<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
PORTARIA CONJUNTA Nº 9 , DE 14 DE ABRIL DE 2020  
Aprova as Diretrizes Brasileiras para Diagnóstico e Tratamento da Doença de NiemannPick Tipo C.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a doença de Niemann-Pick do tipo C no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação n<sup><u>o</u></sup> 451/2019 e n<sup><u>o</u></sup> 502/2020 e os relatórios de recomendação n<sup><u>o</u></sup> 465 – Junho de 2019 e n<sup><u>o</u></sup> 511 – Fevereiro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Brasileiras para Diagnóstico e Tratamento da Doença de Niemann-Pick Tipo C.  
Parágrafo único.  As Diretrizes objeto deste artigo, que contêm o conceito geral da doença de Niemann-Pick do tipo C, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, são de caráter</u> nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da doença de Niemann-Pick do tipo C.  
1  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: DENIZAR VIANNA -->
2  
ANEXO  
DIRETRIZES BRASILEIRAS PARA DIAGNÓSTICO E TRATAMENTO DOENÇA DE NIEMANN-PICK TIPO C

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **1. INTRODUÇÃO** -->
A doença de Niemann-Pick tipo C (NPC) é uma doença de depósito lisossomal neurovisceral, que pode afetar vísceras e cérebro. É causada por um defeito no transporte intracelular de colesterol e glicoesfingolipídeos (1). A doença geralmente ocorre por mutações no gene _NPC1,_ mas também podem ocorrer mutações no gene _NPC2_ , sendo, em ambos, os casos herdadas de forma autossômica recessiva. A maioria dos indivíduos são heterozigotos compostos com mutações exclusivas da família (1). A incidência da doença foi calculada como 1: 120.000 (2), embora publicação recente sugira que esta estimativa possa estar sub-estimada (3). De acordo com relatório da Orphanet de 2019, estima-se que a prevalência da NPC seja de 1:100.000 na Europa (4). Atualmente, não existem dados epidemiológicos brasileiros sobre a NPC.  
A apresentação clínica da NPC varia de uma doença pré-natal fatal a uma doença neurodegenerativa crônica de início na vida adulta (5). Os neonatos podem apresentar ascite e hepatomegalia, e a NPC pode-se associar à dificuldade respiratória por infiltração dos pulmões. Outros lactentes, sem doença hepática ou pulmonar, podem ter hipotonia e atraso no desenvolvimento. A apresentação clássica ocorre na infância média a tardia com o início insidioso de ataxia, paralisia supranuclear vertical do olhar (para cima e para baixo) e demência. Distonia e convulsões são comuns. A morte ocorre geralmente na segunda ou terceira décadas de vida por pneumonia aspirativa. Os adultos são mais propensos a apresentar demência ou sintomas psiquiátricos (1).  
A raridade da doença e a escassez de _expertise_ sobre ela traduzem-se em erro ou atraso de diagnóstico e impedimento ao cuidado adequado, com desgaste emocional dos pacientes e de suas famílias, assim como das equipes de saúde. De outro modo, o diagnóstico exato com o encaminhamento apropriado, proporciona melhoria da qualidade de vida (5). Ainda não há terapia curativa doença-específica disponível para NPC, e a doença progride geralmente para morte prematura. O tratamento é o de suporte  
3  
e sintomático, provido por equipe multiprofissional e interdisciplinar. As presentes Diretrizes destinam-se a orientar a equipe de saúde e fornecer subsídios para o apoio aos pacientes e a seus cuidadores sobre o diagnóstico, tratamento e monitoramento dos casos de NPC.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos da doença de Niemann-Pick do tipo C. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
E75.2:  Outras esfingolipidoses

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3. DIAGNÓSTICO** -->
Pacientes com suspeita moderada a leve devem ser avaliados de modo detalhado a fim de se estabelecer o diagnóstico correto. A avaliação se baseia em achados clínicos e laboratoriais e envolve avaliações oftalmológica, auditiva, neurológica e psiquiátrica. Biomarcadores podem levar à suspeita de NPC, porém os testes genéticos com sequenciamento dos genes _NPC1_ e _NPC2_ é que são diagnósticos (6).  
Na sequência são definidos, detalhadamente, os componentes do diagnóstico de NPC, contendo as características clínicas, diagnóstico diferencial, escala de classificação e diagnóstico laboratorial, organizados ao final em um algoritmo.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1. Manifestações clínicas** -->
A apresentação clínica é extremamente heterogênea e, por vezes, o paciente apresenta sintomas inespecíficos (2, 6), com a idade de início variando do período antenatal à idade adulta (até sétima década de vida). As manifestações clínicas mais comumente associadas à doença de NPC são paralisia do olhar supranuclear  
4  
vertical, cataplexia gelástica <mark>(fraqueza muscular súbita, breve e temporária que provoca a queda do doente, que fica consciente mas incapaz de falar ou de se mexer, e manifesta emoções imotivadas, como o riso e choro),</mark> esplenomegalia isolada, icterícia ou colestase neonatal prolongada, demência ou disfunção cognitiva precoce (7). A sobrevida dos pacientes varia de alguns dias a mais de 60 anos de idade, embora na maioria dos casos o óbito ocorra entre 10 e 25 anos de idade. A progressão da doença e sua mortalidade são influenciados pela idade de início dos sintomas neurológicos, sendo que, na maioria das vezes, quanto mais precoce o início, mais grave a doença (2).  
A doença de NPC pode ser classificada de acordo com a idade de início das manifestações clínicas em 5 grupos distintos (5, 8):

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1.1. Perinatal** -->
- Início antes dos 2 meses de idade, incluindo o período pré-natal (5, 8).  
-  Manifestações sistêmicas: hepatomegalia, esplenomegalia, colestase neonatal, plaquetopenia, insuficiência hepática, hidropsia fetal, ascite fetal, restrição de crescimento intrauterino e doença pulmonar (5).  
- Manifestação neurológica: hipotonia (5).  
- Na forma perinatal, a icterícia desaparece na maioria dos casos espontaneamente ao redor de 3-4 meses de idade, enquanto a visceromegalia persiste por tempo variável. Os sintomas neurológicos são mais tardios. Em cerca de 8%-9% dos casos a doença pode progredir rapidamente para insuficiência hepática ou falência de múltiplos órgãos e óbito em 6 meses. Em alguns casos, a apresentação inicial pode ser ascite e hidropsia fetal. Nos casos rapidamente progressivos, ocorre insuficiente ganho ponderal e hipotonia (5).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1.2. Infantil precoce:** -->
- Início entre 2 meses e 2 anos de idade (5, 8).  
- Manifestações sistêmicas: hepatoesplenomegalia ou esplenomegalia (isolada ou com manifestações neurológicas) e colestase prolongada (5).  
5  
- Manifestações neurológicas: hipotonia central, retardo do desenvolvimento motor, atraso da fala, disfagia, espasticidade, paralisia do olhar vertical supranuclear (POVSN) (5).  
A forma infantil precoce caracteriza-se pela presença de hipotonia e atraso do desenvolvimento motor. A hepatoesplenomegalia ouicterícia neonatal prolongada quase sempre são observadas. A POVSN pode estar presente, porém é dificilmente reconhecida (5).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1.3. Infantil tardio:** -->
- Início entre 2 e 6 anos de idade (5, 8).  
- Manifestações sistêmicas: hepatoesplenomegalia ou esplenomegalia (isolada ou com manifestações neurológicas), história de icterícia neonatal colestática prolongada (5).  
- Manifestações neurológicas: retardo ou regressão do desenvolvimento, atraso da fala, dificuldades de controle motor, quedas frequentes, ataxia progressiva, distonia <mark>(contração que afeta de modo regular um ou vários músculos ou membros e, por vezes, o eixo corporal)</mark> , disartria (dificuldade de articular as palavras), disfagia (dificuldade de engolir), convulsões (parciais ou generalizadas), cataplexia, POVSN e déficit auditivo (5).  
- Na forma infantil tardia, o paciente apresenta dificuldade de controle motor e distúrbio da marcha. Podem ser notados atraso da fala, história de colestase neonatal e visceromegalia variável. A POVSN está tipicamente presente, porém muitas vezes não é reconhecida. O sintoma inicial pode ser a surdez sensorial, podendo ocorrer perda auditiva em altas frequências, anormalidades nos reflexos acústicos ou nas respostas do tronco cerebral no que diz respeito à audição, sugerindo alterações generalizadas (9);  ou a cataplexia gelástica  (como já mencionado, caracterizada pela perda repentina de tônus muscular resultando em quedas ou colapso, frequentemente associada a estímulos emocionais como riso ou choro exagerado) (10) e, algumas vezes, à narcolepsia <mark>(sono súbito e incontrolável, aparentemente sem motivo, que ocorre várias vezes ao dia).</mark> A epilepsia subsequente é muito frequente (5).  
6

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1.4. Juvenil:** -->
- Início entre 6 e 15 anos de idade (5, 8).  
- Manifestações sistêmicas: hepatoesplenomegalia ou esplenomegalia (isolada ou com manifestações neurológicas, as quais não são frequentes) (5).  
- Manifestações neurológicas e psiquiátricas: baixo rendimento escolar, dificuldade de aprendizado, perda da habilidade de linguagem, quedas frequentes, dificuldades de controle motor, ataxia (p <mark>erda do controle muscular durante movimentos voluntários, como andar ou pegar objetos)</mark> progressiva, distonia, dismetria <mark>(incapacidade de direcionar ou limitar adequadamente os movimentos)</mark> , disartria, disfagia, POVSN, cataplexia gelástica, convulsões e distúrbios de comportamento (5).  
- A forma juvenil é a segunda forma mais frequente de apresentação de NPC e se manifesta como distúrbio cognitivo (dificuldade de aprendizado e da fala), problemas de coordenação (dificuldades de controle motor, tem quedas frequentes, ataxia progressiva e distonia) e POVSN (5).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.1.5. Adolescente/adulto:** -->
- Início após 15 anos de idade (5, 8).  
- Manifestação sistêmica: esplenomegalia (frequentemente não presente, pode ocorrer isoladamente em casos muito raros) (5).  
- Manifestações neurológicas e psiquiátricas: declínio cognitivo, demência, dificuldade de aprendizado, esquizofrenia (psicose), depressão, dificuldades de controle motor, sintomas motores progressivos, tremor, ataxia, distonia ou discinesia <mark>(movimentos musculares anormais, involuntários, excessivos, diminuídos ou ausentes),</mark> disartria, disfagia, POVSN (5).  
- A forma de início em adolescentes e adultos corresponde a até um terço dos casos de doença de NPC. Prejuízo cognitivo ocorre invariavelmente e há maior taxa de manifestações neurológicas e psiquiátricas. O atraso diagnóstico é comum, sendo minimizado se a POVSN for identificada (5).  
7  
8  
- A **Figura 1** ilustra as formas de doença de NPC, classificadas de acordo com a idade de surgimento de manifestações neurológicas e com os principais sinais e sintomas que podem estar presentes em cada uma delas.  
<!-- Start of picture text -->
Doenga de Niemann-Pick Tipo C<br>Comprometimento Sistémico<br>(Hepato)Esplenomegalia<br>* Ausente em 15% dos casos;<br>+ Sempre antecede manifestacdes<br>celeste + Idade de inicio varidvel;<br>Ascite fetal/ i y + neurolégicas;Pode regredircom a idade.<br>MMMM" ayespienomegaliaHepato- __Esplenomegalia<br>Idade (anos)<br>1 2 3 6 10 20 300240 50 60<br>Nascimento<br>Infantil Precoce<br>| Infantil Tardio<br>‘traso no Tuventl<br>desenvolvimentd —___——<br>‘motor, hipotonia Difieulde d ee<br>jeit, atraso na Problemas |<br>sv cl ont tana, Sistonia,<br>ee problemas psiquidtricos<br>$$(cataplexia) Pnatisia (deméncia)<br>40 otnarsupranciar vertical ne<br>Comprometimento Neurolégico<br>legends; ~~ PSO urago<br><!-- End of picture text -->  
**Figura 1 -** Esquema da classificação da doença de NPC e os principais sinais e sintomas em cada forma da doença.  
Fonte: Adaptado de Vanier et al., 2010 (2).  
A heterogeneidade clínica da apresentação inicial faz com que os pacientes sejam avaliados pela primeira vez por médicos generalistas ou por diferentes especialistas, sendo muitas vezes o diagnóstico feito tardiamente. Foram desenvolvidos índices de Suspeita (IS) de NPC para auxiliar na identificação precoce dos pacientes, baseados nas manifestações clínicas, combinação de sintomas e história familiar. Esta ferramenta gera um escore de risco preditivo de doença para identificar pacientes que devem ser investigados para doença de NPC (7, 11).  
O IS considera sintomas individuais agrupados em três categorias (viscerais, neurológicos e psiquiátricos), bem como a ocorrência de manifestações entre as categorias e histórico familiar. A pontuação é dada pela somatória de todos os critérios e pode variar de 0 a 352. No critério que considera a presença de sintomas  
9  
entre categorias (visceral e psiquiátrica, visceral e neurológica, neurológica e psiquiátrica), a presença de uma manifestação em cada uma delas é o suficiente para conferir a pontuação máxima ( **Figura 2** ) (7).  
<!-- Start of picture text -->
Peo<br>Muito40 pontos porForte  item ++ POVSN:Cataplexia geldstica oaao dol<br>+ ictericia neonatal, o<br>Forte prolongada inexplicada<br>20 pontos por tem + Esplenomegalia_isoladaemits aida oo * Deciinioeménciacognitive pré-senil e/ou a<br>on<br>==<br>20 pontos por tem + Denacou dst g | ES euEs S| a<br>Freco + Espascdade ———progressna—,-«* «Somes piqudticos restentes  [y<br>Aer + Hops feta 1 * Retard de deservoimento fs) [OGRE Coe Gl)<br>‘1 ponto poritem ‘+ Inmoscom ascite fetal Oo * Convusdes a agressive "<br>ee C7<br>40 ponts: Visceral psiquitca cere + Vscerle 4 Newoléaicae<br>40 pontos:Visceral ©neurologica psiquiatrica Neurolégica psiquiatrica<br>440Histéria10 pontos:pontos:familiarPaisPrimos ou de irmBosNPC Pais‘com ou irmiosNPC. + PrimosNPC com<br>indice de suspeitade NPC Soma dos escores=[]<br><!-- End of picture text -->  
**Figura 2 -** Índice de Suspeita de NPC  
**Legenda:** NPC – Doença de Niemann-Pick tipo C; POSVN – paralisia do olhar vertical supranuclear.  
Fonte: Wijburg et al., 2012 (7).  
Segundo o IS, escores < 40 pontos são indicativos de baixa suspeita, devendo ser consideradas outras doenças ou condições antes de investigar NPC. Para escores entre 40 e 69, há moderada suspeita, sendo necessário acompanhamento e investigação. Escores ≥ 70 são indicativos de alta suspeita e devem ser investigados para NPC (7).  
10

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.2. Diagnóstico Diferencial** -->
Dada a grande heterogeneidade clínica da NPC, há uma ampla gama de diagnósticos diferenciais (12). A seguir, são listados os sintomas comumente observados na doença de NPC e os possíveis diagnósticos que devem ser considerados no diagnóstico para a exclusão de outras doenças que não NPC.  
- Hidropsia fetal: doenças cromossômicas, malformações cardíacas congênitas, hemoglobinopatias, doenças infecciosas, outros erros inatos do metabolismo (13).  
- Icterícia neonatal prolongada: hepatite neonatal idiopática, atresia biliar, galactosemia, deficiência de alfa-1-antitripsina, distúrbios da síntese dos ácidos biliares, fibrose cística, tirosinemia tipo I, colestase familiar intrahepática progressiva, peroxissomopatias (13).  
- Esplenomegalia isolada ou hepatoesplenomegalia:  
mucopolissacaridoses, oligossacaridoses, esfingolipidoses (doença de Gaucher, de Niemann-Pick A e B), deficiência de lipase ácida lisossomal, doença do depósito de glicogênio (13).  
- Distonia: distúrbios da cadeia respiratória, deficiência de piruvato desidrogenase, deficiência de vitamina E, deficiência do transportador de glicose 1, homocistinúria, doença de Wilson, defeitos do ciclo da ureia, acidúria orgânica (13).  
- Ataxia: doenças mitocondriais, ataxia de Friedreich, deficiência de vitamina E, ataxia cerebelar autossômica recessiva (13).  
- Paralisia do olhar vertical supranuclear: paralisia supranuclear progressiva, atrofia sistêmica múltipla, demência com corpúsculos de Lewy, ataxia espinocerebelar, doença de Tay-Sachs, doença de Wilson, deficiência de vitamina B12, encefalopatia de Wernicke, doença de Huntington, doença de Jakob Creutzfeldt (13).  
- Cataplexia gelástica: convulsões gelásticas, tetrade narcoléptica (13).  
- Psicose: histeria, esquizofrenia, doença de Wilson, defeito do ciclo da ureia, porfiria intermitente aguda, xantomatose cerebrotendinosa, homocistinúria (13).  
11

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.3. Diagnóstico laboratorial** -->
**Estudo genético** : Pelo estudo genético, variantes patogênicas bi-alélicas em _NPC1_ correspondem a 95% dos casos e, em _NPC2_ , a cerca de 4% dos casos de NPC (6, 14). A identificação de dois alelos com mutações do gene _NPC1_ ou _NPC2,_ sabidamente associadas à doença _,_ confirma o diagnóstico de NPC. Cerca de 700 variantes _NPC1_ foram relatadas, das quais 420 são consideradas patogênicas (5).  
É difícil estabelecer a relação genótipo e o fenótipo, porém há evidências de que, se ambos os alelos tiverem mutações graves ( _frameshift, nonsense, large deletion_ ), ocorre doença neurológica infantil precoce com maior risco de doença sistêmica neonatal, possivelmente fatal. Homozigose recorrente das mutações _missense_ (em geral p.G1240R) pode também ser classificada nesta categoria. A mutação p.I1061T de _NPC1_ , em homozigose, mais comumente se associa com a forma neurológica de início juvenil e, menos frequentemente, com o fenótipo neurológico infantil tardio. Em heterozigose, dependendo da segunda mutação, é encontrada na forma de início na adolescência e idade adulta. A mutação p.P1007A em _NPC1_ associase mais comumente à forma de início juvenil ou em adulto. Algumas mutações _missense_ em _NPC1_ (p.R978C, p.G992R, p.D874V) podem estar associadas à forma neurológica de início tardio; relatada também em heterozigose com alelo grave ou _null_ (5).  
Vinte e seis mutações patogênicas em _NPC2_ já foram descritas, sendo a maioria das variantes _frameshift_ ou _nonsense_ ou deleção grande, associadas a fenótipos clínicos mais graves. Duas variantes _missense_ p.V39M e p.P120S estão associadas com forma juvenil ou em adulto da doença. As mutações _NPC2_ predominam no Norte da África, Itália e Turquia (5). Na forma perinatal, infiltração pulmonar pelas células xantomatosas e insuficiência respiratória grave ocorre em pacientes com mutações do gene _NPC2_ (13).  
Estudos em numerosas famílias indicam que as mutações _NPC1_ ou _NPC2_ parecem predizer o curso da doença neurológica e não de doença sistêmica (5).  
Os seguintes procedimentos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, são compatíveis com a identificação dessas mutações: 03.01.01.021-8 - Avaliação clínica de diagnóstico de doenças raras - Eixo I: 3 - Erros inatos de metabolismo; 02.02.10.011-1 - Identificaçâo de mutação por  
12  
sequenciamento por amplicon até 500 pares de bases; 02.02.10.007-3 - Análise de dna por MLPA; e 02.02.10.008-1 - Identificação de mutação/rearranjos por PCR, PCR sensível a metilação, QPCR e QPCR sensível a metilação.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Exames de neuroimagem** -->
Os dados de neuroimagem por tomografia computadorizada por emissão de pósitrons (PET) e ressonância magnética (RM) foram obtidos primariamente de pacientes adolescentes e adultos com NPC. O padrão é variável, podendo ser normal principalmente no início da doença. As imagens frequentemente mostram alterações de estruturas cerebrais, embora não sejam específicas para pacientes com NPC. A maioria dos pacientes tem alterações do volume cerebelar que se correlaciona com ataxia e função motora ocular. Com a progressão da doença, ocorre redução no volume do hipocampo, gânglios da base e tálamo. A alteração da substância branca é difusa, na maioria das vezes detectável como alterações da imagem de difusão ou visualmente como atrofia do corpo caloso. Aumento da relação ponte/mesencéfalo, atrofia cerebral principalmente nas regiões frontal e temporal podem ocorrer. A RM comumente mostra hipometabolismo do tálamo e cerebelo (1, 5). Deste modo, recomenda-se realização de RM para auxiliar no diagnóstico da doença, caso esteja disponível nos serviços de saúde em que o paciente esteja sendo avaliado.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.4. Algoritmo diagnóstico de NPC** -->
Caso haja uma suspeita moderada ou alta de NPC, o paciente deverá ser encaminhado a um centro de referência, para que seja feita uma investigação detalhada  
<!-- Start of picture text -->
——Cataplexia argeldstica {indice de suspeita de NPC sxcuirxcluir outrasotras ot<br>Paralisia do olhar supranuclear moderada ou alta (NPA/B, Gaucher, etc.)<br>Ataxia<br>Sintomas psiquiatricos<br>Hepatoesplenomegalia Encaminhar para centros de referéncia<br>ColestaseFamiliares neonatalde 1° grau inexplicadacom NPC v<br>Sequenciamento NPC1/NPC2<br>2 mutacBes 1mutac3o —_Nenhuma mutagio<br>patogénicas patogénica patogénica<br>conhecidas conhecida conhecida<br>v v se forte suspeita clinica permanece<br>Diagnéstico MLPA / Array-CGH<br>mY v<br>2 mutacBes 1 mutacSo Nenhuma mutaco<br>patogénicas patogénica patogénica<br>conhecidas conhecida conhecida 13<br>Diagnéstico Investigag3o subsequente sera<br>NPC determinada por especialistas em<br>erros inatos do metabolismo<br><!-- End of picture text -->  
e o diagnóstico diferencial. O médico, preferencialmente, geneticista ou especialista em doenças raras, deve solicitar teste genético para sequenciamento dos genes _NPC1 e NPC2_ . Sendo identificadas duas mutações patogênicas conhecidas, o diagnóstico da doença de NPC é confirmado. Em alguns casos, uma ou nenhuma mutação patogênica pode ser identificada. Permanecendo forte suspeita clínica, o especialista deve solicitar exames de análise de DNA por MLPA ou CGH _array_ . O diagnóstico da doença será confirmado caso sejam identificadas duas mutações conhecidas. Em caso de uma ou nenhuma mutação identificada, o especialista em erros inatos do metabolismo determinará a necessária investigação subsequente ( **Figura 3** ).  
**Figura 3 -** Algoritmo diagnóstico de Doença de Niemann-Pick tipo C (NPC) **Legenda:** DDL: doença de depósito lisossômica; MLPA _multipleligation dependent probe amplification_ ; NPA/B: Doença de Niemann-Pick tipo A/B; NPC: Doença de Niemann-Pick tipo C.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **3.5. Aconselhamento genético** -->
Sendo a NPC autossômica recessiva, a probabilidade de recorrência para outros irmãos do paciente é de 25%. Portanto, os irmãos do ‘caso índice’ devem ser avaliados quanto à presença de doença de NPC.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Pacientes com diagnóstico de doença Niemann-Pick do tipo C, confirmado por teste molecular dos genes _NPC1_ e _NPC2_ .

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Pacientes com diagnóstico confirmado de outra esfingolipidose, que não doença de NPC (ver em 3.2. Diagnóstico diferencial).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **6. CASOS ESPECIAIS** -->
Casos não diagnosticados de acordo com os critérios adotados devem ser encaminhados para Centro de Referência em Doenças Raras.  
14

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **7. CENTROS DE REFERÊNCIA** -->
Os centros de referência devem possuir uma equipe multidisciplinar integrada de especialistas, incluindo, por exemplo, médicos geneticistas e neurologistas, que assegurem o atendimento abrangente dos pacientes, desde o diagnóstico até o tratamento e seguimento.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **8. TRATAMENTO** -->
O atendimento dos pacientes envolve equipe multidisciplinar (5, 12, 15). Pelo menos uma revisão por ano deve ser realizada, preferencialmente, em centro de referência para doenças raras, contemplando avaliações do estado clínico e exames laboratoriais e de imagem.  
Nestas Diretrizes não está indicado, em qualquer forma da doença de Niemann-Pick, o uso de terapia de redução do substrato (miglustate), haja vista que o mesmo não se associa a benefícios em desfechos clínicos relevantes (16-27). A Portaria nº 35/SCTIE/MS, de 23/07/2019, aprovando o Relatório de Recomendação da CONITEC, decide por não incorporar o miglustate para manifestações neurológicas da doença de Niemann-Pick tipo C, no âmbito do Sistema Único de Saúde (28).  
O objetivo do tratamento da doença de Niemann-Pick do tipo C é reduzir as limitações por ela impostas e melhorar a qualidade de vida dos doentes. Deste modo, o tratamento preconizado pelas presentes Diretrizes dado aos pacientes durante toda sua vida.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **8.1. Tratamento inespecífico** -->
O paciente com NPC tem uma doença crônica, progressiva, multissistêmica e, frequentemente, requer cuidados urgentes por equipe multiprofissional que inclua fonoaudiólogo, fisioterapeuta, terapeuta ocupacional, equipe de enfermagem e diferentes especialidades médicas (5, 12, 15). É crucial que um médico cuide continuamente do paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando o paciente a especialistas conforme necessário e coordenando o atendimento como um todo. O cuidado do paciente deve, preferencialmente, ocorrer em centro de referência, que, quando necessário, poderá dar  
15  
outros encaminhamentos quanto ao cuidado e monitorização em outros níveis de atendimento do SUS.  
Além disso, é necessário que os pacientes e suas famílias sejam orientados sobre a doença e possíveis complicações e riscos também por meio de um relatório escrito. Os pacientes também devem ser informados de que o médico que o atender em caso de emergência deve ser informado sobre doença e receber uma cópia do relatório médico.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **_8.1.2.1.Respiratório_** -->
Entre os objetivos do tratamento clínico, está melhorar o controle das infecções recorrentes das vias aéreas (5, 12, 15). Solução salina isotônica nasal ou hipertônica deve ser usada para eliminar crostas e secreções, melhorar a mobilidade dos cílios e reduzir o edema da mucosa. É comum a ocorrência de infecções respiratórias de vias aéreas superiores crônicas e recorrentes (mais de seis episódios ao ano), sendo recomendado que os pacientes recebam a vacina contra _Streptococcus pneumoniae_ e _Haemophilus influenzae_ (5, 12, 15) _._ Antibióticos são utilizados para o tratamento de exacerbações respiratórias de origem bacteriana agudas.  
O papel da fisioterapia respiratória não foi estudado diretamente na NPC, mas sabe-se que a fisioterapia respiratória visa a melhorar a função pulmonar, ventilação e biomecânica respiratória que podem estar prejudicadas nessa doença.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **_8.1.2.2.Neurológico_** -->
Dependendo da gravidade da doença, as manifestações neurológicas dos pacientes com doença de NPC podem incluir atraso na obtenção dos marcos do desenvolvimento ou regressão neurológica, comprometimento cognitivo e convulsões (5, 12, 15). Recomenda-se o tratamento das crises convulsivas com anticonvulsivantes usualmente indicados para crises tônico-clônicas e, preferencialmente, deve-se iniciar o tratamento em monoterapia com a menor dose eficaz, conforme orientação do Protocolo Clínico e Diretrizes Terapêuticas da Epilepsia vigente, do Minéstério da Saúde (29).  
16

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **_8.1.2.3.Outros aspectos_** -->
Como se trata de uma doença crônica, multissistêmica e progressiva, os pacientes com NPC e suas famílias geralmente requerem apoio psicológico e social considerável, a partir do diagnóstico da doença (5, 12, 15). As associações de pacientes fornecem apoio psicossocial muito importante para as famílias, assim como a possibilidade de estabelecer vínculos com outros indivíduos afetados, proporcionando troca de experiências e melhor enfrentamento das dificuldades encontradas.  
Deve ser oferecido aconselhamento genético a todas as famílias e aos pacientes, visando a fornecer informações sobre heterozigotos, diagnóstico pré-natal e chance de recorrência.  
Medicamentos que causam salivação excessiva ou que possam exacerbar epilepsia por interação com antiepilépticos devem ser evitados. Bebidas alcoólicas e diferentes drogas podem exacerbar a ataxia e também devem ser evitadas (5, 12, 15).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **8.1.3. Tratamento cirúrgico** -->
A deglutição é prejudicada pelo comprometimento neurológico e tende a piorar, aumentando o risco de aspiração (5, 12, 15). Gastrostomia pode, então, ser indicada.  
As principais manifestações clínicas de NPC e as opções de tratamento de suporte e sintomático recomendadas podem ser encontradas no **Quadro 1** . É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e de maior gravidade nos pacientes com as formas graves da doença. Da mesma forma, nem todos os pacientes necessitarão ser submetidos a todas formas de tratamento.  
**Quadro 1 -** Principais manifestações da Doença de Niemann-Pick tipo C e condutas assistenciais correspondentes  
|**Manifestação Clínica**|**Conduta Assistencial**|
|---|---|
|Convulsões|Anticonvulsivantes|
|Cataplexia|Anticonvulsivantes,antidepressivos tricíclicos|
|Distonia|Medicamentoso|
|Distúrbio de deglutição|Fonoaudiológico; gastrostomia se necessário.|
|Ataxia|Fisioterapia|
|Espasticidade|Fisioterapia|
|Retardo Mental/Regressão|Terapia Ocupacional; psicopedagogia|  
17  
|**Manifestação Clínica**|**Conduta Assistencial**|
|---|---|
|Neurológica||
|Distúrbios do sono|Medicamentos indutores do sono|
|Distúrbios psiquiátricos|Medicamentos antidepressivos e antipsicóticos;<br>psicoterapia|
|Constipação intestinal|Medicamentos laxantes|
|Pneumonias de repetição|Fisioterapia respiratória e antibioticoterapia|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **9. MONITORIZAÇÃO** -->
O monitoramento dos pacientes com NPC necessita de equipe multidisciplinar que inclui clínico, neurologista, psiquiatra, oftalmologista, anestesista, fonoaudiólogo, otorrinolaringologista, fisioterapeuta, terapeuta ocupacional, nutricionista, ortopedista, assistente social e geneticista.  
O monitoramento da doença e da resposta ao tratamento deve ser periódica e envolver avaliação clínica e realização de exames laboratoriais e de imagem. No **Quadro 2** , constam os principais parâmetros e exames a serem adotiados, bem como a frequência ideal do acompanhamento.  
**Quadro 2 -** Avaliações recomendadas no monitoramento da Doença de Niemann-Pick tipo C (NPC)  
|**Avaliação**|**Hustificativa**|**Frequência***|
|---|---|---|
|Análise genética de<br>_NPC-1/NPC-2_|Confirmar diagnóstico de NPC.|Ao diagnóstico.|
|História inicial|Estabelecer a atual gravidade da<br>doença<br>e<br>estimar<br>taxa<br>de<br>progressão retrospectivamente.|Ao diagnóstico.|
|Ultrassonografia<br>abdominal|Avaliar a medida do fígado e do<br>baço.|Ao diagnóstico.|
|Aconselhamento<br>genético|Educar a família e avaliar irmãos<br>do<br>caso<br>índice<br>quanto<br>à<br>ocorrência de doença.|Ao diagnóstico e a cada<br>24 meses.|
|Intervalo de história|Estabelecer<br>a<br>progressão<br>da<br>doença;<br>monitorar<br>adesão<br>e<br>efeitos<br>adversos<br>da<br>terapia;<br>monitorar<br>condições<br>que<br>indiquem suspensão imediata da<br>terapia; monitorar surgimento de<br>novos sintomas.|A cada 6 meses.|
|Exame físico|Documentar<br>parâmetros<br>de<br>crescimento;<br>avaliar<br>características<br>neurológicas<br>e<br>visceromegalias.|Ao diagnóstico e a cada<br>12 meses.|
|Escore clínico de|Documentar<br>principais|Ao diagnóstico e a cada|  
18  
|**Avaliação**|**Hustificativa**|**Frequência***|
|---|---|---|
|gravidade do NPC<br>(**Quadro 3**)|características<br>da<br>doença<br>ao<br>diagnóstico,<br>progressão<br>e<br>resposta à terapia.|12 meses.|
|Avaliação<br>neuropsiquiátrica|Documentar<br>e<br>tratar<br>as<br>manifestações<br>psiquiátricas<br>e<br>resposta à terapia.|Ao diagnóstico e a cada<br>12 meses.|
|Avaliação do<br>desenvolvimento<br>ou cognitivo|Documentar o grau de prejuízo<br>cognitivo<br>basal<br>e<br>monitorar<br>resposta à terapia.|Ao diagnóstico e a cada 6<br>em crianças e a cada 12<br>meses em adultos.|
|Avaliação<br>oftalmológica|Documentar<br>velocidade<br>de<br>movimento ocular sacádico e<br>presença de paralisia do olhar<br>basal e documentar resposta ao<br>tratamento.|Ao diagnóstico, 6 e 12<br>meses; após início do<br>tratamento;<br>posteriormente, avaliação<br>a cada 24 meses.|
|Audiometria|Documentar presença de perda<br>auditiva.|Ao diagnóstico e a cada<br>12 meses.|
|Avaliação<br>Nutricional|Avaliar<br>se<br>necessidades<br>nutricionais estão sendo atendidas<br>adequadamente.|Ao diagnóstico e a cada<br>12 meses.|
|Avaliação<br>Fonoaudiológica|Avaliar audição, deglutição e<br>fala.|Ao diagnóstico e a cada<br>24 meses.|
|Avaliação da<br>deglutição|Avaliação clínica da deglutição<br>em<br>todos<br>os<br>pacientes;<br>documentar presença de disfagia<br>e<br>aspiração<br>e<br>resposta<br>ao<br>tratamento.|Ao diagnóstico e depois a<br>cada 6 meses em crianças;<br>a cada 12 meses em<br>adultos assintomáticos e<br>com a doença estável.|
|Neuroimagem -<br>Ressonância<br>magnética de crânio|Avaliar a neuroanatomia.|Ao<br>diagnóstico,<br>se<br>disponível. Reavaliação de<br>acordo<br>com<br>disponibilidade<br>e<br>necessidade.|
|Avaliação com<br>cirurgião ortopédico|Avaliar quanto à necessidade de<br>cirurgia<br>para<br>correção<br>de<br>escoliose, espasticidade, retração<br>ósteo-articular, e problemas no<br>quadril.|Ao diagnóstico e a cada<br>24 meses.|
|Avaliação com<br>cirurgião geral|Avaliar quanto à necessidade de<br>gastrostomia ou traqueostomia.|Referência<br>conforme<br>avaliação<br>médica<br>e<br>nutricional.|
|Exames<br>laboratoriais<br>[Hemograma,<br>plaquetas,<br>AST/TGO, ALT/,<br>bilirrubinas, gama-<br>GT, dosagem sérica<br>de proteínas<br>(albumina) e  tempo<br>e atividade de|Auxiliar o diagnóstico; monitorar<br>terapêutica.|Ao diagnóstico e a cada<br>12 meses.|  
19  
|**Avaliação**|**Hustificativa**|**Frequência***|
|---|---|---|
|protrombina].|||  
*A periodicidade de qualquer item da avaliação pode ser alterada de acordo com quadro clínico do paciente. Fonte: _International Niemann-Pick Disease Registry._  
O uso de escores de gravidade da doença é útil para avaliar a resposta terapêutica e determinar o prognóstico e é preconizado nestas Diretrizes ( **Quadro 3** ). Trata-se de um escore composto, em que quanto maior a somatória, mais grave a doença (5).  
**Quadro 3 -** Critérios de avaliação de gravidade da doença  
|**ESCALA DE INCAPACIDADE FUNCIONAL**|
|---|
|**Deambulação**<br>**Escore**|
|Normal<br>0|
|Desajeitada<br>1|
|Marcha atáxica autônoma<br>2|
|Deambulação assistida ao ar livre<br>3|
|Deambulação assistida emambiente coberto<br>4|
|Uso de cadeira de rodas<br>5|
|**Manipulação**<br>**Escore**|
|Normal<br>0|
|Tremor<br>1|
|Dismetria/distonia mínima(permite manipulação autônoma)<br>2|
|Dismetria/distonia leve (requer auxílio para várias tarefas,<br>mas se alimenta sozinho<br>3|
|Dismetria/distonia grave (requer auxílio para todas as<br>atividades)<br>4|
|**Linguagem**<br>**Escore**|
|Normal<br>0|
|Aquisição atrasada<br>1|
|Disartria leve(compreensível)<br>2|
|Disartria grave (compreensível para alguns membros<br>familiares)<br>3|
|Comunicação nãoverbal<br>4|
|Ausência de comunicação<br>5|
|**Deglutição**<br>**Escore**|
|Normal<br>0|
|Disfagia ocasional<br>1|
|Disfagia diária<br>2|
|Sonda nasogástrica ougastrostomia<br>3|
|**Movimentos oculares**<br>**Escore**|
|Normal<br>0|
|Acompanhamento ocular lento<br>1|
|Oftalmoplegiavertical<br>2|
|Oftalmoplegia completa<br>3|  
20  
|**Convulsões**|**Escore**|
|---|---|
|Não|0|
|Sim,controlada com antiepilépticos|2|
|Sim, não controlada com 2 ou mais antiepilépticos na dose<br>máxima|4|
|**AVALIAÇÃO NEUROCOGNITIVA**|**Presença/Ausênci**<br>**a**|
|**Desenvolvimento (< 12 anos de idade)**||
|Normal||
|Retardo de aprendizado leve||
|Retardo de aprendizado moderado||
|Retardograve/platô||
|Regressão||
|**Memória (> 12 anos de idade)**||
|Normal||
|Prejuízo leve||
|Prejuízo moderado||
|Dificuldade em seguir comandos||
|_Incapaz de seguir comandos_||  
Fonte: Adaptado de Geberhiwot et al., 2018 (5).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **10. REGULAÇÃO/ CONTROLE/ AVALIAÇÃO PELO GESTOR** -->
Pacientes com suspeita de doença de NPC devem, preferencialmente, ser encaminhados para um centro de referência em doenças raras para seu adequado diagnóstico e inclusão no tratamento. No caso de localidades onde inexistam tais centros, recomenda-se que o profissional médico entre em contato com um especialista em doenças raras para discussão do caso e conduta assistencial adequada. A avaliação e o tratamento iniciais devem, preferencialmente, ocorrer em centro de referência ou serviço especializado, podendo ocorrer de modo descentralizado, de acordo com a disponibilidade dos serviços de saúde nas diferentes esferas de atuação.  
Devem ser observados os critérios de inclusão e exclusão de pacientes, a duração e a monitorização do tratamento.  
Verificar no Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP), disponível em http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp, os exames laboratoriais e procedimentos especificados nestas Diretrizes.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **11. REFERÊNCIAS** -->
21  
1. MC P. Niemann-Pick Disease. In: Schapira A WZ, Dawson TM, Wood N, editor. Neurodegeneration. 1st ed. Hoboken, NJ: Wiley Blackwell; 2017. p. 303-8.  
2. Vanier MT. Niemann-Pick disease type C. Orphanet J Rare Dis. 2010;5:16.  
3. Wassif CA CJ, Iben J, Sanchez-Pulido L, Cougnoux A, Platt FM, Ory DS, Ponting CP, Bailey-Wilson JE, Beisecker LG, Porter FD.   . High incidence of unrecognized visceral/neurological late-onset Niemann-Pick disease, type C1, predicted by analysis of massively parallel sequencing data sets. Genetics in Medicine. 2015;18(1):41-8.  
4. Orphanet. Prevalence and incidence of rare diseases: Bibliographic data - Orphanet Report Series - Rare Diseases collection. 2019;1.  
5. Geberhiwot T  MA, Dardis A, Ramaswami U, Sirrs S, Pineda Marfa M, Vanier MT, Walterfang M, Bolton S, Dawson C, Héron B, Stampfer M, Imrie J, Hendriksz C, Gissen P, Crushell E, Coll MJ, Nadjar Y, Klünemann H, Mengel E, Hrebicek M, Jones SA, Ory D, Bembi B, PattersonM. Consensus clinical management guidelines for Niemann-Pick disease type C. Orphanet Journal of Rare Diseases. 2018;13(50).  
6. Patterson MC, Clayton P, Gissen P, Anheim M, Bauer P, Bonnot O, et al. Recommendations for the detection and diagnosis of Niemann-Pick disease type C : An update. Neurology: Clinical Practice. 2017;7(6):499-511.  
7. Wijburg FA SF, Pineda M, Hendriksz CJ, Fahey M, Walterfang M, Patterson MC, Wraith JE, Kolb SA. Development of a Suspicion Index to aid diagnosis of NiemanPick disease type C Neurology. 2012;78:1560-7.  
8. Lyseng-Williamson KA. Miglustat: a review of its use in Niemann-Pick disease type C. Drugs. 2014;74(1):61-74.  
9. King K G-SS, Yanjamin N, Zalewski C, Houser A, Porter F, Brewer CC. Auditory Phenotype of Niemann-Pick Disease, Type C1. Ear Hear. 2014;35(1):110-7.  
10. Mengel E, Klünemann HH, Lourenço CM, Hendriksz CJ, Sedel F, Walterfang M, et al. Niemann-Pick disease type C symptomatology: An expert-based clinical description. Orphanet Journal of Rare Diseases. 2013;8(1).  
11. Wijburg FA, Mengel E, Patterson MC, Wraith JE, Vanier MT, Schwierin B, et al. The international registry for niemann-pick disease type c (NP-C) in clinical practice. Archives of Disease in Childhood. 2012;97:A297.  
12. Pineda M ME, Jahnová  H, Héron B, Imrie J, Lourenço CM, van der Linden V, Karimzadeh P, Valayannopoulos V, Jesina P, Torres JV, Kolb SA. A Suspicion Index to aid screening of early-onset Niemann-Pick disease Type C (NP-C). BMC Pediatr. 2016;16(107):1-10.  
13. Wraith JE, Baumgartner MR, Bembi B, Covanis A, Levade T, Mengel E, et al. Recommendations on the diagnosis and management of Niemann-Pick disease type C. Molecular Genetics and Metabolism. 2009;98(1-2):152-65.  
14. Alobaidy H. Recent advances in the diagnosis and treatment of niemann-pick disease type C in children: a guide to early diagnosis for the general pediatrician. Int J Pediatr. 2015;2015:816593.  
15. Pineda M, Walterfang M, Patterson MC. Miglustat in Niemann-Pick disease type C patients: a review. Orphanet J Rare Dis. 2018;13(1):140.  
16. Patterson MC, Hendriksz CJ, Walterfang M, Sedel F, Vanier MT, Wijburg F. Recommendations for the diagnosis and management of Niemann-Pick disease type C: an update. Mol Genet Metab. 2012;106(3):330-44.  
17. Patterson MC, Vecchio D, Prady H, Abel L, Wraith JE. Miglustat for treatment of Niemann-Pick C disease: a randomised controlled study. Lancet Neurol. 2007;6(9):765-72.  
18. Freihuber C, Dahmani B, Brassier A, Broue P, Cances C, Chabrol B, et al. Effects of miglustat therapy on neurological disorder and survival in early-infantile  
22  
niemann-Pick disease type C: A national French retrospective study. European Journal of Paediatric Neurology. 2017;21:e2.  
19. Ginocchio VM, D'Amico A, Bertini E, Ceravolo F, Dardis A, Verrigni D, et al. Efficacy of miglustat in Niemann-Pick C disease: a single centre experience. Mol Genet Metab. 2013;110(3):329-35.  
20. Héron B, Valayannopoulos V, Baruteau J, Chabrol B, Ogier H, Latour P, et al. Miglustat therapy in the French cohort of paediatric patients with Niemann-Pick disease type C. Orphanet Journal of Rare Diseases. 2012;7(1).  
21. Patterson M, Vecchio D, Jacklin E, Wraith E. Long-term clinical trial with miglustat in Niemann-Pick disease type C. Molecular Genetics and Metabolism. 2009;96(2):S33-S4.  
22. Wraith JE, Vecchio D, Jacklin E, Abel L, Chadha-Boreham H, Luzy C, et al. Miglustat in adult and juvenile patients with Niemann-Pick disease type C: long-term data from a clinical trial. Mol Genet Metab. 2010;99(4):351-7.  
23. Patterson MC, Vecchio D, Jacklin E, Abel L, Chadha-Boreham H, Luzy C, et al. Long-term miglustat therapy in children with Niemann-Pick disease type C. J Child Neurol. 2010;25(3):300-5.  
24. Patterson MC, Garver WS, Giugliani R, Imrie J, Jahnova H, Meaney FJ, et al. Does miglustat treatment confer a benefit on survival in NP-C? Insights from a large observational cohort study. Journal of Inherited Metabolic Disease. 2018;41:S181.  
25. Patterson MC, Vanier MT, Mengel E, Moneuse P, Rosenberg D, Schwierin B, et al. Miglustat treatment is associated with stabilised disability scores in patients from the International NPC Registry. Journal of Inherited Metabolic Disease. 2018;41:S181. 26. Patterson MC, Mengel E, Vanier MT, Schwierin B, Muller A, Cornelisse P, et al. Stable or improved neurological manifestations during miglustat therapy in patients from the international disease registry for Niemann-Pick disease type C: an observational cohort study. Orphanet J Rare Dis. 2015;10:65.  
27. Fecarotta S, Romano A, Della Casa R, Del Giudice E, Bruschini D, Mansi G, et al. Long term follow-up to evaluate the efficacy of miglustat treatment in Italian patients with Niemann-Pick disease type C. Orphanet J Rare Dis. 2015;10:22.  
28. BRASIL. MIGLUSTATE PARA MANIFESTAÇÕES NEUROLÓGICAS DA DOENÇA DE NIEMANN-PICK TIPO C (NPC). In: Saúde Md, editor. Brasília2019. 29. Brasil. PORTARIA Nº 35, DE 23 DE JULHO DE 2019. Torna pública a decisão de não incorporar o miglustate para manifestações neurológicas da doença de NiemannPick tipo C, no âmbito do Sistema Único de Saúde - SUS. In: Saúde Md, editor. Brasilia: Diário Oficial da União; 2019. 30. Brasil. PORTARIA CONJUNTA Nº 17, DE 21 DE JUNHO DE 2018. In: Saúde Md, editor. Brasília: DOU; 2018. p. 45.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **APÊNDICE 1** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA  
As Diretrizes Brasileiras para Diagnóstico e Tratamento da Doença de Niemann-Pick tipo C teve início com uma reunião presencial para delimitação do escopo do documento. Esta reunião foi composta por três membros do Comitê Gestor e  
23  
por cinco membros do Grupo Elaborador, sendo três especialistas (uma hepatologista pediátrica e duas geneticistas) e dois metodologistas. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflito de Interesses e de Confidencialidade.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do documento, sendo definida a sua macroestrutura, embasado no disposto em Portaria N° 375/SAS/, de 10/11/2009 (32) e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde (33), sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Deste modo, as especialistas foram orientadas a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO ( **Figura A** ) para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida técnico-científica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião.  
Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas no SUS não teriam questões de pesquisa definidas, por se tratar de prática assistencial já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.  
Para as presentes Diretrizes, apenas uma questão de pesquisa foi levantada, referente ao uso do miglustate para o tratamento da doença de NPC: “Qual a eficácia e segurança do miglustate para o tratamento de pacientes adultos e pediátricos com doença de Niemann-Pick tipo C?”  
Nesta pergunta ( **Figura A)** , pacientes (P) eram os doentes de NPC, pediátricos ou adultos; intervenção (I) era o miglustate; comparador (C) eram os cuidados padrão e paliativos; e desfechos (O) eram aumento de sobrevida, aumento da qualidade de vida,  
24  
estabilização da doença neurológica e psiquiátrica (distúrbio de deglutição, marcha, distonia, cataplexia gelástica, convulsão, declínio cognitivo), estabilização de escores neuropsicológicos.  
<!-- Start of picture text -->
P • População ou condição clínica<br>• Intervenção, no caso de estudos experimentais<br>I • Fator de exposição, em caso de estudos observacionais<br>• Teste índice, nos casos de estudos de acurácia diagnóstica<br>C • Controle, de acordo com tratamento/níveis de exposição do fator/exames disponíveis no SUS<br>O • Desfechos: sempre que possível, definidos a priori, de acordo com sua importância<br><!-- End of picture text -->  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
A relatoria das seções foi distribuída entre as médicas especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática assistencial estabelecidas e apenas com tecnologias já disponíveis no SUS), as especialistas foram orientadas a referenciar a recomendação com base nos estudos pivotais que consolidaram aquela prática. Quando a seção continha uma ou mais questões de pesquisa, as relatoras, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas à ocasião da reunião de consenso.  
Acordou-se que a equipe de metodologistas envolvida no processo ficaria responsável pela busca e avaliação de evidências, segundo a Metodologia GRADE. Deste modo, a busca na literatura foi realizada nas bases PubMed e Embase e validadas no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
25  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e validado por um segundo, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com metaanálise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia e segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiu-se que estudos com menos de 10 participantes seriam desconsiderados. Dada a natureza da doença, mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Os estudos excluídos após leitura completa tiveram suas razões de exclusão relatadas, referenciadas e estão apresentadas ao longo deste Apêndice. O processo de seleção dos estudos foi representado em forma de fluxograma e também pode ser visto ao longo do texto deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel®. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
26  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (34), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (35) e os estudos observacionais pela ferramenta Newcastle-Ottawa (36). Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ ) (37), de forma qualitativa, visto que, dada a heterogeneidade dos dados, não foi possível conduzir meta-análise do conjunto de evidências. O conjunto de evidências foi avaliado para cada desfecho considerado neste Apêndice, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles. Posteriormente, ainda de acordo com a Metodologia GRADE, foi criada a tabela _Evidence to Decision_ (EtD), que sumariza os principais achados do processo de avaliação da tecnologia segundo aspectos que devem ser levados em consideração no momento de tomada de decisão sobre a incorporação do produto (magnitude do problema, benefícios, danos, balanço entre danos e benefícios, certeza na evidência, aceitabilidade, viabilidade de implementação, uso de recursos, custo-efetividade, equidade, valores e preferências dos pacientes) (38).  
Após a conclusão do Relatório de Recomendação do miglustate e de sua apresentação à 76ª Reunião Ordinária da CONITEC, houve reunião de monitoramento e consenso, da qual participaram membros do Grupo Elaborador, sendo as três especialistas e os dois metodologistas inicialmente envolvidos no processo. Nessa reunião, foram apresentados os resultados do relatório e a deliberação inicial de não incorporação do miglustate, bem como discutido o progresso na escrita do relatório e a necessidade de ajustes. Para mais informações sobre a avaliação do miglustate. o  
27  
processo de tomada de decisão e o Relatório de Recomendação, consultar o sítio eletrônico da CONITEC (39).  
**Questão de pesquisa: “Qual a eficácia e segurança no miglustate para o tratamento**  
**de pacientes adultos e pediátricos com doença de Niemann-Pick tipo C?”**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **A. Estratégia de busca** -->
O **Quadro A** resume a estratégia de busca utilizada.  
**Quadro A -** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Resultados**|
|---|---|---|
|Pubmed|(("Niemann-Pick Disease, Type C"[Mesh] OR niemann-<br>pick disease type c OR niemann-pick c disease OR<br>niemann-pick c OR niemann pick c disease OR niemann<br>pick c)) AND ("miglustat" [Supplementary Concept]<br>OR miglustat OR zavesca)<br>Data de acesso:22/10/2018|139|
|Embase|('niemann pick disease'/exp OR 'niemann pick disease'<br>OR 'niemann pick disease type c'/exp OR 'niemann pick<br>disease type c' OR 'niemann pick c' OR 'niemann-pick<br>disease type c'/exp OR 'niemann-pick disease type c' OR<br>'niemann-pick c') AND [embase]/lim DN ('zavesca'/exp<br>OR 'zavesca' OR 'miglustat'/exp OR 'miglustat') AND<br>[embase]/lim<br>Data de acesso:22/10/2018|386|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **B. Seleção das evidências** -->
A busca das evidências resultou em 525 referências (139 no MEDLINE e 386 no EMBASE). Destas, 115 foram excluídas por estarem duplicadas. Quatrocentas e dez referências foram triadas por meio da leitura de título e resumos, das quais 40 tiveram seus textos completos avaliados para confirmação da elegibilidade. Após a leitura do texto completo dos estudos, vinte e sete estudos foram excluídos: (1) Dois por tipo de estudo: revisões sistemáticas, sem meta-análise estratificada (40, 41); (2) Cinco estudos por tipo de desfecho: 2.1) Dois que avaliaram possíveis marcadores para monitoramento do tratamento (42, 43); 2.2) Dois que avaliaram alterações de estruturas cerebrais decorrentes do uso de miglustate (44, 45); 2.3) Um que avaliou indicações de  
28  
tratamento (46); (3) Oito pela forma de apresentação dos dados (47-54); e (4) Doze por apresentarem versões de artigos completos ou mais recentes (55-66). No **Quadro B** encontram-se as justificativas para exclusão de cada estudo avaliado pela leitura completa.  
**Quadro B -** Estudos excluídos no processo de seleção das evidências, com justificativas individuais.  
|**Ano**|**Autor**|**Tipo de**<br>**Estudo**|**Justificativa para exclusão**|
|---|---|---|---|
|2015|Abel et al.<br>(47)|Coorte|Apresenta inconsistências nas avaliações, sendo<br>que pacientes apresentaram diferentes tempos e<br>números de reavaliações. Apresenta análise<br>ajustada conforme perdas. Inclui pequeno<br>número de pacientes (6 no grupo tratamento e 3<br>no grupo controle).|
|2015|<sup>Bowman et</sup><br>al. (45)|Coorte|<br>Avalia alterações em estruturas cerebrais<br>decorrentes da terapia com miglustate|
|2018|<sup>Bowman et</sup><br>al. (44)|Coorte|Avalia alterações em estruturas cerebrais<br>decorrentes da terapia com miglustate|
|2009|<sup>Fecarotta et</sup><br>al. (56)|Série de<br>casos|Estudo com artigo completo e dados mais<br>recentes (Fecarotta et al., 2015)|
|2015|<sup>Freihuber et</sup><br>al. (55)|Coorte|Estudo com dados mais recentes e completos<br>(Freihuber et al., 2017)<br>|
|2016|<sup>Giugliani et</sup><br>al. (48)|Coorte|Apresenta dados de sobrevida para tratados e<br>não tratados, mas não fornece nenhum teste para<br>avaliar a diferença entre os grupos.<br>Incluiu 21 pacientes, dos quais apenas 12<br>|
|2017|Heitz et al.<br>(49)|Série de<br>casos|receberam miglustate. Os resultados são<br>apresentados de modo geral, para os 21<br>pacientes, não sendo avaliar a influência do<br>grupo não tratado nos resultados.|
|2010|Jacklin et<br>al. (53)|Série de<br>casos|<br>Não apresenta critérios de<br>melhora/estabilização.|
|2012|<sup>Karimzadeh</sup><br>et al. (50)|Série de<br>casos|Apresentação irregular dos dados.|
|2018|Nadjar et<br>al. (51)|Coorte|Agrupa dados de controles com pacientes com<br>tempo de tratamento < 2 anos.|
|2009b|<sup>Patterson et</sup><br>al. (64)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2009c|<sup>Patterson et</sup><br>al. (66)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2014|<sup>Patterson et</sup><br>al. (65)|Série de<br>casos|<br>Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2014|Pineda et<br>al. (61)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2013|Pineda et|Série de|Apresenta versão de estudo com dados mais|
||al. (62)|casos|completos e recentes (Patterson et al., 2015)|  
29  
|**Ano**|**Autor**|**Tipo de**<br>**Estudo**|**Justificativa para exclusão**|
|---|---|---|---|
|2013<br>2010|Pineda et<br>al. (63)<br>Pineda et<br>al. (52)|Série de<br>casos<br>Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)<br>Apresenta resultados individuais para cada<br>paciente, sem medida-resumo. Apresenta grande<br>número de perdas para uma amostra já limitada.|
|2009b|Pineda et<br>al. (57)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos (Pineda et al., 2009a)|
|2009c|Pineda et<br>al. (60)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2009d|Pineda et<br>al. (59)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2009e|Pineda et<br>al. (58)|Série de<br>casos|Apresenta versão de estudo com dados mais<br>completos e recentes (Patterson et al., 2015)|
|2011<br>2009|Pineda et<br>al. (46)<br>Poyato et<br>al. (54)|Série de<br>casos<br>Coorte|Avalia indicações de uso do miglustate (início,<br>manutenção e suspensão do tratamento)<br>Não apresenta dados quantitativos (absolutos ou<br>relativos) referentes à eficácia do miglustate<br>sobre parâmetros de incapacidade.|
|2012|<sup>Ribas et al.</sup><br>(43)|Coorte|Avalia marcadores para monitoramento de<br>tratamento.|
|2015|Santos-<br>Lozano et<br>al. (40)|Revisão<br>Sistemática|Não apresenta meta-análise.|
|2016|Sedel et al.<br>(42)|Série de<br>casos<br>Revisão|Avalia marcadores para monitoramento de<br>tratamento. Não tem braço comparador para<br>avaliar mudanças sem miglustate.|
|2012|<sup>Walterfang</sup><br>et al. (41)|Sistemática<br>+ Meta-<br>análise|Inclui outras doenças degenerativas, sem<br>estratificar na análise.|  
30  
Ao final, foram incluídas 12 referências (16-26, 67), sendo um ensaio clínico randomizado (16), do qual derivaram três estudos de extensão (20-22) e uma análise _post hoc_ (67); uma coorte retrospectiva (17), quatro estudos baseados em registros internacionais a  doença (23-26), e duas séries de caso (18, 19). A representação do processo de seleção das evidências encontra-se esquematizada no fluxograma a seguir ( **Figura B** ).  
31

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Figura B -** Fluxograma representativo do processo de seleção da evidência. -->
<!-- Start of picture text -->
Publicações identificadas por pesquisa nas<br>bases de dados: 525<br>PUBMED = 139<br>EMBASE= 386<br>Busca Manual= 0<br>Publicações após remoção de duplicatas: 410  Publicações excluídas segundo<br>critérios de exclusão: 370<br>Publicações excluídas segundo<br>critérios de exclusão: 27<br>Publicações selecionadas para leitura  Tipo de delineamento: 02<br>completa: 39  Tipo de desfecho: 05<br>Apresentação dos dados: 08<br>Disponibilidade de versão mais<br>completa ou recente: 12<br>Estudos incluídos: 12 estudos<br>Ensaio clínico randomizado: 01<br>Estudos de Coorte: 01<br>Séries de caso: 10<br>Identificação<br>Triagem<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**C. Descrição dos estudos e resultados**  
A descrição sumária dos estudos incluídos encontra-se na **Tabela A** .  A caracterização dos participantes de cada estudo pode ser vista na **Tabela B** . Resultados de eficácia do miglustate encontram-se nas **Tabelas C e D** . Na **Tabela E** , podem ser vistos os desfechos de segurança relacionados ao uso do miglustate. A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista na **Tabela F** , que corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT. A **Tabela G** inclui os **quadros C** a E (análises de impacto orçamentário de custos com medicamento e exames diagnósticos de 2020-2024) e  
32  
contém a sumarização das evidências, organizadas de acordo com o _layout_ da tabela _Evidence to Decision_ (EtD), também da Metodologia GRADE.  
33  
**Tabela A -** Características dos estudos selecionados para avaliar eficácia e segurança do miglustate para o tratamento da forma neurológica de NPC.  
|**Ano**|**Estudo**|**Desenho de**<br>**estudo**|**Objetivo**|**Classificação da**<br>**NPC**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|
|**2007**|**Patterson**<br>**et al.**|Ensaio<br>Clínico<br>Randomizado|Avaliar efeitos de<br>miglustate no<br>tratamento de NPC em<br>pacientes adultos,<br>adolescentes e<br>pediátricos|adulto e<br>pediátrico|41 pacientes<br>com NPC|Miglustate<br>(n=20<br>pacientes<br>adultos e 12<br>pediátricos)<br>(Ajustado de<br>acordo com<br>superfície<br>corpórea)|cuidados<br>padrão<br>(n=9)|12 meses|
|**2009**|**Patterson**<br>**et al.**|Série de<br>casos|Relatar desfechos de<br>longo prazo do ensaio<br>clínico de Patterson et<br>al., 2007|adolescentes e<br>adultos|16 pacientes<br>(36 meses -<br>n=15; 42<br>meses - n=<br>11; 48 meses<br>- n=9; 66<br>meses - n=2)|Miglustate<br>(200 mg<br>3x/dia)|Não se<br>aplica|até 66<br>meses|
|**2009**|**Wraith et**<br>**al.**|Série de<br>casos|Apresentar dados de<br>análise post hoc de<br>progressão de doença<br>neurológica|pediátrico (n=10)<br>e adulto (n=19)|29 pacientes<br>com NPC|Miglustate<br>(200mg 3x<br>dia ou<br>ajustado de<br>acordo com<br>a superfície<br>corpórea)|Não se<br>aplica|Não<br>informado|  
34  
|**Ano**|**Estudo**|**Desenho de**<br>**estudo**|**Objetivo**|**Classificação da**<br>**NPC**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|
|**2010**|**Patterson**<br>**et al.**|Série de<br>casos<br>(extensão<br>Patterson et<br>al., 2007)|Relatar dados de<br>eficácia em pacientes<br>que receberam<br>miglustate por pelo<br>menos 24 meses e<br>segurança e<br>tolerabilidade de terapia<br>de extensão em até 52<br>meses|pediátrico|10 pacientes<br>com NPC|Miglustate<br>(Ajustado de<br>acordo com<br>superfície<br>corpórea)|Não se<br>aplica|24 meses/<br>52 meses<br>para<br>segurança|
|**2010**|**Wraith et**<br>**al.**|Série de<br>casos|Relatar dados de<br>eficácia e segurança a<br>longo prazo do<br>miglustate em pacientes<br>juvenis e adultos|juvenis e adultos|12 meses:<br>n=21/ 24<br>meses: n=15/<br>segurança (66<br>meses):n=28|Miglustate<br>(200 mg<br>3x/dia)|Não se<br>aplica|24 meses/<br>até 66<br>meses para<br>segurança|
||||Comparar desfecho de||||||
|**2017**|**Freihuber**<br>**et al.**|Coorte<br>retrospectiva|neurodesenvolvimento<br>tratados e não tratados<br>com NPC infantil<br>precoce|Infantil-precoce|26 pacientes<br>com NPC|Miglustate<br>(n=10)|sem<br>tratamento<br>(n=16)|Não<br>informado|
|**2018a**|<sup>**Patterson**</sup><br>**et al.**|Série de<br>casos|Avaliar o efeito de<br>miglustate na sobrevida<br>depacientes comNPC|infantil precoce,<br>infantil tardio,<br>adulta/adolescente|590 pacientes<br>com NPC|Miglustate|Não se<br>aplica|Não<br>informado|
||||Relatar dados de<br>|infantil precoce<br>(9,4%), infantil|||||
|**2018b**|<sup>**Patterson**</sup><br>**et al.**|Série de<br>casos|progressão de doença<br>em pacientes tratados<br>com miglustate por pelo<br>menos 12 meses|tardia (29,5%),<br>juvenil (36,2%),<br>adolescente/<br>adulta(25%)|241 pacientes<br>com NPC|Miglustate|Não se<br>aplica|média: 3,29<br>anos|  
35  
|**Ano**|**Estudo**|**Desenho de**<br>**estudo**|**Objetivo**|**Classificação da**<br>**NPC**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|
|**2009**|**Pineda et**<br>**al.**|Série de<br>casos|Relatar dados de<br>vigilância pós<br>comercialização do<br>miglustate para<br>pacientes comNPC|infantil precoce,<br>infantil tardio,<br>adulta/adolescente|102 pacientes<br>com NPC|Miglustate<br>(Ajustado de<br>acordo com<br>superfície<br>corpórea)|Não se<br>aplica|6 anos|
|**2015**|**Patterson**<br>**et al.**|série de casos|Apresentar dados<br>longitudinais de<br>progressão de doença e<br>observações de<br>segurança em pacientes<br>do Registro de NPC em<br>países europeus|infantil precoce,<br>infantil tardio,<br>adulta/adolescente|92 pacientes<br>com NPC|Miglustate|Não se<br>aplica|média (DP):<br>2 (0,7) anos|
|**2015**|**Fecarotta**<br>**et al.**|Série de<br>casos|Relatar os achados de<br>um ensaio clínico<br>independente do<br>miglustate em pacientes<br>italianos com NPC|infantil precoce<br>(n=2), infantil<br>tardia (n=6),<br>juvenil (n=9),<br>adulto (n=6),<br>visceral (n=2)|25 pacientes<br>com NPC|Miglustate<br>(200 mg, 3x/<br>dia ou<br>ajustado de<br>acordo com<br>superfície<br>corpórea)|Não se<br>aplica|48-96<br>meses|
|**2013**|**Ginocchio**<br>**et al.**|Série de<br>casos|Relatar dados de<br>eficácia e segurança da<br>terapêutica com<br>miglustate em 10<br>pacientes com NPC|infantil precoce<br>(n=2), infantil<br>tardia (n=3) e<br>juvenil (n=5)|10 pacientes<br>com NPC|miglustate<br>(n=8) (200<br>mg, 3x/ dia<br>ou ajustado<br>de acordo<br>com<br>superfície<br>corpórea)|Não se<br>aplica|Não<br>informado|  
36  
|**Ano**|**Estudo**|**Desenho de**<br>**estudo**|**Objetivo**|**Classificação da**<br>**NPC**|**Número de**<br>**estudos e**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|**Seguimento**|
|---|---|---|---|---|---|---|---|---|
|**2012**|**Héron et**<br>**al.**|Série de<br>casos|Avaliar a progressão de<br>doença e resposta ao<br>tratamento com<br>miglustate em todos os<br>pacientes pediátricos<br>diagnosticados com<br>NPC em hospitais da<br>Franca|perinatal (n=1),<br>infantil precoce<br>(n=8), infantil-<br>tardia (n=8),<br>juvenil (n=3)|20 pacientes<br>com NPC|miglustate<br>(200 mg, 3x/<br>dia ou<br>ajustado de<br>acordo com<br>superfície<br>corpórea)|Não se<br>aplica|50 meses|  
**Legenda:** mg – miligramas, ND – não descrito, NPC – Niemann-Pick tipo C.  
37  
**Tabela B -** Características dos participantes dos estudos que avaliaram a eficácia e segurança do miglustate.  
|**Ano**|**Estudo**|**Classificação**<br>**NPC**|**Intervenção**|**Controle**|**Idade (anos)**<br>**Intervenção**<br>**Média (DP)**|**Idade**<br>**(anos)**<br>**Controle**<br>**Média (DP)**|**% sexo**<br>**Intervenção**|**% sexo**<br>**Controle**|<br>**Tempo de**<br>**tratamento**<br>**Mediana**<br>**(variação)**|
|---|---|---|---|---|---|---|---|---|---|
|**2007**|**Patterson**<br>**et al.**|pediátrico e<br>adulto|Miglustate<br>(n=20)|Cuidados<br>padrão<br>(n=9)|adultos: 25,4<br>(9,8),<br>variação: 12-<br>42;<br>pediátricos:<br>7,2 (2,5),<br>variação:4-11|22,9 (7,5),<br>variação: 13-<br>32|adultos:<br>55% F;<br>pediátricos:<br>58% F|56% M|adultos: 364,5<br>(180-429)<br>dias;<br>pediátrico:<br>371 (71-400)<br>dias|
|**2009**|**Patterson**<br>**et al.**|adolescentes e<br>adultos|Miglustate|Não se<br>aplica|22,6 (9,4)|Não se<br>aplica|44%F|Não se<br>aplica|1465 (825-<br>2056)dias|
|**2009**|**Wraith et**<br>**al.**|pediátrico e<br>adulto|Miglustate|Não se<br>aplica|juvenil/<br>Adulto: 22,6<br>(9,4);<br>pediátrico: 7,2<br>(2,4)|Não se<br>aplica|Não<br>relatado|Não se<br>aplica|NA|
|**2010**|**Patterson**<br>**et al.**|pediátrico<br>(n=10)|Miglustate|Não se<br>aplica|7,2, variação:<br>4-11|Não se<br>aplica|58% F|Não se<br>aplica|1073 (725-<br>1604)dias|
|**2010**|**Wraith et**<br>**al., 2010**|juvenis e<br>adultos|Miglustate|Não se<br>aplica|24,6 (9,1) -<br>_baseline_|52%F|Não<br>relatado|Não se<br>aplica|1465 (825-<br>2056)dias|
|**2017**|**Freihuber**<br>**et al.**|Infantil<br>precoce|Miglustate<br>(n=10)|sem<br>tratamento<br>(n=16)|Não relatado|Não relatado|Não<br>relatado|Não<br>relatado|29 meses|
|||infantil||||||||
|**2018a**|<sup>**Patterson**</sup><br>**et al.**|precoce,<br>infantil tardia,<br>juvenil,<br>adolescente/|Miglustate<br>(n=789)|sem<br>tratamento|20 (12,4)|Não se<br>aplica|Não<br>relatado|Não se<br>aplica|NA|  
38  
|**Ano**|**Estudo**|**Classificação**<br>**NPC**|**Intervenção**|**Controle**|**Idade (anos)**<br>**Intervenção**<br>**Média (DP)**|**Idade**<br>**(anos)**<br>**Controle**<br>**Média (DP)**|**% sexo**<br>**Intervenção**|**% sexo**<br>**Controle**|**Tempo de**<br>**tratamento**<br>**Mediana**<br>**(variação)**|
|---|---|---|---|---|---|---|---|---|---|
|||adulta||||||||
|**2018b**|<sup>**Patterson**</sup><br>**et al.**|infantil<br>precoce<br>(9,4%),<br>infantil tardia<br>(29,5%),<br>juvenil<br>(36,2%),<br>adolescente/<br>adulta(25%)|Miglustate<br>(n=241)|não se<br>aplica|20,0 (12,4)<br>anos|Não se<br>aplica|Não<br>relatado|Não se<br>aplica|NA|
|**2009**|**Pineda et**<br>**al.**|infantil<br>precoce,<br>infantil tardia,<br>juvenil,<br>adolescente/<br>adulta|Miglustate|Não se<br>aplica|13,3 (9,8)<br>anos|Não se<br>aplica|55,9% F|Não se<br>aplica|30,2 (0,4-<br>83,5) meses|
|**2015**|**Patterson**<br>**et al.**|infantil<br>precoce,<br>infantil tardia,<br>juvenil,<br>adolescente/<br>adulta|Miglustate|não se<br>aplica|Mediana<br>(variação):<br>12,0 (0,1-<br>44,7)|Não se<br>aplica|49,9% F|Não se<br>aplica|média (DP):<br>3,9 (1,9) anos|  
39  
|**Ano**|**Estudo**|**Classificação**<br>**NPC**|**Intervenção**|**Controle**|**Idade (anos)**<br>**Intervenção**<br>**Média (DP)**|**Idade**<br>**(anos)**<br>**Controle**<br>**Média (DP)**|**% sexo**<br>**Intervenção**|**% sexo**<br>**Controle**|**Tempo de**<br>**tratamento**<br>**Mediana**<br>**(variação)**|
|---|---|---|---|---|---|---|---|---|---|
|**2015**|**Fecarotta**<br>**et al.**|infantil<br>precoce (n=2),<br>infantil tardia<br>(n=6), juvenil<br>(n=9), adulto<br>(n=6), visceral<br>(n=2)|Miglustate|Não se<br>aplica|16 (11,7);<br>variação:<br>1,58-43,83|Não se<br>aplica|64% F|Não se<br>aplica|Antes do<br>recrutamento<br>- média<br>(variação):<br>9,0 (6,0-31,0)<br>Após<br>recrutamento<br>- média<br>(variação):<br>71,0 (48,0-<br>96,0);|
|**2013**|**Ginocchio**<br>**et al.**|infantil<br>precoce (n=2),<br>infantil tardia<br>(n=3) e<br>juvenil(n=5)|Miglustate|Não se<br>aplica|17,6(8,5),<br>variação: 4-31|não se aplica|70% F|Não se<br>aplica|média (DP):<br>48 (21) meses|
|**2012**|**Héron et**<br>**al.**|perinatal<br>(n=1), infantil<br>precoce (n=8),<br>infantil-tardia<br>(n=8), juvenil<br>(n=3)|Miglustate|Não se<br>aplica|mediana<br>(variação): 1,5<br>(prenatal-14<br>anos)|Não se<br>aplica|55% F|Não se<br>aplica|infantil<br>precoce: 16<br>(8-27) meses;<br>infantil-<br>tardio: 1,0<br>(0,8-5,0)<br>anos; juvenil:<br>1,0 (0,6-2,5)<br>anos|
|**Lege**|**nda:**F – femi|nino, NA – não a|valiado.|||||||  
40  
41  
**Tabela C -** Desfechos de eficácia do miglustate no tratamento de NPC (Parte I).  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||Intervençã||||||||
||||o<br>pediátrico<br>(n=12)|NA|ND|NA|NA|ND|ND|NA|
|||||||||30%|||
|||||||||(água);|||
||||Intervençã|||||15% (purê);|||
||||o||n=20|||15%|MEEM (n=||
||||adolescent<br>e e adulto|NA|∆= 0,2<br>(0,7)|NA|NA|(sólidos<br>macios);|19)<br>∆=1,2 (2,5)|NA|
|**2007**|**Patters**<br>**on et al.**|12 meses|(n=20)|||||35%<br>(cookie) -<br>melhora|||
|||||||||12%<br>adicionais|||
||||Controle<br>adolescent<br>e e adulto<br>(n=9)|NA|n=9<br>∆=0,7 (0,9)|NA|NA|apresentara<br>m<br>dificuldade<br>de deglutir<br>sólidos|MEEM<br>(n=9)<br>∆=-0,3 (2,8)|NA|
|||||||||macios e<br>cookie|||  
42  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||Intervençã<br>o<br>(adolescen||∆=-0,715;<br>IC 95%: [-|||Para|||
||||tes/<br>adultos)<br>vs.<br>Controle|NA|1,438 a<br>0,007];<br>p=0,52|NA|NA|cookie:<br>p=0,044|p=0,165|NA|
|||||||||78,6%|||
|||||||||(água),<br>85,7%|||
|**2009**|**Patters**<br>**on et al.**|66 meses|adolescent<br>e/ adulta:<br>>12 anos<br>(n=14)|NA|66,7%:<br>estabilizaç<br>ão (n=12)|NA|NA|(purê),<br>92,8%<br>(sólido<br>macio e<br>cookie):<br>melhora ou<br>estabilizaçã<br>o(n=14)|NA|NA|
|**2009**|**Wraith**<br>|ND|infantil<br>precoce e<br>tardia<br>(n=10)|NA|n=10: 80%<br>estável ou<br>melhorada<br>|NA|NA|n=9: 100%<br>estável ou<br>melhorada<br>|NA|NA|
||**et al.**||adolescent<br>e/ adulta<br>(n=19)||n=19:<br>89,5%<br>estável ou<br>melhorada|||n=19:<br>78,9%<br>estável ou<br>melhorada|n=18: 77,7%<br>estável ou<br>melhorada||  
43  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||**Baseline:**<br>2,0,<br>IC95%:|||**Mês 24:**<br>Estável<br>para 4 tipos<br>de|||
||||||[0,7-3,3];|||alimentos|||
|**2010**|**Patters**<br>**on et al.**|52 meses|pediátrico:<br><12 anos<br>(n=10)|NA|**Mês 12:**<br>2,3,<br>IC95%:<br>[0,6- 4,0];<br>**Mês 24:**|NA|NA|na maioria<br>dos<br>pacientes.<br>10% dos<br>pacientes|NA|NA|
||||||2,6|||tiveram|||
||||||IC95%:|||melhora na|||
||||||[0,7- 4,5) -|||deglutição|||
||||||Estável em|||de cookie e|||
||||||80%|||10% teve<br>piora.|||  
44  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||**12 meses**<br>**(n=21)-**|||**Mês 12**<br>**(n=21):**|**12 meses**<br>**(n=18) -**||
||||||**Baseline:**|||85,7% -|Baseline:||
||||||2,38,|||melhora ou|22,94,||
||||||IC95%:[1,|||estabilizaçã|IC95%:[20,2||
||||||59; 3,18];|||o para 4|8; 25,61];||
||||||**Mês 12**|||alimentos -|Mês 12:||
||||||(n=21):|||Melhora ou|24,06,||
||||||2,57, IC|||estabilizaçã|IC95%:[21,1||
||||adolescent||95%:|||o: 78,9%,|8; 26,93] -||
|||24 meses/|e/ adulto:||[1,61;|||IC 95%:|Melhora ou||
|||<br>monitoram|<br>>12 anos||3,53] -|||[54,4%;|estabilização||
|**2010**|**Wraith**<br>**et al.**|ento de EA<br>té 66|<br>(12 meses<br>=21 24|NA|Melhora<br>ou|NA|NA|94%],<br>n=19;**Mês**|: 77,8%,<br>IC95%:|NA|
|||a<br>|- n,<br>||estabilizaç|||**24 (n=14)**:|[52,4%;||
|||meses|meses -<br>15||ão: 85,9%,|||92,9%|93,6%],||
||||n=)||IC95%:|||(água),|n=18/**24**||
||||||[66,9%;|||85,7%|**Meses (n=6)**||
||||||98,7%],|||(purê),|- Baseline:||
||||||n=19/**24**|||78,6%|19,5, IC||
||||||**meses**|||(sólidos|95%: [12,21;||
||||||**(n=15) -**|||macios) e|26,79]; Mês||
||||||**Baseline:**|||85,7%|12: 21,17, IC||
||||||2,13,|||(cookie)-|95%:[13,94;||
||||||IC95%[1,5|||melhora ou|28,39]; Mês||
||||||1;2,76];|||estabilizaçã|24:19,33,IC||  
45  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||||**Mês 12:**<br>2,20,<br>IC95%:<br>[1,47;<br>2,93];**Mês**<br>**24:**2,40,<br>IC95%:<br>[1,49;<br>3,31]|||o|95%: [9,98;<br>28,69]||
|**2017**|**Freihu**<br>**ber et**<br>**al.**|ND|Intervençã<br>o - Infantil<br>Precoce<br>(n=10)<br>Controle -<br>Infantil<br>Precoce<br>(n=16)|NA<br>NA|ND|ND|ND|ND|NA|NA|
||||Agrupado<br>juvenil|NA|||||||
|**2018**<br>**a**|**Patters**<br>**on et al.**|10 anos|infantil-<br>tardia<br>juvenil|NA|NA|NA|NA|NA|NA|NA|  
46  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
||||Agrupado<br>- Neuro<br>(n=669);<br>DX<br>(n=590)||||||||
|**2018**<br>**b**|**Patters**<br>**on et al.**|3,29 anos|NE|Baseline:<br>0,38 (0,26)<br>- Infantil-<br>precoce:<br>0,59<br>(0,35);<br>Adolescent<br>e/ adulta:<br>0,32(0,16)|67,8%<br>melhora ou<br>estabilizaç<br>ão|69,2%<br>melhora<br>ou<br>estabilizaç<br>ão|73,9%<br>melhora<br>ou<br>estabilizaç<br>ão|71,3%<br>melhora ou<br>estabilizaçã<br>o|NA|NA|
||||infantil-||||||||
|**2015**|**Patters**<br>**on et al.**|média<br>(DP): 2<br>(0,7) anos|precoce,<br>infanti-<br>tardia,<br>juvenil,<br>adolescent<br>e/ adulta<br>(n=92)|Baseline:<br>0,37<br>(0,23)/<br>Última<br>avaliação:<br>0,38 (0,50)|n=86: 75%<br>melhora ou<br>estabilizaç<br>ão|n=86:<br>71%melho<br>ra ou<br>estabilizaç<br>ão|n=86:<br>77%<br>melhora<br>ou<br>estabilizaç<br>ão|n=86: 74%<br>melhora ou<br>estabilizaçã<br>o|NA|NA|
||||infantil||24 meses:|24 meses:|24 meses:|24 meses:|Após 24||
|**2015**|<sup>**Fecarot**</sup><br>**ta et al.**|48-96<br>meses|precoce<br>(n=2),|NA|79% -<br>estabilizaç|Distonia -<br>70%|56%<br>estabilizaç|Disfagia -<br>45%|meses: 58%<br>tiveram|NA|
||||infantil||ão e 7%,|estabilizaç|ão,13%|estabilizaçã|estabilização||  
47  
|||||||**Des**|**fechos de Ef**|**icácia**|||
|---|---|---|---|---|---|---|---|---|---|---|
|||||**Escores**|||||||
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Manipula**<br>**ção**|**Linguage**<br>**m**|**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
||||tardia<br>(n=6),||melhora<br>48-96|ão, 11%<br>melhora|melhora/<br>48-96|o, e 20%,<br>melhora;|das<br>alterações||
||||juvenil||meses,|48-96|meses:|Deglutição|cognitivas ou||
||||(n=9),||alterações|meses:|presente|-|atrasos no||
||||adulto||em 43%|distonia|em 50%|estabilizaçã|desenvolvim||
||||(n=6),|||presente||o ou|ento e||
||||visceral|||em 55%||melhora -|10,5%,||
||||(n=2)|||||65% (água),<br>58% (purê),<br>60%<br>(macarrão)<br>e 55%<br>(cookie) -<br>n=20|melhora||
|||||||||48-96<br>meses:<br>Persistência<br>de<br>alterações<br>em 40-50%<br>dos|||
|||||||||pacientes|||  
48  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||Geral<br>(n=8):<br>∆=0,04/|||||||
|||||ano;<br>Infantil-|||||||
|**2013**|**Ginocc**<br>**hio et**<br>**al.**|ND|infantil<br>precoce<br>(n=2),<br>infantil<br>tardia<br>(n=3) e<br>juvenil<br>(n=5)|precoce<br>tratada<br>com dose<br>completa<br>(n=1):<br>∆=0,07;<br>Infantil-<br>tardia: ∆<br>=0,08;<br>juvenil: ∆<br>=0,02;<br>Suspensão<br>da terapia:<br>∆ =0,17|n=8: 25%<br>estabilizaç<br>ão|n=8: 50%<br>estabilizaç<br>ão|n=8:<br>12,5%<br>estabilizaç<br>ão|n=8: 50%<br>estabilizaçã<br>o|NA|62,5%<br>estabiliza<br>ção|
||||Geral||ND|ND|ND|ND|NA|ND|
|||||||||10-12|||
|**2012**|**Héron**<br>**et al.**|50 meses|Infantil-<br>precoce<br>(n=8)|18 meses:<br>62,5%<br>deterioraçã<br>o|ND|ND|ND|meses:<br>37,5%<br>necessitara<br>m de<br>alimentação|NA|12,5%<br>novas<br>crises|  
49  
|**Ano**|**Estudo**|**Período de**<br>**observação**|**Grupos**|**Escores**<br>**de**<br>**Incapacid**<br>**ade média**<br>**(DP)**|**Deambula**<br>**ção**|**Des**<br>**Manipula**<br>**ção**|**fechos de Ef**<br>**Linguage**<br>**m**|**icácia**<br>**Deglutição**|**Cognição**<br>**média (DP)**|**Crises**<br>**Convulsi**<br>**vas**|
|---|---|---|---|---|---|---|---|---|---|---|
|||||||||enteral ou|||
|||||||||por<br>gastrostomi<br>a|||
|||||75%||||||25%|
||||Infantil-|melhora||||||novas|
||||Tardia<br>(n=8)|ou<br>estabilizaç|ND|ND|ND|ND|NA|crises (+<br>cataplexia|
|||||ão||||||)|
||||Juvenil<br>(n=3)|33,3%<br>melhora;<br>66,7%<br>piora|ND|ND|ND|ND|NA|33,3%<br>novas<br>crises (+<br>cataplexia<br>)|  
**Legenda:** EA – Eventos Adversos, IC95% - Intervalo de Confiança; MEEM – Mini Exame do Estado Mental, NA – Não avaliado, ND – não descrito.  
50

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Tabela D -** Desfechos de eficácia do miglustate no tratamento de NPC (Parte II). -->
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Desfechos**<br>**Sobrev**<br>**ida**|**de Eficácia**<br>**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|---|---|---|---|---|---|---|---|---|
||||Intervenção<br>pediátrico<br>(n=12)|Velocidade de movimentos<br>oculares horizontais alfa:<br>média (EP): -0,465(0,127)<br>ms/deg.|NA|NA|NA|NDN|
|||||||||20%-25%|
|**20**<br>**07**|**Patters**<br>**on et**<br>**al.**|12<br>meses|Intervenção<br>adolescente e<br>adulto (n=20)|Velocidade de movimentos<br>horizontais alfa - média (EP):<br>Análise ajustada por<br>características basais: ∆= –0,431<br>(0,221) ms/deg<br>Exclusão de pacientes em uso de<br>benzodiazepínicos (n=13):  ∆= -<br>0,485 ms/deg|NA|NA|NA|dos pacientes<br>que<br>apresentavam<br>acuidade<br>auditiva<br>prejudicada<br>tiveram<br>melhora em<br>ambos os<br>lados.|
||||Controle<br>adolescente e<br>adulto (n=9)|Velocidade de movimentos<br>horizontais alfa - média (EP):<br>Análise ajustada por<br>características basais: ∆=+0,074<br>(0,291) ms/deg.<br>Exclusão de pacientes em uso de<br>benzodiazepínicos (n=8):∆=|NA|NA|NA|22% piora da<br>acuidade<br>auditiva|  
51  
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Desfecho**<br>**Sobrev**<br>**ida**|**s de Eficácia**<br>**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|---|---|---|---|---|---|---|---|---|
|||||+0,234 ms/deg|||||
||||Intervenção<br>(adolescentes/<br>adultos) vs.<br>Controle|**Velocidade de movimentos**<br>**horizontais alfa:**Análise<br>ajustada por características<br>basais:  –0,518; IC95%: [–1,125;<br>0,089]; p=0,091/  Exclusão de<br>pacientes em uso de<br>benzodiazepínicos: -0,718; IC<br>95%: [-1,349; -0,088]; p=0,028)<br>**Movimentos oculares**<br>**horizontais beta:**Análise<br>ajustada por características<br>basais:  ∆= -0,722; IC95%: [-<br>7,781; 6,337]; p=0,834)|NA|NA|NA|NDN|
|**20**<br>**09**|**Patters**<br>**on et**<br>**al.**|66<br>meses|adolescente/<br>adulta: >12<br>anos(n=14)|NA|NA|NA|NA|NDN|
|**20**<br>**09**|**Wraith**<br>**et al.**|ND|infantil<br>precoce e<br>tardia (n=10)|Pico de velocidade de<br>movimentos horizontais alfa<br>(n=9): 66,7% - melhora ou<br>estabilização|NA|NA|n=29: 72.4%<br>estáveis (8<br>crianças)|NDN|  
52  
**<mark>Desfechos de Eficácia Progressão de</mark> Períod doença An o de (deterioração, Estudo Grupos Sobrev Mortalidad o observ Movimentos Oculares estabilização Outros ida e ação ou melhora) - média** **<u>(IC95%)</u>** Pico de velocidade de adolescente/ movimentos horizontais alfa adulta (n=19) (n=18): 61,1% - melhora ou <u>estabilização</u> **Pico de velocidade de movimentos horizontais alfa (n=9):** Baseline: 2,181 (IC95%[1,3-3,0]) ms/deg; Mês 12: 1,692, IC95%: [1,0-2,4]) ms/deg no mês 12; Mês 24: 2,106, IC95%: [1,3-2,9]) ms/deg **Patters 20** 52 pediátrico: <12 - melhor ou estável em 67% // **Mês 24** : 80% **on et** NA NA NDN **10** meses anos (n=10) **Movimentos horizontais beta** estabilização/ **al. (n=9):** 20% piora Baseline: 28,96 IC95%:[13,99; 44,0]; Mês 12: 33,66, IC95%:[18,349,0]; Mês 24: 33,47, IC 95%:[17,949,1]  
53  
||||||**Desfecho**|**s de Eficácia**|||
|---|---|---|---|---|---|---|---|---|
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Sobrev**<br>**ida**|**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|**20**<br>**10**|**Wraith**<br>**et al.**|24<br>meses/<br>monitor<br>amento<br>de EA<br>até 66<br>meses|adolescente/<br>adulto: >12<br>anos (12 meses<br>- n=21, 24<br>meses - n=15)|**Pico de velocidade de**<br>**movimentos horizontais alfa:**<br>**12 meses completos (n=21) -**<br>Baseline: 3,06, IC95%:[2,09;<br>4,04], Mês 12: 2,87,<br>IC95%:[2,03; 3,71] -Melhora ou<br>estabilização em 61,1%, IC95%:<br>[35,8%; 81,7%], n=18/**24 meses**<br>**completos (n=15)**- Baseline<br>3,04, IC95%: [1,74; 4,34]; Mês<br>12: 2,57 [1,65; 3,49]; Mês 24:<br>3,27, IC95%: 1,22; 5,31] - //<br>**Movimentos horizontais beta**<br>**(n=9):** **12** **meses completos**<br>**(n=21)**- Baseline: 22,42,<br>IC95%: [17,47; 27,38]; Mês 12:<br>25,95, IC95%: [20,09; 31,81]/<br>**24 meses completos (n=15)**-<br>Baseline: 19,51, IC95%: [13,81;<br>25,20]; Mês 12: 22,98, IC 95%:<br>[17,24; 28,73]; Mês 24: 24,85,<br>IC95%: [17,75; 31,94]|NA|NA|12 meses<br>completos<br>(n=19): 64,8%,<br>IC95%:<br>[43,5%;<br>87,4%] -<br>estabilização|NDN|
|**20**<br>**17**|**Freihu**<br>**ber et**|ND|Intervenção -<br>Infantil|NA|n=7:<br>5,45||NA|NDN|  
54  
||||||**Desfecho**|**s de Eficácia**|||
|---|---|---|---|---|---|---|---|---|
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Sobrev**<br>**ida**|**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
||**al.**||Precoce (n=10)||anos||||
||||Controle -<br>Infantil||n=11:<br>4,42||||
||||Precoce(n=16)||anos||||
|||||||HR=0,57;|||
||||Agrupado|||IC95%[0,22<br>; 1,49],|NA||
|||||||p=0,25|||
|||||||Neuro:<br>HR=0,36|||
||||infantil-tardia|||(p<0,05);<br>DX: HR=<br>0,32|||
|||||||(p<0,001)|||
|**20**|**Patters**|||||DX:|||
|**18**|**on et**|10 anos|juvenil|NA|NA|HR=0,30|NA|NDN|
|**a**|**al.**|||||(p<0,05)|||
|||||||Neuro:|||
||||Agrupado –|||HR=0,42;|||
||||Neuro*|||DX: HR:|||
||||(n=669); DX**|||0,49,|||
||||(n=590)|||p<0,001;<br>Consistente|||  
55  
||||||**Desfecho**|**s de Eficácia**|||
|---|---|---|---|---|---|---|---|---|
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Sobrev**<br>**ida**|**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|||||||em todas as<br>idades<br>(HR= 0,3 a<br>0,6)|||
|**20**<br>**18**<br>**b**|**Patters**<br>**on et**<br>**al.**|3,29<br>anos|NE|NA|NA|NA|70,5% melhora<br>ou<br>estabilização|NDN|
|**20**<br>**15**|**Patters**<br>**on et**<br>**al.**|média<br>(DP): 2<br>(0,7)<br>anos|infantil-<br>precoce,<br>infanti-tardia,<br>juvenil,<br>adolescente/<br>adulta (n=92)|NA|NA|NA|69%<br>estabilização<br>ou melhor<br>(33%infantil-<br>precoce, 50%<br>infantil-tardia,<br>79% juvenil e<br>94%<br>adolescente/<br>adulta)/<br>Progressão<br>média de<br>doença (IC<br>95%) =  0,038<br>(0,018-0,059)/<br>ano|NDN|  
56  
||||||**Desfechos**|**de Eficácia**|||
|---|---|---|---|---|---|---|---|---|
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Sobrev**<br>**ida**|**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|||||||||Dismetria: 24<br>meses: 50%<br>estabilização,<br>11%<br>melhora; 48-<br>96 meses:|
|**20**<br>**15**|**Fecarot**<br>**ta et al.**|48-96<br>meses|infantil<br>precoce (n=2),<br>infantil tardia<br>(n=6), juvenil<br>(n=9), adulto<br>(n=6), visceral<br>(n=2)|NA|NA|NA|ND|presente em<br>41%/<br>Gravidade da<br>doença<br>neurológica<br>(MCSS):<br>56% e 6,25%<br>estabilização<br>ou melhora<br>|
|||||||||em pacientes<br>com|
|||||||||tratamento<br>precoce ou<br>tardio|
|**20**<br>**13**|**Ginocc**<br>**hio et**<br>**al.**|ND|infantil<br>precoce (n=2),<br>infantil tardia<br>(n=3)ejuvenil|87,5 % estabilização<br>Mudança anual - Geral: 0,03;<br>Infantil precoce: 0,12; Infantil<br>tardia: 0,0; Juvenil: 0,02|NA|NA|37,5%<br>estabilização;<br>62,5%<br>deterioração|ND|  
57  
|**An**<br>**o**|**Estudo**|**Períod**<br>**o de**<br>**observ**<br>**ação**|**Grupos**|**Movimentos Oculares**|**Desfechos**<br>**Sobrev**<br>**ida**|**de Eficácia**<br>**Mortalidad**<br>**e**|**Progressão de**<br>**doença**<br>**(deterioração,**<br>**estabilização**<br>**ou melhora) -**<br>**média**<br>**(IC95%)**|**Outros**|
|---|---|---|---|---|---|---|---|---|
||||(n=5)||||||
||||Geral|NA|NA|15%|NA|ND|
|**20**|**Héron**|50|Infantil-<br>precoce (n=8)|NA|NA|12,5%<br>(falência<br>respiratória)|Após 18 meses<br>de terapia:<br>13% tiveram<br>doença<br>estabilizada|18 meses:<br>39%<br>comprometi<br>mento do<br>trato<br>piramidal|
|**12**|**et al.**|meses|Infantil-Tardia<br>(n=8)|NA|NA|12,5%<br>(pneumonia<br>aspirativa)|39% tiveram<br>doença<br>estabilizada<br>nos primeiros<br>12 meses|ND|
||||Juvenil (n=3)|NA|NA|ND|33,3% melhora|12,5% piora<br>da neuropatia|  
**Legenda:** EA – Eventos Adversos, EP – Erro Padrão, HR – _hazard ratio_ , ND – Não descrito, NA – Não Avaliado, *Neuro - grupo caracterizado pelo início de sintomas neurológicos; **Dx – grupo caracterizado pela idade em que o diagnóstico de NPC foi feito; MCSS – _Mean Composite Severity Score_ .  
58

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Tabela E -** Desfechos de segurança do miglustate para o tratamento de NPC. -->
|**An**|**Estud**||||**Dor**||**Per**|**Desfec**|**hos de s**|**eguran**|**ça **<br>**Trom**|**Novas**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**o**|**o**|**Grupos**|**Diarr**<br>**eia**|**Flatulê**<br>**ncia**|<br>**abdomi**<br>**nal**|**Náuse**<br>**a**|**da**<br>**de**<br>**peso**|**Tre**<br>**mor**|**Cefal**<br>**eia**|**Fadi**<br>**ga**|**bocito**<br>**penia**|<br>**convuls**<br>**ões**|**Outros**|
|||Adolesce<br>ntes e<br>adultos<br>(n=20)|**85%**|**70%**|**50%**|**35%**|**65%**|**40%**|**45%**|**35%**|||25% dos pacientes<br>adolescentes e adultos<br>tratados com miglustate<br>apresentaram falta de|
|||Controle<br>(n=9)|**44%**|**0**|**0**|**0**|**0**|**0**|**0**|**0**|||apetite; 20%, 40% e 25%<br>dos pacientes<br>adolescentes/ adultos que|
||||||||||||||receberam miglustate,<br>controles e pacientes|
|**200**|**Patter**||||||||||||pediátricos apresentaram<br>|
|**7**|**son et**<br>**al.**|Pediátric<br>os<br>(n=12)|**67%**|**33%**|**0**|**0**|**25%**|**22%**|**33%**|**42%**|||disfagia/ 30%, 25%, 25%,<br>20%, 20% dos pacientes<br>adultos tratados com<br>miglustate apresentaram<br>insônia, piora dos<br>tremores, marcha<br>espástica, depressão e<br>parestesia,<br>respectivamente. Outros<br>grupos não apresentaram<br>estes eventos|
|**200**<br>**9**|**Patter**<br>**son et**<br>**al.**|Interven<br>ção<br>(n=14)|50,00<br>%||||50%||||||Perda de peso (média<br>(DP); variação): ∆ = +0,56<br>(8,10); 9,3- 21 kg|  
59  
|**An**|**Estd**||||**D**||<br>**Per**|**Desfec**|**hos de s**|**eguran**|**ça **<br>**T**|**N**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**o**|**u**<br>**o**|**Grupos**|**Diarr**<br>**eia**|**Flatulê**<br>**ncia**|**or**<br>**abdomi**<br>**nal**|**Náuse**<br>**a**|**da**<br>**de**<br>**peso**|**Tre**<br>**mor**|**Cefal**<br>**eia**|**Fadi**<br>**ga**|**rom**<br>**bocito**<br>**penia**|**ovas**<br>**convuls**<br>**ões**|**Outros**|
|**201**<br>**0**|**Patter**<br>**son et**<br>**al.**|Interven<br>ção<br>(n=12)|67%|33,30%|ND|ND|25%|58%|50%|42%|||Dois pacientes excluídos<br>do estudo por EA, um por<br>depressão, perda de<br>memória e letargia, outro<br>pordoença de Crohn|
|**201**<br>**0**|**Wrait**<br>**h et**<br>**al.,**|Interven<br>ção<br>(n=28)|89,30<br>%|64,30%|39,30%|32,10<br>%|75%|57,1<br>0%|39,30<br>%|46,4<br>0%|||Quatro pacientes<br>suspenderam o tratamento<br>devido a eventos<br>adversos: um por estado<br>confusional associado a<br>insônia e paranoia, um por<br>diarreia, um por<br>progressão de doença e<br>um por neuropatia axonal<br>e tremores.|
|**201**<br>**7**|**Freihu**<br>**ber et**|Interven<br>ção||70|%||ND|ND|ND|ND|||NDN|
||**al.**|Controle|ND|ND|ND|ND|ND|ND|ND|ND|||NDN|
||||||||||||||17,6% dos pacientes<br>suspenderam tratamento<br>devido a óbito por|
|**200**|**Pineda**|Interven|15,70||||16,7||||||progressão de doença,|
|**9**|**et al.**|ção|%||||0%||||||progressão de doença,<br>solicitação de paciente/<br>familiar, eventos adversos<br>e dificuldade de deglutir.|  
60  
|**An**|**Estud**||||**Dor**||**Per**|**Desfec**|**hos de s**|**eguran**|**ça **<br>**Trom**|**Novas**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**o**|**o**|**Grupos**|**Diarr**<br>**eia**|**Flatulê**<br>**ncia**|<br>**abdomi**<br>**nal**|**Náuse**<br>**a**|**da**<br>**de**<br>**peso**|**Tre**<br>**mor**|**Cefal**<br>**eia**|**Fadi**<br>**ga**|**bocito**<br>**penia**|<br>**convuls**<br>**ões**|**Outros**|
|**201**<br>**5**|**Patter**<br>**son et**<br>**al.**|Interven<br>ção<br>(n=92)|**11%**|||||2%|||54%|33%|33% dos pacientes<br>tiveram novos episódios<br>convulsivos e 54%<br>apresentaram<br>trombocitopenialeve.|
|**201**|**Fecaro**<br>**tta et**|Interven|Comu||||Com|Com|||Prese||Foram detectados:<br>epistaxe, insônia,<br>leucopenia, problemas|
|**5**|<br>**al.**|ção|m||||um|um|||nte||comportamentais,<br>sintomas extrapiramidais,<br>hipertransaminasemia|
|**201**<br>**3**|**Ginoc**<br>**chio et**<br>**al.**|Interven<br>ção||30%||||10%|||||10% (1 paciente)<br>apresentou hipotonia,<br>astenia e distensão<br>abdominal após redução<br>progressiva e posterior<br>interrupção|
||||||||||||||Em 3 pacientes, EAs<br>foram graves e levaram à|
|**201**<br>**2**|**Héron**<br>**et al.**|Interven<br>ção|||75%||||||||interrupção do tratamento:<br>astenia oudiarreia<br>persistente resolvida após<br>retirada do miglustate|  
**Legenda:** EA – Evento Adverso, ND – Não descrito, NDN – nada digno de nota.  
61  
**Tabela F -** Sumarização dos resultados dos estudos incluídos (summary of findings (SOF) do software GRADE PRO).  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|  
**Movimentos oculares sacádicos alfa (HSEM α) (seguimento: variação 12 meses para 24 meses)**  
62  
|**№ dos**||**Risc**|**Avaliação daQ **<br>|**ualidade**<br>||**Outras**|**It**|**Qualidad**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|<br>**consideraçõe**<br>**s**|**mpaco**|**e Global**|**mpornca**|
|4|ensaios<br>clínicos<br>randomizados<br>estudos<br>observacionai<br>s|muit<br>o<br>grave<br>a,b|grave<sup>c</sup>|grave<sup>d</sup>|não grave|nenhum|Observou-se<br>tendência de<br>redução na<br>velocidade dos<br>movimentos<br>oculares no grupo<br>intervenção<br>(0,518; IC95%: [–<br>1,125; 0,089];<br>p=0,091). Quando<br>excluídos<br>pacientes em uso<br>de<br>benzodiazepínico,<br>houve redução da<br>velocidade a favor<br>do miglustate<br>0,718; IC 95%: [-<br>1,349; -0,088];<br>p=0,028) (16).<br>Três estudos<br>apresentaram<br>dados de análise<br>de extensão para<br>as populações<br>pediátrica (<12<br>anos) e<br>adolescente/<br>adulta do ensaio<br>clínico|⨁◯◯◯<br>MUITO<br>BAIXA|63<br>NÃO<br>IMPORTANT<br>E|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|  
**Cognição (seguimento: 12 meses)**  
64  
|**№ dos**||**Risc**|**Avaliação daQ **<br>|**ualidade**<br>||**Outras**|**It**|**Qualidad**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|<br>**consideraçõe**<br>**s**|**mpaco**|**e Global**|**mpornca**|
|4|ensaios<br>clínicos<br>randomizados<br>estudo<br>observacional|muit<br>o<br>grave<br>a,b|grave<sup>c</sup>|não grave|grave<sup>e,f</sup>|nenhum|Embora o grupo<br>intervenção tenha<br>apresentado<br>discreta melhora<br>nos escores<br>médios de MEEM<br>(∆=1,2; DP=2,5)<br>em relação ao<br>grupo controle<br>(∆=-0,3; DP=2,8),<br>não houve<br>diferença com<br>significância<br>estatística entre os<br>grupos (p=0,165)<br>(16). Em dois<br>estudos, mais de<br>2/3 da amostra<br>teve melhora ou<br>estabilização da<br>cognição em até<br>24 meses (26, 67).<br>Em um estudo<br>observou-se que<br>houve melhora<br>nos escores<br>médios do<br>MEEM tanto para<br>quem completou<br>12 meses de|⨁◯◯◯<br>MUITO<br>BAIXA|65<br>CRÍTICO|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Crises convulsivas** -->
|2<br>estudo<br>observacional|muit<br>o<br>grave<br>b|grave<sup>c,g</sup>|não grave|não grave|nenhum|Em um dos<br>estudos,<br>observou-se que<br>mais de 2/3 da<br>amostra teve<br>melhora ou<br>estabilização dos<br>episódios<br>convulsivos.<br>Aproximadament<br>e 19% dos<br>pacientes com as<br>formas infantil<br>precoce e tardia e<br>33% dos<br>pacientes juvenis<br>apresentaram<br>novas crises (18,<br>19).|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
**Sobrevida**  
66  
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**A**<br>**Risc**<br>**o de**<br>**viés**|**valiação daQ **<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|1|estudo<br>observacional|grave<br>h|não grave|grave<sup>i</sup>|não grave|nenhum|Para pacientes em<br>uso de miglustate,<br>o tempo médio de<br>sobrevida foi de<br>5,45 anos e , para<br>os controles, 4,42<br>anos (17).|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|**Progres**<br>7|**são de doença**<br>estudo<br>observacional|muit<br>o<br>grave<br>b|grave<sup>c,g,j</sup>|grave|grave<sup>k</sup>|nenhum|Doença teve<br>estabilização ou<br>melhora em mais<br>de dois terços dos<br>pacientes, com<br>base nos escores<br>de incapacidade,<br>em diferentes<br>períodos de<br>seguimento (de 24<br>a 96 meses) (18,<br>19, 21, 22, 24, 25,<br>67)|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Incapacidade** -->
67  
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ **<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|4|estudo<br>observacional|muit<br>o<br>grave<br>b,h|grave<sup>g,j</sup>|não grave|não grave|nenhum|Os estudos que<br>avaliaram os<br>escores de<br>incapacidade<br>sugerem que<br>houve<br>estabilização da<br>doença com o uso<br>de miglustate,<br>embora não<br>nenhum estudo<br>tenha incluído<br>grupo comparador<br>(18, 19, 24, 25).<br>Em apenas um<br>estudo (19),<br>observou-se que<br>mais de 60% dos<br>pacientes juvenis<br>e infantis precoce<br>apresentaram<br>deterioração<br>neurológica. Os<br>demais<br>apresentaram<br>melhora ou<br>estabilização do<br>quadro.|⨁◯◯◯<br>MUITO<br>BAIXA|68<br>CRÍTICO|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|  
**Deambulação**  
69  
|**№ dos**||**Risc**|**Avaliação daQ **<br>|**ualidade**<br>||**Outras**|**It**|**Qualidad**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|<br>**consideraçõe**<br>**s**|**mpaco**|**e Global**|**mpornca**|
|9|ensaios<br>clínicos<br>randomizados<br>estudo<br>observacional|muit<br>o<br>grave<br>a,b|grave<sup>c,g,j</sup>|não grave|não grave|nenhum|O único ensaio<br>clínico incluído<br>(16) evidenciou<br>que não houve<br>diferença na<br>deambulação para<br>os grupos<br>intervenção e<br>controle, embora<br>os resultados<br>tenham sido<br>inicialmente<br>favoráveis ao<br>miglustate. Os<br>estudos de<br>extensão e as<br>análises post hoc,<br>que não incluíram<br>grupo controle,<br>apresentaram<br>melhora ou<br>estabilização dos<br>escores de<br>deambulação, no<br>entanto (20-22,<br>67). Nas demais<br>séries de casos,<br>mais de 60% dos<br>pacientes<br>apresentaram|⨁◯◯◯<br>MUITO<br>BAIXA|70<br>IMPORTANT<br>E|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Manipulação** -->
|4<br>estudo<br>observacional|muit<br>o<br>grave<br>b|grave<sup>g,j</sup>|não grave|não grave|nenhum|Pelo menos 50%<br>dos pacientes em<br>uso de miglustate<br>apresentaram<br>melhora ou<br>estabilização de<br>escores de<br>manipulação, em<br>diferentes tempos<br>de seguimento<br>(18, 24-26).|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANT<br>E|
|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Linguagem** -->
71  
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ **<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|4|estudo<br>observacional|<br>muit<br>o<br>grave<br>b|grave<sup>g,j</sup>|não grave|não grave|nenhum|Houve melhora da<br>deglutição em<br>mais de 60% dos<br>pacientes, embora<br>aos 18-96 meses,<br>os sintomas ainda<br>persistiam em<br>50% (19). Um<br>estudo, em<br>contrapartida,<br>encontrou que<br>apenas 12,5% dos<br>pacientes<br>apresentaram<br>estabilização dos<br>escores para<br>linguagem (18).|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANT<br>E|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Deglutição** -->
72  
|**№ dos**||**Risc**|**Avaliação daQ **<br>|**ualidade**<br>||**Outras**|**It**|**Qualidad**|**Itâi**|
|---|---|---|---|---|---|---|---|---|---|
|**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**o de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|<br>**consideraçõe**<br>**s**|**mpaco**|**e Global**|**mpornca**|
|10|ensaios<br>clínicos<br>randomizados<br>estudo<br>observacional|muit<br>o<br>grave<br>a,b|grave<sup>c,g,j</sup>|não grave|grave<sup>e</sup>|nenhum|No único ensaio<br>clínico<br>randomizado<br>incluído, o grupo<br>intervenção<br>apresentou<br>pequena melhora<br>na deglutição dos<br>quatro tipos de<br>alimentos testados<br>(15%-35%),<br>enquanto 12% a<br>mais de controles<br>apresentaram<br>dificuldade de<br>deglutir alimentos<br>sólidos. A<br>diferença só foi<br>significativa para<br>_cookies_(16). Para<br>os estudos de<br>extensão e<br>análises post hoc,<br>foi relatada alta<br>frequência de<br>pacientes que<br>apresentaram<br>melhora ou<br>estabilização<br>deste domínio,|⨁◯◯◯<br>MUITO<br>BAIXA|73<br>IMPORTANT<br>E|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|  
**Mortalidade**  
74  
|**№ dos**<br>**estudo**<br>**s**|**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ **<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**|**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2|estudo<br>observacional|grave<br>h,l|grave<sup>c,j</sup>|não grave|grave<sup>e</sup>|nenhum|Os resultados<br>quanto aos efeitos<br>do miglustate<br>sobre mortalidade<br>são conflitantes.<br>Em coorte<br>retrospectiva com<br>crianças, não<br>houve diferença<br>no risco de<br>mortalidade entre<br>os grupos<br>(HR=0,57,<br>IC95%: [0,22;<br>1,49], p=0,25)<br>(17). Já em série<br>de casos com<br>número muito<br>maior de<br>pacientes,<br>observou-se que<br>houve redução<br>significativa do<br>risco de<br>mortalidade (HR<br>= 0,49, p<0,001)<br>(23).|⨁◯◯◯<br>MUITO<br>BAIXA|75<br>CRÍTICO|  
|**№ dos**<br>**estudo**<br>**s**<br>**Delineamento**<br>**do estudo**|**Risc**<br>**o de**<br>**viés**|**Avaliação daQ**<br>**Inconsistênci**<br>**a**|**ualidade**<br>**Evidênci**<br>**a indireta**<br>**Imprecisã**<br>**o**|**Outras**<br>**consideraçõe**<br>**s**|**Impacto**|**Qualidad**<br>**e Global**|**Importância**|
|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Eventos Adversos** -->
|10|ensaios<br>clínicos<br>randomizados<br>estudo<br>observacional|muit<br>o<br>grave<br>a,b|grave<sup>c,g,j</sup>|não grave|não grave|nenhum|Os eventos<br>adversos mais<br>comuns foram os<br>gastrointestinais<br>(diarreia,<br>flatulência,<br>desconforto<br>abdominal) e<br>perda de peso.<br>Estes eventos se<br>resolveram após<br>redução ou<br>retirada do<br>medicamento.<br>Falta de apetite,<br>tremores,<br>trombocitopenia,<br>cefaleia e novos<br>episódios<br>convulsivos<br>também foram<br>relatados (16-22,<br>25, 26, 68).|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANT<br>E|
|---|---|---|---|---|---|---|---|---|---|  
76  
**Legenda:** ECR – Ensaio Clínico Randomizado; HR – _hazard ratio_ ; IC 95% - Intervalo de confiança 95%, MEEM: Mini exame do estado mental; **Explicações:** a. Alto risco de viés pela ferramenta Cochrane; b. Inclusão de série de casos; c. Heterogeneidade metodológica entre estudos; d. Desfecho substituto; e. Intervalo de confiança amplo; f. Grande número de perdas, com redução do n em até 3x; g. tempos de seguimento diferentes; h. Limitação de Informações (resumo); i. Inclui apenas pacientes com uma forma de doença (de quatro possíveis); j. subgrupos diferentes; k. baseada em escores de incapacidade; l. Alto Risco de viés pela (NOS).  
77

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Tabela G** - Sumarização de evidências para tomada de decisão. -->
|**Qual a eficácia e a seg**<br>**Niemann Pick tipo C (**|**urança do miglustate para o tratamento da doença de**<br>**NPC)?**|
|---|---|
|**POPULAÇÃO:**|Manifestação neurológica da doença de Niemann-Pick<br>tipo C|
|**INTERVENÇÃO:**|Miglustate|
|**COMPARADOR:**|Cuidado padrão (fisioterapeuta, fonoaudiólogo, terapeuta<br>ocupacional, medicamentos para controle de sintomas) ou<br>nenhum comparador nas séries de caso e análises de<br>extensão do ECR.|
|**DESFECHOS**<br>**PRINCIPAIS**|Benefícios: Redução de progressão neurológica da doença,<br>melhoria em escores de incapacidade|
|**CENÁRIO**|Todo Brasil (Perspectiva SUS)|

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Avaliação** -->
**Problema O problema é uma prioridade?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **EVIDÊNCIAS DE PESQUISA** -->
- A NPC é uma doença hereditária, rara, com prevalência estimada de 1:100.000<sup>1</sup> . Apresenta manifestações neuroviscerais, com deterioração neurológica progressiva, resultando em incapacidade e morte prematura (8, 69).  
- O miglustate é, atualmente, o único tratamento modificador da doença registrado para manifestações neurológicas da doença de Niemann Pick tipo C(14). Usualmente os pacientes recebem medicamentos para controle de sintomas e fazem acompanhamento com equipe multidisciplinar com vistas a melhorar a qualidade de vida (8, 14).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Efeitos desejáveis** -->
**Quão substanciais são os efeitos desejáveis anteci** **<mark>p</mark> ados?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **EVIDÊNCIAS DE PESQUISA** -->
> 1 Orphanet. Prevlence and Incidence of Rare Diseases: Bibiographic Data. Disponível em: <u>https://www.orpha.net/orphacom/cahiers/docs/GB/Prevalence_of_rare_diseases_by_alphabetical_list.pdf.</u>  
62  
- Estabilização ou melhora nos escores de incapacidade e sub escores - deambulação, manipulação, linguagem e deglutição: tendência à estabilização dos escores de deambulação e deglutição - ausência de diferença entre intervenção e comparador (16); melhora ou estabilização em mais de 50% da amostra em uso de miglustate (18-22, 24-26, 67, 70);  
- Estabilização ou melhora dos movimentos oculares: ausência de diferença entre intervenção e comparador em análise ajustada por características basais; Diferença com significância estatística a favor do miglustate com em pacientes que não utilizavam benzodiazepínicos (-0,718; IC 95%: [-1,349; -0,088]; p=0,028) (16); estabilização ou melhora em mais de 60% dos pacientes em uso de miglustate (18, 21, 22);  
- Estabilização ou melhora na função cognitiva: tendência a favor do miglustate, porém sem diferença entre os grupos (p=0,165) (16); melhora ou estabilização em mais de 55% dos pacientes em uso de miglustate (21, 26, 67);  
- Melhora ou estabilização de episódios convulsivos: Melhora em mais de 60% dos pacientes com as formas infantil precoce, tardia e juvenil em uso de miglustate (18); ocorrência de novas crises e cataplexia em 21% de pacientes pediátricos em uso de miglustate (19);  
- Estabilização da progressão de doença (controverso): Estabilização ou melhora em mais de 60% dos pacientes em uso de miglustate (20, 21, 24, 25, 67); estabilização em menos de 40% dos pacientes em uso de miglustate (18, 19); Deterioração em 20% (22) e em 62,5% (18); e  
- Aumento de sobrevida e redução na mortalidade : ausência de diferença estatisticamente significante entre intervenção (5,45 anos) e controle (4,42 anos) na forma infantil precoce, com HR=0,57; IC95%[0,22; 1,49], p=0,25 (17, 23); redução do risco de mortalidade para pacientes em uso de miglustate, com significância estatística para as formas infantil tardia e juvenil (23).

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Efeitos indesejáveis** -->
**Quão substanciais são os efeitos indesejáveis antecipados?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: EVIDÊNCIAS DE PESQUISA -->
- Sintomas gastrointestinais (diarreia, desconforto abdominal, náusea, vômitos e flatulência) – 50% a 89,5% (20, 21)  
- Alterações hematológicas (trombocitopenia) – 54% (25)  
- Perda de peso (sem prejuízo de crescimento em crianças) – 16,10% - 75% (21, 68)  
- Tremores – 2% - 58% (22, 25)  
- Outros eventos adversos: novos episódios convulsivos (25), cefaleia – 33-50% (16, 22), fadiga – 35% - 46,40% (16, 21). Insônia, problemas comportamentais, falta de apetite, alteração de enzimas hepáticas e disfagia também foram relatados, embora com menor frequência (16, 26);  
- Maioria dos desfechos sobre a eficácia do miglustate são descritivos, sem  
63  
comparador e sem teste estatístico. A definição de melhora é subjetiva, sendo difícil mensurar qual é a significância clínica de um desfecho de melhora ou de estabilidade.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Certeza na evidência** -->
**Qual a certeza global na evidência dos efeitos?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **EVIDÊNCIAS DE PESQUISA** -->
- A qualidade geral da evidência é **muito baixa** . Segue o julgamento para desfechos específicos:  
- Qualidade de evidência muito baixa para estabilização ou melhora em parâmetros de movimentos oculares;  
- Qualidade de evidência muito baixa quando à estabilização ou melhora da função cognitiva;  
- Qualidade de evidência muito baixa a respeito da estabilização ou melhora de crises convulsivas;  
- Qualidade de evidência muito baixa quanto a ganhos em sobrevida e redução de mortalidade;  
- Qualidade de evidência muito baixa para progressão de doença;  
- Qualidade muito baixa para melhora ou estabilização nos escores de incapacidade e seus sub escores (deambulação, manipulação, linguagem e deglutição);  
- Qualidade de evidência muito baixa para eventos adversos.  
**Valores e preferências dos pacientes Existe incerteza importante sobre a variabilidade de quanto as pessoas dão valor ao desfecho principal?**  
- Medicamento via oral, 3x ao dia.  
- Há relatos de suspensão do tratamento devido à falta de percepção de eficácia, dificuldade de deglutição, progressão de doença e óbito (21, 68).  
- Desfecho avaliado por meio de ECR é pouco importante (movimento sacádico ocular) e pode não ser relevante do ponto de vista do paciente, seus cuidadores e família.  
**Balanço entre efeitos (riscos e benefícios) O balan** **<mark>ç</mark> o entre risco e benefício favorece a interven** **<mark>ç</mark> ão ou o comparador?**  
64  
- Conforme observado em efeitos desejáveis e indesejáveis:  
- Ausência de diferença entre grupo intervenção e comparador em deglutição, deambulação, cognição e movimentos oculares ajustados por características basais em pacientes com as formas adolescente e adulta da doença;  
- Escores de incapacidade e sub escores com tendência à estabilização da doença;  
- Tendência à estabilização de episódios convulsivos, porém ocorrência de novas crises;  
- Tendência à estabilização da função cognitiva e progressão de doença;  
- Ausência de diferença na sobrevida e mortalidade em pacientes com a forma infantil precoce da doença, comparados ao grupo controle;  
- Eventos adversos gastrointestinais, perda de peso e tremores são frequentes. Menos comumente, pode ocorrer fadiga, cefaleia, insônia, alterações comportamentais, novos episódios convulsivos e trombocitopenia; e  
- Suspensão do tratamento devido à dificuldade de deglutir medicamento, progressão de doença, solicitação de pacientes e familiares, percepção de ausência de efeito do tratamento e óbito.  
- Avaliação impacto orçamentário:  
- Acesso 100% (2020 a 2024)  
- Somente população SUS.  
- Ano 1 - R$ 356,3 milhões  
- 5 anos: R$ 1,78 bilhão  
**QUADRO C -** Análise de impacto orçamentário de custos com medicamento e exames diagnósticos (2020-2024).  
<!-- Start of picture text -->
2020 211.755.692 2118 o RS 349.996.583,92 RS 6.352.670,76 RS 356.349.254,68<br>2023 216.284.269 2.163 14,55729 RS 357.481.560,90 RS 43.671,87 RS 357.525.232,77<br>2024 217.684.462 2177 14,00193 RS 359.795.844,70 RS 42.005,79 RS 359.837.850,49<br><!-- End of picture text -->  
- Acesso variável (50% - 60% - 70% - 80% - 90%):  
- Somente população SUS  
- Ano 1: R$ 181,3 milhões  
- 5 anos: R$ 1,4 bilhão  
65  
**QUADRO D -** Análise de impacto orçamentário do miglustate e do exame diagnóstico com acesso variável (2020-2024).  
<!-- Start of picture text -->
‘Ano _PopulacSo Br casos casos Novos Valor/ ano aoevalor/ano Custos/Ano<br>2020 © 211.755.692 2aie ° RS174.998.291,96 -RS_—=—=6.352.670,76 ——-RS_—181.350.962,72<br>2021 213.317.639 2.133 18 RS 246.804.753,93 RS 46.858,41 RS -246,851.612,34<br>2022 214.828.540 2a 15 RS 395.075.485,43 RS 45.327,03 —-RS_—_-355.120.812,46<br>2023 216.284.269 2.163 15 RS 285.985.248,72 RS 43.671,87 RS__-286.028.920,59<br>2024 _217.684.462 2477 14 RS 323.816.260.238 RS 42.005,79 RS __323.858.266,02<br>lO miglustate + exames: RS 1.393.210.574,12<br>Legenda: AIO — Andlise de impacto Orcamentério.<br><!-- End of picture text -->  
- Acesso 100%  
- População elegível: 100 pacientes  
- Impacto orçamentário em 5 anos: R$ 172,7 milhões  
**QUADRO E -** Análise de impacto orçamentário do miglustate com população elegível segundo dados da Interfarma (2020-2024).  
<!-- Start of picture text -->
Pacientes<br>a ‘Custo mensal SIASG* Custo Anual AIO5 anos<br>“Fonte interna100do MS, com base emR$ 2.878.020,00compra efetuada em 03/2019,RS 34,536,240,00sendo o valor unitario deR$ 172.681.200,00RS 76,52.<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Custo-efetividade** -->
**A razão custo-efetividade da interven** **<mark>ç</mark> ão favorece a interven** **<mark>ç</mark> ão ou o comparador?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **EVIDÊNCIAS DE PESQUISA** -->
- O miglustate é o único tratamento medicamentoso modificador do curso da doença com aprovação em bula;  
- Nenhum dos estudos utilizou comparador ativo com outro fármaco modificador da atividade da doença;  
- Comparado aos cuidados paliativos, a adição do miglustate ao tratamento ofertado atualmente resulta em razão de custo-efetividade incremental (RCEI) de R$ 459.120,00;  
**Equidade**  
- Único medicamento modificador de doença aprovado (14);  
- O acesso ao medicamento, atualmente, dá-se por meio de ações de judicialização; e  
- Atualmente é oferecido pelo SUS para outras condições que não NPC (Doença  
> 2 Fonte Interna do Ministério da Saúde.  
66

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **Aceitabilidade** -->
**A interven** **<mark>ç</mark> ão é aceitável para os** **_stakeholders_ chave?**

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **EVIDÊNCIAS DE PESQUISA** -->
- Provavelmente aceitável por ser único medicamento modificador de doença, além de ser de fácil uso (oral);  
- Medicamento já adquirido para o tratamento da doença de Gaucher, o que facilita a ampliação do uso;  
- Possibilidade de redução de gasto com a redução/eliminação do fator judicialização;  
- O PBAC foi a única agência internacional que avaliou o miglustate e considerou os dados de efetividade insuficientes para justificar os custos adicionais em relação à terapia paliativa.  
**Viabilidade de implementação A implementa** **<mark>ç</mark> ão da interven** **<mark>ç</mark> ão é viável?**  
- O medicamento se encontra contemplado no Componente Especializado da Assistência Farmacêutica.  
- O paciente deve manter o uso de medicamentos para controle de sintomas e acompanhamento periódico com equipe especializada. Deste modo, a oferta do miglustate geraria um ônus adicional ao tratamento que é proporcionado atualmente.  
- Haverá necessidade de readequação da rede para distribuição do medicamento mediante diagnóstico confirmado.  
- Deve-se levar em conta que a NPC é uma doença de difícil diagnóstico e, muitas vezes, pode envolver o uso de testes caros, que poderiam gerar custos incrementais.

---

<!-- METADADOS: doenca: Doença de Niemann-Pick Tipo C (Diretriz Brasileira) | secao: **REFERÊNCIAS** -->
1. MC P. Niemann-Pick Disease. In: Schapira A WZ, Dawson TM, Wood N, editor. Neurodegeneration. 1st ed. Hoboken, NJ: Wiley Blackwell; 2017. p. 303-8.  
2. Vanier MT. Niemann-Pick disease type C. Orphanet J Rare Dis. 2010;5:16.  
3. Wassif CA CJ, Iben J, Sanchez-Pulido L, Cougnoux A, Platt FM, Ory DS, Ponting CP, Bailey-Wilson JE, Beisecker LG, Porter FD.   . High incidence of unrecognized  
> 3 Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Doença de Gaucher. Disponível em: <u>http://conitec.gov.br/images/Protocolos/PCDT___Doenca_de_Gaucher.pdf , acesso em 27/02/2019.</u>  
67  
visceral/neurological late-onset Niemann-Pick disease, type C1, predicted by analysis of massively parallel sequencing data sets. Genetics in Medicine. 2015;18(1):41-8.  
4. Orphanet. Prevalence and incidence of rare diseases: Bibliographic data - Orphanet Report Series - Rare Diseases collection. 2019;1.  
5. Geberhiwot T  MA, Dardis A, Ramaswami U, Sirrs S, Pineda Marfa M, Vanier MT, Walterfang M, Bolton S, Dawson C, Héron B, Stampfer M, Imrie J, Hendriksz C, Gissen P, Crushell E, Coll MJ, Nadjar Y, Klünemann H, Mengel E, Hrebicek M, Jones SA, Ory D, Bembi B, PattersonM. Consensus clinical management guidelines for Niemann-Pick disease type C. Orphanet Journal of Rare Diseases. 2018;13(50).  
6. Patterson MC, Clayton P, Gissen P, Anheim M, Bauer P, Bonnot O, et al. Recommendations for the detection and diagnosis of Niemann-Pick disease type C : An update. Neurology: Clinical Practice. 2017;7(6):499-511.  
7. Wijburg FA SF, Pineda M, Hendriksz CJ, Fahey M, Walterfang M, Patterson MC, Wraith JE, Kolb SA. Development of a Suspicion Index to aid diagnosis of NiemanPick disease type C Neurology. 2012;78:1560-7.  
8. Lyseng-Williamson KA. Miglustat: a review of its use in Niemann-Pick disease type C. Drugs. 2014;74(1):61-74. 9. King K G-SS, Yanjamin N, Zalewski C, Houser A, Porter F, Brewer CC. Auditory Phenotype of Niemann-Pick Disease, Type C1. Ear Hear. 2014;35(1):110-7.  
10. Mengel E, Klünemann HH, Lourenço CM, Hendriksz CJ, Sedel F, Walterfang M, et al. Niemann-Pick disease type C symptomatology: An expert-based clinical description. Orphanet Journal of Rare Diseases. 2013;8(1).  
11. Pineda M ME, Jahnová  H, Héron B, Imrie J, Lourenço CM, van der Linden V, Karimzadeh P, Valayannopoulos V, Jesina P, Torres JV, Kolb SA. A Suspicion Index to aid screening of early-onset Niemann-Pick disease Type C (NP-C). BMC Pediatr. 2016;16(107):1-10.  
12. Wraith JE, Baumgartner MR, Bembi B, Covanis A, Levade T, Mengel E, et al. Recommendations on the diagnosis and management of Niemann-Pick disease type C. Molecular Genetics and Metabolism. 2009;98(1-2):152-65.  
13. Alobaidy H. Recent advances in the diagnosis and treatment of niemann-pick disease type C in children: a guide to early diagnosis for the general pediatrician. Int J Pediatr. 2015;2015:816593. 14. Pineda M, Walterfang M, Patterson MC. Miglustat in Niemann-Pick disease type C patients: a review. Orphanet J Rare Dis. 2018;13(1):140.  
15. Patterson MC, Hendriksz CJ, Walterfang M, Sedel F, Vanier MT, Wijburg F. Recommendations for the diagnosis and management of Niemann-Pick disease type C: an update. Mol Genet Metab. 2012;106(3):330-44.  
16. Patterson MC, Vecchio D, Prady H, Abel L, Wraith JE. Miglustat for treatment of Niemann-Pick C disease: a randomised controlled study. Lancet Neurol. 2007;6(9):76572.  
17. Freihuber C, Dahmani B, Brassier A, Broue P, Cances C, Chabrol B, et al. Effects of miglustat therapy on neurological disorder and survival in early-infantile niemannPick disease type C: A national French retrospective study. European Journal of Paediatric Neurology. 2017;21:e2.  
18. Ginocchio VM, D'Amico A, Bertini E, Ceravolo F, Dardis A, Verrigni D, et al. Efficacy of miglustat in Niemann-Pick C disease: a single centre experience. Mol Genet Metab. 2013;110(3):329-35.  
19. Héron B, Valayannopoulos V, Baruteau J, Chabrol B, Ogier H, Latour P, et al. Miglustat therapy in the French cohort of paediatric patients with Niemann-Pick disease type C. Orphanet Journal of Rare Diseases. 2012;7(1).  
68  
20. Patterson M, Vecchio D, Jacklin E, Wraith E. Long-term clinical trial with miglustat in Niemann-Pick disease type C. Molecular Genetics and Metabolism. 2009;96(2):S33-S4.  
21. Wraith JE, Vecchio D, Jacklin E, Abel L, Chadha-Boreham H, Luzy C, et al. Miglustat in adult and juvenile patients with Niemann-Pick disease type C: long-term data from a clinical trial. Mol Genet Metab. 2010;99(4):351-7.  
22. Patterson MC, Vecchio D, Jacklin E, Abel L, Chadha-Boreham H, Luzy C, et al. Long-term miglustat therapy in children with Niemann-Pick disease type C. J Child Neurol. 2010;25(3):300-5.  
23. Patterson MC, Garver WS, Giugliani R, Imrie J, Jahnova H, Meaney FJ, et al. Does miglustat treatment confer a benefit on survival in NP-C? Insights from a large observational cohort study. Journal of Inherited Metabolic Disease. 2018;41:S181.  
24. Patterson MC, Vanier MT, Mengel E, Moneuse P, Rosenberg D, Schwierin B, et al. Miglustat treatment is associated with stabilised disability scores in patients from the International NPC Registry. Journal of Inherited Metabolic Disease. 2018;41:S181.  
25. Patterson MC, Mengel E, Vanier MT, Schwierin B, Muller A, Cornelisse P, et al. Stable or improved neurological manifestations during miglustat therapy in patients from the international disease registry for Niemann-Pick disease type C: an observational cohort study. Orphanet J Rare Dis. 2015;10:65.  
26. Fecarotta S, Romano A, Della Casa R, Del Giudice E, Bruschini D, Mansi G, et al. Long term follow-up to evaluate the efficacy of miglustat treatment in Italian patients with Niemann-Pick disease type C. Orphanet J Rare Dis. 2015;10:22.  
27. BRASIL. MIGLUSTATE PARA MANIFESTAÇÕES NEUROLÓGICAS DA DOENÇA DE NIEMANN-PICK TIPO C (NPC). In: Saúde Md, editor. Brasília2019. 28. Brasil. PORTARIA Nº 35, DE 23 DE JULHO DE 2019. Torna pública a decisão de não incorporar o miglustate para manifestações neurológicas da doença de NiemannPick tipo C, no âmbito do Sistema Único de Saúde - SUS. In: Saúde Md, editor. Brasilia: Diário Oficial da União; 2019. 29. Brasil. PORTARIA CONJUNTA Nº 17, DE 21 DE JUNHO DE 2018. In: Saúde Md, editor. Brasília: DOU; 2018. p. 45.  
30. van Karnebeek CD, Stockler S. Treatable inborn errors of metabolism causing intellectual disability: a systematic literature review. Mol Genet Metab. 2012;105(3):368-81.  
31. Pineda M JM, Karimzadeh P, Kolnikova M, Malinova V, Insua JL, Velten C and Kolb SA. Disease characteristics, prognosis and miglustat treatment effects on disease progression in patients with Niemann-Pick disease Type C: an international, multicenter, retrospective chart review. Orphanet Journal of Rare Diseases. 2019;14(32).  
32. BRASIL. PORTARIA Nº 375, DE 10 DE NOVEMBRO DE 2009. In: Saúde Md, editor. Brasília2009.  
33. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. In: Saúde Md, editor. Brasília2016.  
34. Shea BJ RB, Wells G, Thuku M, Hammel C, Moran J, Moher J, Tugwell P, Welch V, Kristjansson E, Henry DA. AMSTAR 2: a critical apparaisal tool for systematic reviews that ionclude randomised or non randomised studies of healthcare interventions, or both. BMJ. 2017;358.  
35. Higgins JPT SG. Handbook for Systematic Reviews of Interventions. The Cochrane Collaboration 2011.  
69  
36. Wells G SB, O'Connell D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for Assessing the Quality of Nonrandomised Studies in meta-analysis. . 2011;2009.  
37. Guyatt GH OA, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, Schünemann HJ. Rating quality of evidence and strength of recommendations: GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ: British Medical Journal. 2008;336(7650):924.  
38. Moberg J OA, rosenbaum S, Schünemann HJ, Guyatt G, Flottorp S, Glenton C, Lewin A, Morelli A, Rada D, Alonso-Coello P The GRADE Evidence to Decision (EtD) framework for health system and public health decisions. Health Research and Policy Systems. 2018;16:45.  
39. Brasil. CONITEC 2019 [Available from: <u>http://conitec.gov.br/tecnologias-emavaliacao.</u>  
40. Santos-Lozano A, Villamandos Garcia D, Sanchis-Gomar F, Fiuza-Luces C, Pareja-Galeano H, Garatachea N, et al. Niemann-Pick disease treatment: a systematic review of clinical trials. Ann Transl Med. 2015;3(22):360.  
41. Walterfang M, Chien YH, Imrie J, Rushton D, Schubiger D, Patterson MC. Dysphagia as a risk factor for mortality in Niemann-Pick disease type C: systematic literature review and evidence from studies with miglustat. Orphanet J Rare Dis. 2012;7:76.  
42. Sedel F, Chabrol B, Audoin B, Kaphan E, Tranchant C, Burzykowski T, et al. Normalisation of brain spectroscopy findings in Niemann–Pick disease type C patients treated with miglustat. Journal of Neurology. 2016;263(5):927-36.  
43. Ribas GS, Pires R, Coelho JC, Rodrigues D, Mescka CP, Vanzin CS, et al. Oxidative stress in Niemann-Pick type C patients: A protective role of N-butyldeoxynojirimycin therapy. International Journal of Developmental Neuroscience. 2012;30(6):439-44.  
44. Bowman EA, Velakoulis D, Desmond P, Walterfang M. Longitudinal Changes in White Matter Fractional Anisotropy in Adult-Onset Niemann-Pick Disease Type C Patients Treated with Miglustat. JIMD Rep. 2018;39:39-43.  
45. Bowman EA, Walterfang M, Abel L, Desmond P, Fahey M, Velakoulis D. Longitudinal changes in cerebellar and subcortical volumes in adult-onset NiemannPick disease type C patients treated with miglustat. J Neurol. 2015;262(9):2106-14.  
46. Pineda Marfa M, Del Socorro Pérez Poyato M, Del Mar O'Callaghan Gordo M, Macías Vidal J, Josep Coll i Coll M, Aracil A. Niemann-Pick disease type C when to give and discontinue treatment with substrate inhibitor therapy. European Journal of Paediatric Neurology. 2011;15:S26.  
47. Abel LA, Walterfang M, Stainer MJ, Bowman EA, Velakoulis D. Longitudinal assessment of reflexive and volitional saccades in Niemann-Pick Type C disease during treatment with miglustat. Orphanet J Rare Dis. 2015;10:160.  
48. Giugliani L, Van Der Linder V, Van Der Linden Junior H, Lourenc¸o CM, De Araújo Leão EKE, Arita JH, et al. Disease duration and survival in Brazilian NiemannPick disease type C patients: Preliminary data on potential impact of miglustat. Molecular Genetics and Metabolism. 2016;117(2):S50-S1.  
49. Heitz C, Epelbaum S, Nadjar Y. Cognitive impairment profile in adult patients with Niemann pick type C disease. Orphanet J Rare Dis. 2017;12(1):166.  
50. Karimzadeh P, Tonekaboni SH, Ashrafi MR, Shafeghati Y, Rezayi A, Salehpour S, et al. Effects of miglustat on stabilization of neurological disorder in niemann-pick disease type C: Iranian pediatric case series. J Child Neurol. 2013;28(12):1599-606.  
70  
51. Nadjar Y, Hutter-Moncada AL, Latour P, Ayrignac X, Kaphan E, Tranchant C, et al. Adult Niemann-Pick disease type C in France: clinical phenotypes and long-term miglustat treatment effect. Orphanet J Rare Dis. 2018;13(1):175.  
52. Pineda M, Perez-Poyato MS, O'Callaghan M, Vilaseca MA, Pocovi M, Domingo R, et al. Clinical experience with miglustat therapy in pediatric patients with Niemann-Pick disease type C: A case series. Molecular Genetics and Metabolism. 2010;99(4):358-66. 53. Jacklin E, Imrie J, Jones S, Wraith E. Review of 11 patients with NPC1 treated with miglustat. Molecular Genetics and Metabolism. 2010;99(2):S22.  
54. Poyato MSP, Marfa MP, Vilaseca MA, Gordo MMO, Macias J, Coll MJ. Cerebral PET and disability evaluation in patients with Niemann Pick disease Type C treated with miglustat. European Journal of Paediatric Neurology. 2009;13:S13.  
55. Freihuber C, Vanier MT, Brassier A, Broue P, Chabrol B, Eyer D, et al. Miglustat therapy in early infantile Niemann-Pick C patients: A retrospective survival study. Journal of Inherited Metabolic Disease. 2015;38(1):S304.  
56. Fecarotta S, Astarita L, Bruschini D, Pisani L, Romano A, Del Giudice E, et al. Efficacy of miglustat on the neurological involvement in Italian patients with niemannpick disease type C. Molecular Genetics and Metabolism. 2009;98(1-2):70.  
57. Pineda M, Wraith JE, Mengel E, Imrie J, Schwierin B, Bembi B. Safety monitoring of miglustat in patients with Niemann-Pick disease type C. Journal of Neurology. 2009;256:S167.  
58. Pineda M, Wraith JE, Mengel E, Sedel F, Hwu WL, Rohrbach M, et al. A multicentre retrospective cohort study of miglustat in patients with Niemann-Pick disease type C. European Journal of Paediatric Neurology. 2009;13:S115.  
59. Pineda M, Wraith JE, Mengel E, Sedel F, Hwu WL, Rohrbach M, et al. A multicentre retrospective cohort study of miglustat in patients with Niemann-Pick disease type C. Journal of Neurology. 2009;256:S39-S40.  
60. Pineda M, Wraith JE, Mengel E, Sedel F, Hwu WL, Rohrbach M, et al. Miglustat in patients with Niemann-Pick disease Type C (NP-C): a multicenter observational retrospective cohort study. Mol Genet Metab. 2009;98(3):243-9.  
61. Pineda M, Mengel E, Vanier MT, Schwierin B, Muller A, Cornelisse P, et al. Longitudinal outcomes from the international disease registry for Niemann-Pick disease type C (NP-C). Journal of Neurology. 2014;261:S243.  
62. Pineda M, Mengel E, Wijburg FA, Muller A, Schwierin B, Drevon H, et al. Longitudinal outcomes from the international disease registry for Niemann-Pick disease type C (NP-C). Journal of Inherited Metabolic Disease. 2013;36(2):S263.  
63. Pineda M, Mengel E, Wijburg FA, Vanier MT, Schwierin B, Muller A, et al. Longitudinal outcomes from the international disease registry for Niemann-Pick disease type C (NP-C). European Journal of Paediatric Neurology. 2013;17:S39.  
64. Patterson M, Pineda M, Sedel F, Mengel E, Hwu WL, Rohrbach M, et al. A multicentre retrospective survey of miglustat in patients with Niemann-Pick type C disease. Molecular Genetics and Metabolism. 2009;96(2):S34.  
65. Patterson MC, Mengel E, Wijburg FA, Vanier MT, Schwierin B, Muller A, et al. Longitudinal data from the international registry for Niemann-Pick disease type C (NPC). Molecular Genetics and Metabolism. 2014;111(2):S85.  
66. Patterson MC, Wraith JE, Mengel E, Sedel F, Hwu WL, Rohrbach M, et al. A multicentre retrospective cohort study of miglustat in patients with Niemann-Pick disease type C. Molecular Genetics and Metabolism. 2009;98(1-2):61.  
67. Wraith E, Vecchio D, Jacklin E, Luzy C, Giorgino R, Patterson M. Disease stability in patients with Niemann-Pick disease type C treated with miglustat. Molecular Genetics and Metabolism. 2009;96(2):S46.  
71  
68. Pineda M, Wraith JE, Mengel E, Imrie J, Hahnell K, Bembi B. Safety monitoring of miglustat in patients with Niemann-Pick disease type C: An update. European Journal of Paediatric Neurology. 2009;13:S114.  
69. Evans WRH, Hendriksz CJ. Niemann-pick type C disease -The tip of the iceberg? A review of neuropsychiatric presentation, diagnosis and treatment. Psychiatrist. 2017;41(2):109-14.  
70. Imrie J, Dasgupta S, Besley GTN, Harris C, Heptinstall L, Knight S, et al. The natural history of Niemann-Pick disease type C in the UK. Journal of Inherited Metabolic Disease. 2007;30(1):51-9.  
72

---

