<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 353, DE 14 DE FEVEREIRO DE 2017(*)  
Aprova as Diretrizes Nacionais de Assistência ao Parto Normal.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o parto normal no Brasil e diretrizes nacionais para a sua utilização e acompanhamento das mulheres a ele submetidas;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação n<sup><u>o</u></sup> 211 – Maio/2016 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), que aprova as Diretrizes de Assistência ao Parto Normal; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias no SUS (DGITS/SCTIE/MS, do Departamento de Ações Programáticas Estratégicas(DAPES/SAS/MS) e da assessoria técnica da SAS/MS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo, disponível a partir de 8 de março de 2017, no sítio: www.saude.gov.br/sas, as “Diretrizes Nacionais de Assistência ao Parto Normal”.  
Parágrafo único. As diretrizes de que trata este artigo, que contêm as recomendações para o parto normal, são de caráter nacional e devem utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação da gestante, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao  uso de procedimento ou medicamento para a realização do parto normal.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento das gestantes em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
- (*) Republicada por ter saído, no Diário Oficial da União – DOU nº 36, de fevereiro de 2017, seção 1, página 37, com incorreções no original.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Apresentação -->
O nascimento no ambiente hospitalar se caracteriza pela adoção de várias tecnologias e procedimentos com o objetivo de torná-lo mais seguro para a mulher e seu bebê. Se por um lado, o avanço da obstetrícia contribuiu com a melhoria dos indicadores de morbidade e mortalidade materna e perinatais, por outro permitiu a concretização de um modelo que considera a gravidez, o parto e o nascimento como doenças e não como expressões de saúde, expondo as mulheres e recém-nascidos a altas taxas de intervenções, que deveriam ser utilizadas de forma parcimoniosa e apenas em situações de necessidade, e não como rotineiras. Esse excesso de intervenções deixou de considerar os aspectos emocionais, humanos e culturais envolvidos no processo, esquecendo que a assistência ao nascimento se reveste de um caráter particular que vai além do processo de parir e nascer. Quando as mulheres procuram ajuda, além da preocupação sobre a sua saúde e a do seu bebê, estão também em busca de uma compreensão mais ampla e abrangente da sua situação, pois para elas e suas famílias o momento da gravidez e do parto, em particular, é único na vida e carregado de fortes emoções. A experiência vivida por elas neste momento pode deixar marcas indeléveis, positivas ou negativas, para o resto das suas vidas.  
Por isso, torna-se imprescindível a qualificação da atenção à gestante, a fim de garantir que a decisão pela via de parto considere os ganhos em saúde e seus possíveis riscos, de forma claramente informada e compartilhada entre a gestante e a equipe de saúde que a atende.  
As Diretrizes Nacionais de Assistência ao Parto Normal é um esforço da Coordenação- Geral de Saúde da Mulher do Departamento de Ações Programáticas Estratégicas, da Secretaria de Atenção à Saúde do Ministério da Saúde (CGSM/DAPES/SAS/MS), para a qualificação do modo de nascer no Brasil. Este documento, em conjunto com Diretrizes de Atenção à Gestante: a operação cesariana, publicada em março de 2016, visa a orientar as mulheres brasileiras, os profissionais e os gestores da saúde, nos âmbitos público e privado, sobre importantes questões relacionadas às vias de parto, suas indicações e condutas, baseadas nas melhores evidências científicas disponíveis.  
Estas Diretrizes foram elaboradas por um grupo multidisciplinar, o Grupo Elaborador das Diretrizes (GED), composto por médicos obstetras, médicos de família, clínicos gerais, médico neonatologista, médico anestesiologista e enfermeiras obstétricas,convidados pela Comissão Nacional de Incrporação de Tecnologias no SUS (CONITEC) e pela Coordenação-Geral da Saúde da Mulher (CGSM/DAPES/SAS/MS).  
O escopo das Diretrizes e as perguntas a serem respondidas foram definidas com a participação de um grupo ampliado de interessados (Grupo Consultivo), entre eles sociedades e associações médicas, de enfermagem e das mulheres, agências reguladoras, pesquisadores, profissionais e conselhos de profissionais da saúde, além de áreas técnicas do Ministério da Saúde e a CONITEC.  
O documento resultante do consenso obtido pelo grupo ampliado foi apresentado à CONITEC, em sua 42 ª Reunião, realizada nos dias  02 e 03 de dezembro de 2015, na qual os membros dessa Comissão apreciaram a proposta com recomendação preliminar favorável, sendo, então, disponibilizada para Consulta Pública .  
Logo, esta versão das Diretrizes Nacionais de Assistência ao Parto Normal inclui as modificações que foram realizadas após a Consulta Pública. Esta ficou disponível para contribuições no período de 12  
de janeiro de 2016 a 29 de fevereiro de 2016, período estendido por solicitação da Associação Médica Brasileira (AMB).  
Foram recebidas 396 contribuições, das quais: 66 de mulheres, 24 de familiares, amigos ou cuidadores, 233 de profissionais da saúde, 63 de interessados no tema e 10 de pessoas jurídicas, incluindo empresas (2), instituição de ensino (1), sociedades médicas (3) e grupos/associação/organização de pacientes (2) e outra (2).  
Do total de contribuições, a maioria (84%) foi dada por mulheres. Na avaliação geral, 79% avaliaram as Diretrizes como boas ou muito boas, 7% como regulares e 14% como ruins ou muito ruins.  
Todas as contribuições foram analisadas pelo Grupo Elaborador e apresentadas ao Grupo Consultivo, em reunião realizada no dia 17 de março de 2016, em que estiveram presentes representantes de entidades médicas, de enfermagem, de hospitais, de associações em defesa dos direitos das mulheres, de universidades, bem como especialistas em saúde da mulher e gestores da saúde. Nesta reunião, foi discutida amplamente a pertinência da alteração ou não do conteúdo das Diretrizes a partir de cada contribuição, e da discussão surgiram os consensos em torno das alterações pertinentes que poderiam ser feitas, à luz das contribuições da Consulta Pública e das evidências encontradas nas Diretrizes e nas fontes verificadas no processo de adaptação.  
Importante ressaltar que só foram feitas alterações que não infringissem a metodologia de adaptação de diretrizes clínicas (ADAPTE) e que não fossem contrárias às evidências encontradas.  
O resultado da Consulta Pública, bem como a análise de seu conteúdo, foram apresentados em reunião do plenário da CONITEC no dia 06 de abril de 2016, que aprovou o documento na íntegra, apenas com a ressalva de que fosse alterado o título para Diretrizes Nacionais (no plural) de Assistência ao Parto Normal, e que fossem incluídos no corpo do documento, nominalmente, e por reunião, todos os representantes de entidades de classe que participaram das reuniões do Grupo Consultivo.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 1 Introdução e contexto -->
A cada ano acontecem no Brasil cerca de 3 milhões de nascimentos, envolvendo quase 6 milhões de pessoas, ou seja, as parturientes e os seus filhos ou filhas, com cerca de 98% deles acontecendo em estabelecimentos hospitalares, sejam públicos ou privados<sup>1,2</sup> . Isso significa que, a cada ano, o nascimento influencia parcela significativa da população brasileira, considerando as famílias e o seu meio social.  
Consolidado em nosso meio, o nascimento no ambiente hospitalar se caracteriza pela adoção de várias tecnologias e procedimentos com o objetivo de torná-lo mais seguro para a mulher e seu filho ou filha. De fato, os avanços da obstetrícia contribuíram com a melhoria dos indicadores de morbidade e mortalidade materna e perinatais em todo o mundo. Entretanto, as mulheres e recém-nascidos são expostos a altas taxas de intervenções, como a episiotomia, o uso de ocitocina, a cesariana, aspiração naso-faringeana, entre outras. Tais intervenções, que deveriam ser utilizadas de forma parcimoniosa, apenas em situações de necessidade, são muito comuns, atingindo um grande número de mulheres e seus filhos ou filhas que são assistidas em hospitais no país. Esse excesso de intervenções deixou de considerar os aspectos emocionais, humanos e culturais envolvidos no processo, esquecendo que a assistência ao nascimento se reveste de um caráter particular que vai além do processo de adoecer e morrer. Quando as mulheres procuram ajuda, além da preocupação sobre a sua saúde e a do seu filho ou filha, estão também em busca de uma compreensão mais ampla e abrangente da sua situação, pois para elas e suas famílias o momento da gravidez e do parto, em particular, é único na vida e carregado  
de fortes emoções. A experiência vivida por eles neste momento pode deixar marcas indeléveis, positivas ou negativas, para o resto das suas vidas  
Como resultado de pressões da opinião pública e consumidores de serviços de saúde, principalmente nos países mais desenvolvidos, assim como o surgimento de novas evidências científicas, a prática obstétrica tem sofrido mudanças significativas nos últimos 20-30 anos, com uma maior ênfase na promoção e resgate das características naturais e fisiológicas do parto e nascimento<sup>3</sup> . Com isso, vários procedimentos hospitalares têm sido questionados pela carência de evidências científicas que os suportem, a existência de evidências que os contra-indiquem e por trazerem desconforto à mulher. Também os ambientes onde o nascimento tem lugar têm sofrido modificações, tornando-se mais aconchegantes e com rotinas mais flexíveis, permitindo que a mulher e sua família possam participar e expressar livremente suas expectativas e preferências. Surgem também, como opção, modalidades de assistência em ambientes não hospitalares, como o parto domiciliar e em centros de nascimento dentro ou fora dos hospitais. Questiona-se também o predomínio do profissional médico na assistência, com o fortalecimento das enfermeiras obstétricas e obstetrizes<sup>1</sup> como atores importantes no processo assistencial.  
Além do mais, há uma grande diversidade de práticas clínicas nos diversos ambientes de atenção e, frequentemente, também ocorre uma grande variedade de condutas aplicáveis a situações semelhantes. Esta variedade de práticas pode colocar em risco a segurança das parturientes e seus filhos ou filhas já que, em muitos casos, não devem estar recebendo a assistência mais adequada às suas necessidades e de acordo com as melhores evidências derivadas de estudos científicos bem desenhados. Em outros casos também, podem estar sendo submetidas a práticas diagnósticas ou terapêuticas com potencial de provocar danos. Adicionalmente, a enorme expansão do conhecimento científico publicado nos últimos anos dificulta a sua aquisição de forma rápida e eficiente por parte daqueles envolvidos na assistência. Muitos problemas podem ter a sua origem na aplicação inadequada do conhecimento ou mesmo a não aplicação da prática mais eficaz para lidar com situações específicas. As diretrizes clínicas baseadas em evidências fornecem uma ferramenta adequada de consulta para os profissionais na sua atividade diária já que, se corretamente desenvolvidas, com avaliação sistemática e sintetização da informação científica disponível, são potentes aliadas na tomada de decisões. Nesse processo, as habilidades e experiência clínica do provedor de cuidados associadas às expectativas e necessidades únicas das mulheres e suas famílias, mais a informação derivada da melhor pesquisa científica, formam o tripé que se chama de prática clínica baseada em evidência, uma das regras básicas para uma assistência focada na qualidade.  
Em junho de 2011 o Governo Brasileiro instituiu a Rede Cegonha no âmbito do SUS (Sistema Único de Saúde)<sup>4</sup> , visando a assegurar à mulher o direito ao planejamento reprodutivo e à atenção humanizada à gravidez, ao parto e ao puerpério, bem como à criança o direito ao nascimento seguro e ao crescimento e ao desenvolvimento saudáveis. Entre os objetivos da Rede Cegonha está o de “fomentar a implementação de novo modelo de atenção à saúde da mulher e à saúde da criança com foco na atenção ao parto, ao nascimento, ao crescimento e ao desenvolvimento da criança de zero aos vinte e quatro meses”. No componente Parto e Nascimento da Rede Cegonha figura como ação a adoção de práticas de atenção à saúde baseada em evidências científicas nos termos do documento da Organização Mundial da Saúde, de 1996: "Boas práticas de atenção ao parto e ao nascimento".<sup>5</sup>  
> 1 Enfermeiras obstétricas e Obstetrizes são profissionais legalmente habilitados e capacitados para a assistência à gravidez e partos normais no Brasil, de acordo com a Lei no 7.498, de 25 de junho de 1986, além dos médicos.  
Seguindo essas determinações, o Ministério da Saúde, por meio da Secretaria de Atenção à Saúde, da Secretaria de Ciência Tecnologia e Insumos Estratégicos e seus respectivos Departamento de Ações Programáticas e Estratégicas e Departamento de Gestão da Incorporação de Tecnologias em Saúde (DGITS), solicitou à Coordenação-Geral da Saúde da Mulher (CGSM) e à Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) a elaboração de diretrizes para a assistência ao parto normal, para utilização no SUS e Saúde Suplementar no Brasil.  
2 Escopo e finalidades

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 2.1 Objetivos gerais -->
Estas Diretrizes têm como finalidades principais:  
Sintetizar e avaliar sistematicamente a informação científica disponível em relação às práticas mais comuns na assistência ao parto e ao nascimento fornecendo subsídios e orientação a todos os envolvidos no cuidado, no intuito de promover, proteger e incentivar o parto normal  
2.2 Objetivos específicos  
- Promover mudanças na prática clínica, uniformizar e padronizar as práticas mais comuns utilizadas na assistência ao parto normal;  
- diminuir a variabilidade de condutas entre os profissionais no processo de assistência ao parto;  
- reduzir intervenções desnecessárias no processo de assistência ao parto normal e consequentemente os seus agravos;  
- difundir práticas baseadas em evidências na assistência ao parto normal; e  
- recomendar determinadas práticas sem, no entanto, substituir o julgamento individual do profissional, da parturiente e dos pais em relação à criança, no processo de decisão no momento de cuidados individuais.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 3 A quem estas diretrizes se destinam -->
Estas Diretrizes deverão servir de referência e orientação para a assistência a:  
- mulheres em trabalho de parto com parto normal planejado (espontâneo ou induzido) entre 37 e 42 semanas de gestação com feto único, vivo e em apresentação cefálica;  
- gestantes com ruptura prematura de membranas no termo ou imediatamente antes do parto;  
- parturientes que apresentarem eliminação de mecônio imediatamente antes ou durante o trabalho de parto;  
- anormalidades ou complicações mais comuns encontradas na assistência ao trabalho de parto e parto em todas as suas fases;  
- recém-nascido normal imediatamente após o parto e nas primeiras horas de vida;  
- recém-nascido imediatamente após o parto na presença de líquido meconial;  
- recém-nascido normal em alojamento conjunto e no momento da alta; e  
- aleitamento materno e estímulo à amamentação.  
As seguintes situações não estão cobertas por estas Diretrizes:  
- mulheres em trabalho de parto prematuro (antes de 37 semanas de gestação);  
- conduta em outras anormalidades ou complicações do trabalho de parto e parto não constantes das diretrizes;  
- mulheres com diagnóstico de morte fetal ou com complicações da gestação tais como desordens hipertensivas, diabetes, gravidez múltipla, restrição de crescimento fetal, apresentações anômalas, etc.;  
- métodos e técnicas de indução do parto;  
- técnicas de parto vaginal operatório ou cesariana;  
- mulheres que necessitem de cuidados adicionais por infecção pelo HIV, herpes genital, estreptococo do grupo B ou outras infecções; ou  
- tratamento da hemorragia pós-parto.  
Nas mulheres em trabalho de parto a termo, espontâneo ou induzido, com complicações da gestação, tais como desordens hipertensivas, diabetes, gravidez múltipla, restrição de crescimento fetal, etc., estas Diretrizes também podem servir de referência já que algumas práticas e intervenções podem ser semelhantes.  
Para efeito destas Diretrizes entende-se como parto normal ou espontâneo aquele que não foi assistido por fórceps, vácuo extrator ou cesariana, podendo ocorrer intervenções baseadas em evidências, em circunstâncias apropriadas, para facilitar o progresso do parto e um parto vaginal normal, tais como:  
- estimulação do trabalho de parto com ocitocina;  
- ruptura artificial de membranas;  
- alívio farmacológico da dor (peridural, opióides, óxido nitroso);  
- alívio não farmacológico da dor; ou  
- manobra ativa no terceiro período.  
- Profissionais/usuários destas Diretrizes  
Audiência primária :  
- Todos os profissionais envolvidos diretamente na assistência ao parto, tais como: médicos obstetras, pediatras, neonatologistas, anestesiologistas, generalistas, enfermeiras obstétricas, obstetrizes, enfermeiras assistenciais, técnicos de enfermagem, etc.  
- Todos os profissionais em processo de treinamento envolvidos diretamente na assistência, tais como: especializandos e residentes de enfermagem obstétrica e neonatal, graduandos de obstetrícia e médicos residentes de obstetrícia, neonatologia e anestesiologia.  
Audiência secundária:  
- Todos os profissionais envolvidos indiretamente na assistência ao parto como fisioterapeutas, psicólogos, etc.  
- Estudantes de graduação na prática de estágio curricular ou extra-curricular envolvidos no processo de assistência ao parto.  
- As mulheres, seus familiares ou representantes.  
- Doulas, educadores perinatais, etc.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 4 Quem desenvolveu estas Diretrizes -->
Estas Diretrizes foram elaboradas por um grupo multidisciplinar, o Grupo Elaborador das Diretrizes (GED), convidados pela CONITEC e CGSM/DAPES/SAS/MS. O grupo foi composto por médicos obstetras, médicos de família, clínicos gerais, médico neonatologista, médico anestesiologista e enfermeiras obstétricas. Foi designado como coordenador do GED um médico obstetra. (Anexo I)  
Foi criado também um Comitê Executivo (Anexo II) do processo de elaboração das diretrizes, composto por profissionais do DGITS/SCTIE/MS, que é a Secretaria Executiva da CONITEC, e outros indicados pela CGSM/DAPES/SAS/MS. Esse Comitê se responsabilizou pela organização, planejamento e logística das oficinas do Conselho Consultivo e reuniões do GED.  
Todos os membros do GED declararam seus potenciais conflitos de interesses em formulário próprio da  
CONITEC. No formulário, constam interesses relacionados com a indústria da saúde ou qualquer outro interesse, comercial ou financeiro, com as recomendações das diretrizes.  
Os recursos para o custeio das atividades do GED, Conselho Consultivo e Comitê Executivo foram disponibilizados pelo Ministério da Saúde. A participação de colaboradores da Agência Nacional de Saúde (ANS) foi custeada por esta Agência. Alguns membros do Conselho Consultivo tiveram suas despesas de deslocamento e estadia custeadas pelas suas respectivas entidades. Os órgãos financiadores não influenciaram nas decisões do GED.  
5 Metodologia para elaboração destas Diretrizes  
5.1 Elaboração do escopo  
O escopo das Diretrizes, assim como as questões a serem respondidas, foi elaborado em oficina realizada em Brasília, com a participação de indivíduos e instituições interessadas, convidados pela CGSM/DAPES/SAS/MS, que passou a ser chamado de Conselho Consultivo, cujos membros estão relacionados no Anexo III. As questões estão nas seções e sub-seções das Diretrizes.  
5.2 Processo para elaboração das Diretrizes  
5.2.1 Estratégia de busca da literatura  
Após a listagem e aprovação das questões a serem respondidas, o painel organizador das Diretrizes, com a participação do coordenador do Grupo Elaborador, decidiu inicialmente buscar por diretrizes já elaboradas por outros grupos ou instituições e adaptá-las ao contexto brasileiro, utilizando o instrumento ADAPTE<sup>6</sup> .  
Foi, portanto, realizada uma busca por diretrizes de assistência ao parto, em inglês, espanhol, francês e português, publicadas entre 2004 e 2014, para análise e potencial adaptação. Os termos gerais utilizados para busca foram: “childbirth or labor or labour or (intrapartum care)” and “guidelines”. Esses termos foram adaptados para os diferentes idiomas e bases de dados eletrônicas. A busca foi realizada por dois profissionais de maneira independente, nas seguintes bases de dados eletrônicas e sítios da internet:  
Tripdatabase - http://www.tripdatabase.com GIN - http://www.g-i-n.net NGC - http://www.guideline.gov GPC Colômbia - http://gpc.minsalud.gov.co/Pages/Default.aspx NICE - http://www.nice.org.uk SIGN - http://www.sign.ac.uk ICSI - https://www.icsi.org HAS (França) - http://www.has-sante.fr Projeto Diretrizes/Brasil - http://www.projetodiretrizes.org.br  
No banco de dados do GPC da Colômbia, foi consultada apenas a lista de diretrizes clínicas organizada por tema, sem a utilização de termos de busca.  
No sítio do Ministério da Saúde da França, os termos utilizados foram: “travail accouchement”.  
No sítio do Projeto Diretrizes foi feita busca pela lista das sociedades científicas, sem a utilização de termos de busca.  
O processo de busca identificou seis diretrizes disponíveis em texto integral (listadas em ordem alfabética):  
1 – CREEDON, D. et. all. Management of labor. Bloomington (MN): Institute for Clinical Systems Improvement (ICSI). 66 p, Mar 2013<sup>7</sup> .  
2 – FEBRASGO – FEDERAÇÃO BRASILEIRA DAS ASSOCIAÇÕES DE GINECOLOGIA E OBSTETRÍCIA. Assistência ao Trabalho de Parto. S.L: Diretrizes Clínicas na Saúde Suplementar. Associação Médica Brasileira (AMB). Agência Nacional de Saúde Suplementar (ANS). 12 p, jan. 2011<sup>8</sup> .  
3 – GRUPO DE TRABALHO DO GUIA DE PRÁTICA CLÍNICA SOBRE CUIDADOS COM O PARTO NORMAL. Guia de Prática Clínica sobre Cuidados com o Parto Normal. Vitoria – Gasteiz: Plano de Qualidade para o Sistema Nacional de Saúde do Ministério da Saúde e Política Social. Agencia de Evaluación de Tecnologías Sanitarias del País Vasco (OSTEBA). Agencia de Evaluación de Tecnologías Sanitarias de Galícia. 316 p, Out. 2010<sup>9</sup> .  
4 – MAMBOURG, F.; GAILLY, J.; ZHANG, W. Guideline relative to low risk birth. Brussels: Belgian Health Care Knowledge Centre (KCE). 186 p, 2010<sup>10</sup> .  
5 – NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 332 p, Sep. 2007<sup>11</sup> .  
6 – QUEENSLAND MATERNITY AND NEONATAL CLINICAL GUIDELINES PROGRAM. Normal Birth. Brisbane (Qld): State of Queensland (Queensland Health), 2012<sup>12</sup> .  
Após o processo de busca e identificação, as diretrizes foram avaliadas por três avaliadores independentes, utilizando o instrumento AGREE II<sup>13</sup> , evidenciando os resultados dispostos na Tabela 1 por ordem decrescente no ranque do item Avaliação Geral:  
Tabela 1 – Avaliação das diretrizes segundo instrumento AGREE II<sup>13</sup>  
|Diretriz|||||Domíni|os|||
|---|---|---|---|---|---|---|---|---|
|es|1|2|3|4|5|6|Avaliação<br>Geral|Recomendaç<br>ãopara uso|
|3|94%|96%|88%|100%|85%|92%|94%|Sim = 3|
|5|98%|93%|99%|100%|68%|69%|94%|Sim = 3|
|4|91%|69%|88%|94%|18%|72%|78%|Sim = 2<br>Sim c/ modif.<br>= 1<br>Não = 0|
|1|76%|76%|53%|89%|33%|92%|56%|Sim c/ modif.<br>= 3|
|2|59%|0%|29%|63%|1%|50%|33%|Não = 3|
|6|48%|22%|7%|80%|17%|0%|28%|Não = 3|  
Domínio 1 = Escopo e Objetivo; Domínio 2 = Envolvimento dos interessados; Domínio 3 = Rigor do desenvolvimento; Domínio 4 = Clareza da apresentação; Domínio 5 = Aplicabilidade; Domínio 6 = Independência editorial.  
Após essa avaliação inicial, que foi realizada no mês de outubro de 2014, o grupo elaborador das Diretrizes decidiu utilizar, como fontes para a adaptação, as quatro diretrizes mais bem avaliadas, sendo excluídas as duas com piores avaliações. O motivo da exclusão foi porque obtiveram escore menor que 50% na avaliação geral. As duas diretrizes mais bem avaliadas foram escolhidas como referência principal para a adaptação<sup>9,11</sup> , que seriam utilizadas para responder às questões clínicas definidas no escopo. Caso nenhuma das duas diretrizes principais abordasse o tópico, as outras duas escolhidas, por ordem decrescente no ranque da avaliação, seriam utilizadas para buscar a resposta.  
Porém, após a definição dessa metodologia, o National Institute for Health Care and Clinical Excelence  
(NICE) publicou, em dezembro de 2014, a atualização das suas diretrizes de 2007<sup>14</sup> . As diretrizes de 2014 atualizaram vários dos tópicos das diretrizes de 2007, mas não todos, com pesquisa na literatura até fevereiro de 2014. Após essa publicação, as diretrizes de 2014 do NICE passaram a ser a fonte principal para a adaptação desenvolvida pelo Brasil, sendo referidas neste documento como diretrizes do NICE, e as outras ficaram como referência secundária, em caso de necessidade, se alguma das questões do escopo não fossem respondidas pelas diretrizes-fonte principais. Embora tenha obtido excelente escore na avaliação do AGREE, as Diretrizes do NICE apresentam algumas limitações, pois se limita apenas à análise e revisão de estudos publicados em inglês, embora sem limitações quanto ao país onde os estudos foram realizados.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 5.2.2 Avaliação, síntese e classificação das evidências. -->
A avaliação e síntese da evidência seguiram a metodologia das diretrizes do NICE de 2007, segundo a Tabela 2. Na atualização de 2014 das diretrizes do NICE, foi utilizada a metodologia GRADE<sup>15</sup> apenas para os tópicos que foram atualizados, mantendo-se a metodologia utilizada nas diretrizes de 2007 para os demais. O Grupo Elaborador do Brasil, com anuência do painel organizador, decidiu utilizar como referência de avaliação e síntese da evidência, para todo o documento, a metodologia utilizada nas diretrizes do NICE de 2007, mesmo nas questões atualizadas por este em 2014, com o objetivo de deixar mais claro e de mais fácil compreensão a forma de expor a classificação das evidências.  Logo, as evidências classificadas pela metodologia GRADE foram reclassificadas segundo a metodologia anterior. Tabela 2 – Níveis de evidência de estudos de intervenção<sup>14</sup>  
|Nível|Fonte da evidência|
|---|---|
|1++|Meta-análises de alta qualidade, revisões sistemáticas de ensaios randomizados<br>controlados(ERCs)ou ERCs com um risco muito baixo de viéses.|
|1+|Meta-análises bem conduzidas, revisões sitemáticas de ERCs ou ERCs com baixo<br>risco de viéses.|
|1-|Meta-análises,revisões sistemática de ERCs ou ERCs com alto risco de vieses.|
|2++|Revisões sistemáticas de alta qualidade de estudos caso-controle ou de coorte;<br>estudos caso-controle ou de coorte com um risco muito baixo de confusão,<br>viéses ou chance e uma altaprobabilidadeque a relação seja de causa-efeito.|
|2+|Estudos caso-controle ou de coorte bem conduzidos ou estudos de coorte com<br>um baixo risco de confusão, viéses ou chance e probabilidade moderada que a<br>relação seja de causa-efeito.|
|2-|Estudos caso-controle ou de coorte com um alto risco de confusão, viéses ou<br>chance e um risco significativoque a relação não seja de causa-efeito.|
|3|Estudos não analíticos(ex. realtos de casos,séries de casos).|
|4|Opinião de especialistas,consensos formais.|  
Fonte: NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 839 p, Dec. 2014.  
O tipo de questão de revisão determina o nível de evidência mais alto que deve ser procurado. O estudos recebem uma classificação de ‘++’, ‘+’ ou ‘-‘ dependendo da qualidade. Para estudos sobre tratamento ou outras intervenções o mais alto nível possível de evidência (NE) é uma revisão sistemática ou meta-análise bem conduzida de ensaios randomizados controlados (ERCs) (NE = 1++) ou ERC individual (NE = 1+). Estudos de baixa qualidade são classificados com o símbolo ‘-‘ e, a princípio,  
não devem servir de referência para fazer uma recomendação mas podem ser utilizados para informar a recomendação caso não existam outros estudos de maior qualidade. Para questões de prognóstico, a evidência de mais alto nível é uma revisão sistemática ou meta-análise de estudos de coorte (NE = 2++). Os sumários dos resultados dos estudos são apresentados no texto das Diretrizes ou em tabelas, seguindo principalmente a metodologia das diretrizes do NICE de 2014. As variáveis dicotômicas são apresentadas como riscos relativos (RRs) com intervalos de confiança de 95% (IC 95%) e as variáveis contínuas são apresentadas como diferenças médias com intervalos de confiança de 95% ou desvios padrão (DP). As meta-análises baseadas em variáveis dicotômicas são apresentadas como razão de pares agrupada (OR) ou risco relativo agrupado (RRs) e as meta-análises baseadas em variáveis contínuas são apresentadas como diferenças da média ponderada (DMP) com ICs de 95%.  
5.2.3 Considerações sobre utilização de recursos e análises econômicas  
A principal fonte para esta adaptação<sup>14</sup> priorizou alguns tópicos para análise de custo-efetividade e, entre eles, os seguintes fizeram parte do escopo destas Diretrizes adaptadas:  
- Terceiro período do parto: conduta na retenção placentária e  
- assistência ao parto em diferentes locais baseado em uma análise de custo-efetividade realizada no Reino Unido.  
O Grupo Elaborador destas Diretrizes adaptadas levou em consideração as análises realizadas pelos elaboradores das diretrizes inglesas, caso as mesmas se aplicassem ao Brasil, por meio de consenso formal. Outras considerações foram realizadas do ponto de vista da utilização de recursos no Brasil, mas sem a realização de análises econômicas formais. As outras diretrizes-fonte não realizaram análises econômicas de nenhum dos tópicos incluídos nestas Diretrizes. Também não  foram realizadas buscas na literatura brasileira de estudos de análises econômicas das diversas intervenções consideradas.  
5.2.4 Das evidências às recomendações  
As recomendações destas Diretrizes foram formuladas a partir das recomendações das diretrizes-fonte de adaptação, com modificação da linguagem que foi adaptada ao contexto brasileiro, mas relacionando-as explicitamente às evidências que as originaram. Algumas recomendações foram modificadas de acordo com a realidade brasileira, mas mantendo a sua relação com as evidências analisadas nas diretrizes-fonte de adaptação. O motivo das modificações estão detalhados no texto destas Diretrizes. As recomendações iniciais foram decididas através de consenso no Grupo Elaborador. As questões contidas no escopo destas Diretrizes que não foram abordadas por nenhuma das diretrizes consultadas não foram respondidas e ficaram para a etapa de sua atualização. Outras recomendações foram elaboradas baseadas na legislação brasileira, quando aplicável, e por ausência de evidências que justificassem outra recomendação.  
5.2.5 Revisão externa  
Uma versão preliminar destas Diretrizes foi submetida a análise e considerações do Conselho Consultivo, composto por indivíduos e instituições listados no Anexo III. O Conselho Consultivo opinou sobre o texto e principalmente sobre as recomendações, fazendo as modificações necessárias. O texto final da versão preliminar, com suas recomendações, foi aprovado pelo Conselho Consultivo, em oficina realizada em Brasília, a qual contou também com a participação de membros do GED. Após aprovação na oficina foi encaminhado à subcomissão de análise da Subcomissão de PCDT (Protocolos Clínicos e Diretrizes Terapêuticas) da CONITEC, e depois encaminhada à plenária da CONITEC para aprovação. Após aprovação na plenária foi colocada em consulta pública para receber contribuições da sociedade. As contribuições foram analisadas pelo GED e pelo painel organizador e, quando factíveis, estas foram  
incorporadas a estas Diretrizes, desde que mantendo a relação com as evidências contidas nas diretrizes-fonte de adaptação. Após a incorporação das modificações, o texto final foi novamente aprovado em oficina do Conselho Consultivo e na plenária da CONITEC, sendo enviado para publicação. 5.2.6 Desfechos considerados nestas Diretrizes  
Os desfechos primários considerados para análise de impacto das recomendações destas Diretrizes foram a mortalidade materna e perinatal, a morbidade materna e neonatal de curto e longo prazo e a satisfação da mulher. Como desfechos secundários foram considerados os eventos do trabalho de parto e parto (duração do trabalho de parto, intervenções, tipo de parto, complicações do parto, trauma perineal, etc.), os eventos neonatais (condições ao nascer, tocotraumatismo, admissão em unidade neonatal), a saúde mental e as visões das mulheres sobre a experiência de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 5.2.7 Atualização destas Diretrizes -->
Estas Diretrizes sofrerão processo de atualização três anos após sua publicação. Em relação às questões não respondidas, cujos tópicos não foram abordados pelas diretrizes-fonte da adaptação, será realizada uma fase II de elaboração destas Diretrizes, um ano após sua publicação, para a busca na literatura de evidências publicadas em outros idiomas além do inglês, e da literatura latino-americana, incluindo a brasileira. Também será constituído um grupo de monitoramento das evidências e, caso surja uma evidência de qualidade que possa modificar substancialmente qualquer uma das recomendações contidas nestas Diretrizes, uma declaração de modificação será elaborada antes do prazo definido para atualização.  
6 Sumário de recomendações  
Local de assistência ao parto  
1. Informar às gestantes de baixo risco de complicações que o parto normal é geralmente muito seguro tanto para a mulher quanto para a criança.  
2. Informar às gestantes de baixo risco sobre os riscos e benefícios dos locais de parto (domicílio, Centro de Parto Normal extra, peri ou intra hospitalar, maternidade). Utilizar as tabelas 8, 9, 10 e 11 para tal. Informar também que as evidências são oriundas de outros países, e não necessariamente aplicáveis ao Brasil.  
3. As mulheres nulíparas ou multíparas que optarem pelo planejamento do parto em Centro de Parto Normal (extra, peri ou intra-hospitalar), se disponível na sua área de abrangência ou próximos dessa, e cientes dos riscos e benefícios desses locais, devem ser apoiadas em sua decisão.  
4. Informar a todas as gestantes que a assistência ao parto no domicílio não faz parte das políticas atuais de saúde no país.  
5. Informar às nulíparas de baixo risco de complicações que o planejamento do parto no domicílio não é recomendado tendo em vista o maior risco de complicações para a criança. Informar também que as evidências são oriundas de outros países e não necessariamente aplicáveis ao Brasil.  
6. Informar às multíparas de baixo risco de complicações que, tendo em vista o contexto brasileiro, o parto domiciliar não está disponível no sistema de saúde, por isso não há como recomendar. No entanto, não se deve desencorajar o planejamento do parto no domicílio, desde que atenda o item 8.  
7. As mulheres devem receber as seguintes informações sobre o local de parto:  
- Acesso à equipe médica (obstetrícia, anestesiologia e pediatria)  
- Acesso ao cuidado no trabalho de parto e parto por enfermeiras obstétricas ou obstetrizes,  
- Acesso a métodos de alívio da dor, incluindo os não farmacológicos (banheira, chuveiro,  
massagens, etc.), analgesia regional e outras substâncias analgésicas.  
- A probabilidade de ser transferida para uma maternidade (se esse não for o local escolhido), as razões porque isso pode acontecer e o tempo necessário para tal.  
8. Assegurar que todas as mulheres que optarem pelo planejamento do parto fora do hospital tenham acesso em tempo hábil e oportuno a uma maternidade, se houver necessidade de transferência.  
9. Utilizar as tabelas 12, 13, 14 e 15 como instrumentos de avaliação das mulheres em relação à escolha do local do parto:  
- As tabelas 12 e 13 apresentam condições clínicas e situações onde existe um risco aumentado para a mãe e a criança durante ou imediatamente após o parto e a assistência em uma maternidade poderia reduzir este risco.  
- O fatores listados nas tabelas 14 e 15 são razões para aconselhar as mulheres a planejarem o parto em uma maternidade baseada em hospital, mas indica que outras situações sejam levadas em consideração em relação ao local do parto, tendo em vista a proximidade deste local com a maternidade e as preferências da mulher.  
- Discutir os riscos e os cuidados adicionais que podem ser oferecidos em uma maternidade para que as mulheres possam fazer uma escolha informada sobre o local planejado para o parto.  
- Profissional que assiste o parto  
10. A assistência ao parto e nascimento de baixo risco que se mantenha dentro dos limites da normalidade pode ser realizada tanto por médico obstetra quanto por enfermeira obstétrica e obstetriz.  
11. É recomendado que os gestores de saúde proporcionem condições para a implementação de modelo de assistência que inclua a enfermeira obstétrica e obstetriz na assistência ao parto de baixo risco por apresentar vantagens em relação à redução de intervenções e maior satisfação das mulheres.  
Cuidados gerais durante o trabalho de parto  
Informações e comunicação  
12. Mulheres em trabalho de parto devem ser tratadas com respeito, ter acesso às informações baseadas em evidências e serem incluídas na tomada de decisões. Para isso, os profissionais que as atendem deverão estabelecer uma relação íntima com as mesmas, perguntando-lhes sobre seus desejos e expectativas. Devem estar conscientes da importância de sua atitude, do tom de voz e das próprias palavras usadas, bem como a forma como os cuidados são prestados.  
13. Para estabelecer comunicação com a mulher os profissionais devem:  
- Cumprimentar a mulher com um sorriso e uma boa acolhida, se apresentar e explicar o qual o seu papel nos cuidados e indagar sobre as suas necessidades, incluindo como gostaria de ser chamada.  
- Manter uma abordagem calma e confiante, demonstrando à ela que tudo está indo bem.  
- Bater na porta do quarto ou enfermaria e esperar antes de entrar, respeitando aquele local como espaço pessoal da mulher e orientar outras pessoas a fazerem o mesmo.  
- Perguntar à mulher como ela está se sentindo e se alguma coisa em particular a preocupa.  
- Se a mulher tem um plano de parto escrito, ler e discutir com ela, levando-se em consideração as condições para a sua implementação tais como a organização do local de assistência, limitações (físicas, recursos) relativas à unidade e a disponibiidade de certos métodos e técnicas.  
- Verificar se a mulher tem dificuldades para se comunicar da forma proposta, se possui deficiêcia  
auditivia, visual ou intelectual; perguntar qual língua brasileira (português ou libras) prefere utilizar ou, ainda, para o caso de mulheres estrangeiras ou indígenas verificar se compreendem português.  
- Avaliar o que a mulher sabe sobre estratégias de alívio da dor e oferecer informações balanceadas para encontrar quais abordagens são mais aceitáveis para ela.  
- Encorajar a mulher a adaptar o ambiente às suas necessidades.  
- Solicitar permissão à mulher antes de qualquer procedimento e observações, focando nela e não na tecnologia ou documentação.  
- Mostrar à mulher e aos seus acompanhantes como ajudar e assegurar-lhe que ela o pode fazer em qualquer momento e quantas vezes quiser. Quando sair do quarto, avisar quando vai retornar.  
- Envolver a mulher na transferência de cuidados para outro profissional, tanto quando solicitar opinião adicional ou no final de um plantão.  
14. Durante o pré-natal  informar as mulheres sobre os seguintes assuntos:  
- Riscos e benefícios das diversas práticas e intervenções durante o trabalho de parto e parto (uso de ocitocina, jejum, episiotomia, analgesia farmacológica, etc.);  
- A necessidade de escolha de um acompanhante pela mulher para o apoio durante o parto. Este acompanhante deve receber as informações importantes no mesmo momento que a mulher;  
- Estratégias de controle da dor e métodos disponíveis na unidade, descrevendo os riscos e benefícios de cada método (farmacológicos e não farmacológicos);  
- Organização e indicadores assistenciais do local de atenção ao parto, limitações (física, recursos disponíveis) relativos à unidade, bem como disponibilidade de certos métodos e técnicas;  
- Os diferentes estágios do parto e as práticas utilizadas pela equipe para auxiliar as mulheres em escolhas bem informadas.  
Apoio físico e emocional  
15. Todas as parturientes devem ter apoio contínuo e individualizado durante o trabalho de parto e parto, de preferência por pessoal que não seja membro da equipe hospitalar.  
16. O apoio por pessoal de fora da equipe hospitalar não dispensa o apoio oferecido pelo pessoal do hospital.  
17. Uma mulher em trabalho de parto não deve ser deixada sozinha, exceto por curtos períodos de tempo ou por sua solicitação.  
18. As mulheres devem ter acompanhantes de sua escolha durante o trabalho de parto e parto, não invalidando o apoio dado por pessoal de fora da rede social da mulher (ex. doula).  
- Dieta durante o trabalho de parto  
19. Mulheres em trabalho de parto podem ingerir líquidos, de preferência soluções isotônicas ao invés de somente água.  
20. Mulheres em trabalho de parto que não estiverem sob efeito de opióides ou não apresentarem fatores de risco iminente para anestesia geral podem ingerir uma dieta leve.  
21. Os antagonistas H2 e antiácidos não devem ser utilizados de rotina para mulheres de baixo risco para anestesia geral durante o trabalho de parto.  
22. As mulheres que receberem opióides ou apresentarem fatores de risco que aumentem a chance de uma anestesia geral devem receber antagonistas H2 ou antiácidos.  
- Medidas de assepsia para o parto vaginal  
23. A água potável pode ser usada para a limpeza vulvar e perineal se houver necessidade, antes do exame vaginal.  
24. Medidas de higiene, incluindo higiene padrão das mãos e uso de luvas únicas não necessariamente estéreis, são apropriadas para reduzir a contaminação cruzada entre as mulheres, crianças e profissionais.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Avaliação do bem-estar fetal -->
25. A avaliação do bem-estar fetal em parturientes de baixo risco deve ser realizada com ausculta intermitente, em todos os locais de parto:  
- Utilizar estetoscópio de Pinard ou sonar Doppler:  
- Realizar a ausculta antes, durante e imediatamente após uma contração, por pelo menos 1 minuto e a cada 30 minutos, registrando como uma taxa única  
- Registrar acelerações e desacelerações se ouvidas  
- Palpar o pulso materno se alguma anormalidade for suspeitada para diferenciar os batimentos fetais e da mãe.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Alívio da dor no trabalho de parto -->
Experiência e satisfação das mulheres em relação à dor no trabalho de parto  
26. Os profissionais de saúde devem refletir como suas próprias crenças e valores influenciam a sua atitude em lidar com a dor do parto e garantir que os seus cuidados apoiem a escolha da mulher.  
Estratégias e métodos não farmacológicos de alívio da dor no trabalho de parto  
27. Sempre que possível deve ser oferecido à mulher a imersão em água para alívio da dor no trabalho de parto.  
28. Os gestores nacionais e locais devem proporcionar condições para o redesenho das unidades de assistência ao parto visando a oferta da imersão em água para as mulheres no trabalho de parto.  
29. Se uma mulher escolher técnicas de massagem durante o trabalho de parto que tenham sido ensinadas aos seus acompanhantes, ela deve ser apoiada em sua escolha.  
30. Se uma mulher escolher técnicas de relaxamento no trabalho de parto, sua escolha deve ser apoiada.  
31. A injeção de água estéril não deve ser usada para alívio da dor no parto.  
32. A estimulação elétrica transcutânea não deve ser utilizada em mulheres em trabalho de parto estabelecido.  
33. A acupuntura pode ser oferecida às mulheres que desejarem usar essa técnica durante o trabalho de parto, se houver profissional habilitado e disponível para tal.  
34. Apoiar que sejam tocadas as músicas de escolha da mulher durante o trabalho de parto.  
35. A hipnose pode ser oferecida às mulheres que desejarem usar essa técnica durante o trabalho de parto, se houver profissional habilitado para tal.  
36. Por se tratar de intervenções não invasivas e sem descrição de efeitos colaterais, não se deve coibir as mulheres que desejarem usar audio-analgesia e aromaterapia durante o trabalho de parto.  
37. Os métodos não farmacológicos de alívio da dor devem ser oferecidos à mulher antes da utilização de métodos farmacológicos.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Analgesia inalatória -->
38. O óxido nitroso a 50% em veículo específico pode ser oferecido para alívio da dor no trabalho de parto, quando possível e disponível, mas informar às mulheres que elas podem apresentar náusea, tonteiras, vômitos e alteração da memória.  
Analgesia intramuscular e endovenosa  
39. Os opióides não devem ser utilizados de rotina pois os mesmos oferecem alívio limitado da dor e apresentam efeitos colaterais significativos para a mulher (náusea, sonolência e tonteira) e para a criança (depressão respiratória ao nascer e sonolência que pode durar vários dias) assim como interferência negativa no aleitamento materno.  
40. Diante da administração de opióides (EV ou IM) utilizar concomitantemente um anti-emético.  
41. Até duas horas após a administração de opióides (EV ou IM) ou se sentirem sonolentas, as mulheres não devem entrar em  piscina ou banheira.  
42. Analgesia com opióides é acompanhada de aumento na complexidade da assistência ao parto, como por exemplo: maior necessidade de monitorização e acesso venoso.  
43. Uma vez que a segurança da realização de analgesia farmacológica no ambiente extra-hospitalar ainda não foi estabelecida, esta é restrita ao complexo hospitalar, seja bloco cirúrgico ou PPP (sala de pré-parto, parto e pós-parto).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Analgesia regional -->
44. A analgesia regional deve ser previamente discutida com a gestante antes do parto e seus riscos e benefícios devem ser informados.  
45. As seguintes informações devem ser oferecidas à mulher:  
- A analgesia regional só está disponível no ambiente hospitalar  
- É mais eficaz para alívio da dor que os opióides  
- Não está associada com aumento na incidência de dor lombar  
- Não está associada com primeiro período do parto mais longo ou aumento na chance de cesariana  
- Está associada com aumento na duração do segundo período do parto e na chance de parto vaginal instrumental.  
- Necessita de nível mais elevado de monitoração e a mobilidade pode ser reduzida  
46. Uma vez que a segurança da realização de analgesia farmacológica no ambiente extra-hospitalar ainda não foi estabelecida, esta é restrita ao complexo hospitalar, seja bloco cirúrgico ou PPP (sala de pré-parto, parto e pós-parto).  
47. A solicitação materna por analgesia de parto compreende indicação suficiente para sua realização, independente da fase do parto e do grau de dilatação. Isto inclui parturientes em fase latente com dor intensa, após esgotados os métodos não farmacológicos.  
48. A analgesia peridural e a analgesia combinada raqui – peridural (RPC) constituem técnicas igualmente eficazes para alívio da dor de parto. A escolha entre elas será influenciada pela experiência do anestesiologista com a técnica.  
49. Iniciar a analgesia peridural com as substâncias usuais (bupivacaína, ropivacaína e levobupivacaína) diluídas na dose:  volume 13 a 20 ml em concentração de 0,0625% a 0,1%, acrescidos de fentanila (2 mcg/ml), ou opióide lipossolúvel em dose equipotente.  
50. Quando se pretende fornecer alívio rápido da dor, sem elevação da dose de anestésico, a via intratecal é a técnica de escolha.  
51. Quando se utilizar a RPC, adequar a dose ao momento do parto:  
- Fase não avançada do parto (doses próximas a 15 mcg de fentanila intratecal ou outro opióide lipossolúvel em dose equivalente).  
- Fase avançada do parto (bupivacaína 1,25 mg intratecal ou outro anestésico em dose  
equivalente, associada ao opióide lipossolúvel).  
52. A manutenção da analgesia via cateter peridural deve ser iniciada com a menor concentração efetiva de cada anestésico; como exemplo bupivacaína 0,0625% ou ropivacaína 0,1%, ambos acrescidas de fentanila (2 mcg/ml) ou doses equipotentes de outro opióide lipossolúvel.  
53. A manutenção da analgesia via cateter peridural deve ser iniciada com volumes próximos a 10 ml/h.  
54. A manutenção da analgesia via cateter peridural deve ser individualizada, levando em consideração a resposta à solução inicial, assim como particularidades da mulher. Mediante resposta insatisfatória na primeira hora de infusão, deve-se elevar a dose de anestésico, aumentando a taxa de infusão de forma escalonada até no máximo 20 ml/h. Mediante resposta persistentemente insatisfatória devese elevar a concentração do anestésico, após revisar posicionamento do cateter.  
55. A manutenção da analgesia peridural em bolus intermitente ou sob regime de PCA (“analgesia peridural controlada pela paciente”) são os modos preferidos de administração para a manutenção da analgesia peridural.  
56. A utilização de um ou outro modo dependerá da disponibilidade de recursos locais.  
57. Não se recomendam rotineiramente altas concentrações de soluções de anestesia local (0,25% ou acima de bupivacaína ou equivalente) para estabelecer ou manter a analgesia peridural.  
58. Antes da realização da analgesia regional de parto deve haver acesso venoso pré-estabelecido.  
59. Pré-hidratação não deve ser utilizada de forma rotineira mas apenas em casos selecionados.  
60. Toda gestante após analgesia regional deve ser avaliada quanto à ocorrência de hipotensão arterial, sendo a necessidade de hidratação ou suporte com substâncias vasoativas avaliada individualmente.  
61. A manutenção da hidratação deve obedecer a recomendação citada no ítem dieta no trabalho de parto. Convém ressaltar que, em função da administração de opióides, a oferta de dieta com resíduos é proscrita após anestesia regional.  
62. A gestante sob analgesia peridural, quando se sentir confortável e segura, deve ser encorajada a deambular e adotar posições mais verticais.  
63. A administração da solução peridural não deve ser interrompida no intuito de se otimizar desfechos, mas deve obedeçer as necessidades e desejo materno, ainda que no período expulsivo.  
64. O cateter peridural, instalado durante o parto, poderá ser utilizado no terceiro estágio do parto, como por exemplo na reparação perineal.  
65. Após confirmados os 10 cm de dilatação, não se deve incentivar a gestante a realizar puxos, exceto se tardiamente (sugere-se no mínimo após 1 hora de dilatação total) ou quando a cabeça fetal se tornar visível.  
66. Os puxos devem ser sempre durante a contração.  
67. Após constatado 10 cm de dilatação, devem ser estabelecidas estratégias para que o  nascimento ocorra em até 4 horas, independente da paridade.  
68. A administração de ocitocina após analgesia regional não é recomendada de rotina e deve obedecer as recomendações referentes ao uso de  uterotônicos expostas nas seções específicas.  
69. A técnica de analgesia no parto deve visar o controle adequado da dor com o menor comprometimento possível das funções sensoriais, motoras e autonômicas. Para isto a iniciação e manutenção da analgesia com baixas concentrações de anestésico local constitui fator fundamental, particularmente importante para que as parturientes se mantenham em movimento.  
70. Toda gestante submetida a analgesia de parto deverá estar com monitorização básica previamente instalada (Pressão Arterial Não Invasiva - PANI a cada 5 minutos e oximetria de pulso).  
71. Estando sob monitoriação, após 15 minutos da administração do(s) agente(s), a gestante deverá ser avaliada quanto à resposta (nível do bloqueio, sensibilidade perineal, testes de função motora , teste do equilíbrio e de hipotensão postural). Caso a avaliação seja desfavorável à mobilização ou se constate “estado de anestesia”  (hiposensibilidade e bloqueio motor) a gestante deverá permanecer no leito sob vigilância constante até nova reavaliação. Caso a avaliação seja favorável, somente “estado de analgesia“, a gestante estará sem impedimentos para deambular e assumir a posição que desejar.  
72. Caso a avaliação seja desfavorável à mobilização ou se constate estado de anestesia (hiposensibilidade e bloqueio motor), os quais persistem mesmo após o terceiro estágio, a gestante deverá ser encaminhada a SRPA (Sala de Recuperação Pós-Anestésica) e permanecer no leito sob vigilância constante até alta pelo médico anestesiologista.  
73. A rotina de monitoração para iniciação da analgesia de parto deve ser repetida nos momentos de doses de resgate via cateter peridural.  
74. Se após 30 minutos do início da analgesia ou dose de resgate for constatada inefetividade, o anestesiologista deverá considerar falha técnica ou revisar individualmente as necessidades de alívio da parturiente.  
75. Uma vez realizada analgesia de parto, ainda que não ocorram doses de resgate, o anestesiologista deverá acompanhar a parturiente, com avaliação horária, até o terceiro período.  
76. Considerando a possibilidade de complicações, todo cateter peridural deve ser retirado pelo médico anestesiologista. A gestante não poderá receber alta do bloco obstétrico, unidade PPP ou SRPA com cateter instalado, exceto com a autorização do anestesiologista.  
77. Toda parturiente submetida a início de analgesia regional ou doses adiconais de resgate, seja qual for a técnica, deve ser submetida a ausculta intermitente da FCF de 5 em 5 minutos por no mínimo 30 minutos. Uma vez alterado deve-se instalar CTG, assim como proceder a cuidados habituais como decúbito lateral esquerdo e avaliar necessidade de otimização das condições respiratórias e circulatórias. Caso não ocorra melhora, seguir diretrizes próprias para conduta no estado fetal não tranquilizador.  
78. Se ocorrerem anormalidades graves da FCF, não transitórias, considerar outra causa que não analgesia regional e seguir diretrizes próprias para conduta no estado fetal não tranquilizador.  
Ruptura prematura de membranas (RPM) no termo  
79. Não realizar exame especular se o diagnóstico de ruptura das membranas for evidente.  
80. Se houver dúvida em relação ao diagnóstico de ruptura das membranas realizar um exame especular. Evitar toque vaginal na ausência de contrações.  
81. Explicar às mulheres com ruptura precoce de membranas no termo que:  
- o risco de infecção neonatal grave é de 1%, comparado com 0,5% para mulheres com membranas intactas.  
- 60% das mulheres com ruptura precoce de membranas no termo entrará em trabalho de parto dentro de 24 horas.  
- a indução do trabalho de parto é apropriada dentro das 24 horas após a ruptura precoce das membranas.  
82. Até que a indução do trabalho de parto seja iniciada ou se a conduta expectante for escolhida pela gestante para além de 24 horas:  
- Aconselhar a mulher a aguardar em ambiente hospitalar  
- Medir a temperatura a cada 4 horas durante o período de observação e observar qualquer alteração na cor ou cheiro das perdas vaginais.  
- Se a mulher optar por aguardar no domicílio manter as mesmas recomendações anteriores e informá-la que tomar banho não está associado com um aumento da infecção, mas ter relações sexuais pode estar.  
83. Avaliar a movimentação fetal e a frequência cardíaca fetal na consulta inicial e depois a cada 24 horas após a ruptura precoce das membranas, enquanto a mulher não entrar em trabalho de parto, e aconselhá-la a comunicar imediatamente qualquer diminuição nos movimentos fetais.  
84. Se o trabalho de parto não se iniciar dentro de 24 horas após a ruptura precoce das membranas, a mulher deve ser aconselhada a ter o parto em uma maternidade baseada em hospital, com serviço de neonatologia.  
Eliminação de mecônio imediatamente antes ou durante o trabalho de parto  
85. Não se aconselha o uso de sistemas de gradação e classificação de mecônio para a condura na eliminação de mecônio imediatamente antes ou durante o trabalho de parto, exceto quando se considerar a amnioinfusão ou como critério de transferência. Ver recomendações 87, 96 e 97;  
86. Tanto a monitoração eletrônica contínua da frequência cardíaca fetal, se disponível, como a ausculta fetal intermitente, seguindo técnicas padronizadas, podem ser utilizadas para avaliação do bemestar fetal diante da eliminação de mecônio durante o trabalho de parto;  
87. Considerar a realização de amnioinfusão diante da eliminação de mecônio moderado a espesso durante o trabalho de parto se não houver disponibilidade de monitoração eletrônica fetal contínua;  
88. Não existem evidências para recomendar ou não recomendar a cesariana apenas pela eliminação isolada de mecônio durante o trabalho de parto.  
Assistência no primeiro período do parto  
Diagnóstico do início do trabalho de parto e momento de admissão para assistência ou início da  
assistência no domicílio  
89. Incluir o seguinte quando da avaliação precoce ou triagem de trabalho de parto em qualquer local de assistência:  
- Indagar à mulher como ela está e sobre os seus desejos, expectativas e preocupações.  
- Indagar sobre os movimentos da criança, incluindo qualquer mudança nos mesmos.  
- Oferecer informações sobre o que a mulher pode esperar na fase de latência do trabalho de parto e o que fazer se sentir dor.  
- Oferecer informações sobre o que esperar quando procurar assistência.  
- Estabelecer um plano de cuidados com a mulher, incluindo orientação de quando e  com quem contatar posteriormente.  
- Oferecer orientação e apoio para o(s) acompanhante(s) da mulher.  
90. Se uma mulher busca orientação ou assistência em uma maternidade ou unidade de parto extra, peri ou intra-hospitalar:  
- E não está em trabalho de parto estabelecido (≤ 3 cm de dilatação cervical):  
- Ter em mente que a mulher pode estar tendo contrações dolorosas, sem mudanças cervicais, e embora ainda não esteja em trabalho de parto ativo, ela pode sentir que está pela sua própria definição.  
- Oferecer apoio individual e alívio da dor se necessário.  
- Encorajar e aconselhar a mulher a permanecer ou retornar para casa, levando em  
consideração as suas preocupações, a distância entre a sua casa e o local do parto e o risco deste acontecer sem assistência.  
- Está em trabalho de parto estabelecido (≥ 4 cm de dilatação cervical)  
- Admitir para assistência  
Definição e duração das fases do primeiro período do trabalho de parto  
91. Para fins destas Diretrizes, utilizar as seguintes definições de trabalho de parto:  
- Fase de latência do primeiro período do trabalho de parto – um período não necessariamente contínuo quando:  
- há contrações uterinas dolorosas E  
`o` há alguma modificação cervical, incluindo apagamento e dilatação até 4 cm.  
- Trabalho de parto estabelecido – quando:  
- há contrações uterinas regulares E  
`o` há dilatação cervical progressiva a partir dos 4 cm.  
92. A duração do trabalho de parto ativo pode variar:  
- Nas primíparas dura em média 8 horas e é pouco provável que dure mais que 18 horas.  
- Nas multíparas dura em média 5 horas e é pouco provável que dure mais que 12 horas.  
- Observações e monitoração no primeiro período do parto  
93. Registrar as seguintes observações no primeiro período do trabalho de parto:  
- Frequência das contrações uterinas de 1 em 1 hora  
- Pulso de 1 em 1 hora  
- Temperatura e PA de 4 em 4 horas  
- Frequência da diurese  
- Exame vaginal de 4 em 4 horas ou se houver alguma preocupação com o progresso do parto ou em resposta aos desejos da mulher (após palpação abdominal e avaliação de perdas vaginais).  
94. Um partograma com linha de ação de 4 horas deve ser utilizado para o registro do progresso do parto, modelo da OMS ou equivalente.  
95. Transferir a mulher para uma maternidade baseada em hospital ou solicitar assistência de médico obstetra, se o mesmo não for o profissional assistente, se qualquer uma das seguintes condições forem atingidas, a não ser que os riscos da transferência supere os benefícios.  
- Observações da mulher:  
- Pulso >120 bpm em 2 ocasiões com 30 minutos de intervalo  
- PA sistólica ≥ 160 mmHg OU PA diastólica ≥ 110 mmHg em uma única medida  
- PA sistólica ≥ 140 mmHg OU diastólica ≥ 90 mmHg em 2 medidas consecutivas com 30 minutos de intervalo  
- Proteinúria de fita 2++ ou mais E uma única medida de PA sistólica ≥ 140 mmHg ou diastólica ≥ 90 mmHg  
- Temperatura de 38°C ou mais em uma única medida OU 37,5°C ou mais em 2 ocasiões consecutivas com 1 hora de intervalo  
- Qualquer sangramento vaginal, exceto eliminação de tampão  
- Presença de mecônio significativo  
- Dor relatada pela mulher que difere da dor normalmente associada às contrações  
- Progresso lento confirmado do primeiro e segundo períodos do trabalho de parto  
- Solicitação da mulher de alívio da dor por analgesia regional  
- Emergência obstétrica – incluindo hemorragia anteparto, prolapso de cordão, convulsão ou colapso materno ou necessidade de ressuscitação neonatal avançada.  
- Observações fetais:  
- Qualquer apresentação anômala, incluindo apresentação de cordão  
- Situação transversa ou oblíqua  
- Apresentação cefálica alta (-3/3 De Lee) ou móvel em uma nulípara  
- Suspeita de restrição de crescimento intra-uterino ou macrossomia  
- Suspeita de anidrâmnio ou polihidrâmnio  
- Frequência cardíaca fetal (FCF) < 110 ou > 160 bpm  
- Desacelerações da FCF à ausculta intermitente.  
96. Se mecônio significativo (verde escuro ou preto, grosso, tenaz, contendo grumos) estiver presente assegurar que:  
- Profissionais treinados em suporte avançado de vida neonatal estejam presentes no momento do parto  
97. Se mecônio significativo estiver presente, transferir a mulher para uma maternidade baseada em hospital de forma segura desde que seja improvável que o parto ocorra antes da transferência se completar.  
Intervenções e medidas de rotina no primeiro período do parto  
98. O enema não deve ser realizado de forma rotineira durante o trabalho de parto  
99. A tricotomia pubiana e perineal não deve ser realizada de forma rotineira durante o trabalho de parto  
100. A amniotomia precoce, associada ou não à ocitocina, não deve ser realizada de rotina em mulheres em trabalho de parto que estejam progredindo bem.  
101. As mulheres devem ser encorajadas a se movimentarem e adotarem as posições que lhes sejam mais confortáveis no trabalho de parto.  
Falha de progresso no primeiro período do trabalho de parto  
102. Se houver suspeita de falha de progresso no primeiro estágio do trabalho de parto levar em consideração:  
- O ambiente onde a mulher está sendo assistida  
- A atitude da mulher, se postura mais ativa ou não  
- estado emocional da mulher  
- O tipo de apoio e suporte físico e emocional que a mulher estiver recebendo  
- Paridade  
- Dilatação e mudanças cervicais  
- Contrações uterinas  
- Altura e posição da apresentação  
- Necessidade de referência ou solicitação de assistência profissional apropriada.  
103. Se houver suspeita de falha de progresso na fase ativa do trabalho de parto considerar também para o diagnóstico todos os aspectos da evolução do trabalho de parto , incluindo:  
- dilatação cervical menor que 2 cm em 4 horas para as primíparas  
- dilatação cervical menor que 2 cm em  4 horas ou um progresso lento do trabalho de parto para as multíparas  
- descida e rotação do pólo cefálico  
- mudanças na intensidade, duração e frequência das contrações uterinas.  
104. Diante da suspeita de falha de progresso no primeiro estágio do trabalho de parto, considerar a realização de amniotomia se as membranas estiverem íntegras. Explicar o procedimento e avisar que o mesmo irá diminuir o trabalho de parto por cerca de 1 hora e pode aumentar a intensidade e dor das contrações.  
105. Se a amniotomia for ou não realizada, realizar um exame vaginal após 2 horas e confirmar falha de progresso se a dilatação progredir menos que 1 cm.  
106. Se for confirmada falha de progresso no primeiro estágio do parto:  
- A mulher deve ser transferida para assistência sob responsabilidade de médico obstetra se não estiver sob seus cuidados. O mesmo deverá realizar uma revisão e diagnosticar a falha de progresso e decidir sobre as opções de conduta, incluindo o uso de ocitocina.  
- Explicar que o uso de ocitocina após a ruptura das membranas irá diminuir o tempo para o parto mas não influenciará no tipo de parto ou outros desfechos.  
107. Se as membranas estiverem íntegras e o diagnóstico de falha de progresso for confirmado, aconselhar à mulher a ser submetida a uma amniotomia e repetir o exame vaginal 2 horas após, independente do estado das membranas.  
108. Oferecer apoio e controle efetivo da dor a todas as mulheres com falha de progresso no primeiro estágio do trabalho de parto.  
109. Informar às mulheres que a ocitocina irá aumentar a freqüência e intensidade das contrações e que a criança deverá ser monitorada continuamente ou com mais freqüência.  
110. Oferecer analgesia peridural, se disponível, se for indicado o uso de ocitocina.  
111. Se a ocitocina for utilizada assegurar que os incrementos na dose não sejam mais frequentes do que a cada 30 minutos. Aumentar a dose de ocitocina até haver 4-5 contrações em 10 minutos.  
112. Realizar exame vaginal 4 horas após o início da ocitocina:  
- Se a dilatação cervical aumentou menos que 2 cm após 4 horas, uma revisão obstétrica adicional deve ser realizada para avaliar a necessidade de cesariana.  
- Se a dilatação cervical aumentou 2 cm ou mais após 4 horas, continuar observação do progresso do parto.  
Assistência no segundo período do parto  
Ambiente de assistência, posições e imersão em água  
113. Deve-se desencorajar a mulher a ficar em posição supina, decúbito dorsal horizontal, ou posição semi-supina no segundo período do trabalho de parto. A mulher deve ser incentivada a adotar qualquer outra posição que ela achar mais confortável incluindo as posições de cócoras, lateral ou quatro apoios  
114. Informar às mulheres que há insuficiência de evidências de alta qualidade, tanto para apoiar como para desencorajar o parto na água.  
Puxos e manobra de Kristeller  
115. Deve-se apoiar a realização de puxos espontâneos no segundo período do trabalho de parto em mulheres sem analgesia, evitando os puxos dirigidos.  
116. Caso o puxo espontâneo seja ineficaz ou se solicitado pela mulher, deve-se oferecer outras estratégias para auxiliar o nascimento, tais como suporte, mudança de posição, esvaziamento da bexiga e encorajamento.  
117. Em mulheres com analgesia regional, após a confirmação da dilatação cervical completa, o puxo  
deve ser adiado por pelo menos 1 hora ou mais, se a mulher o desejar, exceto se a mulher quiser realizar o puxo ou a cabeça do bebê estiver visível. Após 1 hora a mulher deve ser incentivada ativamente para realizar o puxo durante as contrações.  
118. A manobra de Kristeller não deve ser realizada no segundo período do trabalho de parto. Definição e duração do segundo período do trabalho de parto  
119. Para fins destas Diretrizes, o segundo período do parto deverá ser definido como:  
- Fase inicial ou passiva: dilatação total do colo sem sensação de puxo involuntário ou parturiente com analgesia e a cabeça do feto ainda relativamente alta na pelve.  
- Fase ativa: dilatação total do colo, cabeça do bebê visível, contrações de expulsão ou esforço materno ativo após a confirmação da dilatação completa do colo do útero na ausência das contrações de expulsão.  
120. Se a dilatação completa do colo uterino for confirmada em uma mulher sem analgesia regional e não for identificado puxo, uma nova avaliação mais aprofundada deverá ser realizada em 1 hora para identificação da fase do segundo período.  
121. A distribuição dos limites de tempo encontrados nos estudos para a duração normal da fase ativa do segundo período do trabalho parto é a seguinte:  
- Primíparas:  cerca de 0,5–2,5 horas sem peridural e 1–3 horas com peridural.  
- Multíparas:  até 1 hora sem peridural e 2 horas com peridural.  
122. Para a conduta na falha de progresso do segundo período deve-se considerar a paridade, da seguinte maneira:  
- Nulíparas:  
- Na maioria das mulheres o parto deve ocorrer no prazo de 3 horas após o início da fase ativa do segundo período.  
- A confirmação de falha de progresso no segundo período deve ser feita quando este durar mais de 2 horas e a mulher deve ser encaminhada, ou assistência adicional solicitada, a médico treinado na realização de parto vaginal operatório se o nascimento não for iminente.  
- Multíparas:  
- Na maioria das mulheres o parto deve ocorrer no prazo de 2 horas após o início da fase ativa do segundo período.  
- A confirmação de falha de progresso no segundo período deve ser feita quando este durar mais de 1 hora e a mulher deve ser encaminhada, ou assistência adicional solicitada, a médico treinado na realização de parto vaginal operatório se o nascimento não for iminente.  
Falha de progresso no segundo período do parto  
123. Se houver prolongamento do segundo período do trabalho de parto, ou se a mulher estiver excessivamente estressada, promover medidas de apoio e encorajamento e avaliar a necessidade de analgesia/anestesia.  
124. Se as contrações forem inadequadas no início do segundo período, considerar o uso de ocitocina e realização de analgesia regional.  
125. Para as nulíparas, suspeitar de prolongamento se o progresso (em termos de rotação ou descida da apresentação) não for adequado após 1 hora de segundo período ativo. Realizar amniotomia se as membranas estiverem intactas.  
126. Para as multíparas, suspeitar de prolongamento se o progresso (em termos de rotação ou descida da apresentação) não for adequado após 30 minutos de segundo estágio ativo. Realizar amniotomia se as membranas estiverem intactas.  
127. Um médico obstetra deve avaliar a mulher com prolongamento confirmado do segundo período do parto antes do uso de ocitocina.  
128. Após a avaliação obstétrica inicial, manter a revisão a cada 15-30 minutos.  
129. Considerar o uso de parto instrumental (vácuo-extrator ou fórceps) se não houver segurança quanto ao bem estar fetal ou prolongamento do segundo período.  
130. Reconhecer que, em algumas ocasiões, a necessidade de ajuda por parte da mulher no segundo estágio pode ser uma indicação para o parto vaginal assistido quando o apoio falhar.  
131. A escolha do instrumento para o parto instrumental dependerá das circunstâncias clínicas e da experiência do profissional.  
132. Por ser um procedimento operatório, uma anestesia efetiva deve ser oferecida para a realização de um parto vaginal instrumental.  
133. Se a mulher recusar anestesia ou a mesma não estiver disponível, realizar um bloqueio de pudendo combinado com anestesia local do períneo durante o parto instrumental.  
134. Mesmo se houver preocupação com o bem-estar fetal, uma anestesia efetiva pode ser realizada mas, se o tempo não permitir, realizar um bloqueio de pudendo combinado com anestesia local do períneo durante o parto instrumental.  
135. Orientar a mulher e realizar uma cesariana se o parto vaginal não for possível. Cuidados com o períneo  
136. Não se recomenda a massagem perineal durante o segundo período do parto.  
137. Considerar aplicação de compressas mornas no períneo no segundo período do parto.  
138. Não se recomenda a aplicação de spray de lidocaína para reduzir a dor perineal no segundo período do parto.  
139. Tanto a técnica de ‘mãos sobre’ (proteger o períneo e flexionar a cabeça fetal) quanto a técnica de ‘mãos prontas’ (com as mãos sem tocar o períneo e a cabeça fetal, mas preparadas para tal) podem ser utilizadas para facilitar o parto espontâneo.  
140. Se a técnica de ‘mãos sobre’ for utilizada, controlar a deflexão da cabeça e orientar à mulher para não empurrar nesse momento.  
141. Não realizar episiotomia de rotina durante o parto vaginal espontâneo.  
142. Se uma episiotomia for realizada, a sua indicação deve ser justificada, recomendando-se a médio-lateral originando na fúrcula vaginal e direcionada para o lado direito, com um ângulo do eixo vertical entre 45 e 60 graus.  
143. Assegurar analgesia efetiva antes da realização de uma episiotomia. Assistência no terceiro período do parto  
144. Reconhecer que o período imediatamente após o nascimento é um período bastante sensível, quando a mulher e seus acompanhantes vão finalmente conhecer a criança. Assegurar que a assistência e qualquer intervenção que for realizada levem em consideração esse momento, no sentido de minimizar a separação entre mãe e filho.  
145. Para efeito destas Diretrizes, utilizar as seguintes definições:  
- O terceiro período do parto é o momento desde o nascimento da criança até a expulsão da placenta e membranas.  
- A conduta ativa no terceiro período envolve um conjunto de intervenções com os seguintes componentes:  
- uso rotineiro de substâncias uterotônicas;  
- clampeamento e secção precoce do cordão umbilical; e  
- tração controlada do cordão após sinais de separação placentária.  
- A conduta fisiológica no terceiro período do parto envolve um conjunto de cuidados que inclui os seguintes componentes:  
- sem uso rotineiro de uterotônicos  
- clampemento do cordão após parar a pulsação  
- expulsão da placenta por esforço materno  
146. Considerar terceiro período prolongado após decorridos 30 minutos. Seguir recomendações 164172 no caso de placenta retida.  
147. Manter observação rigorosa da mulher, com as seguintes avaliações:  
- condição física geral, através da coloração de pele e mucosas, respiração e sensação de bemestar;  
- perda sanguínea  
148. Se houver hemorragia, retenção placentária, colapso materno ou qualquer outra preocupação quanto ao bem-estar da mulher:  
- solicitar assistência de médico obstetra para assumir o caso se este não for o profissional assistente no momento;  
- instalar acesso venoso calibroso e informar a puérpera sobre a situação e os procedimentos previstos;  
- se o parto ocorreu em domicilio ou unidade de parto extra ou peri-hospitalar, a puérpera deve ser transferida imediatamente para uma maternidade baseada em hospital.  
149. Explicar à mulher, antes do parto, as opções de conduta no terceiro período, com os riscos e benefícios de cada uma.  
150. Explicar à mulher que a conduta ativa:  
- encurta o terceiro período em comparação com a conduta fisiológica;  
- está associado a náusea e vômitos em cerca de 100 mulheres em 1.000;  
- está associado com um risco aproximado de 13 mulheres em 1.000 de uma hemorragia de mais de 1 litro; e  
- está associada com um risco aproximado de 14 em 1.000 de uma transfusão de sangue.  
151. Explicar à mulher que a conduta fisiológica:  
- está associada a náusea e vômitos em cerca de 50 mulheres em 1.000;  
- está associada com um risco aproximado de 29 mulheres em 1.000 de uma hemorragia de mais de 1 litro; e  
- está associada com um risco aproximado de 40 mulheres em 1.000 de uma transfusão de sangue.  
152. A conduta ativa é recomendada na assistência ao terceiro período do parto pois está associado com menor risco de hemorragia e transfusão sanguínea.  
153. Se uma mulher com baixo risco de hemorragia pós-parto solicitar conduta expectante,  apoiá-la em sua escolha.  
154. Para a conduta ativa, administrar 10 UI de ocitocina intramuscular após o desprendimento da  
criança, antes do clampeamento e corte do cordão. A ocitocina é preferível, pois está associada com menos efeitos colaterais do que a ocitocina associada à ergometrina.  
155. Após a administração de ocitocina, pinçar e seccionar o cordão.  
- Não realizar a secção do cordão antes de 1 minuto após o nascimento, a menos que haja necessidade de manobras de ressuscitação neonatal.  
- Pinçar o cordão antes de 5 minutos após o nascimento para realizar a tração controlada do cordão como parte da conduta ativa.  
- Se uma mulher solicitar o clampeamento e secção do cordão após 5 minutos, apoiá-la em sua escolha.  
156. Após a secção do cordão realizar tração controlada do mesmo.  
157. A tração controlada do cordão, como parte da conduta ativa, só deve ser realizada após administração de ocitocina e sinais de separação da placenta.  
158. Documentar o momento do clampeamento do cordão tanto na conduta ativa quanto na conduta expectante.  
159. Mudar da conduta expectante para a conduta ativa se ocorrer:  
- Hemorragia  
- A placenta não dequitou 1 hora após o parto  
160. Oferecer a conduta ativa, quando a mulher prefere encurtar o terceiro estágio do trabalho de parto.  
161. Não usar injeção de ocitocina na veia umbilical rotineiramente.  
162. As mulheres que apresentarem fatores de risco para hemorragia pós-parto devem ser orientadas a ter o parto em uma maternidade baseada em hospital, onde existem mais opções de tratamentos emergenciais;  
163. Se uma mulher apresentar fatores de risco para hemorragia pós-parto, isso deve ser registrado no seu prontuário e cartão de pré-natal, para que um plano de assistência no terceiro período do parto seja realizado.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Retenção placentária -->
164. Explicar para a mulher o que está acontecendo e quais serão os procedimentos necessários  
165. Providenciar um acesso venoso calibroso.  
166. Não usar Ocitocina IV adicional de rotina para desprendimento da placenta.  
167. Usar Ocitocina IV adicional de rotina para desprendimento da placenta, se houver hemorragia.  
168. Realizar exame vaginal minucioso. Oferecer analgesia para este procedimento e providenciar, se a mulher demandar.  
169. Providenciar transferência antes da exploração uterina, se o parto ocorreu em uma modalidade extra-hospitalar.  
170. Não realizar remoção manual ou cirúrgica sem analgesia adequada. Cuidados maternos imediatamente após o parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Observação e monitoração da mulher imediatamente após o parto -->
171. Realizar as seguintes observações da mulher logo após o parto:  
- Temperatura, pulso e pressão arterial.  
- Lóquios e contrações uterinas uterinas.  
- Examinar a placenta e membranas: avaliar suas condições, estrutura, integridade e vasos umbilicais.  
- Avaliação precoce das condições emocionais da mulher em resposta ao trabalho de parto e parto.  
- Micção bem sucedida.  
- Transferir a mulher ou solicitar assistência de médico obstetra, se este não for o profissional responsável, se qualquer das seguintes situações forem atingidas, a não ser que os riscos da transferência superem os benefícios:  
- Pulso >120 bpm em 2 ocasiões com 30 minutos de intervalo  
- PA sistólica ≥ 160 mmHg OU PA diastólica ≥ 110 mmHg em uma única medida  
- PA sistólica ≥ 140 mmHg OU diastólica ≥ 90 mmHg em 2 medidas consecutivas com 30 minutos de intervalo  
- Proteinúria de fita 2++ ou mais E uma única medida de PA sistólica ≥ 140 mmHg ou diastólica ≥ 90 mmHg  
- Temperatura de 38°C ou mais em uma única medida OU 37,5°C ou mais em 2 ocasiões consecutivas com 1 hora de intervalo  
- Bexiga palpável e ausência de micção  6 horas após o parto  
- Emergência obstétrica – hemorragia pós-parto, convulsão ou colapso materno  
- Placenta retida ou incompleta  
- Lacerações perineais de terceiro e quarto graus ou outro trauma perineal complicado  
- Cuidados com o períneo  
172. O trauma perineal ou genital deve ser definido como aquele provocado por episiotomia ou lacerações, da seguinte maneira:  
- Primeiro grau – lesão apenas da pele e mucosas  
- Segundo grau – lesão dos músculos perineais sem atingir o esfínciter anal  
- Terceiro grau – lesão do períneo envolvendo o complexo do esfíncter anal:  
- 3a – laceração de menos de 50% da espessura do esfíncter anal  
- 3b – laceração de mais de 50% da espessura do esfíncter anal  
- 3c – laceração do esfíncter  anal interno.  
- Quarto grau – lesão do períneo envolvendo o complexo do esfíncter anal  (esfíncter anal interno e externo) e o epitélio anal.  
173. Antes de avaliar o trauma genital:  
- Explicar à mulher o que será realizado e porque  
- Ofereça analgesia adequada  
- Assegurar boa iluminação  
- Posicionar a mulher de maneira confortável e com boa exposição das estruturas genitais  
174. Realizar o exame inicial de maneira gentil e sensível. Isto pode ser feito imediatamente após o parto.  
175. Se for identificado trauma perineal, uma avaliação sistemática do mesmo deve ser realizada.  
176. Na avaliação sistemática do trauma genital:  
- Explicar novamente o que será realizado e porque  
- Providenciar analgesia local ou regional efetiva  
- Avaliar visualmente toda a extensão do trauma, incluindo as estruturas envolvidas, o ápice da lesão e o sangramento  
- Na suspeita de qualquer lesão da musculatura perineal, realizar exame retal para verificar se  
ocorreu algum dano ao esfíncter anal externo e interno  
177. Assegurar que o momento para essa avaliação sistemática não interfira na relação mãe-filho exceto se houver sangramento que requeira medidas de urgência.  
178. Ajudar a mulher a adotar uma posição que permita uma visualização adequada do grau do trauma e para o reparo. Manter essa posição apenas pelo tempo necessário para a avaliação sistemática e reparo do períneo. Se não for possível uma avaliação adequada do trauma, a mulher deverá ser assistida por médico obstetra, se esse não for o profissional que assistiu o parto. Se o parto ocorreu fora do hospital, a mesma deverá ser transferida para uma maternidade baseada em hospital.  
179. Solicitar avaliação de um profissional mais experiente se houver incerteza quanto à natureza e extensão do trauma. Transferir a mulher (com a criança) para uma maternidade baseada em hospital, se o parto ocorreu fora da mesma e se o reparo necessitar de avaliação cirúrgica ou anestésica especializada.  
180. Documentar a avaliação sitemática e os seus resultados.  
181. Tanto as enfermeiras obstétricas ou obstetrizes assim como os médicos obstetras envolvidos na assistência ao parto devem estar adequadamente treinados na avaliação e reparo do trauma genital, certificando-se que essas habilidades sejam mantidas.  
182. Aconselhar a mulher que, no caso de trauma de primeiro grau, a ferida deve ser suturada, a fim de melhorar a cicatrização, a menos que as bordas da pele estejam bem apostas.  
183. Aconselhar a mulher que, no caso de um trauma de segundo grau, o músculo deve ser suturado, a fim de melhorar a cicatrização.  
184. Durante o reparo perineal:  
- Assegurar analgesia efetiva com a infiltração de até 20 ml de lidocaína 1% ou equivalente ou  
- Realizar nova dose de anestéscio peridural se a mulher estiver com catéter, ou realizar uma anestesia espinhal  
185. Se a mulher relatar alívio inadequado da dor a qualquer momento, levar isso em consideração imediatamente e providenciar método mais eficaz de alívio.  
186. Não há necessidade de sutura da pele se as suas bordas se apõem após a sutura do músculo, em trauma de segundo grau ou episiotomia.  
187. Se houver necessidade de sutura da pele, utilizar uma técnica subcutânea contínua .  
188. Realizar a reparação perineal usando uma técnica de sutura contínua para a camada de parede vaginal e músculo.  
189. Recomenda-se a utilização de material de sutura sintética absorvível para suturar o períneo.  
190. Observar os princípios básicos seguintes ao realizar reparos perineais  
- Realize a reparação do trauma perineal utilizando técnicas assépticas.  
- Verifique os equipamentos e conte as compressas, gazes e agulhas antes e depois do procedimento.  
- Uma boa iluminação é essencial para identificar as estruturas envolvidas.  
- O trauma de difícil reparação deve ser reparado por um médico experiente sob anestesia local ou geral.  
- Inserir um cateter vesical permanente por 24 horas para evitar retenção urinária.  
- Certifique-se de que um bom alinhamento anatômico da ferida foi alcançado e que se dê atenção aos resultados estéticos.  
- Realizar exame retal após a conclusão do reparo em casos de trauma de difícil abordagem ou de 3<sup>o</sup> ou 4<sup>o</sup> graus, para garantir que o material de sutura não foi acidentalmente inserido através  da mucosa retal.  
- Após a conclusão do reparo, documentar detalhadamente a extensão do trauma, o método de reparação e os materiais usados.  
- Dar a informação à mulher sobre a extensão do trauma, o alívio da dor, dieta, higiene e a importância dos exercícios do assoalho pélvico.  
191. Recomenda-se oferecer supositórios retais de anti-inflamatórios não esteróides rotineiramente após o reparo do trauma perineal de primeiro e de segundo grau, desde que esses medicamentos não sejam contraindicados.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Assistência ao recém-nascido -->
Assistência imediatamente após o parto  
192. O atendimento ao recém-nascido consiste na assistência por profissional capacitado, médico (preferencialmente pediatra ou neonatologista) ou profissional de enfermagem (preferencialmente enfermeiro obstétrico/obstetriz ou neonatal), desde o período imediatamente anterior ao parto, até que o RN seja encaminhado ao Alojamento Conjunto com sua mãe, ou à Unidade Neonatal ou ainda, no caso de nascimento em quarto de pré-parto parto e puerpério (PPP) seja mantido junto à sua mãe, sob supervisão da própria equipe profissional responsável pelo PPP.  
193. É recomendada a presença de um médico pediatra adequadamente treinado em todos os passos da reanimação neonatal.  
194. Em situações onde não é possível a presença de um médico pediatra, é recomendada a presença de um profissional médico ou de enfermagem adequadamente treinado em reanimação neonatal.  
195. Os estabelecimentos de saúde que mantenham profissional de enfermagem habilitado em reanimação neonatal no momento do parto, deverá possuir em sua equipe de retaguarda, durante 24 horas, ao menos um médico que tenha realizado treinamento teórico-prático em reanimação neonatal.  
196. Realizar o índice de Apgar ao primeiro e quinto minutos de vida, rotineiramente 197. Coletar sangue de cordão para análise de pH em recém-nascidos com alterações clínicas tais como respiração irregular e tônus diminuído. Não fazer a coleta de maneira rotineira e universal.  
198. Não se recomenda a aspiração orofaringeana e nem nasofaringeana sistemática do recémnascido saudável.  
199. Não se recomenda realizar a passagem sistemática de sonda nasogástrica e nem retal para descartar atresias no recém-nascido saudável.  
200. Realizar o clampeamento  do cordão umbilical entre 1 a 5 minutos ou de forma fisiológica quando cessar a pulsação, exceto se houver alguma contra indicação em relação ao cordão ou necessidade de reanimação neonatal .  
201. A profilaxia da oftalmia neonatal deve ser realizada de rotina nos cuidados com o recém-nascido. 202. O tempo de administração da profilaxia da oftalmia neonatal pode ser ampliado em até 4 horas após o nascimento.  
203. Recomenda-se a utilização da pomada de eritromicina a 0,5% e, como alternativa, tetraciclina a 1% para realização da profilaxia da oftalmia neonatal. A utilização de nitrato de prata a 1% deve ser reservado apenas em caso de não se dispor de eritromicina ou tetraciclina.  
204. Todos os recém-nascidos devem receber vitamina K para a profilaxia da doença hemorrágica.  
205. A vitamina K deve ser administrada por via intramuscular, na dose única de 1 mg, pois este método apresenta a melhor relação de custo-efetividade.  
206. Se os pais recusarem a administração intramuscular, deve ser oferecida a administração oral da vitamina K e eles devem ser advertidos que este método deve seguir as recomendações do fabricante e exige múltiplas doses.  
207. A dose oral é de 2 mg ao nascimento ou logo após, seguida por uma dose de 2 mg entre o quarto e o sétimo dia.  
208. Para recém-nascidos em aleitamento materno exclusivo, em adição às recomendações para todos os neonatos, uma dose de 2 mg via oral deve ser administrada após 4 a 7 semanas, por causa dos níveis variáveis e baixos da vitamina K no leite materno e a inadequada produção endógena.  
209. Ao nascimento, avaliar as condições do recém-nascido – especificamente a respiração, frequência cardíaca e tônus – no sentido de determinar se a ressuscitação é necessária de acordo com diretrizes reconhecidas de reanimação neonatal.  
210. Todos os profissionais que prestam cuidados diretos no nascimento devem ser treinados em reanimação neonatal de acordo com diretrizes reconhecidas de reanimação neonatal.  
211. Em todas os locais de parto: `o` Planejar o cuidado e ter em mente que pode ser necessário chamar por ajuda se o recémnascido precisar de ressuscitação  
- Assegurar que existam recursos para ressuscitação e para transferência do recém-nascido para outro local se necessário  
- Desenvolver fluxogramas de referência de emergência e implementá-los se necessário  
212. Se o recém-nascido necessitar de ressuscitação básica, iniciar com ar ambiente.  
213. Minimizar a separação do recém-nascido e sua mãe, levando em consideração as circunstâncias clínicas.  
214. Se houver mecônio significativo e o recém-nascido não apresenta respiração, frequência cardíaca e tônus normais o mesmo deve ser assistido segundo diretrizes reconhecidas de reanimação neonatal, incluindo realização precoce de laringoscopia e sucção sob visão direta.  
215. Se houver mecônio significativo e a criança estiver saudável, a mesma deve ser observada em uma unidade com acesso imediato a um neonatologista. Essas observações devem ser realizadas com 1 e 2 horas de vida e depois de 2 em 2 horas por 12 horas.  
216. Se não houver mecônio significativo, observar o recém-nascido com 1 e 2 horas de vida em todos os locais de parto.  
217. Se qualquer um dos seguintes sinais forem observados, com qualquer grau de mecônio, o recémnascido deve ser avaliado por um neonatologista/pediatra (o recém-nascido e a mãe devem ser transferidos se não estiverem em uma maternidade):  
- Frequência respiratória > 60 ipm  
- Presença de gemidos  
- Frequência cardíaca < 100 bpm ou > 160 bpm  
- Enchimento capilar acima de 3 segundos  
- Temperatura corporal ≥ 38°C ou 37,5°C em 2 ocasiões com 30 minutos de intervalo  
- Saturação de oxigênio < 95% (a medida da saturação de oxigênio é opcional após mecônio não significativo)  
- Presença de cianose central confirmada pela Oximetria de pulso se disponível  
218. Explicar os achados para a mulher e informá-la sobre o que procurar e com quem falar se tiver qualquer preocupação  
219. Estimular as mulheres a terem contato pele-a-pele imediato com a criança logo após o nascimento.  
220. Cobrir a criança com um campo ou toalha morna para mantê-la aquecida enquanto  mantém o contato pele-a-pele  
221. Evitar a separação mãe-filho na primeira hora após o nascimento para procedimentos de rotina tais como, pesar, medir e dar banho a não ser que os procedimentos sejam solicitados pela mulher ou sejam realmente necessários para os cuidados imediatos do recém-nascido.  
222. Estimular o início precoce do aleitamento materno, idealmente na primeira hora de vida.  
223. Registrar a circunferência cefálica, temperatura corporal e peso após a primeira hora de vida. 224. Realizar exame físico inicial para detectar qualquer anormalidade física maior e para identificar problemas que possam requerer transferência.  
225. Assegurar que qualquer exame, intervenção ou tratamento da criança seja realizado com o consentimento dos pais e também na sua presença ou, se isso não for possível, com o seu conhecimento.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 7.1 Introdução -->
Em quase todo o mundo, embora com algumas variações geográficas, até as décadas de 40-50, a maioria dos nascimentos aconteciam no domicílio com a mulher geralmente rodeada por parentes e amigas. A partir de então, uma enorme mudança ocorreu, e os partos passaram a ter lugar em hospitais, principalmente nos países desenvolvidos e em muitos países em desenvolvimento. Com essa mudança, o nascimento no ambiente hospitalar passou a ser a norma e o padrão a ser seguido em todo o mundo contemporâneo. Entretanto, esse padrão tem sido questionado, gerando muitas controvérsias na obstetrícia e, em muitos lugares surgem outras opções de assistência ao nascimento fora do ambiente hospitalar tradicional, como o parto domiciliar e em centros de nascimento dentro ou fora dos hospitais. A principal discussão em relação ao parto fora do hospital se refere à segurança. Os potenciais riscos do parto planejado fora do hospital se refere ao fato de que mesmo nas situações de baixo risco poderiam surgir problemas emergenciais que só poderiam ser solucionados no ambiente hospitalar. Por outro lado, o parto no ambiente hospitalar pode estar associado a intervenções, muitas vezes desnecessárias, a que as mulheres são submetidas acarretando-lhes também problemas. No Brasil, embora não sendo componente da política oficial do governo, algumas mulheres têm optado pelo parto no domicílio, principalmente nas grandes capitais do país, geralmente assistidas por Enfermeiras obstétricas e eventualmente por médicos. Entretanto, a assistência em centros de parto normal dentro ou fora dos hospitais já faz parte das políticas públicas, sendo um dos componentes da Rede Cegonha. Por se tratar de uma questão central na contemporaneidade do mundo e também do Brasil, as evidências atuais devem ser analisadas criticamente  para se responder de maneira adequada as dúvidas e controvérsias associadas ao tema.  
7.2 Benefícios e riscos associados com o local do nascimento  
7.2.1 Questão de revisão:  
- Quais os locais onde se pode prestar assistência qualificada ao parto?  
Para a resposta a essa questão foram considerados os desfechos maternos e perinatais. Do ponto de vista neonatal foram considerados prioritários a mortalidade e morbidade, incluindo a admissão em unidade de terapia intensiva. Para as mães foram considerados a mortalidade e morbidade, parto instrumental, cesariana, taxas de transferência e trauma perineal. Foram considerados também os benefícios para a saúde e a utilização de recursos em relação aos diversos locais onde se pode prestar assistência ao parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 7.2.2. Evidências Científicas -->
As diretrizes do NICE de 2014<sup>14</sup> abordou o tema, analisando os resultados da assistência ao parto em quatro locais:  
- Domicílio  
- Centro de Parto Normal extra-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes (CPNE) (“freestanding midwifery unit”)  
- Centro de Parto Normal intra ou peri-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes (CPNI) (“alongside midwifery unit”)  
- Maternidade baseada em Hospital (MH)  
- 7.2.3 Domicílio comparado com Centro de Parto Normal extra-hospitalar (CPNE) conduzido por enfermeiras obstétricas ou obstetrizes  (“freestanding midwifery unit”)  
Estas Diretrizes incluíram dois estudos (relatados em 3 publicações)<sup>16,17,18</sup> na sua revisão. Um deles, o  
Birthplace in England<sup>16</sup> , foi um grande estudo de coorte prospectivo conduzido na Inglaterra envolvendo cerca de 28.000 mulheres que planejaram o parto no domicílio ou em um CPN extra-hospitalar conduzida por Enfermeiras obstétricas/obstetrizes e o outro, um estudo retrospectivo realizado na Nova Zelândia<sup>17</sup> , que envolveu 4.699 mulheres. No estudo Inglês algumas diferenças demográficas entre os grupos, que não foram ajustadas para a comparação entre o parto domiciliar e o parto em unidades extra-hospitalares, pode ter afetado os resultados. No estudo da Nova Zelândia houve ajustes para as diferenças demográficas entre os dois grupos estudados. Os estudos não foram agrupados para análise já que se tratava de dados observacionais. Todas as análises foram por intenção de tratar, independente do local real do parto. A tabela 3 apresenta os resultados e magnitude do efeito para as diversas variáveis analisadas nos estudos incluídos na revisão.  
Tabela 3: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN extra-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes  
||Número d|e mulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado<br>domicílio|no<br>Parto<br>planejado em<br>um CPNE|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Mortalidade Materna|||||
|Birthplace in England<br>Collaborative Group,<br>2011<sup>16</sup>|0/16.840<br>(0%)|0/11.282<br>(0%)|NC|NC|
|Tipo departo:parto vagi|nal espontân|eo|||
|Birthplace in England<br>Collaborative Group,<br>2011<sup>16</sup>|15.590/1<br>6.825<br>(92,7%)|10.150/11.280<br>(90%)|RR 1,03<br>(1,02 a 1,04)|27 mais/1.000<br>(de 18 mais a<br>36 mais)|
|Davis et al., 2011<sup>17</sup>|1.743/1.8<br>26<br>(95,5%)|2.722/2.873<br>(94,7%)|RR 1,01<br>(0,99 a 1,02)|9 mais/1.000<br>(de 9 menos a<br>19 mais)|
|Tipo departo:parto vagi|nal instrumen|tal|||
|Birthplace in England<br>Collaborative Group,<br>2011<sup>16</sup>|714/16.8<br>25<br>(4,2%)|686/11.280<br>(6,1%)|RR 0,7<br>(0,63 a 0,77)|18<br>menos/1.000<br>(de 14 menos a<br>23 menos)|
|Tipo departo: cesariana|||||
|Birthplace in England<br>Collaborative Group,<br>2011|458/16.8<br>25<br>(2,7%)|405/11.280<br>(3,6%)|RR 0,76<br>(0,66 a 0,86)|9 menos/1.000<br>(de 5 menos a<br>12 menos)|  
Tabela 3: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN extra-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes  
||Número d|e mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado<br>domicílio|no<br>Parto<br>planejado em<br>um CPNE|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Davis et al., 2011|47/1.826<br>(2,6%)|91/2.873<br>(3,2%)|RR ajustado<br>0,86|6 menos/1000<br>(de 14 menos a|
||||(0,60 a 1,24)<sup>a</sup>|5 mais)|
|Uso deperidural|||||
|Birthplace in England<br>Collaborative Group,<br>|1418/16.<br>799<br>|1251/11.251<br>(11,1%)|RR 0,76<br>(0,71 a 0,82)|27<br>menos/1.000<br>|
|2011|(84%)|||(de 20 menos a|
|<br>Medidas deperda sangu|,<br>ínea: hemorr|agiapós-parto maio|r(> 1.000 ml)|<br>32 menos)|
|Davis et al., 2011|19/1.830<br>(1,0%)|32/2.904<br>(1,1%)|RR ajustado<br>0,93|2 menos/1.000<br>(de 17 menos a|
||||(0,49 a 1,74)<sup>a</sup>|24 mais)|
|Medidas deperda sangu<br>|ínea: necessi<br>|dade de hemotransf<br>|usão<br>||
|Birthplace in England<br>Collaborative Group,|101/16.6<br>87|67/11.230<br>(0,6%)|RR 1,01<br>(0,75 to 1,38)|0 mais/1000<br>(de 1 menos a 2|
|2011|(0,61%)|||mais)|
|Mulheres nulíparas|||||
|Birthplace in England|39/4.488|24/5.158|RR 1,87|4.048/|
|Collaborative Group,<br>2011|(0,87%)|(0,47%)|(1,12 to 3,10)|1.000.000<br>(de 558 mais a|
|||||<br>9.771 mais)|
|Mulheres multíparas|||||
|Birthplace in England<br>Collaborative Group,<br>2011|31/12.05<br>0<br>(0,26%)|17/6.035<br>(0,28%)|RR 0,91<br>(0,51 a 1,65)|254/1.000.000<br>(de 1.383<br>menos a 1.834|
|||||mais)|
|Encefalopatia neonatal(|diagnóstico c<br>|línico)<br>|||
|Birthplace in England|34/16.58|17/11.210|RR 1,35|531/1.000.000|
|Collaborative Group,|9|(0,15%)|(0,76 to|(de 364 menos|
|2011|(0,2%)||2,42)c|a 2.153 mais)|
|Encefalopatia neonatal(|sinais)<sup>d</sup>||||
|Birthplace in England|4/16.840|2/11.282|RR 1,34|60/1.000.000|
|Collaborative Group,|(0,02%)|(0,02%)|(0,25 to|(de 133 menos|
|2011|||7,31)<sup>b</sup>|a 1.119 mais|
|Episiotomia|||||  
Tabela 3: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN extra-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes  
||Número d|e mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado<br>domicílio|no<br>Parto<br>planejado em<br>um CPNE|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Birthplace in England<br>Collaborative Group,<br>2011|933/16.6<br>70<br>(5,6%)|995/11.275<br>(8,8%)|RR 0,63<br>(0,58 a 0,69)|33<br>menos/1.000<br>(de 27 menos a<br>37 menos)|
|Davis et al., 2011|NR|NR|RR ajustado<br>0,57<br>(0,40 a 0,82)<sup>a</sup>|NC|
|Laceraçõesperineais|||||
|Davis et al., 2011|NR|NR|RR ajustado<br>0,74<br>(0,65 a 0,84)|NC|
|Laceraçõesperineiais de 3|<sup>o</sup>ou 4<sup>o</sup> grau||||
|Birthplace in England|318/16.8|259/11.262|RR 0,82|4 menos/1.000|
|Collaborative Group,|00|(2,3%)|(0,7 a 0,97)|(de 1 menos a 7|
|2011|(1,9%)|||menos)|
|Morte fetal|||||
|Birthplace in England<br>Collaborative Group,<br>2011|6/16.839<br>(0,04%)|4/11.282<br>(0,04%)|RR 1<br>(0,28 a 3,56)<sup>b</sup>|0 menos/<br>1.000.000<br>(de 255 menos<br>a 908 mais|
|Davis et al., 2011|0/1.826|0/2.873|NC|NC|
||(0%)|(0%)|||
|Morte neonatal|||||
|Birthplace in England<br>Collaborative Group,<br>2011|5/16.759<br>(0,03%)|5/11.263<br>(0,04%)|RR 0,67<br>(0,19 a 2,32)c|146 menos/<br>1.000.000<br>(de 360 menos<br>a 586 mais)|
|Davis et al., 2011|2/1.826<br>(0,11%)|0/2.873<br>(0%)|RR 7,87<br>(0,38 a|NC|
||||<br>163,74)||
|Tipo departo: cesariana|||||
|Birthplace in England|458/16.8|405/11.280|RR 0,76|9 menos/1.000|
|Collaborative Group,<br>2011|25<br>(2,7%)|(3,6%)|(0,66 a 0,86)|(de 5 menos a<br>12 menos)|  
Tabela 3: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN extra-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes  
||Número d|e mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado<br>domicílio|no<br>Parto<br>planejado em<br>um CPNE|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Davis et al., 2011|47/1.826<br>(2,6%)|91/2.873<br>(3,2%)|RR ajustado<br>0,86<br>(0,60 a 1,24)<sup>a</sup>|6 menos/1.000<br>(de 14 menos a<br>5 mais)|
|Admissão em Unidade d|e Terapia Inte|nsiva Neonatal(UTI|N)||
|Birthplace in England<br>Collaborative Group,<br>2011|284/16.6<br>96<br>(1,7%)|194/11.257<br>(1,7%)|RR 0,99<br>(0,82 to 1,18)|0 menos/1.000<br>(de 3 menos a 3<br>mais)|
|Davis et al., 2011<br>Morbidade e mortalidad<br>Todas as mulheres de ba|NR<br>eperinatal co<br>ixo risco|NR<br>mposta<sup>c</sup>|RR 0,98<br>(0,65 to 1,47)|NC|
|Birthplace in England|70/16.55|41/11.199|RR 1,16|586 mais/|
|Collaborative Group,<br>2011|3<br>(0,42%)|(0,37%)|(0,79 a 1,7)|1.000.000<br>(de 769 menos<br>a 2.563 mais)|  
IC intervalo de confiança, NC não calculável, NR não relatado, RR risco relativo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: a. Ajustado para idade materna, paridade, etnia e tabagismo -->
b. Este desfecho é parte dos desfechos compostos de morbidade/mortalidade no estudo Birthplace e o estudo teve força apenas para detectar diferenças nos resultados compostos, não nos seus componentes individuais  
c. Composto de morte fetal após início da assistência no trabalho de parto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula.  
d. Definido como internação em unidade neonatal dentro de 48 horas do parto, por pelo menos 48 horas, com evidência de dificuldade para alimentar e desconforto respiratório  
Fonte: Modificado de NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 839 p, Dec. 2014

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 7.2.3.1 Resumo da evidência e conclusões -->
As evidências demonstraram uma tendência de menores taxas de parto instrumental, cesariana, analgesia peridural, episiotomia, lacerações em geral e lacerações de 3<sup>o</sup> e 4<sup>o</sup> grau entre as mulheres que planejaram um parto em casa em comparação com aquelas que planejaram o parto em um CPN extrahospitalar. Em relação aos resultados neonatais não foram demonstradas diferenças entre os grupos em relação a mortalidade fetal e neonatal precoce e internação em unidade de terapia intensiva neonatal.  
No estudo inglês, os resultados adversos neonatais foram agrupados (morte fetal intraparto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula) não se evidenciado diferença entre os grupos quando todas as mulheres foram analisadas em conjunto. Entretanto, em uma análise de sub-grupo por paridade (n= 9.646), demonstrou-se que, para as nulíparas, houve um maior risco de resultados neonatais adversos compostos no grupo que planejou o parto no domicílio, sem diferenças entre as multíparas. Nesse mesmo estudo, não foram encontradas diferenças em relação ao diagnóstico clínico e sinais de encefalopatia neonatal.  
Não houve diferenças entre os grupos na ocorrência de hemorragia pós-parto ou transfusão de hemoderivados.  
No estudo inglês, as taxas de transferência em geral, no grupo que planejou o parto no domicílio, foram de 21% (antes do parto: 14,2%; após: 6,2%; momento desconhecido: 0,6%). Entre as nulíparas foram de 45% (79,8% antes do parto) e nas multíparas 12% (55% antes do parto). No grupo que planejou o parto em um CPN extra-hospitalar foram em geral de 21,9% (antes do parto: 16,5%; após: 4,8%; momento desconhecido: 0,5%). Entre as nulíparas foi de 36,3% (83,4% antes do parto). Entre as multíparas foi de 9,4% (57,4% antes do parto). No estudo neo-zelandês, 82,7% dos partos planejados no domicílio aconteceram de fato no domicílio, contra 90,2% daqueles planejados para um CPN extra-hospitalar, que aconteceram na unidade. As diretrizes não apresentam análises estatísticas para as taxas de transferência.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 7.2.3.2 Outras considerações -->
A relação entre os benefícios clínicos e danos dos dois locais estudados demonstra benefícios para o parto planejado no domicílio em relação a incidência de parto vaginal instrumental, cesariana, lacerações perineais em geral, lacerações de terceiro e quarto grau e episiotomia. Quanto à hemorragia e transfusão de hemoderivados não há superioridade entre um ou outro local. Em relação aos resultados perinatais, quando se analisa todas participantes em conjunto, não há diferenças significativas entre os dois locais de nascimento. Entretanto, os estudos isoladamente não tiveram poder estatístico suficiente para detectar diferenças na mortalidade e encefalopatia neonatal. Foi demonstrado também um maior risco de resultados neonatais adversos compostos entre as nulíparas que planejaram o parto no domicílio.  
Em relação aos benefícios para a saúde e uso de recursos, concluiu-se que um parto planejado no domicílio oferece menores custos que um parto planejado em um CPN extra-hospitalar, tendo em vista os custos relacionados à infra estrutura dessas unidades. Por outro lado, considerou-se que os custos de transferência seriam os mesmos já que em ambos os locais estariam envolvidos custos de ambulância. Por esse motivo o grupo elaborador das diretrizes inglesa recomendou que, para as multíparas, a decisão e escolha sobre o local de parto ficasse a seu critério e, para as nulíparas, que fossem aconselhadas a planejar o parto em um Centro de Parto Normal extra-hospitalar e não em casa. 7.2.4 Domicílio comparado com centro de parto normal intra- ou peri-hospitalar (CPNI) (“alongside  
midwifery unit”)  
Para essa comparação um único estudo foi incluído nestas Diretrizes, o estudo de coorte realizado na Inglaterra já descrito<sup>16</sup> . A Tabela 4 apresenta o sumário dos estudos e a magnitude do efeito para os desfechos analisados.  
Tabela 4: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN intra ou peri-hospitalar consuzido por enfermeiras obstétricas ou obstetrizes (CPNI)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto planejado<br>no domicílio|Parto planejado<br>em um CPNI|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Mortalidade Materna|||||
|Birthplace in England|0/16.840|0/16.710|NC|NC|
|Collaborative Group,|(0%)|(0%)|||
|2011<br>Tipo departo:parto vag|inal espontâneo||||
|Birthplace in England<br>Collaborative Group,|15.590/16.825<br>(92,7%)|14.413/16.690<br>(86,4%)|RR 1,07<br>(1,07 to|60 mais/1.000<br>(de 60 mais a|
|2011|||1,08)|69 mais)|
|Tipo departo:parto vag|inal instrumental||||
|Birthplace in England<br>Collaborative Group,|714/16.825<br>(4,2%)|1.524/16.690<br>(9,1%)|RR 0,46<br>(0,43 a|49/1.000<br>(de 45 menos|
|2011|||0,51)|a 52 menos)|
|Tipo departo: cesariana|||||
|Birthplace in England<br>Collaborative Group,<br>2011|458/16.825<br>(2,7%)|727/16.690<br>(4,4%)|RR 0,62<br>(0,56 a 0,7)|17<br>menos/1.000<br>(de 13 menos|
|||||a 19 menos)|
|Uso deperidural|||||
|Birthplace in England<br>Collaborative Group,<br>2011|1.418/16.799<br>(8.4%)|2.464/16.661<br>(14.8%)|RR 0,57<br>(0,54 a<br>0,61)|64<br>menos/1.000<br>(de 58 menos|
|Medidas deperda sangu|ínea: necessidade|de hemotransfusã|o|a 68 menos)|
|Birthplace in England<br>Collaborative Group,|101/16.687<br>(0,61%)|136/16.548<br>(0,82%)|RR 0,74<br>(0,57 a|2 mais/1.000<br>(de 0 menos a|
|2011|||0,95)|4 menos)|
|Episiotomia|||||
|Birthplace in England<br>Collaborative Group,|933/16.670<br>(5,6%)|2.098/16.689<br>(12,6%)|RR 0,45<br>(0,41 a|69<br>menos/1.000|
|2011|||0,48)|(de 65 menos|
|||||<br>a 74 menos)|
|Laceraçõesperineiais de|3<sup>o</sup>ou 4<sup>o</sup> grau||||
|Birthplace in England|318/16.800|535/16.654|RR 0,59|13|
|Collaborative Group,<br>2011|(1,9%)|(3,2%)|(0,51 a<br>0,68)|menos/1.000<br>(de 10 menos|  
Tabela 4: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN intra ou peri-hospitalar consuzido por enfermeiras obstétricas ou obstetrizes (CPNI)  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto planejado<br>no domicílio|Parto planejado<br>em um CPNI|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Morte fetal||||a 16 menos)<br>|
|Birthplace in England<br>Collaborative Group,<br>2011|6/16.839<br>(0,04%)|1/16.708<br>(0,006%)|RR 5,95<br>(0,72 a<br>4944)<sup>a</sup>|296 mais/<br>1.000.000<br>(de 17 menos|
|<br>Morte neonatalprecoc|e||,|<br>a 2.899 mais|
|Birthplace in England<br>Collaborative Group,<br>2011<br>Admissão em Unidade d|5/16.759<br>(0,03%)<br>e Terapia Intensiva|3/16.633<br>(0,02%)<br>Neonatal(UTIN)|RR 1,65<br>(0,4 to 6,92)|117 mais/<br>1.000.000<br>(de 108<br>menos a<br>1.068 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|284/16.696<br>(1,7%)|307/16.580<br>(1,9%)|RR 0,92<br>(0,78 a<br>1,08)|1<br>menos/1.000<br>(de 4 menos a|
|||||<br>1 mais)|
|Morbidade e mortalida|deperinatal compo|sta<sup>b</sup>|||
|Todas as mulheres de b|aixo risco<br>||||
|Birthplace in England<br>Collaborative Group,<br>2011|70/16.553<br>(0,42%)|58/16.524<br>(0,35%)|RR 1,2<br>(0,85 to<br>1,71)|702 mais/<br>1.000.000<br>(de 527<br>menos a<br>2.492 mais)|
|Mulheres nulíparas|||||
|Birthplace in England<br>Collaborative Group,<br>2011|39/4.488<br>(0,87%)|38/8.256<br>(0,46%)|RR 1,89<br>(1,21 a<br>2,95)|4.096/<br>1.000.000<br>(de 967 mais|
|||||<br>a 8.975 mais)|
|Mulheres multíparas|||||
|Birthplace in England<br>Collaborative Group,<br>2011|31/12.050<br>(0,26%)|20/8.234<br>(0,24%)|RR 1,06<br>(0,60 a<br>1,86)|146/1.000.00<br>0<br>(de 972<br>menos a<br>2.089 mais)|  
Tabela 4: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em um CPN intra ou peri-hospitalar consuzido por enfermeiras obstétricas ou obstetrizes (CPNI)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto planejado<br>no domicílio|Parto planejado<br>em um CPNI|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Encefalopatia neonatal(|diagnóstico clínico)||||
|Birthplace in England<br>Collaborative Group,<br>2011<br>Encefalopatia neonatal(<br>|34/16.589<br>(0,2%)<br>sinais)<sup>c</sup><br>|4/16.710<br>(0,02%)<br>|RR 0.99<br>(0,25 a<br>3,97)<sup>a</sup><br>|531/1.000.00<br>0<br>(de 364<br>menos a<br>2.153 mais)<br>|
|Birthplace in England<br>Collaborative Group,<br>2011|4/16.840<br>(0,02%)|4/16.710<br>(0,02%)|RR 0,99<br>(0,25 a<br>3,97)<sup>a</sup>|2 menos/<br>1.000.000<br>(de 180<br>menos a 711<br>mais|  
IC intervalo de confiança, NC não calculável, RR risco relativo,  
a. Este desfecho é parte dos desfechos compostos de morbidade/mortalidade no estudo Birthplace e o estudo teve força apenas para detectar diferenças nos resultados compostos, não os seus componentes individuais.  
b. Composto de morte fetal após início da assistência no trabalho de parto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula.  
c. Definido como internação em unidade neonatal dentro de 48 horas do parto, por pelo menos 48 horas, com evidência de dificuldade para alimentar e desconforto respiratório.  
Fonte: Modificado de : NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 839 p, Dec. 2014

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 7.2.4.1 Resumo da evidência e conclusões -->
As evidências demonstram que as mulheres que planejaram o parto em casa tiveram uma menor incidência de parto vaginal instrumental, cesariana, analgesia peridural, transfusão de sangue, episiotomia e lacerações de 3<sup>o</sup> ou 4<sup>o</sup> graus em comparação às mulheres que planejaram o parto em um CPN intra ou peri-hospitalar.  
Nesse mesmo estudo, não houve diferenças, no geral, nos resultados compostos de mortalidade e morbidade neonatal nos dois grupos. Entretanto, na análise de sub-grupo, estratificada por paridade, houve uma maior incidência de resultados adversos compostos para os recém-nascidos das nulíparas que planejaram o parto em casa. Não houve nenhuma evidência de diferenças estatisticamente significativas entre os grupos em termos de admissão em UTI neonatal e riscos de morte perinatal. Entretanto, esses desfechos fizeram parte dos resultados compostos e o estudo não tinha tamanho amostral suficiente para detectar diferenças nos componentes individuais. O estudo relatou uma maior  
incidência de diagnóstico clínico de encefalopatia neonatal (outro componente dos resultados compostos) entre os recém-nascidos de mulheres que planejaram o parto em casa, mas nenhuma diferença nas taxas de recém-nascidos com os sinais de encefalopatia neonatal.  
As taxas de transferência em geral, no grupo que planejou o parto no domicílio  foram de 21% (antes do parto: 14,2%; após: 6,2%; momento não conhecido: 0,6%). Entre as nulíparas foram de 45% (79,8% antes do parto) e nas multíparas 12% (55% antes do parto). No grupo que planejou o parto em um CPN intra ou peri-hospitalar foram em geral de 26,4% (antes do parto: 21,2%; após: 4.3%; momento não conhecido: 0,9%). Entre as nulíparas foi de 40,2% (86,4% antes do parto). Entre as multíparas foi de 12.5% (70,8% antes do parto).  
7.2.4.2 Outras considerações  
Em relação aos benefícios clínicos e danos dos dois locais estudados a evidência demonstra benefícios para o parto planejado no domicílio em relação às taxas de intervenção como cesariana, parto vaginal instrumental e episiotomia, assim como em relação às lacerações perineais de terceiro e quarto grau e transfusão de hemoderivados. Em termos perinatais, os riscos e benefícios foram semelhantes para ambos os grupos quando se considera os resultados neonatais adversos compostos. Em relação ao achado mais comum de diagnóstico de encefalopatia neonatal no grupo que planejou o parto no domicílio, não foi relatado os graus de encefalopatia, tornando difícil a interpretação dos resultados. Algumas crianças podem ter sobrevivido sem sequelas de longo prazo, assim como outras podem ter evoluído com morbidade grave .  
Foram considerados os custos e benefícios para a saúde nos dois locais de parto avaliados, concluindo que, por apresentar menor incidência de intervenções e transfusão de sangue, além de não utilizar serviços de hotelaria, o parto planejado no domicílio pode apresentar custos menores. Entretanto, considerando as taxas de transferência e necessidade de utilização de serviços de ambulância, o parto planejado no domicílio pode apresentar custos adicionais. Também em um CPN intra ou peri-hospitalar, a utilização de pessoal auxiliar para oferecer apoio às mulheres pode representar menor custo com pessoal já que no parto domiciliar há a necessidade da presença contínua de uma Enfermeira obstétrica ou obstetriz durante o trabalho de parto e de duas no momento do nascimento.  
7.2.5 Domicílio comparado com uma maternidade baseada em hospital  
As diretrizes do NICE incluíram 15 estudos na sua revisão. Apenas um dos estudos foi um ensaio clínico randomizado piloto realizado na Inglaterra<sup>19</sup> . Três estudos foram de coorte prospectivos conduzidos na Inglaterra<sup>16</sup> , Suiça<sup>20</sup> e Canadá<sup>21</sup> . Os outros 11 estudos foram coortes retrospectivos realizados em 8 países diferentes: Inglaterra<sup>22</sup> , Holanda<sup>23,24,25</sup> , Suécia<sup>26</sup> , EUA<sup>27</sup> , Canadá<sup>28,29</sup> , Austrália<sup>30</sup> , Nova Zelândia<sup>17,18</sup> e Noruega<sup>31</sup> .  
Todos os estudos analisaram os dados por intenção de tratar. Três deles avaliaram os resultados pelo local agendado para o parto durante o pré-natal (Ackermann-Liebrich et al., 1996<sup>20</sup> ; Dowswell et al., 1996<sup>19</sup> ; Woodcock et al., 1994<sup>30</sup> ). Um estudo<sup>16</sup> analisou os resultados pelo local de intenção do parto no início dos cuidados no trabalho de parto. O restante analisou os resultados pelo local de intenção do parto no início do trabalho de parto. Os estudos planejavam incluir apenas mulheres de baixo risco mas uma proporção delas tinha complicações, o que as levou a serem consideradas de alto risco e portanto fora do escopo das diretrizes. Não foi realizada meta-análise dos estudos, que foram analisados individualmente. Ver tabela 5 com o sumário dos estudos e a magnitude do efeito para os desfechos analisados.  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se|Absoluto<br>(IC 95%)|
|Mortalidade Materna|||declarado])||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|0/16.840<br>(0%)|0/19.706<br>(0%)|NC|NC|
|Ackermann-Liebrich<br>et al.,1996|0/214<br>(0%)|0/214<br>(0%)|NC|NC|
|Lindgren et al., 2008|0/897<br>(0%)|0/11.341<br>(0%)|NC|NC|
|Janssen et al., 2009|0/2.899<br>(0%)|0/10.083<br>(0%)|NC|NC|
|Hutton et al., 2009|0/6.692|0/6.692|NC|NC|
||(0%)|(0%)|||
|Tipo departo:parto v|aginal espontân|eo|||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|15.590/16.82<br>5<br>(92,7%)|14.645/19.688<br>(74.4%)|OR Ajustado<br>3,61<br>(IC 99% 2,97 a<br>4,38)<sup>a</sup>|186<br>mais/1.000<br>(de 171 mais a<br>193 mais)|
|Davis et al., 2011|1.743/1.826<br>(95,5%)|9.195/11.448<br>(80,3%)|RR 1,19<br>(1,17 to 1,2)|153<br>mais/1.000<br>(de 137 mais a<br>161 mais)|
|Janssen et al., 2002)|779/862<br>(90,4%)|941/1.314<br>(71,6%)|RR 1,26<br>(1,21 to 1,31)|186<br>mais/1.000<br>(de 150 mais a<br>222 mais)|
|Hutton et al., 2009|6.146/6.692<br>(91,8%)|5.852/6.692<br>(87,4%)|RR 1,05<br>(1,04 to 1,06)|44 mais/1.000<br>(de 35 mais a<br>52 mais)|
|Woodcock et al.,<br>1994|865/976<br>(88,6%)|1.787/2.928<br>(61%)|RR 1,45<br>(1,4 to 1,51)|275 mais/1000<br>(de 244 mais a<br>311 mais)|
|Blix et al., 2012|1.572/1.631<br>(96.4%)|14.477/16.310<br>(88.8%)|RR 1,09<br>(1,07 to 1,10)|80 mais/1000<br>(de 62 mais a<br>89 mais)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Dowswell et al.,<br>1996 (ERC)|5/5<br>(100%)|6/6<br>(100%)|RR 1<br>(0,73 a 1,37)|0 menos/1.000<br>(de 270 menos|
|||||a 370 mais)|
|Tipo departo:parto v<br>|aginal instrumen<br>|tal<br>|||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|714/16.825<br>(4,2%)|2.842/19.688<br>(14.4%)|OR Ajustado<br>Ventosa: 0,29<br>(IC 99% 0,21 A<br>0,40)<sup>a</sup><br>Fórceps: 0,43<br>(IC 99% 0,32 a<br>0,57)<sup>a</sup>|102<br>menos/1.000<br>(de 98 menos<br>a 105 menos)|
|Davis et al., 2011|36/1.826<br>(2%)|1.018/11.448<br>(8,9%)|RR 0,22<br>(0,16 a 0,31)|69<br>menos/1.000<br>(de 61 menos<br>a 75 menos)|
|Ackermann-Liebrich<br>et al., 1996|8/207<br>(3,9%)|18/207<br>(8,7%)|RR 0,44<br>(0,2 to 1,00)|49<br>menos/1.000<br>(de 70 menos<br>a 0 mais)|
|Lindgren et al., 2008|20/897<br>(2,2%)|1.089/11.341<br>(9,6%)|RR ajustado 0,3<br>(0,2 a 0,5)<sup>b</sup>|74<br>menos/1.000<br>(de 61 menos<br>a 82 menos)|
|Janssen et al., 2002)|28/862<br>(3,2%)|170/1314<br>(12,9%)|RR 0,25<br>(0,17 a 0,37)|97<br>menos/1.000<br>(de 82 menos<br>a 107 menos)|
|Janssen et al., 2009)|86/2.899<br>(3%)|1.080/10.083<br>(10,7%)|RR 028<br>(0,22 a 0,34)|77<br>menos/1.000<br>(de 71 menos<br>a 84 menos)|
|Hutton et al., 2009|195/6.692<br>(2,9%)|293/6.692<br>(4,4%)|RR 0,67<br>(0,56 a 0,8)|14<br>menos/1.000<br>(de 9 menos a<br>19 menos)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Woodcock et al.,<br>1994|86/2.899<br>(3%)|1.080/10.083<br>(10,7%)|RR 0,28<br>(0,22 a 0,34)|77<br>menos/1.000<br>(from 71 fewer<br>to 84 fewer)|
|Blix et al., 2012|28/1.631<br>(1,6%)|1.218/16.310<br>(7,5%)|RR 0,23<br>(0,16 a 0,33)|58<br>menos/1.000<br>(50 menos a<br>63 menos)|
|Dowswell et al.,<br>1996 (ERC)|0/5<br>(0%)|0/6<br>(0%)|NC|NC|
|Tipo departo: cesaria|na||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|458/16.825<br>(2,7%)|2.158/19.688<br>(11%)|OR Ajustada<br>0,31<br>(IC 99% 0,23 a<br>0,41)b|82<br>menos/1.000<br>(de 80 menos<br>a 84 menos)|
|Davis et al., 2011|47/1.826<br>(2,6%)|1.232/11.448<br>(10,8%)|RR 0,24<br>0,18 a 0,32)|82<br>menos/1.000<br>(de 73 menos<br>a 88 menos)|
|Ackermann-Liebrich<br>et al., 1996|12/207<br>(5,8%)|24/207<br>(11,6%)|RR 0,5<br>(0,26 a 0,97)|58<br>menos/1.000<br>(de 3 menos a<br>86 menos)|
|Lindgren et al., 2008|22/897<br>(2,5%)|776/11.341<br>(6,8%)|RR ajustado 0,3<br>(0,2 a 0,7)<sup>b</sup>|44<br>menos/1.000<br>(de 31 menos<br>a 52 menos)|
|Janssen et al., 2002)|55/862<br>(6,4%)|203/1.314<br>(15,4%)|RR 0,41<br>(0,31 a 0,55)|91 enos/1.000<br>(de 70 menos<br>a 107 menos)|
|Janssen et al., 2009)|208/2.899<br>(7,2%)|1.086/10.083<br>(10,8%)|RR 0,67<br>(0,58 a 0,77)|36<br>menos/1.000<br>(de 25 menos<br>a 45 menos)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Hutton et al., 2009|348/6.692<br>(5,2%)|544/6.692<br>(8,1%)|RR 0,64<br>(0,56 a 0,73)|29<br>menos/1.000<br>(de 22 menos<br>a 36 menos)|
|Woodcock et al.,<br>1994|42/976<br>(4,3%)|424/2.928<br>(14,5%)|OR ajustado:<br>Emergência<br>0,25<br>(0,17 a 0,38)<sup>c</sup><br>Eletiva 0,06<br>(0,03 a 0,14)<sup>c</sup>|101<br>menos/1.000<br>(de 87 menos<br>a 113 menos)|
|Blix et al., 2012|31/1.631<br>(1,9%)|615/16.310<br>(3,8%)|RR 0,50<br>(0,35 a 0,72)|19<br>menos/1.000<br>(11 menos a<br>30 menos)|
|Dowswell et al.,<br>1996 (ERC)|0/5<br>(0%)|0/6<br>(0%)|NC|NC|
|Uso deperidural|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|1.418/16.799<br>(8,4%)|5.817/19.576<br>(29,7%)|OR Ajustado<br>0,25<br>(IC 99% 0,20 a<br>0,31)<sup>a</sup>|214<br>menos/1.000<br>(de 208 menos<br>a 217 menos)|
|Janssen et al., 2002)|66/862<br>(7,7%)|355/1.314<br>(27%)|RR 0,28<br>(0,22 a 0,36)|195<br>menos/1.000<br>(de 173 menos<br>a 211 menos)|
|Janssen et al., 2009)|224/2.899<br>(7,7%)|2.388/10.083<br>(23,7%)|RR 0,33<br>(0,29 a 0,37)|159<br>menos/1.000<br>(de 149 menos<br>a 168 menos)|
|Hutton et al., 2009|655/6.692<br>(9,8%)|1.405/6.692<br>(21%)|RR 0,47<br>0,43 a 0,51)|111<br>menos/1.000<br>(de 103 menos<br>a 120 menos)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Blix et al., 2012<br>Medidas deperda san|31/1.631<br>(1,9%)<br> guínea: hemorra|615/16.310<br>(3,8%)<br> giapós-parto(qual|RR 0,50<br>(0,35 a 0,72)<br>quer)|19<br>menos/1.000<br>(11 menos a<br>30 menos)|
|Lindgren et al., 2008|não relatado<br>(NR)|NR|RR ajustado 0,4<br>(0,2 a 1,0)<sup>b</sup>|NC|
|Janssen et al., 2009)|110/2.899<br>(3,8%)|642/10.083<br>(6,4%)|RR 0,6<br>(0,49 a 0,73)|25<br>menos/1.000<br>(de 17 menos<br>a 32 menos)|
|Hutton et al., 2009|624/6.692<br>(9,3%)|760/6.692<br>(11,4%)|RR 0,82<br>(0,74 a 0,91)|20<br>menos/1.000<br>(de 10 menos<br>a 30 menos)|
|Woodcock et al.,<br>1994|64/976<br>(6,6%)|46/2.928<br>(1,6%)|OR Ajustado<br>3,83<br>(2,59 a 5,66) <sup>c</sup>|50 mais/1.000<br>(de 10 mais a<br>30 mais)|
|Pang et al., 2002|74/5.969<br>(1,2%)|84/9.861<br>(0,85%)|RR 1,46<br>(1,07 a 1,99)|4 mais/1.000<br>(de 1 mais a 8<br>mais)|
|Blix et al., 2012<br>Medidas deperda san|50/1.631<br>(3,1%)<br> guínea: hemorra|1.361/16.310<br>(8,3%)<br> giapós-parto maio|RR 0,44<br>(0,34 a 0,57)<br>r(> 1.000 ml)|47<br>menos/1.000<br>(36 menos a<br>55 menos)|
|Janssen et al., 2002)|38/862<br>(4,4%)|66/1314<br>(5%)|RR 0,88<br>(0,59 to 1,3)|6 menos/1.000<br>(de 21 menos<br>a 15 mais)|
|Hutton et al., 2009|56/6.692<br>(0,84%)|82/6.692<br>(1,2%)|RR 0,68<br>(0,49 a 0,96)|4 menos/1.000<br>(de 0 menos a<br>6 menos)|
|Davis et al., 2012|19/1.830<br>(1,0%)|163/11.466<br>(1,4%)|RR 0,73<br>(0,46 a 1,17)|4 menos/1.000<br>(de 8 menos a<br>2 mais)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Nove et al., 2012|23/5.998<br>(0,4%)|2.785/267.874<br>(1,0%)|RR 0,37<br>(0,24 a 0,56)|7 menos/1.000<br>(de 5 menos a<br>8 menos)|
|De Jonge et al., 2013|2699/92.333<br>(2,9%)|2.172/54.419<br>(4,0%)|RR 0,73<br>(0,69 to 0,77)|11<br>menos/1.000<br>(de 15 menos<br>a 7 menos)|
|Medidas deperda san<br>|guínea: necessid<br>|ade de hemotrans<br>|fusão<br>||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|101/16.687<br>(0,61%)|241/19.579<br>(1,2%)|OR ajustado<br>0,72<br>(IC 99% 0,47 a<br>1,12)<sup>b</sup>|6 menos/1.000<br>(de 5 menos a<br>8 menos)|
|Janssen et al., 2002)|3/862<br>(0,35%)|1/1.314<br>(0,08%)|RR 4,57<br>(0,48 a 43,89)|3 mais/1.000<br>(de 0 menos a<br>33 mais)|
|Janssen et al., 2009)|2/2899<br>(0,07%)|25/10.083<br>(0,25%)|RR 0,28<br>(0,07 a 1,17)|2 menos/1.000<br>(de 2 menos a<br>0 mais)|
|De Jonge et al., 2013|134/92.333<br>(0,15%)|122/54.419<br>(0,22%)|RR 0,65<br>(0,51 a 0,83)|1 menos/1.000<br>(de 0 menos a|
|||||1 menos|
|Episiotomia|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|933/16.670<br>(5,6%)|3.780/19.678<br>(19,2%)|OR Ajustada<br>0,33<br>(IC 99% 0,28 a<br>0,39)<sup>a</sup>|136<br>menos/1.000<br>(de 133 menos<br>a 140 menos)|
|Ackermann-Liebrich<br>et al., 1996|45/207<br>(21,7%)|128/207<br>(61,8%)|RR 0,35<br>(0,27 a 0,47)|402<br>menos/1.000<br>(de 328 menos<br>a 451 menos)|
|Lindgren et al., 2008|8/897<br>(0,89%)|820/11.341<br>(7,2%)|RR Ajustado 0,1<br>(0 a 0,2)c|64<br>menos/1.000<br>(de 54 menos<br>a 68 menos|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Janssen et al., 2002)|33/862<br>(3,8%)|176/1.314<br>(13,4%)|RR 0,29<br>(0,2 a 0,41)|95<br>menos/1.000<br>(de 79 menos<br>a 107 menos)|
|Janssen et al., 2009)|84/2.899<br>(2,9%)|1.089/10.083<br>(10,8%)|RR 0,27<br>(0,22 a 0,33)|79<br>menos/1.000<br>(de 72 menos<br>a 84 menos)|
|Hutton et al., 2009|286/6.692<br>(4,3%)|393/6.692<br>(5,9%)|RR 0,73<br>(0,63 a 0,84)|16<br>menos/1.000<br>(de 9 menos a<br>22 menos)|
|Períneo intacto|||||
|Ackermann-Liebrich<br>et al., 1996|63/207<br>(30,4%)|16/207<br>(7,7%)|RR 3,94<br>(2,36 a 6,58)|227<br>mais/1.000<br>(de 105 mais a<br>431 mais)|
|Janssen et al., 2002)|474/862<br>(55%)|612/1.314<br>(46,6%)|RR 1,18<br>(1,09 a 1,28)|84 mais/1.000<br>(de 42 mais a|
|||||130 mais)|
|Laceraçõesperineiais|de 3<sup>o</sup>ou 4<sup>o</sup> grau||||
|Birthplace in<br>England|318/16.800<br>(1,9%)|625/19.638<br>(3,2%)|RR Ajustado<br>0,77|13<br>menos/1.000|
|Collaborative Group,<br>2011|||(IC 99% 0,57 a<br>1,05)a|(de 10 menos<br>a 15 menos)|
|Lindgren et al., 2008|3/897<br>(0,33%)|311/11.341<br>(2,7%)|RR Ajustado 0,2<br>(0 a 0,7)e|24<br>menos/1.000<br>(de 17 menos<br>a 26 menos|
|Janssen et al., 2002)|19/862<br>(2,2%)|45/1.314<br>(3,4%)|RR 0,64<br>(0,38 a 1,09)|12<br>menos/1.000<br>(de 21 menos<br>a 3 mais)|
|Janssen et al., 2009)|34/2899<br>(1,2%)|320/10.083<br>(3,2%)|RR 0,37<br>(0,26 a 0,52)|20<br>menos/1.000|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|||||(de 15 menos<br>a 23 menos)|
|Hutton et al., 2009|99/6.692<br>(1,5%)|145/6.692<br>(2,2%)|RR 0,68<br>(0,53 a 0,88)|7 menos/1.000<br>(de 3 menos a<br>10 menos)|
|Woodcock et al.,<br>1994|2/976<br>(0,2%)|11/2.928<br>(0,38%)|OR Ajustado<br>0,54|2 menos/1.000<br>(de 3 menos a|
||||(0,12 a 2,49) <sup>c</sup>|5 mais)|
|Lacerações vaginais/p|erineiais sem es|pecificargrau|||
|Ackermann-Liebrich<br>et al., 1996|65/207<br>(31,4%)<sup>f</sup>|29/207<br>(14%)<sup>f</sup>|RR 2,24<br>(1,51 a 3,32)|174<br>mais/1.000<br>(de 71 mais a<br>325 mais)|
|Lindgren et al., 2008|Lacerações<br>Vaginais<br>161/897<br>(17,9%)|Lacerações<br>Vaginais<br>3.577/11.341|RR Ajustado 0,7<br>(0,6 a 0,9)e|136<br>menos/1.000<br>(de 107 menos<br>a 161 menos|
||Lacerações<br>perineais<br>178/897<br>(19,8%)|Lacerações<br>perineais<br>2.587/11.341<br>(22,8%)|RR Ajustado 1,0<br>(0,8 a 1,3)e|30<br>menos/1.000<br>(de 55 menos<br>a 0 menos|
|Janssen et al., 2002)|388/862<br>(45%)|702/1.314<br>(53,4%)|RR 0,84<br>(0,77 a 0,92)|85<br>menos/1.000<br>(de 43 menos<br>a 123 menos)|
|Janssen et al., 2009)|1.321/2.899<br>(45,6%)|5.603/10.083<br>(55,6%)|RR 0,82<br>(0,79 a 0,86)|100<br>menos/1.000<br>(de 78 menos<br>a 117 menos)|
|Hutton et al., 2009|3.612/6.692<br>(54%)|4.081/6.692<br>(61%)|RR 0,89<br>(0,86 a 0,91)|67<br>menos/1.000<br>(de 55 menos<br>a 85 menos)|
|Dowswell et al.,|2/5|3/6|RR 0,8|100|
|1996(ERC)|(40%)|(50%)|(0,21 a 3,05)|menos/1.000|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|||||(de 395 menos<br>a 1.000 mais)|
|Mortalidadeperinatal|||||
||2/897<br>(0,22%)|7/11341<br>(0,06%)|RR 3,61<br>(0,75 a 17,36)g|1611<br>mais/1.000.00<br>0<br>(de 154 menos<br>a 10.098 mais)|
|Janssen et al., 2002)|3/860<br>(0,35%)|1/1296<br>(0,08%)|RR 4,52<br>(0,47 a 43,39)h|2716<br>mais/1.000.00<br>0<br>(de 409 menos<br>a 32.708 mais)|
|Janssen et al., 2009)|1/2.882<br>(0,03%)|6/10.017<br>(0,06%)|RR 0,58<br>(0,07 a 4,81)h|252<br>menos/1.000.0<br>00<br>(de 557 menos<br>a 2.282 mais)|
|van der Kooy et al.,<br>2011|Abordagem<br>natural<br>594/402.912<br>(0,15%)|Abordagem<br>natural<br>403/219.105<br>(0,18%)|OR Ajustado<br>1,05<br>(0,91 a 1,21)i|368<br>menos/1.000.0<br>00<br>(de 166 menos|
||Abordagem<br>perfeita das<br>diretrizes<br>344/363.568<br>(0,09%)|Abordagem<br>perfeita das<br>diretrizes<br>182/190.098<br>(0,1%)|OR Ajustado<br>1,11<br>(0,93 a 1,34)i|a 533 menos)|
|De Jonge et al., 2013|207/321.307<br>(0,06%)|116/163.261<br>(0,07%)|RR Ajustado 1,0<br>(0,78 to 1,27)j|64<br>menos/1.000.0<br>00<br>(de 199 menos<br>a 99 mais)|
|Morte fetal|||||
|Birthplace in|6/16.839|3/19.706|RR 2,34|204|
|England|(0,04%)|(0,02%)|(0,59 a 9,36)h|mais/1.000.00|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Collaborative Group,<br>2011||||0<br>(de 62 menos<br>a 1.273 mais)|
|Hutton et al., 2009|3/6.692<br>(0,04%)|4/6.692<br>(0,06%)|RR 0,75<br>(0,17 a 3,35)|149<br>menos/1,000,0<br>00<br>(de 496 menos<br>a 1.405 mais)|
|Woodcock et al.,<br>1994|2/976<br>(0,2%)|11/2.928<br>(0,38%)|RR 0,55<br>(0,12 a 2,46)|1.691<br>menos/1.000.0<br>00<br>(de 3.306<br>menos a 5.485<br>mais)|
|Davis et al., 2011|0/1.826<br>(0%)|0/11.448<br>(0%)|NC|NC|
|De Jonge et al., 2009|207/321.307<br>(0,06%)|116/163.261<br>(0,07%)|RR Ajustado 1,0<br>(0,78 to 1,27)j|64<br>menos/1.000.0<br>00<br>(de 199 menos<br>a 99 mais)|
|Blix et al., 2012|1/1631<br>(0,06%)|2/16.310<br>0,01%)|RR 5,0 (0,45 a<br>55,11)|490<br>mais/1.000.00<br>0<br>(67 menos a<br>6.635 mais)|
|Mortalidade neonatal|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|5/16.759<br>(0,03%)|5/19637<br>(0,025%)|RR 1,17<br>(0,34 a 4,05)h|143 mais/<br>1.000.000<br>(de 168 menos<br>a 777 mais)|
|Hutton et al., 2009|6/6.692<br>(0,09%)|4/6.692<br>(0,06%)|RR 1.5<br>(0,42 a 5.31)m|299<br>mais/1.000.00<br>0<br>(de 347 menos|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|||||a 2.576 mais)|
|Woodcock et al.,<br>1994|3/976<br>(0,31%)|1/2.928<br>(0,03%)|RR 9<br>(0,94 a 86,42)|2732<br>mais/1.000.00<br>0<br>(de 20 menos a<br>29.174 mais)|
|Davis et al., 2011|2/1.826<br>(0,11%)|4/11.448<br>(0,03%)|RR 3,13<br>(0,57 a 17,1)|744<br>mais/1.000.00<br>0<br>(de 150 menos<br>a 5.625 mais)|
|De Jonge et al., 2009|108/321.307<br>(0,03%)l|55/163.261<br>(0,03%)l|RR 1<br>(0,72 to 1,38)|0<br>menos/1.000.0<br>00<br>(de 94 menos a<br>128 mais)|
|Blix et al., 2012|1/1631<br>(0,06%)|15/16.310<br>(0,09%)|RR 0,67<br>(0,09 a 5,04)|303<br>menos/1.000.0<br>00<br>(de 837 menos<br>a 3.716 mais)|
|Pang et al., 2002<br>Admissão em Unidade|20/6.133<br>(0,33%)<br>de Terapia Inte|18/10.593<br>(0,17%)<br>nsiva Neonatal(UT|RR Ajustado<br>2,09<br>(1,09 a 3,97)d<br>IN)|1.563<br>mais/1.000.00<br>0<br>(de 34 mais a<br>4.469 mais)|
|Birthplace in<br>England<br>Collaborative Group,<br>2011|284/16.696<br>(1,7%)|543/19.642<br>(2,8%)|RR Ajustado<br>0,73<br>(0,52 a 1,01)a|11<br>menos/1.000<br>(de 8 menos a<br>13 menos)|
|De Jonge et al., 2009|540/321.307<br>(0,17%)|323/163.261<br>(0,2%)|RR Ajustado 1,0<br>(0,86 1 1,16)j|0 menos/1.000<br>(de 0 menos a<br>1 menos)|  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Hutton et al., 2009|102/6.692<br>(1,5%)|115/6.690<br>(1,7%)|RR 0,89<br>(0,68 a 1,16)|2 menos/1.000<br>(de 6 menos a<br>3 mais)|
|Woodcock et al.,<br>1994|13/976<br>(1,3%)|219/2.928<br>(7,5%)|RR 0,18<br>(0,1 a 0,31)|61<br>menos/1.000<br>(de 52 menos a<br>67 menos)|
|Morbidade e mortalid|adeperinatal co|mposta<sup>n</sup>|||
|Birthplace in<br>England|70/16.553<br>(0,42%)|81/19.551<br>(0,41%)|OR Ajustado<br>1,16|83 mais/ 1.000<br>(de 1.077|
|Collaborative Group,<br>2011|||(0,76 a 1,77)a|menos a 1.657<br>mais)|
|Hutton et al., 2009|159/6.692<br>(2,4%)|190/6.690<br>(2,8%)|RR 0,84<br>(0,68 a 1,03)|4.544<br>menos/1.000.<br>000<br>(de 9.088<br>menos a 852<br>mais)|
|Mulheres nulíparas|||||
|Birthplace in<br>England|39/4.488<br>(0,87%)|52/10.541<br>(0,49%)|OR Ajustado<br>1,75|3.749 mais/<br>1.000.000|
|Collaborative Group,<br>2011|||(1,07 a 2,86)|(de 789 mais a<br>8.189 mais)|
|Hutton et al., 2009|NR|NR|RR 0,94|NC|
||||(0,70 a 1,20)||
|Mulheres multíparas|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|31/12.050<br>(0,26%)|29/8.980<br>(0,32%)|OR Ajustado<br>0,72<br>(0,41 a 1,27)|646<br>menos/1.000.<br>000<br>(de 1.679<br>menos a 1.033<br>mais)|
|Hutton et al., 2009|NR|NR|RR 0,75<br>(0,56 a 1,00)|NC|
|Encefalopatia neonata|l(diagnóstico cl|ínico)|||  
Tabela 5: Sumário dos estudos e magnitude do efeito. Parto planejado no domicílio comparado com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado no<br>domicílio|Parto planejado<br>em uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Birthplace in England<br>Collaborative Group,<br>2011<br>Encefalopatia neonata|34/16.589<br>(0,2%)<br>l(sinais)<sup>o</sup>|34/19.587<br>(0,17%)|RR 1,18<br>(0,73 a 1,9)h|312<br>mais/1.000.000<br>(de 469 menos<br>a 1.562 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|4/16.840<br>(0,02%)|8/19.706<br>(0,04%)|RR 0,59<br>(0,18 a 1,94)h|166<br>menos/1.000.0<br>00<br>(de 333 menos<br>a 382 mais)|  
IC intervalo de confiança, NC não calculável, RR risco relativo, OR odds ratio  
a. Ajustado para idade materna, etnia, compreensão do Inglês, estado marital, índice de massa corporal, quintil do escore de privação, gestações prévias e semanas de gravidez e também ponderados para refletir a duração da participação na unidade e probabilidade de participarem da amostra  
b. Ajustado para paridade, IMC, tabagismo e nacionalidade.  
c. Ajustado para peso ao nascer e idade gestacional. Os desfechos de tipo de parto têm como referência uma odds ratio de 1 para parto vaginal espontâneo. Outros desfechos são relatados em relação à ausência do desfecho.  
d.Ajustado para paridade e incluindo apenas mulheres cujos recém-nascidos tinham pelo menos 37 semanas ao nascer.  
e.Ajustado para paridade, IMC, tabagismo, nacionalidade uso de peridural e ocitocina.  
f. Relatado como “lesão perineal.” 1 mulher (0,6%) no grupo de parto planejado no domicílio e 4 mulheres (2,4%) no grupo de pato planejado no hospital tiveram tanto lesões vaginais como perineais (diferenças não significativas: p=0,38).  
g. Definido como morte intraparto ou durante os primeiros 28 dias de vida. As duas mortes no grupo de parto domiciliar foram nos dias 1 e dia 19. As mortes no grupo de parto hospitalar foram nos dias 0 (n=3), dia 2 (n=1) e dia 19 (n=1).  
h. Definido como morte fetal após 20 semanas ou morte nos primeiros 7 dias de vida (Janssen et al., 2009) ou no período de hospitalização após o parto (Janssen et al., 2002). É relatado apenas para bebês sem anomalias congênitas.  
i. Ajustado para fatores maternos (incluindo paridade, idade, etnia e vizinhança), idade gestacional, presença de anomalias congênitas, pequeno para a idade gestacional, Apgar <7 em 5 minutos e prematuridade.  
j. Ajustado para paridade, idade gestacional, idade materna, etnia e estado sócio-econômico.  
k. Deve-se notar que este desfecho fez parte do desfechos compostos de morbidade/mortalidade no  
estudo Birthplace e que o estudo só teve poder suficiente para detectar diferenças nos resultados compostos e não nos seus componentes individuais.  
l. Calculado pela equipe técnica baseado nos dados relatados para o desfecho único de morte intraparto e o desfecho combinado de mortes intraparto e neonatais.  
m. Inclui 2 crianças no grupo de parto planejado no hospital com uma anomalia congênita maior (1 tumor cerebral, 1 cirrose hepática).  
n. Para o Birthplace in England Collaborative Group, 2011 o desfecho foi um composto de morte fetal após início dos cuidados no parto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula. Para Hutton et al, o resultado foi definido como a presença de um ou mais dos seguintes: morte perinatal, escore de Apgar <4 em 5 minutos, ressuscitação neonatal necessitando de ventilações por pressão positiva e compressões cardíacas, internação em UTIN ou cuidados intensivos pediátricos por mais de 4 dias, peso ao nascer <2500 g (excluindo 2 bebês com anomalias congênitas maiores no grupo de parto planejado no hospital).  
o. Definido como internação em uma unidade neonatal dentro de 48 horas do nascimento por pelo menos 48 horas com evidência de dificuldade para alimentar ou desconforto respiratório. 7.2.5.1 Resumo da evidência e conclusões  
As evidências demonstraram consistentemente que as mulheres que planejaram o parto no domicílio tiveram uma menor incidência de cesariana (n=112.837 participantes nos estudos que analisaram essa variável) e parto vaginal instrumental (n=98.158 participantes) e maiores taxas de parto vaginal espontâneo (n=100.184 participantes) em relação às mulheres que planejaram o parto em uma maternidade baseada em hospital. O risco de hemorragia pós-parto foi menor nas mulheres que planejaram o parto em casa em quatro estudos (n=44.307) e em outros dois (n=19.734) foi maior. Três estudos (n= 434.008) relataram uma redução do risco de hemorragia pós-parto grave nas mulheres que planejaram o parto em casa, enquanto que em outros (n=15.472) não houve diferenças. Dois grandes estudos (n=183.018) demonstraram que a taxa de transfusão de hemoderivados foi menor nas mulheres que planejaram o parto em casa mas, em outros dois (15.472) não houve diferenças. Em 6 estudos (n=77.542), as taxas de episiotomia foram consistentemente maiores nas mulheres que planejaram o parto em uma maternidade baseada em hospital e dois estudos (n=2.590) apresentaram evidências consistentes de maior chance de períneo intacto para as mulheres que planejaram o parto em casa. A maioria dos estudos (n=53.198) demonstrou maior risco de lacerações vaginais/perineais em geral entre as mulheres que planejaram o parto em uma maternidade baseada em hospital, em outro estudo (n=414) o resultado foi o contrário e outro (n=11) não encontrou diferenças, mas este último teve uma quantidade muito pequena de participantes. Três estudos (n=38.574) relataram um aumento de lacerações de terceiro e quarto grau entre as mulheres que planejaram o parto em uma maternidade baseada em hospital, mas outros três estudos (n=42.518) não relataram diferenças. Não houve nenhum caso de morte materna em nenhum dos locais analisados nos cinco estudos (n=75.578) que relataram este resultado.  
Nenhum estudo encontrou diferenças no risco de morte fetal ou perinatal entre os grupos. Cinco estudos (n=612.134) também não relataram diferenças no risco de morte neonatal. Um estudo (Pang et al., 2002) demonstrou um aumento no risco de mortalidade neonatal entre os recém-nascidos de mulheres que planejaram o parto em casa mas, o risco de vieses deste estudo compromete a confiabilidade dos seus resultados. Dada a raridade da mortalidade perinatal, nenhum dos estudos teve  
tamanho amostral suficiente para detectar diferenças quanto a este resultado. Outro estudo (n=36.172) não encontrou diferenças no risco de encefalopatia neonatal, mas esta variável fazia parte dos resultados compostos e o estudo não teve poder estatístico suficiente para detectar diferenças. Em relação à taxa de admissão em UTI, a evidência foi inconsistente, mas a maioria sugere que não houve diferenças no risco, com apenas um estudo (n=3.904) apontando um risco menor entre os recémnascidos das mulheres que planejaram o parto em casa.  
Um estudo, com poder estatístico suficiente para esta análise, apresentou resultados compostos de mortalidade e morbidade perinatal. Não houve diferenças entre os dois grupos quando todas as mulheres de baixo risco foram consideradas. Na análise de sub-grupo por paridade, os recém-nascidos das nulíparas que planejaram o parto em casa tiveram maior probabilidade de resultados adversos compostos. Para as multíparas, com ou sem complicações no início do trabalho de parto, não houve diferenças nos resultados entre os grupos.  
As taxas de transferência foram de 20-25%. Um dos estudos relatou que as transferências foram quatro vezes mais frequentes entre as nulíparas.  
7.2.5.2 Outras considerações  
Em relação aos benefícios clínicos e danos do dois locais estudados, a evidência demonstra benefícios consistentes para as mulheres que planejaram o parto no domicílio em relação à ocorrência de parto vaginal instrumental, cesariana e episiotomia. Em relação às taxas de trauma perineal, a evidência foi menos consistente, com resultados variáveis entre os estudos. Apesar dessa inconsistência, a maior proporção de mulheres com períneo intacto no grupo que planejou o parto no domicílio, demonstrada em dois estudos, sugere um  maior benefício para esse grupo. Em relação à ocorrência de hemorragia pós-parto e transfusão de hemoderivados, a evidência não foi consistente, demonstrando benefícios tanto para um como para o outro grupo, dependendo do estudo realizado. Em termos perinatais, a análise conjunta dos resultados não demonstra diferenças significativas em ambos os grupos em relação à mortalidade fetal e neonatal. Entretanto, para os recém-nascidos das nulíparas sem complicações no início do trabalho de parto houve um maior risco de resultados adversos compostos, embora a frequência, em termos absolutos, tenha sido muito baixa em ambos os grupos.  
Em relação aos benefícios para a saúde e utilização de recursos concluiu-se que o parto planejado no domicílio pode envolver custos menores, tendo em vista a menor ocorrência de intervenções e também por não envolver custos de hotelaria hospitalar. Por outro lado também, a necessidade de transferência do domicílio para uma maternidade baseada em hospital implicaria custos de ambulância. Dada a alta taxa de transferência entre as nulíparas, isso poderia envolver custos substanciais. Outras considerações em termos de utilização de recursos implica a realocação de enfermeiras obstétricas ou obstetrizes para prestar serviços nas comunidades e em ambientes não hospitalares, demandando maiores recursos para treinamento e uma reorganização da assistência. Dados os benefícios claros para o parto planejado no domicílio para as multíparas de baixo risco, uma mudança nessa direção poderia redundar em uma potencial economia de recursos no futuro.  
7.2.6 Centro de Parto Normal extra-hospitalar comparado com centro de parto normal intra ou peri-  
hospitalar conduzido por enfermeiras obstétricas  
Apenas um estudo foi incluído nas diretrizes do NICE de 2014 (Birthplace in England Collaborative Group, 2011)<sup>16</sup> . A análise comparativa entre os grupos incluiu 27.992 mulheres e demonstrou maiores taxas de parto vaginal espontâneo (n=27.970; RR = 1,04 IC 95% 1,03 – 1,05), menores taxas de parto vaginal instrumental (n=27.970; RR = 0,67 IC 95% 0,61 – 0,73), cesariana (n=27.970; RR = 0,82 IC 95%  
0,73 – 0,93), transfusão de hemoderivados (n=27.778; RR = 0,73 IC 95% 0,54 – 0,97), episiotomia (n=27.964; RR = 0,7 IC 95% 0,65 – 0,75) e lacerações de terceiro e quarto graus (n=27.916; RR = 0,72 IC 95% 0,62 – 0,83) no grupo de parto planejado em um CPN extra-hospitalar conduzido por Enfermeiras obstétricas ou obstetrizes . Não houve registro de mortes maternas em nenhum dos grupos.  
Em termos neonatais, não houve diferenças entre os grupos nos resultados compostos adversos (n=27.723; RR = 1,04 IC 95% 0,7 – 1,55) nos dois grupos, mesmo na análise de sub-grupo por paridade. Também não houve diferenças na ocorrência de sinais de encefalopatia neonatal (n=27.992; RR = 0,74 IC 95% 0,14 – 4,04)  e internação em UTI (n=27.837; RR = 0,93 IC 95% 0,78 – 1,11) .  
As taxas de transferências foram similares em ambos os grupos, sendo 3 a 4 vezes mais comuns em nulíparas.  
7.2.6.1 Outras considerações  
Em relação aos benefícios clínicos e danos do dois locais estudados, a evidência demonstra benefícios consistentes para as mulheres que planejaram o parto em um CPN extra-hospitalar conduzido por Enfermeiras obstétricas ou obstetrizes em relação à ocorrência de parto vaginal instrumental, cesariana, episiotomia, lacerações perineais de terceiro e quarto graus e transfusão de hemoderivados. Em termos perinatais, não houve diferenças entre os grupos em relação aos resultados adversos compostos. Entretanto, o estudo analisado não teve poder estatístico  suficiente para detectar diferenças nos resultados de mortalidade e encefalopatia neonatal. Por outro lado, deve ser lembrado que para detectar essas diferenças será necessário conduzir um estudo com grande tamanho amostral, o que é muito difícil.  
Em relação aos benefícios para a saúde e utilização de recursos concluiu-se que o parto planejado em um centro de parto normal extra-hospitalar pode envolver custos menores, tendo em vista a menor ocorrência de intervenções. Por outro lado também, a necessidade de transferência para uma maternidade baseada em hospital necessitaria de ambulância, aumentando os custos em relação a um CPN intra ou peri-hospitalar. Outras considerações em termos de utilização de recursos seria a instalação de unidades extra-hospitalares em áreas pouco populosas onde a oferta de vagas seria maior do que a demanda e portanto, não viável economicamente.  
7.2.7 Centro de Parto Normal extra-hospitalar comparado com maternidade baseada em hospital Para essa comparação, as diretrizes inglesas incluíram cinco estudos de coorte prospectivos conduzidos na Inglaterra (Birthplace in England Collaborative Group, 2011<sup>16</sup> ), Dinamarca (Overgaard et al., 2011<sup>32</sup> ) e EUA (Jackson et al., 2003<sup>33</sup> ; Scupholme et al., 1986<sup>34</sup> ; Stone, 1998<sup>35</sup> ) e outros três  estudos de coorte retrospectivos conduzidos na Alemanha (David et al., 1999<sup>36</sup> ), EUA  (Feldman & Hurst, 1987<sup>37</sup> ) e Nova Zelândia (Davis et al., 2011<sup>17</sup> ).  
Todas as análises nos dois grupos foram por intenção de tratar. Um dos estudos avaliou os resultados pelo local de agendamento do parto durante o pré-natal (Jackson et al., 2003<sup>33</sup> ) e os outros pelo local de intenção do parto no início do trabalho de parto.  
Os estudos pretendiam restringir suas populações às mulheres de baixo risco mas, como algumas delas tinham complicações, foram consideradas de alto risco e fora do escopo das diretrizes. Também foram encontradas algumas diferenças nas características das mulheres que planejaram o parto em um centro de parto normal extra-hospitalar e aquelas que planejaram o parto em uma maternidade baseada em hospital. Três estudos fizeram ajustes para variáveis de confusão (Birthplace in England Collaborative Group, 2011<sup>16</sup> ; Davis et al., 2011<sup>17</sup> ; Jackson et al., 2003<sup>33</sup> ) e outros três minimizaram as diferenças entre os grupos por características sócio-demográficas, critérios de risco ou uma combinação de fatores

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: diferentes. -->
Ver tabela 6 para os resultados e magnitude do efeito para as diversas variáveis estudadas. Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se|Absoluto<br>(IC 95%)|
||||declarado])||
|Mortalidade Materna|||||
|Birthplace in England<br>Collaborative Group,<br>2011|0/11.282<br>(0%)|0/19.706<br>(0%)|NC|NC|
|Feldman & Hurst,<br>1987|0/77<br>(0%)|0/72<br>(0%)|NC|NC|
|Scupholme et al.,<br>1986|0/250<br>(0%)|0/250<br>(0%)|NC|NC|
|David et al., 1999|0/801<br>(0%)|1/3.271<br>(0,03%)|RR 1.36<br>(0.06 to 33.35)|110 /1.000.000<br>(de 287 menos a|
|||||9.890 mais)|
|Tipo departo:parto va|ginal espontâne|o|||
|Birthplace in England<br>Collaborative Group,<br>2011|10.150/11.28<br>0<br>(90%)|14.645/19.68<br>8<br>(74,4%)|OR Ajustado<br>3,38<br>(IC 99% 2,7 a<br>4,25)<sup>a</sup>|156 mais/1.000<br>(de 149 mais a<br>164 mais)|
|Davis et al., 2011|2.722/2.873<br>(94,7%)|9.195/11.448<br>(80,3%)|RR 1,18<br>(1,16 a 1,19)|145 mais/1.000<br>(de 129 mais a<br>153 mais)|
|Overgaard et al.,<br>2012)|796/839<br>(94,9%)|751/839<br>(89,5%)|RR 1,06<br>(1,03 a 1,09)|54 mais/1.000<br>(de 27 mais a 81<br>mais)|
|Jackson et al., 2003|1.462/1.808<br>(80,9%)|720/1.149<br>(62,7%)|Diferença<br>ajustada de<br>risco (DR) 14,9<br>(11,5 a 18,3)<sup>b</sup>|182 mais/1.000<br>(de 144 mais a<br>226 mais)|
|Feldman & Hurst,<br>1987|87,9%<sup>c</sup>|45.0%<sup>c</sup>|NC|Difference 42,9<sup>c</sup>|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Scupholme et al.,<br>1986|92%|83%|NC|p=0.005 – 0,01<br>para todos os<br>tipos departo|
|David et al., 1999|91,4%|84,3%|NC|p<0,001|
|Tipo departo:parto va|ginal instrumen|tal|||
|Birthplace in England<br>Collaborative Group,<br>2011|686/11.280<br>(6,1%)|2.842/19.688<br>(14,4%)|OR Ajustado<br>Ventosa: 0,32<br>(IC 99% 0,22 A<br>0,47)<sup>a</sup><br>Fórceps: 0,45<br>(IC 99% 0,32<sup>a</sup><br>0,63)<sup>a</sup>|84 menos/1.000<br>(de 78 menos a<br>88 menos)|
|Davis et al., 2011|58/2.873<br>(2%)|1018/11.448<br>(8,9%)|RR 0,23<br>(0,17 a 0,29)<sup>d</sup>|68 menos/1.000<br>(de 63 enos a 74<br>menos|
|Overgaard et al.,<br>2012)|25/839<br>(3%)|61/839<br>(7,3%)|RR 0,41<br>(0,26 a 0,65)|43 menos/1.000<br>(de 25 menos a<br>54 menos)|
|Jackson et al., 2003|151/1.808<br>(8,4%)|208/1.149<br>(18,1%)|DR ajustada<br>-9,7<br>(-12,5 a -6,9)<sup>b</sup>|98 menos/1.000<br>(de 80 menos a<br>112 menos)|
|Feldman & Hurst,<br>1987|5,6%|43,7%|NC|p<0,0001|
|Scupholme et al.,<br>1986|2%|3%|NC|p=0.005 – 0,01<br>para todos os<br>tipos departo|
|David et al., 1999|5%|11%|NC|p<0,001|
|Tipo departo: cesarian|a||||
|Birthplace in England<br>Collaborative Group,<br>2011|405/11.280<br>(3.6%)|2.158/19.688<br>(11%)|OR Ajustado<br>0,32<br>(IC 99% 0,24<sup>a</sup>|73 menos/1.000<br>(de 70 menos a<br>77 menos)|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
||||0,42)a||
|Davis et al., 2011|91/2.873<br>(3,2%)|1.232/11.448<br>(10,8%)|RR 0,29<br>(0,24 a 0,36)<sup>d</sup>|76 menos/1.000<br>(de 69 menos a<br>82 menos)|
|Overgaard et al.,<br>2012)|19/839<br>(2,3%)|34/839<br>(4,1%)|RR 0,56<br>(0,32 to 0,97)|18 menos/1.000<br>(de 1 menos a 28<br>menos)|
|Jackson et al., 2003|194/1.808<br>(10,7%)|219/1.149<br>(19,1%)|DR ajustada<br>-4,7<br>(-7,3 a -2,2)<sup>b</sup>|84 menos/1.000<br>(de 63 menos a<br>101 menos)|
|Feldman & Hurst,<br>1987|5/77e<br>(6,5%)|8/71e<br>(11,3%)|RR 0,58<br>(0,2 to 1,68)|47 menos/1.000<br>(de 90 menos a<br>77 mais)|
|Scupholme et al.,<br>1986|15/250f<br>(6%)|35/250f<br>(14%)|RR 0,43<br>(0,24 a 0,76)|80 menos/1.000<br>(de 34 menos a<br>106 menos)<br>p=0.005 – 0,01<br>para todos os<br>tipos departo|
|David et al., 1999|3,0%|4,6%|NC|p=0,057|
|Uso deperidural|||||
|Birthplace in England<br>Collaborative Group,<br>2011|1.251/11.251<br>(11,1%)|5.817/19.576<br>(29,7%)|OR Ajustado<br>0,27<br>(IC 99% 0,22 a<br>0,34)<sup>a</sup>|187 menos/1000<br>(de 178 menos a<br>193 menos)|
|Overgaard et al.,<br>2012)|35/839<br>(4,2%)|86/839<br>(10,3%)|RR 0,41<br>(0,28 a 0,6)|60 menos/1.000<br>(de 41 menos a<br>74 menos)|
|Jackson et al., 2003|522/1.779<br>(29,3%)|742/1.089<br>(68,1%)|DR ajustada<br>-35,7<br>(-39,5 a -31,8)<sup>b</sup>|388 menos/1.000<br>(de 361 menos a<br>409 menos)|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|<br>Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Feldman & Hurst,<br>1987|4/77e<br>(5,2%)|40/71e<br>(56,3%)|RR 0,09<br>(0,03 a 0,24)|513 menos/1.000<br>(de 428 menos a|
|||||546 menos)|
|Medidas deperda san|guínea: hemor|ragiapós-parto(q|ualquer)||
|Overgaard et al.,<br>2012)|29/839<br>(3,5%)|68/839<br>(8,1%)|RR 0,43<br>(0,28 a 0,65)|46 menos/1.000<br>(de 28 menos a<br>58 menos)|
|Feldman & Hurst,<br>1987|2/72 <br>(2,8%)|1/63<br>(1,6%)|RR 1,75<br>(0,16 a 18,84)|12 mais/1.000<br>(de 13 menos a<br>283 mais)|
|Scupholme et al.,<br>1986|5%|1,4%|NC|p-value NR|
|<br>Medidas deperda san<br>|guínea: hemor<br>|ragiapós-parto m<br>|aior(> 1.000 ml)||
|Overgaard et al.,<br>2012)|11/839<br>(1,3%)|14/839<br>(1,7%)|RR 0,79<br>(0,36 a 1,72)|4 menos/1.000<br>(de 11 menos a|
|||||12 mais)|
|Davis et al., 2011|Taxas dos ev<br>tendo a cent<br>enfermeiras<br>como referên<br>Hospital secu<br>RR 1,20 (IC 9<br>RR ajustado<br>Hospital terci<br>RR 1,47 (IC 9<br>RR Ajustado|entos não relatad<br>ro de parto norma<br>obstétricas ou obs<br>cia.<br>ndário comparad<br>5% 0,80 a 1,79)<br>1,20 (IC 95% 0,80<br>ário comparado c<br>5% 0,96 a 2,24)<br>1,39(IC 95% 0,90|as. RR calculado<br>l conduzido por<br>tetrizes (CPNEO)<br>o com CPNEO:<br>a 1,81)<sup>f</sup><br>om CPNEO:<br>a 2,16)<sup>f</sup>|NC|
|Medidas deperda san|guínea: necess|idade de hemotra|nsfusão||
|Birthplace in England<br>Collaborative Group,<br>2011|67/11.230<br>(0,6%)|241/19.579<br>(1,2%)|OR ajustado<br>0,48<br>(IC 99% 0,32 a<br>0,73)<sup>a</sup>|6 menos/1.000<br>(de 5 menos a 8<br>menos)|
|Episiotomia|||||  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|<br>Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Birthplace in England<br>Collaborative Group,<br>2011|995/11.275<br>(8,8%)|3.780/19.678<br>(19,2%)|OR Ajustada<br>0,40<br>(IC 99% 0,32 a<br>0,51)<sup>a</sup>|104 menos/1.000<br>(de 98 menos a<br>109 menos)|
|Davis et al., 2011|Taxas dos eve<br>tendo o centr<br>enfermeiras o<br>como referên<br>Hospital secu<br>RR 2,10 (IC 95<br>RR ajustado 1<br>Hospital terci<br>RR 3,97 (IC 95<br>RR Ajustado 2|ntos não relatad<br>o de parto norma<br>bstétricas ou obs<br>cia.<br>ndário comparad<br>% 1,72 a 2,56)<br>,88 (IC 95% 1,54<br>ário comparado c<br>% 3,25 a 4,85)<br> ,91(IC 95% 2,37|as. RR calculado<br>l conduzido por<br>tetrizes (CPNEO)<br>o com CPNEO:<br>a 2,3)<sup>d</sup><br>om CPNEO:<br>a 3,57)<sup>d</sup>|NC|
|Jackson et al., 2003|209/1.779<br>(11,7%)|348/1.089<br>(32%)|DR ajustada<br>-22,5<br>(-26,4 a -18,5)<sup>b</sup>|201 menos/1.000<br>(de 182 menos a<br>217 menos)|
|Feldman & Hurst,<br>1987|47,2%|78,1%|NC|p<0,0001|
|David et al., 1999|15,7%|54,8%|NC|p<0,001|
|Stone, 1998|4/54<br>(7,4%)|29/52<br>(55,8%)|RR 0,13<br>(0,05 a 0,35)|485 menos/1.000<br>(de 362 menos a|
|||||530 menos)|
|Períneo ou canal depa|rto intacto||||
|Overgaard et al.,<br>2012)|514/839<br>(61,3%)|466/839<br>(55,5%)|RR 1,1<br>(1,02 to 1,2)|56 mais/1.000<br>(de 11 mais a 111<br>mais)|
|Feldman & Hurst,<br>1987|18/77<sup>e</sup><br>(23,4%)|4/72<sup>e</sup><br>(5,6%)|RR 4,21<br>(1,50 a 11,84)|167 mais/1.000<br>(de 28 mais a 602<br>mais)|
|David et al., 1999|30%|22%|NC|p<0,001|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Stone, 1998|12/54<br>(22,2%)|4/52<br>(7,7%)|RR 2,89<br>(1 a 8,39)|145 mais/1.000<br>(de 0 menos a|
|||||568 mais) p≤0,01|
|Laceraçõesperineiais|de 3<sup>o</sup>ou 4<sup>o</sup> grau||||
|Birthplace in England<br>Collaborative Group,<br>2011|259/11.262<br>(2,3%)|625/19.638<br>(3,2%)|RR Ajustado<br>0,78<br>(IC 99% 0,58 a<br>1,05)a|9 menos/1.000<br>(de 5 menos a 12<br>menos)|
|Overgaard et al.,<br>2012)|19/839<br>(2,3%)|24/839<br>(2,9%)|RR 0,79<br>(0,44 a 1,43)|6 menos/1.000<br>(de 16 menos a<br>12 mais)|
|Feldman & Hurst,<br>1987|7/77<sup>e</sup><br>(9,1%)|6/72<sup>e</sup><br>(8,3%)|RR 1,09<br>(0,38 a 3,09)|8 mais/1.000<br>(de 52 menos a<br>174 mais)|
|David et al., 1999|0,9%|1,1%|NC|p=0,24|
|Stone, 1998|0/54<br>(0%)|2/52<br>(3,8%)|RR 0,19<br>(0,01 a 3,92)|31 menos/1.000<br>(de 38 menos a|
|Lacerações vaginais/p|<br>erineiais sem es|<br>pecificargrau||<br>112 mais)|
|Overgaard et al.,<br>2012)|309/839<br>(36,8%)|361/839<br>(43%)|RR 0,86<br>(0,76 a 0,96)|60 menos/1.000<br>(de 17 menos a|
|||||103 menos)|
|Davis et al., 2011|Taxas dos even<br>tendo o centro<br>enfermeiras ob<br>como referênci<br>Hospital secun<br>RR 0,95 (IC 95%<br>RR ajustado 0,8<br>Hospital terciár<br>RR 1,27 (IC 95%<br>RR Ajustado 0,|tos não relatada<br>de parto norma<br>stétricas ou obs<br>a.<br>dário comparad<br>0,7 a 1,04)<br>3 (IC 95% 0,76 a<br>io comparado c<br>1,15 a 1,40)<br>91(IC 95% 0,82|s. RR calculado<br>l conduzido por<br>tetrizes (CPNEO)<br>o com CPNEO:<br>0,91)<sup>f</sup><br>om CPNEO:<br>a 1,02)<sup>e</sup>|NC|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Feldman & Hurst,<br>1987|26/77<sup>e</sup><br>(33,8%)|10/72<sup>e</sup><br>(13,9%)|RR 2,43<br>(1,26 a 46,8)|199 mais/1.000<br>(de 36 mais a 511<br>mais)|
|Stone, 1998|35/54<br>(64,8%)|18/52<br>(34,6%)|RR 1,87<br>(1,23 a 2,86)|301 mais/1.000<br>(de 80 mais a 644|
|||||mais)|
|Complicações materna<br>Intraparto|s<sup>g</sup>||||
|Jackson et al., 2003|329/1.808<br>(18,2%)|201/1.149<br>(17,5%)|DR ajustada<br>0,8|7 menos/1.000<br>(de 19 menos a|
||||(-2,4 a 4,0)<sup>b</sup>|38 menos)|
|Pós-parto|||||
|Jackson et al., 2003|14/1.808<br>(0,77%)|4/1.149<br>(0,35%)|DR ajustada<br>0,6|4 mais/1.000<br>(de 1 menos a 20|
||||(-4,2 a 5,3)<sup>b</sup>|mais)|
|Reinternação materna|ou consulta no|pós-parto imedi|ato||
|Overgaard et al.,<br>2012)|24/839<br>(2,9%)|40/839<br>(4,8%)|RR 0,6<br>(0,37 a 0,99)|19 menos/1.000<br>(de 0 menos a 30<br>menos)|
|Jackson et al., 2003|8/1.808<br>(0,44%)|11/1.149<br>(0,96%)|DR ajustada<br>-0,9<br>(-4,8 a 3,0)<sup>b</sup>|5 menos/1.000<br>(de 8 menos a 1<br>mais)|
|Scupholme et al.,<br>1986|0/250<br>(0%)|0/250<br>(0%)|NC|NC|
|Morte fetal|||||
|Birthplace in England<br>Collaborative Group,<br>2011|4/11.282<br>(0,04%)|3/19.706<br>(0,02%)|RR 2,33<br>(0,52 a 10,4)<sup>h</sup>|202<br>mais/1.000.000<br>(de 73 menos a<br>1.431 mais)|
|Davis et al., 2011|0/2.873<br>(0%)|0/11448<br>(0%)|NC|NC|
|Jackson et al., 2003|0,4%|0,4%|NC|DR 0,0<br>(−0,5 a 0,4)|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Feldman & Hurst,<br>1987|0/77<br>(0%)|1/72<br>(1,4%)|RR 0,31<br>(0,01 a 7,54)|9.583<br>menos/1.000.000<br>(de 13.750 menos<br>a 90.833 mais)|
|David et al., 1999|0/801<br>(0%)|1/3271<br>(0,03%)|RR 1,36<br>(0,06 a 33,35)|110<br>mais/1.000.000<br>(de 287 menos a<br>9.890 mais)|
|Mortalidade neonatal|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|5/11.263<br>(0,04%)|5/19.637<br>(0,03%)|RR 1,74<br>(0,5 a 6,02)<sup>h</sup>|188<br>mais/1.000.000<br>(de 127 menos a<br>1.278 mais)|
|Overgaard et al.,<br>2012)|1/839<br>(0,12%)|0/839<br>(0%)|RR 3<br>(0,12 a 73,54)<sup>J</sup>|NC|
|Davis et al., 2011|0/2.873<br>(0%)|4/11.448<br>(0,03%)|RR 0,44<br>(0,02 a 8,22)|196<br>menos/1.000.000<br>(de 342 menos a<br>2.523 mais)|
|Jackson et al., 2003|0,2%|0,3%|NC|DR −0.1<br>(−0,5 a 0,3)|
|Feldman & Hurst,<br>1987|0/77<br>(0%)|0/72<br>(0%)|NC|NC|
|David et al., 1999|0/801<br>(0%)|2/3.271<br>(0,06%)|RR 0,82<br>(0,04 a 16,98)|110<br>menos/1.000.000<br>(de 587 menos a<br>9.771 mais)|
|Admissão em Unidade|de Terapia Inte|nsiva Neonatal(|UTIN)||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|194/11.257<br>(1,7%)|543/19.642<br>(2,8%)|RR Ajustado<br>0,61<br>(0,40 a 0,91)<sup>a</sup>|11 menos/1000<br>(de 7 menos a 13<br>menos)|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de|mulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|<br>Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Overgaard et al.,<br>2012)|28/839<br>(3,3%)|42/839<br>(5%)|RR 0,67<br>(0,42 a 1,07)|17 menos/1.000<br>(de 29 menos a 4<br>mais)|
|Davis et al., 2011|Taxas dos eve<br>tendo o centr<br>enfermeiras<br>como referên<br>Hospital secu<br>RR 1,40 (IC 95<br>RR ajustado 0<br>Hospital terci<br>RR 1,87 (IC 95<br>RR Ajustado|ntos não relatada<br>o de parto norma<br>obstétricas ou obs<br>cia.<br>ndário comparad<br>% 1,05 a 1,91)<br>,83 (IC 95% 0,76<br>ário comparado c<br>% 1,39 a 2,53)<br>1,78(IC 95% 1,31|s. RR calculado<br>l conduzido por<br>tetrizes (CPNEO)<br>o com CPNEO:<br>a 1,87)<sup>f</sup><br>om CPNEO:<br>a 2,42)<sup>f</sup>|NC|
|Jackson et al., 2003|171/1.808<br>(9,5%)j|134/1.149<br>(11,7%)j|DR ajustada<br>-1.3<br>(-3.8 a 1.1)<sup>b</sup>|22 menos/1.000<br>(de 41 menos a 0<br>mais)|
|Feldman & Hurst,<br>1987|1/77<sup>e</sup><br>(1,3%)|4/72<sup>e</sup><br>(5,6%)|RR 0,23<br>(0,03 a 2,04)|43 menos/1.000<br>(de 54 menos a<br>58 mais)|
|David et al., 1999|2,6%|2,0%|NC|p=0,39|
|Morbidade e mortalid|adeperinatal c|omposta<sup>k</sup>|||
|Birthplace in<br>England|41/11.199<br>(0,37%)|81/19.551<br>(0,41%)|OR Ajustado<br>0,92|497<br>menos/1.000.000|
|Collaborative Group,<br>2011|||(0,58 a 1,46)<sup>a</sup>|(de 1.616 menos<br>a 1.201 mais)|
|Jackson et al., 2003|80/1.808<br>(4,4%)j|73/1.149<br>(6,4%)|DR ajustada<br>-1.8<br>(-3.8 a 0.1)<sup>b</sup>|19.060<br>menos/1.000.000<br>(de 3.177 menos<br>a 31.131 menos)|
|Mulheres nulíparas|||||
|Birthplace in|24/5.158|52/10.541|OR Ajustado|296|
|England|(0,47%)|(0,49%)|0,91|menos/1.000.000|
|Collaborative Group,|||(0,52 a 1,60)<sup>a</sup>|(de 2.072 menos|  
Tabela 6: Sumário dos estudos e magnitude do efeito. Parto planejado em um centro de parto normal extra-hospitalar (CPNE) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>um CPNE|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|2011||||a 2.615 mais)|
|Mulheres multíparas|||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|17/6.025<br>(0,28%)|29/8.980<br>(0,32%)|OR Ajustado<br>0,91<br>(0,46 a 1,80)|420<br>menos/1.000.000<br>(de 1.679 menos<br>a 1.905 mais)|
|Encefalopatia neonata|l(diagnóstico clí|nico)|||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|17/11.210<br>(0,15%)|34/19.587<br>(0,17%)|RR 0,87<br>(0,49 a 1,56)<sup>h</sup>|226<br>menos/1.000.000<br>(de 885 menos a<br>972 mais)|
|Encefalopatia neonata|l(sinais)<sup>l</sup>||||
|Birthplace in<br>England<br>Collaborative Group,<br>2011|2/11.282<br>(0,02%)|8/19.706<br>(0,04%)|RR 0,44<br>(0,09 a 2,06)<sup>h</sup>|227<br>menos/1.000.000<br>(de 369 menos a<br>430 mais)|  
IC intervalo de confiança, NC não calculável, RR risco relativo, OR odds ratio, DR diferença de risco, CPNEO unidade conduzida por Enfermeiras obstétricas ou obstetrizes MH maternidade baseada em hospital baseada em hospital/maternidade  
a. Ajustado para idade materna, etnia, compreensão do Inglês, estado marital, índice de massa corporal, quintil do escore de privação, gestações prévias e semanas de gravidez e também ponderados para refletir a duração da participação na unidade e probabilidade de participarem da amostra  
b. Ajustado para raça/etnia, paridade e história de cesariana, educação, estado marital, país de origem, altura e tabagismo durante a gravidez  
c. Calculado pela equipe técnica baseado nos desfechos relatados no estudo os quais são qualquer parto vaginal (72/77 [93,5%]no braço da unidade conduzida por Enfermeiras obstétricas ou obstetrizes - CPNEO 63/71 [88.7%] no braço hospitalar [diferenças não significativas]) e fórceps (5,6% no braço da CPNEO e 43,7% no braço hospitalar [p<0,0001, eventos crus não calculáveis]) .  
d. Os autores relatam uma análise que foi ajustada para idade materna, paridade, etnia e tabagismo. As razões ajustadas de risco não foram relatadas na tabela porque elas são relatadas com a unidade de enfermagem obstétrica ou obstetriz (CPNEO) como grupo de referência ao invés de outra forma. Elas não mudam a significância dos efeitos. Os RR ajustados para a unidade secundária comparado com a  
CPNEO foram 4,11 (IC 95%  2,86 a 5,91) para vácuo-extração, 2,57 (IC 95% 1,66 a 3,97) para fórceps e 2,73 (IC 95% 2,17 a 3,44) para cesariana de emergência. Os RR ajustados para a unidade terciária comparado com a CPNEO foram 6,12 (IC 95%  4,24 a 8,84) para vácuo-extração, 5,41 (IC 95% 3,51 a 8,33) para fórceps e 4,62 (IC 95% 3,66 a 5,84) para cesariana de emergência.  
e. Taxa crua do evento calculada pela equipe técnica baseado no % e informação do denominador relatada no estudo.  
f. Ajustado para idade materna, paridade, etnia e tabagismo  
g. Complicações intraparto: prolapso de cordão, placenta prévia, descolamento de placenta, hipertensão grave induzida pela gravidez com eclâmpsia, mecônio espesso, prematuridade (<34 semanas), ruptura de cicatriz uterina, hemorragia ≥1.000 ml, distócia de ombro, laceração perineal de quarto grau, laceração cervical necessitando reparo, morte intra-uterina ou outras. Complicações pósparto: complicações anestésicas, coagulação intravascular disseminada, embolia pulmonar, hematoma, hipertensão grave induzida pela gravidez com eclâmpsia, morte materna ou outras.  
h. Deve-se notar que este desfecho fez parte do desfechos compostos de morbidade/mortalidade no estudo Birthplace e que o estudo só teve poder suficiente para detectar diferenças nos resultados compostos e não nos seus componentes individuais.  
i. A morte de um recém-nascido com uma hérnia diafragmática grave não detectada ao ultrassom de 19,4 semanas. Os autores anotaram especificamente que o estudo não tinha poder suficiente para detectar diferenças neste desfecho.  
j. O estudo só incluiu nascidos vivos no denominador; entretanto, para o cálculo do risco relativo cru, a equipe técnica usou o denominador inteiro pois a exclusão de alguns bebês não ofereceu uma estimativa acurada do risco do local planejado para o parto. (Nota: ambas as análises forneceram riscos relativos similares e a análise ajustada está como relatada no estudo).  
k.Para Birthplace in England Collaborative Group, 2011 o desfecho foi um composto de morte fetal após início dos cuidados no parto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula. For Jackson et al., 2003,foi definido como convulsões, asfixia, infecção bacteriana além de sepse, displasia broncopulmonar, falência cardíaca, hipovolemia, hipotensão, choque, hemorragia intra-ventricular, enterocolite necrotizante, hipertensão pulmonar persistente, pneumonia, insuficiência renal, síndrome de desconforto respiratório, retinopatia da prematuridade, doença hemolítica Rh, sepse, idade gestacional >34 semanas ao nascer ou outras incluindo paralisia ou fratura.  
l. Definido como internação em uma unidade neonatal dentro de 48 horas do nascimento por pelo menos 48 horas com evidência de dificuldade para alimentar ou desconforto respiratório  
7.2.7.1 Resumo da evidência e conclusões  
Nas mais de 50.000 mulheres que participaram dos estudos a evidência demonstrou, de forma consistente, que o parto planejado em centros de parto normal extra-hospitalares, quando comparado ao planejado em uma maternidade baseada em hospital,  está associado a menores taxas de parto vaginal instrumental e portanto maiores taxas de parto vaginal espontâneo. Em relação à cesariana, a maioria dos estudos demonstrou maiores taxas entre as mulheres que planejaram o parto em uma maternidade baseada em hospital mas, mesmo aqueles que não encontraram diferenças estatísticas, mostraram a mesma tendência. As taxas de episiotomia foram maiores (6 estudos; n=47.163) assim como uma menor proporção de períneo intacto (n=18.037) entre as mulheres que planejaram o parto em uma maternidade baseada em hospital. A evidência foi consistente e nenhuma diferença foi  
encontrada no risco de laceração de terceiro ou quarto grau (n=49.038). Entretanto, em se tratando de qualquer trauma perineal, houve uma variação, com alguns estudos (n=255) sugerindo maiores taxas entre as mulheres que planejaram o parto em um centro de parto normal extra-hospitalar enquanto outro grande estudo (n=1.678) sugeriu o contrário. Em dois estudos (n=17.888) a evidência foi consistente e não demonstrou diferenças na ocorrência de hemorragia pós-parto grave entre os grupos. Outro estudo (n=30.809) entretanto, demonstrou uma maior taxa de transfusão de hemoderivados nas mulheres que planejaram o parto em uma maternidade baseada em hospital.  
Dois estudos (n=5.914) sugeriram que não houve diferenças nas complicações maternas entre os dois grupos. Outro estudo (n=1.678) demonstrou uma menor incidência de readmissão materna e consultas ambulatoriais no pós-parto entre as mulheres que planejaram o parto em um centro de parto normal extra-hospitalar e outro estudo demonstrou a mesma tendência.  
Um estudo (n=30.750) não encontrou nenhuma diferença nos resultados compostos de morbidade e mortalidade neonatal entre os dois grupos, mesmo na análise de sub-grupo por paridade. Diversos estudos, envolvendo ao todo mais de 30.000 mulheres, não encontraram diferenças nas taxas de mortalidade fetal ou neonatal, embora nenhum deles tivesse poder estatístico suficiente para detectar tal diferença. Outro estudo (n=30.797) não encontrou diferença no risco de encefalopatia neonatal mas também não tinha tamanho amostral suficiente para detectar diferença significativa. Em relação às taxas de admissão em UTIN, a evidência foi inconsistente: 4 estudos com mais de 4.000 mulheres não encontraram diferenças mas, 2 estudos com mais de 30.000 mulheres relataram maiores taxas entre os recém-nascidos de mulheres que planejaram o parto em uma maternidade baseada em hospital. As taxas de transferência variaram de cerca de 10 a 20%. Um estudo (n=64.538) relatou taxas 4 vezes maiores para as nulíparas em comparação com as multíparas. 7.2.7.2 Outras considerações  
Em relação aos benefícios clínicos e danos do dois locais estudados, a evidência demonstra benefícios consistentes para as mulheres que planejaram o parto em uma unidade de parto extra-hospitalar conduzida por Enfermeiras obstétricas ou obstetrizes em relação à ocorrência de parto vaginal instrumental, cesariana e episiotomia. Em relação às taxas de trauma perineal, a evidência foi menos consistente, com resultados variáveis entre os estudos. Apesar dessa inconsistência, a maior proporção de mulheres com períneo intacto no grupo que planejou o parto em uma unidade de parto extrahospitalar conduzida por enfermeiras obstétricas (diferenças significativas demonstradas em quatro estudos) além de uma menor taxa de episiotomia, sugere um  maior benefício para esse grupo. Em relação à ocorrência de hemorragia pós-parto e transfusão de hemoderivados, a evidência demonstrou benefícios para o grupo que planejou o parto em uma unidade de parto extra hospitalar. Em termos perinatais, a análise dos resultados não demonstra diferenças significativas em ambos os grupos em relação à mortalidade fetal e neonatal, embora nenhum dos estudos tivesse poder estatístico suficiente para detectar essas diferenças. Um grande estudo observacional realizado na Inglaterra teve poder estatístico suficiente para detectar resultados neonatais adversos compostos, não encontrando diferenças entre os grupos. O achado de maior internação em UTIN para os recém-nascidos de mulheres que planejaram o parto em uma maternidade baseada em hospital, demonstrado nesse mesmo estudo, pode estar relacionado ao fato de haver mais facilidade para admitir um recém-nascido em uma UTIN estando esse mais próximo da mesma ou mesmo a admissão por medidas de precaução. Por outro lado também, a necessidade de internação pode estar relacionada a maiores danos iatrogênicos, tendo em vista o maior risco de intervenções às quais as mulheres que planejaram o parto em uma maternidade

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: baseada em hospital foram submetidas. -->
Em relação aos benefícios para a saúde e utilização de recursos, conclui-se que o parto planejado em uma unidade de parto extra hospitalar pode envolver custos menores, tendo em vista a menor ocorrência de intervenções. Por outro lado também, a necessidade de transferência para uma maternidade baseada em hospital implicaria custos de ambulância. Outras considerações em termos de utilização de recursos implicaria na utilização adequada das centros de parto normal extra-hospitalares que deveriam contar com número adequado de profissionais para atender à demanda real. Unidades com equipes completas mas não utilizadas em sua plenitude seriam um desperdício de recursos. Adicionalmente, um centro de parto normal extra-hospitalar não pode funcionar sem uma maternidade baseada em hospital de referência e isso também dever ser levado em consideração na alocação de recursos. Apesar disso, considerando os benefícios já demonstrados, se mais mulheres de baixo risco tivessem o seu parto em um CPN extra-hospitalar, haveria economia de recursos. Outro modelo que poderia ser custo-efetivo seria a existência de centros de parto normal extra-hospitalares que funcionassem apenas quando existissem mulheres em trabalho de parto, permanecendo fechadas em caso contrário. A transferência de Enfermeiras obstétricas/obstetrizes das maternidades baseadas em hospital para centros de parto normal extra-hospitalares para cuidar de mulheres de baixo risco e consequentemente a redução de intervenções, também permitiria que os médicos nas maternidades baseadas em hospitais utilizassem mais as suas habilidades para lidar com as mulheres de alto risco e com aquelas transferidas de outros locais de parto.  
7.2.8 Centro de parto normal intra ou peri-hospitalar comparado com maternidade baseada em hospital As diretrizes do NICE incluíram 13 estudos nessa revisão. Nove dos estudos relataram resultados de 8 ensaios randomizados controlados, que foram conduzidos na Inglaterra (Chapman et al., 1986<sup>38</sup> ; MacVicar et al., 1993<sup>39</sup> ), Escócia (Hundley et al., 1994<sup>40</sup> ), Irlanda (Begley et al., 2011<sup>41</sup> ), Noruega (Bernitz et al., 2011<sup>42</sup> ), Suécia (Waldenstrom et al., 1997<sup>43</sup> ; Waldenstrom and Nilsson, 1997<sup>44</sup> [dois relatos do mesmo ensaio]), Canadá (Klein et al., 1984<sup>45</sup> ) e Austrália (Byrne et al., 2000<sup>46</sup> ). Os outros quatro estudos foram observacionais prospectivos que foram conduzidos na Ingalterra (Birthplace in England Collaborative Group, 2011<sup>16</sup> ; Campbell et al., 1999<sup>47</sup> ), França (Gaudineau et al., 2013<sup>48</sup> ) e Noruega (Eide et al., 2009<sup>49</sup> ).  
As análises em todos os estudos foram por intenção de tratar. Sete estudos avaliaram os resultados pelo agendamento do local do parto durante o pré-natal (Begley et al., 2011<sup>41</sup> ; Byrne et al., 2000<sup>46</sup> ; Campbell et al., 1999<sup>47</sup> ; Hundley et al., 1994<sup>40</sup> ; MacVicar et al., 1993<sup>39</sup> ; Waldenstrom et al., 1997<sup>43</sup> ; Waldenstrom & Nilsson, 1997<sup>44</sup> ) enquanto o restante pelo local de intenção do parto no início do trabalho de parto ou no início dos cuidados para o parto.  
Os estudos planejaram restringir suas populações às mulheres de baixo risco mas, como muitas foram alocadas durante o período pré-natal, uma proporção delas desenvolveram complicações no início do trabalho de parto, sendo consideradas de alto risco e fora do escopo das diretrizes (por exemplo, parto induzido).  
A tabela 7 apresenta os dados dos estudos e a magnitude do efeito dos locais de assistência ao parto analisados.  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
|Número de mulheres/bebês|Efeito|
|---|---|  
|Estudos|Parto|Parto|Relativo|Absoluto|
|---|---|---|---|---|
||planejado em<br>CPNI|planejado em<br>uma MH|(IC 95% [ou<br>outro se|(IC 95%)|
||||declarado])||
|Mortalidade Materna|||||
|Begley et al., 2011|0/1.101<br>(0%)|0/552<br>(0%)|NC|NC|
|Birthplace in England<br>Collaborative Group,|0/16.710<br>(0%)|0/19.706<br>(0%)|NC|NC|
|2011|||||
|Tipo departo:parto vag|inal espontâneo||||
|1 meta-análise de 5<br>estudos<br>(Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>MacVicar et al.,1993)|4.449/5.736<br>(77,6%)|2.632/3.472<br>(75,8%)|RR 1,04<br>(1,01 a 1,06)|30 mais/1.000<br>(de 8 mais a 45<br>mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|14.413/16.690<br>(86,4%)|14.645/19.68<br>8<br>(74.4%)|OR Ajustado<br>2,22<br>(IC 99% 1,76 a<br>2,81)<sup>a</sup>|119<br>mais/1.000<br>(de 112 mais a<br>126 mais)|
|Eide et al., 2009|205/252<br>(81,3%)|161/201<br>(80,1%)|RR 1,02<br>(0,93 a 1,11)<sup>a</sup>|16 mais/1.000<br>(de 56 menos<br>a 88 mais)|
|Campbell et al., 1999|657/782<br>(84%)|586/702<br>(83,5%)|RR 1,01<br>(0,96 a 1,05)|8 mais/1.000<br>(de 33 menos<br>a 42 mais)|
|Gaudineau et al., 2013|280/316<br>(88,6%)|737/890<br>(82,8%)|RR 1,07 (1,01 a<br>1,12)|58 mais/1.000<br>(de 8 mais a 99|
|||||mais)|
|Tipo departo:parto vag|inal instrumental||||
|1 meta-análise de 7<br>estudos<br>(Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>Klein et al.,<br>1984; MacVicar et al.,<br>1993; Waldenstrom et<br>al.,1997)|661/6.704<br>(9,9%)|477/4.446<br>(10,7%)|RR 0,89<br>(0,79 a 0,99)|12<br>menos/1.000<br>(de 1 menos a<br>23 menos)|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Birthplace in England<br>Collaborative Group,<br>2011|1.524/16.690<br>(9,1%)|2.842/19.688<br>(14,4%)|OR Ajustado<br>Ventosa: 0,56<br>(IC 99% 0,39 a<br>0,82)<sup>a</sup><br>Fórceps: 0,7<br>(IC 99% 0,46 a<br>1,05)<sup>a</sup>|53<br>menos/1.000<br>(de 48 menos<br>a 58 menos)|
|Eide et al., 2009|29/252<br>(11,5%)|24/201<br>(11,9%)|RR 0,96<br>(0,58 a 1,6)<sup>b</sup>|5 menos/1.000<br>(de 50 menos<br>a 72 mais)|
|Campbell et al., 1999|61/782<br>(7,8%)|71/702<br>(10,1%)|RR 0,77<br>(0,56 a 1,07)|23<br>menos/1.000<br>(de 45 menos<br>a 7 mais)|
|Gaudineau et al., 2013|28/316<br>(8,9%)|106/890<br>(11,9%)|RR 0,74 (0,50  a<br>1,10)|<br>31<br>menos/1.000<br>(60 menos a<br>12 mais)|
|Tipo departo: cesariana|||||
|1 meta-análise de 8<br>estudos<br>(Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Chapman et al.,<br>1986; Hundley et al.,<br>1994; Klein et al., 1984;<br>MacVicar et al., 1993;<br>Waldenstrom et al.,<br>1997)|563/6780<br>(8,3%)|403/4518<br>(8,9%)|RR 0,89<br>(0,78 a 1)|10<br>menos/1.000<br>(de 20 menos<br>a 0 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|727/16690<br>(4,4%)|2.842/19.688<br>(14,4%)|OR Ajustado:<br>0,39<br>(IC 99% 0,29 a|66<br>menos/1.000<br>(de 62 menos|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
||||0,53)<sup>a</sup>|a 69 menos)|
|Eide et al., 2009|16/252<br>(6,3%)|14/201<br>(7%)|RR 0,91<br>(0,46 a 1,82)<sup>b</sup>|6 menos/1.000<br>(de 38 menos<br>a 57 mais)|
|Campbell et al., 1999|63/782<br>(8,1%)|45/702<br>(6,4%)|RR 1,26<br>(0,87 a 1,82)|17 mais/1.000<br>(de 8 menos a<br>53 mais)|
|Gaudineau et al., 2013|8/316<br>(2,5%)|47/890<br>(5,3%)|RR 0,48 (0,23 a<br>1,00)|25<br>menos/1.000<br>(41 menos a 0<br>mais)|
|Uso deperidural|||||
|1 meta-análise de 7<br>estudos<br>Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>Klein et al., 1984;<br>MacVicar et al., 1993;<br>Waldenstrom et al.,<br>1997)|998/6.687<br>(14,9%)|847/4.424<br>(19,1%)|RR 0,8<br>(0,73 a 0,87)|38<br>menos/1.000<br>(de 25 menos<br>a 52 menos)|
|Birthplace in England<br>Collaborative Group,<br>2011|2.464/16.661<br>(14,8%)|5.817/19.576<br>(29,7%)|OR Ajustado<br>0,40<br>(IC 99% 0,32 a<br>0,50)<sup>a</sup>|149<br>menos/1000<br>(de 143 menos<br>a 155 menos)|
|Eide et al., 2009|61/252<br>(24,2%)|126/201<br>(62,7%)|RR 0,39<br>(0,3 to 0,49)<sup>b</sup>|382<br>menos/1.000<br>(de 320 menos<br>a 439 menos)|
|Campbell et al., 1999|107/782<br>(13,7%)|139/703<br>(19,8%)|RR 0,69<br>(0,55 a 0,87)|61<br>menos/1.000<br>(de 26 menos|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|||||a 89 emnos)|
|Medidas deperda sangu|ínea: hemorragia|pós-parto(qualq|uer)||
|1 meta-análise de 5<br>estudos<br>Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>MacVicar et al., 1993;<br>Waldenstrom et al.,<br>1997)|448/4.764<br>(9,4%)|391/3.391<br>(11,5%)|RR 0,92<br>(0,81 a 1,05)|9 menos/1.000<br>(de 22 menos<br>a 6 mais)|
|Campbell et al., 1999|51/770<br>(6,6%)|38/695<br>(5,5%)|RR 1,21<br>(0,81 a 1,82)|11 mais/1.000<br>(de 10 menos<br>a 45 mais)|
|Gaudineau et al., 2013|9/316<br>(2,9%)|46/890<br>(5,2%)|RR 0,55 (0,27 a<br>1,11|23<br>menos/1.000<br>(38 menos a 6<br>|
|||||mais)|
|Medidas deperda sangu|ínea: hemorragia|pós-parto maior|(> 1.000 ml)||
|Bernitz et al., 2011|7/412<br>(1,7%)|18/699<br>(2,6%)|RR 0,66<br>(0,28 a 1,57)|9 menos/1.000<br>(de 19 menos|
|||||<br>a 15 mais)|
|Medidas deperda sangu|ínea: necessidade|de hemotransfu|são||
|1 meta-análise de 2<br>estudos (MacVicar et<br>al., 1993; Waldenstrom<br>et al.,1997)|32/3.151<br>(1%)|22/2.040<br>(1,1%)|RR 0,87<br>(0,51 a 1,49)|1 menos/1.000<br>(de 5 menos a<br>5 mais)|
|Birthplace in England<br>Collaborative Group,|136/16.548<br>(0,82%)|241/19.579<br>(1,2%)|OR ajustado<br>0,75|4 menos/1.000<br>(de 2 menos a|
|2011|||(IC 99% 0,55 a|6 menos)|
||||1,02)<sup>a</sup>||
|Episiotomia|||||
|1 meta-análise de 7|1.239/6.704|951/4.446|RR 0,84|34|
|estudos|(18,5%)|(21,4%)|(0,78 a 0,91)|menos/1.000|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Efe|ito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|(Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>Klein et al., 1984;<br>MacVicar et al., 1993;<br>Waldenstrom et al.,<br>1997)||||(de 19 menos<br>a 47 menos)|
|Birthplace in England<br>Collaborative Group,<br>2011|2.098/16.689<br>(12,6%)|3.780/19.678<br>(19,2%)|OR Ajustado:<br>0,62<br>(IC 99% 0,50 a<br>0,77)<sup>a</sup>|67<br>menos/1.000<br>(de 60 menos<br>a 73 menos)|
|Eide et al., 2009|72/252<br>(28,6%)|73/201<br>(36,3%)|RR 0,79<br>(0,6 a 1,03)<sup>b</sup>|76<br>menos/1.000<br>(de 145 menos<br>a 11 mais)|
|Campbell et al., 1999|131/780<br>(16,8%)|173/702<br>(24,6%)|RR 0,68<br>(0,56 a 0,83)|79<br>menos/1.000<br>(de 42 menos<br>a 108 menos)|
|Gaudineau et al., 2013|22/316<br>(7,1%)|96/890<br>(11,4%)|RR 0,65 (0,41 a<br>1,00)|39<br>menos/1.000<br>(de 64 menos|
|||||a 0 mais)|
|Períneo intacto|||||
|1 meta-análise de 5<br>estudos<br>(Begley et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>Klein et al., 1984;|1.513/5.380<br>(28,1%)|731/2.831<br>(25,8%)|RR 1,05<br>(0.,89 a 1,24)|13 mais/1.000<br>(de 28 menos<br>a 62 mais)|
|MacVicar et al.,1993;)|||||
|Lacerações vaginais/peri|neiais sem especi|ficargrau|||  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|1 meta-análise de 4<br>estudos<br>(Byrne et al., 2000;<br>Hundley et al., 1994;<br>MacVicar et al., 1993;<br>Waldenstrom &<br>Nilsson,1997)|2.456/5.064<br>(48,5%)|1.480/3.036<br>(48,7%)|RR 1,07<br>(1,02 a 1,12)<sup>c</sup>|34 mais/1.000<br>(de 10 mais a<br>58 mais)|
|Campbell et al., 1999|338/780<br>(43,3%)|307/702<br>(43,7%)|RR 0,99<br>(0,88 a 1,11)|4 menos/1.000<br>(de 52 menos|
|||||a 48 mais)|
|Laceraçõesperineiais de|3<sup>o</sup>ou 4<sup>o</sup> grau||||
|1 meta-análise de 4<br>estudos<br>(Bernitz et al., 2011;<br>Hundley et al., 1994;<br>MacVicar et al., 1993;<br>Waldenstrom &<br>Nilsson,1997)|50/5.376<br>(0,93%)|36/3.635<br>(0,99%)|RR 1,17<br>(0,74 a 1,84)|2 mais/1.000<br>(de 3 menos a<br>8 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|535/16.654<br>(3,2%)|625/19.638<br>(3,2%)|RR Ajustado<br>0,78<br>(IC 99% 0,58 a<br>1,05)a|9 menos/1.000<br>(de 5 menos a<br>12 menos)|
|Eide et al., 2009|34/252<br>(13,5%)|22/201<br>(10,9%)|RR 1,23<br>(0,75 a 2,04)<sup>b</sup>|25 mais/1.000<br>(de 27 menos|
|Morbidade materna: bu<br>hospitalar)<sup>d</sup>|sca por assistênci|a 2 meses após o|parto (ambulato|a 114 mais)<br>rial ou|
|Waldenstrom &<br>Nilsson, 1997|181/883<br>(20,5%)|161/853<br>(18,9%)|RR 1,09<br>(0,9 a 1,31)|17 mais/1.000<br>(de 19 menos|
|<br>Morbidade materna:(pr|<br>oblemas significa|<br>tivos após opart|<br>o(não definidos)|<br>a 59 mais)|
|Campbell et al., 1999|83/776<br>(10,7%)|84/695<br>(12,1%)|RR 0,88<br>(0,67 a 1,18)|15<br>menos/1.000<br>(de 40 menos|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|Morteperinatal(morte i<br>Waldenstrom et al.,<br>1997|ntrauterina após<br>8/912<sup>e</sup><br>(0,88%)|22 semanas ou n<br>2/916<br>(0,22%)|eonatal até 7 dia<br>RR 4,02<br>(0,86 a 18,87)|a 22 mais)<br>s de vida)<br>6.594<br>mais/1.000.00<br>0<br>(de 306 menos<br>a 39.017 mais)|
|Morte fetal|||||
|1 meta-análise de 3<br>estudos<br>(Begley et al., 2011<br>Hundley et al., 1994;<br>MacVicar et al., 1993)|20/5.225<br>(0,38%)|9/2.676<br>(0,34%)|RR 1,11<br>(0,52 a 2,4)<sup>f</sup>|370<br>mais/1.000.00<br>0<br>(de 1.614<br>menos a 4.709<br>mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|1/16.708<br>(0,006%)|3/19.706<br>(0,02%)|RR 0,39<br>(0,04 a 3,78)<sup>g</sup>|93<br>menos/1.000.0<br>00<br>(de 146 menos<br>a 423 mais)|
|Mortalidade neonatal|||||
|1 meta-análise de 3<br>estudos<br>(Begley et al., 2011<br>Hundley et al., 1994;<br>MacVicar et al.,1993)|16/5.225<br>(0,31%)|4/2.676<br>(0,15%)|RR 1,86<br>(0,66 a 5,27)<sup>h</sup>|1.286<br>mais/1.000.00<br>0<br>(de 508 menos<br>a 6.383 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|3/16.633<br>(0,02%)|5/19.637<br>(0,03%)|RR 0,71<br>(0,17 a 2,96)<sup>g</sup>|74<br>menos/1.000.0<br>00<br>(de 211 menos<br>a 499 mais)|
|Admissão em Unidade d|e Terapia Intensiv|a Neonatal(UTIN|)||
|1 meta-análise de 7|501/6.705|362/4.449|RR 1,03|2 mais/1.000|
|estudos|(7,5%)|(8,1%)|(0,91 a 1,17)|(de 7 menos a|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|(Begley et al., 2011;<br>Bernitz et al., 2011;<br>Byrne et al., 2000;<br>Hundley et al., 1994;<br>Klein et al., 1984;<br>MacVicar et al., 1993;<br>Waldenstrom et al.,<br>1997)||||14 mais)|
|Birthplace in England<br>Collaborative Group,<br>2011|307/16.580<br>(1,9%)|543/19.642<br>(2,8%)|RR Ajustado<br>0,75<br>(0,50 a 1,11)<sup>a</sup>|9 menos/1.000<br>(de 6 menos a<br>12 menos)|
|Campbell et al., 1999|36/782<br>(4,6%)|43/702<br>(6,1%)|RR 0,75<br>(0,49 a 1,16)|15<br>menos/1.000<br>(de 31 menos<br>a 10 mais)|
|Morbidade e mortalida|deperinatal comp|osta<sup>i</sup>|||
|Todas as mulheres de b|aixo risco||||
|Birthplace in England<br>Collaborative Group,<br>2011|58/16.524<br>(0,35%)|81/19.551<br>(0,41%)|OR Ajustado<br>0,92<br>(0,6 a 1,39)<sup>a</sup>|621<br>menos/1.000.0<br>00<br>(de 1.616<br>menos a 787<br>mais)|
|Mulheres nulíparas|||||
|Birthplace in England<br>Collaborative Group,<br>2011|38/8.256<br>(0,46%)|52/10.541<br>(0,49%)|OR Ajustado<br>0,96<br>(0,58 a 1,61)<sup>a</sup>|345<br>menos/1.000.0<br>00<br>(de 1.924<br>menos a 2.072<br>mais)|
|Mulheres multíparas|||||
|Birthplace in England|20/8.234|29/8.980|OR Ajustado|807|
|Collaborative Group,<br>2011|(0,24%)|(0,32%)|0,81<br>(0,40 a 1,62)<sup>a</sup>|menos/1.000.0<br>00|  
Tabela 7: Sumário dos estudos e magnitude do efeito. Parto planejado em uma unidade de parto intra-hospitalar (CPNI) com o parto planejado em uma maternidade baseada em hospital (MH)  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|Parto<br>planejado em<br>CPNI|Parto<br>planejado em<br>uma MH|Relativo<br>(IC 95% [ou<br>outro se<br>declarado])|Absoluto<br>(IC 95%)|
|||||(de 1.841<br>menos a 1.066<br>mais)|
|Morbidade neonatalgra|ve não causadap|or mal-formaçõe|s ouprematurida|de<sup>j</sup>|
|Waldenstrom et al.,<br>1997|6/933<br>(0,64%)|2/936<br>(0,21%)|RR 3,01<br>(0,61 a 14,87)|4.295<br>mais/1.000.000<br>(de 833 menos<br>a 29.637 mais)|
|Gaudineau et al., 2013|23/316<br>(7,3%)|64/890<br>(7,2%)|RR 0,94 (0,59<br>a 1,49)|4 menos/1.000<br>(29 menos a 35|
|||||mais)|
|Encefalopatia neonatal|(diagnóstico clínic|o)|||
|Birthplace in England<br>Collaborative Group,<br>2011|17/16.569<br>(0,1%)|34/19.587<br>(0,17%)|RR 0,59<br>(0,33 a 1,06)<sup>g</sup>|712<br>menos/1.000.0<br>00<br>(de 1.163<br>menos a 104<br>mais)|
|Encefalopatia neonatal|(sinais)<sup>k</sup>||||
|Birthplace in England<br>Collaborative Group,<br>2011|4/16.710<br>(0,02%)|8/19.706<br>(0,04%)|RR 0,59<br>(0,18 a 1,96)<sup>g</sup>|166<br>menos/1.000.0<br>00<br>(de 333 menos<br>a 390 mais)|  
IC intervalo de confiança, NC não calculável, RR risco relativo, OR odds ratio, UIO unidade peri ou intrahospitalar conduzida por Enfermeiras obstétricas ou obstetrizes MH maternidade baseada em hospital baseada em hospital/maternidade  
a. Ajustado para idade materna, etnia, compreensão do Inglês, estado marital, índice de massa corporal, quintil do escore de privação, gestações prévias e semanas de gravidez e também ponderados para refletir a duração da participação na unidade e probabilidade de participarem da amostra b. Os autores relatam uma análise que foi ajustada para idade materna, paridade, etnia e tabagismo. A direção e significância do efeito foram as mesmas em todos os casos, exceto para o desfecho de episiotomia, que se tornou estatisticamente significativo quando foi ajustado. As razões ajustadas de  
risco não foram relatadas na tabela porque elas são relatadas com a unidade de enfermagem obstétrica ou obstetriz como grupo de referência ao invés de outra forma.  
c. Notar que, embora o % baseado no evento da taxa de crua implica que a incidência deste desfecho é menor entre as mulheres que planejaram o parto em uma unidade peri ou intra-hospitalar, o riso realtivo na meta-análise (ponderdo pelo estudo) mostra que o risco é na realidade maior entre as mulheres que planejaram o parto em uma unidade peri ou intra-hospitalar. Isto está de acordo com todos os riscos relativos dos estudos individuais. Maiores detalhes no apêndice J das diretrizes-fonte da adaptação.  
d. As razões para procurar assistência médica são definidas com maiores detalhes no apêndice I das diretrizes-fonte da adaptação; entretanto, a maioria delas estão relacionadas ao período do parto e pósparto.  
e. Fatores evitáveis foram identificados em duas das mortes nas mulheres randomizaddas para as unidade peri ou intra-hospitalares. Maiores detalhes no apêndice I das diretrizes-fonte da adaptação. f. Em Begley et al., 2011,houve uma morte fetal > 24 semanas no braço da unidade conduzida por Enfermeiras obstétricas ou obstetrizes. Em Hundley et al., 1994,em todas as mortes fetais, os batimentos cardíacos da criança estavam ausentes na admissão ao hospital. Em MacVicar et al., 1993, possíveis fatores evetáveis foram identificados em 2/13 das mortes no grupo da unidade conduzida por Enfermeiras obstétricas ou obstetrizes. Maiores detalhes no apêndice I das diretrizes-fonte da adaptação.  
g. Deve-se notar que este desfecho fez parte do desfechos compostos de morbidade/mortalidade no estudo Birthplace e que o estudo só teve poder suficiente para detectar diferenças nos resultados compostos e não nos seus componentes individuais.  
h. Em Hundley et al., 1994, 5/11 mortes foram resultado de malformações fetais letais e  4/11 foram em bebês com menos de 37 semanas de gestação. Em MacVicar et al., 1993, os autores relatam que nenhum fator evitável foi identificado. Maiores detalhes no apêndice I das diretrizes-fonte da adaptação.  
i.Composto de morte fetal após início dos cuidados no parto, morte neonatal precoce, encefalopatia neonatal, síndrome de aspiração meconial, lesão de plexo braquial, fratura de úmero ou clavícula. j. Morbidade neonatal grave não foi definida adicionalmente em Waldenstrom et al, 1997; definida como pH <7.15 na artéria ouescore de  Apgar aos 5 min ≤6 ou morte neonatal em Gaudineau et al., 2013.  
k. Definido como internação em uma unidade neonatal dentro de 48 horas do nascimento por pelo menos 48 horas com evidência de dificuldade para alimentar ou desconforto respiratório. 7.2.8.1 Resumo da evidência e conclusões  
Houve evidência consistente na meta-análise dos nove ensaios randomizados controlados (n=9.208) e de um grande estudo observacional (n=36.378) que as mulheres que planejaram o parto em uma centro de parto normal intra ou peri-hospitalar tiveram maiores taxas de parto vaginal espontâneo e menores taxas de parto vaginal instrumental em relação àquelas que planejaram o parto em uma maternidade baseada em hospital. Um pequeno estudo observacional (n=1.206) também encontrou uma maior taxa de parto vaginal espontâneo na centro de parto normal intra ou peri-hospitalar mas nenhuma diferença nas taxas de parto vaginal instrumental. Outros dois estudos observacionais (n=1.937) não encontrou diferenças em nenhum dos resultados. Um grande estudo observacional (n=36.378) sugeriu uma grande redução nas taxas de cesariana para o parto planejado em uma centro de parto normal intra- ou peri-  
hospitalar conduzido por enfermeiras obstétricas, e a meta-análise dos ensaios randomizados controlados (n=11.298) demonstrou a mesma tendência, assim como em outro pequeno estudo observacional. Três outros estudos observacionais (n=3.143) não encontraram diferenças nas taxas de cesariana. Também as taxas de episiotomia foram menores para o parto planejado em um centro de parto normal intra ou peri-hospitalar conduzido por enfermeiras obstétricas, mas a evidência da metaanálise (n=8.100) demonstrou um maior risco de quaisquer lacerações vaginais/perineais, embora em um estudo observacional (n=1.482) não foram encontradas diferenças. Não houve diferenças na proporção de mulheres com períneo intacto ou no risco de lacerações vaginais/perineais de terceiro e quarto grau. Também não houve diferenças na hemorragia pós-parto (n=10.826), hemorragia pós-parto grave (n=1.111) ou necessidade de transfusão de hemoderivados (n=41.318). Não houve nenhum caso de morte materna nos dois estudos que relataram esse resultado (n=38.069).  
Em relação aos resultados perinatais, a evidência foi consistente (n=30.796), não demonstrando diferenças nas taxas de admissão em UTIN entre os recém-nascidos de ambos os grupos. Também não houve diferenças na incidência de resultados neonatais compostos de morbidade e mortalidade entre os dois grupos, analisados em um grande (n=36.075) e em outro pequeno estudo observacional. Mesmo na análise de sub-grupo por paridade nenhuma diferença foi encontrada. Não houve diferenças no risco de mortalidade fetal (n=44.315) e neonatal (n=1.828) e encefalopatia neonatal (n=36.156) embora nenhum dos estudos isoladamente tivesse força suficiente para detectar diferenças em desfechos tão raros.  
As taxas de transferência variaram de 20 a 50%, sendo maior entre as nulíparas. 7.2.8.2 Outras considerações  
Em relação aos benefícios clínicos e danos do dois locais estudados, a evidência demonstra benefícios para as mulheres que planejaram o parto em um centro de parto normal intra- ou peri-hospitalar conduzido por enfermeiras obstétricas em relação à ocorrência de parto vaginal instrumental e cesariana. Em relação ao trauma perineal, considerando também a episiotomia e à ocorrência de hemorragia pós-parto e transfusão de hemoderivados não foram identificadas diferenças significativas entre os grupos. Em termos perinatais, a análise dos resultados não demonstra diferenças significativas em ambos os grupos em relação à mortalidade fetal e neonatal e encefalopatia neonatal, embora nenhum dos estudos tivesse força suficiente para detectar essas diferenças. O grande estudo observacional realizado na Inglaterra teve força suficiente para detectar resultados neonatais adversos compostos, não encontrando diferenças entre os grupos. Também em relação a admissão em UTIN não foram encontradas diferenças. Tendo em vista as evidências, o nascimento em um centro de parto normal intra- ou peri-hospitalar conduzido por enfermeiras obstétricas ou obstetrizes é tão seguro para a criança quanto o nascimento em uma maternidade baseada em hospital.  
Em relação aos benefícios para a saúde e utilização de recursos concluiu-se que o parto planejado em uma centro de parto normal intra ou peri-hospitalar pode envolver custos menores, tendo em vista a menor ocorrência de intervenções. Por outro lado, um centro de parto normal intra ou peri-hospitalar não pode funcionar sem uma maternidade baseada em hospital de referência e isso também dever ser levado em consideração na alocação de recursos. Apesar disso, considerando os benefícios já demonstrados, se mais mulheres de baixo risco tivessem o seu parto em um CPN intra ou perihospitalar, haveria economia de recursos. A transferência de Enfermeiras obstétricas e obstetrizes das maternidades baseadas em hospital para unidades de parto intra ou peri-hospitalares para cuidar de mulheres de baixo risco e, consequentemente reduzindo intervenções, também permitiria que as  
maternidades baseadas em hospital utilizassem mais os seus recursos para lidar com as mulheres de alto risco e com aquelas transferidas de outros locais de parto.  
7.2.9 Conclusões em relação aos riscos e benefícios sobre o local do parto  
Os desenvolvedores das diretrizes do NICE concluíram que o parto, de uma maneira geral, é muito seguro em todos os locais, com uma incidência absoluta muito baixa de mortalidade ou morbidade grave. Mulheres de baixo risco que tiveram os seus partos em uma maternidade baseada em hospital foram mais sujeitas a intervenções obstétricas e sua morbidade associada, quando comparadas às mulheres que planejaram o parto em outros locais. Além do mais, a evidência demonstrou um aumento na admissão em UTIN de recém-nascidos em maternidades baseadas em hospital, com nenhuma diferença nos outros desfechos neonatais entre o parto planejado em maternidades baseadas em hospital, centros de parto normal intra ou peri-hospitalares e centros de parto normal extra-hospitalares conduzidos por enfermeiras obstétricas ou obstetrizes. Em termos de custo-efetividade, a assistência ao parto a mulheres de baixo risco fora do hospital parece ser superior em relação ao planejamento do parto em uma maternidade baseada em hospital.  
Houve diferenças importantes para os resultados neonatais quando análises de sub-grupo por paridade foram realizadas. Os achados indicaram que para os recém-nascidos das nulíparas que planejaram o parto em casa, houve um maior risco de resultados adversos compostos quando comparado a outros locais de parto, embora o risco absoluto permanecesse baixo. O grupo também reconheceu que o uso de resultados adversos compostos para a morbidade perinatal pode ser enganoso se o local de parto afetar resultados diferentes e de maneiras diferentes. Ademais, cerca de 90% dos casos de resultados perinatais compostos incluíram condições que estavam no espectro final de gravidade (morte perinatal, encefalopatia neonatal ou síndrome de aspiração meconial). Não houve nenhuma diferença para as multíparas em todos os locais de parto estudados. Por essas razões, associado ao fato de que ter o parto em uma maternidade baseada em hospital aumenta a morbidade materna, o grupo desenvolvedor das diretrizes recomendou que as nulíparas fossem orientadas a ter o seu parto em unidades de parto conduzidas por enfermeiras obstétricas ou obstetrizes, sejam extra, intra ou peri-hospitalares. Para as multíparas a recomendação foi que tivessem o seu parto em casa ou em unidades de parto extra, intra ou peri-hospitalares. Além do mais, o grupo concluiu que deve ser imperativo que à todas as mulheres sejam oferecidas a opção de escolha sobre o local de parto e recebam informações baseadas em evidências, em um formato facilmente acessível, sobre os riscos e benefícios associados com cada local, no sentido de ajudá-las a decidir qual o mais apropriado para darem à luz. O grupo também considerou importante que a informação seja dada com os dados de nulíparas e multíparas de maneira separada. O grupo também considerou a existência de lacunas nas pesquisas sobre o local de parto, recomendando novas pesquisas, principalmente em relação aos resultados de longo prazo relacionados aos diferentes locais, além dos componentes individuais da assistência oferecida em locais conduzidos por Enfermeiras obstétricas ou obstetrizes que contribui para as baixas taxas de intervenções. O grupo também reconheceu que as novas recomendações promoverão uma mudança em direção a mais mulheres terem os seus partos fora de uma maternidade baseada em hospital do que antes. 7.2.11 Nota explicativa e interpretação da evidência destas Diretrizes adaptadas para o Brasil  
Concluiu-se que os estudos em relação ao local de parto foram realizados em países distintos e em realidades diferentes da brasileira e, portanto, a aplicabilidade dos seus resultados no país deve ser vista com cautela. Nos países onde os estudos foram realizados já existem políticas mais duradouras de assistência ao parto fora do hospital, com uma organização e estruturação da assistência obstétrica que  
já contempla a assistência nestes outros locais, com sistemas de referência mais robustos, o que não é o caso do Brasil. Entretanto, concluiu-se que as evidências atuais, mesmo que oriundas de países diferentes, são uma referência para os formuladores de políticas de saúde, no nível nacional e local, para redesenhar o modelo e a organização da assistência obstétrica no País e também para a realização de estudos nacionais sobre o tema. As evidências analisadas são consistentes em demonstrar que a assistência ao parto no hospital, nos países onde os estudos foram realizados, deve ser reservada para aquelas parturientes que possuem riscos de complicações no início do trabalho de parto ou no início dos cuidados para o parto. Para todas as mulheres, o planejamento do parto em centros de parto normal conduzidos por enfermeiras obstétricas ou obstetrizes (extra, peri ou intra-hospitalares) parece ser a melhor opção em termos de riscos e benefícios para a saúde. Para as multíparas, pode-se acrescentar também a opção do planejamento do parto no domicílio, mantendo-se a mesma relação em termos de riscos/benefícios.  
Do ponto de vista do cuidado individual, concluiu-se que as evidências ora disponíveis e aqui analisadas devem servir de referência para a orientação para todas as gestantes das opções disponíveis em outros países e também no nível local de assistência no Brasil. Entretanto, deve-se ressalvar que as evidências são oriundas de fora, cujos desfechos não necessariamente seriam os mesmos no país.  
Em termos de benefícios para a saúde e o uso de recursos no Brasil, quando se compara a assistência ao parto nos diversos locais avaliados, deve-se levar em consideração a ínfima proporção de partos extrahospitalares no Brasil e ainda o fato da assistência ao parto no domicílio não ser coberta pelo Sistema Público e Suplementar de Saúde, além de carecer de uma regulação e normatização oficial. Importante notar que, para o redesenho do modelo, há que se considerar toda a organização, com sistemas de referência robustos, a infra-estrutura, disponibilidade de transporte, profissionais capacitados em todos os níveis e o financiamento para custeio. Em relação aos partos assistidos em centros de parto normal extra, intra e peri-hospitalares, o grupo concluiu que a existência de unidades em funcionamento no país, além da normatização já existente em portarias ministeriais, permite uma avaliação do uso de recursos para a sua implementação. Por outro lado também, o mesmo raciocínio utilizado para a análise do uso de recursos na Inglaterra também pode ser válido para o Brasil.  
Outra consideração a ser feita em relação ao uso de recursos no Brasil é a pequena quantidade de enfermeiras obstétricas e obstetrizes em atividade no país. Profissionais chave na assistência ao parto fora do hospital, a sua carência pode inviabilizar qualquer tentativa de redesenho do modelo de assistência obstétrica. Por isso, os recursos a serem destinados à formação desses profissionais, além do estabelecimento de um currículo mínimo de aquisição de competências e habilidades para garantir a segurança da assistência, tanto à mulher, como ao recém-nascido, devem ser considerados no sentido de suprir todas as necessidades do modelo.  
7.2.12 Recomendações em relação ao local do parto destas Diretrizes adaptadas para o Brasil  
As recomendações a seguir foram modificadas em relação às recomendações das diretrizes-fonte da adaptação, tendo em vista o contexto brasileiro, já explicitado na nota acima.  
1. Informar às gestantes de baixo risco de complicações que o parto normal é geralmente muito seguro tanto para a mulher quanto para a criança.  
2. Informar às gestantes de baixo risco sobre os riscos e benefícios dos locais de parto (domicílio, Centro de Parto Normal extra, peri ou intra hospitalar, maternidade). Utilizar as tabelas 8, 9, 10 e 11 para tal. Informar também que as evidências são oriundas de outros países, e não necessariamente aplicáveis ao Brasil.  
3. As mulheres nulíparas ou multíparas que optarem pelo planejamento do parto em Centro de Parto Normal (extra, peri ou intra-hospitalar), se disponível na sua área de abrangência ou próximos dessa, e cientes dos riscos e benefícios desses locais, devem ser apoiadas em sua decisão.  
4. Informar a todas as gestantes que a assistência ao parto no domicílio não faz parte das políticas atuais de saúde no país.  
5. Informar às nulíparas de baixo risco de complicações que o planejamento do parto no domicílio não é recomendado tendo em vista o maior risco de complicações para a criança. Informar também que as evidências são oriundas de outros países e não necessariamente aplicáveis ao Brasil.  
6. Informar às multíparas de baixo risco de complicações que, tendo em vista o contexto brasileiro, o parto domiciliar não está disponível no sistema de saúde, por isso não há como recomendar. No entanto, não se deve desencorajar o planejamento do parto no domicílio, desde que atenda o item 8.  
7. As mulheres devem receber as seguintes informações sobre o local de parto:  
- Acesso à equipe médica (obstetrícia, anestesiologia e pediatria)  
- Acesso ao cuidado no trabalho de parto e parto por enfermeiras obstétricas ou obstetrizes e demais profissionais que se fizerem necessários.  
- Acesso a métodos de alívio da dor, incluindo os não farmacológicos (banheira, chuveiro, massagens, etc.), analgesia regional e outras substâncias analgésicas.  
- A probabilidade de ser transferida para uma maternidade (se esse não for o local escolhido), as razões porque isso pode acontecer e o tempo necessário para tal.  
8. Assegurar que todas as mulheres que optarem pelo planejamento do parto fora do hospital tenham acesso em tempo hábil e oportuno a uma maternidade, se houver necessidade de transferência.  
Tabela 8: Taxas de parto vaginal espontâneo, transferência para uma maternidade baseada em hospital e intervenções obstétricas para cada local planejado para o parto: multíparas de baixo risco (fontes: Birthplace 2011<sup>16</sup> <u>; Blix et al. 2012</u><sup>31</sup> <u>)</u>  
|Eventos|Número|de incidênciaspo|r 1.000 multíparasq|ue dão à luz|
|---|---|---|---|---|
||Domicílio|Centro de<br>Parto Normal<br>extra-<br>hospitalar|Centro de Parto<br>Normal peri ou<br>intra hospitalar|Maternidade<br>baseada em<br>hospital|
|Parto vaginal espontâneo|984*|980|967|927*|
|Transferência para<br>maternidade baseada em<br>hospital|115*|94|125|10**|
|Analgesia regional (peridural<br>ou raquidiana***|28*|40|60|121*|
|Episiotomia|15*|23|35|56*|
|Cesariana|7*|8|10|35*|
|Parto instrumental (fórceps<br>ou ventosa)|9*|12|23|38*|
|Transfusão de sangue|4|4|5|8|  
*Números oriundos de Birthplace, 2011 e Blix et al., 2012 (todos os outros de Birthplace, 2011)  
**Transferência de uma maternidade baseada em hospital para outra devido a baixa capacidade ou resolutividade ***Blix relatou analgesia peridural e Birthplace relatou peridural ou raquidiana Tabela 9: Resultados para o recém-nascido para cada local planejado de parto: multíparas de baixo risco (fontes: Birthplace, 2011<sup>16</sup> <u>)</u>  
||Número de|recém-nascidos|por 1.000 nascimen|tos|
|---|---|---|---|---|
||Domicílio|Centro de<br>Parto Normal<br>extra-<br>hospitalar|Centro de Parto<br>Normal peri ou<br>intra hospitalar|Maternidade<br>baseada em<br>hospital|
|Recém-nascidos sem<br>problemasgraves|997|997|998|997|
|Recém-nascidos com<br>problemasgraves*|3|3|2|3|  
*Os problemas graves foram combinados no estudo: encefalopatia neonatal e síndrome de aspiração de mecônio foram os eventos adversos mais comuns, juntos representaram 75% do total. As mortes fetais após o início do cuidado no trabalho de parto e morte neonatal na primeira semana de vida representaram 13% dos eventos. Fratura de úmero e clavícula foram eventos incomuns (menos de 4% dos eventos adversos).  
Tabela 10: Taxas de parto vaginal espontâneo, transferência para uma maternidade baseada em hospital e intervenções obstétricas para cada local planejado para o parto: nulíparas de baixo risco (fontes: Birthplace 2011<sup>16</sup> <u>; Blix et al. 2012</u><sup>31</sup> <u>)</u>  
||Número d|e incidênciaspor|1.000 nulíparasque|dão à luz|
|---|---|---|---|---|
||Domicílio|Centro de<br>Parto Normal<br>extra-<br>hospitalar|Centro de Parto<br>Normal peri ou<br>intra hospitalar|Maternidade<br>baseada em<br>hospital|
|Parto vaginal espontâneo|794*|813|765|688*|
|Transferência para<br>maternidade baseada em<br>hospital|450*|363|402|10**|
|Analgesia regional (peridural<br>ou raquidiana***|218*|200|240|349|
|Episiotomia|165*|165|216|242*|
|Cesariana|80*|69|76|121*|
|Parto instrumental (fórceps ou<br>ventosa)|126*|118|159|191*|
|Transfusão de sangue|12|8|11|16|  
*Números oriundos de Birthplace, 2011 e Blix et al., 2012 (todos os outros de Birthplace, 2011) **Transferência de uma maternidade baseada em hospital para outra devido a baixa capacidade ou

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: resolutividade -->
***Blix relatou analgesia peridural e Birthplace relatou peridural ou raquidiana Tabela 11: Resultados para o recém-nascido para cada local planejado de parto: nulíparas de baixo risco (fontes: Birthplace 2011<sup>16</sup> <u>)</u>  
||Número de<br>Domicílio|recém-nascidos<br>Centro de<br>Parto Normal<br>extra-<br>hospitalar|por 1.000 nascimen<br>Centro de Parto<br>Normal peri ou<br>intra hospitalar|tos<br>Maternidade<br>baseada em<br>hospital|
|---|---|---|---|---|
|Recém-nascidos sem<br>problemasgraves|991|995|995|995|
|Recém-nascidos com<br>problemasgraves*|9|5|5|5|  
*Os problemas graves foram combinados no estudo: encefalopatia neonatal e síndrome de aspiração de mecônio foram os eventos adversos mais comuns, juntos representaram 75% do total. As mortes fetais após o início do cuidado no trabalho de parto e morte neonatal na primeira semana de vida representaram 13% dos eventos. Fratura de úmero e clavícula foram eventos incomuns (menos de 4% dos eventos adversos).  
- 7.2.13 Recomendações sobre necessidade de pesquisa  
1. Quais os riscos e benefícos dos diversos locais de parto no Brasil, incluindo resultados de curto e longo prazo?  
População: Parturientes de baixo de baixo risco de complicações admitidas no início do trabalho de parto para assistência nos diversos locais selecionados (domicílio, centro de parto normal extra, peri ou intra-hospitalar e maternidade)  
Intervenção: Parto planejado fora do hospital (domicílio, centro de parto normal extra, peri e intrahospitalar).  
Comparação: Parto planejado em uma maternidade.  
Desfechos: Mortalidade e morbidade materna e perinatal, intervenções (cesariana, uso de ocitocina, episiotomia, parto vaginal instrumental), admissão do recém-nascido em unidades neonatais, taxas de transferência e satisfação da mulher.  
Desenho do estudo: Estudo de coorte retrospectivo ou prospectivo, com componente qualitativo. Qual a importância disso?  
Tendo em vista que todos os estudos relacionados ao local de parto publicados até o momento foram realizados em países desenvolvidos, o grupo elaborador concluiu que há necessidade de pesquisas sobre o local de parto no Brasil, envolvendo todos os locais analisados nestas Diretrizes (domicílio, centro de parto normal extra, peri e intra-hospitalar e maternidade) para uma conhecimento mais profundo da realidade brasileira.  
- 7.3 Critérios para nortear a seleção do local de parto  
- 7.3.1 Questão de revisão  
- Quais critérios devem nortear a seleção do local de parto?  
- 7.3.2 Evidências científicas  
As diretrizes do NICE abordaram essa questão mas no processo de revisão não foram encontradas evidências fortes relacionadas ao tema. Por esse motivo, os desenvolvedores das diretrizes definiram,  
por consenso, os critérios que devem nortear as orientações a serem fornecidas às mulheres, considerando o risco relativo associado ao local do parto desejado por elas. Nestas Diretrizes adaptada definiram-se os mesmos critérios, com algumas modificações, tendo em vista a realidade brasileira. 7.3.3. Recomendações em relação aos critérios para a seleção do local do parto  
9. Utilizar as tabelas 12, 13, 14 e 15 como instrumentos de avaliação das mulheres em relação à escolha do local do parto:  
- As tabelas 12 e 13 apresentam condições clínicas e situações onde existe um risco aumentado para a mãe e a criança durante ou imediatamente após o parto e a assistência em uma maternidade poderia reduzir este risco.  
- O fatores listados nas tabelas 14 e 15 são razões para aconselhar as mulheres a planejarem o parto em uma maternidade baseada em hospital, mas indica que outras situações sejam levadas em consideração em relação ao local do parto, tendo em vista a proximidade deste local com a maternidade e as preferências da mulher.  
- Discutir os riscos e os cuidados adicionais que podem ser oferecidos em uma maternidade para que as mulheres possam fazer uma escolha informada sobre o local planejado para o parto  
- Tabela 12: Condições clínicas de alto risco indicando o planejamento do parto em uma maternidade  
|Área|Condição Clínica|
|---|---|
|Cardiovascular|Cardiopatia confirmada<br>Hipertensão|
|Respiratória|Asma que necessita aumento do tratamento ou tratamento<br>hospitalar<br>Fibrose Cística|
|Hematológica|Hemoglobinopatias – anemia falciforme, beta-talassemia<br>major<br>História de doença tromboembólica<br>Púpura<br>trombocitopênica<br>imune<br>ou<br>outro<br>distúrbio<br>plaquetário ou contagem de plaquetas < 100.000/mL<br>Doença de Von Willebrand<br>Distúrbio hemorrágico materno ou fetal<br>Anticorpos atípicos que carreiam o risco de doença<br>hemolítica do recém-nascido|
|Endócrino|Diabetes<br>Hipertireoidismo|
|Infecciosa|Fatores de risco para estreptococo do grupo B com<br>necessidade de uso de antibióticos durante o trabalho de<br>parto<br>Hepatite B/C com testes de função hepática anormais<br>Portadora ou infecção pelo HIV<br>Toxoplasmose – recebendo tratamento<br>Varicela/Rubéola/Herpes genital atual na mãe ou feto<br>Tuberculose em tratamento|
|Imune|Lúpus eritematoso sistêmico|  
Tabela 12: Condições clínicas de alto risco indicando o planejamento do parto em uma maternidade  
|Área|Condição Clínica|
|---|---|
||Esclerodermia|
|Renal|Função renal anormal<br>Nefropatia necessitando supervisão de especialista|
|Neurológica|Epilepsia|
||Miastenia Gravis<br>Acidente vascular cerebralprévio|
|Gastrointestinal|Hepatopatia com testes de função hepática anormais|
|Psiquiátrica|Doençapsiquiátrica necessitando internação|

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Tabela 13: Outros fatores de alto risco indicando o planejamento do parto em uma maternidade -->
|Fator|Informação adicional|
|---|---|
|Complicações prévias|Morte<br>fetal/neonatal<br>inexplicada<br>ou<br>morte<br>prévia<br>relacionada a dificuldades intraparto<br>Recém-nascido prévio com encefalopatia neonatal<br>Pré-eclâmpsia necessitando parto prematuro<br>Descolamento prematuro de placenta com resultado adverso<br>Eclâmpsia<br>Ruptura uterina<br>Hemorragia pós-parto primária necessitando tratamento<br>adicional ou transfusão de sangue<br>Placenta retida necessitando extração manual em sala<br>cirúrgica<br>Cesariana<br>Distócia de ombro|
|Gravidez atual|Gestação múltipla<br>Placenta prévia<br>Pré-eclâmpsia ou hipertensão gestacional<br>Trabalho de parto prematuro ou rotura prematura de<br>membranas pré-termo<br>Descolamento prematuro de placenta<br>Anemia – hemoglobina < 8,5 g/dL no início do trabalho de<br>parto<br>Morte fetal<br>Indução do parto<br>Uso de drogas ilícitas<br>Dependência<br>de<br>álcool<br>necessitando<br>avaliação<br>ou<br>tratamento<br>Diabetes gestacional<br>Apresentação anômala –pélvico ou transverso|  
Tabela 13: Outros fatores de alto risco indicando o planejamento do parto em uma maternidade  
|Fator|Informação adicional|
|---|---|
||IMC no início do pré-natal > 35 kg/m2<br>Hemorragia anteparto recorrente<br>Pequeno para a idade gestacional nessa gravidez (< percentil<br>5 ou velocidade de crescimento reduzida ao ultrassom)<br>Frequência Cardíaca Fetal anormal/Doppler anormal<br>Oligohidrâmnio oupolihidrâmnio ao ultrassom|
|História ginecológica prévia|Miomectomia<br>Histerotomia|  
Tabela 14: Condições clínicas que indicam uma avaliação individual em relação ao <u>planejamento do local do parto</u>  
|Área|Condição Clínica|
|---|---|
|Cardiovascular|Cardiopatia sem implicaçõespara oparto|
|Hematológica|Anticorpos atípicos sem risco de doença hemolítica do<br>recém-nascido<br>Traço falciforme<br>Traço de talassemia<br>Anemia – hemoglobina 8,5–10,5 g/dL no início do trabalho<br>departo|
|Endócrino|Hipotireoidismo<br>instável<br>necessitando<br>mudança<br>no<br>tratamento|
|Infecciosa|Hepatite B/C com testes de função hepática normais|
|Imune|Doenças não específicas do tecido conjuntivo|
|Esquelética/Neurológica|Anormalidade da coluna<br>Déficit neurológico|
|Gastrointestinal|Hepatopatia com testes de função hepática normais<br>Doença de Crohn<br>Colite ulcerativa|  
Tabela 15: Outros fatores indicando avaliação individual em relação ao planejamento do local do parto  
|Fator|Informação adicional|
|---|---|
|Complicações prévias|Morte fetal/neonatal com causa conhecida e não recorrente<br>Pré-eclâmpsia no termo<br>Descolamento prematuro de placenta com bom resultado<br>Eclâmpsia|
||História de recém-nascido prévio com peso > 4,5 Kg<br>Laceração vaginal ou cervical extensa ou trauma perineal de<br>terceiro ou quarto grau<br>Recém-nascidoprévio no termo com icterícia necessitando|  
Tabela 15: Outros fatores indicando avaliação individual em relação ao planejamento do local do parto  
|Fator|Informação adicional|
|---|---|
||exsanguíneotranfusão|
|Gravidez atual|Hemorragia anteparto de origem desconhecida (episódio<br>único após 24 semanas de gestação)<br>IMC no início do pré-natal de 30–35 kg/m2<br>Pressão arterial sistólica ≥ 140 mmHg ou  diastólica ≥ 90<br>mmHg em duas ocasiões<br>Suspeita de macrossomia, clínica ou por ultrassom<br>Para 4 ou mais<br>Uso recreacional de drogas ilícitas<br>Em tratamento psiquiátrico ambulatorial<br>Idade > 35 no início dopré-natal|
|Indicações fetais|Anormalidade fetal|
|História ginecológica prévia|Cirurgia ginecológica maior<br>Biópsia por conização ou excisão por alça diatérmica da zona<br>de transformação<br>Miomas|  
As outras questões de revisão do escopo das diretrizes relacionadas ao local de parto não foram abordadas por nenhuma das diretrizes consultadas:  
- Como assegurar à mulher o direito de escolha sobre o local de parto?  
- Quais são as condições mínimas para assistência segura ao parto domiciliar?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.1 Introdução -->
Existem três principais modelos que comportam diferentes perfis profissionais na assistência ao parto: cuidado oferecido por Enfermeiras obstétricas ou obstetrizes, cuidado oferecido por médicos obstetras e cuidado colaborativo entre os dois profissionais.  
O modelo de cuidado no qual a Enfermeira obstétrica ou obstetriz tem a responsabilidade pelo cuidado é oferecido a mulheres com gestação de baixo risco, com variações em seus critérios, mas sobretudo tem em comum o pressuposto da gestação e do parto como um evento saudável da fase da vida da mulher e por esta razão as mulheres podem ter uma experiência do parto com intervenções mínimas. Nos demais modelos de cuidado compartilhado pelos diferentes profissionais o médico obstetra é responsável pela tomada de decisão.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.2 Questões de revisão -->
- Qual é a qualificação profissional mínima necessária para garantir assistência adequada ao parto normal?”  
- Como o tipo de profissional influi nos resultados do parto?  
- Há vantagens em um modelo de assistência ao parto prestada por Enfermeiras obstétricas ou obstetrizes?  
- Qual o papel dos diversos profissionais de saúde na assistência institucional ao parto normal?  
- 8.3 Evidências Científicas  
As diretrizes do NICE de 2014 não abordam as questões sobre as características e perfis dos diferentes profissionais para a atenção ao parto. Já as diretrizes do País Basco abordaram o assunto com uma questão:  “Como o perfil do profissional influi nos resultados do parto?”. Foi incluída para análise uma revisão sistemática (RS) que incluiu 11 ERCs com um total de 12.276 mulheres<sup>50</sup> . Dos 11 estudos, sete compararam um modelo de cuidados com gravidez, parto e puerpério orientado por Enfermeiras obstétricas ou obstetrizes com um modelo de cuidados compartilhados (Enfermeiras obstétricas/obstetrizes, médicos obstetras e médicos da atenção primária), três estudos compararam um modelo orientado por Enfermeiras obstétricas/obstetrizes com um modelo de cuidados médicos e, um último por Enfermeiras obstétricas/obstetrizes com várias opções de padrão de cuidados, incluindo modelos de cuidados médicos e cuidados compartilhados. Os resultados mostraram que as mulheres que receberam cuidados oferecidos por Enfermeiras obstétricas ou obstetrizes foram menos propensas a necessitar de hospital durante a gravidez (RR 0,90 [IC 95% 0,81 a 0,99]), a requerer episiotomia (RR 0,82 [IC 95% 0,77 a 0,88) e analgésicos durante a gravidez (RR 0,81 [IC 95% 0,73 a 0,91 ). Estas mulheres, ainda, tiveram maior chance de parto vaginal espontâneo (RR 1,04 [IC 95% 1,02 a 1,06 ), maior sensação de controle da experiência do parto (RR 1,74 [IC 95% 1,32 a 2,30] ), de serem atendidas por Enfermeiras obstétricas ou obstetrizes anteriormente conhecidas (RR 7,84 [IC 95% 4,15 a 2,30] ) e de iniciarem a amamentação (RR 1,35 [IC 95% 1,03 a 1,76] ). Também no grupo de cuidados por Enfermeiras obstétricas/obstetrizes houve um menor propensão à perda fetal antes de 24 semanas de gestação (RR 0,79 [IC 95% 0,65 a 0,97] e menor permanência hospitalar (DMP  -2 dias [IC 95%  -1,85 a -2,15]). Não houve diferenças estatisticamente significativas entre os modelos comparados, em relação aos resultados sobre morte fetal e neonatal em geral (RR 0,83 [IC 95% 0,70 a 1,00]).  
Para investigar as possíveis fontes de heterogeneidade, foram realizadas análises de subgrupos entre: a) diferentes modelos de cuidados por enfermeiras obstétricas (modelos de gestão de casos por 2-3 enfermeiras obstétricas e modelos de equipes de enfermeiras obstétricas); b) variações de risco materno (baixo risco em comparação com misto); e c) diferentes ambientes (cuidados comunitários em comparação com hospitalares).  
Foram realizadas análises de subgrupos que não explicaram a grande heterogeneidade estatística (I<sup>2</sup> superior a 50%) encontrada em alguns resultados (hospitalização durante a gravidez, uso de analgésicos regionais, uso de analgesia com opióide, episiotomia, parto vaginal espontâneo, cuidados por enfermeiras obstétricas conhecidas e permanência hospitalar mais curta), exceto quanto ao resultado do uso de analgesia com opióide, que demonstra uma heterogeneidade que poderia ser influenciada pelos diferentes ambientes assistenciais.  
A satisfação materna foi avaliada, medindo diferentes componentes da experiência do nascimento: informações recebidas, assessoramento, explicações, local do parto, preparação para o parto e nascimento e dor, assim como a percepção da escolha do método de alívio e da avaliação do comportamento do profissional que a atende. Devido às diferentes medidas de satisfação não foi possível agrupar os dados para análise, mas a avaliação dos estudos individualmente demonstrou que a satisfação parece ser maior em modelos orientados por Enfermeira obstétricas/obstetrizes. 8.3.1 Resumo da evidência e conclusões  
As evidências analisadas demonstraram vantagens, do ponto de vista dos benefícios clínicos e danos, de um modelo de cuidados promovidos por Enfermeiras obstétricas ou obstetrizes em relação aos outros modelos comparativos, com redução de intervenções obstétricas, como analgesia regional e episiotomia, além de  aumento da satisfação das mulheres e início mais precoce da amamentação, sem  
efeitos adversos. A evidência aponta que, num modelo de cuidados promovidos por Enfermeiras obstétricas/obstetrizes, os médicos obstetras deveriam atuar como auxílio adicional para intervir nas situações além dos limites da normalidade.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.3.2 Outras considerações -->
Em relação aos benefícios para a saúde e uso de recursos no Brasil, a evidência demonstra que um modelo de assistência conduzido por Enfermeiras obstétricas ou obstetrizes pode ser custo-efetivo tendo em vista a redução de intervenções obstétricas e utilização mais racional dos recursos humanos disponíveis. O custo de formação e também de inserção desses profissionais nas equipes assistenciais pode representar um economia de recursos quando comparado ao um modelo conduzido  apenas por médicos obstetras.  
Em relação à qualificação profissional mínima necessária para garantir assistência adequada ao parto normal, nenhuma das diretrizes consultadas aborda a questão além das Enfermeiras obstétricas ou obstetrizes e médicos obstetras. As diretrizes também não abordam sobre o papel dos diversos profissionais na assistência institucional no parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.3.3 Recomendação em relação ao profissional que assiste o parto -->
As recomendações seguintes foram modificadas em relação às recomendações das diretrizes-fonte de adpatação.  
10. A assistência ao parto e nascimento de baixo risco que se mantenha dentro dos limites da normalidade pode ser realizada tanto por médico obstetra quanto por enfermeira obstétrica e obstetriz.  
11. É recomendado que os gestores de saúde proporcionem condições para a implementação de modelo de assistência que inclua a enfermeira obstétrica e obstetriz na assistência ao parto de baixo risco por apresentar vantagens em relação à redução de intervenções e maior satisfação das mulheres.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9 Cuidados gerais durante o trabalho de parto -->
- 9.1 Informações e comunicação

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.1.1 Introdução -->
A comunicação efetiva em todas as formas é um aspecto fundamental nos serviços de maternidade. O objetivo global do cuidado durante o parto é gerar uma experiência positiva para a mulher e sua família, mantendo a saúde física e emocional, bem como evitar complicações, e intervir rapidamente caso haja uma situação de emergência.  
Para alcançar este objetivo, uma boa comunicação entre os profissionais e à gestante é crucial. Desenvolver um relacionamento íntimo, individualizado e harmônico com a mesma é importante para que se alcance uma percepção positiva da experiência do parto. Outros fatores incluem a participação na tomada de decisões, as explicações bem informadas e baseadas em evidência, atendendo às expectativas pessoais.  
As opiniões, crenças e valores da mulher, seu parceiro e sua família em relação aos seus cuidados e de seu bebê devem ser avaliados e respeitados em todos os momentos. As mulheres devem estar plenamente envolvidas para que o cuidado seja flexível e adaptado às necessidades individuais e do seu bebê. As mulheres devem ter a oportunidade de tomar decisões informadas sobre todos os aspectos do parto e do nascimento. Entender que, algumas vezes, as mulheres recusam intervenções oferecidas por vários motivos, incluindo experiências desagradáveis anteriores.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.1.2 Questões de revisão -->
- As mulheres devem receber informações baseadas em evidência para que tomem decisões informadas sobre o parto?  
- Quem deve oferecer essas informações?  
- Como essas informações devem ser oferecidas? Em grupos, individual ou por escrito?  
- Em que momento essas informações devem ser oferecidas à mulher?  
- Qual o conteúdo e formato dessas informações?  
- Qual a efetividade da realização de um plano de parto por parte da mulher?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.1.3 Evidências Científicas -->
As diretrizes do NICE abordam sobre a importância da comunicação entre os profissionais e à gestante, durante o trabalho de parto. A questão respondida nas diretrizes foi em relação ao efeito que a comunicação teria na percepção da mulher sobre sua experiência do parto. As intervenções incluíram o efeito do controle, escolha e processo de tomada de decisões no bem-estar psicológico no médio e longo prazo. Os desfechos analisados incluíram a depressão pós-parto e desordens de estresse pós traumático.  
As diretrizes incluiu 19 estudos, dentre eles uma revisão sistemática. Além da revisão sistemática, em sua  grande maioria, os outros foram estudos de coortes, prospectivos e qualitativos, que foram realizados por meio de pesquisas e entrevistas, os quais foram desenhados para descrever as relações entre o comportamento das pessoas que atendem as mulheres durante o parto e os resultados psicossociais das mesmas. Esses estudos são resumidos a seguir:  
Uma revisão sistemática incluiu estudos observacionais, outras revisões sistemáticas e ensaios randomizados controlados envolvendo mais de 45.000 mulheres em vários países (Austrália, EUA, Reino Unido, Canadá, Finlândia, Suécia, Irlanda, China, México, Líbano, Singapura, França e outros países não citados pela fonte, incluídos nas revisões sistemáticas. O objetivo da revisão foi avaliar a dor e os fatores que influenciaram as mulheres em relação às suas experiências de parto.<sup>51</sup> [NE = 3] O estudo identificou quatro principais fatores que influenciaram sobre a experiência do parto nas mulheres: expectativa pessoal, quantidade de apoio dos prestadores do cuidado, a qualidade da relação do cuidador-paciente e o envolvimento na tomada de decisão. Concluiu-se também que a dor, alívio da dor e intervenções intraparto são importantes na satisfação das mulheres mas não tão forte como as influências das atitudes e comportamentos dos cuidadores.  
Outro estudo sueco com 2.541 mulheres que avaliou os fatores de risco relacionados à experiência de parto durante a gravidez e 2 meses após o parto,<sup>52</sup> [NE = 2+] identificou que problemas médicos inesperados, fatores sociais, os sentimentos das mulheres durante o trabalho de parto, tais como dor e falta de controle, além da ausência de apoio e administração de analgesia estiveram associados com a experiência negativa do parto.  
Um estudo realizado no Reino Unido (n = 1.146) avaliou as preferências e expectativas das mulheres, além de desfechos psicológicos em relação ao parto.<sup>53</sup> [NE = 2+] As multíparas tiveram maior sensação de controle do que as nulíparas em todos os casos. As sensação de controle também esteve associada com o comportamento dos profissionais tais como ser capaz de sentir confortável, ser tratada com respeito como indivíduo e a percepção de ser considerada.  
Outro estudo inglês que incluiu 412 nulíparas<sup>54</sup> [NE = 3] explorou as visões das mulheres no trabalho de parto revelando como temas principais de importância: apoio, intervenção, controle e tomada de decisão e alívio da dor .  
Um estudo foi realizado com o objetivo de explorar os fatores relacionados à experiência do parto em 1.111 mulheres.<sup>55</sup> [NE = 3] Foram identificadas cinco variáveis explanatórias: envolvimento no processo de nascimento (percepção de controle) e apoio da enfermagem obstétrica/obstetriz foram preditivos de uma experiência positiva; ansiedade, dor e ter o primeiro filho foram preditivos de uma experiência negativa.  
Outro estudo sueco com 295 mulheres demonstrou que as mesmas usualmente experimentaram dor intensa e vários graus de ansiedade, além da maioria ter apresentado episódios de pânico por um curto período ou por alguma parte do trabalho de parto.<sup>56</sup> [NE = 3] Apesar destes sentimentos negativos, a maioria delas se sentiram bastante envolvidas no processo de nascimento, ficaram satisfeitas com seus próprios alcances e tinham lidado melhor do que o esperado com a situação. As variáveis que mais contribuíram para a experiência de parto foram: apoio da Enfermeira obstétrica/obstetriz (sensibilidade às necessidades); duração do trabalho de parto; dor; expectativas do parto; envolvimento e participação no processo de nascimento e procedimentos cirúrgicos (cesariana de emergência, vácuo-extrator, fórceps e episiotomia).  
Outro estudo realizado na Austrália (n = 790)<sup>57</sup> [NE = 3] revelou que não ter um fala ativa nas decisões esteve associada com um aumento de seis vezes no grau de insatisfação entre as nulíparas e de 15 vezes entre as multíparas. Após análise de regressão logística por paridade, os seguintes fatores estiveram fortemente relacionados com a insatisfação com a assistência no parto: falta de envolvimento no processo de decisão (P < 0.001); informação insuficiente (P < 0.001); maior escore de intervenções obstétricas (P < 0.015); e a percepção que os cuidadores não ofereciam ajuda (P < 0.04).  
Outro estudo australiano envolvendo 1.336 mulheres, após ajustar por paridade, fatores sociais e assistência obstétrica, evidenciou que a percepção de falta de ajuda por parte dos cuidadores e não ter uma fala ativa nas decisões sobre os seus cuidados foram as variáveis que tiveram o maior impacto na experiência negativa de parto das mulheres.<sup>58</sup> [NE = 3]  
Outro estudo realizado na Austrália investigou as experiências de parto de 499 mulheres. Uma em três identificou um evento traumático no parto e relatou a presença de pelo menos três sinais de trauma. 28 mulheres (5,6%) atingiram os critérios de desordem de estresse pós traumático de acordo com o DSMIV. O nível de intervenção obstétrica junto com a percepção de cuidados inadequados durante o trabalho de parto estiveram consistentemente associados com o desenvolvimento dos sintomas.<sup>59</sup> [NE = 3]  
Um estudo realizado na Finlândia com 271 mulheres investigou as suas percepções de trabalho de parto e parto.<sup>60</sup> [NE = 3] Análise de regressão logística demonstrou que as experiências positivas do parto estiveram associadas com as características positivas e habilidades profissionais da Enfermeira obstétrica ou obstetriz assistente, as atitudes positivas do pai da criança durante a gravidez e um trabalho de parto rápido.  
Nos EUA (início dos anos 90), após análise de 33 histórias de parto de uma amostra de 15 mulheres, os pesquisadores concluíram que quando a tomada de decisão era mais compartilhada entre as mulheres e os cuidadores, as mesmas expressaram emoções mais positivas.<sup>61</sup> [NE = 3].  
Em um estudo qualitativo sueco envolvendo 18 mulheres, realizado em 1994, três temas associados com uma experiência positiva no parto emergiram: a necessidade de ser vista como um indivíduo; ter um relação de confiança e ser apoiada e guiada em seus próprios termos.<sup>62</sup> [NE = 3]  
Outro estudo qualitativo realizado na Islândia envolvendo 14 mulheres demonstrou que as mesmas tinham a necessidade de senso de controle, de cuidado e compreensão, além de uma necessidade de  
uma boa relação com a Enfermeira obstétrica/obstetriz, que incluiu o sentimento de se sentir segura. Um explanação dos eventos e tranquilização em relação ao processo também foram importantes.<sup>63</sup> [NE = 3]  
Outro estudo da Islândia avaliou as visões e experiências de parto de 10 mulheres<sup>64</sup> [NE = 3] em uma análise qualitativa e os autores sumarizaram as três características da Enfermeira obstétrica/obstetriz cuidadosa:  
- competência – tem o conhecimento e as habilidades necessárias para conduzir uma mulher durante o trabalho de parto e nascimento; é responsável, atenciosa, deliberada e comunica de maneira efetiva.  
- preocupação genuína e respeito pela mulher – doa-se, demonstra solidariedade e compartilhamento, é encorajadora e apoiadora, respeitosa e benevolente.  
 atitude mental positiva – é alegre e positiva, confiável e confiante, considerada e compreensiva. Os autores também sumarizaram as três características de uma Enfermeira obstétrica/obstetriz descuidada:  
- falta de competência – ser rude durante o cuidado da mulher, comunicar de maneira ineficiente, não tomar iniciativas quando necessário e falta de compreensão e flexibilidade.  
- falta de preocupação genuína e respeito pela mulher como uma pessoa – ser negligente, estrita a rotinas e regras, não ter notícia da mulher e falta de cooperação; ser indiferente e não se tocar pelo evento como tal, falta de interesse e compreensão em geral, não dar apoio, ser insensível, estar com pressa e correndo.  
- características negativas de caráter – ser sombria e brusca, fria, grosseira ou áspera.  
Um estudo americano mostrou vídeos dos próprios partos para um amostra de 20 mulheres ao mesmo tempo que as entrevistaram.<sup>65</sup> [NE = 3] Os 25 cuidadores das mulheres também foram entrevistados separadamente enquanto viam os vídeos. Embora ambos parecessem concordar com qual informação as mulheres necessitavam e como ela deveria ser fornecida, as percepções dos cuidadores foram mais positivas do que as das mulheres. Muitas delas queriam mais informação e valorizaram a informação detalhada para explicar o que estava acontecendo.  
Uma discussão baseada em um artigo prévio<sup>66</sup> [NE = 3] aborda a ideia de que as mulheres têm menos interesse para os cuidadores do que o equipamento e que a falta de informação retira poder das mulheres. Os cuidadores costumam bloquear as preocupações ou interesses das mulheres através do silêncio, mudando o assunto ou declarações neutras tais como ‘vamos ver como faremos’.  
Uma observação de uma amostra de 12 mulheres no segundo período do trabalho de parto examinou a comunicação entre as Enfermeiras obstétricas/obstetrizes, as estudantes de enfermagem obstétrica/obstetrícia, as mulheres em trabalho de parto e seus acompanhantes, através da análise de vídeos gravados<sup>67</sup> [NE = 3]. A comunicação foi categorizada como: inovadora, encorajadora, direcionadora, educacional, questionadora, social e profissional. A maioria da comunicação foi categorizada como direcionadora, encorajadora ou educacional, com algum grau de sobreposição das duas últimas. As Enfermeiras obstétricas/obstetrizes foram alocadas em um de dois grupos: aquelas que tendiam a ser direcionadoras ou aquelas que tendiam a ser encorajadoras e educadoras. As mulheres preferiram as últimas.  
O instrumento de Avaliação do Comportamento do Cuidado foi usado em uma amostra de 31 mulheres após o parto normal nos EUA<sup>68</sup> e demonstrou que os comportamentos percebidos pelas mulheres com maior indicação de cuidado focaram na competência profissional e monitoração das condições da  
mulher. Os comportamentos mais cuidadosos incluiram conhecimento do que se fazia, tratar a mulher com respeito e como um indivíduo, ser gentil, ter consideração e tranquilizar a mulher.  
Em um estudo qualitativo foram realizadas entrevistas com 10 mulheres chinesas e 10 mulheres escocesas que deram à luz na Escócia, além de entrevistas com os profissionais de saúde, parentes e amigos. As repostas à experiência de parto foram parcialmente relacionadas à cultura da mulher, com as chinesas aceitando mais o cuidado oferecido, mas alguns assuntos foram comuns em todas as mulheres, independente do contexto cultural, principalmente o sentimento de estar no controle que se relacionou com um melhor desfecho emocional. A falha dos cuidadores de se engajarem com a mulher como um ser humano foi experimentada como muito traumática.<sup>69</sup> [NE = 3]  
Quanto a quem deve oferecer essas informações, as diretrizes do NICE e do KCE (Bélgica) definem que todos os prestadores de cuidado, dentre eles, os médicos e as Enfermeiras obstétricas/obstetrizes podem oferecê-las mas não apresentam estudos que avaliem a eficácia de acordo com o profissional. A forma como essas informações são oferecidas (em grupo, individual ou por escrito) não foram abordadas especificamente pelas diretrizes adaptadas, não sendo citado nenhum estudo que avaliasse o impacto das informações de acordo com o tipo. Entretanto, as diretrizes do NICE citam a importância do atendimento individualizado. As diretrizes do KCE (Bélgica) relatam que informações sobre estratégias de alívio da dor, analgesia farmacológica, indução, utilização de ocitocina, devem também ser informadas na forma escrita.  
O momento que essas informações devem ser oferecidas à mulher também não foi objeto de avaliação sistemática por nenhuma das diretrizes mas, a maioria dos estudos avaliados nas diretrizes do NICE foram realizados com o intuito de avaliar o impacto da comunicação e relacionamento dos prestadores de cuidado em relação à percepção das mulheres sobre a sua própria experiência de parto, no momento do trabalho de parto. As diretrizes do KCE reporta sobre informações específicas a serem dadas durante o período pré-natal.  
Em relação ao conteúdo e formato dessas informações, as diretrizes do NICE não respondem especificamente esta questão mas, como já descrito acima, algumas características do relacionamento e da comunicação dos prestadores de cuidados com as mulheres influenciaram nas suas experiências de parto. As diretrizes do KCE tem uma seção sobre temas a serem informados durante o período prénatal, mas sem nenhuma avaliação sistemática do impacto que cada um deles tem na assistência. Eestas Diretrizes adaptadas mantêm as recomendações das diretrizes-fonte, com algumas modificações. Ver recomendações.  
Quanto ao impacto da realização de um plano de parto por parte da mulher, nenhuma das diretrizes abordou esta questão.  
9.1.3.1 Outras considerações  
Os estudos incluídos nas diretrizes do NICE variaram na metodologia e no método de análise empregado. Identificou-se que o modo como os prestadores do cuidado se relacionam com as mulheres influenciam fortemente suas experiências em relação ao parto.  Os fatores mais importantes destacados foram o tratamento de forma individualizada, com respeito e carinho. Em segundo lugar, a maioria das mulheres necessitava de informações baseadas em evidência, bem explicadas e interpretadas, para se sentirem orientadas, apoiadas, seguras e protegidas ao longo do parto.  
Os estudos apresentaram os resultados listando as palavras mais utilizadas pelas mulheres para descrever tanto as enfermeiras obstétricas quanto os sentimentos envolvidos em uma experiência positiva do parto. Estas palavras incluem: carinho, consideração, compreensão, competência  
profissional, confiança, empatia, ternura, gentileza, amigabilidade, tranquilidade, atenção, calma, expertise profissional e ritmo pausado.  
- 9.1.5 Recomendações sobre Informações e comunicação  
12. Mulheres em trabalho de parto devem ser tratadas com respeito, ter acesso às informações baseadas em evidências e serem incluídas na tomada de decisões. Para isso, os profissionais que as atendem deverão estabelecer uma relação íntima com as mesmas, perguntando-lhes sobre seus desejos e expectativas. Devem estar conscientes da importância de sua atitude, do tom de voz e das próprias palavras usadas, bem como a forma como os cuidados são prestados.  
13. Para estabelecer comunicação com a mulher os profissionais devem:  
- Cumprimentar a mulher com um sorriso e uma boa acolhida, se apresentar e explicar o qual o seu papel nos cuidados e indagar sobre as suas necessidades, incluindo como gostaria de ser chamada.  
- Manter uma abordagem calma e confiante, demonstrando à ela que tudo está indo bem.  
- Bater na porta do quarto ou enfermaria e esperar antes de entrar, respeitando aquele local como espaço pessoal da mulher e orientar outras pessoas a fazerem o mesmo.  
- Perguntar à mulher como ela está se sentindo e se alguma coisa em particular a preocupa.  
- Se a mulher tem um plano de parto escrito, ler e discutir com ela, levando-se em consideração as condições para a sua implementação tais como a organização do local de assistência, limitações (físicas, recursos) relativas à unidade e a disponibiidade de certos métodos e técnicas.  
- Verificar se a mulher tem dificuldades para se comunicar da forma proposta, se possui deficiêcia auditivia, visual ou intelectual; perguntar qual língua brasileira (português ou libras) prefere utilizar ou, ainda, para o caso de mulheres estrangeiras ou indígenas verificar se compreendem português.  
- Avaliar o que a mulher sabe sobre estratégias de alívio da dor e oferecer informações balanceadas para encontrar quais abordagens são mais aceitáveis para ela.  
- Encorajar a mulher a adaptar o ambiente às suas necessidades.  
- Solicitar permissão à mulher antes de qualquer procedimento e observações, focando nela e não na tecnologia ou documentação.  
- Mostrar à mulher e aos seus acompanhantes como ajudar e assegurar-lhe que ela o pode fazer em qualquer momento e quantas vezes quiser. Quando sair do quarto, avisar quando vai retornar.  
- Envolver a mulher na transferência de cuidados para outro profissional, tanto quando solicitar opinião adicional ou no final de um plantão.  
14. Durante o pré-natal  informar as mulheres sobre os seguintes assuntos:  
- Riscos e benefícios das diversas práticas e intervenções durante o trabalho de parto e parto (uso de ocitocina, jejum, episiotomia, analgesia farmacológica, etc.);  
- A necessidade de escolha de um acompanhante pela mulher para o apoio durante o parto. Este acompanhante deve receber as informações importantes no mesmo momento que a mulher;  
- Estratégias de alívio da dor e métodos disponíveis na unidade, descrevendo os riscos e benefícios de cada método (farmacológicos e não farmacológicos);  
- Organização e indicadores assistenciais do local de atenção ao parto, limitações (física, recursos disponíveis) relativos à unidade, bem como disponibilidade de certos métodos e técnicas;  
- Os diferentes estágios do parto e as práticas utilizadas pela equipe para auxiliar as mulheres em

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.2.1 Introdução -->
Até meados do século XX, antes da hospitalização do parto, as mulheres eram atendidas em casa por uma outra mulher durante todo o trabalho de parto e parto. Com a hospitalização, principalmente no Brasil, a mulher normalmente passou a ser acompanhada por um profissional que por sua vez também tem de cuidar de várias outras parturientes ao mesmo tempo, dependendo da demanda e disponibilidade de profissionais do serviço. Dessa forma, o apoio contínuo no parto tem se tornado a exceção na maioria das maternidades brasileiras, contribuindo para uma desvalorização da experiência humana nesse momento tão particular. Esse apoio envolve aspectos emocionais, medidas de apoio, informação e advocacia. As evidências científicas atuais devem ser analisadas para se avaliar o impacto do apoio físico e emocional no parto em termos de riscos e benefícios para as mulheres e seus filhos ou filhas.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.2.2 Questões de revisão -->
- Quais os efeitos do apoio físico e emocional para mulheres em trabalho de parto?  
- Quem deve oferecer esse suporte (familiares/amigos, profissionais de saúde ou doulas)?  
- 9.2.3 Evidências Científicas  
A principal evidência analisada pelas diretrizes do NICE de 2014 se baseou em uma revisão sistemática da literatura (RS) que incluiu 15 Ensaios Clínicos com 12.791 mulheres<sup>70</sup> [NE = 1++]. Esses estudos foram realizados em países desenvolvidos e em desenvolvimento  (Austrália, Bélgica, Botswana, Canadá, Finlândia, França, Grécia, Guatemala, México, África do Sul e EUA). Observou-se uma diferença no impacto nos resultados relacionado ao status do cuidador. Na análise estratificada, um grupo teve esse suporte de cuidado realizado por profissionais do hospital (8 estudos) e no outro grupo (7 estudos) os cuidadores eram externos ao hospital com variável nível de conhecimento e treinamento específico (enfermeira aposentada, parente, marido, etc.). Em 9 estudos o hospital permitia a presença do marido ou familiar como acompanhante enquanto nos outros 6 nenhum outro tipo de suporte era permitido. Nenhum estudo investigou a efetividade do marido ou parceiro como sendo o cuidador.  
Mulheres que receberam suporte individualizado foram menos propensas a receber analgesia do que as de tratamento padrão. A diferença foi significativa tanto no grupo  apoiado pela equipe do hospital (RR 0,97 [IC 95% 0,95 – 0,99]) quanto no grupo que recebeu apoio de pessoas sem formação profissional (RR 0,83 [IC 95% 0,77 – 0,89])  
A meta-análise dos 9 ERC sem estratificação que incluiu 10.322 mulheres não apresentou diferenças significativas no tempo de trabalho de parto. Em ambos os grupos as mulheres que receberam apoio individualizado foram mais propensas ao parto vaginal natural e menos propensas ao parto vaginal instrumental e cesariana. Mulheres apoiadas pela equipe do hospital tiveram uma maior probabilidade de parto espontâneo (RR 1,03 [IC 95% 1,01 – 1,06]) e menos propensão a ter um parto vaginal instrumental (RR 0,92 [IC 95% 0,85 – 0,99]) ou cesariana  (RR 0,92 [IC 95% 0,85 – 0,99]). Se o apoio foi dado por pessoa externa ao hospital, o impacto permaneceu positivo no parto vaginal espontâneo, parto vaginal instrumental e cesariana com RR de 1,12 [IC 95% 1,07 – 1,18]), 0,59 [IC 95% 0,42-0,81] e 0,74 [IC 95% 0,61 – 0,90], respectivamente.  
Na meta-análise de todos os ensaios não parece ter havido diferenças em relação ao trauma perineal. Em um estudo, onde a taxa de episiotomia foi investigada, não foram encontradas diferenças significativas quando o suporte era fornecido por enfermeira especialmente treinada ou tratamento  
padrão (RR 0,97 [95% CI 0,90 – 1.05]). Meta-análise de dois estudos, ambos investigando o suporte realizado por membros do hospital, não encontraram diferenças significativas no trauma perineal (RR 0.99 [95% CI 0,95 – 1,03]).  
A meta-análise dos estudos não mostrou nenhuma diferença significativa nos escores de Apgar abaixo de 5 minutos (sete ensaios, RR total de 0,81 [IC 95% 0,56 – 1 ,16]; com o apoio de um membro da equipe do hospital RR 0,83 [IC 95% 0,56 – 1,22]  e com o apoio por pessoas não pertencentes às equipes hospitalares (RR 0,64 [IC 95% 0,22 – 1,92] ); e admissão em unidades neonatais (quatro ensaios RR 0,94 [IC 95% 0,82 – 1,09]).  
A insatisfação da mulher que recebeu apoio individualizado realizado por profissional do quadro do hospital em relação à experiência do parto foi estatisticamente insignificante quando comparada com o tratamento padrão. Entretanto, diminuiu bastante quando realizada por acompanhante escolhido pela mulher.  
Meta-análise de oito estudos mostrou que não houve diferenças significativas na insatisfação e experiência negativa do parto entre mulheres apoiadas por um membro do hospital (RR 0,83 [IC 95% 0,67 – 1,02]) e mulheres que receberam o tratamento padrão, mas havia uma diferença significativa se o apoio foi fornecido por pessoal não pertencente ao quadro de profissionais do hospital (RR 0,64 [IC 95% 0,58 – 0,78]). Não houve diferenças significativas entre as práticas com relação a saúde mental e autoestima da mulher.  
Um ERC que investigou a incidência de depressão pós-parto em mulheres que receberam apoio de um enfermeira especialmente treinada demonstrou que menos mulheres no grupo que recebeu apoio relataram depressão em relação àquelas que receberam o tratamento padrão, mas essa diferença não foi estatisticamente significativa (RR 0,89 [IC de 95% 0,75 – 1,05]). Outro estudo investigou o impacto da auto-estima no pós parto de mulheres que receberam apoio por uma enfermeira aposentada. Não houve diferenças no número de mulheres com baixa auto-estima no pós-parto, no grupo que recebeu apoio em relação ao grupo que recebeu o tratamento padrão (RR 1,07 [IC 95% 0,82 – 1,4])  
Um estudo investigou os resultados a longo prazo do apoio realizado  por uma enfermeira especialmente treinada, para mulheres em trabalho de parto. Não houve diferenças significativas entre os grupos em relação a um relacionamento ruim com o parceiro após o parto  (RR 1,00 [IC 95% 0,80 – 1,23]), incontinência urinária (RR 0,93 [IC 95% 0,81 – 1,06]) ou incontinência fecal (RR 0,89 [IC 95% 0,64 – 1,24])

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.2.4 Resumo da evidência e conclusões -->
As evidências demonstram que entre os principais benefícios do apoio contínuo no parto estão a diminuição da propensão à analgesia, ao parto vaginal instrumentalizado e à cesariana e uma melhor satisfação e experiência positiva do parto. O impacto sobre a satisfação e experiência positiva se torna mais evidente quando realizado por pessoas de fora do quadro de profissionais do hospital, incluindo parceiros, parentes, amigos e doulas, embora haja grande variabilidade nos estudos sobre o  grau de conhecimento, treinamento  e sobre o contexto desses cuidadores e cuidados. Dentre esses cuidadores, as evidências ainda não são fortes o suficiente para definir quem deve fazer esse papel, mas sugerem que eles se complementam.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.2.5 Outras considerações -->
Em relação aos benefícios clínicos e danos relacionados ao apoio contínuo no parto, as evidências analisadas também não demonstraram nenhum risco para a saúde das mulheres e seus filhos ou filhas embora existam poucas evidências sobre a mortalidade perinatal e o bem estar a longo prazo.  
Em relação aos benefícios para a saúde e uso de recursos no Brasil, o apoio contínuo no parto envolveria em um aumento significativo no número de profissionais que prestam assistência no país, principalmente pela equipe de enfermagem, quando se trata da utilização de pessoal das equipes hospitalares, envolvendo dessa forma maiores investimentos na formação e inserção de mais profissionais nas equipes de saúde. Por outro lado, considerando os benefícios já demonstrados, principalmente a redução de procedimentos e intervenções, esse apoio pode redundar em  menores custos. Além do mais, o apoio contínuo fornecido por pessoal de fora da equipe hospitalar, considerando algumas experiências com uso de pessoal voluntário e pessoas da própria rede social da mulher, poderia redundar em uma economia de recursos ainda mais substancial. Análises econômicas devem ser realizadas para definir mais claramente esse impacto.  
9.2.5 Recomendações em relação ao apoio contínuo no parto  
15. Todas as parturientes devem ter apoio contínuo e individualizado durante o trabalho de parto e parto, de preferência por pessoal que não seja membro da equipe hospitalar.  
16. O apoio por pessoal de fora da equipe hospitalar não dispensa o apoio oferecido pelo pessoal do hospital.  
17. Uma mulher em trabalho de parto não deve ser deixada sozinha, exceto por curtos períodos de tempo ou por sua solicitação.  
18. As mulheres devem ter pelo menos um acompanhante de sua escolha durante o trabalho de parto e parto, não invalidando o apoio dado por pessoal de fora da rede social da mulher (ex. doula).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.3.1 Introdução -->
A prática ainda comum nas maternidades brasileiras de se proibir a ingestão de alimentos líquidos ou sólidos no trabalho de parto se deve ao medo de aspiração de conteúdo estomacal durante uma anestesia. O risco entretanto, está associado à anestesia geral, que é raramente praticada, principalmente em ambientes de baixo risco. Baseado na necessidade de manter uma hidratação e um aporte calórico adequado à mulher durante o parto, assim como oferecer conforto e bem-estar, em vários locais permite-se a ingestão de alimentos leves ou fluidos durante o trabalho de parto<sup>71</sup> . Uma política de ingestão de alimentos ou líquidos durante o trabalho de parto deve ser analisada à luz dos conhecimentos atuais, avaliando os seus riscos e benefícios.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.3.2 Questão de revisão -->
 Qual a efetividade, segurança e custo-efetividade da restrição da dieta durante o trabalho de parto?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.3.3 Evidências científicas -->
As diretrizes do NICE (NCCWCH, 2014) abordou essa questão. Um ERC (n=88) com mulheres em trabalho de parto a termo, com feto em apresentação cefálica<sup>72</sup> (NE= 1+), avaliou a ingestão de uma dieta de baixo resíduo (n= 45) com apenas água (n= 43). No grupo de mulheres com restrição de alimentos houve um aumento significativo nos níveis plasmáticos de β-hidroxibutirato e ácidos graxos não esterificados (diferença da média (DM) 0,38 mmol/l [IC 95% 0,21 a 0,55 mmol/l], P < 0,001) . No grupo que ingeriu alimentos houve um aumento significativo nos níveis plasmáticos de glicose (DM 0,62 mmol/l [IC 95% 0,22 a 1,01 mmol/l], P = 0,003) e insulina (DM 15,6 mmol/l [IC 95% 2,9 a 28,3 mmol/l], P = 0,017). As medidas transversais das áreas gástricas antrais dentro de 1 hora de trabalho de parto foram significativamente maiores no grupo que alimentou (DM 1,85 cm<sup>2</sup> [IC 95% 0,81 a 2,88 cm<sup>2</sup> ], P = 0,001), assim como uma probabilidade duas vezes maior de vomitar no momento do parto (DM 19% [IC 95% 0,8% a 38%], P = 0,046). Os volumes vomitados no grupo que alimentou foram significativamente maiores (DM 205 ml [IC 95% 99 a 311 ml], P = 0,001). Os níveis de ácido lático permaneceram similares em ambos os grupos (DM −0,29 mmol/l [IC 95% −0,71 a 0,12 mmol/l], P = 0,167. O estudo não mostrou diferenças significativas na duração do primeiro e segundo períodos do parto, necessidade de ocitocina, tipo de parto, Apgar e gasometria de cordão entre os dois grupos.  
As diretrizes também abordaram medidas para prevenir a cetose durante o trabalho de parto.  Três ERCs realizados na Holanda avaliaram a ingestão de carboidratos, comparado com placebo, envolvendo ao todo 503 mulheres (NE = 1+). Os estudos variaram em relação ao momento do trabalho de parto em que as mulheres foram randomizadas assim como a permissão para ingerir outros tipos de alimentos além da solução estudada.  
No primeiro estudo, envolvendo 201 mulheres, não foram encontradas diferenças significativas entre os grupos em relação a estimulação ocitócica (RR 0,83 [IC 95% 0,55 a 1,26]), uso de opióides (RR 0,96 [IC 95% 0,44 a 2,11]), analgesia peridural (RR 1,56 [IC 95% 0,89 a 2,73], analgesia inalatória (RR 3,64 [IC 95% 0,72 a 15,8]), parto vaginal espontâneo (RR 0,90 [IC 95% 0,68 a 1,17])  ou instrumental (RR 0,78 [IC 95% 0,52 a 1,17]), escores de Apgar no 1<sup>o</sup> minuto (P = 0,17) e no 5<sup>o</sup> minuto (P = 0,18)  e gasometria de cordão (P = 0,07). O número de cesarianas foi significativamente maior no grupo que ingeriu carboidratos (RR 2,9 [IC 95% 1,29 a 6,54])<sup>73</sup> [NE = 1+].  
No segundo estudo, envolvendo 202 nulíparas,  não foram encontradas diferenças entre os grupos em relação a parto vaginal espontâneo (RR 1,07 [IC 95% 0,88 a 1,30]), parto vaginal instrumental (RR 1,05  
[IC 95% 0,69 a 1,60]) ou cesariana (RR 0,15 [IC 95% 0,02 a 1,16]),  escores de Apgar com 1 minuto (P = 0,22), 5 minutos (P = 0,32) ou pH arterial umbilical (P = 0,80). Também não houve diferenças nos níveis plasmáticos de glicose (P = 1,00), lactato (P = 0,07) ou β-hydroxybutirato (P = 0,21). Houve uma diminuição significativa nos níveis de ácidos graxos livres (P = 0,02) no grupo que ingeriu carboidratos<sup>74</sup> [NE = 1+].  
O terceiro estudo, envolvendo 100 mulheres, não demonstrou diferenças entre os grupos  em relação a parto vaginal espontâneo (P = 0,30) ou instrumental (P = 0,84). Também não foram encontradas diferenças na gasometria arterial e venosa de cordão umbilical, mas sem apresentar dados estatísticos. Ocorreram quatro cesarianas no grupo placebo e nenhuma no grupo de carboidratos<sup>75</sup> [NE = 1+]. Um ERC realizado no Reino Unido, envolvendo 60 mulheres<sup>76</sup> [NE = 1+],  avaliou a ingestão de bebidas esportivas comparada com água. No grupo que ingeriu bebidas esportivas houve uma diminuição significativa nos níveis de β-hidroxibutirato (DM −0,63 [IC 95% −0,85 a −0,42]) e ácidos graxos não esterificados (DM −0,36 [IC 95% −0,46 a −0,25]). Os níveis de glicose não se alteraram no grupo de bebidas esportivas mas diminuíram significativamente no grupo que ingeriu somente água (DM 0,76 mmol/l [IC 95% 0,22 a 1,3 mmol/l]). A quantidade de líquido ingerido foi maior no grupo de bebidas esportivas (P = 0,001).  As medidas totais de calorias ingeridas foi maior no grupo de bebidas esportivas (47 kcal/h (DP 16 kcal/h) do que no grupo que ingeriu água (0 kcal/h). Não houve diferenças na medida da área transversal gástrica antral (DM −0,63 cm<sup>2</sup> [IC 95% −1,12 a 0,70 cm<sup>2</sup> ]), volume vomitado durante o trabalho de parto (DM 66 ml [IC 95% −115 A 246 ml]) e dentro de 1 hora após o parto (DM 65 ml [IC 95% −141 a 271 ml]). Também não houve diferenças na duração do trabalho de parto, uso de ocitocina, tipo de parto e analgesia peridural entre os grupos.  
As diretrizes também avaliaram o uso rotineiro de substâncias profiláticas no trabalho de parto para reduzir a aspiração gástrica. A referência foi uma revisão sistemática de três ERC<sup>77</sup> [NE = 1+]. Os resultados demonstraram uma redução na chance de vomitar durante o trabalho de parto quando antiácidos foram comparados com nenhuma intervenção (um ensaio, n = 578; RR 0,46 [IC 95% 0,27 a 0,77])  e nenhuma diferença quando diferentes antiácidos foram comparados entre si (Gelusil® versus Maalox® (n = 300): RR 0,83 [IC 95% 0,39 a 1,75]; Gelusil® versus Mylanta II® (n = 325): RR 1,32 [IC 95% 0,58 to 2.99]); Maalox® versus Mylanta II® (n = 285): RR 1,59 [IC 95% 0,69 a 3,65]). Quando os antagonistas de H2 foram comparados com antiácidos, também não foram observadas diferenças na incidência de vômitos (um ensaio, n = 1.287; RR 0,96 [IC 95% 0,73 a 1,27]), cesariana (um ensaio, n = 1.287; RR 0,93 [IC 95% 0,59 a 1,47]), anestesia geral de emergência (um ensaio, n = 1.287; RR 0,92 [IC 95% 0,62 a 1,35]), hemorragia pós-parto (um ensaio, n = 1.287; RR 0,83 [IC 95% 0,08 a 9,14])  e morte fetal (um ensaio, n = 1.287; RR 0,69 [IC 95% 0,17 a 2,89]) .  
Os antagonistas de dopamina associados à petidina reduzem a incidência de vômitos no trabalho de parto (um ensaio, n = 584; RR 0,40 [IC 95% 0,23 a 0,68]) quando comparados com placebo ou nenhuma outro tratamento associado à petidina, sem demonstrar diferenças nos escores de Apgar < 7 com 1 minuto (RR 1,02 [IC 95% 0,62 a 1,69]) ou mortes perinatais (RR 1,22 [IC 95% 0,24 a 6,21]). A comparação entre metoclopramida e perfenazina (n = 393) também não demonstrou diferenças na ocorrência de vômitos (RR 1,45 [IC 95% 0,64 a 3,32]), escore de Apgar < 7 com 1 minuto (RR 0,83 [IC 95% 0,47 a 1,47]) ou morte perinatal (RR 0,25 [IC 95% 0,03 a 2,23]).  
9.3.4 Resumo da evidência e conclusões  
A evidência demonstra que uma dieta leve e a ingestão de soluções calóricas diminui a produção de corpos cetônicos e aumenta os níveis de glicose e insulina. Entretanto há um aumento do conteúdo  
estomacal e a probabilidade de náusea. Não existem diferenças significativas em outros resultados clínicos avaliados.  
Os estudos não tiveram força suficiente para avaliar a incidência de aspiração gástrica e Síndrome de Mendelson. A evidência disponível aponta que antiácidos ou os antagonistas de dopamina quando associados à petidina reduzem a chance de vômitos. Os receptores de H2 quando comparados com antiácidos não apresentam impacto na incidência de vômitos.  
Não foram incluídos estudos que avaliassem o impacto da dieta zero comparado com outras formas de ingestão de alimentos ou outros líquidos durante o trabalho de parto.  
- 9.3.5 Recomendações em relação à dieta e intervenções para reduzir aspiração gástrica  
19. Mulheres em trabalho de parto podem ingerir líquidos, de preferência soluções isotônicas ao invés de somente água.  
20. Mulheres em trabalho de parto que não estiverem sob efeito de opióides ou não apresentarem fatores de risco iminente para anestesia geral podem ingerir uma dieta leve.  
21. Os antagonistas H2 e antiácidos não devem ser utilizados de rotina para mulheres de baixo risco para anestesia geral durante o trabalho de parto.  
22. As mulheres que receberem opióides ou apresentarem fatores de risco que aumentem a chance de uma anestesia geral devem receber antagonistas H2 ou antiácidos.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.4.1 Introdução -->
Dentre as causas de morte materna no Brasil, a infecção ocupa o terceiro lugar, às vezes rivalizando com a hemorragia no segundo lugar. Vários são os fatores responsáveis pela ocorrência de infecções após um parto vaginal. Desde fatores intrínsecos da mulher, como a colonização do trato genital por bactérias patogênicas antes do parto, até as intervenções às quais a mulher é submetida no processo assistencial. As medidas de assepsia, largamente utilizadas na assistência ao parto com o objetivo de diminuir as complicações infecciosas, são muito variáveis dependendo do local de assistência. O real impacto dessas intervenções e qual delas é mais efetiva para a prevenção da sepse puerperal ainda é desconhecido. Por esse motivo, é importante a avaliação e análise da evidência científica disponível para poder recomendar quais as medidas de assepsia são mais eficazes para o parto vaginal.  
9.4.2 Questões de revisão  
- Quais são as medidas mais eficazes de assepsia para o parto vaginal?  
- Quais são as medidas apropriadas de assepsia e higiene para o parto na água, incluindo a banheira?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.4.3 Evidências científicas -->
As diretrizes do NICE (NCCWCH, 2014) abordaram essa questão analisando as seguintes medidas:  
- ducha vaginal com clorexidina;  
- lavagem perineal; e  
- uso de luvas duplas e outros procedimentos durante a episiotomia.  
- 9.4.3.1 Ducha vaginal com clorexidina  
As diretrizes incluíram uma revisão sistemática para análise. Esta revisão incluiu três ensaios randomizados controlados (n=3.102) realizados nos EUA, comparando a ducha vaginal com clorexidina e água estéril<sup>78</sup> [NE = 1++].  
Os resultados não evidenciaram diferença na incidência de corioamnionite entre os dois grupos (RR 1,10 [IC 95% 0,86 – 1,42]). Em relação à endometrite, os estudos sugeriram uma pequena redução no grupo que utilizou clorexidina, embora estatisticamente não significativa (RR 0.83 [IC 95% 0,61 – 1,13]).  
Em relação aos desfechos neonatais, não houve diferenças significativas nas taxas de  pneumonia (RR 0,33 [IC 95% 0,01 a 8,09]), meningite (RR 0,34 [IC 95% 0,01 a 8,29]), sepse bacterialmente confirmada (RR 0,75 [IC 95% 0,17 a 3,35]) ou mortalidade perinatal (RR 1,00 [IC 95% 0,17 a 5,79]). Houve uma tendência sugerindo que o uso da clorexidina vaginal poderia levar a uma maior necessidade de uso de antibióticos entre os recém-nascidos, embora não estatisticamente significativa (RR 1,65 [IC 95% 0,73 a 3,74]).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.4.3.2 Lavagem perineal -->
As diretriz incluíram um estudo controlado realizado no Reino Unido (n = 3.905) que comparou cetrimida/clorexidina com água potável para a lavagem perineal durante o trabalho de parto<sup>79</sup> [NE = 2+]. Foram incluídas mulheres que também foram submetidas a cesariana. O grupo que utilizou cetrimida/clorexidina envolveu 1.813 mulheres e o grupo que utilizou água envolveu 2.092 mulheres. Não houve diferenças na ocorrência de febre (TA > 38<sup>0</sup> C)  (OR 1,2 [IC 95% 0,8-1,9]), uso de antibióticos (OR 1,02 [IC 95% 0,86-1,9]), infecção perineal (OR 1,4 [IC 95% 0,77-2,7]), deiscência de períneo (OR 5,8 [IC 95% 0,3-999]) ou infecção de ferida operatória de cesariana (OR 1,3 [IC 95% 0,86 - 1,9]).  
Os resultados neonatais não demonstraram diferenças na incidência de infecção oftálmica (OR 1,1 [IC 95% 0,78 – 1.7]), onfalite (OR 1,3 [IC 95% 0,7 – 21]), outras infecções não especificadas (OR 0,87 [IC 95%  
0,65 – 1,2]), admissão para cuidados neonatais (OR 1,1 [IC 95% CI 0,9 – 1,4]), uso de antibióticos (OR 0,99 [IC 95% CI 0,82 – 1,2]) ou febre ( > 38 °C) (OR 1,4 [IC 95% 0,66 – 3,0]).  
9.4.3.3 Uso de luvas duplas durante a episiotomia e outros procedimentos  
As diretrizes incluíram dois ERC realizados na Tailândia comparando o uso de luvas duplas com luvas únicas no momento da realização da episiotomia. O desfecho analisado foi apenas a incidência de perfurações. O primeiro estudo envolvendo 2.058 conjuntos de luvas (luvas duplas n = 1.316 e luvas únicas n = 742)<sup>80</sup> [NE = 1+], relatou taxas de perfuração da luva interna de 2,7% (P < 0,05) e da externa de 5,9%, quando comparado com a luva única, de 6,7%. O outro estudo envolvendo 300 conjuntos de luvas (luvas duplas n = 150; luvas únicas n = 150) relatou taxas de perfuração de 4,6% (P < 0,05) para as luvas duplas internas e de 22,6% para as externas, comparado com as luvas únicas, de 18,0%.<sup>81</sup>  
Uma série de casos conduzida o Reino Unido (n=80) avaliou a efetividade do uso de uma manga estéril no braço por cima do capote para prevenir a contaminação durante procedimentos obstétricos<sup>82</sup> [NE = 3]. A contaminação de braços e mãos foi de 3,8 e 5%, respectivamente.  
9.4.4 Resumo da evidência e conclusões  
A evidência demonstra que a cetrimida/clorexidina não é mais efetiva do que água potável para a limpeza perineal.  
O uso de luvas duplas parece reduzir as taxas de perfuração da luva interna. Entretanto deve-se analisar os resultados com cautela já que a alocação para os grupos não foi oculta.  
A evidência é insuficiente em relação ao uso de mangas estéreis para os braços para reduzir a contaminação.  
Não existem evidências em relação ao uso de capotes e pacotes estéreis e a lavagem vulvar antes do exame vaginal ou do parto para a prevenção de infecções maternas ou neonatais. Nenhuma das diretrizes consultadas abordaram medidas específicas de assepsia e higiene para o parto na água, incluindo a banheira  
9.4.5 Recomendações sobre medidas de assepsia para o parto vaginal  
23. A água potável pode ser usada para a limpeza vulvar e perineal se houver necessidade, antes do exame vaginal.  
24. Medidas de higiene, incluindo higiene padrão das mãos e uso de luvas únicas não necessariamente estéreis, são apropriadas para reduzir a contaminação cruzada entre as mulheres, crianças e profissionais. Se as membranas estiverem rotas, recomenda-se a utilização de luvas estéreis para a realização de toque vaginal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 8.5.1 Introdução -->
Embora a grande maioria dos partos transcorram sem problemas para a criança, em algumas situações pode ocorrer interrupção da transferência de oxigênio do ambiente para o feto além daquilo que é considerado normal, podendo levar, em uma cascata de eventos, à acidemia fetal e consequentemente aos seus desfechos finais como sequelas permanentes ou mesmo a morte. Mesmo que tais eventos aconteçam com uma frequência muito rara, as suas consequências podem ser catastróficas, principalmente devido ao impacto que provocam nas famílias e nos profissionais envolvidos. Além do mais, os custos para a sociedade podem se tornar bastante elevados tendo em vista os recursos que têm que ser disponibilizados para o cuidado necessário aos indivíduos com sequelas. Além do mais, no Brasil, a asfixia/hipóxia representa uma das principais causas de mortalidade neonatal, figurando como  
terceira ou quarta causa, dependendo da região do país (BRASIL, 2012)<sup>83</sup> . O objetivo da monitoração do bem-estar fetal intraparto é avaliar a adequação da oxigenação fetal durante o trabalho de parto e consequentemente prevenir os danos resultantes da interrupção da transferência de oxigênio do ambiente para o feto. As evidências sobre quais métodos são mais adequados para tal deve ser avaliada e sintetizada para servir como ferramenta de consulta e auxílio na tomada de decisões em relação ao estado de oxigenação fetal durante o trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.5.2 Questões de revisão -->
Qual a efetividade, segurança e custo-efetividade dos diversos métodos de avaliação do bem estar fetal intraparto tais como?:  
- Ausculta intermitente com Pinard ou Doppler  
- Monitoração eletrônica intermitente  
- Monitoração eletrônica contínua

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.5.3 Evidências Científicas -->
As diretrizes do NICE de 2014 abordaram a questão da ausculta intermitente comparada com a monitoração eletrônica contínua com cardiotocografia (CTG) em mulheres de baixo risco em trabalho de parto. Foram incluídos seis estudos na revisão, quatro ERC, um quasi-randomizado e um estudo de seguimento de um dos ERCs (Grant et al., 1989<sup>84</sup> ; Kelso et al., 1978<sup>85</sup> ; Leveno et al., 1986<sup>86</sup> ; MacDonald et al., 1985<sup>87</sup> ; Vintzileos et al., 1993<sup>88</sup> ; Wood et al., 1981<sup>89</sup> ). Os desfechos considerados foram tipo de parto, mortalidade perinatal, paralisia cerebral e encefalopatia hipóxico-isquêmica. A tabela 16 apresenta os estudos e a magnitude do efeito para os desfechos estudados.  
Tabela 16: Sumário dos estudos e magnitude do efeito. Comparação entre CTG contínua e ausculta intermitente durtante o trabalho de parto  
||Número de m|ulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|CTG contínua|Ausculta<br>intermitente|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|Tipo departo:parto vag|inal espontâneo||||
|1 meta-análise de 3<br>estudos<br>(Kelso et al., 1978;<br>Vintzileos et al., 1993;<br>Wood et al.,1981)|1.036/1.444<br>(71,7%)|1.094/1.415<br>(77,3%)|RR 0,92<br>(0,89 a 0,97)|62<br>menos/1.000<br>(de 23 menos<br>a 85 menos)|
|Tipo departo:parto vag|inal instrumentalp|orqualquer moti|vo||
|1 meta-análise de 4<br>estudos<br>(Kelso et al., 1978;<br>MacDonald et al.,<br>1985;<br>Vintzileos et al., 1993;<br>Wood et al.,1981)|823/7.918<br>(10,4%)|648/7.905<br>(8,2%)|RR 1,24<br>(1,04 a 1,48)|20<br>mais/1.000<br>(de 3 mais a<br>39 mais)|
|Tipo departo:parto vag|inal instrumentalp|or sofrimento fet|al||
|1 estudo|190/6.474|75/6.490|RR 2,54|18|
|(MacDonald et al.)|(2,9%)|(1,2%)|(1,95 a 3,31)|mais/1.000|  
Tabela 16: Sumário dos estudos e magnitude do efeito. Comparação entre CTG contínua e ausculta intermitente durtante o trabalho de parto  
||Número de|mulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|CTG contínua|Ausculta<br>intermitente|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|||||(de 11 mais a<br>27 mais)|
|Tipo departo: cesariana|porqualquer mo|tivo|||
|1 meta-análise de 4<br>estudos<br>(Kelso et al., 1978;<br>MacDonald et al., 1985;<br>Vintzileos et al., 1993;<br>Wood et al.,1981)|<br>271/7.918<br>(3,4%)|224/7.905<br>(2,8%)|RR 1,19<br>(1 a 1,41)|5 mais/1.000<br>(de 0 menos<br>a 12 mais)|
|Tipo departo: cesariana|por sofrimento f|etal|||
|1 meta-análise de 4<br>estudos|133/14.761<br>(0,9%)|57/14.753<br>(0,39%)|RR 2,28<br>(1,68 a 3,1)|5 mais/1.000<br>(de 3 mais a|
|(Kelso et al., 1978;<br>MacDonald et al., 1985;<br>Vintzileos et al., 1993;||||8 mais)|
|Wood et al.,1981)|||||
|Morte fetal intraparto|||||
|1 meta-análise de 3|3/14.564|4/14.566|RR 0,76|0|
|estudos<br>(Leveno et al., 1986;<br>MacDonald et al., 1985;|(0,02%)|(0,03%)|(0,19 a 3,01)|<br>menos/1.000<br>(de 0 menos<br>a 1 mais)|
|Vintzileos et al.,1993;)|||||
|Mortalidade neonatal|||||
|1 meta-análise de 5<br>estudos|18/15.262<br>(0,12%)|25/15.299<br>(0,16%)|RR 0,72<br>(0,4 a 1,3)|0<br>menos/1.000|
|(Kelso et al., 1978;<br>Leveno et al., 1986;<br>MacDonald et al., 1985;<br>Vintzileos et al., 1993;||||(de 1 menos<br>a 0 mais)|
|<br>Wood et al.,1981)|||||
|Morbidade neonatal: Pa|ralisia cerebral||||
|1 estudo|12/6.527|10/6.552|RR 1,2|0 mais/1.000|
|(Grant et al., 1989)|(0,18%)|(0,15%)|(0,52 a 2,79)|(de 1 menos a|
|Morbidade neonatal: En|cefalopatia hipóx|ico-isquêmica||3 mais)|
|1 estudo|1/746|2/682|RR 0,46|2 menos/1.000|
|(Vintzileos et al.,|(0,13%)|(0,29%)|(0,04 a 5,03)|(de 3 menos a|  
Tabela 16: Sumário dos estudos e magnitude do efeito. Comparação entre CTG contínua e ausculta intermitente durtante o trabalho de parto  
||Número de m|ulheres/bebês|E|feito|
|---|---|---|---|---|
|Estudos|CTG contínua|Ausculta<br>intermitente|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|1993)||||12 mais)|
|Morbidade neonatal: Co|nvulsões||||
|1 meta-análise de 3<br>estudos<br>(Leveno et al., 1986;<br>MacDonald et al., 1985;|<br>8/13.072<br>(0,06%)|24/13.027<br>(0,18%)|RR 0,34<br>(0,16 a 0,75)|<br>1<br>menos/1.000<br>(de 0 menos<br>a 2 menos)<sup>a</sup>|
|Vintzileos et al.,1993)|||||
|Morbidade neonatal: He|morragia intraven|tricular|||
|1 estudo<br>(Vintzileos et al., 1993)<br>Morbidade neonatal: De|0/746<br>(0%)<br>sconforto respira|1/682<br>(0,15%)<br>tório|RR 0,3<br>(0,01 a 7,47)|<br>1<br>menos/1.000<br>(de 1 menos<br>a 9 mais)|
|1 estudo|55/746|40/682|RR 1,26|15|
|(Vintzileos et al., 1993)|(7,4%)|(5,9%)|(0,85 a 1,86)|<br>mais/1.000<br>(de 9 menos<br>a 50 mais)|
|Morbidade neonatal: Sin|tomas ou sinais n|eurológicos anorm|ais||
|1 meta-análise de 3<br>estudos<br>(Kelso et al., 1978;<br>MacDonald et al., 1985;|<br>19/5.767<br>(0,33%)|31/5.804<br>(0,53%)|RR 0,62<br>(0,35 a 1,09)|<br>2<br>menos/1.000<br>(de 3 menos<br>a 0 mais)|
|Wood et al.,1981)|||||
|Admissão em UTIN ou b|erçário||||
|1 meta-análise de 5<br>estudos<br>(Kelso et al., 1978;<br>Leveno et al., 1986;<br>MacDonald et al.,<br>1985; Vintzileos et al.,<br>1993; Wood et al.,<br>1981)|780/15.200<br>(5,1%)|753/15.291<br>(4,9%)|RR 1,03<br>(0,94 a 1,13)|1 mais/1.000<br>(de 3 menos a<br>6 mais)|
|Gasometria arterial ao n|ascer:pH venoso|ou arterial < 7,10|||
|1 meta-análise de 2|36/1.279|29/1.215|RR 0,92|2 menos/1.000|
|estudos<br>(MacDonald et al.,|(2,8%)|(2,4%)|(0,27 a 3,11)|(de 17 menos a<br>50 mais)|  
Tabela 16: Sumário dos estudos e magnitude do efeito. Comparação entre CTG contínua e ausculta intermitente durtante o trabalho de parto  
||Número de|mulheres/bebês|Ef|eito|
|---|---|---|---|---|
|Estudos|CTG contínua|Ausculta<br>intermitente|Relativo<br>(IC 95%)|Absoluto<br>(IC 95%)|
|1985; Vintzileos et al.,<br>1993;)|||||  
IC intervalo de confiança, RR risco relativo, UTIN unidade de terapia intensiva neonatal CTG cardiotocografia  
Em relação à monitoração eletrônica intermitente, as diretrizes do NICE não abordaram o assunto que foi abordado nas diretrizes espanholas que identificaram um ERC realizado na Suécia<sup>84</sup> (366) (NE = 1+) e que estava incluído na RS anterior. Foram incluídas 4.044 mulheres. O grupo com monitoração intermitente foi monitorado por 10 a 30 minutos, a cada 2 ou 2 horas e meia durante o primeiro período do parto e os batimentos cardio-fetais foram auscultados a cada 15-30 minutos entre os períodos. No Segundo período do parto a monitoração foi contínua. O grupo cobtrole foi submetido a monitoração eletrônica contínua. Não foram observadas diferenças entre os grupos em relação a frequência cardíaca fetal suspeita ou patológica, cesariana por suspeita de comprometimento fetal, pH umbilical, escores de Apgar ou admissão em UTI neonatal. Não foram feitas comparações entre a monitoração eletrônica intermitente e a ausculta fetal intermitente.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.5.4 Resumo da evidência e conclusões -->
A evidência demonstrou que no grupo monitorado com CTG contínua ocorreram menores taxas de parto vaginal espontâneo (n=2.859) e maiores taxas de cesariana e parto vaginal instrumental por comprometimento fetal (n=15.823). Também houve uma maior incidência de convulsões (n=16.099) nos recém-nascidos do grupo de ausculta intermitente, mas nenhuma diferença na mortalidade (n=30.561); paralisia cerebral (n=13.079); encefalopatia hipóxico-isquêmica, (n=1.428); hemorragia intra-ventricular (n=1.428); desconforto respiratório (n=1.428); sinais ou sintomas de anormalidades neurológicas (n=11.571); admissão em UTI (n=30.491); e pH umbilical.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 9.5.5 Outras considerações -->
A evidência disponível aponta que a ausculta intermitente com estetoscópio de Pinard ou sonnar Doppler é tão segura quanto a CTG contínua para avaliação do bem-estar fetal em parturientes de baixo risco. Em relação aos benefícios clínicos e danos, a CTG aumenta a incidência de intervenções tais como parto instrumental e cesariana, sem impacto positivo nos indicadores de morbidade e mortalidade perinatal. Embora no grupo de ausculta intermitente tenha ocorrido mais convulsões, não houve diferença nos outros indicadores finais de saúde neonatal. Em relação à monitoração eletrônica intermitente, a mesma só foi comparada com a monitoração contínua, não apresentando diferenças nos desfechos analisados entre os dois grupos.  
Em relação aos benefícios para a saúde e uso de recursos no Brasil, a evidência demonstra que uma política de ausculta intermitente é mais vantajosa do que a CTG contínua, tendo em vista o custo e manutenção dos equipamentos. Por outro lado, uma avaliação do bem-estar fetal com qualidade, mesmo utilizando a ausculta intermitente, envolve uso intensivo de recursos humanos, médicos ou de enfermagem, acarretando também mais custos do que o usual no Brasil. Uma política de utilização de pessoal de enfermagem especialmente treinado para esse fim pode significar mais qualidade assistencial com economia de recursos.  
- 9.5.6 Recomendações em relação à avaliação do bem-estar Fetal  
25. A avaliação do bem-estar fetal em parturientes de baixo risco deve ser realizada com ausculta intermitente, em todos os locais de parto.  
- Utilizar estetoscópio de Pinard ou sonar Doppler:  
- realizar a ausculta antes, durante e imediatamente após uma contração, por pelo menos 1 minuto e a cada 30 minutos, registrando como uma taxa única;  
- registrar acelerações e desacelerações se ouvidas;  
- palpar o pulso materno se alguma anormalidade for suspeitada para diferenciar os batimentos fetais e da mãe.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.1 Introdução -->
A dor durante o trabalho de parto é um aspecto fisiológico importante, responsável por desencadear a liberação de endorfinas e outras substâncias endógenas relacionadas não só com a maior tolerância à dor, mas com a sensação de prazer e satisfação no parto. Por essa razão, a assistência obstétrica adequada não deve estar centrada no objetivo de garantir a ausência de dor, nem esta deve ser um marcador da qualidade da assistência ao parto.  
A dor excessiva e insuportável pode estar relacionada a fatores culturais, emocionais, à insuficiência de apoio qualificado à mulher e às práticas assistenciais inadequadas.  
Para algumas parturientes, a dor pode requerer alguma forma de alívio e nas suas manifestações extremas pode resultar em trauma psicológico, enquanto para outras os efeitos colaterais indesejáveis da analgesia podem ser deletérios. Durante o pré-natal, a construção de expectativas maternas flexíveis em relação ao parto e aos resultados de diferentes métodos de alívio da dor, pode influenciar o bem estar psicológico durante o trabalho de parto e depois do nascimento. Não necessariamente as formas mais efetivas de alívio da dor estão associadas com maior satisfação com a experiência do parto e, por outro lado, a falha de um método previamente escolhido pode levar à não satisfação.  
O objetivo do controle da dor é dar apoio à mulher, aumentar seu limiar para as sensações dolorosas e contribuir para que o parto seja uma experiência positiva. Este capítulo lidará especificamente com o controle da dor durante o trabalho de parto, avaliando e analisando sistematicamente os métodos de alívio, não farmacológicos e farmacológicos, além da experiência e satisfação das mulheres em relação ao alívio da dor.  
10.2 Experiência e satisfação das mulheres em relação à dor no trabalho de parto  
10.2.1 Questões de revisão  
- Quais são os efeitos da dor no progresso do parto e na satisfação das mulheres em relação à sua experiência de parto?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.2.2 Evidências Científicas -->
As diretrizes do NICE incluíram uma revisão sistemática que por sua vez incluiu vários estudos que avaliaram a satisfação das mulheres durante o parto em relação à dor e outras intervenções<sup>90</sup> [NE = 2++], incluindo tanto estudos descritivos como ensaios clínicos randomizados e revisões sistemáticas. Nesta revisão foi incluída uma revisão sistemática e 20 ERCs que preencheram os critérios de inclusão para estudos que incluíram o alívio da dor como uma medida de satisfação da mulher como desfecho. O método mais comum para avaliação da satisfação foi a escala visual analógica (EVA) no período pósnatal. A relação entre dor, alívio da dor e experiência das mulheres com o nascimento é complexa. Em  
uma pesquisa britânica, mulheres muito ansiosas com a dor do parto no período pré-natal estiveram menos satisfeitas depois do nascimento. As mais satisfeitas foram aquelas que não receberam substâncias para o alívio da dor durante o parto. Já em um estudo australiano a chance de insatisfação foi maior quando as mulheres avaliaram negativamente seus prestadores e quando sentiam que não tinham sido ativamente envolvidas no processo de tomada de decisão. A síntese das evidências de todos os estudos envolvidos levou à conclusão de que existem quatro fatores relacionados com a satisfação com a experiência do parto e a dor do nascimento: a) expectativas pessoais; b) quantidade de apoio dos prestadores; c) qualidade da relação prestador-usuária; d) envolvimento no processo de decisão. 10.2.3 Resumo da evidência e conclusões  
A experiência do nascimento varia enormemente entre as mulheres e é influenciada por muitos fatores, incluindo suas expectativas, grau de preparação para o parto, complexidade do parto e intensidade da dor. A atitude e o comportamento do prestador é consistentemente vista como a influência mais óbvia e poderosa na satisfação da mulher. Mulheres são mais satisfeitas com o alívio da dor quando as suas expectativas de dor e como elas escolhem lidar com elas se encontram.  
10.2.4 Recomendação em relação à experiência e satisfação das mulheres com o alívio da dor no  
- trabalho de parto  
26. Os profissionais de saúde devem refletir como suas próprias crenças e valores influenciam a sua atitude em lidar com a dor do parto e garantir que os seus cuidados apoiem a escolha da mulher.  
10.3 Estratégias e métodos não farmacológicos de alívio da dor no trabalho de parto  
10.3.1 Questões de revisão  
- Qual a efetividade, segurança e custo-efetividade dos diversos métodos não farmacológicos de alívio da dor no parto tais como:  
- Imersão em água?  
- Banhos de chuveiro?  
- Massagem?  
- Injeção subcutânea de água estéril?  
- Uso de bolas?  
- Estimulação elétrica transcutânea?  
- Técnicas de relaxamento?  
- Acupuntura?  
- Hipnose?  
- Musicoterapia?  
- Outros?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.1 Imersão em água -->
As diretrizes do NICE incluíram uma revisão sistemática<sup>91</sup> [NE = 1+] que, por sua vez, incluiu 8 ERCs além de 1 ERC isolado para a sua revisão<sup>92</sup> [NE = 1-]. A meta-análise de 4 ERCs relatados na revisão demonstrou uma redução significativa na necessidade de analgesia regional com a imersão em água (OR 0,84; IC 95% 0,71-0,99) (NE = 1+). O ERC isolado demonstrou redução significativa da dor para as mulheres que tiveram o trabalho de parto na água (OR 0,23; IC 95% 0,08-0,63). Também ficou demonstrado, na meta-análise de 4 ERCs, não haver diferenças na duração do primeiro e segundo período do trabalho de parto entre as mulheres que utilizaram a água comparado com as que não utilizaram. Na meta-análise de 6 ERCs também não foram encontradas diferenças nas taxas de cesariana  
(OR 1,33 [IC 95% 0,92 a 1,91]), parto vaginal instrumental (OR 0.83 [IC 95% 0,66 a 1,05]), episiotomia (OR 0,89 [IC 95% 0,68 a 1,15]), laceração de segundo grau (OR 0,90 [IC 95% 0,66 a 1,23]) ou de terceiro/quarto grau (OR 1,38 [IC 95% 0,85 a 2,24])[NE = 1+].  
Em relação aos resultados neonatais, cinco ERCs não encontrou diferenças no número de recémnascidos com escore de Apgar < 7 no quinto minuto (OR 1,59 [IC 95% 0,63 a 4,01]). Em dois ERCs as admissões em unidade neonatal foram semelhantes nos dois grupos (OR 1,05 [IC 95% 0,68 a 1,61]). As taxas de infecção relatadas em quatro ERCs foram muito baixas (6/629 versus 3/633; OR 2,01 [IC 95%  
0.,50 a 8,07]).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.1.2 Banhos de chuveiro -->
Nenhuma das diretrizes consultadas abordou essa questão.  
10.3.2.3 Massagem  
As diretrizes do NICE incluíram duas revisões sistemáticas que avaliaram o uso da massagem e do toque terapêutico  para alívio da dor durante o trabalho de parto<sup>93,94</sup> [ambos NE = 1+]. Cada revisão incluiu 2 ERCs, com um total de 3 estudos, 2 pequenos ERCs (24 e 60 pacientes) e um estudo observacional. Não foi possível realizar meta-análise devido às diferenças entre os ERCs. Ambos os ERCs demonstraram uma significativa redução da dor do trabalho de parto percebida tanto pelas enfermeiras como observada pelas mulheres, sem nenhuma menção à necessidade de analgesia. No menor estudo também se observou redução significativa no estresse e na ansiedade intraparto, bem como melhoria no humor materno tanto intraparto como pós-natal. No estudo observacional incluindo 90 mulheres observou-se redução significativa da ansiedade materna no grupo recebendo massagem (P < 0,05). 10.3.2.4 Injeção intradérmica de água estéril  
As diretrizes do NICE incluíram duas revisões sistemáticas que incluíram os mesmos quatro ERCs (tamanho amostral variando de 35 a 272 mulheres), incluindo mulheres em trabalho de parto com dor nas costas<sup>93,94</sup> [NE = 1+] . Diferenças nos ERCs não tornaram a meta-análise possível. Nos quatro ERCs a dor nas costas foi significativamente reduzida por 45-90 minutos com as injeções intradérmicas de água estéril. Apesar do alívio da dor, não houve diferenças no uso subsequente de analgesia. Uma das maiores desvantagens desse método de alívio da dor é a dor intensa que muitas mulheres relatam durante a administração das injeções.  
Não há evidências acerca do efeito das injeções subcutâneas de água na experiência do nascimento ou outros desfechos clínicos.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.5 Uso de bolas -->
Nenhum estudo foi encontrado avaliando o uso de bolas suíças durante o trabalho de parto e portanto não há evidência de qualquer efeito dessas sobre a experiência do parto e os desfechos clínicos. 10.3.2.6 Estimulação elétrica transcutânea (TENS)  
As diretrizes do NICE incluíram uma revisão sistemática que incluiu 10 ERCs com 877 mulheres<sup>95</sup> . Nenhuma diferença na intensidade da dor ou no alívio da dor foi encontrada para mulheres recebendo TENS comparadas com controles.  Também não houve diferenças na necessidade de intervenções analgésicas adicionais (RR 0,88 [IC 95% 0,72 a 1.07]). Nenhum efeito adverso foi relatado.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.7 Técnicas de relaxamento -->
Um ERC<sup>94</sup> foi encontrado dentro de uma revisão sistemática de terapias complementares durante o trabalho de parto mas incluiu apenas 54 mulheres. Houve uma significativa redução na dor intraparto relatada pelas mulheres que receberam a intervenção, porém esse efeito só foi observado em mulheres que eram muito ansiosas durante a gravidez.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.8 Acupressão e Acupuntura -->
As diretrizes do NICE incluíram uma revisão sistemática que avaliou três ERCs<sup>96-98</sup> usando acupuntura, com razoável homogeneidade e um que avaliou a acupressão no ponto SP6<sup>99</sup> [NE = 1+]. A acupuntura reduziu significativamente o uso de métodos farmacológicos para alívio da dor (RR 0,74; IC 95% 0,630,86), analgesia peridural (RR 0,45; IC 95% 0,29-0,69) e a necessidade de uso de ocitocina (RR=0,58; IC 95% 0,40-0,86).  Em um ERC não houve diferença nos escores de dor depois da acupuntura nem na taxa de parto vaginal espontâneo. Outros desfechos como satisfação materna, complicações maternas e neonatais não foram investigados. A acupressão demonstrou um redução nos escores de dor (DMP −1,20 [IC 95% −2.04 a −0,36]), mas nenhuma evidência de diferenças na necessidade de métodos farmacológicos de alívio da dor (RR 0,54 [IC 95% 0,20 a 1,43]).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.9 Hipnose -->
Uma revisão sistemática envolveu 5 ERCs e 14 estudos comparativos, porém só foram considerados os resultados dos ERCs<sup>100</sup> [NE = 1+]. A hipnose reduziu significativamente o uso de métodos farmacológicos de alívio da dor (RR 0,51; IC 95% 0,28-0,98) e a necessidade de ocitocina (RR 0,31; IC 95% 0,18-0,52). Nenhum outro desfecho foi avaliado.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.10 Musicoterapia -->
As diretrizes do NICE incluíram um ERC envolvendo 110 mulheres na sua revisão<sup>101</sup> [NE = 1+].  Houve uma significativa redução da sensação e do sofrimento da dor, porém nenhum outro desfecho foi avaliado.  Não há evidências de alto nível sobre os efeitos da música sobre dor e outros desfechos do parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.3.2.11 Audioanalgesia e aromaterapia -->
As diretrizes do NICE incluíram um ERC que estava incluído em uma revisão sistemática<sup>102</sup> , realizado no reino Unido [NE = 1+] que avaliou o efeito da áudio-analgesia utilizando ‘barulho do mar’ a 120 decibéis comparado com o mesmo barulho a 90 decibéis não evidenciando diferenças na satisfação materna entre os dois grupos (RR 2.00 [IC 95% 0,82 a 4,89]). Outros desfechos não foram avaliados.  
Também foi incluída uma revisão sistemática com um ERC realizado na Nova Zelândia<sup>102</sup> que comparou a utilização de óleo de gengibre e folhas de limão na banheira não demonstrando diferenças no uso de analgesia farmacológica (RR 2,50 [IC 95% 0,31 a 20,45]), parto vaginal espontâneo (RR 0,93 [IC 95% 0,67 a 1,28]), parto vaginal instrumental (RR 0,83 [IC 95% 0,06 a 11,70]) ou cesariana (RR 2,54 [IC 95% 0,11 a 56,25]). Outros desfechos não foram avaliados. [NE = 1+]  
10.3.3 Resumo da evidência e conclusões sobre estratégias e métodos não farmacológicos de alívio da  
dor  
A imersão em água demonstrou efeitos positivos no controle da dor sem evidências de efeitos adversos maternos, com resultados neonatais equivalentes, sem risco aumentado de infecção. Evidências limitadas sugerem alívio da dor e da ansiedade maternas com massagem intraparto. Não há evidência de que outros desfechos sejam influenciados pela massagem.  
A injeção subcutânea de água estéril pode proporcionar algum alívio da dor, mas a dor relatada durante o procedimento limita o seu uso.  
Há evidência de boa qualidade documentando a falta de efeito do TENS em mulheres com trabalho de parto estabelecido mas não existem evidências sobre efeitos do TENS em mulheres na fase latente do trabalho de parto.  
Não há evidências de que técnicas de relaxamento reduzam a dor mensurada no trabalho de parto ou afetem qualquer outro desfecho.  
A acupuntura está associada com a redução no uso de analgesia farmacológica mas sem impacto nos escores de dor.  
A hipnose parece se associar com a redução no uso de analgesia farmacológica e estimulação ocitócica, mas há ausência de evidência em relação aos escores de dor.  
Não há evidências de alto nível sobre musicoterapia, áudio-analgesia e aromaterapia no alívio da dor ou qualquer outro desfecho no parto.  
10.3.3 Outras considerações em relação às estratégias e métodos não farmacológicos de alívio da dor Embora o uso da água no trabalho de parto apresente benefícios no controle da dor, sem efeitos adversos relatados para a mãe ou para a criança, a sua utilização no Brasil envolve o redesenho das unidades de assistência ao parto, já que a maioria delas não possuem banheiras, com dispêndio de recursos para a sua operacionalização. Tal fato deve ser considerado quando da construção ou reforma de unidades assistenciais.  
Em relação a outros métodos de alívio da dor que ofereçam algum efeito positivo, apesar da limitação das evidências, não há o envolvimento significativo de recursos, dependendo entretanto da mudança de atitudes dos profissionais envolvidos.  
- 10.3.4 Recomendações em relação às estratégias e métodos não farmacológicos de alívio da dor no trabalho de parto:  
27. Sempre que possível deve ser oferecido à mulher a imersão em água para alívio da dor no trabalho de parto.  
28. Os gestores nacionais e locais devem proporcionar condições para o redesenho das unidades de assistência ao parto visando a oferta da imersão em água para as mulheres no trabalho de parto.  
29. Se uma mulher escolher técnicas de massagem durante o trabalho de parto que tenham sido ensinadas aos seus acompanhantes, ela deve ser apoiada em sua escolha.  
30. Se uma mulher escolher técnicas de relaxamento no trabalho de parto, sua escolha deve ser apoiada.  
31. A injeção de água estéril não deve ser usada para alívio da dor no parto.  
32. A estimulação elétrica transcutânea não deve ser utilizada em mulheres em trabalho de parto estabelecido.  
33. A acupuntura pode ser oferecida às mulheres que desejarem usar essa técnica durante o trabalho de parto, se houver profissional habilitado e disponível para tal.  
34. Apoiar que sejam tocadas as músicas de escolha da mulher durante o trabalho de parto.  
35. A hipnose pode ser oferecida às mulheres que desejarem usar essa técnica durante o trabalho de parto, se houver profissional habilitado para tal.  
36. Por se tratar de intervenções não invasivas e sem descrição de efeitos colaterais, não se deve coibir as mulheres que desejarem usar audio-analgesia e aromaterapia durante o trabalho de parto.  
37. Os métodos não farmacológicos de alívio da dor devem ser oferecidos à mulher antes da utilização de métodos farmacológicos.  
- 10.4 Analgesia inalatória  
- 10.4.1 Questões de revisão  
- Qual a efetividade, segurança e custo-efetividade da analgesia inalatória para alívio da dor no parto em relação a outras formas de analgesia e a não realização de analgesia?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.4.2 Evidências científicas -->
As diretrizes do NICE incluíram uma revisão sistemática sobre o uso de óxido nitroso, incluindo oito ERCs e oito estudos observacionais<sup>103</sup> [NE = 2+]. Devido à inconsistência dos métodos de análise, os resultados são resumidos de forma descritiva. Embora não tenha sido encontrada nenhuma evidência clara, quantitativa e objetiva, sete estudos descreveram analgesia efetiva com o óxido nitroso e dois estudos relataram que as mulheres escolheram continuar usando óxido nitroso mesmo depois do período do estudo. Nenhuma alteração do óxido nitroso sobre a contratilidade uterina foi encontrada e também não houve efeitos sobre a progressão do trabalho de parto. Náusea e vômitos variaram entre 5% e 36%. Nos quatro estudos que avaliaram escores de Apgar não houve evidência de qualquer diferença e um estudo não demonstrou diferença em uma escala de comportamento neurológico precoce.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.4.3 Resumo da evidência sobre analgesia inalatório no trabalho de parto -->
A evidência é moderada para apoiar o uso de óxido nitroso durante o trabalho de parto. Não há evidência de riscos para o bebê.  
10.4.4 Outras considerações em relação à analgesia inalatória no trabalho de parto  
Em relação à analgesia inalatória, há de se considerar os custos adicionais da sua implementação, tendo em vista a ausência de familiaridade com o seu uso no Brasil, não estando disponível na quase totalidade das unidades de assistência ao parto. Além do mais, como se trata da incorporação de uma nova tecnologia no Brasil, isso deve envolver todo um processo de avaliação e incorporação de tecnologias no sistema público no país.  
10.4.5 Recomendações em relação à analgesia inalatória no trabalho de parto  
38. O óxido nitroso a 50% em veículo específico pode ser oferecido para alívio da dor no trabalho de parto, quando possível e disponível, mas informar às mulheres que elas podem apresentar náusea, tonteiras, vômitos e alteração da memória.  
10.5 Analgesia intramuscular e endovenosa  
10.5.1 Questões de revisão  
- Qual a efetividade segurança e custo-efetividade dos diversos métodos de analgesia intramuscular ou endovenosa para alívio da dor no parto em relação a outras formas de analgesia e a não realização de analgesia tais como?:  
- Petidina/meperidina  
- Pentazocina  
- Remifentanila  
- Fentanila  
- Tramadol  
- Outros  
10.5.2 Evidências Científicas  
10.5.2.1 Uso Intramuscular de opióides  
10.5.2.1.1 Petidina versus placebo  
Foram incuídos dois ERCs um deles relatado em duas RS<sup>104-106</sup> (NE = 1+]. O primeiro avaliou 224 parturientes, demonstrando melhor analgesia  no grupo de petidina, porém em ambos observou-se alto grau de insatisfação com a qualidade da analgesia ofererecida (taxa de insatisfação 83% versus 71%, P = 0,04). O segundo estudo, desenvolvido em Hong-kong em 2004<sup>106</sup> , observou novamente que a petidina se difere do placebo (queda média no EVA: petidina −11 mm versus placebo +4 mm;  P = 0,009; EVA médio: petidina 54 versus 78 mm, P = 0,01 e escala de satisfação 1 à 5 pts: petidina média 2 versus

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.5.2.1.2 Dose de opióide: Baixa dose (40-50 mg) versus alta dose (80 -100 mg). -->
As diretrizes do NICE incluíram dois ERCs conduzidos em 1970 que foram relatados nas duas RS já descritas<sup>104,105</sup> (NE = 1+], que tentaram definir a melhor dose de petidina intramuscular em um total de 170 gestantes. A taxa de mulheres insatisfeitas foi alta em ambas as doses: baixa dose 42/55 versus alta dose 37/57 (RR 1.73 [IC 95%  0,77 a 3,88]). A interferência nos escores de dor, independente da dose, também foram discretas. As mulheres em esquema de baixa dose solicitaram mais por nova dose de analgésico. A incidência de náusea, assim como tonteira foram maiores no grupo de alta dose, porém sem significância estatística. Náusea (9/88 versus 17/85; OR 0,46 [IC 95% 0,20 a 1,06]. Sonolência/tonteira (11/68 versus 19/65; OR 0,48 [IC 95% 0,21 a 1,07]). A necessidade de naloxona foi maior no grupo de alta dose, porém a mostra era muita pequena e inapropriada para suportar esta evidência.  
Além da petidina foi incluido 1 ERC, que também estava incluído nas duas RS já descritas, que comparou uma dose de Tramadol 50 mg versus 100 mg. O estudo incluiu 60 gestantes e demonstrou que uma dose menor esteve associada a maior número de mulheres insatisfeitas (27/30 versus 7/30; OR 14,44 (IC 95% 5,24 a 39,74]), sendo a diferença na incidência de efeitos adversos (náusea e sonolência e tonteira) não significativa.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.5.2.1.3 Diferentes opióides por via intramuscular. -->
As diretrizes do NICE incluíram duas RS que por sua vez incluiram três ERCs que compararam o uso do tramadol 150 mg (IM) versus a petidina 50 a 100 mg (IM).<sup>104,105</sup> [NE = 1+] envolvendo 144 mulheres. Observou-se vantagem estatística, porém clinicamente discreta, com o uso o uso da petidina (DMP na EVA com o uso da petidia:  13,20 mm [IC 95% 0,37 a 26,03 mm]). Porém o número de mulheres insatisafeitas (5/50 versus 13/49; OR 1,18 [IC 95%  0,49 a 2,84]), incidência de náusea-vômitos (6/74 versus 9/70; OR 0,63 [IC 95%  0,21 a 1,84]), sonolência (16/74 versus 22/70; OR 0,61 [IC 95% 0,29 a 1,29]) e demais desfechos foram semelhantes. Não foram avaliados os desfechos neonatais.  
Foi também incluído um ERC<sup>107</sup> realizado na Turquia que constatou que nenhuma das substâncias foi efetiva para alívio da dor de parto, quando avaliadas pela escala de Lickert, (Escala de alívio de 0 – 5: petidina = 4 e tramadol = 5 (p < 0,05). Os efeitos adversos também foram mais incidentes com o tramadol, destacando-se uma alta incidência de náusea (1/29 versus 9/30, P = 0,004) e fadiga (15/29 versus 23/30, P = 0,045). Neste ensaio foram avaliados os desfechos neonatais, observando-se alta incidência de depressão respiratória neonatal (petidina 3/29 versus tramadol 7/30), necessidade de oxigenioterapia suplementar e admissão em UTI. A média do escore de Apgar no primeiro minuto foi 7,76 (DP 1,06) para a petidina e 7,13 (DP 1,38) para o tramadol. No quinto minuto foi 9,28 (DP 0,65) para a petidina e 9,17 (DP 0,91) para o tramadol.  
Nas mesmas RS citadas anteriormente, também foi incluida a comparação entre petidina e meptazinol e pentazocina. [NE = 1+]<sup>104,105.</sup> Foi realizada metanálise de seis ERC que comparou Petidina 100 mg (IM) versus a pentazocina 40-60 mg (IM) em um total de 678 gestantes. Os autores concluiram que estas substâncias fornecem analgesia semelhantes, porém a  pentazocina deve ser administrada mais vezes para obtenção do mesmo benefício. Não foram observadas diferenças significativas quanto a sonolência/tonteira e náusea. Em virtude da pequena amostra de cada estudo, não foi realizada análise de desfecho neonatal.  
Na duas RS já citadas[NE = 1+]<sup>104,105</sup> também foram comparadas a petidina 50 mg (IM) versus  o meptazinol 100 mg (IM) em seis ERCs totalizando 1.906 parturientes. As medidas de analgesia foram  
similares para as duas substâncias sem diferenças significativas nos vários desfechos de dor mensurados. No maior ensaio incluído da revisão (n = 1.035) a petidina esteve associada em menos náusea e vômitos de forma significativa (184/498 versus 141/507; OR 1,52 [IC 95% 1,17 a 1,98]). A metaanálise de todos os ensaios manteve essa diferença (OR 1,37 [IC 95% 1,09 a 1,72]). O maior ensaio da revisão também demonstrou mais tonteira/sonolência no grupo que recebeu petidina (202/522 versus 147/513; OR 0,64 [IC 95% 0,49 a 0.83]). Não foram encontradas diferenças no tipo de parto, comprometimento fetal, escores de Apgar, morte neonatal e admissão em unidade neonatal. Ficou demnostrado maior necessidade de admnistração de naloxane para os recém-nascidos no grupo de petidina (231/496 versus 198/479; OR 0,81 [IC 95% CI 0,63 a 1,04]).  
Um ERC inglês comparou o uso intramuscular da petidina versus a diamorfina em 133 gestantes.<sup>108</sup> [NE = 1+]. As doses foram petidina 100 a 150 mg e diamorfina 7,5 mg a 5 mg. As nulíparas receberam mais dose (150 ou 7,5mg) do que as multíparas (100 ou 5mg); e todas receberam proclorperazina como antiemético profilático. A diamorfina obteve maior redução no escore na EVA (58 versus 67; média −9.00 [IC 95% −10,21 a −7,79], P < 0.0001) e menor taxa de mulheres insatisfeitas (35 versus 56; RR 0,63 [IC 95% 0,43 a 0,94], P = 0,02). Assim como menor incidência de vômitos (11 versus 28; RR 0,39 [IC 95% 0,17 a 0,86], P = 0,02).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.5.2.2 Uso intravensoso de opióides -->
10.5.2.2.1 Petidina versus placebo  
As diretrizes do NICE incluíram dois ERCs<sup>109-110</sup> [NE = 1+]. O primeiro, realizado nos EUA em 2004, avaliou 407 parturientes após 4-6 cm de dilatação, quanto à eficácia e interferência nos desfechos obstétricos<sup>109</sup> . As mulheres foram randomizadas para receber petidina 100 mg IV versus placebo. A diferença na incidência de dor intensa (escore de dor na EVA > 7 em uma escala de 7-10) foi estatisticamente significativa com RR de proteção para petidina variando de 0,87 no início e de 0,77 ao fim da primeira hora. Porém 66% das parturientes do grupo de petidina reclamaram de dor intensa. A incidência de efeitos adversos (náusea, vômitos e tonteria) foi maior no grupo de petidina: RR 1,91 [IC 95% 1,44 a 2,53]. A petidina também esteve associada a necessidade de maior uso de ocitocina (RR 2,24 [IC 95% 1,13 a 4,43]) e significativa interferência nos desfechos neonatais: Apgar < 7 no primeiro minuto (RR 4,11 [IC 95% 1,72 a 9,80]; pH de cordão umbilical < 7.20: RR 1,55 [IC 95% 1,13 a 2,14]; pH arterial de cordão umbilical < 7,10 (RR 3,94 [IC 95% 1,76 a 8,82]. Não houve diferença no apgar do quinto minuto.  
O segundo estudo, desenvolvido na Tailândia em 2002, avaliou 84 parturientes após 3-5 cm de dilatação quanto à eficácia e efeitos adversos. A dose de petidina dependia do peso da gestante. Se < 75 kg, somente 50 mg, do contrário 75 mg. Observaram-se resultados muitos semelhantes à análise anterior. Foram encontradas diferenças significativas nos escores médios de dor, que foram menores do grupo de petidina, e efeitos adversos que foram mais frequentes no grupo de petidina. Porém, a taxa de mulheres que consideraram efetivo o alívio da dor foi baixa em ambos os grupos: petidina 23,8% versus placebo 7,1%. Os autores não reportaram quanto ao desfecho neonatal.  
10.5.2.2.2 Dose de opiódie para uso intravenoso  
As diretrizes do NICE incluíram apenas um estudo tipo dose/resposta da morfina endovenosa no trabalho de parto ativo realizado na Suécia<sup>111</sup> [NE = 3]. Morfina endovenosa foi administrada a 17 gestantes, em doses progressivas de 0,05 mg/kg até um máximo de 0,2 mg/kg.  Dor e sedação forma mensurados em escala de 100 mm. O escore álgico pré e pós morfina  alcançou diferença estatisticamente significativa: Pré = 85 mm (53 a 100 mm]  e pós = 70 mm (46 a 99 mm), z = 2,49, P = 0,01, Wilcoxon test), assim como o número de mulheres que tiveram alívio da dor referida nas costas:  
Pré = 13/14 e pós = 4/14 (P = 0,01). A dor referida no abdome não teve alívio significativo. Quanto ao efeito sedativo: Pré = 0 mm versus 78 mm (56,1 a 99,5), P < 0,05. 10.5.2.2.3 Petidina versus outros opióides por via endovenosa  
As diretrizes do NICE incluíram vários estudos comparando petidina com outros opióides que são descritos a seguir.  
Um ERC realizado nos EUA em 2005<sup>112</sup> [NE = 1−], comparou três grupos: petidina 50 mg versus butorfanol 1 mg versus associação (petidina 25 mg + butorfamol 0,5 mg) avaliando a eficácia (escala 0- 10) e efeitos adversos. Todos os três grupos obtiveram alívio da dor, somente moderado, em relação ao estado pré-analgésico. Butorfanol: 7,2 (DP 0.6) versus 5,5 (DP 0,8), P < 0,05; petidina: 7,4 (DP 0,4) versus 5,2 (DP 0,5), P < 0,05; butorfanol + petidina: 7,4 (DP 0,4) versus 4,7 (DP 0,8), P < 0,05). O grau de analgesia e sedação não diferiu significativamente entre os grupos. Anormalidades no rítmo cardíaco fetal também não diferiu entre os grupos: (n = 5, 3, 5 para butorfanol, petidina e associação, respectivamente). Apenas duas crianças tiveram apgar < 8 no primeiro minuto e todas tiveram Apgar ≥ 8 no quinto minuto.  
Dois ERCs ingleses compararam a eficácia e segurança da petidina versus a remifentanila, ambos em regime de PCA (“analgesia peridural controlada pela paciente”). No primeiro<sup>113</sup> [NE = 1+], 40 mulheres foram alocadas para receber petidina PCA 15 mg/10 min ou remifentanila PCA 40 mcg/2 min. Todas elas também estavam em uso de N20 50% inalatório. Não houve diferença no escore de dor EVA (0-10 cm): Remifentanila EVA médio de 6,4 cm (1,5 cm) versus petidina EVA média de 6,9 cm (1,7 cm), porém houve significativa diferença quanto ao grau de satisfação (0-10) em 60 minutos de PCA: Peditina média 8,0 [IQR 7,5 a 9,0] versus 6,0 [IQR 4,5 a 7,5], P = 0,029). Não houve diferença quanto aos efeitos adversos analisados: Náusea, vômitos, sedação, ansiedade e tempo de saturação < 94% e < 90%. Na análise do desfecho neonatal os bebês nascidos de mães do grupo petidina obtiveram menores Escores de Capacidade Neurológica Adaptativa em 30 minutos, sem diferença aos 120 minutos de nascimento. Não houve diferença quanto aos demais desfechos neonatais: rítmo cardíaco fetal, escore de Apgar e pH de cordão.  
O segundo ensaio<sup>114</sup> [NE = 1−] foi uma amostra pequena com apenas nove parturientes. A dose dentre os grupos foram de remifentanila PCA 0,5 mg/kg/2 min versus petidina PCA 10 mg/5 min. O grupo remifentanila exibiu escores de dor  menores e estatísticamente significante durante a após o parto, porém não expressou resultados em números, mas apenas graficamente. Não ocorreram episódios de hipotensão, bradicardia e bradipnéia materna. Quanto ao desfecho neonatal o estudo apresenta seus resultados mais relevantes. O escore de Apgar de primeiro e quinto minuto foram significativamente menores no grupo de petidina PCA (1 minuto: remifentanila = média 9 [DP 9 a 9]; petidina = média 5,5 [Dp 5 a 8], P = 0.01; (5 minutos: remifentanila média = 10 [DP 9 a 10]; petidina média = 7,5 [DP 6 a 9], P = 0,04), sendo um bebê do grupo petidina admitido em UTI. O estudo foi terminado em função dos malefícios observados com a petidina nesta comparação inicial.  
Um ERC canadense115 [NE = 1−] comparou dois opióides lipossolúveis em regime de PCA em 23 gestantes. Fentanila (bolus 50 mcg + PCA 10 mcg/5 min + infusão contínua 20 mcg/h) versus alfentanila (bolus 500 mcg + PCA 100 mcg/5 min + infusão contínua 200 mcg/h). Não foram observadas diferenças quanto ao escore de dor, sedação, náusea e prurido, assim como desfechos neonatais: escore de Apgar, neuroadaptação, pH  venoso de cordão umibilical e necessidade de naloxona. Quanto à taxa de insatisfação, 5 das 12 mulheres do grupo alfentanila contra 9 em 11 do grupo fentanila consideraram a analgesia inadequada (P = NS).  
10.5.2.3 Comparação entre opióides IM versus EV versus PCA As diretrizes do NICE incluíram vários estudos que são descritos a seguir:  
Um ERC canadense116 [NE = 1−], comparou petidina via EV (bolus 25 mg + 60 mg/hora + resgate máximo de 25 mg/h) versus petidina via IM (injeções de 50 mg a 100 mg 2/2 horas com dose máxima de 200 mg) em 39 gestantes. A via endovenosa foi associada a menores escores de dor; porém o  estudo apresenta alguns viéses. A começar, pelo fato de que a dose de petidina no grupo EV foi significativamente menor (média de 82 mg versus 121 mg), assim como oito pacientes do grupo IM também utilizaram anestesia inalatória (N20 50%). Não houve diferença quanto aos demais desfechos.  
Um ERC escocês<sup>117</sup> [NE = 1+] comparou diamorfina via IM (7,5 mg em nulíparas ou 5 mg em multíparas) versus diamorfina via EV (bolus 1,2 mg + PCA 0,15 mg/5 min; 1,8 mg/h) em 354 gestantes. Em caso de solicitação analgesia adicional por analgesia insatisfatória, a peridural foi considerada. Os resultados são descritos em nulíparas e multíparas separadamente. Nulíparas:  O grupo endovenoso PCA (EV-PCA) utilizou quantidade de analgésico significativamente menor  do que o grupo intramucular (IM: média 3,2 mg/hora; EV-PCA: média 1,7 mg/hora; diferença 1,5 mg/hour [IC 95% 1,1 a 1,9 mg/hora], P < 0,001). Porém mais de 80% das pacientes em ambos os grupos utilizaram outra técnica de analgesia concomitantemente (óxido nitroso à 50% ou EETN).  Apenas 15% das nulíparas em uso da diamorfina não necessitaram de solicitar outra técnica analgésica, porém não houve diferença quanto ao requerimento de peridural entre os grupos. Taxa de insatisfação foi maior no grupo EV-PCA (PCA 35% versus IM 7%, RR 5,08 [IC 95% 2,22 a 11,61]). Escore de dor EVA (0-10) no grupo IM foi significativamente menor do que no grupo EV-PCA (5,3 versus 6,7, diferença 1,4 [IC 95% 0,8 a 2,0]). Multíparas: Novamente o grupo endovenoso PCA utilizou quantidade de analgésico significativamente menor  do que o grupo intramucular (IM: média 3,1 mg/hora; EV-PCA: média 1,6 mg/hora; diferença 1,6 mg/hora [IC 95% 1,1 a 2,0 mg/hora], P < 0,001). Menor número de multíparas em uso de diamorfina EV chegaram ao término do parto sem necessitar outra forma de analgesia. 61% versus 79%, RR 0,77 [IC 95%  0,61 a 0,97], porém não houve diferença quanto à solicitação de peridural.  Assim como anteriormente, nas multíparas a taxa de insatisfação foi maior no grupo EV-PCA, porém não foram constatadas difrenças no escore de dor. Os autores, avaliando os pobres resultados da diamorfina EV, ponderaram que a falta de costume e confiança com o regime de PCA levaram as pacientes a requererem menos bolus, assim como desejar mais facilmente outros métodos.  
O terceiro ERC realizado no Reino Unido comparou via endovenosa versus intramuscular<sup>118</sup> [NE = 1−] de peditina 100 mg via IM versus remifentanila via EV (20 mcg/3min) em uma pequena amostra de 36 gestantes (5 multíparas e 13 nulíparas em cada grupo). O escore de dor em EVA de 10 cm foi significativamente menor no grupo de remifentanila EV-PCA: média 48 versus 72 na primeira hora, P = 0,0004; e escore máximo nas duas primeiras horas 66,5 versus 82; P = 0,009). Duas e sete pacientes apresentaram saturação < 94% nos grupos de petidina e remifentanila respectivamente, entretanto o grau de saturação mínima  e frequencia respiratória não diferiu entre os grupos. Não houve diferenças quanto a incidência de náusea. Mulheres sob remifentanila EV tiveram menos partos vaginais espontaneos (11/18 versus 16/17, P = 0,04). Não houveram diferenças no escore de Apgar, porém este desfecho somente foi avaliado no sub-grupo que não recebeu peridural. 10.5.3 Resumo das evidências e conclusões  
Independente do opióide e sua via de administração (IM ou EV) o efeito analgésico é limitado. A petidina é o agente historicamente mais utilizado e muitos centros não disponibilizam outros tipos de opióides. Existem evidências limitadas que sugerem mais efetividade analgésica e menor interferência  
no desfecho neonatal com a diamorfina e o remifentanila. Como os estudos avaliam uma miscelânia de agentes, vias e esquemas de infusão, não foi possível um agrupamento das evidências que apontem para uma dose e esquema ideal, principalmente visando a menor interferência neonatal e na amamentação.  
- 10.5.4 Recomendações sobre opióides por via endovenosa ou intramuscular  
39. Os opióides não devem ser utilizados de rotina pois os mesmos oferecem alívio limitado da dor e apresentam efeitos colaterais significativos para a mulher (náusea, sonolência e tonteira) e para a criança (depressão respiratória ao nascer e sonolência que pode durar vários dias) assim como interferência negativa no aleitamento materno.  
40. Diante da administração de opióides (EV ou IM) utilizar concomitantemente um anti-emético.  
41. Até duas horas após administração de opióides (EV ou IM) ou se sentirem sonolentas, as mulheres não devem entrar em piscina ou banheira.  
42. Analgesia com opióides é acompanhada de aumento na complexidade da assistência ao parto, como por exemplo: maior necessidade de monitorização e acesso venoso.  
43. Uma vez que a segurança da realização de analgesia farmacológica no ambiente extra-hospitalar ainda não foi estabelecida, esta é restrita ao complexo hospitalar, seja bloco cirúrgico ou PPP (sala de pré-parto, parto e pós-parto).  
- 10.6 Analgesia regional

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.1 Introdução -->
A história da analgesia de parto está intimamente ligada à história da anestesia e impulsionou o desenvolvimento das técnicas regionais. Em 1900, Kreis utilizou pela primeira vez a raquianestesia em seis parturientes suíças, porém a anestesia e o calibre das agulhas não era apropriado, resultando em bloqueio motor e cefaléia respectivamente. Em 1942, Hingson, Edwards e ToMHy introduziram a analgesia peridural contínua e a raquianestesia em sela. Em 1981, Brownridge divulga o método promissor da anestesia combinada: raquiperidural. Já no final do século passado, os anestésicos locais foram combinados com outros agentes, ditos adjuvantes. Tal fato propiciou a redução na concentração dos anestésicos, o que notadamente contribuíu para preservação da função motora e propiocepção materna. Na última década a analgesia de parto tem caminhado no sentido de se adequar às expectativas maternas, visando colocar a mãe como protagonista de seu parto. Deambular, assumir a posição desejada e participar ativamente do nascimento, sem ser privada por uma dor incapacitante são desejos que impulsionam a ciência para técnicas cada vez mais peculiares ao contexto. A história da analgesia de parto no Brasil é recente e se desenvolveu consecutivamente às descobertas nos países mais desenvolvidos. O objetivo dessa seção é  analisar e sintetizar as evidências disponíveis em relação aos diversos métodos e técnicas e substâncias empregadas na analgesia regional para alívio da dor no parto<sup>119,120</sup> .

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.2 Questões de revisão -->
- Qual a efetividade, segurança e custo-efetividade da analgesia regional no parto em relação a não realização de analgesia, outras formas de analgesia e entre si?:  
- Raquidiana  
- Peridural tradicional  
- Peridural com baixa dose que permite deambulação  
- Raquidiana-peridural combinada  
- Qual o momento mais apropriado para a utilização destes métodos de analgesia regional?  
- Qual o método mais efetivo de uso da analgesia regional para alívio da dor e minimização das taxas de parto instrumental no segundo período do parto?  
- Quais controles maternos e fetais, além do habitual, devem ser realizados durante o uso da analgesia regional?  
- Qual a efetividade da infusão de soluções cristalóides imediatamente antes da realização e para manutenção da analgesia regional?  
- Qual a efetividade da manutenção da analgesia regional no segundo período do parto em relação ao controle da dor, satisfação da mulher, duração do segundo período e necessidade de parto operatório (fórceps, vacuum ou cesariana)?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.3 Analgesia regional versus outras formas de analgesia ou nenhuma analgesia 10.6.3.1 Evidências Científicas -->
10.6.3.1.1 Analgesia peridural versus nenhuma analgesia farmacológica  
As diretrizes do NICE incluíram apenas um estudo realizado no México em 1999<sup>121</sup> que foi incluído em uma revisão sistemática<sup>122</sup> o qual comparou a analgesia peridural com pacientes sem qualquer tipo de analgesia farmacológica. (NE = 1+) Este estudo admitiu 129 nulíparas em início da fase ativa de trabalho de parto (peridural: n = 69; sem analgesia: n =  63). O resultado mais significativo deste trabalho foi a taxa de dor intensa; 9 e 100% para primigestas com analgesia peridural e sem analgesia respectivamente. A duração de primeiro estágio foi reduzido no grupo de analgesia peridural (média - 119,0 minutos IC 95% -154,5 a -83,50 min), porém não houve diferenças quanto ao segundo estágio (média -6,03 minutos IC 95% -12,61 a -0,55 min). Não houve diferenças significativas quanto ao tipo de parto.  
Estudos como o relatado são raros pela dificuldade de proceder uma randomização neste cenário. Há mais de uma década a analgesia de parto é de indicação materna, neste ponto se interpõe um problema ético, não há como aleatorizar e excluir um dos grupos de gestantes.  
10.6.3.1.2 Analgesia peridural em relação a outras formas de analgesia farmacológica As diretrizes do NICE incluíram vários estudos sumarizados a seguir:  
Uma revisão sistemática da Cochrane que por sua vez icluiu 21 ERCs<sup>122</sup> , um dos quais, já relatado acima, comparou a analgesia peridural com nenhuma analgesia. Destes estudos, foram excluídos três por se tratarem de parturientes com doença hipertensiva associada a gravidez. Das 5.576 mulheres em trabalho de parto incluídas na meta-análise, todas tinham ≥ 36 semanas de gestação e em um estudo foram incluídas mulheres com início do parto induzido e espontâneo. Todos os ensaios compararam a analgesia peridural com opióides. Os benefícios da peridural se concentraram nas variáveis de alívio da dor (qualidade, latência e necessidade de re-intervenção), os resultados além de estatísticamente significante são clinicamente relevantes. A peridural foi fator de proteção na percepção de dor durante o primeiro e segundo estágio do trabalho de parto (primeiro estágio: DMP −15,67 [IC 95% −16,98 a −14,35]; segundo estágio: DMP -20,75 [IC 95% -22,50 a -19,01] 2 ERC; n= 164 ). Outros resultados foram o menor tempo de latência entre a administração da analgesia e o alívio da dor (1 ERC; DMP -6,7 min; [IC 95% -8,02 a -5,38]) e a menor necessidade de reintervenção analgésica (13 ERC; RR 0,05 [IC 95% 0,02 a 0,17]) no grupo de peridural. A peridural não influenciou no grau de satisfação da mulher com o alívio da dor (5 ERC; RR  1,18 [IC 95% 0,92 a 1,5]) e com a experiência de parto (1 ERC; RR 0,95 [IC 95% 0,87 a 1,03]). Os desfechos negativos associados à peridural foram: prolongamento do segundo estágio (10 ERC; DMP 18,96 min [IC 95% 10,87 a 27,06 ), elevação da taxa de parto instrumental (15 ERC; RR 1,34 [IC 95% 1,2 a 1,5]), maior necessidade de ocitocina(10 ERC; RR 1,19 [IC 95% 1,02 a 1,38]), maior incidência  
de hipotensão arterial (6 ERC; RR 58,49 [IC 95% 21,29 a 160,66]), temperatura materna ≥ 38° (2 ERC; RR 4,37 [IC 95% 2,99 a 6,38), retenção urinária (3 ERC; RR 17,05 [IC 95% 4,82 a 60,39]).  
Em relação ao estado fetal, no grupo de peridural houve menos necessidade de se utilizar naloxona nos recém nascidos (4 ERC; RR 0,15 [IC 95% 0,06 a 0,40]) sem diferença na taxa de pH de cordão <7,2 (5 ERC; RR 0,87 Ic 95% 0,71 a 1,07).  
Não foram encontradas diferenças em relação a: cesariana (17 ERC; RR 1,08 [IC 95% 0,92 a 1,26]), duração do primeiro estágio do trabalho de parto, trauma perineal, cefaléia, dor nas costas e Apgar < 7 ao quinto minuto.  
Foi realizada outra meta-análise dos estudos incluídos na revisão onde a peridural foi realizada em baixas doses (bupivacaína ≤ 0,25% ou equivalente) demonstrando aumento no risco de parto instrumental (7 ERC; RR 1,31 [IC 95% 1,14 a 1,49]), maior duração do segundo estágio do trabalho de parto (4 ERC; DMP 20,89 minutos [IC 95% 10,82 a 29,57 minutos]) e maior uso de ocitocina (4 ERC; RR 1,31 [IC 95% 1,03 a 1,67]).  
Uma outra revisão sistemática incluiu 14 ERCs e 4.324 gestantes, sendo 11 ERCs presentes na metaanálise anterior<sup>123</sup> NE = 1+. A revisão incluiu também dois estudos de coorte prospectivos realizados com o objetivo de avaliar a amamentação e a incontinência urinária. Os resultados foram muito semelhantes em relação à outra meta-análise. Apenas a satisfação materna foi maior no grupo de peridural (OR 0,27 [IC 95% 0,19 a 0,38] P < 0,001). Um dos estudos de coorte demonstrou um aumento significativo nas taxas de incontinência urinária no pós-parto imediato com a peridural, diferença essa não evidente aos 3 e 12 meses após o parto. No outro estudo não foram demonstradas diferenças no sucesso do aleitamento materno aos 6 meses.  
Outra meta-análise se concentrou apenas no desfecho fetal, especificamente na análise do equilíbrio ácido-básico no sangue de cordão. Foram incluídos oito ERCs com um total de 2.268 mulheres, sendo seis presentes na revisão da Cochrane de 2005 já descrita<sup>124</sup> (NE = 1+) e outros cinco não ERCs com um total de 185 mulheres. Os resultados demonstraram que  a peridural está associada a melhor pH na artéria umbilical (DMP 0,009 [IC 95% 0,002 a 0,015] P = 0,007) assim como o excesso de bases (DMP 0,779 meq/L [IC 95% 0,056 a 1,502] P = 0,035).  
Além destas três revisões sistemáticas, no mesmo período, outros cinco estudos relevantes e de boa qualidade foram publicados em revistas de grande impacto, os quais foram incluídos na revisão das diretrizes do NICE.  
Um ERC realizado nos E.U.A incluindo 715 gestantes analisou especificamente a elevação da temperatura materna após a peridural em comparação com a petidina endovenosa em regime de PCA (“analgesia peridural controlada pela paciente”)<sup>125</sup> (NE = 1+). A peridural esteve associada a maior elevação da temperatura auricular > 38°C [peridural = 54/358 (15%) vs PCA = 14/357 (4%), P < 0.001]. A análise por paridade demonstrou que este efeito foi aparente nas nulíparas e não nas multíparas [nulíparas com peridural = 47/197 (24%) versus nulíparas com PCA =  9/189 (5%), P < 0.001; multíparas com peridural 7/161 (4%) versus multíparas com PCA 6/168 (3%), NS]. Análise de regressão logística demonstrou os seguintes fatores independentes associados com elevação da temperatura: duração do trabalho de parto maior que 12 horas, utilização de ocitocina e monitoração fetal interna. Os fatores independentes mais importantes foram a nuliparidade e a distócia de trabalho de parto. Nesse estudo 90% dos recém-nascidos das mulheres que tiveram febre intra-parto foram submetidos a triagem para sepse e receberam antibiótico, mas não houve diferenças entre o grupo de peridural e o grupo controle. Um estudo de coorte prospectivo realizado nos E.U.A analisou especificamente a variedade de  
apresentação do polo cefálico em 1.562 parturientes<sup>126</sup> (NE = 2+) comparando os grupos com  peridural (n = 1.439) e sem qualquer outro tipo de analgesia (n= 123). As gestantes foram submetidas a ultrasonografia, por operador único, acompanhando o posicionamento fetal. Em mais de 92% das mulheres a primeira avaliação foi feita antes dos 4 cm de dilatação. A última avaliação ecográfica ocorreu ao final do período de dilatação, sendo a posição ao nascimento também aferida pelo profissional assistente. A peridural esteve associada a maior incidência de occípito posterior (OP) no momento do parto:  [OP início do trabalho de parto por USG; peridural = 23,4% vs controle = 26%. NS]; [OP final do período diltação por USG; peridural = 24,9% vs controle = 28,3%.NS]; [OP no parto por análise clínica; peridural = 12,9% vs controle = 3,3%. P = 0,002]. O risco de OP em relação com occípito anterior (OA) no grupo de peridural foi em média 4 vezes maior (OR 4 [IC 95% 1.4 a 11.1]). A peridural não se associou à posição occípito transversa (OR 1.3 [IC 95% 0.6 a 3.0]). O tipo de parto em relação à posição do pólo fetal foi: parto espontaneo (OA = 76,2%, OP = 17,4% e OT = 13,5%; P < 0,01); parto instrumental (OA = 17,5%, OP = 17,9% e OT = 12,7%) p < 0,4 NS); cesariana (OA = 6,3 %, OP = 64,7% e OT = 73,8%; P < 0,001). A associação da peridural com a variedade OP não se traduziu em elevação do parto instrumental, porém as posições não OA se associaram a taxas muito elevadas de cesariana. Cerca de 50% das paciente em outra posição que não OA ao nascimento tiveram partos prolongados (> 18 horas). Sendo o tempo de parto uma co-variável relevante quanto ao tipo de parto.  
Uma análise secundária do banco de dados deste último ERC avaliou a influência da peridural na curva de Friedman e a necessidade de ocitocina entre os dois grupos<sup>127</sup> (NE = 1+ ). O critério para início da ocitocina era ausência de dilatação durante dois horas de de trabalho de parto ativo. Os resultados associaram a peridural a um prolongamento do período de dilatação (primeiro estágio; peridural = 5,2 h [IC 95% 3,9 a 8,0) vs petidina = 4 h [IC 95% 2,7 a 7,0 ) P < 0,001] sem comprometer o estágio seguinte; ao uso de ocitocina (peridural = 44% vs petidina = 32% p < 0,009); aumento de fórceps (peridural = 12% vs petidina = 3% P < 0,003) sem diferenças na taxa de cesariana (peridural = 5% vs petidina = 6% P < 0,94). Um estudo de coorte prospectivo realizado no Canadá avaliou a influência da peridural na incidência de dor lombar<sup>128</sup> [NE = 2+]. Foram incluídas 329 mulheres que receberam peridural (n = 164) e um grupo controle (n = 165). Após análise de regresão logística multivariada ficou demonstrado uma associação significativa da peridural com aumento na dor lombar (mediana: 1 [0 a 8] versus 0 [0 a 8], P < 0.05). Para o subgrupo de mulheres que relataram dor lombar durante a gravidez este efeito foi ainda mais aparente no grupo de peridural (RR ajustado 2,05 [IC 95% 1,07 a 3.92]). Estas diferenças desapareceram 7 dias e 6 semanas após o parto (dia 7: RR ajustada 1.00 [IC 95% 0,54 a 1,86]; 6 semanas: RR ajustada 2,22 [IC 95% 0,89 a 5,53]).  
Outro estudo de coorte de base populacional realizado na Suécia, envolvendo 52 maternidades e 94.217 mulheres analisou prospectivamente o tipo de parto em parturientes que receberam peridural vs controle<sup>129</sup> [NE = 3+]. Não foi encontrada nenhuma associação entre a analgesia peridural e a incidência de cesariana não eletiva. A menor proporção de cesariana (9,1%) foi nas unidades com o menor e maior uso de peridural (20–29% e 60–64% respectivamente), com uma OR 0,84 [IC 95% 0,77 a 0,93] e OR 0,85 [IC 95% 0,77 a 0,93], respectivamente (a OR foi calculada tendo as unidades com 40–49% como referência). Em outras categorias de uso da peridural (30–39%, 40–49% e 50–59%) a taxa de cesariana variou de 10,3% a 10,6%, sem diferenças estatísticas. Também não foram encontradas diferenças no uso da peridural e a taxa de parto instrumental, sendo o mesmo mais comum nas unidades com uso de peridural na faixa de 50–59%, OR 1,23 [IC 95% 1,18 a 1,29] compardo com o grupo de 40–49%. A menor taxa de parto instrumental (14,1%) foi encontrada nas unidades com uso de peridural na faixa de 30–  
39%, OR 0,88 [IC 95% 0,84 a 0,92]. Também não foram encontradas diferenças entre as unidades de acordo com os seus níveis de complexidade (I, IIb, IIa e III).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.3.2 Resumo das evidências e conclusões -->
Considerando apenas as evidências de alto nível, demonstradas em um único ERC, a analgesia peridural comparada com ausência de analgesia farmacológica, é eficaz na redução da dor e não interfere no tipo de parto.  
Considerando apenas as evidências de alto nível, quando se compara a analgesia peridural com opióides venosos, conclui-se que:  
- Proporciona alívio da dor mais efetivo.  
- Está associada a efeitos benéficos no pH umbilical fetal.  
- Está associada a prolongamento do segundo estágio do trabalho de parto, assim como elevação da taxa de parto instrumental.  
- Não prolonga o primeiro estágio de parto, embora esteja associada a necessidade de ocitocina.  
- Não influencia significativamente as taxas de cesariana intraparto.  
Considerando apenas as evidências de alto nível, conclui-se que os efeitos adversos da analgesia regional são:  
- Elevação da temperatura materna de nulíparas; particularmente naquelas em trabalho de parto prolongado.  
- Hipotensão materna (quanto maior for a concentração de anestésico local utilizada)  
- Retenção urinária (com eventual necessidade de cateterismo vesical de alívio)  
Considerando as evidências de nível inferior, quando se compara a analgesia peridural com opióides venosos, conclui-se que:  
- A analgesia peridural está associada a um aumento na incidência da variedade de posição do polo cefálico em occípito posterior (OP), particularmente naquelas em trabalho de parto prolongado.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.3.3 Outras considerações -->
Em relação aos benefícios clínicos e riscos para a saúde quando se compara a analgesia peridural com outra formas de analgesia farmacológica como o uso de opióides intravenosos ou intramusculares, as evidências apontam que a analgesia peridural é mais eficiente no controle da dor e não interfere de maneira significativa na incidência de cesarianas, embora aumente a duração do segundo período do parto e a incidência de parto instrumental. Outros efeitos negativos como hipotensão, elevação da temperatura materna e retenção urinária também estão associados à intervenção e devem ser levados em consideração quando do aconselhamento das mulheres. Em relação a outras variáveis finais de morbidade materna e perinatal, não há evidências de efeitos adversos significativos.  
Em relação ao uso de recursos e benefícios para a saúde no Brasil, deve ser levado em consideração o custo da disponibilização da analgesia regional nas maternidades, principalmente nas públicas.  
- 10.6.3.4 Recomendações em relação a analgesia regional versus outras formas de analgesia de parto:  
44. A analgesia regional deve ser previamente discutida com a gestante antes do parto e seus riscos e benefícios devem ser informados.  
45. As seguintes informações devem ser oferecidas à mulher:  
- A analgesia regional só está disponível no ambiente hospitalar  
- É mais eficaz para alívio da dor que os opióides  
- Não está associada com aumento na incidência de dor lombar  
- Não está associada com primeiro período do parto mais longo ou aumento na chance de cesariana  
- Está associada com aumento na duração do segundo período do parto e na chance de parto vaginal instrumental  
- Necessita de nível mais elevado de monitoração e a mobilidade pode ser reduzida  
46. Uma vez que a segurança da realização de analgesia farmacológica no ambiente extra-hospitalar ainda não foi estabelecida, esta é restrita ao complexo hospitalar, seja bloco cirúrgico ou PPP (sala de pré-parto, parto e pós-parto).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.4 Momento de administração da analgesia regional -->
10.6.4.1 Evidências científicas  
As diretrizes do NICE incluíram seis estudos de qualidade aceitável.<sup>130-136</sup> Pela heterogeneidade dos mesmos não foi possível reuni-los em meta-análise e portanto serão sumariamente descritos: Um ERC realizado nos EUA e publicado em 1994, avaliou mulheres em trabalho de parto espontâneo e induzido. Foram incluídas parturientes com dilatação inicial de 3 a 5 cm, (149  mulheres de parto induzido e 334 outras de parto espontaneo) que foram randomizadas para receber bupivacaína peridural à 0,25% ou nalbufina endovenosa.<sup>130,131</sup> [NE = 1+]. Em ambas as populações (parto induzido e parto espontâneo) houve diminuição nos escores de dor 30 e 120 minutos após a aleatorização, assim como maior incidência de hipotensão nas mulheres que receberam analgesia peridural na fase precoce do trabalho de parto. Os recém-nascidos  das mulheres que recebram nalbufina na fase precoce do trabalho de parto tiveram um pH de cordão umbilical menor que no grupo de perianalgesia. Em relação aos desfechos centrais, tempo dos estágios e via de parto, não houveram diferenças em se iniciar precocemente a analgesia peridural.  
Um estudo de coorte prospectivo com alocação sequencial envolvendo 60 mulherres foi conduzido na Itália<sup>132</sup> [NE = 2+] com o objetivo de determinar a concentração mínima do anestésico local (CMAL) peridural nas fases precoces (dilatação cervical média de 2 cm) e tardia (dilatação cervical média de 5 cm) do trabalho de parto. Demonstrou-se que a concentração mínima de anestésico local necessária para alívio da dor nas pacientes com média de 2 cm de dilatação era estatisticamente diferente daquelas com média de 5 cm, sendo maior nessas últimas.  
Um ERC realizado em Taiwan e publicado em 1999<sup>133</sup> [NE = 1+] randomizou 120 gestantes com dilatação menor ou igual a 4 cm para a utilização peridural de fentanila 5mcg/ml versus nenhum anestésico local. Os resultados mostraram maior controle da dor em relação ao grupo controle, sem acrescer qualquer malefício aos demais defechos como duração e tipo do parto, gasometria arterial de cordão e escores de Apgar.  
Outros estudos realizados em Israel em 1998<sup>134</sup> e 2006<sup>135</sup> [NE = 1+] e nos EUA em 2005<sup>136</sup> [NE = 1+] conduziram randomizações semelhantes, demostrando que a analgesia peridural precoce em comparação com seu início tardio não está associada a qualquer desfecho negativo, seja duração ou via do parto. Destes últimos estudos convém destacar o realizado nos EUA, envolvendo 750 nulíparas, que utilizou a via intratecal para a administração precoce de fentanila, estando a bupivacaína peridural ultradiluída à 0,0625% com fentanila 2 mcg/ml disponível em regime de PCA (“analgesia peridural controlada pela paciente”)<sup>136</sup> . Os resultados demostraram associação da utilização precoce da analgesia regional com menor tempo de primeiro estágio e maiores escores de Apgar. Um dos estudos realizados em Israel<sup>135</sup> se diferiu dos demais por administrar analgesia peridural precoce, especificamente antes dos 3 cm (embora o critério de admissão no estudo fosse uma cérvix apagada 80% e ao menos duas  
contrações dolorosas em 10 minutos). Não houve diferença quanto aos desfechos, exceto pelo fato de que as gestantes alocadas no grupo peridural tardia gostariam de ter sido sorteadas no grupo precoce (p< 0.001).  
10.6.4.2 Resumo das evidências e conclusões sobre momento para administração da analgesia regional Considerando  evidências de alto nível, quando se compara a analgesia peridural inciada precoce versus tardiamente, conclui-se que:  
- Proporciona alívio mais efetivo da dor, sem prolongar os estágios do trabalho de parto ou modificar a via de parto e a taxa de instrumentalização.  
10.6.4.3 Outras considerações  
A escolha da solução analgésica regional deve considerar o momento do parto, onde na fase precoce são requeridas concentrações ultradiluídas de anestésico local ou apenas opióide lipossolúvel. Um único estudo, porém de alta qualidade, aponta benefício da via intratecal para a administração de opióides, observando aceleração do primeiro estágio de trabalho de parto e melhor desfecho neonatal imediato. 10.6.4.4 Recomendação em relação ao momento para administração da analgesia regional  
47. A solicitação materna por analgesia de parto compreende indicação suficiente para sua realização, independente da fase do parto e do grau de dilatação. Isto inclui parturientes em fase latente com dor intensa, após esgotados os métodos não farmacológicos.  
10.6.5 iniciando a analgesia regional  
10.6.5.1 Evidências científicas  
10.6.5.1.1 Dose (concentração x volume ) para se iniciar a analgesia peridural  
As diretrizes do NICE incluíram três estudos comparando diferentes doses de anestésico local peridural, todos em associação com fentanila para o início da analgesia peridural. Por se tratarem de trabalhos heterogênos, são avaliados em separado:  
Bupivacaína 15 mg versus 25 mg combinada com 50 microgramas de fentanila.  
Um estudo realizado no Reino Unido publicado em 1966 que incluiu 60 mulheres.<sup>137</sup> [NE = 1+] comparou 15 mg e 25 mg de bupivacaína (ambos em 15 ml), combinado com 50 microgramas de fentanila, para o estabelecimento da analgesia peridural. Houve evidência de que mulheres que receberam uma dose menor de bupivacaína tiveram menor bloqueio motor do que as mulheres do outro grupo. Não houve indícios de diferenças em outros resultados.  
Bupivacaína 0,5% versus 0,2% versus 0,1%  
<mark>Um estudo realizado na Bélgica e publicado em 1998 que incluiu 58 mulheres</mark><sup>138</sup> [NE = 1+] comparou 20 mg de bupivacaína, administrada em 0,5% (4ml), 0,2% (10 ml) ou 0,1% (20 ml), para estabelecimento da analgesia peridural. <mark>Constatou-se que as mulheres submetidas à bupicavaína 0,2% ou 0,1% sentiram menos dor e aquelas submetidas à bupicavaína 0,1% obtiveram um início de analgesia mais rápido do que aquelas do grupo de 0,2%.</mark> Não houve indícios de diferenças em outros resultados. Ropivacaina 0,2% versus 0,15% versus 0,1%  
Um estudo realizado nos Estados Unidos, publicado em 1999, que incluiu 68 mulheres.<sup>139</sup> [NE = 1+] comparou 13 ml de ropivacaína tanto a 0,2%, 0,15% ou 0,1% para estabelecimento de analgesia peridual durante o parto. Houve evidência de que mulheres do grupo com 0,2% foram mais propensas a ter uma analgesia mais adequada (mensurada pela pontuação de dor) do que as dos outros grupos. <mark>Não houve indícios de diferença com relação a efeitos adversos.</mark>  
<mark>10.6.5.1.2 Técnica (Analgesia peridural versus analgesia raqui-peridural combinada - RPC)</mark>  
As diretrizes do NICE incluíram vários estudos que são sumarizados a seguir.  
Uma RS que incluiu 14 ERCs (n = 2.047 mulheres)<sup>140</sup> [NE = 1+]  que foi realizada para avaliar os efeitos relativos da raqui – peridural combinadas (RPC) versus a analgesia peridural. A análise incluiu o estudo COMET realizado no Reino Unido. Foram avaliados 25 desfechos, dos quais, apenas três diferiram significativamente entre os grupos. O tempo de início de analgesia efetiva, após a primeira injeção, revelou ser significativamente mais curto no grupo de RPC (quatro estudos) (DMP −5.50 minutos [IC 95% −6.47 a −4.52 minutes]). O número de mulheres satisfeitas com sua analgesia revelou-se significativamente mais alto no grupo de RPC (três estudos) (OR 4,69 [IC 95% 1,27 a 17,29]). A única outra diferença significativa encontrada entre os dois grupos foi uma incidência maior de prurido nas mulheres com RPC (nove estudos) (OR 2,79[IC 95% 1.87 a 4.18]). Nenhuma diferença significativa foi encontrada entre as mulheres dos dois grupos em relação a: cefaléia pós-punção dural (CPPD): nove ERCs (OR 1,46 [IC 95% 0,37 a 5,71]); punção dural acidental: seis ERCs (OR 1,77 [IC 95% 0,53 a 5,94]) ou o número de mulheres que precisaram de tamponamento sanguíneo para CPPD: seis ensaios (OR 1,47 [IC 95% 0,24 a 8,98]). Além disso, nenhuma diferença significativa foi encontrada no que diz respeito à incidência de outros efeitos colaterais, necessidade de estimulação ocitócica, tipo de parto ou desfechos neonatais.  
Um ERC conduzido na Arábia Saudita também comparou RPC com peridural.<sup>141</sup> [NE = 1+] As mulheres alocadas no grupo de RPC (n = 50) receberam bupivacaína intratecal 0,25% 0,5 ml (1,25 mg) com fentanila 25 microgramas em 0,5 ml. O componente peridural consistiu em 10 ml de bupivacaína 0,0625% com fentanila 1,5 microgramas/ml, seguido por uma infusão de 6-10 ml/hora de acordo com a estatura da mulher. O grupo de comparação (n = 51) recebeu uma dose peridural baixa consistindo de um bolus inicial (10-20 ml) de 0,0625% de bupivacaína com fentanila 1,5 microgramas/ml (volume determinado pela estatura da mulher). Para analgesia adicional, o mesmo esquema que foi utilizado para a RPC foi empregado. Ambos os grupos foram compostos de mulheres nulíparas saudáveis, de 36 ou mais semanas de gestação, na primeira etapa do parto, que requereram peridural antes de  4 cm de dilatação cervical. Todas as mulheres receberam o método de analgesia alocado. Os resultados mostraram um início significativamente mais rápido da analgesia para as mulheres que receberam RPC. Depois de 5 minutos, todas as mulheres que receberam RPC relataram analgesia adequada em comparação com 41,2% de mulheres no grupo peridural (P <0,05). Esta diferença permaneceu significativa aos 10 e 15 minutos, tempo em que a proporção de mulheres relatando analgesia adequada no grupo peridural tinha subido para 60,8%. Aos 30 minutos todas as mulheres em cada grupo relataram analgesia adequada. Nenhuma diferença significativa foi encontrada em relação a deambulação, tipo de parto, duração da primeira fase, duração da segunda fase ou satisfação das mulheres com o alívio da dor, que foi alta para ambos os grupos. Significativamente mais mulheres no grupo de RPC relataram prurido (38% versus 14%, P <0,05). Nenhuma outra diferença foi notada no que diz respeito a efeitos colaterais ou complicações. Os resultados neonatais foram semelhantes para os dois grupos, embora os números não tenham sido divulgados.  
Um relatório resumido sobre as principais conclusões de um ERC realizado no Reino Unido e um estudo prospectivo de coorte combinado para resultados a longo prazo, o estudo COMET.<sup>142</sup> [NE =2+] Os resultados de curto prazo deste estudo estão incluídos na meta-análise da RS já descrita.<sup>140</sup> O resultado primário de longo prazo foi dor nas costas, com duração de mais de 6 semanas, nos primeiros 3 meses após o parto. Nenhuma diferença significativa foi encontrada na incidência de dor nas costas de longa duração entre as mulheres nos três grupos diferentes de peridural, ou seja, RPC, peridural tradicional (injeção em bolus) e peridural com infusão de dose baixa. O grupo não-peridural (coorte prospectivo  
combinado, n = 351) relatou significativamente menos dor nas costas do que o grupo peridural tradicional (OR 1,46 [IC 95% 1,02 a 2,09]). A satisfação das mulheres, a longo prazo, com a experiência geral de dar a luz não diferiu entre os grupos de peridural (conclusões do grupo de não-peridural não relatadas). Uma proporção muito maior de mulheres que receberam uma RPC escolheriam o mesmo método novamente, em comparação com a proporção de mulheres no grupo peridural tradicional que escolheria a peridural tradicional novamente (números não fornecidos).  
10.6.5.1.3 Anestésicos, coadjuvantes e doses para se iniciar a analgesia raqui-peridural combinada (RPC)  
As diretrizes do NICE incluíram os seguintes estudos na sua revisão:  
Uma RS que incluiu 24 ERCs e 3.513 mulheres.<sup>143</sup> [NE = 1+] onde foram testados três opióides intratecais (sufentanila, fentanila e morfina), com ou sem várias doses diversas de bupivacaína intratecal ou peridural. Um ERC realizado nos EUA em 2003 que incluiu 108 mulheres.<sup>144</sup> [NE = 1+] e comparou seis doses diferentes (0, 5, 10, 15, 20, 25 microgramas) de fentanila intratecal, combinado com 2,5 mg de bupivacaína. O outro ERC foi realizado em Cingapura em 2004, e incluiu 40 mulheres.<sup>145</sup> [NE = 1+] e combinou 25 microgramas de fentanila intratecal com placebo, em combinação com 2,5 mg de levobupivacaína, seguida por uma infusão peridural de 10 ml/hora de  0,125%  de levobupivacaína e 2 microgramas/ml de fentanila.  
Tanto os estudos da RS como os outros estudos isolados foram analisados em uma meta-análise que demonstrou que as mulheres com opiáceo intratecal tiveram maior incidência de bradicardia fetal dentro de 1 hora de analgesia do que o grupo controle, embora não tenha havido nenhuma evidência de uma diferença na incidência de outras anormalidades cardíacas fetais. Houve uma forte evidência de que as mulheres com opiáceo intratecal experimentaram mais prurido do que o grupo controle que não recebeu opióide intratecal. Um dos ERCs mostrou que todas as mulheres que receberam 15 microgramas de fentanila ou mais, tinham um nível de EVA inferior a 20 mm (em uma EVA de 0 a 100 mm), enquanto aquelas que receberam menos de 15 microgramas não.<sup>144</sup> Não houve evidência de diferença na incidência de náusea e vômitos, ou anormalidades cardíacas fetais, embora tenha havido maior incidência de prurido nas mulheres às quais foi aplicada fentanila intratecal. O outro estudo mostrou um efeito significativamente mais longo de analgesia para aquelas com 25 microgramas de fentanila do que 2,5 mg de levobupivacaina apenas.<sup>145</sup> O estudo foi insuficiente para avaliação de eventos adversos.  
Na RS não foram encontradas diferenças no tipo de parto ou uso de ocitocina.<sup>143</sup> Nenhum outro resultado foi relatado em qualquer dos estudo . Não houve nenhuma evidência de diferença na incidência de baixo escore de Apgar aos 5 minutos. Nenhum outro resultado fetal foi relatado. A satisfação não foi relatada nesses estudos.  
Uma RS<sup>146</sup> [NE = 1+] avaliou três opióides intratecais (morfina, sufentanila e fentanila) comparados com bupivacaína ou lidocaína por via peridural. A meta-análise demonstrou eficácia analgésica comparável 15-20 minutos após a administração intratecal de opióides, embora estes estivessem associados ao aumento da incidência de prurido. Não houve diferenças na incidência de náusea ou tipo de parto.  
Um estudo realizado nos EUA em 1999 que incluiu 90 mulheres<sup>147</sup> [NE = 1+] comparou três doses diferentes (0 mg, 1,25 mg ou 2,5 mg) de bupivacaína combinada com 25 microgramas de fentanila para RPC. Houve evidência de que as mulheres com 2,5 mg de bupivacaína apresentaram analgesia com uma duração mais longa do que aquelas sem bupivacaína, e as mulheres com bupivacaína tiveram um início mais rápido da analgesia do que aquelas sem bupivacaína. Não houve evidência de diferenças em outros

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: resultados. -->
Ensaio conduzido em Cingapura publicado em 2004 que incluiu 40 mulheres<sup>148</sup> [NE = 1+]  comparou levobupivacaína/fentanila intratecal 2,5 mg/25 microgramas e 1,25 mg/12,5 microgramas demonstrou que as mulheres com menor dose tiveram menos bloqueio motor do que as dos outros grupos, embora não tenha havido nenhuma diferença no início/duração da analgesia ou eventos adversos, tais como hipotensão, tremores, prurido, náusea e vômitos.  
Um ERC realizado em Hong Kong publicado em 1999 que incluiu 49 mulheres.<sup>149</sup> [NE =1+]  comparou Bupivacaína 1,25 mg e 2,5 mg  combinada com 25 microgramas de fentanila para o início da RPC. Houve evidência de que as mulheres com uma dose maior de bupivacaína tiveram uma analgesia de duração mais longa, mas um nível maior de bloqueio de sensibilidade e mais incidência de bloqueio motor. Não houve diferenças em outros resultados.  
Outro estudo realizado nos EUA publicado em 1998 que incluiu 84 mulheres.<sup>150</sup> [NE = 1+] comparou sete doses diferentes (5 a 45 microgramas) de fentanila intratecal para início da RPC. Uma curva de doseresposta indicou que a dose eficaz mediana de fentanila foi de 14 microgramas [13-15 microgramas]. Um estudo realizado no Reino Unido publicado em 2001 que incluiu 124 mulheres<sup>151</sup> [NE = 1+] comparou três doses diferentes (0, 5, 15 ou 25 microgramas) de fentanila intratecal para RPC. Houve evidência dose-dependente de aumento de prurido quanto e duração da analgesia espinhal com doses crescentes de fentanila. Não houve evidência de diferenças entre diferentes doses de fentanila em outros resultados.  
Outro estudo realizado nos EUA publicado em 1999 que incluiu 60 mulheres<sup>152</sup> [NE =1+]  comparou 25 microgramas, 37,5 microgramas ou 50 microgramas de fentanila intratecal para o início do analgesia RPC durante o trabalho de parto. Não houve evidência de diferenças na duração da analgesia ou eventos adversos.  
10.6.5.2 Resumo das evidências e conclusões em relação ao início da analgesia regional Considerando a utilização de concentrações diluídas de anestésico local, as evidências são limitadas para padronizar uma dose (concentração x volume) ideal para se iniciar a analgesia peridural. <mark>Há evidência de que o estabelecimento de analgesia peridural a partir da administração de volumes maiores de soluções mais diluídas de anestesia local alcance analgesia mais rápida e efetiva do que com volumes menores de soluções mais concentradas. Há também evidência limitada de que o estabelecimento de analgesia com doses maiores de anestesia local cause maior bloqueio motor do que com doses menores.</mark>  
Em relação à técnica para início da analgesia regional, quando se compara a raqui – peridural combinada (RPC) com a peridural, evidências de alta qualidade apontam que a RPC fornece analgesia mais rápida e está associada a maior satisfação materna, diminuição da taxa de parto instrumental e maior incidência de prurido quando se utiliza opióides. Uma vez que a analgesia é estabelecida, as duas técnicas são igualmente eficazes. Não existem diferenças quanto aos demais desfechos.  
Em relação aos anestésicos, coadjuvantes e doses para se inicair a RPC, um opióide intratecal pareceu ter eficácia analgésica comparável aos 15 minutos de administração, embora com aumento da incidência de prurido, em comparação com  anestésicos locais por via peridural. A RPC com utilização isolada de opióides lipossolúveis intratecal é suficiente para alívio da dor do parto em fases não avançadas e o acréscimo de anestésico local apenas diminui a latência. Houve evidência limitada de que iniciar a RPC com uma dose maior de anestésicos locais ou opióides surtiu efeitos mais longos na analgesia, maior incidência de bloqueio motor e mais bloqueio sensorial, do que uma dose menor. A dose média efetiva de fentanila intratecal para alívio da dor de parto inicial está próxima a 15 mcg.  
Os principais efeitos adversos da utilização de opioíde intratecal são o prurido e a bradicardia fetal transitória. Apesar da potencial queda da FCF, esta não esteve associada a desfecho fetal negativo. A utilização de anestésico local na RPC é indicada em fases mais avançadas do trabalho de parto. Doses mínimas de levobupivacaína ou bupivacaína intratecal (1,25 mg ) são tão eficazes quanto doses maiores para alívio da dor, apesar da menor duração. Levobupivacaína ou bupivacaína em altas doses (2,5 mg) intratecal podem ocasionar anestesia, ao invés de analgesia do parto, particularmente maior incidência de bloqueio motor.  
10.6.5.3 Outras considerações em relação ao início da analgesia regional  
As evidências, apesar de limitadas, sugerem que a variável dose peridural inicial não influencia significativamente o desfecho, uma vez diluída. Considerando que as gestantes receberão infusões adicionais, estudos que avaliem a dose total, o tempo e o modo parecem ser mais relevantes. Quando se considera doses iguais, o fator volume é mais relevante do que a concentração administrada para eficácia da analgesia. Por exemplo, a capacidade de deambular parece estar mais relacionada a concentração de anestésico local utilizada do que à técnica propriamente dita.  
Ambas as técnicas, peridural isolada ou RPC, foram eficazes no alívio da dor. O fato das mulheres estarem mais satisfeitas no grupo da analgesia combinada, não implica em insatisfação no grupo peridural. Infere-se que esta satisfação possa estar relacioanada ao alívio mais rápido em fases mais avançadas do parto e que o prurido não constitui problema relevante.  
10.6.5.4 Recomendações em relação ao início da analgesia regional  
48. A analgesia peridural e a analgesia combinada raqui – peridural (RPC) constituem técnicas igualmente eficazes para alívio da dor de parto. A escolha entre elas será influenciada pela experiência do anestesiologista com a técnica.  
49. Iniciar a analgesia peridural com as substâncias usuais (bupivacaína, ropivacaína ou levobupivacaína) diluídas na dose:  volume 13 a 20 ml em concentração de 0,0625% a 0,1%, acrescidos de fentanila (2 mcg/ml), ou opióide lipossolúvel em dose equipotente.  
50. Quando se pretende fornecer alívio rápido da dor, sem elevação da dose de anestésico, a via intratecal é a técnica de escolha.  
51. Quando se utilizar a RPC, adequar a dose ao momento do parto:  
- Fase não avançada do parto (doses próximas a 15 mcg de fentanila intratecal ou outro opióide lipossolúvel em dose equivalente).  
- Fase avançada do parto (bupivacaína 1,25 mg intratecal ou outro anestésico em dose equivalente, associada ao opióide lipossolúvel).  
10.6.6 Manutenção da analgesia regional  
10.6.6.1 Evidências científicas  
10.6.6.1.1 Dosagem/taxas diferentes de infusão para a manutenção da analgesia peridual  
As diretrizes do NICE incluíram 11 estudos que compararam diferentes doses ou taxas de infusão contínua/injecão para analgesia peridural ou RPC<sup>153-163</sup> . Devido à heterogeneidade nos desenhos dos estudos, os resultados são resumidos a seguir .  
Bupivacaína 0,125% versus 0,0625 versus % 0,04 %  
ERC realizado nos EUA e publicado em 2002, incluiu 89 mulheres<sup>154</sup> [NE =1+]. O estudo comparou uma infusão peridural a 10 mL/h de solução salina (n = 23), bupivacaína a 0,125 % (n = 22), 0,0625 % (n = 22) e bupivacaína 0,04 % mais epinefrina 1:600.000 (n = 22). Todos, exceto o grupo de salina, receberam fentail 2 mcg/mL. A infusão teve início 15 minutos após 25 microgramas de fentanila + 1 ml de  
bupivacaína 0,25% subaracnóide seguida 5 minutos após por uma dose peridural teste de 3 ml de bupivacaína a 0,25%. O estudo não teve poder suficiente, de forma que não apresentou  resultados significativos que comparassem os três grupos de bupivacaína, em qualquer dos desfechos, incluindo a duração da analgesia e reações adversas.  
Bupivacaína 0,08 % versus 0,25 %  
ERC ealizado no Reino Unido e publicado em 1986 que incluiu 53 mulheres<sup>158</sup> [NE= 1+]. comparou uma infusão de bupivacaína entre 0,08 % (n = 25) e 0,25 % (n = 28) com a mesma quantidade de dose do analgésico por hora (20 mg/hora de bupivacaína ) para  analgesia peridural  no trabalho de parto, seguida de uma dose teste de 3 ml de bupivacaína administrada a 0,5%. Há evidências de que o grupo de 0,08% teve intervalos maiores sem intervenção ou menos reforços do que o outro grupo. Bupivacaína 0,0625 % versus 0,125%  
ERC realizado no Reino Unido e publicado em 1985 que incluiu 98 mulheres<sup>159</sup> [NE =1+]. comparou cinco doses e concentrações diferentes da infusão de bupivacaína para analgesia peridural: (i) não bupivacaína; ( ii ) 0,0625 % , 6,25 mg / hora; ( iii ) 0,125 %, 6,25 mg/hora ; (iv) 0,125%, 12,5 mg/hora; e (v ) 0,125%, 18,75 mg/hora . Embora não houvesse resultados com diferenças estatisticamente significativas entre os grupos ii–v, a bupivacaína 0,125 %, 12,5 mg/ hora (10 ml/hora) pareceu ter a menor dose utilizada com menos bloqueio motor.  
Bupivacaína 0,031 % versus 0,062 % versus 0,125 %  
ERC conduzido no Reino Unido e publicado em 1991 que incluiu 56 mulheres<sup>160</sup> [NE=1+] comparou bupivacaína em infusão de 0,125%, 0,062 % ou 0,032 % combinada com fentanila 0,0002 % com a mesma taxa de infusão (7,5 ml/hora ), após uma dose inicial de 8 ml de bupivacaína a 0,5 %. Houve evidências de que as mulheres que receberam bupivacaína 0,032 % usaram menos analgésico do que os outros grupos. No entanto, não houve evidência de diferença na escala da dor. O estudo não teve poder para demonstrar diferenças em outros resultados, incluindo o tipo de parto e resultados neonatais. Bupivacaína 0,0625 % versus 0,125%  
ERC realizado no Reino Unido e publicado em 1994 que incluiu 98 mulheres<sup>161</sup> [NE =1+] comparou bupivacaína 0,0625 % e 0,125 % (ambos a 10 ml/hora) para analgesia peridural no trabalho de parto. Há evidências de que as mulheres que receberam  bupivacaína a 0,0625 % ficaram mais propensas a precisarem de fórceps de Kielland rotativos, mas menos propensas a precisarem de fórceps de Neville – Barnes do que o outro grupo.  
Bupivacaína 0,5 % 6-8 ml contra 0,25 % 10-14 ml contra 0,25 % 6-8 ml  
ERC realizado no Reino Unido e publicado em 1981 que incluiu 517 mulheres<sup>162</sup> [NE =1+] comparou três doses diferentes (0,5% 6-8 ml, 0,25% 10-14 ml ou 0,25% 6-8ml ) de bupivacaína, para injecção inicial e reforço para analgesia peridural. Houve evidência de que as mulheres com a  dose de 0,25% 6-8 ml tiveram mais partos vaginais espontâneos, mas o alívio da dor foi classificado como menor do que nos outros grupos . As mulheres com maiores concentrações ou volume de injeção de bupivacaína foram mais propensas a ter bloqueio motor e retenção urinária, apesar de não haver evidências de diferenças em outros resultados.  
Bupivacaína versus ropivacaína (0,25 % versus 0,125 %)  
ERC conduzido na Suécia e publicado em 2001 que incluiu 68 mulheres<sup>153</sup> [NE = 1+] comparou duas doses diferentes e dois medicamentos diferentes (bupivacaína a 0,25%, ropivacaína 0,25%, bupivacaína a 0,125%, ropivacaína 0,125%) para analgesia peridural durante o parto.  Há evidências de que mulheres com 0,25%  tanto de uma substância quanto da outra ficaram mais propensas a ter bloqueio motor do  
que os outros grupos e, entre os grupos de 0,25 %, as mulheres com bupivacaína ficaram mais propensas a ter bloqueio motor do que aquelas com ropivacaína. Não houve evidência de diferenças no tipo de parto, escore de Apgar e incidência de hipotensão.  
Ropivacaína 4, 6, 8 e 10 ml/hora  
ERC realizado na França e publicado em 1997 que incluiu 133 mulheres<sup>155</sup> [NE = 1+ ] comparou quatro taxas de infusão diferentes de ropivacaína 2 mg / ml ( 4, 6, 8 e 10 ml/ hora) para analgesia peridural durante o parto. Houve evidência de que o grupo que recebeu  4 ml/horarequisitou mais doses em bolus do que os outros grupos, e que o grupo de  10 ml/ hora tinha dose total mais elevada de ropivacaína que os outros grupos. Não houve evidência de diferenças na pontuação da dor, bloqueio sensitivo, bloqueio motor, tipo de parto ou pontuação de Apgar do recém-nascido.  
Outro ERC conduzido nos EUA e publicado em 1998 que incluiu 127 mulheres<sup>157</sup> [NE = 1+] comparou  as mesmas taxas de infusão do estudo anterior de ropivacaína 2 mg/ml ( 4, 6, 8 e 10 ml / hora). Houve evidências de que o grupo de mulheres que receberam a droaga a 4 ml/ hora necessitaram de mais injeções de reforço adicionais do que os outros grupos, embora tivesse menos bloqueio motor. Não houve evidência de diferenças em pontuação Apgar ou ECNA (Escore de Capacidade Neurológica e Adptativa) para os recém-nascidos .  
Ropivacaína 0,2 % versus 0,125 %  
ERC conduzido em Cingapura e publicado em 1999 que incluiu 50 mulheres<sup>163</sup> [NE = 1+ ] comparou ropivacaína 0,2% e 0,125% para PCA. Houve evidência de que as mulheres no grupo de 0,125% tiveram menos bloqueio motor, apesar de não haver evidência de diferenças em outros resultados. Ropivacaína 2, 16 e 20 ml a 0,1% mais 0,5 microgramas de fentanila versus 6 e 8 ml a 0,2% mais 0,5 microgramas de fentanila.  
ERC realizado na França e publicado em 2003 que incluiu 150 mulheres (25 para cada braço)<sup>156</sup> [NE = 1+ ] comparou seis doses diferentes  de ropivacaína mais fentanila (ropivacaína 0,1%  mais 0,5 microgramas de fentanila (i) 12 ml, (ii) 16 ml e (iii) 20 ml, ropivacaína 0,2 % mais 0,5 microgramas de fentanila (iv) 6 ml, (v) 8 ml e (vi) e 10 ml) para PCA (“analgesia peridural controlada pela paciente”) durante o parto. Os resultados mostraram que a eficácia de analgesia depende mais  da quantidade de medicamento em massa, do que do volume ou concentração.  
10.6.6.1.2 Anestésico local com opiáceo versus anestésico local sem opiáceo  
As diretrizes do NICE incluíram vários estudos que avaliaram a utilização de anestésico local sem opiáceos comparado com anestésico local com opiáceos para a manutenção da analgesia regional. Os mesmos são sumarizados a seguir.  
Dois ERCs compararam Bupivacaína 0,125% versus bupivacaína 0,125% mais fentanila 2–3 microgramas<sup>164,165</sup> . O primeiro estudo foi realizado no Reino Unido em 1991 e incluiu 42 mulheres. O segundo foi realizado no Canadá em 1991 e incluiu 60 mulheres. Foi realizada uma meta-análise dos dois estudos, incluindo um total de 93 mulheres. [NE = 1++] Não houve evidência de diferenças no início da analgesia, dose total de bupivacaína ou incidência de reações adversas, incluindo hipotensão, pruridos, retenção urinária, vômitos/náusea e bloqueio motor assim como no tipo de parto e duração do segundo estágio. Outros desfechos maternos não foram relatados. Também não foram encontradas diferenças no escores de Apgar dos recém-nascidos. Outros desfechos neonatais não foram relatados. Somente o segundo estudo avaliou a satisfação das mulheres com a anestesia. Houve evidência, no limite da siginificância,  que as mulheres que receberam fentanila ficaram mais satisfeitas com o alívio da dor na primeira fase do trabalho de parto, apesar de não ter havido diferenças no segundo estágio.  
Quatro ERCs, relatados em cinco publicações<sup>166-170</sup> compararam Bupivacaína 0,125% versus bupivacaína 0,0625% mais 2–3 microgramas de fentanila. Foram conduzidas meta-análises dos quatro estudos a fim de resumir os resultados, totalizando 667 mulheres. Três estudos<sup>166-169</sup> foram realizados no Reino Unido entre 1995 e 1998 e outro foi realizado nos Estados Unidos em 1988<sup>170</sup> [NE = 1++]. Os resultados mostraram evidência significativa de que as mulheres com fentanila tiveram uma dose total de bupivacaína menor e menos bloqueio motor, com uma maior duração da analgesia e mais prurido que o outro grupo. Não houve evidência de diferenças na incidência de hipotensão, retenção urinária e náusea/vômitos. Não houve diferenças no tipo de parto e duração do segundo estágio. Não houve diferenças nos escores de Apgar, pH da artéria umblical e no Escore de Capacidade Neurológica e Adaptativa  (ECNA) dos recém nascidos. Não foram evidenciadas diferenças na satisfação das mulheres em relação ao alívio da dor.  
Um ERC conduzido no Reino Unido publicado em 2001, o estudo COMET (Comparative Obstetric Mobile Peridural Trial ) incluindo 703 mulheres comparou duas estratégias de analgesia no parto. A “Clássica“ (10 ml iniciais de bupivacaína 0,25% seguida de bolus posteriores a 0,25%; n = 353) versus outra mais moderna, intitulada “walking peridural” (Peridural Móvel; n = 350). A Peridural Móvel compreendia duas diferentes técnicas: (i)15 ml de bupivacaína 0,1% com fentanila 2 mcg/ml ou (ii)RPC com 2,5mg de bupivacaína e fentanila 25 mcg intratecais. A analgesia no grupo moderno foi mantida com infusão contínua de bupivacaína à 0,1% com fentanila a 2 mcg/ml<sup>171,172</sup> [NE = 1+]. Não foram encontradas diferenças nas pontuações medianas na EVA, na intensidade da dor após administração da injeção peridural (clássica n=14; moderno n=12) ou nas habilidades de puxo das mulheres durante o parto (RR 1,04, p = 0.77). Também não houve diferenças no montante de bupivacaína usada durante o parto, excluindo-se complementos para procedimentos cirúrgicos (clássico = 103,8 (DP 56,1) mg; contínuo = 101,1 (DP 55,1) mg). No esquema moderno, ocorreram mais partos normais espontâneos (RR 1,39 [IC 95% 1,02 a 1,88]) e uma duração menor do segundo estágio (≤ 60 minutos RR 1,36 [IC 95% 1,01 a 1,84]) do que no esquema clássico. Não houve diferença na incidência de cesariana (RR 1,07 [IC 95% 0,77 a 1,49]).  
Evidenciou-se uma maior propensão a baixos escores de Apgar em 1 minuto no esquema moderno (≤ 7 RR 1,64, P = 0,01) e de um nível mais alto de ressuscitação (uma ou mais máscara e bolsa ou intubação (intubação ou naloxona) RR 5,00, P = 0,02), apesar de não haver diferenças no escore de Apgar em 5 minutos (RR 3,00, P = 0,09) e admissão na unidade neonatal (RR 0,80, P = 0,72).  
O nível de satisfação das mulheres a longo prazo com a experiência do parto, no geral, não foi diferente entre os dois grupos.  
Não foram encontradas diferenças em relação a  cefaléia, dores na coluna ou na região cervical a longo prazo ou parestesia entre os dois grupos, apesar de que as mulheres no grupo contínuo apresentaram menos controle de incontinência urinária de esforço ou intestinal, comparadas com o grupo tradicional. 10.6.6.1.3 Diferentes tipos de anestésico local para analgesia peridural Bupivacaína versus Levobupivacaína  
As diretrizes do NICE incluíram 6 ERCs para esta comparação<sup>173,178</sup> . Entre os estudos incluídos, três foram iniciados com RPC<sup>174,176,178</sup> e o restante com analgesia peridural. Meta-análises foram conduzidas a fim de resumir os resultados [NE =1+]. Independente do método de analgesia, demonstrou-se que a levobupivacaína se associou a uma menor duração da analgesia, mas sem diferenças na incidência de hipotensão arterial, náusea/vômitos, bloqueio motor e traçados anormais na monitoração eletrônica fetal. Também não foram demonstradas diferenças no tipo de parto, duração do período expulsivo,  
escore de Apgar ou ECNA. Na análise de subgrupo incluindo apenas as mulheres que utilizaram a analgesia peridural, não foram demonstradas diferenças no tipo de parto (parto vaginal espontâneo, um ERC: RR 1,39 [IC 95% 0,58 a 3.37]; cesariana, um ERC: RR 1,33 [IC 95% 0,59 a 2,97]), duração e início da analgesia (início da analgesia, um ERC: DMP -1.00 minutos [IC 95 % -4,93 a 2,93 minutos]; duração da analgesia, um ERC: DMP -1.77 minutos [IC 95% −4.00 a 0,47 minutes]); efeitos adversos (hipotensão, cinco ERCs: RR 1,61[ IC 95% 0,79 a 3,27]; náusea/vômitos, cinco ERCs: RR 0,58 [IC 95% 0,31 a 1,08]; pontuação Bromage = 0, cinco ERCs: RR 0,99 [IC 95% 0,89 a 1,10]; traçado anormal ou preocupante da FCF, três ERCs: RR 0,86 [IC 95% 0,30 a 2,42]) ou resultado neonatal (pH de cordão umbilical, ERC: DMP 0,01 [IC 95% −0,03 a 0,05]). A satisfação das mulheres não foi relatada Bupivacaína versus ropivacaína  
As diretrizes do NICE incluíram 29 ERCs para esta comparação<sup>174,176,179-203</sup> . Quatro foram iniciados com RPC<sup>174,176,189,201</sup> , cinco com PCA<sup>181,184,188,197,200</sup> e o restante com analgesia peridural tradicional<sup>179,180,182,183,185-187,190-196,198,199,202,203</sup> . Meta-análises foram conduzidas para resumir os resultados[NE =1+ ]. Independente do modo de administração da analgesia demonstrou-se que a ropivacaína se associou a uma duração mais curta da analgesia e menos bloqueio motor, embora sem diferenças no início da analgesia, hipotensão arterial, náusea/vômitos ou traçado anormal da FCF. Demonstrou-se também uma duração mais curta do período expulsivo do parto no grupo com bupivacaína, embora sem diferenças no tipo de parto. Houve evidência de que mais recém-nascidos no grupo de ropivacaína tiveram escore de ECNA maior 2 horas após o nascimento do que aqueles com bupivacaína, mas sem diferenças nos escores de Apgar em 1 e 5 minutos, pH do cordão umbilical ou ECNA às 24 horas. Não houve diferença na satisfação das mulheres em relação ao alívio da dor. Na análise de subgrupo incluindo apenas estudos de analgesia peridural, não foram encontradas diferenças no início da analgesia (quatro ERCs DMP −0.32 minutos [IC 95% −1.09 a 0,44 minutos]) ou na duração da analgesia (sete ERCs DMP 3,20 minutos [IC 95% −3.03 a 9,43 minutos]). Também não foram encontradas diferenças no tipo de parto (vaginal espontâneo, 22 ERCs: RR 1,03 [IC 95% 0,96 a 1,10]; cesariana, 21 ERCs: RR 0,95 [IC 95% 0,80 a 1,12]). No grupo de ropivacaína ficou demonstrada maior duração do período expulsivo (nove ERCs DMP 3,22 minutos [IC 95% 1,08 a 5,36 minutos]). Menos mulheres experimentaram bloqueio motor no grupo de ropivacaína (18 ERCs RR 1,21 [IC 95% 1,04 a 1,39]), sem diferenças em outros resultados adversos incluindo hipotensão (12 ERCs RR 0,98 [IC 95% 0,69 a 1,40]) e náusea ou vômitos (oito ERCs RR 1,04 [I C 95% 0,50 a 2,15]). Mais recém-nascidos apresentaram escore de ECNA > 35 às 2 horas no grupo de ropivacaína (três ERCs RR 1,25 [IC 95% CI 1,06 a 1,46]), embora sem diferenças em outros desfechos fetais ou neonatais, incluindo pontuação de ECNA às 24 horas (> 35 quatro ERCs RR 1,02 [IC 95% 0,96 a 1,07]), traçado anormal ou preocupante da FCF (três ERCs RR 1,29 [IC 95% 0,59 a 2,82]), Apgar (< 7 em 1 minuto, dez ERCs: RR 0,85 [IC 95% 0,63 a 1,14]; < 7 aos 5 minutos, 13 ERCs RR 1,39 [IC 95% 0,69-2,82]) e pH da artéria umbilical (cinco ERCs: DMP 0,01 [IC 95% CI -0,02 a 0,03]). Também não houve diferenças no escore de satisfação das mulheres (6 ERCs RR 1,03 [IC 95% CI 0,99 a 1,06]).  
10.6.6.1.4 Modo de administração da analgesia regional  
Infusão contínua versus administração em bolus intermitente para analgesia peridural  
As diretrizes do NICE incluíram 8 ERCs na sua revisão<sup>204-211</sup> . Em todos os estudos foram comparados administração em bolus intermitente repetido e infusão contínua para analgesia peridural durante o parto, exceto por um estudo que foi iniciado com analgesia combinada raqui-peridural (RPC) e, então, mantido com analgesia peridural<sup>204</sup> . Quatro estudos usaram apenas bupivacaína<sup>206-208</sup> , três usaram  
bupivacaína e fentanila<sup>205,210,211</sup> e o restante ropivacaína e fentanila<sup>204</sup> . Todos os estudos mostraram uma homogeneidade razoável e, portanto, meta-análises foram conduzidas para se resumir os resultados [NE=1++].  
Houve evidência de que mais analgesia local foi requerida no grupo contínuo do que no grupo intermitente (dose total; dois ERCs DMP −5.78 [−7.61 a −3.96]), sem diferenças no tipo de parto (parto vaginal espontâneo: oito ERCs RR 1,23 [IC 95% 0,92 a 1,65], cesariana: oito ERCs OR 0,95 [IC 95% 0,63 a 1,43]); eventos adversos (incluindo hipotensão: cinco ERCs OR 1,46 [IC 95% 0,80 a 2,66], prurido: um ERC  RR 0,73 [IC 95% 0,24 a 2,21], bloqueio motor (pontuação na escala de Bromage = 0): três ERCs OR 1.57 [IC 95% 0,61 a 4,00], traçado anormal ou preocupante da FCF: dois ERCs OR 1,39 [IC 95% 0,83 a 2,33]); ou pontuação de Apgar (< 7 em 1 minuto: dois ERCs OR 7,79 [IC 95% 0,38 a 157,97], < 7 em 5 minutos: dois ERCs OR 5,36 [IC 95% 0,25 a 116,76]). Dois ensaios avaliaram a satisfação das mulheres. Um deles demonstrou que as mulheres com infusão contínua ficaram mais satisfeitas com o alívio da dor do que aquelas com administração intermitente.<sup>192</sup> O outro não demonstrou evidência de diferença entre os dois braços.<sup>191</sup>  
Analgesia peridural controlada pela paciente (PCA) versus infusão contínua As diretrizes do NICE incluíram 2 estudos:  
Uma revisão sistemática (RS)<sup>212</sup> [NE = 1+] que por sua vez incluiu nove estudos e 640 mulheres que comparou a analgesia peridural controlada pela paciente (PCA) sem histórico de infusão contínua no trabalho de parto com a infusão contínua, demonstrou haver menos  intervenções anestésicas no grupo PCA do que no grupo de infusão. O grupo PCA pareceu ter menos anestesia local e menos bloqueio motor. Não houve diferenças em outros eventos adversos, incluindo hipotensão, bloqueio sensorial alto, tremores, náusea e prurido. Todos os estudos usaram ropivacaína ou bupivacaína como analgésicos Um ERC isolado<sup>213</sup> [NE = 1+] que também usou ropivacaína ou bupivacaína como analgésicos demonstrou uma tendência similar. A necessidade de anestesia local de hora em hora foi menor no grupo de PCA do que no grupo de infusão, apesar de não ter havido diferença na incidência de eventos adversos, incluindo náusea, hipotensão e prurido.  
Tanto na RS como no ERC isolado não foram demonstradas diferenças no tipo ou duração do parto, incidência de baixos escores de Apgar no 1<sup>o</sup> e 5<sup>o</sup> minutos e no grau de satisfação das mulheres com o alívio da dor entre os dois grupos.  
PCA versus administração em bolus intermitente pela equipe do hospital  
As diretrizes do NICE incluíram 4 estudos comparando PCA e administração em bolus intermitente dado pela equipe do hospital para analgesia durante o parto:  
O primeiro estudo, conduzido em 1990, incluiu 58 mulheres, e usou 12 ml de bupivacaína a 0,125%  com epinefrina a 1:400.000, a critério dos anestesistas, comparado com 4 ml de incremento da mesma solução a um máximo de 12 ml/hora por PCA<sup>214</sup> [NE = 1+]. Não foram demonstradas diferenças na necessidade de anestesia local de hora em hora ou nos níveis sensoriais.  
O segundo estudo que utilizou bupivacaína-fentanila foi conduzido em 1991 e incluiu 50 mulheres. Comparou-se a PCA com administração em bolus por enfermeiras obstétricas. A PCA foi iniciada com uma solução de bupivacaína a 0,125% mais 2 microgramas/ml de fentanila e a analgesia foi mantida ou a 4ml/h de infusão constante mais 4 ml administrados em bolus mediante pedido (intervalo de bloqueio: 15 minutos) ou 8 ml/h de infusão mais 3 ml administrados em bolus<sup>215</sup> [NE = 1+]. As mulheres no grupo que recebeu a analgeisa administrada por enfermeiras obstétricas mostrou um nível mais baixo de dor 2 horas após o início da anestesia, apesar de não ter havido diferenças na incidência de  
eventos adversos tais como náusea, prurido, tremores, hipotensão ou bloqueio motor. O terceiro estudo foi conduzido em 1995, usando bupivacaína-fentanila (0,125% de bupivacaína mais 3 microgramas/ml de fentanila) incluiu 167 mulheres e comparou a PCA com administração em bolus pela equipe<sup>216</sup> [NE = 1+]. Houve evidência limítrofe de que as mulheres no grupo administrado pela equipe mostraram níveis mais baixos de dor 2 a 3 horas após o início da analgesia, apesar não ter havido diferenças na escala mediana de dor, hipotensão, tremores, prurido ou vômitos. Entretanto, a retenção urinária foi mais comum nas mulheres no grupo PCA.  
O último estudo usando bupivacaína-fentanila, foi conduzido em 2005, incluindo 187 mulheres e comparou PCA com administração pela equipe. PCA (0,08%  de bupivacaína e 2 microgramas/ml de infusão de fentanila 5 ml/hora com administração única de 5 ml em bolus e 15 minutos de intervalo de bloqueio) foi comparado com bolus de 20 mg de bupivacaina and 75 microgramas de fentanila em um volume de 15 ml<sup>217</sup> [NE = 1+]. Demonstrou-se que as mulheres no grupo PCA sentiram menos dor durante o primeiro e o segundo estágios do parto, mas usaram mais bupivacaína do que o grupo de controle.  
No primeiro, segundo e último estudos, não foram relatadas diferenças na duração e tipo de parto. No terceiro estudo, houve uma tendência de menos partos vaginais espontâneos (P = 0,08) e uma duração mais longa do segundo estágio (P = 0,02) nas mulheres no grupo PCA. Nenhum estudo demonstrou diferenças nos escores de Apgar. Os dois primeiros estudos demonstraram que as mulheres nos grupos PCA ficaram significativamente mais satisfeitas com o alívio da dor do que nos outros grupos. Nos dois últimos estudos essas diferenças não foram evidenciadas.  
Diferente doses/bloqueios para PCA  
As diretrizes do NICE incluíram quatro ERCs comparando doses diferentes administradas em bolus e bloqueios para PCA:  
O primeiro ensaio foi conduzido em 1993, comparando cinco diferentes doses/bloqueios para PCA (2ml administrados em bolus/bloqueio de 10 minutos, 3 ml/15 minutos, 4 ml/20 minutos, 6 ml/30 minutos e 8 ml/hora em infusão contínua) de bupivacaína–fentanila com epinefrina e incluiu 68 mulheres<sup>218</sup> [NE= 1+]. Não houve evidência de diferença no nível de dor entre os cinco esquemas diferentes, exceto pela quantidade total de anestésicos usados, que foram mais consumidos no grupo de infusão contínua do que nos outros quatro grupos.  
O segundo ensaio foi conduzido em 2000, comparando administração em bolus de 12 ml/25 minutos de bloqueio e administração em bolus de 4 ml/8 minutos de bloqueio de bupivacaina–suLfentanila e incluiu 203 mulheres<sup>219</sup> [EL = 1+]. O grupo de dose maior demonstrou um nível menor de dor, mas uma quantidade total maior de anestésicos consumidos do que no grupo de dose menor. Não houve diferença na gravidade da hipotensão mostrada nesse estudo.  
O terceiro ensaio foi conduzido no Líbano, comparando três esquemas diferentes (administração em bolus de 3 ml /6 minutos de bloqueio, 6 ml/12 minutos e 9 ml/18 minutos) e incluiu 84 mulheres<sup>220</sup> [NE = 1+] e demonstrou menor necessidade de analgesia de resgate nas mulheres do grupo de dose maior em relação aos outros dois grupos, apesar de não ter havido diferença nos níveis de dor, sensibilidade e bloqueio motor ou quantidade total de anestésicos usados entre eles.  
O quarto estudo, conduzido nos Estados Unidos em 2005, comparou 5 minutos de bloqueio com 15 minutos de bloqueio e incluiu 60 mulheres<sup>221</sup> [NE = 1+] não demonstrando diferenças  nos níveis de dor, bloqueio motor, bloqueio sensorial ou mudanças da FCF entre os bloqueios de 5 e 15 minutos. Em todos os estudos não foram demonstradas diferenças na duração do trabalho de parto, tipo de parto  
e escores  de Apgar. Apesar do segundo estudo ter demonstrado que as mulheres do grupo com dose maior expressaram maior satisfação com o alívio da dor do que no grupo com dose menor, não houve evidência de diferença na satisfação das mulheres com o alívio da dor no restante dos estudos. 10.6.6.2 Resumo da evidência e conclusões em relação à manutenção da analgesia regional  
Uma evidência de alto nível demonstrou que o esquema peridural moderno (mantido com uma infusão contínua de bupivacaína 0,1% com fentanila 2 microgramas/ml) não apenas aumentou as taxa de partos normais e diminuiu a duração do segundo estágio do trabalho de parto, mas também aumentou o número de bebês que tinham um baixo escore de Apgar e necessitaram de um nível maior de ressuscitação do que aqueles do esquema tradicional (mantidas com administrações em bolus de 0,25% de bupivacaína).  
As evidências analisadas não demonstraram quaisquer diferenças significativas entre bupivacaína 0,125% e bupivacaína 0,125% associada a 2-3 microgramas de fentanila. Há um  alto número de evidências de que as mulheres que receberam fentanila associado a um analgésico local receberam uma dose total menor de bupivacaína e tiveram menos bloqueio motor, com uma duração maior de analgesia e mais prurido do que o outro grupo. Não houve evidência de outras diferenças encontradas entre os grupos.  
As evidências analisadas demonstram que não existem diferenças significativas nos desfechos analisados entre bupivacaína, levobupivacaína e ropivacaína em baixas doses para analgesia regional no parto.  
Uma dose local reduzida de anestésico parece ser tão eficaz quanto uma dose mais elevada, embora não haja forte evidência que confirme dosagem apropriada durante a analgesia peridural. Concentrações elevadas de anestésicos locais (0,25% ou mais de bupivacaína ou equivalente) para analgesia peridural resultou em menor mobilidade para as mulheres (maior bloqueio motor), em aumento de partos instrumentais e em aumento da incidência de hipotensão arterial. A longo prazo (12 meses), as mulheres no grupo de altas dosagens  parecem ter mais problemas de incontinência urinária e controle intestinal. A adição do opióide (por exemplo, 2 microgramas/ml de fentanila) para baixa concentração de anestésicos locais (menos do que 0,125% de bupivacaína ou equivalente) proporciona analgesia eficiente  com menor bloqueio motor e menos partos instrumentais. Em termos de eficiência analgésica e resultados obstétricos, há pouca diferença entre as anestesias locais com baixa concentração (Bupivacaína 0,0625% a 0,1% ou equivalente) e opióides locais. Há evidências limitadas que sugerem que a adição de opióides pode resultar em um aumento de reanimação neonatal. As taxas de volume, sejam em administração intermitente ou em infusão contínua, variaram muito em cada método estudado. Taxas menores que 6 ml/h são menos eficazes e alguns autores sugerem como ideal manter a 8 ml/h.  
Considerando a eficácia da analgesia, os resultados convergem para uma maior relevância da dose, do que para as variáveis desta em sí. Considerando que altas concentrações podem estar associadas a piora da função motora, é preferível ajustar a dose otimizando o volume.  
Apesar da infusão contínua da analgesia peridural ter parecido aumentar a quantidade total da analgesia requerida, comparada à administração em bolus intermitente, ela pode também aumentar a satisfação das mulheres. Não houve evidência de diferenças em outros resultados, incluindo  o tipo de parto, eventos adversos e  consequências neonatais.  
A PCA pareceu reduzir a necessidade de se chamar novamente os anestesistas, assim como a dose total de anestesia local e o bloqueio motor das mulheres, comparado à infusão peridural contínua. Não  
houve diferenças significativas nos outros resultados. A PCA parece aumentar a satisfação da mulher. Uma dose maior de PCA pode reduzir o nível de dor e aumentar a satisfação das mulheres, mas pode resultar em uma dose maior do total de analgésico usado.  
Há evidência insuficiente nos resultados obstétricos e neonatais para todos os modos de administração. 10.6.6.3 Outras considerações em relação à manutenção da analgesia regional  
Em relação aos riscos e benefícios clínicos das opções avaliadas, concluiu-se que a utlização de menores concentrações de anestésicos locais associados a opióides traz mais benefícos em relação ao alívio da dor e outros efeitos adversos maternos e perinatais, além de maior satisfação das mulheres. A associação de fentanila à solução de analgesia de parto está associada à maior necessidade de atenção na assistência neonatal, porém sem impacto nos resultados neonatais finais.  A ocorrência de prurido é inerente ao acréscimo de opióides. As diversas  formas de administração da analgesia peridural (administração em bolus intermitente, infusão contínua e PCA) não demonstraram diferenças significativas, exceto por uma melhor satisfação da mulher em relação à PCA quando comparada com administração em bolus intermitente.  
Em relação aos benefícios para a saúde e utilização de recursos no Brasil, todas as substâncias analgésicas e anestésicas consideradas nos estudos são comercializadas no país, não havendo dificuldade para a sua obtenção. A PCA envolve mais recursos do ponto de vista de aporte de tecnologia que as outras opções mas, por outro lado, a menor necessidade de presença dos anestesistas para doses de resgate e diminuição da dose total de anestésicos, pode redundar em economia de recursos. A infusão contínua, comparada com a administração intermitente de anestésicos parece envolver mais recursos, principalmente em termos de horas trabalhadas da equipe de anestesiologistas por requerer mais anestésicos de resgate. Essas considerações não foram baseadas em análises econômicas formais. 10.6.6.4 Recomendações em relação à manutenção da analgesia peridural  
52. A manutenção da analgesia via cateter peridural deve ser iniciada com a menor concentração efetiva de cada anestésico; como exemplo bupivacaína 0,0625% ou ropivacaína 0,1%, ambos acrescidos de fentanila (2 mcg/ml) ou doses equipotentes de outro opióide lipossolúvel.  
53. A manutenção da analgesia via cateter peridural deve ser iniciada com volumes próximos a 10 ml/h.  
54. A manutenção da analgesia via cateter peridural deve ser individualizada, levando em consideração a resposta à solução inicial, assim como particularidades da mulher. Mediante resposta insatisfatória na primeira hora de infusão, deve-se elevar a dose de anestésico, aumentando a taxa de infusão de forma escalonada até no máximo 20 ml/h. Mediante resposta persistentemente insatisfatória devese elevar a concentração do anestésico, após revisar posicionamento do cateter.  
55. A manutenção da analgesia peridural em bolus intermitente ou sob regime de PCA são os modos preferidos de administração para a manutenção da analgesia peridural.  
56. A utilização de um ou outro modo dependerá da disponibilidade de recursos locais.  
57. Não se recomendam rotineiramente altas concentrações de soluções de anestesia local (0,25% ou acima de bupivacaína ou equivalente) para estabelecer ou manter a analgesia peridural.  
- 10.6.7 Conduta e orientação da parturiente sob analgesia regional  
- 10.6.7.1 Infusão de soluções cristalóides imediatamente antes da realização e para manutenção da analgesia regional  
- 10.6.7.1.2 Evidências científicas  
As diretrizes do NICE incluíram uma única revisão sistemática de 2004222 [NE = 1+] que incluiu seis estudos envolvendo 473 gestantes. Dentre os desfechos, primariamente se avaliou a incidência de  
hipotensão materna após a realização da analgesia peridural.  A definição de hipotensão variou entre pouco entre os autores, sendo desfecho negativo quedas na pressão sistólica superiores a 20 mmgH ou 20% dos níveis basais. Porém os trabalhos foram heterogênenos quanto ao quantitativo de cristalóide utilizado na pré-hidratação e a técnica anestésica. A pré-hidratação variou  de 7 ml/kg à 1000 ml. Dois estudos foram com altas doses de anestésico local, outros dois com baixas doses associados ao fentanila e dois com anestesia combinada raqui-peridural. Apenas uma randomização de 1978 (Collins e cols) demonstrou benefício da pré-hidratação com 1 litro de ringer lactato. A peridural foi realizada com a maior concentração de bupivacaína dentre os inclusos (10 ml à 0,375%). A incidência de hipotensão foi de 28% no grupo controle e de apenas 2% no grupo de intervenção (RR 0.07 [95% CI 0.01 to 0.53]; n = 102 ); outro desfecho significativo e favorável foi a incidência de anormalidades na frequencia cardíaca fetal (RR 0,36 [95% CI 0.16 to 0.83]; n = 102). Em nenhum dos outro estudos a intervenção se mostrou eficaz em minimizar a ocorrência de hipotensão materna após analgesia peridural, assim como os demais desfechos. Interessante observar que a incidência de hipotensão entre os estudos variou de 0 a 45%, o que sugere a existência de outra variável não descrita entre as populações estudadas, como por exemplo, o esquema de hidratação das gestantes ao longo do trabalho de parto. 10.6.7.2 Deambulação, mobilização e verticalização após analgesia regional 10.6.7.2.1 Evidências científicas  
As diretrizes do NICE incluíram 3 estudos que avaliaram a deambulação, mobilização e verticalização da mulher sob analgesia peridural que são descritos a seguir.  
Uma RS avaliou se a deambulação no primeiro estágio do parto influencia nos desfechos em mulheres sob analgesia peridural223 [NE = 1+]. Foram incluídos cinco ERCs (n = 1161) incluindo tanto mulheres em trabalho de parto espontâneo como induzido. No grupo estudado foram incluídas mulheres que assumiram qualquer posição vertical maior que 45°, seja sentada, em pé ou caminhando. Entretanto, 66 a 86% das mulheres neste grupo deambularam entre 5 a 20 minutos por diferentes períodos. Não houveram diferenças signifivativas para quaisquer desfechos. Taxa de parto instrumental (RR 0.91 [IC 95% 0,93 a 1,44]) e taxa de cesariana (RR 0,91 [IC 95% 0,70 a 1.19]). Não houve diferenças quanto a incidência de acidentes ou efeitos adversos aparentes com a mobilização de gestantes sob analgesia, porém o número de eventos foi muito baixo para se concluir por hipótese nula.  
Na segunda revisão, uma metanálise do mesmo autor, avalia especificamenente o benefício de posições  
verticalizadas no segundo estágio de parto224 [NE = 1+]. Foram incluídos dois ERCs (n  =  281) de boa qualidade. Foram consideradas posições verticais: em pé, andando, ajoelhada, agachada (cócoras) ou sentada > 60°.  Apesar de não ter observado diferenças signifivativas para o desfecho via de parto: taxa de parto instrumental (RR 0,77 [IC 95% 0,46 a 1,28]) e taxa de cesariana (RR 0,57 [IC 95% 0,28 a 1,16]), a duração do parto foi menor no grupo que assumiu posições verticais. Menor tempo de segundo estágio e menor tempo total respectivamente nos dois ERCs incluídos. Os estudos não foram desenhados para avaliar sangramento e demais complicações.  
O terceiro estudo trata-se de um ERC, conduzido por obstetrizes do Reino Unido que avaliaram nulíparas sob analgesia peridural. As parturientes foram incluídas na fase passiva do segundo estágio e  
alocadas para posição sentada ou decúbito lateral, afim de avaliar influência no desfecho225[NE = 1-]. Não houve controle intergrupos do índice de massa corporal e porcentagem de partos induzidos. Além disso o tamanho da amostra, pouco mais de cem pacientes, limitou o poder de análise dos desfechos. Sumariamente, não houve diferença estatísticamente significantiva quanto aos desfechos analisados,  
exceto pela taxa de episiotomia, maior no grupo de gestantes que assumiu a posição sentada (44,9% versus 63,8%, χ2 = 3.8, df = 1 [IC 95% 0,44 a 1,00], porém sem diferença quanto ao traumatismo perineal.  
10.6.7.3 Interrupção da analgesia peridural em fases tardias do parto 10.6.7.3.1 Evidências científicas  
As diretrizes do NICE incluíram uma RS<sup>226</sup> [NE = 1+] que incluiu 468 gestantes as quais foram alocadas quanto à presença ou não de anestésico durante o segundo estágio. No grupo de intervenção a infusão peridural foi interrupida após 8 cm de dilatação. Não foram demonstradas diferenças estatística entre os desfechos: Taxa de instrumentalização(RR 0,84 [IC 95% 0,61 a 1,15], cesariana (RR 0,98 [IC 95% 0,43 a 2,25]) e duração do segundo estágio (DMP −5.80 minutes [IC 95% −12,91 a 1,30 minutes]). O único desfecho diferente entre os grupos foi o fato das gestantes, nas quais fora interrompida a peridural, reclamarem pela ausência de analgesia (RR 3,68 [IC 95% 1,99 a 6,80]). A satisfação materna não foi avaliada. Dois estudos dessa RS não foram incluídos na metanálise, porém os resultados não diferem dos demais.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.7.4 Puxos maternos no segundo estágio em parturientes sob analgesia peridural -->
10.6.7.4.1 Evidências científicas  
As diretrizes do NICE incluíram vários estudos na sua revisão que avaliaram o efeito dos puxos maternos no segundo período do parto em parturientes sob analgesia peridural. Os mesmos são descritos a seguir.  
Um estudo de coorte prospectivo incluíndo 413 gestantes sob analgesia peridural<sup>227</sup> [NE = 2+] avaliou parturientes que iniciavam os puxos logo que informadas quanto aos 10 cm de dilatação comparadas com outro grupo onde os puxos somente eram realizados quando se visualizava a cabeça fetal ou passado três horas da dilatação total (situação que se estabelecesse primeiro). Cerca de ¾ das gestantes requereram ocitocina. O tempo para se iniciar os puxos voluntários foi relativamente próximo em ambos os grupos: 0,7 e 0,9 horas nos grupos passivo e ativo respectivamente. Resultados: menor tempo de segundo estágio (fase passiva), assim como menor necessidade de fórceps por distócia de rotação (44,84% versus 54,79%, P < 0.04) no grupo de puxos voluntários. A taxa de admissão em UTI neonatal também foi menor no grupo de puxos ativos (n = 5 vs n = 14, P = 0,017), embora sem diferenças quanto ao escore de APGAR e necessidade de suporte ventilatório. Apesar das limitações metodológicas evidentes, este foi o primeiro estudo comparativo nesta sub-população, e sucitou a realização de outros de melhor qualidade.  
Uma RS incluindo oito ERC<sup>228</sup> [NE = 1+] comparou a realização involuntária de puxos após 10 cm de dilatação versus uma conduta materna mais passiva caracterizada pelo atraso nos puxos voluntários por uma hora (um estudo) ou somente involuntários próximos ao final do parto (sete estudos). Os resultados não mostraram resultados que fossem estatísticamente significativos para a maioria dos desfechos, como o total de partos instrumentais (RR 0,94 IC 95% 0,84 a 1,01]), embora com uma diminuição na incidência de fórceps médio e rotacional no grupo de puxos atrasados (RR 0,69 [IC 95% 0,55 a 0,87]). A duração do segundo estágio foi abreviada em média 58 minutos (média 58,2 min IC 95% 21,51 a 94,84 min) no grupo que realizou puxos voluntários logo que foram informadas sobre a dilatação total, porém o tempo de segundo período ativo variou amplamente.  
Um ERC incluindo 45 nulíparas sob parto induzido que requeriram analgesia peridural<sup>229</sup> [NE = 1+] comparou parturientes que iniciaram os puxos logo que informadas quanto aos 10 cm de dilatação, especificamente realizando puxos sincronizdos com respiração lenta e profunda, retendo-os em seu  
ápice por dez segundos cerca de três vezes a cada contração. No outro grupo, os puxos somente foram realizados involuntariamente na emergência de desprendimento fetal ou passado duas horas da dilatação total (situação que se estabelecer primeiro). Excetuando o fato das gestantes de puxo imediato serem mais jovens, os grupos foram homogêneos. Resultados: a duração do segundo estágio foi significativamente maior nas gestantes que assumiam uma conduta mais passiva (média  de 38 minutes à mais, P < 0,01) mas a fase ativa de puxos foi maior no grupo de puxo imediato (média de 42 minutes à mais, P = 0,002).  Os resultados sugerem um maior estresse fetal quando são solicitados puxos ativos imediatos, tendo em vista maior incidência de desaturação, desaceleração e desaceleração prolongada (P = 0,001). Apesar disto o pH do cordão umbilical e os escores de Apgar foram semelhantes. Outro resultado distinto foi a maior incidência de trauma perineal nas gestantes com puxos precoces. (n = 13 versus n = 5, χ2 = 6.54, P = 0.01). Não houve diferença para os demais desfechos, como via de parto, instrumentalização e episiotomia  
10.6.7.5 Uso de ocitocina em parturiente sob analgesia peridural  
10.6.7.5.1 Evidências científicas  
Um único ERC duplo cego em 226 nulíparas está disponível comparando o uso rotineiro de ocitocina ( 2  
a 16 mUi/min) versus placebo (conduta expectante) após analgesia peridural230 [NE= 1+]. O uso rotineiro de ocitocina reduziu o tempo de segundo estágio (média −17.0 min Ic 95% −31.4 to −3.8 minutes), a necessidade de episiotomia  (RR 0.84, P = 0.04)  e a perda de sangue (média −19.0 ml [95% CI −49.0 to 1.0 ml). Quanto ao parto instrumental diminuiu a necessidade do fórceps por distócia não rotacional, sem diferenças quanto a necessidade de fórceps por distócia de rotação. Não houve diferenças estatísticamente significante quanto ao escore de Apgar.  
10.6.7.6 Controles maternos durante o uso da analgesia regional  
10.7.7.6.1 Evidências científicas  
As diretrizes do NICE não encontraram nenhum estudo relacionando a monitoração materna com os desfechos do parto e nascimento em parturientes sob analgesia regional. Incluem apenas duas RS que avaliam a ocorrência de efeitos colaterais após analgesia de parto<sup>173,156</sup> . Os desenvolvedores das diretrizes do NICE fazem recomendações baseadas na ocorrência desses efeitos mas sem apontar evidências do impacto dessas observações nos desfechos maternos e perinatais. As recomendações dessa diretriz adaptada seguem as recomendações da diretrizes- fonte de adpatação com modificações e acréscimos nos limites das orientações especificadas em normativas brasileiras.  
10.6.8 Resumo das evidências e conclusões em relação à assistência à parturiente sob analgesia  
peridural  
Não existem evidencias de que a pré-hidratação seja eficaz para minimizar a ocorrência de hipotensão materna e anormalidades na frequencia cardíaca fetal após analgesia peridural. Exceto quando utilizadas altas concentrações de anestésico local, à saber bupivacaína 0,375%. Porém, à luz das evidencias atuais, esta concentração raramente é requerida para analgesia de parto, o que limita a reprodução deste benefício.  
Nesta sub-população, a estratégia de incentivo a deambulação e verticalização durante o parto produz resultados discretos sobre os desfechos mais relevantes. Uma postura mais ativa está associada há menor tempo de parto, sem alterar a via e necessidade de instrumentalização.  
A interrupção da infusão peridural em fases mais avançadas do parto não está associada a benefícios para quaisquer desfechos maternos e neonatais e eleva a dor materna.  
A solicitação de puxos maternos voluntários após 10 cm de dilatação está associado a menor tempo de  
segundo estágio. Porém, quando discriminamos o tempo de segundo estágio em passivo e ativo, os resultados são controversos para este. Alguns estudos associam os puxos precoces e involuntários a fase ativa de segundo estágio prolongada, sugerindo fadiga materna. Um único ERC associa puxos precoces e involuntários a um maior estresse fetal. Novos estudos devem ser agregados à revisão afim de definir melhor o benefício dos puxos ativos e precoces.  
O uso profilático da ocitocina após analgesia peridural não altera o desfecho obstétrico e neonatal. 10.6.9. Outras considerações  
Em relação à pré-hidratação, os estudos não avaliaram a necessidade de cateterismo vesical de alívio. Não foram descritas evidências que fazem análise do esquema de hidratação das pacientes antes de serem alocadas para analgesia.  
Embora não fosse o desfecho avaliado nos estudos,  observa-se que a analgesia peridural em baixas dose associada a opióides é compatível com a deambulação e mobilização da gestante.  
Os estudos não foram desenhados com amostra suficiente e poder estatístico para se avaliar a segurança. Entretanto a baixa incidência de eventos adversos sugerem que  a analgesia peridural em baixas doses associada a opióides  é segura para as gestantes que desejem deambular e assumir posições mais verticais.  
Considerando que não há domínio pleno sobre a ocorrência materna de efeitos adversos e complicações, considera-se rotineira a  necessidade de uma monitorização básica e por um período mínimo após analgesia regional. Já o tempo e a complexidade desta monitorização irá depender da técnica utilizada e da análise individualizada da gestante.  
Foi consenso no grupo elaborador que a analgesia deve acontecer sob constante vigilância com monitorização da circulação e oxigenação. Entretanto pode acontecer da parturiente desejar deambular ou assumir outras posições durante o trabalho de parto, necessitando se desvencilhar dos cabos e monitores. Neste momento se faz necessária uma análise individualizada da parturiente. Se não ocorrer anestesia, mas apenas analgesia de parto (alívio total ou parcial da dor), a mulher estará apta para mobilização.  
O planejamento da analgesia de parto, no que tange a escolha de técnicas e soluções, assim como a avaliação após analgesia da resposta materna, são passos fundamentais neste processo. 10.6.10 Recomendação em relação à assistência à parturiente sob analgesia peridural  
58. Antes da realização da analgesia regional de parto deve haver acesso venoso pré-estabelecido.  
59. Pré-hidratação não deve ser utilizada de forma rotineira mas apenas em casos selecionados.  
60. Toda gestante após analgesia regional deve ser avaliada quanto à ocorrência de hipotensão arterial, sendo a necessidade de hidratação ou suporte com substâncias vasoativas avaliada individualmente.  
61. A manutenção da hidratação deve obedecer a recomendação citada no ítem dieta no trabalho de parto. Convém ressaltar que, em função da administração de opióides, a oferta de dieta com resíduos é proscrita após anestesia regional.  
62. A gestante sob analgesia peridural, quando se sentir confortável e segura,  deve ser encorajada a deambular e adotar posições mais verticais.  
63. A administração da solução peridural não deve ser interrompida no intuito de se otimizar desfechos, mas deve obedeçer as necessidades e desejo materno, ainda que no período expulsivo.  
64. O cateter peridural, instalado durante o parto, poderá ser utilizado no terceiro estágio do parto, como por exemplo na reparação perineal.  
65. Após confirmados os 10 cm de dilatação, não se deve incentivar a gestante a realizar puxos, exceto  
se tardiamente (sugere-se no mínimo após 1 hora de dilatação total) ou quando a cabeça fetal se tornar visível.  
66. Os puxos devem ser sempre durante a contração.  
67. Após constatado 10 cm de dilatação, devem ser estabelecidas estratégias para que o  nascimento ocorra em até 4 horas, independente da paridade.  
68. A administração de ocitocina após analgesia regional não é recomendada de rotina e deve obedecer as recomendações referentes ao uso de  uterotônicos expostas nas seções específicas.  
69. A técnica de analgesia no parto deve visar o controle adequado da dor  com o menor comprometimento possível das funções sensoriais, motoras e autonômicas. Para isto a iniciação e manutenção da analgesia com baixas concentrações de anestésico local constitui fator fundamental, particularmente importante para que as parturientes se mantenham em movimento.  
70. Toda gestante submetida a analgesia de parto deverá estar com monitorização básica previamente instalada (Pressão Arterial Não Invasiva - PANI a cada 5 minutos e oximetria de pulso).  
71. Estando sob monitoriação, após 15 minutos da administração do(s) agente(s) a gestante deverá ser avaliada quanto à resposta (nível do bloqueio, sensibilidade perineal, testes de função motora , teste do equilíbrio e de hipotensão postural). Caso a avaliação seja desfavorável à mobilização ou se constate “estado de anestesia”  (hiposensibilidade e bloqueio motor) a gestante deverá permanecer no leito sob vigilância constante até nova reavaliação. Caso a avaliação seja favorável, somente “estado de analgesia”, a gestante estará sem impedimentos para deambular e assumir a posição que desejar.  
72. Caso a avaliação seja desfavorável à mobilização ou se constate estado de anestesia (hiposensibilidade e bloqueio motor), os quais persistem mesmo após o terceiro estágio a gestante deverá ser encaminhada a SRPA (Sala de Recuperação Pós-Anestésica) e permanecer no leito sob vigilância constante até alta pelo médico anestesiologista.  
73. A rotina de monitoração para iniciação da analgesia de parto deve ser repetida nos momentos de doses de resgate via cateter peridural.  
74. Se após 30 minutos da analgesia de parto ou repique for constatada inefetividade, o anestesiologista deverá considerar falha técnica ou revisar individualmente as necessidades de alívio da parturiente.  
75. Uma vez realizada analgesia de parto, ainda que não ocorram doses de resgate, o anestesiologista deverá acompanhar a parturiente, com avaliação horária, até o terceiro período.  
76. Considerando a possibilidade de complicações, todo cateter peridural deve ser retirado pelo médico anestesiologista. A gestante não poderá receber alta do bloco obstétrico, unidade PPP ou SRPA com cateter instalado, exceto com a autorização do anestesiologista.  
10.6.10 Controles fetais durante o uso da analgesia regional

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 10.6.10.1 Evidências científicas -->
As diretrizes do NICE incluíram 2 estudos<sup>231,233</sup> de um mesmo grupo de pesquisa [NE = 1+] que compararam a analgesia peridural versus meperidina endovenosa quanto à incidência de anormalidade no ritmo cardíaco fetal. Em outro cenário, a incidência foi avaliada após o uso de opióide intratecal. Os resultados foram integrados em uma revisão sistemática.  
Em ambos estudos a analgesia peridural foi conduzida com baixa concentração de anestésico local, definida como bupivacaína menor que 0,25% ou equivalente. Especificamente comparou-se: Bupivacaína peridural versus 10 mg de meperidina endovenosa e Bupivacaína peridural 0,0625% com 2mcg/ml fentanila versus meperidina 15 mg. Em ambos, as doses de resgate foram realizadas com  
bupivacaína 0,25%, e no controle a meperidina administrada com intervalo mínimo de 10 minutos até no máximo de 50 mg.  
No primeiro estudo incluído (n = 358 nulíparas)<sup>231</sup> não se observou diferenças nos traçados da FCF (frequência cardíaca fetal) (RR 1,07 [95% CI 0.27 to 4.21]). Já no outro (n = 200 nulíparas)<sup>232</sup> foi demonstrado que mulheres com analgesia peridural apresentaram nos primeiros 40 minutos variabilidade fetal diminuída à CTG (30% versus 7%, P < 0,001) (RR 0,23 IC 95% 0,15 a 0,30), assim como mais acelerações (88% versus 62%, P < 0,001)  (RR 1,42 IC 95% 1,24 a 1,63]), porém não houveram diferenças significativas quanto às desacelerações (34% versus 41%; P = 0,353). A RS anteriormente citada<sup>122</sup> , na análise do desfecho neonatal não observou diferenças quando comparado a anestesia regional versus endovenosa ou sem analgesia. Entretanto no grupo de opióide endovenoso  a necessidade de se utilizar naloxona imediatamente após o nascimento foi muito mais frequente com os opióies endovenosos (4 ERC; RR 0,15 IC 95% 0,06 a 0,40). A despeito disto não houve diferença no pH do cordão umblical <7,2 (5 ERC; RR 0,87 IC 95% 0,71 a 1,07).  
Uma RS inglesa incluiu 24 estudos totalizando 3.513 gestantes233 [NE = 1+] avaliou o impacto de três opióides de uso intratecal em diferentes doses e com ou sem anestésico local (morfina, fentanila e sufentanila) na FCF à CTG. A metanálise concluiu pela incidência significativa de bradicardia fetal transitória na primeira hora após administração de opióide intratecal em relação ao seu uso endovenoso. Não foram encontradas outras anormalidades significativas no rítmo cardíaco fetal. 10.6.10.2 Resumo das evidências e conclusões  
A analgesia peridural e a administração de opióide intratecal quando comparada a analgesia opióide intravenosa estão associadas a maior incidência de alterações clinicamente pouco relevantes à CTG e bradicardia fetal transitória respectivamente.  
10.6.10.3 Outras considerações  
Emboram possam ocorrer alterações no rítmo e frequencia cardíaca fetais, não há associação com pior desfecho neonatal. Exceto, pela maior necessidade de naloxona no grupo venoso. As alterações subsequentes a analgesia regional, são em sua imensa maioria, passageiras.  
10.6.10.4 Recomendações em relação à monitoração fetal em parturientes sob analgesia regional  
77. Toda parturiente submetida a início de analgesia regional ou doses adiconais de resgate, seja qual for a técnica, deve ser submetida a ausculta intermitente da FCF de 5 em 5 minutos por no mínimo 30 minutos. Uma vez alterado deve-se instalar CTG, assim como proceder a cuidados habituais como decúbito lateral esquerdo e avaliar necessidade de otimização das condições respiratórias e circulatórias. Caso não ocorra melhora, seguir diretrizes próprias para conduta no estado fetal não tranquilizador.  
78. Se ocorrerem anormalidades fetais graves, não transitórias, considerar outra causa que não analgesia regional e seguir diretrizes próprias para conduta no estado fetal não tranquilizador.  
10.6.11 A analgesia regional e a amamentação  
10.6.11.1 Evidências científicas  
As diretrizes do NICE avaliaram a influência da fentanila quando usado na analgesia regional e seu impacto na amamentação. Foram incluídos dois estudos na revisão que são descritos a seguir. Um estudo trasnversal e retrospectivo incluindo 425 nulíparas atendidas em uma maternidade no ano 2000234[NE = 3] avaliou a porcentagem de recém nascidos que necessitavam de amamentação artifical (suplemento) e correlacionou com o tipo de anestesia administrada: 32% com oxido nitroso, 42% com opióides (IM), 44% com anestésico local neuraxial e 54% com solução neuraxial contendo fentanila. Em  
análise de regressão logística, o fentanila elevou a chance de amamentação artificial em 1,0004 vez para cada micrograma administrada (OR 1,0004 IC 1,000 a 1,008). Apesar do baixo nível de evidência, este trabalho despertou o interesse por estudos de maior capacidade analítica.  
ERC norte americano235[NE = 1+] randomizou 177 gestantes em três grupos conforme dose de fentanila peridural: 0, até 150 e superior a 150 mcg. Os níveis de fentanila no cordão umbilical foram significativamente elevados quanto maior a dose administrada. Assim como foi menor o Escore de Capacidade Neurológica Adaptativa (ECNA): 35, 34 e 32 nos grupos sem opióide, intermediário e alta dose respetivamente. Apesar disto, a relevância clínica desta diferença não foi determinada, assim como não refletiu na amamentação nas primeiras 24 horas após o nascimento. No seguimento tardio 14 gestantes (9%) não amamentaram por mais de seis meses: 1, 3 e 10 nos grupos sem opióide, intermediário e alta dose respetivamente. Os níveis de fentanila no cordão > 200 pg/ml quando comparados a < 200 pg/ml foi preditor para este desfecho tardio desfavorável (P = 0,02), entretanto a preditividade mais significativa esteve relacionada a dificuldade das mesmas mães amamentarem ainda nas primeiras 24 horas (29% versus 6%, P = 0.004).  
10.6.11.2 Resumo das evidências  
Pequenos estudos sugerem uma fraca associação entre a dose de fentanila peridural e o desfecho amamentação (sucesso e duração). Novos estudos são necessários.  
10.6.11.3 Outras considerações  
Embora supõe-se que a via de administração intratecal dos opióides seja de menor absorção sistêmica quando comparada a peridural, não existem estudos que comprovem este benefício.  
As diretrizes-fonte de adpatação não faz nenhuma recomendação específica a respeito deste tópico, apenas recomenda a necessidade de mais estudos para avaliar o impacto de opióides utilizados na analgesia regional nos desfechos neonatais, incluindo necessidade de reanimação e no aleitamento. 11 Ruptura prematura de membranas (RPM) no termo.  
11.1 Introdução  
A ruptura prematura de membranas no termo é fator de preocupação para as mulheres e seus familiares, estando associada a muitos mitos em relação aos riscos maternos e neonatais. Mesmo entre os profissionais que assistem a mulher nesse momento não há um consenso sobre a melhor forma de atuação diante dessa situação. Esta seção tem como objetivo analisar e sintetizar as evidências científicas disponíveis para auxiliar na conduta a adotar no caso de mulheres que apresentarem RPM no termo.  
11.2  Questões de Revisão  
- Como identificar e agir adequadamente diante da ruptura prematura de membranas no termo?  
- O período de tempo entre a ruptura das membranas e o parto afeta os resultados maternos e perinatais?  
- A conduta expectante pode ser oferecida para a rotura prematura de membranas no termo?  
- O número de exames genitais durante o trabalho de parto com RPM afeta os resultados maternos e perinatais?  
- A monitoração eletrônica de rotina da FCF e a frequência e tipo da monitoração materna afeta os resultados?  
- O uso de antibióticos antes do parto em mulheres com RPM no termo, assintomáticas  ou sintomáticas, afeta os resultados?  
- Quais são os critérios para o uso de antibióticos em recém-nascidos saudáveis após ruptura pré-

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.3 Identificação da RPM no termo -->
As diretrizes do NICE, do País Basco e da Bélgica não abordaram técnicas específicas para a identificação da ruptura prematura de membranas. As diretrizes do ICSI recomendam a utilização de observação de líquido acumulado no canal vaginal, o teste de cristalização, o teste de nitrazina e a utilização de testes comerciais como o AmniSure para a identificação da ruptura prematura de membranas. Entretanto, não apresenta evidências em relação à eficácia das referidas técnicas diagnósticas.  
11.4 Vigilância e monitoração na RPM no termo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.4.1 Evidências Científicas -->
Não foram encontradas evidências científicas que mostrem um efeito positivo sobre que tipo de vigilância seria benéfica para parturientes e seus fetos. Foram incluídas monitoração eletrônica da frequência cardíaca fetal (EFM), verificação da temperatura e o pulso materno e a triagem laboratorial para infecção.  
11.5 Período de tempo entre a RPM e desfechos maternos e perinatais  
11.5.1 Evidências científicas  
As diretrizes do NICE incluíram em sua revisão uma revisão sistemática de 12 ERCs envolvendo 6.814 mulheres<sup>236</sup> [NE = 1+] e uma análise secundária de um estudo internacional, multicêntrico, envolvendo 72 instituições em seis países (n = 5.041 mulheres)<sup>237</sup> [NE = 2++].  
A revisão sistemática incluiu mulheres com RPM, eram saudáveis e com pelo menos 37 semanas de idade gestacional que foram alocadas para indução do trabalho de parto imediato ou indução dentro de 24 horas, ou para a conduta expectante (sem intervenção planejada dentro de 24 horas)<sup>236</sup> [NE = 1+]. Os resultados da meta-análise  mostrou que as mulheres alocadas para conduta ativa imediata tiveram um menor tempo entre a ruptura das membranas e o parto que a conduta expectante (cinco ensaios): diferença da média ponderada (DMP) -9,53 horas [IC 95% -12,96 a -6,10 horas]. O mesmo achado se repetiu com a corioamnionite com uma menor incidência no grupo da conduta ativa: 226/3300 contra 327/3311; RR 0,74 [IC 95%  0,56 - 0,97]. Novamente o grupo da conduta ativa teve menor incidência de endometrite: 5/217 contra 19/228; RR 0,30 [IC 95% 0,12-0,74], apesar de não haver diferença significativa entre os grupos em relação à incidência de febre pós-parto: 82/2747 contra 117/2774; RR 0,69 [IC de 95% 0,41-1,17].  
Não houve diferença entre os grupos no tipo de parto quando comparados a conduta ativa ou expectante: cesariana: 333/3401 contra 360/3413; RR 0,94 [IC 95% 0,82-1,08]; parto vaginal instrumentado: 487/2786 contra 502/2825; RR 0,98 [IC de 95% 0,84-1,16].  
Os recém-nascidos do grupo da conduta ativa da RPM tiveram menor chance de serem admitidos em UTIN ou em unidade de cuidados intermediários que os da conduta expectante: 356/2825 contra 484/2854; RR 0,73 [IC de 95% 0,58-0,91]. No entanto, esta diferença na taxa de admissão pode refletir as políticas do hospital, em vez da necessidade clínica. Não foram encontradas diferenças significativas para quaisquer desfechos neonatais como mortalidade fetal/perinatal: 3/2946 contra 7/2924; RR 0,46 [IC 95% 0,13-1,66]; Apgar < 7 aos 5 minutos: 335/3000 contra 366/3005; RR 0,93 [IC de 95% 0,81-1,07]; ventilação mecânica: 25/2566 contra 28/2592; RR 0,99 [IC 95% 0,46-2,12]; infecção neonatal: 74/3210 contra 93/3196; RR 0,83 [IC de 95% 0,61-1,12].  
Análises secundárias de dados do ensaio multicêntrico internacional<sup>237</sup> foram realizadas para identificar preditores de infecção neonatal associados à RPM no termo. Os resultados mostraram que períodos mais longos de tempo com RPM foram associados a uma maior incidência de infecção neonatal: 48  
horas ou mais versus 12 horas: OR 2,25 [IC 95% 1,21-4,18]; De 24 a 48 horas versus 12 horas: OR 1,97 [IC 95% 1,11-3,48].

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.6.1 Evidências científicas -->
As diretrizes do NICE (NCCWCH, 2014) incluíram em sua revisão análises secundárias de dados de um grande estudo internacional (n = 1.670 mulheres)<sup>238</sup> , um pequeno ERC do Reino Unido (n = 56)<sup>239</sup> e um estudo observacional, prospectivo dinamarquês (n = 276)<sup>240</sup> .  
O conjunto de dados do estudo de RPM no termo foi analisado para determinar se os efeitos adversos da conduta expectante da RPM no termo e satisfação das mulheres foi maior se as mulheres fossem cuidadas em casa, em vez de no hospital<sup>238</sup> [NE = 2 +]. A análise envolveu 653 mulheres que permaneceram em casa em comparação com 1.017 que foram admitidas no hospital. Várias análises de regressão logística mostraram que recém-nascidos das primíparas que foram assistidas em casa usaram mais antibióticos, em comparação com os recém-nascidos cujas mães foram assistidas no hospital: OR 1,52 [IC 95% 1,04-2,24]. As mulheres negativas para estreptococo do grupo B (GBS) tinham mais chances de cesariana quando cuidadas em casa, em vez de no hospital: OR 1.48 [IC 95% 1,03-2,14]. “As multíparas afirmaram que “participariam novamente do estudo” se o atendimento fosse domiciliar, em vez de no hospital: OR 1,80 [IC 95% 1,27-2,54]. O risco de infecção neonatal foi maior entre as mulheres que foram assistidas em casa, em comparação com as do hospital: OR 1.97 [IC 95% 1,00-3,90].  
O ERC inglês comparou a conduta expectante em casa (n = 29) com a conduta expectante no hospital (n = 27) em pacientes com RPM no termo<sup>239</sup> [NE = 1-]. Em ambos os grupos a conduta foi de induzir o trabalho de parto se o mesmo não tivesse iniciado nas primeiras 24h da RPM. Não houve diferença entre os grupos quanto tempo de RPM e o parto (casa: 31,39 horas (DP 12,70 horas); hospitalares: 26,99 horas (DP 11,78 horas), o valor de t = 1,34, P = 0,18. Não foram encontradas diferenças entre os grupos para: infecção materna precoce: 7/28 contra 9/27, χ2 = 0,46, P = 0,49; infecção materna tardia: 14/24 contra 11/23, χ2 = 0,521 P = 0,47 e infecção neonatal: 12/17 contra 11/12, χ2 = 2,98, P = 0,23. Os autores reconhecem, no entanto, que o ensaio foi insuficiente para detectar uma diferença significativa nestes desfechos.  
O estudo prospectivo observacional comparou os desfechos entre pacientes que se mantiveram no domicilio e eram avaliadas em ambulatório para aguardar o início do trabalho de parto após RPM (n = 176) com um grupo histórico de pacientes que foram internadas no hospital para indução do parto entre 6-12h após a RPM (n = 100)<sup>240</sup> [NE = 2-] As pacientes deveriam medir a temperatura 2 vezes ao dia e serem avaliada com MEF a cada dois dias e para verificar se havia sinais de infecção. O intervalo de tempo entre a RPM e o parto no grupo estudado foi de  14-85 horas (percentil 10-90). Embora a morbidade infecciosa materna, sofrimento fetal, parto vaginal instrumental devido à falta de progresso tenham sido mais elevados no grupo de intervenção em nenhum deles houve diferenças com significância estatística. A incidência de morbidade infecciosa neonatal foi de 2% em cada grupo de estudo. Houve dois óbitos neonatais na conduta expectante no grupo observacional, no entanto, nenhum recém-nascido apresentou culturas positivas para infecção.  
11.7 Fatores de risco para infecção na RPM no termo  
11.7.1 Evidências científicas  
As diretrizes do NICE incluíram na sua revisão análises realizadas do subgrupo da revisão sistemática de 12 estudos descritos acima<sup>236</sup> [NE = 1+] mais análises secundárias de resultados do estudo multicêntrico internacional<sup>238,241</sup> [NE = 2 ++], um pequeno quasi-ERC<sup>242</sup> [NE = 1-], um estudo prospectivo  
observacional<sup>243</sup> [NE = 2 +] e um estudo caso-controle retrospectivo<sup>244</sup> [NE = 2+] . 11.7.1.1 Paridade  
Análises dos resultados de subgrupos da revisão sistemática descrita acima investigaram os efeitos da paridade no desfecho materno e neonatal na RPM no termo<sup>236</sup> [NE = 1+]. Não foram encontradas diferenças significativas entre os resultados para as mulheres nulíparas e multíparas.  
O estudo caso-controle retrospectivo de mulheres com RPM com 37 semanas de gestação ou mais realizado em Israel (n = 132 casos e n = 279 controles)<sup>244</sup> [NE = 2 +] comparou três grupos de pacientes: as que tiveram parto induzido imediatamente; pacientes com conduta expectante de até 24 horas e depois foram induzidas; e pacientes com conduta expectante por mais de 24 horas. O desfecho primário escolhido foi a infecção, não sendo feita qualquer distinção entre a infecção materna e neonatal, embora refira-se que a taxa de infecção neonatal total foi muito baixa (menos do que 1%). A análise multivariada por regressão logística revelou que a nuliparidade foi fator independente associado com infecções na mulher e recém-nascido: OR 1,92 [IC 95% 1,19-3,00].  
11.7.1.2 Colo Favorável/Desfavorável  
A revisão sistemática também realizou uma análise de subgrupo para investigar os efeitos do colo desfavorável versus um estado misto ou desconhecido do colo<sup>236</sup> [NE = 1+]. Não foram encontradas diferenças significativas entre os resultados quando se comparam estes dois subgrupos.  
O pequeno quasi-ERC americano comparou indução imediata do trabalho de parto (n = 32) com a conduta expectante (n = 35) para as mulheres com RPM entre 38 e 41 semanas de gestação<sup>242</sup> [NE = 1-]. Todas as pacientes incluídas no estudo tinham um colo desfavorável para a indução do trabalho de parto (2 cm ou menos dilatação e não mais do que 50% apagados). A incidência de endometrite foi maior no grupo de indução imediata: 4/35 contra 10/32, P = 0,04 (teste exato de Fisher). Este fato pode ser explicado em parte pelo trabalho de parto mais prolongados neste grupo: (média) 10,44 horas (DP 5,5 horas) versus 14,1 horas (DP 6,0 horas); e ao maior número de exames vaginais realizados durante o parto para as mulheres neste grupo: (média) 3,9 contra 5,7. Não houve incidentes de sepse neonatal em ambos os grupos.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.7.1.3 Exame Vaginal -->
O estudo internacional, multicêntrico de RPM no termo também investigou preditores de corioamnionite clínica e febre pós-parto<sup>238,241</sup> [NE = 2 ++]. Os preditores foram calculados usando análise secundária dos dados experimentais que compararam a conduta ativa com a conduta expectante de até 4 dias após a RPM. A corioamnionite clínica foi definida como um ou mais dos seguintes achados: febre materna maior do que 37,5° C em duas ou mais ocasiões com 1 hora ou mais de intervalo, ou uma única temperatura superior a 38°C antes do parto; leucocitose superior a 20.000 células / mm3 ou mau-cheiro do líquido amniótico<sup>241</sup> [NE = 2 ++]. Ocorreu corioamnionite clínica em 6,7% das mulheres (n = 335). O número de exames vaginais (EV) foi o fator independente direto mais importante para aumento do risco da infecção. Por exemplo: menos de 3 EV contra 3-4 EV: OR 2,06 [IC 95% 1,07-3,97]; ou menos de 3 EV contra 7-8 EV: OR 3,80 [95% IC 1,92-7,53], e a incidência de corioamnionite aumentou de 2% para 13%. O estudo caso-controle retrospectivo realizado em Israel mostrou o mesmo resultado que  aponta o EV como fator independente de infecção (materna ou neonatal)<sup>244</sup> [NE = 3]. As pacientes com 7 ou mais EV apresentaram um risco maior de infecção (materna/neonatal) em comparação com as pacientes com menos de 7 EV durante o trabalho de parto (OR 2,70 [IC 95% 1,66-4,34]).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.7.1.4 Duração do trabalho de parto -->
A análise secundária dos dados do estudo multicêntrico internacional de RPM no termo determinou que  
a duração do trabalho de parto é fator de risco para infecção, pois quando ele foi maior que 9 horas comparado com aqueles que duraram menos de 3 horas a incidência de corioamnionite passou de 2% para 12% (OR 2,94 [95% IC 1,75-4,94])<sup>241</sup> [NE = 2 ++]. O efeito da fase latente foi significativa para durações acima de 12 horas: de 12 a 24 horas versus menos que 12 horas a incidência de infecção foi de 10% (n = 115) OR 1,77 [95% IC 1,27-2,47]; igual ou maior que 48 horas versus menos que 12 horas, a incidência de infecção também foi de 10% (n = 68) ou 1,76 [95% IC 1,21-2,55]. A febre pós-parto ocorreu em 3% das pacientes no estudo (n = 146)<sup>241</sup> [NE = 2 ++] O fator de risco independente mais forte para febre pós-parto foi a corioamnionite clínica (OR 5,37 [IC 95% 3,60-8,00]). A duração do trabalho de parto também foi um fator importante  para o aumento da infecção que passou de 2% em trabalhos de parto entre 3 horas e menos que 6 horas (OR 3,04 [IC 95% 1,30-7,09]) para 8% quando o trabalho de parto durou 12 horas ou mais (OR 4,86 [ 95% CI 2,07-11,4]).  
11.7.1.5 Banho  
Um estudo observacional prospectivo, realizado na Suécia, comparou as taxas de infecção materna e neonatal entre as mulheres com RPM que escolheram tomar banho (n = 538) e aquelas que não tomaram banho (n = 847)<sup>243</sup> [NE = 2 +]. Todas as paciente tinham pelo menos 34 semanas de idade gestacional: idade gestacional média em cada grupo de 39 semanas (DP 1,5 e 1,6). As pacientes foram desaconselhadas a não tomar banho se houvesse presença de mecônio, sofrimento fetal ou quaisquer sinais de infecção (não definido). Houve uma baixa frequência de infecções maternas e neonatais. Ocorreu corioamnionite durante o parto em 1,1% (n = 6) no grupo do banho e 0,2% (n = 2) no grupo do não-banho, p = 0,06. Ocorreram três episódios de endometrite em cada grupo, 0,6% e 0,4%, respectivamente, P = 0,68. A frequência de recém-nascidos que receberam antibióticos foi de 3,7 e 4,8%, respectivamente (P = 0,43).  
11.7.1.6 Fatores de risco associados à infecção neonatal  
A análise secundária dos dados do estudo multicêntrico internacional de RPM no termo foi realizada para identificar fatores de riscos independentes de infecção neonatal<sup>237</sup> [NE = 2 ++]. A infecção neonatal foi diagnosticada ou provável com base em sinais clínicos apoiados por testes laboratoriais bem estabelecidos. Infecção diagnosticada ou provável ocorreu em 2,6% dos recém-nascidos (n = 133). O mais forte fator de risco de infecção neonatal associado a RPM foi a corioamnionite clínica (OR 5,89 [IC 95% 2,02-4,68]). Outros fatores de riscos independentes identificados foram presença de uma cultura materna positiva para estreptococo do grupo (EGB) (em comparação com o desconhecido ou negativo) (OR 3,08 [95% CI 1 2,02-4,68]); 7 ou 8 EV (em comparação com 0 a 2) (OR 2,37 [95% IC 1,03-5,43]); e antibióticos administrados à parturiente antes do parto (OR 1,63 [IC 95% 1,01-2,62]).  
11.8 Uso profilático de antibióticos na RPM no termo  
11.8.1 Evidências científicas  
As diretrizes do NICE incluíram para análise na sua revisão uma revisão sistemática de dois ERC (n = 838 mulheres)<sup>245</sup> [NE = 1+] e a análise de subgrupo da revisão sistemática de 12 ERCs já descrita anteriormente<sup>236</sup> [NE = 1+].  
A revisão sistemática foi realizada para avaliar o uso de antibiótico profilático em gestantes com 36 semanas ou mais de idade gestacional e que apresentavam RPM<sup>245</sup> [NE = 1+]. Dois ensaios foram incluídos na revisão (n= 838 pacientes). Ambos os ensaios utilizaram antibióticos endovenosos e a indução do trabalho de parto com ocitocina em até 24 horas. O uso de antibiótico profilático resultou em diminuição significativa de: endometrite, RR 0,09 [IC 95% 0,01-0,73]; corioamnionite ou endometrite (3% versus 7%), RR de 0,43 [95% IC 0,23-0,82]; e diminuição do tempo de internação neonatal (relatado  
por um ensaio), diferença média -0,90 dias [IC 95% -1,34 a -0,46 dias]. Não houve outras  diferenças, inclusive na morbidade neonatal.  
A análise de subgrupo da revisão sistemática que incluiu 12 ERCs também analisou o uso de antibiótico profilático<sup>236</sup> [NE = 1+]. Por causa das limitações dos estudos incluídos, os grupos de comparação não foram úteis. Não foram encontradas diferenças entre os dois conjuntos de ensaios para a incidência da infecção materna ou neonatal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 11.9 Resumo da evidência e conclusões -->
Há evidências de alto nível que mostra um aumento na infecção neonatal quando ocorre a RPM no termo. O risco aumenta em proporção direta ao tempo de latência entre RPM e o parto. A infecção neonatal é rara, porém pode ser grave e resultar em morte ou invalidez. As evidências demonstram que não há aumento significativo das taxas de infecção neonatal com a conduta expectante até 24 horas. Não foram encontradas evidências em relação aos resultados de longo prazo.  
Para outros desfechos neonatais ou taxas de cesariana ou parto vaginais instrumentados, não há diferenças entre indução imediata e conduta expectante até 96 horas após a ruptura das membranas. Não há aumento significativo no risco de corioamnionite ou endometrite  com a conduta expectante até 24 horas. Não foram encontradas evidências em relação à conduta expectante além de 96 horas após a ruptura de membranas, pois a maioria das pacientes já teriam parido.  
Há evidências limitadas de alto nível sobre efeito do uso rotineiro do antibiótico profilático na mãe que apresente RPM no termo sobre as taxas de infecção, mas os resultados são conflitantes.  
11.10 Recomendações em relação à RPM no termo  
79. Não realizar exame especular se o diagnóstico de ruptura das membranas for evidente.  
80. Se houver dúvida em relação ao diagnóstico de ruptura das membranas realizar um exame especular. Evitar toque vaginal na ausência de contrações.  
81. Explicar às muheres com ruptura precoce de membranas no termo que:  
- o risco de infecção neonatal grave é de 1%, comparado com 0,5% para mulheres com membranas intactas.  
- 60% das mulheres com ruptura precoce de membranas no termo entrará em trabalho de parto dentro de 24 horas.  
- a indução do trabalho de parto é apropriada dentro das 24 horas após a ruptura precoce das membranas.  
82. Até que a indução do trabalho de parto seja iniciada ou se a conduta expectante for escolhida pela mulher para além de 24 horas:  
- Aconselhar a mulher a aguardar em ambiente hospitalar  
- Não realizar coleta de swab vaginal-anal e dosagem da proteína C-reativa materna.  
- Medir a temperatura a cada 4 horas durante o período de observação e observar qualquer alteração na cor ou cheiro das perdas vaginais.  
- Se a mulher optar por aguardar no domicílio manter as mesmas recomendações anteriores e informá-la que tomar banho não está associado com um aumento da infecção, mas ter relações sexuais pode estar.  
83. Avaliar a movimentação fetal e a frequência cardíaca fetal na consulta inicial e depois a cada 24 horas após a ruptura precoce das membranas, enquanto a mulher não entrar em trabalho de parto, e aconselhá-la a comunicar imediatamente qualquer diminuição nos movimentos fetais.  
84. Se o trabalho de parto não se iniciar dentro de 24 horas após a ruptura precoce das membranas, a  
mulher deve ser aconselhada a ter o parto em uma maternidade baseada em hospital, com serviço de neonatologia.  
12 Eliminação de mecônio imediatamente antes ou durante o trabalho de parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.1 Introdução -->
O mecônio é tido como um sinal de alerta pela maioria dos profissionais que assistem partos. Ainda é controversa a sua valorização e qual a melhor conduta ser oferecida diante da eliminação de mecônio antes ou durante o trabalho de parto. O objetivo dessa seção é avaliar a evidência atualmente disponível sobre o tema no sentido de orientar adequadamente os profissionais envolvidos no cuidado. 12.2 Questões de revisão  
- A identificação e a conduta na eliminação de mecônio imediatamente antes ou durante o trabalho de parto afeta os resultados?  
- Como identificar e atuar adequadamente ante a eliminação de mecônio imediatamente antes e durante o trabalho de parto?  
- A gradação do mecônio (fluido, moderado, espesso) afeta os resultados?  
- O tipo de monitoração da FCF (ausculta intermitente versus monitoração eletrônica contínua) afeta os resultados?  
- A amnioinfusão deve ser utilizada no caso de eliminação de mecônio?  
- A realização de cesariana apenas pela eliminação de mecônio afeta os resultados?  
12.3 Identificação, graduação e conduta na eliminação de mecônio

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.3.1 Evidências científicas -->
As diretrizes do NICE incluíram na sua revisão três estudos observacionais, realizados em Israel<sup>246</sup> , Estados Unidos da América (EUA)<sup>247</sup> e na Austrália<sup>248</sup> . Todos já estavam presentes nas diretrizes de 2007. Nenhum estudo mais relevante foi encontrado.  
Um dos estudos incluídos avaliou o grau de acerto entre intra e inter-observador de um sistema de classificação do mecônio, dando a 20 Enfermeiras obstétricas/obstetrizes amostras de mecônio e pedindo-lhes para classificar o grau de coloração mais clara, tinto, moderada ou espesso em 2 ocasiões separadas<sup>248</sup> . O grau de acerto foi analisado comparando a avaliação das Enfermeiras obstétricas/obstetrizes com a classificação padrão fornecida pelos autores, e avaliando o grau de concordância entre as classificações individuais da Enfermeira obstétrica/obstetriz em amostras duplicadas. Outro dos estudos incluídos avaliou o nível de concordância entre a avaliação clínica (tinto, moderado, espesso) pelo médico assistente e um cálculo do ‘meconiumcrit’ usando a razão entre o volume sólido para o volume total<sup>247</sup> O último estudo foi um estudo prospectivo, com um controle retrospectivo, que comparou um sistema de escore para determinar a conduta na presença do líquido meconial verso ausência de escore avaliando se houve melhora com o escore<sup>246</sup>  
Os dados para as diversas comparações são apresentados nas tabelas seguintes:  
Tabela 17 – Resumo para concordância inter e intra-observador em um sistema de classificação de amostras de líquido meconial  
|Estudos|Número de amostras de mecônio|Grau de concordância (medido<br>tanto como uma proporção ou<br>uma estatística kappa<sup>a</sup>)|
|---|---|---|
|Concordância Inter-o<br>com a classificaçãopa|bservador (taxa de concordância das e<br>drão realizadapelos autores)|nfermeiras obstetrs/obstetrizes|
|Primeira avaliação|||  
Tabela 17 – Resumo para concordância inter e intra-observador em um sistema de classificação de amostras de líquido meconial  
|Estudos|Número de amostras de mecônio|Grau de concordância (medido<br>tanto como uma proporção ou<br>uma estatística kappa<sup>a</sup>)|
|---|---|---|
|van Heijst et al.,<br>1995<sup>248</sup>|32 amostras avaliadas por 20<br>Enfermeiras<br>obstétricas/obstetrizes|Concordância exata com o<br>padrão: média 20,5/32<br>(intervalo 11 a 27) Kappa:<br>média 0,52 (intervalo 0,13 a<br>0,79)|
|Segunda medição|||
|van Heijst et al.,<br>1995<sup>248</sup>|32 amostras avaliadas por 20<br>Enfermeiras<br>obstétricas/obstetrizes|Concordância exata com o<br>padrão:<br>média<br>21,8/32<br>(intervalo 13 a 27)<br>Kappa: média 0,57 (intervalo<br>0,21 a 0,79)|
|Grau de concordância|geral com opadrão,classificadaspelo|porgrau de coloração<sup>b</sup>|
|van Heijst et al.,<br>1995<sup>248</sup>|32 amostras avaliadas por 20<br>Enfermeiras<br>obstétricas/obstetrizes|Claro: 294/320 (91,9%)<br>Tinto: 188/320 (58,8%)<br>Moderado: 134/320 (41,9%)<br>Espesso: 233/320(72,8%)|
|Grau de concordância<br>em amostras duplica|intra-observador (índice de concordâ<br>das dentro de um conjunto)|ncia de parteira com ela mesma|
|Primeira medição|||
|van Heijst et al.,<br>1995<sup>248</sup>|16 pares de amostras duplicadas<br>avaliadas por 20 Enfermeiras<br>obstétricas/obstetrizes|Concordância correta em<br>amostras duplicadas: média<br>23,7/32 (intervalo 14 a 30)<br>Kappa: média de 0,64<br>(intervalo 0,24-0,91)|
|Segunda medição|||
|van Heijst et al.,<br>1995<sup>248</sup>|16 pares de amostras duplicadas<br>avaliadas por 20 Enfermeiras<br>obstétricas/obstetrizes|Concordância correta em<br>amostras duplicadas: média<br>23,5/32 (intervalo 18 a 30)<br>Kappa: média de 0,64<br>(intervalo 0,42-0,91)|  
a. Os autores relatam que a estatística kappa pode ser interpretado da seguinte forma: 0 = sem acordo; <0,20: concordância pobre; 21-0,40: concordância leve; 0,41-0,60: concordância moderada; 0,61-0,80: boa concordância; 0,81-1,00: concordância muito boa; 1.00: concordância completa.  
b. Fora das amostras julgadas clara, tinto, moderada ou espessa pelo padrão definido pelos autores, em quantas ocasiões individuais foram classificadas corretamente pelas enfermeiras obstétricas. As classificações foram descritas da seguinte forma: Tinto = verde pálido  para amarelo sem grumos; Moderado = qualquer amostra entre tinto e espesso, ou com dúvida; Espesso = verde escuro ou preto  
na cor ou com uma  aparência espessa ou "tenaz", ou qualquer líquido que tinha pedaços de mecônio (Nota: definição para 'claro' não é descrito)  
Tabela 18 – Resumo para concordância entre a classificação clínica e o ‘meconiumcrit’ para o <u>grau de classificação da coloração do mecônio</u>  
|Estudos|Número de mulheres com Líquido<br>Meconial|Proporção de mulheres em<br>cada categoria e grau de<br>concordância|
|---|---|---|
|Acordo entre a classific|ação clínica da coloração meconial  e c|álculo do ‘meconiumcrit’<sup>a</sup>|
|Trimmer & Gilstrap,<br>1991<sup>247</sup>|106|Tinto<br>Meconiumcrit: 61/106 (58%)<br>Classificação Clínica: 58/106<br>(55%)<br>Moderada<br>Meconiumcrit: 36/106 (34%)<br>Classificação Clínica: 38/106<br>(36%)<br>Espesso<br>Meconiumcrit: 9/106 (8%)<br>Classificação Clínica: 10/106<br>(9%)<br>Spearman's p=1.00<br>Pearson's r=0.997<br>p=0.047|  
a. O Meconiumcrit foi mensurado pela  divisão do volume de sólido pelo volume total e classificado como tinto (<10%), moderado (10% - 30%) ou espesso (30%). Os pontos de corte foram selecionados arbitrariamente antes do início do estudo. Critérios para a classificação clínica não foram fornecidos.  
Tabela 19 – Resumo para comparação de sistema de escore verso nenhum sistema de escore como parte do cuidado de recém-nascidos com líquido meconial  
|Estudos<br>Número de|mulheres ou fetos|E|feito|
|---|---|---|---|
|Escore<sup>a</sup><br>Mortalidade Neonatal|Controle<sup>b</sup>|Risco Relativo<br>(IC 95%)|Absoluto (IC 95%)|
|Morad et al.,<br>1998<sup>246</sup><br>0/80<br>(0%)|0/100<br>(0%)|Não Calculável<br>(NC)|NC|
|Intubação Neonatal||||
|Morad et al.,<br>1998<sup>246</sup><br>18/80<br>(22,5%)|30/100<br>(30%)|RR 0,75<br>(0,45 a 1,24)|Menos 75 por<br>1.000<br>(entre menos 165<br>a mais 72)|  
Síndrome de Aspiração de Mecônio  
Tabela 19 – Resumo para comparação de sistema de escore verso nenhum sistema de escore como parte do cuidado de recém-nascidos com líquido meconial  
|Estudos|Número de|mulheres ou fetos|E|feito|
|---|---|---|---|---|
||Escore<sup>a</sup>|Controle<sup>b</sup>|Risco Relativo<br>(IC 95%)|Absoluto (IC 95%)|
|Morad et al.,<br>1998<sup>246</sup><br>Síndrome de Aspir|4/80<br>(5%)<br>ação de Mecônio|6/100<br>(6%)<br> que requer Ventilaç|RR 0,83<br>(0,24 a 2,85)<br>ão|Menos 10 por<br>1.000<br>(entre menos 46<br>a mais 111)|
|Morad et al.,<br>1998<sup>246</sup>|2/80<br>(2,5%)|2/100<br>(2%)|RR 1,25<br>(0,18 a 8,68)|Mais 5 por 1.000<br>(entre menos 16|
|Tipo departo:part|o vaginal espont|âneo||a mais 154)|
|Morad et al.,<br>1998<sup>246</sup>|67/80<br>(83,8%)|89/100<br>(89%)|RR 0,94<br>(0,84 a 1,06)|Menos 53 por<br>1.000<br>(entre menos 142<br>a mais 53)|
|Tipo departo:part|o vaginal instrum|ental|||
|Morad et al.,<br>1998<sup>246</sup>|3/80<br>(3,8%)|5/100<br>(5%)|RR 0,75<br>(0,18 a 3,04)|Menos 13 por<br>1.000<br>(entre menos 41<br>a mais 102)|
|Tipo departo: ces|ariana||||
|Morad et al.,<br>1998<sup>246</sup>|9/80<br>(11,3%)|6/100<br>(6%)|RR 1,88<br>(0,7 a 5,05)|Mais 53 por 1.000<br>(entre menos 18<br>a mais 243)|  
CI intervalo de confiança, NC não calculável, RR risco relativo  
a. Os recém-nascidos receberam uma pontuação baseada na presença de sofrimento fetal durante o monitorização intraparto, se sucção orofaríngea foi realizada antes da primeira respiração, se mecônio foi tinto ou espesso, e a condição clínica do recém-nascido. O escore  de 0-1 indicou a necessidade de orofaríngea aspiração gentil e de curta duração. O escore de pelo menos 2 indica intubação e aspiração imediata das vias aéreas superiores e inferiores.  
b. A laringoscopia foi realizada em todos os recém-nascidos para visualização direta da glote e a aspiração endotraqueal foi realizada se houve mecônio nas cordas vocais.  
12.3.2 Resumo da evidência e conclusões  
O acerto médio intra-observador entre 20 Enfermeiras obstétricas/obstetrizes na classificação de 32 amostras de mecônio foi considerada como boa, mas variou de regular a muito boa dependendo da Enfermeira obstétrica/obstetriz. A concordância média das Enfermeiras obstétricas/obstetrizes com o padrão foi apenas moderada, e variou de pobre para boa. Houve bom acordo sobre a definição de líquido meconial tinto, mas 27% das amostras "espessas", 41% das amostras "leves" e 58% das amostras "moderadas" foram classificadas incorretamente pelas Enfermeiras obstétricas/obstetrizes, quando comparado com o padrão. Houve alta correlação (r = 0,997) entre a classificação da coloração de  
mecônio pela clínica e através do cálculo do 'meconiumcrit".  
Evidências de um estudo (n = 180) demonstrou que o uso de um escore na avaliação do líquido meconial não melhorou os resultados neonatais ou reduziu as taxas de cesariana e parto vaginal instrumental, quando comparado com o uso de nenhum escore.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.3.3 Outras Considerações -->
Em relação aos benefícios clínicos e danos de sistemas de gradação e classificação de mecônio em relação à morbidade e mortalidade materna e neonatal, a evidência analisada não fornece informações que pudessem ser traduzidas na prática clínica diária. O pequeno grau de concordância intra e interobservador para um sistema de escore do mecônio no estudo de van Heijst et al.<sup>248</sup> ,  particularmente nas categorias tinto e moderadas, não esclarece as controvérsias em relação à conduta na eliminação de mecônio. Da mesma forma, o estudo de Trimmer e Gilstrap<sup>247</sup> não apresenta evidências claras sobre a eficácia dos sistemas de escore de mecônio que pudesse ser traduzida para a clínica. Também o "Meconiumcrit” não é um sistema amplamente utilizado.  
Em relação aos benefícios para a saúde e usos de recursos, não há como avaliar o impacto dos sistemas de gradação e classificação de mecônio até então estudados, por não apresentarem evidências de benefícios clínicos.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.4.1 Evidências Científicas -->
A Drietriz do NICE incluiu na sua revisão uma revisão sistemática de 12 ensaios clínicos controlados e randomizados realizados em vários países<sup>249</sup> . Dois destes ensaios foram considerados para análise. Todos os estudos incluídos na revisão  avaliaram a eficácia do monitorização eletrônica contínua da frequência cardíaca fetal usando cardiotocografia (CTG) em comparação com ausculta intermitente. Dez dos estudos componentes da revisão sistemática tinha um pequeno número de casos de líquido meconial e não foi feita uma análise de subgrupo, logo não foram utilizados nesta avaliação. Os dois estudos restantes incluiu um maior número de mulheres com líquido meconial e são relatados para esta revisão. Os estudos foram realizados no Paquistão e em Melbourne. No estudo do Paquistão todas as mulheres tinham líquido meconial e apenas 40% tinha líquido meconial no estudo de Melbourne. Os dados sobre a eficácia da CTG contínua comparada com ausculta intermitente na presença de líquido meconial são sumarizados na tabela 20.  
Tabela 20 – Resumo para a comparação entre monitorização contínua da FCF com ausculta intermitente diante da presença de mecônio no trabalho de parto  
|Estudos|Número d|e mulheres|E|feito|
|---|---|---|---|---|
||Monitorização<br>contínua (CTG)|Ausculta<br>intermitente<br>(AI)|Risco Relativo<br>(IC 95%)|Absoluto (IC<br>95%)|
|Cesariana|||||
|1 meta-análise<br>com 2 estudos|74/275<br>(26,9%)|36/275<br>(13,1%)|RR 2,11<br>(1,19 a 3,74)|Mais 145 por<br>1.000|
|(Alfirevic et al.)<sup>249</sup>||||(entre mais 25 a<br>mais 359)|
|Cesarianapor alter|ações na FCF ou a|cidose|||
|1 meta-análise<br>com 2 estudos|47/275<br>(17,1%)|21/275<br>(7,6%)|RR 2,24<br>(1,38 a 3,64)|Mais 95 por<br>1.000|  
Tabela 20 – Resumo para a comparação entre monitorização contínua da FCF com ausculta intermitente diante da presença de mecônio no trabalho de parto  
|Estudos|Número d|e mulheres|E|feito|
|---|---|---|---|---|
||Monitorização<br>contínua (CTG)|Ausculta<br>intermitente<br>(AI)|Risco Relativo<br>(IC 95%)|Absoluto (IC<br>95%)|
|(Alfirevic et al.)||||(entre mais 29 a|
|||||mais 202)|
|Cesarianapor outr|a razão||||
|1 meta-análise<br>com 2 estudos|27/275<br>(9.8%)|15/275<br>(5,5%)|RR 1,80<br>(0,98 a 3,31)|Mais 43 por<br>1.000|
|(Alfirevic et al.)||||(entre menos 1|
|||||<br>a mais 125)|
|Parto vaginal instr|umentado||||
|1 meta-análise<br>com 2 estudos|108/275<br>(39,3%)|94/275<br>(34,2%)|RR 1,16<br>(0,88 a 1,54)|Mais 55 por 1.000<br>(menos 41 mais|
|(Alfirevic et al)||||185)|
|.<br>Parto vaginal espo|ntâneo não alcanç|ado|||
|1 metanálise com|182/275|130/275|RR 1,4|Mais 189 por|
|2 estudos<br>(Alfirevic et al.)|(66,2%)|(47,3%)|(1,2 a 1,63)|1.000<br>(entre mais 95 a|
|||||mais 295)|
|Mortalidadeperin|atal||||
|1 metanálise com<br>2 estudos|5/275<br>(1,8%)<sup>a</sup>|6/275<br>(2,2%)<sup>a</sup>|RR 0,83<br>(0,26 ao 2,67)|Menos 4 por<br>1.000|
|(Alfirevic et al.)||||(entre menos 16|
|||||<br>a mais 36)|
|Admissão na UTIN|||||
|1  estudo<br>(Alfirevic et al.)|11/175<br>(6,3%)|30/175<br>(17,1%)|RR 0,37<br>(0,19 a 0,71)|Menos 108 por<br>1.000|
|||||(entre menos 50|
|||||<br>a menos 139)|
|Convulsões neona|tais||||
|1  estudo|0/175|4/175|RR 0,11|Menos 20 por|
|(Alfirevic et al.)|(0%)|(2,3%)|(0,01 a 2,05)|1.000|
|Infecção ou dano|devidos ao eletrod|o ou da amostra|de sangue de couro|(menos 23 a mais<br>24)<br>cabeludo|
|1  estudo|1/100|0/100|RR 3|NC|
|(Alfirevic et al.)|(1%)|(0%)|(0,12 a 72,77)||  
IC intervalo de confiança, CTG cardiotocografia, AI ausculta intermitente, UTIN Unidade de Terapia Intensiva Neonatal, RR risco relativo, MFE monitorização fetal eletrônica.  
a. A taxa de mortalidade foi de 4,5% (4/100 em grupo MFE e 5/100 no grupo AI) em um estudo (Paquistão 1989) e 0,6% (1/175 em grupo MFE e 1/175 no grupo AI) em outro estudo (Melbourne, 1976). 89% do peso de meta-análise é a partir de um estudo (Paquistão 1989) .Os razões das mortes perinatais não são relatadas

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.4.2 Resumo da evidência e conclusões -->
As evidências demonstram que as mulheres submetidas a monitorização contínua tiveram menos chances de ter um parto vaginal espontâneo em relação às mulheres que receberam ausculta intermitente, sendo esta diferença explicada pelo índice de cesariana mais alto no grupo da monitorização contínua. Os resultados neonatais não mostraram diferenças significativas entre os dois grupos quanto à mortalidade perinatal (n=550) e incidência de convulsões neonatais, mas a incidência de admissão UTIN (n=350) foi maior no grupo de ausculta intermitente que no de monitorização contínua.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.4.3 Outras considerações -->
Considerando os benefícios clínicos e danos da monitorização eletrônica contínua comparada com a ausculta intermitente da frequência cardíaca fetal diante da eliminação de mecônio, a evidência não aponta diferenças na mortalidade e morbidade perinatal final, demonstrando um aumento nas intervenções como cesariana e parto vaginal instrumental e uma redução na admissão em UTIN. Considerando os benefícios para a saúde e uso de recursos no Brasil, a monitoração eletrônica contínua diante da eliminação de mecônio pode implicar uso significativo de recursos para a aquisição e manutenção de equipamentos, além de treinamento de pessoal na interpretação e conduta adequados diante dos traçados cardiotocográficos. Considerando benefícios clínicos apenas marginais, não se aconselha a utilização rotineira da monitoração eletrônica contínua da frequência cardíaca fetal diante da eliminação de mecônio no trabalho de parto no Brasil. A ausculta intermitente estruturada parece ser mais apropriada para a realidade brasileira.  
12.5 Amnioinfusão para a eliminação de mecônio no trabalho de parto  
12.5.1 Evidências Científicas  
A Drietriz do NICE incluiu na sua revisão uma revisão sistemática<sup>250</sup> com 13 ERCs de vários países (Estados Unidos da América [6 ensaios], África do Sul [2 ensaios], Índia [2 ensaios], Espanha [1 ensaio], Zimbábue [1 ensaio], multicêntrico [1 ensaio] e um ERC isolado realizado na Índia (Choudhary et al., 2010).<sup>251</sup>  
Todos os estudos incluídos compararam o uso ou não da amnioinfusão para a conduta na eliminação de mecônio durante o trabalho de parto. O nível de coloração do mecônio foi "mais do que um traço" em um estudo, “graus I, II e III” em outro estudo (tinto de mecônio até mecônio espesso), moderado a espesso em 7 ensaios e espesso em 5 ensaios. A amnioinfusão foi realizada com solução salina com uma infusão inicial de 500-1.000 ml ao longo de um período de 20 minutos a 1 hora (embora um estudo descreva uma infusão de 4 horas), normalmente seguido por manutenção com 2-3 ml por minuto. Outros métodos de reanimação intra-uterina para fetos com líquido meconial foram procurados, mas não foram identificados estudos relevantes.  
Um dos estudos relatados restringiu a sua população a mulheres "sem complicações pré-parto" e outro excluiu as mulheres com "condições clínicas ou cirúrgicas". O restante dos ensaios não se restringiu apenas a mulheres de baixo risco, mas alguns grupos de alto risco foram excluídos. Na revisão sistemática foi realizada uma análise de subgrupo para determinar se o estudo foi realizado em um ambiente com vigilância peri-parto padrão  (11 ensaios) ou de vigilância peri-parto limitada (2 ensaios).  
A tabela 21 abaixo apresenta a meta-análise de todos os estudos.  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de|mulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Com|Sem|Relativo (IC 95%)|Absoluto (IC 95%)|
||amnioinfusã|o<br>amnioinfusão<sup>a</sup>|||
|Mortalidade Perin|atal||||
|Todos os e|studos||||
|1 meta-análise|12/1.942|35/1.971|RR 0,35|Menos 12 por|
|de 10 ERCs|(0,62%)|(1,8%)|(0,18 a 0,66)|1.000 (entre|
|(Choudhary et<br>al., 2010;<br>Hofmeyr & Xu,<br>2010)<br>Estudos e|m ambientes co|m vigilânciaperi-p|artopadrão|menos 6 e  menos<br>15)|
|1 meta-análise|5/1.372|5/1.390|RR 1|Menos 0 por|
|com 7 ERCs|(0,36%)|(0,36%)|(0,29 a 3,45)|1.000 (entre|
|(Hofmeyr & Xu,||||menos 3 a menos|
|2010)||||9)|
|Estudos de|mulheres de b|aixo risco em amb|ientes com vigilância|peri-partopadrão|
|1 meta-análise<br>com 2 ERCs|0/77<br>(0%)||Não calculável<br>(NC)|NC|
|(Hofmeyr & Xu,|||||
|<br>2010)|||||
|Mortalidadeperin<br>Todos os e|atal ou morbid<br>studos|adegrave<sup>b</sup>|||
|1 ERC<br>|112/986<br>|99/989<br>|RR 1,13<br>|13 mais por 1.000<br>|
|(Hofmeyr & Xu,|(11,4%)|(10%)|(0,88 a 1,47)|(12 menos a 47|
|2010)<br>Estudos e|m ambientes co|m vigilânciaperi-p|artopadrão|mais)|
|1 ERC<br>(Hofmeyr & Xu,|112/986<br>(11,4%)|99/989<br>(10%)|RR 1,13<br>(0.88 to 1.47)|13 mais por 1000<br>(12 menos a 47|
|2010)||||mais)|
|Estudos de|mulheres de b|aixo risco em amb|ientes com vigilância|peri-partopadrão|
|0<br>Encefalopatia neo<br>Todos os e|Nenhuma ev<br>natal<br>studos|idência disponível|||
|1 meta-análise|1/350|16/359|RR 0,09|41 menos/1000|
|com 2 ERCs|(0,29%)|(4,5%)|(0,02 a 0,49)|(de 23 menos a 44|
|(Hofmeyr & Xu,||||menos|
|2010)|||||
|Estudos e|m ambientes co|m vigilânciaperi-p|artopadrão||
|1 ERC|0/30|2/30|RR 0,2|53 menos/1.000|  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de m|ulheres ou fetos|<br>Ef|eito|
|---|---|---|---|---|
||Com<br>amnioinfusão|<br>Sem<br>amnioinfusão<sup>a</sup>|Relativo (IC 95%)|Absoluto (IC 95%)|
|(Hofmeyr & Xu,|(0%)|(6,7%)|(0,01 a 4)|(de 66 menos a|
|2010)||||200 mais)|
|Estudos de|mulheres de b|aixo risco em am|bientes com vigilânci|aperi-partopadrão|
|1 ERC|0/30|2/30|RR 0,2|53 menos/1.000|
|(Hofmeyr & Xu,|(0%)|(6,7%)|(0,01 a 4)|(de 66 menos a|
|2010)||||200 mais)|
|Síndrome da Aspi<br>Todos os E<br>|ração do Mecôn<br>studos<br>|io<br>|||
|1 metanálise<br>com 14 ERCs<br>(Choudhary et<br>al., 2010;<br>Hofmeyr & Xu,<br>2010)<br>Estudos e|72/2.241<br>(3,2%)<br>m ambientes co<br>|150/2.277<br>(6,6%)<br>m vigilânciaperi-<br>|RR 0,38<br>(0,19 a 0,76)<br>partopadrão|41 menos/1.000<br>(de 16 menos a 53<br>menos)<br>|
|1 metanálise<br>com 11 ERCs<br>|61/1.672<br>(3,6%)|84/1.702<br>(4,9%)|RR 0,52<br>(0,26 a 1,06)|24 menos/1.000<br>(de 37 menos a 3<br>|
|(Hofmeyr & Xu,||||mais)|
|<br>2010)|||||
|Estudos de|mulheres de b|aixo risco em am|bientes com vigilânci|aperi-partopadrão|
|1 metanálise|2/77|12/88|RR 0,19|110 menos/1.000|
|com 2 ERCs<br>|(2,6%)|(13,6%)|(0,04 a 0,83)|(de 23 menos a<br>|
|(Hofmeyr & Xu,||||131 menos)|
|2010)<br>Frequência Cardía<br>Todos os e|ca Fetalpadrão<br>studos|: desacelerações|variáveis||
|1 metanálise<br>com 5 ERC|328/1.050<br>(31,2%)|385/1.051<br>(36,6%)|RR 0,67<br>(0,47 a 0,96)|Menos 121 por<br>1.000 (de menos|
|(Hofmeyr & Xu,||||15 a menos 194)|
|2010)<br>Estudos e|m ambientes co|m vigilânciaperi-|partopadrão||
|1 metanálise|328/1.050|385/1.051|RR 0,67|Menos 121 por|
|com 5 ERC|(31,2%)|(36,6%)|(0,47 a 0,96)|1.000 (de menos|
|(Hofmeyr & Xu,||||15 a menos 194)|
|<br>2010)<br>Estudos de|mulheres de b<br>|aixo risco em am<br>|bientes com vigilânci|<br>aperi-partopadrão|
|1 ERC|2/47|10/58|RR 0,25|Menos 129 por|
|(Hofmeyr & Xu,|(4,3%)|(17,2%)|(0,06 a 1,07)|1.000(de menos|  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de|mulheres ou feto|s<br>E|feito|
|---|---|---|---|---|
||Com<br>amnioinfusã|o<br>Sem<br>amnioinfusão|<sup>a</sup><br>Relativo (IC 95%)|Absoluto (IC 95%)|
|2010)||||162 a mais 12)|
|Mecônio abaixo d<br>Todos os e<br>|as cordas vocai<br>studos<br>|s<br>|||
|1 metanálise<br>com 11 ERCs<br>|109/1.734<br>(6,3%)|282/1.764<br>(16%)|RR 0,32<br>(0,2 a 0,52)|menos 109 por<br>1.000 (de menos<br>|
|(Hofmeyr & Xu,||||77 a menos  128)|
|<br>2010)<br>Estudos e|m ambientes co|m vigilânciaperi|-partopadrão||
|1 meta-análise<br>com 10 ERCs|99/1.634<br>(6,1%)|258/1.664<br>(15,5%)|RR 0,31<br>(0,18 a 0,53)|menos 107 por<br>1.000 (de menos|
|(Hofmeyr & Xu,||||73 a menos 127)|
|2010)<br>Estudos d|e mulheres de b|aixo risco em am|bientes com vigilânci|aperi-partopadrão|
|1 ERC<br>(Hofmeyr & Xu,|2/47<br>(4,3%)|33/58<br>(56,9%)|RR 0,07<br>(0,02 a 0,3)|menos 529 por<br>1.000 (de  menos|
|2010)||||398 a  menos 558)|
|Mecônio Significa|tivo||||
|Todos os estudos|<br>||||
|1 meta-análise<br>com  2 ERCs<br>|1/65<br>(1,5%)|55/73<br>(75,3%)|RR 0,03<br>(0,01 a 0,15)|menos 731 por<br>1.000 (menos de<br>|
|(Hofmeyr & Xu,||||640 a  menos 746)|
|2010)<br>Estudos e<br>Todos os e<br>|m ambientes co<br>studos<br>|m vigilânciaperi<br>|-partopadrão||
|1 metanálise|1/65|55/73|RR 0,03|menos 731 por|
|com  2 ERCs|(1,5%)|(75,3%)|(0,01 a 0,15)|1.000 (menos de|
|(Hofmeyr & Xu,||||640 a  menos 746)|
|<br>2010)<br>Estudos d|e mulheres de b|aixo risco em am|bientes com vigilânci|<br>aperi-partopadrão|
|1 ERC|0/46|42/52|RR 0,01|menos 800 por|
|(Hofmeyr & Xu,|(0%)|(80,8%)|(0 a 0,21)|1000 (de menos|
|2010)||||638 a  menos 808)|
|Admissão<br>Todos os E|na unidade de<br>studos|cuidados intensiv|os neonatais ou venti|<br>lação mecânica|
|1 metanálise|54/651|112/674|RR 0,51|menos 81 por|
|com  5 ERCs|(8,3%)|(16,6%)|(0,38 a 0,68)|1000 (de menos 53|
|(Hofmeyr & Xu,<br>2010)||||a menos 103)|  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de|mulheres ou fetos|<br>Ef|eito|
|---|---|---|---|---|
||Com|Sem|Relativo (IC 95%)|Absoluto (IC 95%)|
||amnioinfusã|o<br>amnioinfusão<sup>a</sup>|||
|Estudos e<br>|m ambientes c<br>|om vigilânciaperi-<br>|partopadrão||
|1 metanálise|10/230|25/242|RR 0,45|menos 57 por|
|com 3 ERCs<br>|(4,3%)|(10,3%)|(0,23 a 0,9)|1000 (de menos<br>|
|(Hofmeyr & Xu,||||10 a  menos 80)|
|<br>2010)<br>Estudos de mulhe|res de baixo ri|sco em ambientes|com vigilânciaperi-p|<br>artopadrão|
|1 ERC|4/47|11/58|RR 0,45|Menos de 104 por|
|(Hofmeyr & Xu,|(8,5%)|(19%)|(0,15 a 1,32)|1000 (de menos|
|2010)||||161 a menos  61)|
|Valores dosgases<br>Todos os|do sangue do<br>Estudos<br>|cordão:pH da art<br>|éria umbilical <7,20||
|1 metanálise|188/903|226/885|RR 0,62|Menos 97 por|
|com 7 ERCs|(20,8%)|(25,5%)|(0,4 a 0,96)|1.000 (de menos|
|(Hofmeyr & Xu,||||10 a menos 153)|
|2010)<br>Estudos e|m ambientes c|om vigilânciaperi-|partopadrão||
|1 metanálise|188/903|226/885|RR 0,62|Menos 97 por|
|com 7 ERCs|(20,8%)|(25,5%)|(0,4 a 0,96)|1.000 (de menos|
|(Hofmeyr & Xu,||||10 a menos 153)|
|2010)<br>Estudos d|e mulheres de|baixo risco em am|bientes com vigilância|peri-partopadrão|
|1 ERC|4/45|12/50|RR 0,37|151 menos/1.000|
|(Hofmeyr & Xu,|(8,9%)|(24%)|(0,13 a 1,07)|(de 209 menos a|
|2010)||||17 mais)|
|Mortalidade Mat<br>Todos os Estudos|erna ou morbi<br>|dadegrave<sup>c</sup>|||
|1 ERC|15/986|15/989|RR 1|Menos zero por|
|(Hofmeyr & Xu,|(1,5%)|(1,5%)|(0,49 a 2,04)|1.000( menos 8 a|
|2010)||||mais 16)|
|Estudos e|m ambientes c|om vigilânciaperi-|partopadrão||
|1 ERC|15/986|15/989|RR 1|0 menos por 1.000|
|(Hofmeyr & Xu,|(1,5%)|(1,5%)|(0,49 a 2,04)|(menos 8 a mais|
|2010)||||16)|
|Estudos d|e mulheres de|baixo risco em am|bientes com vigilância|peri-partopadrão|
|0|Sem evidênc|ias|||
|Tipo departo: ce<br>|sarianaporqu<br>|alquer indicação|||
|Todos os|estudos||||
|1 metanálise|577/2245|682/2272|RR 0,72|Menos 84por|  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de|mulheres ou feto|s<br>E|feito|
|---|---|---|---|---|
||Com<br>amnioinfusã|o<br>Sem<br>amnioinfusão|<sup>a</sup><br>Relativo (IC 95%)|Absoluto (IC 95%)|
|com 14 ERCs<br>(Choudhary et<br>al., 2010;<br>Hofmeyr & Xu,<br>2010)|(25,7%)|(30%)|(0,56 a 0,93)|1.000 (de menos<br>21 a menos 132)|
|Estudos e|m ambientes co|m vigilânciaperi|-partopadrão||
|1 metanálise<br>com 11 ERCs<br>(Hofmeyr & Xu,|483/1682<br>(28,7%)|516/1698<br>(30,4%)|RR 0,78<br>(0,6 a 1,02)|Menos de 67 por<br>1.000 (de menos<br>122 a mais de 87)|
|2010)<br>Estudos d|e mulheres de b|aixo risco em am|bientes com vigilânci|aperi-partopadrão|
|1 metanálise<br>com  2 ERCs<br>|26/77<br>(33,8%)|25/88<br>(28,4%)|RR 1,15<br>(0,74 a 1,80)|Mais 43 por 1.000<br>(de menos 74 a<br>|
|(Hofmeyr & Xu,||||mais 227)|
|2010)|||||
|Tipo departo: ce<br>Todos os<br>|sarianapor sofr<br>estudos<br>|imento fetal<br>|||
|1 metanálise<br>com 11 ERCs<br>(Choudhary et<br>al., 2010;<br>Hofmeyr & Xu,<br>2010)<br>Estudos e|196/1.943<br>(10,1%)<br>m ambientes co<br>|295/1.969<br>(15%)<br>m vigilânciaperi<br>|RR 0,42<br>(0,25 a 0,73)<br>-partopadrão|Menos 87 por<br>1000 (de menos 40<br>a menos 112)|
|1 metanálise<br>com 8 ERCs|151/1.376<br>(11%)|174/1.389<br>(12,5%)|RR 0,4<br>(0,19 a 0,86)|Menos 75 por<br>1000 (de menos 18|
|(Hofmeyr & Xu,||||a menos 101)|
|<br>2010)<br>Estudos d|e mulheres de b|aixo risco em am|bientes com vigilânci|<br>aperi-partopadrão|
|1 metanálise|4/77|12/88|RR 0,36|Menos 87 por 1000|
|com 2 ERCs|(5,2%)|(13,6%)|(0,12 a 1,05)|(de menos 120 a|
|(Hofmeyr & Xu,||||mais 7)|
|<br>2010)<br>Tipo departo:pa<br>|rto vaginal instr<br>|umentalporqua|lquer indicação||
|Todos os estudos|||||
|1 metanálise|63/1.021|95/1.038|RR 0,68|Menos 29 por|
|com 9 ERCs<br>(Choudharyet|(6,2%)|(9,2%)|(0,5 a 0,91)|1.000 (de menos 8<br>a menos 46)|  
Tabela 21 – Amnioinfusão versus nenhuma amnioinfusão para a eliminação de mecônio no trabalho de parto  
|Estudos|Número de|mulheres ou fet|os<br>Ef|eito|
|---|---|---|---|---|
||Com<br>amnioinfusã|o<br>Sem<br>amnioinfusã|o<sup>a</sup><br>Relativo (IC 95%)|Absoluto (IC 95%)|
|al., 2010;<br>Hofmeyr & Xu,<br>2010)<br>Estudos e<br>|m ambientes co<br>|m vigilânciaper<br>|i-partopadrão<br>||
|1 metanálise<br>com 6 ERCs|45/455<br>(9,9%)|63/459<br>(13,7%)|RR 0,73<br>(0,51 a 1,04)|Menos 37 por<br>1.000 (de menos|
|(Hofmeyr & Xu,||||67 a mais 5)|
|2010)|||||
|Estudos d|e mulheres de b|aixo risco em a|mbientes com vigilância|peri-partopadrão|
|1 metanálise<br>com 2 ERCs|2/77<br>(2,6%)|10/88<br>(11,4%)|RR 0,25<br>(0,06 a 1,07)|Menos 85 por<br>1.000 (de menos|
|(Hofmeyr & Xu,||||107 a mais 8)|
|2010)<br>Tipo departo:par<br>Todos os e<br>|to vaginal instr<br>studos<br>|umentalpor sof<br>|rimento fetal||
|1 metanálise<br>com 3 ERCs<br>|60/1.136<br>(5,3%)|56/1.150<br>(4,9%)|RR 1,09<br>(0,76 a 1,55)|Mais 4 por 1000<br>(de menos 12 a<br>|
|(Hofmeyr & Xu,||||mais 27)|
|2010)<br>Estudos e|m ambientes co|m vigilânciaper|i-partopadrão||
|1 metanálise<br>com 3 ERCs|60/1.136<br>(5,3%)|56/1.150<br>(4,9%)|RR 1,09<br>(0,76 a 1,55)|Mais 4 por 1000<br>(de menos 12 a|
|(Hofmeyr & Xu,||||mais 27)|
|2010)<br>Estudos d|e mulheres de b|aixo risco em a|mbientes com vigilância|peri-partopadrão|
|1 ERC|1/47|5/58|RR 0,25|Menos 65 por|
|(Hofmeyr & Xu,|(2,1%)|(8,6%)|(0,3 a 2,04)|1000 (de menos|
|2010)||||84 a mais 90)|
|Tipo departo:par<br>Todos os e|to normal espo<br>studos|ntâneo|||
|1 ERC<br>|103/146<br>|46/146<br>|RR 2,24<br>|Mais 391 por 1000<br>|
|(Choudhary et|(70,5%)|(31,5%)|(1,72 a 2,91)|(de mais 227 a|
|al.,2010)<br>Estudos e|m ambientes co|m vigilânciaper|i-partopadrão|mais 502)|
|0|Não há evidê|ncia|||
|Estudos d<br>0|e mulheres de b<br>Não há evidê|aixo risco em a<br>ncia|mbientes com vigilância|peri-partopadrão|  
IC Intervalo de confiança; NC não calculável; RR risco relativo  
a. Poucos detalhes são informados sobre os grupos de controle, apenas que eles não receberam amnioinfusão ou receberam cuidados padrão  
b. Definido como a presença de pelo menos uma das seguintes opções: a morte perinatal, síndrome de aspiração de mecônio moderada ou grave, hipotonia, ventilação ou intubação assistida de duração superior a cinco minutos, índice de Apgar <7 no 5 minuto, pH artéria do cordão umbilical <7,05, consciência anormal, necessidade de alimentação por sonda, convulsões, sangue ou cultura lombar positiva para bactérias, traumatismo grave incluindo fratura de crânio basal ou de ossos longos, lesão da medula espinhal, e facial ou paralisia braquial  
c. Definido como a presença de qualquer dos seguintes: ruptura uterina, embolia amniótica, hemorragia anteparto precisando parto precipitado, hemorragia pós-parto necessitando de transfusão (isso ocorreu em 11 [1,1%] mulheres em cada braço do estudo), a histerectomia, a admissão na unidade intensiva de cuidados, ou coagulação intravascular disseminada  
12.5.2 Resumo da evidência e conclusões  
As evidências demonstraram que a amnioinfusão pode reduzir as taxas de mortalidade perinatal (n = 3.913) e encefalopatia neonatal (n = 709) no geral, benefícios estes não demonstrados em ambientes com vigilância peri-parto padrão. Houve evidência consistente de redução de mecônio abaixo das cordas vocais (n = 3.498) e coloração significativa de mecônio  (n = 138) embora em relação à redução da síndrome de aspiração meconial (n = 4.518) os achados foram mistos. Na meta-análise de dois estudos de mulheres de baixo risco (n = 138), em ambientes com vigilância peri-parto padrão, demonstrou-se uma redução na síndrome de aspiração meconial, assim como na meta-análise geral. Entretanto, na meta-análise de 11 estudos (n = 3374) em ambientes com vigilância peri-parto padrão esse efeito não foi demonstrado.  
Em relação à admissão em unidade de terapia intensiva, ventilação neonatal (n = 1.325), pH arterial baixo no nascimento (n = 1758) e a ocorrência de desacelerações variáveis (n = 2.101), demonstrou-se uma redução significativa na análise do grupo geral e também no subgrupo de estudos com vigilância peri-parto padrão, mas não nos estudos de mulheres de baixo risco.  
A evidência em torno do tipo de parto também foi mista. Houve alguma evidência de que as taxas de parto vaginal instrumental (n = 2.059) e cesariana (n = 4.517) foram reduzidas com o uso da amnioinfusão, mas não houve efeito quando a análise foi restrita a ambientes com vigilância peri-parto padrão.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 12.5.3 Outras considerações -->
Considerando os resultados, como a morte neonatal, síndrome de aspiração de mecônio, internação em unidade de terapia intensiva neonatal (UTIN) e redução de parto operatório (cesariana e parto vaginal instrumental) a amnioinfusão pode oferecer benefícios clínicos em relação aos danos. Houve uma redução significativa da mortalidade perinatal demonstrada na meta-análise geral, sendo que o único estudo que mostra um efeito significativo foi o de Choudhary et al. (2010)<sup>251</sup> , realizado na Índia, que tinha uma taxa de mortalidade de 11% no grupo controle. Não foi demonstrada redução similar na mortalidade na análise de subgrupo de estudos realizados em ambientes com vigilância peri-parto padrão. Observou-se também que o efeito da amnioinfusão no desfectho composto de mortalidade perinatal e morbidade grave foi demonstrado no maior estudo incluído na meta-análise. Considerando a realidade brasileira, onde em muitos lugares ainda existe uma carência de assistência peri-parto padrão, a amnioinfusão deve ser considerada diante da eliminação de mecônio moderado a espesso durante o trabalho de parto. Por esse motivo, o grupo elaborador destas Diretrizes adaptadas decidiu pela  
modificação das recomendações das diretrizes-fonte.  
Considerando os benefícios à saúde e usos de recursos no Brasil, a amnioinfusão requer recursos de pessoal e de equipamentos que devem ser levados em consideração quando da sua utilização. Tendo em vista a realidade brasileira e os bons resultados demonstrados nos estudos realizados em ambientes carentes de assistência peri-parto padrão, além da simplicidade dos insumos utilizados para a amnioinfusão, a mesma deve ser considerada.  
12.6 Cesariana para eliminação de mecônio durante o trabalho de parto  
Nenhuma das diretrizes consultadas abordou a questão da cesariana para a conduta na eliminação de mecônio durante o trabalho de parto.  
12.7 Recomendações em relação a eliminação de mecônio durante o trabalho de parto  
85. Não se aconselha o uso de sistemas de gradação e classificação de mecônio ante a eliminação de mecônio imediatamente antes ou durante o trabalho de parto, exceto quando se considerar a amnioinfusão ou como critério de transferência. Ver recomendações 87,96 e 97;  
86. Tanto a monitoração eletrônica contínua da frequência cardíaca fetal, se disponível, como a ausculta fetal intermitente, seguindo técnicas padronizadas, podem ser utilizadas para avaliação do bemestar fetal diante da eliminação de mecônio durante o trabalho de parto;  
87. Considerar a realização de amnioinfusão diante da eliminação de mecônio moderado a espesso durante o trabalho de parto se não houver disponibilidade de monitoração eletrônica fetal contínua;  
88. Não existem evidências para recomendar ou não recomendar a cesariana apenas pela eliminação isolada de mecônio durante o trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.1 Introdução -->
A assistência qualificada durante o trabalho de parto é fundamental para que os melhores resultados sejam alcançados para a mãe e para a criança, tanto do ponto de vista físico como emocional. Para se atingir tais objetivos é necessário que as atitudes, medidas e intervenções adotadas pelos profissionais de assistência sejam baseadas nas melhores evidências disponíveis. Esta seção aborda a conduta adequada para a assistência no primeiro período do trabalho de parto, identificando, analisando e resumindo as evidências científicas atuais a respeito dos temas em questão.  
13.2 Diagnóstico do trabalho de parto e momento de início da assistência  
13.2.1 Introdução  
Um dos aspectos fundamentais na assistência ao parto é definir qual o momento mais apropriado para se iniciar o cuidado no trabalho de parto, seja no ambiente extra-hospitalar, assim como intra– hospitalar. Essa definição é importante, pois caso a assistência não seja iniciada no momento oportuno, complicações que podem surgir nesse período não serão detectadas, podendo trazer resultados desfavoráveis para a mãe e para a criança. Por outro lado, o início da assistência muito precocemente pode sujeitar a mulher a intervenções desnecessárias e, consequentemente, as suas complicações. Por se tratar de um fenômeno humano complexo, com grandes variações individuais, o início do trabalho de parto não é tão facilmente identificável como possa parecer. A certeza de que uma mulher esteve em trabalho de parto só pode ser dada de maneira retrospectiva, com o nascimento da criança, desde que todo o processo tenha transcorrido espontaneamente.  
13.2.2 Questão de revisão  
 Como diagnosticar o início do trabalho de parto e qual o momento de admissão para assistência

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: ou para início da assistência profissional no domicílio? -->
Os desfechos considerados para essa questão foram: taxas de intervenções como uso de ocitocina, cesariana e uso de analgesia/anestesia, satisfação da mulher, parto sem assistência profissional, morbidade e mortalidade materna e perinatal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.2.3 Evidências científicas -->
As diretrizes do NICE de 2007<sup>11</sup> abordaram essa questão de maneira mais particular, que foi abordada na atualização de 2014 como parte de uma gama de intervenções para assistência à mulher no fase de latência do trabalho de parto. Foram analisados um ensaio randomizado controlado (ERC) realizado no Canadá [NE= 1-]. Outros dois estudos de coorte, um estudo transversal estadunidense [NE = 3] e outro ERC que avaliou o impacto do primeiro contato ser realizado em casa através da visita de uma Enfermeira obstétrica comparado a uma triagem realizada por telefone [NE = 1].  
O ERC Canadense envolveu 209 mulheres que foram alocadas em dois grupos: avaliação precoce do trabalho de parto (fase ativa ou fase de latência ou admissão direta no hospital)<sup>252</sup> . As mulheres que não estavam na fase ativa do trabalho de parto foram encorajadas e aconselhadas a retornarem às suas casas ou deambularem fora do hospital até o trabalho de parto se tornar mais ativo. As mulheres que tiveram a sua internação retardada para a fase ativa tiveram menos uso de ocitocina (OR 0,44 [IC 95% 0,24 a 0,80]) e analgesia/anestesia (OR 0,36 [IC 95% 0,16 a 0,78]) e maior satisfação com a assistência recebida (P = 0,001). Não houve diferenças nos desfechos neonatais tendo em vista o tamanho pequeno da amostra.  
Um estudo de coorte canadense (n = 3.220) avaliou os resultados das mulheres que foram admitidas com 3 cm ou menos de dilatação cervical, com aquelas que foram admitidas com 4 ou mais cm<sup>253</sup> [NE = 2−]. As mulheres admitidas precocemente tiveram uma trabalho de parto mais longo (DM 3,10 hours, P < 0,001), maior uso de ocitocina (RR 1,58, P < 0,001) e uma maior taxa de cesariana (RR 2,45, P = 0,001). Outro estudo de coorte canadense (n = 3.485) comparou os resultados de dois grupos de mulheres de baixo risco sob os cuidados de médicos de família. Em um grupo 50% ou mais das mulheres foram admitidas com 3 cm ou menos de dilatação cervical e no outro grupo menos de 50% das mulheres foram admitidas precocmente<sup>254</sup> [NE = 2−]. No grupo cujas mulheres foram admitidas precocemente ocorreram maiores taxas de peridural (OR 1,34 [IC 95% 1,15 a 1,55]), cesariana (OR 1,33 [IC 95% 1,00 a 1,65] e monitoração eletrônica fetal (OR 1,55 [IC 95% 1,27 a 1,89]).  
O estudo transversal americano (n = 8818) comparou os desfechos intraparto naquelas mulheres que foram admitidas na fase ativa do trabalho de parto com aquelas admitidas na fase de latência<sup>255</sup> [NE = 3]. As admitidas na fase de latência tiveram mais parada de progressão no parto (OR 2,2 [IC 95% 1,6 a 2,6]), uso de ocitocina (OR 2,3 [IC 95% 2,1 a 2,6]), peridural (OR 2,2 [IC 95% 2,0 a 2,4]) intubação do recémnascido (OR 1,2 [IC 95% 1,0 a 1,4]), amnionite (OR 2,7 [IC 95% 1,5 a 4,7]) e infecção puerperal (OR 1,7 [IC 95% 1,0 a 2,9]).  
Um ERC investigou os desfechos de mulheres no início do trabalho de parto que receberam uma visita domiciliar de uma Enfermeira obstétrica (n = 117) comparadas com outras que receberam uma triagem por telefone (n = 120)<sup>461</sup> [NE = 1−]. As mulheres que receberam a visita tiveram menos analgesia opióide (OR 0,55 [IC 95% 0,32 a 0,96]) e menos recém-nascidos admitidos em unidades neonatais (OR 0,13 [IC 95% 0,03 a 0,60]) sem outras diferenças significativas, incluindo custos.  
13.2.4 Resumo da evidência e conclusões  
As evidências em relação ao momento de internação ou início para assistência no trabalho de parto são limitadas mas apontam que retardar a admissão das mulheres para a fase ativa do trabalho de parto  
reduz intervenções, com possível redução de morbidade materna e neonatal. 13.2.5 Outras considerações  
Em relação aos benefícios clínicos e danos das intervenções avaliadas, medidas que retardem a admissão das mulheres nas maternidades diminuem as taxas de intervenções e também o tempo entre a internação e o parto e, consequentemente, as suas complicações. Entretanto, tais medidas devem ser avaliadas com cuidado quando se trata de casos individuais. O tempo de deslocamento de casa para a maternidade deve ser levado em consideração quando se for aconselhar uma mulher a voltar para casa na fase de latência do trabalho de parto. Em relação à mortalidade materna e perinatal as evidências foram insuficientes para demonstrar diferenças.  
Em relação aos benefícios para a saúde e utilização de recursos, a admissão de mulheres nas maternidades apenas na fase ativa do trabalho de parto pode reduzir custos, tendo em vista um menor número de intervenções e também um tempo menor desde a internação até o parto e, em consequência, uma menor utilização de recursos materiais e humanos. Em relação à visita domiciliar de uma Enfermeira obstétrica antes da admissão na maternidade, deve-se levar em consideração os custos de deslocamento desse profissional, além do tempo de sua permanência no domicílio prestando cuidados individuais, afastando-o das atividades na maternidade onde poderia estar cuidando de um número maior de mulheres.  
As diretrizes consultadas não abordaram o momento adequado para o início da assistência profissional no domicílio mas as evidências disponíveis podem oferecer uma referência para tal, por analogia. 13.2.6 Recomendações sobre diagnóstico do trabalho de parto e momento para admissão e início da assistência  
89. Incluir o seguinte quando da avaliação precoce ou triagem de trabalho de parto em qualquer local de assistência:  
- Indagar à mulher como ela está e sobre os seus desejos, expectativas e preocupações.  
- Indagar sobre os movimentos da criança, incluindo qualquer mudança nos mesmos.  
- Oferecer informações sobre o que a mulher pode esperar na fase de latência do trabalho de parto e o que fazer se sentir dor.  
- Oferecer informações sobre o que esperar quando procurar assistência.  
- Estabelecer um plano de cuidados com a mulher, incluindo orientação de quando e  com quem contatar posteriormente.  
- Oferecer orientação e apoio para o(s) acompanhante(s) da mulher.  
90. Se uma mulher busca orientação ou assistência em uma maternidade ou unidade de parto extra, peri ou intra-hospitalar:  
- E não está em trabalho de parto estabelecido (≤ 3 cm de dilatação cervical):  
- Ter em mente que a mulher pode estar tendo contrações dolorosas, sem mudanças cervicais, e embora ainda não esteja em trabalho de parto ativo, ela pode sentir que está pela sua própria definição.  
- Oferecer apoio individual e alívio da dor se necessário.  
- Encorajar e aconselhar a mulher a permanecer ou retornar para casa, levando em consideração as suas preocupações, a distância entre a sua casa e o local do parto e o risco deste acontecer sem assistência.  
- Está em trabalho de parto estabelecido (≥ 4 cm de dilatação cervical)  
- Admitir para assistência

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.3.1 Introdução -->
Embora seja um processo contínuo, a divisão do trabalho de parto em fases pode ser apropriada para facilitar a comunicação entre os membros da equipe assistencial e também com a mulher, permitindo uma maior compreensão dos conceitos e facilitando uma atuação mais coesa e padronizada. Em relação à sua duração, uma definição seria muito mais apropriada às máquinas do que a seres humanos. Entretanto, o estabelecimento de algumas fronteiras que possam alertar para desvios da normalidade podem ser úteis para informar os cuidadores e as mulheres sobre o que esperar. Também pode servir de orientação para a transferência para níveis mais complexos de assistência, caso seja necessário. 13.3.2 Questões de revisão  
- Qual a definição das fases do primeiro período do parto?  
- A duração e progresso do primeiro período do parto influencia nos resultados?  
- 13.3.3 Evidências científicas  
13.3.3.1 Definição das fases do trabalho de parto  
As diretrizes do NICE de 2014 não incluíram nenhum estudo relevante que tenha investigado os desfechos relacionados com as diferentes definições de trabalho de parto. Várias definições que são utilizadas na prática ou na pesquisa foram exploradas. Seis estudos descritivos, investigando a duração do trabalho de parto, foram utilizados para informar sobre as definições do trabalho de parto.  
As definições do início do trabalho de parto pode envolver o início de contrações<sup>256-259</sup> , modificações cervicais<sup>260</sup> ou ambos. Enquanto a consideração sobre as contrações isoladamente na definição do início do trabalho de parto pode caber também às próprias mulheres, as modificações cervicais depende da confirmação de um profissional. Na prática e na literatura, uma fase latente ou precoce do trabalho de parto é reconhecida e definida como uma dilatação cervical de 0-2 cm<sup>258</sup> e 0-4cm<sup>261-263</sup> e é caracterizada por uma velocidade lenta da dilatação e apagamento cervical, com contrações irregulares em intensidade e frequência. Esta fase é seguida pela fase ativa. Novamente, esta fase só pode ser definida pela dilatação cervical, ex. 2-10 cm<sup>258</sup> ou 4-10 cm<sup>261-263</sup> , incluindo aí a experiência da mulher, ou seja, o início de contrações regulares até o momento em que a mulher sinta desejo de fazer força, na dilatação completa<sup>259</sup> .  
13.3.3.2 Recomendações sobre as definições das fases do primeiro período do trabalho de parto  
91. Para fins destas Diretrizes, utilizar as seguintes definições de trabalho de parto:  
- Fase de latência do primeiro período do trabalho de parto – um período não necessariamente contínuo quando:  
`o` há contrações uterinas dolorosas E  
`o` há alguma modificação cervical, incluindo apagamento e dilatação até 4 cm.  
- Trabalho de parto estabelecido – quando:  
`o` há contrações uterinas regulares E  
`o` há dilatação cervical progressiva a partir dos 4 cm.  
13.3.3.3 Duração das fases do primeiro período do trabalho de parto  
As diretrizes do NICE 2014 incluíram uma série de estudos, com metodologia variada, na sua revisão. Um estudo transversal realizado nos EUA (n = 10.979) investigou a fase de latência prolongada e os resultados intraparto<sup>257</sup> [NE = 3] demonstrando alguma evidência de associação entre uma fase de latência prolongada (definida como mais de 12 horas em nulíparas e mais de 6 horas em multíparas com maiores taxas de cesariana (RR 1,65 [IC 95%  1,32 a 2,06]), aumento da necessidade de ressuscitação  
neonatal (RR 1,37 [IC 95% 1,15 a 1,64]) e aumento na incidência de Apgar < 7 aos 5 minutos (RR 1,97 [IC 95% 1,23 a 3,16]).  
Outro estudo transversal americano (n = 30) não encontrou evidência de associação entre a duração do primeiro período do trabalho de parto (3-10 cm de dilatação) e escore de ansiedade materna<sup>264</sup> [NE = 3] Outros três estudos não especificaram o estágio do trabalho de parto. Um pequeno estudo casocontrole pareado (n = 34) conduzido no Reino Unido demonstrou alguma evidência de maior duração do trabalho de parto associada à psicose puerperal (DM 4,6 horas, P < 0.05)<sup>265</sup> [NE = 2−]. Um estudo transversal estadunidense (n = 198) que usou controles pareados pela idade, paridade e peso ao nascer demonstrou que trabalho de parto curto (menos de 3 horas de primeiro e segundo estágio) não se associou com lacerações perineais de terceiro e quarto grau (RR 0,5 P = NS), hemorragia pós-parto (RR 0,72 P = NS) ou escore de Apgar < 7 aos 5 minutos (RR 1,5 P = NS)<sup>266</sup> [NE = 3].  
Outro estudo caso-controle aninhado realizado nos EUA demonstrou que o trabalho de parto prolongado esteve associado com complicações maternas intraparto (RR 12,5 [IC 95% 4,94 a 23,38 para mulheres que tiveram parto vaginal]; RR 28,89 [IC 95% 20,00 a 39,43 para mulheres que tiveram cesariana])<sup>267</sup> [NE = 2−]  
13.3.3.4 Fatores associados à duração do trabalho de parto  
Em um estudo observacional realizado na Alemanha (n = 932)<sup>259</sup> , a duração média do primeiro período do trabalho de parto, excluindo mulheres definidas como tendo trabalho de parto “prolongado” pelos limites superiores, foi de 7,3 horas para nulíparas (de 1,0 a 17,0 horas e 3,9 horas (de 0,5 a 12,0 horas) para as multíparas. Após controle para variáveis de confusão, demonstrou-se que as multíparas tinham primeiros períodos mais curtos do que as nulíparas, mas nenhuma outra variável demográfica esteve associada com a duração do primeiro período do trabalho de parto (a etnia não foi considerada). Um intervalo mais curto entre o início do trabalho de parto e início dos cuidados da enfermeira obstétrica ou obstetriz esteve associado com uma menor duração do primeiro período do trabalho de parto, efeito mais pronunciado, especialmente nas multíparas, se as membranas se romperam no início dos cuidados. Um estudo estadunidense envolvendo 1.162 nulíparas demonstrou uma duração média do primeiro período do trabalho de parto de 7,3 horas (p10 = 3,3 horas e p90 = 13,7 horas)<sup>263</sup> . Em outro estudo, também realizado nos EUA, envolvendo 2.511 mulheres<sup>262</sup> , a duração média da fase ativa do trabalho de parto, com os seus limites superiores (dois desvios padrão) foi de 7,7 e 17,5 horas para as nulíparas e de 5,6 e 13,8 horas para as multíparas. Após controle de variáveis de confusão ficou demonstrado que a monitoração fetal eletrônica contínua e a deambulação no trabalho de parto estiveram significativamente associados com trabalhos de parto mais prolongados. A analgesia com narcóticos esteve significativamente associada com trabalhos de parto mais longos nas multíparas. Os achados demonstraram apenas associação e não causalidade.  
Em um estudo realizado nos EUA envolvendo 1.473 mulheres, agrupadas por etnia (brancas não Hispânicas, Hispânicas e índias Americanas)<sup>261</sup> a duração média e limites superiores (dois desvios padrão) do primeiro período do trabalho de parto foi de 7,7 e 19,4 horas para s nulíparas e 5,7 e 13,7 horas para as multíparas. Não houve achados com diferenças estatísticas entre os grupos étnicos.  
Em uma análise secundária de dados de nascimentos nos EUA coletados de 1976 a 1987 foi descrita a duração do trabalho de parto em 6.911 mulheres a termo que tiveram parto normal e não utilizaram ocitocina, a duração média e limites superiores (p95) da fase ativa do trabalho de parto foi o seguinte: nulíparas sem analgesia de condução 8,1 horas (16,6 horas); com analgesia 10,2 horas (19,0 horas); multíparas sem analgesia 5,7 horas (12,5 horas) e com analgesia 7,4 horas (14,9 horas).  
Um pequeno estudo estadunidense envolvendo 100 nulíparas demonstrou que a fase latente do trabalho de parto durou de 1,7 a 15,0 horas, média de 7,3 horas (DP = 5,5 horas) e a fase ativa durou de 1,8 a 9,5 horas, com uma média de 4,4 horas (DP = 1,9 horas) (279). A amostra foi muito misturada e incluiu um parto pélvico, um par de gêmeos, quatro induções e apenas 29 partos espontâneos<sup>258</sup> .  
Um estudo observacional realizado no Reino Unido descreveu o progresso do trabalho de parto para 403 multíparas que deram à luz em uma unidade conduzida por Enfermeiras obstétricas/obstetrizes, mostrando que a taxa média de dilatação cervical foi de 2,9 cm/hora com uma mediana de 1,9 cm/hora (p10 = 0,7 cm/hora; p5=0,5 cm/hora). Para as mulheres incluídas no estudo com menos de 4 cm de dilatação cervical, as taxas de dilatação cervical tenderam a aumentar no transcorrer do tempo. Vários perfis individuais demonstraram períodos de nenhum progresso seguido por progresso. Tomando uma dilatação cervical de 4 cm como o início da fase ativa do trabalho de parto e utilizando a média da taxa de dilatação, isto daria uma média de duração da fase ativa do trabalho de parto de 3 horas e 9 minutos. Utilizando o percentil 10 como limite superior, isto extrapolaria para uma duração da fase ativa do trabalho de parto para 13 horas.<sup>268</sup>  
Reunindo os achados dos estudos resumidos acima, a variação dos limites superiores de duração do trabalho de parto normal são de 8,2 a 19,4 horas para as nulíparas e de 12,5 a 14,9 horas para as multíparas (tabela 22). Entretanto, estes números são questionáveis, já que incluem cálculos baseados em desvios padrão, que assumem uma distribuição normal, o que não é o caso quando se considera a duração do trabalho de parto.  
Tabela 22: Tabela resumindo a variação da duração dos estágios do trabalho de parto  
|||Limite inferior|Limite superior|
|---|---|---|---|
|Nulíparas|Fase de latência|1,7 horas|15,0 horas|
||Fase ativa|1,0 hora|19,4 horas|
||Fase de latência|Não estudada|Não estudada|
|Multíparas|Fase ativa|0,5 hora|14,9 horas|  
N = 6 estudos descritivos incluindo mulheres com analgesia peridural  
13.3.4 Conclusões  
A duração do trabalho de parto apresenta grandes variações individuais, sendo influenciada principalmente pela paridade, e o progresso não é linear. A maioria das primíparas em trabalho de parto ativo atingirão o segundo período do parto dentro de 18 horas sem intervenções e as multíparas em 12 horas.  
- 13.3.5 Recomendações sobre a duração do trabalho de parto  
92. A duração do trabalho de parto ativo pode variar:  
- Nas primíparas dura em média 8 horas e é pouco provável que dure mais que 18 horas.  
- Nas multíparas dura em média 5 horas e é pouco provável que dure mais que 12 horas.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.4.1 Introdução -->
Um dos principais objetivos da assistência profissional no parto é avaliar o bem-estar e necessidades da mulher, o bem-estar fetal e o progresso do parto. Para isso uma série de observações são realizadas, visando também detectar problemas que possam exigir alguma ação no sentido de corrigi-las. A observação também é importante para se determinar o momento em que a mulher deve ser transferida para níveis mais complexos de assistência, dependendo do local da assistência. Embora já bastante estabelecidas na prática cotidiana, os benefícios que tais observações podem trazer em relação aos desfechos maternos e perinatais ainda não são conhecidos à luz das evidências.  
13.4.2 Questões de revisão  
- Qual a efetividade, segurança e custo-efetividade e freqüência da monitoração rotineira dos dados vitais e da função vesical durante o trabalho de parto?  
- Qual a efetividade, segurança e custo-efetividade e frequência da avaliação da atividade uterina e de toques vaginais durante o trabalho de parto?  
- Qual a efetividade, segurança e custo-efetividade do uso do partograma e seus diferentes modelos?  
- Quais são as indicações de transferência de parturientes, puérperas ou recém-nascidos para níveis mais complexos de assistência?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.4.3.1 Dados vitais e função vesical -->
As diretrizes do NICE 2014 abordaram essas questões mas não encontrou estudos relevantes que avaliassem o impacto da monitoração rotineira dos dados vitais e da função vesical durante o trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.4.3.2 Avaliação da atividade uterina e exames vaginais -->
Também não foram encontrados estudos que avaliassem a freqüência de avaliação da atividade uterina nos desfechos maternos e perinatais. Em relação aos exames vaginais as diretrizes incluíram na sua revisão um ERC realizado no Reino Unido (n=109) [NE = 1-]<sup>269</sup> que avaliou o impacto da sua realização a cada 2 ou 4 horas e não encontrou diferenças na duração do trabalho de parto, embora o estudo também tenha demonstrado que o número de exames vaginais foi o mesmo em ambos os grupos. Outro estudo caso-controle realizado na Suécia (n=68) [NE = 2-]<sup>270</sup> avaliou quais fatores poderiam estar associados com a sepse neonatal e, entre sete variáveis consideradas como possíveis preditores de sepse, incluindo os exames vaginais, nenhuma foi confirmada como tal. Entretanto, outro estudo demonstrou que, na presença de ruptura de membranas, o número de exames vaginais esteve associado com a sepse neonatal [NE = 2++]<sup>271</sup> .

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.4.3.3 Partograma -->
A forma como as observações maternas e fetais são registradas durante o trabalho de parto é muito variável, dependendo dos serviços, indo desde anotações comuns nas folhas de evolução até registros em gráficos chamados partogramas, onde são registrados a dilatação cervical, a atividade uterina, a descida da apresentação, a freqüência cardíaca fetal e também os dados vitais. Diferentes modelos de partograma são descritos na literatura, carecendo de evidências que validem a sua necessidade ou mesmo se existem diferenças entre eles nos desfechos maternos e perinatais.  
As diretrizes do NICE abordaram o assunto, incluindo um ERC em grupo conduzido no Sudeste Asiático (n = 8 hospitais; 35.484 mulheres) comparando o uso do partograma da OMS (um partograma com uma  
linha de ação) com nenhum uso de partograma<sup>272</sup> [NE = 1+]. Os resultados demonstraram que para as nulíparas o uso do partograma reduziu a proporção de partos prolongados (> 18 horas, RR 0,56 [IC 95% 0,47 a 0,67]), uso de ocitocina para estimulação do TP (RR 0,43 [IC 95% 0,39 a 0,47]), sepse puerperal (RR 0,09 [IC 95% 0,03–0,31]), cesariana(RR 0,70 [IC 95% 0,61 a 0,81]) e aumento na taxa de partos cefálicos espontâneos (RR 1,05 [IC 95% CI 1,03 a 1,08]. Para as multíparas os achados foram similares. As diretrizes também incluíram três ERCs que compararam partogramas com diferentes linhas de ação. Um (n = 928) realizado no Reino Unido comparou o uso de linhas de ação de 2, 3 e 4 horas<sup>273</sup> [NE = 1++] demonstrando que o uso de linhas de ação de 2 horas comparado a linhas de ação de 3 horas aumentou a satisfação materna (escore de satisfação DM 3,5 [IC 95% 1,7 a 5,3]), mas sem diferenças na incidência de amniotomia: OR 0,9 [IC 95% 0,6 a 1,3]; peridural OR 1,3 [IC 95% 0,9 a 1,8]; cesariana por parada de progressão: OR 0,7 [IC 95% 0,4 a 1,3]; ou parto instrumental: OR 0,9 [IC 95% 0,6 a 1,4]).302 [NE = 1++]. Não houve diferenças nos desfechos neonatais. Comparando uma linha de ação de 3 horas  com 4 horas houve aumento nas taxas de cesariana em geral (OR 1,8 [IC 95% 1,1 a 3,2]), mas não nas taxas de cesariana por sofrimento fetal (OR 1,8 [IC 95% 0.6 a 5,5]) ou por parada de progressão (OR 1,8 [IC 95% 0,9 a 3,4]). Não houve diferenças em outras intervenções, satisfação materna ou desfechos neonatais. Uma linha de ação de 2 horas comparada com 4 horas aumentou a satisfação materna (escore de satisfação DM 5,2 [IC 95% 3,4 a 7,0]) sem evidências de diferença nas taxas de intervenção ou desfechos neonatais.  
Outro ensaio realizado na África do Sul envolvendo 694 mulheres, comparou um partograma  com uma única linha de ação de 2 horas com o partograma da OMS com linha de ação de 4 horas. Os resultados demonstraram que uma única linha de ação reduziu a taxa de cesariana (RR 0,68 [IC 95% 0,50 a 0,93]) e partos instrumentais (RR 0,73 [IC 95% 0,56 a 0,96]) e aumentou o uso de ocitocina (RR 1,51 [IC 95% 1,10 to 2.07])<sup>274</sup> . Não houve diferenças no uso de analgesia (RR 1,01 [IC 95% 0,93 a 1,11]) ou desfechos neonatais (Apgar < 8 com 1 minuto (RR 1,24 [IC 95% 0,93 a 1,65]); morte perinatal RR 7,12 [IC 95% 0,37 a 137,37]).  
Outro ensaio também realizado no Reino Unido envolvendo 2.975 mulheres nulíparas comparou o uso de um partograma com linha de ação de 2 horas com outro de 4 horas, dispostas à direita da linha de alerta (NE = 1+)<sup>275</sup> . Não foram encontradas diferenças em relação a: cesariana RR 1,0 (IC 95% 0,80 a 1,26); insatisfação com a experiência de parto RR 0,89 [IC 95% 0,66 a 1,21]. No grupo de 2 horas mais mulheres cruzaram a linha de ação (854/1490 versus 673/1485; RR 1,27 [IC 95% 1,18 a 1,37]) e foram submetidas a mais intervenções para estimular o trabalho de parto (772/1490 versus 624/1486; RR 1,23 [IC 95% 1,14 a 1,33]). Não houve diferenças para parto intrumental, pH de cordão umbilical < 7,1, escore de Apgar < 7 com 5 minutos ou admissão em unidade neonatal.  
Não foram identificados estudos comparando partogramas com ou sem linhas de alerta. Além do mais, as evidências apresentadas nas diretrizes foram as mesmas de 2007, não havendo atualizações a partir de então.  
13.4.4 Resumo da evidência e conclusões  
Não foram encontradas evidências avaliando o impacto da monitoração dos dados vitais e da avaliação da atividade uterina nos desfechos maternos e perinatais. A evidência é limitada em relação à freqüência dos exames vaginais nos resultados maternos e perinatais, não sendo possível retirar conclusões, exceto diante da rotura prematura de membranas onde o número de exames vaginais está associado positivamente com a sepse neonatal. Em relação ao partograma há evidência que a sua utilização pode trazer benefícios, e linhas de ação mais precoces que uma linha de ação de 4 horas  
aumenta as intervenções sem benefícios para a mãe ou a criança.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.4.5 Outras considerações -->
Embora a evidência sobre a freqüência e tipo de observações que devem ser realizadas durante o trabalho de parto seja limitada, o grupo elaborador destas Diretrizes adaptadas, tendo como referência as recomendações das diretrizes-fonte, estabeleceu recomendações a esse respeito, assim como os gatilhos para a transferência de mulheres para níveis mais complexos e em relação ao partograma de acordo com as evidências analisadas.  
13.4.6 Recomendações em relação às observações durante o trabalho de parto  
93. Registrar as seguintes observações no primeiro período do trabalho de parto:  
- Frequência das contrações uterinas de 1 em 1 hora  
- Pulso de 1 em 1 hora  
- Temperatura e PA de 4 em 4 horas  
- Frequência da diurese  
- Exame vaginal de 4 em 4 horas ou se houver alguma preocupação com o progresso do parto ou em resposta aos desejos da mulher (após palpação abdominal e avaliação de perdas vaginais).  
94. Um partograma com linha de ação de 4 horas deve ser utilizado para o registro do progresso do parto, modelo da OMS ou equivalente.  
95. Transferir a mulher para uma maternidade baseada em hospital ou solicitar assistência de médico obstetra, se o mesmo não for o profissional assistente, se qualquer uma das seguintes condições forem atingidas, a não ser que os riscos da transferência supere os benefícios.  
- Observações da mulher:  
- Pulso >120 bpm em 2 ocasiões com 30 minutos de intervalo  
- PA sistólica ≥ 160 mmHg OU PA diastólica ≥ 110 mmHg em uma única medida  
- PA sistólica ≥ 140 mmHg OU diastólica ≥ 90 mmHg em 2 medidas consecutivas com 30 minutos de intervalo  
- Proteinúria de fita 2++ ou mais E uma única medida de PA sistólica ≥ 140 mmHg ou diastólica ≥ 90 mmHg  
- Temperatura de 38°C ou mais em uma única medida OU 37,5°C ou mais em 2 ocasiões consecutivas com 1 hora de intervalo  
- Qualquer sangramento vaginal, exceto eliminação de tampão  
- Presença de mecônio significativo  
- Dor relatada pela mulher que difere da dor normalmente associada às contrações  
- Progresso lento confirmado do primeiro e segundo períodos do trabalho de parto  
- Solicitação da mulher de alívio da dor por analgesia regional  
- Emergência obstétrica – incluindo hemorragia anteparto, prolapso de cordão, hemorragia pós-parto, convulsão ou colapso materno ou necessidade de ressuscitação neonatal avançada  
- Placenta retida  
- Lacerações perineais de terceiro e quarto graus ou outro trauma perineal complicado  
- Observações fetais:  
- Qualquer apresentação anômala, incluindo apresentação de cordão  
- Situação transversa ou oblíqua  
- Apresentação cefálica alta (-3/3 De Lee) ou móvel em uma nulípara  
- Suspeita de restrição de crescimento intra-uterino ou macrossomia  
- Suspeita de anidrâmnio ou polihidrâmnio  
- Frequência cardíaca fetal (FCF) < 110 ou > 160 bpm  
- Desacelerações da FCF à ausculta intermitente.  
96. Se mecônio significativo (verde escuro ou preto, grosso, tenaz, contendo grumos) estiver presente assegurar que:  
- Profissionais treinados em suporte avançado de vida neonatal estejam presentes no momento do parto  
97. Se mecônio significativo estiver presente, transferir a mulher para uma maternidade baseada em hospital de forma segura desde que seja improvável que o parto ocorra antes da transferência se completar.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.1 Introdução -->
De uma maneira geral, as mulheres são submetidas a várias intervenções de rotina durante o trabalho de parto. Infelizmente, essas práticas foram incorporadas à assistência sem a devida validação por estudos científicos bem desenhados. É importante a análise e sintetização das evidências atualmente disponíveis para se determinar quais dessas intervenções são realmente necessárias em termos de benefícios clínicos e danos para as mulheres e seus recém-nascidos.  
13.5.2 Questões de revisão  
- Qual é a efetividade, segurança e custo-efetividade do enema de rotina durante o trabalho de parto?  
- Qual é a efetividade, segurança e custo-efetividade  da tricotomia perineal e pubiana de rotina durante o trabalho de parto?  
- Qual a efetividade, segurança e custo-efetividade da rotura artificial de membranas de rotina durante o trabalho de parto?  
- Qual a efetividade, segurança e custo-efetividade da infusão rotineira de ocitocina durante o trabalho de parto?  
- Qual a efetividade, segurança e custo-efetividade  da movimentação e adoção de diversas posições durante o primeiro período do trabalho de parto?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.3 Enema -->
O enema evacuante de rotina no início do trabalho de parto ainda é prática comum em muitas maternidades brasileiras, com a alegação de que o mesmo traria benefícios tais como: a aceleração do trabalho de parto, a diminuição da contaminação do períneo e conseqüentemente a redução dos índices de infecção materna e neonatal. Por outro lado, a sua realização pode provocar desconforto e embaraço para a mulher, além da contaminação da região perineal com fezes líquidas. As evidências devem ser analisadas para se determinar os riscos e benefícios da realização rotineira do enema no início do trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.3.1 Evidências científicas -->
As diretrizes do NICE não abordam a utilização do enema durante o trabalho de parto. As diretrizes espanholas entretanto abordam o assunto e incluíram em sua análise uma RS que incluiu três ERCs<sup>276</sup> . Os resultados mostraram que não houve diferenças significativas entre os dois grupos em relação a onfalite neonatal (RR 7,47 [IC 95% 0,39 a 143,55]), infecção puerperal (RR 0,66 IC 95% 0,42 a 19,04]),  
laceração perineal sem comprometimento do esfíncter anal (RR 1,11 [IC 95% 0,65 A 1,90]) e laceração perineal com comprometimento do esfíncter anal (RR 0,59 [IC 95% 0,14 a 2,42]). Nas outras variáveis estudadas também não foram encontradas diferenças em relação ao recém-nascido (infecção ou Apgar) e deiscência de episiotomia. A duração do trabalho de parto foi menor no grupo de enema (1.077 mulheres, 409,4 versus 459,8 minutos; p < 0,001) mas não foram realizados ajustes por paridade. Também não foram encontradas diferenças na satisfação da mulher medida pela escala de Likert de 5 pontos (p=0,922).  
13.5.3.2 Resumo da evidência e Conclusões  
A realização de enemas evacuantes de rotina não melhora nenhum dos desfechos maternos ou neonatais estudados e tampouco a satisfação materna com a assistência. Em relação aos benefícios clínicos e riscos, não existem evidências que o mesmo seja benéfico, trazendo um potencial de provocar danos.  
13.5.3.3 Outras considerações  
Em relação aos benefícios para a saúde e uso de recursos, a realização de enema evacuante de rotina pode acarretar em aumento de custos, tendo em vista a utilização de recursos humanos e materiais adicionais, sem nenhum benefício conhecido.  
13.5.3.4 Recomendação em relação ao enema  
98. O enema não deve ser realizado de forma rotineira durante o trabalho de parto  
13.5.4 Tricotomia pubiana e perineal  
A tricotomia é outro procedimento comum, realizado com o intuito de diminuir os índices de infecção e facilitar a sutura perineal em caso de laceração ou episiotomia. Muitas mulheres não gostam do procedimento e relatam um desconforto durante o período de crescimento dos pelos. É outra prática que foi incorporada à assistência sem a devida validação científica.  
13.5.4.1 Evidências Científicas  
Assim como o enema, as diretrizes do NICE  não abordam essa questão, que foi abordada nas diretrizes espanholas que incluíram em sua análise uma RS da Biblioteca Cochrane<sup>277</sup> , que por sua vez incluiu dois ERC, com um total de 539 mulheres. Os resultados não demonstraram diferenças nos dois grupos (tricotomizadas ou não) em relação a morbidade febril materna (OR 1,26 [IC 95% 0,75 a 2,12]). Em um dos ensaios, envolvendo 150 mulheres, houve uma menor colonização com bactérias Gram-negativo nas mulheres que se submeteram à tricotomia (OR 0,43 [IC 95% 0,20 a 0,92]). No entanto o significado clínico deste achado é desconhecido.  
13.5.4.2 Conclusões  
As evidências apontam que a tricotomia de rotina no trabalho de parto não apresenta benefícios clínicos significativos, além de apresentar danos potenciais.  
13.5.4.3 Outras considerações  
Em relação aos benefícios para a saúde e uso de recursos, uma política de uso rotineiro da tricotomia acarreta mais custos, tendo em vista a utilização de recursos humanos e materiais, sem nenhum benefício conhecido.  
13.5.4.4 Recomendação em relação à tricotomia pubiana e perineal  
99. A tricotomia pubiana e perineal não deve ser realizada de forma rotineira durante o trabalho de parto  
13.5.5 Amniotomia  
A amniotomia precoce de rotina é uma intervenção bastante comum nas maternidades brasileiras. O  
argumento utilizado para a sua realização é que diminuiria a duração do trabalho de parto. Entretanto, a amniotomia precoce pode estar associada com algumas complicações potenciais tais como o aumento na ocorrência de desacelerações da freqüência cardíaca fetal e infecção. Os riscos e benefícios da amniotomia precoce de rotina devem ser avaliados à luz das evidências atuais.  
13.5.5.1 Evidências Científicas  
As diretrizes do NICE de 2014 abordam a questão da amniotomia em duas comparações:  
- amniotomia precoce de rotina com uso seletivo de ocitocina versus conduta conservadora;  
- amniotomia precoce de rotina mais ocitocina no início do trabalho de parto.  
13.5.5.1.1 Amniotomia precoce de rotina com uso seletivo de ocitocina versus conduta conservadora Essa comparação incluiu o uso de ocitocina após a amniotomia caso não ocorresse progresso suficiente do parto. As diretrizes incluíram 2 ERCs, um estudo Belga envolvendo 306 mulheres nulíparas (intervenção n = 152; controle n = 154)<sup>278</sup> e um ensaio estadunidense envolvendo 705 mulheres nulíparas (intervenção n = 351; controle n = 354)<sup>279</sup> , com os quais se realizou uma meta-análise. Os resultados demonstraram não haver diferenças no tipo de parto (cesariana: RR 0,80 [IC 95% 0,55 a 1,17]; parto vaginal espontâneo: RR 1,06 [IC 95% 0,97 a 1,16]), uso de peridural: RR 1,02 [IC 95% 0,92 a 1,12]; , duração do primeiro período do parto: DMP −65.06 minutos [IC 95% −134.83 a 4,71 minutos]; segundo período do parto: DMP 1,80 minutos [IC 95% −1,83 a 5,44 minutos]; escores de Apgar < 7 com 5 minutos: RR 1,22 [IC 95% 0,38 a 3,93]; e admissão em UTI neonatal: RR 0,90 [IC 95% 0,47 a 1,72]. 13.5.5.1.2 Amniotomia precoce de rotina mais ocitocina no início do trabalho de parto  
Essa comparação foi definida como a realização precoce de amniotomia, associada a ocitocina no início do trabalho de parto. As diretrizes incluíram um ERC realizado nos EUA envolvendo 150 mulheres nulíparas (intervenção = 75; controle = 75) que demonstrou não haver diferenças no tipo de parto (cesariana: RR 0,91 [IC 95% 0,41 a 2,01]; parto vaginal espontâneo: RR 0,97 [IC 95% 0,82 a 1,14]), nenhuma evidência forte na duração do trabalho de parto (fase latente DM −0,73 horas [IC 95% −0,84 a −0,62 horas]; fase ativa DM 0,24 horas [IC 95% 0,12 a 0,36 horas]; fase de desaceleração DM 0,00 horas [IC 95% −0.02 a 0,02 horas]) e escores de Apgar (1 minuto DM 0,35 [IC 95% 0,30 a 0,40]; 5 minutos DM 0,02 [IC 95% 0,00 a 0,04])<sup>280</sup> .

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.5.2 Conclusões -->
As evidências demonstram que não há benefícios na realização rotineira de amniotomia precoce, associada ou não à ocitocina, nos desfechos maternos e neonatais estudados.  
13.5.5.3 Outras considerações  
Em relação aos benefícios para a saúde e utilização de recursos, a realização rotineira de amniotomia, associada ou não à ocitocina, pode acarretar em aumento de custos, tendo em vista a utilização de recursos humanos e materiais, sem nenhum benefício significativo. Não foram incluídos estudos que avaliassem apenas a utilização de ocitocina de rotina, não associada à amniotomia, no trabalho de parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.5.4 Recomendações em relação à amniotomia de rotina -->
100. A amniotomia precoce, associada ou não à ocitocina, não deve ser realizada de rotina em mulheres em trabalho de parto que estejam progredindo bem.  
13.5.6 Movimentação e posição no parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.6.1 Introdução -->
Desde que a assistência ao parto passou a ser realizada em hospitais, a mulher foi obrigada a adotar a posição supina, ou seja, deitada em uma cama, em decúbito lateral esquerdo, durante todo o trabalho  
de parto, sendo proibida de se movimentar. A alegação para tal conduta era de que em decúbito lateral haveria aumento da perfusão placentária e, consequentemente maior oxigenação fetal. Entretanto, mesmo que o decúbito lateral esquerdo possa aumentar a oxigenação fetal, as evidências avaliando outras posições no trabalho de parto, em relação aos desfechos, precisam ser avaliadas e analisadas de maneira sistemática.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.6.2 Evidências Científicas -->
As diretrizes do NICE abordam a questão incluindo em sua revisão uma revisão sistemática (RS) que, por sua vez incluiu 14 ERCs<sup>281</sup> , além de 5 outros ERCs<sup>282-286</sup> isolados realizados nos EUA, Austrália, Argentina e Reino Unido.  
A RS incluiu estudos com várias diferenças no seu desenho, além de ausência de detalhes, na maioria dos artigos, em relação a medidas para prevenir viéses. As dificuldades de aderência e diferentes métodos de avaliação da dor dificultaram a confiabilidade nos dados e não permitiram a sua análise em conjunto. O único achado consistente foi de que nenhuma das mulheres relataram maior conforto na posição supina. Além do mais, demonstrou que a alternância entre a posição supina e sentada parece reduzir a eficiência da atividade uterina comparada com a alternância entre a supina e em pé ou de lado. Demonstrou-se também que muitas mulheres tiveram dificuldades em permanecerem na posição em pé ou mobilizando durante o trabalho de parto, principalmente no final do primeiro período e no segundo período do parto. Não foi possível concluir sobre o efeito da posição e mobilização na dor ou na duração do trabalho de parto.  
Um ERC realizado nos EUA comparou a deambulação no trabalho de parto (n = 536) com a não deambulação (n = 531)<sup>282</sup> [NE = 1+] demonstrando que das mulheres alocadas para o grupo de deambulação, 22% escolheram não deambular. Das 420 mulheres que realmente deambularam, o tempo médio de deambulação foi de 56 minutos (DP = 46 minutos). No grupo alocado para não deambular, o grau de deambulação foi mínimo. Não foram encontradas diferenças significativas entre os grupos em relação a duração do trabalho de parto, uso de ocitocina, analgesia, tipo de parto e outros desfechos maternos ou neonatais. De 278 mulheres que deambularam, 99% relataram que o fariam novamente no futuro.  
Outro ERC realizado na Austrália (n = 196) comparou a deambulação com a posição deitada<sup>283</sup> [NE = 1+]. As análises foram por intenção de tratar.  Não foram encontradas diferenças significativas em relação aos desfechos do trabalho de parto, tipo de parto e desfechos maternos ou neonatais. Apenas 37 das 96 mulheres alocadas para o grupo de deambulação (39%) realmente escolheram deambular por mais de 30 minutos. Das que deambularam, o tempo médio em posição ereta foi de 1,5 hora (DP = 0,8 h). Na fase de recrutamento, 389 mulheres negaram participar do estudo, 46% delas por medo de não ter a oportunidade de deambular durante o trabalho de parto.  
Um pequeno ERC realizado no Reino Unido (n = 68) comparou a deambulação com a posição deitada no primeiro período do trabalho de parto [NE = 1-]<sup>284</sup> . Os resultados demonstraram que nas mulheres que deambularam houve menos analgesia, as contrações foram menos frequentes mas de maior amplitude, a duração do trabalho de parto foi mais curta, ocorreram mais partos normais e os escores de Apgar foram maiores. O tempo médio de deambulação foi de 2,2 horas (0,8 a 8,3 horas). O estudo teve vieses de seleção, já que as mulheres participantes foram selecionadas de um grupo que já havia demonstrado o desejo de deambular.  
Um ERC conduzido na Argentina comparou a percepção de dor em dois grupos de 50 mulheres alocadas para adotar posições verticais alternadas (sentada, em pé ou deambulando) ou posição horizontal  
(decúbito lateral ou dorsal) por períodos de 15 minutos no primeiro período do parto<sup>285</sup> [NE = 1+]. Cada mulher atuou como o seu próprio controle. A avaliação da dor foi realizada por duas escalas (escala tipoLickert e uma escala analógica visual de 10 cm (EAV)). No decorrer do trabalho de parto foram notados maiores níveis de dor, tanto das contrações abdominais quanto dor lombar, no grupo da posição horizontal.  
Outro pequeno ensaio realizado nos EUA (n = 20), envolvendo nulíparas comparou posições verticais (em pé, deambulando, de joelhos, sentada ou de cócoras) com posições recostadas (supina, lateral ou de quatro) [NE = 1+]<sup>286</sup> . No grupo de posições verticais, a duração da fase ativa do trabalho de parto foi menor (diferença da média 90,25 minutos, P = 0,003) e as contrações foram mais longas e mais frequentes. Não houve diferenças significativas em relação ao conforto físico das mulheres.  
13.5.6.3 Conclusões  
As evidências são limitadas em relação à liberdade de movimentação comparada à restrição de movimentação no trabalho de parto em relação ao progresso do parto, conforto e bem-estar fetal. Não existem evidências de alto nível comparando as diversas posições no parto ou a mobilização em relação aos benefícios clínicos e danos nos desfechos maternos ou perinatais. Em relação à preferência das mulheres, parece haver mais preferência pelas posições verticais .

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.5.6.4 Outras considerações -->
Em relação aos benefícios para a saúde e utilização de recursos no Brasil, a liberdade para que as mulheres se movimentem ou adotem a posição que lhes for mais confortável no trabalho de parto, não envolve custos adicionais significativos, exceto pela disponibilização, pelos serviços de maternidade, de espaço, utensílios e materiais que facilitem as posições verticais tais como bolas, cadeiras, cavalinhos, escadas, etc.  
13.5.6.5 Recomendações em relação à movimentação e posição no parto  
101. As mulheres devem ser encorajadas a se movimentarem e adotarem as posições que lhes sejam mais confortáveis no trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.1 Introdução -->
A observação e monitoração adequada do progresso do parto é importante pois permite reconhecer em tempo hábil os desvios da normalidade que possam requerer alguma intervenção, assim como a transferência da parturiente para níveis mais complexos de assistência ou para a solicitação de assistência adicional. Além do mais os critérios utilizados para a identificação e conduta na falha de progresso no parto também apresenta uma grande variabilidade na prática clínica diária levando, muitas vezes, a intervenções desnecessárias ou mesmo a ausência de intervenções onde seriam realmente necessárias.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.2 Questões de revisão -->
 Como identificar e atuar na falha de progresso no parto?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3 Evidências Científicas -->
As diretrizes do NICE de 2014 abordam as intervenções para suspeita de demora de progressão no trabalho de parto, mas não incluiu nenhum estudo que avaliasse critérios diferentes de identificação da falha de progresso no parto nos desfechos maternos e perinatais. Entretanto, baseado nos estudos sobre duração do trabalho de parto já descritos, o grupo elaborador fez recomendações a respeito, enumeradas no final dessa seção. As evidências sobre os efeitos das diversas intervenções para a  
conduta na falha de progresso no parto, são descritas nas sub-seções seguintes. 13.6.3.1 Amniotomia versus conduta expectante  
Foi incluída para análise uma RS que por sua vez incluiu 9 ERCs<sup>287</sup> que avaliou a amniotomia para a conduta na falha de progresso no parto, para nulíparas e multíparas.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3.1.1 Nulíparas -->
Os resultados mostraram forte evidência de que a amniotomia reduziu de maneira significativa o intervalo de tempo para o parto (dois ensaios, n = 117 mulheres): DM −53,67 minutos [IC 95% −66.50 a −40.83 minutos], tempo para a dilatação completa (três ensaios, n = 298 mulheres): DM −39.45 minutos [IC 95% −50,10 a −28,80 minutos]; taxa de distócia (um ensaio , n = 925 mulheres): OR 0,63 [IC 95% 0,48 a 0,82]); prolapso de cordão (um ensaio, n = 925 mulheres): OR 0,14 [IC 95% 0,00 a 6,84]; e o percentual de mulheres que relataram que o parto foi insuportável (três ensaios, n = 1.283 mulheres): OR 0,76 [IC 95% 0,60 a 0,97]; Não foram demonstradas diferenças no uso de ocitocina, uso de analgesia, taxa de cesariana, parto instrumental, FCF suspeita ou anormal, morbidade febril materna, transfusão de sangue ou satisfação materna. Em relação aos desfechos neonatais não houve diferenças em: márotação da cabeça (um ensaio, n = 32 mulheres): OR 0,47 [IC 95% 0,12 a 1,89]; escores de Apgar < 7 com 5 minutos (cinco ensaios, n = 2.518 mulheres): OR 0,94 [IC 95% 0,67 a 1,33]; icterícia neonatal (três ensaios, n = 2.383 mulheres): OR 1,05 [IC 95% 0,70 a 1,58]; admissão em unidade neonatal (quatro ensaios, n = 1.996 mulheres): OR 1,13 [IC 95% 0,78 a 1,62]; céfalo-hematoma (dois ensaios, n = 1.022 mulheres): OR 1,66 [IC 95% 0,86 a 3,21]; e morbidade infecciosa (dois ensaios, n = 1.353 mulheres): OR 1,43 [IC 95% 0,85 a 2,41].

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3.1.2 Multíparas -->
A evidência mostrou redução significativa no intervalo entre a randomização e a dilatação completa (um ensaio, n = 269 mulheres): DM −54,00 minutos [IC 95% −101,37 a −6,63 minutos], sem mostrar diferenças no uso de ocitocina (um ensaio, n = 940 mulheres): OR 1,22 [IC 95% 0,67 a 2,21]; uso de analgesia (peridural/narcóticos) (um ensaio, 940 mulheres): OR 1,14 [IC 95% CI 0,80 a 1,63]; cesariana (um ensaio, n = 940 mulheres): OR 2,65 [IC 95% 0,75 a 9,29]; parto vaginal instrumental (um ensaio, n = 940 mulheres): OR 1,20 [IC 95% 0,65 a 2,21]; e icterícia neonatal (um ensaio, n = 531 mulheres): OR 3,61 [IC 95% 0,89 a 14,75].

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3.2 Amniotomia mais ocitocina versus ocitocina -->
Foi incluído um ERC realizado nos EUA (n = 118) que comparou a realização de amniotomia mais ocitocina com ocitocina seguida de amniotomia seletiva em caso de necessidade de intervenção em caso de parada de progressão no parto<sup>288</sup> [NE = 1+]. Não foram encontradas diferenças no intervalo entre a randomização e o parto (DM −0,70 hours [−1,55 a 0,15 hours]); taxa de cesariana (RR 1,21 [95% IC 0,34 a 4,28]) e infecção neonatal (RR 4,83 [IC 95% 0,58 a 40,13]). Houve significativamente mais mulheres com infecção puerperal no grupo de amniotomia mais ocitocina (amniotomia = 7/60; controle = 0/58, P = 0.01).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3.3 Amniotomia versus amniotomia mais ocitocina -->
Foram incluídos para análise três ERCs<sup>289-291</sup> , com os quais foi realizada uma meta-análise (n = 1.028). Não foram demonstradas diferenças na taxa de cesariana (três ensaios, RR 0,82 [IC 95% 0,47 a 1,40]); uso de peridural (dois ensaios, RR 1,01 [IC 95% 0,79 a 1,30]); Apgar < 7 com 5 minutos (dois ensaios, RR 0,95 [IC 95% 0,13 a 7,09]); admissão na unidade neonatal (um ensaio, RR 3,00 [IC 95% 0,12 a 78,04]); e escore de satisfação materna (um ensaio DM 9.00 [IC 95% −6,73 a 24,73]) nos dois grupos estudados. 13.6.3.4 Amniotomia mais ocitocina imediata versus amniotomia mais ocitocina tardia  
Um ERC<sup>291</sup> realizado no Reino Unido incluindo 61 mulheres e incluído na revisão já descrita avaliou essa comparação (ocitocina + amniotomia = 21; expectante = 19) e demonstrou uma redução significativa no intervalo entre a randomização e o parto (intervenção = 266 minutos (DP 166), controle = 463 minutes (DP 164 minutes), P < 0,001) e aumento na satisfação materna (escore de satisfação intervenção = 149 (DP 23), controle = 118 (DP 33), P = 0,002), sem diferenças no uso de peridural (RR 0,55 [IC 95% 0,12 a 2,4]), taxa de cesariana (RR 2,6 [IC 95% 0,4 a 30,9]) e desfechos neonatais (Apgar < 7 com 5 minutos intervenção = 1/21, controle = 0/19; admissão em unidade neonatal intervenção = 1/21, controle = 0/19 ).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 13.6.3.5 Resumo da evidência e conclusões -->
A evidência demonstra que se houver demora na evolução do trabalho de parto, a amniotomia seguida por uma infusão de ocitocina diminui a duração do trabalho de parto mas não aumenta a chance de parto vaginal ou melhora qualquer outro resultado. Se as membranas estiverem rotas, não há evidências de que a ocitocina nas primeiras 8 horas após altera qualquer coisa além da duração do trabalho de parto.  
12.6.3.6 Esquemas e doses de ocitocina  
12.6.3.6.1 Altas doses versus baixas doses de ocitocina para estimulação  
Foram consideradas as seguintes quantidades de ocitocina:  
- alta dose definida como uma dose inicial e incrementos de 4 mUI/minuto ou mais  
- baixa dose definida como uma dose inicial e incrementos até 2 mUI/minuto  
- intervalo de aumento das doses entre 15 e 40 minutos.  
Foram incluídos na revisão qutro ERCs que fizeram essa comparação<sup>290,292-294</sup> . A tabela 125 sumariza as dosagens empregadas:  
Tabela 23: Protocolos de baixas e altas doses de ocitocina para estimulação do trabalho de parto  
|Estudo|Baixa dose|Alta dose|
|---|---|---|
|Jamal (2004)<sup>294</sup>|Iniciar a 1,5 mU/minuto<br>Aumentar 1,5 mU/30<br>minutos|Iniciar a 4,5 mU/minuto<br>Aumentar 4,5 mU/30<br>minutes|
|Merrill (1999)<sup>292</sup>|Iniciar a 1,5 mU/minuto<br>Aumentar 1,5 mU/30<br>minutos|Iniciar a 4,5 mU/minuto<br>Aumentar 4,5 mU/30<br>minutos|
|Xenakis (1995)<sup>293</sup>|Iniciar a 1,5 mU/minuto<br>Aumentar 1,5 mU/30<br>minutos até 4 mU/minuto<br>Esperar 120 minutos<br>Aumentar 1,5 mU/30<br>minutos|Iniciar a 4,5 mU/minuto<br>Aumentar 4,5 mU/15<br>minutos|
|Bidgood (1987)<sup>290</sup>|Iniciar a 2 mU/minuto<br>Aumentar 2 mU/15<br>minutos|Iniciar a 7 mU/minuto<br>Aumentar 7 mU/15<br>minutos|  
A meta-análise dos ensaios não demonstrou diferenças no intervalo entre o início da ocitocina e o parto (dois ensaios, DM −98,45 minutos [IC 95% −269,71 a 72,82 minutos]), mas uma dose máxima de ocitocina mais alta no grupo de altas doses em relação ao grupo de baixas doses (três ensaios, DM 7,49  
mU/minuto [IC 95% 7,06 a 7,91 mU/minuto]). No grupo de altas doses demonstrou-se uma redução na taxa total de cesariana (quatro enasios): RR 0,76 [IC 95% 0,62 a 0,92] e cesariana por distócia (três ensaios): RR 0,72 [IC 95% 0,57 a 0,91] sem diferenças na taxa de cesariana por sofrimento fetal (trê ensaios): RR 0,91 [IC 95% 0,58 a 1,40]; Houve também um aumento na taxa de parto vaginal espontâneo (dois ensaios): RR 1,13 [IC 95% 1,07 a 1,20]); hiperestimulação uterina (quatro ensaios): RR 1,35 [IC 95% 1,21 a 1,50]) e menos corioamnionite (três ensaios): RR 0,71 [IC 95% 0,56 a 0,90]). Também não houve diferenças na incidência de distócia de ombro entre os grupos (dois ensaios): RR 1,36 [IC 95% CI 0,63 a 2,95]).  
Em relação aos desfechos neonatais, não houve diferenças na admissão em unidades neonatais (dois ensaios, RR 0,95 [IC 95% 0,68 a 1,32]); escore de Apgar menor que 7 aos 5 minutos (quatro ensaios, RR 0,98 [IC 95% 0,42 a 2,28]); e mortes perinatais (quatro ensaios, RR 1,45 [IC 95% 0,37 a 5,74]). 13.6.3.6.2 Resumo da evidência e conclusões  
Existem evidências de qualidade razoável demonstrando que esquemas de altas doses de ocitocina para estimulação do trabalho de parto estão associados com trabalhos de parto mais rápidos, menos cesariana, principalmente por distócia, mais partos vaginais espontâneos e menos corioamnionite. Tiveram também doses máximas mais altas de ocitocina e mais hiper-estimulação em relação aos esquemas de baixas doses. Os estudos não tiveram poder suficiente para avaliar a mortalidade ou morbidade neonatal grave. Não foram encontrados estudos que avaliassem o grau de satisfação materna com os diferentes protocolos estudados.  
13.6.3.6.3 Outras considerações  
Considerando o balanço entre riscos e benefícos clínicos, conclui-se que embora os esquemas de altas doses de ocitocina (4 mU/minuto ou mais) para estimulação do trabalho de parto estejam associados com trabalhos de parto mais curtos, menos cesariana e mais partos vaginais espontâneos, deve-se ter cautela em relação ao seu uso rotineiro tendo em vista a heterogeneidade dos estudos e a carência de evidências em relação aos desfechos neonatais e o grau de satisfação materna. 13.6.3.6.4 Comparação entre dosagens diferentes de ocitocina  
Foram incluídos cinco ERCs que investigaram diferentes dosagens de ocitocina além dos estudos já analisados<sup>295-299</sup> Não foi possível realizar meta-análise dos mesmos os quais são sumarizados a seguir. Um ensaio realizado no Zimbabwe (2001) envolvendo 258 nulíparas comparou diferentes  doses altas de ocitocina<sup>295</sup> [NE = 1-]. A menor dose foi iniciada a 4 mU/minuto, dobrada a cada 30 minutos até 16 mU/minuto e depois 64 mU/minuto. A dose maior foi iniciada a 10 mU/minuto e dobrada a cada  60 minutos até 40 mU/minuto. Demonstrou-se uma redução significativa na proporção de mulheres que tiveram mais que 6 horas de duração entre o início da estimulação e o parto (RR 0.36 [IC 95% 0,21 a 0,62]). Não foram encontradas diferenças nas taxas de cesariana (RR 0,95 [IC 95% 0,42 a 2,15]) ou desfechos neonatais.  
Um ERC realizado no EUA (1994) envolvendo 1.167 mulheres comparou diferentes tempos de incremento das doses de ocitocina: 20 minutos (início a 6 mU/minuto, aumento de 6 mU/20 minutos até 42 mU/minuto) versus 40 minutos (início a 6 mU/minuto, aumento de 6 mU/40 minutos até 42 mU/minuto)<sup>296</sup> [NE = 1+]. Demonstrou-se uma redução na incidência de cesarina por distócia com o incremento mais rápido (OR 0,65 [IC 95% 0,43 a 0,97]), com um aumento limítrofe na incidência de hiper-estimulação (OR 1,3 [IC 95% 0,98 a 1,7]), mas sem diferenças na incidência de corioamnionite (OR 0,97 [IC 95% 0,66 a 1,4]) e admissão de bebês em unidade neonatal (OR 1,3 [IC 95% 0,77 a 2,4]) Um outro ERC realizado nos EUA envolvendo 487 mulheres, comparou um esquema de incremento das  
doses a cada 15 minutos (início a 1 mU/minuto, incremento de 1 mU/15 minutos até 5 mU/minuto, depois incremento de 1–2 mU/15 minutos) e a cada 40 minutos (início a 1 mU/minuto, incremento de 1,5 mU/40 minutos até 7 mU/minuto, depois incremento de 1,5–3,0 mU/40 minutos)<sup>297</sup> [NE = 1+]. Demonstrou-se que mais mulheres atingiram uma dose máxima mais alta de ocitocina (15 minutos = 8.2 mU/minuto; 40 minutos = 6.5 mU/minuto, P < 0,001), apresentaram sofrimento fetal (RR 1,68, P < 0,005) e hiper-estimulação uterina (RR 1,69, P < 0,001) com o incremento a cada 15 minutos, comparado com o incremento a cada 40 minutos.  
Outro ERC conduzido nos EUA (n = 94) comparou uma infusão contínua de ocitocina (início a 1 mU/minuto, incremento a 1 mU/20 minutes) com uma injeção pulsátil repetida (início a 1 mU por pulso (10 segundos a cada 8 minutos), dobrado a cada 24 minutos<sup>298</sup> [NE = 1+] As mulheres no esquema pulsátil necessitaram uma quantidade menor de: nível médio de ocitocina pulsátil = 2.1 mU/minute (DP 0,4 mU/minuto), contínua = 4,1 mU/minuto (DP 0,4 mU/minuto), P < 0,001; quantidade total de ocitocina pulsátil = 1.300 mU (DP 332 mU), contínua = 1.803 mU (DP 302 mU), P < 0,001); Não houve diferenças na incidência de contrações disfuncionais (RR 1,04, NS).  
Um ERC conduzido no Reino Unido<sup>299</sup> [NE = 1-] envolvendo 68 mulheres nulíparas comparou a mesma dose e esquema de ocitocina (início a 2,5 mU/minuto, incremento a 2,5 mU/30 minutos) em dois grupos. Em um grupo a ocitocina foi aumentada até as contrações atingissem 6 em 15 minutos e no outro até a atividade uterina medida por catetrer intra-uterina atingisse 1750 kPas/15 minutos. O estudo não teve força suficiente e não encontrou dfirenças em: dose máxima de ocitocina para a frequência de contrações = 8.3 mU/minuto (DP 3,7 mU/minuto); para atividade uterina máxima = 8,0 mU/minuto (SD 3.1 mU/minute); hiper-estimulação (RR 0,54, NS); cesarina (RR 2,00, NS); e Apgar < 5 em 1 minuto (RR 0.33, NS).  
13.6.3.6.5 Resumo da evidência e conclusões  
A evidência em relação às diferentes dosagens de ocitocina é limitada, com os estudos tendendo a ter baixo poder estatístico e utilizar muitos esquemas diferentes. Nos estudos com incrementos mais rápidos das doses há mais hiper-estimulação uterina. Nos estudos de altas doses com incrementos mais rápidos houve menos cesariana por distócia, diferença essa não encontrada nos estudos de doses menores. Incrementos mais rápidos de baixas doses podem estar associados a sofrimento fetal. A evidência é limitada em relação à ocitocina pulsátil comparada com a contínua, demonstrando uma necessidade de menor quantidade de ocitocina com as injeções pulsáteis mas sem nenhuma diferença nos outros desfechos. A evidência é insuficiente em relação a outros desfechos, incluindo os desfechos neonatais e satisfação das mulheres em relação às diferentes dosagens de ocitocina. O aumento das doses com frequência maior do que a cada 20 minutos pode estar associado a mais hiper-estimulação uterina e padrões não tranquilizadores da frequência cardíaca fetal.  
13.6.4 Recomendação sobre a identificação e conduta na falha de progresso no primeiro estágio do parto  
102. Se houver suspeita de falha de progresso no primeiro estágio do trabalho de parto levar em consideração:  
- O ambiente onde a mulher está sendo assistida  
- A atitude da mulher, se postura mais ativa ou não  
- estado emocional da mulher  
- O tipo de apoio e suporte físico e emocional que a mulher estiver recebendo  
- Paridade  
- Dilatação e mudanças cervicais  
- Contrações uterinas  
- Altura e posição da apresentação  
- Necessidade de referência ou solicitação de assistência profissional apropriada.  
103. Se houver suspeita de falha de progresso na fase ativa do trabalho de parto considerar também para o diagnóstico todos os aspectos da evolução do trabalho de parto , incluindo:  
- progresso da dilatação cervical inferior a 2 cm em 4 horas  
- descida e rotação do pólo cefálico  
- mudanças na intensidade, duração e frequência das contrações uterinas.  
104. Diante da suspeita de falha de progresso no primeiro estágio do trabalho de parto, considerar a realização de amniotomia se as membranas estiverem íntegras. Explicar o procedimento e avisar que o mesmo irá diminuir o trabalho de parto por cerca de 1 hora e pode aumentar a intensidade e dor das contrações.  
105. Se a amniotomia for ou não realizada, realizar um exame vaginal após 2 horas e confirmar falha de progresso se a dilatação progredir menos que 1 cm.  
106. Se for confirmada falha de progresso no primeiro estágio do parto:  
- A mulher deve ser transferida para assistência sob responsabilidade de médico obstetra se não estiver sob seus cuidados. O mesmo deverá realizar uma revisão e diagnosticar a falha de progresso e decidir sobre as opções de conduta, incluindo o uso de ocitocina.  
- Explicar que o uso de ocitocina após a ruptura das membranas irá diminuir o tempo para o parto mas não influenciará no tipo de parto ou outros desfechos.  
107. Se as membranas estiverem íntegras e o diagnóstico de falha de progresso for confirmado, aconselhar a mulher a ser submetida a uma amniotomia e repetir o exame vaginal 2 horas após.  
108. Oferecer apoio e controle efetivo da dor à todas as mulheres com falha de progresso no primeiro estágio do trabalho de parto.  
109. Informar às mulheres que a ocitocina irá aumentar a freqüência e intensidade das contrações e que a criança deverá ser monitorada continuamente ou com mais freqüência.  
110. Oferecer analgesia peridural, se disponível, se for indicado o uso de ocitocina.  
111. Se a ocitocina for utilizada assegurar que os incrementos na dose não sejam mais frequentes do que a cada 30 minutos. Aumentar a dose de ocitocina até haver 4-5 contrações em 10 minutos.  
112. Realizar exame vaginal 4 horas após o início da ocitocina:  
- Se a dilatação cervical aumentou menos que 2 cm após 4 horas, uma revisão obstétrica adicional deve ser realizada para avaliar a necessidade de cesariana.  
- Se a dilatação cervical aumentou 2 cm ou mais após 4 horas, continuar observação do progresso do parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.1.1 Introdução -->
Na assistência hospitalar ao parto é bastante comum que, ao atingir o segundo período do trabalho de parto, a maioria das mulheres sejam transferidas para assistência em salas de parto isoladas ou em ambientes cirúrgicos. Nos últimos anos, entretanto, várias opções de assistência em ambientes não cirúrgicos têm sido recomendadas, como em suítes PPP (Pré-parto, Parto e Pós-parto imediato), locais onde a mulher pode vivenciar todos os períodos do parto. Em relação às posições da mulher no segundo período do parto, outras alternativas têm surgido em substituição à posição de litotomia clássica, principalmente posições verticalizadas como semi-sentada, sentada, de cócoras, etc. Também a imersão em água tem sido utilizada por muitas mulheres durante o período expulsivo, com o parto ocorrendo de fato dentro da água. É necessário analisar as evidências científicas disponíveis para uma avaliação dos riscos e benefícios, em termos de desfechos maternos e perinatais das medidas descritas.  
14.1.2 Questão de revisão  
- Existem diferenças em relação aos diversos ambientes para assistência ao segundo período do parto tais como?  
`o` Suítes PPP (Pré-parto, Parto e Pós-parto imediato)?  
`o` Salas de parto isoladas em ambientes cirúrgicos ou não?  
- Quais os efeitos da adoção de diversas posições durante o segundo período do parto (período expulsivo)?  
- Quais os efeitos da imersão em água durante o segundo período do parto (período expulsivo)?  
14.1.3 Evidências Científicas

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.1.3.1 Ambiente para assistência ao segundo período do trabalho de parto -->
As diretrizes consultadas não avaliaram as diferenças entre os diversos ambientes de assistência ao parto hospitalar (suítes PPP, salas de parto isoladas em ambientes cirúrgicos ou não) em relação aos desfechos maternos e perinatais.  
14.1.3.2 Posições no segundo período do trabalho de parto  
Nas diretrizes do NICE (2014), a evidência para o efeito de diferentes posições e a mobilização durante a segunda fase do trabalho de parto sobre os resultados foi elaborada a partir de uma revisão sistemática de 19 ERCs<sup>300</sup> [NE = 1+] envolvendo 5.764 mulheres. Aconselha-se precaução na interpretação dos resultados, uma vez que a qualidade dos estudos incluídos é variável.  
As posições verticais incluíram a posição sentada (incluindo cadeira de parto ); posição semi-deitada (tronco inclinada para trás 30 graus em relação à vertical); cócoras (sem apoio ou usando barras); cócoras (usando almofada de parto). Para efeitos desta revisão, as posições verticais foram combinadas com a posição lateral para comparação com as posições supina ou litotomia. O uso de qualquer posição vertical ou lateral, quando comparadas com a posição supina, decúbito dorsal horizontal ou de litotomia, associou-se com redução média de 4,29 minutos [IC 95% 2,95-5,64 ] na duração do segundo período do trabalho de parto.  
Observou-se ainda uma redução na frequência de partos instrumentalizados (18 ensaios): RR 0,84 [IC 95% 0,73-0,98]; nas episiotomias (12 ensaios: RR 0,84 [95% IC 0,79-0,91]); na dor intensa durante o segundo período (um ensaio: RR 0,73 [IC 95% 0,60-0,90]) e menos padrões anormais da FCF (um ensaio RR 0,31 [IC 95% 0,08-0,98]). Além disso, observou-se um aumento de lacerações de segundo grau (11 ensaios: RR 1,23 [IC 95% 1,09-1,39]) e aumento estimado de perda sanguínea superior a 500 ml (11

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: ensaios: RR 1,68 [IC 95% 1,32-2,15]). -->
Nenhuma diferença significativa foi observada para uso de analgesia ou anestesia durante o segundo período do trabalho de parto (sete ensaios), lacerações de terceiro ou quarto grau (quatro ensaios), necessidade de transfusão de sangue (dois ensaios), remoção manual da placenta (três ensaios), experiência desagradável no nascimento (um ensaio), insatisfação com o segundo período do parto (um ensaio), sensação de falta de controle (um ensaio), admissão à UTI (dois ensaios), tocotraumatismo (um ensaio) ou morte neonatal (três ensaios).  
A posição lateral foi investigada em um estudo nos EUA<sup>301</sup> cujos achados sugerem que a posição lateral para o parto foi associada com uma menor incidência de lacerações espontâneas entre as mulheres nulíparas (n = 919) (OR 0,6 [IC 95% 0,2 a 1,0]) mas não entre as multíparas.  
Outro estudo realizado na Suécia investigou os efeitos da posição de mãos-e-joelhos (quatro apoios) em comparação com a posição sentada, sobre a duração do segundo período do parto<sup>302</sup> [NE = 1+]. Mulheres alocadas para a posição de quatro apoios foram mais propensas a relatar maior conforto no parto (OR 0,5 [IC 95% 0,1-0,9], P = 0,030) e menos propensas a considerar o segundo período longo (apesar de não haver diferença significativa na duração real da segunda fase entre os dois grupos) (OR [IC 95% 0,8-0,9] 1,4, P = 0,002). Relataram também menos dor (OR [IC 95% 1,1-1,9] 1,3, P = 0,01) e menos dor perineal nos 3 primeiros dias pós-parto (OR 1,9 [IC 95% 1,3-2,9], P = 0,001) em comparação com as mulheres do grupo controle. Não houve diferenças significativas nos desfechos clínicos tanto para as mulheres (incluindo grau de trauma perineal) ou seus bebês.  
14.1.3.3 Imersão em água no segundo período do trabalho de parto  
Em relação à imersão em água no segundo período do trabalho de parto, as diretrizes do NICE (2014) incluíram dois estudos<sup>91,303</sup> . No último ensaio, apenas 23 das 60 mulheres alocadas para a imersão realmente o fizeram. Não foram encontradas diferenças na frequencia de intervenções ou complicações para as mulheres ou os recém-nascidos.  
Um estudo transversal relatou uma mortalidade perinatal de 1,2/1.000 [IC 95% 0,4 a 2,9] e uma taxa de admissão em unidade neonatal de 8,4/1.000 [IC 95% 5,8 a 11,8] para os recém-nascidos após parto na água, comparados com três outros relatórios de mortalidade perinatal (de 0,8 a 4,6/1.000) e uma taxa de admissão em unidade neonatal de (9,2 a 64/1.000) de estudos em populações de baixo risco.<sup>304</sup> 14.1.4 Resumo da Evidência e conclusões  
Há evidências de alto nível demonstrando que a posição supina (decúbito dorsal horizontal) no segundo período do trabalho de parto aumenta a incidência de parto vaginal instrumental, aumenta a dor e pode aumentar a incidência de anormalidades da freqüência cardíaca fetal, embora não haja informações sobre o puxo. Não há diferença na proporção de mulheres que dão à luz com um períneo intacto. O uso de uma cadeira ou banco de parto está associado a um registro de sangramento maior que 500 mL. Há também algumas evidências de alto nível demonstrando que o uso da posição de mãos-e-joelhos (quatro apoios) no segundo período do trabalho de parto, reduz a dor e não há efeitos adversos sobre os resultados maternos ou neonatais.  
Em relação a imersão em água no segundo período do trabalho de parto as evidências são escassas e de baixa qualidade não permitindo uma avaliação mais clara sobre riscos e benefícios clínicos. 14.1.5 Recomendação sobre a posição e imersão em água no segundo período do trabalho de parto: 113. Deve-se desencorajar a mulher a ficar em posição supina, decúbito dorsal horizontal, ou posição semi-supina no segundo período do trabalho de parto. A mulher deve ser incentivada a adotar qualquer outra posição que ela achar mais confortável incluindo as posições de cócoras, lateral ou

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: quatro apoios -->
114. Informar às mulheres que há insuficiência de evidências de alta qualidade, tanto para apoiar como para desencorajar o parto na água.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.2.1 Introdução -->
Ainda é muito comum, embora não havendo registros oficiais, a adoção de puxos dirigidos e orientados de rotina, assim como a manobra de Kristeller, na assistência no segundo período do trabalho de parto. A manobra de Kristeller consiste na compressão do fundo uterino durante o segundo período do trabalho de parto objetivando a sua abreviação. Embora rotineiras, tais medidas necessitam de uma análise crítica das evidências disponíveis para se determinar os seus reais benefícios, assim como os riscos associados à sua utilização.  
14.2.2 Questões de revisão  
- Qual é a efetividade das diferentes técnicas de puxo durante o segundo período do parto nos resultados maternos e neonatais?  
- Qual é o momento ideal para recomendar puxos dirigidos?  
- Quais os efeitos da manobra de Kristeller no segundo período do parto nos resultados maternos e perinatais?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.2.3.1 Puxos e suas técnicas -->
As diretrizes do NICE (2014) incluíram cinco ERC que avaliaram o puxo na segunda etapa do trabalho de parto, os quais são descritos a seguir. Em todos os estudos incluídos, as mulheres não receberam analgesia peridural.  
Um ERC realizado nos EUA<sup>305</sup> [NE = 1+] alocou mulheres nulíparas em dois grupos : grupos com puxos orientados ou dirigidos (n= 163) em que as mulheres recebiam instruções sobre como fazer força com a glote fechada durante as contrações, motivando-as a respirar normalmente entre as contrações; e grupo de mulheres sem orientações (n=157) que foram atendidas pelo mesmo grupo de Enfermeiras obstétricas/obstetrizes que não orientavam o puxo e eram incentivadas a agir “para o que viesse naturalmente”. A média de duração do segundo estágio foi menor nas mulheres com puxos orientados e dirigidos comparada ao grupo que agiu por si, naturalmente. (46 min X 59 min, p=0.014). Não houve diferença em outros desfechos maternos e neonatais.  
O outro ERC, também realizado nos EUA<sup>306</sup> , incluindo 128 mulheres, teve o objetivo de determinar se a abstenção de dirigir os puxos influenciaria as dimensões uroginecológicas pós–parto e a função do assoalho pélvico. As mulheres foram randomizadas no momento da dilatação total para realizarem puxos dirigidos ou não. A avaliação do assoalho pélvico foi realizada 3 meses após o parto por enfermeiras mascaradas em relação ao tipo de puxo realizado. Não houve diferenças significativas entre os dois grupos em relação a fatores demográficos, prolongamento do segundo estágio do trabalho de parto (˃ 2 horas), taxas de episiotomia, lacerações do esfíncter anal, uso de analgesia peridural, fórceps, ocitocina e recém-nascido pesando mais que 4kg. O teste urodinâmico revelou diminuição da capacidade vesical (p=0.051) e diminuição da sensibilidade vesical ao primeiro desejo de urinar (p=0.025) no grupo de puxo orientado.  
O ERC dinamarquês comparou o puxo espontâneo (n=151) com a técnica “forçada” de prender a respiração (n=151)<sup>307</sup> [NE = 1+] na fase final da segunda etapa do trabalho de parto em mulheres que iam ter parto vaginal pela primeira vez (a amostra também incluiu mulheres que tinham tido cesárea  
prévia, mas não relatou a quantidade). Os puxos orientados não foram encorajados até que a cabeça do bebê estivesse visível. Até este momento, as mulheres poderiam realizar puxos como desejassem, sem orientação e ajuda da Enfermeira obstétrica/obstetriz. O recrutamento no estudo foi difícil e  das 1.413 mulheres elegíveis, somente 350 participaram. As razões foram a relutância da mulher de ser alocada para o grupo de puxo espontâneo quando percebiam que não teriam a orientação e o suporte da obstetriz. Ademais, em 44 mulheres randomizadas não foi possível o seguimento, pois tiveram que fazer cesárea. Essas dificuldades enfraqueceram a confiabilidade dos resultados. Os dois grupos seguidos eram semelhantes em relação às características maternas e do bebê. Não houve diferenças significativas entre eles em relação à duração do trabalho de parto, do segundo estágio, do segundo estágio expulsivo (a partir do vértice cefálico visível até o nascimento), tipo de parto, trauma perineal, escore de Apgar e pH de sangue da artéria umbilical. Os autores explicam estas similaridades em termos de não conformidade com a técnica de puxo orientada. O uso frequente de ocitocina (40,1% no grupo espontâneo e 45,8% no grupo orientado) e de episiotomia (36% no grupo espontâneo e 30% no grupo orientado) também podem ter contribuído para estes resultados.  
O ERC realizado na Inglaterra avaliou os efeitos do puxo espontâneo (n=15) versus o puxo  dirigido com a técnica de prender a respiração (n=17)<sup>308</sup> [NE = 1-]. Os dois grupos  foram bem pareados em relação às características maternas e recém-nascido, mas não foi incluída a posição fetal . A duração do primeiro estágio de trabalho de parto foi significativamente maior no grupo de puxo espontâneo (média 12.32 hs [DP 5.13] versus 7.88 hs [DP 2.62], p=0.005). Não houve outras diferenças significativas em relação ao primeiro estágio de parto, incluindo o uso de Entonox, petidina ou necessidade de infusão intravenosa. Não foi mencionado o uso de ocitocina. Não houve diferenças em relação ao tipo de parto, trauma perineal, perda de sangue materna, ressuscitação neonatal e gasometria de sangue de cordão. A percepção da mulher no segundo estágio de trabalho de parto foi similar entre os dois grupos e foi avaliada por uma escala visual analógica (ex: Como foi a parte do puxo durante o seu trabalho de parto”, "Quão satisfeita você se sente com a forma como você lidou na parte do puxo durante seu trabalho de parto?”). O segundo estágio do trabalho de parto foi significantemente maior no grupo de puxo espontâneo (média de 121,4 min [DP 58,4 min] versus 58 min [DP 42 min], p= 0,002). As diferenças em relação à duração das primeiras etapas do trabalho de parto, que foram significativamente maiores neste grupo, podem ter contribuído por essas diferenças, em vez de serem imputadas somente às diferentes técnicas de puxo empregadas.  
O último ERC dos EUA, comparou a técnica de puxo com respiração prolongada (n=10) com a técnica de puxo com exalação (n=17)<sup>309</sup> [NE = 1-]. Todas as mulheres deram a luz sentadas em uma cadeira de parto. A amostra final de mulheres representa uma proporção bastante reduzida das 94 mulheres que inicialmente concordaram em participar do estudo. Não está claro no estudo quando a randomização foi realizada, mas parece que um certo número de mulheres foram descartados da análise após a randomização por não cumprirem o protocolo do estudo, por exemplo, não usar a cadeira de parto para a segunda fase (n= 20) ou não utilizar o puxo designado (n = 9). Não houve diferenças significativas na duração da segunda fase de trabalho de parto entre os dois grupos (média = 45,6 minutos para ambos os grupos). Algumas diferenças foram descritas nos padrões de Frequência Cardíaca Fetal (FCF) entre os dois grupos, com um aumento de desacelerações no grupo com respiração prolongada (30% versus 17,6%, sem valor de P). No entanto, o significado clínico deste achado não é discutido e não há avaliação de resultados clínicos, por exemplo, os escores de Apgar, a necessidade de ressuscitação e a admissão à UTI neonatal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.2.3.2 Momento dos puxos -->
As diretrizes do NICE (2014) não avaliaram o momento ideal dos puxos em mulheres sem analgesia, apenas foram avaliados os puxos tardios ou imediatos em mulheres com analgesia. Para responder esta questão, as diretrizes do Nice incluíram 4 estudos. Entretanto, apenas 3 responderam especificamente à pergunta. Os mesmos são descritos a seguir  
Uma RS incluindo 9 estudos, com um total de 2.953 mulheres comparou os benefícios e prejuízos de uma conduta de puxos atrasados entre as mulheres que tiveram partos sem complicações e com analgesia peridural estabelecida na primeira etapa do parto<sup>228</sup> [NE = 1+]. Foram excluídas mulheres com complicações médicas ou obstétricas em vários estudos. Os estudos variaram em relação à conduta na fase ativa da segunda etapa do trabalho de parto e nas diferentes técnicas de puxo e de uso de ocitocina. A qualidade metodológica dos estudos incluídos foi variada. O tempo para iniciar os puxos no grupo experimental (puxos atrasados) variou entre os diferentes estudos, de 1 a 3 horas. Em relação ao parto instrumental, a meta-análise apontou uma redução significativa de partos instrumentais rotacionais ou por fórceps no grupo com puxos atrasados (RR de 0,69 [IC 95% de 0,55 a 0,87]. A metaanálise de cinco ensaios demonstrou uma redução de 31% na taxa de parto vaginal instrumental rotacional ou no estreito médio no grupo de puxos atrasados (RR 0.69 [IC 95% 0,55 a 0,87]). A duração do segundo período do trabalho de parto foi significativamente maior no grupo de puxos atrasados (três ensaios DMP 58,2 minutes [IC 95% 21,51 a 94,84 minutos]). A duração da fase ativa do segundo período foi variável entre os estudos, e a meta-análise de dois estudos que a relataram não demonstraram diferenças significativas entre os grupos (DMP 1,11 minutos [IC 95% −20,19 a 22,40 minutos]). Um dos estudos não demonstrou diferenças significativas na ocorrência de febre intra-parto entre os grupos e outros encontrou uma incidência significativamente maior de febre no grupo de puxos atrasados. Em um estudo não foram encontradas diferenças significativas na incidência de morbidade do assoalho pélvico 3 meses após o parto entre os grupos. Os poucos estudos que relataram desfechos neonatais não encontraram diferenças significativas entre os grupos.  
O ERC realizado nos EUA<sup>229</sup> [NE = 1+] comparou 2 grupos de mulheres nulíparas em trabalho de parto induzido a termo, com analgesia peridural e uso de ocitocina com puxo imediato (n=22) e puxo tardio (n= 23). O grupo com puxo imediato iniciou o puxo quando se atingiu a dilatação completa, e as mulheres foram treinadas para prender a respiração e empurrar entre três e quatro vezes em um total de dez tentativas durante cada contração. Com relação ao grupo com puxo com atraso, recomendou-se esperar até que sentissem necessidade de empurrar ou quando já haviam passado 2 horas da segunda etapa. Durante o puxo, foram estimuladas a empurrar sem prender a respiração por não mais que 6-8 segundos em cada puxo. Os dois grupos foram semelhantes nas variáveis demográficas, ainda que as mulheres do grupo com puxo imediato fossem significativamente maisjovens. A segunda etapa foi mais longa no grupo com puxos com atraso (duração média de 38 minutos maior [p < 0,01]), mas a duração do momento do puxo ativo foi maior no grupo com puxo imediato (duração média de 42 minutos maior [p = 0,002]). A queda na saturação de oxigênio fetal foi significativamente maior no grupo com puxo imediato e as desacelerações da frequência cardíaca fetal foram mais variáveis e prolongadas. Não houve diferenças significativas em outras variáveis tais como: cesariana, parto vaginal instrumental, 2<sup>o</sup> período prolongado (> 3 horas), episiotomia, gasometria do cordão umbilical, escore de Apgar ou outros padrões de frequência cardíaca fetal. Houve maior ocorrência de lacerações perineais no grupo com puxo imediato (n=13 versus n = 5, X<sup>2</sup> = 6,54; p = 0,01). 1+  
Por último, o estudo de coorte realizado na Irlanda comparou os puxos com atraso com puxos precoces  
durante a segunda etapa do parto<sup>227</sup> [NE = 2+]. Todas as mulheres eram nulíparas ou estavam no termo da gravidez e eram semelhantes quanto à idade e peso nos dois grupos. Não foram dados detalhes com relação a posição dos neonatos ou situação da segunda etapa no nascimento. No grupo tardio (n = 194), aconselhou-se puxar quando a cabeça ficasse visível ou já tivessem transcorrido 3 horas desde a dilatação completa; no grupo com puxos precoces (n = 219), foram estimuladas a realizar puxos enquanto começava a 2<sup>a</sup> etapa. A duração da 2<sup>a</sup> etapa foi maior no grupo com puxos em atraso (p < 0,001), apesar de que se esperava uma média de 0,7 hora antes de se começar a puxar no grupo com puxos precoces e uma média de 0,9 hora no grupo com puxos em atraso. O uso de fórceps não rotacional foi menor no grupo com puxos em atraso (44,84% em comparação com 54,79%; p < 0,04). Os padrões cardíacos fetais anormais ou o aparecimento de mecônio foram mais comuns no grupo com puxo em atraso (27,8% em comparação com 3,91%; p < 0,01); e o número de admissões em unidades de terapia intensiva neonatal também foi maior no grupo com puxos em atraso (14 em comparação com 5; p = 0,017). Não foram encontradas diferenças no índice de partos espontâneos, índice de episiotomias, complicações no 3<sup>o</sup> período, escores de Apgar, necessidades de intubação do recém-nascido ou morbidade pós-natal.  
14.2.3.3 Manobra de Kristeller  
Para responder esta questão, utilizaram-se as diretrizes espanholas, uma vez que a do NICE não abordou o tema.  
As diretrizes espanholas incluíram um documento da OMS, “Cuidados com o Parto Normal: Um Guia Prático” publicado em 1996, o qual recomenda como grau C a manobra de Kristeller, especificando que se trata de uma prática da qual não existem claras evidências para fomentá-la e que deveria ser usada com cuidado, até que novos estudos esclareçam o tema. Adicionalmente, fez uma atualização dessa diretrizes até 2009 e selecionou 2 ERCs<sup>310,311</sup> e uma Revisão Sistemática<sup>312</sup> .  
A Revisão Sistemática incluiu apenas um estudo e avaliou se a pressão no fundo uterino (ou manobra de Kristeller) era eficaz para obter um parto espontâneo e para prevenção de uma segunda etapa de parto prolongada ou um parto instrumental, assim como também os possíveis efeitos maternos e fetais relacionados com a manobra  
O ERC incluído foi realizado em Londres e incluiu 500 mulheres nulíparas com analgesia peridural para determinar se uma cinta obstétrica inflável para aplicação de pressão no fundo uterino durante a contração reduziria as taxas de parto instrumental quando utilizada no segundo período do parto<sup>310</sup> [NE = 1+]. Um total de 42,7% das 260 mulheres no grupo com cinta apresentou parto espontâneo, em comparação com 39,2% das 240 no grupo controle, ainda que essa diferença não tenha sido significativa (p = 0,423). A taxa de partos instrumentais foi semelhante entre os dois grupos (RR de 0,94 [IC 95% de 0,80 a 1,11]), sem diferenças significativas, assim como a taxa de cesarianas. O períneo ficou intacto em mais casos entre as mulheres no grupo com intervenção (RR de 1,73 [IC 95% de 1,07 a 2,77]), assim como laceração de esfíncter anal (RR de 15,69 [IC 95% de 2,10 a 117,02]).  
A revisão concluiu que a manobra de Kristeller, realizada através de uma cinta inflável, não aumenta a taxa de partos vaginais espontâneos e nem reduziu a taxa de parto instrumental, que as provas de seu efeito sobre o períneo não são concludentes e que as evidências sobre segurança do neonato são insuficientes.  
O outro ERC incluído, tinha como objetivo determinar o efeito da realização da manobra de Kristeller sobre o encurtamento da segunda etapa do parto e sobre os resultados fetais<sup>311</sup> [NE = 1+]. Foram incluídas 197 mulheres com 37 a 42 semanas de gestação e que não haviam recebido nenhum tipo de  
analgesia neuroaxial. Os resultados não demonstraram diferenças significativas na duração média da segunda etapa do trabalho de parto entre os dois grupos, nem nasmedidas de resultados secundárias (pH da artéria umbilical, HCO3-, excessode base, pO2, valores de pCO2 e taxa de partos instrumentais, morbidadematerna grave e mortalidade, traumatismos neonatais, admissão em unidadeneonatal de terapia intensiva e morte neonatal), exceto quanto aos valores depO2 (que ficaram mais baixos no grupo com intervenção) e de pCO2 (queforam maiores). No entanto, os valores ainda se mantiveram dentro dasfaixas normais e não houve nenhum recém-nascido com pontuação de Apgar < 7 em nenhum dos grupos. Conclui-se que a manobra de Kristeller é ineficaz na redução da segunda etapa do trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.2.4 Resumo da evidência e conclusões -->
Não existem evidências de alto nível que comprove se o puxo dirigido ou orientado em mulheres sem anestesia peridural afeta os resultados.  
Não existem evidências do benefício da manobra de Kristeller realizada no segundo período do parto e, além disso, existem algumas evidências, ainda que escassas, de que tal manobra constitui um fator de risco de morbidade materna e fetal, pelo que se considera que sua realização deve ser limitada a protocolos de investigação desenhados para avaliar sua eficácia e segurança para a mãe e o feto. 14.2.5 Recomendações em relação aos puxos e manobra de Kristeller  
115. Deve-se apoiar a realização de puxos espontâneos no segundo período do trabalho de parto em mulheres sem analgesia, evitando-se os puxos dirigidos.  
116. Caso o puxo espontâneo seja ineficaz ou se solicitado pela mulher, deve-se oferecer outras estratégias para auxiliar o nascimento, tais como suporte, mudança de posição, esvaziamento da bexiga e encorajamento.  
117. Em mulheres com analgesia regional, após a confirmação da dilatação cervical completa, o puxo deve ser adiado por pelo menos 1 hora ou mais, se a mulher o desejar, exceto se a mulher quiser realizar o puxo ou a cabeça do bebê estiver visível. Após 1 hora a mulher deve ser incentivada ativamente para realizar o puxo durante as contrações.  
118. A manobra de Kristeller não deve ser realizada no segundo período do trabalho de parto. 14.3 Definição e duração do segundo período do trabalho de parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.3.1 Introdução -->
Na assistência ao trabalho de parto, as definições das suas fases são importantes, principalmente para que todos aqueles envolvidos nos cuidados tenham uma compreensão comum dos conceitos envolvidos para facilitar a comunicação e a atuação efetiva quando desvios da normalidade forem detectados. Também faz-se necessário analisar as evidências disponíveis relacionadas à duração do segundo período do trabalho de parto e os desfechos perinatais.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.3.2  Questões de revisão -->
- Qual a definição e duração das fases do segundo período do parto?  
- A duração e progresso do segundo período do parto influencia nos desfechos?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.3.3 Evidências Científicas -->
As diretrizes do NICE (NCCWCH, 2014) não incluíram nenhum estudo relevante que tenha investigado os desfechos relacionados com as diferentes definições de trabalho de parto. Várias definições que são utilizadas na prática ou na pesquisa foram exploradas. Seis estudos descritivos, investigando a duração do trabalho de parto, foram utilizados para informar sobre as definições do trabalho de parto O segundo período do trabalho de parto começa com a dilatação completa do colo do útero. Além disso,  
para o diagnóstico dessa fase, pode ser considerado o início do puxo materno, o que diferencia a fase ativa do segundo período da sua fase passiva.  
Em relação à duração da segunda fase do trabalho de parto, três estudos foram identificados. Em alguns casos, os fatores associados com a duração do trabalho de parto também foram investigados [NE = 3]. Um estudo norte-americano envolvendo 2.511 mulheres em trabalho de parto espontâneo a termo, com baixo risco de desenvolvimento de complicações durante o parto e que não receberam ocitocina ou peridural teve como objetivo descrever a duração dos estágios ativos do trabalho de parto e os fatores clínicos<sup>262</sup> . A duração média do segundo período foi de 54 minutos para mulheres nulíparas e 18 minutos para as mulheres multíparas (limites superiores: 146 e 64 minutos, respectivamente). A análise multivariada por regressão logística mostrou que o monitoramento eletrônico fetal contínuo e deambulação no trabalho de parto estiveram significativamente associados a maior tempo de trabalho de parto. Além disso, a analgesia narcótica associou-se a maior tempo de trabalho de parto em multíparas e a idade materna acima de 30 anos em nulíparas.  
Outro estudo<sup>261</sup> observou uma duração média do segundo estágio do trabalho de parto de 53 minutos para mulheres nulíparas e 17 minutos para as mulheres multíparas (limites superiores: 147 e 57 minutos, respectivamente). Uma análise secundária<sup>277</sup> usando dados de nascimento entre 1976-1987 de 6.991 mulheres observou uma duração média e os limites superiores (percentil 95) de tempo para o segundo período: nulíparas sem anestesia de condução = 54 minutos (132 minutos), com anestesia de condução = 79 minutos (185 minutos); multíparas sem anestesia de condução = 19 minutos (61 minutos), com anestesia de condução = 45 minutos (131 minutos).  
Em relação à duração do segundo período do trabalho de parto e os desfechos maternos e perinatais, foram incluídos dez estudos observacionais que investigaram essa associação. A qualidade dos estudos variou.  
Um grande estudo de corte transversal realizado nos EUA (n = 15.759) investigou a duração prolongada do segundo período (mais de 4 horas) em relação a alguns desfechos<sup>313</sup> [NE = 3]. A análise de regressão logística, controlando para vários fatores de confusão, mostrou que não houve evidência de associação entre um segundo período prolongado e corioamnionite (OR [IC 95% 1,44-2,22] 1,79), lacerações de terceiro ou quarto grau (OR 1,33 [95 CI% 1,07-1,67]), incidência de cesárea (OR 5,65 [IC 95% 4,46-7,16]), parto vaginal instrumental (OR 2,83 IC [95% 2,38-3,36]) ou Apgar <7 em 5 minutos (OR 0,45 [95% IC 0,25-0,84]). Não foi demonstrada associação entre um segundo período prolongado e a incidência de endomiometrite (OR 0.79 [IC 95% 0,49 a 1,26]), hemorragia pós-parto (OR 1,05 [IC 95% 0,84 a 1,31]), líquido amniótico meconial (OR 1,11 [IC 95% 0,93 a 1,33]) ou admissão em unidade neonatal (OR 0,59 [IC 95% 0,35 a 1,03]).  
Outro grande estudo transversal realizado nos EUA (n = 7.818) comparou o segundo período prolongado (121+ minutos) com a duração normal (1-120 minutos) em relação a desfechos definidos<sup>314</sup> [NE = 3] e a análise, não controlada, mostrou algumas evidências de que o segundo período prolongado (mais de 120 minutos) está associado a várias intervenções médicas.  
Outro estudo transversal alemão (n = 1.200)<sup>315</sup> [NE = 3] observou evidência de uma associação de segundo período prolongado com baixo índice de Apgar no 1<sup>o</sup> minuto, hemorragia pós-parto, lacerações perineais e febre pós-parto, embora as análises não tenham sido controladas por fatores de confusão. Um estudo transversal realizado em Taiwan (n = 1.915)<sup>316</sup> [NE = 3] não mostrou nenhuma evidência de uma associação entre segundo período prolongado e resultados intraparto adversos, maternos e neonatais.  
Outro grande estudo transversal canadense (n = 6.041)<sup>317</sup> [NE = 2+] não identificou nenhuma evidência de associação entre a duração do segundo período e baixos índices de Apgar no 5<sup>o</sup> minuto, convulsões neonatais ou internação em UTIs neonatais.  
Um grande estudo transversal realizado no Reino Unido (n = 25.069) que avaliou o segundo período prolongado<sup>318,319</sup> observou evidência de associação entre a duração mais longa do segundo período e hemorragia pós-parto (duração: 120-179 minutos OR 1,6 [IC 95% 1,3 a 1,9]; 180-239 minutos OR 1,7 [IC 95% 1,3 a 2,3]; 240+ minutos OR 1,9 [IC 95% 1,2-2,8]), mas não houve evidência de associação com infecção pós-parto (120–179 minutos OR 1,1 [IC 95% 0,9 a 1,4]; 180–239 minutos OR 1,1 [IC 95% 0,7 a 1,6]; 240+ minutos OR 1,2 [IC 95% 0,7 a 2,0])  ou índice de Apgar menor que 7 no 5º minuto (120–179 minutos OR 1,3 [IC 95% 0,8 a 2,0]; 180–239 minutes OR 0,9 [IC 95% 0,3 a 2,3]; 240+ minutos OR 1,9 [IC 95% 0,8 a 4,7]).  
Uma estudo caso-controle (n = 173) não encontrou nenhuma evidência de uma associação entre incontinência urinária de esforço 7-8 anos após o nascimento e a duração do segundo período do trabalho de parto (OR 1,07 [IC 95% 0,9 a 1,3])<sup>320</sup> [NE = 2+].  
Estudo de base populacional dos Estados Unidos (n = 1432)<sup>321</sup> [NE = 2+], sem controle de fatores de confusão, mostrou evidências de associação entre maior duração do segundo período e aumento das taxas de cesariana e parto vaginal instrumental. Não houve associação com quaisquer resultados neonatais adversos.  
Um pequeno estudo descritivo longitudinal estadunidense<sup>264</sup> [NE = 2−] não encontrou nenhuma associação entre a duração do segundo período do parto e escores de ansiedade  (inter-correlação −0,24).  
Um grande estudo transversal Americano (n = 4.403)<sup>322</sup> [NE = 2−], que não controlou para variáveis de confusão, não demonstrou evidências de associação entre a duração do segundo estágio do trabalho de parto e desfechos neonatais, exceto por um baixo escore de Apgar no 1<sup>o</sup> minuto (P < 0.03). A hemorragia e a morbidade febril puerperal demonstraram alguma evidência de associação com a duração do trabalho de parto (P < 0,001 para ambos).  
14.3.4 Conclusões e resumo da evidência  
Um resumo com a duração média e os limites máximos para a duração do segundo período do trabalho de parto de mulheres sem analgesia envolvendo todos os estudos descritos está apresentado na tabela 24.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Tabela 24 - Resumo duração do segundo período do trabalho de parto -->
||Média(DP)- minutos|Limite superior(média + 2 DP)|
|---|---|---|
|Nulíparas(n = 3.664)|54(44)|142|
|Multíparas(n = 6.389)|18(21)|60|  
Estes números não são precisos porque foram calculados utilizando média e desvio padrão, assumindo uma distribuição normal, o que não ocorre na duração do trabalho de parto.  
A limitada qualidade das evidências torna difícil avaliar o impacto de um segundo período prolongado sobre os desfechos maternos e perinatais.  
14.3.5 Recomendação em relação à definição e duração do segundo período do parto  
119. Para fins destas Diretrizes, o segundo período do parto deverá ser definido como:  
- Fase inicial ou passiva: dilatação total do colo sem sensação de puxo involuntário ou parturiente com analgesia e a cabeça do feto ainda relativamente alta na pelve.  
- Fase ativa: dilatação total do colo, cabeça do bebê visível, contrações de expulsão ou esforço  
materno ativo após a confirmação da dilatação completa do colo do útero na ausência das contrações de expulsão.  
120. Se a dilatação completa do colo uterino for confirmada em uma mulher sem analgesia regional e não for identificado puxo, uma nova avaliação mais aprofundada deverá ser realizada em 1 hora para identificação da fase do segundo período.  
121. A distribuição dos limites de tempo encontrados nos estudos para a duração normal da fase ativa do segundo período do trabalho parto é a seguinte:  
- Primíparas:  cerca de 0,5–2,5 horas sem peridural e 1–3 horas com peridural.  
- Multíparas:  até 1 hora sem peridural e 2 horas com peridural.  
122. Para a conduta na falha de progresso do segundo período deve-se considerar a paridade, da seguinte maneira:  
- Nulíparas:  
- Na maioria das mulheres o parto deve ocorrer no prazo de 3 horas após o início da fase ativa do segundo período.  
- A confirmação de falha de progresso no segundo período deve ser feita quando este durar mais de 2 horas e a mulher deve ser encaminhada, ou assistência adicional solicitada, a médico treinado na realização de parto vaginal operatório se o nascimento não for iminente.  
- Multíparas:  
- Na maioria das mulheres o parto deve ocorrer no prazo de 2 horas após o início da fase ativa do segundo período.  
- A confirmação de falha de progresso no segundo período deve ser feita quando este durar mais de 1 hora e a mulher deve ser encaminhada, ou assistência adicional solicitada, a médico treinado na realização de parto vaginal operatório se o nascimento não for iminente.  
14.4 Falha de progresso no segundo período do parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.4.1 Questão de revisão -->
 Como identificar e atuar na falha de progresso no segundo período do parto? Ver a recomendação 122 para a identificação da falha de progresso no segundo período do parto. Nas seções seguintes serão descritas e analisadas as evidências em relação às diversas intervenções na parada de progresso no segundo período do trabalho de parto.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.4.2 Evidências Científicas -->
Nas diretrizes do NICE foram consideradas algumas intervenções na parada de progresso no segundo período do parto mas não foram encontrados estudos que avaliassem as seguintes intervenções: ocitocina comparada com conduta expectante e ocitocina comparada com parto vaginal instrumental. Em relação a outras intervenções as evidências são descritas e analisadas as seguir.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.4.2.1 Ventosa versus fórceps -->
Foi incluída uma revisão sistemática que por sua vez incluiu dez ensaios realizados nos EUA, Dinamarca, Suécia, Reino Unido, África do Sul e Grécia<sup>323</sup> . Além da RS, três outros ensaios mais recentes realizados no Sri Lanka<sup>324</sup> , Paquistão<sup>325</sup> e Irlanda<sup>326</sup> foram incluídos [NE = 1+]. Foram incluídos também outros dois estudos de seguimento de ensaios incluídos na RS, os quais investigaram os desfechos de longo prazo das mães e das crianças. Estes estudos foram conduzidos no Reino Unido.<sup>327,328</sup> 14.4.2.1.1 Eventos do parto  
A meta-análise de nove ensaios demonstrou que o parto vaginal assistido por ventosa está mais associado a falhas do procedimento com os instrumentos selecionados comparado com o parto assistido por fórceps (n = 2.849, OR 1,69 [IC 95% 1,31, 2,19]).<sup>329</sup> Outro ensaio recente realizado no Paquistão demonstrou a mesma associação (n = 442, RR 2,04 [IC 95% 114, 3,70]).<sup>325</sup> Não houve diferenças nas taxas de cesariana (meta-análise de sete ensaios, n = 1.662, OR 0,56 [IC 95% 0,31, 1,02]). A meta-análise de 12 ensaios demonstrou uma redução significativa do uso de anestesia com o parto assistido por ventosa (n = 5.051, OR 0,59 [IC 95% 0,51, 0,68]). 14.4.2.1.2 Complicações maternas  
A meta-análise demonstrou que o parto assistido por ventosa reduziu significativamente o trauma materno (sete ensaios, n = 2.582): OR 0,41 [IC 95% 0,33 a 0,50] e dor perineal grave em 24 horas (dois ensaios, n = 495): OR 0,54 [IC 95% 0,31 a 0,93]. O ensaio Paquistanês também evidenciou um redução significativa nas lacerações cervicais e trauma perineal de terceiro grau no grupo de parto assistido por ventosa comparado com o grupo de parto assistido por fórceps (n = 442: RR 0,19 [IC 95% 0,04 a 0,86]). 14.4.2.1.3 Desfechos neonatais  
A meta-análise demonstrou que o parto assistido por ventosa aumentou a incidência de cefalohematoma (seis ensaios, n = 1.966): OR 2,38 [IC 95% 1,68 a 3,37] e hemorragia de retina (cinco ensaios, n = 445): OR 1,99 [IC 95% 1,35 a 2,96]. O ensaio Paquistanês também demonstrou a mesma associação do parto assistido por ventosa com cefalohematoma (n = 442): RR 7,14 [IC 95% 1,59 a 33,33]. Houve também um aumento não significativo nos escores baixos de Apgar aos 5 minutos nos partos assistidos por ventosa (cinco ensaios, n = 1.545): OR 1,67 [IC 95% 0,99 a 2,81]. A meta-análise não demonstrou diferenças nos escores de Apgar menor que 7 com 1 minuto (meta-análise de três ensaios, n = 822): OR 1.13 [IC 95% 0,76 a 1,68]; e no ensaio do Sri Lanka (n = 50): RR 0,85 [IC 95% 0,24 a 3,03]; lesões de couro cabeludo ou face (não cefalohematoma) (seis ensaios, n = 2.330): OR 0,89 [IC 95% 0,70 a 1,13]; uso de fototerapia (quatro ensaios, n = 1.648): OR 1,08 [IC 95% 0,66 a 1,77]; mortalidade perinatal (sete ensaios, n = 1.800): OR 0,80 [IC 95% 0,18 a 3,52]; seguimento/readmissão no hospital (um ensaio,<sup>330</sup> n = 232): OR 1,33 [IC 95% 0,58 a 3,05]; audição anormal (confirmada/suspeita) (um ensaio,<sup>330</sup> n = 232):OR 1,66 [IC 95% 0,54 a 5,06]; e estrabismo ou anormalidade suspeita da visão (um ensaio,<sup>330</sup> n = 232): OR 1,38 [IC 95% 0,47 a 4,05]. O estudo do Sri Lanka também não demonstrou diferenças nas complicações neonatais (n = 50): RR 1,00 [IC 95% 0,72 a 1,39]. 13.4.2.1.4 Desfechos mentais e psicológicos e satisfação das mulheres  
A meta-análise de três ensaios demonstrou que as preocupações das mães em relação aos seus bebês aumentaram significativamente com parto assistido por ventosa (n = 561): OR 2,17 [IC 95% 1,19 a 3,94]. O estudo Irlandês investigou a satisfação das mulheres e não demonstrou diferenças (escolheria cesariana para o próximo parto): RR 0,53 [IC 95% 0,23 a 1,27]. Na RS, apenas dois ensaios incluiu avaliação da dor pela mulher durante o parto .<sup>331,332</sup> Um ensaio que comparou os métodos de parto instrumental continha um sub-estudo sobre as visões das mulheres e dos médicos obstetras e Enfermeiras obstétricas ou obstetrizes.<sup>332</sup> A sub-amostra de 66 das 304 mulheres que participaram do ensaio foram entrevistadas entre o primeiro e oitavo dia pós-parto. Apesar de terem recebido mais analgesia, 12 das 33 mulheres que foram submetidas ao fórceps consideraram o parto ‘muito’ ou ‘extremamente doloroso, comparadas com 7 das 33 que foram submetidas ao parto por vácuo-extrator. Achados similares foram relatados em outro estudo o qual demonstrou que 27% (n = 28) das mulheres consideraram o parto por fórceps ‘insuportável’ comparado com 18% (n = 19) das mulheres submetidas ao vácuo-extrator: OR 1,5 [IC 95% 0,5 a 4,2].<sup>331</sup>  
Um terceiro estudo concluiu que houve significativamente menos mulheres no grupo de vácuo-extrator que requereu peridural ou anestesia espinhal (25,4% versus 32,7%) ou anestesia geral (1% versus 4%) comparado com o grupo de fórceps.<sup>333</sup>  
14.4.2.1.5 Desfechos de médio e longo prazo  
O estudo de seguimento do Reino Unido demonstrou uma incidência significativamente menor de defeitos do esfíncter anal com o uso da ventosa (RR 0,58 [IC 95% 0,32 a 0,92]); e pressão anal máxima maior (ventosa, média = 38; fórceps, média = 53; P = 0,02); sem diferenças na incontinência anal (RR 1,47 [IC 95% 0,44 a 4,92]); e pressão anal máxima de repouso (ventosa, média = 55; fórceps, média = 60; P = 0,32) no final dos 5 anos de seguimento.<sup>328</sup> Outro estudo com a mesma população não demonstrou diferenças nos hábitos urinários e intestinais das mulheres após 5 anos.<sup>327</sup> Este estudo também não demonstrou diferenças nos problemas visuais (OR 0,9 [IC 95% 0,38 a 2,5]) ou de desenvolvimento das crianças.  
O estudo Irlandês de longo prazo (3 meses) demonstrou uma redução significativa de incontinência (RR 0,35 [IC 95% 0,17 a 0,71]) e uma tendência para uma maior pressão anal entre as mulheres que tiveram o parto assistido por ventosa: pressão de repouso (mmHg) (ventosa mediana = 63, fórceps mediana = 54, P = 0,05); pressão de aperto (mmHg) (ventosa mediana = 96, fórceps mediana = 86, P = 0,11); pressão de incremento (mmHg) (ventosa mediana = 25, fórceps mediana = 27, P = 0,12); índice de vetor de simetria (RR 0,77 [IC 95% CI 0,39 a 1,54]). Não houve diferenças nos escores de continência (ventosa média = 3, fórceps média = 3, P = 0,17); urgência fecal menor que 5 minutos (RR 0,72 [IC 95% 0,34 a 1,54]); e desconforto perineal (RR 0,78 [IC 95% 0,37 a 1,64]).  
14.4.2.2 Ventosa macia versus ventosa rígida  
As diretrizes do NICE (2014) incluíram nessa comparação uma RS de boa qualidade que incluiu 1.375 mulheres de nove ensaios realizados na Arábia Saudita, Nepal, Reino Unido, Suécia, África do Sul, Holanda, Malásia, Grécia e Tailândia.<sup>334</sup> [NE = 1+]  
14.4.2.2.1 Eventos do parto  
A meta-análide dos nove estudos demonstrou um aumento significativo no índice de falhas quando o instrumento utilizado foi o de ventosa macia comparado com o de ventosa rígida (n = 1.368 mulheres): OR 1,65 [IC 95% 1,19 a 2,29]. Outros desfechos não foram relatados.  
14.4.2.2.2 Desfechos maternos  
Meta- análise de seis ensaios não evidenciou diferenças na incidência de lesões maternas (n = 1137 mulheres): OR 0,85 [IC 95% 0,57 a 1,27]. 14.4.2.2.3 Desfechos neonatais  
Meta-análise de oito ensaios demonstrou que o uso de ventosas macias reduziu significativamente  o trauma de couro cabeludo (n = 1337): OR 0,45 [IC 95% 0,34 a 0,60] mas sem diferenças nos escores de Apgar menor que 7 com 1 minuto (quatro  ensaios, n = 866): OR 1,21 [IC 95% 0,80 a 1,83]; menor que 7 com 5 minutos (cinco ensaios, n = 765): OR 0,68 [IC 95% 0,35 a 1.33]; incidência de cefalohematoma (quatro ensaios, n = 538): OR 0,70 [IC 95% 0,34 a 1,44]; fototerapia ou icterícia (seis ensaios, n = 1137): OR 0,73 [IC 95% 0,50 a 1,07]; hemorragia retiniana/intracraniana grave (dois ensaios, n = 218): OR 0,84 [IC 95% 0.27 2,64]; e morte neonatal (um ensaio, n = 72): OR 1,26 [IC 95% 0,08 a 20,85]. 14.4.2.3 Falha/Sucesso do parto vaginal instrumental e cesariana  
Um estudo de coorte realizado no Reino Unido comparou mulheres com parto vaginal instrumental bem sucedido (n = 184), cesariana imediata (n = 102) e tentativa de parto vaginal e depois cesariana (n = 107).<sup>335</sup> [NE = 2+]. Os resultados demonstraram que no grupo de cesariana imediata houve aumento de  
hemorragia (> 1.000 mL) (OR 2,82 [IC 95% 1,10 a 7,62]); maior necessidade de opióides (OR 10,93 [IC 95% 6,44 a 18,91]); maior necessidade de cateterismo urinário por mais de 24 horas (OR 3,09 [IC 95% 1,39 a 6,88]); e maior permanência hospitalar (6 dias ou mais) (OR 3,47 [IC 95% 1,58 a 7,62]) comparado com o parto instrumental e controlando para vários fatores de confusão. Em relação aos desfechos neonatais houve mais admissões em unidade neonatal (OR 2,64 [IC 95% 1,16 a 6,02]); mas menos trauma de parto (OR 0,37 [IC 95% 0,20 a 0,70]; e trauma grave (OR 0,34 [IC 95% 0,08 a 1,42]), no grupo de cesariana comparado com o grupo de parto vaginal instrumental. Não houve diferenças nos escores de Apgar < 7 com 5 minutos (OR 2,81 [IC 95% 0,48 a 16,74]).  
14.4.3 Resumo da evidência e conclusões  
Não existem evidências de alto nível sobre a efetividade e segurança no uso da ocitocina na falha de progresso no segundo período do parto, comparada com o parto vaginal instrumental. Evidências de alta qualidade apontam que o parto vaginal assistido por ventosa (vácuo-extrator), quando comparado com o fórceps está mais associado com falha do uso, menos trauma perineal/genital e menos dor perineal a curto e longo prazo, mas com maior incidência de cefalohematoma e hemorragia retiniana do recém-nascido. Quando há falha com o uso de um primeiro instrumento, há um aumento na incidência de trauma nos recém-nascidos com o uso de instrumentos sequenciais.  
Não há evidências de diferenças entre a ventosa e fórceps na taxa de cesariana, desfechos neonatais de longo prazo, satisfação da mulher e desfechos psicológicos.  
Há evidência de qualidade moderada que as ventosas macias estão mais associadas com falha no procedimento, mas significativamente com menos trauma de couro cabeludo nos recém–nascidos. Não há evidência de diferenças em outros desfechos maiores, incluindo os de longo prazo.  
Há evidência limitada que o parto vaginal instrumental, quando comparado com a cesariana imediata, está mais associado com menor perda sanguínea, menor permanência hospitalar e menos admissão em unidade neonatal, mas maior probabilidade de trauma nos recém-nascidos.  
14.4.4 Recomendação em relação à falha de progresso no segundo período do parto  
123. Se houver prolongamento do segundo período do trabalho de parto, ou se a mulher estiver excessivamente estressada, promover medidas de apoio e encorajamento e avaliar a necessidade de analgesia/anestesia.  
124. Se as contrações forem inadequadas no início do segundo período, considerar o uso de ocitocina e realização de analgesia regional.  
125. Para as nulíparas, suspeitar de prolongamento se o progresso (em termos de rotação ou descida da apresentação) não for adequado após 1 hora de segundo período ativo. Realizar amniotomia se as membranas estiverem intactas.  
126. Para as multíparas, suspeitar de prolongamento se o progresso (em termos de rotação ou descida da apresentação) não for adequado após 30 minutos de segundo estágio ativo. Realizar amniotomia se as membranas estiverem intactas.  
127. Um médico obstetra deve avaliar a mulher com prolongamento confirmado do segundo período do parto antes do uso de ocitocina.  
128. Após a avaliação obstétrica inicial, manter a revisão a cada 15-30 minutos.  
129. Considerar o uso de parto instrumental (vácuo-extrator ou fórceps) se não houver segurança quanto ao bem estar fetal ou prolongamento do segundo período.  
130. Reconhecer que, em algumas ocasiões, a necessidade de ajuda por parte da mulher no segundo estágio pode ser uma indicação para o parto vaginal assistido quando o apoio falhar.  
131. A escolha do instrumento para o parto instrumental dependerá das circunstâncias clínicas e da experiência do profissional.  
132. Por ser um procedimento operatório, uma anestesia efetiva deve ser oferecida para a realização de um parto vaginal instrumental.  
133. Se a mulher recusar anestesia ou a mesma não estiver disponível, realizar um bloqueio de pudendo combinado com anestesia local do períneo durante o parto instrumental.  
134. Mesmo se houver preocupação com o bem-estar fetal, uma anestesia efetiva pode ser realizada mas, se o tempo não permitir, realizar um bloqueio de pudendo combinado com anestesia local do períneo durante o parto instrumental.  
135. Orientar a mulher e realizar uma cesariana se o parto vaginal não for possível.  
14.7 Cuidados com o períneo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.7.1 Introdução -->
Na assistência ao segundo período do  parto há uma preocupação, tanto por parte dos profissionais envolvidos na assistência, como por parte das mulheres, em relação ao trauma perineal. Muitas estratégias são utilizadas com o objetivo de reduzir o trauma perineal e a sua utilização depende frequentemente dos hábitos e costumes locais. Esta seção estuda o impacto das intervenções realizadas com o propósito de reduzir o trauma perineal ou dor perineal durante o segundo período do trabalho de parto em mulheres com gravidez de baixo risco obstétrico, a termo, com previsão de parto normal. 14.7.2 Questões de revisão  
- Qual é a efetividade das seguintes intervenções na prevenção do traumatismo genital?  
- Massagem do períneo  
- Aplicação de calor perineal,  
- Uso de anestésicos locais no períneo,  
- Aplicação de frio perineal  
- Aplicação de óleos no períneo  
- Proteção do períneo  
- Desvio ativo da cabeça  
- Extração ativa do ombro  
- Outros  
- Qual é a efetividade da episiotomia e suas diversas técnicas?  
- Em quais situações a episiotomia deve ser realizada?  
- Existe uma taxa de referência para a episiotomia?  
- Deve haver antibiótico profilaxia para mulheres em que a episiotomia é realizada?  
De acordo com as diretrizes do NICE, a definição de trauma perineal é o trauma causado por laceração ou episiotomia, como:  
- Primeiro grau – Lesão apenas na pele  
- Segundo grau – Lesão dos músculos do períneo sem o envolvimento do esfíncter anal  
- Terceiro grau – Lesão do períneo envolvendo o complexo do esfíncter anal  
- 3a – Lesão menor que 50% da espessura do esfíncter anal externo  
- 3b – Lesão maior de 50% da espessura do esfíncter anal externo com laceração do esfíncter anal interno.  
- Quarto grau - lesão do períneo envolvendo o complexo do esfíncter anal (externo e do esfíncter anal interno) e epitélio anal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.7.3.1 Massagem perineal durante o parto -->
As diretrizes do NICE incluíram um ERC realizado na Austrália,<sup>336</sup> cujo objetivo foi estudar os efeitos da massagem perineal no segundo período do parto. O estudo incluiu um total de 1.340 mulheres (grupo com massagem, n = 708), que foram submetidas à massagem durante cada contração. Os resultados não encontraram diferenças significativas entre os dois grupos quanto às variáveis estudadas: períneo intacto: 198/708 versus 171/632, RR 1,03 [IC 95% 0,87 a 1,23] , laceração de I grau: 122/708 versus 106/632, RR 1,03 [IC 95% 0,81 a 1,30]; laceração de II grau: 190/708 versus 164/632, RR 1,03 [IC 95% 0,86 a 1,24]; episiotomia: 176/708 versus 170/632, RR 0,92 [IC 95% 0,77 a 1,11] , dor vaginal em 3 dias: 416/597 versus 359/499, RR 0,97 [IC 95% 0,90 a 1,05]; dor vaginal em 10 dias: 184/632 versus 187/555, RR 0,86 [IC 95% 0,73 a 1,02]; dor vaginal em 3 meses: 58/503 versus 54/436, RR 0,93 [IC 95% 0,66 a 1,32]; dispareunia: 78/503 versus 68/436; RR 0,9 [IC 95% 0,74 a 1,34] ; ausência de retomada das relações sexuais: 49/503 versus 60/436; RR 0,71 (IC 95% 0,50 a 1,01) e controle urinário e fecal. As lacerações de terceiro grau tiveram menor incidência no grupo com massagem (12/708 versus 26/632; RR 0,47 [IC 95% 0,23 a 0,93]).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.7.3.2 Aplicação de calor/frio -->
Nas diretrizes do NICE (2014) foi incluído um grande estudo observacional de coorte realizado nos EUA<sup>337</sup> [NE 2+] incluindo 2.595 mulheres, com o intuito de analisar fatores associados com o traumatismo perineal durante o parto. As mulheres foram estudadas por 12 meses, e os resultados indicaram que a colocação de compressas mornas na 2ª etapa do parto poderia prevenir ligeiramente o surgimento de  lacerações espontâneas em mulheres sem episiotomia, tanto nas multíparas (OR 0,6 [IC 95% 0,3 a 0,9]), como nas nulíparas (OR 0,7 [IC 95% CI 0,4 a 1,0]). Houve também uma diminuição na realização de episiotomia em nulíparas (OR 0,3 [IC 95% 0,0 a 0,8]).  
Nas diretrizes do País Basco foi incluído um ERC<sup>338</sup> que responde à pergunta sobre aplicação de calor/frio que não foi incluído nas diretrizes do Nice (2014). O objetivo do ensaio foi determinar os efeitos da aplicação de compressas quentes no períneo (compressas embebidas com água fervida em temperatura de 45<sup>o</sup> C) sobre o trauma perineal e a co-morbidade materna, durante a fase final do segundo estágio do parto. O estudo incluiu 717 mulheres nulíparas, com gravidez única a termo, em apresentação cefálica, nas quais se previa um parto normal e que não haviam sido submetidas a massagem perineal. As mulheres foram randomizadas para dois grupos: no grupo com intervenção, as compressas quentes foram aplicadas desde o final do segundo estágio do trabalho de parto até a apresentação da cabeça da criança, em comparação com a conduta habitual, que não incluiu panos mornos. Embora não tenha sido possível ocultar o procedimento das mulheres ou de quem cuidava do parto, os avaliadores externos foram mascarados em relação às intervenções. O ensaio foi realizado em uma população etnicamente diversa na Austrália, em que 75% das mulheres eram imigrantes de outros países. Com tamanho amostral adequado para detectar uma diferença de 10%, não foram encontradas diferenças nos grupos quanto ao resultado principal: a necessidade de sutura perineal (OR 1,0 [IC 95% 0,69 a 1,47]). No entanto, a taxa de lacerações de terceiro e quarto graus foi maior no grupo controle (OR 2,16 [IC 95% 1,15 a 4,10]). As mulheres que receberam compressas mornas tiveram probabilidade significativamente menor de dor intensa durante o parto que aquelas que não receberam (59 versus 82%, respectivamente). Também foi encontrada uma redução modesta, porém significativa, nas pontuações médias de dor perineal nos dias 1 e 2 pós-parto, utilizando uma escala analógica visual de 10 pontos, com menos de 1 ponto de diferença média. Em 3 meses pós-parto, foi menos provável que  
as mulheres que receberam compressas quentes apresentassem incontinência urinária (26/277 contra 59/262; p < 0,0001).  
14.7.3.3 Posição da mão no momento do nascimento  
A posição da mão no momento do nascimento engloba várias técnicas para proteção perineal, muitas delas sem uma padronização adequada, dependendo muitas vezes da experiência e julgamento individual do profissional assistente. As diretrizes do NICE incluiu na sua revisão 3 estudos, utilizando técnicas variáveis, que são descritos a seguir.  
Um grande ERC (n = 5.471) realizado no Reino Unido comparou dois métodos de cuidados com o períneo durante o desprendimento da cabeça fetal no parto vaginal espontâneo – ‘mãos sobre’ um método pelo qual a Enfermeira obstétrica/obstetriz utilizava as suas mãos para pressionar a cabeça fetal no sentido de flexioná-la e apoiar o períneo; ‘mãos prontas’ método pelo qual a Enfermeira obstétrica/obstetriz mantinha suas mãos preparadas mas sem tocar a cabeça ou o períneo<sup>339</sup> [NE = 1+]. O principal desfecho analisado no ensaio foi a dor perineal relatada pela mulher nas 24 horas prévias 10 dias após o parto, que foi significativamente maior no grupo de ‘mãos prontas’ comparado com o grupo de ‘mãos sobre’: 910/2.669 versus 823/2.647, RR 1,10 [IC 95% 1,01 a 1,18], representando uma diferença absoluta de risco de 3% [IC 95% 0,5% a 5,0%]. Esta diferença, entretanto, residiu predominantemente na dor leve (dor leve: 23,5% versus 20,9%; dor moderada: 9,2% versus 8,8%; dor intensa: 1,4% versus 1,4%). Não foram encontradas outras diferenças significativas em outros desfechos de dor, ex. sensação de dor nas 24 horas prévias após 2 dias (alguma dor: 70,0% versus 71,3%, NS; leve: 27,5% versus 28,8%, NS; moderada: 37,0% versus 37,4%, NS; grave: 5,2% versus 5,1%, NS). As incidências de dor foram também muito similares 3 meses após o parto. Análises estratificadas demonstraram a que a maior diferença entre os grupos em relação à dor foram nas primíparas, nas que não usaram analgesia peridural no segundo estágio e na última parte do ensaio (após 6 meses).  Houve também evidência do efeito das preferências das Enfermeiras obstétricas/obstetrizes viciando os resultados em favor da preferência expressada por elas, com a técnica de ‘mãos sobre’ tornando-se significativamente melhor quando a Enfermeira obstétrica/obstetriz a preferia (teste de heterogeneidade P = 0,03).  
As taxas de trauma perineal foram similares entre os grupos: segundo grau (incluindo episiotomia 36,9% versus 36,6%); terceiro grau (1,5% versus 1,2%) e trauma vaginal e genital anterior. A taxa de episiotomia isoladamente foi maior no grupo de ‘mãos sobre’ (10,2% versus 12,9%, RR 0,79 [IC 99% 1,02 a 2,78]). A taxa de extração manual da placenta foi significativamente mais frequente no grupo de ‘mãos prontas’: n = 71 (2.6%) versus 42 (1.5%), RR 1,69 (IC 99% 1,02 a 2,78). Os desfechos neonatais (Apgar, necessidade de ressuscitação ao nascer, cuidados neonatais adicionais, aleitamento materno com 2 dias, 10 dias e 3 meses) e outros desfechos maternos aos 3 meses (dispareunia, problemas urinários, problemas intestinais, tratamento de trauma perineal, depressão) foram similares em ambos os grupos. Um ensaio quasi-randomizado conduzido na Áustria investigou os efeitos das técnicas de ‘mãos sobre’ e ‘mãos prontas’ nos cuidados com o períneo (n = 1076)<sup>340</sup> [NE = 1+]. O trauma perineal de primeiro e segundo grau foi semelhante entre os grupos (‘mãos sobre’ 29,8%; ‘mãos prontas 33,7%, NS), e o trauma de terceiro grau foi maior no grupo de ‘mãos sobre’ (n = 16 (2,7%) versus n = 5 (0,9%)). O estudo não teve poder suficiente para detectar diferenças estatisticamente significativas nesse evento raro. A taxa de episiotomia foi maior no grupo de ‘mãos sobre’: 17.9% versus 10,1%, P < 0.01. Não foram encontradas diferenças em relação a trauma vaginal, duração do segundo estágio do parto ou extração manual da placenta. Os desfechos neonatais foram muito similares entre os grupos.  
Um ERC conduzido nos EUA, envolvendo 1.211 mulheres, comparou três medidas de cuidados perineais no segundo estágio do parto: compressas mornas; massagem com lubrificantes; e não tocar o períneo até o coroamento da cabeça fetal<sup>341</sup> [NE = 1+]. A taxa de episiotomia foi muito baixa no estudo (0,8%). Os perfis de trauma perineal/genital foram muito semelhantes em todos os grupos estudados: nenhum trauma (n = 278, 23%); trauma mais grave (laceração perineal de segundo, terceiro e quarto grau, laceração do terço médio e superior da vagina e laceração cervical; n = 242, 20%) e trauma leve (laceração perineal de primeiro grau, laceração do terço inferior da vagina ou da genitália externa; n = 691, 57%). Não foram encontradas diferenças na comparação de compressas mornas com a técnica de ‘mão prontas’: RR 1,04 [IC 95% 0,81 a 1,35] ou massagem com a técnica de ‘mãos prontas’: RR 1,05 [IC 95% 0,81 a 1,35]. Análise estratificada controlando para a paridade, uso de peridural, peso do recémnascido ou primeiro ano versus últimos anos do estudo não demonstrou diferenças entre os grupos. Um modelo final de regressão logística evidenciou duas medidas que foram protetoras do períneo, a posição sentada para o parto e o desprendimento da cabeça fetal entre (ao invés de durante) as contrações. 14.7.3.3 Anestesia local com spray  
As diretrizes do NICE (2014) incluíram na sua revisão um ERC que avaliou a efetividade e a aceitabilidade de um spray de lidocaína para reduzir a dor perineal durante o parto vaginal espontâneo. O ensaio incluiu um total de 185 mulheres (n = 93 com lidocaína e n = 92 com placebo<sup>342</sup> [NE = 1+] ). Os resultados não demonstraram diferenças significativas na dor experimentada pelas mulheres nos dois grupos (média e [desvio padrão]): lidocaína (76,9 [21,6] em comparação com placebo (72,1 [22,2]) (DM de 4,8 [IC 95% de -1,7 a 11,2]; p = 0,14). No entanto, foram mostradas diferenças favoráveis ao grupo com lidocaína na incidência de lacerações de grau II (RR de 0,63 [IC 95% de 0,42 a 0,93], p = 0,019) e na dispareunia (RR de 0,52 [IC 95% de 0,35 a 0,76], p = 0,0004). Esses efeitos adversos podem ser devidos às diferenças entre os dois grupos de tratamento do ensaio com relação à paridade das mulheres (mais multíparas no grupo com intervenção) e ao peso fetal (menor no grupo com intervenção). 14.7.3.4 Desvio da cabeça  
Sobre essa questão em particular, as diretrizes do NICE não incluíram nenhum estudo. As diretrizes do País Basco (2010) incluíram na sua atualização<sup>343</sup> um estudo de coorte, realizado como parte de um programa nacional norueguês, com o objetivo de definir se um programa de intervenção poderia diminuir a frequência de ruptura do esfíncter anal. A intervenção realizada consistiu em retardar a fase de expulsão da cabeça através de duas manobras (controlando o desvio da cabeça e informando a mãe para que não empurrasse) para proteger o períneo. No estudo, foram analisados os dados de 12.369 partos vaginais ocorridos entre 2002-2007 e estes foram comparados com o impacto do programa de intervenção (realizado de outubro de 2005 a março de 2007, depois de um período de treinamento em janeiro-setembro de 2005) na taxa de ruptura do esfíncter anal em dois subgrupos de tipos diferentes de parto (partos instrumentais e não instrumentais).  
Observou-se uma redução global de lacerações do esfíncter anal durante o período de intervenção: de 4,03% de lacerações no período 2002-2004 para 1,17% no período 2005-2007 (p < 0,001). Essa tendência foi observada tanto em partos não instrumentais (de 16,26 para 4,90%; p < 0,001) como em partos instrumentais (de 2,70 para 0,72%; p < 0,001).  
Além disso, também observou-se um aumento dos partos instrumentais no período de intervenção (de 9,8% no período 2002-2003 a 11,7% durante os primeiros 9 meses de 2005 (p < 0,001) e a 12,2% durante os últimos 9 meses do período de intervenção (p < 0,001)), assim como também um aumento do número de episiotomias realizadas (13,9% no período 2002-2004; 23,1% nos primeiros meses de  
2005 (p < 0,001); e 21,1% nos últimos 9 meses do período de intervenção (p < 0,001)).  
Dessa forma, os resultados mostram que a proteção manual do períneo através do retardamento do desvio da cabeça fetal diminui o número de rupturas do esfíncter anal.  
14.7.3.5 Episiotomia  
As diretrizes do NICE (2014) incluíram na sua revisão uma revisão sistemática que por sua vez incluiu sete ERCs e oito estudos de coorte, além de outro ERC extra. Os achados da RS se sobrepõem a uma outra RS anterior (1999) que incluiu seis dos sete ERCs<sup>344</sup> .  
A RS considerou os desfechos maternos, comparando o uso da episiotomia de rotina versus o uso restritivo<sup>345</sup> [NE = 1+]. Foram incluídos dados de sete ERCs envolvendo 5.001 mulheres e oito estudos de coorte, envolvendo 6.463 mulheres. Seis dos ensaios estudaram a episiotomia médio-lateral e apenas um utilizou a episiotomia mediana. Três ensaios incluíram apenas primíparas. Os estudos tiveram como foco os partos vaginais espontâneos, embora uma pequena proporção de partos vaginais instrumentais tenha sido incluída na maioria deles (0-5% em quatro ensaios e 5-15% em três ensaios). As evidências dos ensaios foi resumida de forma descritiva, em vez de realização de meta-análise. Todos os ensaios mostraram uma grande variação no uso da episiotomia que foi de 7,6% no uso restritivo até 93,7% no uso de rotina. No ensaio considerado de melhor qualidade (n = 1.000), a incidência de períneo íntegro foi de 33,9% no grupo de uso restritivo versus 24% no grupo de rotina. No maior ensaio (n = 2.606), a necessidade de reparo cirúrgico foi de 63% no grupo de episiotomia restritiva, em comparação com 88% no grupo de rotina. Em cinco ensaios, a necessidade de reparo perineal foi menor no grupo restritivo: RR 0,46 [IC 95% 0,30 a 0,70]. A necessidade de qualquer sutura foi 26% maior nos grupos de rotina (três ensaios): RR 1,26 [IC 95% 1,08 a 1,48]. Os ensaios não tiveram poder estatístico suficiente para demonstrar eventuais diferenças de trauma do terceiro ou quarto grau, com uma incidência de 105/5.001 (sete ensaios).  
A experiência de dor foi avaliada em cinco ensaios. Em um deles (n = 895/1.000), os resultados foram semelhantes entre os dois grupos. Grupo de rotina: dor leve = 14,6%; dor moderada = 7,8% e dor intensa = 0,2%.  Grupo restritivo: 14,1%, 7,5% e 0,9%, respectivamente. O uso de analgésicos orais 10 dias após o parto e os desfechos de dor após 3 meses foram semelhantes entre os grupos. Três outros estudos evidenciaram maior intensidade da dor nos grupos de uso rotineiro da episiotomia, porém cada ensaio usou um desfecho diferente de dor. O maior estudo (n = 2.422/2.606) relatou maior "dor no dia da alta" no grupo de uso rotineiro (42,7%) em comparação com o uso restritivo (30,7%). Um segundo experimento avaliou a dor, usando uma escala visual analógica (EVA) para quatro atividades (dias 1 a 5 pós-parto). Repouso no leito: grupo de rotina = 39 mm (DP 28 mm) e grupo restritivo = 22 mm (DP 21 mm); sentada: grupo de rotina = 69 mm (DP 23 mm) e grupo restritivo = 51 mm (DP 25 mm); andando: grupo de rotina = 56 mm (DP 24 mm) e grupo restritivo = 37 mm (DP 24 mm); defecando: grupo de rotina = 36 mm (DP 30 mm) e grupo restritivo = 21 mm (SD 21 mm). Em todas as atividades, o grupo de uso restritivo experimentou menos dor perineal do que o grupo de uso rotineiro (P = 0,005-0,048). A incontinência urinária foi investigada em dois ERCs. O maior ensaio (n = 895/1.000) investigou a perda involuntária de urina e a utilização de forros para incontinência aos 3 meses . Ambos os grupos tiveram resultados muito semelhantes para os dois grupos (perda involuntária de urina: rotina = 19,0%; restritivo = 18,9%). A meta-análise dos dois ensaios não evidenciou diferenças na incidência de incontinência urinária entre os dois grupos: RR 1,02 [IC 95% 0,83 a 1,26].  
Cinco estudos prospectivos de coorte investigaram a incontinência urinária auto-referida. Não houve diferença entre os grupos de pacientes com episiotomia em relação àquelas com laceração espontânea  
(cinco estudos: RR 0,88 [IC 95% 0,72 a 1,07]). Quatro estudos investigaram a incontinência fecal. A episiotomia não foi fator de proteção para incontinência fecal ou de gases. O agrupamento dos dados dos dois estudos de coorte com resultados comparáveis indicou um aumento do risco associado ao uso da episiotomia: RR 1,91 [IC 95% 1,03-3,56].  
Dois estudos avaliaram a função sexual por intenção de tratar. O maior estudo (n = 895/1.000) demonstrou maior propensão para a retomada da atividade sexual em 1 mês no grupo de uso restritivo em comparação com o grupo de rotina (27% versus 37%, P <0,01). Não houve diferenças entre os grupos nos outros desfechos como: retomada de relações sexuais aos três meses, dispareunia em 3 meses, ou em 3 anos. Cinco estudos prospectivos de coorte não encontraram diferenças na função sexual entre os grupos de episiotomia e os grupos de laceração espontânea. A dispareunia aos 3 meses também foi similar entre os grupos (dois ensaios: RR 1.53 [IC 95% 0,93 a 2,51]).  
Um ERC realizado na Alemanha comparou o uso restritivo da episiotomia (apenas indicações fetais) (n = 49) com uma utilização mais liberal (indicações fetais e se uma laceração era iminente) (n = 60)<sup>346</sup> [NE = 1+]. As taxas de episiotomia foram 41% no grupo restritivo e 77% no grupo liberal (RR 0,47 [IC 95% 0,3 a 0,7]. A dor referida foi menor no grupo de uso restritivo. Não houve diferença entre os grupos para os escores de Apgar dos recém-nascidos ou pH da artéria umbilical. As incidências de períneo intacto e trauma perineal ‘menor’ (períneo intacto ou lacerações de primeiro grau) foi mais comum no grupo de uso restritivo: períneo intacto: 14/49 versus 6/60, RR 2,9 [IC 95% 1,2 a 6.9]; períneo intacto ou laceração de primeiro grau: 19/49 versus 8/60, RR 2,9 [IC 95% 1,6 ta 10,5]. Não houve diferenças significativas em relação ao trauma anterior: 27/49 versus 25/60, RR 1,1 [IC 95% 0,8 a 1,8].  
Devido às semelhanças entre os estudos e medidas de resultado, foi possível reunir algumas das conclusões do único ERC<sup>346</sup> e da revisão sistemática de 1999<sup>344</sup> e realizar uma meta-análise. A metaanálise foi realizada utilizando um modelo de efeitos aleatórios, devido à heterogeneidade significativa entre os desfechos e da incerteza quanto à confiabilidade da classificação das medidas dos resultados, por exemplo, diagnóstico de lacerações de terceiro grau e as avaliações de dor feitas em uma escala visual analógica. Os resultados comparando o uso restritivo com o uso rotineiro da episiotomia são os seguintes:  
- trauma perineal grave (laceração de terceiro e quarto graus ): RR 0,74 [IC 95% 0,42-1,28] (seis ensaios, um sem incidentes)  
- qualquer trauma perineal posterior: RR 0,87 [IC 95% 0,83-0,91] (cinco ensaios)  
- trauma anterior: RR 1,75 [IC 95% 1,52-2,01] (cinco ensaios)  
- Apgar < 7 em 1 minuto: RR 1,05 [IC 95% 0,76-1,45].  
Devido a diferenças nas medidas dos desfechos, os dados relativos à dor perineal não puderam ser combinados.  
14.7.3.5.1 Ângulo da Episiotomia  
As diretrizes do NICE incluíram um estudo observacional prospectivo que teve como objetivo identificar os fatores de risco associados às lacerações perineais do terceiro e quarto graus no parto<sup>347</sup> [NE = 3]. O estudo envolveu 241 primíparas. Após o parto um investigador experiente realizou um exame perineal e retal, para identificar e classificar o trauma perineal. As dimensões e o ângulo de episiotomia foram anotadas e as variáveis obstétricas foram colhidas. Lesão do esfíncter foi identificada em 59 (25%) das 241 mulheres. A regressão logística múltipla identificou maior peso ao nascer (P = 0,021) e episiotomia médio-lateral (OR 4,04 [intervalo 1,71-9,56] como fatores de risco independentes para a lesão do esfíncter anal. Investigações detalhadas revelaram que o ângulo da episiotomia mais próximo da linha  
média são associados com lesões do esfíncter anal (26 contra 37 graus, p = 0,01). Nenhuma das Enfermeiras obstétricas/obstetrizes fez uma episiotomia adequada e somente 22% dos médicos obstetras realizaram uma episiotomia médio-lateral adequada (com ângulo de pelo menos 40 graus a partir da linha média).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 14.7.4 Resumo da evidência e conclusões sobre cuidados com o períneo -->
Há evidências de alto nível de que massagens perineais ou aplicação de compressas mornas no segundo período do trabalho de parto não resultam em melhores resultados para o períneo. O uso de spray de lidocaína não está associado a uma redução da dor perineal, mas pode estar associado a uma redução no trauma perineal.  
Os benefícios e riscos da posição das mãos durante o desprendimento fetal demonstrou que no grupo de ‘mãos sobre’ ou seja, a adoção de alguma intervenção para proteger o períneo associa-se com menor incidência de dor leve 10 dias após o parto, quando comparado com a técnica de ‘mãos prontas’ ou seja, não tocar o períneo durante o desprendimento fetal. As taxas de trauma perineal em geral (incluindo episiotomia) foram semelhantes entre os dois grupos, mas a episiotomia foi maior no grupo de ‘mãos prontas’.  
Há evidências de alto nível de que o uso rotineiro de episiotomia (média 71,6%; variando entre 44,9% a 93,7%) não apresenta benefícios para as parturientes, quer a curto ou a longo prazo, em comparação com uso restritivo da episiotomia (média 29,1%; variando entre 7,6% a 53,0%).  
Nenhuma das diretrizes consultadas apresentou evidências sobre quais situação a episiotomia deve ser realizada ou sobre o uso de antibióticos profiláticos quando da sua realização. Também não foram apresentadas evidências sobre a aplicação de frio no períneo e sobre a extração ativa dos ombros.  
- 14.7.5 Recomendações sobre cuidados com o períneo  
136. Não se recomenda a massagem perineal durante o segundo período do parto.  
137. Considerar aplicação de compressas mornas no períneo no segundo período do parto.  
138. Não se recomenda a aplicação de spray de lidocaína para reduzir a dor perineal no segundo período do parto.  
139. Tanto a técnica de ‘mãos sobre’ (proteger o períneo e flexionar a cabeça fetal) quanto a técnica de ‘mãos prontas’ (com as mãos sem tocar o períneo e a cabeça fetal, mas preparadas para tal) podem ser utilizadas para facilitar o parto espontâneo.  
140. Se a técnica de ‘mãos sobre’ for utilizada, controlar a deflexão da cabeça e orientar à mulher para não empurrar nesse momento.  
141. Não realizar episiotomia de rotina durante o parto vaginal espontâneo.  
142. Se uma episiotomia for realizada, a sua indicação deve ser justificada, recomendando-se a médio-lateral originando na fúrcula vaginal e direcionada para o lado direito, com um ângulo do eixo vertical entre 45 e 60 graus.  
143. Assegurar analgesia efetiva antes da realização de uma episiotomia.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.1 Introdução -->
A assistência no terceiro período do parto, ou etapa final do mesmo, se reveste de fundamental importância tendo em vista as complicações que podem surgir nesse período, principalmente para as mulheres. A mais importante e mais comum é a hemorragia, que figura como a segunda causa de mortalidade materna no Brasil. O terceiro estágio pode ser assistido de diversas maneiras – variando entre a conduta completamente fisiológica sem intervenção nenhuma e a conduta ativa, incluindo vários procedimentos (administração de uterotônico, corte precoce do cordão e tração controlado do cordão) ou combinações ou modificações dos seus componentes individuais. A possibilidade de reduzir o risco para HPP acelerando o desprendimento da placenta e encurtando a duração do terceiro estágio é a  justificativa alegada para a adoção da conduta ativa. As evidências sobre as melhores práticas na condução do terceiro período do trabalho de parto devem ser avaliadas e analisadas de forma sistemática no intuito de se reduzir as suas complicações.  
15.2 Questões de revisão  
- Qual a definição e duração do terceiro período do parto?  
- Há benefícios na identificação de mulheres com risco aumentado para hemorragia no terceiro período do parto?  
- Quais estratégias são eficazes para a prevenção de hemorragia no terceiro período do parto?  
- Como deve ser realizado a conduta no terceiro período do parto em relação a:  
- Conduta fisiológica?  
- Sucção ao seio materno?  
- Conduta ativa?  
- Efeitos, vias de administração e uso conjunto ou isolado dos diversos uterotônicos (ocitocina, derivados do ergot, prostaglandinas etc.)?  
- Momento de clampeamento do cordão?  
- Como identificar e atuar adequadamente em caso de retenção placentária?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.3 Duração e definição do terceiro período do parto -->
As diretrizes do NICE de 2007 abordaram essa questão que não foi abordada nas diretrizes de 2014, onde os desenvolvedores só a mencionaram na recomendação. Não foram encontrados estudos relevantes que investigassem os desfechos relacionados com diferentes definições do terceiro período do parto e portanto, nenhuma definição foi encontrada na literatura sobre essa fase do parto. Por se tratar de um período simples e facilmente reconhecível, os desenvolvedores das diretrizes inglesas chegaram a um consenso sobre a sua definição. Para estas Diretrizes adaptadas para o Brasil, chegou-se também a um consenso diferente do que está nas recomendações das diretrizes originais em relação à duração do terceiro período. Ver recomendação.  
15.4 Conduta no terceiro período do parto  
15.4.1 Conduta ativa comparada com a conduta fisiológica do terceiro período do parto  
15.4.1.1 Evidências Científicas  
As diretrizes do NICE de 2014 incluíram na sua revisão 4 ERCs, 3 conduzidos no Reino Unido<sup>348-350</sup> e 1 na Holanda<sup>351</sup> . Para efeito de comparação a conduta ativa foi definida como a utilização de um ou mais componentes de um conjunto de intervenções, incluindo a administração intramuscular de um uterotônico, clampeamento precoce do cordão e tração controlada do cordão. A conduta fisiológica foi definida como a expulsão da placenta sem a utilização rotineira desses componentes.  
Os estudos realizados no Reino Unido compararam a conduta fisiológica com todo o conjunto de intervenções da conduta ativa. A maioria das mulheres recebeu uma combinação de ocitocina e ergometrina. O estudo holandês comparou a ocitocina intramuscular com placebo, sem os outros componentes da conduta ativa.  
As tabelas xxx apresentam o resumo dos resultados dos estudos, com as variáveis estudadas Tabela 25 – Conduta ativa (todas as intervenções) versus conduta fisiológica  
|Estudos|Número d|e mulheres|Efe|ito|
|---|---|---|---|---|
||Conduta ativa|Conduta<br>fisiológica|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Perda sanguínea ≥ 50|0 ml na hora dopa|rto|||
|1 meta-análise de 2<br>estudos<sup>348,349</sup>|101/1.594<br>(6,3%)|278/1.613<br>(17,2%)|RR 0,37<br>(0,3 a 0,46)|109<br>menos/1.000<br>(de 93 menos<br>a  121<br>menos)|
|Perda sanguínea ≥ 1.0|00 ml||||
|1 meta-análise de 2<br>estudos<sup>348,349</sup>|20/1.594<br>(1,3%)|46/1.613<br>(2,9%)|RR 0,44<br>(0,26 a 0,74)|16 menos/<br>1.000|
|Necessidade de transf|usão sanguínea|||de 7 menos a<br>21 menos)|
|1 meta-análise de 3<br>estudos<sup>348,349,350</sup>|23/1.697<br>(1,4%)|68/1.703<br>(4%)|RR 0,34<br>(0,22 a 0,55)|26<br>menos/1.000<br>(de 18 menos<br>a 31 menos)|
|Necessidade de remo|ção manual dapla|centa|||
|1 meta-análise de 3<br>estudos<sup>348,349,350</sup>|32/1.697<br>(1,9%)|35/1.703<br>(2,1%)|RR 0,92<br>(0,58 a 1,48)|2<br>menos/1.000<br>(de 9 menos<br>a 10 mais)|
|Uso de ocitocina tera|pêutica||||
|1 meta-análise de 3<br>estudos<sup>348,349,350</sup><br>Necessidade de retira|79/1.697<br>(4,7%)<br>da cirúrgica de res|420/1.703<br>(24,7%)<br>tosplacentários|RR 0,19<br>(0,15 a 0,24)|200<br>menos/1.000<br>(de 187<br>menos a 210<br>menos)|
|1 meta-análise de 2<br>estudos<sup>348,349</sup>|20/1.594<br>(1,3%)|22/1.613<br>(1,4%)|RR 0,92<br>(0,5 a 1,67)|1<br>menos/1.000<br>(de 7 menos<br>a 9 mais)|  
Readmissão por causa de sangramento  
Tabela 25 – Conduta ativa (todas as intervenções) versus conduta fisiológica  
|Estudos|Número de|mulheres|Efe|ito|
|---|---|---|---|---|
||Conduta ativa|Conduta<br>fisiológica|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1  estudo<sup>349</sup>|12/748<br>|5/764<br>|RR 2,45<br>|9 mais/1.000<br>|
||(1,6%)|(0.65%)|(0,87 a 6,92)|(de 1 menos|
|||||a 39 mais)|
|Efeito colateral: náuse|a||||
|1  estudo<sup>349</sup><br>Efeito colateral: vômit|86/748<br>(11,5%)<br>o|45/764<br>(5,9%)|RR 1,95<br>(1,38 a 2,76)|56<br>mais/1.000<br>(de 22 mais a<br>104 mais)|
|1 meta-análise de 2<br>estudos<sup>348,349</sup>|149/1.594<br>(9,3%)|72/1.613<br>(4,5%)|RR 2,09<br>(1,59 a 2,74)|49<br>mais/1.000|
|Efeito colateral: cefalé|ia|||(de 26 mais a<br>78 mais)|
|1 meta-análise de 2<br>|18/1.594<br>|11/1.613<br>|RR 1,65<br>|4 mais/1.000<br>|
|estudos<sup>348,349</sup>|(11%)|(068%)|(078 a 348)|(de 2 menos|
|Efeito colateral: Hiper|,<br>tensão(pressão dia|,<br>stólica>100mmH|,  ,<br>g)|<br>a 17 mais)|
|1 meta-análise de 2<br>|23/1.594<br>|9/1.613<br>|RR 2,57<br>|9 mais/1000<br>|
|estudos<sup>348,349,350</sup>|(1,4%)|(0,56%)|(1,2 a 5,54)|(de 1 mais a|
|||||<br>25 mais)|
|Peso ao nascer|||||
|1 meta-análise de 2<br>estudos<sup>348,349,350</sup>|Média 3.337gr<br>(DP 451) e 3.454<br>gr (DP 465)<br>n=1.594|Média 3.422gr<br>(DP 444) e<br>3.521gr (DP<br>470)|Não calculável<br>(NC)|DM 76,9<br>menor<br>(de 108,51<br>menor a 45,3|
|||n=1.613||menor)|
|Apgar <7 no 5º minuto|||||
|1  estudo<sup>348</sup>|8/846<br>(0,95%)|8/849<br>(0,94%)|RR 1<br>(0,38 a 2,66)|0<br>menos/1.000<br>(de 6 menos<br>a 16 mais)|
|Hematócrito neonatal|<50%||||
|1  estudo<sup>348</sup>|19/127<br>(15%)|11/166<br>(6,6%)|RR 2,26<br>(1,11 a 4,57)|83<br>mais/1.000<br>(de 7 mais a<br>237 mais)|
|Hematócrito neonatal|>65%||||  
Tabela 25 – Conduta ativa (todas as intervenções) versus conduta fisiológica  
|Estudos|Número d|e mulheres|Efe|ito|
|---|---|---|---|---|
||Conduta ativa|Conduta<br>fisiológica|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1  estudo<sup>348</sup>|15/127<br>(11,8%)|64/166<br>(38,6%)|RR 0,31<br>(0.18 a 0.51)|266 menos/<br>1.000<br>(de 189<br>menos a 316<br>menos)|
|Admissão em unidade|neonatal||||
|1 meta-análise de 2<br>estudos<sup>348,349</sup>|68/1.562<br>(4,4%)|84/1.580<br>(5,3%)|RR 0,82<br>(0,6 a 1,11)|10 menos/<br>1.000|
|||||(de 21 menos<br>a 6 mais)|
|Icterícia neontal: nece|ssidade de uso de|fototerapia|||
|1 estudo<sup>349</sup>|32/716<br>(4,5%)|25/731<br>(3,4%)|RR 1,31<br>(0,78 a 2,18)|11 mais/<br>1.000<br>(de 8 menos<br>a 40 mais)|
|Icterícia neontal: bilirr|ubina > 25mg/dl||||
|1 estudo<sup>348</sup>|39/846<br>(4,6%)|54/849<br>(6,4%)|RR 0,72<br>(0,49 a 1,08)|18 menos/<br>1.000|
|||||(de 32 menos<br>a 5 mais)|
|Amamentação: início|nasprimeiras duas|horas após opar|to||
|1 estudo<sup>348</sup>|487/748<br>(65,1%)|497/764<br>(65,1%)|RR 1<br>(0,93 a 1,08)|0 menos/<br>1.000|
|||||(de 46 menos|
|||||<br>a 52 mais)|
|Amamentação:qualq|uer aleitamento na|alta|||
|1 meta-análise de 2|1.191/1.594|1.174/1.613|RR 1,03|22 mais/|
|estudos<sup>348,349</sup>|(74,7%)|(72,8%)|(0,98 a 1,07)|1.000|
|||||(de 15 menos<br>a 51 mais)|
|Amamentação: aleita|mento exclusive co|m 6 semanas apó|s oparto||
|1 estudo<sup>348</sup>|265/748<br>(35,4%)|272/764<br>(35,6%)|RR 1<br>(0,87 a 1,14)|0 menos/<br>1.000<br>(de 46 menos<br>a 50 mais)|
|Hemoglobina materna|:queda entre 32 -|37 semanas deg|estação e opós-pa|rto|  
Tabela 25 – Conduta ativa (todas as intervenções) versus conduta fisiológica  
|Estudos|Número de|mulheres|Ef|eito|
|---|---|---|---|---|
||Conduta ativa|Conduta<br>fisiológica|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 meta-análise de 2<br>estudos<sup>348,349</sup><br>Hemoglobina matern|Médias<br>0,1 (DP 2,1)<br>e -0,9 (DP 1,28)<sup>a</sup><br>n=1.293<br>a:queda da hemog|Médias<br>0,6 (DP 1,3)<br>e 0,4 (DP<br>1,56)<sup>a</sup><br>n=1.304<br>lobina(observad|NC<br>D<br>(0<br>1<br>a noperíodopós-|M 0,99 menor<br>,87 menor a<br>,11 menor)<br>parto)|
|1 estudo<sup>350</sup><br>Hemoglobina matern<br>pósparto|Mediana<br>0,5<br>(VIQ -0,1 a 1,2)<br>a: proporção das m|Mediana<br>0,7<br>(VIQ -0,3 a 1,4)<br>ulheres com hem|<br>NC<br>oglobina ≤10g/dl|Mediana 0,2<br>menor (IC<br>NC)<br>p>0,5<br>no segundo dia|
|1 estudo<sup>349</sup><br>Hemoglobina matern<br>horaspós-parto<sup>b</sup>|107/702<br>(15,2%)<br>a: proporção das m|204/718<br>(28,4%)<br>ulheres com hem|RR 0,54<br>(0,44 a 0,66)<br>oglobina ≤9g/dl c|131 menos/<br>1.000<br>(de 97 menos<br>a 159 menos)<br>om 24 a 48|
|1 estudo<sup>348</sup><br>Hemoglobina matern|27/685<br>(3,9%)<br>a:proporção das m|51/694<br>(7,3%)<br>ulheres com hem|RR 0,54<br>(0,34 a 0,84)<br>oglobina <9g/dl n|34 menos/<br>1.000<br>(de 12 menos<br>a 49 menos)<br>opósparto|
|1 estudo<sup>350</sup>|1/103<br>(0,97%)|5/90<br>(5,6%)|RR 0,17<br>(0,02 a 1,47)|46 menos/<br>1.000<br>(de 54 menos<br>a 26 mais)|  
IC intervalo de confiança, RR risco relativo, DM diferença média, VIQ Variação interquartil, DP desvio padrão, NC não calculável  
a. os dados de um estudo<sup>348</sup> foram convertidos em g/dl por especialistas. Erros padrão relatados num estudo<sup>349</sup> foram convertidos em desvios padrão para seu uso na meta-análise.  
b. Relatado como proporção com hemoglobina ≤90 g/litro no estudo e convertido para  g/dl por especialistas para obter consistência  
Tabela 26 – Conduta ativa – Intervenção isolada (administração de ocitocina) versus conduta fisiológica (administração de placebo)  
|Estudos|Número d|e mulheres|E|feito|
|---|---|---|---|---|
||Conduta ativa|Conduta|Relativo (IC|Absoluto (IC|
|||fisiológica|95%)|95%)|  
Tabela 26 – Conduta ativa – Intervenção isolada (administração de ocitocina) versus conduta fisiológica (administração de placebo)  
|Estudos|Número d|e mulheres|Ef|eito|
|---|---|---|---|---|
||Conduta ativa|Conduta|Relativo (IC|Absoluto (IC|
|||fisiológica|95%)|95%)|
|Perda sanguínea ≥ 5<br>|00 ml na hora dopar|to|||
|1 estudo<sup>351</sup>|25/78<br>(32,1%)|55/143<br>(38,5%)|RR 0,83<br>(0,57 a 1,22)|65 menos/<br>1.000<br>(de 165<br>menos a 85<br>mais)|
|Perda sanguínea ≥ 1|000 ml||||
|1 estudo<sup>351</sup>|7/78<br>(9%)|16/143<br>(11,2%)|RR 0,8<br>(0,34 a 1,87)|22 menos/<br>1.000<br>(de 74 menos<br>a 97 mais)|
|Necessidade de tran|sfusão sanguínea||||
|1 estudo<sup>351</sup>|2/78<br>(2,6%)|3/143<br>(2,1%)|RR 1.22<br>(0,21 a 7,16)|5 mais/ 1.000<br>(de 17 menos|
|||||a 129 mais)|
|Necessidade de rem|oção manual daplac|enta|||
|1 estudo<sup>351</sup>|1/78<br>(1,3%)|0/143<br>(0%)|RR 5,47<br>(0,23 a<br>132,66)|13 mais/<br>1.000<br>(de 15 menos|
|||||a 69 mais)|
|Uso de ocitocina ter|apêutica||||
|1 estudo<sup>351</sup>|14/78<br>(17,9%)|26/143<br>(18,2%)|RR 0,99<br>(0,55 a 1,78)|2 menos/<br>1.000<br>(de 82 menos<br>a 142 mais)|
|Peso ao nascer|||||
|1 estudo<sup>351</sup>|Media 3534 gr<br>(DP 410)<br>n=78|Media 3498 gr<br>(DP 444)<br>n=43|NC|DM 36 maior<br>(80.51 menor<br>a 152.51<br>maior)|  
IC Intervalo de confiança, DM diferença média, NC não calculável, RRrisco  relativo, DP desvio padrão  
15.4.1.2 Resumo da evidência e conclusões

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.4.1.2.1 Conduta ativo versos conduta fisiológica -->
As evidências de três estudos (n=3.400) são claras em relação à associação da conduta ativa com a redução da perda sanguínea (≥500ml e ≥1.000ml),  a transfusão sanguínea e medidas melhores da hemoglobina no pós-parto. O quarto estudo menor (n=193) não mostrou diferença significativa nas medidas de hemoglobina, mas uma tendência similar. Três estudos (n=3.400) evidenciaram redução significativa da necessidade de uso de uterotônicos terapêuticos após a conduta ativa, mas não uma  
diferença significativa em relação à necessidade de remoção manual placenta ou à remoção cirúrgica de restos placentários. Os efeitos colaterais (n=1,512) foram mais freqüentes com a adoção da conduta ativa.  
Os recém-nascidos de partos com conduta ativa tiveram um peso médio significativamente menor do que aqueles nascidos em partos com conduta fisiológica (n=3.207). Esta diferença é consequência do volume sanguíneo adicional recebido na coduta fisiológica. Um estudo (n=293) evidenciou também que os primeiros tiveram um maior risco de hematócrito baixo  e um menor risco de hematócrito diminuído. Todos outros resultados neonatais como Apgar <7 (n=1.695), internação em unidade de tratamento intensivo neonatal (n=3.142), taxas de aleitamento materno (n=3.207) e medidas de icterícia (n=1.695) não mostraram diferenças significativas entre recém-nascidos de partos com conduta ativa e aqueles de partos com conduta fisiológica.  
15.4.1.2.2 Conduta ativa (uso somente de ocitocina) versos conduta fisiológica  
Um estudo pequeno (n = 321) não mostrou diferenças significativas em relação à perda sanguínea ou à necessidade de intervenções posteriores com o uso de uterotônicos e remoção manual da placenta e resultados neonatais (peso ao nascer).  
15.4.1.3 Outras considerações  
Em relação aos benefícios clínicos e danos dos dois tipos de conduta, as evidências são claras em demonstrar os benefícios da conduta ativa na redução da hemorragia pós-parto, principlamente nas medidas mais objetivas como a necessidade de tranfusão sanguínea e quedas nos níveis de hemoglobina. Entretanto, os efeitos secundários da conduta ativa, como náusea e vômitos, podem interferir na vivência do parto e no entrosamento entre mãe e bebê. Nessas situações particulares a opinião da mulher, quando orientada sobre os efeitos colaterias, for favorável à conduta expectante, deve ser respeitada, principalmente no caso das mulheres de risco habitual. O estudo das evidências dos componentes isoladamente sugere que a conduta ativa pode ser modificada sem perder seus benefícios. <mark>A tração controlada do cordão, como parte da conduta ativa ou isoladamente pode reduzir o risco de remoção manual da placenta. Ela pode ser oferecida rotineiramente na assistência ao terceiro estágio do trabalho de parto, desde que assistência seja prestada por um profissional treinado. Nas mulheres que preferem uma assistência menos intervencionista, a tração controlada não é necessária, se um uterotônico faz parte da conduta ativa. O corte do cordão pode ser adiado por pelo menos 60 segundos sem que aumente o risco de hemorragia pós-parto (veja seção</mark> 15.4.3). É possível promover o primeiro contato pele a pele entre recém-nascido e mãe com calma, mesmo quando se utiliza a conduta ativa no terceiro estágio do parto.  
Em relação à utilização de recursos e benefícios para a saúde no Brasil, deve-se considerar que a hemorragia pós-parto figura como a segunda causa de mortes maternas no Brasil e que cerca de 98% dos partos acontecem em instituições hospitalares. Considerando os seus claros benefícios, em termos de medidas de hemorragia, a conduta ativa no terceiro período deve ser adotado em todos os partos institucionais. Embora a conduta fisiológica não envolva nenhum custo, o custo dos insumos e os recursos humanos necessários para a  implementação da conduta ativa muito provavelmente são menores do que os custos relacionados ao tratamento da hemorragia como transfusão sanguínea e outros.  
15.4.2 Ocitocina comparada com outras substâncias na conduta ativa do terceiro período do parto 15.4.2.1  Evidências Científicas  
Para a avaliação da evidência em relação ao uso de ocitocina ou ocitona+ergometrina, as diretrizes do  
NICE relataram os resultados de uma revisão sistemática<sup>352</sup> que incluiu 6 ERCs  
Em todos os estudos incluídos na revisão sistemática, as mulheres receberam a ocitocina por via intramuscular no grupo de intervenção e de controle, exceto em um estudo no qual a ocitocina foi administrada por via intravenosa no grupo controle. Entretanto, a via de administração  não interferiu na significância dos resultados após análise de sensibilidade.  
Em 4 ensaios da revisão sistemática, as mulheres receberam ergometrina + ocitocina 1 ml ou ocitocina 10 UI . Em dois estudos  as mulheres receberam ergometrina + ocitocina 1 ml ou 5 UI de ocitocina. Em um destes dois ensaios mulheres receberam OCMT 505 (medicação experimental, similar a ocitocina e ergometrina) em vez da ergometrina +  ocitocina. A ocitocina foi administrada em todos os ensaios no momento do nascimento do ombro anterior do bebê.  
A revisão avaliou as seguintes comparações:  
- Ergometrina + ocitocina versus ocitocina (em qualquer dosagem)  
- Ergometrina + ocitocina versus ocitocina (5 UI)  
- Ergometrina + ocitocina versus ocitocina (10 UI).  
As tabelas abaixo apresentam as evidências e os resultadso das variáveis estudadas.  
Tabela 27 – Ergometrina + ocitocina versus ocitocina (em qualquer dosagem)  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Ergometrina +<br>ocitocina|ocitocina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Perda sanguínea ≥ 50|0 ml na hora dop|arto|||
|1 meta-análise de 6<br>estudos<sup>352</sup>|392/4.661<br>(8,4%)|469/4.671<br>(10%)|RR 0,84<br>(0,74 a 0,95)|16<br>menos/1.000<br>(de 5 menos a<br>26 menos)|
|Perda sanguínea ≥ 10|00 ml||||
|1 meta-análise de 5<br>estudos<sup>352</sup>|86/3.972<br>(2,2%)|111/3.982<br>(2,8%)|RR 0,78<br>(0,59 a 1,03)|6 menos/1.000<br>(de 11 menos a|
|||||1 mais)|
|Necessidade de transf|usão sanguinea||||
|1 meta-análise de 4<br>estudos<sup>352</sup>|49/3.735<br>(1,3%)|36/3.747<br>(0,96%)|RR 1,36<br>(0,89 a 2,09)|3 mais/1.000<br>(de 1 menos a|
|||||10 mais)|
|Necessidade de remo|ção manual dapla|centa|||
|1 meta-análise de 6<br>estudos<sup>352</sup>|130/4.661<br>(2,8%)|127/4.671<br>(2,7%)|RR 1,03<br>(0,81 a 1,31)|1 mais/1.000<br>(de 5 menos a|
|||||8 mais)|
|Uso de ocitocina tera|pêutica||||
|1 meta-análise de 3<br>estudos<sup>352</sup>|397/2.726<br>(14,6%)|466/2.739<br>(17%)|RR 0,86<br>(0,76 a 0,97)|24<br>menos/1.000<br>(de 5 menos a<br>41 menos)|
|Efeito colateral: vômit|o||||
|1 meta-análise de 3|373/2.721|66/2.737|RR 5,72|114|  
Tabela 27 – Ergometrina + ocitocina versus ocitocina (em qualquer dosagem)  
|Estudos|Número de m|ulheres ou fetos|E|feito|
|---|---|---|---|---|
||Ergometrina +<br>ocitocina|<br>ocitocina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|estudos<sup>352</sup>|(13,7%)|(2,4%)|(4,44 a 7,38)|mais/1.000<br>(de 83 mais a<br>154 mais)|
|Efeito colateral: vômit|o e náusea||||
|1 meta-análise de 3<br>estudos<sup>352</sup>|874/3.737<br>(23,4%)|198/3.749<br>(5,3%)|RR 4,47<br>(3,88 a 5,15)|183<br>mais/1.000<br>(de 152 mais a<br>219 mais)|
|Efeito colateral: Hiper|tensão||||
|1 meta-análise de 4<br>estudos<sup>352</sup>|65/3.737<br>(1,7%)|26/3.749<br>(0,69%)|RR 2,47<br>(1,58 a 3,86)|10 mais/1.000<br>(de 4 mais a 20|
|||||<br>mais)|
|Terceiro estágio > 30|min.||||
|1 meta-análise de 5<br>|80/3.645|75/3.659|RR 1,07|1 mais/1.000|
|estudos<sup>352</sup>|(2,2%)|(2%)|(0,78 a 1,46)|(de 5 menos a|
|||||<br>9 mais)|
|Terceiro estágio > 60|min.||||
|1 meta-análise de 2<br>estudos<sup>352</sup>|34/2.419<br>(14%)|31/2.442<br>(13%)|RR 1,11<br>(068 a 18)|1 mais/1.000<br>(de 4 menos a|
||,|,|,  ,|<br>10 mais)|
|Apgar <7 no 5º min.|||||
|1 meta-análise de 2<br>estudos<sup>352</sup>|48/2.729<br>(1,8%)|48/2.739<br>(1,8%)|RR 1<br>(0,67 a 1,49)|0 menos/1.000<br>(de 6 menos a|
|||||9 mais)|
|Admissão em unidade|neonatal||||
|1 estudo<sup>352</sup>|317/1.713<br>|309/1.727<br>|RR 1,03<br>|5 mais/1.000<br>|
||(185%)|(179%)|(09 a 119)|(de 18 menos a|
||,|,|,  ,|<br>34 mais)|
|Icterícia neontal|||||
|1 meta-análise de 2|453/2.729|466/2.739|RR 0,98|3 menos/1.000|
|estudos<sup>352</sup>|(16,6%)|(17%)|(0,87 a 1,1)|(de 22 menos a|
|Amamentação: início|nasprimeiras du|as horas após opa|rto|17 mais)|
|1 estudo<sup>349</sup>|487/748|497/764|RR 1|0 menos/1.000|
||(65,1%)|(65,1%)|(0,93 a 1,08)|(de 46 menos a|
|||||<br>52 mais)|
|Amamentação: sem al|eitamento na al|ta|||
|1 estudo<sup>349</sup>|252/1.713|235/1.727|RR 1,08|11 mais/1.000|
||(14,7%)|(13,6%)|(0,92 a 1,27)|(de 11 menos a|  
Tabela 27 – Ergometrina + ocitocina versus ocitocina (em qualquer dosagem)  
|Estudos|Número de m|ulheres ou fetos|E|feito|
|---|---|---|---|---|
||Ergometrina +<br>|ocitocina|Relativo (IC<br>|Absoluto (IC<br>|
||ocitocina||95%)|95%)|
|||||37 mais)|
|IC Intervalo de confiança;RR|risco relativo||||
|Tabela 28 – Ergometr|ina + ocitocina v|ersus ocitocina(5|UI)||
|Estudos|Número de m|ulheres ou fetos|E|feito|
||Ergometrina+|Ocitocina|Relativo (IC|Absoluto (IC|
||ocitocina||95%)|95%)|
|Perda sanguínea ≥ 50|0 ml na hora do|parto|||
|1 meta-análise de 2<br>estudos<sup>352</sup>|11/919<br>(1,2%)|26/920<br>(2,8%)|RR 0,42<br>(0,21 a 0,85)|16<br>menos/1.000<br>|
|Perda sanguínea ≥ 10|00 ml|||(de 4 menos a<br>22 menos)|
|1 estudo<sup>352</sup>|0/230|1/231|RR 0,33|3 menos/1.000|
||(0%)|(0,43%)|(0,01 a 8,18)|(de 4 menos a|
|Necessidade de remo|ção manual dap|lacenta||31 mais)|
|1 meta-análise de 2<br>estudos<sup>352</sup>|23/919<br>(2,5%)|15/920<br>(1,6%)|RR 1,54<br>(0,81 a 2,92)|9 mais/1.000<br>(de 3 menos a|
|Terceiro estágio > 30|<br>min.<br>|<br>||<br>31 mais)<br>|
|1 meta-análise de 2<br>estudos<sup>352</sup>|9/919<br>(0,98%)|12/920<br>(1,3%)|RR 0,75<br>(0,32 a 1,77)|3 menos/1.000<br>(de 9 menos a|
|Terceiro estágio > 60|min.|||10 mais)|
|1 estudo<sup>352</sup>|4/689|6/689|RR 0,67|3 menos/1.000|
||(0,58%)|(0,87%)|(0,19 a 2,35)|(de 7 menos a|
|IC Intervalo de confiança; RR<br>Tabela 29 – Ergometr|<br>risco relativo; U<br>ina + ocitocina v|<br>I unidades interna<br>ersus ocitocina(10|<br>cionais<br>UI)|<br>12 mais)|
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
||Ergometrina +|ocitocina|Relativo (IC|Absoluto (IC|
||ocitocina||95%)|95%)|
|Perda sanguínea ≥ 50|<br>0 ml na hora do|parto|||
|1 meta-análise de 4|372/3.742|432/3.751|RR 0,87|15|
|estudos<sup>352</sup>|<br>(9,9%)|<br>(11,5%)|<br>(0,76 a 0,99)|menos/1.000|
|||||(de 1 menos a<br>28 menos)|
|Perda sanguínea ≥ 10|00 ml||||
|1 meta-análise de 4|86/3.742|110/3.751|RR 0,79|6 menos/1.000|  
Tabela 29 – Ergometrina + ocitocina versus ocitocina (10 UI)  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Ergometrina +<br>ocitocina|ocitocina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|estudos<sup>352</sup>|(2,3%)|(2,9%)|(0,6 a 1,04)|(de 12 menos|
|Necessidade de trans|fusão sanguinea|||a 1 mais)|
|1 meta-análise de 4<br><sup>352</sup>|49/3.735<br>|36/3.747<br>|RR 1,36<br>|3 mais/1.000<br>|
|estudos|(1,3%)|(0,96%)|(0,89 a 2,09)|(de1 menos a|
|Necessidade de remo|<br> ção manual dap|<br>lacenta||<br>10 mais)|
|1 meta-análise de 4<br>estudos (McDonald|107/3.742<br>(2,9%)|112/3.751<br>(3%)|RR 0,96<br>(0,74 a 1,25)|1 menos/1.000<br>(de 8 menos a|
|et al.,2009)||||7 mais)|
|Uso de ocitocina tera|pêutica||||
|1 meta-análise de 3<br>estudos<sup>352</sup>|397/2.726<br>(14,6%)|466/2.739<br>(17%)|RR 0,86<br>(0,76 a 0,97)|24<br>menos/1.000|
|||||(de 5 menos a<br>41 menos)|
|Efeito colateral: vômi|to||||
|1 meta-análise de 3<br>estudos<sup>352</sup>|487/2.721<br>(17,9%)|128/2.737<br>(4,7%)|RR 3,85<br>(3,2 a 4,63)|133<br>mais/1.000<br>(de 103 mais a<br>70 mais)|
|Efeito colateral: vômi|to e náusea||||
|1 meta-análise de 4<br>estudos<sup>352</sup>|874/3.737<br>(23,4%)|198/3.749<br>(5,3%)|RR 4,47<br>(3,88 a 5,15)|183<br>mais/1.000<br>(de 152 mais a<br>219 mais)|
|Efeito colateral: Hipe|rtensão||||
|1 meta-análise de 4|65/3.737|26/3.749|RR 2,47|10 mais/1.000|
|estudos<sup>352</sup>|(1,7%)|(0,69%)|(1,58 a 3,86)|(de 4 mais a 20|
|||||<br>mais)|
|Terceiro estágio > 30|min.||||
|1 meta-análise de 3<br>estudos<sup>352</sup>|71/2726<br>(2.6%)|63/2739<br>(2.3%)|RR 1.13<br>(0.81 a 1.58)|3 mais/1000<br>(de 4 menos a|
|||||<br>13 mais)|
|Terceiro estágio > 60|min.||||
|1 estudo<sup>352</sup>|30/1.730<br>(1,7%)|25/1.753<br>(1,4%)|RR 1,22<br>(0,72 a 2,06)|3 mais/1.000<br>(de 4 menos a|
|||||15 mais)|
|Apgar <7 no 5º min.|||||
|1 meta-análise de 2|48/2.729|48/2.739|RR 1|0 menos/1.000|  
Tabela 29 – Ergometrina + ocitocina versus ocitocina (10 UI)  
|Estudos|Número de m|ulheres ou fetos|E|feito|
|---|---|---|---|---|
||Ergometrina +<br>ocitocina|ocitocina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|estudos<sup>352</sup><br>Admissão em unidad|(1,8%)<br>e neonatal|(1,8%)|(0,67 a 1,49)|(de 6 menos a<br>9 mais)|
|1 estudo<sup>352</sup><br>Icterícia neontal|317/1.713<br>(18,5%)|309/1.727<br>(17,9%)|RR 1,03<br>(0,9 a 1,19)|5 mais/1.000<br>(de 18 menos<br>a 34 mais)|
|1 meta-análise de 2<br>estudos<sup>352</sup><br>Amamentação: sem a|453/2.729<br>(16,6%)<br>leitamento na alt|466/2.739<br>(17%)<br>a|RR 0,98<br>(0,87 a 1,1)|3 menos/1.000<br>(de 22 menos<br>a 17 mais)|
|1 estudo<sup>352</sup>|252/1.713<br>(14,7%)|235/1.727<br>(13,6%)|RR 1,08<br>(0,92 a 1,27)|11 mais/1.000<br>(de 11 menos<br>a  37 mais)|  
IC Intervalo de confiança; RR risco relativo; UI unidades internacionais 15.4.2.2 Resumo da evidência e conclusões  
Independentemente da dose de ocitocina utilizada, o uso de ergometrina + ocitocina em comparação com a utilização de ocitocina isolada foi associada a uma taxa significativamente mais baixa de HPP com perda de sangue ≥ 500 ml (n=9.332 para qualquer dosagem de ocitocina, n=1.839 para 5 UI e n=7493 para 10 UI). Em Relação à perda sanguinea ≥ 1.000ml, não houve diferença estatisticamente significativa, independentemente da dose utilizada (n=7.954 para qualquer dosagem; n=461 para 5 UI; 7493 para 10 UI). O uso de ergometrina + ocitocina em comparação com o uso de ocitocina em qualquer dosagem ou de 10 UI também foi associado com uma menor necessidade para uso posterior de uterotônicos terapêuticos (n=7.954). Em relação à remoção manual da placenta, da duração do terceiro estágio e da necessidade para hemotransfusão não houve diferenças significativas, independentemente da dose utilizada. <mark>A elevação da PA foi associada ao uso da combinação e</mark> rgometrina + ocitocina. A <mark>incidência de vômitos e náusea foi siginificativamente maior no grupo de ocitocina + ergometrina quando comaparada ao uso de coitocina em qualquer dosagem ou em dosagem de 10UI.  O</mark> s resultados neonatais (Apgar < 7 no 5º minuto, admissão em unidade de tratamento intensiva e icterícia) não apresentaram diferenças entre o uso das duas medicações, independentemente das dosagens utilizadas.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.4.2.3 Outras considerações -->
Em relação aos benefícios clínicos e danos das formas de conduta analisadas, as evidências apontam um benefício da associação ocitocina + ergometrina para a prevenção da HPP na faixa de 500 a 1.000 ml, sem nenhuma diferença na incidência de hemorragia ≥ 1.000 ml. Além do mais, os efeitos adversos como hipertensão náusea e vômitos foram siginificativamente mais comuns no grupo que recebeu ocitocina + ergometrina. Para prevenir um caso de HPP ≥ 500 ml seria necessário tratar 66 mulheres com ocitocina + ergometrina ao invés de ocitocina. Ao contrário porém, seria necessário tratar 5 mulheres com ocitocina + ergometrina para provocar um caso de náusea ou vômito. As náusea e  
vômitos, por sua vez, podem interferir na saúde da mulher e na sua capacidade de desfrutar e cuidar de seu bebê durante o importante período imediatamente após o nascimento. Considerando que a perda sanguínea na faixa de 500-1.000 ml não seria tão preocupante e, diante dos danos da associação ergometrina + ocitocina, não se justifica recomendar sua utilização para prevenção de HPP, sendo a ocitocina a medicação de primeira escolha.  
Em relação ao uso de recursos e benefícios para a saúde no Brasil, embora não exista estudos conclusivos sobre a melhor via de administração da ocitocina, a via intra-muscular é a via mais fácil e de menor custo operacional. Além da facilidade na administração da ocitocina, seu armazenamento não apresenta problemas em países tropicais como o Brasil, enquanto a Ergometrina requer refrigeração para manter a durabilidade do efeito. Em termos de custo/efetividade, a ocitocina provavelmente é mais vantajosa na realidade brasileira.  
15.4.3 Momento de clampeamento do cordão  
15.4.3.1  Evidências Científicas  
As diretrizes do NICE de 2014 incluíram na sua revisão quatro estudos<sup>353-356</sup> . Os estudos incluiram uma revisão sistemática com 15 ensaios de diferentes componentes a partir de uma variedade de locais<sup>355</sup> e 3 ERCs, dos quais houve um no Irã<sup>353</sup> , um no Paquistão<sup>354</sup> e um na Suécia<sup>356</sup> .  
Todos os estudos incluídos avaliaram o efeito do tempo de pinçamento do cordão umbilical de bebês nascidos a termo sobre os resultados maternos e neonatais. O momento de clampeamento do cordão variou entre os estudos. O clampeamento do cordão 'precoce' foi definido como pinçamento imediato do cordão até 1 minuto após o nascimento do bebê. Clampeamento tardio foi definido como pinçamento do cordão entre 1-5 minutos após o nascimento do bebê ou após a cessação da pulsação do cordão. O tipo de uterotônico, a dose utilizada e o tempo de administração também variaram entre os estudos incluídos. Alguns estudos não especificaram se o uterotônico foi usado ou não.  
O nível do posicionamneto do bebê em relaçao ao útero materno antes do clampeamento do cordão foi observado na maioria dos ensaios e relatado na revisão sistemática (McDonald et al., 2013). Em 4 ensaios o bebê foi posicionado ao nível do útero ou da vagina, em 6 ensaios o bebê foi mantido abaixo do nível do útero (que variou de 10 cm a 30 cm abaixo) e em 4 ensaios o bebê foi colocado sobre o ventre materno. Para os dois ensaios restantes a posição do bebê em relação ao útero não foi relatada. A tabela das evidências abaixo expõe todos os resultados da comparação entre clampeamento precoce e tardio de acordo com três subgrupos, definidos em relação ao momento da administração do uterotônico:  
- uterotônico administrado antes clampeamento do cordão  
- uterotônico  administrado no momento ou após o pinçamento do cordão  
- momento da administração do uterotônico não especificado.  
Obs. O clampeamento precoce é a intervenção enquanto o grupo controle consiste nos partos com clampeamento tardio. Na meta-análise todas as variáveis foram analisadas de acordo com o uso de uterotônicos.  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de mu|lheres ou fetos|E|feito|
|---|---|---|---|---|
||Clampeament|Clampeament|Relativo (IC|Absoluto (IC|
||oprecoce|o tardio|95%)|95%)|
|Perda sanguínea ≥ 50|0 ml  – média de t|odas as mulheres|||
|1 meta-análise de 5|144/1.060|147/1.200|RR 1,17|21 mais/1.000|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|estudos<sup>355</sup>|(13,6%)|(12,2%)|(0,94 a 1,44)|(de 7 menos a|
|Perda sanguínea ≥ 50|0 ml – uterotônic|o antes do clampe|amento|54 mais)|
|1 meta-análise de 2<br>estudos<sup>355</sup>|43/492<br>(8,7%)|41/540<br>(7,6%)|RR 1,11<br>(0,74 a 1,67)|8 mais/1.000<br>(de 20 menos a|
|Perda sanguínea ≥ 50<br>clampeamento|0 ml na hora do p|arto – uterotônico|depois ou no m|51 mais)<br>omento do|
|1 meta-análise de 3|77/478|63/478|RR 1.22|29 mais/1.000|
|estudos<sup>355</sup>|(16,1%)|(13,1%)|(0,90 a 1,65)|(de 13 menos a|
|||||90 mais)|
|Perda sanguínea ≥ 50|0 ml – uterotônic|o sem especificar|o momento da a|dministração|
|1 estudo<sup>355</sup>|24/90<br>(26,7%)|43/182<br>(23,6%)|RR 1,13<br>(0,73 a 1,74)|31 mais/1.000<br>(de 64 menos a<br>175 mais)|
|1 meta-análise de 6<br>|(3,5%)|37/1091<br>|RR 1,04<br>|1 mais/1.000<br>|
|estudos<sup>355</sup>||(3,4%)|(0,65 a 1,65)|(de 12 menos a|
|Perda sanguínea ≥ 10|00 ml – uterotôn|ico antes do clamp|eamento|22 mais)|
|1 estudo<sup>355</sup>|9/236<br>|8/244<br>|RR 1,16<br>|5 mais/1.000<br>|
||(3,8%)|(3,3%)|(0,46 a 2,96)|(de 18 menos a|
|Perda sanguínea ≥ 10<br>clampeamento|<br>00 ml na hora do|<br>parto – uterotôni|<br>co depois ou no|<br>64 mais)<br>momento do|
|1 meta-análise de 3|20/478|19/478|RR 1,06|2 menso/1.000|
|estudos<sup>355</sup>|(4,2%)|(4%)|(0,57 a 1,95)|(de 17 menos a|
|Perda sanguínea ≥ 10|00 ml – uterotôn|ico sem especifica|r o momento da|38 mais)<br>administração|
|1 meta-análise de 2|5/261|10/369|RR 0,85|4 menos/1.000|
|estudos<sup>355</sup>|(1,9%)|(2,7%)|(0,29 a 2,49)|(de 19 menos a|
|Perda de sangue méd|ia(ml)-para tod|as as mulheres||40 mais)|
|1 meta-análise de 3<br>estudos<sup>355</sup>|n=669|n=676|NC|DM 5,11 maior<br>(23,18 menor a<br>33,39 maior)|
|||||p=NS|
|Perda de sangue méd|ia(ml)– uterotô|nico antes do clam|peamento||
|1 estudo<sup>355</sup>|373|351|NC|DM 22 maior|
||(DP 366)|(DP 372)||(40,16 menor a|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
||n=236|n=244||84.16 maior)|
|Perda de sangue méd|ia(ml)– uterotôn|ico  depois ou no|momento do cla|p=NS<br>mpeamento|
|1 meta-análise de 2<br>|n=433|n=432|NC|DM 0,7 maior<br>|
|estudos<sup>355</sup><br>Necessidade de trans|fusão sanguínea –|para todas as mu|lheres|(31,06 menor a<br>32,46 maior)<br>p=NS|
|1 meta-análise de 2|10/669|10/676|RR 1,02|0 menos/1.000|
|estudos<sup>355</sup>|(1,5%)|(1,5%)|(0,44 a 2,37)|(de 8 menos a|
|Necessidade de trans|fusão sanguinea –|uterotônico ante|s do clampeame|20 mais)<br>nto|
|1 estudo<sup>355</sup>|3/236<br>(1,3%)|2/244<br>(0,82%)|RR 1,55<br>(0,26 a 9,2)|5 mais/1.000<br>(de 6 menos a|
|Necessidade de trans<br>clampeamento|fusão sanguínea –|uterotônico dep|ois  ou no momen|67 mais)<br>to do|
|1 meta-análise de 2<br>|7/433|8/432|RR 0,89|2 menos/1.000|
|estudos<sup>355</sup>|(1,6%)|(1,9%)|(0,34 a 2,35)|(de 12 menos a|
|Necessidade de remo|ção manual dapl|acenta –para tod|as as mulheres|25 mais)|
|1 meta-análise de 2<br>estudos<sup>355</sup>|18/736<br>(2,4%)|12/779<br>(1,5%)|RR 1,59<br>(0,78 a 3,26)|9 mais/1.000<br>(de 3 menos a|
|Necessidade de remo|ção manual dapl|acenta – uterotôn|ico antes do clam|35 mais)<br> peamento|
|1 meta-análise de 2<br>|16/492<br>|8/540<br>|RR 2.17<br>|17 mais/1.000<br>|
|estudos<sup>355</sup>|(3,3%)|(1,5%)|(0,94 a 5,01)|(de 1 menos a|
|Necessidade de remo<br>clampeamento|ção manual da pl|acenta – uterotôn|ico depois  ou no|59 mais)<br>momento do|
|1 meta-análise de 2<br>estudos<sup>355</sup>|14/669<br>(2,1%)|12/676<br>(1,8%)|RR 1,18<br>(0,55 a 2,52)|3 mais/1.000<br>(de 8 menos a|
|||||27 mais)|
|Uso de ocitocina tera|pêutica – todas as|mulheres|||
|1 estudo<sup>355</sup>|100/480<br>(20,8%)|107/483<br>(22,2%)|RR 0,94<br>(0,74 a 1,2)|13<br>menos/1.000<br>(de 58 menos a<br>44 mais)|
|Uso de ocitocina tera|pêutica – uterotô|nico antes do clam|peamento||  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 estudo<sup>355</sup>|52/236<br>(22%)|49/244<br>(20,1%)|RR 1,1<br>(0,78 a 1,55)|20 mais/1.000<br>(de 44 menos a|
|||||110 mais)|
|Uso de ocitocina tera|pêutica –  uterotô|nico  depois  ou n|o momento do cl|ampeamento|
|1 estudo<sup>355</sup>|48/244<br>(19.7%)|58/239<br>(24.3%)|RR 0.81<br>(0.58 a 1.14)|46<br>menos/1000<br>|
|||||(de 102 menos<br>a 34 mais)|
|Hemoglobina matern|a(g/dl)24-72 hp|osparto –para tod|as as mulheres||
|1 meta-análise de  3<br>estudos<sup>355</sup>|n=557|n=571|NC|DM 0.12<br>menor<br>(0.3 menor a<br>0.06 maior)<br>p=NS|
|Hemoglobina matern|a(g/dl)24-72 hp|osparto – uterotô|nico antes do clam|peamento|
|1 estudo<sup>355</sup>|10.8<br>(DP 1.8)<br>n=236|10.8<br>(DP 1.6)<br>n=244|NC|DM 0 maior<br>(0.31 menor a<br>0.31 maior)|
|||||<br>p=NS|
|Hemoglobina matern<br>clampeamento|a (g/dl) 24-72 h p|osparto – uterotô|nico  depois  ou n|o momento do|
|1 estudo<sup>355</sup>|11.1|11.2|NC|DM 0.1 menor|
||(DP 1.7)<br>|(DP 1.9)<br>||(0.42 menor a<br>|
||n=244|n=239||0.22 maior)|
|||||<br>p=NS|
|Hemoglobina matern|a (g/dl) 24-72 h p|osparto – uterotô|nico sem especific|ar o momento|
|da administração|||||
|1 meta-análise de<br>estudos<sup>355</sup>|n=77|n=88|NC|DM 0.28<br>menor<br>(0.6 menor a<br>0.04 maior)|
|||||<br>p=NS|
|Terceiro estágio > 30|min. –para todas|as mulheres|||
|1 estudo<sup>355</sup>|5/480|5/483|RR 1|0 menos/1000|
||(1%)|(1%)|(0.29 a 3.41)|(de 7 menos a|
|||||25 mais)|
|Terceiro estágio > 30|min. – uterotônic|o antes do clampe|amento||
|1 meta-análise de 2|11/433|11/432|RR 1.1|0 more per|
|estudos<sup>355</sup>|(2.5%)|(2.5%)|(0.44 to 2.29)|1000|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Terceiro estágio > 30|min. – uterotônic|o depois ou no mo|mento do clamp|(from 14 fewer<br>to 33 more)<br>eamento|
|1 estudo<sup>355</sup>|2/244|4/239|RR 0.49|9 menos/1000|
||(0.82%)|(1.7%)|(0.09 a 2.65)|(de 15 menos|
|||||28 mais)|
|Terceiro estágio > 60|min. –para todas|as mulheres|||
|1 meta-análise de 2<br>estudos<sup>355</sup>|12/669<br>(1.8%)|10/676<br>(1.5%)|RR 1.11<br>(0.33 a 3.74)|2 mai/1000<br>(de 10 menos a|
|Terceiro estágio > 60|min – uterotônic|o antes do clampe|amento|41 mais)|
|1 estudo<sup>355</sup>|6/236<br>(2.5%)|6/244<br>(2.5%)|RR 1.03<br>(0.34 a 3.16)|1 mais/1000<br>(de 16 menos|
|Terceiro estágio > 60|min – uterotônic|o depois ou no mo|mento do clampe|53 mais)<br>amento|
|1 meta-análise de 2<br>estudos<sup>355</sup>|6/433<br>(1.4%)|4/432<br>(0.9%)|RR 1.68<br>(0.09 a 31.66)|6 mais/1000<br>(de 8 menos a|
|||||284 mais)|
|Apgar <7 no 5º min. –|para todas as m|ulheres|||
|1 meta-análise de 4<br>estudos<sup>355</sup>|30/700<br>(4.3%)|24/699<br>(3.4%)|RR 1.23<br>(0.73 a 2.07)|8 mais/1000<br>(de 10 menos a|
|Apgar <7 no 5º min. –|<br>uterotônico ant|<br>es do clampeamen|<br>to|<br>38 mais)|
|1 estudo<sup>355</sup>|5/236<br>(2.1%)|3/244<br>(1.2%)|RR 1.72<br>(0.42 a 7.13)|9 mais/1000<br>(de 7 menos a|
|Apgar <7 no 5º min. –|uterotônico dep|ois ou no moment|o do clampeame|75 mais)<br>nto|
|1 meta-análise de 2|8/272|4/268|RR 1.96|14 mais/1000|
|estudos<sup>355</sup>|(2.9%)|(1.5%)|(0.6 a 6.42)|(de 6 menos a|
|||||81 mais)|
|Apgar <7 no 5º min. –|uterotônico sem|especificar o mom|ento da adminis|tração|
|1 estudo (McDonald|17/192|17/187|RR 0.97|3 menos/1000|
|et al., 2013)|(8.9%)|(9.1%)|(0.51 a 1.85)|(de 45 menos a|
|||||77 mais)|
|Admissão em unidade|neonatal -para|todas as mulheres|||
|1 meta-análise de 5<br>estudos<sup>355</sup>|25/788<br>(3.2%)|38/887<br>(4.3%)|RR 0.79<br>(0.48 a 1.31)|9 menos/1000<br>(de 22 menos a|
|||||13 mais)|
|Admissão em unidade|neonatal – uter|otônico  antes do c|lampeamento||  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 estudo<sup>355</sup>|7/236<br>(3%)|5/244<br>(2%)|RR 1.45<br>(0.47 a 4.5)|9 mais/1000<br>(de 11 menos a|
|Admissão em UTIN –|uterotônico depo|is ou no momento|do clampeamen|72 mais)<br>to|
|1 meta-análise de 2|14/433|19/432|RR 0.74|11|
|estudos<sup>355</sup>|(3.2%)|(4.4%)|(0.37 a 1.46)|menos/1000<br>|
|||||(de 28 menos a<br>20 mais)|
|Admissão emUTIN – u|terotônico sem e|specificar o mom|ento da administr|ação|
|1 meta-análise de 2|4/119|14/211|RR 0.57|29|
|estudos<sup>355</sup>|(3.4%)|(6.6%)|(0.2 a 1.6)|menos/1000|
|Desconforto respirató|rio neonatal –pa|ra todas as mulhe|res|(de 53 menos a<br>40 mais)|
|1 meta-análise de 3<br>estudos<sup>355</sup>|29/466<br>(6.2%)|28/369<br>(7.6%)|RR 0.7<br>(0.22 a 2.19)|23<br>menos/1000|
|||||(de 59 menos a<br>90 mais)|
|Desconforto respirató|rio neonatal – ut|erotônico depois|ou no momento d|o clampeamento|
|1 estudo<sup>355</sup>|8/197<br>(4.1%)|6/197<br>(3%)|RR 1.33<br>(0.47 a 3.77)|10 mais/1000<br>de 16 menos|
|Icterícia neonatal dem|<br>andando fototer|<br>apia –para todas|<br>as mulheres|84 mais)|
|1 meta-análise de|31/1131|52/1193|RR 0.62|17|
|8 estudos<sup>355</sup>;1|(2.7%)|(4.4%)|(0.41 a 0.96)|menos/1000|
|estudo<sup>356</sup>||||(de 2 menos a|
|Icterícia neonatal dem|andando fototer|apia – uterotônic|o  antes do clamp|<br>26 menos)<br>eamento|
|1 meta-análise de 2|15/492|27/540|RR 0.59|21|
|estudos<sup>355</sup>|(3%)|(5%)|(0.32 a 1.11)|menos/1000|
|Icterícia neonatal dem<br>clampeamento|andando fototer|apia – uterotônic|o depois ou no m|(de 34 menos<br>6 mais)<br>omento do|
|1 meta-análise de 5|15/549|24/559|RR 0.64|15|
|estudos (1 meta-|(2.7%)|(4.3%)|(0.35 a 1.18)|menos/1000|
|análise de 4 estudos||||(de 28 menos a|
|355;1 estudo356)||||8 mais)|
|Icterícia no exame clín|ico –para todas|as mulheres|||  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 meta-análise de 6<br>estudos<sup>355</sup>|97/977<br>(9.9%)|129/1121<br>(11.5%)|RR 0.84<br>(0.66 a 1.07)|18 menos/<br>1000<br>|
|Icterícia no exame clín|ico – uterotônic|o antes do clampe|amento|(de 39 menos<br>8 mais)|
|1 meta-análise de 2<br>estudos<sup>355</sup>|57/484<br>(11.8%)|75/538<br>(13.9%)|RR 0.86<br>(0.62 a 1.18)|20<br>menos/1000<br>|
|Icterícia no exame clín|ico – uterotônic|o depois ou no mo|mento do clamp|(de 53 menos a<br>25 mais)<br>eamento|
|1 meta-análise de  2<br>estudos<sup>355</sup>|33/286<br>(11.5%)|41/290<br>(14.1%)|RR 0.87<br>(0.57 a 1.31)|18<br>menos/1000<br>|
|Icterícia no exame clín|ico – uterotônic|o sem especificar|o momento da ad|(de 61 menos<br>44 mais)<br>ministração|
|1 meta-análise de 2<br>estudos<sup>355</sup>|7/207<br>(3.4%)|13/293<br>(4.4%)|RR 0.64<br>(0.29 a 1.39)|16<br>menos/1000<br>|
|Policitemia neonatal(|hematócrito >65|%)-para todas as|mulheres|(de 32 menos a<br>17 mais)|
|1 meta-análise de 5|3/459|14/566|RR 0.39|15|
|estudos<sup>355</sup>|(0.7%)|(2.5%)|(0.12 a 1.27)|menos/1000|
|Policitemia neonatal (<br>clampeamento|hematócrito >65|%) – uterotônico d|epois ou no mom|(de 22 menos a<br>7 mais)<br>ento do|
|1 meta-análise de 2|1/280|4/297|RR 0.38|8 menos/1000|
|estudos<sup>355</sup>|(0.4%)|(1.3%)|(0.06 a 2.48)|(de 13 menos a|
|Policitemia neonatal (<br>administração|hematócrito >65|%) – uterotônico s|em especificar o|20 mais)<br>momento da|
|1 estudo<sup>355</sup>|2/179<br>(1.1%)|10/269<br>(3.7%)|RR 0.4<br>(0.09 a 1.8)|22 fewer per<br>1000|
|Hemoglobina neonata|l ao nascimento|(g/dl)–para toda|s as mulheres|(de 34 menos a<br>30 mais)|
|1 meta-análise de 3|n=276|n=395|NC|DM 2.17|
|estudos<sup>355</sup>||||menor<br>(4.06 a 0.28|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|E|feito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|||||menor)<br>p=0.02|
|Hemoglobina neonat<br>clampeamento|al ao nascimento (|g/dl) – uterotônic|o depois ou no|momento do|
|1 estudo<sup>355</sup>|16.8|21.25|NC|DM 4.45|
||(DP 1.27)<br>n=15|(DP 1.67)<br>n=30||menor<br>(5.33 a 3.57<br>menor)<br>p<0.00001|
|Hemoglobina neonat<br>administração|al ao nascimento (|g/dl) – uterotônic|o sem especifica|r o momento da|
|1 meta-análise de 2|n=261|n=365|NC|DM 1.07|
|estudos<sup>355</sup>||||menor<br>(2.03 a 0.12<br>menor)<br>p=0.02|
|Hemoglobina neonat<br>mulheres|al (g/dl) com 24 –|72 horas após o n|ascimento – par|a todas as|
|1 meta-análise de 4|n=385|n=499|NC|DM 1.49|
|estudos (3 estudos||||menor|
|<br>355;1 estudo356)||||(1.78 a 1.21<br>menor)<br>p<0.00001|
|Hemoglobina neonat|al (g/dl) com 24 –|72 horas após o n|ascimento – ute|rotônico depois|
|ou no momento do cl|ampeamento||||
|1 meta-análise de 2|n=206|n=220|NC|DM 1.4 menor|
|estudos<sup>355,356</sup>||||(1.75 a 1.05<br>menor)<br>p<0.00001|
|Hemoglobina neonat|al (g/dl) com 24 –|72 horas – uterot|ônico sem espec|ificar o momento|
|da administração|||||
|1 meta-análise de 2|n=179|n=279|NC|DM 1.68|
|estudos<sup>355</sup>||||menor|
|||||(2.18 a 1.19<br>menor)|
|||||p<0.00001|
|Hemoglobina neonat|al(g/dl)com 2-4m|eses após o nasci|mento –para to|das as mulheres|
|1 estudo<sup>355</sup>|11.3 (07)|11.3 (08)|NC|DM 0 maior|
||n=175|n=168||0.16 menor a|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Hemoglobina neonata|l(g/dl)com 3-6|meses após o nasc|imento –para to|0.16 maior)<br>p=ns<br>das as mulheres|
|1 meta-análise de 6|n=546|n =569|lower|DM 0.15 maior|
|estudos<sup>355</sup>||||(0.48 menor a<br>0.19 maior)<br>p=NS|
|Hemoglobina neonata<br>clampeamento|l (g/dl) com 3-6|meses – uterotôni|co depois ou no m|omento do|
|1 meta-análise de 2<br>|n=220|n=214|NC|DM 0.03 maior|
|estudos<sup>355</sup><br>Hemoglobina neonata<br>administração|l (g/dl) com 3-6|meses – uterotôni|co sem especifica|(0.17 menor a<br>0.22 maior)<br>p=NS<br>r o momento da|
|1 meta-análise de  2<br>estudos<sup>355</sup>|n=326<br>(DP 0.9)<br>n=171|n=355<br>(DP 1.1)<br>n=185|NC|DM 0.26<br>menor<br>(0.79 menor a<br>0.26 maior)<br>p=NS|
|Baixa hemoglobina ne|onatal com 3-6 m|eses após o nasci|mento –para tod|as as mulheres|
|1 meta-análise de 2|73/469|72/485|RR 1.05|7 mais/1000|
|estudos<sup>355</sup>|(15.6%)|(14.8%)|(0.79 a 1.39)|(de 31 menos a|
|Baixa hemoglobina ne<br>clampeamento|onatal com 3-6 m|eses – uterotônic|o depois ou no m|58 mais)<br>omento do|
|1 meta-análise de  2|42/220|44/218|RR 0.96|8 menos/1000|
|estudos<sup>355</sup>|(19.1%)|(20.2%)|(0.67  1.36)|(de 67 menos a|
|Baixa hemoglobina ne<br>administração|onatal com 3-6 m|eses – uterotônic|o sem especifica|73 mais)<br>r o momento da|
|1 meta-análise de 2|31/249|28/267|RR 1.19|20 mais/1000|
|estudos<sup>355</sup>|(12.2%)|(10.5%)|(0.74 a 1.92)|(de 27 menos a|
|HB neonatal <14g/dl c<br>administração|om 6 horas de vi|da – uterotônico s|em especificar o|96 mais)<br>momento da|
|1 estudo<sup>354</sup>|49/100<br>(49%)|37/100<br>(37%)|RR 1.32<br>(0.96 a 1.83)|118 mais/1000<br>(de 15 menos a<br>307 mais)|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||Clampeament|Clampeament|Relativo (IC<br>|Absoluto (IC<br>|
||oprecoce|o tardio|95%)|95%)|
|HB neonatal <10,5g/d<br>|<br>l com 4 meses de|<br>vida – uterotônic|o depois ou no m|omento do|
|clampeamento|||||
|1 estudo<sup>356</sup>|21/175<br>(12%)|21/172<br>(12.2%)|RR 0.98<br>(0.56 a 1.73)|2 menos/1000<br>(de 54 menos a|
|Hematócrito neonata<br>da administração|l <45% com 6 hor|as de vida – utero|tônico sem especi|89 mais)<br>ficar o momento|
|1 estudo<sup>355</sup>|8/90<br>(8.9%)|1/182<br>(0.55%)|RR 16.18<br>(2.05 a 127.37)|<br>83 mais/1000<br>(de 6 menos a|
|Hemtócrito neonatal<br>momento da adminis|<45% com 24-48<br>tração|horas de vida – ut|erotônico sem esp|694 mais)<br>ecificar o|
|1 estudo<sup>355</sup>|15/89<br>(16.9%)|5/179<br>(2.8%)|RR 6.03<br>(2.27 a 16.07)|141 mais/1000<br>(de 35 menos a|
|Hematócrito neonata<br>clampeamento<br>|l com 2 horas de|vida – uterotônico|depois ou no mo|421 mais)<br>mento do|
|1 estudo<sup>353</sup>|61<br>(DP 4.9)<br>n=34|62.2<br>(DP 4.5)<br>n=30|NC|DM 1.2 menos<br>(3.5 menos a<br>1.1 maior)|
|Hematócrito neonata<br>clampeamento<br>|l com 18 horas de|vida – uterotônic|o depois ou no m|<br>p=NS<br>omento do|
|1 estudo<sup>353</sup>|56.9<br>(DP 3.9)|56.2<br>(DP 3.9)|NC|DM 0.7 maior<br>(1.21 menor a|
||n=34|n=30||2.61 maior)|
|Ferritina infantil <20μ|g/L com 4 meses|devida – uterotôn|ico depois ou no|momento do|
|clampeamento|||||
|1 estudo<sup>356</sup>|13/175|0/172|RR 26.54|NC|
||(7.4%)|(0%)|(1.59 a 442.97)||
|Deficiência de ferro c|om 3 – 6 meses||||
|1 meta-análise de 5|75/532|49/620|RR 2.65|130 mais/1000|
|estudos<sup>355</sup>|(14.1%)|(7.9%)|(1.04 a 6.73)|(de 3 menos a|
|Deficiência de ferro c<br>clampeamento|om 3 – 6 meses –|uterotônico depo|is ou no momento|453 mais)<br>do|
|1 meta-análise de 2|38/214|28/211|RR 2.73|230|
|estudos<sup>355</sup>|(17.8%)|(13.3%)|(0.19 a 40.19)|moais/1000<br>(de 107 menos|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de mu|lheres ou fetos|E|feito|
|---|---|---|---|---|
||Clampeament<br>oprecoce|Clampeament<br>o tardio|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Deficiência de ferro co<br>administração|m 3 – 6 meses –|uterotônico sem e|specificar o mo|a 1000 mais)<br>mento da|
|1 meta-análise de 3<br><sup>355</sup>|37/318<br>|21/409<br>|RR 2.91<br>|98 mais/1000<br>|
|estudos|(11.6%)|(5.1%)|(1.18 a 7.2)|(de 9 mais a|
|Desenvolvimento neu|<br>rológico valor ASQ|<br> para motricidad|<br>e fina|<br>318 mais)|
|1 estudo<sup>355</sup>|M 257.5 (29.2)<br>n=180|M 258.9 (28.4)<br>n=185|NC|98 mais/ 1000<br>(de 9 mais a|
|Aleitamento exclusivo|<br>na alta – uterotô|<br>nico antes do cla|mpeamento|<br>318 mais)|
|1 estudo<sup>355</sup>|212/236<br>(89.8%)|216/244<br>(88.5%)|RR 1.01<br>(0.95 a 1.08)|9 mais/ 1000<br>(de 44 menos a|
|Sem aleitamento na al<br>|<br>ta|||<br>71 mais)|
|1 estud0<sup>355</sup>|140/792|139/841|RR 1.11|18 mais/000|
||(17.7%)|(16.5%)|(0.90 a 1.36)|(de 17 menos a|
|||||60 mais)|
|Sem aleitamento com|1 mês de vida||||
|1 estudo<sup>355</sup>|82/90<br>(91.1%)|148/178<br>(83.1%)|RR 1.1<br>(1 a 1.2)|83 mais/ 1000<br>(de 0 mais a|
|||||<br>166 mais)|
|Sem aleitamento com<br>|2 meses de vida||||
|1 estudo<sup>355</sup>|0/41<br>(0%)|2/43<br>(4.6%)|RR 0.21<br>(0.01 a 4.24)|37<br>menos/1000<br>(de 46 menos a|
|||||<br>151 mais)|
|Sem aleitamento com|3 meses de vida||||
|1 estudo<sup>355</sup>|7/69|8/75|RR 10.93|7 menos/ 1000|
||(10.1%)|(10.6%)|(0.36 a 2.42)|(de 68 menos a|
|||||<br>151 mais)|
|Sem aleitamento com|4 meses de vida||||
|1 estudo<sup>355</sup>|102/186|128/205|RR 1|75 menos/|
||(54.8%)|(62.4%)|(0.74 a 1.04)|1000<br>|
|||||(de 162 menos|
|||||<br>a 25 mais)|
|Sem aleitamento com|6 meses de vida||||
|1 estudo<sup>355</sup>|152/208|162/222|RR 0.99|7 menos/1000|
||(73%)|(72.9%)|(0.89 a 1.11)|(de 80 menos a|  
Tabela 30 – Efeito do clampeamento precoce do cordão versus clampeamento tardio  
|Estudos|Número de mu|lheres ou fetos|E|feito|
|---|---|---|---|---|
||Clampeament|Clampeament|Relativo (IC|Absoluto (IC|
||oprecoce|o tardio|95%)|95%)|
|||||92 mais)|  
IC Intervalo de  confiança, DM Diferença média, NC não calculável, UTIN Unidade neonatalde terapia intensivat, NS não significante,  RR Risco relativo, DP Desvio padrão, HB Hemoglobina; Hk Hematócrito 15.4.3.2  Resumo da evidência e conclusões  
Nenhum dos estudos encontrou uma diferença significativa entre os grupos para os seguintes resultados: perda de sangue ≥ 500 ml (n = 2.260 ); perda de sangue ≥ 1000 ml (n = 2066 ); perda sanguínea média (n = 1.345 ); hemoglobina materna 24 a 72 horas pós-parto (n = 1128); transfusão de sangue (n = 1.345 ); remoção manual da placenta ( n = 1515 ); duração da terceira fase do parto > 30 minutos (n = 963) e 60 minutos (n = 1345); necessidade de uterotônicos terapêuticos (n = 963). Estes resultados não foram afetados pelo momento da administração do uterotônico. A análise do subgrupo para paises desenvolvidos também não mostrou resultados contraditórios. Portanto, do ponto de vista materno, na há contraindicação para o clampeamento tardio do cordão.  
Evidência de alta qualidade mostrou que a incidência de icterícia requerendo fototerapia (n = 2.324) foi menor em recém-nascidos alocados no grupo do clampeamento precoce comparado com aqueles alocados no grupo do clampeamento tardio. Os níveis de hemoglobina com 24-48 horas de vida (n = 884) também foram menores neste grupo. No entanto, não foram encontradas diferenças significativas entre os 2 grupos para o nível de hemoglobina com 2-4 meses (n = 343) ou 6 meses após o nascimento (n = 1.115) e para os níveis de ferritina com 4 meses de vida (n = 347). A evidência mostrou que a deficiência de ferro do lactente (n = 1.152) foi significativamente maior em recém-nascidos alocados no grupo do clampeamento precoce. Houve ainda um aumento significativo de recém-nascidos com hematócrito menor que 45 % com 6 horas de vida e 24-48 horas no grupo de clampeamento precoce. Nenhum dos estudos encontrou uma diferença significativa entre os grupos para os seguintes resultados: incidência de icterícia ao exame clínico (n = 2.098); Apgar menor que 7 no 5º minuto (n = 1.399); admissão em unidade de terapia intensiva neonatal (UTIN) (n = 1675); desconforto respiratório (n = 835); policitemia (n = 1.052); sem amamentação na alta (n = 1.623) e aos 2, 4 e 6 meses (n = 430). Estes resultados não foram afetados pelo momento da administração do uterotônico.  
Seis dos 14 estudos incluídos foram realizados em países desenvolvidos e a análise deste subgrupo mostrou que o número de recém-nascidos com icterícia demandando fototerapia foi significativamente menor no grupo do clampeamento precoce comparados com o grupo do clampeamento tardio. Observou-se também que o momento da administração de um uterotônico em relação ao momento do clampeamento do cordão não interfere nos resultados de forma significativa, embora houvesse uma tendência de aumento do risco para retenção de placenta com clampeamento precoce do cordão após a administração de um uterotônico.  
À luz desta evidência, o grupo de desenvolvimento das diretrizes do NICE decidiu recomendar o clampeamento tardio do cordão, determinando o momento adequado entre um e cinco minutos após o nascimento. Esta recomendação será seguida também nestas Diretrizes. 15.4.3.3 Outras considerações  
Em relação aos benefícos clínicos e danos das duas condutas analisadas, foi dado maior ênfase nos niveis da hemoglobina do lactente para elaborar as recomendações, uma vez que os limites de  
bilirrubina admitidos para a fase neonatal são mais elevados do que nos estudos e existe uma grande amplitude para os níveis de ferritina considerados normais. As diferenças na hemoglobina não excederam os limites considerados clinicamente relevantes. A diferença entre os grupos em relação ao hematócrito neonatal não foi considerada importante do ponto de vista clínico.  
O momento do clampeamento do cordão não interfere na amamentação a longo prazo, uma vez que a taxa de aleitamento materno com 2 a 6 meses não mostrou diferença.  
Uma das principais vantagens do clampeamento precoce é o suprimento com oxigênio do recémnascido pela transfusão de sangue da placenta enquanto o cordão umbilical ainda está pulsando. Isto é especialmente relevante nos casos em que o comprometimento fetal ocorre em fases mais tardias do trabalho de parto. Supõe-se que a passagem de sangue no primeiro minuto pode contribuir para um melhor êxito das manobras de reanimação. Diante disso, conclui-se que na maioria dos casos, o cordão não deve ser clampeado antes do 1º minuto de vida da criança. As evidências não indicam um limite superior para o clampeamento do cordão, mas a maioria dos estudos não avaliaram os efeitos do clampeamento após 3 minutos. Aparentemente não há benefícios adicionais do clampeamento após este prazo, mas os profissionais devem ser flexíveis na sua assitência para adequá-la às preferências da parturiente.  
Em relação aos benefícos para a saúde e uso de recursos, podem surgir custos adicionais para o sistema de saúde por causa do aumento de icterícia observado nos estudos demandando fototerapia, dependendo do protocolo utilizado nos serviços. O clampeamento tardio do cordão pode permitir a realização do contato pele a pele imediato, uma vez que não há necessidade de manipulação do recémnascido pelo profissional nos primeiros minutos da sua vida. Isso pode trazer para mãe e filho uma vivência positiva.  
15.5 Hemorragia pós-parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.5.1 Fatores de risco para hemorragia pós-parto -->
15.5.1.1 Evidências Científicas  
15.5.1.1.1 Múltiplos fatores  
As diretrizes do NICE incluíram na sua revisão sete estudos (dois estudos caso-controle<sup>357,358</sup> e cinco estudos de corte transversal<sup>359–363</sup> ) em busca de múltiplos fatores de risco para hemorragia pós-parto, embora três deles fossem inconclusivos.<sup>357,360,361</sup> Serão sumarizados aqui os estudos conclusivos.  
Um estudo de corte transversal realizado na Holanda incluindo 3.464 mulheres nulíparas<sup>359</sup> [NE = 3] investigou os fatores de risco para hemorragia pós-parto (HPP) padrão (≥ 500 ml de perda sanguínea) e grave (> 1.000 ml de perda sanguínea). Análises de regressão logística multivariada demonstraram fatores de rico significativos para HPP padrão como: placenta retida  (OR ajustada 7.83 [IC 95% 3,78 a 16,22]); terceiro período prolongado (> 30 minutos) (OR ajustada 2,61 [IC 95% 1,83 a 3,72]); gestação múltipla (OR ajustada 2,60 [IC 95% 1,06 a 6,39]); episiotomia (OR ajustada  2,18 [IC 95% 1,68 a 2,81]); macrossomia (> 4 kg) (OR ajustada 2,11 [IC 95% 1,62 a 2,76]); trauma perineal (OR ajustada  1,40 [IC 95% 1,04 a 1,87]); raça da Europa Ocidental (OR ajustada 1,32 [IC 95% 1,00  1,73]). Os fatores de risco para HPP grave foram: placenta retida (OR ajustada 11,73 [IC 95% 5,67 a 24,1]); terceiro período prolongado (> 30 minutos) (OR ajustada 4,90 [IC 95% 2,89 s 8.32]); macrossomia (OR ajustada 2,55 [IC 95% 1,57 a 4,18]); e trauma perineal (OR ajustada 1,82 [IC 95% 1,01 a 3,28]). Na análise estratificada pelo risco inerente das mulheres, os seguintes fatores de risco para HPP grave nas mulheres de baixo risco ficaram demonstrados: placenta retida (OR ajustada 21,6 [IC 95% 5,99 a 78,00]); terceiro período prolongado (> 30 minutes) (OR ajustada 3,59 [IC 95% 1,60 a 8,03]); enquanto aqueles para as mulheres de alto risco  
foram: placenta retida (OR ajustada 9,29 [IC 95% 3,69 a 23,4]); terceiro período prolongado (> 30 minutes) (OR ajustada 6,11 [IC 95% 2,94 a 12,7]); macrossomia (OR ajustada 2,75 [IC 95% 1,52 a 4,97]); indução (OR ajustada 1,74 [IC 95% 1,06 a 2,87]); segundo período prolongado (≥ 30 minutos) (OR ajustada 2,74 [IC 95% 1,37 a 5,49]).  
Um estudo caso-controle realizado na Austrália investigou os fatores de risco para hemorragia em 250 mulheres (125 casos contra 125 controles)<sup>358</sup> [NE = 2+]. Após análise de regressão logística ficou demonstrado que os fatores de risco para HPP ≥ 500 ml foram: história anterior de HPP (OR ajustada 14,11 [IC 95% IC 1,62 a 123,06]); segundo período do parto prolongado (≥ 60 min.) (OR ajustada 2,68 [IC 95% 1,27 a 5,64]); fórceps (OR ajustada 3,47 [IC 95% 1,35 a 8,91]); e membranas incompletas/laceradas (OR ajustada 3,56 [IC 95% 1,52 a 8,36]).  
Outro estudo de corte transversal realizado na Austrália envolvendo 13.868 mulheres<sup>362</sup> [NE = 3] demonstrou, após análise de regressão logística, os seguintes fatores de risco para HPP (≥ 1.000 ml ou necessidade transfusão): Raça (OR ajustada 1,8 [IC 95% 1,4 a 2,2]); distúrbios hematológicos (OR ajustada 1,3 [IC 95% 1,1 a 1,6]); HPP anterior (OR ajustada 1,8 [IC 95% 1,4 a 2,2]); história de retenção placentária (OR ajustada 6,2 [IC 95% 4,6 a 8,2]); gestação múltipla (OR ajustada 2,2 [IC 95% 1,5 a 3,2]); hemorragia anteparto (OR ajustada 1,8 [IC 95% 1,3 a 2,3]); lacerações genitais genital (OR ajustada 1,7 [IC 95% 1,4 a 2,1]); macrossomia (≥ 4 kg) (OR ajustada 1,8 [IC 95% 1,4 a 2,3]); parto induzido (OR ajustada 1,8 [IC 95% 1,4 a 2,2]); corioamnionite (OR ajustada 1,3 [IC 95% 1,1 a 1,7]); hemorragia intraparto (OR ajustada 1,5 [IC 95% 1,0 a 2,3]); morte fetal (OR ajustada 2,6 [IC 95% 1,1 a 5,7]); apresentação fetal composta (OR ajustada 3,0 [IC 95% 1,1 a 7,3]); analgesia peridural (OR ajustada 1,3 [IC 95% 1,0 a 1,6]); primeiro/segundo período do parto prolongado (primeiro período) (OR ajustada 1,6 [IC 95% 1,0 a 1,6]); segundo período (OR ajustada 1,6 [IC 95% 1,1 a 2,1]); e fórceps após falha de vácuoextrator OR (ajustada 1,9 [IC 95% 1,1 a 3,2]).  
15.5.1.1.2 Placenta baixa  
Um estudo de corte transversal realizado no Canadá<sup>364</sup> [NE = 3] demonstrou, após análise de regressão logística multivariada, que a placenta baixa esteve significativamente associada ao risco de HPP (≥ 500 ml para parto vaginal, > 1000 ml para cesariana (OR ajustada 1,72 [IC 95% 1,12 a 2,66], ajustado para idade materna e peso ao nascer).  
15.5.1.1.3 Segundo período do parto prolongado  
Em um estudo de corte transversal realizado nos EUA<sup>313</sup> [NE = 3], após análise de regressão logísitica, não demonstrou associação entre o segundo período do parto prolongado (> 4 horas) com a HPP (RR 1,05 [IC 95% 0,84 a 1,31]).  
Outro estudo realizado na Alemanha (n = 1.200)<sup>315</sup> [NE = 3] demonstrou que o segundo período do parto prolongado (> 2 horas) esteve associado com baixos escores de Apgar em 1 minuto, HPP, lacerações perineais e febre puerperal, embora as análises não tenham controlado para fatores de confusão.  
Um estudo de corte transversal (n = 25.069) realizado no Reino Unido<sup>319</sup> [NE = 3] demonstrou, após análise de regressão logística, uma associação entre maior duração do segundo período do parto e HPP (duração: 120-179 minutos, OR 1,6 [IC 95% 1,3 a 1,9]; 180-239 min, OR 1,7 [IC 95% 1,3 a 2,3)]; 240 minutos ou mais, OR 1,9 [IC 95% 1,2 a 2,8])  
Outro estudo de corte transversal realizado nos EUA (n = 4.403)<sup>322</sup> [NE = 3], sem controle de fatores de confusão, não demonstrou associação entre a duração do segundo período do parto e desfechos neonatais, exceto baixo escore de Apgar no primeiro minuto (P < 0,03). A HPP e a morbidade febril  
estiveram associadas com a duração do trabalho de parto (P < 0.001 para ambos), mas as análises não consideraram os fatores de confusão.  
Um estudo de corte transversal realizado nos EUA (n = 7.818)<sup>314</sup> [NE = 3] demonstrou associação entre o segundo período do parto prolongado (> 120 minutos) e HPP (RR 2.70, P < 0.001). 15.5.1.1.4 Terceiro período do parto prolongado Ver seção  
15.5.1.1.5 Índice de Massa Corporal (IMC) e peso  
Em um estudo de corte transversal realizado no Reino Unido entre 1990 e 1999 incluindo 60.167 partos ficou demonstrado que mulheres com IMC > 30 kg/m2 tiveram risco siginificativamente aumentado de HPP ≥ 500 ml  (OR 1,5 [IC 95% 1,2 a 1,8]), embora não tenha sido realizadas análise para controle de fatores de confusão.<sup>365</sup> [NE = 3]  
Em um estudo de corte transversal realizado no Canadá entre 1988 e 2002, envolvendo 142.404 mulheres, após análises de regressão logística multivariada, demonstrou-se que mulheres com peso entre 90 e 120 Kg tiveram risco aumentado de HPP (OR ajustada 1,12 [IC 95% 1,02 a 1,22]), associação essa não encontrada em mulheres com peso superior a 120 Kg (OR ajustada 1,07 [IC 95% 0,80 a 1,42]).<sup>366</sup> [NE = 3]  
Em um estudo de corte transversal conduzido no Reino Unido entre 1989 e 1997, incluindo 325.395 gestações, após controle para variáveis de confusão (etnia, paridade, idade e história de hipertensão), ficou demonstrado um risco aumentado de HPP > 1.000 ml entre as mulheres com IMC entre 25–30 kg/m2, (OR ajustada 1,16 [IC 99% 1,12 a 1,21]; e IMC ≥ 30 kg/m2, (OR ajustada 1,39 [IC 99% 1,32 a 1,46].<sup>367</sup> [NE = 3]  
Outro estudo de corte transversal realizado no Reino Unido entre 1988 e 1997 com a mesma população do estudo anterior, incluindo 215.105 mulheres, após análises de regressão logísitica, demostrou que mulheres com IMC entre 20-25 kg/m2) tiveram menor chance de HPP em geral (OR ajustada 0,85 [IC 99% 0,80 a 0,90]; e HPP grave (OR ajustada 0,83 [IC 99% 0,72 a 0,95]).<sup>368</sup> [NE = 3]  
15.5.1.1.6 Nascimento pós-termo  
Um um estudo de corte tranaversal realizado entre 1978 e 1993, após análise de regressão logísitica, evidenciou um risco significativamente maior de HPP nas gestantes pós-temo (OR ajustada 1,37 [IC 95% 1,28 a 1,46])<sup>369</sup> [NE = 3] .  
15.5.1.1.7 Macrossomia  
Em um estudo de corte transversal realizado no Reino Unido entre 1988 e 1987, envolvendo 350.311 gestações, após análise de regressão logística múltipla, ficou demonstrado um risco significativamente maior de HPP entrte as mulheres com recém-nascidos com peso > 4 kg (OR ajustado 2,01 [IC 99% 1,93 a 2,10]) e com peso acima do percentil 90 (OR ajustado 1,63 [IC 99% 1,56 a 1,71])<sup>370</sup> [NE = 3].  
Um estudo de corte transversal realizado no EUA, incluindo 146.526 partos, após análise de regressão logísitica múltipla, evidenciou um maior risco de hemorragia nas mulheres cujos recém-nascidos tinham peso aumentado (4.000–4.499 g, OR ajustado 1,69 [IC 95% 1,58 a 2,10]; 4.500–4.999 g, OR ajustado 2,15 [IC 95% 1,86 a 2,48]; ≥ 5000 g, OR ajustada 2,03 [IC 95% 1,33 a 3,09]).<sup>371</sup> [NE = 3] 15.5.1.1.8 Idade materna  
Estudo realizado no Reino Unido, incluindo 385.120 gestações, após análise de regressão logística, demonstrou associação sginificativa entre a idade materna e a HPP (35–40 anos HPP moderada, OR ajustada 1,14 [IC 99% 1,09 a 1,19]; HPP grave OR ajustada 1,28 [IC 99% 1,16 a 1,41]); > 40 anos HPP moderada, OR ajustada 1,27 [IC 99% 1,15 a 1,39]; HPP grave OR ajustada 1,55 [IC 99% 1,29 a 1,88]).<sup>372</sup>

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: [NE = 3] -->
Estudo realizado no Japão, após análise de regressão logística, demonstrou risco aumentado de HPP em mulheres com 35 anos ou mais (parto vaginal, OR ajustada 1,5 [IC 95% 1,2 a 1,9]; cesariana, OR ajustada 1,8 [IC 95% 1,2 a 2,7]) quando comparadas com mulheres com menos de 30 anos.<sup>373</sup> [NE = 3] 15.5.1.1.9 Paridade  
Em relação à paridade, foram incluídos estudos de corte transversal com resultados conclusivos, sumarizados a seguir:  
Um estudo caso controle pareado realizado no Reino Unido, envolvedo 397 grande multíparas pareado por idade com 397 multíparas, não encontrou diferenças na incidência de HPP entre os grupos (OR 1,18 [IC 95% 0,6 a 2,4]).<sup>374</sup> [NE = 3]  
Estudo realizado no Reino Unido publicado em 1987, envolvendo 216 grande multíparas comparadas com mulheres de menor paridade pareadas por idade e etnia, encontrou maior incidência de HPP > 500 ml entre as grande multíparas (P < 0.01).<sup>375</sup> [NE = 3]  
Estudo realizado na Austrália entre 1992 e 2001 comparou 653 grande multíparas com 15.255 mulheres de menor paridade e, após análise de regressão logísitica, encontrou ligeiro aumento no risco de HPP entre as grande multíparas (OR 1.36 [IC 95% 0,99 a 1,87]).<sup>376</sup> [NE = 3]  
Estudo realizado nos EUA comparou 382 grande multíparas com outras mulheres, pareadas por idade, com paridade entre dois e quatro, entre 1989 e 1991 não encontrou diferenças na incidência de HPP entre os grupos  (OR 0,97 [IC 95% 0,57 a 1,63]).<sup>377</sup> [NE = 3]  
Outro estudo estadunidense comparou 25.512 grande multíparas com 265.060 mulheres multíparas com 30 anos ou mais de idade, entre 1997 e 1998, encontrando maior risco de HPP entre as grande multíparas (OR ajustada 1,2 [1,1 a 1,3]).<sup>378</sup> [NE = 3]  
Outro estudo inglês, envolvendo 36.312 mulheres, realizado entre 1967 e 1981 encontrou maior incidência de HPP em nulíparas e após parto induzido. Nas 6.615 mulheres com dois ou mais nascidos vivos entre 1967 e 1989 houve um risco duas e quatro vezes maior de HPP em um parto subsequente entre aquelas com história prévia de HPP ou placenta retida, comparadas com aquelas que não possuíam tais fatores de risco.<sup>379</sup> [NE = 3]  
15.5.1.2 Resumo da evidência e conclusões sobre fatores de risco para hemorragia pós-parto São fatores de risco para hemorragia pós-parto:  
Pré-natais: história prévia de placenta retida, história de HPP, hemglobina materna < 8,5 g/dl no iníco do trabalho de parto; IMC aumentado; grande multiparidade (quatro ou mais); hemorragia ante-parto; sobredistensão uterina (ex. gravidez múltipla, polihidrâmnio, macorssomia); anomalias uterinas; placenta baixa; e idade (≥ 35 anos).  
Intraparto: indução, primeiro, segundo e terceiro período do parto prolongado, uso de ocitocina, parto precipitado, parto operatória ou cesariana.  
15.6 Recomendações quanto à assistência no terceiro período do parto  
144. Reconhecer que o período imediatamente após o nascimento é um período bastante sensível, quando a mulher e seus acompanhantes vão finalmente conhecer a criança. Assegurar que a assistência e qualquer intervenção que for realizada levem em consideração esse momento, no sentido de minimizar a separação entre mãe e filho.  
145. Para efeito destas Diretrizes, utilizar as seguintes definições:  
- O terceiro período do parto é o momento desde o nascimento da criança até a expulsão da placenta e membranas.  
- A conduta ativa no terceiro período envolve um conjunto de intervenções com os seguintes componentes:  
- uso rotineiro de substâncias uterotônicas;  
- clampeamento e secção precoce do cordão umbilical; e  
- tração controlada do cordão após sinais de separação placentária.  
- A conduta fisiológica no terceiro período do parto envolve um conjunto de cuidados que inclui os seguintes componentes:  
- sem uso rotineiro de uterotônicos;  
- clampemento do cordão após parar a pulsação; e  
- expulsão da placenta por esforço materno.  
146. Considerar terceiro período prolongado após decorridos 30 minutos. Seguir recomendações 164172 no caso de placenta retida.  
147. Manter observação rigorosa da mulher, com as seguintes avaliações:  
- condição física geral, através da coloração de pele e mucosas, respiração e sensação de bemestar;  
- perda sanguínea  
148. Se houver hemorragia, retenção placentária, colapso materno ou qualquer outra preocupação quanto ao bem-estar da mulher:  
- solicitar assistência de médico obstetra para assumir o caso se este não for o profissional assistente no momento;  
- instalar acesso venoso calibroso e informar a puérpera sobre a situação e os procedimentos previstos;  
- se o parto ocorreu em domicilio ou unidade de parto extra ou peri-hospitalar, a puérpera deve ser transferida imediatamente para uma maternidade baseada em hospital.  
149. Explicar à mulher, antes do parto, as opções de conduta no terceiro período, com os riscos e benefícios de cada uma.  
150. Explicar à mulher que a conduta ativa:  
- encurta o terceiro período em comparação com a conduta fisiológic;  
- está associado a náusea e vômitos em cerca de 100 mulheres em 1.000;  
- está associado com um risco aproximado de 13 mulheres em 1.000 de uma hemorragia de mais de 1 litro de sangue; e  
- está associada com um risco aproximado de 14 mulheres em 1.000 de uma transfusão de sangue.  
151. Explicar à mulher que a conduta fisiológica:  
- está associada a náusea e vômitos em cerca de 50 mulheres em 1.000;  
- está associada com um risco aproximado de 29 mulheres em 1.000 de uma hemorragia de mais de 1 litro de sangue; e  
- está associada com um risco aproximado de 40 em 1.000 de uma transfusão de sangue.  
152. A conduta ativa é recomendada na assistência ao terceiro período do parto pois está associado com menor risco de hemorragia e transfusão sanguínea.  
153. Se uma mulher com baixo risco de hemorragia pós-parto solicitar conduta expectante,  apoiá-la em sua escolha.  
154. Para a conduta ativa, administrar 10 UI de ocitocina intramuscular após o desprendimento da  
criança, antes do clampeamento e corte do cordão. A ocitocina é preferível, pois está associada com menos efeitos colaterais do que a ocitocina associada à ergometrina.  
155. Após a administração de ocitocina, pinçar e seccionar o cordão.  
- Não realizar a secção do cordão antes de 1 minuto após o nascimento, a menos que haja necessidade de manobras de ressuscitação neonatal.  
- Pinçar o cordão antes de 5 minutos após o nascimento para realizar a tração controlada do cordão como parte da conduta ativa.  
- Se uma mulher solicitar o clampeamento e secção do cordão após 5 minutos, apoiá-la em sua escolha.  
156. Após a secção do cordão realizar tração controlada do mesmo.  
157. A tração controlada do cordão, como parte da conduta ativa, só deve ser realizada após administração de ocitocina e sinais de separação da placenta.  
158. Documentar o momento do clampeamento do cordão tanto na conduta ativa quanto na conduta expectante.  
159. Mudar da conduta expectante para a conduta ativa se ocorrer:  
- Hemorragia ou  
- a placenta não dequitou 1 hora após o parto.  
160. Oferecer a conduta ativa quando a mulher prefere encurtar o terceiro estágio do trabalho de parto.  
161. Não usar injeção de ocitocina na veia umbilical rotineiramente.  
162. As mulheres que apresentarem fatores de risco para hemorragia pós-parto devem ser orientadas a ter o parto em uma maternidade baseada em hospital, onde existem mais opções de tratamentos emergenciais.  
163. Se uma mulher apresentar fatores de risco para hemorragia pós-parto, isso deve ser registrado no seu prontuário e cartão de pré-natal, para que um plano de assistência no terceiro período do parto seja realizado.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.7 Retenção placentária -->
- 15.7.1  Evidências Científicas  
As diretrizes do NICE de 2014 incluíram 9 estudos na sua revisão<sup>380,381,382,383,384,385,386,387,388</sup> . Os estudos incluídos consistem em uma revisão sistemática, com 15 ensaios de de vários países<sup>382</sup> e 8 ERCs da Suécia<sup>380</sup> , Tanzânia<sup>384</sup> , Holanda<sup>383,386</sup> , Egito<sup>381</sup> , Tailândia<sup>385</sup> , Índia<sup>387</sup> e da Malásia<sup>388</sup> .  
A maioria dos estudos avaliou a conduta no caso da retenção placentária após a conduta ativa na terceira fase do trabalho de parto. No entanto, em 2 ensaios na revisão sistemática nem todas as mulheres receberam um ocitócico durante a terceira fase. Em mais de 4 ensaios da revisão sistemática, nenhum detalhe foi relatado sobre a conduta no terceiro estágio. A definição de retenção placentária variou entre os estudos, estipulando prazo entre 15 a 60 minutos após o nascimento do bebê. Nenhum dos estudos incluíram mulheres com hemorragia pós-parto e uma análise de sub-grupo destas mulheres não pôde ser realizada.  
Os estudos incluídos avaliaram as seguintes comparações:  
- Injecção de ocitocina na veia umbilical (IVU) versus conduta expectante (Nardin et al. 2011)  
- IVU de ocitocina versus IVU salina (Nardin et al, 2011;. Samanta et al, 2013; Lim et al, 2011)  
- IVU de ocitocina versus IVU de prostaglandina (misoprostol ou PGF2a) (Harara et al., 2011;Nardin et al., 2011)  
- IVU de ocitocina versus IVU expansor plasmático (Nardin et al., 2011)  
- IVU de ocitocina versus IVU ergometrina (Harara et al., 2011)  
- IVUde solução salina  versus conduta expectante (Nardin et al., 2011)  
- Uso de prostaglandina (misoprostol, PGF2a ou sulprostona) versus solução salina com IVU (Nardin et al., 2011) ou intravenosa (IV) (van Beekhuizen et al., 2006)  
- IVU (misoprostol) de prostaglandina versus IVU de ergometrine (Harara et al., 2011)  
- Uso de nitroglicerina intravenosa (IV) (Visalyaputra et al., 2011) ou sublingual versus placebo, (Bullarbo et al., 2005)  
 Uso de misoprostol oral versus placebo (van Stralen et al., 2013; Van Beekhuizen et al., 2013) Houve muita variação nos estudos incluídos no que diz respeito ao tipo de conduta ativa na terceira fase do trabalho de parto, ao tempo para o diagnóstico de uma placenta retida, à dose utilizada e ao tempo após o qual se considerou falha da conduta e indicação da remoção manual da placenta. Por esta razão, um modelo de efeitos aleatórios foi utilizado para todos as meta-análises. As tabelas abaixo mostram os resultados destas comparações.  
Tabela 31 – Injeção de ocitocina na veia umbilical (IVU) versus conduta expectante  
|Estudos|Número d|e mulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||IVU Ocitocin|a<br>Conduta<br>expectante|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Mortalidade Materna|||||
|1 meta-análise de 2<br>estudos<sup>382</sup>|0/45<br>(0%)|0/48<br>(0%)|NC|NC|
|Necessidade de trans|fusão sanguin|ea|||
|1 meta-análise de 2<br>estudos<sup>382</sup>|18/120<br>(15%)|19/117<br>(16.2%)|RR 0.89<br>(0.5 a 1.58)|18 menos/<br>1000<br>(de 81 menos<br>a 94 mais)|
|Necessidade de remo|ção manual d|aplacenta|||
|1 meta-análise de 5<br>estudos<sup>382</sup>|117/234<br>(50%)|123/210<br>(58.6%)|RR 0.82<br>(0.65 a 1.05)|105 menos/<br>1000<br>(de 205 menos<br>a  29 mais)|
|Necessidade de remo|ção cirúrgica|de restosplacentário|s||
|1 estudo<sup>382</sup>|23/94<br>(24.5%)|31/88<br>(35.2%)|RR 0.69<br>(0.44 a 1.09)|109 menos/<br>1000<br>(de 197 menos<br>a 32 mais)|
|Morbidade materna g<br>respiratória aguda, o<br>remoção manual dap|rave (histere<br>utros procedi<br>lacenta)|ctomia, admissão em<br>mentos adicionais par|UTI, insuficiência<br>a tratamento de|renal ou<br>HPP além da|
|1 meta-análise de 2<br>estudos<sup>382</sup>|0/45<br>(0%)|0/45<br>(0%)|NC|NC|  
Tabela 31 – Injeção de ocitocina na veia umbilical (IVU) versus conduta expectante  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
||IVU Ocitocina|Conduta<br>expectante|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Perda sanguínea ≥ 5|00 ml(HPP leve)||||
|1 estudo<sup>382</sup>|26/96<br>(27.1%)|15/89<br>(16.9%)|RR 1.51<br>(0.88 a 2.61)|86 mais/ 1000<br>(de 20 menos<br>a  271 mais)|
|Perda sanguínea ≥ 1|000 ml(HPPgrav|e)|||
|1 estudo<sup>382</sup>|6/70<br>(8.6%)|4/60<br>(6.7%)|RR 1.29<br>(0.38 a 4.34)|19 mais/ 1000<br>(de 41 menos<br>a 223 mais)|
|Hemoglobina 24-48|horas após opart|o|||
|1 estudo<sup>382</sup>|Média 9.7<br>(DP 1.9)<br>n=85|Média 9.7<br>(DP 2.1)<br>n=81|NC|DM 0 maior<br>(0.61 menos a<br>0.61 maior)|
|Infecção|||||
|1 estudo<sup>382</sup>|5/93<br>(5.4%)|4/86<br>(4.7%)|RR 1.16<br>(0.32 a 4.16)|7 mais/ 1000<br>(de 32 menos<br>a  147 mais)|  
CI Intervalo de Confiança, DM Diferença média, NC não calculável, RR Risco relativo, DP Desvio padrão, IVU Injeção na veia umbilical,  UTI Unidade de terapia intensiva, HPP hemorragia pósparto  
a. Nos 5 ERCs a duração da conduta expectante antes da remoção manual da placenta foi de 15, 30 e 45minutos, de acordo com julgamento clínico ou não foi relatado.  
Tabela 32 – IVU de ocitocina versus IVU de solução salina  
|Estudos|Número de mu|lheres ou fetos|Ef|eito|
|---|---|---|---|---|
||IVU Ocitocina|IVU Solução<br>salina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Mortalidade Materna|||||
|1 meta-análise de 5<br>estudos|1/398<br>(0.3%)|0/384<br>(0%)|RR 2.93<br>(0.12a 71.59)|3 mais/ 1000<br>(de 8 menos a|
|(1 meta-análise de 4<br>estudos<sup>382</sup>; 1<br>estudo<sup>387</sup>)||||15 mais)a|
|Necessidade de trans|fusão sanguinea||||
|1 meta-análise de 5|64/475|56/463|RR 1.13|16 mais/1000|  
Tabela 32 – IVU de ocitocina versus IVU de solução salina  
|Estudos|Número de|mulheres ou fetos|E|feito|
|---|---|---|---|---|
||IVU Ocitocin|a IVU Solução<br>salina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|estudos<br>(1 meta-análise de 4<br>estudos<sup>382</sup>; 1<br>estudo<sup>387</sup>)|(13.5%)|(12.1%)|(0.81 a 1.58)|(de 23 menos a<br>70 mais)|
|Necessidade de remo|ção manual d|aplacenta|||
|1 meta-análise de<br>13 estudos<br>(1 meta-análise de<br>12 estudos<sup>382</sup>; 1|364/685<br>(53.1%)|392/652<br>(60.1%)|RR 0.88<br>(0.80 a 0.97)|72 menos/<br>1000<br>(de 18 menos a<br>120 menos)|
|estudo<sup>388</sup>)<br>Necessidade de remo|ção cirúrgica|de restosplacentário|s||
|1 meta-análise de 4|27/420|29/406|RR 0.88|9 menso/ 1000|
|estudos<sup>382</sup>|(6.4%)|(7.1%)|(0.56 a 1.4)|(de 31 menos a|
|Necessidade de uso d|<br>e ocitocina te|<br>rapêutica||<br>29 mais)|
|1 meta-análise de 5<br>estudos<br>(1 meta-análise de 4<br>|53/376<br>(14.1%)|66/362<br>(18.2)|RR 0.69<br>(0.43 a 1.13)|56 menos/<br>1000<br>(de 104 menos<br>|
|estudos<sup>382</sup>; 1||||a 24 mais)|
|<br>estudo<sup>388</sup>)<br>Morbidade materna g<br>respiratória aguda, ou<br>remoção manual dap|rave (histerec<br>tros procedim<br>lacenta)|tomia, admissão em<br>entos adicionais pa|UTI, insuficiência<br>ra tratamento de|<br>renal ou<br>HPP além da|
|1 meta-análise de 4<br>|0/369|1/355|RR 0.33|2 menos/1000|
|estudos<sup>382</sup>|(0%)|(0.28%)|(0.01 a 7.95)|(de 3 menos a|
|||||20 mais)|
|Perda sanguínea ≥ 50|0 ml(HPP leve|)|||
|1 meta-análise de 5<br>estudos|137/454<br>(30.0%)|135/436<br>(31%)|RR 0.95<br>(0.69 a 1.32)|15<br>menos/1000|
|(1 meta-análise de 4<br>estudos<sup>382</sup>; 1||||(de 96 menos a<br>99 mais)|
|estudo<sup>388</sup>)|||||
|Perda sanguínea ≥ 1.0|00 ml(HPP in|tensa)|||
|1 meta-análise de 5|38/421|34/406|RR 1.09|8 menos/1000|
|estudos|(9.0%)|(8.4%)|(0.7 a 1.69)|(de 25 menos a|
|(1 meta-análise de 4<br>estudos<sup>382</sup>; 1||||58 mais)|
|estudo<sup>388</sup>)|||||
|Hemoglobina 24-48 h|oras após op|arto(g%)|||  
Tabela 32 – IVU de ocitocina versus IVU de solução salina  
|Estudos|Número de mu|lheres ou fetos|E|feito|
|---|---|---|---|---|
||IVU Ocitocina|IVU Solução<br>salina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 estudo<sup>382</sup>|Média 9.7<br>(DP 1.9)<br>n=85|Média 9.8<br>(DP 2.4)<br>n=82|NC|DM 0.1 menor<br>(0.76 menor a<br>0.56 maior)|
|Queda da hemoglobin|a em mais doq|ue 10%|||
|1 meta-análise de 5<br>estudos<br>(1 meta-análise de 4<br>estudos<sup>382</sup>; 1 estudo<br>387)<br>Infecção|185/303<br>(61.1%)|180/296<br>(60.8%)|RR 1<br>(0.89 a 1.13)|0 menos/ 1000<br>(de 67 menos a<br>79 mais)|
|1 meta-análise de 3<br>estudos<sup>382</sup>|43/417<br>(10.3%)|31/403<br>(7.7%)|RR 1.34<br>(0.87 a 2.08)|26 mais/ 1000<br>(de 10 menos a|
|||||83 mais)|
|Efeito colateral: cefal|éia||||
|1 estudo<sup>382</sup>|0/32|0/28|NC|NC|
||(0%)|(0%)|||
|Efeito colateral: náuse|a||||
|1 estudo<sup>382</sup>|0/32|0/28|NC|NC|
||(0%)|(0%)|||
|Efeito colateral: eleva|ção dapressão a|rterial|||
|1 meta-análise de 5<br>estudos|0/61<br>(0%)|0/57<br>(0%)|NC|NC|
|(1 meta-análise de 4<br>estudos<sup>382</sup>; 1 estudo<br>387)<br>Duração do terceiro e|stágio(minutos)||||
|1 estudo<sup>382</sup>|Média 111.4<br>(DP 43.2)<br>n=15|Média 95.2<br>(DP 44.6)<br>n=15|NC|DM 16.2 maior<br>(15.22 menor a<br>47.62 maior)|  
CI Intervalo de Confiança, DM Diferença média, NC não calculável, RR Risco relativo, DP Desvio padrão, IVU Injeção na veia umbilical, HPP Hemorragia posparto, UTI Unidade de terapia intensiva  
Tabela 33 – IVU de ocitocina versus IVU de prostaglandina (misoprostol ou PGF2a)  
|Estudos|Número de m|ulheres ou fetos|Efe|ito|
|---|---|---|---|---|
||IVU Ocitocina|IVU de<br>prostaglandina<br>(Misoprostol<br>ou<br>PGF2a)|Relativo (IC 95%)|Absoluto (IC 95%)|  
Tabela 33 – IVU de ocitocina versus IVU de prostaglandina (misoprostol ou PGF2a)  
|Estudos|Número de m|ulheres ou fetos|Efe|ito|
|---|---|---|---|---|
|Necessidade de r|IVU Ocitocina<br>emoção manual|IVU de<br>prostaglandina<br>(Misoprostol<br>ou<br>PGF2a)<br>daplacenta|Relativo (IC 95%)|Absoluto (IC 95%)|
|1 meta-análise<br>de 3|28/57<br>(49.1%)|14/56<br>(25%)|RR 1.82<br>(1.14 a 2.92)|205 mais/1000<br>(de 35 mais a 480|
|estudos<sup>381,382</sup>||||mais)|
|Necessidade de u|so de ocitocina t|erapêutica|||
|1 estudo<sup>382</sup>|5/11<br>(45.5%)|6/10<br>(60%)|RR 0.76<br>(0.33 a 1.72)|144 menos/1000<br>(de 402 menos a<br>432 mais)|
|Hemorragiapósp|arto||||
|1 estudo<br>(Harara et al.,<br>2011)|0/26<br>(0%)|0/25<br>(0%)|NC|NC|
|Efeito colateral:|qualquer||||
|1 estudo<sup>381</sup>|0/26<br>(0%)|0/25<br>(0%)|NC|NC|
|Tempo entre inje|ção e dequitação|daplacenta(min|utos)||
|1 meta-análise<br>de 2<br>estudos<sup>381,382</sup>|n=30|n=30|NC|DM 6.07 maior<br>(4.47 a 7.66<br>maior)|  
CI Intervalo de Confiança, DM Diferença média, NC não calculável, RR Risco relativo, DP Desvio padrão, IVU Injeção na veia umbilical  
Tabela 34 – IVU de ocitocina versus IVU expansor plasmático  
|Estudos|Número de mu|lheres ou fetos|Efeit|o|
|---|---|---|---|---|
|Necessidade de rem<br>|IVU Ocitocina<br>oção manual dapla<br>|IVU de<br>expansor<br>plasmático<br>centa<br>|Relativo (IC 95%)<br>|Absoluto (IC<br>95%)<br>|
|1 estudo<sup>382</sup>|49/68<br>(72.1%)|22/41<br>(53.7%)|RR 1.34<br>(0.97 a 1.85)|182<br>mais/1000<br>(de 16 menos<br>a  456 mais)|
|Perda sanguínea ≥ 1<br>|000 ml(HPPgrave)<br>||||
|1 estudo<sup>382</sup>|8/68<br>(11.8%)|5/41<br>(12.2%)|RR 0.96<br>(0.34 a 2.75)|5<br>menos/1000<br>(de 80 menos|  
Tabela 34 – IVU de ocitocina versus IVU expansor plasmático  
|Estudos|Número de mu|lheres ou fetos|Efeit|o|
|---|---|---|---|---|
||IVU Ocitocina|IVU de|Relativo (IC 95%)|Absoluto (IC|
|||expansor||95%)|
|||plasmático|||
|||||a  213 mais)|  
CI Intervalo de Confiança,  RR Risco relativo, IVU Injeção na veia umbilical  
Tabela 35 – IVU de ocitocina versus IVU ergometrina  
|Estudos|Número de mu|lheres ou fetos|Ef|eito|
|---|---|---|---|---|
||IVU Ocitocina|IVU de<br>ergometrina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Necessidade de re|moção manual dapl|acenta|||
|1 estudo<sup>381</sup><br>Hemorragiapós-pa|7/26<br>(26.9%)<br>rto|10/27<br>(37%)|RR 0.73<br>(0.33 a 1.62)|100<br>menos/1000<br>(de 248 menos<br>a  230 mais)|
|1 estudo<sup>381</sup><br>Efeito colateral:qu|0/26<br>(0%)<br>alquer|0/27<br>(0%)|NC|NC|
|1 estudo<sup>381</sup><br>Tempo entre injeçã|0/26<br>(0%)<br>o e dequitação dap|0/27<br>(0%)<br>lacenta(minutos|NC<br>)|NC|
|1 estudo<sup>381</sup>|Média 13.1<br>(DP 3.76)<br>n=19|Média 22.5<br>(DP 4.37)<br>n=17|NC|DM 9.4 menor<br>(12.08 menor<br>a  6.72 menor)|  
CI Intervalo de Confiança, DM Diferença média, NC não calculável, RR Risco relativo, DP Desvio padrão, IVU Injeção na veia umbilical  
Tabela 36 – IVU Solução salina versus  conduta expectante  
|Estudos|Número de m|ulheres ou fetos|Efe|ito|
|---|---|---|---|---|
|Mortalidade Mate|IVU Solução<br>salina<br>rna|Conduta<br>expectante|Relativo (IC 95%)|Absoluto (IC<br>95%)|
|1 meta-análise<br>de 2 estudos<sup>382</sup>|0/42<br>(0%)|0/45<br>(0%)|NC|NC|
|Necessidade de tr|ansfusão sangui|nea|||
|1 meta-análise|15/118|19/117|RR 0.76|39 menos/1000|
|de 2 estudos<sup>382</sup>|(12.7%)|(16.2%)|(0.41 a 1.39)|(de 96 menos a<br>63 mais)|
|Necessidade de re|moção manual d|aplacenta|||  
Tabela 36 – IVU Solução salina versus  conduta expectante  
|Estudos|Número de m|ulheres ou fetos|Efe|ito|
|---|---|---|---|---|
||IVU Solução<br>salina|Conduta<br>expectante|Relativo (IC 95%)|Absoluto (IC<br>95%)|
|1 meta-análise<br>de 4 estudos<sup>382</sup>|114/206<br>(55.3%)|113/197<br>(57.4%)|RR 0.97<br>(0.84 a 1.12)|17 menos/1000<br>(de 92 menos a|
|Necessidade de re<br>|moção cirúrgica<br>|de restosplacent<br>|ários|69 mais)<br>|
|1  estudo<sup>382</sup>|25/90<br>(27.8%)|31/88<br>(35.2%)|RR 0.79<br>(0.51 a 1.22)|74 menos/ 1000<br>(de 173 menos a|
|Morbidade mater<br>respiratória aguda<br>remoção manual<br>|na grave (histere<br>, outros procedi<br>daplacenta)<br>|ctomia, admissão<br>mentos adicionais<br>|em UTI, insuficiênci<br>para tratamento de<br>|78 mais)<br>a renal ou<br>HPP além da<br>|
|1 meta-análise|0/42|0/45|NC|NC|
|de 2 estudos<sup>382</sup>|(0%)|(0%)|||
|<br>Perda sanguínea ≥|500 ml(HPP le<br>|ve)<br>|||
|1 meta-análise<br>de 2 estudos<sup>382</sup>|15/88<br>(17%)|15/89<br>(16.9%)|RR 1<br>(0.53 a 1.86)|0 menos/1000<br>(de 79 m,enos a|
|Perda sanguínea ≥|<br>1000 ml(HPPg|<br>rave)||<br>145 mais)|
|1  estudo<sup>382</sup>|3/62|4/60|RR 0.73|18 menos/1000|
||(4.8%)|(6.7%)|(0.17 a 3.11)|(de 55 menos a|
|||||141 mais)|
|Hemoglobina 24-4<br>|8 horas após o|parto(g%)|||
|1 estudo<sup>382</sup>|Média 9.8<br>(DP 2.4)|Média<br>9.7 (DP 2.1)|NC|DM 0.1 maior<br>(0.59 menos a|
||n=82|n=81||0.79 maior)|
|Infecção|||||
|1 estudo<sup>382</sup>|2/90<br>(2.2%)|4/86<br>(4.7%)|RR 0.48<br>(0.09 a 2.54)|24 menos/1000<br>(de 42 menos a|
|||||72 mais)|
|IC Intervalo de Confiança|, DM Diferença|média, NC não cal|culável, RR Risco rela|tivo, DP Desvio padrão,|  
Tabela 37 – IVU Prostaglandina (Misoprostrol ou PGF2a) versus IVU Solução salina  
|Estudos|Número de mu|lheres ou fetos|Ef|eito|
|---|---|---|---|---|
||IVU<br>Prostaglandin<br>a<br>(Misoprostol<br>ou PGF2a)|IVU Solução<br>salina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|  
Necessidade de remoção manual da placenta  
|1 meta-análise<br>de 2 estudos<sup>382</sup><br>Necessidade do u<br>|9/31<br>(29%)<br>so de ocitocin<br>|14/20<br>(70%)<br>a adicional<br>|RR 0.24<br>(0.01 a 6.41)|532 menos/<br>1000<br>(de 693 menos a<br>1000 mais)<br>|
|---|---|---|---|---|
|1 estudo<sup>382</sup>|6/10<br>(60%)|4/7<br>(57.1%)|RR 1.05<br>(0.46 a 2.38)|29 mais/1000<br>(de 309 menos a<br>789 mais)|  
CI Intervalo de Confiança,  RR Risco relativo, IVU Injeção na veia umbilical

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Tabela 38 –  Prostaglandina IV(Sulprostone) versus  Solução salina IV -->
|Estudos|Número d|e mulheres|E|feito|
|---|---|---|---|---|
|Necessidade de r|Prostaglandina<br>(Sulprostone)<br>IV<br>emoção manual da|Solução salina<br>IV<br> placenta|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 estudo<sup>383</sup><br>Histerectomia|11/24<br>(45.8%)|22/26<br>(84.6%)|RR 0.54<br>(0.34 a 0.86)|389 menos/1000<br>(de 118 menos a<br>558 menos)|
|1 estudo<sup>383</sup><br>Necessidade de t|0/24<br>(0%)<br>ransfusão sanguine|0/26<br>(0%)<br>a|NC|NC|
|1 estudo<sup>383</sup><br>Efeito colateral:|6/24<br>(25%)<br>Náusea|8/26<br>(30.8%)|RR 0.81<br>(0.33 a 2)|58 menos/ 1000<br>(de 206 menos a<br>308 mais)|
|1 estudo<sup>383</sup>|0/24<br>(0%)|1/26<br>(3.8%)|RR 0.36<br>(0.02 a 8.43)|25 menos/1000<br>(de 38 menos a<br>286 mais)|  
CI Intervalo de Confiança,  RR Risco relativo  
Tabela 39 – IVU Prostaglandina (Misoprostol) versus IVU Ergometrina  
|Estudos|Número de m|ulheres ou fetos|E|feito|
|---|---|---|---|---|
||IVU<br>Prostaglandin<br>a<br>(Misoprostol)|IVU Ergometrina|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|Necessidade de|remoção manual d|aplacenta|||
|1 estudo<sup>381</sup>|5/25<br>(20%)|10/27<br>(37%)|RR 0.54<br>(0.21 a 1.36)|170 menos/1000<br>(de 293 menos a<br>133 mais)|
|Hemorragiapós|-parto||||  
|1 estudo<sup>381</sup>|0/25<br>(0%)|0/27<br>(0%)|NC|NC|
|---|---|---|---|---|
|Efeito colateral:|qualquer||||
|1 estudo<sup>381</sup>|0/25<br>(0%)|0/27<br>(0%)|NC|NC|
|Tempo entre in|jeção e dequitaçã|o daplacenta(min|utos)||
|1 estudo<sup>381</sup>|Média 7.0<br>(DP 2.2)<br>n=20|Média 22.5<br>(DP 4.37)<br>n=17|NC|DM 15.5 menor<br>(17.79 a 13.21<br>menor)|  
IC Intervalo de confiança, RR risco relativo, IVU Injeção na veia umbilical, NC não calculável, DP Desvio padrão, DM diferença média  
Tabela 40 – Nitroglicerina (IV ou sublingual) versus placebo  
|Estudos|Número de m|ulheres ou fetos|Ef|eito|
|---|---|---|---|---|
|Necessidade de r|Nitroglicerina<br>(IV ou<br>sublingual)<br>emoção manual d|Placebo<br>aplacenta|Relativo (IC<br>95%)|Absoluto (IC<br>95%)|
|1 estudo<sup>380</sup>|0/12<br>(0%)|11/12<br>(91.7%)|RR 0.04<br>(0 a 0.66)|880 menos/1000<br>(de 312 menos a<br>917 menos)|
|1 estudo<sup>385</sup>|17/20<br>(85%)|16/20<br>(80%)|RR 1.06<br>(0.8 a 1.41)|48 mais/1000<br>(de 160 menos a<br>328 mais)|
|Necessidade de r|epetição de remoç|ão manual daplac|enta ou de curetag|em|
|1 estudo<sup>385</sup><br>Efeito colateral:|3/20<br>(15%)<br>hipotensãograve(|0/20<br>(0%)<br>pressão sistólica <|RR 7<br>(0.38 a 127.32)<br>80mmHg)|150 mais/1000<br>(de 38 menos a<br>360 mais)a|
|1 estudo<sup>385</sup>|2/20<br>(10%)|2/20<br>(10%)|RR 1<br>(0.16 a 6.42)|0 menos/1000<br>(de 84 menos a<br>542 mais)|
|Efeito colateral:|cefaléia||||
|1 estudo<sup>385</sup>|1/20<br>(5%)|0/20<br>(0%)|RR 3<br>(0.13 a 69.52)|50 mais/ 1000<br>(de 116 menos a<br>236 mais)a|  
IC Intervalo de confiança, RR risco relativo, IV Injeção intravenosa; a calculado com Excel  
Tabela 41 – Misoprostol oral versus placebo  
|Estudos|Número de mul|heres ou fetos|Efeit|o|
|---|---|---|---|---|
||Misoprostol|Placebo|Relativo (IC 95%)|Absoluto (IC|
||oral|||95%)|  
Tabela 41 – Misoprostol oral versus placebo  
|Estudos|Número de m|ulheres ou fetos|Efei|to|
|---|---|---|---|---|
||Misoprostol|Placebo|Relativo (IC 95%)|Absoluto (IC|
||l|||95%|
||ora|||)|
|Necessidade de re|moção manual d|aplacenta|||
|2 estudos<sup>386,384</sup>|50/113<br>(44.2%)|38/84<br>(45.2%)|1.05<br>(0.76 a 1.44)|23 mais/1000<br>(109 menos a|
|Necessidade de tr|ansfusão sanguin|ea||199 mais)|
|2 estudos<sup>386,384</sup>|16/113<br>(14.2%)|16/74<br>(21.6%)|0.83<br>(0.27 a 1.84)|82 menos/1000<br>(de 199 menos|
|Hemorragiapós-p<br>|arto > 1000 ml|||a  30 mais)|
|2 estudos<sup>386,384</sup>|37/113<br>(32.7%)|35/88<br>(39.8%)|0.87<br>(0.6 a 1.26)|52 menos/1000<br>(de 159 menos|
|||||<br>a  103 mais)|
|Efeito colateral: n|áusea||||
|1 estudo<sup>386</sup>|6/42<br>(14%)|1/32<br>(3%)|4.8<br>(0.58 a 36.1)|119 mais/1000<br>(13 menos a|
|||||<br>1000 mais)|
|Efeito colateral: v|ômito||||
|1 estudo<sup>386</sup>|3/42<br>(7.1%)|0/32<br>(0%)|5.4<br>(0.29 a 100.4)|71 mais/1000<br>(91 menos a|
|||||233 mais)a|
|Efeito colateral: d|or abdominal||||
|1 estudo<sup>386</sup>|8/42<br>(19%)|8/32<br>(25%)|0.76<br>(0.3 a 1.8)|60 menos/ 1000<br>(175 menos a|
|||||200 mais)|
|Efeito colateral: c<br>|efaléia||||
|1 estudo<sup>386</sup>|1/42|1/32|0.76|8 menos/1000|
||(2.3%)|(3.1%)|(0.05 a 11.8)|(30 menos a|
|||||338 mais)|
|Efeito colateral: t|ontura||||
|1 estudo<sup>386</sup>|5/42<br>(12%)|3/32<br>(9.3%)|1.26<br>(0.33 a 4.93)|37 mais/1000<br>(96 menos a|
|||||<br>561 mais)|
|Efeito colateral: d|ispepsia||||
|1 estudo<sup>386</sup>|4/42<br>(9.5%)|0/32<br>(0%)|6.91<br>(0.39 a 123.8)|95 mais/1000<br>(66 menos a<br>257 mais)a|  
Efeito colateral: tremores  
Tabela 41 – Misoprostol oral versus placebo  
|Estudos|Número de m|ulheres ou fetos|Efei|to|
|---|---|---|---|---|
||Misoprostol<br>oral|Placebo|Relativo (IC 95%)|Absoluto (IC<br>95%)|
|1 studo: (van|15/42|1/28|10|321 mais/1000|
|Stralen et al.,|(35%)|(3.5%)|(1.4 a 71.5)|(14 mais a 1000|
|2013)||||mais)|  
IC Intervalo de confiança, RR risco relativo, IV Injeção intravenosa; a calculado com Excel

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.7.2. Resumo da evidência e conclusões -->
Não houve evidência de diferenças significativas dos resultados para as mulheres que receberam a ocitocina IVU e mulheres que receberam a conduta expectante.  
Uma revisão sistemática ( n = 1377 ) mostrou que o risco de remoção manual da placenta foi mais baixa nas mulheres que receberam ocitocina IVU em comparação com as mulheres que receberam solução salina IVU. Não houve incidência de efeitos colaterais ( náusea [ n = 60 ], cefaléia [n = 60] , hipertensão [n = 118]) nos estudos desta revisão, mas o tamanho da amostra de um dos estudos era muito pequena. Há evidências de que o risco para remoção manual da placenta foi maior em mulheres alocadas no grupo com ocitocina IVU quando comparadas com as mulheres alocadas no grupo da prostaglandina IVU , embora o tamanho da amostra do estudo tenha sido pequena (n = 113). Não houve nenhuma diferença entre os 2 grupos para uso de uterotônicos adicionais (n = 22 ). Um estudo, de amostra pequena (n=51), não relatou incidência de HPP ou de efeitos colaterais. A diferença do intervalo de tempo entre a injeção e a expulsão da placenta (n = 60) não foi considerado clinicamente significativo. Comparando nitroglicerina e placebo, um estudo (n = 24) demonstrou que as mulheres que receberam nitroglicerina eram menos propensos à necessidade de remoção manual da placenta, embora outro estudo (n = 40) não encontrou diferença. Não houve evidência de aumento de efeitos colaterais da nitroglicerina ou da necessidade de repetir a remoção manual da placenta. Por causa do tamanho reduzido das amostras nos estudos, os resultados não foram conclusivos.  
Não houve diferença significativa em relação à incidência de remoção manual da placenta (n = 197), transfusão de sangue (n = 187) e hemorragia pós-parto mais de 1000 ml (n = 201) para mulheres que receberam misoprostol por via oral em comparação com as mulheres que receberam placebo. A incidência de tremores (n = 70) foi significativamente maior para as mulheres que receberam misoprostol comparado com aquelas que receberam placebo.  
Em relação à mortalidade materna ou morbidade materna grave somente 1 estudo com amostra pequena mostrou evidências. Outras comparações não mostraram diferença ou este resultado não foi analisado.  
As evidências encontradas nas comparações entre diferentes substâncias na retenção placentária não identificaram uma susbtância de destaque. A comparação entre ocitocina IVU versus conduta expectante mostrou que a injeção de ocitocina não se associa de maneira significativa à diminuição da remoção manual ou cirúrgica da placenta e à transfusão sanguínea e, portanto, não traz benefícios adicionais para as mulheres.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.7.3 Outras considerações -->
Em relação aos benefícios clínicos e danos, as evidências não analisaram resultados de longo prazo como morbidade grave e mortalidade materna. Os desfechos considerados mais importantes pelos  
desevolvedores das diretrizes do NICE foram os de curto prazo como hemorragia e a necessidade de remoção manual da placenta. Estes podem interferir de forma negativa na vivência da  parturição e impedir a mulher de ter contato imediato com o recém-nascido logo após o parto.  
Ficou demonstrado uma tendência maior para hemorragia pósparto na injeção de ocitocina na veia umbilical, embora sem diferenças significativas, comparado com injeção de solução salina ou conduta expectante. Por outro lado, a ocitocina IVU foi associada a um número significativamente menor de remoções manuais quando comparado com IVU salina com uma tendência semelhante quando comparado com a conduta expectante (embora esta constatação não tenha alcançado significância estatística). Estimou-se que 12 mulheres teriam de ser tratadas com ocitocina IUV em vez da conduta expectante para evitar uma única remoção manual e,  para cada 53 mulheres tratadas com ocitocina IVU, haveria mais uma hemorragia adicional superior a 1.000 ml. Em suma, concluiu-se que as evidências não justificam recomendar ocitocina IVU para a conduta na retenção placentária.  
Houve redução significativa da necessidade de remoção manual da placenta seguida de prostaglandina IVU quando comparado com ocitocina IVU e seguida de sulprostona IV quando comparado com solução salina IV. No entanto, esta evidência é de apenas alguns ensaios, com amostras pequenas e o efeito não foi consistente, uma vez que a comparação entre  prostaglandina IVU e solução salina IVU não demonstraram benefícios significativos. Infelizmente não foi encontrado um ensaio avaliando o uso de prostaglandina em comparação com a conduta expectante.  
Ainda deve se considerar, que o diagnóstico de retenção placentária pode estar equivocado, quando não há dequitação da placenta, mas esta se encontrar ainda no canal vaginal. Nesse caso, a mulher seria submetida a uma intervenção desnecessariamente. Quando o parto ocorre em modalidades extrahospitalares, o diagnóstico errôneo leva a uma transferência desnecessária acarretando desconforto para a mulher e sua família e custos adicionais. Um exame vaginal municioso deve ser realizado antes do diagnóstico definitivo.  
Em relação aos benefícios para a saúde e uso de recursos no Brasil, deve-se considerar que o uso da prostaglandina (misoprostol) no país é atrelada a uma série de normas administrativas que dificultam a sua difusão e as outras prostaglandinas como sulprostone e PGF2a não são comercializadas no país. Portanto, mesmo que tenham demonstrado benefícios marginais, os ensaios com prostaglandina não teriam importância prática na clínica, principalmente nos serviços com número reduzido de partos, localizados no interior. Este fato e a falta de uma evidência forte em favor da prostaglandina justificam que não se recomende o seu uso para conduta na retenção placentária.  
15.7.4 Recomendações sobre retenção placentária  
164. Explicar para a mulher o que está acontecendo e quais serão os procedimentos necessários  
165. Providenciar um acesso venoso calibroso.  
166. Não usar Ocitocina IV adicional de rotina para desprendimento da placenta.  
167. Usar Ocitocina IV adicional de rotina para desprendimento da placenta, se houver hemorragia.  
168. Realizar exame vaginal minucioso. Oferecer analgesia para este procedimento e providenciar, se a mulher demandar.  
169. Providenciar transferência antes da exploração uterina, se o parto ocorreu em uma modalidade extra-hospitalar.  
170. Não realizar remoção manual ou cirúrgica sem analgesia adequada.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.1 Introdução -->
A prestação de cuidados maternos imediatamente após o parto, ou seja nas primeiras duas horas, é um aspecto fundamental. A hemorragia, por exemplo, é uma das complicações mais comuns nesse período, já abordada no capítulo anterior. Além do mais, muitas mulheres sofrem algum tipo de trauma perineal no parto e, entre elas, algumas continuam a ter dor perineal de longo prazo, como dispareunia superficial. A morbidade relacionada à sutura perineal pode ter impacto relevante na saúde da mulher, causando doenças e incômodos que comprometem a capacidade da mesma de cuidar do seu bebê e da sua família. Nesse cenário, a reparação apropriada das lesões perineais pode promover hemostasia e cicatrização, e pode prevenir a infecção, o desconforto e dor após o nascimento. O tipo de trauma, manipulação do local e aproximação dos planos teciduais na sutura podem ser aspectos importantes para redução da dor e boa cicatrização. Ademais, o material utilizado para a sutura das lacerações perineais após o parto pode ter influência na intensidade da dor experimentada pelas mulheres, tanto a curto quanto a longo prazo.  
As algias no período puerperal podem surgir momentos após o nascimento e persistir por meses. Interferem no sono, na movimentação, na micção, na evacuação e no apetite da mulher, desservindo a vivência positiva e prazerosa da maternidade. Este capítulo abordará os cuidados maternos imediatmente após o parto, à luz das evidências científicas atuais.  
16.2 Questões de revisão  
- Qual a efetividade e freqüência da monitoração rotineira dos dados vitais, da retração uterina, dos lóquios, da função vesical e do bem-estar físico e emocional da mulher imediatamente após o parto?  
- Como identificar, avaliar e classificar adequadamente o trauma perineal/genital?  
- Quais são as técnicas mais apropriadas para reparo do trauma perineal/genital de graus I e II ?  
- Quais são as técnicas mais apropriadas para reparo da episiotomia?  
- Quais são as técnicas mais apropriadas para reparo do trauma perineal/genital de graus III e IV?  
- Quais materiais de sutura devem ser utilizados para reparo do trauma perineal/genital?  
- A experiência e treinamento do profissional que presta cuidados no trauma perineal influencia nos resultados?  
- Algum método de analgesia deve ser utilizado para dor perineal após o reparo do trauma? Qual analgésico é mais eficaz?  
16.3 Observação e monitoração da mulher imediatamente após o parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.3.1 Evidências Científicas -->
Os desenvolvedores das diretriz do NICE de 2014 não encontraram nenhuma evidência relacionada à observação e monitoração da mulher logo após o parto, principalmente em se tratando da avaliação dos dados vitais. Entretanto, fizeram recomendações baseadas em outras diretrizes da própria insitituição (Routine postnatal care of women and their babies – NICE clinical guideline 37)<sup>389</sup> . Ver recomendações. 16.3.2 Recomendações em relação à observação e monitoração da mulher imediatamente após o parto 171. Realizar as seguintes observações da mulher logo após o parto:  
- Temperatura, pulso e pressão arterial.  
- Lóquios e contrações uterinas.  
- Examinar a placenta e membranas: avaliar suas condições, estrutura, integridade e vasos umbilicais.  
- Avaliação precoce das condições emocionais da mulher em resposta ao trabalho de parto e parto.  
- Micção bem-sucedida.  
- Transferir a mulher ou solicitar assistência de médico obstetra, se este não for o profissional responsável, se qualquer das seguintes situações forem atingidas, a não ser que os riscos da transferência superem os benefícios:  
- Pulso >120 bpm em 2 ocasiões com 30 minutos de intervalo  
- PA sistólica ≥ 160 mmHg OU PA diastólica ≥ 110 mmHg em uma única medida  
- PA sistólica ≥ 140 mmHg OU diastólica ≥ 90 mmHg em 2 medidas consecutivas com 30 minutos de intervalo  
- Proteinúria de fita 2++ ou mais E uma única medida de PA sistólica ≥ 140 mmHg ou diastólica ≥ 90 mmHg  
- Temperatura de 38°C ou mais em uma única medida OU 37,5°C ou mais em 2 ocasiões consecutivas com 1 hora de intervalo  
- Bexiga palpável e ausência de micção 6 horas após o parto  
- Emergência obstétrica – hemorragia pós-parto, convulsão ou colapso materno  
- Placenta retida ou incompleta  
- Lacerações perineais de terceiro e quarto graus ou outro trauma perineal complicado.  
16.4 Cuidados com o períneo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.4.1.1 Evidências Científicas -->
Os desenvolvedores das diretrizes do NICE de 2014 chegaram a um consenso em relação à definição e classificação do trauma perineal de acordo com as diretrizes do Royal College of Obstetricians and Gyanecologists<sup>390</sup> . O GED destas Diretrizes adaptadas também, por consenso, decidiu adotar a mesma classificação. Ver recomendação.  
16.4.1.2 Recomendação em relação à definição do trauma perineal  
172. O trauma perineal ou genital deve ser definido como aquele provocado porepisiotomia ou lacerações, da seguinte maneira:  
- Primeiro grau – lesão apenas da pele e mucosas  
- Segundo grau – lesão dos músculos perineais sem atingir o esfínciter anal  
- Terceiro grau – lesão do períneo envolvendo o complexo do esfíncter anal:  
- 3a – laceração de menos de 50% da espessura do esfíncter anal  
- 3b – laceração de mais de 50% da espessura do esfíncter anal  
- 3c – laceração do esfíncter anal interno.  
- Quarto grau – lesão do períneo envolvendo o complexo do esfíncter anal  (esfínceter anal interno e externo) e o epitélio anal.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.4.2.1 Evidências Científicas -->
As diretrizes do NICE de 2014 incluíram três estudos na sua revisão os quais são sumarizados a seguir: Um estudo realizado no Reino Unido avaliou a efetividade de um curso de treinamento de reparo perineal<sup>391</sup> [NE = 2+] para melhorar a habilidade dos profissionais na correta identificação e classificação do trauma perineal. O curso incluiu várias atividades, desde apresentações e vídeos até a prática de toque retal e sutura utilizando modelos. Os participantes responderam um questionário e as avaliações  
foram baseadas nas respostas de 147 pares de questionários pré e pós curso com uma taxa de resposta de 71%. A maioria dos respondentes foram enfermeiras obstétricas/obstetrizes (95%), 68% delas com qualificação maior que cinco anos. Residentes de obstetrícia e estudantes de medicina também participaram. Após o curso, ficou demonstrado uma melhora na classificação correta das lacerações dependendo do grau de lesão do esfíncter: esfíncter anal externo (EAE) parcialmente lacerado: 77% versus 85%, P = 0,049; EAE completamente lacerado: 70% versus 85%, P = 0,001; esfíncter anal interno (EAI) exposto mas não lacerado: 63% versus 82%, P < 0,001; EAI lacerado: 45% versus 67%, P < 0,001; esfíncter e mucosa anal lacerados anal: 80% versus 89%, P = 0,031. Também constatou-se um aumento na realização de exame retal antes do reparo perineal: 28% versus 89%, P < 0,001, teste de McNemar); uma mudança em direção à realização de sutura contínua dos músculos perienais e pele: músculos: 32% versus 84%, P < 0,001; pele 39% versus 81%, P < 0,001.  
Com o objetivo de avaliar a prevalência de lesões esfincterianas clinicamente reconhecíveis e ocultas, um estudo intervencional prospectivo realizado no Reino Unido envolveu um re-exame, por pesquisador experiente, de nulíparas que apresentaram trauma perienal.<sup>392</sup> [NE = 2+]. As lesões obstétricas do esfíncter anal (LOEA) identificadas foram confirmadas por um consultor especialista. Todas as mulheres (n = 241) também foram submetidas a um ultrassom endoanal imdiatamente após o parto e antes da sutura e, a maioria delas (86%), realizou um novo ultrassom 7 dias após o parto. 173 partos foram assistidos por Enfermeiras obstétricas/obstetrizes, 75% delas com no mínimo 5 anos de experiência. 68 partos foram assistidos por médicos obstetras, sendo 63 partos instrumentais. A prevalência de LOEA aumentou significativamente de 11% para 24,5% após as mulheres serem examinadas pelo consultor especialista. Dos 173 partos assistidos por Enfermeiras obstétricas/obstetrizes, oito apresentaram LOEA sustentada. Apenas quatro destas lesões foram confirmadas pelo especialista. Em 26 mulheres que tiveram LOEA sustentada, a Enfermeira obstétrica/obstetriz realizou diagnóstico de laceração de segundo grau em 25 e de primeiro grau em uma. Todos os 30 casos de LOEA foram confirmados pelo consultor especializado. Dos 68 partos assistidos por médicos obstetras, 32% tiveram LOEA diagnosticada e confirmada pelo pesquisador. Outros sete casos foram identificados pelo pesquisador, três deles não tinham sido reconhecidos pelo especialista de plantão mas foram confirmados pelo consultor especializado. As Enfermeiras obstétricas/obstetrizes também examinaram as mulheres que foram assistidas no parto pelos médicos obstetras. De 29 LOEA apenas uma foi identificada pelas Enfermeiras obstétricas/obstetrizes e nenhuma delas realizou um exame retal. O ultrassom endoanal realizado logo após o parto detectou todos as LOEA detectadas clinicamente além de três defeitos não identificados clinicamente. O ultrassom realizado 7 dias após não detecetou defeitos adicionais.  
Um estudo observacional prospectivo realizado no Reino Unido avaliou se o diagnóstico clínico de lacerações de terceiro grau poderia ser aprimorado por um aumento da vigilância da avaliação perineal<sup>393</sup> [NE = 3]. 121 nulíparas foram avaliadas inicialmente pelo médico obstetra ou pela Enfermeira obstétrica/obstetriz assistente e posteriormente por um avaliador independente (um pesquisador clínico; grupo avaliado). Esses achados foram comparados com as outras mulheres que tiveram parto no mesmo período de 6 meses que foram avaliadas apenas pelo clínico assistente (cuidado usual; n = 362). Ambos os grupos foram similares em várias caracterísiticas chave. Episiotomias que se extenderam ao esfíncter anal foram classificadas como lacerações de terceiro grau. Mais lacerações de terceiro grau foram identificadas no grupo avaliado (14,9%) do que no grupo usual (7,5%). O estudo não teve poder suficiente para detectar significância estatística. No grupo avaliado, 11 das 18 lacerações de terceiro grau foram identificadas pelo clínico que assistiu o parto. Não houve desacordo entre o clínico e o  
pesquisador assim que o diagnóstico foi feito. As lacerações de terceiro grau foram de 3,2% no parto espontâneo, 14,9% no parto instrumental com ventosa e 22% com fórceps. Quando comparadas com mulheres que tiveram parto 6 meses antes e depois do período de estudo, a incidência de lacerações de terceiro grau foi: antes = 2,5%, durante = 9,3% e após =  4,6%.  
16.4.2.2 Resumo da evidência e conclusões  
A evidência analisada demonstra que uma avaliação sistemática da vagina, períneo e reto é necessária para avaliar de forma adequada a extensão do trauma perineal. Demonstra também que o treinamento dos profissionais é inadequado para avaliar o trauma perineal e que aqueles que são apropriadamente treinadaos realizam um cuidado do períneo consistente e de alto padrão.  
16.4.2.3 Recomendações em relação à avaliação e identificação do trauma perineal  
173. Antes de avaliar o trauma genital:  
- Explicar à mulher o que será realizado e porque  
- Ofereça analgesia adequada  
- Assegurar boa iluminação  
- Posicionar a mulher de maneira confortável e com boa exposição das estruturas genitais  
174. Realizar o exame inicial de maneira gentil e sensível. Isto pode ser feito imediatamente após o parto.  
175. Se for identificado trauma perineal, uma avaliação sistemática do mesmo deve ser realizada.  
176. Na avaliação sistemática do trauma genital:  
- explicar novamente o que será realizado e porque  
- providenciar analgesia local ou regional efetiva  
- avaliar visualmente toda a extensão do trauma, incluindo as estruturas envolvidas, o ápice da lesão e o sangramento  
- na suspeita de qualquer lesão da musculatura perineal, realizar exame retal para verificar se ocorreu algum dano ao esfíncter anal externo e interno  
177. Assegurar que o momento para essa avaliação sistemática não interfira na relação mãe-filho exceto se houver sangramento que requeira medidas de urgência  
178. Ajudar a mulher a adotar uma posição que permita uma visualização adequada do grau do trauma e para o reparo. Manter essa posição apenas pelo tempo necessário para a avaliação sistemática e reparo do períneo. Se não for possível uma avaliação adequada do trauma, a mulher edeverá ser assistida por médico obstetra, se esse não for o profissional que assistiu o parto. Se o parto ocorreu fora do hospital, a mesma deverá ser transferida para uma maternidade baseada em hospital.  
179. Solicitar avaliação de um profissional mais experiente se houver incerteza quanto à natureza e extensão do trauma. Transferir a mulher (com a criança) para uma maternidade baseada em hospital, se o parto ocorreu fora da mesma e se o reparo necessitar de avaliação cirúrgica ou anestésica especializada .  
180. Documentar a avaliação sitemática e os seus resultados.  
181. Tanto as enfermeiras obstétricas ou obstetrizes assim como os médicos obstetras envolvidos na assistência ao parto devem estar adequadamente treinados na avaliação e reparo do trauma genital, certificando-se que essas habilidades sejam mantidas.  
- 16.4.3 Reparo do períneo  
16.4.3.1 Realização ou não do reparo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 15.3.3.1.1 Evidências Científicas -->
As diretrizes do NICE de 2014 avaliaram um ERC<sup>394</sup> que comparou mulheres nulíparas que tiveram lesões de grau I ou II e foram suturadas (n = 33) com mulheres nulíparas cujo trauma perineal não foi suturado (n = 41). Os resultados não demonstraram diferenças em relação aos escores de dor medidos pelo ‘Questionário de Dor de McGill’: dia 1: 11 [0 a 33] versus 10 [0 a 44]; 1 [IC 95% −2 a 4,999]; dia 10: 0 [ 0 a 18] versus 0 [0 a 33]; 0 [IC 95% 0 a 0,001]; 6 semanas 0 [0 a 28] 0 [0 a 7]; 0 [IC 95% 0 a 0]. Também não foram encontradas diferenças quando uma EVA foi utilizada. Ficou demonstrado também cicatrização significativamentede melhor das feridas, segundo a escala REEDA, no grupo suturado. A aproximação das bordas da ferida foi melhor no grupo suturado: dia 1: 1 [ 0 a 3] versus 2 [ 1 a 3]; −1 [IC 95% −1,0001 a 0], P < 0,001; dia 10: 1 [ 0 a 2] versus 2 [ 0 a 3]; −1 [IC 95% −1,0001 a −0,0003], P = 0,003; 6 semanas: 1 [ 0 a 1] versus 1 [ 0 a 3]; 0 [IC 95% − 0,9999 a 0,0001], P = 0,001. Os escores totais de cicatrização também evidenciou uma tendência de melhor cicatrização no grupo suturado nos dias 1 e 10: dia 1: [ 0 a 9] 5 [1 a 10]; −1 [IC 95% −2 a 0], NS; dia 10: 1 [0 a 6] versus 2 [0 a 8]; 0 [IC 95% −1 a 0], NS e também co seis semanas: 0 [0 a 3] versus 1 [0 a 3]; 0 [IC 95% −1,0001 a −0,0003], P = 0,003. 16.4.3.1.2 Resumo da evidência e conclusões  
A evidência aponta que a sutura do trauma perineal de primeiro e segundo grau resulta em melhor cicatrização com seis semanas após o parto. Não foram avaliados desfechos de longo prazo. 16.4.3.1.3 Recomendações sobre reparar ou não reparar o períneo  
182. Aconselhar a mulher que, no caso de trauma de primeiro grau, a ferida deve ser suturada, a fim de melhorar a cicatrização, a menos que as bordas da pele estejam bem apostas.  
183. Aconselhar a mulher que, no caso de um trauma de segundo grau, o músculo deve ser suturado, a fim de melhorar a cicatrização.  
- 15.4.3.2 Analgesia durante o reparo perineal  
16.4.3.2.1 Evidências Científicas  
Nehuma das diretrizes consultadas abordou técnicas de analgesia durante o reparo perineal. Nas diretrizes do NICE de 2014, o GED relatou não ter encontrado evidências sobre o assunto mas fez recomendações a respeito. O GED destas Diretrizes adaptadas também concordou com as recomendações do GED inglês.  
16.4.3.2.3 Recomendações em relação à analgesia durante o reparo perineal  
184. Durante o reparo perineal:  
- Assegurar analgesia efetiva com a infiltração de até 20 ml de lidocaína 1% ou equivalente ou  
- Realizar nova dose de anestéscio peridural se a mulher estiver com catéter, ou realizar uma anestesia espinhal  
185. Se a mulher relatar alívio inadequado da dor a qualquer momento, levar isso em consideração imediatamente e providenciar método mais eficaz de alívio.  
- 16.4.3.3 Métodos de reparo perineal  
16.4.3.3.1 Evidências Científicas  
As diretrizes do NICE de 2014 incluíram em sua revisão os estudos que são sumarizados a seguir: Uma revisão sistemática que incluiu quatro ERCs (n = 1.864)<sup>395</sup> [NE = 1+] comparou uma sutura subcuticular contínua com uma sutura em pontos interrompidos, demonstrando que o método de sutura subcuticular está associado com menos dor de curto prazo (até o 10<sup>o</sup> dia): 160/789 versus 218/799, OR 0,68 [IC 95% CI 0,53 a 0,86]. Não foram encontradas outras diferenças entre os grupos em relação a: analgesia até o dia 10: 56/527 versus 65/541, OR 0,86 [IC 95% 0,58 a 1,26]; dor aos 3 meses  
58/465 versus 51/451, OR 1,12 [IC 95% 0,75 a 1,67]; remoção de material de sutura até 3 meses: 121/465 versus 16/451, OR 0,61 [IC 95% 0,46 a 0,80]; reinício de atividade sexual livre de dor até 3 meses: 157/465 versus 144/451, OR 1,09 [IC 95% 0,82 a 1,43]; ressutura até 3 meses: 3/487 versus 3/531, OR 1,11 [IC 95% 0,22 a 5,53]; dispareunia até 3 meses: 172/775 versus 184/749, OR 0.88 [IC 95% 0,69 a 1,12]. Os efeitos de longo prazo não ficaram claros.  
Um ERC realizado no Reino Unido comparou uma sutura contínua com uma sutura interrompida para o reparo perineal utilizando fios rapidamente absorvíveis<sup>396</sup> [NE = 1+]. Uma técnica de sutura contínua envolvendo a parede vaginal, muscultura perineal e pele, utilizando uma só sutura contínua (n = 771) foi comparada com uma técnica de sutura interrompida utilizando sutura contínua na parede vaginal e suturas interrompidas na musculatura e pele (n = 771). Foram incluídas mulheres com lacerações de primeiro e segundo grau ou episiotomia, após parto vaginal espontâneo. A sutura contínua subcuticular esteve associada a menos dor perineal de curto prazo: com 2 dias: 530/770 versus 609/770, OR 0,59 [IC 95% 0,44 a 0,79]; com 10 dias: 204/770 versus 338/769, OR 0,47 [IC 95% 0,35 a 0,61]. Não foram encontradas diferenças em relação a dor de longo prazo: com 3 meses: 70/751 versus 96/741, OR 0,70 [IC 95% 0,46 a 1,07]; com 12 meses: 31/700 versus 47/689, OR 0,64 [IC 95% 0,35 a 1,16]; dispareunia com 3 meses: 98/581 versus 102/593, OR 0,98 [IC 95% 0,72 a 1,33]; dispareunia com 12 meses: 94/658 versus 91/667, OR 1,05 [IC 95% 0,77 a 1,43]. O relato de desconforto 2 dias após o parto também foi menor no grupo de sutura contínua: 273/770 versus 318/770, OR 0,78 [IC 95% 0,64 a 0,96] que se tornou mais acentuada com 10 dias (OR 0,58 [IC 95% 0,46 a 0,74]). Também mais mulheres no grupo de sutura interrompida relataram aperto na sutura com 2 e 10 dias, assim como maior necessidade de remoção da sutura entre 10 dias e 3 meses: 22/751 versus 63/741, OR 0,36 [IC 95% 0,23 a 0,55]. Houve mais falhas na ferida com a sutura contínua (com 10 dias: 23/770 versus 50/769, OR 0,46 [IC 95% 0,29 a 0,74]) assim como melhor satisfação da mulher aos 3 meses: 628/751 versus 560/741, OR 1,64 [IC 95% 1,28 a 2,11] e 12 meses: 603/700 versus 542/689, OR 1,68 [IC 95% 1,27 a 2,21]. As mulheres também relataram com mais frequencia, terem voltado ao normal aos 3 meses, no grupo de sutura contínua: 414/700 versus 332/689, OR 1,55 [IC 95% 1,26 a 1,92].  
Um ERC realizado no Reino Unido e publicado em 1998 comparou o reparo perineal em duas (n = 890) e em três fases (n = 890)<sup>397</sup> [NE = 1 +]. Além disso, comparou ambos em relação ao material de sutura utilizado. Não foram encontradas diferenças com 2 dias em relação a dor: qualquer dor em 24 horas: 545/885 (62%) versus 569/889 (64%); analgesia em 24 horas: 400/885 (45%) versus 392/889 (44%); pontos apertados: 162/885 (18%) versus 196/889 (22%). Houve mais deiscência de sutura no grupo de duas fases: 203/885 (23%) versus 40/889 (4%), P < 0,00001. Não foram encontradas diferenças aos 10 dias em relação a dor  e uso de analgesia (dor em 24 24 horas: 221/886 (25%) versus 244/885 (28%); analgesia em 24 horas: 73/886 (8%) versus 69/885 (8%). Mais mulheres no grupo de 3 fases relataram pontos apertados: 126/886 (14%) versus 163/885 (18%), RR 0,77 [IC 95% CI 0,62 a 0,96], P = 0,02. A incidência de falhas na sutura com 10 dias foi também maior no grupo de duas fases: 227/886 (26%) versus 145/885 (16%), P < 0,00001. A remoção da sutura foi menor no grupo de duas fases: 26/886 (3%) versus 67/885 (8%), P < 0,0001. A incidência de reparo de deiscência foi muito baixo em ambos os grupos (n = 5 versus n = 7). Não houve diferenças em relação à dor aos 3 meses: qualquer dor na última semana: 64/828 (8%) versus 87/836 (10%); reinício de atividade sexual: 704/828 (85%) versus 712/836 (85%); reinício de atividade sexual sem dor: 576/828 (70%) versus 551/836 (66%). Houve diferenças no relato de dispareunia: 128/890 (14.3%) versus 162/890 (18.2%), RR 0,80 [IC 95% 0,65 a 0,99], P = 0, 04. A remoção de sutura com 3 meses foi menor no grupo de duas fases: 59/828 (7%) versus 98/836 (11%),  
RR 0,61 [IC 95% 0.45 a 0.83]. A necessidade de ressutura foi muito pequena em ambos os grupos (n = 4 versus n = 9).  
Um ano após o estudo acima, um questionário foi enviado pelo correio a 793 mulheres<sup>398</sup> [NE = 1+]. Nesta amostra foram incluídas 31% de mulheres que haviam sido submetidas a um parto instrumental (na amostra original foram 17%). Os grupos não demonstraram diferenças em relação a dor persistente: 28/396 versus 26/396. As mulheres que haviam sido submetidas ao reparo em 3 fases relataram que “se sentiam diferentes” na região perineal comparada com aquelas submetidas ao reparo em 2 fases: 17/395 versus 157/396, RR 0,75 [IC 95% CI 0,61 a 0,91]. Análise de subgrupo demonstrou que essa diferença foi mais marcante comparando o parto espontâneo com o parto instrumental: instrumental = 45/123 versus 55/124, RR 0,82 [IC 95% CI 0,61 a 1,12]; espontâneo = 72/272 versus 102/272, RR 0,71 [IC 95% 0,55 a 0,91]; suturas interrompidas comparadas com técnica mista ou subcuticular: sutura interrompida = 57/209 versus 87/202, RR 0,63 [IC 95% 0,48 a 0,83]; técnica mista = 46/133 versus 55/136, RR 0,86 [IC 95% 0,63 a 1,17]; subcuticular = 14/53 versus 15/58, RR 1,02 [IC 95% 0,55 a 1,91]. Não houve diferenças entre os grupos em relação a dispareunia, falha para reiniciar as atividades sexuais livre de dor ou necessidade de ressutura.  
Outro estudo conduzido na Nigéria, no ano de 2003, também comparou o reparou o reparo perineal em duas e três fases (n=1.077)<sup>399</sup> [NE = 1+]. Verificou-se que o grupo de reparo perineal em duas fases associou-se a menos dor (57% versus 65%, RR= 0,87; IC95%=0,78-0,97) e suturas com pontos apertados (25% versus 38%, RR=0,67 IC95%= 0,54-0,82). O uso de analgesia, grau de inflamação e escoriação foi significativamente menor no grupo de duas fases (analgesia: 34% versus 49%, RR 0,71 [IC 95% 0,60 a 0,83]; inflamação/escoriação: 7% versus 14%, RR 0,50 [IC 95% 0,33 a 0,77]). Falha na ferida (bordas > 0,5 cm separadas) foi mais comum no grupo de duas fases: 26% versus 5%, RR 4,96 [IC 95% 3,17 a 7,76]. Aos 14 dias e 6 semanas após o parto, a incidência de dor perienal foi menor no grupo de duas fases A diferença em relação à falha de ferida foi muito menor aos 14 dias: 21% versus 17%, RR 1,25 [IC 95% 0,94 a 1,67]. Não houve diferenças na deiscência de ferida: 3% versus 2%, RR 1,27 [IC 95% 0,56 a 2,85]. A incidência de dispareunia aos 3 meses foi menor no grupo de duas fases: 10% versus 17%, RR 0,61 [IC 95% 0,43 a 0,87].  
As diretrizes do País Basco, na sua atualização de 2006 a 2008, incluíram 3 estudos que abordaram técnicas para reparo perineal. Uma RS da Cochrane<sup>400</sup> , uma revisão francesa<sup>401</sup> e um ERC<sup>402</sup>  
A primeira RS<sup>400</sup> [NE = 1++] avaliou os efeitos das suturas contínuas em relação aos de suturas absorvíveis contínuas para reparação de episiotomia e lesões perineais de segundo grau após o parto. A meta-análise demonstrou que as técnicas de sutura contínua para o fechamento perineal, em comparação com qualquer uma das técnicas de sutura descontínua (todas as camadas ou apenas pele perineal), continuam se associando com menos dor por até 10 dias após o parto (RR = 0,70; IC95% = 0,64-0,76).  
A segunda das revisões<sup>401</sup> incluiu artigos sobre comparação entre diferentes técnicas de sutura para reparação de episiotomia, todas já incluídas na revisão sistemática anterior. Por fim, o ERC<sup>402</sup> [NE = 1+] selecionado pretendia comparar a sutura contínua com a descontínua, ambas sem depilação perineal em 395 mulheres primíparas com parto vaginal a termo, randomizadas em dois grupos. Os resultados do ensaio mostraram que não existem diferenças significativas entre a técnica de sutura descontínua e a sutura contínua, e estas oferecem os mesmos resultados quanto à dor (RR = 0,90; IC95% = 0,68-1,18), necessidade de analgesia oral (RR = 1,04; IC95% = 0,59-1,87), satisfação (RR = 0,99; IC95% = 0,91 a 1,08), número de ressuturas (RR = 0,99; IC 95% = 0,25-3,92) e frequência de dispareunia na primeira relação  
sexual e em seis meses (RR = 1,13; IC95% = 0,96-1,33 e RR = 0,81; IC95% = 0,58-1,12, respectivamente). 16.4.3.3.2 Resumo da evidência e conclusões  
As evidências apontam que uma sutura contínua simples para o reparo da musculatura perineal está associada a menos dor no curto prazo, além de aumento da satisfação e sensação de normalidade da mulher aos 3 meses.  
Uma sutura de duas fases (a pele é aposta mas não suturada) não se associa com aumento no reparo de deiscência mas evidencia menos dispareunia aos 3 meses, além de alguma evidência com menos dor perineal no curto prazo quando as suturas são de catgut cromado.  
A sutura contínua subcuticular está associada com menor dor no curto prazo quando comparada com a sutura interrompida da pele.  
16.4.3.3.3 Recomendações em relação aos métodos de reparo perineal  
186. Não há necessidade de sutura da pele se as suas bordas se apõem após a sutura do músculo, em trauma de segundo grau ou episiotomia.  
187. Se houver necessidade de sutura da pele, utilizar uma técnica subcutânea contínua .  
188. Realizar a reparação perineal usando uma técnica de sutura contínua para a camada de parede vaginal e músculo.  
16.4.3.4 Materiais para o reparo perineal  
16.4.3.4.1 Evidências Científicas  
Uma revisão sistemática foi realizada em 1999 para avaliar os efeitos do material de sutura sintético absorvível em comparação com catgut<sup>403</sup> [NE = 1+]. A revisão incluiu oito ensaios clínicos, envolvendo 3.642 mulheres. Sete ensaios utilizaram fio de ácido poliglicólico (Dexon) e um ensaio clínico utilizou o fio a base de poligalactina (Vicryl). Mulheres incluídas nos grupos que utilizaram material de sutura sintética absorvível relataram significativamente menor dor de curto prazo em comparação com aquelas cujas suturas foram realizadas com categut: dia 3 pós sutura ou antes: OR = 0,62; IC95%: 0,54-0,71, em oito ensaios; dia 04-10: OR=0,71; IC95%: 0,58-0,87, três ensaios. Esse grupo de mulheres também relatou menos deiscência de sutura até o décimo dia (OR=0,45; IC95%: 0,29-0,70), em cinco ensaios; e necessidade de ressutura do trauma perineal até 3 meses (OR=0,26; IC95%: 0,10-0,66), em quatro ensaios. Contudo, a necessidade de remoção de material de sutura até 3 meses foi maior no grupo de mulheres que foram suturadas com material de sutura sintética absorvível (OR=2,01; IC95%: 1,56-2,58), em dois ensaios.  
Um outro ERC comparou o processo de cicatrização de suturas realizadas com categut cromado (449/908) com a poligalactina de rápida absorção (459/908)<sup>404</sup> [NE = 1+]. No grupo suturado com catgut cromado, mais mulheres apresentaram dor uterina moderada/intensa em 24-48 horas (n = 114 (25%) versus n = 154 (34%), p=0,006). Esta diferença significativa foi também evidente em 6-8 semanas Outra RS da Cochrane foram comparou material de sutura sintética rapidamente absorvido (n = 772) com um material de sutura sintético padrão (n = 770). O estudo envolveu mulheres que tiveram laceração de segundo grau ou episiotomia<sup>405</sup> [NE = 1+]. Não houve diferenças significativas entre os grupos em relação à dor 10 dias após o parto, mas outros achados favoreceram o grupo que foi submetido a sutura com material sintético de absorção rápida: OR 0,84 [IC 95% 0,68 a 1,04]. Houve redução significativa de utilização de analgesia nas 24 horas prévias nas mulheres do grupo de material de sutura de absorção rápida (OR=0,55; IC95%: 0,36-0,83); além de uma redução significativa da dor ao andar para este grupo (OR=0,74; IC95%: 0,56-0,97). A necessidade de remoção de suturas nos 3 meses após o parto foi também menor para as mulheres suturadas com o material de sutura de absorção

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.4.3.4.2 Resumo da evidência e conclusões -->
Há evidências de que o material de sutura sintético de absorção rápida está associado a menos dor no curto prazo, menos deiscência de sutura e menor necessidade de nova sutura do períneo até três meses após o parto quando comparado a sutura realizada com fio do tipo catgut.  
16.4.3.4.3 Recomendações em relação aos materiais para o reparo perineal  
189. Recomenda-se a utilização de material de sutura sintética absorvível para suturar o períneo.  
190. Observar os princípios básicos seguintes ao realizar reparos perineais:  
- Realizar a reparação do trauma perineal utilizando técnicas assépticas.  
- Verificar os equipamentos e conte as compressas, gazes e agulhas antes e depois do procedimento.  
- Dispor de uma boa iluminação para identificar as estruturas envolvidas.  
- O trauma de difícil reparação deve ser reparado por um médico experiente sob anestesia regional ou geral.  
- Certificar-se de que um bom alinhamento anatômico da ferida foi alcançado e que se dê atenção aos resultados estéticos.  
- Realizar exame retal após a conclusão do reparo em casos de trauma de difícil abordagem ou de 3<sup>o</sup> ou 4<sup>o</sup> graus, para garantir que o material de sutura não foi acidentalmente inserido através da mucosa retal.  
- Após a conclusão do reparo, documentar detalhadamente a extensão do trauma, o método de reparação e os materiais usados.  
- Dar a informação à mulher sobre a extensão do trauma, o alívio da dor, dieta, higiene e a importância dos exercícios do assoalho pélvico.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 16.4.3.2.1 Evidências Científicas -->
As diretrizes do NICE de 2014 incluíram uma revisão sistemática, que por sua vez incluiu 249 mulheres, que avaliou a eficácia dos analgésicos retais para dor de trauma perineal após o parto<sup>406</sup> [NE = 1+]. Os dois ensaios clínicos incluídos usaram supositórios analgésicos anti-inflamatórios não-esteroidais (AINES) em comparação com um placebo. Os resultados sugerem que a administração anti-inflamatórios não esteroidais por via retal proporcionam alívio eficaz da dor após o reparo perineal (nos dois ensaios). Para a indometacina, a incidência de dor perineal nas primeiras 24 horas pós-parto foi de 6/30 contra 30/30, RR=0,20; IC 95%: 0,10-0,41; para o diclofenaco RR=0,65; IC 95%: 0,50-0,85.  
Um ensaio clínico randomizado realizado na Austrália também avaliou a eficácia de anti-inflamatório diclofenaco retal em comparação com um placebo<sup>407</sup> [NE = 1+]. As mulheres no grupo de tratamento (n = 67) recebeu um diclofenaco supositório imediatamente após o reparo perineal (com laceração de segundo grau e episiotomia). Mulheres randomizados para o grupo controle recebeu um supositório placebo . Ambos os grupos receberam uma segunda dose de supositório 12-24 horas depois. Às 24 horas após o nascimento, os escores de dor das mulheres foram significativamente menores para o grupo de tratamento, em comparação com o grupo controle, embora isto não tenha sido evidente em todas as escalas de medição. Para escores de dor associado ao movimento às 24 horas, ambas as escalas utilizadas apresentaram pontuações significativamente menores no grupo de tratamento.  
16.4.3.2.2 Resumo da evidência e conclusões  
Há evidências de alto nível que os AINEs retais reduzem a dor perineal imediatamente após o reparo

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: perineal. -->
16.4.3.2.3 Recomendações em relação à analgesia após o reparo perineal  
191. Recomenda-se oferecer supositórios retais de anti-inflamatórios não esteróides rotineiramente após o reparo do trauma perineal de primeiro e de segundo grau, desde que esses medicamentos não sejam contraindicados.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.1 Introdução -->
O nascimento é um evento cercado de inúmeras modificações fisiológicas na transição do feto para a vida extrauterina. Tais modificações incluem o estabelecimento da respiração, alterações cardiovasculares, regulação da temperatura corporal, início do processo de digestão e absorção dos alimentos e desenvolvimento do sistema imune.  
A grande maioria das crianças fazem essa transição sem intercorrências mas a vigilância por parte dos profissionais de saúde e intervenção oportuna, quando necessária, podem influenciar na saúde desse recém-nascido e no seu desenvolvimento futuro.  
Estima-se que, durante as primeiras 24 horas após o parto, ocorrem entre 25 e 45% das mortes neonatais associados a problemas como asfixia, baixo peso ao nascer e prematuridade.  
No Brasil, em 2013, nasceram 2.904.027 crianças sendo 11,5% prematuros e 8,5% com baixo peso ao nascer (<2500g). A mortalidade infantil no período foi de 13,4 por mil nascidos vivos. Considerando-se o total de óbitos no primeiro ano de vida, cerca de 60% desses ocorreram nos primeiros 6 dias de vida expressando a complexa conjunção de fatores biológicos, socioeconômicos e assistenciais, esses últimos relacionados à atenção à gestante e ao recém-nascido<sup>408,409</sup> .  
Esse fato tem chamado a atenção para práticas importantes no cuidado neonatal ao nascimento e nos primeiros dias de vida com o objetivo de reduzir de forma expressiva a mortalidade neonatal. Entre essas práticas destacamos a reanimação neonatal, o clampeamento tardio do cordão umbilical, o contato imediato pele-a-pele e o início da amamentação exclusiva ao seio materno, entre outras. São práticas que, além de proporcionar benefício instantâneo ao recém-nascido, podem ter impacto no longo prazo e no desenvolvimento da criança muito além do período neonatal.  
17.2 Assistência imediatamente após o parto

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.1 Introdução -->
A assistência neonatal imediata nos reporta às práticas de reanimação neonatal pois segundo evidências científicas, um em cada 10 recém-nascidos (RN) necessita de ventilação com pressão positiva para iniciar ou manter movimentos respiratórios efetivos, um em cada 100 neonatos precisa de intubação ou massagem cardíaca e um em cada 1.000 necessita de intubação traqueal, massagem e medicações, desde que a ventilação seja aplicada adequadamente. Considerando que nascem no Brasil cerca de três milhões de crianças ao ano, das quais 98% em hospitais, estima-se que, a cada ano, 300.000 crianças necessitem de ajuda para iniciar e manter a respiração ao nascer. Nesse sentido as manobras de reanimação neonatal podem ser necessárias de maneira inesperada e assim, torna-se essencial o conhecimento e a habilidade em reanimação neonatal pelos profissionais que atendem ao recémnascido em sala de parto.  
17.2.2 Profissional que assiste ao recém-nascido logo após o parto  
17.2.2.1 Questão de revisão  
- Qual deve ser a formação do profissional  para assistência imediata ao recém-nascido normal e  
para início de técnicas básicas de ressuscitação em ambiente de parto para assegurar os melhores resultados?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.2.2 Evidências Científicas -->
Nenhuma da diretrizes-fonte desta adpatação abordaram esse tópico e não apresentaram evidências científicas avaliando os riscos e benefícios dos diversos profissionais para assistência imediata do recémnascido normal em ambiente de parto.  
As diretrizes do NICE recomendam que todos os profissionais envolvidos no cuidado à mãe e RN deverão realizar um curso anual em reanimação neonatal de acordo com as diretrizes nacionais do programa de reanimação neonatal.  
As diretrizes ainda ressaltam que em todos os ambientes de nascimento, poderá ser necessária a reanimação neonatal e assim deve-se assegurar que estejam disponíveis os equipamentos e medicações para a reanimação e para a transferência do RN para outro local, se necessário, e que se desenvolva e implemente protocolos de encaminhamento de emergência tanto para a mulher como para o RN.  
Nos primeiros minutos após o nascimento deve-se avaliar a condição do recém-nascido, especificamente a respiração, frequência cardíaca e o tônus, a fim de determinar se é necessária reanimação de acordo com as orientações nacionais em reanimação neonatal.  
Relata ainda que se deve minimizar a separação do recém-nascido de sua mãe e em casos de reanimação um profissional de saúde deve conversar com a gestante e oferecer apoio para a mulher e seu acompanhante.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.2.3 Outras considerações -->
As recomendações do NICE coincidem com as recomendações do Ministério da Saúde no sentido de ter um profissional capacitado em reanimação neonatal em todo o nascimento. Essa recomendação está contemplada na Portaria 371 do Ministério da Saúde do Brasil de 07 de maio de 2014, que considera como capacitado em reanimação neonatal o profissional que tenha realizado treinamento teóricoprático, conforme orientação da Norma técnica 16/2014, da Coordenação Geral da Saúde da Criança e Aleitamento Materno (CGSCAM/MS) de 10 de junho de 2014<sup>410,411</sup> .  
O atendimento ao recém-nascido consiste na assistência por profissional capacitado, médico (preferencialmente pediatra ou neonatologista) ou profissional de enfermagem (preferencialmente enfermeiro obstetra ou neonatal). Importante lembrar que aos profissionais médicos e de enfermagem cabem os procedimentos referentes aos passos iniciais da reanimação neonatal e da ventilação com pressão positiva com reanimadores manuais com máscara facial. No entanto cabe somente ao médico os procedimentos de ventilação com pressão positiva com intubação traqueal, massagem cardíaca e indicação de medicações, de acordo com os protocolos e manuais adotados pelo Ministério da Saúde. Esses últimos procedimentos podem ser necessários em qualquer nascimento mesmo nos partos de baixo risco.  
Dessa forma há o entendimento do Programa de Reanimação Neonatal da Sociedade Brasileira de Pediatria, e a adotado pelo Ministério da Saúde,  de que a assistência ao recém-nascido na sala de parto seja realizada pelo melhor profissional capacitado, ou seja, o pediatra treinado em todos os procedimentos de reanimação neonatal. Nos locais distantes dos grandes centros, em que a presença do pediatra não é possível, o recém-nascido tem o direito ao melhor atendimento disponível por outro profissional médico ou de enfermagem habilitado em ventilação com balão e máscara, cuja atenção esteja voltada exclusivamente para o mesmo. A portaria 371 em seu artigo 6 garante a presença de pelo menos um médico, durante as 24 horas do dia, habilitado em reanimação conforme previsto no artigo 3  
dessa portaria, nos estabelecimentos de saúde que realizam parto<sup>410</sup> .  
As recomendações a seguir não foram abordadas por nenhuma das diretrizes adaptadas e foram baseadas na legislação brasileira.  
17.2.2.4 Recomendações sobre profissional que assiste ao recém-nascido logo após o parto  
192. O atendimento ao recém-nascido consiste na assistência por profissional capacitado, médico (preferencialmente pediatra ou neonatologista) ou profissional de enfermagem (preferencialmente enfermeiro obstetra/obstetriz ou neonatal), desde o período imediatamente anterior ao parto, até que o RN seja encaminhado ao Alojamento Conjunto com sua mãe, ou à Unidade Neonatal ou ainda, no caso de nascimento em quarto de pré-parto parto e puerpério (PPP) seja mantido junto à sua mãe, sob supervisão da própria equipe profissional responsável pelo PPP.  
193. É recomendada a presença de um médico pediatra adequadamente treinado em todos os passos da reanimação neonatal.  
194. Em situações onde não é possível a presença de um médico pediatra, é recomendada a presença de um profissional médico ou de enfermagem adequadamente treinado em reanimação neonatal.  
195. Os estabelecimentos de saúde que mantenham profissional de enfermagem habilitado em reanimação neonatal no momento do parto, deverá possuir em sua equipe de retaguarda, durante 24 horas, ao menos um médico que tenha realizado treinamento teórico-prático em reanimação neonatal.  
17.2.3 Métodos de avaliação imediata do recém-nascido logo após o nascimento  
17.2.3.1 Questões de revisão  
 Como os diferentes métodos de avaliação imediata do recém-nascido influencia nos resultados?  
17.2.3.2 Introdução  
Os métodos de avaliação imediata do recém-nascido incluem o índice de Apgar e a medida do pH de sangue do cordão umbilical. O índice de Apgar foi desenvolvido em 1953 e tem sido amplamente adotado como método de avaliação da criança ao nascimento<sup>412</sup> . Foi inicialmente planejado para indicar a necessidade de reanimação e não havia, na época, intenção de correlacioná-lo com o prognóstico. O pH de cordão umbilical, especialmente da amostra arterial, também tem sido avaliado como marcador de mortalidade neonatal, encefalopatia hipóxico-isquêmica moderada e grave, convulsão, necessidade de internação em unidade de terapia intensiva neonatal, repercussões neurológicas e alterações do neurodesenvolvimento no futuro.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.3.3 Evidências Científicas -->
As evidências em relação a esses dois métodos de avaliação do recém-nascido são analisadas a seguir. 17.2.3.3.1 Escore de Apgar  
As diretrizes do NICE incluíram 5 estudos de coorte e uma revisão sistemática que avaliou 16 estudos também de coorte correlacionando o valor prognóstico do índice de Apgar de 1º e 5º minuto de vida e mortalidade e ocorrência de paralisia cerebral<sup>413-418</sup> . De modo geral, o índice de Apgar pareceu ser um preditor de nível moderado para morte neonatal e desenvolvimento de paralisia cerebral, com o índice de 5º minuto tendo um valor preditivo melhor que o de 1º minuto. Em relação à mortalidade, comparando-se o índice de Apgar de primeiro minuto de 0 a 3 versus 4 a 10 o OR foi de 17,71 (16,07 – 19,51) e para valores de 0 a 6 versus 7 a 10 o OR foi de 10,73 (9,72-11,35). Na comparação de valores de Apagar de quinto minuto temos: 0 a 3 versus 4 a 10 o OR foi de 218,42 (203,09 – 234,90) e 0 a 6 versus 7 a 10 o  OR foi de 97,16 (91,58 – 103,07). Em relação à ocorrência de paralisia cerebral, a meta-análise mostrou que, em relação ao primeiro minuto, comparando-se valores entre 0 a 3 versus 4 a 10  foram  
obtidos OR de 6,67 (4,67 – 9,61) e entre valores de 0 a 6 versus 7 a 10 o OR foi de 3,36 (2,44 – 4,61). Para valores de quinto minuto, comparando valores entre 0 a 3 versus 4 a 10 encontrou-se OR de 39,90 (28,37-56,11) e entre 0 a 6 versus 7 a 10, OR=29,59 (23,80 – 36,78). 17.2.3.3.2 pH de cordão umbilical  
Em relação ao pH de cordão, nas diretrizes do NICE foram encontrados oito estudos<sup>419-426</sup> , incluindo uma revisão sistemática com 51 estudos observacionais de diferentes países e desenhos metodológicos. Essa revisão<sup>421</sup> reuniu trabalhos que avaliaram o valor preditivo tanto do pH de sangue arterial como venoso ou excesso de base. Alguns estudos relacionaram o pH de cordão com o prognóstico em curto e longo prazo do recém-nascido, da criança e mesmo na vida adulta, bem como sua coleta universal no seguimento perinatal.  Todos os trabalhos utilizaram o pH de sangue umbilical, não sendo utilizado como critério de seleção dos trabalhos o sangue do recém-nascido coletado logo após o nascimento. Em relação aos valores de pH de sangue de artéria umbilical e desfechos da criança, há uma evidência positiva entre pH <7,00 e mortalidade neonatal (3 estudos – 464.663 RNs - OR 16,09 IC 95% 8,94 a 28,95), encefalopatia hipóxico-isquêmica  (5 estudos – 14.453 RNs – OR 10,45 IC 95% 4,83 a 22,62) e convulsão (1 estudo – 63 RNs – OR 99 IC 95% 5,11 a 1918,03). Porém, não houve há associação com paralisia cerebral (1 estudo – 202 RNs – OR 0,45 IC 95% 0,02 a 9,59). Em meta-análise de 3 estudos não se encontrou associação entre pH de 7,10 a 7,20 e mortalidade neonatal (1.888 RNs OR 4,71 IC 95% 0,89 a 25,11). Usando um corte de pH< 7,05 e pH <7,10 as evidências também mostram uma forte correlação positiva entre o pH do cordão e encefalopatia hipóxico-isquêmica grau II/III (OR 50,38 IC 95% 9,14 a 277 e OR 23,08 IC 95% 4,45 a 109, respectivamente). Meta-análise de 4 estudos mostrou que pH<7,00 ou <7,20 teve uma forte associação positiva com convulsão (OR 43,66 IC 95% 5,69 a 335,1 e OR 3,13 IC 95% 1,83 a 5,34, respectivamente). Um estudo com 13.489 RNs mostrou forte associação entre a admissão hospitalar e pH ≤7,00 versus pH 7,26-7,30 (OR 6,38 IC 95% 5,72 a 7,1). Apenas um estudo, onde se avaliou pH≤7,00 e entre 7,01-7,10 versus pH=7,26-7,30, correlacionou-se com encefalopatia e convulsão ou com morte e admissão em unidade de terapia intensiva. No mesmo estudo não foram encontradas diferenças em recém-nascidos com pH=7,11–7,20 e 7,21–7,25 comparado com pH 7,26–7,30. Estudos que avaliaram desempenho de crianças aos 18 meses também não mostraram correlação com PH<7,12 quando comparado com pH maior. Outros desfechos como asma, rinite alergica e eczema atópico aos 5- 6 anos em crianças com pH <7,19 também não foram diferentes em relação às crianças com pH de 7,26– 7,29.  No entanto, houve diferença quando a comparação foi entre pH<7,12 versus 7,26–7,29 na mesma idade de avaliação. Um pequeno estudo com apenas 43 crianças avaliou o desempenho neurológico e motor aos 3 meses sem obter diferença entre os valores de pH.  O mesmo ocorreu com a possibilidade de internação observado em um estudo com 6.714 recém-nascidos.  
Considerando-se o desempenho intelectual apenas um estudo mostra baixa correlação de aquisições cognitivas aos 6-8 anos com valores de pH.  
17.2.3.4 Resumo da evidência e conclusões  
As diretrizes informam que há um baixo nível de evidência de que o índice de Apgar de quinto minuto possa predizer a morte neonatal e paralisia cerebral com especificidade razoável e baixa sensibilidade. Não há nível de evidência elevado para sustentar sua correlação com desfechos neonatais a curto e longo prazo.  
Em relação aos valores de pH os estudos mostram resultados neonatais desfavoráveis com pH de artéria umbilical abaixo de 7,0, incluindo mortalidade, encefalopatia hipóxico-isquêmica, convulsão e admissão em unidade de terapia intensiva.  As diretrizes concordam que a mensuração do pH nas circunstâncias  
de uma criança sem boa vitalidade (avaliada por padrão anormal de respiração, frequência cardíaca e tônus) é clinicamente útil pois pode fornecer informações adicionais que podem ajudar no planejamento do cuidado de crianças com suspeita de asfixia. Também foram encontrados resultados desfavoráveis com o pH<7,10. Assim, esse dado pode ser um preditor de resultados ruins neonatais, e dessa forma, indicar encefalopatia e convulsão. Assim poder-se-á propor tratamentos específicos, como resfriamento terapêutico, e assim melhorar o prognóstico futuro dessas crianças.  Além dos benefícios diretos na saúde dos recém-nascidos esse procedimento poderá implicar em diminuição de gastos em saúde.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.3.5 Outras considerações -->
O grupo de desenvolvimento das diretrizes NICE vem discutindo se seria conveniente recomendar análise do sangue do cordão de forma universal. No entanto, a evidência para esta abordagem ainda é de baixa qualidade e o grupo não se sente confortável nessa recomendação. O mais adequado seria obter esse exame se alguma condição clínica do recém-nascido assim o indicar. Assim, dadas as limitações da evidência, não se recomenda, de forma universal, a análise do sangue do pH de cordão em todos os recém-nascidos. Na atualização do NICE de 2014 foi encontrado um estudo<sup>422</sup> que mostrou correlação baixa ou muito baixa entre as várias medidas cognitivas e valores de pH. Esse estudo além de excluir recém-nascidos com pH<7,0, não estratificou diferentes valores. Assim, permaneceu a mesma falta de evidências já descrita anteriormente.  
Assim se considera que é útil obter o pH arterial umbilical no momento do nascimento  a fim de fornecer informações adicionais que podem ajudar o plano de assistência neonatal adequado, para as crianças onde há a suspeita de que houve um período de hipóxia intra-parto.  
17.2.3.6 Recomendações sobre métodos de avaliação imediata do recém-nascido logo após o parto 196. Realizar o índice de Apgar ao primeiro e quinto minutos de vida, rotineiramente  
197. Coletar sangue de cordão para análise de pH em recém-nascidos com alterações clínicas tais  
como respiração irregular e tônus diminuído. Não fazer a coleta de maneira rotineira e universal.  
17.2.4 Intervenções de rotina no recém-nascido logo após o nascimento  
17.2.4.1 Questões de revisão  
- Qual o momento mais apropriado para clampeamento do cordão umbilical?  
- Qual posição, em relação à mãe, o recém-nascido deve permanecer até o pinçamento do cordão umbilical, para favorecer a transfusão placentária?  
- A profilaxia da hipotermia neonatal deve ser realizada de rotina?  
- Quais métodos são mais apropriados para profilaxia da hipotermia neonatal?  
- Qual a efetividade da aspiração nasofaringeana e sondagem gástrica e retal de rotina do recémnascido no pós parto imediato?  
- A profilaxia da oftalmia neonatal deve ser feita de rotina?  
- Qual o momento ideal para realização da profilaxia da oftalmia neonatal?  
- Quais intervenções são mais apropriadas para a realização da profilaxia da oftalmia neonatal?  
- A profilaxia da doença hemorrágica do recém-nascido deve ser feita de rotina?  
- Qual o momento ideal para realização da profilaxia da doença hemorrágica do recém-nascido?  
- Quais intervenções são mais apropriadas para a profilaxia da doença hemorrágica do recémnascido?  
17.2.4.2 Clampeamento do cordão umbilical  
17.2.4.2.1 Evidências Científicas  
As diretrizes do NICE incluíram 4 estudos<sup>353-356</sup> , sendo um deles uma revisão sistemática com 15 estudos em diferentes locais<sup>355</sup> e 3 estudos controlados randomizados. Todos os estudos incluídos avaliaram o efeito do momento do clampeamento do cordão umbilical nos resultados maternos e em recémnascidos de termo sendo que esse momento variou entre os estudos. O clampeamento do cordão precoce foi definido quando este ocorreu entre 5 segundos a 1 minuto após o nascimento e o tardio quando ocorreu entre 1-5 minutos após o nascimento ou quando o cordão parou de pulsar. Alguns estudos relacionaram também o tipo de uterolítico, a dose utilizada e o tempo de administração, os quais também variaram entre os estudos incluídos.  
O nível em que o RN foi posicionado antes do clampeamento do cordão foi observado na maioria dos ensaios e relatado na revisão sistemática<sup>355</sup> . Em 4 ensaios, o RN foi colocado ao nível do útero ou da vagina, em 6 ensaios abaixo do nível do útero (10 cm a 30 cm) e em 4 ensaios o RN está foi colocado sobre o abdômen mãe.  
Os desfechos neonatais reportados foram Apgar de quinto minuto, presença de icterícia, admissão em unidade de terapia intensiva neonatal (UTIN), policitemia, valores de hemoglobina e hematócrito em diferentes tempos,  ferritina e ferro aos 3-6 meses, avaliação neurológica aos 4 meses e tipo de aleitamento na alta e de 1-6 meses.  
Algumas análises incluíram apenas países desenvolvidos.  Uma meta-análise de três estudos encontrou um número de recém-nascidos com icterícia que necessitavam fototerapia significativamente menor naqueles alocados para receber clampeamento precoce do cordão quando comparados com o procedimento tardio. Outro estudo encontrou níveis estatisticamente significativamente mais baixos de hemoglobina no nascimento em recém-nascidos alocados para clampeamento precoce do cordão versus tardio. O mesmo ocorreu quando se avaliou a hemoglobina em 24-48 horas. Um estudo mais aprofundado de um país desenvolvido encontrou de forma estatisticamente significativa, menor número de recém-nascidos com ferritina<20 mg/litro aos 4 meses naqueles com clampeamento precoce versus tardio. Não foram observadas diferenças estatisticamente significativas entre os tempos de clampeamento para todos os outros desfechos  
Evidências científicas de alta qualidade mostram que a incidência de icterícia que necessita de fototerapia  são  menores  em recém-nascidos que tiveram clampeamento precoce do cordão quando comparado com procedimento tardio. Esses dados não foram considerados relevantes do ponto de vista clinico.  
Houve diferenças estatisticamente significativas em uma série de medidas de hemoglobina neonatal. No entanto, essas diferenças também não foram importantes do ponto de vista clinico nas avaliações de 24-48 horas, 2-4 meses e 3-6 meses. Houve uma taxa estatisticamente significativa de hematócrito <45% com 6 horas e 24-48 horas no grupo de clampeamento precoce. Há também níveis mais baixos de ferritina aos 3, 4 e 6 meses no grupo de clampeamento precoce do cordão. Embora isso possa sugerir um dano potencial esse dado não foi valorizado na medida que existe uma grande faixa de normalidade para a ferritina.  
Nenhum dos estudos encontrou uma diferença significativa entre recém-nascidos com clampeamento precoce versus tardio nos seguintes resultados: incidência de icterícia clínica, Apgar menor que 7 aos 5 minutos, admissão à unidade de terapia intensiva neonatal,  síndrome do desconforto respiratório 3 policitemia.  
Em relação ao aleitamento materno, uma meta-análise que demonstrou uma taxa significativamente maior de aleitamento materno exclusivo ao primeiro mês no grupo de clampeamento precoce, mas essa

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: diferença não permaneceu aos 2-6 meses. -->
Em relação à posição do recém-nascido no momento do clampeamento do cordão, nenhum das diretrizes-fonte da adaptação analisam desfechos relacionados à intervenção. As diretrizes do  NICE apenas comentam que o nível em que o RN foi posicionado antes do clampeamento do cordão foi observado na maioria dos ensaios e relatado na revisão sistemática<sup>355</sup> .  Em 4 ensaios o RN permaneceu ao nível do útero ou da vagina, em 6 ensaios foi mantido abaixo do nível do útero (10 cm a 30 cm abaixo) e em 4 ensaios o cordão foi clampeado pela mulher ou colocado em seu abdômen. Para os dois ensaios restantes a posição do RN em relação ao útero não foi relatada. Mas, no entanto não realizaram análise dos desfechos em relação às diferentes posições e portanto, nenhuma recomendação sobre essa intervenção será realizada nestas Diretrizes adaptadas.  
17.2.4.2.2 Resumo das evidências e conclusões  
Em resumo, os estudos mostram uma certa discrepância nos resultados apresentados, principalmente relacionadas às definições do que se entende como clampeamento precoce e tardio bem como as variáveis de desfecho incluídas. Nos estudos em que consideraram a icterícia com fototerapia como um resultado neonatal desfavorável, não relataram o protocolo usado para a indicação desse procedimento.  Foi observado também um aumento dos níveis de hemoglobina no grupo de clampeamento tardio.  
De forma geral os estudos mostraram que a qualidade das evidências variaram consideravelmente. Uma das principais razões para que os estudos perdessem seu valor foi devido ao fato de que os resultados observados tiveram amplos intervalos de confiança.  
17.2.4.2.3 Outras considerações  
De maneira geral é  recomendado que o clampeamento não deva ocorrer antes do primeiro minuto do nascimento do RN. No entanto,  às vezes há  necessidade desse clampeamento ser mais precoce nos casos em que é necessária uma reanimação neonatal.  Os estudos não indicam um tempo limite máximo para o clampeamento, muito embora a maioria dos trabalhos não se realizou esse clampeamento depois de 3 minutos após o nascimento. Não foram observados benefícios adicionais se o clampeamento ocorresse além de 5 minutos.  
Se o clampeamento tardio leva a um aumento no número de recém-nascidos com icterícia, então esta estratégia iria aumentar o uso dos recursos. RN com icterícia exigiria um acompanhamento e, em alguns casos o tratamento com fototerapia. No entanto, como os limiares de tratamento utilizados nos estudos são diferentes das práticas do Reino Unido, essas diferenças não puderam ser analisadas.  
17.2.4.2.4 Recomendações em relação ao clampeamento do cordão  
198. Realizar o clampeamento do cordão umbilical entre 1 a 5 minutos ou de forma fisiológica quando cessar a pulsação, exceto se houver alguma contra indicação em relação ao cordão ou necessidade de reanimação neonatal .  
17.2.4.3 Profilaxia da hipotermia neonatal  
Nenhuma das diretrizes-fonte dessa adaptação abordou esse tópico.  
17.2.4.3 Aspiração nasofaringeana e sondagem gástrica e retal de rotina do recém-nascido no pós parto  
imediato  
17.2.4.3.1 Evidências científicas  
As diretrizes do NICE não abordaram essa questão, que foi abordada pelas diretrizes espanholas. Foram incluídos dois estudos que avaliaram a aspiração nasofaringeana em recém-nascidos saudáveis em comparação com ausência de aspiração.  
O primeiro estudo foi uma amostra pequena (n = 40), com risco de viéses devido à ausência de uma randomização correta e de uma ocultação da sequência<sup>427</sup> [NE = 1-]. Não foram encontradas diferenças significativas nas variáveis estudadas. O estudo concluiu que, considerando que a mecânica respiratória e a frequência cardíaca não se beneficiam da aspiração oronasofaringeana, seu uso rotineiro deve ser limitado em recém-nascidos saudáveis.  
O ERC publicado em 2005, realizado na Turquia, incluiu 140 recém-nascidos após parto vaginal e líquido amniótico claro, agrupados em dois grupos com 70 recém-nascidos cada (com e sem aspiração oronasofaringeana)<sup>428</sup> [NE = 1+]. Os resultados demonstraram uma frequência cardíaca significativamente menor aos 3-6 minutos no grupo sem aspiração (p < 0,001). O tempo máximo para obter níveis de SpO2 > 92% foi de 6 e 11 minutos (sem e com aspiração), respectivamente (p < 0,001). O escore de Apgar com 1 minuto atingiu uma pontuação de 8-9 em ambos os grupos, enquanto que o Apgar aos 5 minutos nos recém-nascidos aspirados não chegou a pontuação 10. Os autores concluíram recomendando revisar a política de aspiração orofaringeana em recém-nascidos saudáveis.  
Em relação à sondagem gástrica e retal, os desenvolvedores das diretrizes espanhola não encontraram evidências e consideraram que existem outros sinais de alarme que permitem suspeitar de uma atresia de esôfago, estando de acordo com as últimas recomendações da Associação Espanhola de Pediatria sobre cuidados e atenção com o recém-nascido saudável nas primeiras horas após o nascimento<sup>429</sup> , em não realizar sondagem pelas fossas nasais, pelo esôfago e pelo ânus, já que um exame físico rotineiro do recém-nascido pode ser suficiente para descartar a maior parte dos problemas neonatais.  
17.2.4.3.2 Resumo da evidência e conclusões  
As evidências analisadas nas diretrizes permitem a mesma conclusão de que não há necessidade de realizar a aspiração nasofaringeana em recém-nascidos saudáveis. Em relação à sondagem gástrica e retal as diretrizes espanholas recomendam pela sua não realização, utilizando como referência as recomendações da Associação Espanhola de Pediatria.  
17.2.4.3.3 Recomendações em relação à aspiração nasofaringeana e sondagem gástrica e retal de rotina em recém-nascidos saudáveis  
199. Não se recomenda a aspiração orofaringeana e nem nasofaringeana sistemática do recémnascido saudável.  
200. Não se recomenda realizar a passagem sistemática de sonda nasogástrica e nem retal para descartar atresias no recém-nascido saudável.  
17.2.4.4 Profilaxia da oftalmia neonatal  
17.2.4.4.1 Evidências científicas  
As diretriz do NICE não abordaram esse tópico que foi abordado nas diretrizes espanholas. Foi incluído um documento de revisão elaborado por Goldbloom RB em 1994 para a Força-Tarefa Canadense sobre a profilaxia oftálmica para gonococos e clamídia em neonatos<sup>430</sup> . A revisão incluiu estudos que avaliaram a eficácia da profilaxia ocular neonatal com solução de nitrato de prata a 1% ou pomada de tetraciclina a 1% ou de eritromicina a 0,5% em dose única, aplicados na conjuntiva do recém-nascido.  
As evidências de estudos realizados antes e depois que compararam a realização da profilaxia em comparação com sua não realização mostraram uma drástica redução na incidência de oftalmia gonocócica e cegueira. Com relação à infecção por clamídia, as evidências procedentes de ensaios quase experimentais mostraram que os diferentes agentes possuem eficácia comparável, ainda que isso não seja conclusivo.  
Em relação ao momento mas apropriado para a realização da profilaxia da oftalmia neonatal, foi  
incluído, nas diretrizes espanholas, um relatório realizado em 2002 sobre práticas rotineiras de enfermagem no Canadá<sup>431</sup> . Com base nas evidências disponíveis na época e através de consenso, estabeleceu-se o momento da administração da eritromicina na profilaxia da oftalmia neonatal que, até aquele momento, era realizada antes de uma hora depois do nascimento e, a partir de então, foi estendido para duas horas, objetivando o fortalecimento do apego mãe-filho logo após o nascimento. Essas mudanças basearam-se no conhecimento de que o período de incubação da gonorréia é de 9 dias e da clamídia de 3-4 dias. Os autores recomendam que o momento ideal para a profilaxia oftálmica seja de 4 horas após o parto. Por outro lado, a RS da Força-Tarefa Canadense de 1994, já mencionada, propunha realizar a profilaxia antes de uma hora após o nascimento, pois já faziam isso nos estudos incluídos na mesma.  
Em relação às intervenções para a profilaxia da oftalmia neonatal, as diretrizes espanholas incluiu a revisão de Goldbloom RB de 1994<sup>430</sup> que recomendou a profilaxia com pomada oftálmica de eritromicina a 0,5%, tetraciclina a 1% ou nitrato de prata a 1% em aplicação e dose única. No entanto, mencionam que o uso do nitrato de prata pode apresentar efeitos secundários, tais como conjuntivites químicas transitórias.  
As diretrizes também citam como referência as opiniões das sociedades científicas, entre elas a Associação Espanhola de Pediatria (AEP), que recomenda, em seus protocolos sobre diagnóstico e terapêutica neonatológica em pediatria (revisados em 2003)<sup>432</sup> , realizar a prevenção da oftalmia neonatal dentro dos cuidados gerais na sala de parto, com administração de pomada oftálmica de tetraciclina a 1% ou eritromicina a 0,5% em ambos os olhos, reconhecendo que a prática é bastante útil no caso de infecção por Neisseria gonorrhoeae e é parcialmente efetiva no caso de infecção por clamídia.  
Além disso, citam que no documento da Associação Espanhola de Pediatria publicado em 2009 sobre cuidados e atenção com o recém-nascido saudável no parto e nas primeiras horas após o nascimento<sup>429</sup> , recomendava-se o diagnóstico e o tratamento das infecções por gonococos e C. trachomatis na gestante como melhor forma de prevenção da infecção neonatal vertical, assim como a administração de dose única de colírio ou pomada antibiótica no recém-nascido, o mais precocemente possível. No entanto, e devido ao fato de que esses fármacos podem turvar a visão do recém-nascido e interferir na instauração do vínculo mãe-filho, recomenda-se atrasar essa administração até que o período de contato de pele a pele tenha terminado (50-120 min). O grupo elaborador das diretrizes espanholas concordou, tanto com a evidência para administração do tratamento farmacológico, quanto com o atraso de tal tratamento até a finalização do período de contato pele a pele.  
17.2.4.4.2 Resumo da evidência e conclusões sobre profilaxia da oftalmia neonatal  
Resumindo, existem evidências de qualidade para justificar a utilização rotineira da profilaxia da oftalmia neonatal por infecção gonocócica, pelo menos na ausência de testes pré-natais universais quanto à gonorréia. Em relação à eficácia da profilaxia da oftalmia neonatal por clamídia, as evidências não são conclusivas.  
Há evidências sobre os períodos de incubação das infecções oftálmicas (9 dias para gonorréia e 3-4 para clamídia) que têm servido de apoio para atrasar o momento de realização da profilaxia oftálmica. Embora não apresentando evidências de comparação entre as intervenções para a profilaxia da oftalmia neonatal, as diretrizes espanholas, baseadas em recomendações da Associação Espanhola de Pediatria aponta que doses únicas de pomada oftálmica de eritromicina a 0,5%, tetraciclina a 1% ou nitrato de prata a 1% são eficazes e comparáveis na profilaxia oftálmica do recém-nascido. A solução de nitrato de  
prata pode causar conjuntivites químicas transitórias no recém-nascido. 17.2.4.4.3 Recomendações sobre profilaxia da oftalmia neonatal  
201. A profilaxia da oftalmia neonatal deve ser realizada de rotina nos cuidados com o recém-nascido. 202. O tempo de administração da profilaxia da oftalmia neonatal pode ser ampliado em até 4 horas após o nascimento.  
203. Recomenda-se a utilização da pomada de eritromicina a 0,5% e, como alternativa, tetraciclina a 1% para realização da profilaxia da oftalmia neonatal. A utilização de nitrato de prata a 1% deve ser reservado apenas em caso de não se dispor de eritromicina ou tetraciclina.  
17.2.4.5 Profilaxia da doença hemorrágica do recém-nascido  
17.2.4.5.1 Introdução  
A Doença Hemorrágica por Deficiência de Vitamina K (DHVK) pode se apresentar em uma de 3 maneiras: início precoce dentro das primeiras 24 horas após o nascimento; doença clássica, dentro da primeira semana após o nascimento e tipicamente se manifestando por sangramento oral, umbilical, retal ou na circuncisão; início tardio, após a primeira semana após o nascimento, quase que exclusivamente em crianças amamentadas. As evidências disponíveis indicam que a profilaxia com vitamina K é efetiva e reduz a mortalidade e morbidades relacionadas à DHDVK<sup>433</sup> .Entretanto, os riscos e benefícios da profilaxia devem ser analisados à luz das evidências.  
17.2.4.5.1 Evidências científicas  
As diretrizes NICE 2014 remetem às diretrizes de 2006 – Postnatal Care: Routine Postnatal Care of Women and Their Babies<sup>389</sup> . Nestas diretrizes vários estudos são analisados, avaliando os riscos e benefícios da profilaxia da DHDVK, em diferentes dosagens, momentos e vias de administração. Em estudo caso controle de 19 casos de câncer infantil e 8 controles publicado em 1992, foi descrita uma associação entre o câncer infantil e a administração de vitamina K intramuscular<sup>434</sup> . Houve uma associação significativa (p=0,002) com o uso intramuscular da vitamina K (OR 1,97 IC 1,3-3,0) quando comparado com administração oral ou nenhuma profilaxia. No entanto, trabalhos realizados por outros investigadores e peritos do Reino Unido concluíram que com os dados disponíveis não era possível se associar o câncer infantil, incluindo a leucemia, ao uso de vitamina K IM. Um relatório publicado em 2002<sup>435</sup> realizou uma análise combinada de 2.431 crianças com câncer infantil comparadas com 6.338 controles e afirmaram que tumores sólidos não eram mais comuns em crianças que receberam vitamina K IM ao nascimento. Em relação à leucemia, os resultados foram menos claros pois praticamente todos os recém-nascidos receberam alguma forma de profilaxia com vitamina K, o que dificultou as conclusões finais. Foi detectado um pequeno aumento no risco (OR=1,25 -CI 1,06-1,46) mas que poderia ser devido a problemas de seleção de amostragem de grupos que já tinham um risco aumentado, de causa desconhecida, para essa doença.  
Outro grande estudo, o United Kingdom Childhood Cancer Study (UKCCS) reunindo 7.017 crianças (1.174 com leucemia) não encontrou associação entre vitamina K IM e qualquer tipo de câncer, com OR para leucemia diagnosticada entre 12 e 71 meses de idade de 0,98 (IC 0,79-1,22)<sup>436</sup> . Os autores concluem que apenas o acaso foi a explicação para os achados iniciais relacionando a vitamina K IM e câncer na infância. Somente um estudo controlado poderia resolver esta dúvida, mas esses trabalhos não seriam eticamente possíveis.  
Uma revisão sistemática da Cochrane<sup>437</sup> avaliou 11 ERCs comparando índices bioquímicos de avaliação da coagulação entre os modos oral e intramuscular da administração da vitamina K. Uma dose única oral comparada com uma dose única IM resultou em níveis plasmáticos menores de vitamina K com 2  
semanas e um mês enquanto que o esquema de 3 doses via oral resultou em níveis maiores de vitamina K com 2 semanas e 2 meses que a dose única IM. Um estudo realizado no norte da Inglaterra, entre 1993 e 1998<sup>438</sup> tratou, ao nascimento, 182.000 crianças saudáveis com 1 mg de uma preparação oral de vitamina K (Orakay). As crianças em que se julgou serem de maior risco (13.472) receberam 0,1 mg/kg IM de vitamina K ao nascimento. Independentemente do tratamento ao nascimento, houve recomendação aos pais das crianças amamentadas que deveriam dar a elas 3 cápsulas de 1 mg de Orokay e foi recomendado que o conteúdo de cada cápsula fosse administrada em intervalos de quinze dias após a alta. Nenhuma das crianças tratadas com Orokay apresentou qualquer sinal sugestivo de doença hemorrágica por deficiência de vitamina K nos primeiros 7 dias de vida. Ocorreram 4 casos documentados de doença hemorrágica tardia por deficiência de vitamina K. Duas crianças tinham deficiência de alfa-1-antitripsina subjacente e as mães das duas outras crianças não receberam as instruções ou as cápsulas para a profilaxia. Um inquérito postal de 458 mães (taxa de resposta de 61) e entrevista com 173 mães selecionadas aleatoriamente indicaram, ambos, que 93% das crianças que ainda continuavam a ser amamentadas receberam as 4 doses como o recomendado e que 98% receberam pelo menos 3 doses.  
A via intramuscular foi a via mais comum de administração de vitamina K até o relato de  Golding et al.<sup>434</sup> que associou o uso IM com câncer infantil. Subsequentemente, A British Paediatric Association – Sociedade Britânica de Pediatria – atualmente denominada Royal College of Paediatrics and Child Health recomenda que as crianças que são amamentadas devem receber suplementação de vitamina K oral com várias doses.  
Como não havia incerteza sobre a dosagem ideal, os esquemas de administração na Grã-Bretanha tornaram-se bastante variados. Além disso, alguns problemas inerentes com a administração oral, os quais potencialmente comprometem a efetividade, foram identificados. Esses incluem:  
Aderência: várias doses de vitamina K oral foram por várias semanas. Um hospital em Londres fez um acompanhamento de mães em junho de 1993 para avaliar a nova política da prescrição de três doses de 0,5 mg de vitamina K para crianças amamentadas. A pesquisa (n = 207) apresentou uma taxa de adesão de 99% para a primeira dose, 88% para a segunda em uma semana de vida e de 39% para as doses entre 3 e 6 semanas<sup>439</sup>  
Absorção: Há uma falta de confiabilidade em potencial na absorção de vitamina K oral, por exemplo, relacionadas à problemas na variabilidade na absorção ou regurgitação. Em dezembro de 1992, os Colégios Australianos de Pediatria e de Ginecologia e Obstetrícia - Australian College of Paediatrics e the Royal Australian College of Obstetricians and Gynaecologists recomendou substituir a dose de vitamina K IM por três doses orais de 1 mg cada. No entanto, a decisão foi revogada em 1994 devido ao aumento da incidência de DHDVK, assim, enfatizando a eficácia de um esquema da profilaxia por via IM.  
Em vários países europeus, os esquemas de administração oral de vitamina K foram iniciados por conta do estudo de Golding et al<sup>434</sup> . Os estudos de vigilância da forma tardia da DHDVK (ocorrendo entre os dias 8-84 de vida) nos países que adotaram a terapia oral estão indicados a seguir:  
1. 325.000 recém-nascidos receberam 1 mg de vitamina K IM ao nascimento: 0 casos de DHDVK.  
2. 1.200.000 recém-nascidos na Alemanha receberam 1 mg de vitamina K via oral ao nascimento e duas doses adicionais de 1 mg entre os dias 4-10 e 28-42 dias: 32 casos de DHDVK tardia (2,7 por 100.000). 3. 800.000 recém-nascidos na Alemanha receberam 2 mg de vitamina K via oral ao nascimento e duas doses adicionais de 2 mg entre os dias 4-10 e 28-42 dias: 7 casos de DHDVK tardia (0,9 por 100.000). 4. 325.000 recém-nascidos na Austrália receberam três doses de 1 mg via oral de vitamina K no  
nascimento e novamente entre os dias 3-5 e 21-28 dias: 8 casos de DHDVK tardia (2,5 por 100.000). 5. 83.000 recém-nascidos na Suíça receberam 2 mg via oral de uma preparação mista micelar de vitamina K (Konakion MM – melhor absorvido e produz maiores níveis plasmáticos do que a preparação oral padrão), nos dias 1 e 4: 4 casos de DHDVK tardia (4,8 por 100.000).  
6. 439.000 recém-nascidos na Holanda receberam 1 mg via oral de vitamina K ao nascimento e 25 microgramas por dia de semana por 13 semanas: 5 casos DHDVK tardia  (2 não receberam a profilaxia como recomendado e três tinham "doença predisponente" e não receberam vitamina K, à qual teria sido apropriada): (1 por 100.000).  
7. 396 mil recém-nascidos na Dinamarca receberam 1 mg via oral de vitamina K ao nascimento e 1 mg semanal: 0 casos de DHDVK<sup>440</sup>  
8. A eficácia de três doses orais de 2 mg com Konakion MM permanece a ser estabelecida (von Kries 1999)  
17.2.4.5.2 Resumo da Evidência e conclusões  
As evidências disponíveis indicam que a profilaxia com vitamina K é efetiva e reduz a mortalidade e morbidades relacionadas à DHDVK. em relação às doses, momento e vias de administração, a via IM é mais eficaz, tendo em vista os problemas relacionados à aderência e absorção da via oral. Entretanto ambas podem ser consideradas, desde que todas as doses do esquema oral sejam realmente administradas.  
17.2.4.5.3 Outras considerações  
Nas diretrizes do NICE, a orientação atual do Departamento de Saúde (DH) continua a aconselhar que todos os recém-nascidos recebam um esquema de vitamina K apropriado para evitar a rara, porém grave e por vezes fatal, DHDVK.  
As recomendações estabelecem que a vitamina K pode ser dada em uma dose única de 1 mg IM. O esquema oral de vitamina K, por outro lado, deve ser repetido. Acompanhamento próximo local deve ser seguido para garantir que todas as doses orais recomendadas sejam dadas no momentos apropriados. As doses de vitamina K realizadas ao nascer ou logo após devem ser suficientes para crianças alimentadas com fórmula. Crianças amamentadas necessitam de doses adicionais de vitamina K. Konakion MM é licenciado no Reino Unido para uso oral em duas doses de 2 mg a serem feitas na primeira semana de vida para todas os recém-nascidos e, para crianças amamentadas exclusivamente, uma terceira dose de 2 mg deve ser dada com um mês de idade. Konakion MM é formulado em ampolas de vidro e atualmente é  necessário que um profissional de saúde administre a dose<sup>441</sup> . Orokay não está mais licenciada no Reino Unido.  
Em relação aos benefícios para a saúde e utilização de recursos será apresentada aqui análise de custo realizada no Reino Unido e constantes das diretrizes-fonte desta adaptação. Existem dois principais custos associados com a administração de vitamina K em recém-nascidos. O primeiro é o custo do medicamento e o segundo é o custo do profissional de saúde necessário (para certas situações) para administrá-la. Neste caso, questões relacionadas com efetividade são de menor importância do que aqueles relacionados com o custo. A primeira razão é que a Doença Hemorrágica por Deficiência de Vitamina K (DHDVK) é altamente incomum entre as crianças que receberam a administração bem sucedida de vitamina K (ambos os esquemas por via oral ou IM terão um resultado similar). A segunda é que o tratamento intramuscular é geralmente considerado como mais provável de eliminar a ameaça da doença do que o esquema oral. Uma vez que esta abordagem de custos irá mostrar um nível de custo mais baixo para a abordagem IM, a inclusão da efetividade só irá acentuar as vantagens da estratégia de

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: aplicação IM. -->
A comparação realizada aqui é do custo de um esquema de uso de Konakion MM contra um esquema IM da mesma substância. O Orokay é uma alternativa futura mas ainda não licenciado. Orientações gerais sobre o efeito de introduzir o Orokay nos aspectos de custo efetividade serão delineados posteriormente.  
Outra questão importante é a ligação sugerida entre profilaxia com vitamina K IM e leucemia infantil. Exceto o estudo de Bristol<sup>434</sup> há um amplo consenso de que nenhuma ligação sólida tenha sido estabelecida. Portanto, este ponto de vista foi seguido.  
O esquema por via oral que parece ser predominante é uma série de três doses de 2 mg, uma ao nascimento, uma dentro da primeira semana e depois ao redor de um mês para crianças amamentadas uma vez que eles não recebem a vitamina K suplementada na fórmula láctea. Isto contrasta com a via IM que requer uma dose de 1 mg logo após o nascimento. O custo de uma dose oral de Konakion MM Pediatric é de 1,00 libra esterlina (abril de 2006), enquanto a opção intramuscular (Konakion Neonatal) custa 21 pounds de libra.  No dia 31 de março de 2006, Konakion Neonatal foi descontinuado. Assim, são relatados os resultados da análise para a opção intramuscular alternativa, especificamente Konakion MM Pediatric. Assim,  
O custo da substância no esquema por via oral é, portanto, de £ 2,00  ou 3,00 dependendo se a criança é amamentada. Assim o custo total da substância é (£ 2,00 X (1-taxa de amamentação x 640.000) + (£ 3,00 x taxa de amamentação X 640.000).  Assumindo uma taxa de amamentação de 50%, isto significará um custo total da substância de £ 1,6 milhão. Em março de 2006, a via IM custava £ 1,00 por criança. Isto é baseado no pressuposto que a segunda metade de cada frasco de 2 mg é desperdiçado. Assim, a implementação total desta estratégia iria custar £ 640.000 (o custo da susbtância é o custo total). Considerou-se que a não utilização da segunda metade do frasco representa a melhor prática atual. A suposição feita do ponto de vista de custos foi a de que a administração IM e a primeira e segunda doses oral foram efetivamente sem custos, uma vez que pode estar ligados com outras visitas rotineiras do profissional de saúde (no hospital ou não).  
Para as crianças amamentadas, essa suposição de ausência de custo de provisão foi de menor certeza quando a terceira dose é o estágio posterior. Parece que a estratégia na Inglaterra e País de Gales para administrar esta terceira dose é bastante heterogênea. É o caso de um profissional de saúde que iria até  
a criança para administrá-la (o visitador domiciliar no caso). Os valores de custo para isto foram tomados de Curtis e Netten, Unit Costs of Health and Social Care 2004<sup>442</sup>  
O custo anual total de um visitador de saúde domiciliar (salários mais contribuições) foi calculado e dividido pela jornada de trabalho sugerida (37,5 hora multiplicado por 42 semanas) para fornecer um custo por hora. Assumindo que a viagem leva meia hora e adicionando o custo da viagem (retirado da mesma fonte), isto resulta em um total de £ 11,86 por visita. Os custos não relacionados ao esquema de Konakion MM oral foram assim calculadas, £ 11,86 x taxa de amamentação x 640.000. Se usarmos o pressuposto anterior de uma taxa de amamentação de 50%, isso significa um custo não relacionado à substância de £ 3.795.000. Se o responsável pela criança administra a terceira dose, este custo seria eliminado mas outros custos seriam incorporados incorridos até pelo aparecimento de casos de DHDVK decorrentes da não adesão ao tratamento.  
A soma destes produz um custo de um esquema por via oral de Konakion MM de £ 1.600.000 (5.395.000 £ se a terceira dose é administrada pelo profissional de saúde) e um custo do esquema por via IM de 640.000 libras esterlinas.  
A opção mais frequentemente citada como uma alternativa a estas duas abordagens é Orakay. Atualmente, ele está sem licença de uso. Portanto, ele só pode ser recomendado apenas se a evidência clínica e a relação de custo efetividade fale em seu favor. Se, e quando, Orakay for licenciado, o efeito seria de baixar o custo da abordagem oral (uma vez que o custo é de cerca 31,7 pounds de libra por dose). Se Orakay for recomendado para ser administrado pelos pais, seria necessário repetir a análise considerando uma taxa de não adesão. É importante notar que uma recomendação para Orakay baseada em critérios de custo efetividade necessariamente requereriam significativamente melhores desfechos clínicos do que a abordagem intramuscular ou reduzir os custos. No momento, as evidências sugerem que nenhuma é comprovada.  
Em resumo, do ponto de vista de custo, um esquema de profilaxia com vitamina K IM é menos caro do que o esquema por via oral licenciado. Os respectivos custos anuais são £ 640.000 e £ 1.6 milhões. Se forem analisados o ponto de vista sobre a falta de uma ligação entre a profilaxia IM e leucemia infantil, o que acrescenta uma medida de efeito para essa análise, fará a profilaxia IM relativamente mais custo efetiva comparado com a sua alternativa oral.  
Se Orakay for incluído nos cálculos, as evidências de custo efetividade relacionado à administração IM é incerta, mas é possível que seja preferido ao esquema de Konakion MM oral devido a um menor nível de custos.  
17.2.4.5.4 Considerações em relação ao Brasil  
Levando em conta a análise de custo realizada pelos desenvolvedores das diretrizes do NICE (Postnatal Care: Routine Postnatal Care of Women and Their Babies), o grupo elaborador destas Diretrizes adaptadas concluiu que as análises de custo realizadas no Reino Unido também podem ser aplicadas ao Brasil, embora em proporções diferentes. Há de se considerar também que no Brasil, a aderência ao tratamento oral seria mais prejudicada do que no Reino Unido, principalmente em relação às doses subsequentes, tendo em vista a organização do sistema público de saúde e a distribuição e múltiplas tarefas das equipes de saúde da família, que a princípio seriam responsáveis pela administração da substância após a alta do recém-nascido. Diante disso, em relação aos benefícios para a saúde e uso de recursos no Brasil, principlamente no sistema público de saúde, a administração de vitamina K em uma única dose de 1 mg IM logo após o nascimento é a melhor opção. No Brasil a vitamina K também é comercializada em ampolas de vidro contendo uma solução de micelas mistas com 2 mg de vitamina K1 em 0,2 mL, para uso endovenoso, intramuscular e oral.  
17.2.4.5.5 Recomendações em relação à profilaxia da doença hemorrágica do recém-nascido  
204. Todos os recém-nascidos devem receber vitamina K para a profilaxia da doença hemorrágica.  
205. A vitamina K deve ser administrada por via intramuscular, na dose única de 1 mg, pois este método apresenta a melhor relação de custo-efetividade.  
206. Se os pais recusarem a administração intramuscular, deve ser oferecida a administração oral da vitamina K e eles devem ser advertidos que este método deve seguir as recomendações do fabricante e exige múltiplas doses.  
207. A dose oral é de 2 mg ao nascimento ou logo após, seguida por uma dose de 2 mg entre o quarto e o sétimo dia.  
208. Para recém-nascidos em aleitamento materno exclusivo, em adição às recomendações para todos os neonatos, uma dose de 2 mg via oral deve ser administrada após 4 a 7 semanas, por causa dos níveis variáveis e baixos da vitamina K no leite materno e a inadequada produção endógena.  
17.2.5 Ressuscitação neonatal

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.5.1 Questões de revisão -->
- Qual a efetividade da aspiração nasofaringeana, intubação e sondagem gástrica e retal de rotina do recém-nascido com líquido meconial no pós parto imediato?  
- Como as diferentes técnicas básicas de ressuscitação neonatal influencia nos resultados?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 17.2.5.2 Evidências Científicas -->
As diretrizes do NICE abordam esses tópicos em relação aos cuidado de recém-nascidos com líquido amniótico meconial, incluindo duas intervenções, a aspiração nasofaringeana e a intubação. Também avaliam a utilização de oxigênio ou ar ambiente diante da necessidade de manobras de ressuscitação neonatal. Nenhuma das diretrizes-fonte avaliaram a utilização de sondagem gástrica e retal de rotina em recém-nascidos com líquido meconial logo após o nascimento. Outras técnicas de ressuscitação neonatal também não foram avaliadas por nenhuma das diretrizes-fonte desta adaptação.  
17.2.5.2.1 Aspiração nasofaringeana em recém-nascidos com líquido meconial  
Um grande ERC multicêntrico conduzido na Argentina (11 centros) e nos EUA (1 centro) incluindo 2.514 recém-nascidos, publicado em 2004<sup>443</sup> [NE = 1+ comparou uma política de sucção da orofaringe antes do desprendimento dos ombros com uma política de não sucção. Não foram encontradas diferenças na incidência de morte neonatal (todos os RNs, RR 2,23 [IC 95% 0,69 a 7,22], RNs com mecônio não significativo (‘fluido’ ou ‘moderado’) (RR 3,90 [0,44 a 34,83] RNs com mecônio significativo (espesso) (RR 1,85 [IC 95% 0,45 a 7,63]); síndrome de aspiração meconial (todos os RNs RR 1,1 [IC 95% 0,74 a 1,61], RNs com mecônio não significativo (‘fluido’ ou ‘moderado’) RR 1,22 [IC 95% 0,72 a 2,07], RNs com mecônio significativo (espesso) (RR 1,06 [IC 95% 0,62 a 1,83]); ventilação mecânica por síndrome de aspiração meconial (todos os RNs RR 1,32 [IC 95% 0,72 a 2,42], RNs com mecônio não significativo (‘fluido’ ou ‘moderado’) (RR 1,36 [0,61 a 3,06] RNs com mecônio significativo (‘espesso’) (RR 1,39 [IC 95% 0,56 a 3,43]); necessidade de intubação, sucção ou ventilação com pressão positiva na sala de parto (RR 0,93 [IC 95% 0,72 a 1,2]); outras doenças respiratórias (RR 0,76 [IC 95% 0,55 a 1,06]); pneumotórax (RR 0,99 [IC 95% 0,2 a 4,9]); duração do tratamento com oxigênio em dias (DM 0,6 mais [de 2,54 menos a 3,74 mais]); duração da ventilação mecânica em dias (DM 0,9 mais (de 2,29 menos a 4,09 mais) e duração dos cuidados hospitalares em dias (DM 0,8 menos (de 4,72 menos a 3,12 mais).  
17.2.5.2.2 Intubação em recém-nascidos com líquido meconial  
As diretrizes do NICE incluíram em sua revisão 4 ERCs que compararam uma política de intubação de rotina com uma de nenhuma intubação<sup>444-446</sup> e um que comparou intubação de rotina com intubação apenas quando indicada<sup>447</sup> . Os resultados são descritos na tabela 43  
Tabela 42 – Comparação entre intubação de rotina com nenhuma intubação ou intubação seletiva em recém-nascidos com líquido meconial  
|Estudos|Número de|recém-nascidos|Ef|eito|
|---|---|---|---|---|
||Intubação|Nenhuma ou<br>intubação<br>seletiva|Relativo (IC 95%)|Absoluto (IC 95%)|
|Mortalidade Neona|tal||||
|Todos os Recém-N|ascidos||||
|1 meta-análise de<br>3 ERCs<sup>444,446,447</sup>|3/1.385<br>(0,22%)|3/1.330<br>(0,23%)|RR 0,96<br>(0,22 a 4,25)|0 menos/1.000<br>(de 2 menos a 7<br>mais)|
|RNs com mecônio|não significativ|o(‘fluido’)|||  
Tabela 42 – Comparação entre intubação de rotina com nenhuma intubação ou intubação seletiva em recém-nascidos com líquido meconial  
|Estudos|Número de r|ecém-nascidos|Ef|eito|
|---|---|---|---|---|
||Intubação|Nenhuma ou<br>intubação<br>seletiva|Relativo (IC 95%)|Absoluto (IC 95%)|
|0<br>RNs com mecônio<br>0|Nenhuma evid<br>não significativo<br>Nenhuma evid|ência disponível<br> (‘moderado’)<br>ência disponível|||
|RNs com mecônio s|ignificativo(‘es|pesso’)|||
|1 ERC<sup>444</sup>|1/26|0/23|RR 2,67|NC|
||(3,8%)|(0%)|(0,11 62,42)||
|Síndrome de aspira|ção meconial||||
|Todos os RNs|||||
|1 meta-análise de<br>2 ERCs<sup>446,447</sup>|38/1.359<br>(2,8%)|28/1.307<br>(2,1%)|RR 1,33<br>(0,82 a 2,14)|7 mais/1.000<br>(de 4 menos a 24|
|||||mais)|
|RNs com mecônio|não significativo|(‘fluido’)|||
|1 ERC<sup>447</sup>|5/447<br>(1,1%)|2/453<br>(0,44%)|RR 2,53<br>(0,49 a 12,99)|7 mais/1.000<br>(de 2 menos a 53|
|||||mais)|
|RNs com mecônio|não significativo|(‘moderado’)|||
|1 ERC|7/301|6/307|RR 1,19|4 mais/1.000|
|(Wiswell et al.,|(2,3%)|(2%)|(0,4 a 3,5)|(de 12 menos a 49|
|2000)||||mais)|
|RNs com mecônio s|ignificativo(‘es|pesso’)|||
|1 ERC<sup>447</sup>|22/303<br>(7,3%)|20/283<br>(7,1%)|RR 1,03<br>(0,57 a 1.84)|2 mais/1.000<br>(de 30 menos a 59|
|||||mais)|
|Outros sintomas re|spiratórios||||
|Todos os RNs|||||
|1 meta-análise de<br>2 ERCs<sup>445,447</sup>|42/1.128<br>(3,7%)|48/1.135<br>(4,2%)|RR 0,87<br>(0,58 a 1,31)|5 menos/1.000<br>(de 18 menos a 13|
|||||mais)|
|RNs com mecônio|não significativo|(‘fluido’)|||
|1 meta-análise de|8/524|9/545|RR 0,93|1 menos/1.000|
|2 ERCs<sup>445,447</sup>|(1,5%)|(1,7%)|(0,36 a 2,37)|(de 11 menos a 23|
|||||mais)|
|RNs com mecônio|não significativo|(‘moderado’)|||
|1 ERC<sup>447</sup>|10/301|15/307|RR 0,68|16 menos/1.000|
||(3,3%)|(4,9%)|(0,31 a 1,49)|(de 34 menos a 24<br>mais)|  
RNs com mecônio significativo (‘espesso’)  
Tabela 42 – Comparação entre intubação de rotina com nenhuma intubação ou intubação seletiva em recém-nascidos com líquido meconial  
|Estudos|Número de|recém-nascidos|Ef|eito|
|---|---|---|---|---|
||Intubação|Nenhuma ou<br>intubação<br>seletiva|Relativo (IC 95%)|Absoluto (IC 95%)|
|1 ERC<sup>447</sup>|24/303<br>(7,9%)|24/283<br>(8,5%)|RR 0,93<br>(0,54 a 1,61)|6 menos/1.000<br>(de 39 menos a 52|
|||||mais)|
|Encefalopatia hipó|xico-isquêmica||||
|Todos os Recém-N|ascidos||||
|1 ERC<sup>444</sup>|1/26|0/23|RR 2,67|NC|
||(3,8%)|(0%)|(0,11 a 62,42)||
|RNs com mecônio|não significati|vo(‘fluido’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|não significati|vo(‘moderado’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|significativo(‘|espesso’)|||
|1 ERC<sup>444</sup>|1/26|0/23|RR 2,67|NC|
||(3,8%)|(0%)|(0,11 62,42)||
|Estridor|||||
|Todos os Recém-N<br>|ascidos||||
|1 ERC<sup>446</sup>|2/308|0/264|RR 4,29|NC|
||(0,65%)|(0%)|(0,21 a 88,92)||
|RNs com mecônio|não significati|vo(‘fluido’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|não significati|vo(‘moderado’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|significativo(‘|espesso’)|||
|0|Nenhuma ev|idência disponível|||
|Pneumotórax<sup>a</sup>|||||
|Todos os Recém-N|ascidos||||
|1 meta-análise de|2/334|2/287|RR 0,87|1 menos/1.000|
|2 ERCs<sup>444,446</sup>|(0,6%)|(0,7%)|(0,16 a 4,92)|(de 6 menos a 27|
|||||mais)|
|RNs com mecônio|não significati|vo(‘fluido’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|não significati|vo(‘moderado’)|||
|0|Nenhuma ev|idência disponível|||
|RNs com mecônio|significativo(‘|espesso’)|||
|1 ERC<sup>444</sup>|1/26|2/23|RR 0,44|49 menos/1.000|
||(3,8%)|(8,7%)|(0,04 a 4,56)|(de 83 menos a|  
Tabela 42 – Comparação entre intubação de rotina com nenhuma intubação ou intubação seletiva em recém-nascidos com líquido meconial  
|Estudos|Número de|recém-nascidos|E|feito|
|---|---|---|---|---|
||Intubação|Nenhuma ou<br>intubação<br>seletiva|Relativo (IC 95%)|Absoluto (IC 95%)|
|||||310 mais)|
|Uso de oxigenação|membranosa|extracorpórea|||
|Todos os Recém-N|ascidos||||
|1 ERC<sup>447</sup>|1/1.051<br>(0,1%)|1/1.043<br>(0,1%)|RR 0,99<br>(0,06 a 15,84)|0 menos/1.000<br>(de 1 menos a 14|
|||||mais)|
|RNs com mecônio|não significativ|o(‘fluido’)|||
|0|Nenhuma evi|dência disponível|||
|RNs com mecônio|não significativ|o(‘moderado’)|||
|0|Nenhuma evi|dência disponível|||
|RNs com mecônio|significativo(‘e|spesso’)|||
|0|Nenhuma evi|dência disponível|||
|Uso de oxigênio su|plementar||||
|Todos os Recém-N|ascidos||||
|1 meta-análise de|5/385|0/356|RR 5,82|NC|
|2 ERCs<sup>445,446</sup>|(1,3%)|(0%)|(0,68 a 49,93)||
|RNs com mecônio|não significativ|o(‘fluido’)|||
|1 ERC<sup>445</sup>|1/77|0/92|RR 3,58|NC|
||(13%)|(0%)|(015 a 8657)||
|RNs com mecônio|,<br>não significativ|o(‘moderado’)|, ,||
|0|Nenhuma evi|dência disponível|||
|RNs com mecônio|significativo(‘e|spesso’)|||
|0|Nenhuma evi|dência disponível|||
|Administração de o|xigênioporpe|lo menos 4 dias<sup>b</sup>|||
|Todos os Recém-N|ascidos||||
|1 ERC<sup>444</sup>|12/26|12/23|RR 0,88|63 menos/1.000|
||(46,2%)|(52,2%)|(0,5 a 1,57)|(de 261 menos a|
|||||297 mais)|
|RNs com mecônio|não significativ|o(‘fluido’)|||
|1 ERC<sup>445</sup>|1/77|0/92|RR 3,58|NC|
||(13%)|(0%)|(015 a 8657)||
|RNs com mecônio|,<br>não significativ|o(‘moderado’)|, ,||
|0|Nenhuma evi|dência disponível|||
|RNs com mecônio|significativo(‘e|spesso’)|||
|1 ERC<sup>444</sup>|12/26|12/23|RR 0,88|63 menos/1.000|
||(46,2%)|(52,2%)|(0,5 a 1,57)|(de 261 menos a|  
Tabela 42 – Comparação entre intubação de rotina com nenhuma intubação ou intubação seletiva em recém-nascidos com líquido meconial  
|Estudos|Número de|recém-nascidos|Ef|eito|
|---|---|---|---|---|
||Intubação|Nenhuma ou<br>intubação<br>seletiva|Relativo (IC 95%)|Absoluto (IC 95%)|
|||||297 mais)|  
IC intervalo de confiança, NC não calculável, RR risco relativo  
a. Análise de sensibilidade removendo Daga et al. (1994) muda a direção, embora não significativa, do efeito. O risco relativo torna-se 2,57 (IC 95%  0,11 a 62,89)  
b. Devido à maneira em que os dados são relatados (recém-nascidos que necessitam oxigênio por 0-3 dias; recém-nascidos que necessitam oxigênio por pelo menos 4 dias) não é possível calcular a proporção de recém-nascidos necessitando oxigênio no sentido de meta-analisá-los com os dados relatados por outros estudos.  
17.2.5.2.3 Oxigênio versus ar ambiente para ressuscitação neonatal  
As diretrizes do NICE incluíram 7 ERCs – 6 deles foram ensaios conduzidos na Espanha<sup>448-450</sup> e Índia<sup>451-453</sup> em centros isolados. O sétimo estudo foi um ensaio multicêntrico<sup>454</sup> com um seguimento de 18-24 meses<sup>455</sup> . Os estudos compararam o uso de ar ambiente (oxigênio a 21%) com oxigênio a 100% para a ressuscitação inicial de recém-nascidos. Foram incluídos nos estudos tanto recém-nascidos a termo como prematuros, assim como recém-nascidos de baixo e alto risco de desenvolver complicações. Os resultados são apresentados na tabela 44.  
Tabela 43 – Comparação entre ar ambiente e oxigênio para ressuscitação neonatal  
|Estudos|Número de r|ecém-nascidos|Ef|eito|
|---|---|---|---|---|
||Ar ambiente|Oxigênio 100%|Relativo(IC 95%)|Absoluto(IC 95%)|
|Mortalidade Neona|tal: Geral<sup>a</sup>||||
|1 meta-análise de|88/664|126/703|RR 0,74|47 menos/1.000|
|5 ERCs<sup>450-453,455</sup><br>Mortalidade Neona|(13,3%)<br>tal: relacionada|(17,9%)<br>a asfixia<sup>a</sup>|(0,58 a 0,95)|(de 9 menos a 75<br>menos)|
|1 meta-análise de<br>3 ERCs<sup>451-453</sup>|32/359<br>(8,9%)|42/360<br>(11,7%)|RR 0,77<br>(0,5 a 1,19)|27 menos/1.000<br>(de 58 menos a 22|
|||||mais)|
|Encefalopatia hipóx|ico-isquêmica(|EHI):qualquer|||
|1 meta-análise de<br>4 ERCs<sup>451-453,455</sup><br>EHI:grau II ou III<sup>b</sup>|162/647<br>(25%)|173/681<br>(25,4%)|RR 0,97<br>(0,81 a 1,16)|8 menos/1.000<br>(de 48 menos a 41<br>mais)|
|1 meta-análise de|80/437|81/460|RR 1,02|4 mais/1.000|
|3 ERCs<sup>451,452,455</sup>|(18,3%)|(17,6%)|(0,78 a 1,35)|(de 39 menos a 62<br>mais)|
|1 ERC<sup>451</sup>|17,2%<br>(dados crús|24,7%<br>(dados crús|NC|75 menos/1.000<br>(IC NC)|  
Tabela 43 – Comparação entre ar ambiente e oxigênio para ressuscitação neonatal  
|Estudos|Número de|recém-nascidos|Ef|eito|
|---|---|---|---|---|
||Ar ambiente|<br>Oxigênio 100%|Relativo(IC 95%)|Absoluto(IC 95%)|
||NR)|NR)|||
|Exame neurológico<br>|anormal(seg <br>|uimento de curtop<br>|razo)<sup>c</sup>||
|1 meta-análise de|22/117|16/122|RR 1,44|58 mais/1.000|
|2 ERCs<sup>451,452</sup>|(18,8%)|(13,1%)|(0,8 a 2,6)|(de 26 menos a|
|Paralisia cerebral(s|eguimento de|18-24 meses)||210 mais)|
|1 ERC<sup>454</sup>|9/91<br>(9,9%)|8/122<br>(6,6%)<sup>d</sup>|RR 1,51<br>(0,61 a 3,76)|33 mais/1.000<br>(de 26 menos a|
|Desenvolvimento a|normalgeral(|seguimento de 18-|24 meses)<sup>e</sup>|181 mais)|
|1 ERC<sup>454</sup>|14/91<br>(15,4%)|12/122<br>(9,8%)|RR 1,56<br>(0,76 a 3,22)|55 mais/1.000<br>(de 24 menos a|
|Desenvolvimento a|normal: nãop|uxarpara cima aos|18-24 meses|218 mais)|
|1 ERC<sup>454</sup>|12/91<br>(13,2%)|10/122<br>(8,2%)|RR 1,61<br>(0,73 a 3,56)|50 mais/1.000<br>(de 22 menos a|
|Desenvolvimento a|<br>normal: sem f|<br>alar aos 18-24 mes|<br>es|<br>210 mais)|
|1 ERC<sup>454</sup>|6/91<br>|3/122<br>|RR 2,68<br>|41 mais/1.000<br>|
||(6,6%)|(2,5%)|(0,69 a 10,44)|(de 8 menos a 232|
|Falha na ressuscita|ção(incluindo|troca degás)<sup>f</sup>||mais)|
|1 meta-análise de|165/662|181/676|RR 0,95|13 menos/1.000|
|5 ERCs<sup>450,451-453,455</sup>|(24,9%)|(26,8%)|(0,8 a 1,13)|(de 54 menos a 35|
|Intervenções adicio<br>|nais: compres|sões torácicas||mais)|
|1 ERC<sup>451</sup>|7/107<br>(6,5%)|9/97<br>(9,3%)|RR 0,71<br>(0,27 a 1,82)|27 menos/1.000<br>(de 68 menos a 76|
|||||mais)|
|Intervenções adicio|nais: uso de a|drenalina|||
|1 ERC<sup>451</sup>|2/107|3/97|RR 0,6|12 menos/1.000|
||(1,9%)|(3,1%)|(0,1 a 3,54)|(de 28 menos a 79|
|Intervenções adicio|nais: intubaçã|o durante a ressus|citação|mais)|
|1 meta-análise de|59/149|37/139|RR 1,46|122 mais/1.000|
|2 ERCs<sup>451,452</sup>|(39,6%)|(26,6%)|(1,06 a 2,01)|(de 16 mais a 269|
|||||mais)|
|Frequência cardíac|a com 1 minut|o|||
|1 meta-análise de|n=605<sup>g</sup>|n=639<sup>g</sup>|NC|DM 2,74 mais alta|
|3 ERCs<sup>451,453,455</sup>||||(3,77 mais baixa a|  
Tabela 43 – Comparação entre ar ambiente e oxigênio para ressuscitação neonatal  
|Estudos|Número de r|ecém-nascidos|Ef|eito|
|---|---|---|---|---|
||Ar ambiente|Oxigênio 100%|Relativo(IC 95%)|Absoluto(IC 95%)|
|||||9,25 mais alta)|
|Frequência cardí|aca com 5 minuto<br>|s<br>|||
|1 meta-análise d|e<br>n=317<sup>h</sup>|n=318<sup>h</sup>|NC|DM 0,99 mais alta|
|2 ERCs<sup>451,453</sup>||||(1,43 mais baixa a|
|||||3,41 mais alta)|
|Escore de Apgar|aos 5 minutos||||
|Proporção de Re<br>|cém-Nascidos com|Apgar < 7|||
|1 ERC<sup>455</sup>|71/286<br>(24,8%)|102/321<br>(31,8%)|RR 0,78<br>(0,6 a 1,01)|70 menos/1.000<br>(de 127 menos a 3|
|||||<br>mais)|
|Média do escore|de Apgar||||
|1 ERC<sup>451</sup>|Média 6,8<br>(DP 2,0)<br>n=107|Média 7,1<br>(DP 1,6)<br>n=97|NC|DM 0,3 mais baixo<br>(0,79 mais baixo a<br>019 mais alto)|
|||||,<br>p=0,27|
|Mediana do esco|re de Apgar||||
|1 ERC<sup>448</sup>|Mediana 8<br>(percentil 5<sup>o</sup><br>– 95<sup>o</sup>: 7 - 9)|Mediana 7<br>(percentil 5<sup>o</sup>–<br>95<sup>o</sup>:5 - 8)|NC|Mediana 1 mais<br>alto<br>(IC NC)<br>não significativo<br>(valor depNR)|
|1 ERC<sup>452</sup>|Mediana 8<br>(percentil 25<sup>o</sup><br>– 75<sup>o</sup>: 7 - 9)|Mediana 7<br>(percentil 25<sup>o</sup><br>– 75<sup>o</sup>:6 - 8)|NC|Mediana 1 mais<br>alto<br>(IC NC)<br>p=0,19|
|1 ERC<sup>453</sup>|Mediana 7<br>(percentil 5<sup>o</sup><br>– 95<sup>o</sup>: 3 - 10)|Mediana 7<br>(percentil 5<sup>o</sup>–<br>95<sup>o</sup>:2 - 10)|NC|Mediana 0 mais<br>alto<br>(IC NC)<br>não significativo<br>(valor depNR)|
|1 ERC<sup>449</sup>|Mediana 6<br>(percentil 5<sup>o</sup><br>– 95<sup>o</sup>: 5 - 8)|Mediana 6<br>(percentil 5<sup>o</sup>–<br>95<sup>o</sup>:4 - 8)|NC|Mediana 0 mais<br>alto<br>(IC NC)<br>não significativo<br>(valor depNR)|
|1 ERC<sup>450</sup>|Mediana 5<br>(percentil 5<sup>o</sup><br>– 95<sup>o</sup>: 3 - 5)<sup>i</sup>|Mediana 4<br>(percentil 5<sup>o</sup>–<br>95<sup>o</sup>:3 - 5)<sup>i</sup>|NC|Mediana 1 mais<br>alto<br>(IC NC)<br>p< 0,05|  
IC intervalo de confiança, EHI Encefalopatia hipóxico-isquêmica, DM Diferença média, NC não calculável,

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: NR Não relatado, RR risco relativo, DP desvio padrão -->
a. Bajaj et al. (2005) relata morte antes da alta; Ramji et al. (1993) e Ramji et al. (2003)relata que as mortes ocorreram no primeira semana de vida; Saugstad et al. (1998) e Vento et al. (2005) relatam mortes nos primeiros 28 dias de vida.  
b.Taxas individuais de EHI graus II e III foram somadas pela equipe técnica do NCC-WCH para Ramji et al. (1993) e Ramji et al. (2003.)  
c. Bajaj et al. (2005) definiram exame neurológico anormal na alta como a necessidade de anticonvulsivantes, hipotonia, hipertonia, ou déficit visual/auditivo. Os autores relataram o denominador excluindo os recém-nascidos que morreram; entretanto, usando o denominador cheio dos recém-nascidos randomizados não afeta a direção ou significância do efeito (o risco relativo metaanalisado torna-se 1,29 [IC 95% 0,71 a 2,34]). Ramji et al. (1993)definiram neurologia anormal na primeira semana de vida com hipotonia, hipertonia, respostas reflexas inapropriadas para a gestação (Moro, sucção, rotação) ou convulsões  
d. Um recém-nascido adicional no grupo de oxigênio teve hemiparesia (seguindo a cápsula interna).  
e. Isso inclui recém-nascidos com paralisia cerebral, mais outros recém-nascidos com déficit motor grosseiro ou retardo mental.  
f. Bajaj et al. (2005) definiu falha no grupo de ar ambiente como tendo que mudar para oxigênio, mas não relatou como a falha no grupo de oxigênio foi definida. Ramji et al. (1993) relatou que os recémnascidos no grupo de ar ambiente que falharam na resposta e ficaram cianóticos ou bradicárdicos (< 100 bpm) após 90 segundos foram mudados para o oxigênio  (nenhum recém-nascido foi mudado do oxigênio). Ramji et al. (2003)relatou a proporção de recém-nascidos que permaneceram (< 100 bpm) ou cianóticos após 90 segundos – aqueles do grupo do ara ambiente foram trocados e aqueles do grupo de oxigênio foram registrados para comparabilidade. Em Saugstad et al. (1998)a falha do tratamento foi definida com uma FC < 80 bpm ou cianose central aos 90 segundos – aqueles no grupo de ar ambiente foram mudados para o oxigênio e aqueles do grupo de oxigênio fora registrados para comparabilidade. Vento et al. (2001) relatou o número de recém-nascidos que necessitaram mudar de uma gás para o outro.  
g. FC média (em bpm) com 1 minuto nos estudos individuais foram: Bajaj et al. (2003) – Ar ambiente: 113, Oxigênio 100%: 108; Ramji et al. (2003) – Ar ambiente: 94,4, Oxigênio 100%: 87,7; Saugstad et al. (1998) – Ar ambiente: 90, Oxigênio 100%: 93  
h. FC média (em bpm) aos 5 minutos nos estudos individuais foram: Bajaj et al. (2003) – Ar ambiente: 134, Oxigênio 100%: 132; Ramji et al. (2003) –Ar ambiente: 13,5, Oxigênio 100%: 131,1  
i. Isto é relatado como um desfecho no artigo; entretanto, os critérios de inclusão para este ensaio foram recém-nascidos gravemente asfixiados definido como palidez cutânea, bradicardia, não responsivo ao estímulo, pH de cordão ≤7,0  ao nascer e escore de Apgar 5 ou menos por mais que 5 minutos.  
17.2.5.2 Resumo da evidência e conclusões sobre ressuscitação neonatal  
Em relação à aspiração de recém-nascidos com líquido meconial antes do desprendimento dos ombros no parto, comparado com aqueles sem aspiração, um grande estudo bem conduzido controlado e randomizado (n = 2.514) não demonstrou diferenças na incidência de morte neonatal, síndrome de aspiração meconial, outras doenças respiratórias, necessidade de intubação, sucção ou ventilação com pressão positiva na sala de parto, uso de ventilação mecânica por síndrome de aspiração meconial e  
pneumotórax. Da mesma forma, quando se considera a duração do tratamento com oxigênio, ventilação mecânica e cuidados hospitalares entre os recém-nascidos com síndrome de aspiração de mecônio, não foi encontrada diferença entre os dois grupos.  
Em relação à intubação de rotina para recém-nascidos com líquido meconial, a evidência não demonstra nenhum benefício clínico para quaisquer dos desfechos considerados. Mesmo quando a análise de subgrupo foi realizada, incluindo os recém-nascidos com mecônio fluido e espesso, não foram encontradas diferenças.  
Em relação ao uso do ar ambiente comparado com o oxigênio a 100% para ressuscitação neonatal, a evidência demonstrou menores taxas de mortalidade neonatal com o uso do ar ambiente, com tendência similar para as mortes relacionadas à asfixia. Não foram encontradas diferenças para a encefalopatia hipóxico-isquêmica e desfechos neurológicos de curto e longo prazo. Em um dos estudos, mais recém-nascidos necessitaram de intubação no grupo de ar ambiente em relação ao grupo de oxigênio a 100% mas sem diferença em outras intervenções, tanto na falha do procedimento de ressuscitação quanto na necessidade de massagem cardíaca e uso de adrenalina. Também não foram encontradas diferenças na frequência cardíaca média com 1 e 5 minutos de vida. Em relação ao Apgar de 5 minutos os resultados foram mistos. Cinco ensaios não relataram diferenças mas, em dois a mediana do escore de Apgar foi maior no grupo de ar ambiente.  
17.2.5.3 Outras considerações  
Em relação aos benefícios clínicos e danos das intervenções analisadas, a aspiração rotineira antes do deprendimento dos ombros, assim como a intubação de recém-nascidos com mecônio, independente do tipo (fluido, moderado ou espesso) não confere qualquer benefício. Em relação à ressuscitação neonatal deve-se levar em consideração a redução significativa da mortalidade neonatal com o uso do ar ambiente para a resuscitação em comparação com o oxigênio a 100%. O aumento da necessidade de intubação com o uso de ar ambiente também deve ser considerada mas, em termos de magnitude de risco, considerando a mortalidade, os benefícios do uso do ar ambiente supera os riscos e o mesmo deve ser utilizado na ressuscitação neonatal ao invés do oxigênio a 100%.  
Em relação aos benefícios para a saúde e utilização de recursos no Brasil, o abandono da aspiração e intubação rotineira de recém nascidos com mecônio pode levar a uma economia de tempo dos profissionais responsáveis pela assistência ao recém-nascido em sala de parto. A utilização de ar ambiente, ao invés de oxigênio a 100%, para a ressuscitação neonatal pode trazer um economia importante de recursos, tendo em vista o custo do oxigênio.  
17.2.5.4 Recomendações sobre ressuscitação neonatal  
209. Ao nascimento, avaliar as condições do recém-nascido – especificamente a respiração, frequência cardíaca e tônus – no sentido de determinar se a ressuscitação é necessária de acordo com diretrizes reconhecidas de reanimação neonatal.  
210. Todos os profissionais que prestam cuidados diretos no nascimento devem ser treinados  
em reanimação neonatal de acordo com diretrizes reconhecidas de reanimação neonatal. 211. Em todas os locais de parto:  
- Planejar o cuidado e ter em mente que pode ser necessário chamar por ajuda se o recém-  
- nascido precisar de ressuscitação  
- Assegurar que existam recursos para ressuscitação e para transferência do recém-nascido  
- para outro local se necessário  
- Desenvolver fluxogramas de referência de emergência e implementá-los se necessário  
212. Se o recém-nascido necessitar de ressuscitação básica, iniciar com ar ambiente.  
213. Minimizar a separação do recém-nascido e sua mãe, levando em consideração as circunstâncias clínicas.  
214. Se houver mecônio significativo e o recém-nascido não apresenta respiração, frequência cardíaca e tônus normais o mesmo deve ser assistido segundo diretrizes reconhecidas de reanimação neonatal, incluindo realização precoce de laringoscopia e sucção sob visão direta.  
215. Se houver mecônio significativo e a criança estiver saudável, a mesma deve ser observada em uma unidade com acesso imediato a um neonatologista. Essas observações devem ser realizadas com 1 e 2 horas de vida e depois de 2 em 2 horas por 12 horas.  
216. Se não houver mecônio significativo, observar o recém-nascido com 1 e 2 horas de vida em todos os locais de parto.  
217. Se qualquer um dos seguintes sinais forem observados, com qualquer grau de mecônio, o recém-nascido deve ser avaliado por um neonatologista/pediatra (o recém-nascido e a mãe devem ser transferidos se não estiverem em uma maternidade):  
- Frequência respiratória > 60 ipm  
- Presença de gemidos  
- Frequência cardíaca < 100 bpm ou > 160 bpm  
- Enchimento capilar acima de 3 segundos  
- Temperatura corporal ≥ 38°C ou 37,5°C em 2 ocasiões com 30 minutos de intervalo  
- Saturação de oxigênio > 95% (a medida da saturação de oxigênio é opcional na após mecônio não significativo)  
`o` Presença de cianose central confirmada pela Oximetria de pulso se disponível  
218. Explicar os achados para a mulher e informá-la sobre o que procurar e com quem falar se tiver qualquer preocupação  
17.2.6 Aleitamento materno e interação mãe-filho logo após o parto  
17.2.6.1 Introdução  
A preocupação em facilitar um início precoce da amamentação tem se resultado na prática de estimular a pega do seio materno ainda na sala de parto, logo após o nascimento da criança. Entretanto, alguns argumentam que se deve esperar que o recém-nascido esteja preparado para iniciar a sucção e que seja ele mesmo quem encontre o mamilo e segure o peito espontaneamente. Dessa forma, se respeitaria melhor o processo de adaptação dos recém-nascidos e se facilitaria uma pega correta do mamilo. Essa seção analisará as evidências a respeito do inícico precoce da sucção e amamentação e o seu impacto nos desfechos maternos e neonatais, principalmente em relação à permanência do aleitamento materno. Também analisará o impacto do contato precoce mãe-filho na sala de parto e suas repercussões na saúde materna e da criança.  
17.2.6.2 Questões de revisão  
- Quais métodos são efetivos para encorajar o apego mãe-filho em ambiente de parto?  
- Quais os efeitos do contato pele a pele imediato logo após o parto?  
- Quais os efeitos da amamentação imediata em ambiente de parto?  
- Em que tempo logo após o parto a amamentação é mais efetiva?  
- Quais intervenções são efetivas para promover a amamentação imediatamente após o parto?  
- 17.2.6.3 Evidências científicas  
As diretriz do NICE remetem às outras diretrizes de 2006 – Postnatal Care: Routine Postnatal Care of  
Women and Their Babies<sup>389</sup> . Nessas diretrizes, afirma-se que, embora o momento ideal para o recémnascido iniciar a mamentação ainda não tenha sido estudado de maneira explícita, um estudo demonstrou algumas vantagens em relação ao início precoce da amamentação, incluindo melhora na relação mãe-filho e manutenção da temperatura do recém-nascido<sup>456</sup> .  
Outros estudos foram incluídos, que são sumarizados a seguir.  
Uma RS publicada em 2003 que incluiu 17 estudos realizados em vários países, totalizando 806 pares de mães-bebês, avaliou algumas características do recém-nascido logo após o parto, principalmente o contato pele-a-pele, e suas repercussões<sup>457</sup> . Concluiu-se que os recém-nascidos a termo e saudáveis agarram o mamilo espontaneamente e começam a mamar aproximadamente em 55 minutos após o nascimento e que, durante os primeiros 30 minutos, apenas lambem o mamilo. O aleitamento materno foi maior, 30 a 90 dias após o nascimento, entre as mães e crianças que mantiveram contato pele-a-pele imediato (OR 2,15; IC 1,10 a 4,22). O comportamento de choro das crianças também foi melhor no grupo de contato pele-a-pele precoce.  
Um estudo de coorte realizado no Paquistão e publicado em 1995<sup>458</sup> estudou o comportamento de préalimentação de 46 recém-nascidos, através de reflexos como levar o dedo à boca ou girar a cabeça quando se toca a bochecha. Os resultados indicaram que crianças que tomam banho dentro de 17 minutos após o nascimento apresentam menos esses sinais do que as que tomam banho após 28,5 minutos desde o nascimento.  
Um ERC publicado em 1985<sup>459</sup> [NE = 1+] descobriu que o contato precoce pele-a-pele entre mãe e filho associado com sucção 30 a 70 minutos após o nascimento, se associou com maior duração da amamentação materna (p < 0,001) em comparação com apenas contato pele-a-pele.  
As diretrizes espanholas atualizaram as diretrizes inglesas já citadas, no período de 2005 a 2008. Foi incluída uma RS realizada em 2007<sup>460</sup> [NE = 1++] que avaliou se o contato pele-a-pele precoce tinha resultados benéficos ou adversos sobre a amamentação onde foram apresentados resultados de 16 estudos. Quinze dos 16 estudos permitiram que os neonatos mamassem durante o contato pele-a-pele, mas apenas três estudos documentaram o sucesso da primeira tentativa de mamar. Nesses 3 estudos com 223 participantes, o contato precoce pele-a-pele proporcionou melhora significativa nas medidas de amamentação com a pontuação BAT (índice de status de amamentação) (OR 2,65 [IC 95% 1,19 a 5,91]), quando se comparou com neonatos mantidos enrolados em cobertores por suas mães. Em 28 dias, os resultados não foram significativos.  
17.2.6.4 Resumo das evidências e conclusões  
As evidências analisadas demonstram que o contato pele-a-pele com início precoce da amamentação na primeira hora após o parto favorece uma maior relação mãe e filho e maior duração da amamentação materna.  
17.2.6.5 Recomendações sobre aleitamento materno e interação mãe-bebê logo após o parto  
219. Estimular as mulheres a ter contato pele-a-pele imediato com a criança logo após o  
nascimento.  
220. Cobrir a criança com um campo ou toalha morna para mantê-la aquecida enquanto mantém o contato pele-a-pele  
221. Evitar a separação mãe-filho na primeira hora após o nascimento para procedimentos de rotina tais como, pesar, medir e dar banho a não ser que os procedimentos sejam solicitados pela mulher ou sejam realmente necessários para os cuidados imediatos do recém-nascido  
222. Estimular o início precoce do aleitamento materno, idealmente na primeira hora de vida.  
223. Registrar a circunferência cefálica, temperatura corporal e peso após a primeira hora de  
vida.  
224. Realizar exame físico inicial para detectar qualquer anormalidade física maior e para identificar problemas que possam requerer transferência.  
225. Assegurar que qualquer exame, intervenção ou tratamento da criança seja realizado com o consentimento dos pais e também na sua presença ou, se isso não for possível, com o seu conhecimento.  
As seguintes questões sobre assistência ao recém-nascido não foram abordadas de forma sistemática por nenhuma das diretrizes escolhidas para adaptação:  
- A profilaxia da hipotermia neonatal deve ser realizada de rotina?  
- Quais métodos são mais apropriados para profilaxia da hipotermia neonatal?  
- Qual a efetividade e segurança do banho do recém-nascido?  
- Em que momento o banho do recém-nascido deve ser realizado?  
- Qual é o local adequado para permanência do recém-nascido normal após o nascimento hospitalar?  
- Qual é a efetividade do primeiro exame do RN normal?  
- Qual o local e o momento adequado para o primeiro exame do RN normal?  
- Qual é o método mais adequado para a definição da idade gestacional do RN?  
- Quais são os critérios para definir a alta do recém-nascido normal dependendo do local do parto?  
- Qual o momento adequado para a alta do recém-nascido normal dependendo do local do parto?  
- Qual o profissional qualificado para declarar a alta do recém-nascido normal dependendo do local do parto?

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: 18 Referências bibliográficas -->
1. BRASIL. MS/SVS/DASIS. Nascidos vivos – Brasil. Nascim p/resid. mãe segundo Região. Sistema de Informações sobre Nascidos Vivos – SINASC, 2013. Disponível em: < <u>http://tabnet.datasus.gov.br/cgi/tabcgi.exe?sinasc/cnv/nvuf.deff>. Acesso em: 17 ago. 2015.</u>  
2. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia. PNDS 2006 – Pesquisa Nacional de Demografia e Saúde da Criança e da Mulher. Brasília: Editora do Ministério da Saúde, 2008, 583 p.  
3. Expert Maternity Group. Changing Childbirth. London: HMSO; 1993  
4. BRASIL. Ministério da Saúde. Gabinete do Ministro. Portaria Nº 1.459, de 24 de junho de 2011. Institui no âmbito do Sistema Único de Saúde - SUS - a Rede Cegonha. Diário Oficial da União n.121, seção 1, p.109, 27/06/2011.  
5. OMS - Organização Mundial da Saúde. Assistência ao Parto Normal: um guia prático. Genebra: OMS, 2000, 93 p.  
6. The ADAPTE Collaboration. The ADAPTE Process: Resource Toolkit for Guideline  
Adaptation. Version 2.0. 2009. Disponível em: http://g-i-n.net.  
7. Creedon, D. et. all. Management of labor. Bloomington (MN): Institute for Clinical Systems Improvement (ICSI). 66 p, mar 2013  
8. FEBRASGO – FEDERAÇÃO BRASILEIRA DAS ASSOCIAÇÕES DE GINECOLOGIA E OBSTETRÍCIA. Assistência ao Trabalho de Parto. S.L: Diretrizes Clínicas na Saúde Suplementar.  
Associação Médica Brasileira (AMB). Agência Nacional de Saúde Suplementar (ANS). 12 p, jan. 2011.  
9. GRUPO DE TRABALHO DO GUIA DE PRÁTICA CLÍNICA SOBRE CUIDADOS COM O PARTO NORMAL. Guia de Prática Clínica sobre Cuidados com o Parto Normal. Vitoria – Gasteiz: Plano de Qualidade para o Sistema Nacional de Saúde do Ministério da Saúde e Política Social. Agencia de Evaluación de Tecnologías Sanitarias del País Vasco (OSTEBA). Agencia de Evaluación de Tecnologías Sanitarias de Galícia. 316 p, Out. 2010.  
10. Mambourg, F.; Gailly, J.; Zhang, W. Guideline relative to low risk birth. Brussels: Belgian Health Care Knowledge Centre (KCE). 186 p, 2010.  
11. NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S  
HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 332 p, Sep. 2007.  
12. QUEENSLAND MATERNITY AND NEONATAL CLINICAL GUIDELINES PROGRAM. Normal  
Birth. Brisbane (Qld): State of Queensland (Queensland Health), 2012.  
13. Brouwers M, Kho ME, Browman GP, Cluzeau F, feder G, Fervers B, Hanna S, Makarski J on behalf of the AGREE. Next Steps Consortium. AGREE II: Advancing guideline development, reporting and evaluation in healthcare. Can. Med. Assoc. J. Dec 2010, 182:E839-842; doi: 10.1503/cmaj.090449. Disponível em: http://www.agreetrust.org.  
14. NCCWCH – NATIONAL COLLABORATING CENTRE FOR WOMEN’S AND CHILDREN’S HEALTH. Intrapartum care. Care of healthy women and their babies during childbirth. London: RCOG Press. 839 p, Dec. 2014.  
15. GRADE working group. Disponível em: http://www.gradeworkinggroup.org/index.htm.  
16. Birthplace in England Collaborative Group. Perinatal and maternal outcomes by planned  
place of birth for healthy women with low risk pregnancies: the Birthplace in England national prospective cohort study, BMJ, 343, d7400-, 2011  
17. Davis D, Baddock S, Pairman S, Hunter M, Benn C, Wilson D, Dixon L, Herbison P. Planned place of birth in New Zealand: does it affect mode of birth and intervention rates among low-risk women? Birth. Jun;38(2):111-9, 2011  
18. Davis,D., Baddock,S., Pairman,S., Hunter,M., Benn,C., Anderson,J., Dixon,L., Herbison,P., Risk of severe postpartum hemorrhage in low-risk childbearing women in new zealand: exploring the effect of place of birth and comparing third stage management of labor, Birth, 39, 98-105, 2012.  
19. Dowswell,T., Thornton,J.G., Hewison,J., Lilford,R.J., Raisler,J., Macfarlane,A., Young,G., Newburn,M., Dodds,R., Settatree,R.S., Should there be a trial of home versus hospital delivery in the United Kingdom?, British Medical Journal, BMJ, 312, 753-757, 1996  
20. Ackermann-Liebrich,U., Voegeli,T., Gunter-Witt,K., Kunz,I., Zullig,M., Schindler,C., Maurer,M., Home versus hospital deliveries: Follow up study of matched pairs for procedures and outcome, British Medical Journal,BMJ, 313, 1313-1318, 1996  
21. Janssen,P.A., Lee,S.K., Ryan,E.M., Etches,D.J., Farquharson,D.F., Peacock,D., Klein,M.C., Outcomes of planned home births versus planned hospital births after regulation of midwifery in British Columbia, Canadian Medical Association Journal,Can.Med.Assoc.J., 166, 315-323, 2002  
22. Nove,A, Berrington,A, Matthews,Z, Comparing the odds of postpartum haemorrhage in planned home birth against planned hospital birth: results of an observational study of over 500,000 maternities in the UK, BMC Pregnancy and Childbirth, 12, 130-, 2012  
23. de Jonge A., van der Goes,B.Y., Ravelli,A.C., melink-Verburg,M.P., Mol,B.W., Nijhuis,J.G.,  
Bennebroek,Gravenhorst J., Buitendijk,S.E., Perinatal mortality and morbidity in a nationwide cohort of 529,688 low-risk planned home and hospital births, BJOG: An International Journal of Obstetrics and Gynaecology, 116, 1177-1184, 2009  
24. de Jonge A., Mesman,J.A., Mannien,J., Zwart,J.J., van,Dillen J., van,Roosmalen J., Severe adverse maternal outcomes among low risk women with planned home versus hospital births in the Netherlands: nationwide cohort study, BMJ, 346, f3263-, 2013  
25. van der Kooy J., Poeran,J., de Graaf,J.P., Birnie,E., Denktass,S., Steegers,E.A., Bonsel,G.J., Planned home compared with planned hospital births in the Netherlands: intrapartum and early neonatal death in low-risk pregnancies, Obstetrics and Gynecology, 118, 1037-1046, 2011  
26. Lindgren,H.E., Radestad,I.J., Christensson,K., Hildingsson,I.M., Outcome of planned home  
births compared to hospital births in Sweden between 1992 and 2004. A population-based register study, Acta Obstetricia et Gynecologica Scandinavica, 87, 751-759, 2008  
27. Pang,J.W., Heffelfinger,J.D., Huang,G.J., Benedetti,T.J., Weiss,N.S., Outcomes of planned  
home births in Washington State: 1989-1996, Obstetrics and Gynecology, 100, 253-259, 2002  
28. Hutton,E.K., Reitsma,A.H., Kaufman,K., Outcomes associated with planned home and  
planned hospital births in low-risk women attended by midwives in Ontario, Canada, 2003-2006: A retrospective cohort study, Birth, 36, 180-189, 2009  
29. Janssen,P.A., Saxell,L., Page,L.A., Klein,M.C., Liston,R.M., Lee,S.K., Outcomes of planned  
home birth with registered midwife versus planned hospital birth with midwife or physician.[Erratum appears in CMAJ. 2009 Oct 27;181(9):617], CMAJ Canadian Medical Association Journal, 181, 377-383, 2009  
30. Woodcock,H.C., Read,A.W., Bower,C., Stanley,F.J., Moore,D.J., A matched cohort study of  
planned home and hospital births in Western Australia 1981-1987., Midwifery, 10, 125-135, 1994 31. Blix,E., Huitfeldt,A.S., Oian,P., Straume,B., Kumle,M., Outcomes of planned home births  
and planned hospital births in low-risk women in Norway between 1990 and 2007: A retrospective cohort study, Sexual and Reproductive Healthcare, 3, 147-153, 2012  
32. Overgaard,Charlotte, Moller,Anna Margrethe, Fenger-Gron,Morten, Knudsen,Lisbeth B.,  
Sandall,Jane, Freestanding midwifery unit versus obstetric unit: a matched cohort study of outcomes in low-risk women, BMJ Open, 1, -, 2011  
33. Jackson,D.J., Lang,J.M., Swartz,W.H., Ganiats,T.G., Fullerton,J., Ecker,J., Nguyen,U.,  
Outcomes, safety, and resource utilization in a collaborative care birth center program compared with traditional physician-based perinatal care, American Journal of Public Health, 93, 999-1006, 2003  
34. Scupholme,A., McLeod,A.G.W., Robertson,E.G., A birth center affiliated with the tertiary  
care center: Comparison of outcome, Obstetrics and Gynecology,Obstet.Gynecol., 67, 598-603, 1986  
35. Stone,P.W., Maternity care outcomes: assessing a nursing model of care for low-risk  
pregnancy, Outcomes Management for Nursing Practice, 2, 71-75, 1998 Intrapartum Care References 36. David,M., von Schwarzenfeld,H.K., Dimer,J.A., Kentenich,H., Perinatal outcome in hospital  
and birth center obstetric care, International Journal of Gynaecology and Obstetrics,Int.J.Gynaecol.Obstet., 65, 149-156, 1999  
37. Feldman,E., Hurst,M., Outcomes and procedures in low risk birth: a comparison of  
hospital and birth center settings, Birth, 14, 18-24, 1987  
38. Chapman,M.G., Jones,M., Spring,J.E., De,Swiet M., Chamberlain,G.V., The use of a birthroom: a randomized controlled trial comparing delivery with that in the labour ward, British Journal  
of Obstetrics and Gynaecology, 93, 182-187, 1986  
39. MacVicar,J., Dobbie,G., Owen-Johnstone,L., Jagger,C., Hopkins,M., Kennedy,J., Simulated home delivery in hospital: a randomised controlled trial, British Journal of Obstetrics and Gynaecology, 100, 316-323, 1993  
40. Hundley,V.A., Milne,J.M., Glazener,C.M., Mollison,J., Satisfaction and the three C's: continuity, choice and control. Women's views from a randomised controlled trial of midwife-led care, British Journal of Obstetrics and Gynaecology, 104, 1273-1280, 1997  
41. Begley,C., Devane,D., Clarke,M., McCann,C., Hughes,P., Reilly,M., Maguire,R., Higgins,S., Finan,A., Gormally,S., Doyle,M., Comparison of midwife-led and consultant-led care of healthy women at low risk of childbirth complications in the Republic of Ireland: A randomised trial, BMC Pregnancy and Childbirth, 11 , 2011. Article Number, -, 2011  
42. Bernitz,S., Rolland,R., Blix,E., Jacobsen,M., Sjoborg,K., Oian,P., Is the operative delivery rate in low-risk women dependent on the level of birth care? A randomised controlled trial, BJOG : an international journal of obstetrics and gynaecology, 118, 1357-1364, 2011  
43. Waldenstrom,U., Nilsson,C.A., Winbladh,B., The Stockholm birth centre trial: maternal and infant outcome, British journal of obstetrics and gynaecology, 104, 410-418, 1997  
44. Waldenstrom,U., Nilsson,C.A., A randomized controlled study of birth center care versus  
standard maternity care: effects on women's health, Birth, 24, 17-26, 1997  
45. Klein,M., Papageorgiou,A., Westreich,R., Spector-Dunsky,L., Elkins,V., Kramer,M.S., Gelfand,M.M., Care in a birth room versus a conventional setting: a controlled trial, Canadian Medical Association Journal, 131, 1461-1466, 1984  
46. Byrne,J.P., Crowther,C.A., Moss,J.R., A randomised controlled trial comparing birthing  
centre care with delivery suite care in Adelaide, Australia, Australian and New Zealand Journal of Obstetrics and Gynaecology, 40, 268-274, 2000  
47. Campbell,R., Macfarlane,A., Hempsall,V., Hatchard,K., Evaluation of midwife-led care  
provided at the Royal Bournemouth Hospital, Midwifery, 15, 183-193, 1999  
48. Gaudineau,A., Sauleau,E.A., Nisand,I., Langer,B., Obstetric and neonatal outcomes in a  
home-like birth centre: a case-control study, Archives of Gynecology and Obstetrics, 287, 211-216, 2013 49. Eide,B.I., Nilsen,A.B., Rasmussen,S., Births in two different delivery units in the same  
clinic--a prospective study of healthy primiparous women, BMC Pregnancy and Childbirth, 9, 25-, 2009 50. Hatem M, Sandall J, Devane D, Soltani H, Gates S. Midwife-led versus other models of  
care for childbearing women. Cochrane Database Syst Rev. Issue 4. Art. No.: CD004667. DOI: 10.1002/14651858.CD004667.pub2, 2008).  
51. Hodnett ED. Pain and women’s satisfaction with the experience of childbirth: a systematic  
review. American Journal of Obstetrics and Gynecology. 2002;186(5 Suppl Nature):S160–72. [PubMed] 52. Waldenstrom U, Hildingsson I, Rubertsson C. A negative birth experience: prevalence and  
risk factors in a national sample. Birth. 2004;31(1):17–27. [PubMed]  
53. Green JM, Baston HA. Feeling in control during labor: concepts, correlates, and  
consequences. Birth. 2003;30(4):235–47.  
54. Lavender T, Stephen A, Walkinshaw SA, et al. A prospective study of women’s views of  
factors contributing to a positive birth experience. Midwifery. 1999;15:40–6.  
55. Waldenstrom U. Experience of labor and birth in 1111 women. Journal of Psychosomatic  
Research. 1999;47(5):471–82.  
56. Waldenstrom U, Borg IM, Olsson B, et al. The childbirth experience: a study of 295 new  
mothers. Birth. 1996;23(3):144–53. [PubMed]  
57. Brown S, Lumley J. Satisfaction with care in labor and birth: a survey of 790 Australian  
women. Birth. 1994;21(1):4–13. [PubMed]  
58. Brown S, Lumley J. Changing childbirth: lessons from an Australian survey of 1336  
women. BJOG: an international journal of obstetrics & gynaecology. 1998;105(2):143–55.  
59. Creedy DK, Shochet IM, Horsfall J. Childbirth and the development of acute trauma  
symptoms: incidence and contributing factors. Birth. 2000;27(2):104–11. [PubMed] 60. Tarkka MT, Paunonen M, Laippala P. Importance of the midwife in the first-time mother’s  
experience of childbirth. Scandinavian Journal of Caring Sciences. 2000;14(3):184–90. [PubMed]  
61. VandeVusse L. Decision making in analyses of women’s birth stories. Birth.  
1999;26(1):43–50. [PubMed] 62. Berg M, Lundgren I, Hermansson E, et al. Women’s experience of the encounter with the  
midwife during childbirth. Midwifery. 1996;12(1):11–15. [PubMed] 63. Halldorsdottir S, Karlsdottir SI. Journeying through labour and delivery: perceptions of  
women who have given birth. Midwifery. 1996;12(2):48–61. [PubMed]  
64. Halldorsdottir S, Karlsdottir SI. Empowerment or discouragement: women’s experience of  
caring and uncaring encounters during childbirth. Health Care for Women International. 1996;17(4):361–79. [PubMed]  
65. McKay S, Smith SY. “What are they talking about? Is something wrong?” Information  
sharing during the second stage of labor. Birth. 1993;20(3):142–7. [PubMed]  
66. McKay S. Shared power: The essence of humanized childbirth. Journal of Prenatal and  
Perinatal Psychology and Health. 1991;5(4):283–95. 67. Adams M. Research and the Midwife Conference Proceedings 1989. Manchester:  
Research and the Midwife; 1990. A Study of Communication in the Labour Ward; pp. 2–18. 68. Manogin TW, Bechtel GA, Rami JS. Caring behaviors by nurses: women’s perceptions  
during childbirth. Journal of Obstetric, Gynecologic and Neonatal Nursing. 2000;29(2):153–7.  
69. Cheung NF. Choice and control as experienced by Chinese and Scottish childbearing  
women in Scotland. Midwifery. 2002;18(3):200–13. [PubMed]  
70. Hodnett ED, Gates S, Hofmeyr GJ, Sakala C. Cochrane Database of Systematic Reviews.  
Oxford: Update Software; 2004. Continuous support for women during childbirth. (Cochrane Review). 71. Scheepers HC, Essed GG, Brouns F. Aspects of food and fluid intake during labor. Policies  
of midwives and obstetricians in The Netherlands. Eur J Obstet Gynecol Reprod Biol 1998; 78: 37-40.  
72. Scheepers HC, de Jong PA, Essed GG, et al. Carbohydrate solution intake during labour  
just before the start of the second stage: a double-blind study on metabolic effects and clinical outcome. BJOG: an international journal of obstetrics & gynaecology. 2004;111(12):1382–7. [PubMed]  
73. Scheepers H, Thans MCJ, de Jong PA, et al. A double-blind, randomised, placebo  
controlled study on the influence of carbohydrate solution intake during labour. BJOG: an international journal of obstetrics & gynaecology. 2002;109(2):178–81. [PubMed] 74. Scheepers HC, de Jong PA, Essed GG, et al. Carbohydrate solution intake during labour  
just before the start of the second stage: a double-blind study on metabolic effects and clinical outcome. BJOG: an international journal of obstetrics & gynaecology. 2004;111(12):1382–7. [PubMed]  
75. Scheepers HC, Thans MC, de Jong PA, et al. The effects of oral carbohydrate  
administration on fetal acid base balance. Journal of Perinatal Medicine. 2002;30(5):400–4. [PubMed]  
76. Kubli M, Scrutton MJ, Seed PT, et al. An evaluation of isotonic “sport drinks” during labor. Anesthesia and Analgesia. 2002;94(2):404–8. [PubMed]  
77. Gyte G, Richens Y. Cochrane Database of Systematic Reviews. Oxford: Update Software; 2006. Routine prophylactic drugs in normal labour for reducing gastric aspiration and its effects. (Cochrane Review).  
78. Lumbiganon P, Thinkhamrop J, Thinkhamrop B, Tolosa JE. Cochrane Database of Systematic Reviews. 1. Oxford: Update Software; 2005. Vaginal chlorhexidine during labour for preventing maternal and neonatal infections (excluding Group B Streptococcal and HIV). (Cochrane Review).  
79. Keane HE, Thornton JG. A trial of cetrimide/chlorhexidine or tap water for perineal cleaning. British Journal of Midwifery. 1998;6(1):34–7.  
80. Kovavisarach E, Jaravechson S. Comparison of perforation between single and doublegloving in perineorrhaphy after vaginal delivery: a randomized controlled trial. Australian and New Zealand Journal of Obstetrics and Gynaecology. 1998;38(1):58–60.  
81. Punyatanasakchai P, Chittacharoen A, Ayudhya NI. Randomized controlled trial of glove perforation in single- and double-gloving in episiotomy repair after vaginal delivery. Journal of Obstetrics and Gynaecology Research. 2004;30(5):354–7. [PubMed]  
82. Kabukoba JJ, Pearce JM. The design, effectiveness and acceptability of the arm sleeve for  
the prevention of body fluid contamination during obstetric procedures. BJOG: an international journal of obstetrics & gynaecology. 1993;100(8):714–16.  
83. BRASIL. MINISTÉRIO DA SAÚDE. SECRETARIA DE VIGILÂNCIA EM SAÚDE. DEPARTAMENTO DE ANÁLISE DA SITUAÇÃO EM SAÚDE. Mortalidade infantil no Brasil: tendências, componentes e causas de morte no período de 2000 a 2010. In: Saúde Brasil 2011: uma análise da situação de saúde e a vigilância da saúde da Mulher. Brasília: Editora do Ministério da Saúde, 2012, p. 163-182.  
84. Grant,A., O'Brien,N., Joy,M.T., Hennessy,E., MacDonald,D., Cerebral palsy among children  
born during the Dublin randomised trial of intrapartum monitoring, Lancet, 2, 1233-1236, 1989  
85. Kelso,I.M., Parsons,R.J., Lawrence,G.F., Arora,S.S., Edmonds,D.K., Cooke,I.D., An  
assessment of continuous fetal heart rate monitoring in labor. A randomized trial, American Journal of Obstetrics and Gynecology, 131, 526-532, 1978  
86. Leveno,K.J., Cunningham,F.G., Nelson,S., Roark,M., Williams,M.L., Guzick,D., Dowling,S.,  
Rosenfeld,C.R., Buckley,A., A prospective comparison of selective and universal electronic fetal monitoring in 34,995 pregnancies, New England Journal of Medicine,N Engl J Med, 315, 615-619, 1986  
87. MacDonald,D., Grant,A., Sheridan-Pereira,M., Boylan,P., Chalmers,I., The Dublin randomized controlled trial of intrapartum fetal heart rate monitoring, American Journal of Obstetrics and Gynecology, 152, 524-539, 1985  
88. Vintzileos,A.M., Antsaklis,A., Varvarigos,I., Papas,C., Sofatzis,I., Montgomery,J.T., A randomized trial of intrapartum electronic fetal heart rate monitoring versus intermittent auscultation, Obstetrics and Gynecology, 81, 899-907, 1993  
89. Wood,C., Renou,P., Oats,J., Farrell,E., Beischer,N., Anderson,I., A controlled trial of fetal  
heart rate monitoring in a low-risk obstetric population, American Journal of Obstetrics and Gynecology, 141, 527-534, 1981  
90. Hodnett ED. Pain and women’s satisfaction with the experience of childbirth: a systematic  
review. American Journal of Obstetrics and Gynecology. 2002;186 (5 Suppl Nature):S160–72. [PubMed] 91. Cluett ER, Nikodem VC, McCandlish RE, Burns EE. Cochrane Database of Systematic Reviews. 2. Oxford: Update Software; 2004. Immersion in water in pregnancy, labour and birth. (Cochrane Review).  
92. Cluett ER, Pickering RM, Getliffe K, et al. Randomised controlled trial of labouring in water compared with standard of augmentation for management of dystocia in first stage of labour. British Medical Journal. 2004;328(7435):314–18. [PMC free article]  
93. Cheung NF. Choice and control as experienced by Chinese and Scottish childbearing women in Scotland. Midwifery. 2002;18(3):200–13. [PubMed]  
94. Huntley AL, Coon JT, Ernst E. Complementary and alternative medicine for labor pain: a  
systematic review. American Journal of Obstetrics and Gynecology. 2004;191(1):36–44. [PubMed]  
95. Carroll D, Moore RA, Tramer MR, et al. Transcutaneous electrical nerve stimulation does  
not relieve labor pain: Updated systematic review. Contemporary Reviews in Obstetrics and Gynaecology. 1997;9(3):195–205.  
96. Ramnero A, Hanson U, Kihlgren M. Acupuncture treatment during labour--a randomised  
controlled trial. BJOG: an international journal of obstetrics & gynaecology. 2002;109(6):637–44. [PubMed] 97. Skilnand E, Fossen D, Heiberg E. Acupuncture in the management of pain in labor. Acta  
Obstetricia et Gynecologica Scandinavica. 2002;81(10):943–8. [PubMed]  
98. Nesheim BI, Kinge R, Berg B, et al. Acupuncture during labor can reduce the use of  
meperidine: a controlled clinical study. Clinical Journal of Pain. 2003;19(3):187–91. [PubMed]  
99. Lee MK, Chang SB, Kang DH. Effects of SP6 acupressure on labor pain and length of  
delivery time in women during labor. Journal of Alternative and Complementary Medicine. 2004;10(6):959–65.  
100. Cyna AM, McAuliffe GL, Andrew MI. Hypnosis for pain relief in labour and childbirth: a  
systematic review. British Journal of Anaesthesia. 2004;93(4):505–11.  
101. Phumdoung S, Good M. Music reduces sensation and distress of labor pain. Pain  
Management Nursing. 2003;4(2):54–61. [PubMed]  
102. Smith CA, Collins CT, Cyna AM, Crowther CA. Cochrane Database of Systematic Reviews.  
2. Oxford: Update Software; 2005. Complementary and alternative therapies for pain management in labour. (Cochrane Review).  
103. Rosen MA. Nitrous oxide for relief of labor pain: a systematic review. American Journal of  
Obstetrics and Gynecology. 2002;186(5 Suppl Nature):S110–26. [PubMed]  
104. Bricker L, Lavender T. Parenteral opioids for labor pain relief: a systematic review.  
American Journal of Obstetrics and Gynecology. 2002;186(5 Suppl Nature):S94–109. [PubMed]  
105. Elbourne D, Wiseman RA. Cochrane Database of Systematic Reviews. 3. Oxford: Update  
Software; 2000. Types of intra-muscular opiods for maternal pain relief in labour. (Cochrane Review). 106. 143. Tsui MH, Ngan Kee WD, Ng FF, et al. A double blinded randomised placebo-  
controlled study of intramuscular pethidine for pain relief in the first stage of labour. BJOG: an international journal of obstetrics & gynaecology. 2004;111(7):648–55. [PubMed]  
107. Keskin HL, Keskin EA, Avsar AF, et al. Pethidine versus tramadol for pain relief during  
labor. International Journal of Gynaecology and Obstetrics. 2003;82(1):11–16. [PubMed]  
108. Fairlie FM, Marshall L, Walker JJ, et al. Intramuscular opioids for maternal pain relief in  
labour: a randomised controlled trial comparing pethidine with diamorphine. BJOG: an international journal of obstetrics & gynaecology. 1999;106(11):1181–7.  
109. Sosa CG, Balaguer E, Alonso JG, et al. Meperidine for dystocia during the first stage of  
labor: A randomized controlled trial. American Journal of Obstetrics and Gynecology. 2004;191(4):1212– 18. [PubMed]  
110. Soontrapa S, Somboonporn W, Komwilaisak R, et al. Effectiveness of intravenous  
meperidine for pain relief in the first stage of labour. Journal of the Medical Association of Thailand. 2002;85(11):1169–75. [PubMed]  
111. Olofsson C, Ekblom A, Ekman-Ordeberg G, et al. Analgesic efficacy of intravenous  
morphine in labour pain: A reappraisal. International Journal of Obstetric Anesthesia. 1996;5(3):176–80. [PubMed]  
112. Nelson KE, Eisenach JC. Intravenous butorphanol, meperidine, and their combination  
relieve pain and distress in women in labor. Anesthesiology. 2005;102(5):1008–13. [PubMed  
113. Blair JM, Dobson GT, Hill DA, et al. Patient controlled analgesia for labour: a comparison  
of remifentanila with pethidine. Anaesthesia. 2005;60(1):22–7. [PubMed]  
114. Volikas I, Male D. A comparison of pethidine and remifentanila patient-controlled  
analgesia in labour. International Journal of Obstetric Anesthesia. 2001;10(2):86–90. [PubMed]  
115. Morley-Forster PK, Reid DW, Vandeberghe H. A comparison of patient-controlled  
analgesia fentanyl and alfentanila for labour analgesia. Canadian Journal of Anaesthesia. 2000;47(2):113–19. [PubMed]  
116. Isenor L, Penny-MacGillivray T. Intravenous meperidine infusion for obstetric analgesia.  
Journal of Obstetric, Gynecologic and Neonatal Nursing. 1993;22(4):349–56.  
117. McInnes RJ, Hillan E, Clark D, et al. Diamorphine for pain relief in labour : a randomised  
controlled trial comparing intramuscular injection and patient-controlled analgesia. BJOG: an international journal of obstetrics & gynaecology. 2004;111(10):1081–9.  
118. Thurlow JA, Laxton CH, Dick A, et al. Remifentanila by patient-controlled analgesia  
compared with intramuscular meperidine for pain relief in labour. British Journal of Anaesthesia. 2002;88(3):374–8.  
119. Vale NB e cols. O tempo e a Anestesia Obstétrica: da Cosmologia Caótica à Cronobiologia.  
Rev Bras Anestesiol 2009; 59: 5: 624-647.  
120. Leite S – Cartas dos primeiros jesuítas do Brasil, Comissão do IV Centenário da Cidade de  
São Paulo, São Paulo, 1954.  
121. Morgan-Ortiz F, Quintero-Ledezma JC, Perez-Sotelo JA, et al. Evolution and quality of care  
during labor and delivery in primiparous patients who underwent early obstetrical analgesia. [Spanish] Ginecologia y Obstetricia de Mexico. 1999;67:522–6. [PubMed]  
122. Anim-Somuah M, Smyth R, Howell C. Cochrane Database of Systematic Reviews. Oxford:  
Update Software; 2005. Peridural versus non-peridural or no analgesia in labour. (Cochrane Review).  
123. Leighton BL, Halpern SH. The effects of peridural analgesia on labor, maternal, and  
neonatal outcomes: a systematic review. American Journal of Obstetrics and Gynecology. 2002;186(5 Suppl Nature):S69–77. [PubMed]  
124. Reynolds F, Sharma SK, Seed PT. Analgesia in labour and fetal acid-base balance: a metaanalysis comparing peridural with systemic opioid analgesia. BJOG: an international journal of obstetrics & gynaecology. 2002;109(12):1344–53. [PubMed]  
125. Philip J, Alexander JM, Sharma SK, et al. Peridural analgesia during labor and maternal  
fever. Anesthesiology. 1999;90(5):1271–5. [PubMed]  
126. Lieberman E, Davidson K, Lee-Parritz A, et al. Changes in fetal position during labor and  
their association with peridural analgesia. Obstetrics and Gynecology. 2005;105(5 I):974–82. [PubMed] 127. Alexander JM, Sharma SK, McIntire DD, et al. Peridural analgesia lengthens the Friedman  
active phase of labor. Obstetrics and Gynecology. 2002;100(1):46–50. [PubMed]  
128. Macarthur A, MacArthur C, Weeks S. Peridural anaesthesia and low back pain after  
delivery: a prospective cohort study. British Medical Journal. 1995;311(7016):1336–9. [PMC free article] [PubMed]  
129. Eriksson SL, Olausson PO, Olofsson C. Use of peridural analgesia and its relation to caesarean and instrumental deliveries-a population-based study of 94,217 primiparae. European Journal of Obstetrics, Gynecology and Reproductive Biology. 2005. E-print ahead of print.  
130. Chestnut DH, Vincent RD Jr, McGrath JM, et al. Does early administration of peridural analgesia affect obstetric outcome in nulliparous women who are receiving intravenous oxytocin? Anesthesiology. 1994;80(6):1193–200. [PubMed]  
131. Chestnut DH, McGrath JM, Vincent RD Jr, et al. Does early administration of peridural analgesia affect obstetric outcome in nulliparous women who are in spontaneous labor? Anesthesiology. 1994;80(6):1201–8. [PubMed] Intrapartum Care References  
132. Capogna G, Celleno D, Lyons G, et al. Minimum local analgesic concentration of  
extradural bupivacaine increases with progression of labour. British Journal of Anaesthesia. 1998;80(1):11–13. [PubMed]  
133. Chen L-K, Hsu H-W, Lin C-J, et al. Effects of peridural fentanyl on labor pain during the early period of the first stage of induced labor in nulliparous women. Journal of the Formosan Medical Association. 2000;99(7):549–53. [PubMed]  
134. Luxman D, Wolman I, Groutz A, et al. The effect of early peridural block administration on  
the progression and outcome of labor. International Journal of Obstetric Anesthesia. 1998;7(3):161–4. [PubMed]  
135. Ohel G, Gonen R, Vaida S, et al. Early versus late initiation of peridural analgesia in labor:  
does it increase the risk of cesarean section? A randomized trial. American Journal of Obstetrics and Gynecology. 2006;194(3):600–5. [PubMed]  
136. Wong CA, Scavone BM, Peaceman AM, et al. The risk of cesarean delivery with neuraxial  
analgesia given early versus late in labor. New England Journal of Medicine. 2005;352(7):655–65. [PubMed]  
137. <mark>Plaat FS, Royston P, Morgan BM. Comparison of 15 mg and 25 mg of bupivacaine both with 50 mug fentanyl as initial dose for peridural analgesia. International Journal of Obstetric Anesthesia. 1996;5(4):240–3. [PubMed]</mark>  
138. <mark>Christiaens F, Verborgh C, Dierick A, et al. Effects of diluent volume of a single dose of</mark>  
<mark>peridural bupivacaine in parturients during the first stage of labor. Regional Anesthesia and Pain Medicine. 1998;23(2):134–41. [PubMed]</mark>  
139. <mark>Beilin Y, Galea M, Zahn J, et al. Peridural ropivacaine for the initiation of labor peridural analgesia: a dose finding study. Anesthesia and Analgesia. 1999;88(6):1340–5. [PubMed]</mark>  
140. Hughes D, Simmons SW, Brown J, Cyna AM. Cochrane Database of Systematic Reviews.  
Oxford. Oxford: Update Software; 2005. Combined spinal-peridural versus peridural analgesia in labour.  
(Cochrane Review).  
141. Zeidan AZ. Combined spinal-peridural compared with low dose peridural during  
ambulatory labour analgesia in nulliparous women. Egyptian Journal of Anaesthesia. 2004;20(3):273–81. 142. MacArthur C. A randomised controlled trial of mobile and non-mobile techniques of  
regional analgesia for labour, evaluating short and long term outcomes. 2004. [www.ReFeR.nhs.uk/ViewRecord.asp?ID=1210]  
143. Mardirosoff C, Dumont L, Boulvain M, et al. Fetal bradycardia due to intrathecal opioids  
for labour analgesia: a systematic review. BJOG: an international journal of obstetrics & gynaecology. 2002;109(3):274–81. [PubMed]  
144. Wong CA, Scavone BM, Slavenas JP, et al. Efficacy and side effect profile of varying doses  
of intrathecal fentanyl added to bupivacaine for labor analgesia. International Journal of Obstetric Anesthesia. 2004;13(1):19–24. [PubMed]  
145. Lim Y, Sia AT, Ocampo CE. Comparison of intrathecal levobupivacaine with and without  
fentanyl in combined spinal peridural for labor analgesia. Medical Science Monitor. 2004;10(7):I87–91. 146. Bucklin BA, Chestnut DH, Hawkins JL. Intrathecal opioids versus peridural local  
anesthetics for labor analgesia: a meta-analysis. Regional Anesthesia and Pain Medicine. 2002;27(1):23– 30. [PubMed]  
147. Palmer CM, Van Maren G, Nogami WM, et al. Bupivacaine augments intrathecal fentanyl  
for labor analgesia. Anesthesiology. 1999;91(1):84–9. [PubMed]  
148. Chan SY, Chiu JW. Intrathecal labor analgesia using levobupivacaine 2.5 mg with fentanyl  
25 microg--would half the dose suffice? Medical Science Monitor. 2004;10(10):I110– 14. 149. Lee BB, Ngan Kee WD, Hung VY, et al. Combined spinal-peridural analgesia in labour:  
comparison of two doses of intrathecal bupivacaine with fentanyl. British Journal of Anaesthesia. 1999;83(6):868–71. [PubMed]  
150. Palmer CM, Cork RC, Hays R, et al. The dose-response relation of intrathecal fentanyl for  
labor analgesia. Anesthesiology. 1998;88(2):355–61. [PubMed]  
151. Stocks GM, Hallworth SP, Fernando R, et al. Minimum local analgesic dose of intrathecal  
bupivacaine in labor and the effect of intrathecal fentanyl. Anesthesiology. 2001;94(4):593–8. [PubMed] 152. Celeski DC, Heindel L, Haas J, et al. Effect of intrathecal fentanyl dose on the duration of  
labor analgesia. AANA Journal. 1999;67(3):239–44. [PubMed]  
153. Merson N. A comparison of motor block between ropivacaine and bupivacaine for  
continuous labor peridural analgesia. AANA Journal. 2001;69(1):54–8. [PubMed]  
154. Beilin Y, Nair A, Arnold I, et al. A comparison of peridural infusions in the combined spina  
peridural technique for labor analgesia. Anesthesia and Analgesia. 2002;94(4):927–32. [PubMed]  
155. Benhamou D, Hamza J, Eledjam J-J, et al. Continuous extradural infusion of ropivacaine 2  
mg ml-1 for pain relief during labour. British Journal of Anaesthesia. 1997;78(6):748–50. [PubMed]  
156. Bernard JM, Le RD, Frouin J. Ropivacaine and fentanyl concentrations in patient-  
controlled peridural analgesia during labor: a volume-range study. Anesthesia and Analgesia. 2003;97(6):1800–7. [PubMed]  
157. Cascio MG, Gaiser RR, Camann WR, et al. Comparative evaluation of four different  
infusion rates of ropivacaine (2 mg/mL) for peridural labor analgesia. Regional Anesthesia and Pain Medicine. 1998;23(6):548–53. [PubMed]  
158. Ewen A, McLeod DD, MacLeod DM. Continuous infusion peridural analgesia in obstetrics.  
A comparison of 0.08% and 0.25% bupivacaine. Anaesthesia. 1986;41(2):143–7. [PubMed]  
159. Li DF, Rees GA, Rosen M. Continuous extradural infusion of 0.0625% or 0.125% bupivacaine for pain relief in primigravid labour. British Journal of Anaesthesia. 1985;57(3):264–70. [PubMed]  
160. Noble HA, Enever GR, Thomas TA. Peridural bupivacaine dilution for labour. A comparison  
of three concentrations infused with a fixed dose of fentanyl. Anaesthesia. 1991;46(7):549–52.  
[PubMed]  
161. Stoddart AP, Nicholson KEA, Popham PA. Low dose bupivacaine/fentanyl peridural infusions in labour and mode of delivery. Anaesthesia. 1994;49(12):1087–90. [PubMed] Intrapartum Care References  
162. Thorburn J, Moir DD. Extradural analgesia: The influence of volume and concentration of bupivacaine on the mode of delivery, analgesic efficacy and motor block. British Journal of Anaesthesia. 1981;53(9):933–9. [PubMed]  
163. Sia AT, Ruban P, Chong JL, et al. Motor blockade is reduced with ropivacaine 0.125% for parturient-controlled peridural analgesia during labour. Canadian Journal of Anaesthesia. 1999;46(11):1019–23. [PubMed]  
164. Elliott RD. Continuous infusion peridural analgesia for obstetrics: Bupivacaine versus  
bupivacaine-fentanyl mixture. Canadian Journal of Anaesthesia. 1991;38(3):303–10. [PubMed]  
165. Enever GR, Noble HA, Kolditz D, et al. Peridural infusion of diamorphine with bupivacaine  
in labour. A comparison with fentanyl and bupivacaine. Anaesthesia. 1991;46(3):169–73. [PubMed]  
166. Russell R, Quinlan J, Reynolds F. Motor block during peridural infusions for nulliparous  
women in labour. A randomized double-blind study of plain bupivacaine and low dose bupivacaine with fentanyl. International Journal of Obstetric Anesthesia. 1995;4(2):82–8. [PubMed]  
167. Russell R, Reynolds F. Peridural infusion of low-dose bupivacaine and opioid in labour:  
Does reducing motor block increase the spontaneous delivery rate? Anaesthesia. 1996;51(3):266–73. [PubMed]  
168. Reynolds F, Russell R, Porter J, et al. Does the use of low dose bupivacaine/opioid peridural infusion increase the normal delivery rate? International Journal of Obstetric Anesthesia. 2003;12(3):156–63. [PubMed]  
169. Porter J, Bonello E, Reynolds F. Effect of peridural fentanyl on neonatal respiration. [Erratum appears in Anesthesiology 1998 Dec;89(6):1615] Anesthesiology. 1998;89(1):79–85. [PubMed] Intrapartum Care References  
170. Chestnut DH, Owen CL, Bates JN, et al. Continuous infusion peridural analgesia during labor. A randomized, double-blind comparison of 0.0625% bupivacaine/0.0002% fentanyl versus 0.125% bupivacaine. Anesthesiology. 1988;68(5):754–9. [PubMed]  
171. Comparative Obstetric Mobile Peridural Trial (COMET) Study Group. Effect of low-dose mobile versus traditional peridural techniques on mode of delivery: a randomised controlled trial. Lancet. 2001;358(9275):19–23. [PubMed]  
172. Huch A, Huch R. Physiological insights based on fetal tcPO2 monitoring. Journal of Perinatal Medicine. 1981;9(4):184–8. [PubMed]  
173. Burke D, Henderson DJ, Simpson AM, et al. Comparison of 0.25% S(-)-bupivacaine with 0.25% RS-bupivacaine for peridural analgesia in labour. British Journal of Anaesthesia. 1999;83(5):750– 5. [PubMed]  
174. Camorcia M, Capogna G, Columb MO. Minimum local analgesic doses of ropivacaine, levobupivacaine, and bupivacaine for intrathecal labor analgesia. Anesthesiology. 2005;102(3):646–50. [PubMed]  
175. El-Moutaz H, El-Said A, Fouad M. Comparative study between 0.25% levobupivacaine and 0.25% racemic bupivacaine for peridural analgesia in labour. Egyptian Journal of Anaesthesia. 2003;19(4):417–21.  
176. Lim Y, Ocampo CE, Sia AT. A comparison of duration of analgesia of intrathecal 2.5 mg of bupivacaine, ropivacaine, and levobupivacaine in combined spinal peridural analgesia for patients in labor. Anesthesia and Analgesia. 2004;98(1):235–9. [PubMed]  
177. Lyons G, Columb M, Wilson RC, et al. Peridural pain relief in labour: potencies of levobupivacaine and racemic bupivacaine. [erratum appears in Br J Anaesth 1999;82(3):488] British Journal of Anaesthesia. 1998;81(6):899–901. [PubMed]  
178. Sah N, Vallejo MC, Ramanathan S, et al. Bupivacaine versus L-bupivacaine for labor analgesia via combined spinal-peridural: A randomized, double-blinded study. Journal of Clinical Anesthesia. 2005;17(2):91–5. [PubMed]  
179. Asik I, Goktug A, Gulay I, et al. Comparison of bupivacaine 0.2% and ropivacaine 0.2% combined with fentanyl for peridural analgesia during labour. European Journal of Anaesthesiology. 2002;19(4):263–70. [PubMed]  
180. Campbell DC, Zwack RM, Crone LA, et al. Ambulatory labor peridural analgesia: bupivacaine versus ropivacaine. Anesthesia and Analgesia. 2000;90(6):1384–9. [PubMed]  
181. Chua NP, Sia AT, Ocampo CE. Parturient-controlled peridural analgesia during labour: Bupivacaine vs. ropivacaine. Anaesthesia. 2001;56(12):1169–73. [PubMed] Intrapartum Care References 182. Dresner M, Freeman J, Calow C, et al. Ropivacaine 0.2% versus bupivacaine 0.1% with fentanyl: a double blind comparison for analgesia during labour. British Journal of Anaesthesia. 2000;85(6):826–9. [PubMed]  
183. Eddleston JM, Holland JJ, Griffin RP, et al. A double-blind comparison of 0.25% ropivacaine and 0.25% bupivacaine for extradural analgesia in labour. British Journal of Anaesthesia. 1996;76(1):66–71. [PubMed]  
184. Evron S, Glezerman M, Sadan O, et al. Patient-controlled peridural analgesia for labor pain: Effect on labor, delivery and neonatal outcome of 0.125% bupivacaine vs 0.2% ropivacaine. International Journal of Obstetric Anesthesia. 2004;13(1):5–10. [PubMed]  
185. Fernandez-Guisasola J, Serrano ML, Cobo B, et al. A comparison of 0.0625% bupivacaine with fentanyl and 0.1% ropivacaine with fentanyl for continuous peridural labor analgesia. Anesthesia and Analgesia. 2001;92(5):1261–5. [PubMed]  
186. Finegold H, Mandell G, Ramanathan S. Comparison of ropivacaine 0.1%-fentanyl and bupivacaine 0.125%-fentanyl infusions for peridural labour analgesia. Canadian Journal of Anaesthesia. 2000;47(8):740–5. [PubMed]  
187. Gaiser RR, Venkateswaren P, Cheek TG, et al. Comparison of 0.25% Ropivacaine and bupivacaine for peridural analgesia for labor and vaginal delivery. Journal of Clinical Anesthesia. 1997;9(7):564–8. [PubMed]  
188. Halpern SH, Breen TW, Campbell DC, et al. A multicenter, randomized, controlled trial comparing bupivacaine with ropivacaine for labor analgesia. Anesthesiology. 2003;98(6):1431–5. [PubMed]  
189. Hughes D, Hill D, Fee JP. Intrathecal ropivacaine or bupivacaine with fentanyl for labour.  
British Journal of Anaesthesia. 2001;87(5):733–7. [PubMed]  
190. Irestedt L, Ekblom A, Olofsson C, et al. Pharmacokinetics and clinical effect during  
continuous peridural infusion with ropivacaine 2.5 mg/ml or bupivacaine 2.5 mg/ml for labour pain relief. Acta Anaesthesiologica Scandinavica. 1998;42(8):890–6. [PubMed]  
191. Lee BB, Ngan Kee WD, Ng FF, et al. Peridural Infusions of Ropivacaine and Bupivacanie for  
Labor Analgesia: A Randomized, Double-Blind Study of Obstetric Outcome. Anesthesia and Analgesia. 2004;98(4):1145–52. [PubMed]  
192. McCrae AF, Jozwiak H, McClure JH. Comparison of ropivacaine and bupivacaine in  
extradural analgesia for the relief of pain in labour. British Journal of Anaesthesia. 1995;74(3):261–5. [PubMed]  
193. McCrae AF, Westerling P, McClure JH. Pharmacokinetic and clinical study of ropivacaine  
and bupivacaine in women receiving extradural analgesia in labour. British Journal of Anaesthesia. 1997;79(5):558–62. [PubMed]  
194. Meister GC, D’Angelo R, Owen M, et al. A comparison of peridural analgesia with 0.125%  
ropivacaine with fentanyl versus 0.125% bupivacaine with fentanyl during labor. Anesthesia and Analgesia. 2000;90(3):632–7. [PubMed]  
195. Merson N. A comparison of motor block between ropivacaine and bupivacaine for  
continuous labor peridural analgesia. AANA Journal. 2001;69(1):54–8. [PubMed]  
196. Muir HA, Writer D, Douglas J, et al. Double-blind comparison of peridural ropivacaine  
0.25% and bupivacaine 0.25%, for the relief of childbirth pain. Canadian Journal of Anaesthesia. 1997;44(6):599–604. [PubMed] Intrapartum Care References  
197. Owen MD, D’Angelo R, Gerancher JC, et al. 0.125% ropivacaine is similar to 0.125%  
bupivacaine for labor analgesia using patient-controlled peridural infusion. Anesthesia and Analgesia. 1998;86(3):527–31. [PubMed]  
198. Owen MD, Thomas JA, Smith T, et al. Ropivacaine 0.075% and Bupivacaine 0.075% with  
Fentanyl 2 mug/mL are equivalent for labor peridural analgesia. Anesthesia and Analgesia. 2002;94(1):179–83. [PubMed]  
199. Parpaglioni R, Capogna G, Celleno D. A comparison between low-dose ropivacaine and  
bupivacaine at equianalgesic concentrations for peridural analgesia during the first stage of labor. International Journal of Obstetric Anesthesia. 2000;9(2):83–6. [PubMed]  
200. Pirbudak L, Tuncer S, Kocoglu H, et al. Fentanyl added to bupivacaine 0.05% or  
ropivacaine 0.05% in patient-controlled peridural analgesia in labour. European Journal of Anaesthesiology. 2002;19(4):271–5. [PubMed]  
201. Shah MK, Sia ATH, Chong JL. The effect of the addition of ropivacaine or bupivacaine  
upon pruritus induced by intrathecal fentanyl in labour. Anaesthesia. 2000;55(10):1003–13. [PubMed] 202. Stienstra R, Jonker TA, Bourdrez P, et al. Ropivacaine 0.25% versus bupivacaine 0.25% for  
continuous peridural analgesia in labor: A double-blind comparison. Anesthesia and Analgesia. 1995;80(2):285–9. [PubMed]  
203. Bolukbasi D, Sener EB, Sarihasan B, et al. Comparison of maternal and neonatal outcomes  
with peridural bupivacaine plus fentanyl and ropivacaine plus fentanyl for labor analgesia. International Journal of Obstetric Anesthesia. 2005;14(4):288–93. [PubMed]  
204. Chua SM, Sia AT. Automated intermittent peridural boluses improve analgesia induced by  
intrathecal fentanyl during labour. Canadian Journal of Anaesthesia. 2004;51(6):581–5. [PubMed]  
205. D’Athis F, Macheboeuf M, Thomas H, et al. Peridural analgesia with a bupivacainefentanyl mixture in obstetrics: comparison of repeated injections and continuous infusion. Canadian Journal of Anaesthesia. 1988;35(2):116–22. [PubMed]  
206. Eddleston JM, Maresh M, Horsman EL, et al. Comparison of the maternal and fetal effects associated with intermittent or continuous infusion of extradural analgesia. British Journal of Anaesthesia. 1992;69(2):154–8. [PubMed]  
207. Hicks JA, Jenkins JG, Newton MC, et al. Continuous peridural infusion of 0.075% bupivacaine for pain relief in labour. A comparison with intermittent top-ups of 0.5% bupivacaine. Anaesthesia. 1988;43(4):289–92. [PubMed]  
208. Lamont RF, Pinney D, Rodgers P, et al. Continuous versus intermittent peridural analgesia.  
A randomised trial to observe obstetric outcome. Anaesthesia. 1989;44(11):893–6. [PubMed]  
209. Smedstad KG, Morison DH. A comparative study of continuous and intermittent peridural  
analgesia for labour and delivery. Canadian Journal of Anaesthesia. 1988;35(3):234–41. [PubMed]  
210. Wong CA, Ratliff JT, Sullivan JT, et al. A randomized comparison of programmed intermittent peridural bolus with continuous peridural infusion for labor analgesia. Anesthesia and Analgesia. 2006;102(3):904–9. [PubMed]  
211. Lim Y, Sia AT, Ocampo C. Automated regular boluses for peridural analgesia: a  
comparison with continuous infusion. International Journal of Obstetric Anesthesia. 2005;14(4):305–9. [PubMed]  
212. van der Vyver M, Halpern S, Joseph G. Patient-controlled peridural analgesia versus continuous infusion for labour analgesia: a meta-analysis. British Journal of Anaesthesia. 2002;89(3):459–65. [PubMed]  
213. Saito M, Okutomi T, Kanai Y, et al. Patient-controlled peridural analgesia during labor using ropivacaine and fentanyl provides better maternal satisfaction with less local anesthetic requirement. Journal of Anesthesia. 2005;19(3):208–12. [PubMed]  
214. Gambling DR, McMorland GH, Yu P, et al. Comparison of patient-controlled peridural analgesia and conventional intermittent ‘top-up’ injections during labor. Anesthesia and Analgesia. 1990;70(3):256–61. [PubMed]  
215. Paech MJ. Peridural analgesia in labour: Constant infusion plus patient-controlled boluses. Anaesthesia and Intensive Care. 1991;19(1):32–9. [PubMed]  
216. Paech MJ, Pavy TJG, Sims C, et al. Clinical experience with patient-controlled and staffadministered intermittent bolus peridural analgesia in labour. Anaesthesia and Intensive Care. 1995;23(4):459–63. [PubMed]  
217. Halonen P, Sarvela J, Saisto T, et al. Patient-controlled peridural technique improves analgesia for labor but increases cesarean delivery rate compared with the intermittent bolus technique. Acta Anaesthesiologica Scandinavica. 2004;48(6):732–7. [PubMed]  
218. Gambling DR, Huber CJ, Berkowitz J, et al. Patient-controlled peridural analgesia in labour: varying bolus dose and lockout interval. Canadian Journal of Anaesthesia. 1993;40(3):211–17. [PubMed]  
219. Bernard JM, Le RD, Vizquel L, et al. Patient-controlled peridural analgesia during labor: the effects of the increase in bolus and lockout interval. Anesthesia and Analgesia. 2000;90(2):328–32. [PubMed]  
220. Siddik-Sayyid SM, Aouad MT, Jalbout MI, et al. Comparison of three modes of patient-  
controlled peridural analgesia during labour. European Journal of Anaesthesiology. 2005;22(1):30–4. [PubMed]  
221. Stratmann G, Gambling DR, Moeller-Bertram T, et al. A randomized comparison of a five-  
minute versus fifteen-minute lockout interval for PCEA during labor. International Journal of Obstetric Anesthesia. 2005;14(3):200–7. [PubMed]  
222. Hofmeyr GJ. Cochrane Database of Systematic Reviews. 3. Oxford: Update Software;  
2000. Prophylactic intravenous preloading for regional analgesia in labour. (Cochrane Review).  
223. Roberts CL, Algert CS, Olive E. Impact of first-stage ambulation on mode of delivery  
among women with peridural analgesia. Australian and New Zealand Journal of Obstetrics and Gynaecology. 2004;44(6):489–94. [PubMed]  
224. Roberts CL, Algert CS, Cameron CA. A meta-analysis of upright positions in the second  
stage to reduce instrumental deliveries in women with peridural analgesia. Acta Obstetricia et Gynecologica Scandinavica. 2005;84(8):794–8. [PubMed]  
225. Downe S, Gerrett D, Renfrew MJ. A prospective randomised trial on the effect of position  
in the passive second stage of labour on birth outcome in nulliparous women using peridural analgesia. Midwifery. 2004;20(2):157–68. [PubMed]  
226. Torvaldsen S, Roberts CL, Bell JC, Raynes-Greenow CH. Cochrane Database of Systematic  
Reviews. Oxford. Oxford: Update Software; 2005. Discontinuation of peridural analgesia late in labour for reducing the adverse delivery outcomes associated with peridural analgesia. (Cochrane Review).  
227. 180. Gleeson NC, Griffith AP. The management of the second stage of labour in  
primiparae with peridural analgesia. British Journal of Clinical Practice. 1991;45(2):90–1.  
228. Roberts CL, Torvaldsen S, Cameron CA, et al. Delayed versus early pushing in women with  
peridural analgesia: a systematic review and meta-analysis. BJOG: an international journal of obstetrics & gynaecology. 2004;111(12):1333–40.  
229. Simpson KR, James DC. Effects of immediate versus delayed pushing during second-  
stage labor on fetal well-being: a randomized clinical trial. Nursing Research. 2005;54(3):149–57.  
230. Saunders NJ, Spiby H, Gilbert L, et al. Oxytocin infusion during second stage of labour in  
primiparous women using peridural analgesia: a randomised double blind placebo controlled trial. British Medical Journal. 1989;299(6713):1423–6. [PMC free article]  
231. Sharma SK, Sidawi JE, Ramin SM, et al. Cesarean delivery: a randomized trial of peridural  
versus patient-controlled meperidine analgesia during labor. Anesthesiology. 1997;87(3):487–94.  
232. Hill JB, Alexander JM, Sharma SK, et al. A comparison of the effects of peridural and  
meperidine analgesia during labor on fetal heart rate. Obstetrics and Gynecology. 2003;102(2):333–7.  
233. Mardirosoff C, Dumont L, Boulvain M, et al. Fetal bradycardia due to intrathecal opioids  
for labour analgesia: a systematic review. BJOG: an international journal of obstetrics & gynaecology. 2002;109(3):274–81.  
234. Jordan S, Emery S, Bradshaw C, et al. The impact of intrapartum analgesia on infant  
feeding. BJOG: an international journal of obstetrics & gynaecology. 2005;112(7):927–34.  
235. Beilin Y, Bodian CA, Weiser J, et al. Effect of labor peridural analgesia with and without  
fentanyl on infant breast-feeding: a prospective, randomized, double-blind study. Anesthesiology. 2005;103(6):1211–17.  
236. Dare MR, Middleton P, Crowther CA, Flenady V, Varatharaju B. Cochrane Database of  
Systematic Reviews. 1. Oxford: Update Software; 2006. Planned early birth versus expectant management (waiting) for prelabour rupture of membranes at term (37 weeks or more). (Cochrane Review).  
237. Seaward PG, Hannah ME, Myhr TL, et al. International multicenter term PROM study: evaluation of predictors of neonatal infection in infants born to patients with premature rupture of membranes at term. Premature Rupture of the Membranes. American Journal of Obstetrics and Gynecology. 1998;179(3 Pt 1):635–9. [PubMed]  
238. Hannah ME, Hodnett ED, Willan A, et al. Prelabor rupture of the membranes at term: expectant management at home or in hospital? The TermPROM Study Group. Obstetrics and Gynecology. 2000;96(4):533–8.  
239. Jomeen J, Martin CR. The impact of clinical management type on maternal and neo-natal outcome following pre-labour rupture of membranes at term. Clinical Effectiveness in Nursing. 2002;6(1):3–9.  
240. Hagskog K, Nisell H, Sarman I, et al. Conservative ambulatory management of prelabor rupture of the membranes at term in nulliparous women. Acta Obstetricia et Gynecologica Scandinavica. 1994;73(10):765–9.  
241. Seaward PG, Hannah ME, Myhr TL, et al. International Multicentre Term Prelabor Rupture of Membranes Study: evaluation of predictors of clinical chorioamnionitis and postpartum fever in patients with prelabor rupture of membranes at term. American Journal of Obstetrics and Gynecology. 1997;177(5):1024–9. [PubMed]  
242. Apuzzio JJ, Fenmore B, Ganesh V. Conservative versus aggressive management of premature rupture of membranes at term with an unfavorable cervix. International Journal of FetoMaternal Medicine. 1990;3(4):205–8.  
243. Eriksson M, Ladfors L, Mattsson LA, et al. Warm tub bath during labor. A study of 1385 women with prelabor rupture of the membranes after 34 weeks of gestation. Acta Obstetricia et Gynecologica Scandinavica. 1996;75(7):642–4.  
244. Ezra Y, Michaelson-Cohen R, Abramov Y, et al. Prelabor rupture of the membranes at term: When to induce labor? European Journal of Obstetrics, Gynecology and Reproductive Biology. 2004;115(1):23–7.  
245. Flenady V, King J. Cochrane Database of Systematic Reviews. 3. Oxford: Update Software; 2002. Antibiotics for prelabour rupture of membranes at or near term. (Cochrane Review).  
246. Morad,Y., Kaplan,B., Zangen,S., Rabinerson,D., Peleg,D., Merlob,P., Management of meconium-stained neonates, Journal of Obstetrics and Gynaecology, 18, 223-226, 1998  
247. Trimmer,K.J., Gilstrap,L.C.,III, "Meconiumcrit" and birth asphyxia, American Journal of Obstetrics and Gynecology, 165, 1010-1013, 1991  
248. van Heijst,M.L., van,Roosmalen G., Keirse,M.J., Classifying meconium-stained liquor: is it feasible?, Birth, 22, 191-195, 1995  
249. Alfirevic,Z., Devane,D., Gyte,G.M., Continuous cardiotocography (CTG) as a form of electronic fetal monitoring (EFM) for fetal assessment during labour. [55 refs]Updated, Cochrane Database of Systematic Reviews, 5, CD006066-, 2013  
250. Hofmeyr,G.J., Xu,H., Amnioinfusion for meconium-stained liquor in labour. [68 refs][Update of Cochrane Database Syst Rev. 2009;(1):CD000014; PMID: 19160173], Cochrane Database of Systematic Reviews, CD000014-, 2010  
251. Choudhary,D., Bano,I., Ali,S.M., Does amnioinfusion reduce caesarean section rate in  
meconium-stained amniotic fluid, Archives of Gynecology and Obstetrics, 282, 17-22, 2010  
252. McNiven PS, Wiliams JI, Hodnett E, et al. An early labour assessment program: a  
randomised controlled trial. Birth. 1998;25(1):5–10.  
253. Holmes P, Oppenheimer LW, Wen SW. The relationship between cervical dilatation at  
initial presentation in labour and subsequent intervention. BJOG: an international journal of obstetrics & gynaecology. 2001;108(11):1120–4.  
254. Klein MC, Kelly A, Kaczorowski J, et al. The effect of family physician timing of maternal  
admission on procedures in labour and maternal and infant morbidity. Journal of Obstetrics and Gynaecology Canada. 2004;26(7):641–5.  
255. Bailit JL, Dierker L, Blanchard MH, et al. Outcomes of women presenting in active versus  
latent phase of spontaneous labor. Obstetrics and Gynecology. 2005;105(1):77–9.  
256. Kilpatrick SJ, Laros RK. Characteristics of normal labor. Obstetrics and Gynecology.  
1989;74(1):85–7.  
257. Chelmow D, Kilpatrick SJ, Laros RK Jr. Maternal and neonatal outcomes after prolonged  
latent phase. Obstetrics and Gynecology. 1993;81(4):486–91.  
258. Friedman EA. The graphic analysis of labor. American Journal of Obstetrics and  
Gynecology. 1954;68(6):1568–75.  
259. Gross MM, Drobnic S, Keirse MJN. Influence of fixed and time-dependent factors on  
duration of normal first stage labor. Birth. 2005;32(1):27–33.  
260. Chamberlain G, Steer P. Turnbull’s Obstetrics. 3rd ed. London: Harcourt; 2001.  
261. Albers LL, Schiff M, Gorwoda JG. The length of active labor in normal pregnancies.  
Obstetrics and Gynecology. 1996;87(3):355–9.  
262. Albers LL. The duration of labor in healthy women. Journal of Perinatology. 1999;19(2):114–19.  
263. Zhang J, Troendle JF, Yancey MK. Reassessing the labor curve in nulliparous women.  
American Journal of Obstetrics and Gynecology. 2002;187(4):824–8.  
264. Lederman RP, Lederman E, Work BA Jr, et al. The relationship of maternal anxiety, plasma  
catecholamines, and plasma cortisol to progress in labor. American Journal of Obstetrics and Gynecology. 1978;132(5):495–500.  
265. Sharma V, Smith A, Khan M. The relationship between duration of labour, time of  
delivery, and puerperal psychosis. Journal of Affective Disorders. 2004;83(2–3):215–20.  
266. Mahon TR, Chazotte C, Cohen WR. Short labor: characteristics and outcome. Obstetrics  
and Gynecology. 1994;84(1):47–51.  
267. Abitbol MM, Castillo I, Udom-Rice I, et al. Maternal complications following prolonged or  
arrested labor. Journal of Maternal-Fetal Investigation. 1994;4(1):9–13.  
268. Lavender T, Hart A, Walkinshaw S, et al. Progress of first stage of labour for multiparous  
women: an observational study. BJOG: an international journal of obstetrics & gynaecology. 2005;112(12):1663–5.  
269. Abukhalil IH, Kilby MD, Aiken J, et al. Can the frequency of vaginal examinations influence  
the duration of labour? A prospective randomised study. Journal of Obstetrics and Gynaecology. 1996;16(1):22–5.  
270. Ahlden S, Andersch B, Stigsson L, et al. Prediction of sepsis neonatorum following a full-  
term pregnancy. Gynecologic and Obstetric Investigation. 1988;25(3):181–5. [PubMed]  
271. Seaward PG, Hannah ME, Myhr TL, et al. International multicenter term PROM study: evaluation of predictors of neonatal infection in infants born to patients with premature rupture of membranes at term. Premature Rupture of the Membranes. American Journal of Obstetrics and Gynecology. 1998;179(3 Pt 1):635–9. [PubMed]  
272. World Health Organization partograph in management of labour. World Health  
Organization Maternal Health and Safe Motherhood Programme. Lancet. 1994;343(8910):1399–404.  
273. Lavender T, Alfirevic Z, Walkinshaw S. Partogram action line study: a randomised trial.  
BJOG: an international journal of obstetrics & gynaecology. 1998;105(9):976–80.  
274. Pattinson RC, Howarth GR, Mdluli W, et al. Aggressive or expectant management of labour: a randomised clinical trial. BJOG: an international journal of obstetrics & gynaecology. 2003;110(5):457–61.  
275. Lavender T, Alfirevic Z, Walkinshaw S. Effect of different partogram action lines on birth outcomes: A randomized controlled trial. Obstetrics and Gynecology. 2006;108(2):295–302. [PubMed] 276. Reveiz LGH, Cuervo LG. Enemas durante el trabajo de parto Revision Cochrane traducida. In: La Biblioteca Chchrane Plus, 2008;Numero 1.Oxford: Update Software Ltd. Disponível em: http://www.update-software.com. Traducida de The Cochrane Library, 2008 Issue 1. Chichester, UK: John Wiley& Sons, Ltd.  
277. Basevi V, Lavender T. Rasurado perineal sistematico en el ingreso a la sala de partos Revision Cochrane traducida. En: La Biblioteca Cochrane Plus,2008 Numero 2 Oxford: Update Software Ltd Disponível em: http://www.update-software.com Traducida de The Cochrane Library, 2008;Issue 2. Chichester,UK: John Wiley & Sons, Ltd.  
278. Cammu H, Van Eeckhout E. A randomised controlled trial of early versus delayed use of amniotomy and oxytocin infusion in nulliparous labour. BJOG: an international journal of obstetrics & gynaecology. 1996;103(4):313–18.  
279. Lopez-Zeno JA, Peaceman AM, Adashek JA, et al. A controlled trial of a program for the active management of labor. New England Journal of Medicine. 1992;326(7):450–4.  
280. Cohen GR, O’Brien WF, Lewis L, et al. A prospective randomized study of the aggressive  
management of early labor. American Journal of Obstetrics and Gynecology. 1987;157(5):1174–7.  
281. Simkin PP, O’Hara M. Nonpharmacologic relief of pain during labor: systematic reviews of  
five methods. American Journal of Obstetrics and Gynecology. 2002;186(5 Suppl):S131–59. [PubMed]  
282. Bloom SL, McIntire DD, Kelly MA, et al. Lack of effect of walking on labor and delivery.  
New England Journal of Medicine. 1998;339(2):76–9. [PubMed] Intrapartum Care References  
283. MacLennan AH, Crowther C, Derham R. Does the option to ambulate during spontaneous  
labour confer any advantage or disadvantage? Journal of Maternal-Fetal Investigation. 1994;3(1):43–8. 284. Flynn AM, Kelly J, Hollins G, et al. Ambulation in labour. British Medical Journal.  
1978;2(6137):591–3. [PMC free article] [PubMed]  
285. Molina FJ, Sola PA, Lopez E, et al. Pain in the first stage of labor: relationship with the  
patient’s position. Journal of Pain and Symptom Management. 1997;13(2):98–103. [PubMed]  
286. Andrews CM, Chrzanowski M. Maternal position, labor, and comfort. Applied Nursing  
Research. 1990;3(1):7–13. [PubMed]  
287. Fraser WD, Turcot L, Krauss I, Brisson-Carrol G. Cochrane Database of Systematic Reviews. 2. Oxford: Update Software; 2005. Amniotomy for shortening spontaneous labour. (Cochrane  
Review).  
288. Rouse DJ, McCullough C, Wren AL, et al. Active-phase labor arrest: a randomized trial of  
chorioamnion management. Obstetrics and Gynecology. 1994;83(6):937–40. [PubMed]  
289. Cardozo L, Pearce JM. Oxytocin in active-phase abnormalities of labor: a randomized  
study. Obstetrics and Gynecology. 1990;75(2):152–7. [PubMed]  
290. Bidgood KA, Steer PJ. A randomized control study of oxytocin augmentation of labour. 1.  
Obstetric outcome. BJOG: an international journal of obstetrics & gynaecology. 1987;94(6):512–17. 291. Blanch G, Lavender T, Walkinshaw S, et al. Dysfunctional labour: A randomised trial.  
BJOG: an international journal of obstetrics & gynaecology. 1998;105(1):117–20.  
292. Merrill DC, Zlatnik FJ. Randomized, double-masked comparison of oxytocin dosage in  
induction and augmentation of labor. [see comments] Obstetrics and Gynecology. 1999;94(3):455–63. 293. Xenakis EM, Langer O, Piper JM, et al. Low-dose versus high-dose oxytocin augmentation  
of labor--a randomized trial. American Journal of Obstetrics and Gynecology. 1995;173(6):1874–8. [PubMed]  
294. Jamal A, Kalantari R. High and low dose oxytocin in augmentation of labor. International  
Journal of Gynaecology and Obstetrics. 2004;87(1):6–8.  
295. Majoko F. Effectiveness and safety of high dose oxytocin for augmentation of labour in  
nulliparous women. [Erratum appears in Cent Afr J Med 2002;48(5–6):74] Central African Journal of Medicine. 2001;47(11–12):247–50. [PubMed] 296. Satin AJ, Leveno KJ, Sherman L, et al. High-dose oxytocin: 20- versus 40-minute dosage  
interval. Obstetrics and Gynecology. 1994;83(2):234–8. [PubMed]  
297. Lazor LZ, Philipson EH, Ingardia CJ, et al. A randomized comparison of 15- and 40-minute  
dosing protocols for labor augmentation and induction. Obstetrics and Gynecology. 1993;82(6):1009– 12. 298. Cummiskey KC, Gall SA, Yusoff DM. Pulsatile administration of oxytocin for augmentation  
of labor. Obstetrics and Gynecology. 1989;74(6):869–72.  
299. Arulkumaran S, Yang M, Ingemarsson PS, et al. Augmentation of labour: does oxytocin  
titration to achieve preset active contraction area values produce better obstetric outcome? AsiaOceania Journal of Obstetrics and Gynaecology. 1989;15(4):333–7.  
300. Gupta JK, Hofmeyr GJ. Cochrane Database of Systematic Reviews. Oxford: Update  
Software; 2005. Position in the second stage of labour for women without peridural anaesthesia. (Cochrane Review).  
301. Moon JM, Smith CV, Rayburn WF. Perinatal outcome after a prolonged second stage of  
labor. Journal of Reproductive Medicine. 1990;35(3):229–31.  
302. Ragnar I, Altman D, Tyden T, et al. Comparison of the maternal experience and duration  
of labour in two upright delivery positions – A randomised controlled trial. BJOG: an international journal of obstetrics & gynaecology. 2006;113(2):165–70.  
303. Woodward J, Kelly SM. A pilot study for a randomised controlled trial of waterbirth versus  
land birth. BJOG: an international journal of obstetrics & gynaecology. 2004;111(6):537–45. 304. Gilbert RE, Tookey PA. Perinatal mortality and morbidity among babies delivered in  
water: surveillance study and postal survey. British Medical Journal. 1999;319(7208):483–7. [PMC free article]  
305. Bloom SL, Casey BM, Schaffer JI, et al. A randomized trial of coached versus uncoached  
maternal pushing during the second stage of labor. American Journal of Obstetrics and Gynecology. 2006;194(1):10–13.  
306. Schaffer JI, Bloom SL, Casey BM, et al. A randomized trial of the effects of coached vs uncoached maternal pushing during the second stage of labor on postpartum pelvic floor structure and function. American Journal of Obstetrics and Gynecology. 2005;192(5):1692–6.  
307. Parnell C, Langhoff-Roos J, Iversen R, et al. Pushing method in the expulsive phase of labor. A randomized trial. Acta Obstetricia et Gynecologica Scandinavica. 1993;72(1):31–5.  
308. Thomson AM. Pushing techniques in the second stage of labour. Journal of Advanced Nursing. 1993;18(2):171–7.  
309. Knauth DG, Haloburdo EP. Effect of pushing techniques in birthing chair on length of second stage of labor. Nursing Research. 1986;35(1):49–51.  
310. Cox J, Cotzias CS, Siakpere O, Osuagwu FI, Holmes EP, Paterson-Brown S. Does an inflatable obstetric belt facilitate spontaneous vaginal delivery in nulliparae with peridural analgesia? British Journal of Obstetrics & Gynaecology 1999;106(12):1280-6.  
311. Api O, Balcin ME, Ugurel V, Api M, Turan C, Unal O. The effect of uterine fundal pressure on the duration of the second stage of labor: a randomized controlled trial. Acta Obstet Gynecol Scand 2009;88(3):320-4.  
312. Verheijen EC, Raven JH, Hofmeyr GJ. Fundal pressure during the second stage of labour. Cochrane database of Systematic Reviews. Issue 4 Art No: CD006067 DOI: 10 1002/14651858 CD006067 pub2 2009.  
313. Cheng YW, Hopkins LM, Caughey AB. How long is too long: does a prolonged second stage of labor in nulliparous women affect maternal and neonatal outcomes? American Journal of Obstetrics and Gynecology. 2004;191(3):933–8.  
314. Myles TD, Santolaya J. Maternal and neonatal outcomes in patients with a prolonged second stage of labor. Obstetrics and Gynecology. 2003;102(1):52–8.  
315. Janni W, Schiessl B, Peschers U, et al. The prognostic impact of a prolonged second stage of labor on maternal and fetal outcome. Acta Obstetricia et Gynecologica Scandinavica. 2002;81(3):214– 21.  
316. Kuo YC, Chen CP, Wang KG. Factors influencing the prolonged second stage and the effects on perinatal and maternal outcomes. Journal of Obstetrics and Gynaecology Research. 1996;22(3):253–7.  
317. Menticoglou SM, Manning F, Harman C, et al. Perinatal outcome in relation to secondstage duration. American Journal of Obstetrics and Gynecology. 1995;173(3 Part 1):906–12. [PubMed]  
318. Saunders NS, Paterson CM, Wadsworth J. Neonatal and maternal morbidity in relation to the length of the second stage of labour. BJOG: an international journal of obstetrics & gynaecology. 1992;99(5):381–5.  
319. Paterson CM, Saunders NS, Wadsworth J. The characteristics of the second stage of labour in 25,069 singleton deliveries in the North West Thames Health Region, 1988. BJOG: an international journal of obstetrics & gynaecology. 1992;99(5):377–80.  
320. van Kessel K, Reed S, Newton K, et al. The second stage of labor and stress urinary incontinence. American Journal of Obstetrics and Gynecology. 2001;184(7):1571–5. [PubMed]  
321. Moon JM, Smith CV, Rayburn WF. Perinatal outcome after a prolonged second stage of labor. Journal of Reproductive Medicine. 1990;35(3):229–31.  
322. Cohen WR. Influence of the duration of second stage labor on perinatal outcome and puerperal morbidity. Obstetrics and Gynecology. 1977;49(3):266–9.  
323. Johanson RB, Menon V. Cochrane Database of Systematic Reviews. 2. Oxford: Update  
Software; 2000. Vacuum extraction versus forceps for assisted vaginal delivery. (Cochrane Review).  
324. Weerasekera DS, Premaratne S. A randomised prospective trial of the obstetric forceps  
versus vacuum extraction using defined criteria. Journal of Obstetrics and Gynaecology. 2002;22(4):344– 5. [PubMed]  
325. Mustafa R, Mustafa R. Perinatal and maternal outcome in ventouse versus forceps  
delivery. Journal of the College of Physicians and Surgeons Pakistan. 2002;12(6):345–8.  
326. Fitzpatrick M, Behan M, O’Connell PR, et al. Randomised clinical trial to assess anal  
sphincter function following forceps or vacuum assisted vaginal delivery. BJOG: an international journal of obstetrics & gynaecology. 2003;110(4):424–9. [PubMed]  
327. Johanson RB, Heycock E, Carter J, et al. Maternal and child health after assisted vaginal delivery: Five-year follow up of a randomised controlled study comparing forceps and ventouse. BJOG: an international journal of obstetrics & gynaecology. 1999;106(6):544–9.  
328. Sultan AH, Johanson RB, Carter JE. Occult anal sphincter trauma following randomized  
forceps and vacuum delivery. International Journal of Gynaecology and Obstetrics. 1998;61(2):113–19. [PubMed]  
329. Johanson R, Pusey J, Livera N, et al. North Staffordshire/Wigan assisted delivery trial.  
BJOG: an international journal of obstetrics & gynaecology. 1989;96(5):537–44.  
330. Carmody F, Grant A, Mutch L. Follow up of babies delivered in a randomized controlled  
comparison of vacuum extraction and forceps delivery. Acta Obstetricia et Gynecologica Scandinavica. 1986;65(7):763–6. [PubMed]  
331. Pusey J, Hodge C, Wilkinson P, et al. Maternal impressions of forceps or the Silc-cup.  
BJOG: an international journal of obstetrics & gynaecology. 1991;98(5):487–8.  
332. Garcia J, Anderson J, Vacca A. Views of women and their medical and midwifery  
attendants about instrumental delivery using vacuum extraction and forceps. Journal of Psychosomatic Obstetrics and Gynecology. 1985;4(1):1–9.  
333. Johanson RB, Rice C, Doyle M, et al. A randomised prospective study comparing the new  
vacuum extractor policy with forceps delivery. BJOG: an international journal of obstetrics & gynaecology. 1993;100(6):524–30.  
334. Johanson R, Menon V. Cochrane Database of Systematic Reviews. 2. Oxford: Update  
Software; 2000. Soft versus rigid vacuum extractor cups for assisted vaginal delivery. (Cochrane Review). 335. Murphy DJ, Liebling RE, Verity L, et al. Early maternal and neonatal morbidity associated  
with operative delivery in second stage of labour: a cohort study. Lancet. 2001;358(9289):1203–7. [PubMed]  
336. Stamp G, Kruzins G, Crowther C. Perineal massage in labour and prevention of perineal  
trauma: randomised controlled trial. British Medical Journal. 2001;322(7297):1277–80. [PMC free article] [PubMed]  
337. Albers LL, Anderson D, Cragin L, et al. Factors related to perineal trauma in childbirth.  
Journal of Nurse-Midwifery. 1996;41(4):269–76. [PubMed]  
338. Dahlen HG, Homer CS, Cooke M, Upton AM, Nunn R, Brodrick B. Perineal outcomes and  
maternal comfort related to the application of perineal warm packs in the second stage of labor: a  
randomized controlled trial. Birth 2007;34(4):282-90.  
339. McCandlish R, Bowler U, van Asten H, et al. A randomised controlled trial of care of the perineum during second stage of normal labour. BJOG: an international journal of obstetrics & gynaecology. 1998;105(12):1262–72.  
340. Mayerhofer K, Bodner-Adler B, Bodner K, et al. Traditional care of the perineum during  
birth. A prospective, randomized, multicenter study of 1,076 women. Journal of Reproductive Medicine. 2002;47(6):477–82.  
341. Albers LL, Sedler KD, Bedrick EJ, et al. Midwifery care measures in the second stage of labor and reduction of genital tract trauma at birth: A randomized trial. Journal of Midwifery and Women’s Health. 2005;50(5):365–72.  
342. Sanders J, Peters TJ, Campbell R. Does lidocaine spray reduce perineal pain during spontaneous vaginal delivery? A randomised controlled trial. Current Controlled Trials. 2006. [ www.controlled-trials.com/isrctn/trial/ISRCTN99732966/0/99732966.html]  
343. Laine K, Pirhonen T, Rolland R, Pirhonen J. Decreasing the incidence of anal sphincter tears during delivery. Obstet Gynecol 2008;111(5):1053-7.  
344. Carroli G, Belizan J. Cochrane Database of Systematic Reviews. 3. Oxford: Update Software; 1998. Episiotomy for vaginal birth. (Cochrane Review).  
345. Hartmann K, Viswanathan M, Palmieri R, et al. Outcomes of routine episiotomy: a  
- systematic review. JAMA: the Journal of the American Medical Association. 2005;293(17):2141–8. [PubMed]  
346. Dannecker C, Hillemanns P, Strauss A, et al. Episiotomy and perineal tears presumed to be imminent: randomized controlled trial. Acta Obstetricia et Gynecologica Scandinavica. 2004;83(4):364–8.  
347. Andrews V, Sultan AH, Thakar R, et al. Risk factors for obstetric anal sphincter injury: a prospective study. Birth. 2006;33(2):117–22.  
348. Prendiville,W.J., Harding,J.E., Elbourne,D.R., Stirrat,G.M., The Bristol third stage trial: active versus physiological management of third stage of labour, BMJ, 297, 1295-1300, 1988  
349. Rogers,J., Wood,J., McCandlish,R., Ayers,S., Truesdale,A., Elbourne,D., Active versus expectant management of third stage of labour: the Hinchingbrooke randomised controlled trial, Lancet, 351, 693-699, 1998  
350. Thilaganathan,B., Cutner,A., Latimer,J., Beard,R., Management of the third stage of labour in women at low risk of postpartum haemorrhage, European Journal of Obstetrics, Gynecology, and Reproductive Biology, 48, 19-22, 1993  
351. de Groot,A.N., van,Roosmalen J., van Dongen,P.W., Borm,G.F., A placebo-controlled trial of oral ergometrine to reduce postpartum hemorrhage, Acta Obstetricia et Gynecologica Scandinavica, 75, 464-468, 1996  
352. McDonald,Susan J., Abbott,Jo M., Higgins,Shane P., Prophylactic ergometrine-oxytocin versus oxytocin for the third stage of labour, Cochrane Database of Systematic Reviews, -, 2009  
353. Jahazi,A., Kordi,M., Mirbehbahani,N.B., Mazloom,S.R., The effect of early and late  
umbilical cord clamping on neonatal hematocrit, Journal of Perinatology, 28, 523-525, 2008  
354. Jaleel,R., Deeba,F., Khan,A., Timing of umbilical cord clamping and neonatal  
haematological status, JPMA - Journal of the Pakistan Medical Association, 59, 468-470, 2009 355. McDonald,Susan J., Middleton,Philippa, Effect of timing of umbilical cord clamping of  
term infants on maternal and neonatal outcomes, Cochrane Database of Systematic Reviews, , -, 2013  
356. Andersson,O., Hellstrom-Westas,L., Andersson,D., Domellof,M., Effect of delayed versus early umbilical cord clamping on neonatal outcomes and iron status at 4 months: a randomised controlled trial, BMJ, 343, d7157-, 2011  
357. Gilbert L, Porter W, Brown VA. Postpartum haemorrhage--a continuing problem. BJOG: an international journal of obstetrics & gynaecology. 1987;94(1):67–71.  
358. Henry A, Birch M-R, Sullivan EA, et al. Primary postpartum haemorrhage in an Australian tertiary hospital: A case-control study. Australian and New Zealand Journal of Obstetrics and Gynaecology. 2005;45(3):233–6. [PubMed]  
359. Bais JMJ, Eskes M, Pel M, et al. Postpartum haemorrhage in nulliparous women: incidence and risk factors in low and high risk women. A Dutch population-based cohort study on standard (> or = 500 ml) and severe (> or = 1000 ml) postpartum haemorrhage. European Journal of Obstetrics, Gynecology and Reproductive Biology. 2004;115(2):166–72.  
360. Chichakli LO, Atrash HK, MacKay AP, et al. Pregnancy-related mortality in the United States due to hemorrhage: 1979–1992. Obstetrics and Gynecology. 1999;94(5):721–5. [PubMed]  
361. Hall MH, Halliwell R, Carr-Hill R. Concomitant and repeated happenings of complications of the third stage of labour. BJOG: an international journal of obstetrics & gynaecology. 1985;92(7):732– 8.  
362. Magann EF, Evans S, Hutchinson M, et al. Postpartum hemorrhage after vaginal birth: An analysis of risk factors. Southern Medical Journal. 2005;98(4):419–22. [PubMed]  
363. Stones RW, Paterson CM, Saunders NJ. Risk factors for major obstetric haemorrhage. European Journal of Obstetrics, Gynecology and Reproductive Biology. 1993;48(1):15–18.  
364. Ogueh O, Morin L, Usher RH, et al. Obstetric implications of low-lying placentas  
diagnosed in the second trimester. International Journal of Gynaecology and Obstetrics. 2003;83(1):11– 17.  
365. Usha Kiran TS, Hemmadi S, Bethel J, et al. Outcome of pregnancy in a woman with an increased body mass index. BJOG: an international journal of obstetrics & gynaecology. 2005;112(6):768–72.  
366. Robinson HE, O’Connell CM, Joseph KS, et al. Maternal outcomes in pregnancies complicated by obesity. Obstetrics and Gynecology. 2005;106(6):1357–64.  
367. 581. Sebire NJ, Jolly M, Harris JP, et al. Maternal obesity and pregnancy outcome: A study of 287,213 pregnancies in London. International Journal of Obesity. 2001;25(8):1175–82.  
368. Sebire NJ, Jolly M, Harris J, et al. Is maternal underweight really a risk factor for adverse pregnancy outcome? A population-based study in London. BJOG: an international journal of obstetrics & gynaecology. 2001;108(1):61–6.  
369. Olesen AW, Westergaard JG, Olsen J. Perinatal and maternal complications related to postterm delivery: a national register-based study, 1978–1993. American Journal of Obstetrics and Gynecology. 2003;189(1):222–7.  
370. Jolly MC, Sebire NJ, Harris JP, et al. Risk factors for macrosomia and its clinical consequences: A study of 350,311 pregnancies. European Journal of Obstetrics, Gynecology and Reproductive Biology. 2003;111(1):9–14.  
371. Stotland NE, Caughey AB, Breed EM, et al. Risk factors and obstetric complications associated with macrosomia. [Erratum appears in Int J Gynaecol Obstet 2005;90(1):88] International  
- Journal of Gynaecology and Obstetrics. 2004;87(3):220–6. 372. Jolly M, Sebire N, Harris J, et al. The risks associated with pregnancy in women aged 35  
- years or older. Human Reproduction. 2000;15(11):2433–7. [PubMed]  
373. Ohkuchi A, Onagawa T, Usui R, et al. Effect of maternal age on blood loss during  
parturition: a retrospective multivariate analysis of 10,053 cases. Journal of Perinatal Medicine. 2003;31(3):209–15.  
374. Bugg GJ, Atwal GS, Maresh M. Grandmultiparae in a modern setting. BJOG: an international journal of obstetrics & gynaecology. 2002;109(3):249–53.  
375. Henson GL, Knott PD, Colley NV. The dangerous multipara: Fact or fiction? Journal of  
Obstetrics and Gynaecology. 1987;8(2):130–4.  
376. Humphrey MD. Is grand multiparity an independent predictor of pregnancy risk? A  
retrospective observational study. Medical Journal of Australia. 2003;179(6):294–6.  
377. Toohey JS, Keegan KA Jr, Morgan MA, et al. The ‘dangerous multipara’: Fact or fiction?  
American Journal of Obstetrics and Gynecology. 1995;172(2 I):683–6.  
378. Yasmeen S, Danielsen B, Moshesh M, et al. Is grandmultiparity an independent risk factor  
for adverse perinatal outcomes? Journal of Maternal-Fetal and Neonatal Medicine. 2005;17(4):277–80.  
379. Irvine LM, Otigbah C, Crawford A, et al. Grand multiparity – An obstetric problem in Great  
Britain in the 90s? Journal of Obstetrics and Gynaecology. 1996;16(4):217–23.  
380. Bullarbo M, Tjugum J, Ekerhovd E. Sublingual nitroglycerin for management of retained  
placenta. International Journal of Gynecology and Obstetrics. 2005;91(3):228–32.  
381. Harara,R., Hanafy,S., Zidan,M.S., Alberry,M., Intraumbilical injection of three different  
uterotonics in the management of retained placenta, Journal of Obstetrics and Gynaecology Research, 37, 1203-1207, 2011  
382. Nardin,J.M., Weeks,A., Carroli,G. Umbilical vein injection for management of retained placenta. [Update of Cochrane Database Syst Rev. 2001;(4):CD001337; PMID: 11687109], Cochrane Database of Systematic Reviews, 5, CD001337-, 2011  
383. van Beekhuizen,H.J., de Groot,A.N., De Boo T., Burger,D., Jansen,N., Lotgering,F.K. Sulprostone reduces the need for the manual removal of the placenta in patients with retained placenta: a randomized controlled trial, American Journal of Obstetrics and Gynecology, 194, 446-450, 2006  
384. van Beekhuizen,H., Tarimo,V., Pembe,A.B., Fauteck,H., Lotgering,F.K., A randomized controlled trial on the value of misoprostol for the treatment of retained placenta in a low-resource setting, International Journal of Gynecology and Obstetrics, 122, 234-237, 2013  
385. Visalyaputra,S., Prechapanich,J., Suwanvichai,S., Yimyam,S., Permpolprasert,L., Suksopee,P., Intravenous nitroglycerin for controlled cord traction in the management of retained placenta, International Journal of Gynaecology and Obstetrics, 112, 103-106, 2011  
386. van Stralen G., Veenhof,M., Holleboom,C., van,Roosmalen J., No reduction of manual removal after misoprostol for retained placenta: a double-blind, randomized trial, Acta Obstetricia et Gynecologica Scandinavica, 92, 398-403, 2013  
387. Samanta,A., Roy,S.G., Mistri,P.K., Mitra,A., Pal,R., Naskar,A., Bhattacharya,S.K., Pal,P.P., Pande,A., Efficacy of intra-umbilical oxytocin in the management of retained placenta: a randomized controlled trial, Journal of Obstetrics and Gynaecology Research, 39, 75-82, 2013  
388. Lim,P.S., Singh,S., Lee,A., Muhammad Yassin,M.A., Umbilical vein oxytocin in the  
management of retained placenta: an alternative to manual removal of placenta?, Archives of Gynecology and Obstetrics, 284, 1073-1079, 2011  
389. Demott K, Bick D, Norman R, Ritchie G, Turnbull N, Adams C, Barry C, Byrom S, Elliman D, Marchant S, Mccandlish R, Mellows H, Neale C, Parkar M, Tait P, Taylor C, (2006) Clinical Guidelines And Evidence Review For Post Natal Care: Routine Post Natal Care Of Recently Delivered Women And Their Babies. London: National Collaborating Centre For Primary Care And Royal College Of General Practitioners.  
390. Royal College of Obstetricians and Gynaecologists. Green Top Guideline No. 15. London: RCOG Press; 1998. Peritoneal closure; pp. 1–6.  
391. Andrews V, Thakar R, Sultan AH, et al. Clinical issues. Can hands-on perineal repair courses affect clinical practice? British Journal of Midwifery. 2005;13(9):562–6.  
392. Andrews V, Sultan AH, Thakar R, et al. Occult anal sphincter injuries—myth or reality?  
BJOG: an international journal of obstetrics & gynaecology. 2006;113(2):195–200. [PubMed]  
393. Groom KM, Paterson-Brown S. Can we improve on the diagnosis of third degree tears?  
European Journal of Obstetrics, Gynecology and Reproductive Biology. 2002;101(1):19–21.  
394. Fleming VE, Hagen S, Niven C. Does perineal suturing make a difference? The SUNS trial.  
BJOG: an international journal of obstetrics & gynaecology. 2003;110(7):684–9.  
395. Kettle C, Johanson RB. Cochrane Database of Systematic Reviews. 1. Oxford: Update  
Software; 2006. Continuous versus interrupted sutures for perineal repair. (Cochrane Review).  
396. Kettle C, Hills RK, Jones P, et al. Continuous versus interrupted perineal repair with  
standard or rapidly absorbed sutures after spontaneous vaginal birth: a randomised controlled trial. Lancet. 2002;359(9325):2217–23.  
397. Gordon B, Mackrodt C, Fern E, et al. The Ipswich Childbirth Study: 1. A randomised evaluation of two stage postpartum perineal repair leaving the skin unsutured. BJOG: an international journal of obstetrics & gynaecology. 1998;105:435–40.  
398. Grant A, Gordon B, Mackrodat C, et al. The Ipswich childbirth study: one year follow up of  
alternative methods used in perineal repair. BJOG: an international journal of obstetrics & gynaecology. 2001;108(1):34–40.  
399. Oboro VO, Tabowei TO, Loto OM, et al. A multicentre evaluation of the two-layered repair of postpartum perineal trauma. Journal of Obstetrics and Gynaecology. 2003;23(1):5–8.  
400. Kettle C, Hills RK, Ismail KMK. Suturas continuas versus interrumpidas para la reparacion de la episiotomia o los desgarros de segundo grado (Revision Cochrane traducida). In: La Biblioteca Cochrane Plus, 2008 Numero 1 OxfORd: Update Software Ltd Disponível em: http://www updatesoftware com (Traducida de The Cochrane Library, 2008 Issue 1 Chichester, UK: John Wiley & Sons, Ltd ) 2008.  
401. Verspyck E, Sentilhes L, Roman H, Sergent F, Marpeau L. [Episiotomy techniques]. J Gynecol Obstet Biol Reprod (Paris) 2006;35(1 Suppl):1S40-51.  
402. Kindberg S, Stehouwer M, Hvidman L, Henriksen TB. Postpartum perineal repair performed by midwives: a randomised trial comparing two suture techniques leaving the skin unsutured. BJOG 2008;115(4):472-9.  
403. Upton A, Roberts CL, Ryan M, et al. A randomised trial, conducted by midwives, of perineal repairs comparing a polyglycolic suture material and chromic catgut. Midwifery. 2002;18(3):223–9. [PubMed]  
404. Greenberg JA, Lieberman E, Cohen AP, et al. Randomized comparison of chromic versus fast-absorbing polyglactin 910 for postpartum perineal repair. Obstetrics and Gynecology. 2004;103(6):1308–13.  
405. Kettle C, Hills RK, Jones P, et al. Continuous versus interrupted perineal repair with standard or rapidly absorbed sutures after spontaneous vaginal birth: a randomised controlled trial. Lancet. 2002;359(9325):2217–23. [PubMed]  
406. Hedayati H, Parsons J, Crowther CA. Cochrane Database of Systematic Reviews. 3. Oxford: Update Software; 2003. Rectal analgesia for pain from perineal trauma following childbirth. (Cochrane Review).  
407. Dodd JM, Hedayati H, Pearce E, et al. Rectal analgesia for the relief of perineal pain after childbirth: a randomised controlled trial of diclofenac suppositories. BJOG: an international journal of obstetrics & gynaecology. 2004;111(10):1059–64. 408. BRASIL – MS/SVS/DASIS – Sistema de Informações sobre Nascidos Vivos - SINASC NASCIDOS VIVOS – BRASIL. Nascim p/resid. mãe segundo Região. Disponível em <http://tabnet.datasus.gov.br/cgi/tabcgi.exe?sinasc/cnv/nvuf.def>. acessos em 24 nov. 2015  
409. BRASIL. MINISTÉRIO DA SAÚDE. SECRETARIA DE VIGILÂNCIA EM SAÚDE. DEPARTAMENTO DE ANÁLISE DA SITUAÇÃO EM SAÚDE. Mortalidade infantil no Brasil: tendências, componentes e causas de morte no período de 2000 a 2010. Saúde Brasil 2011: uma análise da situação de saúde e a vigilância da saúde da Mulher. Brasília: Editora do Ministério da Saúde, 2012b, 305r. 163-182.  
410. BRASIL. MINISTÉRIO DA SAÚDE. SECRETARIA DE ASSISTÊNCIA A SAÚDE. Portaria Nº 371, de 7 de maio de 2014. Disponível em <http://bvsms.saude.gov.br/bvs/saudelegis/sas/2014/prt0371_07_05_2014.html>. acesso em 22 dez. 2015.  
411. BRASIL. MINISTÉRIO DA SAÚDE. SECRETARIA DE ASSISTÊNCIA A SAÚDE. DEPARTAMENTO DE AÇÕES PROGRAMÁTICAS E ESTRATÉGICAS. COORDENAÇÃO GERAL DE SAÚDE DA CRIANÇA E ALEITAMENTO MATERNO. Nota técnica 16/2014. Disponível em <http://www.sbp.com.br/src/uploads/2014/08/PortariaMS371-NotaTecnica_SAS16-em-10junho2014Atendimento-RN-ao-nascimento.pdf>. acesso em 22 dez. 2015.  
412. Apgar V. Proposal for new method of evaluation of newborn infant. Anesthesia and Analgesia. 1953;32:260–7.  
413. van de Riet JE, Vandenbussche FP, Le Cessie S, et al. Newborn assessment and long-term adverse outcome: a systematic review. American Journal of Obstetrics and Gynecology. 1999;180(4):1024–9. [PubMed]  
414. Chong DS, Karlberg J. Refining the Apgar score cut-off point for newborns at risk. Acta Paediatrica. 2004;93(1):53–9. [PubMed]  
415. Gaffney G, Sellers S, Flavell V, et al. Case-control study of intrapartum care, cerebral palsy, and perinatal death. British Medical Journal. 1994;308(6931):743–50. [PMC free article] [PubMed] 416. Moster D, Lie RT, Markestad T. Joint association of Apgar scores and early neonatal symptoms with minor disabilities at school age. Archives of Disease in Childhood Fetal and Neonatal Edition. 2002;86(1):F16–21. [PMC free article] [PubMed]  
417. Moster D, Lie RT, Irgens LM, et al. The association of Apgar score with subsequent death and cerebral palsy: A population-based study in term infants. Journal of Pediatrics. 2001;138(6):798– 803. [PubMed]  
418. Casey BM, McIntire DD, Leveno KJ. The continuing value of the Apgar score for the  
assessment of newborn infants. New England Journal of Medicine. 2001;344(7):467–71.  
419. Hefler,L.A., Tomovski,C., Waibel,V., Brugger,C., Heim,K., Reinthaller,A., Tempfer,C.,  
Concin,H., Umbilical arterial pH levels after delivery and adult intelligence: a hospital-based study, Acta Obstetricia et Gynecologica Scandinavica, 86, 1404-1406, 2007  
420. Keski-Nisula,L., Putus,T., Pekkanen,J., Umbilical artery pH values at birth and risk of  
asthma at 5 to 6 years of age, Journal of Investigational Allergology and Clinical Immunology, 22, 48-54, 2012  
421. Malin,G.L., Morris,R.K., Khan,K.S., Strength of association between umbilical cord pH and  
perinatal and long term outcomes: systematic review and meta-analysis. [104 refs], BMJ, 340, c1471-, 2010  
422. Svirko,E., Mellanby,J., Impey,L., The association between cord pH at birth and intellectual  
function in childhood, Early Human Development, 84, 37-41, 2008  
423. White,C.R., Doherty,D.A., Henderson,J.J., Kohan,R., Newnham,J.P., Pennell,C.E., Benefits  
of introducing universal umbilical cord blood gas and lactate analysis into an obstetric unit, Australian and New Zealand Journal of Obstetrics and Gynaecology, 50, 318-328, 2010  
424. Wiberg,N., Kallen,K., Herbst,A., Olofsson,P., Relation between umbilical cord blood pH,  
base deficit, lactate, 5-minute Apgar score and development of hypoxic ischemic encephalopathy, Acta Obstetricia et Gynecologica Scandinavica, 89, 1263-1269, 2010  
425. Wildschut,J., Feron,F.J., Hendriksen,J.G., van,Hall M., Gavilanes-Jiminez,D.W., Hadders-  
Algra,M., Vles,J.S., Acid-base status at birth, spontaneous motor behaviour at term and 3 months and neurodevelopmental outcome at age 4 years in full-term infants, Early Human Development, 81, 535544, 2005  
426. Yeh,P., Emary,K., Impey,L., The relationship between umbilical cord arterial pH and  
serious adverse neonatal outcome: analysis of 51,519 consecutive validated samples, BJOG: An International Journal of Obstetrics and Gynaecology, 119, 824-831, 2012  
427. Wiswell TE, Bent RC. Meconium staining and the meconium aspiration syndrome-  
unresolved issues. Pediatr Clin North Am 1993;40:955-80.  
428. Gungor S, Teksoz E, Ceyhan T, Kurt E, Goktolga U, Baser I. Oronasopharyngeal suction  
versus no suction in normal, term and vaginally born infants: a prospective randomised controlled trial. Aust NZ J Obstet Gynaecol 2005;45(5):453-6.  
429. Sanchez-Luna M, Pallas- Alonso C.R, Botet-Mussons F, Echaniz-Urcelay I, Castro-Conde J.R, Narbona E. Comision de estandares de la Sociedad Espanola de Neonatologia. Recomendaciones para el cuidado y atencion del recien nacido sano en el parto y en las primeras horas despues del nacimiento. An Pediatr(Barc) 2009;71(4):349-61.  
430. Goldbloom RB. Prophylaxis for gonococcal and chamydial ophtalmia neonatorum. In:  
Canadian Task Force on the Periodic Health Examination Canadian Guide to Clinical preventive Health Care Ottawa: Health Canada 1994;168-75.  
431. Dumas L, Landry I, savoie A. (Perinatal interventions. The importance of convincing data).  
Infirm Que 2002;10(2):31-6.  
432. Jimenez R. Cuidados del recien nacido normal.En: Delgado Rubio, coordinador. Protocolos  
diagnosticos y terapeuticos de neonatologia en Pediatria. (Internet).Madrid: Asociacion Española de Pediatria. [data de consulta: 24 jun 2008] Disponível em:  
http://www.aeped.es/protocolos/neonatologia/index.htm 2002.  
433. Ross, J. A. & Davies, S. M. 2000, “Vitamin K prophylaxis and childhood cancer” Medical &  
Pediatric Oncology, vol. 34, no. 6, pp. 434-437.  
434. Golding, J., Birmingham, K., Greenwood, R., & Mott, M. 1992, “Childhood cancer,  
intramuscular vitamin K, and pethidine given during labour”, BMJ, vol. 305, pp. 341-346.  
435. Roman, E., Fear, N. T., Ansell, P., Bull, D., Draper, G., McKinney, P., Michaelis, J.,  
Passmore, S. J., & von, K. R. 2002, “Vitamin K and childhood cancer: analysis of individual patient data from six case-control studies”, British Journal of Cancer, vol. 86, no. 1, pp. 63-69.  
436. Fear, N. T., Roman, E., Ansell, P., Simpson, J., Day, N., & Eden, O. B. 2003, “Vitamin K and  
childhood cancer: a report from the United Kingdom Childhood Cancer Study”, British Journal of Cancer, vol. 89, no. 7, pp. 1228-1231.  
437. Puckett, R. M. & Offringa, M. 2000, “Prophylactic vitamin K for vitamin K deficiency  
bleeding in neonates,” in Cochrane Database of Sytematic Reviews 2000, Issue 4, Chichester, John Wiley & Sons Ltd.  
438. Wariyar, U., Hilton, S., Pagan, J., Tin, W., & Hey, E. 2000, “Six years’ experience of  
prophylactic oral vitamin K”, Archives of Disease in Childhood Fetal & Neonatal Edition, vol. 82, no. 1, p. F64-F68.  
439. Croucher, C. & Azzopardi, D. 1994, “Compliance with recommendations for giving vitamin  
K to newborn infants”, BMJ, vol. 308, no. 6933, pp. 894-895.  
440. Hansen, K. N., Minousis, M., & Ebbesen, F. 2003, “Weekly oral vitamin K prophylaxis in  
Denmark”, Acta Paediatrica, vol. 92, no. 7, pp. 802-805.  
441. Department of Health 1998, Vitamin K for newborn babies, PL/CMO/98/3. London:  
Department of Health.  
442. Curtis, L. & Netten, A. 2004, Unit Costs of Health and Social Care 2004 Canterbury:  
University of Kent at Canterbury, Personal Social Services Research Unit.  
443. Vain,N.E., Szyld,E.G., Prudent,L.M., Wiswell,T.E., Aguilar,A.M., Vivas,N.I., Oropharyngeal  
and nasopharyngeal suctioning of meconium-stained neonates before delivery of their shoulders: multicentre, randomised controlled trial, Lancet, 364, 597-602, 2004  
444. Daga,S.R., Dave,K., Mehta,V., Pai,V., Tracheal suction in meconium stained infants: a  
randomized controlled study, Journal of Tropical Pediatrics, 40, 198-200, 1994  
445. Liu,W.F., Harrington,T., The need for delivery room intubation of thin meconium in the  
low-risk newborn: a clinical trial, American Journal of Perinatology, 15, 675-682, 1998  
446. Linder,N., Aranda,J.V., Tsur,M., Matoth,I., Yatsiv,I., Mandelberg,H., Rottem,M.,  
Feigenbaum,D., Ezra,Y., Tamir,I., Need for endotracheal intubation and suction in meconium-stained neonates, Journal of Pediatrics, 112, 613-615, 1988  
447. Wiswell,T.E., Gannon,C.M., Jacob,J., Goldsmith,L., Szyld,E., Weiss,K., Schutzman,D.,  
Cleary,G.M., Filipov,P., Kurlat,I., Caballero,C.L., Abassi,S., Sprague,D., Oltorf,C., Padula,M., Delivery room management of the apparently vigorous meconium-stained neonate: results of the multicenter, international collaborative trial, Pediatrics, 105, 1-7, 2000  
448. Vento,M., Asensi,M., Sastre,J., Garcia-Sala,F., Pallardo,F.V., Vina,J., Resuscitation with  
room air instead of 100% oxygen prevents oxidative stress in moderately asphyxiated term neonates, Pediatrics, 107, 642-647, 2001  
449. Vento,M., Asensi,M., Sastre,J., Lloret,A., Garcia-Sala,F., Vina,J., Oxidative stress in  
asphyxiated term infants resuscitated with 100% oxygen.[Erratum appears in J Pediatr. 2003 Jun;142(6):616], Journal of Pediatrics, 142, 240-246, 2003  
450. Vento,M., Sastre,J., Asensi,M.A., Vina,J., Room-air resuscitation causes less damage to heart and kidney than 100% oxygen, American Journal of Respiratory and Critical Care Medicine, 172, 1393-1398, 2005  
451. Bajaj,N., Udani,R.H., Nanavati,R.N., Room air vs. 100 per cent oxygen for neonatal  
resuscitation: a controlled clinical trial, Journal of Tropical Pediatrics, 51, 206-211, 2005  
452. Ramji,S., Ahuja,S., Thirupuram,S., Rootwelt,T., Rooth,G., Saugstad,O.D., Resuscitation of  
asphyxic newborn infants with room air or 100% oxygen, Pediatric Research, 34, 809-812, 1993  
453. Ramji,S., Rasaily,R., Mishra,P.K., Narang,A., Jayam,S., Kapoor,A.N., Kambo,I., Mathur,A.,  
Saxena,B.N., Resuscitation of asphyxiated newborns with room air or 100% oxygen at birth: a multicentric clinical trial, Indian Pediatrics, 40, 510-517, 2003  
454. Saugstad,O.D., Ramji,S., Irani,S.F., El-Meneza,S., Hernandez,E.A., Vento,M., Talvik,T.,  
Solberg,R., Rootwelt,T., Aalen,O.O., Resuscitation of newborn infants with 21% or 100% oxygen: followup at 18 to 24 months, Pediatrics, 112, 296-300, 2003  
455. Saugstad,O.D., Rootwelt,T., Aalen,O., Resuscitation of asphyxiated newborn infants with  
room air or oxygen: an international controlled trial: the Resair 2 study, Pediatrics, 102, e1-, 1998  
456. Dyson, Renfrew, McFadden, McCormick, Herbert and Thomas 2006, Effectiveness of  
public health interventions to promote the duration of breastfeeding: systematic review. London: National Institute for Health and Clinical Excellence.  
457. Anderson, G. C., Moore, E., Hepworth, J., & Bergman, N. 2003, “Early skin-toskin contact  
for mothers and their healthy newborn infants,” in Cochrane Database of Systematic Reviews 2003 Issue 2, Chichester, John Wiley & Sons Ltd.  
458. UM, Mustafa T, Khan MA, Linblad BS, Widstrom AM. The effects of medically orientated  
labour ward routines on prefeeding behaviour and body temperature in newborn infants. J Trop Pediatr 1995;41(6):360-3.  
459. Taylor PM, Maloni JA, Taylor FH, Campbell SB. Extra early mother-infant contact and duration of breast-feeding. Acta Paediatr Scand Suppl 1985;316(15):22.  
460. Moore ER, Anderson GC, Bergman N. Contacto piel-a-piel temprano para las madres y sus recien nacidos sanos (Revisison Cochrane traducida). In: La Biblioteca Cochrane Plus, 2008. Numero 1 Oxford: Update Software Ltd Disponível em: http://www update-software com (Traducida de The Cochrane Library, 2008 Issue 1 Chichester, UK: John Wiley & Sons, Ltd) 2008.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Anexo I – Membros do Grupo Elaborador -->
João Batista Marinho de Castro Lima (Coordenador do Grupo Elaborador)  
Médico Ginecologista e Obstetra. Diretor Clínico do Hospital Sofia Feldman. Aline Monte de Mesquita  
Especialista em Regulação da Agência Nacional de Saúde Suplementar (ANS). Coordenadora de Gestão de Tecnologias em Saúde da Gerência de Assistência à Saúde da Diretoria de Normas e Habilitação dos Produtos da ANS. Mestre em Gestão de Tecnologias em Saúde na Universidade do Estado do Rio de Janeiro- Instituto de Medicina Social.  
Bruno Carvalho Cunha de Leão  
Médico Anestesiologista. Mestre em Saúde da Mulher (UFMG). Coordenador da residência de anestesia Maternidade Odete Valadares (Fhemig).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Felipe de Araujo Bastos Vianna -->
Interno de Medicina da Universidade do Estado do Rio de Janeiro (UERJ). Estagiário de nível superior da Agência Nacional de Saúde Suplementar (ANS).

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Maria Elisa Cabanelas Pazos -->
Graduada em Medicina pela Universidade Federal Fluminense, especialista em Pediatria, Neonatologia e Saúde Pública (ENSP/Fiocruz). Formação complementar em Qualidade / Acreditação e Medicina Baseada em Evidência. Pesquisadora do Núcleo de Prática Clínica Baseada em Evidencia da Amil, tutora e membro do grupo organizador do workshop Prática Clínica Baseada em Evidencia da McMaster no Rio de Janeiro.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Mauro Blini -->
Médico Ginecologista Obstetra. Superintendente de Qualidade da Regulação da Bradesco Saúde. Membro da Comissão de Assuntos Assistenciais da FenaSaúde. Representante da FenaSaúde no Grupo Elaborador das Diretrizes.

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: Melania Maria Ramos de Amorim -->
Professora Doutora de Ginecologia e Obstetrícia da UFCG. Professora da Pós-Graduação em Saúde Materno-Infantil do IMIP

---

<!-- METADADOS: doenca: Assistência ao Parto Normal - Diretriz NacionaL | secao: <mark>Sérgio Tadeu Martins Marba</mark> -->
<mark>Professor Titular do Departamento de Pediatria da Faculdade de Ciências Médicas da Universidade Estadual de Campinas (UNICAMP). Diretor da Divisão de Neonatologia do Hospital da Mulher / UNICAMP. Consultor Nacional Neonatal e do Método Canguru da Coordenação Geral da Saúde da Criança e do Aleitamento Materno do Ministério da Saúde (CGSCAM/DAPES/MS). Assessor de Políticas Públicas da Sociedade Brasileira de Pediatria (SBP). Membro do Departamento de Neonatologia da SBP e da  Sociedade de Pediatria de São Paulo (SPSP). Membro do Grupo Executivo do Programa de Reanimação Neonatal da SBP</mark>  
Sérgio Hecker Luz Professor Adjunto da Faculdade de Medicina na PUCRS  
Sibylle Emilie Vogt  
Enfermeira obstétra do Hospital Sofia Feldman. Mestre de Enfermagem pela Universidade Federal de Minas Gerais/UFMG. Doutora em Saúde da Criança e da Mulher do Instituto Fernandes Figueira/FIOCRUZ.  
Anexo II – Membros do Comitê Executivo Ávila Teixeira Vidal  
Departamento de Gestão e Incorporação de Tecnologias no SUS – Ministério da Saúde – Secretaria Executiva da CONITEC  
Sonia Lansky Coordenação-Geral da Saúde da Mulher - Ministério da Saúde  
ANEXO III – MEMBROS DO GRUPO CONSULTIVO  
Associação Brasileira de Obstetrizes e Enfermeiros Obstetras - ABENFO Kelly Cristina Almeida Borgonove Kleyde Ventura de Souza Valdercy Herdy Virginia Leismann Moretto  
Agência Nacional de Saúde - ANS Jacqueline Torres Karla S. Coelho  
Agência Nacional de Vigilância Sanitária - ANVISA Eduardo André Viana Alves Maria Ângela da Paz Benafran J. Bezerra  
ARTEMIS Raquel Almeida Marques  
Associação Brasileira de Enfermagem - ABEn Iraci do Carmo de França Associação Médica Brasileira - AMB Antônio Jorge Salomão  
Centro Cochrane do Brasil Maria Regina Torloni  
Comissão Nacional de Incorporação de Tecnologias no SUS - CONITEC Clarice Alegre Petramale  
Conselho Federal de Enfermagem – Cofen Maria do Rosário de Fátima B. Sampaio  
Conselho Federal de Medicina – CFM Almerindo Brasil de Sousa Antonio Jorge Salomão Roberto Magliano de Morais  
Conselho Nacional de Saúde - CNS Maria do Espírito Santo dos Santos  
Coordenação-Geral de Saúde do Adolescente – Ministério da Saúde Maria da Guia  
Coordenação-Geral de Saúde das Crianças e Aleitamento Materno – Ministério da Saúde Ana Paula da Cruz Mariane Curado Borges Paulo V. Bonilha Almeida Tatyana Coimbra  
Coordenação-Geral de Saúde dos Homens - Ministério Da Saúde Michelle Leite da Silva  
Coordenação-Geral de Saúde das Mulheres - Ministério da Saúde Amanda F. de Vico Camilla Schneck Maria Esther de Albuquerque Vilela Sonia Lansky  
Departamento de Ciência e Tecnologia – Ministério da Saúde Betânia Leite Dayane Gabriele A. Silveira Nathan Mendes  
Departamento de Gestão da Incorporação de Tecnologias no SUS – Ministério da Saúde Ana Carolina de F. Lopes  
Aline S. Silva Ávila Teixeira Vidal Jorgiany Emerick Ebeidalla Roberta Buarque Rabelo Tacila Pires Vania C. Canuto Santos  
Federação Brasileira das Associações de Ginecologia e Obstetrícia - FEBRASGO Etelvino de Souza Trindade  
Federação Brasileira de Hospitais - FBH Eduardo de Oliveira João Henrique Araujo Fernandes Walter Lyrio do Valle  
Federação Nacional de Saúde Suplementar - FENASAÚDE Vera Queiros Sampaio de Souza  
Escola Nacional de Saúde Pública Sérgio Arouca – Ensp/Fiocruz Maria da Guia Leal Maria Helena Bastos GEAP - Fundação de Seguridade Social Fernando Santos Luciana Rodriguez Teixeira Silvana Souza Lima da Silva Hospital Israelita Albert Einstein Eduardo Cordioli Instituto Fernandes Figueiras – IFF/Fiocruz Maria do Carmo Leal Organização Pan-Americana da Saúde – OPAS/OMS Rodolfo Gomes Parto do Princípio Denise Yoshie Niy Deborah Rachel A. Delage Silva  
Rede pela Humanização do Parto e do Nascimento - REHUNA Daphne Rattner Ricardo H. Jones  
Sociedade Brasileira de Pediatria - SBP Dennis Burns  
Sociedade Cooperativa de Trabalho Médico - UNIMED Amilcar José Ribeiro Carvalho Jeyner Valério Junior Paulo Tarcísio Pinheiro da Silva

---

