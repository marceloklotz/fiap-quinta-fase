<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: Geral -->
Torna pública a decisão de aprovar as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 5, no âmbito do Sistema Único de Saúde - SUS.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS DO MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Ficam aprovadas as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - Capítulo 5, no âmbito do Sistema Único de Saúde - SUS.  
Art. 2º Conforme determina o art. 25 do Decreto 7.646/2011, o prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art. 3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: http://conitec.gov.br/.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: Geral -->
1  
Anexo

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Resumo metodologia capítulo Piretroides  
Para maior informação sobre metodologia consultar o arquivo de metodologia das diretrizes e anexo V.1 (perguntas PICO), anexo V.2 (Estratégia de busca) anexo V.3 (Síntese de evidencias), anexo V.4. Avaliação de recomendações e anexo V.5 (Avaliação de evidencias).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Enquanto as piretrinas são inseticidas naturais presentes em flores de crisântemo, os piretroides são inseticidas sintéticos obtidos pela modificação química desses compostos. Portanto, os piretroides apresentam maior potência, menor labilidade físico-química, modificação da meia-vida, além de outras propriedades<sup>1</sup> .  
Além de seu uso na agricultura, os piretroides têm uso importante nos programas de saúde pública. Estima-se, globalmente, que mais de 520 toneladas de ingrediente ativo desses compostos são usadas anualmente em programas de controle de vetores<sup>2</sup> .  
Os piretroides fazem parte da formulação de diversos produtos registrados para uso na agricultura, veterinária e para o tratamento de ectoparasitoses em humanos. No Brasil, segundo dados do Ministério da Agricultura, Pecuária e Abastecimento (MAPA), há 14 ingredientes ativos registrados, os quais são disponibilizados em 123 formulações comerciais diferentes<sup>3</sup> . Mesmo não tendo em nosso país uma base de dados que permita determinar exatamente  a quantidade de produtos veterinários formulados com esses compostos, segundo o “Relatório de Produtos com Licença Vigente” disponibilizado pelo MAPA, em 2014, é possível identificar mais de 50 produtos licenciados<sup>4</sup> .  
Na base dados da Agência Nacional de Vigilância Sanitária (ANVISA) é possível identificar 21 produtos farmacêuticos à base de piretroides, com registro válido, utilizados para o tratamento de ectoparasitoses humanas<sup>5</sup> .  
Em formulações comerciais, os piretroides são geralmente dissolvidos em solventes diversos. A influência do veículo de administração na toxicidade aguda por via oral implica que o veículo afeta a taxa ou extensão da absorção gastrointestinal, mas não há estudos publicados projetados especificamente para abordar esta questão. Algumas vezes, o butóxido de piperonila é adicionado a algumas das formulações comercializadas. Esse composto tem efeito sinérgico, o que aumenta a eficácia do ingrediente ativo<sup>6</sup> .  
2  
O cenário de exposição dos agrotóxicos utilizados para fins de saúde pública é bastante variável. Ele inclui desde a exposição a larvicidas em água potável até a exposição dérmica ou por inalação advinda da pulverização ou da utilização  domiciliar habitual de inseticidas apresentados em diversas formas, como por exemplo: spray, bombas de aplicação, etc.<sup>6</sup> .  
Considerando a diversidade química dos piretroides, eles são categorizados em dois grandes grupos, baseado em suas estruturas químicas: os de tipo I (estrutura de ciclopropano, como é caso da aletrina, da resmetrina, da D-fenotrina e da permetrina) e os de tipo-II (com um grupo ciano). Os compostos Tipo I são aqueles que causam tremores como efeito tóxico principal, sendo assim considerados como produtores da síndrome do envenenamento tipo I ou “Síndrome T”. Por outro lado, os compostos Tipo II causam coreoatetose e salivação (Síndrome da Coreoatetose tipo II ou “Síndrome CS”). Entretanto, cabe destacar que alguns piretroides, como é o caso da permetrina, exibem características T e CS, gerando um quadro clínico combinado das duas síndromes<sup>6,7</sup> .  
Estudos em ratos indicam que após a absorção, os piretroides são rapidamente distribuídos em todo o organismo, principalmente no tecido adiposo, estômago, intestino, fígado, rins e sistema nervoso. A sua metabolização é rápida e extensiva e envolve enzimas hepáticas diversas, sendo que os compostos parentais dificilmente são associados aos efeitos de curto e longo prazo. A sua excreção é bastante rápida, mesmo após exposições repetidas. Estima-se que 90% da dose administrada é excretada na urina e nas fezes dentro de uma semana após a exposição. Em contraste, esses inseticidas são pouco absorvidos após a exposição dérmica<sup>6,8</sup> .  
Os piretroides agem diretamente nos canais de sódio, alterando a sua permeabilidade e, consequentemente, aumentando o tempo da fase excitatória do potencial de ação. Essa é uma das características toxicodinâmicas marcantes desses compostos. Razão pela qual a correlação desses efeitos com a atividade inseticida ter sido revisada extensivamente<sup>1,9–11</sup> .  
**_Abordagem Inicial e Diagnóstico nas intoxicações agudas por piretroides_**  
**<mark>O fluxograma de atendimento e de procedimentos utilizados na abordagem inicial para</mark> o atendimento nos casos onde há suspeita de intoxicação por agrotóxicos encontra-se nos anexos apresentados na Portaria SCTIE/MS n° 43/2018, publicada em 16 de outubro de 2018**  
O diagnóstico de intoxicações agudas por piretroides é dificultado não somente pela presença de outros componentes nas formulações disponibilizadas comercialmente, como também pelo fato da sintomatologia ser semelhante à de intoxicações por outros agrotóxicos. Alguns estudos apontam que essas podem ser erroneamente diagnosticadas como sendo ocasionadas por organofosforados ou organoclorados.<sup>12,13</sup> .  
3

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Durante o acolhimento e anamnese de vítimas com suspeita de intoxicação por piretroides atente para os aspectos históricos relacionados à exposição. Estes devem ser coletados e explorados cuidadosamente visto que são considerados críticos para o delineamento do diagnóstico<sup>12,13</sup>  
Durante a avaliação inicial do paciente, colete o maior número de informações no menor tempo possível<sup>14</sup> .  
São Informações essenciais **(** ERICKSON; THOMPSON; LU, 2007) **:**  
- **_Quem?_**  
Nome, idade, ocupação, sexo, gravidez, histórico (uso de medicamentos, doenças agudas e crônicas, uso de álcool, drogas ilícitas).  
- **_O que foi utilizado e quanto?_**  
- Formulação/Nome comercial e quantidade utilizada. Verificar a disponibilidade da embalagem e bula do produto. Dada a grande variedade de formulações à base de piretroides, a identificação correta do produto permite a elaboração de estratégias direcionadas aos efeitos tóxicos relacionados ao surfactante ou aos adjuvantes presentes.  
- **_Qual a via de exposição?_**  
Via oral, dérmica, inalatória ou outras.  
- **_Onde?_**  
- Obter dados sobre o local de exposição.  
- **_Como?_**  
Determinar a circunstância na qual ocorreu a exposição ao agrotóxico, se essa foi acidental, ocupacional, tentativa de suicídio, agressão, ambiental (vazamentos ou deriva de pulverização durante a aplicação) e a intenção de uso do produto.  
- **Há quanto tempo?**  
Estabelecer o lapso temporal entre a exposição e o atendimento.  
4  
Colete informações por meio dos acompanhantes ou familiares das vítimas de intoxicações por formulações à base de piretroides, especialmente quando essas são crianças ou se encontrem com nível de consciência alterado<sup>15</sup> .  
Ligue para o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para orientações sobre suspeita de intoxicações com manifestações clínicas atípicas ou com quadros iniciais de difícil identificação.  
No site: <u>http://portal.anvisa.gov.br/disqueintoxicacao</u> estão disponíveis os números de contato dos diferentes centros de informação e assistência toxicológica da Rede Nacional de Centros de Informação e Assistência Toxicológica (Renaciat). O número gratuito do serviço Disqueintoxicação é **0800 722 6001.**  
No site http://abracit.org.br/wp/centros/ estão disponíveis os contatos dos centros de intoxicação da Associação Brasileira de Centros de Informação e Assistência Toxicológica (ABRACIT).  
Consulte também a Ficha de Informações de Segurança de Produto Químico, o rótulo, os componentes da formulação e a bula do produto para obter mais informações<sup>14</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Tal qual as demais classes de inseticidas, as intoxicações orais com piretroides são normalmente mais graves do que as decorrentes da exposição dérmica.  A biodisponibilidade desses compostos por meio da absorção gástrica é estimada como sendo de 36%, enquanto que a dérmica é de apenas 1%.<sup>6,12,16,17</sup>  
Uma das dificuldades para a determinação do prognóstico de intoxicações por piretroides relaciona-se não somente à diversidade de moléculas registradas, mas também à variabilidade de adjuvantes e à possível intoxicação com múltiplos agentes<sup>6</sup> .  
A presença de determinados solventes na formulação, como é o caso de etilenoglicol e hidrocarbonetos alifáticos e aromáticos, pode agravar os quadros de intoxicação com esses produtos. Juntamente com alguns adjuvantes, alguns solventes têm um potencial tóxico mais grave do que o inseticida em si, o qual merece atenção e deve ser considerado nos diagnósticos e no estabelecimento de condutas terapêuticas apropriadas<sup>18,19</sup> .  
5

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Tal qual as demais classes de inseticidas, as intoxicações orais com piretroides são normalmente mais graves do que as decorrentes da exposição dérmica. A biodisponibilidade desses compostos por meio da absorção gástrica é estimada como sendo de 36%, enquanto que a dérmica é de apenas 1%<sup>6,12,16,17</sup>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Nos casos suspeitos de exposição aguda a produtos contendo piretroides, independente dos demais constituintes da formulação, os seguintes sinais e sintomas são comumente observados, considerando as principais vias de exposição:  
- I. Exposição Oral<sup>9,12,16,18–21</sup>  Sialorreia  
- Dor de garganta, desconforto e dor epigástrica, náuseas, vômito, dor abdominal  
- Bradicardia ou taquicardia, hipotensão arterial, turgência jugular, parada sinusal; extra-sístole ventricular  
- Cefaleia, midríase  Bradipneia, dispneia, broncorreia, crepitações  Cianose  Cãibras musculares, fasciculação, astenia,adinamia  
- II. Dérmica<sup>2,12,18</sup>  Parestesia das áreas de contato  Eritema multiforme  Dermatite de contato  Prurido, sensação de picada, dormência, ardor na pele  
- III. Ocular<sup>8,12</sup>  Ardor e irritação local  Edema periorbital  
- IV. Respiratória<sup>22–25</sup>  Anosmia  Irritação de vias aéreas superiores, tosse, dispneia  Zumbido  Cefaleia, tontura  
6  
- Naúseas  
- Dormência de membros superiores e inferiores  
- Pneumonia eosinofílica aguda  
- Convulsões tônico-clônicas  
- Anafilaxia  
O sistema nervoso é o principal alvo da ação tóxica do piretroides, mas os efeitos no trato respiratório também são observados, a depender do tempo e da forma de exposição. O desenvolvimento de manifestações graves, tais como hemorragias maciças e edema pulmonar, podem ser observados após inalação em concentrações elevadas ou doses consideradas letais<sup>6</sup> .  
Considere a possibilidade das seguintes manifestações atípicas, principalmente nos casos de ingestão intencional de grandes quantidades de formulações contendo piretroides:  
- Insuficiência respiratória e necessidade de ventilação mecânica  
- Hipotensão (Pressão Arterial Sistólica <90 mm Hg)  
- Pneumonia eosinofílica  
- Insuficiência renal aguda (Creatinina sérica > 1,4 mg / dL)  
- Convulsões  
- Pontuação na Escala de Glasgow <15  
- Óbito  
São considerados preditores dessas manifestações a ingestão de volumes acima de 250 mL e valores de lactato sérico acima de 3,5 mmol / L<sup>17</sup>  
Considerando o risco de manifestações atípicas, nos casos de ingestão oral de formulações à base de piretroides, manter o paciente em observação por um período mínimo de 48h<sup>8,9</sup>  
Lembre-se que na exposição a piretroides de pessoas com histórico de reações de hipersensibilidade respiratória ou cutânea podem desenvolver pneumonite, asma e evoluir para óbito; ou dermatite de contato alérgica e irritante<sup>7,8,26</sup>  
7  
Alguns dos sintomas observados não são relacionados ao mecanismo de ação tóxico dos piretroides e podem ser atribuídos aos solventes presentes na formulação, outros agrotóxicos e até, em alguns casos, às circunstâncias da exposição. Há relatos do uso recreacional desses produtos como droga de abuso, provavelmente devido à presença de solventes nas formulações 6,27.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Para todos os casos suspeitos de intoxicação por formulações à base de piretroides, investigue com a vítima, com familiares ou com os que lhe prestaram o atendimento inicial, a composição exata do produto ao qual o paciente foi exposto, principalmente nos casos de ingestão intencional<sup>19</sup> .  
Cabe destacar que o tipo de veículo presente na formulação também influencia na absorção de piretroides pela pele e através do trato gastrintestinal<sup>6</sup> .  Razão pela qual é essencial que os órgãos responsáveis pelo registro de agrotóxicos exijam dos fabricantes dados de rotulagem que permitam a identificação de todos os componentes potencialmente perigosos à saúde humana, sendo consenso de que solventes perigosos não devem ser utilizados na fabricação desses e nem de outros inseticidas<sup>19</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Algumas alterações hematológicas e bioquímicas podem ocorrer em vítimas expostas oralmente a esses produtos, sendo que o estabelecimento de um quadro de acidose metabólica é comum. Ele se caracteriza por uma redução dos níveis de bicarbonato e um aníon gap pronunciado, devendo se estar atento para as ocorrência de alterações cardíacas,  principalmente quando na formulação há solventes tóxicos<sup>16,19,28</sup> .  
Apesar do ácido 3 fenoxibenzoico (3PBA) ser um dos principais metabólitos urinários dos piretroides, não há evidências suficientes para estabelecê-lo como um biomarcador que permite avaliar o grau de exposição a esses compostos<sup>29</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Ao longo das primeiras 36 horas da admissão, monitore os níveis de bicarbonato (HCO3<sup>-</sup> ) de pacientes com histórico de ingestão de formulações contendo solventes tóxicos.  
Nível de recomendação: Condicional a favor (Anexo V.4)  
**Evidências** :  
Em um total de 56 pacientes, 54 foram expostos intencionalmente, por via oral, a formulações  
8  
contendo piretroides (96,4%). Na gasometria arterial, o pH mediano arterial, as dosagens de bicarbonato (HCO3<sup>-</sup> ) e lactato sérico foram, respectivamente,  7,38 (IQR 7,33–7,42), 19,6 (IQR 17,7– 21,9) mmol / L e 3,67 (IQR 2,38-5,54) mmol / L. O tempo médio de internação foi de 2 dias (0-4,8) e a mortalidade estimada em 3,6% (n=2)<sup>9</sup> .  
Paciente vítima de uma exposição oral a 20 mL de uma formulação contendo 1,6% de praletrina e 5% de butóxido de piperonil, apesar de estável nas primeiras 24h, desenvolveu um quadro de acidose metabólica aguda (pH 7,21 e [HCO3<sup>-</sup> ]= 15 mEq/L), com hiato iônico normal. Concomitantemente ela apresentou um quadro de parada sinusal com alteração do ritmo juncional. Após receber a infusão de 250 meq de bicarbonato de sódio (7,5%) por um período de 12h, a sua condição normalizou (pH 7,34 e [HCO3<sup>-</sup> ]= 22 mEq/L)<sup>16</sup> .  
Paciente de 27 anos sem antecedentes patológicos, encaminhado ao serviço de emergência, 10 h após a ingestão intencional de uma quantidade desconhecida de cipermetrina (10%). Além da leucocitose (13.000 / mm<sup>3</sup> ) e da elevação da creatinina (24 mg / L), desenvolveu um quadro de acidose metabólica (pH = 7,15 e [HCO3<sup>-</sup> ] = 12 mEq / L e aníon GAP = 32mEq / L). Apesar da tentativa de infusão de solução de bicarbonato a 4,2%, o indivíduo foi a óbito após 12 horas de internação com choque refratário<sup>19</sup> .  
Nível de evidência: Muito Baixa (Anexo V.5)

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Não há antídotos que possam ser utilizados nos casos de intoxicações agudas por formulações contendo piretroides. As manifestações clínicas dependem da via de exposição<sup>7,21,30</sup> .  
Nas exposições dérmicas, por exemplo, a simples descontaminação com água e sabão é de grande valia. Por outro lado, no caso de ingestão oral, não há evidências suficientes que amparem o uso de técnicas de descontaminação gastroenteral<sup>31</sup> .  
O estabelecimento de uma estratégia que inclua medidas de descontaminação, suporte vital e tratamento sintomático das manifestações clínicas observadas devem ser medidas adotadas para as diversas formas de exposição a esses compostos.<sup>12,16,28,31</sup> .  
9

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
As seguintes práticas são recomendadas para o manejo das reações alérgicas  relacionadas com as intoxicações por formulações contendo piretroides<sup>1,8,14</sup> :  
- Utilize anti-histamínicos injetáveis como uma das opções para o controle das reações alérgicas;  
- Considere a administração de beta-agonistas ou corticoides sistêmicos para o controle das reações asmáticas, principalmente em pacientes que tenham predisposição ou histórico dessas;  
- O tratamento de reações anafiláticas deve ser feito por meio de epinefrina subcutânea, epinefrina intravenosa e suporte ventilatório;  
- Trate as dermatites de contato decorrentes da exposição cutânea aos piretroides com corticoides tópicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Considere a infusão de bicarbonato (HCO3) em pacientes vítimas de intoxicação oral, que evoluam para um quadro de acidose e que apresentem um aníon gap elevado e redução significativa dos níveis séricos de bicarbonato.  
Como a acidose metabólica é uma alteração observada em pacientes intoxicados com formulações contendo piretroides, a infusão de bicarbonato de sódio é uma das estratégias que  
vem sendo utilizadas para a reversão do quadro. 7,16,31.  
Não foram encontradas evidências que suportem o uso de histamínicos, de hidratantes à base de Vitamina E ou a recomendação banhos com água mais fria para o tratamento das intoxicações decorrentes da exposição dérmica aos piretroides<sup>7</sup> . Contudo, essas são práticas adotadas utilizadas para alívio dos sintomas ocasionados pelo contato com esses produtos, principalmente em indivíduos com maior sensibilidade<sup>31</sup>  
10

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
**Todos os procedimentos utilizados para a descontaminação de pele e mucosas nos casos onde há suspeita de intoxicação por agrotóxicos encontram-se apresentados nos anexos** **<u>publicados na Portaria MS/SCTIE n°43/2018, publicada em 16 de outubro de 2018</u>**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
No atendimento inicial aos casos de exposição dérmica a formulações contendo piretroides, assegure que a pele e o cabelo da vítima sejam lavados com quantidade abundante de água e sabão. Os profissionais responsáveis pelo procedimento devem considerar as técnicas de proteção padrão e uso de equipamento de proteção individual<sup>14</sup> .  
A descontaminação dos olhos deve ser feita com água limpa ou solução salina em abundância. Irrigue o (s) olho (s) exposto (s) com quantidade abundante de água durante pelo 10-15 minutos. Como algumas formulações à base de piretroides podem ser corrosivas, caso persista a irritação, referenciar o paciente para um serviço especializado<sup>14</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Não há evidências suficientes para amparar o uso da lavagem gástrica em pacientes intoxicados por formulações à base de piretroides e seus derivados. Contudo, ela pode ser uma alternativa a ser utilizada, com cautela, caso a vítima tenha ingerido um grande volume de solução. Nesse caso, o procedimento deve ser realizado em até 1 hora (60 min) da ingestão do agente<sup>14</sup> .  
Nas exposições com baixas dose ou que se caracterizem somente pelo contato oral (especialmente em crianças) não é recomendado realizar lavagem gástrica, considerando que as formulações domésticas comercializadas no Brasil apresentam baixas concentrações de piretroides.  
11  
A lavagem gástrica não é recomendada em pacientes que apresentem<sup>32</sup> :  
- Vias aéreas desprotegidas;  
- Histórico de ingestão concomitante de outras substâncias depressoras do Sistema Nervoso Central, compostos corrosivos (ácidos ou alcalinos) ou hidrocarbonetos (solventes);  
- Convulsões;  
- Risco de sangramento ou de perfuração do trato gastrointestinal devido a cirurgias ou outras condições clínicas (ex.: coagulopatias)  
Não há evidências suficientes para amparar o uso de carvão ativado em pacientes intoxicados por piretroides, apesar de alguns relatos apresentados na literatura<sup>16–18,26</sup> .  Há indícios de uma possível redução da biodisponibilidade do agente tóxico ao se realizar o procedimento em até 60 min após a ingestão, considerando dados de estudos realizados, em voluntários, com outros agentes. Entretanto nenhum desses foi realizado com os referidos compostos e foi realizado em populações diferentes com diferentes sistemas de saúde<sup>14</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Não foram encontrados estudos que apresentem evidências suficientes que amparem a utilização de técnicas de eliminação extracorpórea, tais como hemodiálise.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Toda vítima de intoxicação por piretroides relacionadas a tentativa de suicídio deve ser encaminhar à Rede de Atenção Psicossocial (RAPS).  
Para conhecer mais sobre a RAPS acesse o endereço eletrônico do Portal da Saúde: <u>http://portalsaude.saude.gov.br/index.php/o-ministerio/principal/secretarias/sas/daet/saudemental</u>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
A exposição ocupacional a piretroides pode ocorrer, principalmente, por meio de contato e inalação de poeiras e sprays. Enquanto a inalação é a principal via de exposição em trabalhadores da indústria, a pele é a principal via de exposição de trabalhadores rurais e de agentes de controle  
12  
de endemias. Contudo, no universo dos outros agrotóxicos, a exposição ocupacional aos piretroides, apesar de relevante no âmbito da saúde pública, é menos frequente<sup>2</sup> .  
Um dos primeiros estudos realizados para avaliar a intoxicação ocupacional aguda por piretroides foi realizado por Chen e colaboradores. Foram acompanhados 3.113 trabalhadores rurais responsáveis pela pulverização de piretroides, os quais foram entrevistados e acompanhados ao longo das 72 horas subsequentes à exposição. Apesar sintomas sistêmicos significativos terem sido observados em somente 10 sujeitos, parestesia, tontura, dor de cabeça, fadiga, náusea ou perda de apetite forma sintomas relatados por 834 dos participantes. O estudo também revelou que no caso de agricultores expostos a piretroides, contaminação dérmica é a principal via de exposição<sup>33</sup> .  
Programas de biomonitoramento sugerem o acompanhamento dos níveis urinários do ácido 3- fenoxibenzoico (3PBA), considerando que mais de 18 piretroides são metabolizados e forma 3PBA<sup>34</sup> . Outros estudos sugerem a utilização da proteína C reativa (PCR) como um biomarcador de exposição de médio prazo a piretroides, dada a correlação encontrada por alguns autores<sup>35</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
O ácido 3 fenoxibenzoico (3PBA), apesar de ser um dos principais metabólitos urinários dos piretroides, não deve ser utilizado como biomarcador para avaliar o grau de exposição ocupacional a piretroides<sup>36</sup>  
A parestesia é também um dos efeitos comumente observados entre trabalhadores expostos aos piretroides do grupo ciano. Ela é percebida algumas horas após a exposição, como uma sensação de beliscar ou queimar, às vezes acompanhada de dormência da área, que piora com o a sudorese ou banhos com água morna ou quente, sendo de resolução espontânea. Geralmente, desaparece em menos de vinte e quatro horas<sup>28</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
De um modo geral, a exposição da população pode ocorrer por meio da  inalação, do contato da pele com produtos, pela ingestão de alimentos que contenham resíduos de piretroides aplicados como pesticidas ou medicamentos veterinários, ou através de ingestão acidental ou intencional de formulações contendo esses produtos<sup>2</sup> .  
No Brasil, apesar da notificação de suspeitas de intoxicação por agrotóxicos ser compulsória desde 2011, ela se mostra bastante tímida frente às dimensões continentais do país. Além disso, boa parte das fichas recebidas pelo Sistema de Informação de Agravos de Notificação (Sinan) não apresentam todos os dados. Assim, em muitos dos relatórios gerados a partir da análise dessas  
13  
informações, detalhes em relação ao tipo de ingrediente ativo usado, à circunstância da exposição/contaminação ou às atividades exercidas são desconhecidos pelo setor de vigilância.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Capítulo 5 – Abordagem ao Paciente Intoxicado por produtos formulados com piretroides** -->
Uma vez finalizada a atenção inicial e estabilizado o paciente, deve-se realizar a respectiva notificação do caso, utilizando o formato de notificação de intoxicações apropriado.  
Notifique todos os casos suspeitos de intoxicação exógena no Sistema de Informação de Agravos de Notificação (Sinan). Ela é obrigatória a todos os profissionais de saúde, e é um fator determinante para medidas de vigilância.  
Existe também a possibilidade da comunicação pelos cidadãos ou estabelecimentos educacionais por meio do Disque Notifica: 0800-644-6645 ou notifica@saude.gov.br.  
**(Verificar Portaria MS/SCTIE n°43/2018, publicada em 16 de outubro de 2018 para maiores detalhes em relação à obrigatoriedade da notificação compulsória dos casos de suspeita de intoxicação exógena)**  
Em caso de ser uma intoxicação exógena por agrotóxicos relacionada ao trabalho, de acordo com a Lei 8.213/1991; Portaria GM/MS de Consolidação nº 2 de 2017, anexo XV (origem: PRT MS 1.823/2012); Portaria GM/MS de Consolidação nº 5 de 2017, art. 422 e Anexo LXXIX (origem: PRT MS 3.120/1998)<sup>37</sup> ; Lei 6.015/1973; Portaria GM/MS de Consolidação nº 4 de 2017, anexo V (Origem: PRT MS/GM 204/2016)<sup>38</sup> ; o médico ou profissional de saúde deve:  
- Emitir a Comunicação de Acidente de Trabalho (CAT) para os trabalhadores que contribuem com o INSS e os segurados especiais (a exemplo de agricultores e pescadores);  
- Referenciar o trabalhador, para a atenção básica, caso o primeiro atendimento seja realizado em serviços de média ou alta complexidade com o objetivo de dar continuidade ao cuidado;  
- Acionar o Centros de Referência em Saúde do Trabalhador (Cerest) ou equipe de vigilância em saúde para realizar vigilância de ambiente e processo de trabalho referente ao caso, com o objetivo de intervir, minimizando ou eliminando a exposição de trabalhadores aos agrotóxicos;  
14  
- Notificar o caso na ficha de investigação de **Intoxicação Exógena do Sinan** e sempre preencher os campos: 32-Ocupação, 36-Atividade Econômica (CNAE), 34-Local de ocorrência da exposição como “ambiente de trabalho”, 56-A exposição/contaminação foi decorrente do trabalho/ ocupação? Como “Sim”;  
- Em caso de **óbito** , incluindo suicídio, por intoxicação por agrotóxicos relacionada ao trabalho, preencher um dos campos de causa do óbito da Declaração de Óbito (DO) com o CID-10, Y96-Circunstâncias relativas às condições de trabalho. E ainda assinalar o campo acidente de trabalho como “sim” na parte de causas externas da DO.  
( **Verificar o anexo D, do Capítulo de Abordagem Geral publicado por meio da Portaria SCTIE 43, outubro de 2018, o qual apresenta o fluxograma para o atendimento de trabalhadores com suspeita de intoxicação por agrotóxicos** )  
Referências bibliográficas  
1. US EPA O. Pyrethrins and Pyrethroids. [cited 2018 Nov 26]; Available from: https://www.epa.gov/ingredients-used-pesticide-products/pyrethrins-and-pyrethroids  
2. WHO/CDS/WHOPES/GCDPP/2005.10. Safety of Pyrethroids for Public Health Use. World Health Organization 2005. 2005.  
3. Brasil. Ministerio da Agricultura Pecuaria e Abastecimento. AGROFIT [Internet]. [cited 2018 Nov 1]. Available from:  
http://agrofit.agricultura.gov.br/primeira_pagina/extranet/AGROFIT.html  
4. BRASIL. MINISTÉRIO DA AGRICULTURA PEACDFDPV. RELATÓRIO DE PRODUTOS VETERINÁRIOS COM LICENÇA VIGENTE [Internet]. BRASÍLIA; 2014 [cited 2018 Dec 12]. p. 200. Available from:  
http://www.agricultura.gov.br/assuntos/insumos-agropecuarios/insumospecuarios/produtos-veterinarios/arquivos-comunicacoes-e-instrucoestecnicas/ProdutosVigentesAbril2014.pdf  
5. BRASIL. AGÊNCIA NACIONAL DE VIGILÂNCIA SANITÁRIA. Consultas - Agência Nacional de Vigilância Sanitária [Internet]. [cited 2018 Dec 12]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
6. Soderlund DM, Clark JM, Sheets  larry P, Mullin LS, Piccirillo VJ, Sargent D, et al. Mechanisms of pyrethroid neurotoxicity: implications for cumulative risk assessmen. Toxicology. 2002;171:3–59.  
7. Ray DE, Ray D, Forshaw PJ, Ray DE, Ray D, Pyrethroid PJF, et al. Pyrethroid Insecticides : Poisoning Syndromes , Synergies , and Therapy Pyrethroid Insecticides :  
15  
Poisoning Syndromes , Synergies , and Therapy. 2017;3810(December).  
8. Rehman H, Aziz AT, Saggu S, Abbas ZK, Mohan A, Ansari AA. Systematic review on pyrethroid toxicity with special reference to deltamethrin. ~ 60 ~ J Entomol Zool Stud. 2014;2(6):60–70.  
9. Cha YS, Kim H, Cho NH, Jung WJ, Kim YW, Kim TH, et al. Pyrethroid poisoning: Features and predictors of atypical presentations. Emerg Med J. 2014;31(11):899–903.  
10. George J, Shukla Y. Pesticides and cancer: Insights into toxicoproteomic-based findings. J Proteomics. 2011;74(12):2713–22.  
11. Maroni M, Colosio C, Ferioli A, Fait A. Biological monitoring of pesticide exposure: A review. Vol. 143, Toxicology. 2000. 5-118 p.  
12. Bradberry SM, Cage SA, Proudfoot AT, Vale JA. Poisoning due to pyrethrins. Toxicol Rev. 2005;24(2):107–13.  
13. Chandra A, Dixit M, Banavaliker J. Prallethrin poisoning: A diagnostic dilemma. J Anaesthesiol Clin Pharmacol [Internet]. 2013;29(1):121. Available from: http://www.joacp.org/text.asp?2013/29/1/121/105820  
14. Roberts JR, Reigart JR. Recognition and Management of Pesticides Poisoning [Internet]. 6th ed. Agency USEP, editor. United States Environmental Protection Agency. Washington, DC; 2013. 272 p. Available from:  
http://dx.doi.org/10.1016/j.mayocp.2011.09.004  
15. Erickson TB, Thompson TM, Lu JJ. The Approach to the Patient with an Unknown Overdose. Emerg Med Clin North Am. 2007;25(2):249–81.  
16. Bhaskar EM, Moorthy S, Ganeshwala G, Abraham G. Cardiac conduction disturbance due to prallethrin (pyrethroid) poisoning. J Med Toxicol. 2010;6(1):27–30.  
17. Cha YS, Kim H, Cho NH, Jung WJ, Kim YW, Kim TH, et al. Pyrethroid poisoning: features and predictors of atypical presentations. Emerg Med J [Internet]. 2014;31(11):899–903. Available from:  
http://emj.bmj.com/lookup/doi/10.1136/emermed-2013-202908  
18. Gunay N, Kekec Z, Cete Y, Eken C, Demiryurek AT. Oral deltamethrin ingestion due in a suicide attempt. Bratislava Med J. 2010;111(5):303–5.  
19. Aissaoui Y, Kichna H, Boughalem M, Kamili ND. An intoxication can hide another one more serious. Example of a fatal poisoning with ethylene glycol intoxication masked by a pyrethroid insecticide. Pan Afr Med J. 2013;14(February 2014):128.  
20. Lin CC, Lai SY, Hu SY, Tsan YT, Hu WH. Takotsubo cardiomyopathy related to  
16  
carbamate and pyrethroid intoxication. Resuscitation. 2010;81(8):1051–2.  
21. Gotoh Y, Kawakami M, Matsumoto N. Permethrin Emulsion Ingestion : Clinical Manifestations and Clearance of Isomers. 1998;36:57–61.  
22. Gobba F, Abbacchini C. Anosmia after exposure to a pyrethrin-based insecticide: A case report. Int J Occup Med Environ Health. 2012;25(4):506–12.  
23. Kongtip P, Sasrisuk S, Preklang S, Yoosook W, Sujirarat D. Assessment of occupational exposure to malathion and bifenthrin in mosquito control sprayers through dermal contact. J Med Assoc Thai. 2013;96 Suppl 5(7):82–91.  
24. Kuriakose K, Klair J, Johnsrud A, Rudrappa M, Meena NK. Pyrethroid induced acute eosinophilic pneumonia . Chest  [Internet]. 2014;146(4 MEETING ABSTRACT):314A. Available from:  
http://journal.publications.chestnet.org/article.aspx?articleID=1912775%0Ahttp://dx.doi. org/10.1378/chest.1989377%0AAdded Mar 15  
25. Román MS, Herranz J, Arteaga R. Intoxicación por piretrinas: una causa singular de convulsiones en el lactante. Bol Pediatr [Internet]. 2003;43:284–9. Available from: http://www.sccalp.org/boletin/185/BolPediatr2003_43_284-289.pdf  
26. Proudfoot AT. Poisoning due to pyrethrins. Toxicol Rev. 2005;24(2):107–13.  
27. Sharma P, Manning S, Baronia R, Mushtaq S. Pyrethroid as a Substance of Abuse. Case Rep Psychiatry [Internet]. 2014;2014:169294. Available from:  
- http://www.pubmedcentral.nih.gov/articlerender.fcgi?artid=4241337&tool=pmcentrez&r endertype=abstract  
28. Plagbol. Manual de Diagnóstico Tratamiento y Prevención de Intoxicaciones Agudas por Plaguicidas. Susana Ren. La Paz: SPC Impresores S.A.; 2008. 189 p.  
29. Aras M, Schmitt C, Glaizal M, Kervégant M, Tichadou L, de Haro L. Accidental Occupational Exposure to Phytosanitary Products: Experience of the Poison Control Center in Marseille From 2008 to 2010. J Agromedicine. 2013;18(2):117–21.  
30. Adams RD, Gibson AL, Good AM, Bateman DN. Systematic differences between healthcare professionals and poison information staff in the severity scoring of pesticide exposures. Clin Toxicol. 2010;48(6):550–8.  
31. Bateman DN. Management of Pyrethroid Exposure. 2000;38(2):107–9.  
32. Benson BE, Hoppu K, Troutman WG, Bedry R, Erdman A, Jer JHÖ, et al. Position paper update: gastric lavage for gastrointestinal decontamination. 2013;  
33. Chen S, Zhang Z, He F, Yao P, Wu Y, Sun J, et al. An epidemiological study on  
17  
occupational acute pyrethroid poisoning in cotton farmers. Br J Ind Med. 1991;48:77– 81.  
34. Burns CJ, Pastoor TP. Pyrethroid epidemiology: a quality-based review. Crit Rev Toxicol. 2018;48(4):297–311.  
35. Huang X, Zhang C, Hu R, Li Y, Yin Y, Chen Z, et al. Association between occupational exposures to pesticides with heterogeneous chemical structures and farmer health in China. 2016;  
36. Morgan MK, Sobus JR, Barr DB, Croghan CW, Chen FL, Walker R, et al. Temporal variability of pyrethroid metabolite levels in bedtime, morning, and 24-h urine samples for 50 adults in North Carolina. Environ Res. 2016;144:81–91.  
37. Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 5/2017. 5 Brasília; 2017.  
38. Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 4/2017. Ministério da Saúde, Gabinete do Ministro, Brasília, DF, Brasil Brasília; 2017 p. 288p.  
18

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: ANEXOS -->
19  
**Anexo V.1 – PERGUNTAS PICO  Piretroides**  
**Quadro IV.1.1 -** Perguntas PICO relativas à intoxicação aguda por produtos formulados com piretroides.  
|**Perguntas**|**População**|**Intervenção**|**Comparação**|**Desfecho**|
|---|---|---|---|---|
|Quais são as manifestações clínicas,<br>sinais e sintomas que permitem<br>suspeitar intoxicação aguda por<br>piretroides?|Homens e mulheres<br>expostos a piretroides<br>Subgrupos específicos:<br>Grávidas, criança e<br>idosos|- Exposições agudas: Reações anafiláticas (hipotensão e<br>taquicardia), broncoespasmo, edema de glote, crises de<br>asma,  pneumonite e edema pulmonar;  dermatite<br>alérgica.<br>- Exposição Dérmica: formigamento, prurido, eritema e<br>ardor; neurotoxicidade periférica com hiperatividade.<br>Dermatite alérgica e sensibilização; toxicidade sistêmica.<br>- Exposição Ocular: irritação ocular e conjuntivite<br>transitória.<br>- Exposição Inalatória: Irritação do trato respiratório com<br>tosse, dispnéia moderada, espirros e<br>rinorréia; toxicidade sistêmica com pneumonite.<br>- Exposição Oral: náusea, vômito, anorexia e dor<br>abdominal. Sintomas neurológicos e<br>efeitos sistêmicos. (Toxicidade Sistêmica: dor de cabeça,<br>vertigem, anorexia e sialorréia; alterações de<br>consciência, fasciculações musculares, convulsões,<br>fadiga, salivação elevada, visão turva, edema pulmonar<br>não cardiogênico e rigidez torácica; palpitação e<br>arritmias).|-ausência do fator|Deteção de casos<br>de intoxicação<br>aguda por<br>piretroides|
|Quais são as provas a realizar para<br>definir uma intoxicação aguda por<br>piretroides?|Homes e mulheres<br>com suspeita de|- Quadro clínico;<br>- histórico de exposição;<br>- Testes eletrólitos, glicemia e gasometria|-ausência do fator|Deteção de casos<br>de intoxicação|  
20  
||intoxicação por<br>piretroides|||aguda por<br>piretroides|
|---|---|---|---|---|
|Quais os critérios de gravidade<br>específica para intoxicações agudas<br>por piretroides?|Homes e mulheres<br>com suspeita de<br>intoxicação por<br>piretroides||-ausência do fator|-Mortalidade<br>-Internação<br>-Discapacidade|
|Qual é o tratamento não<br>farmacológico inicial para o paciente<br>intoxicado com piretroides?|Homes e mulheres<br>com suspeita de<br>intoxicação por<br>piretroides|- Remoção da roupa<br>- Banho<br>- Administrar leite ou outras bebidas imediatamente<br>após a ingestão<br>- lavagem gástrica<br>- aspiração gástrica<br>- Endoscopia<br>- Indução de vômito|-ausência do fator|-Letalidade<br>-Internação<br>-Discapacidade|
|Qual é o tratamento farmacológico<br>inicial para o paciente intoxicado<br>com piretroides?|Homens e mulheres<br>potencialmente<br>expostos a piretroides<br>Subgrupo:<br>trabalhadores|- Terapia com oxigênio<br>- Hidratação<br>- Carvão ativado<br>- Antídoto<br>- Vitamina E para irritação de pele<br>- Anti-histamínicos|-ausência do fator||
|Qual é a melhor forma de fazer<br>seguimento aos pacientes com<br>intoxicação aguda leve,<br>subaguda/subcrônica por<br>piretroides?|Homens e mulheres<br>com intoxicação por<br>piretroides|- Ambulatorial<br>- Tempo de internação<br>- Afastamento da exposição|-ausência do fator|-Sequelas<br>-retorno dos<br>sintomas<br>-efeitos  tardios|  
21  
|Qual deve ser o acompanhamento,<br>segmento e reabilitação do paciente<br>intoxicado por piretroides?|Homens e mulheres<br>que passaram pelo<br>quadro de intoxicação<br>por piretroides que<br>possuem quadro de<br>sintomatologia<br>continuada|- Frequência do monitoramento<br>- Caracteristicas do monitoramento (indicadores)<br>- Sintomatologia pós-trauma|-ausência do fator|-Sequelas<br>-retorno dos<br>sintomas<br>-efeitos  tardios<br>- Absentismo<br>escolar<br>-Absentismo<br>ocupacional|
|---|---|---|---|---|
|Quais são as manifestações clínicas,<br>sinais e sintomas que permitem<br>suspeitar intoxicação aguda por<br>piretroides?|Homens e mulheres<br>expostos a piretroides<br>Subgrupos específicos:<br>Grávidas, criança e<br>idosos|- Exposições agudas: Reações anafiláticas (hipotensão e<br>taquicardia), broncoespasmo, edema de glote, crises de<br>asma,  pneumonite e edema pulmonar;  dermatite<br>alérgica.<br>- Exposição Dérmica: formigamento, prurido, eritema e<br>ardor; neurotoxicidade periférica com hiperatividade.<br>Dermatite alérgica e sensibilização; toxicidade sistêmica.<br>- Exposição Ocular: irritação ocular e conjuntivite<br>transitória.<br>- Exposição Inalatória: Irritação do trato respiratório com<br>tosse, dispnéia moderada, espirros e<br>rinorréia; toxicidade sistêmica com pneumonite.<br>- Exposição Oral: náusea, vômito, anorexia e dor<br>abdominal. Sintomas neurológicos e<br>efeitos sistêmicos. (Toxicidade Sistêmica: dor de cabeça,<br>vertigem, anorexia e sialorréia; alterações de<br>consciência, fasciculações musculares, convulsões,<br>fadiga, salivação elevada, visão turva, edema pulmonar|-ausência do fator|Detecção de casos<br>de intoxicação<br>aguda por<br>piretroides|  
22  
|||não cardiogênico e rigidez torácica; palpitação e<br>arritmias).|||
|---|---|---|---|---|
|Quais são as provas a realizar para<br>definir uma intoxicação aguda por<br>piretroides?|Homes e mulheres<br>com suspeita de<br>intoxicação por<br>piretroides|- Quadro clínico;<br>- histórico de exposição;<br>- Testes eletrólitos, glicemia e gasometria|-ausência do fator|Detecção de casos<br>de intoxicação<br>aguda por<br>piretroides|
|Quais os critérios de gravidade<br>específica para intoxicações agudas<br>por piretroides?|Homes e mulheres<br>com suspeita de<br>intoxicação por<br>piretroides||-ausência do fator|-Mortalidade<br>-Internação<br>-Discapacidade|  
23

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.2 Estratégias de Busca** -->
**Quadro V.2.1** Estratégia de busca e associação de palavras-chave para as perguntas PICO de Manifestações clinicas e sintomas  Capítulo Piretroides  
**Quadro V.2.2** Estratégia de busca e associação de palavras-chave para as perguntas PICO de Gravidade do Capítulo Piretroides.  
**Quadro V.2.3** Estratégia de busca e associação de palavras-chave para as perguntas PICO de tratamento Capítulo Piretroides  
24

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.2 Estratégias de Busca** -->
**1.** Como deve ser a anamnese no paciente com suspeita de intoxicação por piretroides? (Busca não realizada, será mantida anamnese do capítulo 1)  
**2.** Quais são as manifestações clínicas, sinais e sintomas que permitem suspeitar **intoxicação aguda por piretroides?**  
3. Qual o diagnóstico diferencial com relação a outros solventes, depressores do SNC e substâncias irritantes de pele e mucosas, e de outras condições que causam alterações do SNC, pulmonares e de hipersensibilidade?  
4. Quais são as provas laboratoriais que apoiam a avaliação de um paciente com intoxicação aguda por piretroides?  
5. Quais são as provas para realizar diagnóstico laboratorial de intoxicação aguda por piretroides?  
6. Quais os critérios de avaliação de gravidade específica para intoxicações agudas por piretroides?  
**Quadro V.2.1** Estratégia de busca e associação de palavras-chave, para as perguntas PICO de manifestações clinicas  Capítulo Piretroides  
|BASE|ESTRATÉGIA|REGISTROS|OBSERVAÇÕES|
|---|---|---|---|
|MEDLINE/PUBMED<br>1a|("Pyrethrins/adverse effects"[Mesh] OR "Pyrethrins/etiology"[Mesh]<br>OR "Pyrethrins/poisoning"[Mesh] OR "Pyrethrins/toxicity"[Mesh])<br>NOT ("Animals"[Mesh] NOT ("Animals"[Mesh] AND<br>"Humans"[Mesh])) AND ("2010/01/01"[PDAT] :<br>"2018/07/16"[PDAT])|**268**|Realizada em 16/07/2018|
|LILACS<br>1b|tw:((pyrethrins OR piretrinas OR piretroide OR piretroides) AND<br>((toxicity OR toxicidade OR toxicidade) OR (envenenamento OR<br>poisoning OR envenenamento) OR (adverse effects OR efectos<br>adversos OR efeitos adversos) OR (safety OR seguridad OR<br>segurança)) AND (humans NOT animal)) AND (instance:"regional")<br>AND ( db:("LILACS" OR "IBECS" OR "WHOLIS" OR "BINACIS" OR<br>"BDENF" OR "CUMED" OR "colecionaSUS"))|29||  
25  
|Cochrane<br>1c|COCHRANE LIBRARY<br>ID<br>Search Hits #1 MeSH descriptor:<br>[Pyrethrins] explode all trees #2<br>pyrethroid (Word variations<br>have been searched) #3<br>"toxicity" (Word variations have<br>been searched) #4<br>"poisoning" (Word variations have been<br>searched) #5<br>"safety" (Word variations have been searched) #6<br>"adverse effect" (Word variations have been searched) #7<br>"adverse effects" (Word variations have been searched) #8<br>#1 or #2 #9<br>#3 or #4 or #5 or #6 or #7 #10 #8 and #9<br>Publication Year from 2010 to 2018 (Word variations have been<br>searched)|35||
|---|---|---|---|
|**adro V.2.2**Estraté<br>BASE|gia de busca e associação de palavras-chave, para as perguntas PICO de Diagn<br>ESTRATÉGIA|óstico Capítulo<br>REGISTROS|Piretroides<br>OBSERVAÇÕES|
|Pubmed<br>2a|((( "Pyrethrins/adverse effects"[Mesh] OR<br>"Pyrethrins/etiology"[Mesh] OR "Pyrethrins/poisoning"[Mesh] OR<br>"Pyrethrins/toxicity"[Mesh] ))) AND ((((((( "Pyrethrins/adverse<br>effects"[Mesh] OR "Pyrethrins/etiology"[Mesh] OR<br>"Pyrethrins/poisoning"[Mesh] OR "Pyrethrins/toxicity"[Mesh] )))<br>AND (((sensitiv*[Title/Abstract] OR sensitivity and specificity[MeSH<br>Terms] OR diagnose[Title/Abstract] OR diagnosed[Title/Abstract] OR<br>diagnoses[Title/Abstract] OR diagnosing[Title/Abstract] OR<br>diagnosis[Title/Abstract] OR diagnostic[Title/Abstract] OR<br>diagnosis[MeSH:noexp] OR diagnostic * [MeSH:noexp] OR<br>diagnosis,differential[MeSH:noexp] OR<br>diagnosis[Subheading:noexp])))) OR (specificity[Title/Abstract]))) OR|180|.|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.2 Estratégias de Busca** -->
26  
||(specif<br>"2018/|icity[Title/Abstract])) AND ("2010/01/01"[PDAT] :<br>07/18"[PDAT])||
|---|---|---|---|
|LILACS<br>2b|LILACS<br>AND ((<br>poison<br>advers<br>segura<br>diagno<br>specifi<br>diferen<br>AND (i<br>"BINAC|/BVS: (pyrethrins OR piretrinas OR piretroide OR piretroides)<br>toxicity OR toxicidade OR toxicidade) OR (envenenamento OR<br>ing OR envenenamento) OR (adverse effects OR efectos<br>os OR efeitos adversos) OR (safety OR seguridad OR<br>nça)) AND ((diagnóstico OR diagnosis OR diagnóstico OR<br>se) OR (“ sensibilidade e especificidade” OR “sensitivity AND<br>city” OR “sensibilidad y especificidad”) OR (diagnóstico<br>cial OR diagnosis, differential OR diagnóstico diferencial))<br>nstance:"regional") AND ( db:("LILACS" OR "BDENF" OR<br>IS" OR "IBECS" OR "MINSA" OR "colecionaSUS"))|7|
|Cochrane|ID|Search  Hits|7|
|2c|#1<br>#2<br>search|MeSH descriptor: [Pyrethrins] explode all trees             246<br>"pyrethroid"  (Word variations have been<br>ed)                113||
||#3<br>#4<br>#5<br>search<br>#6<br>trees<br>#7<br>all tree<br>#8<br>trees|"poisoning"  (Word variations have been searched)    1593<br>"safety"  (Word variations have been searched)    165769<br>"adverse effect"  (Word variations have been<br>ed)                152722<br>MeSH descriptor: [Diagnosis] explode all<br>329187<br>MeSH descriptor: [Clinical Laboratory Techniques] explode<br>s     44570<br>MeSH descriptor: [Diagnosis, Differential] explode all<br>1724||  
27  
|#9           MeSH descriptor: [Sensitivity and Specificity] explode all|
|---|
|trees                19521|
|#10        "toxicity"  (Word variations have been searched)    34623|
|#11        #1 or #2               327|
|#12        #3 or #4 or #5 or #10      296892|
|#13        #6 or #7 or #8 or #9        332951|
|#14        #11 and #12 and #13 Publication Year from 2010 to|
|2018|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.2 Estratégias de Busca** -->
|BASE|ESTRATÉGIA|REGISTROS|OBSERVAÇÕES|
|---|---|---|---|
|PUBMED|(((((( "Pyrethrins/adverse effects"[Mesh] OR<br>"Pyrethrins/etiology"[Mesh] OR "Pyrethrins/poisoning"[Mesh] OR<br>"Pyrethrins/toxicity"[Mesh] )))))) AND ((((incidence[MeSH:noexp] OR<br>mortality[MeSH Terms] OR follow up studies[MeSH:noexp] OR<br>prognos*[Text Word] OR predict*[Text Word] OR course*[Text<br>Word]))) OR ((prognos*[Title/Abstract] OR (first[Title/Abstract] AND<br>episode[Title/Abstract]) OR cohort[Title/Abstract])))  AND<br>("2010/01/01"[PDAT] : "2018/07/18"[PDAT])|112|Sem limite de data.|
|LILACS|(Pyrethrins OR Piretrinas OR Piretroide OR Piretroides) AND<br>((Toxicity OR toxicidade OR toxicidade) or (envenenamento OR<br>poisoning OR envenenamento) OR (adverse effects OR efectos|0||  
28  
||adversos OR efeitos adversos) OR (Safety OR Seguridad OR<br>Segurança)) AND ((Prognóstico OR Prognosis OR  Pronóstico OR<br>Fatores Prognósticos)<br>(Seguimentos OR  Follow-Up Studies OR Estudios de Seguimiento)<br>OR (Mortalidade OR Mortality OR Mortalidad) OR (Evolução Fatal<br>OR  Fatal Outcome OR  Resultado Fatal))||
|---|---|---|
|Cochrane|#1           MeSH descriptor: [Pyrethrins] explode all trees     246<br>#2           "pyrethroid"  (Word variations have been<br>searched)           113<br>#3           "poisoning"  (Word variations have been<br>searched)           1593<br>#4           "safety"  (Word variations have been<br>searched)           165769<br>#5           "adverse effect"  (Word variations have been<br>searched)           152722<br>#6           "toxicity"  (Word variations have been<br>searched)           34623<br>#7           MeSH descriptor: [Prognosis] explode all trees     149797<br>#8           MeSH descriptor: [Follow-Up Studies] explode all<br>trees             56654<br>#9           MeSH descriptor: [Mortality] explode all trees     13955<br>#10        #1 or #2               327|8|
||#11        #3 or #4 or #5 or #6        296892<br>#12        #7 or #8 or #9    182481<br>#13        #10 and #11 and #12      22<br>#14        #10 and #11 and #12 Publication Year from 2010 to 2018||  
29  
**Quadro V.2.3** Estratégia de busca e associação de palavras-chave, para as perguntas PICO de tratamento Capítulo Piretroides  
|BASE|ESTRATÉGIA|REGISTROS|OBSERVAÇÕES|
|---|---|---|---|
|MEDLINE/PUBMED<br>4a|("Therapeutics"[Mesh] OR "therapy"[Subheading] OR "Emergency<br>Treatment"[Mesh]) AND ("Poisoning"[Mesh] OR<br>"poisoning"[Subheading]) AND "Pyrethrins"[Mesh] AND<br>"humans"[MeSH Terms] AND (English[lang] OR Portuguese[lang] OR<br>Spanish[lang])|**122**||
|LILACS<br>4b|tw:(pyrethrins) AND (instance:"regional") AND ( db:("LILACS" OR<br>"colecionaSUS") AND clinical_aspect:("therapy") AND<br>limit:("humans"))|**11**||
|Cochrane|ID           Search  Hits|0||
|4C|#1           MeSH descriptor: [Pyrethrins] explode all trees<br>#2           pyrethroid  (Word variations have been searched)<br>#3           "toxicity"  (Word variations have been searched)<br>#4           "poisoning"  (Word variations have been searched)<br>#5           "terapy"  (Word variations have been searched)|||  
30

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
**Quadro V.3.1.** Artigos resultantes da busca sistemática no site **Pubmed** , para as perguntas PICO sobre manifestações clinicas para intoxicações por produtos contendo piretroides  
**Busca - pergunta PICO** manifestações clinicas ( **268 resultados)**  
|Busca|<br>Título|autores|Ano|Artigo<br>considerado|
|---|---|---|---|---|
|||Gunay, Nurullah and Kekec, Zeynep and Cete,<br>Yildiray and Eken, Cenker and Demiryurek,|||
|1a|Oral deltamethrin ingestion due in a suicide attempt.|Abdullah T|2010|Sim|
|||Wylie, Blair J and Hauptman, Marissa and Woolf,|||
|1a|Insect Repellants During Pregnancy in the Era of the Zika Virus.|Alan D and Goldman, Rose H|2016|Não|
|||Margekar, Shubha Laxmi and Singh, Neelima and|||
|1a|Pyrethroid ingestion-induced status epilepticus in a young woman.|Margekar, Venu Gopal and Trikha, Sushma|2013|Não|
||Pesticide exposure and neurodevelopmental outcomes: review of the|Burns, Carol J and McIntosh, Laura J and Mink,|||
|1a|epidemiologic and animal studies.|Pamela J and Jurek, Anne M and Li, Abby A|2013|Não|
|1a|Advances in the mode of action of pyrethroids.|Clark, J Marshall and Symington, Steven B|2012|Não|
|||Vanden Driessche, Koen S J and Sow, Alassane|||
|1a|Anaphylaxis in an airplane after insecticide spraying.|and Van Gompel, Alfons and Vandeurzen, Kurt|2010|Sim|
|||Shormanov, V K and Chigareva, E N and|||
|1a|[Chemical toxicological identification of esfenvalerate].|Vladimirenko, E N|2012|Não|
|1a|[Coma is caused by cyhalothrin: a report of two cases].|Wang, Wenjie and Lu, Houqing|2016|Não|  
31  
||Deleterious effects of cypermethrin on rat liver and kidney: protective role|Abdou, Heba M and Hussien, Hend M and Yousef,|||
|---|---|---|---|---|
|1a|of sesame oil.|Mokhtar I|2012|Não|
||Erythema multiforme-like irritant contact dermatitis after application of an||||
|1a|antiscabies treatment.|Bassi, A and D'Erme, A M and Gola, M|2011|Sim|
|1a|Estrogenic pyrethroid pesticides regulate expression of estrogen receptor<br>transcripts in mouse Sertoli cells differently from 17beta-estradiol.|Taylor, J S and Thomson, B M and Lang, C N and<br>Sin, F Y T and Podivinsky, E|2010|Não|
||An Evaluation of the Human Relevance of the Lung Tumors Observed in|Yamada, Tomoya and Kondo, Miwa and Miyata,<br>Kaori and Ogata, Keiko and Kushida, Masahiko<br>and Sumida, Kayo and Kawamura, Satoshi and<br>Osimitz, Thomas G and Lake, Brian G and Cohen,|||
|1a|Female Mice Treated With Permethrin Based on Mode of Action.|Samuel M|2017|Não|
||Falling through the regulatory cracks: Street selling of pesticides and||||
|1a|poisoning among urban youth in South Africa.|Rother, Hanna-Andrea|2010|Não|
||Knowledge, attitude and practices of pesticide use and acetylcholinesterase|Atreya, Kishor and Sitaula, Bishal Kumar and<br>Overgaard, Hans and Bajracharya, Roshan Man|||
|1a|depression among farm workers in Nepal.|and Sharma, Subodh|2012|Sim|
|1a|Measured versus simulated dietary pesticide intakes in children.|Riederer, A M and Lu, C|2012|Não|
|||Goksugur, Sevil B and Karatas, Zehra and<br>Goksugur, Nadir and Bekdas, Mervan and|||
|1a|Metabolic acidosis in an infant associated with permethrin toxicity.|Demircioglu, Fatih|2015|Sim|
||Parameters for pyrethroid insecticide QSAR and PBPK/PD models for|Knaak, James B and Dary, Curtis C and Zhang,<br>Xiaofei and Gerlach, Robert W and Tornero-<br>Velez, R and Chang, Daniel T and Goldsmith,|||
|1a|human risk assessment.|Rocky and Blancato, Jerry N|2012|Não|
||Pediatric myasthenia gravis exacerbation associated with permethrin||||
|1a|cream.|Anziska, Yaacov and Rahman, Afsana|2017|Sim|  
32  
||Quantifying children's aggregate (dietary and residential) exposure and<br>dose to permethrin: application and evaluation of EPA's probabilistic|Zartarian, Valerie and Xue, Jianping and Glen,<br>Graham and Smith, Luther and Tulve, Nicolle and|||
|---|---|---|---|---|
|1a|SHEDS-Multimedia model.|Tornero-Velez, Rogelio|2012|Não|
|1a|Transient Complete Heart Block Secondary to Bed Bug Insecticide: A Case<br>of Pyrethroid Cardiac Toxicity.|Singh, Hemindermeet and Luni, Faraz Khan and<br>Marwaha, Bharat and Ali, Syed Sohail and Alo,<br>Mohammed|2016|Sim|
||Using physiologically-based pharmacokinetic models to incorporate<br>chemical and non-chemical stressors into cumulative risk assessment: a|Wason, Susan C and Smith, Thomas J and Perry,|||
|1a|case study of pesticide exposures.|Melissa J and Levy, Jonathan I|2012|Não|
|||Wang, Jinsong and Zhu, Yueqian and Cai, Xiang<br>and Yu, Jinming and Yang, Xiaoping and Cheng,|||
|1a|Abnormal glucose regulation in pyrethroid pesticide factory workers.|Jinxia|2011|Sim|
||Accidental occupational exposure to phytosanitary products: experience of|Aras, Myriam and Schmitt, Corinne and Glaizal,<br>Mathieu and Kervegant, Morgane and Tichadou,|||
|1a|the Poison Control Center in Marseille from 2008 to 2010.|Lucia and de Haro, Luc|2013|Sim|
||Acute Eosinophilic Pneumonia: Pyrethroid Exposure & Change In Smoking|Kuriakose, Kevin and Klair, Jagpal Singh and|||
|1a|Habit!|Johnsrud, Andrew and Meena, Nikhil K|2016|Sim|
|1a|Acute illnesses associated with insecticides used to control bed bugs--seven|states, 2003--2010.|2011|Sim|
|1a|Acute kidney injury secondary to exposure to insecticides used for bedbug<br>(Cimex  lectularis) control.|Bashir, Babar and Sharma, Shree G and Stein,<br>Harold D and Sirota, Robert A and D'Agati,<br>Vivette D|2013|Sim|
||Allethrin toxicity on human corneal epithelial cells involves mitochondrial|Gupta, Geetika and Chaitanya, R K and Golla,|||
|1a|pathway mediated apoptosis.|Madhu and Karnati, Roy|2013|Sim|
||Alteration of hedgehog signaling by chronic exposure to different pesticide<br>formulations and unveiling the regenerative potential of recombinant sonic||||
|1a|hedgehog in mouse model of bone marrow aplasia.|Chaklader, Malay and Law, Sujata|2015|Não|  
33  
||Amelioration of prallethrin-induced oxidative stress and hepatotoxicity in|Mossa, Abdel-Tawab H and Refaie, Amel A and|||
|---|---|---|---|---|
|1a|rat by the administration of Origanum majorana essential oil.|Ramadan, Amal and Bouajila, Jalloul|2013|Não|
|1a|Anosmia after exposure to a pyrethrin-based insecticide: a case report.|Gobba, Fabriziomaria and Abbacchini, Carlotta|2012|Sim|
||Anti-androgen effects of cypermethrin on the amino- and carboxyl-terminal|Hu, Jin-Xia and Li, Yan-Fang and Pan, Chen and<br>Zhang, Jin-Peng and Wang, Hong-Mei and Li, Jing|||
|1a|interaction of the androgen receptor.|and Xu, Li-Chun|2012|Não|
||Application of species sensitivity distribution in aquatic probabilistic<br>ecological risk assessment of cypermethrin: a case study in an urban stream||||
|1a|in South China.|Li, Huizhen and You, Jing|2015|Não|
|||de Perre, Chloe and Williard, Karl W J and<br>Schoonover, Jon E and Young, Bryan G and|||
|1a|Assessing the fate and effects of an insecticidal formulation.|Murphy, Tracye M and Lydy, Michael J|2015|Não|
|||Azab, Mohammad and Khabour, Omar F and<br>Alzoubi, Karem H and Hawamdeh, Hasan and|||
|1a|Assessment of genotoxicity of pyrethrin in cultured human lymphocytes.|Quttina, Maram and Nassar, Liliana|2017|Sim|
||Assessment of occupational exposure to malathion and bifenthrin in|Kongtip, Pornpimol and Sasrisuk, Somnuek and<br>Preklang, Smart and Yoosook, Witaya and|||
|1a|mosquito control sprayers through dermal contact.|Sujirarat, Dusit|2013|Sim|
||Association between occupational exposures to pesticides with|Huang, Xusheng and Zhang, Chao and Hu, Ruifa<br>and Li, Yifan and Yin, Yanhong and Chen, Zhaohui|||
|1a|heterogeneous chemical structures and farmer health in China.|and Cai, Jinyang and Cui, Fang|2016|Sim|
||Association of pyrethroid pesticide exposure with attention-<br>deficit/hyperactivity disorder in a nationally representative sample of U.S.|Wagner-Schuman, Melissa and Richardson, Jason<br>R and Auinger, Peggy and Braun, Joseph M and<br>Lanphear, Bruce P and Epstein, Jeffery N and|||
|1a|children.|Yolton, Kimberly and Froehlich, Tanya E|2015|Sim|
||Behavioural disorders in 6-year-old children and pyrethroid insecticide|Viel, Jean-Francois and Rouget, Florence and|||
|1a|exposure: the PELAGIE mother-child cohort.|Warembourg, Charline and Monfort, Christine|2017|Sim|  
34  
|||and Limon, Gwendolina and Cordier, Sylvaine and<br>Chevrier, Cecile|||
|---|---|---|---|---|
||Bifenthrin-induced oxidative stress in human erythrocytes in vitro and|Sadowska-Woda, Izabela and Popowicz, Diana|||
|1a|protective effect of selected flavonols.|and Karowicz-Bilinska, Agata|2010|Não|
||Biochemical and toxicological evidence of neurological effects of pesticides:||||
|1a|the example of Parkinson's disease.|Moretto, A and Colosio, C|2011|Não|
||A capillary micellar electrokinetic chromatography method for the|Garcia, M feminine Angeles and Menendez-<br>Lopez, Nuria and Boltes, Karina and Castro-|||
|1a|stereoselective quantitation of bioallethrin in biotic and abiotic samples.|Puyana, Maria and Marina, M feminine Luisa|2017|Não|
|||Bhaskar, Emmanuel M and Moorthy, Swathy and|||
|1a|Cardiac conduction disturbance due to prallethrin (pyrethroid) poisoning.|Ganeshwala, Gaurav and Abraham, Georgi|2010|Sim|
||A case study on toxicological aspects of the pest and disease control in the|Sadlo, Stanislaw and Szpyrka, Ewa and|||
|1a|production of the high-quality raspberry (Rubus idaeus L.).|Piechowicz, Bartosz and Grodzicki, Przemyslaw|2015|Não|
||Changes on fecal microbiota in rats exposed to permethrin during postnatal|Nasuti, Cinzia and Coman, Maria Magdalena and<br>Olek, Robert A and Fiorini, Dennis and Verdenelli,<br>Maria Cristina and Cecchini, Cinzia and Silvi,<br>Stefania and Fedeli, Donatella and Gabbianelli,|||
|1a|development.|Rosita|2016|Não|
|1a|Characteristics and magnitude of acute pesticide-related illnesses and<br>injuries associated with pyrethrin and pyrethroid exposures--11 states,<br>2000-2008.|Hudson, Naomi L and Kasner, Edward J and<br>Beckman, John and Mehler, Louise and Schwartz,<br>Abby and Higgins, Sheila and Bonnar-Prado,<br>Joanne and Lackovic, Michelle and Mulay,<br>Prakash and Mitchell, Yvette and Larios, Leo and<br>Walker, Rob and Waltz, Justin and Moraga-<br>McHaley, Stephanie and Roisman, Rachel and<br>Calvert, Geoffrey M|2014|Sim|  
35  
|1a|Characterization of alpha-cypermethrin exposure in Egyptian agricultural<br>workers.|Singleton, Steven T and Lein, Pamela J and<br>Farahat, Fayssal M and Farahat, Taghreed and<br>Bonner, Matthew R and Knaak, James B and<br>Olson, James R|2014|Sim|
|---|---|---|---|---|
|||Abass, Khaled and Lamsa, Virpi and Reponen,<br>Petri and Kublbeck, Jenni and Honkakoski, Paavo<br>and Mattila, Sampo and Pelkonen, Olavi and|||
|1a|Characterization of human cytochrome P450 induction by pesticides.|Hakkola, Jukka|2012|Não|
|||O'Reilly, Kathryn E and Patel, Utpal and Chu, Julie|||
|1a|Chemical leukoderma.|and Patel, Rishi and Machler, Brian C|2011|Sim|
||Chlorfenapyr-Induced Toxic Leukoencephalopathy with Radiologic|Baek, Byung Hyun and Kim, Seul Kee and Yoon,<br>Woong and Heo, Tae Wook and Lee, Yun Young|||
|1a|Reversibility: A Case Report and Literature Review.|and Kang, Heoung Keun|2016|Sim|
||Chlorpyrifos and cypermethrin induce apoptosis in human neuroblastoma|Raszewski, Grzegorz and Lemieszek, Marta Kinga<br>and Lukawski, Krzysztof and Juszczak, Malgorzata|||
|1a|cell line SH-SY5Y.|and Rzeski, Wojciech|2015|Não|
||Chlorpyrifos and lambda cyhalothrin-induced oxidative stress in human|Deeba, Farah and Raza, Irum and Muhammad,<br>Noor and Rahman, Hazir and Ur Rehman, Zia and<br>Azizullah, Azizullah and Khattak, Baharullah and|||
|1a|erythrocytes.|Ullah, Farman and Daud, M K|2017|Não|
||Class-specific immunoaffinity monolith for efficient on-line clean-up of|Liang, Yuan and Zhou, Shuang and Hu, Liming and|||
|1a|pyrethroids followed by high-performance liquid chromatography analysis.|Li, Lin and Zhao, Meiping and Liu, Huwei|2010|Não|
||A comparative assessment of cytotoxicity of commonly used agricultural|Yun, Xinming and Huang, Qingchun and Rao,<br>Wenbing and Xiao, Ciying and Zhang, Tao and|||
|1a|insecticides to human and insect cells.|Mao, Zhifan and Wan, Ziyi|2017|Não|  
36  
||Comparative cytotoxic and genotoxic effects of permethrin and its|Sundaramoorthy, Rajiv and Velusamy, Yuvaraj<br>and Balaji, A P B and Mukherjee, Amitava and|||
|---|---|---|---|---|
|1a|nanometric form on human erythrocytes and lymphocytes in vitro.|Chandrasekaran, Natarajan|2016|Não|
||Comparative efficacy and safety of topical permethrin, topical ivermectin,|Chhaiya, Sunita B and Patel, Varsha J and Dave,<br>Jayendra N and Mehta, Dimple S and Shah, Hiral|||
|1a|and oral ivermectin in patients of uncomplicated scabies.|A|2012|Sim|
||Comparative efficacy of piperine and curcumin in deltamethrin induced||||
|1a|splenic apoptosis and altered immune functions.|Kumar, Anoop and Sharma, Neelima|2015|Não|
||Consumer and farmer safety evaluation of application of botanical|Hernandez-Moreno, David and Soffers, Ans E M F<br>and , Wiratno and Falke, Hein E and Rietjens,|||
|1a|pesticides in black pepper crop protection.|Ivonne M C M and Murk, Albertinka J|2013|Não|
||Cumulative risk assessment of the exposure to pyrethroids through fruits|Li, Zhixia and Nie, Jiyun and Lu, Zeqi and Xie,<br>Hanzhong and Kang, Lu and Chen, Qiusheng and<br>Li, An and Zhao, Xubo and Xu, Guofeng and Yan,|||
|1a|consumption in China - Based on a 3-year investigation.|Zhen|2016|Não|
||Cytokine patterns in greenhouse workers occupationally exposed to alpha-|Costa, Chiara and Rapisarda, Venerando and<br>Catania, Stefania and Di Nola, Carmelina and|||
|1a|cypermethrin: an observational study.|Ledda, Caterina and Fenga, Concettina|2013|Sim|
||Cytotoxic effect of fenitrothion and lambda-cyhalothrin mixture on lipid||||
|1a|peroxidation and antioxidant defense system in rat kidney.|El-Demerdash, Fatma M|2012|Não|
|1a|Cytotoxic, genotoxic and biochemical markers of insecticide toxicity<br>evaluated in human peripheral blood lymphocytes and an HepG2 cell line.|Zeljezic, Davor and Mladinic, Marin and Zunec,<br>Suzana and Lucic Vrdoljak, Ana and Kasuba,<br>Vilena and Tariba, Blanka and Zivkovic, Tanja and<br>Marjanovic, Ana Marija and Pavicic, Ivan and<br>Milic, Mirta and Rozgaj, Ruzica and Kopjar,<br>Nevenka|2016|Não|  
37  
||Cytotoxicity induced by cypermethrin in Human Neuroblastoma Cell Line|Raszewski, Grzegorz and Lemieszek, Marta Kinga|||
|---|---|---|---|---|
|1a|SH-SY5Y.|and Lukawski, Krzysztof|2016|Não|
||Cytotoxicity induced by deltamethrin and its metabolites in SH-SY5Y cells|Romero, Alejandro and Ramos, Eva and<br>Castellano, Victor and Martinez, Maria Aranzazu<br>and Ares, Irma and Martinez, Marta and<br>Martinez-Larranaga, Maria Rosa and Anadon,|||
|1a|can be  differentially prevented by selected antioxidants.|Arturo|2012|Não|
||DDT & deltamethrin resistance status of known Japanese encephalitis|Dhiman, Sunil and Rabha, Bipul and Talukdar, P K<br>and Das, N G and Yadav, Kavita and Baruah, Indra|||
|1a|vectors in Assam, India.|and Singh, Lokendra and Veer, Vijay|2013|Não|
|||Nardini, Luisa and Christian, Riann N and Coetzer,|||
|1a|DDT and pyrethroid resistance in Anopheles arabiensis from South Africa.|Nanette and Koekemoer, Lizette L|2013|Não|
|1a|Development and application of the adverse outcome pathway framework<br>for understanding and predicting chronic toxicity: II. A focus on growth<br>impairment in fish.|Groh, Ksenia J and Carvalho, Raquel N and<br>Chipman, James K and Denslow, Nancy D and<br>Halder, Marlies and Murphy, Cheryl A and<br>Roelofs, Dick and Rolaki, Alexandra and Schirmer,<br>Kristin and Watanabe, Karen H|2015|Não|
||Development of Environment-Friendly Insecticides Based on||||
|1a|Enantioselectivity: Bifenthrin as a Case.|Qian, Yi and Zhou, Peixue and Zhang, Quan|2017|Não|
|1a|Developmental neurotoxicity of succeeding generations of insecticides.|Abreu-Villaca, Yael and Levin, Edward D|2017|Sim|
|1a|Developmental pesticide exposure reproduces features of attention deficit<br>hyperactivity disorder.|Richardson, Jason R and Taylor, Michele M and<br>Shalat, Stuart L and Guillot, Thomas S 3rd and<br>Caudle, W Michael and Hossain, Muhammad M<br>and Mathews, Tiffany A and Jones, Sara R and<br>Cory-Slechta, Deborah A and Miller, Gary W|2015|Sim|  
38  
||Dietary exposure of Hong Kong adults to pesticide residues: results of the|Wong, Waiky W K and Yau, Arthur T C and Chung,<br>Stephen W C and Lam, Chi-ho and Ma, Stephanie|||
|---|---|---|---|---|
|1a|first  Hong Kong Total Diet Study.|and Ho, Y Y and Xiao, Ying|2014|Não|
||Differential state-dependent modification of rat Na(v)1.6 sodium channels<br>expressed in human embryonic kidney (HEK293) cells by the pyrethroid||||
|1a|insecticides tefluthrin and deltamethrin.|He, Bingjun and Soderlund, David M|2011|Não|
||Disruption of the hormonal network and the enantioselectivity of|Zhao, Meirong and Zhang, Ying and Zhuang,<br>Shulin and Zhang, Quan and Lu, Chengsheng and|||
|1a|bifenthrin in trophoblast: maternal-fetal health risk of chiral pesticides.|Liu, Weiping|2014|Não|
|1a|Do Varying Aquatic Plant Species Affect Phytoplankton and Crustacean<br>Responses to a Nitrogen-Permethrin Mixture?|Lizotte, Richard E Jr and Moore, Matthew T|2017|Não|
||Double-blind non-controlled chemical challenge with environmental||||
|1a|toxicological assessment in a Multiple Chemical Sensitivity case.|Ralph, Baden and Martine, Ott and Jacques, Reis|2011|Não|
|1a|Early changes in proteome levels upon acute deltamethrin exposure in<br>mammalian skin system associated with its neoplastic transformation<br>potential.|George, Jasmine and Shukla, Yogeshwer|2013|Não|
|1a|Ecotoxicogenomics: Microarray interlaboratory comparability.|Vidal-Dorsch, Doris E and Bay, Steven M and<br>Moore, Shelly and Layton, Blythe and Mehinto,<br>Alvine C and Vulpe, Chris D and Brown-Augustine,<br>Marianna and Loguinov, Alex and Poynton, Helen<br>and Garcia-Reyero, Natalia and Perkins, Edward J<br>and Escalon, Lynn and Denslow, Nancy D and<br>Cristina, Colli-Dula R and Doan, Tri and<br>Shukradas, Shweta and Bruno, Joy and Brown,<br>Lorraine and Van Agglen, Graham and Jackman,<br>Paula and Bauer, Megan|2016|Não|  
39  
|1a|Effect of bednets and indoor residual spraying on spatio-temporal<br>clustering of malaria in a village in south Ethiopia: a longitudinal study.|Loha, Eskindir and Lunde, Torleif Markussen and<br>Lindtjorn, Bernt|2012|Não|
|---|---|---|---|---|
||Effect of Dursban 480 EC (chlorpyrifos) and Talstar 10 EC (bifenthrin) on the|Medo, Juraj and Makova, Jana and Kovacsova,<br>Silvia and Majercikova, Kamila and Javorekova,|||
|1a|physiological and genetic diversity of microorganisms in soil.|Sona|2015|Não|
||The effect of environmental exposure to pyrethroids and DNA damage in|Jurewicz, Joanna and Radwan, Michal and<br>Wielgomas, Bartosz and Sobala, Wojciech and<br>Piskunowicz, Marta and Radwan, Pawel and|||
|1a|human sperm.|Bochenek, Michal and Hanke, Wojciech|2015|Não|
||The effect of insecticides chlorpyrifos, alpha-cypermethrin and imidacloprid<br>on primary DNA damage, TP 53 and c-Myc structural integrity by comet-|Zeljezic, Davor and Vinkovic, Benjamin and<br>Kasuba, Vilena and Kopjar, Nevenka and Milic,|||
|1a|FISH assay.|Mirta and Mladinic, Marin|2017|Não|
||Effect of lambda cyhalothrin on Calothrix sp. (GUEco 1001), an||||
|1a|autochthonous cyanobacterium of rice fields of Brahmaputra floodplain.|Gupta, Kiran and Baruah, P P|2015|Não|
||Effect of selected antioxidants in beta-cyfluthrin-induced oxidative stress in|Sadowska-Woda, Izabela and Wojcik, Natalia and<br>Karowicz-Bilinska, Agata and Bieszczad-|||
|1a|human erythrocytes in vitro.|Bedrejczuk, Edyta|2010|Não|
||Effect of some commonly used pesticides on seed germination, biomass<br>production and photosynthetic pigments in tomato (Lycopersicon|Shakir, Shakirullah Khan and Kanwal, Memoona<br>and Murad, Waheed and Rehman, Zia ur and<br>Rehman, Shafiq ur and Daud, M K and Azizullah,|||
|1a|esculentum).|Azizullah|2016|Não|
||Effect of synthetic pyrethroid pesticide exposure during pregnancy on the|Xue, Zhanyou and Li, Xiaoqiong and Su, Qian and<br>Xu, Li and Zhang, Peng and Kong, Zhenyu and Xu,|||
|1a|growth  and development of infants.|Jianhui and Teng, Junfang|2013|Não|
||Effect of three insecticides and two herbicides on rice (Oryza sativa)||||
|1a|seedling germination and growth.|Moore, M T and Kroger, R|2010|Não|  
40  
|1a|Effects of cypermethrin on Allium cepa.|Cavusoglu, Kultigin and Kaya, Arzu and Yilmaz,<br>Fadime and Yalcin, Emine|2012|Não|
|---|---|---|---|---|
||Effects of cypermethrin on the ligand-independent interaction between|Pan, Chen and Liu, Ya-Peng and Li, Yan-Fang and<br>Hu, Jin-Xia and Zhang, Jin-Peng and Wang, Hong-|||
|1a|androgen receptor and steroid receptor coactivator-1.|Mei and Li, Jing and Xu, Li-Chun|2012|Não|
||Effects of non-occupational environmental exposure to pyrethroids on|Ji, Guixiang and Xia, Yankai and Gu, Aihua and<br>Shi, Xiangguo and Long, Yan and Song, Ling and|||
|1a|semen quality and sperm DNA integrity in Chinese men.|Wang, Shoulin and Wang, Xinru|2011|Não|
||The effects of oral treatment with transfluthrin on the urothelium of rats|Yokohira, Masanao and Arnold, Lora L and<br>Lautraite, Sophie and Sheets, Larry and Wason,<br>Sheila and Stahl, Bernhard and Eigenberg, David<br>and Pennington, Karen L and Kakiuchi-Kiyota,|||
|1a|and its metabolite, tetrafluorobenzoic acid on urothelial cells in vitro.|Satoko and Cohen, Samuel M|2011|Não|
||Effects of pyrethroid pesticide cis-bifenthrin on lipogenesis in hepatic cell|Xiang, Dandan and Chu, Tianyi and Li, Meng and|||
|1a|line.|Wang, Qiangwei and Zhu, Guonian|2018|Não|
||The effects of taurine on permethrininduced cytogenetic and oxidative||||
|1a|damage in cultured human lymphocytes.|Turkez, Hasan and Aydin, Elanur|2012|Não|
||Effects of the beta1 auxiliary subunit on modification of Rat Na(v)1.6<br>sodium channels expressed in HEK293 cells by the pyrethroid insecticides||||
|1a|tefluthrin and deltamethrin.|He, Bingjun and Soderlund, David M|2016|Não|
|||Mostafa, Heba El-Sayed and Abd El-Baset, Samia<br>A and Kattaia, Asmaa A A and Zidan, Rania A and|||
|1a|Efficacy of naringenin against permethrin-induced testicular toxicity in rats.|Al Sadek, Mona M A|2016|Não|
||Elucidation of pyrethroid and DDT receptor sites in the voltage-gated||||
|1a|sodium channel.|Zhorov, Boris S and Dong, Ke|2017|Não|
|1a|An empirical approach to sufficient similarity: combining exposure data and<br>mixtures toxicology data.|Marshall, Scott and Gennings, Chris and<br>Teuschler, Linda K and Stork, Leanna G and|2013|Não|  
41  
|||Tornero-Velez, Rogelio and Crofton, Kevin M and<br>Rice, Glenn E|||
|---|---|---|---|---|
||Enantioselective apoptosis induced by individual isomers of bifenthrin in||||
|1a|Hep G2  cells.|Liu, Huigang and Li, Juan|2015|Não|
||An endocrine-disrupting chemical, fenvalerate, induces cell cycle<br>progression and collagen type I expression in human uterine leiomyoma|Gao, Xiaohua and Yu, Linda and Castro, Lysandra<br>and Moore, Alicia B and Hermon, Tonia and|||
|1a|and myometrial cells.|Bortner, Carl and Sifre, Maria and Dixon, Darlene|2010|Não|
||Endocrine disruptor activity of multiple environmental food chain|Wielogorska, E and Elliott, C T and Danaher, M|||
|1a|contaminants.|and Connolly, L|2015|Não|
||Environmental and occupational pesticide exposure and human sperm||||
|1a|parameters: a systematic review.|Martenies, Sheena E and Perry, Melissa J|2013|Não|
||Environmental benignity of a pesticide in soft colloidal hydrodispersive<br>nanometric form with improved toxic precision towards the target|Balaji, A P B and Sastry, Thotapalli P and<br>Manigandan, Subramani and Mukherjee, Amitava|||
|1a|organisms than non-target organisms.|and Chandrasekaran, Natarajan|2017|Não|
||Environmental exposure to pyrethroids and sperm sex chromosome|Young, Heather A and Meeker, John D and<br>Martenies, Sheena E and Figueroa, Zaida I and|||
|1a|disomy: a cross-sectional study.|Barr, Dana Boyd and Perry, Melissa J|2013|Não|
||Evaluation of efficacy and human health risk of aerial ultra-low volume<br>applications of pyrethrins and piperonyl butoxide for adult mosquito<br>management in response to West Nile virus activity in Sacramento County,|Macedo, Paula A and Schleier, Jerome J 3rd and<br>Reed, Marcia and Kelley, Kara and Goodman,<br>Gary W and Brown, David A and Peterson, Robert|||
|1a|California.|K D|2010|Não|
|||Nagy, Karoly and Racz, Gabor and Matsumoto,|||
|1a|Evaluation of the genotoxicity of the pyrethroid insecticide phenothrin.|Takashi and Adany, Roza and Adam, Balazs|2014|Não|
||Evaluation of the human relevance of the constitutive androstane receptor-<br>mediated mode of action for rat hepatocellular tumor formation by the|Okuda, Yu and Kushida, Masahiko and Kikumoto,<br>Hiroko and Nakamura, Yoshimasa and Higuchi,|||
|1a|synthetic pyrethroid momfluorothrin.|Hashihiro and Kawamura, Satoshi and Cohen,|2017|Não|  
42  
|||Samuel M and Lake, Brian G and Yamada,<br>Tomoya|||
|---|---|---|---|---|
||Evaluation of the stereoselective biotransformation of permethrin in<br>human liver  microsomes: contributions of cytochrome P450|Lavado, Ramon and Li, Jiwen and Rimoldi, John M|||
|1a|monooxygenases to the formation of estrogenic metabolites.|and Schlenk, Daniel|2014|Não|
||Evidence for dose-additive effects of a type II pyrethroid mixture. In vitro|Romero, A and Ares, I and Ramos, E and<br>Castellano, V and Martinez, M and Martinez-|||
|1a|assessment.|Larranaga, M R and Anadon, A and Martinez, M A|2015|Não|
||Exclusion of phlebotomine sand flies from inhabited areas by means of|Faiman, R and Kirstein, O and Freund, M and|||
|1a|vertical mesh barriers.|Guetta, H and Warburg, A|2011|Não|
||Exogenous application of salicylic acid to alleviate the toxic effects of|Singh, Aradhana and Srivastava, Anjil Kumar and|||
|1a|insecticides in Vicia faba L.|Singh, Ashok Kumar|2013|Não|
|1a|Exposure to cypermethrin and mancozeb alters the expression profile of<br>THBS1, SPP1, FEZ1 and GPNMB in human peripheral blood mononuclear<br>cells.|Mandarapu, Rajesh and Prakhya, Balakrishna<br>Murthy|2016|Não|
||Exposure to pyrethroid pesticides and the risk of childhood brain tumors in|Chen, Sheng and Gu, Shuo and Wang, Yue and<br>Yao, Yongliang and Wang, Guoquan and Jin, Yue|||
|1a|East  China.|and Wu, Yeming|2016|Não|
||Exposure to pyrethroids insecticides and serum levels of thyroid-related|Zhang, Jie and Hisada, Aya and Yoshinaga, Jun<br>and Shiraishi, Hiroaki and Shimodaira, Kazuhisa<br>and Okai, Takashi and Noda, Yumiko and|||
|1a|measures in pregnant women.|Shirakawa, Miyako and Kato, Nobumasa|2013|Não|
|1a|"Exposure to the insecticides permethrin and malathion induces leukemia<br>and lymphoma-associated gene aberrations in vitro".|Navarrete-Meneses, M P and Salas-Labadia, C<br>and Sanabrais-Jimenez, M and Santana-<br>Hernandez, J and Serrano-Cuevas, A and Juarez-<br>Velazquez, R and Olaya-Vargas, A and Perez-Vera,<br>P|2017|Não|  
43  
|1a|Fatality from acute chlorfenapyr poisoning.|Choi, Ung Tae and Kang, Gu Hyun and Jang, Yong<br>Soo and Ahn, Hee Cheol and Seo, Jeong Youl and<br>Sohn, You Dong|2010|Sim|
|---|---|---|---|---|
||Fenpropathrin, a Widely Used Pesticide, Causes Dopaminergic|Xiong, Jing and Zhang, Xiaowei and Huang, Jinsha<br>and Chen, Chunnuan and Chen, Zhenzhen and<br>Liu, Ling and Zhang, Guoxin and Yang, Jiaolong<br>and Zhang, Zhentao and Zhang, Zhaohui and Lin,|||
|1a|Degeneration.|Zhicheng and Xiong, Nian and Wang, Tao|2016|Não|
||Fenugreek supplementation imparts erythrocyte resistance to||||
|1a|cypermethrin induced  oxidative changes in vivo.|Navayath, Sushma and Thiyagarajan, Devasena|2011|Não|
||Fetal exposure to chlordane and permethrin mixtures in relation to|Neta, Gila and Goldman, Lynn R and Barr, Dana<br>and Apelberg, Benjamin J and Witter, Frank R and|||
|1a|inflammatory cytokines and birth outcomes.|Halden, Rolf U|2011|Não|
||A field trial of a fixed combination of permethrin and fipronil (Effitix((R)))<br>for the treatment and prevention of flea infestation in dogs living with|Chatzis, Manolis K and Psemmas, Dimitris and<br>Papadopoulos, Elias and Navarro, Christelle and|||
|1a|sheep.|Saridomichelakis, Manolis N|2017|Não|
||Genetic mapping identifies a major locus spanning P450 clusters associated|Witzig, C and Parry, M and Morgan, J C and<br>Irving, H and Steven, A and Cuamba, N and<br>Kerah-Hinzoumbe, C and Ranson, H and Wondji,|||
|1a|with pyrethroid resistance in kdr-free Anopheles arabiensis from Chad.|C S|2013|Não|
||Genotoxic and cytotoxic evaluation of pyrethroid insecticides lambda-||||
|1a|cyhalothrin  and alpha-cypermethrin on human blood lymphocyte culture.|Muranli, Fulya Dilek Gokalp|2013|Não|
||Genotoxic effects of a particular mixture of acetamiprid and alpha-<br>cypermethrin on chromosome aberration, sister chromatid exchange, and||||
|1a|micronucleus formation in human peripheral blood lymphocytes.|Kocaman, Ayse Yavuz and Topaktas, Mehmet|2010|Não|
||Genotoxic effects of chlorpyrifos, cypermethrin, endosulfan and 2,4-D on||||
|1a|human peripheral lymphocytes cultured from smokers and nonsmokers.|Sandal, Suleyman and Yilmaz, Bayram|2011|Não|  
44  
|1a|Genotoxic evaluation of Halfenprox using the human peripheral<br>lymphocyte micronucleus assay and the Ames test.|Akyil, Dilek and Eren, Yasin and Konuk, Muhsin<br>and Dere, Hatice and Serteser, Ahmet|2017|Não|
|---|---|---|---|---|
||Genotoxicity of fenpropathrin and fenitrothion on root tip cells of Vicia|Bu, N and Wang, S H and Yu, C M and Zhang, Y|||
|1a|faba.|and Ma, C Y and Li, X M and Ma, L J|2011|Não|
||The growth behavior of three marine phytoplankton species in the|Wang, Zhao-Hui and Yang, Yu-feng and Yue,<br>Wen-Jie and Kang, Wei and Liang, Wen-Jun and|||
|1a|presence of commercial cypermethrin.|Li, Wei-Jie|2010|Não|
||Gulf War agent exposure causes impairment of long-term memory<br>formation and neuropathological changes in a mouse model of Gulf War|Zakirova, Zuchra and Tweed, Miles and Crynen,<br>Gogce and Reed, Jon and Abdullah, Laila and<br>Nissanka, Nadee and Mullan, Myles and Mullan,<br>Michael J and Mathura, Venkatarajan and|||
|1a|Illness.|Crawford, Fiona and Ait-Ghezala, Ghania|2015|Não|
||Hazard-ranking of agricultural pesticides for chronic health effects in Yuma|Sugeng, Anastasia J and Beamer, Paloma I and|||
|1a|County, Arizona.|Lutz, Eric A and Rosales, Cecilia B|2013|Não|
||Home Use of a Pyrethroid-Containing Pesticide and Facial Paresthesia in a|Perkins, Alexandra and Walters, Frederick and<br>Sievert, Jennifer and Rhodes, Blaine and|||
|1a|Toddler: A Case Report.|Morrissey, Barbara and Karr, Catherine J|2016|Sim|
|1a|Human intravenous injection of beta-cyfluthrin with minimal toxic effects.|Miller, Michael A and Menowsky, Michael|2014|Sim|
||Human volunteer studies investigating the potential for toxicokinetic<br>interactions between the pesticides deltamethrin; pirimicarb and||||
|1a|chlorpyrifos-methyl following oral exposure at the acceptable daily intake.|Sams, Craig and Jones, Kate|2011|Sim|
|||Skolarczyk, Justyna and Pekar, Joanna and|||
|1a|Immune disorders induced by exposure to pyrethroid insecticides.|Nieradko-Iwanicka, Barbara|2017|Não|
||Immunological and genotoxic effects of occupational exposure to alpha-|El Okda, El-Sayed and Abdel-Hamid, Mona Abdel-|||
|1a|cypermethrin pesticide.|Aal and Hamdy, Ahmed Mohamed|2017|Não|
||Immunomodulation of serum complement (C3) and macrophages by||||
|1a|synthetic pyrethroid fenvalerate: in vitro study.|Dutta, Raini and Das, Nibhriti|2011|Não|  
45  
|1a|Immunotoxicity of pyrethroid metabolites in an in vitro model.|Zhang, Ying and Zhao, Meirong and Jin, Meiqing<br>and Xu, Chao and Wang, Cui and Liu, Weiping|2010|Não|
|---|---|---|---|---|
|1a|Impact of a proposed revision of the IESTI equation on the acute risk<br>assessment  conducted when setting maximum residue levels (MRLs) in the<br>European Union (EU): A case study.|Breysse, Nicolas and Vial, Gaelle and Pattingre,<br>Lauriane and Ossendorp, Bernadette C and<br>Mahieu, Karin and Reich, Hermine and Rietveld,<br>Anton and Sieke, Christian and van der Velde-<br>Koerts, Trijntje and Sarda, Xavier|2018|Não|
|1a|Impact of beta-cypermethrin on soil microbial community associated with<br>its bioavailability: a combined study by isothermal microcalorimetry and<br>enzyme assay techniques.|Zhuang, Rensheng and Chen, Huilun and Yao, Jun<br>and Li, Zhe and Burnet, Julia Ellis and Choi,<br>Martin M F|2011|Não|
|1a|[Impact of prenatal pyrethroid exposure on neurodevelopment of one-year<br>old infants].|Qi, Xiaojuan and Zheng, Minglan and Wu,<br>Chunhua and Chang, Xiuli and Wang, Guoquan<br>and Lu, Dasheng and Zhou, Zhijun|2011|Não|
|||Wondji, Charles S and Coleman, Michael and<br>Kleinschmidt, Immo and Mzilahowa, Themba and<br>Irving, Helen and Ndula, Miranda and Rehman,<br>Andrea and Morgan, John and Barnes, Kayla G|||
|1a|Impact of pyrethroid resistance on operational malaria control in Malawi.|and Hemingway, Janet|2012|Não|
|||Ding, Ruqian and Cao, Zongfu and Wang, Yihan<br>and Gao, Xiaobo and Luo, Haiyan and Zhang,<br>Changyong and Ma, Shuangcheng and Ma, Xu|||
|1a|The implication of p66shc in oxidative stress induced by deltamethrin.|and Jin, Hongyu and Lu, Cailing|2017|Não|
|1a|The in vitro exposure to cypermethrin does not inhibit the proliferative<br>response of peripheral blood mononuclear cells.|Almeida, Tatiana Fernandes Araujo and Lauton<br>Santos, Sandra and Nicomedes, Ulisses Lara and<br>Brito-Melo, Gustavo Eustaquio and Rocha-Vieira,<br>Etel|2016|Não|  
46  
||In vitro myelotoxic effects of cypermethrin and mancozeb on human|Mandarapu, Rajesh and Prakhya, Balakrishna|||
|---|---|---|---|---|
|1a|hematopoietic progenitor cells.|Murthy|2015|Não|
||In vitro study of cypermethrin on human spermatozoa and the possible|Zalata, A and Elhanbly, S and Abdalla, H and<br>Serria, M S and Aziz, A and El-Dakrooy, S A and El-|||
|1a|protective role of vitamins C and E.|Bakary, A A and Mostafa, T|2014|Não|
|1a|Increasing use of pyrethroids in Canadian households: should we be<br>concerned?|van Balen, Erna C and Wolansky, Marcelo J and<br>Kosatsky, Tom|2012|Sim|
||Influences on transfer of selected synthetic pyrethroids from treated|Melnyk, Lisa Jo and Hieber, Thomas E and<br>Turbeville, Tracy and Vonderheide, Anne P and|||
|1a|Formica to  foods.|Morgan, Jeffrey N|2011|Não|
||Inhibition of Human Drug Transporter Activities by the Pyrethroid|Chedik, Lisa and Bruyere, Arnaud and Le Vee,<br>Marc and Stieger, Bruno and Denizot, Claire and<br>Parmentier, Yannick and Potin, Sophie and|||
|1a|Pesticides Allethrin and Tetramethrin.|Fardel, Olivier|2017|Não|
|||Kim, Dongseob and Moon, Jeongmi and Chun,|||
|1a|The initial hyperglycemia in acute type II pyrethroid poisoning.|Byeongjo|2015|Sim|
||Insecticide resistance in head lice: clinical, parasitological and genetic|Durand, R and Bouvresse, S and Berdjane, Z and|||
|1a|aspects.|Izri, A and Chosidow, O and Clark, J M|2012|Não|
||Insecticide substitutes for DDT to control mosquitoes may be causes of||||
|1a|several diseases.|Rahman, Md Mahbubar|2013|Não|
|1a|Insecticides reduce survival and the expression of traits associated with<br>carnivory of carnivorous plants.|Jennings, David E and Congelosi, Alexandra M<br>and Rohr, Jason R|2012|Não|
|1a|Integrative assessment of enantioselectivity in endocrine disruption and<br>immunotoxicity of synthetic pyrethroids.|Zhao, Meirong and Chen, Fang and Wang, Cui<br>and Zhang, Quan and Gan, Jianying and Liu,<br>Weiping|2010|Não|  
47  
||[An intoxication can hide another one more serious. Example of a fatal<br>poisoning  with ethylene glycol intoxication masked by a pyrethroid|Aissaoui, Younes and Kichna, Hicham and<br>Boughalem, Mohammed and Kamili, Noureddine|||
|---|---|---|---|---|
|1a|insecticide].|Drissi|2013|Sim|
||Is cumulated pyrethroid exposure associated with prediabetes? A cross-|Hansen, Martin Rune and Jors, Erik and Lander,<br>Flemming and Condarco, Guido and Schlunssen,|||
|1a|sectional study.|Vivi|2014|Não|
||Isolation of alpaca anti-hapten heavy chain single domain antibodies for|Kim, Hee-Joo and McCoy, Mark R and Majkova,<br>Zuzana and Dechant, Julie E and Gee, Shirley J<br>and Tabares-da Rosa, Sofia and Gonzalez-|||
|1a|development of sensitive immunoassay.|Sapienza, Gualberto G and Hammock, Bruce D|2012|Não|
||Isolation of broad-specificity domain antibody from phage library for|Zhao, Yanyan and Liang, Ying and Liu, Yuan and<br>Zhang, Xiao and Hu, Xiaodan and Tu, Sicong and<br>Wu, Aihua and Zhang, Cunzheng and Zhong,<br>Jianfeng and Zhao, Shengming and Liu, Xianjin|||
|1a|development of pyrethroid immunoassay.|and Tu, Kang|2016|Não|
|1a|The life cycle and effectiveness of insecticides against the bed bugs of<br>Thailand.|Suwannayod, Suttida and Chanbang, Yaowaluk<br>and Buranapanichpan, Sawai|2010|Não|
||[Limited toxicity of the pediculicides pyrethrin, pyrethroids, and||||
|1a|permethrin].|Sunderkotter, C and Kirchhefer, U|2010|Sim|
|1a|Lupus erythematosus. Are residential insecticides exposure the missing<br>link?|Fortes, Cristina|2010|Não|
|||Tsuji, Ryozo and Yamada, Tomoya and|||
|1a|Mammal toxicology of synthetic pyrethroids.|Kawamura, Satoshi|2012|Sim|
|1a|Maternal Exposure to Pyrethroid Insecticides during Pregnancy and Infant<br>Development at 18 Months of Age.|Hisada, Aya and Yoshinaga, Jun and Zhang, Jie<br>and Kato, Takahiko and Shiraishi, Hiroaki and<br>Shimodaira, Kazuhisa and Okai, Takashi and Ariki,|2017|Não|  
48  
|||Nagako and Komine, Yoko and Shirakawa,<br>Miyako and Noda, Yumiko and Kato, Nobumasa|||
|---|---|---|---|---|
||Mechanism of pyrethroid pesticide-induced apoptosis: role of calpain and||||
|1a|the ER stress pathway.|Hossain, Muhammad M and Richardson, Jason R|2011|Não|
|1a|Methodologies for estimating cumulative human exposures to current-use<br>pyrethroid pesticides.|Tulve, Nicolle S and Egeghy, Peter P and<br>Fortmann, Roy C and Xue, Jianping and Evans,<br>Jeff and Whitaker, Donald A and Croghan, Carry<br>W|2011|Não|
||Methomyl-alphamethrin poisoning presented with cholinergic crisis,|Hu, Yu-Hui and Yang, Chen-Chang and Deng, Juo-|||
|1a|cortical blindness, and delayed peripheral neuropathy.|Fang and Wu, Ming-Ling|2010|Sim|
||Microbial detoxification of bifenthrin by a novel yeast and its potential for|Chen, Shaohua and Luo, Jianjun and Hu, Meiying|||
|1a|contaminated soils treatment.|and Geng, Peng and Zhang, Yanbo|2012|Não|
|1a|Molecular mechanisms of pyrethroid insecticide neurotoxicity: recent<br>advances.|Soderlund, David M|2012|Sim|
||Monitoring and risk assessment of 74 pesticide residues in Pu-erh tea|Chen, Hongping and Wang, Qinghua and Jiang,<br>Ying and Wang, Chuanpi and Yin, Peng and Liu,|||
|1a|produced in Yunnan, China.|Xin and Lu, Chengyin|2015|Não|
||Motor neuron disorder with tongue spasms due to pyrethroid insecticide|Ahdab, R and Ayache, S S and Maltonti, F and|||
|1a|toxicity.|Brugieres, P and Lefaucheur, J-P|2011|Sim|
||mTOR inhibition by rapamycin protects against deltamethrin-induced|Park, Yun Sun and Park, Jae Hyeon and Ko,|||
|1a|apoptosis in PC12 Cells.|Juyeon and Shin, In Chul and Koh, Hyun Chul|2017|Não|
|1a|Multicentre studies of insecticide-treated durable wall lining in Africa and<br>South-East Asia: entomological efficacy and household acceptability during<br>one year of field use.|Messenger, Louisa A and Matias, Abrahan and<br>Manana, Antonio Nkulu and Stiles-Ocran, Joseph<br>B and Knowles, Steve and Boakye, Daniel A and<br>Coulibaly, Mamadou B and Larsen, Marie-Louise<br>and Traore, Amadou S and Diallo, Brehima and<br>Konate, Mamadou and Guindo, Amadou and|2012|Não|  
49  
|||Traore, Sekou F and Mulder, Chris Eg and Le,<br>Hoan and Kleinschmidt, Immo and Rowland,<br>Mark|||
|---|---|---|---|---|
||Mutagenic and cytotoxic potential of Endosulfan and Lambda-cyhalothrin -|Saleem, Umber and Ejaz, Sohail and Ashraf,<br>Muhammad and Omer, Muhammad Ovais and<br>Altaf, Imran and Batool, Zainab and Fatima, Riffat|||
|1a|in vitro study describing individual and combined effects of pesticides.|and Afzal, Msbah|2014|Não|
||Mutagenic biomonitoring of pirethroid insecticides in human lymphocyte<br>cultures:  use of micronuclei as biomarkers and recovery by Rosa canina||||
|1a|extracts of mutagenic effects.|Kasimoglu, Caner and Uysal, Handan|2015|Não|
||Myopia and Exposure to Organophosphate and Pyrethroid Pesticides in the|Migneron-Foisy, Vincent and Bouchard, Maryse F|||
|1a|General United States Population.|and Freeman, Ellen E and Saint-Amour, Dave|2017|Não|
|1a|Natural pyrethrins induces apoptosis in human hepatocyte cells via Bax-<br>and Bcl-2-mediated mitochondrial pathway.|Yang, Yun and Zong, Mimi and Xu, Wenping and<br>Zhang, Yang and Wang, Bo and Yang, Mingjun<br>and Tao, Liming|2017|Não|
|||Grzywacz, Kelly and Brochu, Pierre and<br>Beaunoyer, Mona and Lallier, Michel and Alvarez,|||
|1a|Neonatal peliosis with maternal ingestion of pesticides.|Fernando|2014|Sim|
|1a|Net risk: a risk assessment of long-lasting insecticide bed nets used for<br>malaria management.|Peterson, Robert K D and Barber, Loren M and<br>Schleier, Jerome J 3rd|2011|Não|
|1a|Neurobehavioral effects of exposure to organophosphates and pyrethroid<br>pesticides among Thai children.|Fiedler, Nancy and Rohitrattana, Juthasiri and<br>Siriwong, Wattasit and Suttiwan, Panrapee and<br>Ohman Strickland, Pam and Ryan, P Barry and<br>Rohlman, Diane S and Panuwet, Parinya and Barr,<br>Dana Boyd and Robson, Mark G|2015|Sim|
|||Burns, Carol J and Cohen, Stuart Z and Lunchick,|||
|1a|Neurodevelopmental disorders and agricultural pesticide exposures.|Curt|2015|Sim|  
50  
||Neurodevelopmental disorders and prenatal residential proximity to|Shelton, Janie F and Geraghty, Estella M and<br>Tancredi, Daniel J and Delwiche, Lora D and<br>Schmidt, Rebecca J and Ritz, Beate and Hansen,|||
|---|---|---|---|---|
|1a|agricultural pesticides: the CHARGE study.|Robin L and Hertz-Picciotto, Irva|2014|Não|
||A new long-lasting indoor residual formulation of the organophosphate<br>insecticide pirimiphos methyl for prolonged control of pyrethroid-resistant|Rowland, Mark and Boko, Pelagie and Odjo,<br>Abibatou and Asidi, Alex and Akogbeto, Martin|||
|1a|mosquitoes: an experimental hut trial in Benin.|and N'Guessan, Raphael|2013|Não|
||Nontarget effects of chemical pesticides and biological pesticide on|Singh, Sunil and Gupta, Rashi and Kumari, Madhu|||
|1a|rhizospheric microbial community structure and function in Vigna radiata.|and Sharma, Shilpi|2015|Não|
||A novel toxicokinetic modeling of cypermethrin and permethrin and their|Cote, Jonathan and Bonvalot, Yvette and Carrier,<br>Gaetan and Lapointe, Caroline and Fuhr, Uwe<br>and Tomalik-Scharte, Dorota and Wachall, Bertil|||
|1a|metabolites in humans for dose reconstruction from biomarker data.|and Bouchard, Michele|2014|Sim|
||Occupational exposure to pesticides and consequences on male semen and|Mehrpour, Omid and Karrari, Parissa and Zamani,<br>Nasim and Tsatsakis, Aristides M and Abdollahi,|||
|1a|fertility: a review.|Mohammad|2014|Não|
||Olive (Olea europaea L.) leaf extract counteracts genotoxicity and oxidative||||
|1a|stress of permethrin in human lymphocytes.|Turkez, Hasan and Togar, Basak|2011|Não|
||Organophosphate-pyrethroid combination pesticides may be associated<br>with increased toxicity in human poisoning compared to either pesticide|Iyyadurai, R and Peter, J V and Immanuel, S and<br>Begum, A and Zachariah, A and Jasmine, S and|||
|1a|alone.|Abhilash, K P P|2014|Sim|
||Oxidative stress and gene expression profiling of cell death pathways in|Romero, Alejandro and Ramos, Eva and Ares,<br>Irma and Castellano, Victor and Martinez, Marta<br>and Martinez-Larranaga, Maria-Rosa and|||
|1a|alpha-cypermethrin-treated SH-SY5Y cells.|Anadon, Arturo and Martinez, Maria-Aranzazu|2017|Não|
||Oxidative stress and genetic damage among workers exposed primarily to|Zepeda-Arce, Rigoberto and Rojas-Garcia, Aurora|||
|1a|organophosphate and pyrethroid pesticides.|Elizabeth and Benitez-Trinidad, Alma and|2017|Não|  
51  
|||Herrera-Moreno, Jose Francisco and Medina-<br>Diaz, Irma Martha and Barron-Vivanco, Briscia S<br>and Villegas, German Pier and Hernandez-Ochoa,<br>Isabel and Solis Heredia, Maria de Jesus and<br>Bernal-Hernandez, Yael Y|||
|---|---|---|---|---|
|1a|Oxidative stress in the blood of farm workers following intensive pesticide<br>exposure.|Ogut, Serdal and Gultekin, Fatih and Kisioglu, A<br>Nesimi and Kucukoner, Erdogan|2011|Sim|
|1a|A permethrin/allethrin mixture induces genotoxicity and cytotoxicity in<br>human peripheral blood lymphocytes.|Ramos-Chavez, Lucio A and Sordo, Monserrat<br>and Calderon-Aranda, Emma and Castaneda-<br>Saucedo, Eduardo and Ostrosky-Wegman,<br>Patricia and Moreno-Godinez, Ma Elena|2015|Não|
|1a|Permethrin alters adipogenesis in 3T3-L1 adipocytes and causes insulin<br>resistance in C2C12 myotubes.|Kim, Jonggun and Park, Yooheon and Yoon,<br>Kyong Sup and Clark, J Marshall and Park,<br>Yeonhwa|2014|Não|
|1a|Permethrin and ivermectin for scabies.|Currie, Bart J and McCarthy, James S|2010|Não|
|1a|Permethrin drastically affects the developmental cycle of the non-target<br>slime mould Dictyostelium discoideum.|Amaroli, Andrea and Gallus, Lorenzo and<br>Ferrando, Sara|2018|Não|
|1a|Permethrin for scabies in children.|Albakri, Lina and Goldman, Ran D|2010|Não|
|||Wang, Xu and Martinez, Maria-Aranzazu and Dai,<br>Menghong and Chen, Dongmei and Ares, Irma<br>and Romero, Alejandro and Castellano, Victor<br>and Martinez, Marta and Rodriguez, Jose Luis and<br>Martinez-Larranaga, Maria-Rosa and Anadon,|||
|1a|Permethrin-induced oxidative stress and toxicity and metabolism. A review.|Arturo and Yuan, Zonghui|2016|Não|
||Persistence of bifenthrin in sandy loam soil as affected by microbial||||
|1a|community.|Sharma, Divya and Singh, Shashi Bala|2012|Não|  
52  
|1a|Persistence of alpha-cypermethrin residues in milk of lactating donkeys<br>(Equus asinus) using UHPLC-MS/MS.|Chirollo, Claudia and Radovnikovic, Anita and<br>Veneziano, Vincenzo and Marrone, Raffaele and<br>Pepe, Tiziana and Danaher, Martin and Anastasio,<br>Aniello|2014|Não|
|---|---|---|---|---|
|||Gyenwali, Deepak and Vaidya, Abhinav and<br>Tiwari, Sundar and Khatiwada, Prakash and|||
|1a|Pesticide poisoning in Chitwan, Nepal: a descriptive epidemiological study.|Lamsal, Daya Ram and Giri, Shrikrishana|2017|Sim|
||Pesticide poisoning trend analysis of 13 years: a retrospective study based<br>on telephone calls at the National Poisons Information Centre, All India|Peshin, Sharda Shah and Srivastava, Amita and|||
|1a|Institute of Medical Sciences, New Delhi.|Halder, Nabanita and Gupta, Yogendra Kumar|2014|Sim|
||Pesticide-related poison center exposures in children and adolescents aged|Trueblood, Amber B and Forrester, Mathias B and<br>Han, Daikwon and Shipp, Eva M and Cizmas,|||
|1a|</=19  years in Texas, 2000-2013.|Leslie H|2016|Sim|
|1a|Pesticide residues in human breast milk: risk assessment for infants from<br>Punjab, India.|Bedi, J S and Gill, J P S and Aulakh, R S and Kaur, P<br>and Sharma, A and Pooni, P A|2013|Sim|
||Pesticide use modifies the association between genetic variants on|Koutros, Stella and Beane Freeman, Laura E and<br>Berndt, Sonja I and Andreotti, Gabriella and<br>Lubin, Jay H and Sandler, Dale P and Hoppin, Jane<br>A and Yu, Kai and Li, Qizhai and Burdette, Laura A<br>and Yuenger, Jeffrey and Yeager, Meredith and|||
|1a|chromosome 8q24 and prostate cancer.|Alavanja, Michael C R|2010|Sim|
||Pesticides and autism spectrum disorders: new findings from the CHARGE||||
|1a|study.|Holzman, David C|2014|Sim|
|1a|Pesticides exposure as etiological factors of Parkinson's disease and other<br>neurodegenerative diseases--a mechanistic approach.|Baltazar, Maria Teresa and Dinis-Oliveira, Ricardo<br>Jorge and de Lourdes Bastos, Maria and<br>Tsatsakis, Aristidis M and Duarte, Jose Alberto<br>and Carvalho, Felix|2014|Não|  
53  
|1a|Pet Groomer's Lung: A novel occupation related hypersensitivity<br>pneumonitis related to pyrethrin exposure in a pet groomer.|Pu, Chan Yeu and Rasheed, Mohamed Rizwan<br>Haroon Al and Sekosan, Marin and Sharma, Vibhu|2017|Sim|
|---|---|---|---|---|
||Physiological responses of three marine microalgae exposed to|Wang, Zhao-Hui and Nie, Xiang-Ping and Yue,|||
|1a|cypermethrin.|Wen-Jie and Li, Xin|2012|Não|
||Phytotoxicity of atrazine, S-metolachlor, and permethrin to Typha latifolia||||
|1a|(Linneaus) germination and seedling growth.|Moore, M T and Locke, M A|2012|Não|
||A pilot study of workplace dermal exposures to cypermethrin at a chemical|Buckley, Timothy J and Geer, Laura A and Connor,<br>Thomas H and Robertson, Shirley and Sammons,<br>Deborah and Smith, Jerome and Snawder, John|||
|1a|manufacturing plant.|and Boeniger, Mark|2011|Sim|
||Poisoning suicide with ingestion of the pyrethroids alpha-cypermethrin and|Boumba, Vassiliki A and Rallis, Georgios N and|||
|1a|deltamethrin and the antidepressant mirtazapine: A case report.|Vougiouklakis, Theodore|2017|Sim|
||Positional cloning of rp2 QTL associates the P450 genes CYP6Z1, CYP6Z3<br>and CYP6M7 with pyrethroid resistance in the malaria vector Anopheles|Irving, H and Riveron, J M and Ibrahim, S S and|||
|1a|funestus.|Lobo, N F and Wondji, C S|2012|Não|
|||Tan, Yanjun and Wang, Hengjuan and Song, Yan|||
|1a|[Potential endocrine disrupting effects of bifenthrin in rats].|and Yang, Hui and Jia, Xudong and Li, Ning|2012|Não|
|1a|PPAR-gamma activation attenuates deltamethrin-induced apoptosis by<br>regulating cytosolic PINK1 and inhibiting mitochondrial dysfunction.|Ko, Juyeon and Park, Jae Hyeon and Park, Yun<br>Sun and Koh, Hyun Chul|2016|Não|
||Predicted transport of pyrethroid insecticides from an urban landscape to|Jorgenson, Brant and Fleishman, Erica and<br>Macneale, Kate H and Schlenk, Daniel and Scholz,<br>Nathaniel L and Spromberg, Julann A and<br>Werner, Inge and Weston, Donald P and Xiao,<br>Qingfu and Young, Thomas M and Zhang,|||
|1a|surface water.|Minghua|2013|Não|
||Prediction of developmental chemical toxicity based on gene networks of|Yamane, Junko and Aburatani, Sachiyo and|||
|1a|human embryonic stem cells.|Imanishi, Satoshi and Akanuma, Hiromi and|2016|Não|  
54  
|||Nagano, Reiko and Kato, Tsuyoshi and Sone,<br>Hideko and Ohsako, Seiichiroh and Fujibuchi,<br>Wataru|||
|---|---|---|---|---|
||Prenatal exposure to pesticide ingredient piperonyl butoxide and childhood|Liu, Bian and Jung, Kyung Hwa and Horton,<br>Megan K and Camann, David E and Liu, Xinhua<br>and Reardon, Ann Marie and Perzanowski,<br>Matthew S and Zhang, Hanjie and Perera,<br>Frederica P and Whyatt, Robin M and Miller,|||
|1a|cough  in an urban cohort.|Rachel L|2012|Sim|
||Prenatal exposure to pyrethroid insecticides and birth outcomes in Rural|Ding, Guodong and Cui, Chang and Chen, Limei<br>and Gao, Yu and Zhou, Yijun and Shi, Rong and|||
|1a|Northern China.|Tian, Ying|2015|Sim|
|1a|Prenatal exposure to pyrethroid pesticides and childhood behavior and<br>executive functioning.|Furlong, Melissa A and Barr, Dana Boyd and<br>Wolff, Mary S and Engel, Stephanie M|2017|Não|
||Probabilistic acute dietary exposure assessment of the Chinese population|Sun, J-F and Liu, P and Li, C-Y and Li, J-X and|||
|1a|to cypermethrin residues.|Wang, C-N and Min, J and Hu, D and Wu, Y-N|2011|Não|
||Protective effects of oat oil on deltamethrin-induced reprotoxicity in male|Ben Halima, Nihed and Ben Slima, Ahlem and<br>Moalla, Imen and Fetoui, Hamadi and Pichon,<br>Chantal and Gdoura, Radhouane and Abdelkafi,|||
|1a|mice.|Slim|2014|Não|
||Pyrethroid Insecticide Cypermethrin Accelerates Pubertal Onset in Male|Ye, Xiaoqing and Li, Feixue and Zhang, Jianyun<br>and Ma, Huihui and Ji, Dapeng and Huang, Xin<br>and Curry, Thomas E Jr and Liu, Weiping and Liu,|||
|1a|Mice via Disrupting Hypothalamic-Pituitary-Gonadal Axis.|Jing|2017|Não|
|1a|Pyrethroid insecticide exposure and reproductive hormone levels in healthy<br>Japanese male subjects.|Yoshinaga, J and Imai, K and Shiraishi, H and<br>Nozawa, S and Yoshiike, M and Mieno, M N and<br>Andersson, A-M and Iwamoto, T|2014|Não|  
55  
|1a|Pyrethroid insecticide neurotoxicity.|van Thriel, C and Hengstler, J G and Marchan, R|2012|Não|
|---|---|---|---|---|
||Pyrethroid pesticide exposure and parental report of learning disability and<br>attention deficit/hyperactivity disorder in U.S. children: NHANES 1999-|Quiros-Alcala, Lesliam and Mehta, Suril and|||
|1a|2002.|Eskenazi, Brenda|2014|Não|
|1a|Pyrethroid pesticide exposure and risk of childhood acute lymphocytic<br>leukemia in Shanghai.|Ding, Guodong and Shi, Rong and Gao, Yu and<br>Zhang, Yan and Kamijima, Michihiro and Sakai,<br>Kiyoshi and Wang, Guoquan and Feng, Chao and<br>Tian, Ying|2012|Não|
|||Cha, Yong Sung and Kim, Hyun and Cho, Nam<br>Hyub and Jung, Woo Jin and Kim, Yong Won and<br>Kim, Tae Hoon and Kim, Oh Hyun and Cha,<br>Kyoung Chul and Lee, Kang Hyun and Hwang,|||
|1a|Pyrethroid poisoning: features and predictors of atypical presentations.|Sung Oh and Nelson, Lewis S|2014|Sim|
||Pyrethroid resistance in Anopheles gambiae, in Bomi County, Liberia,|Temu, Emmanuel A and Maxwell, Caroline and<br>Munyekenye, Godwil and Howard, Annabel F V<br>and Munga, Stephen and Avicor, Silas W and<br>Poupardin, Rodolphe and Jones, Joel J and Allan,<br>Richard and Kleinschmidt, Immo and Ranson,|||
|1a|compromises  malaria vector control.|Hilary|2012|Não|
|||Scott, Jeffrey G and Yoshimizu, Melissa|||
|1a|Pyrethroid resistance in Culex pipiens mosquitoes.|Hardstone and Kasai, Shinji|2015|Não|
|||Saillenfait, Anne-Marie and Ndiaye, Dieynaba and|||
|1a|Pyrethroids: exposure and health effects--an update.|Sabate, Jean-Philippe|2015|Sim|
|1a|Pyrethroids: mammalian metabolism and toxicity.|Kaneko, Hideo|2011|Não|
|1a|Raman spectroscopy of human neuronal and epidermal cells exposed to an<br>insecticide mixture of chlorpyrifos and deltamethrin.|Lasalvia, Maria and Perna, Giuseppe and Capozzi,<br>Vito|2014|Não|  
56  
||A randomised, assessor blind, parallel group comparative efficacy trial of<br>three  products for the treatment of head lice in children--melaleuca oil and<br>lavender oil, pyrethrins and piperonyl butoxide, and a "suffocation"||||
|---|---|---|---|---|
|1a|product.|Barker, Stephen C and Altman, Phillip M|2010|Não|
||Recurrent tonic-clonic seizures and coma due to ingestion of Type I|Giampreti, A and Lampati, L and Chidini, G and<br>Rocchi, L and Rolandi, L and Lonati, D and<br>Petrolini, V M and Vecchio, S and Locatelli, C A|||
|1a|pyrethroids in a 19-month-old patient.|and Manzo, L|2013|Sim|
||Relationship between Urinary Pesticide Residue Levels and Neurotoxic||||
|1a|Symptoms among Women on Farms in the Western Cape, South Africa.|Motsoeneng, Portia M and Dalvie, Mohamed A|2015|Não|
||Relationships of Pyrethroid Exposure with Gonadotropin Levels and|Ye, Xiaoqing and Pan, Wuye and Zhao, Shilin and<br>Zhao, Yuehao and Zhu, Yimin and Liu, Jing and|||
|1a|Pubertal Development in Chinese Boys.|Liu, Weiping|2017|Não|
|1a|[Research advances in the neurotoxicology of pyrethroid pesticides].|Cao, Pei and Xu, Hai-bin|2012|Não|
|||Du, Pengqiang and Liu, Xingang and Gu, Xiaojun<br>and Dong, Fengshou and Xu, Jun and Kong,|||
|1a|Residue behaviour of six pesticides in button crimini during home canning.|Zhiqiang and Li, Yuanbo and Zheng, Yongquan|2014|Não|
||Response of soil microbial activity and biodiversity in soils polluted with|Tejada, Manuel and Garcia, Carlos and|||
|1a|different concentrations of cypermethrin insecticide.|Hernandez, Teresa and Gomez, Isidoro|2015|Não|
||Risk assessment of the exposure of insecticide operators to fenvalerate|Moon, Joon-Kwan and Park, Sewon and Kim,|||
|1a|during treatment in apple orchards.|Eunhye and Lee, Hyeri and Kim, Jeong-Han|2013|Sim|
||[The role of BDNF pathway in lambda-cyhalothrin disrupting the promotion<br>of 17beta-Estradiol on Post-synaptic Density 95 protein expression in HT22|Li, N and Wang, Q N and Wu, D J and Yang, C W|||
|1a|cell].|and Luo, B B|2016|Não|
||Safety prediction of topically exposed biocides using permeability|Sugino, Masahiro and Todo, Hiroaki and Suzuki,|||
|1a|coefficients and the desquamation rate at the stratum corneum.|Takamasa and Nakada, Keiichi and Tsuji, Kiyomi|2014|Não|  
57  
|||and Tokunaga, Hiroshi and Jinno, Hideto and<br>Sugibayashi, Kenji|||
|---|---|---|---|---|
|1a|Scabies.|Johnstone, Paul and Stong, Mark|2015|Não|
||Semen quality and the level of reproductive hormones after environmental|Radwan, Michal and Jurewicz, Joanna and<br>Wielgomas, Bartosz and Sobala, Wojciech and<br>Piskunowicz, Marta and Radwan, Pawel and|||
|1a|exposure to pyrethroids.|Hanke, Wojciech|2014|Não|
||Single and cartel effect of pesticides on biochemical and haematological||||
|1a|status of Clarias batrachus: A long-term monitoring.|Narra, Madhusudan Reddy|2016|Não|
||Status epilepticus following inhalational exposure to bifenthrin, a Type II||||
|1a|pyrethroid.|Rangaraju, Srikant and Webb, Adam|2013|Sim|
||[Stevens-Johnson syndrome and toxic epidermal necrolysis (SJSTEN) related||||
|1a|to insecticide: Second case in the literature and potential implications].|Moullan, M and Ahossi, V and Zwetyenga, N|2016|Sim|
||Studying permethrin exposure in flight attendants using a physiologically|Wei, Binnian and Isukapalli, Sastry S and Weisel,|||
|1a|based pharmacokinetic model.|Clifford P|2013|Sim|
|1a|Successful validation of genomic biomarkers for human immunotoxicity in<br>Jurkat T  cells in vitro.|Schmeits, Peter C J and Shao, Jia and van der<br>Krieken, Danique A and Volger, Oscar L and van<br>Loveren, Henk and Peijnenburg, Ad A C M and<br>Hendriksen, Peter J M|2015|Não|
||Synergy between prochloraz and esfenvalerate in Daphnia magna from|Bjergager, Maj-Britt A and Hanson, Mark L and|||
|1a|acute and subchronic exposures in the laboratory and microcosms.|Solomon, Keith R and Cedergreen, Nina|2012|Não|
||Systematic review of biomonitoring studies to determine the association<br>between exposure to organophosphorus and pyrethroid insecticides and|Koureas, Michalis and Tsakalof, Andreas and<br>Tsatsakis, Aristidis and Hadjichristodoulou,|||
|1a|human health outcomes.|Christos|2012|Sim|
||Takotsubo cardiomyopathy related to carbamate and pyrethroid|Lin, Chi-Cheng and Lai, Shih-Yuan and Hu, Sung-|||
|1a|intoxication.|Yuan and Tsan, Yu-Tse and Hu, Wei-Hsiung|2010|Sim|  
58  
|||Paasch, Uwe and Grunewald, Sonja and Handrick,|||
|---|---|---|---|---|
|1a|[Teases at the scalp: ectoparasites].|Werner and Nenoff, P|2012|Não|
||Time courses and variability of pyrethroid biomarkers of exposure in a|Ratelle, Mylene and Cote, Jonathan and|||
|1a|group of agricultural workers in Quebec, Canada.|Bouchard, Michele|2016|Sim|
||Tocopheryl acetate 20% spray for elimination of head louse infestation: a|Burgess, Ian F and Burgess, Nazma A and|||
|1a|randomised controlled trial comparing with 1% permethrin creme rinse.|Brunton, Elizabeth R|2013|Não|
|||Hidalgo-Castellon, Antonio J and Ramos-|||
|1a|[Toxic hepatitis after intake of raspberries].|Clemente, Juan Ignacio and Perez, Miguel Angel|2013|Não|
||Toxicokinetics of permethrin biomarkers of exposure in orally exposed|Ratelle, Mylene and Cote, Jonathan and|||
|1a|volunteers.|Bouchard, Michele|2015|Sim|
||Toxicological effects of cypermethrin to marine phytoplankton in a co-|Wang, Zhao-Hui and Nie, Xiang-Ping and Yue,|||
|1a|culture system under laboratory conditions.|Wen-Jie|2011|Não|
||Trait Characteristics Determine Pyrethroid Sensitivity in Nonstandard Test|Wiberg-Larsen, Peter and Graeber, Daniel and<br>Kristensen, Esben A and Baattrup-Pedersen,|||
|1a|Species of Freshwater Macroinvertebrates: A Reality Check.|Annette and Friberg, Nikolai and Rasmussen, Jes J|2016|Não|
||Upper respiratory tract nociceptor stimulation and stress response<br>following acute and repeated Cyfluthrin inhalation in normal and pregnant<br>rats: Physiological rat-specific adaptions can easily be misunderstood as||||
|1a|adversities.|Pauluhn, Juergen|2018|Não|
|||Rossbach, Bernd and Appel, Klaus E and Mross,|||
|1a|Uptake of permethrin from impregnated clothing.|Klaus G and Letzel, Stephan|2010|Sim|
||Urban and agricultural sources of pyrethroid insecticides to the||||
|1a|Sacramento-San Joaquin Delta of California.|Weston, Donald P and Lydy, Michael J|2010|Não|
||Urinary concentrations of pyrethroid metabolites and its association with|Ye, Ming and Beach, Jeremy and Martin,|||
|1a|lung function in a Canadian general population.|Jonathan W and Senthilselvan, Ambikaipakan|2016|Sim|  
59  
||The use of self-reported symptoms as a proxy for acute organophosphate||||
|---|---|---|---|---|
|1a|poisoning  after exposure to chlorpyrifos 50% plus cypermethrin 5% among<br>Nepali farmers: a randomized, double-blind, placebo-controlled, crossover<br>study.|Kofod, Dea Haagensen and Jors, Erik and Varma,<br>Anshu and Bhatta, Shankuk and Thomsen, Jane<br>Frolund|2016|Sim|
||Use of the RISK21 roadmap and matrix: human health risk assessment of|Doe, John E and Lander, Deborah R and Doerrer,<br>Nancy G and Heard, Nina and Hines, Ronald N<br>and Lowit, Anna B and Pastoor, Timothy and<br>Phillips, Richard D and Sargent, Dana and<br>Sherman, James H and Young Tanir, Jennifer and|||
|1a|the use of  a pyrethroid in bed netting.|Embry, Michelle R|2016|Não|
|1a|Utilization of the human louse genome to study insecticide resistance and<br>innate  immune response.|Clark, J Marshall and Yoon, Kyong Sup and Kim, Ju<br>Hyeon and Lee, Si Hyeock and Pittendrigh, Barry<br>R|2015|Não|
|1a|Who is the real killer? Chlorfenapyr or detergent micelle-chlorfenapyr<br>complex?|Periasamy, Srinivasan and Deng, Jou-Fang and<br>Liu, Ming-Yie|2017|Não|
||Interceptor(R) long-lasting insecticidal net: phase III evaluation over three<br>years of household use and calibration with Phase II experimental hut|Tungu, Patrick and Kirby, Matthew and Malima,<br>Robert and Kisinza, William and Magesa, Stephen<br>and Maxwell, Caroline and Batengana, Benard|||
|1a|outcomes.|and Pigeon, Olivier and Rowland, Mark|2016|Não|
||Effect of permethrin-impregnated underwear on body lice in sheltered|Benkouiten, Samir and Drali, Rezak and Badiaga,<br>Sekene and Veracx, Aurelie and Giorgi, Roch and|||
|1a|homeless persons: a randomized controlled trial.|Raoult, Didier and Brouqui, Philippe|2014|Não|  
60  
**Quadro V.3.2.** Artigos resultantes da busca sistemática no site **Lilacs** , para as perguntas PICO sobre manifestações clinicas para intoxicações por produtos contendo piretroides

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|**Busca**|<br>**Titulo**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|---|
|1b|Perfil do uso populacional de inseticidas domÃ©sticos no combate a<br>mosquitos TT  - Profile of the population use of household insecticides<br>against mosquitoes|Oliveira, Luzilene Barbosa de and Nunes, Rafaela<br>Maria Pessoa and Santana, Claudiana Mangabeira<br>and Costa, AntÃ´nia Rosa da and Nunes, Narcia<br>Mariana Fonseca and Calou, Iana Bantim Felicio<br>and Peron, Ana Paula and Marques, Marcia Maria<br>Mendes and Ferreira, Paulo Michel Pinheiro|2015||
|1b|IntoxicaÃ§Ã£o por agrotÃ³xicos: clÃnica, diagnÃ³stico e manejo dos<br>pacientes expostos TT  - Pesticide poisoning: Clinical, diagnosis and<br>management of patients exposed|Pardal, Pedro de Oliveira|2014||
|1b|IntoxicaÃ§Ãµes por agrotÃ³xicos registrados em um centro de controle de<br>intoxicaÃ§Ãµes TT  - Intoxications by pesticides recorded at a poisoning<br>control center|Marangoni, SÃ´nia Regina and Seleghim, Maycon<br>RogÃ©rio and Teixeira, JÃ©ssica Adrielle and<br>Buriola, Aline Aparecida and Ballani, TanimÃ¡ria da<br>Silva Lira and Oliveira, Magda LÃºcia FÃ©lix de|2011||
|1b|IntoxicaÃ§Ãµes ExÃ³genas: Perfil dos Casos que Necessitaram de<br>AssistÃªncia Intensiva em 2007 TT  - Exogenous Intoxications: Profile of<br>Cases that Required Intensive Care in 2007|Silva, Cleyton CÃ©zar Souto and Souza, Katyshely<br>SÃ¡ de and Marques, Maria De FÃ¡tima Leandro|2011||
|1b|Compatibilidad de 13 aislamientos de Beauveria bassiana patÃ³genos para<br>Rhodnius prolixus (Triatominae) con insecticidas quÃmicos TT  -|Cazorla, Dalmiro and Morales Moreno, Pedro|2010||  
61  
||Compatibility of 13 Beauveria bassiana isolates pathogenic to Rhodnius<br>prolixus (Triatominae) with insecticides|||
|---|---|---|---|
|1b|Manual de diagnÃ³stico tratamiento y prevenciÃ³n de intoxicaciones<br>agudas por plaguicidas TT  - Manual on diagnostic treatment and<br>prevention of acute pesticide poisoning|Bolivia, FundaciÃ³n Plaguicidas|2008|
|1b|Respuesta conductual de Aedes aegypti (Linnaeus, 1762) frente a<br>adulticidas piretroides de uso frecuente en salÃºd pÃºblica TT  -<br>Behavioural response of Aedes aegypti (Linnaeus, 1762) exposed to<br>pyretrhoids insecticides of frequently use in public health|Ayala-Sulca, Yuri O and Ibarra-Juarez, Luis and<br>Grieco, Jhon P and Achee, Nicole and Mercado-<br>Hernandez, Roberto and FernÃ¡ndez-Salas,<br>Ildefonso|2008|
|1b|SÃndrome de fatiga crÃ³nica e hipersensibilidad quÃmica mÃºltiple tras<br>exposiciÃ³n a insecticidas TT  - Chronic fatigue syndrome and multiple<br>chemical hypersensitivity after insecticide exposition|FernÃ¡ndez-SolÃ , Joaquim and LluÃs Padierna,<br>Meritxell and NoguÃ© Xarau, Santiago and Pere<br>MunnÃ© Mas, Pere|2005|
|1b|IntoxicaciÃ³n inhalatoria con cipermetrina TT  - Inhalatory intoxication with<br>cipermetrine|Bonne HernÃ¡ndez, RaÃºl and PÃ©rez Infante,<br>Lizett and Rojas VÃ¡zquez, Evelyn and MarÃn<br>SÃ¡nchez, Dayana|2003|
|1b|IntoxicaciÃ³n por piretrinas: una causa singular de convulsiones en el<br>lactante TT  - Intoxication from pyrethrins: a singular cause of seizures in<br>the infant|San RomÃ¡n, M and Herranz, J L and Arteaga, R|2003|
|1b|SaÃºde auditiva de trabalhadores expostos a ruÃdo e inseticidas TT  -<br>Hearing health of workers exposed to noise and insecticides|Teixeira, Cleide Fernandes and Augusto, Lia<br>Giraldo da Silva and Morata, Thais C|2003|
|1b|SituaciÃ³n actual en espaÃ±a de los aerosoles insecticidas registrados en<br>sanidad ambiental para uso domÃ©stico TT  - Current situation in Spain of<br>aerosol insect sprays registered for household use by the environmental<br>health authorities|Moreno MarÃ, Josefa and MeliÃ¡ LlÃ¡cer, Amparo<br>and Oltra MoscardÃ³, MarÃa Teresa and<br>JimÃ©nez PeydrÃ³, Ricardo|2003|
|1b|DiscussÃ¤o sobre o risco das interaÃ§Ã¶es de agrotÃ³xicos na dieta<br>brasileira TT  - Discussion about the risk of pesticides interactions in the<br>Brazilian diet|LourenÃ§o, Rita de CÃ¡ssia|2003|  
62  
|1b|IntoxicaciÃ³n por piretrinas y neurotoxicidad TT  - Intoxication and<br>neurotoxicity for pyrethrins|BÃ¶rgel, Laura and Briones, Gloria and Rousseau,<br>Ivonne and Araya, Alejandra|2002|
|---|---|---|---|
|1b|A questÃ¤o dos praguicidas na agricultura e a situaÃ§Ã¤o no Estado de<br>Pernambuco TT  - The question of Pesticide in agriculture and the situation<br>in the State of Pernambuco|AraÃºjo, AdÃ©lia C P and Augusto, Lia G S and<br>Telles, Danuza L|2000|
|1b|Efectividad de lociones capilares sobre poblaciones de Pediculus capitis<br>resistentes a insecticidas TT  - Effectiveness of capilar lotions against<br>insecticide resistant Pediculus capitis populations|Mougabure Cueto, GastÃ³n and Vassena, Claudia<br>and Gonzalea Audino, Paola and Picollo, MarÃa<br>InÃ©s and Zerba, Eduardo NicolÃ¡s|2000|
|1b|ActualizaciÃ³n en el tratamiento de la pediculosis, sarna y leishmaniasis TT<br>- Treatment review in pediculosis scabies and leishmaniasis|SÃ¡nchez Carpintero, I and Quintanilla, E and<br>Castellanos, C and Resano, A and Solano, T|2000|
|1b|Baixa aderÃªncia e alto custo como fatores de insucesso do uso de<br>mosquiteiros impregnados com inseticida no controle da malÃ¡ria na<br>AmazÃ´nia Brasileira TT  - Low adherence and high cost as failure factors of<br>impregnated bed nets with inseticide for malaria control in the Brazilian<br>Amazon|Santos, JoÃ¤o Barberino|1999|
|1b|Estudo sobre o uso de mosquiteiros impregnados com deltametrina em<br>uma Ã¡rea endÃªmica de malÃ¡ria na AmazÃ´nia brasileira TT  - Use of<br>deltametrine impregnated mosquito nets in an endemic malaria region in<br>the brazilian Amazon|Santos, JoÃ¤o Barberino|1997|
|1b|DiagnÃ³stico, tratamiento y prevenciÃ³n de intoxicaciones agudas causadas<br>por plaguicidas: curso a distancia dirigido a mÃ©dicos y enfermeras TT  -<br>Diagnosis, treatment and prevention of acute intoxications caused by<br>plaguicides|Salud, PerÃº. Ministerio de|1996|
|1b|Deltamethrin / published under the joint sponsorship of the United<br>Nations Environment Programme, the International Labour Organisation,<br>and the World Health Organization|Safety, International Programme on Chemical and<br>Organization, World Health|1990|  
63  
|1b|Tetramethrin / published under the joint sponsorship of the United Nations<br>Environment Programme, the International Labour Organisation, and the<br>World Health Organization|Organization, World Health and Safety,<br>International Programme on Chemical|1990|
|---|---|---|---|
|1b|Permethrin / published under the joint sponsorship of the United Nations<br>Environment Programme, the International Labour Organisation, and the<br>World Health Organization|Organization, World Health and Safety,<br>International Programme on Chemical|1990|
|1b|IncidÃªncia de intoxicaÃ§Ã¶es por praguicidas no Estado da Bahia, Brasil,<br>1983/1987 TT  - Occurrence of intoxication by pesticides in State of Bahia,<br>Brazil, 1983-1987|Carvalho, Wilson Andrade de and Rodrigues, Daisy<br>Schwab and Santos, Raimundo JosÃ© RÃªgo and<br>Ramos, Carlos Alberto and Costa, F Maviael<br>Ferreira|1988|
|1b|Suscetibilidade de Sitophilus oryzae (L. 1763) (Coleoptera:Curculionidae)ao<br>PiretrÃ³ide deltametrina TT  - Susceptibility of Sitophilus oryzae (L.1763)<br>(Coleoptera:Curculionidae) to Pyrethroid deltamethrin|Pacheco, IvÃ¢nia AthiÃª and Sartori, Maria Regina<br>and Yokomizo, Yuriko|1988|
|1b|Medicamentos ectoparasiticidas: risco e benefÃcio TT  - Ectoparasiticides<br>drugs: risk and benefit|Rahde, Alberto Furtado and Salvi, Rosane M|1987|
|1b|AvaliaÃ§Ã¤o clÃnica do uso da decametrina no tratamento da pediculose<br>do couro cabeludo TT  - Clinical evaluation of the use of decamethrin in the<br>treatment of pediculosis of the scalp|Sasaki, Newton Mamoru and Cortez, JosÃ©<br>Rubens Barbosa|1985|
|1b|Ambiente y salud: estudio de un agente xenobiÃ³tico sobre la comunidad<br>humana TT  - Environment and health: study of a xenobiotic agent on the<br>human community|Astolfi, Emilio and Maccagno, Armando and<br>Rabinovich, Alfredo and Higa de Landoni, Julia|1977|  
64

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|Busca|<br>Titulo|key|year|Seleccionado|
|---|---|---|---|---|
|1c|Control methods for Aedes albopictus and Aedes aegypti|Praveen2017|2017|Não|
|1c|Vector and reservoir control for preventing leishmaniasis|Urba2015|2015|Não|
|1c|Ivermectin and permethrin for treating scabies|Stefanie2018|2018|Sim|
|1c|Indoor residual spraying for preventing malaria|Bianca2010|2010|Não|
||Piperonyl butoxide (PBO) combined with pyrethroids in long-lasting||||
|1c|insecticidal nets (LLINs) to prevent malaria in Africa|Katherine2017|2017|Não|
|1c|Mosquito repellents for malaria prevention|MF2018|2018|Não|
||The efficacy and safety of alphacypermethrin as a pour-on treatment for||||
|1c|water buffalo (Bubalus bubalis) infested with Haematopinus tu|Veneziano2013|2013|Não|
|1c|Efficacy and safety of a mineral oil-based head lice shampoo: a randomized|Wolf2016|2016|Não|
||5-Aminolevulinic acid improves DNA damage and DNA Methylation||||
|1c|changes in deltamethrin-exposed Phaseolus vulgaris seedlings|Found2017|2017|Não|
||Efficacy and Safety of a Mineral Oil-Based Head Lice Shampoo: a||||
|1c|Randomized|Wolf2016a|2016|Não|
|1c|The AvecNet Trial to assess whether addition of pyriproxyfen|AB2015|2015|Não|
|1c|The AvecNet Trial to assess whether addition of pyriproxyfen|AB2015a|2015|Não|
||Mass Drug Administration for Scabies Control in a Population with Endemic||||
|1c|Disease|Romani2015|2015|Não|
|1c|Efficacy and safety of permethrin 5|Raoufinejad2016|2016|Não|
|1c|Bio-equivalence Study Comparing Permethrin Cream|NCT029785082016|2016|Não|  
65  
|1c|Long-lasting permethrin impregnated uniforms: a randomized-controlled<br>trial for tick bite prevention|MF2014|2014|Não|
|---|---|---|---|---|
|1c|Efficacy and Safety of Licefreee Spray Against Nix 1|NCT015145132012|2012|Não|
|1c|A Dose Ranging Vehicle Controlled Study to Determine the Safety and<br>Efficacy of Permethrin Foam|NCT020947162014|2014|Não|
|1c|Oral Ivermectin Versus Topical Permethrin to Treat Scabies in Children|NCT024077822015|2015|Não|
|1c|The efficacy of permethrin 5|MR2013|2013|Não|
||Efficacy Study Between Two Different Dosages of an Antiparasitic in||||
|1c|Patients With Crusted Scabies|NCT028412152016|2016|Não|
|1c|Fiji Integrated Therapy (FIT) - Triple Therapy for Lymphatic Filariasis|NCT031779932017|2017|Não|
||Safety of insecticide-treated mosquito nets for infants and their mothers:||||
|1c|randomized controlled community trial in Burkina Faso|Lu2015|2015|Sim|
|1c|Efficacy|TA2016|2016|Não|
||To assess whether addition of pyriproxyfen to long-lasting insecticidal||||
|1c|mosquito nets increases their durability compared to standard|Sagnon2015|2015|Não|
|1c|Treatment of Scabies: comparison of Lindane 1|Rezaee2015|2015|Não|
||Effectiveness Study of New Generation Bednets in the Context of||||
|1c|Conventional Insecticide Resistance in the Democratic Republic of the|NCT032896632017|2017|Não|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
**Quadro V.3.4.** Artigos resultantes da busca sistemática no site **Pubmed** , para as perguntas PICO sobre diagnóstico para intoxicações por produtos contendo piretroides  
**Busca - pergunta PICO Diagnóstico (180 resultados)**  
66  
|Busca|<br>Título|Autor|Ano|Estudo<br>considerado|
|---|---|---|---|---|
|2a|Scabies.|Johnstone P, Stong M.|2015|Não|
|2a|Permethrin and ivermectin for scabies.|Currie BJ, McCarthy JS.|2010|Não|
||Effects of mosquito control pesticides on competent queen conch||||
|2a|(Strombus gigas) larvae.|Delgado GA, Glazer RA, Wetzel D.|2013|Não|
|2a|Variations in lethal and sublethal effects of cypermethrin among aquatic<br>stages and species of anuran amphibians.|Biga LM, Blaustein AR.|2013|Não|
|2a|Analysis, occurrence, and toxic potential of pyrethroids, and fipronil in<br>sediments from an urban estuary.|Lao W, Tsukada D, Greenstein DJ, Bay SM, Maruya<br>KA.|2010|Não|
|2a|Joint effects of pesticides and ultraviolet-B radiation on amphibian larvae.|Yu S, Wages M, Willming M, Cobb GP, Maul JD.|2015|Não|
|2a|Comet assay in gill cells of Prochilodus lineatus exposed in vivo to<br>cypermethrin.|Poletta GL, Gigena F, Loteste A, Parma MJ,<br>Kleinsorge EC, Simoniello MF.|2013|Não|
|2a|Toxicity of cypermethrin on the neotropical lacewing Chrysoperla externa<br>(Neuroptera: Chrysopidae).|Haramboure M, Francesena N, Reboredo GR,<br>Smagghe G, Alzogaray RA, Schneider MI.|2013|Sim|
||Sensitivity assessment of freshwater macroinvertebrates to pesticides using||||
|2a|biological traits.|Ippolito A, Todeschini R, Vighi M.|2012|Não|
||Prenatal exposure to pyrethroid insecticides and birth outcomes in Rural||||
|2a|Northern China.|Ding G, Cui C, Chen L, Gao Y, Zhou Y, Shi R, Tian Y.|2015|Não|
||Methomyl-alphamethrin poisoning presented with cholinergic crisis,||||
|2a|cortical blindness, and delayed peripheral neuropathy.|Hu YH, Yang CC, Deng JF, Wu ML.|2010|Não|
|2a|Are there fitness costs of adaptive pyrethroid resistance in the amphipod,<br>Hyalella azteca?|Heim JR, Weston DP, Major K, Poynton H, Huff<br>Hartz KE, Lydy MJ.|2018|Não|  
67  
|2a|First report of a fish kill episode caused by pyrethroids in Italian freshwater.|Bille L, Binato G, Gabrieli C, Manfrin A, Pascoli F,<br>Pretto T, Toffan A, Dalla Pozza M, Angeletti R,<br>Arcangeli G.|2017|Não|
|---|---|---|---|---|
|2a|Differential response between histological and biochemical biomarkers in<br>the apple snail Pomacea canaliculata (Gasteropoda: Amullariidae) exposed<br>to cypermethrin.|Arrighetti F, Ambrosio E, Astiz M, CapÃtulo AR,<br>LavarÃas S.|2018|Não|
||Permethrin drastically affects the developmental cycle of the non-target||||
|2a|slime mould Dictyostelium discoideum.|Amaroli A, Gallus L, Ferrando S.|2018|Não|
||Effects of deltamethrin, dimethoate, and chlorpyrifos on survival and<br>reproduction of the collembolan Folsomia candida and the predatory mite|Jaabiri Kamoun I, Jegede OO, Owojori OJ, Bouzid J,|||
|2a|Hypoaspis aculeifer in two African and two European soils.|Gargouri R, RÃ¶mbke J.|2018|Não|
||Testing the time-scale dependence of delayed interactions: A heat wave<br>during the egg stage shapes how a pesticide interacts with a successive||||
|2a|heat wave in the larval stage.|Janssens L, TÃ¼zÃ¼n N, Stoks R.|2017|Não|
|2a|Immune disorders induced by exposure to pyrethroid insecticides.|Skolarczyk J, Pekar J, Nieradko-Iwanicka B.|2017|Não|
|2a|A capillary micellar electrokinetic chromatography method for the<br>stereoselective quantitation of bioallethrin in biotic and abiotic samples.|GarcÃa MÃ•, MenÃ©ndez-LÃ³pez N, Boltes K,<br>Castro-Puyana M, Marina ML.|2017|Não|
||Histopathological effects of cypermethrin and Bacillus thuringiensis var.<br>israelensis on midgut of Chironomus calligraphus larvae (Diptera:||||
|2a|Chironomidae).|LavarÃas S, Arrighetti F, Siri A.|2017|Não|
||Bifenthrin Causes Toxicity in Urban Stormwater Wetlands: Field and|Jeppe KJ, Kellar CR, Marshall S, Colombo V, Sinclair|||
|2a|Laboratory Assessment Using Austrochiltonia (Amphipoda).|GM, Pettigrove V.|2017|Não|
|2a|An Evaluation of the Human Relevance of the Lung Tumors Observed in<br>Female Mice Treated With Permethrin Based on Mode of Action.|Yamada T, Kondo M, Miyata K, Ogata K, Kushida<br>M, Sumida K, Kawamura S, Osimitz TG, Lake BG,<br>Cohen SM.|2017|Não|  
68  
||Can fractal methods applied to video tracking detect the effects of|Tenorio BM, da Silva Filho EA, Neiva GSM, da Silva<br>VA, Tenorio FDCAM, da Silva TJ, Silva ECSE,|||
|---|---|---|---|---|
|2a|deltamethrin pesticide or mercury on the locomotion behavior of shrimps?|Nogueira RA.|2017|Não|
||Effects of Î±-cypermethrin enantiomers on the growth, biochemical<br>parameters and bioaccumulation in Rana nigromaculata tadpoles of the||||
|2a|anuran amphibians.|Xu P, Huang L.|2017|Não|
||Molecular diagnostics for detecting pyrethroid and abamectin resistance||||
|2a|mutations in Tetranychus urticae.|Ilias A, Vassiliou VA, Vontas J, Tsagkarakou A.|2017|Não|
|2a|Toxicity of nine insecticides on four natural enemies of Spodoptera exigua.|Liu Y, Li X, Zhou C, Liu F, Mu W.|2016|Não|
|2a|A comparative assessment of cytotoxicity of commonly used agricultural<br>insecticides to human and insect cells.|Yun X, Huang Q, Rao W, Xiao C, Zhang T, Mao Z,<br>Wan Z.|2017|Não|
||Natural pyrethrins induces apoptosis in human hepatocyte cells via Bax-|Yang Y, Zong M, Xu W, Zhang Y, Wang B, Yang M,|||
|2a|and Bcl-2-mediated mitochondrial pathway.|Tao L.|2017|Não|
||Endemic shrimp Macrobrachium pantanalense as a test species to assess|Soares MP, Jesus F, Almeida AR, Zlabek V, Grabic|||
|2a|potential contamination by pesticides in Pantanal (Brazil).|R, Domingues I, Hayd L.|2017|Não|
||Persistent gross lipemia and suspected corneal lipidosis following||||
|2a|intravenous lipid therapy in a cat with permethrin toxicosis.|Seitz MA, Burkitt-Creedon JM.|2016|Não|
|||Chueh TC, Hsu LS, Kao CM, Hsu TW, Liao HY, Wang<br>|||
|2a|Transcriptome analysis of zebrafish embryos exposed to deltamethrin.|KY, Chen SC.|2017|Não|
||Elucidation of pyrethroid and DDT receptor sites in the voltage-gated||||
|2a|sodium channel.|Zhorov BS, Dong K.|2017|Não|
||Initial development of a multigene 'omics-based exposure biomarker for|Biales AD, Kostich MS, Batt AL, See MJ, Flick RW,|||
|2a|pyrethroid pesticides.|Gordon DA, Lazorchak JM, Bencic DC.|2016|Não|
||Home Use of a Pyrethroid-Containing Pesticide and Facial Paresthesia in a|Perkins A, Walters F, Sievert J, Rhodes B,|||
|2a|Toddler: A Case Report.|Morrissey B, Karr CJ.|2016|Não|
||Comparing the impacts of sediment-bound bifenthrin on aquatic|Boyle RL, Hoak MN, Pettigrove VJ, Hoffmann AA,|||
|2a|macroinvertebrates in laboratory bioassays and field microcosms.|Long SM.|2016|Não|  
69  
|2a|Toxicant mixtures in sediment alter gene expression in the cysteine<br>metabolism of Chironomus tepperi.|Jeppe KJ, Carew ME, Pettigrove V, Hoffmann AA.|2017|Não|
|---|---|---|---|---|
||Transient Complete Heart Block Secondary to Bed Bug Insecticide: A Case||||
|2a|of Pyrethroid Cardiac Toxicity.|Singh H, Luni FK, Marwaha B, Ali SS, Alo M.|2016|Não|
||Environmentally relevant pyrethroid mixtures: A study on the correlation of<br>blood and brain concentrations of a mixture of pyrethroid insecticides to|Hughes MF, Ross DG, Starr JM, Scollon EJ,|||
|2a|motor activity in the rat.|Wolansky MJ, Crofton KM, DeVito MJ.|2016|Não|
||Burrowing mayfly Ephemera orientalis (Ephemeroptera: Ephemeridae) as a||||
|2a|new test species for pesticide toxicity.|Mo HH, Kim Y, Lee YS, Bae YJ, Khim JS, Cho K.|2016|Não|
||[Stevens-Johnson syndrome and toxic epidermal necrolysis (SJSTEN) related||||
|2a|to insecticide: Second case in the literature and potential implications].|Moullan M, Ahossi V, Zwetyenga N.|2016|Não|
|2a|Evidence for the Induction of Key Components of the NOTCH Signaling<br>Pathway via Deltamethrin and Azamethiphos Treatment in the Sea Louse<br>Caligus rogercresseyi.|BoltaÃ±a S, ChÃ¡vez-Mardones J, Valenzuela-<br>MuÃ±oz V, Gallardo-EscÃ¡rate C.|2016|Não|
|||Pierce LM, Kurata WE, Matsumoto KW, Clark ME,|||
|2a|Long-term epigenetic alterations in a rat model of Gulf War Illness.|Farmer DM.|2016|Não|
||Trait Characteristics Determine Pyrethroid Sensitivity in Nonstandard Test|Wiberg-Larsen P, Graeber D, Kristensen EA,|||
|2a|Species of Freshwater Macroinvertebrates: A Reality Check.|Baattrup-Pedersen A, Friberg N, Rasmussen JJ.|2016|Não|
||Behavioral swimming effects and acetylcholinesterase activity changes in<br>Jenynsia multidentata exposed to chlorpyrifos and cypermethrin||||
|2a|individually and in mixtures.|Bonansea RI, Wunderlin DA, AmÃ© MV.|2016|Não|
|2a|Deltamethrin is toxic to the fish (crucian carp, Carassius carassius) heart.|Haverinen J, Vornanen M.|2016|Não|
||Estimating the DNA strand breakage using a fuzzy inference system and<br>agarose gel electrophoresis, a case study with toothed carp Aphanius|Poorbagher H, Moghaddam MN, Eagderi S,|||
|2a|sophiae exposed to cypermethrin.|Farahmand H.|2016|Não|
|2a|Isolation of broad-specificity domain antibody from phage library for<br>development of pyrethroid immunoassay.|Zhao Y, Liang Y, Liu Y, Zhang X, Hu X, Tu S, Wu A,<br>Zhang C, Zhong J, Zhao S, Liu X, Tu K.|2016|Sim|  
70  
||Population-specific toxicity of six insecticides to the trematode||||
|---|---|---|---|---|
|2a|Echinoparyphium sp.|Hua J, Buss N, Kim J, Orlofske SA, Hoverman JT.|2016|Não|
||Effects of environmental endocrine disruptors, including insecticides used|Patrick SM, Bornman MS, Joubert AM, Pitts N,|||
|2a|for malaria vector control on reproductive parameters of male rats.|Naidoo V, de Jager C.|2016|Não|
||Comparative toxicity and bioaccumulation of fenvalerate and esfenvalerate||||
|2a|to earthworm Eisenia fetida.|Ye X, Xiong K, Liu J.|2016|Não|
|2a|Over-expression of CYP6A2 is associated with spirotetramat resistance and<br>cross-resistance in the resistant strain of Aphis gossypii Glover.|Peng T, Pan Y, Yang C, Gao X, Xi J, Wu Y, Huang X,<br>Zhu E, Xin X, Zhan C, Shang Q.|2016|Não|
||Effects of the Î²1 auxiliary subunit on modification of Rat Na(v)1.6 sodium<br>channels expressed in HEK293 cells by the pyrethroid insecticides tefluthrin||||
|2a|and deltamethrin.|He B, Soderlund DM.|2016|Não|
||Evidence of Field-Evolved Resistance to Bifenthrin in Western Corn<br>Rootworm (Diabrotica virgifera virgifera LeConte) Populations in Western|Pereira AE, Wang H, Zukoff SN, Meinke LJ, French|||
|2a|Nebraska and Kansas.|BW, Siegfried BD.|2015|Não|
||A long-term assessment of pesticide mixture effects on aquatic||||
|2a|invertebrate communities.|Hasenbein S, Lawler SP, Geist J, Connon RE.|2016|Não|
||Could humic acid relieve the biochemical toxicities and DNA damage||||
|2a|caused by nickel and deltamethrin in earthworms (Eisenia foetida)?|Shen CC, Shen DS, Shentu JL, Wang MZ, Wan MY.|2015|Não|
||Comparative sensitivity among early life stages of the South American toad||||
|2a|to cypermethrin-based pesticide.|Svartz G, Aronzon C, PÃ©rez Coll C.|2016|Não|
||Redox status in liver of rats following subchronic exposure to the|Xu MY, Wang P, Sun YJ, Wang HP, Liang YJ, Zhu L,|||
|2a|combination of low dose dichlorvos and deltamethrin.|Wu YJ.|2015|Não|
||Is the chronic Tier-1 effect assessment approach for insecticides protective||||
|2a|for aquatic ecosystems?|Brock TC, Bhatta R, van Wijngaarden RP, Rico A.|2016|Não|
||Adaptation, not acclimation, is the likely mechanism for reduced sensitivity||||
|2a|of some wild Hyalella populations to pyrethroid insecticides.|Weston D, Poynton H, Lydy M, Wellborn G.|2015|Não|  
71  
|2a|Antioxidant activity and hepatoprotective potential of Cedrelopsis grevei<br>on cypermethrin induced oxidative stress and liver damage in male mice.|Mossa AT, Heikal TM, Belaiba M, Raoelison EG,<br>Ferhout H, Bouajila J.|2015|Não|
|---|---|---|---|---|
||Low doses of the common alpha-cypermethrin insecticide<br>affectÂ behavioural thermoregulation of the non-targeted beneficial||||
|2a|carabid beetle Platynus assimilis (Coleoptera: Carabidae).|Merivee E, Tooming E, Must A, Sibul I, Williams IH.|2015|Não|
|2a|Association of pyrethroid pesticide exposure with attention-<br>deficit/hyperactivity disorder in a nationally representative sample of U.S.<br>children.|Wagner-Schuman M, Richardson JR, Auinger P,<br>Braun JM, Lanphear BP, Epstein JN, Yolton K,<br>Froehlich TE.|2015|Não|
||Amphibian (Euphlyctis cyanophlyctis) in vitro ovarian culture system to<br>assess impact of aquatic agrochemical contaminants on female||||
|2a|reproduction.|Katti PA, Ghodgeri MG, Goundadkar BB.|2016|Não|
||Comparative sensitivity of field and laboratory populations of Hyalella|Clark SL, Ogle RS, Gantner A, Hall LW Jr, Mitchell<br>G, Giddings J, McCoole M, Dobbs M, Henry K,|||
|2a|azteca to the pyrethroid insecticides bifenthrin and cypermethrin.|Valenti T.|2015|Não|
||A comparison of the sublethal and lethal toxicity of four pesticides in||||
|2a|Hyalella azteca and Chironomus dilutus.|Hasenbein S, Connon RE, Lawler SP, Geist J.|2015|Não|
||Assessment of toxic interactions between deltamethrin and copper on the<br>fertility and developmental events in the Mediterranean sea urchin,||||
|2a|Paracentrotus lividus.|Gharred T, Ezzine IK, Naija A, Bouali RR, Jebali J.|2015|Não|
||Investigation of insecticide-resistance status of Cydia pomonella in Chinese||||
|2a|populations.|Yang XQ, Zhang YL.|2015|Não|
||Neurobehavioral effects of exposure to organophosphates and pyrethroid|Fiedler N, Rohitrattana J, Siriwong W, Suttiwan P,<br>Ohman Strickland P, Ryan PB, Rohlman DS,|||
|2a|pesticides among Thai children.|Panuwet P, Barr DB, Robson MG.|2015|Não|
|2a|Effect of subacute poisoning with bifenthrin on locomotor activity, memory<br>retention, haematological, biochemical and histopathological parameters in<br>mice.|Nieradko-Iwanicka B, Borzecki A, Jodlowska-<br>Jedrych B.|2015|Não|  
72  
|2a|Molecular features and toxicological properties of four common pesticides,<br>acetamiprid, deltamethrin, chlorpyriphos and fipronil.|Taillebois E, Alamiddine Z, Brazier C, Graton J,<br>Laurent AD, Thany SH, Le Questel JY.|2015|Sim|
|---|---|---|---|---|
||Synergistic protective effects of ceftriaxone and ascorbic acid against||||
|2a|subacute deltamethrin-induced nephrotoxicity in rats.|Abdel-Daim MM, El-Ghoneimy A.|2015|Não|
|2a|Evidence for dose-additive effects of a type II pyrethroid mixture. In vitro<br>assessment.|Romero A, Ares I, Ramos E, Castellano V, MartÃ-<br>nez M, MartÃnez-LarraÃ±aga MR, AnadÃ³n A,<br>MartÃnez MA.|2015|Não|
|2a|Distinct roles of the DmNav and DSC1 channels in the action of DDT and<br>pyrethroids.|Rinkevich FD, Du Y, Tolinski J, Ueda A, Wu CF,<br>Zhorov BS, Dong K.|2015|Não|
||Developmental pesticide exposure reproduces features of attention deficit|Richardson JR, Taylor MM, Shalat SL, Guillot TS<br>3rd, Caudle WM, Hossain MM, Mathews TA, Jones|||
|2a|hyperactivity disorder.|SR, Cory-Slechta DA, Miller GW.|2015|Não|
|2a|Identification of polymorphisms in Cyrtorhinus lividipennis RDL subunit<br>contributing to fipronil sensitivity.|Jiang F, Zhang Y, Sun H, Meng X, Bao H, Fang J, Liu<br>Z.|2015|Não|
||Application of species sensitivity distribution in aquatic probabilistic<br>ecological risk assessment of cypermethrin: a case study in an urban stream<br>||||
|2a|in South China.|Li H, You J.|2015|Não|
||Alteration of hedgehog signaling by chronic exposure to different pesticide<br>formulations and unveiling the regenerative potential of recombinant sonic||||
|2a|hedgehog in mouse model of bone marrow aplasia.|Chaklader M, Law S.|2015|Não|
||Susceptibility to insecticides and resistance mechanisms in Aedes aegypti|Maestre-Serrano R, Gomez-Camargo D, Ponce-|||
|2a|from the Colombian Caribbean Region.|Garcia G, Flores AE.|2014|Não|
||Genomic analysis of the interaction between pesticide exposure and||||
|2a|nutrition in honey bees (Apis mellifera).|Schmehl DR, Teal PE, Frazier JL, Grozinger CM.|2014|Não|
|2a|Successful validation of genomic biomarkers for human immunotoxicity in<br>Jurkat T cells in vitro.|Schmeits PC, Shao J, van der Krieken DA, Volger<br>OL, van Loveren H, Peijnenburg AA, Hendriksen PJ.|2015|Não|  
73  
||Pyrethroids differentially alter voltage-gated sodium channels from the|Kadala A, Charreton M, Jakob I, Cens T, Rousset M,|||
|---|---|---|---|---|
|2a|honeybee central olfactory neurons.|Chahine M, Le Conte Y, Charnet P, Collet C.|2014|Não|
|2a|Semen quality and the level of reproductive hormones after environmental<br>exposure to pyrethroids.|Radwan M, Jurewicz J, Wielgomas B, Sobala W,<br>Piskunowicz M, Radwan P, Hanke W.|2014|Não|
||Mosquito control insecticides: a probabilistic ecological risk assessment on<br>drift exposures of naled, dichlorvos (naled metabolite) and permethrin to||||
|2a|adult butterflies.|Hoang TC, Rand GM.|2015|Não|
|2a|Is acetylcholinesterase a biomarker of susceptibility in Daphnia magna<br>(Crustacea, Cladocera) after deltamethrin exposure?|Toumi H, Boumaiza M, Millet M, Radetski CM,<br>Felten V, FÃ©rard JF.|2015|Não|
|2a|The use of zebrafish (Danio rerio) behavioral responses in identifying<br>sublethal exposures to deltamethrin.|Huang Y, Zhang J, Han X, Huang T.|2014|Não|
||Pyrethroid insecticide exposure and reproductive hormone levels in healthy|Yoshinaga J, Imai K, Shiraishi H, Nozawa S, Yoshiike|||
|2a|Japanese male subjects.|M, Mieno MN, Andersson AM, Iwamoto T.|2014|Sim|
||DDT & deltamethrin resistance status of known Japanese encephalitis|Dhiman S, Rabha B, Talukdar PK, Das NG, Yadav K,|||
|2a|vectors in Assam, India.|Baruah I, Singh L, Veer V.|2013|Não|
||In vitro myelotoxic effects of cypermethrin and mancozeb on human||||
|2a|hematopoietic progenitor cells.|Mandarapu R, Prakhya BM.|2015|Não|
||Effect of deltamethrin (pyrethroid insecticide) on two clones of Daphnia|Toumi H, Boumaiza M, Immel F, Sohm B, Felten V,|||
|2a|magna (Crustacea, Cladocera): a proteomic investigation.|FÃ©rard JF.|2014|Não|
|2a|Intravenous lipid emulsion for treating permethrin toxicosis in a cat.|DeGroot WD.|2014|Não|
|2a|Earthworm biomarker responses on exposure to commercial cypermethrin.|Muangphra P, Sengsai S, Gooneratne R.|2015|Não|
||Using Hexagenia in sediment bioassays: methods, applicability, and relative||||
|2a|sensitivity.|Harwood AD, Rothert AK, Lydy MJ.|2014|Não|
||Synergistic sub-lethal effects of a biocide mixture on the springtail Folsomia||||
|2a|fimetaria.|Schnug L, Leinaas HP, Jensen J.|2014|Não|
|2a|Comparative toxicity of carbaryl, carbofuran, cypermethrin and fenvalerate<br>in Metaphire posthuma and Eisenia fetida -a possible mechanism.|Saxena PN, Gupta SK, Murthy RC.|2014|Não|  
74  
||Interactive effects of Î»-cyhalothrin, soil moisture, and temperature on||||
|---|---|---|---|---|
|2a|Folsomia candida and Sinella curviseta (Collembola).|Bandow C, Coors A, Karau N, RÃ¶mbke J.|2014|Não|
||Point mutations in the sodium channel gene conferring tau-fluvalinate|Hubert J, Nesvorna M, Kamler M, Kopecky J, Tyl J,|||
|2a|resistance in Varroa destructor.|Titera D, Stara J.|2014|Não|
|2a|Species composition of a soil invertebrate multi-species test system<br>determines the level of ecotoxicity.|Sechi V, D'Annibale A, Maraldo K, Johansen A,<br>Bossi R, Jensen J, Krogh PH.|2014|Não|
|2a|Pairing behavior and reproduction in Hyalella azteca as sensitive endpoints<br>for detecting long-term consequences of pesticide pulses.|Pedersen S, Palmqvist A, Thorbek P, Hamer M,<br>Forbes V.|2013|Não|
||Biological endpoints, enzyme activities, and blood cell parameters in two|Attademo AM, Peltzer PM, Lajmanovich RC,|||
|2a|anuran tadpole species in rice agroecosystems of mid-eastern Argentina.|Cabagna-Zenklusen MC, Junges CM, Basso A.|2014|Não|
|2a|Multiple origins of pyrethroid insecticide resistance across the species<br>complex of a nontarget aquatic crustacean, Hyalella azteca.|Weston DP, Poynton HC, Wellborn GA, Lydy MJ,<br>Blalock BJ, Sepulveda MS, Colbourne JK.|2013|Não|
||Pyrethroid effects on freshwater invertebrates: a meta-analysis of pulse|Rasmussen JJ, Wiberg-Larsen P, Kristensen EA,|||
|2a|exposures.|Cedergreen N, Friberg N.|2013|Não|
||Identification of an alternative knockdown resistance (kdr)-like mutation,<br>M918L, and a novel mutation, V1010A, in the Thrips tabaci voltage-gated||||
|2a|sodium channel gene.|Wu M, Gotoh H, Waters T, Walsh DB, Lavine LC.|2014|Não|
|||Cha YS, Kim H, Cho NH, Jung WJ, Kim YW, Kim TH,|||
|2a|Pyrethroid poisoning: features and predictors of atypical presentations.|Kim OH, Cha KC, Lee KH, Hwang SO, Nelson LS.|2014|Sim|
||Cytokine patterns in greenhouse workers occupationally exposed to Î±-|Costa C, Rapisarda V, Catania S, Di Nola C, Ledda C,|||
|2a|cypermethrin: an observational study.|Fenga C.|2013|Sim|
|2a|Pyrethroid insecticides in municipal wastewater.|Weston DP, Ramil HL, Lydy MJ.|2013|Não|
||Molecular evidence for dual pyrethroid-receptor sites on a mosquito|Du Y, Nomura Y, Satar G, Hu Z, Nauen R, He SY,|||
|2a|sodium channel.|Zhorov BS, Dong K.|2013|Não|
||Different sensitivities of biomarker responses in two epigeic earthworm||||
|2a|species after exposure to pyrethroid and organophosphate insecticides.|Velki M, Hackenberger BK.|2013|Não|  
75  
||Acute kidney injury secondary to exposure to insecticides used for bedbug|Bashir B, Sharma SG, Stein HD, Sirota RA, D'Agati|||
|---|---|---|---|---|
|2a|(Cimex lectularis) control.|VD.|2013|Sim|
||A residue in the transmembrane segment 6 of domain I in insect and<br>mammalian sodium channels regulate differential sensitivities to||||
|2a|pyrethroid insecticides.|Oliveira EE, Du Y, Nomura Y, Dong K.|2013|Não|
||[An intoxication can hide another one more serious. Example of a fatal<br>poisoning with ethylene glycol intoxication masked by a pyrethroid||||
|2a|insecticide].|Aissaoui Y, Kichna H, Boughalem M, Kamili ND.|2013|Sim|
||Density shift, morphological damage, lysosomal fragility and apoptosis of||||
|2a|hemocytes of Indian molluscs exposed to pyrethroid pesticides.|Ray M, Bhunia AS, Bhunia NS, Ray S.|2013|Não|
||Lethal and sublethal effects of three insecticides on two developmental||||
|2a|stages of Xenopus laevis and comparison with other amphibians.|Yu S, Wages MR, Cai Q, Maul JD, Cobb GP.|2013|Não|
||Retrospective estimation of population-level effect of pollutants based on||||
|2a|local adaptation and fitness cost of tolerance.|Tanaka Y, Tatsuta H.|2013|Sim|
||Linking sub-individual and population level toxicity effects in Daphnia<br>schoedleri (Cladocera: Anomopoda) exposed to sublethal concentrations of<br>|MartÃnez-JerÃ³nimo F, Arzate-CÃ¡rdenas M, Ortiz-<br>|||
|2a|the pesticide Î±-cypermethrin.|ButrÃ³n R.|2013|Não|
|2a|[Distribution of deltamethrin in acute poisoned rats].|Wu B, Yan P, Wei ZW, Wang YJ.|2013|Não|
||Effects of deltamethrin (pyrethroid insecticide) on growth, reproduction,<br>embryonic development and sex differentiation in two strains of Daphnia|Toumi H, Boumaiza M, Millet M, Radetski CM,|||
|2a|magna (Crustacea, Cladocera).|Felten V, Fouque C, FÃ©rard JF.|2013|Não|
||Deltamethrin induced toxicity and ameliorative effect of alpha-tocopherol||||
|2a|in broilers.|Chandra N, Jain NK, Sondhia S, Srivastava AB.|2013|Não|
|2a|[Chronotoxicology of fenvalerate on the male rats reproductive system].|Qin F, Yuan H, Chen L, Jiang B, Tong J, Zhang J.|2012|Não|
|2a|Comparative toxicity of pyrethroid insecticides to two estuarine crustacean<br>species, Americamysis bahia and Palaemonetes pugio.|DeLorenzo ME, Key PB, Chung KW, Sapozhnikova<br>Y, Fulton MH.|2014|Não|  
76  
|2a|A refined aquatic ecological risk assessment for a pyrethroid insecticide<br>used for adult mosquito management.|Schleier JJ 3rd, Peterson RK.|2013|Não|
|---|---|---|---|---|
||Applying biofluid metabonomic techniques to analyze the combined||||
|2a|subchronic toxicity of propoxur and permethrin in rats.|Liang YJ, Wang HP, Long DX, Wu YJ.|2012|Não|
||[Effects of the environmental hormone cypermethrin on the reproduction||||
|2a|of Brachionus calyciflorus].|Dong XX, Yang JX, LÃ¼ LL, Zhao WH, Yu YB.|2012|Não|
|2a|Two stressors and a community: effects of hydrological disturbance and a<br>toxicant on freshwater zooplankton.|Stampfli NC, Knillmann S, Liess M, Noskov YA,<br>SchÃ¤fer RB, Beketov MA.|2013|Não|
|2a|Acute effects of deltamethrin on swimming velocity and biomarkers of the<br>common prawn Palaemon serratus.|Oliveira C, Almeida J, Guilhermino L, Soares AM,<br>Gravato C.|2012|Não|
|2a|[Teases at the scalp: ectoparasites].|Paasch U, Grunewald S, Handrick W, Nenoff P.|2012|Sim|
||Effects of deltamethrin on the specific discrimination of sex pheromones in||||
|2a|two sympatric Trichogramma species.|Delpuech JM, Dupont C, Allemand R.|2012|Não|
|2a|[Chemical toxicological identification of esfenvalerate].|Shormanov VK, Chigareva EN, Vladimirenko EN.|2012|Sim|
|2a|Environmentally relevant mixtures in cumulative assessments: an acute<br>study of toxicokinetics and effects on motor activity in rats exposed to a<br>mixture of pyrethroids.|Starr JM, Scollon EJ, Hughes MF, Ross DG, Graham<br>SE, Crofton KM, Wolansky MJ, Devito MJ, Tornero-<br>Velez R.|2012|Não|
||Population growth rate responses of Ceriodaphnia dubia to ternary<br>mixtures of specific acting chemicals: pharmacological versus|Barata C, FernÃ¡ndez-San Juan M, Feo ML,|||
|2a|ecotoxicological modes of action.|Eljarrrat E, Soares AM, BarcelÃ³ D, Baird DJ.|2012|Não|
||Phytotoxicity of atrazine, S-metolachlor, and permethrin to Typha latifolia||||
|2a|(Linneaus) germination and seedling growth.|Moore MT, Locke MA.|2012|Não|
||Does insecticide drift adversely affect grasshoppers (Orthoptera: Saltatoria)<br>in field margins? A case study combining laboratory acute toxicity testing||||
|2a|with field monitoring data.|Bundschuh R, Schmitz J, Bundschuh M, BrÃ¼hl CA.|2012|Não|
|2a|Intraspecific competition increases toxicant effects in outdoor pond<br>microcosms.|Knillmann S, Stampfli NC, Beketov MA, Liess M.|2012|Não|  
77  
||Deltamethrin-induced oxidative stress and biochemical changes in tissues<br>and blood of catfish (Clarias gariepinus): antioxidant defense and role of||||
|---|---|---|---|---|
|2a|alpha-tocopherol.|Amin KA, Hashem KS.|2012|Não|
|2a|Acute contact toxicity test of insecticides (Cipermetrina 25, Lorsban 48E,<br>Thionex 35) on honeybees in the southwestern zone of Uruguay.|Carrasco-Letelier L, Mendoza-Spina Y,<br>Branchiccela MB.|2012|Não|
|2a|Quantifying children's aggregate (dietary and residential) exposure and<br>dose to permethrin: application and evaluation of EPA's probabilistic<br>SHEDS-Multimedia model.|Zartarian V, Xue J, Glen G, Smith L, Tulve N,<br>Tornero-Velez R.|2012|Sim|
|2a|Toxic effects of deltamethrin and Î»-cyhalothrin on Xenopus laevis<br>tadpoles.|Aydin-Sinan H, GÃ¼ngÃ¶rdÃ¼ A, Ozmen M.|2012|Não|
|2a|Interspecific competition delays recovery of Daphnia spp. populations from<br>pesticide stress.|Knillmann S, Stampfli NC, Noskov YA, Beketov MA,<br>Liess M.|2012|Não|
|2a|Comparative study on the toxicity of pyrethroids, Î±-cypermethrin and<br>deltamethrin to Ceriodaphnia dubia.|Shen MF, Kumar A, Ding SY, Grocke S.|2012|Não|
|||Li JL, Zhou HY, Cao J, Zhu GD, Wang WM, Gu Y, Liu|||
|2a|[Sensitivity of Anopheles sinensis to insecticides in Jiangsu Province].|Y, Cao Y, Zhang C, Gao Q.|2011|Não|
|2a|Isolation of alpaca anti-hapten heavy chain single domain antibodies for<br>development of sensitive immunoassay.|Kim HJ, McCoy MR, Majkova Z, Dechant JE, Gee SJ,<br>Tabares-da Rosa S, GonzÃ¡lez-Sapienza GG,<br>Hammock BD.|2012|Não|
||Evaluation of suitable endpoints for assessing the impacts of toxicants at||||
|2a|the community level.|SÃ¡nchez-Bayo F, Goka K.|2012|Sim|
||Effects of pesticide formulations and active ingredients on the coelenterate|Demetrio PM, Bulus Rossini GD, Bonetto CA,|||
|2a|Hydra attenuata (Pallas, 1766).|Ronco AE.|2012|Não|
|2a|Advances in the mode of action of pyrethroids.|Clark JM, Symington SB.|2012|Sim|
||Acute toxicities of cadmium and permethrin on the pre-spawning and post-||||
|2a|spawning phases of Hexaplex trunculus from Bizerta Lagoon, Tunisia.|Mahmoud N, Dellali M, Aissa P, Mahmoudi E.|2012|Não|  
78  
|2a|Joint toxicity of a pyrethroid insecticide, cypermethrin, and a heavy metal,<br>lead, to the benthic invertebrate Chironomus dilutus.|Mehler WT, Du J, Lydy MJ, You J.|2011|Não|
|---|---|---|---|---|
||Structural and functional effects of conventional and low pesticide input<br>crop-protection programs on benthic macroinvertebrate communities in||||
|2a|outdoor pond mesocosms.|Auber A, Roucaute M, Togola A, Caquet T.|2011|Sim|
||Effects of the synthetic pyrethroid insecticide, permethrin, on two||||
|2a|estuarine fish species.|Parent LM, Delorenzo ME, Fulton MH.|2011|Sim|
||Susceptibility of oriental fruit moth (Lepidoptera: Tortricidae) to two<br>pyrethroids and a proposed diagnostic dose of esfenvalerate for field||||
|2a|detection of resistance.|Jones MM, Robertson JL, Weinzierl RA.|2011|Sim|
|||Weston DP, Asbell AM, Hecht SA, Scholz NL, Lydy|||
|2a|Pyrethroid insecticides in urban salmon streams of the Pacific Northwest.|MJ.|2011|Sim|
||Environmental context determines community sensitivity of freshwater||||
|2a|zooplankton to a pesticide.|Stampfli NC, Knillmann S, Liess M, Beketov MA.|2011|Sim|
||Toxicological effects of cypermethrin to marine phytoplankton in a co-||||
|2a|culture system under laboratory conditions.|Wang ZH, Nie XP, Yue WJ.|2011|Sim|
||Double-blind non-controlled chemical challenge with environmental||||
|2a|toxicological assessment in a Multiple Chemical Sensitivity case.|Ralph B, Martine O, Jacques R.|2011|Sim|
||Biochemical and toxicological evidence of neurological effects of pesticides:||||
|2a|the example of Parkinson's disease.|Moretto A, Colosio C.|2011|Sim|
||Pyrethroid mode(s) of action in the context of Food Quality Protection Act||||
|2a|(FQPA) regulation.|Gammon DW, Leggett MF, Clark JM.|2011|Sim|
||Use of butterflies as nontarget insect test species and the acute toxicity and||||
|2a|hazard of mosquito control insecticides.|Hoang TC, Pryor RL, Rand GM, Frakes RA.|2011|Sim|
||Chlorfenapyr: a new insecticide with novel mode of action can control|Raghavendra K, Barik TK, Sharma P, Bhatt RM,|||
|2a|pyrethroid resistant malaria vectors.|Srivastava HC, Sreehari U, Dash AP.|2011|Sim|  
79  
||Motor neuron disorder with tongue spasms due to pyrethroid insecticide|Ahdab R, Ayache SS, Maltonti F, BrugiÃ¨res P,|||
|---|---|---|---|---|
|2a|toxicity.|Lefaucheur JP.|2011|Sim|
||Synergy in microcosms with environmentally realistic concentrations of|Bjergager MB, Hanson ML, Lissemore L, Henriquez|||
|2a|prochloraz and esfenvalerate.|N, Solomon KR, Cedergreen N.|2011|Não|
||The effect of cypermethrin on different tissues of freshwater fish Tilapia||||
|2a|mossambica (Perters).|Prashanth MS, Hiragond NC, Nikam KN.|2011|Não|
||B-esterase activities and blood cell morphology in the frog Leptodactylus<br>chaquensis (Amphibia: Leptodactylidae) on rice agroecosystems from Santa|Attademo AM, Cabagna-Zenklusen M,|||
|2a|Fe Province (Argentina).|Lajmanovich RC, Peltzer PM, Junges C, BassÃ³ A.|2011|Não|
||Effects of an environmentally realistic pesticide mixture on Daphnia magna||||
|2a|exposed for two generations.|Brausch JM, Salice CJ.|2011|Não|
|2a|Abnormal glucose regulation in pyrethroid pesticide factory workers.|Wang J, Zhu Y, Cai X, Yu J, Yang X, Cheng J.|2011|Sim|
||Monitoring for resistance to organophosphorus and pyrethroid insecticides||||
|2a|in Varroa mite populations.|Kanga LH, Adamczyk J, Marshall K, Cox R.|2010|Sim|
||A multi-biomarker approach to assess the impact of farming systems on|Tu HT, Silvestre F, Wang N, Thome JP, Phuong NT,|||
|2a|black tiger shrimp (Penaeus monodon).|Kestemont P.|2010|Não|
||Persistence of DDT, malathion & deltamethrin resistance in Anopheles<br>culicifacies after their sequential withdrawal from indoor residual spraying|Raghavendra K, Verma V, Srivastava HC,|||
|2a|in Surat district, India.|Gunasekaran K, Sreehari U, Dash AP.|2010|Não|
||Dual enantioselective effect of the insecticide bifenthrin on locomotor||||
|2a|behavior and development in embryonic-larval zebrafish.|Jin M, Zhang Y, Ye J, Huang C, Zhao M, Liu W.|2010|Não|
||Discriminating between different acute chemical toxicities via changes in||||
|2a|the daphnid metabolome.|Taylor NS, Weber RJ, White TA, Viant MR.|2010|Não|
||Takotsubo cardiomyopathy related to carbamate and pyrethroid||||
|2a|intoxication.|Lin CC, Lai SY, Hu SY, Tsan YT, Hu WH.|2010|Sim|
||Divergent actions of the pyrethroid insecticides S-bioallethrin, tefluthrin,||||
|2a|and deltamethrin on rat Na(v)1.6 sodium channels.|Tan J, Soderlund DM.|2010|Não|  
80  
|2a|Cytotoxicity of lambda-cyhalothrin on the macrophage cell line RAW 264.7.|Zhang Q, Wang C, Sun L, Li L, Zhao M.|2010|Não|
|---|---|---|---|---|
||Differences in the behavior characteristics between Daphnia magna and||||
|2a|Japanese madaka in an on-line biomonitoring system.|Ren Z, Wang Z.|2010|Não|
|||Andrade FH, Figueiroa FC, Bersano PR, Bissacot|||
|2a|Malignant mammary tumor in female dogs: environmental contaminants.|DZ, Rocha NS.|2010|Não|
|2a|Oral deltamethrin ingestion due in a suicide attempt.|Gunay N, Kekec Z, Cete Y, Eken C, Demiryurek AT.|2010|Sim|
||A negative charge in transmembrane segment 1 of domain II of the<br>cockroach sodium channel is critical for channel gating and action of|Du Y, Song W, Groome JR, Nomura Y, Luo N, Dong|||
|2a|pyrethroid insecticides.|K.|2010|Não|
|2a|Ecotoxicological tools for the tropics: Sublethal assays with fish to evaluate<br>edge-of-field pesticide runoff toxicity.|Moreira SM, Moreira-Santos M, RendÃ³n-von<br>Osten J, da Silva EM, Ribeiro R, Guilhermino L,<br>Soares AM.|2010|Não|
|2a|Behavioural changes in three species of freshwater macroinvertebrates<br>exposed to the pyrethroid lambda-cyhalothrin: laboratory and stream<br>microcosm studies.|NÃ¸rum U, Friberg N, Jensen MR, Pedersen JM,<br>Bjerregaard P.|2010|Não|
||Toxicity of the insecticide etofenprox to three life stages of the grass||||
|2a|shrimp, Palaemonetes pugio.|DeLorenzo ME, De Leon RG.|2010|Não|
||High sensitivity of Gammarus sp. juveniles to deltamethrin: outcomes for||||
|2a|risk assessment.|Adam O, Degiorgi F, Crini G, Badot PM.|2010|Não|
|2a|The growth behavior of three marine phytoplankton species in the<br>presence of commercial cypermethrin.|Wang ZH, Yang YF, Yue WJ, Kang W, Liang WJ, Li<br>WJ.|2010|Não|
|2a|Fenvalerate exposure alters thyroid hormone status in selenium- and/or<br>iodine-deficient rats.|Giray B, CaÄŸlayan A, ErkekoÄŸlu P, Hincal F.|2010|Não|  
81  
**Quadro V.3.5.** Artigos resultantes da busca sistemática no site **Lilacs** , para as perguntas PICO sobre diagnóstico para intoxicações por produtos contendo piretroides

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|||||Estudo|
|---|---|---|---|---|
|Busca|<br>Título|Autor|Ano|Considerado|
||Intoxicação por agrotóxicos: clÃnica, diagnÃ³stico e manejo dos pacientes<br>expostos TT  - Pesticide poisoning: Clinical, diagnosis and management of||||
|2b|patients exposed|Pardal, Pedro de Oliveira|2014|Sim|
||IntoxicaÃ§Ãµes por agrotÃ³xicos registrados em um centro de controle de<br>intoxicaÃ§Ãµes TT  - Intoxications by pesticides recorded at a poisoning|Marangoni, SÃ´nia Regina and Seleghim, Maycon<br>RogÃ©rio and Teixeira, JÃ©ssica Adrielle and<br>Buriola, Aline Aparecida and Ballani, TanimÃ¡ria da|||
|2b|control center|Silva Lira and Oliveira, Magda LÃºcia FÃ©lix de|2011|Não|
||Manual de diagnÃ³stico tratamiento y prevenciÃ³n de intoxicaciones<br>agudas por plaguicidas TT  - Manual on diagnostic treatment and||||
|2b|prevention of acute pesticide poisoning|Bolivia, FundaciÃ³n Plaguicidas|2008|Sim|
||IntoxicaciÃ³n por piretrinas: una causa singular de convulsiones en el<br>lactante TT  - Intoxication from pyrethrins: a singular cause of seizures in||||
|2b|the infant|San RomÃ¡n, M and Herranz, J L and Arteaga, R|2003|Sim|
||DiagnÃ³stico, tratamiento y prevenciÃ³n de intoxicaciones agudas causadas<br>por plaguicidas: curso a distancia dirigido a mÃ©dicos y enfermeras TT  -<br>Diagnosis, treatment and prevention of acute intoxications caused by||||
|2b|plaguicides|Salud, PerÃº. Ministerio de|1996|Sim|
||Ambiente y salud: estudio de un agente xenobiÃ³tico sobre la comunidad<br>humana TT  - Environment and health: study of a xenobiotic agent on the|Astolfi, Emilio and Maccagno, Armando and|||
|2b|human community|Rabinovich, Alfredo and Higa de Landoni, Julia|1977|Não|  
82

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|||||Estudo|
|---|---|---|---|---|
|Busca|<br>title|authors|year|Considerado|
|2c|Treatment of Scabies: comparison of Lindane 1% vs Permethrin 5|E, Rezaee and M, Goldust and H, Alipour|2015|Não|
||To assess whether addition of pyriproxyfen to long-lasting insecticidal<br>mosquito nets increases their durability compared to standard long-lasting|N, Sagnon and M, Pinder and EF, Tchicaya and AB,<br>Tiono and B, Faragher and H, Ranson and SW,|||
|2c|insecticidal mosquito nets: study protocol for a randomised controlled trial|Lindsay|2015|Não|
|||MK, Chatzis and D, Psemmas and E, Papadopoulos|||
|2c|A field trial of a fixed combination of permethrin and fipronil (Effitix|and C, Navarro and MN, Saridomichelakis|2017|Não|
||A randomised, assessor blind, parallel group comparative efficacy trial of<br>three products for the treatment of head lice in children--melaleuca oil and<br>lavender oil, pyrethrins and piperonyl butoxide, and a "suffocation"||||
|2c|product|SC, Barker and PM, Altman|2010|Não|
||Tocopheryl acetate 20% spray for elimination of head louse infestation: a||||
|2c|randomised controlled trial comparing with 1% permethrin creme rinse|IF, Burgess and NA, Burgess and ER, Brunton|2013|Não|
||Effect of permethrin-impregnated underwear on body lice in sheltered|S, Benkouiten and R, Drali and S, Badiaga and A,|||
|2c|homeless persons: a randomized controlled trial|Veracx and R, Giorgi and D, Raoult and P, Brouqui|2014|Não|
||Efficacy and Safety of a Mineral Oil-Based Head Lice Shampoo: a|L, Wolf and F, Eertmans and D, Wolf and B, Rossel|||
|2c|Randomized, Controlled, Investigator-Blinded, Comparative Study|and E, Adriaens|2016|Não|  
83

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|**Busca**|<br>**titulo**|**autor**|**ano**|**Estudo**<br>**considerado**|
|---|---|---|---|---|
|3a|Scabies|||Não|
|3a|Variations in lethal and sublethal effects of cypermethrin among aquatic<br>stages and species of anuran amphibians.|Biga LM, Blaustein AR.|2013|Não|
|3a|Synergism between demethylation inhibitor fungicides or gibberellin<br>inhibitor plant growth regulators and bifenthrin in a pyrethroid-resistant<br>population of Listronotus maculicollis (Coleoptera: Curculionidae).|Ramoutar D, Cowles RS, Requintina E Jr, Alm SR.|2010|Não|
|3a|Development and application of the adverse outcome pathway framework<br>for understanding and predicting chronic toxicity: II. A focus on growth<br>impairment in fish.|Groh KJ, Carvalho RN, Chipman JK, Denslow ND,<br>Halder M, Murphy CA, Roelofs D, Rolaki A,<br>Schirmer K, Watanabe KH.|2015|Não|
|3a|Sensitivity assessment of freshwater macroinvertebrates to pesticides<br>using biological traits.|Ippolito A, Todeschini R, Vighi M.|2012|Não|
|3a|Measured versus simulated dietary pesticide intakes in children.|Riederer AM, Lu C.|2012|Não|
|3a|Prenatal exposure to pyrethroid insecticides and birth outcomes in Rural<br>Northern China.|Ding G, Cui C, Chen L, Gao Y, Zhou Y, Shi R, Tian Y.|2015|Não|
|3a|First report of a fish kill episode caused by pyrethroids in Italian<br>freshwater.|Bille L, Binato G, Gabrieli C, Manfrin A, Pascoli F,<br>Pretto T, Toffan A, Dalla Pozza M, Angeletti R,<br>Arcangeli G.|2017|Não|  
84  
|3a|Testing the time-scale dependence of delayed interactions: A heat wave<br>during the egg stage shapes how a pesticide interacts with a successive<br>heat wave in the larval stage.|Janssens L, TÃ¼zÃ¼n N, Stoks R.|2017|Não|
|---|---|---|---|---|
|3a|Bifenthrin Causes Toxicity in Urban Stormwater Wetlands: Field and<br>Laboratory Assessment Using Austrochiltonia (Amphipoda).|Jeppe KJ, Kellar CR, Marshall S, Colombo V,<br>Sinclair GM, Pettigrove V.|2017|Não|
|3a|An Evaluation of the Human Relevance of the Lung Tumors Observed in<br>Female Mice Treated With Permethrin Based on Mode of Action.|Yamada T, Kondo M, Miyata K, Ogata K, Kushida<br>M, Sumida K, Kawamura S, Osimitz TG, Lake BG,<br>Cohen SM.|2017|Não|
|3a|Comparing the impacts of sediment-bound bifenthrin on aquatic<br>macroinvertebrates in laboratory bioassays and field microcosms.|Boyle RL, Hoak MN, Pettigrove VJ, Hoffmann AA,<br>Long SM.|2016|Não|
|3a|Transient Complete Heart Block Secondary to Bed Bug Insecticide: A Case<br>of Pyrethroid Cardiac Toxicity.|Singh H, Luni FK, Marwaha B, Ali SS, Alo M.|2016|Sim|
|3a|Trait Characteristics Determine Pyrethroid Sensitivity in Nonstandard Test<br>Species of Freshwater Macroinvertebrates: A Reality Check.|Wiberg-Larsen P, Graeber D, Kristensen EA,<br>Baattrup-Pedersen A, Friberg N, Rasmussen JJ.|2016|Não|
|3a|Population-specific toxicity of six insecticides to the trematode<br>Echinoparyphium sp.|Hua J, Buss N, Kim J, Orlofske SA, Hoverman JT.|2016|Não|
|3a|Neurobehavioral effects of exposure to organophosphates and pyrethroid<br>pesticides among Thai children.|Fiedler N, Rohitrattana J, Siriwong W, Suttiwan P,<br>Ohman Strickland P, Ryan PB, Rohlman DS,<br>Panuwet P, Barr DB, Robson MG.|2015|Sim|
|3a|Effect of subacute poisoning with bifenthrin on locomotor activity|Nieradko-Iwanicka B, Borzecki A, Jodlowska-<br>Jedrych B.|2015|Não|
|3a|Distinct roles of the DmNav and DSC1 channels in the action of DDT and<br>pyrethroids.|Rinkevich FD, Du Y, Tolinski J, Ueda A, Wu CF,<br>Zhorov BS, Dong K.|2015|Não|
|3a|Successful validation of genomic biomarkers for human immunotoxicity in<br>Jurkat T cells in vitro.|Schmeits PC, Shao J, van der Krieken DA, Volger<br>OL, van Loveren H, Peijnenburg AA, Hendriksen<br>PJ.|2015|Não|  
85  
|3a|Synergistic sub-lethal effects of a biocide mixture on the springtail<br>Folsomia fimetaria.|Schnug L, Leinaas HP, Jensen J.|2014|Não|
|---|---|---|---|---|
|3a|Pyrethroid poisoning: features and predictors of atypical presentations.|Cha YS, Kim H, Cho NH, Jung WJ, Kim YW, Kim TH,<br>Kim OH, Cha KC, Lee KH, Hwang SO, Nelson LS.|2014|Sim|
|3a|Molecular evidence for dual pyrethroid-receptor sites on a mosquito<br>sodium channel.|Du Y, Nomura Y, Satar G, Hu Z, Nauen R, He SY,<br>Zhorov BS, Dong K.|2013|Não|
|3a|[An intoxication can hide another one more serious. Example of a fatal<br>poisoning with ethylene glycol intoxication masked by a pyrethroid<br>insecticide].|Aissaoui Y, Kichna H, Boughalem M, Kamili ND.|2013|Sim|
|3a|Linking sub-individual and population level toxicity effects in Daphnia<br>schoedleri (Cladocera: Anomopoda) exposed to sublethal concentrations of<br>the pesticide Î±-cypermethrin.|MartÃnez-JerÃ³nimo F, Arzate-CÃ¡rdenas M,<br>Ortiz-ButrÃ³n R.|2013|Não|
|3a|Comparative toxicity of pyrethroid insecticides to two estuarine crustacean<br>species|DeLorenzo ME, Key PB, Chung KW, Sapozhnikova<br>Y, Fulton MH.|2014|Não|
|3a|Two stressors and a community: effects of hydrological disturbance and a<br>toxicant on freshwater zooplankton.|Stampfli NC, Knillmann S, Liess M, Noskov YA,<br>SchÃ¤fer RB, Beketov MA.|2013|Não|
|3a|Population growth rate responses of Ceriodaphnia dubia to ternary<br>mixtures of specific acting chemicals: pharmacological versus<br>ecotoxicological modes of action.|Barata C, FernÃ¡ndez-San Juan M, Feo ML,<br>Eljarrrat E, Soares AM, BarcelÃ³ D, Baird DJ.|2012|Não|
|3a|Does insecticide drift adversely affect grasshoppers (Orthoptera:<br>Saltatoria) in field margins? A case study combining laboratory acute<br>toxicity testing with field monitoring data.|Bundschuh R, Schmitz J, Bundschuh M, BrÃ¼hl CA.|2012|Não|
|3a|Interspecific competition delays recovery of Daphnia spp. populations from<br>pesticide stress.|Knillmann S, Stampfli NC, Noskov YA, Beketov MA,<br>Liess M.|2012|Não|
|3a|Evaluation of suitable endpoints for assessing the impacts of toxicants at<br>the community level.|SÃ¡nchez-Bayo F, Goka K.|2012|Sim|  
86  
|3a|Effects of an environmentally realistic pesticide mixture on Daphnia magna||||
|---|---|---|---|---|
||exposed for two generations.|Brausch JM, Salice CJ.|2011|Não|
|3a|Persistence of DDT|Raghavendra K, Verma V, Srivastava HC,<br>Gunasekaran K, Sreehari U, Dash AP.|2010|Não|
|3a|Behavioural changes in three species of freshwater macroinvertebrates<br>exposed to the pyrethroid lambda-cyhalothrin: laboratory and stream<br>microcosm studies.|NÃ¸rum U, Friberg N, Jensen MR, Pedersen JM,<br>Bjerregaard P.|2010|Não|
|3a|Acute effects of binary mixtures of Type II pyrethroids and<br>organophosphate insecticides on Oreochromis niloticus.|Fai PBA, Tsobgny Kinfack JS, Tala Towa YJ.|2017|Não|
|3a|Acute illnesses associated with insecticides used to control bed bugs--<br>seven states|Centers for Disease Control and Prevention<br>(CDC)..|2011|Sim|
|3a|Acute toxicity tests with Daphnia magna|Brock TC, Van Wijngaarden RP.|2012|Não|
|3a|Additive and synergistic antiandrogenic activities of mixtures of azol<br>fungicides and vinclozolin.|Christen V, Crettaz P, Fent K.|2014|Não|
|3a|Anosmia after exposure to a pyrethrin-based insecticide: a case report.|Gobba F, Abbacchini C.|2012|Sim|
|3a|Assessing the fate and effects of an insecticidal formulation.|de Perre C, Williard KW, Schoonover JE, Young BG,<br>Murphy TM, Lydy MJ.|2015|Não|
|3a|Assessment of potential immunotoxic effects caused by cypermethrin|Martini F, FernÃ¡ndez C, Segundo LS, Tarazona JV,<br>Pablos MV.|2010|Não|
|3a|Behavioural disorders in 6-year-old children and pyrethroid insecticide<br>exposure: the PELAGIE mother-child cohort.|Viel JF, Rouget F, Warembourg C, Monfort C,<br>Limon G, Cordier S, Chevrier C.|2017|Sim|
|3a|Bioavailability-based toxicity endpoints of bifenthrin for Hyalella azteca and<br>Chironomus dilutus.|<br>Harwood AD, Landrum PF, Lydy MJ.|2013|Não|
|3a|Characteristics and magnitude of acute pesticide-related illnesses and|Hudson NL, Kasner EJ, Beckman J, Mehler L,<br>Schwartz A, Higgins S, Bonnar-Prado J, Lackovic M,<br>Mulay P, Mitchell Y, Larios L, Walker R, Waltz J,|||
||injuries associated with pyrethrin and pyrethroid exposures--11 states|Moraga-McHaley S, Roisman R, Calvert GM.|2014|Sim|  
87  
|3a|Characteristics of suspended solids affect bifenthrin toxicity to the calanoid||||
|---|---|---|---|---|
||copepods Eurytemora affinis and Pseudodiaptomus forbesi.|Parry E, Lesmeister S, Teh S, Young TM.|2015|Não|
|3a|Characterization of Î±-cypermethrin exposure in Egyptian agricultural<br>workers.|Singleton ST, Lein PJ, Farahat FM, Farahat T,<br>Bonner MR, Knaak JB, Olson JR.|2014|Sim|
|3a|Combined toxicity of butachlor|Chen C, Wang Y, Zhao X, Qian Y, Wang Q.|2014|Não|
|3a|Comparative toxicities of organophosphate and pyrethroid insecticides to<br>aquatic macroarthropods.|Halstead NT, Civitello DJ, Rohr JR.|2015|Não|
|3a|A comparison of mixture toxicity assessment: examining the chronic<br>toxicity of atrazine|Phyu YL, Palmer CG, Warne MS, Hose GC,<br>Chapman JC, Lim RP.|2011|Não|
|3a|Correlation of tissue concentrations of the pyrethroid bifenthrin with<br>neurotoxicity in the rat.|Scollon EJ, Starr JM, Crofton KM, Wolansky MJ,<br>DeVito MJ, Hughes MF.|2011|Não|
|3a|Critical consideration of the multiplicity of experimental and organismic<br>determinants of pyrethroid neurotoxicity: a proof of concept.|Wolansky MJ, Tornero-Velez R.|2013|Sim|
|3a|Cypermethrin alters the status of oxidative stress in the peripheral blood:<br>relevance to Parkinsonism.|Tripathi P, Singh A, Agrawal S, Prakash O, Singh<br>MP.|2014|Sim|
|3a|Deltamethrin Induced Alteration of Biochemical Parameters in Channa<br>punctata|Bhattacharjee P, Das S.|2017|Não|
|3a|Determining lower threshold concentrations for synergistic effects.|Bjergager MA, Dalhoff K, Kretschmann A,<br>NÃ¸rgaard KB, Mayer P, Cedergreen N.|2017|Não|
|3a|Determining modifications to bifenthrin toxicity and sediment binding<br>affinity from varying potassium chloride concentrations in overlying water.|Trimble AJ, Belden JB, Mueting SA, Lydy MJ.|2010|Não|
|3a|Disruption of the hormonal network and the enantioselectivity of<br>bifenthrin in trophoblast: maternal-fetal health risk of chiral pesticides.|Zhao M, Zhang Y, Zhuang S, Zhang Q, Lu C, Liu W.|2014|Sim|
|3a|Early life exposure to permethrin: a progressive animal model of<br>Parkinson's disease.|Nasuti C, Brunori G, Eusepi P, Marinelli L,<br>Ciccocioppo R, Gabbianelli R.|2017|Não|
|3a||Maund SJ, Campbell PJ, Giddings JM, Hamer MJ,|||
||Ecotoxicology of synthetic pyrethroids.|Henry K, Pilling ED, Warinton JS, Wheeler JR.|2012|Não|  
88  
|3a|Effect of permethrin-impregnated underwear on body lice in sheltered<br>homeless persons: a randomized controlled trial.|Benkouiten S, Drali R, Badiaga S, Veracx A, Giorgi<br>R, Raoult D, Brouqui P.|2014|Não|
|---|---|---|---|---|
|3a|Effect of pH and ionic strength on exposure and toxicity of encapsulated<br>lambda-cyhalothrin to Daphnia magna.|Son J, Hooven LA, Harper B, Harper SL.|2015|Não|
|3a|Effects of an environmentally-relevant mixture of pyrethroid insecticides<br>on spontaneous activity in primary cortical networks on microelectrode<br>arrays.|Johnstone AFM, Strickland JD, Crofton KM,<br>Gennings C, Shafer TJ.|2017|Não|
|3a|Effects of functionalized fullerenes on bifenthrin and tribufos toxicity to<br>Daphnia magna: Survival|Brausch KA, Anderson TA, Smith PN, Maul JD.|2010|Não|
|3a|Effects of predator cues on pesticide toxicity: toward an understanding of<br>the mechanism of the interaction.|Qin G, Presley SM, Anderson TA, Gao W, Maul JD.|2011|Não|
|3a|Environmental fate of pyrethroids in urban and suburban stream<br>sediments and the appropriateness of Hyalella azteca model in<br>determining ecological risk.|Palmquist K, Fairbrother A, Salatas J, Guiney PD.|2011|Não|
|3a|Evaluation and physiological correlation of plasma proteomic fingerprints<br>for deltamethrin-induced hepatotoxicity in Wistar rats.|Arora D, Siddiqui MH, Sharma PK, Singh SP,<br>Tripathi A, Mandal P, Singh US, Singh PK, Shukla Y.|2016|Não|
|3a|Evaluation of the stereoselective biotransformation of permethrin in<br>human liver microsomes: contributions of cytochrome P450<br>monooxygenases to the formation of estrogenic metabolites.|Lavado R, Li J, Rimoldi JM, Schlenk D.|2014|Sim|
|3a|Exposure to pyrethroid pesticides and the risk of childhood brain tumors in||||
||East China.|Chen S, Gu S, Wang Y, Yao Y, Wang G, Jin Y, Wu Y.|2016|Sim|
|3a|Exposure to pyrethroids insecticides and serum levels of thyroid-related<br>measures in pregnant women.|Zhang J, Hisada A, Yoshinaga J, Shiraishi H,<br>Shimodaira K, Okai T, Noda Y, Shirakawa M, Kato<br>N.|2013|Sim|
|3a|Fatality from acute chlorfenapyr poisoning.|Choi UT, Kang GH, Jang YS, Ahn HC, Seo JY, Sohn<br>YD.|2010|Sim|
|3a|Human intravenous injection of Î²-cyfluthrin with minimal toxic effects.|Miller MA, Menowsky M.|2014|Sim|  
89  
|3a|Identification and characterization of six cytochrome P450 genes belonging<br>to CYP4 and CYP6 gene families in the silkworm|Li B, Zhang H, Ni M, Wang BB, Li FC, Xu KZ, Shen<br>WD, Xia QY, Zhao P.|2014|Não|
|---|---|---|---|---|
|3a|Improving reptile ecological risk assessment: oral and dermal toxicity of<br>pesticides to a common lizard species (Sceloporus occidentalis).|Weir SM, Yu S, Talent LG, Maul JD, Anderson TA,<br>Salice CJ.|2015|Não|
|3a|In utero and lactational exposure to low-doses of the pyrethroid insecticide<br>cypermethrin leads to neurodevelopmental defects in male mice-An<br>ethological and transcriptomic study.|Laugeray A, Herzine A, Perche O, Richard O,<br>Montecot-Dubourg C, Menuet A, Mazaud-Guittot<br>S, LesnÃ© L, Jegou B, Mortaud S.|2017|Não|
|3a|Influences on transfer of selected synthetic pyrethroids from treated<br>Formica to foods.|Melnyk LJ, Hieber TE, Turbeville T, Vonderheide<br>AP, Morgan JN.|2011|Não|
|3a|Inhibition of Human Drug Transporter Activities by the Pyrethroid<br>Pesticides Allethrin and Tetramethrin.|Chedik L, Bruyere A, Le Vee M, Stieger B, Denizot<br>C, Parmentier Y, Potin S, Fardel O.|2017|Sim|
|3a|The initial hyperglycemia in acute type II pyrethroid poisoning.|Kim D, Moon J, Chun B.|2015|Sim|
|3a|Insecticide-mediated up-regulation of cytochrome P450 genes in the red<br>flour beetle (Tribolium castaneum).|Liang X, Xiao D, He Y, Yao J, Zhu G, Zhu KY.|2015|Não|
|3a|Intraspecific competition delays recovery of population structure.|Liess M, Foit K.|2010|Sim|
|3a|Knockdown of several components of cytochrome P450 enzyme systems<br>by RNA interference enhances the susceptibility of Helicoverpa armigera to<br>fenvalerate.|Tang T, Zhao C, Feng X, Liu X, Qiu L.|2012|Não|
|3a|Locomotor activity and tissue levels following acute administration of<br>lambda- and gamma-cyhalothrin in rats.|Moser VC, Liu Z, Schlosser C, Spanogle TL,<br>Chandrasekaran A, McDaniel KL.|2016|Não|
|3a|Mixture toxicity effects of sea louse control agents in Daphnia magna.|Rose S, Altenburger R, Sturm A.|2016|Não|
|3a|Modeling the integration of parasitoid|Onstad DW, Liu X, Chen M, Roush R, Shelton AM.|2013|Não|
|3a|Multiple exposure routes of a pesticide exacerbate effects on a grazing<br>mayfly.|Pristed MJ, Bundschuh M, Rasmussen JJ.|2016|Não|
|3a|A novel toxicokinetic modeling of cypermethrin and permethrin and their<br>metabolites in humans for dose reconstruction from biomarker data.|CÃ´tÃ© J, Bonvalot Y, Carrier G, Lapointe C, Fuhr<br>U, Tomalik-Scharte D, Wachall B, Bouchard M.|2014|Não|  
90  
|3a|Organic carbon content effects on bioavailability of pyrethroid insecticides<br>and validation of solid phase extraction with Poly (2|Feo ML, Corcellas C, Barata C, Ginebreda A,<br>Eljarrat E, BarcelÃ³ D.|2013|Não|
|---|---|---|---|---|
|3a|Pesticide use modifies the association between genetic variants on<br>chromosome 8q24 and prostate cancer.|Koutros S, Beane Freeman LE, Berndt SI, Andreotti<br>G, Lubin JH, Sandler DP, Hoppin JA, Yu K, Li Q,<br>Burdette LA, Yuenger J, Yeager M, Alavanja MC.|2010|Não|
|3a|A pilot study of workplace dermal exposures to cypermethrin at a chemical<br>manufacturing plant.|Buckley TJ, Geer LA, Connor TH, Robertson S,<br>Sammons D, Smith J, Snawder J, Boeniger M.|2011|Sim|
|3a|Potential of piperonyl butoxide-synergised pyrethrins against psocids<br>(Psocoptera: Liposcelididae) for stored-grain protection.|Nayak MK.|2010|Não|
|3a|Predicted transport of pyrethroid insecticides from an urban landscape to<br>surface water.|Jorgenson B, Fleishman E, Macneale KH, Schlenk<br>D, Scholz NL, Spromberg JA, Werner I, Weston DP,<br>Xiao Q, Young TM, Zhang M.|2013|Não|
|3a|Predicting the toxicity of permethrin to Daphnia magna in water using<br>SPME fibers.|Harwood AD, Bunch AR, Flickinger DL, You J, Lydy<br>MJ.|2012|Não|
|3a|Prediction of developmental chemical toxicity based on gene networks of<br>human embryonic stem cells.|Yamane J, Aburatani S, Imanishi S, Akanuma H,<br>Nagano R, Kato T, Sone H, Ohsako S, Fujibuchi W.|2016|Não|
|3a|Prenatal exposure to pesticide ingredient piperonyl butoxide and<br>childhood cough in an urban cohort.|Liu B, Jung KH, Horton MK, Camann DE, Liu X,<br>Reardon AM, Perzanowski MS, Zhang H, Perera<br>FP, Whyatt RM, Miller RL.|2012|Sim|
|3a|Prenatal exposure to pyrethroid pesticides and childhood behavior and<br>executive functioning.|Furlong MA, Barr DB, Wolff MS, Engel SM.|2017|Sim|
|3a|Pyrethroids in Southern California coastal sediments.|Lao W, Tiefenthaler L, Greenstein DJ, Maruya KA,<br>Bay SM, Ritter K, Schiff K.|2012|Não|
|3a|Reduction in swimming performance in juvenile rainbow trout<br>(Oncorhynchus mykiss) following sublethal exposure to pyrethroid<br>insecticides.|Goulding AT, Shelley LK, Ross PS, Kennedy CJ.|2013|Não|  
91  
|3a||Lu G, TraorÃ© C, Meissner P, KouyatÃ© B,|||
|---|---|---|---|---|
||Safety of insecticide-treated mosquito nets for infants and their mothers:<br>randomized controlled community trial in Burkina Faso.|Kynast-Wolf G, Beiersmann C, Coulibaly B, Becher<br>H, MÃ¼ller O.|2015|Não|
|3a|Safety prediction of topically exposed biocides using permeability<br>coefficients and the desquamation rate at the stratum corneum.|Sugino M, Todo H, Suzuki T, Nakada K, Tsuji K,<br>Tokunaga H, Jinno H, Sugibayashi K.|2014|Sim|
|3a|Short-term disturbance of a grazer has long-term effects on bacterial<br>communities--relevance of trophic interactions for recovery from pesticide<br>effects.|Foit K, Chatzinotas A, Liess M.|2010|Não|
|3a|Short-Term Exposure to Lambda-Cyhalothrin Negatively Affects the<br>Survival and Memory-Related Characteristics of Worker Bees Apis<br>mellifera.|Liao CH, He XJ, Wang ZL, Barron AB, Zhang B, Zeng<br>ZJ, Wu XB.|2018|Não|
|3a|Studying permethrin exposure in flight attendants using a physiologically<br>based pharmacokinetic model.|Wei B, Isukapalli SS, Weisel CP.|2013|Não|
|3a|Subacute poisoning of mice with deltamethrin produces memory<br>impairment|Nieradko-Iwanicka B, BorzÄ™cki A.|2015|Não|
|3a|Successful treatment of permethrin toxicosis in two cats with an<br>intravenous lipid administration.|BrÃ¼ckner M, Schwedes CS.|2012|Não|
|3a|Synergistic effect of piperonyl butoxide on acute toxicity of pyrethrins to<br>Hyalella azteca.|Giddings J, Gagne J, Sharp J.|2016|Não|
|3a|The synergistic toxicity of the multiple chemical mixtures: implications for<br>risk assessment in the terrestrial environment.|Chen C, Wang Y, Qian Y, Zhao X, Wang Q.|2015|Não|
|3a|Tenax extraction as a simple approach to improve environmental risk<br>assessments.|Harwood AD, Nutile SA, Landrum PF, Lydy MJ.|2015|Não|
|3a|Ternary toxicological interactions of insecticides|Wang Y, Chen C, Qian Y, Zhao X, Wang Q.|2015|Não|
|3a|Time courses and variability of pyrethroid biomarkers of exposure in a<br>group of agricultural workers in Quebec|Ratelle M, CÃ´tÃ© J, Bouchard M.|2016|Sim|  
92  
|3a|The toxicity of a ternary biocide mixture to two consecutive earthworm<br>(Eisenia fetida) Generations.|Schnug L, Jakob L, Hartnik T.|2013|Não|
|---|---|---|---|---|
|3a|Toxicokinetics of permethrin biomarkers of exposure in orally exposed<br>volunteers.|Ratelle M, CÃ´tÃ© J, Bouchard M.|2015|Sim|
|3a|Treatment of Scabies: Comparison of Lindane 1% vs Permethrin 5.|Rezaee E, Goldust M, Alipour H.|2015|Não|
|3a|The use of growth and behavioral endpoints to assess the effects of<br>pesticide mixtures upon aquatic organisms.|Hasenbein S, Lawler SP, Geist J, Connon RE.|2015|Não|
|3a|Variation in susceptibility of laboratory and field strains of three stored-<br>grain insect species to Î²-cyfluthrin and chlorpyrifos-methyl plus<br>deltamethrin applied to concrete surfaces.|Sehgal B, Subramanyam B, Arthur FH, Gill BS.|2014|Não|  
**Quadro V.3.7.** Artigos resultantes da busca sistemática no site **Cochrane** , para as perguntas PICO sobre gravidade para intoxicações por produtos contendo piretroides  
**Busca - pergunta PICO Diagnóstico (8 resultados)**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|**Busca**|**Titulo**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|---|
|3b|Treatment of Scabies: comparison of Lindane 1% vs||||
||Permethrin|Rezaee E,  Goldust M,  Alipour H.|2015|Não|
|3b|To assess whether addition of pyriproxyfen to long-lasting||||
||insecticidal mosquito nets increases their durability|N, Sagnon and M, Pinder and EF, Tchicaya and|||
||compared to standard long-lasting insecticidal mosquito nets:|<br>AB, Tiono and B, Faragher and H, Ranson and|||
||study protocol for a randomised controlled trial|SW, Lindsay|2015|Não|  
93  
|3b|A field trial of a fixed combination of permethrin and fipronil|MK, Chatzis and D, Psemmas and E,<br>Papadopoulos and C, Navarro and MN,<br>Saridomichelakis|2017|Não|
|---|---|---|---|---|
|3b|A randomised, assessor blind, parallel group comparative<br>efficacy trial of three products for the treatment of head lice<br>in children--melaleuca oil and lavender oil, pyrethrins and<br>piperonyl butoxide, and a ""suffocation"" product"|SC, Barker and PM, Altman|2010|Não|
|3b|Tocopheryl acetate 20% spray for elimination of head louse<br>infestation: a randomised controlled trial comparing with 1%||||
||permethrin creme rinse|IF, Burgess and NA, Burgess and ER, Brunton|2013|Não|
|3b|Safety of insecticide-treated mosquito nets for infants and<br>their mothers: randomized controlled community trial in<br>Burkina Faso|Lu G, Traoré C, Meissner P, Kouyaté B, Kynast-<br>Wolf G, Beiersmann C, Coulibaly B, Becher H,<br>Müller O.|2015|Sim|
|3b|Efficacy and Safety of a Mineral Oil-Based Head Lice<br>Shampoo: a Randomized, Controlled, Investigator-Blinded,|L, Wolf and F, Eertmans and D, Wolf and B,|||
||Comparative Study|Rossel and E, Adriaens|2016|Não|  
**Quadro V.3.8.** Artigos resultantes da busca sistemática no site **pubmed** , para as perguntas PICO sobre tratamento para intoxicações por produtos contendo piretroides

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|**Busca**|<br>Titulo|Autor|Ano|**Estudo**<br>**considerado**|
|---|---|---|---|---|
|4a|Field evaluation of personal protection methods against outdoor-biting|Tangena JA, Thammavong P, Chonephetsarath S,|2018|<sup>Não</sup>|
||mosquitoes in Lao PDR.,|Logan JG, Brey PT, Lindsay SW.|||  
94  
|4a|Why some sites are responding better to anti-malarial interventions? A<br>case study from western Kenya.,|Kapesa A, Kweka EJ, Atieli H, Kamugisha E, Zhou G,<br>Githeko AK, Yan G.|2017|<sup>Não</sup>|
|---|---|---|---|---|
|4a|Residual Effectiveness of Permethrin-Treated Clothing for Prevention of<br>Mosquito Bites Under Simulated Conditions.,|Richards SL, Balanay JAG, Harris JW, Banks VM,<br>Meshnick S.|2017|<sup>Não</sup>|
|4a|Eave tubes for malaria control in Africa: prototyping and evaluation against<br>Anopheles gambiae s.s. and Anopheles arabiensis under semi-field<br>conditions in western Kenya.,|Snetselaar J, Njiru BN, Gachie B, Owigo P,<br>Andriessen R, Glunt K, Osinga AJ, Mutunga J,<br>Farenhorst M, Knols BGJ.|2017|Não|
|4a|Pesticide poisoning in Chitwan, Nepal: a descriptive epidemiological study.,|Gyenwali D, Vaidya A, Tiwari S, Khatiwada P,<br>Lamsal DR, Giri S.|2017|<sup>Não</sup>|
|4a|Seizures in patients with acute pesticide intoxication, with a focus on<br>glufosinate ammonium.,|Park S, Kim DE, Park SY, Gil HW, Hong SY.|2018|<sup>Não</sup>|
|4a|A low technology emanator treated with the volatile pyrethroid<br>transfluthrin confers long term protection against outdoor biting vectors of<br>lymphatic filariasis, arboviruses and malaria.,|Ogoma SB, Mmando AS, Swai JK, Horstmann S,<br>Malone D, Killeen GF.|2017|Não|
|4a|Insect Repellants During Pregnancy in the Era of the Zika Virus.,|Wylie BJ, Hauptman M, Woolf AD, Goldman RH.|2016|Não|
|4a|Biting back.,|Enserink M, Roberts L.|2016|Não|
|4a|Itch Management in Childhood.,|FÃ¶lster-Holst R.|2016|Não|
|4a|Effectiveness of Residential Acaricides to Prevent Lyme and Other Tick-<br>borne Diseases in Humans.,|Hinckley AF, Meek JI, Ray JA, Niesobecki SA,<br>Connally NP, Feldman KA, Jones EH, Backenson<br>PB, White JL, Lukacik G, Kay AB, Miranda WP,<br>Mead PS.|2016|Não|
|4a|Bioactivity and laundering resistance of five commercially available, factory-<br>treated permethrin-impregnated fabrics for the prevention of mosquito-<br>borne diseases: the need for a standardized testing and licensing<br>procedure.,|Faulde MK, Pages F, Uedelhoven W.|2016|Não|
|4a|Long-Lasting Permethrin-Impregnated Clothing Protects Against Mosquito<br>Bites in Outdoor Workers.,|Londono-Renteria B, Patel JC, Vaughn M,<br>Funkhauser S, Ponnusamy L, Grippin C, Jameson|2015|<sup>Não</sup>|  
95  
|||SB, Apperson C, Mores CN, Wesson DM, Colpitts<br>TM, Meshnick SR.|||
|---|---|---|---|---|
|4a|Impact of Malaria Vector Control Interventions at the Beginning of a<br>Malaria Elimination Stage in a Dominant Area of Anopheles<br>anthropophagus, Hubei Province, China.,|Li KJ, Cai SX, Lin W, Xia J, Pi Q, Hu LQ, Huang GQ,<br>Pei SJ, Zhang HX.|2015|Não|
|4a|Biomonitoring and evaluation of permethrin uptake in forestry workers<br>using permethrin-treated tick-proof pants.,|Rossbach B, Kegel P, SÃ¼ÃŸ H, Letzel S.|2016|<sup>Não</sup>|
|4a|Pilot study assessing the effectiveness of factory-treated, long-lasting<br>permethrin-impregnated clothing for the prevention of tick bites during<br>occupational tick exposure in highly infested military training areas,<br>Germany.,|Faulde MK, Rutenfranz M, Keth A, Hepke J, Rogge<br>M, GÃ¶rner A.|2015|Não|
|4a|Assessment of occupational exposure to malathion and bifenthrin in<br>mosquito control sprayers through dermal contact.,|Kongtip P, Sasrisuk S, Preklang S, Yoosook W,<br>Sujirarat D.|2013|<sup>Não</sup>|
|4a|Organophosphate-pyrethroid combination pesticides may be associated<br>with increased toxicity in human poisoning compared to either pesticide<br>alone.,|Iyyadurai R, Peter JV, Immanuel S, Begum A,<br>Zachariah A, Jasmine S, Abhilash KP.|2014|Não|
|4a|Long-lasting permethrin impregnated uniforms: A randomized-controlled<br>trial for tick bite prevention.,|Vaughn MF, Funkhouser SW, Lin FC, Fine J, Juliano<br>JJ, Apperson CS, Meshnick SR.|2014|<sup>Não</sup>|
|4a|Tick repellents for human use: prevention of tick bites and tick-borne<br>diseases.,|Pages F, Dautel H, Duvallet G, Kahl O, de Gentile L,<br>Boulanger N.|2014|<sup>Não</sup>|
|4a|Ultra low concentration deltamethrin loaded patch development and<br>evaluation of its repellency against dengue vector Aedes (S) albopictus.,|Chattopadhyay P, Dhiman S, Devi K, Banerjee S,<br>Rabha B, Chaurasia A, Veer V.|2013|<sup>Não</sup>|
|4a|Pyrethroid ingestion-induced status epilepticus in a young woman.,|Margekar SL, Singh N, Margekar VG, Trikha S.|2013|Não|
|4a|Efficacy and duration of three residual insecticides on cotton duck and vinyl<br>tent surfaces for control of the sand fly Phlebotomus papatasi (Diptera:<br>Psychodidae).,|Zayed AB, Hoel DF, Tageldin RA, Fawaz EY, Furman<br>BD, Hogsette JA, Bernier UR.|2013|Não|  
96  
|4a|Accidental occupational exposure to phytosanitary products: experience of<br>the Poison Control Center in Marseille from 2008 to 2010.,|Aras M, Schmitt C, Glaizal M, KervÃ©gant M,<br>Tichadou L, de Haro L.|2013|Sim|
|---|---|---|---|---|
|4a|Challenges for malaria elimination in Zanzibar: pyrethroid resistance in<br>malaria vectors and poor performance of long-lasting insecticide nets.,|Haji KA, Khatib BO, Smith S, Ali AS, Devine GJ,<br>Coetzee M, Majambere S.|2013|<sup>Não</sup>|
|4a|A shift from indoor residual spraying (IRS) with bendiocarb to long-lasting<br>insecticidal (mosquito) nets (LLINs) associated with changes in malaria<br>transmission indicators in pyrethroid resistance areas in Benin.,|OssÃ¨ RA, AÃ¯kpon R, GbÃ©djissi GL, Gnanguenon<br>V, SÃ¨zonlin M, GovoÃ©tchan R, Sovi A, Oussou<br>O, OkÃ©-Agbo F, AkogbÃ©to M.|2013|Não|
|4a|Comparative field evaluation of combinations of long-lasting insecticide<br>treated nets and indoor residual spraying, relative to either method alone,<br>for malaria prevention in an area where the main vector is Anopheles<br>arabiensis.,|Okumu FO, Mbeyela E, Lingamba G, Moore J,<br>Ntamatungiro AJ, Kavishe DR, Kenward MG,<br>Turner E, Lorenz LM, Moore SJ.|2013|Não|
|4a|Impact of cyfluthrin (Solfac EW050) impregnated bed nets on malaria<br>transmission in the city of Mbandjock : lessons for the nationwide<br>distribution of long-lasting insecticidal nets (LLINs) in Cameroon.,|Antonio-Nkondjio C, Demanou M, Etang J,<br>Bouchite B.|2013|Não|
|4a|A systematic review of mosquito coils and passive emanators: defining<br>recommendations for spatial repellency testing methodologies.,|Ogoma SB, Moore SJ, Maia MF.|2012|<sup>Não</sup>|
|4a|The effect of deltamethrin-treated net fencing around cattle enclosures on<br>outdoor-biting mosquitoes in Kumasi, Ghana.,|Maia MF, Abonuusum A, Lorenz LM, Clausen PH,<br>Bauer B, Garms R, Kruppa T.|2012|<sup>Não</sup>|
|4a|Changes in Anopheles funestus biting behavior following universal coverage<br>of long-lasting insecticidal nets in Benin.,|Moiroux N, Gomez MB, Pennetier C, Elanga E,<br>DjÃ¨nontin A, Chandre F, DjÃ¨gbÃ© I, Guis H,<br>Corbel V.|2012|Não|
|4a|Loss of household protection from use of insecticide-treated nets against<br>pyrethroid-resistant mosquitoes, benin.,|Asidi A, N'Guessan R, Akogbeto M, Curtis C,<br>Rowland M.|2012|<sup>Não</sup>|
|4a|Malaria morbidity and pyrethroid resistance after the introduction of<br>insecticide-treated bednets and artemisinin-based combination therapies: a<br>longitudinal study.,|Trape JF, Tall A, Diagne N, Ndiath O, Ly AB, Faye J,<br>Dieye-Ba F, Roucher C, Bouganali C, Badiane A,<br>Sarr FD, Mazenot C, TourÃ©-BaldÃ© A, Raoult D,|2011|Não|  
97  
|||Druilhe P, Mercereau-Puijalon O, Rogier C, Sokhna<br>C.|||
|---|---|---|---|---|
|4a|Improvements in compliance with medical force protection measures by<br>simplification of the anti-malarial chemoprophylaxis regime.,|Sellers EL, Ross DA, Green AD.|2011|<sup>Não</sup>|
|4a|The lethal ovitrap: a response to the resurgence of dengue and<br>chikungunya.,|Zeichner BC, Debboun M.|2011|<sup>Não</sup>|
|4a|Tick bite protection with permethrin-treated summer-weight clothing.,|Miller NJ, Rainone EE, Dyer MC, GonzÃ¡lez ML,<br>Mather TN.|2011|<sup>Não</sup>|
|4a|Pilot study assessing the effectiveness of long-lasting permethrin-<br>impregnated clothing for the prevention of tick bites.,|Vaughn MF, Meshnick SR.|2011|<sup>Não</sup>|
|4a|Failure of interior residual sprays as protection against mosquitoes in<br>military-issued two-man tents.,|Morrow MG, Johnson RN, Polanco J, Claborn DM.|2010|<sup>Não</sup>|
|4a|Analysis of Anopheles arabiensis blood feeding behavior in southern<br>Zambia during the two years after introduction of insecticide-treated bed<br>nets.,|Fornadel CM, Norris LC, Glass GE, Norris DE.|2010|Não|
|4a|Sclerodermus domesticus infestation: an occupational disease in<br>antiquarians and restorers.,|Veraldi S, Maria Serini S, Violetti SA.|2010|<sup>Não</sup>|
|4a|Fatal intoxication with hydrocarbons in deltamethrin preparation.,|Magdalan J, Zawadzki M, Merwid-Lad A.|2009|Não|
|4a|Managing Rocky Mountain spotted fever.,|Minniear TD, Buckingham SC.|2009|Não|
|4a|Comparative study of kala-azar vector control measures in eastern Nepal.,|Das ML, Roy L, Rijal S, Paudel IS, Picado A, Kroeger<br>A, Petzold M, Davies C, Boelaert M.|2010|<sup>Não</sup>|
|4a|Wash-resistance and field efficacy of Olyset net, a permethrin-incorporated<br>long-lasting insecticidal netting, against Anopheles minimus-transmitted<br>malaria in Assam, Northeastern India.,|Dev V, Raghavendra K, Barman K, Phookan S, Dash<br>AP.|2010|Não|  
98  
|4a|Managing insecticide resistance in malaria vectors by combining<br>carbamate-treated plastic wall sheeting and pyrethroid-treated bed nets.,|DjÃ¨nontin A, Chabi J, Baldet T, Irish S, Pennetier<br>C, Hougard JM, Corbel V, AkogbÃ©to M, Chandre<br>F.|2009|Não|
|---|---|---|---|---|
|4a|Evaluation of PermaNet 2.0 mosquito bednets against mosquitoes,<br>including Anopheles minimus s.l., in India.,|Prakash A, Bhattacharyya DR, Mohapatra PK,<br>Gogoi P, Sarma DK, Bhattacharjee K, Mahanta J.|2009|<sup>Não</sup>|
|4a|Application of the industrial hygiene hierarchy of controls to prioritize and<br>promote safer methods of pest control: a case study.,|Weinberg JL, Bunin LJ, Das R.|2009|<sup>Não</sup>|
|4a|Efficacy of topical permethrin as repellent against Aedes aegypti's bites.,|Miot HA, Ferreira DP, Mendes FG, Carrenho FR, de<br>Oliveira Amui I, Carneiro CA, Madeira NG.|2008|<sup>Não</sup>|
|4a|Impact of urban agriculture on malaria vectors in Accra, Ghana.,|Klinkenberg E, McCall P, Wilson MD, Amerasinghe<br>FP, Donnelly MJ.|2008|<sup>Não</sup>|
|4a|Chemical defense against blood-feeding arthropods by disruption of biting<br>behavior.,|Debboun M, Klun JA.|2008|<sup>Não</sup>|
|4a|An experimental hut evaluation of Olyset nets against anopheline<br>mosquitoes after seven years use in Tanzanian villages.,|Malima RC, Magesa SM, Tungu PK, Mwingira V,<br>Magogo FS, Sudi W, Mosha FW, Curtis CF, Maxwell<br>C, Rowland M.|2008|Não|
|4a|Insect repellents: historical perspectives and new developments.,|Katz TM, Miller JH, Hebert AA.|2008|Não|
|4a|DEET microencapsulation: a slow-release formulation enhancing the<br>residual efficacy of bed nets against malaria vectors.,|N'guessan R, Knols BG, Pennetier C, Rowland M.|2008|<sup>Não</sup>|
|4a|Pyrethrin and pyrethroid exposures in the United States: a longitudinal<br>analysis of incidents reported to poison centers.,|Power LE, Sudakin DL.|2007|Sim|
|4a|Comparative field evaluation of residual-sprayed deltamethrin WG and<br>deltamethrin WP for the control of malaria in Pahang, Malaysia.,|Rohani A, Zamree I, Lim LH, Rahini H, David L,<br>Kamilan D.|2006|<sup>Não</sup>|
|4a|Acaricidal and repellent properties of permethrin, its role in reducing<br>transmission of vector-borne pathogens.,|Mencke N.|2006|<sup>Não</sup>|  
99  
|4a|A mixture of organophosphate and pyrethroid intoxication requiring<br>intensive care unit admission: a diagnostic dilemma and therapeutic<br>approach.,|Tripathi M, Pandey R, Ambesh SP, Pandey M.|2006|Não|
|---|---|---|---|---|
|4a|Multiple pruritic papules from lone star tick larvae bites.,|Fisher EJ, Mo J, Lucky AW.|2006|Não|
|4a|A reassessment of the neurotoxicity of pyrethroid insecticides.,|Ray DE, Fry JR.|2006|Não|
|4a|Poisoning due to pyrethrins.,|Proudfoot AT.|2005|Não repetido|
|4a|Poisoning due to pyrethroids.,|Bradberry SM, Cage SA, Proudfoot AT, Vale JA.|2005|Sim|
|4a|Injection of pyrethroids without significant sequelae.,|LoVecchio F, Knight J.|2005|Não|
|4a|Passive prophylaxis with permethrin-treated tents reduces mosquito bites<br>among North American summer campers.,|Boulware DR, Beisang AA 3rd.|2005|<sup>Não</sup>|
|4a|Repellency of permethrin-treated battle-dress uniforms during Operation<br>Tandem Thrust 2001.,|Miller RJ, Wing J, Cope SE, Klavons JA, Kline DL.|2004|<sup>Não</sup>|
|4a|Mosquito coil (Allethrin) poisoining in two brothers.,|Garg P, Garg P.|2004|Não|
|4a|Medical pearl: permethrin can prevent arthropod bites and stings.,|Elgart ML.|2004|Não|
|4a|Measuring the efficacy of insecticide treated bednets: the use of DNA<br>fingerprinting to increase the accuracy of personal protection estimates in<br>Tanzania.,|Soremekun S, Maxwell C, Zuwakuu M, Chen C,<br>Michael E, Curtis C.|2004|Não|
|4a|Experimental hut comparisons of nets treated with carbamate or<br>pyrethroid insecticides, washed or unwashed, against pyrethroid-resistant<br>mosquitoes.,|Asidi AN, N'Guessan R, Hutchinson RA, TraorÃ©-<br>Lamizana M, Carnevale P, Curtis CF.|2004|Não|
|4a|Acute upper-airway obstruction in a two-year-old child who ingested an<br>herbicide preparation.,|Bradley KG, Cox RD.|2004|<sup>Não</sup>|
|4a|Repellent efficacy of a combination containing imidacloprid and permethrin<br>against sand flies (Phlebotomus papatasi) in dogs.,|Mencke N, Volf P, Volfova V, Stanneck D.|2003|<sup>Não</sup>|
|4a|Integrated control of vector-borne diseases of livestock--pyrethroids:<br>panacea or poison?,|Eisler MC, Torr SJ, Coleman PG, Machila N, Morton<br>JF.|2003|<sup>Não</sup>|  
100  
|4a|Is it scabies? How to tell.,|Lafuente CR.|2003|Não|
|---|---|---|---|---|
|4a|Longitudinal evaluation of an educational intervention for preventing tick<br>bites in an area with endemic lyme disease in Baltimore County, Maryland.,|Malouin R, Winch P, Leontsini E, Glass G, Simon D,<br>Hayes EB, Schwartz BS.|2003|<sup>Não</sup>|
|4a|Survey of personal protection measures against mosquitoes among<br>Australian defense force personnel deployed to East Timor.,|Frances SP, Auliff AM, Edstein MD, Cooper RD.|2003|<sup>Não</sup>|
|4a|Do insecticide-treated bednets have an effect on malaria vectors?,|Takken W.|2002|Não|
|4a|Insect repellents and mosquito bites.,|Adams DR, Anderson BE, Ammirati CT.|2002|Não|
|4a|Comparison of three pyrethroid treatments of top-sheets for malaria<br>control in emergencies: entomological and user acceptance studies in an<br>Afghan refugee camp in Pakistan.,|Graham K, Mohammad N, Rehman H, Farhan M,<br>Kamal M, Rowland M.|2002|Não|
|4a|Topical insecticide treatments to protect dogs from sand fly vectors of<br>leishmaniasis.,|Reithinger R, Teodoro U, Davies CR.|2001|<sup>Não</sup>|
|4a|Deltamethrin treated bednets for control of malaria transmitted by<br>Anopheles culicifacies (Diptera: Culicidae) in India.,|Yadav RS, Sampath RR, Sharma VP.|2001|<sup>Não</sup>|
|4a|Diversion of Anopheles gambiae from children to other hosts following<br>exposure to permethrin-treated bednets.,|QuiÃ±ones ML, Drakeley CJ, MÃ¼ller O, Lines JD,<br>Haywood M, Greenwood BM.|2000|<sup>Não</sup>|
|4a|Management of pyrethroid exposure.,|Bateman DN.|2000|Sim|
|4a|Pyrethroid insecticides: poisoning syndromes, synergies, and therapy.,|Ray DE, Forshaw PJ.|2000|Sim|
|4a|Organic insecticides.,|Peter JV, Cherian AM.|2000|Não|
|4a|The effect of delivery mechanisms on the uptake of bed net re-<br>impregnation in Kilifi District, Kenya.,|Snow RW, McCabe E, Mbogo CN, Molyneux CS,<br>Some ES, Mung'ala VO, Nevill CG.|1999|<sup>Não</sup>|
|4a|Cyfluthrin (EW 050)-impregnated bednets in a malaria control program in<br>Ghassreghand (Baluchistan, Iran).,|Zaim M, Ghavami MB, Nazari M, Edrissian GH,<br>Nateghpour M.|1998|<sup>Não</sup>|
|4a|Possibilities of long-term protection against blood-sucking insects and<br>ticks.,|KocisovÃ¡ A, Para L.|1999|<sup>Não</sup>|  
101  
|4a|Plant products used as mosquito repellents in Guinea Bissau, West Africa.,|PÃ¥lsson K, Jaenson TG.|1999|Não|
|---|---|---|---|---|
|4a|Permethrin emulsion ingestion: clinical manifestations and clearance of<br>isomers.,|Gotoh Y, Kawakami M, Matsumoto N, Okada Y.|1998|Sim|
|4a|Insect repellents. What really works?,|Mafong EA, Kaplan LA.|1997|Não|
|4a|Insect repellents: an overview.,|Brown M, Hebert AA.|1997|Não|
|4a|Potentially toxic self-treatment of uremic pruritus with topical pyrethroid<br>insecticides.,|Robertson KE, Mueller BA.|1997|Sim|
|4a|The impact of permethrin-impregnated bednets on malaria vectors of the<br>Kenyan coast.,|Mbogo CN, Baya NM, Ofulla AV, Githure JI, Snow<br>RW.|1996|<sup>Não</sup>|
|4a|Insecticide-impregnated bed nets for malaria control: varying experiences<br>from Ecuador, Colombia, and Peru concerning acceptability and<br>effectiveness.,|Kroeger A, Mancheno M, Alarcon J, Pesse K.|1995|Não|
|4a|Impact of deltamethrin-impregnated bednets on biting rates of mosquitoes<br>in Zaire.,|Karch S, Asidi N, Manzambi Z, Salaun JJ, Mouchet<br>J.|1995|<sup>Não</sup>|
|4a|Laboratory and field evaluations of a repellent soap containing diethyl<br>toluamide (DEET) and permethrin against phlebotomine sand flies (Diptera:<br>Psychodidae) in Valle del Cauca, Colombia.,|Alexander B, Cadena H, Usma MC, Rojas CA.|1995|Não|
|4a|Synthetic pyrethroids.,|He F.|1994|Não|
|4a|Fatality associated with inhalation of a pyrethrin shampoo.,|Wax PM, Hoffman RS.|1994|Não|
|4a|Efficacy of Esbiothrin mosquito coils at community level in northern<br>Tanzania.,|Mosha FW, Njau RJ, Alfred J.|1992|<sup>Não</sup>|
|4a|Various pyrethroids on bednets and curtains.,|Curtis CF, Myamba J, Wilkes TJ.|1992|Não|
|4a|Efficacy of insecticide impregnated bed-nets to control malaria in a rural<br>forested area in southern Cameroon.,|Le Goff G, Robert V, Fondjo E, Carnevale P.|1992|<sup>Não</sup>|
|4a|Permethrin and dimethyl phthalate as tent fabric treatments against Aedes<br>aegypti.,|Schreck CE.|1991|<sup>Não</sup>|  
102  
|4a|Field efficacy of|/pubmed/1664850||Não|
|---|---|---|---|---|
|4a|Pyrethroid-treated bednet effects on mosquitoes of the Anopheles<br>gambiae complex in The Gambia.,|Lindsay SW, Adiamah JH, Miller JE, Armstrong JR.|1991|<sup>Não</sup>|
|4a|Levels of exposure and biological monitoring of pyrethroids in spraymen.,|Zhang ZW, Sun JX, Chen SY, Wu YQ, He FS.|1991|Não|
|4a|Influence of deltamethrin treatment of bed nets on malaria transmission in<br>the Kou valley, Burkina Faso.,|Robert V, Carnevale P.|1991|<sup>Não</sup>|
|4a|Relative repellency of two formulations of N,N-diethyl-3-methylbenzamide<br>(deet) and permethrin-treated clothing against Culex sitiens and Aedes<br>vigilax in Thailand.,|Harbach RE, Tang DB, Wirtz RA, Gingrich JB.|1990|Não|
|4a|Use of an electrostatic sprayer for control of anopheline mosquitoes.,|Chadd EM.|1990|Não|
|4a|An assessment of the toxicological properties of pyrethroids and their<br>neurotoxicity.,|Aldridge WN.|1990|<sup>Não</sup>|
|4a|Permethrin-impregnated bednets: behavioural and killing effects on<br>mosquitoes.,|Hossain MI, Curtis CF.|1989|<sup>Não</sup>|
|4a|Efficacy of mosquito nets treated with permethrin in Suriname.,|Rozendaal JA, Voorham J, Van Hoof JP, Oostburg<br>BF.|1989|<sup>Não</sup>|
|4a|Impact of permethrin-treated bednets on malaria transmission by the<br>Anopheles gambiae complex in The Gambia.,|Lindsay SW, Snow RW, Broomfield GL, Janneh MS,<br>Wirtz RA, Greenwood BM.|1989|<sup>Não</sup>|
|4a|Repellents and other personal protection strategies against Aedes<br>albopictus.,|Schreck CE, McGovern TP.|1989|<sup>Não</sup>|
|4a|Effects of weathering on fabrics treated with permethrin for protection<br>against mosquitoes.,|Gupta RK, Rutledge LC, Reifenrath WG, Gutierrez<br>GA, Korte DW Jr.|1989|<sup>Não</sup>|
|4a|Evaluations of permethrin-impregnated clothing and three topical repellent<br>formulations of deet against tsetse flies in Zambia.,|Sholdt LL, Schreck CE, Mwangelwa MI, Nondo J,<br>Siachinji VJ.|1989|<sup>Não</sup>|  
103  
|4a|Personal protection afforded by controlled-release topical repellents and<br>permethrin-treated clothing against natural populations of Aedes<br>taeniorhynchus.,|Schreck CE, Kline DL.|1989|Não|
|---|---|---|---|---|
|4a|Field bioassays of permethrin-treated uniforms and a new extended<br>duration repellent against mosquitoes in Pakistan.,|Sholdt LL, Schreck CE, Qureshi A, Mammino S, Aziz<br>A, Iqbal M.|1988|<sup>Não</sup>|
|4a|Pyrethrin poisoning from commercial-strength flea and tick spray.,|Paton DL, Walker JS.|1988|Não|
|4a|Effectiveness of soap formulations containing deet and permethrin as<br>personal protection against outdoor mosquitoes in Malaysia.,|Yap HH.|1986|<sup>Não</sup>|
|4a|The effectiveness of permethrin and deet, alone or in combination, for<br>protection against Aedes taeniorhynchus.,|Schreck CE, Haile DG, Kline DL.|1984|<sup>Não</sup>|
|4a|Pressurized sprays of permethrin and deet on clothing for personal<br>protection against the lone star tick and the American dog tick (Acari:<br>Ixodidae).,|Mount GA, Snoddy EL.|1983|Não|
|4a|Evaluation of personal protection methods against phlebotomine sand flies<br>including vectors of leishmaniasis in Panama.,|Schreck CE, Kline DL, Chaniotis BN, Wilkinson N,<br>McGovern TP, Weidhaas DE.|1982|<sup>Não</sup>|
|4a|Pressurized sprays of permethrin and deet on clothing for personal<br>protection against the lone star tick and the American dog tick (Acari:<br>Ixodidae).,|Mount GA, Snoddy EL.|1983|Não|
|4a|Evaluation of personal protection methods against phlebotomine sand flies<br>including vectors of leishmaniasis in Panama.,|Schreck CE, Kline DL, Chaniotis BN, Wilkinson N,<br>McGovern TP, Weidhaas DE.|1982|Não|  
104

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.3** -->
|Busca|<br>Título|Autores|Ano|Estudo<br>considerado|
|---|---|---|---|---|
|4b|Pediculosis hasta 2008/ Pediculosis until 2008|Salduna, María Dolores; Ruiz Lascano, Alejandro|2008|Não|
|4b|Ectoparasitosis/ Ectoparasitoses|Viovy A., Alejandro|1999|Não|
|4b|Pediculosis Capitis/ Pediculosis Capitis|Pierini, A. M; Manterola, A|1996|Não|
|4b|El aumento de la sarna y su tratamiento/ The increase of the<br>scabies and its treatment|Achenbach, Ricardo E|1995|Não|
|4b|Tratamiento de la pediculosis capitis en niños con permetrina al 1<br>por ciento en champú o loción/ Treatment of pediculosis capitis in<br>children with 1 percent permethrin shampoo or lotion|Schenone Fernández, Hugo; Wiedmaier, Gonzalo; Contreras,<br>Lidia|1994|Não|
||Actualización del tratamiento de la sarna/ Update in the treatment||||
|4b|of scabies|Benavides Yanulaque, María Isabel; Moncada Hue, Ximena|1991|Não|
||Profilaxis y tratamiento de pediculosis con cuasia amarga/||||
|4b|Prophylaxis and treatment of the pediculosis with quassia amara|Ninci, Marcelo E|1991|Não|
||Medicamentos ectoparasiticidas: risco e benefício/||||
|4b|Ectoparasiticides drugs: risk and benefit|Rahde, Alberto Furtado; Salvi, Rosane M|1987|Não disponivel|
||Deltametrina no tratamento das ectoparasitoses: estudo<br>multicêntrico realizado a nível nacional/ Deltametrin in the<br>treatment of ectoparasitosis: multicenter study performed at||||
|4b|national level|Waisman, Jaime, coord|1986|Não|
|4b|Tratamiento de la sarna con loción dermatológica de decametrina<br>al 0,02% estudio en 127 pacientes mediante la utilización de dos|Schenone, Hugo; Prieto, Rafael; Lobos, Margarita; Fabres,<br>Pamela; Beresi, Rebeca|1986|Não|  
105  
||esquemas terapéuticos/ Treatment of scabies with a|||
|---|---|---|---|
||dermatological lotion of decamethrin at 0,02%: study in 127|||
||patients by the use of 2 therapeutic regimens|||
||Avaliaçäo clínica do uso da decametrina no tratamento da<br>pediculose do couro cabeludo/ Clinical evaluation of the use of|||
|4b|decamethrin in the treatment of pediculosis of the scalp|Sasaki, Newton Mamoru; Cortez, José Rubens Barbosa|1985 Não|  
106

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.4 – Avaliação De Recomendações Por Grade** -->
**QUADRO V.4.1** – Tabela com o detalhamento da avaliação do Grupo Elaborador das recomendações para a “Abordagem ao Paciente Intoxicado por produtos formulados com piretróides”  
|**PERGUNTA: Qu**|**ais são os testes auxiliam no aco**|**mpanhamento do paciente com suspeita de intoxicação por 2,4D e seus derivados**|**?**|
|---|---|---|---|
|**P**População int|oxicada por produtos formulados|contendo piretroides||
|**I**Testes labora<br>tóxicos. )|toriais (Monitoramento dos níveis|de bicarbonato (HCO3<sup>-</sup>) de pacientes com histórico de ingestão de formulações con|tendo solventes|
|**C**Ausência da i|ntervenção|||
|**O**Mortalidade|e Tempo de internação|||
|**S**Relatos de ca|so e Cohort retrospectiva|||
||**Julgamento**|**Evidências**|**Considerações**<br>**adicionais**|
|**Benefícios e**<br>**riscos**|**Qual a qualidade da Evidência**<br>☐Sem estudos<br>☒Muito baixa<br>☐Baixa<br>☐Moderada<br>☐Alta|Em um total de 56 pacientes, 54 foram expostos intencionalmente, por via oral,<br>a formulações contendo piretroides (96,4%). Na gasometria arterial, o pH<br>mediano arterial, as dosagens de bicarbonato e lactato sérico foram,<br>respectivamente, 7,38 (IQR 7,33–7,42), 19,6 (IQR 17,7– 21,9) mmol / L e 3,67<br>(IQR 2,38-5,54) mmol / L. O tempo médio de internação foi de 2 dias (0-4,8) e a<br>mortalidade estimada em 3,6% (n=2) (CHA et al., 2014b).<br>Paciente vítima de uma exposição oral a 20 mL de uma formulação contendo<br>1,6% de praletrina e 5% de butóxido de piperonil, apesar de estável nas<br>primeiras 24h, desenvolveu um quadro de acidose metabólica aguda (pH 7,21<br>e [HCO3<sup>-</sup>]= 15 mEq/L), com hiato iônico normal. Concomitantemente ela<br>apresentou um quadro de parada sinusal com alteração do ritmo juncional.<br>Após receber a infusão de 250 meq de bicarbonato de sódio (7,5%) por um<br>período de 12h, a sua condição normalizou (pH 7,34 e [HCO3<sup>-</sup>]= 22||  
107  
|||mEq/L)(BHASKAR et al., 2010).|
|---|---|---|
|||Paciente de 27 anos sem antecedentes patológicos, encaminhado ao serviço de<br>emergência, 10 h após a ingestão intencional de uma quantidade desconhecida<br>de cipermetrina (10%). Além da leucocitose (13.000 / mm<sup>3</sup>) e da elevação da<br>creatinina (24 mg / L), desenvolveu um quadro de acidose metabólica (pH = 7,15<br>e [HCO3<sup>-</sup>] = 12 mEq / L e hiato iônico = 32mEq / L). Apesar da tentativa de infusão<br>de solução de bicarbonato a 4,2%, o indivíduo foi a óbito após 12 horas de<br>internação com choque refratário (AISSAOUI et al., 2013).|
||**Há balanço entre os**<br>**riscos e benefícios**||
||`☐`Benefícios sobrepõem os<br>riscos<br>`☐`Há equilíbrio entre riscos<br>e benefícios<br>`☐`Riscos sobrepõem os<br>benefícios||
|**Valores  e**<br>**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito||  
108  
||Os custos associados à<br>intervenção são pequenos?|
|---|---|
|**Custos**|`☐`Não<br>`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☐`Sim<br>`☐`Há variabilidade|
|**Aceitabilidade**|**A opção é aceitável para**<br>**as principais partes**<br>**interessadas?**<br>`☐`Não<br>`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☐`Sim|
||`☐`Há variabilidade|  
109  
<!-- Start of picture text -->
A opção é viável para<br>implementar?<br>☐ Não<br>☐ Provavelmente não<br>☐ Incerto<br>☐ Provavelmente sim<br>☐ Sim<br>☐ Há variabilidade<br>Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação condicional/fraca  Recomendação condicional a  Recomendação forte<br>contra a intervenção  contra a intervenção  favor da intervenção  a favor da<br>intervenção<br>☐ ☐ ☐ ☐<br>Ao longo das primeiras 36 horas da admissão, monitore os níveis de bicarbonato (HCO3 - ) de pacientes com histórico de<br>Recomendação<br>ingestão de formulações contendo solventes tóxicos.<br>Justificativa<br>Considerações subgrupo<br>Considerações<br>implementação<br>Monitoramento e avaliação<br>Viabilidade<br><!-- End of picture text -->  
110  
**Prioridades de pesquisa**  
|**QUADRO**<br>produtos<br>**PERGU**<br>**P**Popul<br>**I**Métod<br>**C**Ausê<br>**O**Morta<br>**S**Relat|**III.3.2**– Tabela com o detalhamento da avaliação co<br>formulados com 2,4 D e seus derivados<br>**NTA: Quais são os métodos de eliminação efe**<br>ação intoxicadaporprodutos formulados com 2,4<br>os de eliminação(alcalinização urinária)<br>ncia da intervenção<br>lidade e tempo de internação<br>os de Caso<br>|nsensual do Grupo Elaborador das recomendações para<br>**tivos na intoxicaçãopor 2,4 D e seus derivados?**<br>D e seus derivados<br>|o tratamento de intoxicações por<br> <br>|
|---|---|---|---|
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta<br>**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☒`Há equilíbrio entre riscos e benefícios|||  
111  
||`☐`Riscos sobrepõem os benefícios|
|---|---|
|**Valores  e**<br>**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito|
||Os custos associados à intervenção são<br>pequenos?|
|**Custos**|`☐`Não<br>`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☐`Sim<br>`☐`Há variabilidade|  
112  
<!-- Start of picture text -->
A opção é aceitável para as principais<br>partes interessadas?<br>☐ Não<br>☒ Provavelmente não<br>☐ Incerto<br>☐ Provavelmente sim<br>☐ Sim<br>☐ Há variabilidade<br>A opção é viável para implementar?<br>☐ Não<br>☒ Provavelmente não<br>☐ Incerto<br>☐ Provavelmente sim<br>☐ Sim<br>☐ Há variabilidade<br>Conclusão<br>Tipo de recomendação  Recomendação forte  Recomendação  Recomendação  Recomendação forte a<br>contra a intervenção  condicional/fraca contra  condicional a favor da  favor da intervenção<br>a intervenção  intervenção<br>☐ ☒ ☐<br>☐<br>Aceitabilidade<br>Viabilidade<br><!-- End of picture text -->  
113  
|**Recomendação**|**Considere a infusão contínua de HCO3 (7.5%) em pacientes vítimas de intoxicação oral, os e que evoluam**<br>**para um quadro de acidose, que apresentam hiato iônico elevado e redução significativa dos níveis**<br>**séricos de bicarbonato.**|
|---|---|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**<br>**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||
|**PERGUNTA: Quais interven**<br>**piretroidesque desenvolvem**|**ções terapêuticas podem ser utilizadas em pacientes intoxicados com produtos formulados com**<br>**acidose metabólica?**|
|**P**População intoxicada com ag<br>**I**Infusão  contínua de solução|rotóxicos inibidores de colinesterase<br>de bicarbonato(7,5%)|
|**C**Ausência da intervenção<br>**O**Redução da mortalidade e te<br>|mpo de internação|
|**S**Clínicos e observacionais||
|**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Be**<br>**nef**<br>**íci**<br>**Qual a qualidade d**|**a Evidência**<br>Paciente vítima de uma exposição oral a 20 mL|  
114  
|☐Sem estudos|de uma formulação contendo 1,6% de praletrina|
|---|---|
|☒Muito baixa (Mortalidade)|e 5% de butóxido de piperonil, apesar de estável|
|☐Baixa|nas primeiras 24h, desenvolveu um quadro de|
|☐Moderada<br>☐Alta|acidose metabólica aguda (pH 7,21 e [HCO3<sup>-</sup>]=<br>15<br>mEq/L),<br>com<br>hiato<br>iônico<br>normal.<br>Concomitantemente ela apresentou um quadro<br>de parada sinusal com alteração do ritmo<br>juncional. Após receber a infusão de 250 meq de<br>bicarbonato de sódio (7,5%) por um período de<br>12h, a sua condição normalizou (pH 7,34 e<br>[HCO3<sup>-</sup>]= 22 mEq/L). Após esse tempo, não se<br>administrou o bicarbonato, havendo uma rápida<br>reversão da acidose e normalização eletrolítica.<br>Ela recebeu alta no sétimo dia de internação,<br>sendo<br>reavaliada<br>após<br>quatro<br>semanas<br>(BHASKAR et al., 2010).)(BHASKAR et al.,<br>2010).|
||Paciente<br>de<br>27<br>anos<br>sem<br>antecedentes<br>patológicos,<br>encaminhado<br>ao<br>serviço<br>de<br>emergência, 10 h após a ingestão intencional de<br>uma quantidade desconhecida de cipermetrina|  
115  
|||(10%). Além da leucocitose (13.000 / mm<sup>3</sup>) e da<br>elevação da creatinina (24 mg / L), desenvolveu<br>um quadro de acidose metabólica (pH = 7,15 e<br>[HCO3<sup>-</sup>] = 12 mEq / L e hiato iônico = 32mEq / L).<br>Apesar da tentativa de infusão de solução de<br>bicarbonato a 4,2%, o indivíduo foi a óbito após<br>12 horas de internação com choque refratário<br>(AISSAOUI et al., 2013).|
|---|---|---|
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito||  
116  
||**Os custos associados à intervenção são**<br>**pequenos?**|
|---|---|
|**Custos**|`☐`Não<br>`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☐`Sim<br>`☐`Há variabilidade|
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|**Aceitabilidade**|`☐`Não<br>`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☐`Sim|
||`☐`Há variabilidade|  
117  
||A opção é viável par|a implementar?||||
|---|---|---|---|---|---|
|**Viabilidade**|`☐`Não<br>`☐`Provavelmente nã<br>`☐`Incerto<br>`☐`Provavelmente si<br>`☐`Sim<br>`☐`Há variabilidade|o<br>m||||
||||**Conclusão**|||
|**Tipo de**|**recomendação**|**Recomendação forte**<br>**contra a intervenção**<br>☐|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**<br>☐|**Recomendação**<br>**condicional a favor da**<br>**intervenção**<br>☐|**Recomendação forte a**<br>**favor da intervenção**<br>☐|
|**Recome**|**ndação**|Nos casos graves de intoxi<br>intuito de favorecer a remo|cação com produtos à base d<br>ção de todos os ingredientes|e 2,4D considere a utilizaçã<br>presentes na formulação.|o de métodos dialíticos no|
|**Justific**|**ativa**|||||
|**Conside**|**rações subgrupo**|||||
|**Conside**<br>**implem**|**rações**<br>**entação**|||||
|**Monitor**|**amento e avaliação**|||||  
118

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.5 - Avaliação pelo método GRADE – Piretroides** -->
#### **Quadro V.5.1.** Avaliação das evidências pelo método GRADE sobre a questão: “ Devem ser monitorados os níveis de bicarbonato de sódio comparado a não monitorar em vítimas de intoxicação intencional por meio da ingestão de formulações á base de piretroides?”  
**Contexto** : Alterações hematológicas e bioquímicas são passíveis de ocorrência em vítimas expostas oralmente a esses produtos. Assim, o estabelecimento de um quadro de acidose metabólica, o qual além da redução dos níveis de bicarbonato, se caracteriza por um aníon GAP pronunciado, e alterações cardíacas podem ser algumas das manifestações observadas, principalmente quando há solventes tóxicos na formulação  
||||**Avaliação da**|**Evidência**|||**№ de p**|**acientes**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**monitorar dos**<br>**níveis de**<br>**bicarbonato de**<br>**sódio**|**não monitorar**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Mortalidad|e||||||||||||
|3<br>Tempo de i|estudo<br>observacional<br>nternação|grave<sup>1,2,3,a</sup>|grave<sup>a,b</sup>|não grave|grave<sup>b</sup>|associação muito forte|3/56 (5.4%)||não estimável||⨁`◯◯◯`<br>MUITO BAIXA|CRÍTICO|  
119  
||||**Avaliação da**|**Evidência**|||**№ de p**|**acientes**|**Efeit**|**o**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**monitorar dos**<br>**níveis de**<br>**bicarbonato de**<br>**sódio**|**não monitorar**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|2|estudo<br>observacional|grave<sup>1,2,a,b</sup>|grave<sup>1,2,a,b</sup>|não grave|não grave|todos os potenciais<br>fatores de confusão<br>sugeririam um efeito<br>espúrio e, mesmo assim,<br>nenhum efeito foi<br>observado.|Em um total de 56 p<br>oral, a formulações<br>pH mediano arteria<br>respectivamente, 7,<br>3,67 (IQR 2,38-5,54)<br>(0-4,8) e a mortalid|acientes, 54 foram ex<br>contendo piretroides<br>l, as dosagens de bicar<br>38 (IQR 7,33–7,42), 19<br>mmol / L. O tempo m<br>ade estimada em 3,6%|postos intencional<br>(96,4%). Na gasom<br>bonato e lactato sé<br>,6 (IQR 17,7– 21,9)<br>édio de internação<br>(n=2) (CHA et al., 2|mente, por via<br>etria arterial, o<br>rico foram,<br>mmol / L e<br>foi de 2 dias<br>014b).|⨁`◯◯◯`<br>MUITO BAIXA|IMPORTANTE|  
**CI:** Confidence interval  
#### <u>Explicação</u>  
a. Os pacientes foram expostos a diferentes compostos/formulações, bem como diferentes dosagens/volumes de agente tóxico  
b. Desenhos distintos de estudo, havendo dois estudos de caso e uma avaliação retrospectiva (observacional)  
#### <u>Bibliografia</u>  
1. BHASKAR, Emmanuel M. et al.. Cardiac conduction disturbance due to prallethrin (pyrethroid) poisoning. . Journal of Medical Toxicology; 2010.  
2. CHA, Yong Sung et al.. Pyrethroid poisoning: features and predictors of atypical presentations. . Emergency Medicine Journal; 2014.  
3. AISSAOUI, Younes et al.. An intoxication can hide another one more serious. Example of a fatal poisoning with ethylene glycol intoxication masked by a pyrethroid insecticide. . The Pan African Medical Journal; 2014.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.6 – Síntese Evidências – Piretroides - Tratamento** -->
**Quadro V.6.1:** Síntese de evidências – capítulo 5 - Tratamento  
|**REFERÊNCIA**|**DELINEAM.**|**PICO**|**DESFECHO**|**TIPO DE**<br>**SINTOMAS/**<br>**ANÁLISES**|**EVIDÊNCIAS DO ARTIGO**|
|---|---|---|---|---|---|
|Göen et al., 2017|Não é escopo||Análise de<br>exposição a||Análise de dieta orgânica e exposição a agrotóxicos.|  
120  
|||agrotóxicos por<br>meio da dieta||O estudo confirma que uma intervenção de dieta orgânica resulta<br>em menor exposição considerável a agrotóxicos organofosforados<br>e piretróides.|
|---|---|---|---|---|
|Khan K, Wozniak SE,<br>Coleman J, Didolkar MS.<br>2016|Não é escopo|||Artigo trata da associação entre agente laranja e câncer|
|Park et al., 2011|Série de Casos|Mortalidade|Testes<br>laboratoriais e<br>descrição de 17<br>casos de ingestão<br>intencional de<br>agrotóxicos|Neste estudo, foi revisado uma série de casos agudos de<br>intoxicação por herbicida análogos à auxina, tratados em hospital<br>na Coreia. Foram incluídos 17 pacientes com intoxicação aguda<br>por ingestão intencional, identificados a partir dos registros<br>médicos do Instituto de Intoxicação por Agrotóxicos do Hospital<br>Soonchunhyang Cheonan (República da Coreia) entre setembro de<br>2006 e maio de 2011.<br>Dos 17 pacientes, 12 pacientes ingeriram o ácido 3,6-dicloro-2-<br>metoxibenzóico (dicamba); 3 pacientes, ido [(3,5,6-tricloro-2-<br>piridinil) oxi] acico (triclopir); 1 paciente, ingeriu complexo de<br>ácido 2-metil-4-clorofenoxiacético (MCPA) e 3-isopropil-1H-2,1,3-<br>benzotiadiazin-4 (3H) -ona-2,2-dióxido (Bentazona); e 1 paciente,<br>ácido (rs)-2- (4-chloro-0-tolyoxy)propionico (mecoprop).<br>**A modalidade de tratamento foi sintomática: a lavagem gástrica**<br>**foi empregada quando o paciente foi internado em até 2 horas**<br>**após a ingestão. Também foi realizada uma sessão de**<br>**hemodiálise (HD) e uma de hemoperfusão (HP), seguida por**<br>**administração intravenosa de líquidos. Respirador e oxigênio**<br>**foram utilizados quando necessário. Quando ocorreu**<br>**insuficiência hepática e renal, foram tratados por cuidados de**<br>**suporte. O uso de diálise eperfusão é umaparte doprotocolo do**|  
121

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 5 | secao: **Anexo V.6 – Síntese Evidências – Piretroides - Tratamento** -->
<mark>Não foi observada relação significativa entre a quantidade de dicamba ingerida e o desfecho clínico</mark>  
<mark>O número de pacientes nos outros grupos foi muito baixo para a análise estatística sobre a ingestão.</mark>  
<mark>Entre 17 pacientes, 1 paciente (caso 17) morreu 36h após a admissão, e 12 pacientes tiveram alta do hospital sem qualquer queixa específica no dia 7, após receber tratamento conservador. Os outros quatro pacientes sofreram algumas complicações e foram tratados por mais de uma semana. O caso 3 ingeriu 300 mL de dicamba, sofreu pneumonia e paralisia do íleo durante a admissão. Este paciente foi tratado com antibióticos e nutrição parenteral e recebeu alta hospitalar no dia 28. O caso 9 chegou à sala de emergência após ingestão de 200 mL de dicamba. Durante a internação, teve infecção relacionada ao cateter e foi administrado cefazolina, tendo alta hospitalar no dia 10. O caso 11 ingeriu 300 mL de dicamba. No teste laboratorial inicial, níveis anormalmente elevados de aminotransferase (AST, 235 UI / L; ALT, 169 UI / L) e anticorpo anti-Hepatite C (anti-HCV) positivo foram relatados. O caso 12 mostrou hematúria microscópica na urinálise, mas recebeu alta hospitalar no dia 8.</mark>  
<mark>O caso fatal 17 era um indivíduo alcóolatra e ele foi levado ao pronto-socorro em estado de intoxicação alcoólica e por mecoprop (havia frasco vazio ao lado do corpo, de volume 500mL). As características clínicas na admissão foram inconsciência, hipotensão, insuficiência respiratória e</mark>  
122  
<mark>rabdomiólise. As concentrações séricas de álcool e ácido lático foram de 172 mg/dL (referência normal: 0-10 mg/dL) e 51,6 mg/dL (referência normal, 0 mg/dL), respectivamente.</mark>  
**<mark>Tabela 1: Achados laboratoriais (média, IC)</mark>** <mark>WBC (no./μL) 14,779.0 8224.7 [1037, 31440] Hb (g / dL) - 14.7 1.8 [10.7, 17.2] Na (mEq / L) - 142.8 3.7 [135, 150] Cloreto (mEq / L) - 104.4 5.1 [93, 112] K (mEq / L) - 4.1 0.8 [3.1, 6.7] Glicemia em jejum (mg / dL) 149.1 90.0 [64, 451] Proteína (g / dL) - 7.0 0.7 [5.4, 8.7] Albumina (g / dL) - 4.3 0.5 [3.3, 5.1] AST (IU / L) 54.4 60.8 [16, 235] ALT (UI / L) 37.7 36.2 [8, 169] Colesterol, total (mg / dL) 251.1 241.7 [23, 891] Triglicérido (mg / dL) 151.2 71.8 [17.6, 313] BUN (mg / dL) 16.6 7.6 [4.1, 36.6] Creatinina (mg / dL) 1.3 0.7 [0.6, 3.2]</mark>  
<mark>Análise de gasometria arterial pH 7.375 0.1 [7.080, 7.487] PCO2 (mmHg) 34.6 7.6 [21.4, 50.4] PO2 (mmHg) 148.5 88.3 [31.7, 148.5] HCO3 (mmol / L) 19.9 5.7 [6.6, 28.3]</mark>  
<mark>Em conclusão, os autores observaram que a toxicidade humana por auxina sintética parece ser benigna, com exceção à ingestão de grandes quantidades, inclusive quando associada com a ingestão de álcool.</mark>  
123  
|Azazh A. 2010|Não disponível||||
|---|---|---|---|---|
|Darren M Roberts, Nick<br>Buckley 2007|Revisão<br>sistemática|Mortalidade e<br>efeitos adversos|Alcalinização<br>urinária|O artigo avalia a eficácia da alcalinização urinária, em particular o<br>bicarbonato de sódio, para o tratamento de intoxicação aguda por<br>herbicidas do tipo clorofenoxi.<br>Pesquisou-se as bases MEDLINE, EMBASE, CENTRAL, Current<br>Awareness em Toxicologia Clínica, Info Trac,<br>http://www.google.com.au e Science Citation Index de estudos<br>identificados pelas pesquisas anteriores. Ensaios clínicos<br>randomizados de alcalinização urinária em pacientes que<br>ingeriram um herbicida clorofenoxi e se apresentaram dentro de<br>24 a 48 horas da intoxicação foram procurados. A qualidade dos<br>estudos e a elegibilidade para inclusão foi avaliada usando os<br>critérios de Jadad e Schulz.<br>As bibliografias de estudos relevantes identificados também<br>foram pesquisadas. Especialistas na área foram contatados,<br>incluindo autores de capítulos de livros didáticos e artigos de<br>revisão sobre intoxicação por herbicida clorofenoxi. O contato foi<br>feito por e-mail e cada especialista foi incentivado a encaminhar o<br>e-mail para outros especialistas com conhecimento da área.<br>A revista “Clinical Toxicology” (indexada no Info Trac) foi<br>pesquisada como os resumos das duas maiores conferências<br>internacionais de toxicologia clínica foram publicados nesta<br>revista.<br>Um autor analisou os resultados de todas as buscas e não<br>identificou nenhum artigo que pudesse ser elegível, considerando<br>a intoxicação aguda por clorofenoxi e tratamento com qualquer<br>forma de alcalinização. Estes estudos foram então discutidos<br>entre os autores para confirmar a elegibilidade para inclusão na<br>revisão sistemática.<br>**Resultados:**|  
124  
**<mark>Risco de viés nos estudos incluídos: Nenhum estudo satisfez os critérios de inclusão. Efeitos das intervenções: Nenhum estudo satisfez os critérios de inclusão. Artigo resultante das buscas: Flanagan 1990</mark>** <mark>-</mark> **<mark>Razão de exclusão: não há grupo controle</mark>** <mark>Portanto, os autores não consideram que haja evidências suficientes para apoiar o uso rotineiro de alcalinização urinária</mark> <u><mark>para envenenamento por herbicida com clorofenoxi.</mark></u> <mark>Flanagen, 1990 (referência</mark> Série de Casos Mortalidade Alcalinização <mark>Estudou-se prospectivamente os pacientes notificados à unidade do artigo Darren et al.,</mark> urinária <mark>de saúde durante 1984-87, nos quais disseram ter se intoxicado 2007) com clorofenoxi-herbicidas ou ioxinil. Informações registradas incluem sexo, características clínicas e a quantidade e a natureza do produto ingerido. O coma foi classificado na Escala de Édivers. Quando apropriado, o tratamento com bicarbonato de sódio foi recomendado com base na história e características clínicas de toxicidade ou devido às altas concentrações de clorofenoxi total no plasma. Estudo feito por levantamento de informações em 41 pacientes. Mais de um Herbicide foi encontrado em 38 casos. 6 de 30 pacientes que ingeriram apenas compostos clorofenoxicos morreram; 16 pacientes (principalmente em coma de grau 3-4) tiveram diurese alcalina e 15 sobreviveram. 7 de 11 dos doentes que co-ingeriram ioxinil morreram; 3 fizeram diurese alcalina e todos sobreviveram. A</mark> **<mark>diurese alcalina reduziu a meia-vida de clorofenoxi plasmática para valores observados após doses que não mostravam efeitos adversos (ou seja, abaixo de 30 h), mas não influenciou o clearance de ioxynil</mark>**  
125  
||||Os autores sugerem o uso da diurese alcalina deve ser usada para<br>tratar intoxicação aguda com herbicidas clorofenoxi ou ioxinil, em<br>presença de coma ou mal prognóstico.|
|---|---|---|---|
|US-EPA|Guia|**Tratamento**|Tratamento de Toxicose Clorofenoxida<br>1. Descontaminação da pele e dos cabelos, banhando-os com sabão e água e lavando<br>com shampoo. Indivíduos com doenças de pele crônicas ou sensibilidade conhecida a<br>esses herbicidas devem evitar usá-los ou tomar precauções para evitar contato<br>(respirador, luvas, etc.).<br>2. Lave e retire os produtos químicos contaminantes dos olhos com grandes<br>quantidades de água limpa por 10 a 15 minutos. Se a irritação persistir, um exame<br>oftalmológico deve ser realizado.<br>3. Se algum sintoma de intoxicação ocorrer durante ou após a inalação do spray,<br>remova a vítima do contato com o material por pelo menos 2 a 3 dias. Permitir o<br>contato subsequente com os compostos clorofenoxi somente se houver proteção<br>respiratória efetiva.<br>4. Considere os procedimentos de descontaminação gástrica, conforme descrito no<br>Capítulo 3 do guia da US- EPA, Princípios Gerais. Se quantidades substanciais de<br>compostos clorofenoxi tiverem sido ingeridas, a emese espontânea pode ocorrer.<br>5. Administrar líquidos endovenosos para acelerar a excreção do composto<br>clorofenoxi e para limitar a concentração do agente tóxico no rim. Uma urina de 4-6<br>mL/minuto é desejável. A solução salina/dextrosa intravenosa tem sido suficiente|  
126  
<mark>para resgatar pacientes comatosos que ingeriram 2,4-D e mecoprope várias horas antes da admissão hospitalar.</mark>  
**<mark>CUIDADO</mark>** <mark>: Monitorize com cuidado as proteínas e células na urina, uréia, creatinina sérica, eletrólitos séricos e a entrada / saída de fluido para assegurar que a função renal permaneça intacta e que a sobrecarga de fluido não ocorra. 6.</mark> **<mark>Alcalinize a urina para manter um pH entre 7,6 e 8,8. A alcalinização urinária tem sido usada com sucesso no manejo de ingestões suicidas de compostos clorofenoxi, especialmente quando iniciadas precocemente</mark>** <mark>.(4,6,9) Embora o termo “diurese alcalina forçada” tenha sido usado anteriormente para descrever esse tratamento, a terminologia preferida é agora “alcalinização urinária” para enfatizar a importância da manipulação do pH da urina para limpar o ácido fraco.(23) A alcalinização da urina incluindo bicarbonato de sódio (44-88 mEq por litro) na solução intravenosa acelera a excreção de 2,4-D e excreção de mecoprofil substancialmente, porque o ácido fraco está em um estado ionizado no túbulo renal e, portanto, não pode se difundir através do túbulo para o sangue. A depuração renal é mínima a um pH ácido de 5,1 (0,14 mL / min) em comparação com a depuração a um pH de 8,3 (63 mL / min) .6,23 Há controvérsia e a falta de estudos clínicos controlados em torno da maneira mais eficaz de induzir a depuração de 2,4-D e mecoprope. O documento de posicionamento AACT e EAPCCT recomenda que a alcalinização da urina e a alta diurese forçada (diurese forçada) sejam consideradas.(23) A Cochrane Database of Systemic Reviews observa a falta de evidência, baseada na falta de ensaios clínicos randomizados para esse tratamento.</mark> **<mark>O autor concluiu que “não é despropositado tentar a alcalinização urinária”, dada a toxicidade prolongada e o potencial de morte, e que “são necessários ensaios controlados, randomizados e controlados”</mark>** <mark>.(24) 7. Inclua cloreto de potássio quando necessário para compensar o aumento das perdas de potássio, com 20-40 mEq de cloreto de potássio para cada litro de solução intravenosa. Alto fluxo de urina, aproximadamente 200 mL / h, melhora a depuração, Em um caso de insuficiência renal, a alcalinização urinária foi iniciada 26 horas após a ingestão,</mark> <u><mark>(9) e em outro foi iniciada no dia 2 da internação hospitalar.(20) Portanto, é</mark></u>  
127  
<mark>crucial monitorar cuidadosamente a função renal, assim como os eletrólitos séricos, especialmente potássio e cálcio.</mark>  
<mark>8.</mark> **<mark>Considerar a hemodiálise em casos graves</mark>** <mark>, particularmente quando o excesso de administração não é recomendado.(17) Não é recomendada como terapia de primeira linha.</mark>  
<mark>9. Incluir estudos de eletromiografia e condução nervosa no exame clínico de acompanhamento para detectar quaisquer alterações neuropáticas e defeitos na junção neuromuscular.</mark>  
128

---

