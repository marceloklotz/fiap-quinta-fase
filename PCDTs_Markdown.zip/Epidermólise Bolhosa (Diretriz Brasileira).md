<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
<!-- Start of picture text -->
3{<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 24, DE 23 DE DEZEMBRO de 2021.  
Aprova as Diretrizes Brasileiras para os Cuidados de Pacientes com Epidermólise Bolhosa.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a epidermólise bolhosa no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 679/2021 e o Relatório de Recomendação nº 683 - Novembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Ficam aprovada as Diretrizes Brasileiras para os Cuidados de Pacientes com Epidermólise bolhosa.  
Parágrafo único.  As Diretrizes objeto deste artigo, que contêm o conceito geral da epidermólise bolhosa, critérios de diagnóstico, critérios de inclusão e de exclusão, cuidados gerais e específicos e mecanismos de regulação, controle e avaliação, disponíveis no sítio <u>https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt , são de caráter nacional e devem ser</u> utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da epidermólise bolhosa.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas  no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria Conjunta n<sup>o</sup> 11/SAES e SCTIE/MS, de 26 de junho de 2020, publicada no Diário Oficial da União nº 122, de 29 de junho de 2020, seção 1, página 54.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.  
SERGIO YOSHIMASA OKANE  
HÉLIO ANGOTTI NETO  
ANEXO

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A Epidermólise Bolhosa (EB) compreende um grupo de doenças genéticas que comprometem a resistência da pele para estresse mecânico e levam à formação de bolhas após mínimos traumas mecânicos<sup>1</sup> . As bolhas podem, de forma localizada, nas extremidades ou generalizada, afetar diferentes locais do corpo. A EB pode ter causa genética ou autoimune, e, por conseguinte, é dividida entre as formas epidermólise bolhosa hereditária (EBH) ou epidermólise bolhosa adquirida (EBA), respectivamente. A EBA pode acometer pele e mucosas, com diferentes fenótipos, na qual há produção de anticorpos contra o colágeno VII<sup>2</sup> . Não há transmissão genética na EBA.  
A EB é de ocorrência mundial e acomete ambos os sexos. Inexistem dados epidemiológicos sobre sua frequência no Brasil. De acordo com a literatura, a prevalência de EBH fica em torno de 11 casos por um milhão de habitantes e a incidência é de aproximadamente 20 casos por um milhão de nascidos vivos<sup>3</sup> . <mark>A incidência estimada de EBH (Epidermólise Bolhosa Hereditária), em diferentes marcos cronológicos, nos EUA, Itália, Romênia e Japão variou de 3,8 a 25 por 1 milhão de nascidos vivos</mark><sup>3</sup> .  
Trata-se de um grupo de doenças que apresentam alterações de proteínas estruturais que podem estar presentes na epiderme, na junção dermoepidérmica ou na derme papilar superior. Essas alterações moleculares genéticas presentes na EBH são de transmissão autossômica dominante (AD) ou recessiva (AR) e geram bolhas espontâneas ou desencadeadas por traumas na pele e mucosas. A identificação de fatores de risco e da doença em seu estágio inicial dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos<sup>.1</sup> . Do mesmo modo, a equipe responsável pelo atendimento inicial na fase neonatal deve adotar uma conduta adequada, com encaminhamento para a rede assistencial e serviços especializados apenas após as medidas iniciais apropriadas e estabilização do paciente<sup>4,5</sup> .  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos da epidermólise bolhosa. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Q81.0 Epidermólise bolhosa simples  
- Q81.1 Epidermólise bolhosa letal  
- Q81,2 Epidermólise bolhosa distrófica  
- Q81.8 Outras pidermólises bolhosas  
- Q81.9 Epidermólise bolhosa não especificada  
- L12.3 Epidermólise Bolhosa Adquirida  
**3. TAXONOMIA** **_NORTH AMERICAN NURSING DIAGNOSIS ASSOCIATION_ (NANDA®-I 2018-2020)**<sup>**6**</sup>  
- Risco de resiliência prejudicada (00211)  
- Integridade da membrana mucosa oral prejudicada (00045)  
- Risco de integridade da membrana mucosa oral prejudicada (00247)  
- Integridade da pele prejudicada (00046)  
- Risco de integridade da pele prejudicada (00047)  
- Risco de integridade tissular prejudicada (00248)  
- Integridade tissular prejudicada (00044)  
- Risco de infecção (00004)  
- Dor aguda (00132)  
- Dor crônica (00133)

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Conforme a camada da pele na qual ocorre a formação de bolhas ( **Figura 1** ), a EB é classificada em 4 tipos clássicos: EB simples (EBS; camada intraepidérmica), EB juncional (EBJ; dentro da lâmina lúcida da membrana basal), EB distrófica (EBD; abaixo da membrana basal) e EB de Kindler (EBK; padrão misto de clivagem da pele). Com manifestações clínicas heterogêneas, a EB compreende fenótipos que envolvem cerca de 16 genes<sup>1</sup> . A epidermólise bolhosa hereditária juncional (EBJ) envolve principalmente o gene que codifica a laminina; a epidermólise bolhosa hereditária distrófica (EBD), o gene que codifica o colágeno tipo VII, e; a síndrome de Kindler (SK), no gene que codifica kindlina-1. Outras proteínas também podem estar envolvidas na etiologia da EB<sup>7</sup> .  
<!-- Start of picture text -->
—<br>ccc<br>EBs eae.<br>mo: EBJ Flamenios -<br>EBD Fibrlasde ancoragem<br><!-- End of picture text -->  
**Figura 1** - Representação das camadas da pele associadas aos diferentes tipos de epidermólise bolhosa (EB). A epiderme, onde estão os queratinócitos, é anexada à derme pela membrana basal, formada pela lâmina lúcida e lâmina densa. À esquerda é apresentado cada tipo principal de EB próximo à respectiva camada da pele onde ocorre a formação das bolhas: na EB simples (EBS) ocorre nos queratinócitos basais; na EB juncional (EBJ) na lâmina lúcida e na EB distrófica (EBD), na sublâmina densa (porção superior da derme ou derme papilar). Na EB de Kindler (EBK), a clivagem pode ocorrer tanto nos queratinócitos quanto nas lâminas (lúcida ou densa). À direita são apresentados os principais complexos de adesão das camadas da pele que estão associados aos subtipos de EB. Em evidência estão os hemidesmossomos, os filamentos  
de ancoragem e as fibrilas de ancoragem, que têm papel essencial para a estável adesão dos queratinócitos basais à zona da membrana basal para a ligação da lâmina densa<sup>1,8</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A EBS possui 4 subtipos associados a 7 genes e compreende o maior número de subgrupos clínicos 1,8. Dentre as formas EBS ( **Quadro 1** ), a localizada, intermediária e grave são as mais graves e mais frequentes. Esses três subtipos são causados por variantes patogênicas nos genes KRT5 ou KRT14, que codificam as queratinas 5 e 14, respectivamente,<sup>1,8</sup> . Quase todas as formas de EBS são autossômicas dominantes<sup>9</sup> .  
A EBS localizada (antes conhecida como Weber-Cockayne) é a forma mais leve. Entre a infância e a terceira década de vida são observadas bolhas induzidas por traumas, geralmente limitadas às regiões palmoplantares. O cabelo e os dentes não costumam apresentar alterações e a distrofia ungueal é rara<sup>1,8,10</sup> . As bolhas podem se desenvolver na infância, especialmente quando a criança começa a engatinhar e caminhar, mas geralmente não estão presentes ao nascimento. Ceratodermia palmoplantar focal (espessamento da pele das mãos e dos pés) pode aparecer na vida adulta e infecções secundárias às bolhas são as complicações mais comuns<sup>1,8</sup> .  
Na EBS intermediária generalizada (antes conhecida como Koebner), as bolhas surgem logo após o nascimento com a distribuição generalizada de bolhas, sem a formação de agrupamento (herpetiforme). Não envolve acometimento extracutâneo (presentes na forma grave) e o desenvolvimento dos cabelos, dentes e unhas é normal. As lesões geralmente cicatrizam deixando pigmentação pós-inflamatória. Atrofia e milia podem ocorrer, embora menos frequentemente do que na forma grave generalizada<sup>1,8,10</sup> .  
A EBS grave (antes conhecida como Dowling-Meara) é a forma mais grave de EBS, caracterizada por bolhas grandes herpetiformes que podem ser hemorrágicas. Durante a infância, as bolhas se desenvolvem por todo o corpo, com maior frequência nas mãos e nos pés, ao redor da boca, no tronco e pescoço. O acometimento da mucosa bucal é comum. As lesões comumente curam sem cicatrizes, mas podem ocorrer inflamações, especialmente das bolhas hemorrágicas. Hiperqueratose das palmas e plantas, distrofia das unhas, milia e atrofia podem ocorrer. A EBS grave generalizada pode melhorar na puberdade, contudo, a ceratodermia palmoplantar é mais grave para a maioria dos casos<sup>1,8,10</sup> .  
Outros tipos de EBS são formas raras e autossômicas recessivas<sup>9</sup> : EBS com distrofia muscular, EBS autossômica recessiva, EBS superficial, EBS acantolítica letal, EBS com deficiência de placofilina 1, EBS com atresia de piloro, EBS autossômica recessiva, EBS circinata migratória<sup>10</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Todas as formas de epidermólise bolhosa hereditária juncional (EBJ) são autossômicas recessivas e classificadas de acordo com os sinais clínicos apresentados e a gravidade do fenótipo, em 9 subtipos variáveis, que levam a mutações em 7 genes diferentes ( **Quadro 1** ). Atualmente, a EBJ pode ser dividida nas formas localizada e generalizada, ambas se redividindo em subtipos. Embora a apresentação clínica seja diferente entre os subtipos de EBJ, em todos ocorre hipoplasia do esmalte dentário. Os subtipos mais frequentes de EBJ são causados por variantes patogênicas nos genes que codificam a proteína laminina332 e o colágeno tipo XVII<sup>1,8,10,11</sup> .  
A forma mais grave desse grupo é a EBJ grave (antes conhecida como EBJ generalizada grave ou EBJ-Herlitz), que se caracteriza por extensa fragilidade da pele e das membranas mucosas, com formação de bolhas e erosões mucocutâneas, por todo o corpo, desde o nascimento<sup>1,12</sup> . Um tecido de granulação vermelho vivo e friável é formado especialmente ao redor de nariz e boca, nas nádegas e nas pregas das unhas. As consequências são atraso no desenvolvimento, dificuldade de cicatrização de feridas, anemia, complicações respiratórias e perda de proteínas, fluidos e ferro que aumenta a suscetibilidade a infecções acarretando à morte nos primeiros anos de vida<sup>1,8</sup> .  
O subtipo EBJ intermediária (antes conhecida como EBJ generalizada intermediária ou EBJ generalizada não Herlitz) compreende um grupo clinicamente heterogêneo, com bolhas generalizadas que resultam em discreta atrofia e hipopigmentação nos locais cicatrizados. Assim como no subtipo mais grave, na EBJ intermediária, há comprometimento das membranas, entretanto de forma mais branda. Podem aparecer manifestações clínicas como alopecia, defeitos de esmalte e distrofia ou ausência de unhas, em diferentes níveis de gravidade. Tecido de granulação, formação de feridas crônicas e envolvimento extracutâneo em córnea, laringe e trato urinário também podem ocorrer<sup>12,13,14,15</sup> . Nesses pacientes o colágeno do tipo XVII é reduzido, mas não ausente<sup>13,16</sup> .  
A EBJ localizada, assim como o subtipo intermediário, está associada à distrofia ou ausência de unhas, à hipoplasia do esmalte dentário e à tendência para o desenvolvimento de cáries, mas não é comum a apresentação de cicatrizes atróficas extensas, alopecia e outros achados extracutâneos como anemia e atraso no desenvolvimento. Diferente do subtipo grave da doença, a forma localizada pode apresentar um fenótipo muito leve com somente distrofia de unhas<sup>16</sup> .  
Na forma inversa, um dos subtipos mais raros, aparecem manifestações cutâneas (comumente mais extensas que a EBJ localizada), principalmente, em áreas intertriginosas (áreas da pele que se encostam ou se atritam)<sup>17</sup> .  
O subtipo EBJ com atresia pilórica envolve alterações nos genes que codificam a integrina α6β4 que está associado à atresia pilórica, à formação de bolhas generalizadas, à ausência congênita de pele e à letalidade precoce<sup>12</sup> ; contudo, essa forma de EB também pode se apresentar com menos gravidade<sup>18</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Na EBD a clivagem da pele ocorre na região da sublâmina densa (porção superior da derme). Subdividida em autossômica dominante (EBDD) ou recessiva (EBDR), a EBD está associada a diferentes gravidades que variam desde a ocorrência isolada de distrofia leve de unhas até a formação generalizada de bolhas com envolvimento extracutâneo grave e morte prematura<sup>12,19</sup> .  
A EBDR grave (antes conhecida como EBDR generalizada grave ou EBDR-Hallopeau-Siemens) é a forma mais grave de EBD. Pode apresentar ausência completa do colágeno VII, formação de bolhas generalizadas na mucosa oral, na região da córnea e no epitélio gastrintestinal, logo ao nascimento, cicatrizes com pseudosindactilia (fusão dos dedos) em mãos e pés e contraturas das articulacções. Úlceras crônicas de difícil cicatrização, mília, distrofia de unhas e estenose esofágica também podem aparecer<sup>1,8</sup> .  
A EBDR intermediária (antes conhecida como EBDR generalizada intermediária ou EBDR não Hallopeau-Siemens) se caracteriza pela formação de bolhas de distribuição generalizada de menor gravidade, se comparada com a EBDR grave<sup>20</sup> . Apesar de menos frequentes, sinais clínicos muito comuns  
na forma grave, como a constrição esofágica, as lesões na córnea, pseudosindactilia de mãos e pés, anemia e atraso no desenvolvimento podem surgir essa forma intermediária da doença<sup>1,8</sup> .  
A EBDD intermediária (antes EBDD generalizada) se caracteriza pela formação de bolhas com distribuição generalizada ao nascimento, lesões albopapuloides, mília, cicatrização atrófica e distrofia de unhas, mas diferente do subtipo EBDR grave, atraso no desenvolvimento, anemia grave e risco de carcinoma de células escamosas não ocorrem na forma EBDD intermediária<sup>1,8</sup> .  
Os subtipos EBDD localizada e a EBDR localizada são diferenciados geneticamente, pois não apresentam diferenças clínicas<sup>12</sup> . São formas com fenótipos muito atenuados de EB, cujos principais sinais clínicos são distribuição de bolhas de maneira localizada nas regiões de mãos e pés e distrofia de unhas. Mília e cicatrizes atróficas também podem ocorrer, mas não há envolvimento extracutâneo e pseudosindactilia<sup>20</sup> .  
A EBDR inversa se caracteriza por achados clínicos peculiares. Ocorre formação de bolhas generalizadas no período neonatal que, no início da infância, se curam e deixam cicatrizes atróficas. Com o passar dos anos, os sinais cutâneos tendem a melhorar, mas lesões graves se desenvolvem nas mucosas oral, esofágica, anal e genital<sup>21,22</sup> .  
A EBD pruriginosa compreende um prurido grave<sup>23,20</sup> .  
A EBD autorreparável (antes conhecida como EBD epidermólise bolhosa do recém-nascido) é um subtipo de EBD que se apresenta ao nascimento, ou logo após, com a formação de bolhas generalizadas. Diferente de outros subtipos, na EBD autorreparável, os sinais clínicos desaparecem por volta do 6º a 24º meses de vida<sup>20</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A EBK (antes conhecida como síndrome de Kindler) é um subtipo raro de EB<sup>1</sup> . De diagnóstico difícil, a clivagem da pele na EBK pode ocorrer em múltiplas camadas (intraepidérmica, juncional ou sublâmina densa). As características clínicas muito comuns na EBK são a poiquilodermia, que combina a hiper ou hipopigmentação da pele e a ocorrência de aglomerados de vasos sanguíneos logo abaixo da epiderme (telangiectasias) e fotossensibilidade, que se manifesta como eritema e queimadura na pele após exposição solar Manifestações extracutâneas da EBK incluem erosões na gengiva e envolvimento ocular, esofágico, gastrintestinal e geniturinário<sup>1,22</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Doença bolhosa auto-imune subepitelial rara, crônica, incurável e caracterizada pela presença de autoanticorpos ligados ao tecido contra o colágeno tipo VII, na zona da membrana basal da junção dermoepidérmica, do epitélio escamoso estratificado<sup>24</sup> . A apresentação clínica é variada e pode envolver pele, mucosa bucal e terço superior do esôfago. A apresentação clássica é uma reminiscência da EBD com fragilidade da pele, bolhas, erosões e cicatrizes na pele. Outras apresentações clínicas não clássicas incluem erupção inflamatória do tipo penfigoide bolhoso, erupção do tipo membrana mucosa do penfigoide e doença do tipo IgA da dermatose bolhosa<sup>24</sup> .  
As principais características e subtipos de EB encontram-se detalhadas no **Quadro 1** .  
**Quadro 1 -** Tipos, subtipos e principais características das epidermólises bolhosas  
|**Tipo da EB**|**Subtipos em cada categoria**|**Gene(Proteína)**|
|---|---|---|
||**Epidermólises bolhosas her**|**editárias– EBH**|
|EB simles|_Autossômicas dominantes:_||
|p|<br>EBS localizada;<br>EBS intermediária;<br>EBS grave;<br>EBS com pigmentação moteada;<br>EBS circinado migratório;<br>EBS intermediária;<br>EBS intermediária com cardiomiopatia.|KRT5 (queratina 5 --- K5)<br>KRT14 (queratina 14 --- K14)<br>KRT5 (queratina 5 --- K5)<br>KRT14 (queratina 14 --- K14)<br>KRT5 (queratina 5 --- K5)<br>KRT14 (queratina 14 --- K14)<br>KRT5 (queratina 5 --- K5)<br>KRT5 (queratina 5 --- K5)<br>PLEC (plectina)<br>KLHL24 (Kelch-like 24)|
||_Autossômicas recessivas:_<br>EBS intermediária ou grave<br>EBS intermediária<br>EBS localizada ou intermediária com<br>deficiência de BP230<br>EBS localizada ou intermediária com<br>deficiência de exofilina-5<br>EBS<br>intermediária<br>com<br>distrofia<br>musculara|KRT5 (queratina 5 --- K5)<br>KRT14 (queratina 14 --- K14)<br>PLEC (plectina)<br>DST (antígeno penfigoide bolhoso 1 ---<br>BP230b)<br>EXPH5 (exofilina-5c)<br>PLEC (plectina)<br>PLEC (plectina)|
||EBS grave com atresia pilórica<br>EBS localizada com nefropatia|CD151 (antígeno CD151d)|
|EB juncional|EBJ grave<br>EBJ intermediária<br>EBJ intermediária<br>EBJ com atresia pilórica<br>EBJ localizada<br>EBJ inversa<br>EBJ início tardio<br>EBJ síndrome<br>EBJ com doença pulmonar intersticial e<br>síndrome nefrótica.|LAMA3, LAMB3, LAMC2 (laminina-332)<br>LAMA3, LAMB3, LAMC2 (laminina-332)<br>COL17A1 (colágeno XVII)<br>ITGB4, ITGA6 (integrina α6β4)<br>COL17A1 (colágeno XVII)<br>ITGB4 (integrina α6β4)<br>LAMA3, LAMB3, LAMC2 (laminina-332)<br>ITGA3 (integrina subunidade α 3)<br>LAMA3, LAMB3, LAMC2 (laminina-332)<br>COL17A1 (colágeno XVII)<br>LOC LAMA3A (laminina α3A)<br>ITGA3 (integrina subunidade α3)|
|EB distrófica|_Autossômicas dominantes:_<br>EBDD intermediária<br>EBDD localizada<br>EBDD pruriginosa<br>EBDD autorreparável|COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)|
||_Autossômicas recessivas:_<br>EBDR grave<br>EBDR intermediária<br>EBDR inversa<br>EBDR localizada<br>EBDR pruriginosa<br>EBDR autorreparável|COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)<br>COL7A1 (colágeno tipo VII)|
||_Autossômicas dominante e recessiva_<br>_(heterozigose composta): _||  
|**Tipo da EB**|**Subtipos em cada categoria**|**Gene(Proteína)**|
|---|---|---|
||EBDgrave|COL7A1(colágeno tipo VII)|
|EB de Kindler|NA|FERMT1(kindlina-1)|
||**Epidermólises bolho**|**sas Adquiridas**|
|EB adquirida<br>(_Epidermolysis_<br>_Bullosa_<br>_Acquisita_)|NA|(colágeno tipo VII)|  
Adaptado de Has _et al_ ., (2020)<sup>1</sup> e de Denyer et al., 2017<sup>9</sup>  
NA: Não se aplica. EBS: Epidermólise Bolhosa Simples; EBJ: Epidermólise Bolhosa Juncional; EBD: Epidermólise Bolhosa Distrófica. EBDD: Epidermólise Bolhosa Distrófica Autossômica Dominante; EBDR: Epidermólise Bolhosa Distrófica Autossômica Recessiva.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Diante do exposto acima, as diversas classificações das EB podem apresentar acometimento da pele e, também, extra cutâneo. É importante, para a correta identificação, classificação e planejamento do cuidado, que o indivíduo com EB seja avaliado por uma equipe multidisciplinar, a qual deve compreender médico, fisioterapeuta, terapeuta ocupacional, nutricionista, odontólogo, enfermeiro, fonoaudiólogo e psicólogo. Algumas condições extra cutâneas podem levar à necessidade de equipe profissional especializada em cardiologia, ortopedia, reumatologia, gastroenterologia, dermatologia, nefrologia, entre outras.  
Os principais sinais e sintomas clínicos são detalhados a seguir.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A formação de bolhas na pele em locais de trauma mecânico é a principal característica clínica da EB. As bolhas podem ser superficiais como na EBS e resultar em erosões, ou podem ser mais profundas, como na EBJ, EBD e SK e levar a ulcerações. As bolhas podem ser generalizadas, disseminadas para diferentes locais do corpo ou localizadas nas extremidades<sup>1</sup> .  
As membranas mucosas oculares, orais, esofágicas, traqueais, geniturinárias e anais podem ser afetadas por erosões, ulcerações e cicatrizes. A fragilidade dos anexos cutâneos pode envolver unhas, que podem se tornar distróficas ou perdidas, e cabelos, levando à alopecia. Essas manifestações são características de subtipos específicos de EB<sup>12</sup> , conforme descrito no **Quadro 1** .  
A cicatrização progressiva, em formas mais graves de EB, pode resultar em contraturas das mãos e dos pés (pseudossindactilia) ou de articulações diversas, microstomia, desfiguração e estenose esofágica, comuns na SK e na EBD, ou dispneia com risco de asfixia em formas específicas de EBJ. Os dentes podem ser afetados por causa da amelogênese imperfeita (em EBJ) ou secundariamente à fragilidade e cicatrização da mucosa bucal, levando a uma higiene bucal prejudicada<sup>1</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A EBD recessiva generalizada, devido ao alto dispêndio energético e às complicações adquiridas na pele, pode ser acompanhada por falha no desenvolvimento, anemia, osteoporose, contraturas nas articulações, cardiomiopatia ou amiloidose renal, por exemplo<sup>1</sup> .  
Além das complicações supracitadas, podem ser observadas as alterações relacionadas ao sistema gastrointestinal, principalmente, constipação intestinal e estenose esofágica, em que o paciente pode evoluir com disfagia progressiva, podendo resultar em desnutrição<sup>2</sup> , anemia, restrição de crescimento, entre outras complicações<sup>26</sup> . O estado nutricional dos pacientes com EB pode ser prejudicado a depender da extensão das manifestações cutâneas e extra cutâneas. Estas, por sua vez, dependem do tipo e da gravidade da EB<sup>26</sup> .  
Pacientes com formas mais graves de EB geralmente têm balanço energético e nitrogenado negativos, devido a fatores que limitam a nutrição (microstomia, anquiloglossia, presença de bolhas na cavidade bucal e no esôfago, alterações dentárias, refluxo gastroesofágico, gastrite, megacólon, doenças inflamatórias intestinais, entre outros). Estas alterações resultam em comprometimento do consumo e da absorção de nutrientes. Ademais, a demanda energética nestes indivíduos é maior, em decorrência de hipermetabolismo resultante da presença de lesões cutâneas ou infeções<sup>26-28</sup> . Entretanto, em alguns casos pode ocorrer excesso de peso, que pode estar relacionado ao sedentarismo e a situações em que a ingestão é excessiva e nutricionalmente inadequada. O cuidado nutricional deve ser adequado, considerando que o excesso de peso também pode ter resultados deletérios, visto que estes indivíduos podem ser menos ativos fisicamente, mais propensos à formação de bolhas nos pés ou se tornarem dependentes de cadeiras de rodas<sup>26,27</sup> .  
Pode ocorrer distrofia muscular na EBS com deficiência de plectina; atresia pilórica em EBS com deficiência de plectina e em EBJ com deficiência de integrina a6b4; cardiomiopatia na EBS causada por variantes da sequência KLHL24 ou PLEC e em síndromes de fragilidade cutânea com variantes da sequência DSP e JUP<sup>29</sup> ; fibrose pulmonar e síndrome nefrótica na EBJ com deficiência da subunidade integrina a3<sup>30</sup> ; anormalidade do tecido conjuntivo em pacientes com mutação no gene PLOD3<sup>31</sup> ; ou síndrome nefrótica em pacientes com deficiência de CD151<sup>1</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
O diagnóstico laboratorial pode envolver um combinado de testes moleculares e exames histopatológicos. A aplicação do teste e exame corretos e, consequentemente, a correta classificação de subtipo de EB é de fundamental importância para o correto direcionamento dos cuidados necessários e para o prognóstico do caso.  
O diagnóstico molecular é descrito a seguir, de acordo com algumas especificidades de subpopulações. O completo mapeamento laboratorial na EB pode ser visualizado na **Figura 2** .  
<!-- Start of picture text -->
Suspeita de EB<br>Biópsia de pele Coleta de sangue, saliva ou swab<br>bucal<br>Imunofluorescencia para<br>identificação de proteínas<br>Microscopia eletrônica possivelmente ausentes: Colágeno Teste genético<br>7, queratina, laminina<br>Painel de 25 genes *<br>Tipo de EB: junctional,  envolvidos na EB por<br>Exoma completo<br>simples, distrófica ou sequenciamento de<br>Kindler próxima geração<br>Sequenciamento Sanger para algum<br>gene suspeito ou confirmação de<br>Inconclusivo variante encontrada<br>Nenhuma variante encontrada nos genes  Variante patogenica<br>da EB. Reconsiderar o diagnositico de EB  Variante de significado encontrada (tipo de EB e<br>e diferenciais incerto subtipo relacionado com<br>a clinica)<br>Teste genetico nos pais<br>Estudos funcionais – Sequenciamento<br>EB é improvavel: adaptar o plano individualizados como MLPA, EB é provavel: testes  mRNA e proteina Sanger para a varianteencontrada<br>para investigação de outras qPCR, sequenciamento complete<br>genodermatoses do genoma<br>Variante patogenica<br>detectada Aconselhamento<br>genetico<br><!-- End of picture text -->  
**Figura 2** - Proposta de fluxo diagnóstico  
*25 genes: CAST CD151 CDSN CHST8 COL17A1 COL7A1 CSTA DSP DST EXPH5 FERMT1 FLG2 ITGA3 ITGA6 ITGB4 KLHL24 KRT14 KRT5 LAMA3 LAMB3 LAMC2 MMP1 PLEC SERPINB8 TGM5  
Fonte: Has et al., 2020.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A equipe de atenção ao recém-nascido deve ser orientada sobre o diagnóstico imediato e tratamento adequado no próprio serviço de neonatologia onde foi realizado o parto. Na dúvida, frente a um recémnascido com lesões na pele ou ausência de pele, devem-se implementar cuidados básicos como se fosse um caso de EB<sup>9</sup> .  
Um bebê recém-nascido, que apresente sinais e sintomas condizentes com EB grave, como ausência congênita de pele, formação de bolhas ou fragilidade cutânea, após estabilizado, pode ser encaminhado a um centro de atendimento especializado de alta complexidade como hospital universitário ou a um centro de doenças raras para diagnóstico e tratamento adequado. Deve-se considerar, entretanto, que o transporte pode causar mais danos ao bebê. É importante evitar este transporte nesta fase inicial, visto que muitos neonatos com EB grave podem ter outras malformações ou agravos associados. Além de uma amostra de sangue para a extração do DNA genômico, uma biópsia de pele deve ser realizada no paciente. A confirmação do diagnóstico pode ser obtida (i) utilizando o exame histopatológico de material obtido pela biópsia de pele; ou (ii) por testes genéticos diretos. Em alguns casos, ambos os procedimentos são  
necessários<sup>1,5,32</sup> . Vale ressaltar que a biópsia não está indicada para confirmar EB e sim para descartar os diagnósticos diferenciais.  
Caso julgado necessário pelo médico responsável pela equipe assistencial, profissionais da saúde voluntários de associação ou representação de pacientes podem ser consultados ao nascimento ou acionados para dar suporte à equipe nessa fase do atendimento.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Como a apresentação das manifestações clínicas pode se tornar mais clara com a idade, qualquer paciente pediátrico ou adulto com fragilidade da pele que já tenha desenvolvido manifestações típicas do subtipo EB pode ser encaminhado diretamente a um centro de referência em doenças raras. Dependendo da situação, o método escolhido pode ser a identificação de mutação por sequenciamento do DNA<sup>1</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
O teste genético é sempre recomendado para o diagnóstico de EB. Sempre que possível, os pais devem ser testados para fornecer aconselhamento genético confiável e cálculo de risco para familiares e filhos. Sob a condição dominante da doença, isso pode atuar como uma “confirmação de variante de sequência”. A segregação de variantes patogênicas nos pais e outros membros da família é importante para compreender o padrão de herança (autossômico recessivo, autossômico dominante, de novo) e a avaliação de risco para gravidez futura. A recorrência da doença na família é possível, mesmo que o risco calculado seja muito baixo, portanto, as famílias devem ter o correto aconselhamento genético<sup>1,33,34</sup> .  
Quando o status de portador da variante de sequência familiar foi determinado em ambos os membros de um casal, o teste pré-natal baseado em DNA pode ser oferecido ao casal mediante solicitação<sup>1</sup> . Os resultados do diagnóstico laboratorial da EB devem ser comunicados ao paciente e à família, preferencialmente por geneticistas e dermatologistas com experiência no campo. O aconselhamento genético é sempre recomendado<sup>1</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Pacientes com diagnóstico de EB hereditária ou adquirida, sem restrição de sexo e idade.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Quaisquer outras dermatoses bolhosas não EB, como por exemplo:  
- Doença de IgA linear em adultos;  
- Penfigoide bolhoso;  
- Lúpus eritematoso bolhoso;  
- Doença de IgA linear na infância (doença bolhosa crônica da infância);  
- Penfigoide cicatricial (penfigoide mucoso benigno, penfigoide benigno da membrana mucosa, pênfigo ocular, penfigoide cicatricial);  
- Dermatite herpetiforme (doença de Duhring);  
- Pênfigo endêmico (pênfigo foliáceo endêmico, fogo selvagem);  
- Doença de Grover (dermatose acantolítica papular benigna, dermatose acantolítica persistente, dermatose acantolítica transitória);  
- Pênfigo IgA;  
- Dermatose neutrofílicaintra-epidérmica por IgA;  
- Penfigoide cicatricial localizado (Penfigoide cicatricial de Brunsting-Perry);  
- Pênfigo paraneoplásico;  
- Pênfigo eritematoso (síndrome de Senear – Usher);  
- Pênfigo foliáceo;  
- Pênfigo herpetiforme (dermatite herpetiformeacantolítica, pênfigo herpetiforme, doença bolhosa mista, pênfigo controlado por sulfapiridina);  
- Penfigoide nodular;  
- Pênfigo vegetans;  
- Pênfigo vegetans de Hallopeau;  
- Pênfigo vegetans de Neumann;  
- Pênfigo vulgar;  
- Penfigoide vesicular;  
- Penfigoide vulvar na infância;

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
O tratamento da EB inclui diferentes medidas medicamentosas e não medicamentosas para prevenção e tratamento de lesões bolhosas e complicações decorrentes. O planejamento do cuidado do paciente com EB deve se adequar ao tipo de EB, bem como às condições clínicas no momento da avaliação.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Como uma condição clínica sem cura, os cuidados com as feridas é a base do tratamento dos pacientes com EB. Entretanto, há uma escassez de evidências científicas com a maioria das recomendações baseadas em opiniões de especialistas. As feridas desses pacientes são recorrentes e difíceis de cicatrizar, podem ser muito exsudativas, necróticas, extensas e de cicatrização complexa. Variam conforme o tipo e subtipos de EB, todavia problemas como risco de infecção, controle da umidade do leito, dor, odor e necessidade de prevenção de danos adicionais à pele delicada são comuns a todos. Além da prevenção e do tratamento das feridas, existem outros pilares importantes como o controle da dor e o reconhecimento precoce de possíveis complicações, como infeção bacteriana seguida de sepse (causa comum de mortalidade neonatal), a cicatrização deformante e o aparecimento de neoplasias cutâneas agressivas (causa comum de mortalidade a partir da adolescência)<sup>35</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Com a finalidade de alinhar conceitos, nessas Diretrizes foram consideradas como _coberturas_ , as tecnologias usadas para prevenir feridas ou otimizar o processo de cicatrização das mesmas e como _curativo,_ o procedimento que inclui a avaliação do paciente com a ferida, limpeza do leito da ferida e da região perilesional, indicação e colocação da cobertura e sua adequada fixação<sup>36</sup> . Para facilitar a compreensão dessa seção, as recomendações gerais para cuidar dos pacientes com feridas relacionadas à EB foram agrupadas, de acordo com as abordagens temáticas as quais elas se referem, a saber: (i) avaliação do paciente; (i) plano de cuidados; (iii) limpeza do leito da ferida e remoção de curativos; (iv) cuidados durante o banho e troca de fraldas; (v) cuidados com dispositivos de assistência; (vi) prevenção de feridas; (vii) escolha da cobertura; (viii) controle da carga bacteriana; (ix) controle da dor e (x) controle do calor e do prurido.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considere a estrutura de suporte do sistema de saúde, em todos os níveis de atenção (primária, secundária e terciária) para estruturar uma abordagem multidisciplinar para novos casos;  
- Avaliação inicial (anamnese e exame físico) completa e meticulosa do paciente com EB que seja capaz de subsidiar um plano de cuidados individualizado e fundamentado nas necessidades biopsicossociais e preferências do paciente<sup>37</sup> ;  
- Fazer uma abordagem empática e focada na qualidade de vida do paciente/família para aumentar a possibilidade de adesão e resultados de sucesso<sup>38</sup> ;  
- Elaborar um inventário da área de superfície corporal envolvida com a determinação do tipo de feridas (bolhas intactas, erosões, úlceras, feridas agudas ou crônicas) e caracterização das mesmas (extensão, quantidade de exsudato, tipo de tecido). <mark>A avaliação cutânea global não é recomendada de forma rotineira, contudo pode-se considerar um cronograma semestral para avaliação e atualização do inventário pela equipe multidisciplinar</mark><sup>36</sup> ;  
<mark>- Considerar o instrumento de Apoio à Decisão Clínica TIME (mnemônico) que é utilizado, em diversos países, por profissionais especialistas e não especialistas em feridas para avaliar e preparar o leito da ferida, reduzindo variações na tomada de decisão clínica, a partir da identificação de quatro componentes que podem comprometer o processo cicatricial</mark><sup>39</sup> :  
- <mark>T (Tecido inviável): se presente no leito da ferida tecido inviável, necrótico ou deficiente é recomendado o desbridamento, que pode ser instrumental, autolítico, enzimático, mecânico ou biológico.</mark>  
- <mark>I (Infecção ou inflamação): se o leito da ferida apresenta sinais clínicos de inflamação persistente ou infecção após a limpeza da ferida, é recomendado considerar o uso de antimicrobianos, antiinflamatórios ou antibióticos, conforme apropriado.</mark>  
- <mark>M (Manutenção da umidade): para garantir uma boa evolução cicatricial, o controle da umidade do leito da ferida é fundamental. O excesso de umidade pode acarretar em maceração das bordas e da região peri-lesão e o leito ressecado dificulta a migração das células epiteliais. Nesses casos, é recomendado o uso de tecnologias que controlam a quantidade de exsudato no leito da ferida.</mark>  
- <mark>E (Epitelização das bordas): se ocorrer epitelização das bordas, não ocorre migração de queratinócitos e progressão do tecido epitelial a partir das bordas. Nesse caso, pode ser recomendado, conforme apropriado, o desbridamento, enxertia ou terapias adjuntas;</mark>  
<mark>- Considerar o uso da “regra dos nove” para</mark> mensurar a extensão de queimaduras ou a fotografia digital para monitorar a evolução cicatricial <mark>ou aplicativos como</mark> _<mark>Push Tool</mark>_ <mark>e</mark> _<mark>Measure</mark>_ <mark>;</mark>  
- Considerar a indicação de biópsia das feridas que apresentam sinais de má evolução, como aumento rápido da extensão; da intensidade dolorosa, cicatrização estagnada, bordas com caracterização atípica ou mudança das características do leito<sup>40</sup> ;  
- Considerar, após o preparo adequado do leito, os seguintes parâmetros clínicos para avaliar o processo cicatricial: retração e caracterização das bordas, tipo de tecido que compõe o leito (granulação e necrose) e quantidade e tipo de exsudato (seroso, sanguinolento e purulento), dor e odor<sup>9</sup> ;  
- Considerar a redução de 20% a 40% da extensão da ferida em 2 e 4 semanas como um indicador cicatricial confiável<sup>41</sup> ;  
- Registrar formalmente a avaliação realizada no prontuário do paciente.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Elaborar um plano de cuidados que inclui as necessidades humanas, metas a serem alcançadas pelo paciente, família e equipe multiprofissional e as intervenções que serão adotadas para atingir resultados de  
sucesso;  
- Considerar o uso de sistemas de classificação, como NANDA®, Classificação Internacional para a Prática de Enfermagem (CIPE®), _Nursing Interventions Classification_ (NIC®), _Nursing Outcomes Classification_ (NOC®). O uso de linguagens padronizadas pode facilitar a comunicação, julgamento clínico e garantir consciência da documentação;  
- Considerar o perfil do cuidador para construção do plano de cuidados;  
- Registrar formalmente o plano de cuidados no prontuário do paciente;  
- Entregar o plano de cuidados em formato físico e com linguagem acessível para o paciente e seus familiares;  
- Reavaliar e atualizar o plano de cuidados considerando as necessidades individuais do paciente, a  
gravidade das suas feridas e a capacidade de atendimento da rede de saúde local;  
- Educar e envolver a família no plano de cuidados dos pacientes com EB pode aumentar a adesão às intervenções propostas e melhorar a qualidade de vida dos mesmos.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar que a limpeza do leito da ferida pode ser feita com solução fisiológica (cloreto de sódio a 0,9%) em uma seringa para evitar traumas cutâneos mecânicos<sup>9</sup> ;  
- Considerar realizar curativos membro a membro (por região corporal), evitando a exposição corporal a possíveis traumas e o risco de hipotermia<sup>9</sup> ;  
- Considerar que soluções contendo polihexanida (PHMB) têm ação antibiofilme e podem auxiliar no controle da carga bacteriana;  
- Para facilitar o processo, pode-se molhar o curativo durante o banho ou irrigá-lo com solução de cloreto de sódio a 0,9% ou água morna antes da remoção<sup>10</sup> . Caso o paciente com EB apresente grande superfície  
- corporal acometida ou com lesões infectadas, deve-se evitar banho de imersão<sup>9,42</sup> .  
- Secar a pele palpando gentilmente com toalha macia, nunca friccionando;  
- Utilizar hidratantes em regiões livres de lesões ou bolhas e protetores cutâneos, como polímero de acrilato, na área de fraldas.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar adiar o primeiro banho até que os danos relacionados ao nascimento estejam controlados;  
- Considerar frequência de banhos, conforme a necessidade e peculiaridade de cada paciente;  
- Considerar, para lavar membro e peri-ferida, o uso de sabonete neutro com pH entre 4 e 6<sup>43,44</sup> ;  
- Considerar o uso de fraldas de tamanho maior para que elas fiquem frouxas e sejam forradas com tecido  
- macio. Isso pode evitar atrito e trauma das regiões de contato com suas bordas e durante a movimentação  
- do recém-nascido (RN)<sup>45</sup> ;  
- Considerar a retirada de elásticos das fraldas<sup>45</sup> ;  
- Evitar o uso de toalhas higiênicas para realizar a limpeza da pele da área de fralda<sup>9</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Deve-se atentar para a regulação adequada da temperatura dos berços e e <mark>vitar, sempre que possível, a</mark>  
- <mark>permanência do RN a termo em incubadoras, pois</mark> o calor e ambiente úmido podem acarretar na formação  
de bolhas<sup>9</sup> , principalmente nos pacientes com EBS;  
- Coberturas preventivas, com baixa aderência, podem ser colocadas nas regiões onde serão fixados eletrodos e oxímetros de pulso; onde será posicionado o manguito para monitorização da pressão arterial não invasiva e onde foi coletada amostra sanguínea<sup>46</sup> ;  
- Deve-se evitar a aspiração da nasofaringe (utilizar mínima pressão de sucção, caso esta seja necessária);  
- Deve-se evitar o clampeamento do cordão umbilical com _clamps_ plásticos dando preferência para  
ligaduras;  
- Deve-se evitar o uso de pulseiras plásticas de identificação do paciente<sup>46</sup> ;  
- Evitar cateteres venosos umbilicais, sempre que possível, pois a inserção destes dispositivos pode causar  
- danos cutâneos. Quando o acesso intravenoso é necessário, a fixação desse dispositivo deve ser feita, preferencialmente, com fita de silicone<sup>45</sup> ;  
- Incentivar a alimentação oral, inclusive o aleitamento materno, associada com acompanhamento nutricional;  
- Manipular o RN com auxílio de dispositivos (erguer o RN sobre um colchão macio) ou com a técnica de  
- rolamento posicionando uma mão espalmada atrás da cabeça, outra sob as nádegas e pressionando a superfície de suporte do berço para que o RN role<sup>47</sup> ;  
- Considerar o uso de joelheiras e sapatos especiais macios para evitar bolhas em crianças com mais mobilidade<sup>9</sup> ;  
- Em relação ao vestuário, deve-se dar preferência aos tecidos macios, sem etiquetas, com a costura virada para fora e, se possível, com fecho na frente, para facilitar a remoção da vestimenta. Deve-se evitar o uso de roupas com excesso de adornos, botões e zíperes.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar que os títulos diagnósticos de enfermagem “Risco de integridade da pele prejudicada<sup>6</sup> ” e “Risco de integridade tissular prejudicada” representam necessidades prioritárias dos pacientes com EB, pois focam na prevenção de formação de novas feridas de diferentes espessuras;  
- Considerar que, com o mínimo de força externa, a derme ou a epiderme pode se separar da membrana basal da pele acarretando na formação de bolhas;  
- Considerar que a formação de bolhas é um ponto central dos danos à pele do paciente com EB. O conteúdo e a pressão dentro da bolha têm tendência a aumentar e estender o dano através da pele instável do paciente  
com EB;  
- Considerar que a punção da bolha e drenagem do seu conteúdo podem reduzir dor, evitar a propagação de novas feridas e necessidade de coberturas estéreis<sup>45</sup> ;  
- A punção da bolha deve ser realizada com agulha estéril e técnica asséptica ( **Figura 3** ). Após a drenagem de todo o conteúdo, a camada epidérmica adjacente pode ser deixada sobre o leito, como um curativo primário natural capaz de reduzir a dor e diminuir o risco de infecção<sup>48</sup> .  
**Figura 3 -** Método recomendado para lancetar a bolha para saída do seu conteúdo Adaptado de Denyer et al., 2017<sup>10</sup> .  
- Considerar o uso de coberturas de baixa aderência no leito das bolhas, logo após a drenagem do seu conteúdo, conforme descrito na recomendação anterior<sup>48,49</sup> ;  
- Evitar o uso de coberturas adesivas e compressivas pois as mesmas podem induzir a formação de novas bolhas;  
<mark>- Desbridar os tecidos inviáveis que podem surgir sobre o leito das feridas para evitar formação de biofilme e processo i</mark> nflamatório exacerbado<sup>49</sup> ;

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar para seleção a cobertura apropriada: as necessidades individuais do paciente, o tipo e subtipo de EB, as características da ferida, a frequência de troca dos curativos, a disponibilidade e custo das  
coberturas<sup>47</sup> ;  
- Considerar que o uso de coberturas primárias de baixa aderência e secundárias não adesivas pode garantir não somente a proteção contra possíveis traumas como também a prevenção de formação de bolhas;  
- Considerar um fluxo de atendimento na rede de atenção à saúde para os casos de troca de curativos de feridas complexas (com perda de espessura total) que devem ser realizadas por enfermeiros e técnicos de enfermagem devidamente treinados, conforme a Resolução nº 567/2018 do Conselho Federal de Enfermagem<sup>51</sup> ;  
- Considerar o uso de espumas, principalmente durante o sono, entre os dígitos a fim de evitar deformidades  
e fusão dos mesmos. Esse procedimento é particularmente importante para EB distróficas, mas a fusão  
digital pode ocorrer também em outros tipos de EB;  
- Considerar que as bordas e o calor das coberturas podem acarretar em formação de bolhas<sup>9</sup> . Para estes casos, são recomendados hidrofibras e coberturas transferidoras de exsudato;  
- Considerar que coberturas contendo PHMB têm ação antibiofilme e podem auxiliar no controle da carga bacteriana;  
- Considerar o uso de alternativas terapêuticas, como coberturas biológicas e equivalentes da pele, para prevenir cicatrizes hipertróficas e estimular a cicatrização de feridas estagnadas<sup>52</sup> ;  
- Considerar que o ambiente da ferida com excesso de umidade pode acarretar em maceração, irritação e mais fragilidade da pele;  
- Considerar o uso de espumas com bordas de baixa aderência e remoção atraumática como alternativas terapêuticas ou preventivas nos pacientes com EBD recessivo leve e dominante, dispensando a necessidade de coberturas secundárias, pois as feridas dessas crianças normalmente se desenvolveram sobre proeminências ósseas, como joelhos, tornozelos, dorso das mãos e dedos<sup>47</sup> ;  
- Considerar para os casos de pacientes com EBJ que têm tendência a desenvolver, logo ao nascimento, feridas crônicas, extensas e muito exsudativas o uso de cobertura lipido colóide ou telas de silicone como cobertura primária e gaze e PHMB em gel como cobertura secundária. Uma malha tubular pode ser usada também sobre o curativo secundário. Apesar de as coberturas de silicones serem bastante empregadas nos outros tipos de EB, nesses casos de pacientes com EBJ, especificamente, é desafiante a manutenção dos curativos  garantir a permanência da cobertura no leito da ferida.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar os títulos diagnósticos de enfermagem “Integridade da pele prejudicada<sup>6</sup> ” e “Integridade tissular prejudicada” para representar as necessidades dos pacientes que apresentam feridas que comprometem as camadas da pele, membranas mucosas, córnea, fáscia muscular tendão, osso, cartilagem e, inclusive ligamento<sup>6</sup> ;  
- Considerar que a avaliação meticulosa do leito da ferida pode prevenir infecção das feridas já existentes<sup>47</sup> ;  
- Considerar que o ambiente da ferida quente e excessivamente úmido pode ser ideal para proliferação de bactérias que causa odores, aumento da quantidade de exsudato, infecção e cronicidade de uma ferida;  
- Considerar o uso de espumas de hidropolímero que podem favorecer o processo cicatricial garantindo a controle da umidade no leito da ferida<sup>53</sup> ;  
- Considerar, principalmente para os pacientes com EBD generalizada que evoluem com feridas extensas e crônicas, o uso de tecnologias transferidoras de exsudato com prata como coberturas primárias que podem favorecer a controle da umidade (com cobertura secundária absorvente), o controle da carga bacteriana e reduzir o número de trocas dolorosas de curativos;  
- Considerar o uso de coberturas antimicrobianas, inclusive para prevenir infecção dos pacientes com EBD grave;  
- Considerar que o diagnóstico de enfermagem “Risco de infecção” se refere à suscetibilidade a invasão de patógenos. Pacientes com EB podem apresentar fatores de risco relacionados a esse diagnóstico, como alteração da integridade da pele e desnutrição<sup>6</sup> ;  
- Considerar o uso _off label_ da prata, em crianças, como antimicrobiano tendo como ponto de atenção a sua concentração plasmática e o tempo de uso devido à possibilidade de impregnação e intoxicação por sais de prata<sup>46, 53</sup> ;  
- Considerar, apesar das evidências limitadas, o uso de cobertura com cloreto de dialquil carbomoil (DACC) que se destaca como uma alternativa de redução da carga bacteriana por mecanismo mecânico (interação hidrofóbica) no qual as bactérias são atraídas por um ácido graxo;  
- Considerar que o controle do exsudato e da carga bacteriana acarretam no controle do odor;  
- Considerar o uso de coberturas de carvão ativado com prata para controle do odor e da carga bacteriana;  
- Considerar desbridamento conservador não traumático para reduzir a carga bacteriana;  
- Considerar o diagnóstico de infecção da ferida a partir de sinais clínicos amplamente conhecidos pelos métodos mnemônicos NERDS que sugere colonização crítica (cicatrização estagnada, exsudato inflamatório, tecido de granulação friável e de coloração vermelho vivo, pedaços de tecido e odor) e STONEES que sugere infecção (aumento do tamanho da ferida, hipertermia local, exposição óssea, exsudado, edema, eritema e odor)<sup>53,54</sup> ;  
- Considerar que a presença de sinais de infecção tecidual profunda (linfadenopatia, febre e mal-estar) podem indicar necessidade de terapia antimicrobiana sistêmica.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar que o paciente pode sentir dor durante as trocas de curativos, banho e outras atividades da vida diária, inclusive durante o repouso devido a bolhas e pele desnudada, infecção secundária, fricção e cisalhamento com movimentos físicos<sup>54</sup> ;  
- Considerar que outros fatores como ansiedade, depressão e experiências prévias podem contribuir para a experiência da dor<sup>55</sup> ;  
- Considerar a analgesia regular, apesar das dificuldades relacionadas à avaliação da intensidade de dor em neonatos<sup>56</sup> ;  
- Considerar que o uso de coberturas transferidoras de exsudato pode reduzir a frequência de trocas e  
- diminuir as experiências dolorosas relacionadas aos curativos;  
- Considerar o uso de coberturas impregnadas com ibuprofeno para os pacientes com feridas dolorosas;  
- Avaliar a severidade da dor apresentada pelo paciente com uso de uma ferramenta adequada e  
- preferencialmente validada e registrar no prontuário do paciente a intensidade, padrão temporal e fatores agravantes relacionados;  
- Considerar alternativas terapêuticas não farmacológicas, incluindo as PICS (Práticas Integrativas e Complementares em Saúde) como relaxamento, distração, biofeedback e vibração, disponíveis no SUS para  
controle da dor, que podem ser úteis combinadas ou não com as farmacológicas;  
- Considerar o uso da sacarose oral como um analgésico de ação curta para crianças menores de 2 anos de idade<sup>55</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
- Considerar que os títulos diagnósticos de enfermagem “Dor aguda” e “Dor crônica” se referem a experiências sensorial e emocional desagradáveis que podem estar associadas à lesão tissular real ou potencial de início súbito ou lento, de intensidade leve a intensa, com duração variável<sup>6</sup> ;  
- Remover os curativos dos pacientes com EB, principalmente do tipo EBS, após o fechamento das feridas  
- e manter a criança com roupas macias e do lado avesso<sup>9</sup>  
- Considerar que o prurido é um sintoma comum na população com EB e que, quando mal gerido, pode afetar a qualidade de vida<sup>55</sup> ;  
- Investigar o início do prurido e os fatores de exacerbação<sup>57</sup> ;  
- Considerar que a cobertura tópica pode ser a causa do calor e prurido<sup>57</sup> ;  
- Considerar que o prurido noturno pode estar relacionado ao superaquecimento corporal<sup>57</sup> ;  
- Deve-se proteger contra a incidência solar, não somente pelo calor, como também devido ao risco  
- aumentado para carcinoma em algumas formas de EB;  
- <mark>Considerar que o ressecamento da pele e o acúmulo de tecidos inviáveis e ressecados podem ser causa de</mark>  
- <mark>prurido, devendo-se dar especial atenção à hidratação;</mark>  
- Considerar que algumas formas de EB são particularmente mais pruriginosas e requerem abordagem  
terapêutica apropriada.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
As coberturas em geral são projetadas para promover as condições para a cicatrização úmida, proteger o leito da ferida de traumas mecânicos, fazer o controle da dor e do exsudato e garantir que sua retirada seja atraumática. Todavia, nenhuma cobertura é adequada para ser usada em todos os tipos de feridas. Nem sempre os formatos e tamanhos dessas coberturas atendem às necessidades específicas dos pacientes com EB, pois suas feridas ocupam grandes extensões corporais, envolvendo regiões como pescoço, virilha e axila. Além disso, a variabilidade de alternativas terapêuticas aliada à falta de dados de eficácia e efetividade; à diversidade clínica dos pacientes e à disponibilidade de recursos dificultam não  
somente a escolha da tecnologia a ser empregada, como também a construção de planos de cuidados individualizados e fundamentado nas necessidades humanas de cada paciente com EB.  
Todos os cuidados são prestados ao paciente com ferida e não às feridas, portanto, não há pretensão de padronizar a tomada de decisão sobre a escolha de uma cobertura para tratar o paciente com EB. Contudo, ainda que o processo cicatricial dependa das condições gerais do organismo e dos tipos e subtipos de EB que o paciente apresenta, refletir sobre as etapas da cicatrização e quais coberturas podem ser indicadas em cada uma dessas fases pode orientar os profissionais a desenvolver o raciocínio clínico que, por sua vez, é um subsídio útil para aquisição de competências e habilidades para formulação de planos de cuidados adequados.  
A cicatrização de feridas requer condições adequadas de nutrição, circulação e resposta imunológica; é um processo sistêmico e dinâmico que envolve basicamente três fases sucessivas e sobrepostas: inflamação, proliferação e remodelação<sup>58</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A fase inflamatória se inicia com a liberação de substâncias vasoconstritoras, principalmente tromboxano e prostaglandinas, pelas membranas celulares. A hemostasia ocorre a partir da ação das plaquetas e dos fibroblastos. Depois da formação do coágulo, a resposta inflamatória se inicia com vasodilatação e aumento da permeabilidade vascular, promovendo a migração de células de defesa (primeiro, os neutrófilos; depois, os macrófagos) que fazem a limpeza do ambiente da ferida e liberam citocinas e fatores de crescimento. Desta forma, inicia-se a angiogênese, fibroplasia e síntese de matriz extracelular<sup>59,60</sup> .  
Nesta fase tanto o leito quanto a borda da ferida podem apresentar sinais inflamatórios clássicos: edema, hiperemia, calor e dor. A quantidade de exsudato tende a ser exacerbada e pode ser percebida, durante as trocas de curativos, a partir da observação dos graus de saturação da cobertura (primária e/ou secundária) a ser retirada e de maceração das bordas da ferida. O uso de coberturas primárias absorventes com baixa aderência e transferidoras de exsudato pode auxiliar no controle da umidade ( **Figura 4** ).  
O ambiente da ferida com excesso de umidade pode acarretar em maceração, irritação e mais fragilidade da pele. Espumas de hidropolímero podem ser empregadas, como coberturas primárias ou secundárias, por apresentarem alta capacidade de absorção, protegerem a ferida contra possíveis traumas e prevenir a formação de bolhas.  
<!-- Start of picture text -->
FASE INFLAMATÓRIA<br>↑ Exsudato sem sinais clínicos de  Ferida com sinais de colonização crítica /<br>colonização crítica/infecção infecção<br>Transferidoras de  Espumas de  Antimicrobiano<br>exsudato  hidropolímero<br>Odor<br>RN com EB Tecido necrótico ↑ Exsudato<br>desagradável<br>Transferidoras de<br>DACC Tecnologia lipdio Carvão ativado  exsudato com<br>colóide com prata  com prata<br>prata<br>Curativo com<br>Hidrofibra e prata surfactante<br><!-- End of picture text -->  
**<mark>Figura 4</mark>** <mark>– Sugestões de coberturas que podem ser empregadas na fase inflamatória do processo cicatricial</mark>  
O leito da ferida deve ser avaliado rigorosamente quanto aos sinais clínicos que sugerem colonização crítica (cicatrização estagnada, exsudato inflamatório, tecido de granulação friável e de coloração vermelho vivo, pedaços de tecido e odor desagradável) e infecção (aumento do tamanho da ferida, hipertermia local, exposição óssea, quantidade e caracterização do exsudado, edema, eritema e odor desagradável)<sup>54</sup> . Se confirmado o diagnóstico clínico de colonização crítica ou infecção, estão indicadas as coberturas antimicrobianas. Para os pacientes com EBD generalizada e com EBJ que evoluem com feridas extensas e crônicas, coberturas antimicrobianas podem ser empregadas inclusive para prevenir infecção. A escolha dessas coberturas está atrelada à avaliação local e sistêmica de sinais clínicos evidentes e às peculiaridades de cada paciente. Vale lembrar que é importante considerar o uso de antibioticoterapia, quando presentes sinais sistêmicos de infecção<sup>54</sup> .  
A presença de tecido necrótico no leito da ferida pode acarretar na formação de biofilme e processo inflamatório exarcerbado<sup>26</sup> . Isso ocorre principalmente nas feridas crônicas que não evoluem com cicatrização apropriada por apresentarem fase inflamatória intensa e prolongada. Recomenda-se o desbridamento conservador não traumático e a redução da carga bacteriana podem ser alcançados com coberturas antimicrobiana.  
É importante destacar que o uso de coberturas com prata em crianças com idade inferior a 1 ano deve ser evitado. Para esses casos, coberturas com DACC podem ser uma alternativa para pacientes com EBJ que têm tendência a desenvolver, logo ao nascimento, feridas crônicas, extensas e muito exsudativas, pois essas coberturas possuem mecanismo de ação mecânico (interação hidrofóbica) no qual as bactérias são atraídas por um ácido graxo. Coberturas com hidrofibra e prata também podem ser uma alternativa para  
manutenção do curativo nesses pacientes que apresentam a pele escorregadia ao nascer, todavia devem ser indicadas com critérios, pois podem ser aderentes ao leito quando a quantidade de exsudato é mínima<sup>45</sup>  
Ainda sobre o controle da carga microbiana, o carvão ativado com prata é amplamente conhecido não somente como antimicrobiano, como também como tecnologia capaz de gerir o odor desagradável que pode surgir nos processos infecciosos e causar constrangimento nos pacientes.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Na fase proliferativa a angiogênese é estimulada pelo fator de necrose tumoral alfa (TNF-α). A formação de capilares e a migração celular resultam na restauração das camadas da pele. Os fibroblastos são as principais células da fase proliferativa que termina com a formação do tecido de granulação<sup>59,60</sup> .  
Nessa fase o controle da umidade do leito é imprescindível para permitir a migração e proliferação celular no leito da ferida. O hidrogel pode ser empregado como adjuvante ou como cobertura, em feridas com ambiente desidratado ( **Figura 5** )<sup>61</sup> . Já as coberturas transferidoras de exsudato (com ou sem prata) podem ser indicadas para feridas com ambiente excessivamente úmido.  
Nas feridas dos pacientes com EBD recessivo leve e dominante se desenvolveram sobre proeminências ósseas, como joelhos, tornozelos, dorso das mãos e dedos, podem ser empregadas espumas de hidropolímero com bordas adesivas que dispensam a necessidade de coberturas secundárias.  
<!-- Start of picture text -->
FASE PROLIFERATIVA<br>Ferida sem sinais clínicos de  Ferida com sinais de colonização crítica /<br>colonização crítica/infecção infecção<br>Antimicrobianos<br>↑ exsudato ↓ exsudato<br>Tecido  Odor<br>Transferidoras  Espuma de  RN com EBJ necrótico desagradável  ↑ Exsudato<br>de exsudato<br>hidropolímero<br>Tecnologia  Carvão ativado  Transferidoras de<br>Gel com  DACC lipdio colóide com prata  exsudato com<br>Dor  Sangramento PHMB  com prata  prata<br>Hidrofibra e<br>Curativo com<br>prata<br>Impregnadas  surfactante F.68<br>Alginatos Hidrogel<br>com ibuprofeno<br><!-- End of picture text -->  
**<mark>Figura 5</mark>** <mark>– Sugestões de coberturas que podem ser empregadas na fase proliferativa do processo</mark>  
<mark>cicatricial</mark>  
Considerando a fragilidade do tecido neoformado, coberturas constituídas por alginato podem ser indicadas caso ocorram eventuais sangramentos que desse tecido e coberturas impregnadas com ibuprofeno podem ser indicadas para o controle da dor local, contudo, deve-se evitar o emprego concomitante dessa cobertura em grandes extensões corporais ou a associação com analgésicos sistêmicos.  
Assim como na fase inflamatória, na proliferativa, o paciente deve ser criteriosamente avaliado quanto à presença de sinais clínicos de colonização crítica e infecção. Além do mais, a atividade proteolítica persistente pode danificar o tecido neoformado e degradar os fatores de crescimento, acarretando em estacionamento da cicatrização, o que ocorre também muito comumente em feridas crônicas<sup>62</sup> . Em feridas sem sinais clínicos de colonização crítica e infecção, coberturas com colágeno podem favorecer o crescimento tecidual por diminuírem a concentração de proteases, como colagenase e elastase, no ambiente da ferida.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Na fase de remodelamento, a deposição organizada de colágeno é o evento clínico mais importante. A princípio ocorre a produção do colágeno inicial (tipo III) que é mais fino se comparado ao colágeno da pele normal. Depois, esse colágeno é reabsorvido e um colágeno mais espesso é organizado ao longo da cicatriz garantindo à ferida maior força tênsil<sup>59,60</sup> . O processo completo de remodelação dura meses podendo ser mais prolongado nos indivíduos com EB, pois dano genético pode provocar a ausência ou redução da formação do colágeno VII. A frágil cicatriz recém formada pode ser protegida com protetores cutâneos, como o polímero de acrilato em spray e espumas. ( **Figura 6** ).  
<!-- Start of picture text -->
FASE DE REMODELAÇÃO<br>Proteção de cicatrizes recentes<br>Protetores cutâneos  Espumas<br>Polímero de acrilato<br><!-- End of picture text -->  
**Figura 6** – Sugestões de cobert <mark>uras que podem ser empregadas na fase proliferativa do processo cicatricial</mark>

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A EB pode acometer tanto a região periocular como a superfície ocular. As manifestações oftalmológicas mais comumente encontradas em pacientes com EB são: formação de bolhas, erosões e tecido cicatricial nas córneas e conjuntivas, ectrópio (eversão da pálpebra), obstrução de ducto lacrimal, simbléfaro (adesão da pálpebra ao globo ocular), formação de bolhas e cicatrizes em pálpebras, formação de _pannus_ ocular e alargamento do limbo. A presença de lesões oculares de repetição pode resultar em  
acometimento visual permanente<sup>63</sup> . Pacientes com EB podem ainda apresentar lesões oculares decorrentes de ressecamento da mucosa ocular ou irritação por meio de corpos estranhos. Deste modo, é necessário orientar pacientes, pais e cuidadores quanto à necessidade de alguns cuidados oculares:  
- Evitar coçar a região dos olhos;  
- Evitar uso de maquiagens e retirar antes de dormir, se utilizar;  
- Procurar manter os cabelos presos, afastados do rosto;  
- Evitar manter rosto próximo a ventiladores ou aparelhos de ar condicionado para que não haja ressecamento da mucosa ocular;  
- Utilizar colírios lubrificantes a cada duas horas<sup>63</sup> ;  
- Lentes de contato suaves podem ser utilizadas por pacientes com EB: além do efeito corretivo, as lentes podem servir como uma barreira protetora<sup>63</sup> ;  
- Bolhas em região palpebral devem ser tratadas do mesmo modo como em qualquer outra região do corpo<sup>63</sup> ;  
- Em caso de lesões, aplicar compressas de soro fisiológicos, colírios lubrificantes para promover redução do edema e lubrificação local;  
- Em caso de bolhas e erosões em córneas, deve-se evitar piscar para minimizar a fricção e manter o olho fechado até que a lesão cicatrize, o que geralmente ocorre em 2 a 3 dias na ausência de tecido cicatricial<sup>63</sup> ;  
- Caso necessário, o oftalmologista pode prescrever colírios/pomadas a base de antibióticos para o tratamento de lesões de córnea;  
- Colírios e pomadas a base de corticoides não são recomendados, pois podem agravar e fragilidade da mucosa oftálmica.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
As manifestações da EB em forma de bolhas que surgem na mucosa bucal dificultam, mas não impedem os cuidados locais, e predispõem o paciente a diferentes complicações. Cuidados especiais são necessários e beneficiarão os acometidos pela doença, independentemente do tipo e subtipo de EB. Deste modo, intervenções devem ser adotadas não só para o tratamento destas complicações, mas também para preveni-las<sup>25</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Os pacientes com EB devem ser encaminhados o mais precocemente possível (entre 3 e 6 meses de idade) a um dentista, mesmo antes da vigência de lesões bucais. O dentista deve, preferencialmente, fazer parte de uma equipe multidisciplinar e ser capacitado para esse atendimento<sup>25,64</sup> .  
Na avaliação inicial, pais e cuidadores devem ser informados e educados quanto à higiene e outros cuidados bucais, aspectos nutricionais e possíveis manifestações locais. Deve-se ainda examinar a região para identificação precoce de alterações de esmalte, alinhamento de arcada dentária e de cárie dentária<sup>25</sup> .  
Mais especificamente, pais e cuidadores devem ser orientados a:  
- Aplicar vaselina em lábios e pele peribucal antes da escovação<sup>25,64</sup> ;  
- Escovar os dentes do doente com escova dental com cabeça pequena e cerdas macias<sup>25,64</sup> ;  
- Caso a região bucal esteja gravemente lesionada, podem ser utilizadas hastes flexíveis com algodão, gazes ou tecidos de algodão limpos para a higiene dos dentes<sup>25</sup> ;  
- Auxiliar no processo de higiene dental para melhorar a redução de placas e reduzir o risco de novas lesões na cavidade bucal<sup>25</sup> ;  
- Enxaguar a boca ou bochechos suaves com água após as refeições para remoção de alimentos;  
- Fazer a higiene bucal com solução de clorexidina não alcoólica a 0,12% para prevenção de infecções e outras doenças na boca (bochechos suaves duas vezes por dia por duas semanas a cada três meses)<sup>25</sup> . É importante ressaltar que o bochecho só é recomendado a partir do momento que a criança tenha condições de cuspir. Antes disso, está terminantemente contra indicado, em função do risco de deglutição do produto; - Aplicar solução de flúor a 0,05% (sem álcool) na superfície dos dentes uma vez por dia com auxílio de cotonetes ou outro tipo de hastes flexíveis com algodão<sup>25,64</sup> ;  
- Realizar diariamente exercícios de abertura e fechamento da boca por meia hora para facilitar a abertura e o acesso à cavidade bucal<sup>25,64</sup> ;  
Todos os esforços devem ser feitos na tentativa de se evitar tratamentos invasivos pelo dentista. Estes tratamentos podem ser extremamente desconfortáveis e dolorosos, além de apresentarem barreiras como a microstomia e as próprias lesões. Deste modo, a realização de alguns procedimentos, que seriam comumente realizados em nível ambulatorial, é limitada. Apesar de ser possível a realização de intervenções odontológicas sob sedação ou mesmo anestesia geral, dependendo do estado de saúde geral do paciente, estes são contraindicados<sup>25</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Caso sejam necessários tratamentos dentários, devem ser tomadas algumas precauções, principalmente em se tratando de paciente com EBD, para reduzir o risco de trauma em tecidos moles, sendo recomendados:  
- Lubrificação dos lábios com vaselina ou outros lubrificantes antes do procedimento para reduzir aderências e redução de pressões que possam causar traumas ao tecido<sup>25,64</sup> ;  
- Apoiar o equipamento de sucção em tecidos duros ou em algodão umedecido para evitar formação de bolhas em partes moles<sup>25, 41</sup> ;  
- Caso novas bolhas se formem, elas devem ser drenadas por meio de punção conforme técnica anteriormente citada e demonstrada na **Figura 3**<sup>25,65</sup> ;  
- Caso o paciente apresente microstomia significativa, o uso de instrumentos pediátricos facilita o acesso<sup>25</sup> ;  
- Ao final de cada sessão, deve-se inspecionar a boca para localização de lesões bolhosas ou materiais remanescentes na cavidade;  
- Caso seja identificada alguma lesão incomum, deve-se coletar material para biópsia para investigação de tecido pré-cancerígeno ou carcinoma intrabucal<sup>25</sup> ;  
- Caso sejam feitas restaurações ou sejam utilizadas próteses dentárias, estas devem ser adaptadas e polidas adequadamente para evitar novas lesões causadas por atrito<sup>25</sup> ;  
- O uso de anestésicos tópicos deve ser considerado para promover analgesia local<sup>25</sup> ;  
- Sendo necessária aplicação de anestésico local, a solução deve ser injetada profunda e vagarosamente para evitar separação mecânica dos tecidos. O uso de anestesia geral deve ser feito apenas se uma equipe de anestesia estiver disponível<sup>25</sup> .  
- Inexiste contraindicação absoluta para a realização de radiografias. Em pacientes com EBD recessiva grave, deve-se priorizar a realização de radiografias panorâmicas, com utilização de filmes e _bitewings_ pediátricos vaselinados. Em pacientes com outras formas de EB menos graves, outros tipos de radiografias podem ser feitas com pouca ou nenhuma necessidade de adaptação<sup>25</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
O cuidado do paciente com EB deve abranger suporte nutricional, que tem como objetivo prevenir a subnutrição e deficiências nutricionais, aliviar o estresse relacionado à nutrição por via oral e favorecer o crescimento e desenvolvimento<sup>26, 27</sup> .  
Pacientes que apresentem complicações, como microstomia, anquiloglossia, problemas de mastigação por precariedade dentária, disfagia, odinofagia, anemia e disfunção renal, hepática ou do músculo esquelético e déficit de crescimento devem receber suporte nutricional adequado. Na impossibilidade de dieta oral, deve-se considerar gastrostomia<sup>26,28</sup> .  
As necessidades nutricionais de pacientes com formas graves de EB são comparáveis (mas não iguais) aos indivíduos queimados, considerando o catabolismo intenso, compatível com o gasto energético de acordo com a porcentagem da superfície corporal afetada<sup>26,28</sup> . As necessidades proteicas também são maiores nos pacientes com EB, em comparação aos seus pares saudáveis da mesma idade e sexo. Os nutrientes são necessários não apenas para o crescimento, mas também para reposição das perdas proteicas excessivas que ocorrem para as bolhas. As deficiências de micronutrientes são resultados das perdas teciduais, inflamação crônica e ingestão inadequada<sup>26</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Em indivíduos que apresentem formas menos graves de EB, as necessidades nutricionais podem ser supridas por meio de aleitamento materno. Entretanto, recomenda-se aplicação de vaselina nos mamilos, boca e face do bebê para redução de atrito e, consequentemente, a formação de bolhas. Em caso de uso de mamadeiras, deve-se orientar os pais ou cuidadores a umedecer o bico da mamadeira com água fervida e resfriada, evitando que grude na boca do bebê<sup>26</sup> .  
Em casos de extensas lesões bolhosas, pode ser necessário suporte nutricional para aumentar ingestão energética. A introdução de alimentos sólidos deve ser iniciada do mesmo modo que em crianças saudáveis. Recomenda-se a oferta de alimentos com maior densidade energética (em menor volume possível). Além disso, recomenda-se evitar o consumo de alimentos ou preparações de consistência mais dura<sup>26</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Com a progressão da doença, podem ocorrer limitações à nutrição. Em alguns casos, apenas alimentos pastosos e líquidos podem ser tolerados. Deste modo, os pais, cuidadores e os próprios pacientes  
devem ser orientados a enriquecer sua alimentação por meio da adição de alimentos com maior valor energético (azeite de oliva, queijo, manteiga etc.). O consumo de alimentos e bebidas ricos em açúcar não são recomendados devido ao aumento da chance de cáries, devendo ser consumidos apenas durante as refeições. Deve-se reforçar a necessidade de consumir alimentos ricos em fibras para prevenção de constipação intestinal<sup>26, 27</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Em geral, as necessidades energéticas de um paciente com EB variam de 100% a 150% das necessidades médias de indivíduos saudáveis, podendo ser maiores, considerando-se a extensão das lesões bolhosas, presença e gravidade da infecção ou necessidade de recuperação nutricional<sup>26, 27</sup> .  
Pacientes com EB apresentam maiores necessidades proteicas devido à presença das bolhas e ao processo inflamatório, sendo cerca de 115% das necessidades médias quando há mínimas complicações e de 200% na vigência de complicações graves<sup>26</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Perdas teciduais, estado de inflamação crônica e ingestão inadequada de micronutrientes podem levar a deficiências nutricionais<sup>26</sup> . O ideal é que se incluam alimentos na dieta que possam suprir as necessidades diárias dos micronutrientes. Em alguns casos, pode ser necessária a suplementação por meio de polivitamínicos. Neste caso, deve-se atentar à ocorrência de eventos adversos por superdose destes nutrientes.  
Pais, cuidadores e pacientes devem ser orientados a incluir no plano alimentar alimentos que contenham vitamina D, ferro, zinco, selênio e arginina e fibras, além de aumentar a oferta hídrica para repor as perdas. Alimentos ricos em açúcares devem ser evitados devido ao seu potencial cariogênico. O consumo de produtos ultraprocessados deve ser desencorajado pelo seu baixo valor nutricional, alto teor de sódio e prejuízos à saúde. As orientações sobre os tipos de alimentos adequados para suprir as necessidades nutricionais seguem as mesmas dadas à população geral e podem ser encontradas no Guia Alimentar para a População Brasileira<sup>48</sup> .  
Contudo, considerando a elevada demanda de macro- e micronutrientes<sup>26, 27</sup> , acompanhada das dificuldades de mastigação e deglutição<sup>28</sup> , especialmente entre os doentes portadores das formas mais graves de EB, podem ser necessários alimentos orais<sup>66</sup> , com alto teor calórico e proteico de acordo com as necessidades diárias de cada paciente.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Em alguns casos, o consumo de alimentos por via oral pode ser insuficiente para suprir as necessidades nutricionais dos pacientes com EB, sendo necessária oferta por via enteral. O uso de sondas enterais é recomendado apenas como medida temporária para melhora do estado nutricional antes de realizar gastrostomia. Este procedimento, por sua vez, está recomendado em caso de incapacidade de alimentação por via oral ou consumo alimentar insuficiente com prejuízo de crescimento. Preferencialmente, a introdução de alimentação via gastrostomia deve ser feita antes de se instalar um processo de desnutrição<sup>26,28, 67</sup> . O suporte nutricional pode ser necessário, levando em consideração as necessidades nutricionais, o crescimento, a tolerância e o estilo de vida familiar. Embora receba sua  
alimentação de modo diferenciado, os pacientes com EB com gastrostomia devem ser encorajados a participar das refeições junto com os demais familiares<sup>26</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A anemia é uma complicação comumente observada em pacientes com EBD recessiva e juncional, podendo estar relacionada a perdas sanguíneas crônicas por meio das lesões bolhosas, descamação da mucosa gastrointestinal, redução na ingesta de ferro ou supressão de eritropoiese. A anemia está associada à ocorrência de fadiga, anorexia e prejuízos na cicatrização de feridas. Deste modo, transfusões sanguíneas devem ser consideradas quando os valores de hemoglobina estiverem inferiores a 8 g/dL ou caso se apresentem sintomas de anemia que não respondam a outras medidas, como por exemplo a suplementação de ferro<sup>47</sup> .

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Até o momento, inexiste tratamento medicamentoso modificador do curso da doença específico para EB. O tratamento sintomático compreende a utilização de anti-histamínicos, em presença de prurido intenso, e de analgésicos para o controle da dor crônica.  
O prurido é queixa comum nos pacientes com EB. A intensidade é variável, mas muitas vezes agrava quadros de ansiedade ou depressão e ocasiona novas lesões pela coceira crônica. Fatores como lesões em cicatrização, pele seca, lesões infectadas, calor e alta umidade do ambiente podem acentuar esse sintoma<sup>68</sup> . Alguns subtipos de epidermólise bolhosa têm classicamente prurido intenso, como a epidermólise bolhosa pré-tibial. Indivíduos com formas de EB com presença de prurido mais intenso podem se beneficiar do uso de anti-histamínicos com ação sedativa como o maleato de dexclorfeniramina<sup>69</sup> , com alívio momentâneo da coceira e consequente diminuição da formação de novas bolhas.  
O controle da dor crônica nas formas graves também deve ser realizado, com uso de analgésicos como ibuprofeno, dipirona, paracetamol e morfina antes da troca dos curativos, dos banhos e outros procedimentos dolorosos<sup>10</sup> . O controle da dor inclui componentes biopsicossociais, com a associação de terapia farmacológica, psicológica e de reabilitação<sup>63</sup> , e está estabelecido no Protocolo Clínico e Diretrizes Terapêuticas de Dor Crônica vigente no SUS<sup>69</sup> .  
Em caso de infecções extensas ou sistêmicas, pode ser necessário tratamento sistêmico com antibióticos por via oral ou intravenosa, de acordo com o tipo de agente patológico e da apresentação clínica do paciente<sup>9,10</sup> . Caso seja identificada infecção da cavidade bucal por _Candida sp_ , solução oral de nistatina pode ser preconizada.  
No **Quadro 2** encontram-se os principais fármacos que podem ser indicados na terapia do paciente com EB para controle de sintomas e cuidados com mucosas e pele.  
**Quadro 2 -** Principais fármacos indicados na terapia de pacientes com epidermólise bolhosa  
|**Fármacos**|**Apresentação**|
|---|---|
|**Analgésicos**|**e adjuvantes**|
|Ibuprofeno|Comprimidos de 200 mg, 300 mg e 600 mg<br>Suspensão oral de 50 mg/mL|
|Dipirona|Comprimidos de 500 mg<br>Solução oral de 500 mg/mL|
|Paracetamol|Comprimidos de 500 mg<br>Solução oral de 200 mg/mL|
|Sulfato de morfina|Solução injetável de 10 mg/mL<br>Solução oral de 10 mg/mL (frasco com 60 mL)<br>Comprimidos de 10 ou 30 mg<br>Cápsula de liberação prolongada de 30 ,60 ou 100<br>mg|
|Gabapentina|Cápsula de 300 ou 400 mg|
|**Anti-hist**|**amínicos**|
|Maleato de dexclorfeniramina|Comprimido de 2 mg<br>Xarope de 0,4 mg/mL<br>Solução oral de 0,4 mg/mL|
|**Polivitamínicos/ C**<br>|**ontrole da Anemia**<br>|
|Ácido fólico|Comprimidos de 1 mg<br>Solução oral de 0,2 mg/mL|
|Micronutrientes (vitamina A 400 mcg, vitamina D<br>5 mcg, vitamina E 5 mg, vitamina C 30 mg,<br>vitamina B1 0,5 mg, vitamina B2 0,5 mg, vitamina<br>B6 0,5 mg, vitamina PP 6 mg, vitamina B9 150<br>mcg, vitamina B12 0,9 mcg, ferro 10 mg, zinco 4,1<br>mg, cobre 560 mcg, selênio 17 mcg, iodo 90 mcg<br>pó)|Sachês de 1g|
|Sulfato ferroso|Xarope de 5 mg/mL<br>Solução oral de 25 mg/mL<br>Comprimido de 40 mg|
|**Cuidados c**|**om mucosas**|
|Hipromelose|Solução oftálmica de 3 mg/mL (0,3%)|
|Nistatina|Suspensão oral de 100.000 UI/mL|

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
As formas distróficas de EB, em especial a distrófica recessiva, podem evoluir com o surgimento de cicatrizes ou sinéquias que levam à fusão dos dedos das mãos e pés, com impacto psicossocial e funcional importantes. A prevenção desse tipo de complicação pode ser feita por meio de medidas simples, como o  
uso contínuo de curativos ditos especiais para separar os dedos ou pelo uso de luvas de tecido macio, sem costuras em contato com a pele.  
Nos casos em que ocorreu a fusão dos dedos (pseudossindactilia), há indicação de tratamento cirúrgico, que deve ser realizado por cirurgiões ortopedistas de mão. Entretanto, se após o procedimento, os cuidados com o uso das luvas para separação dos dedos não forem adotados, novas sinéquias podem surgir com o passar do tempo<sup>10</sup> .  
Como já abordado anteriormente, há também a necessidade de tratamento cirúrgico dos carcinomas espinocelulares, mais comumente observados em alguns subtipos de EB  
Alguns pacientes também necessitarão de gastrostomia ou traqueostomia, devido à formação de bolhas na orofaringe e esôfago, evoluindo com anquiloglossia, microstomia, estenoses de laringe, vestíbulo nasal e esôfago<sup>70</sup> .  
Durante o intraoperatório, a equipe multidisciplinar deve se atentar para alguns cuidados:  
- Manter a lubrificação ocular por meio do uso de colírios lubrificantes;  
- Manter monitorização de saturação de oxigênio com uso de oxímetros pediátricos;  
- Aplicar curativo dito especial no local em que será feita medida de pressão arterial;  
- Ter à disposição material de via aérea e instrumental cirúrgico pediátrico.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Um grande impacto na qualidade de vida, seja em função da dor física, dos custos do tratamento ou do estado emocional, é observado nos pacientes com EB e seus familiares, especialmente naqueles que apresentam formas distróficas e juncional, havendo a necessidade de apoio e tratamento multidisciplinar (médico, odontológico, psicológico, nutricional, de enfermagem, entre outros) contínuo. Está disponível, no Brasil, questionário validado para o português para a avaliação da qualidade de vida dos pacientes com EB<sup>71</sup> . Deve ser estimulada a formação de grupos de apoio, para troca de experiências, suporte e prevenção de isolamento social, bem como a adaptação dos ambientes de convívio social dos pacientes de EB de acordo com suas necessidades e capacidades<sup>11</sup> .  
Sugere-se o acompanhamento de paciente com EB seguindo um Projeto Terapêutico Singular (PTS) por equipe multiprofissional, sempre que possível. Quando não houver disponibilidade, é importante que este paciente e sua família tenham acesso regular a diferentes profissionais de saúde. No **Quadro 3** , seguem as especialidades e exames laboratoriais que devem ser monitorados, bem como sua frequência sugerida. O intervalo de avaliação pode ser alterado de acordo com a condição clínica e necessidades do paciente.  
**Quadro 3 -** Monitoramento do paciente com epidermólise bolhosa  
|**Acompanhamento**|**Sugestão de frequência**|
|---|---|
|**Equipe m**|**ultidisciplinar**|
|Psicologia|Encaminhar de acordo com a necessidade.|
|Psiquiatria|Encaminhar de acordo com a necessidade.|
|Odontologia|Encaminhar o paciente precocemente (3 – 6<br>meses de idade)<br>A cada 3-4 meses|
|Nutrição|A cada 3 – 4 meses|
|Dermatologia|A cada 3 – 6 meses|  
|Equipe saúde da família||
|---|---|
|Médico de Família<br>Enfermeira|Mensal<br>Semanal|
|Enfermagem (preferencialmente em estomaterapia ou<br>dermatologia,de acordo com tipo de EB)|A cada 6 meses|
|Fonoaudiologia|Semanal|
|Ortopedia|Encaminhar de acordo com a necessidade.|
|Cirurgia Geral|Encaminhar de acordo com a necessidade.|
|Gastroenterologista|A cada 6 meses|
|Geneticista|Ao diagnóstico e a cada 2 anos|
|Terapia Ocupacional(de acordo com tipo de EB)|Semanal|
|Fisioterapia(de acordo com tipo de EB)|Semanal|
|Pediatria|Encaminhar de acordo com a necessidade.|
|Cardiologia|Anual|
|Oftalmologia|Anual|
|Nefrologista|Anual|
|Endocrinologista|Anual|
|Hematologista|A cada 3 meses|
|Otorrinolaringologista|Anual|
|Pneumologista|Anual|
|Ginecologista|A cada 6 meses|
|**Exames laborat**|**oriais**|
|Hemograma, ureia, creatinina, sódio, potássio, cálcio,<br>fosfatos, vitamina D, proteínas totais (albumina),<br>fosfatase alcalina, zinco, ferro, ferritina, receptores de<br>transferrina,<br>reticulócitos,<br>velocidade<br>de<br>hemossedimentação (VHS), volume corpuscular médio<br>(VCM), proteína C-reativa (PCR), transaminase<br>glutâmico-oxalacética (TGO), transaminase glutâmico-<br>pirúvica(TGP), dosagem de glicose, triglicerídeos,<br>colesterol HDL, LDL e frações, hormônio folículo-<br>estimulante (FSH), hormônio luteinizante (LH),<br>hormônio estimulante da tireoide (TSH), T4 livre,<br>cortisol,<br>progesterona,<br>estrona,<br>prolactina,<br>dehidropiandrosterona (DHEA), androstenediona e<br>testosterona Vitamina B12,carnitina e folato.|A cada 6 meses – 1 ano|
|Adaptado de Haynes, 2007<sup>27</sup>e GDF, 2016<sup>72</sup>.||

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014<sup>73</sup> . A Política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e seu objetivo é: reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Básica e Atenção Especializada, em conformidade com a (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Básica é responsável  
pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na rede. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção básica.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras. Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de atenção especializada em doenças raras: presta serviço de saúde para uma ou mais doenças raras;  
- Serviço de referência em doenças raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, _para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica_ , o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para o Serviço de atenção especializada em doenças raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS e, se houver necessidade, o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade<sup>73</sup> , e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Básica e Atenção Especializada, em conformidade com a RAS, e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde<sup>4,73</sup> .  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis<sup>73</sup> .  
Cabe esclarecer que o cuidado aos pacientes para o tratamento de outras condições, tal como infecções e suporte psicológico, estão contemplados nestas Diretrizes, e os pacientes devem ser direcionados aos serviços de acordo com a sua manifestação clínica.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados nestas Diretrizes.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
1. Has, C., Bauer, J. W., Bodemer, C., Bolling, M. C., Bruckner-Tuderman, L., Diem, A., Fine, J. D., Heagerty, A., Hovnanian, A., Marinkovich, M. P., Martinez, A. E., McGrath, J. A., Moss, C., Murrell, D. F., Palisson, F., Schwieger-Briel, A., Sprecher, E., Tamai, K., Uitto, J., Woodley, D. T., … Mellerio, J. E. (2020). Consensus reclassification of inherited epidermolysis bullosa and other disorders with skin fragility. The British journal of dermatology, 183(4), 614–627. https://doi.org/10.1111/bjd.18921  
2. Kridin K, Kneiber D, Kowalski EH, Valdebran M, Amber KT. Epidermolysis bullosa acquisita: A comprehensive review. Autoimmun Rev. 2019;18(8):786-95  
3. Fine JD. Epidemiology of Inherited Epidermolysis Bullosa Based on Incidence and Prevalence Estimates From the National Epidermolysis Bullosa Registry. JAMA Dermatol. 2016;152(11):1231-8  
4. Brasil. Ministério da Saúde. Portaria Nº 199/GM/MS, DE 30 DE JANEIRO DE 2014. Institui a Política Nacional de Atenção Integral às Pessoas com Doenças Raras, aprova as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do Sistema Único de Saúde (SUS) e institui incentivos financeiros de custeio. In: Ministro MdSGd, editor. Brasília, DF: Ministério da Saúde; 2014.  
5. Brasil. Diretrizes para Atenção integral às Pessoas com Doenças Raras no Sistema Único de Saúde – SUS. In: Saúde Md, editor. Brasília: Ministério da Saúde; 2014.  
6. NANDA-I. Diagnósticos de Enfermagem da NANDA: definições e classificação - 2018-2020.Trad. Regina Machado Garcez. Porto Alegre: Artmed, 2018.  
7. Oliveira  Z, Machado , MCR, Fernandes ,JD, Junior. Genodermatoses Bolhosas. In: Atheneu, editor. Walter Belda; Chiacchio, Nilton Di; Criado, Paulo Ricardo Tratado de dermatologia. 3ª ed. São Paulo2018. p. 1739-48  
8. Mariath LM, Santin JT, Schuler-Faccini L, Kiszewski AE. Inherited epidermolysis bullosa: update on the clinical and genetic aspects. An Bras Dermatol. 2020;95:551-69  
9. Denyer J PE, Clapham J. Best practice Guidelines for skin and wound care in epidermolysis bullosa: international consensus. Wounds International. 2017.  
10. Clapham; JDEPJ. Best Practice Guidelines: Skin and wound care in EPIDERMOLYSIS BULLOSA. An expert working group consensus. Wounds International; 2017  
11. Martin K, Geuens S, Asche JK, Bodan R, Browne F, Downe A, et al. Psychosocial recommendations for the care of children and adults with epidermolysis bullosa and their family: evidence based guidelines. Orphanet Journal of Rare Diseases. 2019;14(1):133.  
12. Fine JD, Bruckner-Tuderman L, Eady RA, Bauer EA, Bauer JW, Has C, et al. Inherited epidermolysis bullosa: updated recommendations on diagnosis and classification. J Am Acad Dermatol. 2014;70(6):1103-26  
13. Kiritsi D, Has C, Bruckner-Tuderman L. Laminin 332 in junctional epidermolysis bullosa. Cell Adh Migr. 2013;7:135---41  
14. Yuen WY, Lemmink HH, van Dijk-Bos KK, Sinke RJ, Jonkman MF. Herlitz junctional epidermolysis bullosa: diagnostic features, mutational profile, incidence and population carrier frequency in the Netherlands. Br J Dermatol. 2011;165:1314---22.  
15. Yenamandra VK, Vellarikkal SK, Kumar M, Chowdhury MR, Jayarajan R, Verma A, et al. Application of whole exome sequencing in elucidating the phenotype and genotype spectrum of junctional epidermolysis bullosa: A preliminary experience of a tertiary care centre in India. J Dermatol Sci. 2017;86:30---6.  
16. Kiritsi D, Kern JS, Schumann H, Kohlhase J, Has C, Bruckner- Tuderman L. Molecular mechanisms of phenotypic variability in junctional epidermolysis bullosa. J Med Genet. 2011;48: 450---7.  
17. Yancey KB, Hintner H. Non-herlitz junctional epidermolysis bullosa. Dermatol Clin. 2010;28:67---77  
18. Mencía Á, García M, García E, Llames S, Charlesworth A, de Lucas R, et al. Identification of two rare and novel large deletions in ITGB4 gene causing epidermolysis bullosa with pyloric atresia. Exp Dermatol. 2016;25:269---74.  
19. Varki R, Sadowski S, Uitto J, Pfendner E. Epidermolysis bullosa II. Type VII collagen mutations and phenotype- -genotype correlations in the dystrophic subtypes. J Med Genet. 2007;44:181---92.  
20. Fine JD. Inherited epidermolysis bullosa. Orphanet J Rare Dis. 2010; 5: 12.  
21. Chiaverini C, Charlesworth AV, Youssef M, Cuny JF, Rabia SH, Lacour JP, et al. Inversa dystrophic epidermolysis bullosa is caused by missense mutations at specific positions of the collagenic domain of collagen type VII. J Invest Dermatol. 2010;130:2508---11.  
22. Fine JD, Eady RA, Bauer EA, Bauer JW, Bruckner-Tuderman L, Heagerty A, et al. The classification of inherited epidermolysis bullosa (EB): Report of the Third International Consensus Meeting on Diagnosis and Classification of EB. J Am Acad Dermatol. 2008;58:931---50.  
23. McGrath JA, Schofield OM, Eady RA. Epidermolysis bullosa pruriginosa: dystrophic epidermolysis bullosa with distinctive clinicopathological features. Br J Dermatol. 1994;130:617---25.  
24. Orphanet. The portal for rare diseases and orphan drugs: Epidermolysis bullosa acquisita 2019 [Available from: https://www.orpha.net/consor/cgi-bin/OC_Exp.php?lng=EN&Expert=46487  
25. Krämer SM SM, Zillmann G, Gálvez P, Araya I, Yanine N, Carrasco-Labra A, Oliva P, BrignardelloPetersen R, Villanueva J. Oral Health Care for Patients with Epidermolysis Bullosa - Best Clinical Practice Guidelines. International Journal of paediatric Dentistry. 2012;22(Suppl.1):1-35  
26. Salera S TG, Rossetti D, Grassi FS, Marchicio P, Agostini C, Giavoli C, Rodari G, Guez S. A nutritionbased approach to epidermolysis bullosa: Causes, assessments, requirements and management. Clinical Nutrition. 2019  
27. Haynes L. Clinical Practice Guidelinesfor Nutrition Supportin: Infants and Children with Epidermolysis Bullosa (EB) including THINC (Tool to Help IdentifyNutritional Compromise in EB). Supported by an educational grant from SHS-Nutricia, 2007. Disponível em: chromeextension://efaidnbmnnnibpcajpcglclefindmkaj/viewer.html?pdfurl=https%3A%2F%2Fwww.debra.o rg.uk%2Fdownloads%2Fcommunity-support%2Feb-clinical-practice-guidelines-nutrition-inchildren-100613.pdf&clen=709061&chunk=true  
28. Zidorio AP LD, Dutra ES, Costa IMC. Nutritional aspects of children and adolescents with epidermolysis bullosa: literature review. Anais Brasileiros de Dermatologia. 2015;90(2):217-23.  
29. Schwieger-Briel A, Fuentes I, Castiglia D, Barbato A, Greutmann M, Leppert J, et al. Epidermolysis Bullosa Simplex with KLHL24 Mutations Is Associated with Dilated Cardiomyopathy. The Journal of investigative dermatology. 2019;139(1):244-9.  
30. Has C, Sparta G, Kiritsi D, Weibel L, Moeller A, Vega-Warner V, et al. Integrin alpha3 mutations with kidney, lung, and skin disease. The New England journal of medicine. 2012;366(16):1508-14  
31. Vahidnezhad H, Youssefian L, Saeidian AH, Touati A, Pajouhanfar S, Baghdadi T, et al. Mutations in PLOD3, encoding lysyl hydroxylase 3, cause a complex connective tissue disorder including recessive dystrophic epidermolysis bullosa-like blistering phenotype with abnormal anchoring fibrils and type VII collagen deficiency. Matrix biology : journal of the International Society for Matrix Biology. 2019;81:91-106.  
32. Feinstein JA, Jambal P, Peoples K, Lucky AW, Khuu P, Tang JY, et al. Assessment of the Timing of Milestone Clinical Events in Patients With Epidermolysis Bullosa From North America. JAMA Dermatol. 2019;155(2):196-203.  
33. Henneman L, Borry P, Chokoshvili D, Cornel MC, van El CG, Forzano F, et al. Responsible implementation of expanded carrier screening. Eur J Hum Genet. 2016;24(6):e1-e12  
34. Klausegger A, Pulkkinen L, Pohla-Gubo G, Dallinger G, Puttinger R, Uitto J, et al. Is screening of the candidate gene necessary in unrelated partners of members of families with Herlitz junctional epidermolysis bullosa? The Journal of investigative dermatology. 2001;116(3):474-5  
35. <mark>Mariath, L. M., Santin, J. T., Frantz, J. A., Doriqui, M., Kiszewski, A. E., & Schuler-Faccini, L. (2019). An overview of the genetic basis of epidermolysis bullosa in Brazil: discovery of novel and recurrent disease-causing variants.</mark> _<mark>Clinical genetics</mark>_ <mark>,</mark> _<mark>96</mark>_ <mark>(3), 189–198. https://doi.org/10.1111/cge.13555</mark>  
36. Benício CDAV, Carvalho NAR, Santos JDM, Sá IRG, Luz MHBA. Epidermólise Bolhosa: Foco na Assistência de Enfermagem. ESTIMA, v.14 n.2, p. 91-98, 2016 <mark>https://doi.org/10.5327/Z18063144201600020007</mark>  
37. <mark>Jain, SV, Harris, AG, Su, JC, Orchard, D., Warren, LJ, McManus, H., & Murrell, DF (2017).</mark> The Epidermolysis Bullosa Disease Activity and Scarring Index (EBDASI): grading disease severity and assessing responsiveness to clinical change in epidermolysis bullosa <mark>.</mark> _<mark>Jornal da Academia Europeia de Dermatologia e Venereologia: JEADV</mark>_ <mark>,</mark> _<mark>31</mark>_ <mark>(4), 692-698. https://doi.org/10.1111/jdv.13953</mark>  
38. <mark>Wagner, J. E., Ishida-Yamamoto, A., McGrath, J. A., Hordinsky, M., Keene, D. R., Woodley, D. T., Chen, M., Riddle, M. J., Osborn, M. J., Lund, T., Dolan, M., Blazar, B. R., & Tolar, J. (2010). Bone marrow transplantation for recessive dystrophic epidermolysis bullosa.</mark> _<mark>The New England journal of medicine</mark>_ <mark>,</mark> _<mark>363</mark>_ <mark>(7), 629–639. https://doi.org/10.1056/NEJMoa0910501</mark>  
39. <mark>World Union of Wound Healing Societies (2020) Strategies to reduce practice variation in wound assessment and management: The T.I.M.E. Clinical Decision Support Tool. London: Wounds International.</mark>  
40. <mark>Venugopal, S. S., & Murrell, D. F. (2010). Treatment of skin cancers in epidermolysis bullosa.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 283–x. https://doi.org/10.1016/j.det.2010.01.009</mark>  
41. <mark>Kantor, J., & Margolis, D. J. (2000). A multicentre study of percentage change in venous leg ulcer area as a prognostic index of healing at 24 weeks.</mark> _<mark>The British journal of dermatology</mark>_ <mark>,</mark> _<mark>142</mark>_ <mark>(5), 960–964. https://doi.org/10.1046/j.1365-2133.2000.03478.x</mark>  
42. Petersen BW, Arbuckle HA, Berman S. Effectiveness of Saltwater Baths in the Treatment of Epidermolysis Bullosa. Pediatric Dermatology. 2015;32(1):60-3.  
43. Weir D, Swanson T (2019) Ten top tips: wound cleansing. Wounds International 10(4): 8-11  
44. LeBlanc K, Beeckman D, Campbell K et al (2021) _Best practice recommendations for prevention and management of periwound skin complications._ Wounds International  
45. <mark>Denyer J. E. Wound management for children with epidermolysis bllosa.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 257–ix, 2010. https://doi.org/10.1016/j.det.2010.01.002</mark>  
46. El Hachem M, Zambruno G, Bourdon-Lanoy E, Ciasulli A, Buisson C, Hadj-Rabia S, et al. Multicentre consensus recommendations for skin care in inherited epidermolysis bullosa. Orphanet J Rare Dis. 2014;9:76  
47. Pope E, Lara-Corrales I, Mellerio J, Martinez A, Schultz G, Burrell R, et al. A consensus approach to wound care in epidermolysis bullosa. J Am Acad Dermatol. 2012;67(5):904-17.  
48. <mark>Liy-Wong, C., Cepeda-Valdes, R., & Salas-Alanis, J. C. Epidermolysis bullosa care in Mexico.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 393–xiii, 2010. https://doi.org/10.1016/j.det.2010.02.014</mark>  
49. <mark>Mellerio J. E. Epidermolysis bullosa care in the United Kingdom.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 395– xi, 2010. https://doi.org/10.1016/j.det.2010.02.015</mark>  
50. <mark>Arbuckle H. A. Epidermolysis bullosa care in the United States.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 387–xiii, 2010. https://doi.org/10.1016/j.det.2010.02.012</mark>  
51. Conselho Federal de Enfermagem (COFEN). Resolução n º 567/2018 que regulamenta a atuação da equipe de enfermagem no cuidado aos pacientes com feridas  
52. <mark>Shin, KC, Park, BY, Kim, HK, Kim, WS e Bae, TH. O uso de enxerto de ceratinócitos alogênicos cultivados em um paciente com epidermólise bolhosa simplex.</mark> _<mark>Annals of dermatology</mark>_ <mark>,</mark> _<mark>23</mark>_ <mark>(Suppl 3), S393 – S397, 2011. https://doi.org/10.5021/ad.2011.23.S3.S393</mark>  
53. <mark>Bruckner-Tuderman L. Epidermolysis bullosa care in Germany.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 405–xiv, 2010. https://doi.org/10.1016/j.det.2010.02.020</mark>  
54. <mark>Sibbald, R. G., Woo, K., & Ayello, E. A. Increased bacterial burden and infection: the story of NERDS and STONES.</mark> _<mark>Advances in skin & wound care</mark>_ <mark>,</mark> _<mark>19</mark>_ <mark>(8), 447–463, 2006. https://doi.org/10.1097/00129334-200610000-00012</mark>  
55. <mark>Goldschneider, K. R., & Lucky, A. W. Pain management in epidermolysis bullosa.</mark> _<mark>Dermatologic clinics</mark>_ <mark>,</mark> _<mark>28</mark>_ <mark>(2), 273–ix, 2010. https://doi.org/10.1016/j.det.2010.01.008</mark>  
56. <mark>Anand K. J. Clinical importance of pain and stress in preterm neonates.</mark> _<mark>Biology of the neonate</mark>_ <mark>,</mark> _<mark>73</mark>_ <mark>(1), 1–9, 1998. https://doi.org/10.1159/000013953</mark>  
57. <mark>Allegaert, K., & Naulaers, G. Gabapentin as part of multimodal analgesia in a newborn with epidermolysis bullosa.</mark> _<mark>Paediatric anaesthesia</mark>_ <mark>,</mark> _<mark>20</mark>_ <mark>(10), 972–973, 2010. https://doi.org/10.1111/j.14609592.2010.03396.x</mark>  
58. <mark>Wang, P. H., Huang, B. S., Horng, H. C., Yeh, C. C., & Chen, Y. J. Wound healing. Journal of the Chinese Medical Association : JCMA, 81(2), 94–101, 2018. https://doi.org/10.1016/j.jcma.2017.11.002</mark>  
59. Campos, Antonio Carlos Ligocki, Borges-Branco, Alessandra e Groth, Anne Karoline. Cicatrização de feridas. ABCD. Arquivos Brasileiros de Cirurgia Digestiva (São Paulo) , 20 (1), 51-58, 2007. https://doi.org/10.1590/S0102-67202007000100010  
60. <mark>Öztürk, F., & Ermertcan, A. T. Wound healing: a new approach to the topical wound care.</mark> _<mark>Cutaneous and ocular toxicology</mark>_ <mark>,</mark> _<mark>30</mark>_ <mark>(2), 92–99, 2011. https://doi.org/10.3109/15569527.2010.539586</mark>  
61. Celestino VP, Maestri G, Bierhalz ACK, Immich APS. Produção e caracterização de hidrogel de carboximetilcelulose para aplicação na área de curativos biomédicos. 14° Congresso da Sociedade Latino Americana de Biomateriais, Orgãos Artificiais e Engenharia de Tecidos – SLABO. 5ª Edição do Workshop de Biomateriais, Engenharia de Tecidos e Orgãos Artificiais – São Paulo, Brasil; 2017. Disponível em: http://www.metallum.com.br/obi2017/anais/PDF/02-231.pdf  
62. Westby MJ, Norman G, Dumville JC, Stubbs N, Cullum N.Protease modulating matrix treatments for healing venous leg ulcers. [internet] 2016 [acesso em 10 de ago 2017    ] Cochrane Database of Systematic Reviews. Issue12. Art. No.: CD011918. Disponível em: 10.1002/14651858.CD011918.pub2.  
63. Fine JD HH. Life with Epidermolysis bullosa (EB): Etiology, diagnosis, multidisciplinary care and therapy. Austria: SpringerWien New York; 2009  
64. Wright. JT. Oral Manifestations of Epidermolysis Bullosa. . In: Fine JD BE, McGuire J, Moshell A, editor. Epidermolysis Bullosa Clinical, Epidemiologic, and Laboratory Advances and the Findings of the National Epidermolysis Bullosa Registry. Baltimore, MD: The Johns Hopkins University Press; 1999. p. 236-56.  
65. Lozada-Nur F KM, Mendez M, McGuirre J, Ortega E. Guidelines for patients with oral epidermolysisbullosa (EB): dental and oral care. 1997  
66. Gagnier JJ. CHAPTER 19 - Nutritional, Herbal, and Homeopathic Supplements. In: Dagenais S, Haldeman S, editors. Evidence-Based Management of Low Back Pain. Saint Louis: Mosby; 2012. p. 258-68  
67. Colomb V, Bourdon-Lannoy E, Lambe C, Sauvat F, Hadj Rabia S, Teillac D, et al. Nutritional outcome in children with severe generalized recessive dystrophic epidermolysis bullosa: a short- and long-term evaluation of gastrostomy and enteral feeding. Br J Dermatol. 2012;166(2):354-61.  
68. Danial C, Adeduntan R, Gorell ES, Lucky AW, Paller AS, Bruckner A, et al. Prevalence and characterization of pruritus in epidermolysis bullosa. Pediatr Dermatol. 2015;32(1):53-9.  
69. DoHRoHaSSN. Dietary Reference Values for Food Energy and Nutrients for the United Kingdom. In: Subject DoHRoHaS, editor. London: The Stationery Office; 1991  
70. Fantauzzi RSea. Manifestações otorrinolaringológicas e esofágicas da epidermólise bolhosa. Rev Bras Otorrinolaringol. 2008;74(5):657-61  
71. Cestari T, Prati C, Menegon DB, Prado Oliveira ZN, Machado MC, Dumet J, et al. Translation, crosscultural adaptation and validation of the Quality of Life Evaluation in Epidermolysis Bullosa instrument in Brazilian Portuguese. Int J Dermatol. 2016;55(2):e94-9  
72. Federal GdD. Portaria SES-DF Nº 29 de 1° de Março de 2016. Protocolo de tratamento para pacientes portadores de epidermólise bolhosa. In: SAIS/SES-DF CdDeGdEd, editor. Brasília: Diário Oficial do Distrito Federal; 2016  
73. Brasil. Ministério da Saúde. Doenças raras: o que são, causas, tratamento, diagnóstico e prevenção Brasília, DF: Ministério da Saúde; 2019 [Available from: http://www.saude.gov.br/saude-de-az/doencas-raras  
74. Brasil Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Pauta da 82ª Reunião do Plenário. Disponível em:  http://conitec.gov.br/images/Reuniao_Conitec/2019/Pauta_82Reuniao.pdf. Acesso em: 20 de julho de 2020.  
75. Brasil. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Ata da 82ª Reunião do Plenário. Disponível em: http://conitec.gov.br/images/Reuniao_Conitec/2019/Ata_82_Reuniao.pdf. Acesso em: 20 de julho de 2020  
76. Shea BJ RB, Wells G, Thuku M, Hammel C, Moran J, Moher J, Tugwell P, Welch V, Kristjansson E, Henry DA. AMSTAR 2: a critical apparaisal tool for systematic reviews that ionclude randomised or non randomised studies of healthcare interventions, or both. BMJ. 2017;358.  
77. Schwieger-Briel A, Kiritsi D, Schempp C, Has C, Schumann H. Betulin-based oleogel to improve wound healing in dystrophic epidermolysis bullosa: A prospective controlled proof-of-concept study. Dermatology Research and Practice. 2017;2017.  
78. Bafaraj MG, Cesko E, Weindorf M, Dissemond J. Chronic leg ulcers as a rare cause for the first diagnosis of epidermolysis bullosa dystrophica. International Wound Journal. 2014;11(3):274-7.  
79. Kim M, Jain S, Harris AG, Murrell DF. Colchicine may assist in reducing granulation tissue in junctional epidermolysis bullosa. International Journal of Women's Dermatology. 2016;2(2):56-9.  
80. Graham T, Sooriah S, Giampieri S, Box R, Grocott P. Iterative codesign and testing of a novel dressing glove for epidermolysis bullosa. J Wound Care. 2019;28(1):5-14.  
81. Kao CH, Chen SJ, Hwang B, Yang AH, Hsu CY, Huang CH. Junctional epidermolysis bullosa. J Chin Med Assoc. 2006;69(10):503-6.  
82. Denyer J, Marsh C, Kirsner RS. Keratin gel in the management of Epidermolysis bullosa. J Wound Care. 2015;24(10):446-50.  
83. Sürücü HA, Yeşilova Y, Turan E, Aksoy M, Tanrikulu O, Eroglu N. Lack of effectiveness of keratin dressings in epidermolysis bullosa. Indian Journal of Dermatology, Venereology and Leprology. 2015;81(1):91-2.  
84. Çetin C, Köse AA, Karabaǧli Y, Özyilmaz M. Lyophilised polyurethane membrane dressing for surgically-separated pseudosyndactyly in epidermolysis bullosa. Scandinavian Journal of Plastic and Reconstructive Surgery and Hand Surgery. 2003;37(4):245-7.  
85. Williams C. Mepitel. Br J Nurs. 1995;4(1):51-2, 4-5.  
86. Hagele T, Metterle L, Nelson G, Divine J, Seminario-Vidal L, Patel N. A novel approach to pretibial epidermolysis bullosa: A case report and literature review. Journal of the American Academy of Dermatology. 2016;74(5):AB141.  
87. Kern JS, Schwieger-Briel A, Löwe S, Sumeray M, Davis C, Martinez AE. Oleogel-S10 Phase 3 study "eASE" for epidermolysis bullosa: Study design and rationale. Trials. 2019;20(1).  
88. Venugopal SS, Intong LR, Cohn HI, Mather-Hillon J, Murrell DF. Responsiveness of nonHerlitz Junctional Epidermolysis Bullosa to topical gentian violet. International Journal of Dermatology. 2010;49(11):1282-5.  
89. Kirsner RS, Cassidy S, Marsh C, Vivas A, Kelly RJ. Use of a keratin-based wound dressing in the management of wounds in a patient with recessive dystrophic epidermolysis bullosa. Adv Skin Wound Care. 2012;25(9):400-3.  
90. Jutkiewicz J, Noszczyk BH, Wrobel M. The use of Biobrane for hand surgery in Epidermolysis bullosa. J Plast Reconstr Aesthet Surg. 2010;63(8):1305-11.  
91. Denyer J, Gibson E. Use of fibre dressings in children with severe epidermolysis bullosa. Br J Nurs. 2015;24(6):S38, S40-3.  
92. Hon J. Using honey to heal a chronic wound in a patient with epidermolysis bullosa. Br J Nurs. 2005;14(19):S4-5, S8, S10 passim.  
**<mark>APÊNDICE 1</mark>**

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Descreve-se a seguir metodologia utilizada para detalhar o tratamento não medicamentoso do paciente com epidermólise bolhosa. As buscas foram realizadas pela equipe da Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas – CGPCD/DGITIS/SCTIE/MS, a fim de atualizar o texto publicado, pela Portaria Conjunta/SAES e SCTIE/MS n<sup>o</sup> 11, de 26/06/2020, como Protocolo Clínico e Diretrizes Terapêuticas da Epidermólise Bolhosa Hereditária e Adquirida,  razões pelas quais adiante se mantém o registro da elaboração desse PCDT que evoluiu para as presentes Diretrizes Brasileiras para os Cuidados de Pacientes com Epidermólise Bolhosa.  
Considerando que as alternativas terapêuticas tópicas empregadas no tratamento de feridas são um campo de intensa inovação, foram buscados estudos publicados nos últimos cinco anos de forma a obter recomendações apropriadas para orientar a prática clínica.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
As estratégias de busca encontram-se detalhadas no **Quadro A.**  
**Quadro A -** Estratégias de busca nas bases de dados PubMed e Cochrane  
|**Base de dados**|**Estratégia de busca**|**Número de**<br>**estudos**|
|---|---|---|
||((Bullous Epidermolysis) AND (Treatment of Injuries))|2|
||((Bullous Epidermolysis) AND (Bandages))|1|
||((Bullous Epidermolysis) AND (wound))|7|
|Pubmed|((Bullous Epidermolysis) AND (Injuries))|3|
||((Bullous Epidermolysis) AND (Itching))|5|
||((Bullous Epidermolysis) AND (Pain))|2|
||((Bullous Epidermolysis) AND (Wound care))|4|
||# 1 MeSH descriptor: [Epidermolysis Bullosa] explode all trees||
|Cochrane|# 2 MeSH descriptor: [Wounds and Injuries] this term only|166|
||# 1 AND # 2||  
**B. Seleção das evidências**  
Dos 24 estudos encontrados no Pubmed, 17 foram excluídos a partir da leitura dos títulos e resumos e foram selecionados 4 estudos após a leitura completa. No Cochrane, foi utilizado o filtro “ _wounds_ ” e foram encontrados 166 estudos. Desses, 152 foram excluídos a partir da leitura dos títulos e resumos e foram selecionados 3 após a leitura completa. Os critérios de inclusão usados na seleção dos estudos foram: abordar pacientes com EB; prevenção ou tratamento de feridas e coberturas tópicas. Foram adicionados 30 estudos a partir da busca por referências bibliográficas dos artigos selecionados. Um total de 37 estudos foram selecionados para confecção desse relatório. Os tipos de evidência incluíram revisões narrativas, relatos de casos e opiniões de especialistas.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A partir dos 37 estudos selecionados, foram extraídas informações referentes à gestão do paciente com feridas relacionadas à EB.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Epidermólise Bolhosa (EB) teve início com uma reunião presencial para delimitação do escopo do PCDT. Esta reunião foi composta por três membros do Comitê Gestor, pela diretora do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS) e por sete membros do grupo elaborador, sendo quatro especialistas (duas dermatologistas, uma dentista e uma nutricionista), três metodologistas, sendo dois farmacêuticos e uma enfermeira. Ademais, participaram também uma representante da Sociedade Brasileira de Genética Médica (SBGM) e uma representante da Associação Mineira de Parentes, Amigos e Portadores de Epidermólise Bolhosa (AMPAPEB), ligada à DEBRA Brasil. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do Protocolo, conforme o disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009<sup>66</sup> e nas Diretrizes para Elaboração de Diretrizes Clínicas, do Ministério da Saúde<sup>67</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias poderiam ser identificadas. Deste modo, os especialistas foram orientados a elencar questões de pesquisa, estruturadas segundo o acrônimo PICO ( **Figura A** ), para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Foram consideradas tecnologias registro ativo na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião.  
|P|• População ou condição patológica.|
|---|---|
|I|• Intervenção, no caso de estudos experimentais.<br>• Fator de exposição, em caso de estudos observacionais.<br>• Teste índice, nos casos de estudos de acurácia diagnóstica.|
|C|• Controle, de acordo com tratamento/níveis de exposição do<br>fator/exames disponíveis no SUS.|
|O|• Desfechos: sempre que possível, definidos_a priori_, de acordo<br>com sua importância.|  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.  
Assim, na ausência de questão de pesquisa, os especialistas foram orientados a referir a recomendação de acordo com os estudos que consolidaram a prática clínica. As recomendações sobre o diagnóstico, a classificação, o cuidado da pele, o cuidado de neonatos, o cuidado bucal, a nutrição e a monitorização necessária deveriam ser escritas com base na _expertise_ do grupo (profissionais com experiência no cuidado de pacientes com EB e metodologistas) e na melhor evidência advinda de _guidelines_ da literatura internacional.  
Com relação ao tratamento da EB, uma pergunta de pesquisa sobre curativos ditos especiais para o tratamento de lesões bolhosas foi levantada a fim de estruturar a elaboração de um Parecer Técnico Científico (PTC) para avaliação da Conitec, detalhada no item 3 deste Apêndice. Acordou-se que a equipe de metodologistas envolvida no processo ficaria responsável pela busca e avaliação de evidências, segundo a metodologia GRADE.  
Por fim, o grupo elaborador definiu as seções do documento (introdução, elegibilidade, diagnóstico, tratamento e monitorização), bem como estabeleceu conteúdos mínimos para cada uma destas seções. A relatoria do documento foi distribuída entre os especialistas, por seções, e foram acordados prazos para a entrega da versão inicial dos textos.

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Foram buscados os principais _guidelines_ relacionados ao diagnóstico e cuidado de paciente com EB, os quais estão disponíveis no site EB Clinet (https://www.eb-clinet.org/clinical-guidelines/completed-ebguidelines/), em uma parceria com a Organização DEBRA. Entre os _guidelines_ utilizados, destacam-se as bases diagnósticas e os cuidados de feridas e bolhas, bucal e o nutricional. A informação recuperada dos _guidelines_ foi complementada com evidências advindas de outras fontes, conforme a _expertise_ do grupo de especialistas, e adaptada para atender à realidade brasileira.  
Dessa forma, as recomendações sobre o diagnóstico, a classificação, o cuidado da pele, o cuidado de neonatos, o cuidado bucal, a nutrição e a monitorização necessária foram elaboradas com base na  
_expertise_ do grupo (profissionais com experiência no cuidado de pacientes com EB e metodologistas) e na melhor evidência advinda de _guidelines_ da literatura internacional.  
De acordo com o explicitado no item 1, foi elaborada uma pergunta PICO especificamente para avaliação das principais formas de curativos não aderentes para a cuidado da pele em casos de EB (Questão 1), cujos aspectos metodológicos encontram-se descritos no item 3 - Busca na literatura para elaboração do parecer técnico-científico sobre curativos especiais.  
Em decorrência da pergunta PICO definida na reunião de escopo deste PCDT, foi elaborado um parecer técnico científico (PTC) sobre os “curativos especiais para o tratamento da epidermólise bolhosa”, sendo necessária a avaliação da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) quanto à incorporação específica dessas tecnologias no SUS.  
Assim, o tema foi pautado à 82ª Reunião Ordinária do Plenário da Conitec<sup>73</sup> , realizada nos dias 09 e 10 de outubro de 2019. Após as discussões do Plenário, foi registrado em ata<sup>75</sup> que, em razão da diversidade de produtos existentes no mercado, os membros presentes **deliberaram por não analisar o PTC com a avaliação dos curativos especiais** , e recomendaram a alteração do procedimento de tratamento de afecções bolhosas vigente no Sistema Único de Saúde (SUS) para contemplar os custos dos curativos especiais.  
Dessa forma, para operacionalizar o acesso ao tratamento das lesões de pacientes com epidermólise bolhosa no SUS, o Plenário da Conitec recomendou utilizar procedimentos já disponíveis na Tabela de Medicamentos, Procedimentos, Órteses/Próteses e Materiais Especiais do SUS, com a ressalva de que a descrição e atributos destes procedimentos deveriam ser adaptadas para contemplar as necessidades especificadas no PCDT.  
Muitos são os procedimentos de consultas, atendimentos ambulatoriais, atendimentos domiciliares, atendimentos hospitalares e atendimentos em hospital-dia, diagnósticos e terapêuticos, clínicos e cirúrgicos, médicos e não médicos, uni- e multidisciplinares, dessa Tabela que são aplicáveis às pessoas com suspeita ou diagnóstico de epidermólise bolhosa, com ou sem a obrigatoriedade de se informar o respectivo código da CID como atributo. A leitura das descrições dos procedimentos (disponíveis em http://sigtap.datasus.gov.br/) explicitam a que cada procedimento se destina. Especificamente, citam-se:  
- 03.01.01.003-0 - Consulta de profissionais de nível superior na atenção primária (exceto médico);  
- 03.01,01.004-8 - Consulta de profissionais de nível superior na atenção especializada (exceto médico);  
- 03.01.01.006-4 - Consulta médica em atenção primária;  
- 03.01.01.007-2 - Consulta médica em atenção especializada;  
- 03.01.05.002-3 - Assistência domiciliar por equipe multiprofissional;  
- 03.01.05.003-1 - Assistência domiciliar por equipe multiprofissional na atenção especializada;  
- 03.03.08.004-3 - Tratamento de afecções bolhosas; e  
- 03.01.10.027-6 - Curativo especial.  
Entre estes, dos procedimentos que exigem o atributo CID, somente o 03.03.08.004-3 - Tratamento de afecções bolhosas carece da inclusão dos códigos de epidermólise bolhosa hereditária (Q81.0, Q81.1, Q81,2, Q81.8 e Q81.9), uma vez que já inclui o da epidermólise bolhosa adquirida (L12.3).

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
Para fins de registro, a seguir está detalhada a metodologia utilizada para a elaboração do Parecer Técnico-Científico (PTC) apresentado à Conitec em outubro de 2019, o qual não foi analisado pelo Plenário da Conitec por motivos relatados no item 2 nem utilizado como base para as recomendações deste Protocolo.  
Com relação ao tratamento da EB, uma pergunta de pesquisa sobre curativos especiais para o tratamento de lesões bolhosas foi levantada a fim de estruturar a seguinte pergunta PICO:  
**Questão 1: “O uso de curativos especiais é eficaz, seguro e custo-efetivo em pacientes com Epidermólise Bolhosa? ”**  
Nesta pergunta, pacientes (P) eram pessoas com EB; intervenções (I) eram curativos especiais; comparadores (C) eram outros curativos; e desfechos (O) Tempo de cicatrização, tempo para reepitelização, qualidade de vida, preferências de pacientes e profissionais da saúde e eventos adversos.  
A questão de pesquisa foi respondida por uma única estratégia de busca. Deste modo, a busca na literatura foi realizada nas bases PubMed e Embase e validadas no Google Scholar, Epistemonikos e CINAHL. A estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por dois metodologistas, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise poderia ser considerada. Quando a revisão sistemática não tinha meta-análise, foram considerados os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia e segurança. Adicionalmente, checou-se a identificação de estudos adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas, por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e observacionais. Considerando a natureza da doença, séries e relatos de casos também foram consideradas para inclusão. Os estudos excluídos na fase 3 (leitura completa) tiveram suas razões de exclusão relatadas  
e referidas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. Essa extração foi feita por um metodologista e revisada por um segundo, em uma única planilha de Excel<sup>®</sup> . As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess Systematic Reviews 2_ (AMSTAR-2)<sup>75</sup> ; os ensaios clínicos randomizados, pela ferramenta de risco de viés da Cochrane<sup>58</sup> ; e os estudos observacionais, pela ferramenta NewcastleOttawa<sup>78</sup> . Séries e relatos de caso foram considerados como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao seu desenho.  
Após a finalização da extração dos dados, as tabelas e quadros aqui apresentados foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluations_ )<sup>79</sup> , de forma narrativa, visto que, em virtude da heterogeneidade dos dados, não foi possível conduzir meta-análise do conjunto de evidências. O conjunto de evidências foi avaliado para cada desfecho considerado neste Protocolo, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles.  
Após a conclusão do Relatório de Recomendação sobre os curativos especiais, iniciou-se o trabalho de revisão, escrita e harmonização do texto do PCDT para a apresentação conjunta ao Plenário da Conitec. O texto final foi revisado pelas especialistas participantes da reunião de escopo e encaminhado ao Comitê Gestor para que fossem feitas a revisão do texto e as contribuições acerca do conteúdo. As etapas metodológicas são detalhadas a seguir.  
**Questão de pesquisa: “O uso de curativos especiais é eficaz, seguro e custo-efetivo em pacientes com Epidermólise bolhosa? ”**  
- D. **Estratégia de busca**  
As estratégias de busca encontram-se detalhadas no **Quadro B.**  
**Quadro B -** Estratégias de busca nas bases de dados PubMed e Embase  
|**Base de da**|**dos**|**Estratégia de Busca**||**Resultados**|
|---|---|---|---|---|
|Medline<br>Pubmed|via|(("Poikiloderma of<br>Poikiloderma of Kind<br>Bullosa"[Mesh] OR|Kindler" [Supplementary Concept] OR<br>ler OR Kindler syndrome OR "Epidermolysis<br>Epidermolysis bullosa OR "Epidermolysis|90|  
|**Base de dados**|**Estratégia de Busca**|**Resultados**|
|---|---|---|
||Bullosa Simplex"[Mesh] OR Epidermolysis Bullosa simplex OR<br>"Epidermolysis Bullosa, Junctional"[Mesh] OR Epidermolise<br>Bullosa junctional OR "Epidermolysis Bullosa Dystrophica"[Mesh]<br>OR Epidermolysis Bullosa Dystrophica OR "Epidermolysis Bullosa||
||Acquisita"[Mesh]<br>OR<br>Epidermolysis<br>bullosa<br>acquisitaOR<br>Acantholysis Bullosa OR Epidermolysis Bullosa Simplices OR||
||Epidermolysis<br>Bullosa<br>Herpetiformis<br>Dowling<br>Meara<br>OR||
||Epidermolysis Bullosa Simplex, Cockayne-Touraine Type OR||
||Epidermolysis Bullosa Simplex, Cockayne Touraine Type OR||
||Epidermolysis Bullosa Simplex, Weber-Cockayne Type OR<br>Epidermolysis Bullosa Simplex, Weber Cockayne Type OR Weber<br>Cockayne Syndrome OR Epidermolysis Bullosa Simplex, Localized<br>OR Epidermolysis Bullosa Simplex Kobner OR Epidermolysis<br>Bullosa Simplex, Generalized OR Epidermolysis Bullosa Simplex,||
||Koebner Type)) AND ("Bandages"[Mesh] OR "Bandages,||
||Hydrocolloid"[Mesh]<br>OR<br>"Occlusive<br>Dressings"[Mesh]<br>OR||
||"Alginates"[Mesh] OR bandage* OR occlusive dressing* OR<br>hydrocolloid bandage* OR wound dressing* OR alginate OR non<br>adherent dressings OR non adherent wound dressing OR synthetic<br>dressings OR hydrogel* OR Vigilon OR DermaGuaze OR Normlgel||
||OR<br>Restore<br>Hydrogel<br>OR<br>antimicrobial<br>dressing*<br>OR||
||Bismuthtribromophenate<br>OR<br>Mepitel<br>OR<br>N-Terface<br>OR||
||Conformant 2 OR Restore Contact Layer OR Impregnated Gauze OR||
||Vaseline Gauze OR Aquaphor Gauze OR Viscopaste Zinc Oxide||
||Paste Gauze OR Telfa OR Non Adhesive Pad* OR Non-Adherent<br>Gauze* OR Allevyn OR Cutinova Foam OR Gentleheal OR Mepilex<br>OR Mepilex Transfer OR Mepilex Lite OR Mepilex Border OR<br>Mepilex Border Lite OR QuadraFoam OR Restore Foam OR Exu-<br>dryORAquacel OR Restore Calcium Alginate)||

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
<mark>'poikiloderma of kindler' OR 'kindler syndrome'/exp OR 'kindler syndrome' OR 'epidermolysis bullosa'/exp OR 'epidermolysis bullosa' OR 'epidermolysis bullosa simplex'/exp OR 'epidermolysis bullosa simplex' OR 'epidermolysis bullosa, junctional'/exp OR 'epidermolysis bullosa, junctional' OR 'epidermolise bullosa junctional' OR 'epidermolysis bullosa dystrophica'/exp OR 'epidermolysis bullosa dystrophica' OR 'epidermolysis bullosa acquisita'/exp OR 'epidermolysis bullosa acquisita' OR</mark>  
220  
Embase  
**Base de dados Estratégia de Busca Resultados** <mark>'acantholysis bullosa' OR 'epidermolysis bullosa simplices' OR 'epidermolysis bullosa herpetiformisdowlingmeara' OR 'epidermolysis bullosa simplex, cockayne-touraine type' OR 'epidermolysis bullosa simplex, cockaynetouraine type' OR 'epidermolysis bullosa simplex, weber-cockayne type' OR 'epidermolysis bullosa simplex, weber cockayne type or weber cockayne syndrome' OR 'epidermolysis bullosa simplex, localized' OR 'epidermolysis bullosa simplex kobner' OR 'epidermolysis bullosa simplex, generalized' OR 'epidermolysis bullosa simplex, koebner type' AND 'bandages'/exp OR 'bandages' OR 'bandages, hydrocolloid'/exp OR 'bandages, hydrocolloid' OR 'occlusive dressings'/exp OR 'occlusive dressings' OR 'alginates'/exp OR 'alginates' OR 'bandage'/exp OR 'bandage' OR 'occlusive dressing'/exp OR 'occlusive dressing' OR 'hydrocolloid bandage'/exp OR 'hydrocolloid bandage' OR 'wound dressing'/exp OR 'wound dressing' OR 'alginate'/exp OR 'alginate' OR 'non adherent dressings' OR 'non adherent wound dressing' OR 'synthetic dressings' OR 'hydrogel'/exp OR 'hydrogel' OR 'vigilon'/exp OR 'vigilon' OR 'dermaguaze' OR 'normlgel' OR 'restore hydrogel' OR 'antimicrobial dressing'/exp OR 'antimicrobial dressing' OR 'bismuthtribromophenate' OR 'mepitel'/exp OR 'mepitel' OR 'nterface' OR 'conformant 2' OR 'restore contact layer' OR 'impregnated gauze' OR 'vaseline gauze' OR 'aquaphor gauze' OR 'viscopaste zinc oxide paste gauze' OR 'telfa or non adhesive pad' OR 'non-adherent gauze' OR 'allevyn'/exp OR 'allevyn' OR 'cutinova foam' OR 'gentleheal' OR 'mepilex'/exp OR 'mepilex' OR 'mepilex transfer' OR 'mepilex lite' OR 'mepilex border' OR 'mepilex border lite' OR 'quadrafoam' OR 'restore foam' OR 'exudryoraquacel' OR 'restore calcium alginate'</mark>

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A busca das evidências resultou em 311 referências - 90 no Pubmed, 220 no Embase e uma por busca manual ( **Figura B** ). Esses estudos foram triados com base nos seguintes critérios de inclusão: amostra  
de pacientes com epidermólise bolhosa, sem distinção de subtipo, que avaliassem um ou mais curativos para o tratamento das lesões bolhosas, cujos resultados refletissem a eficácia/ efetividade dos produtos testados. Foram incluídos apenas aqueles estudos que avaliaram curativos com registro na Agência Nacional de Vigilância Sanitária (ANVISA). Dessa forma, das 311 referências recuperadas, 73 foram excluídas por estarem duplicadas. Duzentas e trinta e oito referências foram triadas por meio da leitura de títulos e resumos, das quais 21 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dezesseis estudos foram excluídos por não atenderem a pelo menos um dos critérios de inclusão e as justificativas encontram-se no **Quadro C** .  
<!-- Start of picture text -->
i i Referéncias identificadas por meio Referéncias identificadas em  fontes<br>| | da pesquisa nas bases de dados complementares<br>| i (n= 310) (n=)<br>i | MEDLINE (n= 90)<br>| F i EMBASE (n = 220)<br>| | Referéncias duplicadas<br>| (n=73)<br>1E | Referéncias triadas por titulo e resumo<br>if | (n= 238)<br>i | Referéncias excluidas<br>{ i {n=217)<br>i | Referéncias selecionadas para andlise<br>| | do texto completo<br>is | (n=21)<br>is | Referéncias excluidas, com<br>| | justificativas<br>| | (n = 16)<br>i i ~ Produtos nao registrados pela<br>Nt ANVISA: 10<br>oc - Tipo de intervencio: 01<br>| | ~ Tipo de desfecho: 03<br>| | - Tipo de Estudo: 02<br>| 3 i Estudos incluidos<br>(EB (n=05)<br>Ld<br><!-- End of picture text -->  
**Figura B -** Fluxograma representativo do processo de seleção da evidência

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
|**Estudo**|**Motivo de exclusão**|
|---|---|
|Schwieger-Briel et al., 2017<sup>77</sup>|Intervenção sem registro na ANVISA|
|Bafaraj et al., 2014<sup>78</sup>|Relata a história do paciente, sem focar nos resultados do tratamento|
|Kim et al., 2016<sup>79</sup>|Medicamento oral|
|Graham et al., 2019<sup>80</sup>|Estudo qualitativo para construção de luvas para evitar sindactilia, sem<br>dados de eficácia e segurança.|
|Kao et al., 2006<sup>81</sup>|Relata a história do paciente, sem focar nos resultados do tratamento|
|Denyer et al., 2015<sup>82</sup>|Intervenção sem registro na ANVISA|
|Sürücü et al., 2015<sup>83</sup>|Intervenção sem registro na ANVISA|
|Çetin et al., 2003<sup>84</sup>|Intervenção sem registro na ANVISA|
|Williams et al., 1995<sup>85</sup>|Relata a história do paciente, sem focar nos resultados do tratamento|
|Hagele et al., 2016<sup>86</sup>|Resumo de congresso com poucas informações sobre a intervenção e<br>resultados.|
|Kern et al., 2019<sup>87</sup>|Intervenção sem registro na ANVISA|
|Venugopal et al., 2010<sup>88</sup>|Intervenção sem registro na ANVISA|
|Kirsner et al., 2012<sup>89</sup>|Intervenção sem registro na ANVISA|
|Jutkiewicz et al., 2010<sup>90</sup>|Intervenção sem registro na ANVISA|
|Denyer et al., 2015<sup>91</sup>|Intervenção sem registro na ANVISA|
|Hon et al., 2005<sup>92</sup>|Intervenção sem registro na ANVISA|

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: Geral -->
A caracterização dos participantes de cada estudo pode ser vista no **Quadro D** . Os resultados de eficácia dos curativos encontram-se no **Quadro E** e os de segurança, no **Quadro F** . A avaliação da qualidade da evidência, gerada a partir do corpo de evidências, pode ser vista na **Tabela A** , ao final deste Apêndice. Esta tabela corresponde à Tabela _Summary of Findings_ (SoF), criado por meio do _webapp_ GRADE Pro GDT.  
**Quadro D -** Características basais dos participantes dos estudos que avaliaram a segurança e eficácia dos curativos especiais no tratamento de lesões bolhosas em pacientes com epidermólise bolhosa  
|**Autor/ Ano**|**Intervenção**|**N intervenção**|**Idade intervenção média**<br>**(DP)**|**N (%) sexo feminino**<br>**(intervenção)**|**Tempo de**<br>**seguimento**|
|---|---|---|---|---|---|
|Eisenberg et al.,<br>1986|Curativos de hidrocoloide,<br>Telfa ougazeparafinada.|3|Os três pacientes tinham 5,<br>10 e 13 anos de idade.|1 (33,3)|6 semanas|
|Muller et al.,<br>2017|Curativo de hidrocoloide|1|10 anos|0 (0)|3 dias|
|Blanchet-<br>Bardon et al.,<br>2005|Urgotul®|20|Adultos (n=11)<br>29,4 (10,0)<br>Crianças (n=9)<br>5,8(4,8)|9 (45%)|4 semanas|  
50  
**Quadro E -** Desfechos de eficácia de estudos sobre os curativos especiais no tratamento de lesões bolhosas em pacientes com epidermólise  
bolhosa  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Tempo (dias) de**<br>**taxa de**<br>**reepitelização**<br>**para que 50% da**<br>**ferida seja**<br>**curada**|**Valor de p**|**Dor**|**Qualidade de**<br>**vida**|**Outros**|
|---|---|---|---|---|---|---|---|
||||**Gaze parafinada:**<br>De todas as<br>feridas:12,6<br>Pescoço:4,2<br>Ombros:11,4<br>Coxas:12,0<br>Joelhos:18,0<br>Canelas:16,6|P< 0,001 para<br>hidrocoloide comparado a<br>gaze parafinada em todas<br>feridas.<br>P<0,01 para hidrocoloide<br>comparado a telfa em<br>todas feridas.|||**-**|
|Eisenb<br>erg et<br>al.,<br>1986|Relato de<br>3 casos|Curativos de<br>hidrocoloide,<br>Telfa® ou gaze<br>parafinada.|**Hidrocoloide:**<br>De todas as<br>feridas:3,0<br>Pescoço:1,6<br>Ombros:3,5<br>Coxas:3,1<br>Joelhos:3,3<br>Canelas:3,3|P<0,001 para hidrocoloide<br>comparado com gaze<br>parafinada nos ombros.<br>P<0,05 para telfa<br>comparado com gaze<br>parafinada nos ombros.|-|-||
||||**Telfa:**<br>De todas as<br>feridas:4,2<br>Pescoço:3,6|P<0,05 para hidrocoloide<br>comparado com telfa nos<br>ombros.||||  
51  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Tempo (dias) de**<br>**taxa de**<br>**reepitelização**<br>**para que 50% da**<br>**ferida seja**<br>**curada**|**Valor de p**|**Dor**|**Qualidade de**<br>**vida**|**Outros**|
|---|---|---|---|---|---|---|---|
||||Ombros:5,9<br>Coxas:3,5<br>Joelhos:3,7<br>Canelas:4,1|||||
|Lynne<br>et al.,<br>2018|Série de<br>casos<br>(n=4)|Allevyn GB<br>Lite®|**-**|ND|-|-|Proteção das feridas por<br>tempo prolongado;<br>permanência prolongada;<br>maior facilidade de remoção<br>e sem traumas; formato<br>adequado ao da lesão.|
|Blanch<br>et-<br>Bardo<br>n et<br>al.,<br>2005|EC não<br>controlad<br>o, open<br>label<br>(n=20)|Urgotul®|Tempo médio para<br>cura (DP): 8,7<br>(8,5)<br>Cura 19/20 lesões||Em 87% das<br>trocas de<br>curativos não<br>foi necessária<br>analgesia<br>prévia; Em<br>91% das<br>trocas os<br>pacientes não<br>apresentaram<br>dor, nas<br>demais,<br>ocorreu dor|55% relataram<br>melhoria da<br>qualidade de vida<br>com o uso de<br>Urgotul®|**Aplicação do curativo:**<br>94,5% consideraram fácil ou<br>muito fácil<br>**Tempo para troca de**<br>**curativo:**comparado a<br>experiências com outros<br>produtos, 35% consideraram<br>que demorou menos, 45%<br>que levou o mesmo tempo e<br>20% que demorou mais<br>**Remoção do curativo:**98%<br>consideraram fácil|  
52  
|**Autor,**<br>**ano**|**Desenho**<br>**do**<br>**Estudo**|**Intervenção**|**Tempo (dias) de**<br>**taxa de**<br>**reepitelização**<br>**para que 50% da**<br>**ferida seja**<br>**curada**|**Valor de p**|**Dor**|**Qualidade de**<br>**vida**|**Outros**|
|---|---|---|---|---|---|---|---|
||||||leve a<br>moderada||**Odor:**Odor leve e<br>transitório foi relatado em<br>19/152<br>**Sangramento e aderência:**<br>Sangramento leve ocorreu<br>em 18/152 trocas e em<br>2/152 o curativo estava<br>fortemente aderido<br>**Conforto:**15 pacientes<br>consideraram o curativo<br>mais confortável|
|Kuvat<br>et al.,<br>2010|Relato de<br>caso<br>|Gaze<br>esterilizada com<br>dexpantenol +<br>clorexidina.|-|-|-|-|Após 3 semanas a ferida<br>estava completamente<br>reepitelizada, mas a área<br>ficou hipopigmentada.|  
**Quadro F -** Desfechos de segurança de estudos sobre curativos especiais no tratamento de lesões bolhosas em pacientes com epidermólise  
bolhosa  
|**Eisenberg et al., 1986**|**Muller et al.**|**, 2017**<br>**Blanchet-Bardon et al., 2005**|
|---|---|---|  
53  
|**Eventos**<br>**adversos**|Nenhum desconforto associado ao uso<br>dos curativos, a não ser na remoção de<br>área com pelos.<br>Dermatite generalizada|Dois pacientes (10%) apresentaram prurido<br>entre duas trocas de curativo; Um paciente (5%)<br>relatou vazamento de exsudato durante quatro|
|---|---|---|
|||trocas.|  
54

---

<!-- METADADOS: doenca: Epidermólise Bolhosa (Diretriz Brasileira) | secao: **Qualidade da Evidência** -->
|**№ dos**<br>**estudos**|**Delineament**<br>**o do estudo**|**Risco**<br>**de viés**|**Inco**<br>**nsist**<br>**ência**|<br>**Evidênci**<br>**a**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**considerações**|**Impacto**|**Qualidad**<br>**e**<br>**Importância**|
|---|---|---|---|---|---|---|---|---|  
**Tempo (dias) para reepitelização para que a ferida seja curada**  
|2<br>estudo|muito|muit|não grave|muito|nenhum|Reepitelização de 50%: No<br>⨁`◯◯◯`<br>CRÍTICO|
|---|---|---|---|---|---|---|
|observacional|grave|o||grave<sup>d</sup>||estudo de Eisenberg et al.,<br>MUITO|
||a,b|grave||||1986, independentemente do<br>BAIXA|
|||c||||tipo de curativo utilizado a|
|||||||área do pescoço foi o local|
|||||||cuja cicatrização ocorreu de|
|||||||forma mais rápida. Em todas|
|||||||as áreas de feridas avaliadas,|
|||||||a cicatrização foi mais rápida|
|||||||com<br>os<br>curativos<br>de|
|||||||hidrocoloide, seguidos dos|
|||||||telfa<br>e<br>gaze<br>parafinada.|
|||||||Reepitelização total: O uso de|  
55  
|**№ dos**<br>**estudos**|**Delineament**<br>**o do estudo**|**Quali**<br>**Risco**<br>**de viés**|**dade d**<br>**Inco**<br>**nsist**<br>**ência**|**a Evidênci**<br>**Evidênci**<br>**a**<br>**indireta**|**a**<br>**Imprecisã**<br>**o**|**Outras**<br>**considerações**|**Impacto**|**Qualidad**<br>**e**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
||||||||Urgotul® resultou em tempo<br>médio de 8,7 (DP=8,5) dias<br>para cura da lesão (Blanchet-<br>Bardon et al., 2005).|||
|**Qualidade de**|**vida**|||||||||
|1|estudo<br>observacional|muito<br>grave<sup>e</sup>|muit<br>o<br>grave<br>f|não grave|muito<br>grave<sup>d</sup>|nenhum|55% relataram melhoria da<br>qualidade de vida com o uso<br>de Urgotul®|⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|**Dor**||||||||||
|1|estudo<br>observacional|muito<br>grave<sup>e</sup>|muit<br>o|não grave|muito<br>grave<sup>d</sup>|nenhum|Em 87% das trocas de<br>curativos não foi necessária<br>analgesia prévia; Em 91% das|⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|  
56  
<!-- Start of picture text -->
Qualidade da Evidência<br>Inco Evidênci Qualidad<br>№ dos  Delineament Risco  Imprecisã Outras  Impacto  Importância<br>nsist a  e<br>estudos  o do estudo  de viés  o  considerações<br>ência  indireta<br>grave  trocas  os  pacientes  não<br>f<br>apresentaram  dor,  nas<br>demais, ocorreu dor leve a<br>moderada.<br>Alterações Dermatológicas<br>2   estudo  muito  muit não grave  muito  nenhum   Em relato de caso, um  ⨁ ◯◯◯ CRÍTICO<br>observacional   grave b, o  grave  d paciente apresentou dermatite  MUITO<br>g grave generalizada  ao  utilizar  BAIXA<br>f<br>curativo  a  base  de<br>hidrocoloide (Muller et al.,<br><!-- End of picture text -->  
57  
<!-- Start of picture text -->
Qualidade da Evidência<br>Inco Evidênci Qualidad<br>№ dos  Delineament Risco  Imprecisã Outras  Impacto  Importância<br>nsist a  e<br>estudos  o do estudo  de viés  o  considerações<br>ência  indireta<br>2017). Dois pacientes eu uso<br>de  Urgotul®  (10%)<br>apresentaram prurido entre<br>duas trocas de curativos<br>(Blanchet-Bardon  et  al.,<br>2005)<br><!-- End of picture text -->  
a. Trata-se de uma série de casos com 3 pacientes, ou seja, apresenta alto risco de viés; b. Série de casos com 20 pacientes com epidermólise bolhosa distrófica (EBD) e epidermólise bolhosa (EBS), sendo 11 adultos e 9 crianças, com médias de idade de 29,4 (10,0) e 5,8 (4,8), respectivamente; c. Alta heterogeneidade entre os grupos, os três pacientes tinham 5, 10 e 13 anos de idade; Devido ao próprio desenho de estudo, com poucos pacientes e sem mensuração de médias e intervalos de confiança; Trata-se de um ensaio clínico não controlado, ou seja, apresenta alto risco de viés; f. Alta heterogeneidade entre os pacientes, foram incluídos 20 pacientes com EBD e EBS, sendo 11 adultos e 9 crianças, com médias de idade de 29,4 (10,0) e 5,8 (4,8), respectivamente; g. Relato de caso de um paciente de 10 anos em uso de curativo de hidrocoloide.  
58  
59

---

