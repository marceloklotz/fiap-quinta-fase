<!-- METADADOS: doenca: Hepatite Autoimune | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 14, DE 9 DE MAIO DE 2018.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hepatite Autoimune.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a hepatite autoimune no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 325/2018 e o Relatório de Recomendação n<sup><u>o</u></sup> 343 – Março de 2018 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hepatite  
Autoimune.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da hepatite autoimune, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hepatite autoimune.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 457/SAS/MS, de 21 de maio de 2012, publicada no Diário Oficial da União nº 96, de 22 de maio de 2012, seção 1, páginas 96-99.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN  
ANEXO

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **1 INTRODUÇÃO** -->
Em 1950, Waldenström descreveu uma série de casos de mulheres jovens com uma forma de hepatite grave associada a _rash_ acneiforme, aranhas vasculares, amenorreia e marcada elevação das concentrações séricas de gamaglobulina. Estabelecida sua origem imunológica, a doença passou a ser conhecida como “hepatite lupoide” ou “hepatite autoimune crônica ativa”. Em dois encontros internacionais - em 1992, em Brighton no Reino Unido, e, em 1994, em Los Angeles nos Estados Unidos -, especialistas reconheceram que os termos crônica e ativa eram desnecessários, pois a doença é _a priori_ crônica, mas nem sempre é ativa, em razão de seu caráter flutuante. Desse modo, foi recomendado o uso da expressão hepatite autoimune (HAI) para sua designação<sup>1</sup> .  
A prevalência da HAI, baseada em estatísticas internacionais realizadas na Europa setentrional, situa-se em cerca de 17 casos por 100.000 habitantes, com uma incidência anual de 1,9 caso por 100.000 habitantes<sup>1</sup> . No Brasil, a incidência não é plenamente conhecida. Em um Inquérito Nacional sobre Hepatite Autoimune, apresentado no XVI Congresso Brasileiro de Hepatologia em 2001, sua prevalência foi de 3,3%<sup>2</sup> entre as causas de hepatopatia crônica. As principais características da HAI são um quadro histopatológico de hepatite de interface (periportal ou perisseptal), hipergamaglobulinemia, presença de autoanticorpos tissulares e responsividade à terapia imunossupressora na maioria dos casos<sup>1</sup> . Na HAI tipo 1, os principais anticorpos são fator antinuclear (FAN), antimúsculo liso (AML), pANCA e anti-SLA/LP. Anti-LKM1 e o anticitosol hepático 1 (ALC-1), isoladamente ou em associação, caracterizam a HAI tipo 2<sup>3</sup> .  
Em aproximadamente 50% dos casos, o início da doença é insidioso, com os pacientes apresentando fadiga, náusea, anorexia, perda de peso, dor ou desconforto abdominais, icterícia, _rash_ cutâneo, artralgias e mialgias. Ao exame físico, podem estar presentes hepatoesplenomegalia, ascite, eritema palmar, aranhas vasculares, edema periférico e encefalopatia<sup>1,4</sup> . Cerca de 30% dos pacientes apresentam um quadro agudo, com icterícia intensa, sendo essenciais a identificação precoce e o tratamento adequado para evitar progressão para insuficiência hepática. O restante dos casos são assintomáticos, sendo identificados pelo achado incidental de aumento dos níveis séricos de aminotransferases/transaminases (AST/TGO e ALT/TGP)<sup>1</sup> .  
A história natural e o prognóstico da HAI dependem do grau de atividade da doença e da presença ou não de cirrose<sup>4</sup> . Elevação persistente de aminotransferases/transaminases séricas (ALT/TGP ou AST/TGO) acima de 10 vezes o limite superior da normalidade, ou de 5 vezes das mesmas enzimas juntamente com a elevação de 2 vezes o valor normal de gamaglobulina, associamse a aumento na mortalidade, que pode atingir 90% em 10 anos<sup>5,6</sup> . A mortalidade chega a 40% nos primeiros seis meses nos portadores de doença grave que não receberam terapia imunossupressora<sup>6</sup> . A mortalidade em pacientes com cirrose não tratados é de 58% em 5 anos, sendo que a presença desta doença parece não influenciar na resposta terapêutica<sup>7</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da hepatite autoimune. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- K75.4 Hepatite autoimune

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **3 DIAGNÓSTICO** -->
O diagnóstico da HAI é feito pela soma de informações clínicas, bioquímicas, histopatológicas e de resposta ao tratamento. Devem ser afastadas causas virais, tóxicas e metabólicas antes que se possa firmar o diagnóstico. Corroboram o diagnóstico aumento expressivo nas concentrações séricas de gamaglobulinas, grau de elevação das AST/TGO e ALT/TGP superior ao grau de elevação da fosfatase alcalina, presença de FAN, AML ou anti-LKM1 positivos, ausência de anticorpo antimitocondrial e exame histopatológico com hepatite de interface sem lesões biliares, granulomas ou alterações proeminentes sugestivas de outra doença<sup>8</sup> . Em uma revisão sistemática com meta-análise, FAN apresentou sensibilidade de 65,0% (IC95%: 61,9% a 68,0%), especificidade de 75,1% (IC95%: 73,7% a 76,4%) e _odds ratio_ de 7,38 (IC95%: 4,34 a 12,54) para o diagnóstico de HAI enquanto AML apresentou, para os mesmos parâmetros, valores de 59,3% (IC95%: 56,4% a 62,1%), 92,6% (IC95%: 91,7% a 93,4%) e 31,55 (IC95%: 17,15 a 58,06)<sup>9</sup> . Revisão sistemática com meta-análise identificou que idosos (i.e., maiores de 60 a 65 anos) possuem maior chance de apresentarem HAI assintomática, associada à cirrose e com HLA-DR4 positivo em comparação a pacientes mais jovens<sup>10</sup> .  
Em 1992, foi realizado um painel com 27 especialistas em HAI em que os critérios diagnósticos foram discutidos, tendo sido criado um escore diagnóstico, com a finalidade de padronização da doença<sup>11</sup> . Esse escore foi estudado em uma série de contextos. Com base nesses estudos, em 1998 nova reunião do _International Autoimmune Hepatitis Group_ (IAIHG) foi realizada, sendo os critérios revisados e o escore levemente modificado – escore revisado e adaptado para o diagnóstico de hepatite autoimune (ERDHAI) –, principalmente com a finalidade de excluir com maior precisão as doenças colestáticas. Em 2008, foram publicados os critérios diagnósticos simplificados de HAI<sup>12</sup> . Desde então, esses novos critérios têm sido validados em adultos e crianças no mundo todo<sup>12-18</sup> . Os critérios simplificados apresentam elevada acurácia frente ao ERDHAI e têm sido recomendados por diretrizes europeias<sup>19</sup> . Ambos podem ser empregados de maneira complementar para o diagnóstico de HAI tendo em vista que o ERDHAI é melhor quando aplicado a pacientes com poucos achados ou com achados atípicos de HAI e os critérios simplificados são mais úteis que os revisados para a exclusão de HAI em pacientes com outras doenças autoimunes concomitantes<sup>14</sup> . Dessa forma, recomenda-se o uso do ERDHAI ( **Tabela 1** ) para o diagnóstico de pacientes com suspeita de HAI sem outras doenças autoimunes concomitantes e o emprego dos critérios simplificados para os pacientes com doenças autoimunes conhecidas.  
Os critérios modificados e que continuam válidos podem ser vistos na **Tabela 2** .  
**Tabela 1 -** Escore revisado e adaptado para o diagnóstico de hepatite autoimune (ERDHAI)<sup>20</sup>  
|PARÂMETRO|ESCORE|<br>NOTAS<br>EXPLICATIVAS|
|---|---|---|
|Sexo feminino|+2||
|Relação fosfatase alcalina/AST (TGO) (ou ALT/TGP)||a|
|< 1,5|+2||
|1,5-3,0|0||
|> 3,0|-2||
|Gamaglobulina ou IgG (n<sup>o</sup> de vezes acima do normal)|||
|> 2,0|+3||
|1,5-2,0|+2||
|1,0-1,5|+1||
|< 1,0|0||
|FAN, AML ou anti-LKM1||b|
|> 1:80|+3||
|1:80|+2||
|1:40|+1||  
|< 1:40|0||
|---|---|---|
|Antimitocôndria positivo|-4||
|Marcadores de hepatites virais||c|
|Reagente|-3||
|Não reagente|+3||
|Consumo de fármacos hepatotóxicos atual ou recente|||
|Presente|-4||
|Ausente|+1||
|Consumo médio de álcool|||
|< 25 g/dia|+2||
|> 60 g/dia|-2||
|Histologia hepática|||
|Infiltrado periportal com necrose em saca-bocado|+3||
|Infiltrado linfoplasmocitário predominante|+1||
|Hepatócitos em roseta|+1||
|Nenhum dos critérios acima|-5||
|Alterações biliares|-3||
|Outras alterações|-3||
|Outra doença autoimune (própria ou em familiar de 1<sup>o</sup> grau)|+2||
|Parâmetros opcionais|||
|Positividade de outro anticorpo associado a HAI|+2|d,e|
|HLA DR3, DR7 ou DR13|+1|d,f|
|Resposta ao tratamento imunossupressor||g|
|Completa|+2|h|
|Recaída com a diminuição|+3|i|  
a) É calculado com a divisão do número de vezes acima do limite superior da normalidade da fosfatase alcalina pelo número de vezes acima do limite superior da normalidade das aminotransferases/transaminases.  
b) Consideram-se os títulos medidos por imunofluorescência indireta em tecidos de roedores ou para FAN em células Hep-2. Títulos baixos em crianças podem ter significado, devendo ser atribuído pelo menos 1 ponto (especialmente de anti-LKM1).  
c) Consideram-se os resultados laboratoriais não reagentes de anti-HAV IgM, HBsAg, anti-HBc total, anti-HCV e HCV-RNA qualitativo. Se há suspeita de uma etiologia viral, pode ser necesssária a exclusão de citomegalovírus e de vírus Epstein-Barr.  
d) São válidos para pontuação apenas se FAN, AML e anti-LKM1 forem negativos.  
e) Incluem anti-SLA/LP, p-ANCA, anti-ASGPR, anti-LC1 e antissulfatide.  
f) HLA DR7 e DR13 foram incluídos no escore original de acordo com resultados de estudo realizado em São Paulo<sup>21</sup> .  
g) Se o paciente ainda não foi tratado, desconsiderar e utilizar ponto de corte pré-tratamento (ver a seguir), incluindo a pontuação apropriada após o início da terapia.  
h) Considera-se resposta completa a ocorrência de pelo menos uma das seguintes situações: 1) melhora importante dos sintomas associada à normalização de AST/TGO, ALT/TGP, bilirrubinas e gamaglobulinas no prazo de 1 ano do início do tratamento e mantido por 6 meses; 2) melhora dos sintomas em 50% de AST, ALT e bilirrubinas no primeiro mês de tratamento e AST e ALT permanecendo no máximo 2 vezes o limite superior da normalidade durante os primeiros 6 meses da terapia de manutenção; 3) biópsia durante este período mostrando no máximo atividade mínima.  
i) Considera-se recaída a ocorrência de uma das seguintes situações após resposta completa: 1) aumento de AST ou ALT 2 vezes acima do limite superior da normalidade; 2) biópsia hepática mostrando doença ativa; 3) retorno de sintomas que necessitem aumento da imunossupressão acompanhado de elevação de AST ou ALT.  
A partir do escore obtido, o diagnóstico de HAI é feito da seguinte forma:  
- a) Pacientes que ainda não tenham sido tratados com imunossupressores:  
- ERDHAI de 10 a 15 (diagnóstico provável de HAI);  
- ERDHAI acima de 15 (diagnóstico definido de HAI).  
- b) Pacientes já tratados com imunossupressores:  
- ERDHAI de 12 a 17 (diagnóstico provável de HAI);  
- ERDHAI acima de 17 (diagnóstico definido de HAI).  
Em pacientes sem resposta prévia a imunossupressores não se exclui a possibilidade do diagnóstico; recomenda-se, contudo, investigação complementar para exclusão de outras doenças, especialmente se houver alterações colestáticas no perfil bioquímico.  
**Tabela 2 -** Critérios simplificados para diagnóstico de HAI (12)  
|PARÂMETRO|PONTO DE CORTE|PONTUAÇÃO|
|---|---|---|
|FAN positivo ou AML positivo|≥1:40|**+1**|
|FAN positivo ou AML positivo|≥1:80|**+2**|
|ou anti-LKM positivo|≥1:40|**+2**|
|ou anti-SLA/LP positivo|qualquer valor|**+2**|
|IgG ou gama-globulina|>limite normal<br>> 1,1 vez o limite<br>superior|**+1**<br>**+2**|
|Biópsia hepática (evidência de hepatite é indispensável)|Compatível<br>Típica|**+1**<br>**+2**|
||Atípica|**0**|
|Hepatite viral|Sim|**0**|
||Não|**+2**|  
A doença é considerada provável se o paciente atingir 6 pontos e definitiva, se alcançar 7 ou mais pontos<sup>12</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **4 CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentem as duas condições abaixo<sup>22</sup> : - diagnóstico definido ou provável de HAI segundo a escala ERDHAI ou, se houver outras doenças autoimunes concomitantes, os critérios simplificados; e  
- pelo menos um dos itens abaixo: a) AST/TGO 10 vezes acima do valor normal<sup>6</sup> ; b) AST/TGO 5 vezes acima do valor normal associado a gamaglobulina 2 vezes acima do valor normal<sup>6</sup> ;  
- c) pontuação no índice de atividade histológica maior ou igual a 4<sup>19,23</sup> ;  
- d) hepatite de interface, necrose em ponte ou multilobular à histologia<sup>24</sup> ;  
- e) cirrose com atividade inflamatória<sup>25</sup> ;  
- f) sintomas constitucionais incapacitantes.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **5 CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem:  
- biópsia hepática com ausência de infiltrado inflamatório (ausência de atividade), mesmo com cirrose, pois não há evidência de benefício de terapia imunossupressora nestes casos;  
- diagnóstico de colangite biliar primária ou de colangite esclerosante primária;  
- evidência de causas infecciosas, tóxicas ou metabólicas; ou  
- contraindicação ou intolerância ao uso de prednisona ou azatioprina.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **6 CASOS ESPECIAIS Crianças** -->
O tratamento preconizado para crianças é semelhante ao dos adultos, tanto com prednisona em monoterapia quanto com prednisona e azatioprina, porém o tratamento tem sido menos estudado nessa faixa etária. Com a intenção de diminuir os efeitos deletérios sobre o crescimento, o desenvolvimento ósseo e a aparência física, é comum o uso de corticosteroide em dias alternados<sup>26</sup> . Pacientes pediátricos podem apresentar gravidade maior do que os adultos, com menor probabilidade de remissão sustentada sem o uso de medicamentos e maiores taxas de recidiva. Os princípios do tratamento de crianças com HAI são semelhantes aos dos adultos<sup>19</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Mulheres pós-menopáusicas e pacientes idosos** -->
Este grupo não difere quanto ao benefício alcançado com a terapia ou quanto à gravidade da apresentação clínica, tendo as mesmas indicações de tratamento dos outros pacientes. Entretanto, apresentam risco aumentado para osteopenia, osteoporose e fraturas com o uso de corticosteroide, especialmente se prolongado. Os esquemas de manutenção devem ser realizados com doses baixas de corticosteroide ou com azatioprina, caso ocorram múltiplas recaídas. Também deve ser oferecida profilaxia para osteoporose quando os pacientes estiverem recebendo mais de 5 mg de prednisona por mais de três meses, conforme o Protocolo Clínico e Diretrizes Terapêuticas do Ministério da Saúde da Osteoporose vigente.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Portadores de cirrose** -->
Pacientes com cirrose respondem ao tratamento tão bem quanto os não cirróticos<sup>7</sup> . Os com ascite e encefalopatia hepática têm pior prognóstico, mas a estabilização pode ser obtida com terapia específica para a descompensação hepática associada a imunossupressores. A decisão de transplante deve ser adiada, se possível por duas semanas, a fim de se observar a resposta terapêutica. Pode haver maior incidência de efeitos adversos do corticosteroide, secundários a hipoalbuminemia e hiperbilirrubinemia, motivo pelo qual preconizam-se doses baixas de corticosteroide ou a sua associação com azatioprina.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Gestantes** -->
Pacientes com HAI e com cirrose não têm contraindicação para gestação, embora haja maior risco de parto prematuro, baixo peso ao nascimento e necessidade de cesariana. Pacientes com quadros avançados de cirrose podem ter complicações durante a gestação pelas alterações hemodinâmicas que ocorrem; está indicada contracepção se estiverem menstruando. A maioria das mulheres com cirrose avançada já apresenta amenorreia, não necessitando de anticoncepção. Existe preocupação com o potencial teratogênico da azatioprina. Mesmo que esse risco seja baixo, recomenda-se, durante a gestação, monoterapia com corticosteroide, que elimina essa apreensão<sup>26</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Pacientes com HAI de apresentação aguda** -->
Os pacientes podem se apresentar com hepatite aguda e, raramente, com HAI fulminante. Devem ser tratados prontamente com corticosteroide, sendo a taxa de resposta semelhante à de outros pacientes com HAI.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Pacientes com sobreposição de manifestação (** **_overlap_ )** -->
Algumas características da HAI, como hipergamaglobulinemia, autoanticorpos e hepatite de interface podem estar presentes em outras doenças hepáticas. Em alguns casos, pode haver sobreposição de manifestações em que duas doenças possam coexistir. Há diversos relatos de sobreposição de HAI com doenças colestáticas, principalmente cirrose biliar primária (CBP) - anteriormente conhecida por cirrose biliar primária - e colangite esclerosante primária (CEP). Inexiste uma nomenclatura unificada internacionalmente para essas situações, sendo frequentemente denominadas de HAI/CBP, CBP com anticorpo antimitocondrial (AMA) negativo, HAI com AMA positivo, HAI colestática, HAI/CEP, colangite autoimune e colangiopatia autoimune. Essas síndromes são denominadas de HAI com _overlap_ .  
Em sua publicação mais recente, o IAIHG sugere que pacientes com doenças autoimunes do fígado devam ser categorizados de acordo com suas características predominantes como doentes de HAI, CBP ou CEP e que indivíduos com achados de sobreposição devam ser classificados como doentes de uma destas três entidades diagnósticas distintas<sup>27</sup> . O escore ERDHAI não é apropriado para a identificação do subgrupo de pacientes ditos com “overlap”<sup>27</sup> . O IAIHG afirma que pacientes com achados histológicos compatíveis com HAI e que também apresentem evidência histológica clara de lesão de ducto biliar ou granulomas bem definidos não devem ser considerados como doentes de HAI<sup>20,27</sup> . Pacientes com AMA positivo em altos títulos devem ser considerados, segundo o conhecimento atual, como doentes de CBP e deverão receber tratamento para esta condição<sup>20,27</sup> . À histologia, a presença de degeneração do epitélio dos ductos biliares, obliteração focal de ductos biliares e formação de granulomas é altamente sugestiva de CBP<sup>27</sup> . Já pacientes AMA negativos, com elevação da fosfatase alcalina ≥3 vezes o limite superior normal, achados histológicos de inflamação da tríade portal com infiltração de linfócitos nos ductos biliares e proliferação ductal têm quadro altamente sugestivo de CEP<sup>27</sup> .  
De qualquer forma, essas sobreposições são raras. Aproximadamente, 2% a 19% dos pacientes com CBP e 7% a 14% dos pacientes com CEP apresentam características de HAI<sup>27</sup> . Segundo o IAIHG, não há recomendação baseada em evidências para o tratamento de pacientes com HAI e características concomitantes de CBP ou de CEP<sup>27</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **7 TRATAMENTO** -->
Este PCDT versa exclusivamente sobre o tratamento de HAI; pacientes com formas variantes (“overlap”, sobreposição ou imbricamento), ou com CBP ou CEP não são incluídos.  
Três ensaios clínicos clássicos avaliaram a utilidade da terapia imunossupressora para HAI. O primeiro, publicado em 1971, avaliou 49 pacientes com o diagnóstico de “hepatite crônica ativa”. Os pacientes foram randomizados para receber prednisolona (15 mg) ou permanecer em acompanhamento sem tratamento. Houve diminuição significativa dos níveis da bilirrubina sérica e das globulinas totais com aumento dos níveis de albumina sérica dos que receberam prednisolona em relação aos controles. Após 6 anos de acompanhamento, morreram 3 (13,6%) dos 22 pacientes do grupo prednisolona e 15 (55,6%) dos 27 do grupo controle (p < 0,01)<sup>27</sup> .  
Um segundo estudo realizado em 63 pacientes com “doença hepática crônica ativa acentuada” comparou o tratamento com prednisona (20 mg/dia), prednisona (10 mg/dia) associada a azatioprina (50 mg/dia), azatioprina (100 mg/dia) ou placebo. O estudo foi duplo-cego, mas não deixou claro se os grupos foram randomizados. Houve aumento na sobrevida, resolução dos exames de bioquímica hepática e melhora histológica nos pacientes que receberam prednisona ou associação de prednisona e azatioprina em relação ao grupo azatioprina em monoterapia e ao grupo placebo<sup>6</sup> .  
Um terceiro estudo randomizado com 47 pacientes comparou a eficácia de prednisona (15 mg/dia) em relação a azatioprina (75 mg/dia) na terapia de manutenção de pacientes com “hepatite crônica ativa” após tratamento de indução com prednisona (30 mg/dia) e azatioprina (112,5 mg/dia) por 4 semanas. O estudo foi interrompido após 2 anos de seguimento, pois a sobrevida no grupo prednisona naquele momento era de 95% e no grupo azatioprina, de 72%. Os autores não calcularam a significância estatística exata, pois os dados não tinham uma distribuição normal<sup>25</sup> . Analisando-se os resultados desses estudos, fica claro o benefício de prednisona em monoterapia ou associada a azatioprina, mas não de azatioprina isoladamente, em aumentar a expectativa de vida desses pacientes.  
Havia dúvida quanto ao impacto da insuficiência hepática na biotransformação de prednisona a prednisolona, que é o seu metabólito ativo, o que poderia diminuir sua eficácia em pacientes hepatopatas. Um estudo avaliou os parâmetros farmacocinéticos de prednisona em comparação com os mesmos parâmetros em voluntários sadios. Não foi encontrada nenhuma diferença no metabolismo  
de prednisona em pacientes com doença hepática crônica ativa<sup>28</sup> , concluindo-se que ela pode ser utilizada com segurança em pacientes com HAI.  
A prednisona usada isoladamente ou em dose baixa associada a azatioprina é a base da indução do tratamento de HAI<sup>26</sup> . Ambos os esquemas de tratamento são equivalentemente eficazes na indução da remissão, sendo que a terapia combinada permite uso de metade das doses de prednisona. A associação de prednisona e azatioprina é preferida pela menor frequência de efeitos adversos secundários ao corticosteroide (incidência de 10% _versus_ 44%)<sup>29</sup> . O uso de azatioprina isoladamente é uma alternativa ( **Tabela 3** ) como forma de tratamento de manutenção, para pacientes com resposta incompleta ao tratamento indutor de remissão ou com múltiplas recaídas<sup>26</sup> .  
**Tabela 3 -** Indicações ideais para monoterapia com prednisona ou associação de prednisona e azatioprina<sup>26</sup>  
|PREDNISONA E AZATIOPRINA|PREDNISONA EM MONOTERAPIA|
|---|---|
|Mulheres pós-menopáusicas|Citopenias|
|Osteoporose|Gestação|
|Diabetes|Doença maligna atual|
|Hipertensão arterial sistêmica|Curto período de tratamento (< 6 meses)|
|Labilidade emocional/depressão|Deficiência de tiopurina-metiltransferase|
|Obesidade||
|Acne||  
O tratamento é iniciado conforme as doses preconizadas na **Tabela 3** e mantido até a remissão, falha terapêutica, resposta incompleta ou toxicidade por medicamentos.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Remissão** -->
Caracteriza-se por ausência de sintomas, normalização dos níveis de bilirrubinas e gamaglobulina, ALT/TGP e AST/TGO abaixo do limite superior da normalidade e melhora histológica com no máximo infiltrado portal e ausência de hepatite de interface. As melhoras clínica e bioquímica precedem a melhora histológica em 3 a 6 meses, sendo essencial a comprovação da remissão histológica antes da interrupção do tratamento.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Falha terapêutica** -->
Caracteriza-se por aumento de AST/TGO em dois terços do valor pré-tratamento, piora da atividade histológica ou surgimento de encefalopatia ou de ascite a despeito de adequada adesão ao tratamento. Os pacientes devem ser tratados com as doses preconizadas para falha do tratamento de indução da remissão (ver item 8.2). Apenas 20% alcançarão remissão histológica, sendo que os demais necessitarão de tratamento continuado. Não havendo resposta adequada, com insuficiência hepática irreversível, deverá ser indicado transplante hepático, com resultados excelentes e sobrevida de 10 anos de 75%. Pode haver recorrência pós-transplante em 40% dos casos, sendo mais histológica do que clínica<sup>3</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Resposta incompleta** -->
Corresponde a melhoras clínica, bioquímica e histológica, contudo sem resposta completa após 3 anos de tratamento contínuo. Os pacientes devem ser mantidos em tratamento de manutenção com prednisona (dose baixa) ou azatioprina (ver item 7.2)<sup>31,32</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Toxicidade por medicamento** -->
Há necessidade de redução ou interrupção temporária ou definitiva do uso do medicamento. A prednisona é o fármaco que mais frequentemente causa toxicidade. Se o paciente ainda não estiver em uso de azatioprina e houver condições de fazê-lo, ela pode ser utilizada para redução da dose do corticosteroide. Quando os efeitos adversos são intensos, reduz-se à dose mínima possível para tentar evitá-los, sendo em alguns casos necessário interromper o tratamento. Na presença de hepatite  
colestática, pancreatite, _rash_ ou citopenia importante secundários a azatioprina, a interrupção do fármaco é mandatória.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Recaída** -->
Pacientes com recaída após a retirada da imunossupressão que se segue à remissão histológica devem ser novamente encaminhados para tratamento de indução da remissão ( **Tabela 4** ). A recaída é caracterizada pela recrudescência dos sintomas clínicos com aumento de ALT/TGP duas vezes acima do limite superior da normalidade. A taxa de recaída é da ordem de 20% após comprovada remissão histológica e chega a 80% quando há atividade periportal no momento da retirada da imunossupressão, o que enfatiza a necessidade de comprovação histológica da remissão antes de se suspender a imunossupressão. Após uma segunda recaída, a probabilidade de se alcançar remissão duradoura sem imunossupressão é muito baixa, devendo-se manter o paciente em regime de doses baixas de prednisona ou em monoterapia com azatioprina (ver item 7.2).

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: _Micofenolato/ciclosporina/tacrolimo_ -->
Até 20% dos pacientes não respondem ou são intolerantes ao tratamento de primeira linha. Uma série de casos prospectiva com 59 pacientes<sup>33</sup> avaliou a resposta destes pacientes ao uso de micofenolato. Ao total, 59,3% dos pacientes tiveram resposta completa. Nenhum dos pacientes foi não respondedor. Ciclosporina e tacrolimo foram avaliados somente em séries de casos e pequenas coortes em adultos e crianças<sup>34-36</sup> . A melhor e mais recente evidência sobre tratamento de segunda linha da HAI provém de uma revisão sistemática com meta-análise de estudos observacionais que conclui por benefício da associação de micofenolato mofetila mais prednisona na remissão histológica da doença<sup>37</sup> . Porém, o uso desses medicamentos para essa indicação deve ser analisada pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) em termos de eficácia, efetividade e custo-efetividade.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: _Budesonida_ -->
Um ensaio clínico randomizado, de fase IIb, com 6 meses de acompanhamento, comparou budesonida 3 mg duas a três vezes ao dia, com prednisona 10-40 mg ao dia, ambas associadas a azatioprina 1-2 mg/kg/dia. O desfecho principal, que era normalização de aminotransferases/transaminases sem efeitos adversos específicos de esteroide, foi obtido em 47% do grupo budesonida e 18,4% do grupo prednisona (P<0,001)<sup>38</sup> . Contudo, estudo clínico randomizado (ECR) envolvendo crianças e adolescentes que comparou budesonida e azatioprina _versus_ prednisona e azatioprina encontrou taxas idênticas de remissão bioquímica<sup>39</sup> . Ademais, a eficácia e tolerância de longo prazo da budesonida ainda não foram adequadamente avaliadas<sup>19</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: _Ácido ursodesoxicólico (AUDC)_ -->
Um ensaio clínico randomizado duplo-cego de fase III testou o AUDC mais corticoesteroides contra placebo mais corticoesteroides em pacientes com HAI tipo 1 e história de falha terapêutica, recorrência repetida ou de resposta incompleta ao tratamento. O desfecho primário foi redução ou suspensão de corticoesteroides. O AUDC se mostrou idêntico a placebo e por isso é contraindicado por diretriz da _American Association for the Study of Liver Diseases (AASLD)_ para o tratamento de resgate da HAI<sup>35,40</sup> . Os autores do ensaio clínico concluem que a terapia adjuvante com o AUDC reduziu a AST/TGO e fosfatase alcalina, porém a magnitude desse efeito foi pequena e de relevância clínica duvidosa<sup>40</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **7.1 FÁRMACOS** -->
- Prednisona: comprimidos de 5 e 20 mg;  
- Azatioprina: comprimidos de 50 mg.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **7.2 ESQUEMAS DE ADMINISTRAÇÃO** -->
Os esquemas de administração de imunossupressores são os seguintes:

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Indução da remissão** -->
Em adultos, utilizam-se as doses preconizadas na **Tabela 4** . Em crianças, as doses iniciais recomendadas são de 2 mg/kg de prednisona (dose máxima de 60 mg/dia), sendo possível a associação de azatioprina como medida para redução da dose de corticosteroide<sup>26</sup> .  
**Tabela 4 -** Doses do Tratamento de Indução da Remissão em Adultos  
|Semanas em tratamento|Tratamento<br>combinado|Prednisona em m|onoterapia|
|---|---|---|---|
|Pred|nisona (mg/dia)|Azatioprina (mg/dia)|Prednisona<br>(mg/dia)|
|1|30|50-150|60|
|1|20|50-150|40|
|2|15|50-150|30|
|Manutenção até o|5-15|50-150|20|
|desfecho do tratamento||||

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Esquema para falha do tratamento de indução da remissão** -->
Deve-se iniciar com prednisona em monoterapia (60 mg/dia) ou prednisona (30 mg/dia) associada à azatioprina (150 mg/dia). As doses são reduzidas mensalmente enquanto houver melhora laboratorial (redução de 10 mg/mês para prednisona e de 50 mg/mês para azatioprina) até atingir-se a dose de 10 mg/dia de prednisona e de 50 mg/dia de azatioprina ou 20 mg/dia de prednisona em monoterapia, quando os pacientes devem ser tratados como os que se encontram em esquemas de tratamento padrão.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **Esquema para resposta incompleta ou a partir da segunda recaída** -->
A manutenção com prednisona em doses baixas é preconizada para resposta incompleta ou a partir da segunda recaída. Após remissão clínica e bioquímica com a terapia de indução, reduz-se a dose de prednisona (2,5 mg/dia ou 5 mg a cada 2 dias) enquanto houver estabilidade clínicolaboratorial até encontrar-se a dose mínima eficaz para manter o paciente assintomático e AST/TGO 5 vezes abaixo do limite superior da normalidade. A maior vantagem da monoterapia com corticosteroide em doses baixas é a prevenção da teratogenicidade de azatioprina em mulheres em idade fértil.  
A manutenção com azatioprina em monoterapia tem as mesmas indicações da manutenção com prednisona em doses baixas. Após remissão clínica e bioquímica com a terapia de indução, a dose de azatioprina é aumentada gradualmente (até 2 mg/kg/dia), permitindo redução da dose de corticosteroide. A maior vantagem da monoterapia com azatioprina é a prevenção dos efeitos adversos dos corticosteroides, em especial nas pacientes pós-menopáusicas.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **7.3 TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
O tratamento não tem duração pré-determinada, havendo reduções de dose ou interrupção de acordo com a resposta do paciente.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **7.4 BENEFÍCIOS ESPERADOS** -->
- Aumento da expectativa de vida;  
- melhora da qualidade de vida;  
- melhora dos sintomas clínicos;  
- diminuição da atividade inflamatória ao exame da amostra de biópsia hepática;  
- normalização dos níveis das aminotransferases/transaminases;

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **8 MONITORIZAÇÃO** -->
Para pacientes em uso de corticosteroide, recomenda-se a avaliação regular da pressão arterial e realizar dosagens de potássio e sódio séricos e glicemia de jejum para identificação e tratamento de potenciais efeitos adversos sobre o metabolismo glicídico e equilíbrio hidro-eletrolítico. Para pacientes em uso de corticosteroide por períodos superiores a seis semanas, recomenda-se avaliação oftalmológica<sup>41</sup> .  
A azatioprina se transforma rapidamente, depois de ingerida, em 6-mercaptopurina que por sua vez é metabolizada por três vias, duas catabólicas e uma anabólica. A via catabólica de metilação se efetua pela ação da enzima TPMT (tiopurina metil-transferase) e a outra de oxidação pela xantina oxidase (XO). A via anabólica se inicia pela ação da enzima HGPRT (hipoxantina-fosfo-ribosiltransferase) sobre a 6-mercaptopurina e leva a formação dos metabólitos ativos 6-TGN (6tioguanínicos) que são os responsáveis pela ação imunossupressora e mielotóxica da azatioprina. Pacientes que geneticamente não apresentam atividade da enzima TPMT, ou a tem em nível muito baixo, são intolerantes à azatioprina em razão da maior oferta de 6-mercaptopurina para se formar 6TGN. Esses pacientes são extremamente sensíveis ao uso da azatioprina, mesmo com doses baixas, e a mielotoxicidade nessas situações se manifesta precocemente, após poucos dias de uso<sup>42,43</sup> . Desta forma deve-se realizar hemograma completo semanalmente no primeiro mês, quinzenalmente no segundo e no terceiro meses e, após, mensalmente<sup>44</sup> . A redução de dose ou suspensão da azatioprina devem ser feitas a critério médico. A determinação de 6-TGN poderá vir a ser útil para monitorizar a dose a ser ministrada e propiciar aumento de sua eficácia, sobretudo para os doentes com alta atividade da TPMT. Isso tem ainda fundamento limitado, mas algumas evidências demonstram que cerca de 30% dos pacientes sob uso prolongado de azatioprina não formam, em nível detectável pela metodologia atual (HPLC), os metabólitos ativos desse imunossupressor.  
A hepatotoxicidade da azatioprina é incomum e parece estar relacionada ao metabólito 6- metil-mercaptopurina. Deve ser realizado controle de AST/TGO e ALT/TGP na mesma periodicidade dos hemogramas nos primeiros 6 meses e, após, trimestralmente. Caracterizada hepatotoxicidade, reavaliar continuidade do tratamento.  
Se após 3 a 6 meses de tratamento com corticoesteroide não houver resposta clínica ou laboratorial, a hipótese de colangite esclerosante primária deverá ser investigada por meio de exame de imagem apropriado<sup>34</sup> . Deve-se ter em mente também que pacientes anti-SLA positivos têm maior risco de recaída após suspensão do tratamento: _odds ratio_ de 2,24 (IC95%: 1,38 a 3,64)<sup>45</sup> . Um revisão sistemática qualitativa identificou que 19% a 40% dos pacientes podem atingir um estado de remissão livre de corticosteroide ou azatioprina após 3 anos de tratamento<sup>46</sup> . Fatores que favorecem esse estado são: idade ≥40 anos; ausência de cirrose ao diagnóstico; ausência de doenças autoimunes concomitantes; resposta terapêutica dentro dos primeiros 5 meses de tratamento; escore ERDHAI <17 pontos ao diagnóstico; boa adesão ao tratamento; bioquímica hepática normal e ausência de plasmócitos ao exame anatomopatológico do fígado à suspensão do tratamento<sup>46</sup> . Contudo, sabe-se que remissão bioquímica pode preceder a remissão histológica em 3 a 8 meses; logo, sugere-se que o tratamento seja mantido por este período após normalização das aminotransferases/transaminases<sup>47</sup> .  
Recomenda-se rastreamento semestral de carcinoma hepatocelular (CHC) com ultrassonografia de abdome para pacientes cirróticos com HAI, apesar do risco de CHC nesta população ser menor que nos cirróticos por hepatites virais crônicas ou CBP<sup>19,48</sup> .

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **9 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se cientificar o paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **11 REFERÊNCIAS** -->
1. McFarlane IG. Definition and classification of autoimmune hepatitis. Semin Liver Dis. novembro de 2002;22(4):317–24.  
2. Sociedade Brasileira de Hepatologia. Inquérito Nacional sobre Hepatite Autoimune (HAI) - 1997-1999. Disponível em: http://www.sbhepatologia.org.br/nacional/inquer.htm 3. Krawitt EL. Autoimmune hepatitis. N Engl J Med. 5 de janeiro de 2006;354(1):54–66. 4. Manns MP, Strassburg CP. Autoimmune hepatitis: clinical challenges. Gastroenterology. maio de 2001;120(6):1502–17.  
5. Geall MG, Schoenfield LJ, Summerskill WH. Classification and treatment of chronic active liver disease. Gastroenterology. dezembro de 1968;55(6):724–9.  
6. Soloway RD, Summerskill WH, Baggenstoss AH, Geall MG, Gitnićk GL, Elveback IR, et al. Clinical, biochemical, and histological remission of severe chronic active liver disease: a controlled study of treatments and early prognosis. Gastroenterology. novembro de 1972;63(5):820–33.  
7. Roberts SK, Therneau TM, Czaja AJ. Prognosis of histological cirrhosis in type 1 autoimmune hepatitis. Gastroenterology. março de 1996;110(3):848–57.  
8. Bittencourt PL, Cançado ELR, Couto CA, Levy C, Porta G, Silva AEB, et al. Brazilian society of hepatology recommendations for the diagnosis and management of autoimmune diseases of the liver. Arq Gastroenterol. dezembro de 2015;52 Suppl 1:15–46.  
9. Zhang W-C, Zhao F-R, Chen J, Chen W-X. Meta-analysis: diagnostic accuracy of antinuclear antibodies, smooth muscle antibodies and antibodies to a soluble liver antigen/liver pancreas in autoimmune hepatitis. PloS One. 2014;9(3):e92267.  
10. Chen J, Eslick GD, Weltman M. Systematic review with meta-analysis: clinical manifestations and management of autoimmune hepatitis in the elderly. Aliment Pharmacol Ther. janeiro de 2014;39(2):117–24.  
11. Johnson PJ, McFarlane IG. Meeting report: International Autoimmune Hepatitis Group. Hepatol Baltim Md. outubro de 1993;18(4):998–1005.  
12. Elke M. Hennes, Zeniya M, Czaja AJ, Parés A, Dalekos GN, Krawitt EL, et al. Simplified criteria for the diagnosis of autoimmune hepatitis. Hepatol Baltim Md. julho de 2008;48(1):169–76.  
13. Kim BH, Kim YJ, Jeong S-H, Tak WY, Ahn SH, Lee YJ, et al. Clinical features of autoimmune hepatitis and comparison of two diagnostic criteria in Korea: a nationwide, multicenter study. J Gastroenterol Hepatol. janeiro de 2013;28(1):128–34.  
14. Czaja AJ. Performance parameters of the diagnostic scoring systems for autoimmune hepatitis. Hepatol Baltim Md. novembro de 2008;48(5):1540–8.  
15. Mileti E, Rosenthal P, Peters MG. Validation and modification of simplified diagnostic criteria for autoimmune hepatitis in children. Clin Gastroenterol Hepatol Off Clin Pract J Am Gastroenterol Assoc. abril de 2012;10(4):417-421.e1-2.  
16. Muratori P, Granito A, Pappas G, Muratori L. Validation of simplified diagnostic criteria for autoimmune hepatitis in Italian patients. Hepatol Baltim Md. maio de 2009;49(5):1782–1783; author reply 1783.  
17. Qiu D, Wang Q, Wang H, Xie Q, Zang G, Jiang H, et al. Validation of the simplified criteria for diagnosis of autoimmune hepatitis in Chinese patients. J Hepatol. fevereiro de 2011;54(2):340–7. 18. Candia R, Norero B, Agüero C, Díaz L, Ortega JP, Wolff R, et al. Validation of the Simplified Criteria for the Diagnosis of Autoimmune Hepatitis in Chilean-Hispanic Patients. Ann Hepatol. outubro de 2017;16(5):772–9.  
19. European Association for the Study of the Liver. EASL Clinical Practice Guidelines: Autoimmune hepatitis. J Hepatol. 2015;63(4):971–1004.  
20. Alvarez F, Berg PA, Bianchi FB, Bianchi L, Burroughs AK, Cancado EL, et al. International Autoimmune Hepatitis Group Report: review of criteria for diagnosis of autoimmune hepatitis. J Hepatol. novembro de 1999;31(5):929–38.  
21. Czaja AJ, Souto EO, Bittencourt PL, Cancado ELR, Porta G, Goldberg AC, et al. Clinical distinctions and pathogenic implications of type 1 autoimmune hepatitis in Brazil and the United States. J Hepatol. setembro de 2002;37(3):302–8.  
22. Czaja AJ, Freese DK, American Association for the Study of Liver Disease. Diagnosis and treatment of autoimmune hepatitis. Hepatol Baltim Md. agosto de 2002;36(2):479–97. 23. Knodell RG, Ishak KG, Black WC, Chen TS, Craig R, Kaplowitz N, et al. Formulation and application of a numerical scoring system for assessing histological activity in asymptomatic chronic active hepatitis. Hepatol Baltim Md. outubro de 1981;1(5):431–5.  
24. Schalm SW, Korman MG, Summerskill WH, Czaja AJ, Baggenstoss AH. Severe chronic active liver disease. Prognostic significance of initial morphologic patterns. Am J Dig Dis. novembro de 1977;22(11):973–80.  
25. Murray-Lyon IM, Stern RB, Williams R. Controlled trial of prednisone and azathioprine in active chronic hepatitis. Lancet Lond Engl. 7 de abril de 1973;1(7806):735–7.  
26. Lamers MMH, van Oijen MGH, Pronk M, Drenth JPH. Treatment options for autoimmune hepatitis: a systematic review of randomized controlled trials. J Hepatol. julho de 2010;53(1):191–8. 27. Boberg KM, Chapman RW, Hirschfield GM, Lohse AW, Manns MP, Schrumpf E, et al. Overlap syndromes: the International Autoimmune Hepatitis Group (IAIHG) position statement on a controversial issue. J Hepatol. fevereiro de 2011;54(2):374–85.  
28. Cook GC, Mulligan R, Sherlock S. Controlled prospective trial of corticosteroid therapy in active chronic hepatitis. Q J Med. abril de 1971;40(158):159–85.  
29. Schalm SW, Summerskill WH, Go VL. Prednisone for chronic active liver disease: pharmacokinetics, including conversion to prednisolone. Gastroenterology. maio de 1977;72(5 Pt 1):910–3.  
30. Summerskill WH, Korman MG, Ammon HV, Baggenstoss AH. Prednisone for chronic active liver disease: dose titration, standard dose, and combination with azathioprine compared. Gut. novembro de 1975;16(11):876–83.  
31. Stellon AJ, Keating JJ, Johnson PJ, McFarlane IG, Williams R. Maintenance of remission in autoimmune chronic active hepatitis with azathioprine after corticosteroid withdrawal. Hepatol Baltim Md. agosto de 1988;8(4):781–4.  
32. Johnson PJ, McFarlane IG, Williams R. Azathioprine for long-term maintenance of remission in autoimmune hepatitis. N Engl J Med. 12 de outubro de 1995;333(15):958–63.  
33. Zachou K, Gatselis N, Papadamou G, Rigopoulou EI, Dalekos GN. Mycophenolate for the treatment of autoimmune hepatitis: prospective assessment of its efficacy and safety for induction and maintenance of remission in a large cohort of treatment-naïve patients. J Hepatol. setembro de 2011;55(3):636–46.  
34. Selvarajah V, Montano-Loza AJ, Czaja AJ. Systematic review: managing suboptimal treatment responses in autoimmune hepatitis with conventional and nonstandard drugs. Aliment Pharmacol Ther. outubro de 2012;36(8):691–707.  
35. Manns MP, Czaja AJ, Gorham JD, Krawitt EL, Mieli-Vergani G, Vergani D, et al. Diagnosis and management of autoimmune hepatitis. Hepatol Baltim Md. junho de 2010;51(6):2193–213. 36. Zizzo A.N., Valentino P.L., Shah P.S., Kamath B.M. Second-line Agents in Pediatric Patients with Autoimmune Hepatitis: A Systematic Review and Meta-analysis. J Pediatr Gastroenterol Nutr. 2017;65(1):6–15.  
37. De Lemos-Bonotto M, Valle-Tovo C, Costabeber AM, Mattos AA, Azeredo-da-Silva ALF. A systematic review and meta-analysis of second-line immunosuppressants for autoimmune hepatitis treatment. Eur J Gastroenterol Hepatol. fevereiro de 2018;30(2):212–6.  
38. Manns MP, Woynarowski M, Kreisel W, Lurie Y, Rust C, Zuckerman E, et al. Budesonide induces remission more effectively than prednisone in a controlled trial of patients with autoimmune hepatitis. Gastroenterology. outubro de 2010;139(4):1198–206.  
39. Woynarowski M, Nemeth A, Baruch Y, Koletzko S, Melter M, Rodeck B, et al. Budesonide versus prednisone with azathioprine for the treatment of autoimmune hepatitis in children and adolescents. J Pediatr. novembro de 2013;163(5):1347–1353.e1.  
40. Czaja AJ, Carpenter HA, Lindor KD. Ursodeoxycholic acid as adjunctive therapy for problematic type 1 autoimmune hepatitis: a randomized placebo-controlled treatment trial. Hepatol Baltim Md. dezembro de 1999;30(6):1381–6.  
41. United States Pharmacopeial Convention. USP DI. Volume 1, Volume 1,. Greenwood Village, CO: Thomson/MICROMEDEX; 2007.  
42. Chocair PR, Duley JA, Simmonds HA, Cameron JS. The importance of thiopurine methyltransferase activity for the use of azathioprine in transplant recipients. Transplantation. maio de 1992;53(5):1051–6.  
43. Elion GB. Nobel Lecture. The purine path to chemotherapy. Biosci Rep. outubro de 1989;9(5):509–29.  
44. Physicians’ desk reference. Montvale, N.J.: Physicians’ Desk Reference Inc.;  
45. Chen Z-X, Shao J-G, Shen Y, Zhang J, Hua Y, Wang L-J, et al. Prognostic Implications of Antibodies to Soluble Liver Antigen in Autoimmune Hepatitis: A PRISMA-Compliant MetaAnalysis. Medicine (Baltimore). junho de 2015;94(23):e953.  
46. Czaja A.J. Review article: Permanent drug withdrawal is desirable and achievable for autoimmune hepatitis. Aliment Pharmacol Ther. 2014;39(10):1043–58.  
47. Feldman M, Friedman LS, Brandt LJ, organizadores. Sleisenger and Fordtran’s  
gastrointestinal and liver disease: pathophysiology/diagnosis/management. Tenth edition. Philadelphia, PA: Saunders/Elsevier; 2016. 2370 p.  
48. Tansel A, Katz LH, El-Serag HB, Thrift AP, Parepally M, Shakhatreh MH, et al. Incidence and Determinants of Hepatocellular Carcinoma in Autoimmune Hepatitis: A Systematic Review and Meta-analysis. Clin Gastroenterol Hepatol Off Clin Pract J Am Gastroenterol Assoc. agosto de 2017;15(8):1207–1217.e4.  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE PREDNISONA E AZATIOPRINA  
Eu, ____________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **prednisona** e **azatioprina** , indicadas para o tratamento da **hepatite autoimune** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico ______________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- aumento da expectativa de vida;  
- melhora da qualidade de vida;  
- melhora dos sintomas clínicos;  
- diminuição da atividade inflamatória à biópsia hepática;  
- normalização dos níveis das enzimas (aminotransferases/transaminases);  
- prevenção de recaídas.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso dos medicamentos:  
**- azatioprina** : na gravidez, há evidências de riscos ao feto, mas um benefício potencial pode ser maior do que os riscos. Caso engravide, devo avisar imediatamente o médico; para **prednisona** , não se sabe ao certo os riscos do uso na gravidez; portanto, caso engravide, deve avisar imediatamente o médico **- principais efeitos adversos da prednisona** : os mais comuns são dor de cabeça, vertigem, pressão alta, aumento da glicose no sangue, barriga inchada, suor excessivo, manchas roxas na pele, crescimento excessivo de pêlo, retenção de sódio e líquidos, bolinhas vermelhas na pele, cansaço excessivo, convulsões, aumento de peso, catarata, perda de cabelo, aumento da pressão intraocular, perda de massa muscular, dificuldade da cicatrização, alterações no período menstrual, gordura na região abdominal e no pescoço, olhos salientes ou estrias vermelhas.  
**- principais efeitos adversos da azatioprina** : efeitos adversos comuns: febre, calafrios, diminuição de apetite, vermelhidão de pele, queda de cabelo, aftas, dores articulares, problemas nos olhos (retinopatia), falta de ar, pressão baixa e reações de hipersensibilidade; hematológicos: anemia, diminuição das células brancas, vermelhas e plaquetas do sangue; gastrointestinais: náusea, vômitos, diarreia, dor abdominal, fezes com sangue, toxicidade para o fígado;;  
- os medicamentos são contraindicados em caso de hipersensibilidade (alergia) conhecida ao fármaco ou componentes da fórmula.  
_Estou ciente de que o(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-lo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei ser assistido(a), inclusive em caso de desistir de usar o(s) medicamento(s)._  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (   ) Sim                (   ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento(s):  
(    ) azatioprina  
- (    ) prednisona  
Local:                                                             Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
Assinatura do paciente ou do responsável legal Médico responsável: CRM: UF: Assinatura e carimbo do médico Data:____________________  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos referidos.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **1 LEVANTAMENTO DE INFORMAÇÕES PARA PLANEJAMENTO DA REUNIÃO DE ESCOPO COM OS ESPECIALISTAS** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), sítio da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP) e o Protocolo Clínico e Diretriz Terapêutica (PCDT) de Hepatite autoimune vigente para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas.  
A partir das consultas realizadas foi possível identificar:  
- O tratamento no SUS segue o orientado no PCDT de Hepatite Autoimune, conforme Portaria SAS/MS nº 457, de 21 de maio de 2012;  
- Os medicamentos atualmente disponíveis são: prednisona e azatioprina;  
- Não há solicitação de nenhuma nova tecnologia na CONITEC.  
Na enquete pública realizada pelo Ministério da Saúde sobre os PCDT foi identificada a seguinte contribuição na atualização do PCDT:  
- Inclusão do ácido ursodesoxicólico para os pacientes com síndrome de imbricamento em combinação com cirrose biliar primária.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **2 REUNIÃO COM ESPECIALISTAS** -->
Foi realizada reunião com o consultor especialista e metodologistas do comitê elaborador dos PCDT na qual foram apresentados os resultados do levantamento de informações realizadas pelos metodologistas. O consultor especialista não indicou a necessidade de avaliação da inclusão de nenhum medicamento.  
Sendo assim, foi estabelecido que o protocolo destina-se a pacientes com hepatite autoimune e tem por objetivo revisar práticas diagnósticas e terapêuticas a partir da data da busca do PCDT vigente.

---

<!-- METADADOS: doenca: Hepatite Autoimune | secao: **3 BUSCAS NA LITERATURA PARA ATUALIZAÇÃO DO PCDT** -->
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre intervenções terapêuticas baseadas em evidências definida pela pergunta PICO descrita no Quadro 1.  
**Quadro 1 -** Pergunta PICO  
|População|Pacientes com hepatite autoimune|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Tratamento consagrado:corticoesteroides com ou sem azatioprina.|
|Desfechos|Melhora clínica ou clínico-laboratorial|
|Tipos de estudos|Meta-análises,revisões sistemáticas(RS)e ECR|  
O Quadro 2 apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**<u>Quadro 2 -</u>** Buscas sobre intervenções terapêuticas  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline (via|"Hepatitis, Autoimmune"[Mesh]|18|7|
|PubMed)|OR "Hepatitis,<br>Autoimmune"[All Fields] AND||Motivo das exclusões:<br>1 relato de caso|
|Data da|((Meta-Analysis[ptyp] OR||1 estudo de fisiopatogenia|
|busca:|systematic[sb] OR Randomized||9 estudos que não|
|02/05/2017|Controlled Trial[ptyp]) AND<br>"2012/05/17"[PDat]:||respondiam à questão<br>PICO|  
||"2017/05/15"[PDat] AND<br>"humans"[MeSH Terms])|||
|---|---|---|---|
|Embase<br>Data da<br>busca:<br>02/05/2017|'autoimmune hepatitis'/exp/mj<br>AND ([systematic review]/lim<br>OR [meta analysis]/lim OR<br>[randomized controlled<br>trial]/lim) AND [humans]/lim<br>AND [2012-2017]/py|37|8<br>(5 dos quais também<br>encontrados no PubMed)<br>Motivo das exclusões:<br>26 estudos que não<br>respondiam à questão<br>PICO<br>3 estudos publicados<br>somente como resumos em<br>anais de congresso|
|Cochrane<br>Library<br>Data da<br>busca:<br>02/05/2017|''autoimmune hepatitis' in Title,<br>Abstract, Keywords , Publication<br>Year from 2012 to 2017 in<br>Cochrane Reviews'|0|--|  
Os artigos selecionados encontram-se na **Tabela A** .  
A fim de guiar a revisão do PCDT vigente, foi realizada busca na literatura sobre diagnóstico nos consensos e guidelines internacionais. O Quadro 3 apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**<u>Quadro 3 -</u>** Busca por consensos e _<u>guidelines internacionais</u>_ sobre diagnóstico  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|Medline<br>(via<br>PubMed)<br>Data da<br>busca:|"Hepatitis, Autoimmune"[Mesh]<br>OR "Hepatitis, Autoimmune"[All<br>Fields] AND ((Practice<br>Guideline[ptyp] OR<br>Guideline[ptyp] OR Government<br>Publications[ptyp] OR Consensus|3|2<br>**Motivo das exclusões:**<br>- 1 estudo que não tinha<br>hepatite autoimune como<br>foco da diretriz|
|02/05/2017|Development Conference,<br>NIH[ptyp] OR Consensus<br>Development Conference[ptyp])<br>AND "2012/05/17"[PDAT] :<br>"2017/05/15"[PDAT] AND<br>"humans"[MeSH Terms])|||
|National|https://www.guideline.gov/search?q|6|0|
|Guideline|=%22Autoimmune+hepatitis%22&||**Motivo das exclusões:**|
|Clearingho<br>use|f_dateRangeFrom=2012&f_dateRa<br>ngeTo=2016||- 6 estudos que não tinham<br>hepatite autoimune como<br>foco da diretriz|  
Para informações adicionais de dados nacionais sobre a doença, também foi realizada uma busca, conforme Quadro 4, que apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**Quadro 4 -** Busca por dados nacionais sobre a doença  
|**Base**|**Estratégia**|**Localizados**|**Selecionados**|
|---|---|---|---|
|MEDLINE|"Hepatitis, Autoimmune"[Mesh]|4|1|
|(via|AND "Brazil"[Mesh] AND||**Motivo das exclusões:**|
|PubMed)|"2012/05/17"[PDAT] :<br>"2017/05/15"[PDAT] AND||- 3 estudos que não<br>respondiam à questão PICO|
|Data da<br>busca:<br>24/04/2017|"humans"[MeSH Terms]|||  
Após a Consulta Pública número  62/2017, foram incorporadas mais três referências ao PCDT  (27,37,47).  
|**Tabela A -**C|aracterísticas dos estudosinclu|ídos||||||
|---|---|---|---|---|---|---|---|
|Autor, ano|Desenho|População|Intervenção|Controle|Desfecho|Resultados|Limitações e<br>comentários|
|Lemos-<br>Bonotto,<br>2018|Revisão sistemática com<br>meta-análise|Pacientes com<br>HAI|Ciclosporina,<br>tacrolimo e<br>micofenolato<br>mofetil (MMF)|Predniso<br>na com<br>ou sem<br>azatiopri<br>na|Remissão<br>laboratorial e<br>histológica|Remissão<br>laboratorial em<br>78,7% do grupo<br>MMF; remissão<br>histológica em<br>88,6% do grupo<br>MMF|Meta-análise<br>fundamentalment<br>e de séries de<br>casos e pequenas<br>coortes|
|Bittencourt,<br>2015|Diretriz|Pacientes com<br>HAI, CBP, CEP<br>ou síndromes de<br>imbricamento|Prednisona,<br>azatioprina e<br>budesonida|Não se<br>aplica|Remissão<br>clínica,<br>laboratorial e<br>histológica|Não se aplica|Nada digno de<br>nota|
|European<br>Association<br>for the<br>Study of the<br>Liver, 2015|Diretriz|Pacientes com<br>HAI ou<br>síndromes de<br>imbricamento|Prednisona,<br>prednisolona,<br>azatioprina,<br>budesonida,<br>ciclosporina,<br>tacrolimus e<br>micofenolato<br>mofetil|Não se<br>aplica|Indução e<br>manutenção<br>de remissão|Não se aplica|Nada digno de<br>nota|
|Manns,<br>2010|Diretriz|Pacientes com<br>HAI|Prednisona,<br>prednisolona,<br>azatioprina,<br>budesonida,<br>ciclosporina,<br>metotrexato,<br>ácido<br>ursodesoxicólic<br>o, tacrolimus,<br>micofenolato<br>mofetil e|Não se<br>aplica|Indução e<br>manutenção<br>de remissão|Não se aplica|Nada digno de<br>nota|  
||||transplante<br>hepático|||||
|---|---|---|---|---|---|---|---|
|Chen, 2015|- Revisão sistemática com<br>meta-análise<br>- Período da busca:<br>07/06/2017<br>- Bases consultadas:<br>EMBASE/Pubmed/OVID<br>- Critérios de elegibilidade:<br>Estudos observacionais;<br>participantes com AIH e teste<br>de anti-SLA; marcadores de<br>gravidade da doença; pelo<br>menos um dos desfechos<br>prognósticos: morte por<br>falência hepática ou<br>transplante hepático, resposta<br>à terapia imunossupressora;<br>amostra mínima de 50<br>pacientes; em língua inglesa.<br>- Objetivo: Definir se<br>pacientes com anti-SLA<br>positivos devem ser mantidos<br>indefinidamente em ajuste de<br>medicação para melhora<br>prognóstica.|Pacientes com<br>HAI|Não se aplica|Não se<br>aplica|- Primários:<br>Taxa de<br>remissão de<br>AIH com ou<br>sem anti-<br>SLA. Apenas<br>6 estudos<br>incluiram<br>taxa de<br>recaída.<br>-<br>Secundarios:<br>3 estudos<br>como<br>falência<br>hepática, 3<br>estudos como<br>frequência de<br>transplante<br>hepático e 4<br>estudos como<br>falência<br>hepática ou<br>tranplsante<br>hepático<br>como outra<br>medida de<br>desfecho.|- Taxa de<br>remissão de<br>doença entre<br>pacientes anti-<br>SLA positivos e<br>negativos não<br>foi<br>estatisticamente<br>significativa.<br>(RR:1,10, IC<br>95% 0,75-1,61,<br>8 estudos)<br>- Taxa de<br>recaída de<br>doença em<br>pacientes anti-<br>SLA positivos<br>após retirada de<br>tratamento foi<br>maior<br>(estatisticament<br>e significativa).<br>(RR: 2,24, IC<br>95% 1,38-3,64,<br>6 estudos)|-Restrição à<br>língua inglesa<br>significa perda<br>de alguns<br>estudos, em<br>particular grupos<br>étnicos se eles<br>tivessem sido<br>publicados em<br>outras línguas<br>-Estudos não<br>cobriam<br>Carcinoma<br>Hepatocelular,<br>que é um<br>desfecho da AIH|
|Zhang, 2014|- Revisão sistemática com<br>meta-análise|- Pacientes com<br>diagnóstico de<br>AIH e outras|Não se aplica|Não se<br>aplica|Desempenho<br>diagnóstico<br>na HAI|- AAN: LR+ de<br>3,030 (IC 95%<br>2,349-3,910);|-Possível viés de<br>publicação<br>-Possívelviés de|  
|- Período da busca:<br>12/06/2017<br>- Bases consultadas:<br>PubMed, CNKI, WANFANG<br>e SInoMed<br>- Critérios de elegibilidade:<br>Estudos que analisaram<br>anticorpos antinucleares,<br>anticorpos de músculo liso e<br>anticorpos de antígenos<br>hepáticos ou pancreáticos<br>solúveis em associação com<br>AIH e publicados até outubro<br>de 2013, em inglês e chinês.<br>- Objetivo: Avaliar a<br>acurácia diagnóstica de<br>anticorpos antinucleares,<br>anticorpos de músculo liso e<br>anticorpos de antígenos<br>hepáticos ou hepato-<br>pancreáticos solúveis em AIH|doenças ""não-<br>AIH"" como<br>cirrose biliar<br>primária,<br>colangite<br>esclerosante<br>primária,<br>colangite<br>autoimune,<br>doenças<br>reumáticas e<br>outras doenças<br>hepáticas.<br>(Idade média:<br>grupo AAN<br>42,43 anos<br>(74,62%<br>mulheres);<br>grupo AML<br>43,47 anos<br>(74,35%<br>mulheres)  e<br>grupo anti-<br>SLA/LP 36,90<br>anos (68,31%).<br>Pacientes de<br>diferentes<br>regiões,<br>incluindo<br>China, Japão,<br>IRaque,<br>Alemanha,<br>França, Itália,<br>Turquia,Reino|LR- de 0,464<br>(IC 95% 0,356-<br>0,604).<br>Sensibilidade<br>0,650 (IC 95%<br>0,619-0,680);<br>Especificidade<br>0,751 (IC 95%<br>0,737-0,764);<br>DOR<br>(diagnostic odds<br>ratio) de 7,380<br>(IC 95% 4,344-<br>12,539)<br>- AML: LR+ de<br>11,740 (IC 95%<br>7,37-18,678);<br>LR- de 0,449<br>(IC 95% 0,367-<br>0,549).<br>Sensibilidade de<br>0,593 (IC 95%<br>0,564-0,621);<br>Especificidade<br>de 0,926(IC<br>95% 0,917-<br>0,934); DOR de<br>31,553 (IC 95%<br>17,147-58,060)<br>- Anti-SLA/LP:<br>LR+ de 11,089<br>(IC 95% 7,601-<br>16,177); LR- de<br>0,839 (CI95%|seleção: apenas<br>estudos em<br>chinês e inglês|
|---|---|---|---|  
|||Unido, Áustria e<br>Suécia.)||||0,777-0,905);<br>Sensibilidade de<br>0,194 (IC 95%<br>0,168-0,222);<br>Especificidade<br>de 0,989 (IC<br>95% 0,985-<br>0,993) ; DOR<br>de 16,867 (IC<br>95% 10,956-<br>25,967).||
|---|---|---|---|---|---|---|---|
|Chen, 2014|- Revisão Sistemática com<br>Meta-análise<br>- Período da busca:<br>13/06/2017<br>- Bases consultadas:<br>MEDLINE, PubMed e<br>EMBASE.<br>- Critérios de elegibilidade:<br>seguindo a diretriz PRISMA.<br>Foram procurados estudos<br>usando termos como<br>"hepatite autoimune em<br>idosos", "hepatite autoimune<br>E idosos", "hepatite<br>autoimune E aging", "hepatite<br>autoimune E pacientes mais<br>velhos", "hepatite autoimune<br>E envelhecimento", e esses<br>termos foram procurados<br>como texto. Não foi usado<br>restrição de idioma tanto na<br>pesquisa, quanto na seleção.<br>Não foi feitapesquisapor|- Pacientes com<br>AIH. 264 idosos<br>(com idade >65<br>anos em 7<br>estudos e >60<br>em 3 estudos).<br>592 pacientes<br>mais novos<br>(quaisquer<br>pacientes abaixo<br>dessas faixas<br>supracitadas).<br>Em um estudo,<br>foi criado cinco<br>grupos de<br>comparação<br>com  a faixa<br>etária mais<br>avançada, tendo<br>como um braço<br>acima de 60<br>anos e a faixa<br>maisjovem de|Não se aplica|Não se<br>aplica|-<br>Comparação<br>de resposta<br>clínica e<br>laboratorial<br>entre<br>pacientes<br>jovens e<br>idosos|- Parâmetros<br>Bioquímicos:<br>média<br>comparativa<br>entre idosos e<br>mais novos.<br>TGO: 368 x<br>328u/l p=0.06;<br>TGP 442 x 426<br>p=0,53;<br>BT 54 x<br>47umol/L<br>p=0,30;<br>Gamaglobulina<br>30 x 27g/L<br>p=0,39;<br>Albumina 33 x<br>38g/L p=0,39.<br>- Razão de<br>probabilidade<br>de idosos<br>apresentarem a<br>informação|Todos os estudos<br>incluídos na<br>meta-análise<br>eram<br>retrospectivos|  
|publicações não publicadas.<br>- Objetivo: Demonstrar<br>manifestações clinicas e<br>conduta para AIH em<br>pacientes idosos.|18 a 30 anos,<br>com 47 e 31<br>pacientes,<br>respectivamente<br>. Em outro<br>estudo, apesar<br>de 120<br>pacientes terem<br>AIH, houve 20<br>pacientes acima<br>de 65 anos,<br>sendo usado 20<br>dos pacientes<br>mais jovens<br>para o estudo.<br>-76% dos<br>pacientes no<br>estudo eram do<br>sexo feminino.<br>Pacientes idosas<br>perfizeram 21%<br>do total de<br>pacientes dos 10<br>estudos.|escolhida em<br>relação aos mais<br>jovens.<br>Cirrose: OR<br>1,56 IC 95%<br>1,03-2,43<br>p=0,34.<br>HLA DR3 OR<br>0,45 IC 95%<br>0,27-0,75<br>p=0,39.<br>HLA DR4 OR<br>2,94 IC 95%<br>1,21-7,14<br>p=0,08.<br>Assintomáticos<br>OR 2,59 IC<br>95% 1,11-6,05<br>p=0,19.<br>Recaída OR<br>0,38 IC 95%<br>0,23-0,36<br>p=0,49<br>Doenças<br>autoimunes OR<br>1,25 IC 95%<br>0,76-2,08<br>p=0,27<br>Doenças<br>autoimunes da<br>tireoide OR<br>2,71 IC 95%<br>1,18-6,19<br>p=0,22|
|---|---|---|  
|||||||AAN OR 1,24<br>IC 95% 0,42-<br>3,66 p=0,007<br>AML OR 0,73<br>IC 0,32-1,65<br>p=0,02<br>Apresentacão<br>aguda OR 1,83<br>IC 95% 0,90-<br>3,74 p=0,03<br>Apresentação<br>crônica OR 0,56<br>IC 95% 0,28-<br>1,12 p=0,08<br>Resposta<br>completa OR<br>1,21 IC 95%<br>0,66-2,22<br>p=0,88<br>Resposta parcial<br>OR 1,33 IC<br>95% 0,44-4,06<br>p=0,22<br>Falha de<br>tratamento OR<br>0,47 IC 95%<br>0,09-2,41<br>p=0,24||
|---|---|---|---|---|---|---|---|
|Woynarows<br>ki, 2013|Ensaio clínico randomizado|- 46 pacientes<br>com AIH<br>conforme<br>diagnóstico<br>orientado pelos<br>critérios do|Budesonida<br>3mg/dia ou BID<br>+ Azatioprina 1-<br>2mg/kg/dia|Controle<br>:<br>Predniso<br>na<br>40mg/di<br>a|- Primários:<br>Remissão<br>bioquímica<br>completa<br>(TGO e TGP<br>em níveis|- Na primeira<br>visita (6 meses),<br>o desfecho<br>primário foi<br>alcançado em 3<br>dos 19 pacientes|Potencial viés de<br>seleção: grupos<br>heterogêneos|  
|grupo<br>internacional de<br>hepatite<br>autoimune.<br>(11 homens e 35<br>mulheres) com<br>idade na faixa<br>de 9-17 anos.|escalona<br>ndo para<br>10mg/di<br>a +<br>Azatiopr<br>ina 1-<br>2mg/kg/<br>dia|normais) sem<br>efeitos<br>adversos<br>associados<br>aos<br>medicamento<br>s esteroides.<br>-<br>Secundários:<br>Mudança de<br>peso durante<br>os períodos<br>de tratamento<br>e seguimento|(16%) do grupo<br>budesonida e 4<br>dos 27 (15%)<br>dos pacientes do<br>grupo<br>prednisona.<br>Remissão<br>bioquímica foi<br>atingida em 6<br>dos 19 (32%) no<br>primeiro grupo<br>e 9 dos 27<br>(33%) no<br>segundo grupo.<br>A diferença<br>entre os grupos<br>não foi<br>estatisticamente<br>significativa.<br>- Na segunda<br>visita (12<br>meses), a<br>remissão<br>bioquímica<br>completa foi<br>alcançada em 9<br>dos 18 (50%) do<br>primeiro grupo<br>e 10 dos 24<br>(42%) no<br>segundo grupo.<br>A diferença<br>entre os dois<br>grupos não foi|
|---|---|---|---|  
|||||||estatisticamente<br>significante.<br>- Efeitos<br>adversos:<br>incluíram face<br>em lua cheia<br>(11% na<br>budesonida,<br>44% na<br>prednisona;<br>p=0,01), acne<br>(21% vs. 26%<br>p=não<br>signicativo) e<br>estrias violáceas<br>(5% vs 11%<br>p=não<br>significativo). O<br>ganho de peso<br>foi<br>significativame<br>nte menor no<br>grupo<br>budesonida<br>(1,2kg<br>vs 5,1kg<br>p=0,006).||
|---|---|---|---|---|---|---|---|
|Selvarajah,<br>2012|- Revisão Sistemática<br>- Período da busca:<br>14/06/2017<br>- Bases consultadas:<br>PubMed<br>-Critérios de elegibilidade:|- Pacientes com<br>hepatite<br>autoimune.|Prednisona,<br>prednisolona,<br>azatioprina,<br>budesonida,<br>ciclosporina,<br>tacrolimus e|Não se<br>aplica|- Primários:<br>Resposta ao<br>tratamento<br>com<br>medicamento<br>s|- Respostas<br>insuficientes<br>envolveram<br>falha de<br>tratamento<br>(7%),resposta|- Não relata<br>quantos estudos<br>foram incluídos,<br>quais estudos e<br>como foram<br>realizadas buscas|  
|Artigos em inglês com o<br>termo "hepatite autoimune".<br>Experiência pessoal dos<br>autores e estudos<br>investigacionais ajudaram a<br>identificar contribuições<br>importantes na literatura.<br>- Objetivo: Comparar a<br>resposta ao tratamento sub-<br>ótimo na hepatite auto-imune<br>em relação a medicamentos<br>convencionais e não-<br>convencionais.|micofenolato<br>mofetil|convencionai<br>s vs não-<br>convencionai<br>s.|incompleta<br>(14%),<br>toxicidade de<br>medicamento<br>(13%) e recaída<br>após retirada<br>dos<br>medicamentos<br>(50-86%)<br>- A<br>probabilidade<br>de resposta<br>insuficiente é<br>maior em<br>pacientes jovens<br>e em pacientes<br>com<br>apresentação<br>grave, icterícia,<br>MELD alto no<br>diagnóstico,<br>necrose<br>multilobular ou<br>cirrose, Anti-<br>SLA positivo ou<br>inabilidade de<br>melhora dos<br>índices clínicos<br>em duas<br>semanas ou de<br>score MELD<br>durante 7 dias<br>de tratamento<br>convencional|e extração dos<br>dados|
|---|---|---|---|---|  
|||||||com<br>corticosteroides.<br>- Após<br>diagnosticada<br>resposta<br>insuficiente, ela<br>deve ser tratada<br>com um nível<br>alto de<br>individualização<br>e um regime de<br>monitoramento<br>constante,<br>preferindo<br>medicamentos<br>convencionais.||
|---|---|---|---|---|---|---|---|
|Zizzo, 2017|Revisão sistemática com<br>meta-análise|Pacientes<br>pediátricos com<br>HAI|Micofenolato<br>mofetil,<br>tacrolimus e<br>ciclosporina|Sem<br>grupo<br>controle|Taxa de<br>resposta<br>clínica em 6<br>meses|Micofenolato<br>mofetil: 36%<br>Ciclosporina<br>83%<br>Tacrolimus:<br>50%|Incluídos<br>somente estudos<br>não controlados|
|Tansel, 2015|Revisão sistemática|Pacientes com<br>HAI|Não se aplica|Não se<br>aplica|Incidência de<br>carcinoma<br>hepatocelular|Densidade de<br>incidência de<br>carcinoma<br>hepatocelular de<br>0,24 por 100<br>pacientes-ano e,<br>para cirróticos<br>com HAI, 0,83<br>por 100<br>pacientes-ano|6 dos 14 estudos<br>incluídos eram<br>retrospectivos|
|Czaja, 2014|Revisão narrativa da<br>literatura|Pacientes com<br>HAI|Não se aplica|Não se<br>aplica|Manutenção<br>da remissão|19 a 40% dos<br>pacientes com|Delineamento<br>propenso aviés|  
|após|tratamento|
|---|---|
|suspensão do|suspenso a pelo|
|tratamento|menos 3 anos|
||conseguem<br>manter a doença|
||em remissão|

---

