<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: SECRETARIA DE ATENÇÃO À SAÚDE -->
PORTARIA N° 16 DE 15 DE JANEIRO DE 2010.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecer parâmetros sobre a Hiperplasia Adrenal Congênita no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade, precisão de indicação e posologia;  
Considerando a Consulta Pública SAS/MS n° 13, de 07 de dezembro de 2009;  
Considerando a Portaria SAS/MS nº 375, de 10 de novembro de 2009, que aprova o roteiro a ser utilizado na elaboração de PCDT, no âmbito da Secretaria de Atenção à Saúde; e  
Considerando a avaliação da Secretaria de Atenção à Saúde - Departamento de Atenção Especializada, resolve:  
Art. 1º - Aprovar, na forma do Anexo desta Portaria, o PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS - HIPERPLASIA ADRENAL CONGÊNITA.  
§ 1º - O Protocolo, objeto deste Artigo, que contêm o conceito geral da Hiperplasia Adrenal Congênita, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes;  
§ 2º - É obrigatória a observância desse Protocolo para fins de dispensação do medicamento nele previsto;  
§ 3º - É obrigatória a cientificação ao paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso do medicamento preconizado para o tratamento da Hiperplasia Adrenal Congênita, o que deverá ser formalizado por meio da assinatura do respectivo Termo de Esclarecimento e Responsabilidade, conforme o modelo integrante do Protocolo.  
§ 4º - Os gestores estaduais e municipais do Sistema Único de Saúde - SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 2º - Esta Portaria entra em vigor na data de sua publicação.  
Art. 3º - Fica revogada a Portaria SAS/MS nº 849, de 31/10/2002, publicada no Diário Oficial da União, de 04 de novembro de 2002, Seção 1, pág. 85.  
ALBERTO BELTRAME

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 1. METODOLOGIA DE BUSCA DA LITERATURA -->
Utilizou-se como estratégia de busca no Pubmed os termos " _Adrenal Hyperplasia, Congenital_ "[Mesh] e " _Diagnosis_ "[Mesh]) e " _Therapeutics_ "[Mesh], e restringindo-se para artigos em humanos, publicados nos últimos 10 anos, resultou em 50 artigos. Busca na mesma base de dados, utilizando-se a estratégia de busca " _Adrenal Hyperplasia, Congenital_ "[Mesh] e _Clinical Trials_ restringindo-se para artigos em humanos, publicados nos últimos 10 anos, resultou em outros 50 artigos. Todos os artigos foram revisados e os 22 identificados como de interesse, incluídos na a elaboração do protocolo. Também foram consultados livros-texto de endocrinologia.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 2. INTRODUÇÃO -->
A denominação hiperplasia adrenal congênita (HAC) engloba um conjunto de síndromes transmitidas de forma autossômica recessiva (1,2) que se caracterizam por diferentes deficiências enzimáticas na síntese dos esteróides adrenais. A incidência de HAC é variável entre diferentes populações, com incidências da forma perdedora de sal variando de 1:280 (3) a 1:42.000 nascidosvivos (4). No Brasil, a incidência da HAC forma perdedora de sal parece ser de aproximadamente 1:7.500 (5) a 1:10.000 nascidos-vivos (6). As deficiências enzimáticas mais comuns na HAC são: 21hidroxilase (CYP21A2), que responde por cerca de 95% dos casos (2); e 11-beta-hidroxilase (CYP11B1), encontrada em aproximadamente 5% dos casos. Tanto a 21-hidroxilase como a 11-betahidroxilase, estão envolvidas na rota de síntese do cortisol e da aldosterona. Casos muito raros de HAC por deficiência nas enzimas 20,22-desmolase (CYP11A1), 17-alfa-hidroxilase (CYP17), 3-betahidroxisreróide-desidrogenase (HSD3B2), aldosterona sintase (CYP11B2) e hiperplasia lipóide (StAR) podem ocorrer.  
As manifestações clínicas das HAC dependem da enzima envolvida, e do grau de deficiência enzimática (total ou parcial). A apresentação clínica pode ocorrer por insuficiência glicocorticóide (deficiência na síntese de cortisol), insuficiência mineralocorticóide (deficiência na síntese da aldosterona) ou do excesso de andrógenos (desvio da rota de síntese hormonal, com aumento de síntese dos precursores androgênicos). Em casos de HAC por deficiência das enzimas 11-betahidroxilase e 17-alfa-hidroxilase, o acúmulo dos precursores pregnenolona e progesterona pode ocasionar desvio na rota, e aumento na síntese do mineralocorticóide desoxicorticosterona, com conseqüente hipertensão e hipocalemia. As síndromes clínicas mais freqüentes da HAC podem ser divididas em 3 formas:  
Forma clássica perdedora de sal:  
Constitui a forma mais comum de HAC clássica (60% dos casos). Nos recém nascidos do sexo feminino há virilização da genitália externa (aumento de clitóris, fusão labial e formação de seio urogenital), decorrente do excesso de andrógenos durante a vida intra-uterina. Nos recém nascidos do sexo masculino e nos do sexo feminino nos quais a virilização da genitália externa não foi identificada, como há deficiência mineralocorticóide, a apresentação é nos primeiros dias de vida com crise adrenal: depleção de volume, desidratação, hipotensão, hiponatremia e hipercalemia.  
Forma clássica não perdedora de sal (virilizante simples):  
Nos recém nascidos do sexo feminino há virilização da genitália externa. Como nesta forma não há deficiência mineralocorticóide com repercussão clínica, os recém nascidos do sexo masculino são frequentemente identificados em idade tardia por sinais de hiperandrogenismo: velocidade de  
crescimento aumentada, maturação óssea acelerada, ou pubarca precoce.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: Forma não-clássica (de início tardio): -->
Esta forma de apresentação é cerca de 15 vezes mais freqüente que a forma clássica de HAC (7). Os pacientes com as formas não-clássicas frequentemente são assintomáticos ou se apresentam tardiamente na infância ou adolescência. No sexo feminino, devido ao hiperandrogenismo decorrente da deficiência enzimática, a apresentação pode ser por aumento de clitóris, pubarca precoce, ciclos menstruais irregulares e hirsutismo. No sexo masculino, o quadro costuma ser assintomático.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- E25.0 Transtornos adrenogenitais congênitos associados a deficiência enzimática

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 4.1 CLÍNICO -->
Em recém nascidos do sexo feminino, o diagnóstico de HAC forma clássica é suspeitado pela presença de virilização da genitália externa. Já em recém nascidos do sexo masculino, o diagnóstico clínico de HAC é dependente do grau de deficiência mineralocorticóide. A HAC forma perdedora de sal apresenta-se nos primeiros dias de vida com desidratação, hipotensão, taquicardia, vômitos, perda de peso, letargia, hiponatremia e hipercalemia. A HAC forma não-perdedora de sal (virilizante simples), no sexo masculino, apresenta-se mais tardiamente, com pubarca precoce, velocidade de crescimento aumentada ou maturação óssea acelerada (2).  
O diagnóstico de HAC forma não-clássica, em pacientes do sexo feminino, deve ser considerado em meninas com sintomas ou sinais de hiperandrogenismo. Os pacientes do sexo masculino com diagnóstico de HAC forma não-clássica são geralmente assintomáticos. Entretanto, alguns desses pacientes, com tecido adrenal ectópico em testículo, podem apresentar aumento do volume testicular e oligospermia.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 4.2 LABORATORIAL -->
As deficiências enzimáticas da HAC, na síntese do cortisol e da aldosterona, levam ao acúmulo de metabólitos precursores, dentre estes a 17-OH-progesterona.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: Forma clássica -->
A dosagem de 17-OH-progesterona é utilizada como forma de rastreamento neonatal através do Teste do Pezinho (8). Os valores de 17-OH-progesterona em neonatos dependem da idade gestacional ao nascimento (9), da idade de coleta do exame (10), do peso de nascimento (10) e do sexo (11). O uso de corticóide antenatal pela mãe, devido a sua passagem transplacentária, pode suprimir a produção de 17-OH-progesterona no neonato, podendo ocasionar resultados falsonegativos (12). Os valores de referência para ponto de corte para rastreamento de HAC variam de 15 a 40ng/mL.  
Pacientes com rastreamento positivo para HAC por papel filtro devem confirmar o resultado através de dosagem de 17-OH-progesterona em sangue periférico. Em neonatos, valores de 17-OHprogesterona < 10ng/mL excluem HAC. Pacientes com HAC geralmente apresentam dosagem de 17OH-progesterona > 35ng/mL, sendo que resultados de 17-OH-progesterona > 100ng/mL, vistos na maioria dos pacientes com HAC forma clássica, confirmam o diagnóstico (13). Quando os resultados de 17-OH-progesterona basais são indeterminados, teste de estímulo com 250mcg de ACTH, ou testagem por biologia molecular, são opções para complementação da avaliação (1).  
Forma não-clássica  
Valores de 17-OH-progesterona > 0,8ng/mL em crianças, e > 2ng/mL em mulheres adultas (coletados durante a fase folicular do ciclo menstrual) sugerem o diagnóstico. Nesses casos, teste de estímulo com 250mcg de ACTH, com dosagem de 17-OH-progesterona > 10ng/mL confirma o diagnóstico (14).

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 5. CRITÉRIOS DE INCLUSÃO -->
Para uso de glicocorticorticóides:  
Apresentar diagnóstico de HAC clássica com ou sem deficiência mineralocorticóide, segundo os critérios abaixo:  
Diagnóstico de HAC clássica: feito através de dosagem de 17-OH-progesterona em amostra de sangue periférico com valores > 100ng/mL (basal ou após estímulo com 250mcg de ACTH);  
Para uso de mineralocorticóide:  
Diagnóstico de deficiência mineralocorticóide (forma perdedora de sal): além da dosagem de 17-OH-progesterona em amostra de sangue periférico com valores > 100ng/mL (basal ou após estímulo com 250mcg de ACTH), quadro clínico e dosagem em sangue periférico de sódio e potássio ou renina e aldosterona. Em pacientes com sinais de deficiência mineralocorticóide, são resultados considerados diagnósticos:  
- Hiponatremia, (sódio < 135 mEq/L e hipercalemia (potássio > 5,5 mEq/L);  
- Renina acima do valor de referência e aldosterona abaixo do valor de referência.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 6. CRITÉRIOS DE EXCLUSÃO -->
- Resultado de teste do pezinho com 17-OH-progesterona elevada, sem exame confirmatório  
- em amostra de sangue.  
- Paciente com contra-indicação ou intolerância aos medicamentos especificados.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 7. CASOS ESPECIAIS -->
Pacientes do sexo masculino, assintomáticos, com HAC forma não-clássica, não necessitam de tratamento. O tratamento de pacientes do sexo feminino com diagnóstico de HAC forma nãoclássica deve ser seguido conforme Protocolo Clínico e Diretrizes Terapêuticas do Hirsutismo.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 8. COMITÊ DE ESPECIALISTAS/ CENTRO DE REFERÊNCIA (CR) -->
Pacientes com Hiperplasia Adrenal Congênita devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. Recomenda-se  o atendimento em centro de referência, que facilita o tratamento em si, bem como o ajuste das doses conforme necessário e o controle de efeitos adversos.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9. TRATAMENTO -->
O tratamento de pacientes com HAC deve ser dirigido a suprir as deficiências glicocorticóide e mineralocorticóide, e remediar os sinais/sintomas da hiperandrogenemia. O tratamento com contraceptivos orais e antiandrogênicos deve ser seguido conforme protocolo clínico e diretrizes terapêuticas do Hirsutismo É fundamental, para o caso de necessidade de atendimento médico emergencial, que todo paciente com HAC forma clássica porte consigo identificação (pulseira, corrente ou cartão) que informe da sua condição e que contenha instruções de medidas a serem tomadas (1).

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9.1.1 GLICOCORTICÓIDES -->
- Dexametasona: Elixir de 0,1mg/ml; Comprimido de 4mg., Sol. injetável de 4mg/mL.  
- Prednisona: Comprimidos de 5 e 20mg.  
- Prednisolona: Solução oral de 1,34mg/mL  
- Hidrocortisona: Solução injetável de 100 e 500mg.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9.1.2 MINERALOCORTICÓIDE -->
- Fludrocortisona: Co           mprimidos de 0,1 mg.  
Tabela 1. Potências biológicas relativas dos esteróides sintéticos em relação ao cortisol.  
|Esteróide|Atividade<br>anti-<br>inflamatória<br>(15)|Retenção<br>salina<br>(16)|Supressão<br>do eixo<br>Hipotálamo-<br>Hipófise<br>(15)|
|---|---|---|---|
|Cortisol/Hidrocortisona|1|1|1|
|Fludrocortisona|12|125|12|
|Prednisona|3|0,8|4|
|Prednisolona|3|0,8|4|
|Dexametasona|26|0|17|  
* Em pessoas sem deficiência enzimática, a produção diária de cortisol é estimada em 7-9mg/m<sup>2</sup> em neonatos (17), 6-7mg/m<sup>2</sup> em crianças e adolescentes (18) e 10-15mg em adultos (19).  
- 9.2 ESQUEMAS DE ADMINISTRAÇÃO

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9.2.1 GLICOCORTICÓIDES -->
O tratamento com glicocorticóides deve ser feito com a menor dose possível para manter controlados os níveis de andrógenos. A tentativa de supressão extrema dos níveis de andrógenos leva a excesso glicocorticóide, com desenvolvimento de Síndrome de _Cushing_ iatrogênica (1). Tanto o excesso de andrógenos (subtratamento), como de glicocorticóides (sobretratamento), tem impacto negativo no crescimento de crianças com HAC (20, 21). O tratamento da HAC pode ser realizado com qualquer um dos glicocorticóides listados abaixo:  
Dexametasona: administrada por via oral, intramuscular ou endovenosa, em dose única diária. Dose inicial: crianças 0,27mg/m<sup>2</sup> /dia (22) e adultos 0,25-0,75mg/dia. Prednisona: administrada por via oral, em dose única diária.  
Dose inicial: - crianças 2,5-4mg/m<sup>2</sup> /dia (23) e adultos 2,5-7,5mg/dia. Prednisolona: administrada por via oral, em dose única diária. Dose inicial: crianças 2-3mg/m<sup>2</sup> /dia (23, 24) e adultos 2,5-7,5mg/dia. Hidrocortisona: administrada por intramuscular ou endovenosa:  
Dose inicial: crianças 12-18mg/m<sup>2</sup> /dia (em estresse/crise adrenal 60-100mg/m<sup>2</sup> /dia) (1) e adultos 20mg/dia (em crise adrenal 200-300mg/dia).  
Em gestantes com HAC, para evitar a exposição fetal ao glicocorticóide, o tratamento é realizado de preferência com glicocorticóide metabolizável pela placenta (ex. prednisona, prednisolona ou hidrocortisona).  
Tabela 2. Glicocorticóides usados no tratamento da HAC.  
|Esterói<br>de|Dose-<br>equiv<br>alent<br>e|Dose-<br>equiv<br>alent<br>e|Do<br>ses<br>ao<br>dia|½<br>vid<br>a<br>(ho<br>ras|Vias<br>de<br>admini|
|---|---|---|---|---|---|  
||em<br>crianç<br>as<br>(mg/<br>m<sup>2</sup>/di<br>a)<br>(23)|em<br>adult<br>os<br>(mg/<br>dia)<br>(15)||)<br>(15<br>)|straçã<br>o|EV = endovenoso; IM = intramuscular; VO = via<br>oral.<br>9.2.2 MINERALOCORTICÓIDE<br>O tratamento com mineralocorticóide<br>(fludrocortisona) deve ser feito nos pacientes com<br>HAC forma perdedora de sal, com a o objetivo de|
|---|---|---|---|---|---|---|
|Hidroc<br>ortiso<br>na|10-18|20|2-4|12|EV, IM|normalizar a volemia, e corrigir os distúrbios de<br>sódio e potássio. Em crianças com < 6 meses,<br>devido<br>à<br>menor<br>sensibilidade<br>renal<br>aos|
|Predni<br>sona|2,5-4|5|1|12-<br>36|VO|mineralocorticóides, pode ser necessário uso de<br>doses altas de fludrocortisona e administração de|
|Predni<br>solona|2-3|5|1|12-<br>36|VO|1-3g/dia de sal suplementar (25). Após os 6-12<br>meses de vida, a dose pode ser gradualmente|
|Dexam<br>etason<br>a|0,27|0,7|1|>4<br>8|EV,<br>IM, VO|reduzida até se atingir a dose de manutenção, que<br>normalmente é de 0,1mg/dia.<br>Fludrocortisona: Administrada por via oral,<br>em dose única diária.|  
- crianças 0,1 mg/dia (podendo variar de  
0,05-0,3mg/dia).  
- adultos 0,1 mg/dia (podendo variar de 0,05-0,4mg/dia).

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9.3 TEMPO DE TRATAMENTO -->
O tratamento com glicocorticóides e mineralocorticóides deve ser feito ao longo da vida em pacientes com HAC forma clássica.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 9.4 BENEFÍCIOS ESPERADOS -->
O tratamento da HAC forma perdedora de sal com fludrocortisona salva vidas de pacientes afetados. Apesar disso, nestes pacientes, mesmo com o tratamento instituído, quando há problemas de entendimento da doença e de adesão ao tratamento, o risco de morte por insuficiência adrenal aguda (crise adrenal) permanece aumentado (26).  
O tratamento da HAC melhora o padrão de crescimento sem, entretanto, normalizá-lo. Pacientes com HAC tratados adequadamente atingem altura final cerca de 1,5 desvios-padrão (~10cm) abaixo da altura prevista (27).

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 10. MONITORIZAÇÃO -->
O acompanhamento deve ser feito a cada 3 meses até o primeiro ano de vida e, em crianças com tratamento adequado, a cada 4-6 meses após esse período.  
As dosagens de 17-OH-progesterona, androstenediona e testosterona total são realizadas para acompanhamento da reposição de glicocorticóides, com objetivo de manter as dosagens de 17-OH-progesterona entre 4-12ng/mL (1) e androstenediona e testosterona total em valores pouco acima do limite superior do valor de referência. É importante que em todas as consultas sejam avaliados sinais clínicos de excesso glicocorticóide, como fragilidade capilar, presença de giba, estrias violáceas, fácies de lua cheia, fraqueza muscular proximal e hipertensão. Velocidade de crescimento e maturação óssea devem ter especial atenção, devendo a medida da altura fazer parte de todas as consultas de acompanhamento. A maturação óssea é acompanhada através de realização anual de Raio-X de mãos e punhos para estimativa da idade óssea.  
Para acompanhamento da reposição de mineralocorticóide, é importante dosar renina, sódio e potássio. Os objetivos do tratamento são normalizar sódio (135-145 mEq/L) e potássio (3,5-5,5  
mEq/L), e não suprimir a renina, mantendo a pressão arterial normal. Supressão de renina ou hipertensão podem indicar excesso mineralocorticóide, sendo necessária revisão da dose de fludrocortisona.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 11. ACOMPANHAMENTO PÓS-TRATAMENTO -->
O tratamento deve ser contínuo ao longo da vida, com intervalo entre consultas levando em consideração os dados clínicos, e com realização de exames laboratoriais conforme sugerido no item Monitorização.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 12. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Há de se observar os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 13. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER -->
É obrigatória a cientificação do paciente ou de seu responsável legal dos potenciais riscos, benefícios e efeitos colaterais ao uso dos medicamentos preconizados neste protocolo. O TER é obrigatório ao se prescrever medicamento do Componente Especializado da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: 14. REFERÊNCIAS BIBLIOGRÁFICAS -->
1. Merke DP, Bornstein SR. Congenital adrenal hyperplasia. Lancet. 2005 Jun 18-24;365(9477):212536.  
2. Merke DP, Bornstein SR, Avila NA, Chrousos GP. NIH conference. Future directions in the study and management of congenital adrenal hyperplasia due to 21-hydroxylase deficiency. Ann Intern Med. 2002 Feb 19;136(4):320-34.  
3. Pang S, Murphey W, Levine LS, Spence DA, Leon A, LaFranchi S, et al. A pilot newborn screening for congenital adrenal hyperplasia in Alaska. J Clin Endocrinol Metab. 1982 Sep;55(3):413-20.  
4. Therrell BL, Jr., Berenbaum SA, Manter-Kapanke V, Simmank J, Korman K, Prentice L, et al. Results of screening 1.9 million Texas newborns for 21-hydroxylase-deficient congenital adrenal hyperplasia. Pediatrics. 1998 Apr; 101(4 Pt 1):583-90.  
5. Pang SY, Clark A. Congenital adrenal hyperplasia due to 21-hydroxylase defieiency: newbom screening and its relationship to the diagnosis and treatment of the disorder. Screening. 1993;2:10539.  
6. Silveira EL, dos Santos EP, Bachega TA, van der Linden Nader I, Gross JL, Elnecave RH. The actual incidence of congenital adrenal hyperplasia in Brazil may not be as high as inferred--an estimate based on a public neonatal screening program in the state of Goias. J Pediatr Endocrinol Metab. 2008 May;21(5):455-60.  
7. Labarta JI, Bello E, Ruiz-Echarri M, Rueda C, Martul P, Mayayo E, et al. Childhood-onset congenital adrenal hyperplasia: long-term outcome and optimization of therapy. J Pediatr Endocrinol Metab. 2004 Mar;17 Suppl 3:411-22.  
8. Speiser PW. Prenatal and neonatal diagnosis and treatment of congenital adrenal hyperplasia. Horm Res. 2007;68 Suppl 5:90-2.  
9. van der Kamp HJ, Oudshoorn CG, Elvers BH, van Baarle M, Otten BJ, Wit JM, et al. Cutoff levels of 17-alpha-hydroxyprogesterone in neonatal screening for congenital adrenal hyperplasia should be based on gestational age rather than on birth weight. J Clin Endocrinol Metab. 2005 Jul;90(7):39047.  
10. Olgemoller B, Roscher AA, Liebl B, Fingerhut R. Screening for congenital adrenal hyperplasia: adjustment of 17-hydroxyprogesterone cut-off values to both age and birth weight markedly improves the predictive value. J Clin Endocrinol Metab. 2003 Dec;88(12):5790-4.  
11. Varness TS, Allen DB, Hoffman GL. Newborn screening for congenital adrenal hyperplasia has reduced sensitivity in girls. J Pediatr. 2005 Oct;147(4):493-8.  
12. Gatelais F, Berthelot J, Beringue F, Descamps P, Bonneau D, Limal JM, et al. Effect of single and multiple courses of prenatal corticosteroids on 17-hydroxyprogesterone levels: implication for neonatal screening of congenital adrenal hyperplasia. Pediatr Res. 2004 Nov;56(5):701-5.  
13. Speiser PW, White PC. Congenital adrenal hyperplasia. N Engl J Med. 2003 Aug 21;349(8):77688.  
14. New MI, Lorenzen F, Lerner AJ, Kohn B, Oberfield SE, Pollack MS, et al. Genotyping steroid 21hydroxylase deficiency: hormonal reference data. J Clin Endocrinol Metab. 1983 Aug;57(2):320-6. 15. Trikudanathan S, McMahon GT. Optimum management of glucocorticoid-treated patients. Nat Clin Pract Endocrinol Metab. 2008 May;4(5):262-71.  
16. Stewart PM. The Adrenal Cortex. In Williams Textbook of Endocrinology. Philadelphia: Elsevier; 2008.  
17. Metzger DL, Wright NM, Veldhuis JD, Rogol AD, Kerrigan JR. Characterization of pulsatile secretion and clearance of plasma cortisol in premature and term neonates using deconvolution analysis. J Clin Endocrinol Metab. 1993 Aug;77(2):458-63.  
18. Linder BL, Esteban NV, Yergey AL, Winterer JC, Loriaux DL, Cassorla F. Cortisol production rate in childhood and adolescence. J Pediatr. 1990 Dec;117(6):892-6.  
19. Esteban NV, Loughlin T, Yergey AL, Zawadzki JK, Booth JD, Winterer JC, et al. Daily cortisol production rate in man determined by stable isotope dilution/mass spectrometry. J Clin Endocrinol Metab. 1991 Jan;72(1):39-45.  
20. Elnecave RH, Kopacek C, Rigatto M, Keller Brenner J, Sisson de Castro JA. Bone mineral density in girls with classical congenital adrenal hyperplasia due to CYP21 deficiency. J Pediatr Endocrinol Metab. 2008 Dec;21(12):1155-62.  
21. Rasat R, Espiner EA, Abbott GD. Growth patterns and outcomes in congenital adrenal hyperplasia; effect of chronic treatment regimens. N Z Med J. 1995 Aug 11;108(1005):311-4.  
22. Rivkees SA, Crawford JD. Dexamethasone treatment of virilizing congenital adrenal hyperplasia: the ability to achieve normal growth. Pediatrics. 2000 Oct;106(4):767-73.  
23. Kater CE. Hiperplasia Adrenal Congênita - Como Diagnosticar e Tratar. Em Vilar, E. Endocrinologia Clínica. 3° ed. Rio de Janeiro: Guanabara Koogan; 2006.  
24. Punthakee Z, Legault L, Polychronakos C. Prednisolone in the treatment of adrenal insufficiency: a re-evaluation of relative potency. J Pediatr. 2003 Sep;143(3):402-5.  
25. Consensus statement on 21-hydroxylase deficiency from the Lawson Wilkins Pediatric Endocrine Society and the European Society for Paediatric Endocrinology. J Clin Endocrinol Metab. 2002 Sep;87(9):4048-53.  
26. Swerdlow AJ, Higgins CD, Brook CG, Dunger DB, Hindmarsh PC, Price DA, et al. Mortality in patients with congenital adrenal hyperplasia: a cohort study. J Pediatr. 1998 Oct;133(4):516-20.  
27. Eugster EA, Dimeglio LA, Wright JC, Freidenberg GR, Seshadri R, Pescovitz OH. Height outcome in congenital adrenal hyperplasia caused by 21-hydroxylase deficiency: a meta-analysis. J Pediatr. 2001 Jan;138(1):26-32.

---

<!-- METADADOS: doenca: hiperplasia adrenal congênita | secao: FLUDROCORTISONA -->
Eu, _________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contra-indicações e principais efeitos adversos  
relacionados ao uso do medicamento fludrocortisona, indicado para o tratamento da  hiperplasia adrenal congênita.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ________________________________________________________ (nome do médico que prescreve).  
Assim declaro que:  
Fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhorias:  
- Aumento do crescimento;  
- Para a forma perdedora de sal, a fludrocortisona salva a vida.  
Fui também claramente informado a respeito das seguintes contra-indicações, potenciais efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez, portanto, caso  
- engravide, o médico deverá ser avisado imediatamente;  
- pequenas quantidades do medicamento podem passar para o leite materno, portanto o  
- uso da fludrocortisona durante a amamentação não é indicada;  
- os efeitos adversos já relatados são os seguintes: náuseas, vômitos, diarréia, dores de  
- cabeça, nervosismo, desorientação, fraqueza, convulsões, ganho de peso, inchaço, alterações do paladar, aumento da pressão arterial, perda de potássio e insuficiência cardíaca congestiva.(6)  
- medicamento está contra-indicado em casos de hipersensibilidade (alergia) conhecida ao  
fármaco;  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendome a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser atendido, inclusive em caso de eu desistir de usar o medicamento. Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
<!-- Start of picture text -->
Local:                                                                Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Observação: Este Termo é obrigatório ao se solicitar o fornecimento de medicamento do Componente Especializado da Assistência Farmacêutica e deverá ser preenchido em duas vias, ficando uma arquivada na farmácia e a outra entregue ao usuário ou seu responsável legal.

---

