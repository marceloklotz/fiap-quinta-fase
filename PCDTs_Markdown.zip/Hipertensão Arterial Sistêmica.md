<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E DO COMPLEXO ECONÔMICOINDUSTRIAL DA SAÚDE

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: Geral -->
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Hipertensão Arterial  
Sistêmica.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Hipertensão Arterial Sistêmica.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: Geral -->
1

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **INTRODUÇÃO** -->
A Hipertensão Arterial Sistêmica (HAS) é uma doença crônica de causa multifatorial, caracterizada por níveis elevados e sustentados de pressão arterial (PA), geralmente não associada a sintomas<sup>1</sup> . Contudo, frequentemente, a HAS é associada às alterações funcionais ou estruturais de órgãos-alvo (coração, encéfalo, rins e vasos sanguíneos) e a alterações metabólicas, com aumento do risco de eventos cardiovasculares fatais e não fatais<sup>1,2</sup> .  
Além de ser causa direta de cardiopatia e nefropatia hipertensivas, a HAS é fator de risco linear e contínuo para doenças decorrentes de aterosclerose e trombose, que se manifestam, predominantemente, por doença isquêmica cardíaca, cerebrovascular, vascular periférica e renal, assim como de morte prematura<sup>1,3</sup> . Em decorrência de cardiopatia hipertensiva e isquêmica, é também fator etiológico de insuficiência cardíaca e fibrilação atrial<sup>1,3</sup> . Além disso, quando iniciada em fases precoces da vida, a HAS é um fator de risco para o desenvolvimento de Alzheimer e demência vascular<sup>1,3</sup> .  
Dessa forma, a HAS é uma das causas relacionadas à maior redução da expectativa de vida e da qualidade de vida dos indivíduos<sup>1</sup> . Estima-se que o tratamento e o acompanhamento (hospitalizações, procedimentos ambulatoriais e medicamentos) de adultos com HAS representaram um custo de, aproximadamente, R$ 2 bilhões em 2018 para o SUS<sup>3</sup> .  
Além da carga financeira, a HAS é um grave problema de saúde pública no Brasil e no mundo. De acordo com estimativas, entre 1990 e 2019, 1,28 bilhão de pessoas entre 30 anos e 79 anos em todo o mundo apresentavam hipertensão, representando 33% da população nessa faixa etária<sup>1,2</sup> . No Brasil, segundo dados da Pesquisa Nacional de Saúde (PNS) de 2019, 23,9% de indivíduos com 18 anos ou mais de idade relataram diagnóstico para HAS, o que equivale a 38,1 milhões de pessoas<sup>4</sup> . A HAS também é maior entre mulheres (26,4%) do que em homens (21,1%), e aumenta com a idade, tendo sido referida por 56,6% entre as pessoas de 65 anos a 74 anos, e 62,1% entre as pessoas com 75 anos ou mais de idade. Em 2021, foram notificados 39.966 óbitos atribuíveis à HAS no Brasil<sup>5</sup> .  
Os fatores de risco específicos para HAS incluem características genética, idade (quanto maior a idade, maior o risco), sexo masculino, etnia (preta), sobrepeso ou obesidade, hiperglicemia, ingestão elevada de sódio e reduzida de potássio, consumo elevado de bebidas alcoólicas, tabagismo, inatividade física e a apneia obstrutiva do sono<sup>6</sup> . Determinantes sociais como a urbanização, baixa renda familiar anual, baixa escolaridade, residir em bairros desfavorecidos, em área com escassez de profissionais de saúde e as condições de moradia estão envolvidos no desenvolvimento da HAS e doenças cardiovasculares (DCV)<sup>7</sup> . Além disso, alguns medicamentos e drogas ilícitas têm potencial de elevar a PA ou dificultar seu controle, tais como os inibidores da monoaminaoxidase, simpaticomiméticos, como descongestionantes nasais (fenilefrina), antidepressivos tricíclicos (imipramina e outros), hormônios tireoidianos, contraceptivos orais, anti-inflamatórios não esteroides, carbexonolona e liquorice, glicocorticoides, ciclosporina, eritropoietina, drogas ilícitas (cocaína, _Cannabis sativa_ , anfetamina e 3,4-metilenodioximetanfetamina - MDMA, entre outras<sup>6</sup> .  
A Atenção Primária à Saúde (APS) é essencial na prevenção, na identificação dos fatores de risco, no rastreamento e no diagnóstico da doença em seu estágio inicial<sup>4</sup> . Além disso, é responsável pelo controle adequado e pelo acompanhamento integral e longitudinal dos pacientes e, quando necessário, por realizar o encaminhamento adequado e em tempo oportuno para o  
2  
atendimento especializado, objetivando um melhor resultado terapêutico e prognóstico dos casos 1.  
Esse PCDT visa a estabelecer os critérios de rastreamento, diagnósticos, terapêuticos e de acompanhamento dos indivíduos com HAS no âmbito do SUS. Portanto, seu público-alvo inclui indivíduos com suspeita ou diagnóstico da HAS, assim como seus responsáveis, em caso de menores de idade, profissionais da saúde envolvidos no cuidado integral desses indivíduos no âmbito da APS e da Atenção Especializada à Saúde, bem como gestores, com vistas a subsidiar as decisões clínicas e otimizar a qualidade do cuidado ofertado a esses pacientes.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **2. METODOLOGIA** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- I10 - Hipertensão essencial (primária)  
- I15 - Hipertensão secundária  
- O10.0 - Hipertensão essencial pré-existente complicando a gravidez, o parto e o puerpério  
- O10.4 - Hipertensão secundária pré-existente complicando a gravidez, o parto e o puerpério  
- O10.9 - Hipertensão pré-existente não especificada, complicando a gravidez, o parto e o puerpério  
- O13 - Hipertensão gestacional (induzida pela gravidez) sem proteinúria significativa  
- O14 - Hipertensão gestacional (induzida pela gravidez) com proteinúria significativa  
- O16 - Hipertensão materna não especificada

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **4. PREVENÇÃO DE DOENÇAS E PROMOÇÃO DA SAÚDE** -->
Segundo a Organização Mundial de Saúde (OMS), a prevenção primária ou secundária de doenças compreende intervenções específicas, populacionais ou individuais, visando a minimizar a carga de doenças e fatores de risco associados. Já a promoção da saúde é definida como um conjunto de estratégias, tanto individuais quanto coletivas, focando na cooperação intrasetorial e intersetorial e formação da Rede de Atenção à Saúde (RAS), visando a equidade e a qualidade de vida, reduzindo vulnerabilidades e riscos relacionados aos determinantes sociais, econômicos, políticos, culturais e ambientais<sup>8</sup> . Portanto, a prevenção de doenças ou fatores de risco, assim como a promoção da saúde, partilham muitos objetivos, estando diretamente interligadas e podendo ser utilizadas de forma complementar<sup>9</sup> .  
No contexto da HAS, as estratégias de prevenção incluem a adoção de uma alimentação adequada e saudável, com redução do consumo de sódio e de alimentos ultraprocessados; controle do peso corporal; prática regular de atividade física; redução ou cessação da ingestão de bebidas alcoólicas; prevenção e cessação do tabagismo; redução e gerenciamento do estresse; maior  
3  
qualidade do sono; medição regular da PA; gerenciamento de outras condições de saúde; e estratificação do risco cardiovascular (RCV)<sup>6,7</sup> .  
É fundamental a adoção de metodologias dialógicas e participativas que estimulem o autocuidado para o controle da HAS, tendo em vista a literacia para a saúde<sup>10</sup> . Faz-se necessária a identificação e o reconhecimento dos determinantes sociais, como educação, renda e ambiente, de forma a desenvolver e implementar ações de promoção da saúde que sejam culturalmente factíveis, de fácil compreensão e que utilizem os espaços e recursos disponíveis na comunidade. Intervenções associadas à educação que estimulem a compreensão em saúde e aumentem o conhecimento sobre saúde também tendem a melhorar a qualidade de vida, o rastreamento de fatores de risco e o tratamento da HAS<sup>11</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **a. Rastreamento em crianças e adolescentes** -->
O rastreamento da HAS em crianças e adolescentes deve ser realizado a partir dos 3 anos de idade, anualmente. Entretanto, crianças e adolescentes que tenham um ou mais fatores de risco (obesidade, uso crônico de medicamentos que reconhecidamente elevam a PA, doença renal, coarctação de aorta e diabete melito) devem ser rastreados em qualquer consulta clínica. Crianças menores de 3 anos de idade devem ter a PA medida em caso de presença de pelo menos uma das seguintes condições clínicas relacionadas à HAS, a serem avaliadas no momento da anamnese<sup>12</sup> :  
- Restrição de crescimento intrauterino;  
- Crianças prematuras;  
- Muito baixo peso ao nascer;  
- Cardiopatia congênita operada ou não, como coarctação da aorta;  
- História de internação em unidade de terapia intensiva (UTI) neonatal;  
- Antecedente de cateterização umbilical pós-natal;  
- Doença renal crônica (DRC), infecções urinárias de repetição, malformações renais, estenose da artéria renal, hematúria e proteinúria, história familiar de doença renal;  
- Transplante de órgãos sólidos, câncer e transplante de medula óssea;  
- Hipertensão intracraniana;  
- Obstruções da aorta abdominal (neurofibromatose, síndrome de Williams, síndrome de Alagille, arterite de Takayasu);  
- Distúrbios endocrinológicos, excesso de catecolaminas, mineralocorticoides, hiperplasia adrenal congênita, hiperaldosteronismo familiar, hipertireoidismo, tumores (feocromocitoma);  
- Exposição a metais tóxicos, como mercúrio;  
- Doenças sistêmicas que levam à HAS, como esclerose tuberosa;  
- Uso de medicamentos corticoides e anti-inflamatórios não esteroidais;  
- Sobrepeso ou obesidade;  
- História familiar da HAS.  
Deve-se considerar a anamnese, o exame físico, o resultado do índice de massa corporal (IMC) e a medida da PA em consultório clínico. Em crianças de 1 ano a 13 anos de idade, a PA é considerada normal se estiver abaixo do percentil 90 (P90) para idade, altura e sexo, portanto, PA ≥ P90 corresponde a rastreio positivo para HAS (Material Suplementar 1). Em adolescentes a partir de 13 anos de idade, a PA é considerada normal se estiver abaixo de 120 mmHg /80  
4  
mmHg. Portanto, valores de PA ≥ 120 mmHg /80 mmHg correspondem a rastreio positivo para HAS<sup>12</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **b. Rastreamento em adultos** -->
Todas as pessoas com idade igual ou maior a 18 anos, sem diagnóstico da HAS, devem ser rastreadas para esta condição, por meio da medida de PA<sup>13,14</sup> . O rastreamento de adultos, com subsequente diagnóstico e tratamento da HAS, apresenta evidências de redução substancial da incidência de eventos cardiovasculares, com poucos eventos negativos, como possíveis distúrbios do sono, dor ou desconforto, equimoses ou irritação da pele<sup>15</sup> .  
Como a HAS é uma condição geralmente assintomática, seu rastreamento deve ser realizado, anualmente, com duas medidas de PA no consultório<sup>16</sup> . Em caso de PA obtida com resultado menor que 130 mmHg /85 mmHg é recomendado orientar a prevenção primária e realizar nova medida de rastreamento no intervalo de 1 ano. Se PA ≥ 130 mmHg /85 mmHg e < 139 mmHg /89 mmHg, considera-se que o indivíduo possui PA normal alta e deve passar por consulta para identificar a presença de outros fatores de risco para DCV. Na presença de fatores de risco para DCV, a PA deverá ser verificada em mais duas ocasiões, em um intervalo de 7 dias a 14 dias. Na ausência de fatores de risco para DCV, é necessária consulta com profissional de saúde para orientações sobre mudanças dos modos de vida. Para aqueles com idade entre 40 anos e 74 anos, sem DCV pré-estabelecida, deve ser realizada a estratificação do RCV visando à prevenção primária de tais condições. Os indivíduos que apresentarem PA ≥ 140 mmHg /90 mmHg devem seguir os critérios para confirmação diagnóstica (ver item Diagnóstico).

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **6. ESTRATIFICAÇÃO DO RISCO CARDIOVASCULAR** -->
À medida que os valores da PA se elevam, a HAS frequentemente evolui com alterações estruturais e funcionais em órgãos-alvo com consequente aumento do risco de DCV, DRC e morte, independentemente do sexo, idade e grupo étnico. Desse modo, dentre as complicações de lesão em órgão-alvo, há a doença arterial coronariana, insuficiência cardíaca, fibrilação atrial, morte súbita, acidente vascular encefálico (AVE) isquêmico ou hemorrágico, demência, DRC e doença arterial obstrutiva periférica (DAOP)<sup>6,13</sup> . Além disso, a HAS raramente ocorre isolada de outros fatores de RCV, como dislipidemia e diabetes<sup>17</sup> , atuando de maneira sinérgica no efeito aterogênico. Dessa forma, múltiplos fatores apresentam um efeito acumulativo no RCV<sup>6,13</sup> .  
Por este motivo, o RCV deve ser estimado em todos os indivíduos com pressão normal alta ou HAS, sem doença cardiovascular pré-estabelecida. Indivíduos com doença cardiovascular já identificada não necessitam realizar a estratificação do RCV, uma vez que já são considerados com RCV muito alto. A avaliação de fatores de risco modificáveis e do RCV de um indivíduo com HAS, ou seja, a estimativa da probabilidade de ocorrência de um evento cardiovascular em um determinado período, é fundamental para a elaboração da estratégia de cuidado, sendo essencial para o diagnóstico precoce e o tratamento oportuno<sup>6,18</sup> .  
O RCV do indivíduo direcionará as medidas de prevenção e de tratamento que lhe serão recomendadas<sup>6</sup> . Esta avaliação deve ser realizada antes e durante o tratamento medicamentoso da HAS, anualmente. Apesar de sua notada importância, a impossibilidade de realizar a avaliação de RCV não deve impedir que o paciente inicie o tratamento da HAS<sup>19</sup> .  
A estratificação do RCV deve ser realizada com ferramenta validada<sup>6</sup> . A escolha da ferramenta adequada deve considerar os recursos disponíveis, a aceitabilidade, a factibilidade de  
5  
sua aplicação e deve ser avaliada em cada contexto<sup>19</sup> . Apesar de não existir uma ferramenta que considere o cálculo do RCV derivado de estudo da população brasileira, existem diferentes calculadoras de RCV validadas e que podem ser utilizadas para avaliar o RCV do indivíduo com HAS<sup>20</sup> .  
Cabe destacar que, após examinar o desempenho de escores de risco de DCV internacionais utilizados no país, os resultados do Estudo Longitudinal de Saúde do Adulto - ELSA Brasil<sup>20</sup> , o maior estudo de coorte baseado na comunidade brasileira que investiga os fatores determinantes das DCV e do diabetes, apontaram a calculadora da Iniciativa HEARTS/OPAS/OMS como a ferramenta de estratificação do RCV que demonstrou melhor calibração para a população brasileira.  
Atualmente, no Brasil, recomenda-se a avaliação anual do RCV em indivíduos entre 40 anos e 74 anos, independente de já apresentarem HAS ou não, com o uso da calculadora da Iniciativa HEARTS/OPAS/OMS, que utiliza parâmetros definidos a partir do _Global Burden Disease_<sup>21</sup> . Esta ferramenta possibilita a estratificação do RCV conforme gravidade, por meio de critérios laboratoriais e não laboratoriais, sendo seu uso oportuno e de fácil aplicabilidade nos estabelecimentos de saúde<sup>21</sup> .  
Os dados necessários para utilização da referida calculadora consideram a presença ou ausência de DCV, DRC e Diabete Melito tipo 2 (DM2), já estabelecidas. Caso a resposta a cada uma dessas três perguntas seja negativa, deve-se informar se o valor de colesterol no sangue está disponível ou não, pois as informações seguintes dependerão da disponibilidade do seu valor. Se o colesterol total estiver disponível, deve-se informar sexo, idade, tabagismo, diabetes, valor do colesterol total e pressão arterial sistólica (PAS). Caso o valor do colesterol total não esteja disponível, informa-se sexo, idade, tabagismo, pressão sistólica, peso e altura. A partir das informações registradas, a calculadora fornece o resultado da estratificação do risco, de modo que a ausência de dados laboratoriais não é um impeditivo para seu uso<sup>22</sup> . Contudo, para uma confirmação precisa, recomenda-se o cálculo utilizando o valor do colesterol total.  
Para indivíduos com idade até 39 anos e a partir de 75 anos, a avaliação do RCV deve ser realizada a partir de outras calculadoras apropriadas para a faixa etária, devendo-se atentar para as condições indicativas e potencializadoras do RCV, com recomendação para adoção do autocuidado apoiado, alimentação adequada e saudável, prática regular de atividade física, prevenção e cessação do tabagismo e redução do consumo de bebidas alcoólicas<sup>23,24</sup> .  
A calculadora HEARTS permite a estratificação do RCV em baixo, moderado, alto, muito alto e crítico. Ainda, para fins deste Protocolo, os pacientes estratificados com RCV crítico devem seguir as condutas descritas para os pacientes com RCV muito alto.  
Em geral, indivíduos com HAS e lesão em órgão-alvo, lipoproteínas de baixa densidade (LDL) ≥ 190 mg/dL, DRC em estágio ≥ 3 ou diabete melito com idade ≥ 40 anos já são considerados com risco elevado para eventos cardiovasculares e requerem tratamento preventivo com estatinas, conforme PCDT das Dislipidemias vigente. No entanto, considerando a integralidade do cuidado, preconiza-se a estratificação RCV para auxílio na tomada de decisão acerca de outras comorbidades que o indivíduo possa apresentar<sup>25</sup> .  
No indivíduo com HAS, são consideradas as seguintes lesões em órgão-alvo<sup>6,13</sup> :  
- doença cerebrovascular (AVE isquêmico ou hemorrágico, acidente isquêmico transitório);  
- doença arterial coronariana (angina, infarto agudo do miocárdio), isquemia miocárdica silenciosa, cirurgia de revascularização miocárdica, intervenção coronariana prévias);  
6  
- insuficiência cardíaca; fibrilação atrial;  
- doença arterial obstrutiva periférica;  
- aneurismas, hematomas ou ulcerações aórticas;  
- DRC estágio 3, ou seja, taxa de filtração glomerular estimada (TFGe) entre 30 mL/min/1,73 m<sup>2</sup> e 60 mL/min/1,73 m<sup>2</sup> ;  
- albuminúria entre 30 mg/24 horas e 300 mg/24 horas ou relação albumina/creatininúria urinária de 30 a 300 mg;  
- retinopatia hipertensiva (hemorragias, exsudatos ou papiledema).  
Os indivíduos com DM2 com idade até 39 anos devem ser considerados de alto risco caso também apresentem nefropatia ou retinopatia. Nos indivíduos que vivem com DM tipo 1, devese avaliar o RCV de forma individualizada, preferencialmente, em conjunto com o serviço de atenção especializada<sup>25</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **7. DIAGNÓSTICO** -->
É fundamental que o profissional de saúde possa agregar no processo de diagnóstico, tratamento e monitoramento das pessoas com HAS, identificando e reconhecendo marcadores de determinantes sociais como identidade de gênero, orientação sexual, raça, etnia e iniquidades sociais e econômicas, como indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento. Por isso, é imprescindível que o cuidado integral inclua a abordagem aos determinantes sociais, por meio de um acolhimento que ultrapasse o olhar clínico e contextualize histórias de vida, especialmente considerando as vulnerabilidades individuais e coletivas fruto das desigualdades sociais do País<sup>23</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **a. Diagnóstico inicial** -->
A medida da PA no consultório clínico é a base para o diagnóstico precoce e acompanhamento da HAS, sendo fundamental para que o indivíduo receba o tratamento adequado e em tempo oportuno, reduzindo assim o RCV<sup>18,26</sup> .  
A avaliação diagnóstica da HAS deve ser realizada em consulta clínica, com duas a três medidas de PA, com intervalos de 1 dia a 4 semanas<sup>16</sup> . O número de visitas à unidade de saúde e o intervalo de tempo entre elas varia de acordo com a gravidade da HAS, evidência de DCV ou lesão em órgão-alvo.  
Durante este período de avaliação da PA, a avaliação do RCV e testes de triagem de rotina devem ser realizados, conforme a necessidade e especificidade de cada caso. O diagnóstico da HAS por medida de PA no consultório clínico ocorre se os valores da PA permanecerem maior ou igual a 140 mmHg para PAS, ou maior ou igual a 90 mmHg para PAD<sup>17</sup> .  
Suspeita-se da HAS grau 1 nos indivíduos com PA entre 140 mmHg /159 mmHg (PAS) e 90 mmHg /99 mmHg (PAD). Portanto, estes pacientes devem ser submetidos a confirmação diagnóstica, por meio da realização de duas medições da PA, considerando o intervalo de 7 dias a 14 dias entre as medidas. Já os indivíduos que apresentarem PA ≥ 160 mmHg /100 mmHg têm recomendação imediata de consulta médica. O mesmo ocorre se a medida da PA for ≥ 180 mmHg /110 mmHg ou houver evidência de DCV ou lesão em órgão-alvo, situação em que diagnóstico é definido em apenas uma consulta<sup>15</sup> .  
7  
Assim, os indivíduos adultos com diagnóstico confirmado devem ser classificados conforme os diferentes graus da HAS descritos no Quadro 1.  
Quadro 1. Classificação da pressão arterial de adultos, de acordo com a medida em consultório.  
|**PA ótima**|**Normal**|**Graduação da Pr**<br>**Normal alta**|**essão Arterial(mm**<br>**GRAU 1**|**Hg)**<br>**HAS**<br>**GRAU 2**|**GRAU 3**|
|---|---|---|---|---|---|
|PAS < 120|PAS 120-129|PAS ≥ 130, ≤ 139|PAS ≥ 140, ≤ 159|PAS ≥ 160, ≤ 179|PAS ≥ 180|
|PAD < 80|PAD 80-84|PAD ≥ 85, ≤ 89|PAD ≥ 90, ≤ 99|PAD ≥ 100, ≤ 109|PAD ≥ 110|  
**Legenda:** HAS: Hipertensão Arterial Sistêmica; PAD: pressão arterial diastólica; PAS: pressão arterial sistólica.  
**Fonte:** Adaptado de Barroso et al., 2021<sup>6</sup> .  
Quando há confirmação do diagnóstico da HAS, após passar por consulta médica, o indivíduo deve iniciar o tratamento considerando o grau da doença e seu RCV. Deve-se orientálo sobre a periodicidade preconizada para as consultas de retorno e a importância da adesão ao tratamento, das medidas de autocuidado e prevenção de agravos. Caso não seja confirmada a PA ≥ 140 mmHg /90 mmHg, o indivíduo deve passar por consulta com profissional de saúde para orientações sobre mudança dos modos de vida e estratificação do RCV, caso esteja na faixa etária preconizada e se ainda não tiver sido realizada<sup>15</sup> .  
Apesar da medida da PA durante a consulta clínica ser o método de escolha inicial para a confirmação diagnóstica da HAS, há situações em que é necessário avaliar a PA pelo método de monitorização ambulatorial da pressão arterial (MAPA) ou monitorização residencial da pressão arterial (MRPA) (ver item Confirmação diagnóstica por meio da monitorização ambulatorial ou residencial da pressão arterial). As instruções para as medidas de PA por esses três métodos indiretos usuais e validados são descritas no Material Suplementar 2.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: i. **Circunstâncias específicas** -->
Ao diagnóstico, é importante identificar circunstâncias que podem interferir na conduta terapêutica. No contexto das variações de PA entre consultório e domicílio, reconhece-se a importância da hipertensão do avental branco e hipertensão mascarada. A identificação dessas circunstâncias impactará na definição de tratamento: no caso da HAS secundária, deve considerar as causas de base, e; no caso de hipertensão arterial resistente e refratária, esquemas mais complexos após confirmação de adesão terapêutica adequada.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **ii. Hipertensão do avental branco e hipertensão mascarada** -->
Cerca de 10% a 30% dos indivíduos que apresentam PA elevada em consultório clínico têm hipertensão do avental branco, ou seja, PA elevada apenas no consultório clínico enquanto a PA ambulatorial ou residencial está dentro dos limites da normalidade. Ainda, entre 10% e 15% têm hipertensão mascarada, que é quando a PA se apresenta dentro dos limites da normalidade quando medida no consultório clínico, mas elevada em avaliação ambulatorial ou residencial<sup>26</sup> .  
Indivíduos com hipertensão do avental branco apresentam RCV moderado comparado a indivíduos com PA normal e indivíduos com HAS, muito embora isso não altere o diagnóstico de  
8  
normotenso ou hipertenso, enquanto pacientes com hipertensão mascarada apresentam risco semelhante de eventos cardiovasculares em relação aos indivíduos com HAS sustentada<sup>26</sup> .  
Indivíduos com possível hipertensão do avental branco podem não ter tratamento medicamentoso prescrito se o RCV total for baixo e não houver lesão de órgão-alvo associada à hipertensão. No entanto, os pacientes devem ser orientados quanto à adoção de modos de vida saudáveis, pois, podem desenvolver HAS e necessitar tratamento medicamentoso. Indivíduos com possível hipertensão mascarada podem receber tratamento com o objetivo de normalizar a PA fora do consultório<sup>26</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iii. Hipertensão arterial secundária** -->
A hipertensão arterial secundária, em contraposição à hipertensão arterial primária, ocorre devido a uma causa identificável e que pode ser tratada com uma intervenção específica, a qual determina a remissão ou melhora do controle pressórico<sup>6</sup> . Estima-se que entre 5% e 10% dos pacientes com HAS podem ter hipertensão secundária, o que indica presença de uma causa subjacente e potencialmente reversível<sup>27</sup> . Deve-se suspeitar de hipertensão arterial secundária caso o paciente apresente algumas das características descritas no Quadro 2.  
Quadro 2. Características para suspeita de hipertensão arterial secundária.  
|**Indícios**|**Características**|
|---|---|
|HAS de início precoce e<br>tardio|Presença de lesões em órgãos-alvo e diagnóstico antes dos 30<br>anos ou após os 50 anos de idade.|
|Hipertensão<br>arterial<br>resistente<br>(HAR)<br>ou<br>refratária|HAR: PA que permanece ≥140/90 mmHg, apesar do uso de três<br>ou mais classes de medicamentos anti-hipertensivos em doses<br>máximas; ou<br>HAR controlada: PA < 140/90 mmHg, em uso de quatro ou mais<br>medicamentos anti-hipertensivos para alançar o controle da PA;<br>ou<br>Refratária: PA não controlada ≥140/90 mmHg, mesmo em uso de<br>cinco ou mais medicamentos anti-hipertensivos.|
|Uso de substâncias|Uso de hormônios exógenos, medicamentos ou outras substâncias<br>quepossam elevar apressão arterial.|
|Tríade<br>do<br>feocromocitoma|Presença de crises de palpitações, sudorese e cefaleia.|
|Indícios<br>de<br>apneia<br>obstrutiva do sono|Presença de sintomas ou diagnóstico confirmado.|
|Características físicas ou<br>condições associadas a<br>HAS|Fácies típica ou biótipo de doenças como hipertireoidismo,<br>Síndrome de Cushing, acromegalia, doença renal crônica.|
|Presença de sinais físicos|Presença de sopros em territórios arteriais ou massas abdominais.|
|Assimetria ou ausência de<br>pulsos|Pulsos assimétricos ou ausentes em membros inferiores.|
|Hipopotassemia|Espontânea ou severa,induzidapor diuréticos.|
|Anormalidade em exames<br>de urina e função renal|Presença de hematúria glomerular (dismórfica), de albuminúria<br>ou proteinúria, diminuição do TFGe, aumento de creatinina sérica<br>ou alterações de imagem renal.|  
**Legenda:** TFGe: taxa de filtração glomerular estimado; HAS: hipertensão arterial sistêmica, HAR: hipertensão arterial resistente, PA: Pressão Arterial **Fonte:** Barroso et al. 2021<sup>6</sup> .  
9  
A realização da anamnese, exame físico adequado (incluindo medida correta da PA e palpação de pulsos em membros superiores e inferiores), além dos exames de rotina para o paciente com HAS, pode auxiliar na identificação de potenciais causas secundárias (ver item Avaliação clínica e avaliação de lesão orgânica mediada por hipertensão)<sup>6</sup> . Os achados clínicos, a potencial causa da HAS e as sugestões de investigação diagnóstica para hipertensão arterial secundária estão descritos no Quadro 3.  
Quadro 3. Principais causas não endócrinas e endócrinas de hipertensão arterial secundária, conforme achados clínicos e exames adicionais, e suspeita diagnóstica.  
|**Achados clínicos**|**Suspeita Diagnóstica**|**Exames adicionais**|
|---|---|---|
|**Causas Não Endócrinas**|||
|Edema, anemia, anorexia, fadiga,<br>níveis elevados de creatinina e<br>ureia, alterações do sedimento<br>urinário ou nos exames de<br>imagem<br>HAS de aparecimento súbito ou<br>com piora sem causa aparente<br>antes dos 30 anos ou após 50<br>anos de idade, HAR, refratária,<br>presença de sopro abdominal,<br>edema agudos dos pulmões,<br>alteração<br>da<br>função<br>renal<br>inexplicável<br>ou<br>devido<br>a<br>medicamentos que bloqueiam o<br>sistema<br>renina<br>angiotensina,<br>assimetria entre o tamanho dos<br>rins maior que 1,5 cm.|Doença<br>renal<br>parenquimatosa<br>Estenose de artéria renal|Cálculo da TFGe (a partir da<br>medida da creatinina sérica),<br>ultrassom renal, pesquisa de<br>albuminúria,<br>proteinúria,<br>hematúria dismórfica<br>Usualmente a realização de um<br>ultrassom com Doppler renal<br>com medida de velocidade de<br>fluxo e índice de resistividade<br>(rastreio,<br>mas<br>observador<br>dependente) ou cintilografia<br>renal<br>com<br>captopril,<br>angiografia por ressonância ou<br>tomografia<br>auxiliam<br>na<br>investigação.<br>Se disponível, a arteriografia<br>renal convencional (exame de<br>escolha) é indicada nos casos<br>suspeitos com potencial de<br>tratamento<br>no<br>mesmo<br>procedimento.|
|||Questionários<br>apresentam<br>baixa a moderada acurácia para|
|Pós-menopausa,<br>ronco<br>na<br>maioria das noites, fragmentação<br>do sono com pausas ou engasgos,<br>sonolência<br>excessiva<br>diurna,<br>sono não reparador, fadiga,<br>noctúria,<br>cefaleia<br>matinal,<br>presença<br>de<br>obesidade<br>ou<br>síndrome metabólica.|Apneia Obstrutiva do<br>Sono (AOS)|triagem. Exames objetivos:<br>polissonografia em ambiente<br>hospitalar ou domiciliar com<br>monitor portátil.<br>IAH < 5 eventos/h: sem AOS;<br>IAH 5-14,9 eventos/h: AOS<br>leve; IAH 15-29,9 eventos/h:<br>AOS moderada; IAH ≥ 30<br>eventos/h: AOS importante ou<br>grave.|
|Pulsos em membros inferiores<br>ausentes<br>ou<br>de<br>amplitude<br>diminuída, PAS 10 mmHg maior<br>em membros superiores em<br>relação aos membros inferiores,<br>sopro sistólico interescapular e<br>no tórax.|Coarctação de aorta|Radiografia<br>de<br>Tórax,<br>Ecocardiograma para rastreio.<br>TC<br>ou,<br>preferencialmente,<br>RNM<br>aorta.<br>Angiografia<br>invasiva,<br>apenas<br>quando<br>necessários dados adicionais|  
10  
|**Achados clínicos**|**Suspeita Diagnóstica**|**Exames adicionais**|
|---|---|---|
|**Causas Endócrinas**|||
|Hipertensão Arterial resistente<br>ou<br>refratária<br>ou<br>com<br>hipopotassemia (não obrigatória)<br>ou com nódulo adrenal, se exame<br>de imagem disponível|Hiperaldosteronismo<br>primário (hiperplasia ou<br>adenoma)|Determinações de aldosterona<br>(> 15 ng/dL) e concentração de<br>renina plasmática ou atividade<br>plasmática de renina (por<br>exemplo, APR, concentração<br>de renina em µUI/ml vezes 12);<br>relação aldosterona/APR > 30.<br>Testes<br>confirmatórios<br>são<br>indicados quando a relação está<br>entre 30 e 100.<br>Exames de imagem: TC com<br>cortes finos ou RNM. Coleta<br>seletiva<br>de<br>aldosterona<br>e<br>cortisol em veias adrenais, para<br>identificar<br>subtipo,<br>quando<br>indicado|
|HAS paroxística com a tríade<br>composta por cefaleia, sudorese<br>epalpitações|Feocromocitoma<br>e<br>Paragangliomas|Cintilografia, TC e RNM.|
|Fadiga, ganho de peso corporal,<br>perda de cabelo, HAS diastólica,<br>fraqueza muscular,sonolência<br>̂|Hipotireoidismo<br>̂|TSH e T4 livre|
|Intolerância ao calor, redução|̂||
|̂<br>do peso corporal, palpitações,<br>exoftalmia, hipertermia, reflexos<br>exaltados,<br>tremores,<br>bócio,<br>|̂<br>Hipertireoidismo|TSH e T4 livre|
|taquicardia|||
|Litíase urinária, osteoporose,<br>depressão, letargia, fraqueza ou<br>espasmos<br>musculares,<br>sede,<br>poliúria, polidpsia,constipação|Hiperparatireoidismo<br>(hiperplasia<br>ou<br>adenoma)|Cálcio total ou ionizável,<br>fósforo, PTH, calciúria de 24<br>horas e dosagem de vitamina<br>D.|
|Ganho<br>de<br>peso<br>corporal,<br>diminuição da libido, fadiga,<br>hirsutismo, amenorreia, “faces<br>em lua cheia”, “giba dorsal”,<br>estrias<br>purpúreas,<br>obesidade<br>central, hipopotassemia|Síndrome de Cushing<br>(hiperplasia, adenoma e<br>excesso de produção de<br>ACTH)|Dosagem de cortisol e teste de<br>supressão do cortisol após<br>dexametasona<br>(tomar<br>dexametasona 1 mg às 23 horas<br>ou meia-noite e dosar cortisol<br>entre 7h e 8h do dia seguinte).<br>TC,RNM|
|Aumento da gordura central ou<br>generalizada|Obesidade<br>Grau 1:<br>IMC de 30 a < 35 kg/m<sup>2</sup><br>Grau 2:<br>IMC de 35 a < 40 kg/m<sup>2</sup><br>Grau 3:<br>IMC≥40 kg/m<sup>2</sup>|IMC<br>e<br>circunferência<br>abdominal (> 102 cm homem e<br>88 cm mulher)|
|HAS em até 30% dos casos, além||Dosagem de IGF-1, nível|
|de<br>diabetes,<br>hipertrofia<br>ventricular esquerda e AOS.<br>Outros<br>sintomas:<br>defeitos<br>visuais, paralisia de nervos<br>cranianos, cefaleia, macrognatia,<br>crescimento depés e mãos,|Acromegalia|sérico<br>de<br>GH,<br>teste<br>de<br>supressão<br>do<br>HGH<br>pós<br>sobrecarga oral de glicose.<br>Localização: RNM de sela<br>túrcica (preferencial) ou TC de<br>sela túrcica.|  
11  
|**Achados clínicos**|**Suspeita Diagnóstica**|**Exames adicionais**|
|---|---|---|
|hipertrofia de tecidos moles,|||
|macroglossia,<br>complicações<br>musculoesqueléticas.|||  
**Legenda:** ACTH: adrenocorticotropina; AOS: Apneia Obstrutiva do Sono; APR: atividade plasmática de renina; TFGe: taxa de filtração glomerular estimada; GH: hormônio do crescimento; HAS: hipertensão arterial sistêmica; HGH; hormônio do crescimento humano; <mark>IAH: índice de apneia e h</mark> ipopneia; IGF-1: fator de crescimento insulina-símile tipo 1; IMC: índice de massa corporal; PAS: pressão arterial sistólica; PTH: paratormônio; RNM: ressonância nuclear magnética; T4: tiroxina;  TC: tomografia computadorizada; TSH: hormônio tireoestimulante. **Fonte:** Barroso et al. 2021<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iv. Hipertensão arterial resistente e refratária** -->
A hipertensão arterial resistente (HAR) é uma condição clínica definida quando a PA permanece acima das metas recomendadas (em adultos PAS ≥ 140 mmHg ou PAD ≥ 90 mmHg) 6,26,28–30 após seis meses de tratamento intensivo adequado 31. Esse tratamento inclui o uso de três anti-hipertensivos de diferentes classes, em doses máximas preconizadas e toleradas, administrados com frequência apropriada e com boa adesão terapêutica<sup>6,26,28–30</sup> . Esses medicamentos, incluem um bloqueador do sistema renina-angiotensina (inibidor da enzima conversora da angiotensina [IECA] ou bloqueador do receptor de angiotensina [BRA]), um bloqueador dos canais de cálcio (BCC) de ação prolongada e um diurético tiazídico (DT) de longa ação<sup>6,26,28–30</sup> .  
Quando o paciente necessita do uso de quatro ou mais medicamentos anti-hipertensivos para alcançar o controle da PA, considera-se que ele apresenta HAR controlada se a PA estiver menor que 140 mmHg /90 mmHg<sup>6</sup> .  
Estima-se que entre 10% e 20% dos pacientes com hipertensão apresentem HAR<sup>32</sup> . O aumento da expectativa de vida e a maior prevalência de obesidade na população, entre outras condições associadas à HAR, têm se tornado cada vez mais comuns<sup>6,32</sup> . A HAR está associada a maior lesão de órgãos-alvo mediada pela HAS, maior ocorrência de desfechos cardiovasculares negativos e maior frequência de causas secundárias determinantes da HAS<sup>6</sup> .  
A hipertensão arterial refratária é um espectro extremo da HAR, em que não há controle da PA a despeito do uso regular e otimizado de medicamentos anti-hipertensivos de cinco classes terapêuticas distintas<sup>6</sup> .  
Contudo, o paciente pode utilizar os medicamentos em doses não otimizadas ou apresentar baixa adesão ao tratamento da HAS, fazendo com que seja encaminhado à Atenção Especializada, por falsa suspeita de HAR. Desta forma, adequar a prescrição medicamentosa e adotar estratégias para aumentar a adesão ao tratamento podem melhorar o controle pressórico<sup>33</sup> . Diante de suspeita de HAR, devem ser adotados os cuidados diagnósticos descritos no Quadro 4.  
Quadro 4. Cuidados para o diagnóstico da hipertensão arterial resistente.  
|Verificar a adesão ao tratamento medicamentoso, uma das causas mais comuns de pseudo<br>resistência.|
|---|
|Otimizar o tratamento não medicamentoso e medicamentoso antes de diagnosticar o paciente<br>com hipertensão arterial resistente.|
|Medir corretamente a pressão arterial, usando técnica e manguito apropriado ao tamanho da<br>circunferência de braço dopaciente.|  
12  
Medir a PA de forma padronizada, fora do ambiente do consultório clínico, para descartar o efeito do “jaleco ou avental branco”.  
**Fonte:** Barroso et al. 2021<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **v. Confirmação diagnóstica por meio da monitorização ambulatorial ou residencial da pressão arterial** -->
A MAPA é o método que permite o registro contínuo da PA, geralmente durante 24 horas, medidos durante as atividades diárias e também nos períodos de vigília e sono. A Diretriz Europeia de Hipertensão relata que, entre as técnicas comumente usadas, a MAPA é melhor preditora de danos em órgãos-alvo quando comparada a PA de consultório e prognóstico da doença<sup>30</sup> . Além disso, a MAPA permite identificar a hipertensão do avental branco e a hipertensão mascarada, melhorando a precisão diagnóstica da hipertensão primária<sup>18,26,30</sup> .  
A MRPA, incorporada ao SUS por meio da Portaria SECTICS/MS nº 22, de 10 de maio de 2023, consiste em um método de medição residencial da PA<sup>34</sup> . A MRPA resulta em um valor médio de uma série de medidas realizadas em domicílio durante cinco dias consecutivos, duas vezes ao dia, uma pela manhã e uma à noite<sup>15</sup> .  
Recomenda-se que a confirmação diagnóstica seja realizada com MAPA ou, quando indisponível, com MRPA, em uma das seguintes situações<sup>6</sup> :  
- Suspeita de hipertensão do avental branco, particularmente, nas seguintes situações:  
- HAS grau 1 avaliada em consultório clínico;  
- Elevação significativa da PA no consultório, sem lesão de órgão-alvo e com  
- baixo RCV total.  
- Suspeita de hipertensão mascarada:  
- PA entre 130 mmHg /85 mmHg e 139 mmHg /89 mmHg em consultório clínico;  
- PA menor que 140 mmHg /90 mmHg em consultório clínico, em indivíduos assintomáticos com lesão de órgão-alvo ou com alto RCV total.  
- Confirmação diagnóstica de HAR;  
- Resposta exacerbada da PA à atividade física e ao exercício físico;  
- Presença de grande variabilidade da PA no consultório.  
A medida da PA no consultório clínico, associada à medida residencial ou ambulatorial, quando indicada, permite identificar essas situações e evitar que os indivíduos deixem de receber tratamento ou sejam tratados inadequadamente para HAS<sup>16</sup> .  
Além disso, recomenda-se que a confirmação diagnóstica seja realizada especificamente com o MAPA, quando<sup>6</sup> :  
- há discordância importante entre os valores da PA avaliada em consultório clínico e residencial;  
- há necessidade de avaliação da PA durante o sono e descenso do sono; e  
- há necessidade de avaliar a existência de hipotensão postural e pós-prandial.  
Por envolver múltiplas medidas automatizadas da PA e sem supervisão de profissionais de saúde, o MAPA ou o MRPA fornecem uma avaliação mais padronizada da PA, demonstrando valores de PA usualmente menores do que os obtidos em consultório clínico<sup>6</sup> . Nesses casos, o diagnóstico da HAS é confirmado quando os valores de PA atingem os seguintes limiares: **MAPA** média de 24 horas ≥ 130 mmHg/80 mmHg, média durante o dia (em vigília) ≥ 135 mmHg/85  
13  
mmHg, ou média noturna (durante o sono) ≥ 120 mmHg/70 mmHg; e **MRPA** média dos valores observados ≥ 130 mmHg/80 mmHg<sup>6</sup> . Ressalta-se que esses pontos de corte são específicos para MAPA/MRPA, e diferem dos critérios utilizados para aferição da PA em consultório, nos quais valores entre 130 mmHg e 139 mmHg (PAS) e entre 85 mmHg e 89 mmHg (PAD) são classificados como PA normal alta, conforme mencionado na seção Rastreamento.  
O Quadro 5 apresenta as vantagens e desvantagens da MAPA e da MRPA, em comparação à medida da PA em consultório clínico.  
Quadro 5. Vantagens e desvantagens da avaliação da pressão arterial fora do consultório clínico.  
|**Considerações**||**Método**|
|---|---|---|
||**MAPA**|**MRPA**|
||Leituras durante o sono|Maior disponibilidade|
||<br> <br>|Medida da PA em ambiente domiciliar,<br> <br> <br>|
||Permite<br>medidas<br>durante<br>atividades cotidianas|que<br>pode<br>representar<br>maior<br>tranquilidade para o paciente do que o<br>ambiente do consultório clínico.|
|Vantagens|Utilizado em pacientes com<br>déficits cognitivos e nos raros<br>casos<br>de<br>comportamento<br>obsessivo|Permite avaliar a variabilidade da PA<br>no dia a dia|
||Permite avaliar a variabilidade<br>da PA emperíodos curtos|Envolvimento do paciente na medida<br>da PA|
||Evidência<br>prognóstica<br>mais<br>robusta|Maior adesão ao tratamento|
||Custo elevado|Somente PA em vigília|
|Desvantagens|Disponibilidade,<br>por<br>vezes,<br>limitada|Potencial de erro nos resultados|
||Pode ser desconfortável|Medida apenas em repouso|  
**Legenda:** MAPA: monitorização ambulatorial da pressão arterial; MRPA: monitorização residencial da pressão arterial; PA: pressão arterial. **Fonte:** Barroso et al. (2021)<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **i. Histórico clínico** -->
Pacientes com HAS são frequentemente assintomáticos. O surgimento de sintomas específicos pode sugerir hipertensão arterial secundária ou complicações hipertensivas, que requerem investigação adicional. Históricos clínicos e familiares completos são recomendados e devem incluir<sup>26</sup> :  
1. Identificação pessoal: dados socioeconômicos, ocupação, escolaridade, atividades realizadas em lazer, rede de apoio, potencial para desenvolvimento de autocuidado, entre outros.  
2. Histórico pessoal relacionado à HAS: período de início recente, valor de PA usual, antes do diagnóstico da HAS, uso atual ou anterior de medicamentos antihipertensivos, uso de medicamentos com potencial de influenciar a PA, histórico de intolerância ou eventos adversos relacionados a medicamentos anti-  
14  
hipertensivos, adesão ao tratamento anti-hipertensivo, hipertensão prévia relacionada ao uso de contraceptivos orais ou a gravidez.  
3. Fatores de risco: histórico pessoal de DCV (como infarto agudo do miocárdio, insuficiência cardíaca, AVE, ataques isquêmicos transitórios, entre outros), diabete melito, dislipidemia, hipercolesterolemia familiar, DRC, tabagismo, alimentação inadequada, ingestão de bebidas alcóolicas, inatividade física, aspectos psicossociais prejudiciais, histórico de depressão, histórico familiar da HAS ou DCV.  
4. Avaliação do RCV geral, conforme estratificação de risco proposta pela calculadora da iniciativa HEARTS<sup>14</sup> (ver item Estratificação do risco cardiovascular) para indivíduos de 40 anos a 74 anos de idade; ou, se fora desta faixa etária, utilizar calculadoras apropriadas.  
5. Sintomas ou sinais da HAS e doenças coexistentes: dor torácica, falta de ar, palpitações, claudicação, edema periférico, dores de cabeça, visão turva, noctúria, hematúria, tontura.  
6. Sintomas sugestivos de hipertensão arterial secundária: fraqueza muscular ou tetania, cãibras, arritmias (hipocalemia, aldosteronismo primário), edema pulmonar instantâneo (estenose da artéria renal), sudorese, palpitações, dores de cabeça frequentes (feocromocitoma), ronco, sonolência diurna (apneia obstrutiva do sono), sintomas sugestivos de doença da tireoide.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **ii. Exame físico** -->
O exame físico deve ser minucioso, buscando sinais sugestivos de lesões de órgãos-alvo e de hipertensão secundária. O exame de fundo de olho deve ser sempre feito ou solicitado na primeira avaliação, em especial em pacientes com HAS grau 3, que apresentam diabetes ou lesão em órgãos-alvo.  
As avaliações abrangentes a serem realizadas durante o exame clínico estão descritas no Quadro 6 e devem ser adaptadas de acordo com a gravidade da HAS, existência de DCV prematura e as circunstâncias clínicas<sup>30</sup> .  
Quadro 6. Avaliações ao exame clínico.  
**<mark>Medidas corporais</mark>** Peso (medido em balança calibrada) e altura Cálculo do índice de massa corporal Circunferência abdominal Frequência cardíaca **<mark>Sinais de lesão de órgão-alvo associada à hipertensão</mark>** Ausculta pulmonar Exame neurológico e estado cognitivo Exame fundoscópico para retinopatia hipertensiva Palpação e ausculta do coração e artérias carótidas Palpação de artérias periféricas Comparação dos valores de pressão arterial em ambos os braços, medidos pelo menos uma vez, em cada um dos braços Realização do Índice Tornozelo- Braquial (ITB)<sup>a</sup> **<mark>Hipertensão arterial secundária</mark>** Inspeção da pele: manchas café com leite de neurofibromatose (feocromocitoma) Palpação do rim para identificar sinais de aumento renal na doença renal policística  
15  
Ausculta do coração e artérias renais para verificar a existência de sopros ou sopros indicativos de coarctação da aorta  
Auscultar e palpar o abdômen para verificar a presença de frêmitos, sopros, massas abdominais indicativas de rins policísticos e tumores Comparação do pulso radial com o femoral Sinais de doença de _Cushing_ ou acromegalia Avaliar sinais de doença da tireoide e realizar palpação da mesma  
**Fonte:** Traduzido e adaptado de _European Society of Hypertension_ (ESH) _Guidelines_ – Mancia et al. (2023)<sup>30</sup> ., e Barroso et al. (2021)<sup>6</sup> . **Nota:**<sup>a</sup> O ITB é a razão entre a pressão sistólica no tornozelo e no braço. É considerado um marcador de rigidez arterial em pacientes sem doença arterial periférica.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iii. Investigações laboratoriais e eletrocardiograma** -->
A avaliação laboratorial visa a detectar lesões em órgão-alvo, proporcionando uma estratificação mais precisa do RCV e para o diagnóstico preciso da HAS. Esta avaliação inclui as seguintes investigações a serem realizadas, conforme o caso clínico de cada indivíduo<sup>6</sup> :  
- Exames de sangue: sódio, potássio, ácido úrico, albuminúria, creatinina sérica, TFGe, perfil lipídico e glicemia de jejum<sup>16</sup> .  
- Análise de urina: teste de urina de vareta.  
- Eletrocardiograma de 12 derivações: detecção de fibrilação atrial, hipertrofia ventricular esquerda, cardiopatia isquêmica.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **c. Testes diagnósticos adicionais** -->
Investigações adicionais, quando indicadas, podem ser realizadas para avaliar e confirmar a suspeita de doenças coexistentes ou hipertensão arterial secundária<sup>26,30</sup> . Possíveis testes diagnósticos adicionais e suas respectivas indicações estão descritos no Quadro 7.  
Quadro 7. Testes diagnósticos adicionais e suas indicações.  
**<u><mark>1.Técnicas de imagem</mark></u>** 1.1. Exames adicionais para casos específicos: Ecocardiografia: hipertrofia ventricular esquerda, disfunção sistólica ou diastólica, dilatação atrial, coarctação da aorta. Ultrassonografia carotídea: placas (aterosclerose), estenose. Ultrassonografia renal com Doppler. 1.2. Exames de investigação clínica complementar de acordo com lesões em órgão-alvo das emergências hipertensivas: Angiografia por tomografia computadorizada/ressonância magnética: doença do parênquima renal, estenose da artéria renal, lesões adrenais, outra patologia abdominal. Tomografia computadorizada/ressonância magnética do cérebro: lesão cerebral isquêmica ou hemorrágica devido à hipertensão. **<mark>2. Testes funcionais</mark>** **<u><mark>e investigações laboratoriais adicionais</mark></u>** Índice tornozelo-braquial: doença arterial periférica (extremidade inferior). Testes adicionais para hipertensão arterial secundária, se houver suspeita: relação aldosteronarenina ou outros testes de triagem para excesso de cortisol. Relação albumina/creatinina urinária. Testes de função hepática, especialmente dosagem de enzimas hepáticas (Transaminase Glutâmica Oxalacética, Transaminase Glutâmica Pirúvica, Gama Glutamil Transferase, fosfatase alcalina).  
16  
**Fonte:** Barroso et al. (2021), Mancia et al. (2023) e Unger et al. (2020)<sup>6,26,30</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **d. Crise hipertensiva** -->
Crises hipertensivas são consideradas as grandes elevações pressóricas, arbitrariamente definidas como PAS maior ou igual a 180 mmHg ou pressão arterial diastólica maior ou igual a 120 mmHg<sup>6,17</sup> . Essas crises hipertensivas podem ser classificadas como emergência ou urgência hipertensiva<sup>6,28,35</sup> . Entretanto, deve-se observar se a técnica correta de medida da PA foi realizada (Material Suplementar 2), para evitar o diagnóstico de uma “falsa crise hipertensiva”<sup>6,17</sup> .  
As expressões “urgência” e “emergência” hipertensivas foram propostas em 1993 pelo V _Joint National Committee on Detection Evaluation and Treatment of High Blood Pressure_<sup>6</sup> . Os termos ‘hipertensão acelerada’ e ‘hipertensão maligna’ têm sido intercambiáveis<sup>6</sup> e, geralmente, associados às emergências hipertensivas. A emergência hipertensiva é a crise hipertensiva com lesão em órgão-alvo aguda ou em progressão, usualmente com risco de vida<sup>6,26,28,30,35</sup> . Pode ocorrer em pacientes com ou sem diagnóstico prévio da HAS e com um limiar pressórico menor que o arbitrariamente definido para crise hipertensiva. Entretanto, emergências hipertensivas são relativamente incomuns, sendo responsáveis por menos de 1% das consultas em emergências. As urgências hipertensivas (UH) são definidas por situações clínicas sintomáticas em que há a elevação acentuada da pressão arterial com valores da PAS igual ou superior a 180 mmHg ou PAD igual ou superior a 120 mmHg sem lesão aguda e progressiva de órgãos alvo e sem risco iminente de morte. As urgências hipertensivas ocorrem mais frequentemente entre pacientes com HAS inadequadamente tratada, de difícil controle ou sem adesão ao tratamento medicamentoso, ou não medicamentoso<sup>6,35</sup> . A maioria dos pacientes que têm urgências hipertensivas são assintomáticos, mas alguns podem referir algum sintoma no momento da medição aferição da PA, que não necessariamente é a causa ou a consequência de seu aumento<sup>36,4</sup> . Sintomas comumente associados a urgências hipertensivas são: cefaleia, dispneia, epistaxe, palpitação e ansiedade<sup>6,17</sup> .  
As urgências hipertensivas podem ser subclassificadas em “falsas” ou “pseudocrises hipertensivas”, se a crise hipertensiva ocorrer sem evidência de lesão em órgão-alvo, em algum dos seguintes casos: indivíduos assintomáticos ou oligossintomáticos; em decorrência de ansiedade, dor, evento emocional doloroso ou a algum desconforto (por exemplo, retenção urinária); hipertensão do avental branco; ou devido a erros na técnica de medida da PA<sup>6</sup> .  
Já as emergências hipertensivas (EH) são definidas por situações clínicas sintomáticas em que há a elevação acentuada da PA com valores da PAS igual ou superior a 180 mmHg ou PAD igual ou superior a 120 mmHg com lesão aguda e progressiva de órgãos alvo e sem risco iminente de morte.  
As manifestações clínicas da emergência hipertensiva correspondem às da respectiva condição clínica associada<sup>13,26</sup> . As manifestações mais comuns são cerebrais, como o AVE isquêmico (39% a 40%) ou hemorrágico, encefalopatia hipertensiva – letargia, convulsões, amaurose cortical e coma sem outra etiologia<sup>26</sup> ; cardíacas, como síndromes coronarianas agudas, insuficiência cardíaca aguda com edema agudo de pulmão (25% a 32%); além de manifestações renais e oculares. Menos frequentes, ocorrem a dissecção aguda de aorta (2%) e emergências hipertensivas da gestação (2%) – pré-eclâmpsia grave, eclâmpsia e síndrome HELLP<sup>6,26</sup> .  
A emergência hipertensiva pode também ocorrer por hiperatividade simpática, devido ao feocromocitoma, uso de _crack_ , cocaína ou derivados anfetamínicos, como o _ecstasy_ , ou por interrupção do uso de clonidina ou betabloqueadores; por uso de anti-inflamatórios não esteroidais, esteroides ou imunossupressores<sup>13,26,35</sup> , ou por envolvimento de múltiplos órgãos,  
17  
com acometimento de pelo menos três sistemas, entre os quais cardíaco, neurológico, renal e hematológico<sup>6,13,26</sup> .  
A avaliação dos pacientes com emergências hipertensivas deve considerar o início e duração dos sintomas, potenciais condições precipitantes e comorbidades preexistentes<sup>6,17,36</sup> . Devem ser investigados especialmente os fatores associados às causas mais frequentes de emergências hipertensivas: cefaleia, história de traumatismo craniano, náuseas, vômitos, dor torácica, dispneia, gestação diagnosticada ou possível, uso de medicamentos (anti-inflamatório não esteroidal, esteroides, imunossupressores) ou substâncias simpaticomiméticas (como _crack_ , cocaína ou derivados anfetamínicos) e interrupção recente de tratamento anti-hipertensivo, especialmente com clonidina ou betabloqueadores<sup>6,26,30</sup> .  
Pacientes com emergência hipertensiva devem realizar exame físico completo, com ênfase nas seguintes avaliações<sup>6,26,30</sup> :  
- cardíaca: para taquicardia e arritmias;  
- pulmonar: para edema pulmonar e derrame pleural;  
- pulsos centrais e turgência jugular;  
- neurológica: incluindo estado mental, fundoscopia, força, presença de disartria, rigidez de nuca ou déficits focais;  
- exame abdominal: para aneurisma de aorta abdominal, sopros sugestivos de estenose de artéria renal e sinais de obstrução vesical; e  
- exame de extremidades: para pulsos periféricos e edema.  
Todos os pacientes com emergência hipertensiva devem realizar dosagem de hemoglobina sérica, contagem de plaquetas, dosagens de sódio, potássio e creatinina, com TFGe, e eletrocardiograma. Também deve ser realizada urinálise para avaliar proteinúria, hematúria e cilindros e a relação albuminúria/creatinúria<sup>26,30</sup> . Conforme as manifestações e suspeitas clínicas, pode ser avaliada a saturação de oxigênio, além dos níveis de lactato-desidrogenase, fibrinogênio, haptoglobina, troponina, dor torácica e exame toxicológico (intoxicação por substâncias ilícitas). Para pacientes que possuem insuficiência cardíaca, a avaliação da porção N-terminal do próhormônio do peptídeo natriurético do tipo B (NT-proBNP) também é recomendada. Mulheres em idade fértil devem realizar teste de gravidez. Exames de imagem também podem ser necessários, para auxiliar no diagnóstico de doenças, conforme o Quadro 8.  
Quadro 8. Avaliação de imagem diagnóstica para pacientes com suspeita de emergência hipertensiva.  
|**Exame de imagem **|**Condições de saúde/Doenças**|
|---|---|
|Raio-X de tórax|Congestão ou sobrecarga devolume|
|Ecocardiograma|Insuficiência cardíaca ou isquemia|
|Ecocardiograma<br>transesofágico,<br>tomografia computadorizada de tórax,<br>ressonância nuclear magnética de tórax ou<br>angiografia|Dissecção de aorta|
|Tomografia<br>computadorizada<br>ou<br>ressonância nuclear magnética de crânio|Traumatismo craniano, sinais ou sintomas<br>neurológicos ou retinopatia hipertensiva|
|Ultrassonografia renal|Insuficiência renal, incluindo aquelas causadas<br>por obstrução urinária|
|Ecodoppler de artéria renal|Estenose de artéria renal|  
**Fonte:** Adaptado de Mancia et al., 2023 e Barroso et al. 2021<sup>6,30</sup> .  
18  
Na avaliação do paciente com urgência hipertensiva, o mais importante é se certificar de que se trata realmente de uma urgência, e não de uma emergência hipertensiva, a partir da história clínica e do exame físico. Exames complementares devem ser solicitados conforme a necessidade. Caso a urgência hipertensiva seja confirmada, devem ser procurados potenciais fatores precipitantes, sendo os mais comuns: má adesão ao tratamento medicamentoso, modo de vida não saudável e uso de medicamentos que aumentam a PA, incluindo anti-inflamatórios não esteroidais, corticoides, contraceptivos orais, imunossupressores, esteroides anabolizantes e simpaticomiméticos<sup>6,26</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **e. Diagnóstico de crianças e adolescentes** -->
O diagnóstico de crianças e adolescentes é realizado por meio da medida da PA, que deve ser realizada com técnica adequada, a depender da idade cronológica, considerando as recomendações a seguir<sup>37</sup> :  
- Paciente com menos de 3 anos de idade: posição deitada;  
- Paciente com idade a partir de 3 anos: sentado, com o braço na altura do coração;  
- A bolsa inflável deve ter o comprimento de 80% da circunferência do braço e largura de pelo menos 40% da circunferência do braço;  
- Deve-se medir a PA nos quatro membros na primeira consulta;  
- A PA deve ser verificada anualmente, após os 3 anos de idade;  
- Deve-se considerar os valores de PA para crianças e adolescentes elencados no Quadro 9, considerando três visitas distintas, de acordo com idade, sexo e percentil de estatura (Material Suplementar 1).  
Em crianças e adolescentes, a HAS pode ser classificada em grau 1 e 2, como apresentado no Quadro 9.  
Quadro 9. Classificação dos valores de pressão arterial de acordo com a faixa etária de crianças e adolescentes.  
|**Classificação**|**Crianças e pré-adolescentes (1 a 13**<br>**anos)**|**Adolescentes (a partir de 13 anos)**|
|---|---|---|
|PA normal|PA < P90para idade,sexo e altura a|PA < 120 mmHg/< 80 mm Hg|
|PA elevada|- PA ≥ P90 e < P95 para idade, sexo e<br>altura a; ou<br>- PA 120 mmHg /80 mmHg, mas < P95<br>(oque for menor)a|PA 120 mmHg /< 80 mmHg a 129<br>mmHg /< 80 mmHg|
|Hipertensão<br>arterial grau 1|- PA ≥ P95 para idade, sexo e altura, e<br>< P95 + 12 mmHg a; ou<br>- PA entre 130 mmHg /80 mmHg até<br>139 mmHg /89 mmHg (o que for<br>menor)|PA 130 mmHg /80 mmHg a 139<br>mmHg /89 mmHg|
|Hipertensão<br>arterial grau 2|- PA ≥ P95 + 12 mmHg para idade,<br>sexo e altura a; ou<br>- PA ≥ 140 mmHg /90 mmHg (o que for<br>menor)|PA ≥ 140 mmHg /90 mmHg|  
**Legenda:** P: percentil; PA: pressão arterial.  
19  
**Fonte:** Elaboração própria com base em Barroso et al. (2021)<sup>6</sup> .  
A avaliação laboratorial para o diagnóstico etiológico da HAS em crianças e adolescentes deve incluir exames de eletrólitos, ureia, creatinina, perfil lipídico e urinálise. Métodos de imagem podem ser complementares como a ultrassonografia renal em pacientes menores de seis anos de idade<sup>37</sup> .  
Em indivíduos com obesidade, é importante a avaliação da hemoglobina glicada, enzimas hepáticas e perfil lipídico. Na avaliação diagnóstica da HAS, podem ser realizados opcionalmente exames da função tiroidiana, estudo de avaliação do sono e dos níveis de esteroide no plasma e urinários<sup>37</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **f. Diagnóstico de gestantes** -->
A HAS na gestação é definida quando a PAS é igual ou superior a 140 mmHg ou PAD é igual ou superior a 90 mmHg, considerando-se o desaparecimento dos sons (Fase V de _Korotkoff_ ). As medidas devem ser realizadas, preferencialmente, na posição sentada e com intervalo entre quatro e seis horas com manguito de tamanho adequado. Se os valores de PAS forem ≥ 160 mmHg ou PAD ≥ 110 mmHg, a verificação deve ser repetida em 15 minutos, e não em quatro horas, pois se os valores forem mantidos ou se elevarem deve-se administrar tratamento oportuno. A posição em decúbito lateral esquerdo poderá ser utilizada para repouso da gestante. O método manual auscultatório é o mais indicado para realizar a medição, visto que os dispositivos automatizados podem subestimar a PA nesses casos<sup>6</sup> .  
Na primeira metade da gravidez, a paciente pode ter HAS se houve diagnóstico antes da gravidez ou identificada antes da 20ª semana. Também pode ocorrer a síndrome do avental branco, quando há alteração da hipertensão arterial durante as consultas, que não se mantém em avaliações domiciliares.  
Já na segunda metade da gravidez, pode ocorrer a hipertensão gestacional, quando há alteração da hipertensão arterial após a 20ª semana, em gestante previamente normotensa, sem proteinúria ou disfunção de órgãos-alvo. Já os casos de pré-eclâmpsia/eclampsia envolvem diagnóstico de hipertensão arterial após a 20ª semana de gestação, em gestante previamente normotensa, associada à proteinúria significativa ou disfunção de órgãos-alvo (contagem de plaquetas < 150.000/mm<sup>3</sup> , transaminases oxalacética ou pirúvica > 40 UI/L, creatinina > 1,2 mg/dL), edema pulmonar, iminência de eclâmpsia (cefaleia, epigastralgia, escotomas) ou eclâmpsia. Restrição de crescimento fetal ou alterações dopplervelocimétricas fetais devem chamar atenção para o diagnóstico de pré-eclâmpsia, mesmo na ausência de proteinúria<sup>6</sup> .  
Por fim, a pré-eclâmpsia sobreposta à hipertensão arterial sistêmica ocorre nas seguintes situações<sup>38</sup> :  
- quando, após a 20ª semana de gestação, ocorre o aparecimento ou piora da proteinúria, já detectada na primeira metade da gravidez;  
- quando após a 20ª semana de gestação, ocorre piora do controle pressórico (necessidade de aumento das doses ou associação de anti-hipertensivos); ou ocorrência de disfunção de órgãos-alvo.  
A eclâmpsia caracteriza-se pela presença de convulsões tônico-clônicas generalizadas ou coma em mulher com qualquer quadro hipertensivo, não causadas por epilepsia ou qualquer outra  
20  
doença convulsiva durante a gravidez, no parto e no puerpério imediato<sup>37,39–41</sup> . São sinais premonitórios de eclâmpsia<sup>38,42</sup> :  
- escotomas cintilantes;  
- cefaleia occipital;  
- epigastralgia ou dor intensa no hipocôndrio direito com ou sem hipertensão arterial grave ou proteinúria.  
A síndrome de HELLP relaciona-se com a anemia hemolítica microangiopática e ao vasoespasmo no fígado materno. A suspeita clínica dos casos de síndrome de HELLP deve ser considerada quando na presença de trombocitopenia em uma gestante com pré-eclâmpsia. Vale ressaltar que, a síndrome desenvolve-se em 10% a 20% das gestantes com pré-eclâmpsia grave/ ou eclâmpsia. O diagnóstico faz-se com a presença de hemólise por meio da análise das bilirrubinas (acima de 1,2 mg/dlL), alteração da função hepática por meio da análise do TGO ou TGP (acima de 70 UI), plaquetopenia (menor que 100.000/mm<sup>3</sup> ) e a desidrogenase lática (DHL) (acima de 600 U/L)<sup>38</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **8. CRITÉRIOS DE INCLUSÃO** -->
Devem ser incluídos nesse Protocolo indivíduos com suspeita ou diagnóstico confirmado de pressão normal alta ou HAS.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **9. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que inicialmente foram rastreados para HAS, mas cujo diagnóstico de pressão normal alta ou HAS foi descartado, devem ser excluídos do tratamento e monitoramento previstos neste Protocolo. Adicionalmente, serão excluídos deste Protocolo pacientes recém-nascidos.  
Pacientes que apresentarem intolerância, hipersensibilidade ou contraindicação a qualquer procedimento preconizado por este Protocolo estão excluídos da recomendação de uso do respectivo medicamento ou procedimento.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **10. ABORDAGEM TERAPÊUTICA** -->
A estratégia de tratamento da HAS inclui ações de curto prazo, para resolução de crise hipertensiva, por exemplo, e longo prazo para controle da PA e redução do RCV. O foco do tratamento da HAS engloba três dimensões: autocuidado e ações educativas, terapias não medicamentosas com enfoque multiprofissional e interdisciplinar e terapia medicamentosa<sup>16</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **a. Metas terapêuticas da pressão arterial** -->
É consenso entre a maioria das diretrizes clínicas que a meta inicial da PA em consultório clínico deve ser menor que 140 mmHg /90 mmHg, independentemente das comorbidades e do nível do RCV que o paciente apresente<sup>13,19,26</sup> . Caso o tratamento seja bem tolerado, a meta deve ser 130 mmHg /80 mmHg nos indivíduos com menos de 65 anos de idade e, especialmente, naqueles com comorbidades (diabetes, DRC, doença arterial coronariana, pós-acidente vascular ou ataque isquêmico)<sup>13,19,26,28</sup> .  
21  
Em pacientes com HAS de 65 anos a 79 anos, recomenda-se inicialmente reduzir a PAS para valores entre 140 mmHg e 130 mmHg, balanceando proteção cardiovascular e eventos adversos. Se o paciente tolerar o tratamento e não apresentar sinais de hipoperfusão, pode-se considerar reduzir a PAS para menos de 130 mmHg. A PAD deve ser reduzida para menos de 80 mmHg, mas não se deve tentar diminuir a PAS/PAD para menos de 120 mmHg /70 mmHg<sup>30</sup> . Assim, é recomendado estabelecer metas flexíveis e individualizadas para idosos, que considerem sua heterogeneidade, sua vitalidade e sua resposta aos eventos adversos<sup>43</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **i. Metas terapêuticas para crianças e adolescentes** -->
Os objetivos do tratamento da HAS em crianças e adolescentes são manter a PAS ou PAD abaixo do percentil 95 (Material Suplementar 1). Para aqueles com fatores de risco associados ou danos em órgãos-alvos, a recomendação é que a PAS ou a PAD deve ser mantida abaixo do percentil 90, para sexo, idade e altura (Material Suplementar 1)<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **ii. Metas terapêuticas para gestantes** -->
O principal objetivo do tratamento da HAS em gestantes é garantir o controle da PA para evitar complicações maternas. A PAS deve ser mantida entre > 120 mmHg e < 160 mmHg e a PAD, entre > 80 mmHg e < 110 mmHg, já que tanto a hipertensão quanto a hipotensão induzida podem prejudicar a perfusão placentária e, consequentemente, o crescimento fetal<sup>44</sup> .  
Além disso, o tratamento deve prevenir a progressão de lesões em órgão-alvo, complicações cardíacas e cerebrovasculares, além das complicações obstétricas e fetais<sup>44</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **b. Tratamento não medicamentoso** -->
O tratamento não medicamentoso envolve ações de autocuidado, alcance ou manutenção de peso corporal adequado (avaliado pelo IMC e circunferência abdominal) e de uma alimentação adequada e saudável, com redução do consumo de sódio e da ingestão de alimentos ultraprocessados; controle do peso corporal; prática regular de atividade física; redução ou cessação da ingestão de bebidas alcóolicas; prevenção e cessação do tabagismo; redução e gerenciamento do estresse; e maior qualidade do sono<sup>16</sup> .  
Destaca-se que o tratamento não medicamentoso no caso de gestantes não deverá ser utilizado isoladamente em situações em que a PAS esteja acima de 160 mmHg persistente por mais de 15 minutos, sendo a internação hospitalar indicada em pacientes com hipertensão grave na gestação, uma vez que valores de PAS acima de 155 mmHg são detectados imediatamente antes da ocorrência de AVE de gestantes com pré-eclâmpsia grave<sup>6</sup> .  
O **Erro! Fonte de referência não encontrada.** apresenta condutas e recomendações para a modificação dos modos de vida e a melhora da saúde cardiovascular, as quais serão detalhadas nas seções subsequentes.  
Quadro 10. Recomendações para o tratamento não medicamentoso da hipertensão arterial sistêmica.  
|**Condutas**|**Recomendações**|
|---|---|
|**Alimentação**|<br>**Adotar um padrão alimentar saudável,**com predominância de|
||alimentos de origemvegetal_in natura_ou minimamenteprocessados,|  
22  
|**Condutas**|**Recomendações**|
|---|---|
||laticínios de baixo teor de gordura, aves e peixes, e consumo restrito de<br>carnes vermelhas e processadas.<br><br>**Reduzir o consumo de sódio**para até**2 g/dia**(equivalente a 5 g<br>de sal/dia).<br><br>**Aumentar a ingestão de potássio**, consumindo mais frutas,<br>hortaliças, cereais integrais e laticínios com baixo teor de gordura, exceto<br>na condição de hipercalemia.<br><br>Outras recomendações sobre redução da ingestão calórica para<br>diminuição de massa corporal podem ser consultadas no PCDT de<br>sobrepeso e obesidade em adultos.|
|**Ingestão de**<br>**bebida alcoólica**|<br>**Não há nível seguro**para o consumo de álcool, mesmo em<br>pequenas doses ele causaprejuízos.|
|**Tabagismo**|**Cessar o tabagismo.**<br><br>Profissionais de saúde devem oferecer**suporte contínuo**para<br>cessação.<br><br>Considerar prescrição de medicamentos quando necessário, conforme<br>PCDT do Tabagismopublicadopelo Ministério da Saúde.|
|**Atividade física e**<br>**exercício físico**|**Realizar atividades físicas:**<br><br>Qualquer aumento no nível de atividade física é benéfico à saúde.<br><br>Tentar atingir, pelo menos, 150 min/sem de atividades físicas<br>moderadas.<br><br>Maiores benefícios são obtidos com 300 min/sem de atividades<br>físicas moderadas.<br>**Fazer treinamento físico estruturado**<br>**Exercícios aeróbicos:**<br>-    Opções: caminhada, corrida, natação, dança, ciclismo, entre outros.<br>-     Realizar pelo menos 3 vezes/semana, pelo menos 30 min/sessão,<br>intensidade moderada (40% a 60% da frequência cardíaca de reserva).<br>**Exercícios resistidos:**<br><br>Complementares aos aeróbicos.<br><br>Realizar 8 a 10 exercícios, com 1 a 3 séries de 8 a 12 repetições,<br>evitando fadiga total e com pausas de 90 segundos entre os exercícios e<br>as séries.|
|**Controle do**<br>**estresse**|<br>**Realizar técnicas de controle do estresse**, como a meditação e<br>outras.|
|**Autocuidado**|<br>**Realizar intervenções educacionais de autocuidado**que<br>promovam mudanças de comportamento.|
|**Saúde bucal**|<br>**Realizar avaliação prévia a procedimentos invasivos**com risco<br>de sangramento. Por exemplo: exodontias, intervenções periodontais,<br>implantes,endodontia,ortodontia e limpezaprofilática.|
|**Qualidade do**<br>**sono**|- Manter horário regular de dormir/acordar.<br>- Respeitar a duração do sono (habitualmente entre 7 e 8 horas para<br>adultos).<br>- Evitar uso de telas e luz azul antes de dormir.<br>- Reduzir o consumo de cafeína e álcool à noite.<br>- Avaliar apresença de distúrbios do sono como insônia e apneia do sono.|  
Fonte: elaboração própria.  
23

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **i. Alimentação e nutrição** -->
O Ministério da Saúde dispõe de documentos orientadores para o cuidado em alimentação e nutrição da população brasileira e das pessoas com HAS que devem subsidiar a prática profissional<sup>45</sup> . Nesse sentido, podendo ser citados o Guia Alimentar para População Brasileira<sup>46</sup> ; Alimentação Cardioprotetora: manual de orientações para os profissionais de saúde da Atenção Básica<sup>47</sup> . O protocolo de Uso do Guia Alimentar para a População Brasileira na Orientação Alimentar de Pessoas Adultas com Obesidade, Hipertensão arterial e Diabetes mellitus: bases teóricas e metodológicas<sup>48</sup> e a Matriz para Organização dos Cuidados em Alimentação e Nutrição na APS<sup>49</sup> .  
De uma maneira geral, como proposto pelo Guia Alimentar para a População Brasileira, uma alimentação adequada e saudável deve ser baseada em alimentos _in natura_ ou minimamente processados (frutas, legumes, verduras, leguminosa, cereais integrais e oleaginosas), variados e predominantemente de origem vegetal. O consumo excessivo de sódio, açúcares, gorduras saturadas e gorduras trans e alimentos ultraprocessados, aumentam o risco de doenças do coração e outras doenças crônicas, e por isso devem ser evitados<sup>45</sup> .  
O padrão alimentar _Dietary Approaches to Stop Hypertension_ (DASH) caracteriza-se por uma alimentação com predominância de alimentos de origem vegetal _in natura_ e minimamente processados, com produtos lácteos com baixo teor de gordura, aves e peixes e consumo restrito de carnes vermelhas e processadas, bem como redução no consumo de bebidas adoçadas<sup>50</sup> . Alguns componentes presentes nos alimentos que compõem este padrão alimentar estão associados com a baixa incidência de DCV e, por essa razão, são intitulados alimentos cardioprotetores<sup>47,51</sup> .  
Assim, recomenda-se, quando possível, o consumo integral dos alimentos (cascas, talos, sementes, entre outros), após higienização adequada, para melhoria do aporte de nutrientes importantes no controle da HAS e outras condições crônicas<sup>52–54</sup> .  
A ingestão recomendada de sódio é a mesma para a população em geral, de até 2 g/dia, o que equivale a 5 g/dia de sal (uma colher de chá rasa). Contudo, a redução diária da ingestão de sódio, inclusive abaixo da quantidade recomendada, contribui para a diminuição da PA, principalmente dos indivíduos hipertensos, negros e idosos<sup>55</sup> .  
A redução do sódio durante o preparo dos alimentos pode ser alcançada com a utilização do sal de ervas (mistura de sal e ervas desidratadas como salsa, alecrim, manjericão, orégano)<sup>a</sup> na mesma proporção em que o sal seria utilizado<sup>47</sup> . Além disso, recomenda-se a redução do consumo de produtos ricos em sódio como _fast food_ , carnes salgadas, a exemplo do bacon e charque, alimentos conservados em salmoura ou enlatados (molho de tomate e conservas de milho, ervilhas, azeitonas entre outros), queijos amarelos (parmesão, provolone, prato) e alimentos ultraprocessados, tais como empanados de carne, frango ou peixe, embutidos (presunto, mortadela, salsicha, linguiça, salame), temperos prontos, molho de soja ( _shoyu_ ), molho inglês, _ketchup_ , mostarda, maionese, caldos concentrados, temperos prontos em tabletes ou em pó, amaciantes de carne e sopas desidratadas, além de petiscos industrializados ( _chips_ , batata frita e outros salgadinhos)<sup>6,56</sup> .  
Convém destacar que o consumo de ultraprocessados, além de produzir efeitos negativos sobre a saúde, afetam de modo desfavorável a cultura, a vida social e o meio ambiente, em  
> a **Receita:** 25 g (1 colher de sopa) de sal; 25 g (5 colheres de sopa) de alecrim desidratado; 25 g (6 colheres de sopa) de salsinha desidratada; 25 g (6 colheres de sopa) de manjericão desidratado; 25 g (6 colheres de sopa) de orégano desidratado.  
24  
decorrência das lógicas de produção, distribuição e comercialização desses alimentos. Nesse sentido, recomenda-se evitar o seu consumo<sup>46</sup> .  
O sal rosa do Himalaia e o sal marinho, entre outros, apresentam o mesmo conteúdo de cloreto de sódio do sal de cozinha ou do sal grosso, também sendo recomendado o seu uso restritivo<sup>6</sup> . Os substitutos do sal contendo cloreto de potássio e redução do cloreto de sódio (30% a 50%) são úteis para diminuir a ingestão de sódio e aumentar a de potássio. No entanto, seu uso é contraindicado em pacientes com hipercalemia<sup>6</sup> .  
Padrões saudáveis de dieta, como a DASH, são ricos em potássio, nutriente cuja ingestão alimentar deve ser incentivada preferencialmente ao uso de suplementação, pois a presença de outros nutrientes no alimento pode melhorar a sua biodisponibilidade<sup>28</sup> . O consumo adequado de potássio reduz o impacto negativo do sódio na PA<sup>57</sup> . Os pacientes com HAS que não apresentem disfunção renal estágios 3 a 5 devem aumentar a ingestão diária de alimentos ricos em potássio, tais como, frutas, hortaliças, cereais integrais, leite e derivados com baixo teor de gordura (Quadro 11).  
Quadro 11. Quantidade de potássio por porção de alimento ou preparo.  
|**Alimento ou preparo**|**Porção**|**Quantidade de potássio (mg)**|
|---|---|---|
|Banana|1 unidade|376|
|Melão|1porção|216|
|Laranja|1 unidade|163|
|Leite|1 copo|266|
|Iogurte|1porção|150|
|Feijão|1 concha|230|
|Salada (tomate, cebola e<br>alface)|1 prato sobremesa|260|
|Tomate,extrato|3colheres de sopa|204|
|Pão integral|1 fatia|80|  
**Fonte:** Valores retirados do Núcleo de Estudos e Pesquisas em Alimentação - Unicamp, 2011.  
De forma a auxiliar as escolhas alimentares, a leitura dos rótulos dos alimentos é fundamental e deve ser incentivada. Com o atual sistema de rotulagem adotado no Brasil, é possível identificar o alerta da lupa em produtos com quantidades excessivas de sódio, açúcares adicionados e gorduras saturadas. Assim, a população poderá ampliar o seu grau de autonomia para escolhas alimentares, sendo recomendado que pessoas com HAS evitem consumir produtos industrializados cuja quantidade excessiva desses nutrientes seja sinalizada pela lupa na rotulagem frontal<sup>46</sup> .  
É importante ainda destacar que no caso da alimentação infantil para além do reforço das recomendações do Guia Alimentar da População Brasileira, é necessário cuidado com uso de alimentos desnatados, desnecessário dentro de uma alimentação infantil adequada e saudável, assim como não são recomendados o uso de alimentos classificados como _light_ ou _diet_ devido às composições substitutivas entre ingredientes reduzidos ou retirados, respectivamente, que podem ser prejudiciais.  
Como uma das estratégias para o cuidado às pessoas com HAS no que tange às práticas alimentares, recomenda-se a avaliação do consumo alimentar, por meio do Formulário de Avaliação de Marcadores do Consumo Alimentar<sup>58</sup> . O uso desta ferramenta possibilita inferências sobre as escolhas mais frequentes e os padrões saudáveis e não saudáveis adotados pelas pessoas acompanhadas. Incluir esta avaliação no cotidiano do serviço de saúde, alinhado  
25  
com os protocolos de uso do Guia Alimentar para a População Brasileira<sup>46</sup> e da Matriz para Organização dos Cuidados em Alimentação e Nutrição na APS<sup>49</sup> , possibilitará a ampliação do espaço para o diálogo sobre alimentação adequada e saudável considerando a inserção sociocultural, desafios, possibilidades, necessidades e motivações do indivíduo, bem como a aproximação de profissionais de saúde das informações sobre alimentação baseadas em evidências científicas.  
Os questionários de avaliação de consumo alimentar são ferramentas possíveis que contribuem para o processo de gestão do cuidado, principalmente no âmbito individual, potencializando as ações de promoção da alimentação adequada e saudável, na perspectiva da educação em saúde, prevenção e tratamento da HAS no dia a dia da APS<sup>48</sup> .  
A alimentação não saudável se apresenta como um dos principais fatores de risco relacionados à carga global de doenças no mundo, sendo no Brasil, o maior fator de risco que contribuiu para os anos de vida perdidos, superior ao uso de bebidas alcóolicas, drogas, tabagismo e inatividade física, no ano de 2015<sup>48,59</sup> .  
Estudos sinalizam a relação direta e linear entre aumento de peso e maiores níveis de PA. Dessa forma, o alcance e a manutenção do peso saudável são fundamentais para que a PA permaneça em níveis mais baixos como ação preventiva<sup>6,28</sup> . No contexto do tratamento, a redução de peso para níveis adequados diminui tanto a PAS quanto a PAD, principalmente em indivíduos que utilizam medicamentos e apresentam sobrepeso e obesidade<sup>60</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **ii. Ingestão de bebida alcoólica** -->
A ingestão de bebidas alcoólicas acompanha rotinas sociais em diversos contextos populacionais, o que facilita ignorar ou desconsiderar a saúde e os danos sociais em decorrência do seu abuso. A OMS incluiu esse hábito como um dos desafios de saúde pública na agenda dos objetivos do desenvolvimento sustentável para 2030<sup>61</sup> .  
O consumo de bebidas alcóolicas, seja pela ingestão regular ou episódica, está notadamente associado ao aumento do risco de DCV, mortes por AVE hemorrágico (47,5%), doença cardíaca isquêmica (42,5%) e arritmia cardíaca<sup>7,61</sup> . Em 2016, o consumo de álcool foi responsável em todo o mundo por aproximadamente 7,2% da mortalidade prematura, entre pessoas com idade inferior ou igual a 69 anos. Além disso, de todas as mortes atribuídas ao consumo de álcool nesse período, 19% foi devido às DCV<sup>61</sup> .  
O consumo de álcool pode trazer prejuízos ao tratamento das doenças crônicas não transmissíveis, dentre elas a HAS<sup>1</sup> . Uma revisão com meta-análise envolvendo a população do Reino Unido mostrou que, em pacientes que bebiam mais de dois drinques por dia, reduzir o consumo de bebida alcoólica associou-se à maior diminuição da PAS e da PAD<sup>62</sup> . Um estudo longitudinal sobre saúde do adulto mostrou que, em quatro anos de seguimento, as pessoas que reduziram o consumo total de bebida alcoólica apresentaram menor aumento da PAS e PAD em comparação aos que aumentaram o consumo<sup>63</sup> .  
A redução da ingestão de bebida alcoólica diminui a PA de maneira dose-dependente com um aparente efeito de limiar. O tempo do efeito da ingestão alcoólica na PA também deve ser considerado. Evidências de certeza moderada mostraram que o consumo agudo de doses médias e elevadas de teor alcoólico a PA nas primeiras seis horas e por até 12 horas após o consumo de álcool. Altas doses de consumo de álcool aumentaram a PA em tempos superiores a 13 horas<sup>64</sup> .  
Nesse contexto, as atuais evidências demonstram que não existe consumo de álcool isento de risco, mesmo em pequenas doses<sup>65</sup> . Além dos efeitos relacionados ao consumo de álcool, os  
26  
indivíduos com HAS costumam ter dificuldades no uso regular dos medicamentos<sup>66</sup> . Assim, o consumo de bebida alcoólica deve ser contraindicado<sup>65,67,68</sup> . A implementação de intervenções para prevenção ou cessação do uso de álcool em pessoas que bebem mais do que dois drinques por dia reduz a carga de doenças e da HAS, devendo ser priorizadas em países com risco substancial atribuível ao álcool. É importante ainda, orientar sobre o possível ganho de peso associado ao consumo do álcool<sup>69</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iii. Tabagismo** -->
O tabagismo inclui o uso de cigarro, charuto, cigarrilha, cachimbo, narguilé e cigarro eletrônico, além da exposição passiva à fumaça do tabaco. Considerado um fator de risco totalmente evitável, fumar apenas um único cigarro por dia aumenta o risco de desenvolver doença arterial coronariana e AVE, além de aumentar a PA de forma aguda e transitória por meio da ativação nervosa simpática<sup>28,70–73</sup> .  
Além disso, o uso de cigarros eletrônicos vem aumentando entre adolescentes e adultos jovens que nunca fumaram. Uma revisão demonstrou que o uso destes dispositivos eleva a PAS e a PAD, indicando que seu uso deve ser totalmente desencorajado<sup>69</sup> .  
O combate ao tabagismo possui características que envolvem dependências psíquica e química. Portanto, os profissionais de saúde devem estar preparados para orientar constantemente e fornecer apoio psicossocial ao tabagista. Caso necessário, deve ser avaliada a possibilidade de prescrição médica de medicamentos para auxiliar na cessação do tabagismo<sup>6</sup> . O PCDT do Tabagismo vigente apresenta as orientações sobre o tratamento medicamentoso e não medicamentoso para cessação do tabagismo<sup>74</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iv. Atividade física e exercício físico** -->
O Ministério da Saúde dispõe de orientações sobre a prática de atividade física para crianças, adolescentes, adultos, idosos, além de pessoas gestantes, no puerpério e pessoas com deficiências, o qual também deve direcionar o cuidado desses pacientes<sup>75</sup> .  
Recomenda-se que todos os indivíduos adultos realizem pelo menos 150 minutos de atividades físicas moderadas por semana<sup>76</sup> . Essas práticas diminuem a incidência da HAS e, em pacientes que já tenham HAS, reduzem o risco de mortalidade. Assim, incluir hábitos mais ativos na rotina contribui tanto para a prevenção, quanto para o tratamento da HAS<sup>77,78</sup> .  
Destaca-se, entretanto, que níveis menores de atividade física também trazem benefícios à saúde, visto que a quantidade de passos dados por dia é inversamente proporcional à mortalidade nos indivíduos com HAS<sup>75</sup> . Dessa forma, mesmo quando as recomendações preconizadas não puderem ser alcançadas, os indivíduos devem ser orientados a se movimentarem mais, onde e quando for possível, e aumentarem gradativamente o tempo na prática dessas atividades. Caso o paciente apresente condições clínicas adequadas e seja possível, deve-se incentivar que se atinja a meta de 300 minutos/semana de atividades físicas, para obter benefícios mais expressivos, especialmente nos pacientes com sobrepeso ou obesidade<sup>76</sup> .  
Ressalta-se que, para se atingir as recomendações apresentadas, pode-se realizar atividades físicas no ambiente de trabalho ou estudo, doméstico, em deslocamentos diversos ou no tempo livre. Além disso, as recomendações podem ser cumpridas de diferentes formas, como realizar 30 minutos de atividades físicas cinco vezes na semana ou 50 minutos de atividade física três vezes na semana. Ainda, pode-se optar por realizar a atividade física de forma acumulada no  
27  
mesmo dia, em blocos de no mínimo 10 minutos, ou seja: 30 minutos contínuos ou 2 blocos de 15 minutos cada ou ainda 3 blocos de 10 minutos cada<sup>76</sup> .  
Para o tratamento mais individualizado da HAS, maiores benefícios podem ser obtidos com a prática regular de exercícios físicos estruturados, sistematizados e planejados, de preferência com a orientação de um profissional qualificado. Recomenda-se que as pessoas com HAS, independentemente do grau da doença e do RCV, realizem atividades aeróbicas, de resistência de força e de flexibilidade<sup>76</sup> .  
Diferentes tipos de atividades aeróbicas podem ser realizadas (andar, correr, nadar, dançar, pedalar, praticar esportes, entre outras) e o paciente deve realizar pelo menos 3 sessões por semana, com duração de pelo menos 30 minutos por sessão, em intensidade moderada, equivalente a 40% a 60% da frequência cardíaca de reserva<sup>75</sup> . A progressão dessas atividades sistematizadas (exercício físico), no decorrer do tempo, deve ser baseada principalmente no aumento do volume, com aumento do número de sessões semanais ou maior duração das sessões de treinamento<sup>6,26,79</sup> . Com a prática de exercícios físicos aeróbicos, esperam-se reduções médias de -12,3 mmHg (IC 95%, -15,2 mmHg a -9,3 mmHg) na PAS e -6,1 mmHg (IC95%, -7,8 mmHg a -4,5 mmHg) na PAD de hipertensos<sup>79</sup> , além de reduções das médias da PAS de 24 horas de - 5,5 mmHg (IC95%, -8,1 mmHg a -2,8 mmHg) e da PAD de 24 horas de -3,8 mmHg (IC95%, - 4,9 mmHg a -2,6 mmHg)<sup>80</sup> .  
Os exercícios resistidos dinâmicos complementares devem ser realizados com 8 a 10 exercícios de intensidade moderada, com 1 a 3 séries cada, incluindo cerca de 8 a 12 repetições por série. Esses exercícios devem ser executados sem atingir a fadiga concêntrica (ou seja, interromper a série quando a velocidade do movimento diminuir) e mantendo-se pausas longas passivas, em torno de 90 segundos, entre as séries<sup>6,28</sup> . Com o treinamento resistido dinâmico em indivíduos com HAS, são observadas reduções médias da PAS de -5,7 mmHg (IC95%, -9,0 mmHg a -2,7 mmHg) e da PAD de -5,2 mmHg (IC95%, -8,4 mmHg a -1,9 mmHg)<sup>81</sup> , mas seu efeito sobre a PA medida em ambulatório é pouco evidente<sup>80</sup> .  
<mark>A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos estabelecimentos de saúde e polos do Programa Academia da Saúde na APS, além de fortalecer algumas atividades, como as Práticas Integrativas e Complementares em Saúde (PICS).</mark>  
As PICS, sempre que disponíveis nos serviços de saúde, devem compor o rol de ações e intervenções voltadas ao cuidado de indivíduos, complementando o tratamento da equipe multiprofissional. A Política Nacional de Práticas Integrativas e Complementares no SUS (PNPIC) orienta que estados, distrito federal e municípios instituam suas próprias normativas trazendo para o SUS práticas que atendam às necessidades regionais<sup>82</sup> . As PICS podem ser consideradas de forma complementar ao tratamento, devido aos possíveis benefícios aos pacientes com HAS. Contudo, ressalta-se que as PICS não substituem os demais tratamentos preconizados pelo Protocolo e que o tratamento medicamentoso não pode ser interrompido sem orientação médica.  
Indivíduos com HAS que apresentam valores de PAS/PAD acima de 180 mmHg/110 mmHg, dois fatores de RCV associados, lesão de órgão-alvo, doenças cardíacas associadas ou que pretendam realizar a prática de atividades físicas e exercícios físicos intensos ou de competição, devem fazer um teste de esforço físico antes de iniciar as atividades, para excluir a presença de isquemias ou arritmias que necessitem de prescrição específica de programa de exercício físico. Ressalta-se que para realização desse teste, o paciente deve manter o uso habitual de todos os seus medicamentos anti-hipertensivos<sup>6,79,83</sup> .  
28  
As gestantes devem ser orientadas a praticar atividade física de maneira regular. É recomendado que esta realize exercícios de intensidade moderada, que podem divididos ao longo da semana, totalizando pelo menos 150 minutos de atividade física semanal. Gestantes com suspeita ou diagnóstico de pré-eclâmpsia devem ser internadas, mantendo repouso relativo no ambiente hospitalar. Condições de saúde que podem se agravar durante a prática de atividade física, devem ser avaliadas de maneira individualizada no pré-natal.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **v. Estresse** -->
Na etiologia da HAS há intrínseca associação entre os fatores genéticos e os comportamentais, de modo que tem sido considerada a relação entre estresse psicossocial e HAS 82. Uma revisão sistemática com meta-análise mostrou que o estresse psicossocial foi associado a um risco aumentado de HAS (OR 2,40; IC 95%, 1,65-3,49) e que os hipertensos tiveram maior incidência de estresse psicossocial em comparação com pacientes normotensos (OR 2,69; IC95%, 2,32-3,11)<sup>84</sup> .  
Cada vez mais, as pessoas têm vivenciado situações de ansiedade, depressão e estresse psicossocial crônico em decorrência da globalização, mudanças culturais, mudanças socioeconômicas e condições de trabalho. Um estudo de revisão integrativa concluiu <mark>que ansiedade e estresse, além da depressão, podem ser agentes moduladores da HAS</mark><sup>84</sup> .  
Apesar de estudos analisarem a interação entre estresse psicossocial e HAS, essa relação ainda é controversa. Embora sejam necessárias mais pesquisas para determinar os efeitos do estresse crônico na PA, ensaios clínicos randomizados que avaliaram os efeitos da meditação transcendental e atenção plena ( _mindfullness_ ) na PA sugerem que essas práticas reduziram a PA 85. Uma revisão sistemática com meta-análise avaliando o efeito de programas de _mindfullness_ para reduzir estresse em pacientes com HAS, mostrou que essa intervenção parece ser eficaz particularmente para a redução da PAD<sup>86</sup> .  
Segundo a _American Heart Association_ , a meditação<sup>87</sup> , assim como as estratégias de meditação transcendental<sup>88</sup> e ioga<sup>89,90</sup> podem ser consideradas como um coadjuvante para a redução do RCV, embora os seus benefícios ainda não estejam bem estabelecidos. Uma revisão do _National Institute for Health and Care Excellence_ (NICE)<sup>91</sup> incluiu um único estudo que não indicou benefício em 12 meses das terapias de relaxamento na incidência de infarto agudo do miocárdio (OR 0,15; IC95%, 0,00-7,52); de AVE (OR 8,18; IC95% 0,16-414,30) e na presença de angina (OR 0,15; IC95%, 0,00-7,52)<sup>92</sup> .  
Embora ainda sejam necessários estudos mais robustos, o controle do estresse emocional deve ser incluído como uma das ferramentas de prevenção primária da HAS, visando a redução da reatividade cardiovascular, redução da PA e sua variabilidade<sup>71,93–95</sup> .  
As orientações gerais para todo indivíduo com doença crônica, como a prática regular de atividade física, incluindo as PICS, alimentação adequada e saudável, prevenção e cessação de tabagismo, e controle do consumo de álcool também colaboram com a redução do estresse<sup>23</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **vi. Autocuidado** -->
O autocuidado apoiado busca preparar e emponderar as pessoas para que possam autogerenciar sua saúde e a atenção recebida, por meio de atividades exercidas pelo indivíduo para o seu próprio benefício, buscando a manutenção da vida, da saúde e do bem-estar. Quando o indivíduo consegue desenvolver ações que atendam suas necessidades, ele está apto ao  
29  
autocuidado, sendo essa aptidão adquirida pelo aprendizado, e influenciada pela idade, experiências de vida, cultura, crenças, educação, dentre outros fatores. Este conceito se baseia a partir de ações como<sup>96</sup> :  
- Papel central das pessoas usuárias: os indivíduos devem participar ativamente no gerenciamento de sua saúde, desenvolvendo autorresponsabilidade (por exemplo: identificação de problemas relacionados à sua saúde, estabelecimento de prioridades, proposição conjunta de metas com a equipe de saúde e participação ativa na elaboração de seus planos de cuidado).  
- Estratégias de apoio ao autocuidado: incluem avaliação contínua do estado de saúde, fixação de metas, elaboração de planos personalizados e utilização de tecnologias de solução de problemas. Essas estratégias são fundamentadas em evidências científicas e programas que oferecem informações, suporte emocional e ações para que profissionais e pessoas usuárias possam lidar com condições crônicas, como a HAS.  
- Organização de recursos de estabelecimentos de saúde e da comunidade: treinamento de profissionais de saúde, monitoramento das metas de autocuidado, suporte por meio de grupos, ações educacionais e mobilização de recursos comunitários para alcançar as metas de autogerenciamento.  
Em resumo, o autocuidado apoiado é uma colaboração estreita entre a equipe de saúde e as pessoas usuárias, focando no empoderamento e na autogestão da saúde. Este modelo não desresponsabiliza os profissionais de saúde, mas fortalece o apoio para que as pessoas usuárias se tornem agentes ativos na gestão de sua própria saúde<sup>96</sup> .  
Os comportamentos de autocuidado recomendados para o controle da HAS incluem principalmente a adesão à terapêutica anti-hipertensiva e à alimentação adequada e saudável, com baixo teor de sal, realização de atividade física regular, prevenção e cessação do tabagismo e moderação ou cessação no consumo de bebidas alcoólicas, quando houver. Em estudos controlados randomizados, mudanças na dieta, exercícios físicos e intervenções para reduzir o consumo de álcool demonstraram produzir uma redução significativa na PA. Destaca-se ainda a importância das consultas periódicas de reavaliação junto à equipe de referência da APS, cuja frequência varia conforme o estágio da doença e a estratificação do RCV, o que deve ser frisado pelos profissionais desde o diagnóstico.  
Intervenções educacionais têm sido indicadas para o direcionamento ao autocuidado, tanto na promoção da saúde quanto na prevenção de agravos à saúde, ressaltando-se também para sua efetividade, a importância da literacia para a saúde na abordagem profissional. Uma revisão sobre ações educacionais em indivíduos com HAS apontou benefícios nas formas de intervenção educacional individual e em grupo. Estratégias, como contato telefônico, lembretes por mensagens e materiais para leitura, foram utilizadas como métodos de apoio e mostraram efeito moderado a alto na adesão às modificações do modo de vida e controle da PA. Porém, as mudanças em comportamentos de saúde muitas vezes são difíceis de serem obtidas a curto prazo e, em seguida, mantidas a longo prazo ou para toda a vida<sup>97</sup> .  
Nesse sentido, o modelo de mudanças de comportamento conhecido como 5As (arguir, aconselhar, avaliar, assistir e acompanhar), desenvolvido para intervenções breves, é recomendado<sup>98</sup> . Além disso, a autoeficácia pode influenciar o autocuidado e refere-se à crença de um indivíduo em si mesmo e em sua capacidade de ser bem-sucedido em uma tarefa. Uma revisão sistemática com meta-análise indicou que programas de educação em autogestão podem promover a autoeficácia em pacientes com HAS, possivelmente contribuindo para um melhor controle da doença e do tratamento. Essas estratégias também podem fornecer uma visão mais abrangente para os profissionais de saúde, de modo que intervenções eficazes para o controle dos  
30  
hipertensos sejam propostas. Ainda, o compromisso dos pacientes com sua própria saúde e seu envolvimento com o autocuidado podem ser avaliados por meio do comparecimento às consultas clínicas, adesão ao tratamento e mudanças nos modos de vida<sup>97</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **vii. Saúde Bucal** -->
O atendimento odontológico desempenha um papel fundamental no cuidado multiprofissional de usuários com doenças cardíacas, contribuindo significativamente para a saúde geral desses indivíduos, por meio de ações de promoção da saúde e prevenção de doenças, além do alívio de dores bucais, eliminação de focos de infecção e redução do estresse durante os atendimentos clínicos<sup>99</sup> .  
Todos os profissionais de saúde devem orientar as pessoas com HAS a consultarem um cirurgião-dentista. O encaminhamento desses usuários deve ser organizado de acordo com o fluxo de atendimento de cada Unidade de Saúde<sup>100</sup> .  
Quando há suspeita de problemas cardiovasculares, é recomendável que a PA, a frequência cardíaca e a frequência respiratória sejam avaliadas antes de cada consulta odontológica<sup>101</sup> . Contudo, a alta prevalência da HAS justifica a implementação de uma rotina de verificação da PA antes de qualquer procedimento. A identificação de PA elevada antes da intervenção pode exigir cuidados específicos, prevenindo reações adversas durante e após o tratamento<sup>102</sup> Portanto, é essencial que o profissional pergunte sempre ao indivíduo sobre um diagnóstico prévio da HAS.  
Os riscos associados ao atendimento odontológico para esse grupo de indivíduos exigem maior atenção, uma vez que procedimentos mais invasivos podem, em combinação com os riscos da DCV, levar à descompensação do quadro cardiológico e resultar em emergências médicas. Por isso, é fundamental que essas pessoas sejam submetidas a uma anamnese detalhada, possibilitando a identificação do risco cardiológico e a adequação do controle clínico<sup>103,104</sup> .  
As cardiopatias são classificadas em três níveis de risco para procedimentos odontológicos: alto, moderado e baixo. Indivíduos com alto risco incluem aqueles com próteses valvares cardíacas, histórico de endocardite bacteriana, cardiopatias congênitas cianóticas e shunts cirúrgicos<sup>100</sup> . O risco moderado abrange pessoas com malformações cardíacas congênitas acianóticas, disfunção valvar adquirida e insuficiência cardíaca congestiva<sup>105</sup> . Aqueles que não se enquadram nesses grupos são considerados de baixo risco. A profilaxia antibiótica tem se mostrado eficaz para reduzir o risco de endocardite infecciosa após procedimentos odontológicos em pacientes de alto risco, mas não oferece benefícios comprovados para indivíduos de risco moderado, baixo ou desconhecido<sup>106</sup> .  
Dessa forma, os procedimentos invasivos com previsão de sangramento requerem uma avaliação de risco antes de serem realizados. Tais procedimentos incluem exodontias, intervenções periodontais, colocação de implantes, tratamentos endodônticos, colocação de bandas ortodônticas, anestesia intraligamentar e limpeza profilática<sup>107</sup> .  
Conforme a condição odontológica e os procedimentos necessários, o indivíduo pode ser encaminhado ao Centro de Especialidade Odontológica (CEO), ao Serviço de Especialidades em Saúde Bucal (Sesb) ou a uma unidade de referência local. Antes desse encaminhamento, os profissionais da equipe de Saúde Bucal da APS devem realizar a adequação do meio bucal e fornecer ações de educação em saúde. Após o atendimento no CEO, Sesb ou unidade de referência local, é crucial que o profissional faça a contrarreferência para a equipe da APS, garantindo que  
31  
o indivíduo continue sendo acompanhado por uma equipe de Saúde Bucal. Isso assegura um cuidado integral e reforça o papel estratégico da APS como coordenadora do cuidado<sup>108</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **c. Tratamento medicamentoso** -->
A maioria dos pacientes com HAS precisarão associar o tratamento não medicamentoso ao tratamento medicamentoso<sup>30</sup> . Estudos mostram que redução de 10 mmHg na PAS ou de 5 mmHg na PAD está associada a decréscimos significativos em eventos cardiovasculares maiores (20%), mortalidade por todas as causas (10% a 15%), AVE (35%), eventos coronarianos (20%) e insuficiência cardíaca (40%)<sup>109,110</sup> .  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **i. Início da terapia medicamentosa** -->
De modo geral, o uso de medicamentos, em associação ou monoterapia, é a estratégia terapêutica preferencial para a maioria das pessoas com HAS, a despeito do grau da doença e do RCV<sup>6</sup> .  
Em pacientes com HAS grau 1 que tenham baixo RCV ou que sejam idosos frágeis, recomenda-se o tratamento em monoterapia e a alteração dos modos de vida para alcance da meta pressórica<sup>6</sup> . A classe medicamentosa a ser utilizada em monoterapia deve ser definida conforme avaliação da equipe de saúde e preferência do paciente. Todavia, as evidências sobre o início do tratamento medicamentoso para esta população são fracas, uma vez que estes perfis raramente são considerados nos estudos<sup>30</sup> .  
Considera-se idoso frágil ou em situação de fragilidade aquele que apresenta pelo menos um dos seguintes critérios: idade igual ou maior que 75 anos, vive em instituições de longa permanência para idosos (ILPI), encontra-se acamado, esteve hospitalizado recentemente por qualquer razão, apresente doenças sabidamente causadoras de incapacidade funcional – AVE, síndromes demenciais e outras doenças neurodegenerativas, etilismo, neoplasia terminal, amputações de membros –, encontra-se com pelo menos uma incapacidade funcional básica, ou viva situações de violência doméstica.  
Todos os pacientes com HAS de grau 1 de RCV moderado e alto ou que possuam lesões em órgão-alvo e aqueles com HAS graus 2 e 3, independentemente do RCV, devem iniciar o  
32  
tratamento medicamentoso com a combinação de dois medicamentos anti-hipertensivos com mecanismos de ação distintos, associado ao tratamento não medicamentoso<sup>6</sup> .  
Ainda, pacientes com PA normal alta (‘ _high normal’)_ , ou seja, que apresentem PAS entre 130 mmHg e 139 mmHg ou PAD entre 85 mmHg e 89 mmHg devem realizar avaliação do RCV e, conforme o caso, iniciar o tratamento medicamentoso em monoterapia associado ao tratamento não medicamentoso. A classe medicamentosa a ser utilizada em monoterapia deve ser definida conforme avaliação da equipe de saúde e preferência do paciente. Se seu RCV for alto ou muito alto, recomenda-se iniciar tratamento com anti-hipertensivo e estatina. Neste caso, a recomendação de iniciar prontamente o tratamento para controle pressórico se justifica por seu efeito protetor, associado a uma redução do risco de eventos cardiovasculares importantes, em especial, para pacientes de muito alto RCV<sup>30</sup> . Já se o RCV for baixo ou moderado, recomendase tratamento não medicamentoso. Em ambos os casos, o RCV e o controle pressórico do paciente devem ser reavaliados em 3 meses a 6 meses para decisão sobre o tratamento<sup>6</sup> .  
Todos os pacientes PA normal alta ou com diagnóstico da HAS, independente do grau da doença e do RCV, deverão passar por reavaliação periódica e individualizada, a fim de avaliar a meta pressórica, adesão aos tratamentos medicamentoso e não medicamentoso e manutenção ou adaptação ou intensificação do tratamento medicamentoso, de acordo com cada caso<sup>6</sup> .  
33  
A Erro! Fonte de referência não encontrada. descreve o fluxograma de tratamento dos pacientes com HAS e pressão normal alta.  
<!-- Start of picture text -->
Pessoas com idade maior ou igual a 18 anosem avaliac3o J<br>[naagao da pressdo atonal PA™ |<br>{<br>PAnormalalta<br>| { Hipertensiio. 1 Hipertensao 2) p<br>PAs30-1398589 PA'140-159700.99)orau Pe To0.170"100-109gray Hipertenstoison orau 3<br>mmo mn<br>eamesAvataglo 60 nco Seedapatmmo Sagmma| “Tatamento|  no<br>eee medicamentoso ‘medicamentoso<br>Teatemento Teatamento<br>came)isco isco isco cardiovascular |Risco cardiovascuta aciemertoeo+ mmedicamentoso+<br>.eine ou moderado (amet‘oumutto antea ‘eecemcnme) fgg\ smn Acompannamento a ‘Acompannamentoa<br>‘Tratamento<br>ii Tatamento|  no . eras15 nBo - ‘ratamentomedicamentoseJ no i Tatermesicamentoe9iom nas cada 3 meses ‘cada 3 meses:<br>‘camentoso medicamentoso em ‘Tratamento ‘Tratamento<br>—— medcamentoso modcomertteo<br>‘Acompannamantocote 30 8rraces ‘Acompannamonto‘mies0 oases ‘AcompannamentoSeomeses entre Acompanamentoaa omesee, a<br>—__, Fees<br>[ pmconotaae | [panto contotaae<br>eee:<br>5 atamonto com<br>‘olomo-em tee<br>ts<br>PetraaqdeTala er aoFetcarnieey aagnéetco pea a ava otisemoneconsutroos extol ou valores rows eauivalentes CDT GespareDs mondoriza¢Soewias owt anbulatril da pressSo atrial e mondozatloresdencal da prosslo aren<br><!-- End of picture text -->  
Figura 1. Fluxograma para definição do tratamento (não medicamentoso e medicamentoso) em pessoas com idade maior ou igual a 18 anos com diferentes níveis de pressão arterial medida em consultório.  
**Legenda:** PA: pressão arterial.  
**Fonte** : Traduzido e adaptado de _European Society of Hypertension_ (ESH) _Guidelines_ – Mancia et al. (2023)<sup>30</sup> , e Diretriz Brasileira de Hipertensão Arterial (HAS) - Barroso et al. (2021)<sup>6</sup> .  
34

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **ii. Definição do tratamento medicamentoso** -->
Preconiza-se que o tratamento medicamentoso seja baseado em cinco classes terapêuticas principais: inibidores da enzima conversora de angiotensina (IECA), bloqueadores do sistema renina angiotensina II (BRA), bloqueadores de canais de cálcio (BCC), diuréticos (por exemplo, tiazídicos e similares) e betabloqueadores (BB)<sup>13,26,28,109,111,112</sup> .  
Como os desfechos cardiovasculares maiores e mortalidade são similares entre estas cinco classes terapêuticas utilizadas no tratamento inicial, a escolha de qual delas será utilizada deve considerar a presença de comorbidades, raça/etnia, indicações e contraindicações conhecidas (Quadro 12), acesso, acessibilidade e preferências do paciente<sup>30</sup> .  
Quadro 12. Contraindicações que exigem uso cauteloso das classes terapêuticas antihipertensivas.  
|**Classe terapêu**|**tica**|**Contrain**|**dicação**|**Uso**<br>**cauteloso**<br>**nas**<br>**seguintes situações**|
|---|---|---|---|---|
|Bloqueadores<br>dos canais de<br>cálcio|Dihidropiridínicos<br>(por<br>exemplo,<br>besilato<br>de<br>anlodipino<br>e<br>nifedipino)|-||Taquiarritmia<br>Insuficiência<br>cardíaca<br>com fração de ejeção<br>reduzida, classe III ou IV<br>Edema de perna grave<br>prévio|
||Não<br>dihidropiridínicos<br>(por<br>exemplo,<br>cloridrato<br>de<br>verapamil)|Bloqueio<br>atrioventri<br>grau<br>Disfunção<br>esquerdo<br>(fração d<br>menor que<br>Bradicardi<br>cardíaca<br>batimento|sinoatrial<br>ou<br>cular de alto-<br>de ventrículo<br>(VE)<br>grave<br>e ejeção de VE<br>40%)<br>a<br>(frequência<br>menor que 60<br>spor minuto)|Constipação|
|Betabloqueado<br>atenolol, carve<br>tartarato de me<br>depropranolol)|res (por exemplo,<br>dilol, succinato ou<br>toprolol e cloridrato<br>|Asma grav<br>Bloqueio<br>atrioventri<br>grau|e<br>sinoatrial<br>ou<br>cular de alto-|Síndrome metabólica<br>Intolerância à glicose<br>Pacientes<br>atletas<br>e<br>fisicamente ativos|
|Bloqueadores<br>angiotensina<br>losartana potás|do<br>receptor<br>de<br>II (por exemplo,<br>sica)|Gravidez<br>Hipercale<br>potássio<br>mmol/L)<br>Estenose<br>bilateral|mia<br>(nível<br>de<br>maior que 5,5<br>arterial<br>renal|Mulher<br>em<br>idade<br>reprodutiva sem uso de<br>contracepção confiável|
|Diuréticos (tia<br>(por exemplo,|zídicos e similares)<br>hidroclorotiazida)|Gota||Síndrome metabólica<br>Intolerância à glicose<br>Gravidez<br>Hipercalcemia<br>Hipocalemia|
|Inibidores da<br>de angiotensi<br>captopril e mal|enzima conversora<br>na (por exemplo,<br>eato de enalapril)|Gravidez<br>Edema<br>prévio|angioneurótico|Mulher<br>em<br>idade<br>reprodutiva sem uso de<br>contracepção confiável|  
35  
|**Classe terapêutica**|**Contraindicação**||**Uso**<br>**seguin**|**cauteloso**<br>**tes situações**|**nas**|
|---|---|---|---|---|---|
||Hipercalemia<br>(nível<br>potássio acima de<br>mmol/L)|<br>de<br>5,5||||
||Estenose<br>arterial<br>bilateral|renal||||  
**Fonte:** Traduzido e adaptado de _European Society of Hypertension_ (ESH) _Guidelines_ – Mancia et al. (2023)<sup>30</sup> .  
O tratamento inicial deve incluir qualquer uma das classes terapêuticas, considerando-se  
que:  
- a associação de BB e outra classe terapêutica é uma alternativa para indivíduos com indicações específicas, tais como angina, pós-infarto agudo, insuficiência cardíaca, controle da frequência cardíaca ou cardiopatia isquêmica<sup>113</sup> ;  
- Até 10% dos pacientes tratados com IECA apresentam tosse persistente, sendo o risco maior em pessoas afrodescendentes<sup>14</sup> ;  
- IECA apresentam um pequeno risco de angiodema, sendo o maior risco em pessoas afrodescententes<sup>14</sup> ;  
- IECA/BRA são mais indicados em pacientes com proteinúria, diabete melito, insuficiência cardíaca ou doença renal<sup>6</sup> ;  
- diuréticos de alça são preferíveis em pacientes com doença renal ou insuficiência cardíaca<sup>6</sup> ;  
- os eventos adversos dos BRA (hipercalemia) são incomuns e melhor tolerados dos que os do IECA por pacientes afrodescendentes<sup>13,19,28</sup> .  
Diretrizes recentes recomendam o uso de diferentes classes de medicamentos como tratamento inicial em sua menor dose e, caso necessário, sua associação a outras classes terapêuticas até que o controle da PA seja alcançado, visando ao sucesso terapêutico, minimização de eventos adversos indesejáveis e abandono do tratamento. Essa estratégia é recomendada em detrimento do aumento da dose do medicamento em monoterapia ou troca por outro medicamento em monoterapia<sup>6,13,19,28</sup> .  
Este PCDT recomenda a associação entre classes medicamentosas, de forma individualizada, uma vez que a combinação fixa de benazepril associado a anlodipino (Portaria SECTICS/MS Nº 31, de 28 de junho de 2023) e a combinação fixa de losartana associada a hidroclorotiazida (Portaria SECTICS/MS Nº 32, de 28 de junho de 2023) foram avaliadas e, conforme recomendações desfavoráveis da Conitec, não foram incorporadas ao SUS.  
Se mesmo com a combinação das duas classes terapêuticas não houver alcance da meta terapêutica, então, deve-se aumentar gradualmente as doses prescritas até que o controle da PA seja alcançado, observando-se a dose máxima recomendada dos medicamentos. Se ainda assim o controle da PA não for alcançado, recomenda-se incluir uma terceira classe em sua dose mínima, aumentando-a gradualmente, caso não haja o controle da PA esperado, até a dose máxima. Embora as estratégias não sejam complexas e mostrem-se eficazes no contexto dos ensaios clínicos, estima-se que apenas 40% dos pacientes com HAS recebam terapia medicamentosa e destes, 35% controlam a PA<sup>13,114</sup> .  
No caso de falha de controle da PA, conforme metas terapêuticas estabelecidas, antes do acréscimo de dose ou classe terapêutica, deve-se sempre avaliar se houve adesão ao tratamento e se a combinação de tratamentos foi adequada antes de aumentar a dose do medicamento ou incluir  
36  
nova classe terapêutica<sup>13</sup> . Portanto, antes de definir falha terapêutica e a necessidade de intensificação do tratamento, sugere-se avaliar a adesão terapêutica em um mês de tratamento.  
A baixa adesão terapêutica pode estar relacionada à complexidade da terapia medicamentosa<sup>115,116</sup> . Já a insuficiência na combinação de tratamentos pode estar relacionada à continuidade do uso de medicamento em monoterapia a despeito do não controle da PA<sup>117,118</sup> . Especialmente nos casos de falha terapêutica, deve-se considerar a associação de mais classes de anti-hipertensivos<sup>17,18</sup> . Também deve-se preferir esquemas terapêuticos menos complexos, com menor número de comprimidos por dia e menor frequência de administração ao dia<sup>13,19</sup> .  
Para adultos e idosos não frágeis (sem declínio funcional estabelecido e sem incapacidades únicas ou múltiplas) com HAS grau 2 ou 3, o tratamento inicial deve envolver a associação de dois medicamentos por ser mais eficaz que a monoterapia em reduzir a PA<sup>119</sup> . Ainda, a terapia medicamentosa combinada pode ser especialmente valiosa quando a PA basal é igual ou maior que 20 mmHg /10 mmHg acima dos valores de PA estabelecidos como meta terapêutica<sup>19</sup> .  
No caso de pacientes com hipertensão arterial resistente, o uso de espironolactona ou outras classes terapêuticas, por exemplo, agonista alfa de ação central (metildopa), alfabloqueador (mesilato de doxazosina), vasodilatador direto e betabloqueador podem ser indicados, conforme seção ‘ _Indivíduos com hipertensão resistente_ ’<sup>119</sup> .  
Recomenda-se observar as orientações do PCDT das Dislipidemias vigentes para uso das estatinas, conforme RCV do paciente.  
As Figuras 2 e 3 sumarizam os algoritmos de tratamento, considerando, os diferentes graus da HAS, RCV e a presença ou ausência das principais comorbidades que alteram o tratamento da HAS; uma vez que esses fatores podem indicar a preferência por uso de medicamento em monoterapia ou em associação, e as diferenças na eficácia, efetividade e segurança dos pacientes.  
37  
<!-- Start of picture text -->
Pessoa com idade maior ou iguala 18 anos com diagnéstico de HAS<br>Sai Sim Consular algoritmo<br>DRC, > ra<br>ICFEr ou FA? aes<br>| Nao<br>Paciente com HAS grau 1 ey<br>e RCV baixo<br>ou<br>idosos frageis? ,<br>Monoterapia<br>Nao | :<br>Combinacao dupla: Nao Paciente<br>(IECA ou BRA) + (BCC <——_____allcancou meta<br>‘ou diurético)* terapéutica? °<br>| sim<br>sim= Paciente Nao" Manter<br>alcancou meta<br>terapéutica? °<br>Pact ‘Combinacao tripla:<br>| ressescease | (ECA ou+ diurético BRA)  >+ BCC<br>‘Sim Paciente Nao<br>alcancou meta<br>terapéutica? °<br>os Adicionar 4° farmaco:<br>alfa-bloqueador ou BB ou<br>tratamento espironolactona ou<br>hidratazina *°<br><!-- End of picture text -->  
Figura 1. Algoritmo de tratamento medicamentoso anti-hipertensivo na ausência de comorbidades.  
**Legenda:** BRA: bloqueador de receptor de angiotensina (losartana potássica); BB: betabloqueador (atenolol, carvedilol, metoprolol e cloridrato de propranolol); BCC: bloqueador de canal de cálcio (besilato de anlodipino, nifedipino e cloridrato de verapamil); Diurético (hidroclorotiazida); IECA: inibidor de enzima conversora de angiotensina (preferencialmente maleato de enalapril, exceto se indicado outro medicamento).  
**Notas:** a – Considerar betabloqueadores em qualquer etapa, quando existir uma indicação específica (por exemplo, angina, pós-infarto agudo do miocárdio ou mulher em idade reprodutiva ou planejando gravidez).  
b – A meta terapêutica é atingir pressão arterial inferior a 130 mmHg /80 mmHg. No caso de idosos frágeis, a meta deve ser flexível, idealmente, 140-149 mmHg /70-79 mmHg. Antes de definir a falha terapêutica e a necessidade de intensificação do tratamento, deve-se reforçar as orientações para adesão terapêutica e reavaliar o paciente após um mês de tratamento. c - Considerar encaminhamento a um cardiologista para maiores investigação.  
**Fonte:** Traduzido e adaptado de _European Society of Hypertension_ (ESH) _Guidelines_ – Mancia et al. (2023)<sup>30</sup> .  
38  
<!-- Start of picture text -->
Pessoa com age maior ova 218 aos com HAS endcagle de amentomedcamentoso<br>; Spree : Ss<br>[curren eS = [reams | =e)<br>reset vcaau(ECACombina¢éo ou a8) BRA)ou «arco dupla+ (BCC) eee,Combinacdo((ECA ou BRA) trpla+ ouCombinacaoeeeBRA+‘néio-DHP)"(BB dupia | ontaoa a"‘sim SsIdososties frageisou<br>azidico ou diurético de alga) "* BB +BCC<br>a | 4 1 on | |<br>Se.Paciente N30 sm BatePaciente Nao ‘sim fonsPacionte Nao! eeee RECAenese ORG,ror<br>‘cuban = ae<br>coaamas ro oa centerseeeeSntoa SeeFee| om oe<br>Passo (IECA ou BRA) + BCC Manter pully Manter GEGA.ou BRAYBE + OC: — torapéutica?* =Alii|<br>diurético de alga) °° de alga’ diurético tiazidico) Ne<br>‘Sim i ameter” conan wih<br>alcangouPacientemeta N30 ‘sim alcancouPacientemeta Nao. (BCC‘aumentar(peel ou diurético)terese tolerado,<br>peri<br>woke até dose plena °<br>_ == ‘anailsSeeepronoacona ou | Ee secamoe eeneee:anace PionmarriePaciente Sm | E=|<br><!-- End of picture text -->  
Figura 2. Algoritmo de tratamento medicamentoso anti-hipertensivo na presença de comorbidades.  
**Legenda** : BRA: bloqueador de receptor de angiotensina (losartana potássica); BB: betabloqueador (atenolol, carvedilol, metoprolol e cloridrato de propranolol); BCC: bloqueador de canal de cálcio; BCC não-DHP: BCC não dihidropiridínicos (cloridrato de verapamil e diltiazem); BCC-DHP: BCC dihidropiridínicos (besilato de anlodipino e nifedipino); Diurético (hidroclorotiazida); Diurético de alça (furosemida); IECA: inibidor de enzima conversora de angiotensina (captopril e maleato de enalapril). Notas:  
a – Doença renal crônica é definida como taxa de filtração glomerular estimada abaixo de 60 mL/min/1,73 m<sup>2</sup> com ou sem proteinúria. Uma redução na taxa de filtração glomerular estimada e aumento na creatinina sérica é esperada em pacientes com doença renal crônica que recebem terapia antihipertensiva, especialmente naqueles tratados com um IECA ou BRA. Em caso de aumento da creatinina sérica maior que 30%, deve ser prontamente avaliada a possibilidade de doença renovascular;  
39  
b – Considerar o uso de betabloqueadores em qualquer passo, quando existir uma indicação específica (por exemplo, insuficiência cardíaca, angina, pósinfarto agudo do miocárdio, fibrilação atrial ou mulher em idade reprodutiva ou planejando gravidez);  
- c – Uso de diuréticos de alça quando taxa de filtração glomerular estimada é menor que 30 mL/min/1,73 m<sup>2</sup> , uma vez que diuréticos tiazídicos ou similares são muito menos efetivos ou inefetivos quando taxa de filtração glomerular estimada é reduzida neste nível;  
- d – Atenção: risco de hipercalemia com espironolactona, especialmente quando a taxa de filtração glomerular estimada é menor que 45 mL/min/1,73 m<sup>2</sup> ou o nível de potássio basal é igual ou maior que 4,5 mmol/L;  
e – Quando a terapia anti-hipertensiva não é necessária, o tratamento deve ser prescrito de acordo com PCDT da Insuficiência Cardíaca com Fração de Ejeção Reduzida vigente;  
f – Diurético se refere a diurético tiazídico ou similar. Considerar diurético de alça como alternativa em pacientes com edema;  
g – Considerar o uso de anticoagulante oral quando indicado de acordo com o escore CHA2DS2-VASc*, a não ser quando o seu uso for contraindicado; h – Associação de betabloqueadores e bloqueadores de canais de cálcio não dihidropiridínico (por exemplo, cloridrato de verapamil) não é recomendada devido à potencial redução acentuada na frequência cardíaca;  
i - Avaliar adesão terapêutica em um mês de tratamento antes de definir falha terapêutica e necessidade de intensificação do tratamento.  
**Nota explicativa:** *O escore CHA2DS2-VASc é usado para avaliar o risco de acidente vascular cerebral em pacientes com fibrilação atrial, ajudando a determinar a necessidade de anticoagulação para prevenir eventos tromboembólicos.  
**Fonte:** Traduzido e adaptado de European Society of Hypertension (ESH) Guidelines – Mancia et al. (2023)<sup>30</sup> e Diretriz de Hipertensão Arterial Sistêmica da Sociedade Brasileira de Cardiologia Barroso et al. (2021)<sup>6</sup> .  
40  
O Quadro 13 apresenta os medicamentos disponíveis no Sistema Único de Saúde, conforme suas classes terapêuticas.  
Quadro 13. Medicamentos disponíveis no SUS para tratamento da hipertensão arterial sistêmica, segundo classe terapêutica.  
|**Classe T**|**erapêutica**|**Medicamentos**|
|---|---|---|
|Alfa-agonista|de ação central<sup>a</sup>|Metildopa|
|Alfa-bl|oqueador<sup>a</sup>|Mesilato de doxazosina|
|Betabloq|ueadores<sup>b, e</sup>|Atenolol; carvedilol; succinato de<br>metoprolol; tartarato de metoprolol;<br>cloridrato depropranolol|
|Bloqueador do recep|tor de angiotensina II<sup>b</sup>|Losartanapotássica|
|Bloqueadores dos|Dihidropiridínico|Besilato de anlodipino;nifedipino|
|canais de cálcio<br>(BCC)<sup>b</sup>|Não dihidropiridínico<br>c|Cloridrato de verapamil|
|Diurétic|o de alça<sup>d</sup>|Furosemida|
|Diuréticopoup|ador depotássio<sup>a</sup>|Espironolactona|
|Diuréticos tiazí|dicos e similares<sup>b</sup>|Hidroclorotiazida|
|Inibidores da enz<br>angiot|ima conversora de<br>ensina<sup>b, e</sup>|Maleato de enalapril; Captopril;|
|Vasodilat|ador direto<sup>a</sup>|Cloridrato de hidralazina|  
**Notas** : a – Opções a serem consideradas no caso de hipertensão resistente; b – Uma das cinco classes terapêuticas mais usuais no tratamento da hipertensão nos passos 1 a 3 no adulto segundo algoritmos de tratamento; c - Opção a ser considerada no caso de hipertensão e fibrilação atrial; d – Opção a ser considerada no caso de hipertensão e doença renal crônica ou insuficiência cardíaca; e – Opções a serem consideradas no caso de hipertensão e insuficiência cardíaca.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **iii. Classes terapêuticas** -->
Ao abordar diferentes classes terapêuticas, é crucial que o profissional de saúde esteja atento aos possíveis eventos adversos que podem surgir durante o tratamento. Monitorar esses eventos é fundamental, pois podem ser um fator significativo para a não adesão ao tratamento.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.1. Bloqueador do receptor de angiotensina II -->
Os BRA reduzem a PA por antagonizar a ação vasoconstritora da angiotensina II. Seus eventos adversos incluem: alterações transitórias da função renal (aumento dos níveis de ureia e creatinina sérica), hipercalemia, especialmente na presença de insuficiência renal, e mais raramente, exantema. O seu uso é contraindicado em gestantes devido ao risco de complicações fetais<sup>6</sup> assim como em pacientes que já estejam em uso de IECA ou com história de angioedema 6,28. Em monoterapia, não devem ser a primeira escolha para afrodescendentes.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.2. Bloqueadores dos canais de cálcio -->
Os bloqueadores dos canais de cálcio atuam nas células musculares lisas das arteríolas, reduzindo a disponibilidade de cálcio intracelular, dificultando a contração muscular e, desta forma, diminuindo a resistência vascular periférica por vasodilatação. Os BCC são classificados em dois tipos: dihidropiridínicos (que incluem o besilato de anlodipino e nifedipino) e não  
41  
dihidropiridínico (que incluem o cloridrato de verapamil). Comparados aos não dihidropiridínicos, os BCC dihidropiridínicos são mais frequentemente usados como antihipertensivos, pois têm mínima interferência na frequência cardíaca e na função sistólica. De forma geral, os BCC, especialmente os não dihidropiridínicos, devem ser evitados em pacientes com disfunção miocárdica ou insuficiência cardíaca<sup>6,28</sup> . Ainda, é preferível o uso de BCC não dihidropiridínicos em pacientes com HAS e fibrilação atrial<sup>6</sup> . Os principais eventos adversos dessa classe são dose-dependentes e incluem o edema maleolar, a cefaleia latejante, a constipação e as tonturas<sup>6,28</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.3. Diuréticos -->
Os diuréticos têm ação anti-hipertensiva, principalmente, devido à redução do volume circulante e extracelular. Deve-se utilizar, preferencialmente, diuréticos tiazídicos (hidroclorotiazida). Já os diuréticos de alça (furosemida) devem ser utilizados por pacientes com doença renal (TFGe abaixo de 30 mL/min/1,73 m<sup>2</sup> ) ou com edema por insuficiência cardíaca. Ainda, os diuréticos poupadores de potássio (espironolactona) devem ser utilizados em pacientes com HAR<sup>6,28</sup> .  
Os principais eventos adversos dos diuréticos são fraqueza, cãibras, hipovolemia e disfunção erétil. No entanto, seu uso em doses baixas diminui o risco destes eventos, sem prejudicar a efetividade do tratamento<sup>6,28</sup> .  
Pacientes em uso de diuréticos tiazídicos devem ser monitorados quanto à hiponatremia, à hipocalemia e aos níveis de ácido úrico e cálcio. Pacientes com história de gota devem evitar o uso de diuréticos tiazídicos, a menos que também estejam em terapia para redução de ácido úrico 6,28.  
Destaca-se que a incorporação da clortalidona foi avaliada e, conforme recomendação desfavorável da Conitec, não foi incorporado ao SUS (Portaria SECTICS/MS Nº 33, de 28 de junho de 2023).

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.4. Inibidores da enzima conversora de angiotensina -->
Os medicamentos desta classe apresentam ação anti-hipertensiva por inibir a conversão de angiotensina I em II, a qual possui ação vasoconstritora, além de reduzir a degradação da bradicinina, cuja ação é vasodilatadora. Além disso, seu uso pode beneficiar pacientes com insuficiência cardíaca, doença renal por diabete ou de outras etiologias ou após infarto agudo do miocárdio<sup>6</sup> .  
A tosse seca é o evento adverso mais comum dos IECA. A piora da função renal, em geral, é transitória. No entanto, deve-se interromper o uso do medicamento e investigar caso a piora seja importante (acima de 30% de elevação do nível de ureia e creatinina séricas). Outros eventos relevantes são a hiperpotassemia, em pacientes com insuficiência renal; o edema angioneurótico e as erupções cutâneas, apesar de raras. O uso de IECA é contraindicado em gestantes pelo risco de complicações fetais<sup>6</sup> assim como em pacientes que já estejam em uso de BRA ou possuam história de angioedema. Em monoterapia, não devem ser a primeira escolha para afrodescendentes.  
A incorporação do benazepril<sup>120</sup> foi avaliada pela Conitec, com decisão final de não incorporação (Portaria SECTICS/MS Nº 35, de 28 de junho de 2023).  
42

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.5. Betabloqueadores -->
Alguns dos efeitos mais relevantes dos BB são a diminuição do débito cardíaco e da secreção de renina. Podem ser não seletivos (por exemplo, cloridrato de propranolol), cardiosseletivos (por exemplo, atenolol e metoprolol) e com ação vasodilatadora (por exemplo, carvedilol).  
Comparativamente a outras classes terapêuticas de anti-hipertensivos, os BB aumentam o risco de AVE. Por isso, devem ser utilizados em casos específicos, como pacientes com angina, pós-infarto agudo, insuficiência cardíaca, cardiopatia isquêmica ou para controle da frequência cardíaca, ou mulher em idade reprodutiva ou planejando gravidez<sup>6</sup> . Portanto, exceto nesses casos específicos, os BB não devem ser utilizados como tratamento inicial da HAS<sup>28</sup> .  
Os eventos adversos do uso de BB incluem: broncoespasmo, bradicardia, distúrbios da condução atrioventricular, vasoconstrição periférica, insônia, pesadelos, depressão, astenia e disfunção sexual. Podem contribuir para a intolerância à glicose (exceto BB de terceira geração, como carvedilol), hipertrigliceridemia, elevação dos níveis de LDL e redução dos níveis de lipoproteína de alta densidade (colesterol-HDL). Além disso, BB são contraindicados em pacientes com asma, doença pulmonar obstrutiva crônica e bloqueio atrioventricular de segundo e terceiro graus<sup>6</sup> . Deve-se evitar a interrupção abrupta do uso dessa classe de medicamentos<sup>28</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.6. Outras classes terapêuticas -->
Outras classes terapêuticas, como os agonistas alfa de ação central, alfa-bloqueadores e vasodilatadores diretos são menos usuais no tratamento da HAS. Contudo, seu uso ainda é relevante, especialmente nos casos de HAR ou durante a gestação<sup>6</sup> .  
O Quadro 14 apresenta os principais eventos adversos dessas classes de medicamentos.  
Quadro 14. Principais eventos adversos dos agonistas alfa de ação central, alfa-bloqueadores e vasodilatadores diretos.  
|**Classe terapêutica**|**Medicamento**<br>**disponível no SUS**|**Principais eventos adversos**|
|---|---|---|
|Agonistas alfa<br>(simpatolíticos) de<br>ação central|Metildopa|Febre, anemia hemolítica, galactorreia e<br>disfunção hepática|
|Alfa-bloqueadores|Mesilato de<br>doxazosina|Hipotensão postural e incontinência<br>urinária e aumento da incidência de<br>insuficiência cardíaca|
|Vasodilatadores<br>diretos|Cloridrato de<br>hidralazina|Cefaleia,_flushing_, taquicardia reflexa e<br>reação_lupus-like_|  
**Fonte** : Adaptado de Whelton et al. 2018 e Barroso et al. 2021<sup>6,28</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.1. Indivíduos com hipertensão arterial resistente -->
Adequar a prescrição medicamentosa e aumentar a adesão ao tratamento não medicamentoso e multidisciplinar podem melhorar o controle pressórico. Além de reforçar o tratamento não medicamentoso, as evidências apontam que a espironolactona, um diurético que  
43  
age como antagonista da aldosterona, deve ser a quarta classe terapêutica preferencial no tratamento anti-hipertensivo<sup>121,122</sup> .  Contudo, deve ser dada atenção ao uso da espironolactona em pacientes com DRC, pelo risco potencial da hipercalemia.  
Outras opções, como os agonistas alfa-2 adrenérgicos, alfa-bloqueadores e BB podem ser consideradas<sup>123,124</sup> . A decisão sobre a classe terapêutica a ser utilizada pelo paciente deve considerar a presença de comorbidades e eventos adversos prévios, conforme algoritmos de tratamento.  
No contexto da APS, a forte suspeita de um paciente com HAR é um critério para encaminhá-lo à investigação de causas secundárias da HAS.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.2. Indivíduos em crise hipertensiva -->
A APS desempenha um papel fundamental na prevenção, identificação precoce e cuidado inicial das crises hipertensivas. As principais ações incluem: monitoramento regular, por meio de avaliações periódicas da PA em pacientes com histórico de hipertensão, permitindo a detecção precoce de elevações pressóricas; controle inicial ao identificar e tratar condições que podem precipitar uma crise hipertensiva, como desidratação, e a falta de adesão ao tratamento; tratamento medicamentoso, com início ou ajuste da terapia anti-hipertensiva, conforme necessário<sup>16</sup> .  
O encaminhamento para serviços de urgência e emergência é recomendado quando são necessários tratamento intravenoso e monitorização contínua, em caso de PAS ≥ 180 mmHg e PAD ≥ 120 mmHg, mesmo após a administração de medicamentos, ou se o paciente apresentar sinais ou sintomas de lesão aguda em órgão alvo<sup>16</sup> .  
Apesar de não haver evidências de ensaios clínicos randomizados avaliando as diferentes estratégias de tratamento para emergências hipertensivas<sup>6,13,26</sup> , exceto para o AVE, a experiência clínica e a evolução dos pacientes tratados indicam que esta condição requer intervenção imediata. Geralmente, são utilizados medicamentos administrados por via intravenosa 6,13,26, preferencialmente em UTI<sup>6,36</sup> , para evitar a falência orgânica progressiva.  
A PA deve ser reduzida gradualmente, em minutos a horas, a valores-alvo não muito baixos, pois a redução muito rápida e intensa da PA está associada à isquemia em leitos vasculares habituados a níveis pressóricos mais altos (autorregulação), podendo ocasionar eventos isquêmicos como AVE, infarto agudo do miocárdio ou cegueira<sup>6,13,26.</sup> Desse modo, as recomendações gerais de redução da PA em EH devem ser:  
- PA média ≤ 25% na 1ª hora;  
- PA 160 mmHg /100 mmHg - 110 mmHg nas primeiras 2 horas a 6 horas;  
- PA 135 mmHg /85 mmHg em um período de 24 horas a 48 horas subsequentes.  
Vale ressaltar ainda que, as emergências hipertensivas não são definidas pelo nível de elevação da PA, mas comumente pelo estado clínico do paciente, podendo manifestar-se como um evento cardiovascular, cerebrovascular, renal ou com envolvimento de múltiplos órgãos ou mesmo na forma de pré-eclâmpsia com sinais de gravidade ou eclâmpsia. Nesse contexto, devem ser abordadas considerando o sistema ou o órgão-alvo acometido.  
Sendo assim, as principais emergências hipertensivas são descritas no Quadro 15:  
44  
Quadro 15. Principais eventos adversos dos agonistas alfa de ação central, alfa-bloqueadores e vasodilatadores diretos.  
Cerebrovasculares  
Encefalopatia hipertensiva Acidente vascular encefálico isquêmico Acidente vascular encefálico hemorrágico Hemorragia subaracnoidea  
Cardiocirculatórias  
Dissecção aguda da aorta  
Edema agudo de pulmão com insuficiência ventricular esquerda  
Síndromes coronarianas agudas  
Renais/ comprometimento de múltiplos órgãos  
Hipertensão acelerada/maligna Hipertensão com múltiplos danos aos órgãos-alvo Crises adrenérgicas graves  
Crise do feocromocitoma  
Dose excessiva de drogas ilícitas (cocaína, _crack_ , LSD)  
Hipertensão na gestação  
Eclâmpsia  
Pré-eclâmpsia com sinais de gravidade  
Síndrome “HELLP” hemolysis, elevated liver enzymes, low platelets  
Hipertensão grave em final de gestação  
O tratamento da emergência hipertensiva, incluindo a seleção do anti-hipertensivo e o alvo da PA, é determinado pela condição associada<sup>6</sup> . No Brasil, eles podem não estar elencados na Relação Nacional de Medicamentos Essenciais (Rename), uma vez que correspondem ao contexto de emergência e ambiente hospitalar. Sendo assim, cabe aos serviços de saúde a sua seleção e disponibilização, segundo protocolos assistenciais estabelecidos localmente. Nitroprussiato (ou nitroprusseto) de sódio é indicado na maioria das emergências hipertensivas<sup>6</sup> . As condutas gerais em caso de emergências hipertensivas são:  
 AVE isquêmico (85% dos AVE): a PA deve ser reduzida na fase aguda apenas se estiver igual ou acima de 185 mmHg/110 mmHg em candidatos à terapia trombolítica, ou igual ou acima de 220 mmHg/120 mmHg nos indivíduos não candidatos à terapia trombolítica; no último grupo, a redução da PA deve ser de 15% a 25%<sup>6,26</sup> . A PA deve ser mantida nesse nível durante as primeiras 24 horas.  
45  
- AVE hemorrágico (15% dos AVE): a PAS deve ser reduzida para menos de 180 mmHg, mas não menos de 140 mmHg, na fase hiperaguda (primeiras 24 horas). Se a PAS estiver maior que 220 mmHg, essa redução deve ser gradual<sup>6</sup> .  
- Traumatismo cranioencefálico: o aumento da PA é tratado apenas se a pressão de perfusão cerebral (PA média menos pressão intracraniana) for maior que 120 mmHg e a pressão intracraniana for maior que 20 mmHg. Contudo, deve haver extrema cautela na intensidade da redução<sup>36</sup> .  
- Encefalopatia hipertensiva: a PAS deve ser reduzida em não mais de 20% a 25% e a PAD em não menos de 100 mmHg a 110 mmHg na primeira hora de tratamento<sup>6</sup> . Posteriormente, o alvo da PAS deve ser 160 mmHg e da PAD deve ser entre 90 mmHg e 100 mmHg.  
- Síndromes coronarianas agudas:  recomenda-se uma redução da PA em 20% nas primeiras duas horas, com um alvo subsequente de 120 mmHg /70 mmHg a 160 mmHg/100 mmHg<sup>6</sup> . Os betabloqueadores não devem ser utilizados se houver sinais de insuficiência cardíaca<sup>6</sup> .  
- Insuficiência cardíaca aguda com edema agudo de pulmão: é recomendável administrar diuréticos de alça e um vasodilatador de fácil titulação<sup>36,125</sup> . Medicamentos que aumentem o trabalho cardíaco, como cloridrato de hidralazina, ou que diminuem a contratilidade cardíaca, como BB, devem ser evitados. A PAS deve ser reduzida gradativamente até menos de 140 mmHg<sup>6,13,26</sup> .  
- Dissecção aórtica aguda: a PAS deve ser rapidamente reduzida, em 20 minutos a 60 minutos, até atingir o alvo de 100 mmHg a 120 mmHg, para reduzir as forças de cisalhamento aórtico<sup>36,125</sup> . Pode ser utilizado inicialmente um BB (cloridrato de propranolol ou metoprolol) para uma redução da frequência cardíaca até menos de 60 batimentos por minuto, seguido por um vasodilatador<sup>36,125</sup> . Para pacientes com contraindicação ao uso de BB (como os asmáticos), uma alternativa é o cloridrato de verapamil (BCC não dihidropínico)<sup>6</sup> .  
- Hiperatividade simpática (feocromocitoma, abuso de _crack_ , cocaína ou derivados anfetamínicos, abstinência de clonidina ou betabloqueadores): reduzir a PAS a menos de 140 mmHg na primeira hora, nos pacientes com feocromocitoma, e em 20% em duas a três horas para as demais condições<sup>36</sup> . Opções de tratamento incluem cloridrato de verapamil podendo ser adicionado benzodiazepínico. Deve-se evitar o uso de BB devido à possibilidade de indução de estímulo alfa e aumento da PA<sup>6,36</sup> .  
- Emergências hipertensivas da gestação: os medicamentos de primeira escolha no tratamento da crise hipertensiva são o nifedipino por via oral ou a hidralazina por via intravenosa. Tanto o nifedipino (10 mg) como a hidralazina (5 mg), devem ser repetidos a intervalos de 20 a 30 minutos enquanto a pressão arterial se mantiver acima de 160 mmHg ou 110 mmHg, até uma dose total de 30 mg. A monitoração fetal deve ser feita durante o tratamento da crise hipertensiva e se houver hipotensão arterial com desaceleração ou bradicardia fetal, manter a gestante em decúbito lateral esquerdo e aumentar a infusão de soro fisiológico. Visando à prevenção de desfechos adversos, pode-se indicar o uso de sulfato de magnésio (MgSO4) mesmo em gestantes assintomáticas, quando forem removidas para centros de referência.  
O monitoramento de PA intra-arterial deve ser considerado em pacientes com manifestações clínicas graves ou PA lábil<sup>36</sup> . Após um período adequado de controle da PA na UTI, geralmente de 8 horas a 24 horas, conforme o alvo definido para a condição associada, a terapia medicamentosa por via intravenosa pode ser substituída pela via oral<sup>36</sup> .  
46  
O tratamento da urgência hipertensiva é a retirada de seu fator desencadeante. Deve-se iniciar com um período de observação em ambiente calmo, com o uso de analgésicos e tranquilizantes se necessário<sup>6</sup> , o que por si só pode reduzir a PA<sup>13</sup> . Não há evidência de benefícios na redução rápida da pressão em pacientes com HAS grave assintomática, e há riscos de complicações isquêmicas, como AVE, infarto agudo do miocárdio, cegueira e dano renal<sup>36,125</sup> . Na ausência de estudos de boa qualidade avaliando o melhor cuidado para o paciente com HAS grave assintomática, geralmente se recomenda a redução gradual da PA com anti-hipertensivos por via oral num período de 24 horas a 48 horas, que pode ser estendido para alguns poucos dias, especialmente em idosos<sup>6,13,35</sup> .  
Pacientes com urgência hipertensiva e risco de eventos cardiovasculares iminentes pela PA muito elevada, como aqueles com diagnóstico prévio de aneurisma aórtico ou cerebral, devem ter sua PA reduzida em um período de horas<sup>36</sup> por meio do uso de medicamentos por via oral. Podem ser utilizados agentes de curta ação, como captopril 25 mg (se não houver sobrecarga de volume), cujo pico de ação ocorre em 60 minutos a 90 minutos.  
No entanto, uma estratégia superior é o tratamento de longo prazo, com seguimento ambulatorial em 24 horas a 48 horas em indivíduos com diagnóstico prévio da HAS, visando a uma redução da PA para 160 mmHg/95 mmHg ou menos em até 48 horas<sup>36</sup> . Caso não apresentem diagnóstico prévio da HAS, podem utilizar captopril por via oral (observar que não é via sublingual), com orientação de consultarem seu médico da APS para avaliar se são hipertensos ou apenas apresentaram uma pseudocrise hipertensiva. Em caso de pseudocrise hipertensiva, também podem ser utilizados ansiolíticos, como benzodiazepínicos<sup>36</sup> , de forma aguda, se necessário, ou outras medidas, conforme a etiologia da urgência hipertensiva. Nos casos de urgência hipertensiva sem risco de eventos cardiovasculares iminentes e pseudocrise hipertensiva, os pacientes devem permanecer algumas horas em observação no serviço de saúde e, caso permaneçam assintomáticos e apresentem redução da PA, podem ser liberados para retorno ao domicílio.  
Todos os pacientes atendidos com emergência hipertensiva necessitam retornar para consulta ambulatorial em sete dias para avaliar se a PA se manteve controlada com o tratamento estabelecido, otimizar seu tratamento e reforçar a manutenção do acompanhamento no serviço de saúde e a adesão ao tratamento<sup>13,18,35,126</sup> . Os casos de emergência hipertensiva podem necessitar de acompanhamento com um especialista da área relacionada ao fator desencadeante<sup>30,36</sup> . No caso de urgência hipertensiva, o retorno deve ser com o médico da APS, que deve manter o cuidado longitudinal e acompanhar o desenvolvimento do quadro em conjunto com a atenção especializada<sup>36</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.3. Crianças e adolescentes -->
Hábitos de vida saudáveis devem ser instituídos para crianças e adolescentes<sup>26</sup> **.** Ainda, quando adequado, devem ser adotados mudanças no modo de vida, como:  
- Redução de peso corporal, com manutenção do IMC entre o z-score +1 e -1 ou abaixo do percentil 95 (Material Suplementar 1);  
- Realização de 60 minutos ou mais de atividade física por dia, de intensidade moderada à vigorosa. Pelo menos 3 dias na semana é recomendado incluir atividades de fortalecimento dos músculos e ossos, de forma lúdica e que considere as preferências e gostos dessa população-alvo<sup>75</sup> ;  
47  
- Diminuição do tempo em comportamento sedentário diário, ou seja, o tempo que se passa sentado ou deitado assistindo à televisão ou usando o celular, computador, tablet ou videogame;  
- Controle do estresse;  
- Adoção de uma alimentação adequada e saudável. Essa medida, devendo restringir o consumo de sódio, é especialmente eficaz na HAS associada à obesidade<sup>6</sup> . A dieta DASH pode ser adotada, com ênfase no aumento do consumo de alimentos de origem vegetal e na redução da ingestão de açúcares, doces e alimentos ultraprocessados. É importante garantir a participação da família nessa estratégia<sup>127</sup> .  
O tratamento medicamentoso é indicado para crianças e adolescentes nas seguintes situações<sup>127</sup> :  
- Manutenção da HAS grau 1, apesar de mudanças dos modos de vida;  
- HAS sintomática;  
- HAS grau 2;  
- Lesão em órgão-alvo;  
- Presença de doença renal crônica; e  
- Presença de Diabete Melito tipo 1 ou tipo 2.  
O tratamento deve ser iniciado com a menor dose do medicamento anti-hipertensivo. A dose do medicamento deve ser aumentada a cada duas a quatro semanas, até se atingir o alvo terapêutico adequado (por exemplo, abaixo do percentil 90 – Material Suplementar 1)<sup>127</sup> .  
Os medicamentos recomendados como tratamento em monoterapia para crianças e adolescentes sem hipertensão arterial secundária são IECA, BRA e BCC. O uso de BB não é recomendado como primeira linha em crianças e adolescentes com asma ou diabete<sup>127</sup> . Caso seja necessário combinar um segundo anti-hipertensivo, recomenda-se considerar um diurético tiazídico; e na necessidade de um terceiro anti-hipertensivo, recomendam-se alfa-bloqueadores, BB simpatolíticos de ação central ou diuréticos poupadores de potássio<sup>6</sup> .  
A escolha do tratamento medicamentoso para a hipertensão arterial secundária deve ser feita em consonância com o princípio fisiopatológico envolvido, considerando as comorbidades presentes em cada caso<sup>128</sup> .  
Em caso de não resposta à monoterapia por mais de seis meses, deve-se considerar o encaminhamento à Atenção Especializada<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.4. Gestantes -->
Os distúrbios hipertensivos na gestação são uma das principais causas de mortalidade materna e perinatal em todo o mundo. A HAS na gestação é caracterizada por PAS ≥ 140 mmHg ou PAD ≥ 90 mmHg, enquanto a hipertensão gestacional grave é definida por PAS ≥ 160 mmHg ou PAD ≥ 110 mmHg, também com medições em duas ocasiões e intervalo de pelo menos quatro horas<sup>6</sup> .  
Na decisão de iniciar terapêutica anti-hipertensiva, são fatores principais o valor da pressão arterial e a presença de sinais e sintomas associados. Gestantes com diagnóstico da HAS toleram valores elevados de pressão arterial, sem apresentar manifestações clínicas. Ao contrário, gestantes jovens, com valores de pressão arterial anteriores considerados baixos, podem evoluir  
48  
para quadros graves e para eclâmpsia, apesar de valores pouco alterados da pressão arterial. Todas as gestantes que manifestarem hipertensão arterial persistente (PAS ≥ 140 mmHg ou PAD ≥ 90 mmHg) devem receber tratamento com anti-hipertensivos, tendo como objetivo manter os valores da PAD em torno de 85 mmHg<sup>129</sup> .  
O início do tratamento medicamentoso em gestantes com HAS abaixo de 160 mmHg/110 mmHg ainda é controverso, exceto quando as gestantes apresentam lesão de órgão-alvo<sup>6</sup> . Uma revisão sistemática mostrou que tratar a HAS leve a moderada não reduz significativamente a morbidade materna, fetal e do recém-nascido<sup>130</sup> . O uso de BB e BCC foi mais eficaz do que o de metildopa para a prevenção da HAS grave, em que pese a metildopa ter sido o terceiro medicamento de escolha a ser utilizado<sup>130,131</sup> . Outros medicamentos disponíveis no SUS indicados para gestantes são diuréticos tiazídicos (hidroclorotiazida) e cloridrato de hidralazina (Quadro 16).  
Quadro 16. Anti-hipertensivos recomendados para uso na gestação.  
|**Classe terapêutica**|**Medicamento**|**Posologia**|
|---|---|---|
|Agonistas alfa<br>(simpatolíticos) de<br>ação central|Metildopa<br>Comprimido de 250 mg|750 mg a 2.000 mg/dia, divididos em 2 a 4<br>administrações|
|Bloqueadores de|Nifedipino<br>Comprimidos de 10 mg|20 mg a 60 mg/dia, divididos em 2 a 3<br>administrações**ou**<br>20 mg a 120 mg/dia, divididos em 1 a 3<br>administrações|
|canais de cálcio|Besilato de anlodipino<br>Comprimido 5 mg e 10<br>mg|5 mg a 20 mg/dia, divididos em 1 a 2<br>administrações**ou**<br>20 mg a 60 mg/dia, dividido em 2 a 3<br>vezes administrações|
|Vasodilatador<br>periférico|Cloridrato de hidralazina<br>Comprimidos de 25 mg e<br>50 mg|50 mg a 150 mg/dia, dividido em 2 a 3<br>administrações|
||Metoprolol<br>Comprimidos de 25 mg,<br>50 mg e 100 mg|100 mg a 200 mg/dia, dividido em 1 a 2<br>administrações|
|Beta-bloqueadores|Carvedilol<br>Comprimidos de 6,25 mg<br>e 12,5 mg|12,5 mg a 50 mg/dia, divididos em 1 a 2<br>administrações<br>Recomenda-se iniciar com 12,5 mg/dia por<br>2 dias e, a partir de então, aumentar a dose|  
**Fonte:** Adaptado de PERAÇOLI, 2020. Brasil. Ministério da Saúde. Manual de gestação de alto risco [recurso eletrônico], 2022<sup>38</sup> .  
O tratamento para emergência hipertensiva na gestante pode ser feito tanto com nifedipino 10 mg por via oral ou cloridrato de hidralazina por via intravenosa. Se o controle não for adequado, pode-se adicionar outro medicamento de primeira linha ou de segunda linha, como diurético tiazídico, clonidina ou cloridrato de hidralazina, evitando combinações dentro da mesma classe<sup>6</sup> .  
49  
Os medicamentos recomendados para o tratamento da crise ou emergência hipertensiva em gestantes são indicados no Quadro 17.  
Quadro 17. Anti-hipertensivos recomendados para uso na crise ou emergência hipertensiva em gestantes.  
|**Medicamentos**|**Orientações**|
|---|---|
|Cloridrato<br>de<br>hidralazina<br>Solução injetável de<br>20 mg/mL|A ampola de cloridrato de hidralazina contém 1 mL, na concentração de<br>20 mg/mL. Diluir uma ampola (1 mL) em 19 mL de água destilada, para<br>obter a concentração de 1 mg/mL.<br>Dose inicial: 5 mg, via intravenosa<br>Repetir, se necessário: 5 mg a cada 20 minutos<br>Dose máxima: 30 mg|
|Nifedipino<br>Comprimido de 10<br>mg|Dose inicial: 10 mg, via oral<br>Repetir, se necessário: 10 mg a cada 20 a 30 minutos (via oral)<br>Dose máxima: 30 mg|
|Nitroprussiato<br>de<br>sódio<br>Solução injetável 50<br>mg/2 mL|A ampola de nitroprussiato de sódio contém 2 mL, na concentração de<br>50mg/2 ml. Diluir uma ampola (2 mL) em 248 mL de soro glicosado<br>5%, assim teremos a para obter a concentração de 200 mcg/mlL<br>Dose inicial: o,5 mcg a 10 mcg/kg/min, infusão intravenosa contínua|  
**Fonte:** PERAÇOLI, 2020. Brasil. Ministério da Saúde. Manual de gestação de alto risco [recurso eletrônico], 2022<sup>38</sup> .  
O sulfato de magnésio é o anticonvulsivante de escolha a ser administrado quando há risco de convulsão, situação inerente aos quadros de pré-eclâmpsia com sinais de deterioração clínica ou laboratorial, iminência de eclâmpsia, eclâmpsia, síndrome HELLP e hipertensão de difícil controle. Caso a paciente apresente PAS ≥ 160 mmHg ou PAD ≥ 110 mmHg, **mesmo na ausência de sintomas** , há indicação de profilaxia de convulsão com sulfato de magnésio<sup>38</sup> .  
São formalmente contraindicados na gestação os seguintes medicamentos<sup>6</sup> :  
- IECA, BRA e antagonistas dos receptores de mineralocorticoides, devido ao risco de malformação fetal;  
- atenolol, devido ao alto risco de restrição de crescimento fetal;  
- Evitar o uso de diuréticos em pacientes com HAS pré-existente, pois podem agravar a depleção do volume intravascular.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.5. Puérperas -->
A HAS no puerpério deve ser considerada, de forma a evitar desfechos graves. O uso de anti-hipertensivos durante a amamentação pode trazer malefícios para os bebês, caso sejam excretados no leite materno a ponto de causar hipoglicemia, hipotermia, hipotensão e bradicardia. Contudo, de forma geral, constatou-se que os benefícios da amamentação superam os riscos para o bebê amamentado pela mãe que faz uso de anti-hipertensivos<sup>131</sup> .  
Lactantes podem utilizar nifedipino, IECA, hidroclotiazida, espironolactona, metoprolol, cloridrato de propranolol, cloridrato de hidralazina e metildopa, uma vez que a sua excreção no  
50  
leite materno é muito baixa<sup>6</sup> . Em puérperas, recomenda-se priorizar o uso de nifedipino (ou besilato de anlodipino para mulheres que já fizerem seu uso)<sup>131</sup> . O uso de clonidina e atenolol é contraindicado devido à grande excreção no leite, assim como o uso de BRA devido à ausência de estudos suficientes para aprová-lo em lactantes<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 1.1.1.6. População preta -->
Estudos demonstram que pessoas adultas pretas hipertensas tendem a ter menor resposta à monoterapia com IECA ou BRA, medicamentos que atuam na via renina-angiotensinaaldosterona<sup>132</sup> . Por essa razão, as diretrizes sugerem priorizar outras classes de anti-hipertensivos em vez de IECA ou BRA como medicamentos de primeira escolha em monoterapia para esse grupo populacional<sup>6,26,28–30</sup> Nesses casos, os diuréticos tiazídicos são considerados a primeira opção terapêutica, podendo ser utilizados isoladamente ou em associação com bloqueadores dos canais de cálcio, especialmente em esquemas de terapia combinada<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **v. Medicamentos** -->
- Atenolol: comprimidos de 50 mg e 100 mg;  
- Besilato de anlodipino: comprimidos de 5 mg e 10 mg;  
- Captopril: comprimidos de 25 mg;  
- Carvedilol: comprimidos de 3,125 mg, 6,25 mg, 12,5 mg e 25 mg;  
- Cloridrato de hidralazina: comprimidos de 25 mg e 50 mg;  
- Cloridrato de propranolol: comprimidos de 10 mg e 40 mg;  
- Cloridrato de verapamil: comprimidos de 80 mg e 120 mg; solução injetável de 2,5 mg/mL.  
- Espironolactona: comprimidos de 25 mg e 100 mg;  
- Furosemida: comprimidos de 40 mg e solução injetável de 10 mg/mL;  
- Hidroclorotiazida: comprimidos de 12,5 mg e 25 mg;  
- Losartana potássica: comprimidos de 50 mg;  
- Maleato de enalapril: comprimidos de 5 mg, 10 mg e 20 mg;  
- Mesilato de doxazosina: comprimidos de 2 mg e 4 mg;  
- Metildopa: comprimidos de 250 mg;  
- Nifedipino: cápsulas ou comprimidos de 10 mg;  
- Succinato de metoprolol: comprimidos de liberação prolongada de 25 mg, 50 mg e 100 mg;  
- Tartarato de metoprolol: comprimidos de 100 mg;  
**Nota** : Estão disponíveis por meio do Programa “Aqui Tem – Farmácia Popular”<sup>133</sup> os seguintes medicamentos para o tratamento da HAS: atenolol: comprimidos de 25 mg; besilato de anlodipino: comprimidos de 5 mg; captopril: comprimidos de 25 mg; cloridrato de propranolol: comprimidos de 40mg; espironolactona: comprimidos de 25 mg; furosemida: comprimidos de 40 mg; hidroclorotiazida: comprimidos de 25mg; losartana potássica: comprimidos de 50mg; maleato de enalapril: comprimidos de 10mg; e succinato de metoprolol: comprimidos de liberação prolongada de 25 mg.  
51

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **vi. Esquemas de administração** -->
Os esquemas de administração, via oral, segundo a classe terapêutica, estão descritos nos Quadro 18 (tratamento de adultos) e Quadro 19 (tratamento de crianças e adolescentes).  
Quadro 18. Esquemas de administração dos medicamentos disponíveis no SUS para tratamento da HAS em adultos.  
|**Classe terapêutica**|**Medicamento**|**Dose diária**<br>**habitual**<br>**(mg)**|**Dose diária**<br>**máxima**<br>**(mg)**|**Frequência**<br>**diária**<sup>**a**</sup>|
|---|---|---|---|---|
|Inibidores da enzima<br>|Captopril|25 a 150|250|2 a 3|
|conversora de<br>angiotensina|Maleato de enalapril|5 a 40|40|1 a 2|
|Bloqueador do receptor<br>de angiotensina|Losartana potássica|50 a 100|100|1 a 2|
||Besilato de<br>anlodipino|2,5 a 10|10|1|
|Bloqueadores do Canal<br>de Cálcio|Nifedipino|10a60|60|1 a3|
||Cloridrato de<br>verapamil|120 a 360|480|1 a 2|
|Betabloqueadores não<br>cardiosseletivos|Cloridrato de<br>propranolol|80 a 320|640|2 a 3|
||Atenolol|50 a 100|100|1 a 2|
|Betabloqueadores|Carvedilol<br>|12,5a50|50|1 a 2|
|<br>cardiosseletivos|Succinato ou<br>tartarato de<br>metoprolol|50 a 200|200|1 a 2|
|Diuréticos tiazídicos|Hidroclorotiazida|25a50|200|1 a 2|
|Diurético de alça|Furosemida|20 a 80|b|1 a 3|
|Diurético poupador de<br>potássio|Espironolactona|25 a 100|200|1 a 2|
|Simpatolítico de ação<br>central|Metildopa|500 a 2000|3 g|2 a 3|
|Alfabloqueador|Mesilato de<br>doxazosina|1 a 16|16|1|
|Vasodilatador direto|Cloridrato de<br>hidralazina|50 a 200|200|2 a 3|  
**Nota:** a - Quando houver múltiplas administrações ao dia, a dose habitual diária deve ser dividida pela quantidade de administrações. b – depende da resposta do paciente. **Fonte** : Adaptado de Barroso et al. (2021)<sup>6</sup> .  
52  
Quadro 19. Esquemas de administração dos medicamentos disponíveis no SUS para tratamento da HAS em crianças e adolescentes.  
|**Classe terapêutica**|**Medicamento**|**Esquemas de administração**|
|---|---|---|
|Inibidores da enzima<br>conersora de|Captopril<sup>a</sup>|Inicial: 0,3 a 0,5 mg/kg/dose (três vezes/dia)<br>Máximo: 6 mg/kg/dia|
|v<br>angiotensina – IECA|Maleato de<br>enalapril<sup>a</sup>|Inicial: 0,08 mg/kg/dia (duas vezes/dia)<br>Máximo: 0,6 mg/kg/dia ou 40 mg/dia|
|Bloqueador do receptor<br>de angiotensina II –<br>BRA|Losartana<br>potássica<sup>a</sup>|Inicial: 0,7 mg/kg/dia<br>Máximo: 1,4 mg/kg/dia ou 100 mg/dia|
|Bloqueadores do Canal|Besilato de<br>anlodipino<sup>a</sup>|Inicial: 0,1 mg/kg/dia<br>Máximo: 0,6mg/kg/dia ou 10mg/dia|
|de Cálcio - BCC|Nifedipino<sup>a</sup>|Inicial: 0,04 a 0,25 mg/kg/dia<br>Máximo:1 a 2 mg/kg/dia|
|Diurético|Hidroclorotiazida|Inicial: 1 mg/kg/dia<br>Máximo: 3mg/kg/dia ou50mg/dia|
||Atenolol<sup>a</sup>|Inicial: 0.5 a 1 mg/kg/dose<br>Máximo:2 mg/kg/dia ou 100mg/dia|
|Beta Bloqueadores –<br>BB|Succinato de<br>metoprolol<sup>a</sup>|Inicial: 1 a 2 mg/kg/dia<br>Máximo: 6mg/kg/dia ou 200mg/dia|
||Cloridrato de<br>propranolol<sup>a</sup>|Inicial: 1 a 2 mg/kg/dia<br>Máximo:4 mg/kg/dia ou640mg/dia|  
**Fonte** : Traduzido e adaptado de Siddiqui et al. (2020)<sup>37</sup> .  
Nota:<sup>a</sup> Aprovado para uso adulto, mas com relatos de uso pediátrico.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **vii. Contraindicações** -->
Além de hipersensibilidade ao fármaco ou qualquer componente da fórmula, as contraindicações de uso dos medicamentos preconizados por este Protocolo são:  
- **Besilato de anlodipino:** não deve ser utilizado por mulheres grávidas sem orientação médica.  
- **Nifedipino:** casos de choque cardiovascular; gravidez antes da 20ª semana de gestação e durante a amamentação. Não deve ser usado em associação com a rifampicina, pois, devido à indução enzimática, o nifedipino pode não atingir níveis plasmáticos eficazes.  
- **Atenolol:** bradicardia, choque cardiogênico, hipotensão, acidose metabólica, distúrbios graves da circulação arterial periférica, bloqueio cardíaco de segundo ou terceiro grau, síndrome do nodo sinusal, feocromocitoma não tratado, insuficiência cardíaca descompensada.  
- **Carvedilol:** insuficiência cardíaca descompensada/instável, que exija terapia inotrópica intravenosa; insuficiência hepática clinicamente manifesta; asma brônquica ou doença pulmonar obstrutiva crônica com componente broncoespástico; bloqueio atrioventricular de segundo ou terceiro grau (a menos que o paciente tenha um marca-passo permanente); bradicardia grave (< 50 batimentos por minuto); síndrome do nó sinusal (incluindo bloqueio sinoatrial); choque cardiogênico; hipotensão grave (pressão arterial sistólica < 85 mmHg); pessoas com insuficiência de sacarose-isomaltase.  
- **Succinato de metoprolol:** hipersensibilidade a outros betabloqueadores, Bloqueio atrioventricular de grau II ou de grau III, pacientes com insuficiência cardíaca não compensada instável (edema pulmonar, hipoperfusão ou hipotensão), e pacientes com terapia  
53  
inotrópica contínua ou intermitente agindo por meio de agonista do receptor beta, bradicardia sinusal clinicamente relevante, síndrome do nó sino-atrial (a não ser que um marcapasso permanente esteja em uso), choque cardiogênico e arteriopatia periférica grave. O metoprolol não deve ser administrado em pacientes com suspeita de infarto agudo do miocárdio, enquanto a frequência cardíaca for < 45 batimentos/minuto, o intervalo PQ for > 0,24 segundos ou a pressão sistólica for < 100 mmHg.  
- **Tartarato de metoprolol:** hipersensibilidade a outros betabloqueadores, Bloqueio atrioventricular de grau II ou III insuficiência cardíaca não compensada; Bradicardia sinusal clinicamente relevante (frequência cardíaca menor que 45 a 50 batimentos por minuto); Doença do nó sinusal; Distúrbios circulatórios arteriais periféricos graves; Choque cardiogênico; Feocromocitoma não tratado; Hipotensão; Asma brônquica grave ou história de broncoespasmo grave; Infarto do miocárdio com frequência cardíaca menor que 45 a 50 batimentos por minuto, intervalo P-R maior que 0,24 segundos, pressão sistólica menor que 100 mmHg e/ou insuficiência cardíaca grave.  
- **Cloridrato de propranolol:** hipotensão; bradicardia; distúrbios graves da circulação arterial periférica; síndrome do nó sinoatrial; feocromocitoma não tratado (com um antagonista do receptor alfa-adrenérgico); insuficiência cardíaca descompensada; angina de Prinzmetal; choque cardiogênico; acidose metabólica; pacientes com predisposição à hipoglicemia, isto é, após jejum prolongado ou pacientes com reservas contrarregulatórias restritas; bloqueio cardíaco de segundo ou terceiro grau; histórico de asma brônquica ou broncoespasmo.  
- **Captopril:** hipersensibilidade a outro inibidor da IECA; não deve ser utilizado por mulheres grávidas sem orientação médica.  
- **Maleato de enalapril:** pacientes com histórico de edema angioneurótico relacionado a utilização de inibidores da enzima conversora de angiotensina e pacientes com angioedema hereditário ou idiopático. Não deve ser administrado com alisquireno em pacientes com diabetes. É contraindicado em combinação com um inibidor de neprilisina (por exemplo, sacubitril), devendo ser administrado 36 horas antes ou depois de utilizar sacubitril valsartana.  
- **Mesilato de doxazosina:** hipersensibilidade a outros tipos de quinazolinas (por exemplo, prazosina, terazosina), história de hipotensão ortostática, hiperplasia prostática benigna e congestão concomitante do trato urinário superior, infecção crônica do trato urinário ou cálculos na bexiga, pacientes com histórico de obstrução gastrointestinal, obstrução esofágica ou qualquer grau de diminuição do diâmetro do lúmen do trato gastrointestinal. Está contraindicado como monoterapia em pacientes com transbordamento da bexiga ou anúria com ou sem insuficiência renal progressiva.  
- **Espironolactona:** insuficiência renal aguda, diminuição significativa da função renal, anúria; doença de Addison; hipercalemia; uso concomitante de eplerenona.  
- **Furosemida:** lactantes, pacientes com insuficiência renal com anúria, pré-coma e coma associado à encefalopatia hepática, hipopotassemia severa, hiponatremia severa, hipovolemia (com ou sem hipotensão) ou desidratação, hipersensibilidade às sulfonamidas. Não deve ser usado por pessoas com síndrome de má-absorção de glicose-galactose.  
- **Cloridrato de hidralazina:** lúpus eritematoso sistêmico idiopático e doenças correlatas, taquicardia grave e insuficiência cardíaca com alto débito cardíaco (por exemplo, em tireotoxicose), insuficiência do miocárdio devido à obstrução mecânica (por exemplo, em estenose aórtica ou mitral e na pericardite constritiva); insuficiência cardíaca isolada do ventrículo direito devido à hipertensão pulmonar ( _cor pulmonale_ ); e aneurisma dissecante da aorta.  
- **Hidroclorotiazida:** comprometimento grave da função renal (depuração da creatinina abaixo de 30 mL/min), com distúrbio hepático grave, icterícia em crianças, com distúrbio grave do equilíbrio de eletrólitos, anúria. Não deve ser usado por pessoas com síndrome de máabsorção de glicose-galactose.  
54  
- **Losartana potássica:** insuficiência hepática grave. O uso concomitante com produtos contendo alisquireno é contraindicado em pacientes com diabetes e insuficiência renal (TGF < 60 mL/min/1,73m<sup>2</sup> ). O medicamento não deve ser administrado durante o segundo ou o terceiro trimestre de gestação.  
- **Metildopa:** hepatopatias ativas, tais como hepatite aguda e cirrose ativa; tratamento com inibidores da monoaminoxidase (MAO).  
- **Cloridrato de verapamil** : choque cardiogênico; bloqueio atrioventricular de segundo ou terceiro grau (exceto em pacientes com marcapasso artificial em funcionamento); síndrome do nódulo sinusal (exceto em pacientes com marcapasso artificial em funcionamento); insuficiência cardíaca com fração de ejeção menor que 35 % e/ou pressão pulmonar acima de 20 mmHg (a não ser que secundário para taquicardia supraventricular sensível ao tratamento com verapamil); “flutter” ou fibrilação atrial na presença de feixes de condução acessórios (ou seja, síndrome de _WolffParkinson-White_ e _Lown-Ganong-Levine_ ).

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **viii. Critérios de interrupção** -->
O tratamento medicamentoso pode ser interrompido em situações específicas, a critério médico, considerando efetividade ou segurança subótima.  
Para interrupção de uso de betabloqueadores, recomenda-se a retirada gradual (em duas a quatro semanas) para evitar taquicardia reflexa e mal-estar<sup>6</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **11. ADESÃO TERAPÊUTICA** -->
Apesar da eficácia comprovada do tratamento, o controle dos níveis da PA ainda é pouco satisfatório, <mark>tanto em países de alta renda (com taxas de controle da PA de 50% a 58% para mulheres e 48% a 69% para homens, respectivamente)</mark><sup>134</sup> , e países de baixa renda (com taxas de controle menor que 10%)<sup>134</sup> <mark>. Dados</mark> nacionais mostram que as taxas de controle da HAS têm ampla variação e encontram-se entre 10% e 50%<sup>135–137</sup> . Os índices de não adesão são variados, com taxas de 8,2% a 74,9%, dependendo da forma de avaliação<sup>6</sup> .  
Diversos fatores podem influenciar o controle da HAS, embora a falta de adesão ao tratamento seja o mais frequente<sup>6,28</sup> . A adesão ao tratamento no contexto das doenças crônicas não transmissíveis corresponde ao grau em que o comportamento de uma pessoa atende às recomendações relacionadas ao tratamento medicamentoso ou não medicamentoso, estabelecidas com o profissional de saúde<sup>138</sup> .  
A adesão terapêutica pode ser definida como um processo caracterizado por três grandes componentes: o início, a implementação e a descontinuação. O início é o tempo desde a prescrição até a administração da primeira dose do medicamento. Já a implementação corresponde à coincidência entre a dose que o paciente utiliza e a prescrita, enquanto a descontinuação marca a interrupção, quando a próxima dose a ser administrada é omitida e o tratamento é interrompido posteriormente. Nesse contexto, a persistência ao tratamento é estabelecida pelo período entre a sua iniciação e a interrupção<sup>139</sup> . Promover a adesão terapêutica ainda é um grande desafio no tratamento da HAS<sup>140</sup> .  
Devido à sua multidimensionalidade, a adesão ao tratamento anti-hipertensivo é processual e influenciada por múltiplos fatores, que podem ser divididos em cinco dimensões<sup>6,</sup> 19,28,140–148.  
- Socioeconômica: sexo, idade, escolaridade, renda, acesso a transporte, distância aos serviços de saúde, moradia em zona rural e situações de desastres e pandemia.  
55  
- Relacionada ao tratamento medicamentoso: custo de aquisição dos medicamentos, eventos adversos, complexidade e tempo do tratamento.  
- Equipe e sistema de saúde: relacionamento equipe multiprofissional-paciente, comunicação, individualização do tratamento, identificação de não adesão terapêutica e atualização do tratamento.  
- Fatores relacionados ao paciente: negação ou aceitação da doença, percepção do benefício do tratamento, conhecimento sobre a doença e do seu tratamento, percepção de dependência e dos eventos adversos dos medicamentos antihipertensivos, apoio familiar.  
- Relacionada à doença: ausência ou presença de sintomas, de complicações a longo prazo, de comorbidades associadas e qualidade de vida.  
Dessa forma, estratégias para adesão terapêutica devem ser implementadas para minimizar os efeitos do controle inadequado da PA e, consequentemente, as repercussões deletérias com lesão de órgão-alvo.  
Diversas intervenções podem beneficiar a adesão ao tratamento, sendo relacionadas ao<sup>6</sup> :  
- Autocuidado apoiado à pessoa com hipertensão: estratégias motivacionais, monitorização da PA em casa, uso de recursos tecnológicos como telemonitoramento à distância, educação em saúde individual e em grupo, uso de lembretes e caixas organizadoras de medicamentos, apoio familiar e social e envio de mensagem por telefone móvel.  
- Tratamento medicamentoso, que inclui: evitar doses elevadas em monoterapia, uso de medicamentos com menos eventos adversos, receituário de fácil entendimento escrito ou impresso, tratamento diferenciado para grupos específicos (afrodescendentes, idosos, mulheres, obesos, diabéticos).  
- Equipes e sistemas de saúde, destacando-se as que estabelecem vínculo com a pessoa hipertensa, como: fixar os profissionais à equipe da Estratégia Saúde da Família, usar formas de comunicação de fácil compreensão, realizar busca ativa das pessoas que faltam às consultas clínicas, realizar visitas domiciliares, atuar em equipe multidisciplinar (médico, enfermeiro, farmacêutico, profissional de educação física, nutricionista, psicólogo, assistente social, agentes comunitários de saúde) e contribuir para o acesso aos medicamentos<sup>149–157</sup> .  
Face à ampla magnitude de estratégias para promover a adesão, as evidências destacam a atuação do farmacêutico, no contexto do cuidado farmacêutico, e do enfermeiro, na promoção da adesão ao tratamento anti-hipertensivo, reforçando a importância do acompanhamento multiprofissional e interdisciplinar<sup>158</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **12. MONITORAMENTO** -->
Os pacientes com HAS devem ser acompanhados periodicamente ao longo de sua vida. Um sistema organizado de monitoramento regular dos pacientes, aliado à terapia medicamentosa anti-hipertensiva, mostrou redução da PA e da mortalidade por todas as causas em cinco anos de seguimento<sup>158</sup> . Sistemas de recordação de data de retorno parecem reduzir o número de faltas às consultas clínicas (OR 0,41; IC 95%, 0,32-0,51) e levaram à melhora do controle da PA <mark>(OR 0,54; IC 95%, 0,41-0,73)</mark><sup>158</sup> .  
56  
Reavaliações mensais devem ser realizadas até que o alvo terapêutico seja alcançado<sup>19,30</sup> . Durante o primeiro ano após o início do tratamento, as consultas devem ocorrer trimestralmente, idealmente em intervalos de 3 meses a 6 meses. Após atingir o alvo terapêutico, as reavaliações podem ser feitas semestralmente<sup>18,28</sup> .  
O acompanhamento deve incluir a avaliação do controle da PA medida em consultório clínico, por apresentar as melhores evidências de impacto em desfechos de saúde importantes nos estudos iniciais sobre HAS, sendo considerada o padrão-ouro<sup>18</sup> . Como a PA medida no consultório pode não representar a medida acurada da PA de um indivíduo<sup>159</sup> , a MAPA pode ser uma estratégia importante, principalmente em pacientes com suspeita de hipertensão do avental branco ou hipertensão mascarada, para avaliação do controle da HAS, com ênfase aos indivíduos com alto RCV, e avaliação de sintomas sugestivos de hipotensão decorrente do tratamento<sup>18,159</sup> . Ressalta-se que os pontos de corte dos valores de PA considerados normais são 5 mmHg inferiores com MAPA em relação aos valores de PA medida em consultório<sup>18</sup> , (ver item “Confirmação diagnóstica por meio da monitorização ambulatorial ou residencial da pressão arterial”).  
A constatação de PA elevada na consulta clínica, com a técnica correta de medida, deve sempre suscitar a busca por sua causa<sup>30</sup> . As causas mais comuns são a má adesão ao tratamento prescrito (medicamentoso e não medicamentoso), hipertensão do avental branco e ingestão de substâncias que elevam a PA, como sal, álcool e medicamentos, como por exemplo antiinflamatórios não esteroidais<sup>30</sup> . Essa investigação etiológica requer um questionamento cuidadoso e rigoroso do paciente e de seus familiares<sup>30</sup> .  
Após a identificação da causa da elevação da PA, deve-se corrigi-la e reavaliar o paciente com medidas repetidas de PA nas semanas seguintes para verificar se a PA foi controlada<sup>30</sup> (ver item Metas terapêuticas). Se a PA persistir elevada e for necessário adição de tratamento medicamentoso ou uso associado de medicamentos, este deve ser realizado<sup>34</sup> , conforme descrito no item Tratamento Medicamentoso, a fim de evitar a “inércia clínica”, um dos principais contribuintes para o controle inadequado da PA em todo o mundo<sup>30</sup> .  
Além da avaliação quanto ao controle da PA, também é necessário investigar potenciais eventos adversos dos medicamentos anti-hipertensivos e rastrear demais fatores de RCV e de lesões em órgão-alvo<sup>30</sup> . Na história do paciente, devem ser avaliados: adesão ao tratamento não medicamentoso e medicamentoso; fatores de risco modificáveis, como alimentação inadequada e não saudável, inatividade física, tabagismo, consumo excessivo de álcool, apneia do sono, uso de medicamentos que podem aumentar a PA (por exemplo, contraceptivos hormonais), e sintomas de lesões em órgãos, como cérebro e olhos (cefaleia, pré-síncope, síncope, redução na visão, déficit sensitivo ou motor, piora cognitiva), coração (dor torácica, dispneia, edema, palpitações), rins (polidipsia, poliúria, noctúria, hematúria) e sistema arterial periférico (extremidades frias, claudicação intermitente)<sup>30</sup> .  
No exame físico, devem ser medidos peso e altura, para cálculo do IMC, circunferência abdominal e realizados ausculta cardíaca, palpação de pulsos e exame neurológico sumário, além de outros exames, conforme dados da anamnese do paciente<sup>6</sup> .  
Em relação aos exames complementares, devem ser solicitados perfil lipídico, glicemia de jejum ou hemoglobina glicada, creatinina, potássio, sódio (se paciente estiver em uso de diuréticos tiazídicos), urinálise e eletrocardiograma<sup>30</sup> . Esses exames são importantes para avaliar a toxicidade dos medicamentos, garantindo a segurança e a adesão ao tratamento<sup>6,30</sup> . Os exames laboratoriais devem ser solicitados anualmente ou pelo menos a cada 2 anos<sup>30</sup> . Não foram encontradas evidências relativas à periodicidade de solicitação de eletrocardiograma em hipertensos assintomáticos.  
57  
As interações medicamentosas entre anti-hipertensivos em geral são mínimas, especialmente as farmacocinéticas, permitindo combinações terapêuticas seguras<sup>6,30</sup> . No entanto, em pacientes idosos, a polifarmácia exige atenção, pois o uso de múltiplos medicamentos pode aumentar o risco de interações e efeitos adversos<sup>6,30</sup> .  
Apesar do efeito na redução da PA da maioria dos anti-hipertensivos iniciar dentro de poucos minutos a uma hora, seu efeito pleno costuma se estabelecer apenas dentro de uma a duas semanas, podendo levar até dois meses<sup>19,30</sup> .  
O Quadro 20 descreve as principais ações de monitoramento dos pacientes com HAS.  
Quadro 20. Monitoramento de pacientes com HAS.  
|**Ações de**<br>**monitoramento**|**Periodicidade**|
|---|---|
|Reavaliação|- um mês após o início do tratamento;<br>- um mês a cada modificação do tratamento, até que seja alcançado o alvo<br>terapêutico  <sup>19,30</sup>;|
||- duas a quatro vezes por ano durante o primeiro ano após o início do|
|Acompanhamento|tratamento, idealmente, no intervalo de 3- a 6 meses;<br>- semestral após alcançado o alvo terapêutico<sup>18,28</sup>;.|  
O monitoramento da HAS gestacional é importante para a saúde da mulher e do bebê, já que pode estar associada à restrição do crescimento intrauterino, natimorto ou parto prematuro<sup>38</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **13. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento póstratamento.  
Pacientes com HAS devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica.  
O cuidado da HAS incluiu ações de prevenção de doenças e promoção da saúde, rastreamento, diagnóstico, definição do tratamento e seu acompanhamento, que deve ser realizado pelas equipes da APS e encaminhados para atenção especializada, nos seguintes casos:  
- Pacientes com suspeita de hipertensão arterial secundária, a depender das possíveis etiologias e dos recursos disponíveis para sua investigação<sup>18</sup> ;  
- Deve-se suspeitar de causas secundárias da HAS em todos os indivíduos com diagnóstico da HAS antes dos 40 anos de idade<sup>18</sup> ;  
- Crianças e adolescentes que não apresentarem resposta após seis meses de tratamento com medicamento em monoterapia<sup>13</sup> ;  
- Pacientes com HAR (PA elevada após seis meses de tratamento intensivo adequado com três medicamentos e boa adesão terapêutica)<sup>31</sup> ;  
- Pacientes com HAS e múltiplas comorbidades ou complicações<sup>36</sup> ;  
- Pacientes com muito alto RCV.  
58  
Ainda, pacientes com emergências hipertensivas, como AVE, síndromes coronarianas agudas, insuficiência cardíaca com edema agudo de pulmão, dissecção aórtica aguda, doença renal aguda, feocromocitoma, emergências hipertensivas da gestação e urgências hipertensivas devem ser encaminhados para avaliação no mesmo dia em serviço de urgência e emergência<sup>8</sup> .  
Todos os pacientes encaminhados para avaliação ou acompanhamento, em serviço de urgência ou não, devem manter o acompanhamento longitudinal com a sua equipe de referência na APS.  
Verificar na Rename vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo e dar preferência ao provimento destes, conforme o nível de atenção à saúde do serviço. Salienta-se que, por meio do Programa Farmácia Popular do Brasil, também é possível acessar os principais medicamentos recomendados.  
As gestões estaduais, distrital e municipais deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Além disso, as gestões deverão coordenar e executar ações para garantir a implementação da estrutura que permita o cuidado integral de indivíduos com HAS de forma qualificada e em tempo oportuno, de modo a viabilizar a estrutura física adequada, os exames laboratoriais, e a capacitação dos profissionais da equipe multidisciplinar para que possam realizar a prevenção, o manejo e o controle da HAS. Para isso, deve ser considerado o perfil epidemiológico local, as necessidades de saúde e a capacidade instalada do território.  
Ainda, como parte da rede da APS, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores direcionadores de suas atividades o desenvolvimento de autonomia, a equidade, o empoderamento, a participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso. <mark>Os procedimentos diagnósticos (Grupo 02) e terapêuticos clínicos (Grupo 03) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.</mark>  
59

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **14. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **15. REFERÊNCIAS** -->
1. Brasil / Ministério da Saúde. Cadernos de Atenção Básica. Estratégias para o cuidado da pessoa com doença crônica. Brasília - DF; 2013.  
2. Zhou B, Carrillo-Larco RM, Danaei G, Riley LM, Paciorek CJ, Stevens GA, et al. Worldwide trends in hypertension prevalence and progress in treatment and control from 1990 to 2019: a pooled analysis of 1201 population-representative studies with 104 million participants. The Lancet. 2021 Sep;398(10304):957–80.  
3. Nilson EAF, Andrade R da CS, Brito DA de, Michele Lessa de O. Custos atribuíveis a obesidade, hipertensão e diabetes no Sistema Único de Saúde, Brasil, 2018. Revista Panamericana de Salud Pública. 2020 Apr 10;44:1.  
4. Instituto Brasileiro de Geografi a e Estatística - IBGE. Pesquisa Nacional de Saúde 2019: Percepção do estado de saúde, estilos de vida, doenças crônicas e saúde bucal - Brasil e grandes regiões [Internet]. Rio de Janeiro; 2020 [cited 2024 Jul 23]. Available from: https://www.pns.icict.fiocruz.br/wp-content/uploads/2021/02/liv101764.pdf  
5. Brasil. Ministério da Saúde. Coordenação-Geral de Informações e Análises Epidemiológicas (CGIAE) do Departamento de Análise Epidemiológica e Vigilância de Doenças Não Transmissíveis (DAENT/SVSA/MS). Sistema de Informações sobre Mortalidade - SIM [Internet]. Departamento de Análise Epidemiológica e Vigilância de Doenças Não Transmissíveis. SECRETARIA DE VIGILÂNCIA EM SAÚDE E AMBIENTE. 2021 [cited 2024 Jul 23]. Available from: https://svs.aids.gov.br/daent/cgiae/sim/  
6. Barroso WKS, Rodrigues CIS, Bortolotto LA, Mota-Gomes MA, Brandão AA, Feitosa AD de M, et al. Diretrizes Brasileiras de Hipertensão Arterial – 2020. Arq Bras Cardiol. 2021 Mar 3;116(3):516–658.  
7. OPAS. HEARTS Pacote de medidas técnicas para manejo da doença cardiovascular na atenção primária à saúde. Hábitos saudáveis: aconselhamento a pacientes. 2019.  
8. Brasil. Ministério da Saúde. Política Nacional de Promoção da Saúde: PNPS: Anexo I da Portaria de Consolidação n<sup>o</sup> 2, de 28 de setembro de 2017, que consolida as normas sobre as políticas nacionais de saúde do SUS [Internet]. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Secretaria de Atenção à Saúde. 2018 [cited 2024 Jul 23]. p. 1–40. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/politica_nacional_promocao_saude.pdf  
9. World Health Organization (WHO). Health promotion and disease prevention through population-based interventions, including action to address social determinants and health inequity [Internet]. World Health Organization (WHO). 2023 [cited 2024 Jul 23]. Available from: https://www.emro.who.int/about-who/public-health-functions/health-promotion-diseaseprevention.html  
10. Brasil. Ministério da Saúde. Autocuidado em Saúde e a Literacia para a Saúde no contexto da promoção, prevenção e cuidado das pessoas em condições crônicas : guia para  
60  
profissionais da saúde [Internet]. Brasilia; 2023 [cited 2024 Jul 23]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/autocuidado_saude_literacia_condicoes_cronicas.pdf  
11. World Health Organization - WHO. Hypertension [Internet]. World Health Organization - WHO. 2023 [cited 2024 Jul 23]. Available from: https://www.who.int/newsroom/fact-sheets/detail/hypertension  
12. Malachias M, Souza W, Plavnik F, Rodrigues C, Brandão A, Neves M, et al. Capítulo 10 - Hipertensão na Criança e no Adolescente. Arq Bras Cardiol. 2016;107(3).  
13. Williams B, Mancia G, Spiering W, Agabiti Rosei E, Azizi M, Burnier M, et al. 2018 ESC/ESH Guidelines for the management of arterial hypertension. Eur Heart J. 2018 Sep 1;39(33):3021–104.  
14. OPAS -  Organização PanAmericana da Saúde. HEARTS Pacote de medidas técnicas para manejo da doença cardiovascular na atenção primária à saúde. Evidências: protocolos de tratamento baseados em evidências [Internet]. Washington, D.C; 2019 [cited 2024 Jul 24]. Available from: https://iris.paho.org/handle/10665.2/51770  
15. US Preventive Services Task Force, Krist AH, Davidson KW, Mangione CM, Cabana M, Caughey AB, et al. Screening for Hypertension in Adults: US Preventive Services Task Force Reaffirmation Recommendation Statement. JAMA. 2021;325(16):1650–6.  
16. Brasil. Ministério da Saúde. Secretaria de Atenção Primária à Saúde. Departamento de Saúde da Família. Linha de Cuidado do adulto com hipertensão arterial sistêmica. Brasília: Ministério da Saúde; 2021. p. 85.  
17. OPAS. HEARTS - Evidências: protocolos de tratamento baseados em evidências. 2019;48.  
18. NICE - National Institute for Health and Care Excellence. Hypertension in adults: diagnosis and management - [A] Evidence review for diagnosis. 2019.  
19. World Health Organization (WHO). Guideline for the pharmacological treatment of hypertension in adults. Geneva; 2021. p. 61.  
20. Pedroso Camargos A, Barreto S, Brant L, Ribeiro ALP, Dhingra LS, Aminorroaya A, et al. Performance of contemporary cardiovascular risk stratification scores in Brazil: an evaluation in the ELSA-Brasil study. Open Heart. 2024 Jun 11;11(1):e002762.  
21. Brasil. Ministério da Saúde. Estratégia de Saúde Cardiovascular na Atenção Primária à Saúde: instrutivo para profissionais e gestores [Internet]. Brasília; 2022 [cited 2024 Jul 23]. Available from:  
http://bvsms.saude.gov.br/bvs/publicacoes/estrategia_saude_cardiovascular_instrutivo_profissio nais.pdf  
22. World Health Organization - WHO. HEARTS technical package for cardiovascular disease management in primary health care: risk based CVD management. [Internet]. Geneva; 2020 [cited 2024 Jul 23]. Available from: https://iris.who.int/bitstream/handle/10665/333221/9789240001367-eng.pdf  
23. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas Diabete Melito tipo 2 [Internet]. Brasília; 2024 Feb [cited 2024 Jul 30]. Available from: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/RRPCDTDM2_Final.pdf  
61  
24. Faludi A, Izar M, Saraiva J, Chacra A, Bianco H, Afiune Neto A, et al. ATUALIZAÇÃO DA DIRETRIZ BRASILEIRA DE DISLIPIDEMIAS E PREVENÇÃO DA ATEROSCLEROSE - 2017. Arq Bras Cardiol. 2017;109(1).  
25. American Diabetes Association. Standards of Medical Care in Diabetes—2022. Abridged for Primary Care Providers. Clinical Diabetes. 2022 Jan 1;40(1):10–38.  
26. Unger T, Borghi C, Charchar F, Khan NA, Poulter NR, Prabhakaran D, et al. 2020 International Society of Hypertension Global Hypertension Practice Guidelines. Hypertension. 2020 Jun;75(6):1334–57.  
27. Manoel R, Póvoa S. HIPERTENSÃO ARTERIAL SECUNDÁRIA SECONDARY ARTERIAL HYPERTENSION Curso de Hipertensão arterial-13 Arterial hypertension course-13 DEFINIÇÃO. Vol. 26, Rev Bras Hipertens. 2019.  
28. Whelton PK, Carey RM, Aronow WS, Casey DE, Collins KJ, Dennison Himmelfarb C, et al. 2017 ACC/AHA/AAPA/ABC/ACPM/AGS/APhA/ASH/ASPC/NMA/PCNA Guideline for the Prevention, Detection, Evaluation, and Management of High Blood Pressure in Adults: A Report of the American College of Cardiology/American Heart Association Task Force on Clinical Pr. Hypertension. 2018 Jun;71(6):1269–324.  
29. Moreno Júnior H, Manoel R, Póvoa S, Carlos Yugar-Toledo J. HIPERTENSÃO ARTERIAL RESISTENTE (HAR) RESISTANT ARTERIAL HYPERTENSION (RAH) [Internet]. Vol. 26, Rev Bras Hipertens. Brasília; 2019 [cited 2025 Jan 21]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/caderno_atencao_basica15.pdf  
30. Mancia G, Kreutz R, Brunström M, Burnier M, Grassi G, Januszewicz A, et al. 2023 ESH Guidelines for the management of arterial hypertension The Task Force for the management of arterial hypertension of the European Society of Hypertension. J Hypertens. 2023 Dec;41(12):1874–2071.  
31. Brook RD, Townsend RR. Treatment of resistant hypertension. UpToDate [Internet]. 2024 Oct [cited 2025 Jan 23]; Available from: https://www.uptodate.com/contents/treatment-of-resistant-hypertension  
32. Brant LCC, Passaglia LG, Pinto-Filho MM, de Castilho FM, Ribeiro ALP, Nascimento BR. The Burden of Resistant Hypertension Across the World. Curr Hypertens Rep. 2022 Mar 3;24(3):55–66.  
33. Brasil. Ministério da Saúde. Hipertensão arterial sistêmica para o Sistema Único de Saúde - Cadernos de Atenção Básica [Internet]. Brasília; 2006 [cited 2025 Jan 21]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/caderno_atencao_basica15.pdf  
34. Brasil. Ministério da Saúde. PORTARIA SECTICS/MS N<sup>o</sup> 22, DE 10 DE MAIO DE 2023 - Monitorização residencial da pressão arterial para diagnóstico de hipertensão arterial sistêmica em adultos com suspeita da doença. Brasília; 2023.  
35. Elliott WJ, Varon J. Evaluation and treatment of hypertensive emergencies in adults [Internet]. UpToDate. Available from: https://www.uptodate.com/contents/evaluation-andtreatment-of-hypertensive-emergencies-in-adults?search=crise hipertensiva&source=search_result&selectedTitle=1~150&usage_type=default&display_rank=1  
36. DynaMed. Hypertensive Crisis. EBSCO Information Services [Internet]. 2023 Nov 20 [cited 2025 Jan 23]; Available from: https://www.dynamed.com/condition/hypertensivecrisis  
62  
37. Siddiqui S, Malatesta-Muncher R. Hypertension in Children and Adolescents: A Review of Recent Guidelines. Pediatr Ann. 2020 Jun;49(6).  
38. Brasil. Ministério da Saúde. Manual de gestação de alto risco [Internet]. 2022 [cited 2025 Jan 22]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/manual_gestacao_alto_risco.pdf  
39. Nathan AM, Tang JPL, Goh A, Teoh OH, Chay OM. Compliance with noninvasive home ventilation in children with obstructive sleep apnoea. Singapore Med J. 2013;54(12):678–82.  
40. Lurbe E, Agabiti-Rosei E, Cruickshank JK, Dominiczak A, Erdine S, Hirth A, et al. 2016 European Society of Hypertension guidelines for the management of high blood pressure in children and adolescents. J Hypertens. 2016 Oct;34(10):1887–920.  
41. Flynn JT, Kaelber DC, Baker-Smith CM, Blowey D, Carroll AE, Daniels SR, et al. Clinical Practice Guideline for Screening and Management of High Blood Pressure in Children and Adolescents. Pediatrics. 2017 Sep;140(3):e20171904.  
42. Redman CWG, Staff AC, Roberts JM. Syncytiotrophoblast stress in preeclampsia: the convergence point for multiple pathways. Am J Obstet Gynecol. 2022 Feb;226(2):S907–27.  
43. Moraes END, RAMM, & MFD. Manual de terapêutica segura no Idoso. Belo Horizonte: Folium; 2019. 362–365 p.  
44. ACOG Practice Bulletin No. 203: Chronic Hypertension in Pregnancy. Obstetrics & Gynecology. 2019 Jan;133(1):e26–50.  
45. Lane MM, Davis JA, Beattie S, Gómez‐Donoso C, Loughman A, O’Neil A, et al. Ultraprocessed food and chronic noncommunicable diseases: A systematic review and meta‐ analysis of 43 observational studies. Obesity Reviews. 2021 Mar 9;22(3).  
46. Brasil. Ministério da Saúde. S. Guia alimentar para a população brasileira [Internet]. Brasília; 2014 [cited 2024 Jul 25]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/guia_alimentar_populacao_brasileira_2ed.pdf  
47. Ministério da Saúde / Hospital do Coração. Alimentação Cardioprotetora: manual de orientações para os profissionais de saúde da Atenção Básica. DF: Ministério da Saúde; 2018. p. 138.  
48. Brasil. Ministério da Saúde. Orientação alimentar de pessoas adultas com obesidade, hipertensão arterial e diabetes mellitus: bases teóricas e metodológicas / Protocolos de uso do guia alimentar para a população brasileira [Internet]. Brasilia; 2022 [cited 2024 Jul 25]. Available from:  
https://bvsms.saude.gov.br/bvs/publicacoes/fasciculo1_protocolos_alimentar_adultas_obesidade. pdf  
49. Brasil. Ministério da Saúde. Matriz para Organização dos Cuidados em Alimentação e Nutrição na Atenção Primária à Saúde [Internet]. Brasília; 2022 [cited 2024 Jul 25]. Available from:  
https://bvsms.saude.gov.br/bvs/publicacoes/matriz_organizacao_cuidados_alimentacao_aps.pdf  
50. Appel LJ, Moore TJ, Obarzanek E, Vollmer WM, Svetkey LP, Sacks FM, et al. A Clinical Trial of the Effects of Dietary Patterns on Blood Pressure. New England Journal of Medicine. 1997 Apr 17;336(16):1117–24.  
63  
51. Mozaffarian D, Appel LJ, Van Horn L. Components of a Cardioprotective Diet. Circulation. 2011 Jun 21;123(24):2870–91.  
52. Spiker ML, Hiza HAB, Siddiqi SM, Neff RA. Wasted Food, Wasted Nutrients: Nutrient Loss from Wasted Food in the United States and Comparison to Gaps in Dietary Intake. J Acad Nutr Diet. 2017 Jul;117(7):1031-1040.e22.  
53. Conrad Z, Blackstone NT, Roy ED. Healthy diets can create environmental tradeoffs, depending on how diet quality is measured. Nutr J. 2020 Dec 27;19(1):117.  
54. Brennan A, Browne S. Food Waste and Nutrition Quality in the Context of Public Health: A Scoping Review. Int J Environ Res Public Health. 2021 May 18;18(10):5379.  
55. World Health Organization. Guideline: Sodium Intake for Adults and Children. Geneva: World Health Organization; 2012.  
56. Verdecchia P, Reboldi G, Angeli F. The 2020 International Society of Hypertension global hypertension practice guidelines - key messages and clinical considerations. Eur J Intern Med. 2020 Dec;82:1–6.  
57. Mente A, O’Donnell MJ, Rangarajan S, McQueen MJ, Poirier P, Wielgosz A, et al. Association of Urinary Sodium and Potassium Excretion with Blood Pressure. New England Journal of Medicine. 2014 Aug 14;371(7):601–11.  
58. Brasil. Ministério da Saúde. Orientações para avaliação de marcadores de consumo alimentar na atenção básica [Internet]. Brasília; 2015 [cited 2024 Jul 25]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/marcadores_consumo_alimentar_atencao_basica.pdf  
59. Malta DC, Felisbino-Mendes MS, Machado ÍE, Passos VM de A, Abreu DMX de, Ishitani LH, et al. Fatores de risco relacionados à carga global de doença do Brasil e Unidades Federadas, 2015. Revista Brasileira de Epidemiologia. 2017 May;20(suppl 1):217–32.  
60. Neter JE, Stam BE, Kok FJ, Grobbee DE, Geleijnse JM. Influence of Weight Reduction on Blood Pressure. Hypertension. 2003 Nov;42(5):878–84.  
61. World Health Organization. Global status report on alcohol and health 2018 [Internet]. p. 450. Available from: https://www.who.int/publications/i/item/9789241565639  
62. Roerecke M, Kaczorowski J, Tobe SW, Gmel G, Hasan OSM, Rehm J. The effect of a reduction in alcohol consumption on blood pressure: a systematic review and meta-analysis. Lancet Public Health. 2017 Feb;2(2):e108–20.  
63. Coelho JS, Martinez OGE, Siqueira JH, Campos GC, Viana MC, Griep RH, et al. Alcoholic beverage consumption, changes in blood pressure, and incidence of hypertension in the Longitudinal Adult Health Study (ELSA-Brasil). Nutrition. 2021 Nov;91–92:111387.  
64. Tasnim S, Tang C, Musini VM, Wright JM. Effect of alcohol on blood pressure. Cochrane Database of Systematic Reviews. 2020 Jul 1;2020(7).  
65. World Health Organization - WHO. No level of alcohol consumption is safe for our health [Internet]. World Health Organization - WHO. 2023 [cited 2024 Jul 25]. Available from: https://www.who.int/azerbaijan/news/item/04-01-2023-no-level-of-alcohol-consumptionis-safe-for-our-health  
66. Brasil. Ministério da Saúde. Linha de Cuidado do Adulto com Diabetes Mellitus tipo 2 (DM2) [Internet]. Brasília; 2020 [cited 2024 Jul 30]. Available from: https://linhasdecuidado.saude.gov.br/portal/diabetes-mellitus-tipo-2-(DM2)-no-adulto  
64  
67. Anderson BO, Berdzuli N, Ilbawi A, Kestel D, Kluge HP, Krech R, et al. Health and cancer risks associated with low levels of alcohol consumption. Lancet Public Health. 2023 Jan;8(1):e6–7.  
68. Oba‐Yamamoto C, Takeuchi J, Nakamura A, Takikawa R, Ozaki A, Nomoto H, et al. Combination of alcohol and glucose consumption as a risk to induce reactive hypoglycemia. J Diabetes Investig. 2021 Apr 7;12(4):651–7.  
69. Martinez-Morata I, Sanchez TR, Shimbo D, Navas-Acien A. Electronic Cigarette Use and Blood Pressure Endpoints: a Systematic Review. Curr Hypertens Rep. 2021 Jan 23;23(1):2.  
70. Bezerra HC de J, Gaudêncio E de O, Batista JR de M, De Lucena M do SR, De Oliveira AR. A RELAÇÃO ENTRE HIPERTENSÃO ARTERIAL, ANSIEDADE E ESTRESSE: UMA REVISÃO INTEGRATIVA DA LITERATURA. Psicol Estud. 2021 Nov 12;26.  
71. Johnson HM. Anxiety and Hypertension: Is There a Link? A Literature Review of the Comorbidity Relationship Between Anxiety and Hypertension. Curr Hypertens Rep. 2019 Sep 18;21(9):66.  
72. World Health Organization. WHO Report on the Global Tobacco Epidemic. Geneva, Switzerland: World Health Organization; 2017.  
73. Khoramdad M, Vahedian‐azimi A, Karimi L, Rahimi‐Bashar F, Amini H, Sahebkar A. Association between passive smoking and cardiovascular disease: A systematic review and meta‐analysis. IUBMB Life. 2020 Apr 13;72(4):677–86.  
74. Brasil. Portaria conjunta n<sup>o</sup> 10, de 16 de abril de 2020 - Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Tabagismo. [Internet]. Brasília: Diário Oficial da União; 2020. p. 74. Available from: http://conitec.gov.br/images/Protocolos/PCDT_Tabagismo.pdf  
75. Brasil. Ministério da Saúde. GUIA DE ATIVIDADE FÍSICA PARA A POPULAÇÃO BRASILEIRA [Internet]. Brasília ; 2021 [cited 2024 Jul 25]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/guia_atividade_fisica_populacao_brasileira.pdf  
76. WHO. WHO guidelines on physical activity and sedentary behaviour. Geneva;  
2020.  
77. Liu XJ, Zhang DD, Liu Y, Sun XZ, Han CY, Wang BY, et al. Dose-Response Association Between Physical Activity and Incident Hypertension A Systematic Review and Meta-Analysis of Cohort Studies. Hypertension. 2017;69(5):813-+.  
78. Leitzmann MF, Park Y, Blair A, Ballard-Barbash R, Mouw T, Hollenbeck AR, et al. Physical activity recommendations and decreased risk of mortality. Arch Intern Med. 2007;167(22):2453–60.  
79. ACSM. ACSM’s Guidelines for Exercise Testing and Prescription. Philadelphia: Lippincott Williams and Wilkins; 2006.  
80. Saco‐Ledo G, Valenzuela PL, Ruiz‐Hurtado G, Ruilope LM, Lucia A. Exercise Reduces Ambulatory Blood Pressure in Patients With Hypertension: A Systematic Review and Meta‐Analysis of Randomized Controlled Trials. J Am Heart Assoc. 2020 Dec 15;9(24).  
81. MacDonald H V., Johnson BT, Huedo‐Medina TB, Livingston J, Forsyth KC, Kraemer WJ, et al. Dynamic Resistance Training as Stand‐Alone Antihypertensive Lifestyle Therapy: A Meta‐Analysis. J Am Heart Assoc. 2016 Oct 3;5(10).  
65  
82. Brasil. Ministério da Saúde. Portaria de consolidação no 2, de 28 de setembro de 2017 [Internet]. Brasil. Ministério da Saúde. 2024 [cited 2024 Jul 25]. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html  
83. Meneghelo  C.G.S.; Stein, R.; Mastrocolla, L.E.; Albuquerque, P.F.; Serra, S.M. RS; A. III Diretrizes da Sociedade Brasileira de Cardiologia sobre teste ergométrico. Arq Bras Cardiol. 2010;95:26.  
84. Liu MY, Li N, Li WA, Khan H. Association between psychosocial stress and hypertension: a systematic review and meta-analysis. Neurol Res. 2017 Jun 3;39(6):573–80.  
85. Solano López AL. Effectiveness of the Mindfulness‐Based Stress Reduction Program on Blood Pressure: A Systematic Review of Literature. Worldviews Evid Based Nurs. 2018 Oct 19;15(5):344–52.  
86. Conversano C, Orrù G, Pozza A, Miccoli M, Ciacchini R, Marchi L, et al. Is Mindfulness-Based Stress Reduction Effective for People with Hypertension? A Systematic Review and Meta-Analysis of 30 Years of Evidence. Int J Environ Res Public Health. 2021 Mar 11;18(6):2882.  
87. Levine GN, Lange RA, Bairey‐Merz CN, Davidson RJ, Jamerson K, Mehta PK, et al. Meditation and Cardiovascular Risk Reduction. J Am Heart Assoc. 2017 Oct 11;6(10).  
88. Ooi SL, Giovino M, Pak SC. Transcendental meditation for lowering blood pressure: An overview of systematic reviews and meta-analyses. Complement Ther Med. 2017 Oct;34:26–34.  
89. Gathright EC, Salmoirago-Blotcher E, DeCosta J, Balletto BL, Donahue ML, Feulner MM, et al. The impact of transcendental meditation on depressive symptoms and blood pressure in adults with cardiovascular disease: A systematic review and meta-analysis. Complement Ther Med. 2019 Oct;46:172–9.  
90. Nalbant G, Hassanein ZM, Lewis S, Chattopadhyay K. Content, Structure, and Delivery Characteristics of Yoga Interventions for Managing Hypertension: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. Front Public Health. 2022 Mar 28;10.  
91. NICE. Hypertension in adults: diagnosis and management [H] Evidence review for relaxation therapies. 2019;48.  
92. Patel C, Marmot M. Can general practitioners use training in relaxation and management of stress to reduce mild hypertension? BMJ. 1988 Jan 2;296(6614):21–4.  
93. Précoma DB, Oliveira GMM de, Simão AF, Dutra OP, Coelho-Filho OR, Izar MC de O, et al. Updated Cardiovascular Prevention Guideline of the Brazilian Society of Cardiology - 2019. Arq Bras Cardiol. 2019;  
94. Arnett DK, Blumenthal RS, Albert MA, Buroker AB, Goldberger ZD, Hahn EJ, et al. 2019 ACC/AHA Guideline on the Primary Prevention of Cardiovascular Disease: A Report of the American College of Cardiology/American Heart Association Task Force on Clinical Practice Guidelines. Circulation. 2019 Sep 10;140(11).  
95. Osborne MT, Shin LM, Mehta NN, Pitman RK, Fayad ZA, Tawakol A. Disentangling the Links Between Psychosocial Stress and Cardiovascular Disease. Circ Cardiovasc Imaging. 2020 Aug;13(8).  
96. Mendes EV. O cuidado das condições crônicas na atenção primária à saúde: o imperativo da consolidação da estratégia da saúde da família [Internet]. Brasília; 2012 [cited 2024  
66  
Jul 25]. Available from: https://iris.paho.org/bitstream/handle/10665.2/49107/9788579670787por.pdf?sequence=1&isAllowed=y  
97. Innab A, Kerari A. Impact of Behavioral Interventions on Patient Activation in Adults with Hypertension: A Systematic Review and Meta-Analysis. INQUIRY: The Journal of Health Care Organization, Provision, and Financing. 2022 Jan 29;59:004695802210904.  
98. Organização Pan-Americana da Saúde - OPAS. HEARTS Pacote de medidas técnicas para manejo da doença cardiovascular na atenção primária à saúde. Guia de implementação. [Internet]. Washington, D.C; 2019 [cited 2024 Jul 25]. Available from: https://iris.paho.org/bitstream/handle/10665.2/51769/OPASNMH19001_por.pdf?sequence=1&is Allowed=y  
99. Chang Y, Woo HG, Park J, Lee JS, Song TJ. Improved oral hygiene care is associated with decreased risk of occurrence for atrial fibrillation and heart failure: A nationwide population-based cohort study. Eur J Prev Cardiol. 2020 Nov 1;27(17):1835–45.  
100. Brasil. Ministério da Saúde. Estratégias para o cuidado da pessoa com doença crônica: hipertensão arterial sistêmica. Brasília; 2013.  
101. ANDRADE ED de;, RANALI J, VOLPATO MC. Terapêutica medicamentosa em odontologia: procedimentos clínicos e uso de medicamentos nas principais situaçöes da prática odontológica. In: Pacientes que requerem cuidados especiais. 2002. p. 93–140.  
102. Davenport RE, Porcelli RJ, Iacono VJ, Bonura CF, Mallis GI, Baer PN. Effects of Anesthetics Containing Epinephrine on Catecholamine Levels During Periodontal Surgery. J Periodontol. 1990 Sep;61(9):553–8.  
103. Hawwa N, Vest AR, Kumar R, Lahoud R, Young JB, Wu Y, et al. Comparison Between the Kansas City Cardiomyopathy Questionnaire and New York Heart Association in Assessing Functional Capacity and Clinical Outcomes. J Card Fail. 2017 Apr;23(4):280–5.  
104. Herman WW, Ferguson HW. Dental care for patients with heart failure. The Journal of the American Dental Association. 2010 Jul;141(7):845–53.  
105. Peralta CC, Castro AL de;, Castro JCB de;, Inada M, Cabrera MA de;, Dossi MC, et al. Hipertensão arterial: um risco para tratamento odontológico / Arterial hypertension: a risk in dentistry treatment. Rev Fac Odontol Lins . 1995 Jan;8(1):16–22.  
106. Sperotto F, France K, Gobbo M, Bindakhil M, Pimolbutr K, Holmes H, et al. Antibiotic Prophylaxis and Infective Endocarditis Incidence Following Invasive Dental Procedures. JAMA Cardiol. 2024 Jul 1;9(7):599.  
107. American Heart Association. Prophylaxis recommendations for infective endocarditis. Circulation. 1995;96(1):258–366.  
108. Brasil. Ministério da Saúde. A saúde bucal no Sistema Único de Saúde [Internet]. Brasília; 2018 [cited 2025 Jan 22]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/saude_bucal_sistema_unico_saude.pdf  
109. Ettehad D, Emdin CA, Kiran A, Anderson SG, Callender T, Emberson J, et al. Blood pressure lowering for prevention of cardiovascular disease and death: a systematic review and meta-analysis. The Lancet. 2016 Mar;387(10022):957–67.  
110. Thomopoulos C, Parati G, Zanchetti A. Effects of blood pressure lowering on outcome incidence in hypertension. 1. Overview, meta-analyses, and meta-regression analyses of randomized trials. J Hypertens. 2014 Dec;32(12):2285–95.  
67  
111. Thomopoulos C, Parati G, Zanchetti A. Effects of blood-pressure-lowering treatment on outcome incidence. 12. Effects in individuals with high-normal and normal blood pressure. J Hypertens. 2017 Nov;35(11):2150–60.  
112. Thomopoulos C, Parati G, Zanchetti A. Effects of blood pressure-lowering on outcome incidence in hypertension. J Hypertens. 2015 Jul;33(7):1321–41.  
113. Sousa CT, Ribeiro A, Barreto SM, Giatti L, Brant L, Lotufo P, et al. Diferenças Raciais no Controle da Pressão Arterial em Usuários de Anti-Hipertensivos em Monoterapia: Resultados do Estudo ELSA-Brasil. Arq Bras Cardiol. 2022 Mar 11;118(3):614–22.  
114. Chow CK. Prevalence, Awareness, Treatment, and Control of Hypertension in Rural and Urban Communities in High-, Middle-, and Low-Income Countries. JAMA. 2013 Sep 4;310(9):959.  
115. Corrao G, Parodi A, Nicotra F, Zambon A, Merlino L, Cesana G, et al. Better compliance to antihypertensive medications reduces cardiovascular risk. J Hypertens. 2011 Mar;29(3):610–8.  
116. Gupta P, Patel P, Štrauch B, Lai FY, Akbarov A, Gulsin GS, et al. Biochemical Screening for Nonadherence Is Associated With Blood Pressure Reduction and Improvement in Adherence. Hypertension. 2017 Nov;70(5):1042–8.  
117. Wang YR. Outpatient Hypertension Treatment, Treatment Intensification, and Control in Western Europe and the United States. Arch Intern Med. 2007 Jan 22;167(2):141.  
118. Chow CK. Prevalence, Awareness, Treatment, and Control of Hypertension in Rural and Urban Communities in High-, Middle-, and Low-Income Countries. JAMA. 2013 Sep;310(9):959.  
119. Wald DS, Law M, Morris JK, Bestwick JP, Wald NJ. Combination Therapy Versus Monotherapy in Reducing Blood Pressure: Meta-analysis on 11,000 Participants from 42 Trials. Am J Med. 2009 Mar;122(3):290–300.  
120. Williams B, MacDonald TM, Morant S, Webb DJ, Sever P, McInnes G, et al. Spironolactone versus placebo, bisoprolol, and doxazosin to determine the optimal treatment for drug-resistant hypertension (PATHWAY-2): a randomised, double-blind, crossover trial. The Lancet. 2015 Nov;386(10008):2059–68.  
121. Krieger EM, Drager LF, Giorgi DMA, Pereira AC, Barreto-Filho JAS, Nogueira AR, et al. Spironolactone Versus Clonidine as a Fourth-Drug Therapy for Resistant Hypertension. Hypertension. 2018 Apr;71(4):681–90.  
122. Pio-Abreu A, Drager LF. Resistant Hypertension: Time to Consider the Best Fifth Anti-Hypertensive Treatment. Curr Hypertens Rep. 2018 Aug 16;20(8):67.  
123. Yugar-Toledo JC, Moreno Júnior H, Gus M, Rosito GBA, Scala LCN, Muxfeldt ES, et al. Posicionamento Brasileiro sobre Hipertensão Arterial Resistente – 2020. Arq Bras Cardiol. 2020;  
124. Elliott WJ, Varon J. Evaluation and treatment of hypertensive emergencies in adults. UpToDate [Internet]. 2023 Jun 14 [cited 2025 Jan 23]; Available from: https://www.uptodate.com/contents/evaluation-and-treatment-of-hypertensive-emergencies-inadults  
125. Dynamed. Hypertensive Crisis. EBSCO Information Services.  
68  
126. Rabi DM, McBrien KA, Sapir-Pichhadze R, Nakhla M, Ahmed SB, Dumanski SM, et al. Hypertension Canada’s 2020 Comprehensive Guidelines for the Prevention, Diagnosis, Risk Assessment, and Treatment of Hypertension in Adults and Children. Canadian Journal of Cardiology. 2020 May;36(5):596–624.  
127. Ferguson MA, Flynn JT. Rational use of antihypertensive medications in children. Pediatric Nephrology. 2014 Jun 29;29(6):979–88.  
128. Meher S, Abalos E, Carroli G. Bed rest with or without hospitalisation for hypertension during pregnancy. Cochrane Database of Systematic Reviews. 2005 Oct 19;2010(2).  
129. Abalos E, Duley L, Steyn DW, Gialdini C. Antihypertensive drug therapy for mild to moderate hypertension during pregnancy. Cochrane Database of Systematic Reviews. 2018 Oct 1;2018(10).  
130. NICE. Hypertension in Pregnancy [B] Evidence review for monitoring gestational hypertension. 2019. p. 82.  
131. Brasil. Ministério da Saúde. ELENCO DE MEDICAMENTOS E INSUMOS DO PROGRAMA FARMÁCIA POPULAR DO BRASIL [Internet]. Ministério da Saúde. Programa Farmácia Popular do Brasil - PFPB. 2024 [cited 2024 Aug 1]. Available from: https://www.gov.br/saude/pt-br/composicao/sectics/farmacia-popular/arquivos/elenco-demedicamentos-e-insumos.pdf  
132. Zhou B, Danaei G, Stevens GA, Bixby H, Taddei C, Carrillo-Larco RM, et al. Long-term and recent trends in hypertension awareness, treatment, and control in 12 high-income countries: an analysis of 123 nationally representative surveys. The Lancet. 2019 Aug;394(10199):639–51.  
133. Lopes RD, Barroso WKS, Brandao AA, Barbosa ECD, Malachias MVB, Gomes MM, et al. The First Brazilian Registry of Hypertension. Am Heart J. 2018 Nov;205:154–7.  
134. Picon R V., Dias-Da-Costa JS, Fuchs FD, Olinto MTA, Choudhry NK, Fuchs SC. Hypertension Management in Brazil: Usual Practice in Primary Care—A Meta-Analysis. Int J Hypertens. 2017;2017:1–9.  
135. Pierin AMG, Marroni SN, Taveira LAF, Benseñor IJM. Controle da hipertensão arterial e fatores associados na atenção primária em Unidades Básicas de Saúde localizadas na Região Oeste da cidade de São Paulo. Cien Saude Colet. 2011;16(suppl 1):1389–400.  
136. World Health Organization. Adherence to long-term therapies: evidence for action. Geneva: WHO; 2003.  
137. Vrijens B, De Geest S, Hughes DA, Przemyslaw K, Demonceau J, Ruppar T, et al. A new taxonomy for describing and defining adherence to medications. Br J Clin Pharmacol. 2012 May;73(5):691–705.  
138. Burnier M, Egan BM. Adherence in Hypertension. Circ Res. 2019 Mar 29;124(7):1124–40.  
139. Dhar L, Dantas J, Ali M. A Systematic Review of Factors Influencing Medication Adherence to Hypertension Treatment in Developing Countries. Open J Epidemiol. 2017;07(03):211–50.  
140. Abegaz TM, Shehab A, Gebreyohannes EA, Bhagavathula AS, Elnour AA. Nonadherence to antihypertensive drugs. Medicine. 2017 Jan;96(4):e5641.  
69  
141. Glynn LG, Murphy AW, Smith SM, Schroeder K, Fahey T. Interventions used to improve control of blood pressure in patients with hypertension. Cochrane Database of Systematic Reviews. 2010 Mar 17;(3).  
142. Shahaj O, Denneny D, Schwappach A, Pearce G, Epiphaniou E, Parke HL, et al. Supporting self-management for people with hypertension. J Hypertens. 2019 Feb;37(2):264–79.  
143. Sherrill B, Halpern M, Khan S, Zhang J, Panjabi S. Single-Pill vs Free-Equivalent Combination Therapies for Hypertension: A Meta-Analysis of Health Care Costs and Adherence. The Journal of Clinical Hypertension. 2011 Dec;13(12):898–909.  
144. Gwadry-Sridhar FH, Manias E, Lal L, Salas M, Hughes DA, Ratzki-Leewing A, et al. Impact of Interventions on Medication Adherence and Blood Pressure Control in Patients with Essential Hypertension: A Systematic Review by the ISPOR Medication Adherence and Persistence Special Interest Group. Value in Health. 2013 Jul;16(5):863–71.  
145. Conn VS, Ruppar TM. Medication adherence outcomes of 771 intervention trials: Systematic review and meta-analysis. Prev Med (Baltim). 2017 Jun;99:269–76.  
146. Guimarães MCLP, Coelho JC, Silva GV da, Drager LF, Gengo e Silva Butcher R de C, Butcher HK, et al. Blood Pressure Control and Adherence to Drug Treatment in Patients with Hypertension Treated at a Specialized Outpatient Clinic: A Cross-Sectional Study. Patient Prefer Adherence. 2021 Dec;Volume 15:2749–61.  
147. Gupta AK, Arshad S, Poulter NR. Compliance, Safety, and Effectiveness of Fixed-Dose Combinations of Antihypertensive Agents. Hypertension. 2010 Feb;55(2):399–407.  
148. Santschi V, Chiolero A, Colosimo AL, Platt RW, Taffé P, Burnier M, et al. Improving blood pressure control through pharmacist interventions: a meta-analysis of randomized controlled trials. Journal of the American Heart Association. 2014.  
149. Christensen A, Osterberg LG, Hansen EH. Electronic monitoring of patient adherence to oral antihypertensive medical treatment: a systematic review. J Hypertens. 2009 Aug;27(8):1540–51.  
150. Rudd P, Miller NH, Kaufman J, Kraemer HC, Bandura A, Greenwald G, et al. Nurse management for hypertension. A systems approach. Am J Hypertens. 2004 Oct;17(10):921– 7.  
151. Checchi KD, Huybrechts KF, Avorn J, Kesselheim AS. Electronic Medication Packaging Devices and Medication Adherence. JAMA. 2014 Sep 24;312(12):1237.  
152. Omboni S, Gazzola T, Carabelli G, Parati G. Clinical usefulness and cost effectiveness of home blood pressure telemonitoring. J Hypertens. 2013 Mar;31(3):455–68.  
153. Tan JP, Cheng KKF, Siah RC. A systematic review and meta‐analysis on the effectiveness of education on medication adherence for patients with hypertension, hyperlipidaemia and diabetes. J Adv Nurs. 2019 Nov 24;75(11):2478–94.  
154. Tucker KL, Sheppard JP, Stevens R, Bosworth HB, Bove A, Bray EP, et al. Selfmonitoring of blood pressure in hypertension: A systematic review and individual patient data meta-analysis. Rahimi K, editor. PLoS Med. 2017 Sep 19;14(9):e1002389.  
155. Chan AHY, Foot H, Pearce CJ, Horne R, Foster JM, Harrison J. Effect of electronic adherence monitoring on adherence and outcomes in chronic conditions: A systematic review and meta-analysis. Florez ID, editor. PLoS One. 2022 Mar 21;17(3):e0265715.  
70  
156. Schmidt BM, Durao S, Toews I, Bavuma CM, Hohlfeld A, Nury E, et al. Screening strategies for hypertension. Cochrane Database of Systematic Reviews. 2020 May 7;2020(5).  
157. Townsend, Raymond R Cohen J. Out-of-office blood pressure measurement: Ambulatory and self-measured blood pressure monitoring [Internet]. UpToDate. Available from: https://www.uptodate.com/contents/out-of-office-blood-pressure-measurement-ambulatory-andself-measured-blood-pressure-monitoring?search=hypertension follow up&topicRef=3879&source=see_link  
71

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ATENOLOL, BESILATO DE ANLODIPINO, CAPTOPRIL, CARVEDILOL, MESILATO DE DOXAZOSINA, MALEATO DE ENALAPRIL, ESPIRONOLACTONA, FUROSEMIDA, CLORIDRATO DE HIDRALAZINA, HIDROCLOROTIAZIDA, LOSARTANA POTÁSSICA, METILDOPA, SUCCINATO DE METOPROLOL, TARTARATO DE METOPROLOL, NIFEDIPINO, CLORIDRATO DE PROPRANOLOL E CLORIDRATO DE VERAPAMIL  
Eu, __________________________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **besilato de anlodipino, atenolol, captopril, carvedilol, mesilato de doxazosina, maleato de enalapril, espironolactona, furosemida, cloridrato de hidralazina, hidroclorotiazida, losartana potássica, metildopa, succinato de metoprolol, tartarato de metoprolol, nifedipino, cloridrato de propranolol** e **cloridrato de verapamil** , indicados para o tratamento da **hipertensão arterial sistêmica** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios principais:  
- redução da pressão arterial sistólica e diastólica;  
- redução do risco de eventos cardiovasculares;  
- redução do risco de morte.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
 **Besilato de anlodipino:** não deve ser utilizado por mulheres grávidas sem orientação médica. Os eventos adversos mais comuns são rubor facial, cefaleia, edema de membros inferiores, constipação, tontura, vertigem, tremores, taquicardia, hipotensão e sensação de mal-estar. **Nifedipino:** casos de choque cardiovascular; gravidez antes da 20ª semana de gestação e durante a amamentação. Não deve ser usado em associação com a rifampicina, pois, devido à indução enzimática, o nifedipino pode não atingir níveis plasmáticos eficazes. Os eventos adversos mais comuns são rubor facial, cefaleia, edema de membros inferiores, constipação, tontura, vertigem, tremores, taquicardia, hipotensão e sensação de mal-estar. **Atenolol:** bradicardia, choque cardiogênico, hipotensão, acidose metabólica, distúrbios graves da circulação arterial periférica, bloqueio cardíaco de segundo ou terceiro grau, síndrome do nodo sinusal, feocromocitoma não tratado, insuficiência cardíaca descompensada.  
- **Carvedilol:** insuficiência cardíaca descompensada/instável, que exija terapia inotrópica intravenosa; insuficiência hepática clinicamente manifesta; asma brônquica ou doença pulmonar obstrutiva crônica com componente broncoespástico; bloqueio atrioventricular de segundo ou terceiro grau (a menos que o paciente tenha um marca-passo permanente); bradicardia grave (< 50 batimentos por minuto); síndrome do nó sinusal (incluindo bloqueio  
72  
sinoatrial); choque cardiogênico; hipotensão grave (pressão arterial sistólica < 85 mmHg); pessoas com insuficiência de sacarose-isomaltase.  
**Succinato de metoprolol:** hipersensibilidade a outros betabloqueadores, Bloqueio atrioventricular de grau II ou de grau III, pacientes com insuficiência cardíaca não compensada instável (edema pulmonar, hipoperfusão ou hipotensão), e pacientes com terapia inotrópica contínua ou intermitente agindo por meio de agonista do receptor beta, bradicardia sinusal clinicamente relevante, síndrome do nó sino-atrial (a não ser que um marcapasso permanente esteja em uso), choque cardiogênico e arteriopatia periférica grave. O metoprolol não deve ser administrado em pacientes com suspeita de infarto agudo do miocárdio, enquanto a frequência cardíaca for < 45 batimentos/minuto, o intervalo PQ for > 0,24 segundos ou a pressão sistólica for < 100 mmHg.  
 **Tartarato de metoprolol:** hipersensibilidade a outros betabloqueadores, Bloqueio atrioventricular de grau II ou III insuficiência cardíaca não compensada; Bradicardia sinusal clinicamente relevante (frequência cardíaca menor que 45 a 50 batimentos por minuto); Doença do nó sinusal; Distúrbios circulatórios arteriais periféricos graves; Choque cardiogênico; Feocromocitoma não tratado; Hipotensão; Asma brônquica grave ou história de broncoespasmo grave; Infarto do miocárdio com frequência cardíaca menor que 45 a 50 batimentos por minuto, intervalo P-R maior que 0,24 segundos, pressão sistólica menor que 100 mmHg e/ou insuficiência cardíaca grave.  
- **Cloridrato de propranolol:** hipotensão; bradicardia; distúrbios graves da circulação arterial periférica; síndrome do nó sinoatrial; feocromocitoma não tratado (com um antagonista do receptor alfa-adrenérgico); insuficiência cardíaca descompensada; angina de Prinzmetal; choque cardiogênico; acidose metabólica; pacientes com predisposição à hipoglicemia, isto é, após jejum prolongado ou pacientes com reservas contrarregulatórias restritas; bloqueio cardíaco de segundo ou terceiro grau; histórico de asma brônquica ou broncoespasmo.  
- **Captopril:** hipersensibilidade a outro inibidor da IECA; não deve ser utilizado por mulheres grávidas sem orientação médica. Tosse seca, piora da função renal, em geral, transitória, hipercalemia em pacientes com insuficiência renal, são os principais eventos adversos  
- **Maleato de enalapril:** pacientes com histórico de edema angioneurótico relacionado a utilização de inibidores da enzima conversora de angiotensina e pacientes com angioedema hereditário ou idiopático. Não deve ser administrado com alisquireno em pacientes com diabetes. É contraindicado em combinação com um inibidor de neprilisina (por exemplo, sacubitril), devendo ser administrado 36 horas antes ou depois de utilizar sacubitri valsartana. Tosse seca, piora da função renal, em geral, transitória, hipercalemia em pacientes com insuficiência renal, são os principais eventos adversos  
- **Mesilato de doxazosina:** hipersensibilidade a outros tipos de quinazolinas (por exemplo, prazosina, terazosina), história de hipotensão ortostática, hiperplasia prostática benigna e congestão concomitante do trato urinário superior, infecção crônica do trato urinário ou cálculos na bexiga, pacientes com histórico de obstrução gastrointestinal, obstrução esofágica ou qualquer grau de diminuição do diâmetro do lúmen do trato gastrointestinal. Está contraindicado como monoterapia em pacientes com transbordamento da bexiga ou anúria com ou sem insuficiência renal progressiva. Eventos adversos incluem hipotensão postural e incontinência urinária e aumento da incidência de insuficiência cardíaca.  
- **Espironolactona:** insuficiência renal aguda, diminuição significativa da função renal, anúria; doença de Addison; hipercalemia; uso concomitante de eplerenona; fraqueza; cãibras; hipovolemia e disfunção erétil.  
- **Furosemida:** lactantes, pacientes com insuficiência renal com anúria, pré-coma e coma associado à encefalopatia hepática, hipopotassemia severa, hiponatremia severa, hipovolemia (com ou sem hipotensão) ou desidratação, hipersensibilidade às sulfonamidas. Não deve ser usado por pessoas com síndrome de má-absorção de glicose-galactose.  
73  
- **Cloridrato de hidralazina:** lúpus eritematoso sistêmico idiopático e doenças correlatas, taquicardia grave e insuficiência cardíaca com alto débito cardíaco (por exemplo, em tireotoxicose), insuficiência do miocárdio devido à obstrução mecânica (por exemplo, em estenose aórtica ou mitral e na pericardite constritiva); insuficiência cardíaca isolada do ventrículo direito devido à hipertensão pulmonar ( _cor pulmonale_ ); e aneurisma dissecante da aorta. Eventos adversos incluem cefaleia, flushing, taquicardia reflexa e reação lupus-like.  
- **Hidroclorotiazida:** comprometimento grave da função renal (depuração da creatinina abaixo de 30 mL/min), com distúrbio hepático grave, icterícia em crianças, com distúrbio grave do equilíbrio de eletrólitos, anúria. Não deve ser usado por pessoas com síndrome de máabsorção de glicose-galactose.  
- **Losartana potássica:** insuficiência hepática grave. O uso concomitante com produtos contendo alisquireno é contraindicado em pacientes com diabetes e insuficiência renal (TGF < 60 mL/min/1,73m<sup>2</sup> ). O medicamento não deve ser administrado durante o segundo ou o terceiro trimestre de gestação.  
- **Metildopa:** hepatopatias ativas, tais como hepatite aguda e cirrose ativa; tratamento com inibidores da monoaminoxidase (MAO). Eventos adversos incluem febre, anemia hemolítica e galactorreia.  
 **Cloridrato de verapamil** : choque cardiogênico; bloqueio atrioventricular de segundo ou terceiro grau (exceto em pacientes com marcapasso artificial em funcionamento); síndrome do nódulo sinusal (exceto em pacientes com marcapasso artificial em funcionamento); insuficiência cardíaca com fração de ejeção menor que 35 % e/ou pressão pulmonar acima de 20 mmHg (a não ser que secundário para taquicardia supraventricular sensível ao tratamento com verapamil); “flutter” ou fibrilação atrial na presença de feixes de condução acessórios (ou seja, síndrome de _WolffParkinson-White_ e _Lown-Ganong-Levine_ ). Eventos adversos incluem edema maleolar, a cefaleia latejante, a constipação e as tonturas.  
Fui informado que todos os medicamentos são contraindicados em caso de hipersensibilidade (alergia) aos medicamentos ou aos componentes da fórmula e que o risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este(s) medicamento(s) somente pode(m) ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser atendido(a), inclusive em caso de desistir de usar o(s) medicamento(s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- ( ) Sim ( ) Não  
Meu tratamento constará de um ou mais dos seguintes medicamentos:  
- (  ) Besilato de anlodipino  
- (  ) Atenolol  
- (  ) Captopril  
- (  ) Carvedilol  
- (  ) Mesilato de doxazosina  
- (  ) Espironolactona  
- (  ) Furosemida  
- ( ) Cloridrato de hidralazina  
- (  ) Hidroclorotiazida  
- (  ) Losartana potássica  
- (  ) Maleato de enalapril (  ) Metildopa  
74  
- (  ) Succinato de metoprolol (  ) Cloridrato de propranolol  
- (  ) Tartarato de metoprolol  
- (  ) Cloridrato de verapamil  
- (  ) Nifedipino  
|Local:Data:|
|---|
|Nome dopaciente:|
|CartãoNacional deSaúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|
|_____________________________________<br>Assinatura dopaciente ou do responsável legal|
|Médico Responsável:<br>CRM:<br>UF:|
|_____________________________________________<br>Assinatura e carimbo do médico|  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
75

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **MATERIAL SUPLEMENTAR 1 – VALORES DA PRESSÃO ARTERIAL PARA CRIANÇAS** -->
Tabela S1. Valores de pressão arterial para meninos de acordo com a idade e o percentil de estatura.  
|**Idade**<br>**(anos)**|**Percentil da**<br>**PA**|**Perce**<br>|**Press**<br>**ntis da **<br>|**ão Arte**<br>**Estatura**<br>|**rial Sist**<br> **ou Me**<br>|**ólica (m**<br>**dida da **<br>|**mHg)**<br>**Estatura**<br>|**(cm)**<br>|**Perce**<br>|**Press**<br>**ntis da **<br>|**ão Arter**<br>**Estatur**<br>|**ial Dias**<br>**a ou Me**<br>|**tólica (m**<br>**dida da **<br>|**mHg)**<br>**Estatur**<br>|**a (cm)**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|
|1|Estatura(cm)|77,2|78,3|80,2|82,4|84,6|86,7|87,9|77,2|78,3|80,2|82,4|84,6|86,7|87,9|
||P50|85|85|86|86|87|88|88|40|40|40|41|41|42|42|
||P90|98|99|99|100|100|101|101|52|52|53|53|54|54|54|
||P95|102|102|103|103|104|105|105|54|54|55|55|56|57|57|
||P95+ 12 mmHg|114|114|115|115|116|117|117|66|66|67|67|68|69|69|
|2|Estatura(cm)|86,1|87,4|89,6|92,1|94,7|97,1|98,5|86,1|87,4|89,6|92,1|94,7|97,1|98,5|
||P50|87|87|88|89|89|90|91|43|43|44|44|45|46|46|
||P90|100|100|101|102|103|103|104|55|55|56|56|57|58|58|
||P95|104|105|105|106|107|107|108|57|58|58|59|60|61|61|
||P95 + 12 mmHg|116|117|117|118|119|119|120|69|70|70|71|72|73|73|
|3|Estatura(cm)|92,5|93,9|96,3|99|101,8|104,3|105,8|92,5|93,9|96,3|99|101,8|104,3|105,8|
||P50|88|89|89|90|91|92|92|45|46|46|47|48|49|49|
||P90|101|102|102|103|104|105|105|58|58|59|59|60|61|61|
||P95|106|106|107|107|108|109|109|60|61|61|62|63|64|64|
||P95 + 12 mmHg|118|118|119|119|120|121|121|72|73|73|74|75|76|76|
|4|Estatura(cm)|98,5|100,2|102,9|105,9|108,9|111,5|113,2|98,5|100,2|102,9|105,9|108,9|111,5|113,2|
||P50|90|90|91|92|93|94|94|48|49|49|50|51|52|52|
||P90|102|103|104|105|105|106|107|60|61|62|62|63|64|64|
||P95|107|107|108|108|109|110|110|63|64|65|66|67|67|68|
||P95 + 12 mmHg|119|119|120|120|121|122|122|75|76|77|78|79|79|80|
|5|Estatura(cm)|104,4|106,2|109,1|112,4|115,7|118,6|120,3|104,4|106,2|109,1|112,4|115,7|118,6|120,3|
||P50|91|92|93|94|95|96|96|96|51|52|53|54|55|55|
||P90|103|104|105|106|107|108|108|63|64|65|65|66|67|67|
||P95|107|108|109|109|110|111|112|66|67|68|69|70|70|71|
||P95 + 12 mmHg|119|120|121|121|122|123|124|78|79|80|81|82|82|83|
|6|Estatura(cm)|110,3|112,2|115,3|118,9|122,4|125,6|127,5|110,3|112,2|115,3|118,9|122,4|125,6|127,5|
||P50|93|93|94|95|96|97|98|54|54|55|56|57|57|58|  
76  
|**Idade**<br>**(anos)**|**Percentil da**<br>**PA**|**Perce**|**Press**<br>**ntis da**|**ão Arte**<br>**Estatura**|**rial Sist**<br>**ou Me**|**ólica (m**<br>**dida da**|**mHg)**<br>**Estatura**|**(cm)**|**Perce**|**Press**<br>**ntis da**|**ão Arter**<br>**Estatur**|**ial Dias**<br>**a ou Me**|**tólica (m**<br>**dida da**|**mHg)**<br>**Estatur**|**a (cm)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|
||P90|105|105|106|107|109|110|110|66|66|67|68|68|69|69|
||P95|108|109|110|111|112|113|114|69|70|70|71|72|72|73|
||P95 + 12 mmHg|120|121|122|123|124|125|126|81|82|82|83|84|84|85|
|7|Estatura(cm)|116,1|118|121,4|125,1|128,9|123,4|134,5|116,1|118|121,4|125,1|128,9|132,4|134,5|
||P50|94|94|95|97|98|98|99|56|56|57|58|58|59|59|
||P90|106|107|108|109|110|111|111|68|68|69|70|70|71|71|
||P95|110|110|111|112|114|115|116|71|71|72|73|73|74|74|
||P95 + 12 mmHg|122|122|123|124|126|127|128|83|83|84|85|85|86|86|
|8|Estatura(cm)|121,4|123,5|127|131|135,1|138,8|141|121,4|123,5|127|131|135,1|138,8|141|
||P50|95|96|97|98|99|99|100|57|57|58|59|59|60|60|
||P90|107|108|109|110|111|112|112|69|70|70|71|72|72|73|
||P95|111|112|112|114|115|116|117|72|73|73|74|75|75|75|
||P95+ 12 mmHg|123|124|124|126|127|128|129|84|85|85|86|87|87|87|
|9|Estatura(cm)|126|128,3|132,1|136,3|140,7|144,7|147,1|126|128,3|132,1|136,3|140,7|144,7|147,1|
||P50|96|97|98|99|100|101|101|57|58|59|60|61|62|62|
||P90|107|108|109|110|112|113|114|70|71|72|73|74|74|74|
||P95|112|112|113|115|116|118|119|74|74|75|76|76|77|77|
||P95+ 12 mmHg|124|124|125|127|128|130|131|86|86|87|88|88|89|89|
|10|Estatura(cm)|130,2|132,7|136,7|141,3|145,9|150,1|152,7|130,2|132,7|136,7|141,3|145,9|150,1|152,7|
||P50|97|98|99|100|101|102|103|59|60|61|62|63|63|64|
||P90|108|109|111|112|113|115|116|72|73|74|74|75|75|76|
||P95|112|113|114|116|118|120|121|76|76|77|77|78|78|78|
||P95+ 12 mmHg|124|125|126|128|130|132|133|88|88|89|89|90|90|90|
|11|Estatura(cm)|134,7|137,3|141,5|146,4|151,3|155,8|158,6|134,7|137,3|141,5|146,4|151,3|155,8|158,6|
||P50|99|99|101|102|103|104|106|61|61|62|63|63|63|63|
||P90|110|111|112|114|116|117|118|74|74|75|75|75|76|76|
||P95|114|114|116|118|120|123|124|77|78|78|78|78|78|78|
||P95+ 12 mmHg|126|126|128|130|132|135|136|89|90|90|90|90|90|90|
|12|Estatura (cm)|140,3|143|147,5|152,7|157,9|162,6|165,5|140,3|143|147,5|152,7|157,9|162,6|165,5|
|||101|101|102|104|106|108|109|61|62|62|62|62|63|63|
||P50|101|101|102|104|106|108|109|61|62|62|62|62|63|63|  
77  
|**Idade**<br>**()**|**Percentil da**<br>**PA**|**Perce**|**Press**<br>**ntis da**|**ão Arte**<br>**Estatura**|**rial Sist**<br>**ou Me**|**ólica (m**<br>**dida da**|**mHg)**<br>**Estatura**|**(cm)**|**Perce**|**Press**<br>**ntis da**|**ão Arter**<br>**Estatur**|**ial Dias**<br>**a ou Me**|**tólica (m**<br>**dida da**|**mHg)**<br>**Estatur**|**a (cm)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**anos**||**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|**5%**|**10%**|**25%**|**50%**|**75%**|**90%**|**95%**|
||P90|113|114|115|117|119|121|122|75|75|75|75|75|76|76|
||P95|116|117|118|121|124|126|128|78|78|78|78|78|79|79|
||P95 + 12 mmHg|128|129|130|133|136|138|140|90|90|90|90|90|91|91|
|13|Estatura(cm)|147|150|154,9|160,3|165,7|170,5|173,4|147|150|154,9|160,3|165,7|170,5|173,4|
||P50|103|104|105|108|110|111|112|61|60|61|62|63|64|65|
||P90|115|116|118|121|124|126|126|74|74|74|75|76|77|77|
||P95|119|120|122|125|128|130|131|78|78|78|78|80|81|81|
||P95 + 12 mmHg|131|132|134|137|140|142|143|90|90|90|90|92|93|93|
|14|Estatura(cm)|153,8|156,9|162|167,5|172,7|177,4|180,1|153,8|156,9|162|167,5|172,7|177,4|180,1|
||P50|105|106|109|111|112|113|113|60|60|62|64|65|66|67|
||P90|119|120|123|126|127|128|129|74|74|75|77|78|79|80|
||P95|123|125|127|130|132|133|134|77|78|79|81|82|83|84|
||P95+ 12 mmHg|135|137|139|142|144|145|146|89|90|91|93|94|95|96|
|15|Estatura(cm)|159|162|166,9|172,2|177,2|181,6|184,2|159|162|166,9|172,2|177,2|181,6|184,2|
||P50|108|110|112|113|114|114|114|61|62|64|65|66|67|68|
||P90|123|124|126|128|129|130|130|75|76|78|79|80|81|81|
||P95|127|129|131|132|134|135|135|78|79|81|83|84|85|85|
||P95+ 12 mmHg|139|141|143|144|146|147|147|90|91|93|95|96|97|97|
|16|Estatura(cm)|162,1|165|169,6|174,6|179,5|183,8|186,4|162,1|165|169,6|174,6|179,5|183,8|186,4|
||P50|111|112|114|115|115|116|116|63|64|66|67|68|69|69|
||P90|126|127|128|129|131|131|132|77|78|79|80|81|82|82|
||P95|130|131|133|134|135|136|137|80|81|83|84|85|86|86|
||P95+ 12 mmHg|142|143|145|146|147|148|149|92|93|95|96|97|98|98|
|17|Estatura(cm)|163,8|166,5|170,9|175,8|180,7|184,9|187,5|163,8|166,5|170,9|175,8|180,7|184,9|187,5|
||P50|114|115|116|117|117|118|118|65|66|67|68|69|70|70|
||P90|128|129|130|131|132|133|134|78|79|80|81|82|82|83|
||P95|132|133|134|135|137|138|138|81|82|84|85|86|86|87|
||P95+ 12 mmHg|144|145|146|147|149|150|150|93|94|96|97|98|98|99|  
**Fonte:** Tabela extraída na íntegra da Diretriz Brasileira de HAS (2021) Barroso et al. (2021)<sup>1</sup> .  
78  
Tabela S2. Valores de pressão arterial para meninas de acordo com a idade e o percentil de estatura.  
|**Idd**|||**Press**|**ão Arte**|**rial Sist**|**ólica (m**|**mHg)**|||**Pressã**|**o Arter**|**ial Dias**|**tólica (**|**mmHg)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**ae**<br>**(anos)**|**Percentil da PA**|**Perce**|**ntis da E**|**statura**|**ou Me**|**dida da**|**Estatur**|**a (cm)**|**Perce**|**ntis da E**|**statura**|**ou Me**|**dida da**|**Estatur**|**a (cm)**|
|||5%|10%|25%|50%|75%|90%|95%|5%|10%|25%|50%|75%|90%|95%|
||Estatura(cm)|75,4|76,6|78,6|80,8|83|84,9|86,1|75,4|76,6|78,6|80,8|83|84,9|86,1|
||P50|84|85|86|86|87|88|88|41|42|42|43|44|45|46|
|1|P90|98|99|99|100|101|102|102|54|55|56|56|57|58|58|
||P95|101|102|102|103|104|105|105|59|59|60|60|61|62|62|
||P95+ 12 mmHg|113|114|114|115|116|117|117|71|71|72|72|73|74|74|
||Estatura(cm)|84,9|86,3|88,6|91,1|93,7|96|97,4|84,9|86,3|88,6|91,1|93,7|96|97,4|
||P50|87|87|88|89|90|91|91|45|46|47|48|49|50|51|
|2|P90|101|101|102|103|104|105|106|58|58|59|60|61|62|62|
||P95|104|105|106|106|107|108|109|62|63|63|64|65|66|66|
||P95+ 12 mmHg|116|117|118|118|119|120|121|74|75|75|76|77|78|78|
||Estatura(cm)|91|92,4|94,9|97,6|100,5|103,1|104,6|91|92,4|94,9|97,6|100,5|103,1|104,6|
||P50|88|89|89|90|91|92|93|48|48|49|50|51|53|53|
|3|P90|102|103|104|104|105|106|107|60|61|61|62|63|64|65|
||P95|106|106|107|108|109|110|110|64|65|65|66|67|68|69|
||P95+ 12 mmHg|118|118|119|120|121|122|122|76|77|77|78|79|80|81|
||Estatura(cm)|97,2|98,8|101,4|104,5|107,6|110,5|112,2|97,2|98,8|101,4|104,5|107,6|110,5|112,2|
||P50|89|90|91|92|93|94|94|50|51|51|53|54|55|55|
|4|P90|103|104|105|106|107|108|108|62|63|64|65|66|67|67|
||P95|107|108|109|109|110|111|112|66|67|68|69|70|70|71|
||P95 + 12 mmHg|119|120|121|121|122|123|124|78|79|80|81|82|82|83|
||Estatura(cm)|103,6|105,3|108,2|111,5|114,9|118,1|120|103,6|105,3|108,2|111,5|114,9|118,1|120|
||P50|90|91|92|93|94|95|96|52|52|53|55|56|57|57|
|5|P90|104|105|106|107|108|109|110|64|65|66|67|68|69|70|
||P95|108|109|109|110|111|112|113|68|69|70|71|72|73|73|
||P95 + 12 mmHg|120|121|121|122|123|124|125|80|81|82|83|84|85|85|
||Estatura(cm)|110|111,8|114,9|118,4|122,1|125,6|127,7|110|111,8|114,9|118,4|122,1|125,6|127,7|
||P50|92|92|93|94|96|97|97|54|54|55|56|57|58|59|
|6|P90|105|106|107|108|109|110|111|67|67|68|69|70|71|71|
||P95|109|109|110|111|112|113|114|70|71|72|72|73|74|74|  
79  
|**Idade**<br>**(anos)**|**Percentil da PA**|**Percen**<br>|**Press**<br>**tis da E**<br>|**ão Arte**<br>**statura**<br>|**rial Sist**<br>**ou Me**<br>|**ólica (m**<br>**dida da**<br>|**mHg)**<br>**Estatur**<br>|**a (cm)**<br>|**Perce**<br>|**Pressã**<br>**ntis da E**<br>|**o Arter**<br>**statura**<br>|**ial Dias**<br>**ou Me**<br>|**tólica (**<br>**dida da**<br>|**mmHg)**<br>**Estatur**<br>|**a (cm)**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||5%|10%|25%|50%|75%|90%|95%|5%|10%|25%|50%|75%|90%|95%|
||P95 + 12 mmHg|121|121|122|123|124|125|126|82|83|84|84|85|86|86|
||Estatura(cm)|115,9|117,8|121,1|124,9|128,8|132,5|134,7|115,9|117,8|121,1|124,9|128,8|132,5|134,7|
||P50|92|93|94|95|97|98|99|55|55|56|57|58|59|60|
|7|P90|106|106|107|109|110|111|112|68|68|69|70|71|72|72|
||P95|109|110|111|112|113|114|115|72|72|73|73|74|74|75|
||P95+ 12 mmHg|121|122|123|124|125|126|127|84|84|85|85|86|86|87|
||Estatura(cm)|121|123|126,5|130,6|134,7|138,5|140,9|121|123|126,5|130,6|134,7|138,5|140,9|
||P50|93|94|95|97|98|99|100|56|56|57|59|60|61|61|
|8|P90|107|107|108|110|111|112|113|69|70|71|72|72|73|73|
||P95|110|111|112|113|115|116|117|72|73|74|74|75|75|75|
||P95+ 12 mmHg|122|123|124|125|127|128|129|84|85|86|86|87|87|87|
||Estatura(cm)|125,3|127,6|131,3|135,6|140,1|144,1|146,6|125,3|127,6|131,3|135,6|140,1|144,1|146,6|
||P50|95|95|97|98|99|100|101|57|58|59|60|60|61|61|
|9|P90|108|108|109|111|112|113|114|71|71|72|73|73|73|73|
||P95|112|112|113|114|116|117|118|74|74|75|75|75|75|75|
||P95+ 12 mmHg|124|124|125|126|128|129|130|86|86|87|87|87|87|87|
||Estatura(cm)|129,7|132,2|136,3|141|145,8|150,2|152,8|129,7|132,2|136,3|141|145,8|150,2|152,8|
||P50|96|97|98|99|101|102|103|58|59|59|60|61|61|62|
|10|P90|109|110|111|112|113|115|116|72|73|73|73|73|73|73|
||P95|113|114|114|116|117|119|120|75|75|76|76|76|76|76|
||P95+ 12 mmHg|125|126|126|128|129|131|132|87|87|88|88|88|88|88|
||Estatura(cm)|135,6|138,3|142,8|147,8|152,8|157,3|160|135,6|138,3|142,8|147,8|152,8|157,3|160|
||P50|98|99|101|102|104|105|106|60|60|60|61|62|63|64|
|11|P90|111|112|113|114|116|118|120|74|74|74|74|74|75|75|
||P95|115|116|117|118|120|123|124|76|77|77|77|77|77|77|
||P95+ 12 mmHg|127|128|129|130|132|135|136|88|89|89|89|89|89|89|
||Estatura(cm)|142,8|145,5|149,9|154,8|159,6|163,8|166,4|142,8|145,5|149,9|154,8|159,6|163,8|166,4|
||P50|102|102|104|105|107|108|108|61|61|61|62|64|65|65|
|12|P90|114|115|116|118|120|122|122|75|75|75|75|76|76|76|
||P95|118|119|120|122|124|125|126|78|78|78|78|79|79|79|
||P95 + 12 mmHg|130|131|132|134|136|137|138|90|90|90|90|91|91|91|  
80  
|**Idade**<br>**(anos)**|**Percentil da PA**|**Percen**|**Press**<br>**tis da E**|**ão Arter**<br>**statura**|**ial Sist**<br>**ou Me**|**ólica (m**<br>**dida da**|**mHg)**<br>**Estatur**|**a (cm)**|**Perce**|**Pressã**<br>**ntis da E**|**o Arter**<br>**statura**|**ial Dias**<br>**ou Me**|**tólica (**<br>**dida da**|**mmHg)**<br>**Estatur**|**a (cm)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|||5%|10%|25%|50%|75%|90%|95%|5%|10%|25%|50%|75%|90%|95%|
||Estatura(cm)|148,1|150,6|154,7|159,2|163,7|167,8|170,2|148,1|150,6|154,7|159,2|163,7|167,8|170,2|
||P50|104|105|106|107|108|108|109|62|62|63|64|65|65|66|
|13|P90|116|117|119|121|122|123|123|75|75|75|76|76|76|76|
||P95|121|122|123|124|126|126|127|79|79|79|79|80|80|81|
||P95 + 12 mmHg|133|134|135|136|138|138|139|91|91|91|91|92|92|93|
||Estatura(cm)|150,6|153|156,9|161,3|165,7|169,7|172,1|150,6|153|156,9|161,3|165,7|169,7|172,1|
||P50|105|106|107|108|109|109|109|63|63|64|65|66|66|66|
|14|P90|118|118|120|122|123|123|123|76|76|76|76|77|77|77|
||P95|123|123|124|125|126|127|127|80|80|80|80|81|81|82|
||P95 + 12 mmHg|135|135|136|137|138|139|139|92|92|92|92|93|93|94|
||Estatura(cm)|151,7|154|157,9|162,3|166,7|170,6|173|151,7|154|157,9|162,3|166,7|170,6|173|
||P50|105|106|107|108|109|109|109|64|64|64|65|66|67|67|
|15|P90|118|119|121|122|123|123|124|76|76|76|77|77|78|78|
||P95|124|124|125|126|127|127|128|80|80|80|81|82|82|82|
||P95 + 12 mmHg|136|136|137|138|139|139|140|92|92|92|93|94|94|94|
||Estatura(cm)|152,1|154,5|158,4|162,8|167,1|171,1|173,4|152,1|154,5|158,4|162,8|167,1|171,1|173,4|
||P50|106|107|108|109|109|110|110|64|64|65|66|66|67|67|
|16|P90|119|120|122|123|124|124|124|76|76|76|77|78|78|78|
||P95|124|125|125|127|127|128|128|80|80|80|81|82|82|82|
||P95+ 12 mmHg|136|137|137|139|139|140|140|92|92|92|93|94|94|94|
||Estatura(cm)|152,4|154,7|158,7|163,0|167,4|171,3|173,7|152,4|154,7|158,7|163,0|167,4|171,3|173,7|
||P50|107|108|109|110|110|110|111|64|64|65|66|66|66|67|
|17|P90|120|121|123|124|124|125|125|76|76|77|77|78|78|78|
||P95|125|125|126|127|128|128|128|80|80|80|81|82|82|82|
||P95 + 12 mmHg|137|137|138|139|140|140|140|92|92|92|93|94|94|94|  
**Fonte:** Tabela extraída na íntegra da Diretriz Brasileira de HAS (2021) Barroso et al. (2021)<sup>1</sup> **.**  
**Nota:** Use valores percentuais para graduar as leituras de PA, considerando PA elevada: ≥ percentil 90; hipertensão grau 1: ≥ percentil 95; e hipertensão grau 2: ≥ percentil 95 + 12 mm Hg. Os percentis 50, 90 e 95 foram derivados usando regressão quantílica com base em crianças com peso normal (IMC < percentil 85).  
81  
Referência:  
1. Barroso WKS, Rodrigues CIS, Bortolotto LA, Mota-Gomes MA, Brandão AA,  
Feitosa AD de M, et al. Diretrizes Brasileiras de Hipertensão Arterial – 2020. Arq Bras Cardiol. 3 de março de 2021;116(3):516–658.  
82

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **MATERIAL SUPLEMENTAR 2 – MEDIDA DE PRESSÃO ARTERIAL** -->
1. Medindo a pressão arterial em consultório clínico, com aparelho eletrônico ou manual  
A medida da pressão arterial em consultório clínico pode ser realizada pela técnica auscultatória, com esfigmomanômetro aneroide e estetoscópio, ou com aparelho eletrônico, semiautomático ou automático, calibrados e validados. No entanto, se disponível, o aparelho eletrônico de manguito de braço é preferível, uma vez que as medidas apresentam maior reprodutibilidade, sendo menos influenciadas por variações da técnica utilizada ou vieses dos observadores<sup>1</sup> . Aparelhos eletrônicos sem manguito apresentam acurácia incerta, não sendo recomendado o uso para diagnóstico da HAS<sup>1</sup> .  
Para garantir que a medida da pressão arterial em consultório clínico, com aparelho eletrônico ou manual, será correta, antes de realizá-la, o paciente deve ser preparado conforme as seguintes instruções<sup>1</sup> .  
Preparo do paciente  
1. Verificar se o paciente está com a bexiga vazia; se não praticou exercícios físicos há, pelo menos, 30 minutos; se não ingeriu bebidas alcoólicas, café ou alimentos; ou fumou há 30 minutos e, em caso negativo, aguardar o tempo.  
2. Manter o indivíduo em repouso, em ambiente calmo e confortável, por 3 minutos a 5 minutos.  
3. Orientar não falar durante o procedimento, possíveis dúvidas devem ser sanadas antes ou depois.  
4. Posicionar o paciente sentado, com pernas descruzadas, pés apoiados no chão, dorso relaxado e recostado na cadeira.  
5. Posicionar o braço apoiado na altura do coração, com a palma da mão voltada para cima e sem garrotear o braço com roupas.  
6. Usar braçadeira de tamanho apropriado: a pequena para circunferência do braço entre 22 cm e 26 cm; a média para circunferência do braço entre 27 cm e 34 cm; e a grande para circunferência do braço entre 35 cm e 44 cm. A largura da bolsa inflável deve corresponder a 40% da circunferência do braço, envolvendo pelo menos 80% do braço, e ser centralizada de acordo com a marcação.  
Realização do procedimento de medida da pressão arterial com aparelho manual (técnica auscultatória)  
Nesse procedimento, as etapas 2, 3, 6 e 7 envolvem a técnica auscultatória.  
1. Colocar o manguito, sem deixar folgas, 2 cm a 3 cm acima da fossa cubital, centralizando o meio da bolsa inflável sobre a artéria braquial.  
2. <mark>Estimar o nível da pressão sistólica,</mark> por meio dos batimentos na artéria radial; fechar a válvula da pêra e inflar até o pulso desaparecer; abrir a válvula lentamente; e identificar pelo método palpatório a PAS<sup>1</sup> .  
3. Palpar a artéria braquial na fossa cubital e colocar a campânula ou o diafragma do estetoscópio sem comprimir excessivamente.  
4. Inflar rapidamente até ultrapassar o nível estimado da PAS em 20 mmHg a 30 mmHg.  
5. Realizar a deflação lentamente, cerca de 2 mmHg/segundo.  
83  
6. Identificar a pressão sistólica na ausculta do primeiro som (fase I de _Korotkoff_ ) e, depois, aumentar ligeiramente a velocidade de deflação.  
7. Identificar a PAD no desaparecimento dos sons (fase V de _Korotkoff_ ).  
8. Continuar a auscultar cerca de 20 mmHg a 30 mmHg abaixo do último som para confirmar seu desaparecimento e, depois proceder, a deflação rápida e completa. Se os sons persistirem até o zero, determinar a PAD no abafamento dos sons (fase IV de Korotkoff) e anotar os valores da pressão zero, PAS e PAD.  
9. Registrar em prontuário os valores exatos sem “arredondamentos”, o braço em que a PA foi medida, a posição do paciente, o tamanho do manguito e qualquer possível interferência.  
10. Informar ao usuário o valor de PA obtido na medição.  
Realização do procedimento de medida da pressão arterial com aparelho eletrônico (técnica oscilométrica)  
1. Selecionar o manguito de tamanho adequado ao braço, considerando a circunferência do braço no ponto médio entre acrômio e olecrano.  
2. Colocar o manguito, sem deixar folgas, 2 cm a 3 cm acima da fossa cubital, centralizando o meio da parte compressiva do manguito sobre a artéria braquial.  
3. Realizar pelo menos duas medidas, com intervalo em torno de um minuto. Medições adicionais deverão ser realizadas se as duas primeiras tiverem 5 mmHg ou mais de diferença.  
4. Aguardar 1 minuto a 2 minutos entre as medidas no mesmo braço.  
5. Considerar a média das duas últimas medidas.  
6. Registrar em prontuário os valores exatos sem “arredondamentos”, o braço em que a PA foi medida, a posição do paciente, o tamanho do manguito e qualquer possível interferência.  
7. Informar ao usuário o valor de PA obtido na medição.  
Na avaliação inicial, é preferível medir a PA nos dois braços e, depois, usar o braço com o valor maior. Se houver uma diferença consistente, maior que 10 mmHg, entre os braços em medidas repetidas, usar o braço com a PA mais alta. Se a diferença for maior que 20 mmHg, devese considerar uma investigação mais aprofundada<sup>1</sup> .  
Recomenda-se fazer pelo menos duas medidas da PA e usar a segunda leitura quando os valores forem normais, e pelo menos três medidas da PA para valores elevados, descartando os primeiros valores e usando a média das duas últimas medidas<sup>1</sup> .  
Em caso de suspeita de hipotensão postural, especialmente, em idosos, diabéticos, disautonômicos ou naqueles em uso de anti-hipertensivos, a medida deve ser feita com paciente em pé, após 3 minutos<sup>1</sup> . A hipotensão ortostática é definida como uma redução na PAS ≥ 20 mmHg ou na PAD ≥ 10 mmHg dentro do 3º minuto em pé e está associada a um risco aumentado de mortalidade e eventos cardiovasculares<sup>2</sup> .  
2. Monitorização ambulatorial da pressão arterial  
A monitorização ambulatorial da pressão arterial (MAPA) é feita por meio de equipamento que contém um monitor conectado a cinto ou suporte fixado na cintura do paciente e uma braçadeira semelhante à utilizada para medir a PA colocada de preferência no braço não dominante, conectados por um tubo. O dispositivo utilizado é normalmente programado para  
84  
registrar a PA em intervalos de 15 minutos a 30 minutos e os valores médios são geralmente fornecidos para o dia, noite e 24 horas. Um diário das atividades do paciente e o tempo de sono também podem ser registrados. Para que uma sessão de MAPA seja válida, é necessário um mínimo de 70% dos registros de PA utilizáveis. É importante que o indivíduo seja orientado a não retirar, manipular ou desligar o monitor durante as 24 horas do procedimento<sup>3,4</sup> .

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: 3. Monitorização residencial da pressão arterial -->
A MRPA resulta em um valor médio de uma série de medidas realizadas em domicílio durante três a sete dias consecutivos, duas vezes ao dia (manhã e noite). Duas medições devem ser realizadas em cada ocasião, com intervalo de um a dois minutos entre cada. Pela manhã, as medições devem ser feitas antes do desjejum e do uso de medicamentos e pela noite antes do jantar. A monitorização deve ser realizada em uma sala silenciosa, após cinco minutos de repouso, com o indivíduo sentado e com as costas e braços apoiados, além disso, deve-se evitar, falar, ler ou assistir televisão durante a medição. Recomenda-se utilizar um monitor de PA automático e validado, preferencialmente dispositivo automático oscilométrico, e registrar os valores medidos imediatamente<sup>3</sup> .  
Além disso, o treinamento do indivíduo responsável pela medida é fundamental no contexto de diagnóstico, em que se espera, na maioria dos casos, falta de familiaridade com a técnica. Ao profissional de saúde, portanto, cabe o treinamento adequado para realização adequada do procedimento, validado e periodicamente avaliado quanto à sua precisão<sup>3</sup> .  É importante que seja utilizado o manguito correto, e o comprimento da bolsa inflável seja de 80% a 100% da circunferência do braço e a largura de, pelo menos, 40% da circunferência do braço<sup>5</sup> .  
Referências:  
1. Unger T, Borghi C, Charchar F, Khan NA, Poulter NR, Prabhakaran D, et al. 2020 International Society of Hypertension Global Hypertension Practice Guidelines. Hypertension. junho de 2020;75(6):1334–57.  
2. Barroso WKS, Rodrigues CIS, Bortolotto LA, Mota-Gomes MA, Brandão AA, Feitosa AD de M, et al. Diretrizes Brasileiras de Hipertensão Arterial – 2020. Arq Bras Cardiol. 3 de março de 2021;116(3):516–658.  
3. Williams B, Mancia G, Spiering W, Agabiti Rosei E, Azizi M, Burnier M, et al. 2018 ESC/ESH Guidelines for the management of arterial hypertension. Eur Heart J. 1o de setembro de 2018;39(33):3021–104.  
4. Brasil. Ministério da Saúde. Secretaria de Atenção Primária à Saúde. Departamento de Saúde da Família. Linha de Cuidado do adulto com hipertensão arterial sistêmica. Brasília: Ministério da Saúde; 2021. p. 85.  
5. Siddiqui S, Malatesta-Muncher R. Hypertension in Children and Adolescents: A Review of Recent Guidelines. Pediatr Ann. junho de 2020;49(6).  
85

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **16. Escopo e finalidade do protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Hipertensão Arterial Sistêmica, <mark>contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.</mark>  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do <mark>Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS).</mark>  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, os quais foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
A elaboração do PCDT da Hipertensão Arterial Sistêmica iniciou-se com a demanda pelo Ministério da Saúde (MS) e as reuniões de pré-escopo, de escopo e de priorização de perguntas realizadas entre 28/09/2021 e 17/03/2022.  
Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para elaboração de PCDT. Definiu-se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Ainda, foram elencadas seis novas questões de pesquisa para a elaboração do PCDT.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **17. Etapas do processo de elaboração** -->
A proposta inicial de elaboração do PCDT da Hipertensão Arterial Sistêmica foi inicialmente discutida durante a reunião de pré-escopo, ocorrida em 28 de setembro de 2021. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Atenção Primária à Saúde (SAPS).  
Posteriormente, o escopo do documento foi discutido em reuniões de escopo, ocorridas em 14 de outubro de 2021 e 17 de janeiro de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS, SAPS, SAES, representantes de pacientes, de sociedades médicas e especialistas convidados.  
Foram elaboradas perguntas PICO para as dúvidas clínicas e tecnologias que necessitariam de avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Após levantamento inicial das evidências pelo Grupo Elaborador, elas foram apresentadas em reunião ocorrida em 17 de março de 2022, com a presença de metodologistas e especialistas do Grupo Elaborador e representantes da SECTICS, SAPS e SAES. A partir das evidências encontradas, as perguntas de pesquisa a serem respondidas foram priorizadas e validadas.  
86

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **18. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Hipertensão Arterial Sistêmica foi apresentada na 122ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 28 de janeiro de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS), Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada inicialmente aos membros do Comitê de Protocolos Clínicos e Diretrizes Terapêuticas da Conitec em sua 137ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **19. Consulta pública** -->
A Consulta Pública nº 11/2025, para a elaboração do PCDT da Hipertensão Arterial Sistêmica, foi realizada entre os dias 14 de março de 2025 e 02 de abril de 2025. Foram recebidas 07 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2025/contribuicao-de-consulta-publica-11-2025-pcdt-dehipertensao-arterial-sistemica.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **20. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO ( **Figura A** ).  
<!-- Start of picture text -->
PP *Populacdo ou condi¢ao clinica<br>*Intervencdo, no caso de estudos experimentais<br>Fator de exposicdo, em caso de estudos observacionais<br>*Teste indice, nos casos de estudos de acuracia diagnostica<br>*Controle, de acordo com tratamento/niveis de exposicao do fator/exames<br>disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Figura A. Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
Durante a reunião de escopo deste PCDT seis questões de pesquisa foram definidas **:**  
- Benazepril é eficaz e seguro para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial?  
87  
- A combinação fixa benazepril associado a anlodipino é eficaz e segura para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial?  
- Clortalidona é eficaz e segura para adultos com hipertensão arterial sistêmica e controle inadequado da pressão arterial?  
- A combinação fixa losartana potássica associada a hidroclorotiazida é eficaz e segura para adultos com hipertensão arterial sistêmica e controle inadequado da pressão arterial?  
- Em adultos com HAS em tratamento medicamentoso, independentemente da pressão arterial de consultório, a monitorização residencial da pressão arterial (MRPA) é eficaz, efetiva, custo-efetiva e viável orçamentariamente para o monitoramento da HAS, quando comparada à monitorização ambulatorial da pressão arterial (MAPA) e medida da PA de consultório?  
- A MRPA é acurada, custo-efetiva e viável orçamentariamente para o diagnóstico da HAS em adultos com suspeita da doença em comparação à MAPA e medida da PA de consultório?  
Para cada uma das perguntas, as informações sobre a evidência encontram-se nos seus respectivos relatórios de recomendação.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **QUESTÃO 1: Benazepril é eficaz e seguro para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial?** -->
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de benazepril para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial conforme Relatório de Recomendação nº 821/2023, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2023/benazepril-para-adultos-comhipertensao-arterial-sistemica-com-controle-inadequado-da-pressao-arterial.</u> A Conitec considerou as incertezas em relação ao impacto orçamentário (possibilidade de incremento) e ausência de evidências quanto a um aumento de adesão ao tratamento.  
A estrutura PICO para esta pergunta foi:  
|**População**|Adultos com hipertensão arterial sistêmica com controle inadequado da<br>pressão arterial com monoterapiaprévia emqualquer dose.|
|---|---|
|**Intervenção**|Benazepril|
|**Comparador**|Todas as opções disponíveis no SUS em monoterapia ou combinação de<br>medicamentos|
|**Desfechos**|Primários: Variação da pressão arterial sistólica de consultório e<br>ambulatorial, Variação da pressão arterial diastólica de consultório e<br>ambulatorial, Morte devido a evento cardiovascular, Eventos<br>cardiovasculares maiores, Progressão de doença renal crônica para<br>necessidade de diálise, Mortalidade geral, Pacientes que alcançam a meta<br>terapêutica para pressão arterial<br>Secundários: Pacientes com eventos adversos, Pacientes com eventos<br>adversos graves, Descontinuação por evento adverso, Variação da adesão<br>terapêutica,Pacientesquepassam a aderir|  
88

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: Métodos e resultados da busca: -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 821/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **QUESTÃO 2: A combinação fixa benazepril associado a anlodipino é eficaz e segura para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial?** -->
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de combinação fixa de benazepril associado a anlodipino para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial, conforme Relatório de Recomendação nº 822/2023, disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2023/combinacao-fixa-de-benazepril-associado-a-anlodipino-para-adultoscom-hipertensao-arterial-sistemica-com-controle-inadequado-da-pressao-arterial.</u> A Conitec considerou as incertezas em relação ao impacto orçamentário (possibilidade de incremento) e ausência de evidências quanto a um aumento de adesão ao tratamento.  
A estrutura PICO para esta pergunta foi:  
|**População**|Adultos com hipertensão arterial sistêmica com controle inadequado da<br>pressão arterial com monoterapiaprévia emqualquer dose|
|---|---|
|**Intervenção**|Benazepril + anlodipino|
|**Comparador**|Todas as opções disponíveis no SUS em monoterapia ou combinação de<br>medicamentos|
|**Desfechos**|Primários: Variação da pressão arterial sistólica de consultório e<br>ambulatorial, Morte devido a evento cardiovascular, Eventos<br>cardiovasculares maiores, Progressão de doença renal crônica para<br>necessidade de diálise, Mortalidade geral, Pacientes que alcançam a meta<br>terapêutica para pressão arterial<br>Secundários: Pacientes com eventos adversos, Pacientes com eventos<br>adversos graves, Descontinuação por evento adverso, Variação da adesão<br>terapêutica,Pacientesquepassam a aderir|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 822/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **QUESTÃO 3: Clortalidona é eficaz e segura para adultos com hipertensão arterial sistêmica e controle inadequado da pressão arterial?** -->
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de clortalidona para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial, conforme Relatório de Recomendação nº 823/2023, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2023/clortalidona-para-adultos-comhipertensao-arterial-sistemica-com-controle-inadequado-da-pressao-arterial.</u>  
89  
A Conitec considerou as incertezas em relação ao impacto orçamentário (possibilidade de incremento) e ausência de evidências quanto a um aumento de adesão ao tratamento.  
A estrutura PICO para esta pergunta foi:  
|**População**|Adultos com hipertensão arterial sistêmica com controle inadequado da<br>pressão arterial com monoterapiaprévia emqualquer dose|
|---|---|
|**Intervenção**|Clortalidona(monoterapia)|
|**Comparador**|Todas as opções disponíveis no SUS em monoterapia ou combinação de<br>medicamentos|
|**Desfechos**|**Primários:**Variação da pressão arterial sistólica de consultório e<br>ambulatorial, Variação da pressão arterial diastólica de consultório e<br>ambulatorial, Morte devido a evento cardiovascular, Eventos<br>cardiovasculares maiores, Progressão de doença renal crônica para<br>necessidade de diálise, Mortalidade geral, Pacientes que alcançam a meta<br>terapêutica para pressão arterial<br>**Secundários:**Pacientes com eventos adversos, Pacientes com eventos<br>adversos graves, Descontinuação por evento adverso, Variação da adesão<br>terapêutica,Pacientesquepassam a aderir|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 823/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 4: A combinação fixa losartana associada a hidroclorotiazida é eficaz e segura para adultos com hipertensão arterial sistêmica e controle inadequado da pressão arterial?**  
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de combinação fixa de losartana associada a hidroclorotiazida para adultos com hipertensão arterial sistêmica com controle inadequado da pressão arterial, conforme Relatório de Recomendação nº 820/2023, disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2023/combinacao-fixa-de-losartana-associada-a-hidroclorotiazida-paraadultos-com-hipertensao-arterial-sistemica-com-controle-inadequado-da-pressao-arterial.</u> A Conitec considerou as incertezas em relação ao impacto orçamentário (possibilidade de incremento) e ausência de evidências quanto a um aumento de adesão ao tratamento.  
A estrutura PICO para esta pergunta foi:  
|**População**|Adultos com hipertensão arterial sistêmica com controle inadequado da<br>pressão arterial com monoterapiaprévia emqualquer dose|
|---|---|
|**Intervenção**|Losartana + hidroclorotiazida em associação fixa|
|**Comparador**|Todas as opções disponíveis no SUS em monoterapia ou combinação de<br>medicamentos|
|**Desfechos**|**Primários:**Variação da pressão arterial sistólica de consultório e<br>ambulatorial, Variação da pressão arterial diastólica de consultório e<br>ambulatorial, Morte devido a evento cardiovascular, Eventos<br>cardiovasculares maiores,Progressão de doença renal crônicapara|  
90  
necessidade de diálise, Mortalidade geral, Pacientes que alcançam a meta terapêutica para pressão arterial **Secundários:** Pacientes com eventos adversos, Pacientes com eventos adversos graves, Descontinuação por evento adverso, Variação da adesão terapêutica, Pacientes que passam a aderir  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 820/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
**QUESTÃO 5: Em adultos com HAS em tratamento medicamentoso, independentemente da pressão arterial de consultório, a monitorização residencial da pressão arterial (MRPA) é eficaz, efetiva, custo-efetiva e viável orçamentariamente para o monitoramento da HAS, quando comparada à monitorização ambulatorial da pressão arterial (MAPA) e medida da PA de consultório?**  
Recomendação: Adotou-se a deliberação da Conitec, em não recomendar a incorporação no SUS de monitorização residencial da pressão arterial em adultos com hipertensão arterial sistêmica em tratamento medicamentoso, independentemente da pressão arterial do consultório, conforme Relatório de Recomendação nº 818/2023, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2023/20230428_relatorio-818mrpa_monitoramento_hipertensao-arterial.pdf. A Conitec considerou que estudos tinham</u> limitações inerentes, sendo que sua qualidade está intimamente ligada à robustez e à confiabilidade dos dados clínicos primários.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: A estrutura PICO para esta pergunta foi: -->
|**População**|Adultos<br>com<br>hipertensão<br>arterial<br>sistêmica<br>em<br>tratamento<br>medicamentoso,independentemente dapressão arterial de consultório|
|---|---|
|**Intervenção**|Monitorização Residencial da Pressão Arterial|
|**Comparador**|Monitorização Ambulatorial da Pressão Arterial; Medida da PA de<br>consultório|
|**Desfechos**|**Primários (críticos):**Mudança da pressão arterial sistólica, Mudança da<br>pressão arterial diastólica, Pacientes que alcançam a meta terapêutica<br>para pressão arterial, Morte devido a evento cardiovascular, Eventos<br>cardiovasculares maiores, Hospitalização por insuficiência cardíaca,<br>Mortalidade geral, Progressão de doença renal crônica para necessidade<br>de diálise<br>**Secundários (importante):**Otimização da adesão; Proporção de<br>eventos adversos.|

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: Métodos e resultados da busca: -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 818/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
91

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **QUESTÃO 6: A MRPA é acurada, custo-efetiva e viável orçamentariamente para o diagnóstico de HAS em adultos com suspeita da doença em comparação à MAPA e medida da PA de consultório?** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de monitorização residencial da pressão arterial para diagnóstico de hipertensão arterial sistêmica em adultos com suspeita da doença, conforme Relatório de Recomendação nº 817/2023, disponível em: <u>https://www.gov.br/conitec/ptbr/midias/relatorios/2023/20230511_relatorio_817_mrpa_diagnostico_hipertensao-arterial.pdf.</u> A Conitec considerou o benefício em reduzir tratamento desnecessário com hipertensão do jaleco branco, reduzido impacto orçamentário e viabilidade de implementação.  
A estrutura PIRD para esta pergunta foi:  
|**População**|Adultos com suspeita de HAS|
|---|---|
|**Teste Indice**|MRPA|
|**Teste de Referência**|MAPA,Medida da PA de consultório|
|**Diagnóstico de interesse**|HAS|  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 817/2023 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **21. Equipe de elaboração e partes interessadas** -->
O Protocolo foi elaborado pelo Unidade de Avaliação de Tecnologias em Saúde (UATS) do Hospital Alemão Oswaldo Cruz (HAOC).  
Os participantes das reuniões de elaboração e do processo de desenvolvimento do referido PCDT estão descritos no Quadro A.  
Quadro A. Participantes das reuniões virtuais e do processo de desenvolvimento do  
PCDT.  
|**Participantes**|
|---|
|Aline Leal Gonçalves Creder Lopes|
|Álvaro Avezum*|
|Ana Carolina de Freitas Lopes|
|Ana Paula Giacomo Assunção Souza de Jesus|
|André Klafke de Lima*|
|Angela Maria Geraldo Pierin*|
|Antonio Luiz Pinho Ribeiro*|
|Ávila Teixeira Vidal|
|Brígida Dias Fernandes|
|Camila Araújo da Silva**|
|Carisi A Polanczyk*|
|Cláudia Lúcia de Moraes Forjaz*|
|Dandara Baçã de Jesus Lima|  
92  
|**Participantes**|
|---|
|Daniel da Silva Pereira Curado|
|Elivan Silva Souza|
|Elivelton Borges Pinheiro**|
|Estela Azeka*|
|Flavio Danni Fuchs*|
|Frida Liane Plavnik Plavnik*|
|Gabriella Carrilho Lins de Andrade|
|Giovanio Vieira da Silva*|
|Glauciene Analha Leister|
|Haliton Alves de Oliveira Junior**|
|Izabella Barbosa de Brito|
|Jessica Yumi Matuoka**|
|Jose Francisco Saraiva*|
|Juliana Fersura Reis|
|Juliana Nunes|
|KarolinyEvangelista de Moraes Duque|
|Klébya Hellen Dantas de Oliveira|
|Layssa Andrade Oliveira**|
|Letícia Mendes Ricardo|
|Luciano Ferreira Drager*|
|Luisa Campos Caldeira Brant*|
|Luiz Aparecido Bortolotto*|
|Marcia da Costa Pereira de Jesus*|
|Marcia Maria GodoyGowdak*|
|Maria Cristina Caetano Kuschnir*|
|Marta da Cunha Lobo Souto Maior|
|Natacha de Oliveira Hoepfner|
|Nicole Freitas de Mello|
|Patrícia Lisboa Izetti Ribeiro|
|Paulo Henrique Ribeiro Fernandes Almeida|
|Rafaela Tavares Peixoto|
|Roberta Maria Leite Costa|
|Rosa Camila Lucchetta**|
|Sofia Wolker Manta|
|Sônia Mara Linhares de Almeida|
|Tassiane Cristine Santos de Paula**|
|Thais Fonseca Veloso de Oliveira|
|Valéria Verri|
|Wendel Mombaque dos Santos**|  
*Membros votantes na reunião de escopo; **Metodologistas.  
93

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro B).  
<u>Quadro B. Questionário de conflitos de interesse diretrizes clínico-assistenciais.</u>  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar fi<br>algum dos benefícios abaixo?|nanceiramente|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz<br>(<br>(|) Sim<br> )Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino<br>(<br>(|) Sim<br> )Não|
|c) Financiamento para redação de artigos ou editorias<br>(<br>(|) Sim<br> )Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área<br>(<br>(|) Sim<br> )Não|
|e) Recursos ou apoio financeiro para membro da equipe<br>(<br>(|) Sim<br> )Não|
|f) Algum outro benefício financeiro<br>(<br>(|) Sim<br> )Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma<br>ser beneficiada ouprejudicada com as recomendações da diretriz?<br>(<br>(|) Sim<br> )Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?<br>(<br>(|) Sim<br> )Não|
|4. Você já atuou como perito judicial na área tema da diretriz?<br>(<br>(|) Sim<br> )Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos inte<br>ser afetadospela sua atividade na elaboração ou revisão da diretriz?|resses possam|
|a) Instituição privada com ou sem fins lucrativos<br>(<br>(|) Sim<br> )Não|
|b) Organização governamental ou não-governamental<br>(<br>(|) Sim<br> )Não|
|c) Produtor, distribuidor ou detentor de registro<br>(<br>(|) Sim<br> )Não|
|d) Partido político<br>(<br>(|) Sim<br> )Não|
|e) Comitê, sociedade ou grupo de trabalho<br>(<br>(|) Sim<br> )Não|
|f) Outro grupo de interesse<br>(<br>(|) Sim<br> )Não|
|6. Você poderia ter algum tipo de benefício clínico?<br>(<br>(|) Sim<br> )Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses<br>possam ser afetados?<br>(<br>(|) Sim<br> )Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o<br>que você irá escrever eque deveria ser do conhecimentopúblico?<br>(<br>(|) Sim<br> )Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado<br>acima, quepossa afetar sua objetividade ou imparcialidade?<br>(<br>(|) Sim<br> )Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?<br>(<br>(|) Sim<br> )Não|  
94  
O resumo dos conflitos de interesse dos participantes das reuniões de desenvolvimento e membros do Grupo Elaborador está na Quadro C.  
Quadro C. Declaração de conflitos de interesse dos participantes das reuniões de desenvolvimento e membros do Grupo Elaborador do PCDT.  
|**Participante**|**Conflitos d**|**e interesses declarados**|**Decisão tomada**|
|---|---|---|---|
||**Questão**|**Descriçãogeral**||
|André Klafke de Lima|-|-|Declarar e<br>participar|
|Angela Maria Geraldo Pierin|-|-|Declarar e<br>participar|
|Antônio Luiz Pinho Ribeiro|5b|Consultor do Ministério<br>da Saúde|Declarar e<br>participar|
|Camila Araújo da Silva|-|-|Declarar e<br>participar|
|Carisi Anne Polanczyk|1b,5c|Realiza aula e<br>consultoria para Bayer,<br>Roche, Novartis e<br>Amgen em. outras<br>temáticas.<br>Financiamento de<br>empresas para estudo de<br>custos de doenças.|Declarar e<br>participar|
|Cláudia Lúcia de Moraes Forjaz|-|-|Declarar e<br>participar|
|Elivelton Borges Pinheiro|-|-|Declarar e<br>participar|
|Estela Azeka|-|-|Declarar e<br>participar|
|Frida Liane Plavnik Plavnik|-|-|Declarar e<br>participar|
|Flávio Fuchs|-|-|Declarar e<br>participar|
|Giovanio Vieira da Silva|||Declarar e<br>participar|
|Haliton Alves de Oliveira Junior|-|-|Declarar e<br>participar|
|Jessica Yumi Matuoka|-|-|Declarar e<br>participar|
|Jose Francisco Saraiva|1b,d|Honorários por<br>apresentação,<br>consultoria, palestra ou<br>atividades de ensino e<br>pesquisa|Declarar e<br>participar|
|Layssa Andrade Oliveira|-|-|Declarar e<br>participar|
|Luciano Ferreira Drager|1b|Declara ser palestrante e<br>escrever material<br>científico (separatas, não<br>artigos científicos ou<br>editoriais em revistas)<br>para as empresas ACHÉ,<br>Biolab,Boehringer,|Declarar e<br>participar|  
95  
|**Participante**|**Conflitos d**<br>|**e interesses declarados**<br>|**Decisão tomada**|
|---|---|---|---|
||**Questão**|**Descriçãogeral**||
|||Merck,<br>Novartis e Servier.||
|Ludhmila Abrahão Hajjar|-|-|Declarar e<br>participar|
|Luisa Campos Caldeira Brant|-|-|Declarar e<br>participar|
|Luiz Aparecido Bortolotto|1c|Redação de artigos para<br>Dalghi-Sanrpo e Merck<br>Servier|Declarar e<br>participar|
|Marcia da Costa Pereira de Jesus|5d, 8|Afiliação partidária e<br>convicções religiosas|Declarar e<br>participar|
|Marcia Maria Godoy Gowdak|-|-|Declarar e<br>participar|
|Maria Cristina Caetano Kuschnir|-|-|Declarar e<br>participar|
|Rosa Camila Lucchetta|-|-|Declarar e<br>participar|
|Tassiane Cristine Santos de Paula|-|-|Declarar e<br>participar|
|Valeria Verri|-|-|Declarar e<br>participar|
|Wendel Mombaque dos Santos|-|-|Declarar e<br>participar|  
96

---

<!-- METADADOS: doenca: Hipertensão Arterial Sistêmica | secao: **APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>**Relatório da**<br>**diretriz**<br>**clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Tecno**<br>**Incorporação ou**<br>**alteração do uso**<br>**no SUS**|**logias avaliadaspela Conitec**<br>**Não incorporação ou não alteração no**<br>**SUS**|
|---|---|---|---|
|Portaria<br>SECTICS/MS<br>nº<br>49/2025<br>[Relatório<br>de<br>Recomendação<br>nº 1006/2025]|Primeira<br>versão do<br>documento|Monitorização<br>residencial<br>da<br>pressão<br>arterial<br>para diagnóstico<br>de<br>hipertensão<br>arterial sistêmica<br>em adultos com<br>suspeita<br>da<br>doença [Relatório<br>de<br>Recomendação<br>nº<br>817/2023;<br>Portaria<br>SECTICS/MS nº<br>22/2023]|Benazepril para adultos com hipertensão<br>arterial<br>sistêmica<br>com<br>controle<br>inadequado da pressão arterial<br>[Relatório de Recomendação nº 821/2023;<br>Portaria SECTICS/MS nº 35/2023]<br>Combinação fixa de losartana associada a<br>hidroclorotiazida<br>para<br>adultos<br>com<br>hipertensão<br>arterial<br>sistêmica<br>com<br>controle inadequado da pressão arterial<br>[Relatório de Recomendação nº 820/2023;<br>Portaria SECTICS/MS nº 32/2023]<br>Clortalidona para adultos com hipertensão<br>arterial<br>sistêmica<br>com<br>controle<br>inadequado da pressão arterial<br>[Relatório de Recomendação nº 823/2023;<br>Portaria SECTICS/MS nº 33/2023]<br>Combinação fixa de benazepril associado<br>a anlodipino para adultos com hipertensão<br>arterial<br>sistêmica<br>com<br>controle<br>inadequado da pressão arterial<br>[Relatório de Recomendação nº 822/2023;<br>Portaria SECTICS/MS nº 31/2023]<br>Monitorização residencial da pressão<br>arterial em adultos com hipertensão<br>arterial<br>sistêmica<br>em<br>tratamento<br>medicamentoso, independentemente da<br>pressão arterial do consultório<br>[Relatório de Recomendação nº 818/2023;<br>PortariaSECTICS/MSnº 19/2023]|  
97

---

