<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
PORTARIA Nº. 1159, DE 18 DE NOVEMBRO DE 2015  
Aprova o Protocolo de uso da isotretinoína no tratamento da acne grave.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a acne grave no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º  Ficam aprovados, na forma do Anexo, disponível no sítio: www.saude.gov.br/sas, o Protocolo de uso da isotretinoína no tratamento da acne grave.  
Parágrafo único. O Protocolo de que trata este artigo, que contém o conceito geral da acne grave, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso do medicamento preconizados para o tratamento da acne grave.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 143/SAS/MS, de 31 de março de 2010, publicada no Diário Oficial da União nº 62, de 01 de abril de 2010, seção 1, pág. 31.  
ALBERTO BELTRAME  
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A busca na literatura foi realizada avaliando os artigos publicados entre 1980 e setembro de 2009 com os termos MeSH _acne vulgaris_ e _therapeutics_ e limitados a ensaios clínicos, meta-análises ou diretrizes terapêuticas, escritos na língua inglesa e com estudos com humanos. Foram utilizadas as seguintes base de dados: MEDLINE/PubMed, Cochrane e SciELO. A busca gerou 292 artigos, sendo que a maioria descrevia estudos com terapias tópicas, hormonais e laser, entre outros. Quando a busca foi restringida ao tema de interesse do Protocolo, com os termos MESH _acne vulgaris_ e _isotretinoin_ , foram encontrados 40 artigos. Foram excluídos na análise estudos que descreviam o uso da isotretinoína para outros fins terapêuticos, tratamentos com fórmula de isotretinoína não disponível no Brasil (micronizada), tratamentos para acne que não incluíam a isotretinoína e estudos que somente avaliavam aspectos específicos dos efeitos adversos laboratoriais e moleculares do tratamento com isotretinoína. Dessa seleção foram analisados 11 ensaios clínicos randomizados (ECR) e duas diretrizes terapêuticas utilizadas neste Protocolo. Na biblioteca Cochrane foram encontradas quatro revisões sistemáticas, mas apenas uma foi avaliada, visto que as demais eram referentes a tratamentos diversos para acne que não isotretinoína. Foram utilizados também os estudos não indexados pertinentes ao tema.  
Em 26/08/2014, foi realizada atualização da busca na literatura com os critérios de inclusão originalmente empregados. Na base MEDLINE/PubMed foi utilizada a estratégia <mark>("acne vulgaris"[MeSH Terms] OR severe acne[Title/Abstract]) OR acne conglobate[Title/Abstract] AND ((Meta-Analysis[ptyp] OR systematic[sb] OR Randomized Controlled Trial[ptyp] OR Guideline[ptyp]) AND ("2009/09/01"[PDAT]: "3000/12/31"[PDAT]) AND (English[lang] OR Portuguese[lang] OR Spanish[lang])). Nessa base foram localizados 219 estudos, sendo 10 meta-análises e 63 revisões sistemáticas; foram selecionados 20 estudos para leitura, resultando na inclusão de quatro deles.</mark>  
<mark>Na base Embase, utilizando a estratégia 'acne'/mj OR 'severe acne:ti' AND ([systematic review]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [1-1-2009]/sd, identificarm-se 75 resultados. Essa busca não resultou na inclusão de novos estudos.</mark>

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
<mark>Também foi realizada busca por revisões sistemáticas da Cochrane com o termo “acne:ti”, recuperando-se cinco revisões completas; porém, nenhuma preencheu os critérios de inclusão.</mark>  
<mark>Foram excluídos estudos com desfechos não clínicos, avaliando métodos de tratamento alternativos ou técnicas ou produtos não aprovados no Brasil, com graves problemas metodológicos ou resultados inconclusivos ou insuficientes para resultar em nova recomendação. Foi ainda consultada a base de dados UpToDate versão 22.10. Ao todo, incluem-se 41 referências neste Protocolo.</mark>

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A acne é uma dermatose extremamente comum na prática médica. Em levantamento epidemiológico realizado pela Sociedade Brasileira de Dermatologia, a acne foi a causa mais frequente de consultas ao dermatologista, correspondendo a 14% de todos os atendimentos(1). Outros estudos epidemiológicos mostram que 80% dos adolescentes e adultos jovens entre 11 e 30 anos irão apresentar acne(2). Seu tratamento justifica-se tanto pela possibilidade de evitar tanto lesões cutâneas permanentes quanto pelo aparecimento ou agravamento de transtornos psicológicos, oriundos do abalo à autoestima ocasionado pelas lesões(3-5).  
Os principais fatores etiopatogênicos relacionados com a acne são: 1) produção de andrógenos pelo organismo, 2) produção excessiva de sebo, 3) alteração na descamação do epitélio do ducto da glândula sebácea, 4) proliferação de _Propionibacterium acnes_ e 5) respostas inflamatórias e imunológicas do indivíduo(6).  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
3 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- L 70.0 Acne vulgar  
- L 70.1 Acne conglobata  
- L70.8 Outras formas de acne

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico de acne é clínico e caracterizado por lesões cutâneas variadas como comedões abertos e fechados, pápulas inflamatórias, pústulas, nódulos, cistos, lesões conglobatas e cicatrizes. As lesões acometem principalmente a face e o dorso, mas podem estender-se para a região superior dos braços e o tórax anterior.  
A acne pode ser classificada quanto à sua gravidade, o que se torna muito importante para a tomada de decisões terapêuticas(6).  
<u>Acne não inflamatória:</u>  
- Acne comedônica (grau I): presença de comedões abertos.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Pápulopustulosa (grau II): pápulas inflamatórias ou pústulas associadas aos comedões abertos;  
- Nodulocística (grau III): lesões císticas e nodulares associadas a qualquer das lesões anteriores;  
-  Conglobata (grau IV): presença das lesões anteriores associadas a nódulos purulentos, numerosos e grandes formando abscessos e fístulas que drenam material purulento.  
Outras informações clínicas que determinam a gravidade da acne são a extensão das lesões e a presença de cicatrizes.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Devido ao seu potencial teratogênico e às várias reações adversas possíveis, o tratamento com isotretinoína oral para acne deve ser restrito aos casos mais graves e refratários a outras medidas terapêuticas, bem como àqueles pacientes em que se espera ótima adesão aos cuidados necessários durante o tratamento.  
Serão incluídos neste Protocolo os pacientes que apresentarem pelo menos uma das condições entre 1 e 4 e, necessariamente, a quinta condição:  
1. Acne nodulocística grave;  
2. Acne conglobata;  
3. Outras variantes graves de acne;  
4. Acne com recidivas frequentes, requerendo cursos repetidos e prolongados de antibiótico sistêmico (2,6-8);  
5. Ausência de resposta satisfatória ao tratamento convencional, incluindo antibiótico sistêmico administrado por um período de pelo menos 2 meses(6). Um exemplo de opção de antibiótico é a eritromicina na dose de 1.000 mg/dia.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Serão excluídos deste Protocolo os pacientes que apresentarem pelo menos uma das condições abaixo:  
- Gestação;  
- Amamentação;  
- Hipersensibilidade à isotretinoína, à vitamina A ou aos componentes da  
- fórmula.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O uso de isotretinoína deve ser evitado ou realizado com cautela nos casos de:  
- Insuficiência hepática: não há descrição na literatura de valores alterados de  
- transaminases hepáticas que tornem o uso de isotretinoína contraindicado;  
- Pacientes menores de 15 anos;

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Alterações no metabolismo de lipídios expressas pelo nível sérico de triglicerídeos acima de 500 mg/dL ou nível sérico de colesterol total acima de 300 mg/dL(9-12). Os pacientes excluídos por alteração no metabolismo dos lipídios poderão ser incluídos neste Protocolo após correção da dislipidemia por tratamento específico;  
- Ausência de condições de compreender e executar as orientações médicas. Nas mulheres em idade fértil, o uso da isotretinoína está contraindicado, exceto se preencherem todos os requisitos abaixo:  
- apresentar acne nodulocística grave, refratária à terapia usual;  
- mostrar-se confiável para compreender e executar as orientações dadas;  
- ter recebido orientações verbais e por escrito sobre os riscos do uso de isotretinoína durante a gestação e riscos de possíveis falhas dos métodos contraceptivos utilizados;  
- iniciar, preferencialmente, o tratamento no segundo ou terceiro dia do ciclo menstrual regular;  
- fazer uso de dois métodos anticoncepcionais desde 2 meses antes do tratamento até 2 meses após seu término. O teste sorológico de gravidez deve ser negativo antes do início e realizado mensalmente até 5 semanas após a última administração da isotretinoína(13,14).

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A escolha do tratamento da acne compreende uma série de opções que irão variar de acordo com a gravidade do quadro. Essas opções incluem o uso de substâncias de limpeza de pele, retinoides e fármacos antibacterianos tópicos para os casos mais leves até o uso de antibióticos sistêmicos, terapias hormonais e, para casos mais graves e resistentes, o uso da isotretinoína.  
Os ECR que avaliaram o uso da isotretinoína oral para o tratamento da acne foram analisados em uma revisão sistemática realizada em 1999(15), a única realizada até o momento com esse fim. Essa revisão sistemática buscou ECR com a palavrachave acne e avaliou publicações sobre todos os tipos de tratamento para todos os graus de acne. Foram selecionados 250 artigos por meio desta análise; destes, apenas nove estudavam o uso da isotretinoína oral e serão descritos brevemente a seguir.  
Peck et al.(16) realizaram um dos primeiros estudos comparando isotretinoína oral com placebo em pacientes com acne grave. Ele avaliou 33 pacientes randomizados em dois grupos, sendo que aqueles que receberam isotretinoína o fizeram em uma dose média de 0,65 mg/kg/dia por 16 semanas. Os resultados clínicos favoráveis ao uso da isotretinoína foram estatisticamente significativos, mas o estudo tem muitas limitações metodológicas, pois, além do número pequeno de pacientes, cerca de metade daqueles no grupo placebo precisaram sair do estudo por piora clínica.  
Estudos comparando isotretinoína oral com outras terapias sistêmicas foram feitos por Prendiville et al.(17) e Lester et al.(18) utilizando dapsona e tetraciclina

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
respectivamente. O primeiro estudo foi realizado com 40 pacientes com acne grave randomizados para receber isotretinoína 40 mg/dia ou dapsona 100 mg/dia e acompanhados por 16 semanas. Ambos os grupos apresentaram melhora clínica significativa, porém no grupo da dapsona essa melhora foi mais tardia. Na comparação entre os grupos, aquele que recebeu isotretinoína teve melhora maior, mas a análise estatística não é descrita para todas as variáveis. Lester et al. avaliaram 30 pacientes randomizados para receber isotretinoína 1,0 mg/kg/dia ou tetraciclina 1.000 mg/dia. Não houve diferença significativa entre os grupos na semana 12; porém, no seguimento pós-terapia, os pacientes que usaram isotretinoína tiveram melhora significativa no número e tamanho dos cistos, assim como na contagem de comedões e pústulas.  
No início da década de 1980, uma série de trabalhos foi feita para avaliar a resposta clínica da acne a doses variadas de isotretinoína.  
Em 1980, Farrel et al. (19) publicaram um ECR com 14 pacientes divididos em três grupos para uso de isotretinoína 1,0, 0,5 e 0,1 mg/kg/dia por 12 semanas e mostrou diferença significativa em todos os pacientes em comparação ao estado basal, mas sem diferença entre os grupos. Logo após, em 1982, King et al.(20) avaliaram por 16 semanas 28 pacientes randomizados em três grupos com as mesmas doses do estudo anterior e mostraram resultados semelhantes tanto na resposta clínica como na taxa de redução de sebo, sem diferença entre os grupos. Em 1983, Jones et al.(21) e Stewart et al.(22) publicaram trabalhos com metodologia similar e mostraram que, num grupo de 76 e 22 pacientes, respectivamente, a taxa de excreção de sebo foi significativamente menor no grupo que recebeu 1,0 mg/kg/dia de isotretinoína comparada à dos outros grupos, mas a avaliação clínica da acne não mostrou diferença entre eles. Em todos esses trabalhos, especialmente no de Jones et al.(21), que seguiu os pacientes por 16 semanas após o término do tratamento, houve tendência a menos recaídas nos grupos com doses maiores de isotretinoína, mas esses dados não tiveram análise estatística.  
Também em 1983, Van der Meerer et al.(23) mostraram, em ECR com 58 homens com acne conglobata, que não houve diferença significativa na avaliação clínica da acne entre grupos que recebiam 0,5 mg/kg ou 1,0 mg/kg de isotretinoína via oral. Esse resultado foi avaliado após 12 semanas e mostrou que os efeitos adversos clínicos foram mais frequentes e mais graves nos pacientes que receberam dose maior do medicamento.  
Em 1984, foi publicado por Strauss et al.(24) o maior ECR comparando a eficácia de diferentes doses de isotretinoína em 150 pacientes alocados em caráter multicêntrico. Esse foi o primeiro trabalho a mostrar diferença significativa na avaliação do grau de acne entre os grupos de 1,0 mg/kg/dia e 0,1 mg/kg/dia já a partir da quarta semana após o término do tratamento. Mostrou também que apenas 10% dos pacientes que receberam a dose maior de isotretinoína necessitaram de retratamento, contra 42% dos que receberam a dose menor. Baseadas nesses estudos,  
surgiram recomendações para o uso de dose maior de isotretinoína com vistas a resposta clínica sustentada. Ainda que os efeitos adversos sejam mais frequentes em pacientes que receberam uma dose maior do medicamento, geralmente são efeitos adversos de pouca gravidade e reversíveis ao término da terapia.  
Em 1993, com o objetivo de avaliar recidivas e necessidade de retratamento, Layton et al.(25) publicaram estudo observacional com 88 pacientes após 10 anos de uso de isotretinoína 0,5 mg/kg/dia a 1,0 mg/kg/dia por 16 semanas ou até 85% de melhora clínica. Os achados foram que 61% estavam sem lesões, 16% necessitaram terapia complementar com antibióticos e 23% voltaram a ser tratados com isotretinoína.  
Em 2001, Gollnick et al.(26) realizaram um ECR aberto com 85 pacientes do sexo masculino com acne grave (grau 4). Foram randomizados 50 pacientes para receber minociclina 100 mg/dia mais ácido azelaico 20% gel tópico e 35 pacientes para receber isotretinoína em doses regressivas iniciando com 0,8 mg/kg/dia até 0,5 mg/kg/dia. Os pacientes receberam os respectivos tratamentos por 6 meses e depois foram seguidos por mais 3 meses, sendo que o grupo da minociclina seguiu recebendo ácido azelaico tópico e o grupo da isotretinoína, não. Ambos os tratamentos foram eficazes, porém a isotretinoína foi superior. Os efeitos adversos foram leves em ambos os grupos.  
Em 2006, Kaymak & Ilter(27) avaliaram em estudo observacional com 100 pacientes em tratamento para acne com isotretinoína na dose de 100 mg/kg/dose total com doses diárias de 0,5-1,0 mg/kg/dia. Os desfechos foram melhora clínica e efeitos adversos: 91% dos pacientes tiveram cura das lesões e 9% melhora parcial. Apenas efeitos adversos mucocutâneos foram relatados, sendo que 100% dos pacientes apresentaram queilite.  
No ano seguinte, Akman et al.(28) realizaram um ECR para testar doses intermitentes de isotretinoína e compará-las com a dose padrão contínua. Sessenta e seis pacientes com acne moderada a grave foram divididos em três grupos para receber isotretinoína 0,5 mg/kg/dia: nos primeiros 10 dias do mês por 6 meses (grupo 1), todos os dias do primeiro mês e depois nos 10 primeiros dias de cada mês por 5 meses (grupo 2) ou diariamente por 6 meses (grupo 3). Todos os esquemas de tratamento foram eficazes (p<0,001). A isotretinoína em dose padrão (grupo 3) foi superior à intermitente do grupo 1 nos casos de acne grave (p=0,013). Esse foi o primeiro estudo randomizado a analisar doses intermitentes e, embora os resultados tenham sido interessantes, foi um estudo pequeno com cerca de 20 pacientes em cada grupo. Além disso, não foram apresentadas informações sobre taxas de recidiva dos esquemas alternativos, e é importante ressaltar que, nos pacientes mais graves, para os quais está destinado este Protocolo, o esquema contínuo foi superior.  
Em 2007, um ECR de Oprica et al.(29) comparou a eficácia clínica e microbiológica de isotretinoína 1,0 mg/kg/dia com tetraciclina 500 mg/dia por via oral mais adapaleno 0,1% gel tópico para tratamento de acne moderada a grave em 52 pacientes. Houve superioridade significativa da eficácia clínica no grupo da  
isotretinoína, assim como na redução total de _P. acnes_ . Não houve diferença entre os grupos quanto à presença de bactérias resistentes.  
Há poucos estudos comparativos avaliando o tratamento de acne com isotretinoína, porque as tentativas nos estudos iniciais já mostraram resultados nunca antes obtidos com terapias convencionais. Nenhum outro tratamento leva à cura das lesões em porcentagem tão alta de resposta como a isotretinoína, e seu uso acabou consagrado(14).

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
- Isotretinoína: cápsulas de 10 mg e de 20 mg.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A dose diária pode variar de 0,5-2,0 mg/kg/dia, em uma ou duas administrações diárias, ingerida(s) com os alimentos durante a refeição.  
A dose preconizada é de 0,5-1,0 mg/kg/dia, mas pacientes com lesões muito avançadas ou preponderantemente no tronco podem receber doses de até 2 mg/kg/dia. A dose pode ser ajustada conforme a resposta clínica e a ocorrência de efeitos adversos. Atingir uma dose total cumulativa de 120 mg/kg a 150 mg/kg é recomendado para diminuir as recidivas(30-32).

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tempo de tratamento irá depender da dose total diária e da dose total cumulativa. Na maioria dos casos, esse tempo será de 4 a 6 meses, podendo ser estendido até 9 meses no caso de resposta insuficiente(32). Um segundo período de tratamento pode ser iniciado dentro de 2 meses após o término do anterior, se as lesões persistirem ou houver recorrência de lesões graves, com a mesma dose diária e dose cumulativa.  
- 8.4 CRITÉRIOS DE INTERRUPÇÃO DO TRATAMENTO  
- Triglicerídeos séricos acima de 800 mg/mL (risco de pancreatite) (12);  
- Transferases/transaminases hepáticas séricas acima de que 2,5 vezes os  
- valores normais.  
Nesse caso, deve-se interromper o tratamento e repetir os exames em 15 dias. Se os valores das transferases/transaminases tiverem retornado ao normal, pode-se reintroduzir a isotretinoína em dose mais baixa, com controle estrito. Caso os exames se mantenham alterados, o doente deverá ser encaminhar para investigação de hepatopatia. Nos aumentos de transferases/transaminases hepáticas menores que 2,5 vezes os valores normais, reduzir a dose da isotretinoína e repetir exames em 15 dias. Se os valores estiverem normais, manter o tratamento; caso contrário, interromper o tratamento e investigar hepatopatia(30). Pacientes que apresentarem triglicerídeos acima de 800 mg/dl devem ter seu tratamento suspenso definitivamente(33).

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A resposta terapêutica geralmente não ocorre antes de 1 a 2 meses do início do tratamento; da mesma forma, os benefícios terapêuticos permanecem por alguns meses após o término da terapia. As pústulas tendem a melhorar antes das pápulas e dos nódulos, e as lesões de face tendem a responder mais rapidamente que as de tronco(2).  
Após usar a dose total cumulativa de 150 mg/kg, cerca de 15% dos casos não terão remissão completa, e, mesmo que as recomendações em termos do uso da dose ideal sejam cumpridas, ocorrerão recidivas em cerca de 20% dos pacientes(34). Os fatores de risco relacionados à recidiva são uso de dose baixa de isotretinoína(0,1-0,5 mg/kg), acne grave, acne acometendo tronco e mulheres com mais de 25 anos ao início da terapia. Geralmente as recidivas ocorrem no primeiro ano após o tratamento, raramente ocorrendo após 3 anos.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Alteração no perfil lipídico é um efeito colateral comum ao uso da isotretinoína. Estudo de coorte populacional mostrou que a elevação de triglicerídeos ocorreu em 45% dos pacientes durante o tratamento, enquanto que aumento de colesterol total foi encontrado em 30% deles(35). Geralmente essas elevações são leves e não determinam a interrupção do tratamento.  
No caso de alteração no perfil lipídico, os pacientes devem ser seguidos do ponto de vista clínico e laboratorial a cada 3 meses. É mandatório orientar-se a dieta, com redução do consumo de açúcares simples e bebida alcoólica para redução de triglicerídeos e redução no consumo alimentos ricos em gordura saturada para controle do colesterol. Considerar redução da dose de isotretinoína conforme o resultado dos exames subsequentes e da dieta(30). A incidência de elevação nos níveis séricos de transferases/transaminases hepáticas é relativamente baixa(11%), e a maioria das elevações são leves (91%)(30). Deve-se dar especial atenção aos pacientes com maior risco de hepatotoxicidade, ou seja, que apresentam os seguintes fatores: consumo de álcool, antecedente de hepatopatia e terapia medicamentosa concomitante(12,30,31,34,35).  
A associação entre depressão/suicídio e tratamento com isotretinoína foi descrita em vários estudos(36). No entanto, pequenos ensaios clínicos não confirmaram essa associação(37,38). Uma revisão sistemática sobre o tema publicada em 2007 concluiu que as informações disponíveis atualmente são insuficientes para estabelecer uma relação causal entre o medicamento e risco de depressão e suicídio(39). Bremner et al. conduziram uma ampla revisão da literatura e concluíram haver uma associação entre isotretinoína, depressão e suicídio em um subgrupo de pacientes vulneráveis, incluindo pacientes com histórico de depressão. Essa revisão tem limitações relevantes, devido à heterogeneidade dos estudos primários

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
incluídos(40). Sugere-se manter-se atento para a possibilidade do surgimento desses sintomas nos pacientes em tratamento com isotetrinoína.  
Devido aos possíveis efeitos adversos do fármaco, a relação entre o risco e o benefício deve ser avaliada nos pacientes com predisposição a desenvolver alterações nos seguintes órgãos ou sistemas:  
- Sistema nervoso central: fadiga, cefaleia, pseudotumor cerebral (hipertensão intracraniana), alterações visuais;  
- Pele e mucosas: ressecamento de pele e mucosas (xerose, conjuntivite, queilite, uretrite) e fotossensibilidade - os efeitos mucocutâneos são os mais comuns relacionados à terapia e podem ocorrer em até 100% dos pacientes;  
- Trato gastrointestinal: boca seca, náusea, vômitos, dor abdominal, doença inflamatória intestinal e sangramento intestinal;  
- Trato geniturinário: proteinúria, hematúria e perda de função renal;  
- Sistema músculo-esquelético: artralgia, dor muscular e hiperostose;  
- Olhos: conjuntivite, opacidade corneana, fotofobia, intolerância a lentes de  
- contato e diminuição da visão noturna;  
- Sistema hematopoético: anemia, leucopenia, trombocitopenia e trombocitose;  
- Possibilidade de interações medicamentosas em usuários de carbamazepina (diminuição de seu nível sérico), tetraciclina e minociclina (aumento da incidência de pseudotumor cerebral e papiledema), vitamina A (potencialização dos efeitos tóxicos da isotretinoína) e álcool (reação semelhante à do dissulfiram, com náusea, cefaleia, hipotensão e síncope).  
Deve ser realizado controle laboratorial das transferases/transaminases hepáticas, do colesterol total e frações e dos triglicerídeos antes do início do tratamento, após 30 dias e a cada 3 meses de tratamento.  
Teste de gravidez deve ser repetido uma vez por mês durante todo o tratamento(41) e até 5 semanas após a última administração da isotretinoína.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tempo de tratamento é definido pelo peso do paciente e dose diária do medicamento. Em geral, dura de 6 a 9 meses. Após o término do tratamento, o medicamento permanece no organismo por 30 dias. Entretanto, sugere-se que deva ser mantida a anticoncepção por 60 dias como medida de segurança, já que os ciclos menstruais das pacientes são variáveis, bem como o período do mês em que será interrompida a isotretinoína. Após 30 dias da suspensão do tratamento, não é mais necessária a monitorização laboratorial.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica da dose de medicamento prescrita e dispensada, e a adequação de uso e do acompanhamento pós-tratamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
É obrigatório informar ao paciente ou a seu responsável legal dos potenciais riscos, benefícios e efeitos colaterais relacionados ao uso do medicamento preconizado neste Protocolo. O TER é obrigatório ao se prescrever medicamento do Componente Especializado da Assistência Farmacêutica.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1. Sociedade Brasileira de Dermatologia. Perfil nosológico das consultas dermatológicas no Brasil. An Bras Dermatol 2006;81(6):549-58.  
2. Gollnick H, Cunliffe W, Berson D, Dreno B, Finlay A, Leyden JJ, et al. Management of acne: a report from a Global Alliance to Improve Outcomes in Acne. J Am Acad Dermatol. 2003;49(1 Suppl):S1-37.  
3. Picardi A, Abeni D, Melchi CF, Puddu P, Pasquini P. Psychiatric morbidity in dermatological outpatients: an issue to be recognized. Br J Dermatol. 2000;143(5):98391.  
4. Mallon E, Newton JN, Klassen A, Stewart-Brown SL, Ryan TJ, Finlay AY. The quality of life in acne: a comparison with general medical conditions using generic questionnaires. Br J Dermatol. 1999;140(4):672-6.  
5. Cunliffe WJ. Acne and unemployment. Br J Dermatol. 1986;115(3):386.  
6. Sinclair W, Jordaan HF; ; Global Alliance to Improve Outcomes in Acne. Acne guideline 2005 update. S Afr Med J. 2005;95(11 Pt 2):881-92.  
7. Katsambas AD, Stefanaki C, Cunliffe WJ. Guidelines for treating acne. Clin Dermatol. 2004;22(5):439-44.  
8. Katsambas A, Papakonstantinou A. Acne: systemic treatment. Clin Dermatol. 2004;22(5):412-8.  
9. Marsden JR. Lipid metabolism and retinoid therapy. Pharmacol Ther. 1989;40(1):5565.  
10. Marsden J. Hyperlipidaemia due to isotretinoin and etretinate: possible mechanisms and consequences. Br J Dermatol. 1986;114(4):401-7.  
11. Lestringant GG, Frossard PM, Agarwal M, Galadari IH. Variations in lipid and lipoprotein levels during isotretinoin treatment for acne vulgaris with special emphasis on HDL-cholesterol. Int J Dermatol. 1997;36(11):859-62.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
12. McCarter TL, Chen YK. Marked hyperlipidemia and pancreatitis associated with isotretinoin therapy. Am J Gastroenterol. 1992;87(12):1855-8.  
13. Goldsmith LA, Bolognia JL, Callen JP, Chen SC, Feldman SR, Lim HW, et al. American Academy of Dermatology Consensus Conference on the safe and optimal use of isotretinoin: summary and recommendations. J Am Acad Dermatol. 2004;50(6):900-6. 14. Costa CS, Bagatin E. Evidence on acne therapy. Sao Paulo Med J. 2013;131(3):1937.  
15. Management of Acne. Summary, Evidence Report/Technology Assessment: Number 17. AHRQ Publication No. 01-E018, March 2001. Agency for Healthcare Research and Quality, Rockville, MD.  
16. Peck GL, Olsen TG, Butkus D, Pandya M, Arnaud-Battandier J, Gross EG, et al. Isotretinoin versus placebo in the treatment of cystic acne. A randomized double-blind study. J Am Acad Dermatol. 1982;6(4 Pt 2 Suppl):735-45.  
17. Prendiville JS, Logan RA, Russell-Jones R. A comparison of dapsone with 13-cis retinoic acid in the treatment of nodular cystic acne. Clin Exp Dermatol. 1988;13(2):6771.  
18. Lester RS, Schachter GD, Light MJ. Isotretinoin and tetracycline in the management of severe nodulocystic acne. Int J Dermatol. 1985;24(4):252-7.  
19. Farrell LN, Strauss JS, Stranieri AM. The treatment of severe cystic acne with 13-cisretinoic acid. Evaluation of sebum production and the clinical response in a multipledose trial. J Am Acad Dermatol. 1980;3(6):602-11.  
20. King K, Jones DH, Daltrey DC, Cunliffe WJ. A double-blind study of the effects of 13cis-retinoic acid on acne, sebum excretion rate and microbial population. Br J Dermatol. 1982;107(5):583-90.  
21. Jones DH, King K, Miller AJ, Cunliffe WJ. A dose-response study of I3-cis-retinoic acid in acne vulgaris. Br J Dermatol. 1983;108(3):333-43.  
22. Stewart ME, Benoit AM, Stranieri AM, Rapini RP, Strauss JS, Downing DT. Effect of oral 13-cis-retinoic acid at three dose levels on sustainable rates of sebum secretion and on acne. J Am Acad Dermatol. 1983;8(4):532-8.  
23. van der Meeren HL, van der Schroeff JG, Stijnen T, van Duren JA, van der Dries HA, van Voorst Vader PC. Dose-response relationship in isotretinoin therapy for conglobate acne. Dermatologica. 1983;167(6):299-303.  
24. Strauss JS, Rapini RP, Shalita AR, Konecky E, Pochi PE, Comite H, et al. Isotretinoin therapy for acne: results of a multicenter dose-response study. J Am Acad Dermatol. 1984;10(3):490-6.  
25. Layton AM, Knaggs H, Taylor J, Cunliffe WJ. Isotretinoin for acne vulgaris--10 years later: a safe and successful treatment. Br J Dermatol. 1993;129(3):292-6.  
26. Gollnick HP, Graupe K, Zaumseil RP. Comparison of combined azelaic acid cream plus oral minocycline with oral isotretinoin in severe acne. Eur J Dermatol. 2001;11(6):538-44.  
27. Kaymak Y, Ilter N. The results and side effects of systemic isotretinoin treatment in 100 patients with acne vulgaris. Dermatol Nurs. 2006;18(6):576-80.  
28. Akman A, Durusoy C, Senturk M, Koc CK, Soyturk D, Alpsoy E. Treatment of acne with intermittent and conventional isotretinoin: a randomized, controlled multicenter study. Arch Dermatol Res. 2007;299(10):467-73.  
29. Oprica C, Emtestam L, Hagströmer L, Nord CE. Clinical and microbiological comparisons of isotretinoin vs. tetracycline in acne vulgaris. Acta Derm Venereol. 2007;87(3):246-54.  
30. Chivot M. Retinoid therapy for acne. A comparative review. Am J Clin Dermatol. 2005;6(1):13-9. 31. Thielitz A, Krautheim A, Gollnick H. Update in retinoid therapy of acne. Dermatol Ther. 2006;19(5):272-9.  
32. Nast A, Rosumeck S, Sammain A, Sporbeck B, Rzany B. Methods report on the development of the European S3 guidelines for the treatment of acne. J Eur Acad Dermatol Venereol. 2012;26(Suppl. 1):e1-e39.  
33. Ormerod AD, Campalani E, Goodfield MJ. British Association of Dermatologists guidelines on the efficacy and use of acitretin in dermatology. Br J Dermatol. 2010;162(5):952-63.  
34. Stainforth JM, Layton AM, Taylor JP, Cunliffe WJ. Isotretinoin for the treatment of acne vulgaris: which factors may predict the need for more than one course? Br J Dermatol. 1993;129(3):297-301.  
35. Zane LT, Leyden WA, Marqueling AL, Manos MM. A population-based analysis of laboratory abnormalities during isotretinoin therapy for acne vulgaris. Arch Dermatol. 2006;142(8):1016-22.  
36. Wysowski DK, Pitts M, Beitz J. An analysis of reports of depression and suicide in patients treated with isotretinoin. J Am Acad Dermatol. 2001;45(4):515-9.  
37. Ferahbas A, Turan MT, Esel E, Utas S, Kutlugun C, Kilic CG. A pilot study evaluating anxiety and depressive scores in acne patients treated with isotretinoin. J Dermatolog Treat. 2004;15(3):153-7.  
38. Bremner JD, Fani N, Ashraf A, Votaw JR, Brummer ME, Cummins T, et al. Functional brain imaging alterations in acne patients treated with isotretinoin. Am J Psychiatry. 2005;162(5):983-91.  
39. Marqueling AL, Zane LT. Depression and suicidal behavior in acne patients treated with isotretinoin: a systematic review. Semin Cutan Med Surg. 2007;26(4):210-20.  
40. Bremner JD, Shearer KD, McCaffery PJ. Retinoic acid and affective disorders: The evidence for an association. J Clin Psychiatry. 2012;73(1):37-50.  
41. Oral isotretinoin therapy for acne vulgaris [Internet]. UpToDate; 2014 [acesso em 30/08/2014]. Disponível em: http://www.uptodate.com/contents/oral-isotretinointherapy-for-acne-vulgaris.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Eu,_____________________________________________________ (nome do (a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento isotretinoína, indicado para o tratamento da acne grave.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _____________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer o seguinte benefício:  
- melhora da pele.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento contraindicado na gestação ou em mulheres que planejam engravidar;  
- medicamento contraindicado em casos de alergia ao fármaco, à vitamina A e a seus derivados;  
- os efeitos adversos incluem pele e mucosas (boca, nariz, vagina) secas, coceiras na pele, rouquidão, ressecamento e problemas nos olhos (p. ex.: conjuntivite, catarata), queda ou aumento do crescimento dos cabelos, dores musculares, dores nas juntas, dores de cabeça, zumbido no ouvido, náusea, vômitos, diarreia, diminuição das células brancas e vermelhas do sangue, aumento ou diminuição das plaquetas (células da coagulação), aumento dos triglicerídeos ou do colesterol, aumento do ácido úrico no sangue, aumento da possibilidade de infecções. Os efeitos mais raros incluem inflamação do pâncreas (pancreatite) e inflamação do fígado (hepatite);  
- pode ocorrer uma piora da acne nas primeiras semanas do tratamento; - pacientes com problemas depressivos devem ser cuidadosamente  
- acompanhados em caso de piora do quadro;  
- recomenda-se a utilização de cremes com fator de proteção solar, visto que o sol pode provocar o aparecimento de reações na pele;  
- o risco de ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que esse medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.

---

<!-- METADADOS: doenca: Isotretinoína no tratamento da acne grave | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim (   ) Não  
|Local:                                                                Data:||
|---|---|
|Nome dopaciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||
|Documento de identificação do responsável leg|al:|
|_____________________________________<br>Assinatura dopaciente ou do responsável legal||
|Médico Responsável:<br>CRM:|UF:|  
___________________________ Assinatura e carimbo do médico Data:____________________  
Observação: Este termo é obrigatório ao se solicitar o fornecimento de medicamento do Componente Especializado da Assistência Farmacêutica e deverá ser preenchido em duas vias, ficando uma arquivada na farmácia e a outra entregue ao usuário ou seu responsável legal.

---

