<!-- METADADOS: doenca: Colangite Biliar Primária | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 11, DE 09 DE SETEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Colangite Biliar Primária.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o  SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a colangite biliar primária no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 459/2019 e o Relatório de Recomendação n<sup><u>o</u></sup> 470 – Julho de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Colangite Biliar Primária.  
Parágrafo único. O Protocolo, objeto deste artigo, que contém o conceito geral da colangite biliar primária, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado</u> pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da colangite biliar primária.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
FRANCISCO DE ASSIS FIGUEIREDO  
DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **1. INTRODUÇÃO** -->
A colangite biliar primária (CBP), anteriormente denominada cirrose biliar primária, é uma doença hepática colestática crônica progressiva, autoimune com reatividade sorológica para anticorpos antimitocondriais (AAM) e anticorpo antinúcleo (AAN), caracterizada pela inflamação e destruição progressiva dos ductos biliares interlobulares de pequeno e médio calibre. Apresenta evidência histológica de colangite crônica não-supurativa, granulomatosa, linfocitária de ductos biliares de pequeno calibre<sup>1–3</sup> .  
A etiologia da doença não é clara, contudo, interações imunogenéticas e ambientais<sup>2</sup> parecem desencadear uma intensa resposta autoimune contra as células epiteliais biliares, levando à lesões hepato-biliares<sup>4</sup> .  
A CBP deve ser suspeitada em pacientes com anormalidades colestáticas persistentes, por mais de 6 meses, em testes bioquímicos séricos hepáticos, ou sintomas como fadiga e prurido<sup>1</sup> . Trata-se de um distúrbio hepático raro que afeta predominantemente as mulheres (10:1), com a mediana de idade do início da doença de 50 anos<sup>5</sup> e raros relatos de caso na adolescência<sup>6,7</sup> . Os pacientes mais jovens são os mais afetados, com comprometimento da qualidade de vida devido aos sintomas da doença. Neste sentido, a menor capacidade funcional imposta pela fadiga e as implicações sociais do prurido, limitam a vida social destes pacientes<sup>8</sup> . Esta doença pode evoluir para cirrose, doença hepática terminal ou a morte<sup>1,2,9</sup> .  
No momento do diagnóstico cerca de metade dos pacientes são assintomáticos<sup>10,11</sup> . Entretanto, mesmo em fase assintomática, o tratamento pode retardar a progressão e melhorar a sobrevida do paciente livre de transplante<sup>12</sup> .  
Uma revisão sistemática que avaliou estudos epidemiológicos de base populacional de diversos países, apontou incidência variando de 0,33 a 5,8 por 100 mil habitantes e prevalência variando de 1,91 a 40,2 por 100 mil habitantes, evidenciando grande incerteza nestes parâmetros<sup>13</sup> . Todavia, atualmente não existem estudos que descrevam dados epidemiológicos para a CBP na população brasileira.  
Neste contexto, o presente documento tem como objetivo orientar os profissionais de saúde quanto ao diagnóstico e tratamento adequado da CBP a fim de evitar complicações.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da colangite biliar primária. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- K74.3 Cirrose biliar primária (Colangite destrutiva não-supurativa crônica)

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **3. DIAGNÓSTICO** -->
O diagnóstico de CBP é baseado em achados clínicos, laboratoriais e exames de imagem.  
<u>Diagnóstico Clínico</u>  
O paciente típico com doença sintomática é mulher de meia idade com queixas de fadiga e prurido. Outros sinais e sintomas, incluem dor abdominal no quadrante superior direito, dor, anorexia, hiperpigmentação, xantelasma, hepatoesplenomegalia, icterícia, alteração no padrão do sono, osteoporose e síndrome de má-absorção. A icterícia costuma ocorrer no curso mais avançado da doença<sup>14</sup> .  
Outras doenças autoimunes podem ser vistas com uma maior frequência em pacientes com CBP, como síndrome de Sjögren (SICCA síndrome), esclerodermia, síndrome de CREST, tireoidite, artrite, síndrome de Raynaud, doença celíaca e lúpus eritematoso sistêmico<sup>15,16</sup> .  
O diagnóstico da CBP deve ser suspeitado nos pacientes com colestase crônica, por mais de 6 meses, depois da exclusão de outras causas de doença do fígado, particularmente em mulheres com elevação inexplicada de fosfatase alcalina sérica(FA)<sup>17</sup> .  
Os diagnósticos diferenciais incluem colestase medicamentosa, obstrução biliar, sarcoidose, hepatite autoimune, colangite esclerosante primária<sup>17</sup> e hepatites virais<sup>18</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: <u>Imagem</u> -->
A avaliação não-invasiva por imagem do fígado e da árvore biliar é mandatória em todos os pacientes com evidência bioquímica de colestase<sup>17</sup> . A ausência de dilatação do ducto biliar  
indica que a causa da colestase deve ser intra-hepática, enquanto que a dilatação dos ductos sugere a avaliação de causas extra-hepáticas<sup>14</sup> . Usualmente, a ultrassonografia é o primeiro exame a ser feito para excluir obstrução extra-hepática biliar, que é parte do diagnóstico diferencial da CBP 15. Pode-se também usar tomografia computadorizada ou ressonância magnética14.  
A colangioressonância por ressonância magnética é um exame seguro e com acurácia para detecção de estenose e dilatação de ductos intra- e extra-hepáticos, sendo fundamental para diagnóstico de colangite esclerosante primária ou secundária<sup>1</sup> . A colangiopancreatografia retrógrada por via endoscópica é clinicamente equivalente na detecção de lesões e litíase por ductos biliares causada por obstrução extra-hepática, particularmente no ducto biliar distal<sup>1</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **3.1 DIAGNÓSTICO LABORATORIAL** -->
O diagnóstico de CBP envolve métodos bioquímicos, imunológico e, eventualmente, histológicos. A confirmação diagnóstica é realizada na presença de 2 dos 3 critérios apresentados a seguir<sup>1,19,20</sup> e de acordo com o fluxograma de Diagnóstico de Colangite Biliar Primária abaixo.  
- Elevação de enzimas colestáticas, especialmente da FA;  
- Presença de anticorpos antimitocondriais (AAM) ou anticorpo antinúcleo (AAN) por imunoflourescencia indireta, padrões nucleares tipo membrana nuclear e nuclear pontilhado com pontos isolados ou por Elisa,  anti- gp210 e  anti-sp-100<sup>1,17</sup> ;  
- Evidência histológica de colangite destrutiva não-supurativa.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: _<u>Marcadores Bioquímicos</u>_ -->
No início do curso da doença, a CBP é caracterizada por níveis séricos elevados de FA e gama-glutamiltransferase (GGT), enquanto no curso mais tardio da doença há níveis séricos elevados de bilirrubina e diminuição da albumina sérica, sendo considerados como importantes marcadores<sup>18</sup> . A elevação da FA e da bilirrubina correlaciona-se com a progressão da doença, enquanto valores mais baixos são preditores de maior sobrevida e de menor necessidade de transplante hepático<sup>21</sup> .  
Quase todos os pacientes têm aumento de FA, tipicamente ≥ 1,5 vezes o limite superior da normalidade, e elevação de GGT<sup>14,15</sup> . As aminotransferases/transaminases séricas, aspartatoaminotransferase (AST/TGO) e alanino-aminotransferase (ALT/TGP), estão levemente aumentadas (geralmente, <3 vezes o limite superior normal). Elevações de AST e ALT acima de 5 vezes o limite superior da normalidade são incomuns e sugerem síndrome de sobreposição de hepatite autoimune e CBP ou coexistência de hepatites virais<sup>14</sup> .  
Uma queda na albumina sérica e na contagem de plaquetas são indicadores do desenvolvimento de cirrose e de hipertensão portal<sup>17</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: _<u>Marcadores Imunológicos</u>_ -->
Em pacientes com colestase intra-hepática crônica, a pesquisa de AAM é útil para confirmação diagnóstica. Títulos séricos elevados são detectados em cerca de 95% dos doentes, a reatividade AAM é classicamente estudada por imunofluorescência indireta ou por ELISA. Não há evidências de superioridade de uma técnica sobre a outra e a técnica escolhida é baseada na experiência local e na disponibilidade<sup>18</sup> . A titulação do AAM é considerada positiva quando for ≥1/40<sup>16,17,22,23</sup> . Indivíduos assintomáticos, AAM positivos, podem eventualmente desenvolver a doença<sup>23</sup> .  
Em indivíduos com AAM negativo, recomenda-se pesquisa de AAN, que pode ser realizada por imunofluorescencia indireta, padrões nucleares tipo membrana nuclear ( _perinuclear rims_ ) e nuclear pontilhado com pontos isolados ( _nuclear dots)_ ou por Elisa,  gp210 e sp-100, os quais são encontrados em até 30%-50% dos pacientes com CBP<sup>16,23</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: _<u>Métodos Histológicos</u>_ -->
A biópsia hepática é recomendada para o diagnóstico de CBP em indivíduos com AAM negativo e AAN (padrões específicos de CBP) negativo, colangiorressonância ou colangiopancreatografia retrógrada por via endoscópica normais, com quadro clínico sugestivo de CBP, conforme o fluxograma de diagnóstico de CBP. Em pacientes com AAM positivos e bioquímica hepática colestática, a biópsia não é recomendada, visto que não aumenta a acurácia diagnóstica<sup>18,24</sup> . Na prática clínica, a maior parte dos pacientes é diagnosticada clínica e laboratorialmente de forma adequada e segura sem a necessidade da biópsia hepática<sup>18</sup> . Ainda, a biópsia, pode ser útil para a avaliação da atividade e estadiamento da doença. As lesões histológicas da CBP classicamente dividem-se em quatro estágios, como proposto por Ludwig et al.<sup>25</sup> e Scheuer<sup>26</sup> , de acordo com o grau de lesão do canal biliar, inflamação e fibrose. A Tabela 1 demonstra o sistema de estadiamento das lesões histológicas da CBP<sup>22</sup> .  
**Tabela 1 -** Estadiamento das lesões histológicas da CBP.  
|**Estadiament**|**o**<br>**Scheuer**|**Ludwig**|
|---|---|---|
|**I (Portal)**|Inflamação portal com lesão do ducto|Inflamação portal com lesão do ducto|
||biliar, contendo ou não lesão ductal|biliar, contendo ou não lesão ductal|
||florida|florida|  
**II** Reação ductular (fibrose periportal Inflamação periportal (fibrose **(Periportal)** presente) periportal presente) **III (Septal)** Fibrose em ponte (ductopenia Fibrose em ponte (ductopenia normalmente presente) normalmente presente) **IV (Cirrose)** Cirrose biliar Cirrose biliar  
<!-- Start of picture text -->
Fluxograma de Diagnéstico de Colangite Biliar Primaria (CBP)<br>Colestase Hepatica Crénica<br>(FA 21,5 LSN por 6 meses)<br>*Diagnosticos Diferenciais:<br>Descartar PEERSJ zs Diferenciais*" a ColestaseHepatitesmedicamentosa,virais<br>Exame de Imagem (US preferivel). ObstrucaoSa aabiliar,<br>Hepatite autoimune,<br>Colangite esclerosante primaria.<br>Mantém suspeita de CBP?<br>[no]<br>Solicitar AAM Seguir investigacao<br>de diagnésticos alternativos<br>Solicitar AAN<br>(anti-sp 100, anti-gp210)<br>Negativo}<br>Solicitar colangioressonancia (preferivel)<br>ou colangiopancreatografia retrégrada (via endoscdpica)<br>rr 7 Estenosee dilatagao<br>intra- e/ou extra-hepaticas<br>Bidpsia do figado Seguir investigacao<br>de diagnésticos alternativos<br>Seguir investigacao<br>de diagnésticos alternativos<br><!-- End of picture text -->  
Legenda: FA, fosfatase alcalina; LSN, limite superior da normalidade; AAM, anticorpo antimitocôndria; AAN, anticorpo antinúcleo; CBP, colangite biliar primária.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com diagnóstico de CBP, de acordo com o item 3 de diagnóstico, de ambos os sexos, que preencham pelo menos, 2 de 3 dos seguintes critérios diagnósticos:  
- Elevação de enzimas colestáticas, especialmente da FA;  
- Presença de AAM ou AAN (padrões específicos à imunofluorescência ou anti-gp210 e anti-sp-100 por Elisa);  
- Evidência histológica de colangite destrutiva não-supurativa.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos do tratamento com o ácido ursodesoxicólico os pacientes que se  
enquadrem nas seguintes situações:  
- Alergia a ácido ursodesoxicólico ou a qualquer um dos componentes da formulação;  
- Úlcera péptica (gástrica ou duodenal) em fase ativa;  
- Doença intestinal inflamatória e outras condições do intestino delgado, cólon e fígado, que possam interferir com a circulação entero-hepática dos sais biliares (ressecção ileal e estoma, colestase intra e extra-hepática, doença hepática grave);  
- Cólicas biliares frequentes;  
- Inflamação aguda da vesícula biliar ou trato biliar;  
- Oclusão do trato biliar (oclusão do ducto biliar comum ou um ducto cístico);  
- Contratilidade comprometida da vesícula biliar;  
- Cálculos biliares calcificados radiopacos;  
- Pacientes com intolerância a galactose, deficiência de Lapp lactase ou má absorção de glicose galactose.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **6. CASOS ESPECIAIS** -->
A evidência científica apontada na literatura para tratamento de gestantes com CBP com ácido ursodesoxicólico é limitada a série de casos<sup>27</sup> . Portanto, recomenda-se a utilização de métodos contraceptivos em mulheres em idade fértil com diagnóstico de CBP. Em gestantes, quando o tratamento medicamentoso for claramente necessário, o hepatologista deve ser consultado e o tratamento deve ser individualizado.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **7.1. TRATAMENTO NÃO MEDICAMENTOSO** -->
Os pacientes com CBP devem ser orientados a suspender o consumo de álcool ou tabaco e evitar o uso alimentos e bebidas com a presença de cafeína. Deve ser incentivada prática de exercícios físicos regulares, e a adoção de uma dieta balanceada<sup>10</sup> .  
Pacientes com prurido intratável grave, resistência ao tratamento medicamentoso e complicações cirróticas devem ser avaliados para receber transplante hepático. O transplante de hepático é eficaz, mas só deve ser considerado quando as demais intervenções disponíveis mostrarem ineficácia.  
O transplante hepático melhorou drasticamente a sobrevida em doentes com CBP em estádio avançado. As indicações para transplante hepático em pacientes com CBP são as mesmas que para pacientes com outras etiologias de insuficiência hepática<sup>28–30</sup> . As taxas de sobrevida são superiores a 90% e, após cinco anos, as taxas de sobrevida são de 80%-85%<sup>31</sup> .  
Estes doentes devem ser encaminhados para um centro de transplante hepático, habilitado pelo SUS, conforme preconizado na Portaria nº 2.600, de 21 de outubro de 2009.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **7.2. TRATAMENTO MEDICAMENTOSO – Ácido ursodesoxicólico** -->
O primeiro  tratamento aprovado pela agência _U.S. Food and Drug Administration_ para CBP foi o ácido Ursodesoxicólico<sup>15</sup> . O ácido ursodesoxicólico é um ácido biliar hidrofílico que inibe a síntese hepática do colesterol e estimula a síntese de ácidos biliares, reestabelecendo o equilibro entre eles. Deste modo, o medicamento possui propriedades citoprotetoras, coleréticas, imunomoduladoras, anti-inflamátorias, baixa propriedade hepatotóxica, ou seja, é seguro<sup>10</sup> . O tratamento com ácido ursodesoxicólico é considerado o esquema de primeira linha para todos os pacientes com CBP e usualmente é mantido por vida toda. O medicamento pode ser utilizada em qualquer estágio da CBP, desde que as enzimas hepáticas colestáticas sejam anormais<sup>1</sup> . Pacientes que são diagnosticados em idade mais precoce (<50 anos) tem maior probabilidade de apresentar sintomas mais intensos, diminuição da qualidade de vida, menor probabilidade de responder ao tratamento com ácido ursodesoxicólico e apresentam um curso mais agressivo da doença<sup>32</sup> .  
As evidências que fundamentam a eficácia e segurança deste medicamento são encontradas em revisões sistemáticas de ensaios clínicos randomizados e estudos de coorte.  
Os estudos não evidenciaram diferença estatisticamente significantes para os desfechos eventos adversos graves e mortalidade quando comparado ao placebo/não tratamento. O ácido ursodesoxicólico é bem tolerado e seguro com mínimos efeitos adversos. O efeito adverso mais comum é ganho de peso. Outros efeitos adversos mais comuns da ácido ursodesoxicólico: diarreia e fezes pastosas. Outros efeitos adversos mais raros (ocorre em menos de 0,01% dos pacientes que utilizam este medicamento): intensa dor abdominal superior direita durante tratamento de  
colangite biliar primária; descompensação hepática foi observada em terapia de estágios avançados de cirrose biliar primária que regrediu parcialmente após a descontinuidade do tratamento; urticária; calcificação de cálculos<sup>33</sup> . Já com relação à eficácia, os estudos apontaram sobrevida global maior no grupo tratado com ácido ursodesoxicólico<sup>34</sup> .  
A sobrevida livre de transplante no acompanhamento em longo prazo foi maior no grupo de pacientes tratados com ácido ursodesoxicólico a partir do quinto ano de tratamento, com resultados estatisticamente significantes para os anos 5, 8 e 10 (p < 0,01)<sup>34</sup> .  
Aproximadamente 65% dos pacientes com CBP respondem integralmente ao tratamento com ácido ursodesoxicólico e têm uma expectativa de vida normal<sup>35</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **8. FÁRMACOS** -->
- Ácido ursodesoxicólico: comprimido de 50 mg, 150 mg e 300 mg.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **8.1. ESQUEMA DE ADMINISTRAÇÃO** -->
- Ácido ursodesoxicólico: 13 mg a 15 mg/kg/dia, via oral, dose única ou dividida em até  
quatro doses diárias.  
Caso seja necessário o uso concomitante de substâncias que inibem a absorção intestinal de ácidos biliares, como a colestiramina, colestipol ou antiácidos à base de alumínio, estas devem ser tomadas ao menos 2 horas antes ou após o ácido ursodesoxicólico<sup>33</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **8.2. CONTRAINDICAÇÕES** -->
Efeitos colaterais são mínimos e infrequentes, havendo relatos de pequeno ganho de peso no primeiro ano de tratamento e efeitos gastrointestinais<sup>10</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **9. TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
O tempo de tratamento não pode ser pré-determinado e deve ser realizado a longo prazo. Espera-se benefícios em termos de retardo ou interrupção da evolução da doença, quando realizado de maneira continua<sup>36</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **10. BENEFÍCIOS ESPERADOS** -->
Espera-se com este Protocolo o diagnóstico ágil para os pacientes com CBP e o tratamento adequado contribua para a redução dos sintomas, prurido e fadiga, por meio de diagnóstico precoce e reversão ou regressão das lesões hepáticas, aumento na sobrevida livre de transplante, melhora dos sintomas e da qualidade de vida dos pacientes.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **11. MONITORIZAÇÃO** -->
A resposta bioquímica ao tratamento é avaliada após um ano, depois do início do tratamento com testes bioquímicos hepáticos, mais especificamente FA e bilirrubina total, usando um dos critérios estabelecidos na Tabela 2<sup>17</sup> . O paciente que não respondeu adequadamente deve ser avaliado em relação à adesão terapêutica e quanto à possibilidade de outros diagnósticos associados, tais como síndrome de sobreposição ou doença celíaca<sup>16,18</sup> .  
As medidas FA e bilirrubinas são duas fortes variáveis usadas para predizer prognóstico.  
Mais da metade dos pacientes, 60%, tratados apresentam melhora nos marcadores bioquímicos, a qual pode ser observada entre um e seis meses após o início, sendo que a maioria dos casos responde ao tratamento ainda nos primeiros três meses<sup>10</sup> .  
**Tabela 2** - Avaliação da resposta ao tratamento com ácido ursodesoxicólico em pacientes com CBP<sup>1</sup> .  
|**Definições**<br>**qualitativas**|**binárias**|**Tempo**<br>**(meses)**|**Falha ao tratamento**|
|---|---|---|---|
|Barcelona||12|Redução < 40% na ALP e ALP ≥ 1 x LSN|
|Paris I||12|ALP ≥ 3 x LSN ou AST ≥2 x LSN ou bilirrubina<br>>1mg/dl|
|Roterdã||12|Bilirrubina ≥1 x LSN ou albumina <1 x LSN|
|Toronto||24|ALP >1,67 x LSN|
|Paris II||12|ALP≥1,5 x LSN ou AST≥1,5 x LSN ou bilirrubina<br>> 1mg/dl|
|**Sistema**<br>**de**<br>**contínuos**|**escores**|**Tempo**<br>**(meses)**|**Parâmetros de pontuação**|
|UK-CBP||12|Bilirrubina, ALP e AST (ou ALT) em 12 meses.<br>Albumina e contagem de plaquetas no baseline|
|GLOBE||12|Bilirrubina,<br>ALP,<br>albumina,<br>contagem<br>de<br>plaquetas em 12 meses. Idade no baseline.|  
Legenda: GGT: gama-glutamiltransferase; ALP: fosfatase alcalina; AST/TGO: aspartato aminotranferase; LSN: limite superior do normal.  
Alguns pacientes podem apresentar piora do quadro clínico no início do tratamento, por exemplo, piora do prurido ou diarreia. Neste caso, a dose do ácido ursodesoxicólico deve ser reduzida até a melhora dos sintomas e gradualmente aumentado de acordo com a tolerância do paciente. Em caso de persistência dos sintomas a terapia deve ser descontinuada<sup>33</sup> .

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **12. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
Pacientes com CBP devem ser atendidos em serviços especializados, preferentemente em centros de referência em hepatologia, para seu adequado diagnóstico, tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **13. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste PCDT, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: **14. REFERÊNCIAS BIBLIOGRÁFICAS** -->
- 1 Hirschfield GM, Beuers U, Corpechot C, _et al._ EASL Clinical Practice Guidelines: The diagnosis and management of patients with primary biliary cholangitis. _J Hepatol_ 2017; **67** : 145–72.  
- 2 Liberal R, Grant CR. Cirrhosis and autoimmune liver disease: Current understanding. _World J Hepatol_ 2016; **8** : 1157–68.  
- 3 Harinck F. Primary biliary cholangitis, let’s try to keep the new nomenclature correct! _Neth J Med_ 2016; **74** : 229–30.  
- 4 Rudic JS, Poropat G, Krstic MN, Bjelakovic G,, Gluud C. Ursodeoxycholic acid for primary biliary cirrhosis (Review). 2012.  
- 5 Griffiths L, Dyson JK, Jones DEJ. The new epidemiology of primary biliary cirrhosis. _Semin Liver Dis_ 2014; **34** : 318–28.  
- 6 Dahlan Y, Smith L, Simmonds D, _et al._ Pediatric-onset primary biliary cirrhosis. _Gastroenterology_ 2003; **125** : 1476–9.  
- 7 Kitic I, Boskovic A, Stankovic I, Prokic D. Twelve-Year-Old Girl with Primary Biliary Cirrhosis. _Case Rep Pediatr_ 2012; **2012** . DOI:10.1155/2012/937150.  
- 8 Dyson JK, Wilkinson N, Jopson L, _et al._ The inter-relationship of symptom severity and quality of life in 2055 patients with primary biliary cholangitis. _Aliment Pharmacol Ther_ 2016; **44** : 1039–50.  
- 9 Lleo A, Jepsen P, Morenghi E, _et al._ Evolving Trends in Female to Male Incidence and Male Mortality of Primary Biliary Cholangitis. _Sci Rep_ 2016; **6** : 25906.  
- 10 Sociedade Brasileira de Hepatologia. Recomendações da sociedade brasileira de hepatologia para diagnóstico e tratamento das doenças colestáticas e hepatite autoimune - parte II. 2015.  
- 11 Saffioti F, Gurusamy KS, Eusebi LH, Tsochatzis E, Davidson BR, Thorburn D. Pharmacological interventions for primary biliary cholangitis: an attempted network metaanalysis. _Cochrane Database Syst Rev_ 2017; **3** : CD011648.  
- 12 Gatselis NK, Dalekos GN. Molecular diagnostic testing for primary biliary cholangitis. _Expert Rev Mol Diagn_ 2016; **16** : 1001–10.  
- 13 Boonstra K, Beuers U, Ponsioen CY. Epidemiology of primary sclerosing cholangitis and primary biliary cirrhosis: a systematic review. _J Hepatol_ 2012; **56** : 1181–8.  
- 14 Qayed E, Srinivasan S, Shahnavaz N. Sleisenger and Fordtran’s Gastrointestinal and Liver Disease Review and Assessment, 10e. 2016.  
- 15 Boyer TD, Wright TL, Manns MP. Zakim and Boyer’s Hepatology. 2006 DOI:10.1016/B9781-4160-3258-8.X5001-3.  
- 16 Bittencourt PL, Cançado ELR, Couto CA, _et al._ Brazilian society of hepatology recommendations for the diagnosis and management of autoimmune diseases of the liver. _Arq Gastroenterol_ 2015; **52 Suppl 1** : 15–46.  
- 17 Lindor KD, Bowlus CL, Boyer J, Levy C, Mayo M. Primary Biliary Cholangitis: 2018 Practice Guidance from the American Association for the Study of Liver Diseases. _Hepatol Baltim Md_ 2019; **69** : 394–419.  
- 18 Hirschfield GM, Dyson JK, Alexander GJM, _et al._ The British Society of Gastroenterology/UK-PBC primary biliary cholangitis treatment and management guidelines. _Gut_ 2018; **67** : 1568–94.  
- 19 Huang Y-Q. Recent advances in the diagnosis and treatment of primary biliary cholangitis. _World J Hepatol_ 2016; **8** : 1419–41.  
- 20 Lindor KD, Gershwin ME, Poupon R, _et al._ Primary biliary cirrhosis. _Hepatol Baltim Md_ 2009; **50** : 291–308.  
- 21 Nevens F, Andreone P, Mazzella G, _et al._ A Placebo-Controlled Trial of Obeticholic Acid in Primary Biliary Cholangitis. _N Engl J Med_ 2016; **375** : 631–43.  
- 22 Associação Europeia para o Estudo do Fígado. Recomendações de Orientação Clínica da EASL: Abordagem de doenças hepáticas colestáticas. _J Hepatol_ 2009; **51** : 237–67.  
- 23 Liberal R, Grant CR. Cirrhosis and autoimmune liver disease: Current understanding. _World J Hepatol_ 2016; **8** : 1157–68.  
- 24 Zein CO, Angulo P, Lindor KD. When is liver biopsy needed in the diagnosis of primary biliary cirrhosis? _Clin Gastroenterol Hepatol Off Clin Pract J Am Gastroenterol Assoc_ 2003; **1** : 89–95.  
- 25 Ludwig J, Dickson ER, McDonald GS. Staging of chronic nonsuppurative destructive cholangitis (syndrome of primary biliary cirrhosis). _Virchows Arch A Pathol Anat Histol_ 1978; **379** : 103–12.  
- 26 Scheuer PJ. Primary biliary cirrhosis: diagnosis, pathology and pathogenesis. _Postgrad Med J_ 1983; **59 Suppl 4** : 106–15.  
- 27 Trivedi PJ, Kumagi T, Al-Harthy N, _et al._ Good maternal and fetal outcomes for pregnant women with primary biliary cirrhosis. _Clin Gastroenterol Hepatol Off Clin Pract J Am Gastroenterol Assoc_ 2014; **12** : 1179-1185.e1.  
- 28 Kuiper EMM, Hansen BE, Metselaar HJ, _et al._ Trends in liver transplantation for primary biliary cirrhosis in the Netherlands 1988-2008. _BMC Gastroenterol_ 2010; **10** : 144.  
- 29 Levy C. Primary Biliary Cholangitis Guidance Update: Implications for Liver Transplantation. _Liver Transplant Off Publ Am Assoc Study Liver Dis Int Liver Transplant Soc_ 2018; **24** : 1508– 11.  
- 30 MacQuillan GC, Neuberger J. Liver transplantation for primary biliary cirrhosis. _Clin Liver Dis_ 2003; **7** : 941–56, ix.  
- 31 Milkiewicz P. Liver transplantation in primary biliary cirrhosis. _Clin Liver Dis_ 2008; **12** : 461– 72; xi.  
- 32 Carbone M, Mells G, Pells G, _et al._ Sex and Age Are Determinants of the Clinical Phenotype of Primary Biliary Cirrhosis and Response to Ursodeoxycholic Acid. 2012 DOI:10.1053/j.gastro.2012.12.005.  
- 33 Zambon Laboratórios Farmacêuticos Ltda. Ursacol®. 2015; published online Sept 1.  
- 34 Ministério da Saúde. Relatório 392 - Ácido ursodesoxicólico para colangite biliar. 2018; published online Oct 17.  
- 35 Corpechot C, Abenavoli L, Rabahi N, _et al._ Biochemical response to ursodeoxycholic acid and long-term prognosis in primary biliary cirrhosis. _Hepatol Baltim Md_ 2008; **48** : 871–7.  
- 36 David E. J. Jones, James Neuberger, Ian R. Mackay, Ned Snyder. Colangite biliar primária - Referências | BMJ Best Practice. https://bestpractice.bmj.com/topics/pt-br/344/references (accessed Feb 20, 2019).  
- 37 Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas : elaboração de diretrizes clínicas, 1<sup>o</sup> edição. Brasília: Editora MS/CGDI http://conitec.gov.br/images/Relatorios/2016/Diretrizes_Metodologicas_WEB.pdf.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: ÁCIDO URSODESOXICÓLICO -->
Eu, _____________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do **ácido ursodesoxicólico** , indicadas para o tratamento de **colangite biliar primária** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico ______________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas e redução das complicações.  
- Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais  
- efeitos adversos e riscos: Não há dados quanto ao uso de ácido ursodesoxicólico, particularmente em mulheres  
- grávidas. Experimentos com animais demonstraram toxicidade reprodutiva durante os estágios iniciais da gravidez.  
- Os riscos do uso de ácido ursodesoxicólico para o bebê durante a gestação são improváveis.  
- Entretanto, caso engravide, deve avisar imediatamente o médico;  
- **efeitos adversos mais comuns da ácido ursodesoxicólico** : Ganho de peso, diarreia e fezes pastosas.  
- **efeitos adversos mais raros** (ocorre em menos de 0,01% dos pacientes que utilizam este medicamento): intensa dor abdominal superior direita durante tratamento de colangite biliar primária; descompensação hepática foi observada em terapia de estágios avançados de cirrose biliar primária que regrediu parcialmente após a suspensão do tratamento; urticária; calcificação de cálculos.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.      (   ) Sim            (   ) Não  
Local:                                                             Data: <u>Nome do paciente:</u> Cartão Nacional de Saúde: <u>Nome do responsável legal:</u> Documento de identificação do responsável legal:  
_____________________________________ Assinatura do paciente ou do responsável legal Médico responsável: CRM: UF: ___________________________ Assinatura e carimbo do médico Data:____________________  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Colangite Biliar Primária | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
O processo de desenvolvimento deste Protocolo utilizou como base a Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>37</sup> . A Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) foram consultados para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas no SUS para o tratamento da colangite biliar primária.  
A Portaria nº 47/SCTIE/MS, de 16 de outubro de 2018, tornou pública a decisão de incorporar o ácido ursodesoxicólico para o tratamento da colangite biliar primária no âmbito do SUS e, deste modo, o medicamento encontra-se incluso neste PCDT. Neste sentido, este PCDT utilizou as buscas de evidência, resultados e referências do Relatório de Recomendação nº 392/2018, ácido ursodesoxicólico para colangite biliar primária, disponível em: <u>http://conitec.gov.br/images/Relatorios/2018/Recomendacao/Relatorio_Acidoursodesoxicolico_ ColagiteBiliar.pdf para elaborar as recomendações do tratamento medicamentoso.</u>  
Para elaboração dos demais itens deste documento foram utilizados _guidelines_ internacionais e nacionais.

---

