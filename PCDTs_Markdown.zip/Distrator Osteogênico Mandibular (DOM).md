<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE -->
PORTARIA CONJUNTA SAES/SECTICS Nº 26, DE 05 DE DEZEMBRO DE 2023.  
Aprova o Protocolo de Uso do Distrator Osteogênico Mandibular (DOM) para o Tratamento de Deformidades Crânio e BucoMaxilo-Faciais Congênitas ou Adquiridas.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o implante e uso do distrator osteogênico mandibular para o tratamento de deformidades crânio e buco-maxilo-faciais congênitas e adquridas no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos de uso de tecnologias em saúde são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 592/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 597 – Março de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo de Uso – Distrator osteogênico mandibular para o tratamento de deformidades crânio e buco-maxilo-faciais congênitas e adquridas.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito do implante e uso do distrator osteogênico mandibular para o tratamento de deformidades crânio e buco-maxilo-faciais congênitas e adquridas, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao implante e uso do distrator osteogênico mandibular.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **PROTOCOLO DE USO** -->
DISTRATOR OSTEOGÊNICO MANDIBULAR (DOM) PARA O TRATAMENTO DE DEFORMIDADES CRÂNIO E BUCO-MAXILO-FACIAIS CONGÊNITAS OU ADQUIRIDAS

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **1. INTRODUÇÃO** -->
As anomalias congênitas ou de desenvolvimento dos ossos do crânio e da face constituem um grupo de diversas anomalias congênitas e afetam significativa parcela da população<sup>1</sup> . A patogênese destas condições é desafiadora, pois parece decorrer de interações entre diferentes genes e fatores ambientais<sup>1,2</sup> . A manifestação clínica mais comum e desencadeadora da sequência de eventos é a micrognatia. Essa anomalia importante do tamanho da mandíbula caracteriza diversas situações clínicas nas quais esses ossos são pouco desenvolvidos (hipoplásicos) ou menores do que o padrão de normalidade<sup>2,3</sup> .  
Estas anomalias constituem as causas mais comuns de má oclusão esquelética no adulto, com uma prevalência de 1 para cada 1.500 nascidos vivos<sup>4</sup> e podem ocorrer de forma esporádica ou como parte de mais de 400 síndromes. Algumas das apresentações mais comuns envolvem também retroposicionamento da língua (glossoptose) e disfunção respiratória, traduzida pela alta prevalência de síndrome de apneia obstrutiva do sono (SAOS)<sup>2,5</sup> . Os indivíduos com micrognatia podem ainda apresentar fissura palatina e comprometimento alimentar. Alterações dento-esqueletais e prejuízos estéticos, além dos funcionais, são frequentemente observados ao longo do crescimento<sup>6</sup> . Estas alterações podem impactar negativamente as relações sociais dos indivíduos acometidos<sup>1</sup> .  
Diferentes condições clínicas, na sua maioria sindrômicas, cursam com deformidades craniofaciais as quais os métodos convencionais de tratamento não são capazes de corrigir funcional e esteticamente. Desse modo, são necessárias abordagens cirúrgicas para a correção das grandes hipoplasias dos segmentos faciais, especialmente as hipoplasias mandibulares e as hipoplasias do terço médio da face<sup>7</sup> .  
Diversas condições clínicas são caracterizadas pela presença de mandíbula hipoplásica ou micrognatia, sendo a mais comum a sequência de Pierre Robin (SPR), que pode ser isolada ou sindrômica. A microssomia craniofacial (MC) e a síndrome de Treacher Collins (STC) são as síndromes craniofaciais que mais frequentemente cursam com SPR<sup>1,2,5</sup> . Quanto maior o comprometimento do tamanho da mandíbula, maior a chance do comprometimento funcional, especialmente respiratório e alimentar. Em casos de obstrução respiratória, o tratamento deve priorizar a manutenção da permeabilidade das vias aéreas. Com a abordagem adequada das alterações respiratórias, frequentemente há melhora das dificuldades alimentares, visto que estas condições são associadas<sup>8</sup> .  
Embora algumas crianças com micrognatia sejam assintomáticas ou possam ser tratadas apenas com medidas conservadoras, grande parte dos pacientes tem significativo comprometimento respiratório e da deglutição, necessitando de intervenção cirúrgica. A terapia conservadora pode incluir desde a colocação do neonato na posição prona (atentar para o risco de morte por sufocamento) até o uso de cânulas nasofaríngeas e de CPAP (pressão positiva contínua em vias aéreas – do inglês, _continuous positive airway pressure_ )<sup>9</sup> .  
No entanto, a obstrução das vias aéreas superiores grave com falha com o tratamento conservador demanda atenção médica urgente. Nesses casos, abordagens cirúrgicas constituem opções terapêuticas viáveis. Entre as modalidades de cirurgia comumente realizadas estão a traqueostomia, embora seu emprego seja limitado<sup>10,11</sup> ; a glossopexia (ou adesão língua-lábio), em que a língua é fixada ou aderida ao lábio inferior e na mandíbula<sup>12</sup> ; e a distração osteogênica mandibular (DOM), que consiste em um método alternativo às formas tradicionais de manejo da via aérea desses pacientes, podendo, em grande parte das vezes, substituir a indicação de traqueostomia. O alongamento gradual mandibular promove a anteriorização da base da língua, permitindo assim a permeabilidade da via aérea superior<sup>13–17</sup> .  
Alterações do crescimento e desenvolvimento mandibular ocorrem na SPR isolada, sindrômica e na anquilose temporomandibular. Essas alterações podem acometer a mandíbula uni ou bilateralmente. O acometimento de outras estruturas  
anatômicas, tais como a maxila, o zigoma, os músculos da mastigação e os tecidos moles adjacentes, torna ainda mais desafiador o tratamento desses pacientes<sup>5,18,19</sup> .  
Este Protocolo tem como objetivo apresentar as diretrizes de uso do distrator osteogênico mandibular (DOM) para o tratamento de pacientes com anomalias congênitas ou de desenvolvimento dos ossos do crânio e da face e a normatização do seu uso na SAOS. A metodologia de busca e avaliação das evidências está detalhada no **Apêndice 3** .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E  PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
Serão contemplados neste Protocolo de Uso pacientes cursando com sequência de Pierre-Robin (SPR) ou com síndrome de apneia obstrutiva do sono (SAOS) de grau moderado a grave em decorrência das alterações e com necessidade de avanço, classificados de acordo com os seguintes códigos:  
- Q87.0 - Síndromes com malformações congênitas afetando predominantemente o aspecto da face;  
- Q75.4 - Disostose mandíbulo-facial;  
- Q67.4 - Outras deformidades congênitas do crânio, da face e da mandíbula;  
- K07.0 - Anomalias importantes (major) do tamanho da mandíbula;  
- K076 - Transtornos da articulação temporomandibular;

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **3.1.1. Sequência de Pierre-Robin (SPR)** -->
A sequência de Pierre Robin (SPR) consiste em uma anomalia craniofacial congênita caracterizada pela tríade de micrognatia, glossoptose e obstrução respiratória associada à fissura palatina e à disfunção alimentar em parte dos casos<sup>20</sup> . A SPR apresenta-se como uma condição isolada ou associada a uma grande variedade de síndromes. Contudo, a micrognatia é o achado clínico comum em todos os casos<sup>5</sup> . Sua prevalência varia entre 1:2.000 a 1:30.000. Essa ampla variabilidade deve-se a estudos feitos em diferentes populações<sup>21</sup> .  
A micrognatia pode ser considerada o evento embriológico inicial e consiste no principal achado clínico observado nesses pacientes. A hipoplasia mandibular leva ao retroposicionamento da língua (glossoptose) e consequente obstrução das vias aéreas superiores devido ao colapso da língua junto à parede posterior da faringe. A língua retroposicionada impede na maioria dos casos o fechamento das lâminas palatinas na linha média durante o período de formação embriológica do palato. Dessa forma, em 60% a 90% dos pacientes com SPR, observa-se a fissura palatina restrita ao palato mole em formato de “U”, constituindose em mais um achado clínico frequente nesses indivíduos<sup>5</sup> . A glossoptose é a causa da obstrução respiratória na imensa maioria dos casos e usualmente é avaliada por meio da endoscopia das vias aéreas superiores, na qual é possível analisar a posição da língua na cavidade oral e na orofaringe, bem como identificar outros níveis de obstrução que não a base da língua<sup>22,23</sup> .  
Devido ao fato de as crianças com SPR apresentarem problemas alimentares e respiratórios de gravidade variável, com ampla taxa de mortalidade, a qual, na literatura, varia de 2,5% a 30%<sup>8,24</sup> , é que se preconiza o início do tratamento imediatamente após o nascimento. A obstrução respiratória presente nesses pacientes pode ser traduzida pela alta prevalência de síndrome da apneia obstrutiva do sono (SAOS). Cerca de 85% desses pacientes, com idade inferior a um ano, apresentam SAOS, crises recorrentes de hipóxia e consequentes possíveis danos cerebrais<sup>25</sup> . As dificuldades alimentares são geralmente consequentes à dificuldade respiratória. Refluxo gastroesofágico está presente em grande parte dos casos. Dessa forma, o alívio da obstrução respiratória pode levar à rápida melhora das condições nutricionais, do crescimento e do desenvolvimento<sup>26</sup> .  
A síndrome de Treacher Collins (STC), ou disostose mandibulofacial, consiste em uma anomalia craniofacial congênita e pode ser considerada uma condição clínica associada à SPR<sup>27,28</sup> . Entre os achados clínicos mais característicos da síndrome  
estão a hipoplasia dos ossos zigomáticos, da maxila e da mandíbula. A hipoplasia mandibular ou a completa dismorfologia do ramo mandibular e a articulação temporomandibular observadas na grande maioria dos casos cursam com grave comprometimento respiratório e alimentar<sup>29</sup> . A oclusão dentária, avaliada pelo sistema de classificação de Angle (Quadro 1 e Figura 1), usualmente é do tipo classe II de Angle, com mordida aberta anterior e grande rotação do plano oclusal no sentido horário<sup>28,30</sup> . Cerca de 66% dos pacientes com STC requerem alguma intervenção nas vias aéreas devido ao comprometimento do espaço aéreo posterior, compatível com o observado na SPR<sup>31</sup> . Desta forma, a manutenção de uma via aérea adequada é prioridade nas crianças recém-nascidas com STC. Disfagia e dificuldade no ganho de peso são muitas vezes sintomas primários do comprometimento respiratório<sup>8</sup> .  
**Quadro 1 –** Sistema de classificação de maloclusão de Angle.  
|**Classificação**|**Características**|
|---|---|
|Classe I|Há relação anteroposterior normal entre mandíbula e maxila em que a cúspide<br>mesiovestibular do primeiro molar superior permanente oclui no sulco vestibular do<br>primeiro molar inferior permanente.|
||Refere-se à relação “distal” da mandíbula em relação à maxila. Nesta classe, a cúspide<br>mesiovestibular do primeiro molar superior permanente oclui anteriormente ao sulco<br>vestibular do primeiro molar inferior permanente.|
|Classe II (distoclusão)|Divisão 1ª: Há função muscular anormal e os incisivos superiores estão projetados<br>vestibularmente, sendo comum haver sobremordida e_overjet_acentuados.<br>Divisão 2ª: A função muscular está preservada. Os incisivos centrais superiores encontram-<br>se verticalizados ou lingualizados e os incisivos laterais vestibularizados. Nesta divisão é<br>comum haver sobremordida bastante acentuada.|
|Classe III (mesioclusão)|Refere-se à relação “mesial” da mandíbula em relação à maxila. A cúspide mesiovestibular<br>do primeiro molar superior permanente oclui posteriormente o sulco vestibular do primeiro<br>molar inferior permanente. Frequentemente há compensação dentária com incisivos<br>superiores vestibularizados e os inferiores retroinclinados na tentativa de reestabelecer<br>contato.|  
Fonte: Adaptado<sup>32</sup> .  
**Figura 1 –** Ilustração das classes de maloclusão segundo o sistema de classificação de Angle: I – normal; II – retrognatia; e III - prognatia.  
Fonte: Relatório de Recomendação n<sup>o</sup> 430 – Distrator osteogênico mandibular<sup>33</sup> .  
A microssomia craniofacial, por sua vez, consiste em uma condição congênita que envolve, predominantemente, estruturas derivadas do primeiro e segundo arcos faríngeos, tais como as orelhas, a mandíbula e partes moles da face<sup>34</sup> . Tais  
estruturas estão afetadas uni ou bilateralmente, embora em graus distintos, o que determina a aparência assimétrica da face<sup>35</sup> . No entanto, a hipoplasia mandibular, nos casos mais graves, pode resultar em obstrução das vias aéreas superiores à semelhança da STC e caracterizar um quadro de SPR<sup>36</sup> . Com uma ocorrência estimada de 1 caso em 4.000 a 5.600 nascidos vivos<sup>37</sup> , é também denominada como espectro oculoauriculovertebral, síndrome de Goldenhar, microssomia hemifacial ou síndrome de 1º e 2º arcos faríngeos<sup>28</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **3.1.2. Complicação associada às alterações crânio-buco-maxilo-faciais: síndrome da apneia obstrutiva do sono** -->
A síndrome da apneia obstrutiva do sono (SAOS) é altamente prevalente em pacientes com alterações do tamanho da mandíbula, sendo decorrente da glossoptose<sup>2,5,25</sup> . A SAOS consiste em despertares repetitivos e/ou dessaturaçōes secundárias à obstrução parcial ou completa das vias aéreas. Tem sequelas neurocognitivas, comportamentais, cardiovasculares e inflamatórias bem descritas. A obstrução das vias aéreas induzida pelo sono é multifatorial e envolve causas anatômicas e funcionais<sup>38</sup> Segundo dados de um estudo com mais de mil participantes na cidade de São Paulo, a prevalência de SAOS é de aproximadamente 30%<sup>39</sup> .  
As queixas mais frequentes dos pacientes adultos com SAOS são: presença de ronco, sufocamento noturno, sonolência excessiva diurna (SED), comprometimento da qualidade de vida e relato de apneias noturnas pelos companheiros<sup>40</sup> . Outros sintomas comuns incluem cefaleia matinal, sono não-reparador, fadiga e alterações cognitivas. Outros parâmetros clínicos como IMC (índice de massa corporal), idade e gênero devem ser considerados. A polissoonografia (PSG) consiste no exame padrãoouro para o diagnóstico da SAOS. A associação de história clínica sugestiva associada ao exame físico e o resultado polissonográfico permitem uma melhor acurácia diagnóstica. Métodos de rastreamento para detecção de pacientes com alto risco de SAOS, como o questionário de Berlim – QB ( **Apêndice 1** ) e a escala de sonolência de Epworth – ESSE ( **Apêndice 2** ), além de avaliar o comprometimento das atividades diárias, também auxiliam no diagnóstico<sup>40,41</sup> . A polissonografia fornece resultados da relação entre apneia e hipopneia, por meio do índice de apneia e hipopneia (IAH), que se refere ao número total de apneias e hipopneias durante o sono dividido pelo tempo total de sono<sup>41</sup> . O IAH permite classificar a SAOS nos graus leve, moderado e grave<sup>42</sup> :  
- Grau I ou leve (5 ≤ IAH ≤ 15): Caracterizada por sonolência diurna ou episódios de sono involuntários durante atividades que requerem pouca atenção, podendo resultar em alterações leves em atividades sociais ou ocupacionais<sup>42</sup> ;  
- Grau II ou moderado (15 < IAH ≤ 30): Caracterizada por sonolência diurna ou episódios de sono involuntários durante atividades que requerem atenção, com prejuízo das atividades sociais e ocupacionais<sup>42</sup> ; e  
- Grau III ou grave (IAH > 30): Caracterizada por sonolência diurna ou episódios de sono involuntários durante atividades que requerem maior atenção, com prejuízo acentuado das atividades sociais e ocupacionais<sup>42</sup> .  
Os outros parâmetros mensurados na PSG devem ser considerados na determinação da gravidade do quadro apresentado pelo paciente, como por exemplo: saturação média e mínima de O2; porcentagem do tempo de sono em apnéia; nível de CO2<sup>42</sup> .  
Diferentes alterações anatômicas devem ser consideradas em indivíduos com SAOS, sendo os achados mais frequentes: alterações nasais, hipertrofia de tonsilas palatinas, inadequada relação entre a base da língua e a orofaringe e comprometimento de partes moles como palato mole e úvula<sup>40,43,44</sup> . Na população brasileira, algum grau de hipoplasia mandibular e consequente oclusão dentária do tipo II pode ser observada em aproximadamente 20% da população<sup>45</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **3.2. Exames complementares** -->
Em todas as condições clínicas, a avaliação das vias aéreas superiores é mandatória, pois permite a quantificação da obstrução respiratória, principalmente em função da glossoptose, além de possibilitar a avaliação de outros sítios obstrutivos concomitantes. O exame de videonasolaringoscopia deve idealmente ser realizado com sono induzido<sup>46</sup> .  
A avaliação da morfologia e da magnitude da hipoplasia mandibular por meio de tomografia computadorizada (TC) de face faz-se necessária e a sua realização é mandatória quando da indicação da DOM. A TC permite adequada programação  
cirúrgica ao considerar o local da osteotomia e da colocação dos pinos em função da anatomia mandibular, da presença de germes dentários e da localização do nervo alveolar inferior. A polissonografia (PSG) é considerada o padrão-ouro para o diagnóstico de SAOS e é altamente recomendável nesses casos. No entanto, diferentes motivos podem restringir a sua realização, como a limitação no número de centros capacitados para efetuar o exame em neonatos e criança, ou torná-la desnecessária, como nos casos clinicamente muito graves e/ou com intubação orotraqueal<sup>46</sup> . Oximetria contínua e análise gasométrica são recomendadas durante o manejo clínico desses pacientes<sup>47</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que preencherem os seguintes critérios:  
- Diagnóstico de sequência de Pierre-Robin; ou  
- Diagnóstico de síndrome da apneia obstrutiva do sono de grau moderado a grave associada a hipoplasias mandibulares  
ou outras alterações de ossos da face com necessidade de avanço mandibular ≥10 mm.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que preencherem o critério a seguir:  
- Pessoas que apresentem síndrome de apneia obstrutiva do sono decorrente de outras condições que não alterações crâniobuco-maxilo-faciais.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **6. CASOS ESPECIAIS** -->
São considerados casos especiais os pacientes com anquilose temporomandibular. A anquilose da articulação temporomandibular (ATM) consiste na fusão das superfícies articulares por tecido ósseo ou fibroso. É uma condição que pode causar grave comprometimento da mastigação, da respiração, da fala, da higiene oral e da assimetria facial, além do impacto psicológico. O comprometimento da ATM varia desde adesões fibrosas até condições que envolvem a fusão do ramo mandibular com o arco zigomático e a presença de verdadeiro bloco anquilótico com a fusão do ramo mandibular à base do crânio. Pode ser causada por vários fatores, incluindo trauma, condições inflamatórias sistêmicas e locais, neoplasias e infecções na região da ATM. O fator etiológico mais comum está associado a trauma ou infecção<sup>48,49</sup> .  
O diagnóstico clínico dá-se pela observação de limitação da abertura bucal além de prejuízo do crescimento mandibular quando presente no esqueleto ainda em desenvolvimento. Micrognatia grave, assimetria mandibular, comprometimento respiratório e alimentar são frequentemente observados. A tomografia computadorizada (TC) de face é imprescindível para a confirmação diagnóstica e planejamento cirúrgico. Naquelas situações de comprometimento respiratório e SAOS, a PSG é recomendada<sup>50,51</sup> .  
Uma variedade de técnicas têm sido citadas na literatura para o tratamento desta condição, incluindo a DOM. Uma vez que o tamanho e a forma da mandíbula estão frequentemente comprometidos na anquilose de ATM, esse procedimento está indicado para aqueles indivíduos que ainda não atingiram a maturação esquelética e apresentam desconforto respiratório e SAOS<sup>52</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **7.1. Sequência de Pierre-Robin** -->
A decisão de quando tratar a obstrução das vias aéreas da sequência de Pierre-Robin pela via cirúrgica versus não cirurgicamente é mal definida, com literatura quantitativa esparsa devido à ampla gama de gravidade na apresentação da anomalia e ao alto número de variáveis clínicas a considerar<sup>11</sup> . No tratamento não cirúrgico, em casos leves, o posicionamento prono pode ser utilizado; já para o uso de oxigênio suplementar ou obturador palatino não há comprovação de sua eficácia<sup>53,54,55</sup> .  
Existem evidências controversas de modalidades, tais como o tubo nasofaríngeo (TNF) ou a terapia por máscara com pressão positiva contínua nas vias aéreas (CPAP), para contornar a obstrução das vias aéreas causada pela base da língua<sup>9,56</sup> , não podendo ser recomendados como tratamento definitivo. Entre 20% a 50% dos neonatos com SPR podem ser tratados não cirurgicamente com sucesso<sup>57,58,59,60,61,62</sup> . Alguns neonatos são incapazes de tolerar os _stents_ naso ou orofaríngeos, e, portanto, esses dispositivos acabam se tornando cada vez mais problemáticos para pais e provedores<sup>57</sup> , de modo que seu uso não é recomendado como tratamento definitivo.  
Além disso, essas medidas não cirúrgicas são eficazes apenas se houver crescimento mandibular suficiente no primeiro ano de vida para resolver a glossoptose. Esse crescimento crítico nem sempre é previsível em todos os pacientes. Não há crescimento real que alcance o tamanho normal da mandíbula na grande maioria dos casos. Os neonatos que não são bons candidatos em potencial para o tratamento conservador ou nos quais este fracassa são considerados elegíveis para tratamentos cirúrgicos mais invasivos<sup>63</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **7.2. Tratamento cirúrgico** -->
As opções de tratamento cirúrgico incluem traqueostomia, adesão língua-lábio (ALL), também conhecida como glossopexia, e a DOM<sup>64</sup> . Embora os casos graves de obstrução das vias aéreas relacionadas à SPR sejam comumente tratados cirurgicamente, grande parte das orientações sobre as indicações cirúrgicas é oriunda de recomendações de evidências de baixo nível, amplamente baseadas na opinião de especialistas<sup>63,65</sup> . Em revisão sobre o manejo não cirúrgico e cirúrgico da SPR em centro de referência terciário durante um período de 20 anos observou-se que o fator de risco objetivo mais significativo entre os que foram submetidos à cirurgia foi a avaliação de sono pré-intervenção insuficiente<sup>11</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **7.2.1. Traqueostomia** -->
A traqueostomia é um método simples e eficaz para estabelecer a permeabilidade da via aérea, que depende do crescimento mandibular subsequente para permitir a decanulação<sup>11</sup> . Como a traqueostomia está associada a múltiplas morbidades, incluindo estenose laríngea, traqueomalácia e pneumonia crônica, a cuidados extensivos de enfermagem e a custos elevados, ela geralmente é reservada para pacientes para os quais nenhuma outra intervenção é considerada uma opção viável<sup>63,66.67.68. 69. 70. 71.</sup> .  
Apesar dessas limitações, a traqueostomia ainda é uma intervenção que salva vidas, principalmente em pacientes com obstrução das vias aéreas em múltiplos níveis<sup>65,72,73</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **7.2.2. Adesão língua-lábio (glossopexia)** -->
A adesão língua-lábio (ALL) é uma técnica cirúrgica em estágios que traciona a base da língua anteriormente até que a obstrução das vias aéreas possa ser definitivamente resolvida. O sucesso da ALL se baseia no crescimento compensatório da recuperação da mandíbula para aliviar a obstrução das vias aéreas, que permanece um conceito debatido<sup>61,63,74,75,76,77</sup> . Presença de refluxo gastroesofágico (RGE), baixo peso ao nascer, diagnóstico sindrômico, intubação pré-operatória e operação tardia parecem ser preditores de falha da ALL<sup>78</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **7.2.3. Distração osteogênica mandibular** -->
A DOM é uma intervenção utilizada para aliviar a obstrução das vias aéreas em lactentes com SPR moderada e grave<sup>16,63,65,72,75,79,80,81,82,83,84,85</sup> e pode ser utilizada em neonatos com peso inferior a 3kg e com obstrução grave das vias aéreas<sup>86,87,88</sup> . O benefício da distração reside na tração anterior direta que o alongamento da mandíbula produz na base da língua, aumentando a perviedade das vias aéreas com a diminuição da glossoptose<sup>23</sup> .  
As indicações atuais para DOM incluem polissonografia que demonstre apneia do sono central inexistente ou limitada e IAH> 20 (NYU) /> 6 (HCPA) ou saturação de oxigênio (SaO2) abaixo de 90% a mais de 1% do tempo de sono (HCPA)<sup>16,89</sup> ou  
retenção significativa de dióxido de carbono<sup>90</sup> ou patologia secundária das vias aéreas inferiores, o que poderia impedir a restauração bem-sucedida das vias aéreas<sup>91</sup> . A presença de patologia neurológica ou cardíaca grave é contra-indicação relativa<sup>92</sup> .  
Em casos mais graves de hipoplasia mandibular a DOM pode ser necessária em um estágio mais precoce para alívio do desconforto respiratório. Outras vezes, a DOM aplicada unilateralmente na mandíbula permite a correção da assimetria em um esqueleto ósseo ainda em crescimento<sup>36</sup> .  
Nos casos em que há algum grau de hipoplasia mandibular e consequente deformidade esquelética do tipo II, o tratamento ortodôntico isolado é geralmente ineficaz. Quando essa condição está associada ao comprometimento respiratório, o avanço mandibular, seja ele por meio de cirurgia ortognática ou DOM, é um dos tratamentos elegíveis<sup>45</sup> .  
As osteotomias mandibulares são consideradas o padrão-ouro para o avanço mandibular em indivíduos adultos. Nessa modalidade, as recidivas pós-cirúrgicas têm sido associadas a uma série de fatores relacionados ao paciente, movimentos esqueléticos maiores que 10 mm de avanço e reabsorção condilar. A DOM, por sua vez, tem sido utilizada em casos nos quais há necessidade de avanço superior a 10 mm e em indivíduos com síndromes que comprometem significativamente o tamanho da mandíbula e apresentam SAOS<sup>93</sup> . Uma menor taxa de lesão nervosa, recidivas e necessidade de reintervenção é observada nessa modalidade quando comparada ao avanço mandibular convencional nessas situações mais extremas<sup>52,94</sup> .  
Os distratores osteogênicos estão atualmente disponíveis em diferentes apresentações, tamanhos e materiais. Eles podem ser internos, justapostos aos ossos ou externos; feitos de titânio e outros materiais; e possuem tamanhos variados, para uso em pacientes pediátricos e adultos. Ademais, estes equipamentos têm diferentes capacidades de extensão e podem ser unidirecionais ou multidirecionais<sup>7</sup> .  
Para estimular a osteogênese e o consequente aumento mandibular, são feitos cortes na mandíbula, seguido de um distanciamento dos segmentos. Os cortes ósseos são realizados com broca ou serra. Quando o distrator é colocado internamente as partes móveis do distrator osteogênico são fixadas em posição sagital por meio de placas de ancoragem e parafusos. Quando o distrator é externo, os pinos de Schantz são colocados transfixando o osso, de cada lado da osteotomia, e, na sequência, as partes móveis são acopladas aos pinos. As partes móveis são separadas de forma controlada para induzir, sob tensão, a formação de tecido ósseo novo entre as extremidades do corte. Depois de um período o distrator é retirado por meio de uma nova cirurgia. O procedimento de distração osteogênica ocorre em cinco etapas: corticotomia (ou osteotomia), instalação do distrator, latência (período entre instalação do distrator e início da expansão), ativação (aplicação das forças de distração) e consolidação<sup>7</sup> .  
Antibioticoterapia profilática é usada no período peri-operatório. A prescrição da analgesia pós-operatória fica a critério do pediatra.  
Independentemente da indicação e da etapa da DOM, os procedimentos devem ser realizados por cirurgião com habilitação em medicina, nas especialidades cirurgia de cabeça e pescoço, cirurgia plástica, otorrinolaringologia ou na área de atuação de cirurgia cranio-buco-maxilo-facial. O profissional pode também ser habilitado em odontologia, na especialidade de cirurgia e traumatologia buco-maxilo-facial.  
O procedimento é realizado sob anestesia geral e, pelo envolvimento de via aérea difícil, há necessidade de que o pósoperatório seja feito em UTI pediátrica, na grande maioria dos casos. Minimamente, deve existir leito de UTI na instituição onde a cirurgia é realizada, caso ocorra algum agravo inesperado decorrente do procedimento em casos menos graves.  
Com relação aos materiais necessários para a realização apropriada do procedimento, deverão ser utilizadas serras compatíveis com cirurgia mandibular. Em neonatos, as peças de mão necessitam ser pequenas e as lâminas com espessura máxima de 0,35 mm. Serras reciprocantes são aconselháveis, embora o procedimento possa ser realizado com serras sagitais ou oscilantes. As serras piezoelétricas são recomendadas por diminuir o risco de dano aos germes dentários e ao nervo alveolar inferior, além de reduzir a perda sanguínea<sup>95,96</sup> . Passador de fio de Kirschner ou motor com baixa rotação devem ser usados para colocação dos pinos nos distratores externos.  
Os distratores poderão ser semi-internos ou externos e deverão ser acompanhados pelas respectivas chaves de fixação e  
ativação. Distratores semi-internos de titânio devem ter o corpo fixado ao osso por meio de parafusos (no mínimo quatro e no máximo oito) e hastes de ativação transcutânea. Já o distrator externo é composto por conjunto de corpo e haste de ativação, pinos de Schantz (dois a quatro pinos) transcutâneos.  
Como na maioria dos casos da SPR há hipoplasia isolada do corpo mandibular, o vetor horizontal é frequentemente usado. Já em casos de deformidade no ramo ou mista, o vetor vertical é frequentemente escolhido para a distração mandibular<sup>72,75</sup> . No entanto, deve-se considerar o risco de dano na articulação temporomandibular quando utilizado o vetor vertical<sup>97</sup> . As osteotomias podem ser oblíquas no ângulo da mandíbula, horizontais no ramo ou em “L” invertido no ramo/corpo. Um aumento substancial das vias aéreas ocorre após a distração mandibular, embora nenhuma diferença no volume final das vias aéreas tenha sido demonstrada entre o uso de vetores horizontais ou oblíquos<sup>98</sup> . A escolha dos materiais é feita de acordo com a idade do paciente, o tipo de alteração apresentada e o grau de acometimento, segundo o que se segue:  
Neonatos (até 30 dias) e lactantes (até dois anos): Em neonatos e na primeira infância o distrator unidirecional é o padrão. As mandíbulas nos primeiros meses de vida são maleáveis e têm alta plasticidade e embora os vetores unidirecionais possam inicialmente levar a discrepâncias maxilo-mandibulares, a médio e longo prazo, alcança-se uma boa relação maxilomandibular<sup>99</sup> . Embora a micrognatia seja principalmente uma consequência de um corpo diminuído, todos os componentes locais são morfologicamente alterados<sup>100,101</sup> . Esses achados incluem um ângulo gonial mais obtuso, especialmente nos pacientes sindrômicos<sup>101,102,103</sup> . Portanto, em pacientes sindrômicos, os distratores multidirecionais podem ser utilizados, mesmo nessa faixa etária. Os distratores externos são preferíveis pela praticidade de implantação e retirada, além de acarretar custos menores<sup>104</sup> .  
Pessoas acimas de dois anos: A partir dessa idade, a decisão passa a estar diretamente relacionada à deformidade diagnosticada. Distratores unidirecionais devem ser usados quando a alteração for majoritariamente em um dos componentes anatômicos mandibulares. Distratores multidirecionais devem ser utilizados quando a deformidade for uniformemente distribuída entre corpo e ramo ou quando o ângulo gonial estiver muito alterado<sup>105</sup> . Quanto à decisão entre distratores internos ou externos, a partir dessa faixa etária o distrator interno passa a ter maior relevância por questões sociais e risco de trauma<sup>106</sup> .  
Quando há SAOS associada, na maioria dos casos observa-se hipoplasia isolada do corpomandibular, sendo o vetor horizontal frequentemente usado. Um aumento substancial dasvias aéreas ocorre após a distração mandibular<sup>98</sup> . Pode-se realizar osteotomia do ramo em L-invertido, do ângulo mandibular ou osteotomia mandibular do corpo<sup>107</sup> . Embora a osteotomia em L- invertido exija mais dissecções e as outras osteotomias sejam mais simples de executar, a osteotomia em L-invertido oferece menor risco para os germes dentários e para a sensibilidade labial<sup>108</sup> .  
A decisão pelo tipo de material a ser utilizado depende da idade do paciente, do tipo e da gravidade da alteração. Para pacientes com idade a partir de 10 anos, a decisão passa a estar diretamente relacionada à deformidade diagnosticada. O tipo de material a ser utilizado segue a mesma definição utilizada para pessoas acima de dois anos cursando com SPR.  
O período de latência, o ritmo e a extensão da ativação deverão ser avaliados caso a caso e feitos conforme critério do médico ou dentista. De modo geral, após a cirurgia segue um período de latência de 0 a 7 dias, seguida de um período de ativação a uma taxa de 1 a 2 mm/ dia, até que classe III oclusal (crista alveolar mandibular 2 a 3 mm à frente da maxilar) seja obtida em pacientes com SPR, até que haja a melhora dos sintomas ou até a extensão máxima do pino do distrator. Após esta fase, seguese um período de consolidação óssea de 4 a 10 semanas<sup>72</sup> . O dispositivo deve ser mantido no local, atuando como um fixador externo por no mínimo quatro semanas até que haja evidência radiográfica de mineralização óssea<sup>7</sup> . Nos casos de adultos com SAOS pode ser necessária osteotomia maxilar para o ajuste oclusal final<sup>52</sup> .  
Para a retirada dos distratores externos, a anestesia pode ser uma sedação ou anestesia local, enquanto a retirada dos internos exige anestesia geral. Neste procedimento, em caso de distratores internos, poderão ser necessárias brocas de desgaste. As respectivas chaves de fixação e ativação deverão estar disponíveis para uso.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **8. MONITORAMENTO** -->
O indivíduo deverá ser avaliado regularmente no pós-operatório para revisão do equipamento e definição dos ajustes. Após orientação e supervisão da equipe cirúrgica, a ativação do distrator é feita diariamente por um familiar ou cuidador do paciente. Depois da alta hospitalar, a avaliação da ativação do distrator e da evolução na fase de consolidação deverá ser realizada semanalmente pelo cirurgião responsável. Durante este período, sinais de infecção, mobilidade dos pinos, retrocesso no pino de ativação, alterações de oclusão e no padrão de mordedura devem ser avaliados cuidadosamente para ajustes no plano de tratamento<sup>7</sup> .  
Enquanto o distrator estiver fixado, pacientes, pais ou cuidadores deverão ser orientados quanto aos cuidados relativos à alimentação adequada, higienização oral, sucção e demais funções. A dieta deve ser líquida e/ou cremosa, sem carga; a limpeza dos pinos exteriorizados deve ser realizada com soro fisiológico ou antissépticos à critério do médico assistente; curativos externos com gazes não são recomendados. Crianças não devem sugar (bicos, chupetas, mamadeiras); o uso de talas nos braços, removíveis para fisioterapia diária, para evitar levar a mão à boca ou ao aparelho é imprescindível. Depois de 48-72 horas de pós-operatório o uso de analgésicos deve ser “se necessário”. A ação de girar o mecanismo de ativação, isto é, “fazer a distração”, não provoca dor. Sugere-se que a ativação seja feita com a criança dormindo para diminuir o risco de trauma por movimento brusco do paciente.  
Uma nasolaringoscopia deverá ser realizada antes da retirada do distrator, idealmente no momento da parada da ativação do aparelho. O acompanhamento a longo prazo deverá ser realizado durante todo o período de crescimento facial (aproximadamente 18 anos de idade). As revisões clínicas devem ser feitas em 1, 3, 6 e 12 meses após a retirada do distrator e anualmente depois do segundo ano de vida. Idealmente, o paciente deverá ser monitorado pelo serviço que realizou a sua cirurgia, de forma a possibilitar o constante seguimento da evolução clínica.  
Na primeira semana após a instalação e após a retirada do distrator, sugere-se avaliação da equipe de enfermagem para orientações sobre cuidados gerais. O paciente deve ser avaliado por fonoaudiólogo e fisioterapeuta previamente ao procedimento para avaliação das funções deglutitória e respiratória, respectivamente. Na primeira semana após o procedimento de inserção, sugere-se avaliação diária destas equipes para restabelecimento das funções de fala, mastigação, deglutição, fala e respiração. Posteriormente à retirada, o acompanhamento podeser feito em 1, 3, 6 e 12 meses.  
Polissonografia de controle deve ser realizada ao redor de seis meses após a retirada dos distratores, e/ou logo antes de realizar a palatoplastia nos pacientes com fissura palatina associada.  
Exames complementares de imagem, como tomografias e radiografias de face, não são realizados rotineiramente, a não ser que seja identificada a necessidade, devido à evolução do quadro clínico.  
No Quadro 4 constam as frequências de avaliações e exames sugeridos no pós-operatório da cirurgia de distração osteogênica mandibular. Estes intervalos podem ser modificados de acordo com a avaliação clínica. Outras categorias profissionais poderão ser acionadas de acordo com a necessidade do paciente.  
**Quadro 4 –** Frequência sugerida de avaliações no pós-cirúrgico da distração osteogênica mandibular.  
|**Especialista**|**Frequência de consulta**|
|---|---|
|Cirurgiāo responsável pelo procedimento<br> <br>|Durante fase de ativação do distrator e fase de consolidação: semanal.<br>Após retirada do distrator: em 1, 3, 6 e 12 meses.<br>A partir do segundo ano: anualmente até o final do período de crescimento facial.|
|Enfermagem<br>|Durante fase de ativação do distrator e fase de consolidação: semanal.|
||Após uma semana da retirada do distrator.|  
|Fonoaudiologia|Primeira semana após a inserção do distrator: diária.|
|---|---|
||Após retirada do distrator: em 1, 3, 6 e 12 meses.|
|Fisioterapia|Primeira semana após a inserção do distrator: diária.|
||Após retirada do distrator: em 1, 3, 6 e 12 meses.|

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **9. REGULAÇÃO E CONTROLE** -->
O acesso dos usuários aos serviços voltados à saúde bucal foi ampliado em 2004, com o lançamento da Política Nacional de Saúde Bucal (PNSB), também conhecido como Programa Brasil Sorridente. Trata-se de um programa cujo objetivo é garantir ações de promoção, proteção, prevenção, tratamento, cura e reabilitação da saúde bucal de usuários do SUS, independentemente da idade, por meio de ações intersetoriais. As principais ações desta política consistem na introdução de equipes de saúde bucal (eSB) na Estratégia Saúde da Família (ESF), na ampliação e qualificação da atenção especializada, na viabilização da adição de flúor nas estações de tratamento de água de abastecimento público em estratégias de educação em saúde<sup>32,109.110</sup> .  
Atualmente, o acesso a serviços de atenção à saúde bucal é operacionalizado por meio da Rede de Atenção à Saúde Bucal, tendo a Atenção Primária à Saúde (APS) como ponto focal, porém com interface com serviços de atendimento especializado por meio de sistemas de referência e contra referência. Na APS, houve implantação de equipes de Saúde Bucal (eSB) como parte da equipe da Estratégia Saúde da família (ESF) e aumento da complexidade dos procedimentos que podem ser realizados neste nível de atenção. A atenção especializada é concretizada nos Centros de Especialidades Odontológicas (CEO), com apoio dos Laboratórios Regionais de Prótese Dentária em âmbito ambulatorial<sup>42,110</sup> .  
Algumas condições citadas neste Protocolo (sequência de Pierre-Robin, síndrome de Treacher-Collins e microssomia craniofacial) constituem doenças raras, de modo que estes pacientes também são amparados pela Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>111</sup> . Esta Política tem como objetivo garantir o acesso destes pacientes a um atendimento qualificado, integral, universal e equânime, com respeito às diferenças e aceitação das pessoas com doenças raras nos diferentes níveis de atenção do SUS<sup>111</sup> .  
A entrada do paciente com anomalias craniofaciais no sistema de saúde pode ocorrer tanto pelos serviços de atenção primária à saúde com posterior encaminhamento para a atenção especializada, como diretamente por estes serviços de maior complexidade e centros de referência. O tratamento destas condições específicas é complexo e deve ser realizado em serviços de atenção especializada. Entretanto, agravos comuns e não relacionados a estas condições (cáries, edentulismo, doença periodontal, entre outros) não necessitam ser tratados com especialista, de modo que o atendimento pode ser feito em Unidades Básicas de Saúde (UBS) ou CEO, de acordo com a necessidade do usuário.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **10. REFERÊNCIAS** -->
1. Shaw W. Global strategies to reduce the health care burden of craniofacial anomalies: report of WHO meetings on international collaborative research on craniofacial anomalies. _Cleft Palate Craniofac J_ . 2004 May;41(3):238–43.  
2. Sanz-Cortés M, Gómez O, Puerto B. 68 - Micrognathia and Retrognathia. In: Copel JA, D’Alton ME, Feltovich H, Gratacós E, Krakow D, Odibo AO, et al., editors. Elsevier; 2018. p. 321-327. e1.  
3. Paladini D. Fetal micrognathia: almost always an ominous finding. Vol. 35, Ultrasound in obstetrics & gynecology: the official journal of the International Society of Ultrasound in Obstetrics and Gynecology. England; 2010. p. 377–84.  
4. Antonakopoulos N, Bhide A. Focus on Prenatal Detection of Micrognathia. _J Fetal Med_ . 2019 Jul.  
5. Breugem CC, Evans KN, Poets CF, Suri S, Picard A, Filip C, et al. Best Practices for the Diagnosis and Evaluation of  
Infants With Robin Sequence: A Clinical Consensus Report. _JAMA Pediatr_ . 2016 Sep;170(9):894–902.  
6. Polley J, Figueroa A, Kidd M. Principles of distraction osteogenesis in craniofacial surgery. In: Craniofacial Surgery: science and surgical technique. Philadelphia: Saunders Company; 2002. p. 163–71.  
7. McCarthy JG, Stelnicki EJ, Mehrara BJ, Longaker MT. Distraction osteogenesis of the craniofacial skeleton. _Plast_  
_Reconstr Surg_ . 2001 Jun;107(7):1812–27.  
8. Marques IL, Sousa TV de, Carneiro AF, Peres SP de BA, Barbieri MA, Bettiol H. Seqüência de Robin: protocolo único  
de tratamento . Vol. 81, Jornal de Pediatria . scielo ; 2005. p. 14–22.  
9. Abel F, Bajaj Y, Wyatt M, Wallis C. The successful use of the nasopharyngeal airway in Pierre Robin sequence: an 11-  
year experience. _Arch Dis Child_ . 2012 Apr;97(4):331–4.  
10. Demke J, Bassim M, Patel MR, Dean S, Rahbar R, van Aalst JA, et al. Parental perceptions and morbidity:  
tracheostomy and Pierre Robin sequence. _Int J Pediatr Otorhinolaryngol_ . 2008 Oct;72(10):1509–16.  
11. Runyan CM, Uribe-Rivera A, Tork S, Shikary TA, Ehsan Z, Weaver KN, et al. Management of Airway Obstruction  
in Infants With Pierre Robin Sequence. _Plast Reconstr surgery Glob open_ . 2018 May;6(5):e1688.  
12. Argamaso R V. Glossopexy for upper airway obstruction in Robin sequence. _Cleft palate-craniofacial J Off Publ Am_  
_Cleft Palate-Craniofacial Assoc_ . 1992 May;29(3):232– 8.  
13. Bookman LB, Melton KR, Pan BS, Bender PL, Chini BA, Greenberg JM, et al. Neonates with tongue-based airway  
obstruction: a systematic review. _Otolaryngol neck Surg Off J Am Acad Otolaryngol Neck Surg_ . 2012 Jan;146(1):8–18.  
14. Paes EC, Mink van der Molen AB, Muradin MSM, Speleman L, Sloot F, Kon M, et al. A systematic review on the  
outcome of mandibular distraction osteogenesis in infants suffering Robin sequence. _Clin Oral Investig_ . 2013 Nov;17(8):1807– 20.  
15. Alonso N, Tonello C, Marques I, Carpes A, Maricevich M, Maricevich R. Robin Sequence. In: Cleft lip and palate  
treatment: a comprehensive guide. Springer; 208AD.  
16. Tahiri Y, Viezel-Mathieu A, Aldekhayel S, Lee J, Gilardino M. The effectiveness of mandibular distraction in  
improving airway obstruction in the pediatric population. _Plast Reconstr Surg_ . 2014 Mar;133(3):352e-359e.  
17. da Costa AL, Manica D, Schweiger C, Kuhl G, Sekine L, Fagondes SC, et al. The effect of mandibular distraction  
osteogenesis on airway obstruction and polysomnographic parameters in children with Robin sequence. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2018 Aug;46(8):1343–7.  
18. Aljerian A, Gilardino MS. Treacher Collins Syndrome. _Clin Plast Surg_ . 2019 Apr;46(2):197–205.  
19. Birgfeld C, Heike C. Craniofacial Microsomia. _Clin Plast Surg_ . 2019 Apr;46(2):207–21.  
20. Robin P. Glossoptosis due to atresia and hypotrophy of the mandible. _Am J Dis Child_ . 1934 Sep;48(3):541–7.  
21. Di Pasquo E, Amiel J, Roth P, Malan V, Lind K, Chalouhi C, et al. Efficiency of prenatal diagnosis in Pierre Robin  
sequence. _Prenat Diagn_ . 2017 Nov;37(11):1169–75.  
22. Manica D, Schweiger C, Sekine L, Fagondes SC, Kuhl G, Collares MVM, et al. The role of flexible fiberoptic  
laryngoscopy in Robin Sequence: A systematic review. _J cranio- maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2017 Feb;45(2):210– 5.  
23. Evans KN, Sie KC, Hopper RA, Glass RP, Hing A V, Cunningham ML. Robin sequence: from diagnosis to  
development of an effective management plan. _Pediatrics_ . 2011 May;127(5):936–48.  
24. Costa MA, Tu MM, Murage KP, Tholpady SS, Engle WA, Flores RL. Robin sequence: mortality, causes of death, and  
clinical outcomes. _Plast Reconstr Surg_ . 2014 Oct;134(4):738–45.  
25. Anderson ICW, Sedaghat AR, McGinley BM, Redett RJ, Boss EF, Ishman SL. Prevalence and severity of obstructive  
sleep apnea and snoring in infants with Pierre Robin sequence. _Cleft palate-craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 2011 Sep;48(5):614–8.  
26. Pinheiro Neto CD, Alonso N, Sennes LU, Goldenberg DC, Santoro P de P. Polysomnography evaluation and  
swallowing endoscopy of patients with Pierre Robin sequence. _Braz J Otorhinolaryngol_ . 2009;75(6):852–6.  
27. Posnick JC, Ruiz RL. Treacher Collins syndrome: current evaluation, treatment, and future directions. _Cleft palate-_  
_craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 2000 Sep;37(5):434.  
28. Passos-Bueno MR, Ornelas CC, Fanganiello RD. Syndromes of the first and second pharyngeal arches: A review. _Am J Med Genet A_ . 2009 Aug;149A(8):1853–9.  
29. Ribeiro A de A, Smith FJ, Nary Filho H, Trindade IEK, Tonello C, Trindade-Suedam IK. Three-Dimensional Upper  
Airway Assessment in Treacher Collins Syndrome. _Cleft palate-craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 2020 Mar;57(3):371– 7.  
30. Posnick JC, Tiwana PS, Costello BJ. Treacher Collins syndrome: comprehensive evaluation and treatment. _Oral_  
_Maxillofac Surg Clin North Am_ . 2004 Nov;16(4):503–23.  
31. Perkins JA, Sie KC, Milczuk H, Richardson MA. Airway management in children with craniofacial anomalies. _Cleft_  
_palate-craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 1997 Mar;34(2):135–40.  
32. BRASIL. A Saúde Bucal no Sistema Único de Saúde. 1a ed. de Oliveira Junior A, editor. Brasília: Ministério da Saúde;  
2018.  
33. BRASIL. Relatório de Recomendação nº 430 - Distrator Osteogênico Mandibular. Ministério da Saúde. 2019.  
34. Ohtani J, Hoffman WY, Vargervik K, Oberoi S. Team management and treatment outcomes for patients with hemifacial microsomia. _Am J Orthod Dentofac Orthop Off Publ Am Assoc Orthod its Const Soc Am Board Orthod_ . 2012 Apr;141(4 Suppl):S74-81.  
35. Werler MM, Starr JR, Cloonan YK, Speltz ML. Hemifacial microsomia: from gestation to childhood. _J Craniofac_  
_Surg_ . 2009 Mar;20 Suppl 1(Suppl 1):664–9.  
36. Weichman KE, Jacobs J, Patel P, Szpalski C, Shetye P, Grayson B, et al. Early Distraction for Mild to Moderate  
Unilateral Craniofacial Microsomia: Long-Term Follow-Up, Outcomes, and Recommendations. _Plast Reconstr Surg_ . 2017 Apr;139(4):941e-953e.  
37. Grabb WC. The first and second branchial arch syndrome. _Plast Reconstr Surg_ . 1965 Nov;36(5):485–508.  
38. Sher AE. Mechanisms of airway obstruction in Robin sequence: implications for treatment. _Cleft palate-craniofacial_  
_J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 1992 May;29(3):224–31.  
39. Tufik S, Santos-Silva R, Taddei JA, Bittencourt LRA. Obstructive sleep apnea syndrome in the Sao Paulo  
Epidemiologic Sleep Study. _Sleep Med_ . 2010 May;11(5):441–6.  
40. Hoffstein V, Szalai JP. Predictive value of clinical features in diagnosing obstructive sleep apnea. _Sleep_ . 1993  
Feb;16(2):118–22.  
41. Ross SD, Sheinhait IA, Harrison KJ, Kvasz M, Connelly JE, Shea SA, et al. Systematic review and meta-analysis of  
the literature regarding the diagnosis of sleep apnea. _Sleep_ . 2000 Jun;23(4):519–32.  
42. Chaves Junior CM, Dal-Fabbro C, Bruin VMS de, Tufik S, Bittencourt LRA. Consenso brasileiro de ronco e apneia  
do sono: aspectos de interesse aos ortodontistas . Vol. 16, Dental Press Journal of Orthodontics . scielo ; 2011. p. e1–10.  
43. Martinho FL, Tangerina RP, Moura SMGT, Gregório LC, Tufik S, Bittencourt LRA. Systematic head and neck physical examination as a predictor of obstructive sleep apnea in class III obese patients. _Brazilian J Med Biol Res = Rev Bras Pesqui medicas e Biol_ . 2008 Dec;41(12):1093–7.  
44. Friedman M, Tanyeri H, La Rosa M, Landsberg R, Vaidyanathan K, Pieri S, et al. Clinical predictors of obstructive sleep apnea. _Laryngoscope_ . 1999 Dec;109(12):1901–7.  
45. Zonato AI, Martinho FL, Bittencourt LR, de Oliveira Camponês Brasil O, Gregório LC, Tufik S. Head and neck physical examination: comparison between nonapneic and obstructive sleep apnea patients. _Laryngoscope_ . 2005 Jun;115(6):1030–4.  
46. Manica D, Schweiger C, Sekine L, Fagondes SC, Kuhl G, Collares MVM, et al. The role of flexible fiberoptic laryngoscopy in Robin Sequence: A systematic review. _J cranio- maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial_  
_Surg_ . 2017 Feb;45(2):210– 5.  
47. Fahradyan A, Azadgoli B, Tsuha M, Urata MM, Francis SH. A Single Lab Test to Aid Pierre Robin Sequence Severity  
Diagnosis. _Cleft palate-craniofacial J Off Publ Am Cleft Palate- Craniofacial Assoc_ . 2019 Mar;56(3):298–306.  
48. Schobel G, Millesi W, Watzke IM, Hollmann K. Ankylosis of the temporomandibular joint. Follow-up of thirteen  
patients. _Oral Surg Oral Med Oral Pathol_ . 1992 Jul;74(1):7– 14.  
49. Sporniak-Tutak K, Janiszewska-Olszowska J, Kowalczyk R. Management of temporomandibular ankylosis--  
compromise or individualization--a literature review. _Med Sci Monit_ . 2011 May;17(5):RA111–6.  
50. Shetty P, Thomas A, Sowmya B. Diagnosis of temporomandibular joint (TMJ) ankylosis in children. _J Indian Soc_  
_Pedod Prev Dent_ . 2014;32(3):266–70.  
51. Rozanski C, Wood K, Sanati-Mehrizy P, Xu H, Taub PJ. Ankylosis of the Temporomandibular Joint in Pediatric  
Patients. _J Craniofac Surg_ . 2019 Jun;30(4):1033– 8.  
52. Tsui WK, Yang Y, Cheung LK, Leung YY. Distraction osteogenesis as a treatment of obstructive sleep apnea  
syndrome: A systematic review. _Medicine (Baltimore)_ . 2016 Sep;95(36):e4674.  
53. Poets CF, Koos B, Reinert S, Wiechers C. The Tübingen palatal plate approach to Robin sequence: Summary of current  
evidence. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2019 Nov;47(11):1699–705.  
54. van Lieshout MJS, Joosten KFM, Hoeve HLJ, Mathijssen IMJ, Koudstaal MJ, Wolvius EB. Unravelling Robin  
sequence: considerations of diagnosis and treatment. _Laryngoscope_ . 2014 May;124(5):E203-9.  
55. Bütow K-W, Naidoo S, Zwahlen RA, Morkel JA. Pierre Robin sequence: Subdivision, data, theories, and treatment -  
- Part 4: Recommended management and treatment of Pierre Robin sequence and its application. _Ann Maxillofac Surg_ . 2016;6(1):44–9.  
56. Daniel M, Bailey S, Walker K, Hensley R, Kol-Castro C, Badawi N, et al. Airway, feeding and growth in infants with  
Robin sequence and sleep apnoea. _Int J Pediatr Otorhinolaryngol_ . 2013 Apr;77(4):499–503.  
57. Lander T, Scott A. Mandibular Distraction. In: Complete Cleft Care: Cleft and Velopharyngeal Insufficiency  
Treatment in Children. New York: Thieme Medical Publishers; 2014. p. 21–36.  
58. Caouette-Laberge L, Bayet B, Larocque Y. The Pierre Robin sequence: review of 125 cases and evolution of treatment  
modalities. _Plast Reconstr Surg_ . 1994 Apr;93(5):934– 42.  
59. Meyer AC, Lidsky ME, Sampson DE, Lander TA, Liu M, Sidman JD. Airway interventions in children with Pierre  
Robin Sequence. _Otolaryngol neck Surg Off J Am Acad Otolaryngol Neck Surg_ . 2008 Jun;138(6):782–7.  
60. Evans AK, Rahbar R, Rogers GF, Mulliken JB, Volk MS. Robin sequence: a retrospective review of 115 patients. _Int_  
_J Pediatr Otorhinolaryngol_ . 2006 Jun;70(6):973–80.  
61. Kirschner RE, Low DW, Randall P, Bartlett SP, McDonald-McGinn DM, Schultz PJ, et al. Surgical airway  
management in Pierre Robin sequence: is there a role for tongue-lip adhesion? _Cleft palate-craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 2003 Jan;40(1):13–8.  
62. Pasyayan HM, Lewis MB. Clinical experience with the Robin sequence. _Cleft Palate J_ . 1984 Oct;21(4):270–6.  
63. Greathouse ST, Costa M, Ferrera A, Tahiri Y, Tholpady SS, Havlik RJ, et al. The Surgical Treatment of Robin  
Sequence. _Ann Plast Surg_ . 2016 Oct;77(4):413–9.  
64. Caouette-Laberge L, Borsuk DE, Bortoluzzi PA. Subperiosteal release of the floor of the mouth to correct airway  
obstruction in pierre robin sequence: review of 31 cases. _Cleft palate-craniofacial J Off Publ Am Cleft Palate-Craniofacial Assoc_ . 2012 Jan;49(1):14– 20.  
65. Zhang RS, Hoppe IC, Taylor JA, Bartlett SP. Surgical Management and Outcomes of Pierre Robin Sequence: A  
- Comparison of Mandibular Distraction Osteogenesis and Tongue-Lip Adhesion. _Plast Reconstr Surg_ . 2018 Aug;142(2):480–509.  
66. Zeitouni A, Manoukian J. Tracheotomy in the first year of life. _J Otolaryngol_ . 1993 Dec;22(6):431–4.  
67. Tomaski SM, Zalzal GH, Saal HM. Airway obstruction in the Pierre Robin sequence. _Laryngoscope_ . 1995  
Feb;105(2):111–4.  
68. Sasaki CT, Horiuchi M, Koss N. Tracheostomy-related subglottic stenosis: bacteriologic pathogenesis. _Laryngoscope_ .  
1979 Jun;89(6 Pt 1):857–65.  
69. Arola MK. Tracheostomy and its complications. A retrospective study of 794 tracheostomized patients. _Ann Chir_  
_Gynaecol_ . 1981;70(3):96–106.  
70. Guilleminault C, Simmons FB, Motta J, Cummiskey J, Rosekind M, Schroeder JS, et al. Obstructive sleep apnea  
syndrome and tracheostomy. Long-term follow-up experience. _Arch Intern Med_ . 1981 Jul;141(8):985–8.  
71. Singer LT, Kercsmar C, Legris G, Orlowski JP, Hill BP, Doershuk C. Developmental sequelae of long-term infant  
tracheostomy. _Dev Med Child Neurol_ . 1989 Apr;31(2):224– 30.  
72. Andrews BT, Fan KL, Roostaeian J, Federico C, Bradley JP. Incidence of concomitant airway anomalies when using  
the university of California, Los Angeles, protocol for neonatal mandibular distraction. _Plast Reconstr Surg_ . 2013 May;131(5):1116–23.  
73. Cruz MJ, Kerschner JE, Beste DJ, Conley SF. Pierre Robin sequences: secondary respiratory difficulties and intrinsic  
feeding abnormalities. _Laryngoscope_ . 1999 Oct;109(10):1632–6.  
74. Denny AD, Amm CA, Schaefer RB. Outcomes of tongue-lip adhesion for neonatal respiratory distress caused by  
Pierre Robin sequence. _J Craniofac Surg_ . 2004 Sep;15(5):819–23.  
75. Denny AD. Distraction osteogenesis in Pierre Robin neonates with airway obstruction. _Clin Plast Surg_ . 2004  
Apr;31(2):221–9.  
76. Schaefer RB, Stadler JA 3rd, Gosain AK. To distract or not to distract: an algorithm for airway management in isolated  
Pierre Robin sequence. _Plast Reconstr Surg_ . 2004 Apr;113(4):1113–25.  
77. Hoffman W. Outcome of tongue-lip plication in patients with severe Pierre Robin sequence. _J Craniofac Surg_ . 2003  
Sep;14(5):602–8.  
78. Rogers GF, Murthy AS, LaBrie RA, Mulliken JB. The GILLS score: part I. Patient selection for tongue-lip adhesion  
in Robin sequence. _Plast Reconstr Surg_ . 2011 Jul;128(1):243– 51.  
79. Genecov DG, Barceló CR, Steinberg D, Trone T, Sperry E. Clinical experience with the application of distraction  
osteogenesis for airway obstruction. _J Craniofac Surg_ . 2009 Sep;20 Suppl 2:1817–21.  
80. Burstein FD, Williams JK. Mandibular distraction osteogenesis in Pierre Robin sequence: application of a new internal  
single-stage resorbable device. _Plast Reconstr Surg_ . 2005 Jan;115(1):61–9.  
81. Murage KP, Tholpady SS, Friel M, Havlik RJ, Flores RL. Outcomes analysis of mandibular distraction osteogenesis  
for the treatment of Pierre Robin sequence. _Plast Reconstr Surg_ . 2013 Aug;132(2):419–21.  
82. Murage KP, Costa MA, Friel MT, Havlik RJ, Tholpady SS, Flores RL. Complications associated with neonatal  
mandibular distraction osteogenesis in the treatment of Robin sequence. _J Craniofac Surg_ . 2014 Mar;25(2):383–7.  
83. Monasterio FO, Molina F, Berlanga F, López ME, Ahumada H, Takenaga RH, et al. Swallowing disorders in Pierre  
Robin sequence: its correction by distraction. _J Craniofac Surg_ . 2004 Nov;15(6):934–41.  
84. Hammoudeh J, Bindingnavele VK, Davis B, Davidson Ward SL, Sanchez-Lara PA, Kleiber G, et al. Neonatal and  
infant mandibular distraction as an alternative to tracheostomy in severe obstructive sleep apnea. _Cleft palate-craniofacial J Off Publ Am Cleft Palate- Craniofacial Assoc_ . 2012 Jan;49(1):32–8.  
85. Scott AR, Tibesar RJ, Lander TA, Sampson DE, Sidman JD. Mandibular distraction osteogenesis in infants younger  
than 3 months. _Arch Facial Plast Surg_ . 2011;13(3):173– 9.  
86. Collares M. USE OF OSTEOGENIC MANDIBULAR DISTRACTION IN NEONATES WITH SEVERE AIRWAY  
OBSTRUCTION. Braz J Craniomaxillofac Surg 2000;3(2):7-12. 2000 Dec;3:7–12.  
87. Monasterio FO, Drucker M, Molina F, Ysunza A. Distraction osteogenesis in Pierre Robin sequence and related respiratory problems in children. _J Craniofac Surg_ . 2002 Jan;13(1):79–83; discussion 84.  
88. Denny A, Kalantarian B. Mandibular distraction in neonates: a strategy to avoid tracheostomy. _Plast Reconstr Surg_ .  
2002 Mar;109(3):896.  
89. Flores RL, Greathouse ST, Costa M, Tahiri Y, Soleimani T, Tholpady SS. Defining failure and its predictors in  
mandibular distraction for Robin sequence. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2015 Oct;43(8):1614–9.  
90. Tahiri Y, Greathouse ST, Tholpady SS, Havlik R, Sood R, Flores RL. Mandibular Distraction Osteogenesis in Low-  
Weight Neonates with Robin Sequence: Is It Safe? _Plast Reconstr Surg_ . 2015 Nov;136(5):1037–44.  
91. Bouchard C, Troulis MJ, Kaban LB. Management of Obstructive Sleep Apnea: Role of Distraction Osteogenesis. _Oral_  
_Maxillofac Surg Clin_ . 2009 Nov;21(4):459–75.  
92. Hammoudeh JA, Fahradyan A, Brady C, Tsuha M, Azadgoli B, Ward S, et al. Predictors of Failure in Infant  
Mandibular Distraction Osteogenesis. _J oral Maxillofac Surg Off J Am Assoc Oral Maxillofac Surg_ . 2018 Sep;76(9):1955–65.  
93. Noller MW, Guilleminault C, Gouveia CJ, Mack D, Neighbors CL, Zaghi S, et al. Mandibular advancement for  
pediatric obstructive sleep apnea: A systematic review and meta-analysis. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2018 Aug;46(8):1296–302.  
94. Verlinden CRA, van de Vijfeijken SECM, Tuinzing DB, Jansma EP, Becking AG, Swennen GRJ. Complications of  
mandibular distraction osteogenesis for developmental deformities: a systematic review of the literature. _Int J Oral Maxillofac Surg_ . 2015 Jan;44(1):44–9.  
95. Gonzalez-Lagunas J. Is the piezoelectric device the new standard for facial osteotomies? _J Stomatol oral Maxillofac_  
_Surg_ . 2017 Sep;118(4):255–8.  
96. Pagotto LEC, de Santana Santos T, de Vasconcellos SJ de A, Santos JS, Martins-Filho PRS. Piezoelectric versus  
conventional techniques for orthognathic surgery: Systematic review and meta-analysis. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio- Maxillo-Facial Surg_ . 2017 Oct;45(10):1607–13.  
97. Flores RL. Neonatal mandibular distraction osteogenesis. _Semin Plast Surg_ . 2014 Nov;28(4):199–206.  
98. Zellner EG, Mhlaba JM, Reid RR, Steinbacher DM. Does Mandibular Distraction Vector Influence Airway Volumes  
and Outcome? _J oral Maxillofac Surg Off J Am Assoc Oral Maxillofac Surg_ . 2017 Jan;75(1):167–77.  
99. Mahrous Mohamed A, Al Bishri A, Haroun Mohamed A. Distraction osteogenesis as followed by CT scan in Pierre  
Robin sequence. _J cranio-maxillo-facial Surg Off Publ Eur Assoc Cranio-Maxillo-Facial Surg_ . 2011 Sep;39(6):412–9.  
100. Mao Z, Zhang N, Shu L, Cui Y. Imaging characteristics of the mandible and upper airway in children with Robin  
sequence and relationship to the treatment strategy. _Int J Oral Maxillofac Surg_ . 2020 Feb.  
101. Zellner EG, Reid RR, Steinbacher DM. The Pierre Robin Mandible is Hypoplastic and Morphologically Abnormal.  
_J Craniofac Surg_ . 2017 Nov;28(8):1946–9.  
102. Susarla SM, Vasilakou N, Kapadia H, Egbert M, Hopper RA, Evans KN. Defining mandibular morphology in Robin  
sequence: A matched case-control study. _Am J Med Genet A_ . 2017 Jul;173(7):1831–8.  
103. Rogers GF, Lim AAT, Mulliken JB, Padwa BL. Effect of a syndromic diagnosis on mandibular size and sagittal  
- position in Robin sequence. _J oral Maxillofac Surg Off J Am Assoc Oral Maxillofac Surg_ . 2009 Nov;67(11):2323–31.  
104. Rachmiel A, Nseir S, Emodi O, Aizenbud D. External versus Internal Distraction Devices in Treatment of Obstructive  
Sleep Apnea in Craniofacial Anomalies. _Plast Reconstr surgery Glob open_ . 2014 Aug;2(7):e188–e188.  
105. Ow ATC, Cheung LK. Meta-analysis of mandibular distraction osteogenesis: clinical applications and functional  
outcomes. _Plast Reconstr Surg_ . 2008 Mar;121(3):54e-69e.  
106. Davidson EH, Brown D, Shetye PR, Greig AVH, Grayson BH, Warren SM, et al. The evolution of mandibular  
distraction: device selection. _Plast Reconstr Surg_ . 2010 Dec;126(6):2061–70.  
107. Fan KL, Mandelbaum M, Buro J, Rokni A, Rogers GF, Chao JW, et al. Current Trends in Surgical Airway  
Management of Neonates with Robin Sequence. _Plast Reconstr surgery Glob open_ . 2018 Nov;6(11):e1973.  
108. Chen W, Davidson EH, MacIsaac ZM, Kumar A. Mapping the Mandibular Lingula in Pierre Robin Sequence: A  
Guide to the Inverted-L Osteotomy. _J Craniofac Surg_ . 2015 Sep;26(6):1847–52.  
109. BRASIL. Passo a passo da Política Nacional de Saúde Bucal. Ministério da Saúde.  2016.  
110. BRASIL. Diretrizes da Política Nacional de Saúde Bucal. Ministério da Saúde. 2004.  
111. BRASIL. Portaria n<sup>o</sup> 199, de 30 de janeiro de 2014. Institui a Política Nacional de Atenção Integral às Pessoas com Doenças Raras, aprova as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do Sistema Único de Saúde (SUS). _Diário Oficial da União_ . 2014;  
**APÊNDICE 1**  
QUESTIONÁRIO DE BERLIM PARA RASTREAMENTO DE SAOS  
|**Categoria 1**||**Categoria 2**||
|---|---|---|---|
||||(  ) Quase todos os dias|
|1 )Você ronca?|(  ) Sim<br>(  ) Não<br>(  ) Não sei|2) Quantas vezes você se<br>sente cansado ou fatigado<br>ao acordar?|(  ) 3 - 4 vezes por semana<br>(  ) 1 - 2 vezes por semana<br>(  ) 1 - 2 vezes por mês<br>(  ) Quase nunca ou nunca|
|3) Seu ronco é:|(  ) Pouco mais alto que<br>a sua respiração<br>(  ) Tão alto quanto<br>falando<br>(  ) Mais alto do que<br>falando<br>(  ) Tão alto que pode<br>ser ouvido dentro de<br>outro cômodo|4) Você se sente cansado<br>ou fatigado durante o<br>dia?|(  ) Quase todos os dias<br>(  ) 3 - 4 vezes por semana<br>(  ) 1 - 2 vezes por semana<br>(  ) 1 - 2 vezes por mês<br>(  ) Quase nunca ou nunca|
|5) Com que frequência<br>você ronca?|(  ) Quase todos os dias<br>(  ) 3 – 4 vezes por<br>semana<br>(  ) 1 -2 vezes por<br>semana<br>(  ) 1-2 vezes por mês<br>(  ) Quase nunca ou<br>nunca|6) Alguma vez você já<br>cochilou ou dormiu<br>enquanto dirigia|(  ) Sim<br>(  ) Não|
|7) O seu ronco incomoda<br>alguém?|(  ) Sim<br>(  ) Não<br>(  ) Não sei|**Categoria 3**||
|8)Alguém notou que<br>você para de respirar<br>enquanto dorme?|(  ) Quase todos os dias<br>(  ) 3 - 4 vezes por<br>semana<br>(  ) 1 - 2 vezes por<br>semana<br>(  ) 1 - 2 vezes por mês<br>(  ) Quase nunca ou|9) É hipertenso?<br>IMC|(  ) Sim<br>(  ) Não<br>(  ) Não sei<br>________ kg/m<sup>2</sup>|
||nunca|||
|**Pontuação:**||||
|Categoria 1 - positiva se a pont|uação é maior ou igual a 2 po|ntos||
|Categoria 2 - positiva se a pont|uação é maior ou igual a 2 po|ntos||
|Categoria 3 - positiva se a repo<br>Alto risco para SAOS: duas ou|sta ao item 9 for sim ou se o<br>mais categorias com pontuaçã|índice de massa corporal (IMC)<br>o positiva|do doente é superior a 30kg/m<sup>2</sup>|  
Baixo risco para SAOS: nenhuma ou apenas uma categoria com pontuação positiva  
Fonte: Netzer et al., 1999<sup>1</sup> Araújo-Melo et al., 2016<sup>2</sup>

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Referências:** -->
1. Netzer NC, Stoohs RA, Netzer CM, Clark K, Strohl KP. Using the Berlin Questionnaire to Identify Patients at Risk for the Sleep Apnea Syndrome. Ann Intern Med. 1999 Oct;131(7):485–91.  
2. Araújo-Melo MH, Neves DD, Ferreira LV, Moreira ML, Nigri R, Simões SM. Questionários e escalas úteis na pesquisa da síndrome da apneia obstrutiva do sono. Rev HUPE. 2016;15(1):49–55.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: ESCALA DE SONOLÊNCIA DE EPWORTH -->
|Qual a probabilidade de você cochilar e dormir, e não apenas se sentir cansado, nas segui|ntes situações?|Consid|ere o modo|
|---|---|---|---|
|de vida que você tem levado recentemente. Mesmo que não tenha feito algumas dessas coisas r<br>elas o afetariam. Escolha o número mais apropriado para responder cada questão.<br>0 = nunca cochilaria|ecentemente, te|nte ima|ginar como|
|1 = pequena probabilidade de cochilar||||
|2 = probabilidade média de cochilar||||
|3 = grande probabilidade de cochilar||||
|**Situação**|**Probabili**|**dade d**|**e cochilar**|
|Sentado e lendo|0|1|2|
|Assistindo TV|0|1|2|
|Sentado, quieto, em um lugar público ( por exemplo, em um teatro, reunião ou palestra)|0|1|2|
|Andando de carro por uma hora sem parar, como passageiro|0|1|2|
|Sentado quieto após o almoço sem bebida de álcool|0|1|2|
|Em um carro parado no trânsito por alguns minutos|0|1|2|
|Pontuação:||||
|1 a 6 pontos: sono normal||||
|7 a 8 pontos: sonolência média||||
|9 a 24 pontos: Sonolência anormal, possivelmente patológica||||  
Fonte: Johns, 1991<sup>1</sup> ; Bertolazi et al., 2009<sup>2</sup> .

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: Referências: -->
1. Johns MW. A New Method for Measuring Daytime Sleepiness: The Epworth Sleepiness Scale. Sleep. 1991 Nov;14(6):540–5.  
2. Bertolazi AN, Fagondes SC, Hoff LS, Pedro VD, Barreto SSM, Johns MW. Pneumonias virais: aspectos epidemiológicos, clínicos, fisiopatológicos e tratamento. J Bras Pneumol. 2009;35(9):899–906.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Escopo e Finalidade do Protocolo** -->
A elaboração do Protocolo de Uso do Distrator Osteogênico Mandibular (DOM) para o Tratamento de Deformidades Crânio e Buco-Maxilo-Faciais Congênitas ou Adquiridas teve início com reunião presencial para delimitação do escopo do Protocolo. Esta reunião foi composta por: cinco membros do então Departamento de Gestão, Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), que representa a secretaria executiva da CONITEC; por seis membros do grupo elaborador, sendo dois especialistas médicos, três metodologistas e a coordenadora administrativa do projeto; e por dois especialistas representantes de sociedades médicas da área.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do Protocolo, sendo definida a sua macroestrutura, embasada no disposto na Portaria n° 375, de 10 de novembro de 2009<sup>1</sup> , e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde, sendo as seções do documento definidas<sup>2</sup> .  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias poderiam ser identificadas. Neste caso, o grupo de especialistas foi orientado sobre a possibilidade de elencar questões de pesquisa, que seriam estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Equipe de elaboração e partes interessadas** -->
O grupo elaborador deste Protocolo foi composto por um painel de especialistas e metodologistas sob coordenação do DGITS. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
O documento foi submetido à apreciação na 83ª reunião da Subcomissão de Protocolos Clínicos e Diretrizes Terapêuticas. A versão atual do Protocolo já considera as solicitações desta Subcomissão.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Consulta pública** -->
A Consulta Pública nº 72/2020, do Protocolo de Uso do Distrator Osteogênico Mandibular (DOM), foi realizada entre os dias 05/01/2021 a 25/01/2021. Foram recebidas 88 contribuições, no total e salienta-se que todas foram analisadas. O conteúdo integral das contribuições se encontra disponível na página da CONITEC em: http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_72_2020_Protocolo_de_Uso.pdf.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Busca da evidência** -->
Este Protocolo foi desenvolvido conforme processos preconizados pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>22</sup> . Este documento se baseou no Relatório n<sup>o</sup> 430 da Conitec, que recomendou a incorporação do procedimento de distração osteogênica mandibular<sup>24</sup> . Durante a reunião de escopo, não foram levantadas perguntas de pesquisa para embasar a escrita.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Recomendações** -->
A relatoria das seções do Protocolo foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Como não foram elencadas questões de pesquisa, os especialistas foram orientados a referenciar a recomendação com  
base nos estudos que consolidaram a prática clínica. Por este mesmo motivo, não foram realizadas reuniões adicionais para discussão das evidências.  
Em fevereiro de 2019, o procedimento de Distração Osteogênica Mandibular foi aprovado para o tratamento de anomalias congênitas ou de desenvolvimento dos ossos do crânio<sup>20</sup> , sendo necessário protocolo de uso desta técnica. A elaboração desse PCDT teve como base para sua estruturação o processo preconizado pelo Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde<sup>21</sup> e pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>22</sup> . A diretriz foi desenvolvida com base na metodologia GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), seguindo os passos descritos no _GIN-McMaster Guideline Development Checklist_<sup>23</sup> . Esta metodologia envolve diversas etapas na elaboração deste documento, dentre elas a definição de um escopo, elaboração de perguntas de pesquisa estruturadas para busca de evidências, seleção, avaliação da qualidade e graduação das evidências pelo sistema GRADE, elaboração de recomendações por meio de um painel com especialistas e redação do texto final. O presente Protocolo é específico para o procedimento de DOM e foi embasado no Relatório de Recomendação n<sup>o</sup> 430 da Conitec<sup>24</sup> . Durante o processo de escopo, não foram elencadas perguntas adicionais, de modo que não foi necessário o desenvolvimento de revisões sistemáticas.

---

<!-- METADADOS: doenca: Distrator Osteogênico Mandibular (DOM) | secao: **Referências:** -->
1. BRASIL. Portaria nº 375, de 10 de novembro de 2009. Diário Oficial da União. 2009.  
2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.

---

