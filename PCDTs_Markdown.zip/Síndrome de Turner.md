<!-- METADADOS: doenca: Síndrome de Turner | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA Nº 15, DE 01 DE AGOSTO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Turner.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Síndrome de Turner no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 975 e o Relatório de Recomendação nº 978/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Síndrome de Turner.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Síndrome de Turner, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Síndrome de Turner.  
Art. 3º Os gestores Estaduais, Distrital e Municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE nº 15, de 9 de maio de 2018, publicada no Diário Oficial da União nº 99, de 24 de maio de 2018, seção 1, pág. 78.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: FERNANDA DE NEGRI -->
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS SÍNDROME DE TURNER**

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **1. INTRODUÇÃO** -->
A síndrome de Turner é uma das anormalidades dos cromossomos sexuais no sexo feminino e requer uma análise cromossômica para confirmação diagnóstica. Múltiplos cariótipos têm sido identificados e estão associados a apresentações variáveis no espectro do fenótipo da síndrome de Turner: monossomia 45,X, mosaicismo 45,X/46,XX, 45,X/46XY, cromossomo X estruturalmente anormal, cromossomos em anel e marcadores<sup>1</sup> . Meninas com monossomia 45,X representam aproximadamente metade dos casos e, normalmente, apresentam o fenótipo mais grave<sup>1,2</sup> .  
De acordo com a literatura, a síndrome de Turner é observada em cerca de 1 em 2.000 a 1 em 2.500 nascidos vivos do sexo feminino. No entanto, a verdadeira prevalência permanece desconhecida, pois muitos pacientes com um fenótipo leve podem permanecer sem diagnóstico ou são diagnosticados no final da idade adulta. A ocorrência da síndrome de Turner é quase a mesma em diferentes etnias e países<sup>2</sup> .  
A apresentação clínica de meninas com síndrome de Turner pode variar significativamente, especialmente entre aquelas com graus mais baixos de mosaicismo para monossomia X, as quais podem não apresentar o clássico fenótipo. A baixa estatura e a disgenesia gonadal são duas das características clínicas da síndrome, embora outros sistemas de órgãos e tecidos também possam ser afetados em menor ou maior extensão. A gama de comorbidades associadas à síndrome pode ter um efeito profundo na qualidade de vida e inclui: malformações cardíacas, anormalidades renais e gastrointestinais, perda auditiva neurossensorial, problemas oftalmológicos, doença tireoidiana autoimune, síndrome metabólica e alterações neuro cognitivas<sup>3</sup> .  
Um quinto a um terço das meninas afetadas são diagnosticadas ao nascer devido a mãos e pés inchados ou pele da nuca redundante que são um efeito residual de higromas císticos no útero. Deve-se suspeitar de síndrome de Turner em qualquer menina recém-nascida com linfedema ou coração esquerdo hipoplásico ou coarctação da aorta, uma vez que a frequência dessas condições é maior entre as crianças com a síndrome. Aproximadamente um terço de meninas com síndrome de Turner recebe o diagnóstico na metade da infância em investigação de baixa estatura, pois, com exceção da baixa estatura familiar ou atraso constitucional, a síndrome de Turner é a causa mais comum de baixa estatura em meninas saudáveis. Na maioria das outras pacientes com síndrome de Turner, a condição é diagnosticada na adolescência, quando as jovens não entram na puberdade, ou na idade adulta, devido a perdas gestacionais. O diagnóstico deve ser excluído em qualquer adolescente com amenorreia primária ou secundária, especialmente se ela apresentar baixa estatura para a idade<sup>4</sup> .  
Na síndrome de Turner, o mosaicismo com presença do cromossomo Y, seja íntegro ou com alteração estrutural, é ressaltado devido ao risco do desenvolvimento de gonadoblastoma, tumor ovariano benigno, mas com alto potencial de transformação maligna. A prevalência de sequências do cromossomo Y em pacientes com síndrome de Turner varia muito conforme a amostra e a técnica utilizada para detecção, que inclui a técnica de FISH (hibridização _in situ_ fluorescente) e técnicas moleculares como PCR (ou Reação em Cadeia da Polimerase)<sup>5,6</sup> .  
O tratamento da síndrome de Turner é centrado nas manifestações clínicas apresentadas. As principais condutas são o uso de somatropina para promoção do crescimento e a terapia de reposição hormonal para indução puberal, além do tratamento das várias comorbidades que podem estar associadas. A identificação precoce da síndrome de Turner e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da síndrome de Turner.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- Q96.0 Cariótipo 45,X  
- Q96.1 Cariótipo 46,X  iso  
- Q96.2 Cariótipo 46,X com cromossomo sexual anormal, salvo iso  
- Q96.3 Mosaicismo cromossômico, 45, X/46, XX ou XY  
- Q96.4 Mosaicismo cromossômico, 45, X/outras linhagens celulares com cromossomo sexual anormal  
- Q96.8 Outras variantes da síndrome de Turner

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **3. DIAGNÓSTICO** -->
O diagnóstico da síndrome de Turner pode ocorrer em diversas fases da vida. No período pré-natal, os achados ultrassonográficos anormais de aumento da transluscência ou higroma cístico da nuca, a presença de coarctação da aorta ou anomalias cardíacas do lado esquerdo, braquicefalia, rim em ferradura, polidrâmnio, oligoidrâmnio ou hidropisia fetal não imune são sinais sugestivos. A recém-nascida pode apresentar linfedema congênito de mãos e pés e pele da nuca redundante<sup>2</sup> . Sempre que houver alterações que sinalizem a possibilidade de síndrome de Turner nesses períodos um cariótipo deve ser realizado para confirmação diagnóstica.  
Além dessas características observadas no período neonatal, a confirmação diagnóstica por meio de cariótipo deve ser realizada também na presença de sinais clínicos como baixa estatura, puberdade tardia ou ausente, anomalias obstrutivas do lado esquerdo do coração e características como pescoço alado, micrognatia, palato alto e estreito, implantação baixa de orelhas, fissuras palpebrais inclinadas para baixo com pregas epicânticas<sup>8,9</sup> .  
O cariótipo com análise de pelo menos 30 células é recomendado e pode detectar até 10% de mosaicismo com 95% de confiança<sup>9</sup> . Essa avaliação é importante porque cerca de 40 a 50% das mulheres com síndrome de Turner apresentam cariótipo 45,X e 15 a 25% apresentam mosaicismo com 45,X/46,XX. As demais apresentam alterações estruturais, sendo que destas, 20% têm um isocromossomo, e os cromossomo em anel ou marcadores estão presentes em menor frequência<sup>8</sup> . Ainda, aproximadamente 10 a 12% das mulheres têm sequências do cromossomo Y, das quais, cerca de 3% apresentam cariótipo 45,X/46,XY<sup>8</sup> , e nas demais há alterações estruturais desse cromossomo,  
Os cromossomos marcadores são aqueles que não podem ser identificados ou caracterizados pelo cariótipo, enquanto os cromossomos em anel resultam da quebra em dois pontos seguidas da fusão das extremidades fraturadas. A identificação de derivados do cromossomo Y em pacientes apresentando cariótipo com mosaicismo com cromossomo marcador ou anel é importante para o acompanhamento desses pacientes devido ao risco aumentado de gonadoblastoma<sup>5,6</sup> . Os estudos demonstram uma provável equivalência da técnica de FISH (hibridização in situ fluorescente) e do PCR (ou Reação em Cadeia da Polimerase) quando são utilizados para identificação de derivados de cromossomo Y<sup>11-16</sup> .  
Em revisão de literatura que incluiu 18 estudos observacionais que avaliaram pacientes com síndrome de Turner com mosaicismo com cromossomo marcador ou em anel, a proporção de sequência de cromossomo Y detectada pelo exame PCR com primers para esse cromossomo foi 51,9% (IC 95%: 35,4 a 68,5)<sup>12-38.</sup> Para a identificação de derivados de cromossomo Y recomenda-se, portanto, a realização de exame em sangue periférico com a utilização de _primers_ de sequências desse cromossomo em todas as pacientes com síndrome de Turner com cariótipo que apresentem mosaicismo com cromossomo marcador ou anel, pela técnica PCR, devido ao menor custo e maior facilidade de execução. Também se recomenda a realização de PCR com _primers_ de sequências de cromossomo Y em pacientes com síndrome de Turner com cariótipo 45X e sinais de virilização, para investigação de possível mosaicismo<sup>9</sup> (Figura 1).  
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, racismo, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
**Figura 1 -** Algoritmo de exames para diagnóstico de síndrome de Turner.  
<!-- Start of picture text -->
Paciente com suspeita de sindrome de Turner<br>Determinar caritipo |<br>eaexx 45,X/46,X + anel ou marcador<br>AB XUEXY 45,X com viriizaco<br>Realizar PCR para<br>cromossomo Y<br>{_ indetectivei | {_Datectvel<br>‘Sem necessidade de \Orientar para risco de<br>exames adicionais gonadoblastoma<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídas neste Protocolo as pacientes com diagnóstico de síndrome de Turner confirmado por meio de cariótipo e que apresentem um dos seguintes critérios:  
- Se idade entre 2 e 5 anos: a altura deverá ser inferior ao percentil 5 da altura prevista para a idade, conforme a curva da  
- Organização Mundial da Saúde (OMS)<sup>30</sup> ;  
- Se idade acima de 5 anos: a altura deverá ser inferior ao percentil 5 da altura prevista para a idade, conforme a curva do _National Center for Health Statistics_ (NCHS)/ _Center of Disease Control_ (CDC) com idade óssea abaixo de 14 anos, estimada por radiografia de mãos e punhos<sup>31</sup> ;

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser excluídos ao uso do respectivo medicamento preconizado.  
Adicionalmente, para o tratamento com somatropina, serão excluídas deste Protocolo as pacientes que apresentarem pelo menos uma das condições abaixo:  
- Doença neoplásica maligna ativa;  
- Anomalias congênitas renais e cardiovasculares graves não corrigidas, que causam instabilidade clínica ou necessidade  
- de internação hospitalar e intervenção cirúrgica;  
- Doença aguda grave, isto é, que necessite internação e tratamento parenteral ou nada por via oral (NPO) ou tratamento  
- em unidade de terapia intensiva (UTI);  
- Hipertensão intracraniana benigna;  
- Retinopatia diabética proliferativa ou pré proliferativa.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6. TRATAMENTO** -->
O tratamento das pacientes com síndrome de Turner depende da idade e requer atenção de equipe multidisciplinar, envolvendo principalmente o tratamento hormonal e o controle adequado das comorbidades. Assim, uma vez feito o diagnóstico, a paciente deve ser encaminhada a serviços especializados para melhor acompanhamento.  
Estudos epidemiológicos demonstram que pacientes com síndrome de Turner apresentam maior morbidade devido às várias condições que podem estar associadas. As comorbidades mais frequentes são: alterações endocrinológicas, como diabetes e tireoidites, osteoporose, doenças cardiovasculares - sobretudo hipertensão e malformações cardíacas congênitas, além de doenças do aparelho digestivo<sup>8</sup> ,  
Nos casos de mosaicismo 45, X/46 XY ou naqueles em que foram detectados fragmentos de cromossomo Y ao diagnóstico citogenético ou molecular, a indicação de gonadectomia profilática deve ser discutida, uma vez que existe o risco de cerca de 10% de desenvolvimento de gonadoblastoma<sup>9</sup> . Apesar do gonadoblastoma ser um tumor benigno, este pode evoluir para um disgerminoma invasivo em aproximadamente 60% dos casos ou outras formas malignas de tumores de células germinativas<sup>32</sup> .  
Ressalta-se, ainda, a importância de os profissionais de saúde realizarem um atendimento baseado nos princípios do acolhimento e da escuta qualificada de meninas e mulheres com síndrome de Turner e seus familiares. Assim, o cuidado inclui o atendimento humanizado, resolutivo, que propicie a criação de vínculo entre as equipes e as pessoas, além de minimizar aspectos relacionados ao estigma, ao sofrimento e ao preconceito.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.1. Tratamento medicamentoso** -->
Durante a infância, deve-se acompanhar o crescimento auxiliado pelo tratamento medicamentoso com somatropina. Embora a síndrome de Turner não envolva deficiência de hormônio de crescimento, acredita-se que a baixa estatura está relacionada à diminuição da resposta ao hormônio, e que assim, a administração de doses adicionais promova melhora na estatura final – as evidências indicam aumento de aproximadamente 7,22 cm (IC 95%:5,27 a 9,18)<sup>33</sup> . No entanto, a efetividade é variável dependendo de múltiplos fatores, como a altura dos pais, estatura inicial, idade do início e duração do tratamento<sup>10</sup> .  
Até o momento, a idade ideal para início do tratamento com somatotropina ainda não foi estabelecida, mas o início precoce e pelo menos 4 anos antes da puberdade está associado à maior efetividade. Assim, o tratamento pode ser iniciado a partir de dois anos de idade se houver evidência de velocidade de crescimento abaixo do normal ou baixa estatura. O tratamento pode ser iniciado em idades maiores se as epífises ósseas estiverem ainda abertas<sup>9</sup> .  
A puberdade espontânea ocorre apenas em aproximadamente 14% das pacientes com monossomia 45,X e em um terço das que apresentam mosaicismo no cariótipo<sup>3</sup> . Portanto, a maioria das pacientes com síndrome de Turner necessitam de indução de puberdade com terapia de reposição de estrógeno e progesterona para alcançar a telarca, maturação uterina e pico de massa óssea.  
A idade ideal para o início da reposição de hormônios sexuais também ainda não foi estabelecida e os consensos clínicos indicam que a indução de puberdade deve ocorrer por volta dos 11 e 12 anos de idade. Apesar da via transdérmica de reposição de estrógeno ser citada como a preferencial<sup>3,9</sup> , as evidências até o momento são consideradas fracas quanto aos desfechos clínicos se comparada a via oral<sup>9,34,35</sup> .  Adicionalmente, inexistem formulações transdérmicas adequadas de estrógenos para as baixas doses utilizadas na indução puberal da síndrome de Turner, de modo que a via oral deve ser utilizada.  
A dosagem de gonadotrofinas (LH e FSH) deve ser realizada anualmente a partir dos 11 anos de idade e, observando-se níveis elevados, a indução da puberdade deve ser iniciada, com doses progressivas de estrógenos até alcançar a dose de adulto. A introdução de progestágenos deve ocorrer após o primeiro sangramento ou após um período de 2 anos, se isto não ocorrer<sup>9</sup> .

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.1.1. Medicamentos** -->
- Estrogênios conjugados: comprimidos de 0,3 mg e 0,625 mg.  
- Acetato de medroxiprogesterona: comprimidos de 10 mg.  
- Somatropina: pó para solução injetável de 4UI, 12UI, 15UI, 16UI, 18UI, 24UI e 30UI; solução injetável de 4UI, 12UI,  
15UI, 16UI, 18UI, 24UI e 30UI.  
Nota: Na fórmula de conversão, 1 mg de somatropina equivale a 3 UI. Há apresentações comerciais com volumes de diluente diferentes para a mesma dose de hormônio, o que deverá ser observado na prescrição e orientação ao paciente.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.1.2. Esquemas de administração** -->
**Estrogênios conjugados** : 0,3 mg/dia por via oral em dias alternados nos primeiros meses. Após 6 meses, as doses são elevadas para 0,3 mg (1 comprimido) por dia. De 12 a 18 meses de tratamento, a dose deve ser de 0,6 mg (dois comprimidos) por dia. A dose adulta deve ser de 0,6 a 1,2 mg (2 a 4 comprimidos) por dia<sup>36,37</sup> .  
**Medroxiprogesterona** : 5 a 10 mg dos dias 20 a 30 do ciclo mensal<sup>37</sup> .  
**Somatropina** : 0,135-0,15 UI/kg/dia (45 a 50 µg/kg/dia administrados por via subcutânea, à noite, diariamente. Doses de  
0,2 UI/kg/dia (68 µg/kg/dia) podem ser administradas se o potencial de estatura final estiver substancialmente comprometido e em casos de baixa velocidade de crescimento<sup>3,9</sup> .

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.1.3. Critérios de interrupção** -->
O tratamento com somatropina deverá ser interrompido nas seguintes situações<sup>3, 9</sup> :  
- Idade óssea de 13,5 a 14 anos de idade;  
- Velocidade de crescimento inferior a 2 cm/ano.  
A terapêutica com estrogênios e progesterona deve ser mantida na vida adulta após ajuste progressivo da dose, até a idade esperada de menopausa<sup>32</sup> .

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.1.4. Tratamento em populações específicas** -->
Em caso de doença aguda grave (com necessidade de internação e tratamento parenteral ou NPO ou tratamento em UTI), o tratamento com somatropina deverá ser interrompido por 1 a 2 meses ou até que haja recuperação da paciente. Em caso de doença neoplásica maligna, o tratamento com somatropina somente poderá ser iniciado após liberação documentada por oncologista, decorridos 1 ano do tratamento e da remissão completa da doença<sup>38</sup> .  
Em caso de anomalias congênitas que necessitem de correção cirúrgica, o tratamento deverá ser adiado ou interrompido durante o tempo necessário para que as correções sejam realizadas e a paciente se recupere.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **6.2. Benefícios esperados** -->
Os benefícios esperados da terapia com somatropina é o aumento da velocidade de crescimento e da estatura final da paciente com síndrome de Turner.  
A administração de estrógeno e progesterona tem como finalidade a indução da puberdade das pacientes com síndrome  
de Turner que apresentam hipogonadismo, proporcionando a telarca, maturação uterina e aumento da massa óssea.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **7. MONITORAMENTO** -->
O acompanhamento clínico da paciente com síndrome de Turner deve ser realizado a cada 4 a 6 meses, com mensuração de estatura e peso corporal, além do rastreamento das comorbidades mais frequentemente associadas.  
Para afastar a possibilidade de malformações cardíacas é recomendada a realização de um ecocardiograma ao diagnóstico. A ressonância magnética cardíaca deve ser solicitada, assim que for possível, sem a necessidade de anestesia<sup>3,9</sup> . O **Quadro 1** apresenta os exames que a paciente deve realizar para o seguimento clínico.  
**Quadro 1 -** Monitoramento de comorbidades associadas à síndrome de Turner.  
|**Parâmetro**|**Avaliação no diagnóstico**|**Periodicidade após o diagnóstico**|
|---|---|---|
|Pressão arterial|Sim|A cada consulta|
|Função tireoidiana|Sim|Anualmente|
|Ultrassonografia renal|Sim|Não|
|Audiometria|Sim|A cada 3 anos|
|Função hepática|Não|Anualmente após 10 anos de idade|
|Glicemia de jejum e hemoglobina glicada (HbA1C)|Não|Anualmente após 10 anos de idade|
|Dosagem de vitamina D|Não|A cada 2 anos após 10 anos de idade|
|Rastreamento de doença celíaca|Não|A cada 2 anos após 2 anos de idade|
|Densitometria óssea|Não|A cada 5 anos|  
Adaptado de: Gravholt _et al_<sup>8</sup> .  
Durante o tratamento com a somatropina, a velocidade de crescimento deve ser avaliada a cada consulta. Também é recomendada a mensuração anual de IGF-1 (fator de crescimento semelhante à insulina tipo 1 ou somatomedina C), cuja produção é estimulada pelo hormônio do crescimento humano. Os níveis de IGF-1 não devem ser superiores a dois desviospadrão acima da média para a idade, portanto, valores elevados indicam a necessidade de redução da dose. Se os níveis de IGF1 estiverem baixos e a velocidade de crescimento estiver abaixo do esperado, mesmo com a comprovação de adesão adequada ao tratamento, a dose de somatropina pode ser aumentada para 0,2 UI/kg/dia<sup>9</sup> .  
A somatropina é um medicamento seguro com raros eventos adversos. As pacientes com síndrome de Turner em uso de somatropina podem apresentar maior risco de hipertensão craniana, deslizamento da epífise femoral e escoliose<sup>9</sup> .  
A indução puberal deve ser monitorada a cada consulta pela evolução do estádio de Tanner das mamas. O início da telarca ocorre no primeiro ano após o início da indução, e atinge o estágio 4 após 2 a 3 anos<sup>9</sup> .

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
O tratamento da síndrome de Turner deve ser feito mediante abordagem multidisciplinar e especializada, idealmente conduzida em centros de referência em doenças raras ou em serviços de endocrinologia ou ambulatórios de genética. A complexidade da síndrome, a diversidade de manifestações clínicas e a necessidade de acompanhamento ao longo da vida, tornam fundamental que as pessoas com síndrome de Turner sejam atendidas por uma equipe multiprofissional experiente e familiarizada com este tipo de condição congênita, para que ocorra adequada orientação e promoção de qualidade de vida.  
Os serviços especializados ou de referência têm de estar capacitados com equipe multiprofissional que abranja endocrinologista e geneticistas.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com Síndrome de Turner deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio, conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde, via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras. A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS, e se houver necessidade o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **10. REFERÊNCIAS** -->
1.  
- Milbrandt T, Thomas E. Turner syndrome. Pediatr Rev. 2013 Sep;34(9):420-1. doi: 10.1542/pir.34-9-420.  
2. Shankar Kikkeri N, Nagalli S. Turner Syndrome. [Updated 2022 Aug 8]. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2023 Jan-. Disponível em:https://www.ncbi.nlm.nih.gov/books/NBK554621  
3. Shankar RK, Backeljauw PF. Current best practice in the management of Turner syndrome. Ther Adv Endocrinol Metab. 2018 Jan;9(1):33-40. doi: 10.1177/2042018817746291. Epub 2017 Dec 18.  
4. Sybert VP, McCauley E. Turner's syndrome. N Engl J Med. 2004 Sep 16;351(12):1227-38. doi: 10.1056/NEJMra030360.  
5. Barbosa LG, Siviero-Miachon AA, Souza MA, Spinola-Castro AM. Recognition of the Y chromosome in Turner syndrome using peripheral blood or oral mucosa tissue. Ann Pediatr Endocrinol Metab. 2021 Dec;26(4):272-277. doi: 10.6065/apem.2142026.013. Epub 2021 Oct 8.  
6. de Marqui AB, da Silva-Grecco RL, Balarin MA. Prevalência de sequências do Y e de gonadoblastoma em síndrome de Turner [Prevalence of Y-chromosome sequences and gonadoblastoma in Turner syndrome]. Rev Paul Pediatr. 2016 Jan-Mar;34(1):114-21. doi: 10.1016/j.rpped.2015.06.007. Epub 2015 Oct 9.  
7. BRASIL. Ministério da Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas. Brasília; 2023. Disponível em: https://www.gov.br/conitec/pt_br/midias/artigos_publicacoes/diretrizes/diretrizes-metodologicas-elaboracao-dediretrizes-clinicas-2020.pdf  
8. Gravholt CH, Viuff MH, Brun S, Stochholm K, Andersen NH. Turner syndrome: mechanisms and management. Nat Rev Endocrinol. 2019 Oct;15(10):601-614.  
9. Gravholt CH, Andersen NH, Christin-Maitre S, Davis SM, Duijnhouwer A, Gawlik A, Maciel-Guerra AT, GutmarkLittle I, Fleischer K, Hong D, Klein KO, Prakash SK, Shankar RK, Sandberg DE, Sas TCJ, Skakkebæk A, Stochholm K, van der Velden JA; International Turner Syndrome Consensus Group; Backeljauw PF. Clinical practice guidelines for the care of girls and women with Turner syndrome. Eur J Endocrinol. 2024 Jun 5;190(6):G53-G151. doi: 10.1093/ejendo/lvae050.  
10. Barros BA, Moraes SG, Coeli FB, Assumpção JG, De Mello MP, Maciel-Guerra AT, Carvalho AB, Viguetti-Campos N, Vieira TA, Amstalden EM, Andrade JG, Esquiaveto-Aun AM, Marques-de-Faria AP, D'Souza-Li LF, Lemos-Marini SH, Guerra G Jr. OCT4 immunohistochemistry may be necessary to identify the real risk of gonadal tumors in patients with Turner syndrome and Y chromosome sequences. Hum Reprod. 2011  
11. Bispo AV, Burégio-Frota P, Oliveira dos Santos L, Leal GF, Duarte AR, Araújo J, Cavalcante da Silva V, Muniz MT, Liehr T, Santos N. Y chromosome in Turner syndrome: detection of hidden mosaicism and the report of a rare X;Y translocation case. Reprod Fertil Dev. 2014 Oct;26(8):1176-82. doi: 10.1071/RD13207.  
12. Cervantes A, Guevara-Yáñez R, López M, Monroy N, Aguinaga M, Valdez H, Sierra C, Canún S, Guízar J, Navarrete C, Zafra G, Salamanca F, Kofman-Alfaro S. PCR-PRINS-FISH analysis of structurally abnormal sex chromosomes in eight patients with Turner phenotype. Clin Genet. 2001 Nov;60(5):385-92. doi: 10.1034/j.1399-0004.2001.600512.x.  
13. Cortés-Gutiérrez EI, Herrera-Bartolo R, Dávila-Rodríguez MI, Palacios-Saucedo GC, Vargas-Villarreal J, RomeroVillarreal JB. Molecular detection of cryptic Y-chromosomal material in patients with Turner syndrome. Oncol Rep. 2012 Oct;28(4):1205-10. doi: 10.3892/or.2012.1916. Epub 2012 Jul 16.  
14. Patsalis PC, Sismani C, Hadjimarcou MI, Kitsiou-Tzeli S, Tzezou A, Hadjiathanasiou CG, Velissariou V, Lymberatou E, Moschonas NK, Skordis N. Detection and incidence of cryptic Y chromosome sequences in Turner syndrome patients. Clin Genet. 1998 Apr;53(4):249-57. doi: 10.1111/j.1399-0004.1998.tb02691.x.  
15. Wang H, Wang T, Yang N, He Y, Chen L, Hong L, Shao X, Li H, Zhu H, Li H. The clinical analysis of small supernumerary marker chromosomes in 17 children with mos 45,X/46,X,+mar karyotype. Oncol Lett. 2017 Jun;13(6):4385-4389. doi: 10.3892/ol.2017.5965. Epub 2017 Mar 31.  
16. Alvarez-Nava F, Soto M, Sánchez MA, Fernández E, Lanes R. Molecular analysis in Turner syndrome. J Pediatr. 2003 Mar;142(3):336-40. doi: 10.1067/mpd.2003.95.  
17. Barbosa LG, Siviero-Miachon AA, Souza MA, Spinola-Castro AM. Recognition of the Y chromosome in Turner syndrome using peripheral blood or oral mucosa tissue. Ann Pediatr Endocrinol Metab. 2021 Dec;26(4):272-277. doi: 10.6065/apem.2142026.013. Epub 2021 Oct 8.  
18. Bianco B, Lipay M, Guedes A, Oliveira K, Verreschi IT. SRY gene increases the risk of developing gonadoblastoma and/or nontumoral gonadal lesions in Turner syndrome. Int J Gynecol Pathol. 2009 Mar;28(2):197-202. doi: 10.1097/PGP.0b013e318186a825.  
19. Carvalho AB, Lemos-Marini SHV, Guerra-Junior G, Maciel-Guerra AT. Clinical and cytogenetic features of 516 patients with suspected Turner syndrome - a single-center experience. J Pediatr Endocrinol Metab. 2018 Jan 26;31(2):167-173. doi: 10.1515/jpem-2017-0273.  
20. Coto E, Toral JF, Menéndez MJ, Hernando I, Plasencia A, Benavides A, López-Larrea C. PCR-based study of the presence of Y-chromosome sequences in patients with Ullrich-Turner syndrome. Am J Med Genet. 1995 Jul 3;57(3):393-6. doi: 10.1002/ajmg.1320570305.  
21. Damiani D, Guedes DR, Fellous M, Barbaux S, McElreavey K, Kalil J, Goldberg AC, Moreira-Filho CA, Barbosa A, Della Manna T, Dichtchekenian V, Setian N. Ullrich-Turner syndrome: relevance of searching for Y chromosome fragments. J Pediatr Endocrinol Metab. 1999 Nov-Dec;12(6):827-31. doi: 10.1515/jpem.1999.12.6.827.  
22. Ferrão L, Lopes ML, Limbert C, Marques B, Boieiro F, Silva M, Marques R, Lavinha J, Mota A, Gonçalves J. Pesquisa de sequências do cromossoma Y em indivíduos com síndroma de Turner [Screening for Y chromosome sequences in patients with Turner syndrome]. Acta Med Port. 2002 Mar-Apr;15(2):89-100.  
23. Gravholt CH, Fedder J, Naeraa RW, Müller J. Occurrence of gonadoblastoma in females with Turner syndrome and Y chromosome material: a population study. J Clin Endocrinol Metab. 2000 Sep;85(9):3199-202. doi: 10.1210/jcem.85.9.6800.  
24. Jakubiczka S, Mohnike K, Wieacker P. Turner-Syndrom: Suche nach zytogenetisch nicht nachweisbaren Zellinien mit V-Chromosom durch molekulargenetische Methoden. Geburtsh Frauenheilk. 1998; 58: 69-72.  
25. López M, Canto P, Aguinaga M, Torres L, Cervantes A, Alfaro G, Méndez JP, Kofman-Alfaro S. Frequency of Y chromosomal material in Mexican patients with Ullrich-Turner syndrome. Am J Med Genet. 1998 Mar 5;76(2):120-4. doi: 10.1002/(sici)1096-8628(19980305)76:2<120::aid-ajmg3>3.0.co;2-x.  
26. Mancilla EE, Poggi H, Repetto G, Rumié H, García H, Ugarte F, Hidalgo S, Jara A, Muzzo S, Panteón E, Torrealba I, Foradori A, Cattani A. Y chromosome sequences in Turner's syndrome: association with virilization and gonadoblastoma. J Pediatr Endocrinol Metab. 2003 Oct-Nov;16(8):1157-63. doi: 10.1515/jpem.2003.16.8.1157.  
27. Mendes JR, Strufaldi MW, Delcelo R, Moisés RC, Vieira JG, Kasamatsu TS, Galera MF, Andrade JA, Verreschi IT. Y-chromosome identification by PCR and gonadal histopathology in Turner's syndrome without overt Y-mosaicism. Clin Endocrinol (Oxf). 1999 Jan;50(1):19-26. doi: 10.1046/j.1365-2265.1999.00607.x.  
28. Nishi MY, Domenice S, Medeiros MA, Mendonca BB, Billerbeck AE. Detection of Y-specific sequences in 122 patients with Turner syndrome: nested PCR is not a reliable method. Am J Med Genet. 2002 Feb 1;107(4):299-305. doi: 10.1002/ajmg.10168. Erratum in: Am J Med Genet. 2002 Nov 15;113(1):116-7.  
29. Silva-Grecco RL, Trovó-Marqui AB, Sousa TA, Croce LD, Balarin MA. Identification of Y-Chromosome Sequences in Turner Syndrome. Indian J Pediatr. 2016 May;83(5):405-9. doi: 10.1007/s12098-015-1929-6. Epub 2015 Dec 4.  
30. World Health Organization. The WHO Child Growth Standards [Internet]. WHO; 2016. Disponível em: <u>http://www.who.int/childgrowth/standards/en/.</u>  
31. Centers for Disease Control and Prevention. CDC Growth Charts[Internet]. Atlanta: CDC; 2010. Disponível em <u>http://www.cdc.gov/growthcharts/cdc_charts.htm.</u>  
32. Oliveira RM, Verreschi IT, Lipay MV, Eça LP, Guedes AD, Bianco B. Y chromosome in Turner syndrome: review of the literature. Sao Paulo Med J. 2009 Nov;127(6):373-8. doi: 10.1590/s1516-31802009000600010. PMID: 20512293.  
33. Li P, Cheng F, Xiu L. Height outcome of the recombinant human growth hormone treatment in Turner syndrome: a meta-analysis. Endocr Connect. 2018 Apr;7(4):573-583. doi: 10.1530/EC-18-0115. Epub 2018 Mar 26.  
34. Gravholt CH, Viuff M, Just J, Sandahl K, Brun S, van der Velden J, Andersen NH, Skakkebaek A. The Changing Face of Turner Syndrome. Endocr Rev. 2023 Jan 12;44(1):33-69. doi: 10.1210/endrev/bnac016.  
35. Zaiem F, Alahdab F, Al Nofal A, Murad MH, Javed A. Oral Versus Transdermal Estrogen in Turner Syndrome: A Systematic Review and Meta-Analysis. Endocr Pract. 2017 Apr 2;23(4):408-421. doi: 10.4158/EP161622.OR. Epub 2017 Jan 17.  
36. Gallicchio CT, Alves STF, Guimaraes MM. Hormone Replacement Therapy in Adolecents with Turner Syndrome. J Pediatri Endocrinol. 2016; 1(2): 1012.  
37. Klein KO, Rosenfield RL, Santen RJ, Gawlik AM, Backeljauw PF, Gravholt CH, Sas TCJ, Mauras N. Estrogen Replacement in Turner Syndrome: Literature Review and Practical Considerations. J Clin Endocrinol Metab. 2018 May 1;103(5):1790-1803. doi: 10.1210/jc.2017-02183.  
38. Grimberg A, DiVall SA, Polychronakos C, Allen DB, Cohen LE, Quintos JB, Rossi WC, Feudtner C, Murad MH; Drug and Therapeutics Committee and Ethics Committee of the Pediatric Endocrine Society. Guidelines for Growth Hormone and Insulin-Like Growth Factor-I Treatment in Children and Adolescents: Growth Hormone Deficiency, Idiopathic Short Stature, and Primary Insulin-Like Growth Factor-I Deficiency. Horm Res Paediatr. 2016;86(6):361-397. doi: 10.1159/000452150. Epub 2016 Nov 25. PMID: 27884013.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE ESTROGÊNIO CONJUGADO, MEDROXIPROGESTERONA E SOMATROPINA** -->
Eu, _____________________________________________________________________________________ (nome  
paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao  
uso de **estrogênios conjugados, medroxiprogesterona e somatropina** , indicados para o tratamento de síndrome de Turner.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
___________________________________________________________________________________________ (nome do(a)  
médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que os medicamentos que passo a receber pode trazer os seguintes benefícios:  
- Estrogênios conjugados e medroxiprogesterona: promover a puberdade e repor a deficiência desses hormônios.  
- Somatropina: melhorar o crescimento e a altura final.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Estrogênios conjugados e medroxiprogesterona: medicamentos classificados na gestação como fator de risco X (seu uso  
é contraindicado para gestantes ou para mulheres planejando engravidar);  
- Somatropina: medicamento classificado na gestação como categoria C quando utilizado no primeiro e segundo trimestres  
- de gestação (estudos em animais mostraram anormalidades nos descendentes, mas não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- Eventos adversos dos estrogênios conjugados: coceira, dor na barriga, gases intestinais, candidíase vaginal, sangramento  
- urinário e uterino; inflamação na vagina, fraqueza; cãibras nas pernas  
- Eventos adversos da medroxiprogesterona: sangramento uterino, corrimento vaginal, dor de cabeça, náusea, depressão,  
- insônia, nervosismo, tontura, alopecia, acne, urticária, prurido, aumento de peso, fadiga, dor e sensibilidade nas mamas, entre outros.  
- Eventos adversos da somatropina: reações no local da injeção, como dor, inchaço e inflamação. Algumas reações mais  
- raras incluem dor de cabeça, dor nos músculos, fraqueza, aumento da glicose no sangue, resistência à insulina, dor no quadril e/ou nos joelhos, leucemia, hipertireoidismo;  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Estrogênios conjugados  
- (    ) Medroxiprogesterona  
- (    ) Somatropina  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Síndrome de Turner contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos da especialidade endocrinologia e genética.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração deste documento foi iniciada em 23 de junho de 2023 com a realização de uma reunião de escopo, a qual definiu as perguntas de pesquisa desse documento. Uma segunda reunião foi realizada em 31 de agosto de 2023 para validação das perguntas de pesquisa priorizadas nesse PCDT. Decidiu-se pela atualização das evidências do tratamento hormonal com estrogênios conjugados, progesterona e somatropina. Foi incluída uma nova pergunta sobre a ampliação da pesquisa citogenética de material de cromossomo Y com exames adicionais, devido ao risco de tumores gonadais.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pelo NATS Cochrane Brasil.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A.** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente a|lgum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|  
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou prejudicada<br>com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|---|---|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetad<br>atividade na elaboração ou revisão da diretriz?|os pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e que<br>deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua<br>objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas  
A proposta de atualização do PCDT da Síndrome de Turner foi apresentada na 118ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 17 de setembro de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (SECTICS) e Secretaria de Atenção Especializada em Saúde (SAES). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 135ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
Consulta pública  
A Consulta Pública nº 90/2024, referente ao Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Turner, foi realizada no período de 22 de novembro de 2024 a 11 de dezembro de 2024. Foi recebida uma (01) contribuição que pode ser verificada em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/CP_CONITEC_090_2024_Protocolo_ Clnico_e.pdf

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **3. Busca da evidência e recomendações** -->
Foi estabelecido que, para as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS para Síndrome de Turner, não seriam objeto de questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso. Desse modo, as evidências em relação às seguintes perguntas preconizadas na reunião de escopo foram atualizadas a fim de subsidiar a redação do PCDT:  
- Qual a melhor idade de início da administração de somatropina, método de acompanhamento e quando interromper seu  
uso?  
- Qual a melhor idade de início e posologia ideal da reposição hormonal com estrógeno e progestágenos no tratamento  
- da Síndrome de Turner?  
- A utilização de estrógenos transdérmicos é mais efetiva e/ou segura que o uso de estrógeno oral?  
- Qual o melhor exame para detecção de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner?  
- Em que casos deve-se solicitar exames adicionais ao cariótipo para afastar uma possível sequência oculta de  
- cromossomo Y?  
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações de outras diretrizes – quando identificadas, e um resumo das evidências.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **QUESTÃO 1: Qual a melhor idade de início da administração de somatropina, método de acompanhamento e quando interromper seu uso?** -->
**Recomendação:** O tratamento pode ser iniciado a partir de dois anos de idade se houver evidência de velocidade de crescimento abaixo do normal ou baixa estatura. O tratamento pode ser iniciado em idades maiores se as epífises ósseas estiverem ainda abertas<sup>1</sup> . Durante o tratamento com a somatropina a velocidade de crescimento deve ser avaliada a cada consulta. É recomendada a mensuração anual de IGF-1 (fator de crescimento semelhante à insulina tipo 1 ou somatomedina.  
O tratamento com somatropina deverá ser interrompido nas seguintes situações:  Idade óssea de 13,5 a 14 anos de idade; velocidade de crescimento inferior a 2 cm/ano. (Recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com síndrome de Turner  
**Intervenção** : somatropina em idade precoce  
**Comparador** : somatropina em idade tardia  
**Desfechos** : estatura final  
Métodos e resultados da busca:  
Foi realizada uma busca sistematizada nas bases Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) para atualizar as evidências acerca da questão. A busca foi realizada em 12 de julho de 2023. As estratégias de busca para cada base estão descritas no **Quadro B** .  
**Quadro B.** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso de somatropina na síndrome de Turner.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|PubMed|#1 "Turner Syndrome"[Mesh] OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-<br>Turner) OR (Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR<br>(Gonadal Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis)<br>OR (Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 "Growth Hormone"[Mesh] OR (Pituitary Growth Hormone) OR Somatotropin OR<br>(Growth Hormone, Pituitary) OR (Growth Hormone, Recombinant) OR (Pituitary Growth<br>Hormones, Recombinant) OR (Recombinant Pituitary Growth Hormones) OR (Recombinant<br>Growth Hormones) OR (Growth Hormones, Recombinant) OR (Recombinant Growth<br>Hormone) OR (Somatotropin*, Recombinant) OR (Recombinant Somatotropin*) OR<br>(Growth Hormones Pituitary, Recombinant)<br>#3 #1 AND #2|261|
|Embase|#1 'turner syndrome'/exp OR '45, x syndrome' OR 'bonnevie ullrich turner syndrome' OR<br>'bonnevie ullrich state' OR 'bonnevie ullrich status' OR 'bonnevie-ullrich syndrome' OR<br>'bonneville ullrich turner syndrome' OR 'bournevie ullhrich turner syndrome' OR<br>'shereshevsky turner syndrome' OR 'turner albright syndrome' OR 'turner ullrich syndrome'<br>OR 'turner disease' OR 'turner stigma' OR 'turner syndrome' OR 'turner`s syndrome' OR<br>'turners syndrome' OR 'ullrich turner syndrome' OR 'ullrich syndrome' OR 'x-chromosome<br>monosomy' OR 'xo turner syndrome' OR 'xo syndrome' OR 'karyotype 45, x syndrome' OR<br>'karyotype 45, xo syndrome' OR 'syndrome, turner' OR 'xo male'<br>#2 'growth hormone'/exp OR 'gh' OR 'antuitrin t' OR 'bovine growth hormone' OR<br>'gerohormetten' OR 'grorm' OR 'growth hormone' OR 'growth hormone fraction' OR 'growth<br>hormone treatment' OR 'growth hormone, hypophysis' OR 'hormone, growth' OR 'hypophysis<br>growth hormone' OR 'immunoreactive growth hormone' OR 'leutrophin' OR 'nanormon' OR<br>'ovine growth hormone' OR 'phyol' OR 'phyon' OR 'pituitary growth hormone' OR 'rat growth<br>hormone' OR 'sf' OR 'somacton' OR 'somantin' OR 'somatotrofin' OR 'somatotrope hormone'<br>OR 'somatotrophic hormone' OR 'somatotrophin' OR 'somatotropic hormone' OR<br>'somatotropin' OR 'somatropic hormone' OR 'st' OR 'sth'<br>#3 #1 AND #2<br>#3 AND (2016:py OR 2017:py OR 2018:py OR 2019:py OR 2020:py OR 2021:py OR|434|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número**<br>**de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||2022:py OR 2023:py)<br>Limit:  2016 - 2023<br>#4 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Libray|#1 (Turner Syndrome) OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-Turner) OR<br>(Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR (Gonadal<br>Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis) OR<br>(Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 (Growth Hormone) OR (Pituitary Growth Hormone) OR Somatotropin OR (Growth<br>Hormone, Pituitary) OR (Growth Hormone, Recombinant) OR (Pituitary Growth Hormones,<br>Recombinant) OR (Recombinant Pituitary Growth Hormones) OR (Recombinant Growth<br>Hormones) OR (Growth Hormones, Recombinant) OR (Recombinant Growth Hormone) OR<br>(Somatotropin*, Recombinant) OR (Recombinant Somatotropin*) OR (Growth Hormones<br>Pituitary, Recombinant)<br>#3 #1 AND #2<br>Limit:  2016 - 2023|18|
|LILACS|#1 MH:"Síndrome de Turner" OR (Síndrome de Turner) OR (Turner Syndrome) OR<br>(Síndrome de Turner) OR (Disgenesia Gonadal 45 X) OR (Disgenesia Gonadal XO) OR<br>(Síndrome<br>de<br>Bonnevie-Ullrich)<br>OR<br>MH:C12.050.351.875.253.309.872$ OR<br>MH:C12.050.351.875.253.795.750$ OR<br>MH:C12.200.706.316.309.872$ OR<br>MH:C12.200.706.316.795.750$ OR<br>MH:C12.800.316.309.872$ OR<br>MH:C12.800.316.795.750$ OR MH:C14.240.400.980$ OR MH:C14.280.400.980$ OR|14|
||MH:C16.131.240.400.970$ OR<br>MH:C16.131.260.830.835.750$ OR<br>MH:C16.131.939.316.309.872$ OR<br>MH:C16.131.939.316.795.750$ OR<br>MH:C16.320.180.830.835.750$ OR<br>MH:C19.391.119.309.872$ OR<br>MH:C19.391.119.795.750$ #2 MH:"Hormônio do Crescimento" OR (Hormônio do Crescimento) OR (Growth Hormone)<br>OR (Hormona del Crecimiento) OR (GH (Hormônio do Crescimento)) OR (Hormônio<br>Hipofisário do Crescimento) OR (Hormônio do Crescimento (GH)) OR (Hormônio do<br>Crescimento Recombinante) OR (Somatotrofina) OR (Somatotropina) OR (Somatotropina<br>Recombinante) OR MH:D06.472.699.631.525.425$ OR MH:D12.644.548.691.525.425$ #3 #1 AND #2<br>Limit:  2016 - 2023||  
Dois avaliadores independentes realizaram a seleção dos estudos e extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com síndrome de Turner  
- (b) Tipo de intervenção  
Somatropina em qualquer dose  
- (c) Tipos de estudos  
Ensaios clínicos randomizados (ECR), estudos observacionais controlados.  
- (d) Desfechos  
Estatura final  
- (e) Idioma  
Sem restrição de idioma  
Resultados da busca  
Foram recuperadas 727 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 6 textos completos<sup>3-8</sup> , sendo três excluídos por ausência de comparação de interesse. Para auxiliar na tomada de decisão, 3 estudos foram incluídos<sup>6-8</sup> . O processo de seleção é detalhado na **Figura A** .  
**Figura A** . Fluxograma de seleção dos estudos incluídos para avaliação da idade de início do tratamento com somatropina  
<!-- Start of picture text -->
Referências indexadas obtidas na<br>busca em bases de dados<br>(n = 727)<br>Duplicatas removidas<br>(n = 8)<br>Resumos avaliados  Artigos excluídos<br>(n = 719)  (n = 713)<br>Artigos completos obtidos  Artigos excluídos com<br>para avaliação  razão<br>(n = 6)  (n = 3)<br>Artigos incluídos na<br>síntese qualitativa<br>(n = 3)<br>Elegibilidade<br>Identificação<br>Avaliação<br>Incluídos<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: Análise e apresentação dos resultados -->
Todos os artigos incluídos correspondem a estudos de coorte controlados. A avaliação de risco de viés foi realizada por meio da ferramenta elaborada pela _Joanna Briggs Institute Critical Appraisal Tools_<sup>9</sup> . Os critérios avaliam os seguintes vieses: viés de seleção, viés de mensuração, viés de confusão e viés de perdas. Cada critério foi classificado como sim, não, incerto ou não se aplica.  
Os desfechos dos estudos foram descritos por meio de variáveis contínuas, e apresentados por meio de médias e desvio padrão, e diferença de médias entre grupos com IC de 95%.  
Resumo das evidências:  
Dois estudos incluídos eram coortes retrospectivas. Irzyniec e col.<sup>6</sup> realizaram um estudo na Polônia com 33 pacientes com síndrome de Turner tratadas com somatropina na infância comparadas a 124 pacientes que não receberam o tratamento.  
As 33 que receberam a terapia foram divididas em idade de início do tratamento menor ou maior de 12 anos (n=12 e n=21, respectivamente). Não foram verificadas diferenças na idade adulta entre os dois grupos (147,1 (5,9) cm vs. 149,0 (6,9) cm, p=0,54).  
O estudo de Kriström e col.<sup>7</sup> , realizado na Suécia, avaliou 132 crianças pré-púberes que receberam tratamento com somatropina e foram classificadas como menor e maior de 9 anos de idade no que se refere ao início do tratamento, que foi  
administrado em duas doses 33 ou 67 µg/kg/dia. Todos os grupos alcançaram a estatura final dentro da normalidade. As pacientes que iniciaram o tratamento com menor idade e receberam a maior dose do hormônio apresentaram maior ganho de estatura prépuberal, permitindo que a reposição com estrógeno com idade mais adequada, favorecendo a transição para a idade adulta.  
O único estudo coorte controlado prospectivo foi realizado por Quigley e col.<sup>8</sup> que é uma extensão observacional para avaliar a estatura final, na idade adulta das participantes do ensaio clínico randomizado _Toddler Turner Study_<sup>5</sup> . O estudo avaliou um grupo que recebeu o hormônio de crescimento antes dos 4 anos de idade e um grupo controle que iniciou o tratamento com aproximadamente 6 anos de idade. Foi observado que o grupo tratado precocemente apresentou maiores estaturas em todas as idades de crescimento, mas não houve diferença estatisticamente significante na estatura final da idade adulta após a puberdade - 151,7 ± 8,2 cm vs. 150,9 ± 6,2 cm, respectivamente. Os autores apresentam a hipótese que isso pode ter ocorrido devido a maiores períodos sem tratamento observados no grupo de início precoce.  
Não foi localizada nova evidência sobre o monitoramento e critérios de interrupção do tratamento com somatropina. Os três estudos descritos avaliaram a idade de início do tratamento e não verificaram diferenças entre o início precoce ou não na estatura final. No entanto, a evidência é fraca devido ao pequeno número de estudos e amostra limitada. O consenso de especialistas da síndrome de Turner de 2024<sup>10</sup> refere ser ainda incerta a melhor idade de início de tratamento, e recomenda que este pode ser iniciado a partir dos dois anos de idade se houver evidência de velocidade de crescimento abaixo do normal ou baixa estatura. O tratamento pode ser iniciado em idades maiores se as epífises ósseas estiverem ainda abertas<sup>10</sup> .  
Um estudo foi considerado com moderado risco de viés<sup>6</sup> devido ao não relato de possíveis vieses de confusão e não relato de perdas. Os outros dois foram avaliados como baixo risco de viés<sup>7,8</sup> .  
A avaliação completa do risco de viés é apresentada no **Quadro C** .  
**Quadro C** : Avaliação de risco de viés dos estudos incluídos sobre o uso somatropina na síndrome de Turner.  
|**Estudo**|**1**|**2**|**3**<br>**4**<br>**5**|**6**<br>**7**<br>**8**<br>**9**|**10**<br>**11**|
|---|---|---|---|---|---|
|Irzynie 2019||||||
|Kriström 2023||||||
|Quigley 2021||||||  
Legenda:  
|1.Os dois grupos são semelhantes e recrutados da mesma população?|7.Os desfechos foram avaliados de maneira válida?|
|---|---|
|2.A exposição foi mensurada de maneira semelhante?|8.O seguimento foi suficiente para ocorrer o desfecho?|
|3.A exposição foi mensurada de maneira válida e confiável?|9.O seguimento foi completo, as perdas descritas e exploradas?|
|4.Os fatores de confusão foram identificados?|10.Houve estratégias para avaliar as perdas de seguimento?|
|5.A estratégia para lidar com fatores de confusão foram descritas?|11.Foi utilizado método estatístico adequado?|  
6.Os grupos não apresentavam o desfecho no início do estudo?

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **QUESTÃO 2: Qual a melhor idade de início e posologia ideal da reposição hormonal com estrógeno e progestágenos no tratamento da Síndrome de Turner?** -->
**Recomendação:** Essa recomendação já constava no PCDT anterior e foi mantida.  
Questão estruturada (PICO) **População** : Pacientes com síndrome de Turner **Intervenção** : Estrógeno e progestágenos **Comparador** : Cuidado usual  
**Desfechos** : Indução adequada de puberdade e desenvolvimento uterino

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: Métodos e resultados da busca: -->
Foi realizada uma busca sistematizada nas bases Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) para atualizar as evidências acerca da questão. A busca foi realizada em 12 de julho de 2023. As estratégias de busca para cada base estão descritas no **Quadro D** .  
**Quadro D** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso de estrógeno e progestágenos na síndrome de Turner  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|PubMed|#1 "Turner Syndrome"[Mesh] OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-<br>Turner) OR (Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR<br>(Gonadal Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis)<br>OR (Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 "Estrogens"[Mesh] OR (Estrogenic Compounds) OR (Compounds, Estrogenic) OR<br>(Estrogenic Agents) OR (Agents, Estrogenic) OR Estrogen OR (Estrogen Receptor Agonists)<br>OR (Agonists, Estrogen Receptor) OR (Receptor Agonists, Estrogen) OR (Estrogen Effect)<br>OR (Estrogenic Effect*) OR (Effects, Estrogenic) OR (Estrogen Effects) OR (Effects,<br>Estrogen)<br>#3 "Progestins"[Mesh] OR (Progestagenic Agent) OR (Agent, Progestagenic) OR<br>Progestagen OR (Progestational Agent) OR (Agent, Progestational) OR (Progestational<br>Compound) OR (Compound, Progestational) OR Progestogen OR (Progestational Hormone)<br>OR (Hormone, Progestational) OR Gestagens OR Progestagens OR (Progestational<br>Hormones) OR Progestogens OR (Progestational Agents) OR (Progestational Compounds)<br>OR (Progestagenic Agents) OR (Gestagenic Agents) OR Progestin OR Gestagen OR<br>(Gestagenic Agent) OR (Agent, Gestagenic) OR (Progestin Effect) OR (Effect, Progestin) OR<br>(Progestogen Effect) OR (Effect, Progestogen) OR (Gestagenic Effects) OR (Effects,<br>Gestagenic) OR (Gestagen Effect) OR (Effect, Gestagen) OR (Gestagen Effects) OR (Effects,<br>Gestagen) OR (Gestagenic Effect) OR (Effect, Gestagenic) OR (Progestin Effects) OR<br>(Effects, Progestin) OR (Progestogen Effects) OR (Effects, Progestogen)<br>#4  #1 AND #2 AND #3<br>Limit:  2016 - 2023<br>Filters applied: from 2016 - 2023.|21|
|Embase|#1 'turner syndrome'/exp OR '45, x syndrome' OR 'bonnevie ullrich turner syndrome' OR<br>'bonnevie ullrich state' OR 'bonnevie ullrich status' OR 'bonnevie-ullrich syndrome' OR|86|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||'bonneville ullrich turner syndrome' OR 'bournevie ullhrich turner syndrome' OR<br>'shereshevsky turner syndrome' OR 'turner albright syndrome' OR 'turner ullrich syndrome'<br>OR 'turner disease' OR 'turner stigma' OR 'turner syndrome' OR 'turner`s syndrome' OR<br>'turners syndrome' OR 'ullrich turner syndrome' OR 'ullrich syndrome' OR 'x-chromosome<br>monosomy' OR 'xo turner syndrome' OR 'xo syndrome' OR 'karyotype 45, x syndrome' OR<br>'karyotype 45, xo syndrome' OR 'syndrome, turner' OR 'xo male'<br>#2 'estrogen'/exp OR 'alpha estrogen' OR 'alpha oestrogen' OR 'beta estrogen' OR 'beta<br>oestrogen' OR 'estrogen' OR 'estrogen uptake' OR 'estrogene' OR 'estrogenic agent' OR<br>'estrogenic hormone' OR 'estrogenic steroids, alkylated' OR 'estrogens' OR 'estrogens, non<br>steroidal' OR 'estrogens, non-steroidal' OR 'kober chromogen' OR 'oestrogen' OR 'oestrogen<br>uptake' OR 'oestrogene' OR 'oestrogenic agent' OR 'oestrogenic hormone' OR 'oestrogenic<br>steroids, alkylated' OR 'oestrogens' OR 'oestrogens, non steroidal' OR 'oestrogens, non-<br>steroidal'<br>#3 'gestagen'/exp OR 'gestagen' OR 'gestogen' OR 'progestagen' OR 'progestational activity'<br>OR 'progestational agent' OR 'progestational drug' OR 'progestational hormones' OR<br>'progestational hormones, synthetic' OR 'progestative agent' OR 'progestative drug' OR<br>'progestin' OR 'progestine' OR 'progestins' OR 'progestogen'<br>#4 #1 AND #2 AND #3<br>#4 AND (2016:py OR 2017:py OR 2018:py OR 2019:py OR 2020:py OR 2021:py OR<br>2022:py OR 2023:py)<br>Limit:  2016 - 2023<br>#4 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim) =||
|Cochrane<br>Libray|#1 (Turner Syndrome) OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-Turner) OR<br>(Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR (Gonadal<br>Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis) OR<br>(Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 Estrogens OR (Estrogenic Compounds) OR (Compounds, Estrogenic) OR (Estrogenic<br>Agents) OR (Agents, Estrogenic) OR Estrogen OR (Estrogen Receptor Agonists) OR<br>(Agonists, Estrogen Receptor) OR (Receptor Agonists, Estrogen) OR (Estrogen Effect) OR<br>(Estrogenic Effect*) OR (Effects, Estrogenic) OR (Estrogen Effects) OR (Effects, Estrogen)|8|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#3 Progestins OR (Progestagenic Agent) OR (Agent, Progestagenic) OR Progestagen OR<br>(Progestational Agent) OR (Agent, Progestational) OR (Progestational Compound) OR<br>(Compound, Progestational) OR Progestogen OR (Progestational Hormone) OR (Hormone,<br>Progestational) OR Gestagens OR Progestagens OR (Progestational Hormones) OR<br>Progestogens OR (Progestational Agents) OR (Progestational Compounds) OR<br>(Progestagenic Agents) OR (Gestagenic Agents) OR Progestin OR Gestagen OR (Gestagenic<br>Agent) OR (Agent, Gestagenic) OR (Progestin Effect) OR (Effect, Progestin) OR<br>(Progestogen Effect) OR (Effect, Progestogen) OR (Gestagenic Effects) OR (Effects,<br>Gestagenic) OR (Gestagen Effect) OR (Effect, Gestagen) OR (Gestagen Effects) OR (Effects,<br>Gestagen) OR (Gestagenic Effect) OR (Effect, Gestagenic) OR (Progestin Effects) OR<br>(Effects, Progestin) OR (Progestogen Effects) OR (Effects, Progestogen)<br>#4  #1 AND #2 AND #3 = 8<br>Limit:  2016 - 2023<br>with Cochrane Library publication date from Jan 2016 to Dec 2023||
|LILACS|#1 MH:"Síndrome de Turner" OR (Síndrome de Turner) OR (Turner Syndrome) OR<br>(Síndrome de Turner) OR (Disgenesia Gonadal 45 X) OR (Disgenesia Gonadal XO) OR<br>(Síndrome<br>de<br>Bonnevie-Ullrich)<br>OR<br>MH:C12.050.351.875.253.309.872$ OR<br>MH:C12.050.351.875.253.795.750$ OR<br>MH:C12.200.706.316.309.872$ OR<br>MH:C12.200.706.316.795.750$ OR<br>MH:C12.800.316.309.872$ OR<br>MH:C12.800.316.795.750$ OR MH:C14.240.400.980$ OR MH:C14.280.400.980$ OR<br>MH:C16.131.240.400.970$ OR<br>MH:C16.131.260.830.835.750$ OR<br>MH:C16.131.939.316.309.872$ OR<br>MH:C16.131.939.316.795.750$ OR<br>MH:C16.320.180.830.835.750$ OR<br>MH:C19.391.119.309.872$ OR<br>MH:C19.391.119.795.750$ #2  MH:Estrogênios OR Estrogênios OR Estrogens OR Estrógenos OR (Efeito Estrogênio)<br>OR Estrogênio OR Estrógenos OR Mh:D27.505.696.399.472.277$ #3 MH:Progestinas OR Progestins OR Progestinas OR (Agente Progestacional) OR (Agentes<br>Progestacionais) OR (Composto Progestacional) OR (Compostos Progestacionais) OR<br>(Efeito Progestina) OR (Efeito da Progestinas) OR (Efeito das Progestinas) OR (Efeito de<br>Progestina) OR (Efeitos das Progestinas) OR Gestagênico OR Gestagênicos OR Gestágeno<br>OR Gestágenos OR (Hormônio Progestacional) OR (Hormônios Progestacionais) OR<br>Progestagênico OR Progestagênicos OR Progestina OR Progestágeno OR Progestágenos OR<br>Progestógeno OR Progestógenos<br>#3 #1 AND #2 AND #3  = 3<br>Limit:  2016 - 2023|2|  
Dois avaliadores independentes realizaram a seleção dos estudos e a extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes Pacientes com síndrome de Turner (b) Tipo de intervenção Estrógeno e progestágenos para indução puberal comparada a cuidado usual. (c) Tipos de estudos Ensaios clínicos randomizados (ECR), estudos observacionais controlados. (d) Desfechos Indução adequada de puberdade e desenvolvimento uterino (e) Idioma Sem restrição de idioma Resultados da busca  
Foram recuperadas 117 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Nenhuma referência preencheu os critérios de elegibilidade. O processo de seleção é detalhado na **Figura B** .  
**Figura B** . Fluxograma de seleção dos estudos incluídos para avaliação da idade de início do tratamento com estrógeno e progesterona.  
<!-- Start of picture text -->
Referéncias indexadas obtidasna<br>busca<br>em basesdedados<br>(n= 117)<br>Duplicatasremovidas<br>(n=1)<br>3<br>: Resumos avaliados Artigos excluidos<br>: (n= 116) (n= 116)<br><t<br>Artigoscompletos obtidos<br>para avaliac3o<br>(n=0)<br><!-- End of picture text -->  
**QUESTÃO 3: A utilização de estrógenos transdérmicos é mais efetiva e/ou segura que o uso de estrógeno oral? Recomendação:** Não foram identificadas novas evidências que subsidiassem uma recomendação.  
A estrutura PICO para esta pergunta foi: **População** : Pacientes com síndrome de Turner **Intervenção** : estrógenos transdérmicos **Comparador** : estrógeno via oral **Desfechos** : indução puberal e segurança Métodos e resultados da busca:  
Foi realizada uma busca sistematizada nas bases Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) para atualizar as evidências acerca da questão. A busca foi realizada em 12 de julho de 2023. As estratégias de busca para cada base estão descritas no **Quadro E** .  
**Quadro E** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o uso de estrógenos transdérmicos ou orais na síndrome de Turner.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|PubMed|#1 "Turner Syndrome"[Mesh] OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-<br>Turner) OR (Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome)<br>OR (Gonadal Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal<br>Dysgenesis) OR (Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich<br>Syndrome) OR (Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 "Estrogens"[Mesh] OR (Estrogenic Compounds) OR (Compounds, Estrogenic) OR<br>(Estrogenic Agents) OR (Agents, Estrogenic) OR Estrogen OR (Estrogen Receptor Agonists)<br>OR (Agonists, Estrogen Receptor) OR (Receptor Agonists, Estrogen) OR (Estrogen Effect)<br>OR (Estrogenic Effect*) OR (Effects, Estrogenic) OR (Estrogen Effects) OR (Effects,<br>Estrogen)<br>#3 "Transdermal Patch"[Mesh] OR (Patch*, Transdermal) OR (Transdermal Patch*) OR<br>"Administration, Oral"[Mesh] OR (Drug Administration*, Oral) OR (Oral Drug<br>Administration*)<br>OR<br>(Oral<br>Administration*)<br>OR<br>(Administrations,<br>Oral)<br>OR<br>(Administration*, Oral Drug)<br>#4  #1 AND #2 AND #3<br>_Filters applied: Clinical Trial, Controlled Clinical Trial, Meta-Analysis, Randomized_<br>_Controlled Trial, Systematic Review._|29|
|Embase|#1 'turner syndrome'/exp OR '45, x syndrome' OR 'bonnevie ullrich turner syndrome' OR<br>'bonnevie ullrich state' OR 'bonnevie ullrich status' OR 'bonnevie-ullrich syndrome' OR<br>'bonneville ullrich turner syndrome' OR 'bournevie ullhrich turner syndrome' OR<br>'shereshevsky turner syndrome' OR 'turner albright syndrome' OR 'turner ullrich syndrome'<br>OR 'turner disease' OR 'turner stigma' OR 'turner syndrome' OR 'turner`s syndrome' OR<br>'turners syndrome' OR 'ullrich turner syndrome' OR 'ullrich syndrome' OR 'x-chromosome<br>monosomy' OR 'xo turner syndrome' OR 'xo syndrome' OR 'karyotype 45, x syndrome' OR|77|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||'karyotype 45, xo syndrome' OR 'syndrome, turner' OR 'xo male'<br>#2 'estrogen'/exp OR 'alpha estrogen' OR 'alpha oestrogen' OR 'beta estrogen' OR 'beta<br>oestrogen' OR 'estrogen' OR 'estrogen uptake' OR 'estrogene' OR 'estrogenic agent' OR<br>'estrogenic hormone' OR 'estrogenic steroids, alkylated' OR 'estrogens' OR 'estrogens, non<br>steroidal' OR 'estrogens, non-steroidal' OR 'kober chromogen' OR 'oestrogen' OR 'oestrogen<br>uptake' OR 'oestrogene' OR 'oestrogenic agent' OR 'oestrogenic hormone' OR 'oestrogenic<br>steroids, alkylated' OR 'oestrogens' OR 'oestrogens, non steroidal' OR 'oestrogens, non-<br>steroidal'<br>#3 'transdermal patch'/exp OR 'cataprestts' OR 'epiture easytouch' OR 'insupatch' OR<br>'macroflux' OR 'microcor' OR 'microhyala' OR 'tdds patch' OR 'viador' OR 'viaskin' OR 'wedd<br>(transdermal patch)' OR 'wearable electronic drug delivery patch' OR 'patch trans-dermal<br>system' OR 'patch transdermal system' OR 'skin patch' OR 'trans-dermal patch' OR 'trans-<br>dermal patches' OR 'transdermal drug delivery patch' OR 'transdermal drug delivery patches'<br>OR 'transdermal drug patch' OR 'transdermal drug patches' OR 'transdermal patch' OR<br>'transdermal patches' OR 'oral drug administration'/exp OR 'administration, oral' OR 'drug<br>administration, oral' OR 'oral administration' OR 'oral drug administration' OR 'oral drug<br>intake' OR 'p.o. administration' OR 'p.o. dosage' OR 'p.o. dose' OR 'p.o. drug administration'<br>OR 'p.o. drug intake' OR 'per os drug administration'<br>#4 #1 AND #2 AND #3   AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)||
|Cochrane<br>Libray|#1 (Turner Syndrome) OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-Turner) OR<br>(Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR (Gonadal<br>Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis) OR<br>(Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 Estrogens OR (Estrogenic Compounds) OR (Compounds, Estrogenic) OR (Estrogenic<br>Agents) OR (Agents, Estrogenic) OR Estrogen OR (Estrogen Receptor Agonists) OR<br>(Agonists, Estrogen Receptor) OR (Receptor Agonists, Estrogen) OR (Estrogen Effect) OR<br>(Estrogenic Effect*) OR (Effects, Estrogenic) OR (Estrogen Effects) OR (Effects, Estrogen)<br>#3 (Transdermal Patch) OR (Patch*, Transdermal) OR (Transdermal Patch*) OR<br>(Administration, Oral) OR (Drug Administration*, Oral) OR (Oral Drug Administration*)<br>OR (Oral Administration*) OR (Administrations, Oral) OR (Administration*, Oral Drug)|41|  
|**Bases de**<br>**dados**|**Estratégia**|**de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|---|
||#4  #1 AND #2 AND #3 =  41 –   5 RS e 36 E|CR||
|LILACS|#1 MH:"Síndrome de Turner" OR (Síndrom<br>(Síndrome de Turner) OR (Disgenesia Gonad<br>(Síndrome<br>de<br>Bonnevie-Ullrich)<br>OR<br>MH:C12.050.351.875.253.795.750$ OR<br>MH:C12.200.706.316.795.750$ OR<br>MH:C12.800.316.795.750$ OR MH:C14.24|e de Turner) OR (Turner Syndrome) OR<br>al 45 X) OR (Disgenesia Gonadal XO) OR<br>MH:C12.050.351.875.253.309.872$ OR<br>MH:C12.200.706.316.309.872$ OR<br>MH:C12.800.316.309.872$ OR<br>0.400.980$ OR MH:C14.280.400.980$ OR|0|
||MH:C16.131.240.400.970$ OR<br>MH:C16.131.939.316.309.872$ OR<br>MH:C16.320.180.830.835.750$ OR<br>MH:C19.391.119.795.750$ #2 MH:Estrogênios OR Estrogênios OR Estro<br>OR Estrogênio OR Estrógenos OR Mh:D27.50<br>#3 MH:"Adesivo Transdérmico" OR (Adesivo<br>(Adesivos Transdérmicos) OR MH:E07.9<br>(Administração Oral) OR (Administration<br>(Administração Oral de Medicamentos) OR M<br>#3 #1 AND #2 AND #3|MH:C16.131.260.830.835.750$ OR<br>MH:C16.131.939.316.795.750$ OR<br>MH:C19.391.119.309.872$ OR<br>gens OR Estrógenos OR (Efeito Estrogênio)<br>5.696.399.472.277$ Transdérmico) OR (Transdermal Patch) OR<br>35$ OR MH:"Administração Oral" OR<br>, Oral) OR (Administración Oral) OR<br>H:E02.319.267.100$||  
Dois avaliadores independentes realizaram a seleção dos estudos e extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com síndrome de Turner.  
- (b) Tipo de intervenção  
Estrógeno transdérmico comparado a via oral.  
- (c) Tipos de estudos  
Ensaios clínicos randomizados (ECR).  
- (d) Desfechos  
Indução de puberdade e segurança.  
- (e) Idioma  
Sem restrição de idioma.  
Resultados da busca  
Foram recuperadas 147 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Nenhuma referência preencheu os critérios de elegibilidade. O processo de seleção é detalhado na **Figura C** .  
**Figura C** . Fluxograma de seleção dos estudos incluídos para avaliação da utilização de estrógenos transdérmicos.  
<!-- Start of picture text -->
Referências indexadas obtidas na<br>busca em bases de dados<br>(n = 147)<br>Duplicatas removidas<br>(n = 3)<br>Resumos avaliados  Artigos excluídos<br>(n = 144)  (n = 144)<br>Artigos completos obtidos<br>para avaliação<br>(n = 0)<br>Identificação<br>Avaliação<br>Elegibilidade<br><!-- End of picture text -->  
Resumo das evidências:  
A busca não retornou novo estudo que atendesse a pergunta PICO envolvendo estrógeno transdérmico comparado à estrógeno oral.  
**QUESTÃO 4: Qual o melhor exame para detecção de sequências ocultas de cromossomo Y em pacientes com**  
**síndrome de Turner?**  
**Recomendação:** Sugere-se utilizar o exame PCR com _primers_ para cromossomo Y para detecção de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner. (Recomendação não graduada)  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com síndrome de Turner  
**Intervenção** : Reação de Cadeia em Polimerase (PCR) – Teste molecular realizado com sondas específicas do cromossomo Y para detecção de fragmentos desse cromossomo.  
**Comparador** : Técnica de FISH (Hibridização in situ por fluorescência),  
**Desfechos** : detecção de sequências Y  
Nota: A técnica de FISH é baseada no pareamento de uma sonda de DNA, marcada com fluorescência que possui  
sequência complementar ao gene de interesse pesquisado, permitindo a identificação/detecção de sequências específicas na  
amostra biológica do paciente. Em casos da síndrome de Turner, tem sido aplicada na identificação da origem de cromossomos estruturalmente anômalos.  
Métodos e resultados da busca:  
Foi realizada uma busca sistematizada nas bases Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) para atualizar as evidências acerca da questão. A busca foi realizada em 12 de julho de 2023. As estratégias de busca para cada base estão descritas no **Quadro F** .  
**Quadro F** : Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre o melhor exame para detecção de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|PubMed|#1 "Turner Syndrome"[Mesh] OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-<br>Turner) OR (Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR<br>(Gonadal Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis)<br>OR (Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 "Polymerase Chain Reaction"[Mesh] OR (Polymerase Chain Reactions) OR (Reaction*,<br>Polymerase Chain) OR (PCR) OR (Inverse PCR) OR (PCR, Inverse) OR (Inverse Polymerase<br>Chain Reaction) OR (Nested Polymerase Chain Reaction) OR (Nested PCR) OR (PCR,<br>Nested) OR (Anchored PCR) OR (PCR, Anchored) OR (Anchored Polymerase Chain<br>Reaction)<br>#3 "In Situ Hybridization, Fluorescence"[Mesh] OR (Hybridization in Situ, Fluorescent) OR<br>(FISH Technique*) OR (Technique*, FISH) OR (Fluorescent in Situ Hybridization) OR<br>(FISH Technic*) OR (Technic*, FISH) OR (Hybridization in Situ, Fluorescence) OR (In Situ<br>Hybridization, Fluorescent)<br>#4  "Y Chromosome"[Mesh] OR (Chromosome*, Y) OR (Y Chromosomes)<br>#5  #2 OR #3<br>#6  #1 AND #5 AND #4|236|
|Embase|#1 'turner syndrome'/exp OR '45, x syndrome' OR 'bonnevie ullrich turner syndrome' OR<br>'bonnevie ullrich state' OR 'bonnevie ullrich status' OR 'bonnevie-ullrich syndrome' OR<br>'bonneville ullrich turner syndrome' OR 'bournevie ullhrich turner syndrome' OR<br>'shereshevsky turner syndrome' OR 'turner albright syndrome' OR 'turner ullrich syndrome'<br>OR 'turner disease' OR 'turner stigma' OR 'turner syndrome' OR 'turner`s syndrome' OR<br>'turners syndrome' OR 'ullrich turner syndrome' OR 'ullrich syndrome' OR 'x-chromosome|83|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||monosomy' OR 'xo turner syndrome' OR 'xo syndrome' OR 'karyotype 45, x syndrome' OR<br>'karyotype 45, xo syndrome' OR 'syndrome, turner' OR 'xo male'<br>#2 'polymerase chain reaction'/exp OR 'pcr (polymerase chain reaction)' OR 'polymerase<br>chain reaction'<br>#3 'fluorescence in situ hybridization'/exp OR 'fish (fluorescence in situ hybridization)' OR<br>'fish assay' OR 'fluorescence in situ hybridisation' OR 'fluorescence in situ hybridization' OR<br>'fluorescence in situ hybridization assay' OR 'fluorescent in situ hybridisation' OR 'fluorescent<br>in situ hybridization' OR 'hybridization, fluorescence in situ' OR 'in situ hybridization,<br>fluorescence'<br>#4 'y chromosome'/exp OR 'y chromosome' OR 'y human chromosomes' OR 'chromosome y'<br>OR 'chromosome, y' OR 'chromosomes, human, y' OR 'human y chromosome' OR 'human y<br>chromosomes'<br>#5 #2 OR #3<br>#6 #1 AND #5 AND #4 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim) = 83||
|Cochrane<br>Libray|#1 (Turner Syndrome) OR (Ullrich-Turner Syndrome) OR (Syndrome, Ullrich-Turner) OR<br>(Ullrich Turner Syndrome) OR (Turner's Syndrome) OR (Turners Syndrome) OR (Gonadal<br>Dysgenesis, 45,X) OR (Gonadal Dysgenesis, XO) OR (XO Gonadal Dysgenesis) OR<br>(Monosomy X) OR (Bonnevie-Ullrich Syndrome) OR (Bonnevie Ullrich Syndrome) OR<br>(Status Bonnevie-Ullrich) OR (Status Bonnevie Ullrich)<br>#2 (Polymerase Chain Reaction) OR (Polymerase Chain Reactions) OR (Reaction*,<br>Polymerase Chain) OR (PCR) OR (Inverse PCR) OR (PCR, Inverse) OR (Inverse Polymerase<br>Chain Reaction) OR (Nested Polymerase Chain Reaction) OR (Nested PCR) OR (PCR,<br>Nested) OR (Anchored PCR) OR (PCR, Anchored) OR (Anchored Polymerase Chain<br>Reaction)<br>#3 (In Situ Hybridization, Fluorescence) OR (Hybridization in Situ, Fluorescent) OR (FISH<br>Technique*) OR (Technique*, FISH) OR (Fluorescent in Situ Hybridization) OR (FISH<br>Technic*) OR (Technic*, FISH) OR (Hybridization in Situ, Fluorescence) OR (In Situ<br>Hybridization, Fluorescent)<br>#4 (Y Chromosome) OR (Chromosome*, Y) OR (Y Chromosomes)|6|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||#5  #2 OR #3<br>#6  #1 AND #5 AND #4||
|LILACS|#1 MH:"Síndrome de Turner" OR (Síndrome de Turner) OR (Turner Syndrome) OR<br>(Síndrome de Turner) OR (Disgenesia Gonadal 45 X) OR (Disgenesia Gonadal XO) OR<br>(Síndrome<br>de<br>Bonnevie-Ullrich)<br>OR<br>MH:C12.050.351.875.253.309.872$ OR<br>MH:C12.050.351.875.253.795.750$ OR<br>MH:C12.200.706.316.309.872$ OR<br>MH:C12.200.706.316.795.750$ OR<br>MH:C12.800.316.309.872$ OR<br>MH:C12.800.316.795.750$ OR MH:C14.240.400.980$ OR MH:C14.280.400.980$ OR<br>MH:C16.131.240.400.970$ OR<br>MH:C16.131.260.830.835.750$ OR<br>MH:C16.131.939.316.309.872$ OR<br>MH:C16.131.939.316.795.750$ OR<br>MH:C16.320.180.830.835.750$ OR<br>MH:C19.391.119.309.872$ OR<br>MH:C19.391.119.795.750$ #2 MH: “Cromossomo Y” OR MD: A11.284.187.865.983 OR<br>MH: G05.360.162.865.983<br>#3 MD: “Reação em Cadeia da Polimerase” OR (PCR) OR (PCR ancorado) OR (PCR<br>aninhado) OR (PCR reverso) OR (Reação da Polimerase em Cadeia) OR (Reação de<br>Polimerase em Cadeia) OR (Reação em Cadeia de Polimerase)<br>#4 MH: “Hibridização in Situ Fluorescente” OR (Hibridização in Situ por Fluorescência) OR<br>(Técnica de FISH)<br>#5 #3 OR #4<br>#6 #1 AND #2 AND 5|41|  
Dois avaliadores independentes realizaram a seleção dos estudos e extração dos dados. Eventuais discordâncias entre os  
metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
(a) Tipos de participantes  
Pacientes com síndrome de Turner.  
(b) Tipo de intervenção  
Exame PCR comparado a Técnica de FISH em sangue periférico.  
- (c) Tipos de estudos  
Estudos observacionais.  
- (d) Desfechos  
Diagnóstico de sequência de cromossomo Y.  
- (e) Idioma  
Sem restrição de idioma.  
Resultados da busca  
Foram recuperadas 366 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram incluídas para leitura de texto completo 51 documentos<sup>10-60</sup> .  
Ao final da avaliação completa, seis<sup>10-15</sup> estudos foram incluídos. O processo de seleção é detalhado na **Figura D** . Os motivos de exclusão dos 45 estudos<sup>16-60</sup> foram, principalmente, a ausência da comparação de interesse e estudos com a mesma amostra publicados em periódicos diferentes.  
**Figura D** . Fluxograma de seleção dos estudos incluídos para avaliação do melhor teste diagnóstico para detecção de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner.  
<!-- Start of picture text -->
Referências indexadas obtidas na<br>busca em bases de dados<br>(n = 366)<br>Duplicatas removidas<br>(n = 3)<br>Resumos avaliados  Artigos excluídos<br>(n = 363)  (n = 312)<br>Artigos completos obtidos  Artigos excluídos com<br>para avaliação  razão<br>(n = 51)  (n = 45)<br>Artigos incluídos na<br>síntese qualitativa<br>(n = 6)<br>Elegibilidade<br>Identificação<br>Avaliação<br>Incluídos<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: Análise e apresentação dos resultados -->
Para a pesquisa de sequência de cromossomo Y em pacientes com síndrome de Turner não existe um padrão ouro, portanto, não é possível realizar estudos de acurácia. Os estudos são observacionais transversais e relataram o desfecho por meio da proporção de exames positivos na amostra estudada.  
Resumo das evidências:  
A pesquisa de fragmento de cromossomo Y é considerada importante devido ao risco de desenvolvimento de gonadoblastoma que apresenta potencial para malignização em pacientes com síndrome de Turner. O exame de cariótipo com análise de pelo menos 30 células pode detectar mosaicismo maior que 10% com intervalo de confiança de 95%. Portanto, resultados de cariótipo 45X podem apresentar mosaicismo em menor porcentagem, e o fragmento não detectado pode ser originado do cromossomo Y. Além disso, cromossomo marcador ou em anel detectados no cariótipo também podem ser originados desse cromossomo.  
A necessidade de exames adicionais ao cariótipo para identificação de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner, com resultado de cariótipo 45,X ou com mosaicismo com cromossomo marcador ou em anel, tem sido extensivamente pesquisada ultimamente.  
Nessa avaliação, seis estudos originais foram incluídos. Os estudos de Barros 2011<sup>10</sup> , Bispo 2013<sup>11</sup> e Cervantes 2001<sup>12</sup> realizaram o teste FISH apenas nos casos em que a sequência de cromossomo Y foi localizada pelo exame PCR, e o teste FISH confirmou os resultados.  
O estudo de Patsalis 1997<sup>14</sup> e Wang 2017<sup>15</sup> observaram concordância entre os resultados positivos para sequência de cromossomo Y dos testes FISH e PCR, em pacientes com síndrome de Turner com mosaicismo com a segunda linhagem sendo um cromossomo marcador. Cortés-Gutiérrez 2012<sup>13</sup> realizou PCR e FISH em 25 pacientes com síndrome de Turner e localizou fragmentos ocultos de cromossomo Y em 2 casos com o PCR e em apenas 1 com o teste de FISH ( **Tabela A** ).  
Esses resultados indicam, portanto, uma possível equivalência entre os exames PCR e FISH para o diagnóstico de sequências ocultas de cromossomo Y em pacientes com síndrome de Turner. A evidência é de baixa qualidade pois os estudos não são de acurácia, e apresentam tamanho de amostra limitado.  
**Tabela A** : Proporção de sequência oculta de cromossomo Y em pacientes com síndrome de Turner. Comparação entre teste FISH e PCR.  
||||**Positivo Y**|**Positivo Y**|
|---|---|---|---|---|
|**Estudo**|**País**|**Cariótipo (N)**|**FISH**|**PCR**|
||||**N (%)**|**N (%)**|
|Barros 2011|Brasil|45X ou mosaico com cromossomo marcador ou anel<br>(101)|10 (9,9)|10 (9,9)|
|Bispo 2013|Brasil|45X ou mosaico com cromossomo marcador ou anel<br>(51)|2 (3,9)|2 (3,9)|
|Cervantes 2001|México|45X mosaico com cromossomo marcador (8)|2 (25,0)|2 (25,0)|
|Patsalis 1997|Grécia|45X mosaico com cromossomo marcador (12)|11 (91,7)|11 (91,7)|
|Wang 2017|China|45X mosaico com cromossomo marcador (16)|2 (12,5)|2 (12,5)|
|Córtes-Gutiérrez<br>2012|México|45X ou mosaico com cromossomo marcador ou anel<br>(25)|1 (4,0)|2 (8,0)|  
**QUESTÃO 5: Em que casos deve-se solicitar exames adicionais ao cariótipo para afastar uma possível sequência oculta de cromossomo Y?**  
**Recomendação:** Recomenda-se realizar exame de PCR com primers para sequências de cromossomo Y em todas as pacientes com síndrome de Turner com mosaicismo com cromossomo marcador ou em anel (Recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com síndrome de Turner  
**Intervenção** : Cariótipo + PCR  
**Comparador** : Cariótipo  
**Desfechos** : detecção de sequências Y  
Essa pergunta foi acrescentada após a elaboração do escopo, pois o painel de especialistas considerou importante não apenas indicar o exame mais apropriado para a detecção de sequencias ocultas de cromossomo Y, mas também sintetizar evidências sobre as situações em que o exame deve ser solicitado.  
Métodos e resultados da busca:  
Foi realizada uma busca sistematizada nas bases Pubmed, Embase via Elsevier, Cochrane Library, Lilacs via Portal da Biblioteca Virtual em Saúde (BVS) para atualizar as evidências acerca da questão. A busca foi realizada em 12 de julho de 2023. As estratégias de busca para cada base foram as mesmas da Questão 4 ( **Quadro F** ).  
Dois avaliadores independentes realizaram a seleção dos estudos e extração dos dados. Eventuais discordâncias entre os metodologistas quanto à inclusão dos estudos foram resolvidas por consenso, ou quando necessário, mediante consulta a um terceiro revisor. Para otimizar o processo de seleção, foi utilizado o aplicativo Rayyan<sup>2</sup> .  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes  
Pacientes com síndrome de Turner.  
- (b) Tipo de intervenção  
Cariótipo + PCR ou FISH comparado a apenas cariótipo.  
- (c) Tipos de estudos  
Estudos observacionais.  
(d) Desfechos  
Diagnóstico de sequência de cromossomo Y.  
- (e) Idioma  
Sem restrição de idioma.  
Resultados da busca  
Foram recuperadas 366 referências por meio das buscas nas bases de dados eletrônicas. Inicialmente, foram excluídas as duplicatas e realizada a avaliação com base nos títulos e resumos. Por fim, foram avaliados 51 textos completos<sup>10-60</sup> . O processo de seleção é detalhado na **Figura E** . Para essa pergunta foram incluídos 40 estudos<sup>10-49</sup> , e os motivos de exclusão de 11 estudos<sup>50-</sup> 60 foram principalmente a ausência do desfecho de interesse e estudos com a mesma amostra publicados em periódicos diferentes.  
Dos estudos incluídos, apenas dois utilizaram o teste FISH<sup>16,47</sup> e seis avaliaram tanto do teste FISH como o PCR<sup>10-15</sup> com resultados equivalentes. Como o exame PCR é de menor custo, fácil execução e o mais estudado na literatura científica foi decidiu-se realizar a síntese apenas dos estudos com PCR.  
**Figura E** . Fluxograma de seleção dos estudos incluídos para avaliação dos casos em que se deve solicitar exames adicionais ao cariótipo para afastar uma possível sequência oculta de cromossomo Y.  
<!-- Start of picture text -->
Referências indexadas obtidas na<br>busca em bases de dados<br>(n = 366)<br>Duplicatas removidas<br>(n = 3)<br>Resumos avaliados  Artigos excluídos<br>(n = 363)  (n = 312)<br>Artigos completos obtidos  Artigos excluídos com<br>para avaliação  razão<br>(n = 51)  (n = 11)<br>Artigos incluídos<br>(n = 40)<br>Identificação<br>Avaliação<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
Para a pesquisa de sequência de cromossomo Y em pacientes com síndrome de Turner não existe um padrão ouro, portanto, não é possível realizar estudos de acurácia. Os estudos que tratam da questão são estudos observacionais transversais que relataram o desfecho por meio da proporção de exames positivos na amostra estudada.  
A meta-análise dos resultados dos estudos foi realizada por meio do programa OpenMeta [Analyst]<sup>61</sup> , utilizando como método para análise o efeito binário randômico ( _Binary Random Effect_ ). A heterogeneidade entre os resultados dos estudos foi avaliada pelo cálculo do teste de Qui-quadrado (p < 0,1 indica heterogeneidade) e o teste _I_<sup>2</sup> , onde mais de 50% representam heterogeneidade. Possíveis causas de heterogeneidade foram investigadas, como diferenças na amostra e intervenções.  
Resumo das evidências:  
Para avaliar a proporção de exames PCR positivos com probes para cromossomo Y em pacientes com síndrome de Turner, com cariótipo 45X, foi possível extrair dados de 32 estudos. A proporção de sequência de cromossomo Y observada na metaanálise foi 5,1% (IC 95%: 3,5 a 6,8; 32 estudos, 1.235 participantes; _I_<sup>2</sup> =49,2%). Certa heterogeneidade observada na análise  
possivelmente se deve à diferentes tipos e quantidades de probes de cromossomo Y utilizados em cada estudo ( **Tabela B** e **Figura F** ).  
**Tabela B:** Proporção de sequência de cromossomo Y detectadas por PCR em pacientes com síndrome de Turner com cariótipo 45X.  
|**Referência**|**País**|**Sequência**|**N**|**Positivo**<br>**Y**|**%**|
|---|---|---|---|---|---|
|Alvarez-Nava 2003|Venezuela|SRY, ZFY, DYS19, DYZ3, DYZ1, TSPY, YRRM|27|1|3,7|
|Araujo 2008|Brasil|SRY, DYZ3, ZFY, DYZ1, DYS1 PABY|27|2|7,4|
|Barbosa 2021|Brasil|SRY, TSPY, AMELX|101|10|9,9|
|Bianco 2009|Brasil|SRY, DYZ3, TSPY|62|12|19,3|
|Bispo  2013|Brasil|SRY, AMGY, DAZ, TSPY,|47|1|2,2|
|Canto 2004|México|SRY, ZFY, Yc, Yq, PABY|107|10|9,3|
|Carvalho 2018|Brasil|SRY, TSPY, DXYZ3|40|3|7,5|
|Cortés-Gutiérrez|México|SRY|24|1|4,2|
|2012||||||
|Coto 1995|Espanha|PABY, SRY, DYZ3,DYZ1|15|8|53,3|
|Cherepnalkovski|Macedonia|SRY|20|0|0,0|
|2008||||||
|Damiani 1999|Brasil|SRY|22|0|0,0|
|El-Eshmawy 2013|Egito|SRY|24|9|18,7|
|Ferrão 2002|Portugal|SRY,TSPY, DYZ3,|12|0|0,0|
|Freriks 2013|Holanda|SRY, DYS14|63|2|3,2|
|Gravholt 2000|Dinamarca|SRY, ZFY, DYZ3, DYS132, DYZI|63|3|4,8|
|Jakubiczka 1998|Alemanha|PABY SRY ZFY DY519 T5PY DYZ3 DYZ1|15|0|-|
|Knauer-Fischer 2014|Alemanha|SRY, ZFY|23|2|8,7|
|Kocova 1993|EUA|SRY, DYZ3|8|1|12,5|
|Lopez 1998|México|SRY, ZFY|36|3|8,3|
|Mancilla 2003|Chile|SRY, TSPY, DYZ3,|30|1|3,3|
|Mazzanti 2005|Itália|SRY, DYZ3|60|2|3,3|
|Medlej 1992|França|SRY|37|1|2,7|
|Mendes 1999|Brasil|SRY, ZFY, DYZ3|15|1|6,6|
|Nishi 2002|Brasil|SRY, TSPY,DYZ3, DYZ1|66|0|0,0|
|Quilter 1998|Inglaterra|SRY, DYZ|50|2|4,0|
|Rojek 2017|Polonia|SRY, DYZ1,3,123, ZFY, TSPY|22|3|13,6|
|Silva-Grecco 2015|Brasil|SRY, DYZ1, DYZ3, ZFY|9|0|0,0|
|Semerci 2007|Turquia|SRY. PABY, DYZ1,3, DYS, YRRM|40|2|5,0|
|Soares 2021|Brasil|SRY, DYZ3|31|1|3,2|
|Vlasak 1999|Hungria|PABY, SRY, ZFY, DYZ3, DYS274, DYS7, DYS239,<br>DYZ2, DYZ1|101|3|3,0|
|Yorifuji 1996|Japão|SRY, DZY2,3|18|0|0,0|
|Zelaya  2015|Argentina|SRY|20|2|10,0|  
**Figura F** : Meta-análise da proporção de sequência de cromossomo Y detectadas por PCR em pacientes com síndrome de Turner com cariótipo 45X.  
<!-- Start of picture text -->
Studies Estimate (95% C.I.) Bv/Trt<br>Zelaya 2015 0.100 (0.000, 0.231) 2/20 ——-—»#—___<br>Yorifyl 1996 0.026 (0.000, 0.098) 0/18 —a+—<br>Viasak 1999 0.030 (0.000, 0.063) 3/101<br>Soares 2021 0.032 (0.000, 0.094) 1/31 —#—<br>Sitva-Grecco 2015 0.050 (0.000, 0.185) 0/9 = —#————<br>Semerci 2007 0.050 (0.000, 0.118) 2/40 ——<br>Rojek 2017 0.136 (0.000, 0.280) 3/22. ——}——»—<br>Quiter 1998 0.040 (0.000, 0.094) 2/50 —a#—<br>Nishi 2002 0.007 (0.000, 0.028) 0/66 fi<br>Mendes 1999 0.067 (0.000, 0.193) 1/18 9 ——+*——<br>Medlej 1992 0.027 (0.000, 0.079) 1/37 —#+—<br>Mazzanti 2006 0.033 (0.000, 0.073) 2/60 —#H—<br>Mancila 2003, 0.033 (0.000, 0.098) 1/30 —a#+—<br>Lopez 1998 0.083 (0.000, 0.174) 3/36 = ——-~*——<br>Kocova 1993 0.125 (0.000, 0.354) 1/8 = +» —_________<br>Knaver-Fischer 2014 0.087 (0.000, 0.202) 2/23 ©=——»——<br>Jakubiczka 1998 0.031 (0.000, 0.117) 0/15 9 —#+——<br>Gravhoit 2000 0.048 (0.000, 0.100) 3/63 ©—#-—<br>Freriks 2013 0.032 (0.000, 0.075) 2/63 —H—<br>Ferréo 2002 0.038 (0.000, 0.143) 0/12. —#+———<br>El-Eshmawy 2013 0.375 (0.181, 0.569) 9/24 a<br>Damiani 1999 0.022 (0.000, 0.081) 0/22 --+—<br>Coto 1995 0.533 (0.281, 0.786) 8/15 oe<br>Cortes-Gutierrez 2012 0,042 (0,000, 0.122) 1/24 —™#——<br>Cherepnalkovsk 2008 0.024 (0.000, 0.089) 0/20 —#+—<br>Carvalho 2018 0.075 (0.000, 0.157) 3/40 ——-#——<br>Canto 2004 0.093 (0.038, 0.143) 10/107 ——<br>Bispo 2013 0.021 (0.000, 0.063) 1/47 +<br>Bianco 2009 0.194 (0.095, 0.292) 12/62 ——<br>Barbosa 2021 0.099 (0.041, 0.157) 10/101 —+—<br>Araujo 2008 0.074 (0.000, 0.173) 2/27 ——+*——<br>Alvarez-Nava 2003 0.037 (0.000, 0.108) 1/27 —#i—<br>Overall (142=49.21% , P=0.001) 0.051 (0.035, 0.068) 86/1235 <><br>a 02 os os<br>Proportion<br><!-- End of picture text -->  
Dos estudos incluídos, 18 apresentaram o resultado da análise por PCR de pacientes com síndrome de Turner com cariótipo apresentado mosaicismo com a segunda linhagem de células sendo um cromossomo marcador ou em anel (45X/46X+mar ou ring).  
A proporção de sequência de cromossomo Y observada na meta-análise foi 51,9% (IC 95%: 35,4 a 68,5; 18 estudos, 116 participantes; _I_<sup>2</sup> =80,8%). A grande heterogeneidade observada na análise possivelmente se deve à diferentes tipos e quantidades de probes de cromossomo Y utilizados em cada estudo ( **Tabela C** e **Figura G** ).  
**Tabela C** : Proporção de sequência de cromossomo Y detectadas por PCR em pacientes com síndrome de Turner com cariótipo (45X/46X+mar ou ring).  
|**Referência**|**País**|**Sequência**|**N**|**Positivo Y**|**%**|
|---|---|---|---|---|---|
|Alvarez-Nava 2003|Venezuela|SRY, ZFY, DYS19, DYZ3, DYZ1, TSPY, YRRM|1|1|100,0|
|Jakubiczka 1998|Alemanha|PABY 5RY ZFY DY519 T5PY DYZ3 DYZ1|3|2|67,0|
|Barbosa 2021|Brasil|SRY, TSPY, AMELX|8|4|50,0|
|Bianco 2009|Brasil|SRY, DYZ3, TSPY|7|3|42,9|
|Carvalho 2018|Brasil|SRY, TSPY, DXYZ3|18|4|22,2|
|Cervantes 2001|México|PABY, SRY, ZFY|8|2|25,0|
|Cortés-Gutiérrez 2012|México|SRY|1|1|100,0|
|Coto 1995|Espanha|PABY, SRY, DYZ3, DYZ1|3|3|100,0|
|Damiani 1999|Brasil|SRY|2|2|100,0|
|Ferrão 2002|Portugal|SRY, TSPY, DYZ3, DAZI|2|2|100,0|  
|**Referência**|**País**|**Sequência**|**N**|**Positivo Y**|**%**|
|---|---|---|---|---|---|
|Gravholt 2000|Dinamarca|SRY, ZFY, DYZ3, DYS132, DYZI|7|2|28,6|
|Lopez 1998|México|SRY, ZFY|4|4|100,0|
|Mancilla 2003|Chile|SRY, TSPY, DYZ3,|6|1|16,7|
|Mendes 1999|Brasil|SRY, ZFY, DYZ3|5|1|20,0|
|Nishi 2002|Brasil|SRY, TSPY,DYZ3, DYZ1|9|4|44,4|
|Patsalis 1997|Grécia|SRY, TSPY, YRRM|12|11|91,7|
|Silva-Grecco 2015|Brasil|SRY, DYZ1, DYZ3, ZFY|4|2|50,0|
|Wang 2017|China|SRY|16|2|12,5|  
**Figura G:** Meta-análise da proporção de sequência de cromossomo Y detectadas por PCR em pacientes com síndrome de Turner com cariótipo (45X/46X+mar ou ring).  
<!-- Start of picture text -->
Studies Estimate (98% C.I.) Bv/Trt<br>Alvarez-Nava 2003 -750 (0.180, 1.000) 1/1 .-<br>Barbosa 2021 +500 (0.154, 0.846) 4/8 ee —<br>Bianco 2000 429 (0,062, 0.795) 3/7 a<br>Carvatio 2018 +222 (04030, 0.414) 4/18 .<br>Cervantes 2001 +250 (0,000, 0.550) 2/8 §~———§#<br>Cortes-Gutierrez 2012 -150 (0.180, 1.000) 1/1 .<br>Coto 1995 -875 (0.551, 1.000) 3/3 er<br>Damiani 1999 833 (0.412, 1.000) 2/2 SS<br>Ferro 2002 +833 (0.412, 1.000) 2/2 .<br>Gravholt 2000 +286 (0,000, 0.620) 2/7»<br>Jakublezka 1998 -667 (0.133, 1.000) 2/3 .<br>Lopez 1998 300 (0.637, 1.000) 4/4 Si<br>Mancita 2003 167 (0.000, 0.865) 1/6 © ————____—<br>Mendes 1999 -200 (0.000, 0.551) 1/5 .<br>Nishi 2002 +444 (0.120, 0.769) 4/9 ——————————1—___<br>Patsalis 1997 917 (0.760, 1.000) 11/12 =<br>Silva-Greceo 2015 +500 (04010, 046990) 2/4<br>Wang 2017 +125 (0.000, 0.287) 2/16 ———{§-———<br>Overall (142=80.79% , P< 0.001) 0.519 (0.354, 0.685) 51/116 —= ==<br>° 02 os 0 o :<br>Proportion<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **4. REFERÊNCIAS** -->
1. Gravholt CH, Andersen NH, Christin-Maitre S, Davis SM, Duijnhouwer A, Gawlik A, Maciel-Guerra AT, Gutmark-Little I, Fleischer K, Hong D, Klein KO, Prakash SK, Shankar RK, Sandberg DE, Sas TCJ, Skakkebæk A, Stochholm K, van der Velden JA; International Turner Syndrome Consensus Group; Backeljauw PF. Clinical practice guidelines for the care of girls and women with Turner syndrome. Eur J Endocrinol. 2024 Jun 5;190(6):G53-G151. doi: 10.1093/ejendo/lvae050.  
2. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews. Syst Rev. 2016 Dec 5;5.  
3. Ahn JM, Suh JH, Kwon AR, Chae HW, Kim HS. Final Adult Height after Growth Hormone Treatment in Patients with Turner Syndrome. Horm Res Paediatr. 2019;91(6):373-379. doi: 10.1159/000500780. Epub 2019 Sep 3.  
4. Dantas NCB, Braz AF, Malaquias A, Lemos-Marini S, Arnhold IJP, Silveira ER, Antonini SR, Guerra-Junior G, Mendonca B, Jorge A, Scalco RC. Adult Height in 299 Patients with Turner Syndrome with or without Growth Hormone Therapy: Results and Literature Review. Horm Res Paediatr. 2021;94(1-2):63-70. doi: 10.1159/000516869. Epub 2021 Jun 16. PMID: 34134112.  
5. Davenport ML, Crowe BJ, Travers SH, Rubin K, Ross JL, Fechner PY, Gunther DF, Liu C, Geffner ME, Thrailkill K, Huseman C, Zagar AJ, Quigley CA. Growth hormone treatment of early growth failure in toddlers with Turner syndrome:  
a randomized, controlled, multicenter trial. J Clin Endocrinol Metab. 2007 Sep;92(9):3406-16. doi: 10.1210/jc.2006-2874. Epub 2007 Jun 26.  
6. Irzyniec T, Jeż W, Lepska K, Maciejewska-Paszek I, Frelich J. Childhood growth hormone treatment in women with Turner syndrome - benefits and adverse effects. Sci Rep. 2019 Nov 4;9(1):15951. doi: 10.1038/s41598-019-52332-0.  
7. Kriström B, Ankarberg-Lindgren C, Barrenäs ML, Nilsson KO, Albertsson-Wikland K. Normalization of puberty and adult height in girls with Turner syndrome: results of the Swedish Growth Hormone trials initiating transition into adulthood. Front Endocrinol (Lausanne). 2023 Jul 17;14:1197897. doi: 10.3389/fendo.2023.1197897.  
8. Quigley CA, Fechner PY, Geffner ME, Eugster EA, Ross JL, Habiby RL, Ugrasbul F, Rubin K, Travers S, Antalis CJ, Patel HN, Davenport ML. Prevention of Growth Failure in Turner Syndrome: Long-Term Results of Early Growth Hormone Treatment in the "Toddler Turner" Cohort. Horm Res Paediatr. 2021;94(1-2):18-35. doi: 10.1159/000513788. Epub 2021 Jun 10.  
9. Moola S, Munn Z, Tufanaru C, Aromataris E, Sears K, Sfetcu R, Currie M, Qureshi R, Mattis P, Lisy K, Mu P-F. Chapter 7: Systematic reviews of etiology and risk . In: Aromataris E, Munn Z (Editors). JBI Manual for Evidence Synthesis. JBI, 2020. Available from https://synthesismanual.jbi.global.  
10. Barros BA, Moraes SG, Coeli FB, Assumpção JG, De Mello MP, Maciel-Guerra AT, Carvalho AB, Viguetti-Campos N, Vieira TA, Amstalden EM, Andrade JG, Esquiaveto-Aun AM, Marques-de-Faria AP, D'Souza-Li LF, Lemos-Marini SH, Guerra G Jr. OCT4 immunohistochemistry may be necessary to identify the real risk of gonadal tumors in patients with Turner syndrome and Y chromosome sequences. Hum Reprod. 2011  
11. Bispo AV, Burégio-Frota P, Oliveira dos Santos L, Leal GF, Duarte AR, Araújo J, Cavalcante da Silva V, Muniz MT, Liehr T, Santos N. Y chromosome in Turner syndrome: detection of hidden mosaicism and the report of a rare X;Y translocation case. Reprod Fertil Dev. 2014 Oct;26(8):1176-82. doi: 10.1071/RD13207.  
12. Cervantes A, Guevara-Yáñez R, López M, Monroy N, Aguinaga M, Valdez H, Sierra C, Canún S, Guízar J, Navarrete C, Zafra G, Salamanca F, Kofman-Alfaro S. PCR-PRINS-FISH analysis of structurally abnormal sex chromosomes in eight patients with Turner phenotype. Clin Genet. 2001 Nov;60(5):385-92. doi: 10.1034/j.1399-0004.2001.600512.x.  
13. Cortés-Gutiérrez EI, Herrera-Bartolo R, Dávila-Rodríguez MI, Palacios-Saucedo GC, Vargas-Villarreal J, RomeroVillarreal JB. Molecular detection of cryptic Y-chromosomal material in patients with Turner syndrome. Oncol Rep. 2012 Oct;28(4):1205-10. doi: 10.3892/or.2012.1916. Epub 2012 Jul 16.  
14. Patsalis PC, Sismani C, Hadjimarcou MI, Kitsiou-Tzeli S, Tzezou A, Hadjiathanasiou CG, Velissariou V, Lymberatou E, Moschonas NK, Skordis N. Detection and incidence of cryptic Y chromosome sequences in Turner syndrome patients. Clin Genet. 1998 Apr;53(4):249-57. doi: 10.1111/j.1399-0004.1998.tb02691.x.  
15. Wang H, Wang T, Yang N, He Y, Chen L, Hong L, Shao X, Li H, Zhu H, Li H. The clinical analysis of small supernumerary marker chromosomes in 17 children with mos 45,X/46,X,+mar karyotype. Oncol Lett. 2017 Jun;13(6):4385-4389. doi: 10.3892/ol.2017.5965. Epub 2017 Mar 31.  
16. Akcan AB, Boduroğlu OK. Y Chromosome Material in Turner Syndrome. Cureus. 2021 Nov 29;13(11):e19977. doi: 10.7759/cureus.19977.  
17. Alvarez-Nava F, Soto M, Sánchez MA, Fernández E, Lanes R. Molecular analysis in Turner syndrome. J Pediatr. 2003 Mar;142(3):336-40. doi: 10.1067/mpd.2003.95. PMID: 12640385.  
18. Araujo C, Galera MF, Galera BB, Silvestre FG, Medeiros SF. Molecular identification of chromosome Y sequences in Brazilian patients with Turner syndrome. Gynecol Endocrinol. 2008 Dec;24(12):713-7. doi: 10.1080/09513590802444142.  
19. Barbosa LG, Siviero-Miachon AA, Souza MA, Spinola-Castro AM. Recognition of the Y chromosome in Turner syndrome using peripheral blood or oral mucosa tissue. Ann Pediatr Endocrinol Metab. 2021 Dec;26(4):272-277. doi: 10.6065/apem.2142026.013. Epub 2021 Oct 8.  
20. Bianco B, Lipay M, Guedes A, Oliveira K, Verreschi IT. SRY gene increases the risk of developing gonadoblastoma and/or nontumoral gonadal lesions in Turner syndrome. Int J Gynecol Pathol. 2009 Mar;28(2):197-202. doi: 10.1097/PGP.0b013e318186a825.  
21. Canto P, Kofman-Alfaro S, Jiménez AL, Söderlund D, Barrón C, Reyes E, Méndez JP, Zenteno JC. Gonadoblastoma in Turner syndrome patients with nonmosaic 45,X karyotype and Y chromosome sequences. Cancer Genet Cytogenet. 2004 Apr 1;150(1):70-2. doi: 10.1016/j.cancergencyto.2003.08.011.  
22. Carvalho AB, Lemos-Marini SHV, Guerra-Junior G, Maciel-Guerra AT. Clinical and cytogenetic features of 516 patients with suspected Turner syndrome - a single-center experience. J Pediatr Endocrinol Metab. 2018 Jan 26;31(2):167-173. doi: 10.1515/jpem-2017-0273.  
23. Cherepnalkovski A,  Koceva S, Kocova M. Analysis of the SRY Gene in Turner Syndrome Patients from the Republic of Macedonia.  Balk J Med Gen 2008; 11: 31-37. 10.2478/v10034-008-0025-x.  
24. Coto E, Toral JF, Menéndez MJ, Hernando I, Plasencia A, Benavides A, López-Larrea C. PCR-based study of the presence of Y-chromosome sequences in patients with Ullrich-Turner syndrome. Am J Med Genet. 1995 Jul 3;57(3):393-6. doi: 10.1002/ajmg.1320570305.  
25. Damiani D, Guedes DR, Fellous M, Barbaux S, McElreavey K, Kalil J, Goldberg AC, Moreira-Filho CA, Barbosa A, Della Manna T, Dichtchekenian V, Setian N. Ullrich-Turner syndrome: relevance of searching for Y chromosome fragments. J Pediatr Endocrinol Metab. 1999 Nov-Dec;12(6):827-31. doi: 10.1515/jpem.1999.12.6.827.  
26. El-Eshmawy MM, Yahia S, El-Dahtory FA, Hamed S, El Hadidy el HM, Ragab M. Hidden Y Chromosome Mosaicism in 48 Egyptian Patients with Turner's Syndrome. Genet Res Int. 2013;2013:463529. doi: 10.1155/2013/463529. Epub 2013 Jul 28.  
27. Ferrão L, Lopes ML, Limbert C, Marques B, Boieiro F, Silva M, Marques R, Lavinha J, Mota A, Gonçalves J. Pesquisa de sequências do cromossoma Y em indivíduos com síndroma de Turner [Screening for Y chromosome sequences in patients with Turner syndrome]. Acta Med Port. 2002 Mar-Apr;15(2):89-100.  
28. Freriks K, Timmers HJ, Netea-Maier RT, Beerendonk CC, Otten BJ, van Alfen-van der Velden JA, Traas MA, Mieloo H, van de Zande GW, Hoefsloot LH, Hermus AR, Smeets DF. Buccal cell FISH and blood PCR-Y detect high rates of X chromosomal mosaicism and Y chromosomal derivatives in patients with Turner syndrome. Eur J Med Genet. 2013 Sep;56(9):497-501. doi: 10.1016/j.ejmg.2013.07.008. Epub 2013 Aug 9.  
29. Gravholt CH, Fedder J, Naeraa RW, Müller J. Occurrence of gonadoblastoma in females with Turner syndrome and Y chromosome material: a population study. J Clin Endocrinol Metab. 2000 Sep;85(9):3199-202. doi: 10.1210/jcem.85.9.6800.  
30. Jakubiczka S, Mohnike K, Wieacker P. Turner-Syndrom: Suche nach zytogenetisch nicht nachweisbaren Zellinien mit V- Chromosom durch molekulargenetische Methoden. Geburtsh Frauenheilk. 1998; 58: 69-72.  
31. Knauer-Fischer S, Besikoglu B, Inta I, Kneppo C, Vogt PH, Bettendorf M. Analyses of Gonadoblastoma Y (GBY)-locus and of Y centromere in Turner syndrome patients. Exp Clin Endocrinol Diabetes. 2015 Jan;123(1):61-5. doi: 10.1055/s0034-1387734. Epub 2014 Oct 14.  
32. Kocova M, Siegel SF, Wenger SL, Lee PA, Trucco M. Detection of Y chromosome sequences in Turner's syndrome by Southern blot analysis of amplified DNA. Lancet. 1993 Jul 17;342(8864):140-3. doi: 10.1016/0140-6736(93)91345-m.  
33. López M, Canto P, Aguinaga M, Torres L, Cervantes A, Alfaro G, Méndez JP, Kofman-Alfaro S. Frequency of Y chromosomal material in Mexican patients with Ullrich-Turner syndrome. Am J Med Genet. 1998 Mar 5;76(2):120-4. doi: 10.1002/(sici)1096-8628(19980305)76:2<120::aid-ajmg3>3.0.co;2-x.  
34. Mancilla EE, Poggi H, Repetto G, Rumié H, García H, Ugarte F, Hidalgo S, Jara A, Muzzo S, Panteón E, Torrealba I, Foradori A, Cattani A. Y chromosome sequences in Turner's syndrome: association with virilization and gonadoblastoma. J Pediatr Endocrinol Metab. 2003 Oct-Nov;16(8):1157-63. doi: 10.1515/jpem.2003.16.8.1157.  
35. Mazzanti L, Cicognani A, Baldazzi L, Bergamaschi R, Scarano E, Strocchi S, Nicoletti A, Mencarelli F, Pittalis M, Forabosco A, Cacciari E. Gonadoblastoma in Turner syndrome and Y-chromosome-derived material. Am J Med Genet A. 2005 Jun 1;135(2):150-4. doi: 10.1002/ajmg.a.30569.  
36. Medlej R, Lobaccaro JM, Berta P, Belon C, Leheup B, Toublanc JE, Weill J, Chevalier C, Dumas R, Sultan C. Screening for Y-derived sex determining gene SRY in 40 patients with Turner syndrome. J Clin Endocrinol Metab. 1992 Nov;75(5):1289-92. doi: 10.1210/jcem.75.5.1430090.  
37. Mendes JR, Strufaldi MW, Delcelo R, Moisés RC, Vieira JG, Kasamatsu TS, Galera MF, Andrade JA, Verreschi IT. Y- chromosome identification by PCR and gonadal histopathology in Turner's syndrome without overt Y-mosaicism. Clin Endocrinol (Oxf). 1999 Jan;50(1):19-26. doi: 10.1046/j.1365-2265.1999.00607.x.  
38. Nishi MY, Domenice S, Medeiros MA, Mendonca BB, Billerbeck AE. Detection of Y-specific sequences in 122 patients with Turner syndrome: nested PCR is not a reliable method. Am J Med Genet. 2002 Feb 1;107(4):299-305. doi: 10.1002/ajmg.10168. Erratum in: Am J Med Genet. 2002 Nov 15;113(1):116-7.  
39. Patsalis PC, Hadjimarcou MI, Velissariou V, Kitsiou-Tzeli S, Zera C, Syrrou M, Lyberatou E, Tsezou A, Galla A, Skordis N. Supernumerary marker chromosomes (SMCs) in Turner syndrome are mostly derived from the Y chromosome. Clin Genet. 1997 Mar;51(3):184-90. doi: 10.1111/j.1399-0004.1997.tb02450.x.  
40. Quilter CR, Taylor K, Conway GS, Nathwani N, Delhanty JD. Cytogenetic and molecular investigations of Y chromosome sequences and their role in Turner syndrome. Ann Hum Genet. 1998 Mar;62(Pt 2):99-106. doi: 10.1046/j.14691809.1998.6220099.x.  
41. Rojek A, Obara-Moszynska M, Kolesinska Z, Rabska-Pietrzak B, Niedziela M. Molecular Detection and Incidence of Y Chromosomal Material in Patients with Turner Syndrome. Sex Dev. 2017;11(5-6):254-261. doi: 10.1159/000484880. Epub 2017 Dec 16.  
42. Sallai A, Sólyom J, Dobos M, Szabó J, Halász Z, Ságodi L, Niederland T, Kozári A, Bertalan R, Ugocsai P, Fekete G. Y- chromosome markers in Turner syndrome: Screening of 130 patients. J Endocrinol Invest. 2010 Apr;33(4):222-7. doi: 10.1007/BF03345783. Epub 2009 Jul 21.  
43. Semerci CN, Satiroglu-Tufan NL, Turan S, Bereket A, Tuysuz B, Yilmaz E, Kayserili H, Karaman B, Semiz S, Duzcan F, Bagci H. Detection of Y chromosomal material in patients with a 45,X karyotype by PCR method. Tohoku J Exp Med. 2007 Mar;211(3):243-9. doi: 10.1620/tjem.211.243. PMID: 17347549.  
44. Silva-Grecco RL, Trovó-Marqui AB, Sousa TA, Croce LD, Balarin MA. Identification of Y-Chromosome Sequences in Turner Syndrome. Indian J Pediatr. 2016 May;83(5):405-9. doi: 10.1007/s12098-015-1929-6. Epub 2015 Dec 4.  
45. Soares JS, da Silva Lago RMR, Toralles MBP, Mota LR, Alves ES, de Carvalho AFL. Searching chromosome mosaicisms in 45,X Turner syndrome: how relevant is it? Arch Endocrinol Metab. 2021 Nov 24;65(6):739-746. doi: 10.20945/23593997000000403. Epub 2021 Nov 11.  
46. Vlasak I, Plöchl E, Kronberger G, Bergendi E, Rittinger O, Hagemann M, Schmitt K, Blümel P, Glatzl J, Fekete G, Kadrnka-Lovrencic M, Borkenstein M, Häusler G, Frisch H. Screening of patients with Turner syndrome for "hidden" Y- mosaicism. Klin Padiatr. 1999 Jan-Feb;211(1):30-4. doi: 10.1055/s-2008-1043759.  
47. Wiktor AE, Van Dyke DL. Detection of low level sex chromosome mosaicism in Ullrich-Turner syndrome patients. Am J Med Genet A. 2005 Oct 15;138A(3):259-61. doi: 10.1002/ajmg.a.30954. PMID: 16158437.  
48. Yorifuji T, Muroi J, Kawai M, Sasaki H, Momoi T, Furusho K. PCR-based detection of mosaicism in Turner syndrome patients. Hum Genet. 1997 Jan;99(1):62-5. doi: 10.1007/s004390050312.  
49. Zelaya G, López Marti JM, Marino R, Garcia de Dávila MT, Gallego MS. Gonadoblastoma in patients with Ullrich-Turner syndrome. Pediatr Dev Pathol. 2015 Mar-Apr;18(2):117-21. doi: 10.2350/14-08-1539-OA.1. Epub 2014 Dec 23. PMID: 25535833.  
50. Abulhasan SJ, Tayel SM, al-Awadi SA. Mosaic Turner syndrome: cytogenetics versus FISH. Ann Hum Genet. 1999 May;63(Pt 3):199-206. doi: 10.1046/j.1469-1809.1999.6330199.x.  
51. Barros BA, Maciel-Guerra AT, De Mello MP, Coeli FB, Carvalho AB, Viguetti-Campos N, Assumpção Jde G, Marquesde-Faria AP, Lemos-Marini SH, Guerra-Junior G. A inclusão de novas técnicas de análise citogenética aperfeiçoou o diagnóstico cromossômico da síndrome de Turner [The inclusion of new techniques of chromosome analysis has improved the cytogenetic profile of Turner syndrome]. Arq Bras Endocrinol Metabol. 2009 Dec;53(9):1137-42. Portuguese. doi: 10.1590/s0004-27302009000900010.  
52. Bianco B, Lipay MV, Melaragno MI, Guedes AD, Verreschi IT. Detection of hidden Y mosaicism in Turner's syndrome: importance in the prevention of gonadoblastoma. J Pediatr Endocrinol Metab. 2006 Sep;19(9):1113-7. doi: 10.1515/jpem.2006.19.9.1113.  
53. Binder G, Koch A, Wajs E, Ranke MB. Nested polymerase chain reaction study of 53 cases with Turner's syndrome: is cytogenetically undetected Y mosaicism common? J Clin Endocrinol Metab. 1995 Dec;80(12):3532-6. doi: 10.1210/jcem.80.12.8530595.  
54. Fernández-García R, García-Doval S, Costoya S, Pásaro E. Analysis of sex chromosome aneuploidy in 41 patients with Turner syndrome: a study of 'hidden' mosaicism. Clin Genet. 2000 Sep;58(3):201-8. doi: 10.1034/j.13990004.2000.580307.x  
55. Graff A, Donadille B, Morel H, Villy MC, Bourcigaux N, Vatier C, Borgel A, Khodawardi A, Siffroi JP, Christin-Maitre S. Added value of buccal cell FISH analysis in the diagnosis and management of Turner syndrome. Hum Reprod. 2020 Oct 1;35(10):2391-2398. doi: 10.1093/humrep/deaa197.  
56. Kurnaz E, Çetinkaya S, Savaş-Erdeve Ş, Aycan Z. Detection of the SRY gene in patients with Turner Syndrome. J Gynecol Obstet Hum Reprod. 2019 Apr;48(4):265-267. doi: 10.1016/j.jogoh.2019.01.012. Epub 2019 Jan 24.  
57. Kuznetzova T, Baranov A, Schwed N, Ivaschenko T, Malet P, Giollant M, Savitsky GA, Baranov V. Cytogenetic and molecular findings in patients with Turner's syndrome stigmata. J Med Genet. 1995 Dec;32(12):962-7. doi: 10.1136/jmg.32.12.962.  
58. Nagafuchi S, Tamura T, Nakahori Y, Takano K, Nishi Y, Iwatani N, Kitao M, Hori Y, Konda S, Hasegawa T, et al. The majority of the marker chromosomes in Japanese patients with stigmata of Turner syndrome are derived from Y chromosomes. Hum Genet. 1992 Aug;89(6):590-2. doi: 10.1007/BF00221943.  
59. Schwartz S, Depinet TW, Leana-Cox J, Isada NB, Karson EM, Park VM, Pasztor LM, Sheppard LC, Stallard R, Wolff DJ, Zinn AB, Zurcher VL, Zackowski JL. Sex chromosome markers: characterization using fluorescence in situ hybridization and review of the literature. Am J Med Genet. 1997 Jul 11;71(1):1-7. doi: 10.1002/(sici)1096-8628(19970711)71:1<1::aidajmg1>3.0.co;2-1.  
60. Wiktor A, Van Dyke DL. FISH analysis helps identify low-level mosaicism in Ullrich-Turner syndrome patients. Genet Med. 2004 May-Jun;6(3):132-5. doi: 10.1097/01.gim.0000127270.49902.56. PMID: 15354330.  
61. Wallace, Byron C., Issa J. Dahabreh, Thomas A. Trikalinos, Joseph Lau, Paul Trow, and Christopher H. Schmid. "Closing the gap between methodologists and end-users: R as a computational back-end." J Stat Softw 49, no. 5 (2012): 1-15.

---

<!-- METADADOS: doenca: Síndrome de Turner | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório da diretriz**||**Tecnologias avaliad**|**as pela Conitec**|
|---|---|---|---|
|**clínica (Conitec) ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não incorporação ou**<br>**não alteração no SUS**|
|Relatório de Recomendação nº<br>978/2025|Atualização de conteúdo -<br>tempo de documento<br>Inclusão<br>de<br>estrogênios<br>conjugados de 0,625 mg|-|-|
|Portaria SAS-SCTIE/MS nº 15, de<br>09 de maio de 2018 [Relatório de<br>Recomendação n° 352/2018]|Atualização<br>devido<br>à<br>ampliação<br>de<br>uso<br>de<br>tecnologias no SUS<br>Inclusão<br>de<br>estrógenos<br>conjugados,<br>medroxiprogesterona e de<br>novas<br>apresentações<br>de<br>somatropina.|Incorporação das<br>apresentações do<br>medicamento somatropina,<br>nas concentrações de 15UI,<br>16UI, 18UI, 24UI e 30UI<br>[Relatório de Recomendação<br>nº 297/2017; Portaria<br>SCTIE/MS nº 47/ 2017]|-|
|Portaria SAS/MS nº 223, de 10 de<br>maio de 2010|Atualização de conteúdo -<br>tempo de documento|-|-|
|Portaria SCTIE/MS nº 72, de 01 de<br>novembro de 2006|Primeira versão do Protocolo<br>Clínico<br>e<br>Diretrizes<br>Terapêuticas da Síndrome de<br>Turner|-|-|

---

