<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: Geral -->
<!-- Start of picture text -->
ae<br>Gey<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 15, de 04 de AGOSTO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Distúrbio Mineral Ósseo na Doença Renal Crônica.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o distúrbio mineral ósseo na doença renal crônica no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com este distúrbio;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 726/2022 e o Relatório de Recomendação ~~n~~<sup><u>o</u></sup> 729 – Maio de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Distúrbio Mineral Ósseo na Doença Renal Crônica. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Distúrbio Mineral Ósseo na Doença Renal Crônica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/pcdt/arquivos/2017/disturbio-mineral-osseo-pcdt.pdf , é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Distúrbio Mineral Ósseo na Doença Renal Crônica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com esse distúrbio em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 801, de 25 de abril de 2017, publicada no Diário Oficial da União nº 80, de 27 de abril de 2017, seção 1, página 71.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO  
SANDRA DE CASTRO BARROS  
ANEXO

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **1. INTRODUÇÃO** -->
A doença renal crônica (DRC) é um problema de saúde pública crescente em todo o mundo e está acompanhada de comorbidades que potencializam o risco de perda da função renal. Dentre essas comorbidades, destacam-se os distúrbios do metabolismo ósseo mineral (DMO), que levam à doença óssea e cardiovascular. Além de poder resultar em fraturas, dor, deformidades ósseas e menor velocidade de crescimento nas crianças, o Distúrbio Mineral Ósseo na Doença Renal Crônica (DMO-DRC) é fator de risco para calcificação vascular e associa-se à miocardiopatia e hipertrofia do ventrículo esquerdo, com consequente aumento do risco para doença cardíaca isquêmica, insuficiência cardíaca e morte por causa cardiovascular. Os mecanismos comuns entre a doença óssea e cardiovascular se apoiam nas crescentes evidências de que alterações na remodelação óssea favorecem o desenvolvimento de calcificações extra ósseas, principalmente vasculares<sup>1-4</sup> .  
As alterações no metabolismo mineral e ósseo são frequentes na DRC e observadas já nos estágios iniciais da DRC, quando a taxa de filtração glomerular está em torno de 60 mL/min, e progridem com o declínio da função renal ( **Tabela 1** )<sup>3</sup> .  
**Tabela 1 -** Classificação da DRC de acordo com a taxa de filtração glomerular  
|**Estágio**|**TFG (mL/min por 1,73m**<sup>**2**</sup>**)**|**Descrição**|
|---|---|---|
|1|> 90|Lesão renal com TFG normal ou aumentada|
|2|60-89|Lesão renal com TFG levemente diminuída|
|3 (A e B)|30-59|TFG moderadamente diminuída|
|4|15-29|TFG gravemente diminuída|
|5|< 15|Falência renal|
|5D|< 15 em diálise|Falência renal em terapia substitutiva|  
TFG: taxa de filtração glomerular.  
Adaptado de _Kidney Disease: Improving Global Outcomes_ (KDIGO), 2017<sup>11</sup> .  
Os níveis de cálcio, fósforo e de seus hormônios reguladores, hormônio da paratireoide (PTH) e calcitriol são alterados por múltiplos fatores. O hiperparatireoidismo secundário (HPTS) é uma das manifestações clássicas dos DMO-DRC, o qual resulta de uma resposta adaptativa às alterações da homeostasia do fósforo e do cálcio decorrente da perda de função renal. Retenção de fósforo e consequentes hiperfosfatemia, hipocalcemia, deficiência de calcitriol, aumento dos níveis séricos de PTH e do fator de crescimento de fibroblastos 23 (FGF-23) e resistência óssea à ação do PTH são mecanismos envolvidos na fisiopatogenia do HPTS decorrente da diminuição da função renal.<sup>6</sup> Embora o HPTS seja a manifestação clássica do DMODRC, doenças de baixa remodelação como a osteomalácia e a doença adinâmica podem estar presentes<sup>5,6</sup> .  
Mais detalhadamente, a vitamina D, o cálcio, o fósforo e o PTH estão fortemente interligados para manter o equilíbrio do metabolismo mineral e ósseo. A ação da vitamina D, mediada pelo receptor de vitamina D (VDR), aumenta a absorção de cálcio e fósforo no trato gastrointestinal e suprime a liberação do PTH na paratireoide. Em pacientes com DRC nos estágios mais avançados, há perda progressiva dos receptores VDR na paratireoide, levando à resistência à vitamina D<sup>6</sup> . O cálcio, via receptor (CaR), atua na paratireoide como principal regulador da secreção do PTH. Quando o cálcio sérico está aumentado, o CaR é ativado e promove a inibição da liberação do PTH na circulação. Com a progressão do HPTS, a hiperplasia da paratireóide tornase mais avançada e a expressão do CaR reduzida. O fósforo inibe a ativação e disponibilização da vitamina D ativa e acarreta na  
redução do cálcio sérico, no aumento da secreção do PTH e na resistência óssea ao PTH que, por sua vez, demanda maiores níveis de PTH para manter a calcemia e a remodelação óssea normais<sup>5</sup> . O PTH exerce função crítica na regulação da concentração de cálcio no sangue. Quando há redução dos níveis de cálcio, o PTH promove sua reabsorção renal e sua liberação a partir do osso. Além disso, aumenta a excreção renal de fósforo, diminuindo seu nível sérico. Assim, o PTH atua, juntamente com outros reguladores de cálcio e fósforo, como a vitamina D3 e FGF-23, na homeostase de minerais<sup>6</sup> .  
No paciente com DRC, a redução da vitamina D ativa disponível e a hipocalcemia levam ao aumento da secreção de PTH pelas paratireoides. A estimulação prolongada da paratireoide pode levar à proliferação de suas células, acarretando em hiperplasia difusa, progressiva e policlonal das glândulas. Conforme a DRC evolui, a hiperplasia da paratireoide pode apresentar um padrão monoclonal benigno, que evolui para hiperplasia nodular. Nesse caso, as glândulas paratireoides apresentam expressão reduzida dos receptores CaR e VDR e se tornam resistentes ao tratamento clínico, sendo indicada a paratireoidectomia (PTx)<sup>3</sup> .  
Segundo o censo de 2020 da Sociedade Brasileira de Nefrologia, estima-se que 144.779 pacientes se encontram em diálise, sendo que aproximadamente 93% estão em hemodiálise. Destes, aproximadamente 32% apresentavam hiperfosfatemia e 18% apresentavam níveis de PTH acima de 600 pg/mL.<sup>7-8</sup> Nos últimos anos, a hiperfosfatemia tornou-se mais relevante na DRC, devido à sua associação com a calcificação extra óssea e mortalidade, principalmente de causa cardiovascular. O controle do fósforo sérico tem sido um dos maiores desafios para os nefrologistas em todo o mundo e o uso de quelantes de fósforo a base de cálcio ou não se torna imperativo. Da mesma forma, análogos da vitamina e calcimiméticos tornam-se necessários para o controle dos níveis do PTH<sup>1-4</sup> . Dada a complexidade do DMO-DRC, vários estudos, incluindo ensaios clínicos randomizados (ECR), revisões sistemáticas (RS) e diretrizes têm sido publicados.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do Distúrbio Mineral Ósseo na Doença Renal Crônica. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- N18.2 - DRC estágio 2  
- N18.3 - DRC estágio 3  
- N18.4 - DRC estágio 4  
- N18.5 - DRC estágio 5  
- N25.0 - Osteodistrofia Renal

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **3.1. Diagnóstico clínico** -->
A maioria dos pacientes é assintomática até os estágios avançados do DMO-DRC, motivo pelo qual recomenda-se iniciar a monitorização laboratorial mesmo em pacientes sem sinais clínicos (vide item diagnóstico laboratorial), para que o diagnóstico possa ser realizado previamente à manifestação clínica<sup>2-4</sup> .  
Nos estágios avançados do DMO-DRC, quando os pacientes já se encontram em terapia renal substitutiva (TRS), sinais e sintomas como dores ósseas e articulares, mialgia, fraqueza muscular, fraturas, ruptura de tendões, prurido, calcificações extra esqueléticas e calcifilaxia podem estar presentes. Em crianças, são comuns as deformidades ósseas e o atraso no crescimento. **3.2. Diagnóstico laboratorial**  
A monitorização laboratorial dos níveis séricos de vitamina D, cálcio, fósforo, PTH e fosfatase alcalina (FA) deve ser iniciada a partir do estágio 3 da DRC em adultos e do estágio 2 em crianças<sup>11</sup> .  
Segundo consensos e diretrizes de sociedades de nefrologia canadense, japonesa, brasileira e _Kidney Disease: Improving Global Outcomes_ (KDIGO) 2017<sup>11-14</sup> , embora não existam evidências de que a mensuração de rotina melhora o prognóstico dos pacientes, as recomendações da periodicidade da monitorização dos níveis de vitamina D, cálcio, fósforo, PTH e fosfatase alcalina são descritas na **Tabela 2** , de acordo com o estágio da DRC.  
**Tabela 2** - Monitorização dos níveis séricos de 25-hidroxivitamina D, cálcio total, fósforo, PTH e fosfatase alcalina de acordo com o estágio da DRC.  
|**DRC**|**25-hidroxivitamina**<br>**D (UI)**|**Cálcio total**<br>**(mg/dL)**|**Fósforo**<br>**(mg/dL)**|**PTH**<br>**(pg/mL)**|**Fosfatase**<br>**alcalina (UI/l)**|
|---|---|---|---|---|---|
|Estágio 3*|anual|anual|anual|anual|anual**|
|Estágio 4|semestral|semestral|semestral|semestral|anual**|
|Estágio 5 não dialítico|semestral|trimestral|trimestral|semestral|semestral**|
|Estágio 5D em diálise|semestral|mensal|mensal|trimestral|trimestral|  
*Se crianças, a partir do estágio 2; ** ou mais frequentemente, se PTH elevado.  
DRC: doença renal crônica; PTH: hormônio da paratireoide. **Fontes** : KDIGO, 2017<sup>11</sup> ; Holden _<mark>et al.</mark> ,_ 2017<sup>12</sup> ; Fukagawa _<mark>et al</mark>_ <mark>.,</mark> 2013<sup>13</sup> , LUCCA _et al_ ., 2021<sup>14</sup> .  
O diagnóstico e posteriores decisões terapêuticas devem ser feitos preferencialmente baseados em medidas repetidas observando as tendências das alterações, e não em medidas únicas. Deve-se também atentar para as diferenças entre os métodos pelos laboratórios, inclusive para os distintos valores de referência. O diagnóstico da hiperfosfatemia é laboratorial, sendo utilizado o ponto de corte de 4,5 mg/dL de fósforo sérico; porém, nos pacientes em diálise, é considerado aceitável nível de fósforo sérico de até 5,5 mg/dL. O cálcio sérico deve ser mantido nos limites da normalidade, geralmente entre 8,5 a 10 mg/dL. Em pacientes pediátricos, os limites séricos de cálcio e fósforo por faixa etária estão descritos na **Tabela 3** . Quanto ao PTH, embora seu valor para predizer o diagnóstico de HPTS seja controverso, valores de PTH acima de 300 pg/mL têm sido adotados como indicativo deste diagnóstico pelas diretrizes mais recentes para os pacientes com DRC em TRS<sup>2,11-14</sup> .  
**Tabela 3** - Valores séricos normais de cálcio total, cálcio iônico e fósforo com relação à faixa etária  
|**Faixa etária**|**Cálcio Total (mg/dL)**|**Cálcio iônico (mmol/L)**|**Fósforo (mg/dL)**|
|---|---|---|---|
|0-11 meses|8,8-11,3|1,22-1,40|4,8-7,4|
|1-5 anos|9,4-10,8|1,22-1,32|4,5-6,5|
|6-12 anos|9,4-10,3|1,15-1,32|3,6-5,8|
|13-18 anos|8,8-10,2|1,12-1,30|2,3-4,5|  
**Fonte** : Adapatado de KDIGO, 2017<sup>11</sup> .  
O Grupo de Trabalho elaborador do KDIGO 2017<sup>11</sup> reconheceu que há informações emergentes sobre o potencial papel da deficiência e insuficiência de vitamina D na patogênese ou agravamento de doenças múltiplas. Além disso, a deficiência e a insuficiência de vitamina D podem ter um papel na patogênese do hiperparatireoidismo (HPT). Os riscos potenciais de reposição de vitamina D são mínimos e, portanto, apesar do benefício incerto, a dosagem e a administração da vitamina D podem ser benéficas. A prevalência de insuficiência ou deficiência de vitamina D varia de acordo com a definição utilizada. A maioria dos estudos define deficiência como valores séricos de 25-hidroxivitamina D (calcidiol) menores que 15 ng/mL (25 nmol/L) e insuficiência como valores entre 15 e 30 ng/mL (50 a 80 nmol/L)<sup>11</sup> . No entanto, não há consenso sobre o que define os níveis adequados de vitamina D ou níveis tóxicos de vitamina D.  
O mesmo grupo também recomenda que a dosagem da FA no diagnóstico e na avaliação de DMO-DRC pode ser um dado adicional, mas se os valores estiverem acima do limite superior da normalidade, deve ser feita avaliação de função hepática. Além disso, os níveis séricos de FA podem ser usados para acompanhar a resposta ao tratamento ou para avaliar a remodelação óssea quando a interpretação do PTH não está clara<sup>11</sup> .

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos, neste PCDT, pacientes crianças e adultos com diagnóstico de DMO secundário à DRC.  
Para o **tratamento da hiperfosfatemia com quelantes à base de cálcio (carbonato de cálcio)** , o paciente deve apresentar um dos seguintes critérios de elegibilidade para o uso:

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: Adultos -->
- DRC estágios 3 a 5 com fósforo acima de 4,5 mg/dL, sem hipercalcemia (cálcio sérico corrigido para albumina sérica)  
- e sem calcificação vascular;  
- DRC estágio 5D com fósforo acima de 5,5 mg/dL, sem hipercalcemia (cálcio sérico corrigido para albumina sérica) e  
- sem calcificação vascular e com PTH acima de 300 pg/mL.  
Crianças e adolescentes  
- DRC estágios 1 a 4 não dialítica com níveis de fósforo acima dos limites normais para a faixa etária, sem hipercalcemia  
- (cálcio sérico corrigido para albumina sérica) e sem calcificação vascular;  
- DRC estágios 5 não dialítica ou em diálise com níveis de fósforo acima de 6,0 mg/dL (1 a 12 anos) e acima de 5,5 mg/dL  
(12 a 18 anos), sem hipercalcemia (cálcio sérico corrigido para albumina sérica) e sem calcificação vascular.  
Para o **tratamento da hiperfosfatemia com quelantes não à base de cálcio (cloridrato de sevelâmer)** , o paciente deve apresentar um dos seguintes critérios de elegibilidade para o uso:  
- DRC em fase não dialítica com níveis de fósforo acima de 4,5 mg/dL;  
- DRC em fase dialítica com níveis de fósforo acima de 5,5 mg/dL; ou  
- Pacientes com contraindicação ao uso de quelantes a base de cálcio.  
Crianças e adolescentes  
- DRC estágios 2 a 4 não dialítica com níveis de fósforo acima dos limites normais para a faixa etária e com cálcio sérico  
- corrigido para albumina normal ou acima do normal com ou sem uso de quelantes à base de cálcio; ou  
- DRC estágios 5 não dialítica ou em diálise com níveis de fósforo acima de 6,0 mg/dL (1 a 12 anos) e acima de 5,5 mg/dL  
(12 a 18 anos) e com cálcio sérico corrigido para albumina normal ou acima do normal, com ou sem uso de quelantes à base de cálcio.  
Além de pelo menos um dos critérios acima, os pacientes devem estar em acompanhamento com nutricionista.  
**Para o tratamento do HPTS** , o paciente deve apresentar um dos seguintes critérios de elegibilidade para o uso:

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: <mark>Para o medicamento</mark> **<mark>calcitriol</mark>** <mark>:</mark> -->
- Crianças com DRC estágios 2 a 5D com níveis séricos de PTH acima do limite superior da normalidade;  
- Adultos portadores de DRC estágio 3A a 5 com níveis séricos de PTH acima dos valores da normalidade;  
- Pacientes com sídrome da fome óssea após realização de paratireoidectomia;  
- Pacientes em diálise peritoneal com níveis séricos de PTH acima de 300 pg/mL.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: <mark>Para o medicamento</mark> **<mark>paricalcitol</mark>** <mark>:</mark> -->
- Pacientes adultos com DRC 5D com níveis séricos de PTH igual ou acima de 300 pg/mL e com normo- ou hipocalcemia.  
<mark>Para o medicamento</mark> **<mark>cinacalcete</mark>** <mark>:</mark>  
- Pacientes adultos com DRC em diálise há pelo menos 3 meses, com níveis séricos de PTH igual ou acima de 300 pg/mL  
- e na ausência de hipocalcemia;  
- Pacientes adultos transplantados renais com níveis séricos de PTH igual ou acima de 120 pg/mL;  
- Pacientes adultos transplantados renais com hipercalcemia.  
**Para o diagnóstico ou tratamento da intoxicação por alumínio com desferroxamina (DFO)** , o paciente deve apresentar um dos seguintes critérios de elegibilidade para o uso:  
- Para realização de teste para diagnóstico de excesso de alumínio: pacientes que apresentam dosagem sérica não estimulada de alumínio elevada (60 a 200 mcg/L) ou sinais e sintomas clínicos sugestivos de intoxicação por alumínio. Deve também ser realizada previamente à paratireoidectomia, quando o paciente tem história de exposição ao alumínio;  
- Para realização de tratamento da intoxicação alumínica: pacientes elegíveis para o tratamento com DFO são aqueles com diagnóstico de intoxicação alumínica, detectada por depósito de alumínio em biópsia óssea, independentemente do tipo histológico da doença óssea. Além disso, os pacientes sintomáticos com diagnóstico de intoxicação por alumínio após teste positivo com DFO são elegíveis para esse tratamento.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo pacientes gestantes ou lactantes com DMO-DRC estágios 2 a 5D. Também serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo. Adicionalmente, serão excluídos do uso do referido medicamento os pacientes que apresentem, pelo menos, um dos seguintes critérios:  
- Para os **quelantes à base de cálcio (carbonato de cálcio):** hipercalcemia. O seu uso também deve ser evitado se nível sérico de PTH inferiores a 150 pg/mL.  
- Para o **calcitriol:** hiperfosfatemia ou hipercalcemia (nível sérico corrigido para albumina).  
- Para o **paricalcitol:** hiperfosfatemia ou hipercalcemia, DRC estágios 3 a 5, crianças.  
- Para o **cinacalcete:** hipocalcemia, DRC estágios 3 a 5, pacientes transplantados renais com hipercalcemia de etiologias  
- não relacionadas ao HPTS.  
- Para a **desferroxamina:** concentrações séricas de alumínio não estimuladas maiores que 200 mcg/L (risco de neurotoxicidade). Esses pacientes devem ter seu programa de TRS intensificado para diminuição do nível de alumínio antes de receber a DFO.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6. TRATAMENTO** -->
O tratamento do DMO-DRC inclui intervenções não medicamentosas, direcionadas principalmente para o tratamento da hiperfosfatemia, e medicamentosas, com o objetivo de corrigir as alterações do metabolismo mineral e ósseo durante o curso da DRC. Dentre os medicamentos que podem ser utilizados, estão os quelantes de fósforo e aqueles utilizados no tratamento do HPTS, tais como vitamina D, análogos de vitamina D e cinacalcete.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.1. Tratamento não medicamentoso** -->
<mark>De acordo com diretrizes nacionais e internacionais</mark><sup>11-14</sup> <mark>, o tratamento da hiperfosfatemia secundária à DRC envolve o tratamento não medicamentoso, que inclui dieta com restrição de fósforo (800 a 1.000 mg ao dia) e adequação dialítica.</mark>  
A concentração do cálcio da diálise interfere no balanço de cálcio no organismo e pode alterar o nível de cálcio sérico e o metabolismo mineral e <mark>ósseo. A concentração de cálcio do dialisato deve ser individualizada conforme as necessidades de cada paciente; no entanto, a melhor concentração em cada situação permanece em discussão. O uso de uma concentração de cálcio do dialisato de 3,0 mEq/L tem sido associado com um balanço neutro de cálcio. Concentrações mais baixas de cálcio do dialisato, como de 2,5 mEq/L, podem promover balanço negativo na maioria dos pacientes e deveriam ser usadas para os pacientes com nível sérico de PTH inferior a 150 pg/mL ou nos casos de hipercalcemia. No entanto, o uso continuado dessa concentração mais baixa de cálcio pode levar à progressão do HPTS. Uma concentração de cálcio do dialisato de 3,5 mEq/L pode levar a um balanço positivo de cálcio e deve ser evitada na maioria dos pacientes em TRS, principalmente nos casos de hipercalcemia, níveis suprimidos de PTH e em pacientes usando calcitriol ou paricalcitol</mark><sup>11-14</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2. Tratamento medicamentoso** -->
O tratamento medicamentoso do DMO-DRC consiste controle da hiperfosfatemia, com o uso de quelantes de fósforo, e no tratamento do HPTS, com o uso da vitamina D, análogos de vitamina D não seletivos e seletivos e cinacalcete.  
A quelação do fósforo é um tratamento recomendado no DMO-DRC para controle da hiperfosfatemia, o qual envolve o uso de medicamentos quelantes à base de cálcio e de quelantes não à base de cálcio, como o sevelâmer. Os quelantes à base de cálcio são preconizados por este Protocolo para pacientes adultos com DRC estágios 3 a 5 com nível de fósforo acima de 4,5 mg/dL ou para pacientes com DRC estágio 5D com fósforo acima de 5,5 mg/dL, sem hipercalcemia (cálcio sérico corrigido para albumina sérica), sem calcificação vascular e com nível sérico de PTH acima de 300 pg/mL. Também é recomendado para crianças e adolescentes com DRC estágios 1 a 5 com níveis de fósforo acima dos limites normais para a faixa etária sem hipercalcemia (cálcio sérico corrigido para albumina sérica) e sem calcificação vascular.  
Quanto ao sevelâmer, a revisão sistemática de Phannajit e colaboradores (2021)<sup>31</sup> mostrou que em pacientes com DRC estágio 5D e hiperfosfatemia, o uso de sevelâmer comparado com os quelantes à base de cálcio (carbonato e acetato de cálcio) foi fator de proteção para calcificação vascular de pacientes dialíticos e associado com reduções significativas da mortalidade geral, das taxas de hospitalização e da ocorrência de hipercalcemia. Diante da análise dessas evidências e em concordância com as diretrizes nacional e internacionais<sup>11-14</sup> , o sevelâmer e o carbonato de cálcio devem ser medicamentos de primeira linha para tratar pacientes com hiperfosfatemia secundária à DRC e a escolha do quelante dependerá dos níveis de cálcio e do PTH. O carbonato de cálcio deve ser o medicamento de primeira escolha para pacientes adultos com DRC estágios 3 a 5 com nível de fósforo acima de 4,5 mg/dL, na ausência de hipercalcemia e da calcificação vascular e para pacientes com DRC estágio 5D com nível de fósforo acima de 5,5 mg/dL, sem hipercalcemia e sem calcificação vascular e com nível de PTH acima de 300 pg/mL. Já o sevelâmer deve ser a opção de primeira escolha para pacientes adultos com DRC em fase não dialítica e níveis de fósforo acima de 4,5 mg/dL ou em fase dialítica com níveis de fósforo acima de 5,5 mg/dL.  
Para o tratamento do HPTS, calcimiméticos, calcitriol e paricalcitol são terapias aceitáveis para pacientes com DRC 5D e a escolha do tratamento deve ser guiada pelos níveis de PTH, dose e uso concomitante de outros medicamentos, bem como pelos níveis de cálcio e fósforo. Paricalcitol e cinacalcete não são terapias concorrentes e sim complementares, sendo paricalcitol a primeira opção quando o nível sérico de PTH estiver em ascensão e acima de 300 pg/mL na ausência de hipercalcemia e hiperfosfatemia. Quando o nível sérico de PTH estiver em ascensão e acima de 300 pg/mL na presença de hipercalcemia e hiperfosfatemia, cinacalcete é a primeira opção. O uso associado de paricalcitol e cinacalcete deve ocorrer quando, após três meses de uso de um destes medicamentos, o PTH alvo entre 150 e 300 pg/mL não é atingido, na ausência de contraindicação do outro medicamento (paricalcitol ou cinacalcete) e com dieta, quelante de fósforo e diálise adequados<sup>49</sup> .  
O cinacalcete é considerado primeira linha de tratamento para pacientes adultos com DRC em diálise há pelo menos 3 meses, com níveis séricos de PTH iguais ou acima de 300 pg/mL e na ausência de hipocalcemia, e; para pacientes adultos transplantados renais com níveis séricos de PTH iguais ou acima de 120 pg/mL ou com hipercalcemia<sup>11-14,49</sup> .  
Quanto ao paricalcitol, uma revisão sistemática recente indicou benefício na sobrevida dos pacientes em diálise quando comparado ao calcitriol, sendo considerado tratamento de primeira linha para pacientes adultos com DRC 5D com nível sérico de PTH igual ou acima de 300 pg/mL e com normo ou hipocalcemia.  
Já o calcitriol é o medicamento de primeira escolha para crianças com DRC estágios 2 a 5D com níveis séricos de PTH acima do limite superior da normalidade; para pacientes adultos portadores de DRC estágio 3A a 5 com níveis séricos de PTH acima dos valores da normalidade; na síndrome de fome óssea (pós paratireoidetomia) e para os pacientes em diálise peritoneal com níveis séricos de PTH acima de 300 pg/mL<sup>45</sup> .  
Por fim, para o diagnóstico e tratamento da intoxicação por alumínio em pacientes com DMO-DRC é indicado o uso de desferroxamina.  
O fluxo de tratamento da hiperfosfatemia e do HPTS secundário à DRC em pacientes em diálise e com PTH acima de 300 pg/mL, de acordo com os níveis de cálcio e fósforo está representado na **Figura 1** .  
**Figura 1** – Conduta terapêutica do hiperpatireoidismo secundário à doença renal crônica de acordo com os níveis de cálcio e fósforo.  
<!-- Start of picture text -->
‘vale cleo do dialisato cinacalcete cinacalcete<br>~considere aterar Cinecaleete sevelémer sevelamer<br>10,0 Alvo de calcio e fésforo cinacalcete<br>Calcio sérico | paricalcitol<br>(mg/dl) cinacalcete ou paricalcitol sevelamer<br>84 0 do cdl<br>be paricalcitol ou do fésforo para iniciar<br>slei cinacalcete ou paricalcitol<br>| aricalctol aguardar normalizacao do calcio<br>| Avalie ~eonsidere= cic “o alerar  dialisato ma] carbonato derefeicées calcio&  entre as sevelamer. ou carbonato de calcio; carbonato de célcio<br>—————————_———<br>‘alie 35 6,0 -<br>®estadoconsumo nutriionalde alimentos Fésforo sérico vallesien eamingestio.torode©<br>(mg/dL)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2.1. Quelantes de Fósforo** -->
<mark>O tratamento</mark> medicamentoso <mark>da hiperfosfatemia secundária à DRC consiste no uso de quelantes, os quais</mark> estão disponíveis no mercado brasileiro em duas classes: quelantes à base de cálcio (carbonato ou acetato de cálcio) e o não à base de cálcio (sevelâmer), sendo disponibilizados pelo SUS representantes dessas duas classes. O carbonato de cálcio e o cloridrato de sevelâmer são os quelantes intestinais de fósforo disponíveis e mais utilizados.  
O carbonato de cálcio é a primeira escolha entre os quelantes de fósforo contendo cálcio, cujo mecanismo de ação é quelar o fósforo oriundo da dieta na luz intestinal, diminuindo sua absorção no tubo digestivo. O principal problema associado ao uso de quelantes à base de cálcio é a possibilidade de sobrecarga de cálcio e episódios transitórios de hipercalcemia, o que exige a redução da dose de análogos da vitamina D e o ajuste da concentração de cálcio na solução de diálise<sup>15-18</sup> . Em uma meta-análise da Cochrane, o uso de carbonato de cálcio diminuiu o nível sérico de fósforo quando comparado com o uso de placebo em média em 0,82 mg/dL (IC95% -1,24 a -0,4). Entretanto, o uso desses medicamentos elevou o nível sérico de cálcio em média em 0,52 mg/dL (IC95% 0,13 a 0,91)<sup>19</sup> .  
O cloridrato de sevelâmer é um polímero quelante de fósforo que não contém cálcio nem alumínio. Como não é absorvido no intestino, é uma alternativa ao carbonato de cálcio para o controle da hiperfosfatemia em pacientes com DRC em estágios avançados. Os estudos clínicos com esse medicamento foram, na sua maioria, realizados em pacientes em TRS. Quando  
comparado com placebo, esse medicamento foi mais efetivo em diminuir o nível de fósforo<sup>20-24</sup> . Em uma meta-análise que incluiu ECR e estudos observacionais para avaliar o efeito do sevelâmer em parâmetros do metabolismo mineral e no perfil lipídico em pacientes em TRS, o tratamento com sevelâmer foi associado com redução de 2,14 mg/dL no nível sérico de fósforo (P<0,001) e de 35,9 pg/mL do nível sérico de PTH (P=0,026). Além disso, o uso do sevelâmer associou-se à diminuição do produto cálciofósforo (P<0,001) sem causar alterações no nível sérico de cálcio e à diminuição dos valores de LDL<sup>25</sup> . Também foi demonstrado que o sevelâmer diminuiu o nível sérico de fósforo, em média, em 1,80 mg/dL (IC95% -3,32 a -0,28) sem resultar em hipercalcemia<sup>19</sup> . Não houve redução na mortalidade.  
Como o sevelâmer diminui o nível de fósforo e não aumenta o de cálcio, sugere-se que o uso desse medicamento possa evitar ou retardar calcificações extra esqueléticas, principalmente em vasos. Pela existência de dados na literatura associando a presença de calcificações vasculares com aumento do risco de eventos cardiovasculares e da mortalidade<sup>24-30</sup> , postulou-se que a utilização de quelantes livres de cálcio poderia diminuir a mortalidade desses pacientes. Sobre o tratamento de pacientes com hiperfosfatemia, a revisão sistemática de Ruospo e colaboradores (2018)<sup>30</sup> mostrou menor mortalidade com uso de sevelâmer quando comparado ao uso carbonato de cálcio. Contudo, dada a fragilidade dessa evidência (diferentes tempos de acompanhamento e significativa heterogeneidade), o carbonato de cálcio continua sendo a primeira escolha dentre os quelantes de fósforo.  
Os pacientes em uso de carbonato de cálcio devem passar a utilizar o cloridrato de sevelâmer se apresentarem uma das seguintes condições: se persistirem com níveis elevados de fósforo ou apresentarem cálcio sérico elevado, após a suspensão ou ajustes na dose de análogos da vitamina D (quando em uso de vitamina D); se apresentarem redução dos níveis de cálcio no dialisato, ou seja, concentração de cálcio de 2,5 mEq/L, se possível, em pacientes com hipercalcemia ou apresentarem níveis séricos de PTH abaixo de 150 pg/mL.  
Na revisão sistemática de Phannajit e colaboradores (2021)<sup>31</sup> foram avaliadas a segurança e eficácia dos quelantes de fósforo para tratar hiperfosfatemia em pacientes com DRC dialítica e não dialítica. Em pacientes com DRC estágio 5D, o uso de sevelâmer, comparado com os quelantes à base de cálcio (carbonato e acetato de cálcio), foi considerado fator de proteção para calcificação vascular de pacientes dialíticos (DMP -0,254; IC95% -0,420 a 0,088; P=0,003) e associado com reduções significativas da mortalidade geral (RR 0,594; IC95% 0,363 a 0,972; P= 0,038), das taxas de hospitalização (RR 0,458; IC95% 0,264 a 0,794; P=0,005) e da ocorrência de hipercalcemia (RR 0,29; IC95% 0,19 a 0,45; P< 0,00001).  
Diante da análise dessas evidências e em concordância com as diretrizes nacional e internacionais<sup>11-14</sup> , o sevelâmer e o carbonato de cálcio devem ser medicamentos de primeira linha para tratar pacientes com hiperfosfatemia secundária à DRC e a escolha do quelante dependerá dos níveis de cálcio e do PTH.  O carbonato de cálcio deve ser o medicamento de primeira escolha para pacientes adultos com DRC estágios 3 a 5 com fósforo acima de 4,5 mg/dL, na ausência de hipercalcemia e da calcificação vascular e para pacientes com DRC estágio 5D com fósforo acima de 5,5 mg/dL, sem hipercalcemia e sem calcificação vascular e com PTH acima de 300 pg/mL. Já o sevelâmer deve ser a primeira escolha para pacientes adultos com DRC em fase não dialítica e níveis de fósforo acima de 4,5 mg/dL ou em fase dialítica com níveis de fósforo acima de 5,5 mg/dL. Para tratar pacientes não dialíticos, quelantes à base de cálcio devem ser evitados se o nível sérico de PTH estiver inferior a 150 pg/mL.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2.2. Análogos da vitamina D** -->
Os análogos da vitamina D são utilizados em pacientes com DRC nos estágios 3 a 5D para corrigir as alterações no metabolismo mineral e ósseo e reduzir o risco ou a progressão de HPTS. O calcitriol é a forma ativa da vitamina D (1,25-OH2vitamina D). Já o alfacalcidol é um análogo sintético da vitamina D3 e requer hidroxilação hepática para ser transformado na forma ativa da vitamina D (pró-fármaco) enquanto o paricalcitol é um composto sintético cuja estrutura foi desenvolvida a partir da vitamina D2 natural, sendo um ativador seletivo do VDR. No Brasil, o calcidiol e o calcitriol intravenoso foram descontinuados  
do mercado em 2017 e 2021, respectivamente. Assim, permanecem disponíveis no SUS o calcitriol via oral e o paricalcitol intravenoso.  
Diretrizes nacionais e internacionais estabelecem os limites para os principais parâmetros referentes ao tratamento do HPTS na DRC<sup>11-14</sup> . Segundo o KDIGO 2017<sup>11</sup> , em pacientes com DRC estágios 3A a 5, o nível ideal de PTH não é conhecido. No entanto, essa referida diretriz que pacientes com níveis de PTH aumentando progressivamente ou persistentemente acima do limite superior sejam avaliados quanto a fatores modificáveis, incluindo hiperfosfatemia, hipocalcemia, alta ingestão de fosfato e deficiência de vitamina D. O uso de calcitriol e análogos seletivos de vitamina D não deve ser rotineiro, e sim reservado aos pacientes com DRC estágios 4 e 5 com HPTS grave e progressivo, sem definir os valores de PTH<sup>11-14</sup> .  
<mark>Na revisão sistemática de Natoli e colaboradores (2013)</mark><sup>32</sup> <mark>foi avaliada a associação entre mortalidade e níveis de PTH, fósforo e cálcio. Os níveis superiores de fósforo (4 estudos; RR 1,20; IC95% 1,15 a 1,25), cálcio (3 estudos; RR 1,10; IC95% 1,05 a 1,14) e PTH (5 estudos; RR 1,11; IC95% 1,07 a 1,16) foram significativamente associados com aumento da mortalidade. Em todos os estudos, os valores médios de PTH considerados como referência foram 225 a 250 pg/mL, com exceção do realizado por Dukkipati e colaboradores (2010)</mark><sup>33</sup> <mark>que adotou 300 a 600</mark> pg/mL.  
O KDIGO 2017<sup>11</sup> , embora não estabeleça valores exatos para o início do tratamento do HPTS, sugere que as tendências de variação do PTH sejam monitorizadas com cuidado. Ao iniciar o tratamento do HPTS apenas quando os níveis de PTH estiverem 9 vezes acima do limite superior, a chance de falência do tratamento clínico aumenta. Portanto, este Protocolo preconiza o tratamento quando os níveis de PTH estiverem em ascensão, mesmo que dentro da faixa considerada segura, de modo a aumentar as chances de sucesso no controle do HPTS.  
Além do KDIGO (2017)<sup>11</sup> , o Canadá, o Japão e o Brasil também estabeleceram suas próprias <mark>recomendações para controlar o HPTS em pacientes com DRC 5D, conforme descrito na</mark> **<mark>Tabela 4</mark>** <mark>.</mark>  
**<mark>Tabela 4 -</mark>** <mark>Recomendações dos valores de referência para níveis séricos de PTH em pacientes com DRC 5D de acordo com diferentes diretrizes</mark>  
|**Parâmetro**|**KDIGO 2017;** **Canadian Society, 2020; SBN, 2021**|**Japanese Society, 2013**|
|---|---|---|
|**PTH**|2 a 9 vezes o limite superior do método|60 a 240 pg/mL|  
SBN: Sociedade Brasileira de Nefrologia.  
**Fonte** : KDIGO, 2017<sup>11</sup> ; Holden _<mark>et al.</mark> ,_ 2017<sup>12</sup> ; Fukagawa _<mark>et al</mark>_ <mark>.,</mark> 2013<sup>13</sup> , Lucca _et al_ ., 2021<sup>14</sup> .  
Pacientes com DRC estágios 3-5 que não estejam em TRS e que tenham o nível sérico de PTH acima do limite superior do método devem ser tratados, inicialmente, para corrigir hiperfosfatemia, hipocalcemia e deficiência de vitamina D<sup>34-36</sup> . Devemse suspeitar de deficiência de vitamina D se o paciente apresentar fatores de risco, tais como não se expor ao sol ou residir em região geográfica do país onde tenha sido identificada deficiência de vitamina D por estudos epidemiológicos. Poucos são os estudos de base populacional sobre prevalência de hipovitaminose D no Brasil, destacando-se um estudo transversal em 120 pacientes com DRC estágios 2-5 não submetidos à TRS. Destes, 55% apresentavam hipovitaminose D e a presença de diabete melito e obesidade foram fatores de risco para hipovitaminose D nessa amostra de pacientes. Além disso, níveis séricos de PTH mais elevados foram associados com níveis menores de vitamina D<sup>34</sup> . Segundo as diretrizes internacionais mais recentes<sup>11-14</sup> , recomenda-se a suplementação com vitamina D2 ou D3 nos pacientes com DRC quando:  
- 25-hidroxivitamina D menor que 20 ng/mL: 50.000 UI de vitamina D2 ou D3 via oral, uma vez por semana durante 6 a  
- 8 semanas. Depois, administração mensal de 50.000 UI durante 6 meses.  
- 25-hidroxivitamina D entre 20 a 30 ng/mL: 50.000 UI por mês durante 6 meses.  
Os pacientes em que o nível sérico de PTH não estiver normalizado após medidas para correção da hiperfosfatemia, hipocalcemia ou deficiência de vitamina D e que tenham um aumento progressivo do nível sérico de PTH, devem iniciar o uso de análogos de vitamina D.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2.3. Calcitriol** -->
As evidências de que o uso do calcitriol com consequente melhora nos desfechos laboratoriais e histológicos resulta em melhores desfechos clínicos ainda são limitadas. Duas revisões sistemáticas com meta-análises publicadas em 2008 e 2009 que incluíram ECR e estudos observacionais mostraram que pacientes tratados com análogos de vitamina D (calcitriol, alfacalcidol e medicamentos mais recentes como paricalcitol, doxercalciferol, maxacalcitol e falecalcitriol) apresentaram redução dos níveis séricos de PTH de forma significativa comparados ao uso de placebo; no entanto, níveis de cálcio e fósforo aumentaram. Os dados sobre o impacto do uso desses medicamentos na mortalidade e no prognóstico cardiovascular foram insuficientes, não permitindo conclusões com relação a esses desfechos<sup>35-39</sup> .  
Quanto à mortalidade, uma revisão sistemática mostrou que pacientes que receberam vitamina D apresentaram mortalidade menor comparados com aqueles sem tratamento (HR 0,71; IC95% 0,57 a 0,89; P<0,001). Os participantes que receberam calcitriol (HR 0,63; IC95% 0,50 a 0,79; P<0,001) e paricalcitol (HR 0,43; IC95% 0,29 a 0,63; P<0,001) apresentaram menor risco de morte cardiovascular. Além disso, os pacientes em uso de paricalcitol apresentaram maior sobrevida do que aqueles recebendo calcitriol (HR 0,95; IC95% 0,91 a 0,99; P<0,001)<sup>36</sup> . Entretanto, essa meta-análise apresenta limitações importantes, como a falta de ECR incluídos, heterogeneidade e poder limitado dos estudos. Dessa forma, não é possível concluir de forma mais consistente que o uso de análogos da vitamina reduz os desfechos de mortalidade por qualquer causa cardiovascular.  
O calcitriol pode ser administrado por via oral ou intravenosa, entretanto, a apresentação intravenosa não se encontra mais disponível no Brasil. Há evidências acerca do uso das duas vias de administração<sup>40-41</sup> . Uma revisão sistemática com metaanálise<sup>39</sup> mostrou superioridade da via intravenosa para supressão do PTH, porém esse estudo apresentava heterogeneidade significativa, tornando seus resultados questionáveis. Por outro lado, outra revisão sistemática com meta-análise, que comparou a administração de calcitriol de forma intermitente por via endovenosa ou oral, não mostrou diferenças de efetividade e segurança. Novamente, uma série de limitações foram descritas como problemas metodológicos e tamanho da amostra<sup>41</sup> . Dessa forma, não parece haver diferenças entre as vias de administração quanto aos desfechos bioquímicos.  
Diante da análise das evidências e em concordância com as diretrizes nacional e internacionais<sup>11-14</sup> , nos pacientes adultos com HPTS à DRC estágios 3 a 5, em pacientes cujos níveis séricos de PTH permanecerem elevados a despeito da correção da hipocalcemia, hiperfosfatemia ou deficiência de vitamina D, o calcitriol via oral deve ser iniciado na dose de 0,5 a 3 μcg/dia.  
Nos pacientes com DRC submetidos à paratireoidectomia, pode ser necessário o uso de calcitriol no pós-operatório no caso de desenvolvimento de síndrome de fome óssea<sup>42-44</sup> . O uso desse fármaco já foi avaliado para essa situação específica, demonstrando que os pacientes que receberam calcitriol tiveram hipocalcemia menos grave e necessitaram de menores doses de suplementação com cálcio quando comparados com os pacientes que receberam placebo. Pela gravidade desse quadro, os pacientes submetidos à paratireoidectomia devem ser adequadamente monitorizados e recomenda-se que o calcitriol seja iniciado, com as doses ajustadas de acordo com os níveis séricos de cálcio total e de fósforo.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2.4. Paricalcitol** -->
O paricalcitol, um análogo seletivo da vitamina D, foi incorporado ao SUS em 2015, sendo contemplado como segunda linha de tratamento para pacientes com HPTS à DRC, em diálise. Na época da sua incorporação, foram analisados três estudos observacionais que avaliaram os desfechos de hospitalização e mortalidade, um estudo clínico e uma revisão sistemática.  
O paricalcitol é uma alternativa de tratamento de HPTS para pacientes com DRC 5D com níveis séricos de PTH igual ou superior a 500 pg/mL e que apresentem hipercalcemia ou hiperfosfatemia com uso de calcitriol em, pelo menos, duas tentativas de tratamento, apesar da dieta e diálise adequadas e uso apropriado de quelantes de fósforo; ou para pacientes com DRC 5D com níveis séricos de PTH persistentemente superior a 500 pg/mL sem resposta após 3 meses de tratamento com calcitriol.  
Acredita-se que quando o PTH se encontra acima de 500 pg/mL, a chance de resposta ao tratamento é reduzida, devendo ser introduzido medicamento injetável. Como a apresentação intravenosa do calcitriol foi descontinuada, foi revisada a indicação de novos pontos de corte tanto do paricalcitol como do cinacalcete para pacientes com DRC estágio 5, considerando-se também os níveis de cálcio e fósforo<sup>4,11</sup> .  
A ampliação de uso de paricalcitol para o tratamento de pacientes com PTH acima de 300 pg/mL foi avaliada pela Conitec e obteve recomendação final favorável à ampliação conforme Relatório de Recomendação nº 703/2022. Assim, recomenda-se o uso de paricalcitol, na dose de 0,04 a 0,1 ucg/kg/dose, em pacientes adultos com HPTS à DRC estágio 5D em que o nível do PTH seja igual ou superior a 300 pg/mL a despeito do uso de quelantes de fósforo, dieta e diálise adequadas e na ausência de hipercalcemia e hiperfosfatemia. O paricalcitol também deve ser utilizado por pacientes em uso de cinacalcete que apresentem hipocalcemia ou necessitem da associação medicamentosa para atingir os níveis alvo de PTH.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **<mark>6.2.5. Cinacalcete</mark>** -->
<mark>O cinacalcete, um calcimimético, foi incorporado ao SUS em 2015, sendo contemplado como terceira linha de tratamento para pacientes com HPTS à DRC e submetidos à diálise, com nível sérico de PTH acima de 800 pg/mL. Entretanto, diretrizes nacionais e internacionais discordam destas indicações restritas para uso do cinacalcete</mark><sup>11-14</sup> <mark>. De acordo com essas diretrizes, calcimiméticos, calcitriol e paricalcitol são terapias aceitáveis para pacientes com DRC 5D que necessitam de tratamento para redução do nível sérico de PTH e a escolha do tratamento deve ser individualizada e guiada pelos níveis de PTH, dose e uso concomitante de medicamentos, bem como pelos níveis de cálcio e fósforo. Paricalcitol e cinacalcete não são terapias concorrentes e sim complementares, sendo paricalcitol a primeira opção quando o nível sérico de PTH estiver acima de 300 pg/mL e na ausência de hipercalcemia e hiperfosfatemia. No caso de o paciente apresentar hipercalcemia ou hiperfosfatemia, cinacalcete seria a primeira opção. Os dois medicamentos podem ser utilizados de forma complementar quando, após três meses de uso de um deles, o nível alvo de PTH entre 150-300 pg/mL não é atingido, se não houver contraindicação ao uso do medicamento complementar (paricalcitol ou cinacalcete) e com dieta, quelante de fósforo e diálise adequados.</mark>  
A ampliação de uso de cinacalcete para o tratamento de pacientes com DRC 5D e transplantados renais foi avaliada pela Conitec e obteve recomendação final favorável conforme Relatório de Recomendação nº 704/2022. Assim, recomenda-se o uso de cinacalcete, na dose de 30 a 180 mg ao dia, em pacientes adultos com HPTS à DRC estágio 5D em que o nível do PTH esteja igual ou superior a 300 pg/mL na ausência de <mark>hipocalcemia e para pacientes transplantados renais com nível sérico de PTH acima de 120 pg/mL ou com hipercalcemia, a despeito do uso de quelantes de fósforo, dieta e diálise adequadas, e na ausência de hipocalcemia.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6.2.6. Desferroxamina** -->
A desferroxamina (DFO) é um medicamento usado para o diagnóstico e tratamento da intoxicação por alumínio desde 1980. A DFO apresenta elevada afinidade com ferro e alumínio, mobilizando esses metais a partir dos depósitos tissulares e da transferrina. Liga-se ao alumínio formando o composto hidrossolúvel denominado aluminoxamina (C25H45AlN6O8; peso molecular = 584,6 g/mol), que é passível de remoção através das membranas biológicas e artificiais, como a membrana peritoneal e os capilares para hemodiálise<sup>51-53</sup> .  
O uso da DFO como teste diagnóstico para intoxicação óssea por alumínio pode ser feito no caso de suspeita clínica de intoxicação, exposição aguda ou crônica a fontes de alumínio e antes da realização da paratireoidectomia. O teste consiste em realizar duas coletas de sangue em jejum, para determinação dos níveis séricos de alumínio. As 1ª e 2ª coletas sanguíneas devem ser realizadas antes das 1ª e 2ª sessões de hemodiálise da semana, respectivamente. Após o término da 1ª sessão de hemodiálise, deve ser infundida, via intravenosa, a DFO (5 mg/kg, diluídos em 100 mL de solução glicosada a 5% ou fisiológica a 0,9%), durante 60 minutos. O resultado do teste é considerado "positivo" quando a diferença (delta) da concentração sérica de alumínio  
entre as duas dosagens for maior que 50 µg/L<sup>54-56</sup> . Para pacientes em diálise peritoneal, o teste de DFO deve ser realizado também com duas coletas de sangue separadas por intervalo de 5 horas, com a cavidade abdominal vazia<sup>55</sup> . O teste de DFO, interpretado de acordo com os níveis séricos de PTH e estoques de ferro, apresenta boa sensibilidade e especificidade para o diagnóstico da intoxicação óssea por alumínio<sup>55,57</sup> . Para os pacientes com o diagnóstico de intoxicação por alumínio confirmada por biópsia óssea, o teste com DFO não é necessário.  
Para o tratamento da intoxicação óssea por alumínio, a dose de DFO recomendada é de 5 mg/kg, a cada 7 dias, ao término da 1ª sessão de hemodiálise da semana, por um período variável de 3 meses a 1 ano, dose cuja efetividade é semelhante às de doses mais elevadas, com a vantagem de ser associada a menos eventos adversos<sup>55, 58-61</sup> .  
Nos pacientes submetidos à diálise peritoneal, a administração de DFO pode ser feita por via intravenosa ou intraperitoneal, na mesma dose e frequência preconizadas para os pacientes em hemodiálise<sup>55</sup> . A infusão intravenosa deve ser feita lentamente, durante 60 minutos, fora do período de diálise (com a cavidade abdominal vazia). A diálise só deve ser reiniciada após, no mínimo, 5 horas do término da administração do medicamento.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **FÁRMACOS** -->
- Calcitriol: cápsula de 0,25 mcg.  
- Carbonato de cálcio: comprimido de 1.250 mg (500 mg de cálcio elementar).  
- Cinacalcete: comprimido revestido de 30 mg e 60 mg.  
- Cloridrato de sevelâmer:  comprimido revestido de 800 mg.  
- Desferroxamina : frasco-ampola contendo 500 mg de pó liofilizado para solução injetável.  
- Paricalcitol: ampola de 5 mcg/mL contendo 1 mL de solução.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **7.1. Esquema de administração** -->
- <u>Carbonato de cálcio: A dose deve, preferencialmente, ser dividida em três tomadas, administrada junto com cada</u> refeição e ajustada de acordo com os níveis de fósforo e cálcio. Recomenda-se que a dose inicial seja de 500 mg de cálcio elementar (um comprimido de carbonato de cálcio de 1.250 mg), por via oral, com aumento conforme a necessidade e tolerância até dose máxima de 2.500 mg de cálcio elementar em crianças (cerca 6.000 mg de carbonato de cálcio) e dose máxima de 2.000 mg de cálcio elementar em adultos (cerca de 5.000 mg de carbonato de cálcio). Para o tratamento da síndrome da fome óssea, em pacientes dialíticos, a dose inicial deve ser de 5.000 mg a 15.000 mg de carbonato de cálcio, divididas em 2 ou 3 vezes ao dia, após a liberação da dieta, longe das refeições. Em pacientes transplantados renais, a reposição oral deve ser iniciada após normalização da hipercalcemia, na dose de 2.000 a 3.000 mg, divididas em 2 ou 3 vezes ao dia.  Após o segundo dia de pósoperatório, a dose deve ser ajustada diariamente, de acordo com o nível de calcio sérico, visando à suspensão da infusão endovenosa de gluconato de cálcio o mais precocemente possível<sup>54</sup> .  
- <u>Cloridrato de sevelâmer: A dose inicial recomendada é de 800 a 1.600 mg (1 a 2 comprimidos), a qual pode ser</u> administrada a cada refeição (duas ou três vezes por dia), devendo ser ajustada de acordo com o nível de fósforo, visando alvo entre 3,5 e 5,5 mg/dL. A dose pode ser aumentada ou diminuída em um comprimido por refeição em intervalos de quatro semanas. Se os valores de fósforo forem inferiores a 3,5 mg/dL, deve-se reduzir um comprinido. Se valores forem superiores a 6 mg/dL, deve-se aumentar um comprimido por refeição. A dose máxima recomendada é de 7.200 mg/dia. Deve-se sempre utilizar a menor dose possível com base na dosagem de fósforo sérico.  
- Calcitriol: A dose recomendada é de 0,25 mcg duas vezes ao dia. Os níveis de cálcio e fósforo devem ser monitorados a cada 4 semanas. Para o tratamento da síndrome de fome óssea, deve-se iniciar calcitriol oral na dose de 2,5 mcg/dia (em  
pacientes dialíticos) ou 0,75 mcg/dia (em pacientes transplantados), fracionada em doses concomitantes ao uso de carbonato de cálcio.  A dose máxima não deve ultrapassar 7,5 mcg/dia.  
- Paricalcitol: A dose inicial pode ser calculada a partir do peso do paciente (0,04 mcg/kg a 0,1 mcg/kg) e administrada por via intravenosa, em bolus, em dias alternados, a qualquer momento durante a diálise. A dose inicial também pode ser calculada divindo-se o nível de PTH do paciente por 80 e administrada por via intravenosa em bolus, em dias alternados, a qualquer momento durante a diálise, sendo a dose máxima de 40 mcg. Durante qualquer período de ajuste de dose, o cálcio e fósforo devem ser monitorados mais frequentemente e, se níveis elevados de cálcio ou de fósforo forem observados, a dose deve ser ajustada até que estes parâmetros sejam normalizados. Se hipercalcemia for observada, a dose de paricalcitol deverá ser imediatamente reduzida ou interrompida até que este parâmetro seja normalizado. Em seguida, paricalcitol deve ser reiniciado com uma dose menor. Se o paciente estiver utilizando quelante de fosfato à base de cálcio, a dose deve ser diminuída ou interrompida, ou o paciente deve trocar para um quelante de fosfato não cálcico. As doses poderão ser reduzidas quando os níveis do PTH começarem a diminuir em resposta à terapia. Se uma resposta satisfatória não for observada, a dose poderá ser elevada de 2 a 4 mcg, em intervalos de duas a quatro semanas. É importante aderir a um regime dietético de suplementação de cálcio e restrição de fósforo e os pacientes devem ser informados sobre os sintomas da elevação de cálcio.  
- Cinacalcete: A dose inicial recomendada para adultos é de 30 mg uma vez por dia, devendo ser ajustada a cada 2 a 4 semanas até a dose máxima de 180 mg, uma vez ao dia, para atingir um nível sérico de PTH entre 150 pg/mL a 300 pg/mL, em pacientes em diálise. Os valores de PTH devem ser analisados, pelo menos, 12 horas após a dose de cinacalcete. O PTH deve ser monitorado de 1 a 4 semanas após o início ou quando do ajuste de dose for realizado. O PTH deve ser monitorado aproximadamente a cada 1 a 3 meses durante a manutenção. Durante o ajuste da dose, os níveis de cálcio sérico devem ser monitorados frequentemente e dentro de 1 semana após o início de cinacalcete ou do ajuste de dose. Uma vez estabelecida a dose de manutenção, o cálcio sérico deve ser medido aproximadamente uma vez por mês. Se os níveis séricos de cálcio caírem abaixo do valor normal, devem ser tomadas medidas apropriadas, incluindo o ajuste da terapia concomitante. Nos casos em que, mesmo com as medidas terapêuticas adotadas, os níveis de PTH continuem acima do limite recomendado, está indicada a paratireoidectoma. De acordo com as Diretrizes Brasileiras de Práticas Clínicas dos DMO-DRC de 2021 da SBN, a paratireoidectomia está indicada para pacientes com PTH acima de 800 pg/mL não responsivo ao tratamento clínico, ou seja, com níveis de PTH persistentemente acima de 800 pg/mL associado a uma ou mais das seguintes condições: hipercalcemia ou hiperfosfatemia refratárias ao tratamento clínico, calcificações extra ósseas ou arteriolopatia urêmica calcificante (calcifilaxia), doença óssea avançada, progressiva e debilitante que não responde ao tratamento clínico; presença de glândulas paratireoides volumosas ao ultrassom (volume maior que 1,0 cm<sup>3</sup> ), ou ainda para transplantados renais com hipercalcemia maligna (nível de cálcio total acima de 14 mg/dL) ou com hipercalcemia associada à perda progressiva e inexplicada da função do enxerto, ou hipercalcemia persistente após o primeiro ano de transplante renal<sup>50</sup> .  
- Desferroxamina (DFO): pacientes com doença renal crônica e com suspeita clínica de intoxicação ou com níveis séricos de alumínio que excedam a 60 ng/mL, associados a níveis séricos de ferritina acima de 100 ng/mL ou antes da realização da paratireoidectomia devem realizar o teste de infusão de DFO. O teste consiste em realizar duas coletas de sangue em jejum, para determinação dos níveis séricos de alumínio. As 1ª e 2ª coletas sanguíneas devem ser realizadas antes da 1ª e das 2ª sessões de hemodiálise da semana, respectivamente. Após o término da 1ª sessão de hemodiálise, deve ser infundido, via intravenosa, a DFO (5 mg/kg, diluídos em 100 mL de solução glicosada a 5% ou fisiológica a 0,9%), durante 60 minutos. O resultado do teste é considerado positivo quando a diferença (delta) da concentração sérica de alumínio entre as duas dosagens for maior que 50 µg/L<sup>54-56</sup> . Para pacientes em diálise peritoneal, o teste de DFO deve ser realizado também com duas coletas de sangue separadas  
por intervalo de 5 horas, com a cavidade abdominal vazia<sup>55</sup> . Para tratamento da intoxicação por alumínio, a DFO deve ser administrada em dose de 5 mg/kg uma vez por semana. Para pacientes com níveis séricos de alumínio inferiores a 100 ng/mL, deve-se administrar DFO em infusão intravenosa lenta, durante os últimos 60 minutos de sessão de diálise. Já para pacientes com níveis séricos de alumínio acima de 100 ng/mL, DFO deve ser administrada em infusão intravenosa lenta, 5 horas antes da sessão de diálise. Após completar os seis primeiros meses de tratamento com DFO, acompanhado de um período de intervalo de 4 semanas, deve-se realizar um teste de infusão de DFO. Se resultar em níveis séricos de alumínio com menos de 50 ng/mL acima do valor basal, não se recomenda tratamento adicional com DFO. Em pacientes sob diálise peritoneal ambulatorial contínua ou sob diálise peritoneal cíclica, deve-se administrar DFO uma vez por semana em dose de 5 mg/kg antes da troca final do dia. A via intraperitoneal é recomendada nesses pacientes, porém, DFO também pode ser administrada por via intramuscular, por infusão intravenosa lenta ou por via subcutânea.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **7.2. Tempo de tratamento – Critérios de Interrupção** -->
Os pacientes com diagnóstico de doença do metabolismo ósseo associada à DRC devem ser tratados continuamente. A interrupção ou a modificação do tratamento deve ser avaliado individualmente para cada paciente, mesmo que os níveis de cálcio, fósforo e PTH estiverem controlados com os medicamentos preconizados neste PCDT.  
O tratamento pode ser interrompido em casos de transplante renal, correção de distúrbios metabólicos do hiperparatireoidismo secundário por paratireoidectomia e nos casos de intoxicação por alumínio. Por essas razões, o tratamento deve ser reavaliado semestralmente, quando o paciente estiver em tratamento cronicamente, ou mais frequentemente, se apresentar alguma alteração no quadro clínico ou laboratorial.  
Os pacientes em uso de DFO para tratamento de intoxicação por alumínio devem ter tratamento suspenso quando apresentarem três testes consecutivos com aumento do alumínio sérico menor que 50 mcg/L, conforme exposto no item esquema de administração.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **7.3. Benefícios esperados** -->
- normalização dos parâmetros bioquímicos do metabolismo mineral e ósseo;  
- redução nos níveis de fósforo no sangue;  
- melhora dos sintomas da doença;  
- redução de necessidade de retirada da glândula paratireoide;  
- redução do risco de fraturas e incidência de eventos cardiovasculares.  
Os benefícios esperados com o uso de desferroxamina são a regressão dos sinais e sintomas de intoxicação por alumínio.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **8. MONITORIZAÇÃO** -->
Inexistem estudos que embasem a periodicidade dos exames laboratoriais para monitorização do tratamento. Atualmente, recomenda-se que esta considere as alterações iniciais (do diagnóstico), o estágio da DRC e o tratamento em uso<sup>2,11</sup> .  
Em pacientes com DRC estágio 3, recomenda-se dosar cálcio, fósforo e PTH séricos a cada 6 a 12 meses. Já nos pacientes com DRC estágio 4, recomenda-se dosagens séricas de cálcio e fósforo a cada 3 a 6 meses e de PTH a cada 6 a 12 meses. Nos pacientes em estágio 5 não submetidos a TRS, a recomendação é dosar o cálcio e o fósforo no soro a cada 1 a 3 meses e PTH a cada 3 a 6 meses. Nos pacientes com DRC estágio 5 submetidos a TRS, recomendam-se dosagens séricas de cálcio e fósforo a cada mês e de PTH a cada 3 meses.  
Em pacientes que estejam em tratamento para DMO-DRC e que tenham anormalidades identificadas nos exames iniciais ou de monitorização, é aconselhável aumentar a frequência desses exames (cálcio e fósforo mensais e PTH a cada 3 meses), para  
a identificação de resposta ao tratamento e de possíveis eventos adversos. Nos pacientes submetidos a TRS, o nível sérico de PTH desejado é duas a nove vezes o limite superior do método utilizado (em gera, entre 150 a 600 pg/mL).  
O carbonato de cálcio como quelante intestinal de fósforo deve ser suspenso se houver eventos adversos não tolerados pelo paciente, particularmente gastrointestinais, e em casos de hipercalcemia. O uso do sevelâmer deve ser suspenso em pacientes que desenvolvam hipofosfatemia ou obstrução intestinal. Sugere-se que os quelantes de fósforo contendo cálcio tenham suas doses reduzidas ou sejam suspensos se o nível sérico de PTH diminuir abaixo de duas vezes o limite superior do método, com preferência ao uso do sevelâmer.  
A hipercalcemia é a principal complicação do tratamento com análogos de vitamina D, ocorrendo em torno de 15% dos pacientes. Pacientes que estão em uso destes medicamentos e que desenvolvem hipercalcemia ou hiperfosfatemia, devem ter sua dose reduzida em 50% ou suspensa. A mesma conduta deve ser tomada se o PTH diminuir abaixo de 150 pg/mL. Ao iniciar qualquer um destes medicamentos, é importante dosar o cálcio e o fósforo nas primeiras 2 a 4 semanas.  
Pacientes que estão em uso de cinacalcete devem ter seu cálcio sérico dosado após 1 a 2 semanas do início do tratamento ou após alteração da dose. Nos casos em que ocorra hipocalcemia (cálcio abaixo de 8,4 mg/dL ou abaixo do limite inferior do método utilizado), o cinacalcete deve ter sua dose reduzida em 50% ou ser suspenso, principalmente se houver hipocalcemia grave (cálcio abaixo de 7,5 mg/dL) ou sintomática mesmo que cálcio fique entre 7,5 e 8,4 mg/dL. Para prevenir e tratar a hipocalcemia, deve-se considerar a adição de quelantes de cálcio e análogos da vitamina D, os quais podem corrigir e prevenir hipocalcemia, além de favorecer controle do HPTS com doses menores dos medicamentos. Essa medida pode trazer o benefício de doses menores, com menor custo, maior eficácia e menor risco de eventos adversos. Outra indicação de suspensão desse medicamento é a queda do nível PTH abaixo de 150 pg/mL. Náusea e vômitos são eventos adversos comuns relacionados ao uso de cinacalcete, principalmente no início do tratamento. Sugere-se que o medicamento seja administrado após a refeição principal. Recomenda-se cautela com uso de antieméticos, incluindo metoclopramida, já que podem causar prolongamento do intervalo QT no eletrocardiograma em pacientes com cardiopatia.  
Já os pacientes em tratamento de síndrome da fome óssea, devem ter os níveis séricos de cálcio e fósforo monitorados semanalmente, nas primeiras 4 semanas após a alta hospitalar, e quinzenalmente até o término da fome óssea. Após o término da fome óssea, os níveis séricos de cálcio, fósforo, fosfatase alcalina, PTH e 25-hidroxivitamina D devem ser monitorados a cada 3 meses no primeiro ano. Nos anos subsequentes, a monitoração deve ser realizada, no mínimo, a cada 6 meses em pacientes em diálise, e anualmente em pacientes transplantados com função renal estável<sup>54</sup> .  
A DFO está associada ao aumento da incidência de mucormicose. Além disso, são descritos neurotoxicidade visual e auditiva, distúrbios gastrintestinais, hipotensão e anafilaxia. Por essas razões, os pacientes que forem submetidos a esse tratamento devem ter avaliações oftalmológicas e otorrinolaringológicas antes do início do tratamento e anualmente.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de DMO-DRC devem ser atendidos em serviços especializados em nefrologia, para seu adequado diagnóstico, inclusão no Protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **11. REFERÊNCIAS** -->
<mark>1. E</mark> ckardt KU, Coresh J, Devuyst O, Johnson RJ, Köttgen A, Levey AS, et al. Evolving importance of kidney disease: from subspecialty to global health burden. The Lancet 2013;382(9887):158–169. doi:10.1016/S0140-6736(13)60439-0  
<mark>2. L</mark> evin A, Bakris GL, Molitch M, Smulders M, Tian J, Williams LA, et al. Prevalence of abnormal serum vitamin D, PTH, calcium, and phosphorus in patients with chronic kidney disease: results of the study to evaluate early kidney disease. Kidney Int 2007;71(1):31-8.  
3. Waziri B, Duarte R, Naicker S. Chronic Kidney Disease–Mineral and Bone Disorder (CKD-MBD): Current Perspectives. International Journal of Nephrology and Renovascular Disease 2019;12:263-276.  
4. Berkoben M, Quarles LD. Treatment of hyperphosphatemia in chronic kidney disease. [Internet]. UpToDate; 2019 [acesso em 05/01/2021]. Disponível em: http://www.uptodate.com/contents/treatment-of-hyperphosphatemia-in-chronickidney-disease  
5. Isakova T, Wolf MS. FGF23 or PTH: which comes first in CKD? Kidney Int 2010;78(10):947-9. doi: 10.1038/ki.2010.281. PMID: 21030968.  
6. Maeda A. et al. Critical role of parathyroid hormone (PTH) receptor-1 phosphorylation in regulating acute responses to PTH. In: (Ed.). Proc Natl Acad Sci U S A. United States, v.110, p.5864-9, 2013.  
7. Sociedade Brasileira de Nefrologia (SBN) [homepage na internet]. Censo 2019 [acesso em 05 jul 2021]. Disponível em: http://www.censo-sbn.org.br/censosAnteriores  
8. Sociedade Brasileira de Nefrologia (SBN) [homepage na internet]. Censo 2020 [acesso em 05 jul 2021]. Disponível em: http://www.censo-sbn.org.br/censosAnteriores  
9. Schunemann HJ, Wiercioch W, Etxeandia I, et al. Guidelines 2.0: systematic development of a comprehensive checklist for a successful guideline enterprise. CMAJ. 2014; 186(3):E123-142.  
10. GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. 2015. Disponível em: gradepro.org.  
11. KIDNEY DISEASE: IMPROVING GLOBAL OUTCOMES, C.K.D.M.D.W.G. KDIGO Clinical Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of Chronic Kidney Disease–Mineral and Bone Disorder (CKDMBD). Kidney International Supplements 2017; 7(1).  
12. Holden RM, Mustafa RA, Alexander RT, Battistella M, Bevilacqua MU, Knoll G, et al. Canadian Society of Nephrology Commentary on the Kidney Disease Improving Global Outcomes 2017 Clinical Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of Chronic Kidney Disease-Mineral and Bone Disorder Canadian Journal of Kidney Health and Disease Volume 7: 1–23  
13. Fukagawa M, Yokoyama K, Koiwa F, Taniguchi M, Shoji T, Kazama JJ, Komaba H, et al. Clinical Practice Guideline for the Management of Chronic Kidney Disease-Mineral and Bone Disorder. Therapeutic Apheresis and Dialysis 2013;17(3):247–288 doi: 10.1111/1744-9987.12058  
14. Lucca LJ, Moyses RMA, Hernandes FR, Gueiros JEB. CKD-MBD diagnosis: biochemical abnormalities. Braz. J. Nephrol. 43 (4 Suppl 1) • 2021 • https://doi.org/10.1590/2175-8239-JBN-2021-S102  
15. Llach F, Yudd M. The importance of hyperphosphataemia in the severity of hyperparathyroidism and its treatment in patients with chronic renal failure. Nephrol Dial Transplant. 1998;13 Suppl 3:57-61.  
16. Loghman-Adham M. Phosphate binders for control of phosphate retention in chronic renal failure. Pediatr Nephrol. 1999;13(8):701-8.  
17. Slatopolsky E, Weerts C, Lopez-Hilker S, Norwood K, Zink M, Windus D, et al. Calcium carbonate as a phosphate binder in patients with chronic renal failure undergoing dialysis. N Engl J Med. 1986;315(3):157-61.  
18. Slatopolsky E, Weerts C, Norwood K, Giles K, Fryer P, Finch J, et al. Long-term effects of calcium carbonate and 2.5 mEq/liter calcium dialysate on mineral metabolism. Kidney Int. 1989;36(5):897-903.  
19. Navaneethan SD, Palmer SC, Vecchio M, Craig JC, Elder GJ, Strippoli GF. Phosphate binders for preventing and treating bone disease in chronic kidney disease patients. Cochrane Database Syst Rev. 2011;(2):CD006023.  
20. Slatopolsky EA, Burke SK, Dillon MA. RenaGel, a nonabsorbed calcium- and aluminum-free phosphate binder, lowers serum phosphorus and parathyroid hormone. The RenaGel Study Group. Kidney Int. 1999;55(1):299-307.  
21. Chertow GM, Burke SK, Dillon MA, Slatopolsky E. Long-term effects of sevelâmer hydrochloride on the calcium x phosphate product and lipid profile of haemodialysis patients. Nephrol Dial Transplant. 1999;14(12):2907-14.  
22. Goldberg DI, Dillon MA, Slatopolsky EA, Garrett B, Gray JR, Marbury T, et al. Effect of RenaGel, a non-absorbed, calcium- and aluminium-free phosphate binder, on serum phosphorus, calcium, and intact parathyroid hormone in end-stage renal disease patients. Nephrol Dial Transplant. 1998;13(9):2303-10.  
23. Chen N, Wu X, Ding X, Mei C, Fu P, Jiang G, et al. Sevelâmer carbonate lowers serum phosphorus effectively in haemodialysis patients: a randomized, double-blind, placebo-controlled, dose-titration study. Nephrol Dial Transplant. 2014;29(1):152-60.  
24. Burke SK, Dillon MA, Hemken DE, Rezabek MS, Balwit JM. Meta-analysis of the effect of sevelâmer on phosphorus, calcium, PTH, and serum lipids in dialysis patients. Adv Ren Replace Ther. 2003;10(2):133-45.  
25. Mautner SL, Mautner GC, Froehlich J, Feuerstein IM, Proschan MA, Roberts WC, et al. Coronary artery disease: prediction with in vitro electron beam CT. Radiology. 1994;192(3):625-30.  
26. Arad Y, Spadaro LA, Goodman K, Newstein D, Guerci AD. Prediction of coronary events with electron beam computed tomography. J Am Coll Cardiol. 2000;36(4):1253-60.  
27. Margolis JR, Chen JT, Kong Y, Peter RH, Behar VS, Kisslo JA. The diagnostic and prognostic significance of coronary artery calcification. A report of 800 cases. Radiology. 1980;137(3):609-16.  
28. Chertow GM, Burke SK, Raggi P; Treat to Goal Working Group. Sevelâmer attenuates the progression of coronary and aortic calcification in hemodialysis patients. Kidney Int. 2002;62(1):245-5  
29. Patel L, Bernard LM, Elder GJ. Sevelamer Versus Calcium-Based Binders for Treatment of Hyperphosphatemia in CKD: A Meta-Analysis of Randomized Controlled Trials. Clin J Am Soc Nephrol 2016; 11:232.  
30. Ruospo M, Palmer SC, Natale P, Craig JC, Vechio M, Elder JC et al. Phosphate binders for preventing and treating chronic kidney disease-mineral and bone disorder (CKD-MBD). Cochrane Database of Systematic Reviews 2018, Issue 8. Art. No.: CD006023. DOI: 10.1002/14651858.CD006023.pub3  
31. Phannajit J, Wonghakaeo N, Takkavatakarn K, Asawavichienjinda T, Praditpornsilpa K, Eiam-Ong S, Susantitaphong P. The impact of phosphate lowering agents on clinical and laboratory outcomes in chronic kidney disease patients: a systematic review and meta-analysis of randomized controlled trials. J Nephrol. 2021 Jun 1. doi: 10.1007/s40620-021-01065-3. Epub ahead of print. PMID: 34061337.  
32. Natoli JL, Boer R, Nathanson BH, Miller RM, Chiroli S, Goodman WG, et al. Is there an association between elevated or low serum levels of phosphorus, parathyroid hormone, and calcium and mortality in patients with end stage renal disease? A meta-analysis. BMC Nephrol 2013;17(14):88. doi: 10.1186/1471-2369-14-88  
33. Dukkipati R, Kovesdy CP, Colman S, Budoff MJ, Nissenson AR, Sprague SM, et al. Association of relatively low serum parathyroid hormone with malnutrition-inflammation complex and survival in maintenance hemodialysis patients. J Ren Nutr 2010;20:243–254. doi: 10.1053/j.jrn.2009.10.006.  
34. Figuiredo-Dias V, Cuppari L, Garcia-Lopes MG, de Carvalho AB, Draibe SA, Kamimura MA. Risk factors for hypovitaminosis D in nondialyzed chronic kidney disease patients. J Ren Nutr. 2012;22(1):4-11.  
35. Palmer SC, McGregor DO, Craig JC, Elder G, Macaskill P, Strippoli GF. Vitamin D compounds for people with chronic kidney disease not requiring dialysis. Cochrane Database Syst Rev. 2009;(4):CD008175. doi:10.1002/14651858.CD008175.  
36. Palmer SC, McGregor DO, Macaskill P, Craig JC, Elder GJ, Strippoli GF. Meta-analysis: vitamin D compounds in chronic kidney disease. Ann Intern Med. 2007;147(12):840-53.  
37. Baker LR, Muir JW, Sharman VL, Abrams SM, Greenwood RN, Cattell WR, et al. Controlled trial of calcitriol in hemodialysis patients. Clin Nephrol. 1986;26(4):185-91.  
38. Tonelli M. Vitamin D in patients with chronic kidney disease: nothing new under the sun. Ann Intern Med. 2007;147(12):880-1.  
39. Zheng Z, Shi H, Jia J, Li D, Lin S. Vitamin D supplementation and mortality risk in chronic kidney disease: a metaanalysis of 20 observational studies. BMC Nephrol. 2013;14:199.  
40. Quarles LD, Yohay DA, Carroll BA, Spritzer CE, Minda SA, Bartholomay D, et al. Prospective trial of pulse oral versus intravenous calcitriol treatment of hyperparathyroidism in ESRD. Kidney Int. 1994;45(6):1710-21.  
41. Haiyang Zhou, Chenggang Xu. Comparison of intermittent intravenous and oral calcitriol in the treatment of secondary hyperparathyroidism in chronic hemodialysis patients: a meta-analysis of randomized controlled trials. Clin Nephrol. 2009;71(3):276-85.  
42. Cruz DN, Perazella MA. Biochemical aberrations in a dialysis patient following parathyroidectomy. Am J Kidney Dis. 1997;29(5):759-62.  
43. Rocha LA, Neves MC, Montenegro FLM. Paratireoidectomia na doença renal crônica. J Bras Nefrol. 2021;43(4 Suppl 1):669-73.  
44. Clair F, Leenhardt L, Bourdeau A, Zingraff J, Robert D, Dubost C, et al. Effect of calcitriol in the control of plasma calcium after parathyroidectomy. A placebo-controlled, double-blind study in chronic hemodialysis patients. Nephron. 1987;46(1):18-22.  
45. Geng X, Shi E, Wang S, Song Y. A comparative analysis of the efficacy and safety of paricalcitol versus other vitamin D receptor activators in patients undergoing hemodialysis: A systematic review and meta-analysis of 15 randomized controlled trials. PLOS ONE 2020;15(5):e0233705.  
46. Zhang Q, Li M, You L, et al. Effects and safety of calcimimetics in end stage renal disease patients with secondary hyperparathyroidism: a meta-analysis. PLoS One. 2012;7(10):e48070. doi:10.1371/journal.pone.0048070  
47. Li D, Shao L, Zhou H, Jiang W, Zhang W, Xu Y. The efficacy of cinacalcet combined with conventional therapy on bone and mineral  
48. Ballinger AE, Palmer SC, Nistor I, Craig JC, Strippoli GF. Calcimimetics for secondary hyperparathyroidism in chronic kidney disease patients. Cochrane Database Syst Rev. 2014;(12):CD006254. doi: 10.1002/14651858.CD006254.pub2. Epub 2014 Dec 9. PMID: 25490118.  
49. Palmer SC, Mavridis D, Johnson DW, Tonelli M, Ruospo M, Strippoli GFM. Comparative Effectiveness of Calcimimetic Agents for Secondary Hyperparathyroidism in Adults: A Systematic Review and Network Meta-analysis. Am J Kidney Dis. 2020 Sep;76(3):321-330. doi: 10.1053/j.ajkd.2020.02.439. Epub 2020 May 28. PMID: 32475604.  
50. Rocha LA, Neves MC, Montenegro FLM. Update of Brazilian Guidelines for Treatment and Assessment of Chronic Kidney Disease – Mineral and Bone Disorders. Parathyroidectomy in chronic kidney disease. J Bras Nefrol 2011;33(Suppl):669673.  DOI: https://doi.org/10.1590/2175-8239- JBN-2021-S112  
51. Ackrill P et al. Successful removal of aluminum from patients with dialysis encephalopathy. Lancet. 1980 Sep 27;2(8196):692-3. https://doi.org/10.1016/S0140- 6736(80)92728-2  
52. Molitoris BA, Alfrey AC, 2.Alfrey PS, Miller NL. Rapid removal of DFO-chelated aluminum during hemodialysis using polysulfone dialyzers. Kidney Int. 1988 Jul;34(1):98-101.  
53. Hercz G, Salusky IB, Norris KC, Fine RN, Coburn JW. Aluminum removal by peritoneal dialysis: intravenous vs. intraperitoneal deferoxamine. Kidney Int. 1986 Dec;30(6):944-8.  
54. Rocha LA. Neves MC, Montenegro FML. Update of Brazilian Guidelines for Treatment and Assessment of Chronic Kidney Disease – Mineral and Bone Disorders- Parathyreoidectomy in Chronic Kidney Disease. Braz. J. Nephrol. (J. Bras. Nefrol.) 2021;43(4 Suppl. 1):669-673  
55. Oliveira RB, Barreto FC, Nunes LA, Custódio MR. Update of Brazilian Guidelines for Treatment and Assessment of Chronic Kidney Disease – Mineral and Bone Disorders- Aluminum Intoxication in Chronic Kidney Disease. Braz. J. Nephrol. (J. Bras. Nefrol.) 2021;43(4 Suppl. 1):660-664  
56. D’Haese PC et al.  Use of the low-dose desferrioxamine test to diagnose and differentiate between patients with aluminium related bone disease, increased risk for aluminium toxicity, or aluminium overload. Nephrol Dial Transplant. 1995 Oct;10(10):1874-84.  
57. Verpooten GA et al.  Pharmacokinetics of aluminoxamine and ferrioxamine and dose finding of desferrioxamine in haemodialysis patients. Nephrol Dial Transplant. 1992 Jan 1;7(9):931-8  
58. Barata JD, D'Haese PC, Pires C, Lamberts LV, Simões J, De Broe ME. Low-dose (5mg/kg) desferrioxamine treatment in acutely aluminium-intoxicated haemodialysis patients using two drug administration schedules. Nephrol Dial Transplant. 1996 Jan 1;11(1):125-32. https://doi.org/10.1093/ndt/11.1.125  
59. Canteros A, Díaz-Corte C, Fernández-Martín JL, Gago E, Fernández-Merayo C, Cannata J. Ultrafiltrable aluminium after very low doses of desferrioxamine. Nephrol Dial Transplant. 1998 Jun 1;13(6):1538-42. https://doi.org/10.1093/ndt/13.6.1538 27.  
60. Kan W-C, Chien C-C, Wu C-C, Su S-B, Hwang J-C, Wang H-Y. Comparison of low-dose deferoxamine versus standard-  
dose deferoxamine for treatment of aluminium overload among haemodialysis patients. Nephrol Dial Transplant. 2010 May;25(5):1604-8. https://doi.org/10.1093/ndt/gfp  
61. Diagnosis and treatment of aluminum overload in endstage renal failure patients. Consensus Conference. Paris, France, 27 June 1992. Nephrol Dial Transplant. 1993;8 Suppl 1:1-54.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
CALCITRIOL, PARICALCITOL, CINACALCETE, SEVELÂMER E DESFERROXAMINA  
Eu,___________________________________________________________________________(nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos calcitriol, paricalcitol, cinacalcete, desferroxamina e sevelâmer, indicados para o tratamento do Distúrbio Mineral e Ósseo na Doença Renal Crônica.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo (a) médico (a)  
(nome do (a) médico (a) que prescreve).  
Assim declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- normalização dos parâmetros bioquímicos do metabolismo mineral e ósseo;  
- redução nos níveis de fósforo no sangue;  
- melhora dos sintomas da doença;  
- redução de necessidade de retirada da glândula paratireoide;  
- redução do risco de fraturas e incidência de eventos cardiovasculares;  
- para a desferroxamina: regressão dos sinais e sintomas de intoxicação por alumínio.  
Fui também claramente informado a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- não se sabe ao certo os riscos do uso desses medicamentos na gravidez, portanto, caso engravide, devo avisar  
- imediatamente ao meu médico;  
- a segurança para o uso dos medicamentos calcitriol, paricalcitol e cinacalcete durante a amamentação deve ser avaliada  
- pelo médico assistente considerando riscos e benefícios, visto que podem ser excretado pelo leite materno;  
- eventos adversos do calcitriol e paricalcitol: aumento dos níveis de cálcio no sangue, prisão de ventre, diarreia, secura da boca, dor de cabeça, sede intensa, aumento da frequência ou da quantidade de urina, perda do apetite, gosto metálico, dor nos músculos, náusea, vômitos, cansaço e fraqueza. Alguns efeitos crônicos podem incluir conjuntivite, diminuição do desejo sexual, irritabilidade, coceiras, infecções do trato urinário, febre alta, aumento da pressão arterial, batimentos cardíacos irregulares, aumento da sensibilidade dos olhos à luz ou irritação, aumento dos níveis de fósforo no sangue, aumento do colesterol, aumento das enzimas do fígado ALT e AST, perda de peso, inflamação no pâncreas e psicose, que é o sintoma mais raro.  
- eventos adversos do cinacalcete: náusea, vômitos, diarreia, dor abdominal, prisão de ventre, reações de hipersensibilidade, problemas na pele, dores musculares, diminuição ou falta de apetite, convulsões, tonturas, dormências, dor de cabeça, pressão baixa, infecção respiratória, falta de ar, tosse, agravamento da insuficiência cardíaca, diminuição do cálcio e aumento do potássio no sangue.  
- eventos adversos da desferroxamina: reações no local de aplicação da injeção (dor, inchaço, coceira, vermelhidão), urina escura, vermelhidão da pele, coceira, reações alérgicas, visão borrada, catarata, zumbidos, tontura, dificuldade para respirar, desconforto abdominal, diarreia, cãibra nas pernas, aumento dos batimentos do coração, febre, retardo no crescimento (em pacientes que começam tratamento antes dos 3 anos de vida), distúrbio renal e suscetibilidade a infecções.  
- eventos adversos do sevelâmer: diarreia, vômitos, náusea, gases, má digestão, azia, aumento ou diminuição da pressão  
- arterial, tosse, dor de cabeça, infecções e dor.  
- os medicamentos são contraindicados em casos de hipersensibilidade (alergia) conhecida ao fármaco,  
- risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que esse medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei sendo atendido, inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. ( ) Sim ( ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento(s):  
( ) calcitriol ( ) paricalcitol ( ) cinacalcete ( ) desferroxamina ( ) sevelâmer  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Distúrbio Mineral Ósseo na Doença Renal Crônica (DMO-DRC) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Para a elaboração deste relatório foi realizada uma reunião de escopo no dia 31/05/2021 com a participação de membros do Grupo Elaborador e do Comitê Gestor. Nesta reunião foram apresentados os conceitos principais de um PCDT, quais os passos necessários para a elaboração, objetivo da reunião de escopo e as portarias e documentos que orientam a elaboração de PCDTs. Foi descrito o panorama geral do DMO-DRC e as informações detalhadas sobre os pontos do Protocolo vigente (Portaria SAS/MS nº 801, de 15 de abril de 2017) e aspectos que necessitam de alterações, entre eles a adequação dos códigos da CID-10 atendidos pelo PCDT, adequação do diagnóstico e do tratamento, em especial, a ampliação do uso dos medicamentos paricalcitol, cinacalcete e sevelâmer.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O painel de especialistas incluiu médicos da especialidade de nefrologia.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT do Distúrbio Mineral Ósseo na Doença Renal Crônica foi apresentada à 95ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em novembro de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Vigilância Sanitária (SVS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria Especial de Saúde Indígena (SESAI). O PCDT foi aprovado para avaliação pelo Plenário da Conitec.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **4. Busca da evidência** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>1</sup> , que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ). O GRADE classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>2</sup> .  
Para cada dúvida clínica, foi elaborada uma pergunta de pesquisa, conforme acrônimo PICO. Para cada uma destas questões, procedeu-se com busca estruturada nas seguintes bases de dados: _Medical Literature Analysis and Retrieval System Online_ (MEDLINE) via Pubmed, _Excerpta medica database_ (EMBASE) via Elsevier, _Cochrane Central Register of Controlled Trials_ via Cochrane Library (CENTRAL), Biblioteca Virtual de Saúde, Epistemonikos e NICE. Também foram realizadas buscas em repositórios de diretrizes clínicas para identificar possíveis atualizações no que diz respeito ao cuidado de pacientes com DMO-DRC.  
Para responder cada questão foram utilizadas as seguintes metodologias: 1) revisões sistemáticas _novas;_ 2) atualização de revisões sistemáticas existentes; e 3) adoção ou adaptação de diretrizes existentes. A seleção dos artigos foi realizada conforme critérios de elegibilidade pré-estabelecidos para cada uma das perguntas. De forma geral, foram selecionadas as revisões sistemáticas com meta-análise (RSMA) e, na ausência de RSMA de qualidade, os ensaios clínicos randomizados (ECR).  
As revisões sistemáticas foram avaliadas por meio da ferramenta AMSTAR-II<sup>3</sup> . Os ensaios clínicos randomizados foram avaliados por meio da ferramenta _Risk of Bias_ , proposta pela Cochrane (ROB 2.0)<sup>4</sup> . Para a extração de dados, foi utilizada uma ficha de extração padronizada e desenvolvida pelo grupo elaborador. A estimativa do efeito de desfechos dicotômicos entre os grupos foi analisada utilizando a medida de risco relativo (RR) e para variáveis contínuas, foi utilizada a diferença padronizada das médias ( _standardized mean difference_ – SMD). O tipo de análise (aleatória/fixa) foi decidido de acordo com a heterogeneidade da amostra. Para amostras homogêneas, foi conduzida uma análise de efeitos fixos, enquanto que para amostras heterogêneas foi realizada uma análise de efeitos aleatórios. A heterogeneidade foi avaliada pelo teste Q de Cochran, complementado com I2. Nós consideramos que a amostra era homogênea para um valor de p ≥ 0,05 no teste Q e valor de I2 ≤ 25%. Gráficos de floresta ( _forest plot_ ) foram usados para representação gráfica de dados. Testes mostrados na área à esquerda mostram uma redução no risco ou menor SMD com a intervenção experimental, enquanto aqueles à direita mostram um aumento em risco ou maior SMD com a intervenção. O efeito geral da análise foi testado com o teste Z. Além do tamanho do efeito para SMD, a interpretação da magnitude da SMD seguiu o definido por Cohen, sendo um efeito pequeno - SMD = 0,2; efeito moderado - SMD = 0,5; efeito grande - SMD = 0,8. Todas as estatísticas individuais e globais foram calculadas com um nível de significância α = 0,05 e confiança de 95%. Todas as análises foram realizadas no RevMan versão 5.4.<sup>5</sup> Toda <mark>s as avaliações foram realizadas por dois pesquisadores de forma independente, com eventuais discordâncias sendo resolvidas mediante consulta a um terceiro avaliador.</mark>  
Após a síntese dos achados, utilizou-se o <mark>sistema GRADE para a avaliação da certeza da evidência.</mark> Dessa forma, foram elaboradas tabelas de perfil de evidências na plataforma GRADEpro (GRADEpro GDT) para cada questão PICO, sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto de cada questão. <mark>A interpretação dos níveis de evidência de acordo com o GRADE é apresentada no</mark> **<mark>Quadro A</mark>** .  
**Quadro A -** Níveis de evidências de acordo com o sistema GRADE.  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|**Moderado**|Há<br>confiança<br>moderada<br>no<br>efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos<br>futuros<br>provavelmente<br>terão<br>um<br>impacto<br>importante em nossa confiança na estimativa de efeito.|
|**Muito baixo**|A confiança na estimativa de efeito é muito<br>limitada.|Qualquer estimativa de efeito é incerta.|
||Há importante grau de incerteza nos||  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
||achados.||  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **5. Desenvolvimento da recomendação** -->
Após a síntese das evidências, duas reuniões de recomendações foram realizadas nos dias 06 e 10 de dezembro de 2021 com o painel de especialistas. Para a elaboração das recomendações, foram considerados os riscos e os benefícios das condutas propostas, balanço dos riscos e benefícios, avaliação da certeza da evidência, custos, e aceitabilidade pelos profissionais e demais barreiras para implementação. Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE ( **Quadro B** ). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou outros esclarecimentos, foram documentadas ao longo do texto.  
**Quadro B -** Implicações da força da recomendação para profissionais, pacientes e gestores em saúde.  
|**Público-alvo**||**Forte**|**Condicional**|
|---|---|---|---|
|**Gestores**||A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das<br>partes interessadas.|
|**Pacientes**||A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno<br>número<br>não<br>aceitaria<br>essa<br>recomendação|Grande parte dos indivíduos desejaria que a<br>intervenção fosse indicada; contudo considerável<br>número não aceitaria essa recomendação.|
||||O profissional deve reconhecer que diferentes|
|**Profissionais**<br>**saúde**|**da**|A maioria dos pacientes deve receber a<br>intervenção recomendada.|escolhas serão apropriadas para cada paciente para<br>definir uma decisão consistente com os seus valores e<br>preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão  
em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **6. Recomendações** -->
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 1: Devemos utilizar a dosagem de 25-hidroxivitamina D para o diagnóstico de insuficiência ou deficiência de vitamina D em pacientes com DRC?** -->
**<u>Recomendação 1:</u>** Sugerimos realizar dosagens de 25 (OH) D (calcidiol) em pacientes com DRC estágios 3 a 5D para  
determinar o valor basal e acompanhar os níveis após o uso de intervenções terapêuticas (recomendação não graduada). A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com DRC estágios 2 a 5D  
**Intervenção:** Dosagem de 25-hidroxivitamina D **Comparador:** Seguimento clínico sem intervenção  
**Desfechos:** Níveis de 25-hidroxivitamina D, calcemia, fosfatemia e PTH dentro da normalidade, eventos cardíacos (IAM), mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Para essa questão não foi realizada busca sistemática da literatura. Foi adotada a recomendação que consta no _The Kidney Disease: Improving Global Outcomes_ (KDIGO) _2017 Clinical Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of chronic kidney disease–mineral and bone disorder_ (CKD-MBD).<sup>6</sup>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
O Grupo de Trabalho elaborador do KDIGO 2017<sup>6</sup> reconheceu que há informações emergentes sobre o potencial papel da deficiência e insuficiência de vitamina D na patogênese ou agravamento de doenças múltiplas. Além disso, a deficiência e a insuficiência de vitamina D podem ter um papel na patogênese do hiperparatireoidismo (HPT). Os riscos potenciais de reposição de vitamina D são mínimos e, portanto, apesar do benefício incerto, o Grupo de Trabalho considerou que a dosagem de vitamina D pode ser benéfica  
A prevalência de insuficiência ou deficiência de vitamina D varia de acordo com a definição usada. A maioria dos estudos define deficiência como valores séricos de 25-hidroxivitamina D (calcidiol) abaixo de 15 ng/mL (25 nmol/L) e insuficiência como valores entre 15 e 30 ng/mL (50–80 nmol/L)<sup>7-8</sup> . No entanto, não há consenso sobre quais seriam os níveis "adequados" ou tóxicos de vitamina D<sup>9</sup> . Acredita-se que um nível normal de vitamina D é aquele que está associado a um nível sérico normal de PTH na população em geral. Outra definição é o nível acima do qual não há redução recíproca adicional no PTH sérico após a suplementação de vitamina D<sup>10-11</sup> . Numerosas publicações encontraram associações entre deficiência de vitamina D e diferentes doenças<sup>12</sup> , na população em geral<sup>13-14</sup> e em pacientes com DRC. Há uma associação de baixos níveis de 25-hidroxivitamina D com mortalidade.  
Um estudo prospectivo randomizado controlado (ECR) na população em geral mostrou que a suplementação de vitamina D reduz o risco de câncer<sup>15</sup> . No entanto, não há dados mostrando que a reposição de vitamina D em um nível específico de 25hidroxivitamina D reduz a mortalidade. Atualmente, definir metas específicas ou limites é provavelmente prematuro. Em particular, usar nível sérico normal de paratormônio (PTH) como critério de adequação de vitamina D na DRC é complexo devido aos múltiplos fatores que afetam a síntese, secreção, resposta do tecido alvo e eliminação do PTH na DRC. Estudos em pacientes com DRC e na população em geral mostram ampla deficiência de vitamina D. De acordo com algumas definições, quase 50% dos estudos envolvem pacientes que apresentam níveis abaixo do ideal. Em pacientes com DRC estágios 3–4, há relatos de níveis mais baixos de 25-hidroxivitaminaD em pacientes com estágios mais avançados de DRC<sup>16-17</sup> .  
A definição de qual nível de vitamina D representa a suficiência é continuamente debatida. Não há dados de que a presença ou ausência de DRC alteraria os níveis recomendados. A decisão de dosar, quando dosar, frequência da dosagem, e qual o nível alvo da vitamina D precisa ser individualizada. Em pacientes com DRC estágios 3 e 4, a deficiência de vitamina D pode ser uma causa subjacente de PTH elevado e, portanto, há uma justificativa para dosare suplementar a vitamina D nesta população, embora esta hipótese não tenha sido testada em um ECR.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 2: Devemos utilizar a dosagem de fosfatase alcalina para o diagnóstico de DMO em pacientes com DRC?** -->
**<u>Recomendação:</u>** Recomendamos monitorar os níveis séricos da atividade da fosfatase alcalina a partir da DRC estágio  
3A em adultos e estágio 2 em crianças (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com DRC estágios 2 a 5D  
**Intervenção:** Dosagem de fosfatase alcalina **Comparador:** Dosagem de PTH apenas  
**Desfechos:** Níveis de 25-hidroxivitamina D, calcemia, fosfatemia e PTH dentro da normalidade, eventos cardíacos (IAM), mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Para essa questão, não foi realizada busca sistemática da literatura. Essa recomendação já constava no PCDT anterior<sup>18</sup> e foi mantida.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
A fosfatase alcalina (FA) é uma enzima que remove o fosfato de proteínas e nucleotídeos, funcionando de forma ideal em pH alcalino e encontrada em todo o corpo na forma de isoenzimas que são exclusivas do tecido de origem. Os níveis elevados de FA geralmente são devidos a uma função hepática anormal (nesse caso, outros testes de função hepática também são anormais), um aumento da atividade óssea ou metástases ósseas. Além disso, podem estar elevados em HPT primário e secundário e doença de Paget.  
A mensuração da FA no diagnóstico e avaliação de DMO-DRC pode ser usada como um teste adjunto, mas se os valores forem altos, então os testes de função hepática devem ser verificados. A FA pode ser usada como um teste de rotina para acompanhar a resposta à terapia ou determinar o status de remodelação óssea quando a interpretação do PTH não está clara. O uso da FA porção óssea forneceria informações adicionais e mais específicas, porém não está prontamente disponível. Níveis séricos elevados de FA foram reconhecidos como uma variável possivelmente independente associada ao aumento no risco relativo (RR) de mortalidade em pacientes com DRC estágio 5D<sup>16-17</sup> . Regidor e colaboradores (2008)<sup>16</sup> descreveram associação entre níveis séricos de FA e mortalidade em pacientes prevalentes em HD, além de curvas em forma de U ou J para cálcio, fósforo e PTH, ressaltando ainda mais a complexidade das relações dessas anormalidades laboratoriais com esses desfechos. Altos níveis de FA estão associados à mortalidade, porém não há evidências de que a redução de seus níveis melhore os resultados.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **<mark>Considerações gerais e para implementação</mark>** -->
- Na DRC estágios 4 a 5D: para a atividade da fosfatase alcalina, indica-se a dosagem a cada 12 meses ou mais frequentemente na presença de PTH elevado. Em pacientes com DRC3 estágios A a 5D, sugerimos que as dosagensde PTH sérico ou fosfatase alcalina óssea específica sejam usadas para avaliar a doença óssea porque valores marcadamente altos ou baixos predizem a renovação óssea subjacente.  
- Os especialistas consideraramque a mensuração da FA no diagnóstico e avaliação de DMO-DRC pode ser usada como um teste adjunto ao PTH, mas se os valores forem altos, os testes de função hepática devem ser verificados. A FA pode ser usada como um teste de rotina para acompanhar a resposta à terapia ou determinar o status de remodelação óssea.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 3: Devemos utilizar quelantes de fósforo à base de cálcio para o tratamento de pacientes com hiperfosfatemia e DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar quelantes à base de cálcio para o tratamento da hiperfosfatemia secundária à DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com DRC estádios 2 a 5D (critérios diagnósticos de DRC) **Intervenção:** Quelantes de fósforo à base de cálcio (carbonato ou acetato de cálcio) **Comparador:** Seguimento clínico sem intervenção ou placebo  
**Desfechos:** calcemia, fosfatemia e PTH dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, mortalidade por todas as causas, mortalidade cardiovascular e fraturas ósseas.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Para essa questão não foi realizada busca sistemática da literatura. Essa recomendação já constava no PCDT anterior e  
foi mantida.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
Entre os quelantes de fósforo contendo cálcio, o carbonato de cálcio é o mais utilizado como primeira escolha. Ele quela o fósforo oriundo da dieta na luz intestinal, diminuindo sua absorção no tubo digestivo. O principal problema associado aos quelantes à base de cálcio é que podem resultar em sobrecarga de cálcio e episódios transitórios de hipercalcemia, exigindo que se reduza a dose de análogos da vitamina D e que se ajuste a concentração de cálcio na solução de diálise<sup>19-22</sup> . Em uma metaanálise da Cochrane, o uso de carbonato de cálcio diminuiu o fósforo quando comparado com o uso de placebo em média em 0,82 mg/dL (IC95% -1,24 a -0,4). Além disso, o uso desses medicamentos elevou o cálcio em média em 0,52 mg/dL (IC 95% 0,13 a 0,91). Esses resultados foram semelhantes a outras preparações de quelante à base de cálcio<sup>23</sup> .

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação** -->
De acordo com o painel de especialistas, os critérios de inclusão são:  
- DRC estágio 3 a 5 com fósforo acima de 4,5 mg/dL sem hipercalcemia e sem calcificação vascular ou;  
- DRC estágio 5D com fósforo acima de 5,5 mg/dL sem hipercalcemia e sem calcificação vascular e com PTH acima de 300 pg/mL.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 4: Devemos utilizar sevelâmer para o tratamento de pacientes com hiperfosfatemia secundária à DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar sevelâmer para o tratamento da hiperfosfatemia secundária à DRC  
(Recomendação forte, certeza da evidência moderada).  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com hiperfosfatemia associada à <mark>DRC estágios 3 a 5D</mark>  
**Intervenção** : Sevelâmer  
**Comparador** : Seguimento clínico com tratamento padrão (carbonato ou acetato de cálcio)  
**Desfechos** : Calcemia, fosfatemia e PTH dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Foi conduzida uma busca nas bases de dados _<mark>The</mark> Cochrane Library_ , MedLine (via PubMed), Embase (Elsevier), Epistemonikos e NICE até 19 de agosto de 2021. A busca resultou em 2.177 referências, das quais 291 foram excluídas por estarem duplicadas. Um total de 1.886 referências foram triadas por meio da leitura de título e resumos. Foram identificadas 14 revisões sistemáticas sobre o tema. Por fim, uma revisão sistemática (RS) foi incluída para a síntese de evidências. <mark>A RS elaborada por Phannajit et al. (2021)</mark><sup>24</sup> <mark>, publicada na</mark> _<mark>Journal of Nephrology,</mark>_ <mark>teve como objetivo avaliar a segurança e eficácia dos quelantes de fósforo no tratamento da hiperfosfatemia de pacientes com DRC dialítica e não dialítica quanto aos níveis de PTH, cálcio, fósforo, desfechos clínicos de eficácia e eventos adversos. Foram incluídos 127 ECR e 20.215 pacientes, sendo que 64 estudos avaliaram o uso de sevelâmer e destes, 36 utilizaram como comparador quelantes a base de cálcio. A</mark> descrição detalhada dos métodos e resultados da busca está disponível no Relatório de Recomendação nº 705/2022.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
O cloridrato de sevelâmer é um polímero quelante de fósforo que não contém cálcio nem alumínio. Como não é absorvido no intestino, é uma alternativa ao carbonato de cálcio para o controle da hiperfosfatemia em pacientes com DRC em estágios avançados. Os estudos clínicos com esse medicamento foram, na sua maioria, realizados em pacientes em TRS. Como principais achados em <mark>Phannajit et al.</mark><sup>26</sup> <mark>,</mark> o tratamento com sevelâmer foi associado com a redução da mortalidade por todas as causas em comparação com os quelantes de fosfato à base de cálcio (RR 0,594; IC95% 0,363 a 0,972; P=0,038). Além disso, o uso de sevelâmer foi considerado fator de proteção para a ocorrência de hipercalcemia quando comparado com os quelantes de fosfato à base de cálcio (RR 0,29; IC95% 0,19 a 0,45; P<0,00001) e foi associado à redução das taxas de hospitalização (RR 0,458; IC95% 0,264 a 0,794; P=0,005). Na mesma revisão sistemática, foi demonstrado que o sevelâmer também reduziu a calcificação vascular de pacientes em diálise quando comparados com quelantes de fosfato à base de cálcio (SMD -0,254; IC95% -0,420 a - 0,088; P=0,003).

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Justificativa para a recomendação** -->
O painel de especialistas considerou que a principal diferença entre a intervenção avaliada e a tecnologia já disponível no SUS é a sua ampliação de uso, de modo que o medicamento passe a ser primeira linha para pacientes em diálise com fósforo acima de 5,5 mg/dL por associar-se a menor risco de óbito quando comparado aos quelantes a base de cálcio. Também foi ressaltado que outros quelantes de fósforo não a base de cálcio, como lanthanum, e a base de ferro ou magnésio não possuem registro no Brasil e não são fabricados no país.  
**Considerações gerais e para implementação**  
Crianças e Adolescentes:  
- DRC estágios 2 a 4 não dialítica com níveis de fósforo acima dos limites normais para a faixa etária e com cálcio sérico corrigido para albumina normal ou acima do normal com ou sem uso de quelantes à base de cálcio;  
- DRC estágios 5 não dialítica ou em diálise com níveis de fósforo acima de 6,0 mg/dL (1 a 12 anos) e acima de 5,5 mg/dL (12-18 anos) e com cálcio sérico corrigido para albumina normal ou acima do normal, com ou sem uso de quelantes à base de cálcio.  
Adultos:  
- DRC em fase não dialítica com níveis de fósforo acima de 4,5 mg/dL ou;  
- DRC em fase dialítica com níveis de fósforo acima de 5,5 mg/dL;  
- É indicado que os níveis de cálcio e fósforo sejam medidos mensalmente e os níveis de PTH trimestralmente nos pacientes com DRC estágio 5D.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Perfil de evidências** -->
A Tabela A apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos: mortalidade por todas as causas, mortalidade por causas cardiovasculares, nível sérico de fósforo, hospitalização, nível sérico de cálcio, nível sérico de PTH, calcificação vascular, eventos cardíacos e eventos gastrointestinais (náusea, vômitos, diarreia, constipação) e hipercalcemia.  
**Tabela A -** Avaliação da certeza da evidência do uso de sevelâmer em pacientes com hiperfosfatemia associada à DRC  
|||**Ava**|**liação da Certe**|**za**||||**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Mortalidade p**|**Delineamento do**<br>**estudo**<br>**or todas as causas**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|**Certeza**|**Importância**|
|5421|ensaios clínicos|não|grave<sup>b</sup>|não grave|não grave|nenhum|RR 0,594|1 menos por 1.000|⨁⨁⨁◯|CRÍTICO|
|participantes<br>**Mortalidade p**|randomizados<br>**or causas cardiovascu**|grave<sup>a</sup><br>**lares**|||||(0,363 para<br>0,972)|(de 1 menos para 0<br>menos)|Moderada||
|3131<br>participantes|ensaios clínicos<br>randomizados|não<br>grave<sup>a</sup>|grave<sup>c</sup>|não grave|grave<sup>d</sup>|nenhum|RR 0,465<br>(0,112 para<br>1,937)|0 menos por 1.000<br>(de 2 menos para 0<br>menos)|⨁⨁◯◯<br>Baixa|CRÍTICO|
|**Nível sérico de**<br>8764|**Fósforo**<br>ensaios clínicos|não|grave<sup>e</sup>|não grave|não grave|nenhum|-|DMP 0,113 menor|⨁⨁⨁◯|CRÍTICO|
|participantes<br>**Hospitalização**|randomizados<br>|grave<sup>a</sup>||||||(0,343 menor para<br>0,118 mais alto)|Moderada||
|1029|ensaios clínicos|não|grave<sup>f</sup>|não grave|não grave|nenhum|RR 0,458|0 menos por 1.000|⨁⨁⨁◯|CRÍTICO|
|participantes|randomizados|grave<sup>a</sup>|||||(0,264 para<br>0,794)|(de 1 menos para 0<br>menos)|Moderada||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Nível sérico de Cálcio** -->
|||**Av**|**aliação da Certe**|**za**||||**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|**Certeza**|**Importância**|
|7397|ensaios clínicos|não|grave<sup>g</sup>|não grave|não grave|nenhum|-|DMP|⨁⨁⨁◯|IMPORTANTE|
|participantes|randomizados|grave<sup>a</sup>||||||0,985 menor<br>(1,262 menor para<br>0,709 menor)|Moderada||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Nível sérico de PTH** -->
|7208<br>participantes<br>**Calcificação va**|ensaios clínicos<br>randomizados<br>**scular**|não<br>grave<sup>a</sup>|grave<sup>h</sup>|não grave|grave<sup>d</sup>|nenhum|-|DMP 0,014 menor<br>(0,446 menor para<br>0,418 mais alto)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|
|1016|ensaios clínicos|não|grave<sup>i</sup>|não grave|não grave|nenhum|-|DMP|⨁⨁⨁◯|IMPORTANTE|
|participantes|randomizados|grave<sup>a</sup>||||||0,254 menor<br>(0,42 menor para<br>0,088 menor)|Moderada||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Eventos cardíacos** -->
|3993|ensaios clínicos|não|grave<sup>j</sup>|não grave|grave<sup>d</sup>|nenhum|RR 0,462|0 menos por 1.000|⨁⨁◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|
|participantes|randomizados|grave<sup>a</sup>|||||(0,162 para|(de 1 menos para 0|Baixa||
||||||||1,315)|menos)|||  
**Eventos gastrointestinais: náuseas**  
|||**Av**|**aliação da Certe**|**za**||||**Efeito**|||
|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|**Certeza**|**Importância**|
|305|ensaios clínicos|não|não grave|não grave|grave<sup>d</sup>|nenhum|RR 0,84|1 menos por 1.000|⨁⨁⨁◯|NÃO|
|participantes<br>**Eventos gastro**|randomizados<br>**intestinais: vômitos**|grave<sup>a</sup>|||||(0,48 para<br>1,49)|(de 1 menos para 0<br>menos)|Moderada|IMPORTANTE|
|203|ensaios clínicos|não|não grave|não grave|grave<sup>d,k</sup>|nenhum|RR 1,03|1 menos por 1.000|⨁⨁⨁◯|NÃO|
|participantes<br>**Eventos gastro**|randomizados<br>**intestinais: diarreia**|grave<sup>a</sup>|||||(0,57 para<br>1,86)|(de 2 menos para 1<br>menos)|Moderada|IMPORTANTE|
|255|ensaios clínicos|não|não grave|não grave|grave<sup>d,k</sup>|nenhum|RR 1,03|1 menos por 1.000|⨁⨁⨁◯|NÃO|
|participantes|randomizados|grave<sup>a</sup>|||||(0,55 para<br>1,91)|(de 2 menos para 1<br>menos)|Moderada|IMPORTANTE|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Eventos gastrointestinais: constipação** -->
|2542<br>participantes|ensaios clínicos<br>randomizados|não<br>grave<sup>a</sup>|não grave|não grave|grave<sup>d</sup>|nenhum|RR 1,51<br>(0,38 para|2 menos por 1.000<br>(de 6 menos para 0|⨁⨁⨁◯<br>Moderada|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|
||||||||6,02)|menos)|||
|**Hipercalcemia**<br>3918|ensaios clínicos|não|não grave|não grave|não grave|nenhum|RR 0,29|0 menos por 1.000|⨁⨁⨁⨁|IMPORTANTE|
|participantes|randomizados|grave<sup>a</sup>|||||(0,19 para|(de 0 menos para 0|Alta||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Hipercalcemia** -->
|||**Av**|**aliação da Certe**|**za**|||**E**|**feito**|||
|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|**Certeza**|**Importância**|
||||||||0,45)|menos)|||  
**IC95%: intervalo de confiança de 95%; RR: risco relativo.**  
**a** . De acordo com a Escala de Jadad, a maioria dos estudos foi considerada de boa qualidade, apresentando baixo risco de viés (escore de 3-5);  
**b** . Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> =69,3%); análise por subgrupos;  
**c** . Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 84,45%); análise por subgrupos;  
**d** . Amplo intervalo de confiança (IC95%) em torno da estimativa de efeito, incluindo a nulidade, sendo impreciso em relação a risco ou benefício;  
**e** . Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 94,15%); análise por subgrupos;  
- **f.** Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> =80,52%);  
- **g** . Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 94,06%);  
- **h** . Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 95,84%);  
- **i.** Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 78,99%);  
- **j.** Presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 68,35%);  
**k.** Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos dicotômicos (300 eventos).  
**Tabela para tomada de decisão (** **_Evidence to Decision table- EtD_ )**  
<mark>A</mark> **<mark>Tabela B</mark>** <mark>apresenta o processo de tomada de decisão sobre o uso do sevelâmer para o tratamento de pacientes com hiperfosfatemia e DRC baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.</mark>  
**<mark>Tabela B</mark>** <mark>- Processo de tomada de decisão referente ao uso de sevelâmer para o tratamento de pacientes com hiperfosfatemia e DRC</mark>  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios:**|Grande|Sevelâmer reduziu a mortalidade por todas as causas, a taxa de<br>hospitalização e os níveis de calcificação vascular. Como principais<br>achados, sevelâmer reduziu a mortalidade por todas as causas (RR<br>0,594; IC 95% 0,363–0,972; P= 0,038) em comparação com os<br>quelantes de fosfato à base de cálcio (carbonato e acetato de cálcio).<br>Sevelâmer foi associado à redução das taxas de hospitalização (RR<br>0,458; IC 95% 0,264–0,794; P=0,005). Sevelâmer também reduziu<br>significativamente a calcificação vascular de pacientes em diálise<br>quando comparados com quelantes de fosfato à base de cálcio (SMD=<br>-0,254; IC 95% -0,420, -0,088; P=0,003).|
|**Riscos:**|Trivial|Unanimidade entre os painelistas de que não houve eventos adversos<br>importantes relacionados à intervenção|
|**Balanço dos riscos**<br>**e benefícios:**|Favorece a intervenção|Unanimidade entre os painelistas de que não houve diferença<br>estatística entre os grupos para eventos adversos e que a intervenção<br>demonstrou efeito protetor para desfechos importantes.|
|**Certeza da**<br>**evidência:**|Moderada|Os painelistas consideraram as evidências para a maioria dos<br>desfechos como moderada. Nível sérico de PTH e eventos cardíacos<br>como baixa e um foi julgado como alta (hipercalcemia).|
|**Custos:**|Custo moderado|Todos os especialistas consideraram o aumento do custo em relação<br>ao comparador. A análise mostrou que o uso de sevelâmer resulta em<br>um custo incremental de R$ 1.164,00 ao ano. Para os especialistas,<br>com a ampliação do uso do cinacalcete, os pacientes apresentarão<br>menos hiperfosfatemia e talvez a indicação do uso do sevelâmer seja<br>menor do que foi estimada para o cálculo do IO|
|**Custo Efetividade:**|Favorece a intervenção|Os especialistas consideraram o valor por morte evitada. Ademais, em<br>análise econômica detalhada no Relatório de Recomendação nº<br>705/2022, observou-se que a custo-efetividade do sevelâmer em<br>comparação aos quelantes à base de cálcio foi de R$ 3.195,00 para o<br>sevelâmer e R$ 419,00 para o carbonato de cálcio.|
|**Aceitabilidade:**|Sim|- Alinhamento do Brasil com as recomendações do KDIGO 2017,|  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|||Sociedades Canadense, Britânica, Japonesa e Brasileira de Nefrologia;<br>- Possibilidade de diminuir a mortalidade no Brasil dos pacientes com<br>DRC em diálise;<br>-Pela perspectiva do paciente, não foi identificada nenhuma barreira<br>quanto à aceitabilidade da intervenção em análise, no SUS, pelas<br>partes interessadas.|
|**Viabilidade de**|Sim|Tendo em vista que o tratamento para hiperfosfatemia já é ofertado|
|**implementação:**||pelo SUS, as questões de implementação já estão consolidadas. O<br>painel de especialistas considerou que o sevelêmer já é um<br>medicamento disponível no SUS e apresenta evidências de efetividade<br>e segurança quando utilizado em pacientes com hiperfosfatemia<br>associada à DRC.|
|**Outras**<br>**considerações**|-|Não foram reportadas outras considerações.|  
DRC: doença renal crônica; SUS: sistema único de saúde;  
Fonte: Autoria própria.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 5: Devemos utilizar calcitriol para o tratamento de pacientes com hiperparatireoidismo secundário à DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar calcitriol para o tratamento de hiperparatireoidismo secundário à DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com hiperparatireoidismo secundário à DMO <mark>-DRC estágios 3 a 5D (c</mark> ritérios diagnósticos de DRC e de hiperparatireoidismo segundo o estágio de DRC)  
**Intervenção:** Calcitriol  
**Comparador:** Seguimento clínico sem intervenção ou placebo  
**Desfechos:** PTH dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Para essa questão não foi realizada busca sistemática da literatura. Essa recomendação consta no KDIGO<sup>6</sup> e foi adotada.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
Desde 2009, o KDIGO<sup>6</sup> recomenda o uso do calcitriol e outros análogos da vitamina D no tratamento de HPTS em pacientes com DRC de 3 a 5D, que apresentem PTH sérico acima do limite superior do método. Ainda não há ECRs demonstrando efeitos benéficos do calcitriol ou de análogos da vitamina D nos desfechos em nível de paciente, como eventos cardíacos ou mortalidade, e o nível ideal de PTH na DRC estágios 3 a 5D não é conhecido. No entanto, além do KDIGO, o Canadá e o Japão também estabeleceram suas próprias recomendações dos valores de referência para o PTH para pacientes com DRC 5D, sendo de 2 a 9 vezes o limite superior do método<sup>7,8,9</sup> .  
Apesar da falta de desfechos clínicos rígidos, vários ensaios clínicos randomizados bem conduzidos citados na acima referida diretriz de 2009 relataram benefícios de calcitriol ou análogos da vitamina D, principalmente envolvidos em desfechos bioquímicos e histomorfometria óssea em pacientes com HPTS secundário à DRC.  
O calcitriol é a forma ativa da vitamina D (1,25-OH2-vitamina D). O calcitriol e os análogos da vitamina D têm sido a base do tratamento de pacientes com DRC nos estágios 3 a 5D para corrigir as alterações no metabolismo mineral e ósseo e reduzir o risco de HPTS ou a sua progressão. A deficiência de vitamina D resulta na diminuição da absorção intestinal de cálcio e pode levar à hipocalcemia, um importante estímulo para a secreção de PTH. Isto leva à proliferação de células da paratireóide, contribuindo para a HPTS. A incidência e a gravidade da HPTS aumentam conforme a função renal diminui<sup>9,10</sup> . Neste contexto, pacientes com DRC estágio 3-5 que não estejam em TRS e que tenham o PTH sérico acima do limite superior do método devem ser tratados, inicialmente, para corrigir hiperfosfatemia, hipocalcemia e deficiência de vitamina D. Os pacientes em que o PTH não seja corrigido após medidas para correção da hiperfosfatemia, hipocalcemia ou deficiência de vitamina D e que tenham um aumento progressivo do PTH devem iniciar tratamento com calcitriol ou análogos de vitamina D<sup>14-16</sup> . No entanto, embora os benefícios fossem predominantemente relacionados à supressão do HPTS, os eventos adversos da hipercalcemia foram considerados preocupantes no KDIGO de 2009. Recentemente, meta-análises confirmaram a associação de risco de hipercalcemia com calcitriol e análogos da vitamina D<sup>23,24</sup> .  
Já em adultos com DRC estágios 3 a 5 sem diálise, o KDIGO sugere que o calcitriol e os análogos da vitamina D não sejam usados rotineiramente. E, em crianças, calcitriol e análogos da vitamina D podem ser considerados para manter os níveis de cálcio sérico na faixa normal apropriada para a idade<sup>12-14</sup> . Nos pacientes com DRC que forem submetidos à paratireoidectomia, pode ser necessário o uso de calcitriol no pós-operatório no caso de desenvolvimento de síndrome da fome óssea<sup>25-27</sup> . O uso desse fármaco nessa situação específica já foi avaliado, demonstrando que os pacientes que receberam calcitriol tiveram hipocalcemia menos grave e necessitaram de menores doses de suplementação com cálcio quando comparados com os pacientes que receberam placebo. Pela gravidade desse quadro, os pacientes submetidos a paratireoidectomia devem ser adequadamente monitorizados e recomenda-se que o calcitriol seja iniciado, com as doses reguladas conforme os níveis de cálcio total e de fósforo.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação** -->
De acordo com o painel de especialistas, os critérios de inclusão são:  
- crianças com DRC estágios 2 a 5D com PTH acima de 300 pg/mL ou  
- <mark>DRC estágio 3A a 5 com</mark> PTH acima de 300 pg/mL ou  
- fome óssea (pós paratireoidectomia) ou  
- pacientes em diálise peritoneal com PTH acima de 300 pg/mL

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 6: Devemos utilizar paricalcitol para o tratamento de pacientes com hiperparatireoidismo secundário à DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar paricalcitol para o tratamento de hiperparatireoidismo secundário à DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com hiperparatireoidismo secundário à <mark>DRC estágios 3 a 5D</mark>  
(Critérios diagnósticos de DRC e de hiperparatireoidismo segundo o estágio de DRC)  
**Intervenção:** Paricalcitol  
**Comparador:** Seguimento clínico sem intervenção ou placebo;  
**Desfechos:** PTH dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Para essa questão não foi realizada busca sistemática da literatura. Essa recomendação já constava no PCDT anterior e foi mantida.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
O paricalcitol é um composto sintético cuja estrutura foi desenvolvida a partir da vitamina D2 natural, sendo um ativador seletivo do receptor de vitamina D destinado ao tratamento e prevenção do HPTS associado à DRC.  A vantagem do paricalcitol sobre o calcitriol seria o fato de estar associado a uma menor incidência de hipercalcemia e hiperfosfatemia por promover menor absorção desses elementos<sup>28</sup> .  
Em relação ao placebo, a efetividade e a segurança do paricalcitol injetável foram avaliadas em 3 ECRs multicêntricos, duplo cegos, com um total de 78 pacientes com DRC em TRS e com HPTS (PTH acima de 400 pg/mL). Após 12 semanas de tratamento objetivado no estudo, os pacientes que receberam paricalcitol apresentaram diminuição significativa nos níveis de PTH de 795± 86 para 406 ±106 pg/mL (P<0,001), enquanto que, no grupo placebo, não houve diferença entre os níveis de PTH pré- e pós-intervenção. O grupo que recebeu paricalcitol também apresentou redução nos níveis de fosfatase alcalina, não sendo observada hipercalcemia até que os níveis de PTH estivessem contro <mark>lados</mark><sup>29</sup> <mark>. Uma m</mark> eta-análise publicada em 2012 sumarizou o resultado de nove ECRs (832 pacientes) que compararam paricalcitol com placebo em pacientes com HPTS não em TRS. Os resultados desse estudo demonstraram que o risco relativo referente à diminuição dos níveis de PTH em pelo menos 30% dos pacientes foi de 6,37 (IC95% 4,64 a 8,74) com o uso do paricalcitol. O risco relativo de hipercalcemia (2,25; IC95% 0,81 a 6,26) não foi significativamente maior neste est <mark>udo</mark><sup>30</sup> <mark>.</mark> Uma segunda meta-análise, com aspectos metodológicos muito semelhantes a essa, também demonstrou resultados sim <mark>ilares</mark><sup>31</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação** -->
De acordo com o grupo elaborador, os seguintes critérios de elegibilidade devem ser considerados:  
Critérios de inclusão:  
-Pacientes adultos com <mark>DRC 5D</mark> com níveis séricos de PTH ≥ 300 pg/mL com normo ou hipocalcemia (condicionada à ampliação de uso)  
Critérios de exclusão:  
-Pacientes com hiperfosfatemia ou hipercalcemia

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **hiperparatireoidismo secundário à DRC?** -->
**<u>Recomendação:</u>** Recomendamos o uso de paricalcitol para o tratamento do hiperparatireoidismo secundário à DRC <mark>estágio 5D (recomendação forte e certeza da evidência moderada).</mark>  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com hiperfosfatemia associada a <mark>DRC estádios 3 a 5D</mark> (critérios diagnósticos de DRC e de hiperfosfatemia segundo o estágio de DRC)  
**Intervenção** : Paricalcitol  
**Comparador** : Calcitriol  
**Desfechos** : PTH dentro da normalidade, eventos cardíacos (IAM) calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Foi realizada busca das evidências nas bases de dados The Cochrane Library, MedLine (via PubMed), Embase (Elsevier), PubMed Central, Epistemonikos, NICE e Biblioteca Virtual de Saúde. A busca resultou em 2.435 referências, das quais 317 foram excluídas por estarem duplicadas. Um total de 2.118 referências foram triadas por meio da leitura de títulos e resumos e  
73 tiveram seus textos completos avaliados para confirmação da elegibilidade. Por fim, 13 revisões sistemáticas foram selecionadas. Destes estudos, uma revisão sistemática foi incluída para a síntese de evidências, a qual foi avaliada conforme a qualidade metodológica. Para identificação das evidências sobre a temática estudada, optou-se por selecionar a revisão sistemática de melhor qualidade metodológica que incluísse todos os estudos que atenderam a PICO.   Foi selecionada a revisão de Geng et al. (2020)<sup>32</sup> <mark>, cujo objetivo foi avaliar a segurança e eficácia do paricalcitol vs. análogos de vitamina D não seletivos no tratamento do HPTS em pacientes com DRC 5D quanto aos níveis de PTH, cálcio, fósforo e eventos adversos. A seleção realizada para atualização da revisão Geng et al., 202031 não resultou em novos estudos para inclusão. Foram incluídos 15 estudos para meta-análise sendo: 11 ECRs (8 ECRs comparando paricalcitol vs. calcitriol, 1 ECR comparando paricalcitol vs. maxacalcitol, 1 ECR comparando paricalcitol vs. alfacalcitol e 1 ECR comparando paricalcitol vs. cinacalcete), 3 estudos quasi experimentais comparando paricalcitol vs. calcitriol e; 1 ensaio clínico não randomizado comparando paricalcitol vs. calcitriol/doxercalcifero, totalizando 110.544 pacientes. A</mark> descrição detalhada dos métodos e resultados da busca estão no Relatório de Recomendação nº 703/2022.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
<mark>Como principais achados em Geng et al., 2020</mark> , <mark>o uso do paricalcitol esteveassociado com a redução da mortalidade por todas as causas quando comparado com outros análogos não seletivos de vitamina D. Não foram observadas diferenças significativas na incidência de eventos adversos como hipercalcemia e hiperfosfatemia e no controle dos níveis de PTH. A qualidade metodológica geral da revisão sistemática selecionada para atualização foi classificada como moderada. Segundo o GRADE, a qualidade da evidência para o desfecho de mortalidade por todas as causas foi moderada; muito baixa para níveis séricos de fósforo e baixa para os demais desfechos avaliados.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Justificativa para a recomendação** -->
<mark>Os níveis de cálcio e fósforo e de seus hormônios reguladores, PTH e calcitriol, são alterados por múltiplos fatores e o HPTS é uma das manifestações clássicas dos DMO-DRC. Segundo o censo da Sociedade Brasileira de Nefrologia (SBN), em 2020</mark><sup>35</sup> <mark>, estima-se que 144.779 pacientes estão em tratamento dialítico no Brasil. Destes, aproximadamente 18% apresentavam níveis de PTH acima de 600 pg/mL. O tratamento medicamentoso do DMO-DRC consiste no uso de quelantes de fósforo (à base de cálcio vs. não à base de cálcio), análogos da vitamina D (via oral e intravenoso) e calcimiméticos, associado à dieta com restrição de fósforo e adequação dialítica.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação** -->
De acordo com o painel de especialistas, os seguintes critérios de elegibilidade devem ser considerados:  
Critérios de inclusão:  
Pacientes adultos com <mark>DRC 5D</mark> com níveis séricos de PTH ≥ 300 pg/mL com normo ou hipocalcemia Critérios de exclusão:  
Pacientes com hiperfosfatemia ou hipercalcemia  
O painel de especialistas sugere que os níveis séricos de cálcio e fósforo sejam medidos mensalmente. A monitorização dos níveis de PTH deve ocorrer a cada 3 meses. Recomendam a dose de 0,04 a 0,1 ucg/kg de paricalcitol por administração, considerando os níveis de Ca e P e de PTH.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Perfil de evidências** -->
A **Tabela C** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos: mortalidade para todas as causas, níveis séricos de PTH, redução de PTH (maior ou igual a 50%), níveis séricos de cálcio, níveis séricos de fósforo e eventos adversos. Segundo o GRADE, a qualidade da evidência para o desfecho de mortalidade por todas as causas foi moderada; muito baixa para níveis séricos de fósforo e baixa para os demais desfechos avaliados.  
**Tabela C -** <mark>Avaliação da certeza da evidência do uso de paricalcitol para o tratamento do HPTS secundário à DRC estágio 5D</mark>  
||||**Avaliação da Ce**|**rteza**|||**№ de p**|**acientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Paricalcitol**|**Comparador**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|||
|**Mortalid**<br>4<br>**Níveis sér**|**ade por todas as**<br>ECR<br>**icos de PTH**|**causas**<br>grave<sup>a</sup>|não grave|não grave|não grave|nenhum|6119/56465<br>(10,8%)|5125/52993<br>(9,7%)|RR 0,84<br>(0,79 para<br>0,90)|15 menos<br>por 1.000<br>(de 20<br>menos para<br>10 menos)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|3|ECR|grave<sup>b</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|37|37|-|DPM 0,35<br>mais<br>(0,11<br>menos para<br>0,81 mais)|⨁⨁◯◯<br>Baixa|CRÍTICO|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Redução de PTH (Acima ou igual a 50%)** -->
|4<br>ECR|grave<sup>b</sup>|não grave|não grave|grave<sup>d</sup>|nenhum|109/174|101/178|RR 1,07|40 mais por|⨁⨁◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|||||||(62,6%)|(56,7%)|(0,85 para<br>1,36)|1.000<br>(de 85<br>menos para<br>204 mais)|Baixa||  
|||**Avaliação da Ce**|**rteza**|||**№ de pacientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Paricalcitol**<br>**Comparador**|**Relativo**|**Absoluto**|||
|**estudos**<br>**do estudo**|**de viés**||**indireta**||**considerações**||**(IC95%)**|**(IC95%)**|||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Níveis Séricos de Cálcio** -->
|6<br>ECR|grave<sup>e</sup>|não grave|não grave|grave<sup>f</sup>|nenhum|137|125|-|DPM 0,01<br>SD mais<br>(0,23<br>menos para<br>0,26 mais)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Níveis Séricos de Fósforo** -->
|5<br>ECR|grave<sup>e</sup>|grave<sup>g</sup>|não grave|grave<sup>h</sup>|nenhum|125|114|-<br>DPM 0,16<br>SD menor<br>(0.,57<br>menor para<br>0,25 mais<br>alto)|⨁◯◯◯<br>Muito<br>baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Eventos Adversos Gerais** -->
|3<br>ECR|grave|não grave|não grave|grave<sup>d</sup>|nenhum|48/75<br>(64,0%)|38/72<br>(52,8%)|RRR 1,16<br>(0,98 para<br>1,36)|84 mais por<br>1.000<br>(de 11<br>menos para<br>190 mais)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|  
ECR: ensaio clínico randomizado; IC95%: intervalo de confiança de 95%; RR: risco relativo; DPM: desvio padronizado de médias  
a. De acordo com a ferramenta ROBINS-I, todos os estudos apresentaram problemas relacionados ao viés de confundimento, viés na classificação das intervenções e por dados faltantes. Além disso, dois estudos apresentaram viés na seleção dos participantes.  
b. De acordo com a ferramenta RoB 2.0, os estudos apresentaram problemas no processo de randomização, desvios da intervenção pretendida e no relato dos desfechos.  
c. Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos contínuos (400 participantes; 200 por grupo); IC95% não é suficientemente estreito, favorecendo o controle (calcitriol).  
d. Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos dicotômicos (300 eventos); IC95% não é suficientemente estreito, incluindo a nulidade sendo impreciso em relação a risco ou benefício.  
e. De acordo com a ferramenta RoB 2.0, somente um estudo não apresentou problemas relacionados aos cinco domínios estudados. Os demais estudos apresentaram problemas no processo de randomização, desvios da intervenção pretendida e no relato dos desfechos.  
f. Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos contínuos (400 participantes; 200 por grupo); IC95% não é suficientemente estreito, incluindo a nulidade sendo impreciso em relação a risco ou benefício.  
g. Alta heterogeneidade entre os estudos (I2=52%).  
h. Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos contínuos (400 participantes; 200 por grupo); IC95% não é suficientemente estreito, no entanto, com tendência a favorecer a intervenção (paricalcitol).  
**Tabela para tomada de decisão (** **_Evidence to Decision table- EtD_ ):**  
A **Tabela D** apresenta o processo de tomada de decisão sobre o uso <mark>do paricalcitol</mark> para o tratamento <mark>do HPTS secundário</mark>  
à <mark>DRC estágio 5D</mark> baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo  
elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela D -** Processo de tomada de decisão referente ao uso de <mark>paricalcitol pa</mark> ra tratamento <mark>do HPTS secundário à DRC estágio 5D</mark>  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios:**|Grande|O painel de especialistas considerou que houve benefício relacionado ao<br>desfecho sobrevida geral em pacientes que fizeram uso de paricalcitol. O<br>desfecho mortalidade por todas as causas, com RR 0,84; IC 95% 0,79-<br>0,90; p <0,00001, como os níveis de PTH, SMD -0,53; IC95% -0,89-0,16,<br>demonstraram maior eficácia do tratamento com paricalcitol do que com<br>outros análogos não seletivos de vitamina D|
|**Riscos:**|Pequeno|O painel de especialistasconsiderou o fato de não terem sido observadas<br>diferenças significativas entre os grupos em relação aos eventos adversos.<br>A elevação do produto cálcio x fósforo não é considerada atualmente para<br>tomada decisões (interpretação do Ca e P individualmente).|
|**Balanço dos riscos e**<br>**benefícios:**|Favorece a<br>intervenção|Considerou-se que a sobrevida geral dos pacientes com uso de paricalcitol<br>foi melhor quando comparada ao grupo do calcitriol.|
|**Certeza da evidência:**|Moderada|O painel de especialistasconsiderou para a avaliação que o desfecho<br>primário dos estudos foi mortalidade. Reforçaram que quanto mais<br>precoce for iniciado o tratamento, melhor o resultado, pois quando iniciado<br>tardiamente, os pacientes já apresentam calcificação vascular e outras<br>complicações do DMO.|
|**Custos:**|Custo moderado|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico. A análise mostrou que o uso de paricalcitol resulta em um custo<br>incremental de R$ 1.475,00 ao ano|
|**Custo-efetividade:**|Favorece a<br>intervenção|O painel de especialistas considerou o desfecho de mortes evitadas.<br>Ademais, em análise econômica detalhada no Relatório de Recomendação<br>nº 703/2022, observou-se que a custo-efetividade do paricalcitol em<br>comparação ao calcitriol foi de R$ 966,00 para o calcitriol e R$ 3.655,00<br>para o paricalcitol|
|**Aceitabilidade:**|Sim|O painel de especialistas comentou que as recomendações corroboram<br>com a última diretriz da Sociedade Brasileira de Nefrologia em DMO|
|**Viabilidade**<br>**de**<br>**implementação:**|Sim|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|**Outras**|-|Não foram reportadas outras considerações.|  
|**Item da EtD**|**Julgamento dos**|**Justificativa**|
|---|---|---|
||**painelistas**||  
**considerações:**  
DMO: distúrbio mineral ósseo; SBN: Sociedade Brasileira de Nefrologia.  
Fonte: Autoria própria.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 8: Devemos utilizar o cinacalcete para o tratamento de pacientes com hiperparatireoidismo secundário à DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar o cinacalcete para o tratamento do hiperparatireoidismo secundário à DRC (recomendação não graduada e certeza de evidência moderada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com hiperparatireoidismo secundário à <mark>DRC estágio 3 a 5D</mark>  
(critérios diagnósticos de DRC e de hiperparatireoidismo segundo o estágio de DRC)  
**Intervenção:** Cinacalcete  
**Comparador:** Seguimento clínico sem intervenção ou placebo;  
**Desfechos:** PTH, calcemia e fosfatemia dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Foi realizada a busca das evidências nas bases de dados The Cochrane Library, MedLine (via PubMed), Embase (Elsevier), PubMed Central, Epistemonikos, NICE e Biblioteca Virtual de Saúde. A busca das evidências resultou em 5.508 referências, destas, 683 foram excluídas por estarem duplicadas. Um total de 4.825 referências foram triadas por meio da leitura de título e resumos, das quais 108 tiveram seus textos completos avaliados para confirmação da elegibilidade. Por fim, 21 revisões sistemáticas foram avaliadas para elegibilidade do estudo. Deste conjunto, 15 revisões foram incluídas para revisão da literatura e uma revisão sistemática foi incluída para atualização. A revisão de Palmer et al., 2020<sup>33</sup> foi escolhida como referência para atualização por se tratar de uma revisão com alta qualidade metodológica, por responder à pergunta PICO de interesse e também por incluir o maior número de estudos envolvendo o cinacalcete. Ademais, essa revisão sistemática avaliou a eficácia e segurança dos calcimiméticos para o tratamento de pacientes portadores de hiperparatireoidismo secundário à DRC. Palmer et al., 2020<sup>36</sup> é uma revisão sistemática com meta-análise em rede publicada no _American Journal of Kidney Diseases_ (AJKD), que avaliou as diversas opções terapêuticas para indivíduos portadores de hiperparatireoidismo secundário à doença renal crônica e que incluiu 36 ECRs, totalizando 11.247 pacientes. Destes, 32 estudos com pacientes com DRC em estágio 5 sob tratamento de diálise. Dois ensaios clínicos incluíram pacientes com DRC em estágio 3-4 que não foram submetidos a diálise ou transplante de rim, e dois ensaios com pacientes com DRC que receberam transplantes renais. Além dos diferentes grupos de pacientes, foram realizadas 5 diferentes comparações com o cinacalcete: (1) cinacalcete _vs._ placebo; (2) cinacalcete _vs._ vitamina D; (3) cinacalcete + baixa dose de vitamina D _vs._ vitamina D; (4) cinacalcete _vs._ paratireoidectomia; (5) cinacalcete _vs._ tratamento padrão (calcitriol ou paricalcitol). Além destas comparações, foram analisados e comparados diferentes tipos de calcimiméticos (cinacalcete _vs._ evocalcete e cinacalcete _vs._ etelcalcetide). Devido aos diversos tipos de calcimiméticos utilizados nesta RS, as evidências clínicas foram apresentadas por desfechos, considerando os dados dos estudos incluídos em Palmer et al., 2020<sup>36</sup> , que tiveram como intervenção o cinacalcete. A descrição detalhada dos métodos e resultados da busca estão no Relatório de Recomendação nº 704/2022.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
Não foram observadas diferenças significativas para mortalidade por todas as causas e cardiovascular entre o grupo que recebeu cinacalcete em comparação com placebo (RR 0,96; IC95% 0,89 a 1,04; P=0,36) e (RR 0,95; IC95% 0,84 a 1,08; P=0,43).  
Com relação ao nível sérico de PTH, foi observada uma diferença significativa entre os grupos de pacientes tratados com cinacalcete, com DMP de -0,80 (IC95% -1,01 a -0,58), que apresentaram níveis diminuídos de PTH em comparação ao grupo placebo (P<0,00001). A análise global revelou uma diferença significativa entre os grupos com DMPde -2,12 (IC95% -2,80 a - 1,44), favorecendo o cinacalcete na diminuição dos níveis de cálcio quando comparado a placebo ou outros os tratamentos (P<0,00001). A análise global sobre os níveis séricos de fósforo revelou uma diferença significativa entre os grupos com DMP de -0,56 (IC95% -0,89 a -0,22), favorecendo o cinacalcete na diminuição dos níveis de fósforo quando comparado a placebo ou outros os tratamentos (P<0,00001). A análise global do produto Ca x P revelou uma diferença significativa entre os grupos com DMP de -1,21 (IC95% -1,77 a -0,64), favorecendo o cinacalcete na diminuição do nível do produto Ca x P quando comparado a placebo ou outros tratamentos (P<0,00001). Não houve diferença significativa entre os grupos para redução na incidência de eventos cardíacos (RR 1,62; IC95% 0,61 a 1,43; P=0,33) e na prevenção de fraturas (RR 0,52; IC95% 0,12 a 2,27; P=0,39). Em relação aos desfechos de segurança da tecnologia, observou-se risco aumentado para eventos gastrointestinais como náusea no grupo que recebeu o cinacalcete em comparação com o placebo (RR 1,74; IC95% 1,47 a 2,05; P<0,00001). A análise global apresentou um risco aumentado de incidência de vômitos para o grupo que recebeu cinacalcete (RR 1,88; IC95% 1,53 a 2,31; P<0,00001). Em relação ao risco relativo global para a incidência de diarréia, não houve diferença significativa entre o grupo que recebeu cinacalcete em comparação com o grupo controle (RR 1,13; IC95% 1,02 a 1,27; P=0,84). Efeito geral significativo para a incidência de hipocalcemia no grupo que recebeu o cinacalcete em comparação com o placebo (RR 8,30; IC95% 4,12 a 16,76; P<0,00001).

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Justificativa para a recomendação** -->
Foi recomendada a ampliação do uso do cinacalcete para o tratamento de pacientes com hiperparatireoidismo secundário à doença renal crônica, submetidos à diálise, com níveis de PTH acima de 300 pg/mL e na ausência de hipocalcemia e para pacientes transplantados renais com PTH acima de 120 pg/mL ou com hipercalcemia, considerando-se qu  e o cinacalcete, embora sem impacto na mortalidade dos pacientes em diálise, possui eficácia superior e segurança semelhante ao comparador paricalcitol, diminuindo o risco de paratireoidectomia dos pacientes em diálise, procedimento cirúrgico complexo e realizado apenas em poucos serviços de referência, além de ser custo-efetivo.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação** -->
Os critérios de elegibilidade para uso do cinacalcete para o tratamento do HPTS à DRC são:  
Critérios de inclusão:  
- Pacientes adultos com DRC em diálise há pelo menos 3 meses, com PTH ≥ 300 pg/mL na ausência de hipocalcemia;  
- Pacientes transplantados renais com PTH ≥ 120 pg/mL;  
- Pacientes transplantados renais com hipercalcemia.  
Critérios de exclusão:  
- Pacientes com Hipocalcemia;  
- DRC 3 a 5;  
- Pacientes transplantados renais com hipercalcemia de etiologias não relacionadas ao HPTS.  
Além disso, o painel de recomendação também sugeriu que:  
- Dosagem mensal dos níveis séricos de cálcio e fósforo e trimestral do PTH;  
- Dose recomendada de 30 a 180 mg/dia, considerando os níveis de Ca e P e de PTH.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **<mark>Perfil de evidências</mark>** -->
A **Tabela E** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos: mortalidade para todas as causas, níveis séricos de PTH, redução de PTH (maior ou igual a 50%), níveis séricos de cálcio, níveis séricos de fósforo e eventos adversos. Segundo o GRADE, a qualidade da evidência para o desfecho de mortalidade por todas as causas foi moderada; muito baixa, para níveis séricos de fósforo e baixa, para os demais desfechos avaliados.  
**Tabela E -** Avaliação da certeza da evidência do uso de cinacalcete para o tratamento de pacientes com hiperparatireoidismo secundário à DRC  
||||**Avaliação da C**|**erteza**|||**№ de pac**|**ientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Mortalid**|**Delineamento**<br>**do estudo**<br>**ade por todas as c**|**Risco**<br>**de**<br>**viés**<br>**ausas - c**|**Inconsistência**<br>**inacalcete vs pla**|**Evidência**<br>**indireta**<br>**cebo em DRC**|**Imprecisão**<br>**em diálise**|**Outras**<br>**considerações**|**Cinacalcete**|**Controle**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|||
|11|ensaios|não|não grave|não grave|não grave|nenhum|716/3036|729/2720|RR 0,97|8 menos|⨁⨁⨁⨁|CRÍTICO|
|**Mortalid**|clínicos<br>randomizados<br>**ade por todas as c**|grave<br>**ausas - c**|**inacalcete vs pla**|**cebo em DRC**|**3-4**||(23,6%)|(26,8%)|(0,89<br>para 1<br>1,05)|por 1.000<br>(de 29<br>menos<br>para 13<br>mais)|ALTA||  
|2|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|2/329<br>(0,6%)|4/129<br>(3,1%)|RR 0,28<br>(0,05<br>para<br>1,44)|22 menos<br>por 1.000<br>(de 29<br>menos<br>para 14<br>mais)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Mortalid**|**ade cardiovascula**|**r - cinac**|**alcete vs placebo**|**- DRC em dia**|**lise**||||||||
|8|ensaios|não|não grave|não grave|grave<sup>a,b</sup>|nenhum|378/2339|391/2233|RR 0,96|7 menos|⨁⨁⨁◯|CRÍTICO|
||clínicos<br>randomizados|grave|||||(16,2%)|(17,5%)|(0,85<br>para<br>1,09)|por 1.000<br>(de 26<br>menos<br>para 16<br>mais)|MODERADA||
|**Mortalid**|**ade cardiovascula**|**r - cinac**|**alcete vs placebo**|**- DRC 3-4**|||||||||
|2|ensaios|não|não grave|não grave|grave<sup>a,b</sup>|nenhum|2/329|4/129|RR 0,28|22 menos|⨁⨁⨁◯|CRÍTICO|
||clínicos|grave|||||(0,6%)|(3,1%)|(0,05|por 1.000|MODERADA||  
||||**Avaliação da**|**Certeza**|||**№ de pa**|**cientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|<br>**Evidência**|**Imprecisão**|**Outras**|**Cinacalcete**|**Controle**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de**<br>**viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||
|**Níveis sé**|randomizados<br>**ricos de PTH - ci**|**nacalcete**|**vs controle**||||||para<br>1,44)|(de 29<br>menos<br>para 14<br>mais)|||
|8<br>**Níveis sé**|ensaios<br>clínicos<br>randomizados<br>**ricos de calcio - c**|não<br>grave<br>**inacalcete**|grave<sup>c</sup><br>**vs control - DR**|não grave<br>**C em diálise**|não grave|nenhum|932|702|-|0<br>(0 para 0)|⨁⨁⨁◯<br>MODERADA|CRÍTICO|
|5|ensaios<br>clínicos<br>randomizados|não<br>grave|grave<sup>c</sup>|não grave|não grave|nenhum|531|329|-|0<br>(0 para 0)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|
|**Níveis sé**|**ricos de fósforo -**|**cinacalce**|**te vs placebo - D**|**RC em diálise**|||||||||
|6|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|não grave|nenhum|903|699|-|DPM<br>0,22 SD<br>menor<br>(0,32<br>menor<br>para 0,12<br>menor)|⨁⨁⨁⨁<br>ALTA|IMPORTANTE|
|**Níveis sé**|**ricos de fósforo -**|**cinacalce**|**te vs outros trat**|**amentos**|||||||||
|4|ensaios<br>clínicos<br>randomizados|não<br>grave|grave<sup>c</sup>|não grave|não grave|nenhum|662|451|-|SMD<br>1,19 SD<br>menor<br>(2,01<br>menor|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|  
||||**Avaliação da**|**Certeza**|||**№ de pa**|**cientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Cinacalcete**|**Controle**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de**<br>**viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||
|**Eventos**|**Adversos Cardiov**<br>|**asculares**|**- cinacalcete vs**|**placebo**||||||para 0,37<br>menor)|||
|2|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|74/1965<br>(3,8%)|91/1950<br>(4,7%)|RR 0,81<br>(0,60<br>para<br>1,09)|9 menos<br>por 1.000<br>(de 19<br>menos<br>para 4<br>mais)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|
|**Incidênc**|**ia de fraturas - ci**|**nacalcete**|**vs controle - DR**|**C em dialise**|||||||||
|2|ensaios<br>clínicos<br>randomizados|não<br>grave|grave<sup>c</sup>|não grave|grave<sup>a,b</sup>|nenhum|240/2003<br>(12,0%)|260/1962<br>(13,3%)|RR 0,52<br>(0,12<br>para<br>2,27)|64 menos<br>por 1.000<br>(de 117<br>menos<br>para 168<br>mais)|⨁⨁◯◯<br>BAIXA|IMPORTANTE|
|**produto**<br>|**cálcio x fósforo -**<br>|**cinacalcet**|**e vs placebo - D**|**RC em dialise**|||||||||
|6|ensaios<br>clínicos<br>randomizados|não<br>grave|grave<sup>c</sup>|não grave|não grave|nenhum|902|699|-|DPM<br>0,41 SD<br>menor<br>(0,74<br>menor<br>para 0,08<br>menor)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|
|**Incidênc**|**ia de paratireoide**|**ctomia**|||||||||||
|6|ensaios|não|não grave|não grave|grave<sup>a</sup>|nenhum|141/2579|288/2350|RR 0,45|67 menos|⨁⨁⨁◯|IMPORTANTE|  
||||**Avaliação da**|**Certeza**|||**№ de pa**|**cientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Cinacalcete**|**Controle**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|||
|**Eventos**|clínicos<br>randomizados<br>**gastrointestinais -**|grave<br>**incidenc**|**ia de nauseas - c**|**inacalcete vs p**|**lacebo**||(5,5%)|(12,3%)|(0,36<br>para<br>0,55)|por 1.000<br>(de 78<br>menos<br>para 55<br>menos)|MODERADA<br>||
|11|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|913/3279<br>(27,8%)|434/2788<br>(15,6%)|RR 1,74<br>(1,47<br>para<br>2,05)|115 mais<br>por 1.000<br>(de 73<br>mais para<br>163<br>mais)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|
|**Eventos**|**gastrointestinais -**|**incidenc**|**ia de vomitos - c**|**inacalcete vs p**|**lacebo**||||||||
|7<br>**Eventos**|ensaios<br>clínicos<br>randomizados<br>**gastrointestinais -**|não<br>grave<br>**incidenc**|não grave<br>**ia de diarreia - c**|não grave<br>**inacalcete vs p**|grave<sup>a</sup><br>**lacebo**|nenhum|751/3175<br>(23,7%)|349/2711<br>(12,9%)|RR 1,90<br>(1,69<br>para<br>2,13)|116 mais<br>por 1.000<br>(de 89<br>mais para<br>145<br>mais)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|
|5|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|522/2644<br>(19,7%)|392/2193<br>(17,9%)|RR 1,13<br>(1,01<br>para<br>1,28)|23 mais<br>por 1.000<br>(de 2<br>mais para<br>50 mais)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|  
**Incidencia de hipocalcemia - cinacalcete vs placebo**  
||||**Avaliação da C**|**erteza**|||**№ de pac**|**ientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Cinacalcete**|**Controle**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de**<br>**viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||
|9|ensaios<br>clínicos<br>randomizados|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|265/1047<br>(25,3%)|8/764<br>(1,0%)|RR 8,30<br>(4,12<br>para<br>16,76)|76 mais<br>por 1.000<br>(de 33<br>mais para<br>165<br>mais)|⨁⨁⨁◯<br>MODERADA|IMPORTANTE|  
IC: Intervalo de Confiança; RR: Risco Relativo; ECR: ensaio clínico randomizado; DPM: Diferença padronizada das médias  
a. intervalo de confiança amplo;  
b. tamanho da amostra pequeno;  
c. alta heterogeneidade;  
- d. intervalo de confiança amplo e divergente

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 9: Devemos utilizar o cinacalcete ao invés de paricalcitol para o tratamento de pacientes com hiperparatireoidismo secundário à DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar o cinacalcete para o tratamento do hiperparatireoidismo secundário à DRC condicionada à decisão final de ampliação de uso (recomendação forte e certeza da evidência moderada).  
A estrutura PICO para esta pergunta foi:  
**População** : Pacientes com hiperfosfatemia associada a <mark>DRC estágio 3 a 5D</mark>  
**Intervenção** : Cinacalcete  
**Comparador** : calcitriol ou paricalcitol  
**Desfechos** : PTH, calcemia e fosfatemia dentro da normalidade, eventos cardíacos (IAM), calcificação vascular, fraturas ósseas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca** -->
Foi realizada a busca das evidências nas bases de dados The Cochrane Library, MedLine (via PubMed), Embase (Elsevier), PubMed Central, Epistemonikos, NICE e Biblioteca Virtual de Saúde. A busca das evidências resultou em 5.508 referências, das quais, 683 foram excluídas por estarem duplicadas. Um total de 4.825 referências foram triadas por meio da leitura de título e resumos, das quais 108 tiveram seus textos completos avaliados para confirmação da elegibilidade. Por fim, 21 revisões sistemáticas foram avaliadas para elegibilidade. Deste conjunto, 15 revisões foram incluídas para revisão da literatura e uma revisão sistemática foi incluída para atualização e síntese de evidências por incluir todos os estudos que atenderam a PICO e de melhor qualidade metodológica, conforme avaliação. Após análise de todas as revisões sistemáticas, a revisão de Palmer et al. (2020)<sup>36</sup> foi escolhida como referência para atualização por se tratar de uma revisão com alta qualidade metodológica e também por incluir o maior número de estudos envolvendo o cinacalcete. Ademais, essa revisão sistemática teve o mesmo objetivo desta PICO: avaliar a eficácia e segurança dos calcimiméticos para o tratamento de pacientes portadores de hiperparatireoidismo secundário à DRC.  
Palmer et al.<sup>36</sup> (2020) é uma revisão sistemática com meta-análise em rede publicada no _American Journal of Kidney Diseases_ (AJKD), que avaliou as diversas opções terapêuticas para indivíduos portadores de hiperparatireoidismo secundário à doença renal crônica. Em Palmer et al.<sup>36</sup> (2020) foram incluídos 36 ECR, totalizando 11.247 pacientes. Destes, 32 estudos com pacientes com DRC em estágio 5 sob tratamento de diálise. Dois ensaios clínicos incluíram pacientes com DRC em estágio 3-4 que não foram submetidos a diálise ou transplante de rim, e dois ensaios com pacientes com DRC que receberam transplantes renais. Além dos diferentes grupos de pacientes, foram realizadas 5 diferentes comparações com o cinacalcete: (1) cinacalcete _versus_ placebo; (2) cinacalcete _versus_ vitamina D; (3) cinacalcete + baixa dose de vitamina D _versus_ vitamina D; (4) cinacalcete _versus_ paratireoidectomia; (5) cinacalcete _versus_ tratamento padrão (calcitriol ou paricalcitol). Além destas comparações, foram analisados e comparados diferentes tipos de calcimiméticos (cinacalcete _versus_ evocalcete e cinacalcete _versus_ etelcalcetide). Devido aos diversos tipos de calcimiméticos utilizados nesta RS, as evidências clínicas deste parecer foram apresentadas por desfechos, considerando os dados dos estudos incluídos em Palmer et al., 2020<sup>36</sup> , que tiveram como intervenção o cinacalcete. A descrição detalhada dos métodos e resultados da busca estão no Relatório de Recomendação nº 704/2022.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências** -->
Em relação aos desfechos primários, houve diferença estatisticamente significativa entre o grupo que recebeu cinacalcete em comparação com o grupo controle para os níveis de PTH (DMP -1,78; IC95% -2,75 a -0,82; P<0,00001), porém, não foram observadas diferenças significativas para mortalidade por todas as causas (RR 0,96; IC95% 0,62 a 1,50; P=0,87) e mortalidade por causa cardiovascular (RR 0,25; IC95% 0,03 a 2,28; P=0,22). Para os desfechos secundários, houve diferença estatisticamente significativa entre o grupo que recebeu cinacalcete em comparação com o grupo controle para os níveis séricos de cálcio (DMP -4,90; IC95% -6,75 a -3,04; P<0,00001), níveis séricos de fósforo (DMP -1,19; IC95% -2,01 a -0,37; P<0,00001) e produto Ca x P (DMP -3,00; IC95% -5,49 a -0,50; P<0,00001). O uso do cinacalcete também foi estatisticamente significativo na prevenção  
de paratireoidectomia, quando comparado ao tratamento padrão (RR 0,21; IC95% 0,05 a 0,83; P<0,03). Não houve diferença significativa entre os grupos para redução na incidência de eventos cardíacos (RR 1,62; IC95% 0,61 a 1,43; P=0,33) e na prevenção de fraturas (RR 0,52; IC95% 0,12 a 2,27; P=0,39). Em relação aos desfechos de segurança da tecnologia, observouse risco aumentado para eventos gastrointestinais como náusea (RR 2,39; IC95% 1,23 a 4,66; P<0,01) para o grupo que recebeu cinacalcete. Foi observado também um risco elevado na incidência de hipocalcemia no grupo que recebeu o cinacalcete em comparação com o grupo controle (RR 8,46; IC95% 5,48 a 13,05; P<0,00001).

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação:** -->
De acordo com os painelistas, os critérios de inclusão e exclusão para uso do cinacalcete para o tratamento do HPTS à DRC são:  
Critérios de inclusão:  
- Pacientes adultos com DRC em diálise há pelo menos 3 meses, com PTH ≥ 300 pg/mL na ausência de hipocalcemia;  
- Pacientes transplantados renais com PTH ≥ 120 pg/mL (condicionada a inclusão dos pacientes transplantados no IO);  
- Pacientes transplantados renai com hipercalcemia.  
Critérios de exclusão:  
- Pacientes com Hipocalcemia;  
- <mark>DRC estágio 3 a 5D;</mark>  
- Pacientes transplantados renais com hipercalcemia de etiologias não relacionadas ao HPTS.  
Sugerem realizar  
- Dosagem mensal dos níveis séricos de cálcio e fósforo e trimestral do PTH;  
- A dose recomendada é de 30 a 180 mg/dia, considerando os níveis de Ca e P e de PTH.  
Considerar que o uso do cinacalcete pode não ser isolado e sim em associação aos análogos da vitamina D (calcitriol ou paricalcitol), pois os efeitos são sinérgicos.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Perfil de evidências:** -->
A **Tabela F** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos mortalidade para todas as causas, mortalidade cardiovascular, níveis séricos de PTH, níveis séricos de cálcio, níveis séricos de fósforo, eventos cardíacos, incidência de fraturas, produto cálcio x fósforo, paratireoidectomia, náusea, vômitos, diarréias e hipocalcemia.  
**<mark>Tabela F -</mark>** <mark>Avaliação da certeza da evidência do uso de cinacalcete p</mark> ara o tratamento de pacientes com hiperparatireoidismo secundário à DRC  
||||**Avaliação da C**|**erteza**|||**№ de**|**pacientes**|**Efe**|**ito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|<br>**Evidência**|**Imprecisão**|<br>**Outras**<br>|**Cinacalcete**|**Comparador**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Mortalidade por todas as causas** -->
|10|ECR|não<br>grave|não grave|não grave|grave<sup>a</sup>|nenhum|40/1182<br>(3,4%)|37/971<br>(3,8%)|**RR 0,96**<br>(0,62<br>para<br>1,50)|**2 menos**<br>**por 1.000**<br>(de 14<br>menos<br>para 19<br>mais)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Mortalidade cardiovascular** -->
|2<br>**el séric**|ECR<br>**o de PTH**|não<br>grave|não grave|não grave|grave<sup>b</sup>|nenhum|0/134 (0%)|3/134 (2,2%)|**RR 0,25**<br>(0,03<br>para<br>2,28)|**17 menos**<br>**por 1.000**<br>(de 22<br>menos<br>para 29<br>mais)|⨁⨁⨁◯<br>Moderada|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|6|ECR|grave<sup>c</sup>|grave<sup>d</sup>|não grave|não grave|nenhum|692|480|-|DPM**1,78**<br>**menor**<br>(2,75|⨁⨁◯◯<br>Baixa|IMPORTANTE|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Nível sérico de PTH** -->
||||**Avaliação da Ce**|**rteza**|||**№ de p**|**acientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**<br>|**Outras**<br>**considerações**|**Cinacalcete**|**Comparador**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|||
|**Nível sér**|**ico de Cálcio**|||||||||menor<br>para 0,82<br>menor)|||
|5<br>**Nível sér**|ECR<br>**ico de Fósforo**|grave<sup>c</sup>|grave<sup>e</sup>|não grave|não grave|nenhum|665|453|-|DPM**4,9**<br>**menor**<br>(6,75<br>menor<br>para 3,04<br>menor)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|5<br>**Eventos**|ECR<br>**cardíacos**|grave<sup>c</sup>|grave<sup>f</sup>|não grave|não grave|nenhum|662|451|-|DPM**1,19**<br>**menor**<br>(2,01<br>menor<br>para 0,37<br>menor)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|5|ECR|grave<sup>c</sup>|não grave|não grave|grave<sup>g</sup>|nenhum|11/624|6/621 (1,0%)|**RR 1,62**|**6 mais por**|⨁⨁◯◯|IMPORTANTE|  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Cinacalcete**|**Comparador**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||
||||||||(1,8%)||(0,61<br>para<br>1,43)|**1.000**<br>(de 4<br>menos<br>para 4<br>mais)|Baixa||

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Incidência de fraturas** -->
|2|ECR|grave<sup>c</sup>|não grave|não grave|grave<sup>h</sup>|nenhum|240/2003<br>(12,0%)|260/1962<br>(13,3%)|**RR 0,52**<br>(0,12<br>para<br>2,27)|**64 menos**<br>**por 1.000**<br>(de 117<br>menos<br>para 168<br>mais)|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Produto Cálcio x Fósforo** -->
|4|ECR|grave<sup>c</sup>|grave<sup>e</sup>|não grave|não grave|nenhum|553|341|-|DPM**3**<br>**menor**<br>(5,49<br>menor<br>para 0,5<br>menor)|⨁⨁◯◯<br>Baixa|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
**Paratireoidectomia**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**|**Delineamento**|**Risco**|**Inconsistência**|**Evidência**|**Imprecisão**|**Outras**|**Cinacalcete**|**Comparador**|**Relativo**|**Absoluto**|||
|**estudos**|**do estudo**|**de viés**||**indireta**||**considerações**|||**(IC95%)**|**(IC95%)**|||
|4|ECR|grave<sup>c</sup>|não grave|não grave|não grave|nenhum|1/337<br>(0,3%)|8/314 (2,5%)|**RR 0,21**<br>(0,05<br>para<br>0,83)|**20 menos**<br>**por 1.000**<br>(de 24<br>menos<br>para 4<br>menos)|⨁⨁⨁◯<br>Moderada|IMPORTANTE|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Náusea** -->
|8|ECR|não<br>grave|grave<sup>i</sup>|não grave|não grave|nenhum|230/1129<br>(20,4%)|60/918<br>(6,5%)|**RR 2,39**<br>(1,23<br>para<br>4,66)|**91 mais**<br>**por 1.000**<br>(de 15<br>mais para<br>239 mais)|⨁⨁⨁◯<br>Moderada|<br>NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Vômitos** -->
|8|ECR|não<br>grave|não grave|não grave|grave<sup>g</sup>|nenhum|175/1129<br>(15,5%)|71/918<br>(7,7%)|**RR 1,65**<br>(1,00<br>para<br>2,75)|**50 mais**<br>**por 1.000**<br>(de 0<br>menos<br>para 135<br>mais)|⨁⨁⨁◯<br>Moderada|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
**Diarreia**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Cinacalcete**|**Comparador**|**Relativo**<br>**(IC95%)**|**Absoluto**<br>**(IC95%)**|||
|8<br>**Hipocalc**|ECR<br>**emia**|não<br>grave|não grave|não grave|grave<sup>g</sup>|nenhum|110/1129<br>(9,7%)|75/918<br>(8,2%)|**RR 1,16**<br>(0,87<br>para<br>1,56)|**13 mais**<br>**por 1.000**<br>(de 11<br>menos<br>para 46<br>mais)|⨁⨁⨁◯<br>Moderada|<br>NÃO<br>IMPORTANTE|
|8|ECR|não<br>grave|não grave|não grave|não grave|nenhum|204/1131<br>(18,0%)|18/916<br>(2,0%)|**RR 8,46**<br>(5,48<br>para<br>13,05)|**147 mais**<br>**por 1.000**<br>(de 88<br>mais para<br>237 mais)|⨁⨁⨁⨁<br>Alta|IMPORTANTE|  
IC: Intervalo de Confiança; RR: Risco Relativo); ECR: ensaio clínico randomizado; DPM: Diferença padronizada das médias  
a. Grande variabilidade na estimativa do efeito com IC95% não suficientemente estreito, incluindo a nulidade, sendo impreciso em relação a risco ou benefício;  
- b. Tamanho amostral pequeno, não atingindo o tamanho ótimo da informação para desfechos dicotômicos (300 eventos) e IC95% não suficientemente estreito, no entanto, indicando a favor da intervenção (cinacalcete);  
- c. Os estudos apresentaram problemas relacionados à sequência de randomização, cegamento e viés de atrito;  
- d. Os IC95% dos estudos não são sobreponíveis e presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 98%);  
- e. Os IC95% dos estudos não são sobreponíveis e presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 99%);  
- f. Os IC95% dos estudos não são sobreponíveis e presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 97%);  
- g. Grande variabilidade na estimativa do efeito com IC95% não suficientemente estreito, no entanto, indicando a favor do tratamento padrão;  
- h. Grande variabilidade na estimativa do efeito com IC95% não suficientemente estreito, no entanto, indicando a favor da intervenção (cinacalcete);  
- i. Os IC95% dos estudos não são sobreponíveis e presença de alta heterogeneidade entre os estudos (I<sup>2</sup> = 75%).  
**Tabela para tomada de decisão (** **_Evidence to Decision table- EtD_ ):**  
A **Tabela G** apresenta o processo de tomada de decisão sobre o us <mark>o de cinacalcete para</mark> o tratamento de pacientes com hiperparatireoidismo secundário à DRC baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Tabela G -** Processo de tomada de decisão referente ao uso de <mark>Cinacalcete</mark> para tratamento de pacientes com hiperparatireoidismo secundário à DRC.  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios:**|Grande|Os painelistas consideraram a melhora na qualidade de vida, embora os<br>estudos tenham considerado que os pacientes/serviços tinham acesso às duas<br>classes de medicamentos (intervenção e comparador), diferente do contexto<br>brasileiro. Diferença estatisticamente significativa entre o grupo que recebeu<br>cinacalcete em comparação com o grupo controle para os níveis de PTH<br>(SMD = -1,78; IC95%: -2,75, -0,82; p < 0,00001)<br>Não foram observadas diferenças significativas para mortalidade por todas<br>as causas (RR=0,96; IC95%:0,62-1,50; p=0,87) e mortalidade por causa<br>cardiovascular (RR=0,25; IC95%:0,03-2,28; p=0,22).<br>Diferença estatisticamente significativa entre o grupo que recebeu<br>cinacalcete em comparação com o grupo controle para os níveis séricos de<br>cálcio (SMD= -4,90; IC95%: -6,75, -3,04; p<0,00001), níveis séricos de<br>fósforo (SMD=-1,19; IC95%:-2,01, -0,37; p<0,00001) e produto Ca x P<br>(SMD= -3,00; IC95%: -5,49, -0,50; p<0,00001).<br>Diferença estatisticamente significativa na prevenção de paratireoidectomia,<br>quando comparado ao tratamento padrão (RR=0,21; IC95%: 0,05-0,83;<br>p<0,03).<br>Não houve diferença significativa entre os grupos para redução na incidência<br>de eventos cardíacos (RR=1,62; IC95%: 0,61-1,43; p=0,33) e na prevenção<br>de fraturas (RR=0,52; IC95%: 0,12-2,27; valor p= 0,39).<br>Em relação aos desfechos de segurança da tecnologia, observou-se risco<br>aumentado para eventos gastrointestinais como náuseas (RR=2,39; CI: 1,23–<br>4,66; p<0,01) para o grupo que recebeu cinacalcete. Foi observado também<br>um risco elevado na incidência de hipocalcemia no grupo que recebeu o<br>cinacalcete em comparação com o grupo controle (RR=8,46; CI: 5,48–<br>13,05; p<0,00001).|
|**Riscos:**|Pequeno|A frequência dos eventos adversos é grande: 40% de náusea e em torno de<br>30% de hipocalcemia. Entretanto, náusea e hipocalcemia são dose<br>dependente e a dose é maior quando o medicamento é introduzido<br>tardiamente. A ampliação do uso implicará em uso mais precoce.<br>Embora o risco de eventos adversos exista, são de pequena gravidade e não|  
|**Item da EtD**|**Julgamento**<br>**painelistas**|**dos**|**Justificativa**|
|---|---|---|---|
||||são impeditivos da prescrição.|
|**Balanço dos riscos e**<br>**benefícios:**|Favorece<br>intervenção|a|Embora não haja benefício na mortalidade, o benefício no controle dos<br>parâmetros laboratoriais e na diminuição do RR das PTxs, o julgamento é<br>favorável. Os painelistas consideraram importante esclarecer os critérios de<br>inclusão e exclusão, considerando os pacientes com hipocalcemia. Destacam<br>que o uso do cinacalcete pode não ser isolado e sim em associação aos<br>análogos da vitamina D (calcitriol ou paricalcitol). Considerar os efeitos<br>sinérgicos.|
|**Certeza da evidência:**|Moderada||Consideraram que os estudos tenham considerado que os pacientes/serviços<br>tinham acesso às duas classes de medicamentos (intervenção e comparador),<br>diferente do contexto brasileiro.|
|**Custos:**|Economia<br>moderada||Destacam que o uso do cinacalcete pode não ser isolado e sim em associação<br>aos análogos da vitamina D (calcitriol ou paricalcitol). Considerar os efeitos<br>sinérgicos. Os painelistas consideraram que, apesar do custo do cinacalcete,<br>a diminuição da necessidade de paratireoidectomias aliada à introdução<br>precoce do medicamento, implicando em doses mais baixas, acarretam<br>economia moderada de recursos. O impacto orçamentário incremental com<br>a ampliação do uso do cinacalcete no SUS estará entre R$ -1.640.864,62 e<br>R$ 12.754.246,38 no primeiro ano, considerando os cenários principal<br>baseado nos dados do DAF e do SABEIS e o cenário epidemiológico<br>baseado nos dados da SBN. Já ao final de 5 anos após a ampliação do uso,<br>estimou-se um impacto incremental entre R$ -10.740.743,86 e R$ 94.812.141,73; considerando os mesmos cenários.|
|**Custo-efetividade:**|Favorece<br>intervenção|a|Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico. Ademais, em análise econômica detalhada no Relatório de<br>Recomendação nº 704/2022 observou-se que a custo-efetividade do<br>cinacalcete em comparação ao paricalcitol foi em uma economia pontual de<br>R$ 1.018,03 ao ano.|
|**Aceitabilidade:**|Sim||Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|**Viabilidade**<br>**de**<br>**implementação:**|Sim||Nenhuma justificativa foi apontada. Julgamento baseado em consenso<br>clínico.|
|**Outras considerações:**|-||Não foram reportadas outras considerações.|  
PTX: paratireoidectomia; PTH: paratormônio; RR: risco relativo Fonte: Autoria própria.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 10: Devemos utilizar a desferroxamina para o diagnóstico de pacientes com intoxicação por alumínio em portadores de DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar a desferroxamina para o diagnóstico de intoxicação por alumínio em pacientes portadores de DRC (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com <mark>DRC estágios 2 a 5D</mark>  
**Intervenção:** Dosagem de desferroxamina  
**Comparador:** Dosagem de alumínio apenas  
**Desfechos:** calcemia, fosfatemia e PTH dentro da normalidade, fraturas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca:** -->
Para essa questão foi realizada uma busca sistemática da literatura nas bases de dados Pubmed, Embase, Scopus, Cochrane, PMC, Epistemonikos, BVS e NICE e foram encontrados 646 registros. Destes, foram selecionados 35 estudos, sendo 34 publicados entre 1984 e 2014 e somente um artigo publicado em 2018, ou seja, um ano após o KDIGO (2017), que já possui uma recomendação específica para a questão avaliada.  Esse único estudo de coorte observacional retrospectivo testou o efeito do corte no valor de 6 ng/mL (limite superior) do alumínio sérico em todas as causas e mortalidade cardiovascular em pacientes em diálise. No entanto, os próprios autores apontam várias limitações do estudo que comprometem a qualidade da evidência, principalmente pela incapacidade de generalização. Como conclusão, ressaltou uma associação independente de um alto nível de alumínio (≥ 6 ng/mL) e todas as causas de mortalidade em pacientes em hemodiálise crônica. Além disso, sugeriram um efeito dose-dependente dos níveis séricos de alumínio sobre a mortalidade e ressaltaram que os níveis séricos de alumínio devem ser mantidos o mais baixo possível em pacientes em CHD. Como que não há literatura que modifique a recomendação que consta no _guideline_ internacional KDIGO 2017 e, a SBN publicou em out/dez de 2021 uma recomendação específica nas Diretrizes Brasileiras para o tratamento e avaliação do DMO da DRC, optou-se por considerar os resultados do documento mais atual.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências:** -->
Existem vários protocolos para a realização do diagnóstico, porém o que parece ser mais seguro e efetivo é a utilização de 5 mg/kg de desferroxamina (DFO)<sup>37</sup> <mark>. O</mark> teste é feito com a administração de DFO na dose de 5 mg/kg de peso, uma hora antes do término ou após a sessão de hemodiálise. As amostras para dosagem de alumínio são coletadas antes da sessão na qual será feita a infusão (basal) e antes da próxima sessão de hemodiálise (estimulada). Em um estudo que avaliou 77 pacientes em TRS, um nível sérico de PTH abaixo de 150 pg/mL associado a um aumento do alumínio sérico maior que 50 mcg/L após a infusão da DFO demonstrou sensibilidade de 87% e especificidade de 95% para detecção de doença óssea por deposição de alumínio em biópsia óssea (padrão-ouro para o diagn <mark>óstico)</mark><sup>38</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação:** -->
- De acordo com os painelistas, o uso da DFO como teste diagnóstico para intoxicação óssea por alumínio, pode ser feito no caso de suspeita clínica de intoxicação, exposição aguda ou crônica a fontes de alumínio e antes da realização da paratireoidectomia.  
- O teste consiste em realizar duas coletas de sangue em jejum, para determinação dos níveis séricos de alumínio, sendo a 1ª e a 2ª coletas realizadas antes da 1ª e das 2ª sessões de hemodiálise da semana, respectivamente. Após o término da 1ª sessão de hemodiálise, infundir por via intravenosa a DFO (5 mg/kg, diluídos em 100 mL de solução glicosada a 5% ou fisiológica a 0,9%, durante 60 minutos).  
- O resultado do teste é considerado "positivo" quando a diferença (delta) da concentração sérica de alumínio entre as duas dosagens for maior que 50 µg/L.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **QUESTÃO 11: Devemos utilizar a desferroxamina para o tratamento de pacientes com intoxicação por alumínio em portadores de DRC?** -->
**<u>Recomendação:</u>** Recomendamos utilizar a desferroxamina para o tratamento da intoxicação por alumínio em pacientes portadores de DRC. (recomendação não graduada)  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com DRC <mark>estágios 2 a 5D</mark>  
**Intervenção:** Desferroxamina  
**Comparador:** Seguimento clínico sem intervenção ou placebo;  
**Desfechos:** calcemia, fosfatemia e PTH dentro da normalidade, fraturas, mortalidade por todas as causas e mortalidade cardiovascular.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Métodos e resultados da busca:** -->
Para essa questão, não foi realizada busca sistemática da literatura. Essa recomendação já constava no PCDT anterior e foi mantida.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Resumo das evidências:** -->
A dose de DFO recomendada para o tratamento da intoxicação óssea por alumínio é de 5 mg/kg, uma vez por semana, ao término da 1ª sessão de hemodiálise da semana, por um período variável de 3 meses a 1 ano, dose cuja efetividade é semelhante à de doses mais elevadas, com a vantagem de ser associada a menos efeitos colaterais<sup>37-40</sup> .

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **Considerações gerais e para implementação:** -->
Os painelistas recomendaram que a dose de DFO para o tratamento da intoxicação óssea por alumínio seja de 5 mg/kg, uma vez por semana, ao término da 1ª sessão de hemodiálise da semana, por um período variável de 3 meses a 1 ano.  
- Nos pacientes submetidos à diálise peritoneal, a administração de DFO pode ser feita por via intravenosa ou intraperitoneal, na mesma dose e frequência preconizadas para os pacientes em hemodiálise<sup>37-41</sup> . A infusão intravenosa deve ser feita lentamente, durante 60 minutos, fora do período de diálise (cavidade abdominal vazia). A diálise só deve ser reiniciada após um mínimo de 5 horas após o término da administração do medicamento.

---

<!-- METADADOS: doenca: Distúrbio Mineral Ósseo na Doença Renal Crônica | secao: **REFERÊNCIAS** -->
<mark>1. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia.  Diretrizes metodológicas: ferramentas para adaptação de Diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014. 2. GRADEpro Guideline Development Tool [Software]. McMaster University, 2020 (developed by Evidence Prime, Inc.). Available from: gradepro.org.</mark>  
3. Shea B J, Reeves B C, Wells G, Thuku M, Hamel C, Moran J et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both BMJ 2017; 358 :j4008 doi:10.1136/bmj.j4008  
4. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, Cates CJ, Cheng H-Y, Corbett MS, Eldridge SM, Hernán MA, Hopewell S, Hróbjartsson A, Junqueira DR, Jüni P, Kirkham JJ, Lasserson T, Li T, McAleenan A, Reeves BC, Shepperd S, Shrier I, Stewart LA, Tilling K, White IR, Whiting PF, Higgins JPT. RoB 2: a revised tool for assessing risk of bias in randomised trials. BMJ 2019; 366: l4898.  
<mark>5. Review Manager (RevMan) [Computer program]. Version 5.4, The Cochrane Collaboration, 2020</mark>  
<mark>6. Kidney Disease: Improving Global Outcomes (KDIGO) CKD-MBD Update Work Group (2017). KDIGO 2017 Clinical</mark>  
<mark>Practice Guideline Update for the Diagnosis, Evaluation, Prevention, and Treatment of Chronic Kidney Disease-Mineral and Bone Disorder (CKD-MBD). Kidney international supplements, 7(1), 1–59</mark>  
<mark>7. Hollis B.W. Circulating 25-hydroxyvitamin D levels indicative of vitamin D sufficiency: implications for establishing a new effective dietary intake recommendation for vitamin D. J Nutr. 2005; 135: 317-322</mark>  
<mark>8. Hollis B.W. Assessment of vitamin D status and definition of a normal circulating range of 25-hydroxyvitamin D. Curr Opin Endocrinol Diabetes Obes. 2008; 15: 489-494</mark>  
<mark>9. Heaney R.P. Optimal vitamin D status. J Bone Miner Res. 2009; 24: 755</mark>  
<mark>10. Steingrimsdottir Le et al. Relationship between serum parathyroid hormone levels, vitamin D sufficiency, and calcium intake. JAMA. 2005; 294: 2336-2341</mark>  
<mark>11. Adami S et al. Relationship between serum parathyroid hormone, vitamin D sufficiency, age, and calcium intake. Bone. 2008; 42: 267-270</mark>  
<mark>12. Giovannucci E. Vitamin D status and cancer incidence and mortality. Adv Exp Med Biol. 2008; 624: 31-42</mark>  
<mark>13. Simon J.A. Review: vitamin D supplementation decreases all-cause mortality in adults and older people. Evid Based Med. 2008; 13: 47</mark>  
<mark>14. Wolf M et al. Vitamin D levels and early mortality among incident hemodialysis patients. Kidney Int. 2007; 72: 1004-</mark>  
<mark>1013</mark>  
<mark>15. Davies K.M.et al. Vitamin D and calcium supplementation reduces cancer risk: results of a randomized trial. Am J Clin Nutr. 2007; 85: 1586-159</mark>  
<mark>16. Gonzales E.A et al. Vitamin D insufficiency and deficiency in chronic kidney disease. A single center observational study. Am J Nephrol. 2004; 24: 503-510</mark>  
<mark>17. LaClair R.E et al. Prevalence of calcidiol deficiency in CKD: a cross-sectional study across latitudes in the United States. Am J Kidney Dis. 2005; 45: 1026-1033</mark>  
<mark>18. B</mark> rasil. Portaria Conjunta SAS/SCTIE nº 801, de 25 de abril de 2017– Aprova o Protocolo Clínico e Diretrizes Terapêuticas (PCDT).  
<mark>19. Regidor DL et al. Serum alkaline phosphatase predicts mortality among maintenance hemodialysis patients. J Am Soc Nephrol. 2008; 19: 2193-2203</mark>  
<mark>20. Blayney MJ et al. High alkaline phosphatase levels in hemodialysis patients are associated with higher risk of hospitalization and death. Kidney Int. 2008; 74 (63): 655</mark>  
<mark>21. Llach F, Yudd M. The importance of hyperphosphataemia in the severity of hyperparathyroidism and its treatment in patients with chronic renal failure. Nephrol Dial Transplant. 1998;13 Suppl 3:57-61.</mark>  
<mark>22. Loghman-Adham M. Phosphate binders for control of phosphate retention in chronic renal failure. Pediatr Nephrol. 1999;13(8):701-8</mark>  
<mark>23. Slatopolsky E, Weerts C, Lopez-Hilker S, Norwood K, Zink M, Windus D, et al. Calcium carbonate as a phosphate binder in patients with chronic renal failure undergoing dialysis. N Engl J Med. 1986;315(3):157-61.</mark>  
<mark>24. Slatopolsky E, Weerts C, Norwood K, Giles K, Fryer P, Finch J, et al. Long-term effects of calcium carbonate and 2.5 mEq/liter calcium dialysate on mineral metabolism. Kidney Int. 1989;36(5):897-903.</mark>  
<mark>25. Navaneethan SD, Palmer SC, Vecchio M, Craig JC, Elder GJ, Strippoli GF. Phosphate binders for preventing and treating bone disease in chronic kidney disease patients. Cochrane Database Syst Rev. 2011;(2):CD006023. 26. Phannajit J, Wonghakaeo N, Takkavatakarn K, Asawavichienjinda T, Praditpornsilpa K, Eiam-Ong S, Susantitaphong P. The impact of phosphate lowering agents on clinical and laboratory outcomes in chronic kidney disease patients: a systematic review and meta-analysis of randomized controlled trials. J Nephrol. 2021 Jun 1. doi: 10.1007/s40620-021-01065-3. Epub ahead of print. PMID: 34061337.</mark>  
<mark>27. Cruz DN, Perazella MA. Biochemical aberrations in a dialysis patient following parathyroidectomy. Am J Kidney Dis. 1997;29(5):759-62.</mark>  
<mark>28. Rocha LA, Neves MC, Montenegro FLM. Paratireoidectomia na doença renal crônica J Bras Nefrol. 2021;43(4 Suppl 1):669-73.</mark>  
<mark>29. Clair F, Leenhardt L, Bourdeau A, Zingraff J, Robert D, Dubost C, et al. Effect of calcitriol in the control of plasma calcium after parathyroidectomy. A placebo-controlled, double-blind study in chronic hemodialysis patients. Nephron. 1987;46(1):18-22.</mark>  
<mark>30. Lund RJ, Andress DL, Amdahl M, Williams LA, Heaney RP. Differential effects of paricalcitol and calcitriol on intestinal calcium absorption in hemodialysis patients. Am J Nephrol. 2010;31(2):165-70.</mark>  
<mark>31. Martin KJ, González EA, Gellens M, Hamm LL, Abboud H, Lindberg J. 19-Nor-1-alpha-25-dihydroxyvitamin D2 (Paricalcitol) safely and effectively reduces the levels of intact parathyroid hormone in patients on hemodialysis. J Am Soc Nephrol. 1998;9(8):1427-32.</mark>  
<mark>32. Cheng J, Zhang W, Zhang X, Li X, Chen J. Efficacy and safety of paricalcitol therapy for chronic kidney disease: a metaanalysis. Clin J Am Soc Nephrol. 2012;7(3):391-400.</mark>  
<mark>33. Han T, Rong G, Quan D, Shu Y, Liang Z, She N, et al. Meta-analysis: the efficacy and safety of paricalcitol for the treatment of secondary hyperparathyroidism and proteinuria in chronic kidney disease. BioMed Res Int. 2</mark> 013; 2013: 320560.  
<mark>34. Geng X, Shi E, Wang S, Song Y. A comparative analysis of the efficacy and safety of paricalcitol versus other vitamin D receptor activators in patients undergoing hemodialysis: A systematic review and meta-analysis of 15 randomized controlled trials. PLOS ONE 2020;15(5):e0233705.</mark>  
<mark>35. Sociedade Brasileira de Nefrologia (SBN) [homepage na internet]. Censo 2020 [acesso em 05 jul 2021]. Disponível em: http://www.censo-sbn.org.br/censosAnteriores</mark>  
<mark>36. Palmer SC, Mavridis D, Johnson DW, Tonelli M, Ruospo M, Strippoli GFM. Comparative Effectiveness of Calcimimetic Agents for Secondary Hyperparathyroidism in Adults: A Systematic Review and Network Meta-analysis. Am J Kidney Dis. 2020 Sep;76(3):321-330. DOI: 10.1053/j.ajkd.2020.02.439. Epub 2020 May 28. PMID: 32475604.</mark>  
<mark>37. D'Haese PC, Couttenye MM, Goodman WG, Lemoniatou E, Digenis P, Sotornik I, et al. Use of the low-dose desferrioxamine test to diagnose and differentiate between patients with aluminium-related bone disease, increased risk for aluminium toxicity, or aluminium overload. Nephrol Dial Transplant. 1995;10(10):1874-84</mark>  
<mark>38. Barata J, D'Haese P, Pires C, Lamberts L, Simões J, De Broe M. Low-dose (5 mg/kg) desferrioxamine treatment in acutely aluminium-intoxicated haemodialysis patients using two drug administration schedules. Nephrol Dial Transplant. 1996;11(1):125-32.</mark>  
<mark>39. Canteros A, Díaz-Corte C, Fernández-Martín JL, Gago E, Fernández-Merayo C, Cannata J. Ultrafiltrable aluminium after very low doses of desferrioxamine. Nephrol Dial Transplant. 1998 Jun 1;13(6):1538-42. https://doi.org/10.1093/ndt/13.6.1538 27.</mark>  
<mark>40. Kan W-C, Chien C-C, Wu C-C, Su S-B, Hwang J-C, Wang H-Y. Comparison of low-dose deferoxamine versus standarddose deferoxamine for treatment of aluminium overload among haemodialysis patients. Nephrol Dial Transplant. 2010 May;25(5):1604-8. https://doi.org/10.1093/ndt/gfp</mark>  
<mark>41. Diagnosis and treatment of aluminum overload in endstage renal failure patients. Consensus Conference. Paris, France, 27 June 1992. Nephrol Dial Transplant. 1993;8 Suppl 1:1-5</mark>

---

