<!-- METADADOS: doenca: Doença de Wilson | secao: Geral -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 15, DE 01 DE NOVEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Wilson.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a doença de Wilson no Brasil e as diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 847 e o Relatório de Recomendação nº 850 de setembro de 2023 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença de Wilson.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da doença de Wilson, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da doença de Wilson.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 9, de 27 de março de 2018, publicada no Diário Oficial da União nº 67, de 9 de abril de 2018, seção 1, pág. 100.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
CARLOS AUGUSTO GRABOIS GADELHA  
ADRIANO MASSUDA  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DA DOENÇA DE WILSON

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **1. INTRODUÇÃO** -->
A doença de Wilson é um distúrbio autossômico recessivo do metabolismo do cobre<sup>1,2</sup> . A prevalência global foi estimada em uma monografia de 1984, prevendo-se 1 caso a cada 30.000 pessoas<sup>2</sup> . Mais recentemente, uma meta-análise publicada em 2019 estimou a prevalência da doença em cerca de 13,9 casos a cada 10.000 pessoas (IC 95%: 12,9 – 14,9), ou 1 a cada 7.194 indivíduos<sup>3</sup> .  
Segundo dados do DATASUS, no Brasil, no período de 2000 a 2019, 396 óbitos por doença de Wilson (CID E83.0) foram registrados no Sistema de Informações sobre Mortalidade (SIM), dos quais 63,1% eram pessoas do sexo masculino, com uma média de idade de 29,8 anos (desvio-padrão 19,0 anos), sem diferenças no perfil para todas as regiões brasileiras (p>0,05). O número de óbitos notificados por ano variou muito no período de 2000 a 2019, sendo o menor em 2000 (8 óbitos) e o maior registrado em 2019 (42 óbitos), com taxa de mortalidade chegando a 2,0/10 milhões de habitantes nesse ano. Entre 2000 e 2020, foram registradas 519 hospitalizações no Sistema Único de Saúde com diagnóstico principal de doença de Wilson. Entre 2016 e 2020, o número de hospitalizações variou de 27 a 35, com média de 31,2± 3,3 internações por ano. O tempo médio de permanência hospitalar foi 9,9 ± 17,4 dias, variando de 0 a 187 dias, com mediana de 3 dias (IIQ25-75% 2-9) entre 2000 e 2020. Contudo, esses dados precisam ser interpretados com cautela porque não representam necessariamente a prevalência da doença na população brasileira.  
O cobre é classificado como um oligoelemento essencial que atua no processo de respiração mitocondrial e, como cofator metaloenzimático, está envolvido na oxidação do ferro e no metabolismo da dopamina<sup>4</sup> . O gene _ATP7B_ codifica uma enzima ATPase transportadora de cobre - altamente expressa no fígado<sup>5</sup> – para a síntese da ceruloplasmina funcional. Nos hepatócitos, além de incorporar o cobre à bile para excreção, a proteína ATP7B é responsável por transportar o cobre para o compartimento transgolgiano, onde o mesmo se liga a ceruloplasmina, que, ao adquirir seu complemento de cobre, assume um estado enovelado e é liberada na circulação<sup>6,7</sup> . No sangue, a ceruloplasmina pode ser encontrada ligada a seis átomos de cobre (holoceruloplasmina) ou sem o cobre ligado (apoceruloplasmina)<sup>8</sup> .  
O distúrbio da doença de Wilson é causado por variantes patogênicas bialélicas no gene _ATP7B_ , localizado no cromossomo 13q14<sup>5</sup> . Até o momento, mais de 1.000 variantes já foram descritas e as mutações mais comuns são do tipo _missense/nonsense_<sup>9</sup> . Nesses casos, o cobre não é excretado de forma eficiente pela bile e passa a se acumular primeiramente no fígado e, posteriormente, no cérebro, rins e olhos<sup>10</sup> . Ainda, os níveis de ceruloplasmina estão diminuídos, ocasionando diminuição no nível total de cobre sérico e aumento na concentração de cobre sérico livre<sup>7,10</sup> . Nesse caso, a toxicidade do cobre seria causada pelo estresse oxidativo e pela criação de radicais livres<sup>7</sup> .  
As manifestações clínicas mais comuns são resultantes do acometimento hepático e do sistema nervoso central. A doença de Wilson acomete preferencialmente, mas não exclusivamente,  pacientes na faixa etária de 3 a 55 anos<sup>11,12</sup> . Apesar do acúmulo de cobre se iniciar logo após o nascimento, as manifestações da doença se iniciam a partir dos 3 anos de idade<sup>11</sup> . Uma ampla gama de alterações hepáticas pode ser encontrada em pacientes com doença de Wilson, principalmente, icterícia recorrente, hepatites, insuficiência fulminante ou doença crônica. A doença hepática clinicamente evidente pode preceder as manifestações neurológicas, que incluem distúrbios do movimento de linha extra-piramidal, e pode ser acompanhada de manifestações psiquiátricas. Por vezes, o quadro psiquiátrico pode ser mais exuberante, incluindo transtornos depressivos, neuróticos, de personalidade e até mesmo de deterioração intelectual<sup>13,14</sup> .  
O diagnóstico pode ser estabelecido, na maioria dos casos, por meio dos achados clínicos e laboratoriais. Para isso, podem ser realizados exames físicos, oftalmológico para pesquisa dos anéis corneanos de Kayser-Fleischer e laboratorial, incluindo dosagem sérica de ceruloplasmina e cuprúria de 24 horas<sup>1,11–13,15</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E83.0 Distúrbios do metabolismo do cobre

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **3. DIAGNÓSTICO** -->
O diagnóstico da doença de Wilson é realizado por meio da avaliação de achados clínicos e laboratoriais e, até hoje, não há um exame padrão-ouro para diagnóstico definitivo da doença. De forma geral, os sintomas da doença tendem a surgir entre os 3 e 55 anos de idade<sup>12</sup> . Na maioria dos casos, o diagnóstico pode ser estabelecido através da combinação de achados, por meio da dosagem dos níveis de ceruloplasmina sérica, o reconhecimento de anéis de Kayser-Fleischer na córnea e a dosagem de concentração de cobre na urina em 24 horas<sup>11,16</sup> . Entretanto, devido à sua variabilidade, a ausência de sinais comuns à doença não exclui o seu diagnóstico.  
As manifestações clínicas da doença de Wilson dependem do local de deposição de cobre no organismo. Por ser o primeiro órgão acometido pelo acúmulo de cobre, manifestações hepáticas ocorrem predominantemente na infância, sendo a cirrose a principal delas<sup>11,12</sup> .  
A forma neurológica da doença tende a se apresentar mais tardiamente. Na maior parte dos casos, pacientes com manifestações do sistema nervoso central já desenvolveram a forma hepática da doença, mesmo que assintomática. Nessa forma, os sintomas extrapiramidais são mais comuns, mas não exclusivos<sup>11</sup> . Um estudo retrospectivo realizado no Hospital das Clínicas da Universidade de São Paulo entre os anos de 1963 e 2004 revelou que entre os achados mais comuns da doença de Wilson estão: disartria (91%), distúrbios da marcha (75%), _risus sardonicus_ (72%), distonia (69%), rigidez (66%), tremores (60%) e disfagia (50%)<sup>14</sup> . No mesmo estudo, manifestações neurológicas foram mais frequentemente observadas em pacientes com idade média próxima aos 20 anos (19,6 ± 6,5 anos), variando entre 7 e 37 anos de idade<sup>14</sup> .  
Os anéis de Kayser-Fleischer - manifestação ocular característica da doença – podem ser visualizados a olho nu, especialmente em pacientes com íris pouco pigmentada. Para avaliação, a utilização da biomicroscopia com lâmpada de fenda é recomendada devido maior sensibilidade para detecção precoce do cobre depositado na membrana de Descemet da córnea. Os anéis de Kayser-Fleischer apresentam-se como uma faixa de cor marrom-dourado próxima ao limbo ocular e estão presentes na quase totalidade dos casos de doença de Wilson com acometimento neurológico. Entretanto, é importante lembrar que eles não são exclusivos da doença de Wilson, pois ocorrem também em outras condições hepatobiliares ou na presença de corpo estranho intraocular que contenha cobre<sup>17</sup> . Manifestações clínicas da doença de Wilson são apresentadas no Quadro 1.  
**Quadro 1** – Manifestações clínicas da doença de Wilson  
|**Manifestação**|**Descrição**|
|---|---|
||Hepatomegalia assintomática, transaminases persistentemente elevadas, hepatite|
|**Hepática**|aguda, hepatite crônica, cirrose (compensada e descompensada), insuficiência<br>hepática aguda, esteatose hepática, esplenomegalia isolada, colelitíase|
|**Neurológica**|Distúrbios<br>do<br>movimento<br>(distonia,<br>tremores,<br>parkinsonismo),<br>paralisia<br>pseudobulbar (incluindo disartria), convulsões, sialorreia|
|**Psiquiátrica**|Alterações comportamentais, depressão, ansiedade, psicose|
|**Osteomuscular**|Artralgia, artrite, fraturas, osteoporose, osteomalácia, condromalácia|
|**Hematológica**|Anemia hemolítica, trombocitopenia, pancitopenia, coagulopatia|  
|**Manifestação**|**Descrição**|
|---|---|
|**Oftalmológica**|Anéis de Kayser-Fleischer, catarata em girassol|
|**Renal**|Cálculos renais, acidose tubular renal, síndrome de Fanconi|  
Fonte: Adaptado de Nagral et al., 2019<sup>11</sup>  
A concentração sérica de ceruloplasmina está geralmente reduzida em pacientes com doença de Wilson<sup>18</sup> e, embora níveis séricos muito baixos possam ser um forte indicativo da doença, esse único achado não pode ser interpretado como um diagnóstico definitivo, já que os níveis de ceruloplasmina também estão diminuídos em pacientes com cirrose de outras etiologias, bem como na síndrome de má absorção entérica ou doença renal<sup>11,15,16</sup> .  
O exame de excreção de cobre na urina em 24 horas auxilia o diagnóstico, mas deve ser cuidadosamente interpretado em função da probabilidade de resultados falso-negativos em pacientes assintomáticos<sup>11</sup> . É importante realizar uma avaliação neurológica detalhada e, quando possível, complementá-la com tomografia computadorizada ou ressonância magnética de encéfalo, antes de iniciar o tratamento de pacientes com doença de Wilson.  A ressonância magnética pode revelar depósito de cobre, caracterizada com hipersinal em T2 nos gânglios da base<sup>15</sup> . Apesar de menos frequente, o sinal da “face do panda gigante” é um achado característico no exame de ressonância magnética cerebral em T2<sup>11,15</sup> e consiste na preservação da intensidade de sinal nos núcleos vermelhos e porção lateral da _pars reticulata_ da substância negra, além de alto sinal no tegmento e hipointensidade do colículo superior<sup>19</sup> , como apresentado na **Figura 1** . Já o sinal da “face do panda em miniatura” resulta da hipointensidade do fascículo longitudinal medial e trato tegmental central em contraste ao sinal elevado do aqueduto no IV ventrículo, junto do véu medular superior<sup>20</sup> .  
**Figura 1** – “Face do panda gigante” (seta) no mesencéfalo por imagem de ressonância magnética axial ponderada em T2  
Fonte: Jacobs, 2003<sup>20</sup>  
A biópsia hepática, embora não seja realizada rotineiramente na suspeita de doença de Wilson, pode auxiliar no diagnóstico. Os achados histológicos não são específicos. Nos estágios iniciais, pode-se encontrar esteatose leve, simulando quadro de doença hepática gordurosa, além de inflamação lobular ou periportal. Também é possível que se apresente com padrão de inflamação mononuclear parenquimatosa e hepatite de interface, simulando padrão de hepatite autoimune. A fibrose pode  
progredir formando pontes porta-porta e culminar em cirrose nodular. Pode haver balonização, corpúsculos de Mallory e Denk, células oncocíticas e, nos casos de hepatite aguda fulminante, há necrose confluente multilobular e numerosos hepatócitos apoptóticos. A presença de glicogênio nuclear com esteatose leve pode sugerir doença de Wilson<sup>12,16</sup> . A análise de orceína e rodanina em tecido hepático pode ser utilizada para identificação de cobre no fígado<sup>11</sup> , mas como a quantidade de cobre pode variar de célula para célula, os resultados de biópsia hepática são normalmente utilizados como evidência de suporte para confirmação diagnóstica<sup>11,16</sup> . Outros achados também podem ser considerados no processo diagnóstico, como a análise de variante patogênica e histórico familiar de morte pela doença.  
De forma geral, sistemas de pontuação são utilizados para avaliação da probabilidade diagnóstica, mas requerem validação prospectiva e revisão periódica<sup>12</sup> . O escore de Leipzig, elaborado em 2001 com base em opinião de especialistas e evidências disponíveis, é um sistema de pontuação que reúne achados clínicos e bioquímicos para dar suporte ao diagnóstico de pacientes com suspeita de doença de Wilson. Apesar do escore ter sido validado para adultos e crianças, alguns critérios utilizados na versão original da ferramenta sofreram críticas em relação a sua ambiguidade e difícil interpretação e, posteriormente, exceções aos critérios de Leipzig para diagnóstico de doença de Wilson foram identificados<sup>12</sup> . Desde então, modificações do escore de Leipzig foram propostas – como a publicada em 2019 por Nagral e colaboradores<sup>11</sup> , que passa a considerar pontos adicionais para pacientes com histórico familiar de doença de Wilson.  
O escore e parâmetros utilizados para o diagnóstico da doença de Wilson segundo a escala de Leipzig são apresentados no **Quadro 2** . Nesse caso, o escore total deve ser calculado através da soma da pontuação atribuída aos graus das manifestações clínicas listadas.  
**Quadro 2** – Escore de Leipzig para diagnóstico da Doença de Wilson  
|**SINTOMAS E SINAIS**|**PONTOS**|
|---|---|
|**Anel de Kayser-Fleisher (biomicroscopia por lâmpada de fenda)**||
|Presente|2|
|Ausente|0|
|**Sintomas neuropsiquiátricos sugestivos (ou ressonância magnética cerebral típica)**<br>Presente|2|
|Ausente|0|
|**Anemia hemolítica - teste de Coombs negativo**||
|Presente|1|
|Ausente|0|
|**EXAMES LABORATORIAIS**||
|**Cobre urinário (na ausência de hepatite aguda)**<br>Normal (3-40 mcg/24h)|0|
|1-2x o LSN|1|
|Mais de 2x LSN*|2|
|Normal, mas mais de 5x LSN após estímulo com 2 x 0,5 g de D-penicilamina|2|
|**Cobre hepático quantitativo**<br>Normal (20-50 mcg/g)<br>Até 5x LSN*|-1<br>1|
|Mais de 5x LSN*|2|
|**Rodanina positiva nos hepatócitos (quando o cobre quantitativo não estiver disponível)**<br>Ausente||  
|**SINTOMAS E SINAIS**||**PONTOS**|
|---|---|---|
|Presente||0<br>1|
|**Ceruloplasmina sérica (por nefelometr**|**ia)**||
|Normal (acima de 20 mg/dL)||0|
|10-20 mg/dL||1|
|Abaixo de 10 mg/dL||2|
|**ANÁLISE DE VARIANTES PATOGÊ**|**NICAS**||
|Detectada em ambos cromossomos||4|
|Detectada em um cromossomo||1|
|Não detectada||0|
|**Interpretação do Escore total**|||
|**≥ 4**|**3**|**≤ 2**|
|Diagnóstico para doença de Wilson<br>altamente provável|Possível diagnóstico para doença de<br>Wilson - mais exames são necessários|Diagnóstico improvável de doença de<br>Wilson|  
*LSN - limite superior da normalidade  
Fonte: Adaptado de Ferenci, 2003<sup>21</sup> e Ferenci, 2012<sup>15</sup>  
O diagnóstico genético por análise molecular do gene _ATP7B_ (cromossomo 13q14.3) é um recurso importante para confirmação diagnóstica em qualquer paciente, além de facilitar a triagem posterior de familiares. Uma das principais dificuldades relacionadas ao teste genético é a quantidade de variantes patogênicas possíveis. Segundo o _The Human Gene Mutation Database_ , mais de 1.000 variantes já foram identificadas<sup>9</sup> . Variantes patogênicas predominantes já foram relatadas para algumas populações, como na Europa Oriental (H1069Q), Sardenha (c-441 427del15) e Japão (229insC, Arg778Leu)<sup>11</sup> . No Brasil, as mutações mais frequentemente detectadas em uma série de pacientes procedentes de diferentes regiões e matriculados no Hospital das Clínicas da Faculdade de Medina da USP foram A1135Qfs (c.3402delC, 30,8%) e L708P (c.2123T>C, 14,1%)<sup>22</sup> . Entretanto, quando se estudou focalmente pacientes procedentes do Paraná, as mutações c.3207C:A e H1069Q se revelam expressivas também<sup>23,24</sup> . Diante da elevada heterogeneidade de mutações encontradas entre os portadores de doença de Wilson brasileiros, é pouco produtivo realizar o sequenciamento de um éxon, ou a busca de uma mutação apenas, a busca específica de uma mutação poderá ser útil somente para rastreio familiar, quando já se conhece o genótipo do caso-índice. Na medida em que técnicas de sequenciamento de nova geração possam ser incorporadas à prática clínica, a genotipagem ATP7B tem potencial de facilitar o diagnóstico preciso e precoce de novos casos de doença de Wilson.  
Deve-se iniciar o processo de rastreamento familiar assim que o diagnóstico do paciente seja estabelecido. A triagem deve incluir todos os parentes de primeiro grau. Esse processo permite a detecção precoce da doença em fase pré-sintomática e identifica familiares saudáveis ou portadores heterozigotos como potenciais doadores, caso um transplante hepático eventualmente seja necessário<sup>11,16,25</sup> . A avaliação deve ser baseada em: histórico familiar, exame físico, testes bioquímicos de função hepática, hemograma completo, concentração sérica de ceruloplasmina, cuprúria de 24h, pesquisa de anéis de KayserFleischer, diagnóstico genético e outros exames, conforme necessário<sup>16</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nesse Protocolo pacientes em qualquer idade que apresentem diagnóstico estabelecido por quatro ou mais pontos na escala de Leipzig modificada.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos do tratamento com os medicamentos preconizados nesse Protocolo, os pacientes que apresentarem contraindicação, intolerância ou hipersensibilidade a um ou mais componentes da formulação.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6. TRATAMENTO** -->
As estratégias terapêuticas incluem, principalmente, alterações na dieta, tratamento medicamentoso e transplante hepático. No primeiro ano de tratamento, ou até que se obtenha redução do cobre excedente, aconselha-se evitar os alimentos mais ricos em cobre, particularmente feijão, chocolate, miúdos e vísceras, nozes, castanhas e frutos do mar<sup>15,26</sup> . O tratamento medicamentoso adequado deve ser iniciado precocemente para evitar ou minimizar os eventos nocivos da impregnação do cobre nos diversos tecidos e deve ser mantido até que o paciente deixe de se beneficiar com ele. As opções terapêuticas envolvem a administração de quelantes, como a penicilamina e trientina, e sais de zinco para redução da absorção do cobre<sup>11,12,15,16</sup> . Sugerese que o acompanhamento seja realizado por equipe multiprofissional, incluindo odontologista, fonoaudiólogo, fisioterapeuta e profissionais de outras especialidades identificados por meio de avaliação de necessidade individual do paciente. Para pacientes que apresentam manifestações neurológicas da doença de Wilson, a fisioterapia, fonoaudiologia e terapia ocupacional podem desempenhar papel importante na reabilitação<sup>11</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Dieta** -->
A restrição dietética de cobre não previne o acúmulo na doença de Wilson e inexistem evidências de que a prática melhore o resultado quando os quelantes são iniciados. No entanto, evitar alimentos ricos em cobre (feijão, mariscos, nozes, cacau, cogumelos e vísceras – como fígado) é aconselhado no primeiro ano de tratamento ou até a remissão dos sintomas e do retorno dos exames bioquímicos aos parâmetros de normalidade<sup>25,26</sup> .  
A restrição de ingestão de cobre em 1 a 2 mg/dia é amplamente aceitável e não específica para peso corporal ou idade (pediátrico ou adulto). Restrições podem ser indicadas para alimentos como feijão e cacau. Ainda, é importante ressaltar que o teor de cobre nos alimentos pode sofrer alteração de acordo com os processos empregados: secagem, torrefação, conservas, enlatamento e adição de conservantes aumentam o teor de cobre, enquanto fervura, polimento e refino reduzem o seu teor<sup>11,27</sup> .  
O Quadro 3 apresenta a quantidade de cobre, em miligramas, em alimentos citados como fontes de cobre.  
**Quadro 3 –** Teor de cobre em alimentos  
|**Alimento**|**Quantidade**||
|---|---|---|
||**Medida caseira (g/mL)**|**Cobre (mg)**|
|**Feijão carioca (grão e caldo)**|1 concha (140 g/mL)|0,28 mg|
|**Ervilha enlatada**|1 colher de servir (38 g/mL)|0,06 mg|
|**Achocolatado em pó**|1 colher de sopa (10 g/mL)|0,06 mg|
|**Fígado grelhado**|1 pedaço médio (110 g/mL)|13,8 mg|
|**Chocolate ao leite**|1 barra (90 g/mL)|0,27 mg|
|**Café infusão (a 10%)**|1 xícara de chá (200 g/mL)|0,01 mg|
|**Mexilhão cozido**|1 colher de servir (40 g/mL)|1,15 mg|
|**Camarão**|1 porção média (100 g/mL)|0,38 mg|  
|**Alimento**|**Quantidade**||
|---|---|---|
||**Medida caseira (g/mL)**|**Cobre (mg)**|
|**Noz pecan torrada**|1 porção média (30 g/mL)|0,35 mg|
|**Amendoim torrado**|1 colher de sopa (19 g/mL)|0,13 mg|
|**Cogumelo Paris cozido**|1 colher de sopa (35 g/mL)|0,18 mg|  
Fonte: Tabela Brasileira de Composição de Alimentos (TBCA)<sup>28</sup>

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Transplante hepático** -->
O transplante hepático é uma alternativa terapêutica para pacientes com insuficiência hepática fulminante ou que não tenham respondido ao tratamento medicamentoso. A substituição do órgão restabelece a função hepática e corrige o distúrbio metabólico subjacente<sup>29</sup> .  
O transplante hepático é necessário para pacientes que apresentam insuficiência hepática aguda ou cirrose descompensada<sup>15</sup> . Conforme revisão sistemática publicada em 2019, doença hepática crônica descompensada e falência hepática fulminante foram as principais indicações de transplante hepático em pacientes não adultos com a doença de Wilson<sup>29</sup> . Outras causas descritas pela mesma revisão foram cirrose descompensada, doença neurológica grave, doença hepática terminal descompensada e sintomas neurológicos<sup>29</sup> . Nesse sentido, o escore de King Wilson pode ser utilizado para orientar a indicação do transplante hepático na insuficiência hepática fulminante: escore igual ou superior a 11 indica a necessidade de transplante<sup>15,30,31</sup> .  
Após o transplante hepático, o paciente pode apresentar pouca melhora do envolvimento neurológico e, especialmente, do psiquiátrico. Assim, o transplante hepático não pode ser considerado uma terapia para pacientes com envolvimento neuropsiquiátrico grave<sup>12,15,25,29</sup> . Embora existam relatos de casos de pacientes com doença de Wilson que realizaram transplante hepático e apresentaram melhora neurológica significativa<sup>32</sup> , mais ensaios clínicos controlados são necessários para apoiar a indicação de transplante hepático como tratamento primário em pacientes com quadro neurológico grave na doença de Wilson<sup>11</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6.2. Tratamento medicamentoso** -->
Na doença de Wilson, o tratamento é baseado no uso de medicamentos que induzem a redução de cobre sérico livre do paciente. São utilizados quelantes, como a penicilamina ou a trientina, que promovem aumento da excreção urinária de cobre e inibidores da absorção de cobre pelo trato digestivo, tais como os sais de zinco: sulfato de zinco, gluconato de zinco ou acetato de zinco<sup>32</sup> .  
O tratamento deve ser iniciado após o diagnóstico e mantido ao longo da vida, assim como o monitoramento da adesão e a detecção precoce de complicações<sup>25</sup> . A falta de adesão e o tratamento com doses inferiores à necessidade do paciente (subdose) são os principais fatores de risco para uma evolução clínica desfavorável. Caso haja boa adesão e monitoramento adequado, o prognóstico do paciente pode ser excelente<sup>25</sup> . Portanto, a adesão ao tratamento ao longo da vida influencia o prognóstico do paciente<sup>16</sup> .  
Devido ao risco de esgotamento do cobre corporal, não é indicado que o tratamento seja iniciado no primeiro ano de vida. Apesar de a apresentação clínica da doença de Wilson ser rara antes dos 3 anos de idade, em pacientes que iniciam seu tratamento aos 2 anos de idade, sugere-se o uso de sais de zinco<sup>11</sup> .  
O tratamento pode ser dividido em duas fases: inicial e manutenção. A fase inicial tem como objetivo reduzir os níveis corporais de cobre ao seu limiar subtóxico. Para atingi-lo, devem ser utilizados quelantes (penicilamina ou trientina) ou sais de zinco. Já a terapia de manutenção deve ser mantida ao longo da vida e objetiva evitar novo acúmulo de cobre após o tratamento efetivo e a redução dos estoques tóxicos de cobre<sup>11,12</sup> .  
Recomenda-se que o tratamento inicial de pacientes sintomáticos com doença de Wilson inclua um agente quelante – penicilamina ou trientina<sup>11,15</sup> . A primeira linha de tratamento para pacientes com doença de Wilson é a penicilamina. A trientina deve ser utilizada por pacientes com intolerância, sem resposta adequada ou que apresentaram eventos adversos decorrentes do uso da penicilamina. Contudo, a trientina pode ser considerada como primeira linha quando houver indisponibilidade de penicilamina, conforme avaliação médica. Ressalta-se que inexistem estudos que comparem diretamente o uso de penicilamina a trientina.  
Quando tolerado, o quelante pode ser mantido durante toda a vida do paciente. O zinco é recomendado para pacientes que não toleram a utilização de quelantes, mas pode ser utilizado como terapia de primeira linha para pacientes assintomáticos e pré-sintomáticos com sintomas neurológicos ou para terapia de manutenção após remoção inicial do cobre com quelante<sup>11</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Penicilamina** -->
A penicilamina é o medicamento recomendado como primeira linha de tratamento de pacientes com doença de Wilson, sendo a principal opção para o tratamento das manifestações hepáticas da doença. Trata-se de um fármaco de eficácia comprovada e custo mais acessível<sup>33</sup> . Na forma neurológica da doença, a penicilamina é utilizada de maneira mais cautelosa, iniciando-se em dose mínima e incrementando-se gradualmente a dose sob monitoramento clínico e bioquímico<sup>11,12</sup> , uma vez que alguns pacientes apresentam agravo das manifestações neurológicas após o início da terapia. Nos pacientes que apresentam a forma neurológica da doença, os benefícios do tratamento são, em geral, observados de forma mais lenta<sup>11,12,15</sup> . A reintrodução do medicamento nos pacientes que interromperam a terapia por um longo período também deve ser feita de forma gradual, com o objetivo de evitar alterações neurológicas irreversíveis<sup>11,12,15</sup> .  
Os eventos adversos sérios desse medicamento estão descritos no **Quadro 4** .  
A penicilamina tende a interferir na ação da piridoxina devido à inibição da enzima piridoxina quinase<sup>33</sup> . Apesar da falta de evidências recentes quanto à deficiência de piridoxina em pacientes em uso de penicilamina<sup>25</sup> , recomenda-se a suplementação para crianças, gestantes e pacientes com desnutrição e doenças intercorrentes<sup>11</sup> , mesmo que essa prática seja muito variável<sup>25,34</sup> . A ocorrência de cútis laxa já foi observada em filhos de pacientes tratados com penicilamina<sup>35</sup> . Outras reações dermatológicas incluem, por exemplo, lesões penfigoides e elastose perfurante serpiginosa<sup>12</sup> .  
Em relação ao armazenamento, a penicilamina deve ser conservada em temperatura ambiente (entre 15<sup>o</sup> C e 30<sup>o</sup> C), protegida da luz e da umidade. O prazo de validade a partir da data de fabricação do medicamento é de 24 meses.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Trientina** -->
Trata-se de um agente quelante indicado para pacientes com doença de Wilson que desenvolveram intolerância, sem resposta adequada ou que apresentaram eventos adversos à penicilamina. Pode ser considerada como primeira linha quando houver indisponibilidade de penicilamina, conforme avaliação médica<sup>12,25</sup> .  
O **Quadro 4** descreve os eventos adversos relacionados à trientina. Apesar da recomendação do período ótimo para administração, a trientina pode ser ingerida próximo às refeições para garantir adesão ao tratamento<sup>15</sup> .  
Em um estudo piloto, oito pacientes utilizaram uma dose única diária e foram observados por um ano, com monitoramento mensal por 3 meses e, posteriormente, aos 6, 9 e 12 meses. Durante o período do estudo, todos permaneceram com exame físico inalterado e sem detecção de novos sinais neurológicos. Mesmo com flutuações nos níveis de transaminases, não foram relatadas interrupções de tratamento ou desistência do estudo<sup>36</sup> . Assim, a administração em dose única pode ser considerada em pacientes com baixa adesão.  
Considerando que a trientina também atua como agente quelante do ferro e de outros metais pesados, a administração simultânea de trientina e ferro é contraindicada, pois forma um complexo tóxico<sup>12,15</sup> . Portanto, se a suplementação de ferro for necessária, ela deve ser administrada em horários distanciados<sup>25</sup> .A trientina deve ser armazenada em temperatura entre 2<sup>o</sup> C e 8<sup>o</sup> C e, nessas condições, o prazo de validade é de 36 meses. Após aberto, o prazo de validade da trientina em temperatura ambiente (entre 15<sup>o</sup> C e 30<sup>o</sup> C) é de 60 dias.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Sais de zinco** -->
O zinco apresenta um bom perfil de segurança e previne ou alivia os sintomas de maneira semelhante à terapia quelante, embora os seus resultados não sejam definitivos. O mecanismo de ação do zinco é lento e a redução da sobrecarga de cobre no organismo pode ocorrer após semanas ou meses de seu uso, sendo inadequado para pacientes com toxicidade aguda de cobre<sup>37</sup> .  
Apesar de ser normalmente utilizado na terapia de manutenção<sup>12</sup> , a terapia inicial com zinco pode ser considerada para pacientes assintomáticos ou com a forma neurológica<sup>11,15,25</sup> . A associação de quelantes e sais de zinco não é recomendada por este Protocolo, pois foi observada uma taxa geral de eventos adversos de 41,7% entre os pacientes com sinais e sintomas hepáticos e taxa de mortalidade de 12,7%, o dobro da relatada para pacientes que receberam os outros medicamentos<sup>38</sup> . A base teórica da associação estaria relacionada ao efeito sinérgico de bloqueio da absorção e aumento da eliminação do excesso de cobre, sendo a administração realizada em intervalos amplamente espaçados para evitar interferências<sup>12,25</sup> . Há relatos sobre a associação de quelantes com zinco como tratamento intensivo em pacientes com doença de Wilson que apresentam cirrose descompensada<sup>12</sup> . Contudo, há poucas evidências sobre os resultados benéficos da terapia combinada em comparação à monoterapia e sua associação ao aumento da mortalidade e eventos adversos<sup>38</sup> . Do mesmo modo, a eficácia da monoterapia com zinco em pacientes sintomáticos com doença hepática ainda está em debate<sup>25,39</sup> . Assim, este Protocolo não recomenda a associação de medicamentos ou da monoterapia com zinco nesta população, tendo em vista as evidências disponíveis.  
Informações adicionais sobre os medicamentos utilizados no tratamento da doença de Wilson são apresentadas no **Quadro 4** .  
**Quadro 4 –** Mecanismo de ação, eventos adversos e informações adicionais sobre penicilamina, trientina e zinco para o tratamento da doença de Wilson  
|**Fármaco**|**Mecanismo de ação**|**Eventos adversos**|**Outras**<br>**informações**|
|---|---|---|---|
|**Penicilamina**|Remoção do excesso de|**Reações de sensibilidade precoce (1 a 3 semanas):**|Necessária|
||cobre<br>por<br>agentes<br>quelantes<br>(Excreção<br>urinária<br>e<br>possível<br>indução<br>de<br>metalotioneína)|febre,<br>erupções<br>cutâneas,<br>linfadenopatia,<br>neutropenia ou trombocitopenia, proteinúria.<br>**Reações a médio e longo prazo:**síndrome<br>semelhante ao lúpus, elevações nos anticorpos<br>antinucleares séricos sem correlação clara com o<br>desenvolvimento de doenças imunomediadas<br>Reações tardias: nefrotoxicidade<br>**Descontinuar imediatamente**<sup>a</sup>**:**trombocitopenia<br>grave ou aplasia total (toxicidade significativa da<br>medula óssea), proteinúria ou presença de outros<br>elementos celulares na urina|suplementação com<br>piridoxina.|
|**Trientina**|Remoção do excesso de<br>cobre<br>por<br>agentes<br>quelantes<br>(Excreção urinária)|Raros:<br>reações<br>alérgicas,<br>artralgias,<br>cãibras<br>musculares e anemia sideroblástica|Administração<br>simultânea<br>de<br>trientina<br>e<br>ferro<br>deve ser evitada.|
|**Zinco**<br>**(sulfato,**<br>**acetato**<sup>**b**</sup>**)**|Bloqueio<br>da<br>absorção<br>intestinal<br>de<br>cobre<br>e<br>indução da metalotioneína<br>dos hepatócitos|Problemas gastrointestinais (dependendo do sal de<br>zinco empregado)<sup>c</sup>, como náuseas, vômitos, dor<br>epigástrica, ulceração ou erosão da mucosa gástrica<br>e duodenal. Anemia secundária a deficiência de<br>ferro. Efeitos imunossupressores e redução da|Tratamento<br>combinado<br>com<br>penicilamina<br>ou<br>trientina pode ser<br>opção<br>para|  
|**Fármaco**|**Mecanismo de ação**|**Eventos adversos**|**Outras**<br>**informações**|
|---|---|---|---|
|||quimiotaxia leucocitária. Elevação isolada de<br>amilase e lipase séricas, sem evidência clínica ou<br>radiológica de pancreatite.|pacientes<br>graves.<br>Nesses<br>casos,<br>a<br>administração deve<br>ser realizada em<br>intervalos<br>espaçados durante<br>o dia e nunca pode<br>ser simultânea.|  
aToxicidade hematológica que justifica a interrupção imediata do uso e a mudança para trientina ou sais de zinco.  
bInexiste apresentação comercial disponível do acetato de zinco, podendo este ser produzido em farmácias de manipulação.  
c Os sintomas gastrointestinais podem desaparecer ao mudar a formulação para acetato de zinco.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Tratamento neurológico e psiquiátrico** -->
O tratamento dos sintomas neurológicos e psiquiátricos deve ser norteado conforme Protocolos Clínicos e Diretrizes Terapêuticas específicos vigentes, tais como o PCDT de Distonias e Espasmo Hemifacial, PCDT de Dor Crônica, PCDT de Espasticidade e PCDT de Epilepsia, e as particularidades da doença de base, conforme **Quadro 5** .  
É importante que a causa das manifestações psiquiátricas seja reconhecida, pois a terapia de quelação pode reverter sintomas, incluindo doenças psiquiátricas resistentes à terapia sintomática convencional<sup>40</sup> .  
**Quadro 5 -** Tratamento medicamentoso dos sintomas neuropsiquiátricos  
|**Condição clínica**|**Medicamentos contraindicados**|**Motivo**|
|---|---|---|
|**Doença de Wilson**|Neurolépticos|Risco de eventos adversos com<br>distúrbios do movimento|
|**Hiperesplenismo ou tratamento com**<br>**penicilamina**|Olanzapina, risperidona, quetiapina e<br>clozapina|Risco aumentado de agranulocitose|
|**Tratamento da mania + Insuficiência**<br>**hepática**|Valproato ou carbamazepina|Metabolismo hepático|
|**Tratamento da mania +**<br>**Acidose tubular renal**|Lítio|Excreção renal do lítio|  
Fonte: Bonnot et al., 2014<sup>41</sup>

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **Terapias aprovadas em agências internacionais e terapias em estudo** -->
No Brasil, a única formulação disponível da trientina é o dicloridrato de trientina. Outras agências internacionais regulamentaram o tetracloridrato de trientina para o tratamento de doença de Wilson - indeferida pela Agência Nacional de Vigilância Sanitária (Anvisa) para registro e comercialização no Brasil<sup>42</sup> por falta de comprovação de eficácia e segurança<sup>43</sup> . Há, também, novas terapias em fase de desenvolvimento, como o tetratiomolibdato bis-colina<sup>44,45</sup> , e a terapia gênica<sup>46,47</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6.2.1. Medicamentos** -->
- Penicilamina: cápsula de 250 mg.  
- Trientina: cápsula de 250 mg.  
- Piridoxina: comprimido de 40 mg.  
- Sulfato de zinco: comprimido mastigável de 10 mg; xarope de 4 mg de zinco elementar/mL.  
No Brasil, não há preparações farmacêuticas industriais prontas de acetato de zinco, sendo necessário que sejam manipuladas em farmácias magistrais.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6.2.2. Esquemas de administração** -->
- **Penicilamina: cápsula de 250 mg**  
- Adultos: 250 mg/dia em fase inicial e 750 a 1.500 mg/dia em fase de manutenção  
- Crianças: 20 mg/kg/dia (arredondado para os 250 mg mais próximos)  
Administrar via oral, dividido em 2 a 4 doses diárias, uma hora antes ou duas horas após as refeições e, pelo menos, uma hora antes de ingerir qualquer alimento ou medicamento<sup>11,12</sup> . O paciente deve ser orientado a tomar meio litro de líquido ao deitar e outro meio litro uma vez durante a noite. Em adultos, a dose inicial recomendada é de 250 mg/dia, aumentada gradualmente até a quantidade desejada, por incrementos de 250 mg semanais. Para maior segurança do paciente, sugere-se que o aumento de dose seja realizado sob monitoramento clínico e bioquímico<sup>11,12</sup> . O tratamento adequado pode ser identificado pela quantificação de cobre sérico livre no soro, usualmente menor que 10 mcg/dL. Na ausência de reações adversas, a dose de manutenção pode ser mantida entre 750 e 1.500 mg<sup>12,48</sup> . A administração única de doses maiores ou iguais a 1.500 mg por dia pode levar a deterioração neurológica rápida e irreversível<sup>15</sup> .  
- **Trientina: cápsula de 250 mg**  
- Adultos: 750 a 1.250 mg/dia em fase inicial, com dose de manutenção máxima de 2.000 mg/dia  
- Crianças: 500 a 750 mg/dia em fase inicial, com dose de manutenção máxima de 1.500 mg/dia  
Administrar via oral, dividido em 2 a 4 doses diárias, uma hora antes ou duas horas após as refeições e, pelo menos, uma hora antes de ingerir qualquer alimento ou medicamento<sup>12</sup> . Caso não seja observada resposta clínica adequada ou quando a concentração de cobre sérico livre no soro apresentar medidas persistentes acima de 20 mcg/dL, a dose diária deve ser aumentada. É recomendado que as doses de manutenção sejam determinadas em intervalos de 6 a 12 meses<sup>49</sup> .  
- **Piridoxina: comprimido de 40 mg**  
- Adultos e crianças: 20 mg/dia, via oral, concomitante ao uso de penicilamina.  
- **Sulfato de zinco (zinco elementar)**  
- Adultos: 150 mg de zinco elementar/dia  
- Crianças:  50 mg de zinco elementar/dia para menores de 5 anos; 75mg de zinco elementar/dia para crianças com peso  
- corporal menor que 50 kg; 150 mg de zinco elementar/dia para crianças com peso corporal maior que 50 kg  
Para menores de 5 anos: Administrar via oral, 25 mg de zinco elementar duas vezes ao dia, 30 minutos antes da refeição. Para os demais, administrar via oral, a dose diária dividida em três vezes, 30 minutos antes da refeição<sup>12</sup> .  
**Nota:** No caso do uso do Acetato de zinco dihidratado magistral, deve-se iniciar com dose de 170 mg (50 mg de zinco elementar) a cada 8 horas, via oral. Preferencialmente, deve ser administrado pelo menos 1 hora antes ou 1 hora após as refeições, o que, em alguns casos, ocasiona sintomas dispépticos. Nessas situações, sugere-se que o medicamento seja tomado junto às refeições, mas deve-se basear a necessidade de aumento de dose pela medida do cobre sérico livre.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6.2.3. Critérios de interrupção** -->
Todos os medicamentos são contraindicados em casos de hipersensibilidade ao fármaco ou a qualquer componente da formulação. O medicamento utilizado deve ser alterado se o paciente apresentar<sup>25</sup> :  
 **Zinco** – Persistência dos níveis de alanina aminotransferase (ALT) em valores três vezes acima do limite superior de referência; Relação Normalizada Internacional (INR - _International Normalized Ratio_ ) maior que 1,5; ou sinais e sintomas de baixa tolerância ao medicamento (náusea, dor abdominal, ulcerações gástricas);  
 **Penicilamina** – Sinais ou sintomas de baixa tolerância ao medicamento ou eventos adversos (febre, neutropenia, trombocitopenia, linfadenopatia ou proteinúria);  
 **Trientina** - Sinais ou sintomas de baixa tolerância ou eventos adversos (artralgia, anemia sideroblástica).  
Durante a fase de manutenção da terapia com quelante, a excreção urinária de cobre em 24 horas deve ser de, aproximadamente, 200 a 500 mcg (3 a 8 µmol/24h) e cobre sérico livre abaixo de 10 mcg/dL<sup>12,16</sup> . Nesses casos, pacientes considerados estáveis podem ser avaliados para substituição da dose de manutenção de quelante por sal de zinco<sup>16</sup> ou diminuição da dose de manutenção do quelante.  Contudo, dever ser mantida a monitorização com cobre sérico livre para certificação da adesão à prescrição do medicamento e da dieta. Com a interrupção do quelante, pode haver casos de piora neurológica e também de descompensação hepática progressiva refratária ao reinício do tratamento.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **6.2.4 Tratamento em populações específicas** -->
Mulheres em idade reprodutiva ou com a intenção de engravidar devem ser informadas sobre o risco aumentado de aborto espontâneo<sup>50</sup> . O aconselhamento deve abordar os riscos envolvidos no uso do medicamento e na doença não controlada. A monitorização dos níveis de cobre antes e durante a gravidez deve ser otimizada<sup>11</sup> .  
A decisão pela utilização de agentes quelantes em mulheres grávidas deve contemplar a relação risco-benefício já que a segurança desses medicamentos durante a gravidez ainda não foi bem estabelecida. Teratogenicidade associada a altas doses de penicilamina foi relatada em estudos em animais<sup>51</sup> .  
Em grávidas, as doses de penicilamina e trientina devem ser reduzidas em 25% a 50% para evitar quelação excessiva e deficiência materna de cobre<sup>11,12,16</sup> . Caso a penicilamina seja prescrita, recomenda-se que a dose diária não ultrapasse 1 g<sup>48</sup> . Os quelantes podem ser mantidos em dose mínima de 300-600 mg/dia no último trimestre para evitar fornecimento insuficiente de cobre para o feto e promover a cicatrização após cesariana, se esta for realizada<sup>15,16</sup> . A dose de sais de zinco pode ser mantida sem alterações<sup>11,12,16,52</sup> . Entretanto, um grupo da Universidade Federal de Minas Gerais relatou uma série de 26 gestantes com doença de Wilson em tratamento, sendo que 6 (23,1%) tiveram crianças que apresentaram malformação congênita, todas elas tratadas com zinco. Além disso, 8 (30,8%) sofreram aborto espontâneo – 2 em uso de penicilamina, 2 em uso de zinco e 4 sem tratamento<sup>50</sup> . A experiência desse grupo difere da relativa segurança relatada previamente, e suscita a necessidade de mais estudos a respeito.  
Uma vez iniciado, é recomendado que o tratamento da doença de Wilson em mulheres grávidas seja mantido durante todo o curso da gravidez pois sua interrupção pode resultar em insuficiência hepática fulminante e aparecimento de sintomas neurológicos<sup>11,15,16</sup> .  
A amamentação não é recomendada para pessoas em uso de penicilamina devido ao potencial efeito prejudicial ao bebê, uma vez que o medicamento é excretado no leite<sup>11</sup> . No momento da prescrição, os riscos da amamentação quando a mãe está em uso de penicilamina devem ser bem esclarecidos para a paciente e recomendam-se verificações regulares de hemograma completo do bebê<sup>12</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **7. MONITORAMENTO** -->
O objetivo do monitoramento do tratamento é confirmar a melhora clínica e bioquímica, garantir a adesão à terapia e identificar os eventos adversos em tempo hábil<sup>16</sup> .  
Durante a fase inicial do tratamento, o monitoramento deve ser mais frequente, assim como para pacientes que apresentem piora dos sintomas ou suspeita de baixa adesão ou abandono da terapia<sup>16</sup> . Recomenda-se que na fase inicial o acompanhamento seja semanal, principalmente durante o aumento gradual de dose da penicilamina<sup>25</sup> . Na fase de manutenção, o monitoramento pode variar, mas deve ser realizado no mínimo duas vezes por ano<sup>16</sup> .  
Em geral, o monitoramento deve avaliar sinais e sintomas relacionados com a doença de Wilson e a terapia adotada – como exame físico, identificação dos anéis de Kayser-Fischer, ultrassom abdominal e ressonância magnética de crânio, função hepática e excreção urinária de cobre na urina 24 horas, principalmente quando em terapia com quelantes. O monitoramento da função hepática é importante para coletar informações de base na fase inicial e avaliar a melhora progressiva a partir de 3 a 12 meses. A melhora clínica da função hepática é caracterizada pela diminuição da icterícia, ascite e hipertensão portal.  
Pacientes que estejam em uso de sais de zinco devem realizar dosagem dos níveis de zinco sérico e urinário. Outro exame necessário é o hemograma, para rastreamento da neutropenia e da anemia que podem ser causadas pela falha da mobilização do ferro, com elevação das transaminases devido ao aumento do ferro hepático acompanhado pelo aumento da ferritina. Também deve ser realizado o exame qualitativo de urina, para rastreio de eventos adversos relacionados à terapia, principalmente proteinúria<sup>25</sup> . Os exames e parâmetros para monitoramento da doença são descritos nos **Quadros 6 e 7** .  
Recomenda-se a realização de hemograma completo e testes de função hepática, semanalmente durante a fase inicial da terapia. Posteriormente, pode-se diminuir a periodicidade da avaliação, passando a ser quinzenal ou mensal, seguida por trimestral, semestral e anual<sup>11</sup> .  
**Quadro 6 –** Parâmetros de monitoramento do tratamento de doença de Wilson com penicilamina ou trientina  
**Penicilamina e trientina**  
|**Parâmetro**|**Valor alvo para fase**<br>**inicial**|**Valor**<br>**alvo**<br>**para**<br>**fase**<br>**de**<br>**manutenção**|**Avaliação de dose e adesão**|
|---|---|---|---|
||**2 dias iniciais:**|200-500 mcg/ 24h|**Após 2 dias de interrupção ou não**|
|**Cobre urinário**<br>**(Urina 24h)**|≥1.000 mcg/ 24h<br>**A partir do 3º dia:**<br>> 500 mcg/ 24h|Diminuição esperada quando os<br>testes de função hepática voltarem<br>ao normal, indicando uma redução<br>na carga corporal de cobre|**adesão:**< 50 mcg/24h<br>**Dose inadequada ou baixa adesão:**<<br>200 mcg/24h ou > 500 mcg/24h|
||||**Dose inadequada ou baixa adesão:**>|
|**Cobre**<br>**sérico**<br>**livre**|25 mcg/dL|5 mcg/ dL|15 mcg/ dL<br>**Dose elevada:**< 5 mcg/ dL|  
Cálculo do cobre sérico livre: cobre sérico subtraído pelo triplo do valor da ceruloplasmina sérica, como indicado: Estimativa do cobre sérico livre (mcg/L) = cobre sérico total (mcg/L) – [3,15x ceruloplasmina sérica (mg/L)].  Não utilizar o cálculo se ceruloplasmina sérica não for medida pelo método enzimático<sup>11</sup> Fonte: Adaptado de Ferenci et al., 2012; Socha et al., 2018; Nagral et al., 2019<sup>11,15,25</sup>  
**Quadro 7 –** Parâmetros de monitoramento do tratamento de doença de Wilson com sais de zinco  
|**Sais de zinco**||||
|---|---|---|---|
|**Parâmetro**|**Valor alvo para fase**<br>**inicial**|**Valor alvo para fase de**<br>**manutenção**|**Avaliação de dose e adesão**|
|**Cobre**<br>**urinário**<br>**(Urina 24h)**|100–500 mcg/24h|30 -75 mcg/ 24 h|**Dose elevada:**<br><30 mcg/24 h|
|**Cobre sérico livre**|> 25 mcg/dL|10–15 mcg/dL|**Dose inadequada ou baixa adesão:**|  
|**Sais de zinco**||||
|---|---|---|---|
|**Parâmetro**|**Valor alvo para fase**<br>**inicial**|**Valor alvo para fase de**<br>**manutenção**|**Avaliação de dose e adesão**|
||||> 15 mcg/dL|
||||**Dose elevada:**<br>< 5 mcg/dL|
|**Zinco sérico**|Informações de base|>125 mcg/dL|**Baixa adesão:**<br>>125 mcg/dL|
|**Zinco Urinário**|>2.000mcg/d|> 2 mg/24 h|**Baixa adesão:**<br>>1,5 -2 g/24 h|  
Cálculo do cobre sérico livre: cobre sérico subtraído pelo triplo do valor da ceruloplasmina sérica. Não utilizar o cálculo se ceruloplasmina sérica não for medida pelo método enzimático<sup>11</sup>  
Fonte: Adaptado de Ferenci et al., 2012; Socha et al., 2018; Nagral et al., 2019<sup>11,15,25</sup>  
Recentemente, uma nova ferramenta está sendo descrita para diagnóstico e acompanhamento da doença de Wilson: a dosagem da fração de cobre intercambiável, que ofereceria uma informação mais correta da sobrecarga de cobre livre. O cobre intercambiável (CuEXC) possui relação direta com a extensão e gravidade da doença de Wilson e a expectativa é de que o cálculo do cobre intercambiável relativo (REC) seja um biomarcador mais fidedigno para o diagnóstico da doença de Wilson<sup>53</sup> . No entanto, como ainda não há uma metodologia padrão-ouro determinada, apesar de promissor, o exame ainda é realizado em caráter experimental, impossibilitando a avaliação de sua incorporação ao SUS<sup>53</sup> .  
A avaliação sequencial dos sintomas neurológicos continua sendo o item mais crítico do monitoramento dos benefícios terapêuticos. As escalas de classificação podem ajudar a quantificar objetivamente a gravidade da doença e seu impacto no estilo de vida do paciente<sup>11</sup> . Um exemplo é a Escala de Avaliação Global para Doença de Wilson ( _Global Assessment Scale for Wilson's Disease_ – GAS), que considera alterações neuropsiquiátricas, hepáticas e osteomusculares em sua avaliação<sup>54</sup> .

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamentos prescritas e dispensadas e da adequação das condutas indicadas e do acompanhamento pós-tratamento.  
Os pacientes com doença de Wilson devem ser, preferencialmente, atendidos em estabelecimentos de saúde localmente designados como centros de referência para a investigação diagnóstica das pessoas com suspeita da doença e para o acompanhamento das pessoas com a doença, incluindo seus familiares, sempre que possível com especialistas que atuem em hepatologia e neurologia (pediátrico e adulto). É desejável que tais serviços sejam especializados também porque os pacientes com doença de Wilson devem ser avaliados periodicamente em relação à eficácia do tratamento e ao desenvolvimento de toxicidade aguda ou crônica e a existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses, conforme necessário, e o controle de eventos adversos. Por fim, dado que o controle da doença exige experiência e familiaridade do profissional com as manifestações clínicas associadas, convém que o médico responsável tenha experiência no seu manejo. Assim, cabe destacar que, sempre que possível, o atendimento da pessoa com Doença de Wilson deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio, conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
Os estados, DF e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde, via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes. Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, a Tabela do SUS, podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, por meio do SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada. A indicação de transplante deve observar o Regulamento Técnico do Sistema Nacional de Transplantes vigente e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela do SUS.  
Os receptores submetidos a transplante originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados. Os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este com as informações atualizadas sobre a evolução dos transplantados.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do SUS por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017). A Política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivos reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e melhorar a qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações no âmbito da Política é estruturada pela Atenção Primária e pela Atenção Especializada, em conformidade com a RAS e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial e hospitalar, apoiando e complementando os serviços da Atenção Primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o lócus da atenção à saúde dos pacientes com doenças raras. Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados conforme a Política Nacional:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **10. REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. Schilsky ML. Wilson Disease: Diagnosis, Treatment, and Follow-up. Clin Liver Dis [Internet]. 2017;21(4):755–67. Available at: http://dx.doi.org/10.1016/j.cld.2017.06.011  
2. Scheinberg I, Sternlieb I. Wilson’s disease. Philadelphia WB Saunders. 1984;  
3. Gao J, Brackley S, Mann JP. The global prevalence of Wilson disease from next-generation sequencing data. Genet Med. 2019;21(5):1155–63.  
4. Bhattacharya PT, Misra SR, Hussain M. Nutritional Aspects of Essential Trace Elements in Oral Health and Disease: An Extensive Review. Scientifica (Cairo) [Internet]. 2016;2016:1–12. Available at: http://www.hindawi.com/journals/scientifica/2016/5464373/  
5. Chanpong A, Dhawan A. Wilson disease in children and young adults - State of the art. Saudi J Gastroenterol. 2022;28(1):21–31.  
6. Guindi M. Wilson disease. Semin Diagn Pathol [Internet]. 2019;36(6):415–22. Available at: https://doi.org/10.1053/j.semdp.2019.07.008  
7. Członkowska A, Litwin T, Dusek P, Ferenci P, Lutsenko S, Medici V, et al. Wilson disease. Nat Rev Dis Prim. 2018;4(1):1–20.  
8. Linder MC. Apoceruloplasmin: Abundance, Detection, Formation, and Metabolism. Biomedicines [Internet]. 25 de fevereiro de 2021;9(3):233. Available at: https://www.mdpi.com/2227-9059/9/3/233  
9. The Human Gene Mutation Database. Wilson Disease [Internet]. 2022 [citado 21 de julho de 2022]. Available at: https://www.hgmd.cf.ac.uk/ac/gene.php?gene=ATP7B  
10. Mulligan C, Bronstein JM. Wilson Disease: An Overview and Approach to Management. Neurol Clin [Internet]. 2020;38(2):417–32. Available at: https://doi.org/10.1016/j.ncl.2020.01.005  
11. Nagral A, Sarma MS, Matthai J, Kukkle PL, Devarbhavi H, Sinha S, et al. Wilson’s Disease: Clinical Practice Guidelines of the Indian National Association for Study of the Liver, the Indian Society of Pediatric Gastroenterology, Hepatology and Nutrition, and the Movement Disorders Society of India. J Clin Exp Hepatol [Internet]. 2019;9(1):74–98. Available at: https://www.embase.com/search/results?subaction=viewrecord&id=L2001156753&from=export  
12. Schilsky ML, Roberts EA, Bronstein JM, Dhawan A, Hamilton JP, Rivard AM, et al. A Multidisciplinary Approach to the Diagnosis and Management of Wilson Disease: 2022 Practice Guidance on Wilson Disease from the American Association for the Study of Liver Diseases. Hepatology. 2022;(September):1–49.  
13. Ferenci P. Diagnosis of Wilson disease [Internet]. 1<sup>o</sup> ed. Vol. 142, Handbook of Clinical Neurology. Elsevier B.V.; 2017. 171–180 p. Available at: http://dx.doi.org/10.1016/B978-0-444-63625-6.00014-8  
14. Machado A, Chien HF, Deguti MM, Cançado E, Azevedo RS, Scaff M, et al. Neurological manifestations in Wilson’s disease: Report of 119 cases. Mov Disord. 2006;21(12):2192–6.  
15. Ferenci P, Czlonkowska A, Stremmel W, Houwen R, Rosenberg W, Schilsky M, et al. EASL Clinical Practice Guidelines: Wilson’s disease. J Hepatol [Internet]. 2012;56(3):671–85. Available at: http://dx.doi.org/10.1016/j.jhep.2011.11.007  
16. Roberts EA, Schilsky ML. A practice guideline on Wilson disease. Hepatology. 2003;37(6):1475–92.  
17. Pandey N, John S. Kayser-Fleischer Ring. StatPearls Publ LLC [Internet]. 2022 [citado 9 de fevereiro de 2023]; Available at: https://www.ncbi.nlm.nih.gov/books/NBK459187/  
18. Salman HM, Amin M, Syed J, Sarfraz Z, Sarfraz A, Sarfraz M, et al. Biochemical testing for the diagnosis of Wilson’s disease: A systematic review. J Clin Lab Anal. 2022;36(2):1–8.  
19. Hitoshi S, Iwata M, Yoshikawa K. Mid-brain pathology of Wilson’s disease: MRI analysis of three cases. Neurosurgery, and Psychiatry. 1991;54:624–6.  
20. Jacobs DA, Markowitz CE, Liebeskind DS, Galetta SL. The “double panda sign” in Wilson’s disease. 2003 [citado 9 de janeiro de 2023]; Available at: http://n.neurology.org/content/61/7/969.full#%23otherarticles  
21. Ferenci P, Caca K, Loudianos G, Mieli-Vergani G, Tanner S, Sternlieb I, et al. Diagnosis and phenotypic classification of Wilson disease. Liver Int. 2003;23(3):139–42.  
22. Deguti MM, Genschel J, Cancado ELR, Barbosa ER, Bochow B, Mucenic M, et al. Wilson disease: novel mutations in the ATP7B gene and clinical correlation in Brazilian patients. Hum Mutat. 2004;23(4):398.  
23. De Bem RS, Raskin S, Muzzillo DA, Deguti MM, Cançado ELR, Araújo TF, et al. Wilson’s disease in southern Brazil: Genotype-phenotype correlation and description of two novel mutations in ATP7B gene. Arq Neuropsiquiatr. 2013;71(8):503–7.  
24. Otto P, Deguti M, Araújo T, Barbosa E, Bem R, Araújo F, et al. Estimation of Allele Frequencies and Population Incidence of Wilson Disease in Brazil. Prensa Med. 2016;102(5).  
25. Socha P, Janczyk W, Dhawan A, Baumann U, D’Antiga L, Tanner S, et al. Wilson’s Disease in Children: A Position Paper by the Hepatology Committee of the European Society for Paediatric Gastroenterology, Hepatology and Nutrition. Vol. 66, Journal of Pediatric Gastroenterology and Nutrition. 2018. 334–344 p.  
26. Palumbo CS, Schilsky ML. Clinical practice guidelines in Wilson disease. Ann Transl Med [Internet]. 2019;7. Available at: https://www.embase.com/search/results?subaction=viewrecord&id=L627520029&from=export  
27. Oliveira DR De, Henriques MC do C, Santos LC dos. Terapia nutricional na doença de Wilson. Rev Bras Nutr Clin 2012; 2012;27(2):132–40.  
28. Tabela Brasileira de Composição de Alimentos (TBCA). Universidade de São Paulo (USP). Food Research Center (FoRC). Versão 7.1. São Paulo. [Internet]. 2020 [citado 24 de julho de 2022]. Available at: http://www.tbca.net.br/  
29. Garoufalia Z, Prodromidou A, Machairas N, Kostakis ID, Stamopoulos P, Zavras N, et al. Liver Transplantation for Wilson’s Disease in Non-adult Patients: A Systematic  Review. Transplant Proc. março de 2019;51(2):443–5.  
30. Chanpong A, Dhawan A. Re-evaluation of King Wilson Index in Children With Acutely Decompensated Hepatic Wilson Disease. J Pediatr Gastroenterol Nutr. 2022;74(4):510–5.  
31. Dhawan A, Taylor RM, Cheeseman P, De Silva P, Katsiyiannakis L, Mieli-Vergani G. Wilson’s disease in children: 37year experience and revised King’s for liver transplantation. Liver Transplant. 2005;11(4):441–8.  
32. Litwin T, Bembenek J, Antos A, Przybyłkowski A, Skowrońska M, Kurkowska-Jastrzębska I, et al. Liver transplantation as a treatment for Wilson’s disease with neurological  presentation: a systematic literature review. Acta Neurol Belg. abril de 2022;122(2):505–18.  
33. Teive HAG, Barbosa ER, Lees AJ. Wilson’s disease: the 60th anniversary of Walshe’s article on treatment with  
penicillamine. Arq Neuropsiquiatr [Internet]. janeiro de 2017;75(1):69–71. Available at: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S0004-282X2017000100069&lng=en&tlng=en  
34. Kleine RT, Mendes R, Pugliese R, Miura I, Danesi V, Porta G. Wilson’s disease: an analysis of 28 Brazilian children. Clinics [Internet]. março de 2012;67(3):231–5. Available at:  
https://linkinghub.elsevier.com/retrieve/pii/S1807593222018579  
35. Pinter R, Hogge WA, McPherson E. Infant with severe penicillamine embryopathy born to a woman with Wilson disease. Am J Med Genet. 2004;128 A(3):294–8.  
36. Ala A, Aliu E, Schilsky ML. Prospective pilot study of a single daily dosage of trientine for the treatment of Wilson disease. Dig Dis Sci [Internet]. 1 de maio de 2015 [citado 23 de julho de 2022];60(5):1433–9. Available at: https://pubmed.ncbi.nlm.nih.gov/25605552/  
37. Appenzeller-Herzog C, Mathes T, Heeres MLS, Weiss KH, Houwen RHJ, Ewald H. Comparative effectiveness of common therapies for Wilson disease: A systematic review and meta-analysis of controlled studies. Liver Int. 2019;39(11):2136–52.  
38. Chen JC, Chuang CH, Wang JD, Wang CW. Combination therapy using chelating agent and zinc for Wilson’s disease. J Med Biol Eng [Internet]. 2015;35(6):697–708. Available at:  
https://www.embase.com/search/results?subaction=viewrecord&id=L608132164&from=export  
39. Avan A, Członkowska A, Gaskin S, Granzotto A, Sensi SL, Hoogenraad TU. The Role of Zinc in the Treatment of Wilson’s Disease. Int J Mol Sci. 2022;23(16):1–16.  
40. Ben-Pazi H, Jaworowski S, Shalev RS. Cognitive and psychiatric phenotypes of movement disorders in children: a systematic review. Dev Med Child Neurol. dezembro de 2011;53(12):1077–84.  
41. Bonnot O, Klünemann HH, Sedel F, Tordjman S, Cohen D, Walterfang M. Diagnostic and treatment implications of psychosis secondary to treatable  metabolic disorders in adults: a systematic review. Orphanet J Rare Dis. abril de 2014;9:65.  
42. Brasil. Resolução-RE N<sup>o</sup> 103, de 13 de janeiro de 2022. Diário Oficial da União - seção 1. N<sup>o</sup> 11, segunda-feira, 17 de janeiro de 2022.  
43. Agência Nacional de Vigilência Sanitária (Anvisa). Parecer Público de Avaliação do Medicamento - Reprovação. R1 20/01/2022. 2022;1–3.  
44. ClinicalTrials.gov. NCT04573309. Copper and Molybdenum Balance in Participants With Wilson Disease Treated With ALXN1840 [Internet]. 2022 [citado 10 de janeiro de 2023]. Available at: https://www.clinicaltrials.gov/ct2/show/NCT04573309?term=NCT04573309&draw=2&rank=1  
45. ClinicalTrials.gov. NCT04422431. Copper Concentration & Histopathologic Changes in Liver Biopsy in Participants With Wilson Disease Treated With ALXN1840 [Internet]. 2022 [citado 10 de janeiro de 2023]. Available at: https://www.clinicaltrials.gov/ct2/show/NCT04422431?term=NCT04422431&draw=2&rank=1  
46. ClinicalTrials.gov. NCT04884815. Study of UX701 Gene Transfer for the Treatment of Wilson Disease [Internet]. 2022 [citado 10 de janeiro de 2023]. Available at:  
https://www.clinicaltrials.gov/ct2/show/NCT04884815?term=NCT04884815&draw=2&rank=1  
47. ClinicalTrials.gov. NCT04537377. A Phase I/II Study of VTX-801 in Adult Patients With Wilson’s Disease  [Internet]. 2022 [citado 10 de janeiro de 2023]. Available at:  
https://www.clinicaltrials.gov/ct2/show/NCT04537377?term=NCT04537377&draw=2&rank=1  
48. Bausch Health. [Bula do Profissional] Cuprimine®. Penicilamina - cápsula 250mg. 2020.  
49. [Bula para o paciente]. WILLENTINE®. Cloridrato de trientina - cápsula dura. 2022.  
50. Mussi MCL, Nardelli MJ, Santos BC, Abreu ES de, Osório FMF, Cançado GGL, et al. Pregnancy Outcomes in Wilson’s  
Disease Women: Single-Center Case Series. Fetal Pediatr Pathol [Internet]. 2022;41(5):741–8. Available at: https://doi.org/10.1080/15513815.2021.1960940  
51. Keen CL, Mark Savage P, Lonnerdal B, Hurley LS. Teratogenic effects of D-penicillamine in rats: relation to copper deficiency. Drug Nutr Interact [Internet]. 1983 [citado 3 de março de 2023];2(1):17–34. Available at: https://europepmc.org/article/med/6678745  
52. Pfeiffenberger J, Beinhardt S, Gotthardt DN, Haag N, Freissmuth C, Reuner U, et al. Pregnancy in Wilson’s disease: Management and outcome. Hepatology [Internet]. 18 de abril de 2018;67(4):1261–9. Available at: https://journals.lww.com/01515467-201804000-00014  
53. Woimant F, Djebrani-Oussedik N, Poujois A. New tools for Wilson’s disease diagnosis: exchangeable copper fraction. Ann Transl Med. 2019;7(S2):S70.  
54. Aggarwal A, Aggarwal N, Nagral A, Jankharia G, Bhatt M. A novel global assessment scale for Wilson’s disease (GAS for WD). Mov Disord. 2009;24(4):509–18.  
55. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 6, de 28 de setembro de 2017 [Internet]. 2017 [citado 10 de janeiro de 2023]. Available at: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.html  
56. Brasil. Ministério da Saúde. Portaria de Consolidação GM/MS n<sup>o</sup> 2, de 28 de setembro de 2017 [Internet]. 2017 [citado 10 de janeiro de 2023]. Available at: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE

---

<!-- METADADOS: doenca: Doença de Wilson | secao: PENICILAMINA, PIRIDOXINA, TRIENTINA E SULFATO DE ZINCO -->
Eu, ___________________________________________________________________________ nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **penicilamina, piridoxina, trientina e sulfato de zinco** indicadas para o tratamento da **doença de Wilson** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico  
___________________________________________________________________________________ (nome do(a) médico(a)  
que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhoras:  
- aumento da expectativa de vida;  
- diminuição dos sintomas, com melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos do  
uso dos medicamentos:  
**- eventos adversos da penicilamina** : principais: reações alérgicas (coceira, vermelhidão na pele), náusea, vômitos, diarreia, dor no estômago, diminuição ou perda do paladar, diminuição das células brancas e vermelhas do sangue (que devem ser muito controladas), fraqueza nos músculos, zumbidos, agitação, ansiedade, queda de cabelo, visão borrada; mais raros: inflamação do pâncreas, inflamação dos pulmões, síndromes miastênicas (dificuldade para respirar, falar, mastigar, engolir, visão dupla e fraqueza nos músculos) e síndromes lúpicas (bolhas na pele, dor no peito e dor nas juntas), proteinúria e síndrome nefrótica;  
- **eventos adversos da piridoxina:** eventos adversos atribuíveis isoladamente à piridoxina são raramente relatados; podem ocorrer queixas de acidez estomacal, indigestão e náusea (geralmente com doses elevadas), além de casos raros de problemas com os nervos nas extremidades;  
- **eventos adversos do sulfato de zinco:** a ingestão excessiva de zinco pode causar náusea, vômitos, dor no estômago,  
- diarreia, lentidão e fadiga;  
**- eventos adversos da trientina** : principalmente cansaço, fraqueza, dor no estômago, azia, alterações na pele, cãibras, deficiência de ferro; casos mais graves incluem lúpus eritematoso sistêmico e distonias;  
Destaca-se ainda que:  
- todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) ao fármaco ou a qualquer  
- componente da formulação;  
- o risco da ocorrência de eventos adversos aumenta com a superdosagem;  
- caso tenha intenção de engravidar, devo informar imediatamente ao médico;  
- devido aos potenciais riscos relacionados ao tratamento da doença, tanto para o feto, quanto para mim, caso engravide  
enquanto faço uso de penicilamina e trientina, devo informar imediatamente ao médico, sem interromper o tratamento;  
- mesmo com o menor risco de danos ao feto, caso engravide enquanto faço uso de sulfato de zinco e piridoxina, devo  
- informar imediatamente ao médico, sem interromper o tratamento.  
Estou ciente de que o medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento,  
desde que assegurado o anonimato, conforme Lei Geral de Proteção de Dados Pessoais (LGPD):  
( ) Sim                                      ( ) Não  
Meu tratamento constará do (s) seguinte (s) medicamento (s):  
|( ) penicilamina    ( ) piridoxina|( ) sulfato de zinco|( ) trientina||
|---|---|---|---|
|Local:                                                             Data:||||
|Nome do paciente:||||
|Cartão Nacional de Saúde:||||
|Nome do responsável legal:||||
|Documento de identificação do responsável legal:||||
|_____________________________________<br>Assinatura do paciente ou do responsável legal||||
|Médico responsável:||CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico||||
|Data:____________________||||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Doença de Wilson contendo a descrição da metodologia de busca de evidências científicas. O documento tem como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde do Ministério da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos das áreas de hepatologia e neuropediatria, além de representantes de sociedades médicas e de pacientes.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
O processo iniciou-se com uma reunião para delimitação do escopo de atualização do referido documento, realizada virtualmente no dia 11 de julho de 2022. Durante a reunião, foram discutidas cada uma das seções do PCDT publicado por meio da Portaria Conjunta SAS-SCTIE/MS nº 9/2018. Também foram discutidas as condutas clínicas e tecnologias que poderiam ser priorizadas para elaboração de revisão sistemática das evidências com ou sem formulação de recomendações, sendo norteada por uma revisão prévia de diretrizes clínicas e de revisões sistemáticas recentemente publicadas.  
Na reunião, foi definido que o texto do PCDT deveria ser atualizado para incluir evidências recentes sobre a epidemiologia, critérios diagnósticos, tratamento e monitorização da doença. Não foram identificadas novas tecnologias com registro válido junto à Agência Nacional de Vigilância Sanitária (Anvisa) para o tratamento da doença de Wilson.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pelo Núcleo de Avaliação de Tecnologias em Saúde (NATS) Unifesp-Diadema (NATSUnifesp-D).

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **2.2 Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **3 . Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da doença de Wilson foi apresentada na 106ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 16 de maio de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **4 . Consulta pública** -->
A Consulta Pública nº 31/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da doença de Wilson, foi realizada entre os dias 26/07/2023 e 14/08/2023. Foram recebidas 54 contribuições, que podem ser verificadas em <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2023/cp_conitec_031_2023_protocolo_clinico_e.pdf.</u>

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **5.1 Métodos e resultados da busca:** -->
Não foram utilizadas restrições de data, idioma ou status da publicação (resumo ou texto completo). Todas as buscas foram conduzidas em 13/07/2022. As estratégias de busca para cada base estão descritas no **Quadro D** .  
**Quadro D** . Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes clínicas ou revisões sistemáticas com ou sem meta-análise sobre o cuidado clínico da Doença de Wilson  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
|MEDLINE<br>(via<br>Pubmed)|("hepatolenticular<br>degeneration"[MeSH<br>Terms]<br>OR<br>(Degeneration,<br>Hepatolenticular)<br>OR<br>(Pseudosclerosis) OR (Wilson Disease) OR (Wilson's Disease) OR (Wilsons Disease) OR (Cerebral<br>Pseudosclerosis) OR (Cerebral Pseudoscleroses) OR (Hepatocerebral Degeneration) OR (Copper Storage<br>Disease) OR (Copper Storage Diseases) OR (Progressive Lenticular Degeneration)) AND<br>(guideline[Publication Type] OR systematic review[Publication Type])|
|EMBASE|'Wilson disease'/exp OR (degeneratio hepato lenticularis) OR (hepatocerebral degeneration) OR<br>(hepatolenticular degeneration) OR (hepatolenticular syndrome) OR (morbus Wilson) OR (progressive<br>lenticular degeneration) OR (wilson degeneration) OR (wilson syndrome) OR (Wilsons disease) AND<br>[embase]/lim NOT ([embase]/lim AND [medline]/lim) AND ('practice guideline'/de OR 'systematic<br>review'/de)|
|Cochrane Library|#1 - MeSH descriptor: [Hepatolenticular Degeneration] explode all trees<br>#2 - (Pseudosclerosis) OR (Copper Storage Diseases) OR (Cerebral Pseudosclerosis) OR (Neurohepatic<br>Degeneration) OR (Neurohepatic Degenerations) OR (Westphal Strumpell Syndrome) OR<br>(Hepatocerebral Degeneration) OR (Storage Disease, Copper) OR (Wilson Diseases, Hepato-Neurologic)<br>OR (Cerebral Pseudoscleroses) OR (Hepatolenticular Degeneration Syndromes) OR (Degeneration,<br>Neurohepatic) OR (Hepato-Neurologic Wilson Diseases) OR (Hepatocerebral Degenerations) OR<br>(Wilson's Disease) OR (Diseases, Hepato-Neurologic Wilson) OR (Degeneration, Hepatocerebral) OR<br>(Kinnier Wilson Disease) OR (Pseudoscleroses, Cerebral) OR (Wilson Disease) OR (Syndromes,<br>Hepatolenticular Degeneration) OR (Hepato Neurologic Wilson Disease) OR (Wilsons Disease) OR<br>(Copper Storage Disease) OR (Hepatolenticular Degeneration Syndrome) OR (Degenerations,<br>Hepatocerebral) OR (Disease, Copper Storage) OR (Degeneration, Hepatolenticular) OR<br>(Pseudosclerosis, Cerebral) OR (Progressive Lenticular Degeneration) OR (Kinnier-Wilson Disease) OR<br>(Westphal-Strumpell Syndrome) OR (Kinnier-Wilson Diseases) OR (Storage Diseases, Copper) OR<br>(Degeneration Syndrome, Hepatolenticular) OR (Lenticular Degeneration, Progressive) OR (Hepato-<br>Neurologic Wilson Disease) OR (Westphal-Strumpell Syndromes) OR (Degenerations, Neurohepatic)|  
|**Bases de dados**|**Estratégia de busca**|
|---|---|
||OR (Degeneration Syndromes, Hepatolenticular) OR (Degeneration, Progressive Lenticular) OR<br>(Syndrome, Hepatolenticular Degeneration) OR (Wilson Disease, Hepato-Neurologic) OR (Diseases,<br>Kinnier-Wilson) OR (Diseases, Copper Storage) OR (Wilson Disease, Hepatic Form) OR (Hepatic Form<br>of Wilson Disease)<br>#3 - #1 OR #2|
|LILACS<br>(via|MH:"Hepatolenticular Degeneration" OR (Degeneração Hepatolenticular) OR (Hepatolenticular|
|BVS)|Degeneration) OR (Degeneración Hepatolenticular) OR (Degeneração Neuro-Hepática) OR<br>(Degeneração Neuroepática) OR (Doença de Wilson) OR (Pseudoesclerose Cerebral) OR<br>(Pseudosclerose) OR (Degeneration, Hepatolenticular) OR (Pseudosclerosis) OR (Wilson Disease) OR<br>(Wilson's Disease) OR (Wilsons Disease) OR (Cerebral Pseudosclerosis) OR (Cerebral<br>Pseudoscleroses) OR (Hepatocerebral Degeneration) OR (Copper Storage Disease) OR (Copper Storage<br>Diseases) OR (Progressive Lenticular Degeneration)|  
A elegibilidade dos estudos foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> . Na segunda etapa, realizou-se a leitura de texto completo, mantendo-se diretrizes clínicas ou revisões sistemáticas que abordassem os aspectos do cuidado da doença de Wilson. Diretrizes clínicas publicadas antes da versão do PCDT vigente à época foram excluídas.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes diagnosticados com doença de Wilson;  
- (b) Tipo de intervenção: Exames diagnósticos ou tratamento clínico;  
- (c) Tipos de estudos: Diretrizes clínicas ou revisões sistemáticas com ou sem meta-análise;  
- (d) Idioma: Português, inglês e espanhol.  
Com o intuito de atualizar o estudo, uma nova busca exploratória foi conduzida em 06/01/2023 para identificar diretrizes  
clínicas recém-publicadas/atualizadas sobre o cuidado da doença de Wilson, tendo sido identificada apenas um novo documento (Schilsky (2022).

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **5.2 Resultados da busca** -->
Inicialmente, foram identificadas 2.427 publicações. Após a exclusão das duplicatas (n = 89) e triagem pela leitura de títulos e resumos, 29 publicações foram selecionadas para a leitura do texto completo (Figura A). Os estudos excluídos são apresentados no **Quadro E** . Foram incluídas 12 publicações, sendo 8 revisões sistemáticas e 5 diretrizes clínicas internacionais. Ainda, a busca exploratória resultou na identificação de 1 diretriz recém-publicada. Assim, um total de 13 publicações foram incluídas para atualização do texto do PCDT de Doença de Wilson. Todas as publicações incluídas são listadas no **Quadro F.**  
**Figura A.** Fluxograma de seleção dos estudos incluídos sobre exames diagnósticos ou tratamento clínico da Doença de Wilson  
<!-- Start of picture text -->
Referéncias identificadas em:<br>Panited (re 478) Referéncias removidas antes do<br>Eines (Oo oee processo de selecao:<br>mbase (n= 255) ~ Duplicatas (n = 61)<br>Cochrane Library (n = 616)<br>LILACS (n = 1078)<br>Referencias avakadas por thulo Referéncias excluidas<br>(n= 2368) - Duplicatas (n = 2337)<br>Referéncias incluidas para Referéncias cujo texto completo<br>avaliacao por texto completo nao foi identificado<br>(n=28) (n= 1)<br>Referéncias avaliadas por texto Referéncias excluidas (n = 16)<br>completo - Fora do escopo do documento<br>(n= 28) (n= 12)<br>- Interven¢do (n = 2)<br>= Idioma (n = 1)<br>- Diretriz desatualizada (n = 1)<br>Busca exploratoria para<br>atualizacao<br>(n= 1)<br>Estudos incluidos na revisio<br>(n= 13)<br>Relatos dos estudos incluidos<br>(n= 13)<br><!-- End of picture text -->  
Fonte: Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/ Fonte: autoria própria  
**Quadro E** – Estudos excluídos na fase de elegibilidade por leitura de texto completo e motivo da exclusão  
|**Estudos excluídos**|**Motivo da exclusão**|
|---|---|
|Balijepalli C, Yan K, Gullapalli L, Barakat S, Chevrou-Severac H, Druyts E. Quality of Life in<br>Wilson’s Disease: A Systematic Literature Review. J Heal Econ Outcomes Res. 2021;8(2):105–13.|Fora do escopo|
|Xu J, Deng Q, Qin Q, Vgontzas AN, Basta M, Xie C, et al. Sleep disorders in Wilson disease: a<br>systematic review and meta-analysis. J Clin sleep Med  JCSM  Off Publ Am  Acad Sleep Med.<br>Fevereiro de 2020;16(2):219–30.|Fora do escopo|
|Xu MB, Rong PQ, Jin TY, Zhang PP, Liang HY, Zheng GQ. Chinese Herbal Medicine for Wilson’s<br>Disease: A Systematic Review and  Meta-Analysis. Vol. 10, Frontiers in pharmacology. 2019. p.<br>277|Intervenção<br>não<br>disponível para doença<br>de Wilson|
|Asabella AN, Cascini GL, Altini C, Paparella D, Notaristefano A, Rubini G. The Copper<br>Radioisotopes: A Systematic Review with Special Interest to 64Cu. Biomed Res Int. 2014;9.|Fora do escopo|
|Ben-Pazi H, Jaworowski S, Shalev RS. Cognitive and psychiatric phenotypes of movement<br>disorders in children: a  systematic review. Dev Med Child Neurol. Dezembro de<br>2011;53(12):1077–84.|Fora do escopo|
|Kłysz B, Bembenek J, Skowrońska M, Członkowska A, Kurkowska-Jastrzębska I. Autonomic<br>nervous system dysfunction in Wilson’s disease – A systematic literature review. Auton Neurosci<br>Basic Clin. Outubro de 2021;236.|Fora do escopo|
|Wang Y, Xie C long, Fu D lei, Lu L, Lin Y, Dong Q qian, et al. Clinical efficacy and safety of<br>Chinese herbal medicine for Wilson’s disease: a  systematic review of 9 randomized controlled<br>trials. Complement Ther Med. junho de 2012;20(3):143–54.|Intervenção<br>não<br>disponível para doença<br>de Wilson|
|Bembenek JP, Kurczych K, Członkowska A. TMS-induced motor evoked potentials in Wilson’s<br>disease: a systematic literature  review. Bioelectromagnetics. Abril de 2015;36(4):255–66.|Fora do escopo|
|Chenbhanich J, Thongprayoon C, Atsawarungruangkit A, Phupitakphol T, Cheungpasitporn W.<br>Osteoporosis and bone mineral density in patients with Wilson’s disease: a systematic review and<br>meta-analysis. Osteoporos Int. 2018;29(2):315–22.|Fora do escopo|
|Cao H, Chen Y, Fan JG. Wilson’s disease: from clinical practice to guidelines . Chinese Journal of<br>Hepatology [Internet]. 2014 [acesso em 22 de julho de 2022]; Disponível em:<br>https://www.semanticscholar.org/paper/%5BWilson%27s-disease%3A-from-clinical-practice-to-<br>Cao-Chen/68706769c7c34597b9c642bae533f115d64ffff5|Idioma|
|Rochel-Pérez A, Santos-Zaldivar K, Cuevas-Koh O, Azuela-Morales M, Méndez-Domínguez N.<br>Clinical presentation of Wilson’s disease in pediatric and adult patients: A systematic review. Mov<br>Disord. 2021;36:S512–3.|Fora do escopo|
|Ibrahim W. Coexistence of seizure with Wilson’s disease: a systematic review. Prog Neurol<br>Psychiatry. 2020;24(1):24–30|Fora do escopo|
|Ruiz-Lopez M, Abrahao A, Freitas ME, Trinh J, Fox S. Wilson disease: A systematic review and<br>meta-analysis in phenotype-genotype correlations. Mov Disord [Internet]. 2019;34(Suplemento<br>2):S192.<br>Disponível<br>em:<br>http://ovidsp.ovid.com/ovidweb.cgi?T=JS&PAGE=reference&D=emed20&NEWS=N&AN=6313<br>99889|Fora do escopo|  
|**Estudos excluídos**|**Motivo da exclusão**|
|---|---|
|Gao J, Brackley S, Mann JP. The global prevalence of Wilson disease from next-generation<br>sequencing data. Genet Med. 2019;21(5):1155–63.|Fora do escopo|
|Carta MG, Mura G, Sorbello O, Farina G, Demelia L. Quality of life and psychiatric symptoms in||
|wilson’s disease: The relevance of bipolar disorders. Clin Pract Epidemiol Ment Heal [Internet].<br>2012;8:102–9.<br>Disponível<br>em:|Fora do escopo|
|https://www.embase.com/search/results?subaction=viewrecord&id=L365938774&from=export||
|Brasil. Ministério da Saúde. Portaria no 1.318/SAS/MS -Aprova o Protocolo Clínico e Diretrizes<br>Terapêuticas da Doença de Wilson. 2013.|Diretriz desatualizada|  
**Quadro F –** Estudos incluídos para atualização do texto do PCDT sobre diagnóstico e tratamento clínico da doença de Wilson  
|**Estudos incluídos**|**Tipo de estudo**|
|---|---|
|Tang S, Bai L, Hou W, Hu Z, Chen X, Zhao J, et al. Comparison of the Effectiveness and Safety<br>of d-Penicillamine and Zinc Salt Treatment for Symptomatic Wilson Disease: A Systematic Review|Revisão sistemática|
|and<br>Meta‐Analysis.<br>Front<br>Pharmacol<br>[Internet].<br>2022;13.<br>Disponível<br>em:||
|https://www.embase.com/search/results?subaction=viewrecord&id=L2015456451&from=export||
|Ferenci P, Czlonkowska A, Stremmel W, Houwen R, Rosenberg W, Schilsky M, et al. EASL<br>Clinical Practice Guidelines: Wilson’s disease. J Hepatol [Internet]. 2012;56(3):671–85. Disponível<br>em: http://dx.doi.org/10.1016/j.jhep.2011.11.007|Diretriz clínica|
|Socha P, Janczyk W, Dhawan A, Baumann U, D’Antiga L, Tanner S, et al. Wilson’s Disease in<br>Children: A Position Paper by the Hepatology Committee of the European Society for Paediatric<br>Gastroenterology, Hepatology and Nutrition. Vol. 66, Journal of Pediatric Gastroenterology and<br>Nutrition. 2018. 334–344 p.|Diretriz clínica|
|Wiggelinkhuizen M, Tilanus MEC, Bollen CW, Houwen RHJ. Systematic review: clinical efficacy<br>of chelator agents and zinc in the initial  treatment of Wilson disease. Aliment Pharmacol Ther.<br>Maio de 2009;29(9):947–58.|Revisão sistemática|
|Garoufalia Z, Prodromidou A, Machairas N, Kostakis ID, Stamopoulos P, Zavras N, et al. Liver<br>Transplantation for Wilson’s Disease in Non-adult Patients: A Systematic  Review. Transplant<br>Proc. março de 2019;51(2):443–5.|Revisão sistemática|
|Bonnot O, Klünemann HH, Sedel F, Tordjman S, Cohen D, Walterfang M. Diagnostic and<br>treatment implications of psychosis secondary to treatable  metabolic disorders in adults: a<br>systematic review. Orphanet J Rare Dis. Abril de 2014;9:65.|Revisão sistemática|
|Appenzeller-Herzog C, Mathes T, Heeres MLS, Weiss KH, Houwen RHJ, Ewald H. Comparative<br>effectiveness of common therapies for Wilson disease: A systematic review and meta-analysis of<br>controlled studies. Liver Int. 2019;39(11):2136–52.|Revisão sistemática|
|Salman HM, Amin M, Syed J, Sarfraz Z, Sarfraz A, Sarfraz M, et al. Biochemical testing for the<br>diagnosis of Wilson’s disease: A systematic review. J Clin Lab Anal. 2022;36(2):1–8.|Revisão sistemática|  
|**Estudos incluídos**|**Tipo de estudo**|
|---|---|
|Litwin T, Bembenek J, Antos A, Przybyłkowski A, Skowrońska M, Kurkowska-Jastrzębska I, et||
|al. Liver transplantation as a treatment for Wilson’s disease with neurological presentation: a<br>systematic literature review. Acta Neurol Belg. Abril de 2022;122(2):505–18.|Revisão sistemática|
|Roberts EA, Schilsky ML. A practice guideline on Wilson disease. Hepatology. 2003;37(6):1475–<br>92.|Diretriz clínica|
|Nagral A, Sarma MS, Matthai J, Kukkle PL, Devarbhavi H, Sinha S, et al. Wilson’s Disease:<br>Clinical Practice Guidelines of the Indian National Association for Study of the Liver, the Indian<br>Society of Pediatric Gastroenterology, Hepatology and Nutrition, and the Movement Disorders|Diretriz clínica|
|Society of India. J Clin Exp Hepatol [Internet]. 2019;9(1):74–98. Disponível em:<br>https://www.embase.com/search/results?subaction=viewrecord&id=L2001156753&from=export||
|Chen JC, Chuang CH, Wang JD, Wang CW. Combination therapy using chelating agent and zinc<br>for Wilson’s disease. J Med Biol Eng [Internet]. 2015;35(6):697–708. Disponível em:<br>https://www.embase.com/search/results?subaction=viewrecord&id=L608132164&from=export|Revisão sistemática|
|Schilsky ML, Roberts EA, Bronstein JM, Dhawan A, Hamilton JP, Rivard AM, et al. A||
|Multidisciplinary Approach to the Diagnosis and Management of Wilson Disease: 2022 Practice<br>Guidance on Wilson Disease from the American Association for the Study of Liver Diseases.<br>Hepatology. 2022;(September):1–49.|Diretriz Clínica|

---

<!-- METADADOS: doenca: Doença de Wilson | secao: **APÊNDICE 2** -->
HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO  
|**Número do Relatório da**||**Tecnologias avaliadas**|**pela Conitec**|
|---|---|---|---|
|**diretriz clínica**<br>**(Conitec) ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação**<br>**ou**<br>**alteração do uso no**<br>**SUS**|**Não incorporação ou**<br>**não alteração no SUS**|
|Relatório<br>Técnico<br>nº<br>847/2023|Atualização do conteúdo, inclusão da<br>possibilidade de uso da trientina como<br>primeira opção de tratamento nos casos de<br>indisponibilidade da penicilamina|-|-|
|Portaria Conjunta SAS-<br>SCTIE/MS nº 09, de 27 de<br>março de 2018|Atualização do conteúdo|-|-|
|Portaria SAS/MS nº 1.318,<br>de 25 de novembro de 2013|Atualização do conteúdo|-|-|
|Portaria SAS/MS nº 848,<br>de 5 de dezembro de 2011|Atualização do conteúdo|-|-|
|Portaria SAS/MS nº 844,<br>de 31 de outubro de 2002|Primeira versão do Protocolo Clínico e<br>Diretrizes Terapêuticas da Doença de<br>Wilson|-|-|

---

