<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Atualiza o Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST).  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS  
EM SAÚDE, no uso de suas atribuições legais, resolve:  
Art. 1º Fica atualizado o Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST).  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico http://conitec.gov.br/.  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.  
Art. 4º Fica revogada a Portaria SCTIE/MS nº 42/2018 de 05 de outubro de 2018, publicada no Diário Oficial da União nº 194, de 08 de outubro de 2018, seção 1, página 88.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
1

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Os Protocolos Clínicos e Diretrizes Terapêuticas – PCDT são documentos que estabelecem os critérios para diagnóstico de infecções/doenças ou agravos à saúde; o tratamento preconizado com medicamentos e demais produtos apropriados; as posologias recomendadas; os mecanismos de controle clínico; e o acompanhamento e a verificação dos resultados terapêuticos a serem seguidos pelos profissionais de saúde e gestores do Sistema Único de Saúde – SUS. Os PCDT devem ser baseados em evidências científicas e considerar critérios de eficácia, segurança, efetividade e custo-efetividade das tecnologias recomendadas.  
O presente PCDT para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST) contém um capítulo sobre saúde sexual, que contempla a abordagem centrada na pessoa com vida sexual ativa. O texto tem por objetivo facilitar a conduta dos profissionais de saúde, de forma alinhada com as mais recentes ferramentas para orientações de prevenção.  
Também apresenta um capítulo sobre infecções entéricas e intestinais sexualmente transmissíveis, que aborda proctites, proctocolites e enterites. Tais agravos necessitam de cuidados especiais em relação à prática sexual e medidas de prevenção para evitar a transmissão.  
Quanto à sífilis, o algoritmo de decisão clínica para manejo da sífilis adquirida e da sífilis em gestantes (seção 5.11), que se encontra dividido em seis lâminas, foi atualizado com a síntese das recomendações para testar, diagnosticar, tratar, notificar e monitorar os casos de sífilis adquirida e em gestantes.  
A resistência da Neisseria gonorrhoeae é preocupação mundial<sup>1</sup> e consta na lista de “patógenos prioritários” resistentes a antibióticos da Organização Mundial da Saúde – OMS. No Brasil, a realidade não é diferente. A rede nacional de vigilância para monitorar a resistência antimicrobiana da _N. gonorrhoeae_ , o Projeto SenGono, constatou alta resistência desse patógeno à penicilina, à tetraciclina e ao ciprofloxacino. Diante disso, este PCDT-IST mantém a atual recomendação pela terapia dupla, baseada em ceftriaxona associada à azitromicina.  
Este PCDT-IST visa o alinhamento com os PCDT para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais, Manejo da Infecção pelo HIV em Adultos, Profilaxia Pós-Exposição de Risco à Infecção pelo HIV (PEP) e Profilaxia Pré- Exposição de Risco à Infecção pelo HIV (PrEP), sendo os respectivos conteúdos referenciados entre os documentos. Os citados PCDT estão disponíveis em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
É fundamental a contínua qualificação das informações epidemiológicas, para melhor conhecimento da magnitude e medir a tendência dos agravos para o planejamento de ações de vigilância, prevenção e controle. O sistema de saúde precisa estar preparado para implementar estratégias preventivas e de intervenção terapêutica imediata, garantindo a disponibilização de insumos, além da confidencialidade e da não discriminação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Saúde sexual é uma estratégia para a promoção da saúde e do desenvolvimento humano<sup>2</sup> e integra aspectos somáticos, emocionais, intelectuais e sociais do ser sexual, de maneiras que são positivamente enriquecedoras e que melhoram a personalidade, a comunicação, o prazer e o amor<sup>3</sup> .  
A sexualidade é definida como uma questão essencial do ser humano, que contempla sexo, identidades e papéis de gênero, orientação sexual, erotismo, prazer, intimidade e reprodução, sendo influenciada por uma relação de aspectos biológicos, psicológicos, socioeconômicos, políticos, culturais, legais, históricos, religiosos e espirituais<sup>4</sup> . Pode ser vivida e expressada por meio de pensamentos, fantasias, desejos,  
1  
crenças, atitudes, valores, comportamentos, práticas, papéis e relacionamentos, embora nem todas essas dimensões sejam experimentadas ou expressadas<sup>4</sup> .  
O direito à vida, à alimentação, à saúde, à moradia, à educação, ao afeto, aos direitos sexuais e aos direitos reprodutivos são considerados Direitos Humanos fundamentais. Respeitá-los é promover a vida em sociedade, sem discriminação de classe social, de cultura, de religião, de raça, de etnia, de profissão ou de orientação sexual. Para que exista a igualdade de direitos, é preciso respeito às diferenças, as quais não devem ter valores diferentes na sociedade. Não existe um direito mais importante que o outro. Para o pleno exercício da cidadania, é preciso a garantia do conjunto dos Direitos Humanos<sup>5</sup> .  
A escuta ativa e a promoção de um ambiente favorável ao diálogo sobre as práticas sexuais devem estar presentes na rotina dos serviços de saúde. Essa abordagem possibilita vínculos e facilita a adesão às tecnologias disponíveis ofertadas pelos profissionais de saúde. A escuta qualificada deve ser realizada com atenção e respeito, livre de preconceitos, possibilitando que a própria pessoa encontre soluções para suas questões<sup>5</sup> .  
Considerando essa percepção e preceito, faz-se necessária a abordagem do cuidado sexual, em que a oferta exclusiva de preservativos não é suficiente para garantir os diversos aspectos da saúde sexual. Assim, torna-se fundamental a ampliação da perspectiva para avaliação e gestão de risco, além das possibilidades que compõem a Prevenção Combinada.  
“Nós fazemos sexo para ter bebês, nós fazemos sexo para expressar nosso amor e afeto, nós fazemos sexo para sentir prazer e intimidade.”<sup>6</sup>

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A percepção dos riscos de adquirir uma IST varia de pessoa para pessoa, e sofre mudanças ao longo da vida. A prevenção dessas infecções impulsiona a continuidade de projetos pessoais, como relacionamentos, filhos(as) e vida sexual saudável. Para que a prevenção ocorra com maior eficácia, deve-se usufruir de todos os avanços científicos existentes. A seguir, será detalhado o que é Prevenção Combinada e sexo seguro como ferramentas colaboradoras para a gestão de risco de cada pessoa. É papel do profissional de saúde oferecer orientações centradas na pessoa com vida sexual ativa e em suas práticas, com o intuito de ajudá-la a reconhecer e minimizar seu risco.  
“O melhor sexo com a maior proteção possível!”<sup>7</sup>

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O termo “Prevenção Combinada” remete à conjugação de diferentes ações de prevenção às IST, ao HIV e às hepatites virais e seus fatores associados. Assim, sua definição está relacionada à combinação das três intervenções: biomédica, comportamental e estrutural (marcos legais), aplicadas ao âmbito individual e coletivo. A união dessas diferentes abordagens não encerra, contudo, todos os significados e possibilidades da Prevenção Combinada<sup>8</sup> .  
A mandala representa a combinação e a ideia de movimento de algumas das diferentes estratégias de prevenção, tendo sido inicialmente proposta para a infecção pelo HIV (Figura 1). Não há hierarquização entre as estratégias. Essa combinação de ações deve ser centrada nas pessoas, nos grupos a que pertencem e na sociedade em que estão inseridas, considerando as especificidades dos sujeitos e dos seus contextos.  
Os profissionais de saúde devem usar a mandala na orientação sobre prevenção às pessoas sob risco de IST, HIV e hepatites virais. Utiliza-se a mesma lógica empregada em relação à saúde reprodutiva. Quando uma pessoa/casal chega ao serviço de saúde em busca de anticoncepção, oferecem-se várias opções, como: anticoncepcional oral ou injetável, DIU com cobre, preservativo, vasectomia etc. Até métodos com menor eficácia podem ser utilizados pelas pessoas/casais a depender de sua indicação, como preservativos. Portanto, a pessoa/casal é quem identifica o método que melhor se enquadre à sua rotina, com auxílio do profissional de saúde. Da mesma maneira, pensa-se a Prevenção Combinada (Figura 1).  
2  
Figura 1 – Mandala da Prevenção Combinada  
<!-- Start of picture text -->
eeeetioe ee<br>$s =e<br>i#& a,VE & y<br>]<br>icy. (eg PRevencto : |<br>fate > We<br>xi “a<br>ON RedugSo <7<br>wea<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
_O melhor método de prevenção é aquele que o indivíduo escolhe, com auxílio do profissional de saúde, e que atende às suas necessidades sexuais e de proteção. Nenhuma intervenção de prevenção isolada se mostrou eficaz o suficiente para reduzir novas infecções._  
Para mais informações sobre as estratégias de Prevenção Combinada, consultar o documento “Prevenção Combinada do HIV: Bases conceituais para trabalhadores e gestores de saúde”<sup>8</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Geralmente, o termo “sexo seguro” é associado ao uso exclusivo de preservativos. Por mais que o uso de preservativos seja uma estratégia fundamental a ser sempre estimulada, ele possui limitações. Assim, outras medidas de prevenção são importantes e complementares para  
uma prática sexual segura, como as apresentadas a seguir:  
- Usar preservativo;  
- Imunizar para HAV, HBV e HPV;  
- Conhecer o status sorológico para HIV da(s) parceria(s) sexual(is);  
- Testar regularmente para HIV e outras IST;  
- Tratar todas as pessoas vivendo com HIV – PVHIV (Tratamento como Prevenção e I=I<sup>I</sup> );  
- Realizar exame preventivo de câncer de colo do útero (colpocitologia oncótica);  
- Realizar Profilaxia Pré-Exposição (PrEP), quando indicado;  
- Conhecer e ter acesso à anticoncepção e concepção;  
- Realizar Profilaxia Pós-Exposição (PEP), quando indicado.  
Nesse sentido, é essencial ampliar as possibilidades de prevenção e tornar o cenário mais completo e efetivo.  
_Sou trabalhadora do sexo vacinada para HBV e HPV. Meu exame preventivo de câncer de colo do útero está em dia. Uso PrEP regularmente e tento utilizar camisinha feminina ou masculina com os meus clientes sempre que possível. Uso gel lubrificante em todas as relações. Tenho DIU há três anos. No acompanhamento de PrEP,_ _<u>para pegar a medicação, realizo testagem para sífilis e HIV em cada</u>_  
I Indetectável = Intransmissível, ou seja, as PVHIV com carga viral indetectável e sustentada não transmitem o HIV por meio de relações sexuais.  
3  
_visita. Meu companheiro e eu pretendemos engravidar nos próximos meses*_  
*Texto fictício e meramente ilustrativo.  
Para mais informações sobre PEP e PrEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco à Infecção pelo HIV, IST e Hepatites Virais” – PCDT PEP<sup>9</sup> e o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição de Risco à Infecção pelo HIV” – PCDT PrEP<sup>10</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O preservativo masculino ou feminino deve ser oferecido às pessoas sexualmente ativas como um método eficaz para a redução do risco de transmissão do HIV e de outras IST, além de evitar gravidez.  
Deve-se ofertar e promover a utilização do preservativo feminino como uma possibilidade de prevenção que está sob o controle da mulher, pois lhe permite maior autonomia em relação ao seu corpo e às suas práticas preventivas. Esse insumo é essencial em situações nas quais existe a dificuldade de negociar o uso do preservativo masculino com as parcerias, contribuindo, assim, para o enfrentamento de vulnerabilidades e iniquidades entre as relações.  
_A oferta do preservativo masculino e feminino deve ser realizada sem restrições de quantidade de retirada e sem exigência de documentos de identificação. A distribuição deve ser feita como parte da rotina de atendimento, conforme a necessidade de cada pessoa._  
As orientações adequadas para a conservação e o uso correto e regular dos preservativos masculino e feminino devem fazer parte da abordagem realizada pelos(as) trabalhadores(as) da saúde.  
O uso regular de preservativos enseja o aperfeiçoamento da técnica de utilização, reduzindo a frequência de ruptura e escape e aumentando sua eficácia. Esses insumos devem ser promovidos e disponibilizados como parte da rotina de atendimento. As orientações adequadas para uso e conservação dos preservativos masculino e feminino estão nos Quadros 1, 2 e 3.  
**Quadro 1 – Cuidados com o preservativo masculino**  
- Armazená-lo longe do calor, observando a integridade da embalagem e o prazo de validade.  
- Deve ser colocado antes da penetração, durante a ereção peniana.  
- Apertar a extremidade do preservativo entre os dedos durante a colocação, retirando todo o ar do seu interior.  
- Ainda segurando a ponta do preservativo, desenrolá-lo até a base do pênis.  
- Devem-se usar apenas lubrificantes de base aquosa (gel lubrificante), pois a utilização de lubrificantes oleosos (como vaselina ou óleos alimentares) danifica o látex, ocasionando sua ruptura. O gel lubrificante facilita o sexo anal e reduz as chances de lesão.  
- Em caso de ruptura, o preservativo deve ser substituído imediatamente.  
- Após a ejaculação, retirar o pênis ainda ereto, segurando o preservativo pela base para que não haja vazamento de esperma.  
- O preservativo não pode ser reutilizado e deve ser descartado no lixo (não no vaso sanitário) após o uso.  
- Fonte: DCCI/SVS/MS.  
**Quadro 2 – Fatores que contribuem para ruptura ou escape do preservativo masculino**  
- Más condições de armazenamento.  
- Não observação do prazo de validade.  
- Danificação da embalagem.  
- Lubrificação vaginal insuficiente.  
- Sexo anal sem lubrificação adequada.  
- Uso de lubrificantes oleosos.  
- Presença de ar e/ou ausência de espaço para recolher o esperma na extremidade do preservativo.  
- Tamanho inadequado em relação ao pênis.  
- Perda de ereção durante o ato sexual.  
- Contração da musculatura vaginal durante a retirada do pênis.  
- Retirada do pênis sem que se segure firmemente a base do preservativo.  
4  
- Uso de dois preservativos (devido à fricção que ocorre entre ambos).  
- Uso de um mesmo preservativo durante coito prolongado.  
Fonte: DCCI/SVS/MS.  
**Quadro 3 – Cuidados com o preservativo feminino**  
- Armazená-lo longe do calor, observando a integridade da embalagem e o prazo de validade.  
- Não deve ser utilizado juntamente com o preservativo masculino.  
- Ao contrário do preservativo masculino, o feminino pode ser colocado até antes da relação e retirado com tranquilidade após o coito, de preferência antes de a mulher levantar-se, para evitar que o esperma escorra do interior do preservativo.  
- O preservativo feminino já vem lubrificado; portanto, não é necessário usar lubrificantes.  
- Para colocá-lo corretamente, a mulher deve encontrar uma posição confortável (em pé com um dos pés em cima de uma cadeira, sentada com os joelhos afastados, agachada ou deitada).  
- Apertar e introduzir na vagina o anel móvel do preservativo. Com o dedo indicador, empurrá-lo o mais profundamente possível, para alcançar o colo do útero; a argola fixa (externa) deve ficar aproximadamente três centímetros para fora da vagina. Durante a penetração, guiar o pênis para o centro do anel externo.  
- Um novo preservativo deve ser utilizado a cada nova relação.  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Observa-se que os pais/responsáveis e a equipe de saúde, comumente, tendem a não abordar aspectos determinantes da saúde sexual dos adolescentes, devido à negação do desejo sexual do jovem e ao incentivo ao prolongamento da infância.  
Dados do Instituto Brasileiro de Geografia e Estatística – IBGE demonstram o início precoce da vida sexual, com pouco uso de preservativos (Quadro 4). Portanto, é essencial destacar que a prática sexual faz parte dessa fase da vida, e que ela pode ser desejada e vivenciada sem culpas, com informação, comunicação, prevenção e exercício do livre arbítrio<sup>11</sup> .  
**Quadro 4 – Dados de iniciação sexual e uso de preservativo em adolescentes segundo questionário IBGE**  
- **Iniciação sexual** : dos escolares de 13 a 17 anos do sexo masculino, 36% declararam já ter se relacionado sexualmente alguma vez, enquanto entre os do sexo feminino dessa mesma faixa etária o percentual foi de 19,5%.  
- **Uso de preservativo** : dos 27,5% dos escolares de 13 a 17 anos que declararam já ter tido relação sexual alguma vez na vida, 61,2% responderam ter usado preservativo na primeira relação.  
Fonte: Brasil (2016)<sup>12</sup> .  
Adolescentes e jovens constituem um grupo populacional que exige novos modos de produzir saúde. Na adolescência, a sexualidade se manifesta em diferentes e surpreendentes sensações corporais, em desejos ainda desconhecidos e em novas necessidades de relacionamento interpessoal, preocupação e curiosidade. Nesse contexto, valores, atitudes, hábitos e comportamentos estão em processo de formação e solidificação e, em determinadas conjunturas, podem tornar esse segmento populacional vulnerável.  
A maneira como os adolescentes expressam e vivem a sexualidade é influenciada por vários fatores, como a qualidade de suas relações emocionais e afetivas, vividas com pessoas significativas na infância e na fase atual; a integração com seus pares; as transformações físicas, psicológicas, cognitivas e sociais em decorrência do crescimento e desenvolvimento; o início da capacidade reprodutiva; as crenças, normas morais, mitos e tabus; e as tradições da família e da sociedade na qual estão inseridos<sup>13</sup> .  
A abordagem ao adolescente deve respeitar sua autonomia, em conformidade com os princípios da confidencialidade e da privacidade, indispensáveis para estabelecer uma relação de confiança e respeito com os profissionais de saúde.  
A temática da sexualidade deve estar presente nas ações de informação, comunicação e educação em saúde para adolescentes, de preferência antes que aconteça a primeira relação sexual, devendo ser abordada de forma gradual e na perspectiva do cuidado integral. De acordo com cada fase da vida, com a identificação de riscos e com as práticas sexuais, podem ser oferecidas diferentes tecnologias associadas à Prevenção Combinada das IST, do HIV/aids e das hepatites virais<sup>11</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
As relações sexuais na gravidez não oferecem risco à gestação. A atividade sexual durante o terceiro trimestre da gravidez não está  
5  
relacionada a aumento de prematuridade e mortalidade perinatal. Entretanto, é importante considerar a possibilidade de contrair IST que prejudiquem a gestação ou que possam ser transmitidas verticalmente, causando aumento da morbimortalidade tanto para a gestante quanto para o concepto.  
_A equipe de saúde deve abordar questões relacionadas à saúde sexual das gestantes e suas parcerias sexuais durante o pré-natal, o parto e o puerpério, especificamente no que tange à identificação de práticas sexuais e à oferta de Prevenção Combinada_<sup>11</sup> _._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O rastreamento é a realização de testes diagnósticos em pessoas assintomáticas a fim de estabelecer o diagnóstico precoce (prevenção secundária), com o objetivo de reduzir a morbimortalidade do agravo rastreado<sup>14,15</sup> .  
Diferentemente de outros rastreamentos, como a mamografia para câncer de mama, o rastreamento das IST não identifica apenas uma pessoa; ao contrário, estará sempre ligado a uma rede de transmissão. Quando não identificado e tratado o agravo na(s) parceria(s), este se perpetua na comunidade e expõe o indivíduo à reinfecção, caso não se estabeleça a adesão ao uso de preservativos.  
O Quadro 5 descreve o rastreamento de IST recomendado por subgrupo populacional, respeitando o limite estabelecido pela prevenção quaternária<sup>16</sup> . Os dois principais fatores de risco para IST são práticas sexuais sem uso de preservativos e idade mais baixa<sup>17,18</sup> . Em relação à sífilis, por exemplo, as notificações no Brasil vêm apresentando tendência de aumento na população mais jovem, de 13 a 29 anos<sup>19</sup> . Por esse motivo, foram incluídas no rastreamento anual as pessoas de até 30 anos de idade com vida sexualmente ativa. Caso a pessoa de 30 anos ou mais pertença a algum outro subgrupo populacional, deve-se optar pelo que for mais representativo.  
Para o restante da população, a testagem para sífilis e demais IST não inclusa no Quadro 5 dependerá da avaliação de risco, devendo fazer parte da abordagem de gerenciamento de risco.  
**Quadro 5 – Rastreamento de IST**  
|**QUEM**|||**QUANDO**||
|---|---|---|---|---|
||**HIV**<sup>**a**</sup>|**Sífilis**<sup>**b**</sup>|**Clamídia egonococo**<sup>**c**</sup>|**Hepatites B**<sup>**d**</sup>**e C**<sup>**e**</sup>|
|**Adolescentes e jovens**<br>**(≤ 30 anos)**|Anu|al|Ver frequência conforme o<br>oupráti|utros subgrupos populacionais<br>cas sexuais|
|**Gestantes**|Na primeira consulta do<br>no 1º trimestre da gestaç<br>No início do 3º trimestre<br>No momento do parto, i<br>exames anteriores.<br>Em caso de aborto/natim<br>independentemente de e|pré-natal (idealmente,<br>ão);<br>(28ª semana);<br>ndependentemente de<br>orto, testar para sífilis,<br>xames anteriores.|Na primeira consulta do<br>pré-natal<br>(Gestantes ≤30 anos)|Hepatite B: na primeira<br>consulta do pré-natal<br>(idealmente, no primeiro<br>trimestre)<sup>f</sup><br>Hepatite C: na primeira<br>consulta do pré-natal|
|**Gays e HSH**<br>**Profissionais do sexo**<br>**Travestis/**<br>**Transexuais**|Seme|stral|Ver frequência conforme<br>outros subgrupos<br>populacionais ou práticas|Semestral a anual|
|**Pessoas que fazem uso**<br>**abusivo de álcool e outras**<br>**drogas**|||<br>sexuais||
|**Pessoas com diagnóstico de**<br>**IST **|No momento do diagnó<br>após o diagnó|stico e 4 a 6 semanas<br>stico de IST|No momento do<br>diagnóstico|No momento do<br>diagnóstico|
|**Pessoas com diagnóstico de**<br>**hepatites virais**|No momento do<br>diagnóstico|–|–|–|
|**Pessoas com diagnóstico de**<br>**tuberculose**|No momento do<br>diagnóstico|–|–|–|
|**PVHIV**|–|Semestral|No momento do<br>diagnóstico|Semestral a anual|
|**Pessoas com prática sexual**<br>**anal receptiva (passiva)**<br>**sem uso de preservativos**||Semestral||Semestral a anual|
|**Pessoas privadas de**<br>**liberdade**|Anual|Semestral|–|Semestral a anual|  
6  
|**Violência sexual**|No atendimento<br>inicial; 4 a 6 semanas<br>após exposição e 3<br>meses após a<br>exposição|No atendimento in<br>e|icial e 4 a 6 semanas após a<br>xposição|No atendimento inicial, 3 e<br>6 meses após a exposição|
|---|---|---|---|---|
|**Pessoas em uso de PrEP**|Em cada visita ao<br>serviço|Trimestral|Semestral|Trimestral|
|**Pessoas com indicação de**<br>**PEP**|No atendimento<br>inicial; 4 a 6 semanas<br>após exposição e 3<br>meses após a<br>exposição|No atendimento<br>inicial e 4 a 6<br>semanas após a<br>exposição|No atendimento inicial e 4<br>a 6 semanas após<br>exposição (exceto nos<br>casos de acidente com<br>material biológico)|No atendimento inicial e 6<br>meses após exposição|  
Fonte: DCCI/SVS/MS. a HIV: preferencialmente com teste rápido. b Sífilis: preferencialmente com teste rápido para sífilis.  
c Clamídia e gonococo: detecção de clamídia e gonococo por biologia molecular. Pesquisa de acordo com a prática sexual: urina (uretral), amostras endocervicais, secreção genital. Para amostras extragenitais (anais e faríngeas), utilizar testes com validação para tais sítios de coleta.  
d Hepatite B: preferencialmente com teste rápido (TR). Realizar o rastreamento conforme os intervalos e orientações da tabela em indivíduos suscetíveis ou não respondedores após 2 esquemas vacinais completos – quando indicado anti-HBs após a vacinação. Pessoa suscetível é aquela que não possui registro de esquema vacinal completo com 3 doses aplicadas adequadamente (ou que não apresentou soroconversão para anti-HBs quando indicado) e que apresenta HBsAg (ou TR) não reagente. Para mais informações em relação a grupos que necessitam de esquemas com 4 aplicações com o dobro da dose indicada para a idade ou de solicitação de anti-HBs para confirmar soroproteção pósvacinal, consultar o PCDT para Hepatite B e Coinfecções.  
e Hepatite C: preferencialmente com teste rápido.  
f Caso a gestante não tenha realizado rastreio no pré-natal, proceder à testagem rápida para hepatite B no momento do parto. Vacina para hepatite B é segura durante a gestação em qualquer idade gestacional e mulheres suscetíveis devem ser vacinadas.  
O sítio de rastreamento para clamídia e gonococo irá depender da prática sexual realizada pela pessoa. Por exemplo: sexo oral sem preservativo – coleta de material de orofaringe; sexo anal receptivo sem preservativo – coleta de _swab_ anal; sexo vaginal receptivo sem preservativo – coleta de material genital; sexo insertivo sem preservativo – coleta de material uretral.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A imunização para HPV é realizada por meio de vacina quadrivalente (tipos 6, 11, 16 e 18), estando indicada para meninas de 9 a 14 anos e meninos de 11 a 14 anos. O esquema é composto de duas doses, com intervalo de seis meses.  
Para PVHIV, pessoas transplantadas de órgãos sólidos ou medula óssea e pacientes oncológicos, a faixa etária indicada para imunização é de 9 a 26 anos, sendo o esquema de vacinação composto por três doses (0, 2 e 6 meses)<sup>9</sup> . Para mais informações, consultar o “Informe técnico da ampliação da oferta das vacinas papilomavírus humano 6, 11, 16 e 18 (recombinante)”<sup>20</sup> e a página do Ministério da Saúde <u>(http://portalms.saude.gov.br/). Mesmo após a vacinação, o exame preventivo de colo uterino segue indicado, conforme as diretrizes</u> brasileiras para o rastreamento do câncer do colo do útero<sup>21</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
No Brasil, desde 2016, a vacinação contra a hepatite B está indicada para todas as faixas etárias. Três doses de vacina contra a hepatite B induzem títulos protetores de anticorpos (anti-HBs maior ou igual a 10 UI/mL) em mais de 90% dos adultos e dos jovens sadios, e em mais de 95% dos lactentes, das crianças e dos adolescentes.  
_A vacinação é a principal medida de prevenção contra a hepatite B, sendo extremamente eficaz e segura. A gestação e a lactação não representam contraindicações para imunização._  
Se possível, a primeira dose da vacina deve ser administrada no momento do primeiro atendimento. Para mais informações, consultar a página do Ministério da Saúde (http://portalms.saude.gov.br/).  
7

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O principal mecanismo de transmissão do vírus da hepatite A (HAV) é o fecal-oral. A transmissão sexual desse vírus é infrequente. No entanto, recentemente, diversos casos de transmissão sexual do vírus da hepatite A foram confirmados em países da Europa e no Brasil<sup>22</sup> . A maioria dos casos parece ocorrer entre homens que fazem sexo com outros homens, embora essa forma de transmissão também tenha sido observada entre mulheres. A magnitude da transmissão da hepatite A por via sexual é provavelmente subestimada<sup>23–26</sup> .  
A transmissão sexual do HAV provavelmente limita o benefício da prevenção por meio do uso exclusivo de preservativos, devendo-se complementar a prevenção com outras medidas, como a higienização das mãos, genitália, períneo e região anal antes e depois do ato sexual; o uso de barreiras de látex durante o sexo oral-anal e de luvas de látex para dedilhado ou “fisting”; a higienização de vibradores e outros acessórios/ brinquedos eróticos.  
_A vacinação se constitui como a principal medida de prevenção contra a hepatite A, sendo extremamente eficaz e segura._  
Se possível, deve-se verificar a susceptibilidade do paciente exposto por meio da pesquisa de exame sorológico específico (anti-HAV IgM e anti-HAV IgG). A presença de anti-HAV IgM reagente sugere episódio agudo de infecção por esse vírus. Já a presença de anti-HAV IgG reagente demonstra imunidade definitiva da pessoa exposta e, portanto, nenhuma medida adicional se faz necessária<sup>9</sup> .  
Caso a pesquisa dos anticorpos seja não reagente, deve-se observar a indicação de vacinação da pessoa exposta, obedecendo-se aos critérios de vacinação do Programa Nacional de Imunizações – PNI, disponíveis na página do Ministério da Saúde (http://portalms.saude.gov.br/) e do “Manual dos Centros de Referência para Imunobiológicos Especiais” – CRIE<sup>27</sup> .  
Em 7 de junho de 2018, foi publicada a Nota Informativa nº 10/2018-COVIG/CGVP/ DCCI/SVS/MS<sup>28</sup> , que amplia a indicação do uso da vacina de hepatite A para pessoas que tenham prática sexual com contato oral-anal (com priorização de gays e HSH). Inicialmente, essa ampliação está prevista para o município de São Paulo, devido ao aumento do número de casos, dos quais alguns evoluíram para hepatite fulminante e óbito. A vacinação está disponível em Centros de Testagem e Aconselhamento – CTA e nos serviços que ofertam PEP, PrEP e/ou atendimento para IST, e que tenham sala de vacina.  
Além disso, atualmente, no SUS, a vacina para hepatite A está indicada para crianças de 15 meses a cinco anos incompletos (quatro anos, 11 meses e 29 dias), e nos CRIE, para pessoas de qualquer idade que apresentem as seguintes situações: hepatopatias crônicas de qualquer etiologia (incluindo os portadores do HCV e do HBV), coagulopatias, PVHIV, portadores de quaisquer doenças imunossupressoras ou doenças de depósito, fibrose cística, trissomias, candidatos a transplante de órgãos, doadores de órgãos cadastrados em programas de transplantes e pessoas com hemoglobinopatias. Nesse contexto, toda a população HSH vivendo com HIV deve ser vacinada.  
Para mais informações, consultar a página do Ministério da Saúde (http://portalms. saude.gov.br/).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Somente por meio de uma avaliação adequada é que se pode identificar o risco de uma pessoa para IST. Hipóteses e inferências sobre o risco de IST podem ser imprecisas. O investimento exclusivo em diagnósticos e tratamentos não será suficiente se não falarmos de sexo. É necessário conhecer a temática para conversar e reduzir o estigma relacionado às práticas sexuais e às IST.  
A saúde sexual é parte fundamental da avaliação geral de saúde de qualquer pessoa. Conhecer a história sexual dos usuários é fundamental para uma abordagem centrada na pessoa, permitindo assim conhecê-la como um todo<sup>29</sup> . Essa investigação deve ser estruturada para identificar os fatores de risco relacionados à saúde sexual, reconhecendo práticas e comportamentos sexuais e também oportunidades para intervenções breves de mudança de comportamento<sup>30</sup> .  
Muitas vezes, os profissionais de saúde e os pacientes não abordam esse tema nas consultas. Geralmente, há uma tendência em subestimar a necessidade que os usuários têm de externar preocupações relacionadas à sua saúde sexual. Por outro lado, os pacientes querem discutir sua saúde sexual, querem que o profissional aborde essa dimensão de sua vida. É importante que o profissional desenvolva uma rotina de perguntar a todos os seus pacientes adultos e adolescentes questões sobre sexualidade, ajudando a diminuir o preconceito ligado ao diálogo sobre sexo e práticas sexuais<sup>31</sup> .  
8  
Para a anamnese de hábitos sexuais e de risco, é preciso primeiro ganhar a confiança do paciente. Um estilo de abordagem mais direto pode funcionar para alguns; porém, é preferível que o profissional de saúde faça uma aproximação mais gradual, com o objetivo de construir uma relação de confiança, normalizar as perguntas e o assunto, e avançar do geral para o específico<sup>32</sup> .  
Nesse sentido, recomenda-se avisar ao paciente que as perguntas que você está fazendo são feitas para todos os pacientes adultos, independentemente de idade ou de estado civil. Também é importante enfatizar o caráter sigiloso da consulta. Igualmente necessária é a escuta respeitosa sobre as diferentes profissões de cada pessoa, visto que estas também podem contribuir para suas vulnerabilizações, principalmente em se tratando da prostituição.  
Ao iniciar o assunto de forma gradual, podem-se utilizar metáforas, mas será necessário avançar para uma comunicação transparente e clara, abordando os pontos mais importantes para a avaliação de risco. Nesse segundo momento, ou para usuários com quem o profissional já estabeleceu uma relação de confiança prévia, para os quais uma abordagem inicial mais direta pode funcionar, algumas perguntas abertas e diretas podem ser usadas para uma comunicação mais transparente.  
No Quadro 6, seguem as orientações gerais para uma abordagem respeitosa e eficaz sobre a saúde sexual.  
**Quadro 6 – História sexual: orientações gerais**  
|**ORIENTAÇÕES GERAIS**|
|---|
|Estabeleça uma rotina de perguntas a todos os usuários sobre sexualidade (diálogo sobre sexo e práticas sexuais).|
|Desenvolva seu próprio estilo.|
|Evite julgamentos prévios. Não assuma conceitos prontos (a menos que você pergunte, não há como conhecer a orientação sexual, os<br>comportamentos, práticas ou a identidade de gênero de uma pessoa).|
|Respeite os limites do paciente (linguagem não verbal). Reformule sua pergunta ou explique brevemente por que você está fazendo o<br>questionamento se o paciente parecer ofendido ou relutante em responder.|
|Observe suas áreas de desconforto. Monitore e contenha as suas próprias reações (linguagem não verbal).|
|Avise que as mesmas perguntas são feitas a todas as pessoas (procedimento protocolar), independentemente de idade ou de estado civil.|
|Use termos neutros e inclusivos (por exemplo, “parceria” ao invés de “namorado”, “namorada”, “marido”, “esposa”) e faça as perguntas de<br>forma não julgadora.|
|Quando estiver atendendo uma pessoa trans, pergunte como esta prefere ser chamada ou identificada. Dê suporte à identidade de gênero atual<br>do paciente, mesmo que sua anatomia não corresponda a essa identidade.|
|Fonte: DCCI/SVS/MS.|  
No Quadro 7, seguem perguntas específicas que abordam os pontos mais importantes relacionados à vulnerabilidade em relação às IST. A partir das respostas, é possível ao profissional fazer uma avaliação de risco adequada e realizar o gerenciamento de risco junto com o paciente.  
**Quadro 7 – História sexual: perguntas específicas para avaliação de risco**  
||**PERGUNTAS ESPECÍFICAS – ROTINA DE CONSULTA**|
|---|---|
|**Saúde sexual**|“Vou fazer algumas perguntas sobre sua saúde sexual. Uma vez que a saúde sexual é muito importante para a saúde<br>geral, sempre pergunto aos pacientes sobre isso. Se está tudo bem para você, eu vou fazer algumas perguntas sobre<br>questões sexuais agora. Antes de começar, você tem dúvidas ou alguma preocupação em relação à sua saúde sexual<br>que gostaria de discutir?”|
|**Identificação**|“O que você se considera ser (orientação sexual)? Homossexual (gay, lésbica), heterossexual, bissexual, outra, não<br>sabe?”|
||“Qual é a sua identidade de gênero? Homem, mulher, homem trans, mulher trans, travesti, outra?”|
||“Qual sexo você foi designado no nascimento, como está registrado na sua certidão de nascimento?”|
|**Parcerias**|“Você já teve relações sexuais?”|
||Se sim: “Quantas parcerias sexuais você teve no último ano?” (ou em outro período de tempo, de acordo com a<br>avaliação clínica a ser realizada na consulta)|
||“Você teve relações sexuais com homens, mulheres ou ambos?”|
||“Nos últimos três meses, você teve relações sexuais com alguém que não conhecia ou acabou de conhecer?”|
||“Você já foi forçado(a) ou pressionado(a) a ter relações sexuais?”|  
9  
|**Práticas sexuais**|“Nos últimos três meses, que tipos de sexo você teve? Anal? Vaginal? Oral? Receptivo (passivo), insertivo (ativo),<br>ambos (passivo e ativo)?”|
|---|---|
||“Você ou sua parceria usou álcool ou drogas quando você fez sexo?”|
||“Você já trocou sexo por drogas ou dinheiro?”|
|**História de IST**|“Você já teve uma IST?” Se sim: “Qual? Onde foi a infecção? Quando foi? Você tratou? Sua parceria se tratou?”|
||“Você já foi testado(a) para o HIV, sífilis, hepatite B/C?” Se sim: “Há quanto tempo foi esse teste? Qual foi o<br>resultado?”|
|**Proteção**|“O que você faz para se proteger das IST, incluindo o HIV?”|
||“Quando você usa essa proteção? Com quais parcerias?”|
||“Você foi vacinado contra hepatite B? Hepatite A? HPV?”|
|**Planejamento**<br>|“Você tem algum desejo de ter (mais) filhos(as)?”|
|**familiar**|Se sim: “Quantos filhos(as) você gostaria de ter? Quando você gostaria de ter um filho? O que você e sua parceria<br>estão fazendo para evitar a gravidez até este momento?”|
||Se não: “Você está fazendo alguma coisa para evitar a gravidez?” (Certifique-se de fazer as mesmas perguntas<br>também a pacientes trans que ainda possuem órgãos reprodutivos femininos)|
|Fonte: adaptado de|Carrió (2012)<sup>32</sup>; Workowski; Bolan (2015)<sup>33</sup>; Nusbaum; Hamilton (2002)<sup>31</sup>.|  
No Quadro 8, apresentam-se orientações específicas para a abordagem na adolescência, a fim de identificar tanto o despertar sexual quanto vulnerabilidades que favorecem o risco de IST.  
**Quadro 8 – História sexual: orientações para abordagem na adolescência**  
**PERGUNTAS A SEREM FEITAS UMA VEZ POR ANO A TODOS OS SEUS PACIENTES ADOLESCENTES** Explique ao pai/mãe/cuidador que você gostaria de ter uma parte de cada consulta sozinho com o(a) adolescente. O tempo sozinho com os adolescentes é fundamental para discutir tópicos sensíveis, como a saúde sexual, e os prepara para assumir a responsabilidade pelos seus cuidados de saúde. Certifique-se de que pai/mãe/cuidador será convidado de volta para completar a consulta. Comece com tópicos menos ameaçadores, como escola ou atividades cotidianas, antes de avançar para tópicos mais sensíveis, como drogas e sexualidade. Faça perguntas abertas para facilitar a conversação. “Eu vou fazer algumas perguntas que eu pergunto a todos os meus pacientes. Essa informação é importante e me ajudará saber como melhor oferecer o cuidado para você. Suas respostas serão mantidas confidenciais; então, fale livremente. Pode ser que algumas vezes talvez seja necessário compartilhar essa informação com outras pessoas”. “Quais perguntas você tem sobre seu corpo e/ou sobre sexo?” “O corpo muda muito durante a adolescência e, embora isso seja normal, também pode ser confuso. Ás vezes, pode acontecer da pessoa sentir que é menina, mas o corpo mudar para o corpo de menino, ou vice-versa, ou mesmo outra coisa diferente. Como isso essa mudança do corpo está acontecendo para você?” “Como você descreveria sua orientação sexual?” “Você já teve relações sexuais com alguém? Por sexo, quero dizer sexo vaginal, oral ou anal”. Fonte: adaptado de Carrió (2012)<sup>32</sup> ; Workowski; Bolan (2015)<sup>33</sup> ; Nusbaum; Hamilton (2002)<sup>31</sup> .  
A partir do resultado da história sexual, é possível realizar uma adequada avaliação do estilo de vida do usuário. Nesse momento, é fundamental olhar para a mandala de Prevenção Combinada e, junto com o usuário, pactuar ações de prevenção individualizadas. **A abordagem da história sexual deve ser repetida de acordo com o perfil do usuário e a pactuação das ações a cada consulta.**

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A anamnese, a identificação das diferentes vulnerabilidades e o exame físico são importantes elementos na abordagem das pessoas com IST. Durante o exame físico, quando indicado, procede-se à coleta de material biológico para exame laboratorial. Sempre que disponíveis, devem ser realizados exames para:  
10  
- Gonorreia  
- Clamídia  
- Sífilis  
- HIV  
- Hepatite B  
- Hepatite C  
As amostras para os exames rápidos ou laboratoriais indicados devem ser colhidas no momento da primeira consulta; caso os resultados não estejam disponíveis imediatamente, a conduta terapêutica não deve ser postergada até a entrega destes. A consulta clínica se completa com a prescrição e orientações de tratamento, além da definição de estratégia para seguimento e atenção às parcerias sexuais e o acesso aos insumos de prevenção, como parte da rotina de atendimento.  
É necessário estabelecer uma relação de confiança entre o profissional de saúde e a pessoa com IST para garantir a qualidade do atendimento, a adesão ao tratamento e a retenção no serviço. Para tanto, o profissional deve promover informação/educação em saúde e assegurar um ambiente de privacidade, tempo e disponibilidade para o diálogo, garantindo a confidencialidade das informações. Para saber mais sobre gerenciamento de risco e Prevenção Combinada, consultar a seção 2.1 e, para indicação de imunizações, a seção 2.5.  
O modelo conceitual representado no Quadro 9 tem sido útil para identificar e quantificar as “perdas” a cada passo da atenção em IST, determinando a proporção de pessoas infectadas que perdem a oportunidade de tratamento nas etapas sucessivas da infecção até a possível cura.  
**Quadro 9 – Barreira ao controle de IST: perdas de seguimento em diferentes níveis entre a infecção e a cura**  
||**PESSOAS COM IST**|
|---|---|
|Sintomáticas|Assintomáticas|
|Buscam atendimento|Não buscam atendimento|
|Diagnóstico adequado|Sem diagnóstico|
|Tratamento correto|Sem tratamento correto|
|Tratamento completo|Não completam tratamento|
|Tratamento das<br>parcerias|Parcerias sexuais não tratadas|
|Cura|Persistência da cadeia de transmissão|  
Fonte: adaptado de WHO (2005)<sup>34</sup> .  
Muitas pessoas com IST não buscam tratamento porque são assintomáticas (a maioria) ou têm sinais e sintomas leves e não percebem as alterações. As pessoas sintomáticas podem preferir tratar-se por conta própria ou procurar tratamento em farmácias ou junto a curandeiros tradicionais. Mesmo aqueles que buscam atendimento na unidade de saúde podem não ter uma IST corretamente diagnosticada ou tratada. No final, apenas uma pequena proporção de pessoas com IST pode chegar à cura e evitar a reinfecção ou a infecção de sua parceira sexual. A duração e a transmissibilidade da infecção são maiores quando o acesso ao tratamento é menor. A vigilância epidemiológica e o manejo dos contatos sexuais também são estratégias para alcançar e tratar todas as pessoas infectadas.  
Todas essas intervenções devem ser acompanhadas pela promoção da busca adequada aos serviços de saúde. Os demais passos estão ligados ao acesso a serviços de qualidade, envolvendo infraestrutura, equipamentos, insumos, recursos financeiros e humanos e educação permanente. Esses serviços devem ter condições mínimas de atendimento, além de estar inseridos em uma rede de atenção que possibilite o encaminhamento para níveis mais complexos, quando necessário.  
O diagnóstico deve ser precoce e o tratamento imediato, com o menor tempo de espera possível, podendo esse período ser aproveitado para a realização de ações de informação/educação em saúde individual e coletiva. Estudos de análise de fluxo de pacientes apontaram que a maior parte do tempo que pessoas passam nos serviços de saúde não representa uma interação produtiva.  
O atendimento imediato de uma pessoa com IST não é apenas uma ação curativa, mas também visa à interrupção da cadeia de transmissão e à prevenção de outras IST e complicações decorrentes das infecções.  
11

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Para que se interrompa a cadeia de transmissão das IST, é fundamental que os contatos sexuais das pessoas infectadas sejam tratados. Portanto, essa informação deve ser repassada à pessoa com IST ao mesmo tempo que se fornecem instrumentos para comunicação e todo apoio até o final do processo.  
_Uma pessoa com IST nunca é só uma pessoa. É uma rede de parcerias sexuais que estão infectadas._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O profissional de saúde que estiver atendendo o paciente deve obter o nome, endereço e outras informações de identificação da parceria sexual para o preenchimento do cartão de comunicação (Anexo A). O cartão consiste de duas partes: a parte A fica retida na unidade que a preencheu, e a parte B é entregue ao caso-índice que, por sua vez, a entregará à parceria. Deve ser preenchido um novo cartão para cada parceria identificada.  
A parte A do cartão deve conter: código da Classificação Internacional das Doenças (CID-10); número do prontuário; nome do caso-índice; dados da parceria (nome, endereço); data do preenchimento e assinatura do profissional de saúde que preencheu o cartão.  
A parte B deve conter o mesmo CID-10, número do prontuário, dados da parceria sexual (nome, endereço), mensagem com solicitação de comparecimento ao serviço de saúde, nome e endereço da unidade de saúde para o atendimento, data do preenchimento e assinatura do profissional de saúde. Quando a parceria apresentar a parte B, o profissional de saúde identificará a IST que ocasionou a comunicação e a unidade que emitiu o cartão. Procede-se então ao tratamento, de acordo com as orientações deste Protocolo.  
O atendimento a portadores de cartões emitidos por outras unidades de saúde deve ser informado à unidade de origem. Todos os cartões devem ser mantidos em regime de confidencialidade e guardados em locais de acesso controlado pelo profissional responsável pelo sistema de comunicação.  
_Comunicação por correspondência e outros meios_  
Caso as parcerias sexuais não atendam à comunicação por cartão em um prazo de até 15 dias, ou o caso-índice não queira entregar os cartões (mas forneça dados de identificação das parcerias), deve-se realizar a comunicação por meio de correspondência ou outros meios de comunicação que garantam a confidencialidade da informação, como contato telefônico e/ou eletrônico.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Essa modalidade só poderá ser executada quando se esgotarem todos os recursos disponíveis, havendo acesso ao endereço. Cada unidade deve implementar as atividades do sistema progressivamente, conforme a disponibilidade local. Por exemplo, pode-se realizar a comunicação por profissionais habilitados, equipe de vigilância epidemiológica ou Estratégia de Saúde da Família da área de abrangência. Ao chegar ao serviço de saúde, a parceria deve ser considerada portadora da mesma infecção que acometeu o caso-índice, mesmo que não apresente sinal ou sintoma, e receber o mesmo tratamento recomendado para a condição clínica. As parcerias sexuais de gestantes com IST e as gestantes parceiras de pessoas com IST que não atenderem à comunicação para tratamento devem ser priorizadas para busca ativa.  
_Princípios para comunicação das parcerias sexuais_  
Qualquer método utilizado na comunicação das parcerias sexuais deve basear-se nos princípios de confidencialidade, ausência de coerção, proteção contra discriminação e legalidade da ação.  
**Confidencialidade:** o profissional de saúde explicará que a informação sobre um paciente não pode ser transmitida a outro. Há menor resistência em utilizar o serviço de saúde quando as pessoas percebem que há garantia de confidencialidade.  
12  
**Ausência de coerção:** a comunicação às parcerias sexuais pelo caso-índice deve ser voluntária, e este deve continuar tendo acesso aos serviços, mesmo que não coopere com o procedimento. Pode acontecer de o caso-índice se recusar a fazer a comunicação ou impedir que o profissional de saúde o faça; por isso, essa decisão deve ser tomada após orientação na consulta, de acordo com princípios éticos. Se o profissional perceber que o risco à saúde da parceria e/ou outros (como um concepto) é tão elevado que seria antiético deixar de realizar a comunicação, poderá fazê-lo, em último caso, esgotadas todas as possibilidades.  
**Proteção contra discriminação:** a comunicação às parcerias sexuais deverá ser feita respeitando os direitos humanos e a dignidade dos envolvidos, principalmente nos ambientes em que o estigma e a discriminação possam se seguir ao diagnóstico, tratamento ou notificação. É necessário lembrar que a discriminação dentro do próprio serviço de saúde é antiética e profissionalmente inaceitável, repercute negativamente na adesão e compromete o trabalho de toda a equipe. Discussões com todos os profissionais são essenciais para homogeneizar as ações.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
As principais manifestações clínicas das IST são: corrimento vaginal, corrimento uretral, úlceras genitais e verrugas anogenitais. Embora possam sofrer variações, essas manifestações têm etiologias bem estabelecidas, o que facilita a escolha e a realização dos testes para o diagnóstico e tratamento.  
As amostras para os exames laboratoriais indicados devem ser colhidas no momento da primeira consulta; caso os resultados não estejam disponíveis imediatamente, a conduta terapêutica não deve ser postergada até a entrega destes. A consulta clínica se completa com a prescrição e orientação para tratamento, além do estabelecimento de estratégia para seguimento e atenção às parcerias sexuais e o acesso aos insumos de prevenção, como parte da rotina de atendimento.  
Na situação em que não há rede laboratorial disponível, ocorre menor especificidade das condutas, existindo a possibilidade de tratamento desnecessário. A resistência da _Neisseria gonorrhoeae_ é preocupação mundial<sup>35,36</sup> , constando na lista de “patógenos prioritários” resistentes aos antibióticos preconizados pela OMS<sup>37</sup> .  
No Brasil, a realidade não é diferente. A rede nacional de vigilância para monitorar a resistência antimicrobiana da _N. gonorrhoeae_ , o Projeto SenGono, constatou alta resistência desse patógeno à penicilina, à tetraciclina e ao ciprofloxacino; emergência de resistência à azitromicina; e total sensibilidade (de acordo com os critérios do _Clinical and Laboratory Standards Institute_ – CLSI) às cefalosporinas de terceira geração (ceftriaxona, cefixima)<sup>38</sup> . Diante disso, é fundamental melhorar nossa rede laboratorial para o diagnóstico da _Neisseria gonorrhoeae,_ pois a correta identificação do patógeno proporciona o tratamento adequado. Outro ponto importante é o diagnóstico e tratamento da parceria sexual para a eliminação da bactéria em toda a rede sexual da pessoa, reduzindo assim, o risco de reinfecção<sup>39</sup> .  
O manejo das IST parte da premissa do conhecimento sobre a frequência dos agentes etiológicos das diferentes manifestações clínicas. Esses estudos de etiologia – componentes fundamentais e necessários da vigilância epidemiológica das IST – devem ser realizados regularmente em cada região.  
Existem situações, como o corrimento vaginal, em que o exame especular e testes mínimos são recomendados, sem os quais é impossível o adequado manejo do caso. Por outro lado, no manejo de doença inflamatória pélvica (DIP), considerando-se a urgência da intervenção, a conduta mais indicada é a instituição de tratamento imediato.  
A infecção pelos diferentes agentes etiológicos causadores das manifestações clínicas também pode se apresentar de forma assintomática. Por essa razão, a atenção integral às pessoas com IST deve, idealmente, incluir também o rastreamento e o diagnóstico de infecções assintomáticas, discutidas no capítulo 2.  
As condutas baseadas apenas na impressão clínica não são recomendadas, por causa de sua baixa sensibilidade e especificidade. As ações clínicas complementares têm tanta importância quanto o diagnóstico e o tratamento adequados. No entanto, apesar da importância do uso de testes laboratoriais no manejo clínico das IST, caso os exames laboratoriais não estejam disponíveis, recomenda-se o tratamento baseado na clínica em todo caso de suspeita de IST.  
O manejo das IST sintomáticas segue condutas baseadas em fluxogramas (com e sem a utilização de testes laboratoriais), conforme a Figura  
2. No seguimento das etapas do fluxograma, é indispensável aprofundar cada item, especialmente a anamnese acurada e o exame físico detalhado.  
13  
**Figura 2 – Manejo clínico de IST sintomáticas**  
<!-- Start of picture text -->
Queixa de sindrome especifica<br>Anamnesee exame fisico<br>Identificacao da sindrome<br>Presenca de<br>laboratorio?<br>Fluxograma sem laboratério Fluxograma com laboratério<br>Tratamento etiolégico ou baseado na clinica<br>(para os principais agentes causadores da sindrome)<br>I<br>1<br>1<br>1<br>1<br>~ Realizar orientacao centrada na pessoa e suas praticas sexuais.<br>~ Contribuir para que a pessoa reconheca e minimize o proprio risco de infeccao por uma IST.<br>- Oferecer testagem para HIV, sifilis e hepatites B e C.<br>~ Oferecer vacinacao para hepatites A e B e para HPV, quando indicado.<br>~ Informar sobre a possibilidade de realizar Prevencao Combinada para IST/HIV/ hepatites virais.<br>~ Tratar, acompanhar e orientar a pessoa e suas parcerias sexuais.<br>= Notificar 0 caso, quando indicado.<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
O Quadro 10, a seguir, apresenta as principais síndromes em IST e os respectivos agentes etiológicos.  
**Quadro 10 – Principais síndromes em IST e os respectivos agentes etiológicos**  
|**SÍNDROME –**|**ÚLCERA ANOGENITAL**|
|---|---|
|**Possíveis agentes etiológicos**|**Infecção**|
|_Chlamydia trachomatis_(sorovariantes L1, L2 e L3)|Linfogranuloma venéreo (LGV)|
|_Haemophilus ducreyi_|Cancroide|
|Vírus do_Herpes simplex_(tipo 2)|Herpes genital<sup>a</sup>|
|_Klebsiela granulomatis_|Donovanose|
|_Treponema pallidum_|Sífilis|  
14  
|**SÍNDROME – CORRI**|**MENTO URETRAL/VAGINAL**|
|---|---|
|**Possíveis agentes etiológicos**|**Infecção**|
|_Candida albicans_|Candidíase vulvovaginal<sup>b</sup>|
|_Chlamydia trachomatis_(sorovariantes D a K)|Clamídia|
|_Neisseria gonorrhoeae_|Gonorreia|
|_Trichomonas vaginalis_|Tricomoníase|
|_Mycoplasma genitalium_|Infecção causada por micoplasma|
|Múltiplos agentes|Vaginose bacteriana<sup>b</sup>|
|**SÍNDROME – V**|**ERRUGA ANOGENITAL**|
|**Possíveis agentes etiológicos**|**Infecção**|
|Papilomavírus humano (HPV)|Condiloma acuminado<sup>a</sup>|  
Fonte: DCCI/SVS/MS.  
a Infecções não curáveis, porém tratáveis.  
b Infecções endógenas do trato reprodutivo, que causam corrimento vaginal; não são consideradas IST.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A sífilis é uma infecção bacteriana sistêmica, crônica, curável e exclusiva do ser humano. Quando não tratada, evolui para estágios de gravidade variada, podendo acometer diversos órgãos e sistemas do corpo. Trata-se de uma doença conhecida há séculos; seu agente etiológico, descoberto em 1905, é o _Treponema pallidum_ , subespécie _pallidum_ . Sua transmissão se dá principalmente por contato sexual; contudo, pode ser transmitida verticalmente para o feto durante a gestação de uma mulher com sífilis não tratada ou tratada de forma não adequada<sup>11</sup> .  
A maioria das pessoas com sífilis são assintomáticas; quando apresentam sinais e sintomas, muitas vezes não os percebem ou valorizam, e podem, sem saber, transmitir a infecção às suas parcerias sexuais. Quando não tratada, a sífilis pode evoluir para formas mais graves, comprometendo especialmente os sistemas nervoso e cardiovascular<sup>33,40,41</sup> .  
Na gestação, a sífilis pode apresentar consequências severas, como abortamento, prematuridade, natimortalidade, manifestações congênitas precoces ou tardias e morte do recém-nascido (RN). O Capítulo 6 abrange importantes informações sobre sífilis congênita.  
O Brasil, assim como muitos países, apresenta uma reemergência da doença. Diante disso, os profissionais de saúde devem estar aptos a reconhecer as manifestações clínicas, conhecer os testes diagnósticos disponíveis, e, principalmente, saber interpretar o resultado do exame para diagnóstico e controle de tratamento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A transmissibilidade da sífilis é maior nos estágios iniciais (sífilis primária e secundária), diminuindo gradualmente com o passar do tempo (sífilis latente recente ou tardia). Vale a pena ressaltar que, no primeiro ano de latência 25% dos pacientes apresentam recrudescimento do secundarismo e, portanto, pode haver a transmissão. Essa maior transmissibilidade explica-se pela riqueza de treponemas nas lesões, comuns na sífilis primária (cancro duro) e secundária (lesões muco-cutâneas). As espiroquetas penetram diretamente nas membranas mucosas ou entram por abrasões na pele<sup>41</sup> . Essas lesões se tornam raras ou inexistentes a partir do segundo ano da doença.  
Em gestantes, a taxa de transmissão vertical de sífilis para o feto é de até 80% intraútero. Essa forma de transmissão ainda pode ocorrer durante o parto vaginal, se a mãe apresentar alguma lesão sifilítica. A infecção fetal é influenciada pelo estágio da doença na mãe (maior nos estágios primário e secundário) e pelo tempo em que o feto foi exposto. Tal acometimento fetal provoca entre 30% a 50% de morte _in utero_ , parto pré-termo ou morte neonatal<sup>42</sup> .  
15

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A sífilis é dividida em estágios que orientam o tratamento e monitoramento<sup>33</sup> , conforme segue :  
- Sífilis recente (primária, secundária e latente recente): até um ano de evolução;  
- Sífilis tardia (latente tardia e terciária): mais de um ano de evolução.  
**Sífilis primária:** o tempo de incubação é de dez a 90 dias (média de três semanas). A primeira manifestação é caracterizada por uma úlcera rica em treponemas, geralmente única e indolor, com borda bem definida e regular, base endurecida e fundo limpo, que ocorre no local de entrada da bactéria (pênis, vulva, vagina, colo uterino, ânus, boca, ou outros locais do tegumento), sendo denominada “cancro duro”. A lesão primária é acompanhada de linfadenopatia regional (acometendo linfonodos localizados próximos ao cancro duro). Sua duração pode variar muito, em geral de três a oito semanas, e seu desaparecimento independe de tratamento. Pode não ser notada ou não ser valorizada pelo paciente. Embora menos frequente, em alguns casos a lesão primária pode ser múltipla.  
**Sífilis secundária:** ocorre em média entre seis semanas a seis meses após a cicatrização do cancro, ainda que manifestações iniciais, recorrentes ou subentrantes do secundarismo possam ocorrer em um período de até um ano. Excepcionalmente, as lesões podem ocorrer em concomitância com a manifestação primária. As manifestações são muito variáveis, mas tendem a seguir uma cronologia própria.  
Inicialmente, apresenta-se uma erupção macular eritematosa pouco visível (roséola), principalmente no tronco e raiz dos membros. Nessa fase, são comuns as placas mucosas, assim como lesões acinzentadas e pouco visíveis nas mucosas. As lesões cutâneas progridem para lesões  
mais evidentes, papulosas eritemato-acastanhadas, que podem atingir todo o tegumento, sendo frequentes nos genitais. Habitualmente, atingem a região plantar e palmar, com um colarinho de escamação característico, em geral não pruriginosa.  
Mais adiante, podem ser identificados condilomas planos nas dobras mucosas, especialmente na área anogenital. Estas são lesões úmidas e vegetantes que frequentemente são confundidas com as verrugas anogenitais causadas pelo HPV. Alopecia em clareiras e madarose são achados eventuais. O secundarismo é acompanhado de micropoliadenopatia, sendo característica a identificação dos gânglios epitrocleares. São comuns sintomas inespecíficos como febre baixa, mal-estar, cefaleia e adinamia.  
A sintomatologia desaparece em algumas semanas, independentemente de tratamento, trazendo a falsa impressão de cura. Atualmente, têmse tornado mais frequentes os quadros oculares, especialmente uveítes. A neurossífilis meningovascular, com acometimento dos pares cranianos, quadros meníngeos e isquêmicos, pode acompanhar essa fase, contrariando a ideia de que a doença neurológica é exclusiva de sífilis tardia. Há que se considerar esse diagnóstico especialmente, mas não exclusivamente, em pacientes com imunodepressão.  
_Toda erupção cutânea sem causa determinada deve ser investigada com testes para sífilis._  
**Sífilis latente:** período em que não se observa nenhum sinal ou sintoma. O diagnóstico faz-se exclusivamente pela reatividade dos testes treponêmicos e não treponêmicos. A maioria dos diagnósticos ocorre nesse estágio. A sífilis latente é dividida em latente recente (até um ano de infecção) e latente tardia (mais de um ano de infecção). Aproximadamente 25% dos pacientes não tratados intercalam lesões de secundarismo com os períodos de latência.  
**Sífilis terciária:** ocorre aproximadamente em 15% a 25% das infecções não tratadas, após um período variável de latência, podendo surgir entre entre 1 e 40 anos depois do início da infecção. A inflamação causada pela sífilis nesse estágio provoca destruição tecidual. É comum o acometimento do sistema nervoso e do sistema cardiovascular. Além disso, verifica-se a formação de gomas sifilíticas (tumorações com tendência a liquefação) na pele, mucosas, ossos ou qualquer tecido. As lesões podem causar desfiguração, incapacidade e até morte.  
O Quadro 11 correlaciona as manifestações clínicas de sífilis adquirida com a evolução e estágios da doença.  
**Quadro 11 – Manifestações clínicas de sífilis adquirida, de acordo com o tempo de infecção, evolução e estágios da doença**  
|**ESTÁGIOS DE SÍFILIS**<br>**ADQUIRIDA**||**MANIFESTAÇÕES CLÍNICAS**|
|---|---|---|
|**Primária**|Cancro duro (úlcera genital)<br>Linfonodos regionais||  
16  
|**Secundária**|Lesões cutâneo-mucosas (roséola, placas mucosas, sifílides papulosas, sifílides palmoplantares, condiloma<br>plano, alopecia em clareira, madarose, rouquidão)<br>Micropoliadenopatia<br>Linfadenopatia generalizada<br>Sinais constitucionais<br>Quadros neurológicos, oculares, hepáticos|
|---|---|
|**Latente recente (até um**<br>**ano de duração)**|Assintomática|
|**Latente tardia (mais de um**<br>**ano de duração)**|Assintomática|
||Cutâneas: lesões gomosas e nodulares, de caráter destrutivo<br>Ósseas: periostite, osteíte gomosa ou esclerosante, artrites, sinovites e nódulos justa-articulares|
|**Terciária**|Cardiovasculares: estenose de coronárias, aortite e aneurisma da aorta, especialmente da porção torácica<br>Neurológicas: meningite, gomas do cérebro ou da medula, atrofia do nervo óptico, lesão do sétimo par<br>craniano, manifestações psiquiátricas,_tabes dorsalis_e quadros demenciais como o da paralisia geral|  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Os testes utilizados para o diagnóstico de sífilis são divididos em duas categorias: exames diretos e testes imunológicos.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Os exames diretos são aqueles em que se realiza a pesquisa ou detecção do _T. pallidum_ em amostras coletadas diretamente das lesões, e estão descritos no Quadro 12.  
<u>Quadro 12 – Métodos diagnósticos de sífilis: exames diretos</u>  
|**Método**|**Manifestações**<br>**clínicas de sífilis**|**Material**|**Sensibilidade/**<br>**especificidade**|**Significado clínico**|**Observações**|
|---|---|---|---|---|---|
|**Exame em**<br>**campo**<br>**escuro**|Lesões primárias e<br>secundárias|Exsudato seroso<br>das lesões ativas<br>para observação<br>dos treponemas<br>viáveis em<br>amostras frescas|Alta sensibilidade e<br>especificidade<br>Depende da<br>experiência do<br>técnico<br>Teste eficiente e de<br>baixo custo para<br>diagnóstico direto de<br>sífilis|**Positivo:**infecção ativa.<br>Considerar diagnóstico<br>diferencial com treponemas<br>não patogênicos e outros<br>organismos espiralados<br>**Negativo:**considerar que<br>1) O número de_T. pallidum_<br>na amostra não foi suficiente<br>para sua detecção;<br>2) A lesão está próxima à|Positividade em<br>pessoas com<br>cancro primário<br>pode ser anterior<br>à soroconversão<br>(positividade nos<br>testes<br>imunológicos)<br>Não é<br>recomendado<br>|
|**Pesquisa**<br>**direta com**<br>**material**<br>**corado**||Esfregaço em<br>lâmina ou cortes<br>histológicos com<br>diferentes<br>corantes|Todas as técnicas têm<br>sensibilidade inferior<br>à microscopia de<br>campo escuro|<br>cura natural;<br>3) A pessoa recebeu<br>tratamento sistêmico ou<br>tópico|para lesões de<br>cavidade oral|  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Os testes imunológicos são, certamente, os mais utilizados na prática clínica. Caracterizam-se pela realização de pesquisa de anticorpos em amostras de sangue total, soro ou plasma. Esses testes são subdivididos em duas classes, os treponêmicos e os não treponêmicos (Quadro 13).  
**Testes treponêmicos:** são testes que detectam anticorpos específicos produzidos contra os antígenos de _T. pallidum._ São os primeiros a se tornarem reagentes, podendo ser utilizados como primeiro teste ou teste complementar. Em 85% dos casos, permanecem reagentes por toda vida, mesmo após o tratamento e, por isso, não são indicados para o monitoramento da resposta ao tratamento.  
17  
Existem vários tipos de testes treponêmicos<sup>II</sup> :  
- Os testes rápidos (TR) utilizam principalmente a metodologia de imunocromatografia de fluxo lateral ou de plataforma de duplo percurso (DPP). São distribuídos pelo Ministério da Saúde para estados e Distrito Federal, sendo os mais indicados para início de diagnóstico;  
_Os TR são práticos e de fácil execução, com leitura do resultado em, no máximo, 30 minutos. Podem ser realizados com amostras de sangue total colhidas por punção digital ou venosa. Têm a vantagem de serem realizados no momento da consulta, possibilitando tratamento imediato._  
- Testes de hemaglutinação (TPHA, do inglês _T. Pallidum Haemagglutination Test_ ) e de aglutinação de partículas (TPPA, do inglês _T. Pallidum Particle Agglutination Assay_ ); ensaios de micro-hemaglutinação (MHA-TP, do inglês _Micro-Haemagglutination Assay_ );  
- Teste de imunofluorescência indireta (FTA-Abs, do inglês _Fluorescent Treponemal Antibody-Absorption_ );  
- Ensaios imunoenzimáticos (como os testes ELISA, do inglês _Enzyme-Linked Immunossorbent Assay_ ) e suas variações, como os ensaios de quimiluminescência (CMIA). A vantagem desses ensaios é sua elevada sensibilidade e capacidade de automação.  
**Testes não treponêmicos** : esses testes detectam anticorpos anticardiolipina não específicos para os antígenos do _T. pallidum_ . Permitem a análise qualitativa e quantitativa. Sempre que um teste não treponêmico é realizado, é imprescindível analisar a amostra pura e diluída, em virtude do fenômeno prozona<sup>III</sup> . Uma vez observada reatividade no teste, a amostra deve ser diluída em um fator dois de diluição, até a última diluição em que não haja mais reatividade no teste. O resultado final dos testes reagentes, portanto, deve ser expresso em títulos (1:2, 1:4, 1:8, etc.). Os testes não treponêmicos são utilizados para o diagnóstico (como primeiro teste ou teste complementar) e também para o monitoramento da resposta ao tratamento e controle de cura.  
A queda adequada dos títulos é o indicativo de sucesso do tratamento. Os testes não treponêmicos mais comumente utilizados no Brasil são o VDRL (do inglês _Venereal Disease Research Laboratory_ ), o RPR (do inglês _Rapid Plasma Reagin_ ) e o USR (do inglês _Unheated-Serum Reagin_ ). Resultados falso-reagentes, ainda que raros, podem ocorrer. Anticorpos anticardiolipinas podem estar presentes em outras doenças. Por isso, é sempre importante realizar testes treponêmicos e não treponêmicos para a definição laboratorial do diagnóstico.  
Os testes não treponêmicos tornam-se reagentes cerca de uma a três semanas após o aparecimento do cancro duro. Se a infecção for detectada nas fases tardias da doença, são esperados títulos baixos nesses testes. Títulos baixos (<1:4) podem persistir por meses ou anos. Pessoas com títulos baixos em testes não treponêmicos, sem registro de tratamento e sem data de infecção conhecida, são consideradas como portadoras de sífilis latente tardia, devendo ser tratadas.  
A denominada “cicatriz sorológica” acontece quando há persistência de resultados reagentes em testes não treponêmicos após o tratamento  
adequado, com registro de queda prévia da titulação em pelo menos duas diluições e descartada nova exposição de risco durante o período analisado.  
II Os testes de hemaglutinação (TPHA), aglutinação de partículas (TPPA) e de imunofluorescência indireta (FTA-abs) são produzidos com antígenos naturais de _Treponema pallidum_ . Esses antígenos são difíceis de obter e, por isso, tornam tais testes mais caros. As metodologias do tipo ELISA, CMIA e os testes rápidos são produzidas com antígenos sintéticos ou recombinantes, fator que favorece sua comercialização por preços menores.  
III A diferenciação entre teste qualitativo e quantitativo faz parte da rotina laboratorial para testar amostras com testes não treponêmicos. O teste qualitativo se inicia com amostra pura e diluída 1:8 ou 1:16, para evitar resultados falso-negativos em virtude do fenômeno de prozona.  
Toda amostra reagente no teste qualitativo deve ser testada com o teste quantitativo para determinar o título, ou seja, a maior diluição da amostra que ainda é reagente. As diluições testadas são 1:2, 1:4, 1:8, 1:16, 1:32, 1:64, 1:128, 1:256, 1:512, 1:1024 e assim sucessivamente.  
O fenômeno de prozona consiste na falta de reatividade no teste realizado em uma amostra que, embora contenha anticorpos não treponêmicos, apresenta resultado não reagente quando é testada sem diluir. Trata-se de fenômeno produzido por excesso de anticorpos em relação à quantidade de antígenos, com formação de imunocomplexos solúveis, gerando resultados falso-negativos.  
Se a amostra for não reagente no teste qualitativo, naturalmente não precisa de diluição para quantificação de anticorpos.  
18  
**Quadro 13 – Métodos diagnósticos de sífilis: testes imunológicos**  
||**Não treponêmicos**|VDRL<br>RPR<br>TRUST<br>USR|Quantificáveis (ex.: 1:2, 1:4, 1:8).<br>Importantes para o diagnóstico e monitoramento da<br>resposta ao tratamento.|
|---|---|---|---|
|**TESTES**<br>**IMUNOLÓGICOS**|**Treponêmicos**|FTA-Abs<br>ELISA/EQL/CMIA<br>TPHA/TPPA/MHA-TP<br>Teste Rápido (TR)|São os primeiros a se tornarem reagentes.<br>Na maioria das vezes, permanecem reagentes por toda<br>a vida, mesmo após o tratamento.<br>São importantes para o diagnóstico, mas**não estão**<br>**indicados para monitoramento da resposta ao**<br>**tratamento.**|  
Fonte: DCCI/SVS/MS.  
_A análise isolada do título de um único resultado de um teste não treponêmico (ex.: VDRL, RPR) é um equívoco frequente. Textos antigos mencionavam um ponto de corte acima do qual o resultado seria indicativo de doença ativa e, abaixo, indicativo de resultado falsoreagente ou de inatividade da doença. Essa ideia leva a decisões terapêuticas inadequadas._  
_Há que se incorporar definitivamente a ideia de que títulos altos nos testes não treponêmicos (em queda) podem ser encontrados em pacientes adequadamente tratados, e de que títulos baixos podem ser encontrados em três situações:_  
_- Infecção recente;_  
- _Estágios tardios da infecção (sífilis tardia);_  
- _Casos de pessoas adequadamente tratadas que não tenham atingido a negativação. Esse fenômeno pode ser temporário ou persistente e é denominado cicatriz sorológica._  
_Os testes treponêmicos (ex. testes rápidos, FTA-Abs, TPHA), por sua vez, permanecem quase sempre reagentes por toda a vida, apesar de tratamento adequado. Entretanto, frente a achados clínico-epidemiológicos, na ausência de tratamento, são indicativos de doença ativa. Ainda assim, os testes não treponêmicos devem ser solicitados para acompanhamento sorológico._  
A Figura 3 apresenta o desempenho dos testes laboratoriais em cada estágio de sífilis.  
**Figura 3 – Estágios clínicos e métodos diagnósticos de sífilis**  
<!-- Start of picture text -->
Curso da sifilis nao tratada<br>TESTES<br>SENSIBILIDADE FTA-abse outros testes treponémicos<br>100<br>90 VDRL<br>no treponémicos<br>80 e outros testes<br>70 campo campo<br>60 POSITIVOtind POSITIVOeuro<br>0 [| Td<br>— PRIMARIA SECUNDARIA LATENTE TERCIARIA<br>curso necnuoescienrosecunoanias —LATENTE | LATENTE<br>CLINICO [E | | RECENTE TARDIA.<br>EXPOSICAO—> —<br>Bias | [SSSSEMAnAS SEMANAS Tt 7<br>jsssawws- | APOSA'SIFILISPRIMARIA  APOSPRIMARIA10 ANOS A SIFILIS<br><!-- End of picture text -->  
19  
Fonte: adaptado de Brasil (2006)<sup>43</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O diagnóstico de sífilis exige uma correlação entre dados clínicos, resultados de testes laboratoriais, histórico de infecções passadas e investigação de exposição recente. Apenas o conjunto de todas essas informações permitirá a correta avaliação diagnóstica de cada caso e, consequentemente, o tratamento adequado.  
A presença de sinais e sintomas compatíveis com sífilis (primária, secundária e terciária) favorecem a suspeição clínica. Entretanto, não há  
sinal ou sintoma patognomônico da doença. Portanto, para a confirmação do diagnóstico é necessária a solicitação de testes diagnósticos.  
Nas fases sintomáticas, é possível a realização de exames diretos, enquanto os testes imunológicos podem ser utilizados tanto na fase sintomática quanto na fase de latência.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Considerando a sensibilidade dos fluxos diagnósticos, recomenda-se, sempre que possível, iniciar a investigação por um teste treponêmico, preferencialmente o teste rápido.  
A combinação de testes sequenciais tem por objetivo aumentar o valor preditivo positivo (VPP) de um resultado reagente no teste inicial. O fluxograma em série é custo-efetivo e está apresentado na Figura 4.  
**Figura 4 – Testes imunológicos para diagnóstico de sífilis**  
<!-- Start of picture text -->
Teste treponémico Teste nao<br>REAGENTE: treponémico Diagnostico<br>- Teste rapido + REAGENTE: = de sifilis<br>-FTA-Abs > -VDRL confirmado*<br>= TPHA -RPR<br>-EQL<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
*O diagnóstico de sífilis não estará confirmado quando houver presença de cicatriz sorológica, ou seja, tratamento anterior para sífilis com documentação da queda da titulação em pelo menos duas diluições (ex.: uma titulação de 1:16 antes do tratamento que se torna menor ou igual a 1:4 após o tratamento) e afastada a possibilidade de reinfecção.  
_Considerando a epidemia de sífilis no Brasil e a sensibilidade dos fluxos de diagnóstico, recomenda-se iniciar a investigação pelo_ **_teste treponêmico_** _, que é o primeiro teste a ficar reagente._  
Os profissionais de saúde, tanto da medicina quanto da enfermagem, devem solicitar os testes imunológicos para sífilis, explicitando no formulário de solicitação a finalidade do exame:  
**Diagnóstico de sífilis:** solicitação para rede laboratorial. Deverá ser solicitado na indisponibilidade do teste rápido no serviço.  
**Diagnóstico de sífilis após TR reagente:** quando foi realizada a testagem rápida no serviço de saúde e com resultado reagente. Nesse momento, o laboratório iniciará a investigação com o teste não treponêmico.  
**Monitoramento do tratamento de sífilis:** quando o diagnóstico e tratamento da sífilis já foram realizados e é necessário monitorar os títulos dos anticorpos não treponêmicos.  
20

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O Quadro 14 apresenta as possíveis interpretações e conduta frente ao resultado dos testes imunológicos.  
**Quadro 14 – Resultados de testes treponêmicos e não treponêmicos de sífilis, interpretação e conduta**  
|**PRIMEIRO**<br>**TESTE**|**+**|**TESTE**<br>**COMPLE-**<br>**MENTAR**|**POSSÍVEIS INTERPRETAÇÕES**|**CONDUTA**|
|---|---|---|---|---|
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**|**Teste não**<br>**treponêmico:**<br>**Reagente**|Diagnóstico de sífilis.<br> Classificação do estágio clínico a ser definida de<br>acordo com o tempo de infecção e o histórico de<br>tratamento.<br>Cicatriz sorológica: tratamento anterior documentado<br>com queda da titulação em pelo menos duas<br>diluições.|Quando sífilis, tratar, realizar<br>monitoramento com teste não<br>treponêmico e notificar o caso de<br>sífilis.<br>Quando confirmado caso de cicatriz<br>sorológica, apenas orientar.|
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**|**Teste não**<br>**treponêmico:**<br>**não reagente**|Realiza-se um**terceiro teste**treponêmico com<br>metodologia diferente do primeiro.<br> Se**reagente:**diagnóstico de sífilis ou cicatriz<br>sorológica.<br> Se**não reagente:**considera-se resultado falso<br>reagente para o primeiro teste, sendo excluído o<br>diagnóstico de sífilis.<br>Se terceiro teste treponêmico não disponível, avaliar<br>exposição de risco, sinais e sintomas e histórico de<br>tratamento para definição de conduta.|Quando sífilis, tratar, realizar<br>monitoramento com teste não<br>treponêmico e avaliar critério de<br>notificação  de sífilis.<br>Quando confirmado caso de cicatriz<br>sorológica, apenas orientar.<br>Para os casos concluídos como<br>ausência de sífilis, apenas orientar.|
|**Teste não**<br>**treponêmico:**<br>**reagente**|**+**|**Teste**<br>**treponêmico:**<br>**Reagente**|Diagnóstico de sífilis.<br> Classificação do estágio clínico a ser definida de<br>acordo com o tempo de infecção e o histórico de<br>tratamento.<br>Cicatriz sorológica: tratamento anterior documentado<br>com queda da titulação em pelo menos duas<br>diluições.|Quando sífilis, tratar, realizar<br>monitoramento com teste não<br>treponêmico e notificar o caso de<br>sífilis.<br>Quando confirmado caso de cicatriz<br>sorológica, apenas orientar.|
|**Teste não**<br>**treponêmico:**<br>**reagente**|**+**|**Teste**<br>**treponêmico:**<br>**não reagente**|Realiza-se um**terceiro teste**treponêmico com<br>metodologia diferente do primeiro.<br>O resultado final do fluxograma será definido pelo<br>resultado desse**terceiro teste.**<br> Se**reagente**, diagnóstico de sífilis ou cicatriz<br>sorológica.<br> Se**não reagente**, considera-se resultado falso<br>reagente para o primeiro teste, sendo excluído o<br>diagnóstico de sífilis.<br>Cicatriz sorológica: tratamento anterior documentado<br>com queda da titulação em pelo menos duas<br>diluições.<br>Se terceiro teste treponêmico não disponível, avaliar<br>exposição de risco, sinais e sintomas e histórico de<br>tratamento para definição de conduta.|Quando sífilis, tratar, realizar<br>monitoramento com teste não<br>treponêmico e avaliar critério de<br>notificação de sífilis.<br>Quando confirmado caso de cicatriz<br>sorológica, apenas orientar.<br>Para os casos concluídos como<br>ausência de sífilis, apenas orientar.|
|**Teste não**<br>**treponêmico:**<br>**não reagente**<br>**ou**<br>**Teste**<br>**treponêmico:**<br>**não reagente**|**+**|Não realizar teste<br>complementar se<br>o primeiro teste<br>for**não reagente**<br>e se não houver<br>suspeita clínica de<br>sífilis primária|Ausência de infecção ou período de incubação (janela<br>imunológica) de sífilis recente.|Em caso de suspeita clínica e/ou<br>epidemiológica, solicitar nova coleta<br>de amostra em 30 dias.<br>Isso não deve, no entanto, retardar a<br>instituição do tratamento, caso o<br>diagnóstico de sífilis seja o mais<br>provável (ex.: visualização de úlcera<br>anogenital) ou o retorno da pessoa ao<br>serviço de saúde não possa ser<br>garantido.|  
Fonte: DCCI/SVS/MS.  
21

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A benzilpenicilina benzatina é o medicamento de escolha para o tratamento de sífilis, sendo a única droga com eficácia documentada durante a gestação. Não há evidências de resistência de _T. pallidum_ à penicilina no Brasil e no mundo.  
Outras opções para não gestantes, como a doxiciclina e a ceftriaxona, devem ser usadas somente em conjunto com um acompanhamento clínico e laboratorial rigoroso, para garantir resposta clínica e cura sorológica.  
Devido ao cenário epidemiológico atual, recomenda-se tratamento imediato, com benzilpenicilina benzatina, após apenas um teste reagente para sífilis (teste treponêmico ou teste não treponêmico) para as seguintes situações (independentemente da presença de sinais e sintomas de sífilis):  
- Gestantes;  
- Vítimas de violência sexual;  
- Pessoas com chance de perda de seguimento (que não retornarão ao serviço);  
- Pessoas com sinais/sintomas de sífilis primária ou secundária;  
- Pessoas sem diagnóstico prévio de sífilis.  
O fato da realização do tratamento com apenas um teste reagente para sífilis não exclui a necessidade de realização do segundo teste (melhor análise diagnóstica), do monitoramento laboratorial (controle de cura) e do tratamento das parcerias sexuais (interrupção da cadeia de transmissão).  
Para pacientes sintomáticos com suspeita de sífilis primária e secundária e impossibilidade de realização de qualquer teste diagnóstico,  
recomenda-se tratamento empírico imediato para sífilis recente, assim como para as respectivas parcerias sexuais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Como medida de garantia de acesso, a benzilpenicilina benzatina passou a ser componente estratégico na Relação Nacional de Medicamentos  
Essenciais (Rename) 2017, com aquisição centralizada pelo Ministério da Saúde<sup>44</sup> . A compra e distribuição tem como base de cálculo os casos notificados de sífilis adquirida e de sífilis em gestantes.  
A benzilpenicilina benzatina dever ser administrada exclusivamente por via intramuscular (IM). A região **ventro-glútea é a via preferencial** , por ser livre de vasos e nervos importantes, sendo tecido subcutâneo de menor espessura, com poucos efeitos adversos e dor local<sup>45</sup> . Outros locais alternativos para aplicação são a região do vasto lateral da coxa e o dorso glúteo.  
_A presença de silicone (prótese ou silicone líquido industrial) nos locais recomendados podem impossibilitar a aplicação IM da medicação. Nesses casos, optar pela medicação alternativa, conforme o Quadro 15._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O Quadro 15 apresenta os esquemas terapêuticos utilizados para sífilis, de acordo com a classificação clínica.  
**Quadro 15 – Tratamento e monitoramento de sífilis**  
|**ESTADIAMENTO**|**ESQUEMA**<br>**TERAPÊUTICO**|**ALTERNATIVA**<sup>**a**</sup><br>**(EXCETO PARA**<br>**GESTANTES)**|**SEGUIMENTO (TESTE**<br>**NÃO TREPONÊMICO)**|
|---|---|---|---|
|Sífilis recente: sífilis<br>primária, secundária e latente<br>recente (com até um ano de|Benzilpenicilina benzatina 2,4 milhões<br>UI, IM, dose única (1,2 milhão UI em<br>cada glúteo)<sup>b</sup>|Doxiciclina 100mg, 12/12h,<br>VO, por 15 dias|Teste não treponêmico<br>trimestral (em**gestantes**, o<br>controle deve ser mensal)|  
22  
|evolução)||||
|---|---|---|---|
|Sífilis tardia: sífilis latente<br>tardia (com mais de um ano<br>de evolução) ou latente com<br>duração ignorada e sífilis<br>terciária|Benzilpenicilina benzatina 2,4 milhões<br>UI, IM, 1x/semana (1,2 milhão UI em<br>cada glúteo) por 3 semanas<sup>c</sup><br>Dose total: 7,2 milhões UI, IM|Doxiciclina 100mg, 12/12h,<br>VO, por 30 dias|Teste não treponêmico<br>trimestral (em**gestantes**, o<br>controle deve ser mensal)|
|Neurossífilis|Benzilpenicilina potássica/cristalina 18-<br>24 milhões UI, 1x/ dia, EV,<br>administrada em doses de 3-4 milhões<br>UI, a cada 4 horas ou por infusão<br>contínua, por 14 dias|Ceftriaxona 2g IV, 1x/dia,<br>por 10-14 dias|Exame de LCR de 6/6<br>meses até normalização|  
Fonte: DCCI/SVS/MS.  
a A benzilpenicilina benzatina é a única opção segura e eficaz para tratamento adequado das gestantes.  
b No caso de sífilis recente em gestantes, alguns experts recomendam uma dose adicional de 2,4 milhões  de unidades de penicilina G benzatina, IM, uma semana após a primeira dose<sup>46</sup> .  
c Em não gestantes, o intervalo entre doses não deve ultrapassar 14 dias. Caso isso ocorra, o esquema deve ser reiniciado47. Em gestantes, o intervalo entre doses não deve ultrapassar 7 dias. Caso isso ocorra, o esquema deve ser reiniciado<sup>46</sup> .  
A benzilpenicilina benzatina é a única opção segura e eficaz para o tratamento adequado das gestantes. Qualquer outro tratamento realizado durante a gestação, para fins de definição de caso e abordagem terapêutica de sífilis congênita, é considerado tratamento não adequado da mãe; por conseguinte, o RN será notificado como sífilis congênita e submetido a avaliação clínica e laboratorial.  
A resolução dos sinais e sintomas após o tratamento, caso estes tenham estado previamente presentes, é indicativa de resposta à terapia. No entanto, o monitoramento pós tratamento com teste não treponêmico é recomendado a todos os pacientes para determinar se ocorreu resposta imunológica adequada<sup>48</sup> – seção 5.7.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A reação de Jarisch-Herxheimer é um evento que pode ocorrer durante as 24 horas após a primeira dose de penicilina, em especial nas fases primária ou secundária. Caracteriza-se por exacerbação das lesões cutâneas, mal-estar geral, febre, cefaleia e artralgia, que regridem espontaneamente após 12 a 24 horas<sup>49</sup> . Pode ser controlada com o uso de analgésicos simples, conforme a necessidade, sem ser preciso descontinuar o tratamento.  
As pessoas com prescrição de tratamento devem ser alertadas quanto à possibilidade de ocorrência dessa reação, em especial para que se faça distinção em relação aos quadros de alergia à penicilina. Estes são muito raros com o uso da benzilpenicilina benzatina e, quando ocorrem, apresentam-se frequentemente na forma de urticária e exantema pruriginoso.  
Gestantes que apresentam essa reação podem ter risco de trabalho de parto prematuro, pela liberação de prostaglandinas em altas doses. Entretanto, caso a gestante não seja tratada adequadamente para sífilis, o risco de abortamento ou morte fetal é maior que os riscos potenciais da reação<sup>11</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
_A administração de benzilpenicilina benzatina pode ser feita com segurança na Atenção Básica, tanto para a pessoa com sífilis quanto quanto suas(s) parceria(s) sexual(is)._  
A probabilidade de reação adversa às penicilinas, em especial as reações graves, é muito rara. Diversos medicamentos normalmente  
prescritos e utilizados na prática clínica diária (ex.: anti-inflamatórios não esteroides – AINE, lidocaína etc.), bem como alimentos (ex.: nozes, frutos do mar, corantes etc.) apresentam maiores riscos de anafilaxia; todavia, não há tanto temor quanto à sua administração ou consumo. Infelizmente, o receio de reações adversas à penicilina por profissionais de saúde, em especial a raríssima reação anafilática, tem contribuído para a perda do momento oportuno de tratamento de pessoas com sífilis, colaborando para a manutenção da cadeia de transmissão da doença, inclusive sua faceta mais grave, a sífilis congênita<sup>11</sup> .  
23  
A possibilidade de reação anafilática à administração de benzilpenicilina benzatina é de 0,002%, segundo levantamento das evidências científicas constante no relatório de recomendação: “Penicilina benzatina para prevenção da Sífilis Congênita durante a gravidez”, elaborado pela Comissão Nacional de Incorporação de Tecnologia no SUS – Conitec<sup>50</sup> .  
O receio de ocorrência de reações adversas não é impeditivo para a administração de benzilpenicilina benzatina nos serviços de saúde, especialmente na Atenção Básica. A anafilaxia, como discutido anteriormente, não é exclusiva das penicilinas e, portanto, os serviços devem estar cientes dos procedimentos a serem adotados em tal situação. A adrenalina é a droga de escolha para tratamento da reação de anafilaxia, caso esta ocorra, e a pessoa deverá receber atendimento conforme preconizado pelo Caderno da Atenção Básica nº 28, v. II, “Acolhimento à Demanda Espontânea: Queixas mais comuns na Atenção Básica”<sup>51</sup> , capítulo 2: Queixas comuns no atendimento à demanda espontânea e urgências/emergências, p. 25.  
Destaca-se também a Decisão nº 0094/2015, do Conselho Federal de Enfermagem – Cofen, que reforça a importância da administração da benzilpenicilina benzatina pelos profissionais de enfermagem na Atenção Básica<sup>52</sup> , além da Nota Técnica Cofen/CTLN nº 03/2017, que reafirma esse compromisso de cuidado à saúde<sup>53</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A maioria dos casos identificados grosseiramente como suspeitos de serem alérgicos à penicilina carecem de anamnese criteriosa para qualificar essa alteração. Em vista disso, é fundamental e imperativo que a anamnese seja objetiva, para a adequada obtenção dessas informações. Tal decisão fundamentou-se no elevado número de casos suspeitos de alergia à penicilina encaminhados para dessensibilização, constatando-se que a quase totalidade deles foram descartados somente pela anamnese. Por sua vez, o uso de derivados da penicilina também pode deflagrar crise de alergia à penicilina<sup>54</sup> .  
Relembre-se que dor e reação local, rash maculopapular, náusea, prurido, mal-estar, cefaleia, história de algum evento suspeito há mais de dez anos, história familiar, entre outras manifestações, isoladamente não configuram alergia à penicilina. As manifestações clínicas que justificam encaminhar a gestante para descartar o diagnóstico de alergia à sífilis incluem reação anafilática prévia e lesões cutâneas graves, como síndrome de Stevens-Johnson<sup>55</sup> . Gestantes comprovadamente alérgicas à penicilina devem ser dessensibilizadas em ambiente hospitalar.  
Para orientar a anamnese, visando obter informações mais específicas sobre o passado de alergia à penicilina, podem-se dirigir às gestantes algumas perguntas com maior potencial de assertividade, dentre elas: 1) você se lembra dos detalhes da reação? 2) há quantos anos a reação ocorreu? 3) como foi o tratamento? 4) qual foi o resultado? 5) por que você recebeu penicilina? 6) você já fez algum tratamento com antibióticos depois desse evento? 7) quais foram esses medicamentos (lembrar que medicamentos como a ampicilina, a amoxicilina e as cefalosporinas são exemplos de drogas derivadas da penicilina)? 7) você já fez uso de penicilina ou de seus derivados após esse evento que você acha que foi alergia à penicilina?

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
_Para o seguimento do paciente, os testes não treponêmicos (ex.: VDRL/ RPR) devem ser realizados mensalmente nas gestantes e, no restante da população (incluindo PVHIV), a cada três meses até o 12º mês do acompanhamento do paciente (3, 6, 9 e 12 meses)._  
A pessoa tratada com sucesso pode ser liberada de novas coletas após um ano de seguimento pós tratamento. Entretanto, a aquisição de uma nova IST, especialmente sífilis, é um fator de risco para outras IST. Deve ser fortemente considerada a realização de rastreamento de acordo com a história sexual e o gerenciamento de risco para sífilis e outras IST na população de pessoas curadas de sífilis.  
Os testes não treponêmicos não são automatizados; portanto, pode haver diferença entre leituras em momentos diferentes e/ou quando realizadas por mais de um observador. Por essa razão, variações do título em uma diluição (ex.: de 1:2 para 1:4; ou de 1:16 para 1:8) devem ser analisadas com cautela.  
O monitoramento é fundamental para classificar a resposta ao tratamento, identificar possível reinfecção e definir a conduta correta para cada caso. Didaticamente, a resposta ao tratamento foi classificada em:  
24  
- Resposta imunológica adequada;  
- Critérios de retratamento: reativação e/ou reinfecção.  
_O monitoramento deve ser realizado com teste não treponêmico e, sempre que possível, com o mesmo método diagnóstico. Por exemplo: se o diagnóstico for realizado com VDRL, deve-se manter seguimento com VDRL. Em caso de diagnóstico realizado com RPR, manter seguimento com RPR._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Tradicionalmente, é indicação de sucesso de tratamento a ocorrência de diminuição da titulação em duas diluições dos testes não treponêmicos em até três meses e quatro diluições até seis meses, com evolução até a sororreversão (teste não treponêmico não reagente)<sup>56</sup> . Essa resposta é mais comum em pessoas de menos idade, com títulos não treponêmicos mais altos no início do tratamento e em estágios mais recentes da infecção (sífilis primária, secundária e latente recente)<sup>57</sup> . Mesmo que ocorra resposta adequada ao tratamento, o seguimento clínico deve continuar, com o objetivo de monitorar possível reativação ou reinfecção.  
**Atualmente, para definição de resposta imunológica adequada, utiliza-se o teste não treponêmico não reagente ou uma queda na titulação em duas diluições em até seis meses para sífilis recente e queda na titulação em duas diluições em até 12 meses para sífilis**  
**tardia**<sup>33,58–61</sup> . Quanto mais precoce for o diagnóstico e o tratamento, mais rapidamente haverá desaparecimento dos anticorpos circulantes e consequente negativação dos testes não treponêmicos, ou, ainda, sua estabilização em títulos baixos.  
Deve-se realizar a coleta do teste não treponêmico, sempre que possível, no início do tratamento (idealmente, no primeiro dia de tratamento), uma vez que os títulos podem aumentar significativamente se o tratamento só for iniciado após alguns dias do diagnóstico. Isso é importante para documentação da titulação no momento do início do tratamento e servirá como base para o monitoramento clínico.  
A persistência de resultados reagentes em testes não treponêmicos após o tratamento adequado e com queda prévia da titulação em pelo menos duas diluições, quando descartada nova exposição de risco durante o período analisado, é chamada de “cicatriz sorológica” ( _serofast_ ) e não caracteriza falha terapêutica.  
_TÍTULO x DILUIÇÃO_  
_Quando os títulos da amostra diminuem em duas diluições (ex.: de 1:64 para 1:16), isso significa que o título da amostra caiu quatro vezes. Isso porque a amostra é diluída em um fator 2; logo, uma diluição equivale a dois títulos._  
_Para realizar um teste não treponêmico, são feitas várias diluições da amostra. A última diluição que ainda apresenta reatividade permite determinar o título (ex.: amostra reagente até a diluição 1:16 corresponde ao título 16)._  
_No Brasil, a maioria dos laboratórios libera o resultado na forma de diluição._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Muitas vezes, é difícil distinguir entre reinfecção, reativação e cicatriz sorológica, sendo fundamental a avaliação da presença de sinais e sintomas clínicos novos, da epidemiologia (reexposição), do histórico de tratamento (duração, adesão e medicação utilizada) e dos exames laboratoriais prévios, para facilitar a elucidação diagnóstica.  
São critérios de retratamento e necessitam de conduta ativa do profissional de saúde:  
- Ausência de redução da titulação em duas diluições no intervalo de seis meses (sífilis recente, primária e secundária) ou 12 meses (sífilis tardia) após o tratamento adequado (ex.: de 1:32 para >1:8; ou de 1:128 para >1:32), OU  
- Aumento da titulação em duas diluições ou mais (ex.: de 1:16 para 1:64; ou de 1:4 para 1:16), OU  
- Persistência ou recorrência de sinais e sintomas clínicos.  
O esquema de retratamento, se para sífilis recente ou tardia, irá depender de cada caso. A investigação de neurossífilis por meio de punção  
25  
lombar está indicada na população geral, quando não houver exposição sexual no período que justifique uma reinfecção. Para PVHIV, a investigação está recomendada em todos os casos de retratamento, independentemente de haver ocorrido ou não nova exposição. Em caso de exame de líquido cefalorraquidiano (LCR) compatível com neurossífilis, tratar conforme o Quadro 19.  
_O monitoramento mensal das gestantes e da população geral aos três e aos nove meses não tem o intuito de avaliar queda da titulação, mas principalmente descartar aumento da titulação em duas diluições, o que configuraria reinfecção/reativação e necessidade de retratamento da pessoa e das parcerias sexuais._

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
_A neurossífilis acomete o SNC, o que pode ocorrer já nas fases iniciais da infecção._  
O envolvimento do sistema nervoso central (SNC) pode ocorrer durante qualquer estágio da sífilis e anormalidades laboratoriais do LCR são comuns em pessoas infectadas já nos estágios iniciais da doença<sup>33</sup> , pois o _T. pallidum_ invade precocemente o SNC dentro de horas a dias após a inoculação. A neuroinvasão pode ser transitória e não está bem estabelecido os preditores de sua persistência e do início de sinais e sintomas clínicos<sup>62</sup> .  
O comprometimento sintomático do SNC nos estágios tardios (sífilis terciária) era uma condição extremamente comum na era préantibiótica, afetando 5% a 10% de todas as pessoas que apresentavam sífilis não tratada. Caracterizava-se por uma grande variedade de anormalidades neurológicas, incluindo _tabes dorsalis_ , AVC, demência e morte. A neurossífilis precoce aparece logo após a infecção sifilítica, causando meningite e anormalidades nos nervos cranianos<sup>63,64</sup> . A história natural da neurossífilis é apresentada na Figura 5.  
**Figura 5 – História natural da neurossífilis**  
<!-- Start of picture text -->
Infeccao pelo T. pallidum<br>Clareamento —<br>Invasaodo SNC<br>Meningite persistente<br>Neurossifilis assintomatica recente<br>Neurossifilis Neurossifilis<br>sintomatica recente sintomatica tardia<br>Semanas-meses-anos Anos-décadas<br>Meningite sintomatica Lesdo meningovascular Paresia geral Tabes dorsalis<br><!-- End of picture text -->  
Fonte: adaptado de Marra (2015)<sup>64</sup> .  
Com a era antibiótica e o uso dominante dos beta-lactâmicos, a apresentação clínica da neurossífilis sofreu mudanças, com aumento dos quadros oligossintomáticos e atípicos<sup>41,65</sup> . No Quadro 16 encontram-se as alterações clínicas da neurossífilis.  
26

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
- <mark>Envolvimento ocular (uveíte, paralisia de nervos cranianos)</mark>  
- Envolvimento auditivo  Paresia geral  Deficiência cognitiva  Mudanças de comportamento  Demência  Depressão  Mania  Psicose com alucinações visuais ou auditivas  Dificuldades de memória  
- Confusão mental  
- Meningite sifilítica  
- Lesão meningovascular: acometimento isquêmico principalmente cápsula interna, artéria cerebral média, carótida, artéria basilar, artéria cerebral posterior, vasos cerebelares  
- _Tabes dorsalis_  
- Goma sifilítica  
- Epilepsia  
Fonte: DCCI/SVS/MS.  
O acometimento ocular pode se dar em qualquer estrutura do olho. A uveíte posterior e a panuveíte são as ocorrências mais comuns e podem evoluir com diminuição da acuidade visual. A sífilis ocular é frequentemente associada a meningite sifilítica (assintomática e sintomática).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
O diagnóstico de neurossífilis continua a ser um desafio, pois não há teste padrão-ouro. Consequentemente, o diagnóstico é baseado em uma combinação de achados clínicos, alterações do LCR e ao resultado do VDRL no LCR. As indicações para punção lombar estão descritas no Quadro 17.  
**Quadro 17 – Indicação de punção lombar para pesquisa de neurossífilis**  
- Na presença de sintomas neurológicos ou oftalmológicos;  
- Em caso de evidência de sífilis terciária ativa;  
- Após falha ao tratamento clínico sem reexposição sexual (ver critérios de retratamento, seção 5.7.2). Para PVHIV, a punção lombar está indicada após falha ao tratamento, independentemente da história sexual.  
Fonte: DCCI/SVS/MS.  
Não existe uma única prova sensível e específica para o diagnóstico de neurossífilis. Devido à baixa sensibilidade, o RPR não é recomendado para o diagnóstico da neurossífilis<sup>66</sup> . O método de escolha é o VDRL, com sensibilidade que varia de 50% a 70%<sup>67</sup> . Embora seja possível encontrar resultados falso-reagentes (ex.: tripanossomíase, malária cerebral e carcinomatose meníngea), na prática um VDRL reagente confere diagnóstico de neurossífilis<sup>41,68–70</sup> .  
Em relação aos testes treponêmicos, apesar da alta sensibilidade, estes apresentam especificidade muito variável e o valor preditivo negativo (VPN) varia de acordo com a prevalência da doença. Em locais de alta prevalência, o VPN é baixo, ou seja, um resultado não reagente não exclui a doença<sup>71–73</sup> . Portanto, não se recomenda a solicitação desse teste de rotina, principalmente no atual cenário epidemiológico brasileiro.  
Em relação à análise do LCR, é raro encontrar pacientes com neurossífilis que não apresentem pleocitose, sendo o aumento linfomonocitário o mais comum<sup>74</sup> . Níveis de proteína no LCR não são nem sensíveis nem específicos para neurossífilis, mas sua normalização é importante para o monitoramento pós tratamento<sup>62,63,74–76</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Devem-se tratar para neurossífilis todos os pacientes com sífilis que apresentem os achados descritos no Quadro 18.  
**Quadro 18 – Quem deve ser tratado para neurossífilis?**  
Todos os casos com VDRL reagente no LCR, independentemente da presença de sinais e sintomas neurológicos e/ou oculares  
27  
Casos que apresentem **VDRL não reagente** no LCR, com alterações bioquímicas no LCR  
**E**  
presença de sinais e sintomas neurológicos e/ou oculares e/ou achados de imagem do SNC característicos da doença **E** desde que os achados não possam ser explicados por outra doença  
Fonte: DCCI/SVS/MS.  
O esquema de tratamento de primeira escolha e alternativo estão descritos no Quadro 19.  
**Quadro 19 – Tratamento da neurossífilis**  
|**NEUROSSÍFILIS**|**TRATAMENTO**|
|---|---|
|**Primeira escolha**|Benzilpenicilina potássica/cristalina, 3 a 4 milhões UI, 4/4h, IV ou por<br>infusão contínua, totalizando 18-24 milhões por dia, por 14 dias.|
|**Alternativa**|Ceftriaxona 2 g, IV, 1x/dia, por 10 a 14 dias.|  
Fonte: Adaptado de WHO (2016)<sup>47</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
**Indivíduos tratados para neurossífilis devem ser submetidos à punção liquórica de controle após seis meses do término do tratamento.** Na persistência de alterações do LCR, recomenda-se o retratamento e punções de controle em intervalos de seis meses, até a normalização da celularidade e VDRL não reagente. Em PVHIV, essa resposta pode ser mais lenta, sendo necessária uma avaliação caso a caso<sup>77</sup> .  
A normalização de testes não treponêmicos em amostras de sangue (queda da titulação em pelo menos duas diluições ou sororreversão para  
não reagente) pode ser um parâmetro a ser considerado como resposta ao tratamento da neurosífilis, principalmente em um cenário de indisponibilidade de realização da punção lombar<sup>77</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Como referido nas seções anteriores, as gestantes com sífilis, devido à grande probabilidade de transmissão vertical, devem ser tratadas com cuidados especiais, conforme segue:  
- As gestantes devem ser testadas para sífilis, no mínimo na primeira consulta de pré-natal, no início do terceiro trimestre e na internação para o parto, em caso de aborto/natimorto ou história de exposição de risco/violência sexual<sup>11</sup> .  
- As gestantes com testes rápidos reagentes para sífilis deverão ser consideradas como portadoras de sífilis até prova em contrário;  
-  
-  
- Na ausência de tratamento adequado, recente e documentado, deverão ser tratadas no momento da consulta;  
- Existe evidência de que os benefícios suplantam o custo e o risco do tratamento com benzilpenicilina benzatina;  
- Ainda nesse momento, deve ser solicitado, ou preferencialmente colhido, teste não treponêmico (linha de base), para seguimento sorológico;  
- O retardo do tratamento no aguardo de resultados de teste complementar faz com que o profissional perca tempo e a oportunidade de evitar a transmissão vertical da sífilis;  
- O monitoramento sorológico deve ser mensal até o termo. Após o parto, o seguimento é trimestral até o 12º mês de acompanhamento (3, 6, 9, 12 meses);  
- A gravidez também é um assunto de homens. Estimular a participação do pai/parceiro durante todo o processo de pré-natal é essencial para o bem-estar biopsicossocial da mãe, do bebê e dele próprio;  
28  
- É fundamental a implementação do pré-natal do parceiro, conforme o “Guia do pré-natal do parceiro para profissionais de saúde”<sup>78</sup> .  
Para mais informações sobre o tratamento da(s) parceria(s) sexual(is), consultar o item 5.10 – Sífilis: parceria sexual.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
A prevalência de sífilis é maior entre as PVHIV que entre as pessoas negativas para o HIV. Uma revisão sistemática mostrou uma mediana de 9,5% de prevalência desse agravo entre as PVHIV<sup>79</sup> . Modelos que demonstraram o impacto da TARV na epidemia de HIV não incluíram o estudo desse impacto sobre as outras IST<sup>80</sup> . Estudos sugerem que a alta taxa de sífilis é mais provavelmente causada por fatores comportamentais que por fatores imunológicos<sup>81–83</sup> .  
A aquisição de sífilis e outras IST em PVHIV confirma a vulnerabilidade e a falha na adesão às orientações de prevenção. Pessoas com comportamento sexual de alto risco muitas vezes têm acesso limitado aos cuidados de saúde, devido a questões econômicas e/ou estigmatização social<sup>84</sup> .  
_A atuação dos profissionais de saúde, por meio das orientações preventivas, suspeição clínica, rastreio dos assintomáticos, tratamento e seguimento adequado, é fundamental para controle da sífilis no país, considerando a epidemia desse agravo e sua alta prevalência nas PVHIV._  
Úlceras genitais podem facilitar a transmissão sexual e perinatal do HIV. A quebra da integridade do epitélio mucoso ocasiona uma via de entrada para o vírus. Além disso, há um influxo local de linfócitos T-CD4+ e aumento da expressão de correceptores CCR5 em macrófagos, aumentando a probabilidade de aquisição do HIV.  
Há relatos isolados de comportamento anormal dos testes imunológicos de sífilis e resposta terapêutica atípica em PVHIV. As recomendações diagnósticas para essa população, no entanto, são as mesmas utilizadas para pessoas sem infecção por HIV. O tratamento com benzilpenicilina benzatina deve ser realizado de acordo com a fase clínica da doença.  
Recomenda-se mais atenção às complicações oculares e neurológicas, que tendem a ser mais frequentes nos pacientes com HIV, pelo menos naqueles não tratados ou tratados de forma não adequada. **Todas as PVHIV diagnosticadas com sífilis devem ser submetidas a um exame**  
**neurológico minucioso.** Em caso de sinais ou sintomas oculares e/ou neurológicos, a consulta com especialista não deve ser retardada e a punção lombar passa a ser uma imposição diagnóstica.  
O curso clínico da sífilis pode ser alterado pela coinfecção com HIV, com a ocorrência de manifestações atípicas ou mais agressivas. As  
apresentações clínicas de cada estágio geralmente são semelhantes às dos pacientes sem infecção pelo HIV. No entanto, podem ocorrer:  
- Desenvolvimento de cancros múltiplos e profundos ou atípicos, os quais apresentam resolução mais lenta;  
- Maior frequência de sobreposição de estágios; concomitância de lesões primárias e secundárias no momento do diagnóstico;  
- Maior frequência de forma clínica de secundarismo; habitualmente, os sintomas constitucionais são mais exuberantes e as lesões cutâneas mais agressivas;  
- Predisposição para o desenvolvimento de lesões oftálmicas e neurológicas.  
O diagnóstico de sífilis em PVHIV é realizado da mesma forma que nos indivíduos sem infecção. Quando os achados clínicos são sugestivos  
de sífilis, mas os testes imunológicos são não reagentes ou as interpretações deixam dúvidas, formas alternativas de diagnóstico, como biópsia da lesão e microscopia de campo escuro de material da lesão, podem ser úteis para o diagnóstico<sup>85</sup> .  
Os casos de neurossífilis meningovascular de apresentação mais precoce são mais prevalentes em pessoas com infecção pelo HIV, particularmente naquelas com aids. A neurossífilis deve ser considerada no diagnóstico diferencial das encefalites.  
Já entre pacientes assintomáticos, é importante atentar para a escassez de dados científicos de qualidade para orientar a tomada de decisão<sup>86</sup> . Desconhece-se a importância clínica e prognóstica das anormalidades laboratoriais do LCR nesses pacientes. Alterações liquóricas são comuns em pessoas coinfectadas com HIV nos estágios iniciais de sífilis, mesmo sem sintomas neurológicos. Vários estudos demonstram que as alterações do LCR estão associadas a contagens de LT-CD4+ abaixo de 350 céls/mm<sup>3</sup> ou em combinação com titulações de VDRL maiores ou iguais a 1:32<sup>87–90</sup> .  
29  
No entanto, a realização rotineira da punção lombar, sem sinais ou sintomas neurológicos, não foi associada a melhores desfechos clínicos. O Quadro 20 destaca as recomendações para punção lombar em PVHIV, a fim de investigar neurossífilis.  
**Quadro 20 – Indicação de punção lombar, em PVHIV, para pesquisa de neurossífilis**  
||Presença de sintomas neurológicos ou oftalmológicos.|
|---|---|
||Evidência de sífilis terciaria ativa.|
||Após falha ao tratamento clínico, independentemente da história sexual.|
|Fon|te: DCCI/SVS/MS.|  
Os critérios diagnósticos e de tratamento para PVHIV são os mesmos utilizados para pacientes negativos para o HIV.  
Para mais informações, consultar o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos<sup>91</sup> , disponível em: www.aids.gov.br/pcdt.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Um terço das parcerias sexuais de pessoas com sífilis recente desenvolverão sífilis dentro de 30 dias da exposição. Portanto, além da avaliação clínica e do seguimento laboratorial, se houve exposição à pessoa com sífilis (até 90 dias), recomenda-se oferta de tratamento presuntivo a esses parceiros sexuais (independentemente do estágio clínico ou sinais e sintomas), com dose única de benzilpenicilina benzatina 2,4 milhões, UI, IM (1,2 milhão de UI em cada glúteo).  
Todas as parcerias devem ser testadas. Quando o teste de sífilis for reagente, recomenda-se tratamento de sífilis adquirida no adulto, de acordo com o estágio clínico.  
A avaliação e tratamento das parcerias sexuais é crucial para interromper a cadeia de transmissão da infecção.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: Geral -->
Dividido em seis lâminas, trata-se de uma ferramenta de apoio à decisão clínica que sintetiza as recomendações para sífilis adquirida e sífilis em gestantes. Com o uso desse algoritmo pelos profissionais de saúde, de medicina ou de enfermagem, será possível testar, diagnosticar, tratar, notificar e monitorar os casos de sífilis adquirida e em gestantes.  
As cinco primeiras lâminas abordam a investigação para o diagnóstico de sífilis. São lâminas que procuram contemplar a diversidade de realidades do Brasil. O número de lâminas utilizadas para o diagnóstico dependerá da estrutura do serviço em que o profissional de saúde trabalha (disponibilidade de teste rápido, rede laboratorial mais estruturada ou menos estruturada).  
A **lâmina 1** aborda quem, quando e como testar para sífilis. Reforça-se, aqui, a importância da implantação e utilização do teste rápido para sífilis (teste treponêmico de alta sensibilidade e especificidade, realizado no local) já no primeiro atendimento, de forma oportuna e sem necessidade de encaminhamento ou agendamento.  
A **lâmina 2** orienta a interpretação e conduta frente aos testes treponêmicos ou não treponêmicos não reagentes. Já as **lâminas 3 e 4** trazem a interpretação e conduta após teste rápido treponêmico (lâmina 3) e não treponêmico reagente (lâmina 4). Na lâmina 3 (teste rápido reagente), o próximo passo indicado é “Solicitar diagnóstico de sífilis após TR reagente”. Dessa forma, o laboratório não iniciará o fluxograma de diagnóstico por um teste treponêmico (já realizado pelo serviço) e realizará diretamente um teste não treponêmico (os mais disponíveis no Brasil são o VDRL e RPR).  
A **lâmina 4** indica a conduta diante de um teste não treponêmico reagente isolado. Assim, o fluxograma de diagnóstico deverá ser continuado com a realização de um teste rápido treponêmico. O conjunto de resultados dos dois testes, associados à apresentação clínica e histórico epidemiológico, definirão a conduta clínica.  
A **lâmina 5** traz a alternativa, na indisponibilidade do teste rápido, de solicitação de diagnóstico de sífilis à rede laboratorial (fluxo laboratorial). Nesse caso, o laboratório já realizará o fluxograma completo (teste treponêmico e não treponêmico, quando for o caso). Dessa  
30  
maneira, evita-se que o paciente necessite retornar ao laboratório para ser novamente testado após o primeiro teste para sífilis reagente, já que o laboratório realizará o segundo ou o terceiro teste com a mesma amostra.  
A **lâmina 6** contém as condutas de tratamento e monitoramento de sífilis. Estão na mesma lâmina para reforçar que tão importante quanto tratar é garantir a segurança do paciente e de suas parcerias sexuais por meio do monitoramento adequado. Os testes recomendados para o monitoramento são os não treponêmicos. Para o monitoramento, a pessoa deverá realizar preferencialmente o mesmo tipo de teste, no mesmo laboratório, de maneira a minimizar diferenças de interpretação do resultado laboratorial.  
No enfrentamento da epidemia de sífilis, necessita-se uma alta suspeição clínica, com testagem de pacientes assintomáticos e tratamento e monitoramento de todos os casos e de suas parcerias sexuais. Nunca se está diante de apenas um caso de sífilis – sempre são pelo menos duas pessoas infectadas. Muitas vezes se trata de toda uma rede sexual infectada. Conversar com o paciente sobre sua prática sexual e suas parcerias sexuais é realizar uma boa assistência à saúde.  
Para o combate à sífilis congênita, o tratamento da gestante com benzilpenicilina benzatina após um teste reagente é fundamental. Cada semana que uma gestante com sífilis passa sem tratamento é mais tempo de exposição e risco de infecção para o concepto. A benzilpenicilina benzatina é segura e a melhor opção para o tratamento da mãe e da criança. Garantir o tratamento adequado da gestante, além de registrá-lo na caderneta de pré-natal, é impedir que o recém-nascido passe por intervenções biomédicas desnecessárias que podem colocá-lo em risco, além de comprometer a relação mãe-bebê.  
31  
<!-- Start of picture text -->
otste<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
**Figura 6 – Algoritmo para manejo da sífilis adquirida e sífilis em gestantes**  
Observação: Slides editáveis em anexo  
<!-- Start of picture text -->
Lamina 1—- Quem, quando e como testar para sifilis<br>Testar<br>para sifilisem uma ou maisdasseguintessituagdes: = 3 4<br>* Sempre: ae , , . i<br>= Pessoa com episédio de exposicdo sexual sem uso de preservativo (avaliar também outras IST, hepatites virais, HIV e PEP)<br>- Pessoa em situacao de violéncia sexual (avaliar também outras IST, hepatites virais, HIV e PEPS<br>- Pessoa com diagnostico de outras IST _<br>~- Gestante Pessoa comna parcerias)sexuallis)primeira consulta de compré-natal, diagndsticono inicio de do siflsterceiro trimestre (28° semana) e no momento do parto (ou em caso de aborto/natimorto).|<br>- Puérpera sem registro de teste para sffilis no pré-natal<br>= Mulher com diagnéstico de abortamento espontaneo/natimorto<br>~ Pessoa com sinais clinicos de sffilis:<br>*=*Sinais UlceradeLinfadenopatia cabelo,deanogenitalsffilisespecialmente generalizada/localizadasecundaria:sem causaem erupcdoaparenteclareiras), cutaneasemsintomas (principalmentecausageraisdeterminada(mal-estar,; em palmasfebre, dascefaleia, mos.  eastenia) plantas dos pés),eolesdes orais, lesdes vegetantes (em especial-  nos genitais),_ alopecia; (perda<br>~ Demais situacées em que a avaliacdo clinica demonstrar necessario<br>*Anualmente:- Adolescente/jovem_ <30 anos, com vida; sexual ativa;<br>*Acada= Gay, ~ PessoaHSH, 6 vivendo meses:  trabalhadoycom H (a) do sexo, travesti/transexual,;  pessoa que usa élcool/outras;  drogas ou pessoa privada;  de liberdade;<br>* Acada 3 meses: .. dee ee<br>~ Pessoa em uso de PrEP e ultimo teste para sifilis hd mais de 3 meses<br>rs<br>Escolher qual teste realizar<br>I<br>Osservico de satide tem teste rapido para sffilis disponivel?<br>sim no<br>Realizar teste rapido Solicitar “Diagnéstico de sifilis” ao laboratério®<br>Se o teste répido for nao reagente, ver lamina 2; sé o teste rapido for reagente, ver lamina 3 Ver lamina 5<br>+ Articularamostras junto de sangu ao s e rvico e &total colhidas coordenacopor puncdolocaldigital a implemou v en osa.tagaoTém do teste ra vant a pido.gem de Os serem testesrealrap i zadosdos so no praticos momento e deda facilconsulta, execuglo,possibilitando com leituratratamento do resultadoimediato. em, no maximo, 30 minutos. Podem ser realizados com<br>20 laboratério realizar a investigacdo para diagnéstico de acordo com sua disponibilidade de testes imunoldgicos.<br><!-- End of picture text -->  
<!-- Start of picture text -->
Lamina 2 — Investigagao para diagnostico de sifilis<br>Teste répido (ou outro teste treponémico) ou VDRL/RPR (ou outro teste nao treponémico) ndo reagente<br>O paciente tem dlcera anogenital?<br>Nao Sim<br>O paciente teve parceria sexual (nos ultimos 3 meses) com diagnéstico de sifilis e nao foi tratado? eiiterecente<br>Nao i + Tratar’ para sifilis recente (ver lamina 6).<br>sim * Realizar teste para sifilis' apds 30 dias.<br>Teste negativo para sifilis Sifilis recente + AvaliarParcerias tratat sexuais para (ultimos sifils recente3 meses). 3s<br>* Adolescente/jovem <30 anos com vida sexualmente ativa: testar para * Tratar’ para sifilis recente (ver lamina 6).<br>sifilis anualmente. * Realizar teste para sifilis' apds 30 dias.<br>* Gay, HSH, trabalhador{a) do sexo, travesti/transexual, pessoa que usa<br>dicool/outras drogas ou pessoa privada de liberdade testar para sifilis<br>a cada 6 meses.<br>* Pessoa vivendo com HIV: testar para sifilis a cada 6 meses.<br>* Pessoa em uso de PrEP: testar para sifilis a cada 3 meses. -<br>* Gestante: repetir<br>tiver sido realizado, o testee no nomomento terceiro do trimestreparto (ou (282em semana),caso de  se jd ndo<br>aborto/natimorto).<br>4Na indisponibilidade do teste rapido, deve-se solicitar “Diagndstico de sifilis” a0 laboratério.<br><!-- End of picture text -->  
b 4 - Lé Conitec ome  
oe a pe | a  
<!-- Start of picture text -->
Lamina 3 — Investigagado para diagnostico de sifilis apds teste rapido reagente<br>___Testerépidoreagente<br>Solicitar “Diagnéstico de sffilis apds TR reagente””<br>* 960adequadopacjentepara apresentasifilis: tratar® Glcgraparaanogenitalsifilis recente ou sinais/sintomas(veja lamina  de6) e sfilsnotificar. secundaria, ou teve parceria sexual com diagnéstico de siflis, o € gestante sem registro de tratamento prévio<br>VORURPRreagente—~=~=~*~S~S~S«~SRPR reagente VDRI/RPRnioreagente —=~=~=~SOS*~*~S*™S<br>Teste treponémico (metodologia # do primeiro)<br>Reagente ou teste nao disponivel Nao reagente<br>Paciente tem historia e/ou registro de tratamento prévio para sifilis?<br>Nao Sim Provavel falso-reagente no<br>Paciente tem VORURPR apds tratamento prévio, para comparagio? primeirarapido) realizado teste teste<br>I<br>Nao * Se o paciente apresenta<br>sim Ulcera anogenital ou teve<br>VDRL/RPR —— oe parcerja sexual (nos ultimos 3<br>0 ultimo para  VORL/RPR sifilis?atual t( e x.:m realizado.ap6s  titulardoVDRL/RBR peloatual  tratamento  menos1:16 2 diluigdese anterior prévio adequado  maior1:4)  que| | sti:ineses)com dlagnostico“aa,  de<br>sim - Tratar para sifilis recente_<br>No {verratado. lamina 6), se ainda ndo<br>Paciente apresenta Ulcera anogenitalou | | _ real Spido?<br>Sinais/sintomas de sifilis secundaria?? Repglizan fests iipido? para<br>Sim Nao<br>Paciente apresenta Ulcera anogenital ou sinais/sintomas de sifilis secundaria??<br>Néo sim<br>** AvaliarTratar sifilisesg,tratartardiapara (versifilisSifilis laminarecente tardia 6) eas notificar.parcerias sexuais + Tratartratado, parae notificar.sifiliscn.  recente__ Sifilis (ver recente lamina 6), se aindandoa | |* VerCicatriz lamina sorolégica1.<br>(ltimos 3 meses). * Avaliar e tratar para sifilis recente as parcerias sexuais<br>(ultimos 3 meses).<br>* Se 0 paciente for HIV positivo, realizar exame neurologico. Em caso de sinais/sintomas oculares/neurolégicos, encaminhar, solicitar puncao lombar e investigar neurossifilis.<br>‘2 Nessa solicitacdo, 0 laboratorio ira realizar um teste ndo treponémico. Os mais disponiveis no Brasil sdo 0 VDRLe o RPR.<br>lesdesOs sinais/sintomasvegetantes (em deespecialsifls secundarianos genitais), ocorremalopeciaentre(perda6 semanasde cabelo, a6 mesesespecialmente ap6s acicatrizagaoem clareiras), da ulcerasintomasprimariaegerais inclyem(mal-estar, erupeiofebre, cutanea(principalmentecefaleia, astenia).  em palmas das méos e plantas dos pés,lesdes orais,<br>3.Na indisponibilidade do teste rapido, deve-se solicitar “Diagnéstico de Sifilis” ao laboratério.<br><!-- End of picture text -->  
Sits  
=  
<!-- Start of picture text -->
Lamina 4 — Investigacdo para diagnostico de sifilis iniciado com teste nao treponémico<br>[_VORL/RPRVDRL/RPR (ou(ou outrooutro testeteste ndondo  treponémico)treponémico) reagentereagente |<br>* Seadequado0 paciente, para apresentasifilis: tratarulcera, para anogenitalsifilis ,recente ou sinals/sintomasae(ver lamina 6) dee notificar. siflis“el  secundéria®,. _ Realizar ou tevetesteparceria rapido* sexual com diagnésticoae de sffills,— ou 4é gestante sem registro.  de tratamento prévioses<br>Teste rapido reagente Teste rapido nao reagente<br>Solicitar outro teste treponémico (metodologia # do teste rapido)<br>Reagente ou teste nao disponivel Nao reagente<br>Paciente tem histéria e/ou registro de tratamento prévio para sifilis? Provavel falso-reagente no<br>teste nado treponémico<br>No * Investigari outras causas<br>Paciente tem VDRL/RPR prévio apés tratamento adequado, para comparacao? * Se o paciente apresenta<br>icera anogenital ou teve<br>Nao Sim parceria sexual com<br>©VDRL/RPRUltimo VDRL/RPR sual temrealizado titulagsoapés pelo tratamento menos 2 diluigdesprévio  maioradequado que -Gt ltimo i Tratar®agno s tico5 mes  dpara es  sfilsifilis):  (nosrecente<br>para sifils? (ex: VORL/APR atual 1:16 ¢ anterior 1:4) (ver lamina 6), se ainda<br>nl nao tratado.<br>Sim [oN<br>- Realizar teste rapido? para<br>Paciente apresenta Uicera anogenital ou sifilis apés 30 dias.<br>sinais/sintomas de sifilis secundaria??<br>Paciente apresenta dicera anogenital ou sinais/sintomas de sifilis secundaria’? sim Nao<br>SifilisNaotardia , Sifilisrecente.Sim *VerSicanrizlaminasorolégica1. |<br>*sAvalt Tratar’SeanaStare para sffilisa tardiaa Seayfil (vera” Tecente lamina 2s parcerias6) e notificar.; +. Tratar Avalan€notificar.meses). para tratarsffilis para recente sflis recente (ver lamina as parcerias sexuals 6), se ainda nao (iltimos tratado, 3 e<br>* Se o paciente for HIV positivo, realizar exame neurolégico:<br>= Em caso de sinais/sintomas oculares/neuroldgicos: encaminhar, solicitar puncao lombar e investigar neurossifilis.<br>208Na sinaig/sintomasindisponibilidade dedo sfilis teste Secundsria.rapido, deve-se ocorremrealizar entrea6 semanas.a 6solicitacSo “Diagndstico meses ands de a Sifilis”cleatriza¢ao ao laboratério. a ulcers priméria e incluem erup¢so cutdnea (principalmente7  se em palmas das mose plantas dos pés), lesbes orals, lesbes<br>bdVelaVvegetantesconduta em para especial tratamento nos genita na l s,amina alopecia 6.  (perda de cabelo) especialmente em clareiras, sintomas gerais (mal-estar, febre, cofalela, astenia).<br><!-- End of picture text -->  
otste =  
<!-- Start of picture text -->
Lamina 5 — Investiga¢ao para diagnéstico de sifilis iniciado com Fluxo Laboratorial'<br>Teste treponémico laboratorial (FTA-Abs, ELISA/EQL/CMIA, TPHA/TPPA/MHA-TP) reagente<br>VDRL/RPR reagente VDRL/RPR nao reagente<br>‘Teste treponémico (metodologia # do primeiro)<br>Reagente ou teste nao disponivel Nao reagente<br>Paciente tem historia e/ou registro de tratamento prévio para sifilis? Provavel falso-reagente no<br>fg Sa OO primeiro testerealizado treponémico<br>Paciente tem VDRL/RPR apés tratamento prévio, para comparacao? Been ene<br>tT i parceria sexual (nos tltimos 3<br>Nao meses)sifilis:  com diagnéstico de<br>VDRL/RPR atual tem titulacdo pelo menos 2 diluigdes maior que pene<br>© ultimo VDRL/RPR realizado apos tratamento prévio adequado - Tratar para sifilis recente_<br>para sifilis? (ex.: VDRL/RPR atual 1:16 e anterior 1:4) (verratado.lamina 6), se ainda nao<br>Sim [No i spido?<br>Paciente apresenta tlcera anogenital ou| | - _SifilisRealizar teste apos 30 dias.rapido? para<br>sinais/sintomas de sifilis secundaria??<br>LF faetentPacient e tem  tlceraera anoano genital ou sina il s/ Ss intomas de  sifilisSTs se cundaria??cundaria?__<br>Nao Sim Sim Nao<br>* Tratar sifilis tardia (verSffilis lamina tardia6) e notificar. + Tratar para sifilis recenteSifilis (verrecente lamina 6), se ainda nao everCicatriz Sanesorolégica Sorolee<br>* Avaliar e tratar para sifilis recente as parcerias sexuais tratado,e notificar. ; ;<br>(ultimos 3 meses). * Avaliaré tratar para sifilis recente as parcerias sexuais<br>(ltimos 3 meses).<br>* Se o paciente for HIV positivo, realizar exame neuroldgico:<br>= Em caso de sinais/sintomas oculares/neuroldgicos: encaminhar, solicitar pungdo lombar e investigar neurossffilis.<br>10 laboratério realizar a investigac3o para diagnéstico de acordo com sua disponibilidade de testes imunolégicos.<br>2 Na indisponibilidade do teste rapido, deve-se solicitar “Diagnéstico de Sifilis” ao laboratério. a ; ;<br>vQGeiORieese ess tnd GEAUOIA SLT Terdsede SBE esp eeNeAe Sk CAA mee ge fina eG GELS” BETS ange nePaImente em palmas das mos e plantas dos pd) labs ora, lesdes<br><!-- End of picture text -->  
etste Conitec TNRelle  
<!-- Start of picture text -->
e 2 e<br><!-- End of picture text -->  
~| —  
<!-- Start of picture text -->
Lamina 6 — Tratamento e monitoramento de sifilis<br>[___ Sffilis recente (priméria, secundériaelatente recente) tardia (tercidria, latente tardia ou latente com duragdo ignorada)—si<br>* howverAplicar, contraindicagao’na mesma consulta, a Benzilpeniclinadose unica de benzatinabenzilpenicilinae paciente benzatina nao for2,4MUI gestante/IM. Se * Aplicar,semanalmentena mesmapor maisconsulta, 2 semanas.primeira Sedose dehouver benzilpenicilinacontraindicacao’2,4MUI a benzilpenicllinaIM e repetir e<br>* estiver amamentando, prescrever doxiciclina 100mg 12/12h, por 15 dias. paciente nao for gestante/estiver amamentando, prescrever doxiciclina 100mg 12/12h<br>* SegemSe pacientepaciente anafilaxia forfor apos gestante/estivergestante/estiver uso de penicilina,amamentando amamentando aplicar dose etiver e tive tnicahistoria historia de peniclinade de reagaoreagaobenzatinagrave/anafilaxia leve/moderada 2,4MUIIM. |_| Seporsem paciente 30anafilaxia dias. forapds gestante/estiveruso de penicilina, amamentandoaplicar primeira e tiver historiadose de debenzilpenicilina reacdo leve/moderada2,4MUI IM<br>apos uso de penicilina, encaminhar/discutir com especialista. e repetir semanalmente por mais 2 semanas.<br>3pds uso de penicilina, encaminhar/discutir com especialista,<br>| + Se paciente for gestante/estiver amamentando e tiver historia de reacSo grave/anafilaxia<br>* Febre,500mg dor6/6h,de secabeca,necessério.dor musculare rash podem;  ocorrer apés tratamento e melhoram em 1-2 dias, espontaneamente (Reagao deJarish-Herxheimer).| Prescrever paracetamol ou dipirona<br>* Tratar parceria(s) (dos ultimos 3 meses) para sifilis recente (independentemente de sintomas/resultado dos testes) e testar para sifilis na mesma semana. Interpretar resultados para<br>decidir continuar tratamento para sifilis tardia. ;<br>* Aregra é de que o intervalo entre as doses seja de 7 dias para completar o tratamento. No entanto, caso esse intervalo ultrapasse 14 dias, o esquema deverd ser reiniciado. ;<br>+ Senatal. gastante e em tratamento completo para 0 estagio clinico da sffls com penicilina benzatina e INICIADO ate 30 dias antes do parto: registrar tratamento adequado na carteira de pré-<br>+ Em caso de sinais e sintomas neurolégicos/oftalmolégicos ou sifilis tercidria ativa: solicitar puncao lombare investigar neurossifilis?.<br>Solicitar ao laboratério “Monitoramento do tratamento de sifilis”> comTepetir3, 6, até9 e completar12 meses. 1Em anocaso(3, 6,de gestante,9€ 12 meses).repetir mensalmente (registrar na carteira de pré-natal) e, apds 0 parto,<br>Monitoramento de sifilis<br>Comparar novo VDRL/RPR com VDRL/RPR prévio<br>TNDRL/RPR* VDRL/RPR atualatual é pelopelo menos menos 22  diluicBesdiluig¢ées menoresmenores queque o do o do dlagndstcodiagnéstico (ex.:(ex.: anterioranterior 1:32, atual 1:32, atual 18},1:8), 12§ meses meses ands tratamentoapds tratamento paraparasiflissifilis recente,tardia  ou<br>Nao |<br>Paciente mantém/desenvolveutratamento incompletonova tilcerado paciente/parceria(s)anogenital ou sinais/sintomasou houve novade sifilisexposi¢do? secundaria?ou ocorreu<br>a No<br>*Se HIV positivo, retratar paciente e parceria(s) para sifilis recente ou tardia (de acordo + Repetir VDRL/RPR trimestralmente até completar 12 meses. Se ndo houver aumento de<br>* Secom HIV cada negativo, caso}, solicitarretratar puncaopacientelombare parceria(s) e investigarpara sffilsneurossifilis’. recente ou tardia (de acordo titulagdoassintomatico em pelo no periodo, menos 2 iluicdesdar alta. (ex: anterior 1:4, tual 21:16)/ e persistir ;<br>comsolicitar cadapuncao caso). Emlombar casoe de tratameinvestigar n eurossifilis*.to comp leto e sem nova exposicao, também * Sr e petir gestante, VDRL/RPRregistrar mensalmente. tratamento adequadoApos parto, e manter queda  seguimento da titulaciio na até carteira  completar de pré-natal, 12 meses.<br>parceria(s)Se houver paraqualquersifilisVRL/RPRrecente  comou tardia pelo(de menosacordo 2 diluigGes com cada maiorcaso). queSe anteriortratamentoou persistencia/novoscompleto e sem nova sinaisexposi¢do de sflis:confirmad nvestig a ,rreexposicdo/trtambém solicit a rtamentopun¢ao incompletoelombare investigar retratarneurossffilis?. paciente e<br>12m30s Contraindicacao testes caso de nao diagnéstico treponémicos& benzilpenicilinade neurossifilis, laboratoriaisbenzatina:‘encaminhat/Aiscutir (VDRL/RPR/USR/TRUST)presenca de silicone com especialista‘sto (prétese 08 testes ou siliconepara internacao utilizados liquido para industrial) ohospitalar monitoramento nose tratamento. locais do recomendados tratamento de para sifilis. aplica¢do Orienta-se IM realizar da medicacaoa mesma e alergia/anafilaxia metodologia durante apés uso todo da o penicilina. periodo de monitoramento.<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A OMS estima que a ocorrência de sífilis complique um milhão de gestações por ano em todo o mundo<sup>92</sup> , levando a mais de 300 mil mortes fetais e neonatais e colocando em risco de morte prematura mais de 200 mil crianças. No Brasil, nos últimos cinco anos, foi observado um aumento constante no número de casos de sífilis em gestantes, sífilis congênita e sífilis adquirida. Esse aumento pode ser atribuído, em parte, à elevação nos números de testagem, decorrente da disseminação dos testes rápidos, mas também à diminuição do uso de preservativos, à redução na administração da penicilina na Atenção Básica e ao desabastecimento mundial de penicilina, entre outros.  
A sífilis congênita (SC) é o resultado da transmissão da espiroqueta do _Treponema pallidum_ da corrente sanguínea da gestante infectada para o concepto por via transplacentária ou, ocasionalmente, por contato direto com a lesão no momento do parto (transmissão vertical)<sup>93–95</sup> . A maioria dos casos acontece porque a mãe não foi testada para sífilis durante o pré-natal ou porque recebeu tratamento não adequado para sífilis antes ou durante a gestação<sup>96–98</sup> .  
A transmissão vertical é passível de ocorrer em qualquer fase gestacional ou estágio da doença materna e pode resultar em aborto, natimorto, prematuridade ou um amplo espectro de manifestações clínicas; apenas os casos muito graves são clinicamente aparentes ao nascimento.  
Entre mulheres com sífilis precoce não tratada, 40% das gestações resultam em aborto espontâneo<sup>99</sup> . Estima-se que, na ausência de tratamento eficaz, 11% das gestações resultarão em morte fetal a termo e 13% em parto pré-termo ou baixo peso ao nascer, além de pelo menos 20% de recém-nascidos (RN) que apresentarão sinais sugestivos de SC<sup>100,101</sup> .  
Portanto, trata-se de uma doença que pode ser prevenida, sendo possível alcançar a eliminação da SC por meio da implementação de estratégias efetivas de diagnóstico precoce e tratamento de sífilis nas gestantes e suas parcerias sexuais<sup>102</sup> . Além disso, o risco de desfechos desfavoráveis à criança será mínimo se a gestante receber tratamento adequado e precoce durante a gestação.  
A sífilis em gestantes e a SC são agravos de notificação compulsória. Os critérios de definição de caso sofreram modificações, em consonância com os critérios adotados pela Opas e pela OMS, e estão apresentados na seção 5.5.  
Informações mais detalhadas sobre sífilis em gestantes e sífilis congênita podem ser encontradas no “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais”<sup>11</sup> .  
- **6.1 . Avaliação inicial da criança exposta ou com sífilis congênita**  
A avaliação inicial da criança exposta à sífilis ou com sífilis congênita é realizada especialmente na maternidade/casa de parto, considerando os seguintes aspectos:  
- Histórico materno de sífilis quanto ao tratamento e seguimento na gestação;  
- Sinais e sintomas clínicos da criança (na maioria das vezes ausentes ou inespecíficos);  
- Teste não treponêmico de sangue periférico da criança comparado com o da mãe.  
Não existe uma avaliação complementar que determine com precisão o diagnóstico da infecção na criança. Assim, esse diagnóstico exige uma combinação de avaliação clínica, epidemiológica e laboratorial<sup>103</sup> .  
_Considera-se tratamento adequado para sífilis durante a gestação: tratamento completo para estágio clínico da sífilis com benzilpenicilina benzatina e iniciado até 30 dias antes do parto._  
_Gestantes que não se enquadrarem nesses critérios serão consideradas inadequadamente tratadas._  
Ressalta-se que, para se considerar tratamento adequado, toda gestante tem que iniciar o tratamento pelo menos 30 dias antes do parto, e que o esquema terapêutico para o estágio clínico definido no diagnóstico já tenha sido finalizado no momento do parto.  
O tratamento das parcerias sexuais não entra nos critérios epidemiológicos de definição de casos de sífilis congênita<sup>104</sup> . Entretanto, faz-se imprescindível esse tratamento, considerando a possibilidade de reinfecção.  
Todas as crianças nascidas de mães diagnosticadas com sífilis durante o pré-natal necessitam de uma avaliação criteriosa no momento do parto, com anamnese, exame físico e teste não treponêmico. Essa avaliação do profissional de saúde pode acrescentar outros dados e gerar uma conclusão de tratamento inadequado para sífilis durante a gestação, mesmo se enquadrando inicialmente dentro dos critérios epidemiológicos de tratamento adequado.  
38  
O histórico de tratamento e seguimento da sífilis na gestação devem estar documentados em prontuário médico ou na caderneta da gestante, não se recomenda considerar apenas a informação verbal.  
_Para fins clínicos e assistenciais, alguns fatores são considerados para o tratamento adequado da GESTANTE com sífilis, como: > Administração de penicilina benzatina; > Início do tratamento até 30 dias antes do parto; > Esquema terapêutico de acordo com o estágio clínico da infecção; > Respeito ao intervalo recomendado entre as doses; > Avaliação quanto ao risco de reinfecção; > Documentação de queda do título do teste não treponêmico em pelo menos duas diluições em três meses, ou de quatro diluições em seis meses após a conclusão do tratamento (ex: antes, 1:16; depois, menor ou igual a 1:4) – resposta imunológica adequada._  
A resposta imunológica adequada durante a gestação pode não ser encontrada, uma vez que depende do momento em que tratamento foi  
realizado e essa resposta é mais comum quando os títulos não treponêmicos são mais altos no início do tratamento e em estágios mais recentes da infecção (sífilis primaria, secundaria e latente recente).  
A resposta imunológica pode ser mais lenta, sem que se configure falha de tratamento, com redução da titulação em duas diluições no intervalo de seis meses (sífilis primária, secundária e sífilis latente recente) ou 12 meses (sífilis tardia) após tratamento adequado. Muitas vezes, é difícil diferenciar entre reinfecção, reativação e resposta imunológica mais lenta, sendo fundamental a avaliação da presença de sinais ou sintomas clínicos novos, reexposição de risco, violência sexual, comorbidades, histórico do tratamento (duração, adesão e medicação utilizada) e exames laboratoriais prévios, para facilitar a elucidação diagnóstica.  
Nessa perspectiva, a conduta de identificar adequadamente crianças expostas (mas não infectadas) é tão importante quanto detectar e tratar  
crianças com sífilis congênita, para não submeter as crianças expostas a condutas desnecessárias, como exames invasivos e internações prolongadas.  
_É essencial garantir o seguimento de todas as crianças expostas à sífilis, excluída ou confirmada a doença em uma avaliação inicial, na perspectiva de que elas podem desenvolver sinais e sintomas mais tardios, independentemente da primeira avaliação e/ ou tratamento na maternidade._  
Diante do exposto, todas as crianças expostas à sífilis ou com sífilis congênita deverão ser avaliadas ao nascimento. A Figura 7 sistematiza o fluxo de notificação a partir da classificação do RN ao nascimento, com base apenas no histórico materno.  
**Figura 7 – Fluxo de notificação a partir da classificação do RN ao nascimento baseado apenas no histórico materno**  
Fonte: DCCI/SVS/MS.  
* **Tratamento adequado** : tratamento completo para o respectivo estágio clínico da sífilis, com benzilpenicilina benzatina, **iniciado** até 30 dias antes do parto. As gestantes que não se enquadrarem nesse critério serão consideradas como tratadas de forma não adequada. Nota: As crianças nascidas de mãe com cicatriz sorológica para sífilis antes da gestação DEVEM realizar teste não treponêmico na maternidade e, na ausência de sinais/sintomas, não necessitam de avaliação ou tratamento na maternidade.  
39

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O referenciamento da criança exposta no momento da alta compete à maternidade ou casa de parto. Toda criança exposta será necessariamente encaminhada para a Atenção Primária a Saúde (APS) de sua área de residência. A APS é o nível de atenção à saúde responsável pela puericultura e coordenação de cuidado dos usuários do SUS; e preferencialmente encontra-se estruturado pela Estratégia de Saúde da Família (ESF). No entanto, a criança exposta também pode ser acompanhada de forma complementar em um serviço de referência existente no território.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Na criança exposta à sífilis, para exclusão da possibilidade de sífilis congênita, o exame físico deve ser completamente normal; o achado de qualquer sinal ou sintoma deve levar à investigação complementar, e a sífilis congênita será incluída no diagnóstico diferencial. Vale lembrar que os sinais e sintomas de sífilis são inespecíficos e podem ser encontrados em outras síndromes congênitas, como toxoplasmose, rubéola, citomegalovírus (CMV), herpes vírus simplex (HSV), sepse neonatal, hepatite neonatal, hidropisia fetal, entre outros.  
Deve haver atenção específica aos sinais e sintomas mais clássicos, referentes às manifestações precoces de sífilis congênita.  
A presença de sinais e sintomas inclui a criança na classificação de SC sintomática, com necessidade de notificação compulsória e tratamento imediato.  
Além do exame físico, toda criança exposta à sífilis deve ser submetida a análise de exame laboratorial não treponêmico para exclusão da possibilidade de sífilis congênita.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Todos os RN nascidos de mãe com diagnóstico de sífilis durante a gestação, independentemente do histórico de tratamento materno, deverão realizar **teste não treponêmico no sangue periférico** . O sangue de cordão umbilical não deve ser utilizado, pois esse tipo de amostra contém uma mistura do sangue da criança com o materno e pode resultar em testes falso-reagentes.  
_A testagem simultânea da mãe e da criança, no pós-parto imediato, com o mesmo tipo de teste não treponêmico, configura o melhor cenário para a determinação do significado dos achados sorológicos da criança._  
No teste não treponêmico, um **título maior que o materno em pelo menos duas diluições** (ex.: materno 1:4, RN maior ou igual a 1:16) é indicativo de infecção congênita. No entanto, **a ausência desse achado não exclui a possibilidade do diagnóstico de SC.**  
Ressalta-se que o título do teste não treponêmico do recém-nascido igual ou inferior ao materno não exclui completamente a sífilis congênita, mesmo nas mães adequadamente tratadas. A decisão de investigar e tratar a criança não deve ser baseada apenas na definição de caso de notificação de sífilis congênita, mas também na avaliação clínica, epidemiológica e laboratorial da infecção.  
Alguns estudos demonstraram que menos de 30% das crianças com sífilis congênita têm resultado pareado do teste não treponêmico maior que o materno<sup>105,106</sup> ; portanto, é fundamental a realização do seguimento de todas as crianças.  
Não há correlação entre a titulação dos testes treponêmicos do RN e da mãe que possa sugerir SC. Dessa forma, não se recomenda a realização do teste treponêmico no bebê até os 18 meses<sup>107</sup> .  
O Quadro 21 apresenta os testes para a criança exposta à sífilis que devem ser realizados na maternidade ou casa de parto e no seguimento clínico e laboratorial.  
**Quadro 21 – Testes de sífilis para criança exposta à sífilis**  
|**TESTES DE**<br>**SÍFILIS**|**NA MATERNIDADE OU**<br>**CASA DE PARTO**|**NO SEGUIMENTO**|**O QUE AVALIAR**|
|---|---|---|---|
|**Teste não**|Coletar amostra de sangue|Realizar com 1,3,6,12 e 18|Não reagente ou reagente com titulação menor,igual ou|  
40  
|**treponêmico**|periférico do RN e da mãe<br>pareados para comparação.<br>Não realizar coleta de cordão<br>umbilical.|meses de idade.<br>Interromper o seguimento<br>laboratorial após dois testes<br>**não reagentes**consecutivos.|até uma diluição maior que o materno (ex.: 1:4 e<br>materno 1:2): baixo risco de SC.<br>Reagente com titulação superior à materna em pelo<br>menos duas diluições: sífilis congênita. Tratar conforme<br>a Figura 9 e realizar notificação imediata do caso de<br>sífilis congênita.<br>Espera-se que os testes não treponêmicos declinem aos<br>3 meses de idade, devendo ser**não reagentes**aos 6<br>meses nos casos em que a criança não tiver sido<br>infectada e seja apenas passagem passiva de anticorpo<br>materno. Se no seguimento ocorrer elevação de títulos<br>em duas diluições em teste não treponêmico ou<br>persistência da titulação aos 6 meses de idade, a criança<br>deverá ser investigada, submetida à coleta de líquor<br>(LCR), tratada para sífilis congênita com<br>benzilpenicilina potássica (cristalina) por 10 dias e<br>notificada a vigilância epidemiológica.<br>Idealmente, o exame deve ser feito pelo mesmo método<br>e no mesmo laboratório.|
|---|---|---|---|
|**Teste**<br>**treponêmico**|Não realizar|**NÃO é obrigatório.**<br>Pode ser realizado a partir<br>dos 18 meses de idade.|Um teste treponêmico reagente após os 18 meses idade<br>(quando desaparecem os anticorpos maternos<br>transferidos passivamente no período intrauterino)<br>confirma o diagnóstico de sífilis congênita. Um<br>resultado não reagente não exclui sífilis congênita nos<br>casos em que a criança foi tratada precocemente.<br>Crianças com teste treponêmico reagente após 18 meses<br>de idade e que não tenham histórico de tratamento<br>prévio deverão passar por uma avaliação completa,<br>receber tratamento e ser notificadas como caso de sífilis<br>congênita.|  
Fonte: adaptado de Workowski; Bolan (2015)<sup>33</sup> ; Hardy et al. (1970)<sup>108</sup> ; Rawstron et al. (2001)<sup>105</sup> ; Chang et al. (1995)<sup>109</sup> ; Lago et al. (2013)<sup>98</sup> .  
Existem testes treponêmicos capazes de detectar anticorpos do tipo IgM contra o _T_ . _pallidum_ no sangue do RN, que são anticorpos que não atravessam a barreira placentária e, portanto, quando presentes na amostra da criança, indicam resposta do sistema imune frente à sífilis, e a não transferência de anticorpos maternos. Porém, esses anticorpos IgM não são detectados em todos os casos de sífilis congênita e, dessa forma, um resultado negativo não exclui o diagnóstico de sífilis no RN. Por isso, não se recomenda a utilização de testes que detectam IgM, como, por exemplo, teste de absorção do anticorpo treponêmico fluorescente ( _Fluorescent Treponemal Antibody-Absorption -_ FTA-Abs) IgM e imunoensaios IgM para o diagnóstico da sífilis congênita<sup>33,110</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É esperado que os testes não treponêmicos das crianças declinem aos três meses de idade, devendo ser **não reagentes aos seis meses** nos casos em que a criança não tiver sido infectada ou que tenha sido adequadamente tratada. A resposta pode ser mais lenta em crianças tratadas após um mês de idade. Idealmente, o exame deve ser feito pelo mesmo método e no mesmo laboratório.  
A falha no tratamento em prevenir a ocorrência de SC é indicada por:  
- Persistência da titulação reagente do teste não treponêmico aos seis meses de idade;  
E/OU  
- Aumento nos títulos não treponêmicos em duas diluições ao longo do seguimento (ex.: 1:2 ao nascimento e 1:8 após).  
Nesses dois casos, as crianças serão notificadas para sífilis congênita e submetidas à punção lombar para estudo do LCR com análise do VDRL, contagem celular e proteína, devendo ser tratadas durante dez dias com penicilina parenteral (a escolha do tratamento dependerá da presença ou não de neurossífilis), mesmo quando houver histórico de tratamento prévio.  
O seguimento de crianças expostas à sífilis pode ser feito na Atenção Básica<sup>111</sup> , com atenção mais cuidadosa no monitoramento de sinais e sintomas sugestivos de sífilis congênita, além do monitoramento laboratorial com teste não treponêmico em 1, 3, 6, 12 e 18 meses de idade.  
A partir dessa idade, se não houver achados clínicos e laboratoriais, exclui-se sífilis congênita.  
41  
A garantia do seguimento clínico e coleta de teste não treponêmico no 1<sup>o</sup> mês de vida é particularmente importante. O referenciamento da maternidade ou casa de parto deve levar em consideração, entre outras questões, a rede de serviços de saúde implantada no território e localidade de moradia da família, para melhor suprir a necessidade de seguimento da criança exposta à sífilis.  
O Quadro 22 sumariza as recomendações do seguimento clínico das crianças exposta à sífilis.  
**Quadro 22 – Seguimento clínico da criança exposta à sífilis**  
|**PROCEDIMENTO**|**FREQUÊNCIA E DURAÇÃO**|**O QUE AVALIAR**|
|---|---|---|
|**Consultas**<br>**ambulatoriais de**<br>**puericultura**|Seguimento habitual na rotina da<br>puericultura, conforme<br>recomendação da Saúde da<br>Criança: na 1ª semana de vida e<br>nos meses 1, 2, 4, 6, 9, 12 e 18,<br>com retorno para checagem de<br>exames complementares, se for o<br>caso.<br>Avaliação laboratorial com TNT<br>com 1, 3, 6, 12 e 18 meses de<br>idade, interrompendo o<br>seguimento após dois testes não<br>reagentes consecutivos.|A criança exposta à sífilis, mesmo que não tenha sido diagnosticada com<br>sífilis congênita no momento no nascimento, pode apresentar sinais e<br>sintomas compatíveis com a doença ao longo do seu desenvolvimento.<br>Dessa forma, deve ser realizada busca ativa de sinais e sintomas a cada<br>retorno referente as manifestações precoces de sífilis congênita e ao<br>desenvolvimento neuropsicomotor.<br>Espera-se que os testes não treponêmicos declinem aos 3 meses de idade,<br>devendo ser**não reagentes**aos 6 meses caso a criança não tenha sido<br>infectada e seja apenas passagem passiva de anticorpo materno.<br>Se no seguimento ocorrer elevação de títulos em duas diluições em teste<br>não treponêmico ou persistência da titulação aos 6 meses de idade, a criança<br>deverá ser investigada, submetida a coleta de líquor, tratada para sífilis<br>congênita com benzilpenicilina potássica (cristalina) por 10 dias e<br>notificada a vigilância epidemiológica.<br>A partir dos 18 meses de idade, se não houver achados clínicos e<br>laboratoriais, exclui-se sífilis congênita.|  
Observações:  
Fazer a solicitação dos testes não treponêmicos, para que os resultados estejam disponíveis na consulta de retorno.  
Aproveitar o momento da consulta para avaliar risco de outras IST maternas. O diagnóstico prévio de uma IST é fator de risco para outras, inclusive HIV, que pode ser transmitido pelo aleitamento materno.  
Indagar sobre práticas sexuais e oferecer testagem para a mãe da criança e suas parcerias sexuais, na rotina, enquanto a mulher estiver amamentando (testagem para HIV pelo menos a cada 6 meses). Oferecer teste rápido para hepatite B e vacina contra hepatite B, quando não houver histórico de vacinação.  
Fonte: Brasil (2017)<sup>8</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A sífilis congênita precoce pode surgir até o segundo ano de vida. Já a sífilis congênita tardia é definida como aquela em que os sinais e sintomas surgem após os dois anos de idade da criança.  
A sífilis congênita precoce deve ser diagnosticada por meio de criteriosa avaliação clínica e epidemiológica da situação materna, associada à avaliação clínico-laboratorial e exames de imagem na criança.  
As crianças com sífilis congênita deverão ser investigadas ainda na maternidade quanto às **manifestações clínicas, exames complementares e resultado do teste não treponêmico** .  
Quando a mãe não foi tratada ou foi tratada de forma não adequada durante o pré-natal, as crianças são classificadas como caso de sífilis congênita, independentemente dos resultados da avaliação clínica ou de exames complementares.  
Independentemente do histórico de tratamento materno, as crianças com resultado de teste não treponêmico maior que o da mãe em pelo menos duas diluições (ex.: mãe 1:4 e RN ≥1:16) são consideradas caso de sífilis congênita, devendo ser notificadas, investigadas, tratadas e acompanhadas quanto a aspectos clínicos e laboratoriais.  
Todas as crianças com sífilis congênita devem ser submetidas a uma investigação completa, incluindo punção lombar para análise do líquor e radiografia de ossos longos.  
As crianças com manifestação clínica, alteração liquórica ou radiológica de sífilis congênita **E** teste não treponêmico reagente preenchem  
critério para sífilis congênita, independentemente do histórico materno quanto ao tratamento e das titulações dos testes não treponêmicos.  
42  
Para as demais situações em que a criança é classificada como sífilis congênita, consultar o Quadro 54 (Critérios para definição de caso de sífilis congênita).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Nas crianças com sífilis congênita, aproximadamente 60% a 90% dos RN vivos são assintomáticos ao nascimento<sup>85,112</sup> ; apenas os casos mais  
graves nascem com sinais/sintomas. As manifestações clínicas das crianças com sífilis congênita raramente surgem após três a quatro meses; dois terços desenvolvem sintomas em três a oito semanas<sup>113</sup> .  
A presença de sinais e sintomas ao nascimento depende do momento da infecção intrauterina e do tratamento durante a gestação<sup>114</sup> . São sinais mais frequentes<sup>85,115</sup> :  
- Hepatomegalia;  
- Esplenomegalia;  
- Icterícia;  
- Corrimento nasal (rinite sifilítica);  
- Exantema cutâneo;  
- Linfadenopatia generalizada;  
- Anormalidades esqueléticas.  
As manifestações clínicas de sífilis **congênita precoce** são variadas. As principais características dessa síndrome estão descritas no Quadro 23.  
As crianças sintomáticas devem ser notificadas, tratadas e acompanhadas em relação aos aspectos clínicos e laboratoriais.  
_Todas essas manifestações são inespecíficas e podem ser encontradas no contexto de outras infecções congênitas. É necessário investigar possíveis diagnósticos diferenciais._  
**Quadro 23 – Manifestações clínicas de sífilis congênita precoce**  
||**GESTACIONAIS/PERINATAIS**|
|---|---|
|**Natimorto/aborto espontâneo**|Pode ocorrer em qualquer momento da gestação.<br>Desfecho em aproximadamente 40% dos casos de sífilis adquirida durante a gestação, com maior risco no<br>primeiro trimestre de gestação.|
|**Prematuridade**|–|
|**Baixo peso ao nascer**<br>**(<2.500g)**|–|
|**Hidropsia fetal não imune**|–|
|**Placenta**|Placenta desproporcionalmente grande, grossa, pálida; vilite proliferativa focal; arterite endo e<br>perivascular; imaturidade difusa ou focal das vilosidades placentares.<br>Encaminhar para análise anatomopatológica.|
|**Cordão umbilical**<br>|Funisite necrotizante é rara, mas patognomônica quando presente. É caracterizada pelo cordão umbilical<br>edemaciado e inflamado, que pode apresentar listras vermelhas e azuladas em alternância com áreas<br>esbranquiçadas. Pontos de abscesso na substância de Wharton, centradas ao redor dos vasos umbilicais.<br>Encaminhar para análise anatomopatológica.<br>**SISTÊMICAS**<br>|
|**Febre**|Pode ser mais significativa em crianças nascidas de mães infectadas tardiamente na gestação.|
|**Hepatomegalia**|Ocorre em praticamente todos os casos de crianças com sífilis congênita<sup>98,116</sup>.<br>O achado ultrassonográfico de hepatomegalia pode indicar falha do tratamento materno para prevenir a<br>transmissão vertical<sup>117</sup>.<br>Está associada a icterícia e colestase. Achados laboratoriais podem incluir aumento de AST/ALT, FA,<br>bilirrubina direta, alargamento do tempo de protrombina e espiroquetas visíveis em biópsia hepática<br>(quando realizada).<br>As alterações de provas hepáticas podem ser exacerbadas com a administração da penicilina, antes da<br>melhora<sup>118</sup>. A melhora geralmente é lenta, mesmo com terapêutica adequada.|
|**Esplenomegalia**|Ocorre em aproximadamente 50% dos pacientes com hepatomegalia (não acontece isoladamente).|
|**Linfadenomegalia**<br>**generalizada**|O linfonodo pode ser de até 1 cm, geralmente não flutuante e firme.|
|**Atraso no desenvolvimento**<br>**neuropsicomotor**|–|  
43  
|**Edema**|Causado por anemia/hidropsia fetal, síndrome nefrótica, desnutrição|
|---|---|
||**MUCOCUTÂNEAS**|
|**Rinite sifilítica ou corrimento**<br>**nasal**|Pode ser um sinal precoce, surgindo após a primeira semana de vida. Ocorre em aproximadamente 40%<br>dos casos.<br>A secreção contém espiroquetas e é infectante. Usar precaução de contato.|
|**Exantema maculopapular**|Geralmente aparece 1 a 2 semanas após a rinite.<br>Apresenta-se como lesões ovais, inicialmente vermelhas ou rosadas, evoluindo para coloração marrom<br>acobreada; podem estar associadas à descamação superficial, caracteristicamente nas regiões palmar e<br>plantar. São mais comuns na região glútea, nas costas, parte posterior das coxas e plantas.<br>As lesões contêm espiroquetas e são infectantes. Usar precaução de contato.|
|**Exantema vesicular (pênfigo**<br>**sifilítico)**|Pode estar presente ao nascimento, desenvolvendo-se mais frequentemente nas primeiras quatro semanas<br>de vida; é amplamente disseminado.<br>O fluido vesicular contém espiroquetas e é infectante. Usar precaução de contato.|
|**Condiloma lata**|Único ou múltiplo. Lesões planas, verrucosas, úmidas ao redor da boca, narinas e ânus e outras áreas da<br>pele em que há umidade ou fricção.<br>Frequentemente presente sem qualquer outro sintoma associado.<br>As lesões contêm espiroquetas e são infectantes. Usar precaução de contato.|
|**Icterícia**|Hiperbilirrubinemia secundária à hepatite sifilítica e/ou hemólise.|
||**HEMATOLÓGICAS**|
|**Anemia**|Período neonatal: hemolítica (teste de Coombs [teste antiglobulina direto] não reagente).<br>Pode persistir após tratamento efetivo.<br>Após 1 mês de idade: pode ser crônica e não hemolítica.|
|**Trombocitopenia**|Algumas vezes associada a sangramento ou petéquias.<br>Pode ser a única manifestação da infecção congênita.|
|**Leucopenia**|–|
|**Leucocitose**|–|
||**MUSCULOESQUELÉTICAS**<br>|
|**Pseudoparalisia de Parrot**|Ausência de movimentação de um membro causada por dor associada à lesão óssea. Afeta com mais<br>frequência membros superiores que inferiores; geralmente unilateral; raramente presente ao nascimento.<br>Baixa correlação com anormalidades radiográficas.|
|**Anormalidades radiográficas**|Anormalidade mais comum na sífilis congênita precoce não tratada, surgindo em 70% a 100% dos casos;<br>tipicamente múltipla e simétrica, acometendo principalmente ossos longos (rádio, ulna, úmero, tíbia, fêmur<br>e fíbula).<br>Pode ocorrer dor à movimentação ativa ou passiva dos membros e, por causa da dor, a criança pode<br>apresentar-se irritada e tendente à imobilidade.|
|**Periostite**|Espessamento periosteal irregular, especialmente na diáfise; geralmente extensa, bilateral e simétrica.|
|**Sinal de Wegner**|Osteocondrite metafisária, visível nas extremidades principalmente do fêmur e do úmero. Há uma sombra<br>de maior densidade, que é a matriz calcificada, com formação “em taça” da epífise.|
|**Sinal de Wimberger**|Desmineralização e destruição óssea da parte superior medial tibial.|
||**NEUROLÓGICAS**|
|**Anormalidades no líquido**<br>**cefalorraquidiano (líquor,**<br>**LCR)**|No mínimo 1 dos 3 parâmetros alterados: células > 25/mm<sup>3</sup>OU proteínas > 150 mg/dl, ou VDRL<br>REAGENTE.|
|**Leptomeningite sifilítica**<br>**aguda**|Surge no primeiro ano de vida, geralmente entre 3 e 6 meses; apresentação semelhante à meningite<br>bacteriana, mas com alterações liquóricas mais consistentes com meningite asséptica (predominância<br>mononuclear).<br>Responde à terapêutica com penicilina.|
|**Sífilis crônica**<br>**meningovascular**|Surge a partir do fim do primeiro ano de vida.<br>Hidrocefalia; paralisia de nervo craniano; deterioração do desenvolvimento intelectual/neuropsicomotor;<br>infarto cerebral.<br>Curso prolongado.|
||**OUTROS**|
|**Pneumonia/pneumonite/esfor**<br>**ço respiratório**|Opacificação completa de ambos os campos pulmonares na radiografia de tórax.|  
44  
Geralmente acontece entre 2 e 3 meses de idade, manifestando-se como edema generalizado e ascite **Síndrome nefrótica** (anasarca). Fontes: Chakraborty; Luck (2008)<sup>119</sup> ; Dobson; Sanchez (2014)<sup>120</sup> ; Hollier et al.(2001)<sup>117</sup> ; Ingall et al. (2006)<sup>121</sup> ; Rawstron (2008)<sup>122</sup> ; Robinson (2009)<sup>123</sup> ; Saloojee et al. (2004)<sup>124</sup> ; Moreira-Silva et al. (2009)<sup>125</sup> . Legenda: AST/ALT – aspartato aminotransferase/alanina aminotransferase; FA – fosfatase alcalina.  
As manifestações clínicas da sífilis congênita tardia estão relacionadas à inflamação cicatricial ou persistente da infecção precoce e se caracterizam pela presença de formação das gomas sifilíticas em diversos tecidos. Surgem em aproximadamente 40% das crianças nascidas de mulheres não tratadas para sífilis durante a gestação. Algumas manifestações podem ser prevenidas por meio do tratamento materno durante a gestação ou do tratamento da criança nos primeiros três meses de vida<sup>126,127</sup> . Porém, outras manifestações como a ceratite intersticial<sup>128</sup> , articulações de Clutton<sup>129</sup> e surdez neurossensorial<sup>130</sup> podem ocorrer e progredir, a despeito de terapêutica apropriada.  
As manifestações de sífilis congênita tardia estão descritas no Quadro 24.  
**Quadro 24 – Manifestações clínicas de sífilis congênita tardia**  
|**CARACTERÍSTICAS**|**MANIFESTAÇÕES**|
|---|---|
|**Faciais**|Fronte olímpica, nariz em sela, hipodesenvolvimento maxilar, palato em ogiva.|
|**Oftalmológicas**|Ceratite intersticial, coriorretinite, glaucoma secundário, cicatriz córnea, atrofia óptica.|
|**Auditivas**|Perda aditiva sensorial.|
|**Orofaríngeas**|Dentes de Hutchinson: incisivos medianos deformados, molares em amora, perfuração do palato duro.|
|**Cutâneas**|Rágades (fissuras periorais e perinasais), gomas.|
|**Sistema nervoso central**|Atraso no desenvolvimento, comprometimento intelectual, hidrocefalia, crises convulsivas, atrofia do<br>nervo óptico, paresia juvenil.|
|**Esqueléticas**|Tíbia em sabre, sinal de Higoumenakis (alargamento da porção esternoclavicular da clavícula), juntas<br>de Clutton (artrite indolor), escápula escafoide.|
|Fonte: adaptado de Ingall et al.<br>(2009)<sup>125</sup>.|(2006)<sup>121</sup>; Dobson; Sanchez (2014)<sup>120</sup>; Woods (2005)<sup>114</sup>; Chakraborty; Luck (2008)<sup>119</sup>; Moreira-Silva et al.|

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Nos casos de sífilis congênita, o _T. pallidum_ é liberado diretamente na circulação fetal, resultando em ampla disseminação das espiroquetas por quase todos os órgãos e sistemas. As manifestações clínicas decorrem da resposta inflamatória e são variáveis. Ossos, fígado, pâncreas, intestino, rins e baço são os órgãos mais frequente e gravemente envolvidos. Dessa forma, a investigação com exames complementares tem como objetivo a identificação dessas alterações<sup>114</sup> .  
Os testes de sífilis e exames deverão ser realizados de acordo com o Quadro 25.  
**Quadro 25 – Testes de sífilis e exames complementares para crianças com sífilis congênita**  
|**EXAME**<br>**COMPLEMENTAR**|**NA**<br>**MATERNIDADE**|**NO SEGUIMENTO**|**O QUE AVALIAR**|
|---|---|---|---|
|**Teste não treponêmico**|Coletar amostras de<br>sangue periférico do<br>RN e da mãe pareadas<br>para comparação.<br>Não realizar coleta de<br>cordão umbilical.|Realizar com 1, 3, 6,<br>12 e 18 meses de<br>idade. Interromper o<br>seguimento<br>laboratorial após:<br>Dois testes**não reagentes**<br>consecutivos.|Espera-se que os testes não treponêmicos declinem<br>aos 3 meses de idade, devendo ser**não reagentes**<br>aos 6 meses caso a criança tenha sido<br>adequadamente tratada.<br>Idealmente, o exame deve ser feito pelo mesmo<br>método e no mesmo laboratório.|  
45  
|**Teste treponêmico**|Não realizar|**NÃO é obrigatório**<br>Pode ser realizado a partir dos<br>18 meses de idade.|Um teste treponêmico reagente após os 18 meses<br>idade (quando desaparecem os anticorpos maternos<br>transferidos passivamente no período intrauterino)<br>confirma o diagnóstico de sífilis congênita. Um<br>resultado não reagente não exclui sífilis congênita<br>nos casos em que a criança foi tratada<br>precocemente<br>Criança com teste treponêmico reagente após 18<br>meses de idade e que não tenha histórico de<br>tratamento prévio deverá passar por avaliação<br>completa, receber tratamento e ser notificada como<br>caso de sífilis congênita.|
|---|---|---|---|
|**Hemograma**|SIM|De acordo com alterações<br>clínicas<br>A critério clínico.|Anemia hemolítica com Coombs não reagente no<br>período neonatal ou crônica não hemolítica no<br>período pós-natal;<br>Leucopenia ou leucocitose;<br>Hemólise pode estar acompanhada de<br>crioglobulinemia, formação de complexo imune e<br>macroglobulinemia. Esse quadro pode durar<br>semanas e costuma não ser responsivo à<br>terapêutica;<br>Plaquetopenia.|
|**Plaquetas**|SIM||Trombocitopenia.|
|**Exames para avaliação**<br>**de função hepática,**<br>**pancreática, renal e**<br>**distúrbios eletrolíticos.**|SIM||Aumento das trasaminases;<br>Icterícia;<br>Distúrbios hidroeletrolíticos.|
|**Líquor (LCR)**|SIM|Deve ser avaliado a cada 6<br>meses nas crianças que<br>apresentaram alteração inicial<br>(neurossífilis), até normalização.|VDRL reagente no líquor;<br>Pleocitose;<br>Proteína aumentada (Valores de exames liquóricos<br>no Quadro 26);<br>VDRL reagente no líquor ou aumento na<br>celularidade ou da proteína que não possam ser<br>atribuídos a outras causas requerem tratamento para<br>possível neurossífilis (Figura 9).|
|**Radiografia de ossos**<br>**longos**|SIM|De acordo com alterações<br>clínicas|Bandas metafisárias luzentes (diagnóstico<br>diferencial com outras doenças sistêmicas);<br>Desmineralizações simétricas localizadas e<br>destruição óssea da porção medial da metáfise<br>proximal tibial (sinal de Wimberger – diagnóstico<br>diferencial com osteomielite e hiperparatireoidismo<br>neonatal);<br>Serrilhado metafisário (sinal de Wegener);<br>Periostite diafisária com neoformação óssea (pode<br>acontecer em outras patologias);<br>Áreas irregulares de aumento de densidade e<br>rarefação.|
|**Radiografia de tórax**|SIM||A descrição clássica é a opacificação completa de<br>ambos os campos pulmonares. No entanto, com o<br>advento da penicilina, é mais comum encontrar<br>infiltrado difuso envolvendo todos os campos<br>pulmonares.|  
46  
|**Neuroimagem**|A critério clínico|Realizar neuroimagem nas crianças que apresentem<br>alterações LCR persistentes (VDRL reagente,<br>proteinorraquia ou celularidade), sem outra<br>explicação mais provável.|
|---|---|---|
|||Ultrassom Transfontanela (USTF) é uma opção de<br>exame não invasivo.|  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A infecção do sistema nervoso central pelo _T. pallidum_ , ou neurossífilis, pode ser sintomática ou assintomática nas crianças com sífilis congênita. A neurossífilis é de ocorrência mais provável em crianças que nascem sintomáticas do que nas assintomáticas; portanto, o benefício do teste deve ser considerado, especialmente em razão da necessidade de internação para administração de benzilpenicilina potássica/cristalina.  
Acredita-se que a neurossífilis ocorra em 60% das crianças com sífilis congênita, com base na presença de alterações no líquor, como reatividade no VDRL, pleocitose e aumento na proteinorraquia<sup>131</sup> . No entanto, nenhum desses achados apresentam suficiente sensibilidade e especificidade<sup>132,133</sup> . Além disso, a reatividade do VDRL no líquor do recém-nascido pode representar falso reagente relacionado a anticorpos maternos circulando no SNC do neonato, ou contaminação com sangue periférico por acidente de punção; podem existir, ainda, falsonegativos (recém-nascidos com VDRL não reagente em um primeiro momento) que posteriormente desenvolvem sinais de neurossífilis.  
A despeito disso, o teste não treponêmico reagente é o parâmetro mais importante, com 90% de especificidade e 54% de sensibilidade<sup>132</sup> . Mas, para adequada avaliação desses parâmetros, o LCR deve estar livre de qualquer contaminação por sangue que possa ocorrer em casos de acidente de punção.  
Para o exame liquórico do RN, consideram-se os valores para diagnóstico de neurossífilis constantes no Quadro 26.  
**Quadro 26 – Valores de exame liquórico em crianças com suspeita de neurossífilis**  
|**Parâmetro**|**LCR normal pré-termo**|**LCR normal a termo**|**LCR sugestivo de sífilis**<br>**no RN**|**LCR sugestivo de sífilis nas**<br>**crianças maiores que 28**<br>**dias**|
|---|---|---|---|---|
|**Leucócitos**|9+8 céls/mm<sup>3</sup><br>(LVN: 0-29 céls/mm<sup>3</sup>)|8+7 céls/mm<sup>3</sup><br>(LVN: 0-32 céls/mm<sup>3</sup>)|Maior que 25 céls/mm<sup>3</sup>|Maior que 5 céls/mm<sup>3</sup>|
|**Proteínas**|115mg/dL<br>(LVN: 65-150mg/dL)|90mg/dL<br>(LVN: 20-170mg/dL)|Maior que 150mg/dL|Maior que 40mg/dL|
|**VDRL**|Não reagente|Não reagente|Reagente|Reagente|  
Fonte: Lago et al. (2013)<sup>98</sup> ; Volpe (2008)<sup>134</sup> . Legenda: LVN – Limite de variação do normal.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O seguimento pode ser feito na puericultura, na Atenção Básica, durante as consultas de rotina, conforme orientação da Saúde da Criança<sup>111</sup> ,  
com atenção mais cuidadosa no monitoramento de sinais e sintomas sugestivos de sífilis congênita, além dos testes de sífilis e exames complementares constantes no Quadro 25.  
Mesmo recebendo tratamento com penicilina na maternidade, deve-se considerar que essa criança se insere em um grupo de risco de desenvolvimento de sífilis congênita sintomática. Assim, é fundamental o seguimento clínico dessa criança.  
O seguimento clínico mínimo das crianças com sífilis congênita (sintomáticas e assintomáticas) está descrito no Quadro 27. As orientações poderão mudar de acordo com as necessidades da criança, devendo ser garantido o cuidado tanto na Atenção Básica como nos serviços especializados e hospitalares, quando for o caso.  
47  
**Quadro 27 – Seguimento clínico da criança com sífilis congênita**  
|**PROCEDIMENTO**|**FREQUÊNCIA E DURAÇÃO**|**O QUE AVALIAR**|
|---|---|---|
|**Consultas**<br>**ambulatoriais de**<br>**puericultura**|Seguimento habitual na rotina da<br>puericultura, conforme<br>recomendação da Saúde da<br>Criança: na 1ª semana de vida e<br>nos meses 1, 2, 4, 6, 9, 12 e 18,<br>com retorno para checagem de<br>exames complementares, se for o<br>caso.<br>Avaliação laboratorial com teste<br>não treponêmico com 1, 3, 6, 12 e<br>18 meses de idade, interrompendo<br>o seguimento após dois testes não<br>reagentes consecutivos.|Espera-se que os testes não treponêmicos declinem aos 3 meses de idade,<br>devendo ser**não reagentes**aos 6 meses caso a criança tenha sido<br>adequadamente tratada.<br>Diante da elevação de títulos em duas diluições em teste não treponêmico ou<br>sua não negativação até 18 meses ou persistência de títulos baixos, reavaliar a<br>criança e proceder ao retratamento.<br>Se criança for tratada de forma não adequada, quanto à dose e/ou tempo<br>preconizado, realizar busca ativa da criança para reavaliação clínico-<br>laboratorial e reinício do tratamento.|
|**Consulta oftalmológica**|Semestrais por 2 anos|Buscar anomalias oftalmológicas. As mais comuns são ceratite intersticial,<br>coriorretinite, glaucoma secundário, cicatriz córnea e atrofia óptica. A faixa<br>etária de acometimento de ceratite intersticial costuma ser dos 2 aos 20 anos.|
|**Consulta audiológica**|Semestrais por 2 anos|Buscar anomalias auditivas.<br>A perda auditiva sensorial pode ter ocorrência mais tardia, entre 10 e 40 anos<br>de idade, por acometimento do 8º par craniano.|
|**Consulta neurológica**|Semestrais por 2 anos|Avaliar o desenvolvimento neuropsicomotor.<br>No caso de neurossífilis, repetir punção lombar a cada 6 meses, até<br>normalização bioquímica, citológica e sorológica. Se o VDRL liquórico se<br>mantiver reagente ou celularidade e/ou proteína liquóricos se mantiverem<br>alterados, realizar nova investigação clínico laboratorial e retratar. Exame de<br>imagempode ser considerado também nesse cenário.|  
Observações:  
Fazer a solicitação dos testes não treponêmicos, para que os resultados estejam disponíveis na consulta de retorno.  
Aproveitar o momento da consulta para avaliar risco de outras IST maternas. O diagnóstico prévio de uma IST é fator de risco para outras, inclusive HIV, que pode ser transmitido pelo aleitamento materno.  
Indagar sobre práticas sexuais e oferecer testagem para a mãe da criança e suas parcerias sexuais, na rotina, enquanto a mulher estiver amamentando (testagem para HIV pelo menos a cada 6 meses).  
Oferecer teste rápido para hepatite B e vacina contra hepatite B, quando não houver histórico de vacinação.  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O medicamento para tratamento de crianças com sífilis congênita é a benzilpenicilina (potássica/cristalina, procaína ou benzatina), a depender do tratamento materno durante a gestação e/ou titulação de teste não treponêmico da criança comparado ao materno e/ou exames clínicos e laboratoriais da criança<sup>135</sup> .  
Para as crianças com sífilis congênita que apresentem neurossífilis, a cristalina é o medicamento de escolha, sendo obrigatória a internação hospitalar. Na ausência de neurossífilis, a criança com sífilis congênita pode ser tratada com benzilpenicilina procaína fora da unidade  
hospitalar, por via intramuscular, ou com benzilpenicilina potássica/cristalina, por via endovenosa, internada.  
A benzilpenicilina benzatina é uma opção terapêutica, mas restrita às crianças cuja mãe não foi tratada ou foi tratada de forma não adequada,  
e que apresentem exame físico normal, exames complementares normais e teste não treponêmico não reagente ao nascimento.  
_A única situação em que não é necessário tratamento é a da criança exposta à sífilis (aquela nascida assintomática, cuja mãe foi adequadamente tratada e cujo teste não treponêmico é não reagente ou reagente com titulação menor, igual ou até uma diluição maior que o materno)._  
_Essas crianças não são notificadas na maternidade, mas devem ser acompanhadas na Atenção Básica, com seguimento clínico e laboratorial._  
O tratamento apropriado de sífilis congênita dentro dos primeiros três meses de vida é capaz de prevenir algumas manifestações clínicas (não todas). A ceratite intersticial e as deformidades ósseas, como a tíbia em “lâmina de sabre”, podem ocorrer ou progredir mesmo com terapia adequada.  
48  
Até o momento, não há evidências científicas da eficácia do uso da ceftriaxona no tratamento de sífilis congênita e, portanto, reforça-se que essa medicação poderá ser utilizada como alternativa somente em situações de indisponibilidade das benzilpenicilinas potássica (cristalina) e procaína. Também não se observa evidência de resistência do _Treponema pallidum_ à penicilina no Brasil e no mundo.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Para crianças assintomáticas, ou seja, com exame físico normal, sem alterações liquóricas, com radiografias de ossos longos normais e sem outras alterações viscerais, com teste não treponêmico não reagente, o tratamento com benzilpenicilina benzatina em dose única é eficaz para prevenção de evidência clínica de sífilis congênita, conforme a Figura 8<sup>136,137</sup> .  
**Figura 8 – Tratamento com benzilpenicilina benzatina dose única**  
<!-- Start of picture text -->
Crianças nascidas de mães não tratadas ou tratadas de forma não adequada, com<br>exame físico normal, exames complementares normais e teste não treponêmico não<br>reagente ao nascimento<br>↓<br>Tratar com benzilpenicilina 50.000 UI/kg, intramuscular, dose<br>única<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- Benzilpenicilina procaína<sup>a</sup> 50.000 UI/kg, IM, uma vez ao dia, por 10 dias OU  
- Benzilpenicilina potássica (cristalina) 50.000 UI/kg, IV, de 12/12h (crianças com menos de 1 semana de vida) e de 8/8h (crianças com mais de 1 semana de vida), por 10 dias.  
a É necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose.  
**Na ausência de neurossífilis** , a criança com sífilis congênita pode ser tratada com benzilpenicilina procaína fora da unidade hospitalar, por via intramuscular; OU com benzilpenicilina potássica/cristalina, com internação hospitalar.  
Como existem evidências de que os níveis de penicilina no líquor são menores com penicilina procaína<sup>138</sup> , é recomendado o uso de **benzilpenicilina potássica/cristalina para os casos de neurossífilis** , com necessidade de internação hospitalar.  
O esquema completo de dez dias com benzilpenicilina deve ser administrado mesmo nos casos em que a criança tenha recebido ampicilina por outra causa.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
 Benzilpenicilina potássica (cristalina) 50.000 UI/kg, IV, de 4/4h a 6/6h, por 10 dias.  
Crianças diagnosticadas com sífilis congênita após um mês de idade e aquelas com sífilis adquirida deverão ser tratadas com benzilpenicilina potássica/cristalina.  
49

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
**Figura 9 – Fluxograma para avaliação e manejo na maternidade das crianças nascidas de mães com diagnóstico de sífilis na gestação atual ou no momento do parto**  
Fonte: DCCI/SVS/MS.  
Legenda: TNT – Teste não treponêmico periférico.  
* Realizar TNT em sangue periférico em todos recém-nascidos de mãe com teste rápido e/ou TNT reagente no momento do parto, independentemente de tratamento prévio realizado  
Observação 1: **Tratamento materno adequado:** Registro de tratamento completo com benzilpenicilina benzatina, adequado para o estágio clínico, com primeira dose realizada até 30 dias antes do parto. Observação 2: **Opções terapêuticas: Benzilpenicilina potássica/cristalina** 50.000 UI/kg, intravenosa, de 12/12h na primeira semana de vida, de 8/8h após a primeira semana de vida, por 10 dias. Obs.: é necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose. **Benzilpenicilina procaína** 50.000 UI/kg, intramuscular, uma vez ao dia, por 10 dias. Obs.: é necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose. **Benzilpenicilina benzatina** 50.000 UI/kg, intramuscular, dose única. ~~a~~  
50  
Observação 3:  
**Investigação para STORCH (sífilis, toxoplasmose, rubéola, citomegalovírus e herpes vírus):**  
Portaria nº 3.502, de 19 de dezembro de 2017, que instituiu a Estratégia de fortalecimento das ações de cuidado das crianças suspeitas ou confirmadas para Síndrome Congênita associada à infecção pelo vírus Zika e outras síndromes causadas por sífilis, toxoplasmose, rubéola, citomegalovírus e herpes vírus<sup>139</sup> .  
Avaliação de acordo com as “Orientações integradas de vigilância e atenção à saúde no âmbito da Emergência de Saúde Pública de Importância Nacional”<sup>140</sup> .  
_As crianças nascidas de mãe com cicatriz sorológica para sífilis antes da gestação_ **_DEVEM_** _realizar teste não treponêmico na maternidade e, na ausência de sinais/sintomas, não necessitam de avaliação ou tratamento na maternidade. No entanto, a testagem para sífilis deve ocorrer, conforme rotina preconizada no pré-natal (1º e 3º trimestres de gestação), idealmente por meio de testes não treponêmicos._  
_* Documentação de queda do título do teste não treponêmico em pelo menos duas diluições em três meses, ou de quatro diluições em seis meses após a conclusão do tratamento (ex: antes, 1:16; depois, menor ou igual a 1:4)_

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O cuidado à criança exposta à sífilis e com sífilis congênita envolve diferentes pontos de atenção à saúde. O seguimento é fundamental para crianças expostas à sífilis e com diagnóstico de sífilis congênita. Portanto, estabelecer a linha de cuidado dessas crianças na rede de atenção é de responsabilidade de estados, Distrito Federal e municípios. A Figura 10 delimita os campos de responsabilidade e o papel da Atenção Básica como coordenadora do cuidado.  
51  
**Figura 10 – Linha de cuidado da criança exposta à sífilis e com sífilis congênita**  
|**Atenção Básica**<br>**Pré-natal**|**Maternidade ou**<br>**casa de parto**|**Atenção Básica**<br>**coordenadora do**<br>**cuidado**|**Serviços da**<br>**especialidade**|
|---|---|---|---|
| Garantir cobertura de<br>pré-natal a todas as<br>gestantes e suas<br>parcerias sexuais.<br>Idealmente, fazer<br>seguimento e<br>planejamento<br>reprodutivo, incluindo<br>rastreio de IST,<br>abordagem à saúde<br>sexual e Prevenção<br>Combinada.<br> Realizar testagem de<br>sífilis no pré-natal, no<br>primeiro e terceiro<br>trimestres de gestação e<br>no puerpério.<br> Realizar tanto TR para<br>|| Receber referência da<br>Atenção Básica quanto<br>ao histórico de<br>tratamento e resultado de<br>exames realizados<br>durante o pré-natal.<br> Fazer TR de HIV e sífilis<br>no momento do parto ou<br>em caso de aborto/<br>natimorto.<br> Realizar parto de<br>acordo com indicação<br>obstétrica.<br> Avaliar todo RN ao<br>nascimento quanto ao<br>histórico de tratamento<br>materno e presença ou<br>ausência de sinais/| Rec**e**b**e**r referência da<br>maternidade quanto à<br>investigação clínica e<br>labor**a**torial realizada na<br>maternidade.<br> Fazer seguimento clínico<br>e laboratorial da criança<br>exp**o**sta à sífilis ou com<br>sífilis congênita.<br> Realizar puericultura<br>conf**o**rme orientações da<br>Saúde da Criança.<br> Notificar criança conforme<br>definição de caso de<br>sífilis congênita, se<br>durante o seguimento<br>houver alteração clínica<br>e/ou laboratorial.<br> R c ber referência<br>da Atenção Básica e<br>avaliar seguimento da<br>cri nça com sífilis<br>congênita, quanto a<br>consultas e exames<br>especializados.<br> F rnecer<br>contrarreferência à<br>Atenção Básica.<br> N tificar criança<br>conforme definição de<br>caso de sífilis<br>congênita, se durante<br>o seguimento houver<br>alteração clínica e/ou<br>laboratorial.|
|sífilis quanto teste não<br>treponêmico (ex.:<br>VDRL/RPR).<br> Notificar todos os casos<br>de sífilis em gestantes.||sintomas clínicos.<br> Notificar a mãe como<br>sífilis em gestante caso<br>não haja registro no<br>Sinan.| Coordenar o cuidado:<br>referência e<br>contrarreferência para<br>especialidade, de acordo<br>com protocolos e<br>|
| Aplicar penicilina<br>benzatina na gestante e<br>documentar tratamento.<br> Orientar a gestante<br>quanto ao risco de nova<br>exposição à sífilis.|| Notificar a criança<br>conforme definição de<br>caso de sífilis congênita<br>(Quadro 54).<br> Fazer contrarreferência<br>para Atenção Básica<br>|necessidade clínica.<br> Manter diálogo com a<br>mulher puérpera sobre<br>saúde sexual, ofertar<br>Prevenção Combinada e<br>rastrear para IST/HIV.|
| Investigar e tratar as||(com consulta||
|<br>parceiras sexuais das<br>gestantes.<br> Monitorar mensalmente<br>a gestante com teste<br>não treponêmico.||agendada), de modo a<br>garantir o seguimento<br>clínico e laboratorial da<br>criança exposta ou com<br>sífilis congênita na<br>puericultura.||
| Referenciar a gestante<br>para a maternidade/<br>casa de parto com<br>histórico de tratamento,<br>resultado de exames<br>realizados durante o pré-<br>natal e número da<br>notificação da gestante<br>no Sinan.||<br> Tratar criança com sífilis<br>congênita na<br>maternidade, sem<br>dispensar seguimento<br>posterior na Atenção<br>Básica.||  
Fonte: DCCI/SVS/MS.  
52

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O corrimento vaginal é uma queixa comum, que ocorre principalmente na idade reprodutiva. Em serviços que atendem com frequência casos de IST, é o principal sintoma referido pelas mulheres atendidas<sup>141–143</sup> ; entre gestantes, é o primeiro ou segundo motivo da consulta, após verruga anogenital<sup>144–146</sup> .  
Entre as causas não infecciosas do corrimento vaginal, incluem-se drenagem de excessivo material mucoide fisiológico, vaginite inflamatória descamativa, vaginite atrófica (em mulheres na pós-menopausa) ou presença de corpo estranho. Outras patologias podem causar prurido vulvovaginal sem corrimento, como dermatites alérgicas ou irritativas (sabonetes, perfumes, látex) ou doenças da pele (líquen, psoríase).  
As infecções do trato reprodutivo (ITR) são divididas em:  
- Infecções endógenas (candidíase vulvovaginal e vaginose bacteriana);  
- Infecções iatrogênicas (infecções pós-aborto, pós-parto);  
- IST (tricomoníase, infecção por _C. trachomatis_ e _N. gonorrhoeae_ ).  
A mulher pode apresentar concomitantemente mais de uma infecção, ocasionando assim corrimento de aspecto inespecífico.  
A vulvovaginite e a vaginose são as causas mais comuns de corrimento vaginal patológico, responsáveis por inúmeras consultas. São afecções do epitélio estratificado da vulva e/ou vagina, cujos agentes etiológicos mais frequentes são fungos, principalmente a _Candida albicans_ ; bactérias anaeróbicas, em especial a _Gardnerella vaginalis_ ; e o protozoário _Trichomonas vaginalis._  
As mulheres com queixa de corrimento vaginal, ao procurarem um serviço de saúde, devem ser bem orientadas sobre as diferenças entre as ITR. O diagnóstico de uma IST tem implicações que estão ausentes nas infecções endógenas ou iatrogênicas, como a necessidade de orientação e tratamento de parcerias sexuais. É importante avaliar a percepção da mulher quanto à existência de corrimento vaginal fisiológico.  
A infecção vaginal pode ser caracterizada por corrimento e/ou prurido e/ou alteração de odor. Daí a necessidade de indagar sobre:  
- Consistência, cor e alterações no odor do corrimento;  
- Presença de prurido; e/ou  
- Irritação local.  
A investigação da história clínica deve ser minuciosa, abrangendo informações sobre:  
- Comportamentos e práticas sexuais;  
- Data da última menstruação;  
- Práticas de higiene vaginal e uso de medicamentos tópicos ou sistêmicos; e/ ou  
- Outros potenciais agentes irritantes locais.  
Durante o exame ginecológico, o profissional de saúde deve observar e anotar as características do corrimento questionadas à paciente, bem como a existência de ulcerações, edema e/ou eritema. Esta é a propedêutica essencial da abordagem das ITR e deve ser realizada conforme os passos recomendados no Quadro 28.  
**Quadro 28 – Exame ginecológico e IST**  
- Examinar a genitália externa e região anal.  
- Separar os lábios vaginais para visualizar o introito vaginal integralmente.  
- Introduzir o espéculo para examinar a vagina, suas paredes, o fundo de saco e o colo uterino.  
- Fazer o teste de pH vaginal, colocando, por um minuto, a fita de papel indicador na parede vaginal lateral (evitar tocar o colo).  
- Colher material para o teste de Whiff (teste das aminas ou do “cheiro” – em uma lâmina ou chumaço de gaze, acrescentar uma gota de KOH 10% sobre o conteúdo vaginal coletado, sendo positivo se apresentar cheiro de peixe podre) e para realização da bacterioscopia, quando disponível.  
- Havendo possibilidade de realização no local, coletar material endocervical para cultura de _N. gonorrhoeae_ em meio de transporte e pesquisa de _C. trachomatis_ e _N. gonorrhoeae_ por biologia molecular; a amostra para biologia molecular pode ser substituída pela urina de 1º jato (armazenada na bexiga no mínimo por 4h), seguindo as orientações da coleta e armazenamento, conforme o meio a ser utilizado.  
Fonte: DCCI/SVS/MS.  
53  
_O exame preventivo de câncer de colo do útero (colpocitologia oncótica) e a colposcopia não devem ser realizados com o intuito de diagnosticar vulvovaginite, vaginose e cervicite. Quando indicados (ex.: para rastreio de neoplasia intraepitelial cervical), devem preferencialmente ser realizados após tratamento das ITR._  
**7.1 . Aspectos específicos dos principais agentes etiológicos de corrimentos vaginais e cervicites**

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
_Candida albicans_ é o agente etiológico da candidíase vulvovaginal (CVV) em 80% a 92% dos casos, podendo o restante ser devido às espécies não _albicans_ ( _glabrata, tropicalis, krusei, parapsilosis_ ) e _Saccharomyces cerevisae_<sup>147</sup> . Durante a vida reprodutiva, 10% a 20% das mulheres serão colonizadas por _Candida spp_ ., de forma assintomática, sem requerer tratamento<sup>148</sup> .  
Dentre os fatores que predispõem à CVV, destacam-se os indicados no Quadro 29.  
**Quadro 29 – Fatores que predispõem à candidíase vulvovaginal**  
- Gravidez  
- Obesidade  
- Diabetes mellitus (descompensado)  
- Uso de corticoides  
- Uso de antibióticos  
- Uso de contraceptivos orais  
- Uso de imunossupressores ou quimio/radioterapia  
- Alterações na resposta imunológica (imunodeficiência)  
- Hábitos de higiene e vestuário que aumentem a umidade e o calor local  
- Contato com substancias alergênicas e/ou irritantes (ex.: talcos, perfumes, sabonetes ou desodorantes íntimos)  
- Infecção pelo HIV  
Fonte: DCCI/SVS/MS.  
A maioria das CVV não são complicadas e respondem a vários esquemas terapêuticos. Todavia, 5% das mulheres apresentam inabilidade de controle do processo agudo, o que leva à instalação da forma recorrente do agravo.  
_A CVV recorrente (CVVR) é definida quando a paciente reporta quatro ou mais episódios sintomáticos de CVV em um ano_<sup>149</sup> _._  
A CVV classifica-se em CVV não complicada e CVV complicada. É considerada não complicada quando presentes todos os critérios a seguir: sintomas leves/moderados, frequência esporádica, agente etiológico _C. albicans_ e ausência de comorbidades. Por outro lado, considera-se CVV complicada quando presente pelo menos um dos seguintes critérios: sintomas intensos, frequência recorrente (CVVR), agente etiológico não _albicans_ ( _glabrata, kruzei_ ), presença de comorbidades (diabetes, HIV) ou gestação<sup>150</sup> .  
_Diagnóstico de candidíase vulvovaginal_  
Clinicamente, a paciente pode referir os seguintes sinais e sintomas, diante de uma CVV clássica: prurido, ardência, corrimento geralmente grumoso, sem odor, dispareunia de introito vaginal e disúria externa. Os sinais característicos são eritema e fissuras vulvares, corrimento grumoso, com placas aderidas à parede vaginal, de cor branca, edema vulvar, escoriações e lesões satélites, por vezes, pustulosas pelo ato de coçar.  
Para a citologia a fresco, utiliza-se soro fisiológico e hidróxido de potássio a 10% a fim de visibilizar a presença de hifas e /ou esporos dos fungos. Além disso, a CVV está associada à pH normal vaginal (<4,5).  
Diante de forte suspeita de CVV, mas com citologia a fresco negativa, deve-se realizar cultura vaginal específica em meios de Sabouraud, Nickerson ou Microstix-candida<sup>151</sup> .  
Para o diagnóstico diferencial da CVVR, deve-se considerar líquen escleroso, vulvovestibulite, dermatite vulvar, vulvodínea, vaginite  
citolítica, vaginite inflamatória descamativa, formas atípicas de herpes genital e reações de hipersensibilidade<sup>150</sup> .  
54

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A vaginose bacteriana (VB) é a desordem mais frequente do trato genital inferior entre mulheres em idade reprodutiva (gestantes ou não) e a causa mais prevalente de corrimento vaginal com odor fétido. Está associada à perda de lactobacilos e ao crescimento de inúmeras bactérias, bacilos e cocos Gram-negativos anaeróbicos, com predomínio de _Gardnerella vaginalis_ , seguida de _Atopobium vaginae, Mobiluncus spp., Mobiluncus curtesii, Mobinculus mulieris, Bacteroides spp., Prevotella spp., Mycoplasma hominis, Ureaplasma urealyticum_ e _Streptococcus agalactie_ (grupo B).  
A VB aumenta o risco de aquisição de IST (incluindo o HIV), e pode trazer complicações às cirurgias ginecológicas e à gravidez (estando associada com ruptura prematura de membranas, corioamnionite, prematuridade e endometrite pós-cesárea). Quando presente nos procedimentos invasivos, como curetagem uterina, biopsia de endométrio e inserção de dispositivo intrauterino (DIU), aumenta o risco de doença inflamatória pélvica (DIP).  
Sem lactobacilos, o pH aumenta e a _Gardnerella vaginalis_ produz aminoácidos, os quais são quebrados pelas bactérias anaeróbicas da VB em aminas voláteis (putrescina e cadaverina), levando ao odor desagradável, particularmente após o coito e a menstruação (que alcalinizam o conteúdo vaginal), o que constitui a queixa principal da paciente. A afecção é facilmente identificada ao exame especular, que mostra as paredes vaginais em sua maioria íntegras, marrons homogêneas ao teste de Schiller, banhadas por corrimento perolado bolhoso em decorrência das aminas voláteis.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Se a microscopia estiver disponível, o diagnóstico é realizado na presença de pelo menos três critérios de Amsel<sup>152</sup> :  
- Corrimento vaginal homogêneo;  
- pH >4,5;  
- Presença de _clue cells_ no exame de lâmina a fresco;  
- Teste de Whiff positivo (odor fétido das aminas com adição de hidróxido de potássio a 10%).  
O padrão-ouro é a coloração por Gram do fluido vaginal. Quantifica-se o número de bactérias e lactobacilos patogênicos, resultando em um escore que determina se há infecção. O mais comumente utilizado é o sistema de Nugent<sup>153</sup> , conforme o Quadro 30. O critério que caracteriza a VB, somada a pontuação de todos os agentes, é um escore de 7 ou mais; um escore de 4 a 6 é intermediário e de 0 a 3 é normal.  
**Quadro 30 – Sistema de Nugent para diagnóstico de vaginose bacteriana**  
|**ESCORE**|**LACTOBACILOS**|**_GARDNERELLA,_**<br>**_BACTEROIDES_, **<br>**ETC.**|**BACILOS**<br>**CURVOS**|**QUANTIFICAÇÃO**|
|---|---|---|---|---|
|0|4+|0|0|0<br>Ausência de bactérias|
|1|3+|1+|1+ ou 2+|1+<br><1 bactéria/campo|
|2|2+|2+|3+ ou 4+|2+<br>1 a 5 bactérias/campo|
|3|1+|3+||3+<br>6 a 30 bactérias/campo|
|4|0|4+||4+<br>>30 bactérias/campo|  
Fonte: Adaptado de Nugent (1991)<sup>153</sup> .  
Nota: interpretação do resultado: 0 a 3 – negativo para VB; 4 a 6 – microbiota alterada; 7 ou mais – vaginose bacteriana.  
Não há indicação de rastreamento de vaginose bacteriana em mulheres assintomáticas. O tratamento é recomendado para mulheres sintomáticas e para assintomáticas quando grávidas, especialmente aquelas com histórico de parto pré-termo e que apresentem comorbidades ou potencial risco de complicações (previamente à inserção de DIU, cirurgias ginecológicas e exames invasivos no trato genital). O tratamento deve ser simultâneo ao procedimento, não havendo razão para sua suspensão ou adiamento.  
55  
A recorrência de VB após o tratamento é comum: 15% a 30% das mulheres apresentam VB sintomática 30 a 90 dias após a terapia com antibióticos, enquanto 70% das pacientes experimentam uma recorrência em nove meses<sup>154–156</sup> .  
Algumas causas justificam a falta de resposta terapêutica aos esquemas convencionais; dentre elas, atividade sexual frequente sem uso de preservativos, duchas vaginais, utilização de DIU, inadequada resposta imune e resistência bacteriana aos imidazólicos. Cepas de _Atopobium vaginae_ resistentes ao metronidazol são identificadas em várias portadoras de vaginose bacteriana recorrente (VBR); contudo, esses bacilos são sensíveis à clindamicina e às cefalosporinas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Vulvovaginite menos frequente nos dias atuais, é causada por um protozoário flagelado unicelular, o _Trichomonas vaginalis_ , e parasita com mais frequência a genitália feminina que a masculina. Seus sinais e sintomas característicos consistem em corrimento vaginal intenso, amarelo-esverdeado, por vezes acinzentado, bolhoso e espumoso, acompanhado de odor fétido (na maioria dos casos, lembrando peixe) e prurido eventual, que pode constituir reação alérgica à afecção. Em caso de inflamação intensa, o corrimento aumenta e pode haver sinusiorragia e dispareunia<sup>157</sup> . Também podem ocorrer edema vulvar e sintomas urinários, como disúria.  
Cerca de 30% dos casos são assintomáticos, mas algum sinal clínico pode aparecer. Não há complicações sérias na mulher na grande maioria dos casos, mas a tricomoníase pode propiciar a transmissão de outros agentes infecciosos agressivos, facilitar DIP, VB e, na gestação, quando não tratada, pode evoluir para rotura prematura das membranas<sup>158</sup> .  
No exame especular, percebem-se microulcerações no colo uterino, que dão um aspecto de morango ou framboesa (teste de Schiller “onçoide” ou “tigroide”). A transudação inflamatória das paredes vaginais eleva o pH para 6,7 a 7,5 e, nesse meio alcalino, pode surgir variada flora bacteriana patogênica, inclusive anaeróbica; por conseguinte se estabelece a vaginose bacteriana associada, que libera as aminas com odor fétido, além de provocar bolhas no corrimento vaginal purulento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O diagnóstico laboratorial microbiológico mais comum é o exame a fresco, mediante gota do conteúdo vaginal e soro fisiológico, com observação do parasita ao microscópio. Habitualmente visualiza-se o movimento do protozoário, que é flagelado, e um grande número de leucócitos. O pH quase sempre é maior que 5,0. Na maioria dos casos, o teste das aminas é positivo. À bacterioscopia com coloração pelo método de Gram, observa-se o parasita Gram-negativo, de morfologia característica. A cultura pode ser requisitada nos casos de difícil diagnóstico. Os meios de cultura são vários e incluem o de Diamond, Trichosel e In Pouch TV<sup>159</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As cervicites são frequentemente assintomáticas (em torno de 70% a 80%). Nos casos sintomáticos, as principais queixas são corrimento vaginal, sangramento intermenstrual ou pós-coito, dispareunia, disúria, polaciúria e dor pélvica crônica<sup>160–167</sup> . Os principais agentes etiológicos são _Chlamydia trachomatis_ e _Neisseria gonorrhoeae_<sup>168</sup> .  
Os fatores associados à prevalência são: mulheres sexualmente ativas com idade inferior a 25 anos, novas ou múltiplas parcerias sexuais, parcerias com IST, história prévia ou presença de outra IST e uso irregular de preservativo<sup>169–174</sup> .  
Ao exame físico, podem estar presentes dor à mobilização do colo uterino, material mucopurulento no orifício externo do colo, edema cervical e sangramento ao toque da espátula ou _swab_ . As principais complicações da cervicite por clamídia e gonorreia, quando não tratadas, incluem: dor pélvica, DIP, gravidez ectópica e infertilidade<sup>160</sup> .  
O risco de desenvolvimento de sequelas é dependente do número de episódios de DIP<sup>175–182</sup> . Para mais informações sobre DIP, consultar o Capítulo 10.  
As infecções por _C. trachomatis_ e _N. gonorrhoeae_ em mulheres frequentemente não produzem corrimento vaginal; entretanto, se ao exame especular for constatada a presença de muco-pus cervical, friabilidade do colo ou teste do cotonete positivo, a paciente deve ser tratada para gonorreia e clamídia, pois esses são os agentes etiológicos mais frequentes da cervicite mucopurulenta ou endocervicite – inflamação da mucosa endocervical.  
56  
Os sinais e sintomas da cervicite por _C. trachomatis_ ou _N. gonorrhoeae_ , em 60% a 80% das vezes, caracterizam-se por dor à manipulação do colo, muco cervical turvo ou amarelado e friabilidade cervical<sup>183–193</sup> ; porém, o diagnóstico sindrômico de cervicite não se presta para aplicação em massa, tendo em vista que o agravo é assintomático em uma frequência que pode atingir até 93,3%<sup>194–196</sup> .  
Além disso, outros sintomas, como corrimento vaginal, febre, dor pélvica, dispareunia e disúria também podem estar associados<sup>184–191,197–200</sup> , não sendo contemplados no fluxograma.  
As infecções gonocócicas ou por clamídia durante a gravidez poderão estar relacionadas a partos pré-termo, ruptura prematura de membrana, perdas fetais, retardo de crescimento intrauterino e endometrite puerperal, além de conjuntivite e pneumonia do RN<sup>158,201–204</sup> .  
No RN, a principal manifestação clínica é a conjuntivite, podendo ocorrer septicemia, artrite, abcessos de couro cabeludo, pneumonia, meningite, endocardite e estomatite<sup>205</sup> . A oftalmia neonatal, definida como conjuntivite purulenta do RN, ocorre no primeiro mês de vida e pode levar à cegueira, especialmente, quando causada pela _N. gonorrhoeae_ . Por isso, a doença deve ser tratada imediatamente, a fim de prevenir dano ocular. Geralmente, o RN é levado ao serviço de saúde por causa de eritema e edema de pálpebras e conjuntiva e/ou presença de material mucopurulento nos olhos.  
A conjuntivite por clamídia é bem menos severa e seu período de incubação varia de cinco a 14 dias. A frequência relativa da infecção pelos dois agentes etiológicos depende da prevalência dessas IST em gestantes e do uso da profilaxia ocular na primeira hora após o nascimento, a qual é efetiva contra _N. gonorrhoeae_ , mas frequentemente não o é contra _C. trachomatis_ . Na ocasião do parto vaginal, o risco de transmissão vertical situa-se entre 30% e 50%, tanto para _N. gonorrhoeae_ como para _C. trachomatis_ .  
É recomendada pelo “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais” – PCDT TV a realização de pesquisa para _N. gonorrhoeae_ e _C. trachomatis_ por biologia molecular na primeira consulta de pré-natal<sup>11</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O diagnóstico laboratorial da cervicite causada por _C. trachomatis_ e _N. gonorrhoeae_ pode ser feito por pela detecção do material genético dos agentes infecciosos por biologia molecular. Esse método é o de escolha para todos os casos, sintomáticos e assintomáticos.  
Para os casos sintomáticos, a cervicite gonocócica também pode ser diagnosticada pela identificação do gonococo após cultura em meio seletivo (Thayer-Martin modificado), a partir de amostras endocervicais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os fluxogramas representados nas Figuras 11 e 12 sumarizam o manejo do corrimento vaginal e cervical.  
57  
**Figura 11 – Fluxograma para o manejo de corrimento vaginal**  
<!-- Start of picture text -->
Fatores de riso para IST<br>= ldde abaio de 30 aos<br>Barer= Parceris com aes IST aca Poe eda cline: aval priticas seals ftores de isco para IST, data da itima<br>=“Uso Hist regular previe/presenga de preservatvo de outa ST Jou‘menstrual, outros potencias agentes pics dehiglenevagnl lanes ewslocals. de medeamentos ‘Spica ou srtmicos<br>Fro vaginal consists, core lteragesno odor do correo, presenga de pro<br>fou ritabo loa<br>ordo8 mobilizagéo coo, edema do cervical colo uterino,esangraentomaterial ao mucopurulento toque daesptula no orificio ou swab? externo GH[a]<br>“a Microscopia a fresco disponivel na consulta?) <—[_sim_]#———{_Corrimento vaginal confirmado? [ nao |<br>= pH vaginal e/ou KOH a 10% disponivel?<br>Ce—§—-<br>Sa<br>== 9<br>= Realzr erento centre na pessoa ees prices sexual. ; ;<br>= Contrib pare que a pessoa reconhegae minimize o proprio<br>= Oferecertestagem para HV sls ehepattes Be C.<br>=“TinformarindicatOferecer sobrevecinegdoa posbidadepre hepatitesde reaizarA e 8 prevensfoe pare HPV,combinadaquando ‘alas 0 exame preventive de cdncer decolo do ter esté em da.<br>poraiSt/HWhepotes<br>“Traar,Soecompan or entav i as. @ psiose sues paceres sexual. peat Quando ye realiadacoetatet pareIEmicroscopepor coloragtode com, Gram, conierartentadoconsidraroresutedo  parapara manejomaneo  do.docaso.<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
**Figura 12 – Fluxograma para o manejo de cervicite**  
<!-- Start of picture text -->
{As cervicites sfo frequentemente<br>assintométicas. Os fatores associados &<br>prevaléncia da cervicite s80: mulheres<br>: iriae ‘novas ou miltiplas parcerias sexuais; parcerias<br>© uso irregular do preservativo.<br>—_—— com IST; histéria prévia ou presenca de outra IST<br>Muco cervical turvo ou amarele fri bilidade a do cervical, edema cervical e as]<br>sangramentoao toque da espatula ou swab, Dor a mobilizacaodo colo uterino?<br>“para : Coles 4 " —_[ =a] Corrimentoconfirmado? vaginal<br>Avaliar se o exame preventivo de cancer<br>de colo do itero est em dia<br>* Podem ser utiizados kits de biologia molecular que detectam mais patégenos simultaneamente, incluindo Mycoplasma genitalium.<br>** Lembrar que mesmo nos casos que apresentam colo e muco cervical normal, Chlamydia trachomatis e Mycoplasma genitalium podem estar presentes e provas de biologia<br>molecular se disponiveis, devem ser utiizadas pare afastar essa possbilidade (principalmente em mulheres jovens).<br>*** quando a microscopia a fresco ndo estiver disponivel, instituir tratamento imediato de vaginose bacteriana,tricomoniase e/ou candidliase, conforme avaliacio clinica. Se<br>realizada coleta para microscopia por coloracio de Gram, considerar o resultado para manejo do caso.<br><!-- End of picture text -->  
58

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O tratamento para cada uma das infecções deve ser realizado de acordo com os Quadros 31 a 35.  
**Quadro 31 – Tratamento de gonorreia e clamídia**  
|**GONORREIA/CLAMÍDIA**|**TRATAMENTO**|
|---|---|
|**Infecção gonocócica NÃO complicada (uretra,**<br>**colo do útero, reto e faringe)**|Ceftriaxona 500mg, IM, dose única<br>**MAIS**<br>Azitromicina 500mg, 2 comprimidos, VO, dose única|
|**Infecção gonocócica disseminada**|Ceftriaxona 1g IM ou IV ao dia, completando ao menos 7 dias de tratamento<br>**MAIS**<br>Azitromicina 500mg, 2 comprimidos, VO, dose única|
|**Conjuntivite gonocócica no adulto**|Ceftriaxona 1g, IM, dose única|
|**Infecção por clamídia**|Azitromicina 500mg, 2 comprimidos, VO, dose única<br>**OU**<br>Doxiciclina 100mg, VO, 2x/dia, por 7 dias (exceto gestantes)|  
Fonte: DCCI/SVS/MS.  
**Quadro 32 – Prevenção e tratamento de oftalmia neonatal**  
|**OFTALMIA NEONATAL**|**TRATAMENTO**|
|---|---|
|**Prevenção da oftalmia neonatal**|Nitrato de prata a 1% (método de Crede), aplicação única, na 1ª hora após o<br>nascimento;<br>**OU**|
||Tetraciclina a 1% (colírio), aplicação única, na 1ª hora após o nascimento|
|**Tratamento da oftalmia neonatal**|Ceftriaxona 25-50mg/kg/dia, IM, no máximo 125mg em dose única|  
- Instilação local de solução fisiológica, de hora em hora;  
- Não se indica a instilação local de penicilina;  
- Nos casos de resposta terapêutica não satisfatória, considerar a hipótese de infecção simultânea por clamídia.  
Fonte: DCCI/SVS/MS.  
**Quadro 33 – Tratamento de candidíase vulvovaginal**  
|**CANDIDÍASE VULVOVAGINAL**|**TRATAMENTO**|
|---|---|
|**Primeira opção**|Miconazol creme a 2% ou outros derivados imidazólicos, via vaginal, um<br>aplicador cheio, à noite ao deitar-se, por 7 dias<br>**OU**<br>Nistatina 100.000 UI, uma aplicação, via vaginal, à noite ao deitar-se, por 14 dias|
|**Segunda opção**|Fluconazol 150mg, VO, dose única<br>**OU**<br>Itraconazol 100mg, 2 comprimidos, VO, 2x/dia, por 1 dia|
|**CVV complicada e CVV recorrente**|Indução:fluconazol 150mg, VO, 1x/dia, dias 1, 4 e 7<br>**OU**<br>Itraconazol 100mg, 2 comprimidos, VO, 2x/dia, por 1 dia<br>**OU**<br>Miconazol creme vaginal tópico diário por 10-14 dias.<br>Manutenção:fluconazol 150mg, VO, 1x/semana, por 6 meses<br>**OU**<br>Miconazol creme vaginal tópico, 2x/semana<br>**OU**<br>Óvulo vaginal, 1x/semana, durante 6 meses|  
59  
- As parcerias sexuais não precisam ser tratadas, exceto as sintomáticas.  
- É comum durante a gestação, podendo haver recidivas pelas condições propícias do pH vaginal que se estabelecem nesse período.  
- Tratamento em gestantes e lactantes: somente por via vaginal. O tratamento oral está contraindicado.  
Fonte: DCCI/SVS/MS.  
**Quadro 34 – Tratamento de vaginose bacteriana**  
|**VAGINOSE BACTERIANA**|**TRATAMENTO**|
|---|---|
|**Primeira opção (incluindo gestantes e lactantes)**|Metronidazol 250mg, 2 comprimidos VO, 2x/dia, por 7 dias<br>**OU**<br>Metronidazol gel vaginal 100mg/g, um aplicador cheio via vaginal, à noite ao<br>deitar-se, por 5 dias|
|**Segunda opção**|Clindamicina 300mg, VO, 2x/dia, por 7 dias|
|**Recorrente**|Metronidazol 250mg, 2 comprimidos VO, 2x/dia, por 10-14 dias<br>**OU**<br>Metronidazol gel vaginal 100mg/g, um aplicador cheio, via vaginal, 1x/ dia, por<br>10 dias, seguido de tratamento supressivo com óvulo de ácido bórico intravaginal<br>de 600mg ao dia por 21 dias e metronidazol gel vaginal 100mg/g, 2x/semana, por<br>4-6 meses|  
- O tratamento das parcerias sexuais não está recomendado.  
- Para as puérperas, recomenda-se o mesmo tratamento das gestantes.  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
|**TRICOMONÍASE**|**TRATAMENTO**|
|---|---|
|**Primeira opção (incluindo gestantes e**<br>**lactantes)**|Metronidazol 400mg, 5 comprimidos, VO, dose única (dose total 2g)<br>**OU**|
||Metronidazol 250mg, 2 comprimidos, VO, 2x/dia, por 7 dias|  
- As parcerias sexuais devem ser tratadas com o mesmo esquema terapêutico. O tratamento pode aliviar os sintomas de corrimento vaginal em gestantes, além de prevenir infecção respiratória ou genital em RN.  
- Para as puérperas, recomenda-se o mesmo tratamento das gestantes.  
Fonte: DCCI/SVS/MS.  
_Observações:_  
- Durante o tratamento com metronidazol, deve-se evitar a ingestão de álcool (efeito antabuse, devido à interação de derivados imidazólicos com álcool, caracterizado por mal-estar, náuseas, tonturas e “gosto metálico na boca”).  
- Durante o tratamento, devem-se suspender as relações sexuais.  
- Manter o tratamento durante a menstruação.  
- O tratamento da(s) parceria(s) sexual(is), quando indicado, deve ser realizado de forma preferencialmente presencial, com a devida orientação, solicitação de exames de outras IST (sífilis, HIV, hepatites B e C) e identificação, captação e tratamento de outas parcerias sexuais, buscando a cadeia de transmissão.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- a. PVHIV: devem ser tratadas com os esquemas habituais, mas atentar para a interação medicamentosa entre o metronidazol e o ritonavir, que pode elevar a intensidade de náuseas e vômitos, reduzindo a adesão aos antirretrovirais. Para evitar tal ocorrência, recomenda-se intervalo de duas horas entre as ingestas do metronidazol e ritonavir.  
- b. A tricomoníase vaginal pode alterar a classe da citologia oncológica. Por isso, nos casos em que houver alterações morfológicas celulares e tricomoníase, deve-se realizar o tratamento e repetir a citologia após três meses, para avaliar se as alterações persistem.  
60

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- a. VB recorrente: o triplo regime (metronidazol gel dez dias + ácido bórico 21 dias + metronidazol gel duas vezes por semana, por quatro a seis meses) parece promissor, porém requer validação com estudo prospectivo randomizado e controlado. O papel do ácido bórico é remover o “biofilme” vaginal que facilitaria a persistência das bactérias patogênicas<sup>206</sup> .  
- b. O uso de antissépticos, pré-bióticos e pró-bióticos e a reposição de lactobacilos vem sendo estudada, mas há ainda longo caminho a percorrer, pois a reposição deve ser realizada com as espécies que habitam a vagina e produzem H2O2, características primordiais para a proteção contra várias infecções, inclusive VB<sup>206,207</sup> .  
- c. PVHIV: devem ser tratadas com os esquemas habituais, mas atentar para interação medicamentosa entre o metronidazol e o ritonavir, que pode elevar a intensidade de náuseas e vômitos, reduzindo a adesão aos antirretrovirais. Para evitar tal ocorrência, recomenda-se intervalo de duas horas entre as ingestas do metronidazol e ritonavir.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- a. Nos casos recorrentes ou de difícil controle, devem-se investigar as causas sistêmicas predisponentes (diabetes, imunodepressão, inclusive a infecção pelo HIV e uso de corticoides).  
- b. Dentre as reações adversas raras (entre 0,01% e 0,1%) do uso do fluconazol, citam-se agranulocitose, leucopenia, neutropenia, trombocitopenia, anafilaxia, angioedema, hipertrigliceridemia, hipercolesterolemia, hipocalemia, toxicidade e insuficiência hepática.  
- c. PVHIV: devem ser tratadas com os esquemas habituais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As uretrites são caracterizadas por inflamação e corrimento uretral. Os agentes microbianos das uretrites podem ser transmitidos por relação sexual vaginal, anal e oral. O corrimento uretral costuma ter aspecto que varia de mucoide a purulento, com volume variável, estando associado a dor uretral (independentemente da micção), disúria, estrangúria (micção lenta e dolorosa), prurido uretral e eritema de meato uretral.  
Entre os fatores associados às uretrites, foram encontrados: idade jovem, baixo nível socioeconômico, múltiplas parcerias ou nova parceria sexual, histórico de IST e uso irregular de preservativos.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os agentes etiológicos mais frequentes das uretrites são a _Neisseria gonorrhoeae_ e a _Chlamydia trachomatis_ . Outros agentes, como _Trichomonas vaginalis, Ureaplasma urealyticum_ , enterobactérias (nas relações anais insertivas), _Mycoplasma genitalium_ , vírus do herpes simples (HSV, do inglês _Herpes Simplex Virus_ ), adenovírus e _Candida sp._ são menos frequentes. Causas traumáticas (produtos e objetos utilizados na prática sexual) devem ser consideradas no diagnóstico diferencial das uretrites.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É um processo infeccioso e inflamatório da mucosa uretral, causado pela _Neisseria gonorrhoeae_ (diplococo Gram-negativo intracelular). O risco de transmissão de um parceiro infectado a outro é, em média, 50% por ato sexual. Os sinais e sintomas são determinados pelos locais primários de infecção: as membranas mucosas da uretra (uretrite), endocérvice (cervicite), reto (proctite), faringe (faringite) e conjuntiva (conjuntivite).  
A infecção uretral no homem é assintomática em menos de 10% dos casos. Nos casos sintomáticos, há presença de corrimento em mais de  
80% e de disúria em mais de 50%. O período de incubação costuma ser de dois a cinco dias após a infecção. Nas mulheres, a uretrite gonocócica é frequentemente assintomática.  
O corrimento mucopurulento ou purulento é frequente. Raramente, há queixa de sensibilidade aumentada no epidídimo e queixas compatíveis com balanite (dor, edema, prurido, hiperemia da região prepucial, descamação da mucosa e, em alguns casos, material purulento e de odor desagradável no prepúcio). As complicações no homem ocorrem por infecção ascendente a partir da uretra, podendo ocasionar  
61  
orquiepididimite, prostatite e estenose de uretra.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É a uretrite sintomática cuja bacterioscopia pela coloração de Gram, cultura e detecção de material genético por biologia molecular são negativas para o gonococo. Vários agentes têm sido responsabilizados por essas infecções, como _Chlamydia trachomatis, Mycoplasma genitalium, Ureaplasma urealyticum, Mycoplasma hominis, Trichomonas vaginalis_ , entre outros<sup>208–210</sup> .  
A infecção por clamídia no homem é responsável por aproximadamente 50% dos casos de uretrite não gonocócica. A transmissão ocorre pelo contato sexual (risco de 20% por ato), sendo o período de incubação, no homem, de 14 a 21 dias. Estima-se que dois terços das parceiras estáveis de homens com uretrite não gonocócica hospedem a _C. trachomatis_ na endocérvice. Elas podem reinfectar sua(s) parceria(s) sexual(ais)e desenvolver quadro de DIP se permanecerem sem tratamento.  
A uretrite não gonocócica caracteriza-se, habitualmente, pela presença de corrimentos mucoides, discretos, com disúria leve e intermitente. A uretrite subaguda é a forma de apresentação em aproximadamente 50% dos pacientes com uretrite causada por _C. trachomatis_ . Entretanto, em alguns casos, os corrimentos das uretrites não gonocócicas podem simular, clinicamente, os da gonorreia. As uretrites causadas por _C. trachomatis_ podem evoluir para prostatite, epididimite, balanite, conjuntivite (por autoinoculação) e síndrome uretro-conjuntivo-sinovial ou síndrome de Reiter.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os pacientes com diagnóstico de uretrite devem retornar ao serviço de saúde entre sete e dez dias após o término do tratamento.  
Os sintomas persistentes ou recorrentes de uretrite podem resultar dos fatores descritos no Quadro 36.  
**Quadro 36 – Fatores associados a uretrites persistentes**  
- Reexposição a parceria sexual não tratada.  
- Infecção adquirida de outra parceria sexual.  
- Medicamentos não tomados corretamente ou esquemas não completados.  
- Infecção por outros patógenos.  
- Presença de organismos resistentes.  
- Outras causas (por exemplo, infecção do trato urinário, prostatite, fimose, irritação química, estenoses uretrais, tumores).  
Fonte: DCCI/SVS/MS.  
Nesses casos, deve-se realizar a avaliação, principalmente, por meio da história clínica, considerando a possibilidade de reinfecção ou o tratamento inadequado para clamídia e gonorreia. Descartadas tais situações, devem-se pesquisar agentes não suscetíveis ao tratamento anterior (ex.: _Mycoplasma genitalium, Trichomonas vaginalis_ e _Ureaplasma urealyticum_ ).  
Outras causas não infecciosas de uretrites, como trauma (ordenha continuada), instrumentalização e inserção de corpos estranhos intrauretrais ou parauretrais ( _piercings_ ) e irritação química (uso de certos produtos lubrificantes e espermicidas) devem ser consideradas no diagnóstico diferencial de uretrites persistentes.  
O _Mycoplasma genitalium_ foi identificado pela primeira vez em 1980 e reconhecido como uma importante causa de uretrite não gonocócica e também de algumas doenças do trato genital em mulheres<sup>211–216</sup> . Entre as mulheres, foi associado ao aumento do risco de cervicite, DIP, parto prematuro, infertilidade e aborto espontâneo<sup>210</sup> . As taxas de prevalência publicadas variam muito entre as populações estudadas<sup>209</sup> .  
O _M. genitalium_ não apresenta parede celular; portanto, antibióticos como os beta-lactâmicos (incluindo penicilinas e cefalosporinas) não são eficazes. A introdução da azitromicina, usada como terapia de dose única para infecções por clamídia, resultou na depuração do _M. genitalium_ do trato urogenital, ocorrendo eliminação do patógeno sem o desenvolvimento de doença. Com o passar dos anos, o desenvolvimento de resistência aos macrolídeos começou a ser identificado em algumas populações<sup>211,213,214,217–221</sup> .  
O insucesso do tratamento com azitromicina foi notificado pela primeira vez na Austrália e subsequentemente documentado em vários  
continentes. Relatórios recentes indicam uma tendência ascendente na prevalência de infecções por _M. genitalium_ resistentes aos macrolídeos (resistência transmitida); casos de resistência induzida após terapia com azitromicina também foram documentados. Não há evidências de que um regime estendido com azitromicina (1,5g) seja superior ao regime de 1g em dose única<sup>222</sup> .  
62  
A moxifloxacina permanece altamente ativa contra a maioria dos _M. genitalium_ resistentes a macrolídeos. No entanto, os primeiros casos clínicos de falha do tratamento com moxifloxacina foram publicados recentemente<sup>214,215,217,223</sup> .  
Tratamentos contínuos e inapropriados provavelmente levarão a infecções intratáveis no futuro<sup>220,221,224,225</sup> . Portanto, o _M. genitalium_ é um problema emergente, necessitando de uma vigilância frequente e estudos com novas opções de diagnóstico e tratamento<sup>33</sup> . A moxifloxacina não está disponível no SUS para uso nas infecções por _Mycoplasma genitallium_ .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A infecção retal é geralmente assintomática, mas pode causar proctite (12%) ou desconforto perianal ou anal (7%), sendo mais frequentes em homens que fazem sexo com homens (HSH).  
A infecção de faringe, tanto em homens como em mulheres, é habitualmente assintomática em mais de 90% dos casos. O diagnóstico se faz a partir do histórico sexual e da prática sexual (sexo oral, boca-ânus), sendo estabelecido por meio das indicações de rastreamento, conforme a seção 2.4.  
A conjuntivite gonocócica é mais comum em recém-nascidos de mães infectadas e em adultos; pode ocorrer por autoinoculação e fômites, evoluindo com secreção purulenta e edema periorbital. Se não tratada, pode levar a complicações como ulceração de córnea, perfuração e cegueira.  
A infecção gonocócica disseminada é rara, entre 0,5% a 3%; resulta da disseminação hematológica a partir das membranas mucosas infectadas e causa febre, lesões cutâneas, artralgia, artrite e tenossinovite sépticas. Raramente, pode também causar endocardite aguda, pericardite, meningite e peri-hepatite. Acomete mais as mulheres, sendo associada à infecção assintomática persistente, e o maior risco é durante o período menstrual, gravidez e pós-parto imediato.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A escolha do método diagnóstico irá depender da presença de sinais e sintomas. A seguir, separam-se os casos entre assintomáticos e sintomáticos.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Após identificação de risco de IST (por meio da anamnese, incluindo história sexual, Capítulo 2 deste PCDT) e exclusão de sinais e sintomas clínicos, é necessário realizar o rastreamento dos assintomáticos de acordo com os critérios descritos na seção 2.4, Quadro 5 – Rastreamento de IST. Para os casos assintomáticos, o método diagnóstico de escolha é a detecção de clamídia e gonococo por biologia molecular.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Após identificação dos sinais e sintomas clínicos de uretrite, devem-se executar os testes diagnósticos apropriados. Devido às taxas de resistência, é fundamental priorizar testes que identifiquem o agente infeccioso, principalmente em casos de reinfecção. Segue a descrição dos métodos diagnósticos incorporados ao SUS:  
- Detecção de clamídia e gonococo por biologia molecular: método com elevada sensibilidade e especificidade. Além de definir o agente etiológico para os casos de infecções sintomáticas, consiste no método de escolha para o rastreio de infecções assintomáticas;  
- Bacterioscopia: a coloração de Gram é um método rápido e possui bom desempenho para o diagnóstico de gonorreia em homens sintomáticos com corrimento uretral. A infecção gonocócica é estabelecida pela presença de diplococos Gram-negativos intracelulares em leucócitos polimorfonucleares. Em mulheres, no entanto, o esfregaço de secreções cervicais detecta apenas 40% a 60% das infecções. Isso ocorre porque a flora vaginal é densa e a identificação dos diplococos Gram-negativos pode ficar  
63  
comprometida. Outra razão para essa baixa sensibilidade pode ser o número reduzido de gonococos nos esfregaços de amostras da endocérvice ou falha técnica na coleta. O diagnóstico de pessoas assintomáticas por microscopia não é recomendado;  
- Cultura de amostras de corrimento uretral em meio seletivo de Thayer-Martin ou similar: útil na identificação de _Neisseria gonorrhoae_ , quando causador da infecção. As colônias Gram-negativas, oxidase e catalase positivas devem ser submetidas a provas bioquímicas (manuais ou automatizadas) para confirmação da espécie _Neisseria gonorrhoae_ , pois o meio seletivo permite o crescimento de demais espécies do gênero _Neisseria_ ;  
- O teste positivo de esterase leucocitária na urina de primeiro jato, ou exame microscópico de sedimento urinário de primeiro jato, apresentando >10 PMN por campo, sugere presença de infecção, mas não define o agente infeccioso. Portanto, poderá ser utilizado na ausência dos outros métodos.  
Além da identificação do patógeno, quando possível, é importante investigar o perfil de susceptibilidade aos antimicrobianos para cepas isoladas e identificadas como _Neisseria gonorrhoeae_ , para fins de vigilância da resistência desse patógeno.  
Para mais informações sobre o diagnóstico laboratorial de corrimento uretral, consultar o manual da OMS, “Diagnóstico Laboratorial de Doenças Sexualmente Transmissíveis, incluindo o Vírus da Imunodeficiência Humana”<sup>110</sup> e as aulas do Telelab, disponíveis em <u>http://telelab.aids.gov.br.</u>

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O fluxograma da Figura 13 sumariza o manejo do corrimento uretral, com suporte mínimo de laboratório.  
**Figura 13 – Fluxograma para o manejo de corrimento uretral**  
<!-- Start of picture text -->
Fatores de isco para IST . -<br>DatsNovas~Parcerias ahatstou miitplas comaanIST  parcerias anee  sexuals Financials aa Histériaprodutos e/ouAspecto clinica: do corrimento: objetos avaliarpréticas na prticamucopurulento, sexuais sexual.e fatorescom volume de rsco varidvel, para IST,associado uso de<br>~ Hist6ria prévia/presenca de outra IST a dor uretral (independentemente da micco), distiria, estrangiria<br>= Uso irregular de preservativo {miccio lenta e dolorosa), prurido uretral e eritema de meato uretral<br>Laboratério disponivel?<br>Coleta de material para microscopia (Gram) Quando disponiveis<br>‘e para cultura e/ou biologia molecular* testesmolecularconforme de biologiaachado.répida,tratar ‘Tratargonorreia’ clamidia*  e<br>Presenga de diplococos gram-<br>negativos intracelulares (Gram)? a<br>| Sinaispersistem e sintomas apés 7 [nao |<br>Ta eae<br>scenic biologia molecular, quando realizados. Exclu reinfecco,tratamento<br>Slemicie EeTT<br>Sinais e sintomas persistem apés 7 dias? Ls TateTratar gonorteiaeae Sovae/ouEEEclamidia inadequadogonorreia, resistenciapara clamidia e<br>Rare alee aa ea antimicrobiana, trauma, iritago<br>Trichomonas- vaginalis. alestranhos.uimica ou insergo de corpos<br>[ae] [nie] Sinais e sintomas persistem Referenciar ao servigo<br>~ Realzarorientagéo centrada na pessoa e suas préticas sexuas. apés 14 dias? especializado<br>== Oferecertestagem Contribuir para que para a pessoa HIV,  reconhegae siflise hepatites  minimize BC o prépriorsco de infecg#o por uma IST.<br>+ Oferecer vecinogBo pera hepattes Ae Be pare HPV, quando indicado, . *Existem kits de biologla molecular que detectam mais patégenos simultaneamente,além de cama e<br>pee=~Trata , Notifcar r eacompanhar 0Dee caso,9 quandoereotientararee indicado, pessoaeee reveneag suas pacerias compensexual.co pore UAWSep eae: ‘gonococo,CapaI e que tambémee so itelsa  parai odiagndstico eiolégicoa erieae oreona a de uretrtes,ircomo M. genital.<br><!-- End of picture text -->  
64  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O Quadro 37 apresenta um resumo sobre as opções de tratamento para uretrites.  
**Quadro 37 – Tratamento de uretrites**  
|**CONDIÇÃO CLÍNICA**|**PRIMEIRA OPÇÃO**|**SEGUNDA OPÇÃO**|**COMENTÁRIOS**|
|---|---|---|---|
|**Uretrite sem identificação do**<br>**agente etiológico**|Ceftriaxona 500mg, IM, dose<br>única<br>**MAIS**<br>Azitromicina 500mg, 2<br>comprimidos, VO, dose única|Ceftriaxona 500mg, IM, dose<br>única<br>**MAIS**<br>Doxiciclina 100mg, 1<br>comprimido, VO, 2x/ dia, por 7<br>dias|–|
|**Uretrite gonocócica e demais**<br>**infecções gonocócicas NÃO**<br>**complicadas (uretra, colo do**<br>**útero, reto e faringe)**|Ceftriaxona 500mg, IM, dose<br>única<br>**MAIS**<br>Azitromicina 500mg, 2<br>comprimidos, VO, dose única|–|–|
|**Uretrite não gonocócica**|Azitromicina 500mg, 2<br>comprimidos, VO, dose única|Doxiciclina 100mg, 1<br>comprimido, VO, 2x/ dia, por 7<br>dias|A resolução dos sintomas pode<br>levar até 7 dias após a conclusão<br>da terapia|
|**Uretrite por clamídia**|Azitromicina 500mg, 2<br>comprimidos, VO, dose única|Doxiciclina 100mg, 1<br>comprimido, VO, 2x/ dia, por 7<br>dias|A resolução dos sintomas pode<br>levar até 7 dias após a conclusão<br>da terapia|
|**Retratamento de infecções**<br>**gonocócicas**|Ceftriaxona 500mg, IM, dose<br>única<br>**MAIS**<br>Azitromicina 500mg, 4<br>comprimidos, VO, dose única|Gentamicina 240mg, IM<br>**MAIS**<br>Azitromicina 500mg, 4<br>comprimidos, VO, dose única|Para casos de falha de tratamento.<br>Possíveis reinfecções devem ser<br>tratadas com as doses habituais|
|**Uretrite por****_Mycoplasma_**<br>**_genitalium_**|Azitromicina 500mg, 2<br>comprimidos, VO, dose única|–|–|
|**Uretrite por****_Trichomonas_**<br>**_vaginalis_**|Metronidazol 250mg, 2<br>comprimidos VO, 2x/dia, por 7<br>dias|Clindamicina 300mg, VO,<br>2x/dia, por 7 dias|–|
|**Infecção gonocócica**<br>**disseminada (exceto meningite**<br>**e endocardite)**|Ceftriaxona 1g IM ou IV ao<br>dia, completando ao menos 7<br>dias de tratamento<br>**MAIS**<br>Azitromicina 500mg, 2<br>comprimidos, VO, dose única|–|–|
|**Conjuntivite gonocócica no**<br>**adulto**|Ceftriaxona 1g, IM, dose única|–|–|  
 Se o paciente apresentar alergia grave às cefalosporinas, indicar azitromicina 500mg, 4 comprimidos, VO, dose única (dose total: 2g).  Os pacientes e a(s) parceria(s) devem se abster de relações sexuais desprotegidas até que o tratamento de ambos esteja completo (ou seja, após o término do tratamento com múltiplas doses ou por 7 dias após a terapia com dose única).  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As úlceras genitais representam síndrome clínica, sendo muitas vezes causadas por IST, e se manifestam como lesões ulcerativas erosivas, precedidas ou não por pústulas e/ou vesículas, acompanhadas ou não de dor, ardor, prurido, drenagem de material mucopurulento, sangramento e linfadenopatia regional.  
Embora a úlcera genital esteja frequentemente associada às IST na população sexualmente ativa, em particular nos adolescentes e adultos jovens, a queixa de úlcera genital não é exclusividade das IST e pode estar associada a infecções inespecíficas por fungos, vírus ou bactérias  
65  
(ex.: dermatoses bolhosas, como o pênfigo, o eritema multiforme e a dermatite de contato; líquen plano erosivo; aftas; lesões traumáticas; erupção fixa por drogas e até mesmo lesões malignas, como o carcinoma espinocelular).  
Nesta seção, serão abordadas as IST que se manifestam com úlceras genitais em alguma fase da doença, cujos agentes etiológicos infecciosos mais comuns são:  
- _Treponema pallidum_ (sífilis);  
- HSV-1 e HSV-2 (herpes perioral e genital, respectivamente);  
- _Haemophilus ducreyi_ (cancroide);  
- _Chlamydia trachomatis_ , sorotipos L1, L2 e L3 (LGV);  
- _Klebsiella granulomatis_ (donovanose).  
Esses agentes podem ser encontrados isoladamente ou em associação em uma mesma lesão, como, por exemplo, úlcera genital por  
_Treponema pallidum_ e HSV-2. A prevalência dos agentes etiológicos sofre influência de fatores geográficos, socioeconômicos e de gênero,  
além do número de parcerias sexuais, uso de drogas, circuncisão, sexo profissional, entre outros.  
A presença de úlcera genital está associada a um elevado risco de transmissão e aquisição do HIV e tem sido descrita como a principal causa para a difusão desse vírus nas populações de maior vulnerabilidade; portanto, o diagnóstico e tratamento imediato dessas lesões constitui uma medida de prevenção e controle da epidemia de HIV.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os aspectos clínicos das úlceras genitais são bastante variados e têm baixo poder preditivo do agente etiológico (baixa relação de sensibilidade e especificidade), mesmo nos casos considerados clássicos. O diagnóstico com base na impressão clínica apresentou valores preditivos positivos baixos – 30,9% para sífilis e 32,7% para cancroide – de acordo com os achados do estudo de validação da abordagem sindrômica no Brasil<sup>200</sup> .  
A seguir, serão abordados aspectos específicos de cada úlcera genital.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A sífilis primária, também conhecida como “cancro duro”, ocorre após o contato sexual com o indivíduo infectado. O período de incubação é de 10 a 90 dias (média de três semanas). A primeira manifestação é caracterizada por úlcera, geralmente única, que ocorre no local de entrada da bactéria (pênis, vulva, vagina, colo uterino, ânus, boca ou outros locais do tegumento), indolor, com base endurecida e fundo limpo, rica em treponemas. Esse estágio pode durar entre duas e seis semanas, desaparecendo espontaneamente, independentemente de tratamento.  
Para mais informações, consultar o Capítulo 5 deste PCDT, que aborda o tema sífilis detalhadamente.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os HSV tipos 1 e 2 pertencem à família _Herpesviridae_ , da qual fazem parte o citomegalovírus (CMV), o vírus da varicela zoster, o vírus Epstein-Barr e o vírus do herpes humano 8. Todos são DNA-vírus que variam quanto à composição química e podem ser diferenciados por técnicas imunológicas. Embora os HSV-1 e HSV-2 possam provocar lesões em qualquer parte do corpo, há predomínio do tipo 2 nas lesões genitais e do tipo 1 nas lesões perorais.  
As manifestações da infecção pelo HSV podem ser divididas em primoinfecção herpética e surtos recorrentes. Sabe-se que muitas pessoas que adquirem a infecção por HSV nunca desenvolverão manifestações e que a proporção de infecções sintomáticas é estimada entre 13% e 37%. Entre as pessoas com infecção pelo HIV, as manifestações tendem a ser dolorosas, atípicas e de maior duração.  
A primoinfecção herpética tem um período de incubação médio de seis dias. Em geral, é uma manifestação mais severa, caracterizada pelo surgimento de lesões eritemato-papulosas de um a três milímetros de diâmetro, que rapidamente evoluem para vesículas sobre base eritematosa, muito dolorosas e de localização variável na região genital. O conteúdo dessas vesículas é geralmente citrino, raramente turvo.  
66  
O quadro local na primoinfecção costuma ser bastante sintomático e, na maioria das vezes, é acompanhado de manifestações gerais, podendo cursar com febre, mal-estar, mialgia e disúria, com ou sem retenção urinária. Em especial, nas mulheres, pode simular quadro de infeção urinária baixa. A linfadenomegalia inguinal dolorosa bilateral está presente em 50% dos casos.  
Quando há acometimento do colo do útero, é comum o corrimento vaginal, que pode ser abundante. Entre os homens, o acometimento da uretra pode provocar corrimento e raramente é acompanhado de lesões extragenitais. O quadro pode durar de duas a três semanas.  
Após a infecção genital, o HSV ascende pelos nervos periféricos sensoriais, penetra nos núcleos das células dos gânglios sensitivos e entra em um estado de latência. A ocorrência de infecção do gânglio sensitivo não é reduzida por qualquer medida terapêutica. Episódios de recorrência são bem mais frequentes entre pacientes que apresentam primoinfecção por HSV-2 que por HSV-1.  
Após a infecção genital primária por HSV-2 ou HSV-1, respectivamente, 90% e 60% dos pacientes desenvolvem novos episódios nos primeiros 12 meses, por reativação viral. Essa reativação deve-se a quadros infecciosos, exposição à radiação ultravioleta, traumatismos locais, menstruação, estresse físico ou emocional, antibioticoterapia prolongada e/ou imunodeficiência.  
O quadro clínico das recorrências é menos intenso que o observado na primoinfecção e pode ser precedido de sintomas prodrômicos característicos, como prurido leve ou sensação de “queimação”, mialgias e “fisgadas” nas pernas, quadris e região anogenital.  
A recorrência tende a ser na mesma localização da lesão inicial, geralmente, em zonas inervadas pelos nervos sensitivos sacrais. As lesões podem ser cutâneas e/ ou mucosas. Apresentam-se como vesículas agrupadas sobre base eritematosa, que evoluem para pequenas úlceras arredondadas ou policíclicas. Nas mucosas, é incomum a visualização das vesículas, uma vez que seus tetos rompem muito facilmente. Mais raramente, a ocorrência de lesões pode ser acompanhada de sintomas gerais. As lesões têm regressão espontânea em sete a dez dias, com ou sem cicatriz. A tendência natural dos surtos é se tornarem menos intensos e menos frequentes com o passar do tempo.  
As gestantes portadoras de herpes simples apresentam risco acrescido de complicações fetais e neonatais, sobretudo quando a infecção ocorre no final da gestação. O maior risco de transmissão do vírus acontece no momento da passagem do feto pelo canal de parto. A infecção pode ser ativa (em aproximadamente 50% dos casos) ou assintomática. Recomenda-se a realização de cesariana sempre que houver lesões herpéticas ativas.  
Nos pacientes com imunodepressão, podem ocorrer manifestações atípicas, com lesões ulceradas ou hipertróficas de grandes dimensões, que persistem na ausência de tratamento local ou até mesmo sistêmico. Os diagnósticos diferenciais incluem o cancroide, a sífilis, o LGV, a donovanose e as ulcerações traumáticas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O cancroide é uma afecção provocada pelo _Haemophilus ducreyi_ , mais frequente nas regiões tropicais. Denomina-se também cancro mole, cancro venéreo ou cancro de Ducrey. O período de incubação é geralmente de três a cinco dias, podendo se estender por até duas semanas. O risco de infecção em uma relação sexual é de 80%, mais frequente em homens.  
As lesões são dolorosas, geralmente múltiplas e devidas à autoinoculação. A borda é irregular, apresentando contornos eritemato-edematosos  
e fundo heterogêneo, recoberto por exsudato necrótico, amarelado, com odor fétido, que, quando removido, revela tecido de granulação com sangramento fácil.  
No homem, as localizações mais frequentes são no frênulo e sulco bálano-prepucial; na mulher, na fúrcula e face interna dos pequenos e grandes lábios. Em 30% a 50% dos pacientes, a bactéria atinge os linfonodos inguino-crurais (bubão), sendo unilaterais em 2/3 dos casos, observados quase exclusivamente no sexo masculino pelas características anatômicas da drenagem linfática. No início, ocorre tumefação sólida e dolorosa, evoluindo para liquefação e fistulização em 50% dos casos, tipicamente por orifício único. Raramente, apresenta-se sob a forma de lesão extragenital ou doença sistêmica.  
A cicatrização pode ser desfigurante. A aspiração, com agulha de grosso calibre, dos gânglios linfáticos regionais comprometidos é indicada  
para alívio de linfonodos tensos e com flutuação. São contraindicadas a incisão com drenagem ou excisão dos linfonodos acometidos.  
O diagnóstico diferencial é feito com cancro duro (sífilis primária), herpes genital, LGV, donovanose e erosões traumáticas infectadas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
67  
O LGV é causado por _Chlamydia trachomatis,_ sorotipos L1, L2 e L3. A manifestação clínica mais comum é a linfadenopatia inguinal e/ou femoral, já que esses sorotipos são altamente invasivos aos tecidos linfáticos.  
A evolução da doença ocorre em três fases: inoculação, disseminação linfática regional e sequelas, que são descritas a seguir:  
- **Fase de inoculação:** inicia-se por pápula, pústula ou exulceração indolor, que desaparece sem deixar sequela. Muitas vezes, não é notada pelo paciente e raramente é observada pelo profissional de saúde. Localiza-se, no homem, no sulco coronal, frênulo e prepúcio; na mulher, na parede vaginal posterior, colo uterino, fúrcula e outras partes da genitália externa;  
- **Fase de disseminação linfática regional:** no homem, a linfadenopatia inguinal se desenvolve entre uma a seis semanas após a lesão inicial; é geralmente unilateral (em 70% dos casos) e se constitui no principal motivo da consulta. Na mulher, a localização da adenopatia depende do local da lesão de inoculação;  
- **Fase de sequelas:** o comprometimento ganglionar evolui com supuração e fistulização por orifícios múltiplos, que correspondem a linfonodos individualizados, parcialmente fundidos em uma grande massa. A lesão da região anal pode levar a proctite e proctocolite hemorrágica. O contato orogenital pode causar glossite ulcerativa difusa, com linfadenopatia regional. Podem ocorrer sintomas gerais, como febre, mal-estar, anorexia, emagrecimento, artralgia, sudorese noturna e meningismo. Os bubões que se tornarem flutuantes podem ser aspirados com agulha calibrosa, não devendo ser incisados cirurgicamente. A obstrução linfática crônica leva à elefantíase genital, que na mulher é denominada estiomene. Além disso, podem ocorrer fístulas retais, vaginais e vesicais, além de estenose retal.  
Recomenda-se a pesquisa de _C. trachomatis_ em praticantes de sexo anal que apresentem úlceras anorretais. Mulheres com prática de coito anal ou HSH receptivos podem apresentar proctocolites como manifestação inicial. O uso de preservativos ou outros métodos de barreira para sexo oral, vaginal e anal previnem a infecção por _C. trachomatis_ . Acessórios sexuais devem ser limpos antes de sua utilização, sendo necessariamente de uso individual.  
O diagnóstico de LGV deve ser considerado em todos os casos de adenite inguinal, elefantíase genital e estenose uretral ou retal.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É uma IST crônica progressiva, causada pela bactéria _Klebsiella granulomatis_ . Acomete preferencialmente pele e mucosas das regiões  
genitais, perianais e inguinais. É pouco frequente, ocorrendo na maioria das vezes em climas tropicais e subtropicais. A donovanose  
(granuloma inguinal) está frequentemente associada à transmissão sexual, embora os mecanismos de transmissão não sejam bem conhecidos, sendo a transmissibilidade baixa.  
O quadro clínico inicia-se com ulceração de borda plana ou hipertrófica, bem delimitada, com fundo granuloso, de aspecto vermelho vivo e  
de sangramento fácil. A ulceração evolui lenta e progressivamente, podendo tornar-se vegetante ou úlcero-vegetante. As lesões costumam ser múltiplas, sendo frequente a configuração em “espelho” nas bordas cutâneas e/ou mucosas.  
Há predileção pelas regiões de dobras e região perianal. Não ocorre adenite, embora raramente possam se formar pseudobubões (granulações subcutâneas) na região inguinal, quase sempre unilaterais. Na mulher, a forma elefantiásica é uma sequela tardia, sendo observada quando há predomínio de fenômenos obstrutivos linfáticos. A localização extragenital é rara e, quase sempre, ocorre a partir de lesões genitais ou perigenitais primárias.  
O diagnóstico diferencial de donovanose inclui sífilis, cancroide, tuberculose cutânea, amebíase cutânea, neoplasias ulceradas, leishmaniose tegumentar americana e outras doenças cutâneas ulcerativas e granulomatosas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A etiologia das úlceras genitais é determinada pela associação de sinais e sintomas clínicos, histórico de exposição ao risco e resultados de testes diagnósticos.  
A microscopia é única opção de teste laboratorial existente no SUS para auxiliar no diagnóstico etiológico das úlceras genitais e está disponível para detecção do _Haemophilus ducreyi_ e _Treponema pallidum_ , conforme descrito a seguir.  
68

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
**Microscopia de material corado pela técnica de coloração de Gram:** visualização de bacilos Gram-negativos típicos, de tamanho pequeno, agrupados em correntes dos tipos “cardume de peixes”, “vias férreas” ou “impressões digitais” em material coletado das úlceras genitais.  
<u>Coleta do material biológico: coleta do exsudato seroso da base da lesão, livre de eritrócitos, outros organismos e restos de tecido.</u>  
<u>Resultado positivo: presença de achados morfológicos típicos de</u> _Haemophilus ducreyi_ na amostra biológica.  
<u>Resultado negativo: ausência de achados morfológicos típicos de</u> _Haemophilus ducreyi_ na amostra biológica. O resultado negativo não exclui a possibilidade de presença do patógeno, pois nem sempre é possível visualizar as morfologias típicas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A pesquisa direta do _Treponema pallidum_ por microscopia pode ser feita de três formas: imunofluorescência direta, técnica com material  
corado e campo escuro, sendo este último o mais comumente utilizado no SUS. Seguem as especificações dessa técnica.  
**Microscopia de campo escuro** : pode ser realizada tanto com amostras obtidas de lesões primárias como de lesões secundárias de sífilis, em adultos ou em crianças. Não é recomendada para materiais de cavidade oral, devido à colonização por outras espiroquetas que podem interferir no diagnóstico de sífilis. O material é levado ao microscópio com condensador de campo escuro, permitindo a visualização do _T. pallidum_ vivo e móvel, devendo ser analisado imediatamente após a coleta da amostra.  
<u>Coleta do material biológico: sempre que houver disponibilidade, deve-se fazer o exame a fresco do exsudato seroso da lesão, livre de</u> eritrócitos, outros organismos e restos de tecido.  
<u>Resultado positivo: visualização de treponemas na amostra biológica com morfologia e mobilidade características de</u> _T. pallidum._  
<u>Resultado negativo: ausência de treponemas na amostra biológica. Porém, esse resultado não exclui a sífilis. A não detecção do treponema</u> utilizando essa metodologia também pode indicar que:  
- O número de _T. pallidum_ presente na amostra não é o suficiente para sua detecção, ou  
- A lesão está próxima da cura natural, ou  
- O paciente recebeu tratamento sistêmico ou tópico.  
Para os demais patógenos, isto é, **HSV-1 e HSV-2,** **_Chlamydia trachomatis,_ sorovariantes (L1, L2, L2a, L2b e L3) e** **_Klebsiella granulomatis_** , o diagnóstico se dará pela exclusão de caso sífilis ( _Treponema pallidum_ ) e cancroide ( _Haemophilus ducreyi_ ), associado ao histórico de exposição ao risco, sinais e sintomas clínicos.  
Para mais informações sobre o diagnóstico laboratorial de úlcera genital, consultar o manual da OMS, “Diagnóstico Laboratorial de Doenças Sexualmente Transmissíveis, incluindo o Vírus da Imunodeficiência Humana”<sup>110</sup> e as aulas do Telelab, disponíveis em <u>http://telelab.aids.gov.br.</u>

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Nos casos em que a úlcera genital for claramente diagnosticada como uma IST, o paciente deve ser assistido adequadamente, segundo o fluxograma para o manejo de úlcera genital, conforme a Figura 14.  
Considerando a importância para a saúde pública, em caso de dúvida sobre a hipótese diagnóstica e na ausência de laboratório, o tratamento da úlcera genital como IST deve ser privilegiado.  
69  
**Figura 14 - Fluxograma para manejo de infecções que causam úlcera genital**  
<!-- Start of picture text -->
Fatores de rise para IST<br>Novasade ou abatomaliplas de 30 pacerassexuas anos Queixa- de dlcera genital- tia lnc: ava priicas seni fotores de rico pora IS<br>~Parcerla com IST Lesdex lcerativa erosives, precedides ou no por pstulase/ou vescuas,<br>~ Histéria prévia/presenga de outra IST acompanhadas ou no de dor, ardor, prurido, drenagem de material<br>Uso lreguler de preservatvo ‘mucopurulento,sengrementoe lnfadenopati regional<br>Investigar outras +e] IST como causa provavel?.<br>[nao] Laboratério disponivel?<br>Visualizacio de Gram- Visualizacdo de treponemas<br>Les6es4 semanas? com mais de ca Evidénciavesiculosas deativas? lesbes correntesnegativos naagrupados bacteriascopia em ‘méveis‘campona microscopiaescuro  de<br>|<br>[a]<br>Sugestivo de H. Avaliar histérico de Tdentificacao<br>ary, exposico a0 risco, sinais e de T. pallidum<br>sintomas clinicos<br>Tratar sifilis, ‘Tratar herpes<br>cancroide. Investigar genital<br>LGV e donovanose. Tratar herpes genital, ‘Tratar sifilis<br>Realizar bidpsia donovanose e/ou LGV rindi<br>‘conforme avaliagio secundéria<br>Ls] Sinais e sintomas persistem apés 14 dias?<br>= Realzarorientarocentredana pessoa esuaspétcas sexual.<br>Contrbur para que a pessoa reconhesa e minimize o prépro isco de nfego por uma IST.<br>~ OferecervacnagSo “InformarOferecertestagem sabre para  para HY hepatites  iseAe hepatite Be para Be. HPV, quando ndiado.<br>“Trete,scompankereorentara possblldade dea pesso realizaresuts preven;do paresis combinadasemua. para iST/HIV/hepatiesvias.<br>= Notficarocas0, quando indicado.<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O Quadro 38 apresenta o tratamento para as úlceras genitais de etiologia herpética; o Quadro 39 mostra o tratamento para cancroide, LGV e donovanose; e o Quadro 40 descreve o tratamento de sífilis. Reforça-se que, quando o diagnóstico etiológico não for possível, o tratamento deverá basear-se em achados clínicos com o uso de fluxogramas.  
**Quadro 38 – Tratamento de herpes genital**  
|**CONDIÇÃO CLÍNICA**|**TRATAMENTO**|**COMENTÁRIOS**|
|---|---|---|
|**Primeiro episódio**|Aciclovir 200mg, 2 comprimidos, VO, 3x/dia,<br>por 7-10 dias<br>**OU**<br>Aciclovir 200 mg, 1 comprimido, VO, 5x/dia<br>(7h, 11h, 15h, 19h, 23h, 7h...), por 7-10 dias|Iniciar o tratamento o mais precocemente possível.<br>O tratamento pode ser prolongado se a cicatrização estiver<br>incompleta após 10 dias de terapia.|  
70  
|**Recidiva**|Aciclovir 200mg, 2 comprimidos, VO, 3x/dia,<br>por 5 dias<br>**OU**<br>Aciclovir 200mg, 4 comprimidos, VO, 2x/dia,<br>por 5 dias|O tratamento deve ser iniciado preferencialmente no período<br>prodrômico (aumento de sensibilidade local, ardor, dor,<br>prurido e hiperemia da região genital).|
|---|---|---|
|**Supressão de herpes genital**<br>**(6 ou mais episódios/ano)**|Aciclovir 200mg, 2 comprimidos, VO, 2x/dia,<br>por até seis meses, podendo o tratamento ser<br>prolongado por até 2 anos|Consideram-se elegíveis para o tratamento supressivo<br>pacientes com episódios repetidos de herpes genital (mais de 6<br>ao ano).<br>Indicada avaliação periódica de função renal e hepática|
|**Herpes genital em**<br>**imunossuprimidos**|Aciclovir endovenoso, 5-10 mg/ kg de peso,<br>EV, de 8/8h, por 5 a 7 dias, ou até resolução<br>clínica|Em caso de lesões extensas em pacientes com<br>imunossupressão (usuários crônicos de corticoide, pacientes<br>em uso de imunomoduladores, transplantados de órgãos<br>sólidos e PVHIV), pode-se optar pelo tratamento endovenoso.|
|**Gestação**|Tratar o primeiro episódio em qualquer trimestre<br>Se a primoinfecção ocorreu na gestação ou se re<br>terapia supressiva, a partir da 36ª semana, com a|da gestação, conforme o tratamento para o primeiro episódio.<br>cidivas foram frequentes no período gestacional, pode-se realizar<br>ciclovir 400mg, 3x/dia.|  
- O tratamento com antivirais é eficaz para redução da intensidade e duração dos episódios, quando realizado precocemente;  
- O tratamento local pode ser feito com compressas de solução fisiológica ou degermante em solução aquosa, para higienização das lesões;  
- Analgésicos orais podem ser utilizados, se necessário;  
- É recomendado retorno em uma semana para reavaliação das lesões;  
- A forma de transmissão, a possibilidade de infecção assintomática, o medo de rejeição por parte das parcerias sexuais e as preocupações sobre a capacidade de ter filhos são aspectos que devem ser abordados;  
- É importante mencionar que não há associação entre herpes simples genital e câncer.  
- Fonte: DCCI/SVS/MS.  
**Quadro 39 – Tratamento de cancroide, LGV e donovanose**  
|**IST**|**PRIMEIRA**<br>**OPÇÃO**|**ALTERNATIVA**|**COMENTÁRIOS**|
|---|---|---|---|
|**Cancroide**|Azitromicina<br>500mg, 2<br>comprimidos,<br>VO, dose única|Ceftriaxona 250mg, IM, dose<br>única<br>**OU**<br>Ciprofloxacino<sup>a</sup>500mg, 1<br>comprimido, VO, 2x/ dia, por 3<br>dias|O tratamento sistêmico deve ser acompanhado de medidas locais<br>de higiene.<br>O tratamento das parcerias sexuais é recomendado, mesmo quando<br>assintomáticas.|
|**Linfogra-**<br>**nuloma**<br>**venéreo (LGV)**|Doxiciclina<sup>b</sup><br>100mg, VO, 1<br>comprimido,<br>2x/dia, por 21<br>dias|Azitromicina 500mg, 2<br>comprimidos, VO, 1x/semana,<br>por 21 dias**(preferencial nas**<br>**gestantes)**|As parcerias sexuais devem ser tratadas. Se a parceria for<br>sintomática, o tratamento deve ser realizado com os mesmos<br>medicamentos do caso-índice. Se a parceria for assintomática,<br>recomenda-se um dos tratamentos abaixo:<br>Azitromicina 500mg, 2 comprimidos, VO, dose única<br>**OU**<br>Doxiciclina<sup>b</sup>100mg, 1 comprimido, VO, 2x/ dia, por 7 dias.<br>O prolongamento da terapia pode ser necessário até a resolução da<br>sintomatologia. A antibioticoterapia não tem efeito expressivo na<br>duração da linfadenopatia inguinal, mas os sintomas agudos são<br>frequentemente erradicados de modo rápido. Os antibióticos não<br>revertem sequelas como estenose retal ou elefantíase genital.|
|**Donovanose**|Azitromicina<br>500mg, 2<br>comprimidos,<br>VO, 1x/ semana,<br>por pelo menos<br>três semanas, ou<br>até a cicatrização<br>das lesões|Doxiciclina<sup>b</sup>100mg, 1<br>comprimido, VO, 2x/dia, por pelo<br>menos 21 dias, ou até o<br>desaparecimento completo das<br>lesões<br>**OU**<br>Ciprofloxacino<sup>a</sup>500mg, 1 e ½<br>comprimido, VO, 2x/ dia, por<br>pelo menos 21 dias, ou até a<br>cicatrização das lesões (dose<br>total: 750mg)<br>**OU**<br>Sulfametoxazol-trimetoprima<br>(400/80mg), 2 comprimidos, VO,<br>2x/dia, por no mínimo 3 semanas,<br>ou até a cicatrização das lesões|Não havendo resposta na aparência da lesão nos primeiros dias de<br>tratamento com ciprofloxacino, recomenda-se adicionar um<br>aminoglicosídeo, como a gentamicina, 1mg/kg/dia, EV, 3x/dia, por<br>pelo menos três semanas, ou até cicatrização das lesões.<br>Em PVHIV, sugerem-se os mesmos esquemas terapêuticos; o uso<br>de terapia parenteral com a gentamicina deve ser considerado nos<br>casos mais graves.<br>O critério de cura é o desaparecimento da lesão, não tendo sido<br>relatada infecção congênita. As sequelas da destruição tecidual ou<br>obstrução linfática podem exigir correção cirúrgica.<br>Devido à baixa infectividade, não é necessário tratar as parcerias<br>sexuais.|  
71  
- PVHIV com cancroide e LGV devem ser monitoradas cuidadosamente, visto que podem necessitar de maior tempo de tratamento, além do que a cura pode ser retardada e a falha terapêutica pode ocorrer com qualquer dos esquemas recomendados.  
Fonte: DCCI/SVS/MS.  
a O ciprofloxacino está contraindicado para gestantes, lactantes e crianças. b A doxiciclina está contraindicada para gestantes e lactantes. **Quadro 40 – Tratamento de sífilis adquirida**  
|**ESTADIAMENTO**|**ESQUEMA TERAPÊUTICO**|**ALTERNATIVA (exceto**<br>**para gestantes)**|**SEGUIMENTO (teste não**<br>**treponêmico)**|
|---|---|---|---|
|**Sífilis recente**: sífilis primária,<br>secundária e latente recente<br>(com até um ano de evolução)|Benzilpenicilina benzatina 2,4<br>milhões UI, IM, dose única (1,2<br>milhão UI em cada glúteo)|Doxiciclina 100mg, 12/12h,<br>VO, por 15 dias|Trimestral|
|**Sífilis tardia:**sífilis latente<br>tardia (com mais de um ano de<br>evolução) ou latente com<br>duração ignorada e sífilis<br>terciária|Benzilpenicilina benzatina 2,4<br>milhões UI, IM, semanal (1,2 milhão<br>UI em cada glúteo), por 3 semanas<br>Dose total: 7,2 milhões UI, IM|Doxiciclina 100mg, 12/12h,<br>VO, por 30 dias|Trimestral|
|**Neurossífilis**|Benzilpenicilina potássica/ cristalina<br>18-24 milhões UI/ dia, por via<br>endovenosa, administrada em doses<br>de 3-4 milhões UI, a cada 4h ou por<br>infusão contínua, por 14 dias|Ceftriaxona 2g IV ao dia, por<br>10- 14 dias|Exame de LCR de 6/6 meses<br>até normalização|  
Fonte: DCCI/SVS/MS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A DIP é uma síndrome clínica atribuída à ascensão de microrganismos do trato genital inferior, espontânea ou devida à manipulação (inserção de DIU, biópsia de endométrio, curetagem, entre outros), comprometendo o endométrio (endometrite), tubas uterinas, anexos uterinos e/ou estruturas contíguas (salpingite, miometrite, ooforite, parametrite, pelviperitonite).  
Constitui uma das mais importantes complicações das IST e um sério problema de saúde pública, sendo comum em mulheres jovens com atividade sexual desprotegida. Está associada a sequelas importantes em longo prazo, causando morbidades reprodutivas que incluem infertilidade por fator tubário, gravidez ectópica e dor pélvica crônica. As taxas variam na literatura entre 9% e 20% e aumentam com o número de episódios. Estima-se um caso de DIP para cada oito a dez casos de pacientes com cervicite por algum dos patógenos elencados a seguir<sup>226</sup> .  
A maioria dos casos de DIP (85%) é causada por agentes patogênicos sexualmente transmitidos ou associados à vaginose bacteriana. Classicamente reconhecidas como as principais etiologias de DIP, a _Chlamydia trachomatis_ e a _Neisseria gonorrhoeae_ têm mostrado incidência decrescente, sendo encontradas, em alguns estudos, em 1/3 dos casos<sup>227–229</sup> .  
Menos de 15% dos casos agudos de DIP não são transmitidos sexualmente, mas associados a germes entéricos (ex.: _Peptococcus_ , _Peptoestreptococcus_ , _Bacteroides Escherichia coli_ , _Streptococcus agalactiae_ e _Campylobacter spp._ ), patógenos respiratórios (ex.: _Haemophilus influenzae_ , _Streptococcus pneumoniae_ , streptococos do Grupo A e _Staphylococcus aureus_ ) ou _Mycoplasma_ e _Ureaplasma_ que colonizam o trato genital inferior<sup>230–234</sup> .  
Os aeróbios facultativos da microbiota são considerados agentes causadores potenciais<sup>230</sup> . No Quadro 41, estão listados agentes etiológicos de DIP.  
**Quadro 41 – Agentes etiológicos de DIP: causas microbiológicas**

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- _Chlamydia trachomatis_  
- _Mycoplasma genitalium_  
- _Neisseria gonorrhoeae_  
- Vírus e protozoários (raro)  
- _Herpes simplex virus_  
- _Trichomonas vaginalis_  
72

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- _Mycoplasma genitalium*_  
- _Mycoplasma hominis_  
- _Ureaplasma urealyticum_  
- **BACTÉRIAS ANAERÓBICAS**  
- _Bacteroides spp._ e _fragilis_  
- _Peptoestreptococcus spp._  
- _Prevotella spp._  
- **BACTÉRIAS FACULTATIVAS (AERÓBICAS)**  
- _Escherichia coli_  
- _Gardnerella vaginalis_  
- _Haemophilus influenzae_  
- _Streptococcus spp._ e _agalactieae_  
Fonte: DCCI/SVS/MS.  
*Segundo Haggerty; Taylor (2011)<sup>231</sup> ; Weinstein; Stiles (2011)<sup>232</sup> ; McGowin; Anderson-Smits (2011)<sup>233</sup> ; Workowski; Berman (2010)<sup>234</sup> .  
A ascensão dos microrganismos é favorecida por variações hormonais do ciclo menstrual. O muco cervical durante o fluxo menstrual apresenta menor efeito bacteriostático e a menstruação retrógrada pode favorecer a ascensão dos agentes. Características imunológicas de cada indivíduo também podem contribuir para a disseminação da infecção.  
A progressão da infecção por agentes aeróbios determina maior consumo de oxigênio e diminuição do potencial de oxirredução local que, aliados à desvitalização de tecidos, proporcionam ambiente de microaerofilia ou mesmo de anaerobiose (teoria de Monif). Nesse ambiente, os microrganismos normais passam a uma fase de crescimento lento e desenvolvem agentes anaeróbios oportunistas. Como resultado, obtémse uma condição infecciosa polimicrobiana.  
Mais recentemente, partindo da observação de que dois terços das mulheres com IST não tinham história anterior ou tratamento de DIP<sup>235</sup> , foi proposto o conceito de DIP subclínica. Essa entidade é tão comumente encontrada quanto a DIP clínica e apresenta as mesmas etiologias.  
A endometrite é frequentemente a primeira manifestação clínica da DIP. O processo infeccioso progride em direção às tubas, à cavidade peritoneal pélvica e, quando atinge o líquido peritoneal, o agente infeccioso pode progredir até o espaço infradiafragmático direito e promover a peri-hepatite ou síndrome de Fitz-Hugh-Curtis.  
Os fatores de risco para DIP incluem:  
- Condições socioeconômicas desfavoráveis (baixa escolaridade, desemprego e baixa renda familiar);  
- Atividade sexual na adolescência. Devido a fatores biológicos e comportamentais próprios dessa fase, as adolescentes com atividade sexual apresentam risco três vezes maior de desenvolver DIP aguda que mulheres acima de 25 anos;  
- Comportamento sexual de pessoas com maior vulnerabilidade para IST (parcerias múltiplas, início precoce das atividades sexuais, novas parcerias etc.);  
- Uso de método anticoncepcional. A utilização de pílulas combinadas (pela possibilidade de causar ectopia) facilita a infecção por _N. gonorrhoeae e C. trachomatis_ , mas não existem trabalhos conclusivos sobre se há aumento de DIP com esse uso. As usuárias de dispositivo intrauterino (DIU) apresentam risco ligeiramente aumentado de DIP em comparação com mulheres que não usam contraceptivos ou que utilizam outros métodos. Esse risco parece guardar relação inversa com o tempo desde a inserção do DIU, sendo mais alto nos primeiros 20 dias da inserção. A exposição a IST é responsável pela ocorrência de DIP no primeiro mês de uso, e não o uso do DIU. No entanto, esse risco é reduzido nas mulheres tratadas para IST antes da inserção do DIU.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
_<u>Quando uma mulher sexualmente ativa se apresenta com dor abdominal baixa e/ou dor pélvica, deverá investigar DIP no diagnóstico</u>_  
73  
_diferencial, independentemente da história de atividade sexual recente._  
O diagnóstico clínico de DIP sintomática resulta em 65% a 90% de VPP para salpingite em comparação com a laparoscopia<sup>234</sup> , sendo este último considerado o exame “padrão ouro”<sup>236</sup> .  
Nas formas sintomáticas de DIP, o diagnóstico diferencial deverá ser feito mediante manifestações uroginecológicas, gastrointestinais e esqueléticas. Portanto, o profissional de saúde deve manter um elevado nível de suspeição, com o intuito de implantar terapêutica precoce e evitar sequelas.  
O exame clínico deve incluir:  
- Aferição de sinais vitais;  
- Exame abdominal;  
- Exame especular vaginal, incluindo inspeção do colo de útero para friabilidade (sangramento fácil) e corrimento mucopurulento cervical;  
- Exame bimanual, com mobilização do colo e palpação dos anexos.  
Os sinais/sintomas de sangramento vaginal anormal em pouca quantidade ( _spotting_ ), dispareunia, corrimento vaginal, dor pélvica ou dor no abdome inferior, além de dor à mobilização do colo do útero ao toque, podem estar presentes na DIP. A ocorrência de _spotting_ em usuárias de anticoncepcional de baixa dosagem é comum e pode ser indicativa de DIP, devendo ser investigada.  
O diagnóstico clínico de DIP é feito a partir de critérios maiores, critérios menores e critérios elaborados, apresentados no Quadro 42. Para o diagnóstico de DIP, é necessária a presença de:  
- Três critérios maiores MAIS um critério menor; OU  
- Um critério elaborado.  
Os critérios elaborados podem aumentar a especificidade do diagnóstico clínico de DIP.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- Dor no hipogástrico  
- Dor à palpação dos anexos  Dor à mobilização do colo uterino

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- Temperatura axilar >37,5°C ou temperatura retal >38,3°C  
- Conteúdo vaginal ou secreção endocervical anormal  Massa pélvica  Mais de 10 leucócitos por campo de imersão em material de endocérvice  
- Leucocitose em sangue periférico  
- Proteína C reativa ou velocidade de hemossedimentação (VHS) elevada  
- Comprovação laboratorial de infecção cervical por gonococo, clamídia ou micoplasmas

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
- Evidência histopatológica de endometrite  
- Presença de abscesso tubo-ovariano ou de fundo de saco de Douglas em estudo de imagem  
- Laparoscopia com evidência de DIP  
Fonte: DCCI/SVS/MS.  
Já os diagnósticos diferenciais de DIP incluem: gravidez ectópica, apendicite aguda, infecção do trato urinário, litíase ureteral, torção de tumor cístico de ovário, torção de mioma uterino, rotura de cisto ovariano, endometriose (endometrioma roto), diverticulite, entre outros.  
Os exames laboratoriais e de imagem são utilizados para diagnóstico etiológico e avaliação da gravidade e estão elencados abaixo:  
- Hemograma completo;  
- VHS;  
- Proteína C reativa;  
74  
- Exame bacterioscópico para vaginose bacteriana;  
- Cultura de material de endocérvice com antibiograma;  
- Detecção de clamídia e gonococo por biologia molecular;  
- Pesquisa de _N. gonorrhoeae_ e _C. trachomatis_ no material de endocérvice, da uretra, de laparoscopia ou de punção do fundo de saco posterior;  
- Exame qualitativo de urina e urocultura (para afastar hipótese de infecção do trato urinário);  
- Hemocultura;  
- Teste de gravidez (para afastar gravidez ectópica);  
- Exames de imagem: a ultrassonografia transvaginal e pélvica é um método acessível e não invasivo no diagnóstico de complicações relacionadas à DIP, como abscesso tubo-ovariano, cistos ovarianos e torção de ovário. O principal achado ultrassonográfico na DIP é a presença de uma fina camada líquida preenchendo a trompa, com ou sem a presença de líquido livre na pelve.  
Para mais informações sobre o diagnóstico laboratorial de DIP, consultar o manual da OMS, “Diagnóstico Laboratorial de Doenças Sexualmente Transmissíveis, incluindo o Vírus da Imunodeficiência Humana”<sup>110</sup> e as aulas do Telelab, disponíveis em <u>http://telelab.aids.gov.br.</u>

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A Figura 15 apresenta o manejo de DIP com suporte mínimo de laboratório, chamando atenção para as situações de maior gravidade, que devem ser referenciadas para avaliação em caráter emergencial (maternidades ou serviços de urgência e emergência).  
**Figura 15 – Fluxograma para o manejo clínico de DIP**  
<!-- Start of picture text -->
—<br>| Queixa de dor abdominal baixa aguda ou dor pélvica aguda | “Novas ou miikiplas parcerias sexuais<br>Historia clinica: avaliar préticas sexuais e fatores: - oles<br>endométrio ou curetagem, entre outros. aD<br>—<br>—<br>Temperature<br>ler 237° ou temperature<br>be] ~Potena Creative ou veloidde de<br>Diagnéstico clinico de DIP? (Trés critérios maiores MAIS um ‘por gonacoco, clamidia ou micoplasmas<br>-critério menor OU umcritério elaborado) Critérios elaborados<br>fundo=de saco de Douglas em estudo de<br>Indicagao de interna¢3o hospitalar?<br>mente tedona aa<br>= Informar sobre a possibilidade de realizar preven3o.<br>Le poms<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
75

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O tratamento ambulatorial aplica-se a mulheres que apresentam quadro clínico leve e exame abdominal e ginecológico sem sinais de pelviperitonite.  
Os critérios para tratamento hospitalar de DIP estão resumidos no Quadro 43.  
**Quadro 43 – Critérios para indicação de tratamento hospitalar de DIP**  
- Abscesso tubo-ovariano  
- Gravidez  
- Ausência de resposta clínica após 72h do início do tratamento com antibioticoterapia oral  
- Intolerância a antibióticos orais ou dificuldade para seguimento ambulatorial  
- Estado geral grave, com náuseas, vômitos e febre  
- Dificuldade na exclusão de emergência cirúrgica (ex.: apendicite, gravidez ectópica)  
Fonte: adaptado de Wiesenfeld (2018)<sup>235</sup> .  
O tratamento imediato evita complicações tardias (infertilidade, gravidez ectópica e dor pélvica crônica)<sup>237</sup> . Analgésicos e anti-inflamatórios são úteis e, se a mulher estiver desidratada, o uso de fluidos intravenosos está indicado.  
_Recomenda-se que, por menor que seja a suspeita, o tratamento seja iniciado o quanto antes._  
Os esquemas terapêuticos deverão ser eficazes contra _Neisseria gonorrhoeae_ ; _Chlamydia trachomatis_ ; anaeróbios (que podem causar lesão  
tubária), em especial o _Bacteroides fragilis_ ; vaginose bacteriana; bactérias Gram-negativas; bactérias facultativas e estreptococos, mesmo que esses agentes não tenham sido confirmados nos exames laboratoriais.  
Devido à diversidade de agentes etiológicos implicados na DIP, a melhor conduta é a associação de antibióticos. A monoterapia não é recomendada.  
A doxiciclina, por ser mais estudada para DIP que a azitromicina, é a medicação de primeira escolha para _C. trachomatis_ . Outros esquemas  
apresentam atividade _in vitro_ , como a combinação clindamicina/gentamicina e as cefalosporinas de segunda geração. A combinação ampicilina/sulbactam também pode ser utilizada, mas não há trabalhos suficientes para confirmação de eficácia.  
_Devido à resistência emergente e em expansão da N. gonorrhoeae ao ciprofloxacino, não se recomenda tratamento empírico para DIP com quinolonas._  
Os esquemas terapêuticos devem apresentar cobertura antimicrobiana para os agentes etiológicos de DIP, conforme o Quadro 44.  
**Quadro 44 – Tratamento de DIP**  
|**TRATAMENTO**|**PRIMEIRA OPÇÃO**|**SEGUNDA OPÇÃO**|**TERCEIRA OPÇÃO**|
|---|---|---|---|
|**Ambulatorial**|Ceftriaxona 500mg, IM, dose única<br>**MAIS**<br>Doxiciclina<sup>a</sup>100mg, 1 comprimido,<br>VO, 2x/dia, por 14 dias<br>**MAIS**<br>Metronidazol 250mg, 2 comprimidos,<br>VO, 2x/dia, por 14 dias|Cefotaxima 500mg, IM, dose única<br>**MAIS**<br>Doxiciclina<sup>a</sup>100mg, 1 comprimido,<br>VO, 2x/dia, por 14 dias<br>**MAIS**<br>Metronidazol 250mg, 2<br>comprimidos, VO, 2x/dia, por 14<br>dias|–|
|**Hospitalar**|Ceftriaxona 1g, IV, 1x/dia, por 14 dias<br>**MAIS**<br>Doxiciclina<sup>a</sup>100mg, 1 comprimido,|Clindamicina 900mg, IV, 3x/dia,<br>por 14 dias<br>**MAIS**<br>Gentamicina(IV ou IM): 3-5|Ampicilina/sulbactam 3g, IV,<br>6/6h, por 14 dias<br>**MAIS**<br>Doxiciclina<sup>a</sup>100mg,1|  
76  
|VO, 2x/dia, por 14 dias|mg/kg, 1x/dia, por 14 dias|comprimido, VO, 2x/dia, por 14<br>|
|---|---|---|
|**MAIS**||dias|
|Metronidazol 400mg, IV, de 12/12h|||  
- O uso parenteral deverá ser suspenso 24 horas após a cessação dos sintomas e a continuação terapêutica antimicrobiana por via oral deve se estender até 14 dias.  
- Orientar quanto ao não uso de bebidas alcoólicas durante e após 24h do uso de metronidazol para evitar efeito dissulfiran (antabuse) símile.  
Fonte: adaptado de Wiesenfeld (2018)<sup>235</sup> ; Duarte et al. (2015)<sup>238</sup> . a A doxiciclina é contraindicada durante a gravidez.  
**10.4. DIP: seguimento**  
A melhora clínica das pacientes com DIP deverá acontecer nos três primeiros dias após o início do tratamento antimicrobiano. A cura é baseada no desaparecimento dos sinais e sintomas. Se a avaliação for feita com critérios bacteriológicos após trinta dias, 40% das mulheres ainda persistem com a presença de um ou mais agentes bacterianos, de acordo com o estudo PEACH ( _Pelvic Inflammatory Disease Evaluation Clinical Health Trial_ )<sup>227,239</sup> . A paciente deverá retornar ao ambulatório para seguimento na primeira semana após a alta hospitalar, observando abstinência sexual até a cura clínica.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Se houver piora do quadro, considerar laparoscopia ou outros exames de imagem, como ressonância nuclear magnética ou tomografia computadorizada axial, para diagnósticos diferenciais ou complicações de DIP. A laparotomia está indicada nos casos de massas anexiais não responsivas ao tratamento ou que se rompem. Também está indicada a culdotomia, caso o abscesso ocupe o fundo de saco de Douglas.  
Em casos particulares, abscessos tubo-ovarianos podem ser esvaziados com punção transabdominal guiada por ultrassonografia.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As parcerias sexuais dos dois meses anteriores ao diagnóstico, sintomáticas ou não, devem ser tratadas empiricamente para _Neisseria gonohrroeae_ e _Chlamydia trachomatis_ . Recomenda-se ceftriaxona 500mg IM associada a azitromicina 1g VO, ambas em dose única.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Mulheres grávidas com suspeita de DIP têm alto risco de abortamento e corioamnionite. Todas as gestantes com suspeita ou com DIP confirmada devem ser internadas e iniciar imediatamente antibióticos intravenosos de amplo espectro.  
O uso de doxiciclina e quinolonas é contraindicado na gestação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Pacientes adolescentes, embora possuam maior risco de DIP e complicações, não necessitam obrigatoriamente ser internadas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Se a paciente for usuária de DIU, não há necessidade de remoção do dispositivo<sup>233</sup> ; porém, caso exista indicação, a remoção não deve ser anterior à instituição da antibioticoterapia, devendo ser realizada somente após duas doses do esquema terapêutico<sup>240</sup> . Nesses casos, orientar a paciente sobre uso de métodos de barreira (preservativo masculino e feminino, diafragma etc.). Não recomendar duchas vaginais.  
77

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Têm comportamento similar às pacientes com imunidade normal, apenas com a ressalva de que desenvolvem mais facilmente abscesso tuboovariano, merecendo, portanto, maior cuidado, sem necessidade de internação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O HPV (sigla em inglês para papilomavírus humano) é um DNA-vírus de cadeia dupla, não encapsulado, membro da família _Papovaviridae_ . Infecta epitélios escamosos e pode induzir uma grande variedade de lesões cutaneomucosas. Atualmente, são identificados mais de 200 tipos  
de HPV, sendo que, desses, aproximadamente 40 tipos acometem o trato anogenital.  
A transmissão do HPV dá-se por qualquer tipo de atividade sexual e, excepcionalmente, durante o parto, com a formação de lesões cutaneomucosas em recém-nascidos ou papilomatose recorrente de laringe. A transmissão por fômites é rara.  
O risco geral estimado para a exposição a essa infecção é de 15% a 25% a cada nova parceria sexual e a quase totalidade das pessoas sexualmente ativas adquirirá a infecção em algum momento de suas vidas. As infecções são tipicamente assintomáticas. Aproximadamente 1% a 2% da população apresentam verrugas anogenitais e 2% a 5% das mulheres mostram alterações no exame preventivo de colo do útero provocadas por infecção pelo HPV. A prevalência é maior em mulheres abaixo dos 30 anos. A maioria das infecções por HPV em mulheres (sobretudo quando adolescentes) tem resolução espontânea, em um período aproximado de até 24 meses.  
Os tipos de HPV que infectam o trato genital são divididos em dois grupos, de acordo com o potencial oncogênico e com as lesões às quais costumam estar associados:  
- Baixo risco oncogênico: tipos 6, 11, 40, 42, 43, 44, 54, 61, 70, 72 e 81.  
- Alto risco oncogênico: tipos 16, 18, 31, 33, 35, 39, 45, 51, 52, 56, 58, 59, 68, 73 e 82.  
Os tipos 26, 53 e 66 provavelmente são de alto risco oncogênico, enquanto os tipos 34, 57 e 83, de risco indeterminado.  
A infecção por um determinado tipo viral não impede a infecção por outros tipos de HPV, podendo ocorrer infecção múltipla. Os tipos que causam verrugas genitais são quase sempre diferentes daqueles que causam câncer. O tempo médio entre a infecção pelo HPV de alto risco e o desenvolvimento do câncer cervical é de aproximadamente 20 anos, de acordo com o tipo do vírus, sua carga viral, sua capacidade de persistência e o estado imunológico do hospedeiro. Tabagismo e deficiências imunológicas, incluindo as causadas pela infecção pelo HIV, desnutrição, cânceres e drogas imunossupressoras são fatores predisponentes.  
Na maioria das pessoas, a infecção pelo HPV não produz qualquer manifestação. O tempo de latência pode variar de meses a anos e, quando presentes, as manifestações podem ser subclínicas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As alterações são detectadas pelo exame preventivo de câncer de colo do útero, por meio de lupas, corantes e colposcopia, acompanhada ou não de biópsia. Os tipos virais de baixo risco oncogênico são geralmente associados a padrão de lesões escamosas de baixo grau ( _low grade intraepithelial lesions_ – LSIL), equivalendo ao quadro histopatológico de displasia leve ou neoplasia intraepitelial cervical grau 1 (NIC1).  
Os tipos de alto potencial oncogênico são em geral associados a lesões intraepiteliais escamosas de alto grau ( _high grade intraepithelial lesions_ – HSIL), correspondendo à histopatologia aos quadros de displasia moderada, grave ou carcinoma _in situ_ – também denominadas neoplasias intraepiteliais cervicais grau 2 (NIC 2) ou grau 3 (NIC 3). Esta última é considerada carcinoma _in situ_ . Como mencionado, outros epitélios podem sofrer a ação oncogênica do vírus, originando neoplasias intraepiteliais vaginais (NIVA), vulvares (NIV), perineais (NIPE), penianas (NIP) e anais (NIA).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As lesões da infecção pelo HPV são polimórficas, sendo as lesões pontiagudas denominadas condiloma acuminado. Variam de um a vários milímetros, podendo atingir vários centímetros. Costumam ser únicas ou múltiplas, achatadas ou papulosas, mas sempre papilomatosas. Por  
78  
essa razão, a superfície apresenta-se fosca, aveludada ou semelhante à da couve-flor. Apresentam-se da cor da pele, eritematosas ou hiperpigmentadas. Em geral são assintomáticas, mas podem ser pruriginosas, dolorosas, friáveis ou sangrantes. As verrugas anogenitais resultam quase exclusivamente de tipos não oncogênicos de HPV.  
No homem, as lesões ocorrem mais frequentemente no folheto interno do prepúcio, no sulco bálano-prepucial ou na glande. Podem acometer, ainda, a pele do pênis e/ou do escroto. Na mulher, costumam ser observadas na vulva, vagina e/ou cérvice. Em ambos, podem ser encontradas nas regiões inguinais ou perianais. As manifestações perianais são mais frequentes, ainda que não exclusivas, em pessoas que tenham atividade sexual anal receptiva. Menos frequentemente, podem estar presentes em áreas extragenitais, como conjuntivas e mucosas nasal, oral e laríngea.  
As PVHIV apresentam maior frequência de neoplasias anogenitais e lesões intraepiteliais decorrentes da infecção pelo HPV.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O diagnóstico das verrugas anogenitais é tipicamente clínico. Em situações especiais, há indicação de biópsia para estudo histopatológico:  
- Dúvida diagnóstica, suspeita de neoplasias ou outras doenças;  
- Lesões atípicas ou que não respondam adequadamente aos tratamentos;  
- Lesões suspeitas em pessoas com imunodeficiências – incluindo a infecção pelo HIV, cânceres e/ou uso de drogas imunossupressoras –, caso em que esse procedimento deve ser considerado com mais frequência e precocidade.  
As mulheres com verrugas anogenitais requerem um exame ginecológico completo, incluindo o exame preventivo de câncer de colo do útero  
e, quando indicada pelas alterações citológicas, colposcopia, acompanhada ou não de biópsia. Pacientes com lesões anais, idealmente, devem ter um exame proctológico com anuscopia e toque retal.  
O estudo citológico de material colhido do canal anal ainda tem sua realização debatida, mas pode ter importância em populações especiais  
(HSH e pessoas com prática sexual anal receptiva) em razão de aumento da incidência de câncer anorretal<sup>241</sup> .  
Não são recomendados testes que identificam os diferentes tipos de HPV na rotina clínica ou mesmo no rastreamento de pessoas assintomáticas com a finalidade de diagnóstico de infecção pelo HPV. Estes testes têm importância para o rastreio de câncer genital, como por exemplo, câncer de colo uterino e de pênis.  
Para mais informações sobre o diagnóstico laboratorial da infecção pelo HPV, consultar o manual da OMS, “Diagnóstico Laboratorial de Doenças Sexualmente Transmissíveis, incluindo o Vírus da Imunodeficiência Humana”<sup>110</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A vacinação é uma opção segura e eficaz na prevenção da infecção pelo HPV e suas complicações. Existe robusta evidência do benefício individual e populacional, com demonstração de redução da ocorrência de lesões benignas e malignas<sup>242–245</sup> .  
A vacina é potencialmente mais eficaz para adolescentes vacinadas(os) antes do primeiro contato sexual, induzindo a produção de anticorpos em quantidade dez vezes maior que a encontrada na infecção naturalmente adquirida em um prazo de dois anos.  
_A vacinação contra o HPV, além de segura e eficaz, não leva a mudanças no comportamento sexual entre adolescentes. É dever dos profissionais de saúde a adequada indicação da vacinação e a ampliação da cobertura vacinal no território_<sup>246–254</sup> _._  
A partir de 2014, o MS ampliou o Calendário Nacional de Vacinação, com a introdução da vacina quadrivalente contra HPV tipos 6 e 11 (de baixo risco oncogênico, responsáveis por lesões verrucosas) e 16 e 18 (de alto risco oncogênico). O Quadro 45 apresenta a indicação da vacinação do HPV.  
**Quadro 45 – Indicação de vacinação para HPV**  
79  
|**CRIANÇAS E ADOLESCENTES**|**PVHIV, TRANSPLANTADOS DE ÓRGÃOS SÓLIDOS, DE**<br>**MEDULA ÓSSEA OU PACIENTES ONCOLÓGICOS**|
|---|---|
|2 doses (0 e 6 meses)|3 doses (0, 2 e 6 meses)|
|Meninas de 9 a 14 anos|Mulheres de 9 a 26 anos|
|Meninos de 11 a 14 anos|Homens de 9 a 26 anos|
|Fonte: Brasil (2018)<sup>20</sup>.||  
A vacinação das PVHIV passa a ser realizada em todos os postos de vacinação, nos CRIE e nos SAE que possuam salas de vacina. Mantémse a necessidade de prescrição médica com indicação do motivo da vacinação nos casos de PVHIV, transplantados de órgãos sólidos, de medula óssea ou pacientes oncológicos.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O objetivo do tratamento das verrugas anogenitais é a destruição das lesões identificáveis. Apesar de haver recomendação de tratamento, não há evidência de que os tratamentos disponíveis modifiquem a história natural da infecção pelo HPV. Independentemente da instituição de tratamentos, as lesões podem desaparecer, permanecer inalteradas ou aumentar em número e/ou volume. Recidivas são frequentes em tempo bastante variável, podendo ocorrer após meses ou anos.  
O tratamento deve ser individualizado, considerando as características das lesões, a disponibilidade de recursos, os efeitos adversos e a experiência do profissional. Em se tratando de uma doença em geral autolimitada, devem ser evitados tratamentos que gerem cicatrizes desfigurantes.  
As situações de imunodeficiência não modificam as recomendações terapêuticas, sendo necessário lembrar, porém, que os pacientes nessas condições tendem a apresentar pior resposta ao tratamento, requerendo maior atenção quanto à possibilidade de complicações.  
_Recomenda-se considerar a mudança de opção terapêutica quando não houver melhora significativa após três sessões, ou se as verrugas não desaparecerem após seis sessões de tratamento. Existe a possibilidade de combinação de tratamentos, com estrito controle dos efeitos inflamatórios sobre os tecidos normais._  
Deve-se considerar o impacto psicossocial das manifestações da infecção pelo HPV. As pessoas com HPV preocupam-se muito quanto à  
evolução das lesões – que são, em muitos casos, de longa duração, com muitas recidivas –, ao potencial de transmissão a outros parceiros, à origem da infecção em uma parceria e, em especial, à possibilidade de transformação maligna. O conhecimento desses aspectos, a completude, a clareza e a firmeza das informações oferecidas pelos profissionais de saúde são indispensáveis.  
A Figura 16 resume as recomendações para o tratamento das verrugas anogenitais, conforme sua morfologia e distribuição.  
**Figura 16 – Fluxograma para o manejo clínico de verrugas anogenitais**  
80  
<!-- Start of picture text -->
\Verruga anogenital sugestiva de HPV Historia clinica: avaliar praticas sexuais e<br>fatores de risco para IST.<br>- Lesdes: polimérficas, pontiagudas, dnicas<br>semelhantes a couve-flor.<br>a Casos especiais? Gestantes, criancas, imunossuprimidos,<br>| verrugas de grande volume, doenga disseminada ~ Idade abaixoFatoresdede30 riscoanos para IST<br>- Histéria prévia/presenca de outra IST<br>re ents, 7 - Uso irregular de preservativo<br>ambulatorial domiciliar<br>{eutoaplicado)<br>Acido tricloroacético (ATA) 80%-90%, OU<br>podofilina 10%-25%, OU Imiquimode «<br>eletrocauterizacao,i OU crioterapia OU exérese cirtrgica,—— OU podofilotoxina € suas~Contribuir- Realizar praticas orienta¢opara sexuais.que centradaa pessoa reconheca na pessoa<br>minimize 0 proprio risco de infec¢ao<br>‘por uma IST.<br>Aparecimento7  de novas lesbes. eae<br>[rao] ou les6es ndo melhoram? - OferecerOferecer vacinac3o paratestagem para hepatitesHIV, sifilis Ae Be<br>para HPV, quando indicado.<br>- Informar sobre a possibilidade de<br>Considerar mudanga de realizar prevencdo combinada para<br>terapiaSe imientoe manter -IST/HIV/hepatites Tratar, acompanharvirais.e orientar a pessoa<br>e suas parcerias sexuais.<br>- Notificar 0 caso, quando indicado.<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
Frente à grande incidência de verrugas anogenitais e ao elevado número de consultas implicadas, os tratamentos realizados em ambulatórios tendem a sobrecarregar os serviços. Em geral, esses tratamentos são dolorosos, sendo importantes a abordagem preventiva, o suporte e a segurança do profissional durante o procedimento. Todos exigem cuidado em sua realização, pois podem produzir bolhas, úlceras e cicatrizes. Também é necessário alertar os pacientes quanto à possibilidade de infecção secundária e seus sinais de alerta. Normas padrão de biossegurança devem ser utilizadas durante o tratamento, incluindo máscaras quando dos procedimentos que gerem aerossóis e/ou fumaça, transportando partículas virais que podem ser inaladas.  
Dividem-se os tratamentos em domiciliares (realizados pelo próprio paciente) e ambulatoriais (realizados pelos profissionais de saúde).

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É bastante conveniente por ser autoaplicado, reduzindo as visitas ao serviço de saúde. São imprescindíveis instruções detalhadas sobre a forma de aplicação e as potenciais complicações. Como autotratamentos já incorporados ao SUS, têm-se o imiquimode e a podofilotoxina. O imiquimode apresenta menos efeitos locais que a podofilotoxina, mas implica maior tempo de tratamento (quatro meses vs. quatro semanas). Não há diferença entre as taxas de abandono<sup>255–258</sup> .  
**a) Imiquimode 50mg/g creme:** é um modulador da resposta imunológica pela indução do interferon alfa e de outras citocinas.  
Homens não circuncidados que estiverem tratando verrugas localizadas sob o prepúcio devem retraí-lo e limpar a região diariamente. O imiquimode não destrói o vírus, mas auxilia na eliminação da verruga. Portanto, novas verrugas podem aparecer durante o tratamento. A exposição da pele à luz solar (inclusive ao bronzeamento artificial) durante o tratamento deve ser evitada, em razão do aumento da sensibilidade cutânea a queimaduras. A inflamação provocada pelo imiquimode é o seu mecanismo de ação terapêutico; portanto, será observada uma irritação e eritema no local do tratamento. É destinado apenas para uso externo, não dever ser usado na uretra, vagina, colo do útero ou na parte interna do ânus.  
81

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
1. Antes de se deitar, lavar as mãos e a área a ser tratada com água e sabonete neutro. Secar bem a área limpa. Abrir um sachê novo de imiquimode e espremê-lo, a fim de liberar o creme na ponta do dedo indicador;  
2. Aplicar uma camada fina de imiquimode sobre a região afetada e massagear suavemente até o creme desaparecer;  
3. Após a aplicação, jogar fora o sachê e lavar as mãos com água e sabão;  
4. Deixar o creme agir por seis a dez horas sobre as verrugas genitais externas;  
5. Durante esse período, evitar qualquer banho ou ducha;  
6. Após esse período, lavar a região tratada com água e sabonete suave. Abrir sempre um novo sachê a cada aplicação do produto;  
7. Após o uso, sempre jogar fora o sachê;  
8. Nunca guardar a sobra do sachê para usá-la posteriormente. Doses maiores que as recomendadas podem levar a um aumento de reações adversas no local de aplicação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Para as verrugas externas genitais/anais, as aplicações devem ser realizadas em dias alternados (três vezes por semana), por exemplo, às segundas, quartas e sextas, ou às terças, quintas e sábados. O tratamento com imiquimode deve ser mantido até o desaparecimento das verrugas ou por um período máximo de 16 semanas a cada episódio de verrugas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As reações adversas mais comuns ocorrem na área de aplicação do produto e incluem vermelhidão, descamação, erosão da pele, escoriação e inchaço.  
**b) Podofilotoxina** : é a forma purificada da podofilina e possui propriedades antimitóticas. A absorção sistêmica após a aplicação tópica é muito baixa.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
9. Antes de aplicar o creme, lavar as áreas afetadas com água e sabão e secar completamente;  
10. Utilizando a ponta dos dedos, aplicar quantidade de creme suficiente para cobrir cada verruga, permanecendo com as pernas afastadas uma em relação a outra até que o creme seja totalmente absorvido;  
11. Se o creme entrar em contato com a pele sadia, ele deve ser retirado com água e sabão;  
12. O contato prolongado com a pele sadia deve ser evitado.  
13. As mãos devem ser completamente lavadas após cada aplicação.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A aplicação de podofilotoxina deve ser feita duas vezes ao dia, pela manhã e à noite, por três dias consecutivos (dias 1, 2 e 3), seguida por  
um período de quatro dias sem aplicação (um ciclo de tratamento). Caso haja qualquer verruga remanescente após sete dias de aplicação, outro ciclo de tratamento pode ser feito. Recomenda-se, no máximo, quatro ciclos de tratamento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Pode ocorrer irritação local no segundo ou terceiro dia de aplicação, associada ao início da necrose da verruga. Na maioria dos casos, as reações são leves. Sensibilização da pele, prurido, ardor, eritema, úlcera epitelial superficial e balanopostite foram relatados. A irritação local diminui gradativamente após o tratamento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
**a) Ácido tricloroacético (ATA) 80% a 90% em solução:** agente cáustico que promove destruição das condilomas pela  
coagulação química de seu conteúdo proteico. Aplicar uma pequena quantidade com um aplicador de algodão, adequado ao tamanho das  
lesões. Deve-se evitar o contato com a mucosa normal e permitir que a solução seque – é observado um branqueamento semelhante à  
82  
porcelana. A frequência e número de sessões deve variar conforme a resposta, sendo adequado iniciar com aplicações semanais. **É um tratamento que pode ser utilizado durante a gestação** . Não deve ser prescrito para uso domiciliar, frente ao potencial dano aos tecidos e suas complicações.  
**b) Podofilina 10%-25% (solução):** derivada de plantas ( _Podophylum peltatum_ ou _Podophylum emodi_ ), tem ação antimitótica, podendo trazer dano ao tecido lesado e ao tecido normal. Aplicar a podofilina sobre as verrugas e aguardar a secagem, evitando o contato com o tecido são. A frequência e o número de sessões variam conforme a resposta ao tratamento, sendo adequado iniciar com aplicações semanais. Em cada sessão, limitar o volume utilizado a 0,5mL e a área tratada a 10cm<sup>2</sup> . Além de irritação local, a absorção de grande quantidade da substância pode acarretar cardio, neuro e nefrotoxicidade. **É contraindicada na gestação.**  
**c) Eletrocauterização:** exige equipamento específico e anestesia local. É apropriada para o caso de lesões exofíticas, pedunculadas e volumosas. Como vantagem, permite a destruição de todas as lesões em uma sessão. Os resultados dependem da experiência do operador; o uso inadequado da técnica pode resultar em cicatrizes desfigurantes e, excepcionalmente, estenose ou fístulas em estruturas tubulares, como uretra, canal anal e vaginal.  
**d) Exérese cirúrgica:** requer anestesia local. A exérese tangencial (“ _shaving”_ ) com tesoura delicada ou lâmina é um excelente método, vez que, além da remoção completa das lesões, permite o estudo histopatológico dos fragmentos. É adequada para lesões volumosas, especialmente as pedunculadas. Em geral, não é necessário realizar sutura ou procedimento para hemostasia, sendo suficiente a compressão do local operado.  
**e) Crioterapia:** o nitrogênio líquido é atualmente a substância mais usada no tratamento ambulatorial das verrugas. Tem seu ponto de ebulição a -192°C e promove citólise térmica. Pode ser utilizada por meio de sondas, aplicadores de algodão ou, em sua forma mais prática, em spray, mediante equipamento específico. **A crioterapia é atóxica, podendo ser utilizada na gestação.** É muito apropriada em caso de lesões isoladas e queratinizadas. Geralmente bem tolerada, pode, excepcionalmente, requerer anestesia. A frequência e o número de sessões variam conforme a resposta ao tratamento, sendo adequado iniciar com aplicações semanais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Sabendo-se que o tratamento das verrugas anogenitais não leva à erradicação viral, recorrências são frequentes. O paciente e sua(s) parceria(s) sexual(is) devem retornar ao serviço caso se identifiquem novas lesões. Testes de detecção viral não são indicados em nenhuma situação, por não trazerem qualquer benefício às pessoas acometidas.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É importante que as parcerias sexuais sejam orientadas e examinadas. O profissional precisa ter segurança quanto às informações, eliminando dúvidas sobre os aspectos da transmissão. Pelo fato de a infecção ser assintomática e por ter um período de incubação potencialmente longo, na maioria das vezes não é possível estabelecer em qual parceria sexual iniciou-se a infecção. É mesmo possível que a infecção inicial tenha ocorrido na parceria sexual que não apresenta qualquer manifestação. A ocorrência de verrugas anogenitais pode ser causa de sofrimento psicológico, com repercussão nos relacionamentos interpessoais. A presença das lesões, como de outras IST, pode trazer insegurança às relações, inclusive com risco de estabelecimento de violência. Daí a importância de abrir uma possibilidade de consulta para a as parcerias sexuais.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O HPV não causa infertilidade. Na gestação, as lesões podem apresentar crescimento rápido, atingirem grande volume, tornar-se friáveis e sangrantes. O tratamento das gestantes muitas vezes tem pior resultado. A podofilina e o imiquimode **não** devem ser usados na gestação. O ácido tricloroacético ou o nitrogênio líquido são boas opções. Por vezes, especialmente no caso de lesões volumosas, a eletrocoagulação ou a exérese tangencial (“ _shaving_ ”) são as melhores opções. Não há indicação de parto cesáreo pela presença das lesões, ainda que haja a possibilidade de transmissão destas ao recém-nascido. A indicação seria a obstrução do canal de parto ou sangramento (ocorrências excepcionais).  
83

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A ocorrência de lesões anogenitais em crianças deve sempre levantar a suspeita de abuso sexual. Ainda que possa ocorrer na ausência de abuso, o achado merece uma investigação cuidadosa, que evite ao mesmo tempo a negligência dessa possibilidade e as consequências indesejáveis de uma acusação injustificada. Ao contrário do que frequentemente se acredita, a presença de lesões em membros da família não é uma prova de abuso, bem como a ausência de lesões em um potencial abusador não significa inexistência de violação. Essa crença gera, inclusive, demandas equivocadas por parte de profissionais de saúde, conselhos e autoridades judiciárias. O manejo dessas situações deve ser individualizado e judicioso.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Pessoas com prática sexual anal, em especial em especial PVHIV, sabidamente têm maior incidência de verrugas genitais perianais e complicações com lesões malignizáveis e neoplasias. É indispensável a informação para a identificação de queixas e alterações proctológicas e, idealmente, o exame periódico da região deve ser incluído nas rotinas de atendimento.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As infecções entéricas e intestinais sexualmente transmissíveis são classificadas por localização e apresentam mecanismos de transmissão e agentes etiológicos distintos. As infecções assintomáticas constituem a maioria dos casos, sendo mantenedoras da cadeia de transmissão<sup>259,260</sup> . Para informações sobre o rastreamento de assintomáticos, consultar a seção 2.4 deste PCDT.  
Quanto aos sinais e sintomas, eles são divididos em baixos (retais) e altos (colônicos). Os baixos incluem dor anal, corrimento anal mucopurulento, tenesmo e hematoquezia. Por sua vez, os altos envolvem diarreia, dor abdominal, cólicas, náuseas e febre. A ocorrência e a frequência dos sintomas variam de acordo com a etiologia da infecção e o _status_ imunológico da pessoa infectada<sup>261–268</sup> .  
_As infecções podem ser mais graves em PVHIV, com uma variabilidade maior de agentes etiológicos envolvidos. Para mais informações, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”_<sup>91</sup> _._  
O uso de preservativos é um método eficaz de proteção contra a aquisição de infecções entéricas e intestinais sexualmente transmissíveis. No entanto, deve-se levar em consideração que os agentes etiológicos podem ser disseminados sem a penetração peniana<sup>263</sup> . As relações sexuais com uso de dedos, instrumentos sexuais e prática boca-ânus também podem ser meios de transmissão. Isso faz com que outras medidas de prevenção devam ser adicionadas para uma prática sexual mais segura. As medidas de prevenção para a prática sexual anal estão descritas no Quadro 46.  
**Quadro 46 – Medidas de prevenção para prática sexual anal**  
- Usar preservativo e gel lubrificante;  
- Usar barreiras de látex durante o sexo oral-anal e luvas de látex para dedilhado ou _"fisting"_ ;  
- Lavar as mãos e a região genital e anal antes e depois do ato sexual;  
- Higienizar vibradores, _plugs_ anais e vaginais.  
Fonte: DCCI/SVS/MS.  
As infecções mais comuns são proctite, proctocolite e enterite, a serem detalhadas a seguir.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
84  
É uma inflamação limitada à mucosa retal, até 10-12 cm da borda anal. A transmissão dos patógenos ocorre por inoculação direta no reto durante o intercurso anal (intercurso receptivo anal) sem uso de preservativos, ou com rompimento destes. Os agentes etiológicos mais comuns da proctite são _Neisseria gonorrhoeae, Chlamydia trachomatis, Treponema pallidum_ e _Herpes simplex virus_ . A apresentação clínica é caracterizada por sinais e sintomas baixos: hematoquezia (73%), dor anal (62%), corrimento anal mucopurulento (58%), tenesmo e constipação<sup>266</sup> . É o principal agravo, inclusive entre os casos assintomáticos.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Trata-se de inflamação da mucosa retal e do cólon que vai além de 10-12cm da borda anal. A transmissão é frequentemente fecal-oral (contato direto ou indireto), estando relacionada à prática sexual que envolve boca-ânus. Os agentes etiológicos mais comuns da proctocolite são _Entamoeba histolytica, Campylobacter species, Salmonella species, Shigella species_ e _Chlamydia trachomatis_ (LGV). A apresentação clínica é caracterizada por sinais e sintomas baixos: dor anal, tenesmo, constipação, hematoquezia e corrimento anal mucopurulento, com alguns sinais e sintomas altos, como diarreia, cólica e dor abdominal em decorrência da inflamação da mucosa colônica.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
É a inflamação do duodeno, jejuno e/ou íleo. A via de transmissão também é fecal-oral (contato direto ou indireto) relacionada à prática sexual boca-ânus. O agente etiológico mais comum da enterite é a _Giardia lamblia._ A apresentação clínica é caracterizada por sinais e sintomas altos, como diarreia, cólicas e dor abdominal, sem os sinais e sintomas baixos das proctites e proctotocolites. A hepatite A também pode se manifestar com sintomatologia de enterite.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A anamnese com abordagem da história sexual é importante para o diagnóstico de infecções entéricas e intestinais sexualmente transmissíveis, além de predizer se a pessoa está sob risco de infecção<sup>263</sup> . Para mais informações sobre práticas sexuais e avaliação clínica, consultar o Capítulo 2 – Saúde sexual.  
A presença de sinais e sintomas, associada ao relato de relações sexuais anais sem proteção de barreira, deve levar à suspeição clínica. Infecções polimicrobianas podem ocorrer, reforçando a importância da coleta de material clínico e do diagnóstico etiológico para o tratamento adequado.  
Toda pessoa sintomática com epidemiologia positiva (prática sexual anal receptiva sem proteção de barreira) deve ser investigada por meio de exame físico, como segue:  
- Exame físico do abdômen;  
- Inspeção estática do ânus;  
- Inspeção dinâmica do ânus;  
- Palpação da região perianal;  
- Toque retal.  
O diagnóstico presuntivo é indicador para o tratamento clínico e para as orientações de prevenção (Figura 17).  
Outras causas de proctites além das IST são doenças autoimunes, radioterapia, irritantes químicos, doença inflamatória intestinal por infecção não sexualmente transmissível<sup>265,267</sup> .  
**Figura 17 – Fluxograma baseado no diagnóstico presuntivo das infecções entéricas e intestinais sexualmente transmissíveis**  
|Prática sexual<br>anal receptiva|Manifestações<br>clínicas de<br>proctite|Exame físico<br>direcionado|Tratamento<br>clínico baseado<br>no diagnóstico<br>presuntivo|
|---|---|---|---|  
85

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O diagnóstico definitivo se estabelece quando da identificação do agente etiológico. Para tanto, o Quadro 47 traz as recomendações para investigação laboratorial dos pacientes sintomáticos e assintomáticos.  
**Quadro 47 – Indicação para investigação laboratorial das infecções entéricas e intestinais sexualmente transmissíveis**  
**SINTOMÁTICOS** _Swab_ anal de todos os pacientes com diagnóstico presuntivo de infecções entéricas e intestinais sexualmente transmissíveis, para cultura (antibiograma) e detecção de clamídia e gonococo por biologia molecular<sup>a</sup> . **ASSINTOMÁTICOS** Rastreamento semestral por meio de _swab_ anal para detecção de clamídia e gonococo por biologia molecular<sup>a</sup> , para todas pessoas com prática anal receptiva sem proteção de barreira. Fonte: DCCI/SVS/MS. a Para amostras extragenitais (anais e faríngeas), utilizar testes com validação para tais sítios de coleta. A cultura, embora possível, se mostra menos sensível do que a biologia molecular. A anuscopia não é obrigatória para o diagnóstico e tratamento de proctite por IST; entretanto, é importante para descartar outros diagnósticos e deve ser solicitada sempre que houver dúvidas diagnósticas ou ausência de melhora após o tratamento clínico. A intensidade da dor anal pode contraindicar o uso da anuscopia. Quando realizada, os achados mais comuns são presença de secreção mucopurulenta no reto, perda do padrão vascular, edema, friabilidade e, às vezes, úlceras ou tumores inflamatórios, como na sífilis e no linfogranuloma venéreo<sup>262,267,268</sup> . Em caso de necessidade da anuscopia, a avaliação especializada está indicada.  
Quando há suspeita de enterite, recomenda-se exame de parasitológico nas fezes para pesquisa de trofozoítos e cistos de giárdia.  
Em todos os casos de diagnóstico de infecções entéricas e intestinais sexualmente transmissíveis, a testagem para HIV, sífilis e hepatites B e C está indicada. O tratamento de sífilis baseia-se nos resultados dos testes imunológicos. Para mais informações sobre diagnóstico, tratamento e monitoramento pós-tratamento de sífilis, consultar o Capítulo 5 deste PCDT.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O tratamento pode ser feito com base no diagnóstico presuntivo<sup>269</sup> , pois leva à rápida resolução e diminui o risco de propagação da doença<sup>266</sup> . Quando o diagnóstico presuntivo é realizado, o tratamento deve ter cobertura para _N. gonorrhoeae_ e _C. trachomatis_<sup>270,271</sup> conforme o Quadro 48.  
**Quadro 48 – Tratamento baseado no diagnóstico presuntivo das infecções entéricas e intestinais sexualmente transmissíveis**  
|**DIAGNÓSTICO**|**TRATAMENTO PREFERENCIAL**|**TRATAMENTO ALTERNATIVO**|
|---|---|---|
|**Proctite**|Ceftriaxona 500mg, IM, dose única|Ceftriaxona 500mg, IM, dose única|
||**MAIS**|**MAIS**|
||Azitromicina 500mg, 2 comprimidos, VO,<br>dose única|Doxiciclinaª 100mg, VO, 12/12h, por 10 dias|  
Fonte: DCCI/SVS/MS.  
ª A doxiciclina está contraindicada durante a gestação.  
Nos casos em que há confirmação da etiologia, o tratamento pode ser direcionado, conforme o Quadro 49. A presença de coinfecção é possível; portanto, o seguimento é fundamental para a identificação precoce de recidivas/reinfecções.  
**Quadro 49 – Tratamento baseado no diagnóstico etiológico das infecções entéricas e intestinais sexualmente transmissíveis**  
|**AGENTE ETIOLÓGICO**|**TRATAMENTO**|
|---|---|
|**_N. gonorrhoeae_**|Ceftriaxona 500mg, IM, dose única|
||**MAIS**|
||Azitromicina 500mg, 2 comprimidos, VO, dose única|  
86  
|**_C. trachomatis_**|Azitromicina 500mg, 2 comprimidos, VO, em dose única|
|---|---|
||**OU**|
||Doxiciclina<sup>a</sup>100mg, VO, 12/12h, por 10 dias|
|**Herpes simplex virus**<sup>**b**</sup>|Aciclovir 200mg, 2 comprimidos, VO, 8/8h, por 10 dias|
|**_T. pallidum_**|Benzilpenicilina benzatina 2,4 milhões UI, IM, dose única|
|**_Giardia lamblia_**|Metronidazol 250mg, 1 comprimido, VO, 8/8h, por 7 dias|  
Fonte: DCCI/SVS/MS.  
a A doxiciclina está contraindicada durante a gestação.  
b A presença de vesículas no exame físico indica cobertura e tratamento para HSV.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Após o tratamento adequado, espera-se a resolução dos sinais e sintomas clínicos. Nos casos de persistência ou recidivas deve-se descartar reexposição. Em um segundo episódio, indica-se encaminhamento para a referência e coleta de material para identificação da etiologia.  
São fundamentais as orientações sobre a prática sexual anal e os cuidados de prevenção a serem iniciados, com o objetivo de interromper a cadeia de transmissão e evitar possíveis novas exposições. Nesse sentido, as principais recomendações são:  
- Orientar a pessoa sobre o risco de novas exposições e os métodos de prevenção disponíveis;  
- Além do uso de preservativos, reforçar a lavagem das mãos antes e após relação sexual;  
- Evitar sexo anal, sexo oral-anal ( _rimming_ ) e coprofagia ( _scat_ ), em caso de paciente sintomático;  
- Incentivar o uso de luvas para _fisting_ ;  
- Evitar compartilhar materiais de _douching_ , enemas e brinquedos sexuais.  
- Verificar imunização para hepatite B e, quando necessário, indicar a imunização;  
- Orientar sobre o risco de hepatite A. As indicações da vacina encontram-se na seção 2.5.3;  
- Testar para HIV;  
- Testar para sífilis. Idealmente, iniciar com teste treponêmico, preferencialmente teste rápido. Caso haja história de diagnóstico de sífilis, iniciar o fluxograma com teste não treponêmico (VDRL, RPR);  
- Verificar imunização para HPV. As indicações da vacina encontram-se nas seções 2.5.1;  
- Avaliar indicação de PrEP e orientar a pessoa sobre essa ferramenta de prevenção. Para mais informações, consultar o PCDT PrEP<sup>10</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Para que a cadeia de transmissão seja interrompida, não basta tratar o paciente. A identificação das parcerias sexuais (rede sexual) e sua adequada avaliação clínica é fundamental. A persistência de pessoas não identificadas e/ou não tratadas na rede sexual aumenta o risco de reinfecções e resistência bacteriana<sup>272</sup> .  
**As parcerias sexuais sintomáticas devem ser tratadas com ceftriaxona 500mg, IM e azitromicina 500mg, 2 comprimidos, VO, dose única.** Para os casos assintomáticos, o rastreamento está indicado de acordo com as práticas sexuais. Toda parceria sexual deve ser testada para sífilis, HIV e hepatites B e C.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A infecção pelo HIV envolve diversas fases, com durações variáveis, que dependem da resposta imunológica do indivíduo e da carga viral. A primeira fase da infecção (infecção aguda) é o período do surgimento de sinais e sintomas inespecíficos da doença, que ocorrem entre a primeira e terceira semana após a infecção. A fase seguinte (infecção assintomática) pode durar anos, até o aparecimento de infecções oportunistas (tuberculose, neurotoxoplasmose, neurocriptococose) e algumas neoplasias (linfomas não Hodgkin e sarcoma de Kaposi). A presença desses eventos define a aids.  
87  
_Desde dezembro de 2013, o DCCI/SVS/MS recomenda início imediato da TARV para todas as PVHIV, independentemente do seu estágio clínico e/ou imunológico._  
O Brasil busca, como parte das ações pactuadas de enfrentamento à epidemia de HIV, atingir a meta 90-90-90, a qual estabelece que, até 2020, 90% das pessoas com HIV sejam diagnosticadas (ampliando o acesso ao diagnóstico do HIV); destas, que 90% estejam em tratamento antirretroviral (ampliando o acesso à TARV); e, destas, que 90% tenham carga viral indetectável (indicando boa adesão ao tratamento e qualidade da assistência à PVHIV). O compromisso assumido exige não somente que novas metodologias de cuidado e de gestão sejam implantadas, mas que também haja um comprometimento de toda a sociedade para o sucesso e alcance desses propósitos.  
Uma estratégia do DCCI/SVS, do Ministério da Saúde, é promover o cuidado compartilhado da atenção às PVHIV entre os serviços especializados e a Atenção Básica, com o objetivo de:  
- Ampliar o acesso à saúde para as PVHIV;  
- Estabelecer maior vínculo destas com os serviços de saúde;  
- Melhorar as possibilidades de atendimento de qualidade;  
- Melhorar o prognóstico das PVHIV.  
_A Atenção Básica é a porta de entrada preferencial da rede SUS, sendo responsável por acolher as PVHIV e promover a vinculação e corresponsabilização pela atenção às suas necessidades de saúde._  
Para dar apoio a essa estratégia, encontram-se disponíveis em http://www.aids.gov.br os seguintes materiais de suporte:  
- Cinco Passos para a Implementação do Manejo da Infecção pelo HIV na Atenção Básica – Manual para gestores;  
- Manual de Manejo do HIV na Atenção Básica – Manual para médicos;  
- Cuidado Integral às Pessoas que Vivem com HIV pela Atenção Básica – Manual para a equipe multiprofissional;  
- Caderno de Boas Práticas em HIV/Aids na Atenção Básica.  
Para mais informações sobre a infecção pelo HIV/aids, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”<sup>91</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
_Toda pessoa com exposição sexual de risco ou diagnosticada com IST deve ser testada para HIV._  
As estratégias para testagem do HIV têm o objetivo de melhorar a qualidade do diagnóstico da infecção pelo vírus e, ao mesmo tempo, fornecer uma base racional para assegurar que esse diagnóstico seja realizado o mais precocemente possível, de forma segura e com rápida conclusão.  
Para mais informações, consultar o Manual Técnico para o “Diagnóstico da Infecção pelo HIV em Adultos e Crianças”<sup>273</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
As hepatites virais causadas pelos vírus hepatotrópicos (vírus das hepatites A, B, C, D ou Delta e E) são doenças causadas por diferentes agentes etiológicos, que têm em comum o tropismo primário pelo tecido hepático e que constituem um enorme desafio à saúde pública em todo o mundo. Essas infecções são responsáveis por cerca de 1,4 milhão de óbitos anualmente, como consequência de suas formas agudas graves e, principalmente, pelas complicações das formas descompensadas crônicas ou por hepatocarcinoma. Esse número é comparável às mortes causadas pela tuberculose e é superior às causadas pelo HIV<sup>274</sup> .  
88  
No Brasil, de 1999 a 2016, foram notificados no Sinan aproximadamente 600.000 casos confirmados de hepatites virais A, B, C e D. Entretanto, estima-se que o número de casos seja bem maior, em razão de a maioria dos casos não apresentarem sintomas, o que dificulta a procura por diagnóstico<sup>275</sup> .  
Dados do Ministério da Saúde estimam que aproximadamente 657 mil pessoas tenham o vírus da hepatite C no Brasil<sup>276</sup> . Devido às suas taxas de prevalência, cronicidade e potencial de transmissibilidade e complicações, as hepatites virais B e C são agravos de grande importância em termos de saúde pública. Embora possuam características clínicas semelhantes, os agentes etiológicos dessas infecções têm diferentes ciclos replicativos e formas de transmissão, o que lhes garante epidemiologia distinta.  
A maioria das pessoas infectadas pelas hepatites virais crônicas desconhece seu diagnóstico, constituindo elo fundamental na cadeia de transmissão dessas infecções.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A hepatite A é uma doença comumente transmitida por meio de contato oral-fecal, por ingestão de água e/ou alimentos contaminados. A transmissão sexual do vírus da hepatite A (HAV) também tem sido relatada. Desde a década de 70, surtos dessa doença têm sido relatados entre homens que fazem sexo com homens (HSH), homossexuais ou bissexuais. Surtos cíclicos em áreas urbanas também têm sido descritos nos Estados Unidos, Canadá, Europa e Austrália<sup>277–281</sup> .  
No Brasil, de acordo com o Centro de Informações Estratégicas de Vigilância em Saúde (CIEVS) e a Divisão de Doenças de Transmissão Hídrica e Alimentar do Ministério da Saúde e da Secretaria de Estado de São Paulo, recentemente tem-se observado aumento do número de casos de hepatite A no município de São Paulo. Até novembro de 2017, ocorreram 656 notificações de hepatite A. Dentre esses casos, 87% eram do sexo masculino, 80% tinham entre 18 e 39 anos e 45% (295) dos casos haviam sido adquiridos por contato sexual desprotegido. Houve quatro casos de hepatite fulminante e dois óbitos<sup>282</sup> .  
Nesse sentido, com o objetivo de diminuir o risco de transmissão sexual da hepatite A, é importante incentivar medidas de higiene antes e após as relações sexuais, assim como o uso de preservativos, no contexto das práticas sexuais que envolvam a possibilidade de contato oralfecal.  
Para informações sobre imunização contra HAV, consultar o item 2.5.3 deste PCDT.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O HBV é transmitido por meio de contato com fluidos corpóreos infectados. O sangue é o veículo de transmissão mais importante, mas outros fluidos também podem transmitir o HBV, como sêmen e saliva. Os meios de transmissão conhecidos são perinatal, sexual e parenteral/percutâneo. As rotas de transmissão predominantes variam de acordo com a endemicidade da infecção pelo HBV. Em áreas com alta endemicidade, a via perinatal é a principal forma de transmissão do vírus. Entretanto, em áreas com baixa endemicidade, o contato sexual entre adultos com alta exposição de risco é a via predominante<sup>283–285</sup> . A capacidade do vírus de sobreviver fora do organismo humano por período prolongado facilita a transmissão por meio do contato direto ou por meio de fômites<sup>284</sup> .  
Quando adquirida no período perinatal, a infecção pelo HBV resulta em aproximadamente 90% de cronicidade; se a aquisição acontece na primeira infância, ocorre entre 20% a 40% de cronicidade; mas, se a hepatite B é contraída na adolescência e idade adulta, essa taxa cai para 0 a 10%.  
A infecção é na maioria das vezes assintomática, sendo que menos de 5% das infecções adquiridas na fase adulta se tornam crônicas<sup>286</sup> .  
No Brasil, a hepatite B grande importância epidemiológica, com altas prevalências na Região Norte, principalmente em comunidades ribeirinhas e indígenas. Além disso, o vírus da hepatite Delta (HDV) também está presente nessa região, com grande impacto clínico e epidemiológico. O HDV é um vírus que acomete apenas pessoas infectadas pelo vírus da hepatite B, podendo sua transmissão ocorrer concomitantemente à infecção pelo HBV (coinfecção) ou posteriormente à infecção pelo HBV (superinfecção).  
Recomenda-se a vacinação contra hepatite B para todas as pessoas, independentemente de faixa etária. A vacina é composta por no mínimo três doses e deve ser oferecida em esquema completo.  
89

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A forma mais eficaz de transmissão do vírus da hepatite C (HCV) ocorre por meio da exposição percutânea repetida, ou mediante grandes volumes de sangue infectado. No Brasil, a transfusão de sangue e hemoderivados de doadores não testados para HCV foi considerada uma forma importante de transmissão durante muitos anos. Porém, a partir de 1993, após a padronização dos processos de triagem pré-doação, houve uma significativa redução na transmissão do HCV por meio transfusional<sup>287</sup> .  
Além desses fatores de risco, outras importantes fontes de transmissão do HCV são hemodiálise, procedimentos de manicure e pedicure, confecção de _piercings_ e tatuagens, tratamentos odontológicos e procedimentos endoscópicos (caso não sigam as normas de boas práticas de esterilização e desinfecção de materiais reutilizáveis e/ou produtos descartáveis), além da transmissão vertical e transmissão sexual, principalmente em PVHIV e HSH<sup>288</sup> .  
A transmissão sexual do HCV é menos frequente que a transmissão da infecção pelo HBV, ocorrendo em pessoas com múltiplas parcerias sexuais e que têm relações sem uso de preservativo. Como em outras infecções de transmissão sexual, a presença de uma IST, como lesões ulceradas em região anogenital, e práticas sexuais de risco para aquisição de IST/HIV constituem um importante facilitador de transmissão, particularmente na população HSH.  
A história natural do HCV é marcada pela evolução silenciosa. Muitas vezes, a doença é diagnosticada décadas após a infecção, e os sinais e sintomas são comuns às demais doenças parenquimatosas crônicas do fígado, manifestando-se apenas em fases mais avançadas da doença.  
A testagem para HCV deve ser solicitada para todos os indivíduos em situações de risco, como:  
- Todas as pessoas com idade igual ou superior a 40 anos;  
- **E/OU**  
- PVHIV;  
- Pessoas prestes a iniciar PrEP ou que façam uso frequente da PEP;  
- Pessoas com múltiplas parcerias sexuais ou com múltiplas IST;  
- Pessoas transexuais;  
- Trabalhadores(as) do sexo;  
- Pacientes com diagnóstico de diabetes, antecedentes psiquiátricos, histórico de patologia hepática sem diagnóstico, elevações de ALT e/ou AST e antecedente de doença renal ou de imunodepressão, a qualquer tempo;  
- Pacientes em regime de diálise;  
- Antecedente de transfusão de sangue, hemoderivados ou órgãos antes de 1993;  
- Antecedente de uso de drogas ilícitas injetáveis, intranasais ou fumadas;  
- Pessoas dependentes de álcool;  
- Antecedente de tatuagem ou _piercing_ em ambiente não regulamentado;  
- Antecedente de exposição a material biológico contaminado;  
- População privada de liberdade;  
- Contactante íntimo ou parceiro sexual de pessoas com anti-HCV reagente;  
- Crianças nascidas de mães que vivem com o HCV.  
-

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O diagnóstico das hepatites virais baseia-se na detecção dos marcadores presentes no sangue, soro, plasma ou fluido oral da pessoa infectada, por meio de imunoensaios, e/ou na detecção do ácido nucleico viral, empregando técnicas de biologia molecular.  
Desde 2011, o Ministério da Saúde inseriu os testes rápidos de hepatite B e C na rede SUS, o que tem ajudado a ampliar o diagnóstico de ambas as infecções. Os testes rápidos são testes de triagem e, uma vez que apresentem resultados reagentes, deverão ser confirmados com a realização da carga viral para hepatite C (HCV-PCR), carga viral para hepatite B (HBV-DNA) ou outros marcadores, conforme a disponibilidade de cada serviço e de acordo com os fluxogramas de diagnóstico propostos pelo DCCI/SVS/ MS. Todos os fluxogramas de diagnóstico referentes às hepatites virais, contemplando vários tipos de metodologias, estão publicados detalhadamente no “Manual Técnico para o Diagnóstico das Hepatites Virais”<sup>289</sup> .  
90  
Para mais informações sobre o manejo clínico e tratamento do paciente com hepatites B e C e coinfecções, ou para a prevenção da transmissão vertical de HIV, sífilis e hepatites virais, consulte os Protocolos Clínicos e Diretrizes Terapêuticas correspondentes<sup>11,290,291</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O vírus Zika é um Flavivírus capaz de causar infecção em humanos; o primeiro caso diagnosticado no Brasil ocorreu no ano de 2015, na Região Nordeste. A maioria das pessoas infectadas apresentará a forma assintomática da doença. Em pessoas sintomáticas, os principais sinais e sintomas são _rash_ cutâneo, febre, conjuntivite, cefaleia, dores articulares e mialgia<sup>292</sup> .  
As anomalias congênitas associadas à infecção pelo vírus Zika foram observadas logo após a entrada do vírus no território nacional. A microcefalia foi o acometimento mais frequente do SNC e desencadeou situação de alerta no Brasil naquele momento, por ter sido considerado uma Situação de Emergência em Saúde Pública de Importância Nacional<sup>293</sup> .  
O vírus pode ser transmitido por meio da picada do vetor _Aedes aegypti_ (o mesmo mosquito que transmite dengue, Chikungunya e febre amarela), assim como por transmissão vertical e sexual. A principal medida de combate à infecção é a prevenção, com medidas de controle do vetor e medidas protetivas individuais (uso de repelentes e de roupas com mangas longas e calças compridas), de modo a diminuir a chance de picada pelo mosquito. Ainda não há vacinas para prevenir a infecção pelo vírus Zika e nem tratamento específico<sup>293</sup> .  
_A transmissão sexual do vírus Zika foi comprovada por inúmeros relatos de casos, sendo a Zika considerada uma IST, cuja transmissão sexual pode ser evitada por meio do uso de preservativo_<sup>294</sup> _._  
Deve-se reforçar a importância do uso do preservativo, especialmente após viagens a áreas endêmicas ou suspeita e/ou confirmação do diagnóstico da infecção pela parceria sexual. Isso porque a persistência das partículas virais foi observada em fluidos corporais, como sêmen<sup>295–299</sup> .  
A OMS publicou em 2016 as diretrizes sobre a prevenção da transmissão sexual do vírus, com base em uma quantidade limitada de evidências, durante uma emergência de saúde pública de interesse internacional. A qualidade de evidências cresceu consideravelmente desde então, o que possibilitou à atualização das diretrizes sobre a prevenção da transmissão sexual do vírus Zika em 2020<sup>300</sup> e estão descritas no quadro abaixo.  
**Para casais que desejam a concepção, recomenda-se**<sup>300</sup> :  
- Aguardar até **três meses** após sinais/sintomas relacionados à infecção pelo vírus Zika quando o homem foi infectado;  
- Aguardar até **oito semanas (dois meses)** após sinais/sintomas relacionados à infecção pelo vírus Zika quando a mulher foi infectada.  
Em áreas endêmicas, casais que desejam a concepção devem ser orientados quanto aos riscos da infecção pelo vírus Zika e a possibilidade de malformações fetais. Em áreas endêmicas, a recomendação de uso contínuo do preservativo durante toda a gestação deve fazer parte do aconselhamento durante as consultas de pré-natal<sup>292</sup> . Até o momento, não há casos de transmissão por meio da reprodução assistida, mas se recomenda que, nos tratamentos de fertilidade, os prazos acima citados sejam considerados.  
O diagnóstico precoce da infecção pelo vírus Zika na gestante, por meio de exames de detecção do RNA viral mediante PCR e/ou sorologias, auxilia no rastreamento das gestações de alto risco. Esses exames também são utilizados no seguimento especializado para a criança que tenha nascido com alguma anomalia congênita.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Os vírus HTLV 1 e 2 pertencem à família _Retroviridae_ , sendo que a infecção não implica, necessariamente, o desenvolvimento de processos patogênicos. As vias de transmissão são a sexual, a parenteral e a vertical (gestação, parto ou aleitamento materno, principalmente)<sup>301–303</sup> .  
91  
O HTLV está associado a doenças neurológicas, oftalmológicas e dermatológicas, assim como a leucemia/linfoma<sup>301</sup> . Das pessoas infectadas pelo HTLV, aproximadamente 90% permanecerão assintomáticas ao longo de suas vidas. Essas pessoas mantêm uma rede de transmissão silenciosa pela via sexual, sanguínea e vertical.  
O aleitamento materno é a principal via de transmissão vertical da infecção, que ocorre em 20% a 30% dos lactentes amamentados por mães infectadas. O risco está associado a variáveis individuais, a exemplo do tempo de amamentação<sup>304</sup> . A transmissão intrauterina ou no período periparto ocorre em menos de 5% dos casos. A transmissão sexual é mais frequente do homem para a mulher, refletindo-se em maiores taxas da infecção entre mulheres<sup>305</sup> .  
As recomendações para a prevenção da transmissão vertical são:  
- Uso de preservativo em todas as relações sexuais;  
- Oferta de redução de danos para pessoas que usam drogas injetáveis;  
- **Contraindicação à amamentação em mães vivendo com HTLV 1/2** , sendo sugerido o uso de inibidores de lactação e de fórmulas lácteas infantis<sup>301,305</sup> .  
A leucemia/linfoma de células T do adulto (ATL) é uma doença das células T periféricas associada à infecção pelo HTLV-1. Para mais informações a respeito, consulte o “Protocolo de Uso da Zidovudina para Tratamento do Adulto com Leucemia/Linfoma Associado ao Vírus HTLV-1”<sup>306</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A violência sexual é entendida como uma questão de saúde pública, segurança e acesso à justiça, que exige do Estado políticas e ações integradas para responder a esse problema. Pode acontecer em espaços públicos e privados, causar traumas e ferimentos visíveis e invisíveis, e, em algumas situações, levar à morte<sup>307</sup> .  
A violência é um fenômeno multidimensional que afeta todas as classes sociais, raças, etnias e orientações sexuais, e que se constitui como uma das principais formas de violação dos direitos humanos, atingindo o direito à vida, à saúde e à integridade física. Um dos grandes desafios para enfrentar essa violência é a articulação e integração dos serviços e da atenção em saúde, de forma a evitar a revitimização e, acima de tudo, oferecer um atendimento humanizado e integral.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A atenção às pessoas em situação de violência sexual é composta por ações intersetoriais que possibilitam o atendimento, proteção, prevenção de novas situações e medidas para possibilitar a responsabilização dos(as) autores(as) da agressão<sup>307</sup> .  
Em âmbito nacional, destacam-se a Lei nº 12.845/2013<sup>308</sup> , que dispõe sobre o atendimento obrigatório e integral de pessoas em situação de violência sexual na rede do SUS e o Decreto nº 7.958/2013<sup>309</sup> , que estabelece diretrizes para o atendimento humanizado às vítimas de violência sexual pelos profissionais da área de segurança pública e da rede de atendimento do SUS.  
O atendimento integral às pessoas em situação de violência é potencializado pelo registro de informações e pela coleta de vestígios no momento do atendimento em saúde, contribuindo para a humanização da atenção e combate à impunidade<sup>307</sup> .  
Nesse sentido, o registro da notificação de violência interpessoal e autoprovocada atende ao disposto na legislação – Leis nº 8.069/1990 (crianças e adolescentes)<sup>310</sup> , nº 10.778/2003 (mulher)<sup>311</sup> e nº 10.741/2003 (pessoa idosa)<sup>312</sup> . No caso de violência sexual e tentativas de suicídio, a notificação deve ser realizada de forma imediata (em até 24 horas) na esfera municipal, com o propósito de garantir a intervenção oportuna nos casos (Portaria MS/GM nº 204/2016)<sup>313</sup> .  
O estupro é definido como o ato de constranger alguém, mediante violência ou grave ameaça, a ter conjunção carnal ou a praticar ou permitir que com ele se pratique outro ato libidinoso, sendo crime previsto no artigo 213 do Código Penal Brasileiro<sup>314</sup> . A real frequência desse ato criminoso é desconhecida, uma vez que as vítimas hesitam em informá-lo, devido à humilhação, medo, sentimento de culpa e desconhecimento das leis.  
92  
O 11º Anuário Brasileiro de Segurança Pública estimou que, em 2016, houve 49.497 ocorrências de estupro, sendo que entre 85% e 88% dos casos a vítima era mulher<sup>315</sup> .  
Os dados da notificação do Sistema de Vigilância de Violências e Acidentes (Viva-Sinan) apontam que, em 2016, foram notificados nos serviços de saúde 31.539 casos de violência sexual. Destes, 23.053 foram notificados como estupro, dos quais 89,2% (20.559) contra pessoas do sexo feminino e 10,8% (2.491) contra pessoas do sexo masculino. Os casos de estupro notificados ocorreram em sua maioria na residência (57,3%), em pessoas da raça/cor preta e parda (54,1%) e na faixa etária de 0 a 19 anos (72,5%).  
O atendimento à vítima de estupro é complexo e necessita, idealmente, de cuidados de uma equipe multidisciplinar familiarizada com casos similares. Quando praticado durante a gravidez, representa fator de risco para saúde da mulher e do feto, por aumentar a possibilidade de complicações obstétricas, abortamento e RN de baixo peso.  
Nos casos de violência contra criança, adolescente e pessoa idosa, os órgãos de proteção devem ser comunicados imediatamente, a exemplo do conselho tutelar, vara da infância, conselho da pessoa idosa ou outros órgãos referentes a essas competências.  
A disponibilização de informações sobre os serviços de referência que asseguram a atenção integral às pessoas em situação de violência sexual em toda a rede de atendimento do SUS contribui para garantir um maior acesso e proteção.  
O medo de ter contraído HIV/IST aumenta a ansiedade dos indivíduos expostos. As pessoas em situação de violência devem ser acolhidas e informadas sobre os procedimentos terapêuticos a serem realizados, como atendimento clínico-laboratorial, psicológico e social imediato; profilaxia do HIV, das IST não virais e da gravidez; vacinação e imunização passiva para HBV; testagem para sífilis, HIV, hepatites virais B e C, clamídia e gonorreia; agendamento de retorno para acompanhamento, entre outros.  
Não há nenhuma previsão legal para exigência de Boletim de Ocorrência (B.O.) para realização do atendimento na saúde; contudo, no caso  
de crianças, adolescentes e pessoas idosas, os respectivos conselhos tutelares (ou outro órgão, na ausência destes) deverão ser imediatamente comunicados para as providências cabíveis.  
Cabe à equipe de saúde acolher e fornecer orientações às pessoas quanto aos seus direitos e à importância de buscar proteção e demais providências legais.  
A prevalência de IST em situações de violência sexual é elevada, e o risco de infecção depende de diversas variáveis, como o tipo de violência sofrida (vaginal, anal ou oral), o número de agressores, o tempo de exposição (única, múltipla ou crônica), a ocorrência de traumatismos genitais, a idade e a susceptibilidade da pessoa, a condição himenal e a presença de IST e/ou úlcera genital prévia.  
A profilaxia das IST não virais está indicada nas situações de exposição com risco de transmissão, independentemente da presença ou gravidade das lesões físicas e idade. Gonorreia, sífilis, infecção por clamídia, tricomoníase e cancroide podem ser prevenidos com o uso de medicamentos de reconhecida eficácia. Algumas IST virais, como as infecções por HSV e HPV, ainda não possuem profilaxias específicas.  
Diferentemente do que ocorre na profilaxia pós-exposição (PEP) da infecção pelo HIV, a prevenção das IST não virais pode ser eventualmente postergada, em função das condições de adesão, mas se recomenda a sua realização imediata, sempre que possível.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O esquema de associação de medicamentos para a profilaxia das IST não virais em vítimas de violência sexual encontra-se no Quadro 50. A profilaxia para as IST não virais durante a gravidez está indicada em qualquer idade gestacional.  
**Quadro 50 – Profilaxia das IST em situação de violência sexual**  
|**IST**|**MEDICAÇÃO**<sup>**a**</sup>|**POSO**|**LOGIA**|
|---|---|---|---|
|||**Adultos e adolescentes com mais**<br>**de 45 kg, incluindo gestantes**|**Crianças e adolescentes com menos**<br>**de 45 kg**|
|**Sífilis**|Benzilpenicilina benzatina|2,4 milhões UI, IM (1,2 milhão UI<br>em cada glúteo) em dose única|50.000 UI/kg, IM, dose única (dose<br>máxima total: 2,4 milhões UI)|
|**Gonorreia**|Ceftriaxona + azitromicina|Ceftriaxona: 500mg, 1 ampola, IM,<br>dose única<br>**MAIS**<br>Azitromicina: 500mg, 2<br>comprimidos,VO,dose única(total|Ceftriaxona: 125mg, IM, dose única<br>**MAIS**<br>Azitromicina: 20mg/kg de peso, VO,<br>dose única (dose máxima total: 1g)|  
93  
|||dose: 1g)||
|---|---|---|---|
|**Infecção por clamídia**|Azitromicina|500mg, 2 comprimidos, VO, dose<br>única (dose total: 1g)|20mg/kg de peso, VO, dose única<br>(dose máxima total: 1g)|
|**Tricomoníase**|Metronidazol<sup>b,c</sup>|500mg, 4 comprimidos VO, dose<br>única (dose total: 2g)|15 mg/kg/dia, divididos em 3<br>doses/dia, por 7 dias (dose diária<br>máxima: 2g)|  
Fonte: DCCI/SVS/MS.  
a Em pessoas com história comprovada de hipersensibilidade aos medicamentos indicados, devem-se utilizar fármacos alternativos, conforme exposto nos capítulos específicos desse PCDT.  
b A administração profilática do metronidazol ou suas alternativas pode ser postergada ou evitada em casos de intolerância gastrintestinal conhecida ao medicamento. Também deve ser postergada nos casos em que houver prescrição de contracepção de emergência e de PEP. c O metronidazol não poderá ser utilizado no primeiro trimestre de gestação.  
As crianças apresentam maior vulnerabilidade às IST, devido à imaturidade anatômica e fisiológica da mucosa vaginal, entre outros fatores. O diagnóstico de uma IST em crianças pode ser o primeiro sinal de abuso sexual e deve ser investigado.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Se a vítima não for vacinada ou estiver com vacinação incompleta contra hepatite B, deve-se vacinar ou completar a vacinação. Não se recomenda o uso rotineiro de IGHAHB, exceto se a vítima for suscetível e o responsável pela violência seja HBsAg reagente ou pertencente a um grupo de risco (pessoas que usam drogas, por exemplo). Quando indicada, a IGHAHB deve ser aplicada o mais precocemente possível – até, no máximo, 14 dias após a exposição<sup>9</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A Profilaxia Pós-Exposição (PEP) de risco à infecção pelo HIV consiste no uso de antirretrovirais, por 28 dias, para reduzir o risco de adquirir essa infecção.  
O atendimento após a exposição ao HIV é uma urgência. A PEP deve ser iniciada o mais precocemente possível, tendo como limite as 72 horas subsequentes à exposição. Nos casos em que o atendimento ocorrer após 72 horas da exposição, a PEP não está mais indicada.  
Mais informações sobre a Profilaxia Pós-Exposição ao HIV encontram-se no “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco (PEP) à Infecção pelo HIV, IST e Hepatites Virais”<sup>9</sup> .

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
De acordo com o Decreto-Lei nº 2.848, de 7 de dezembro de 1940, artigo 128, inciso II do Código Penal brasileiro<sup>314</sup> , o abortamento é permitido quando a gravidez resulta de estupro, risco de morte da gestante ou anencefalia (ADPF 54 – Ação de Descumprimento de Preceito Fundamental).  
O método mais adequado para a **anticoncepção de emergência** consiste na utilização de **levonorgestrel** , em função de evidentes vantagens sobre o método de Yuzpe (uso de hormônios combinados), como: efeitos colaterais sensivelmente reduzidos, não produção de interação com outros medicamentos e maior efetividade<sup>9</sup> .  
**Quadro 51 – Apresentação e posologia da anticoncepção de emergência**  
|**APRESENTAÇÃO**|**POSOLOGIA**|
|---|---|
|Comprimidos de 0,75mg (cartela com 2 comprimidos) e 1,5mg de|**1ª opção**– 1 comprimido de 1,5mg VO ou 2 comprimidos de<br>0,75mg, dose única, até 5 dias após a relação sexual<sup>a</sup>|
|levonorgestrel (cartela com 1 comprimido)|**2ª opção**– 1 comprimido de 0,75mg VO de 12/12 horas, no total<br>de 2 comprimidos, até 5 dias após a relação sexual<sup>a</sup>|
|Fonte: DCCI/SVS/MS.||  
a A eficácia é sempre maior quanto mais próximo à relação for utilizada a anticoncepção de emergência.  
O uso repetitivo da anticoncepção de emergência diminui sua eficácia; portanto, não se trata de um método a ser adotado como rotina. Para mais informações, consultar o “Protocolo para Utilização do Levonorgestrel”, do Ministério da Saúde<sup>316</sup> .  
94

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Enfrentar a violência contra as mulheres exige, acima de tudo, a construção de uma rede intersetorial, articulada e comprometida com a saúde das mulheres, que garanta seus direitos, oferecendo condições para que possam ter acesso ao cuidado qualificado, bem como a possibilidade de tomar decisões conscientes e autônomas.  
Nesse sentido, com o intuito de estabelecer diretrizes técnico-políticas para atenção integral à saúde da mulher, em 2004 foi publicada pelo Ministério da Saúde a “Política Nacional de Atenção Integral à Saúde da Mulher: Princípios e Diretrizes” – PNAISM<sup>317</sup> .  
A Lei nº 12.845, de 1º de agosto de 2013<sup>308</sup> , estabelece que os hospitais devem oferecer às pessoas em situação de violência sexual  
atendimento emergencial, integral e multidisciplinar, e encaminhamento, quando necessário, aos serviços de assistência social.  
As ações durante o atendimento às pessoas em situação de violência sexual no SUS devem ser desenvolvidas em conformidade com a Nota Técnica: “Prevenção e tratamento dos agravos resultantes da violência sexual contra mulheres e adolescentes”, do Ministério da Saúde<sup>318</sup> , e realizadas conforme estabelece também o art. 5º da Portaria nº 485, de 1º de abril de 2014<sup>319</sup> :  
I - Acolhimento;  
II - Atendimento humanizado, observados os princípios do respeito da dignidade da pessoa humana, da não discriminação, do sigilo e da privacidade; III - Escuta qualificada, propiciando ambiente de confiança e respeito; IV - Informação prévia ao paciente, assegurada sua compreensão sobre o que será realizado em cada etapa do atendimento e a importância das condutas médicas, multiprofissionais e policiais, respeitada sua decisão sobre a realização de qualquer procedimento; V - Atendimento clínico; VI - Atendimento psicológico; VII - Realização de anamnese e preenchimento de prontuário onde conste, entre outras, as seguintes informações: a) data e hora do atendimento; b) história clínica detalhada, com dados sobre a violência sofrida; c) exame físico completo, inclusive exame ginecológico, se for necessário; d) descrição minuciosa das lesões, com indicação da temporalidade e localização específica; e e) identificação dos profissionais que atenderam a pessoa em situação de violência; VIII - Dispensação e administração de medicamentos para profilaxias indicadas conforme as normas, regras e diretrizes técnicas do Ministério da Saúde;  
IX - Exames laboratoriais necessários; X - Preenchimento da ficha de notificação compulsória de violência doméstica, sexual e outras violências; XI - Orientação e agendamento ou encaminhamento para acompanhamento clínico e psicossocial; e XII - Orientação às pessoas em situação de violência ou aos seus responsáveis a respeito de seus direitos e sobre a existência de outros serviços para atendimento a pessoas em situação de violência sexual.  
O setor de saúde, por ser um dos espaços privilegiados para a identificação das pessoas em situação de violências, tem papel fundamental na definição e articulação dos serviços e organizações que, direta ou indiretamente, atendem a essas situações.  
Na atenção às pessoas em situação de violências, é essencial que o atendimento seja realizado em rede, de forma articulada e integrada, para a garantia da assistência de forma integral.  
A equipe de saúde precisa buscar identificar as organizações e serviços disponíveis no território que possam contribuir com a assistência, a exemplo das Delegacias da Mulher e da Criança e do Adolescente, do Conselho Tutelar, do Conselho de Direitos de Crianças e Adolescentes, CRAS, CREAS, do Instituto Médico Legal, do Ministério Público, das instituições como casas-abrigo, dos grupos de mulheres, das creches, entre outros. O fluxo e os problemas de acesso e de manejo dos casos em cada nível dessa rede precisam ser debatidos e planejados periodicamente.  
É importante salientar que, mesmo se a rede não estiver totalmente estruturada, é possível realizar o acompanhamento e encaminhamento das pessoas em situação de violência, contanto que o(a) profissional tenha conhecimento dos serviços existentes<sup>320</sup> .  
Nesse sentido, o Quadro 52 apresenta didaticamente o detalhamento de alguns passos essenciais para a materialização da rede de cuidados e  
de proteção social (intra ou intersetorial), cujos passos não necessariamente seguem uma hierarquia podendo acontecer de forma concomitante.  
**Quadro 52 – Estruturação da Rede Intrassetorial e Intersetorial**  
95  
|**PASSOS**|**ESTRUTURAÇÃO DA REDE INTRASSETORIAL E INTERSETORIAL**|
|---|---|
|**Diagnóstico da**<br>**situação**|Mapeamento de todos os serviços governamentais e não governamentais que atuam no cuidado integral, na promoção,<br>defesa e proteção dos direitos das pessoas no território, inclusive serviços de atendimento ao autor da agressão, bem<br>como os serviços regionalizados.|
||Identificação dos serviços que se constituem como “porta de entrada” ou, preferencialmente, como primeiro<br>atendimento para atenção integral às pessoas em situação de violências.|
||Caracterização dos serviços/instituições que realizam o atendimento das pessoas em situação de violências (composição<br>da equipe multiprofissional; existência de protocolos e fluxos de atendimento; articulação em rede intra e intersetorial;<br>tipo de atendimento prestado; endereço, telefones, e-mail, horário de atendimento, entre outros).|
|**Mobilização social e**<br>**_advocacy_**|Pactuação com a gestão local (distrital, municipal e estadual) que compõe a rede de cuidado e de proteção social a<br>priorização da atenção integral às pessoas em situação de violências.|
||Formalização por meio de atos normativos (leis, decretos, portarias, planos de ação, protocolo de intenção, carta<br>compromisso e outros).|
||Construção de alianças estratégicas com Conselhos Tutelares e de Direitos; CREA; CRAS; associações comunitárias;<br>meios de comunicação; Ministério Público, Segurança Pública; Poderes Legislativo e Judiciário, entre outros.|
|**Capacitação**<br>**permanente e**<br>**formação continuada**|Sensibilização e capacitação dos(as) profissionais de saúde dos três níveis de atenção em linha de cuidado, nas<br>dimensões do acolhimento, atendimento (diagnóstico, tratamento e cuidados), notificação e seguimento do caso na rede<br>de cuidado e de proteção social.|
||Articulação com os serviços de promoção, proteção e defesa dos direitos das pessoas em situação de violências para a<br>inclusão de conteúdo da atenção integral à saúde na formação continuada para profissionais e gestores(as).|
||Articulação com as instituições de ensino e pesquisa para a inserção do tema da prevenção de violências e a promoção<br>da cultura de paz nas disciplinas dos cursos de saúde, assistência social e educação, bem como nas pesquisas.|
|**Planejamento e**<br>**gestão**|Criação de grupo de gestão colegiada da rede de cuidado e de proteção social das pessoas em situação de violências e<br>suas famílias, para articular, mobilizar, planejar, acompanhar e avaliar as ações da rede.|
||Planejamento das ações e estratégias para atenção integral à saúde das pessoas em situação de violências, com base na<br>realidade local.|
||Elaboração de protocolos de acolhimento e atendimento humanizados (abordando os aspectos técnicos e éticos) para o<br>serviço de saúde e da rede intersetorial, definindo corresponsabilidades, áreas de abrangência, fluxos de atendimento e<br>seguimento para a rede e normativas específicas, podendo ser utilizados ou adaptados os protocolos existentes.|
||Adoção de estratégias de acompanhamento e apoio técnico e psicossocial às equipes de saúde que atendem às pessoas<br>envolvidas em situação de violência e estimular que a rede intersetorial também siga essas estratégias.|
||Implantação/implementação do sistema Vigilância de Violências e Acidentes no Sinan (Viva Contínuo).|
||Comunicação e divulgação à sociedade da relação de serviços com endereço completo e horários de atendimento às<br>pessoas em situação de violências (Guia de Serviços).|  
Fonte: Adaptado de Brasil (2010)<sup>321</sup> .  
Para melhor monitoramento dos serviços prestados às pessoas em situação de violências, o Ministério da Saúde criou, em 2014, o código 165  
de serviço especializado de Atenção às Pessoas em Situação de Violência Sexual no Sistema de Cadastro Nacional de Estabelecimentos de Saúde – SCNES<sup>322</sup> .  
Desse modo, os serviços de atenção à saúde passaram a informar a disponibilização de: Atenção Integral às Pessoas em Situação de Violência Sexual (001) – que pode ser organizada em hospitais gerais e maternidades, prontos-socorros, Unidades de Pronto- Atendimento (UPA) e no conjunto de serviços de urgência não hospitalares, pois devem atender 24 horas por dia, nos 7 dias da semana, e contar com equipe multiprofissional para o atendimento; Atenção Ambulatorial às Pessoas em Situação de Violência Sexual (007); e/ou Interrupção de Gravidez nos Casos Previstos em Lei (006).  
É de responsabilidade dos gestores locais cadastrar e atualizar seus estabelecimentos no SCNES. O Ministério da Saúde incentiva que todos os serviços que oferecem atendimento às pessoas em situação de violência sexual sejam cadastrados pelos gestores no sistema.  
Para acessar o SCNES e acessar os estabelecimentos cadastrados como referências no Brasil:  
1. Acessar o site http://cnes2.datasus.gov.br/;  
2. Clicar em Relatórios;  
3. Clicar em Serviços Especializados;  
4. Selecionar o Estado, o Município e a Competência (mês/ano) desejados;  
5. Em Serviço Especializado, selecionar 165 – Atenção às pessoas em situação de violência sexual;  
6. Em Classificação Serviço, podem ser selecionadas as divisões: 165-001 – Referência para atenção integral às pessoas em situação de violência sexual; 165-006 – Atenção à interrupção de gravidez nos casos previstos em lei; 165-007 – Atenção Ambulatorial em situação de violência sexual.  
96

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A notificação é obrigatória no caso de sífilis adquirida, sífilis em gestante, sífilis congênita, hepatites virais B e C, aids, infecção pelo HIV, infecção pelo HIV em gestante, parturiente ou puérpera e criança exposta ao risco de transmissão vertical do HIV. **As demais IST, caso se considere conveniente, podem ser incluídas na lista de notificação dos estados/DF/municípios.**  
A notificação compulsória nacional das IST se deu por meio de portarias, de maneira gradual, iniciando-se com a notificação de aids e sífilis congênita em 1986, conforme o Quadro 53.  
**Quadro 53 – Portarias que instituíram a notificação compulsória das IST no Brasil**  
|**AGRAVO**|**NOTIFICAÇÃO**<br>**INSTITUÍDA EM:**|**PORTARIA**|
|---|---|---|
|Aids|1986|Portaria nº 542, de 22 de dezembro de 1986|
|Sífilis congênita|1986|Portaria nº 542, de 22 de dezembro de 1986|
|Hepatite B|1998|Portaria nº 4.052, de 23 de dezembro de 1998|
|Hepatite C|1999|Portaria nº 1.461, de 22 de dezembro de 1999|
|HIV em gestante e criança exposta|2000|Portaria nº 993, de 4 de setembro de 2000|
|Hepatites virais (inclusão das hepatites A, D e<br>E)|2003|Portaria nº 2.325, de 8 de dezembro de 2003|
|Sífilis em gestantes|2005|Portaria nº 33, de 14 de julho de 2005|
|Sífilis adquirida|2010|Portaria nº 2.472, de 31 de agosto de 2010|
|HIV|2014|Portaria nº 1.271, de 6 de junho de 2014|  
Fonte: DCCI/SVS/MS.  
No Brasil, de acordo com a Portaria nº 1.271, de 6 de junho de 2014<sup>323</sup> , em seu artigo 3º, os profissionais de saúde no exercício da profissão, bem como os responsáveis por organizações e estabelecimentos públicos e particulares de saúde e ensino, em conformidade com a Lei nº 6.259, de 30 de outubro de 1975<sup>324</sup> , são obrigados a comunicar aos gestores do SUS a ocorrência de casos suspeitos ou confirmados de doenças de interesse nacional. O caráter compulsório da notificação implica responsabilidades formais para todo cidadão. É uma obrigação inerente ao exercício da medicina, bem como de outras profissões na área da saúde.  
A despeito dessa obrigação de notificação, vale lembrar que a subnotificação de casos no Sistema de Informação de Agravos de Notificação (Sinan) traz relevantes implicações para a resposta a IST no país, visto que permanecem desconhecidas informações importantes no âmbito da epidemiologia, tais como número total de casos, comportamentos e vulnerabilidades, entre outros. Além disso, a ausência de registro pode comprometer a racionalização do sistema para o fornecimento contínuo de medicamentos e as ações prioritárias para populações mais vulneráveis. Isso posto, reforça-se, portanto, a necessidade da notificação oportuna de todos os casos no Sinan, bem como a melhoria da qualidade do preenchimento da ficha de notificação e investigação de casos.  
Para tanto, também se faz necessário que a vigilância epidemiológica estabeleça normas técnicas capazes de uniformizar procedimentos e viabilizar a comparabilidade de dados e informações, além da Lista de Doença de Notificação Compulsória, da Ficha de Notificação Individual e do fluxo de informação. Essa padronização é realizada por meio da definição de caso de uma doença ou agravo, o que possibilita, assim, tornar comparáveis os critérios diagnósticos que regulam a entrada de caso no sistema.  
Cabe ressaltar que, com a finalidade de diminuir a subnotificação e de alinhar as recomendações da Organização Pan-Americana da Saúde, o Ministério da Saúde atualizou recentemente a definição de caso de sífilis adquirida, sífilis em gestante e sífilis congênita, conforme os Quadros 54, 55 e 56.  
**Quadro 54 – Critérios para definição de casos de sífilis congênita**  
|**SITUAÇÃO 1**|
|---|
|<br>Todo recém-nascido, natimorto ou aborto de mulher com sífilis<sup>a</sup>não tratada ou tratada de forma não adequada<sup>b,c</sup>|
|**SITUAÇÃO 2**<sup>**d**</sup>|  
97  
- Toda criança com menos de 13 anos de idade com pelo menos uma das seguintes situações:  
- Manifestação clínica, alteração liquórica ou radiológica de sífilis congênita E teste não treponêmico reagente;  
- Títulos de teste não treponêmicos do lactente maiores que os da mãe, em pelo menos 2 diluições de amostras de sangue periférico, coletadas simultaneamente no momento do parto;  
- `o` Títulos de testes não treponêmicos ascendentes em pelo menos 2 diluições no seguimento da criança exposta<sup>e</sup> ; `o` Títulos de testes não treponêmicos ainda reagentes após 6 meses de idade, exceto em situação de seguimento terapêutico; `o` Testes treponêmicos reagentes após 18 meses de idade, sem diagnóstico prévio de sífilis congênita. **SITUAÇÃO 3**  
- Evidência microbiológica<sup>f</sup> de infecção pelo _Treponema pallidum_ em amostra de secreção nasal ou lesão cutânea, biópsia ou necrópsia de criança, aborto ou natimorto.  
- Fonte: DCCI/SVS/MS.  
a Ver definição de sífilis em gestantes.  
> b Tratamento adequado: tratamento completo para estágio clínico de sífilis com benzilpenicilina benzatina, **iniciado** até 30 dias antes do parto. Gestantes que não se enquadrarem nesses critérios serão consideradas como tratadas de forma não adequada.  
c Para fins de definição de caso de sífilis congênita, não se considera o tratamento da parceria sexual da mãe.  
d Nessa situação, deve ser sempre afastada a possibilidade de sífilis adquirida em situação de violência sexual.  
e Seguimento da criança exposta: 1, 3, 6, 12 e 18 meses de idade.  
> f Detecção do _Treponema pallidum_ por meio de exames diretos por microscopia (de campo escuro ou com material corado). Nota: A parceria sexual da gestante com sífilis NÃO faz parte da definição de caso de sífilis congênita, em relação ao tratamento materno, se adequado ou não adequado. Todavia, o risco de reinfecção por sífilis deve ser acompanhado em todo o período do pré-natal. Assim, recomenda-se que todas as parcerias sexuais de mulheres grávidas com IST sejam avaliadas e tratadas, para evitar reinfecções nas gestantes que foram tratadas adequadamente, especialmente para a sífilis.  
**Quadro 55 – Critérios para definição de caso de sífilis em gestantes**  
|**SITUAÇÃO 1**|
|---|
|Mulher assintomática para sífilis que, durante o pré-natal, parto e/ou puerpério, apresente pelo menos um teste reagente – treponêmico E/OU<br>não treponêmico com qualquer titulação – e que não tenha registro de tratamento prévio.|
|**SITUAÇÃO 2**|
|Mulher sintomática<sup>a</sup>para sífilis que, durante o pré-natal, parto e/ou puerpério, apresente pelo menos um teste reagente – treponêmico E/OU<br>não treponêmico – com qualquer titulação.|
|**SITUAÇÃO 3**|
|<br>Mulher que, durante o pré-natal, parto e/ou puerpério, apresente teste não treponêmico reagente com qualquer titulação**E**teste<br>treponêmico reagente, independentemente de sintomatologia de sífilis e sem registro de tratamento prévio.|  
Fonte: DCCI/SVS/MS.  
a Para mais informações sobre sífilis, consultar o Guia de Vigilância em Saúde325 e os Capítulos 5 e 6 deste PCDT.  
Nota: todos os casos de mulheres diagnosticadas com sífilis durante o pré-natal, parto ou puerpério devem ser notificados na ficha de sífilis em gestantes. Casos confirmados de cicatriz sorológica não devem ser notificados. Considera-se cicatriz sorológica: tratamento anterior para sífilis com documentação da queda da titulação em pelo menos duas diluições (ex.: uma titulação de 1:16 antes do tratamento que se torna menor ou igual a 1:4 após o tratamento).  
**Quadro 56 – Critérios para definição de casos de sífilis adquirida**  
|**SITUAÇÃO 1**|
|---|
|<br>Indivíduo assintomático, com teste não treponêmico reagente com qualquer titulação e teste treponêmico reagente, sem registro de<br>tratamento prévio.|
|**SITUAÇÃO  2**|
|<br>Indivíduo sintomático<sup>a</sup>para sífilis, com pelo menos um teste reagente – treponêmico ou não treponêmico – com qualquer titulação.|  
Fonte: DCCI/SVS/MS.  
a Para mais informações sobre sífilis, consultar o Guia de Vigilância em Saúde325 e os Capítulos 5 e 6 deste PCDT.  
Nota: casos confirmados de cicatriz sorológica não devem ser notificados. Considera-se cicatriz sorológica: tratamento anterior para sífilis com documentação da queda da titulação em pelo menos duas diluições.  
É importante ressaltar que, nos últimos anos, tem-se observado um aumento constante no número de casos de sífilis em gestantes, sífilis congênita e sífilis adquirida. Esse aumento pode ser atribuído, em parte, à expansão da cobertura de testagem, com a ampliação do uso de testes rápidos e redução do uso de preservativo, levando em consideração, também, a resistência dos profissionais de saúde à administração da penicilina na Atenção Básica, o desabastecimento mundial de penicilina, entre outros. Além disso, o aprimoramento do sistema de vigilância pode refletir-se no aumento de casos notificados.  
98  
A Lista de Doenças de Notificação Compulsória vigente no país pode ser consultada na Portaria de Consolidação nº 2, de 28 de setembro de 2017<sup>326</sup> , que consolida as normas sobre as políticas nacionais de saúde do SUS. As Fichas de Notificação Individual de cada agravo e o fluxo de informação estão disponíveis na página do Sinan por meio do link: <u>http://portalsinan.saude.gov.br/. As informações e orientações</u> completas relativas à vigilância desses agravos encontram-se no Guia de Vigilância em Saúde<sup>325</sup> , e os dados epidemiológicos referentes ao HIV/aids, hepatites virais e sífilis são publicados periodicamente nos Boletins Epidemiológicos específicos (disponíveis em <u>http://www.aids.gov.br).</u>  
99

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
1. ECDC. Gonococcal antimicrobial susceptibility surveillance in Europe, 2016 [Internet]. European Centre for Disease Preventaion and Control. Stockholm: ECDC; 2018. Available from: https://www.ecdc.europa.eu/sites/default/files/documents/EURO-GASPreport-2016.pdf 2. Coleman E. What is sexual health? Articulating a sexual health approach to HIV prevention for men who have sex with men. AIDS Behav. 2011;15(SUPPL. 1):18–24. 3. WHO. Education and treatment in human sexuality: the training of health professionals. Report of a WHO meeting. Vol. no. 572, World Health Organization - Technical Report Series. Geneva; 1975. 4. WHO. Defining sexual health: Report of a technical consultation on sexual health 28–31 January 2002 [Internet]. World Health Organization - WHO publications. Geneva; 2006. Available from: https://www.who.int/reproductivehealth/publications/sexual_health/defining_sexual_health.pdf 5. Brasil M da S. Saúde Sexual e Reprodutiva. Vol. 2. Brasília: Ministério da Saúde; 2010. 187 p. 6. Wi TE. How talking about sex could end STIs. [Internet]. Youtube; 2017. Available from: https://www.youtube.com/ watch?v=TRGZcNMR24o 7. Hickson F. What is the point of HIV prevention? In: Plenary address at Australian Federation of AIDS Organisations’ HIV Educators Conference [Internet]. Sydney: Australia; 2010. Available from: https://pt.slideshare.net/AFAO/whats-the-point-of-hiv-prevention 8. Brasil M da S. Prevenção Combinada do HIV. Vol. 1, Secretaria de Vigilância em Saúde do Ministério da Saúde. Brasília: MInistério da Saúde; 2017. 28 p. 9. Brasil M da S. Protocolo e Diretrizes para Profilaxia Pós-Exposição (PEP) de Risco à Infecção pelo HIV, IST e Hepatites Virais [Internet]. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Brasília: Ministério da Saúde; 2018. 98 p. Available from: http://www.aids.gov.br/pt-br/pub/2015/protocolo-clinico-e-diretrizes-terapeuticaspara-profilaxia-pos-exposicao-pep-de-risco 10. Brasil M da S. Protocolo Clínico e Diretrizes Terpêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV [Internet]. Vol. 1, Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. Brasília: Ministério da Saúde; 2018. 56 p. Available from: http://www.aids.gov.br/publicacao/2017/protocolo-clinico-e-diretrizes-terapeuticas-para-profilaxia-pre-exposicao-prep-de-ri 11. Brasil M da S. Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais [Internet]. Brasília: Ministério da Saúde; 2019. 248 p. Available from: http://www.aids.gov.br/pt-br/pub/2015/protocolo-clinico-ediretrizes-terapeuticas-para-prevencao-da-transmissao-vertical-de-hiv 12. Brasil M do PO e G. Pesquisa Ncional de Saúde do Escolar 2015. Instituto Brasileiro de Geografia e Estatística - IBGE. Rio de Janeiro: IBGE; 2016. 132 p. 13. OPAS M. Saúde e Sexualidade de Adolescentes. Construindo equidade no SUS [Internet]. Brasília: OPAS,MS; 2017. 71 p. Available from: http://portalarquivos.saude.gov.br/images/PDF/2017/maio/05/LIVRO-SAUDE-ADOLESCENTES.PDF 14. Gates TJ. Screening for cancer: Evaluating the evidence. Am Fam Physician. 2001;63(3):513–22. 15. Wilson J, Jungner G. Principles and practice of screening for disease. Geneva, Switzerland: Wold Health Organization; 1968;34. Public health papers No 34. Geneva: World Health Organization; 1968. 168 p. 16. Gérvas J, Fernández MP. Uso y abuso del poder médico para definir enfermedad y factor de riesgo, en relación con la prevención cuaternaria (Limits to the power of medicine to define disease and risk factor, and quarternary prevention). Gac Sanit [Internet]. 2006;20(SUPPL. 3):66–71. Available from: http://dx.doi.org/10.1157/13101092 17. Cantor AG, Pappas M, Daeges M, Nelson HD. Screening for syphilis: Updated evidence report and systematic review for the US preventive services task force. JAMA - J Am Med Assoc. 2016;315(21):2328–37. 18. Jalkh AP, Miranda AE, Hurtado-Guerreiro JC, Ramos LAC, Figliuolo G, Maia J, et al. Chlamydia trachomatis in human immunodeficiency virus-infected men treated at a referral hospital for sexually transmitted diseases in the Amazonas, Brazil. Brazilian J Infect Dis [Internet]. 2014;18(2):158–63. Available from: http://dx.doi.org/10.1016/j.bjid.2013.06.007 19. Brasil M de S. Boltem Epidemiológico Sífilis 2017. Brasília: Ministério da Saúde; 2017. p. 44. 20. Brasil M da S. Informe técnico da ampliação da oferta das vacinas papilomavírus humano 6, 11, 16 e 18 (recombinante) – vacina HPV quadrivalente e meningocócica C (conjugada). Ministério da Saúde [Internet]. 2018;18:1–39. Available from: http://portalarquivos2.saude.gov.br/images/pdf/2018/marco/14/Informe-T--cnico-HPV-MENINGITE.pdf 21. Brasil M da S, Câncer IN do. Diretrizes Brasileiras para o rastreamento Do Câncer Do Colo Do Útero [Internet]. Vol. XXXIII, Ministério da Saúde. Rio de Janeiro: INCA; 2016. 81–87 p. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/inca/rastreamento_cancer_colo_utero.pdf 22. Brasil M da S. Boletim Epidemiológico Hepatites virais 2019. Brasília: Ministério da SAúde; 2019. 23. Werber D, Michaelis K, Hausner M, Sissolak D, Wenzel J, Bitzegeio J, et al. Ongoing outbreaks of hepatitis a among men who have sex with men (MSM), Berlin, November 2016 to January 2017 – Linked to other German cities and European countries. Eurosurveillance. 2017;22(5):30457. 24. Freidl GS, Sonder GJ, Bovée LP, Friesema IH, van Rijckevorsel GG, Ruijs WL, et al. Hepatitis a outbreak among men who have sex with men (MSM) predominantly linked with the EuroPride, the Netherlands, July 2016 to February 2017. Eurosurveillance. 2017;22(8):30468. 25. Chen G-J, Lin K-Y, Sun H-Y, Sheng W-H, Hsieh S-M, Huang Y-C, et al. Incidence of acute hepatites A among HIV-positive patients during an outbreak among MSM in Taiwan: impact of HAV vaccination. Liver Int. 2018;38(1):594–601. 26. Beebeejaun K, Degala S, Balogun K, Simms I, Woodhall SC, Heinsbroek E, et al. Outbreak of hepatitis A associated with men who have sex with men (MSM), England, July 2016 to January 2017. Eurosurveillance. 2017;22(5):30454. 27. Brasil M da S. Manual dos Centros de Referência para Imunobiológicos Especiais. 4 ed. Brasília: Ministério da Saúde; 2014. 188 p. 28. Brasil M da S. Nota Informativa n<sup>o</sup> 10 /2018-COVIG/CGVP/DCCI/SVS/MS, de 7 de junho de 2018. Ampliação da indicação do uso da vacina Hepatite A para gays e homens que fazem sexo com homens (HSH) e que tenham prática sexual com contato oral-anal. Brasília: Ministério da Saúde; 2018.  
29. Negreiros TC de GM. Sexualidade e gênero no envelhecimento. ALCEU. 2004;5(9):77–86. 30. Clutterbuck DJ, Flowers P, Barber T, Wilson H, Nelson M, Hedge B, et al. UK national guideline on safer sex advice. Int J STD AIDS. 2012;23(6):381–8. 31. Nusbaum MRH, Hamilton CD. The proactive sexual health history. Am Fam Physician. 2002;66(9):1705–12. 32. Carrió FB. Entrevista Clínica: habilidades de comunicação para profissionais de saúde. 1 ed. Porto Alegre: Artmed; 2012. 348 p.  
100  
33. Workowski KA, Bolan GA. Sexually transmitted diseases treatment guidelines, 2015. Vol. 64, MMWR Recommendations and Reports. 2015. 34. WHO. Sexually transmitted and other reproductive tract infections: a guide to essential practice [Internet]. World Health Organization. Reproducyive Health and Research. Geneva; 2005. Available from: http://whqlibdoc.who.int/publications/2005/9241592656.pdf?ua=1 35. Alirol E, Wi TE, Bala M, Bazzo ML, Chen XS, Deal C, et al. Multidrug-resistant gonorrhea: A research and development roadmap to discover new medicines. PLoS Med [Internet]. 2017;14(7):e1002366. Available from: https://journals.plos.org/plosmedicine/article?id=10.1371/journal.pmed.1002366 36. Kahler CM. Multidrug-resistant Neisseria gonorrhoeae: Future therapeutic options. Future Microbiol. 2018;13(5):499–501. 37. Tacconelli E, Carrara E, Savoldi A, Harbarth S, Mendelson M, Monnet DL, et al. Discovery, research, and development of new antibiotics: the WHO priority list of antibiotic-resistant bacteria and tuberculosis. Lancet Infect Dis. 2018;18(3):318–27. 38. Bazzo ML, Golfetto L, Gaspar PC, Pires AF, Ramos MC, Franchini M, et al. First nationwide antimicrobial susceptibility surveillance for Neisseria gonorrhoeae in Brazil, 2015-16. J Antimicrob Chemother. 2018;73(7):1854–61. 39. Jenness SM, Weiss KM, Goodreau SM, Gift T, Chesson H, Hoover KW, et al. Incidence of gonorrhea and chlamydia following human immunodeficiency virus preexposure prophylaxis among men who have sex with men: A modeling study. Clin Infect Dis. 2017;65(5):712–8. 40. Rolfs RT, Joesoef MR, Hendershot EF, Rompalo AM, Augenbraun MH, Chiu M, et al. A Randomized Trial of Enhanced Therapy for Early Syphilis in Patients with and without Human Immunodeficiency Virus Infection. N Engl J Med. 1997;337(5):307–14. 41. Peeling RW, Mabey D, Kamb ML, Chen XS, Radolf JD, Benzaken AS. Syphilis. Nat Rev Dis Prim. 2017;3:17073. 42. Gomez GB, Kamb ML, Newman LM, Mark J, Broutet N, Hawkes SJ. Untreated maternal syphilis and adverse outcomes of pregnancy: a systematic review and meta-analysis. Bull World Health Organ. 2013;91(3):217–26. 43. Brasil M da S. Manual de Controle das Doenças Sexualmente Transmissíveis. 4th ed. Secretaria de Vigilância em Saúde. Programa Nacional de DST e Aids. Série Manuais, No 68. Brasília: Ministério da Saúde; 2006. 140 p. 44. Brasil M da S. Relação Nacional de Medicamentos Essenciais: RENAME 2017 [Internet]. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Assistência Farmacêutica e Insumos Estratégicos. Brasília: Ministério da Saúde; 2017. 210 p. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/1998/prt3916_30_10_1998.html%0Ahttp://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prt243 6_22_09_2017.html 45. COFEN. Parecer n<sup>o</sup> 09/2016/CTAS/COFEN, de 6 de maio de 2016. Solicitação de parecer sobre a administração de medicamentos por via IM em pacientes que usam prótese de silicone. [Internet]. Brasília; 2016. Available from: http://www.cofen.gov.br/parecer-no-092016ctascofen_42147.html 46. Ghanem KG, Ram S, Rice PA. The Modern Epidemic of Syphilis. N Engl J Med. 2020;382(9):845–54. 47. WHO. Guidelines for the treatment of Treponema pallidum (syphilis). World Health Organization - WHO publications. Geneva: WHO; 2016. 60 p. 48. Seña AC, Wolff M, Behets F, Martin DH, Leone P, Langley C, et al. Rate of decline in nontreponemal antibody titers and seroreversion after treatment of early syphilis. Sex Transm Dis. 2017;44(1):7–11. 49. Butler T. The Jarisch-Herxheimer reaction after antibiotic treatment of spirochetal infections: A review of recent cases and our understanding of pathogenesis. Am J Trop Med Hyg. 2017;96(1):46–52. 50. Brasil M da S. Penicilina benzatina para prevenção da sífilis congênita durante a gravidez. Relatório de recomendação n. 150 [Internet]. CONITEC - Comissão Nacional de Incorporação de Tecnologias no SUS. Brasília; 2015. Available from: http://conitec.gov.br/images/Relatorios/2015/Relatorio_Penicilina_SifilisCongenita_final.pdf 51. Brasil M da S. Acolhimento à demanda espontânea: queixas mais comuns na Atenção Básica. Cadernos de Atenção Básica, n. 28, v. II. 1st ed. Vol. II, Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Brasília: Ministério da Saúde; 2013. 290 p. 52. COFEN. Decisão cofen n<sup>o</sup> 0094/2015, de 8 de julho de 2015. Revoga o parecer de conselheiro 008/2014. PAD COFEN 032/2012. Administração de penicilina pelos profissionais de enfermagem [Internet]. Brasília: COFEN; 2015. Available from: http://www.cofen.gov.br/decisao-cofen-no-00942015_32935.html 53. COFEN. Nota-Técnica- COFEN/CTLN - N° 03/2017, de 14 de junho de 2017. Esclarecimento aos profissionais de enfermagem sobre a importância da administração da penicilina benzatina nas unidades básicas de saúde (UBS) do Sistema Único de Saúde (SUS) [Internet]. Brasília: COFEN; 2017. Available from: http://www.cofen.gov.br/wp-content/uploads/2017/06/NOTA-TÉCNICA-COFENCTLN-N°-03-2017.pdf 54. Shenoy ES, Macy E, Rowe T, Blumenthal KG. Evaluation and management of penicillin allergy: a review. JAMA - J Am Med Assoc. 2019;321(2):188–99. 55. Galvao TF, Silva MT, Serruya SJ, Newman LM, Klausner JD, Pereira MG, et al. Safety of benzathine penicillin for preventing congenital syphilis: a systematic review. PLoS One. 2013;8(2):e56463. 56. Brown ST, Zaidi A, Larsen SA, Reynolds GH. Serological response to syphilis tratment: a new analysis of old data. JAMA. 1985;253(9):1296–9. 57. Seña AC, Zhang XH, Li T, Zheng HP, Yang B, Yang LG, et al. A systematic review of syphilis serological treatment outcomes in HIV-infected and HIV-uninfected persons: Rethinking the significance of serological non-responsiveness and the serofast state after therapy. BMC Infect Dis. 2015;15(1):479. 58. Romanowski B, Sutherland R, Fick GH, Mooney D, Love EJ. Serologic response to treatment of infectious syphilis. Ann Intern Med. 1991;114(12):1005–9. 59. Tong ML, Lin LR, Liu GL, Zhang HL, Zeng YL, Zheng WH, et al. Factors associated with serological cure and the serofast state of HIV-negative patients with primary, secondary, latent, and tertiary syphilis. PLoS One. 2013;8(7):e70102. 60. Clement ME, Okeke NL, Hicks CB. Treatment of syphilis: a systematic review. JAMA - J Am Med Assoc. 2014;312(18):1905– 17. 61. Zhang RL, Wang QQ, Zhang JP, Yang LJ. Molecular subtyping of Treponema pallidum and associated factors of serofast status in early syphilis patients: Identified novel genotype and cytokine marker. PLoS One. 2017;12(4):e0175477. 62. Tuddenham S, Ghanem KG. Neurosyphilis: knowledge gaps and controversies. Sex Transm Dis. 2018;45(3):147–51. 63. Musher DM. Editorial commentary: polymerase chain reaction for the tpp47 gene: a new test for neurosyphilis. Clin Infect Dis. 2016;63(9):1187–8. 64. Marra CM. Neurosyphilis. Continuum (N Y) [Internet]. 2015;21(6):1714–28. Available from: https://journals.lww.com/continuum/Abstract/2015/12000/Neurosyphilis.17.aspx 65. Hall BG, Barlow M. Evolution of the serine beta-lactamases: past, present and future. Drug Resist Uptades [Internet]. 2004;7(2):111–23. Available from: https://pubmed.ncbi.nlm.nih.gov/15158767/  
101  
66. Marra CM, Tantalo LC, Maxwell CL, Ho EL, Sahi SK, Jones T. The rapid plasma reagin test cannot replace the venereal disease research laboratory test for neurosyphilis diagnosis. Sex Transm Dis. 2012;39(6):453–7. 67. Marra CM, Maxwell CL, Dunaway SB, Sahi SK, Tantalo LC. Cerebrospinal fluid Treponema pallidum particle agglutination assay for neurosyphilis diagnosis. J Clin Microbiol. 2017;55(6):1865–70. 68. Chesney AM, Kemp JE. Incidence of Spirochaeta pallida incerebrospinal fluid during early stage of syphilis. JAMA. 1924;83(22):1725–8. 69. Madiedo G, Ho K-C, Walsh P. False -positive VDRL and FTA in cerebrospinal fluid. JAMA. 1980;244(7):688–9. 70. Lukehart SA, Hook EW, Baker-Zander SA, Collier AC, Critchlow CW, Handsfield HH. Invasion of the central nervous system by Treponema pallidum: implications for diagnosis and treatment. Ann Intern Med. 1988;109(11):855–62. 71. Ho EL, Tantalo LC, Jones T, Sahi SK, Marra CM. Point-of-care treponemal tests for neurosyphilis diagnosis. Sex Transm Dis. 2015;42(1):48–52. 72. Levchik N, Ponomareva M, Surganova V, Zilberberg N, Kungurov N. Criteria for the diagnosis of neurosyphilis in cerebrospinal fluid: Relationships with intrathecal immunoglobulin synthesis and blood-cerebrospinal fluid barrier dysfunction. Sex Transm Dis. 2013;40(12):917–22. 73. Harding AS, Ghanem KG. The performance of cerebrospinal fluid treponemal-specific antibody tests in neurosyphilis: A systematic review. Sex Transm Dis. 2012;39(4):291–7. 74. Marra CM, Critchlow CW, HOOK III EW, Collier AC, Lukehart SA. Cerebrospinal fluid treponemal antibodies in untreated early syphilis. Arch Neurol. 1995;52(1):68–72. 75. Merrit HH, Adams RO, Solomon HC. Neurosyphilis. New York: Oxford University Press; 1946. 443 p. 76. Hooshmand H, Escobar MR, Kopf SW. Neurosyphilis: a study os 241 patients. JAMA. 1972;219(6):726–9. 77. Marra CM, Maxwell CL, Tantalo LC, Sahi SK, Lukehart SA. Normalization of serum rapid plasma reagin titer predicts normalization of cerebrospinal fluid and clinical abnormalities after treatment of neurosyphilis. Clin Infect Dis. 2008;47(7):893–9. 78. Brasil M da S. Guia do pré-natal do parceiro para profissionais de saúde. 1st ed. Secretaria de Atenção à Saúde. Departamento de Ações Programáticas Estratégicas. Coordenação Nacional de Saúde do Homem. Rio de Janeiro: Ministério da Saúde; 2016. 55 p. 79. Kalichman SC, Pellowski J, Turner C. Prevalence of sexually transmitted co-infections in people living with HIV/AIDS: systematic review with implications for using HIV treatments for prevention. Sex Transm Infect. 2011;87(3):183–90. 80. Boily MC, Bastos FI, Desai K, Mâsse B. Changes in the transmission dynamics of the HIV epidemic after the wide-scale use of antiretroviral therapy could explain increases in sexually transmitted infections: results from mathematical models. Sex Transm Dis. 2004;31(2):100–12. 81. He H, Wang M, Zaller N, Wang J, Song D, Qu Y, et al. Prevalence of syphilis infection and associations with sexual risk behaviours among HIV-positive men who have sex with men in Shanghai, China. Int J STD AIDS. 2014;25(6):410–9. 82. Callegari FM, Pinto-Neto LF, Medeiros CJ, Scopel CB, Page K, Miranda AE. Syphilis and HIV co-infection in patients who attend an AIDS outpatient clinic in Vitoria, Brazil. AIDS Behav. 2014;18(Suppl. 1):S104–9. 83. Huang YF, Nelson KE, Lin YT, Yang CH, Chang FY, Lew-Ting CY. Syphilis among men who have sex with men (MSM) in Taiwan: Its association with HIV prevalence, awareness of HIV status, and use of antiretroviral therapy. AIDS Behav. 2013;17(4):1406–14. 84. Cohen MS. When people with HIV get syphilis: triple jeopardy. Sex Transm Dis. 2006;33(3):149–50. 85. Bowen V, Su J, Torrone E, Kidd S, Weinstock H. Increase in incidence of congenital syphilis, United States, 2012-2014. MMWR. 2015;64(44):1241–5. 86. Cresswell F V., Fisher M. Management of syphilis in HIV-positive individuals. Sex Health. 2015;12(2):135–40. 87. Marra CM, Maxwell CL, Smith SL, Lukehart SA, Rompalo AM, Eaton M, et al. Cerebrospinal fluid abnormalities in patients with syphilis: association with clinical and laboratory features. J Infect Dis. 2004;189(3):369–76. 88. Marra CM, Maxwell CL, Tantalo L, Eaton M, Rompalo AM, Raines C, et al. Normalization of cerebrospinal fluid abnormalities after neurosyphilis therapy: does HIV status matter? Clin Infect Dis. 2004;38(7):1001–6. 89. Libois A, De Wit S, Poll B, Garcia F, Florence E, Del Rio A, et al. HIV and syphilis: When to perform a lumbar puncture. Sex Transm Dis. 2007;34(3):141–4. 90. Ghanem KG, Moore RD, Rompalo AM, Erbelding EJ, Zenilman JM, Gebo KA. Lumbar puncture in HIV-infected patients with syphilis and no neurologic symptoms. Clin Infect Dis. 2009;48(6):816–21. 91. Brasil M da S. Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em adultos. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. Brasília: Ministério; 2018. 412 p. 92. WHO. Global guidance on criteria and processes for validation: elimination of mother-to-child transmission of HIV and syphilis monitoring. Vol. 143, World Health Organization Library Cataloguing-in-Publication Data. Genova: WHO; 2014. 155–156 p. 93. Grimprel E, Sanchez PJ, Wendel GD, Burstain JM, McCracken GH, Radolf JD, et al. Use of polymerase chain reaction and rabbit infectivity testing to detect Treponema pallidum in amniotic fluid, fetal and neonatal sera, and cerebrospinal fluid. J Clin Microbiol. 1991;29(8):1711–8. 94. Nathan L, Twickler DM, Peters MT, Sánchez PJ, Wendel GD. Fetal syphilis: correlation of sonographic findings and rabbit infectivity testing of amniotic fluid. Obstet Gynecol Surv. 1993;12(2):97–101. 95. Qureshi F, Jacques SM, Reyes MP. Placental histopathology in syphilis. Hum Pathol. 1993;24(7):779–84. 96. Reyes MP, Hunt N, Ostrea EM, George D. Maternal/congenital syphilis in a large tertiary-care urban hospital. Clin Infect Dis. 1993;17(6):1041–6. 97. Caddy SC, Lee BE, Sutherland K, Robinson JL, Plitt SS, Read R, et al. Pregnancy and neonatal outcomes of women with reactive syphilis serology in Alberta, 2002 to 2006. J Obstet Gynaecol Canada [Internet]. 2011;33(5):453–9. Available from: http://dx.doi.org/10.1016/S1701-2163(16)34878-2 98. Lago EG, Vaccari A, Fiori RM. Clinical features and follow-up of congenital syphilis. Sex Transm Dis. 2013;40(2):85–94. 99. CDC. Congenital syphilis - United States 2003-2008. MMWR. 1999;48(34):757–61. 100. Berman SM. Maternal syphilis: pathophysiology and treatment. Bull World Health Organ. 2004;82(6):433–8. 101. Blencowe H, Cousens S, Kamb M, Berman S, Lawn JE. Lives saved tool supplement detection and treatment of syphilis in pregnancy to reduce syphilis related stillbirths and neonatal mortality. BMC Public Health [Internet]. 2011;11(Suppl. 3):S9. Available from: http://www.biomedcentral.com/1471-2458/11/S3/S9 102. WHO. Investment case for eliminating mother-to-child transmission of syphilis: Promoting better maternal and child health and stronger health systems. Geneva: WHO; 2012. 40 p. 103. Woods CR. Congenital syphilis-persisting pestilence. Pediatr Infect Dis J. 2009;28(6):536–7. 104. Brasil M da S. NOTA INFORMATIVA No2 SEI 2017 DIAHV/SVS/MS: Altera os Critérios de Definição de Casos para  
102  
|notificaçã<br>105.<br>|o de Sífilis Adquirida, Sífilis em Gestantes e Sífilis Congênita. SEI 0882971 Nota informativa. Brasília: Ministério da Saúde; 2017.<br>Rawstron SA, Mehta S, Marcellino L, Rempel J, Chery F, Bromberg K. Congenital syphilis and fluorescent treponemal antibody<br>i f h  f 1  S T Di 20012874126|
|---|---|
|teste react<br>106.|vty ater te age o  year. ex ransm s. ;():–.<br>Morshed MG, Singhb AE. Recent trends in the serologic diagnosis of syphilis. Clin Vaccine Immunol. 2015;22(2):137–43.|
|107.<br>Canadian|<br>Singh AE, Guenette T, Gratrix J, Bergman J, Parker P, Anderson B, et al. Seroreversion of treponemal tests in infants meeting<br>surveillance criteria for confirmed early congenital syphilis. Pediatr Infect Dis J. 2013;32(3):199–202.|
|108|Hardy JB Hardy PH Oppenheimer EH Ryan SJ Sheff RN Failure of penicillin in a newborn with congenital syphilis JAMA J|
|.<br>Am Med|,  ,  ,  ,  .         .<br>Assoc. 1970;212(8):1345–9.|
|109.|Chang SN, Chung KY, Lee MG, Lee JB. Seroreversion of the serological tests for syphilis in the newborns born to treated|
|syphilitic|mothers. Genitourin Med. 1995;71(2):68–70.|
|<br>110.<br>World He<br>www.who|<br>WHO. Diagnóstico laboratorial de doenças sexualmente transmissíveis, incluindo o vírus da imunodeficiência humana [Internet].<br>alth Organization. Brasília: Organização Mundial da Saúde/Ministério da Saúde; 2013. 270 p. Available from:<br>.int/reproductivehealth|
|<br>111.<br>Saúde; 20|<br>Brasil M da S. Saúde da criança: crescimento e desenvolvimento. Cadernos de Atenção Básica, n. 33. Brasília: Ministério da<br>12. 272 p.|
|112|Ortiz-Lopez N Diez M Diaz O Simon F Diaz A Epidemiological surveillance of congenital syphilis in Spain 2000-2010|
|.<br>Pediatr Inf|,  ,  ,  ,  .       , .<br>ect Dis J. 2012;31(9):988–90.|
|113.<br>Microbiol|Herremans T, Kortbeek L, Notermans DW. A review of diagnostic tests for congenital syphilis in newborns. Eur J Clin<br>Infect Dis. 2010;29(5):495–501.|
|<br>114.|<br>Woods CR. Syphilis in children: congenital and acquired. Semin Pediatr Infect Dis. 2005;16(4):245–57.|
|115.<br>Practice of|Rawstron SA, Hawkes SJ. Treponema pallidum (Syphilis). In: Long SS, Pickering LK, Prober CG, editors. Principles and<br>Pediatric Infectious Diseases. 4th ed. Edinburgh: Elsevier Saunders; 2012. p. 941.|
|116.|Kollman TR, Dobson S. Syphilis. In: Remington JS, Klein JO, Wilson CB, Nizet V, Maldonado YA, editors. Remington and|
|Kleins´s In|fectiouis Diseases of the Fetus and Newborn Infant. 7th ed. Philadelphia: Elsevier Saunders; 2010. p. 537–63.|
|<br>117.<br>Gynecol. 2|<br>Hollier LM, Harstad TW, Sanchez PJ, Twickler DM, Wendel GD. Fetal syphilis: clinical and laboratory characteristics. Obstet<br>001;97(6):947–53.|
|118.<br>|Shah MS, Barton LL. Congenital syphilitic hepatitis. Pediatr Infect Dis J. 1989;8(12):891–2.<br>|
|119.|Chakraborty R, Luck S. Syphilis is on the increase: the implications for child health. Arch Dis Child. 2008;93(2):105–9.|
|120|Dobson SR Sanchez PJ Syphilis In: Cherry JD Demmler-Harrison GJ Kaplan SL Steinbach WJ Hotez PJ editors Feigin and|
|.<br>Cherr´s|,  . .   ,  ,  ,  ,  , .<br>extbook of Pediatric Infectious Diseases 7th ed Philadelhia: Elsevier Saunders 2014  1761|
|y<br>121.|.  . p  ; . p. .<br>Ingall D, Sanchez PJ, Baker CH. Syphilis. In: Remington J, Klein J, Baker C, Wilson C, editors. Remington and Kleins´s|
|Infectiouis<br>|Diseases of the Fetus and Newborn Infant. 6th ed. Philadelphia: Elsevier Saunders; 2006.<br>|
|122.<br>Pediatric I|Rawstron SA. Treponema pallidum (Syphilis). In: Long SS, Pickering LK, Prober CG, editors. Principles and Practice of<br>nfectious Diseases. 3rd ed. Philadelphia: Saunders; 2008. p. 930.|
|123|Robinson JL Conenital shilis: No loner just of historical interest Paediatr Child Health (Oxford) 2009;14(5):337|
|.<br>124.|. g yp  g    .    . .<br>Saloojee H, Velaphi S, Goga Y, Afadapa N, Steen R, Lincetto O. The prevention and management of congenital syphilis: An|
|overview<br>125|and recommendations. Bull World Health Organ. 2004;82(6):424–30.<br>MiSil SF Pbihi PA Di CF Júi ANA Dli LG Fh DO Al ó  l  ífili|
|.<br>|orera-va , reanc , as , nor , av , rauces . terações sseas em actantes com ss<br>|
|congênita.|DST- J .bras Doenças Sex Transm. 2009;21(4):175–8.|
|126.|Putkonen T. Does early treatment prevent dental changes in congenital syphilis? Acta Derm Venerol. 1963;43:240–9.|
|<br>127.|<br>Stamos JK, Rowley AH. Timely diagnosis of congenital infections. Pediatr Clin North Am. 1994;41(5):1017–33.|
|128.|Oksala A. Interstitial keratitis after adequate penicillin therapy; a case report. Br J Vener Dis. 1957;33(2):113–4.|
|<br>129.<br>Vener Dis|<br>Rodin P. Clutton’s joints: a brief review of the literature, and an unusual case treated with intra-articular hydrocortisone. Br J<br>. 1961;37(3):204–6.|
|130|Karmod CS Schuknecht HF Deafness in Conenital Shilis Arch Otolarnol 1966;83(1):18–27|
|.<br>131.|y ,  .   g yp.  yg. .<br>Platou R V. Treatment of congenital syphilis with penicilin. Adv Pediatr. 1949;4:39–86.|
|132|Michelow IC Wendel GD Norard M V Zera F Leos NK Alsaadi R et al Central nervous sstem infection in conenital|
|.<br>syphilis. N|,  , g  ., y ,  ,  ,  .   y   g<br>Engl J Med. 2002;346(23):1792–8.|
|133.<br>congenital|Beeram MR, Chopde N, Dawood Y, Siriboe S, Abedin M. Lumbar puncture in the evaluation of possible asymptomatic<br>syphilis in neonates J Pediatr 1996;128(1):125–9|
|<br>134.|.  . .<br>Volpe JJ. Neurology of the newborn. 5th ed. Philadelphia: Saunders; 2008. 1120 p.|
|135.|Walker GJA Walker D Franco DM Grillo-Ardila CF. Antibiotic treatment for newborns with congenital syphilis. Cochrane|
|<br>Database|,  ,  ,<br>st Rev 20192(2):CD012071|
|<br>136.<br>penicillin|y . ;.<br>Paryani SG, Vaughh AJ, Crosby M, Lawrence S. Treatment of asymptomatic congenital syphilis: benzathine versus procaine<br>G therapy. J Pediatr. 1994;125(3):471–5.|
|<br>137.<br>randomise|<br>Radcliffe M, Meyer M, Roditi D, Malan A. Single-dose benzathine penicilin in infants at risk of congenital syphilis - results of a<br>d study. S Afr Med J. 1997;87(1):62–5.|
|138|Azimi PH Janner D Berne P Fulroth R Lvoff V Franklin L et al Concentrations of procaine and aqueous penicillin in the|
|.<br>cerebrospi<br>https://pub|,  ,  ,  ,  ,  ,  .<br>nal fluid of infants treated for congenital syphilis. J Pediatr [Internet]. 1994;124(4):649–53. Available from:<br>med.ncbi.nlm.nih.gov/8151486/|
|139.|Brasil M da S. Portaria n<sup>o</sup>3.502 de 19 de dezembro de 2017. Institui no âmbito do Sistema Único de Saúde - SUS a Estratégia|
|<br>de fortalec<br>e out. Vol.|,       ,         ,<br>imento das ações de cuidado das crianças suspeitas ou confirmadas para Síndrome Congênita associada à infecção pelo vírus Zika<br>1, Diário Oficial da União. Brasília: Ministério da Saúde; 2017. p. 4–125.|
|140.|Brasil M da S. Orientações integradas de vigilância e atenção à saúde no âmbito da emergência de saúde pública de importância|
|nacional [|<br>nternet] Secretaria de Vigilância em Saúde Secretaria de Atenção à Saúde Brasília: Ministério da Saúde; 2017 158 p Available|
|<br>from: http|.     .     .     .  .<br>://portalarquivos.saude.gov.br/images/pdf/2016/dezembro/12/orientacoes-integradas-vigilancia-atencao.pdf|
|141.|Bastos LM, Passos MRL, Tibúrcio AS, Varella RQ, Pinheiro VMS. Gestantes atendidas no setor de doenças sexualmente|
|transmissí<br>htt//|<br>veis da Universidade Federal Fluminense. DST- J .bras Doenças Sex Transm [Internet]. 2000;12(2):5–12. Available from:<br>dtffb/|
|p:ww<br>142.|.s.u.r<br>Menezes MLB. Prevalência de infecções cérvico-vaginais e validação do fluxograma de corrimento vaginal em gestantes.|
|Universid|<br>ade Estadual de Campinas; 2003.|
|<br>143.|<br>Passos MRL, Appolinário MAO, Varella RQ. Atendimento de gestantes numa clínica de DST. DST- J .bras Doenças Sex|
|Transm. 2|003;15(1):23–9.|  
103  
144. Behets FM, Ward E, Fox L, Reed R, Spruyt A, Bennet L, et al. Sexually transmitted diseases are common in women attending Jamaican family planning clinics and appropriate detection tools are lacking. Sex Transm Infect. 1998;74(Suppl 1):S123–7. 145. Daly CC, Wangel AM, Hoffman IF. Validation of the WHO diagnostic algorithm and development of an alternative scoring system for management of women presenting with vaginal discharge in Malawi. Sex Transm Infect. 1998;74(Supl 1):S50–8. 146. Diallo MO, Ghys PD, Vuylsteke B, Ettiègne-Traoré V, Gnaoré E, Soroh D, et al. Evaluation of simple diagnostic algorithms for Neisseria gonorrhoeae and Chlamydia trachomatis cervical infections in female sex workers in Abidjan, Cote d’Ivoire. Sex Transm Infect [Internet]. 1998;74(SUPPL. 1):S106–11. Available from: http://dspace.itg.be/bitstream/handle/10390/5221/1998stinS106.pdf?sequence=1 147. Holland J, Young ML, Lee O, Chen SCA. Vulvovaginal carriage of yeasts other than Candida albicans. Sex Transm Infect. 2003;79(3):249–50. 148. Lindner JGEM, Plantema FHF, Hoogkamp-Korstanje JAA. Quantitative studies of the vaginal flora of healthy women and of obstetric and gynaecological patients. J Med Microbiol. 1978;11(3):233–41. 149. Sobel JD. Epidemiology and pathogenesis of recurrent vulvovaginal candidiasis. Am J Obstet Gynecol [Internet]. 1985;152(7):924–35. Available from: http://dx.doi.org/10.1016/S0002-9378(85)80003-X 150. Sobel JD. Candida vulvovaginitis [Internet]. UpToDate. 2017. Available from: http://enjoypregnancyclub.com/wpcontent/uploads/2017/06/Candida vulvovaginitis.pdf 151. Pappas PG, Kauffman CA, Andes D, Benjamin DK, Calandra TF, Edwards JE, et al. Clinical practice guidelines for the management of candidiasis: 2009 Update by the Infectious Diseases Society of America. Clin Infect Dis. 2009;48(5):503–35. 152. Amsel R, Totten PA, Spiegel CA, Chen KCS, Eschenbach D, Holmes KK. Nonspecific vaginitis. Diagnostic criteria and microbial and epidemiologic associations. Am J Med [Internet]. 1983;74(1):14–22. Available from: https://www.sciencedirect.com/science/article/abs/pii/0002934383911129 153. Nugent RP, Krohn MA, Hillier SL. Reliability of diagnosing bacterial vaginosis is improved by a standardized method of gram stain interpretation. J Clin Microbiol. 1991;29(2):297–301. 154. Bradshaw CS, Morton AN, Hocking J, Garland SM, Morris MB, Moss LM, et al. High recurrence rates of bacterial vaginosis over the course of 12 months after oral metronidazole therapy and factors associated with recurrence. J Infect Dis. 2006;193(11):1478–86. 155. Larsson PG. Treatment of bacterial vaginosis. Int J STD AIDS. 1992;3:239–47. 156. Sobel JD, Schmitt C, Meriwether C. Long-term follow-Up of patients with bacterial vaginosis treated with oral metronidazole and topical clindamycin. J Infect Dis. 1993;167(3):783–4. 157. Sood S, Kapil A.  An update on Trichomonas vaginalis . Indian J Sex Transm Dis AIDS. 2008;29(1):7. 158. Mann JR, M S, Gill T. Sexually transmitted infection is associated with increased risk of preterm birth in South Carolina women insured by medicaid. J Matern Neonatal Med. 2010;23(6):563–8. 159. Haefner HK. Current evaluation and management of vulvovaginitis. Clin Obs Gynecol. 1999;42(2):184–95. 160. Stamm WE. Clamydia trachomatis infections of the adult. In: Holmes KK, Mardh PA, editors. Sexually Transmitted Diseases. 3rd ed. New York: MacGraw-Hill; 1999. 161. Patton DL. Immunopathology and histopathology of experimental chlamydial salpingitis. Rev Infect Dis. 1985;7(6):746–53. 162. Paavonen J, Eggert-Kruse W. Chlamydia trachomatis: Impact on human reproduction. Hum Reprod Update. 1999;5(5):433–47. 163. Mårdh PA. Tubal factor infertility, with special regard to chlamydial salpingitis. Curr Opin Infect Dis. 2004;17(1):49–52. 164. Roberts TE, Robinson S, Barton PM, Bryan S, McCarthy A, Macleod J, et al. Cost effectiveness of home based population screening for Chlamydia trachomatis in the UK: Economic evaluation of chlamydia screening studies (ClaSS) project. Br Med J. 2007;335(7614):291–4. 165. Bakken IJ, Skjeldestad FE, Nordbø SA. Chlamydia trachomatis infections increase the risk for ectopic pregnancy: A populationbased, nested case-control study. Sex Transm Dis. 2007;34(3):166–9. 166. Bakken IJ, Ghaderi S. Incidence of pelvic inflammatory disease in a large cohort of women tested for Chlamydia trachomatis: A historical follow-up study. BMC Infect Dis. 2009;9:5–9. 167. Land JA, Van Bergen JEAM, Morré SA, Postma MJ. Epidemiology of Chlamydia trachomatis infection in women and the costeffectiveness of screening. Hum Reprod Update. 2010;16(2):189–204. 168. Benzaken A, Sales DN, Palheta Jr JIL, Pedrosa VL, Garcia EG. Prevalência da infecção por clamídia e gonococo em mulheres atendidas na clínica de DST da Fundação Alfredo da Matta, Manaus, Amazonas. J Bras Doenças Sex Trasmissíveis. 2010;22(3):129–34. 169. Currie MJ, Bowden FJ. The importance of chlamydial infections in obstetrics and gynaecology: An update. Aust New Zeal J Obstet Gynaecol. 2007;47(1):2–8. 170. LaMontagne DS, Baster K, Emmett L, Nichols T, Randall S, McLean L, et al. Incidence and reinfection rates of genital chlamydial infection among women aged 16-24 years attending general practice, family planning and genitourinary medicine clinics in England: A prospective cohort study by the Chlamydia Recall Study Advisory Group. Sex Transm Infect. 2007;83(4):292–303. 171. Skjeldestad FE, Marsico MA, Sings HL, Nordbø SA, Størvold G. Incidence and risk factors for genital chlamydia trachomatis infection: a 4-year prospective cohort study. Sex Transm Dis. 2009;36(5):273–9. 172. Evans C, Das C, Kinghorn G. A retrospective study of recurrent chlamydia infection in men and women: is there a role for targeted screening for those at risk. Int J STD AIDS. 2009;20(3):188–92. 173. Wetmore CM, Manhart LE, Wasserheit JN. Randomized controlled trials of interventions to prevent sexually transmitted infections: Learning from the past to plan for the future. Epidemiol Rev. 2010;32(1):121–36. 174. Pinto VM, Szwarcwald CL, Baroni C, Stringari LL, Inocêncio LA, Miranda AE. Chlamydia trachomatis prevalence and risk behaviors in parturient women aged 15 to 24 in Brazil. Sex Transm Dis. 2011;38(10):957–61. 175. Weström L V. Sexually transmitted diseases and infertility. Sex Transm Dis. 1994;21(2 Suppl):S32–7. 176. Groseclose SL, Zaidi AA, DeLisle SJ, Levine WC, St Louis ME. Estimated incidence and prevalence of genital Chlamydia trachomatis infections in the United States, 1996. Sex Transm Dis. 1999;26(6):339–44. 177. Hook III EW, Handsfield HH. Gonococcal infections in the adults. In: Holmes KK, Mardh PA, Sparling PF, editors. Sexually Transmitted Diseases. 3rd ed. New York: MacGraw-Hill; 1999. p. 451–66. 178. Loomis WP, Starnbach MN. T cell responses to Chlamydia trachomatis. Curr Opin Microbiol. 2002;5(1):87–91. 179. Honey E, Templeton A. Prevention of pelvic inflammatory disease by the control of C. trachomatis infection. Int J Gynecol Obstet. 2002;78(3):257–61. 180. Svenstrup HF, Fedder J, Kristoffersen SE, Trolle B, Birkelund S, Christiansen G. Mycoplasma genitalium, Chlamydia trachomatis, and tubal factor infertility-a prospective study. Fertil Steril. 2008;90(3):513–20. 181. Hosenfeld CB, Workowski KA, Berman S, Zaidi A, Dyson J, Mosure D, et al. Repeat infection with chlamydia and gonorrhea among females: a systematic review of the literature. Sex Transm Dis. 2009;36(8):478–89. 182. Ness RB, Smith KJ, Chang CCH, Schisterman EF, Bass DC. Prediction of pelvic inflammatory disease among young, single,  
104  
sexually active women. Sex Transm Dis. 2006;33(3):137–42. 183. Kapiga SH, Vuylsteke B, Lyamuya EF, Dallabetta G, Laga M. Evaluation of sexually transmitted diseases diagnostic algorithms among family planning clients in Dar es Salaam, Tanzania. Sex Transm Infect. 1998;74(Suppl. 1). 184. Ndoye I, Mboup S, De Schryver A, Van Dyck E, Moran J, Samb ND, et al. Diagnosis of sexually transmitted infections in female prostitutes in Dakar, Senegal. Sex Transm Infect. 1998;74(Suppl. 1):S112–7. 185. Alary M, Baganizi E, Guèdèmè A, Padonou F, Davo N, Adjovi C, et al. Evaluation of clinical algorithms for the diagnosis of gonococcal and chlamydial infections among men with urethral discharge or dysuria and women with vaginal discharge in Benin. Sex Transm Inf [Internet]. 1998;74(Suppl 1):S44–9. Available from: http://dspace.itg.be/bitstream/handle/10390/5220/1998stin0S44.pdf?sequence=1 186. Ryan CA, Courtois BN, Hawes SE, Stevens CE, Eschenbach DA, Holmes KK. Risk assessment, symptoms, and signs as predictors of vulvovaginal and cervical infections in an urban US STD clinic: implications for use of STD algorithms. Sex Transm Infect. 1998;74(Suppl. 1):S59–76. 187. Sánchez SE, Koutsky LA, Sánchez J, Fernández A, Casquero J, Kreiss J, et al. Rapid and inexpensive approaches to managing abnormal vaginal discharge or lower abdominal pain: an evaluation in women attending gynaecology and family planning clinics in Peru. Sex Transm Infect. 1998;74(Suppl. 1):S85–94. 188. Schneider H, Coetzee DJ, Fehler HG, Bellingan A, Dangor Y, Radebe F, et al. Screening for sexually transmitted diseases in rural South African women. Sex Transm Infect. 1998;74(Suppl. 1):S147–52. 189. Wi T, Mesola V, Manalastas R, Tuazon C, Mugriditchian DS, Perine P, et al. Syndromic approach to detection of gonococcal and chlamydial infections among female sex workers in two Philippine cities. Sex Transm Infect. 1998;74(Suppl. 1):S118-122. 190. Sellors JW, Walter SD, Howard M. A new visual indicator of chlamydial cervicitis? Sex Transm Infect. 2000;76(1):46–8. 191. Fonck K, Kidula N, Jaoko W, Estambale B, Claeys P, Ndinya-Achola J, et al. Validity of the vaginal discharge algorithm among pregnant and non- pregnant women in Nairobi, Kenya. Sex Transm Infect. 2000;76(1):33–8. 192. Faúndes A, Telles E, Cristofoletti MDL, Faúndes D, Castro S, Hardy E. The risk of inadvertent intrauterine device insertion in women carriers of endocervical Chlamydia trachomatis. Contraception. 1998;58(2):105–9. 193. Turner CF, Rogers SM, Miller HG, Miller WC, Gribble JN, Chromy JR, et al. Untreated gonococcal and chlamydial infection in a probability sample of adults. J Am Med Assoc. 2002;287(6):726–33. 194. Ravel J, Gajer P, Abdo Z, Schneider GM, Koenig SSK, McCulle SL, et al. Vaginal microbiome of reproductive-age women. Proc Natl Acad Sci U S A. 2011;108(Suppl. 1):4680–7. 195. Bourgeois A, Henzel D, Dibanga G, Malonga-Mouelet G, Peeters M, Coulaud JP, et al. Prospective evaluation of a flow chart using a risk assessment for the diagnosis of STDs in primary healthcare centres in Libreville, Gabon. Sex Transm Infect. 1998;74(Suppl. 1):S128–32. 196. Mayaud P, Ka-Gina G, Cornelissen J, Todd J, Kaatano G, West B, et al. Validation of a WHO algorithm with risk assessment for the clinical management of vaginal discharge in Mwanza, Tanzania. Sex Transm Infect. 1998;74(Suppl. 1):S77–84. 197. Mayaud P, Uledi E, Cornelissen J, Ka-Gina G, Todd J, Rwakatare M, et al. Risk scores to detect cervical infections in urban antenatal clinic attenders in Mwanza, Tanzania. Sex Transm Infect. 1998;74(Suppl. 1):S139–46. 198. Steen R, Soliman C, Mujyambwani A, Twagirakristu JB, Bucyana S, Grundmann C, et al. Notes from the field: practical issues in upgrading STD services based on experience from primary healthcare facilities in two Rwandan towns. Sex Transm Infect. 1998;74(Suppl. 1):S159–65. 199. Ryan CA, Zidouh A, Manhart LE, Selka R, Xia M, Moloney-Kitts M, et al. Reproductive tract infections in primary healthcare, family planning, and dermatovenereology clinics: evaluation of syndromic management in Morocco. Sex Transm Infect. 1998;74(Suppl. 1):S95–105. 200. Moherdaui F, Vuylsteke B, Siqueira LFG, Dos Santos MQ, Jardim ML, De Brito AM, et al. Validation of national algorithms for the diagnosis of sexually transmitted diseases in Brazil: results from a multicentre study. Sex Transm Infect. 1998;74(Suppl. 1):S38–43. 201. Andrews WW, Klebanoff MA, Thom EA, Hauth JC, Carey JC, Meis PJ, et al. Midpregnancy genitourinary tract infection with Chlamydia trachomatis: Association with subsequent preterm delivery in women with bacterial vaginosis and Trichomonas vaginalis. Am J Obstet Gynecol [Internet]. 2006;194(2):493–500. Available from: https://www.ajog.org/article/S0002-9378(05)01377-3/abstract 202. Silveira MF, Ghanem KG, Erbelding EJ, Burke AE, Johnson HL, Singh RH, et al. Chlamydia trachomatis infection during pregnancy and the risk of preterm birth: A case-control study. Int J STD AIDS. 2009;20(7):465–9. 203. Rours GIJG, De Krijger RR, Ott A, Willemse HFM, De Groot R, Zimmermann LJI, et al. Chlamydia trachomatis and placental inflammation in early preterm delivery. Eur J Epidemiol. 2011;26(5):421–8. 204. Rours GIJG, Duijts L, Moll HA, Arends LR, De Groot R, Jaddoe VW, et al. Chlamydia trachomatis infection during pregnancy associated with preterm delivery: A population-based prospective cohort study. Eur J Epidemiol. 2011;26(6):493–502. 205. Peipert JF. Genital chlamydial infections. N Engl J Med [Internet]. 2003;349(25):2424–30. Available from: http://www.ncbi.nlm.nih.gov/pubmed/14681509 206. Machado D, Castro J, Palmeira-de-Oliveira A, Martinez-de-Oliveira J, Cerca N. Bacterial vaginosis biofilms: challenges to current therapies and emerging solutions. Front Microbiol. 2016;6:1528–41. 207. Yudin MH, Money DM. Screening and Management of Bacterial Vaginosis in Pregnancy. J Obstet Gynaecol Canada. 2008;30(8):702–8. 208. Gaydos CA, Maldeis NE, Hardick A, Hardick J, Quinn TC. Mycoplasma genitalium compared to chlamydia, gonorrhoea and trichomonas as an aetiological agent of urethritis in men attending STD clinics. Sex Transm Infect. 2009;85(6):438–40. 209. Daley GM, Russell DB, Tabrizi SN, McBride J. Mycoplasma genitalium: a review. Int J STD AIDS. 2014;25(7):475–87. 210. Lis R, Rowhani-Rahbar A, Manhart LE. Mycoplasma genitalium Infection and Female Reproductive Tract Disease: A Metaanalysis. Clin Infect Dis. 2015;61(3):418–26. 211. Taylor-Robinson D. Diagnosis and antimicrobial treatment of Mycoplasma genitalium infection: sobering thoughts. Expert Rev Anti Infect Ther. 2014;12(6):715–22.  
212. Pond MJ, Nori A V., Witney AA, Lopeman RC, Butcher PD, Sadiq ST. High prevalence of antibiotic-resistant mycoplasma genitalium in nongonococcal urethritis: the need for routine testing and the inadequacy of current treatment options. Clin Infect Dis. 2014;58(5):631–7.  
213. Wold C, Sorthe J, Hartgill U, Olsen AO, Moghaddam A, Reinton N. Identification of macrolide-resistant Mycoplasma genitalium using real-time PCR. J Eur Acad Dermatology Venereol. 2015;29(8):1616–20. 214. Horner P, Blee K, Adams E. Time to manage Mycoplasma genitalium as an STI: but not with azithromycin 1 g! Curr Opin Infect Dis. 2014;27(1):68–74. 215. Manhart LE, Jensen JS, Bradshaw CS, Golden MR, Martin DH. Efficacy of antimicrobial therapy for Mycoplasma genitalium infections. Clin Infect Dis. 2015;61(Suppl 8):S802–17.  
105  
216. Birger R, Saunders J, Estcourt C, Sutton AJ, Mercer CH, Roberts T, et al. Should we screen for the sexually-transmitted infection Mycoplasma genitalium? Evidence synthesis using a transmission-dynamic model. Sci Rep [Internet]. 2017;7(1):16162. Available from: http://dx.doi.org/10.1038/s41598-017-16302-8 217. Bissessor M, Tabrizi SN, Twin J, Abdo H, Fairley CK, Chen MY, et al. Macrolide resistance and azithromycin failure in a mycoplasma genitalium-infected cohort and response of azithromycin failures to alternative antibiotic regimens. Clin Infect Dis. 2015;60(8):1228–36. 218. Kikuchi M, Ito S, Yasuda M, Tsuchiya T, Hatazaki K, Takanashi M, et al. Remarkable increase in fluoroquinolone-resistant mycoplasma genitalium in Japan. J Antimicrob Chemother. 2014;69(9):2376–82. 219. Salado-Rasmussen K, Jensen JS. Mycoplasma genitalium testing pattern and macrolide resistance: a Danish nationwide retrospective survey. Clin Infect Dis. 2014;59(1):24–30. 220. Sethi S, Zaman K, Jain N. Mycoplasma genitalium infections: current treatment options and resistance issues. Infect Drug Resist. 2017;10:283–92. 221. Jensen JS, Bradshaw C. Management of Mycoplasma genitalium infections - can we hit a moving target? BMC Infect Dis [Internet]. 2015;15(1):343. Available from: http://dx.doi.org/10.1186/s12879-015-1041-6 222. Read TRH, Fairley CK, Tabrizi SN, Bissessor M, Vodstrcil L, Chow EPF, et al. Azithromycin 1.5g over 5 days compared to 1g single dose in urethral mycoplasma genitalium: impact on treatment outcome and resistance. Clin Infect Dis. 2017;64(3):250–6. 223. Gratrix J, Plitt S, Turnbull L, Smyczek P, Brandley J, Scarrott R, et al. Prevalence and antibiotic resistance of Mycoplasma genitalium among STI clinic attendees in western Canada: a cross-sectional analysis. BMJ Open. 2017;7(7):e016300. 224. Couldwell DL, Lewis DA. Mycoplasma genitalium infection: Current treatment options, therapeutic failure, and resistanceassociated mutations. Infect Drug Resist. 2015;8:147–61. 225. Munoz JL, Goje OJ. Mycoplasma genitalium: an emerging sexually transmitted infection. Scientifica (Cairo). 2016;2016:7537318. 226. Haggerty CL, Gottlieb SL, Taylor BD, Low N, Xu F, Ness RB. Risk of sequelae after chlamydia trachomatis genital infection in women. J Infect Dis. 2010;201(SUPPL. 2):S134–55. 227. Trent M, Bass D, Ness RB, Haggerty C. Recurrent PID, subsequent STI, and reproductive health outcomes: findings from the PID evaluation and clinical health (PEACH) study. Sex Transm Dis. 2011;38(9):879–81. 228. Short VL, Totten PA, Ness RB, Astete SG, Kelsey SF, Haggerty CL. Clinical presentation of Mycoplasma genitalium infection versus Neisseria gonorrhoeae infection among women with pelvic inflammatory disease. Clin Infect Dis. 2009;48(1):41–7. 229. Sweet RL. Pelvic inflammatory disease: current concepts of diagnosis and management. Curr Infect Dis Rep. 2012;14(2):194– 203. 230. Brunham RC, Gottlieb SL, Paavonen J. Pelvic inflammatory disease. N Engl J Med. 2015;372(21):2039–48. 231. Haggerty CL, Taylor BD. Mycoplasma genitalium: an emerging cause of pelvic inflammatory disease. Infect Dis Obstet Gynecol. 2011;2011:959816. 232. Weinstein SA, Stiles BG. A review of the epidemiology, diagnosis and evidence-based management of Mycoplasma genitalium. Sex Health. 2011;8(2):143–58. 233. McGowin CL, Anderson-Smits C. Mycoplasma genitalium: an emerging cause of sexually transmitted disease in women. PLoS Pathog. 2011;7(5):e1001324. 234. Workowski KA, Berman S. Sexually transmitted diseases treatment guidelines, 2010. MMWR Recomm Reports. 2010;59(RR12):1–110. 235. Wiensenfeld HC. Pelvic inflammatory disease: treatment in adults and adolescentes [Internet]. UpToDate. 2018. Available from: https://www.uptodate.com/contents/pelvic-inflammatory-disease-treatment-in-adults-and-adolescents 236. Papavarnas CP, Venter PF, van Staden MJ. Acute salpingitis--laparoscopic and microbiological evaluation. South African Med J. 1990;8(21):4003–404. 237. Hillis SD, Joesoef R, Marchbanks PA, Wasserheit JN, Cates W, Westrom L. Delayed care of pelvic inflammatory disease as a risk factor for impaired fertility. Am J Obstet Gynecol [Internet]. 1993;168(5):1503–9. Available from: http://dx.doi.org/10.1016/S00029378(11)90790-X 238. Duarte R, Fuhrich D, Ross JDC. A review of antibiotic therapy for pelvic inflammatory disease. Int J Antimicrob Agents [Internet]. 2015;46(3):272–7. Available from: http://dx.doi.org/10.1016/j.ijantimicag.2015.05.004 239. Jaiyeoba O, Lazenby G, Soper DE. Recommendations and rationale for the treatment of pelvic inflammatory disease. Expert Rev Anti Infect Ther. 2011;9(1):61–70. 240. PHAC. Pelvic Inflammatory Disease (PID). In: PHAC, editor. Updates to the Canadian Guidelines on Sexually Transmitted Infections [Internet]. Ottawa: PHAC; 2008. Available from: https://fhs.mcmaster.ca/medicine/infectious_ diseases/residents/docs/CanadianSTI-Guidelines2008.pdf 241. Palefsky JM, Holly EA, Hogeboom CJ, Berry JM, Jay N, Darragh TM. Anal cytology as a screening tool for anal squamous intraepithelial lesions. J Acquir Immune Defic Syndr Hum Retrovirology. 1997;14(5):415–22. 242. Chow EPF, Danielewski JA, Fehler G, Tabrizi SN, Law MG, Bradshaw CS, et al. Human papillomavirus in young women with Chlamydia trachomatis infection 7 years after the Australian human papillomavirus vaccination programme: A cross-sectional study. Lancet Infect Dis [Internet]. 2015;15(11):1314–23. Available from: http://dx.doi.org/10.1016/S1473-3099(15)00055-9 243. Kahn JA, Widdice LE, Ding L, Huang B, Brown DR, Franco EL, et al. Substantial decline in vaccine-type Human Papillomavirus (HPV) among vaccinated young women during the first 8 years after HPV vaccine introduction in a community. Clin Infect Dis. 2016;63(10):1281–7. 244. Smith MA, Canfell K. Projected impact of HPV vaccination and primary HPV screening on cervical adenocarcinoma: example from Australia. Papillomavirus Res [Internet]. 2017;3(April):134–41. Available from: http://dx.doi.org/10.1016/j.pvr.2017.04.003 245. Goggin P, Sauvageau C, Gilca V, Defay F, Lambert G, Mathieu-C S, et al. Low prevalence of vaccine-type HPV infections in young women following the implementation of a school-based and catch-up vaccination in Quebec, Canada. Hum Vaccines Immunother. 2018;14(1):118–23.  
246. Liddon NC, Leichliter JS, Markowitz LE. Human papillomavirus vaccine and sexual behavior among adolescent and young women. Am J Prev Med [Internet]. 2012;42(1):44–52. Available from: http://dx.doi.org/10.1016/j.amepre.2011.09.024 247. Mather T, McCaffery K, Juraskova I. Does HPV vaccination affect women’s attitudes to cervical cancer screening and safe sexual behaviour? Vaccine [Internet]. 2012;30(21):3196–201. Available from: http://dx.doi.org/10.1016/j.vaccine.2012.02.081 248. Marchand E, Glenn BA, Bastani R. HPV vaccination and sexual behavior in a community college sample. J Community Health. 2013;38(6):1010–4. 249. Bowyer HL, Dodd RH, Marlow LAV, Waller J. Association between human papillomavirus vaccine status and other cervical cancer risk factors. Vaccine [Internet]. 2014;32(34):4310–6. Available from: http://dx.doi.org/10.1016/j.vaccine.2014.06.011  
106  
250. Mayhew A, Kowalczyk Mullins TL, Ding L, Rosenthal SL, Zimet GD, Morrow C, et al. Risk perceptions and subsequent sexual behaviors after HPV vaccination in adolescents. Pediatrics. 2014;133(3):404–11. 251. Rysavy MB, Kresowik JDK, Liu D, Mains L, Lessard M, Ryan GL. Human papillomavirus vaccination and sexual behavior in young women. J Pediatr Adolesc Gynecol [Internet]. 2014;27(2):67–71. Available from: http://dx.doi.org/10.1016/j.jpag.2013.08.009 252. Ruiz-Sternberg ÁM, Pinzón-Rondón ÁM. Risk perception and sexual behavior in HPV-vaccinated and unvaccinated young Colombian women. Int J Gynecol Obstet [Internet]. 2014;126(3):205–8. Available from: http://dx.doi.org/10.1016/j.ijgo.2014.03.033 253. Vázquez-Otero C, Thompson EL, Daley EM, Griner SB, Logan R, Vamos CA. Dispelling the myth: exploring associations between the HPV vaccine and inconsistent condom use among college students. Prev Med (Baltim) [Internet]. 2016;93:147–50. Available from: http://dx.doi.org/10.1016/j.ypmed.2016.10.007 254. Mullins TLK, Rosenthal SL, Zimet GD, Ding L, Morrow C, Huang B, et al. Human Papillomavirus vaccine-related risk perceptions do not predict sexual initiation among young women over 30 months following vaccination. J Adolesc Heal [Internet]. 2018;62(2):164–9. Available from: https://doi.org/10.1016/j.jadohealth.2017.09.008 255. Padhiar B, Karia U, Aggarwal R. A comparative study of efficacy of imiquimod 5% versus podophyllin 20% in treatment of external and genital warts (60 patients). Indian J Sex Transm Dis. 2006;27(2):67–9. 256. Yan J, Chen SL, Wang HN, Wu TX. Meta-analysis of 5% imiquimod and 0.5% podophyllotoxin in the treatment of condylomata acuminata. Dermatology. 2006;213(3):218–23. 257. Komericki P, Akkilic-Materna M, Strimitzer T, Aberer W. Efficacy and safety of imiquimod versus podophyllotoxin in the treatment of anogenital warts. Sex Transm Dis. 2011;38(3):216–8. 258. Thurgar E, Barton S, Karner C, Edwards SJ. Clinical effectiveness and cost-effectiveness of interventions for the treatment of anogenital warts: systematic review and economic evaluation. Health Technol Assess (Rockv) [Internet]. 2016;20(24):1–485. Available from: http://dx.doi.org/10.3310/hta20240 259. Kent CK, Chaw JK, Wong W, Liska S, Gibson S, Hubbard G, et al. Prevalence of rectal, urethral, and pharyngeal chlamydia and gonorrhea detected in 2 clinical settings among men who have sex with men: San Francisco, California, 2003. Clin Infect Dis. 2005;41(1):67–74. 260. Wiesner PJ, Tronca E, Bonin P, Pedersen HB, Holmes K k. Clinical spectrum of pharyngeal gonococcal infection. N Engl J Med. 1974;288(4):181–5. 261. Clutterbuck D, Asboe D, Barber T, Emerson C, Field N, Gibson S, et al. 2016 United Kingdom national guideline on the sexual health care of men who have sex with men. Int J STD AIDS [Internet]. 2018;0(0):1–46. Available from: https://doi.org/10.1177/0956462417746897 262. de Vries HJC, Zingoni A, White JA, Ross JDC, Kreuter A. 2013 European Guideline on the management of proctitis, proctocolitis and enteritis caused by sexually transmissible pathogens. Int J STD AIDS. 2014;25(7):465–74. 263. Sigle GW, Kim R. Sexually transmitted proctitis. Clin Colon Rectal Surg. 2015;28(2):70–8. 264. PHAC. Supplementary statement for recommendations related to the diagnosis, management, and follow-up of sexually transmitted proctitis. Canadian Guidelines on Sexually Transmitted Infections. Public Health Agency of Canada. Ottawa; 2014. 265. Brill JR. Sexually transmitted infections in men. Prim Care - Clin Off Pract [Internet]. 2010;37(3):509–25. Available from: http://dx.doi.org/10.1016/j.pop.2010.04.003 266. Davis TW, Goldstone SE. Sexually transmitted infections as a cause of proctitis in men who have sex with men. Dis Colon Rectum. 2009;52(3):507–12. 267. Nadal SR, Manzione CR. Sexually transmitted proctitis. J Coloproct. 2012;32(1):94–6. 268. Hamlyn E, Taylor C. Sexually transmitted proctitis. Postgrad Med J. 2006;82(973):733–6. 269. Shover CL, Beymer MR, Unger EM, Javanbakht M, Bolan RK. Accuracy of presumptive gonorrhea treatment for gay, bisexual, and other men who have sex with men: results from a large sexual health clinic in Los Angeles, California. LGBT Heal. 2018;5(2):139–44. 270. Ivens D, MacDonald K, Bansi L, Nori A. Screening for rectal chlamydia infection in a genitourinary medicine clinic. Int J STD AIDS. 2007;18(6):404–6. 271. Manavi K, McMillan A, Young H. The prevalence of rectal chlamydial infection amongst men who have sex with men attending the genitourinary medicine clinic in Edinburgh. Int J STD AIDS. 2004;15(3):162–4. 272. Kenyon C. Risks of antimicrobial resistance in N. gonorrhoeae associated with intensive screening programs in pre-exposure prophylaxis programs. Clin Infect Dis. 2018;67(1):154–5. 273. Brasil M da S. Manual técnico para o diagnóstico da infecção pelo HIV em adultos e crianças. 4th ed. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/ Aids e das Hepatites Virais. Brasília: Ministério da Saúde; 2018. 149 p. 274. WHO. Global hepatitis report, 2017. Genova; 2017. 275. Brasil M da S. Boletim Epidemiológico Hepatites Virais 2017. Brasília: Ministério da Saúde; 2017. 276. Benzaken AS, Girade R, Catapan E, Pereira GFM, de Almeida EC, Vivaldini S, et al. Hepatitis C disease burden and strategies for elimination by 2030 in Brazil. A mathematical modeling approach. Brazilian J Infect Dis [Internet]. 2019;23(3):182–90. Available from: https://doi.org/10.1016/j.bjid.2019.04.010 277. Nainan O V., Armstrong GL, Han XH, Williams I, Bell BP, Margolis HS. Hepatitis A molecular epidemiology in the United States, 1996-1997: sources of infection and implications of vaccination policy. J Infect Dis. 2005;191(6):957–63. 278. Bell BP, Shapiro CN, Alter MJ, Moyer LA, Judson FN, Mottram K, et al. The diverse patterns of hepatitis A epidemiology in the united states - Implications for vaccination strategies. J Infect Dis. 1998;178(6):1579–84. 279. Cotter SM, Sansom S, Long T, Koch E, Kellerman S, Smith F, et al. Outbreak of hepatitis A among men who have sex with men: Implications for hepatitis A vaccination strategies. J Infect Dis. 2003;187(8):1235–40. 280. CDC. Hepatitis A among homosexual men: United States, Canada, and Australia. MMWR. 1992;41(09):161–4. 281. Henning KJ, Bell E, Braun J, Barker ND. A community-wide outbreak of hepatitis a: risk factors for infection among homosexual and bisexual men. Am J Med. 1995;99(2):132–6. 282. São Paulo S de E de S. Informe técnico: aumento de casos de hepatite A no estado de São Paulo. Atualização Semana Epidemiológica 39, 2017 [Internet]. Centro de Vigilância Epidemiológica. Divisão de Doenças de Transmissão Hídrica e Alimentar. 2017. Available from: http://www.saude.sp.gov.br/resources/cve-centro-de-vigilancia-epidemiologica/areas-de-vigilancia/doencas-transmitidas-poragua-e-alimentos/ doc/2017/hepatitea17_informe_tecnico.pdf 283. McMahon BJ. Epidemiology and natural history of hepatitis B. Semin Liver Dis. 2005;25(SUPPL. 1):3–8. 284. Dienstag JL. Hepatitis B virus infection. N Engl J Med. 2008;359(14):1486–500. 285. Lok ASF, McMahon BJ. Chronic hepatitis B. Hepatology. 2007;45(2):507–39. 286. Alter MJ. Epidemiology of hepatitis C virus infection. World J Gastroenterol [Internet]. 2007;13(17):2436–41. Available from:  
107  
https://www.wjgnet.com/1007-9327/full/v13/i17/2436.htm 287. Busch MP, Kleinman SH, Nemo GJ. Current and emerging infectious risks of blood transfusions. J Am Med Assoc. 2003;289(8):959–62. 288. Martins T, Luz Narciso-Schiavon J, De Lucca Schiavon L. Epidemiologia da infecção pelo vírus da hepatite C. Rev Assoc Med BRas. 2011;57(1):107–12. 289. Brasil M da S. Manual Técnico para o Diagnóstico das Hepatites Virais. 2nd ed. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/ Aids e das Hepatites Virais. Brasília: Ministério da Saúde; 2018. 121 p. 290. Brasil M da S. Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e Coinfecções. 1st ed. Brasília: Ministério da Saúde; 2017. 120 p. 291. Brasil M da S. Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções. 1st ed. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. Brasília: Ministério da Saúde; 2019. 68 p. 292. Petersen EE, Meaney-Delman D, Neblett-Fanfair R, Havers F, Oduyebo T, Hills SL, et al. Update: interim guidance for preconception counseling and prevention of sexual transmission of Zika virus for persons with possible Zika virus exposure — United States, september 2016. MMWR Morb Mortal Wkly Rep. 2016;65(39):1077–81. 293. Brasil M da S. Saúde Brasil 2015/2016: uma análise da situação de saúde e da epidemia pelo vírus Zika e por outras doenças transmitidas pelo Aedes aegypti [Internet]. 1st ed. Brasília: Ministério da Saúde; 2017. 386 p. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/resumo_saude_brasil_2015_2016.pdf 294. Hills SL, Russell K, Hennessey M, Williams C, Oster AM, Fischer M, et al. Transmission of Zika Virus through sexual contact with travelers to areas of ongoing transmission — continental United States, 2016. MMWR Morb Mortal Wkly Rep. 2016;65(8):215–6. 295. Barzon L, Pacenti M, Berto A, Sinigaglia A, Franchin E, Lavezzo E, et al. Isolation of infectious Zika virus from saliva and prolonged viral RNA shedding in a traveller returning from the Dominican Republic to Italy, January 2016. Eurosurveillance. 2016;21(10):1– 5. 296. Trew Deckard D, Chung WM, Brooks JT, Smith JC, Woldai S, Hennessey M, et al. Male-to-male sexual transmission of Zika virus — Texas, January 2016. MMWR Morb Mortal Wkly Rep. 2016;65(14):372–4. 297. Atkinson B, Hearn P, Afrough B, Lumley S, Carter D, Aarons EJ, et al. Detection of Zika virus in semen. Emerg Infect Dis [Internet]. 2016;22(5):940. Available from: https://wwwnc.cdc.gov/eid/article/22/5/16-0107_article 298. Paz-Bailey G, Rosenberg ES, Doyle K, Munoz-Jordan J, Santiago GA, Klein L, et al. Persistence of Zika virus in body fluids — final report. N Engl J Med. 2018;379(13):1234–43. 299. Polen KD, Gilboa SM, Hills S, Oduyebo T, Kohl KS, Brooks JT, et al. Update: interim guidance for preconception counseling and prevention of sexual transmission of Zika virus for men with possible Zika virus exposure — United States, August 2018. MMWR Morb Mortal Wkly Rep. 2018;67(31):868–71. 300. WHO. WHO guidelines for the prevention of sexual transmission of Zika virus [Internet]. World Health Organization. Human Reproduction Programme. Genova: WHO; 2020. 98 p. Available from: https://www.who.int/publications/i/item/prevention-of-sexualtransmission-of-zika-virus 301. Gonçalves DU, Proietti FA, Ribas JGR, Araújo MG, Pinheiro SR, Guedes AC, et al. Epidemiology, treatment, and prevention of human T-cell leukemia virus type 1-associated diseases. Clin Microbiol Rev. 2010;23(3):577–89. 302. Gessain A, Cassar O. Epidemiological aspects and world distribution of HTLV-1 infection. Front Microbiol. 2012;3(388):1–23. 303. Carneiro-Proietti ABF, Catalan-Soares BC, Castro-Costa CM, Murphy EL, Sabino EC, Hisada M, et al. HTLV in the Americas: challenges and perspectives. Rev Panam Salud Publica/Pan Am J Public Heal. 2006;19(1):44–53. 304. Biggar RJ, Ng J, Kim N, Hisada M, Li HC, Cranston B, et al. Human leukocyte antigen concordance and the transmission risk via breast-feeding of human T cell lymphotropic virus type I. J Infect Dis. 2006;193(2):277–82. 305. Fujino T, Nagata Y. HTLV-I transmission from mother to child. J Reprod Immunol. 2000;47(2):197–206. 306. Brasil M da S. Protocolo de uso da zidovudina para tratamento do adulto com leucemia/linfoma associado ao vírus HTLV-1 [Internet]. Secretaria de Vigilância em Saúde. Departamento de Vigilância, Prevenção e Controle das Infecções Sexualmente Transmissíveis, do HIV/Aids e das Hepatites Virais. Brasília; 2016. Available from: http://www.aids.gov.br/pt-br/pub/2016/protocolo-de-uso-da-zidovudinapara-tratamento-do-adulto-com-leucemialinfoma-associado-ao  
307. Brasil M da S. Atenção humanizada às pessoas em situação de violência sexual com registro de informações e coleta de vestígios. Norma técnica. 1st ed. Brasília: Ministério da Saúde; 2015. 44 p. 308. Brasil P da R. Lei n<sup>o</sup> 12.845, de 1<sup>o</sup> de agosto de 2013. Dispõe sobre o atendimento obrigatório e integral de pessoas em situação de violência sexual. Brasília: Diário Oficial da UNião; 2013. 309. Brasil P da R. Decreto n<sup>o</sup> 7.958, de 13 de março de 2013. Estabelece diretrizes para o atendimento às vítimas de violência sexual pelos profissionais de segurança pública e da rede de atendimento do Sistema Único de Saúde. Brasília: Diário Oficial da União; 2013. p. Seção 1. 310. Brasil P da R. Lei No 8.069, de 13 de julho de 1990. Dispõe sobre o Estatuto da Criança e do Adolescente e dá outras providências [Internet]. Brasília: Diário Oficial da União; 1990. Available from: http://www.planalto.gov.br/ccivil_03/leis/l8069.htm  
311. Brasil P da R. Lei No 10.778, de 24 de novembro de 2003. Estabelece a notificação compulsória, no território nacional, do caso de violência contra a mulher que for atendida em serviços de saúde públicos ou privados [Internet]. Brasília: Diário Oficial da União; 2003. Available from: http://www.planalto.gov.br/ccivil_03/leis/2003/l10.778.htm 312. Brasil P da R. Lei No 10.741, de 1o de outubro de 2003. Dispõe sobre o Estatuto do Idoso e dá outras providências [Internet]. Brasília: Diário Oficial da União; 2003. Available from: http://www.planalto.gov.br/ccivil_03/leis/2003/l10.741.htm 313. Brasil M da S. Portaria No 204, de 17 de fevereiro de 2016. Define a Lista Nacional de Notificação Compulsória de doenças, agravos e eventos de saúde pública nos serviços de saúde públicos e privados em todo o território nacional, nos termos do anexo e dá outras providê. Brasília: Diário Oficial da União; 2016.  
314. Brasil P da R. Decreto-Lei N<sup>o</sup> 2.848, de 7 de Dezembro de 1940. Aprova o Código Penal brasileiro. [Internet]. Brasília: Diário Oficial da União; 1940. Available from: hhttp://www.planalto.gov.br/ccivil_03/decreto-lei/del2848.htm  
315. Segurança Pública FB. Anuário Brasileiro de Segurança Pública 2017 [Internet]. Anuário Brasileiro de Segurança Pública. São Paulo: Fórum Brasileiro de Surança Pública; 2017. 108 p. Available from: https://forumseguranca.org.br/wpcontent/uploads/2019/01/ANUARIO_11_2017.pdf  
316. Brasil M da S. Protocolo para utilização do levonorgestrel na anticoncepção hormonal de emergência [Internet]. Brasília: Ministério da Saúde; 2012. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/protocolo_levonorgestrel_anticoncepcao_hormonal_emergencia.pdf 317. Brasil M da S. Política nacional de atenção integral à saúde da mulher: princípios e diretrizes. 1st ed. Secretaria de Atenção à  
108  
Saúde. Departamento de Ações Programáticas Estratégicas. Brasília: Ministério da Saúde; 2004. 82 p.  
|318.<br>Brasil M da S. Prevenção e tratamento dos agravos resultantes da violência sexual contra mulheres e adolescentes. Norma técnica|
|---|
|[Internet]. 3rd ed. Secretaria de Atenção à Saúde. Departamento de Ações Programaticas Estratégicas. Brasília: Ministério da Saúde; 2012.<br>124 p. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/prevencao_agravo_violencia_sexual_mulheres_3ed.pdf|
|319.<br>Brasil M da S. Portaria n° 485, de 1<sup>o</sup>de abril de 2014. Redefine o funcionamento do Serviço de Atenção às Pessoas em Situação<br>de Violência Sexual no âmbito do Sistema Único de Saúde (SUS). Brasília: Diário Oficial da União; 2014. p. v. 63, Seção 11.|
|320.<br>Schraiber LB, D’Oliveira AFPL. O que devem saber os profissionais de saúde para promover os direitos e a saúde das mulheres<br>em situação de violência doméstica. Projeto Gênero, Violência e Direitos Humanos - novas questões para o campo da saúde. 2nd ed. São<br>Paulo: Coletivo Feminista Sexualidade e Saúde/Departamento de Medicina Preventiva da Faculdade de Medicina da Universidade de São<br>Paulo; 2003. 38 p.|
|321.<br>Brasil M da S. Linha de cuidado para a atenção integral à saúde de crianças, adolescentes e suas famílias em situação de<br>violências: orientação para gestores e profissionais de saúde. 1st ed. Brasília: Ministério da Saúde; 2010. 104 p.|
|322.<br>Brasil M da S. Portaria n<sup>o</sup>618, de 18 de julho de 2014. Altera a tabela de serviços especializados do Sistema de Cadastro<br>Nacional de Estabelecimentos de Saúde (SCNES) para o serviço 165 Atenção Integral à Saúde de Pessoas em Situação de Violência Sexual e<br>dispõe sobre . Gabinete do Ministro. Brasília: Diário Oficial da União; 2014. p. Seção 1.|
|323.<br>Brasil M da S. Portaria n° 1.271, de 06 de junho de 2014. Define a Lista Nacional de Notificação Compulsória de doenças,<br>agravos e eventos de saúde pública nos serviços de saúde públicos e privados em todo o território nacional, nos termos do anexo, e dá outras<br>providên [Internet]. Brasília: Diário Oficial da União; 2014. Available from:<br>http://bvsms.saude.gov.br/bvs/saudelegis/gm/2014/prt1271_06_06_2014.html|
|324.<br>Brasil P da R. Lei n<sup>o</sup>6.259, de 30 de outubro de 1975. Dispõe sobre a organização das ações de Vigilância Epidemiológica, sobre<br>o Programa Nacional de Imunizações, estabelece normas relativas à notificação compulsória de doenças, e dá outras providências. Brasília:<br>Diário Oficial da União; 1975. p. Seção 1.|
|325.<br>Brasil M da S. Guia de Vigilância em Saúde. 2nd ed. Secretaria de Vigilância em Saúde. Coordenação-Geral de<br>Desenvolvimento da Epidemiologia em Serviços. Brasília: Ministério da Saúde; 2017. 705 p.|
|326.<br>Brasil M da S. Portaria de Consolidação n<sup>o</sup>2, de 28 de setembro de 2017. Consolidação das normas sobre as políticas nacionais<br>de saúde do Sistema Único de Saúde. Brasília: Diário Oficial da União; 2017.|  
109

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
|Nome:||
|---|---|
|Endereço:|UF:|
|CEP:|Telefone para contato:|
|Solicitamos o seu comparecimento com brevidade à Unidad<br>saúde.|e de Saúde indicada abaixo, para tratar de assunto relacionado à sua|
|Traga este cartão com você e entregue-o na recepção.||
|Atenciosamente,||
|________________________________________<br>Assinatura do profissional de saúde||
|Nome da Unidade de Saúde:||
|Telefone da Unidade de Saúde:||  
110

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST) iniciou- se com a reunião presencial para delimitação do escopo, no dia 31 de outubro de 2019. O objetivo dessa reunião foi a discussão da atualização do referido PCDT. Essa reunião presencial contou com a presença de médicos e outros profissionais de saúde especialistas na Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST) e colaboradores e técnicos do Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI/SVS/MS).  
A dinâmica da reunião foi conduzida com base no PCDT-IST vigente da Portaria SAS/SCTIE no 42, de 5 de outubro de 2018. Cada seção do PCDT-IST foi avaliada com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratarem de práticas clínicas estabelecidas. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT-IST, a relatoria do texto foi distribuída entre os profissionais de saúde especialistas de notório saber e com experiência bem sucedidas no cuidado e manejo das IST. Esses profissionais foram orientados a referenciar as recomendações, sempre que possível, com base em evidências científicas, meta-análises, revisões sistemáticas, estudos clínicos-epidemiológicos multicêntricos que pudessem respaldar as diretrizes atuais. No entanto, em algumas situações na área das IST, a literatura científica traz apenas estudos antigos ou poucas evidências robustas, o que faz-se necessário a opinião dos especialistas para a definição de recomendações nesses casos. A atualização das recomendações pelos especialistas no PCDT-IST vigente visaram qualificar a prática na assistência em IST e orientar os gestores em serviços de saúde do SUS.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O Protocolo foi atualizado pelo Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI/SVS) a partir da revisão de recomendações sugeridas pelo painel de especialistas com base em novos estudos na temática das IST. Os especialistas representaram diversas instituições de ensino e pesquisa, gestão em saúde e associações científicas que tem como foco a atenção integral aos casos de IST. As alterações foram revisadas pelo grupo técnico do DCCI e após finalizado texto, este foi reencaminhado para análise final dos especialistas da área.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
O documento foi apresentado na 83ª Reunião da Subcomissão de PCDT realizada no dia 22/09/2020. A versão atual do PCDT-IST já considera as solicitações desta Subcomissão.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Encaminhado para Consulta Pública.

---

<!-- METADADOS: doenca: Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis | secao: - Conitec -->
Considerando a versão vigente do PCDT para atenção integral às pessoas com infecções sexualmente transmissíveis (IST), partiu-se deste documento de base, o qual manteve a estrutura de metodologia, acrescentando dados referentes à atualização das evidências científicas sobre recomendações clínicas em manejo de IST, diretrizes internacionais e referências contidas no documento ao final de documento PCDT-IST.  
111

---

