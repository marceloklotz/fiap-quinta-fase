<!-- METADADOS: doenca: Hidradenite Supurativa | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 14, DE 11 DE SETEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hidradenite Supurativa.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a hidradenite supurativa no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n o 462/2019 e o Relatório de Recomendação n o 473 – agosto de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hidradenite Supurativa.  
Parágrafo único. O Protocolo, objeto deste artigo, que contém o conceito geral da hidradenite supurativa, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes  é de caráter nacional e deve ser utilizado</u> pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hidradenite supurativa.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
FRANCISCO DE ASSIS FIGUEIREDO DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **1. INTRODUÇÃO** -->
A hidradenite supurativa (HS), acne inversa ou “doença de Verneuil” é uma doença inflamatória, crônica e recorrente dos folículos pilosos. De causa multifatorial, a HS é influenciada por fatores intrínsecos como predisposição genética, alteração hormonal, hipertensão, dislipidemias ou resposta inflamatória sistêmica exacerbada; e fatores extrínsecos relacionados com obesidade, tabagismo, diabetes, atrito mecânico e o uso de alguns medicamentos como lítio, anticonceptivos, isotretinoína, entre outros<sup>1–3</sup> .  
As lesões são originadas a partir de hiperqueratose e oclusão folicular, seguido de dilatação pilossebácea, ruptura e extrusão do conteúdo folicular, o que desencadeia reação inflamatória secundária e afluxo de células inflamatórias com liberação de novas citocinas o que torna o processo contínuo, com a formação de abscessos e fístulas. Dentre as citocinas mais frequentemente encontradas destacam-se TNFα IL-6, IL-10, IL-12, IL-23 e IL-17<sup>2,4</sup> .  
O papel bacteriano não está totalmente elucidado na patogênese da HS<sup>5</sup> , contudo variedade de espécies bacterianas são isoladas nas lesões da HS<sup>5,5–7</sup> . Demonstrou-se que o microbioma da lesão de pele lesional e perilesional da HS é diferente de controles saudáveis e a população de bactérias pode variar, conforme a gravidade da doença<sup>8–10</sup> . Fístulas e tratos sinusais contribuem para a formação do biofilme, colonização bacteriana e infecção secundária que são responsáveis pela exacerbação da doença, supuração e extensão das lesões<sup>5,7,11</sup> .  
A HS se manifesta geralmente após a puberdade, durante a segunda ou terceira décadas de vida dos pacientes<sup>12</sup> . Apresenta-se com maior frequência em mulheres (3:1), acometendo principalmente as regiões axilar, da virilha, mamária e infra-mamária, com atenuação da atividade da doença com o início da menopausa. Nos homens afeta com maior frequência as regiões glútea, perianal, nuca e retroauricular, com maior atividade da doença até a quinta década de vida<sup>1,2</sup> .  
A recorrência das inflamações (2-3 nos últimos 6 meses) nesta doença pode acarretar em cicatrizes graves e consequentemente limitação ou incapacidade de movimento no local podendo variar de menor sensibilidade local e desconforto à incapacidade de se movimentar sem sentir dor, gerando grande impacto na qualidade de vida dos pacientes<sup>2,3,12–15</sup> .  
Estes pacientes também podem apresentar odor fétido, infecções bacterianas, impactando diretamente na vida social dos pacientes com HS.  A longo prazo, a HS está associada com complicações graves como fístulas na uretra, bexiga ou intestino reto, assim como artropatia,  
infecções como celulites, abscesso epidural, osteomielite sacral,   obstrução linfática, linfedema, anemia, hipoproteinemia, amiloidoses, carcinoma celular escamoso, depressão e suicídio<sup>1,4,12,16</sup> .  
Estudos sobre incidência e prevalência da HS apresentam grande variabilidade apontando incerteza quanto à verdadeira frequência da HS<sup>1,4,17</sup> . A prevalência pode variar de 0,00033% a 4,1%<sup>18</sup> e a incidência de 4 a 10 por 100.000 pessoas-ano<sup>4</sup> , sendo mais frequente na população afro-americana e hispânica<sup>19</sup> . No Brasil, estudo transversal realizado em 87 municípios, que representam 40% da população nacional, apontou prevalência de 0,41% (IC 95% 0,32 – 0,50), sem diferenças entre as regiões do país. A idade média dos indivíduos foi de 40,4 anos, com maior prevalência entre adolescentes (0,57%) e adultos (0,47%) do que crianças e idosos. Houve uma ligeira predominância do sexo feminino. Nesse estudo, a prevalência de acordo com a gravidade não foi avaliada<sup>17</sup> . Em estudos de base populacional, a prevalência de HS em estágio I é maior de 50%<sup>20,21</sup> . Em estudos feitos em ambulatórios de dermatologia, de hospital terciário, a prevalência de HS estágio III é abaixo de 30%<sup>22,23</sup> .  
Neste contexto, o presente documento tem como objetivo guiar os profissionais de saúde, em especial aqueles que atuam na atenção primária à saúde, quanto ao diagnóstico e tratamento ambulatorial da HS.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
L73.2 – Hidradenite supurativa

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **3.1. DIAGNÓSTICO CLÍNICO** -->
O diagnóstico é baseado na apresentação clínica da doença, que inclui lesões caraterísticas, em locais específicos e a recorrência de surtos definidos como fases de formação de nódulos intervaladas por um período de melhora. A **Figura 1** mostra a localização das lesões segundo o sexo<sup>15,24,25</sup> .  
O diagnóstico é baseado em 3 características<sup>4,12,15,26</sup> :  
- 1- História de lesões recorrentes dolorosas ou supurativas mais de 2 vezes em 6 meses;  
- 2- Localização anatômica típica: axila, virilha, região perineal e perianal, nádegas, dobras infra- e intermamárias;  
- 3- Lesões típicas: nódulos (inflamatório ou não, único ou múltiplos, doloroso ou profundos), tratos sinusais (inflamatórios ou não), abscessos, comedões e/ou cicatrizes (atróficas, em malha, vermelha, hipertrófica ou linear).  
Evidência de história familiar de HS, sem evidência microbiológica de patógenos ou com presença de microflora normal de pele nas lesões reforçam o diagnóstico de HS<sup>15</sup>  
Recomenda-se o encaminhamento para o Dermatologista de pacientes com HS refratária ou estágio de Hurley II e III<sup>26–29</sup> , conforme definido no item 4. Classificação.  
**Figura 1 - Localização das lesões na Hidradenite Supurativa em ambos os sexos.**  
<!-- Start of picture text -->
Cs)<br>ii<br>ify W<br><!-- End of picture text -->  
Fonte: Zouboulis et al., 2015<sup>15</sup> .  
Estudos apontam que o tempo do início da doença até o diagnóstico é de até 7,2 anos. Neste contexto, e dada a apresentação da doença com caraterísticas bem definidas, se faz necessário o diagnóstico oportuno para evitar o agravamento da HS, visando diminuir o impacto na qualidade de vida destes pacientes<sup>30</sup> .  
Outras doenças podem ter apresentação semelhante à da HS, sendo essencial o diagnóstico diferencial para o adequado diagnóstico, por meio de biópsia ou cultura bacteriana ( **Quadro 1** ).  
**Quadro 1 –** Diagnóstico diferencial da Hidradenite Supurativa.  
|**Diagnósticodiferencial**|**Características em comum**<br>**com a Hidradenite**<br>**Supurativa**|**Diferenciação**|
|---|---|---|
|Erupções cutâneas<br>ocasionadas pela<br>doença de Crohn|Fístulas,<br>abscessos<br>ou<br>cicatrizes perianais e genitais|Úlceras_“knife-cut”_(em forma de<br>corte de faca)_;_fístulas comunicam-<br>se com o trato gastrointestinal, sem<br>a presença de comedões|
|Acne|Cistos com pus, nódulos<br>inflamatórios, cicatrizes|Localização no rosto, costas e parte<br>superior do tórax, presença de<br>comedões|
|Doença pilonidal<br>interglútea|Formação de trato sinusal;<br>lesões edemaciadas,<br>inflamadas e dolorosas|Localização e recorrência das<br>lesões limitada à área interglútea|
|Piodermite, furúnculos,<br>carbúnculos e abscessos|Nódulos e abscessos;<br>drenagem purulenta; pode<br>ocorrer em áreas<br>intertriginosas|Principalmente devido a agente<br>infeccioso; sensação de ardência e<br>eritema perilesional; lesão<br>flutuante; drena no local da<br>incisão; condição transitória; de<br>distribuição aleatória; responde<br>rapidamente aos antibióticos|
|Granuloma inguinal<br>(donovanose)|Localizado nas pregas<br>genitais e inguinais|Úlceras vermelhas; presença de<br>tecido de granulação nas lesões;<br>sangra facilmente; presença de<br>corpos de Donovan (histologia);<br>ocasionado por<br>_Klebsiellagranulomatis_|
|Linfogranulomavenéreo|Localizado nas pregas<br>genitais e inguinais|Ocasionado por<br>_Chlamydiatrachomatis_(sorotipo<br>L1-L3)|
|Actinomicose|Fístulas ou tratos sinusais|Ocasionado por_Actinomyces_|  
|Doença da arranhadura|Lesões papulopustulares;|História de um arranhão ou|
|---|---|---|
|do gato|linfadenitegranulomatosa e|mordida de um gato, infecção por|
||supurativa, subaguda|_Bartonella_|
|Tuberculose cutânea|Drenagem purulenta;<br>abscessos; fístulas|Ocasionado por_Mycobacterium_|
|Esteatocistoma|Drenagem dos nódulos|Tumores foliculares também em|
|múltiplo|inflamados|superfícies convexas da pele|
|Metástase|Nódulos inflamados|Assimétrico, muitas vezes indolor|  
Fonte: Adaptado de Saunte&Jemec (2017)<sup>30</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **3.2 DIAGNÓSTICO LABORATORIAL** -->
Atualmente, não existem exames laboratoriais específicos para o diagnóstico de HS. Entretanto, velocidade de hemossedimentação e proteína C-reativa podem estar aumentadas em pacientes com HS e atividade inflamatória. Estes exames podem ser utilizados para melhor caracterização do quadro mas não são conclusivos<sup>15,24</sup> .  
A cultura microbiológica de amostras do abscesso e exsudato e o teste de sensibilidade aos antimicrobianos é recomendada sempre que houver sinais de infecção secundária, como celulite ou febre, independente do estágio da doença<sup>5,6,8,31</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **3.3. DIAGNÓSTICO POR IMAGEM** -->
A ultrassonografia de pele com transdutor de alta frequência pode auxiliar na avaliação dos abscessos, determinar a extensão dos túneis (fístulas) e relação com estruturas adjacentes. Já a ressonância magnética representa uma alternativa para a detecção de fístulas, em especial as que envolvem outros órgãos (fístulas dermointestinais, perianais, entre outras). Estes exames podem ser utilizados para avaliar a extensão  ou morfologia das lesões ou para diagnóstico diferencial com outras doenças<sup>15,24</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **4. CLASSIFICAÇÃO** -->
Atualmente existem vários modelos de classificação e estadiamento da doença<sup>2,4,25,32–34</sup> . Neste protocolo serão preconizadas as seguintes ferramentas:

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **<u>Ferramentas para classificação da doença</u>** -->
- Estágios de Hurley ( **Quadro 2** ):  
Trata-se de uma ferramenta amplamente utilizada, intuitiva e rápida que permite a classificação em três estágios, a saber:  
**Quadro 2 –** Estágios de Hurley  
|**Estágio**|**Descrição**|
|---|---|
|Estágio I|Abscesso único, ou múltiplos, porém sem fístulas ou cicatrizes|
|Estágio II|Abscesso recorrente único, ou múltiplos, separados, com formação de fístulas e<br>cicatrizes|
|Estágio III|Múltiplas fístulas interconectados e abscessos envolvendo ao menos uma área<br>anatômica completa|  
Todavia, esta ferramenta não permite avaliar a evolução do tratamento, não considera o  
número de áreas afetadas, a localização das lesões e o estado inflamatório.  
- _International Hidradenitis Suppurativa Severity Score System_ (IHS4):  
- Ferramenta para estratificação da gravidade da doença em três níveis (leve, moderada e  
grave). Esta avaliação considera a contagem de lesões atribuindo pesos diferentes segundo o tipo lesão (nódulo, abscesso ou fístula drenante). O cálculo é realizado da seguinte maneira:  
IHS4 = (n° de nódulos x 1) + (n° de abscessos x 2) + (n° de fístulas drenantes x 4)  
A doença é definida como leve quando a pontuação é inferior a 3, moderada entre 4 e 10 pontos e grave acima de 11 pontos.  
- _Physician´s Global Assessment_ (HS-PGA):  
- Ferramenta para avaliar a gravidade da doença em seis níveis (sem lesões, mínima, leve,  
moderada, grave e muito grave).  
|**Classificação**|**Definição**|
|---|---|
|Semlesões (score =|0 abscessos, 0 fístulas, 0 nódulos inflamatórios e 0 nódulos não|
|0)|inflamatórios|
|Mínima (score = 1)|0 abscessos, 0 fístulas, 0 nódulos inflamatórios e presença de nódulos<br>não inflamatórios|
|Leve (score = 2)|0 abscessos, 0 fístulas e 1-4 nódulos inflamatórios ou 1 abcesso ou<br>fístula e 0 nódulos não inflamatórios|
|Moderada(score<br>=|0 abscessos, 0 fístulas, e>5 nódulos inflamatórios; ou 1 abscesso ou|
|3)|fístula e>1 nódulo inflamatório; ou 2-5 abscessos ou fístulas e < 10<br>nódulos inflamatórios|
|Grave (score = 4)|2-5 abscessos ou fístulas e>10 nódulos inflamatórios|  
Muito grave (score > 5 abscessosoufístulas = 5)  
Fonte: van Rappard et al, 2016<sup>34</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **<u>Ferramenta para avaliar a resposta ao tratamento</u>** -->
- _Hidradenitis Suppurativa Clinical Response_ (HiSCR):  
Esta ferramenta avalia a gravidade da doença e permite definir um alvo terapêutico. É  
definida pelos três tipos de lesões:  
1. Abscesso: flutuante, com ou sem drenagem, sensível ou doloroso;  
2. Nódulos inflamatórios: doloroso, eritematoso, granuloma piogênico;  
3. Fístula de drenagem: tratos sinusais com comunicação na derme, drenando secreção  
- purulenta  
A resposta ao tratamento é definida como: redução de no mínimo 50% no quantitativo de abscessos e nódulos inflamatórios, sem aumento do número de abscessos e fístulas. Redução de 25% a 49% dos mesmos parâmetros é considerada resposta parcial.  São considerados não respondedores aqueles que apresentem menos de 25% de redução no HISCR<sup>35</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Adultos de ambos os sexos, maiores de 18 anos com diagnóstico de hidradenite supurativa de acordo com o item 3.1.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste protocolo os pacientes que apresentarem contraindicação absoluta a algum dos tratamentos farmacológicos propostos, conforme item 9. FÁRMACOS, seção 9.1.1. Contraindicações para cada medicamento usado para tratamento da HS.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **7. CASOS ESPECIAIS** -->
Para pacientes com doença hepática severa; processo desmielinizante; malignidades e desordens linfoproliferativas, assim como história de malignidades e idosos<sup>4</sup> , o tratamento com adalimumabe somente deve ser instituído em caso claramente necessário. Nessas situações, o médico deve ser consultado e o tratamento ser individualizado.  
Em caso de reativação de Hepatite B em portadores crônicos da doença; nova manifestação ou exacerbação de sintomas de doença desmielinizante do sistema nervoso central, incluindo esclerose múltipla, neurite óptica e doença desmielinizante periférica; surgimento de malignidade, incluindo linfoma; desordens hematológicas significativas, como pancitopenia e anemia aplásica; novos sintomas ou agravamento dos sintomas de insuficiência cardíaca; desenvolvimento de sintomas sugestivos de síndrome lúpus-símile, o uso do adalimumabe deve ser suspenso<sup>36</sup> .  
O tratamento de gestantes e de lactantes com adalimumabe é de responsabilidade do médico assistente, que deverá avaliar em quais situações o benefício supera o risco. O adalimumabe pode atravessar a placenta e entrar em contato com o recém-nascido em mulheres tratadas com o produto durante a gravidez. Consequentemente, estas crianças podem estar sob risco de infecção aumentado. Durante a lactação, o adalimumabe é excretado no leite humano. Os benefícios para o desenvolvimento e para a saúde provenientes da amamentação devem ser considerados juntamente à necessidade clínica da mãe de utilizar o adalimumabe<sup>36</sup> .  
A clindamicinadeve ser utilizada na gravidez apenas se claramente necessária e com  
orientação médica.  
A rifampicina deve ser utilizada na gravidez e na lactação apenas se claramente necessária e com a orientação médica.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8. TRATAMENTO** -->
<mark>O tratamento da HS inclui medidas de suporte, controle da dor, tratamento cirúrgico e medicamentoso, para os quais deve ser considerada a gravidade do quadro e a sintomatologia dos pacientes</mark><sup>1,3,16</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8.1. TRATAMENTO NÃO MEDICAMENTOSO** -->
<mark>O tratamento da HS varia de acordo com sua gravidade. Inclui higienização, redução de traumas, controle do peso, abandono do fumo e realização de curativos</mark><sup>4,37</sup> .  
<mark>A higienização local deve ser realizada de forma suave com sabonetes neutro e, em caso de odor fétido, uso de antisséptico. Deve ser realizada apenas com as mãos (sem panos ou esponjas) para evitar mais atrito e irritação no local da lesão</mark><sup>16,37</sup> .  
<mark>A redução de trauma no local da lesão, incluindo redução do calor, umidade, suor e atrito é importante para evitar o trauma folicular e a maceração local, a que pode levar à inflamação, obstrução dos folículos e sua ruptura. Assim, recomenda-se o uso de roupas soltas e ventiladas. Materiais sintéticos e justos devem ser evitados</mark><sup>16,37</sup> .  
Pacientes com HS podem utilizar curativos absorventes, que não irritem o local da lesão, com o intuito de diminuir o desconforto causado pelo exsudato das lesões supurativas, mantendo a superfície seca e livre de odores<sup>4,38</sup> .  
A incisão e drenagem é recomendada para pacientes que apresentam abscessos flutuantes com quadro importante de dor<sup>39</sup> .  Esses procedimentos são indicados para melhora do quadro de dor em abscessos  agudos<sup>5</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8.2. TRATAMENTO MEDICAMENTOSO** -->
O tratamento medicamentoso tem por objetivo atingir a meta terapêutica estabelecida pela ferramenta HiSCR ou a remissão. Também são desfechos importantes controlar a inflamação e  
surtos de infecção;  melhorar a qualidade de vida controlando a dor, o prurido e o odor; evitar a progressão da doença; preparar o campo para a cirurgia, reduzindo a inflamação  e delimitando o campo cirúrgico; abordar formas graves, extensas e sindrômicas da doença (em que a HS está associada a outras condições como doenças inflamatórias)<sup>40</sup> . Este inclui antibioticoterapia tópica, sistêmica e medicamento biológico anti-fator de necrose tumoral (anti-TNF)<sup>1,3,16,41</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8.2.1 Terapia tópica** -->
A terapia farmacológica tópica pode ser realizada com o uso da clindamicina gel 1%. Este medicamento é indicado para pacientes com HS localizada em estágios de Hurley I ou para lesões superficiais nos casos de agudização<sup>41,42</sup> .  
O medicamento deve ser utilizado por até o período máximo de 03 meses e apenas prolongado se indicado pelo especialista, destacando entre as reações adversas o prurido e a irritação de pele<sup>3,4,38,40</sup> .  
A clindamicina gel 1% foi incorporada no SUS para o tratamento de lesões superficiais na hidradenite supurativa<sup>58</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8.2.2 Terapia sistêmica** -->
Estas terapias sistêmicas são indicadas em caso de falha à terapia tópica nos doentes de HS estágio de Hurley I (IHS4 leve a moderada)  ou para os estágios Hurley II e III (IHS4 moderada a grave), de acordo com o fluxograma de tratamento ( **Figura 2** )<sup>35,38,40</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **<u>Tetraciclina</u>** -->
O uso da tetraciclina é recomendada em pacientes com HS com lesões tipo nódulo difusas (em estágio de Hurley I) sem presença de lesões inflamatórias profundas, por até 12 semanas na dose máxima de 500mg duas vezes por dia<sup>3,4,41,43,44</sup> .  
Deve ser ingerido apenas com água e não deve ser ingerido nenhum produto lácteo 2 horas antes e após a sua administração<sup>45</sup> .  
Dentre as reações adversas deste medicamento destacam-se a fotossensibilidade, pigmentação da pele e mucosa, efeitos gastrointestinais, vômitos, diarreia, prurido anal, candidíase oral, vulvovaginite, comprometimento renal que pode levar a toxicidade hepática, azotemia, hiperfosfatemia, acidose, o risco de resistência microbiana<sup>3,4,45</sup> .  
Este medicamento é contraindicado em mulheres grávidas, em mulheres que desejam engravidar e durante a lactação, pois trata-se de um medicamento teratogênico. Também é contraindicado o seu uso concomitante com contraceptivos orais e penicilina. O medicamento deve ser administrado com cautela em pacientes em uso de anticoagulantes<sup>3,4,46</sup>  
Apenas um antibiótico da mesma classe deve ser usado, em caso de falha terapêutica<sup>35</sup> .  
O cloridrato de tetraciclina 500 mg foi incorporado no SUS para o tratamento da hidradenite supurativa leve<sup>59</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **<u>Clindamicina associada a rifampicina</u>** -->
A clindamicina 300 mg cápsula e a rifampicina 300 mg cápsula são recomendadas para pacientes que não responderam ao tratamento com tetraciclinas ou em estágios de Hurley II ou III ou HS-PGA moderada e grave. Recomenda-se administrar 300 mg de clindamicina e 300 mg de rifampicina, por via oral,  duas vezes ao dia, durante 10 semanas<sup>3,4,35,38,40,44,47–50</sup> .  
Pacientes em uso deste tratamento podem desenvolver resistência à rifampicina e com tratamentos superiores a 10 semanas superinfecção por _Clostridium difficile_<sup>38</sup> .  
A clindamicina 300 mg e a rifampicina 300 mg foram incorporadas no SUS para o tratamento da hidradenite supurativa moderada a grave<sup>57</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **<u>Medicamento anti-TNF – Adalimumabe</u>** -->
O adalimumabe é indicado para pacientes adultos com HS ativa moderada a grave que falharam a terapia com antibióticos sistêmicos ou que apresentam intolerância ou contraindicação aos antibióticos sistêmicos.  
O esquema posológico recomendado é de 160 mg inicialmente (quatro injeções subcutâneas de 40 mg aplicadas em um dia ou divididos em duas injeções de 40mg por dois dias consecutivos), seguidos por 80 mg (duas injeções de 40mg) no dia 15 (duas semanas depois) e, uma injeção de 40 mg uma vez por semana a partir do dia 29 (duas semanas depois da segunda aplicação). Caso após 12 semanas de tratamento não houver resposta terapêutica (avaliada pelo índice HiSCR), a continuação da terapia deve ser avaliada<sup>35,40,41,51</sup> .  
Estudos apontaram melhores resultados com adalimumabe em comparação ao placebo para os desfechos: redução da dor, resposta clínica da HS mensurado pela ferramenta HiSCR; contagem total de abscessos e nódulos inflamatórios e HS-PGA<sup>51</sup> . Em relação aos eventos adversos, os estudos não apontaram diferenças estatisticamente significativas quando comparado ao grupo que utilizou placebo<sup>51</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **8.3. Resistência Antimicrobiana** -->
De acordo com o Plano de ação nacional de prevenção e controle da resistência aos antimicrobianos no âmbito da saúde única 2018-2022 (PAN-BR), o monitoramento da susceptibilidade de microrganismos aos antimicrobianos no âmbito da saúde humana é imprescindível para orientar protocolos clínicos e avaliar tendências epidemiológicas<sup>52</sup> .  
Assim, tendo em vista que HS é uma condição clínica cujo tratamento envolve medicamentos com atividade antibacteriana, e que pode cursar com infecção secundária, a coleta  
de material da lesão de HS para cultura microbiológica e teste de sensibilidade aos antimicrobianos é indicada sempre que houver sinais como celulite e febre.  
Alguns estudos avaliaram o percentual de resistência bacteriana a antibióticos utilizados para tratamento de HS em amostras de lesão e observaram variação de 33 a 84,7% de resistência para tetraciclina, de 51 a 66% para clindamicina<sup>6,8,31</sup> e 66% para rifampicina<sup>8</sup> .  
Apesar do significativo percentual de resistência bacteriana, Hessam et al (2016) apontam que o uso de antibióticos, como tetraciclina, parece exercer papel de imunomodulação importante para a melhora do quadro de HS. Nesse sentido, é importante ressaltar que, a despeito da susceptibilidade antimicrobiana em isolados de infecção secundária, o esquema de tratamento de pacientes com HS deverá sempre incluir os antibióticos preconizados para cada estágio de Hurley (item 8.2.3) e, quando houver necessidade, um outro antimicrobiano poderá ser adicionado para o tratamento da infecção secundária.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **9. FÁRMACOS** -->
- Fosfato de clindamicina 1% gel.  
- Cloridrato de tetraciclina 500mg cápsula  
- Cloridrato de clindamicina 300mg cápsula.  
- Rifampicina 300mg cápsula.  
- Adalimumabe 40 mg solução injetável.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **9.1. Esquemas de administração** -->
- Fosfato de Clindamicina 1%: aplicação tópica, 2 vezes ao dia.  
- Cloridrato de tetraciclina: 500mg, por via oral, em duas administrações (12/12h).  
- Cloridrato de clindamicina: 300 mg, por via oral, em duas administrações (12/12h).  
- Rifampicina: 300mg, por via oral, em duas administrações (12/12h).  
- Adalimumabe: a dose de indução recomendada é de 160 mg (quatro injeções subcutâneas de 40  
mg, administradas no 1º dia ou divididas em duas injeções de 40mg em 2 dias consecutivos), seguidas por administração de 80 mg (duas injeções subcutânea de 40mg) na 2º semana e, dose de manutenção de uma injeção de 40 mg por semana da 4º a 12º semana.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **9.1.1. Contraindicações** -->
**Fosfato de clindamicina 1%:** Hipersensibilidade conhecida ao medicamento, classe ou componentes; pacientes com antecedentes de enterite regional, colite ulcerativa ou colite induzida ou associada a antibióticos (incluindo colite pseudomembranosa). Não deve ser utilizado por mulheres grávidas ou durante a amamentação<sup>42</sup> .  
**Cloridrato de tetraciclina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes; na gestação e amamentação<sup>45</sup> .  
**Cloridrato de clindamicina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes e amamentação<sup>47–49</sup> .  
**Rifampicina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes. Não deve ser administrada simultaneamente com a combinação de saquinavir/ritonavir<sup>47–49</sup> .  
**Adalimumabe:** Hipersensibilidade conhecida ao medicamento, classe ou componentes; infecções graves devido a bactérias, micobactérias, infecções fúngicas invasivas (histoplasmose disseminada ou extrapulmonar, aspergilose, coccidioidomicose), virais, parasitárias ou outras infecções oportunistas<sup>4,36</sup> ;  tuberculoseativa e latente<sup>4</sup> ; insuficiênciacardíaca _New York Heart Association_ (NYHA) III e IV<sup>4,36</sup> ; vacinação com vírus vivo<sup>36</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **9.1.2. Tempo de tratamento – Critérios de interrupção** -->
O tratamento medicamentoso deverá ser prescrito conforme esquema de tratamento, contraindicações (itens 9.1 e 9.1.1), casos especiais (item 7) e monitorização (item 11) deste Protocolo.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **10. BENEFÍCIOS ESPERADOS** -->
Espera-se que o tratamento adequado contribua para a redução da frequência de novas lesões, controle da supuração, prevenção da progressão da doença, minimização da formação de cicatrizes, melhora dos sintomas e da qualidade de vida dos pacientes com esta doença<sup>40</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **11. MONITORIZAÇÃO** -->
A monitorização do tratamento deve contemplar a promoção da saúde e controle de comorbidades, realizados por equipe multidisciplinar com a participação, quando possível, de um médico com expertise no tema. A equipe deverá velar pelo controle do esquema terapêutico prescrito e a adesão do paciente ao tratamento, por meio de ações educativas e monitoramento clínico-laboratorial.  
Em mulheres em idade fértil, devem ser orientadas a não engravidar e aconselhadas a utilizar métodos contraceptivos. Se ocorrer a gravidez durante o período de tratamento, o medicamento deve ser suspenso imediatamente. Mulheres em uso de adalimumabe, devem fazer uso de contraceptivo por mínimo 5 meses após a última dose do medicamento<sup>4</sup> .  
Antes do início do uso do adalimumabe, devem-se excluir infecções graves devido a bactérias, micobactérias, infecções fúngicas invasivas (histoplasmose disseminada ou extrapulmonar, aspergilose, coccidioidomicose), virais, parasitárias ou outras infecções oportunistas; tuberculose ativa e latente; insuficiência cardíaca _New York Heart Association_ (NYHA) III e IV, com objetivo de adequado planejamento terapêutico e tratamento destes agravos, caso possível, antes de iniciar o mesmo.  
Alguns medicamentos recomendados para o tratamento da hidradenite supurativa podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
Antes do início do uso de adalimumabe e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas:  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia simples de tórax deve ser realizada para excluir a possibilidade de TB ativa.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose<sup>53</sup> no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de adalimumabe após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de adalimumabe pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
Para fins de acompanhamento, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- Para que o uso de adalimumabe não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com adalimumabe devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com adalimumabe devem manter o monitoramento com o IGRA.  
- Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomendase repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame  em uma nova amostra.  
A cobertura vacinal deve ser atualizada, antes do início do tratamento<sup>56</sup> . Pacientes em idade reprodutiva devem ser orientados quanto ao uso de métodos contraceptivos durante o tratamento.  
Revisões periódicas para avaliação de eficácia e segurança do tratamento devem ser realizadas utilizando a ferramenta HiSCR. Assim, na presença de eventos adversos, falha terapêutica ou remissão da doença, o tratamento deve ser reavaliado.  
Deve-se avaliar a resposta do tratamento com adalimumabe após 12 semanas, utilizando a ferramenta HiSCR. Recomenda-se a descontinuação do tratamento se o paciente apresentar uma redução menor de 25% da contagem total de abscessos e de nódulos inflamatórios, além de não apresentar aumento de abscessos e de fístulas com drenagem<sup>54</sup> . Para pacientes que apresentaram uma resposta parcial, ou seja uma redução de 25 a 50% pelo HiSCR, recomenda-se continuar o tratamento e reavaliar depois de 3 meses<sup>35</sup> . Na confirmação de reativação da doença, as recomendações deste Protocolo voltam a ser aplicáveis.  
Após o início do adalimumabe, recomenda-se a avaliação com hemograma completo a cada 6 meses; teste de função hepática a cada 6 meses e solicitar exames para hepatite se apresentar aumento do teste da função hepática; rastreamento para hepatites virais e HIV<sup>55</sup> e vacinação de acordo com o Programa Nacional de Imunizações<sup>56</sup> .

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **12. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Para a correta implementação deste documento, devem ser considerados os critérios de inclusão e exclusão deste PCDT, assim como o esquema terapêutico (doses prescritas, dispensadas, adequação terapêutica, duração e monitorização do tratamento).  
A identificação destes pacientes a tempo de evitar complicações depende da capacitação de profissionais da equipe multidisciplinar para complementar as estratégias de tratamento da HS ou da disponibilidade de médicos com experiência e treinamento nesta doença.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigenteem qual componente da Assistência Farmacêutica se encontram os medicamentospreconizados neste Protocolo.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **13. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **14. REFERÊNCIAS** -->
- 1 Smith MK, Nicholson CL, Parks-Miller A, Hamzavi IH. Hidradenitis suppurativa: an update on connecting the tracts. _F1000Research_ 2017; **6** : 1272.  
- 2 Martorell A, García-Martínez FJ, Jiménez-Gallo D, _et al._ Actualización en hidradenitis supurativa (I): epidemiología, aspectos clínicos y definición de severidad de la enfermedad. _Actas Dermo-Sifiliográficas_ 2015; **106** : 703–15.  
- 3 Gulliver W, Zouboulis CC, Prens E, Jemec GBE, Tzellos T. Evidence-based approach to the treatment of hidradenitis suppurativa/acne inversa, based on the European guidelines for hidradenitis suppurativa. _Rev Endocr Metab Disord_ 2016; **17** : 343–51.  
- 4 Zouboulis CC, Desai N, Emtestam L, _et al._ European S1 guideline for the treatment of hidradenitis suppurativa/acne inversa. _J Eur Acad Dermatol Venereol JEADV_ 2015; **29** : 619– 44.  
- 5 Alikhan A, Sayed C, Alavi A, _et al._ North American Clinical Management Guidelines for Hidradenitis Suppurativa: a Publication from the United States and Canadian Hidradenitis Suppurativa Foundations. Part I: Diagnosis, Evaluation, and the use of Complementary and Procedural Management. _J Am Acad Dermatol_ 2019; published online March 11. DOI:10.1016/j.jaad.2019.02.067.  
- 6 Matusiak Ł, Bieniek A, Szepietowski JC. Bacteriology of hidradenitis suppurativa - which antibiotics are the treatment of choice? _Acta Derm Venereol_ 2014; **94** : 699–702.  
- 7 Vinkel C, Thomsen SF. Hidradenitis Suppurativa: Causes, Features, and Current Treatments. _J Clin Aesthetic Dermatol_ 2018; **11** : 17–23.  
- 8 Bettoli V, Manfredini M, Massoli L, _et al._ Rates of antibiotic resistance/sensitivity in bacterial cultures of hidradenitis suppurativa patients. _J Eur Acad Dermatol Venereol JEADV_ 2019; **33** : 930–6.  
- 9 Guet-Revillet H, Jais J-P, Ungeheuer M-N, _et al._ The Microbiological Landscape of Anaerobic Infections in Hidradenitis Suppurativa: A Prospective Metagenomic Study. _Clin Infect Dis Off Publ Infect Dis Soc Am_ 2017; **65** : 282–91.  
- 10 Guet-Revillet H, Coignard-Biehler H, Jais J-P, _et al._ Bacterial Pathogens Associated with Hidradenitis Suppurativa, France. _Emerg Infect Dis_ 2014; **20** : 1990–8.  
- 11 Ring HC, Bay L, Kallenbach K, _et al._ Normal Skin Microbiota is Altered in Pre-clinical Hidradenitis Suppurativa. _Acta Derm Venereol_ 2017; **97** : 208–13.  
- 12 Hunger RE, Laffitte E, Läuchli S, _et al._ Swiss Practice Recommendations for the Management of Hidradenitis Suppurativa/Acne Inversa. _Dermatol Basel Switz_ 2017; **233** : 113–9.  
- 13 Ingram JR. Interventions for Hidradenitis Suppurativa: Updated Summary of an Original Cochrane Review. _JAMA Dermatol_ 2017; **153** : 458–9.  
- 14 Oliveira M, Gazzalle A, Narvaes G. Hidradenite supurativa (acne inversa): revisão da literatura e relato de caso sobre o tratamento cirúrgico de lesão pré-esternal. _Rev Bras Cir Plástica_ 2001; **30** : 487–94.  
- 15 Zouboulis CC, Del Marmol V, Mrowietz U, Prens EP, Tzellos T, Jemec GBE. Hidradenitis Suppurativa/Acne Inversa: Criteria for Diagnosis, Severity Assessment, Classification and Disease Evaluation. _Dermatol Basel Switz_ 2015; **231** : 184–90.  
- 16 Danby FW, Margesson LJ. Hidradenitis suppurativa. _Dermatol Clin_ 2010; **28** : 779–93.  
- 17 Ianhez M, Schmitt JV, Miot HA. Prevalence of hidradenitis suppurativa in Brazil: a population survey. _Int J Dermatol_ 2018; **57** : 618–20.  
- 18 Miller IM, McAndrew RJ, Hamzavi I. Prevalence, Risk Factors, and Comorbidities of Hidradenitis Suppurativa. _Dermatol Clin_ 2016; **34** : 7–16.  
- 19 Lee DE, Clark AK, Shi VY. Hidradenitis Suppurativa: Disease Burden and Etiology in Skin of Color. _Dermatology_ 2017; **233** : 456–61.  
- 20 Calao M, Wilson JL, Spelman L, _et al._ Hidradenitis Suppurativa (HS) prevalence, demographics and management pathways in Australia: A population-based cross-sectional study. _PloS One_ 2018; **13** : e0200683.  
- 21 Vinding GR, Miller IM, Zarchi K, Ibler KS, Ellervik C, Jemec GBE. The prevalence of inverse recurrent suppuration: a population-based study of possible hidradenitis suppurativa. _Br J Dermatol_ 2014; **170** : 884–9.  
- 22 Andrade TCPC de, Vieira BC, Oliveira AMN, Martins TY, Santiago TM, Martelli ACC. Hidradenitis suppurativa: epidemiological study of cases diagnosed at a dermatological reference center in the city of Bauru, in the Brazilian southeast State of São Paulo, between 2005 and 2015. _An Bras Dermatol_ 2017; **92** : 196–9.  
- 23 Katoulis AC, Liakou AI, Rotsiamis N, _et al._ Descriptive Epidemiology of Hidradenitis Suppurativa in Greece: A Study of 152 Cases. _Skin Appendage Disord_ 2017; **3** : 197–201.  
- 24 Beshara MA. Hidradenitis suppurativa: A Clinician’s Tool for Early Diagnosis and Treatment. _Nurse Pract_ 2010; **35** : 24.  
- 25 van der Zee HH, Jemec GBE. New insights into the diagnosis of hidradenitis suppurativa: Clinical presentations and phenotypes. _J Am Acad Dermatol_ 2015; **73** : S23-26.  
- 26 Vekic DA, Cains GD. Hidradenitis suppurativa - Management, comorbidities and monitoring. _Aust Fam Physician_ 2017; **46** : 584–8.  
- 27 Lee EY, Alhusayen R, Lansang P, Shear N, Yeung J. What is hidradenitis suppurativa? _Can Fam Physician_ 2017; **63** : 114–20.  
- 28 García-Martínez FJ, Pascual JC, López-Martín I, _et al._ Actualización en hidrosadenitis supurativa en Atención Primaria. _Med Fam SEMERGEN_ 2017; **43** : 34–42.  
- 29 Collier F, Smith RC, Morton CA. Diagnosis and management of hidradenitis suppurativa. _BMJ_ 2013; **346** : f2121.  
- 30 Saunte DML, Jemec GBE. Hidradenitis Suppurativa: Advances in Diagnosis and Treatment. _JAMA_ 2017; **318** : 2019–32.  
- 31 Hessam S, Sand M, Georgas D, Anders A, Bechara FG. Microbial Profile and Antimicrobial Susceptibility of Bacteria Found in Inflammatory Hidradenitis Suppurativa Lesions. _Skin Pharmacol Physiol_ 2016; **29** : 161–7.  
- 32 Zouboulis CC, Tzellos T, Kyrgidis A, _et al._ Development and validation of the International Hidradenitis Suppurativa Severity Score System (IHS4), a novel dynamic scoring system to assess HS severity. _Br J Dermatol_ 2017; **177** : 1401–9.  
- 33 Kimball AB, Jemec GBE, Yang M, _et al._ Assessing the validity, responsiveness and meaningfulness of the Hidradenitis Suppurativa Clinical Response (HiSCR) as the clinical endpoint for hidradenitis suppurativa treatment. _Br J Dermatol_ 2014; **171** : 1434–42.  
- 34 van Rappard DC, Mekkes JR, Tzellos T. Randomized Controlled Trials for the Treatment of Hidradenitis Suppurativa. _Dermatol Clin_ 2016; **34** : 69–80.  
- 35 Zouboulis CC, Bechara FG, Dickinson-Blok JL, _et al._ Hidradenitis suppurativa/acne inversa: a practical framework for treatment optimization - systematic review and recommendations from the HS ALLIANCE working group. _J Eur Acad Dermatol Venereol JEADV_ 2019; **33** : 19–31.  
- 36 Abbvie. Adalimumabe. http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=2132908 2017&pIdAnexo=9972862 (accessed May 19, 2019).  
- 37 European Dermatology Forum. Hidradenitis Suppurativa Guidelines: Guideline Summary, Algorithm, Benefit-to-Risk Ratio. https://emedicine.medscape.com/article/1073117guidelines (accessed Nov 21, 2018).  
- 38 Vekic DA, Frew J, Cains GD. Hidradenitis suppurativa, a review of pathogenesis, associations and management. Part 1. _Australas J Dermatol_ 2018; **59** : 267–77.  
- 39 Scuderi N, Monfrecola A, Dessy LA, Fabbrocini G, Megna M, Monfrecola G. Medical and Surgical Treatment of Hidradenitis Suppurativa: A Review. _Skin Appendage Disord_ 2017; **3** : 95–110.  
- 40 Ramos R. Consensus on the treatment of hidradenitis suppurativa – Brazilian Society of Dermatology*. _Bras Dermatol_ 2019; **94** . http://www.anaisdedermatologia.org.br//detalheartigo/103227.  
- 41 Ingram JR, Woo PN, Chua SL, _et al._ Interventions for hidradenitis suppurativa: a Cochrane systematic review incorporating GRADE assessment of evidence quality. _Br J Dermatol_ 2016; **174** : 970–8.  
- 42 Clemmensen OJ. Topical treatment of hidradenitis suppurativa with clindamycin. _Int J Dermatol_ 1983; **22** : 325–8.  
- 43 Alhusayen R, Shear NH. Scientific evidence for the use of current traditional systemic therapies in patients with hidradenitis suppurativa. _J Am Acad Dermatol_ 2015; **73** : S42-46.  
- 44 Ingram JR, Collier F, Brown D, _et al._ British Association of Dermatologists guidelines for the management of hidradenitis suppurativa (acne inversa) 2018. _Br J Dermatol_ 2018; published online Dec 15. DOI:10.1111/bjd.17537.  
- 45 Teuto. Tetraciclin.  
- http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=1085054 2015&pIdAnexo=2997108 (accessed Feb 5, 2019).  
- 46 Sandoz do Brasil Ind. Farm. Ltda. Doxiciclina. http://www.anvisa.gov.br/datavisa/fila_bula/frmVisualizarBula.asp?pNuTransacao=4600882 017&pIdAnexo=5453987 (accessed Feb 5, 2019).  
- 47 van der Zee HH, Boer J, Prens EP, Jemec GBE. The effect of combined treatment with oral clindamycin and oral rifampicin in patients with hidradenitis suppurativa. _Dermatol Basel Switz_ 2009; **219** : 143–7.  
- 48 Ochi H, Tan LC, Oon HH. The effect of oral clindamycin and rifampicin combination therapy in patients with hidradenitis suppurativa in Singapore. _Clin Cosmet Investig Dermatol_ 2018; **11** : 37–9.  
- 49 Mendonça CO, Griffiths CEM. Clindamycin and rifampicin combination therapy for hidradenitis suppurativa. _Br J Dermatol_ 2006; **154** : 977–8.  
- 50 Bettoli V, Join-Lambert O, Nassif A. Antibiotic Treatment of Hidradenitis Suppurativa. _Dermatol Clin_ 2016; **34** : 81–9.  
- 51 Brasil. Adalimumabe para o tratamento da hidradenite supurativa ativa moderada a grave. Relatório de Recomendação n° 395. 2018. Disponível em: http://conitec.gov.br/images/Relatorios/2018/Relatorio_Adalimumabe_HidradeniteSupurativ a.pdf.  
- 52 Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Plano de ação nacional de prevenção e controle da resistência aos antimicrobianos no âmbito da saúde única 2018-2022 (PAN-BR). Brasília, 2018.  
- 53 Brasil, Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância Epidemiológica. Manual de recomendações para o controle da tuberculose no Brasil. Brasilia: Ministério da Saúde, 2011 http://bvsms.saude.gov.br/bvs/publicacoes/manual_recomendacoes_controle_tuberculose_br asil.pdf (accessed Feb 4, 2019).  
- 54 2 The technology | Adalimumab for treating moderate to severe hidradenitis suppurativa | Guidance | NICE. https://www.nice.org.uk/guidance/ta392/chapter/2-The-technology (accessed May 3, 2019).  
- 55 Emer JJ, Frankel A, Zeichner JA. A practical approach to monitoring patients on biological agents for the treatment of psoriasis. _J Clin Aesthetic Dermatol_ 2010; **3** : 20–6.  
- 56 Brasil. Ministério da Saúde. Calendario Nacional de Vacinação. http://www.saude.gov.br/saude-de-a-z/vacinacao/calendario-vacinacao (accessedJune 13, 2019).  
57. Brasil. Clindamicina 300 mg associada com rifampicina 300 mg para o tratamento de hidradenite supurativa moderada.Relatório de Recomendação n° 456.2019. Disponível em:http://conitec.gov.br/images/Relatorios/2019/Relatorio_ClindamicinaRifampicina_Hidra deniteSupurativa.pdf  
- 58.Brasil. Clindamicina 1% tópica para o tratamento de lesões superficiais na hidradenite supurativa. Relatório de Recomendação n° 457. 2019. Disponível em: http://conitec.gov.br/images/Relatorios/2019/Relatorio_ClindamicinaTopica_HidradeniteSup urativa.pdf  
59. Brasil. Tetraciclina 500 mg para o tratamento de hidradenite supurativa leve. Relatório de Recomendação n° 458. 2019. Disponível em:http://conitec.gov.br/images/Relatorios/2019/Relatorio_Tetraciclina_HidradeniteSupurati va.pdf  
<!-- Start of picture text -->
Fluxograma de tratamento<br>Hidradenite Supurativa<br>sinais de infece3o secundaria’, manejo da dor, obesidade,<br>ae eit meee<br>(level— (Modereds)*= —(Gravel<br>Sees [=<br>| “|=D<br>.<br>=<br>pa Zi Eeatividade<br>atividadeate da doenes: capeatividade daoaeedoenca [== |<br>__l_. C i!<br>£ a Z ee ote<br>| PS<br>an<br>mon<br>eae<br>L , (eee<br>pra<br>——eSereEeEeamamaaee<br>a SS<br>“Pode ser utilizada também lesdes superficiais nos casos de agudiza¢30_<br>‘A cultura de bactérias do material da lesSo de HS com teste de sensibilidade para antibiéticos ¢ recomendada sempre que houver sinais de infeccSo secundéria<br>eee 2S Se ces<br><!-- End of picture text -->  
**Figura 2** – Fluxograma de Tratamento da Hidradenite Supurativa  
Fontes: Referências 35,38,40

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ADALIMUMABE, CLINDAMICINA, RIFAMPICINA E TETRACICLINA  
Eu, _______________________________________________  [nome do(a) paciente], declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **fosfato de clindamicina, cloridrato de tetraciclina, cloridrato de clindamicina, rifampicina e adalimumabe** , indicados para o tratamento da **hidradenite supurativa** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico  
____________________________________________________________ (nome do prescritor).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas da doença;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
**- Fosfato de clindamicina 1%:** Hipersensibilidade conhecida ao medicamento, classe ou componentes; pacientes com antecedentes de enterite regional, colite ulcerativa ou colite induzida ou associada a antibióticos (incluindo colite pseudomembranosa). Não deve ser utilizado por mulheres grávidas ou durante a amamentação;  
**- Cloridrato de tetraciclina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes, na gestação e amamentação;  
**- Cloridrato de clindamicina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes e amamentação;  
**- Rifampicina:** Hipersensibilidade conhecida ao medicamento, classe ou componentes. Não deve ser administrada simultaneamente com a combinação de saquinavir/ritonavir;  
**- Adalimumabe:** Hipersensibilidade conhecida ao medicamento, classe ou componentes; infecções graves devido a bactérias, micobactérias, infecções fúngicas invasivas (histoplasmose disseminada ou extrapulmonar, aspergilose, coccidioidomicose), virais, parasitárias ou outras infecções oportunistas<sup>4,36</sup> ;  tuberculoseativa e latente<sup>4</sup> ; insuficiênciacardíaca _New York Heart Association_ (NYHA) III e IV<sup>4,36</sup> ; vacinação com vírus vivo<sup>36</sup> .  
Estou ciente de que o medicamento somente pode ser utilizado por mim, comprometendome a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim (    ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (    ) Fosfato de clindamicina 1% (    ) Rifampicina  
- (    ) Cloridrato de tetraciclina  
- (    ) Adalimumabe  
- (    ) Cloridrato de clindamicina  
<!-- Start of picture text -->
Local: Data:<br>Nome do paciente:<br>Cardio Nacional do SUS:<br>‘Nome do responsdvel legal<br>Documento de identificagao do responsavel legal:<br>Assinatura do paciente ou do responsavel legal:<br>Médico: CRM: RS:<br>‘Assinatura e carimbo do médico<br>Data:<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME)vigente  
em qual componente da Assistência Farmacêutica se encontram os medicamentospreconizados neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Hidradenite Supurativa | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Depois da sua publicação, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Hidradenite Supurativa, pela necessidade de atualizar o item de Monitoramento da infecção por tuberculose ativa e rastreio da infecção por tuberculose latente (ILTB), de modo a harmonizar a orientação em todos os PCDT que preconizam o uso de medicamentos modificadores do curso da doença (MMCD) biológicos ou MMCD sintéticos-alvo específico.  
O tema foi apresentado como informe à 125ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 20 de maio de 2025, e também à 141ª Reunião Ordinária da Conitec, em junho de 2025.

---

