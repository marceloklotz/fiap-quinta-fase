<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: Geral -->
<!-- Start of picture text -->
Tae<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
PORTARIA CONJUNTA nº 13, DE 13 DE AGOSTO DE 2020  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Lateral Amiotrófica.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso das suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a esclerose lateral amiotrófica no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 519/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 527 – Junho de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Esclerose Lateral Amiotrófica.  
Parágrafo único.  O Protocolo objeto deste art., que contém o conceito geral da esclerose lateral amiotrófica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e</u> deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da esclerose lateral amiotrófica.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.151/SAS/MS, de 11 de novembro de 2015, publicada no Diário Oficial da União nº 216, de 12 de novembro de 2015, seção 1, página 65.  
ANEXO

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **1.  INTRODUÇÃO** -->
A esclerose lateral amiotrófica (ELA) é uma doença do neurônio motor (DNM) e uma das principais doenças neurodegenerativas ao lado das doenças de Parkinson e Alzheimer. Sua incidência na população é heterogênea e varia de 0,73 a 1,89 casos por 100.000 pessoas ao ano no sul da Ásia e no norte da Europa, respectivamente<sup>1</sup> (PMID: 27185810)<sup>2,3</sup> . A idade é o fator preditivo mais importante para a sua ocorrência, sendo mais prevalente nos pacientes entre 55 e 75 anos de idade<sup>4</sup> . Tratase de uma doença progressiva que envolve a degeneração do sistema motor em vários níveis: bulbar, cervical, torácico e lombar<sup>5</sup> .  
, frequente - espinhal<sup>5</sup> .  
, boca, garga , tais como aqueles dos membros (superiores e inferiores), tronco, pescoço, bem como do diafragma<sup>6</sup> .  
Acredita-se que, por ocasião do primeiro sintoma de ELA, mais de 80% dos neurônios motores já tenham sido perdidos<sup>7</sup> . Mais de 90% dos casos são esporádicos e a maior parte dos casos familiares apresenta herança autossômica dominante, com vários genes e mutações já identificados<sup>8,9</sup> . A sobrevida média da ELA é de 3 a 5 anos. Na ausência da ventilação mecânica prolongada, a porcentagem de sobreviventes em 10 anos é de 8% a 16%<sup>10</sup> , podendo chegar a 15 anos ou mais com a ajuda do suporte ventilatório<sup>11</sup> .  
O quadro clínico da ELA reflete a perda de neurônios motores localizados no córtex (NMS) e núcleos do tronco encefálico ou corno anterior da medula cervical torácica e lombossacra (NMI).  
A **Tabela 1** traz os principais achados clínicos relacionados à perda de neurônios motores superiores e inferiores nessas regiões.  
**<mark>Tabela 1</mark>** <mark>- Achados clínicos relacionados à perda de NMS e NMI</mark><sup>12</sup> <mark>.</mark>  
||Neurônio motor superior (NMS)|Neurônio motor inferior (NMI)|
|---|---|---|
|Bulbar|Incontinência emocional (choro e riso|Disartria flácida|
||incontroláveis)|Disfagia|
||Disartria espástica|Atrofia e fasciculações da|
||Disfagia (especialmente fase oral)<br>Hiperreflexia (masseter, orbicular da|língua|  
<mark>boca, refluxo nauseoso exacerbado)</mark>  
|Espinhal|Hiperreflexia tendinosa|Fraqueza|
|---|---|---|
||Espasticidade|Atrofia muscular|
||Sinal de Babinsky|Fasciculações|
||Redução da agilidade|Câimbras|  
Além dos sinais e sintomas diretamente causados pela perda neuronal, os pacientes apresentam uma série de achados clínicos indiretamente relacionados à doença, como alterações psicológicas e do sono, constipação, sialorreia, espessamento de secreções mucosas, sintomas de hipoventilação crônica e dor. A disfunção sensitiva (perda de sensibilidade) é incompatível com o diagnóstico de ELA, a não ser que faça parte de um distúrbio subjacente. Apesar de exames cognitivos detalhados poderem mostrar anormalidades em até 50% dos pacientes, quadros de demência propriamente dita são incomuns. Quando ocorre, tendem a ser semelhante à demência frontotemporal<sup>13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da esclerose lateral amiotrófica. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
G12.2 Doença do neurônio motor

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **3.1. Clínico** -->
O diagnóstico da ELA é evidente nos pacientes com longa evolução da doença e sinais e sintomas generalizados. O diagnóstico precoce da doença, quando o paciente tem apenas sintomas focais em uma ou duas regiões (bulbar, membro superior, tronco ou membro inferior), pode ser difícil e dependerá da presença de sinais em outras regiões afetadas e de várias investigações seriadas<sup>14,15</sup> . O tempo médio do início dos sintomas até a confirmação diagnóstica é de aproximadamente 10 a 13 meses<sup>16</sup> . O diagnóstico da ELA é feito com base na presença de sinais de acometimento do NMI e NMS concomitantes em diferentes regiões. Os critérios de _El Escorial_ revisados classificam os diagnósticos em várias categorias<sup>17</sup> :  
- ELA DEFINITIVA  
- Sinais de NMS e NMI em três regiões (bulbar, cervical, torácica ou lombossacral).  
ELA PROVÁVEL  
- Sinais de NMS e NMI em duas regiões (bulbar, cervical, torácica ou lombossacral) com algum sinal de NMS rostral aos sinais de NMI.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: ELA PROVÁVEL COM SUPORTE LABORATORIAL -->
- Sinais de NMS e NMS em uma região ou sinais de NMS, em uma ou mais regiões, associados à evidência de desnervação aguda na eletroneuromiografia (ENMG) em dois ou mais segmentos.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: ELA POSSÍVEL -->
- Sinais de NMS e NMI em uma região somente.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: ELA SUSPEITA -->
- Sinais de NMI em uma ou mais regiões (bulbar, cervical, torácica ou lombossacral).  
- Sinais de NMS em uma ou mais regiões (bulbar, cervical, torácica ou lombossacral).  
- Em todas as modalidades deve haver evidência de progressão da doença e ausência de sinais sensitivos (a não ser que faça parte de um distúrbio subjacente).

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **3.2.   Exames complementares** -->
Deverão ser realizados exames complementares para auxiliar no diagnóstico da ELA e na exclusão de outras doenças sistêmicas que possam mimetizá-la. Para o correto diagnóstico, todo o paciente com suspeita de ELA deve possuir os seguintes exames complementares com resultados compatíveis com essa doença<sup>18</sup> :  
- ENMG de quatro membros com presença de desnervação em mais de um segmento e neurocondução motora e sensitiva normais (exceto quando houver uma polineuropatia associada);  
- hemograma completo, ureia, creatinina, aminotransferases/transaminases (ALT/TGP e AST/TGO) séricas e tempo de protrombina devem estar dentro da normalidade.  
Além, podem, em casos especiais e a critério do médico assistente, ser solicitados os respectivos exames:  
- Ressonância magnética (RM) de encéfalo e junção crânio-cervical, que não deve mostrar lesão estrutural que expliquem os sintomas;  
- proteína C-reativa e eletroforese de proteínas séricas, cujo resultado deve estar dentro da normalidade.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **3.3.   Diagnóstico diferencial** -->
Nos estágios iniciais da doença, em que podem haver sinais mínimos de disfunção dos NMS e NMI, a ELA pode ser confundida com uma série de outras doenças ou condições, reclamando diagnósticos diferenciais ( **Tabela 2**<sup>19</sup> ).  
**<mark>Tabela 2</mark>** <mark>- Diagnóstico diferencial da ELA</mark>  
<mark>Bulbar Espinhal</mark>  
|Neurônio motor<br>superior|Doença<br>cerebrovascula<br>r<br>Esclerose<br>múltipla<br>Irradiação do<br>sistema<br>nervoso central|Adrenomieloneuropatia<br>Ataxia espino-cerebelar<br>Deficiência de hexosaminidase A<br>Deficiência de vitamina B12 ou cobre<br>Doença cerebrovascular<br>Esclerose múltipla<br>Hipertireoidismo<br>Infecção por HIV, HTLV, Sífilis<br>Irradiação do sistema nervoso<br>central<br>Latirismo<br>Malformação de Arnold-Chiari<br>Mielopatia (compressiva, pós-radiação,<br>inflamatória, tumoral)<br>Paraparesia espástica hereditária|
|---|---|---|
|Neurônio motor<br>inferior|Miastenia<br>gravis<br>Seringobulbia<br>Distrofia óculo-<br>faríngea|Hipertireoidismo<br>Hiperparatireoidismo<br>Intoxicação por metais pesados<br>Deficiência de hexosaminidase A<br>Fasciculações benignas<br>Atrofia monomélica<br>Atrofia muscular espinhal<br>Neuropatia motora multifocal com<br>bloqueio de condução<br>Polineuropatia inflamatória<br>desmielinizante crônica<br>Miopatia inflamatória<br>Doença de Pompe|

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **4.  CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem os critérios diagnósticos para ELA definitiva, ELA provável ou ELA provável com suporte laboratorial, avaliados por médico especialista em neurologia e com laudo médico detalhado. Também serão incluídos os pacientes que apresentarem ELA suspeita pelos critérios de _El Escorial_ revisados e se incluam entre os Casos Especiais (ver o item 6).

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **5.  CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem uma das seguintes condições: ELA possível ou suspeita pelos critérios de El Escorial que não se enquadram nos Casos Especiais (vide item 6).

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **6.  CASOS ESPECIAIS** -->
Quando o paciente tiver um familiar de primeiro grau afetado pela ELA, o exame genético focado nas alterações mais prevalentes na população brasileira é indicado, bem como o aconselhamento genético<sup>18,20</sup> .  
Pacientes com doenças do neurônio motor e ELA suspeita pelos critérios de _El Escorial_ revisados– atrofia muscular progressiva (AMP), esclerose lateral primária (ELP), paralisia bulbar progressiva (PBP) e atrofia muscular bulboespinhal (doença de Kennedy) – também devem ser tratados, visto que podem se beneficiar do tratamento específico com riluzol e demais medidas terapêuticas preconizadas neste Protocolo<sup>21</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **6.1. Atrofia muscular progressiva (AMP)** -->
- , envolvendo, progressivamente, membros inferiores e região bulbar. Inexistem se distinguir sob critérios puramente c _post mortem_ , pela<sup>21</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **6.2.   Esclerose lateral primária (ELP)** -->
- a de acometimento de qualquer outra parte do sistema nervoso exceto os tratos córtico-bulbar e córtico-espinhal. Inexiste          , pelo menos nas etapas iniciais da doença, de acomet , do NMI. Clinicame             - (quadro pseudobulbar)<sup>21</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **6.3.   Paralisia bulbar progressiva (PBP)** -->
A PBP, relacionada a ac                                          , caracteriza-se por compromet , acompanhando-se de fraqueza, atrofia e fascic                 . Comprometimento . Associadamente, sinais de ac<sup>21</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **6.4.   Atrofia muscular bulboespinhal (doença de Kennedy)** -->
Os principais aspectos que diferenciam a doença de Kennedy da ELA são a quase exclusividade da ocorrência entre homens , diabete melito e doenças da tireoide . Cerca de 1 entre 25 pacientes i<sup>21</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.   Tratamento não medicamentoso** -->
Entre todas as condutas terapêuticas não medicamentosas, o suporte ventilatório não invasivo, nas suas várias modalidades, é a que mais aumenta a sobrevida e a qualidade de vida do paciente com ELA, sendo inclusive possivelmente  
superior ao uso de riluzol<sup>22</sup> . Outra prática com benefícios prováveis no aumento da sobrevida e da qualidade de vida é o treinamento muscular inspiratório<sup>23</sup> . Exercícios físicos de leve intensidade parecem ser benéficos e não prejudiciais como se acreditava anteriormente<sup>24</sup> . Inexistem evidências suficientes para a recomendação do uso de equipamentos com interfaces cérebro-computador<sup>25</sup> ou estimulação magnética transcraniana repetitiva<sup>26</sup> que possam atenuar os sinais e sintomas motores da doença. Da mesma forma, a suplementação de creatina parece não auxiliar os pacientes com ELA<sup>27</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.1.   Suporte ventilatório** -->
A principal causa de morte por ELA é a insuficiência respiratória<sup>28</sup> . A fraqueza muscular acomete a musculatura respiratória, tendo como consequência a ventilação inadequada dos pulmões (hipoventilação), que causa aumento dos níveis de dióxido de carbono (PaCO2) no sangue, caracterizando a hipercapnia. Esta fraqueza leva a uma respiração cada vez mais superficial e rápida com sintomas crônicos de hipoventilação alveolar. Os sinais de hipoventilação ocorrem durante o sono REM, e em uma fase mais avançada da doença manifestam-se no período diurno. A fraqueza da musculatura expiratória combinada com inadequadas insuflações dos pulmões impede a eficácia da tosse e limpeza de vias aéreas, alterando a resistência das vias aéreas e aumentando o risco de desenvolvimento de atelectasias e pneumonia. A fraqueza da musculatura bulbar (musculatura de orofaringe e laringe) pode afetar a habilidade da fala, deglutição e limpeza de secreções de vias aéreas aumentando a possibilidade de aspirações e, consequentemente, quadros de infecções respiratórias. Há evidência de que o percentual da capacidade vital lenta se correlaciona moderadamente com progressão funcional da doença medida pela _ALS Functional Rating Scale_ : r de Pearson = 0,55 (p = 0,0001)<sup>29</sup> .  
**7.1.1.1. Empilhamento de ar**  
A terapia de hiperinsuflação manual é um método para a prevenção ou tratamento das microatelectasias ou atelectasias, proporcionando melhora da complacência pulmonar, da caixa torácica e auxiliando no aumento do fluxo da tosse. Quando os pacientes perdem a capacidade espontânea para insuflar os pulmões até a capacidade máxima, é necessária assistência. Estudos recomendam iniciar a terapia com empilhamento de ar o mais precoce possível, antes da capacidade vital atingir 70% do previsto.<sup>30</sup>  
Para pacientes com comprometimento da musculatura bulbar foi demonstrada a importância de realizar a insuflação passiva dos pulmões por meio de reanimador manual, mesmo que tenham comprometimento grave da função glótica e da musculatura de inervação bulbar. Os pacientes com capacidade vital baixa são os que mais obtêm benefícios com a técnica de insuflação, com um aumento significativo do volume corrente. O exercício de empilhamento de ar melhora a efetividade da tosse, aumenta a intensidade da voz, melhora ou aumenta a complacência pulmonar e evita as microatelectasias<sup>30</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.1.2. Ventilação mecânica não invasiva** -->
A redução da força muscular inspiratória, que resulta em ventilação alveolar ineficaz, e a fraqueza dos músculos expiratórios, que leva a uma remoção ineficaz de secreções, são causas de insuficiência respiratória crônica, que é potencialmente fatal. Os benefícios da ventilação mecânica (VM) são: a resolução dos sinais e sintomas de hipoventilação noturna (má qualidade do sono, cefaleia matinal,  
hiperssonolência diurna, fadiga, ortopneia), a melhora das trocas gasosas, o aumento do fluxo de ar, a melhora ou manutenção da complacência pulmonar, a redução dos quadros de infecções respiratórias, o aumento da sobrevida e a melhora da qualidade de vida<sup>28</sup> .  
As diretrizes atuais da Academia Americana de Neurologia sugerem iniciar suporte ventilatório em situações de capacidade vital abaixo de 50% do previsto<sup>31</sup> . A _American Thoracic Society_ recomenda que sejam seguidos os seguintes critérios: sintomas de hipoventilação, hipercapnia (>45 mmHg), dessaturação de oxigênio no período noturno com índices menores que 88% por 5 minutos consecutivos, pressão inspiratória máxima (PImáx) menor que 60 cmH20 e capacidade vital forçada (CVF) menor que 50% do predito<sup>32</sup> .  
Na prática clínica, os sinais e sintomas de hipoventilação alveolar são soberanos para a indicação da ventilação.  
Recomenda-se inicialmente a ventilação noturna por meio de ventiladores pressóricos de dois níveis de pressão e frequência respiratória, conhecidos como suporte ventilatório. Com a evolução da doença, os pacientes passam a fazer uso da ventilação em alguns períodos diurnos. Os equipamentos disponíveis no mercado têm a classificação de uso e aprovação da ANVISA de acordo com o dependência ventilatória e número de horas de uso<sup>33</sup> .  
Um aspecto a ser considerado é que em situações de intercorrência, como intervenções cirúrgicas, gastrostomia endoscópica e outros, os pacientes com DNM/ELA que estejam intubados não necessariamente devem ser traqueostomizados. Há a possibilidade de manter os pacientes em ventilação mecânica não invasiva desde que sejam submetidos ao protocolo de extubação<sup>34</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.1.3. Ventilação mecânica invasiva** -->
Os pacientes com DNM/ELA, principalmente os com comprometimento da musculatura de inervação bulbar, com quadro de moderado a grave, podem apresentar sialorreia excessiva, disfagia grave com broncoaspiração e consequentes infecções pulmonares de repetição. Nestes casos, há indicação de traqueostomia que vai prolongar a sobrevida do paciente e melhorar a qualidade de sua vida. Ventilação mecânica invasiva por meio de traqueostomia deve, obrigatoriamente, ser feita utilizando traqueostomia com _cuff_ de alto volume e baixa pressão, supra _cuff_ e endocânula. Esta medida é fundamental para a segurança do paciente no domicilio, uma vez que a cânula plástica sem endocânula pode ocasionar aumento silencioso da resistência, insuficiência respiratória e até morte. Recomenda-se que a ventilação invasiva seja feita exclusivamente por meio de ventiladores classificados como de suporte à vida<sup>18</sup> .  
**7.1.1.4. Remoção das Secreções**  
As secreções brônquicas associam-se ao desenvolvimento de insuficiência respiratória aguda, especialmente em pacientes com DNM/ELA. São responsáveis por quadros emergenciais, muitas vezes seguido de intubação e, posteriormente, traqueostomia, processos que podem ser evitados ou postergados, se as secreções forem controladas adequadamente<sup>18</sup> .  
Para auxiliar na eliminação da secreção é necessário fazer inalação com soro fisiológico a 0,9% de 2 a 3 vezes ao dia com o objetivo de fluidificação das secreções. Após a fluidificação, é preciso remover a secreção, por meio de medidas de higiene brônquica, evitando, assim, quadros de infecção pulmonar<sup>18</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.2.   Suporte nutricional** -->
As alterações nutricionais e a deficiente ingestão alimentar desenvolvem-se com a progressão da ELA, tendo como consequências perda de peso e alteração da composição corporal. As causas da depleção nutricional são múltiplas e incluem a ingestão inadequada de nutrientes, principalmente pelo quadro de disfagia, inapetência, dificuldade de alimentar-se, depressão e hipermetabolismo<sup>18</sup> .  
A piora do estado nutricional tem implicações diretas no tempo de evolução da doença. Há evidências que associam a perda de peso, redução do índice de massa corporal (IMC) e de massa muscular com a menor sobrevida em pacientes com ELA. Em estudo recente, postulou-se que a diminuição de 10% do peso corporal aumentaria em 45% o risco de morte nessa população<sup>35</sup> . Para o IMC, a redução de 1 kg/m<sup>2</sup> estaria associado a um aumento de 20% desse risco<sup>36</sup> .  
O quadro de disfagia é inerente à piora do estado nutricional e ao aumento do risco de desidratação nessa população. Em 17% a 30% dos pacientes com ELA os músculos bulbares são os primeiramente afetados; além disso, com a progressão da doença, a maior parte dos pacientes desenvolve os sintomas bulbares que resultam em disfagia progressiva com dificuldade na ingestão de alimentos e líquidos<sup>37–39</sup> .  
A orientação nutricional por profissional habilitado, portanto, deve ser precoce, com adaptações apropriadas na dieta, objetivando-se aumentar a gordura corporal e                                 hidratação e o hábito intestinal adequados. Diante do desenvolvimento da ELA, a via oral torna-se ineficiente para suprir as necessidades nutricionais com indícios clínicos de aspiração e necessidade de modificação de consistência. Logo, uma via alternativa de alimentação pode ser considerada<sup>18</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.2.1.  Via alternativa de alimentação: Gastrostomia endoscópica percutânea (GEP)** -->
A GEP representa uma opção no tratamento sintomático proporcionando nutrição adequada e contribui para a manutenção do peso corporal. Além disso, é uma alternativa para a administração de líquidos e medicamentos, permitindo ainda a nutrição por via oral, quando possível. A GEP já se revelou superior à gastrostomia radiológica percutânea quanto a complicações relacionadas à inserção da sonda de gastrostomia, sendo a modalidade de escolha<sup>40</sup> .  
Segundo o Consenso Europeu para o tratamento de doenças neurológicas, a GEP deve ser discutida em estágio inicial da doença, em intervalos regulares à medida que a ELA progride e de acordo com a evolução da segurança e eficácia da deglutição<sup>41</sup> . A detecção de disfagia, longa duração das refeições, perda de peso, função respiratória deficiente, risco de asfixia e desejo dos pacientes devem orientar a decisão de indicação da gastrostomia<sup>42</sup> .  
Os critérios de indicação GEP consideram o monitoramento clínico baseado nos indicadores de avaliação multidisciplinar, que incluem: avaliação nutricional, enfatizando a queda de 10% do peso corporal nos últimos três meses, presença de disfagia moderada e avaliação da função respiratória, destacando a medida da capacidade vital forçada (CVF) em torno de 50% do predito. A indicação do procedimento deve acontecer na presença de um ou mais critérios associados<sup>43</sup> . A medida de CVF seria a variável de escolha para o êxito do procedimento, pois, na  
presença de valores inferiores a 50% do predito, existem riscos de hipóxia durante o procedimento<sup>44–46</sup> .  
Durante a realização da GEP, sobretudo nos pacientes com paralisia bulbar progressiva, recomenda-se o uso concomitante de VNI, objetivando-se maior segurança, uma vez que a sedação pode ocasionar apneia e fraqueza em região orofaríngea, favorecendo a intubação traqueal e consequente traqueostomia. Há evidência de que o uso de ventilação mecânica não invasiva usada antes, durante e depois a GEP pode reduzir taxas de complicações respiratórias em pacientes com ELA<sup>47</sup> .  
Um estudo de coorte, prospectivo, longitudinal e multicêntrico com 330 doentes de ELA avaliou a mortalidade em 30 dias após a gastrostomia por três técnicas diferentes (grupos): endoscópica percutânea, inserção radiológica e por via oral guiada por exame de imagem. Os autores encontraram que a gastrostomia evitou a perda de peso na metade dos pacientes e levou ao ganho de peso em 25% dos analisados. Os três grupos apresentaram mortalidade similar de aproximadamente 3%, não havendo diferença estatisticamente significativa entre eles<sup>48</sup> .  
A sobrevida também parece ser afetada com a indicação tardia da gastrostomia. Os pacientes com perda de peso maior de 5 kg, no momento da inserção da GEP, apresentaram sobrevida de 15,3 meses quando comparada com 21,5 meses do grupo com perda menor do peso corporal<sup>49</sup> . A qualidade de vida dos pacientes é outro ponto de destaque: a alimentação assistida por GEP demonstrou estabilizar ou aumentar o peso corporal, aumentar a sobrevida e melhorar a qualidade de vida<sup>42,49–52</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.3.   Suporte de mobilidade e acessibilidade** -->
A fisioterapia motora tem o objetivo de otimizar as funções motoras do paciente, minimizando ou mesmo prevenindo as contraturas, deformidades, dores articulares e encurtamentos musculares, pressão por longos tempos em decúbitos, compressões nervosas e mesmo quedas, ao maximar a força muscular, a mobilidade, a funcionalidade e a autonomia para as atividades de vida diária do paciente<sup>18</sup> .  
Complicações secundárias a imobilidade, como constipação intestinal, edema, atelectasias, dores localizadas ou generalizadas, também são possíveis de ser amenizadas com o tratamento. Por isso, a cada etapa, é importante que avaliações sejam realizadas para adequar a conduta terapêutica<sup>18</sup> .  
É importante que seja feita a correta prescrição de exercícios, sejam eles movimentos ativos, ativo-assistidos ou passivos, sem gerar fadiga no paciente. Deve ser ainda aplicado um programa de conservação de energia, em meio à rotina do paciente, pois exercícios excessivos e com carga podem levar à fadiga e à maior progressão da doença, com aumento da degeneração neuronal, segundo estudos. Por este motivo, não são recomendados exercícios com qualquer tipo de resistência ou mesmo uso de estimulação elétrica funcional<sup>18</sup> .  
Além dos exercícios, outras medidas que auxiliam o paciente: uso de ergonomia para melhoria de funções, avaliação de acessibilidade e possibilidades de deslocamento, avaliação das atividades de vida diária e treinamento de novos meios de realizá-las, entre outros<sup>18</sup> .  
Outro recurso bastante utilizado são as órteses, dispositivos que têm por objetivo apoiar, auxiliar e proteger o sistema locomotor. Podem ser utilizadas para  
imobilização, mobilização, correção, alívio e estabilização de uma parte do corpo. Desta forma, é possível utilizar a órtese para corrigir a postura e o movimento, ou mesmo devolver funções perdidas, dentro da proposta de trabalho de Reabilitação Neurofuncional<sup>18</sup> .  
Em Neurologia, as órteses podem ser utilizadas para compensar as funções do corpo perdidas e são prescritas por um fisioterapeuta, terapeuta ocupacional ou médico após avaliação detalhada da funcionalidade, força muscular e flexibilidade do paciente. O tempo e a forma de uso dependem do tipo de doença e do quadro clínico de cada paciente<sup>18</sup> .  
Durante a progressão da doença, havendo piora da função de marcha e equilíbrio, o paciente com ELA pode necessitar da prescrição e adaptação de cadeiras de rodas para garantir-lhe melhora postural, prevenção de quedas e maior autonomia, com ganhos de deslocamento<sup>18</sup> .  
No Brasil, desde 1993 o Sistema Único de Saúde (SUS) dá acesso a órtese AFO ( _ankle foot orthesis_ ) a todos os cidadãos que dela precisarem. E, em 2013, incluiu-se cadeira de rodas e adaptação postural em cadeiras de rodas, na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais (OPME) do SUS.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.4.  Suporte de comunicação** -->
Sabendo-se que, no decorrer da doença, disfagia, hipersialorreia, disfonia, disartria e laringoespasmo são muito frequentes, a atuação do fonoaudiológico é necessária desde o início do tratamento. Objetiva-se a promoção de cuidados que auxiliem o paciente a se adaptar a cada etapa de progressão da doença<sup>53</sup> .  
A fraqueza dos músculos orofaciais e laríngeos, em conjunto com a alteração de respiração, pode fazer com que o paciente com ELA apresente redução da inteligibilidade e compreensibilidade da sua produção fonoarticulatória, pela presença de um quadro de disartria combinado ou não com um quadro de disfonia. Tais alterações ocorrem em 80% a 95% dos pacientes com ELA, em algum momento durante a progressão da doença<sup>54</sup> .  
Na medida em que esta produção se torna mais deficitária, os interlocutores passam a ter mais dificuldade em compreender a mensagem e a tendência do paciente é a de se isolar, por falta de comunicação. Há um declínio da fala natural e a consequente necessidade de indicação de um recurso de Comunicação Suplementar e Alternativa (CSA)<sup>55</sup> .  
Esta indicação deve ser feita pelo fonoaudiólogo e a adaptação ao acesso ao dispositivo, pelo terapeuta ocupacional. É importante que seja feita uma avaliação clínica por uma equipe especializada, a fim de que a indicação do recurso de comunicação seja individualizada e mais assertiva às necessidades e às possibilidades motoras e cognitivas do paciente<sup>56</sup> .  
A indicação, a escolha e o sucesso da implantação do recurso de comunicação dependem de uma série de fatores, tais como: quadro clínico motor, a partir do qual é feita a definição do melhor dispositivo de acesso ao equipamento/recurso de comunicação; usabilidade; treino funcional da comunicação em diferentes contextos; treinamento da família e cuidadores para uso do recurso; e, por fim, a presença de eventuais comprometimentos de cognição e de linguagem, que comprometam o sucesso desta terapêutica<sup>57</sup> .  
A perda da comunicação efetiva é considerada um dos piores aspectos da doença e pode levar o paciente a apresentar dificuldades no âmbito psicológico, com repercussão no campo emocional, laboral, social e familiar – com consequente piora da sua qualidade de vida e, inclusive, com redução da sua sobrevida<sup>58</sup> .  
Existe evidência que mais de 50% dos pacientes com Doença do Neurônio Motor tenham alterações em sua função cognitiva, variando desde uma alteração leve até um franco quadro de demência frontotemporal. Tais alterações têm uma grande implicação na comunicação, no comportamento, no cuidado, nas tomadas de decisões, na sinalização dos sintomas, na adesão e na aceitação dos cuidados e das condutas clínicas definidas pela equipe<sup>59</sup> .  
Por este motivo, a indicação de uma avaliação e terapia fonoaudiológica, desde os primeiros sintomas bulbares, é essencial, seja em âmbito terapêutico ambulatorial ou domiciliar; uma vez que o fonoaudiólogo reconhecerá eventuais alterações de cognição e linguagem e também disponibilizará ao paciente técnicas que melhorem a sua produção fonoarticulatória, garantindo a ele que se mantenha comunicativo em seu meio, apesar da dificuldade ou mesmo da ausência de fala<sup>60</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.5.  Suporte multidisciplinar** -->
Alguns estudos comprovaram que há maior sobrevida de pessoas com ELA tratadas por uma equipe especializada quando comparadas com os pacientes tratados por uma equipe geral de reabilitação não especializada na área<sup>61</sup> .  
Isto se deve ao fato de a equipe especializada compreender e promover a necessária integração entre todas as áreas, mantendo o paciente, de forma ativa, no centro de todas as decisões. Portanto, o suporte multidisciplinar especializado tem sido apontado como um dos principais fatores de melhoria de qualidade de vida, melhora de saúde mental, funcionamento social e aumento da sobrevida dos pacientes com diagnóstico de Esclerose Lateral Amiotrófica. Este acompanhamento pode se dar no âmbito ambulatorial, na rede de atendimento de reabilitação oferecido pelo SUS, ou em ambiente hospitalar, durante uma eventual internação do paciente, ou ainda em ambiente domiciliar, no âmbito do Programa de Atendimento Domiciliar U  “          C   ”<sup>62</sup> .  
Terapia de dignidade, uma forma de psicoterapia breve, parece reduzir sintomas de depressão e ansiedade tanto em pacientes com DNM assim como na sua família e cuidadores<sup>63</sup> .  
A combinação de todas as intervenções terapêuticas não medicamentosas propostas pela equipe multidisciplinar especializada, somadas ao tratamento medicamentoso, permitem uma visão do tratamento como um todo, integrado, o que, por sua vez, possibilita promover a alta hospitalar do paciente e melhorar a sua habilidade para realizar as atividades de vida diária, garantindo-lhe maior autonomia, funcionalidade e qualidade de vida, além de aumentar a sua sobrevida.  
As emoções vividas se não forem faladas, ou seja, se não saírem pela boca, sairão pelo corpo, manifestando-se como sintomas ou manifestações psicossomáticas. Antes que isso venha acontecer, o apoio emocional tem a possibilidade de evitá-los. Essa é uma das razões de psicólogos fazerem parte de uma equipe multiprofissional, dando suporte psicológico não só ao paciente com ELA, mas também para a sua família, cuidador e para a própria equipe de saúde encarregada pelo atendimento e  
acompanhamento do paciente<sup>64</sup> . A depressão tem uma correlação direta com a mortalidade de pacientes com ELA. Quanto mais grave, menor a sobrevida<sup>65</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.1.6.   Atendimento domiciliar** -->
C -  -                                                . Eles                                                                     o para as atividades tanto fora dado pelo                             -                       , especialmente por propiciar um custo menor e com melhores resultados . A missão do atendimento domiciliar deve ser a melhora da qualidade de vida, sobrevida, independência e autonomia e conforto psicológico.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.2.   Tratamento específico** -->
Várias terapias modificadoras da doença têm sido testadas em ensaios clínicos<sup>66–85</sup> , mas apenas um medicamento – o riluzol – comprovou-se eficaz, além de ser o único tratamento específico registrado pela ANVISA até o momento<sup>86–88</sup> .  
Bensimon _et al._<sup>89</sup> publicaram o primeiro estudo duplo-cego randomizado avaliando o papel do riluzol no tratamento da ELA. Após 573 dias, 58% dos pacientes do grupo placebo estavam vivos, em contraste com 74% do grupo riluzol. O subgrupo mais beneficiado apresentava doença em nível bulbar na fase inicial, com um aumento de sobrevida de aproximadamente 2-3 meses. Um estudo publicado dois anos mais tarde, envolvendo centros americanos e um número maior de pacientes, confirmou esses achados<sup>90</sup> . Especula-se a respeito dos efeitos neuroprotetores do riluzol, porém, mais estudos são necessários para definir o caráter preventivo do fármaco<sup>91</sup> .  
São contraindicações ao uso de riluzol neste PCDT:  
- Insuficiência renal ou hepática;  
- outra doença grave ou incapacitante, incurável ou potencialmente fatal;  
- outras formas de doenças do corno anterior medular;  
- demência, distúrbios visuais, autonômicos, esfincterianos;  
- gravidez ou amamentação;  
- ventilação assistida;  
- hipersensibilidade ao medicamento.  
A terapia celular ainda não possui comprovação de eficácia, tendo apenas quatro ensaios clínicos sobre o tema em andamento<sup>92</sup> . O lítio já se provou ineficaz na redução de progressão de ELA, segundo resultado de revisão sistemática<sup>93</sup> , embora possa haver resposta diferenciada favorecendo pacientes com ELA genótipo UNC13A, segundo análises de subgrupo de três ECR<sup>94</sup> . Visto que essa hipótese ainda não foi devidamente testada em estudo clínico randomizado, este PCDT não preconiza o uso de lítio para tratamento de ELA ou DNM.  
Uma revisão sistemática da Cochrane que estudou o uso de moduladores GABA (e.g., gabapentina e baclofeno) concluiu que esses não são eficazes para redução da progressão da doença<sup>95</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.2.1. Fármaco** -->
Riluzol: comprimidos de 50 mg.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.2.2.  Esquema de administração** -->
01 comprimido de 50 mg, por via oral, a cada 12 horas, 1 hora antes ou 2 horas após as refeições.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.2.3.   Tempo de tratamento** -->
O tempo de tratamento não pode ser pré-determinado e depende da tolerabilidade do paciente ao medicamento.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.2.4.   Benefícios esperados**<sup>**66**</sup> -->
- Leve melhora de sintomas bulbares e da função dos membros;  
- aumento da sobrevida.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **7.3. Tratamento medicamentoso sintomático** -->
Na ausência de um tratamento curativo, as intervenções sintomáticas e cuidados de suporte permanecem a pedra angular do cuidado ao paciente com ELA. Todos os esforços devem ser feitos para melhorar-lhe a qualidade de vida e auxiliá-lo a manter a autonomia durante todo o tempo possível. Nos estágios iniciais da ELA, o foco se concentra na maximização da função, promovendo a independência e tratando os sintomas que se apresentem. Com a progressão da doença, o cuidador também deve receber atenção e tratamento. O envolvimento de equipe multidisciplinar e a adoção de cuidados paliativos o mais precocemente possível são cruciais para se alcançar esses objetivos, melhorando os cuidados gerais, bem como aumentando a sobrevida do paciente.  
Numa doença progressiva e devastadora como a ELA, devem-se seguir os princípios básicos do cuidado: paciente bem informado, respeito à autonomia, disponibilizar equipe multidisciplinar, atenção ao tempo apropriado para decisões especiais e manutenção da esperança.  
O estadiamento clínico da doença torna-se importante nas tomadas de decisões, inclusive quanto ao tratamento. Uma forma prática de realizá-la é utilizando o estadiamento do _King’s College_<sup>96</sup> . Como a doença se inicia focal, numa determinada região, e depois progride, pode-se estadiar segundo as regiões acometidas ( **Quadro 1** ). Existe uma correlação entre a progressão da doença e a escala, podendo ser calculado o tempo do início até chegar a cada estágio. Por exemplo, o uso de sonda para alimentação ocorreu após 27,3 meses e a ventilação não invasiva após 30,3 meses<sup>97</sup> . A escala também possibilita estimar a qualidade de vida dos pacientes à medida que ela declina com progressão da doença. Por fim, a escala oferece a possibilidade de estimar o custo real da doença, que aumenta com a progressão da doença.  
**Quadro 1 - Escala de estadiamento do** **_King’s College_**<sup>96</sup>  
|**Estágio**|**Definição**|
|---|---|
|Estágio 1|Uma região funcionalmente acometida (sintoma<br>inicial).|  
|Estágio 2|Duas regiões funcionalmente acometidas.|
|---|---|
|Estágio 3|Três regiões funcionalmente acometidas.|
|Estágio 4|Qualquer dos estágios acimamais<br>:|
||necessidade de gastrostomia (4A);<br>ventilação não invasiva(4B).|
|Estágio 5|Morte.|  
<mark>O atendimento multidisciplinar especializado prolonga a sobrevida de 7 a 24 meses</mark><sup>98–100</sup> <mark>. Esse modelo de atendimento, tendo no centro o paciente e sua família, integra médicos (neurologista, pneumologista e gastroenterologista) enfermeiros, nutricionistas, fisioterapeutas, terapeutas ocupacionais, psicólogos, fonoaudiólogos, assistentes sociais, com ação antecipatória e proativa, para obter os melhores cuidados.</mark> **<mark>Na Tabela 3</mark>** <mark>, encontram-se os medicamentos e outras medidas terapêuticas, conforme as situações apresentadas pelos pacientes, sem medicamentos ou intervenções não registrados pela ANVISA. Deve-se ressaltar que, para o alívio da dispneia, há notória escassez de evidências que suportem o uso de benzodiazepínicos conforme concluiu revisão sistemática da Cochrane</mark><sup>101</sup> <mark>.</mark>  
**Tabela 3 -** Medicamentos e outras medidas terapêuticas, conforme as situações apresentadas pelos pacientes.  
|**Situação**|**Medicamentos**<br>**1ª linha**|**Medicament**<br>**os       2ª**<br>**linha**|**Outros tratamentos**|**Comentários**|
|---|---|---|---|---|
|**Fasciculações**|Carbamazepina<br>100-200<br>mg 2x dia, VO.|Clonazepam<br>0,5<br>a<br>2<br>mg/dia, VO.|-|Ocorre na fase inicial da doença e raramente<br>incomoda. Não há necessidade de tratamento,<br>na maioria das vezes.|
|**Espasticidad**||Diazepam (5-|Fisioterapia e hidroterapia em|Efeitos adversos dos medicamentos: fadiga e|
|**e**<br>**(vide**<br>**o**<br>**PCDT**<br>**de**<br>**espasticidad**<br>**e**<sup>**102**</sup>**)**||10 mg/dia).|piscina aquecida (32 a 34 °C).|náusea.|
|**Sialorreia**|Amitriptilina<br>25<br>a<br>75<br>mg/dia, VO ou<br>Nortriptilina 10 a 100<br>mg/dia, VO.|Butilbrometo<br>de<br>escopolamin<br>a<br>10<br>mg<br>6/6h, VO.|Aspirações.|EA<br>associado<br>a<br>anticolinérgico:<br>sedação,<br>obstipação,<br>fadiga,<br>impotência,<br>retenção<br>urinária, visão turva, taquicardia, hipotensão<br>ortostática<br>e<br>tontura.<br>Contraindicações:<br>glaucoma, hipertrofia benigna da próstata ou<br>distúrbios cardíacos de condução.|
|**Laringoespas**|Ranitidina 150 mg 2x/dia,|-|Mudança<br>rápida<br>da<br>parte|Ocorre por fechamento súbito das cordas vocais|
|**mo**|VO<br>Metoclopramida<br>solução oral 4 mg/mL, 50<br>gotas, VO.||superior do corpo (sentado),<br>respiração através do nariz,<br>engolir<br>repetidamente<br>e<br>respirando lentamente, com<br>expiração pela boca.|resultando em apneia, é curta duração e é<br>seguido de pânico. Precipitantes: contato de<br>líquido (saliva) na laringe, fumo, álcool, refluxo<br>gástrico, alimentos picantes.|  
|**Saliva**||Cloridrato de|Umidificar o ar. Aumentar a|A saliva espessa pode ser indicador de|
|---|---|---|---|---|
|**espessa/**<br>**secreção**||propranolol<br>10mg|ingesta de líquidos (incluindo,<br>sucos de mamão ou abacaxi) e|desidratação.|
|**brônquica**||2xdia/VO.<br>Nebulizar<br>com solução<br>salina<br>e<br>ipratrópio<br>0,25 mg/mL,<br>40 gotas 3 a<br>4x dia.|reduzir<br>cafeína,<br>leite<br>ou<br>álcool).<br>Técnicas<br>de<br>empilhamento de ar.||
|**Dor**|Dipirona, paracetamol ou<br>ibuprofeno.|Paracetamol<br>+<br>codeína.<br>Morfina.|Massagem;<br>calor<br>local;<br>movimentos<br>passivos;<br>mudança de decúbito. TENS.<br>Cama hospitalar.|Múltiplas causas (rigidez articular; pressão<br>cutânea em única área; neuropática; cãibras).|
|**Labilidade**<br>**emocional**|Antidepressivos tricíclicos:<br>Amitriptilina<br>25-75<br>mg/dia,<br>VO<br>ou<br>Nortriptilina<br>10-100<br>mg/dia, VO.<br>ISRS:<br>Fluoxetina 10-30 mg/dia,<br>VO.||-|EA dos ISRS: disfunção sexual, acatisia, distúrbio<br>do sono e ansiedade.|
|**Constipação**|Lactulose 15 a 30ml/dia,<br>VO.|Supositório<br>retal<br>de<br>glicerol<br>72mg.<br>Enema<br>de|Hidratação. Dieta rica em<br>fibras, frutas, vegetais.<br>(por<br>exemplo,<br>mamão,<br>tamarindo, laranja, ameixa,<br>manga,<br>folhas<br>em<br>geral).|Causas: mobilidade reduzida, redução da<br>ingesta de líquidos/alimentos, efeitos colaterais<br>de medicamentos. EA da lactulona: distensão<br>abdominal, diarreia, flatulência e náusea.|  
glicerol 120 Remoção manual caso mg/mL impactação fecal (fecaloma). solução retal.  
|**Depressão**|Amitriptilina<br>mg/dia,|VO|25-75<br>ou||Suporte psicológico para o<br>paciente e sua família. Práticas|A escolha do antidepressivo será segundo os<br>sintomas associados.|
|---|---|---|---|---|---|---|
||Nortriptilina<br>mg/dia, VO o<br>Fluoxetina 1<br>VO.|u<br>0-30|10-100<br>mg/dia,||integrativas<br>como<br>a<br>meditação, massoterapia, por<br>exemplo.||
|**Insônia**|Amitriptilina<br>mg/dia, VO.|12,5|a 75||Cama<br>hospitalar.<br>Colchão<br>pneumático. VNI.|Comum.<br>Causas:<br>depressão,<br>ansiedade,<br>hipoventilação noturna, dificuldade de se mover<br>na cama, dor.|
|**Ansiedade**|Diazepam 2,<br>12/12 h, VO.|5 a|10 mg|Clonazepam<br>0,5-2mg,<br>à<br>noite, VO.|<br>Psicoterapia.<br>Práticas<br>integrativas<br>como<br>a<br>meditação, massoterapia, por<br>exemplo.|Os benzodiazepínicos apresentam risco de<br>agravar a insuficiência respiratória, provocar<br>tolerância e sintomas de abstinência.|
|**Fadiga**<sup>**103**</sup>|-|||-|Fisioterapia motora.|Descartar causas secundárias: insuficiência<br>respiratória,<br>desnutrição,<br>anemia,<br>efeitos<br>adversos<br>de<br>medicamentos<br>e<br>outras<br>comorbidades.|
|**Frequência/u**<br>**rgência**<br>**urinária.**|Amitriptilina<br>mg/dia, VO.||12,5-75|-|Evitar cafeína e álcool.|Não ocorre na fase inicial da doença. Alguns<br>pacientes precisam urinar a cada 1-2 horas. Para<br>pacientes com muita fraqueza, transferi-lo ao<br>banheiro frequentemente pode ser difícil e<br>demorado. Observar EA da oxibutinina e<br>amitriptilina.|  
|**Saúde bucal**|Digliconato de clorexidina<br>0,12%<br>solução<br>bucal<br>12/12h, nos pacientes em<br>ventilação<br>invasiva<br>(traqueostomizados).<br>-|Escovação dos dentes e língua<br>com escova macia. Utilizar<br>raspador<br>de<br>língua,<br>especialmente<br>na<br>língua<br>saburrosa. Substituir a escova<br>a cada 3-4 meses. Numa fase<br>da doença pode ser necessária<br>utilizar adaptadores na escova<br>(exemplo, os engrossadores de<br>cabo). Uso de fio dental.<br>Massagear as gengivas com<br>gaze umedecida em pacientes<br>que não mastigam. Umidificar<br>a boca durante o uso de VNI.|Motivos para manter a saúde bucal: evitar ou<br>reduzir mau hálito, doenças na gengiva e<br>pneumonia; maximizar o prazer associado a<br>mastigar alimentos e beber líquidos;<br>ajudar a gerenciar a saliva.<br>Visitas regulares com o dentista.|
|---|---|---|---|
|**Edema**<br>**nos**<br>**pés**|-<br>-|Elevação das pernas (cadeira<br>de<br>rodas<br>reclinável<br>com<br>elevação das pernas acima do<br>nível do coração e cama<br>hospitalar).<br>Movimentação<br>passiva várias vezes ao dia.|Evitar diuréticos. No edema assimétrico, pensar<br>em TVP)|
|**Prevenção**|Fisioterapia, elevação das<br>-|-|Não há trabalhos que demonstrem benefícios|
|**de TVP**|pernas<br>e<br>meias<br>compressivas.||com uso de anticoagulação para prevenção de<br>TVP.|
|**Tratamento**|Morfina (2,5 a 5,0 mg a<br>-|Considerar, com a família,||
|**da fase final**|cada 4h) e clorpromazina|internamento hospitalar ou||
|**de vida em**|para dispneia.|não.||
|**ELA**|Midazolam<br>para<br>ansiedade.|||  
Analgésicos para dor. Oxigênio para hypoxemia.  
VO **: por via oral. ISRS: inibidores seletivos da recaptação da serotonina. EA: efeitos adversos. AINE: anti-inflamatório não esteroidal. TENS: estimulação elétrica nervosa transcutânea. VNI: ventilação noturna não invasiva. TVP: trombose venosa profunda.**

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **8.  MONITORAMENTO** -->
O acompanhamento em longo prazo deverá ser realizado por neurologista<sup>104,105</sup> . Os seguintes exames devem ser realizados: hemograma, plaquetas e enzimas hepáticas antes de se iniciar o tratamento, no primeiro, no segundo, nos 3º, 6º, 9º e 12º meses e, após, quando indicado(s).  
Os pacientes devem ser reavaliados a cada 3 ou 4 meses ou conforme orientação médica. O riluzol deve ser administrado até que o paciente não mais o tolere ou o momento em que necessitar de uso de ventilação mecânica<sup>86</sup> . Cabe salientar que o efeito nocebo é frequente nos pacientes com DNM, haja vista a elevada incidência de efeitos adversos nos grupos placebo conforme resultado de meta-análise de ECR: 78,3% (IS-95%: 74,3% a 82,0%)<sup>106</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **8.1.  Critérios para suspensão do tratamento** -->
- Quando a dosagem de aminotransferase/transaminase estiver cinco vezes acima do limite superior da normalidade<sup>107</sup> ;  
- Quando ocorrer citotopenia: leucócitos totais abaixo de 3.000/mm3, neutrófilos abaixo de 1.500/mm<sup>3</sup> , plaquetas abaixo de 100.000/mm<sup>3</sup> ou hemoglobina inferior a 10 g/dL107.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **9.  REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas, da adequação de uso do medicamento e do acompanhamento pós-tratamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamento preconizados neste Protocolo.  
Devido as peculiaridades da doença, pacientes com ELA devem ter uma carteirinha pessoal contendo informações relevantes quanto aos cuidados que devem ser oferecidos em procedimentos em Salas de Emergência ou em procedimentos cirúrgicos. Bloqueadores neuromusculares despolarizantes, como halotano e succinilcolina, são contra-indicados em pacientes com ELA por causa do risco de liberação intensa de potássio<sup>108</sup> .

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **10. REFERÊNCIAS** -->
1. Marin B, Boumédiene F, Logroscino G, et al. Variation in worldwide incidence of amyotrophic lateral sclerosis: a meta-analysis. Int J Epidemiol 2017;46(1):57–74.  
2. Chancellor AM, Warlow CP. Adult onset motor neuron disease: worldwide mortality, incidence and distribution since 1950. J Neurol Neurosurg Psychiatry 1992;55(12):1106–15.  
3. Cronin S, Hardiman O, Traynor BJ. Ethnic variation in the incidence of ALS: a systematic review. Neurology 2007;68(13):1002–7.  
4. Phukan J, Hardiman O. The management of amyotrophic lateral sclerosis. J Neurol 2009;256(2):176–86.  
5. Mitchell JD, Borasio GD. Amyotrophic lateral sclerosis. Lancet 2007;369(9578):2031–41.  
6. Oliveira ASB, Pereira RDB. Amyotrophic lateral sclerosis (ALS): three letters that ’        F                            2  9 67 3   7  –82.  
7. Mitsumoto H, Rabkin JG. Palliative care for patients with amyotrophic lateral “                w                           ” J    2  7 298 2  2 7– 16.  
8. Andersen PM. Amyotrophic lateral sclerosis associated with mutations in the CuZn superoxide dismutase gene. Curr Neurol Neurosci Rep 2006;6(1):37–46.  
9. Zou Z-Y, Zhou Z-R, Che C-H, Liu C-Y, He R-L, Huang H-P. Genetic epidemiology of amyotrophic lateral sclerosis: a systematic review and meta-analysis. J Neurol Neurosurg Psychiatry 2017;88(7):540–9.  
10. Riviere M, Meininger V, Zeisser P, Munsat T. An analysis of extended survival in patients with amyotrophic lateral sclerosis treated with riluzole. Arch Neurol 1998;55(4):526–8.  
11. Hayashi H, Oppenheimer EA. ALS patients on TPPV: totally locked-in state, neurologic findings and ethical implications. Neurology 2003;61(1):135–7.  
12. Kiernan MC, Vucic S, Cheah BC, et al. Amyotrophic lateral sclerosis. Lancet 2011;377(9769):942–55.  
13. Couratier P, Corcia P, Lautrette G, Nicol M, Marin B. ALS and frontotemporal dementia belong to a common disease spectrum. Rev Neurol (Paris) 2017;173(5):273–9.  
14. Wilbourn AJ. Clinical neurophysiology in the diagnosis of amyotrophic lateral sclerosis: the Lambert and the El Escorial criteria. J Neurol Sci 1998;160 Suppl 1:S25-29.  
15. Meininger V. Getting the diagnosis right: beyond El Escorial. J Neurol 1999;246 Suppl 3:III10-12.  
16. Chiò A. ISIS Survey: an international study on the diagnostic process and its implications in amyotrophic lateral sclerosis. J Neurol 1999;246 Suppl 3:III1-5.  
17. Brooks BR, Miller RG, Swash M, Munsat TL, World Federation of Neurology Research Group on Motor Neuron Diseases. El Escorial revisited: revised criteria for the diagnosis of amyotrophic lateral sclerosis. Amyotroph Lateral Scler Other Motor Neuron Disord 2000;1(5):293–9.  
18. Andersen PM, Abrahams S, Borasio GD, et al. EFNS guidelines on the Clinical Management of Amyotrophic Lateral Sclerosis (MALS) – revised report of an EFNS task force. European Journal of Neurology 2012;19(3):360–75.  
19. Baek WS, Desai NP. ALS: pitfalls in the diagnosis. Pract Neurol 2007;7(2):74–81. 20. Da Silva ANR, Pereira GRC, Moreira LGA, Rocha CF, De Mesquita JF. SOD1 in amyotrophic lateral sclerosis development - in silico analysis and molecular dynamics of A4F and A4V variants. J Cell Biochem 2019;120(10):17822–30.  
21. Swash M, Desai J. Motor neuron disease: classification and nomenclature. Amyotroph Lateral Scler Other Motor Neuron Disord 2000;1(2):105–12.  
22. Piepers S, van den Berg J-P, Kalmijn S, et al. Effect of non-invasive ventilation on survival, quality of life, respiratory function and cognition: a review of the literature. Amyotroph Lateral Scler 2006;7(4):195–200.  
23. Eidenberger M, Nowotny S. Inspiratory muscle training in patients with Amyotrophic Lateral Sclerosis: A systematic review. NeuroRehabilitation 2014;35(3):349–61.  
24. Payne C, Wiffen PJ, Martin S. Interventions for fatigue and weight loss in adults with advanced progressive illness. Cochrane Database Syst Rev 2012;1:CD008427.  
25. Marchetti M, Priftis K. Brain-computer interfaces in amyotrophic lateral sclerosis: A metanalysis. Clin Neurophysiol 2015;126(6):1255–63.  
26. Guo J, Zhou M, Yang M, Zhu C, He L. Repetitive transcranial magnetic stimulation for the treatment of amyotrophic lateral sclerosis or motor neuron disease. Cochrane Database Syst Rev 2011;(9):CD008554.  
27. Pastula DM, Moore DH, Bedlack RS. Creatine for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2010;(6):CD005225.  
28. Radunovic A, Annane D, Rafiq M, Brassington R, Mustfa N. Mechanical ventilation for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database of Systematic Reviews [Internet] 2017;(10). Available from: http://dx.doi.org/10.1002/14651858.CD004427.pub4  
29. Jackson C., De Carvalho M., Genge A., Heiman-Patterson T., Shefner J. Correlations between slow vital capacity and measures of respiratory function on the ALSFRS-R. Amyotrophic Lateral Scler Frontotemporal Degener 2017;18((Jackson C., jacksonce@uthscsa.edu) University of Texas Health Science Center, San Antonio, TX, United States):275–6.  
30. Sarmento A, Resqueti V, Dourado-Júnior M, et al. Effects of Air Stacking Maneuver on Cough Peak Flow and Chest Wall Compartmental Volumes of Subjects With Amyotrophic Lateral Sclerosis. Archives of Physical Medicine and Rehabilitation 2017;98(11):2237-2246.e1.  
31. Miller RG, Rosenberg JA, Gelinas DF, et al. Practice parameter: the care of the patient with amyotrophic lateral sclerosis (an evidence-based review): report of the Quality Standards Subcommittee of the American Academy of Neurology: ALS Practice Parameters Task Force. Neurology 1999;52(7):1311–23.  
32. American Thoracic Society/European Respiratory Society. ATS/ERS Statement on respiratory muscle testing. Am J Respir Crit Care Med 2002;166(4):518–624.  
33. Ministério da Saúde [Internet]. [cited 2019 Sep 6];Available from: http://bvsms.saude.gov.br/bvs/saudelegis/sas/2008/prt0370_04_07_2008.html  
34. Bach JR, Gonçalves MR, Hamdani I, Winck JC. Extubation of patients with neuromuscular weakness: a new management paradigm. Chest 2010;137(5):1033–9.  
35. Jawaid A, Murthy SB, Wilson AM, et al. A decrease in body mass index is associated with faster progression of motor symptoms and shorter survival in ALS. Amyotroph Lateral Scler 2010;11(6):542–8.  
36. Marin B, Desport JC, Kajeu P, et al. Alteration of nutritional status at diagnosis is a prognostic factor for survival of amyotrophic lateral sclerosis patients. J Neurol Neurosurg Psychiatry 2011;82(6):628–34.  
37. Gubbay SS, Kahana E, Zilber N, Cooper G, Pintov S, Leibowitz Y. Amyotrophic lateral sclerosis. A study of its presentation and prognosis. J Neurol 1985;232(5):295–300.  
38. Mitsumoto H, Chad DA, Pioro EP. Amyotrophic lateral sclerosis. Philadelphia: Davis; 1998.  
39. Calia L, Annes M. Afecções neurológicas periféricas. In: Reabilitação em doenças neurológicas: guia terapêutico prático. São Paulo: Atheneu; 2003.  
40. Strijbos D., Keszthelyi D., Bogie R.M.M., et al. A Systematic Review and MetaAnalysis on Outcomes and Complications of Percutaneous Endoscopic Versus Radiologic Gastrostomy for Enteral Feeding. J Clin Gastroenterol 2018;52(9):753–64.  
41. Burgos R, Bretón I, Cereda E, et al. ESPEN guideline clinical nutrition in neurology. Clin Nutr 2018;37(1):354–96.  
42. Chiò A, Finocchiaro E, Meineri P, Bottacchi E, Schiffer D. Safety and factors related to survival after percutaneous endoscopic gastrostomy in ALS. ALS Percutaneous Endoscopic Gastrostomy Study Group. Neurology 1999;53(5):1123–5.  
43. Silani V. Nutrition in ALS. European ALS Health profile study 2000;9:1–3.  
44. Mathus-Vliegen LM, Louwerse LS, Merkus MP, Tytgat GN, Vianney de Jong JM. Percutaneous endoscopic gastrostomy in patients with amyotrophic lateral sclerosis and impaired pulmonary function. Gastrointest Endosc 1994;40(4):463–9.  
45. Albert SM, Murphy PL, Del Bene M, Rowland LP, Mitsumoto H. Incidence and predictors of PEG placement in ALS/MND. J Neurol Sci 2001;191(1–2):115–9.  
46. Mitsumoto H, Davidson M, Moore D, et al. Percutaneous endoscopic gastrostomy (PEG) in patients with ALS and bulbar dysfunction. Amyotroph Lateral Scler Other Motor Neuron Disord 2003;4(3):177–85.  
47. Banfi P, Volpato E, Valota C, et al. Use of Noninvasive Ventilation During Feeding Tube Placement. Respir Care 2017;62(11):1474–84.  
48. ProGas Study Group. Gastrostomy in patients with amyotrophic lateral sclerosis (ProGas): a prospective cohort study. Lancet Neurol 2015;14(7):702–9.  
49. Dorst J, Dupuis L, Petri S, et al. Percutaneous endoscopic gastrostomy in amyotrophic lateral sclerosis: a prospective observational study. J Neurol 2015;262(4):849–58.  
50. Spataro R, Ficano L, Piccoli F, La Bella V. Percutaneous endoscopic gastrostomy in amyotrophic lateral sclerosis: effect on survival. J Neurol Sci 2011;304(1– 2):44–8.  
51. Langmore SE, Kasarskis EJ, Manca ML, Olney RK. Enteral tube feeding for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2006;(4):CD004030.  
52. Miller RG, Rosenberg JA, Gelinas DF, et al. Practice parameter: The care of the patient with amyotrophic lateral sclerosis (An evidence-based review). Muscle Nerve 1999;22(8):1104–18.  
53. Oda AL. Intervenção Fonoaudiológica nas Disfagias Orofaríngeas nas Doenças Neuromusculares. In: Reabilitação em Doenças Neuromusculares (Guia Terapêutico). São Paulo, SP: Atheneu Ltda;  
54. Makkonen T, Ruottinen H, Puhto R, Helminen M, Palmio J. Speech deterioration in amyotrophic lateral sclerosis (ALS) after manifestation of bulbar symptoms. International Journal of Language & Communication Disorders 2018;53(2):385– 92.  
55. Beukelman D, Fager S, Nordness A. Communication Support for People with ALS. Neurology Research International 2011;2011:1–6.  
56. Neto LL, Constantini AC, Chun RYS. Communication vulnerable in patients with Amyotrophic Lateral Sclerosis: A systematic review. NRE 2017;40(4):561–8.  
57. Londral A, Pinto A, Pinto S, Azevedo L, De Carvalho M. Quality of life in amyotrophic lateral sclerosis patients and caregivers: Impact of assistive communication from early stages: Communication and QoL in ALS. Muscle Nerve 2015;52(6):933–41.  
58. McNaughton D, Giambalvo F, Kohler K, Nazareth G, Caron J, Fager S. “                             C                C  W         Y     V    ” Key Practices in AAC Assessment and Intervention as Described by Persons with Amyotrophic Lateral Sclerosis. Semin Speech Lang 2018;39(5):399–415.  
59. Mccluskey L. Ethical issues in states of impaired communication with intact consciousness and language. In: Bernat JL, Beresford RH, editors. Ethical and legal issues in neurology. Edinburgh: Elsevier; 2013.  
60. Pattee GL, Plowman EK, (Focht) Garand KL, et al. Provisional best practices guidelines for the evaluation of bulbar dysfunction in amyotrophic lateral sclerosis. Muscle Nerve 2019;59(5):531–6.  
61. Lavernhe S, Antoine J-C, Court-Fortune I, et al. Home care organization impacts patient management and survival in ALS. Amyotrophic Lateral Sclerosis and Frontotemporal Degeneration 2017;18(7–8):562–8.  
62. Amaral N, Cunha M, Labronici R, Oliveira A, Gabbai A. Assistência Domiciliar à Saúde (Home Health Care): sua História e sua Relevância para o Sistema de Saúde Atual. Rev Neurociências 2001;9(3):111–7.  
63. Martínez García M., Belar A., Arantzamendi M., Carrasco J.M., Centeno C. Dignity therapy in palliative care: A comprehensive systematic review of the literature. Palliative Med 2016;30(6):NP209.  
64. Abreu-Filho A, Oliveira A, Silva H. PSYCHOLOGY AND SOCIAL ASPECTS OF AMYOTROPHIC LATERAL SCLEROSIS: REVIEW. Psic, Saúde & Doenças 2019;20(1):88–100.  
65. Thakore NJ, Pioro EP. Depression in ALS in a large self-reporting cohort. Neurology 2016;86(11):1031–8.  
66. Miller RG, Mitchell JD, Moore DH. Riluzole for amyotrophic lateral sclerosis (ALS)/motor neuron disease (MND). Cochrane Database Syst Rev 2012;(3):CD001447.  
67. Mitchell JD, Wokke JH, Borasio GD. Recombinant human insulin-like growth factor I (rhIGF-I) for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2002;(3):CD002064.  
68. Bongioanni P, Reali C, Sogos V. Ciliary neurotrophic factor (CNTF) for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2004;(3):CD004302.  
69. A controlled trial of recombinant methionyl human BDNF in ALS: The BDNF Study Group (Phase III). Neurology 1999;52(7):1427–33.  
70. Ochs G, Penn RD, York M, et al. A phase I/II trial of recombinant methionyl human brain derived neurotrophic factor administered by intrathecal infusion to patients with amyotrophic lateral sclerosis. Amyotroph Lateral Scler Other Motor Neuron Disord 2000;1(3):201–6.  
71. Meininger V, Bensimon G, Bradley WR, et al. Efficacy and safety of xaliproden in amyotrophic lateral sclerosis: results of two phase III trials. Amyotroph Lateral Scler Other Motor Neuron Disord 2004;5(2):107–17.  
72. de Paulis T. ONO-2506. Ono. Curr Opin Investig Drugs 2003;4(7):863–7.  
73. Gordon PH, Moore DH, Gelinas DF, et al. Placebo-controlled phase I/II studies of minocycline in amyotrophic lateral sclerosis. Neurology 2004;62(10):1845–7.  
74. Pontieri FE, Ricci A, Pellicano C, Benincasa D, Buttarelli FR. Minocycline in amyotrophic lateral sclerosis: a pilot study. Neurol Sci 2005;26(4):285–7.  
75. Ryberg H, Askmark H, Persson LI. A double-blind randomized clinical trial in amyotrophic lateral sclerosis using lamotrigine: effects on CSF glutamate, aspartate, branched-chain amino acid levels and clinical parameters. Acta Neurol Scand 2003;108(1):1–8.  
76. Gordon PH, Doorish C, Montes J, et al. Randomized controlled phase II trial of glatiramer acetate in ALS. Neurology 2006;66(7):1117–9.  
77. Orrell RW. AEOL-10150 (Aeolus). Curr Opin Investig Drugs 2006;7(1):70–80.  
78. Meininger V, Asselain B, Guillet P, et al. Pentoxifylline in ALS: a double-blind, randomized, multicenter, placebo-controlled trial. Neurology 2006;66(1):88–92.  
79. Groeneveld GJ, Veldink JH, van der Tweel I, et al. A randomized sequential trial of creatine in amyotrophic lateral sclerosis. Ann Neurol 2003;53(4):437–45.  
80. Desnuelle C, Dib M, Garrel C, Favier A. A double-blind, placebo-controlled randomized clinical trial of alpha-tocopherol (vitamin E) in the treatment of amyotrophic lateral sclerosis. ALS riluzole-tocopherol Study Group. Amyotroph Lateral Scler Other Motor Neuron Disord 2001;2(1):9–18.  
81. Cudkowicz ME, Shefner JM, Schoenfeld DA, et al. A randomized, placebocontrolled trial of topiramate in amyotrophic lateral sclerosis. Neurology 2003;61(4):456–64.  
82. Miller RG, Moore DH, Gelinas DF, et al. Phase III randomized trial of gabapentin in patients with amyotrophic lateral sclerosis. Neurology 2001;56(7):843–8.  
83. Beghi E, Chiò A, Inghilleri M, et al. A randomized controlled trial of recombinant interferon beta-1a in ALS. Italian Amyotrophic Lateral Sclerosis Study Group. Neurology 2000;54(2):469–74.  
84. Beauverd M, Mitchell JD, Wokke JHJ, Borasio GD. Recombinant human insulinlike growth factor I (rhIGF-I) for the treatment of amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2012;11:CD002064.  
85. Cudkowicz ME, van den Berg LH, Shefner JM, et al. Dexpramipexole versus placebo for patients with amyotrophic lateral sclerosis (EMPOWER): a randomised, double-blind, phase 3 trial. Lancet Neurol 2013;12(11):1059–67.  
86. Morren JA, Galvez-Jimenez N. Current and prospective disease-modifying therapies for amyotrophic lateral sclerosis. Expert Opin Investig Drugs 2012;21(3):297–320.  
87. Disease-modifying treatment of amyotrophic lateral sclerosis - UpToDate [Internet]. [cited 2018 Jul 8];Available from: https://www.uptodate.com/contents/disease-modifying-treatment-ofamyotrophic-lateral-  
sclerosis?search=Disease%20modifying%20treatment%20of%20amyotrophic%2  
- 0lateral%20sclerosis&source=search_result&selectedTitle=1~150&usage_type= default&display_rank=1  
88. Consultas - Agência Nacional de Vigilância Sanitária [Internet]. [cited 2018 Jul 9];Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
89. Bensimon G, Lacomblez L, Meininger V. A controlled trial of riluzole in amyotrophic lateral sclerosis. ALS/Riluzole Study Group. N Engl J Med 1994;330(9):585–91.  
90. Lacomblez L, Bensimon G, Leigh PN, Guillet P, Meininger V. Dose-ranging study of riluzole in amyotrophic lateral sclerosis. Amyotrophic Lateral Sclerosis/Riluzole Study Group II. Lancet 1996;347(9013):1425–31.  
91. Liu J, Wang L-N. The efficacy and safety of riluzole for neurodegenerative movement disorders: a systematic review with meta-analysis. Drug Deliv 2018;25(1):43–8.  
92. Abdul Wahid SF, Law ZK, Ismail NA, Azman Ali R, Lai NM. Cell-based therapies for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2016;11:CD011742.  
93. Gamez J, Salvado M, Martinez de la Ossa A, Badia M. Lithium for treatment of amyotrophic lateral sclerosis: much ado about nothing. Neurologia 2016;31(8):550–61.  
94. van Eijk RPA, Jones AR, Sproviero W, et al. Meta-analysis of pharmacogenetic interactions in amyotrophic lateral sclerosis clinical trials. Neurology 2017;89(18):1915–22.  
95. R                 ’                  R          H aminobutyric acid (GABA) modulators for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2017;1:CD006049.  
96. Roche JC, Rojas-Garcia R, Scott KM, et al. A proposed staging system for amyotrophic lateral sclerosis. Brain 2012;135(3):847–52.  
97. Corcia P, Beltran S, Lautrette G, Bakkouche S, Couratier P. Staging amyotrophic lateral sclerosis: A new focus on progression. Rev Neurol (Paris) 2019;175(5):277–82.  
98. Rooney J, Byrne S, Heverin M, et al. A multidisciplinary clinic approach improves survival in ALS: a comparative study of ALS in Ireland and Northern Ireland. Journal of Neurology, Neurosurgery & Psychiatry 2015;86(5):496–501.  
99. Traynor BJ. Effect of a multidisciplinary amyotrophic lateral sclerosis (ALS) clinic on ALS survival: a population based study, 1996-2000. Journal of Neurology, Neurosurgery & Psychiatry 2003;74(9):1258–61.  
100.  Hogden A, Foley G, Henderson R, James N, Aoun S. Amyotrophic lateral sclerosis: improving care with a multidisciplinary approach. JMDH 2017;Volume 10:205– 15.  
101.  Simon S.T., Higginson I.J., Booth S., Harding R., Weingärtner V., Bausewein C. Benzodiazepines for the relief of breathlessness in advanced malignant and nonmalignant diseases in adults. Cochrane Database Syst Rev [Internet] 2016;2016(10). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L612808856  
102.  Protocolo Clínico e Diretrizes Terapêuticas: Espasticidade. [Internet]. [cited 2018 Jul 9];Available from:  
http://portalarquivos2.saude.gov.br/images/pdf/2017/junho/01/MINUTA-dePortaria-SAS-PCDT-Espasticidade-19-05-2017.pdf  
103.  Gibbons C, Pagnini F, Friede T, Young CA. Treatment of fatigue in amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2018;1:CD011005.  
104.  Drug Result Page - MICROMEDEX [Internet]. [cited 2018 Jul 8];Available from: https://www.micromedexsolutions.com/micromedex2/librarian/CS/A52C48/ND _PR/evidencexpert/ND_P/evidencexpert/DUPLICATIONSHIELDSYNC/B3C9F8/ND _PG/evidencexpert/ND_B/evidencexpert/ND_AppProduct/evidencexpert/ND_T /evidencexpert/PFActionId/evidencexpert.IntermediateToDocumentLink?docId= 1680&contentSetId=31&title=RILUZOLE&servicesTitle=RILUZOLE#  
105.  United States Pharmacopeial Convention. USP DI. Englewood CO: Micromedix Inc.; 2000.  
106.  Shafiq F, Mitsikostas D-D, Zis P. Nocebo in motor neuron disease: systematic review and meta-analysis of placebo-controlled clinical trials. Amyotroph Lateral Scler Frontotemporal Degener 2017;18(7–8):576–82.  
107.  Riluzole: Drug information - UpToDate [Internet]. [cited 2019 Nov 26];Available from: https://www.uptodate.com/contents/riluzole-druginformation?search=riluzole&source=panel_search_result&selectedTitle=1~15& usage_type=panel&kp_tab=drug_general&display_rank=1#F218354  
108.  Prabhakar A, Owen CP, Kaye AD. Anesthetic management of the patient with amyotrophic lateral sclerosis. J Anesth 2013;27(6):909–18.  
109.  Zhang J, Wang B, Li R, Ge L, Chen K-H, Tian J. Does antimicrobial lock solution reduce catheter-related infections in hemodialysis patients with central venous catheters? A Bayesian network meta-analysis. Int Urol Nephrol 2017;49(4):701– 16.  
110.  Luo L, Song Z, Li X, et al. Efficacy and safety of edaravone in treatment of amyotrophic lateral sclerosis-a  systematic review and meta-analysis. Neurol Sci 2019;40(2):235–41.  
111.  Elshafay A, Hieu TH, Doheim MF, et al. Efficacy and Safety of Valproic Acid for Spinal Muscular Atrophy: A Systematic Review and Meta-Analysis. CNS Drugs 2019;33(3):239–50.  
112.  Srinivas S, Wali AR, Pham MH. Efficacy of riluzole in the treatment of spinal cord injury: a systematic review  of the literature. Neurosurg Focus 2019;46(3):E6.  
113.  Simonds AK. Home Mechanical Ventilation: An Overview. Ann Am Thorac Soc 2016;13(11):2035–44.  
114.  Au K, Lam D, Garg N, et al. Improving skills retention after advanced structured resuscitation training: A systematic review of randomized controlled trials. Resuscitation 2019;138:284–96.  
115.  Zhou C, Ma G, Li X, et al. Is minimally invasive esophagectomy effective for preventing anastomotic leakages after esophagectomy for cancer? A systematic review and meta-analysis. World J Surg Oncol 2015;13:269.  
116.  Zis P, Mitsikostas D-D. Nocebo Responses in Brain Diseases: A Systematic Review of the Current Literature. Int Rev Neurobiol 2018;139:443–62.  
117.  Sridharan K, Sivaramakrishnan G. Pharmacological interventions for treating sialorrhea associated with neurological disorders: A mixed treatment network meta-analysis of randomized controlled trials. J Clin Neurosci 2018;51:12–7.  
118.  Bartels B, Montes J, van der Pol WL, de Groot JF. Physical exercise training for type 3 spinal muscular atrophy. Cochrane Database Syst Rev 2019;3:CD012120.  
119.  Ferreira GD, Costa ACC, Plentz RDM, Coronel CC, Sbruzzi G. Respiratory training improved ventilatory function and respiratory muscle strength in patients with multiple sclerosis and lateral amyotrophic sclerosis: systematic review and meta-analysis. Physiotherapy 2016;102(3):221–8.  
120.  Ng L, Khan F, Young CA, Galea M. Symptomatic treatments for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev 2017;1:CD011776.  
121.  Donnino MW, Andersen LW, Berg KM, et al. Temperature Management After Cardiac Arrest: An Advisory Statement by the Advanced Life Support Task Force of the International Liaison Committee on Resuscitation and the American Heart Association Emergency Cardiovascular Care Committee and the Council on Cardiopulmonary, Critical Care, Perioperative and Resuscitation. Circulation 2015;132(25):2448–56.  
122.  Bezdjian A, Kraaijenga VJC, Ramekers D, et al. Towards Clinical Application of Neurotrophic Factors to the Auditory Nerve; Assessment of Safety and Efficacy by a Systematic Review of Neurotrophic Treatments in Humans. Int J Mol Sci 2016;17(12).  
123.  Sweegers MG, Buffart LM. [Training to improve quality of life and physical functioning in cancer; which type of training, for which patient, and at which moment?]. Ned Tijdschr Geneeskd 2018;162:D2443.  
124.  Hobson EV, Baird WO, Cooper CL, Mawson S, Shaw PJ, Mcdermott CJ. Using technology to improve access to specialist care in amyotrophic lateral sclerosis: A systematic review. Amyotroph Lateral Scler Frontotemporal Degener 2016;17(5–6):313–24.  
125.  Fernández-Tenorio E., Serrano-Muñoz D., Avendaño-Coy J., Gómez-Soriano J. Estimulación eléctrica nerviosa transcutánea como tratamiento de la espasticidad: una revisión sistemática. Neurologia [Internet] 2016;Available from:  
- http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L613366742  
126.  Ozlem N. A comparison of the results of peg and nasogastric tube feeding. Surg Endosc Interv Tech 2017;31(2):S84.  
127.  Lim K., See Y.M., Lee J. A systematic review of the effectiveness of medical cannabis for psychiatric, movement and neurodegenerative disorders. Clin Psychopharmacol Neurosci 2017;15(4):301–12.  
128.  Petrov D., Mansfield C., Moussy A., Hermine O. ALS clinical trials review: 20 years of failure. Are we any closer to registering a new treatment? Front Aging Neurosci [Internet] 2017;9(MAR). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L615245857  
129.  Conway Z.J., Silburn P.A., Thevathasan W., Maley K.O., Naughton G.A., Cole M.H. Alternate Subthalamic Nucleus Deep Brain Stimulation Parameters to Manage ’                      R    w         -analysis. Mov Disord Clin Pract 2019;6(1):17–26.  
130.  Shoesmith C., Benstead T., Chum M., et al. Canadian ALS best practice recommendations. Amyotrophic Lateral Scler Frontotemporal Degener 2017;18((Shoesmith C., christen.shoesmith@lhsc.on.ca; Chum M.) London Health Sciences Centre, London, ON, Canada):305.  
131.  Farag J., Reebye R., Ganzert C., Mills P. Casting as an adjunct to botulinum neurotoxin injection for limb spasticity in adults: A systematic review. Toxicon 2018;156((Farag J.; Reebye R.; Mills P., patricia.mills@vch.ca) Department of Medicine, University of British Columbia, Vancouver, BC, Canada):S31–2.  
132.  Abdul Wahid S.F., Law Z.K., Lai N.M., Ismail N.A., Azman Ali R. Cell-based therapies for amyotrophic lateral sclerosis/motor neuron disease. Cochrane Database Syst Rev [Internet] 2015;2015(6). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L620562495  
133.  Sharma A., Sane H., Paranjape A., et al. Cellular therapy slows down disease progression in amyotrophic lateral sclerosis. Amyotrophic Lateral Scler Frontotemporal Degener 2016;17((Sharma A., amrutap.neurogen@gmail.com; Sane H.; Paranjape A.; Sawant D.; Inamdar S.; Gokulchandran N.; Badhe P.) NeuroGen Brain and Spine Institute, Navi Mumbai, Maharashtra, India):243–4.  
134.  Maguire C., Mcdermott C., Hind D., Radunovic A., Shaw P.J. Diaphragm pacing systems for amyotrophic lateral sclerosis / motor neuron disease. Cochrane Database Syst Rev [Internet] 2014;2014(11). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L620559851  
135.  Le Pimpec-Barthes F., Legras A., Arame A., et al. Diaphragm pacing: The state of the art. J Thorac Dis 2016;8((Le Pimpec-Barthes F., francoise.lepimpecbarthes@aphp.fr; Legras A.; Arame A.; Pricopi C.; Badia A.) Department of Thoracic Surgery and Lung Transplantation, Assistance Publique-Hôpitaux de Paris, Hopital Europeen Georges Pompidou, Paris, France):S376–86.  
136.  Golby R., Fabros M., Poirier B., Yousefi M., Cashman N. Incidence of ALS in British Columbia, Canada: A 5-year retrospective study. Amyotrophic Lateral Scler Frontotemporal Degener 2015;16((Golby R., rgolby@gmail.com) University of British Columbia, Faculty of Medicine, Vancouver, BC, Canada):147–8.  
137.  Serramontmany E., Alonso C., Gámez J., et al. Level of evidence and degree of recommendation of intravenous immunoglobulin in auto-immune neurological diseases. Euro J Hosp Pharm Sci Pra 2018;25((Serramontmany E.; Alonso C.; V     ’H      U          H Barcelona, Spain):A103.  
138.  Van Eijk R.P.A., Jones A.R., Sproviero W., et al. Meta-analysis of pharmacogenetic interactions in amyotrophic lateral sclerosis clinical trials. Amyotrophic Lateral Scler Frontotemporal Degener 2017;18((Van Eijk R.P.A., r.p.a.vaneijk-2@umcutrecht.nl; Diekstra F.P.; Van Rheenen W.; Eijkemans M.J.C.; Veldink J.H.; Van Den Berg L.H.; Van Es M.A.) University Medical Centre Utrecht, Utrecht, Netherlands):21–2.  
139.  Takei K., Takahashi F., Liu S., Tsuda K., Palumbo J. Onset of detectable effect of edaravone: A post-hoc analysis. Amyotrophic Lateral Scler Frontotemporal Degener 2017;18((Takei K., wendy_agnese@mt-pharma-us.com; Liu S.; Tsuda K.;  
Palumbo J.) Mitsubishi Tanabe Pharma Development America, Inc., Jersey City, NJ, United States):235.  
140.  Buscemi V., Marsden J., Dawes H., et al. Physical activity interventions and therapeutic exercise in rare neurological disorders: A protocol for a scoping review. J Neuromusc Dis 2019;6((Buscemi V., valentina.buscemi@nhs.net; Ramdharry G.) UCLH Queen Square Institute of Neurology, London, United Kingdom):S98.  
141.  Laiwala R.C., Glover J.A., Srinivasan S. Post-stroke pseudobulbar affect-dowe know enough? Am J Geriatr Psychiatry 2016;24(3):S110.  
142.  Velez-Nandayapa L. The risk of depression, euphoric mood and sedation with the use of dextromethorphan in different indications. Results from a systematic review and meta-analysis of randomised clinical trials. Pharmacoepidemiol Drug Saf 2016;25((Velez-Nandayapa L.) Pharmacovigilance, Drug Safety Research Unit (DSRU), Southampton, United Kingdom):590–1.  
143.  Velez-Nandayapa L. The risk of dizziness with the use of dextromethorphan in different indications; Not a rare risk as described in label. Results from a systematic review and meta-analysis of randomised clinical trials. Pharmacoepidemiol Drug Saf 2016;25((Velez-Nandayapa L.) Pharmacovigilance, Drug Safety Research Unit (DSRU), Southampton, United Kingdom):591.  
144.  Young C.A., Gibbons C., Pagnini F., Friede T. Treatment for fatigue in amyotrophic lateral sclerosis/motor neuron disease (ALS/MND). Cochrane Database Syst Rev [Internet] 2014;2014(3). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L620560147  
145.  Velez-Nandayapa L. Unintended central nervous system risks with dextromethorphan in different indications. Preliminary results; systematic review and meta-analysis of randomised clinical trials. Drug Saf 2015;38(10):1038–9.  
146.  D S, D K, R.M.M B, et al. A Systematic Review and Meta-Analysis on Outcomes and Complications of Percutaneous Endoscopic Versus Radiologic Gastrostomy for Enteral Feeding. J Clin Gastroenterol 2018;52(9):753–64.  
147.  S.T S, I.J H, S B, R H, V W, C B. Benzodiazepines for the relief of breathlessness in advanced malignant and non-malignant diseases in adults. Cochrane Database Syst Rev [Internet] 2016;2016(10). Available from: http://www.embase.com/search/results?subaction=viewrecord&from=export&i d=L612808856 U2 - L612808856  
148.  C J, M DC, A G, T H-P, J S. Correlations between slow vital capacity and measures of respiratory function on the ALSFRS-R. Amyotrophic Lateral Scler Frontotemporal Degener 2017;18:275–6.  
149.  M MG, A B, M A, J.M C, C C. Dignity therapy in palliative care: A comprehensive systematic review of the literature. Palliative Med 2016;30(6):NP209.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER RILUZOL -->
Eu,____________________________________________________________  
(nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento riluzol, indicado para o tratamento da esclerose lateral amiotrófica.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico __________________________________ (nome do médico que prescreve).  
Assim declaro que:  
Fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhorias:  
- leve melhora de sintomas da doença;  
- aumento da sobrevida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez, portanto, caso engravide, devo avisar imediatamente ao meu médico;  
- os efeitos adversos incluem fraqueza, sono, náuseas, vômitos, diarreia, dor na barriga, formigamentos, alteração nas enzimas do fígado, dor de cabeça, aumento dos batimentos do coração, diminuição das células brancas (diminuição das defesas) e vermelhas (anemia) do sangue;  
- contraindicado em pacientes com hipersensibilidade ao riluzol ou aos componentes da fórmula e aqueles com problemas no fígado.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser assistido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.    (     ) Sim        (    ) Não  
|~~Local:~~|~~Data:~~|
|---|---|
|~~Nome do paciente:~~||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: Documento de identificação do responsável legal: -->
_____________________________________ Assinatura do paciente ou do responsável legal Médico CRM: UF: Responsável: ___________________________ Assinatura e carimbo do médico Data:  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **1. Escopo e finalidade do Protocolo** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Esclerose Lateral Amiotrófica iniciou-se com a reunião presencial para delimitação do escopo. O objetivo desta reunião foi a discussão sobre a atualização do referido PCDT.  
Uma reunião presencial para revisão do escopo do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida e contou com a presença de oito membros do Grupo Elaborador, sendo três dos quais especialistas e representantes da sociedade médica e três metodologistas, e quatro representantes do Comitê Gestor.  
A dinâmica da reunião realizada em 21/03/2019 foi conduzida com base no PCDT vigente (Portaria nº 1.151/SAS/MS, de 12 de novembro de 2015) e na estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas no Protocolo.  
Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **2. Equipe de elaboração e partes interessadas** -->
Além dos representantes do Ministério da Saúde do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), houve a participação na elaboração deste Protocolo de metodologistas do Hospital Alemão Oswal Cruz (HAOC)/Proadi-SUS e especialistas no tema.  
Todos os participantes do Grupo Elaborador preencheram os respectivos formulários de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados do trabalho.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
Foi apresentado a primeira versão do PCDT à reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas da Conitec, realizado no mês de junho de 2019, e, após a análise e realização dos ajustes e correções apontadas, foi decidido por unanimidade pautar o tema na reunião na 87ª Reunião Ordinária da Conitec, agendada para 03 e 04 de junho de 2020.

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **Consulta pública** -->
A Consulta Pública nº 72 do PCDT foi feita entre os dias 16/12/2019 a 16/01/2020. Foram recebidas 593 contribuições no total e salienta-se que todas foram analisadas e feito o resumo da análise das contribuições recebidas. O conteúdo integral das contribuições se encontra disponível na página da CONITEC em:  
<u>http://conitec.gov.br/images/Consultas/Relatorios/2019/Relatorio_PCDT_Esclerose_L ateral_Amiotrofica.pdf  .</u>

---

<!-- METADADOS: doenca: Esclerose Lateral Amiotrófica | secao: **3. Busca da evidência e recomendações** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados Medline via Pubmed e Embase, limitando os resultados para revisões sistemáticas de ensaios clínicos randomizados (ECR) e meta-análises de ECR, usando filtros validados da _Cochrane Collaboration_ , publicados desde 31/08/2015, conforme o **Quadro A** . Foram incluídos nove estudos conforme **Figura A** .  
**<u>Quadro A</u>** - Estratégia de busca  
|Medline<br>via<br>PubMed|((ALS[All Fields] OR "amyotrophic lateral sclerosis"[MeSH Terms] OR<br>("amyotrophic lateral sclerosis"[MeSH Terms] OR ("amyotrophic"[All Fields]<br>AND "lateral"[All Fields] AND "sclerosis"[All Fields]) OR "amyotrophic lateral<br>sclerosis"[All Fields]) OR "motor neuron disease"[MeSH Terms] OR ("motor<br>neuron disease"[MeSH Terms] OR ("motor"[All Fields] AND "neuron"[All<br>Fields] AND "disease"[All Fields]) OR "motor neuron disease"[All Fields])) AND<br>(("therapy"[Subheading] OR "therapy"[All Fields] OR "treatment"[All Fields]<br>OR "therapeutics"[MeSH Terms] OR "therapeutics"[All Fields]) OR ("drug<br>therapy"[Subheading] OR ("drug"[All Fields] AND "therapy"[All Fields]) OR<br>"drug therapy"[All Fields] OR "drug therapy"[MeSH Terms] OR ("drug"[All<br>Fields]<br>AND<br>"therapy"[All<br>Fields]))<br>OR<br>("therapy"[Subheading]<br>OR<br>"therapy"[All Fields] OR "therapeutics"[MeSH Terms] OR "therapeutics"[All<br>Fields]) OR ("therapeutics"[MeSH Terms] OR "therapeutics"[All Fields]) OR<br>"therapeutics"[MeSH Terms])) AND (randomized controlled trial[pt] OR<br>controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR "clinical<br>trials as topic"[MeSH Terms:noexp] OR randomly[tiab] OR trial[ti] NOT<br>("animals"[MeSH Terms] NOT "humans"[MeSH Terms])) AND ((systematic[sb]<br>OR Meta-Analysis[ptyp])AND("2015/08/31"[PDAT]: "3000/12/31"[PDAT]))|
|---|---|
||('crossover procedure':de OR 'double-blind procedure':de OR 'randomized<br>controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR<br>factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti)<br>OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1<br>blind*):de,ab,ti)<br>OR<br>assign*:de,ab,ti<br>OR<br>allocat*:de,ab,ti<br>OR|
|Embase|volunteer*:de,ab,ti) AND ('amyotrophic lateral sclerosis'/exp OR 'amyotrophic<br>lateral sclerosis' OR 'motor neuron disease'/exp OR 'motor neuron disease')<br>AND (('treatment'/exp OR treatment OR 'drug therapy'/exp OR 'drug therapy'<br>OR 'therapy'/exp OR 'therapy' OR 'drug'/exp OR drug) AND ('therapy'/exp OR<br>therapy) OR 'therapy'/exp OR therapy OR 'therapeutics'/exp OR therapeutics)<br>AND [31-8-2015]/sd AND ([systematic review]/lim OR [meta analysis]/lim)<br>AND[embase]/lim NOT([embase]/lim AND[medline]/lim)|  
<!-- Start of picture text -->
Estudos identificados nas<br>bases de dados (n=53) Embase (n= 29)<br>Medline via Pubmed (n=24)<br>Duplicatas (n=5)<br>IN3o estudaram ELA ou DNM (n =17)<br>RevisOes narrativas ou editoriais (n= 10)<br>No avaliaram desfechos clinicos de interesse (n=6)<br>Estudos excluidos (n=39) .<br>Ndo em RS nem meta-analise de ECR (n=4)<br>edicamento sem registro Anvisa (n=2)<br>Estudos incluidos (n=9) Referéncias ( 47,91-95,10,106,120)<br><!-- End of picture text -->  
**Figura A** – Fluxograma de seleção dos estudos

---

