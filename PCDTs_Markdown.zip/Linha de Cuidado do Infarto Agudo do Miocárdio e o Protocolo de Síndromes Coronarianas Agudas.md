<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: Geral -->
**ADVERTÊNCIA**  
Este texto não substitui o publicado no Diário Oficial da União  
**Ministério da Saúde Gabinete do Ministro**  
**PORTARIA Nº 2.994 DE 13 DE DEZEMBRO DE 2011 (*)**  
**_Aprova a Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas, cria e altera procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS._**  
O MINISTRO DO ESTADO DA SAÚDE no uso de suas atribuições previstas no inciso II do parágrafo único art. 87 da Constituição Federal e,  
Considerando que as doenças cardiovasculares constituem a principal causa de morbidade, incapacidade e morte no mundo e no Brasil;  
Considerando a alta prevalência da Síndrome Coronariana Aguda (SCA) e sua importância como causa de morbidade e mortalidade no Brasil e no mundo;  
Considerando a necessidade de uma ação integrada para reduzir a ocorrência das doenças cardiovasculares, bem como a necessidade de padronizar o tratamento da SCA no âmbito do Sistema Único de Saúde (SUS);  
Considerando a Portaria GM/MS n°4.279, de 30 de dezembro de 2010, que prioriza a organização e implementação das Redes de Atenção à Saúde (RAS) no país;  
Considerando a Portaria GM/MS nº1.600, de 07 de julho de 2011 que reformula a Política Nacional de Atenção às Urgências e a implementação da Rede de Atenção às Urgências;  
Considerando a instituição da Linha de Cuidado do Infarto Agudo do Miocárdio (IAM) como prioritária e componente de atenção na Rede de Atenção às Urgências;  
Considerando a Consulta Pública SAS/MS n° 06, de 20 de setembro de 2011; e  
Considerando a necessidade de aprimorar os mecanismos de regulação, controle e avaliação da assistência aos portadores de doença cardiovascular, resolve:  
Art. 1º Aprovar a Linha de Cuidado do Infarto Agudo do Miocárdio (IAM) e do Protocolo Clínico sobre Síndromes Coronarianas Agudas (SCA).  
Parágrafo único. A Linha de Cuidado do IAM e o Protocolo Clínico sobre SCA de que trata este artigo encontram-se disponíveis no endereço eletrônico www.saude.gov.br/sas.  
Art. 2º Incluir na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS os seguintes procedimentos:  
|Procedimento|06.03.05.004-2 - ALTEPLASE 10MG<br>INJETÁVEL (POR FRASCO AMPOLA).|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover a reperfusão arterial na<br>trombose arterial aguda, como no infarto<br>agudo do miocárdio.|
|Modalidade|02 - Hospitalar|
|Instrumento de Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|
|Valor Ambulatorial SA|R$0,00|
|Valor Ambulatorial<br>Total|R$ 0,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 167,00|
|Valor Hospitalar Total|R$ 167,00|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|01|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|
|CBO|2234-05|
|Serviço/Classificação|125 - Serviço de Farmácia - 006 - Farmácia<br>Hospitalar|  
|Procedimento|06.03.05.005-0 - ALTEPLASE 20MG<br>INJETÁVEL (POR FRASCOAMPOLA).|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover areperfusão arterial na<br>trombose arterial aguda, como no infarto<br>agudodo miocárdio.|
|Modalidade|02 - Hospitalar|
|Instrumento de Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|  
|Valor Ambulatorial SA|R$ 0,00|
|---|---|
|Valor Ambulatorial<br>Total|R$ 0,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 334,00|
|Valor Hospitalar Total|R$ 334,00|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|02|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|
|CBO|2234-05|
|Serviço/Classificação|125 - Serviço de Farmácia - 006 - Farmácia<br>Hospitalar|  
|Procedimento|06.03.05.006-9 - ALTEPLASE 50MG<br>INJETÁVEL (POR FRASCOAMPOLA).|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover areperfusão arterial na<br>trombose arterial aguda, como no infarto<br>agudodo miocárdio.|
|Modalidade|02 - Hospitalar|
|Instrumento de Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|
|Valor Ambulatorial SA|R$ 0,00|
|Valor Ambulatorial<br>Total|R$ 0,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 835,00|
|Valor Hospitalar Total|R$ 835,00|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|01|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|  
CBO 2234-05 125 - Serviço de Farmácia - 006 - Serviço/Classificação Farmácia Hospitalar  
|Procedimento|06.03.05.007-7 - TENECTEPLASE - TNK<br>30MG INJETÁVEL (PORFRASCO<br>AMPOLA)|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover areperfusão arterial no<br>infarto agudo do miocárdio, administrado<br>eminfusão rápida.|
|Modalidade|02 - Hospitalar|
|Instrumento de<br>Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|
|Valor Ambulatorial<br>SA|R$ 0,00|
|Valor Ambulatorial<br>Total|R$ 0,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 1.357,50|
|Valor Hospitalar Total|R$ 1.357,50|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|01|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|
|CBO<br>Serviço/Classificação|2234-05 125 - Serviço de Farmácia - 006 -<br>Farmácia Hospitalar|  
|Procedimento|06.03.05.008-5 - TENECTEPLASE - TNK<br>40MG INJETÁVEL (POR FRASCO<br>AMPOLA)|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover a reperfusão arterial no<br>infarto agudo do miocárdio, administrado em<br>infusão rápida.|
|Modalidade|02 - Hospitalar|  
|Instrumento de Registro|04 - AIH Procedimento especial|
|---|---|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC)|
|Valor Ambulatorial SA|R$0,00|
|Valor Ambulatorial<br>Total|R$0,00|
|Valor Hospitalar SP|R$0,00|
|Valor Hospitalar SH|R$1.810,00|
|Valor Hospitalar Total|R$1.810,00|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|01|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|
|CBO|2234-05|
|Serviço/Classificação|125 - Serviço de Farmácia - 006 - Farmácia<br>Hospitalar|  
|Procedimento|06.03.05.009-3 - TENECTEPLASE - TNK<br>50MG INJETÁVEL (POR FRASCO<br>AMPOLA)|
|---|---|
|Descrição|Medicamento trombolítico fibrino-específico,<br>usado para promover a reperfusão arterial no<br>infarto agudo do miocárdio, administrado em<br>infusão rápida.|
|Modalidade|02 - Hospitalar|
|Instrumento de Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|
|Valor Ambulatorial SA|R$0,00|
|Valor Ambulatorial<br>Total|R$0,00|
|Valor Hospitalar SP|R$0,00|
|Valor Hospitalar SH|R$ 2.262,50|
|Valor Hospitalar Total|R$ 2.262,50|
|Sexo|Ambos|
|Idade Mínima|00|  
|Idade Máxima|110|
|---|---|
|Quantidade Máxima|01|
|CID Principal|I210, I211, I212, I213, I214, I219, I220, I221,<br>I228, I229|
|CBO|2234-05|
|Serviço/Classificação|125 - Serviço de Farmácia - 006 - Farmácia<br>Hospitalar.|  
|Procedimento|06.03.05.010-7 - CLOPIDOGREL 75MG -<br>COMPRIMIDO|
|---|---|
|Descrição|Inibidor da agregação plaquetária usado no<br>tratamento da síndrome coronariana aguda.<br>Diante da necessidade de continuação do<br>tratamento, o estabelecimento hospitalar<br>deverá entregar no dia da alta 30 (trinta)<br>comprimidos aopaciente.|
|Modalidade|02 - Hospitalar|
|Instrumento de Registro|04- AIH Procedimento especial.|
|Complexidade|MC - Média Complexidade|
|Tipo de Financiamento|06 - Média e Alta Complexidade (MAC).|
|Valor Ambulatorial SA|R$ 0,00|
|Valor Ambulatorial<br>Total|R$ 0,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 0,50|
|Valor Hospitalar Total|R$ 0,50|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|40|
|CID Principal|I200, I201, I210, I211, I212, I213, I214, I219,<br>I220, I221, I228, I229, I230, I231, I232, I233,<br>I234, I235, I236, I238, I240, I248, I249|
|CBO|2234-05|
|Serviço/Classificação|125 - Serviço de Farmácia - 006 - Farmácia<br>Hospitalar|  
|Procedimento|02.02.03.120-9 - DOSAGEM DE TROPONINA.|
|---|---|
|Descrição|Exame para diagnóstico do IAM, distinguindo-o<br>de dor torácica resultante de outras causas.|
|Modalidade|01 - Ambulatorial - 02 - Hospitalar 03- Hospital-<br>dia.|
|Instrumento de Registro|02- BPAI-Individualizado, 04- AIH Proc. Especial.|
|Complexidade|Média Complexidade|
|Tipo de Financiamento|Média e Alta Complexidade (MAC).|
|Valor Ambulatorial SA|R$ 9,00|
|Valor Ambulatorial<br>Total|R$ 9,00|
|Valor Hospitalar SP|R$ 0,00|
|Valor Hospitalar SH|R$ 9,00|
|Valor Hospitalar Total|R$ 9,00|
|Sexo|Ambos|
|Idade Mínima|00|
|Idade Máxima|110|
|Quantidade Máxima|02|
|CBO|2211-05, 2212-05, 2231-48, 2234-10, 2253-35|
|Serviço/Classificação|145 - Serviços de diagnóstico por laboratório<br>clínico - 003 - Exames<br>Sorológicos e Imunológicos.|  
Parágrafo único - Os procedimentos a seguir são excludentes entre si:  
|CÓDIGO - NOME|CÓDIGO - NOME|
|---|---|
|06.03.05.004-2 - ALTEPLASE 10MG|06.03.05.007-7-TENECTEPLASE - TNK 30MG<br>06.03.05.008-5 - TENECTEPLASE - TNK 40MG<br>06.03.05.009-3-TENECTEPLASE - TNK 50MG|
|06.03.05.005-0 - ALTEPLASE 20MG|06.03.05.007-7-TENECTEPLASE - TNK 30MG<br>06.03.05.008-5 - TENECTEPLASE - TNK 40MG<br>06.03.05.009-3-TENECTEPLASE - TNK 50MG|
|06.03.05.006-9-ALTEPLASE INJETÁVEL<br>50MG|<br>06.03.05.007-7-TENECTEPLASE - TNK 30MG<br>06.03.05.008-5 - TENECTEPLASE - TNK 40MG<br>06.03.05.009-3-TENECTEPLASE - TNK 50MG|
|06.03.05.007-7 -TENECTEPLASE -<br>TNK 30MG|06.03.05.008-5 - TENECTEPLASE - TNK 40MG<br>06.03.05.009-3-TENECTEPLASE - TNK 50MG|
|06.03.05.008-5 - TENECTEPLASE<br>- TNK 40MG|06.03.05.007-7 - TENECTEPLASE - TNK 30MG<br>06.03.05.009-3 - TENECTEPLASE - TNK 50MG|
|06.03.05.009-3-TENECTEPLASE -<br>TNK 50MG|06.03.05.007-7 - TENECTEPLASE - TNK 30MG<br>06.03.05.008-5 - TENECTEPLASE - TNK 40MG|  
Art. 3º Alterar na Tabela de Procedimentos, Medicamentos e OPM do SUS os atributos dos procedimentos a seguir:  
|Procedimento|03.03.06.019-0 - TRATAMENTO DE<br>INFARTO AGUDO DO MIOCARDIO|
|---|---|
|Descrição|Consiste no tratamento para alívio da<br>obstrução das artérias coronárias e sofrimento<br>do miocárdio.|
|Valor Hospitalar SP|R$ 116,72|
|Valor Hospitalar SH|R$ 471,40|
|Valor Hospitalar Total|R$ 588,12|
|Procedimento|03.03.06.028-0 - TRATAMENTO DA<br>SÍNDROME CORONARIANA AGUDA|
|Descrição|Consiste no tratamento do sofrimento do<br>miocárdio na vigência da insuficiência de<br>fluxo sanguíneo nas coronárias.|
|Valor Hospitalar SP|R$ 59,27|
|Valor Hospitalar SH|R$ 265,81|
|Valor Hospitalar Total|R$ 325,08|  
|Procedimento|04.06.03.004-9 - ANGIOPLASTIA<br>CORONARIANA PRIMARIA|
|---|---|
|Valor Hospitalar SP|R$ 644,44|
|Valor Hospitalar SH|R$ 1.103,08|
|Valor Hospitalar Total|R$ 1.747,52|  
Art. 4º Garantir, na alta hospitalar, a continuidade do uso da medicação clopidogrel (75 mg) para que o paciente faça uso diário por trinta (30) dias da referida medicação, conforme protocolo clínico supracitado.  
Parágrafo único: A medicação clopidogrel será fornecida pelo hospital quando da internação do paciente, conforme protocolo clínico, e o hospital deverá fornecê-la ao paciente por mais 30 dias da alta, até que seja adquirido pelo componente especial da assistência farmacêutica (CEAF).  
Art. 5º. Instituir no âmbito do SUS a Unidade de Terapia Intensiva Coronariana - UCO.  
§ 1º Entende-se por Unidade de Terapia Intensiva Coronariana, ou simplesmente, Unidade Coronariana - UCO, a unidade de terapia intensiva dedicada ao cuidado a pacientes com síndrome coronariana aguda, devendo, necessariamente, dispor de infraestrutura típica de terapia intensiva, mas se localizar em instituição capacitada para fornecer apoio diagnóstico e terapêutico para os pacientes com síndrome coronariana aguda, incluindo recursos humanos qualificados, métodos diagnósticos não invasivos e invasivos e oportunidade de tratamento percutâneo e cirúrgico em caráter de urgência.  
§ 2º Será incluído na Tabela de Leitos Complementares do Sistema de Cadastro Nacional dos Estabelecimentos de Saúde - SCNES, o tipo de leito de Unidade de Terapia Intensiva Coronariana - UCO.  
§ 3º A UCO deverá ser habilitada como Leito de Terapia Intensiva Coronariana - UCO tipo II ou tipo III, de acordo com os critérios de habilitação de Unidade de Terapia Intensiva - UTI tipo II ou tipo III dispostos na Portaria GM/MS nº 3.432, de 12 de agosto de 1998.  
Art. 6º Receberão o custeio diferenciado de R$ 800,00 (oitocentos reais) a diária, de acordo com a forma de cálculo disposta no Anexo desta Portaria, os leitos de Unidades de Terapia Intensiva Coronarianas - UCO nas 37 regiões metropolitanas com maior número de internações e óbito por Infarto Agudo do Miocárdio - IAM, cujos parâmetros são:  
I - Implantação de 01 (uma) Unidade de Terapia Intensiva Coronariana - UCO com 10 leitos para cada 600 IAM/ano nas 10 (dez) Regiões Metropolitanas com maior frequência de Infarto Agudo do Miocárdio - IAM (acima 600 IAM/ano);  
II - Implantação de 02 (dois) leitos de Unidade de Terapia Intensiva Coronariana - UCO no mesmo espaço físico de uma Unidade de Terapia Intensiva nas 27 regiões metropolitanas com frequência entre 100 a 599 IAM/ano.  
§ 1º Serão financiadas 39 (trinta e nove) Unidades Coronarianas - UCO com 10 (dez) leitos cada, em um total de 390 leitos, nas 10 (dez) regiões metropolitanas com frequência de atendimento IAM acima de 600 IAM por ano, mediante a apresentação de projeto para pleitear investimento para implantação da nova unidade no valor de 1 milhão (um milhão de reais) por meio da celebração de convênio ou instrumentos congêneres, devendo estes recursos ser repassados de acordo com as normas do Sistema de Contratos e Convênios do Fundo Nacional de Saúde.  
§ 2º Serão financiados 150 leitos de UCO nas 27 regiões metropolitanas com frequência de atendimento de 100 a 599 IAM por ano, mediante a apresentação de projeto para pleitear investimento para implantação de novos leitos no valor de 100.000,00 (cem mil reais) por leito por meio da celebração de convênio ou instrumentos congêneres, devendo estes recursos serem repassados de acordo com as normas do Sistema de Contratos e Convênios do Fundo Nacional de Saúde.  
Art. 7º Para solicitar habilitação dos leitos de Unidade de Terapia Intensiva Coronariana - UCO, a instituição hospitalar deve cumprir os seguintes requisitos:  
I - Estar habilitada como Centro de Referência ou Unidades de Assistência em Alta Complexidade Cardiovascular, com Serviço de Assistência de Alta Complexidade em Cardiologia Intervencionista, nos termos das Portarias nº 1169/GM e nº 210/SAS, de 15 de junho de 2004;  
II - Possuir leito credenciado como UTI tipo II ou III, conforme Portaria GM/MS nº 3.432, de 12 de agosto de 1998 ou, para novos leitos, seguir os trâmites de habilitação dispostos nesta portaria ou em outra que venha a substituí-la; e  
III - Participar da Linha de Cuidado do IAM na Rede de Atenção às Urgências, por indicação do gestor, realizando ações que permitam sua plena integração com os outros pontos de atenção, nos termos do documento base da referida linha de cuidado, de modo a garantir o cuidado integral e de qualidade ao paciente com síndrome coronariana aguda;  
Art. 8º Para receberem o custeio diferenciado de 800 reais, as UCO deverão cumprir os seguintes critérios de qualificação:  
I - estabelecimento e adoção de protocolos clínicos, assistenciais e de procedimentos administrativos;  
II - equipe de UTI Tipo II ou III, bem como suporte para especialidades nas 24 (vinte e quatro) horas do dia e em todos os dias da semana;  
III - organização do trabalho das equipes multiprofissionais de forma horizontal, utilizando-se prontuário único compartilhado por toda equipe;  
IV - implantação de mecanismos de gestão da clínica visando à qualificação do cuidado, eficiência de leitos, reorganização dos fluxos e processos de trabalho e a implantação de equipe de referência para responsabilização e acompanhamento dos casos;  
V - garantia de realização dos procedimentos diagnósticos e terapêuticos necessários à complexidade dos casos;  
VI - garantia de desenvolvimento de atividades de educação permanente para as equipes, por iniciativa própria ou por meio de cooperação;  
VII - submissão à auditoria do gestor local;  
VIII - regulação integral pelas Centrais de Regulação; e  
IX - taxa de ocupação média mensal da unidade de, no mínimo, 90% (noventa por cento).  
§1º As UCO deverão se qualificar em um prazo máximo de 6 (seis) meses após o início do repasse do custeio diferenciado, previsto nesta Portaria.  
§ 2º O incentivo financeiro de custeio diferenciado de que trata o art. 6º desta Portaria será repassado aos fundos de saúde e, em seguida, aos prestadores de serviços hospitalares, mediante o cumprimento dos critérios de qualificação estabelecidos neste artigo e das metas pactuadas entre os gestores e os prestadores de serviços hospitalares.  
§ 3º Em caso de inobservância dos prazos previstos no § 1º deste artigo, o repasse do incentivo financeiro será cancelado.  
§ 4º Uma vez cancelado o incentivo financeiro, novo pedido somente será deferido com a qualificação integral, demonstrado o cumprimento de todos os requisitos deste artigo, caso em que o incentivo voltará a ser pago a partir do novo deferimento pelo Ministério da Saúde.  
Art. 9º Incluir na tabela de habilitações do SCNES, as seguintes habilitações código 26.08 - Unidade de Terapia Intensiva Coronariana - UCO tipo II e 26.09 - Unidade de Terapia Intensiva Coronariana - UCO tipo III.  
Art. 10 Definir que será publicada em portaria específica a operacionalização das terapias medicamentosas ora incluídas para as Unidades de Pronto Atendimento (UPA 24h) e Serviço de Atendimento Móvel de Urgência (SAMU 192), previstos na Linha de Cuidado do IAM e Protocolo da Síndrome Coronariana Aguda.  
Art. 11 Esta Portaria entra em vigor a partir da competência janeiro de 2012.  
##### **ALEXANDRE ROCHA SANTOS PADILHA**  
##### ANEXO  
LEITOS DE TERAPIA INTENSIVA CORONARIANA - UCO  
I - Valor do incentivo anual para o gestor = Número de leitos de UCO X 365 dias X R$800,00 X 0,90 (90%de taxa de ocupação).  
II - Valor do incentivo anual para o prestador = Número de leitos de UCO X 365 dias X (R$800,00 - valor da diária de UTI tipo II ou tipo III da tabela SUS) X 0,90 (90 % de taxa de ocupação).  
Para isto, os leitos de UCO deverão preencher as condições previstas em portarias específicas para habilitação como UTI tipo II ou III, e faturar as diárias no SIH- SUS.  
(*) Republicada por ter saído no DOU nº 241, de 16 de dezembro de 2011, Seção 1, págs. 118 e 119, com incorreção do original.  
**Saúde Legis - Sistema de Legislação da Saúde**

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
1  
##### **Índice**  
||Página|
|---|---|
|Introdução|3|
|1. O infarto agudo do miocárdio e as terapias de reperfusão|4|
|1.1 Doença Arterial Coronariana e Infarto Agudo do Miocárdio|4|
|1.2 Angioplastia versus terapia trombolítica|5|
|2. Seleção dos pacientes candidatos a terapia de reperfusão pelo eletrocardiograma<br>pré-hospitalar|10|
|3. Linha de Cuidado do Infarto Agudo do Miocárdio|12|
|4. Proposta de indicadores para monitoramento da implementação da Linha de<br>Cuidado do IAM no Brasil|13|
|4.1 Objetivo geral|14|
|4.2 Objetivos específicos|14|
|Referências bibliográficas|16|  
2

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
As doenças cardiovasculares (DCV) são a principal causa de morbidade, incapacidade e morte no mundo e no Brasil, sendo responsáveis por 29% das mortes registradas em 2007. Os gastos com internações pelo SUS totalizaram 1,2 milhões em 2009 e, com envelhecimento da população e mudança dos hábitos de vida, a prevalência e importância das DCV tende a aumentar nos próximos anos. A Organização Panamericana de Saúde (OPAS) reconhece a necessidade de uma ação integrada contra as DCV e irá propor aos países membros que estabeleçam a meta global de reduzir a taxa de mortalidade por DCV em 20% na década de 2011-2020 em relação à década precedente.  
Entre as causas de morte e hospitalização por DCV, destacam-se as síndromes coronarianas aguda (SCA), incluindo o infarto agudo do miocárdio (IAM) e a angina instável (AI). Com os avanços no tratamento da SCA, a mortalidade no IAM nos estudos observacionais caiu de 30%  na década de 50 para menos de 5% nos registros mais recentes em países desenvolvidos. O tratamento moderno do IAM depende do uso de terapias de reperfusão, rápido acesso ao serviço médico e uso de medicações específicas com benefício comprovado. (1) Embora a maioria das abordagens indicadas no tratamento do IAM estarem disponíveis no SUS, a mortalidade hospitalar pelo IAM continua elevada, o que exige uma ação integrada do Ministério da Saúde, Sociedades Científicas, gestores estaduais e municipais e hospitais.  
Neste sentido, o Ministério da Saúde publicou a Portaria GM Nº 1600 de 07 de junho de 2011 que institui a Rede de Atenção às Urgências no âmbito do SUS.  A organização da Rede de Atenção às Urgências tem a finalidade de articular e integrar todos os equipamentos de saúde, objetivando ampliar e qualificar o acesso humanizado e integral aos usuários em situação de urgência e emergência nos serviços de saúde, de forma ágil e oportuna. A Linha de Cuidado Cardiovascular foi definida como prioritária dentre as demais previstas na Rede.  
Este documento resume os princípios que norteiam a construção da Linha de Cuidado do IAM na Rede de Atenção às Urgências no SUS.  
3

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
#### **1.1 Doença Arterial Coronariana e Infarto Agudo do Miocárdio**  
A doença arterial coronariana (DAC) representa a principal causa de óbito no mundo inteiro.(4) Nenhuma outra doença tem maior impacto clínico ou determina maiores gastos financeiros. O mecanismo da DAC geralmente se relaciona à obstrução da luz da artéria coronária por uma placa aterosclerótica, fazendo com que o fluxo sanguíneo se torne insuficiente para uma determinada região do miocárdio, devido ao desequilíbrio entre a oferta e o consumo de oxigênio.  
A DAC pode se apresentar em sua forma crônica, como na angina estável, ou como uma síndrome coronariana aguda (SCA), que engloba a angina instável (AI) e o infarto agudo do miocárdio (IAM). O termo SCA é empregado aos pacientes com evidências clínicas ou laboratoriais de isquemia aguda, produzida por desequilíbrio entre suprimento e demanda de oxigênio para o miocárdio, sendo, na maioria das vezes, causada por instabilização de uma placa aterosclerótica.  
São duas as formas de apresentação da SCA (figura 1): aquela com supradesnivelamento do segmento ST (SCACSSST), ou infarto agudo do miocárdio com supra de ST (IAMCSST), e aquela sem supradesnivelamento do segmento ST (SCASSST). Esta diferenciação é essencial para o tratamento imediato do IAMCSST através da reperfusão miocárdica. A SCASSST se subdivide em angina instável (AI) e infarto agudo do miocárdio sem supradesnivelamento do segmento ST (IAMSSST). Ambos tem apresentações clínicas e eletrocardiográficas semelhantes, sendo distinguidas apenas pela elevação (IAMSSST) ou não (AI) dos marcadores de necrose miocárdica, como troponina I (TnI) e T (TnT) e creatinofosfoquinase – fração MB (CK-MB), após algumas horas do início dos sintomas.  
Considerando que muitos casos de infarto não são internados ou são internados pelo sistema suplementar de saúde, estima-se em 300 a 400 mil o número de infarto ao ano no país e que a cada cinco a sete casos ocorra um óbito. (1) Assim, apesar dos inúmeros avanços terapêuticos obtidos nas últimas décadas, a SCA é ainda uma das mais importantes causas de morte da atualidade. O grande desafio é tornar o tratamento para a síndrome coronariana aguda disponível para a população como um todo, promovendo efetivamente a redução da letalidade da doença em nosso meio.  
4  
<!-- Start of picture text -->
Figura 1 — Formas clinicas da Sindrome coronariana aguda<br>Sindrome Coronariana Aguda<br>SCA sem supra ST SCA com supra ST<br>(SCASSST) (SCACSST)<br>Angina Instavel IAM sem supra ST IAM com supra ST<br>(Al) (IAMSSST) (IAMCSST)<br><!-- End of picture text -->  
#### **1.2 Angioplastia versus terapia trombolítica**  
Das 1.099.131 mortes ocorridas no Brasil em 2009, 99.835 foram atribuídas às doenças isquêmicas do coração, das quais 75.868 são decorrentes do infarto agudo do miocárdio, o que representa 6,9% de todas as mortes (www.datasus.gov.br, acessado em 10 de abril de 2010). É interessante observar que quase a metade dos óbitos (29.849) ocorreu fora do hospital, com destaque para o domicílio do paciente (25.220). Estes números refletem o fato de que, 25 a 35% dos pacientes infartados morrem antes de receber cuidados médicos, geralmente por fibrilação ventricular. (5)  
Para o mesmo período de 2009, foram registradas apenas 57.987 internações no sistema único de saúde com os códigos de procedimento INFARTO AGUDO DO MIOCARDIO (77500024) ou ANGIOPLASTIA CORONARIANA PRIMARIA (48030112), confirmando esta impressão de que muitos pacientes não chegam a ser internados.  
A mortalidade hospitalar por IAM, que se situava em torno de 30% na década de 50, vem melhorando consideravelmente ao longo dos anos. Um estudo recente em quatro estados americanos mostrou que a mortalidade em 30 dias (semelhante à hospitalar) caiu de 8,6% para 3,6% de 1988 a 2000, indicando o elevado impacto das novas modalidades terapêuticas, entre  
5  
as quais se destaca as terapias de reperfusão e o uso de medicamentos. No Brasil, os dados do DATASUS mostram mortalidade elevada para os pacientes que internam com código de procedimento INFARTO AGUDO DO MIOCARDIO (77500024): 15,32%, bem acima dos valores relatados acima, sugerindo que muito possa ser feito para redução da mortalidade em nosso país.  
A restauração do fluxo coronariano é o principal objetivo terapêutico no IAMCSST, no qual a trombose coronariana é o principal mecanismo fisiopatológico subjacente, limitando a extensão da necrose miocárdica e reduzindo a mortalidade. (5) Existem duas formas principais de reperfusão coronariana: a química, com agentes trombolíticos, e a mecânica, através da angioplastia primária.(6) A revascularização miocárdica cirúrgica é reservada para casos selecionados, de alto risco, em que não houve sucesso ou há contra-indicações para outro método. O primeiro relato de caso de angioplastia coronariana primária foi publicado em 1983.(7) Já os agentes trombolíticos foram descobertos nos anos 50, mas apenas foram incorporados à prática clínica em 1986, após o estudo GISSI.(8) Quando agentes trombolíticos são associados ao ácido acetilsalicílico, 50 vidas são salvas em 1000 pacientes tratados.(9) Apesar de essa terapia ser amplamente disponível, facilmente administrada e custo-efetiva, existem limitações importantes no seu uso, (10) especificamente relacionadas à existência de pacientes que não são elegíveis para a trombólise química; de menor freqüência (60 a 70%) de reperfusão completa e da ocorrência de acidente vascular cerebral (AVC) em  1 a 2% dos casos. (10;11) Apesar de tais limitações, a possibilidade de realização de trombólise no ambiente pré-hospitalar e a ampla disponibilidade dos trombolíticos tornam este tratamento como de eleição em muitos sistemas de saúde.  
Por outro lado, a angioplastia primária tem vantagens no que se refere ao sucesso, já que leva a revascularização completa em 90 a 95% dos pacientes. (10;11) Dentre algumas de suas complicações, destacam-se aquelas relacionadas ao acesso vascular (sangramento, hematoma, pseudoaneurisma e fístula arteriovenosa) que ocorrem em 2 a 12% dos casos, (12) nefropatia grave (relacionada, pelo menos parcialmente, ao uso de contraste iodado) em até 2% dos pacientes, (13) e taquicardia e fibrilação ventricular (4,3%). (14)  Atualmente, a reoclusão do vaso-alvo é rara (cerca de 1% dos casos), reduzindo em muito a necessidade de cirurgia de revascularização de urgência (15). A maior limitação da angioplastia primária é a sua disponibilidade e o atraso na transferência do paciente para um centro médico capacitado.  
6  
Quando disponível em tempo hábil, a angioplastia primária é superior à trombólise química no tratamento do IAMCSST, reduzindo as taxas de mortalidade em curto prazo (7% x 9%; p<0,001), reinfarto não-fatal (3% x 7%; p<0,001), AVC (1% x 2%; p<0,001), AVC hemorrágico (0,05% x 1%; p<0,001) e o desfecho combinado de morte, reinfarto não-fatal e AVC (8% x 14%; p<0,001), independentemente do agente trombolítico utilizado e se o paciente foi transferido ou não para realizar a angioplastia primária. (16) Para cada 50 pacientes tratados com angioplastia primária ao invés de trombólise, uma vida foi salva e duas complicações maiores (incluindo AVC e reinfarto) foram prevenidas. Uma importante revisão sistemática realizada no Reino Unido (17) também mostrou que o uso de angioplastia primária promove a redução absoluta de 3% na mortalidade intra-hospitalar e em 30 dias e de 3% na mortalidade dos 6 meses aos 24 meses após o evento, além de redução absoluta na taxa de AVC, reinfarto, cirurgia de revascularização miocárdica e no tempo de internação em dois dias.  
Os benefícios da reperfusão e, em especial, da angioplastia primária sobre a trombólise química, dependem do tempo até o início do tratamento. Segundo as diretrizes atuais, (1;18;19) o tempo de espera para o início da terapia trombolítica desde o primeiro contato com o paciente (tempo porta-agulha) deve ser inferior a 30 minutos, e, para que o benefício da angioplastia primária esteja presente, a espera até a insuflação do balão (tempo porta-balão) deve ser inferior a 90 minutos, sendo que o atraso (tempo porta-balão menos tempo portaagulha) não seja superior a 60 minutos. Asseburg _et al_ . (20) publicou uma atualização da revisão sistemática de Keeley et al. e incluiu, não só desfechos a curto prazo, mas também os desfechos após 6 meses, mostrando que a redução da mortalidade na angioplastia primária só foi significativa quando o tempo de atraso foi menor que 45 minutos, e a redução dos desfechos não-fatais, quando este tempo foi menor que 90 minutos.  
A interferência do tempo de atraso do sistema (o tempo entre o contato do paciente com o serviço de emergência e a angioplastia primária) e a mortalidade a longo prazo foi objeto de estudo de Aerkelsen et al. (21) que publicaram os dados obtidos através de um registro do sistema público do oeste da Dinamarca, entre 2002 e 2008, que incluiu 6209 pacientes com quadro de IAMCSST submetidos a angioplastia primária com menos de doze horas do início dos sintomas, com tempo médio de seguimento de 3,4 anos. Para tal, os autores dividiram o atraso do sistema nos seus diferentes componentes, conforme as figuras 3 e 4. Os autores observaram uma redução absoluta da mortalidade de 15,4% (30,8% para 15,4%; p <0,001)  
7  
quando o tempo de atraso do sistema foi menor que 60 minutos, em comparação com um tempo de atraso entre 181 e 360 minutos. Através de uma análise multivariada, concluíram que o tempo de atraso do sistema representa um preditor independente de mortalidade a longo prazo, bem como seus componentes (tempo de atraso pré-hospitalar e tempo porta-balão). É importante enfatizar que, mais importante do que o tempo porta-balão, é a avaliação deste tempo de atraso do sistema quando avaliamos uma rede de cuidado do IAM, já que o primeiro se presta apenas como indicador da qualidade de um serviço de hemodinâmica.  
Figura 3. Tempos de atraso para trombólise  
<!-- Start of picture text -->
Início dos  Ligação do paciente para o  Chegada ao hospital  Início do<br>sintomas SAMU primário trombolítico<br>Atraso do paciente  Tempo do transporte  Tempo porta-agulha<br>Atraso do sistema<br>Atraso no tratamento (tempo de isquemia)<br>=<br>Figura 4. Tempos de atraso para angioplastia primária<br>Ligação  Chegada ao  Saída do<br>Início dos  Chegada ao hospital  ICP<br>para o  hospital  hospital<br>sintomas com hemodinâmica primária<br>SAMU primário primário<br>Atraso do  Tempo de<br>Atraso do  Tempo do  Tempo porta-<br>hospital  transferência inter-<br>paciente  transporte  balão<br>primário  hospitalar<br>Atraso pré-hospitalar<br>Atraso do sistema<br>Atraso no tratamento (tempo de isquemia)<br>=<br><!-- End of picture text -->  
Figura 4. Tempos de atraso para angioplastia primária  
8  
Bravo Vergel et al. mostraram um maior custo-efetividade da angioplastia em relação à trombólise até um tempo de atraso entre 60 e 90 minutos no Reino Unido, levando-se em consideração todos os gastos com o paciente até 6 meses após o evento agudo (22). Para este caso, a razão de custo–efetividade incremental da angioplastia primária foi de 9.241 libras esterlinas por cada QALY adicional, com uma probabilidade de 90% da estratégia ser custo efetiva ao limiar de 20 mil libras esterlinas. Em outra revisão extensa, Hartwell e colaboradores (17) concluíram que a angioplastia primária é mais custo efetiva do que a trombólise, fornecendo benefícios adicionais no estado de saúde a algum custo extra. No longo prazo, porém, espera-se que esta diferença diminua devido à maior freqüência de recorrências e reintervenções necessárias naqueles que receberam trombólise.  
Sumariando:  
- O infarto agudo do miocárdio é uma das principais causas de morte no país; 25 a 35%  
- dos infartados morrem antes de receber cuidados médicos.  
- A terapia de reperfusão está estabelecida no tratamento do infarto agudo do miocárdio  
- com supradesnivelamento do segmento ST e pode ser feita por angioplastia primária ou trombólise. Em ambas, é necessário o reconhecimento precoce do infarto e o pronto início do tratamento, até 12 horas de início dos sintomas.  
- Comparações formais e extensivas entre as duas estratégias mostram benefício e  
- custo-efetividade da angioplastia primária sobre a trombólise, especialmente em pacientes de alto risco. O benefício, porém, depende da disponibilidade de hemodinâmica 24h e da rápida realização do procedimento e desaparece se o atraso para a realização da angioplastia for maior que 60 a 90 minutos.  
- Assim, a escolha da melhor estratégia de reperfusão no IAM depende de fatores  
- relacionados à disponibilidade regional de recursos e pode variar de região para região.  
9

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
Como o diagnóstico do infarto se baseia primariamente no eletrocardiograma de 12 derivações, a oportunidade de se reduzir o tempo entre o diagnóstico e a intervenção depende da aquisição rápida e interpretação adequada do ECG. Com o diagnóstico pré-hospitalar de IAM com supra, é possível tanto realizar a trombólise na unidade móvel (no Brasil, SAMU – Serviço de Assistência Móvel a Urgência), quanto referenciar o paciente a um serviço médico capaz de estabelecer tratamento de reperfusão imediata, seja ele, a angioplastia primária (preferencialmente) ou a infusão de trombolíticos (23). Mesmo que a Unidade pré-hospitalar encaminhe o paciente a um hospital com possibilidade de tratar o infarto em curso, o tempo até a realização do ECG seria eliminado com a realização pré-hospitalar do exame, estando a equipe já de prontidão para o seu atendimento.  
Para que a estratégia de reperfusão seja eficaz, é necessária a plena integração entre o diagnóstico pré-hospitalar e a conduta hospitalar, dentro do que se conhece hoje como sistemas de cuidado do infarto agudo do miocárdio (24). Existem hoje vários relatos de experiências de cidades européias e regiões americanas nas quais os sistemas de saúde, público ou privado, estabeleceram tais “sistemas de cuidado” ( _systems of care_ ) de pacientes com infarto, incluindo diagnóstico precoce, transporte rápido e rede de hospitais que fazem angioplastia primária (25-29).  
O diagnóstico eletrocardiográfico pré-hospitalar de IAM pode ser obtido de diferentes maneiras: (1) softwares de interpretação ECG automatizados, (2) interpretação do ECG por médicos ou profissionais de saúde presentes na ambulância ou (3) transmissão dos traçados para central de análise à distância, com interpretação e discussão do caso com referência médica especializada (23). A escolha de cada um desses métodos tem tanto vantagens potenciais como dificuldades operacionais, que devem ser cuidadosamente avaliadas antes da implantação (23;30;31). O objetivo final é sempre o reconhecimento precoce do infarto agudo do miocárdio, objetivando que a introdução do tratamento seja o mais rápido possível, seja pela trombólise pré-hospitalar, seja pela angioplatia primária ou trombólise hospitalar.  
10

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
Com a constatação de que o IAM podia ser abordado de forma eficaz, desde que o paciente seja atendido e tratado rapidamente, as atenções se voltaram para o fato de que frequentemente os pacientes elegíveis não recebiam o tratamento indicado um tempo ótimo(32). Para que o paciente com IAM recebesse o tratamento de reperfusão no tempo e local adequado, o sistema de saúde precisaria se organizar, para permitir o reconhecimento precoce do IAM com supra de ST, seu rápido encaminhamento para uma unidade de saúde habilitada ao tratamento e o uso efetivo da terapia de reperfusão nesta unidade de saúde. Estes sistemas de cuidado incluem métodos de telemedicina para diagnóstico eletrocardiográfico precoce (29) e protocolos rígidos de transferência e transporte, existindo diretrizes específicas para sua implantação. (24). O número de vidas perdidas por infarto e a morbidade dos pacientes infartados não reperfundidos, potencialmente evitáveis, foram motivações mais que suficientes para que o problema fosse enfrentado de uma forma sistêmica e não apenas focal.  
Tais tentativas de organização interinstitucional do tratamento do IAM ocorreram inicialmente na Europa e nos Estados Unidos, (25-29), mas rapidamente se espalharam pelo mundo, existindo hoje diretrizes internacionais sobre o assunto (33). Para a implantação da Linha do Cuidado do IAM, é necessário a integração de todas as Unidades de Saúde da Rede de Atenção às Urgências envolvidas com o atendimento deste perfil de paciente.  
Considerando que o atendimento aos usuários com quadros agudos deve ser prestado por todas as portas de entrada dos serviços de saúde do SUS, possibilitando a resolução integral da demanda ou transferindo-a, responsavelmente, para um serviço de maior complexidade, dentro de um sistema hierarquizado e regulado, define-se como constituintes da Linha do Cuidado do IAM os seguintes componentes:  
- Unidades de Atenção Primária à Saúde;  
- Unidades de Atenção Especializada;  
- Serviço móvel pré-hospitalar (SAMU);  
- Unidades de Pronto Atendimento (UPA) e pronto-socorros de hospitais gerais;  
- Hospitais com credenciamento especializado para Atenção Cardiovascular de Alta Complexidade, com habilitação em cardiologia intervencionista e leitos de Unidade Coronariana dedicada à rede de IAM;  
11  
- Atenção Domiciliar;  
- Serviços de Reabilitação;  
- Centrais de regulação municipais e estaduais.  
O objetivo da Rede de Atenção ao IAM é garantir que o paciente com IAM com supra de ST receba a terapia de reperfusão em tempo adequado, com acesso à terapia intensiva e ao tratamento e estratificação complementares à reperfusão. Considera-se que o tempo total de isquemia (entre o início dos sintomas e o início da terapia de reperfusão) deve ser idealmente até 120 minutos.  
É essencial que os protocolos de atenção do IAM sejam definidos e pactuados pelos diferentes componentes da Linha do Cuidado, de forma a uniformizar o cuidado e permitir o acesso de todos os pacientes às terapias estabelecidas, conforme as diretrizes internacionais.  
12

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **LINHA DO CUIDADO DO INFARTO AGUDO DO MIOCÁRDIO NA REDE DE ATENÇÃO ÀS URGÊNCIAS** -->
#### **4.1 Objetivo geral**  
|Objetivo geral|Metas|Indicadores gerais|
|---|---|---|
|Implantar redes de atendimento ao IAM|Reduzir a mortalidade prematura|- Número de mortes por IAM|
|com supra de ST em regiões|e ascomplicações do infarto|- Proporção de pacientes elegíveis aos quais se administrou|
|metropolitanas brasileiras|agudo do miocárdio|terapias de reperfusão|  
#### **4.2 Objetivos específicos**  
|Objetivos específicos|Metas|Indicadores para acompanhamentolocal|
|---|---|---|
|1 Divulgar o conhecimento referente<br>ao infarto e seu tratamento|Fazer com que o paciente procure<br>atendimento mais rapidamente frente a<br>sintomas típicos deIAM|- Tempo entre o início da dor e a chamada do SAMU|
|2 Definir de protocolo padronizado<br>para avaliação e tratamento do IAM|Dispor de protocolo para avaliação e<br>tratamento do IAM passível de ser<br>usado nos diferentes pontos de cuidado,<br>respeitando diferençasregionais|- Protocolo validado pelas sociedades científicas e<br>gestores locais|
|3<br>Prover o transporte do paciente no<br>menor espaço de tempo em viaturas<br>equipadas com pessoal,<br>equipamentos e medicamentos<br>necessários ao atendimento|Reduzir o tempo de transporte de<br>pacientes com IAM|- Tempo entre a chamada do SAMU e a chegada da<br>ambulância<br>- Tempo de transporte entre UPAs/hospitais primários e<br>Unidade coronariana|  
13  
|Objetivos específicos|Metas|Indicadores|
|---|---|---|
|4 Implantar ou incrementar as<br>Centrais de regulação de urgência e<br>emergência, com algoritmos<br>específicos para a abordagem do<br>IAM e protocolos estabelecidos de<br>destinação dos pacientes|Dispor de Central de Regulação capaz de seguir<br>protocolos padronizados e encaminhar os<br>pacientes com IAM aos pontos de atenção<br>habilitados ao seu tratamento|- Presença de Central de regulação do SAMU<br>- Tempo entre a chamada do SAMU e a<br>chegada da ambulância<br>- Tempo de transporte entre UPAs/hospitais<br>primários e  Unidade coronariana|
|5 Estabelecer rede de referências entre<br>os pontos de atenção, com base<br>espacial e administrativa, com<br>sistema facilitado de comunicação<br>entre os pontos|Definir fluxos com métodos facilitados de contato<br>entre os pontos de atenção, sob a coordenação da<br>Central de regulação|- Presença de fluxo definido, discutido pela<br>rede e disponível em todos os pontos de<br>atenção|
|6 Incentivar o uso de telemedicina<br>para diagnóstico precoce e preciso<br>do IAM com supra de ST|Dispor de sistema de telemedicina nas<br>ambulâncias do SAMU e nas UPAS/PS dos<br>hospitais gerais, com transmissão para Central de<br>Regulação e Hospitais de Referência<br>Aumentar a acurácia preditiva do diagnóstico<br>ECG pré-hospitalar|- Proporção de unidades do SAMU e UPAS/<br>PS hospitais gerais com telemedicina<br>- Proporção de pacientes para os quais foram<br>obtidos ou transmitidos ECG adequados|
|7 Capacitar as equipes das UPAs e<br>dos PS hospitais gerais para o<br>tratamento do IAM|Dispor de equipes treinadas para a abordagem do<br>IAM|- Número de equipes capacitadas sob o<br>número total de equipes<br>- Tempo entre a porta e o primeiro ECG<br>- Proporção de pacientes elegíveis aos quais<br>se administrou terapias dereperfusão|
|8 Induzir o uso da trombólise nas<br>UPAS e nos PS hospitais gerais|Aumentar o número de pacientes submetidos à<br>terapia de reperfusão|- Proporção de pacientes elegíveis aos quais<br>se administrou terapias de reperfusão<br>- Tempo porta-agulha (para pacientes não<br>transferidos)|  
14  
||Objetivos específicos|Metas|Indicadores|
|---|---|---|---|
|9|Aumentar o número de leitos de<br>Unidades Coronarianas em<br>hospitais especializados para<br>Atenção Cardiovascular de Alta<br>Complexidade dedicados à Rede<br>de IAM|Dispor de leitos de unidade coronariana em<br>hospitais capazes de realizar angioplastia<br>primária (conforme protocolo, na contra-<br>indicação à trombólise ou em casos de alto<br>risco) e de salvamento|- Número de leitos de UCo dedicados a rede|
|10|Otimizar o tratamento rápido do<br>IAM com supra em hospitais<br>especializados para Atenção<br>Cardiovascular de Alta<br>Complexidade|Obter o melhor cuidado para os pacientes<br>encaminhados para os hospitais<br>especializados para Atenção Cardiovascular<br>de Alta Complexidade|- Mortalidade intra-hospitalar por IAM<br>- Proporção de pacientes elegíveis aos quais se<br>administrou terapias classe I baseado nas diretrizes<br>-Tempo porta-balão<br>-Tempo primeiro hospital-balão (para pacientes<br>transferidos)<br>- Tempo total de isquemia, estratificado por nível de<br>transferência|
|11|Garantir leitos de retaguarda para<br>a UCo, de forma a permitir o<br>fluxo adequado de pacientes|Manter sistema com alta rotatividade e baixo<br>tempo de permanência, garantindo o<br>atendimento de grande número de pacientes|- Número de leitos de retaguarda<br>- Tempo médio de permanência hospitalar<br>- Taxa de ocupação|
|12|Garantir a continuidade do<br>cuidado e a utilização dos<br>recursos terapêuticos adequados<br>para o período pós-IAM|Obter o melhor cuidado no período pós-IAM,<br>com estratificação do risco, encaminhamento<br>para procedimentos de revascularização<br>quando pertinente e retorno do paciente com<br>plano terapêutico estabelecido|- Realização de consultas no hospital especializado<br>- Número de pacientes com encaminhamento<br>qualificado à atenção básica, com plano terapêutico|
|13|Promover a prevenção secundária<br>doIAM|Evitar novos episódios de IAM e síndrome<br>coronariana aguda|- Mortalidade 1 ano após o IAM|
|14|Monitorar os resultados do<br>programa|Garantir a qualidade e efetividade do<br>programa|- Presença do comitê de monitoramento<br>- Resultados da pesquisa de satisfação do usuário|  
15  
Referências bibliográficas  
- (1)  III Diretriz da Sociedade Brasileira de Cardiologia sobre tratamento do infarto agudo do miocárdio. Arq Bras Cardiol 2004; 83 Suppl 4:1-86.  
- (2)  Junqueira-Lodi L, Ribeiro AL, Mafra AA. Protocolo Clínico sobre Síndrome Coronariana Aguda. Secretaria de Estado da Saúde de Minas Gerais, editor.  1-49. 2011. Belo Horizonte.  
- (3)  Araujo DV, Tura BR, Brasileiro AL, Luz NH, Pavao AL, Teich V. Cost-effectiveness of prehospital versus inhospital thrombolysis in acute myocardial infarction. Arq Bras Cardiol 2008; 90(2):91-98.  
- (4)  World Health Organization. Global Burden of Disease. <u>http://www</u> who int/healthinfo/global_burden_disease/en/ [ 2010  Available from: URL:http://www.who.int/healthinfo/global_burden_disease/en/  
- (5)  Antman EM, Anbe DT, Armstrong PW, Bates ER, Green LA, Hand M et al. ACC/AHA guidelines for the management of patients with ST-elevation myocardial infarction: a report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines (Committee to Revise the 1999 Guidelines for the Management of Patients with Acute Myocardial Infarction). Circulation 2004; 110(9):e82-292.  
- (6)  Katritsis D, Karvouni E, Webb-Peploe MM. Reperfusion in acute myocardial infarction: current concepts. Prog Cardiovasc Dis 2003; 45(6):481-492.  
- (7)  Hartzler GO, Rutherford BD, McConahay DR, Johnson WL, Jr., McCallister BD, Gura GM, Jr. et al. Percutaneous transluminal coronary angioplasty with and without thrombolytic therapy for treatment of acute myocardial infarction. Am Heart J 1983; 106(5 Pt 1):965-973.  
- (8)  Effectiveness of intravenous thrombolytic treatment in acute myocardial infarction. Gruppo Italiano per lo Studio della Streptochinasi nell'Infarto Miocardico (GISSI). Lancet 1986; 1(8478):397-402.  
- (9)  Randomised trial of intravenous streptokinase, oral aspirin, both, or neither among 17,187 cases of suspected acute myocardial infarction: ISIS-2. ISIS-2 (Second International Study of Infarct Survival) Collaborative Group. Lancet 1988; 2(8607):349-360.  
- (10)  Ting HH, Yang EH, Rihal CS. Narrative review: reperfusion strategies for STsegment elevation myocardial infarction. Ann Intern Med 2006; 145(8):610-617.  
- (11)  Ribichini F, Ferrero V, Wijns W. Reperfusion treatment of ST-elevation acute myocardial infarction. Prog Cardiovasc Dis 2004; 47(2):131-157.  
- (12)  Yatskar L, Selzer F, Feit F, Cohen HA, Jacobs AK, Williams DO et al. Access site hematoma requiring blood transfusion predicts mortality in patients undergoing percutaneous coronary intervention: data from the National Heart, Lung, and Blood Institute Dynamic Registry. Catheter Cardiovasc Interv 2007; 69(7):961-966.  
16  
- (13)  Bartholomew BA, Harjai KJ, Dukkipati S, Boura JA, Yerkey MW, Glazier S et al. Impact of nephropathy after percutaneous coronary intervention and a method for risk stratification. Am J Cardiol 2004; 93(12):1515-1519.  
- (14)  Mehta RH, Harjai KJ, Grines L, Stone GW, Boura J, Cox D et al. Sustained ventricular tachycardia or fibrillation in the cardiac catheterization laboratory among patients receiving primary percutaneous coronary intervention: incidence, predictors, and outcomes. J Am Coll Cardiol 2004; 43(10):1765-1772.  
- (15)  Yang EH, Gumina RJ, Lennon RJ, Holmes DR, Jr., Rihal CS, Singh M. Emergency coronary artery bypass surgery for percutaneous coronary interventions: changes in the incidence, clinical characteristics, and indications from 1979 to 2003. J Am Coll Cardiol 2005; 46(11):2004-2009.  
- (16)  Keeley EC, Boura JA, Grines CL. Primary angioplasty versus intravenous thrombolytic therapy for acute myocardial infarction: a quantitative review of 23 randomised trials. Lancet 2003; 361(9351):13-20.  
- (17)  Hartwell D, Colquitt J, Loveman E, Clegg AJ, Brodin H, Waugh N et al. Clinical effectiveness and cost-effectiveness of immediate angioplasty for acute myocardial infarction: systematic review and economic evaluation. Health Technol Assess 2005; 9(17):1-iv.  
- (18)  Anderson JL, Adams CD, Antman EM, Bridges CR, Califf RM, Casey DE, Jr. et al. ACC/AHA 2007 guidelines for the management of patients with unstable angina/non ST-elevation myocardial infarction: a report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines (Writing Committee to Revise the 2002 Guidelines for the Management of Patients With Unstable Angina/Non ST-Elevation Myocardial Infarction): developed in collaboration with the American College of Emergency Physicians, the Society for Cardiovascular Angiography and Interventions, and the Society of Thoracic Surgeons: endorsed by the American Association of Cardiovascular and Pulmonary Rehabilitation and the Society for Academic Emergency Medicine. Circulation 2007; 116(7):e148-e304.  
- (19)  Antman EM, Anbe DT, Armstrong PW, Bates ER, Green LA, Hand M et al. ACC/AHA guidelines for the management of patients with ST-elevation myocardial infarction--executive summary. A report of the American College of Cardiology/American Heart Association Task Force on Practice Guidelines (Writing Committee to revise the 1999 guidelines for the management of patients with acute myocardial infarction). J Am Coll Cardiol 2004; 44(3):671-719.  
- (20)  Asseburg C, Vergel YB, Palmer S, Fenwick E, de Belder M, Abrams KR et al. Assessing the effectiveness of primary angioplasty compared with thrombolysis and its relationship to time delay: a Bayesian evidence synthesis. Heart 2007; 93(10):12441250.  
- (21)  Terkelsen CJ, Sorensen JT, Maeng M, Jensen LO, Tilsted HH, Trautner S et al. System delay and mortality among patients with STEMI treated with primary percutaneous coronary intervention. JAMA 2010; 304(7):763-771.  
17  
- (22)  Bravo VY, Palmer S, Asseburg C, Fenwick E, de Belder M, Abrams K et al. Is primary angioplasty cost effective in the UK? Results of a comprehensive decision analysis. Heart 2007; 93(10):1238-1243.  
- (23)  Ting HH, Krumholz HM, Bradley EH, Cone DC, Curtis JP, Drew BJ et al. Implementation and Integration of Prehospital ECGs Into Systems of Care for Acute Coronary Syndrome. A Scientific Statement From the American Heart Association Interdisciplinary Council on Quality of Care and Outcomes Research, Emergency Cardiovascular Care Committee, Council on Cardiovascular Nursing, and Council on Clinical Cardiology. Circulation 2008; 118(10):1066-1079.  
- (24)  Jacobs AK, Antman EM, Faxon DP, Gregory T, Solis P. Development of systems of care for ST-elevation myocardial infarction patients: executive summary. Circulation 2007; 116(2):217-230.  
- (25)  Jacobs AK. Regionalized care for patients with ST-elevation myocardial infarction: it's closer than you think. Circulation 2006; 113(9):1159-1161.  
- (26)  Jacobs AK, Antman EM, Ellrodt G, Faxon DP, Gregory T, Mensah GA et al. Recommendation to develop strategies to increase the number of ST-segmentelevation myocardial infarction patients with timely access to primary percutaneous coronary intervention. Circulation 2006; 113(17):2152-2163.  
- (27)  Hailer B, Naber CK, Koslowski B, Budde T, Jacksch R, Sabin G et al. [STEMI Network Essen - Results after 1 Year.]. Herz 2008; 33(2):153-157.  
- (28)  Marzegalli M, Oltrona L, Corrada E, Fontana G, Klugmann S. [The network for the management of acute coronary syndromes in Milan: results of a four-year experience and perspectives of the prehospital and interhospital cardiological network]. Ital Heart J 2005; 6 Suppl 6:49S-56S.  
- (29)  Catania F, Colombo C, Marzegalli M, Borghi G, Pincirolis F. Service level web monitoring in the field management of emergencies. Stud Health Technol Inform 2004; 106:123-135.  
- (30)  Drew BJ, Dempsey ED, Joo TH, Sommargren CE, Glancy JP, Benedict K et al. Prehospital synthesized 12-lead ECG ischemia monitoring with trans-telephonic transmission in acute coronary syndromes: pilot study results of the ST SMART trial. J Electrocardiol 2004; 37 Suppl:214-221.  
- (31)  Rokos IC, Larson DM, Henry TD, Koenig WJ, Eckstein M, French WJ et al. Rationale for establishing regional ST-elevation myocardial infarction receiving center (SRC) networks. Am Heart J 2006; 152(4):661-667.  
- (32)  Boersma E, Mercado N, Poldermans D, Gardien M, Vos J, Simoons ML. Acute myocardial infarction. Lancet 2003; 361(9360):847-858.  
- (33)  Jacobs AK, Antman EM, Faxon DP, Gregory T, Solis P. Development of Systems of Care for ST-Elevation Myocardial Infarction Patients: Executive Summary. Circulation 2007; 116(2):217-230.  
18

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
19  
- Elaborado a partir das diretrizes da Sociedade Brasileira de Cardiologia e das  
- sociedades internacionais e baseado no Protocolo Clínico “Síndrome Coronariana Aguda” da Secretaria de Estado de Saúde de Minas Gerais, cuja elaboração foi  
- coordenada pelo Hospital das Clínicas da Universidade Federal de Minas Gerais  
|**_SIGLAS_**|
|---|  
|**_AAS_**|Ácido acetilsalicílico|
|---|---|
|**_AI_**|Angina instável|
|**_ATC_**|Angioplastia transluminal coronária|
|**_BBloq_**|Betabloqueadores|
|**_BCRE_**|Bloqueio completo do ramo esquerdo|
|**_BIA_**|Balão intra‐aórtico|
|**_BRA_**|Bloqueadores dos receptores de angiotensina II|
|**_CRVM_**|Cirurgia de revascularização miocárdica|
|**_CIV_**|Comunicação Interventricular|
|**_DAC_**|Doença arterial coronariana|
|**_DM_**|Diabete melito|
|**_EAP_**|Edema agudo de pulmão|
|**_ECG_**|Eletrocardiograma de superfície|
|**_EV_**|Endovenosa|
|**_FA_**|Fibrilação atrial|
|**_FEVE_**|Fração de ejeção do ventrículo esquerdo|
|**_HAS_**|Hipertensão arterial sistêmica|
|**_IAM_**|Infarto agudo do miocárdio|
|**_IAMCSST_**|Infarto agudo do miocárdio com supradesnivelamento do segmento ST|
|**_IAMSSST_**|Infarto agudo do miocárdio sem supradesnivelamento do segmento ST|
|**_IC_**|Insuficiência cardíaca|
|**_ICP_**|Intervenção coronária percutânea|
|**_IECA_**|Inibidores da enzima conversora da angiotensina|
|**_IM_**|Insuficiência mitral|
|**_ISRAA_**|Inibidores do sistema renina‐angiotensina‐aldosterona|
|**_INC_**|Instituto Nacional de Cardiologia|  
20  
|**_IVE_**|Insuficiência ventricular esquerda|
|---|---|
|**_MNM_**|Marcadores de necrose miocárdica|
|**_PAS_**|Pressão arterial sistólica|
|**_POP_**|Procedimento Operacional Padrão|
|**_RC_**|Reabilitação Cardíaca|
|**_SCA_**|Síndrome coronariana aguda|
|**_SCACSST_**|Síndrome coronariana aguda com supra do segmento ST|
|**_SCASSST_**|Síndrome coronariana aguda sem supra do segmento ST|
|**_SNC_**|Sistema nervoso central|
|**_SK_**|Estreptoquinase|
|**_SUS_**|Sistema Único de Saúde|
|**_TE_**|Teste ergométrico|
|**_TEP_**|Tromboembolismo pulmonar|
|**_TnI_**|Troponina I|
|**_TNK_**|Tenecteplase|
|**_TnT_**|Troponina T|
|**_tPA_**|Alteplase|
|**_TRH_**|Terapia de reposição hormonal|
|**_TVS_**|Taquicardia ventricular sustentada|
|**_UCo_**|Unidade coronariana|
|**_UTI_**|Unidade de terapia intensiva|  
##### _CONFLITOS DE INTERESSE_  
Os integrantes declaram não haver qualquer conflito de interesse na elaboração deste <u>protocolo.</u>  
21

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
A doença arterial coronariana (DAC) representa a principal causa de óbito no mundo, estando entre as patologias de maior impacto clínico e financeiro.<sup>1</sup> A maioria dos casos de infarto agudo do miocárdio (IAM) é causada pela oclusão de um ramo coronariano principal. A obstrução e consequente redução do fluxo coronariano se devem comumente à ruptura física de uma placa aterosclerótica com subsequente formação de trombo oclusivo. Vasoconstrição coronária e micro embolização podem também estar envolvidos neste processo.  
A representação clínica da DAC pode ser identificada em suas formas crônica, como a angina estável, e aguda, nas síndromes coronarianas agudas (SCA), com supra ST e sem supra ST.  
No Brasil, estima‐se a ocorrência de 300 mil a 400 mil casos anuais de infarto, e que a cada 5 a 7 casos, ocorra um óbito. Assim, apesar dos inúmeros avanços terapêuticos obtidos nas últimas décadas, a SCA é ainda uma das mais importantes causas de morbimortalidade em nosso meio.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- Redução da morbidade e mortalidade dos pacientes com SCA no território nacional.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- Reconhecer a dor torácica sugestiva de SCA que requer atenção imediata e realização de eletrocardiograma (ECG) em até 10 minutos.  
- Distinguir, dentre os pacientes com SCA, aqueles com quadro de síndrome coronariana aguda com supra ST (SCACSST), que precisam ser submetidos à reperfusão no menor tempo possível (prioritariamente até 12 horas após início do evento agudo)  
- Estratificar o risco dos pacientes com SCA para direcioná‐los para avaliação e tratamento adequados.  
- Identificar e tratar precocemente as complicações relacionadas à SCA.  
- Orientar a prevenção de novos eventos coronarianos, garantindo o cuidado continuado e a reabilitação do paciente.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- Ambulância UTI do Serviço Atendimento Móvel de Urgência (SAMU);  
- Materiais para ressuscitação cardiorrespiratória: tubo endotraqueal, medicamentos, laringoscópio, máscara, valva;  
- Equipamento de ECG com 12 derivações;  
- Recursos de telemedicina que permitam a identificação e o diagnóstico eletrocardiográfico à distância, incluindo desde o envio do traçado por fax a outras formas mais complexas de transmissão de dados para a Unidade de Referência;  
- Medicamentos e insumos para atendimento de urgência – analgesia, sedativo, oxigênio e outros;  
- Medicamentos para a reperfusão miocárdica (trombolíticos);  
22  
- Exames laboratoriais, como marcadores de necrose miocárdica, de preferência a troponina;  
- Monitor cardíaco com oximetria de pulso;  
- Unidade de terapia intensiva (UTI) de referência;  
- Serviço de hemodinâmica de referência;  
- Unidade básica de saúde de referência – acompanhamento pós‐evento.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- Médicos, enfermeiros, técnicos de enfermagem, farmacêuticos, fisioterapeutas, assistentes sociais, nutricionistas, psicólogos e outros.  
- Gestores de saúde de unidades nos níveis primário, secundário e terciário de atenção.  
- Profissionais das unidades móveis de urgência e emergência.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
O termo SCA é empregado nas situações em que o paciente apresenta evidências clínicas e/ou laboratoriais de isquemia miocárdica aguda, produzida por desequilíbrio entre oferta e demanda de oxigênio para o miocárdio, tendo como causa principal a instabilização de uma placa aterosclerótica.  
A SCA se apresenta sob duas formas clínicas: com supradesnivelamento do segmento ST (SCACSSST), ou infarto agudo do miocárdio com supra de ST (IAMCSST), e aquela sem supradesnivelamento do segmento ST (SCASSST). **_<u>Esta diferenciação é fundamental  para o tratamento imediato da SCACSST através da reperfusão miocárdica, seja com trombolíticos ou com angioplastia primária.</u>_**  
A SCASSST se subdivide em angina instável (AI) e infarto agudo do miocárdio sem supradesnivelamento do segmento ST (IAMSSST). Ambos tem apresentações clínicas e eletrocardiográficas semelhantes, sendo distinguidas pela elevação (IAMSSST) ou não (AI) dos marcadores de necrose miocárdica, como troponina e creatinofosfoquinase – fração MB (CK‐MB), após algumas horas do início dos sintomas.  
Estudos recentes de âmbito mundial mostram que a SCACSST ocorre em 1/3 dos casos, enquanto a maioria dos pacientes com SCASSST apresenta‐se com AI.  
<!-- Start of picture text -->
Síndrome Coronariana Aguda<br>(SCA)<br>SCA  sem  supra ST SCA  com  supra ST<br>(SCASSST) (SCACSST)<br>Angina instável IAM  sem  supra ST IAM  com  supra ST<br>(AI) (IAMSSST) (IAMCSST)<br><!-- End of picture text -->  
23

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
Fatores desencadeantes mais comuns das SCA  
Instabilização da placa Progressão de lesão Aumento da demanda de aterosclerótica aterosclerótica Oxigênio pelo miocárdio  
**1. Instabilização de placa aterosclerótica,** com ativação e agregação plaquetárias associada à formação do trombo. O risco de ruptura da placa depende da sua composição e vulnerabilidade (tipo de placa) e do grau de estenose (tamanho da placa). A maioria de todos os trombos relacionados ao infarto surge em placas que causam apenas leve a moderada estenose. Se o trombo é oclusivo, geralmente há necrose transmural na parede miocárdica suprida pela artéria afetada, com aparecimento de supradesnivelamento do segmento ST (IAMCSST). Nas SCASSST, o trombo produz estreitamento grave das artérias coronárias, sem levar a oclusão total.  
**2. Progressão da Lesão Aterosclerótica,** com obstrução coronariana progressiva, acompanhada de angina em caráter progressivo.  
**3. Aumento da demanda de oxigênio** , em casos de estenose coronariana prévia, por fibrilação atrial com rápida resposta ventricular, febre, tireotoxicose, estenose aórtica, entre outras causas. Esta angina é denominada secundária.  
**Causas menos comuns de SCA** : Embolia coronariana (endocardite infecciosa, trombos murais, valvas protéticas), processos inflamatórios (viroses, aortite sifilítica, arterite de Takayasu, poliarterite nodosa, lúpus eritematoso sistêmico, sequela de radioterapia), uso de cocaína (produzindo vasoespasmo coronariano e/ou lesão endotelial) e IAM com artérias coronarianas angiograficamente normais (Vasoespasmo / Doenças da microcirculação).

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
O número de internações devido à SCA e outras doenças isquêmicas do coração pelo SUS vem aumentando progressivamente nos últimos anos no país, conforme visualizado no gráfico abaixo. A maioria das mortes por IAM ocorre nas primeiras horas de manifestação da doença, sendo 40 a 65% dos casos na primeira hora e, aproximadamente 80% nas primeiras 24 horas. Assim, é essencial que os pacientes com SCA sejam prontamente atendidos e tratados.  
24  
<!-- Start of picture text -->
Internagées por IAM e outas doengas isquémicas no SUS, 2000-2009<br>250000<br>2015 0000 a _<br>100000<br>50000<br>°<br>2000 2001 2002 2003 2004 2005 2006 2007 2008 2009<br>—Brasil Fonte: www.datasus.gov.br<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
##### **1.** **<u>HISTÓRIA</u>**  
##### **1.1 CARACTERÍSTICAS DA DOR TORÁCICA E SINTOMAS ASSOCIADOS**  
A dor torácica é a apresentação clínica mais comum da isquemia miocárdica ocorrendo em aproximadamente 80% dos casos.  
A angina estável típica possui três características básicas:  
- É desconforto difuso, retroesternal, não afetado por posição, movimento ou palpação, podendo irradiar para ombros, braço esquerdo, braço direito, pescoço ou mandíbula;  
- É reproduzida pelo esforço ou estresse emocional;  
- É prontamente aliviada pelo repouso ou pelo uso de nitrato sublingual.  
A dor dos pacientes com SCA tem características semelhantes à da angina estável, mas os episódios são mais intensos e prolongados e, normalmente, ocorrem em repouso. Frequentemente, vem acompanhada de sudorese, náuseas, vômitos, ou dispnéia. Não rara é a apresentação atípica, com queixas como mal estar, indigestão, dor epigástrica, sudorese, inclusive sem dor torácica associada, principalmente em idosos e diabéticos.  
Entre os pacientes que apresentam angina pectoris, há três apresentações principais que sugerem o surgimento de uma SCA:  
- <mark>Angina de repouso com geralmente mais de 20 minutos de duração;</mark>  
- <mark>Angina de início recente que limita a atividade;</mark>  
- <mark>Angina em crescendo (maior frequência, maior duração ou ocorre com menor esforço que em eventos anginosos prévios).</mark>  
##### **1.2 DOENÇA ARTERIAL CORONARIANA (DAC) PRÉVIA**  
A DAC prévia é sugerida por internações prévias, exames provocativos de isquemia (p.ex., teste ergométrico), cateterismo coronariano com lesões ou uso de tratamento específico. A presença de DAC prévia identifica pacientes com maior chance de SCA e maior  
25  
taxa de complicações. Pacientes portadores de doença vascular periférica e a doença cérebro vascular comumente tem DAC concomitante.  
##### **1.3 EPIDEMIOLOGIA E FATORES DE RISCO PARA DAC**  
O risco de DAC aumenta progressivamente após cada década acima de 40 anos. O sexo masculino é fator de risco adicional. Em pacientes mais jovens ou com poucos fatores de risco, o uso de cocaína ou metanfetaminas deve ser investigado. Para o diagnóstico de SCA, a presença de fatores de risco para DAC são menos importantes que a história típica, as alterações de ECG e os marcadores de necrose miocárdica, porém a presença de 3 ou mais destes fatores é marcador de pior evolução. **<mark>Fatores de risco para DAC</mark>** <mark>Tabagismo Hipertensão arterial Dislipidemia História familiar de DAC precoce (homem <55anos e mulher < 65anos) Diabetes mellitus</mark> Pacientes com suspeita de SCA devem ser imediatamente avaliados por médicos ~~<u>=</u>~~ capacitados. 2 **<u>EXAME FÍSICO</u>** O exame físico geralmente é inespecífico. Alguns achados podem contribuir no diagnóstico diferencial de doenças, como estenose aórtica e dissecção de aorta (assimetria de pulsos ou sopro de insuficiência aórtica). Por outro lado, o exame físico pode auxiliar no reconhecimento dos quadros de maior gravidade. **SCA: sinais de gravidade** **_Hipotensão arterial Crepitações Taquicardia (PAS < 85mmhg) pulmonares (FC>100 bpm)_** <u>SS</u> **3** **<u>DIAGNÓSTICO DIFERENCIAL DE DOR TORÁCICA</u>**  
Apenas 15 a 25% dos pacientes admitidos em serviços de emergência com dor torácica apresentam SCA. Outras causas de dor torácica potencialmente grave devem ser identificadas precocemente, como:  
- Dissecção aguda de aorta;  
- Tromboembolismo pulmonar;  
- Pneumotórax hipertensivo.  
26  
**4** **<u>ELETROCARDIOGRAMA</u>**  
##### **4.1** **<u>IAMCSST:</u>**  
##### **Critérios eletrocardiográficos:**  
- **Presença de supradesnivelamento do segmento ST, maior que 1 mm em, no mínimo, duas derivações periféricas contínuas ou 2 mm em, no mínimo, duas derivações precordiais contínuas, ou**  
- A localização do IAM pode ser determinada conforme as derivações acometidas:  
- - **Presença de bloqueio completo do ramo esquerdo (BRCE) novo ou presumivelmente novo (representa aproximadamente 7% dos pacientes com IAMCSST).**  
- **Paredes acometidas segundo derivações analisadas:**  
- **<u>Anterior:</u>** duas ou mais derivações precordiais (V1‐V6)  
- **<u>Ântero‐septal:</u>** V1 a V3  
- **<u>Apical ou lateral:</u>** I e aVL, V4 a V6  
- **<u>Inferior:</u>** II, III e aVF; quando deverá ser realizado derivações direitas (V3R e V4R) para avaliação de infarto de ventrículo direito.  
- **<u>Posterior:</u>** V7 e V8; que devem ser realizadas na presença de infradesnivelamento ou ondas R proeminentes em V1 e V2.  
- **<u>Ventrículo direito (VD) :</u>** V3R / V4R . Derivações direitas devem ser realizadas em todos os infartos de parede inferior  
##### **4.2** **<u>SCASSST:</u>**  
- **O ECG define alterações características de maior gravidade:**  
- Infradesnivelamento ≥ 0,5 mm (0,05mV) em 2 ou mais derivações contínuas;  
- Inversão de onda T ≥ 2 mm em derivações sem onda Q.  
##### **DESTAQUES ECG**  
- O eletrocardiograma deve ser realizado em todo paciente com suspeita de SCA em até 10 minutos da admissão hospitalar.  
- Se disponível, o ECG deve ser realizado em ambiente pré‐hospitalar.  
- Se o ECG inicial não for diagnóstico, outro ECG deve ser realizado após 5 a 10 minutos.  
- Caso o paciente permaneça em observação, o ECG deve ser repetido a cada 3 horas nas primeiras 9 a 12h ou a qualquer momento, caso haja mudança na condição  
- clínica.  
- **5.** **<u>MARCADORES DE NECROSE MIOCÁRDICA (MNM)</u>**  
27  
Em pacientes com IAMCSST, o resultado da dosagem dos MNM não deve ser aguardado antes da reperfusão miocárdica, para que não haja atraso no início do tratamento.  
**5.1 TROPONINA** : É o marcador mais sensível e específico para a detecção de necrose miocárdica, constituindo‐se na primeira escolha para diagnóstico definitivo de necrose miocárdica. Eleva‐se após 6 a 12 horas do início dos sintomas. Não há diferença na acuidade entre os dois tipos disponíveis, troponina T e I, devendo a dosagem ser do tipo quantitativa _._ Para diagnóstico de IAM, uma medida acima do valor normal é suficiente (curva enzimática desnecessária). **_Quando dosada a troponina, a dosagem de outros marcadores enzimáticos torna‐se desnecessária. Deve ser dosada na admissão e após 9‐12 h do início dos sintomas_** . Às vezes é necessário avaliar variação da troponina para distinguir elevação basal daquela por necrose miocárdica aguda (ex. doença renal crônica).  
**5.2 CK‐MB:** Se a troponina estiver indisponível, a CK‐MB massa pode ser utilizada como alternativa _._ Se a CK‐MB massa ou a troponina não estiverem disponíveis, a CK‐MB atividade em associação com CK total pode ser utilizada.  A CK‐MB deve ser dosada na admissão e após 6 a 9 h do início dos sintomas. Se a suspeita de IAM for alta e os primeiros exames confirmaram o diagnóstico, colher nova amostra após 12h do início dos sintomas.  
**5.3 CK total:** Pode ser utilizada para determinar a relação entre os níveis de CK total e CK‐ MB, para diferenciar lesão muscular de lesão miocárdica. CK‐MB aumentada e acima de 5 a 20% do valor da CK total sugere IAM.  
Os MNM devem ser dosados à admissão nos pacientes com suspeita de SCA e repetidos com 9 a 12 horas do início dos sintomas nos casos de alta suspeita clínica  
As troponinas (T e I) são os marcadores bioquímicos de escolha para diagnóstico definitivo de necrose miocárdica.  A CK‐MB massa pode ser utilizada como alternativa à troponina.  
28  
##### **DIAGNÓSTICO DE SÍNDROME CORONARIANA AGUDA**  
|||Qualidade|Desconforto difuso, constritiva ou<br>empeso|
|---|---|---|---|
|||Localização|Retroesternal|
||Dor típica|Irradiação|Ombro, braço E, braço D, pescoço ou<br>mandíbula|
|||Não alteradapor|Posição,movimento, palpação|
|||Início|Geralmente em repouso|
|**Anamnese**||Sinais e sintomas<br>associados|Sudorese, náuseas, vômitos ou<br>dispnéia|
||Sintomas<br>atípicos|Mal estar, indigestão<br>principalmente em i<br>melito(DM).|, dor epigástrica e sudorese,<br>dosos e em portadores de diabete|
||Fatores de<br>risco|Tabagismo, HAS, disl<br>DACprecoce(home|ipidemia, DM e história familiar de<br>m < 55 e mulher < 65 anos).|
||IAMCSST|Supradesnivelament<br>consecutivas (>1mm<br>nasprecordiais) **ou**|o ST em 2 ou mais derivações<br>nas derivações periféricas ou >2mm|
|||BCRE novo oupresu|mivelmente novo|
|**ECG**||Incaracterístico||
||SCASSST|Infradesnivelamento<br>derivações consecut|≥ 0,5 mm em duas ou mais<br>ivas|
|||Inversão T ≥ 2 mm e|m derivações sem ondaQ|
|**MNM**|Ti|Na admissão|VN = acima do percentil 99 do_kit_|
|**(marcadores**|roponna|Após 9‐12h da dor|utilizado|
|**de necrose**||Na admissão||
|**miocárdica)**|**ou**CK‐MB|Após 6 – 9h da dor<br>Após 12h da dor|VN = acima do percentil 99 do_kit_<br>utilizado|  
29  
<!-- Start of picture text -->
Sintomas sugestivos de SCA Fluxograma: Diagnóstico de SCA<br>Avaliação médica imediata<br>Supra de ST<br>Diagnóstico provável:<br>Realizar ECG em até 10 min ou SIM<br>IAMCSSST<br>BRE novo<br>NÃO<br>- Infra de ST<br>- Observar por 9 a 12 h; - Inversão de onda T<br>- ECG seriado (3/3h e se  - Dor recorrente<br>mudança clínica); NÃO - Instabilidade hemodinâmica<br>- Monitorização ECG<br>- Alto risco (escores)<br>contínua, se possível.<br>- MNM positivos<br>SIM<br>- Dor recorrente<br>- ECG seriado com alterações  Diagnósticos prováveis:<br>dinâmicas SIM - IAM SSST<br>- MNM seguintes positivos - AI (alto risco)<br>NÃO<br>Diagnósticos prováveis:<br>- AI (baixo/intermediário risco)<br>- Dor torácica não isquêmica<br><!-- End of picture text -->  
30

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
Independente da estratégia de classificação de risco adotada pelo gestor ou pela instituição hospitalar deve‐se reconhecer que a dor torácica é um sintoma comum, sendo necessária a diferenciação daquela de origem coronariana das demais. Como o IAMCSST é uma das formas de SCA no qual a terapia de reperfusão deve ser instituída o mais rápido possível, **_a prioridade no paciente com suspeita de SCA é o seu encaminhamento imediato para um local onde possa ser reconhecido e tratado._** Esta avaliação implica, frente à suspeita de SCA, no acionamento imediato do cuidado pré‐hospitalar móvel (SAMU) nas localidades onde este estiver disponível, ou, na ausência deste, na procura direta à instituição, com atendimento prioritário e realização de ECG, seguido pela terapia de reperfusão, se necessário.  
Critérios clínicos sugestivos de SCA que exigem a avaliação imediata do paciente, com realização de ECG até 10 minutos após o atendimento inicial:  
- dor ou desconforto torácico significativo, de início recente, durando mais que 15 minutos;  
- localização em qualquer local do tórax, possivelmente incluindo pescoço, braços, dorso e abdome superior.  
Fatores que indicam possível maior gravidade e favorecem o atendimento rápido: ‐ sintomas associados com sudorese, náuseas, vômitos ou perda transitória da consciência;  
- idade acima de 30 anos, em ambos os sexos;  
- semelhança com episódio conhecido de angina ou ataque cardíaco prévio;  
- irradiação para o membro superior direito.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- Glicemia, Ureia, Creatinina  
- Sódio, Potássio, Magnésio  
- Hemograma completo  
- Tempo de Ativação da Protrombina (INR ou RNI) e PTT  
- Troponina (T ou I) **_ou_** CK‐MB Massa  
(CK‐MB e total ‐ apenas na ausência de marcadores mais específicos)  
- Colesterol Total e frações e Triglicerídeos  
(colher nas primeiras 24h de internação, com jejum de 10 a 12 horas)  
- RX de Tórax: Não deve atrasar a reperfusão, exceto quando houver suspeita de Dissecção Aórtica  
**A coleta de exames não deve atrasar o início da terapia específica**  
31  
##### **INDICAÇÃO DE INTERNAÇÃO**  
##### **Internação em UCo/UTI:**  
**1.**<sup>Pacientes com IAMCSST ou BRE novo/presumivelmente novo devem ser submetidos à</sup> terapia de reperfusão (trombólise ou ATC primária) e internados em UCo/CTI.  
**2.** Pacientes com IAMSSST devem ser internados em UCo/CTI.  
- Pacientes com AI e critérios de alto risco (Escore TIMI ≥ 5 ou infradesnivelamento do  
- **3.** segmento ST ≥ 0,5 mm em duas ou mais derivações contínuas) devem ser internados em UCo/CTI.  
##### **Internação em Unidade com Monitorização Contínua (Sala de Emergência / Unidade de Dor Torácica):**  
Pacientes com AI de risco intermediário (TIMI 3 ou 4 e ausência de infradesnivelamento do segmento ST ≥ 0,5 mm em duas ou mais derivações contíguas ou aumento dos MNM) devem permanecer em observação por 24‐48 h para  
- Monitorização eletrocardiográfica contínua;  
- ECGs seriados;  
- **1.**  
- MNM seriados, à admissão e 9‐12 horas após a dor _;_  
- Alta para enfermaria em 24 a 48h se não houver recorrência da dor, estiverem estáveis, com ECG e MNM sem alterações;  
- Realizar teste provocativo de isquemia preferencialmente internados ou em 72 horas após a alta.  
Pacientes com suspeita de SCA ou possível SCA de baixo risco (TIMI ≤ 2 e ausência de infradesnivelamento do segmento ST ≥ 0,5 mm em duas ou mais derivações contíguas ou aumento dos MNM) devem permanecer em observação por 12 a 24h para  
- Realização de ECG e  
- **2.**  
- Dosagem sérica de MNM com 6‐9 h e 9‐12h do início da dor _;_  
- Alta para casa após em 12 a 24h se não houver recorrência da dor, se o paciente estiver estável, com ECG e MNM sem alterações;  
- Realizar teste provocativo de isquemia ambulatorialmente.  
32

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
##### **1.** **<u>ATENDIMENTO PRÉ HOSPITALAR</u>**  
O interesse no atendimento pré‐hospitalar do infarto agudo do miocárdio (IAM) se deve ao grande número de óbitos que ocorrem antes que os pacientes cheguem ao hospital tendo como modalidade mais freqüente de parada cardiorrespiratória nas primeiras horas do IAM à fibrilação ventricular . A maior parte das mortes por IAM acontece fora do ambiente hospitalar, geralmente desassistidas pelos médicos, e entre aqueles que chegam ao hospital, apenas cerca de 20% destes pacientes chegam ao setor de emergência com até duas horas após o início dos sintomas.  
A abordagem do paciente com suspeita de síndrome coronária aguda em ambiente extra‐hospitalar deve, idealmente, ser feita por profissional de saúde, com realização de uma história clínica direcionada, investigando as características dos sintomas atuais. O eletrocardiograma executado no local de atendimento e interpretado por um médico habilitado (na ambulância ou em local remoto) mostrou ser um método que reduz em 34% o tempo porta‐agulha e em 18% o tempo porta‐balão além de uma tendência à redução da mortalidade intra‐hospitalar em pacientes com IAMCST.  
O impacto potencial, em termos de benefício, ao se intervir na fase pré‐hospitalar no IAM reforça a necessidade de programas que permitam:  
- **a)** Identificar o perfil dos casos de IAM que não chegam aos hospitais, qualificando o estado atual de atendimento e quantificando o impacto de uma nova estratégia, de grande difusão na população;  
- **b)** Estruturação de unidades de atendimento (móveis e fixas), equipadas, qualificadas e de ampla abrangência no atendimento à população;  
- **c)** Fornecer maior informação à população quanto aos sintomas de IAM e a importância de uma busca rápida por auxílio médico;  
- **d)** Treinamento difuso da população para atendimento de urgência nos moldes de suporte básico de vida (BLS – Basic Life Support).  
##### **1.1. FIBRINÓLISE PRÉ HOSPITALAR**  
O retardo pré‐hospitalar — intervalo entre o início dos sintomas isquêmicos e a chegada ao hospital — é um dos determinantes do tamanho do infarto e da mortalidade pré e intra‐hospitalar. Esse tempo é de 3‐4 horas, em média. A utilização pré‐hospitalar do fibrinolítico visa a reduzir este retardo.  Estudos de fibrinólise pré‐hospitalar realizados em diferentes países demonstraram que esse procedimento é factível e capaz de reduzir o tempo para administração do fibrinolítico . É importante reconhecer que em todos os estudos que utilizaram fibrinolíticos fora do ambiente hospitalar havia condições operacionais apropriadas para seu uso, para a monitorização, tanto clínica como eletrocardiográfica, pré‐hospitalar.  
Disponibilidade de fibrinólise Fibrinólise pré‐hospitalar : desde pré‐hospitalar e impossibilidade que não haja contraindicação e que de fazer angioplastia primária em o tempo primeiro atendimento – 90 min. agulha seja de até 30 minutos  
33  
##### **2** **<u>INTERVENÇÃO TERAPÊUTICA INICIAL</u>**  
##### **2.1 Medidas gerais**  
- Obter acesso venoso calibroso;  
- <u>Repouso</u> no leito nas primeiras 12 a 24h. Se estável hemodinamicamente, sem arritmias e sem recorrência da dor torácica por 12 a 24h, liberar para levantar do leito;  
- • <u>Monitorização eletrocardiográfica contínua;</u>  
- <u>Oxigênio</u> suplementar – apenas em paciente congestão pulmonar, dispnéia, cianose ou SatO2 < 90%;  
- <u>Morfina</u> – se não houver alívio da dor com nitratos, usar morfina 2 a 4 mg a cada 5 a 15 minutos, se necessário, para redução da ansiedade e atividade autonômica, diminuindo a demanda metabólica do miocárdio;  
- <u>Ansiolíticos</u> – não tem indicação de uso indiscriminado. Não há benefício comprovado.  
##### **2.2 Nitratos**  
- Inicialmente usar nitrato sublingual (dinitrato de isossorbida 5mg). Repetir até três vezes, cada 5 min, se houver persistência da dor torácica;  
- Via endovenosa por até 48h e após por via oral, em especial naqueles com hipertensão arterial, ou congestão pulmonar;  
- Contraindicações: bradicardia (FC < 50bpm), PAS < 90 mmHg, IAM de VD, uso de inibidor da fosfodiesterase (sildenafil nas últimas 24h, tadalafil nas últimas 48h e vardenafil ‐ não há tempo definido);  
- Efeitos colaterais: Cefaléia, tonteira, vertigem, rubor facial, hipotensão, hipotensão ortostática, taquicardia reflexa.  
##### **2.3 Ácido Acetil Salicílico (AAS)**  
- É o antiplaquetário de eleição nas SCA;  
- Dose: 160 a 325 mg (deve ser mastigado para facilitar a absorção) quando do primeiro atendimento, antes mesmo da realização do ECG. No Brasil a dose comumente utilizada é de 200 mg no atendimento inicial. A terapia de manutenção pode ser feita com 100 mg/dia;  
- Efeitos colaterais mais comuns: aumento da freqüência de eventos hemorrágicos (principalmente gastrintestinais), broncoespasmo, angioedema, anafilaxia, trombocitopenia;  
- Para paciente com SCA e sangramento gastrintestinal prévio, em uso isolado de AAS ou combinado com o clopidogrel, deve ser prescrito inibidores da bomba de prótons;  
- Para contraindicação ao AAS, deve ser administrado clopidogrel (dose de ataque: 300 mg; dose de manutenção: 75mg/dia).  
##### **2.4 Clopidogrel**  
- Indicado nas SCA com supra e sem supra ST em associação ao AAS.  
34  
- Dose de ataque:  
- Em pacientes com 75 anos ou mais, não administrar dose de ataque – apenas um comprimido de 75 mg.  
- No IAMCSST:  
- Tratamento com ICP primária: 600mg (considerar 300mg em pacientes com risco de sangramento aumentado);  
- Trombolítico ou sem terapia de reperfusão: 300 mg .  
- Na SCASSST: 300 mg. Considerar 600 mg nos pacientes tratados com estratégia invasiva precoce, considerando aumento do risco de sangramento.  
Dose de Manutenção: 75 mg / dia, idealmente por 9 meses. Tempo mínimo de uso em pacientes com stent convencional: 1 mês. É importante não descontinuar o tratamento após alta. Diante desta necessidade de continuação do tratamento, o estabelecimento hospitalar deverá entregar no dia da alta, 30 (trinta) comprimidos ao paciente até que seja adquirido pelo componente especial da assistência farmacêutica (CEAF).  
- Em pacientes com SCA, em que se planeja CRVM, deve‐se suspender o clopidogrel por um período mínimo de 5 dias, a exceção, quando há necessidade de CRVM de urgência.  
- Efeitos colaterais mais comuns: aumento da freqüência de eventos hemorrágicos, reações anafilactóides, angioedema, hipersensibilidade, síndrome de Stevens Johnson, neutropenia.  
##### **2.5 Inibidores da Glicoproteína IIB/IIIA (iGP)**  
O uso dos iGP (abciximab e tirofiban) em adição à terapia antiagregante dupla (clopidogrel em associação ao ácido acetilsalicílico) ainda é controverso, pelo aumento do risco de sangramento e redução do benefício a ser obtido. Reconhece‐se as seguintes indicações aos iGP:  
- IAMCSST: O abciximab pode ser administrado, pelo hemodinamicista, em pacientes < 75 anos que serão submetidos à ICP primaria, especialmente diante de alta “carga trombótica” intracoronária.  
- SCASSST: Considerar abciximab ou tirofiban no tratamento de pacientes de alto risco com programação de coronariografia precoce, quando não é possível ou desejável e utilizar clopidogrel.  
##### **2.6 Anticoagulantes**  
##### **2.6.1 Heparinas**  
Pode‐se utilizar tanto a heparina não fracionada (HNF) como a heparina de baixo peso molecular (HBPM), que apresenta vantagens terapêuticas por não necessitar de monitorização da anticoagulação e ter esquema posológico mais simples. Não há diferença entre elas em relação a morte e IAM não‐fatal na SCASSST, mas a HBPM está associada à menor ocorrência de eventos cardiovasculares maiores nos pacientes com IAMCSST tratados com terapia de reperfusão. Os efeitos colaterais incluem eventos hemorrágicos, trombocitopenia (induzida por heparina ou imune), estados pró‐trombóticos e reações anafilactóides.  
35  
##### **<u>SCACSST</u>**  
- Todo paciente submetido à reperfusão deve receber heparina (HNF ou, preferencialmente, HBPM) por no mínimo 48h, idealmente 8 dias ou até alta hospitalar;  
- Na terapia trombolítica, a Enoxaparina (HBPM) é indicada como adjuvante a terapia trombolítica no IAMCST nas seguintes doses: em pacientes com idade < 75 anos: 30 mg IV em bolo e após 1,0 mg/kg de peso subcutâneo de 12/12 horas até a alta hospitalar; em pacientes com idade ≥ 75 anos: não administrar o bolo e iniciar com 0,75 mg/kg subcutâneo de 12/12 horas. ( I/A). Se se optou por heparina não fracionada como adjuvante na terapia trombolítica, ajustar dose de anticoagulante pelo PTT ( RPC 1,5 a 2.0 X);  
- Nos Pacientes submetidos à angioplastia primária:  
- Em tratamento prévio com HNF, usar bolus adicional durante procedimento.  
- Pacientes tratados com enoxaparina: se a última dose subcutânea foi administrada:  
- Há menos de 8h: não deve ser administrada heparina adicional;  
- Entre 8 e 12h: administrar bolo de 0,3 mg/Kg IV;  
- Há mais de 12h: administrar bolo de 1 mg/Kg IV.  
##### **<u>SCASSST</u>**  
- Todo paciente deverá receber HNF por 48h ou enoxaparina por 8 dias ou até     alta hospitalar;  
- Naqueles eleitos para estratégia conservadora, deve‐se preferir enoxaparina.  
##### **Doses Recomendadas:**  
##### **<u>HNF</u>** ‐ por 48h (risco de trombocitopenia):  
- Bolo inicial: 60U/Kg (máximo: 4000 U)  
- Manutenção: 12U/kg/h (até 1000U/h), mantendo PTTa 1.5 a 2.0 vezes a referência.  
- **<u>Enoxaparina</u>** ‐ na internação hospitalar, por até 8 dias:  
- Pacientes < 75 anos e sem IRC: 1mg/Kg de 12/12h SC;  
- Pacientes > 75 anos: 0,75 mg/kg de 12/12h SC.  
- Pacientes com IRC (clearance de creatinina< 30 mL/min: 1 mg/kg SC, 24/24h.  
##### **2.6.2 FONDAPARINUX**  
Este inibidor indireto do fator Xa tem menor probabilidade de produzir trombocitopenia e é comparável às heparinas, principalmente quando se opta pela terapêutica conservadora.  
##### **<u>IAMCSST</u>**  
- Paciente não submetido à ICP primária deve receber fondaparinux (creatinina < 3 mg/dl) 2.5mg IV, depois 2,5mg SC cada 24h, na internação hospitalar, até 8 dias.  
##### **<u>SCASSST</u>**  
- O fondaparinux pode ser anticoagulante de escolha em casos de tratamento conservador, na dose 2,5mg SC cada 24h, durante a internação hospitalar, por até 8 dias.  
36  
- O fondaparinux pode ser utilizado no lugar da heparina (HNF ou HBPM) no paciente de estratégia invasiva, na dose 2,5mg SC cada 24h, recebendo bolo único IV de HNF (85U/kg ou 60U/kg se uso de iGP) no momento da coronariografia ou da ICP.  
- **2.7 Betabloqueadores**  
- O uso de betabloqueador oral está indicado nas primeiras 24 horas de SCA em pacientes de baixo risco de desenvolver choque cardiogênico e na ausência de contraindicações;  
- Betabloqueador IV deve ser usado em pacientes com hipertensão ou taquiarritmia, na ausência de disfunção ventricular esquerda sistólica;  
- Efeitos colaterais mais comuns incluem bradicardia, bloqueios de condução, piora dos sintomas de insuficiência cardíaca, broncoespasmo, hipotensão.  
_<mark>CONTRAINDICAÇÕES AO USO DE BETABLOQUEADOR</mark>_ Frequência cardíaca <60 bpm Pressão Sistólica <100 mmHg Intervalo PR > 0,24 segundos BAV de 2º e 3º graus História de asma ou doença pulmonar obstrutiva grave Doença vascular periférica grave Disfunção Ventricular grave Classe Killip ≥ 2  
##### **3** **<u>TERAPIA DE REPERFUSÃO</u>**  
A pronta restauração do fluxo sanguíneo coronariano é essencial para o salvamento miocárdico e reduzir mortalidade. Dentro das 3 primeiras horas de apresentação dos sintomas, não há diferença entre a terapia trombolítica e ICP primária no benefício em relação à mortalidade, com exceção dos casos de rápida evolução para choque cardiogênico em que a ICP primária deve ser a opção terapêutica. Independente do modo de reperfusão, o objetivo é reduzir o tempo de isquemia total, definido como o tempo entre o início dos sintomas e o início da terapia de reperfusão.  
##### **TERAPIA DE REPERFUSÃO NO IDOSO:**  
Nos pacientes idosos, especialmente nos com mais de 75 anos, há um grande receio em se realizar trombólise já que nestes pacientes há maior taxa de sangramento e **3.1  TERAPIA TROMBOLÍTICA** AVC em comparação com pacientes mais jovens e, portanto aparentemente não haveria beneficio com o uso do fibrinolítico. No entanto estudos observacionais demonstraram que **O maior benefício desta terapia é observado nas primeiras 6 horas do início dos** fluxo coronariano normal após lise, ocorre, na mesma proporção abaixo e acima de 75 anos **sintomas, não havendo benefício demonstrado após 12 horas de evolução.** e a análise de pacientes com mais de 75 anos e com IAM com ST supra ou BCRE novo **O benefício da trombólise torna‐se mais significativo quando a diferença de tempo** mostrou redução de 15% na mortalidade, quando submetidos à terapia trombolítica. **entre a administração do trombolítico e a ICP primária é maior que 60 minutos (tempo de** Além disso, em pacientes acima de 75 anos a mortalidade por IAM é **atraso).** significantemente maior (5 a 8 vezes) em relação, as faixas de adultos mais jovens, enquanto as taxas de sangramento e AVC ficam apenas duas a três vezes maiores, o que significa que o potencial benefício relativo do uso de líticos é significativo nos mais idosos. Pacientes com IAMCSST com menos de 12 horas do início dos sintomas Nas situações em que é possível angioplastia primária rápida e realmente imediata esta, **3.1** , devem receber terapia trombolítica imediatamente  (idealmente,dentro **<u>TERAPIA TROMBOLÍTICA</u>** deve ser a ~~de 30 min), quando a ICP~~ <u>primeira opção, mas para a grande maioria dos casos em que esta possibilidade</u> primária não pode ser realizada dentro de 90 não é viável, a trombólise deve ser indicada. minutos da admissão. 37  
37  
A terapia trombolítica reduz significativamente a mortalidade em pacientes com IAMCSS. O benefício da trombólise na mortalidade é mais dependente do tempo de isquemia do que a ICP primária, sendo maior nas primeiras 6 horas do início dos sintomas, não havendo benefício demonstrado após 12 horas de evolução.  O benefício da trombólise torna‐se mais significativo quando o tempo de atraso entre a administração do trombolítico e a ICP primária é maior que 60 minutos.  
Pacientes com IAMCSST com menos de 12 horas do início dos sintomas devem receber terapia trombolítica imediatamente (dentro de 30 min.), quando a ICP primária não pode ser realizada dentro de 90 minutos da admissão.  
##### **3.1.1** **<u>COMPARAÇÃO ENTRE OS TROMBOLÍTICOS</u>**  
A classe de trombolíticos é dividida em fibrino‐específicos (alteplase – tPA; tenecteplase – TNK) e não fibrino‐específicos (estreptoquinase – SK).  Os trombolíticos fibrino‐específicos são levemente superiores à SK na redução da mortalidade, porém possuem uma maior taxa de hemorragia cerebral. A TNK, único fibrinolítico disponível para uso em bolo único, é equivalente, em termos de mortalidade, ao tPA e está associada a menor taxa de sangramentos não cerebrais e menor necessidade de transfusão sanguínea. A estreptoquinase não deve ser repetida (após 5 dias), pois anticorpos para a SK persistem por até 10 anos.  
- O TNK é o trombolítico de escolha nas UPAs e no SAMU.  
- Nos ambientes hospitalares, trombolíticos fibrino‐específicos devem ser reservados para IAMCSST de apresentação mais precoce e com maior área de miocárdio afetada ou nos pacientes que apresentam contraindicação ao uso da SK.  
- A SK deve ser preferida em maiores que 75 anos pelo menor risco de sangramento cerebral.  
##### **3.1.2** **<u>CONTRAINDICAÇÕES AO TROMBOLÍTICO</u>**  
Cerca de metade dos pacientes com IAMCSST são inelegíveis para terapia trombolítica. Na maioria dos casos, isto se deve à apresentação tardia (>12 h), e não às contraindicações.  
38  
|_Contraindicações absolutas_|_Contraindicações relativas_|
|---|---|
|Qualquer sangramento intracraniano<br>AVC isquêmico nos últimos três meses<br>Dano ou neoplasia no sistema nervoso<br>central|História de AVC isquêmico > 3 meses ou patologias<br>intracranianas não listadas nas contraindicações<br>Gravidez<br>Uso atual de antagonistas da vitamina K: quanto<br>maior o INR maior o risco de sangramento|
|Trauma significante na cabeça ou<br>rosto nos últimos três meses|Sangramento interno recente < 2‐4 semanas|
|Sangramento<br>ativo<br>ou<br>diástese<br>hemorrágica (exceto menstruação)<br>Qualquer<br>lesão<br>vascular<br>cerebral<br>conhecida<br>(malformação<br>arteriovenosa)|Ressuscitação cardiopulmonar traumática ou<br>prolongada (> 10 min) ou cirurgia < 3 semanas<br>Hipertensão arterial não controlada (pressão<br>arterial sistólica > 180 mmHg ou diastólica > 110<br>mmHg)|
|Suspeita de dissecção de aorta|Punções não compressíveis<br>História<br>de<br>hipertensão<br>arterial<br>crônica<br>importante e não controlada<br>Úlcera péptica ativa<br>Exposição prévia a SK (mais de 5 dias) ou reação<br>alérgicaprévia|  
##### **<u>DOSES DE TROMBOLÍTICOS :</u>**  
|_AGENTE_|_TRATAMENTO_|_ANTITROMBÓTICOS_|
|---|---|---|
|_SK_|1.5 milhões UI em 100 ml SG<br>5% ou SF 0.9% em 30‐60 min|HNF ajustada pelo peso ou Enoxaparina<br>ou fondaparinuxpor até 8 dias.|
|_tPA_|15 mg em bolo , seguidos por<br>0,75 mg/Kg em 30 min e<br>então 0,5 mg/Kg em 60 min<br>Dose máxima total: 100 mg|HNF ajustada pelo peso ou Enoxaparina<br>ou fondaparinux por até 8 dias.|
|_TNK_|Bolo Único:<br>30 mg se <60 Kg<br>35 mg entre 60 e < 70Kg<br>40 mg entre 70 e < 80 Kg<br>45 mg entre 80 e < 90 Kg<br>50 mg > 90 Kg<br>Dose máxima total: 50 mg|HNF ajustada pelo peso ou Enoxaparina<br>ou fondaparinux por até 8 dias.|  
##### **3.2** **<u>INTERVENÇÃO CORONÁRIA PERCUTÂNEA (ICP) PRIMÁRIA</u>**  
ICP primária é a utilização do cateter balão com ou sem implante do stent coronário e sem o uso prévio de trombolítico, para restabelecer mecanicamente o fluxo o coronário anterógrado. Quando disponível, constitui‐se na melhor opção para a obtenção da reperfusão coronária, se iniciada até 90 min após admissão do paciente (tempo porta‐ balão). Se houver contraindicação à trombólise ou em caso de choque cardiogênico, ICP primária também é a opção preferencial.  
39  
■ Pacientes com IAMCSST devem ser tratados imediatamente com ICP primária (dentro de 90 min desde a sua admissão).  
■ Pacientes com contraindicação formal a terapia trombolítica devem ser transferidos para realização de ICP primária em até 12 h do início dos sintomas.  
##### **3.3** **<u>ICP DE RESGATE</u>**  
A ICP de resgate é realizada após o trombolítico, quando não há critérios de reperfusão:  
‐ **<u>Clínicos:</u>** dor torácica persistente e intensa, especialmente se associada à sudorese, dispnéia, e instabilidade hemodinâmica;  
**‐ Eletrocardiográficos** <u>:</u> supra de ST com redução discreta (<50% na derivação com o maior supra de ST), persistente, ou em aumento. Novo ECG deve ser realizado 60 a 90 min. após trombólise.  
Há redução de reinfarto e de incidência de IC, além de uma tendência à redução de mortalidade.  
Diante da ausência de critérios clínicos ou eletrocardiográficos que sugiram reperfusão miocárdica, principalmente no IAMCSST de parede anterior ou de outra grande área em risco, é recomendável a realização precoce da ICP de resgate em tempo < 180 min se possível.  
##### **3.4** **<u>ICP FACILITADA</u>**  
Os estudos não evidenciaram benefício da ICP facilitada na redução do tamanho do IAM ou na melhora dos desfechos.  
##### **3.5** **<u>TRANSFERÊNCIA PARA  ICP PRIMÁRIA</u>**  
Em hospitais sem recursos para ICP primária, existem duas estratégias a serem seguidas: tratamento com trombolíticos ou transferência para serviço com laboratório de hemodinâmica para ICP primária. Pacientes com menos de 3 h de início dos sintomas se beneficiam mais do trombolítico no local do evento. Há benefício da ICP primária após transferência sobre a terapia trombolítica no local, com redução de eventos cardiovasculares combinados, como morte, reinfarto ou AVC, se o atraso provocado pela transferência for menor que 60 minutos. A maior desvantagem da transferência para ICP primária é a demora na reperfusão miocárdica, com prolongamento no tempo de isquemia. Cada 30 minutos de atraso do início dos sintomas à insuflação do balão aumenta em 7,5% a taxa de morte em 1 ano.  
40  
Pacientes atendidos até 3 horas do início da dor devem receber trombolítico no local de atendimento, na ausência de contraindicações, se ICP primária no local for indisponível.  
A transferência para ICP primária deve ser realizada para pacientes com IAMCSST que se apresentam após 3 horas de dor, especialmente em pacientes de alto risco, **se o atraso provocado pela transferência for menor que 60 minutos** .  
A transferência para um centro com um serviço de hemodinâmica deve ser feita assim que possível nos pacientes de alto risco, seja para realização de ICP, se necessário, ou para a estratificação invasiva precoce.  
##### **4** **<u>TERMINOLOGIA DOS TEMPOS DA REPERFUSÃO CORONARIANA</u>**  
##### **_NA ICP PRIMÁRIA:_**  
<!-- Start of picture text -->
Chegada ao  Chegada ao<br>Início dos  Ligação para o  Saída do hospital  ICP<br>hospital  hospital com<br>sintomas  SAMU  primário  primária<br>primário  hemodinâmica<br>Tempo de<br>Atraso do  Tempo do  Atraso do hospital  Tempo<br>transferência inter‐<br>paciente  transporte  primário  porta‐balão<br>hospitalar<br>Atraso pré‐hospitalar<br>Atraso do sistema<br>Atraso no tratamento (tempo de isquemia)<br><!-- End of picture text -->  
##### **_NA TROMBÓLISE:_**  
<!-- Start of picture text -->
Chegada ao<br>Início dos  Ligação para  Início do<br>hospital<br>sintomas  o SAMU  trombolítico<br>primário<br>Atraso do  Tempo do  Tempo porta‐<br>paciente  transporte  agulha<br>Atraso do sistema<br>Atraso no tratamento (tempo de isquemia)<br><!-- End of picture text -->  
##### **5** **<u>REVASCULARIZAÇÃO CIRÚRGICA DE URGÊNCIA NA SCA</u>**  
A cirurgia de revascularização de urgência é hoje pouco utilizada no tratamento da SCACSST, sendo restrita a casos que evoluem com sinais de isquemia recorrente em que a coronariografia identifica lesões críticas com anatomia desfavorável a ICP e passíveis de tratamento cirúrgico _ou_ nas complicações mecânicas do infarto. O período ideal para a revascularização cirúrgica de emergência deve ser inferior a 4‐6 horas após o início do infarto, podendo se estender até 18 horas após a instalação do choque cardiogênico, quando a anatomia coronária for totalmente desfavorável para a ICP.  
41  
<!-- Start of picture text -->
Fluxograma de Reperfusio Miocardica<br>no IAM com Supra ST i ~<br>(VAM com Supra ST\\<br>\ \ BREnovo ou }<br>S : ~<br>jim —~ Choque ~~<br>[ ~cardiogénicoeee,. — > —————~<br>y ng (/ Transferéncia »\<br>aAON Nao | rapida para UCo |<br>yaTempo de sintoma <_—~ 36h~ fou ANA \~ ean)~<br><~\Tempo de choquee  < 18h ~~Nao>—Nao—>/_p/ \_stimizado Ttoclinico0 \y Nao 4.  —< -“Tempodesigtoma <12)> *<br>NLU y Trombélise<br>gi im Nao<br>_”J rental n> _©ontraindicagao A. \ arantia<br><~HemodinamicaHospital com> —Nao>7 < Contraindicagaona Nao»a _Tempo de \Naor de tempo de<br>~ avy trombétise\ a7 \sintoma\  <3h_/Yo \transferéncia_/<60 min<br>sim| (_ aTransferenciasim ) Simify,<br>U™~ \para ICPOO primaria sim (_\paraTransferenciaICP primaria/»)<br>sim a NN oN<br><_/Tempo porta-balaoe  < 90 min Nao _Conaincaglo~.a > >-Naom Trombélise » /Transferéncia rapida\<br>~\ Tempo de atraso < 60min“ \ trombélise \Ppara UCO (2an) yy, )<br>Y JN<br>sim /Critérios de fo<br>y <teperfusao apés > —Naom ICP de resgate )<br>{L .\ \.90\  minutosJ N y,<br>ICP primaria}¢——_____si NY<br>sim<br>/ \<br>(- Ttoclinicoo<br>\. otimizado<br><!-- End of picture text -->  
42  
**6** **<u>TERAPIA FARMACOLÓGICA  ADICIONAL</u>**  
##### **6.1** **<u>Bloqueadores do sistema renina‐angiotensina‐aldosterona</u>**  
Os inibidores da enzima conversora de angiotensina (IECA) reduziram eventos cardiovasculares maiores, inclusive óbito, na fase aguda da SCA. Bloqueadores seletivos do receptor de angiotensina (BRA) tem menor evidência, mas a sua utilização na intolerância aos IECA parece ser segura e benéfica. Recomenda‐se a administração de inibidores da ECA nas primeiras 24 h do evento, em pacientes com IAM anterior, congestão pulmonar ou FEVE < 40%. Fora destas situações, considera‐se que sua administração possa também ser benéfica, mas deve ser reavaliada se não houver disfunção ventricular apos as primeiras 5 semanas.  
- IECA deve ser iniciado nas primeiras 24h (e mantido indefinidamente) em pacientes com IAMCSST com FEVE < 40%, HAS, DM ou DRC, a menos que contraindicado.  
`o` Possui indicação I/B no IAM anterior e Killip ≥ II.  
- Em pacientes de baixo risco é indicação IIa/B.  
- Na SCASSST, na presença FEVE < 40% ou sintomas de congestão pulmonar, o IECA deve ser iniciado nas primeiras 24h, a menos que contraindicado.  
- Nos outros pacientes, é indicação IIa/B.  
- BRA pode ser utilizado, na intolerância ao IECA, nas mesmas indicações.  
**Principais efeitos adversos:** tosse (pouco comum nos BRA), reações anafilactóides, angioedema, hipotensão, hipercalemia, insuficiência renal (sobretudo em caso de patologias obstrutivas de vasos renais), malformações congênitas (se utilizados no 1º trimestre da gravidez) **_._** _A suspensão do IECA está indicada na disfunção renal se o paciente evoluir com hiperpotassemia acentuada: K+ > 5,5 meq/L)._  
##### **6.2** **<u>Hipolipemiantes:</u>**  
Agentes hipolipemiantes, sobretudo as estatinas, são benéficos na prevenção secundária de eventos em pacientes após SCA. Recomenda‐se a administração rotineira de estatinas aos pacientes após SCA ainda na fase hospitalar, independentemente dos níveis de LDL‐colesterol.  
Estatinas devem ser iniciadas em pacientes com SCA, ainda na fase hospitalar, mesmo para aqueles com LDL < 100mg/dl.  
**Principais efeitos adversos:** mialgias (miopatia), rabdomiólise, náuseas, hepatotoxicidade, pancreatite, reações de hipersensibilidade.  
43  
**6.3** **<u>Bloqueadores dos canais de cálcio</u>**  
- Verapamil pode ser usado para controle de sintomas isquêmicos ou da freqüência cardíaca (na fibrilação ou flutter atrial de alta resposta) em pacientes com contraindicação aos BBloq ou que persistem sintomáticos a despeito do uso de BBloq e nitratos,  excluída as contra‐indicações, como sinais de IC, disfunção ventricular e BAV.  
- A Nifedipina de liberação rápida está contraindicada na vigência de SCA.  
**Efeitos Colaterais mais comuns:** bradicardia, bloqueios de condução, arritmias (derivados não‐didropiridínicos). Piora de sintomas de insuficiência cardíaca, congestão pulmonar, angioedema, reações de hipersensibilidade.

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- **1** **<u>ANGINA PÓS INFARTO</u>**  
- Angina, significando novos episódios isquêmicos, pode ocorrer durante o período de hospitalização pós‐infarto agudo em cerca de 20%‐30% dos casos, mas tem sido relatada depois de reperfusão com sucesso em até 58% dos indivíduos;  
- Deve ser otimizada a terapia anti‐isquêmica (Beta bloqueio efetivo / estabilização da PA, anticoagulação efetiva);  
- Cinecoronariografia tão logo possível está indicada naqueles que não respondem rapidamente a terapia farmacológica antiisquêmica.  
##### **2** **<u>INFARTO DE VD</u>**  
- A isquemia ventricular direita pode ser demonstrada em até 50% de todos os infartos do miocárdio de região inferior, embora em somente 10%‐15% dos pacientes possam ser observadas alterações hemodinâmicas clássicas (Hipotensão arterial, sinais de baixo débito);  
- O infarto de ventrículo direito, quando acompanha o infarto inferior, apresenta elevada mortalidade (25%‐30%). BAV é um achado comum, podendo ser encontrado em até 50%dos casos;  
- Em geral, a reposição volêmica com solução salina fisiológica normaliza a hipotensão e melhora o débito cardíaco. Embora a carga volêmica seja o primeiro passo no manuseio da hipotensão associada à isquemia ventricular direita, o suporte inotrópico (dobutamina) deve ser iniciado imediatamente caso o débito cardíaco não melhore após a administração de 500‐1.000 ml de carga volêmica.  
44  
**3** **<u>PERICARDITE PRECOCE PÓS IAM</u>**  
- Manifesta‐se em torno de 24 horas após o início do evento agudo. Clinicamente pode se caracterizar por dor torácica ventilatório‐dependente, agravada por inspiração profunda, tosse e deglutição, e aliviada quando o paciente flete o tórax anteriormente, podendo ou não ser acompanhada de febre baixa. A ausculta de atrito pericárdico é comum e facilita o diagnóstico definitivo;  
- O exame eletrocardiográfico pode levar a suspeita de pericardite quando apresenta elevação do segmento ST em precordiais esquerdas, com concavidade superior preservada;  
- Tratamento de escolha é a aspirina, 500mg 4/4h. A dose pode ser reduzida quando da melhora dos sintomas.  
##### **4** **<u>EDEMA AGUDO DE PULMÃO</u>**  
O edema pulmonar associa‐se a mortalidade de 20 a 40% em 30 dias. A causa do EAP (disfunção sistólica, diastólica, IM aguda, ruptura do septo interventricular – SIV) deve ser avaliada rapidamente através do <u>ecocardiograma. A conduta imediata inclui oxigenação</u> adequada e redução da pré‐carga para o alívio da congestão pulmonar:  
- <u>Oxigênio</u> (SATO2 deve permanecer > 90%);  
- <u>Furosemida EV</u> : 40 a 80 mg;  
- <u>Morfina :</u> 2 mg EV  a cada 2 min , até alívio dos sintomas;  
- <u>Nitrato EV  ( Nitroglicerina)</u> : Naqueles pacientes que não se encontram hipotensos; Nitrato SL pode ser utilizado caso não haja nitrato EV;  
- <u>Ventilação Não Invasiva (VNI): Caso não haja melhora do quadro ventilatório, proceder</u> a intubação orotraqueal.  
<!-- Start of picture text -->
Edema agudo de pulmão Fluxograma para<br>tratamento do EAP<br>Avaliação inicial<br>Respiratório  Hemodinâmico<br>Oxigenioterapia Morfina 2 a 4 mg IV<br>VNI – CPAP Furosemida 40 a 80 mg IV<br>Ventilação mecânica Nitrato SL<br>Status hemodinâmico<br>Hipertensão arterial Hipotensão arterial<br>Nitroglicerina IV 0,3 a 0,5 mcg/min Fármacos inotrópicos e vasopressores<br><!-- End of picture text -->  
45  
##### **5** **<u>CHOQUE CARDIOGÊNICO</u>**  
Estado de hipoperfusão tecidual, caracterizado por pressão arterial sistólica < 90 mmHg, índice cardíaco < 1,8 l/min/m² e pressões de enchimento elevadas.  
Nos pacientes com IAM, as principais causas de choque cardiogênico são:  
- Insuficiência ventricular esquerda (74%);  
- IM aguda (8%);  
- Ruptura do SIV (4%);  
- IAM isolado do VD (3%);  
- Tamponamento ou ruptura cardíaca (1%).  
##### Conduta:  
- <u>Monitorização invasiva da pressão arterial;</u>  
- <u>Dobutamina: não aumenta sobrevida, mas é necessária para manter perfusão coronária</u> e sistêmica;  
- <u>Noradrenalina: recomendada em choque mais grave;</u>  
- <u>Trombolítico: se ocorrer choque entre 3 e 6 horas do início do IAM e previsão de atraso</u> no transporte e na intervenção, a terapia fibrinolítica deve ser iniciada de imediato;  
- <u>Balão intra‐aórtico (BIA): indicado como “ponte” para estabilização hemodinâmica em</u> candidatos a revascularização miocárdica (ICP ou CRVM) de emergência;  
- <u>Coronariografia / ICP primária: há benefício na revascularização miocárdica precoce (ICP</u> ou CRVM), desde que feita em 36h do início do IAMCSST e 18h do início do choque;  
- <u>Ecocardiograma: necessário para excluir complicações mecânicas como CIV, IM grave ou</u> ruptura da parede livre no VE (tamponamento cardíaco);  
- <u>Transferência: recomendada para centro regional com capacidade de CRVM.</u>  
O quadro abaixo orienta o uso de aminas e nitroglicerina no choque cardiogênico no IAMCSST.  
<!-- Start of picture text -->
Choque cardiogénico<br>PAS > 100 mmHg PAS entre 70-100 mmHg PAS entre 70-100 mmHg PAS < 70 mmHg<br>SEM sinais de choque Com sinais de choque<br>Nitroglicerina<br>40-20 meg/min IV Dobutamina Dopamina Noradrenalina<br>2 meginin 2,0-20 meg/Kg/min IV 5-15 mog/Kg/min IV 0,5-30 megimin IV<br><!-- End of picture text -->  
Fonte: Arq Bras Cardiol 2009; 93(6 Supl. 2): e179‐e264  
46  
##### **6.  COMPLICAÇÔES MECÂNICAS**  
##### **6.1 Insuficiência Mitral Aguda**  
-  
-  
-  
-  
-  
-  
- Relacionada à isquemia / ruptura do músculo papilar;  
- Mais comum nos IAM de parede inferior (> 80%);  
- Ocorre mais comumente entre o 2º e 7º dias de IAM;  
- Diagnóstico: ecocardiográfico;  
- Elevada Mortalidade Hospitalar: 22 a 55% (Cirurgia de Urgência)  
- Tratamento;  
- BIA, inotrópicos (Dobutamina), vasodilatadores (Nitroprussiato de sódio) e Diuréticos;  
- Cirurgia de reparo valvar ou troca valvar mitral (I/C);  
- CRVM, se necessária, deve ser realizada no mesmo procedimento cirúrgico.  
##### **6.2 Ruptura do Septo Interventricular**  
- Incidência de 0,2 – 0,3% (complicação rara) ;  
- Ocorre mais comumente entre o 3º e 5º dias de IAM;  
- Diagnóstico: ecocardiográfico;  
- Tratamento:  
- Cirurgia de reparo da ruptura do SIV;  
- CRVM, se necessário, deve ser realizada no mesmo procedimento cirúrgico.  
##### **6.3 Ruptura da Parede livre do VE**  
- Tem incidência de 0,8%‐6,2% dos infartos e está presente em cerca de 10% dos  
- pacientes que morrem de IAM na fase hospitalar;  
- O tratamento é cirúrgico de emergência, quando indicado;  
- Drenagem pericárdica pode ser realizada para alívio do tamponamento cardíaco,  
- antes da correção cirúrgica.  
##### **7 .  TAQUIARRITMIAS**  
##### **7.1 Fibrilação atrial / Flutter atrial**  
- Incidência varia de 10 – 22% na evolução do IAM, principalmente os de parede anterior;  
- Fator de risco independente para mortalidade hospitalar.  
- Em pacientes com instabilidade hemodinâmica – realizar cardioversão elétrica  
- imediata. ( 200 J – FA) / 50 J no Flutter.  
- Nos pacientes estáveis: Controle da resposta ventricular com Bbloq / Digital e/ou  
- tentativa de cardioversão  com drogas (Amiodarona).  
47  
##### **7.2 Taquicardia Ventricular (TV)**  
- TV sustentada polimórfica e instabilidade hemodinâmica deve ser tratada com choque  
- não sincronizado 360J (cardioversor monofásico) ou 200J (cardioversor bifásico).  
- TV sustentada, monomórfica, mas com angina, edema pulmonar ou hipotensão deve  
- ser tratada com choque sincronizado 100J (cardioversor monofásico) sob anestesia e sedação, além de amiodarona IV: 150 mg em 10 min.; repetir 150 mg em 10 min. e depois 540 mg em 18h.  
- TV com estabilidade hemodinâmica poderá ser tratada com amiodarona EV.  
- Na TV sustentada refratária é aceitável tentar reduzir a isquemia com  
- betabloqueadores, BIA, ICP e CRVM, além de manter potássio > 4 mEq/L e magnésio > 2 mEq/L.  
Pacientes de alto risco devem ser referendados para a coronariografia e subseqüente revascularização, se necessário.  
■ Pacientes de alto risco devem ser referendados para a coronariografia e subseqüente revascularização, se necessário.  
##### **7.3  Fibrilação Ventricular**  
A FV primária ocorre nas primeiras 24 às 48h do IAM e não implica em um maior risco de eventos futuros. Já a FV secundária associa‐se a insuficiência cardíaca congestiva ou choque cardiogênico e se desenvolve após 48h do início do IAMCSST.  
■ FV deve ser tratada com choque não sincronizado de 360 joules (cardioversor monofásico) ou choque de 200 joules (cardioversor bifásico). ■ . FV refratária deve ser tratada com amiodarona IV (300 mg ou 5 mg/kg) seguido de choque não sincronizado.  
##### **8. BRADIARRITMIAS**  
- **8.1 Bradicardia sinusal**  
- Ocorre em 30 – 40% dos pacientes infartados, principalmente nos infartos de parede inferior / posterior;  
- Se nas primeiras 4 a 6 horas após o IAM o paciente evoluir com bradicardia (< 40 a 50 bpm) associada a hipotensão, atropina IV pode ser administrada (0,3 a 0,6 mg cada 3 a 10 min. até 2 mg) para manter frequência cardíaca em aproximadamente 60 bpm.  
- **8.2 BAV 1º grau**  
Em geral não precisa de tratamento.  
- **8.3 BAV 2º grau**  
- Mobitz I – Não afeta a sobrevida, terapia específica não é necessária.  
48  
- Mobitz II ‐ geralmente origina‐se de uma lesão no sistema de condução abaixo do feixe de His. Devido a seu potencial para progressão para BAVT, deve ser tratado com marcapasso externo ou transvenoso temporário.  
##### **8.4  BAVT**  
O BAV completo associado com IAM inferior é geralmente     transitório, com QRS estreito e ritmo de escape acima de 40 bpm e baixa mortalidade, enquanto o BAV completo relacionado ao IAM anterior é mais freqüentemente localizado abaixo do nó AV, com ritmo de escape instável, QRS alargado e associado a necrose miocárdica extensa. Caso haja progressão para bradicardia que cause hipotensão ou insuficiência cardíaca não responsiva a atropina, **<u>deve ser implantado marcapasso externo ou transvenoso temporário.</u>**

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
O prognóstico da SCA é muito variável e a estratificação de risco tem basicamente três objetivos:  
- Estimar o risco de IAM e óbito de causa cardiovascular;  
- Direcionar terapias para pacientes com maior risco de eventos cardiovasculares adversos e definir a melhor estratégia de tratamento;  
- Evitar terapias desnecessárias e com efeitos adversos em pacientes de baixo risco.  
Informação prognóstica importante é obtida da avaliação clínica cuidadosa, da evolução do pacientes durante os primeiros dias e da resposta do paciente ao tratamento anti‐isquêmico e antitrombótico.  Há vários escores de estratificação de risco que podem prever morte ou IAM em SCA, sendo os mais utilizados o GRACE e o TIMI (em anexo). Embora o escore TIMI seja mais prático, o escore GRACE parece mais acurado.  
A determinação do risco do paciente pode ser feita com ajuda de escores validados, como o escore TIMI ou o escore GRACE.  
49  
De modo geral, reconhece‐se os seguintes indicadores gerais de gravidade:  
|**CRIT**|**ÉRIOS DE GRAVIDADE**|
|---|---|
|**1.**|MNMpositivos|
|**2.**|Presença de B3 ou congestãopulmonar(KillipII)|
|**3.**|Edema agudo depulmão(KillipIII)|
|**4.**|Choque cardiogênico(KillipIV)|
|**5.**|Alterações dinâmicas do segmento ST(maiorque 0,5mm)|
|**6.**|Sopro de regurgitação mitral de inicio recente ou modificadopeloquadro agudo|
|**7.**|Taquicardia ventricular sustentada|
|**8.**|Angioplastia ou CRVMprévia nos últimos 6 meses|
|**9.**|Angina recorrente em repouso oupequeno esforço apesar de tratamento intensivo|
|**10.**|Depressão da função ventricular(FEVE< 40%)|
|**11.**|Idade maiorque 75 anos|
|**12.**|Escore TIMI ≥ 5pontos(vide anexo)|
|**13.**|Escore Grace  ≥ 170pontos(vide anexo)|
|**14.**|<sup>Testes não invasivos (teste ergométrico, cintilografia miocárdica e ecocardiograma de</sup><br>estresse)com critérios de alto riscopara isquemia|  
##### **1** **<u>SÍNDROME CORONARIA AGUDA SEM SUPRA ST</u>**  
Risco de novos eventos:  
||ALTO|INTERMEDIÁRIO|BAIXO|
|---|---|---|---|
||TIMI ≥ 5 ou GRACE > 170 ou|TIMI 3 ou 4|TIMI ≤ 2|
|−|Alto risco em exame funcional prévio|GRACE 130 a 170|GRACE < 130|
|−|FEVE ≤ 40%|**E**|**E**|
|−<br>−<br>−|ICP nos últimos 6 meses<br>Insuficiência mitral (IM) nova ou piora de IM prévia<br>Sinais de IC aguda|Nenhum critério de<br>alto risco|Nenhum critério<br>de alto risco|
|−|Angina refratária|||
|−|Instabilidade hemodinâmica|||
|−|Instabilidade elétrica|||
|−<br>−|Infra ST novo (>1 mm) ou supra ST transitório<br>MNM elevados(CKMB e troponina)|||  
##### **_BAIXO RISCO_**  
Pacientes com SCASSST de baixo risco não se beneficiam de ICP, exceto se constatada isquemia miocárdica nos testes funcionais não‐invasivos. O teste ergométrico (TE) é o método de escolha na avaliação do paciente com AI de baixo risco na maioria dos casos.  Métodos de imagem (ecocardiograma sob estresse e cintilografia miocárdica) têm desempenho diagnóstico semelhante ou superior ao TE, mas com custo mais elevado. Deve ser realizado quando o TE é normal ou inconclusivo e com sintomas significativos ou na presença de limitações à realização ou interpretação do TE.  
50  
- Um teste de estresse é recomendado em pacientes de baixo risco que estejam livres de  
- isquemia em repouso ou aos mínimos esforços por no mínimo 12h **_._**  
- O teste ergométrico é teste de escolha na avaliação funcional de SCASSST de baixo risco **_._**  
- Métodos de imagem sob estresse (cintilografia miocárdica ou ecocardiograma) podem ser necessários em casos especiais, utilizando‐se:  
- Estresse físico: Em pacientes que são capazes de se exercitar, mas possuem alterações no ECG basal que impedem sua interpretação durante o esforço (marcapasso, BCRE, pré‐excitação ventricular ou infra de ST em repouso > 1 mm) ou que foram submetidos à revascularização miocárdica recentemente ‐> método de imagem sob estresse físico;  
- Estresse farmacológico: Quando limitações físicas impedem o estresse físico adequado.  
Pacientes de baixo risco ou com alto risco de complicações para realização de intervenção não devem ser submetidos à estratégia invasiva.  
##### **_RISCO INTERMEDIÁRIO_**  
Neste grupo, os resultados são similares, tanto na abordagem inicial conservadora, quanto na estratégia terapêutica invasiva. Vantagem da estratégia conservadora inicial é que vários pacientes estabilizam‐se com o tratamento clínico, evitando custos e possivelmente procedimentos invasivos desnecessários.  
- Paciente com SCASSST com risco intermediário de novo evento pode ser submetido à estratificação de risco não invasiva ou a estratificação de risco invasiva.  
- O teste de estresse não invasivo é recomendado neste paciente desde que esteja livre de isquemia em repouso ou aos mínimos esforços por, no mínimo, 12h.  
##### **_ALTO RISCO_**  
A estratégia invasiva em pacientes de alto risco reduz as taxas de IAM, angina grave e de re‐hospitalização no longo prazo. Tais pacientes devem ir diretamente para a angiografia sem teste não invasivo.  
A estratégia invasiva está indicada em pacientes de critérios de alto risco, com realização de coronariografia em até 72 horas (preferencialmente até 24h se houver múltiplos fatores de risco) e subseqüente revascularização, se necessário **_._**  
Pacientes de alto risco isquêmico com angina refratária, associada à insuficiência cardíaca, arritmias, ou instabilidade hemodinâmica devem ser considerados para coronariografia de emergência (< 2 h).  
51  
<!-- Start of picture text -->
( SCASSST \<br>Ne yy,<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fluxograma para estratificagao<br>de risco na SCASSST<br><!-- End of picture text -->  
<!-- Start of picture text -->
oO<br>oy<br>< Baixo riseo<br>~ a<br>NO<br><!-- End of picture text -->  
<!-- Start of picture text -->
ON<br>O isco<br>< tnuermeditio<br>NN a<br>NZ<br><!-- End of picture text -->  
<!-- Start of picture text -->
Uo<br>o ~~<br>Alto riseo ><br>N A<br>NZ<br><!-- End of picture text -->  
<!-- Start of picture text -->
Prova Funcional Coronariografiaou Coronariografiae<br>Prova Funcional Ecocardiograma<br>7 Isquemia ™ Z— wo (eon cRVM\<br>“miocardicava 4 N ao | /(revascularizagaoda\<br>NO <<\FEVE 340 ~%% S > \ artéria relacionada |<br>Sim<br>Nao a \ aolAM) _/<br>ICP ou CRVM<br>(ooAcompanhamento |//ierockvi(revascularizagao )<br>Ne ambulatorial yw, NG completa) D<br><!-- End of picture text -->  
52  
**2** **<u>IAM COM SUPRA ST</u>**  
Em pacientes submetidos à ICP primária, a estratificação adicional do risco pode ser feita após alta, durante atenção ambulatorial. Em pacientes não submetidos à ICP primária, é importante identificar precocemente pacientes de alto risco para intervir e prevenir eventos adicionais como reinfarto e morte. O paciente com IAMCSST submetido à trombólise química ou que não foi trombolisado pode ser submetido à coronariografia ou estratificação de risco não invasiva. Aqueles pacientes com critérios de alto risco descritos abaixo são os que mais se beneficiam da avaliação invasiva, principalmente quando realizada de forma precoce:  
- Instabilidade elétrica ou hemodinâmica;  
- Isquemia miocárdica recorrente;  
- Revascularização miocárdica prévia (ICP ou CRVM);  
- IAM anterior ou IAM inferior com acometimento de VD;  
- FEVE ≤ 40% ou Killip > I ou DM (principalmente se insulino‐requerente);  
O ecocardiograma deve ser realizado em 24 a 48h para a avaliação da função ventricular e do tamanho do IAM **_._**  
- A FEVE é o maior preditor independente de sobrevida no longo prazo.  
Em pacientes submetidos à ICP primária, a avaliação de isquemia residual pode ser feita ambulatorialmente, após 4 a 6 semanas, com um teste funcional **_._**  
Pacientes tratados com reperfusão química ou não trombolisados, deve ter estratificação de risco precoce e intra‐hospitalar:  
- Com características de alto risco devem ser submetidos à coronariografia **_._**  
- Sem características de alto risco podem ser submetidos à estratificação não‐ invasiva.  
53  
<!-- Start of picture text -->
(— \\<br>(IAM com supra ST ou BRE novo )<br>XX yy,<br><!-- End of picture text -->  
<!-- Start of picture text -->
ICP primariaN ><br>UZ<br><!-- End of picture text -->  
<!-- Start of picture text -->
Sim<br><!-- End of picture text -->  
<!-- Start of picture text -->
~<br>/‘neompankamento \<br>\ ambulatorial: )<br>Lem<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fluxograma para estratificacao<br>s . Pp ¢<br>de risco no IAMCSST<br><!-- End of picture text -->  
<!-- Start of picture text -->
Nao Outras<br>FEVE <40% caracteristicas de<br>sito riseo<br><!-- End of picture text -->  
<!-- Start of picture text -->
| Coronariografia ou<br>ere<br>Prova Funcional<br><!-- End of picture text -->  
<!-- Start of picture text -->
Nao<br><!-- End of picture text -->  
<!-- Start of picture text -->
a ><br>Coronariografia Squemiaprova miocarcicafuncional  na,<br>Nao<br>{/-(revascularizagaoICP ou CRVM da \ /neompannamento— ~ \<br>\ artériaartéria relacionadarelaci  ao | ( ambulatorial: }<br>KS IAM)/ XO y<br><!-- End of picture text -->  
<!-- Start of picture text -->
Coronariografia<br><!-- End of picture text -->  
<!-- Start of picture text -->
(ie—  ou CRVM—~ \<br>| (revascularizacioleta) }}<br>KS completa) /<br><!-- End of picture text -->  
54

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
1. Estabilidade hemodinâmica, elétrica, clínica e sem sinais de isquemia recorrente nas últimas 48 h;  
2. SCASSST não complicado após estratificação de risco (no mínimo 48 h);  
3. IAMCSST não complicado (sem arritmias, sangramento, isquemia, angina ou insuficiência cardíaca após evento) com reperfusão: no mínimo 72 h;  
4. IAMCSST anterior extenso, não reperfundido ou complicado: 5 a 7 dias.  
55

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
- **1) Ácido Acetilsalicílico**  
- 75 a 200mg/dia por tempo indeterminado para todos os pacientes **;**  
- Se houver hipersensibilidade ou intolerância gastrointestinal ao AAS, utilizar clopidogrel 75mg/dia **_._**  
##### **2) Clopidogrel**  
- IAMSSST  
- 75mg/dia por 9 meses;  
- Caso o paciente apresente risco de sangramento aumentado, o clopidogrel deve ser mantido por no mínimo 4 semanas.  
- IAMCSSST  
- Pacientes não submetidos à ICP (com ou sem terapia fibrinolítica), manter clopidogrel 75mg por no mínimo 4 semanas, podendo se estender por 9 meses;  
- Pacientes com implante de stent (convencional ou farmacológico), manter clopidogrel 75mg por 9 meses.  
-  
Diante da necessidade de continuação do tratamento, o estabelecimento hospitalar deverá entregar no dia da alta, 30 (trinta) comprimidos ao paciente até que seja adquirido pelo componente especial da assistência farmacêutica (CEAF).  
##### **3) Betabloqueador**  
- SCASSST ‐ Há benefício do uso por tempo indeterminado nos pacientes que evoluem com redução da FE com ou sem sinais clínicos de IC _,_ sendo também razoável para pacientes de baixo risco _._  
- SCACSST – Devem ser administrados por tempo indeterminado a todos os pacientes independentemente dos valores da pressão arterial e da FEVE _._ Exemplos:  
Sem disfunção ventricular:  
- Propranolol – dose inicial: 20mg 8/8h ou 40mg 12/12h; dose máxima: 160‐ 240mg/dia (a dose diária pode ser fracionada 12/12h ou 8/8h);  
- Atenolol – dose inicial: 25mg; dose máxima: 200mg/dia (a dose diária pode administrada em dose única ou ser fracionada 12/12h).  
- Com disfunção ventricular:  
- Carvedilol – dose inicial: 3,125 mg 12/12h; dose máxima: 25mg 12/12h (pacientes com peso corporal até 85kg) e 50mg 12/12h (pacientes com peso corporal > 85kg);  
- Succinato de Metoprolol – dose inicial: 12,5 – 25mg 1x/dia; dose máxima: 200mg/dia (a dose total diária pode ser dividida fracionada 12/12h).  
##### **4) IECA e BRA**  
- IECA deve ser administrado indefinidamente a todos pacientes que possuam DM, IC, HAS, doença renal crônica ou disfunção VE (FE <40%), desde que não exista contraindicação;  
56  
- A indicação do IECA indefinidamente a **todos** os pacientes independentemente da função VE e da pressão arterial não está tão fortemente embasada na literatura, especialmente para a SCASSST _;_  
- BRA deve ser prescrito na intolerância aos IECA e em casos de sinais clínicos e radiológicos de IC e disfunção VE (FE < 40%) _._  
Exemplos:  
- Captopril – dose inicial: 12,5mg 8/8h ou 25mg 8/8horas; dose máxima 50mg 8/8horas;  
- Enalapril – dose inicial: 5mg 12/12h ou 10mg 12/12h; dose máxima 20mg 12/12horas;  
- Losartan – dose inicial: 25mg/dia; dose máxima: 100mg/dia (a dose diária pode administrada em dose única ou ser fracionada 12/12h).  
##### **5) Nitratos**  
O benefício está restrito ao alívio dos sintomas isquêmicos. Uso crônico não está indicado se nos assintomáticos após otimização das doses de betabloqueador e IECA. Exemplos:  
- Mononitrato de isossorbida – dose inicial: 20mg às 8h e às 16 horas; dose máxima: 40mg às 8h e às 16 horas.  
##### **6) Terapia hipolipemiante (estatina)**  
É inequívoco o benefício do uso prolongado das estatinas na prevenção de morte e novos eventos isquêmicos nos portadores de DAC, especialmente após SCA, e independente dos valores basais do colesterol. Devem ser seguidas as orientações do MS para prevenção das doenças cardiovasculares (Prevenção clínica de doença cardiovascular, cerebrovascular e renal crônica, 2006, disponível no sítio _bvsms.saude.gov.br/bvs/publicacoes/abcad14.pdf_ ).  
##### **7) Anticoagulante oral (warfarina)**  
Em casos de fibrilação atrial, prótese valvar metálica, tromboembolismo pulmonar e trombo no VE. Warfarina 5mg/dia às 17h (respeitar 1hora de jejum antes e após a ingestão do comprimido), em adição a AAS e Clopidogrel, quando necessário. Deve‐se manter o RNI entre 2 ‐ 2,5 e utilizar baixa dose de AAS (75‐81mg) e de Clopidogrel (75mg/dia) _._  
##### **8) Antagonistas da aldosterona (espironolactona)**  
Nos pacientes com FE < 40% e sinais de IC ou DM, se a creatinina for < 2,5mg/dL em homens e 2,0mg/dL em mulheres e K < 5,0mmol/L **_._** Espironolactona – dose: 25mg/dia em tomada única. Não há nenhum benefício de doses acima de 25mg/dia na IC. Se a monitorização freqüente dos níveis séricos de potássio não for factível, o risco de hipercalemia pode ser maior do que o benefício do uso crônico da espironolactona, especialmente em pacientes idosos e naqueles com níveis séricos de creatinina > 1,6mg/dL.  
57  
**CUIDADOS NO PÓS‐ALTA**  
##### **RETORNO AS ATIVIDADES PROFISSIONAIS E SEXUAIS:**  
|ATIVIDADES|
|---|
|Retorno às atividades sexuais em pacientes de baixo risco, estáveis, em 7‐10 dias após a alta<br>hospitalar.|
|Retorno às atividades sexuais em pacientes de risco intermediário, estáveis, em 7‐10 dias<br>após estabilização doquadro.|
|Retorno às atividades físicas: pacientes que estejam assintomáticos após IAM não<br>complicadopodem retornar a suas atividades após 2‐4 semanas,com avaliação cardiológica.|
|Recomendado teste ergométricopara orientarprescrição do exercício.|
|Todos pacientes devem ser encorajados a realizar 30 a 60 min. de atividade aeróbia em<br>intensidade moderada,no mínimo 5 vezespor semana.|
|A direção de veículos pode ser permitida após 1 semana nos pacientes sem complicações e 2<br>a 3 semanas empacientes com IAM complicado.|  
58  
- **PLANO DE CUIDADOS – O SEGUIMENTO NA ATENÇÃO PRIMÁRIA Reabilitação Cardíaca** O principal foco da reabilitação é o exercício físico de caráter educacional, mais  
- **1.** complexo que um mero programa de condicionamento físico. Recomendada reabilitação supervisionada por médico em casos de alto risco. **Atividade Física** Todos pacientes devem ser encorajados a realizar 30 a 60 min. de atividade aeróbia em  
- **2.** intensidade moderada, no mínimo 5 vezes por semana, além de aumentar o gasto energético diário (ex: atividades domésticas, jardinagem). Recomendado teste ergométrico para orientar prescrição do exercício. **Retorno ao Trabalho** Pacientes que freqüentam programas de RC após alta retornam ao trabalho antes.  
- **3.** Na maior parte das vezes, o stress sofrido no trabalho é menor que o medido no teste de esforço, reforçando que o retorno ao trabalho deve ser encorajado. **Outras Atividades** Orientação quanto ao retorno às diversas atividades pode ser feita utilizando‐se a capacidade funcional em MET do paciente obtida através de teste ergométrico e da tabela com informações sobre a exigência metabólica de cada uma das atividades.  
- **4.** Atividade sexual com parceiro habitual pode ser reassumida em 7‐10 dias em pacientes sem complicações durante a internação. A direção de veículos pode ser permitida após 1 semana nos pacientes sem complicações e 2 a 3 semanas em pacientes com IAM complicado (arritmias, IC). **Dieta**  
- **5.** Pacientes devem ser encorajados a reduzir a ingesta diária de sal, gorduras saturadas, <u>gorduras trans e colesterol, e aumentar a frutas, vegetais e peixes.</u> **Perda de peso**  
- **6.** Peso corporal e circunferência abdominal devem ser medidos em todas as consultas. Os pacientes devem ser encorajados a atingir e manter IMC entre 18,5 – 24,9 Kg/m<sup>2</sup> e a circunferência abdominal < 102 em homens e < 88 cm em mulheres. **Cessação do tabagismo**  
- **7.** Em todas as consultas o paciente deve ser questionado sobre tabagismo e deve ser estimulado a abandoná‐lo e a evitar o tabagismo passivo. **Pacientes diabéticos**  
- **8.** Modificações do estilo de vida, controle dos demais fatores de risco (HAS, obesidade, dislipidemia) e medicação visando glicohemoglobina ≤ 7% _._  
**9. Portadores de HAS**  
- Modificações do estilo de vida e medicação objetivando PA ≤ 130/80 mmHg.  
**10. Vacina Influenza** Todos os pacientes devem ser vacinados contra Influenza anualmente. **Terapia de reposição hormonal**  
**11.** Não deve ser prescrita para prevenção secundária de eventos coronarianos Não deve ser reiniciada nas pacientes que já eram usuárias _._ **Evitar o uso de antiinflamatórios não‐esteróides** Dores musculoesqueléticas devem ser tratadas com analgésicos do tipo paracetamol e  
**12.** narcóticos de curta ação em pequenas doses; Se não houver melhora, pode‐se utilizar AINE não seletivo – naproxeno _._ O uso de AINEs com alta seletividade pela COX‐2 deve ser restrito a falência terapêutica com as terapias anteriores.  
59

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
||**SUGESTÃO  DE  INDICADORES A SEREM UTILIZADOS PELOS GESTORES**|
|---|---|
||**ESTRUTURA**|
|**1.**|Atendimento pré‐hospitalar:<br>1.1 Número de ambulâncias com ECG;<br>1.2 Número de profissionais habilitados para realização de ECG;<br>1.3 Número deprofissionais habilitados a diagnosticar a SCACSST ao ECG.|
|**2**|Pronto atendimento: protocolos implementados para a rápida identificação dos pacientes com<br>SCA.|
|**3.**|Conduta hospitalar: Quantitativo de médicos, enfermeiros, fisioterapeutas e técnicos com<br>treinamento e conhecimento para o cuidado do paciente conforme protocolo e POPs, a partir<br>do número de casos esperados.|
|**4.**|Planejamento da alta hospitalar: Existência de protocolos de alta hospitalar incluindo<br>encaminhamentopara reabilitação cardíaca.|
||**PROCESSO**|
||**Indicadores não farmacológicos**|
|**5.**|Eletrocardiograma realizado em 10 minutos após a entrada no hospital.|
|**6.**|ICP primária em 90 minutos após a entrada no hospital.|
|**7.**|Terapia de reperfusão em pacientes elegíveis com IAMCSST.|
|**8.**|Estratificação de risco: cateterismo cardíaco, teste ergométrico, cintilografia miocárdica ou<br>ecocardiograma de estresse.|
|**9.**|Avaliação da função ventricular esquerda, preferencialmente por Ecocardiograma.|
|**10.**|Aconselhamento para cessação do tabagismo.|
|**11.**|Número de pacientes em reabilitação cardíaca pós‐infarto.|
||**Indicadores farmacológicos**|
|**12.**|Terapia fibrinolítica administrada entre 30 minutos da entrada do hospital.|
|**13.**|Administração de AAS na entrada do hospital.|
|**14.**|Prescrição de AAS na alta hospitalar.|
|**15.**|Prescrição de estatina na alta hospitalar.|
|**16.**|Prescrição de betabloqueador na alta hospitalar.|
|**17.**|Prescrição de IECA ou BRA na alta hospitalar.|
||**RESULTADO**|
|**18.**|Mortalidade hospitalar.|  
60  
|**Bib**<br>**1.**|**liografia**<br>Nicolau JC, Timerman A, Piegas LS, et al. Guidelines for Unstable Angina and Non‐ST‐Segment Elevation<br>Myocardial Infarction of the Brazilian Society of Cardiology (II Edition, 2007). Arq Bras Cardiol 2007; 89<br>(4): e89‐e131.|
|---|---|
|**2.**|Piegas LS, Feitosa‐Filho GS, Mattos LA, et al. Diretriz da Sociedade Brasileira de Cardiologia sobre<br>Tratamento do Infarto Agudo do Miocárdio com Supradesnível do Segmento ST. Arq Bras.Cardiol. 93(6<br>supl.2),e179‐e264. 2009|
|**3.**|Junqueira LL, Ribeiro AL, Mafra AA, et al.  Secretaria de Estado de Saúde de Minas Gerais. Protocolo<br>Clínico sobre Síndrome Coronariana Aguda. Belo Horizonte 2011. 49p.|
||Antman EM, Anbe DT, Armstrong PW et al. ACC/AHA guidelines for the management of patients with ST‐<br>elevation myocardial infarction; A report of the American College of Cardiology/American Heart|
|**4.**|<br>Association Task Force on Practice Guidelines (Committee to Revise the 1999 Guidelines for the<br>Management ofpatients with acute myocardial infarction). J Am Coll Cardiol 2004;44(3):E1‐E211.|
|**5.**|Van de Werf, Bax J, Betriu A, et al. ESC Guidelines for Management of Acute Myocardial Infarction in<br>Patients Presentingwith Persistente ST Segment Elevation. Eur Heart J.2008. 29,2909‐2945.|
||Hasdai D, Behar S, Wallentin L, et al. A prospective survey of the characteristics, treatments and|
|**6.**|<br>outcomes of patients with acute coronary syndromes in Europe and the Mediteterranean Basin. The<br>Euro Heart Surveyof Acute CoronarySyndromes. Eur Heart J 2002 23,1190–201.|
|**7.**|Eagle KA, Lim MJ, Dabbous OH, et al. GRACE Investigators. A validated prediction model for all forms of<br>acute coronary syndrome: estimating the risk of 6‐month postdischarge death in an international<br>registry. JAMA. 2004;291(22):2727‐33.|
|**8.**|Antman EM, Hand M, Armstrong PW et al. 2007 focused update of the ACC/AHA 2004 guidelines for the<br>management of patients with ST‐elevation myocardial infarction: a report of the American College of<br>Cardiology/American Heart Association Task Force on Practice Guidelines. J Am Coll Cardiol<br>2008;51(2):210‐247|
|**9.**|Erhardt L, Herlitz J, Bossaert L, et al.; Task Force on the management of chest pain. Task force on the<br>management of chestpain. Eur Heart J. 2002 Aug;23(15):1153‐76.|
|**10.**|Smith Jr SC, Kushner FG, Hand M, et al. 2009 Focused Updates : ACC/AHA Guidelines for the<br>management of  Patients with ST‐Elevation Myocardial Infarction and ACC/AHA/SCAI Guidelines on<br>Percutaneous CoronaryIntervention. J Am Coll Cardiol  2009;54(23): 2005‐41.|
|**11.**|Keeley EC, Boura JA, Grines CL. Primary angioplasty versus intravenous thrombolytic therapy for acute<br>myocardial infarction: aquantitative review of 23 randomised trials. Lancet 2003;361(9351):13‐20.|
|**12.**|Terkelsen CJ, Sorensen JT, Maeng M et al. System delay and mortality among patients with STEMI treated<br>withprimary percutaneous coronaryintervention. JAMA 2010;304(7):763‐771.|
|**13.**|Ting HH, Yang EH, Rihal CS. Narrative review: reperfusion strategies for ST‐segment elevation myocardial<br>infarction. Ann Intern Med 2006;145(8):610‐617.|
|**14.**|Scottish Intercollegiate Guidelines Network (SIGN). Acute Coronary Syndromes. 2007.|
|**15.**|Wright RS, Anderson JL, Adams CD, et al. 2011ACCF/AHA Focused Update of the Guidelines for the<br>Management of Patients With Unstable Angina/Non‐ST‐Elevation Myocardial Infarction (Updating the<br>2007 Guideline).J Am Coll Cardiol 2011;57(19):1920‐59|
|**16.**|<br>Fox KAA, Dabbous OH, Goldberg RJ, et al., for the GRACE Investigators. Prediction of risk of death and<br>myocardial infarction in the six months after presentation with acute coronary syndrome: prospective<br>multinational observational study (GRACE). Br Med J 2006;333:1091‐4.|
|**17.**|Antman EM, Cohen M, Peter J, et al. The TIMI Risk score for Unstable Angina /Non‐ST ElevationMI. A<br>Method for Prognostication and Therapeutic Decision Making.JAMA 2000;284(7).|
|**18.**|David A,  Morrow DA, Antman MA et al. TIMI Risk Score for ST‐Elevation Myocardial Infarction: A<br>Convenient,Bedside,Clinical Score for Risk Assessment at Presentation. Circulation. 2000;102:2031‐2037|
|**19.**|Ministério da Saúde.  Prevenção clínica de doença cardiovascular, cerebrovascular e renal crônica.<br>Cadernos de Atenção Básica,n.14. Brasília: 2006. 56p._bvsms.saude.gov.br/bvs/publicacoes/abcad14.pdf_|  
61  
<u>ANEXO 1:  ESCORE GRACE para estratificação de risco na SCA (SSST e CSST)</u>  
|**Características à admissão**||
|---|---|
|Anos|Pontos|
|1 ‐ Idade<br>< 30|0|
|30 ‐ 39|8|
|40 ‐ 49|25|
|50 ‐ 59|41|
|60 ‐ 69|58|
|70 ‐ 79|75|
|80 ‐ 89|91|
|≥ 90|100|
|bpm|Pontos|
|2 ‐ Frequência Cardíaca<br>< 50|0|
|50 ‐ 69|3|
|70 ‐ 89|9|
|90 ‐ 109|15|
|110 ‐ 149|24|
|150 ‐ 199|38|
|> 200|46|
|mmHg|Pontos|
|3 ‐ Pressão Arterial Sistólica<br>< 80|58|
|80 ‐ 99|53|
|100 ‐ 119|43|
|120 ‐ 139|34|
|140 ‐ 159|24|
|160 – 199|10|
|> 200|0|
|mg/dL|Pontos|
|4 ‐ Creatinina<br>0,0 ‐ 0,39|1|
|0,4 ‐ 0,79|4|
|0,8 ‐ 1,19|7|
|1,2 ‐ 1,59|10|
|1,6 ‐ 1,99|13|
|2,0 ‐ 3,99|21|
|> 4|28|
||Pontos|
|5 ‐ Classificação de Killip<br>I|0|
|II|20|
|III|39|
|IV|59|
|6 ‐ Elevação de enzimas cardíacas|14|
|7 ‐ Desvio do segmento ST (infra ou supra)|28|
|8 ‐ Parada cardiorrespiratória|39|  
|**TOTAL**|
|---|
|_Somatória de cada um dos 8 itens_|  
|Escore<br>Grace|Óbito<br>hospitalar|Escore<br>Grace|Óbito<br>hospitalar|
|---|---|---|---|
|≤ 80|≤ 0,4%|170|7,3%|
|90|0,6%|180|9,8%|
|100|0,8%|190|13%|
|110|1,1%|200|18%|
|120|1,6%|210|23%|
|130|2,1%|220|29%|
|140|2,9%|230|36%|
|150|3,9%|240|44%|
|160|5,4%|≥ 250|≥ 52%|  
62  
<u>ANEXO 2: ESCORE TIMI</u>

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
|**Histórico**||||
|---|---|---|---|
||||Pontos|
|1 – Idade > 65 an|os||1|
|2 – ≥ 3 fatores<br>familiar DAC, DM|risco DAC (tabagi<br>, HAS)|smo, dislipidemia, história|1|
|3 – DAC conheci|da (estenose coron|ária > 50%)|1|
|4 – Uso AAS nos|últimos 7 dias||1|
|**Apresentação**||||
|5 – Recorrência|dos sintomas (≥2|episódios nas últimas 24h)|1|
|6 – Elevação MN|M||1|
|7 – Desvio segm|ento ST ≥ 0,5 mm||1|
|**TOTAL**|||**7**|
|<br>_Somatória de ca_<br>|_da um dos 7 itens_<br>Eventos cardí|acos maiores em 14 dias<br>|<br>Risco de|
|Pontos|Óbito / IAM|Óbito / IAM /<br>revascularização urgente|eventos|
|0 ‐ 1|3%|5%|Baixo|
|2|3%|8%||
|3|5%|13%|Intermediário|
|4|7%|20%||
|5|12%|26%|Alto|
|6 ‐ 7|19%|41%||  
63

---

<!-- METADADOS: doenca: Linha de Cuidado do Infarto Agudo do Miocárdio e o Protocolo de Síndromes Coronarianas Agudas | secao: **SÍNDROMES CORONARIANAS AGUDAS** -->
<!-- Start of picture text -->
Escore<br>Pontos<br>Idade<br>≥ 75 anos  3<br>65 – 74 anos  2<br>História de diabetes, hipertensão ou angina 1<br>Exame físico<br>PAS < 100 mmHg  3<br>FC > 100 bpm  2<br>Classe Killip II‐IV  2<br>Peso < 67 kg 1<br>Supradesnível do segmento ST anterior ou BCRE 1<br>Tempo para terapia de reperfusão > 4 horas 1<br>TOTAL  14<br>Pontos  Mortalidade intra‐hospitalar (%) Risco<br>0 0,7<br>1 0,3 Baixo<br>2 1,9<br>3 3,9<br>Intermediário<br>4 6,5<br>5 11,6<br>6 14,7<br>7 21,5 Alto<br>8 24,4<br>>8 31,7<br><!-- End of picture text -->  
64

---

