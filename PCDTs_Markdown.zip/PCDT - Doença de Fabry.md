<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 2, DE 15 DE JANEIRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Fabry.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE SUBSTITUTO, no uso das atribuições que lhe confere o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença de Fabry no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação da Conitec nº 923/2024 e Registro de Deliberação nº 920/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença de Fabry.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Doença de Fabry, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença de Fabry.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS nº 20, de 06 de dezembro de 2021, publicada no Diário Oficial da União (DOU) nº 245, de 29 de dezembro de 2021, seção 1, página 171.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
1

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
A Doença de Fabry (DF), também conhecida como doença de Anderson Fabry, é um erro inato do metabolismo (EIM), uma esfingolipidose, de herança ligada ao X (Xq22.1), ocasionada pela deficiência da enzima lisossômica α-galactosidase A (αGAL-A). Mutações no gene _GLA_ , que codifica a proteína α-galactosidase A (GLA, 300644), levam à deficiência da enzima lisossômica αGAL-A<sup>1,2</sup> .  
A DF é a glicoesfingolipidose mais comum no mundo. A incidência de indivíduos hemizigotos para a doença situa-se em 1 para cada 117.000 indivíduos nascidos vivos<sup>3,4</sup> . A sua prevalência é estimada entre 0,21 a 0,85 casos por 100.000 habitantes, em estudos realizados no Reino Unido, Austrália, Nova Zelândia e Países Baixos<sup>5</sup> . No entanto, a maioria destes estudos não considera as mulheres acometidas pela DF, visto que as manifestações clínicas são muito variáveis e o diagnóstico pela dosagem da αGAL-A não é um bom indicador neste grupo. Assim, as mulheres são identificadas apenas quando um paciente masculino é diagnosticado na família. No Brasil, não há estudos sobre incidência ou prevalência da DF.  
A DF tem um alto grau de penetrância em homens, sendo que quase 100% deles apresentam complicações da doença. Já em mulheres, a penetrância é considerada intermediária e em torno de 50 a 70% das mulheres com mutações no gene apresentam manifestações de DF<sup>6</sup> .  
A deficiência da αGAL-A, por sua vez, leva ao acúmulo de glicoesfingolipídios, principalmente a globotriaosilceramida (GL-3 ou Gb3), em todo o organismo. Esta alteração genética manifesta-se em todos os subtipos celulares, mas o grau de envolvimento varia muito entre os diferentes tipos de células e órgãos, refletindo a heterogeneidade das taxas de metabolismo de esfingolipídios nas células e tecidos do nosso corpo<sup>3-7</sup> .  
A GL-3 acumula-se, especialmente, nas células do epitélio renal, nas células endoteliais vasculares, células do músculo liso, cardiomiócitos e neurônios do sistema nervoso autônomo. Assim, as manifestações clínicas decorrentes do acúmulo de GL3 ocorrem principalmente no endotélio vascular da pele, coração, fígado, rins e sistema nervoso central (SNC). Pode, ainda, haver alterações auditivas, vestibulares, oftalmológicas e do trato gastrointestinal<sup>3-8</sup> .  
A doença é sistêmica e se manifesta com insuficiência renal, doença cardíaca, doença cerebrovascular, neuropatia periférica, perdas sensoriais, perda auditiva, lesões de pele típicas (angioqueratomas), distúrbios gastrointestinais, como diarreia e dor abdominal<sup>7,9</sup> . Outros achados comuns são córnea verticilada (opacidade corneana assintomática); hipo ou anidrose; intolerância ao calor, ao frio e ao exercício<sup>7,10,11</sup> . A manifestação mais comum da DF é a neuropatia dolorosa, incluindo as acroparestesias intermitentes, as denominadas “crises de Fabry”, com dor aguda que dura de horas a dias. Os achados neuropatológicos indicam que a dor é resultado da neurodegeneração das fibras nervosas das raízes dos gânglios dorsais, associadas à degeneração axonal das fibras curtas<sup>7,12</sup> .  
A DF é dividida nas formas clássica e tardia. Na forma clássica, a mais frequente, os sinais e sintomas se iniciam na infância ou adolescência e evoluem progressivamente até a vida adulta. Nesta, os pacientes iniciam com acroparestesias entre os 5 e 10 anos de idade e na maioria deles, quando adultos, desenvolvem doenças renal e cardíaca graves. Já na forma tardia, os sintomas iniciam no início da vida adulta e podem evoluir gradativamente<sup>7</sup> .  
As alterações cardíacas podem incluir hipertrofia ventricular esquerda (HVE), doença valvular (particularmente, insuficiência mitral), doença arterial coronariana e anormalidades de condução, levando com o tempo à insuficiência cardíaca,  
2  
arritmias e infarto agudo do miocárdio<sup>13</sup> . O envolvimento dos podócitos nos glomérulos renais leva a proteinúria e hematúria, geralmente detectadas na adolescência<sup>7</sup> . O comprometimento desses diferentes órgãos e sistemas tem, frequentemente, um caráter evolutivo. Assim sendo, entre a terceira e quinta décadas de vida, a maioria dos indivíduos apresenta doença renal, com necessidade de diálise e transplante e doença cardíaca grave<sup>14</sup> .  
A doença cerebrovascular também é frequente nesta população, apresentando-se com lesões na substância branca, paresias, vertigem, acidente vascular encefálico (AVE) precoce e ataques isquêmicos transitórios (AIT). Não se sabe ao certo o tempo necessário até a evolução para os sintomas e lesões nos órgãos-alvo<sup>7,13</sup> . As insuficiências renal e cardíaca juntas representam as principais causas de morbidade e mortalidade nestes indivíduos e contribuem para redução da expectativa de vida, que é de cerca de 50 anos nos homens e 70 anos nas mulheres<sup>14,15</sup> .  
Em mulheres heterozigotas, o espectro das manifestações varia desde assintomático à doença grave. Algumas mulheres podem apresentar sintomas já na infância e adolescência (como dor) e, na idade adulta, desenvolver HVE, cardiomiopatia, doença cerebrovascular e, mais raramente, doença renal<sup>16-19</sup> . Comparadas aos homens com mutações semelhantes, de uma forma geral, as mulheres apresentam manifestações clínicas menos graves e com início mais tardio<sup>17-20</sup> .  
Devido à natureza inespecífica dos sintomas, os pacientes com DF recebem este diagnóstico geralmente muito após o início dos mesmos. Estudos demonstram<sup>21-24</sup> que a média de tempo entre o surgimento dos primeiros sintomas e o diagnóstico da DF é, em homens, de 13,7 anos e, em mulheres, de 16,3 anos.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado  
dá à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
- E75.2 Outras esfingolipidoses

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
Os primeiros sintomas da DF clássica surgem durante a infância e incluem dor neuropática crônica e crises de dor episódica intensa<sup>26-29</sup> . As manifestações iniciais mais comuns são hipoidrose (diminuição do suor) e angioqueratomas (lesões cutâneas vasculares que se desenvolvem lentamente como grupos de angiectasias individuais e punctatas, vermelho-escuras a azul-escuras que não se modificam com a pressão digital). Usualmente, os angioqueratomas localizam-se na região compreendida entre o umbigo e os joelhos (quadris, costas, coxas, nádegas, pênis e escroto), mas também podem aparecer na mucosa oral ou na conjuntiva<sup>30-32</sup> . Também acontecem distúrbios gastrointestinais (dor, distensão abdominal e diarreia) e a chamada córnea verticilata<sup>30-32</sup> , a qual deve levantar alto grau de suspeição da doença, já que é encontrada em quase todos os pacientes masculinos com DF e em 70% a 90% das pacientes do sexo feminino<sup>11,28</sup> . Frequentemente, as complicações em órgãos alvo manifestam-se na forma de alterações em exames complementares em pacientes adolescentes ou adultos jovens<sup>15,29-31</sup> .  
Na forma de início tardio, as manifestações variam de acordo com o nível de atividade residual da αGAL-A. Nestes pacientes, sintomas cardíacos como HVE, arritmia, anormalidades na ressonância magnética cardíaca e diminuição da taxa de filtração glomerular estão presentes na quarta à sétima décadas de vida, refletindo o início tardio e a progressão mais lenta da doença<sup>15,28,29</sup> . Mulheres heterozigotas, com formas graves, têm quadro semelhante ao observado em homens com a forma clássica  
3  
da doença<sup>15</sup> . O **Quadro 1** resume os principais sinais e sintomas iniciais da DF e a idade em que estes surgem mais frequentemente.  
**Quadro 1** - Sinais e sintomas iniciais da doença de Fabry.  
|**Sinais e sintomas**|**Frequência**|**Mediana de idade de início**|
|---|---|---|
|Dor|66%|Meninos: 10, 1 anos (7,2 anos)|
|Disestesia/crise episódica de<br>queimação nas mãos ou nos pés|(67% meninos, 65% meninas)|Meninas: 15 anos (8,3 anos)|
|Redução da sudorese|59%|Hipoidrose|
|Hipoidrose ou anidrose|(93% meninos, 25% meninas)|Meninos: 10,1 anos<br>Meninas: 4,2 anos<br>Anidrose<br>Meninos: 7,8 anos<br>Nenhum caso para meninas|
|Sinais da córnea|50,8%|Meninos: 12,1 anos|
|Córnea verticilata|(36,1% meninos, 65,5% meninas)|Meninas: 8,9 anos|
|Sintomas gastrointestinais|17,9%|Meninos: 5 anos|
|Náusea, vômito, dor abdominal<br>inespecífica, constipação intestinal,<br>diarreia|(23,2% meninos, 11,4% meninas)|Meninas: 9,5 anos|
|Calor, frio e intolerância ao exercício|Calor: 38,4% (38,9% meninos, 37,9%<br>meninas)<br>Frio: 17% (16,7% meninos, 17,2%<br>meninas)|Calor<br>Meninos: 7,4 anos<br>Meninas: 15,7 anos<br>Frio (mediana):<br>Meninos: 5,0 anos<br>Meninas: 7,7 anos|
|Problemas de audição|Perda auditiva confirmada: 21,8%|Zumbido|
|Perda auditiva, zumbido e vertigem|(19,4% meninos, 24,1% meninas)<br>Zumbido: 40% (22,2% meninos, 41,3%<br>meninas)<br>Vertigem: 30,4% (19,4% meninos,<br>41,4% meninas)|Meninos: 10 anos<br>Meninas: 13,9 anos<br>Vertigem<br>Meninos: 11,8 anos<br>Meninas: 13,4 anos<br>Perda auditiva<br>Meninos: 2,7 anos<br>Meninas: 14,4 anos|
|Angioqueratomas|14,2%|Mediana:|  
4  
|**Sinais e sintomas**|**Frequência**|**Mediana de idade de início**|
|---|---|---|
||(19,6% meninos, 7,6% meninas)|Meninos: 9,1 anos<br>Meninas: 14,4 anos|
|Sinais renais<br>Hiperfiltração, albuminúria patológica,<br>proteinúria|Hiperfiltração: desconhecido<br>Microalbuminúria: 13,2%<br>Proteinúria: 19,7%|Microalbuminúria<br>Meninos: 16,5 anos<br>Meninas: 15,9 anos|
|||Proteinúria<br>Meninos: 13,8 anos<br>Meninas: 14,1 anos|
|Sinais cardíacos<br>Anormalidades de condução,<br>disfunção valvar, arritmias|Anormalidades de condução: 7,6%<br>(8,3% meninos, 6,9% meninas)<br>Disfunção valvar: 14,9% (5,6%<br>meninos, 24,1% meninas)|Anormalidades de condução<br>Disfunção valvar<br>Meninos: 8,6 anos<br>Meninas: 14,4 anos|
||Arritmias: 4,9% (7,3% meninos, 2,5%<br>meninas)|Arritmias Meninos de 9,3 anos|  
Nota: Microalbuminúria representa uma quantidade de albumina entre 30 a 300 mg, na urina de 24 horas. Já a albuminúria corresponde a valores maiores que 300 mg/24 horas. Fonte: Adaptado de Germain et al, 2019<sup>28</sup> .  
Entretanto, nenhuma das características da DF clássica é diagnóstica por si só. Algumas características, como nefropatia e cardiomiopatia, são muito inespecíficas e com um amplo diagnóstico diferencial. Assim, a avaliação de diagnóstico diferencial é essencial nestes pacientes e, por esta razão, os achados clínicos (sinais ou sintomas) não podem ser usados para confirmar o diagnóstico da DF<sup>31,33</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: Geral -->
O diagnóstico de DF geralmente é tardio, ainda que muitas manifestações se iniciem na infância ( **Quadro 1** ). Como os sintomas geralmente não são específicos e o reconhecimento e conscientização sobre as doenças raras são em geral baixos entre os médicos, pode haver atraso no diagnóstico<sup>27,28</sup> . Crianças necessitam de atenção, pois é nessa faixa etária que se iniciam as disfunções celulares que levarão às alterações orgânicas renais, cardíacas e microangiopáticas, que na fase adulta causarão grande morbimortalidade<sup>27,28</sup> .  
A dor é o sintoma mais marcante nas crianças que têm DF, muitas vezes associada com fadiga, ansiedade, depressão e faltas escolares, já que as manifestações gastrointestinais gerais são comuns nessa faixa etária<sup>29</sup> . Os meninos com DF clássica apresentam sintomas mais precocemente, com impacto na qualidade de vida<sup>27</sup> . As manifestações clínicas em meninas geralmente são mais leves e tardias, mas também podem estar associadas ao mesmo quadro clínico de DF clássica manifestado no sexo masculino<sup>28,29</sup> . O diagnóstico e o tratamento precoces são prioritários para diminuir as lesões em órgãos-alvo, a morbidade e a mortalidade<sup>27-31</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
5  
Como as manifestações da DF são múltiplas, o diagnóstico diferencial deve considerar diversas doenças e condições como, por exemplo, doenças reumatológicas (febre reumática e artrite); doenças neuropsicológicas; fibromialgia; dermatomiosite; neuropatia por outras doenças genéticas (amiloidose e doenças mitocondriais); neuropatia por doenças metabólicas (diabete melito); esclerose múltipla; leucoencefalopatia de causa não especificada; vasculite sistêmica ou do sistema nervoso central; Acidente Vascular Cerebral (AVC) juvenil criptogênico; AVC juvenil associado a outros fatores de risco conhecidos; eritromelalgia; teleangiectasia hemorrágica hereditária; doença de Ménière; síndrome do intestino irritável; cardiomiopatia hipertrófica idiopática e insuficiência renal de causa desconhecida<sup>22,23,28-34</sup> . O uso de cloroquina ou amiodarona pode causar anormalidades corneanas idênticas à córnea verticilata<sup>28</sup> e a exposição ao pó de silicone pode levar à nefropatia clínica, similar à observada na DF. Os angioqueratomas também podem ser encontrados em outras doenças de acúmulo lisossômico, tais como manosidose, fucosidose, sialidose e deficiência de betagalactosidase<sup>7,9</sup> .  
Com o aumento da faixa etária e progressão da vasculopatia sistêmica, consequentemente, ocorre aumento na frequência de complicações cardíacas, renais e risco de AVC isquêmico. Naqueles sem diagnóstico de DF, estes sintomas podem ser interpretados pelos profissionais de saúde como morbidades associadas ao envelhecimento<sup>7,10,33</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
O diagnóstico da DF difere em pacientes do sexo masculino e feminino, devido às particularidades da doença cada um: **Sexo masculino:** medida da atividade da enzima αGAL-A em plasma ou leucócitos a partir do sangue periférico ou cultura de fibroblastos<sup>4-37</sup> . Na maior parte das vezes, indivíduos do sexo masculino com DF não têm atividade residual da enzima ou a tem muito baixa (≤ 5% dos valores normais). Casos suspeitos, com atividade superior a 5% dos valores normais, deverão ter seu diagnóstico confirmado por análise molecular<sup>37,38</sup> .  
A análise de ácido desoxirribonucleico (DNA), com a identificação de mutações específicas, de caráter reconhecidamente patogênicas, no gene da αGAL-A, pode ser considerada inicialmente como o método de diagnóstico de escolha em indivíduos do sexo masculino, em centros nos quais este método esteja acessível (a realização da análise para identificação das mutações é recomendada quando houver disponibilidade, mesmo naqueles casos do sexo masculino com atividade enzimática≤ 5%)<sup>38</sup> .  
**Sexo feminino:** como as doentes podem ter um espectro de atividade enzimática que varia de muito baixo a normal<sup>39</sup> , é necessária a identificação de mutações específicas no gene da αGAL-A<sup>37</sup> . Os níveis de GL-3 plasmáticos ou no sedimento urinário de 24 horas geralmente estão aumentados e podem ser úteis no diagnóstico<sup>37,39</sup> . Entretanto, em alguns pacientes com mutações específicas (por exemplo, a mutação p.N215S), tais alterações bioquímicas podem não ocorrer<sup>38,39</sup> . Além disso, a quantificação de GL-3 não é amplamente disponível, mesmo internacionalmente.  
Em alguns casos, achados histopatológicos de biópsias em diferentes tecidos de indivíduos com DF (por exemplo rim ou pele) podem ser úteis, já que há achados característicos que consistem na presença de vacúolos citoplasmáticos contendo os lipídeos acumulados. À microscopia eletrônica, observa-se a presença de inclusões lisossômicas, com a configuração lamelar concêntrica, chamados de corpos de inclusão zebra-similar<sup>10,40</sup> . Por tratar-se de uma doença de herança ligada ao X, a detecção do probando (caso-índice) torna obrigatória a investigação de outros membros da família e o aconselhamento genético<sup>40</sup> .  
A **Figura 1** mostra o algoritmo de investigação diagnóstica laboratorial e molecular recomendada para indivíduos com sinais ou sintomas sugestivos da DF, com achados laboratoriais indicativos da DF ou com história familiar sugestiva ou comprovada da DF<sup>33,41</sup> .  
O diagnóstico da DF é, portanto, uma combinação de aspectos clínicos, laboratoriais e moleculares, conforme consenso sobre DF<sup>26,40,41</sup> , apresentado no **Quadro 2**  
6  
**Figura 1 -** Algoritmo com exames laboratoriais e/ou moleculares para diagnóstico da DF de acordo com achados, histórico e sexo do caso suspeito. Adaptado de Laney _et al_ , 2013<sup>**41**</sup>  
<!-- Start of picture text -->
Pacientes com achados clinicos, historia clinica, achados<br>jaboratoriais ou historia familiar sugestiva de DF<br>| Paciente masculino | Paciente feminino<br>| 7 Paciente tem historia. Nao:<br>Medi atividade da enzima oGAL-Aem plasma, | familiar: com mutac3o ‘Sequenciamento do<br>leucOcitos ou cultura de fibroblastos seeaGAL-Ajé aa gene aGAL-A<br>——#§_,{ a Identiicada?<br>Paciente com atividade Paciente com atividade | sim<br>normal da aGAL-A Geficiente da GGAL-A Siecpioncontonts chan<br>8 mutaco familiar<br>Paciente ndo possui N30 Dautaeee.5<br>doenca de Fabry encontrada<br>‘Sim<br>Paciente afetado pela<br>doenga de Fabry<br><!-- End of picture text -->  
Adaptado de Laney _et al_ , 2013<sup>**41**</sup>  
**Quadro 2.** Critérios clínicos, laboratoriais e moleculares para diagnóstico definitivo de DF.  
|**Pacientes**|**Masculinos**|**Pacientes**|**Femininos**|
|---|---|---|---|
|Presença de mutação patogênic<br>patogênica no gene αGAL-A<br>+|a ou provavelmente|Presença de mutação patogêni<br>patogênica no gene αGAL-A<br>+|ca ou provavelmente|
|Deficiência da enzima αGAL-<br>+<br>A ou B ou C ou D*****|A (atividade ≤5%)|Mensuração da enzima αGAL|-A desnecessária|
|**A (clínica)**|**B (bioquímica)**|**C (familiar)**|**D (histológica)**|
|Presença de um ou mais: dor<br>neuropática, córnea<br>verticillata, angioqueratoma.|Elevação plasmática ou<br>urinária GL-3 ou liso-GL-3*****<br>(> 1,8 ng/mL).|Membro da família com<br>diagnóstico definitivo de DF<br>portando a mesma mutação.|Alterações histológicas<br>sugestivas de depósitos<br>lisossomais em órgãos-alvo<br>(rins, pele, coração).|
|Legenda: DF (doença de Fabry); α-GAL|(α-galactosidase A); GL-3 (globotriaos|ilceramida); liso-GL-3 (globotriaosilesf|ingosina)|  
7  
**Nota 1:** Há pacientes do sexo masculino com mutação patogênica, atividade da enzima α-GAL ≤ 5%, mas sem presença de nenhum critério A/B/C/D.  
**Nota 2:** A despeito dos critérios A, B, C, D estarem na tabela abaixo da atividade enzimática e alterações do gene, é importante ressaltar que na maioria dos pacientes estes antecedem a suspeita e, portanto, a realização estes exames. Casos sem sintomas (no sexo masculino) costumam ser diagnosticados devido à existência de outros casos na família.  
**Nota 3:** Como apresentado na figura 1, naqueles pacientes que já tem uma mutação familiar identificada, preconiza-se sequenciar esta mutação e não o gene completo.  
**Nota 4:** A dosagem da enzima αGAL-A deverá ser realizada em plasma ou leucócitos a partir do sangue periférico ou cultura de fibroblastos. Dosagens realizadas em papel filtro não devem ser utilizadas como critério diagnóstico.  
***** O exame é um dos critérios internacionais para diagnóstico de DF. Contudo, a quantificação de GL-3 não é amplamente disponível, mesmo internacionalmente, e não está disponível no SUS. Adaptado de Silva et al, 2022<sup>26</sup>

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Serão incluídos nesse Protocolo todos os pacientes com diagnóstico confirmado de DF de acordo com um dos seguintes  
critérios:

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- atividade da enzima αGAL-A inferior a 5% dos valores normais **ou** ;  
- análise do DNA que demonstre mutação patogênica do gene que codifica a enzima αGAL-A;

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- análise do DNA que demonstre mutação patogênica do gene que codifica a enzima αGAL-A **ou** ;  
- situação de heterozigota portadora de mutação patogênica no gene da αGAL-A, confirmada por história familiar (por  
- exemplo: paciente que apresente filho e irmão, ambos do sexo masculino, com diagnóstico confirmado de DF) **ou;**  
- ao menos uma destas alterações bioquímicas extremamente sugestivas do diagnóstico de DF (aumento na excreção  
- urinária de GL-3 **ou** evidência histológica de acúmulo de GL-3), associada a, ao menos, uma das manifestações clínicas altamente sugestivas de DF (angioqueratoma confirmado por biópsia **ou** córnea verticilata).  
Os critérios de inclusão, naqueles com diagnóstico estabelecido de DF, para realização de terapia de reposição enzimática  
(TRE) com alfagalsidase ou beta-agalsidase, são:  
O/A paciente deve ter o diagnóstico de doença de Fabry **<u>clássica</u>** <u>,</u> **idade igual ou superior a sete anos e apresentar ao** **<u>menos um dos seguintes critérios para seu grupo populacional</u>** .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- Fenótipo clássico, com sintomas ou sinais precoces de envolvimento de órgãos-alvo **ou** ;  
- Albuminúria ou proteinúria, alteração histológica renal (apagamento dos pedicelos ou sinais moderados ou graves de inclusões de GL-3 e sinais de glomeruloesclerose no tecido renal), TFG entre 60 a 90 mL/min/1,73 m<sup>2</sup> ou TFG < 60 mL/min/1,73 m<sup>2</sup> , mesmo que outros sintomas estejam ausentes.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- Fenótipo clássico, com sintomas ou sinais precoces de envolvimento de órgãos-alvo **ou** ;  
- Albuminúria ou proteinúria, alteração histológica renal (apagamento dos pedicelos ou sinais moderados ou graves de  
inclusões de GL-3 e sinais de glomeruloesclerose no tecido renal), TFG entre 60 a 90 mL/min/1,73 m<sup>2</sup> ou TFG < 60 mL/min/1,73 m<sup>2</sup>

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- Sintomáticos (independentemente do sexo), mesmo na presença de sintomas leves **ou** ;  
- Lesão podocitária em biópsia renal.  
8

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Serão excluídos os pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso dos respectivos medicamentos e procedimentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Por ser uma doença multissistêmica, com manifestações dolorosas frequentes, com diagnóstico tardio em relação ao surgimento das manifestações, muitos pacientes com DF desenvolvem sintomas depressivos. O acompanhamento psicológico destes pacientes é importante, bem como o acompanhamento em grupos de apoio.  
Segundo Veisbich _e colaboradores_<sup>_2_7</sup> , uma particularidade no tratamento não farmacológico em crianças é a terapia cognitivo-comportamental, essencial neste grupo etário no tratamento da dor, sendo muito importante evitar gatilhos de dor. Assim, crianças com DF precisam de orientação sobre atividades físicas. Medidas para evitar o superaquecimento corporal, que incluem a remoção de sapatos e meias quando a dor começar, o tratamento rápido da febre, o uso de spray de água como substituto do suor quando houver hipoidrose e o hábito de evitar alguns tipos de atividades extenuantes (como corrida de longa distância)<sup>27,48</sup> que vão além do nível de tolerância e capacidade do paciente<sup>27,48</sup> .  
Distúrbios psicológicos, especialmente os transtornos do humor, são muito comuns entre pacientes pediátricos, principalmente entre adolescentes. Os distúrbios psicológicos na DF provavelmente refletem uma combinação do impacto primário da doença no SNC e manifestações secundárias de viver com uma doença crônica durante a infância<sup>27,48</sup> .  
A atividade física limitada secundária à dor e a diminuição da tolerância ao exercício são particularmente propensas a contribuir para a sensação de estar isolado ou ser deixado de lado. Meninos com DF apresentam, frequentemente, baixa estatura e constituição física que aparenta fraqueza, correndo o risco de sofrer _bullying_ ou de serem socialmente marginalizados na escola durante a adolescência. Deve-se prestar muita atenção aos riscos psicossociais associados à DF e ao cuidado apropriado das crianças com a doença<sup>27,48</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Dor neuropática é comum em indivíduos com DF e pode ser tratada com o uso de analgésicos. Pacientes devem ser orientados quanto aos possíveis desencadeantes como, por exemplo, exercícios físicos, mudanças de temperatura, estresse emocional. O uso de anti-inflamatórios não esteroidais deve ser evitado devido ao risco de toxicidade renal<sup>15,34</sup> . Recomenda-se que o tratamento da dor crônica seja feito conforme PCDT da Dor Crônica vigente.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
9  
Para prevenção de eventos cerebrovasculares, pode-se considerar a utilização de antitrombóticos, como ácido acetilsalicílico ou clopidogrel, ou anticoagulantes, de acordo com avaliação individualizada<sup>15,34</sup> . Em caso de AVC, recomendase considerar o tratamento preconizado nas linhas de cuidado de AVC na Rede de Atenção às Urgências e Emergências<sup>50</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Pacientes com DF que apresentem eventos cardiovasculares devem receber tratamento padrão, com uso de medicamentos como betabloqueadores, inibidores da enzima conversora de angiotensina (IECA), bloqueadores dos receptores de angiotensina (BRA), estatinas, entre outros<sup>15,34</sup> . Em caso de fibrilação atrial, pode-se utilizar anticoagulantes. A amiodarona deve ser utilizada com cautela por influir na função do lisossomo<sup>15</sup> .  
Recomenda-se que o cuidado dos pacientes siga as orientações do PCDT da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Para pacientes com complicações renais crônicas decorrentes da DF, deve-se atentar para a ocorrência de anemia, distúrbio mineral ósseo e hipertensão. Medicamentos das classes dos IECA e BRA podem ser considerados para o tratamento das manifestações renais por terem efeito sobre a proteinúria<sup>15,34</sup> . Pacientes em fase avançada de doença renal crônica podem necessitar de diálise ou transplante renal<sup>15,34</sup> . As principais manifestações clínicas da Doença de Fabry e opções de tratamentos de suporte ou sintomáticos estão descritas no **Quadro 3** .  
Em relação à anemia da doença renal crônica recomenda-se seguir os aspectos previstos no PCDT de Anemia na DRC vigente.  
**Quadro 3** . Principais manifestações clínicas da Doença de Fabry e opções de tratamentos de suporte ou sintomáticos.  
|**Classificação**|**Manifestação**|**Conduta**|
|---|---|---|
|Aconselhamento<br>Genético|Não se aplica|Deve estar disponível para todos os indivíduos e seus familiares.|
|Prevenção|Crises Dolorosas|Orientação quanto aos possíveis desencadeantes como, por exemplo,<br>exercícios físicos, mudanças de temperatura, estresse emocional.|
||Alto risco de eventos<br>cardiovasculares|Como ocorre na população geral, tanto pacientes masculinos ou femininos<br>devem ter fatores de risco como hipertensão, dislipidemia e diabetes,<br>tratados adequadamente.|
|Neurológica|Dor neuropática|Uso de analgésicos durante as crises; uso de anticonvulsivantes para<br>controle da dor crônica|
||Doença<br>neurovascular/|Instituição do tratamento padrão, considerando o uso de antiagregantes<br>plaquetários e estatinas.|
||Acidente<br>Vascular<br>Encefálico|Tratamento do evento deve ocorrer de acordo com o preconizado nas<br>linhas de cuidado de Acidente Vascular Cerebral (AVC) na Rede de<br>Atenção às Urgências e Emergências do Ministério da Saúde<sup>50</sup>.|  
10  
|**Classificação**|**Manifestação**|**Conduta**|
|---|---|---|
|Renal|Proteinúria|Uso de IECA nos estágios iniciais e nos pacientes sem estenose da artéria<br>renal. O uso de antagonistas do receptor da angiotensina também deve ser<br>considerado como opção de tratamento.|
||Insuficiência<br>renal<br>crônica|Diálise e transplante para doença avançada e conforme as indicações<br>usuais.<br>Consultar os Protocolos Clínicos e Diretrizes Terapêuticas da Anemia na<br>Doença Renal Crônica<sup>46,47</sup>e do Distúrbio Mineral Ósseo na Doença Renal<br>Crônica<sup>54</sup>.|
|Cardiovascular|Hipertensão<br>arterial<br>sistêmica|Uso de IECA e antagonistas do receptor da angiotensina|
||Dislipidemia|Uso de estatinas|
||Arritmias|Uso de medicamentos, marca-passo e desfibrilador, conforme tratamento<br>padrão|
||Insuficiência cardíaca|Tratamento padrão|
|Psiquiátrica|Depressão, ansiedade,<br>abuso de fármacos|Encaminhamento ao psiquiatra, centro especializado em tratamento de dor<br>ou uso de antidepressivos, conforme critérios usuais|
|Otorrinolaringológica|Náusea relacionada à<br>vertigem|Uso de metoclopramida|
|Gastrointestinal|Dispepsia|Orientações dietéticas; uso de inibidor da bomba de prótons|
||Retardo<br>do<br>esvaziamento gástrico|Orientações dietéticas; uso de metoclopramida|
|Reabilitação|Não se aplica|Aos pacientes que necessitarem, como por exemplo, àqueles com sequelas<br>neurológicas.|  
Legenda: IECA: inibidores da enzima conversora de angiotensina.  
Fontes: Adaptado de Ortiz _et al_ (2018)<sup>15</sup> ; Mehta _et al_ (2010)<sup>35</sup> ; Schiffmann _et al_ (2015)<sup>38</sup> ; Laney _et al_ (2013)<sup>41;</sup> Sirrs _et al_ (2018)<sup>42</sup> ; Lidove _et al_ (2010)<sup>44</sup> ; Tahir _et al_ (2007)<sup>45</sup> ; Jain _et al_ (2018)<sup>46</sup> ; Neumann P _et al_ (2013)<sup>43</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Qualquer programa de controle da dor deve envolver o uso criterioso de agentes redutores de dor neuropática e nociceptiva. Os medicamentos devem ser escalonados seguindo uma sequência gradual e controlada que permita a otimização do efeito terapêutico e minimização dos eventos adversos, antes de se considerar adição ou troca de terapia<sup>15,34,49</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Crianças com DF comumente experimentam distúrbios gastrointestinais significativos, incluindo dor abdominal episódica, diarreia grave e explosiva e períodos de constipação. É particularmente importante que esses pacientes recebam uma avaliação adequada para excluir outras causas potenciais de seus sintomas, como doença celíaca<sup>27,28</sup> .  
- O **Quadro 4** elenca as opções de tratamento para as principais manifestações clínicas da DF nessa população. 11  
**Quadro 4** - Principais manifestações clínicas da DF na criança e opções de tratamentos de suporte ou sintomáticos.  
|**Classificação**|**Manifestação**|**Conduta**|
|---|---|---|
|Aconselhamento<br>Genético|-|Deve estar disponível para todos os indivíduos e seus familiares|
|Prevenção|Crises Dolorosas|Orientação quanto aos possíveis desencadeantes como, por exemplo,<br>exercícios físicos, mudanças de temperatura, estresse emocional.|
|Neurológica|Dor neuropática|Uso de analgésicos durante as crises; uso de anticonvulsivantes para<br>controle da dor crônica.|
|Psiquiátrica|Depressão, ansiedade,<br>abuso de fármacos|Encaminhamento ao psiquiatra, centro especializado em tratamento de<br>dor ou uso de antidepressivos, conforme critérios usuais|
|Gastrointestinal|Dispepsia|Orientações dietéticas; uso de inibidor da bomba de prótons|
||Retardo do esvaziamento<br>gástrico|Orientações dietéticas; uso de metoclopramida|
|Reabilitação|-|Aos pacientes que necessitarem, como por exemplo, àqueles com<br>sequelas neurológicas.|  
Fonte: Adaptado de Ortiz _et al_ (2018)<sup>15</sup> ; Mehta _et al_ (2010)<sup>35</sup> ; Schiffmann _et al_ (2015)<sup>38</sup> ; Laney _et al_ (2013)<sup>41;</sup> Sirrs _et al_ (2018)<sup>42</sup> ; Lidove _et al_ (2010)<sup>44</sup> ; Tahir _et al_ (2007)<sup>45</sup> ; Jain _et al_ (2018)<sup>46</sup> ; Neumann P _et al_ (2013)<sup>43</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Este Protocolo recomenda a TRE para o tratamento primário da DF clássica em pacientes a partir dos sete anos de idade, com o uso de alfagalsidase ou beta-agalsidase<sup>47,55,56</sup> . O uso da chaperona migalastate<sup>57</sup> , apesar de ter registro aprovado no Brasil, não é preconizado neste Protocolo.  
Os benefícios potenciais da TRE<sup>42</sup> para DF envolvem: estabilização da nefropatia (estabilização da proteinúria e da taxa de filtração glomerular); estabilização da cardiomiopatia (manutenção ou declínio do índice de massa ventricular esquerdo e da espessura da parede do VE); melhora dos sintomas gastrointestinais (redução da diarreia, cólicas ou dores abdominais, náuseas, vômitos e sintomas dispépticos). No entanto, há outras manifestações da DF para as quais, até o momento, não há evidência de melhora com o tratamento específico, tais como: arritmias (bradiarritmias ou taquiarritmias), AVC ou AIT, depressão e perda de audição.  
O tratamento com TRE tem recomendações distintas para pacientes pediátricos, adultos do sexo masculino e do sexo feminino<sup>26,58-60</sup> e não é recomendado para alguns grupos, independentemente dos aspectos de idade e sexo: pacientes com doença renal crônica (DRC) estágios 4 ou 5; pacientes inelegíveis para transplante renal; pacientes com IC classe IV da NYHA ou com qualquer doença avançada que leve a uma expectativa de vida inferior a um ano<sup>58,59</sup> . Já a gravidez é uma contraindicação relativa para TRE<sup>26,60</sup> .  
12

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
As recomendações para iniciar a TRE são diferentes de acordo com as peculiaridades do paciente e, inclusive, inexiste consenso para o uso de TRE em alguns grupos. As recomendações a seguir, divididas por grupo, se baseiam nas diretrizes brasileiras<sup>26</sup> e na literatura disponível<sup>15,29,58,59</sup> .  
**Grupos nos quais a TRE é recomendada, por evidência de benefício (grau de evidência IA):**  
- Homens e mulheres com doença de fenótipo clássico devem ser tratados quando sinais precoces de envolvimento de  
órgãos-alvo, relacionados à DF, estiverem presentes<sup>59</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- Mulheres sintomáticas;  
- Mulheres assintomáticas, se houver evidência de lesão renal (TFG inferior a 90 mL/min/1,73m<sup>2</sup> , relação  
- albumina/creatinina urinária persistentemente >30 mg/g ou alterações renais histológicas).  
**Grupos nos quais a TRE baseia-se unicamente no envolvimento renal (homens e mulheres - evidências de níveis**  
**IA e IIA, respectivamente):**  
- Albuminúria ou proteinúria (na ausência de outras possíveis causas), alteração histológica, TFG entre 60-90 mL/min/1,73m<sup>2</sup> ou TFG entre 60-90 mL/min/1,73m<sup>2.</sup> Aqui existe diferença entre homens e mulheres em termos de certeza do benefício. Enquanto em homens considera-se que há benefício definido, em mulheres o benefício é provável<sup>26,38</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
- Homens assintomáticos com DF clássica: alguns autores indicam no momento do diagnóstico para prevenir a progressão  
- da DF antes da instalação de alterações irreversíveis<sup>55</sup> . Outros acreditam que deva ser iniciada apenas quando houver sinais de  
envolvimento de órgãos<sup>15,34,35</sup> .  
**Grupos sem indicação de TRE devido à inexistência de benefício plausível**<sup>**26,35**</sup> **:**  
- Pacientes masculinos e femininos com variantes de significado indefinido (VUS) com polimorfismos benignos bem caracterizados.  
Persistem discussões sobre o possível benefício do uso da TRE em alguns grupos. Um exemplo disso: segundo o consenso europeu<sup>58</sup> , em pacientes com DRC avançada, nos quais não se indica usualmente a TRE, esta terapia poderia vir a ser considerada em casos específicos, que tenham envolvimento de outros órgãos com base em avaliação individualizada. Contudo, o presente PCDT não preconiza o uso por pacientes com estas condições.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Inexiste consenso universal quanto à indicação do início da TRE em crianças. Em geral, recomenda-se o início da TRE em crianças a partir de 7 anos de idade, nas seguintes situações<sup>27,29,30</sup> :  
Pacientes sintomáticos: devem iniciar TRE, independentemente do sexo, ainda que os sintomas sejam leves<sup>27</sup> ;  
Indicação de acometimento renal: há estudos<sup>38</sup> que recomendam que, na presença de lesão podocitária, pacientes pediátricos devem iniciar a TRE para evitar a perda dessas células. Dessa forma, a biópsia renal auxilia nessa decisão<sup>27,38,42,58</sup> ;  
Pacientes do sexo masculino assintomáticos: indicação do início de TRE é objeto de discussão. Nos meninos com mutação clássica, alguns autores indicam início da TRE a partir dos 7 anos ou após os 16 anos de idade, com base em biópsia renal<sup>27,38,59</sup> . Alguns especialistas consideram o início da TRE também em meninos assintomáticos com variante patogênica no GLA, história familiar de doença grave em homens, atividade de α-GAL indetectável e liso-GL-3 plasmático > 20 nmol/L<sup>27</sup> ;  
Pacientes do sexo feminino assintomáticas: também não há dados que apoiem o início da TRE. A histologia renal poderia ser um critério para auxiliar a decisão de iniciar o tratamento precoce ou não<sup>27,38,42,58</sup> .  
13  
O medicamento beta-agalsidase possui indicação em bula aprovada a partir de oito anos de idade enquanto o medicamento alfagalsidase possui indicação em bula aprovada a partir de sete anos de idade. Contudo, em sua recomendação final, o Comitê de Medicamentos da Conitec considerou que, apesar de distintas, estas idades são muito próximas, e que o respectivo Protocolo Clínico e Diretrizes Terapêuticas deveria considerar que ambos os medicamentos podem ser utilizados pela mesma faixa etária, respeitando-se os demais critérios de uso.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
Existem informações muito limitadas sobre mulheres grávidas que utilizaram alfagalsidase ou beta-agalsidase<sup>55,56,65,66</sup> . As informações das bulas<sup>55,56</sup> , sobre estudos em animais, não indicam efeitos deletérios diretos ou indiretos em relação à gestação ou desenvolvimento embrionário/fetal, quando há exposição durante a organogênese (classe de risco B).  
Não se sabe se a alfagalsidase é excretada no leite humano<sup>55</sup> . Em relação à beta-agalsidade há dados limitados que sugerem sua presença no leite humano<sup>56</sup> .  
Recomenda-se cautela ao prescrever a TRE às gestantes ou lactantes. A gravidez é uma contraindicação relativa para TRE. <mark>Inexistem estudos controlados em mulheres grávidas em uso de TRE, seja com alfagalsidase ou com beta-agalsidase. No entanto, dados disponíveis de estudos pós-comercialização em mulheres grávidas não identificaram riscos de defeitos congênitos importantes, aborto espontâneo ou eventos adversos maternos ou fetais associados ao medicamento. Deve ser usado apenas se claramente necessário durante a gravidez</mark><sup>55, 56</sup> <mark>(</mark> classe de risco B).  
No entanto, dados do estudo de Holmes _et al_<sup>64</sup> , conduzido com 41 pacientes com DF que engravidaram (apenas 3 em uso de TRE) indicam que um terço das pacientes assintomáticas, no período anterior à gravidez, apresentarão sintomas durante a gestação. O achado mais frequente foi o aparecimento de proteinúria (37%), seguido de acroparestesia (31%), cefaleia (22%) e diarreia (27%)<sup>64</sup> .  
Em 2018, Fernandez _et al_<sup>65</sup> publicaram uma série de 6 casos de mulheres grávidas que mantiveram durante a gestação o uso da alfagalsidase. O medicamento foi bem tolerado em todos os casos e nenhuma complicação relacionada à TRE foi relatada, nem nas mães nem nos recém-nascidos. Conforme Blasco _et al_<sup>66</sup> , níveis elevados de lisoGB-3 podem causar maior deposição de lisoGB-3 na placenta e induzir danos aos seus vasos, com o consequente risco de pré-eclâmpsia. Diante disso, sua consideração é que, contrariamente à prática de muitos, a TRE não deve ser obrigatoriamente abolida durante a gestação, devendo haver avaliação individual dos casos.  
Neste Protocolo, o uso da TRE em gestantes e lactantes deve ser realizado a critério médico.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
A resposta ao tratamento deve ser avaliada da mesma forma em pacientes adultos e crianças. Aspectos clínicos e parâmetros associados ao acometimento de órgãos-alvo, especialmente rins e coração, devem ser minuciosamente investigados<sup>15,26,27,41</sup> .  
O cuidado aos pacientes com DF deve ser baseado na avaliação e monitoramento regular do funcionamento dos órgãos ou sistemas usualmente atingidos pela doença. A despeito da multiplicidade de manifestações da DF, alguns órgãos ou sistemas são afetados mais frequentemente ou ocorre morbidade potencialmente mais grave. Além do surgimento de danos em órgãos anteriormente não comprometidos, pode haver progressão da doença, independentemente de os pacientes estarem usando ou não terapia específica. Assim, ambas as possibilidades devem fazer parte da avaliação inicial e do seguimento destes pacientes<sup>15,41</sup> .  
O monitoramento renal ideal inclui a análise da TFG e albuminúria/proteinúria, pelo menos anualmente, em pacientes com baixo risco de desenvolver DRC. Se o risco for classificado como moderado, a função renal deve ser avaliada a cada seis  
14  
meses e, em pacientes de alto risco, a cada três meses. A realização de uma análise histológica basal (renal, em especial) é um parâmetro útil para avaliar progressão<sup>26,27,41,59</sup> .  
Mulheres assintomáticas com variantes de início tardio e cujas avaliações de órgãos-alvo não indiquem lesões na avaliação inicial também devem ser monitoradas, embora com intervalos mais longos. A ausência de sintomas no momento do diagnóstico e durante o acompanhamento não descarta o desenvolvimento de complicações ao longo do tempo<sup>15,7,41,58,60</sup> .  
Em indivíduos com variante de início tardio é importante definir se os sinais e sintomas que surgem se associam à DF ou ao próprio envelhecimento, em especial no caso das doenças cardiovasculares<sup>26,41</sup> .  
Apesar da administração da TRE, a progressão da DF pode ocorrer por várias razões, dentre elas, o início tardio do tratamento, quando já existem lesões irreversíveis em órgãos alvo; heterogeneidade da taxa de penetração tecidual da enzima (a TRE, por exemplo, não atravessa a barreira hematoencefálica); a complexidade da doença em si, caracteristicamente multissistêmica; a existência de outros fatores de risco individuais para complicações renais e cardiovasculares sem controle adequado ou, ainda, a presença de anticorpos anti-IgG<sup>41</sup> .  
Aspectos como qualidade de vida e dor são importantes para os pacientes com DF e, portanto, o uso de questionários específicos, como o “ _Main Severity Score Index”_ (validado inclusive para a faixa etária pediátrica) ou o “ _Pediatric Health and Pain Questionnaire_ ” (FPHPQ) e o sistema de pontuação de gravidade da doença (DS315) são instrumentos de acompanhamento destes pacientes<sup>26,27,58,61-63</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
− Alfagalsidase: solução injetável de 1 mg/mL;  
- Beta-agalsidase: pó para solução injetável de 35 mg.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
− Alfagalsidase: a dose recomendada é de 0,2 mg/kg de peso em administração intravenosa (IV) a cada duas semanas. O preparo deve envolver a diluição do volume total da alfagalsidase em 100 mL de solução de cloreto de sódio 0,9% para infusão<sup>55</sup> .  
− Beta-agalsidase: a dose recomendada é de 1 mg/kg de peso em administração IV a cada duas semanas. O pó para solução injetável deve ser reconstituído com água estéril para solução, diluído com solução intravenosa de cloreto de sódio 0,9%. O medicamento beta-agalsidase deve ser diluído entre 50 e 500 mL de cloreto de sódio 0,9% considerando a dose individual. Para doses menores que 35 mg deverá ser usado um mínimo de 50 mL; para doses de 35 a 70 mg, utilizar um mínimo de 100 mL; para doses de 70 a 100 mg, utilizar um mínimo de 250 mL, e; para doses maiores que 100 mg, utilizar 500 mL<sup>56</sup> .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
As contraindicações com base na literatura e nas bulas dos medicamentos são<sup>26,55,56</sup> :  
- Pacientes com DRC avançada (estágios 4 e 5), com contraindicação ao transplante renal;  
- Pacientes com insuficiência cardíaca avançada (classe IV da NYHA);  
- Declínio cognitivo grave por qualquer causa;  
- DF avançada ou outras comorbidades com uma expectativa de vida inferior a um ano;  
- Reações infusionais graves ou reação anafilática prévia à TRE com presença de IgE.  
É importante ressaltar que a idade por si só não é uma contraindicação à TRE, no entanto, não há estudos avaliando os  
benefícios em pacientes com 65 anos ou mais<sup>55,56</sup> .  
15

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **3.2     Diagnóstico clínico diferencial** -->
A TRE deve ser utilizada continuamente. Caso o paciente apresente pelo menos uma das seguintes situações, seu uso deve ser interrompido:  
− Paciente com adesão inadequada ao tratamento, definida por falta em mais de 50% das sessões de infusão do medicamento;  
− Redução grave na qualidade de vida e no estado funcional, apesar do tratamento específico para a doença, definidas por condição clínica que se associe a uma expectativa de vida menor que 1 ano;  
- Surgimento de contraindicação ao medicamento.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Estudos _in vitro_ sugerem que ambas as enzimas recombinantes, alfagalsidase e beta-agalsidase, seriam proteínas bioquímica e estruturalmente muito similares e com propriedades funcionalmente indistinguíveis<sup>67</sup> .  
Sobre a possibilidade de troca entre a alfagalsidase e beta-agalsidase para tratamento de pacientes com a DF ou recomendação de troca para os pacientes que apresentarem progressão ou toxicidade com uma das enzimas, uma revisão da literatura (descrita no Material Suplementar) identificou que inexiste evidência sobre diferenças clínicas relevantes, a despeito da escassez de comparações diretas. Uma revisão sistemática com meta-análise, publicada em 2017, não constatou diferenças estatisticamente significativas entre os períodos de uso das formas beta e alfa, para eficácia e segurança<sup>68</sup> .  
A despeito de haver discussões sobre a intercambialidade das enzimas, beta e alfagalsidase, uma análise da literatura indica que, no que tange aos benefícios do tratamento ou aos aspectos de segurança relevantes (eventos adversos graves), ambas as formas enzimáticas podem ser consideradas semelhantes.  
Por fim, não existem recomendações uniformes na literatura sobre a possibilidade de troca de enzimas devido à ocorrência de evento adverso ou ausência de resposta. Alguns autores sugerem que, em pacientes com reações alérgicas graves<sup>68</sup> , pode-se considerar a troca da enzima. Portanto, cabe ao médico assistente definir a necessidade de troca da enzima nessas situações.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Indivíduos com DF devem ser acompanhados por equipe multidisciplinar, cuja composição dependerá de suas necessidades individuais. O **Quadro 5** descreve os exames da avaliação inicial e de seguimento clínico dos pacientes com DF, com um programa de acompanhamento mínimo, o qual pode ser modificado de acordo com julgamento clínico.  
**Quadro 5.** Avaliação inicial e período de acompanhamento clínico mínimo sugerido para pacientes com Doença de Fabry.  
|**Avaliações**|**Avaliação**<br>**inicial/basal**|**Anual**|**Observações**|
|---|---|---|---|
|Consulta<br>clínica<br>completa<br>(anamnese,<br>exame<br>neurológico e exame físico completo)|x|x||
|Exames laboratoriais: hemograma com plaquetas,||||
|eletrólitos, creatinina, ureia, rastreio de fatores de risco<br>cardiovasculares, como perfil lipídico (HDL, colesterol|x|x||
|total, triglicerídeos, LDL-C), glicemia de jejum||||
|Exames laboratoriais de urina: exame qualitativo, coleta|x||Varia de acordo com a função|  
16  
|**Avaliações**|**Avaliação**<br>**inicial/basal**|**Anual**||**Obse**|**rvaçõ**|**es**|
|---|---|---|---|---|---|---|
|de urina de 24h para determinação da proteinúria,|||renal*||||
|albuminúria e depuração da creatinina|||||||
|Eletrocardiograma (ECG)|x|x|||||
|E ftllói (idd il fd d lh|||Repetido|<br>se|for|identificado|
|xame oamogco acuae vsua, uno e oo,<br>exame com lâmpada de fenda)|x||sintomas<br>caso a cas|espec<br>o)|íficos|(avaliação|
||||Repetida|se|houv|er<br>evento|
|Ressonância magnética nuclear (RM) ou tomografia<br>computadorizada (TC) cerebral|x||cerebrova<br>neurológi<br>(avaliaçã|scular<br>cos<br>o caso|<br>ou<br>a caso|<br>sintomas<br>específicos<br>)|
|Ecocardiograma|x||Anual a<br>bianual se|partir<br>meno|dos<br>r de 3|35 anos ou<br>5 anos|
|Questionários validados para avaliação de qualidade de<br>vida e dor|x|x|||||  
Fonte: Autoria própria.  
***** A avaliação da função renal varia de acordo com o estágio da doença renal:  
- Se proteinúria < 1 g/dia: anual;  
- Se doença renal crônica em estágio 1 ou 2: anual;  
- Se doença renal crônica em estágio 4 (TFG 15 a 29 mL/min/1,73 m<sup>2</sup> ): trimestral;  
- Se proteinúria 90 mL/min/1,73m<sup>2</sup> ) ou 2 (TFG 60 a 89 mL/min/1,73 m<sup>2</sup> ): trimestral.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica da(s) dose(s) de medicamento(s) prescrita(s) e dispensado(s), e a adequação de uso e o acompanhamento pós-tratamento. Pessoas com DF devem ser atendidas em serviços especializados em genética, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Pacientes com DF devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses, conforme necessário e o controle de eventos adversos.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>**69-72**</sup> .  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e possui como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a  
17  
Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção primária.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras. Todavia, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras;  
e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS e, se houver necessidade, o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade. A linha de cuidados de pacientes com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com DF deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).  
18

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
1. Garman SC, Garboczi DN.The molecular defect leading to Fabry Disease: structure of human  alpha- galactosidase. J Mol Biol. 2004; 337 (2):319-35.  
2. Online Mendelian Inheritance in Man. Em https://www.omim.org/entry/301500?search=fabry&highlight=fabry:  
3. Wraith JE. Lysosomal disorders. Semin Neonatol.2002; 7:75-83.  
4. Meikle PJ, Hopwood JJ, Clague AE, Carey WF. Prevalence of lysosomal storage disorders.  JAMA. 1999; 281(3):249– 54.  
5. Poorthuis BJ, Wevers RA, Kleijer WJ, Groener JE, de Jong JG, van Weely S, et al <mark>The frequency of lysosomal storage diseases in The Netherlands. H</mark> um Genet. 1999 Jul-Aug;105(1-2):151-6. doi: 10.1007/s004399900075.  
6. Spada M, Pagliardini S, Yasuda M, Tukel T, Thiagarajan G, Sakuraba H et al. High incidence of later- onset Fabry Disease revealed by newborn screening. Am J Hum Genet. 2006; 79 (1):31- 40  
7. Mehta A, Ramaswami U. Fabry Disease. pp 58-62. In Lysosomal Storage Diseases. A Practical Guide. 2012, Editors Mehta A and Winchester B. Edited by Wiley-Blackwell. London, UK.  
8. Tondel C, Thurberg BL, DasMahapatra P, Lyn N, Marski M, et al. Clinical relevance of globotriaosylceramide accumulation in Fabry disease and the effect of agalsidase beta in affected tissues. Mol Genet Metab. 2022;137(4):328341. <mark>doi: 10.1016/j.ymgme.2022.10.005.</mark>  
9. Gieselmann V. Lysosomal storage diseases. Biochim Biophys Acta. 1995; 1270:103-136.  
10. Mehta A, Ricci R, Widmer U, Dehout F, Garcia de Lorenzo A, Kampmann C et al. Fabry Disease defined: baseline clinical manifestations of 366 patients in the Fabry Outcome Survey. Eur J of Clin Invest. 2004; 34:236-42.  
11. Branton M, Schiffmann R, Kopp JB. Natural history and treatment of renal involvement in Fabry Disease. J Am Soc Nephrol. 2002; S2: 139-143.  
12. Eng CM, Fletcher J, Wilcox WR, Germain DP, Lee P, Waldek S, et al. Fabry Disease: baseline medical characteristics of a cohort of 1765 males and females in the Fabry Registry. J Inherit Metabol. 2007; 30:184-192.  
13. MacDermot KD, Holmes A, Miners AH. Anderson-Fabry Disease: clinical manifestations and impact of disease in a cohort of 98 hemizygous males. J Med Genet. 2001; 38 (11): 750-60.  
14. Waldek S, Patel MR, Banikazemi M, Lemay R, Lee P. Life expectancy and cause of death in males and females with Fabry Disease: findings from the Fabry Registry. Genet Med. 2009; 11(11):790-6.  
15. Ortiz A, Germain DP, Desnick RJ, Politei J, Mauer M, Burlina A et al. <mark>Fabry disease revisited: Management and treatment recommendations for adult patients. Mol Genet Metab. 2018;123(4):416-427. doi: 10.1016/j.ymgme.2018.02.014.</mark>  
16. Wendrich K, Whybra C, Ries M, Gal A, Beck M. Neurological manifestation of Fabry Disease in females. Contrib Nephrol. 2001; 136: 241–244.  
17. Deegan PB, Baehner AF, Barba Romero MA, Hughes DA, Kampmann C, Beck M- EuropeanFOS  Investigators. Natural History of Fabry Disease in females in the Fabry Outcome Survey (FOS).  J Med Genet. 2006; 43: 347–35.  
18. Wilcox WR, Oliveira JP, Hopkin RJ, Ortiz A, Banikazemi M, Feldt-Rasmussen U et al. Females with Fabry Disease frequently have major organ involvement: lessons from the Fabry Registry. Mol Gen and Metabol. 2008; 93(2):112-28.  
19. Whybra C, Kampmann C, Willers I, Davies J, Winchester B, Kriegsmann J, et al. Anderson-Fabry disease: clinical manifestations of disease in female heterozygotes. J Inherit Metab Dis. 2001; 24(7):715–24.  
20. Pérez-Jovel E, Cano-Nigenda V, Manrique-Otero D, Castellanos-Pedroza E, Aguilar-Parra GL et al. Fabry Disease and Cerebrovascular Disease. Arch Neurocien (Mex). 2022; 27(2):29-38. 19  
21. Martins AM, Kyosen SO, Garrote J, Marques FM V, Guilhem JG, Macedo E, et al. Demographic characterization of Brazilian patients enrolled in the Fabry Registry. Genet Mol Res. 2013; 12(1):136–42.  
22. Zarate YA, Hopkin RJ. Fabry’s disease. Lancet. 2008; 372(9647):1427–35.  
23. Boggio P, Luna PC, Abad ME, Larralde M. Doença de Fabry. An Bras Dermatol. 2009; 84(4):367–76.  
24. Reisin R, Perrin A, García-Pavía P. Time delays in the diagnosis and treatment of Fabry disease. Int J Clin Pract. 2017; 71(1):e12914.  
25. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. 2016.  
26. Silva CAB, Andrade LGM, Vaisbich MH, Barreto FC. Brazilian consensus recommendations for the diagnosis, screening, and treatment of individuals with fabry disease Committee for Rare Diseases – Brazilian Society of Nephrology/2021 Consenso brasileiro de doença de fabry: recomendações de diagnóstico, triagem e tratamento. Comitê de doenças raras (Comdora) - SBN/2021. Braz. J. Nephrol. (J. Bras. Nefrol.) 2022;44(2):249-267  
27. Vaisbich MH, Andrade LGM, Silva CAB, Barreto FC. Recommendations for the diagnosis and management of Fabry disease in pediatric patients: a document from the Rare Diseases Committee of the Brazilian Society of Nephrology (Comdora-SBN). Recomendações para o diagnóstico e manejo de pacientes pediátricos com doença de Fabry: documento do comitê de doenças raras da Sociedade Brasileira de Nefrologia (Comdora-SBN). J. Bras. Nefrol. 2022;44(2):268-280  
28. Germain DP, Fouilhoux A, Decramer S, Tardieu M, Pillet P, Fila M, et al. Consensus recommendations for diagnosis, management and treatment of Fabry disease in paediatric patients. Clin Genet. 2019; 96(2):107–17.  
29. Mauer M, Kopp J. Fabry disease. UpToDate; 2017.  
30. Silva CA, Barreto FC, Reis MA, Moura Junior JA, Cruz CM. Targeted screening of Fabry disease in male hemodialysis patients in Brazil highlights importance of family screening. Nephron. 2016;134(4):221-30.  
31. Mehta A, Hughes DA. Fabry Disease. In: Adam MP, Ardinger HH, Pagon RA, Wallace SE, Bean LJH, Mirzaa G, et al., editors. Seattle (WA); 1993.  
32. Mehta A, Orteu C. Fabry disease. In: Goldsmith L, Katz S, Gilcrest B, Paller A, Leffell D, Wolff K, editors. Fitzpatrick’s Dermatology in General Medicine. 8 ed. McGraw-Hill Education; 2012.  
33. van der Tol L, Smid BE, Poorthuis BJHM, Biegstraaten M,  Lekanne Derez RH, Linthorst GE,  et al. A systematic review on screening for Fabry disease: prevalence of individuals with genetic variants of unknown significance. J Med Genet. 2014;51:1-9.  
34. Salviati A, Burlina AP, Borsini W. Nervous system and Fabry disease, from symptoms to diagnosis: damage evaluation and follow-up in adult patients, enzyme replacement, and support therapy. Neurol Sci Off J Ital Neurol Soc Ital Soc Clin Neurophysiol. 2010 Jun;31(3):299– 306.  
35. Mehta A, Beck M, Eyskens F, Feliciani C, Kantola I, Ramaswami U, et al. Fabry disease: a review of current management strategies. QJM. 2010; 103(9):641–59.  
36. Ortolano S, Viéitez I, Navarro C, Spuch C. Treatment of lysosomal storage diseases: recent patents and future strategies. Recent Pat Endocr Metab Immune Drug Discov. 2014 Jan;8(1):9– 25.  
37. Desnick R, Ioannou Y, Eng C. Galactosidase A deficiency: Fabry disease. In: The Metabolic Bases of Inherited Disease. 8 ed. New York: McGraw-Hill; 2001. p. 3733–74.  
20  
38. Schiffmann R, Hughes DA, Linthorst GE, Ortiz A, Svarstad E, Warnock DG, et al. Screening, diagnosis, and management of patients with Fabry disease: conclusions from a “Kidney Disease: Improving Global Outcomes”; (KDIGO) Controversies Conference. Kidney Int. 2017; 1;91(2):284–93.  
39. Burlina A, Brand E, Derralynn H, Kantola I, Krӓmer J, Nowak A, et al. An expert consensus on the recommendations for the use of biomarkers in Fabry disease. Molecular Genetics and Metabolism. 2023; 139: 107585. https://doi.org/10.1016/j.ymgme.2023.107585  
40. Linthorst GE, Poorthuis BJHM,  Hollak CEM. Enzyme activity for determination of presence of Fabry disease in women results in 40% false-negative results. J Am Coll Cardiol. 2008;51(21):2082; author reply 2082-3.  doi: 10.1016/j.jacc.2008.02.050.  
41. Laney DA, Bennett RL, Clarke V, Fox A, Hopkin RJ, Johnson J, et al. Fabry Disease Practice Guidelines: Recommendations of the National Society of Genetic Counselors. J Genet Counsel. 2013; 22:555–564 DOI 10.1007/s10897-013-9613-3  
42. Sirrs S, Bichet DG, Iwanochko RM, Khan A, Moore D, Oudit G, et al. Canadian Fabry disease treatment guidelines 2017. Disponível em https://www.fabrycanada.com/content/uploads/Final-Can-FD-Treatment-Guidelines-2017Oct18.pdf  
43. Neumann P, Antongiovanni N, Fainboim A, Kisinovsky I, Amartino H, Cabrera G,et al. Consenso de Médicos de AADELFA y GADYTEF. Guía para el diagnóstico, seguimiento y tratamiento de la enfermedad de Fabry [Guidelines for diagnosis, monitoring and treatment of Fabry disease]. Medicina (B Aires). 2013;73(5):482-94.  
44. Lidove O, West ML, Pintos-Morell G, Reisin R, Nicholls K, Figuera LE, Parini R, Carvalho LR, Kampmann C, Pastores GM, Mehta A. Effects of enzyme replacement therapy in Fabry disease--a comprehensive review of the medical literature. Genet Med. 2010 Nov;12(11):668-79. doi: 10.1097/GIM.0b013e3181f13b75. PMID: 20962662.  
45. Tahir H, Jackson LL, Warnock DG. Antiproteinuric therapy and fabry nephropathy: sustained reduction of proteinuria in patients receiving enzyme replacement therapy with agalsidase-beta. J Am Soc Nephrol. 2007 Sep;18(9):2609-17. doi: 10.1681/ASN.2006121400. Epub 2007 Jul 26. PMID: 17656478.  
46. Jain R, Kalvin L, Johnson B, Muthukumar L, Khandheria BK, Tajik AJ. Many Faces of Fabry's Cardiomyopathy. JACC Cardiovasc Imaging. 2018 Apr;11(4):644-647. doi: 10.1016/j.jcmg.2017.10.018. Epub 2018 Jan 17. PMID: 29361493.  
47. Brasil. Ministério da Saúde. Relatório de Recomendação. Alfagalsidase para o tratamento da doença de Fabry clássica em pacientes a partir dos sete anos de idade Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2023/20230522_relatorio_803_alfagalsidase_doenca_de_fabry-1.pdf  
48. Hopkin RJ, Jefferies JL, Laney DA, Lawson VH, Mauer M, Taylor MR, et al. The management and treatment of children with Fabry disease: A United States-based perspective. Mol Genet Metab. 2016;117(2):104–13.  
49. Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica. Brasil. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica - Portaria SAS/MS no 1.083 - 02/10/2012. Ministério da Saúde. 2012. Em https://www.gov.br/conitec/pt-br/midias/protocolos/dorcronica-1.pdf (Atualização só publicada na forma de CP em https://www.gov.br/conitec/pt-br/midias/consultas/relatorios/2022/20221101_pcdt_dor_cronica_cp74.pdf)  
50. Brasil Ministério da Saúde. Linha de Cuidado do AVC. Disponível em file:///C:/Users/mvinh/Downloads/pcdt-cuidadosAVC.pdf  
51. Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia: prevenção de eventos cardiovasculares e pancreatite. 2020. Em https://www.gov.br/conitec/ptbr/midias/protocolos/publicacoes_ms/pcdt_dislipidemia_prevencaoeventoscardiovascularesepancreatite_isbn_18-082020.pdf].  
21  
52. Protocolo Clínico e Diretrizes Terapêuticas Anemia da Doença Renal Crônica- reposição de ferro. 2017. Em https://www.gov.br/conitec/pt-br/midias/relatorios/2017/relatorio_pcdt_anemiairc_ferro_231.pdf  
53. Protocolo Clínico e Diretrizes Terapêuticas Anemia da Doença Renal Crônica- Alfaepoetina. 2017. Em https://www.gov.br/conitec/pt-br/midias/relatorios/2017/relatorio_pcdt_anemiairc_alfaepoetina_230.pdf  
54. Protocolo Clínico e Diretrizes Terapêuticas Distúrbio Mineral Ósseo na Doença Renal Crônica. 2022. Em https://www.gov.br/conitec/pt-br/midias/relatorios/2022/Relatorioderecomendacao_PCDTDMODRC_FINAL.pdf  
55.  
55. Alfagalsidase Registro ANVISA. Em https://consultas.anvisa.gov.br/#/medicamentos/25351778045202096/?substancia=23552  
56. Betagalsidase Registro ANVISA. Em https://consultas.anvisa.gov.br/#/medicamentos/25351778045202096/?substancia=23552  
57. Migalastate Registro ANVISA. Em  
- https://consultas.anvisa.gov.br/#/medicamentos/25351816326202135/?substancia=26515  
58. Biegstraaten M, Arngrímsson R, Barbey F, Boks L, Cecchi F, Deegan PB, et al. Recommendations for initiation and cessation of enzyme replacement therapy in patients with Fabry disease: the European Fabry Working Group consensus document. Orphanet J Rare Dis. 2015;10:36.  
59. El Dib R, Gomaa H, Ortiz A, Politei J, Kapoor A, Barreto F. Enzyme replacement therapy for Anderson-Fabry disease: a complementary overview of a Cochrane publication through a linear regression and a pooled analysis of proportions from cohort studies. PLoS One. 2017 Mar;12(3):e0173358.  
60. Niemann M, Herrmann S, Hu K, Breunig F, Strotmann J, Beer M, et al. Differences in Fabry cardiomyopathy between female and male patients: consequences for diagnostic assessment. JACC Cardiovasc Imaging. 2011 Jun;4(6):592-601.  
61. Whybra C, Kampmann C, Krummenauer F, Ries M, Mengel E, Miebach E, et al. The Mainz Severity Score Index: a new instrument for quantifying the Anderson-Fabry disease phenotype, and the response of patients to enzyme replacement therapy. Clin Genet. 2004 Apr;65(4):299-307.  
62. Hughes DA, Ramaswami U, Romero MÁB, Deegan P, FOS Investigators. Age adjusting severity scores for AndersonFabry disease. Mol Genet Metab. 2010 Oct/Nov;101(2-3):219-27.  
63. Ramaswami U, Stull DE, Parini R, Pintos-Morell G, Whybra C, Kalkum G, et al. Measuring patient experiences in Fabry disease: validation of the Fabry-specific Pediatric Health and Pain Questionnaire (FPHPQ). Health Qual Life Outcomes. 2012 Sep;10:116.  
64. Holmes A, Laney D. A Restrospective Survey Studing the Impact of Fabry Disease on Pregnancy. JIMD Rep. 2015;21:57--63. Blasco F, Guillámon AE, Muñoz S. Enfermedad de Fabry y embarazo. Situación actual y revisión de la  
65. evidencia. Clínica e Investigación en Ginecología y Obstetricia. 2021; 8(3):100646..  
66. Blasco F, Guillámon AE, Muñoz S. Enfermedad de Fabry y embarazo. Situación actual y revisión de la evidencia. Clínica e Investigación en Ginecología y Obstetricia. 2021; 8(3):100646.  
67. Lee K, Jin X, Zhang K, Copertino L, Andrews L, Baker-Malcolm J et al. A biochemical and pharmacological comparison of enzyme replacement therapies for the glycolipid storage disorder Fabry Disease. Glycobiology. 2003; 13 (4):305-13.  
68. Pisani A, Bruzzese D, Sabbatini M, Spinelli L, Imbriaco M et al. Switch to agalsidase alfa after shortage of agalsidase beta in Fabry disease: a systematic review and meta-analysis of the literature. Genet Med. 2017; 19 (3):275-282. doi: 10.1038/gim.2016.117.  
69. Brasil, Ministério da Saúde. Portaria nº 199, de 30 de janeiro de 2014. Institui a Política Nacional de Atenção Integral às Pessoas com Doenças Raras, aprova as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no âmbito do 22  
Sistema Único de Saúde (SUS) e institui incentivos financeiros de custeio. Em https://bvsms.saude.gov.br/bvs/saudelgis/gm/2014/prt0199_30_01_2014.html  
70. Brasil, Brasil. Ministério da Saúde. Diretrizes para Atenção Integral às Pessoas com Doenças Raras. Em https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_atencao_integral_pessoa_doencas_raras_SUS.pdf  
71. Brasil, Ministério da Saúde. Portaria de Consolidação GM/MS nº 2, de 28 de setembro de 2017. Em:https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html  
72. Brasil. Ministério da Saúde.  Portaria de Consolidação GM/MS nº 6, de 28 de setembro de 2017. https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.html  
23

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Eu, _____________________________________________________________________________________________ (nome do[a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de alfagalsidase e beta-agalsidase, indicada para o tratamento de Doença de Fabry.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)  
_____________________________________________________________________________________________________  
(nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Evitar, reduzir ou estabilizar a perda da função dos rins;  
- Evitar, reduzir ou estabilizar as disfunções do coração (alterações da massa do ventrículo esquerdo, arritmias).  
- Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
 Os medicamentos alfagalsidase e beta-agalsidase são classificados na gestação como categoria B (não há estudos adequados em mulheres e em experimentos com animais não foram encontrados riscos).  
 Os eventos adversos mais comuns dos medicamentos são: cefaleia, náusea, fadiga, diarreia, tosse, vômitos, tontura, artralgia, dor nas costas, pirexia, nasofaringite, parestesia, dor abdominal, dispneia, dor nos membros, dor no peito, palpitações, dor, mialgia, hipoestesia, faringite, astenia, calafrios, dor neuropática, erupção cutânea, edema periférico, zumbidos e tremores.  
- Esses medicamentos podem levar os pacientes a desenvolverem anticorpos contra a proteína que o compõe.  
- Consultas e exames durante o tratamento são necessários.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido.  
Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
Meu tratamento constará do seguinte medicamento:  
(    ) Alfagalsidase (    ) Beta-agalsidase  
24  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
25

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização das Diretrizes Brasileiras para Diagnóstico e Tratamento da Doença de Fabry (DF) (publicada pela Portaria Conjunta SAES-SCTIE/MS nº 20, de 06/12/2021), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados. Com a incorporação do tratamento medicamentoso específico, o formato do documento foi alterado para Protocolo Clínico e Diretrizes Terapêuticas (PCDT).  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Esse Protocolo considerou as melhores evidências advindas da literatura, de diretrizes clínicas já publicadas por outros órgãos ou entidades nacionais e internacionais para o diagnóstico, tratamento e monitorização desses pacientes. A atualização do documento também considerou o conteúdo dos seguintes documentos já publicados pela CONITEC: a) Diretrizes Brasileiras para Diagnóstico e Tratamento da DF (Portaria Conjunta SAES-SCTIE/MS nº 20 de 06/12/2021)<sup>**1**</sup> ; b) Relatório de Recomendação n<sup>o</sup> 803, de março de 2023, que avaliou o uso de alfagalsidase para tratamento da DF clássica em pacientes com sete anos de idade ou mais<sup>**2**</sup> ; e c) Relatório de Recomendação nº 865, de dezembro de 2023, que avaliou o uso de beta-agalsidase para o tratamento da doença de Fabry clássica.  
Na reunião de alinhamento para atualização do documento definiu-se que o PCDT da DF deveria focar na inclusão da TRE, revisão do texto e reorganização do documento, tendo como público-alvo primário: clínicos gerais, geneticistas, urologistas, nefrologistas, neurologistas, cardiologistas e, como público-alvo secundário: oftalmologistas, gastroenterologistas, neuropatologistas, hematologistas e outros especialistas médicos.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
O Protocolo foi atualizado pelo NATS do Hospital das Clínicas de Porto Alegre.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
26  
**Quadro A** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos b|enefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de<br>alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|  
27  
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|---|---|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
A proposta de atualização do PCDT de Doença de Fabry foi apresentada na 109ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em novembro de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec mas sua apreciação foi adiada devido à decisão de incorporação de beta-agalsidase.  
Após a inclusão de orientações sobre beta-agalsidase, a nova proposta de atualização do PCDT de Doença de Fabry foi apresentada na 113ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em março de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 128ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto, tendo sido o mesmo encaminhado à consulta pública.

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
A Consulta Pública nº 19/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Doença de Fabry, foi realizada entre os dias 09/05/2024 a 28/05/2024. Foram recebidas 217 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicoes-da-consulta-publica-19-2024-protocoloclinico-e-diretrizes-terapeuticas-da-doenca-de-fabry .

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>3</sup> . Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas.  
Foram realizadas buscas sistematizadas da literatura nas bases de dados Medline, Embase, BVS (incluindo Lilacs) e Cochrane Library.  
Por se tratar de atualização de documentos oficiais já publicados, seguindo as recomendações da Cochrane, optou-se por definir uma data de início para as buscas, baseada nas informações da diretriz clínica publicada pelo Ministério da Saúde em 2021 e dos dois Relatórios de Recomendação de tecnologias considerados neste PCDT.  
Assim, em relação às diretrizes clínicas para a Doença de Fabry (DF), as bases de dados foram pesquisadas de 01 de janeiro de 2021 até a data de 15 de setembro de 2023 (data final da busca). Em relação às buscas sobre o medicamento alfagalsidase, como o relatório de incorporação foi publicado em março de 2023, suas buscas foram atualizadas até outubro de 2023. Por fim, a busca relacionada à beta-alglicosidase foi atualizada até 31 de dezembro de 2023.  
28  
Foram realizadas diferentes buscas, cada uma associada a uma diferente questão, a saber:  
a) primeira pergunta e estratégia de busca (Busca I) procurou identificar estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com DF;  
b) duas diferentes questões e estratégias de busca (Buscas II e III) focaram na identificação de estudos clínicos, revisões sistemáticas sobre o tratamento da DF em populações especiais de gestantes e lactantes, posto que a doença ocorre durante anos de idade fértil;  
c) uma última questão e estratégia de busca (Busca IV) foi construída para identificar estudos clínicos e revisões sistemáticas sobre a tecnologia incorporada, alfagalsidase, para o tratamento primário da DF.  
As quatro diferentes questões e estratégias de busca são apresentadas nos Quadros A a H e versam, respectivamente, sobre protocolos clínicos ou diretrizes de diagnóstico/acompanhamento/cuidados/tratamento para DF, aspectos específicos destas populações especiais (gestantes e lactentes) e o medicamento alfagalsidase na DF.  
**Questão I** – Quais são as evidências (na forma de estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou recomendações clínicas) sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com DF, produzidas a partir de 2021?  
A pergunta PICOT elaborada para responder à questão I se encontra no Quadro B:  
**Quadro B** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com Doença de Fabry (DF)|
|---|---|
|Intervenção|Tratamento: não medicamentoso, sintomático/suporte, primário com<br>Alfagalasidase ou Beta-agalsidase,|
|Comparador(es)|Tratamento: não medicamentoso, sintomático/suporte|
|Desfecho(s)|Diagnóstico<br>Seguimento<br>Eficácia:<br>- Desfechos renais: TFG, proteinúria, albuminúria, diálise ou transplante<br>renal;<br>- Desfechos cardíacos: massa ventricular esquerda, arritmias, insuficiência<br>cardíaca;<br>- Desfechos gerais: dor, qualidade de vida, mortalidade e acúmulo tecidual<br>de GL3.<br>Segurança|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos, revisões sistemáticas e diretrizes, protocolos ou<br>recomendações clínicas|  
*Por se tratar de atualização de recomendação, incluiu-se publicações produzidas a partir da data inicial 01/01/2021  
No total, foram 120 publicações das bases de dados (Quadro C). Excluindo-se as duplicatas (77), restaram 43 títulos, dos quais 41 foram excluídos na fase de título e resumo. Os dois restantes, que foram incluídos ao final, eram diretrizes de diagnóstico, acompanhamento e tratamento, brasileiras, uma para pacientes pediátricos com DF e outra para adultos.  
29  
**Quadro C** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou estudos clínicos e diretrizes clínicas ou protocolos clínicos ou recomendações clínicas sobre diagnóstico/acompanhamento/cuidados/tratamento para DF  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|Medline (via Pubmed)|(fabry disease[Title/Abstract]) AND<br>((guidelines[Title/Abstract]) OR<br>(recommendation[Title/Abstract]))|33 artigos|
|Embase|('practice guideline' OR ‘recommendations’) AND 'fabry<br>disease':ti,ab,kw AND [2021-2023]/py|48 artigos|
|BVS|(fabry disease) AND ((guidelines) OR<br>(recommendations))- Title, abstract, subject|37 artigos|
|Cochrane library|"Fabry disease" in Title Abstract Keyword AND<br>(guidelines OR recommendations) in Title Abstract<br>Keyword - (Word variations have been searched)|02 artigos,<br>Zero Cochrane Reviews|  
**Nota** : Realizadas entre 01 de janeiro de 2021 e 15 de setembro de 2023.  
Adicionalmente, na busca por diretrizes clínicas, protocolos clínicos e recomendações clínicas sobre diagnóstico, acompanhamento, cuidados e tratamento para DF foram também avaliados os seguintes documentos:  
- NICE _guidelines_ (http://www.nice.org.uk): nenhuma diretriz localizada contemplando TRE em DF e uma diretriz localizada sobre uso da chaperona, migalastate, na DF. **Sem mudanças desde a pesquisa realizada para a diretriz publicada**  
**em 2021** .  
- _National Guideline Clearinghouse_ – http://www.guideline.gov: uma diretriz localizada, sobre aconselhamento genético  
- e aspectos de diagnósticos da DF. **Sem mudanças desde a pesquisa realizada para a diretriz publicada em 2021** .  
- _National Library of Australia. Department of Health and Ageing, Australian Government_ http://www.health.gov.au= uma diretriz localizada sobre tratamento para DF. **Sem mudanças desde a pesquisa realizada para a diretriz publicada em 2021** .  
- _Guideline International Network_ – http://www.g-i- n.net/library/international-guidelines- library: nenhuma diretriz  
- localizada. **Sem mudanças desde a pesquisa realizada para a diretriz publicada em 2021** .  
- Sociedade Brasileira de Genética Médica (SBGM) - http://www.sbgm.org.br: nenhuma diretriz localizada. **Sem**  
- **mudanças desde a pesquisa realizada para a diretriz publicada em 2021** .  
- Diretrizes da Associação Médica Brasileira (AMB) - http://diretrizes.amb.org.br: nenhuma diretriz localizada. **Sem**  
- **mudanças desde a pesquisa realizada para a diretriz publicada em 2021** .  
A pesquisa para diretrizes clínicas internacionais, na SBGM ou na AMB não encontrou literatura nova em relação àquelas consideradas em 2021, não havendo também atualização dos documentos encontrados previamente.  
30  
**A Figura** : A apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
<!-- Start of picture text -->
Titulos identificados: Titulos removidos antes do Titulos identificados:<br>(n=120) Duplicatas removidas (n=77) oe<br>| Bases de dados e Registros processo de screening: nesmicaace, Busca<br>(n=0)<br>(n=43) (n=41) Titulos buscados (n = 0) maEg<br>! Titulos selecionados Titulos exctuidos Titulos nao<br>Titulos buscados (n=2) . Titulos avaliados para<br>Titulos ndo encontrados (n = 0) yiade ro)<br>Titulos _avaliados para<br><!-- End of picture text -->  
<!-- Start of picture text -->
elegibilidade (n=2 ) Titulos excluidos (n =0 )<br>(n=2)<br>Totalincluidosdena revisaoestudos(n =2NOVOS)<br><!-- End of picture text -->  
**Figura A** - Diagrama de PRISMA- atualização sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com DF, produzidas a partir de 2021 (pesquisas em bases de dados, registros e outras fontes). Ref.  Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
A pergunta PICOT elaborada para responder à questão II se encontra no Quadro D.  
**Quadro D** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Gestantes com Doença de Fabry (DF)|
|---|---|
|Intervenção|Tratamento primário para DF com Alfagalasidase ou Beta-agalsidase,|
|Comparador(es)|Sem tratamento primário para DF|
|Desfecho(s)|Segurança<br>Eficácia**|
|Tipos de estudo (desenhos) de interesse|Estudos clínicos e revisões sistemáticas|  
*Por se tratar de atualização de recomendação, incluiu-se publicações produzidas a partir da data inicial 01/01/2021.  
**Eficácia traduzida como: desfechos renais: TFG, proteinúria, albuminúria, diálise ou transplante renal; desfechos cardíacos: massa ventricular esquerda, arritmias, insuficiência cardíaca; desfechos gerais: dor, qualidade de vida, mortalidade e acúmulo tecidual de GL3.  
No total foram 10 publicações das bases de dados (Quadro E). Excluindo-se as duplicatas, restaram 5 títulos, tendo sido todos eles excluídos já na fase de leitura de título e resumo. Assim, não foram incluídos títulos para análise neste tópico.  
31  
**Quadro E** . Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre tratamento primário para DF e gestação/gravidez.  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Medline (via Pubmed)|(fabry disease[Title/Abstract]) AND (pregnancy[Title/Abstract])|02 artigos|
|Embase|'pregnancy' AND 'fabry disease':ti,ab,kw AND [2021-2023]/py|05 artigos|
|BVS|(fabry disease) AND (pregnancy)- Title, abstract, subject|03 artigos|
|Cochrane library|"Fabry disease" in Title Abstract Keyword AND pregnancy in Title<br>Abstract Keyword - (Word variations have been searched)|Zero Cochrane<br>Reviews e artigos|  
Nota: Realizadas entre 01 de janeiro de 2021 e 15 de setembro de 2023.  
A Figura B apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
<!-- Start of picture text -->
Titulos identiicados: Titulos removidos antes do Titulos identiicados: Busca nas<br>Bases de dados e Registros processo de screening: referéncias/citacdes (n =0)<br>(n= 10) Duplicatas removidas (n = 5)<br>Titulos(n=5) selecionados Titulos(n=5) excuidosi ‘Thos buscadosjade (n= 0) Tituloseneoo nao<br>_eeee<br>| Titulos __avaliados. para itulos (n=<br>Novos estudos incluidos<br>(n=0)<br>Total de estudos ~NOVOS<br>incluidos na revisao (n = 0)<br><!-- End of picture text -->  
**Figura B** - Diagrama de PRISMA- atualização sobre aspectos de tratamento de DF em gestantes, produzidas a partir de 2021 (pesquisas em bases de dados, registros e outras fontes). Ref.  Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71.  
32

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
|A pergunta PICOT elaborada para resp<br>**Quadro F**- Pergunta PICOT (população, intervenção, co<br><br>|onder à questão III se encontra no Quadro F:<br>mparador, desfechos e tipos de estudos) elaborada*.<br> <br>|
|---|---|
|População<br>|Lactantes com Doença de Fabry (DF)<br>|
|Intervenção<br>|Tratamento primário para DF com Alfagalasidase ou Beta-agalsidase,<br>|
|Comparador(es)<br>|Sem tratamento primário para DF<br>|
|Desfecho(s)<br>|Segurança<br>Eficácia**<br>|
|Tipos de estudo (desenhos) de interesse<br>|Estudos clínicos e revisões sistemáticas<br>|
|*Por se tratar de atualização de recomendação, incluiu-se<br>**Eficácia traduzida como: desfechos renais: TFG, prot<br>arritmias, insuficiência cardíaca; desfechos gerais: dor, qu<br>|publicações produzidas a partir da data inicial 01/01/2021<br>einúria, albuminúria, diálise ou transplante renal; desfechos cardíacos: massa ventricular esquerda,<br>alidade de vida, mortalidade e acúmulo tecidual de GL3.<br>|  
No total, foram 2 publicações das bases de dados (Quadro G). Não havendo duplicatas, ambos os títulos foram excluídos já na fase de leitura de título e resumo. Desta forma, não foram incluídos títulos para análise neste tópico.  
|**Quadro G.**Estratégias de busca,<br>amamentação<br>|de acordo com a base de dados, para identificação de revisões sistemáticas ou es<br>|tudos clínicos DF sobre tratamento primário e<br>**Número de resultados**<br>|
|---|---|---|
|**Bases de dados**<br>|**Estratégia de busca**<br>|<br>**encontrados**<br>|
|Medline (via Pubmed)<br>|(fabry disease[Title/Abstract]) AND<br>(breastfeeding[Title/Abstract])<br>|Zero artigos<br>|
|Embase<br>|'breastfeeding' AND 'fabry disease':ti,ab,kw AND [2021-<br>2023]/py<br>|Zero artigos<br>|
|BVS<br>|(fabry disease) AND (breastfeeding)- Title, abstract, subject<br>|Zero artigos<br>|
|Cochrane library<br>|Title Abstract Keyword AND breastfeeding in Title Abstract<br>Keyword - (Word variations have been searched)<br>|02 artigos,<br>Zero Cochrane Reviews<br>|
|**Nota**: Buscas realizadas entre 01<br>|de janeiro de 2021 e 15 de setembro de 2023.<br>||
|33|||  
A **Figura C** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
<!-- Start of picture text -->
Titus identiicados: Titulos temovides antes do Titulos identiicados: Busca nas<br>Bases de dados e Registros proceso de screening: referéncias/etacdes (n =0)<br>; (n=2) ' ; ‘Duplcatas; removidas (n = 0) Tiulos do<br>‘Tinsos seteclonasos Tinton exctoiéos Titulos buscados (n=0) || encontrados<br>wo (2) in=0)<br>TTitulos buscados (n =0) Titulo no encontrados (n =0) Seeman<br>| ince OO Titulos excluidos (n= 0)<br>Novos estudesincuidos<br>(n=0)<br>Totalincluidsdena revisioestudos_NOVOS (n = 0)<br><!-- End of picture text -->  
**Figura C** - Diagrama de PRISMA- atualização sobre aspectos de (na forma de estudos clínicos e revisões sistemáticas) sobre o tratamento da DF em lactantes, (produzidas a partir de 2021). Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71.  
**Questão IV Quais os dados disponíveis, advindos de estudos clínicos e revisões sistemáticas, sobre a tecnologia alfagalsidase para o tratamento primário da DF, produzidas a partir de 2022?**  
A pergunta PICOT elaborada para responder à questão IV se encontra no Quadro H:  
**Quadro H** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com Doença de Fabry (DF)|
|---|---|
|Intervenção|Tratamento primário para DF com Alfagalasidase,|
|Comparador(es)|Sem tratamento primário para DF ou com beta-agalsidase|
|Desfecho(s)|Eficácia:<br>- Desfechos renais: TFG, proteinúria, albuminúria, diálise ou transplante<br>renal;<br>- Desfechos cardíacos: massa ventricular esquerda, arritmias, insuficiência<br>cardíaca;|
||- Desfechos gerais: dor, qualidade de vida, mortalidade e acúmulo tecidual<br>de GL3<br>Segurança|
|Tipos de estudo (desenhos) de interesse|estudos clínicos, revisões sistemáticas|  
*Por se tratar de atualização de recomendação de incorporação, incluiu-se publicações produzidas a partir da data inicial 01/01/2022  
34  
No total foram identificadas 200 publicações das bases de dados (Quadro I). Excluindo-se as duplicatas, restaram 154 títulos, dos quais 152 foram excluídos na fase de título e resumo.  
**Quadro I.** Estratégias de busca, de acordo com a base de dados, p/ identificação de revisões sistemáticas e/ou estudos clínicos sobre uso da alfagalsidase em DF  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Medline (via Pubmed)|((((((((("Agalsidase alfa"[Supplementary Concept]) OR ("Agalsidase<br>alfa"[Text Word])) OR ("Agalsidase-alpha"[Text Word])) OR<br>("Recombinant alfa-galactosidase A"[Text Word])) OR ("Recombinant<br>alpha-galactosidase A"[Text Word])) OR ("Replagal"[Text Word])) OR<br>("Alfagalsidase"[Text Word])) OR ("Alphagalsidase"[Text Word])) OR<br>("Alfaagalsidase"[Text Word])) OR ("Alpha-agalsidase"[Text Word])|35 artigos|
|Embase|('agalsidase alfa'/exp OR 'agalsidase alfa':ti,ab,kw OR 'agalsidase-<br>alpha':ti,ab,kw OR 'recombinant alfa-galactosidase a':ti,ab,kw OR<br>'recombinant alpha-galactosidase a':ti,ab,kw OR 'replagal':ti,ab,kw OR<br>'alfagalsidase':ti,ab,kw OR 'alphagalsidase':ti,ab,kw OR<br>'alfaagalsidase':ti,ab,kw OR 'alpha-agalsidase':ti,ab,kw) AND<br>[embase]/lim|150 artigos|
|BVS|(("Agalsidase alfa") OR ("Agalsidase-alpha") OR ("Recombinant alfa-<br>galactosidase A") OR ("Recombinant  alpha-galactosidase A") OR<br>("Replagal") OR ("Alfagalsidase") OR ("Alphagalsidase") OR ("Alfa<br>agalsidase") OR ("Alpha-agalsidase") )<br>Title, abstract, subject|14 artigos|
|Cochrane library|("Agalsidase alfa") OR ("Agalsidase-alpha") in Title Abstract Keyword<br>OR ("Recombinant alfagalactosidase A") OR ("Recombinant alpha-<br>galactosidase A") in Title Abstract Keyword OR ("Replagal") in Title<br>Abstract Keyword OR ("Alfagalsidase") OR ("Alphagalsidase") in Title<br>Abstract Keyword OR ("Alfaagalsidase") OR ("Alpha-agalsidase") in<br>Title Abstract Keyword - (Word variations have been searched)|01 artigo,<br>Zero Cochrane<br>Reviews|  
**Nota** : Buscas realizadas entre 01 de janeiro de 2022 e 15 de setembro de 2023.  
Os dois estudos analisados eram coortes e tratavam de dados dos pacientes seguidos pelo _Fabry Outcome Survey_ (FOS), um registro mundial estabelecido pelo fabricante da alfagalsidase e iniciado em 2001, com pacientes egressos dos primeiros estudos clínicos deste medicamento. Este registro seguiu armazenando dados dos pacientes após o fim oficial do estudo clínico e conta com alguns pacientes com mais de 20 anos de acompanhamento. Sendo assim, não foram incluídos ao final. Os estudos excluídos e razão de exclusão estão descritos no Quadro J.  
35  
**Quadro J** . Estudos excluídos durante a fase de elegibilidade (texto completo) com motivo da exclusão  
|**Artigos excluídos na fase de elegibilidade (texto completo)-  Busca IV**|**Razão da exclusão**|
|---|---|
|_Giugliani et al._,Long-term outcomes in patients with Fabry disease who were<br>treated with agalsidase alfa for more than nineteen years: The Fabry Outcome<br>Survey. Molecular Genetics and Metabolism. 2023.138:107118|Coorte (desenho não contemplado na<br>pergunta PICOT)|
|Beck et al. Twenty years of the Fabry Outcome Survey (FOS): insights,||
|achievements, and lessons learned from a global patient registry. Orphanet|Coorte (desenho não contemplado na|
|Journal of Rare Diseases (2022) 17:238 https://doi.org/10.1186/s13023-022-|pergunta PICOT)|
|02392-9||  
A **Figura D** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
<!-- Start of picture text -->
TitulosBases(n= identiicados: 200)de dados © Registros TosprocessoDuplicatasremovdosde screening. removidasantes (n =48)do ilsWebsitesCesBusca=0)  nas entcados, (n reteranclasietagBesGes = th <0) (0<br>(a=2)Titulos selecionados (9152)Titulos exctuidos Titulos buscados (n = 0) encontradosa=)Titulos nao<br>Titulos _avaliados para<br>Titulos _avaliados para |__+] Tiuios exclidos (n=2)<br>elegibiidade (n =0)<br>Novos estudos incuidos<br>(0=0)<br>Total de estudos _NOVOS<br>incluidos na revisio (n =0)<br><!-- End of picture text -->  
**Figura D** - Diagrama de PRISMA- atualização sobre aspectos de (na forma de estudos clínicos e revisões sistemáticas) sobre o uso da alfagalsidase no tratamento da DF, (produzidas a partir de 2022).

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
A pergunta PICOT elaborada para responder à questão IV se encontra no Quadro K:  
**Quadro K** - Pergunta PICOT (população, intervenção, comparador, desfechos e tipos de estudos) elaborada*.  
|População|Pacientes com Doença de Fabry (DF)|
|---|---|
|Intervenção|Tratamento primário para DF com Beta-agalasidase,|
|Comparador(es)|Sem tratamento primário para DF ou com alfagalsidase|
|Desfecho(s)|Eficácia:<br>Desfechos renais: TFG, proteinúria, albuminúria, diálise ou transplante renal;|  
36  
||Desfechos cardíacos: massa ventricular esquerda, arritmias, insuficiência cardíaca;|
|---|---|
||Desfechos gerais: dor, qualidade de vida, mortalidade e acúmulo tecidual de GL3<br>Segurança|
|Tipos<br>de<br>estudo<br>(desenhos) de interesse|Estudos clínicos, revisões sistemáticas|  
No total foram identificadas 113 publicações das bases de dados (Quadro L). Excluindo-se as duplicatas, restaram 77 títulos, dos quais 73 foram excluídos na fase de título e resumo.  
**Quadro L.** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas e/ou estudos clínicos sobre uso da beta-agalsidase em DF  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Medline<br>(via<br>Pubmed)|((((agalsidase beta[Supplementary Concept]) OR (agalsidase beta[Text<br>Word])) OR (fabrazyme[Text Word])) OR (beta-agalsidase[Text Word]))<br>OR (recombinant agalsidase beta[Text Word])|34 artigos|
|Embase|'agalsidase beta':ti,ab,kw OR 'beta agalsidase':ti,ab,kw OR<br>fabrazyme:ti,ab,kw AND [embase]/lim|42 artigos|
|BVS|(agalsidase beta OR fabrazyme OR beta-agalsidase OR recombinant beta-<br>agalsidase) Title, abstract, subject|30 artigos|
|Cochrane library|agalsidase beta in Title Abstract Keyword OR fabrazyme in Title Abstract<br>Keyword OR beta-agalsidase in Title Abstract Keyword OR recombinant<br>beta-agalsidase in Title Abstract Keyword - with Cochrane Library (Word<br>variations have been searched)|07 artigos,<br>Zero<br>Cochrane<br>Reviews|  
**Nota** : Buscas realizadas entre 01 de janeiro de 2022 e 31 de dezembro de 2023.  
Os quatro estudos analisados eram coortes e tratavam de dados dos pacientes seguidos pelo _Fabry Registry_ , um registro mundial estabelecido pelo fabricante da beta agalsidase com pacientes egressos dos primeiros estudos clínicos deste medicamento. Este registro seguiu armazenando dados dos pacientes após o fim oficial do estudo clínico e conta com alguns pacientes com mais de 20 anos de acompanhamento. Sendo assim, não foram incluídos ao final. Os estudos excluídos e razão de exclusão estão descritos no Quadro M.  
**Quadro M** . Estudos excluídos durante a fase de elegibilidade (texto completo) com motivo da exclusão  
|**Artigos excluídos na fase de elegibilidade (texto completo)-  Busca V**|**Razão da exclusão**|
|---|---|
|Wanner et al. Global reach of over 20 years of experience in the patient-centered Fabry|Coorte (desenho não|
|Registry: Advancement of Fabry disease expertise and dissemination of real-world|contemplado na pergunta|
|evidence to the Fabry community. Mol Genet Metab. 2023 Jul;139(3):107603. doi:|PICOT)|  
37  
|**Artigos excluídos na fase de elegibilidade (texto completo)-  Busca V**|**Razão da exclusão**|
|---|---|
|10.1016/j.ymgme.2023.107603. Epub 2023 Apr 29. PMID: 37236007.||
|Nowak et al. Agalsidase-β should be proposed as first line therapy in classic male Fabry<br>patients with undetectable α-galactosidase A activity. Mol Genet Metab. 2022 Sep-<br>Oct;137(1-2):173-178. doi: 10.1016/j.ymgme.2022.08.003. Epub 2022 Aug 23. PMID:<br>36087505.|Coorte (desenho não<br>contemplado na pergunta<br>PICOT)|
|Hopkin et al. Clinical outcomes among young patients with Fabry disease who initiated|Coorte (desenho não|
|agalsidase beta treatment before 30 years of age: An analysis from the Fabry Registry.|contemplado na pergunta|
|Mol Genet Metab. 2023 Feb;138(2):106967. doi: 10.1016/j.ymgme.2022.106967. Epub<br>2022 Nov 30. PMID: 36709533:|PICOT)|
|van der Veen et al. Early start of enzyme replacement therapy in pediatric male patients|Coorte (desenho não|
|with classical Fabry disease is associated with attenuated disease progression. Mol|contemplado na pergunta|
|Genet Metab. 2022 Feb;135(2):163-169. doi: 10.1016/j.ymgme.2021.12.004. Epub 2021|PICOT)|
|Dec 17. PMID: 35033446.||  
A **Figura E** apresenta o resumo do processo de busca, triagem, análise de elegibilidade e inclusão realizadas.  
<!-- Start of picture text -->
Ths enteaos Tihios removes antes do wenstesTeeton=<br>nce ao dade © Restos onsen to soceang Seer aces<br>oon Sips vont =<br>(n=36)<br>Titulos selecionados Titulos excluidos Titulos buscados (n = 0) encontradosTitulos nao.<br>(0277) (n=73) (n=0)<br>Temoenennae oo Tilesomen?avatovos para<br>‘Titulos avaliados para Titulos excluidos (n=4)<br>Saguiade es<br>Novos estudos incluidos<br>(=0)<br>Teal de estos _NOvOS<br>incluidos na revisdo (n =0)<br><!-- End of picture text -->  
**Figura E** - Diagrama de PRISMA- atualização sobre aspectos de (na forma de estudos clínicos e revisões sistemáticas) sobre o uso da beta-agalsidase no tratamento da DF, (produzidas a partir de 2022).  
Para todas as buscas realizadas (de I a V), foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Pacientes com DF, independente da faixa etária.  
Em relação às buscas II e III, específicas para gestantes e lactantes, apenas este grupo de pacientes com DF foi considerado.  
38  
- (b) Tipo de intervenção  
Tratamento primário com alfagalsidase ou com beta-agalsidase ou sintomáticos ou suporte.  
- (c) Tipos de estudos  
Ensaios clínicos e revisões sistemáticas.  
A primeira estratégia de busca incluiu ainda diretrizes clínicas, protocolos clínicos e recomendações clínicas sobre aspectos de diagnóstico, seguimento, cuidados e tratamento daqueles com DF.  
- (d) Desfechos  
Eficácia e Segurança (em relação à busca I, que envolveu diretrizes, os aspectos de diagnóstico e seguimento clínico também foram considerados).  
- (e) Idioma  
Sem restrição de idioma.  
- (f) Período temporal  
As buscas para as perguntas de pesquisa I a III utilizaram como data de início 01 de janeiro de 2021, posto que a diretriz prévia para DF foi publicada em outubro de 2021. Já as buscas relacionadas às perguntas de pesquisa IV e V utilizaram como data de início 01 de janeiro de 2022, posto que a recomendação para inclusão de alfagalsidase ocorreu em março de 2023 e a da beta-agalsidase em dezembro de 2023.  
Análise e apresentação dos resultados  
Este Protocolo é uma atualização e decorre da incorporação de duas tecnologias, após recomendação favorável pela Conitec, para tratamento primário da DF. Os documentos (Diretrizes Brasileiras de DF e os Relatórios de Recomendação referentes à alfagalsidase e beta-agalsidase) foram considerados recentes, tendo sido publicados em 2021 e 2023, respectivamente. Assim, as buscas de evidências foram desenhadas para encontrar atualizações das evidências previamente analisadas para os dois documentos.  
As buscas não indicaram uma atualização relevante da literatura avaliada desde a publicação das Diretrizes Brasileiras para Doença de Fabry<sup>**1**</sup> em outubro de 2021 e dos Relatório de Recomendação referente às alfagalsidase e beta-agalsidase, em 2023. Contudo, nas buscas feitas foram encontradas diretrizes nacionais de diagnóstico, acompanhamento e tratamento para Doença de Fabry em adultos<sup>**4**</sup> e na população pediátrica<sup>**5**</sup> , ambas publicadas em 2022, sob os auspícios do Comitê de doenças raras (Comdora) da Sociedade Brasileira de Nefrologia (SBN). Estas duas diretrizes foram avaliadas pelo instrumento AGREE II.  
Não foram encontradas diretrizes ou protocolos clínicos internacionais novos ou atualizações daqueles já existentes e previamente publicados. Em relação à alfagalsidase e à beta-agalsidase, não foram detectados na literatura novos ensaios clínicos ou revisões sistemáticas novas.  
Resumo das evidências:  
Em relação às buscas realizadas, apenas na questão referente às diretrizes para diagnóstico, tratamento ou monitorização da DF, foram encontradas novas referências, incluídas neste Protocolo, sendo as duas diretrizes brasileiras de 2022<sup>**4,5**</sup> .  
A diretriz de Silva et al<sup>**4**</sup> versa sobre recomendações de diagnóstico, triagem e tratamento da DF. Em relação ao tratamento, os autores tentaram definir critérios claros para início e interrupção de terapia específica e de medidas adjuntas. Segundo esta diretriz, o primeiro passo para confirmar o diagnóstico de DF é medir a atividade da enzima ααGAL-A, que pode ser realizada  
39  
via plasma, leucócitos ou pelo método de gota de sangue seco em papel filtro (no inglês _dried blood spot_ -DBS). Indivíduos do sexo masculino com formas clássicas da DF têm atividade enzimática muito baixa (<5%) ou ausente, enquanto os casos da forma de início tardio apresentam níveis variáveis de atividade enzimática (5-30%). Embora este seja um método altamente sensível para homens, em indivíduos do sexo feminino com DF que apresentam atividade enzimática normal a ligeiramente diminuída, o método diagnóstico para a doença envolve a identificação de mutações no gene da ααGAL-A.  
Em relação à triagem para a DF, a diretriz define os seguintes pontos: a triagem da população em geral não é recomendada neste momento; recomenda-se a triagem de famílias de um caso índice; recomenda-se a triagem de indivíduos de todas as idades com distúrbios renais, cardíacos ou neurológicos ou sinais ou sintomas clínicos sugestivo de DF, sem etiologia definida; e recomenda-se a triagem de mulheres de todas as idades com alterações renais, cardíacas ou neurológicas de etiologia indefinida ou com sintomas potencialmente atribuíveis à DF.  
A diretriz pediátrica de Veisbich et al<sup>**5**</sup> recomenda a investigação das crianças familiares de um caso índice, assim como de casos com clínica sugestiva. Segundo a conclusão dos elaboradores da referida diretriz, os benefícios do tratamento precoce são grandes, principalmente quanto aos parâmetros de dor neuropática e do acometimento renal.  
Em relação ao início de terapia primária para DF, os autores das diretrizes recomendam oferecê-la àqueles com forma clássica, nas seguintes situações: 1) Paciente do sexo masculino, sintomático ou assintomático, deve ser considerada e aplicada em todos os pacientes, em qualquer idade de apresentação; 2) Paciente do sexo feminino, sintomática quando houver sinais e/ou sintomas sugestivos de envolvimento renal associados à DF: 3) paciente do sexo feminino assintomática se houver evidências disponíveis de exames laboratoriais, histológicos ou de lesão renal, como diminuição da TFG (< 90 mL/min/1,73m<sup>2</sup> ); RAC > 30 mg/g; biópsia renal mostrando sinais de acometimento dos podócitos ou glomeruloesclerose acompanhada por inclusões moderadas a graves de GL3, em diferentes tipos de células renais.  
Conforme os autores, para pacientes com doença de início tardio ou formas variantes de significado indefinido (VUS), masculinos e femininos: 1) a terapia deve ser considerada se houver evidências disponíveis de exames laboratoriais, histológicos ou de lesão renal, mesmo em casos ausência de sintomas típicos de DF. Podendo ser necessário histologia, testes ou avaliação de evidências bioquímicas de acúmulo de GL3; 2) indivíduos com polimorfismos benignos bem caracterizados não devem ser tratados; 3) se o envolvimento tecidual ou os sintomas clínicos associados à DF estiverem ausentes, a terapia pode não ser adequada, particularmente em mulheres.  
Sobre a alfagalsidase, apenas um artigo foi incluído. O relatório sobre a tecnologia publicado em março de 2023 [2] concluiu em síntese, que havia apenas um ECR duplo-cego sobre TRE na DF, controlado por placebo, aferindo a ocorrência de eventos clínicos. Os resultados deste artigo indicaram que a TRE não postergou a progressão de doença renal, cerebrovascular ou cardíaca em pacientes com doença renal leve a moderada e não foi capaz de reduzir a incidência individual ou combinada dos eventos clínicos renais, cerebrovasculares ou cardíacos, quando comparado ao placebo.  
A análise de outros ECRs, aferindo desfechos substitutos, sugeria, no entanto, que a TRE retarda o declínio da função renal, sem reduzir proteinúria ou normalizar função tubular.  
Adicionalmente, a TRE parecia ser mais eficaz se iniciada nos pacientes com doença renal leve, antes do esgotamento da reserva renal e da redução drástica da taxa de filtração glomerular (TFG basal >55 mL/min/1,73m<sup>2</sup> ; creatinina sérica basal ≤1,5 mg/dL e > 1,2 mg/dL). Para os desfechos cardíacos, a evidência comparando alfagalsidase com placebo demonstrou redução da massa ventricular esquerda. A literatura encontrada à época da diretriz diagnóstica e terapêutica<sup>**2**</sup> carecia de estudos prospectivos avaliando o número de mortes súbitas, necessidade de uso de marca-passos e o desenvolvimento de valvulopatia nos pacientes em TRE  
40  
Melhora da dor neuropática e aumento da qualidade de vida relacionada à dor, foi evidenciada em um ECR duplo-cego controlado por placebo, assim como melhora na qualidade de vida, demonstrado em um estudo prospectivo e em um ensaio clínico aberto.  
Desfechos substitutos, como a redução nos depósitos de GL-3, foram demonstrados no plasma, no sedimento urinário, na pele e nos tecidos cardíaco e renal<sup>**2**</sup> . O problema deste desfecho, em particular, é o significado clínico incerto da redução de GL3.  
Como conclusão final, a TRE foi considerada segura e bem tolerada, sendo a maioria dos eventos adversos classificados como leves e possíveis de serem controlados com pré-medicação (anti-histamínicos, antitérmicos e baixas doses de corticoides) e aumento do tempo de infusão<sup>**2**</sup> . Alguns pacientes desenvolveram anticorpos da classe IgG contra a enzima recombinante, porém não foram encontradas evidências de que a presença destes anticorpos se associe a menor depuração de GL-3 no plasma, na urina e na pele ou à ocorrência de eventos clínicos ou influência na função renal.  
Considerações gerais e para implementação:  
Considera-se que a disponibilização dos medicamentos alfagalsidase e beta-agalsidase, assim como o acompanhamento e monitoramento do seu uso, deva ocorrer em centros especializados, nos moldes do já é feito no tratamento de outros erros inatos do metabolismo que dispõem de tratamento primário específico, como a Doença de Gaucher, Doença de Pompe e mucopolissacaridoses dos tipos I, II e IV.  
Em relação aos exames diagnósticos específicos para a avaliação da suspeita diagnóstica de DF, já estão disponíveis no  
SUS:  
03.01.01.021-8 - Avaliação clínica para diagnóstico de doenças raras - Eixo I: 3 - Erros Inatos do Metabolismo;  
02.02.10.008-1 - Identificação de mutação ou rearranjos por PCR, PCR sensível à metilação, qPCR e qPCR sensível à metilação;  
02.02.10.017-0 – Ensaios enzimáticos no plasma e leucócitos para diagnóstico de erros inatos do metabolismo.  
Perfil de evidências:  
Em relação às buscas realizadas, na questão referente às diretrizes para diagnóstico, tratamento e monitorização da DF, foram encontradas novas referências, as quais foram incluídas neste PCDT, sendo que estas foram duas diretrizes.  
A qualidade destas diretrizes foi avaliada pelo instrumento _Appraisal of Guidelines for Research and Evaluation_ II (AGREE II): _domain number, domain title, and specific domain_ items AGREE II, conforme **Quadro N** .  
**Quadro N -** Qualidade das diretrizes incluídas, de acordo com o AGREE II  
|**AGREE II**|**Silva et al.**<br>**2022**<sup>**4**</sup>|**Veisbich et al, 2022**<sup>**5**</sup>|
|---|---|---|
|Domínio 1- ESCOPO E OBJETIVO|||
|1- O(s) objetivo(s) geral(is) da diretriz é(são) especificamente descrito(s).|6|6|
|2- As questões de saúde abrangidas pela diretriz são descritas especificamente.|5|5|
|3- A população (pacientes, público, etc.) à qual a diretriz se destina a ser aplicada<br>é especificamente|6|5|  
41  
|**AGREE II**|**Silva et al.**<br>**2022**<sup>**4**</sup>|**Veisbich et al, 2022**<sup>**5**</sup>|
|---|---|---|
|descrito.|||
|Domínio 2- ENVOLVIMENTO DAS PARTES INTERESSADAS|||
|4- O grupo de desenvolvimento de diretrizes inclui indivíduos de todos os grupos<br>profissionais relevantes.|5|5|
|5- Foram procuradas as opiniões e preferências da população-alvo (pacientes,<br>público, etc.).|1|1|
|6- Os utilizadores-alvo da diretriz estão claramente definidos.|5|5|
|Domínio 3- RIGOR DE DESENVOLVIMEN|TO||
|7- Métodos sistemáticos foram utilizados para busca de evidências.|5|4|
|8- Os critérios para seleção das evidências estão claramente descritos.|1|0|
|9- A força e as limitações do conjunto de evidências estão claramente descritas.|4|4|
|10- Os métodos para formular as recomendações estão claramente descritos.|1|0|
|11- Os benefícios para a saúde, efeitos colaterais e riscos foram considerados na|||
|formulação do<br>recomendações.|6|6|
|12- Existe uma ligação explícita entre as recomendações e as evidências de apoio.|4|4|
|13- A diretriz foi revisada externamente por especialistas antes de sua publicação.|3|3|
|14- É fornecido um procedimento para atualizar a diretriz.|0|0|
|Domínio 4. CLAREZA DE APRESENTAÇÃ|O||
|15- As recomendações são específicas e inequívocas.|5|5|
|16- As diferentes opções para o manejo da condição ou problema de saúde são<br>claramente apresentadas.|5|5|
|17- As principais recomendações são facilmente identificáveis.|7|7|
|Domínio 5. APLICABILIDADE|||
|18-A diretriz descreve facilitadores e barreiras à sua aplicação.|1|0|
|19-A diretriz fornece conselhos e/ou ferramentas sobre como as recomendações<br>podem ser postas em prática.|0|0|
|20-As potenciais implicações em termos de recursos da aplicação das<br>recomendações foram consideradas.|1|1|
|21- A diretriz apresenta critérios de monitoramento e/ou auditoria.|1|0|
|Domínio 6. INDEPENDÊNCIA EDITORIA|L||
|22-As opiniões do organismo financiador não influenciaram o conteúdo da diretriz.|5|5|
|23-Os interesses conflitantes dos membros do grupo de desenvolvimento de<br>diretrizes foram observados e abordados.|5|5|  
Brouwers MC, Kho ME, Browman GP, Burgers JS, Cluzeau F, et al. AGREE II: Advancing guideline development, reporting and evaluation in healthcare. J Clin Epidemol. 2010, 63(12): 1308-11. PMID: 20656455;doi: 10.1016/j.jclinepi.2010.07.001<sup>**6**</sup>  
42

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
1. Brasil. Ministério da Saúde. Protocolos Clínicos e Diretrizes Terapêuticas. Doença de Fabry. Outubro de 2021. Disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2021/20211230_relatorio_674_doenca-de-fabry_final.pdf  
2. Brasil. Ministério da Saúde. Relatório de Recomendação. Alfagalsidase para o tratamento da doença de Fabry clássica em pacientes a partir dos sete anos de idade Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2023/20230522_relatorio_803_alfagalsidase_doenca_de_fabry-1.pdf  
3. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. 2016. Disponível em  
https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_metodologicas_elaboracao_diretrizes_metodologicas.pdf  
4. Silva CAB, Andrade LGM, Vaisbich MH, Barreto FC. Brazilian consensus recommendations for the diagnosis, screening, and treatment of individuals with fabry disease Committee for Rare Diseases – Brazilian Society of Nephrology/2021 Consenso brasileiro de doença de Fabry: recomendações de diagnóstico, triagem e tratamento. Comitê de doenças raras (Comdora) - SBN/2021. Braz. J. Nephrol. (J. Bras. Nefrol.) 2022;44(2):249-267  
5. Vaisbich MH, Andrade LGM, Silva CAB, Barreto FC. Recommendations for the diagnosis and management of Fabry disease in pediatric patients: a document from the Rare Diseases Committee of the Brazilian Society of Nephrology (Comdora-SBN). Recomendações para o diagnóstico e manejo de pacientes pediátricos com doença de Fabry: documento do comitê de doenças raras da Sociedade Brasileira de Nefrologia (Comdora-SBN). J. Bras. Nefrol. 2022;44(2):268-280  
6. Brouwers MC, Kho ME, Browman GP, Burgers JS, Cluzeau F, et al. AGREE II: Advancing guideline development, reporting and evaluation in healthcare. J Clin Epidemol. 2010, 63(12): 1308-11. PMID: 20656455;doi: 10.1016/j.jclinepi.2010.07.001  
43

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
Sobre a possibilidade de troca entre a alfagalsidase e beta-agalsidase para tratamento de pacientes com a DF ou recomendação de troca para os pacientes que apresentarem progressão ou toxicidade com uma das enzimas, foi feita uma revisão da literatura, semelhante àquela descrita no Relatório de Recomendação da Conitec nº 318/2018: “Alfagalsidase e beta-agalsidase como terapia de reposição enzimática na doença de Fabry”<sup>1</sup> .  
Estudos _in vitro_ sugerem que ambas as enzimas recombinantes, alfagalsidase e beta-agalsidase, seriam proteínas bioquímica e estruturalmente muito similares e com propriedades funcionalmente indistinguíveis, possuindo semelhança em relação à composição de aminoácidos, atividade específica, estabilidade e absorção por fibroblastos<sup>2</sup> . Em cultura de fibroblastos e num modelo animal algumas diferenças na captação celular entre as duas foram encontradas<sup>3</sup> , mas não há evidência sobre diferenças clínicas relevantes.  
Foram feitas buscas nas seguintes bases de dados: PubMed, Embase, BVS e Cochrane _library_ . Após eliminar as duplicidades e realizar as exclusões, foram analisados criticamente 13 artigos. Contudo, apenas dois estudos compararam de forma direta as duas enzimas recombinantes<sup>4,5</sup> . Portanto, a maior parte das informações existentes sobre as comparações entre as duas enzimas é oriunda de dados indiretos.  
Os dois ECR em que as duas enzimas são comparadas diretamente foram publicados pelo mesmo grupo de pesquisa. O primeiro, publicado em 2007<sup>4</sup> , comparou beta-agalsidase e alfagalsidase, ambas usadas em doses de 0,2 mg/kg, a cada 15 dias. Trinta e quatro pacientes foram acompanhados e o desfecho primário escolhido foi hipertrofia cardíaca. Não houve diferença significativa em relação aos valores basais ou entre os grupos de tratamento, para os desfechos primário e secundários. A taxa de falha se relacionou à idade e à gravidade a doença de base. Em 2008<sup>5</sup> , foi publicado um novo estudo comparando três grupos de tratamento: alfagalsidase 0,2 mg/kg, beta-agalsidase 0,2 mg e beta-agalsidase 1 mg/kg, todos utilizados a cada 15 dias. O desfecho primário foi a formação de anticorpos anti-α-Gal e os secundários, GL-3 plasmático e urinário, taxa de filtração glomerular e massa do ventrículo esquerdo (e a relação destes com os anticorpos). Não houve diferença significativa entre os grupos em relação à produção de anticorpos ou demais desfechos. Os autores, no entanto, sugeriram a possibilidade de haver uma relação entre dose da enzima e redução da massa do ventrículo esquerdo.  
A maioria dos dados comparando as duas enzimas não é oriundo de comparação direta. Entre 2009 e 2012, houve desabastecimento dos estoques mundiais de beta-agalsidase, secundário à contaminação viral em uma das fábricas da Genzyme® (fabricante do medicamento à época). Devido a isso, pacientes foram obrigados a realizar a troca de beta-agalsidase para alfagalsidase, inclusive nos EUA, onde a segunda não era licenciada. Estes pacientes forneceram dados sobre a possibilidade de equivalência clínica entre os tratamentos e vários estudos (séries de caso e coortes) foram publicados.  
Em 2011<sup>6</sup> , 35 pacientes que participavam da ‘ _Dutch Fabry Cohort_ ’ (17, do sexo masculino) faziam uso de beta-agalsidase e necessitaram fazer a troca para alfagalsidase. As taxas de eventos clínicos (morte, ataque isquêmico transitório, acidente vascular cerebral, arritmia grave com hospitalização e/ou colocação de cardioversor/desfibrilador ou marca-passo, insuficiência cardíaca levando a hospitalização, infarto agudo do miocárdio, necessidade de Angioplastia Coronária Transluminal Percutânea, Cirurgia de Revascularização Miocárdica ou progressão de insuficiência renal ao dialítico) nos períodos de uso de cada uma das  
44  
enzimas foram comparadas. A taxa média de incidência de eventos clínicos por pessoa por ano não foi diferente nos períodos de uso da beta e da alfagalsidase: 0,15 e p=0,68. Os autores também não encontraram correlação entre a ocorrência de eventos adversos. O tempo médio de seguimento dos pacientes no período de uso da alfagalsidase foi de 0,9 ano.  
Um estudo observacional<sup>7</sup> envolvendo 11 pacientes com Doença de Fabry (4 homens e 7 mulheres) avaliou a troca de beta-agalsidase (1 mg/kg a cada 15 dias) para alfagalsidase. Os pacientes foram avaliados antes e depois da troca (seguimento mínimo de 36 meses) para os seguintes desfechos: função renal (DCE), massa cardíaca/VE (ecocardiografia), qualidade de vida (EuroQol), dor (BPI), tolerabilidade e segurança. Houve redução significativa na massa do ventrículo esquerdo em 6 e 12 meses após a troca (média basal: 58,06 ±15,65; média entre 0 e 6 meses: 52,68 ± 13,97, P = 0,0195; média entre 6 e 12 meses: 51,59 ± 15,57, P = 0,0137). Em relação aos demais desfechos avaliados, observou-se que os pacientes permaneceram estáveis durante os 12 meses após a troca. Houve um caso de reação alérgica, caracterizada pelo desenvolvimento de anticorpos anti-alfagalsidase e eosinofilia (que desapareceu após retorno ao tratamento com beta-agalsidase).  
Outro estudo<sup>8</sup> incluiu 10 pacientes e coletou dados de uso de beta-agalsidase (1 mg/kg a cada 15 dias) por ao menos 48 meses e de alfagalsidase (0,2 mg/kg a cada 15 dias) por 20 meses. Foram avaliados função renal, fração de ejeção e massa cardíaca, qualidade de vida (SF 36), dor e segurança. Em 80% dos casos, a massa cardíaca decresceu de forma significativa durante o uso da beta-agalsidase e manteve-se estável após a troca para a alfa. Em relação à fração de ejeção, função renal, qualidade de vida e escores de dor, não se observaram alterações significativas após a troca de enzimas. Os eventos adversos foram em sua maioria leves.  
Lin et al<sup>9</sup> avaliaram retrospectivamente nove pacientes masculinos, que foram acompanhados do momento que iniciaram o uso de beta-agalsidase até a troca para alfagalsidase e por um ano após a troca. Doze meses após o momento da troca houve decréscimo na GL-3 plasmática em cinco dos nove pacientes e seis pacientes apresentaram redução na massa ventricular esquerda. Todos os pacientes mantiveram função renal estável. Quanto à segurança, 3 pacientes apresentaram reações de hipersensibilidade, mas que não os impediram de receber a mesma enzima posteriormente.  
Em 2014, Weidermann et al.<sup>10</sup> publicaram um estudo no qual compararam três modalidades de tratamento em pacientes que haviam utilizado beta-agalsidase por cerca de 1 ano: beta-agalsidase em dose normal, beta-agalsidase em dose reduzida (0,3 a 0,5 mg/kg a cada 15 dias) e troca para alfagalsidase (0,2 mg/kg a cada 15 dias). A alocação por grupo de tratamento não foi aleatória e, no total, 105 pacientes foram incluídos, com idade média de 45,3 anos e sendo 59% homens. O tempo de seguimento médio foi de um ano. O grupo avaliado era heterogêneo: 22,6%, em diálise; 7,6%, transplantados renais, 6,7%, com história prévia de ataque isquêmico transitório ou acidente vascular cerebral, e; 61%, com algum grau de fibrose em ventrículo esquerdo. Os desfechos acompanhados foram eventos clínicos (morte, infarto agudo do miocárdio, ataque isquêmico transitório ou acidente vascular cerebral, diálise ou transplante renal), alterações renais (função renal, albuminúria), alterações cardíacas (de ritmo e estruturais) e neurológicas (neuropatia dolorosa e alterações em biópsias de nervos periféricos). As únicas diferenças observadas foram um aumento da microalbuminúria no grupo que trocou beta-agalsidase por alfagalsidase (não significativa), que poderia ser justificado pelo maior tempo de evolução da doença.  
O mesmo grupo de pesquisa publicou um seguimento de dois anos de 89 pacientes do grupo anterior<sup>11</sup> , relatando os mesmos desfechos. As conclusões foram semelhantes ao estudo prévio: não houve diferenças entre os grupos em relação aos eventos clínicos, mas pacientes dos grupos com redução da dose da beta-agalsidase e com troca para alfagalsidase apresentaram mais episódios de dor no trato gastrointestinal.  
45  
O grupo de pesquisa de Goker-Alpan et al publicou dois estudos diversos<sup>12,13</sup> . O primeiro<sup>12</sup> acompanhou dois grupos de pacientes por 24 meses: tratados com alfagalsidase e tratados com beta-agalsidase e que trocaram para alfagalsidase durante o período de escassez do medicamento. O grupo da troca consistia em 71 indivíduos, com idade média de 36,6 anos. O desfecho primário relatado foi segurança. Foi encontrada uma taxa elevada de eventos adversos graves nos grupos tratados (conforme classificação dos autores), mas muitos destes casos poderiam ser eventos associados à evolução da doença (como AIT, AVC, insuficiência renal ou ICC).  
O mesmo grupo pesquisador<sup>13</sup> publicou uma coorte de quinze pacientes masculinos (14 com a forma clássica da DF) que usavam alfagalsidase (0,2 mg/kg a cada 15 dias) e trocaram para beta-agalsidase (1 mg/kg a cada 15 dias). Após a troca, os pacientes foram avaliados em relação aos níveis séricos de lysoGb3 e níveis séricos e urinários de GL-3 (em 2, 4 e 6 meses). Os resultados apontaram uma redução significativa nos níveis de plasmáticos de lysoGb3 e GL-3, mas sem modificação significativa nos níveis urinários de GL-3.  
Em 2017, foi publicada uma série de casos<sup>14</sup> com 33 pacientes (23 homens) da América Latina que foram submetidos à troca da beta-agalsidase pela alfagalsidas e seguidos por 24 meses após a mudança (idade média de 32,4 ± 2,0 anos). Foram avaliados parâmetros ecocardiográficos (medidas de septo intraventricular e de ventrículo esquerdo), função renal, qualidade de vida, dor e escores de gravidade de doença, não tendo sido encontradas diferenças significativas em nenhum destes desfechos entre os períodos de uso das formas enzimáticas beta-agalsidase e alfagalsidase.  
Em uma revisão sistemática seguida de meta-análise publicada em 2017<sup>15</sup> , incluíram-se 9 estudos (sendo 7 na metaanálise). Para análise dos eventos adversos, foram considerados cinco estudos, totalizando 150 pacientes. A taxa anual de eventos adversos por pessoa foi de 0,04, não se constatando diferença entre os períodos de uso das formas beta-agalsidase e alfagalsidase. Em relação à função renal, foram compilados dados de 7 estudos incluídos na meta-análise (147 pacientes): nenhuma alteração significativa foi observada na taxa de filtração glomerular após a mudança. Por fim, para o desfecho massa ventricular esquerda (5 estudos com 123 pacientes no total), houve uma redução importante após a troca para a alfagalsidase, com uma tendência à significância (diferença média -4,2; IC 95% -8,66 a -0,25). Entretanto, a interpretação deste achado não é clara e não se pode atribuir a melhora da hipertrofia do ventrículo esquerdo (não significativa) à introdução da alfagalsidase, pois essa poderia ser causada pelo maior tempo de uso de TRE.  
Já o estudo publicado em 2019<sup>16</sup> , uma coorte multicêntrica, retrospectiva, avaliou a taxa de eventos clínicos, índice de massa ventricular esquerda, taxa de filtração glomerular estimada, formação de anticorpos e níveis de LisoGb3. Foram comparados 387 pacientes (192 mulheres), tratados com alfagalsidase ou beta-agalsidase. Destes, 248 receberam alfagalsidase. A análise de “ _propensity scores_ ” mostrou uma taxa de eventos semelhantes para ambas as enzimas (HR 0,96, P = 0,87).  
Portanto, a análise da literatura indica que, ainda que haja discussões sobre a intercambialidade das enzimas betaagalsidase e alfagalsidase, ambas as formas enzimáticas podem ser consideradas semelhantes quanto aos benefícios do tratamento ou aos aspectos de segurança relevantes (eventos adversos graves).  
Por fim, não existem recomendações uniformes na literatura sobre a troca de enzimas devido à ocorrência de evento adverso ou ausência de resposta. Alguns autores sugerem que a troca deve ser considerada caso o paciente apresente reações alérgicas graves<sup>8</sup> . Contudo, o estudo de Lin et al<sup>9</sup> mostrou que o desenvolvimento de reações alérgicas infusionais não representa obrigatoriamente a necessidade de troca de enzimas. Portanto, cabe ao médico assistente definir a necessidade de troca da enzima nessas situações.  
46

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
1. Conitec. Relatório Técnico, n<sup>o</sup> 318: “Alfagalsidase e beta-agalsidase como terapia de reposição enzimática na doença de Fabry”, 2018. Em https://www.gov.br/conitec/pt-br/midias/relatorios/2018/relatorio_agalsidase_doencafabry.pdf  
2. Lee K, Jin X, Zhang K, Copertino L, Andrews L, Baker-Malcolm J et al. A biochemical and pharmacological comparison of enzyme replacement therapies for the glycolipid storage disorder Fabry Disease. Glycobiology. 2003; 13 (4):305-13.  
3. Sakuraba H, Murata-Ohsawa M, Kawashima I, Tajima Y, Kotani M, Ohshima T, et al. Comparison of the effects of agalsidase alfa and agalsidase beta on cultured human Fabry fibroblasts and Fabry mice. J Hum Genet 2006; 51: 180-188  
4. Vedder AC, Linthorst GE, Houge G, Groener JE, Ormel EE, Bouma BJ et al. Treatment of Fabry Disease: outcome of a comparative trial with agalsidase alfa or beta at a dose of 0.2mg/kg. PLoS One. 2007; 2(7): e598.  
5. Vedder AC, Breunig F, Donker-Koopman WE, Mills K, Young E et al. Treatment of Fabry disease with different dosing regimens of agalsidase: Effects on antibody formation and GL-3. Molecular Genetics and Metabolism. 2008; 94:319-25.  
6. Smid BE, Rombach SM, Aerts JM, Kuyper S, Mirzaian M, et al. Consequences of a global enzyme shortage of agalsidase beta in adult Dutch Fabry patients. Orphanet J Rare Dis. 2011; 6: 69.  
7. Tsuboi K, Yamamoto H. Clinical observation of patients with Fabry Disease after switching from agalsidase beta (Fabrazyme) to agalsidase alfa (Replagal). Kazuya Genet Med. 2012; 14 (9): 779–86.  
8. Pisani A, Spinelli L, Visciano B, Capuano I, Sabbatini M et al. Effects of Switching from Agalsidase Beta to Agalsidase Alfa in 10 Patients with Anderson-Fabry Disease. JIMD Reports. 2012, 177:41-8. DOI 10.1007/8904_2012_177.  
9. Lin HY, Huang YH, Liao HC, Liu HC, Hsu TR et al. Clinical observations on enzyme replacement therapy in patients with Fabry disease and the switch from agalsidase beta to agalsidase alfa. Journal of the Chinese Medical Association. 2014; 77: 190-197.  
10. Weidemann F, Krämer J, Duning T, Lenders M, Canaan-Kühl S, et al. Patients with Fabry Disease after Enzyme Replacement Therapy Dose Reduction Versus Treatment Switch. J Am Soc Nephrol. 2014; 25:837–849. doi: 10.1681/ASN.2013060585  
11. Lenders M, Canaan-Kühl S, Krämer J, Duning T, Reiermann S, et al. Patients with Fabry Disease after Enzyme Replacement Therapy Dose Reduction and Switch–2-Year Follow-Up. J Am Soc Nephrol. 2016; 27:952–962. doi: 10.1681/ASN.2015030337  
12. Goker-Alpan O, Gambello MJ, Maegawa GH, Nedd KJ, Gruskin DJ et al. Reduction of Plasma Globotriaosylsphingosine Levels After Switching from Agalsidase Alfa to Agalsidase Beta as Enzyme Replacement Therapy for Fabry Disease. JIMD Rep. 2016; 25: 95-106.  
13. Goker-Alpan O, Nedd K, Shankar SP, Lien YH, Weinreb N et al. Effect and Tolerability of Agalsidase Alfa in Patients with Fabry Disease Who Were Treatment Naïve or Formerly Treated with Agalsidase Beta or Agalsidase Alfa. JIMD Rep. 2015; 23:7-15. doi: 10.1007/8904_2015_422.  
14. Ripeau D, Amartino H, Cedrolla M, Urtiaga L, Urdaneta B et al. Switch from Agalsidase beta to Agalsidase alfa in the enzyme replacement therapy of patients with Fabry disease in Latin America. Medicina (Buenos Aires) 2017; 77: 173-9.  
15. Pisani A, Bruzzese D, Sabbatini M, Spinelli L, Imbriaco M et al. Switch to agalsidase alfa after shortage of agalsidase beta in Fabry disease: a systematic review and meta-analysis of the literature. Genet Med. 2017; 19 (3):275-282. doi: 10.1038/gim.2016.117.  
47  
16. Arends M, Biegstraaten M, Wanner C, Siirs S, Mehta A, Elliot PM et al. J Med Genet 2018;55:351–358. doi:10.1136/jmedgenet-2017-104863  
48

---

<!-- METADADOS: doenca: PCDT - Doença de Fabry | secao: **6.2.8  Intercambialidade e troca das enzimas recombinantes** -->
|**Número do Relatório da**||**Tecnologias avalia**|**das pela Conitec**|
|---|---|---|---|
|**diretriz clínica (Conitec) ou**<br>**Portaria de Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório de Recomendação<br>nº 923/2024|Incorporação de<br>tecnologias no SUS.<br>Mudança de formato do<br>documento|Alfagalsidase para o tratamento<br>da doença de Fabry clássica em<br>pacientes a partir dos sete anos<br>de idade [Relatório de<br>Recomendação nº 803/2023;<br>Portaria SECTICS/MS nº<br>26/2023].<br>Beta-agalsidase para o<br>tratamento da doença de Fabry<br>clássica [Relatório de<br>Recomendação nº 865/2023;<br>Portaria SECTICS/MS nº<br>73/2023].|-|
||||Alfagalsidase e a beta-<br>agalsidase para o tratamento<br>da doença de Fabry [Relatório<br>de Recomendação nº<br>574/2021; Portaria|
|Portaria Conjunta SAES-<br>SCTIE/MS nº 20, de 06 de|||SCTIE/MS nº 56/2020].|
|dezembro de 2021 [Relatório<br>de Recomendação nº<br>674/2021]|Atualização de conteúdo|-|Migalastate para o tratamento<br>de pacientes com doença de<br>Fabry com mutações<br>suscetíveis e idade igual ou<br>superior a 16 anos<br>[Relatório de Recomendação<br>nº 632/2021; Portaria<br>SCTIE/MS nº 42/2021].|  
49

---

