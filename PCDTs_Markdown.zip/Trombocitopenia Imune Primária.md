<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
PORTARIA CONJUNTA SAES/SCTIE Nº 41, DE 25 DE FEVEREIRO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Trombocitopenia Imune Primária.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE, no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, resolvem:  
Considerando a necessidade de se atualizarem os parâmetros sobre a Trombocitopenia Imune Primária no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação nº 1049/2025 e o Registro de Deliberação nº 1049/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Trombocitopenia Imune Primária.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Trombocitopenia Imune Primária, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos  
adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Trombocitopenia Imune Primária.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE nº 7, de 23 de fevereiro de 2018, publicada no Diário Oficial da União nº 41, de 1º de março de 2018, seção 1, pág. 58.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
1

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
A trombocitopenia imune<sup>a</sup> (PTI) é uma doença autoimune adquirida, caracterizada pela queda transitória ou persistente dos níveis de plaquetas e inibição da função de megacariócitos, levando à trombocitopenia e risco de sangramentos<sup>1,2</sup> . A PTI primária é definida por trombocitopenia isolada na ausência de outras etiologias<sup>3,4</sup> , ao passo que o termo PTI secundária designa trombocitopenias decorrentes de doenças adjacentes, como neoplasias malignas, doença autoimune sistêmica e infecções virais crônicas, ou à exposição de medicamentos<sup>4</sup> . Este Protocolo tem como foco a PTI primária, diagnosticada por meio da exclusão de outras causas de trombocitopenia. Assim, possíveis causas de PTI secundária devem ser investigadas e tratadas conforme recomendações específicas para a doença de base.  
A causa da PTI permanece desconhecida na maioria dos casos. Acredita-se que a destruição das plaquetas é mediada, principalmente, por mecanismos autoimunes, envolvendo o desenvolvimento de anticorpos antiplaquetários, ou seja, anticorpos direcionados às glicoproteínas da membrana plaquetária, como a GPIIb/IIIa<sup>5,6</sup> . Todavia, apenas cerca de 50% a 80% dos pacientes apresentam anticorpos direcionados às glicoproteínas da superfície plaquetária, sugerindo que mecanismos fisiopatológicos alternativos estão envolvidos. Dentre estes mecanismos, estão as células T citotóxicas autorreativas e autoimunidade humoral e celular dirigida aos megacariócitos, causando deficiência na produção de plaquetas<sup>1,7</sup> . A associação de predisposição genética com a condição foi investigada, embora apenas um número muito pequeno (2%) de indivíduos tenha ocorrência familiar de PTI<sup>8</sup> , ao passo que a presença de eventos desencadeantes em alguns pacientes sugere uma contribuição de fatores genéticos e adquiridos<sup>9</sup> .  
As manifestações clínicas da PTI estão relacionadas, principalmente, ao sangramento, que pode ocorrer em até dois terços dos pacientes, ao passo que cerca de 30% a 40% dos pacientes com PTI crônica são assintomáticos<sup>5</sup> . Apesar de a gravidade dos sintomas estar associada à plaquetometria (contagem de plaquetas), sendo maior em níveis abaixo de 10.000/mm<sup>3</sup> , os achados clínicos são altamente variáveis, mesmo em níveis semelhantes de contagem de plaquetas.  
A apresentação clínica se caracteriza comumente pela presença de petéquias, equimoses, hematomas, sangramento em membranas mucosas abrangendo a cavidade oral e nasal. Estima-se que a maioria das ocorrências hemorrágicas é localizada na pele, nariz ou boca<sup>10</sup> . Complicações menos frequentes incluem o sangramento do trato gastrointestinal e geniturinário, ao passo que o sangramento intracraniano é a complicação de maior gravidade e potencialmente fatal<sup>2,4</sup> . O risco de hemorragia grave gastrointestinal ou do Sistema Nervoso Central no início da doença é inferior a 1%<sup>11</sup> .  
Pacientes com contagem de plaquetas abaixo de 20.000/mm<sup>3</sup> têm maior probabilidade de apresentar sangramento clinicamente importante do que aqueles com contagens mais altas. Contudo, a correlação entre a contagem de plaquetas e o risco de hemorragia é fraca. Os preditores de sangramento clinicamente importante incluem o grau de trombocitopenia (menor que 20.000/mm<sup>3</sup> em PTI crônica ou persistente e menor que 30.000/mm<sup>3</sup> em PTI aguda), sangramento menor anterior e idade avançada<sup>12</sup> . Em adultos, sexo feminino, PTI crônica e uso de anti-inflamatórios não esteroidais (AINEs) também são considerados preditores de sangramento importante<sup>13</sup> .  
> a A condição, antes conhecida como Púrpura Trombocitopênica Idiopática ou Púrpura Trombocitopênica Imune, passou a ser chamada de Trombocitopenia Imune, preservando o acrônimo amplamente reconhecido, "PTI". Esta denominação reconhece o mecanismo imune mediado do distúrbio, ao mesmo tempo que contempla os pacientes que apresentam poucos ou nenhum sinal de púrpura ou sangramento e que representam grande parte dos casos.  
2  
Também é comum que adultos e crianças com PTI apresentem fadiga, associando a diminuição da energia à redução dos níveis de plaquetas<sup>14,15</sup> . As causas da fadiga na PTI não são bem compreendidas, e fatores contribuintes podem incluir condições associadas e comorbidades (por exemplo, lúpus eritematoso sistêmico [LES] e hipotireoidismo), restrições de atividade, eventos adversos do tratamento (como distúrbios do sono causados por glicocorticoides), idade avançada, maior nível de estresse, disfunção autonômica ou eventos adversos causados por citocinas pró-inflamatórias<sup>15</sup> .  
A PTI pode apresentar-se em qualquer idade, mas há um pico de incidência entre crianças, sendo uma das causas mais comuns de trombocitopenia sintomática nesta população. Em crianças, estima-se que a incidência de PTI aguda esteja entre 1,9 e 6,4 por 100.000 crianças por ano<sup>16</sup> , ao passo que a prevalência variou de 4,1 a 9,7 por 100.000 crianças por ano, sendo maior no sexo masculino e nas menores faixas etárias<sup>2</sup> . Já entre os adultos, dados de estudos epidemiológicos internacionais fornecem estimativas de incidência anual de 1,6 a 6,1 casos por 100.000 pessoas e uma prevalência de 4,0 a 23,6 casos por 100.000 pessoas por ano<sup>2,4,17,18</sup> . Cabe destacar que tais estimativas se baseiam, principalmente, em pacientes que desenvolvem trombocitopenia sintomática ou necessitam de hospitalização e, por isso, podem estar subestimadas. Uma vez que a PTI é frequentemente uma doença crônica em adultos, a prevalência excede consideravelmente a incidência. Numa revisão americana, a prevalência foi de aproximadamente 8 por 100.000 em crianças e 12 por 100.000 em adultos<sup>19</sup> .  
A PTI em crianças, especialmente as menores de 10 anos de idade, é uma condição clinicamente distinta da manifestação em adultos, com maior probabilidade de remissão espontânea, menor incidência de doenças subjacentes e comorbidades e, frequentemente, menor risco de hemorragia. Em crianças, aproximadamente 80% dos casos são resolvidos dentro de 6 a 12 meses, mesmo na ausência de tratamento específico<sup>20,21</sup> , ao passo que a PTI evolui para uma doença crônica em 80% dos adultos<sup>2</sup> . Um estudo observacional de 12 anos conduzido em Minas Gerais (UFMG) relatou dados de prontuário de 187 crianças tratadas com PTI. Um terço apresentava diagnóstico prévio de infecções, 76% apresentavam quadros assintomáticos e leves, e as hemorragias eram exclusivamente cutâneas na maior parte dos casos (96%)<sup>7</sup> . Na população adulta, ao contrário, as remissões espontâneas foram observadas em menos de 10% de pacientes não tratados<sup>22</sup> . Durante a adolescência, a PTI pode ser semelhante à PTI típica da infância ou à PTI em adultos.  
Em mulheres, a PTI representa 5% dos casos de trombocitopenia na gravidez, sendo de difícil diagnóstico e podendo gerar complicações importantes para o feto. Estima-se que a doença ocorra em 1 a 2 mulheres a cada 1.000 gestantes, e mulheres com diagnóstico prévio tendem a ter exacerbação do seu quadro clínico ou recidiva da doença durante a gravidez<sup>23</sup> . Calcula-se que um terço dessas mulheres podem necessitar de tratamento, quando gestantes. Em geral, os episódios de sangramentos em pacientes com PTI durante a gestação são mais tênues pelo estado pró-coagulante neste período (aumento nos níveis de fibrinogênio, fator VIII e fator von Willebrand; fibrinólise suprimida; e uma redução na atividade da proteína S) quando comparado com mulheres não grávidas<sup>24,25</sup> .  
Há ligeiro predomínio de prevalência em meninos em relação a meninas, principalmente em lactentes, de acordo com o registro do Grupo de Estudo Intercontinental de PTI na Infância, que incluiu mais de 2.000 bebês e crianças de 3 meses a 16 anos de idade. Em bebês entre 3 e 12 meses de idade, a proporção homem/mulher foi de 1,7:1<sup>26</sup> . A predominância do sexo masculino foi mínima em crianças mais velhas, de modo que a proporção geral entre homens e mulheres nesta coorte pediátrica foi de 1,2:1<sup>27</sup> . Por outro lado, há uma predominância feminina de PTI em adolescentes e adultos de 18 a 45 anos de idade. Uma hipótese que explicaria a predominância feminina em adolescentes está relacionada aos níveis mais elevados de estrogênio, que podem promover autoimunidade<sup>26,27</sup> .  
O tratamento da PTI é direcionado para redução do risco de sangramentos graves por meio da manutenção de níveis adequados de plaquetas (normalmente, acima de 50.000/mm³), não influenciando o prognóstico a longo prazo<sup>22,28,29</sup> . A maior parte dos pacientes, em especial aqueles assintomáticos e com contagem plaquetária acima de 30.000/mm<sup>3</sup> , tendem a seguir um curso clínico favorável, com poucas internações hospitalares e sem mortalidade excessiva<sup>29</sup> . Sugere-se que o tratamento seja  
3  
reservado para os casos que evoluem para trombocitopenia grave e sintomática, com contagens persistentemente abaixo de 20.000/mm<sup>3</sup> ou sangramento ativo devido ao risco de complicações e eventos adversos<sup>3</sup> .  
Indivíduos com trombocitopenia estável sem sangramento podem ser tratados em nível ambulatorial, desde que haja monitoramento rigoroso e orientação para tratamento caso surja sangramento. Para pacientes com PTI que apresentam sangramento grave, a hospitalização urgente é indicada para confirmar o diagnóstico, excluir outras causas potenciais de sangramento e iniciar a terapia apropriada. Isto também se aplica para adultos com PTI recém-diagnosticada e contagem de plaquetas menor que 30.000/mm³<sup>30</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para atendimento especializado dão à Atenção Primária à Saúde (APS) um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este PCDT visa a estabelecer os critérios diagnósticos e terapêuticos de PTI, com o objetivo de orientar, com base em evidências científicas de segurança, efetividade e reprodutibilidade, as condutas e os protocolos assistenciais mais adequados.  
**2       CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- D69.3 Púrpura trombocitopênica idiopática

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Atualmente, inexiste exame laboratorial específico para o diagnóstico de PTI e a dosagem de anticorpos antiplaquetários não é recomendada devido à sua baixa acurácia diagnóstica<sup>31</sup> . Assim, o diagnóstico baseia-se na exclusão de outras causas de trombocitopenia por meio de avaliação do histórico clínico e familiar, exame físico e hemograma completo<sup>31</sup> .  
O exame físico deve focar nas manifestações clínicas mais frequentes na PTI, que estão principalmente relacionadas aos sinais de sangramento, especificamente petéquias, equimoses, hematomas, sangramento em membranas mucosas na cavidade oral e nasal. Cabe destacar que os achados clínicos são altamente variáveis: apesar de apresentarem a mesma contagem de plaquetas, os pacientes podem cursar com quadros clínicos distintos. Além disso, a gravidade dos sintomas pode variar amplamente, desde a ausência de sangramento até hemorragias graves, com potencial risco de vida<sup>28</sup> . Durante o exame físico, a identificação de linfadenopatia ou hepatoesplenomegalia pode sugerir condições subjacentes responsáveis pela trombocitopenia.  
Além da avaliação do histórico do paciente – muito importante no diagnóstico diferencial de trombocitopenia – a realização de outros exames laboratoriais pode ser necessária, conforme a situação clínica, a fim de excluir as principais causas de plaquetopenia. As causas mais comuns de trombocitopenia que devem ser investigadas e excluídas para o diagnóstico da PTI primária estão listadas no **Quadro 1**<sup>32</sup> **.**  
**Quadro 1** . Causas de trombocitopenia não caracterizadas como PTI primária.  
||**PTI secundária**|**Plaquetopenia não imune**|
|---|---|---|
|Doença|s autoimunes / imunodeficiências|Pseudoplaquetopenia (relacionada ao EDTA)|
|`o`|Lúpus eritematoso sistêmico, síndrome|Doença hepática|
||antifosfolípide, síndrome de Evans,|`o`<br>Hipertensão portal, cirrose.|
||imunodeficiência comum variável, outras<br>doenças autoimunes|Produção reduzida|  
4  
|**PTI secundária**|**Plaquetopenia não imune**|
|---|---|
||`o`<br>Falência da medula óssea (mielodisplasia, leucemia,|
|Infecções virais e bacterianas|outras neoplasias, doença metastática, anemia|
|`o`<br>HIV, HCV, HBV, mononucleose infecciosa,|megaloblástica)|
|_Helicobacter pylori_||
||Trombocitopenia hereditária|
|Neoplasias||
|`o`<br>Doenças linfoproliferativas|Consumo periférico de plaquetas<br>`o`<br>Coagulação intravascular disseminada, sepse,|
|Uso de medicamentos e vacinas|microangiopatia trombótica (púrpura trombocitopênica|
||trombótica/síndrome hemolítico-urêmica)|
||Gestação|
||`o`<br>Trombocitopenia gestacional, pré-eclâmpsia|  
**Fonte** : elaboração própria.  
No diagnóstico da PTI, a avaliação adequada do sangue periférico é de fundamental importância. Para a realização do hemograma e da contagem plaquetária recomenda-se priorizar, sempre que disponível no serviço, a coleta de sangue em tubo com anticoagulante diferente do EDTA, como por exemplo, o citrato de sódio com o intuito de descartar falsa plaquetopenia (pseudotrombocitopenia induzida por EDTA). No entanto, vale destacar que a pseudotrombocitopenia pode, embora com menor frequência, ocorrer também com o uso de citrato, heparina ou em situações inflamatórias, como no satelitismo plaquetário em neutrófilos. Os demais exames de controles podem ser feitos com EDTA, após descartar a pseudotrombocitopenia induzida por EDTA.  
Recomenda-se a avaliação do esfregaço de sangue periférico recém-colhido pois ele permite a identificação de agregados plaquetários e de alterações morfológicas importantes para o diagnóstico diferencial, como ausência de grânulos ou plaquetas uniformemente grandes ou pequenas, auxiliando na exclusão de distúrbios plaquetários hereditários. A PTI é caracterizada por morfologia plaquetária geralmente normal, embora seja comum a presença de plaquetas de tamanho aumentado. A ausência de plaquetas grandes, no entanto, não exclui o diagnóstico de PTI<sup>33</sup> .  
Pesquisas de anticorpos anti-HIV e anti-HCV no soro devem ser rotineiramente solicitados em adultos como diagnóstico diferencial, uma vez que a infecção crônica, previamente assintomática, pode se manifestar inicialmente com trombocitopenia. A pesquisa para _Helicobacter pylori_ pode ser realizada para investigar essa infecção crônica, em especial nas formas crônicas de PTI, ou em pacientes com sintomas gastrointestinais sugestivos de infecção<sup>14</sup> .  
Durante a investigação inicial, sempre que possível, sugere-se a avaliação das funções hepática e renal, além da realização de pesquisa de fator antinuclear (FAN), eletroforese de proteínas e dosagem de imunoglobulinas para descartar doenças autoimunes, linfoproliferativas e imunodeficiências, respectivamente.  
Sugere-se a realização dos testes de tempo de protrombina (TP) e tempo de tromboplastina parcial ativada (TTPA), em indivíduos com trombocitopenia moderada ou grave, com sangramento clinicamente importante ou aqueles que realizarão procedimentos invasivos. Estes exames também podem ser aplicados para a avaliação do risco hemorrágico, quando há suspeita de distúrbios da coagulação que podem coexistir com a PTI, ou quando os sintomas clínicos sugerem a possibilidade de outros problemas de coagulação<sup>14</sup> .  
O exame da medula óssea não é necessário para o diagnóstico inicial<sup>14,34</sup> . Recomenda-se que a avaliação da medula óssea (obtida por biópsia e aspirado) seja reservada para quando houver suspeita de neoplasias ou mielodisplasia, outras citopenias  
5  
associadas (anemia, leucopenia), displasia no esfregaço de sangue periférico, ausência de resposta à terapia com PTI ou outras anormalidades na produção de plaquetas, como trombocitopenia amegacariocítica adquirida<sup>1,10,11</sup> . Na PTI, normalmente, a celularidade é normal, o número de megacariócitos está normal ou aumentado e a eritropoiese e a mielopoiese são normais. Em alguns pacientes, pode ser observada predominância de megacariócitos mais jovens, com graus menores de poliploidia nuclear e menor evidência de produção de plaquetas<sup>35</sup> .  
Os testes de função tireoidiana podem ser realizados em pacientes com sintomas de hipotireoidismo ou hipertireoidismo devido a relatos de PTI associada a distúrbios da tireoide. Pacientes que necessitam de cirurgia, como esplenectomia para tratar PTI (ou uma cirurgia não relacionada), devem realizar exames para identificar eventual hipotireoidismo ou hipertireoidismo oculto antes do procedimento devido ao risco aumentado de complicações perioperatórias<sup>14,36</sup> .  
O teste de anticorpos antinucleares (ANAs) não é necessário em pacientes sem sintomas de condições reumatológicas, podendo ser realizado em pacientes com erupção malar, sintomas constitucionais, artrite, mialgia. Os níveis quantitativos de imunoglobulina podem identificar deficiência imunológica variável comum (IDCV) subjacente ou deficiência seletiva de IgA, especialmente em pacientes mais jovens<sup>14</sup> .  
Os níveis de vitamina B12 e folato não devem ser avaliados em pacientes assintomáticos. No entanto, essas vitaminas são necessárias para a hematopoiese e sua deficiência pode cursar com trombocitopenia leve. Recomenda-se a avaliação dos níveis de vitamina B12 e folato quando houver outros achados atribuíveis a essas deficiências (por exemplo, alterações neurológicas ou psiquiátricas, anemia macrocítica, neutrófilos hipersegmentados, práticas dietéticas associadas à diminuição da ingestão ou condições que prejudicam a absorção, como procedimentos de _by-pass_ gástrico)<sup>14</sup> .  
Pacientes com sangramento desproporcional ao grau de trombocitopenia podem justificar a avaliação de condições menos comuns, como doença de von Willebrand tipo 2B (DVW), síndrome de Bernard-Soulier ou outros distúrbios plaquetários hereditários ou adquiridos<sup>37</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Em geral, a maioria das gestantes com PTI já tem o diagnóstico prévio à gestação. Entretanto, mais de 10% dos casos são diagnosticados durante a gravidez em países desenvolvidos, proporção que pode ser ainda maior em locais com baixa assistência médica<sup>38–40</sup> . A PTI pode ser considerada a principal causa de trombocitopenia no primeiro e segundo trimestres de gestação<sup>25</sup> . Contudo, considerando-se todos os trimestres, em especial, o terceiro, a trombocitopenia gestacional é mais frequente<sup>25</sup> . Esta última difere da PTI por não apresentar caráter autoimune, e está relacionada com um ou mais dos seguintes fatores: a) aumento do volume plasmático; b) sequestro das plaquetas na vascularização placentária, ou; c) incremento da depuração plaquetária<sup>25</sup> .  
O diagnóstico de PTI na gestante é semelhante ao dos outros indivíduos. Contudo, o diagnóstico diferencial deve ser feito conforme o trimestre gestacional com outras afecções, principalmente com a trombocitopenia gestacional.  
No primeiro trimestre, recomenda-se avaliar trombocitopenias hereditárias prévias, síndrome hemolítico-urêmica, púrpura trombocitopênica trombótica e deficiência de folato. Nos demais trimestres, a trombocitopenia gestacional deve ser investigada, bem como a trombocitopenia relacionada com a pré-eclâmpsia (doença hipertensiva específica da gestação) associada a Síndrome de HELLP (hemólise, elevação de enzimas hepáticas e plaquetopenia que ocorre na gravidez)<sup>24</sup> .  
Menos de 1% das mulheres com trombocitopenia gestacional têm contagens de plaquetas abaixo de 100.000/mm<sup>3</sup> e 0,1% têm contagens abaixo de 80.000/mm<sup>3 41</sup> . Portanto, a trombocitopenia gestacional pode ser definida por contagens de plaquetas acima de 70.000/mm<sup>3</sup> , e raramente causa sangramentos significativos. Esta afecção se inicia usualmente na segunda metade da gestação e resolve-se no puerpério<sup>42</sup> . Estes aspectos podem auxiliar no diagnóstico diferencial com a PTI.  
Após 20 semanas de gestação, a pré-eclâmpsia deve ser investigada e o critério para seu diagnóstico é a identificação de hipertensão arterial com proteinúria significativa em gestante previamente normotensa<sup>43,44</sup> . Proteinúria significativa é definida  
6  
como relação proteinúria/creatinúria acima de 0,3 mg/dL ou acima de 1,0 mg/dL em fita reagente. Na ausência de proteinúria, também se considera pré-eclâmpsia quando houver<sup>43,44</sup> :  
- Disfunções orgânicas maternas:  
`o` Perda de função renal (creatinina acima de 1,1 mg/dL);  
- Disfunção hepática (aumento de transaminases acima de 2 vezes o limite superior normal; epigastralgia);  
- Complicações neurológicas (estado mental alterado; cegueira; hiperreflexia com clônus, escotomas, turvamento visual,  
diplopia, _doppler_ da artéria oftálmica materna com _peak/ratio_ maior que 0,78);  
`o` Complicações hematológicas, como plaquetopenia, coagulação intravascular disseminada (CIVD) e hemólise;  
`o` Estado de antiangiogênese: fator de crescimento placentário (PLGF; _placental Growth Factor_ ) menor que 36 pg/mL ou  
relação tirosina quinase fms solúvel tipo 1 (sFlt-1)/PIGF maior que 85, marcadores não disponíveis em todos os serviços  
nacionais; ou  
- Disfunção uteroplacentária (retardo de crescimento intrauterino assimétrico; _Doppler_ umbilical alterado,  
- principalmente se presente também _Doppler_ alterado nas duas artérias uterinas maternas).

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
<mark>A PTI primária pode ser classificada quanto à fase da doença, dependendo da duração, ou quanto à resposta aos tratamentos</mark><sup>4,33</sup> <mark>. O</mark> **<mark>Q</mark> uadro 2** <mark>apresenta as definições de</mark> classificação <mark>da PTI adotadas neste PCDT.</mark>  
**Quadro 2.** Classificação da PTI.  
|**Conceito**|**Definição**|
|---|---|
|**Fases da doença**||
|PTI recém-diagnosticada|Duração da PTI menor que 3 meses desde o diagnóstico.|
|PTI persistente|Duração da PTI de 3 a 12 meses desde o diagnóstico.|
|PTI crônica|Duração da PTI maior que 12 meses desde o diagnóstico.|
|**Resposta ao tratamento**||
|Resposta parcial|Contagem de plaquetas entre 30.000 e 100.000/mm<sup>3</sup>ou duplicação da contagem<br>plaquetária basal, sem nenhum sangramento clinicamente relevante.|
|Resposta completa|Contagem de plaquetas maior ou igual a 100.000/mm<sup>3</sup>, sem nenhum sangramento<br>clinicamente relevante.|
|Falha terapêutica|Contagem plaquetária inferior a 30.000/mm<sup>3</sup>ou menos que o dobro da contagem<br>basal, com persistência ou piora dos sintomas hemorrágicos.|
||Persistência de baixa contagem plaquetária, apesar do uso apropriado das terapias|
|PTI refratária<sup>a</sup>|de primeira linha consideradas seguras para o paciente, independentemente das<br>manifestações hemorrágicas.|  
Fonte: adaptado de Rodeghiero et al. (2009)<sup>45</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Serão incluídos neste Protocolo pacientes de qualquer idade com diagnóstico de PTI primária, definido como contagem de plaquetas menor que 100.000/mm<sup>3</sup> e descartando-se outras condições clínicas que cursam com trombocitopenia, como  
7  
infecções, outras doenças autoimunes, imunodeficiência primárias, neoplasias, eventos adversos de medicamentos, trombocitopenias hereditárias, entre outras.  
Adicionalmente, para tratamento medicamentoso serão considerados os critérios a seguir:  
**Para tratamento de primeira linha com prednisona, dexametasona, metilprednisolona e imunoglobulina humana**  
**intravenosa (IVIg),** o paciente deve apresentar um dos seguintes critérios:  
- 1) Presença de sangramento significativo, incluindo emergências, definidas como presença de sangramento intracraniano  
- ou mucoso, com instabilidade hemodinâmica ou respiratória; OU  
- 2) Contagem de plaquetas abaixo de 30.000/mm<sup>3</sup> ; OU  
- 3) Contagem de plaquetas abaixo de 50.000/mm<sup>3</sup> na presença de sangramento ou de fatores de risco para sangramento,  
que incluem:  
- a.Presença de coagulopatias; OU  
- b.Uso de anticoagulantes; OU  
- c.Presença de doenças vasculares; OU  
- d.Preparo para cirurgias e procedimentos invasivos; OU  
- e.Outros fatores de risco para sangramento, como exposição ocupacional, hipertensão arterial ou epilepsia não  
- controladas.  
**Para tratamento com azatioprina ou ciclofosfamida ou rituximabe,** o paciente deve apresentar todos os seguintes  
critérios:  
- 1) PTI persistente OU crônica (duração da PTI maior que 3 meses a partir do diagnóstico); E  
- 2) Ausência de resposta, dependência (uso crônico por mais de oito semanas) ou contraindicação aos medicamentos de  
- primeira linha (i.e., corticoides e IVIg).  
**Para tratamento com eltrombopague ou romiplostim,** o paciente deve apresentar todos os seguintes critérios:  
- 1) PTI persistente OU crônica (duração da PTI maior que 3 meses a partir do diagnóstico); E  
- 2) Ausência de resposta (contagem de plaquetas abaixo de 30.000/mm<sup>3</sup> OU abaixo de 50.000/mm<sup>3</sup> na presença de  
sangramento ou de fatores de risco para sangramento) ou contraindicação ao tratamento com ao menos um dos medicamentos a seguir: azatioprina OU ciclofosfamida OU rituximabe.  
**Para tratamento de com vincristina ou danazol** , o paciente deve apresentar todos os seguintes critérios:  
- 1) PTI persistente OU crônica (duração da PTI maior que 3 meses a partir do diagnóstico); E  
- 2) Ausência de resposta (contagem de plaquetas abaixo de 30.000/mm<sup>3</sup> OU abaixo de 50.000/mm<sup>3</sup> na presença de  
sangramento ou de fatores de risco para sangramento) ou contraindicação ao tratamento com ao menos um dos medicamentos a seguir: eltrombopague OU romiplostim.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Serão excluídos pacientes que apresentarem intolerância, hipersensibilidade ou contraindicações às condutas preconizadas neste Protocolo.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Em determinadas circunstâncias clínicas, é observada uma predisposição acentuada para eventos hemorrágicos ou a presença de comorbidades que demandam níveis-alvo mais elevados de contagem plaquetária ou cuidados especiais. Tais  
8  
manifestações clínicas impõem a necessidade de abordagens terapêuticas diferenciadas ou da introdução da terapia medicamentosa mesmo com plaquetometria acima de 30.000/mm<sup>3</sup> . Estas situações são:  
 **Pacientes diabéticos insulino-dependentes, portadores de diabetes não controlada, distúrbios psiquiátricos ou infecção ativa:** recomenda-se que a terapia inicial seja realizada com IVIg devido às contraindicações relevantes associadas à terapia com corticoides em altas doses<sup>14</sup> .  
 **Pacientes com sangramento uterino anormal (SUA):** a SUA é frequente em mulheres com PTI crônica e interfere negativamente na qualidade de vida, particularmente em pacientes com baixa contagem de plaquetas. Nesses casos, contraceptivos orais podem ser usados para diminuir a frequência e a quantidade do sangramento menstrual<sup>46</sup> .  
 **Pacientes com coagulopatias hereditárias:** quando as manifestações clínicas do paciente são agravadas por um distúrbio subjacente na coagulação, é necessária uma avaliação adicional da função hemostática. A coexistência de múltiplos defeitos na hemostasia é rara, mas representa um grande desafio, exigindo tratamento preventivo com a reposição do fator deficiente, além do tratamento da PTI, com o objetivo de minimizar o risco de hemorragia<sup>47</sup> .  
 **Pacientes com doenças vasculares ou eventos trombóticos:** taxas aumentadas de eventos trombóticos venosos e arteriais foram relatadas em pacientes com PTI, mesmo no contexto de trombocitopenia acentuada. O risco de trombose é multifatorial, incluindo características da PTI, fatores de risco do paciente e tratamentos da PTI, particularmente esplenectomia e os agonistas do receptor da trombopoetina (TPO-Ras) (eltrombopague e romiplostim). O tratamento é desafiador, equilibrando riscos de sangramento e trombose. O uso criterioso de terapia antiplaquetária e anticoagulação é indicado, com limiares plaquetários sugeridos para orientar o tratamento ( **Quadro 3** )<sup>48</sup> .  
 **Cirurgias:** o preparo para cirurgias em pacientes com PTI visa a reduzir o risco de sangramento durante procedimentos invasivos, ao elevar-se os níveis de plaquetas antes da cirurgia por meio de medicamentos, como corticoides, IVIg e TPO-RA (eltrombopague e romiplostim). Em cirurgias eletivas, a preparação é viável, enquanto em cirurgias de emergência, a transfusão de plaquetas pode ser necessária, especialmente se os níveis estiverem abaixo de 50.000/mm<sup>3</sup> . Os limiares plaquetários sugeridos para guiar o tratamento são apresentados no **Quadro 4**<sup>14</sup> .  
**Quadro 3.** Limiares de contagem plaquetária sugeridos para terapia anticoagulante e antiplaquetária.  
|**Contagem**<br>**plaquetária**|**Trombose venosa**<sup>**(1)**</sup>|**Trombose arterial**|
|---|---|---|
|Abaixo<br>de<br>25.000/mm<sup>3</sup>|Considerar tratar para aumentar contagem<br>plaquetária (igual ou acima de 50.000/mm<sup>3</sup>).<br>Corticoide, IgIV, TPO-RA, outros agentes tais<br>como azatioprina, esplenectomia.|Contraindicado antiplaquetário.<br>Considerar<br>tratar<br>para<br>aumentar<br>contagem<br>plaquetária (igual ou acima de 50.000/mm<sup>3</sup>).<br>Corticoide, IgIV, TPO-RA, outros agentes, tais<br>como azatioprina, esplenectomia.|
|Entre 25.000 /mm<sup>3</sup><br>e 50.000/mm<sup>3</sup>|Reduzir a dose da anticoagulação<br>HNF se contagem plaquetária é instável ou há<br>preocupação de sangramento.|Antiplaquetário – um agente pode ser usado.|
|Igual ou acima de<br>50.000/mm<sup>3</sup>|Dose terapêutica de anticoagulação.|Antiagregação com ácido acetilsalicílico pode ser<br>usada.|  
**Nota** a – Anticoagulantes e antiplaquetários são contraindicados em pacientes trombocitopênicos com sangramento ativo, classificação de sangramento da Organização Mundial da Saúde (OMS) grau 2 ou pior. **Legenda:** IgIV, imunoglobulina IgG; TPO-RA, agonista de receptores de trombopoietina; HNF, heparina não fracionada. **Fonte:** Adaptado de Swan et al (2021)<sup>48</sup>  
9  
**Quadro 4.** Limiares de contagem plaquetária sugeridos para cirurgia.  
|**Tipo de cirurgia**|**Contagem plaquetária (/mm**<sup>**3**</sup>**)**|
|---|---|
|Profilaxia odontológica|≥ 20.000 – 30.000|
|Exodontia simples|≥ 30.000|
|Exodontia complexa|≥ 50.000|
|Bloqueio regional|≥ 30.000|
|Cirurgia menor<sup>(1)</sup>|≥ 50.000|
|Cirurgia maior|≥ 80.000|
|Neurocirurgia|≥ 100.000|  
**Nota** a – Cirurgia de catarata com laser não apresenta risco hemorrágico.  
**Fonte:** Adaptado de Provan et al. (2019)<sup>14</sup>

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
O objetivo do tratamento da PTI é reduzir o risco e prevenir a ocorrência de sangramento clinicamente significativo, cessar os sangramentos ativos e aumentar a contagem total de plaquetas.  
A necessidade de intervenção deve considerar a ocorrência e o risco de sangramento, a contagem plaquetária, os fatores psicossociais e o estilo de vida<sup>24,30</sup> . O tratamento medicamentoso eleva a plaquetometria com potencial redução do período sob risco de sangramentos relevantes<sup>49,50</sup> , porém, sem redução do risco de evolução para a forma crônica da doença<sup>51</sup> . Além disso, a escolha da terapia depende da rapidez com que os níveis de plaquetas precisam ser aumentados e dos diferentes perfis de toxicidade das terapias disponíveis.  
A maior parte das crianças com PTI tem uma evolução aguda, sem sangramentos significativos, mesmo com contagens de plaquetas inferiores a 10.000/mm<sup>3</sup> , e cerca de 80% dos casos evoluem para cura em até 6 meses, sem a necessidade de tratamento<sup>30,52</sup> . Diante disso, a observação clínica e laboratorial deve ser considerada como opção terapêutica inicial para crianças com quadro agudo restrito a manifestações cutâneas, como petéquias e hematomas, ou quando não houver evidência de sangramentos. A avaliação dos fatores que potencializam o risco de sangramentos é fundamental, incluindo trauma craniano, uso de medicamentos que afetem a contagem ou função plaquetária, presença de vasculites ou outras coagulopatias<sup>12,30</sup> .  
Adultos assintomáticos e com plaquetopenia leve a moderada (entre 30.000/mm<sup>3</sup> e 50.000/mm<sup>3</sup> ) tendem a ter um curso benigno da doença, sem necessidade de tratamento<sup>53,54</sup> . Em contrapartida, níveis de plaquetas persistentemente baixos (abaixo de 30.000/mm<sup>3</sup> ) estão relacionados a um pior prognóstico<sup>53,54</sup> . Por isso, a observação clínica é uma alternativa para adultos com plaquetopenia leve a moderada, desde que não haja sangramentos ou fatores de risco para sangramento, ao passo que o tratamento medicamentoso é recomendado para pacientes com plaquetas abaixo de 30.000/mm<sup>3 12,30</sup> . Os fatores de risco para sangramentos e outras circunstâncias clínicas específicas que podem sugerir a necessidade de iniciar o tratamento nos pacientes com plaquetometria acima de 30.000/mm<sup>3</sup> são descritas na seção Casos Especiais.  
Pacientes sob observação clínica e laboratorial devem ser orientados quanto:  
- 1) Ao risco substancial de hemorragias graves (mais prováveis quando o nível de plaquetas for inferior a 10.000/mm<sup>3</sup> );  
- 2) Aos sinais de sangramentos, devendo ser instruídos a contatar a equipe médica;  
- 3) Evitar a prática de atividades físicas, sobretudo os esportes de contato, e;  
- 4) Ao risco aumentado de sangramento em caso de uso de medicamentos com atividade antiplaquetária (e.g. ácido  
- acetilsalicílico e AINES)<sup>12,30</sup> .  
10  
Além disso, recomenda-se considerar o encaminhamento para suporte psicológico em pacientes com PTI que apresentem impacto psicossocial relevante ou prejuízo significativo na qualidade de vida, considerando a importância desses aspectos no controle clínico.  
**Cabe destacar que este Protocolo tem como foco a PTI primária. Assim, a PTI secundária a outras causas deve ser investigada e tratada conforme recomendações específicas para a doença de base** .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
As alternativas terapêuticas disponíveis para o tratamento de primeira linha da PTI primária incluem o uso de corticoides (prednisona, dexametasona, metilprednisolona) e imunoglobulina humana (IVIg). Os pacientes – sejam crianças ou adultos – que apresentarem plaquetometria persistentemente baixas (normalmente, abaixo de 30.000/mm<sup>3</sup> ) apesar do uso apropriado das terapias de primeira linha (corticoides e IVIg) são elegíveis aos tratamentos de segunda linha, bem como aqueles que apresentarem dependência ou contraindicação aos medicamentos de primeira linha.  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Os corticoides compreendem o tratamento padrão inicial da PTI e reduzem o sangramento independentemente da elevação das plaquetas<sup>55</sup> . No entanto, seu uso ocasiona eventos adversos que aparecem rapidamente e causam complicações, sobrepujando os benefícios ao longo do tempo. Os eventos adversos dos corticoides incluem alterações do comportamento, distúrbios do sono, aumento do apetite, ganho de peso, edema, osteoporose, infecções oportunistas, sintomas gástricos, catarata, insuficiência adrenal, hipertensão arterial, hiperglicemia e metrorragia<sup>56</sup> .  
Os corticoides disponíveis para tratamento da PTI são **prednisona, prednisolona** ou **dexametasona** . Recomenda-se a **prednisona** em doses mais baixas (0,5 a 2,0 mg/kg/dia) ou **dexametasona** 40 mg/dia por 4 dias. O uso de **prednisolona** em doses altas (4 mg/kg/dia) por três a quatro dias mostrou-se efetivo em 72% a 88% das crianças em até 72 horas<sup>30</sup> . Em adultos, inicialmente, estima-se que a resposta na contagem de plaquetas ocorra em 60% a 70% dos pacientes, no entanto, grande parte apresenta uma recaída em 6 meses<sup>57</sup> . Quando comparada à **prednisona** , a **dexametasona** apresenta resposta inicial maior e mais rápida, mas sem diferença significativa na manutenção da resposta<sup>58,59</sup> . No entanto, os eventos adversos são significativos (insônia, agressividade, perda de concentração), e por isso, seu uso deve ser reservado para situações especiais, como no preparo para esplenectomia<sup>30,52</sup> .  
Portanto, recomenda-se o uso de **dexametasona** para o tratamento inicial de adultos com plaquetopenia grave (contagem de plaquetas abaixo de 20.000/mm<sup>3</sup> ) que necessitam de um rápido aumento na contagem de plaquetas, assintomáticos ou com sangramentos sem repercussão clínica significativa (isto é, petéquias, púrpura, epistaxe e gengivorragia leves)<sup>58,59</sup> .  
11  
A administração parenteral de altas doses de **metilprednisolona** pode ser utilizada para promover um rápido aumento da contagem de plaquetas<sup>59</sup> , e tem sido usada em vários esquemas para tratar pacientes com falha na primeira linha terapêutica, obtendo taxa de resposta de 80%. Entretanto, pela duração curta do seu efeito, corticoides orais são necessários para manutenção da resposta.  
Dessa forma, indica-se o uso de corticoides como primeira linha de tratamento, e, pelo menor tempo possível. Para crianças sem sangramento maior, recomenda-se o uso de prednisona por menos de 7 dias, a fim de minimizar eventos adversos. **Pacientes dependentes de terapia com corticoides de longo prazo (uso por mais de 8 semanas)**<sup>60</sup> **ou que tenham recebido ciclos repetidos de corticoides devem ser encaminhados para serviços especializados com experiência em PTI, sendo elegíveis aos tratamentos para a doença refratária** .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
A **imunoglobulina humana intravenosa** (IVIg) faz parte da primeira linha de tratamento, juntamente com os corticoides, e pode ser utilizada por crianças e adultos<sup>61</sup> .  
Estudos demonstram que o efeito de altas doses de IVIg é comparável ao dos corticoides, mas com resposta em menor tempo (entre um e dois dias, podendo ocorrer incremento plaquetário nas primeiras oito horas). A duração da resposta sustentada é usualmente transitória, com as plaquetas voltando aos níveis pré-tratamento em duas a quatro semanas, podendo persistir por meses em alguns pacientes<sup>14,57</sup> .  
Por apresentar potencial para recuperação mais rápida da plaquetopenia, a IVIg está indicada para casos de sangramento mucoso com maior repercussão clínica (epistaxe e gengivorragia volumosas ou sangramento do trato digestivo ou urinário)<sup>14,57</sup> . Nos casos com sangramento grave e situações de risco, recomenda-se a associação com alta dose de metilprednisolona ou transfusão de plaquetas<sup>14,57</sup> . A IVIg também é efetiva como resgate em paciente crônicos, e pode ser associada às demais terapias de primeira ou segunda linha<sup>14,57</sup> .  
Os principais eventos adversos incluem cefaleia, neutropenia transitória, febre, flushing, fadiga, náusea, diarreia, alterações da pressão arterial, taquicardias e meningite asséptica. Insuficiência renal e trombose são eventos adversos graves, mas raros<sup>14,24</sup> . A IVIg também pode causar inibição da ligação do complemento às plaquetas, interferência na ligação de imunocomplexos às plaquetas e alteração da liberação de citocinas pelos macrófagos.  
Por não apresentar vantagem clínica sobre os tratamentos de primeira linha com corticoides e IVIg, o uso de imunoglobulina anti-D não é recomendado nesse Protocolo.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Os pacientes – sejam crianças ou adultos – que apresentarem plaquetometria persistentemente baixas (normalmente, abaixo de 30.000/mm<sup>3</sup> ) apesar do uso apropriado das terapias de primeira linha (corticoides e IVIg) são elegíveis aos tratamentos de segunda linha, bem como aqueles que apresentarem dependência (uso crônico por mais de oito semanas) ou contraindicação aos medicamentos de primeira linha. Para estes pacientes, **estão disponíveis os medicamentos azatioprina, ciclofosfamida, rituximabe, eltrombopague, romiplostim, danazol e vincristina (Quadro 5)** .  
**Quadro 5** . Medicamentos disponíveis para a PTI refratária em crianças, adolescentes e adultos.  
|**Medicamentos**|**Crianças e adolescentes**|**Adultos**|
|---|---|---|
|Azatioprina|Sim|Sim|
|Ciclofosfamida|Sim|Sim|
|Rituximabe|Acima de dois anos de idade|Sim|
|Eltrombopague|Acima de 6 anos de idade|Sim|
|Romiplostim|Acima de um ano de idade|Sim|  
12  
|**Medicamentos**|**Crianças e adolescentes**|**Adultos**|
|---|---|---|
|Danazol|Não recomendado|Sim, em caso de falha aos agentes<br>descritos acima|
|Vincristina|Reservada aos casos de falha terapêutica ou|refratariedade aos demais agentes|  
A escolha da terapia deve considerar o algoritmo de tratamento ( **Figura 1** ), o perfil de eventos adversos, farmacodinâmica, custo e fatores individuais dos pacientes, como o risco de sangramento, comorbidades e adesão. Na eventualidade de complicação não intencional inaceitável pelo medicamento em uso, é possível seguir para a próxima opção terapêutica. O tempo de tratamento em manutenção pode variar conforme o medicamento e a interrupção do medicamento deve ser avaliada sempre que possível. O paciente deverá ainda ser acompanhado pelo risco de recidiva posterior.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Recomenda-se que pacientes com PTI persistente ou crônica (i.e., duração da PTI maior que 3 meses a partir do diagnóstico) e com ausência de resposta ou dependência (uso crônico por mais de oito semanas) aos medicamentos de primeira linha sejam inicialmente tratados com **rituximabe, azatioprina ou ciclofosfamida** , tendo em vista a maior experiência com seu uso e com o controle de eventos adversos, e a razão de custo-efetividade dos tratamentos.  
Além disso, em caso de contraindicação, falha ou ausência de resposta, o médico pode optar por tentar demais medicamentos da mesma etapa de tratamento antes de seguir para próxima etapa. Por exemplo, pacientes que iniciam tratamento com **azatioprina** e não obtém resposta, podem receber **rituximabe** ou **ciclofosfamida** antes de iniciarem tratamento com **eltrombopague** ou **romiplostim.**  
A **azatioprina** é um imunossupressor que atua causando supressão da medula óssea com consequente diminuição dos linfócitos, redução da produção de imunoglobulinas e diminuição das secreções de interleucina 2 (IL-2). Os principais eventos adversos associados à **azatioprina** foram anemia, leucopenia reversível e aumento da suscetibilidade a infecções, hepatotoxicidade e pancreatite<sup>62</sup> . A taxa de resposta estimada para a **azatioprina** é de 40 a 60%<sup>63</sup> .  
A **ciclofosfamida** é um antineoplásico utilizado para tratamento na PTI refratária. Apesar da escassa evidência apontar para uma boa taxa de resposta (24 a 85%), a ciclofosfamida é utilizada com menor frequência devido à escassez de dados de segurança no longo prazo. Os principais eventos adversos são neutropenia, náuseas, vômitos, infertilidade e malignidade secundária<sup>63</sup> .  
O **rituximabe** é um anticorpo monoclonal que se liga ao antígeno CD20 dos linfócitos B e inicia reações imunológicas que mediarão a lise da célula B<sup>64</sup> , utilizado para tratamento de PTI nas últimas décadas, sendo considerado como uma opção terapêutica importante para pacientes com PTI<sup>65</sup> para tratamento de pacientes refratários ou crônicos, ou que não responderam ao tratamento de primeira linha com corticoides<sup>32,66,67</sup> . O **rituximabe** está aprovado para uso adulto e pediátrico acima de 2 anos.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Os TPO-RA (eltrombopaque e romiplostim) estimulam a maturação dos megacariócitos e a produção plaquetária. Na ocorrência de falha terapêutica a azatioprina, ciclofosfamida ou rituximabe, os pacientes devem ser tratados com **eltrombopague ou romiplostim** . Pacientes que iniciam o tratamento com um TPO-RA podem utilizar um segundo medicamento da mesma classe em caso de falha ou ausência de resposta, antes de seguirem para a próxima etapa do tratamento.  
O **eltrombopague** pode ser utilizado por crianças acima de 6 anos, adolescentes e adultos, e é bem tolerado, mas está associado a eventos adversos, como alterações das enzimas hepáticas aminotransferases/transaminases, risco de complicações trombóticas/tromboembólicas, cefaleia, insônia, fadiga, anemia, náusea, diarreia, mialgias, estado gripal, astenia, edema periférico, síndrome gripal e _rash_ cutâneo. Não houve alteração no padrão de eventos adversos mesmo após 5 anos de exposição<sup>63,68</sup> .  
13  
O **romiplostim** pode ser utilizado por crianças a partir de 1 ano de idade, adolescentes e adultos. A dose inicial recomendada é de 1 mcg/kg/semana, administrada por via subcutânea. As doses subsequentes devem ser ajustadas individualmente para manter a contagem de plaquetas dentro do intervalo de 50.000 a 200.000/mm<sup>3</sup> respeitando a dose máxima de 10 mcg/kg/semana. Nos estudos clínicos, a dose semanal variou de 2 a 10 mcg/kg. Os eventos adversos mais comumente relatados incluem cefaleia, epistaxe e trombocitose, sem registros de eventos adversos graves.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
No caso de falha, ausência de resposta ou contraindicação aos TPO-RA, os pacientes deverão ser tratados com **danazol** , com exceção de crianças e adolescentes pré-púberes, em vista do potencial de virilização desse medicamento e da sua segurança incerta nessa faixa etária. Assim, a **vincristina** é reservada aos casos de falha terapêutica ou refratariedade aos demais agentes ( **azatioprina/ciclofosfamida/rituximabe, eltrombopague/romiplostim** e **danazol** ) ou a crianças e adolescentes pré-púberes com refratariedade ou falha a **ciclofosfamida/azatioprina/rituximabe** e **eltrombopague/romiplostim** ).  
O **danazol** é um esteroide sintético recomendado apenas para pacientes adultos com PTI, cujas taxas de resposta variam amplamente (10% a 70%) entre os estudos e com baixa durabilidade de resposta. É menos frequentemente recomendado para mulheres devido aos efeitos virilizantes<sup>63</sup> .  
A **vincristina** é um alcaloide da vinca, antimitótico e antimicrotúbulo. As taxas de resposta variam entre 10% e 70%, com baixa durabilidade, porém com tempo para resposta relativamente curto (5 a 7 dias)<sup>63</sup> .  
14  
**Figura 1** . Fluxograma para definição do tratamento para PTI.  
<!-- Start of picture text -->
Pacientes de qualquer idade com contagem de plaquetas menor que 100.000/mm?<br>Investigar outras condicées clinicas que cursam com plaquetopenia<br>Tieterdoenca de N30 / plagnéstico de<br>(PTI secundaria)na \¢ PT! Leleprimaria?<br>sim<br>ap6sPTI tratamento persistente da\\$=»Sim ieNecessidadeanede da Nao ccontagemMonitorar de<br>doenca de base? PTI? plaquetas<br>Nao ‘Sim<br>Monitorar Utilzar prednisona,<br>imunogiobulina humana<br>paciente dexametasona, metilprednisolona,<br>intravenosa (IVIg)<br>Utlizar azatioprina, Sim _/meses,PTI por retratéia mais de ou3 “8° | Montorar<br>ciclofosfamida, rituximabe* dependentecorticoides? de Perna’<br>Sim __| Manter tratamento e<br>de plaquetas<br>Nao<br>Utilizar eltrombopague ou ‘Atingiu meta \_S'™__|Manter tratamento<br>romiplostim* terapéutica? de plaqu ae<br>Nao<br>‘Avaliar preferéncia, risco de infeccao<br>e eventos adversos do tratamento<br>medicamentoso<br>( Preferénciaprocedimento por \\—————»Sim _Esplenectomia<br>cinirgico?<br>Nao Nao Mantermonitorar tratamento contagem e<br>de plaquetas<br>Utilizar vineristina ou Atingiu meta sim<br>danazol terapéutica?<br>"Em caso de contraindicaco, falha ou auséncia de resposta, pode-se optar por trocar<br>entre as alternativas dessa mesma etapa de tratamento antes de seguir para a proxima<br>etapa.<br>2 Vincristina é reservada aos casos de falha terapéutica ou refratariedade a todos os<br>demais medicamentos ou a criancas e adolescentes pré-puiberes.<br><!-- End of picture text -->  
**Fonte** : Elaboração própria.  
**Nota:** O rituximabe é indicado para pacientes acima de dois anos de idade; o eltrombopague é indicado para pacientes acima de 6 anos de idade; o romiplostim é indicado para pacientes acima de um ano de idade e o danazol não é recomendado para uso por menores de 18 anos.  
15

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Em pacientes com PTI, define-se como emergência a presença de sangramento intracraniano ou mucoso (digestivo, geniturinário ou respiratório), com instabilidade hemodinâmica ou respiratória.  
O sangramento crítico em pacientes com trombocitopenia imune é definido como<sup>69</sup> :  
- Sangramento em local anatômico crítico, incluindo intracraniano, intraespinhal, intraocular, retroperitoneal, pericárdico  
- ou intramuscular com síndrome compartimental, ou;  
- Sangramento contínuo que resulta em instabilidade hemodinâmica ou comprometimento respiratório.  
O tratamento nas situações de emergência consiste em transfusões de plaquetas com ou sem IVIg e corticoide em altas doses<sup>14,70</sup> . Em casos selecionados, se necessário, é possível combinar tratamentos e adicionar a transfusão de plaquetas.  
A vincristina também pode ser considerada como uma alternativa terapêutica nas situações de emergência, especialmente quando há necessidade de resposta rápida ou quando houver falha ao tratamento com corticoides e IVIg. Este medicamento apresenta tempo de resposta geralmente entre 1 e 2 semanas, o que pode ser útil em casos agudos e graves não responsivos à IVIg ou à pulsoterapia com corticoides.  
O **Quadro 6** apresenta as doses de medicamentos utilizadas e o volume de plaquetas a ser transfundido em emergência  
nas crianças, adolescentes e adultos com PTI.  
**Quadro 6** . Medicamentos e transfusões de plaquetas nos casos de emergências para crianças, adolescentes e adultos.  
|**Produto**|**Crianças e adolescentes**|**Adultos**|
|---|---|---|
|Metilprednisolona|15 mg/kg a 30 mg/kg durante três dias|1 g/dia por três dias|
|Imunoglobulina<br>humana|0,8 g/kg a 1 g/kg por um a dois dias (repete|-se a dose no segundo dia caso a contagem de|
|intravenosa|plaquetas permaneça abaixo de 50.000/mm<sup>3</sup>)||
|Transfusões de plaquetas|Recomenda-se quantidade três vezes maior d|o que a usual, em vista da destruição rápida das|
|com ou sem IVIg|plaquetas que ocorre na PTI (3 unidades para c|ada 10 kg)|
|Vincristina|1,0 a 2,0 mg por via intravenosa, uma vez por|semana, por até quatro semanas|  
**Fonte:** Elaboração própria.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
- **Azatioprina** : comprimidos de 50 mg;  
- **Ciclofosfamida** : comprimidos de 50 mg;  
- **Danazol** : cápsulas de 100 mg e 200 mg;  
- **Dexametasona** : solução injetável de 4 mg/mL e comprimidos de 4 mg;  
- **Eltrombopague** : comprimidos revestidos de 25 mg e 50 mg;  
- **Imunoglobulina humana intravenosa** : solução injetável ou pó para solução injetável contendo 0,5 g, 1,0 g, 2,5 g e  
5 g;  
- **Metilprednisolona** : pó para solução injetável de 500 mg;  
- **Prednisolona:** solução oral de 1 mg/mL e 3 mg/mL;  
- **Prednisona** : comprimidos de 5 mg e 20 mg;  
- **Rituximabe** : solução injetável de 10 mg/mL;  
- **Romiplostim** : pó para solução injetável de 250 mcg/0,5 mL;  
- **Vincristina** : solução injetável de 1 mg/mL.  
16  
**Nota** : A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS. Já a administração intravenosa de vincristina é compatível procedimento 03.03.02.006-7 – Tratamento de defeitos da coagulação, púrpura e outras afecções hemorrágicas, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS, que é compatível com o código D69.3 – Púrpura Trombocitopênica Idiopática, da CID-10.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Os esquemas de administração para tratamento de crianças, adolescentes e adultos com PTI estão descritos no **Quadro**  
**7** :  
**Quadro 7.** Esquemas de administração dos tratamentos de crianças, adolescentes e adultos.  
|**Medicamentos**|**Crianças e adolescentes**|**Adultos**|
|---|---|---|
|**Tratamento de primeira linh**|**a**||
|Prednisona ou prednisolona|1 a 2 mg/kg/dia, por via oral, por 4 a 21 dias,<br>com redução progressiva da dose após<br>resposta<br>terapêutica<br>adequada;<br>ou<br>4<br>mg/kg/dia, por via oral, por três a quatro<br>dias<sup>a</sup>.|De 0,5 a 2 mg/kg/dia, por via oral, de 2 a 4<br>semanas (até que as plaquetas aumentem para<br>níveis entre 30.000/mm<sup>3</sup>e 50.000/mm<sup>3</sup>), com<br>redução progressiva da dose após adequada<br>resposta terapêutica. O tempo de tratamento<br>recomendado<br>é<br>de<br>até<br>oito<br>semanas.<br>Entretanto, se necessário, é aceitável dose<br>inferior a 0,5 mg/kg/dia após este período<sup>b</sup>.|
|Dexametasona|0,6 mg/kg/dia (máximo 40 mg/dia) por 4<br>dias, por via oral ou intravenosa, durante<br>quatro a oito dias.|40 mg/dia, por via oral ou intravenosa, por<br>quatro dias consecutivos; de um a seis ciclos a<br>cada 14 a 28 dias.|
|Metilprednisolona<sup>c</sup>|30<br>mg/kg/dia<br>(alta<br>dose),<br>por<br>via<br>intravenosa, durante três dias, seguido de 20<br>mg/kg/dia<br>nos<br>dias<br>restantes<sup>d</sup>;<br>não<br>ultrapassar a dose de 1 g/dia para crianças<br>com até 11 anos de idade.|30 mg/kg/dia ou 1 g/dia, por via intravenosa,<br>durante três dias.|
|Imunoglobulina<br>humana|0,8 g a 1 g/kg/dia em dose única, podendo|0,5 a 1 g/kg/dia, em dose única, podendo ser|
|intravenosa<sup>e</sup>|ser repetida se não houver resposta ou<br>completando<br>2<br>g/kg/ciclo;<br>ou<br>400<br>mg/kg/dia, durante cinco dias.|repetida<br>se<br>não<br>houver<br>resposta<br>ou<br>completando 2 g/kg/ciclo; ou 400 mg/kg/dia,<br>durante cinco dias.|
|**Tratamento de segunda linh**<br>|<br>**a**<br>||
|Azatioprina|2 mg/kg/dia, por via oral, diariamente.|150 mg/dia, por via oral, diariamente.|
|Ciclofosfamida|50 mg/m<sup>2</sup>a 100 mg/m<sup>2</sup>, por via oral, diariam|ente.|
|Rituximabe|375 mg/m² por semana, por via intravenosa,|durante quatro semanas|
|Eltrombopague f|Dose inicial de 50 mg, por via oral, uma ve<br>plaquetas acima de 50.000/mm<sup>3</sup>até dose<br>ascendência asiática, incluindo aqueles com<br>25 mg, por via oral, uma vez ao dia.|z ao dia. Ajustar dose para atingir contagem de<br>máxima de 75 mg/dia. Para pacientes com<br>insuficiência hepática, a dose inicial deve ser de|
|Romiplostim|Dose inicial de 1 mcg/kg/semana, administr<br>devem ser ajustadas para manter a contage<br>200.000/mm<sup>3</sup>até a dose máxima de 10 mcg/|ada por via subcutânea. As doses subsequentes<br>m de plaquetas dentro do intervalo de 50.000 a<br>kg/semana.|  
17  
|**Medicamentos**|**Crianças e adolescentes**|**Adultos**|
|---|---|---|
|Danazol|Não recomendado|400 mg/dia a 800 mg/dia, por via oral,|
|||diariamente.|
|Vincristina<sup>g</sup>|1,0 a 2,0 mg por via intravenosa, uma vez|por semana, por até quatro semanas.|  
**Fonte:** Elaboração própria. **Notas: a -** Esta dose é efetiva para induzir a resposta nas crianças, podendo ser usada por 4 a 21 dias, dependendo da velocidade de  
resposta desejada<sup>24,71</sup> . Atualmente, recomenda-se o uso de prednisona por menos de 7 dias, para pacientes sem sangramento maior, a fim de minimizar eventos adversos<sup>30,52,56,72</sup> . **b -** Para evitar complicações, recomenda-se reduzir progressivamente a dose tão logo haja melhora na contagem de plaquetas, ou em até quatro semanas para pacientes não responsivos. **c -** A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS. **d -** Reservada para casos em que é necessário o rápido incremento plaquetário, como alternativa ou em associação à IVIg, em sangramentos de maior gravidade<sup>72,73</sup> . **e -** Para minimizar eventos adversos, recomendase<sup>74</sup> : i) Pré-hidratação (30 minutos antes) com soro fisiológico 0,9%, com volume de 10 a 20 mL/kg em crianças; ii) Deixar o produto atingir a temperatura ambiente; iii) Reconstituição adequada de produtos liofilizados; iv) Monitorar sinais vitais a cada 20 a 30 minutos; v) Velocidade de infusão lenta, principalmente nas primeiras aplicações do paciente e utilizando bombas de infusão, sempre que possível. Iniciando-se com 0,01 mL/kg/ minuto (0,5 a 1 mg/kg/minuto), aumentando gradativamente (cada 15 a 30 minuto) para 0,02 mL/kg/minuto, 0,04 mL/kg/min, 0,06 mL/kg/min até 0,08 mL/kg/min (4 a 8 mg/kg/minuto, respectivamente para produtos a 5 e 10%), em 3 a 6 horas. Manter o paciente sob observação por 30 a 60 minutos após o término da infusão. **f –** Crianças acima de 6 anos de idade. **g -** A administração intravenosa de vincristina é compatível procedimento 03.03.02.006-7 – Tratamento de defeitos da coagulação, púrpura e outras afecções hemorrágicas, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS, que é compatível com o código D69.3 – Púrpura Trombocitopênica Idiopática, da CID-10.  
Por se ligar a cátions divalentes (cálcio, ferro, magnésio), a absorção de **eltrombopague** diminui significativamente. Portanto, o medicamento precisa ser ingerido com o estômago vazio (1 hora antes ou 2 horas depois de qualquer refeição); e ao menos 4 horas antes ou depois de outros medicamentos, alimentos ricos em cálcio (laticínios e alimentos enriquecidos com cálcio) ou outros suplementos (ferro, selênio, zinco ou magnésio). As restrições alimentares podem ter um impacto significativo na aderência e efetividade do tratamento. Os estudos demonstram segurança, entretanto, alguns pacientes apresentam alterações hepáticas transitórias, sendo necessário interromper o tratamento<sup>63,68</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Os medicamentos incluídos neste PCDT são contraindicados a pessoas com hipersensibilidade aos princípios ativos ou quaisquer componentes das fórmulas. Demais contraindicações estão apresentadas no **Quadro 8** , e foram obtidas das respectivas bulas dos medicamentos,  
18  
**Quadro 8.** Contraindicações aos medicamentos incluídos no PCDT.  
|**Medicamentos**|**Contraindicação**|
|---|---|
|Corticoides|Pacientes com infecções fúngicas sistêmicas ou infecções não controladas.<br>A administração de vacinas de microrganismos vivos ou atenuados é contraindicada em pacientes<br>recebendo doses imunossupressoras de corticosteroides.|
|IVIg|Pacientes com anticorpos contra IgA|
|Azatioprina|Não deve ser utilizada por mulheres grávidas ou que pretendam engravidar sem orientação médica<br>(categoria de risco na gravidez: D).|
|Ciclofosfamida|Pacientes portadores de problemas da medula óssea, varicela (catapora), Herpes zoster, obstrução das<br>vias urinárias, cistite e infecções agudas. Este medicamento não deve ser utilizado por mulheres<br>grávidas ou que possam ficar grávidas durante o tratamento.|
|Rituximabe|Pacientes em estado gravemente imunocomprometido, pacientes com infecções ativas e graves,<br>insuficiência cardíaca grave (Classe IV da New York Heart Association) ou cardiopatia não<br>controlada grave.<br>Não deve ser utilizado por mulheres grávidas sem orientação médica ou do cirurgião-dentista<br>(categoria de risco na gravidez: C).|
|Danazol|Pessoas que sofrem de insuficiência grave dos rins, do fígado e do coração; mulheres grávidas ou que<br>possam ficar grávidas durante o tratamento; e mulheres durante a amamentação.|
|Vincristina|Pacientes que apresentam a forma desmielinizante da Síndrome de Charcot-Marie Tooth. Não deve<br>ser utilizada por mulheres grávidas ou que pretendam engravidar sem orientação médica (categoria<br>de risco na gravidez: D).|  
IVIg: Imunoglobulina humana intravenosa

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
O tempo de tratamento é definido de acordo com a contagem de plaquetas e o esquema terapêutico utilizado.  
Os corticoides devem ser utilizados pelo menor período possível, visando a evitar o desenvolvimento de eventos adversos, respeitando os esquemas terapêuticos descritos anteriormente. Assim, sua suspensão deve ser considerada se a contagem de plaquetas estiver acima de 20.000/mm<sup>3</sup> e não ocorrerem novos sangramentos. **Pacientes dependentes de terapia com corticoides de longo prazo (uso por mais de 8 semanas)**<sup>60</sup> **ou que tenham recebido ciclos repetidos de corticoides devem ser encaminhados para serviços especializados com experiência em PTI, sendo elegíveis aos tratamentos para a doença refratária** .  
Inexiste tempo mínimo universalmente estabelecido para o uso do tratamento antes da avaliação da resposta terapêutica, pois esse intervalo pode variar conforme o medicamento e o quadro clínico do paciente. De maneira geral, para **rituximabe, azatioprina e ciclofosfamida** , recomenda-se observar a resposta por aproximadamente 3 a 4 semanas após o início do tratamento, reconhecendo que podem ocorrer respostas tardias. Para os TPO-RA ( **eltrombopague e romiplostim** ), a resposta pode ser observada a partir de 5 dias, mas recomenda-se uma avaliação mais abrangente após cerca de 4 semanas em dose plena antes de considerar falha terapêutica ou necessidade de troca.  
**A resposta terapêutica é definida pela contagem de plaquetas acima de 30.000/mm**<sup>**3**</sup> **OU acima de 50.000/mm**<sup>**3**</sup> **na presença de sangramento ou de fatores de risco para sangramento.**  
Em pacientes com plaquetometria acima de 30.000/mm<sup>3</sup> por mais de seis meses (dependendo do histórico e do número de linhas terapêuticas utilizadas), pode-se considerar a suspensão temporária do tratamento.  
19

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Embora a esplenectomia possa oferecer uma maior taxa de resposta duradoura (até 70% dos casos) em comparação com outras terapias, seu uso vem declinando pelo surgimento de novas alternativas terapêuticas com menor risco de complicações. Por isso, recomenda-se que o procedimento seja postergado e reservado aos pacientes que apresentaram falha após o uso de múltiplas terapias<sup>75</sup> .  
Atualmente, inexiste consenso sobre o momento ideal para indicar a esplenectomia, mas, considerando as chances de remissões espontâneas ou induzidas por terapia, recomenda-se que o procedimento seja postergado nos primeiros 12 meses após o diagnóstico de PTI<sup>75</sup> , conforme **Figura 1** .  
Recomenda-se a vacinação contra _Streptococcus pneumoniae_ , _Haemophilus influenzae b_ e _Neisseria meningitidis do_ sorogrupo C, pelo menos 15 dias antes do procedimento. A contagem plaquetária deve estar acima de 50.000/mm<sup>3</sup> para realização do procedimento, sendo frequentemente indicado uso de IVIg ou corticoides para elevação da contagem plaquetária no período pré-operatório.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
O tratamento da PTI na gestação é multiprofissional, envolvendo obstetras, hematologistas, anestesistas e neonatologistas. A maioria das mulheres com PTI apresenta diminuição na contagem de plaquetas durante a gestação e, em muitos casos, a terapia deve ser reiniciada ou intensificada e deve haver um preparo especial para o parto<sup>14,25</sup> .  
Apesar de contagens plaquetárias abaixo de 30.000/mm<sup>3</sup> serem relativamente raras<sup>39,76,77</sup> , as pacientes devem ser tratadas adequadamente devido aos eventos hemorrágicos durante a gravidez, o parto e após o parto. Assim, deve-se considerar também o risco de hemorragia materna para que que a gestação possa prosseguir com segurança e sem riscos de sangramentos para a mãe e para o feto. Salienta-se que as agências internacionais não regularizam o tratamento durante a gestação<sup>25</sup> .  
As contagens de plaquetas devem ser mais frequentes no terceiro trimestre para auxiliar na escolha do tipo de parto, bem como seguimento da paciente após o parto. Salienta-se que o tipo do parto é, em geral, uma indicação obstétrica. Devido ao risco de hemorragia, a paciente deve ser acompanhada em serviço especializado com profissionais treinados para este tipo especial de atendimento<sup>78</sup> . No momento do parto, seja por via vaginal ou cesárea, devem ser mantidas, idealmente, contagens de plaquetas acima de 50.000/mm<sup>3</sup> , tendo em vista o risco de sangramento aumentado que pode ocorrer com menores concentrações plaquetárias. A contagem de plaquetas entre 70.000/mm<sup>3</sup> e 80.000/mm<sup>3</sup> é recomendada para a segurança das anestesias espinhal e peridural<sup>57,79,80</sup> .  
O tratamento específico da gestante com PTI é similar ao de adultos, recomendando-se que seja instituído apenas quando houver indicação materna (contagem de plaquetas inferior a 20.000/mm<sup>3</sup> ou 30.000/mm<sup>3</sup> ).  
A primeira linha de tratamento é o emprego de corticoide, como a prednisona em baixas doses (10 mg/dia a 20 mg/dia), ajustando-a até a dose mínima que resulte em contagem de plaquetas hemostaticamente efetiva. A posterior diminuição da dose deve ser realizada lentamente. No curto prazo, estes medicamentos são efetivos e seguros, pois grande parte é inativada pela placenta<sup>81</sup> .  
Outra alternativa possível é a IgIV na dose de 400 mg/kg ao dia, por até 5 dias, ou de 1 g/kg por dia, administrado por 1 ou 2 dias<sup>25</sup> , quando houver contraindicação ou ausência de resposta aos corticoides, bem como quando houver sangramento<sup>25</sup> . A IgIV é bem tolerada e sua administração pode ser repetida para prevenir hemorragias ou manter a contagem segura de plaquetas para o parto<sup>24</sup> .  
Nos casos refratários, uma combinação de medicamentos pode ser usada nas semanas anteriores ao parto: **metilprednisolona** pode ser administrada em altas doses (1.000 mg), combinada com IVIg ou **azatioprina** (50 a 75 mg/dia). Contudo, inexiste consenso sobre esta segunda linha)<sup>25</sup> .  
20  
Nas pacientes com PTI crônica e plaquetopenia persistente, sem resposta às medidas terapêuticas anteriormente citadas, recomenda-se postergar, dentro do possível, a realização de esplenectomia, visto que parte das pacientes recupera a contagem de plaquetas após o parto<sup>25,82</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
A maioria dos pacientes com PTI pode ser tratada e acompanhada em ambulatórios, com visitas semanais, no mínimo. As hospitalizações são indicadas em caso de hemorragias clinicamente significativas.  
Para o início do tratamento com qualquer um dos medicamentos preconizados por este PCDT, deverão ser apresentados a anamnese, incluindo avaliação do histórico clínico e familiar, exame físico e o hemograma completo (incluindo a plaquetometria). Outros exames complementares podem ser necessários para o diagnóstico diferencial da PTI primária (conforme seção **Diagnóstico** ), mas não são obrigatórios para todos os pacientes para início do tratamento, uma vez que a recomendação destes exames deve ser feita conforme suspeita clínica.  
O **Quadro 9** apresenta os exames complementares (além do hemograma com plaquetometria) exigidos para início do tratamento e os exames recomendados para acompanhamento clínico. Todavia, as recomendações de monitoramento visam a orientar o tratamento, **mas não devem ser interpretadas como exames obrigatórios para continuidade do tratamento** , considerando o risco de interromper a terapia e expor o paciente a sangramentos.  
21  
**Quadro 9.** Resumo das avaliações para monitoramento.  
|**Avaliação**|**Medicamento**|**Avaliação antes**<br>**do início do**<br>**tratamento**|**Monitorização e periodicidade**|
|---|---|---|---|
|Anamnese|Todos|Sim|Sim, a cada 6 meses|
|Hemograma completo|Todos|Sim|Sim, a cada 6 meses|
|Sorologias para hepatite B,<br>hepatite C e HIV|Todos, para adultos;<br>opcionais para<br>crianças com doença<br>refratária ou crônica|Sim|Não|
|Pesquisa de TB ativa e ILTB|Rituximabe,<br>Azatioprina e<br>Ciclofosfamida|Sim|Conforme Manual de Recomendações para o<br>Controle da Tuberculose no Brasil|
|Dosagem sérica de<br>imunoglobulinas|Rituximabe|Sim|Não|
|Dosagem sérica de<br>TGO/AST, TGP/ALT e GGT|Azatioprina<br>Eltrombopague|Sim|Azatioprina: a cada oito semanas<br>Eltrombopague: a cada duas semanas durante<br>a fase de ajuste da dose e mensalmente após o<br>estabelecimento de uma dose estável.|
|Dosagem de bilirrubina|Eltrombopague|Sim|A cada duas semanas, apenas durante a fase<br>de ajuste da dose.|
|Dosagem sérica de fosfatase<br>alcalina|Danazol|Não|Mensalmente, nos primeiros três meses e,<br>após, a cada seis meses|
|Perfil lipídico (colesterol<br>total, DHL e triglicerídeos)|Danazol|Não|Mensalmente, nos primeiros três meses e,<br>após, a cada seis meses|
|Ultrassonografia abdominal|Danazol|Não|Anualmente|
|Dosagem sérica de Beta-<br>HCG ou teste rápido de<br>gravidez|Danazol<br>Vincristina|Sim|Não|  
**Fonte:** Elaboração própria.  
**Legenda:** TGO/AST: transaminase glutâmico oxalacética/ aspartato aminotransferase; TGP/ALT; transaminase glutâmico pirúvica/alanina aminotransferase; GGT: gama glutamil transferase  
**Crianças e adolescentes** com quadro agudo de PTI devem realizar hemograma completo diariamente enquanto houver sangramento ativo ou a critério médico se as contagens de plaquetas estiverem abaixo de 10.000/mm<sup>3</sup> . Após a estabilização, sugere-se reavaliação clínica após três semanas do quadro inicial, com nova contagem de plaquetas. Recomenda-se, ainda, uma avaliação entre três e seis meses com novo hemograma completo, a fim de identificar os eventuais casos que evoluirão para a forma crônica. Pacientes que desenvolverem essa forma deverão ser monitorizados do mesmo modo proposto para os adultos.  
Os **adultos** devem ser monitorizados, inicialmente, com hemograma completo diariamente enquanto houver sangramento ativo ou a critério médico, se as contagens de plaquetas estiverem abaixo de 10.000/mm<sup>3</sup> . Inicialmente, recomenda-se que o monitoramento com hemograma com plaquetas deve ser repetido após três semanas e cerca de três a seis meses do episódio inicial.  
22  
Entretanto, cabe destacar que a frequência do monitoramento e repetição dos exames, tanto para pacientes adultos quanto pediátricos, deverá ser avaliada pelo médico e determinada conforme a necessidade clínica, considerando a terapia instituída, a fase da PTI, o risco hemorrágico e a necessidade de controle dos eventos adversos.  
Para os pacientes que evoluírem para a forma crônica, sugere-se avaliação médica e hemograma com plaquetas a cada três ou quatro meses quando o quadro for estável e as contagens seguras (acima de 20.000 plaquetas/mm<sup>3</sup> ) nos primeiros dois anos de acompanhamento. Em pacientes com evolução favorável, pode-se espaçar as avaliações após esse período.  
Os pacientes com a forma crônica refratária e indicação de tratamento deverão realizar hemograma com plaquetas de duas a três vezes por semana enquanto as plaquetas estiverem em contagens abaixo de 10.000/mm<sup>3</sup> . Quando as contagens estiverem entre 10.000/mm<sup>3</sup> e 20.000/mm<sup>3</sup> , o hemograma com plaquetas deve ser realizado semanalmente até que três contagens estáveis sejam obtidas, momento em que o exame pode ser realizado a cada duas ou três semanas a critério médico. Quando as contagens estiverem acima de 20.000/mm<sup>3</sup> , o hemograma com plaquetas pode ser realizado inicialmente a cada quatro semanas e esse intervalo pode ser ampliado para cada seis ou oito semanas após três medidas estáveis.  
Adicionalmente, deve ser realizada monitorização clínico-laboratorial de pacientes em tratamento para PTI crônica e refratária, de acordo com o medicamento em uso.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **rituximabe** deverão, adicionalmente, realizar testes pré-tratamento para triagem de hepatite B e hipogamaglobulinemia. Os portadores de hepatite B podem sofrer ativação com o tratamento com rituximabe. A hipogamaglobulinemia, embora infrequente com o rituximabe sozinho, pode ocorrer se o rituximabe for administrado concomitantemente com a dexametasona e raramente é grave o suficiente para exigir substituição<sup>83</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **azatioprina** devem realizar dosagem de aminotransferases e transaminases hepáticas (AST/TGO e ALT/TGP) a cada oito semanas. Se houver elevação dessas enzimas entre 3 e 5 vezes o valor de referência, recomenda-se redução da dose pela metade. Se houver elevação superior a 5 vezes o valor de referência, o medicamento deve ser suspenso. Também deve-se atentar para a ocorrência de leucopenia e neutropenia. Em pacientes com contagens de leucócitos entre 3.000/mm<sup>3</sup> e 4.000/mm<sup>3</sup> , sugere-se observação com hemograma pelo menos a cada duas semanas e, se houver persistência por quatro ou mais semanas, redução de 25% da dose. Se os leucócitos se situarem entre 2.000/mm<sup>3</sup> e 3.000/mm<sup>3</sup> ou se os neutrófilos estiverem entre 1.000/mm<sup>3</sup> e 1.500/mm<sup>3</sup> , sugere-se redução de 50% da dose. Se as contagens de leucócitos estiverem abaixo de 2.000/mm<sup>3</sup> ou as de neutrófilos estiverem abaixo de 1.000/mm<sup>3</sup> , sugere-se a suspensão do uso do medicamento. O uso de **azatioprina** pode elevar os níveis de gama-GT, portanto é necessário monitoramento deste parâmetro, bem como avaliar o comprometimento renal antes do início do tratamento e para ajuste de dose. Nos casos de suspensão, pode-se reiniciar o tratamento com redução de 50% da dose, caso não tenha ocorrido tentativa prévia. Nos casos que necessitem de duas ou mais suspensões por toxicidade, o medicamento deve ser interrompido de forma definitiva.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **ciclofosfamida** devem realizar hemograma para avaliar a ocorrência de leucopenia a cada duas semanas. Se a leucometria estiver entre 2.500/mm<sup>3</sup> e 3.500/mm<sup>3</sup> , deve-se reduzir a dose em 25%. Na ocorrência de leucometria entre 2.000/mm<sup>3</sup> e 2.500/mm<sup>3</sup> , a redução da dose deve ser de 50%. O medicamento deve ser suspenso temporariamente se a contagem de leucócitos estiver abaixo de 2.000/mm<sup>3</sup> , devido ao risco de infecções oportunistas. Nos casos de suspensão, é possível reiniciar o tratamento com redução de 50% da dose (se não houver tentativa prévia). Nos casos que necessitem de duas ou mais suspensões por toxicidade, o medicamento deve ser interrompido de forma definitiva e a dosagem de creatinina deve ser realizada mensalmente.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
23  
Alguns medicamentos imunossupressores podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) previamente ao início do tratamento.  
Antes do início do uso de imunossupressores e com objetivo de realizar o planejamento terapêutico adequado, deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB. Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados para investigar a presença de ILTB, como radiografia simples de tórax, a prova tuberculínica (PT com o _purified protein derivative_ – PPD) ou o IGRA (Interferon-Gamma _Release assays_ ), que podem ser solicitados para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desses exames.  
O tratamento da ILTB é indicado para pacientes com PT ≥ 5 mm ou IGRA reagente. Proceder também com o tratamento da ILTB, sem necessidade de realizar o IGRA ou a PT quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar. Os esquemas de tratamento da TB ativa e da ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomendase o início do uso de MMCD após 1 mês do início do tratamento de ILTB ou concomitantemente ao tratamento da TB ativa.  
Para fins de acompanhamento, considera-se desnecessário repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
Não há necessidade de repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição (novo contato).  
Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente recomenda-se repetir a PT ou IGRA anualmente, especialmente locais com alta carga de tuberculose. Não há necessidade de repetir a radiografia simples de tórax, caso não haja suspeita clínica de TB, exceto no caso PT ≥ 5 mm ou IGRA reagente nessa avaliação anual. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir em uma nova amostra. Cabe destacar que essa avaliação deva ser a rotina no seguimento da doença de base. **A dispensação dos medicamentos para a doença de base não deve ser condicionada à realização dos exames para acompanhamento** .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **eltrombopague** devem ser avaliados quanto aos níveis séricos de ALT/TGT, AST/TGO e bilirrubina antes de iniciarem o tratamento, a cada duas semanas durante a fase de ajuste da dose e mensalmente após o estabelecimento de uma dose estável. Deve-se realizar contagens de plaquetas uma vez por semana no primeiro mês de tratamento e, posteriormente, uma vez ao mês, até atingir valores acima de 50.000/mm<sup>3</sup> .  
Para pacientes em uso de **eltrombopague** , se as plaquetas persistirem abaixo de 50.000/mm<sup>3</sup> , é indicado aumentar a dose diária. Se a contagem de plaquetas estiver entre 200.000/mm<sup>3</sup> e 400.000/mm<sup>3</sup> , é indicado diminuir a dose em 25 mg/dia, avaliando novamente em duas semanas. Se a contagem de plaquetas estiver acima de 400.000/mm<sup>3</sup> , é necessário interromper o tratamento e reavaliar a contagem duas vezes por semana até atingir valores menores que 150.000/mm<sup>3</sup> , quando o paciente poderá reiniciar o tratamento com a menor dose diária. A dose diária não pode ser maior que 75 mg, e caso o paciente não apresente resposta após quatro semanas, é indicado suspender o tratamento. Se houver necessidade, pode-se considerar diminuição da dose para 25 mg/dia em dias alternados. Deve-se monitorar as contagens de plaquetas sempre que a dose for ajustada, pelo menos uma vez por semana, durante duas a três semanas. Além das plaquetas, há necessidade de avaliar hemograma, esfregaço periférico, provas de função hepática e função renal ao longo do tratamento até a estabilização do quadro<sup>84</sup> .  
24  
Para pacientes em uso de **romiplostim** , se as plaquetas persistirem abaixo de 50.000/mm<sup>3</sup> , é indicado aumentar a dose semanal em 1 mcg/kg. Se a contagem de plaquetas estiver acima de 150.000/mm<sup>3</sup> por duas semanas consecutivas, recomendase reduzir a dose semanal em 1 mcg/kg.  
No acompanhamento de pacientes em uso de eltrombopague ou romiplostim, embora seja extremamente raro, o aparecimento de alterações leucoeritroblásticas no hemograma associadas à elevação de DHL pode indicar evolução para fibrose de medula óssea. Nesses casos, a critério médico, deve-se considerar a realização de biópsia de medula óssea e a interrupção do tratamento ou troca da classe medicamentosa.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **vincristina** deverão realizar hemograma a cada seis semanas para avaliar a contagem de leucócitos. Para pacientes com contagens entre 3.000/mm<sup>3</sup> e 4.000/mm<sup>3</sup> , sugere-se observação com hemogramas pelo menos a cada duas semanas e, se houver persistência por quatro ou mais semanas, redução da dose em 25%. Se a leucometria se situar entre 2.000/mm<sup>3</sup> e 3.000/mm<sup>3</sup> ou os neutrófilos encontrarem-se entre 1.000/mm<sup>3</sup> e 1.500/mm<sup>3</sup> , sugere-se redução da dose em 50%. Nos casos em que a contagem de leucócitos for menor que 2.000/mm<sup>3</sup> ou a de neutrófilos for menor que 1.000/mm<sup>3</sup> , sugere-se a suspensão do uso do medicamento. Nos casos de suspensão, pode-se reiniciar o tratamento com redução da dose em 50% (se já não realizada previamente). Se forem necessárias duas ou mais suspensões por toxicidade, o medicamento deve ser interrompido de forma definitiva. Os pacientes deverão, ainda, ser monitorizados clinicamente, a cada seis semanas, em relação à ocorrência de neuropatia periférica. Pacientes que apresentarem neuropatia periférica sensitiva ou motora deverão ser monitorizados a cada três semanas. Naqueles com alterações leves (sem qualquer repercussão na vida diária), a dose deverá ser reduzida em 25%; naqueles com grau moderado (repercussão leve nas atividades de vida diária), a dose deverá ser reduzida em 50%; pacientes com neuropatia grave, com limitação significativa nas atividades diárias, deverão ter o tratamento interrompido em definitivo.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: Geral -->
Pacientes em uso de **danazol** deverão realizar provas hepáticas (aminotransferases, transaminases, fosfatase alcalina) e perfil lipídico (colesterol total, DHL e triglicerídeos) mensalmente, nos primeiros três meses e, após, a cada seis meses, e ultrassonografia abdominal anualmente. Na ocorrência de elevações entre 3 e 5 vezes o valor da normalidade das aminotransferases e transaminases, a dose de **danazol** deve ser reduzida em 25%. Elevações superiores a 5 vezes o valor da normalidade requerem interrupção do medicamento e reinício com dose 50% menor. Pacientes que apresentarem alterações na dosagem de aminotransferases e transaminases devem ter seus níveis séricos avaliados pelo menos a cada oito semanas até a estabilização. Alterações no perfil lipídico devem ser tratadas, inicialmente com orientações dietéticas, reservando o tratamento medicamentoso aos casos com alteração persistente ou a critério do médico assistente. O surgimento de lesão hepática suspeita de neoplasia diagnosticada por meio de ultrassonografia abdominal deve acarretar suspensão imediata do uso de **danazol** .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **8.1     Monitoramento da PTI na gestação** -->
Nos dois primeiros trimestres, o tratamento é iniciado quando a paciente é sintomática, se a contagem de plaquetas estiver inferior a 30.000/mm<sup>3</sup> ou para aumentar as plaquetas para um nível seguro para procedimentos<sup>25</sup> . Pacientes com contagem de plaquetas igual ou maior a 30.000/mm<sup>3</sup> ou mais não requerem tratamento de rotina e devem ser monitoradas conforme a proximidade do parto, podendo ser realizado uma vez por semana<sup>70</sup> . Em geral, após o parto, o controle é semelhante ao da população geral.  
A PTI neonatal de mães com a doença é responsável por aproximadamente 3% de todos os casos de trombocitopenia pósparto e raramente precisa ser tratada, mas pode durar vários meses e requer monitorização em longo prazo<sup>25,70,82</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **8.1     Monitoramento da PTI na gestação** -->
25  
Aproximadamente 9 a 15% dos recém-nascidos nascem com contagem de plaquetas menor que 50.000/mm<sup>3 85</sup> , mas não há um marcador preciso para prever quem desenvolverá esta condição<sup>25</sup> . Em geral, os estudos não identificaram uma associação entre trombocitopenia neonatal e doença materna mais intensa, contagem mais baixa ou uso de tratamento próximo ao parto<sup>86–</sup> 90, esplenectomia materna91–95 e presença de anticorpos antiplaquetários circulantes89.  
Revisões mais recentes sugerem que a mortalidade neonatal de mães com PTI é muito baixa. A trombocitopenia grave em neonatos (contagem de plaquetas inferior a 50.000/mm<sup>3</sup> ) pode ocorrer em torno de 10%, enquanto a hemorragia intracraniana ocorre em 0% a 1,5% daqueles com trombocitopenia<sup>96</sup> .

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **8.1     Monitoramento da PTI na gestação** -->
Devem ser observados os critérios de inclusão e exclusão contidos neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas, a adequação de uso e o acompanhamento pós-tratamento. Pessoas com PTI recém-diagnosticada devem ser atendidas e acompanhadas na atenção primária à saúde e, em casos de doença persistente ou crônica (conforme Quadro 2) ou pacientes incluídos como Casos Especiais (Seção 7 deste PCDT), devem ser encaminhadas aos serviços especializados em hematologia.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **8.1     Monitoramento da PTI na gestação** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **11      REFERÊNCIAS** -->
1. Cooper N, Ghanima W. Immune Thrombocytopenia. Solomon CG, editor. New England Journal of Medicine. 2019 Sep 5;381(10):945–55.  
2. Kistangari G, McCrae KR. Immune thrombocytopenia. Hematol Oncol Clin North Am. 2013;27(3):495–520.  
3. Liu X guang, Hou Y, Hou M. How we treat primary immune thrombocytopenia in adults. J Hematol Oncol. 2023;16(1):1–20.  
26  
4. Rodeghiero F, Stasi R, Gernsheimer T, Michel M, Provan D, Arnold DM, et al. Standardization of terminology, definitions and outcome criteria in immune thrombocytopenic purpura of adults and children: Report from an international working group. Blood. 2009;113(11):2386–93.  
5. Singh A, Uzun G, Bakchoul T. Primary immune thrombocytopenia: Novel insights into pathophysiology and disease management. J Clin Med. 2021;10(4):1–21.  
6. Kuwana M, Kaburaki J, Okazaki Y, Miyazaki H, Ikeda Y. Two types of autoantibody-mediated thrombocytopenia in patients with systemic lupus erythematosus. Rheumatology. 2006 Jul 1;45(7):851–4.  
7. Delgado RB, Viana MB, Fernandes RAF. Púrpura trombocitopênica imune da criança: Experiência de 12 anos em uma única instituição brasileira. Rev Bras Hematol Hemoter. 2009;31(1):29–36.  
8. Georgi JA, Middeke JM, Bornhäuser M, Matzdorff A, Trautmann-Grill K. Deciphering the genetic basis of immune thrombocytopenia: current evidence for genetic predisposition in adult ITP. Blood Adv. 2023 Jul 25;7(14):3710–24.  
9. Cines DB, Bussel JB, Liebman HA, Luning Prak ET. The ITP syndrome: pathogenic and clinical diversity. Blood. 2009 Jun 25;113(26):6511–21.  
10. Arnold DM, Nazy I, Clare R, Jaffer AM, Aubie B, Li N, et al. Misdiagnosis of primary immune thrombocytopenia and frequency of bleeding: lessons from the McMaster ITP Registry. Blood Adv. 2017 Nov 28;1(25):2414–20.  
11. Moulis G, Palmaro A, Montastruc JL, Godeau B, Lapeyre-Mestre M, Sailler L. Epidemiology of incident immune thrombocytopenia: A nationwide population-based study in France. Blood. 2014;124(22):3308–15.  
12. Neunert C, Noroozi N, Norman G, Buchanan GR, Goy J, Nazi I, et al. Severe bleeding events in adults and children with primary immune thrombocytopenia: a systematic review. Journal of Thrombosis and Haemostasis. 2015 Mar;13(3):457– 64.  
13. Piel‐Julian M ‐L., Mahévas M, Germain J, Languille L, Comont T, Lapeyre‐Mestre M, et al. Risk factors for bleeding, including platelet count threshold, in newly diagnosed immune thrombocytopenia adults. Journal of Thrombosis and Haemostasis. 2018 Sep;16(9):1830–42.  
14. Provan D, Arnold DM, Bussel JB, Chong BH, Cooper N, Gernsheimer T, et al. Updated international consensus report on the investigation and management of primary immune thrombocytopenia. Blood Adv. 2019 Nov 26;3(22):3780–817.  
15. Hill QA, Newland AC. Fatigue in immune thrombocytopenia. Br J Haematol. 2015 Jul 30;170(2):141–9.  
16. Terrell DR, Beebe LA, Vesely SK, Neas BR, Segal JB, George JN. The incidence of immune thrombocytopenic purpura in children and adults: A critical review of published reports. Am J Hematol. 2010;NA-NA.  
17. Weycker D, Hanau A, Hatfield M, Wu H, Sharma A, Bensink ME, et al. Primary immune thrombocytopenia in US clinical practice: incidence and healthcare burden in first 12 months following diagnosis. J Med Econ. 2020 Feb 1;23(2):184–92.  
18. Abrahamson PE, Hall SA, Feudjo-Tepie M, Mitrani-Gold FS, Logie J. The incidence of idiopathic thrombocytopenic purpura among adults: A population-based study and literature review. Eur J Haematol. 2009;83(2):83–9.  
19. Terrell DR, Beebe LA, Neas BR, Vesely SK, Segal JB, George JN. Prevalence of primary immune thrombocytopenia in Oklahoma. Am J Hematol. 2012 Sep;87(9):848–52.  
20. Cooper N. A review of the management of childhood immune thrombocytopenia: How can we provide an evidencebased approach? Br J Haematol. 2014;165(6):756–67.  
21. Neunert CE, Buchanan GR, Imbach P, Bolton-Maggs PHB, Bennett CM, Neufeld E, et al. Bleeding manifestations and management of children with persistent and chronic immune thrombocytopenia: data from the Intercontinental Cooperative ITP Study Group (ICIS). Blood. 2013 May 30;121(22):4457–62.  
22. Stasi R, Stipa E, Masi M, Cecconi M, Scimò MT, Oliva F, et al. Long-Term observation of 208 adults with chronic idiopathic thrombocytopenic purpura. Am J Med. 1995;98(5):436–42.  
27  
23. Silva CL, Grando AC. Complications of idiopathic thrombocytopenic purpura in pregnancy: A review of literature. J Bras Patol Med Lab. 2021;57:1–8.  
24. Provan D, Stasi R, Newland AC, Blanchette VS, Bolton-Maggs P, Bussel JB, et al. International consensus report on the investigation and management of primary immune thrombocytopenia. Blood. 2010 Jan 14;115(2):168–86.  
25. Bussel JB, Hou M, Cines DB. Management of Primary Immune Thrombocytopenia in Pregnancy. Longo DL, editor. New England Journal of Medicine. 2023 Aug 10;389(6):540–8.  
26. Kühne T, Buchanan GR, Zimmerman S, Michaels LA, Kohan R, Berchtold W, et al. A prospective comparative study of 2540 infants and children with newly diagnosed idiopathic thrombocytopenic purpura (ITP) from the intercontinental childhood ITP study group. J Pediatr. 2003 Nov;143(5):605–8.  
27. Kühne T, Imbach P, Bolton-Maggs PH, Berchtold W, Blanchette V, Buchanan GR. Newly diagnosed idiopathic thrombocytopenic purpura in childhood: an observational study. The Lancet. 2001 Dec;358(9299):2122–5.  
28. Arnold DM. Bleeding complications in immune thrombocytopenia. Hematology (United States). 2015;2015(1):237–42.  
29. Portielje JEA, Westendorp RGJ, Kluin-Nelemans HC, Brand A. Morbidity and mortality in adults with idiopathic thrombocytopenic purpura. Blood. 2001;97(9):2549–54.  
30. Neunert C, Terrell DR, Arnold DM, Buchanan G, Cines DB, Cooper N, et al. American Society of Hematology 2019 guidelines for immune thrombocytopenia. Blood Adv. 2019;3(23):3829–66.  
31. Vrbensky JR, Moore JE, Arnold DM, Smith JW, Kelton JG, Nazy I. The sensitivity and specificity of platelet autoantibody testing in immune thrombocytopenia: a systematic review and meta‐analysis of a diagnostic test. Journal of Thrombosis and Haemostasis. 2019 May;17(5):787–94.  
32. Neunert C, Terrell DR, Arnold DM, Buchanan G, Cines DB, Cooper N, et al. American Society of Hematology 2019 guidelines for immune thrombocytopenia. Blood Adv. 2019;3(23):3829–66.  
33. Neunert C, Lim W, Crowther M, Cohen A, Solberg L, Crowther MA, et al. The American Society of Hematology 2011 evidence-based practice guideline for immune thrombocytopenia. Blood. 2011 Apr 21;117(16):4190–207.  
34. Guidelines for the investigation and management of idiopathic thrombocytopenic purpura in adults, children and in pregnancy. Br J Haematol. 2003 Feb 14;120(4):574–96.  
35. Mahabir VK, Ross C, Popovic S, Sur ML, Bourgeois J, Lim W, et al. A blinded study of bone marrow examinations in patients with primary immune thrombocytopenia. Eur J Haematol. 2013 Feb;90(2):121–6.  
36. Ladenson PW, Levin AA, Ridgway EC, Daniels GH. Complications of surgery in hypothyroid patients. Am J Med. 1984 Aug;77(2):261–6.  
37. McMillan R. The role of antiplatelet autoantibody assays in the diagnosis of immune thrombocytopenic purpura. Curr Hematol Rep. 2005 Mar;4(2):160–5.  
38. Care A, Pavord S, Knight M, Alfirevic Z. Severe primary autoimmune thrombocytopenia in pregnancy: a national cohort study. BJOG. 2018 Apr 10;125(5):604–12.  
39. Comont T, Moulis G, Delavigne K, Cougoul P, Parant O, Guyard‐Boileau B, et al. Re: Severe Primary Autoimmune Thrombocytopenia ( <scp>ITP</scp> ) in Pregnancy: a national cohort study Primary immune thrombocytopenia management during pregnancy. A French study. BJOG. 2018 Apr 20;125(5):629–30.  
40. Rottenstreich A, Israeli N, Roth B, Elchalal U, Amsalem H, Da’as N, et al. Risk factors associated with neonatal thrombocytopenia in pregnant women with immune thrombocytopenic purpura. The Journal of Maternal-Fetal & Neonatal Medicine. 2020 May 2;33(9):1572–8.  
41. Reese JA, Peck JD, Deschamps DR, McIntosh JJ, Knudtson EJ, Terrell DR, et al. Platelet Counts during Pregnancy. New England Journal of Medicine. 2018 Jul 5;379(1):32–43.  
42. Townsley DM. Hematologic Complications of Pregnancy. Semin Hematol. 2013 Jul;50(3):222–31.  
28  
43. FEBRASGO. Pré-eclâmpsia. Série, orientações e recomendações. 2017.  
44. Ministério da Saúde/Secretaria de Atenção Primária à Saúde. Departamento de Ações Programáticas. Manual de Gestação de Alto Risco. Febrasgo. 2022. 1–694 p.  
45. Rodeghiero F, Stasi R, Gernsheimer T, Michel M, Provan D, Arnold DM, et al. Standardization of terminology, definitions and outcome criteria in immune thrombocytopenic purpura of adults and children: Report from an international working group. Blood. 2009;113(11):2386–93.  
46. van Dijk WEM, Punt MC, van Galen KPM, van Leeuwen J, Lely AT, Schutgens REG. Menstrual problems in chronic immune thrombocytopenia: A monthly challenge ‐ a cohort study and review. Br J Haematol. 2022 Aug 3;198(4):753– 64.  
47. Panzer S, Zeitelhuber U, Hach V, Brackmann HH, Niessner H, Mueller‐Eckhardt C. Immune thrombocytopenia in severe hemophilia A treated with high‐dose intravenous immunoglobulin. Transfusion (Paris). 1986 Jan 2;26(1):69–72.  
48. Swan D, Newland A, Rodeghiero F, Thachil J. Thrombosis in immune thrombocytopenia — current status and future perspectives. Br J Haematol. 2021 Sep 6;194(5):822–34.  
49. Beck CE, Nathan PC, Parkin PC, Blanchette VS, Macarthur C. Corticosteroids Versus Intravenous Immune Globulin for the Treatment of Acute Immune Thrombocytopenic Purpura in Children: A Systematic Review and Meta-Analysis of Randomized Controlled Trials. J Pediatr. 2005 Oct;147(4):521–7.  
50. Puavilai T, Thadanipon K, Rattanasiri S, Ingsathit A, McEvoy M, Attia J, et al. Treatment efficacy for adult persistent immune thrombocytopenia: a systematic review and network meta‐analysis. Br J Haematol. 2020 Feb 18;188(3):450–9.  
51. Treutiger I, Rajantie J, Zeller B, Henter JI, Elinder G, Rosthoj S. Does treatment of newly diagnosed idiopathic thrombocytopenic purpura reduce morbidity? Arch Dis Child. 2007 Apr 11;92(8):704–7.  
52. Grace RF, Lambert MP. An update on pediatric ITP: differentiating primary ITP, IPD, and PID. Blood. 2022 Aug 11;140(6):542–55.  
53. Cohen YC, Djulbegovic B, Shamai-Lubovitz O, Mozes B. The bleeding risk and natural history of idiopathic thrombocytopenic purpura in patients with persistent low platelet counts. Arch Intern Med. 2000 Jun 12;160(11):1630– 8.  
54. Portielje JEA, Westendorp RGJ, Kluin-Nelemans HC, Brand A. Morbidity and mortality in adults with idiopathic thrombocytopenic purpura. Blood. 2001 May 1;97(9):2549–54.  
55. Mizutani H, Furubayashi T, Imai Y, Kashiwagi H, Honda S, Take H, et al. Mechanisms of corticosteroid action in immune thrombocytopenic purpura (ITP): experimental studies using ITP-prone mice, (NZW x BXSB) F1. Blood. 1992 Feb 15;79(4):942–7.  
56. Caplan A, Fett N, Rosenbach M, Werth VP, Micheletti RG. Prevention and management of glucocorticoid-induced side effects: A comprehensive review. J Am Acad Dermatol. 2017 Jan;76(1):1–9.  
57. Arnold DM. Positioning new treatments in the management of immune thrombocytopenia. Pediatr Blood Cancer. 2013 Jan 25;60(S1).  
58. Mithoowani S, Gregory-Miller K, Goy J, Miller MC, Wang G, Noroozi N, et al. High-dose dexamethasone compared with prednisone for previously untreated primary immune thrombocytopenia: a systematic review and meta-analysis. Lancet Haematol. 2016 Oct;3(10):e489–96.  
59. Ozelo MC, Colella MP, de Paula EV, do Nascimento ACKV, Villaça PR, Bernardo WM. Guideline on immune thrombocytopenia in adults: Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular. Project guidelines: Associação Médica Brasileira – 2018. Hematol Transfus Cell Ther. 2018 Jan;40(1):50–74.  
29  
60. Choi PY, Merriman E, Bennett A, Enjeti AK, Tan CW, Goncalves I, et al. Consensus guidelines for the management of adult immune thrombocytopenia in Australia and New Zealand. Medical Journal of Australia. 2022 Jan 17;216(1):43– 52.  
61. Jin F, Balthasar JP. Mechanisms of Intravenous Immunoglobulin Action in Immune Thrombocytopenic Purpura. Hum Immunol. 2005 Apr;66(4):403–10.  
62. Mishra K, Pramanik S, Sandal R, Jandial A, Sahu KK, Singh K, et al. Safety and efficacy of azathioprine in immune thrombocytopenia. Am J Blood Res. 2021;11(3):217–26.  
63. Cuker A, Neunert CE. How I treat refractory immune thrombocytopenia. Blood. 2016 Sep 22;128(12):1547–54.  
64. ANVISA. Bula do rituximabe Solução para diluição para infusão 100 mg/10mL e 500mg/50mL - Bio-Manguinhos Rituximabe (rituximabe). 2024.  
65. Lucchini E, Zaja F, Bussel J. Rituximab in the treatment of immune thrombocytopenia: what is the role of this agent in 2019? Haematologica. 2019 Jun;104(6):1124–35.  
66. Ozelo MC, Colella MP, de Paula EV, do Nascimento ACKV, Villaça PR, Bernardo WM. Guideline on immune thrombocytopenia in adults: Associação Brasileira de Hematologia, Hemoterapia e Terapia Celular. Project guidelines: Associação Médica Brasileira – 2018. Hematol Transfus Cell Ther. 2018 Jan;40(1):50–74.  
67. Choi PY, Merriman E, Bennett A, Enjeti AK, Tan CW, Goncalves I, et al. Consensus guidelines for the management of adult immune thrombocytopenia in Australia and New Zealand. Medical Journal of Australia. 2022 Jan 17;216(1):43– 52.  
68. Kim TO, Despotovic J, Lambert MP. Eltrombopag for use in children with immune thrombocytopenia. Blood Adv. 2018 Feb 27;2(4):454–61.  
69. Sirotich E, Guyatt G, Gabe C, Ye Z, Beck CE, Breakey V, et al. Definition of a critical bleed in patients with immune thrombocytopenia: Communication from the ISTH SSC Subcommittee on Platelet Immunology. Journal of Thrombosis and Haemostasis. 2021 Aug;19(8):2082–8.  
70. De Mattia D, Del Vecchio GC, Russo G, De Santis A, Ramenghi U, Notarangelo L, et al. Management of Chronic Childhood Immune Thrombocytopenic Purpura: AIEOP Consensus Guidelines. Acta Haematol. 2010;123(2):96–109.  
71. Santana LM, Neves T, Fenilli AC, Borba LG De, Kirst D, Fetter F, et al. Trombocitopenia autoimune em crianças : revisão das recomendações do último consenso. Boletim Científico de Pediatria. 2013;02(3):77–82.  
72. Duru F, Fisgin T, Yarali N, Kara A. CLINICAL COURSE OF CHILDREN WITH IMMUNE THROMBOCYTOPENIC PURPURA TREATED WITH INTRAVENOUS IMMUNOGLOBULIN G OR MEGADOSE METHYLPREDNISOLONE OR OBSERVED WITHOUT THERAPY. Pediatr Hematol Oncol. 2002 Jan 9;19(4):219– 25.  
73. Carcao M, Silva M, David M, Klaassen RJ, Steele M, Price V, et al. IVMP+IVIG raises platelet counts faster than IVIG alone: results of a randomized, blinded trial in childhood ITP. Blood Adv. 2020 Apr 14;4(7):1492–500.  
74. Goudouris ES, Silva AM do R, Ouricuri AL, Grumach AS, Condino-Neto A, Costa-Carvalho BT, et al. II Brazilian Consensus on the use of human immunoglobulin in patients with primary immunodeficiencies. Einstein (São Paulo). 2017 Mar;15(1):1–16.  
75. Chaturvedi S, Arnold DM, McCrae KR. Splenectomy for immune thrombocytopenia: down but not out. Blood. 2018 Mar 15;131(11):1172–82.  
76. Loustau V, Debouverie O, Canoui‐Poitrine F, Baili L, Khellaf M, Touboul C, et al. Effect of pregnancy on the course of immune thrombocytopenia: a retrospective study of 118 pregnancies in 82 women. Br J Haematol. 2014 Sep 24;166(6):929–35.  
30  
77. Li J, Gao YH, Su J, Zhang L, Sun Y, Li ZY. Diagnostic Ideas and Management Strategies for Thrombocytopenia of Unknown Causes in Pregnancy. Front Surg. 2022 Apr 6;9.  
78. Fujimura K, Harada Y, Fujimoto T, Kuramoto A, Ikeda Y, Akatsuka J ichi, et al. Nationwide Study of Idiopathic Thrombocytopenic Purpura in Pregnant Women and the Clinical Influence on Neonates. Int J Hematol. 2002 May 1;75(4):426–33.  
79. Webert KE, Mittal R, Sigouin C, Heddle NM, Kelton JG. A retrospective 11-year analysis of obstetric patients with idiopathic thrombocytopenic purpura. Blood. 2003 Dec 15;102(13):4306–11.  
80. Bauer ME, Arendt K, Beilin Y, Gernsheimer T, Perez Botero J, James AH, et al. The Society for Obstetric Anesthesia and Perinatology Interdisciplinary Consensus Statement on Neuraxial Procedures in Obstetric Patients With Thrombocytopenia. Anesth Analg. 2021 Jun 4;132(6):1531–44.  
81. Murphy VE, Fittock RJ, Zarzycki PK, Delahunty MM, Smith R, Clifton VL. Metabolism of Synthetic Steroids by the Human Placenta. Placenta. 2007 Jan;28(1):39–46.  
82. Calderwood CJ. Thromboembolism and thrombophilia in pregnancy. Curr Obstet Gynaecol. 2006 Dec;16(6):321–6.  
83. Chapin J, Lee CS, Zhang H, Zehnder JL, Bussel JB. Gender and duration of disease differentiate responses to rituximab– dexamethasone therapy in adults with immune thrombocytopenia. Am J Hematol. 2016 Sep 20;91(9):907–11.  
84. Novartis Biociências S.A. Bula do Medicamento Eltrombopague. 2017.  
85. Eslick R, McLintock C. Managing ITP and thrombocytopenia in pregnancy. Platelets. 2020 Apr 2;31(3):300–6.  
86. Mazzucconi MG, Petrelli V, Gandolfo GM, Carapella E, Chistolini A, Puorger CC, et al. Autoimmune Thrombocytopenic Purpura in Pregnancy: Maternal Risk Factors Predictive of Neonatal Thrombocytopenia. Autoimmunity. 1993 Jan 7;16(3):209–14.  
87. Wegnelius G, Bremme K, Lindqvist PG. Efficacy of treatment immune thrombocytopenic purpura in pregnancy with corticosteroids and intravenous immunoglobulin. Blood Coagulation & Fibrinolysis. 2018 Mar;29(2):141–7.  
88. Kashyap R, Garg A, Pradhan M. Maternal and Fetal Outcomes of Pregnancy in Patients with Immune Thrombocytopenia. The Journal of Obstetrics and Gynecology of India. 2021 Apr 18;71(2):124–30.  
89. Khaspekova SG, Shustova ON, Golubeva N V., Naimushin YA, Larina LE, Mazurov A V. Circulating antiplatelet antibodies in pregnant women with immune thrombocytopenic purpura as predictors of thrombocytopenia in the newborns. Platelets. 2019 Nov 17;30(8):1008–12.  
90. Mazzucconi MG, Petrelli V, Gandolfo GM, Carapella E, Chistolini A, Puorger CC, et al. Autoimmune Thrombocytopenic Purpura in Pregnancy: Maternal Risk Factors Predictive of Neonatal Thrombocytopenia. Autoimmunity. 1993 Jan 7;16(3):209–14.  
91. Yamada H, Fujimoto S. Perinatal management of idiopathic thrombocytopenic purpura in pregnancy: risk factors for passive immune thrombocytopenia. Ann Hematol. 1994 Jan;68(1):39–42.  
92. Mazzucconi MG, Petrelli V, Gandolfo GM, Carapella E, Chistolini A, Puorger CC, et al. Autoimmune Thrombocytopenic Purpura in Pregnancy: Maternal Risk Factors Predictive of Neonatal Thrombocytopenia. Autoimmunity. 1993 Jan 7;16(3):209–14.  
93. VAlat ASy, CAUlier MThérè, Devos P, Rugeri L, Wibaut Béné, Vaast Pasca, et al. Relationships between severe neonatal thrombocytopenia and maternal characteristics in pregnancies associated with autoimmune thrombocytopenia. Br J Haematol. 1998 Nov 4;103(2):397–401.  
94. Khaspekova SG, Shustova ON, Golubeva N V., Naimushin YA, Larina LE, Mazurov A V. Circulating antiplatelet antibodies in pregnant women with immune thrombocytopenic purpura as predictors of thrombocytopenia in the newborns. Platelets. 2019 Nov 17;30(8):1008–12.  
31  
95. Loustau V, Debouverie O, Canoui‐Poitrine F, Baili L, Khellaf M, Touboul C, et al. Effect of pregnancy on the course of immune thrombocytopenia: a retrospective study of 118 pregnancies in 82 women. Br J Haematol. 2014 Sep 24;166(6):929–35.  
96. Payne SD, Resnik R, Moore TR, Hedriana HL, Kelly TF. Maternal characteristics and risk of severe neonatal thrombocytopenia and intracranial hemorrhage in pregnancies complicated by autoimmune thrombocytopenia. Am J Obstet Gynecol. 1997 Jul;177(1):149–55.  
32

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **11      REFERÊNCIAS** -->
Eu, ______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso do(s) medicamento(s), , **azatioprina, ciclofosfamida, danazol, dexametasona, eltrombopague, imunoglobulina humana, metilprednisolona, prednisolona, prednisona, rituximabe, romiplostim e vincristina** , indicados para o tratamento da Trombocitopenia Imune Primária (PTI).  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a) _______________  
________________________________________________________________________________________________ (nome  
do(a) médico(a) que prescreve).  
Assim declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Cessação dos sangramentos ativos.  
- Prevenção da ocorrência de sangramentos clinicamente significativos.  
- Aumento da contagem total de plaquetas.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos do  
uso destes medicamentos:  
- **Prednisona** : medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram anormalidades e, embora estudos em humanos não tenham sido feitos, o medicamento deve ser prescrito com cautela).  
- **Dexametasona, metilprednisolona, eltrombopague, romiplostim, rituximabe e imunoglobulina humana** : medicamentos classificados na gestação como fator de risco C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas o benefício potencial pode ser maior que os riscos).  
- **Azatioprina e vincristina** : medicamentos classificados na gestação como fator de risco D (há evidências de riscos ao feto, mas um benefício potencial pode ser maior que os riscos).  
- **Ciclofosfamida e danazol** : medicamentos classificados na gestação como fator de risco X (seu uso é contraindicado para gestantes ou mulheres que planejam engravidar).  
- **Eventos adversos da prednisona, dexametasona e metilprednisolona** : retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito.  
- **Eventos adversos da imunoglobulina humana** : dor de cabeça, calafrios, febre, reações no local de aplicação da injeção (dor, coceira e vermelhidão); problemas renais (aumento de creatinina e ureia no sangue, seguido de oligúrio e anúria, insuficiência renal aguda, necrose tubular aguda, nefropatia tubular proximal, nefrose osmótica).  
- **Eventos adversos da azatioprina** : diminuição das células brancas, vermelhas e plaquetas do sangue, náusea, vômitos, diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de pele, queda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia, falta de ar, pressão baixa.  
- **Eventos adversos da ciclofosfamida** : náusea, vômitos, queda de cabelo, risco aumentado de infecções, anemia, toxicidade para medula óssea, infecções na bexiga, risco de sangramento (redução do número de plaquetas).  
33  
- **Eventos adversos do eltrombopague** : cefaleia, anemia, diminuição do apetite, insônia, tosse, náusea, diarreia, perda  
- de cabelo, coceira, dor no corpo, febre, cansaço, estado gripal, fraqueza, calafrios e edema periférico. Reações graves observadas foram toxicidade para o fígado e eventos tromboembólicos.  
- **Eventos adversos do danazol** : distúrbios da menstruação, ganho de peso, calorões, inchaço, escurecimento da urina,  
- cansaço, sono, espinhas, aumento da oleosidade do cabelo e da pele, náusea, vômitos, alteração da voz.  
- **Eventos adversos da vincristina** : perda de cabelo, distúrbios neuromusculares (diminuição sensorial, formigamentos, dores neuríticas, dificuldades motoras), prisão de ventre, dor abdominal, cólicas, vômitos, diarreia, retenção urinária ou aumento do volume urinário, perda de peso, febre, ulceração oral, dor de cabeça, alteração no sangue (plaquetas e leucócitos diminuídos), excreção aumentada de sódio (com diminuição do sódio no sangue).  
- Medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos.  
- O risco de ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que esse(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendo-me a devolvê-  
lo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei a ser assistida,  
inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- ( ) Sim ( ) Não  
O meu tratamento constará do seguinte medicamento:  
- ( ) azatioprina ( ) metilprednisolona  
- ( ) ciclofosfamida  
- ( ) danazol  
- ( ) dexametasona  
- ( ) eltrombopague  
- ( ) prednisona/prednisolona  
- ( ) rituximabe  
- ( ) romiplostim  
- ( ) vincristina  
- ( ) imunoglobulina humana  
Local:                                                             Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal:  
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|---|---|---|
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico<br>Data:____________________|||  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
34  
Nota 2: A administração endovenosa de metilprednisolona é compatível com os procedimentos 03.03.02.001-6 - Pulsoterapia I (por aplicação).  
Nota 3: A administração intravenosa de vincristina é compatível procedimento 03.03.02.006-7 – Tratamento de defeitos da coagulação, púrpura e outras afecções hemorrágicas, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS, que é compatível com o código D69.3 – Púrpura Trombocitopênica Idiopática, da CID-10.  
Nota 4: A administração intravenosa de imunoglobulina é compatível com o procedimento 06.03.03.003-3 Imunoglobulina humana 1,0 G injetavel (por frasco) da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
Nota 5: A prescrição de biológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
35  
APÊNDICE 1 – METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **11      REFERÊNCIAS** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas da Trombocitopenia Imune Primária (PTI), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (DGITS/SECTICS/MS). Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia à reunião de escopo.  
A revisão do PCDT da Púrpura Trombocitopênica Idiopática (PTI) foi iniciada com as reuniões virtuais de pré-escopo, escopo e priorização de perguntas de pesquisa realizadas de julho a agosto de 2023. As reuniões tiveram a participação de até 18 participantes entre membros do Grupo Elaborador (n=10) e do Comitê Gestor (n=8). Durante essas reuniões, discutiu-se a alteração do título para Trombocitopenia Imune Primária.  
A dinâmica da reunião foi conduzida com base no PCDT publicado por meio da Portaria Conjunta SAES-SCTIE/MS nº 9, de 31 de julho de 2019, e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
A relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo UATS do Hospital Alemão Oswaldo Cruz.  
Os membros do Grupo Elaborador e os participantes das reuniões de elaboração do referido PCDT estão descritos no  
**Quadro A** .  
**Quadro A.** Membros do Grupo Elaborador e participantes das reuniões de elaboração.  
|**Participante**|
|---|
|Aerica de Figueiredo Pereira|
|Ana Carolina Digues da Costa|
|Ana Clara Kneese Virgílio do Nascimento *|
|Brígida Dias Fernandes|  
36  
|**Participante**|
|---|
|Camila Araújo da Silva|
|Clarisse Lopes de Castro Lobo*|
|Eduardo Freire de Oliveira|
|Franciele Cordeiro Gabriel|
|Francine Doty Campoy*|
|José Maria Soares Júnior*|
|Juliana Yukari K. Viscondi**|
|Layssa Andrade Oliveira**|
|Letícia de Araújo Vitor**|
|Ludmila Peres Gargano**|
|Marta da Cunha Lobo Souto Maior|
|Nicole Freitas de Mello|
|Paula Ribeiro Villaça*|
|Paula Stoll|
|Rosa Camila Lucchetta**|
|Rosângela Maria Gomes|
|Suyanne Camille Caldeira Monteiro|
|Tassiane Cristine Santos de Paulo**|  
*Membros votantes na reunião de escopo e/ou recomendação;  
**Metodologistas.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro B** ).  
**Quadro B** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeirament|e algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|  
37  
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|---|---|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
A proposta de atualização do PCDT da Trombocitopenia Imune Primária foi apresentada na 124ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de abril de 2025. A reunião teve a presença de representantes da SECTICS, Secretaria de Vigilância em Saúde e Ambiente (SVSA), Secretaria de Saúde Indígena (SESAI), Secretaria de Atenção Primária a Saúde (SAPS), Departamento de Ciência e Tecnologia (DECIT) e Secretaria de Atenção Especializada (SAES). <mark>O PCDT foi aprovado para avaliação da Conitec e a proposta será apresentada aos membros do Comitê de PCDT da C</mark> onitec em sua 141ª Reunião Ordinária.  
**4         Consulta pública**  
38  
A Consulta Pública nº 52/2025, do Protocolo Clínico e Diretrizes Terapêuticas da Trombocitopenia Imune Primária, foi realizada entre os dias 24/06/2025 e 14/07/2025. Foram recebidas 236 contribuições. O conteúdo integral das contribuições se encontra disponível na página da CONITEC em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2025/contribuicao-da-cp-52_2025_protocolo_clinico_e.pdf.</u>

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO ( **Figura A** ).  
**Figura A.** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
PP *Populacdo ou condic¢do clinica<br>*Intervengdo, no caso de estudos experimentais<br>*Fator de exposic¢do, em caso de estudos observacionais<br>*Teste indice, nos casos de estudos de acurdcia diagndstica<br>Controle, de acordo com tratamento/niveis de exposicdo do fator/exames<br>disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Durante a reunião de escopo deste PCDT uma questão de pesquisa foi definida e que foi, posteriormente, separada em duas populações **:**  
Para cada uma das perguntas, as informações sobre a evidência encontram-se nos seus respectivos relatórios de recomendação.  
**QUESTÃO 1: Em adultos com PTI primária refratária, crônica ou dependente de corticosteroide, rituximabe, dapsona e romiplostim são eficazes e seguros, quando comparados aos tratamentos disponíveis para a PTI refratária no SUS?**  
Recomendação: Adotou-se a deliberação da Conitec, de recomendar a **não incorporação** da dapsona para o tratamento de adultos com púrpura trombocitopênica idiopática primária refratária ou dependente de corticosteroide e **incorporar** o rituximabe e o romiplostim para o tratamento de adultos com púrpura trombocitopênica idiopática primária refratária ou dependente de corticosteroide, , conforme Relatório de Recomendação nº 950/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-950-rituximabe-dapsona-eromiplostim.  
A estrutura PICO para esta pergunta foi:  
|**População**|Adultos com PTI refratária<sup>a</sup>crônica ou dependentes de corticosteroide<sup>b</sup>|
|---|---|
|**Intervenção**|Rituximabe|  
39  
||Dapsona|
|---|---|
||Romiplostim|
||Eltrombopague|
||Azatioprina|
|**Comparador**|Ciclofosfamida|
||Vincristina|
||Danazol|
||**Primário**|
||Resposta global: pacientes atingindo CP ≥ 50.000 mm³ ou duplicação da contagem|
||de plaquetas da linha de base|
|**Desfechos**|Incidência de sangramento clinicamente significativo<br>**Secundário**|
||Qualidade de vida relacionada à saúde|
||Eventos adversos graves (grau ≥ 3)|  
Notas: a – PTI refratária ao tratamento de primeira linha com corticosteroides e/ou IVIg, independentes se doença persistente ou crônica; b – Considerou-se que a dependência de corticosteroide por longo período também caracteriza necessidade de trocar o tratamento. c – Foram considerados estudos observacionais comparativos para intervenções as quais não foram identificadas evidências de ensaios clínicos randomizados. Legenda: CP: contagem de plaquetas; PTI: Púrpura Trombocitopênica Idiopática.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 950/2024 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
Recomendação: Adotou-se a deliberação da Conitec, de recomendar a **não incorporação** da dapsona para o tratamento de crianças e adolescentes com púrpura trombocitopênica idiopática primária refratária, crônica ou dependente de corticosteroide e **incorporar** o rituximabe e o romiplostim para o tratamento de crianças e adolescentes com púrpura trombocitopênica idiopática primária refratária, crônica ou dependente de corticosteroide, conforme Relatório de Recomendação nº 969/2025, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de-recomendacao-no-969-rituximabe-e-o-romiplostim.</u>  
A estrutura PICO para esta pergunta foi:  
|**População**|Crianças e adolescentes com PTI refratária<sup>a</sup>, crônica ou dependentes de corticosteroide<sup>b</sup>|
|---|---|
||Rituximabe|
|**Intervenção**|Dapsona|
||Romiplostim|
||Eltrombopague|
|**Comparador**|Azatioprina<br>Ciclofosfamida|
||Vincristina|
|**Desfechos**|**Primário**|  
40  
|Resposta global: pacientes atingindo CP ≥ 50.000 mm³ ou duplicação da contagem|
|---|
|de plaquetas da linha de base|
|Incidência de sangramento clinicamente significativo|
|**Secundário**|
|Qualidade de vida relacionada à saúde|
|Eventos adversos graves (grau ≥ 3)|  
Notas: a – PTI refratária ao tratamento de primeira linha com corticosteroides e/ou IVIg, independentes se doença persistente ou crônica; b – Considerou-se que a dependência de corticosteroide por longo período também caracteriza necessidade de trocar o tratamento. c – Foram considerados estudos observacionais comparativos para intervenções as quais não foram identificadas evidências de ensaios clínicos randomizados. Legenda: CP: contagem de plaquetas; PTI: Púrpura Trombocitopênica Idiopática.

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 969/2025 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
41

---

<!-- METADADOS: doenca: Trombocitopenia Imune Primária | secao: **2        Equipe de elaboração e partes interessadas** -->
|**Número do**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Relatório da**<br>**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||Atualização do<br>documento,|Rituximabe para tratamento da púrpura<br>trombocitopênica idiopática refratária,<br>crônica ou dependente de corticosteroide em<br>**crianças e adolescentes**<br>[Relatório de Recomendação n° 969/2025;<br>Portaria SECTICS/MS nº 21/2025]<br>Romiplostim para tratamento da púrpura<br>trombocitopênica idiopática refratária,<br>crônica ou dependente de corticosteroide em<br>**crianças e adolescentes**. [Relatório de<br>Recomendação n° 969/2025; Portaria|Dapsona para tratamento da<br>púrpura trombocitopênica<br>idiopática refratária, crônica ou<br>dependente de corticosteroide<br>em crianças e adolescentes.<br>[Relatório de Recomendação n°<br>969/2025; Portaria|
|Relatório de<br>Recomendação nº<br>1049/2025|alteração no<br>nome do<br>Protocolo e<br>incorporação<br>de tecnologias|SECTICS/MS nº 21/2025]<br>Rituximabe para o tratamento de**indivíduos**<br>**adultos**com púrpura trombocitopênica<br>idiopática primária refratária ou dependente<br>de corticosteroide. [Relatório de<br>Recomendação n° 950/2024; Portaria<br>SECTICS/MS nº 63/2024]<br>Romiplostim para o tratamento de**indivíduos**<br>**adultos**com púrpura trombocitopênica<br>idiopática primária refratária ou dependente<br>de corticosteroide. [Relatório de<br>Recomendação n° 950/2024; Portaria<br>SECTICS/MS nº 63/2024]|SECTICS/MS nº 21/2025]<br>Dapsona para o tratamento de<br>indivíduos adultos com púrpura<br>trombocitopênica idiopática<br>primária refratária ou<br>dependente de corticosteroide.<br>Relatório de Recomendação n°<br>950/2024; Portaria<br>SECTICS/MS nº 63/2024]|
|Portaria Conjunta<br>SAES-SCTIE/MS nº||Eltrombopague olamina no tratamento da|Romiplostim para púrpura<br>trombocitopênica idiopática|
|9, de 31/07/2019;|Atualização do|púrpura trombocitopênica idiopática (PTI)|(PTI) crônica e refratária em alto|
|Relatório de|Protocolo|[Relatório de Recomendação nº 404/2018;|risco de sangramento [Relatório|
|Recomendação nº<br>452/2019||Portaria SCTIE/MS nº 72/2018]|de Recomendação nº 405/2018;<br>Portaria SCTIE/MS nº 69/2018]|  
42  
|**Número do**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Relatório da**||||
|**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**|**Principais**<br>**alterações**|**Incorporação ou alteração do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|**Publicação**||||
|Portaria SAS/MS nº<br>1.316, de 22 de<br>novembro de 2013|Atualização do<br>Protocolo|||
|Portaria SAS/MS nº<br>715,<br>de<br>17<br>de<br>dezembro de 2010|Primeira versão<br>do documento|||  
43

---

