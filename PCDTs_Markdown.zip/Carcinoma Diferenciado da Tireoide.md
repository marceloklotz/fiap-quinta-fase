<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 7 DE 03 DE JANEIRO DE 2014  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Carcinoma Diferenciado da Tireoide.  
A Secretária de Atenção à Saúde - Substituta, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o carcinoma diferenciado da tireoide no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública n<sup><u>o</u></sup> 12/SAS/MS, de 4 de junho de  
2013; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC) e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º  Fica aprovado, na forma do Anexo a esta Portaria, o Protocolo Clínico e Diretrizes Terapêuticas – Carcinoma Diferenciado da Tireoide.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do carcinoma diferenciado da tireoide, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou do seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao tratamento preconizado para caso de carcinoma diferenciado da tireoide.  
Art. 3º  Os gestores estaduais e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria nº 466/SAS/MS, de 20 de agosto de 2007, publicada no Diário Oficial da União nº 162, de 22 de agosto de 2007, seção 1, página 120.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: CLEUSA RODRIGUES DA SILVEIRA BERNARDO -->
2  
ANEXO

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 1.METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Para a elaboração deste Protocolo foram realizadas buscas, em 08/02/2013, nas bases de dados Medline/Pubmed, Embase e sistema Cochrane, sem restrição de data de publicação.  
Na base Medline/Pubmed foram utilizados os unitermos thyroid cancer, radioiodine therapy in thyroid cancer, EBRT in thyroid cancer, ultrasound in thyroid nodule. A busca foi limitada a humanos e artigos na língua inglesa. Não houve restrição de data. Esta busca resultou em 350 artigos que foram revisados.  
Os mesmos unitermos foram utilizados para pesquisa na base de dados Embase e não foram encontrados artigos adicionais com esta estratégia. Foi também acessada a base de dados da Crochane, na qual não foi encontrada nenhuma revisão sistemática.  
Foram excluídos estudos similares, com delineamento inadequado do desfecho analisado ou com tempo de seguimento curto e relatos de casos.  
Além disso, foram consultados livros-texto de endocrinologia, diversos artigos publicados em revistas indexadas consensos e _guidelines_ nacionais e internacionais.  
No total, 102 referências foram utilizadas e acrescidas duas publicações, uma sobre a incidência do câncer no Brasil e a outra, sobre a classificação de tumores malignos, todas devidamente referidas neste Protocolo.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 2. INTRODUÇÃO -->
O Carcinoma Diferenciado da Tireoide (CDT) é a neoplasia maligna endócrina de maior prevalência no mundo (1). Entende-se como CDT, o tumor maligno da tireoide de origem epitelial, sendo o carcinoma papilífero o principal representante desta categoria. Além do carcinoma papilífero, incluem-se dentro do grupo de CDT o carcinoma folicular e o carcinoma de células de Hürthle.  
Estudos epidemiológicos recentes mostram um aumento progressivo na incidência de CDT em diferentes regiões do mundo ao longo das últimas décadas (2,3,4). Este aumento é observado tanto em homens quanto em mulheres e envolve casos de diferentes tamanhos de tumores. Segundo Brito e cols., a incidência de casos no Brasil é de 1,16 e 5,27 por 100.000 habitantes na população masculina e feminina, respectivamente (5). Estimativa recente da incidência do câncer, feita pelo INCA, prevê um total de 10.590 novos casos para 2012, também válido para 2013, representando o câncer da tireoide, excluindo-se o câncer não melanótico de pele, a terceira à sexta neoplasia maligna mais frequente entre a população feminina brasileira, dependendo da região geográfica considerada (6).  
Segundo consensos de especialistas da Associação Americana de Tireoide (ATA), da Associação Europeia de Tireoide (ETA) e do Departamento de Tireoide da Sociedade Brasileira de Endocrinologia e Metabologia, o tratamento inicial do CDT consiste de ressecção da tireoide (tireoidectomia), seguida de tratamento complementar com iodo radioativo (radioiodoterapia - RIT) em casos selecionados (7,8,9).  
3  
A radioterapia externa e a quimioterapia têm papel restrito no tratamento do CDT e serão comentadas especificamente.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
3.CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- C73 – Neoplasia maligna da glândula tireoide

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 4.DIAGNÓSTICO -->
O câncer da tireoide apresenta-se comumente como nódulo detectado pela palpação ou detectado pela ultrassonografia cervical. Embora os nódulos tireoidianos sejam comuns, com prevalência entre 4% a 50%, dependendo dos procedimentos diagnósticos utilizados e da idade das pessoas, o câncer da tireoide é raro (10). Os nódulos impalpáveis ao exame físico e diagnosticados por meio da ultrassonografia ou outro método de imagem são denominados de “incidentalomas”. Os nódulos impalpáveis têm a mesma chance de malignidade do que nódulos palpáveis do mesmo tamanho (11). Em geral, somente nódulos com 1 cm ou mais de diâmetro devem ser investigados, pois têm maior potencial de albergar uma neoplasia maligna. No entanto, indivíduos com nódulos de dimensões inferiores com características suspeitas à ultrassonografia, tais como, a presença de linfonodomegalia cervical, história de irradiação da cabeça e pescoço ou história de câncer em parentes de primeiro grau devem ser submetidos à propedêutica (7,12). É fundamental um exame físico cuidadoso com palpação da região cervical, caracterização do nódulo quanto à consistência, fixação a outras estruturas cervicais e avaliação da presença de disfonia secundária à paralisia de corda vocal (13,14). O objetivo da avaliação do nódulo tireoidiano é estabelecer o risco de câncer por meio de métodos que sejam acurados, precisos, além de seguros e custo-efetivos (12).  
O paciente com diagnóstico de doença nodular tireoidiana deve ter a dosagem de hormônio tireotrófico (TSH), com o objetivo de avaliar a função tireoidiana. Na presença de níveis inferiores aos valores considerados normais, recomenda-se a realização de captação e cintilografia com radioisótopo para investigar a possibilidade de hiperfunção tireoidiana. A incidência de neoplasia maligna neste tipo de nódulo é rara, não havendo indicação de realização de punção guiada pela ultrassonografia (12).  
Os níveis de TSH têm sido relacionados ao risco de câncer da tireoide em pacientes com doença nodular. Boelaert e cols. (15), em um estudo prospectivo no Reino Unido, no qual foram avaliados 1.500 pacientes, concluíram que o nível de TSH em pacientes com doença nodular tireoidiana, mesmo nos limites da normalidade, constituiu-se em fator preditivo independente da presença de malignidade tireoidiana. O mesmo estudo concluiu que o gênero, idade e tipo de bócio ao diagnóstico são também fatores preditores independentes para neoplasia maligna.  
Inexistem evidências que apoiem a recomendação da dosagem rotineira de tireoglobulina na avaliação pré-operatória dos pacientes com doença nodular tireoidiana. Quanto à calcitonina, embora recomendados por alguns autores, com o objetivo de diagnosticar o câncer medular da tireoide em estágios iniciais, ainda é objeto de debate na literatura no que tange ao custoefetividade (7,9).  
A ultrassonografia é uma técnica disseminada e, na atualidade, o exame de primeira linha para detectar e caracterizar a doença nodular tireoidiana, devendo ser realizada em todos pacientes com  
4  
diagnóstico ou suspeita de doença nodular. Algumas características ultrassonográficas são associadas com malignidade: hipoecogenicidade, microcalcificações, ausência de halo periférico, bordas irregulares, aspecto sólido, fluxo intranodular e a forma (altura maior que a profundidade nos eixos longitudinal e transversal, respectivamente). Com exceção da linfonodomegalia cervical suspeita, nenhum achado à ultrassonografia isolado ou em combinação é suficientemente sensível ou específico na identificação de nódulos malignos. Cada uma destas características isoladamente tem baixo valor preditivo positivo (7,11).  
Na avaliação de um nódulo tireoidiano, os seguintes elementos deverão constar na descrição do laudo ultrassonográfico:  
- volume da glândula, ecogenicidade e vascularidade;  
- número de nódulos e com as seguintes descrições para cada um deles: dimensões, forma, ecogenicidade, presença e quantificação do conteúdo líquido, características das bordas, presença de halo periférico, ocorrência de calcificações e suas características, padrão vascular ao doppler (periférico ou central) e presença e caracterização de linfoadenomegalia(s) (16).  
Moon and cols. demonstraram em estudo retrospectivo que a presença de pelo menos um achado sugestivo de malignidade à ultrassonografia teve sensibilidade de 83,3%, especificidade de 74% e acurácia diagnóstica de 78,0%, sendo que esta última foi dependente do tamanho do nódulo (17).  
Em relação às dimensões dos nódulos, um estudo retrospectivo publicado em 2013, envolvendo 4.955 pacientes e 7.000 nódulos tireoidianos puncionados, analisou a relação entre o tamanho do nódulo à ultrassonografia e o risco de malignidade, por meio dos resultados da citologia e da cirurgia: O tamanho do nódulo relacionou-se com o risco absoluto de malignidade em um modelo não linear para diâmetros até 2,0 cm, o que não foi demonstrado para nódulos com diâmetros maiores. No entanto, a ocorrência dos tipos histológicos raros e do carcinoma folicular aumentou proporcionalmente com as dimensões dos nódulos (diâmetro igual ou maior do que 4,0 cm), sendo que a ocorrência da histologia papilífera prevaleceu nos menores (18).  
Há grande discussão na literatura sobre a relação entre tireoidite de Hashimoto e carcinoma da tireoide, com diferentes prevalências entre estudos populacionais. Esta discordância se deve às diferentes metodologias de avaliação adotadas, pois aquelas que utilizaram a citologia obtida por meio de punção por agulha fina não comprovam esta associação. No entanto, as baseadas nos resultados histológicos das tireoidectomias sugerem uma relação entre as duas condições, provavelmente devido a viés de seleção (19).  
Outra controvérsia relaciona-se à prevalência de malignidade e a conduta nos pacientes com múltiplos nódulos tireoidianos. Frates e cols., por meio de estudo de coorte prospectivo de 1.985 pacientes e 3.483 punções dirigidas pela ultrassonografia de nódulos com diâmetros acima de 10 mm, concluíram que a probabilidade de câncer da tireoide não difere entre pacientes com nódulos únicos daqueles que apresentam nódulos múltiplos. (20) A chance de malignidade foi independente do número de nódulos. Para uma exclusão segura de malignidade em uma glândula com múltiplos nódulos com 10 mm ou mais de diâmetro, os autores não recomendam a punção de um único nódulo. (20) Segundo a orientação da ATA, em seu último guideline, na presença de dois ou mais nódulos com mais de 10 mm devem ser puncionados preferencialmente aqueles que apresentam características ultrassonográficas suspeitas (7).  
A biópsia por agulha fina (PAAF) guiada pela ultrassonografia é um importante meio diagnóstico dos nódulos tireoidianos, sendo um método sensível no diagnóstico diferencial entre lesões malignas e benignas. É o procedimento de escolha na avaliação dos nódulos tireoidianos (7,9). Trata-se de um método efetivo na identificação de pacientes candidatos à cirurgia com  
5  
suspeita de presença de malignidade. A PAAF mostrou-se igualmente factível e com acurácia semelhante independente das dimensões dos nódulos, incluindo a proporção de aspirados não diagnósticos, que não diferiu nos nódulos com diâmetros maiores (18).  
No estudo retrospectivo de Boelaert e cols., a PAAF demonstrou uma sensibilidade de 88% e especificidade de 82% e apenas 1% de resultados falsos negativos no diagnóstico de doença maligna e maior chance de doença maligna no nódulo isolado (15).  
Uma coorte retrospectiva da Clínica Mayo avaliou o valor preditivo da PAAF nos pacientes com citologia suspeita ou indeterminada submetidos à cirurgia, e a conclusão foi que tanto nódulos isolados ou múltiplos estão associados ao aumento do risco de malignidade. Confirmou que a PAAF é uma ferramenta efetiva para definir os candidatos à cirurgia neste grupo de pacientes, com valor preditivo positivo de 76% (21).  
Gharib e cols. em revisão da literatura sobre os resultados da PAAF encontraram uma sensibilidade média de 83%, especificidade de 92%, 5% de falsos positivos e 5% de falsos negativos (22).  
Com o objetivo de padronizar a terminologia dos laudos citológicos das punções da tireoide, tem sido adotado nos EUA desde 2007, e também no Brasil, o denominado Sistema de Bethesda para os laudos de citopatologia da tireoide. Esta medida foi de grande importância, pois facilitou a comunicação entre os citopatologistas, endocrinologistas e outros profissionais da saúde. Além disso, tem permitido pesquisas na área de epidemiologia, patologia, diagnóstico e tratamento das doenças tireoidianas, especialmente as neoplasias. São seis categorias gerais, e para cada uma delas há uma estimativa do risco de malignidade, conforme demonstrado no Quadro 1 (23). Não serão discutidas neste Protocolo as características de cada categoria diagnóstica e as condutas a serem adotadas em cada uma delas. Vale ressaltar, no entanto, que a tireoidectomia total está indicada nos pacientes categorizados como “suspeita de malignidade” e “malignos”, e cirurgias menos extensas, como a lobectomia, são preconizadas para pacientes com exames citológicos classificados na categoria “suspeita de neoplasia folicular”. Nesta categoria, têm sido utilizados marcadores moleculares (BRAF, RAS, RET/PTC e outros) para auxiliar na definição diagnóstica. No Brasil, esta conduta está restrita a alguns centros de pesquisas (7,12).  
Bongiovanni e cols. em meta-análise publicada em 2012 avaliaram o impacto desta nova classificação na conduta frente aos indivíduios com nódulos, a variabilidade das categorias entre as instituições e a variação do percentual de malignidade em cada uma delas. A conclusão foi de que o Sistema Bethesda tem alta sensibilidade e alto valor preditivo negativo, comprovando seu valor na conduta clínica destes pacientes. (24)  
Quadro 1 - Sistema Bethesda: correlação do resultado citopatológico e o risco de malignidade em tireoide.  
||RISCO<br>DE|
|---|---|
|CATEGORIA DIAGNÓSTICA|MALIGNIDADE<br>(%)|
|Não<br>diagnóstica<br>ou<br>insatisfatória|1-4|
|Benigna|0-3|
|Atipia<br>de<br>significado|5-15|
|indeterminado ou lesão||  
6  
|folicular<br>de<br>significado<br>indeterminado||
|---|---|
|Neoplasia<br>folicular<br>ou<br>suspeita<br>de<br>neoplasia|15-30|
|folicular||
|Suspeita de malignidade|60-75|
|Maligna|97-99|  
Modificado de Cibas ES, Ali S Z, 2009. (23)

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: A ULTRASONOGRAFIA COMO MÉTODO DE AVALIAÇÃO -->
O nódulo de tireoide é um achado frequente na população. São clinicamente evidentes em cerca de 4% a 7% das mulheres e 1% dos homens adultos. Grande parte destes nódulos é de natureza benigna, porém malignidade pode ser encontrada em cerca de 10% nos adultos e em até 26% nas crianças. (7,25,26)  
A ultrassonografia é o método de escolha para a avaliação dos nódulos tireoideanos. Possui sensibilidade de quase 100%, sendo superior aos outros métodos de imagem. Apresenta custo relativamente baixo, é de fácil execução, não necessita preparo para o exame e não apresenta riscos para o indivíduo. Permite diferenciar nódulos sólidos, nos quais a incidência de malignidade é maior do que nos nódulos císticos e mistos, nos quais prevalece a benignidade. Quando associado ao uso do _doppler_ , observa-se que determinados padrões de vascularização, como, por exemplo, predomínio vascular na periferia do nódulo, sugerem benignidade. Por outro lado, os carcinomas diferenciados se apresentam com vascularização periférica e central, em geral com predomínio desta última. As informações obtidas pelo exame ultrassonográfico podem conduzir à suspeita de malignidade e devem constar em todo laudo de ultrassonografia na avaliação de um nódulo tireoideano. A presença de nódulo tireoideano impalpável em indivíduos de alto risco, cuja tireoide foi previamente irradiada (radioterapia externa da região cervical por outras causas, como linfoma e tumor de laringe) ou com exposição a acidentes radiológicos ou radioativos, cursa com maior risco de malignidade. Nos indivíduos que receberam radioterapia externa em cabeça e pescoço, sugerese que seja realizada ultrassonografia anual até 5 anos após o término da radioterapia. (7,8,27,28)

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Características do nódulo: tamanho, multinodularidade e vascularização:</u> -->
Nódulos únicos com contornos irregulares, nódulo dominante em bócios multinodulares, nódulos com tamanho maior que 4 cm, vascularização intranodular e relação entre a medida transversa do nódulo e a longitudinal maior que 1 cm sugerem tratar-se de nódulo suspeito, com grande chance de malignidade (7,8,28,29).  
<u>Ecogenicidade:</u>  
A baixa ecogenicidade (nódulo sólido hipoecoico) é uma característica relevante, com valor preditivo positivo para malignidade que pode variar de 50% a 63%. Os isoecoicos podem ser malignos em 7% a 25% dos casos, e a malignidade está presente em apenas 4% dos casos de nódulos hiperecoicos. Os carcinomas diferenciados de tireoide totalmente sólidos podem ser malignos em até 95% dos casos (25,30-32).

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Presença de halo:</u> -->
Um halo bem definido e completo sugere benignidade. Quando ele é irregular e parcial, a possibilidade de malignidade deve ser considerada (27,31).  
<u>Calcificações:</u>  
7  
As calcificações no nódulo tireoideano podem ser observadas tanto em nódulos benignos quanto malignos. As macrocalcificaçoes, especialmente na periferia do nódulo (sinal da casca do ovo), são características de benignidade. Já as microcalcificações encontradas no carcinoma papilíifero de tireoide representam os corpos psamomatosos formados pela calcificação de trombos intratumorais ou infarto das extremidades de papilas malignas. A presença de microcalcificações tem alto valor preditivo positivo para malignidade. (27,31)

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Presença e aspecto dos linfonodos cervicais:</u> -->
Os linfonodos cervicais aumentados são achados frequentes, muitas vezes decorrentes de infecções crônicas do trato respiratório superior. Nos tumores diferenciados da tireoide, em especial o carcinoma papilifero, cuja disseminação é por via linfática, a presença de linfonodos aumentados pode indicar acometimento metastático. O estudo ultrassonográfico da região cervical é útil na avaliação de linfonodo suspeito de malignidade; confirma o diagnóstico, quando associado à punção aspirativa e dosagem de tireoglobulina no aspirado; e é importante no seguimento e avaliação da resposta terapêutica. (33)  
As diferenças observadas à ultrassonografia entre linfonodos reacionais e os suspeitos de malignidade já estão bem esclarecidas (34,35): Linfonodos ovalados ou alongados (razão eixo curto/eixo longo menor do que 0,5 ou 0,7), apresentando hilo hiperecogênico central, de ecotextura hipoecogênica uniforme e localizados no 1/3 superior do pescoço (regiões submentoniana, submandibular e jugular superior) são compatíveis com linfonodos reacionais. Os linfonodos arredondados (razão eixo curto/eixo longo maior do que 0,5 ou 0,7), com estrutura heterogênea, hipoecoico com perda do hilo, localizados no 1/3 inferior do pescoço (níveis IV, V e VI) são fortemente suspeitos de metástases de carcinoma diferenciado. Calcificações finas podem ser encontradas em metástases de carcinoma papilífero em 50%–69% dos casos. (7,36)

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 5.ESTADIAMENTO E CLASSIFICAÇÃO DE RISCO -->
A classificação da extensão neoplásica pelo sistema TNM tem como objetivo o prognóstico do CDT (37). Nesta classificação, os pacientes são divididos de acordo com faixa etária: acima ou abaixo de 45 anos. Os quadros 2 e 3 descrevem os critérios desse estadiamento.  
Quadro 2 – Critérios de estadiamento – TNM  
|CATEGORIA<br>TNM|CRITÉRIOS|
|---|---|
|Tx|O tumor primário não pode<br>ser avaliado.|
|T0|Não há evidência de tumor<br>primário.|
|T1a|Tumor com diâmetro de 1 cm<br>ou menos em sua maior<br>dimensão<br>e<br>limitado<br>à<br>tireoide.|
|T1b|Tumor com diâmetro de mais<br>de 1 cm e com até 2 cm em|  
8  
||sua<br>maior<br>dimensão<br>e<br>limitado à tireoide.|
|---|---|
|T2|Tumor com diâmetro mais de<br>2 cm e até 4 cm em sua maior<br>dimensão<br>e<br>limitado<br>à<br>tireoide.|
|T3|Tumor com mais de 4 cm<br>restrito à tireoide ou qualquer<br>tumor com mínima extensão<br>extratireoidiana.|
|T4a|Tumor de qualquer tamanho<br>que se estende além da<br>cápsula tireoidiana e invade<br>tecidos moles subcutâneos,<br>laringe, traqueia, esôfago<br>ou nervo laríngeo recurrente.|
|T4b|Tumor com invasão de fáscia<br>pré-vertebral<br>ou<br>vasos<br>mediastinais ou envolve a<br>artéria carótida.|
|Nx|Linfonodos<br>regionais<br>não<br>podem ser avaliados.|
|N0|Ausência de metástases em<br>linfonodos regionais.|
|N1a|Metástases linfáticas em nível<br>VI (compartimento central).|
||Metástases<br>em<br>outros<br>linfonodos<br>cervicais<br>unilaterais,<br>bilaterais<br>ou|
|N1b|contralaterais (níveis I, II, III,<br>IV ou V) ou em linfonodo<br>retrofaríngeo ou mediastinal<br>superior.|
|M0|Ausência de metástase(s) à<br>distância.|
|M1|Presença de metástase(s) à<br>distância.|  
Adaptado de UICC. TNM – Classificação de Tumores Malignos (37).  
Quadro 3 – Estágios tumorais segundo a Classificação TNM  
9  
|ESTÁGIO|IDADE<br>ABAIXO DE<br>ANOS|45|IDADE<br>ACIMA<br>DE 45 ANOS|
|---|---|---|---|
|I|Qualquer<br>qualquer<br>M0.|T,<br>N,|T1a, T1b, N0,<br>M0.|
|II|Qualquer<br>qualquer<br>M1.|T,<br>N,|T2, N0, M0.|
||||T3, N0, M0.|
|III|||T1, T2, T3, N1a,<br>M0.|
|IVA|||T1, T2, T3, N1b,<br>M0.|
||||T4a, N0, N1,<br>M0.|
|IVB|||T4b,<br>qualquer<br>N, M0.|
|IVC|||Qualquer<br>T,<br>qualquer N, M1.|  
Adaptado de UICC. TNM – Classificação de Tumores Malignos (37).  
O CDT tem excelente prognóstico, mesmo em casos de doença metastática. A taxa média de sobrevida em 10 anos de pacientes com carcinoma papilífero ultrapassa 95% nos casos de doença restrita à tireoide (38). Em pacientes com doença metastática, esta sobrevida é reduzida de maneira significativa (70% e 64% em 10 e 15 anos, respectivamente); entretanto este aumento da taxa de mortalidade é mais lento do que o observado em outras neoplasias malignas (39). Em cerca de 40% dos casos de CDT já se observam metástases linfáticas ao diagnóstico (40). Este fato proporciona consequências como altas taxas de recidiva locorregional, aumento da incidência de retratamento, alta morbidade, potencial redução da qualidade de vida (41) e possível redução na sobrevida (42).  
Recentemente, o papel da resposta ao tratamento inicial tem sido alvo de discussão. Estudos retrospectivos mostram que o tratamento inicial do CDT possui forte correlação com o risco de recidiva em longo prazo (43), reiterando a ideia de que um tratamento inicial adequado é capaz de reduzir a morbi-mortalidade de maneira significativa. Dessa forma, com o objetivo de prever o risco de recidiva, existe recente proposta para o _reestadiamento_ dos pacientes após tratamento inicial definido, classificando-os de acordo com a resposta ao mesmo (43). Uma crítica a esse modelo é o fato da necessidade de radioablação em todos os pacientes para se alcançar esta resposta.  
<u>Classificação do risco:</u>  
Em relação ao estadiamento do CDT, os pacientes podem ser estratificados de acordo com os potenciais de riscos de recidiva e de mortalidade relacionada ao tumor. Os critérios disponíveis se baseiam em dados posteriores ao tratamento inicial.  Com o objetivo de predizer o risco de recidiva tumoral, a ATA propõe que os pacientes sejam classificados como sendo de baixo, intermediário e alto risco (7).  
10  
Os pacientes são considerados de baixo risco quando não apresentam doença metastática, tiveram toda doença macroscópica removida, não apresentavam evidência de invasão tumoral local de tecidos ou estruturas adjacentes, não possuem tumores de variantes histológicas sabidamente agressivas e não apresentaram captação de radioiodo em local que não o leito cirúrgico em cintilografia de corpo inteiro (PCI) realizada após a radioiodoterapia inicial.  
São classificados como de risco intermediário aqueles pacientes que tenham quaisquer das seguintes características: invasão microscópica de estruturas adjacentes, presença de variantes histológicas agressivas ou com invasão vascular, presença de metástase(s) linfática(s) ou que cursaram com captação extraleito tireoidiano de radioiodo na PCI após dose ablativa. Por fim aqueles indivíduos nos quais há presença de doença residual local macroscópica após o tratamento cirúrgico, tumor com invasão local grosseira evidente ou doença metastática à distância são descritos como de alto risco (7).  
De forma semelhante o consenso da ETA estratifica os pacientes como de muito baixo risco, baixo risco e risco elevado (9) com o objetivo de definir critérios quanto ao benefício de tratamento complementar com radioiodo.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 6.TRATAMENTO -->
A modalidade terapêutica dos tumores malignos da glândula tireoide varia com o tipo histológico e o estadiamento. No caso do CDT, deve-se também levar em consideração a análise dos fatores de risco.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 6.1. CIRURGIA -->
A extensão da cirurgia nos tumores malignos da tireoide, em especial o carcinoma papilifero, sempre foi motivo de debate (44). A opção cirúrgica deve levar em conta não somente a remoção do tumor primário e de suas metástases locoregionais, como também reduzir a morbidade do procedimento. De acordo com as tendências atuais e os consensos citados anteriormente, as condutas cirúrgicas também baseiam-se nos fatores prognósticos de mortalidade e recorrência.  
A base teórica que apoia as intervenções cirurgias mais extensas fundamenta-se no fato de que os tumores papilares são comumente multifocais e bilaterais, além de permitirem a ablação com iodo radioativo e o monitoramento por meio da dosagem de tireoglobulina. A tireoidectomia total e lobectomia, quando realizadas por cirurgiões experientes, não mostram diferenças comparativas em relação à morbidade. Porém, Bilimoria and cols avaliaram os dados de 52.173 pacientes com o diagnóstico de carcinoma papilífero da tireoide operados nos EUA no período de 1985-1998, concluindo que a tireoidectomia total, quando comparada com a lobectomia, foi associada com diminuição do risco de mortalidade e da recorrência tumoral para tumores de todas as dimensões, exceto para lesões menores que 1 cm de diâmetro. (45)  
Segundo a ATA, a tireoidectomia total está indicada, devido ao aumento de risco de malignidade, em pacientes com citologia indeterminada em tumores maiores que 4cm, quando existe  alto grau de atipia celular ou  quando a biopsia é suspeita de carcinoma papilífero da tireoide (em qualquer tamanho de nódulo). Uma cirurgia mais ampla também estaria indicada em pacientes com historia familiar de câncer da tireoide e naqueles expostos previamente a radiação ionizante. (7)  
Nos pacientes com diagnóstico de carcinoma maiores que 1 cm, o tratamento inicial é a tireoidectomia total, a não ser que haja alguma contraindicação para o procedimento. A lobectomia poderia ser realizada em pacientes com tumores menores que 1 cm (T1a), unifocais, totalmente  
11  
intratireoidianos, papiliferos clássicos, sem história familiar ou de irradiação prévia, sem metástase (46).  
Segundo a experiência do _Memorial Sloan Kettering Cancer Center_ , a lobectomia é aceitável também em pacientes com tumor menor que 4 cm (T1,T2), totalmente incluído no tecido tireoideano, sem metástases linfonodais e sem doença contralateral confirmada por ultrassonografia (43).  
Em determinadas situações pode ser necessária a complementação da tireoidectomia, especialmente quando não há o diagnóstico pré-operatório de câncer. Muitos tumores são multifocais, e a incidência de novos focos no lobo contralateral é elevada, segundo alguns estudos. Por outro lado, há pacientes em que o estadiamento pós-operatório os inclui nos tumores de risco e, portanto, candidatos ao tratamento com iodo radioativo, para a qual a tireoidectomia total é prérequisito. (47,48,49,50)  
A presença de linfonodos cervicais acometidos no carcinoma papilífero da tireoide é freqüente, variando entre 20% a 50% dos casos e pode estar presente mesmo nos tumores menores que 1 cm. (40,51,52)  
Em revisão publicada por Mazzaferri (53), as metástases linfonodais foram encontradas em 36% de 8.029 adultos com carcinoma papilífero, 17% dos tumores foliculares e em mais de 80% das crianças. Ainda há controvérsia sobre o valor prognóstico da presença de metástases, mas publicações recentes têm apontado para uma associação com maiores taxas de recorrência e menor sobrevida (54).  
As metástases do compartimento central nem sempre são detectadas pelos métodos de imagem, e em tumores classificados como T1 e T2 a freqüência de metástases nesta região chega a 30% (55).  
Embora a presença de linfonodos não seja muito valorizada nos pacientes de baixo risco, alguns autores chamam a atenção para o fato de que em pessoas mais velhas (acima de 45 anos) pode haver maior risco de recorrência, especialmente naquelas com múltiplas metástases ou extravasamento da cápsula do linfonodo (56,57).  
Em muitos pacientes, as metástases linfonodais somente são observadas durante o ato cirúrgico. As metástases do compartimento central não são detectadas no pré–operatório pelos métodos habituais utilizados e mesmo pela palpação durante o ato operatório. Existem controvérsias quanto à indicação da abordagem do compartimento central, isto é, se este deve sempre ser abordado profilaticamente ou apenas quando existem evidências de acometimento linfonodal (55,58).  
A dissecção de linfonodos centrais refere-se à excisão sistemática dos linfonodos pré-larígeos, peritraqueais e paratraqueais que estão no nível VI do pescoço, podendo ser unilateral ou bilateral. Na cirurgia profilática ou eletiva, esta conduta é realizada na ausência de anormalidades linfonodais detectadas por meio do exame clínico ou de imagem (44).  
Para pacientes com tumores pequenos, não invasivos, aparentemente sem metástases ganglionares, a dissecção profilática do compartimento central (níveis VI e VII) traria maior morbidade à cirurgia, quando realizada por profissionais menos experientes. O esvaziamento linfático dos compartimentos laterais (níveis II, III, IV e V) nos pacientes com metástases linfáticas evidentes, reduz o risco de recorrência e possível mortalidade (59).  
Os dados atuais são insuficientes quanto à comprovação de benefício da dissecção profilática do nível central em diminuir a persistência ou recorrência da neoplasia, devido às limitações dos estudos existentes e os resultados conflitantes. A orientação da ATA é de que este procedimento  
12  
deverá ser realizado nos pacientes previamente diagnosticados com metástases linfonodais, naqueles com tumores classificados como T3 ou T4.  Para pacientes com tumores menores, não invasivos e aparentemente sem linfonodos acometidos, o risco-benefício deverá ser considerado individualmente (7,44).

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 6.2. RADIOIODOTERAPIA (RIT) -->
A radioiodoterapia tem duas finalidades (60):  
- radioablação: utilizada após a tireoidectomia total, com o objetivo de destruir tecido tireoidiano remanescente, em geral tecido normal, e facilitar o acompanhamento com a dosagem de tireoglobulina sérica. Em geral são utilizadas atividades de 1.100 a 3.700 MBq (30 a 100 mCi); e  
- terapêutica: além de buscar destruir tecido remanescente, elimina micrometástases locoregionais e metástases à distância. Em geral são utilizadas atividades acima de 3.700 MBq (100 mCi).  
<u>Avaliação inicial e indicações</u>  
O paciente candidato à RIT deverá ser avaliado pelo médico assistente sob o ponto de vista de sua condição clínica atual e indicação do tratamento. É fundamental que sejam apresentadas informações referentes ao tratamento cirúrgico: extensão da cirurgia, complicações, presença de doença residual ou metastática conhecida e a dose iodo radioativo indicada. O laudo com o diagnóstico histopatológico deverá estar disponível, assim como as lâminas e blocos, caso haja necessidade de se proceder à revisão de lâminas ou exames complementares, como de imunohistoquímica ou outros marcadores tumorais.  
À anamnese e ao exame físico, devem ser avaliados os seguintes aspectos: data do diagnóstico, apresentação inicial da doença, extensão do tumor, ausência ou presença de metástases, resultados de exames pré-operatórios, resultados de exames citológias e histopatológicos, tipo de cirurgia realizada, complicações pós-operatórias, uso de levotiroxina e outros tratamentos realizados (cirurgias prévias, radioiodoterpia, radioterapia externa e outros). Na individualização do risco, é importante investigar sobre a história familiar de neoplasias malignas da tireoide, exposição prévia à radiação ionizante, uso de medicamentos e demais fatores que possam interferir no êxito da RIT, como ingestão de medicamentos ricos em iodo, exposição recente a contraste iodado e presença de doença hipotálamo-hipofisária.  
É importante avaliar a indicação de RIT de acordo com critérios de risco de recidiva e mortalidade pelo CDT (7,9).  
Os pacientes considerados como de muito baixo risco pela ETA (ou de baixo risco pela ATA) possivelmente não serão benefíciados com o tratamento com iodo radioativo, devendo manter-se apenas sob controle clínico e seguimento (descrito adiante).  
Pacientes considerados de alto risco são sabidamente favorecidos com a RIT. Dessa forma, devem ser encaminhados para dose terapêutica aqueles com doença residual local ou com metástase(s) à distância iodocaptante(s).  
O benefício da RIT sobre as recidiva e mortalidade em pacientes considerados como de baixo risco pela ETA (risco intermediário pela ATA) é questionável, não havendo consenso sobre a indicação de tratamento nesta população (9). No entanto, não se questiona que a ablação de tecidos remanescentes nestes indivíduos facilita a avaliação da extensão da doença e seguimento clínico (61). Portanto, na falta de dados na literatura que subsidiem a indicação precisa de RIT, em pacientes com tumores restritos à glândula tireoidiana ou com mínima invasão capsular, de tamanho inferior a 4 cm e com presença ou sem metástase(s) linfática(s) apenas em compartimento central (nível VI), a indicação de radioiodoterapia deve ser avaliada segundo critérios particulares  
13  
de cada paciente. O objetivo principal da RIT é a redução do risco de desfechos desfavoráveis relacionados ao tumor e não apenas facilitar o seguimento. Esta recomendação se justifica também no objetivo de se evitar complicações precoces e tardias relacionadas à exposição ao radioiodo (62,63).  
Após a confirmação da indicação do tratamento com radioiodo, os pacientes devem ser encaminhados a Serviço de Medicina Nuclear. Com o objetivo de estimar o volume de tecido remanescente ou de doença metastática, assim como a sua avidez por iodo, poderão ser solicitados exames de captação cervical e pesquisa de corpo inteiro (PCI) com baixas doses de radioiodo. Uma vez que o potencial de metástase(s) à distância é baixo em pacientes considerados de risco baixo/intermediário, a PCI pré-tratamento pode ser prescindida na maioria dos pacientes, sem impacto significativo na mudança do planejamento terapêutico. Tal medida visa também a evitar potencial prejuízo ao tratamento por efeito _stunning_ (64). Também deverão ser solicitados para avaliação pré-tratamento: dosagens séricas de tireoglobulina estimulada (vide a seguir, em “Preparo para a RIT”) e de anticorpos antitireoglobulina, hemograma, cálcio e fósforo.  
Exames direcionados à avaliação de doença metastática previamente conhecida ou recémdiagnosticada pelos exames iniciais podem ser solicitados (cintilografia óssea, radiografia simples, tomografia computadorizada ou ressonância magnética), uma vez que a ressecção cirúrgica das metástases deve ser preferida ao tratamento com radioiodo, sempre que possível (65,66). Demais exames complementares que possam contribuir na avaliação de comorbidades que interfiram direta ou indiretamente com a RIT devem ser solicitados, como espirometria em pacientes com metástases pulmonares difusas e avaliação de função renal em pacientes com insuficiência renal crônica.  
Em casos em que há indícios clínicos, laboratoriais, ou em exames de imagem de tecido remanescente ou de doença residual local de volume considerável, a realização de ultrassonografia da região cervical com _dopplerfluxometria_ pode ser útil na sua quantificação. Nestes casos deve-se avaliar a possibilidade de ressecção cirúrgica deste tecido, uma vez que a eficácia de ablação é reduzida (67).

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Preparo para a radioiodoterapia</u> -->
O preparo para a terapia com radioiodo tem como objetivo aumentar a eficácia do tratamento. A principal medida relacionada à eficácia é a elevação dos níveis de TSH. A elevação deste hormônio estimulante pode ser obtida pela interrupção do uso de levotiroxina, induzindo hipotiroidismo endógeno (causando elevação fisiológica do TSH), ou pela administração exógena de TSH recombinante humano (TSHrh).  
Estudos em pacientes considerados de baixo/intermediário risco mostram que ambas as alternativas possuem valores semelhantes de eficácia na ablação de tecidos remanescentes (68). Outro ponto importante, é que não houve impacto negativo do uso de TSHrh nas taxas de recidiva de doença em pacientes cuja ablação foi realizada com TSHrh (69).  
O uso de TSHrh tem sido utilizado para a ablação de tecido remanescente tireoidiano em pacientes de baixo/intermediário risco no Brasil, EUA, Europa e outros países (70-76), porém a evidência é escassa. Assim, o emprego de TSHrh na RIT de pacientes com doença metastática não foi regulamentado no SUS.  
Outra questão a ser considerada no preparo para a radioiodoterapia deve ser relativamente a dieta pobre em iodo, cuja ingestão diária deverá estar abaixo de 50 mcg/dia). Inexiste consenso sobre o tempo necessário de dieta. Dessa forma, os pacientes devem ser recomendados a mantêla por um período de pelo menos duas semanas antes da RIT, período este que pode sofrer variação de acordo com a região geográfica analisada (maior ou menor aporte regular de iodo na dieta e no  
14  
ambiente). Essa medida tem como objetivo aumentar a avidez pelo iodo do tecido a ser tratado e deverá ser instituída independente do tipo de preparo, seja pela suspensão da tiroxina ou pelo uso do TSH recombinante. (77-80)  
Os pacientes devem também ser orientados a evitar riscos de contaminação por outras fontes externas de iodo não radioativo, também aquele encontrado em tinturas, esmaltes e produtos cosméticos específicos.  
Por fim, os pacientes com indicação de RIT devem ser orientados a manter de forma regular tratamentos de possíveis comorbidades durante todo o período de pré e per tratamento com radioiodo.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Atividade de radiação administrada</u> -->
A atividade a ser administrada de radioiodo em pacientes com CDT varia de acordo com o objetivo do tratamento. É importante salientar que a terapia deve ser a mais eficaz possível com o menor risco de exposição à radiação necessária.  
Nos pacientes de baixo risco que sejam considerados como tendo benefício clínico com a RIT, o objetivo do tratamento é promover a ablação de tecido remanescente. Esta ablação pode ser definida como a ausência de captação de radioiodo em leito tireoidiano em estudo cintilográfico, ou a ausência de níveis séricos detectáveis de tireoglobulina estimulada (7).  
Apesar de tendências no passado de se prescrever atividades mais elevadas para radioablação (7,9,64,68), estudos recentes mostram que atividades em torno de 1.110 MBq (30 mCi), com indução de hipotiroidismo, são capazes de promover ablação de tecido remanescente de maneira não diferente ao observado com atividades de 3.700 MBq (100 mCi) (75,81-84). Dessa forma, os pacientes considerados de baixo/intermediário risco (tumor restrito à glândula tireoidiana ou com mínima invasão capsular, de tamanho inferior a 4 cm, com presença ou não de metástases linfáticas apenas em compartimento central) e em que não houver suspeita de doença residual microscópica, e que poderiam se beneficiar do tratamento com radioiodo, devem receber atividades entre 1.110 e 3.700 MBq (30 e 100 mCi). Nos casos de pacientes também de baixo/intermediário risco, porém em que há suspeita de doença microscópica residual, ou em que fatores de possível pior prognóstico se mostrem presentes (como, por exemplo, presença de variantes histológicas de maior agressividade), recomenda-se neste Protocolo o emprego de ablação com atividade mínima de 3.700 MBq (100 mCi) (7,9,68).  
Nos casos de doença residual macroscópica evidente ou de metástases à distância, o tratamento com radioiodo se relaciona de maneira significativa com benefício na morbimortalidade (39,83). Apesar de não haver consenso sobre a melhor atividade de radiação a ser administrada nesses casos, valores não inferiores a 7.400 MBq (200 mCi), mas não ultrapassando valores radiotóxicos para a medula óssea, devem ser empregados. Devido ao risco de edema peritumoral e consequente compressão de estruturas nobres adjacentes, dependendo da localização e extensão da doença a ser tratada, anti-inflamatórios, esteroides ou não, poderão ser empregados por ocasião da RIT.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: <u>Medidas de radioproteção intra e extra-hospitalares</u> -->
Devido ao potencial risco decorrente de exposição à radiação de pacientes, parentes, profissionais da saúde e população em geral, todos os procedimentos realizados que envolvam exposição interna ou externa a material radioativo devem seguir as recomendações de segurança publicadas pela Comissão Nacional de Energia Nuclear – CNEN (resoluções CNEN 3.0 e CNEN 6.05, disponíveis em <u>http://www.cnen.gov.br/seguranca/normas/mostra-norma.asp?op=305), pela</u> Agência Internacional de Energia Atômica – IAAE (Relatório de Segurança nº 63 da Agência Internacional de Energia Atômica, disponível em <u>http://www-</u>  
15  
<u>pub.iaea.org/MTCD/publications/PDF/pub1417_web.pdf) e pela Agência Nacional de Vigilância Sanitária</u> – <u>ANVISA (RDC 38/Medicina Nuclear 2008, disponível em http://elegis.anvisa.gov.br/leisref/public/showAct.php?id=31277&word=).</u>

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 6.3. RADIOTERAPIA EXTERNA -->
O tratamento clássico do carcinoma diferenciado da tireoide é a tireoidectomia seguida do uso de iodo radioativo, nos casos selecionados, como descrito anteriormente. O uso da radioterapia externa sempre foi objeto de controvérsias, uma vez que não há estudos suficientes para comprovar a sua eficácia.  
Alguns grandes centros de radioterapia (85) mostram que pacientes idosos (acima de 60 anos) que apresentam extensão tumoral extratireoidiana se beneficiam da radioterapia, com melhora da sobrevida e controle local da doença. Outros autores consideram que, mesmo os pacientes com extensão extratireoidiana mínima, com idade superior aos 60 anos também poderiam ser tratados com a radioterapia externa, mas isto não é aceito por todos os autores, por não existirem evidências consistentes na literatura mundial (86).  
Segundo o consenso da ATA e da Associação Britânica de Tireoide, a radioterapia externa estaria indicada nos pacientes com idade superior a 45 anos, que apresentem extensão extratireoidiana volumosa à cirurgia, pacientes com tumor residual e pouca resposta ao iodo radioativo e em pacientes acima de 60 anos, com doença extensa (pT4)  e  grande  disseminação linfonodal, mesmo sem evidência de doença macroscópica. (87,88)  
É necessária uma seleção criteriosa dos pacientes de alto risco, para assegurar que os benefícios em reduzir a recorrência sejam superiores à toxicidade consequente à radioterapia externa (88,89).  
Outras indicações da radioterapia externa seriam na(s) metástase(s) óssea(s) dolorosa(s), em que o alivio da dor é o maior beneficio obtido, e metástase(s) em área(s) crítica(s) ou sujeita(s) a fratura ou fenômeno compressivo, em que a cirurgia não é possível. São exemplos destas lesões as que acometem o sistema nervoso central, vértebra, linfonodo subcarinal ou pelve (87).  
A técnica de radioterapia externa é individualizada e conforme a conduta institucional adotada.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 6.4. QUIMIOTERAPIA -->
A quimioterapia antineoplásica pode ser empregada como uma medida paliativa para 25% dos casos sintomáticos de carcinoma diferenciado da tireoide recorrente inoperável ou metastático, padrão folicular ou misto, que não concentram Iodo131. Segundo o único estudo de fase III publicado, a doxorrubicina é o fármaco classicamente empregado no tratamento paliativo, em monoterapia, com resultados terapêuticos modestos: taxa de resposta de 31% e sobrevida de 15% em 2 anos (90).  
Estudos clínicos preliminares sugerem que a associação de interferona alfa-2b à doxorrubicina (91) ou a monoterapia com sorafenibe (92,93,94), sunitinibe (95), vandetanibe (96) ou vemurafenibe (97) são tratamentos experimentais, e seu emprego fora de ensaios clínicos não pode ser recomendado até que estudos comparativos (fase III) demonstrem sua segurança e eficácia. Visto não haver evidência de claro beneficio global em termos de sobrevida, o Ministério da Saúde não recomenda o uso desses medicamentos para pacientes com carcinoma diferenciado da tireoide. Quando houver evidências suficientes para serem analisadas, eles deverão ser submetidos à CONITEC para esta indicação.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 7.SEGUIMENTO -->
16  
Os pacientes cuja administração de levotiroxina foi suspensa para a elevação de TSH devem ter este medicamento reintroduzido por ocasião da alta hospitalar.  
Após terem recebido o tratamento com radioiodo, independentemente da atividade radioativa da dose administrada, da classificação de risco, da presença ou não de doença residual ou metástase(s) conhecida(s), todos os pacientes devem ser avaliados por meio de PCI, realizada 7 a 10 dias após terem recebido o radiofármaco. A realização de PCI após dose terapêutica é capaz de evidenciar foco(s) de doença metastática desconhecido(s) previamente, alterando a conduta terapêutica futura (98).  
Posteriormente à terapia ablativa, os pacientes devem ser orientados a manter o uso contínuo de levotiroxina, com o objetivo de manter níveis de TSH adequados para a prevenção de recidiva e controle de doença residual. Os níveis de TSH a serem atingidos variam de acordo com o objetivo de supressão hormonal e devem ser individualizados conforme o balanço entre o potencial de risco de desfechos desfavoráveis relacionados à neoplasia e efeitos adversos de supressão do TSH (Quadro 4) (99).  
Quadro 4 – Esquema de terapia de reposição de levotiroxina  
|Risco<br>relacionado à<br>|_Risco de re_<br>_tumoral_|_cidiva e prog_|_ressão_|
|---|---|---|---|
|reposição de||||
|T4|Alto|Intermediário|Baixo|
|_Alto_|Menos<br>de<br>0,1<br>mU/L,<br>caso doença<br>persistente<br>ou<br>metastática;<br>0,1-<br>0,5mU/L,<br>por<br>5-10<br>anos,<br>caso<br>livre<br>de<br>doença.|0,5-1,0mU/L,<br>caso livre de<br>doença por<br>5-10 anos,<br>depois<br>1,0-2,0 mU/L.|1,0-<br>2,0<br>mU/L|
|_Intermediário_|Menos<br>de<br>0,1<br>mU/L,<br>caso doença<br>persistente<br>ou<br>metastática;<br>0,1-<br>0,5mU/L,|0,1-0,5mU/L,<br>caso livre de<br>doença por 5-<br>10 anos,<br>depois1,0-2,0<br>mU/L.|1,0-<br>2,0<br>mU/L|  
17  
||por<br>5-10<br>anos,<br>caso<br>livre<br>de<br>doença.|||
|---|---|---|---|
||Menos<br>de<br>0,1<br>mU/L,<br>caso doença<br>persistente<br>ou|0,1-0,5mU/L,<br>caso livre de<br>doença por 5-<br>10<br>anos,<br>depois|1,0-<br>2,0<br>mU/L|
|Baixo|metastática;<br>0,1-<br>0,5mU/L,<br>por<br>5-10<br>anos|0,3-2,0<br>mU/L.||
||caso<br>livre<br>de<br>doença.|||  
Extraído de Biodi & Cooper, 2010 (99).  
A tireoglobulina é um marcador tumoral específico e muito útil no seguimento dos pacientes com tumores diferenciados da tireoide. Usualmente a dosagem de tireoglobulina é feita pelo método imunométrico. Com este método, a presença de anticorpos antitireoglobulina causa grande interferência, resultando em níveis falsamente baixos do marcador. Portanto, existe sempre a necessidade da dosagem dos anticorpos antitireoglobilina concomitante à da tireoglobulina. As dosagens devem ser feitas de preferência no mesmo laboratório, com a utilização do mesmo ensaio durante o seguimento do paciente. Após a tireoidectomia total e ablação com radioiodo, a tireoglobulina habitualmente torna-se indectável e sua presença deve alertar para possíveis recidivas. (7,9)  
É importante ressaltar que, naqueles pacientes submetidos à tireoidectomia total, mas que não se submeteram à ablação com iodo radioativo como complementação do tratamento, o seguimento deverá ser feito por meio da ultrassonografia cervical e pelos níveis séricos de tireoglobulina, sendo que, nesta situação específica, deverá ser valorizada a elevação deste marcador, ao longo do tempo (7).  
Em relação ao seguimento posterior, os pacientes devem ser reavaliados de acordo com o potencial de risco de recidiva (Quadro 5). Nesse sentido, critérios de re-estratificação do risco poderão ser empregados (43). Seis a doze meses após a RIT, os pacientes considerados como de baixo/intermediário risco devem ter a dosagem de tireoglobulina estimulada, com interrupção de levotiroxina. A fim de confirmar a eficácia da ablação dos remanescentes, a PCI com baixas doses de radioiodo poderá ser indicada. Pacientes considerados de alto risco devem ser submetidos à reavaliação por meio de dosagens de tireoglobulina, anticorpos antitireoglobulina e PCI após 6 meses da RIT. No quadro 5 estão demonstradas as condutas propostas de acordo com a resposta à terapêutica inicial.  
18  
Quadro 5 - Reavaliação 6–12 meses após o tratamento inicial  
|_RESPOSTA_<br>_EXCELENTE_|_RESPOSTA_<br>_ACEITÁVEL_||_RESPOSTA_<br>_INCOMPLETA_|
|---|---|---|---|
|Todos<br>os<br>critérios:|Qualquer<br>dos seguinte|um<br>s:|Qualquer um<br>dos seguintes:|
|Tireoglobulina<br>suprimida<br>e|Tireoglobulin<br>suprimida|a|Tireoglobulina<br>suprimida|
|estimulada|abaixo<br>1ng/ml<br>estimulada|de<br>e|acima de 1<br>ng/ml<br>e<br>estimulada|
||entre 1 e<br>ng/ml.|10|acima de 10<br>ng/ml.|
|Ultrassonografia<br>cervical sem<br>evidência|Ultrassonogr<br>cervical<br>c<br>alterações nã<br>específicas<br>linfonodos<br>estáveis<br>c<br>abaixo de 1c|afia<br>om<br>o<br>ou<br>om<br>m.|Tireoglobulina<br>em elevação|
|Estudos<br>de|Exame|de|Evidência de|
|imagem ou de<br>medicina|imagem ou<br>medicina|de|doença<br>persistente ou|
|nuclear|nuclear||novas lesões|
|negativos|com alteraç<br>não|ões|em exames de<br>imagem ou de|
|(quando<br>ndicados).|específicas,<br>entretanto<br>completame<br>normal.|não<br>nte|medicina<br>nuclear.|  
Adaptado de Tuttle RM, 2010 (43).  
O acompanhamento ambulatorial deverá ser anual ou em intervalos menores em casos específicos, por meio da realização de ultrassonografia de região cervical e dosagens de tireoglobulina e anticorpos antitireoglobulina em uso de levotiroxina.  
O tempo de seguimento depende de presença ou não de recorrência da doença. Quanto maior o tempo sem evidência de recorrência, maior a chance de cura. Inexiste definição sobre o tempo necessário de seguimento destes pacientes; a maioria dos autores considera como 10 anos o tempo mínimo de acompanhamento dos casos de carcinoma de tireoide. Pacientes com indícios de respostas incompletas aos tratamentos iniciais, a pesquisa de recidiva locorregional ou de metástase(s) à distância deve ser realizada por meio de outros métodos de imagem. Uma vez detectada a recidiva local, linfática ou doença metastática, o tratamento deverá ser individualizado  
19  
de acordo com fatores relacionados à doença como: extensão, localização, tipo histológico e aqueles relacionados ao paciente como comorbidades, risco cirúrgico e expectativa de vida. As principais opções terapêuticas nesses casos são a ressecção cirúrgica, nova RIT e radioterapia externa (100).  
Há relato de regressão espontânea após resposta bioquímica incompleta à RIT inicial de doentes com câncer da tireoide (103); e, nos pacientes com persistência de doença local ou metastática, a RIT poderá ser novamente empregada enquanto houver indícios de captação de iodo pela(s) lesão(ões) (7).  
Entretanto, uma parcela dos pacientes com doença persistente ou metastática cursa com refratariedade à RIT e progressão da doença. Nesses casos, estudos com o uso de substâncias indutoras de rediferenciação tumoral não mostrou resultados significativos (101,102), ficando como perspectiva a inclusão de pacientes em estudos clínicos envolvendo medicamento de alvo molecular e inibidor de vias de proliferação celular (104). O acompanhamento nestes casos não tem tempo pré-determinado.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 8.REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR. -->
Pessoas com suspeita ou diagnóstico de nódulo(s) tireoidiano(s) devem ter acesso a consultas com profissionais experientes em doenças da tireoide e à propedêutica básica, em especial a ultrassonografia de qualidade e punção por agulha fina por ela guiada. No seguimento dos pacientes é fundamental a garantia dos exames de TSH, tireoglobulina e anticorpos antitireoglobulina. Os pacientes com alta suspeita ou com diagnóstico de tumor maligno com fatores pré-operatórios de risco intermediário ou alto devem ser priorizados para o atendimento nos serviços em seu município de origem ou na região de saúde, para realização dos tratamentos necessários. Independentemente da localidade do primeiro atendimento, que poderá ocorrer nas unidades básicas de saúde, unidades secundárias ou hospitais credenciados do SUS, públicos ou privados, devem estar garantidas, quando necessárias, as avaliações por especialistas nas áreas de endocrinologia e de cirurgia de cabeça e pescoço, otorrinolaringologia ou cirurgia geral. Cabe à Regulação estabelecer mecanismos e fluxos assistenciais que garantam o acesso à rede assistencial em tempo oportuno e com qualidade, por meio da contratação de serviços ambulatoriais e hospitalares, instalação de complexos reguladores que permitam a disponibilização de agendas, a priorização de pacientes e a autorização de procedimentos ambulatoriais e hospitalares.  
É essencial que sejam estabelecidos mecanismos de controle, avaliação e auditoria, que possam sistematicamente verificar a adequação da assistência aos pacientes, especialmente no que se refere à qualidade dos procedimentos realizados e aos intervalos de tempo entre o diagnóstico e os tratamentos, especialmente os cirúrgicos. São fundamentais o monitoramento da oferta de exames propedêuticos pelos estabelecimentos de saúde credenciados do SUS, públicos e privados, a avaliação da qualidade dos exames de imagem e os resultados das citologias dos nódulos puncionados.  
Em relação às citologias, os seguintes dados devem ser avaliados: percentual de pacientes que tiveram os exames com material insuficiente, citologias inconclusivas e as correlações entre resultados das citologias e os exames anatomopatológicos das peças cirúrgicas.  
É importante criar mecanismos para a busca ativa de pacientes com resultados alterados na rede assistencial, com o objetivo de agilizar o acesso aos serviços referenciais para a continuidade da avaliação e tratamento adequado.  
Os procedimentos cirúrgicos devem ser previamente autorizados por uma instância do complexo regulador, que terá como atribuições verificar a adequação da solicitação, direcionar o paciente para o hospital mais qualificado para a realização do procedimento indicado e monitorar  
20  
o tempo de espera.  As cirurgias devem ser executadas preferencialmente em hospitais habilitados em oncologia como UNACON ou CACON e por equipes capacitadas que possam garantir o acompanhamento dos pacientes no pós-operatório imediato e tardio, tratar as complicações e realizar, quando necessário, o seguimento e a complementação do tratamento.  
Nos hospitais que não possuam Serviço de Medicina Nuclear, o fluxo para acesso à RIT deverá ser previamente definido pelo respectivo Gestor local do SUS, com a garantia desta modalidade de tratamento, assim como os exames propedêuticos necessários, na especialidade em questão.  
O tratamento com iodo radioativo deverá ser autorizado previamente por equipe capacitada, que avaliará a pertinência da solicitação, conforme o estabelecido neste Protocolo. A equipe autorizadora verificará o preenchimento correto do Laudo para Emissão de AIH, no caso de pacientes candidatos a doses elevadas de iodo radioativo, ou o Laudo para Emissão de APAC, nas indicações para o uso de doses ambulatoriais. Devem constar em ambas as modalidades de solicitações: dados de identificação do paciente, descrição da cirurgia realizada (tireoidectomia total ou complementação de tireoidectomia parcial, associadas ou não ao esvaziamento cervical) – <u>a tireoidectomia total é premissa obrigatória para solicitação da RIT; resultado do exame</u> anatomopatológico; código da CID; estágio do tumor (pela Classificação TNM) e o código do procedimento relativo à dose de iodo radioativo solicitada. Recomenda-se que seja estabelecida rotina para a solicitação do exame de pesquisa de corpo inteiro (PCI), a ser realizada no período pósdose, que será autorizada simultaneamente ao tratamento com iodo radioativo.  
Em caso de solicitação de tratamento para recidiva tumoral local ou metástase(s), o médico solicitante deve informar os procedimentos cirúrgicos já realizados e outro(s) tratamento(s) anterior(es) - RIT, radioterapia externa e quimioterapia. Devem ser anexados os resultados dos exames de TSH, tireoglobulina e anticorpos antitireoglobulina e dos exames de imagem que comprovem a doença metastática, assim como o código do procedimento correspondente à dose de iodo indicada.  
O SUS contempla todos os procedimentos cirúrgicos (estes na média e na alta complexidade), radioterápicos e quimioterápico necessários ao tratamento do carcinoma diferenciado da tireoide.  
Especificamente à RIT, são os seguintes os códigos correspondentes que devem ser solicitados no Laudo para Emissão de APAC e AIH:  
03.04.09.005-0 - Iodoterapia de carcinoma diferenciado da tireoide (30 mCi) – APAC/SIA-SUS 03.04.09.006-9 - Iodoterapia de carcinoma diferenciado da tireoide (50 mCi) – APAC/SIA-SUS 03.04.09.002-6 - Iodoterapia de carcinoma diferenciado da tireoide (100 mCi) – AIH/SIH-SUS 03.04.09.001-8 - Iodoterapia de carcinoma diferenciado da tireoide (150 mCi) – AIH/SIH-SUS 03.04.09.003-4 - Iodoterapia de carcinoma diferenciado da tireoide (200 mCi) – AIH/SIH-SUS 03.04.09.004-2 - Iodoterapia de carcinoma diferenciado da tireoide (250 mCi) – AIH/SIH-SUS  
Na indicação do tratamento ambulatorial com dose baixa (30 mCi a 50 mCi), com o objetivo de ablação de remanescentes tireoidianos pós-cirúrgicos em pacientes de baixo risco (conforme descrição no item 6.2 - Atividade de radiação administrada), será necessário o preenchimento do Laudo para Autorização de Procedimentos de Alta Complexidade (APAC), com todas as informações descritas anteriormente. Também nesta opção terapêutica, deve-se realizar a pesquisa de corpo inteiro (PCI) pós- dose.  
O hospital ou serviço no qual o paciente foi submetido à radioiodoterapia será responsável pela assistência ao paciente e complicações advindas do tratamento. Caberá à regulação e ao controle e avaliação analisar a execução dos procedimentos, por meio da produção registrada nos  
21  
sistemas SIA/SUS e SIH/SUS, a verificação _in loco_ das condições de realização e os prazos entre a autorização e execução dos mesmos, além da adequação entre o tratamento autorizado e o efetivamente realizado e sua dose.  
Relativamente à quimioterapia, excetuando-se a talidomida para o tratamento do mieloma múltiplo, do mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia aguda cromossoma Philadelphia positivo e do trastuzumabe para a quimioterapia do carcinoma de mama inicial e locorregionalmente avançado, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.  
O procedimento da tabela do SUS compatível com quimioterapia do carcinoma da tireoide é o seguinte:  
- Quimioterapia paliativa – adulto - 03.04.02.036-2 - Quimioterapia do carcinoma de tireoide avançado.  
A levotiroxina está na Relação Nacional de Medicamentos Essenciais (Rename), inserida no elenco do Componente Básico da Assistência Farmacêutica. Sua disponibilização é de responsabilidade dos municípios e o acesso dá-se por meio das Unidade Básicas de Saúde ou demais estabelecimentos designados pelas Secretarias Municipais de Saúde.

---

<!-- METADADOS: doenca: Carcinoma Diferenciado da Tireoide | secao: 9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE -->
É obrigatória a informação ao paciente ou ao seu responsável legal, dos potenciais riscos, benefícios e efeitos colaterais relacionados a tratamento preconizado neste Protocolo.  
10. REFERÊNCIAS BIBLIOGRÁFICAS  
1- Sipos JA, Mazzaferri EL. Thyroid cancer epidemiology and prognostic variables. Clinical oncology (Royal College of Radiologists 2010; 22(6): 395-404.  
2- Chen AY, Jemal A, Ward EM. Increasing incidence of differentiated thyroid cancer in the United States, 1988-2005. Cancer 2009; 115(16): 3801-3807.  
3- Colonna M, Bossard N, Guizard AV _, et al._ Descriptive epidemiology of thyroid cancer in France: incidence, mortality and survival. Annales d'endocrinologie 2010; 71(2): 95-101.  
4- Wang Y, Wang W. Increasing Incidence of Thyroid Cancer in Shanghai, China, 1983-2007. Asia-Pacific journal of public health / Asia-Pacific Academic Consortium for Public Health 2012; ahead of pub.  
5- Brito Ados S, Coeli CM, Barbosa Fdos S _, et al._ Estimates of thyroid cancer incidence in Brazil: an approach using polynomial models. Cadernos de saude publica 2011 / Ministerio da Saude, Fundação Oswaldo Cruz, Escola Nacional de Saude Publica; 27(7): 1441-1444.  
22  
6- Brasil. Ministério da Saúde. Secretaria de Assistência à Saúde. Instituto Nacional de Câncer. Estimativa da Incidência de Câncer no Brasil – 2012. Rio de Janeiro. INCA, 2011. 118p.  
7- Cooper DS, Doherty GM, Haugen BR _, et al._ Revised American Thyroid Association management guidelines for patients with thyroid nodules and differentiated thyroid cancer. Thyroid 2009; 19(11): 1167-1214.  
8- Maia AL, Ward LS, Carvalho GA _, et al._ [Thyroid nodules and differentiated thyroid cancer: Brazilian consensus]. Arquivos Brasileiros de Endocrinologia e Metabologia 2007; 51(5): 867-893.  
9- Pacini F, Schlumberger M, Dralle H _, et al._ European consensus for the management of patients with differentiated thyroid carcinoma of the follicular epithelium. European Journal of Endocrinology / European Federation of Endocrine Societies 2006; 154(6): 787-803.  
10- _Aschebrook_ - _Kilfoy B_ , _Ward MH_ , _Sabra MM_ , _et al_ . _Thyroid cancer incidence patterns_ in the _United States_ by _histologic type_ , _1992–2006_ . _Thyroid._ 2011; _21:125–134_ .  
11- Hagag  P, Strauss S, Weiss M. Role of ultrasound-guided fine-needle aspiration biopsy in evaluation of non palpable thyroid nodules.Thyroid. 1998;.8: 989-995.  
12- Pacini f, Castagna MG, Brilli L,Pentheroudakis G. Thyroid cancer: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Annals of Oncology. 2012; 23(suppl 7):117-119.  
13- Vaisman  A, Orlov S, Yip J, Orlov D.  Thyroid Cancer: Latest Approaches to Canada’s Fastest Growing Cancer. _UTMJ.2010; 87(3):161-165._  
14- Pacini F, Vorontsova T, Demidchik EP, et al. Post-Chernobyl thyroid carcinoma in Belarus children and adolescents: comparison with naturally occurring thyroid carcinoma in Italy and France. J Clin Endocrinol Metab.1997;82:(11):3563-3569.  
15- Boelaert  K, Horacek J, Holder RL et al. Serum thyrotropin concentration as a novel predictor of malignancy in thyroid nodules investigated by fine-needle aspiration. J Clin Endo Metab. 2006; 91:.4295-4301.  
16- Gharib H, Papini E,Paschke R. AACE/AME/ETA –Thyroid Nodule Guideline. Endocr Pract. 2010: 16(supl).  
17- Moon W J Jung SL, Lee JH. Benign and Malignant Thyroid Nodules: US Differentiation Multicenter Retrospective Study. Radiology. 2008;247(3):762-770.  
18- Kamran SC, Marqusee E, Kim MI. Thyroid Nodule Size and Prediction of Cancer. J Clin Endocrinol  Metab. 2013; 98;(.2):.564-570.  
19- Jankovic B, Le KT, Hershman JM. Hashimoto’s Thyroiditis and Papillary Thyroid Carcinoma: Is There a Correlation. J Clin Endocrinol  Metab. 2013; 98(2):474-482.  
20- Frates C, Benson CB, Doubilet PM. Prevalence and Distribuition of Carcinoma in Patients with Solitary and Multiple Thyroid Nodules on Sonography. J Clin Endocrinol  Metab. 2006;91(9):3411-3417.  
21- Castro MR, Espiritu RP, Bahn RS. Predictors of Malignancy in Patients with Cytologically Suspicious Thyroid Nodules. Thyroid.2011; 21(11):1191-98.  
22- Gharib H, Papini E, Valcavi R, et al.; AACE/AME Task Force on Endocr Pract. 2006; 12:63102.  
23- Cibas ES, Ali S Z. The Bethesda System for Reporting Thyroid Cytopathology. Thyroid. 2009; 19 (11):1159-1165.  
23  
24- Bongiovanni M, Spitale A, Faquin W. The Bethesda  System for Reporting Thyroid Cytopathology: A meta-Analysis. Acta Cytologica. 2012;56:.333-339.  
25- Coltera MD. Evaluation and imaging of a thyroid nodule. _SurgOncolClinN Am, 2008;17: 3756._  
26- AACE/AME Task Force on Thyroid Nodules. American Association of Clinical Endocrinologist and  Associazione Medici Endocrinologi medical guidelines for clinical practice for thediagnosis and management of thyroid nodules. _EndocrPrac, 2006; 12:63-102)._  
27- Tae HJ, Lim DJ, BaeK KH et al.  Diagnostic. Value of ultrasonography to distinguish between benign and malignant lesions in the management of thyroid nodules.Thyroid 2007;17(5):461-6.  
28- Frates MC, Benson CB, Charboneau JW et al. Management of thyroid nodules detected  at US: Society of Radiologists in Ultrasound consensus conference statement. Radiology 2005;237 (3):794-800.  
29- McCoy KL, Jabbour N, Ogilvie JB et al. The incidence of cancer and rate of false negative cytology in thyroid nodules greater than or equal to 4 cm in size. _Surgery 2007; 142(6): 837-44._  
30- <u>Lee MJ, Kim EK, Kwak JY, Partially cystic thyroid nodules on ultrasound: probability of</u> malignancyandsonographic differentiation.Thyroid. 2009 Apr;19(4):341-6.  
31- Hegedus.L Thyroid ultrasound .EndocrinolMetabolClin North Am, 2001; 30:339-60.  
32- de Camargo RY, Tonimori EK. Usefulness of ultrasound in the diagnosis and management ofwell-differentiated thyroid carcinoma. Arq Bras Endocrinol Metabolism, 2007; 17:1269-76).  
33- Ahuja, AT Ying M, Ho SY, Antonio G, Lee YP, Kingand AD, Wong KT .Ultrasound of malignant cervical lymph nodes. Cancer Imaging. 2008; 8(1): 48.  
34- Biscolla RP Investigação de Linfonodos em Pacientes em Seguimento por Carcinoma Diferenciado de Tireoide Arq Bras EndocrinolMetab 2007;51/5:813-817.  
35- Dessler A, Rapparport Y, Blank A, Marmor S, Weiss J, Graif. Cystic appearance of cervical lymph nodes is characteristic of metastatic papillary thyroid carcinoma. J Clin Ultrasound 2003;1:215.  
36- Kuna S. Ultrasonographic differentiation of benign from malignant neck lymphadenopathy in thyroid cancer.J Ultrasound Med 2006;25:1531-7.  
37- União Internacional Contra o Câncer. TNM – Classificação de Tumores Malignos. Rio de Janeiro. Instituto Nacional de Câncer, 2012. Xxv, 325p. (7ª Edição).  
38- Hundahl SA, Fleming ID, Fremgen AM _, et al._ A National Cancer Data Base report on 53,856 cases of thyroid carcinoma treated in the U.S., 1985-1995. Cancer 1998; 83(12): 2638-2648.  
39- Huang IC, Chou FF, Liu RT _, et al._ Long-term outcomes of distant metastasis from differentiated thyroid carcinoma. Clinical Endocrinology 2012; 76(3): 439-447.  
40-. Grebe SK, Hay ID. Thyroid cancer nodal metastases: biologic significance and therapeutic considerations. Surgical Oncology Clinics of North America 1996; 5(1): 43-63.  
41-. Pelttari H, Sintonen H, Schalin-Jantti C _, et al._ Health-related quality of life in long-term follow-up of patients with cured TNM Stage I or II differentiated thyroid carcinoma. Clinical Endocrinology 2009; 70(3): 493-497.  
42- Smith VA, Sessions RB, Lentsch EJ. Cervical lymph node metastasis and papillary thyroid carcinoma: Does the compartment involved affect survival? Experience from the SEER database. Journal of Surgical Oncology 2012. Ahead of pub.  
24  
43- Tuttle RM, Tala H, Shah J _, et al._ Estimating risk of recurrence in differentiated thyroid cancer after total thyroidectomy and radioactive iodine remnant ablation: using response to therapy variables to modify the initial risk estimates predicted by the new American Thyroid Association staging system. Thyroid 2010; 20(12): 1341-1349.  
44- McLeod DAS, Sawka AM, Cooper DS. Controversies in primary treatment of low –risk papillary thyroid cancer.The Lancet. v.381,p.1046-57,2013).  
45- Bilimoria KY, Bentrem DJ, Ko CY at al. Extent of surgery affects survival for papillary thyroid cancer. Ann Surg. v.246,p.375-381,2007.  
46- Mazzaferri EL  Long-term outcome of patients with differentiated thyroid carcinoma: effect of therapy. Endocr Pract 6:469–476, 2000.  
47- Pacini F, Elisei R, Capezzone M, Miccoli P, Molinaro E, Basolo F, Agate L, Bottici V, Raffaelli M, Pinchera A.  Contralateral papillary thyroid cancer is frequent at completion thyroidectomy with no difference in low- and highrisk patients. Thyroid 11, 2001:877–881.  
48- Kim ES, Kim TY, Koh JM, Kim YI, Hong SJ, Kim WB, Shong YK  Completion thyroidectomy in patients with thyroid cancer who initially underwent unilateral operation. Clin Endocrinol (Oxf ) 61, 2004:145–148.  
49- Pasieka JL, Thompson NW, McLeod MK, Burney RE, Macha M. The incidence of bilateral well-differentiated thyroid cancer found at completion thyroidectomy. World J Surg 16, 1992:711– 716; discussion 716–717.  
50- Kim ES, Kim TY, Koh JM, Kim YI, Hong SJ, Kim WB, Erdem E, Gulcelik MA, Kuru B, Alagol H Comparison of completion thyroidectomy and primary surgery for differentiated thyroid carcinoma. Eur J Surg Oncol 29, 2003: 747–749).  
51- Bonnet S, Hartl DM, Trvagli J.P Lymph node dissection for thyroid câncer . J.Visc Surg.2010;147:155-9.  
52- Gimm O, Rath FW, Dralle H Pattrn of Lymph node metastasis in papillary thyroid carcinoma. Endocrine Reviews, December 2011,32(6):798-826).  
53- Mazzaferri EL. Management of a solitary nodule. N Engl J Med. v. 328, 1993: 353-559).  
54- Tuttle RM, Ball DW, Byrd D .   Thyroid Carcinoma. J Natl Compr Canc Netw. v.8, n.1, 2010:.1228-1274.  
55- Bonnet S, Hartl D, Leboulleu S et al. Prophylactic Lymph Node Dissection for Papilallary Thyroid Cancer Less than 2cm: Implications for Radioiodine Treatment.  J Clinc Endocrinol Metabol. v.94, 2009:.1162-1167.  
56- Zaydfudim V, Feurer ID, Griffin MR, Phay JE. The impact of lymph node involvement on survival in patients with papillary and follicular thyroid carcinoma. Surgery 144, 2008:1070–1077; discussion 1077–1078.  
57- Podnos YD, Smith D, Wagman LD, Ellenhorn JD. The implication of lymph node metastasis on survival in patients with well-differentiated thyroid cancer. Am Surg 71, 2005:731–734.  
58- White ML, Gauger PG, Doherty GM. Central lymph node dissection in differentiated thyroid cancer. World J Surg 31, 2007:895–904.  
59- Gemsenjager E, Perren A, Seifert B, Schuler G, Schweizer I, Heitz PU. Lymph node surgery in papillary thyroid carcinoma. J Am Coll Surg 197, 2003:182–190.  
25  
60- Marilee Carballo1 and Roderick M. Quiros To Treat or Not to Treat: The Role of Adjuvant Radioiodine Therapy in Thyroid Cancer Patients. Journal of Oncology. Volume 2012, Article ID 707156, 11 pages.  
61- Rondeau G, Tuttle RM. Similarities and differences in follicular cell-derived thyroid cancer management guidelines used in Europe and the United States. Seminars in Nuclear Medicine 2011; 41(2): 89-95.  
62- Hyer SL, Newbold K, Harmer CL. Early and late toxicity of radioiodine therapy: detection and management. Endocr Pract 2010; 16(6): 1064-1070.  
63- Sawka AM, Thabane L, Parlea L _, et al._ Second primary malignancy risk after radioactive iodine treatment for thyroid cancer: a systematic review and meta-analysis. Thyroid 2009; 19(5): 451-457.  
64- Muratet JP, Giraud P, Daver A _, et al._ Predicting the efficacy of first iodine-131 treatment in differentiated thyroid carcinoma. J Nucl Med 1997; 38(9): 1362-1368.  
65- Pak H, Gourgiotis L, Chang WI _, et al._ Role of metastasectomy in the management of thyroid carcinoma: the NIH experience. Journal of Surgical Oncology 2003; 82(1): 10-18.  
66- Zettinig G, Fueger BJ, Passler C _, et al._ Long-term follow-up of patients with bone metastases from differentiated thyroid carcinoma -- surgery or conventional therapy? Clinical Endocrinology 2002; 56(3): 377-382.  
67- Rosario PW, Maia FF, Cardoso LD _, et al._ Correlation between cervical uptake and results of postsurgical radioiodine ablation in patients with thyroid carcinoma. Clinical Nuclear Medicine 2004; 29(6): 358-361.  
68- Pacini F, Ladenson PW, Schlumberger M _, et al._ Radioiodine ablation of thyroid remnants after preparation with recombinant human thyrotropin in differentiated thyroid carcinoma: results of an international, randomized, controlled study. The Journal of Clinical Endocrinology and Metabolism 2006; 91(3): 926-932.  
69- Tuttle RM, Brokhin M, Omry G _, et al._ Recombinant human TSH-assisted radioactive iodine remnant ablation achieves short-term clinical recurrence rates similar to those of traditional thyroid hormone withdrawal. J Nucl Med 2008; 49(5): 764-770.  
70- Klubo-Gwiezdzinska J, Burman KD, Van Nostrand D _, et al._ Radioiodine treatment of metastatic thyroid cancMartin Schlumberger, M.D., Bogdan Catargi, M.D., Ph.D., Isabelle Borget, Pharm.D., Ph.D., Désiréeer: relative efficacy and side effect profile of preparation by thyroid hormone withdrawal versus recombinant human thyrotropin. Thyroid 2012; 22(3): 310-317.  
71- Robbins RJ, Driedger A, Magner J. Recombinant human thyrotropin-assisted radioiodine therapy for patients with metastatic thyroid cancer who could not elevate endogenous thyrotropin or be withdrawn from thyroxine. Thyroid 2006; 16(11): 1121-1130.  
72- Rudavsky AZ, Freeman LM. Treatment of scan-negative, thyroglobulin-positive metastatic thyroid cancer using radioiodine 131I and recombinant human thyroid stimulating hormone. The Journal of Clinical Endocrinology and Metabon engl j med 366;18 nejm.org may 3, 2012lism 1997; 82(1): 11-14.  
73- Hans G, Paz-Filho G. Uso do TSH Humano Recombinante no Câncer Diferenciadode Tireóide Arq Bras Endocrinol Metab 2007;51/5.  
74- Luster M, Felbinger R, Dietlein M, Reiners C. Thyroid hormone withdrawal in patients with differentiated thyroid carcinoma: a one hundred thirty-patient pilot survey on consequences of  
26  
hypothyroidism and a pharmacoeconomic comparison to recombinant thyrotropin administration. Thyroid 2005;15:1147-55.  
75- Schlumberger M, Catargi B, Borget I et al.  Strategies of Radioiodine Ablation in Patients with Low-Risk Thyroid Cancer N Engl J Med 366;18 nejm.org may 3, 2012.  
76- BRATS. O uso da Tireotrofina alfa no diagnóstico e acompanhamento do Câncer de tireóide. Brasília-DF. Dezembro de 2008.Disponível em http://www.saude.gov.br/rebrats.  
77- Pluijmen MJ, Eustatia-Rutten C, Goslings BM _, et al._ Effects of low-iodide diet on postsurgical radioiodide ablation therapy in patients with differentiated thyroid carcinoma. Clinical Endocrinology 2003; 58(4): 428-435.  
78- Maxon HR, Thomas SR, Boehringer A, Drilling J, Sperling MI, Sparks JC, et al. Low iodine diet in I-131 ablation of thyroid remnants. Clin Nucl Med 1983;8:123-6.  
79- Morris LF, Wilder MS, Waxman AD, Braunstein GD. Reevaluation of the impact of a stringent low-iodine diet on ablation rates in radioiodine treatment of thyroid carcinoma. Thyroid 2001;11:749-55.  
80- Harjai KJ, Licata AA. Effects of amiodarone on thyroid function. Ann Intern Med 1997;126:63-73.  
81- Barbaro D, Boni G, Meucci G _, et al._ Radioiodine treatment with 30 mCi after recombinant human thyrotropin stimulation in thyroid cancer: effectiveness for postsurgical remnants ablation and possible role of iodine content in L-thyroxine in the outcome of ablation. The Journal of Clinical Endocrinology and Metabolism 2003; 88(9): 4110-4115.  
82- Rosario PW, Reis JS, Barroso AL et al. Efficacy of low and high 131I doses for thyroid remnant ablation in patients with differentiated thyroid carcinoma based on post-operative cervical uptake. Nuclear Medicine Communications 2004; 25(11): 1077-1081.  
83- Alexander EK, Larsen PR. Radioiodine for Thyroid Cancer — Is Less More? N Eng J Med 366;18 nejm.1732 org may 3, 2012.  
84- Qiu ZL, Song HJ, Xu YH _, et al._ Efficacy and survival analysis of 131I therapy for bone metastases from differentiated thyroid cancer. The Journal of Clinical Endocrinology and Metabolism 2011; 96(10): 3078-3086.  
85- Brierley J,Tsang R, Panzarella T, Bana N .Prognostic factors and the effect of treatment with radioiodine and  external beam radiation on patientswith differentiated thyroid cancer seen at a single  institution over 40 years. Clinical Endocrinology 2005,63: 418-27.  
86- Sia MA, Tsang RW, PanzarellaT, Brierkey JD. Differenttiated thyroid câncer and extra thyroidal extension: prognosis and the role of external bean radiotherapy. Journal of Thyroid Research 2010:183461).  
87- Cooper D, Doherty GM, Haugen BR  et al. The American Thyroid Association (ATA) guidelines taskforce on thyroid nodules and differentiated thyroid cancer. Revised American Thyroid Association management guidelines for patients with thyroid nodules and differentiated thyroid cancer.Thyroid vol 79, no. 11, 2009.  
88- Beckery J. Update on external beam radiation therapy in Thyroid cancer  J Clin Endocrinol Metab, August 2011, 96(8):2289–2295.  
89- Schwartz DI, Lobo MJ et a.l. Postoperative external beam radiotherapy for differentiated thyroid cancer: Outcomes and morbidity with conformal treatment.  Int. J. Radiation Oncology biol. Phys., vol. 74, no. 4, pp. 1083–1091, 2009.  
27  
90- Shimaoka K, et al. A randomized trial of doxorubicin versus doxorubicin plus cisplatin in patients with advanced thyroid carcinoma. Cancer, 1985; 56(9):2155-60.  
91- Argiris A, et al. A phase II trial of doxorubicin and interferon alpha 2b in advanced, nonmedullary thyroid cancer. Invest New Drugs, 2008; 26(2):183-8.  
92- Kloos RT, et al. Phase II trial of sorafenib in metastatic thyroid cancer. J Clin Oncol, 2009; 27(10):1675-84.  
93- Chen L, et al. Response to sorafenib at a low dose in patients with radioiodine-refractory pulmonary metastases from papillary thyroid carcinoma. Thyroid, 2011; 21(2):119-24.  
94- Schneider TC, et al. Long-term analysis of the efficacy and tolerability of sorafenib in advanced radio-iodine refractory differentiated thyroid carcinoma: final results of a phase II trial. Eur J Endocrinol, 2012; 167(5):643-50.  
95- Carr LL, et al. Phase II study of daily sunitinib in FDG-PET-positive, iodine-refractory differentiated thyroid cancer and metastatic medullary carcinoma of the thyroid with functional imaging correlation. Clin Cancer Res, 2010; 16(21):5260-8.  
96- Leboulleux S, et al. Vandetanib in locally advanced or metastatic differentiated thyroid cancer: a randomised, double-blind, phase 2 trial. Lancet Oncol, 2012; 13(9):897-905.  
97- Kim K, et al. Clinical Responses to Vemurafenib in Patients with Metastatic Papillary Thyroid Cancer Harboring V600EBRAF Mutation. Thyroid, 2013; [no prelo].  
98- Fatourechi V, Hay ID, Mullan BP _, et al._ Are posttherapy radioiodine scans informative and do they influence subsequent therapy of patients with differentiated thyroid cancer? Thyroid 2000; 10(7): 573-577.  
99- Biondi B, Cooper DS. Benefits of thyrotropin suppression versus the risks of adverse effects in differentiated thyroid cancer. Thyroid 2010; 20(2): 135-146.  
100- Brierley JD. Update on external beam radiation therapy in thyroid cancer. The Journal of Clinical Endocrinology and Metabolism 2011; 96(8): 2289-2295.  
101- Coelho SM, Corbo R, Buescu A _, et al._ Retinoic acid in patients with radioiodine nonresponsive thyroid carcinoma. Journal of Endocrinological Investigation 2004; 27(4): 334-339.  
102- Kebebew E, Lindsay S, Clark OH _, et al._ Results of rosiglitazone therapy in patients with thyroglobulin-positive and radioiodine-negative advanced differentiated thyroid cancer. Thyroid 2009; 19(9): 953-956.  
103- Vaismam F, Momesso DA, Bulzico D, Pessoa, CHCN, Corbo R, Vaisman MRM. Spontaneous remission in thyroid cancer patients after biochemical incomplete response to initial therapy. Clinical Endocrinology (Oxford. Print), v. 76, p. no-no, 2012.  
104- Schlumberger M, Sherman SI. Approach to the patient with advanced differentiated thyroid cancer. European Journal of Endocrinology 2012; 166(1): 5-11.  
28

---

