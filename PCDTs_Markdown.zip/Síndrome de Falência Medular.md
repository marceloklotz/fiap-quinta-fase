<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 23, DE 04 DE NOVEMBRO DE 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Falência Medular.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTA e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE – SUBSTITUTA, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Síndrome de Falência Medular no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 755/2022 e o Relatório de Recomendação nº 758 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Síndrome de Falência Medular.  
Parágrafo único. O Protocolo objeto deste artigo, que contém os conceitos gerais da Síndrome de Falência Medular, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter</u> nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Síndrome de Falência Medular.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 1.300, de 21 de novembro de 2013, publicada no Diário Oficial da União nº 227, de 22 de novembro de 2013, seção 1, páginas 66-68; a Portaria SAS/MS n<sup>o</sup> 113, de 04 de fevereiro de 2016, publicada no Diário Oficial da União nº 25, de 05 de fevereiro de 2016, seção 1, página 95; e a Portaria SAS/MS n<sup>o</sup> 449, de 29 de abril de 2016, publicada no Diário Oficial da União nº 82, de 02 de maio de 2016, seção 1, página 53.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: MARIA INEZ PORDEUS GADELHA -->
ANA PAULA TELES FERREIRA BARRETO

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **1. INTRODUÇÃO** -->
A Síndrome de Falência Medular é um grupo de doenças causadas por dano à Célula-Tronco e Progenitora Hematopoética (CTPH). Clinicamente, essas falências resultam em uma medula óssea hipoplástica e, no sangue periférico, em anemia, neutropenia ou trombocitopenia<sup>1,2</sup> . As condições clínicas mais frequentes de falências medulares são a Anemia Aplástica (AA), a Aplasia Pura de Série Vermelha (APSV) e a Neutropenia Congênita Grave.  
A AA é uma doença rara (com incidência de 1,6 casos novos/milhão de habitantes/ano no Brasil)<sup>3</sup> , caracterizada por uma diminuição das células progenitoras hematopoéticas na medula óssea, hipocelularidade da medula óssea e pancitopenia no sangue periférico<sup>1,2</sup> . O quadro clínico e anatomopatológico final de pancitopenia e uma medula óssea aplástica é o cenário final que pode ser desencadeado por etiologias diversas, incluindo:  
- 1) imune, pela destruição da CTPH por linfócitos T citotóxicos patogênicos;  
- 2) herdada: por defeito nas vias de reparo do DNA (anemia de Fanconi), falha na manutenção do telômero  
(telomeropatias) e alteração no controle transcricional (síndrome da deficiência de GATA2);  
- 3) iatrogênica, por dano direto à CTPH por quimioterapia ou radioterapia<sup>1,2</sup> .  
A apresentação clínica da AA é variável, desde citopenias graves, necessitando de intervenções urgentes até citopenias discretas, não necessitando de tratamento específico. A maioria dos casos de AA é adquirida, sendo as formas hereditárias mais raras. As telomeropatias, a anemia de Fanconi e a síndrome de Blackfan-Diamond são exemplos de falência medular herdada<sup>1,2</sup> .  
Já a APSV é uma síndrome clínica rara, caracterizada por anemia normocítica, normocrômica, reticulocitopenia e diminuição ou ausência de eritroblastos; as outras linhagens, granulocítica e megacariócitica, normalmente estão preservadas. Pode ocorrer por imunodeficiência; infecções virais (ex: HIV e parvovírus B19); doenças linfoproliferativas B e T, uso de medicamentos, de forma idiopática (doença primária), entre outras<sup>4</sup> . As manifestações podem surgir de maneira aguda e autolimitada, sendo mais comumente observada em crianças, e de maneira crônica, mais frequente em adultos. A prevalência da APSV é de 5 casos para cada 1.000.000 de habitantes e a sobrevida é inferior quando comparada à da população em geral<sup>5</sup> .  
A neutropenia congênita grave é composta por um grupo raro de doenças hematológicas, caracterizado por defeito na maturação do setor granulocítico<sup>6</sup> . A prevalência de neutropenia congênita é de 3 a 8 casos para cada 1.000.000 de habitantes e a sobrevida destes pacientes é desconhecida<sup>6</sup> .  
A identificação de fatores de risco e destas doenças em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos das falências medulares. A metodologia de busca e avaliação das evidências está detalhada no **Apêndice 1** . Além disso, o histórico de alterações deste Protocolo encontra-se descrito no **Apêndice 2** .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- D60.0 Aplasia pura de glóbulos vermelhos adquirida crônica  
- D60.1 Aplasia pura de glóbulos vermelhos adquirida transitória  
- D60.8 Outras aplasias puras adquiridas da série vermelha  
- D61.0 Anemia Aplástica Constitucional  
- D61.1 Anemia aplástica induzida por drogas  
- D61.2 Anemia aplástica devida a outros agentes externos  
- D61.3 Anemia aplástica idiopática  
- D61.8 Outras anemias aplásticas especificadas  
- D70 Agranulocitose  
- Z94.8 Outros órgãos e tecidos transplantados

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **3.1. Diagnóstico clínico-laboratorial** -->
O diagnóstico de Anemia Aplástica Imunitária é baseado em critérios clínicos e laboratoriais. Os pacientes apresentam medula óssea hipocelular para a idade e uma ou mais citopenias, caracterizadas por nível de hemoglobina abaixo de 10 g/dL, contagem de neutrófilos abaixo de 1.500/µL ou contagem de plaquetas abaixo de 100.000/µL<sup>8</sup> . A AA imune pode ser classificada em moderada, grave ou muito grave. A AA imune é caracterizada como muito grave caso a contagem de neutrófilos esteja abaixo de 200/µL. Os casos graves são definidos por medula óssea com celularidade menor que 30% e duas ou mais das seguintes citopenias: contagem de reticulócitos abaixo de 60.000/µL, em contagem automatizada, ou abaixo de 20.000/µL, em contagem manual; contagem de neutrófilos abaixo de 500/µL ou contagem de plaquetas abaixo de 20.000/µL. A AA imune muito grave é caracterizada por contagem de neutrófilos abaixo de 200/µL. A AA imune é classificada como moderada quando o paciente apresenta os critérios para a AA mas não preenche os critérios para a AA grave<sup>8</sup> .  
Deve-se suspeitar de AA hereditária quando o paciente apresentar: história familiar de AA, leucemia aguda, síndrome mielodisplásica, citopenias, cirrose hepática criptogênica ou fibrose pulmonar idiopática, acompanhado de alterações fenotípicas, incluindo má formação renal, anormalidades cardíacas, alteração da pigmentação cutânea e alterações esqueléticas e comprimento telomérico curto para idade. O sequenciamento de nova geração tem sido utilizado para auxiliar no diagnóstico de falências medulares congênitas<sup>1</sup> .  
Já o diagnóstico de APSV é feito por meio da observação de: anemia normocítica e normocrômica; reticulocitopenia (habitualmente, contagem de reticulócitos inferior a 10.000/µL); e diminuição ou ausência de eritroblastos na medula óssea (habitualmente, contagem de eritroblastos na medula óssea inferior a 5%)<sup>8</sup> . A contagem de neutrófilos e plaquetas está preservada na APSV<sup>8</sup> . As manifestações clínicas da doença estão relacionadas à anemia ou à doença de base<sup>8</sup> .  
A neutropenia congênita grave é diagnosticada quando a contagem de neutrófilos é inferior a 500/µL, cronicamente. É importante realizar hemogramas seriados (2 vezes por semana durante 3 semanas) para exclusão de neutropenia cíclica. A biópsia de medula óssea comumente demonstra atraso de maturação da série granulocítica, com aumento de promielócitos e mielócitos e diminuição de metamielócitos, bastões e neutrófilos<sup>6</sup> . Nos casos de neutropenia cíclica, em que os pacientes não têm infecções de repetição, preconiza-se acompanhamento clínico<sup>7</sup> . Os casos de neutropenias idiopáticas leves normalmente estão relacionados às neutropenias étnicas e, como estes pacientes não costumam ter sintomas relacionados às neutropenias, devem ser acompanhados clinicamente<sup>9</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **3.2. Diagnóstico diferencial** -->
O diagnóstico diferencial das falências medulares é feito entre causas herdadas e adquiridas, assim como com outras doenças hematológicas que cursam com medula óssea hipocelular, como a síndrome mielodisplástica hipocelular, leucemia mieloide aguda hipocelular ou que cursam com pancitopenia (infiltração da medula óssea, mielofitise).  
É essencial o diagnóstico correto de AA imune para o adequado tratamento clínico, incluindo a definição da gravidade da doença. A AA imune deve ser diferenciada das AA herdadas, sendo necessária a análise de cariótipo para quebra  
cromossômica por meio do teste de diepoxibutano (DEB teste) para pacientes com idade inferior a 50 anos e para pacientes com idade superior a 50 anos com suspeita clínica<sup>8,10</sup> .  
Outro diagnóstico diferencial é a síndrome mielodisplásica hipoplástica. A análise morfológica da medula óssea, demonstrando displasia em setor megacariocítico, fibrose medular ou localização anormal de precursores hematopoéticos associada ao aumento da quantificação de CD34+ por imunofenotipagem corrobora o diagnóstico desta entidade<sup>8,10</sup> .  
A pesquisa de células GPI (glicofosfatidilinusitol) negativa para o diagnóstico de hemoglobinúria paroxística noturna deve ser realizada em todos os pacientes com suspeita de AA adquirida. A presença de pequenos clones de células GPI-negativas não altera o diagnóstico de AA imune nem a escolha do tratamento. Contudo, a presença de clones grandes pode estar associada à hemólise e ao aumento do risco trombótico<sup>8,10</sup> .  
Por fim, diversas doenças podem mimetizar a AA imune, como infecções virais e bacterianas (hepatites, infecção por HIV, micobactérias), deficiências vitamínicas (vitamina B12 e ácido fólico), doenças reumatológicas (lúpus eritematoso sistêmico, artrite reumatoide) e neoplasias sólidas com invasão medular<sup>8,10,11</sup> .  
Para o diagnóstico etiológico de APSV e a escolha do tratamento apropriado, deve-se excluir as causas de APSV secundária, por meio dos seguintes exames: análise do sangue periférico e imunofenotipagem para doenças linfoproliferativas; tomografia computadorizada de tórax para exclusão de timoma; sorologias para parvovírus B19, HIV, hepatite B, hepatite C, EBV e CMV, para identificação de possíveis causas virais; pesquisa de doença autoimune com pesquisa de FAN (fator antinuclear) e fator reumatoide; e realização de biópsia de medula óssea, mielograma e análise citogenética, para exclusão de outras doenças de origem hematopoética, como a síndrome mielodisplásica<sup>4,12</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo todos os pacientes que, na ausência de doenças primárias possivelmente causadoras de falência medular, apresentem medula óssea hipocelular, com diminuição de, pelo menos, um dos elementos hematopoéticos e seus precursores, na ausência de células estranhas à medula óssea, fibrose ou hematofagocitose e um dos diagnósticos a seguir:  
- -anemia aplástica adquirida grave ou muito grave; ou  
-anemia aplástica adquirida moderada e que, no acompanhamento médico, necessitem de transfusão significativa (definida como todo paciente que se apresente ou que se torne dependente de transfusão de hemácias ou plaquetas com uso de repetidas transfusões para manter o nível de hemoglobina maior do que 7 g/dL ou uma contagem de plaquetas acima de 20.000/µL) ou uso frequente de antibióticos devido a episódios de neutropenia febril.  
Também serão incluídos os pacientes com os seguintes diagnósticos clínicos ou moleculares:  
- Neutropenia crônica (constitucional) grave (neutropenia congênita ou idiopática) ou neutropenia cíclica, com contagem  
- de neutrófilos abaixo de 200/mm<sup>3</sup> , ou;  
- APSV idiopática e que não entraram em remissão após um mês, ou;  
- APSV secundária e que não tenham respondido ao tratamento da doença de base ou à retirada do medicamento causador  
- da aplasia por, pelo menos, um mês.  
Para o uso de imunoglobulina humana, o paciente deverá ter diagnóstico de APSV, infecção por parvovírus B19 e estar em tratamento de imunossupressão.  
Para o transplante de células-tronco hematopoéticas (TCTH), serão incluídos pacientes com anemia aplástica adquirida grave ou muito grave e que disponham de doador alogênico aparentado HLA (antígeno de histocompatibilidade) idêntico. Serão elegíveis para o transplante os pacientes com doador identificado e em condições clínicas para o transplante, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou  
contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.  
Além disso, serão excluídos deste Protocolo os pacientes que apresentem uma das condições abaixo:  
- pancitopenia secundária a outras doenças, como doenças reumatológicas em atividade (lúpus eritematoso sistêmico, artrite reumatoide) e infecções virais ativas (HIV, VHB, VHC);  
- deficiência de ácido fólico ou de vitamina B12;  
- uso de medicamentos sabidamente mielotóxicos (metotrexato, cloroquina, entre outros) nos últimos 30 dias;  
- exposição a agentes físicos ou químicos sabidamente mielotóxicos nos últimos 30 dias;  
- invasão medular por células estranhas à medula óssea, como metástases de neoplasias malignas;  
- neoplasias hematológicas identificadas por imunofenotipagem de medula óssea;  
- síndrome mielodisplásica diagnosticada na medula óssea por punção e exame citológico (mielograma/medulograma),  
biópsia e exame histopatológico e cariotipagem;  
- neutropenia étnica benigna;  
- anemia de Blackfan-Diamond.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **6.1. Anemia Aplástica Imune** -->
Casos de pancitopenia que sucedem quadros de infecção, como AA grave após hepatite viral de etiologia não identificada,  
podem ser incluídos, desde que preencham os critérios de gravidade definidos no item 3. Diagnóstico.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Pacientes com Timoma** -->
Em pacientes com diagnóstico de timoma, a incidência de desenvolvimento de APASV é de 5%. Atualmente, preconizase a realização de timectomia nesses casos, com taxas de resposta descritas na literatura de 25%-30%. Alguns trabalhos mostraram que somente a realização da timectomia não é suficiente para o tratamento, sendo necessário o uso de medicamentos imunossupressores. Apesar da limitação dos estudos, preconiza-se o uso de medicamentos imunossupressores nesses casos<sup>12</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Gestação** -->
A APASV adquirida relacionada à gestação é condição extremamente rara. Há relatos de remissão espontânea algumas semanas após o parto. A opção terapêutica deve levar em conta o risco ao feto, ficando a escolha a critério do médico<sup>12</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Pacientes com infecção por parvovírus B19** -->
Alguns estudos observacionais (série de casos) com pacientes infectados cronicamente pelo parvovírus B19 (presença de um pequeno número de proeritroblastos vacuolados gigantes na biópsia de medula óssea; presença de anticorpos anti-B19 IgM no soro ou detecção do DNA viral no soro por técnicas de biologia molecular) sugerem a utilização da imunoglobulina intravenosa nos casos de anemia com concentração de hemoglobina menor do que 7 g/dL e infecção crônica em pacientes imunossuprimidos, demonstrando que o medicamento aparentemente apresenta boas taxas de remissão, porém provoca muitas recidivas. Pela gravidade dessa condição clínica, preconiza-se o uso da imunoglobulina, apesar da fragilidade da evidência encontrada na literatura<sup>12</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Pacientes com APASV secundária ao uso da alfaepoetina humana** -->
Os pacientes que desenvolvem APASV secundária ao uso de alfaepoetina humana devem ter seu tratamento inicial centrado na suspensão do medicamento. Como o mecanismo de desenvolvimento dessa complicação é a formação de anticorpos, fica indicado o uso dos medicamentos imunossupressores nesse cenário clínico<sup>12</sup> .

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.1. Tratamento não medicamentoso** -->
É importante identificar possíveis agentes desencadeadores do quadro de AA, APSV ou neutropenia, como medicamentos, infecções ou agentes químicos ou físicos. Quando presentes, devem ser retirados do contato com o paciente ou tratados, logo que possível.  
A transfusão profilática de plaquetas está indicada quando a contagem de plaquetas estiver abaixo de 10.000/µL ou em casos de aumento do risco de sangramento e contagem de plaquetas inferior a 20.000/µL. Já a transfusão de concentrado de hemácias habitualmente está indicada quando o nível de hemoglobina for inferior a 7,0 g/dL ou quando o paciente apresentar níveis de hemoglobina maiores acompanhados de sinais de hipoxemia. Todos os hemocomponentes devem ser leucorreduzidos e irradiados.  
Diversas meta-análises demonstraram que o transplante de medula óssea e o tratamento imunossupressor podem resultar na mesma sobrevida global<sup>13–15</sup> . Contudo, a idade do paciente influencia muito a performance do TCTH alogênico relacionado, sendo os melhores resultados obtidos para pacientes com idade menor de 40 anos<sup>16,17</sup> . Dessa forma, o TCTH alogênico aparentado idêntico é indicado como primeira linha de tratamento para todos os pacientes com diagnóstico de AA adquirida grave ou muito grave que possuem doador alogênico aparentado HLA (antígeno de histocompatibilidade) idêntico. Para pacientes com idade inferior a 18 anos, o TCTH pode ser realizado com doador alogênico não aparentado HLA idêntico dentro dos três primeiros meses após o diagnóstico<sup>2</sup> .  
Já o tratamento da APSV varia conforme sua etiologia. Durante a avaliação inicial do paciente, um suporte transfusional adequado deverá ser oferecido de acordo com os sintomas secundários à anemia. Nesses casos, em geral, a transfusão de concentrado de hemácias está indicada quando o nível de hemoglobina for inferior a 7,0 g/dL. Todos os hemocomponentes devem ser leucorreduzidos.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.2.1. Anemia Aplástica** -->
Pacientes com AA grave ou muito grave acima de 40 anos, AA grave ou muito grave com qualquer idade sem doador de medula óssea aparentado idêntico ou com AA moderada e necessidade transfusional devem receber terapia imunossupressora combinada, incluindo eltrombopague (EPAG), imunoglobulina antitimocítica (GAT) e ciclosporina. A adição de EPAG ao tratamento imunossupressor está associada à maior taxa de resposta e à maior taxa de resposta completa<sup>18,19</sup> . Pacientes idosos ou com capacidade funcional reduzida devem usar apenas EPAG + ciclosporina.  
A administração da GAT requer atendimento hospitalar e monitorização, uma vez que, dentre as complicações possíveis, estão anafilaxia, febre e infecções graves. Antes da primeira infusão, deve ser realizada dose teste (cutânea ou intravenosa) para verificar reação alérgica ao medicamento. Antes de cada dia de infusão, os pacientes devem receber suporte transfusional com concentrado de plaquetas com intuito de manter a contagem de plaquetas acima de 50.000/µL. Em pacientes com AA adquirida, em análise retrospectiva, não houve diferença na taxa de resposta entre pacientes que utilizaram doses de GAT entre 1,0 a 2,5 mg/kg/dia quando comparado a doses maiores<sup>20</sup> . Atualmente, no mercado brasileiro, apenas a GAT derivada de coelho está disponível.  
Após um primeiro tratamento com EPAG, GAT e ciclosporina, uma segunda dose de GAT pode ser utilizada em casos de recaída hematológica. Para pacientes que realizaram imunossupressão e não tenham apresentado resposta a pelo menos um tratamento com GAT, EPAG e ciclosporina, a realização de TCTH alogênico pode ser considerada.  
O uso de fatores estimuladores de colônias de granulócitos (filgrastim) ou de alfaepoetina não apresenta benefício no tratamento de pacientes com AA imune<sup>1,10</sup> . Nos casos de infecções graves, o uso de filgrastim pode ser considerado como terapia adjuvante ao tratamento antimicrobiano.  
Outros imunossupressores, como sirolimo, micofenolato de mofetila, ciclofosfamida e azatioprina não apresentam superioridade terapêutica quando comparados à ciclosporina<sup>1</sup> . A prednisolona ou prednisona deve ser utilizada apenas no início do tratamento com a GAT como profilaxia de doença do soro, de modo que seu uso para o tratamento da AA não é preconizado<sup>1</sup> . O fluxo de tratamento para pacientes com anemia aplástica deve seguir o descrito na **Figura 1** .  
**Figura 1 -** Fluxograma de tratamento de primeira linha para pacientes com Anemia Aplástica (AA).  
<!-- Start of picture text -->
Pacientes com diagnostico<br>de anemia apstica (AA)<br>Suporte e acompanhamento em<br>servigo de hematologia<br>Possui citéios de<br>incluso?<br>Nao<br>Excuséo0 PDT Possuiexcluso? critérios de<br>sim<br>Paciente sim Paciente possui Nao<br>possul Aiea apesel Tratamentocuporta  de<br>menos de 40 anos) “A arava04 mute | >)“<br>sim Nao |<br>Ha doador HLA No Nao" _/  Paciente é idoso sim Paciente: necessita de Nao<br>isantca na cutemcapaciase )<——_{ Fanstusiesoiicatva<br>familia? funcional reduzida? Beecher<br>sim | sim<br>Transplante de Uso de imunogiobulina | e<br>Medula Ossea anitimocitca + ciciosporina + oereiaaare oe<br>aparentado ettombopague por 6 meses | Pa<br>_ Monitorer<br><!-- End of picture text -->  
HLA – Antígeno de histocompatibilidade; PCDT – Protocolo Clínico e Diretrizes Terapêuticas

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.2.2 Neutropenia** -->
Há consenso internacional quanto à indicação dos fatores estimulantes de linhagem mieloide para tratamento da neutropenia em pacientes com doenças de origem hematopoética, embasados por ensaios clínicos randomizados e meta-análises, em especial na neutropenia crônica grave<sup>21</sup> . Assim, em pacientes com neutropenia congênita grave e neutropenia cíclica, devese utilizar filgrastim, uma vez que o medicamento aumenta o nível de neutrófilos e diminui a taxa de infecção<sup>22</sup> .  
A maioria dos efeitos colaterais relacionados ao uso de filgrastim são leves, sendo o mais comum dor óssea<sup>22,23</sup> . O uso do medicamento também deve considerar a avaliação de risco global do paciente, incluindo contagem de neutrófilos (atual ou prevista); condições relacionadas ao paciente (fatores de risco): idade, presença de comorbidades; condições clínicas significativas, história de radioterapia ou quimioterapia prévias; doença de base; toxicidade do tratamento; e intenção do  
tratamento (curativo ou paliativo)<sup>21</sup> . O fluxo de tratamento para pacientes com neutropenia congênita deve seguir o descrito na **Figura 2** .  
**Figura 2** - Fluxograma de tratamento de neutropenia congênita.  
<!-- Start of picture text -->
Pacientes com diagnéstico de<br>neutropenia congénita<br>‘Suporte e acompanhamento em<br>servico de hematologia<br>Nao sim<br>Possui critérios de<br>incluséo?<br>Sim<br>Exclusado Possui critérios de<br>do PCDT excluséo?<br>| Nao<br>| Filgrastim |<br><!-- End of picture text -->  
PCDT – Protocolo Clínico e Diretrizes Terapêuticas

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.2.3 Aplasia Pura da Série Vermelha** -->
Como pode ocorrer remissão espontânea da doença em curto espaço de tempo, preconiza-se aguardar pelo menos 1 mês antes de se iniciar tratamento imunossupressor específico. Nos pacientes em que não houver melhora com o tratamento da doença de base, preconiza-se a imunossupressão. O tratamento de primeira escolha é prednisona associada a ciclosporina<sup>4,12</sup> .  
Caso não ocorra resposta adequada ao uso de prednisona associada a ciclosporina, pode-se tentar a combinação de prednisona e ciclofosfamida. As respostas a todos os medicamentos atualmente disponíveis para o tratamento da APSV são semelhantes e não existem estudos comparativos que permitam a comparação entre eles. Portanto, a seleção é baseada nos seus perfis de eventos adversos<sup>4,12</sup> .  
Em pacientes refratários ao tratamento de primeira e segunda linha, uma possibilidade terapêutica é a utilização de GAT<sup>4,12</sup> .  
Pacientes com diagnóstico de APSV relacionado à infecção por Parvovírus B19 ou com hipoglobulinemia devem utilizar imunoglobulina humana<sup>4,12</sup> .  O fluxo de tratamento para pacientes com aplasia pura de série vermelha deve seguir o descrito na **Figura 3** .  
**Figura 3** - Fluxograma de tratamento de aplasia pura de série vermelha  
<!-- Start of picture text -->
Pacientes com diagnéstico de<br>aplasia pura da série vermelha<br>‘Suporte e acompanhamento em<br>servico de hematologia<br>Nao sim<br>Possui critérios de<br>incluséo?<br>Exclusio sim Possui critérios de<br>do PCDT exclusao?<br>| Nao<br>Nao<br>Prednisona + ciclosporina INE oS CesOs<br>especiais?<br>sim<br>al Houve resposta<br>adequada? Paciente com parvovirus B19<br>| Nao<br>Prednisona + ciclofostamida Imunoglobulina humana<br>sim Howezesposia | Paciente com timoma<br>adequada?<br>i | Nao Timomectomia<br>Considerar 0 uso de<br>imunoglobulina antitimocitica<br><!-- End of picture text -->  
PCDT – Protocolo Clínico e Diretrizes Terapêuticas

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.3 Medicamentos** -->
- Ciclofosfamida: comprimidos de 50 mg;  
- Ciclosporina:  cápsulas de 10, 25, 50 e 100 mg e solução oral de 100 mg/mL;  
- Eltrombopague olamina: comprimidos de 25 e 50 mg;  
- Filgrastim: solução injetável de 300 mcg;  
- Imunoglobulina antitimócitos humanos (coelho): pó para solução injetável de 25 mg;  
- Imunoglobulina humana: pó para solução injetável ou solução injetável contendo 0,5; 1,0; 2,5 e 5,0 g;  
- Prednisona: comprimidos de 5 e 20 mg.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.4 Esquemas de administração** -->
**Ciclofosfamida** : A dose inicial é de 50 a 100 mg/dia, via oral, podendo ser titulada até dose de 150 mg/dia. A mediana de resposta é de 12 semanas. Caso ocorra resposta, a dose da ciclofosfamida deve ser reduzida paulatinamente, sendo o tempo máximo de tratamento preconizado com ciclofosfamida de 6 meses<sup>25–30</sup> .  
**Ciclosporina** : A dose inicial é de 5 mg/kg/dia, via oral, dividida em duas administrações. O ajuste de dose é baseado na concentração do nadir do medicamento que deve estar entre 150 e 400 ng/mL no tratamento da AA adquirida, caso haja resposta, a dose da ciclosporina deve ser reduzida em 20% consecutivamente, após 180 dias (D+180); após 270 dias (D+270) e após 360 dias (D+360). Em seguida, esta dose deve ser administrada por mais 1 ano, totalizando 2 anos de uso de ciclosporina. Caso não haja resposta em 3 a 6 meses, o medicamento deve ser suspenso. Já no tratamento de APSV, caso haja resposta, a dose da ciclosporina deve ser reduzida paulatinamente.  
**Eltrombopague** : A dose inicial preconizada é de 150 mg/dia para adultos e adolescentes entre 12 e 17 anos. A dose inicial preconizada é de 75 mg/dia para pacientes asiáticos e crianças entre 6 e 11 anos de idade. O medicamento deve ser administrado respeitando-se jejum de 4 horas. Após a administração, deve-se manter o jejum por 2 horas.  
**Filgrastim** : Para tratamento da neutropenia congênita grave, a dose inicial preconizada é de 5 mcg/kg/dia, via subcutânea, podendo ser dividida em duas administrações. A dose final deve ser titulada com aumento de 5 mcg/kg/dia a cada 3 a 5 dias para manter a contagem de neutrófilos acima de 1.000 /µL<sup>24</sup> .  
**Imunoglobulina antitimócitos humanos (coelho)** : Para o tratamento de AA adquirida e APSV, a dose preconizada é de 1 a 5 mg/kg/dia, por 5 dias, com infusão em 12 horas, via acesso venoso central. A dose comumente utilizada é de 2,5 mg/kg/dia, por 5 dias.  
**Imunoglobulina humana** : A dose preconizada é de 400 mg/kg/dia por 5 dias, via endovenosa.  
**Prednisona** : Para o tratamento de AA adquirida, o tratamento deve ser iniciado no dia seguinte ao término da de GAT. A dose inicial de prednisona deve ser 1 mg/kg/dia, via oral, dividida em duas administrações, durante 9 dias. Após este período, se não houver doença do soro, deve-se iniciar o desmame da corticoterapia em 5 a 7 dias. Para o tratamento de APSV, a dose inicial é de 1 mg/kg/dia, via oral, dividida em duas administrações, por até 12 semanas. Caso haja resposta clínica, definida como independência transfusional ou elevação do nível de hemoglobina acima de 10 g/dL, deve ocorrer desmame lento em 3 a 4 meses. Caso não haja resposta, o desmame deve ser rápido em 1 a 2 semanas.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.5.1 Anemia Aplástica** -->
Os pacientes submetidos à imunossupressão com GAT, EPAG e ciclosporina levam de 3 a 6 meses para obter resposta. Após este período, caso não se identifique resposta clínica, o medicamento deve ser suspenso e outro tratamento deve ser considerado. Não há tempo definido de tratamento para AA. O nível sérico de ciclosporina deve ser monitorado semanalmente até a obtenção de nível sérico adequado e, posteriormente, a cada duas a quatro semanas para as consultas com o médico assistente. Para os pacientes que apresentam resposta clínica, a ciclosporina deve ser desmamada lentamente em 18 meses, totalizando 24 meses de tratamento.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.5.2 Neutropenia** -->
Caso pacientes em uso de filgrastim apresentem efeitos adversos, os médicos devem avaliar o risco-benefício do tratamento e, se necessário, interrompê-lo.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **7.5.3 Aplasia pura de série vermelha** -->
Os pacientes submetidos à imunossupressão com ciclosporina ou ciclofosfamida demoram de 3 a 4 meses para obter resposta. Após este período, caso não se identifique resposta clínica, outro tratamento deve ser considerado. O tempo de tratamento varia conforme o medicamento utilizado, idealmente até se obter a remissão da doença. Pacientes com recidivas frequentes podem necessitar de tratamento continuado para manter a remissão. Preconiza-se que o tratamento com imunoglobulina não ultrapasse 5 dias e que o tratamento com ciclofosfamida não ultrapasse 6 meses.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **8.1. Anemia Aplástica** -->
Os pacientes submetidos à imunossupressão com GAT, ciclosporina e EPAG devem ser reavaliados após 6 meses, a fim de verificar sua resposta ao tratamento, por meio de hemograma, contagem de reticulócitos, análise de mielograma, biópsia de medula óssea e análise de cariótipo.  
O nível sérico de ciclosporina deve ser avaliado semanalmente até atingir 150 a 400 ng/mL. Após atingir o nível sérico esperado, caso o paciente permaneça estável, devem ser reavaliados a cada 4 semanas até completar 6 meses de tratamento. Além disso, os pacientes em uso de ciclosporina devem ter o nível sérico de creatinina, ureia, sódio, potássio e magnésio monitorados durante as reavaliações do nível sérico de ciclosporina, visto que o medicamento é nefrotóxico e seu uso está associado à espoliação de magnésio.  
O EPAG pode alterar a função hepática, dessa forma é necessário a monitorização de lesão e função hepática, com dosagem de TGO, TGP, gama glutamil transferase (Gama-GT), fosfatase alcalina e bilirrubinas.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **8.2. Neutropenias** -->
Diversas alterações genéticas, tanto de caráter autossômico como recessivo, estão relacionadas à neutropenia congênita grave, com riscos diferentes de evolução clonal para síndrome mielodisplásica e leucemia mieloide aguda. Alguns grupos internacionais preconizam avaliação do mielograma e cariótipo anualmente.  
O paciente deve realizar hemograma semanalmente até que a contagem de neutrófilos esteja acima de 1.000/µL. Uma vez atingido este nível, a dose de filgrastim deve ser titulada para que o paciente utilize a menor dose terapêutica capaz de manter a contagem de neutrófilos acima de 1000/µL. Quando a contagem de neutrófilos dos pacientes estiver estabilizada, deve-se realizar hemograma a cada 1 a 3 meses para reavaliação.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **8.3. Aplasia Pura de Série Vermelha** -->
Os pacientes submetidos à imunossupressão devem ser monitorizados para possíveis eventos adversos relacionados à terapia imunossupressora. Preconiza-se avaliação mínima com hemograma e contagem de reticulócitos a cada retorno de avaliação.  Outros exames laboratoriais devem ser solicitados conforme a doença de base e a terapia imunossupressora em uso.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de síndrome de falência medular devem ser atendidos em serviços especializados em hematologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes. Os resultados de todos os casos síndrome de falência medular submetidos a TCTH mieloablativo aalogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos 1 (um) ano da realização do transplante.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **11. REFERÊNCIAS** -->
1.  Young NS, Calado RT, Scheinberg P. Current concepts in the pathophysiology and treatment of aplastic anemia.  
Blood. 15 de outubro de 2006;108(8):2509–19.  
2.  Young NS. Aplastic Anemia. N Engl J Med. 25 de outubro de 2018;379(17):1643–56.  
3.  Maluf E, Hamerschlak N, Cavalcanti AB, Júnior ÁA, Eluf-Neto J, Falcão RP, et al. Incidence and risk factors of  
aplastic anemia in Latin American countries: the LATIN case-control study. Haematologica. 2009;94(9):1220–6.  
4.  Gurnari C, Maciejewski JP. How I manage acquired pure red cell aplasia in adults. Blood. 2021;137(15):2001–9.  
5.  Choi Y, Jo J-C, Jeon H, Kim DW, Chang MH, Kim H. Trend and treatment patterns of aplastic anemia in Korea, pure  
red cell aplasia and myelodysplastic syndrome in Korea: a nation-wide analysis. Int J Hematol. 1<sup>o</sup> de outubro de 2017;106(4):500–7.  
6.  Skokowa J, Dale DC, Touw IP, Zeidler C, Welte K. Severe congenital neutropenias. Nat Rev Dis Primers. 8 de junho  
de 2017;3(1):1–18.  
7.  Relatorio_DiretrizesMetodologicas_final.pdf [Internet]. [citado 22 de fevereiro de 2022]. Disponível em:  
http://conitec.gov.br/images/Relatorios/2016/Relatorio_DiretrizesMetodologicas_final.pdf  
8.  Killick SB, Bown N, Cavenagh J, Dokal I, Foukaneli T, Hill A, et al. Guidelines for the diagnosis and management  
of adult aplastic anaemia. British Journal of Haematology. 2016;172(2):187–207.  
9.  Atallah-Yunes SA, Ready A, Newburger PE. Benign Ethnic Neutropenia. Blood Rev. setembro de 2019;37:S0268-  
960X(19)30024-4.  
10. Dror Y, Cada M. Acquired Aplastic Anemia. Em: Kupfer GM, Reaman GH, Smith FO, organizadores. Bone Marrow Failure [Internet]. Cham: Springer International Publishing; 2018 [citado 22 de fevereiro de 2022]. p. 25–55. (Pediatric Oncology). Disponível em: https://doi.org/10.1007/978-3-319-61421-2_2  
11. Keel S, Geddis A. The clinical and laboratory evaluation of patients with suspected hypocellular marrow  
failure. Hematology. 10 de dezembro de 2021;2021(1):134–42.  
12. Means RT Jr. Pure red cell aplasia. Blood. 24 de novembro de 2016;128(21):2504–9.  
13. Peinemann F, Bartel C, Grouven U. First-line allogeneic hematopoietic stem cell transplantation of HLA-  
matched sibling donors compared with first-line ciclosporin and/or antithymocyte or antilymphocyte globulin for acquired severe aplastic anemia. Cochrane Database Syst Rev. 23 de julho de 2013;(7):CD006407.  
14. Peinemann F, Labeit AM. Stem cell transplantation of matched sibling donors compared with immunosuppressive therapy for acquired severe aplastic anaemia: a Cochrane systematic review. BMJ Open. 15 de julho de 2014;4(7):e005039.  
15. Zhu Y, Gao Q, Hu J, Liu X, Guan D, Zhang F. Allo-HSCT compared with immunosuppressive therapy for  
acquired aplastic anemia: a system review and meta-analysis. BMC Immunology. 6 de março de 2020;21(1):10.  
16. Gupta V, Eapen M, Brazauskas R, Carreras J, Aljurf M, Gale RP, et al. Impact of age on outcomes after bone  
marrow transplantation for acquired aplastic anemia using HLA-matched sibling donors. Haematologica. dezembro de 2010;95(12):2119–25.  
17. Bacigalupo A. How I treat acquired aplastic anemia. Blood. 16 de março de 2017;129(11):1428–36.  
18. Peffault de Latour R, Kulasekararaj A, Iacobelli S, Terwel SR, Cook R, Griffin M, et al. Eltrombopag Added  
to Immunosuppression in Severe Aplastic Anemia. N Engl J Med. 6 de janeiro de 2022;386(1):11–23.  
19. Townsley DM, Scheinberg P, Winkler T, Desmond R, Dumitriu B, Rios O, et al. Eltrombopag Added to  
Standard Immunosuppression for Aplastic Anemia. N Engl J Med. 20 de abril de 2017;376(16):1540–50.  
20. Clé DV, Atta EH, Dias DSP, Lima CBL, Bonduel M, Sciuccati G, et al. Rabbit antithymocyte globulin dose  
does not affect response or survival as first-line therapy for acquired aplastic anemia: a multicenter retrospective study. Ann Hematol. novembro de 2018;97(11):2039–46.  
21. PCDT_Anemia_AplasticaMielodisplasiaNeutropenia-Fev2016.pdf [Internet]. [citado 24 de março de 2022]. Disponível em: http://conitec.gov.br/images/Protocolos/PCDT_Anemia_AplasticaMielodisplasiaNeutropenia-Fev2016.pdf  
22. Dale DC, Bonilla MA, Davis MW, Nakanishi AM, Hammond WP, Kurtzberg J, et al. A Randomized  
Controlled Phase III Trial of Recombinant Human Granulocyte Colony-Stimulating Factor (Filgrastim) for Treatment of Severe Chronic Neutropenia. Blood. 15 de maio de 1993;81(10):2496.  
23. Dale DC, Crawford J, Klippel Z, Reiner M, Osslund T, Fan E, et al. A systematic literature review of the  
efficacy, effectiveness, and safety of filgrastim. Support Care Cancer. janeiro de 2018;26(1):7–20.  
24. Connelly JA, Walkovich K. Diagnosis and therapeutic decision-making for the neutropenic patient.  
Hematology. 10 de dezembro de 2021;2021(1):492–503.  
25. Go RS, Li C-Y, Tefferi A, Phyliky RL. Acquired pure red cell aplasia associated with lymphoproliferative  
disease of granular T lymphocytes. Blood. 15 de julho de 2001;98(2):483–5.  
26. Balasubramanian SK, Sadaps M, Thota S, Aly M, Przychodzen BP, Hirsch CM, et al. Rational management  
approach to pure red cell aplasia. Haematologica. fevereiro de 2018;103(2):221–30.  
27. Al-Awami Y, Sears DA, Carrum G, Udden MM, Alter BP, Conlon CL. Pure Red Cell Aplasia Associated  
With Hepatitis C Infection: The American Journal of the Medical Sciences. agosto de 1997;314(2):113–7.  
28. Dhodapkar MV, Lust JA, Phyliky RL. T-Cell Large Granular Lymphocytic Leukemia and Pure Red Cell Aplasia in a Patient With Type I Autoimmune Polyendocrinopathy: Response to Immunosuppressive Therapy. Mayo Clinic Proceedings. novembro de 1994;69(11):1085–8.  
29. Hansen RM, Lerner N, Abrams RA, Patrick CW, Malik MI, Keller R. T-cell chronic lymphocytic leukemia with pure red cell aplasia: Laboratory demonstration of persistent leukemia in spite of apparent complete clinical remission. American Journal of Hematology. 1986;22(1):79–86.  
30. Xiao P-P, Chen X-Y, Dong Z-G, Huang J-M, Wang Q-Q, Chen Y-Q, et al. Treatment for CD57-negative γδ T-cell large granular lymphocytic leukemia with pure red cell aplasia: A case report. WJCC. 16 de setembro de 2021;9(26):7818– 24.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
FILGRASTIM, CICLOFOSFAMIDA, CICLOSPORINA, ELTROMPOBAGUE, IMUNOGLOBULINA ANTITIMÓCITOS HUMANOS (COELHO), IMUNOGLOBULINA HUMANA E PREDNISONA.  
Eu,  
(nome do[a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos, indicados para o tratamento da Síndrome de Falência Medular.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) _____________________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- recuperação das contagens celulares, reduzindo a necessidade de transfusões ou tornando os pacientes independentes de  
transfusões e suas complicações e, em alguns casos, curados da doença;  
- redução no tempo de neutropenia (células brancas reduzidas no sangue);  
- redução na incidência de neutropenia grave;  
- redução no tempo de neutropenia febril;  
- redução dos sintomas clínicos.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Filgrastim e ciclofosfamida: medicamentos classificados na gestação como fator de risco D (há evidências de riscos ao  
- feto, mas um benefício potencial pode ser maior que os riscos).  
- <u>Ciclosporina, imunoglobulina humana, imunoglobulina antitimocítica e prednisona: medicamentos classificados na</u> gestação como fator de risco C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior que os riscos).  
- <u>Eltrombopague: medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram</u>  
- anormalidades e, embora estudos em humanos não tenham sido feitos, o medicamento deve ser prescrito com cautela).  
- Os eventos adversos mais comuns da **filgrastim** são: dor no peito; erupção cutânea; náusea; trombocitopenia; aumento  
- da fosfatase alcalina sérica; tontura, fadiga, dor; dor nas costas, osteoalgia, tosse, dispneia e febre.  
- Os eventos adversos mais comuns da **prednisona** são: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabetes melito.  
- Os eventos adversos mais comuns da **ciclofosfamida** são: diminuição do número de células brancas no sangue, fraqueza, náusea, vômito, infecções da bexiga acompanhada ou não de sangramento, problemas nos rins, no coração, pulmão, queda de cabelos, aumento do risco de desenvolver cânceres.  
- Os eventos adversos mais comuns do medicamento **imunoglobulina humana** são: dor de cabeça, calafrios, febre, reações no local de aplicação da injeção (dor, coceira e vermelhidão); problemas renais (aumento de creatinina e ureia no sangue, seguido de oligúria e anúria, insuficiência renal aguda, necrose tubular aguda, nefropatia tubular proximal, nefrose osmótica).  
- Os eventos adversos mais comuns do medicamento **ciclosporina** são: problemas nos rins e fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, aumento do crescimento da gengiva, aumento do colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células  
brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada a temperatura e aumento das mamas.  
- Os eventos adversos mais comuns do medicamento **Imunoglobulina antitimócitos humanos (coelho)** são: hipertensão, hipotensão, edema periférico, taquicardia; acne vulgar, sudorese, erupção cutânea; hipercalemia, hiperlipidemia, hipocalemia; dor abdominal, constipação, diarreia, náusea, vômito; infecção do trato urinário; anemia, leucocitose, leucopenia, trombocitopenia; doença por citomegalovírus, infecção, sepse; ansiedade, calafrios, dor de cabeça, insônia, mal-estar, dor; artralgia, astenia, dor nas costas, mialgia; dispneia, infecção do trato respiratório inferior, doença pulmonar, infecção do trato respiratório superior; febre.  
- Os eventos adversos mais comuns do medicamento **eltrombopague** são: cefaleia, anemia, diminuição do apetite,  
- insônia, tosse, náusea, diarreia, perda de cabelo, coceira, dor no corpo, febre, cansaço, estado gripal, fraqueza, calafrios e edema periférico. Reações graves observadas foram toxicidade para o fígado e eventos tromboembólicos.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Ciclofosfamida  
- (    ) Ciclosporina  
- (    ) Eltrombopague  
- (    ) Filgrastim  
- (    ) Imunoglobulina antitimócitos humanos (coelho)  
- (    ) Imunoglobulina humana  
- (    ) Prednisona  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice contém o documento de trabalho do grupo desenvolvedor do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Síndrome de Falência Medular, apresentando a descrição da metodologia, as recomendações e o racional para tomada de decisão. Este documento de trabalho tem o objetivo de embasar o texto normativo contido no PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais interessados.  
O público-alvo deste PCDT é de profissionais da saúde envolvidos no atendimento de pacientes com síndrome de falência medular, em especial hematologistas. Ainda, a população-alvo destas recomendações são os pacientes com mais de 18 anos e com diagnóstico de síndrome de falência medular que fazem parte do escopo deste documento.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A atualização desse documento foi iniciada em 19 de maio de 2021, com a realização de uma reunião de escopo, a qual definiu as perguntas de pesquisa deste documento.  
Após a publicação do referido Protocolo por meio da Portaria Conjunta SAES-SCTIE/MS nº 23, de 01 de novembro de 2022, verificou-se um erro de edição no item Esquemas de Administração, envolvendo os medicamentos ciclosporina, imunoglobulina humana e prednisona. Adicionalmente, verificou-se que a descrição do código da CID-10 D60.8 estava equivocada. Os ajustes foram apresentados como informe à Subcomissão Técnica de Avaliação de PCDT à sua 105ª Reunião Ordinária, com encaminhamento de correção do texto disponibilizado.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor deste PCDT foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS).  
As reuniões de escopo e de recomendações contaram com a participação de médicos hematologistas, além de representantes do Ministério da Saúde, hospitais de excelência, sociedades médicas, sociedades sem fins lucrativos e associação de pacientes.  
Este grupo foi responsável pelo julgamento das evidências propostas em resposta às questões da diretriz e das suas respectivas recomendações, além da revisão do documento final.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Conflito de Interesses** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesses, utilizando a  
Declaração de Potenciais Conflitos de Interesses ( **Quadro A** ).  
**Quadro A** - Questionário de conflito de interesses relativos a diretrizes clínico-assistenciais  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente|algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|  
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser a<br>atividade na elaboração ou revisão da diretriz?|fetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de elaboração do PCDT da Síndrome de Falência Medular foi apresentada à 98ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 19 de abril de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação da  
Conitec, com a exclusão dos códigos da CID não especificados e com a inclusão de informações sobre os medicamentos disponibilizados. A proposta foi apresentada aos membros do Plenário da Conitec à sua 108ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **3. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT envolveu a realização de revisões sistemáticas (RS) para as sínteses de evidências e foram adotadas ou adaptadas as recomendações de diretrizes existentes para as tecnologias que se encontram disponíveis no SUS para as respectivas condições.  
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel e um resumo das evidências. Para as tecnologias recomendadas, foram apresentadas justificativas e considerações gerais.  
**QUESTÃO 1:** Devemos utilizar transplante de células tronco hematopoéticas alogênico em primeira linha para Anemia Aplástica Grave (AAG)?  
**Recomendação:** Manteve-se a recomendação de realizar transplante de células tronco hematopoéticas (TCTH) alogênico como primeira linha de tratamento de pacientes com Anemia Aplástica Grave (AAG) no âmbito do SUS (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com anemia aplástica grave imune  
**Intervenção -** TCTH alogênico aparentado HLA-compatível  
**Comparador -** Imunossupressão com ATG equina e ciclosporina  
**Desfechos -** Sobrevida  
**Métodos e resultados da busca:**  
Para realizar a análise de evidências, utilizou-se a estratégia ilustrada no **Quadro B** , com a finalidade de se elaborar uma síntese de evidências atualizadas. Além de consultar as referências citadas, foi realizada a busca bibliográfica nas bases EMBASE, MEDLINE (via Pubmed) e Cochrane até 20 de janeiro de 2022. Foram selecionadas as Revisões Sistemáticas com Meta-análises (RSMAs) e, na ausência destas, os Ensaios Clínicos Randomizados (ECRs).  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan™. A seleção dos estudos foi realizada inicialmente por dois pesquisadores independentes e, posteriormente, as discordâncias foram discutidas com um terceiro pesquisador.  
Considerando que o PDCT anterior incluiu pacientes com diagnóstico de AA imune moderada, durante a busca e análise das referências, esta população foi incluída, complementando-se a população que havia sido definida durante a reunião de escopo para a questão 1.  
**Quadro B** – Descritores utilizados e número de publicações identificadas nas bases de dados consultadas para a síntese de evidências sobre o uso de transplante de células tronco hematopoéticas (TCTH) alogênico em primeira linha para anemia aplástica grave (AAG).  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
|**PUBM**|#1 ("Anemia, Aplastic"[Mesh] OR “Aplastic Anemias” OR “Aplastic|124|
|**ED (Medline)**|Anemia” OR “Aplastic Anaemia” OR “Anaemia, Aplastic” OR “Aplastic||
||Anaemias” OR “Anemia, Hypoplastic” OR “Hypoplastic Anemia” OR||
||“Hypoplastic Anemias” OR “severe aplastic anemia”)||
||#2 ("Hematopoietic Stem Cell Transplantation"[Mesh] OR “Stem Cell||  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
||Transplantation, Hematopoietic” OR “Transplantation, Hematopoietic Stem Cell”<br>OR "Bone Marrow"[Mesh] OR "Hematopoietic Stem Cells"[Mesh] OR “Cell,<br>Hematopoietic Stem” OR “Cells, Hematopoietic Stem” OR “Hematopoietic Stem<br>Cell” OR “Stem Cell, Hematopoietic” OR “Hematopoietic Progenitor Cells” OR<br>“Cell, Hematopoietic Progenitor” OR “Cells, Hematopoietic Progenitor” OR<br>“Hematopoietic Progenitor Cell” OR “Progenitor Cell, Hematopoietic” OR<br>“Progenitor Cells, Hematopoietic” OR “Stem Cells, Hematopoietic” OR “Colony-<br>Forming Units, Hematopoietic” OR “Colony Forming Units, Hematopoietic” OR<br>“Colony-Forming Unit, Hematopoietic” OR “Hematopoietic Colony-Forming<br>Unit” OR “Hematopoietic Colony-Forming Units” OR “Unit, Hematopoietic<br>Colony-Forming” OR “Units, Hematopoietic Colony-Forming”)<br>#3  ("Clinical Trials as Topic"[Mesh] OR "Controlled Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trial"[Publication Type]<br>OR "Clinical Trial"[Publication Type] OR "Randomized Controlled Trials as<br>Topic"[Mesh] OR "Random Allocation"[Mesh] OR "clinical trials as topic"<br>[Mesh] OR "placebo"[tiab] OR "randomly"[tiab] OR "clinical trial"[tiab] OR<br>"double-blind method"[MeSH] OR "double-blind"[tiab] OR "Systematic Reviews<br>as Topic"[Mesh] OR “Systematic Review as Topic” OR “Reviews Systematic as<br>Topic” OR "Systematic Review" [Publication Type] OR "Meta-Analysis"<br>[Publication Type] OR "Meta-Analysis as Topic"[Mesh])<br>#4  #1 AND #2 AND #3<br>Estratégia final:  #4 AND [01-01-2013]/sd NOT [19-01-2022]/sd||
|**Embas**<br>**e**|#1 ('aplastic anemia'/exp OR 'aplastic anemias' OR 'aplastic anemia' OR<br>'aplastic anaemia' OR 'anaemia, aplastic' OR 'aplastic anaemias' OR 'anemia,<br>hypoplastic' OR 'hypoplastic anemia' OR 'hypoplastic anemias' OR 'severe aplastic<br>anemia')<br>#2 ('hematopoietic stem cell transplantation'/exp OR 'haematopoietic stem<br>cell therapy' OR 'haemtopoietic stem cell transplantation' OR 'hematopoietic stem<br>cell (hsc) transplantation' OR 'hematopoietic stem cell therapy' OR 'hsc therapy'<br>OR 'hsc transplantation' OR 'bone marrow'/exp OR 'bone marrow activity' OR<br>'bone marrow matrix' OR 'bone medulla' OR marrow OR 'hematopoietic stem<br>cell'/exp OR 'bone marrow stem cell' OR 'haematopoietic precursor cell' OR<br>'haematopoietic progenitor cell' OR 'haematopoietic stem cell' OR 'haematopoietic<br>stem cells' OR 'hematocytopoietic stem cell' OR 'hematopoietic precursor cell' OR<br>'hematopoietic progenitor cell' OR 'hematopoietic stem cells' OR 'hemocytopoietic<br>stem cell' OR 'hemopoietic stem cell')<br>#3 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-<br>analysis' OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled<br>trial, randomized' OR 'randomised controlled study' OR 'randomised controlled<br>trial' OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,|330|  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
||randomized controlled' OR 'systematic review'/exp) AND [embase]/lim<br>#4 #1 AND #2 AND #3<br>Estratégia final:  #4 AND [01-01-2013]/sd NOT [19-01-2022]/sd||
|**Cochra**<br>**ne Reviews**|#1 MeSH descriptor: [Anemia, Aplastic] explode all trees<br>#2 “Aplastic Anemia” OR “Anaemia, Aplastic” OR “Aplastic Anaemia”<br>OR “Aplastic Anemias” OR “Aplastic Anaemias” OR “Hypoplastic Anemia” OR<br>“Anemia, Hypoplastic” OR “Hypoplastic Anemias”<br>#3 #1 OR #2<br># 4 MeSH descriptor: [Hematopoietic Stem Cell Transplantation] explode<br>all trees<br>#5 “Transplantation, Hematopoietic Stem Cell” OR “Stem Cell<br>Transplantation, Hematopoietic”<br>#6 #4 OR #5<br>#7 MeSH descriptor: [Hematopoietic Stem Cells] explode all trees<br>#8 ("Colony Forming Units, Hematopoietic" OR "Colony-Forming Units,<br>Hematopoietic" OR "Hematopoietic Colony-Forming Units" OR "Colony-<br>Forming Unit, Hematopoietic" OR "Hematopoietic Colony-Forming Unit" OR<br>"Units, Hematopoietic Colony-Forming" OR "Unit, Hematopoietic Colony-<br>Forming" OR "Stem Cells, Hematopoietic" OR "Hematopoietic Progenitor Cells"<br>OR "Cell, Hematopoietic Progenitor" OR "Stem Cell, Hematopoietic" OR<br>"Hematopoietic Stem Cell" OR "Cell, Hematopoietic Stem" OR "Cells,<br>Hematopoietic Progenitor" OR "Progenitor Cells, Hematopoietic" OR "Cells,<br>Hematopoietic Stem" OR "Hematopoietic Progenitor Cell" OR "Progenitor Cell,<br>Hematopoietic")<br>#9 #7 OR #8<br>#10 MeSH descriptor: [Bone Marrow] explode all trees<br>#11 ("Marrow, Bone" OR Marrow OR "Marrow, Red" OR "Red Marrow"<br>OR "Yellow Marrow" OR "Marrow, Yellow")<br>#12 #10 OR #11<br>Estratégia final:  #3 AND #6 AND #9 AND #12|9 Cochrane<br>Reviews<br>3 trials|  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com anemia aplástica imune grave ou moderada  
- (b) Tipo de intervenção: Transplante de células tronco hematopoética (TCTH) alogênico  
- (c) Tipos de estudos: para as bases MEDLINE via Pubmed e Cochrane foram considerados RS ou ECR; estudos  
- observacionais; relato e série de casos. Para a base Embase, RS ou ECR.  
- (d) Desfechos: Sobrevida  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **<u>Resultados da busca</u>** -->
Na intenção de responder à questão sobre TCTH alogênico em primeira linha para AAG, foram recuperadas 466 publicações, sendo excluídas 35 duplicatas. Após triagem por título e resumo, 3 estudos foram lidos na íntegra e nenhum estudo foi incluído. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 1** .  
O primeiro estudo excluído - Zhu _et al_ ., (2020)<sup>1</sup> - é uma meta-análise de 15 estudos retrospectivos. No entanto, optou-se pela exclusão deste artigo porque os dados foram relatados como função logarítmica, o que impossibilitou a conversão de todos os desfechos medidos, não foi possível converter.  
Os demais estudos lidos na íntegra e, também, excluídos (n=2) são revisões sistemáticas que, apesar de não serem duplicatas, são idênticas (mesmo primeiro autor e mesmos resultados)<sup>2,3</sup> . Estes estudos foram excluídos por não apresentarem dados do desfecho de interesse, visto que avaliaram eficácia e os eventos adversos do TCTH alogênico de primeira linha de doadores irmãos compatíveis com antígeno leucocitário humano (HLA) em comparação com terapia imunossupressora de primeira linha.  
**Figura 1** - Fluxograma de seleção dos estudos para análise da recomendação e indicação do transplante de células tronco hematopoéticas (TCTH) alogênico para tratamento em primeira linha de pacientes com anemia aplástica grave (AAG).  
<!-- Start of picture text -->
Identificadas (N=466) Duplicatas removidas Identificadas em — outras<br>EMBASE (n=330) (n=35) fontes (n=0)<br>Medline/Pubmed (n=124)<br>Cochrane (n=12)<br>Rastreadas Excluidas (n=428)<br>(n=431)<br>i Excluidas com justificativa<br>Auséncia de desfechos de<br>Elegiveis (n=3) interesse (n=02)<br>Resultados estatisticos<br>apresentados em log<br><!-- End of picture text -->  
De forma complementar, foram analisadas as referências do PCDT publicado por meio da Portaria SAS/MS nº 1.300, de 21 de novembro de 2013 e relacionadas à questão em análise. Foram selecionados dois estudos. Um dos estudos de Bacigalupo _et al.,_ (2000)<sup>4</sup> não estava disponível nas bases científicas e foi excluído das referências. O segundo estudo, Bacigalupo e Passweg (2009)<sup>5</sup> , propôs critérios para _Diagnóstico e Tratamento da Anemia Aplástica Adquirida_ . Os autores consideraram o transplante como primeira linha de tratamento a pacientes com anemia aplástica severa, em pacientes com até 40 anos, somente quando houvesse disponibilidade de medula de irmão idêntico. No entanto, estes estudos basearam-se em achados não publicados: sobrevida atuarial de 10 anos para pacientes enxertados de irmãos HLA idênticos na última década de, respectivamente, 83%, 73%, 68% e 51% para idades de 1 a 20 (N = 681), 21 a 30 (N = 339), 31 a 40 (N = 146) e 40 anos ou mais (N = 111).

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O TCTH alogênico em primeira linha está associado à resolução das citopenias e melhora da sobrevida em pacientes com AAG. O grupo elaborador optou por manter a recomendação existente no PCDT de Anemia Aplástica Adquirida, publicado por meio da Portaria SAS/MS nº 1.300, de 21 de novembro de 2013.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização de TCTH alogênico em primeira linha é indicada em  
pacientes com AAG, de acordo com os critérios de elegibilidade que serão descritos a seguir:  
Inclusão:  
- pacientes com Anemia Aplástica Adquirida, idade inferior a 40 anos, diagnóstico de AA adquirida grave ou muito grave  
- e que possuem doador alogênico aparentado HLA idêntico (HLA - antígeno de histocompatibilidade);  
Exclusão:  
- pacientes com idade superior a 40 anos;  
- pacientes sem doador alogênico aparentado HLA idêntico  
Contraindicações:  
- não se aplica  
Esquemas de administração e tempos de tratamento:  
- não se aplica  
**QUESTÃO 2:** O eltrombopague associado à terapia imunossupressora padrão (ATG e ciclosporina) é eficaz e seguro no tratamento de pacientes adultos com AA grave, quando comparado à terapia imunossupressora padrão (ATG e ciclosporina) isolada?  
**Recomendação:** Após avaliação pela Conitec, houve recomendação favorável à ampliação de uso de eltrombopague associado à terapia imunossupressora padrão (ATG e ciclosporina) para o tratamento de pacientes adultos com AA grave com indicação de uso no SUS.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **A estrutura PICO para esta pergunta foi:** -->
**População -** Pacientes adultos com anemia aplástica grave imune  
**Intervenção -** Eltrombopague associado à terapia imunossupressora padrão (ATG e ciclosporina)  
**Comparador -** Terapia imunossupressora padrão (ATG e ciclosporina) isolada  
**Desfechos -** Resposta hematológica, sobrevida global, incidência cumulativa de recidiva, sobrevida livre de eventos, qualidade de vida e eventos adversos  
**Métodos e resultados da busca:**  
Para realizar a análise de evidências, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação nº 731/2022, relativo à proposta de ampliação de uso de eltrombopague para o tratamento de pacientes adultos com AAG no âmbito do SUS. Para responder à pergunta estruturada e com base nos critérios estabelecidos na PICO, realizouse uma busca na literatura por artigos científicos, com o objetivo de localizar evidências sobre o tema. As bases de dados, as estratégias de busca e o número das referências localizadas e selecionadas se encontram no **Quadro C** . A busca foi realizada no dia 09/01/2022 e não foram utilizados filtros, tais como idioma ou datas de publicação. Adicionalmente, buscas complementares foram conduzidas em websites de agências de Avaliação de Tecnologias em Saúde (ATS) e instituições correlatas. Mecanismos de busca incluíram adicionalmente Google<sup>®</sup> e outras ferramentas online, buscas manuais de referências bibliográficas e resumos de publicações selecionadas.  
**Quadro C -** Estratégia de busca por evidências científicas nas bases de dados para a síntese de evidências da questão sobre eltrombopague associado à terapia  
imunossupressora padrão (ATG e ciclosporina) no tratamento de pacientes adultos com anemia aplástica grave.  
|**Base**<br>**de dados**||**Termos**|**Publicaçõe**<br>**s**|
|---|---|---|---|
|**PUB**|**#1**("Anemia, Aplastic"[Mesh]|OR "Aplastic Anemia*" OR "Aplastic|44|  
|**Base**<br>**de dados**|**Termos**|**Publicaçõe**<br>**s**|
|---|---|---|
|**MED**<br>**(Medline)**|Anaemia*" OR "Anaemia, Aplastic" OR "Anemia, Hypoplastic" OR "Hypoplastic<br>Anemia*" OR "severe aplastic anemia")<br>**#2**("eltrombopag" [Supplementary Concept] OR "eltrombopag" OR<br>"Revolade" OR "SB-497 115" OR "Promacta")<br>**#3**("Cyclosporine"[Mesh] OR Cyclosporine OR "Cyclosporine" OR<br>"Cyclosporine A" OR "Cyclosporin A" OR "Ciclosporin" OR "Cyclosporin" OR<br>"Neoral" OR "Sandimmun Neoral" OR "CyA-NOF" OR "CyA NOF" OR<br>"Sandimmune" OR "Sandimmun" OR "CsA-Neoral" OR "CsA Neoral" OR<br>"CsANeoral" OR "OL 27-400" OR "OL 27 400" OR "OL 27400" OR<br>"immunosuppressive therapy" OR "immunosuppressive agentes")<br>**#4**("Antilymphocyte Serum"[Mesh] OR "Antilymphocyte Serum" OR<br>"Antilymphocyte<br>Serums"<br>OR<br>"Serum,<br>Antilymphocyte"<br>OR<br>"Serums,<br>Antilymphocyte" OR "Antilymphocyte Antibodies" OR "Antibodies, Antilymphocyte"<br>OR<br>"Antibody,<br>Antilymphocyte"<br>OR<br>"Antilymphocyte<br>Antibody"<br>OR<br>"Antilymphocyte Globulin" OR "Antilymphocyte Globulins" OR "Globulin,<br>Antilymphocyte" OR "Globulins, Antilymphocyte" OR "Pressimmune" OR<br>"Antithymoglobulin" OR "Antithymoglobulins" OR "Antithymocyte Globulin" OR<br>"Antithymocyte Globulins" OR "Globulin, Antithymocyte" OR "Globulins,<br>Antithymocyte" OR "Lymphocyte Immune Globulin, Anti-Thymocyte Globulin" OR<br>"Lymphocyte Immune Globulin, Anti Thymocyte Globulin" OR "Anti-Thymocyte<br>Globulin" OR "Anti Thymocyte Globulin" OR "Anti-Thymocyte Globulins" OR<br>"Globulin, Anti-Thymocyte" OR "Globulins, Anti-Thymocyte" OR "ATGAM" OR<br>"Lymphocyte Immune Globulin, Anti-Thymocyte Globulin (Equine) " OR<br>"Lymphocytotoxic Antibodies" OR "Antibodies, Lymphocytotoxic" OR "Antibody,<br>Lymphocytotoxic"<br>OR<br>"Lymphocytotoxic<br>Antibody"<br>OR<br>"Antilymphoblast<br>Globulins" OR "Antilymphoblast Globulin" OR "Globulin, Antilymphoblast" OR<br>"Globulins,<br>Antilymphoblast"<br>OR<br>"Antilymphocyte<br>Immunoglobulin"<br>OR<br>"Antilymphocyte Immunoglobulins" OR "Immunoglobulin, Antilymphocyte" OR<br>"Immunoglobulins, Antilymphocyte")<br>Estratégia final #1 AND #2 AND #3 AND #4||
|**Emba**<br>**se**|**#1**('aplastic anemia'/exp OR 'aplastic anemia*' OR 'aplastic anaemia*' OR<br>'anaemia, aplastic' OR 'anemia, hypoplastic' OR 'hypoplastic anemia*’ OR ‘severe<br>aplastic anemia’)<br>**#2**(eltrombopag OR Revolade OR ‘SB-497 115’ OR Promacta)<br>**#3**(‘cyclosporine’/exp OR ‘cyclosporine A’ OR ‘cyclosporin A’ OR ciclosporin<br>OR cyclosporin OR ‘immunosuppressive therapy’)<br>**#4**('lymphocyte antibody'/exp OR 'antilymphocyte serum' OR 'globulin,<br>antilymphocyte' OR 'globulins, antilymphocyte' OR 'globulin, antithymocyte' OR<br>'globulins, antithymocyte' OR atgam OR 'immunoglobulin*, antilymphocyte' OR 'anti-<br>thymocyte globulin*' OR 'anti thymocyte globulin')|103|  
|**Base**<br>**de dados**|**Termos**|**Publicaçõe**<br>**s**|
|---|---|---|
||Estratégia Final**#1 AND #2 AND #3 AND #4**||
|**Cochr**<br>**ane Reviews**|**#1**MeSH descriptor: [Anemia, Aplastic] explode all trees<br>**#2**('aplastic anemia' OR 'aplastic anemias' OR 'aplastic anemia' OR 'aplastic<br>anaemia' OR 'anaemia, aplastic' OR 'aplastic anaemias' OR 'anemia, hypoplastic' OR<br>'hypoplastic anemia' OR 'hypoplastic anemias')<br>**#3**eltrombopag OR Revolade OR ‘SB-497 115’ OR Promacta<br>**#4**#1 OR #2|38|
||**#5**4 AND #3||
||Estratégia Final**Somente trials**||  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com AAG imune  
- (b) Tipo de intervenção: Eltrombopague associado à terapia imunossupressora padrão (ATG e ciclosporina)  
- (c) Tipos de estudos: RS (com e sem meta-análise) e ECRs.  
- (d) Desfechos: Resposta hematológica, sobrevida global, incidência cumulativa de recidiva, sobrevida livre de eventos,  
- qualidade de vida e eventos adversos  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **<u>Resultados da busca</u>** -->
Como resultado das buscas realizadas nas bases de dados selecionadas, foram encontradas 312 publicações, incluindo-se duplicatas. Dois revisores, aplicando-se os critérios de elegibilidade, selecionaram inicialmente oito publicações para leitura na íntegra e destas, apenas uma foi selecionada e incluída nesta revisão. A **Figura 2** apresenta o fluxograma de seleção de estudos de eficácia e segurança.  
**Figura 2** - Fluxograma de seleção dos estudos incluídos.  
<!-- Start of picture text -->
Identificadas (N=312) Duplicatas removidas Identificadas em  outras<br>EMBASE (n=44) (n=58) fontes (n=2)<br>Medline/PubmedCochrane (n=38) (n=230) |<br>Rastreadas Excluidas (n=248) Rastreadas (n=2)<br>(n=254)<br>J Excluidas com justificativa<br>Elegiveis (n=6) Elegiveis (n=1)<br>(n=6) Populacao divergente i<br>PICO (n = 2)<br>Sem grupo comparador (n Excluidas com justificativa<br>=2) Intervengdo e comparador<br>Intervencao e comparador divergentes a PICO (n =1)<br>divergentes a PICO (n = 2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resumo das evidências:** -->
Foi incluído um único estudo - estudo RACE<sup>6</sup> . Trata-se de ensaio clínico de fase III, multicêntrico, randomizado, prospectivo, aberto, comparando ATG de cavalo mais ciclosporina (terapia imunossupressora padrão) com ou sem EPAG em pacientes com AA grave ou muito grave. Foram submetidos à triagem 285 pacientes com 15 anos de idade ou mais, que tiveram um diagnóstico de AA grave ou muito grave adquirida, não elegíveis para o transplante de células-tronco hematopoéticas. Destes pacientes, 197 pacientes tiveram seus resultados apresentados. O tempo médio de seguimento dos pacientes em ambos os grupos foi de 24 meses (IC95%: 23 a 24). A randomização foi estratificada de acordo com a idade (entre 15 e 40 anos ou a partir de 40 anos), gravidade da doença (grave ou muito grave) e local do estudo. No Grupo A – grupo comparador (N=101), os pacientes foram designados para receber terapia imunossupressora (ATG 40 mg/kg/dia por quatro dias consecutivos e ciclosporina, administrada por via oral em uma dose de 5 mg/kg/dia a partir do dia 1 por um mínimo de 12 meses). Já os pacientes do Grupo B – grupo intervenção (N=96) receberam a terapia imunossupressora mais EPAG, administrado por via oral em uma dose de 150 mg/dia desde o dia 14 até completarem três meses ou seis meses.  
O desfecho primário foi resposta hematológica completa. A proporção de pacientes com resposta completa em três meses e seis meses foi de 10% no Grupo comparador (Grupo A) e 22%, no Grupo intervenção (Grupo B) (OR combinado = 3,2 [IC95%: 1,3 a 7,8; p=0,01]), representando uma diferença significativa entre os grupos. A sobrevida global em dois anos foi semelhante no Grupo A (85%; IC95%: 78% a 92%) e Grupo B (90%; IC95%: 82% a 97%). A incidência cumulativa de recidiva em 18 meses após a resposta não diferiu significativamente entre o Grupo A (11%; IC95%: 2% a 20%) e Grupo B (19%; IC95%: 9% a 29%). Em dois anos, mais eventos ocorreram no Grupo A do que no Grupo B, resultando em uma sobrevida livre de eventos inferior no Grupo A (34%; IC95%: 24% a 44%) do que no Grupo B (46%; IC95%: 36% a 57%).  
A qualidade de vida (desfecho relatado pelo paciente) foi avaliada com o uso do questionário da _European Organization for Research and Treatment of Cancer_ (EORTC), aplicado no início do estudo e seis, 12 e 24 meses após a randomização. As pontuações melhoraram desde a linha de base ao longo do tempo em relação ao estado de saúde global, bem como nas escalas física, social e emocional, com diferenças mínimas entre os grupos. A incidência de todos os eventos adversos, incluindo complicações infecciosas e hepáticas, foi semelhante nos dois grupos. A incidência cumulativa de hemoglobinúria paroxística noturna (HPN) em 24 meses foi de 7% no Grupo A e 1% no Grupo B. A introdução de EPAG para o tratamento da forma grave da doença (AAG), em pacientes não elegíveis ao transplante de células-tronco hematopoéticas (TCTH) alogênico, trouxe resultados relevantes com taxa de resposta global significativamente superior, melhorando a necessidade de tratamentos agressivos e melhoria na qualidade de vida dos pacientes.  
**QUESTÃO 3:** Devemos utilizar o fator estimulador de granulócitos no tratamento de neutropenias constitucionais (NC)?  
**Recomendação:** Manteve-se a recomendação de utilizar o fator estimulador de granulócitos no tratamento de neutropenias constitucionais no âmbito do SUS (recomendação não graduada).  
**A estrutura PICO para esta pergunta foi:**  
**População -** Pacientes com Neutropenias Constitucionais  
**Intervenção -** G-CSF Fator estimulador de granulócitos  
**Comparador -** Suporte Transfusional  
**Desfechos -** Incidência de Infecções e sobrevida  
**Métodos e resultados da busca:**  
Para a tomada de decisão, foram consideradas as evidências incluídas no PCDT de Anemia Aplástica Adquirida (publicado por meio da Portaria SAS/MS nº 1.300, de 21 de novembro de 2013), e, adicionalmente, foi estruturada e realizada uma busca para localizar as novas evidências acerca da questão. Com base na pergunta PICO estruturada, foram realizadas buscas nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 20 de janeiro de 2022. As estratégias de busca estão  
descritas no **Quadro D** . Foram selecionados todos os tipos de estudos para as bases MEDLINE via Pubmed e Cochrane, e aplicou-se um filtro de RS ou ECR para Embase.  
Os resultados dessas bases foram exportados para a base RAYYAN<sup>®</sup> , permitindo que dois observadores independentes fizessem a avaliação dos artigos encontrados, sendo que as divergências foram posteriormente resolvidas, após a abertura do cegamento, em reunião presencial, e um terceiro pesquisador serviu para auxiliar em casos específicos.  
**Quadro D -** Estratégias de busca, de acordo com a base de dados, para identificação de estudos sobre o uso de fator estimulador de granulócitos no tratamento de neutropenias constitucionais (NC).  
|**Base**<br>**de dados**|**Termos**|**Publicaçõe**<br>**s**|
|---|---|---|
|**PUB**|#1 (“Neutropenia”[Mesh] OR Neutropenia OR “constitutional neutropenia”)|392|
|**MED**|#2 ("Colony-Stimulating Factors"[Mesh] OR "Colony Stimulating Factors" OR||
|**(Medline)**|"Colony-Stimulating Factor" OR "MGI-1 Protein" OR "MGI 1 Protein" OR "Myeloid<br>Cell-Growth Inducer" OR "Cell-Growth Inducer, Myeloid" OR "Inducer, Myeloid<br>Cell-Growth" OR "Myeloid Cell Growth Inducer" OR "Colony Stimulating Factor<br>MGI-1" OR "Macrophage-Granulocyte Inducer" OR "Inducer, Macrophage-<br>Granulocyte" OR "Macrophage Granulocyte Inducer" OR "Protein Inducer MGI" OR<br>"MGI, Protein Inducer" OR "Filgrastim"[Mesh] OR “Recombinant-Methionyl Human<br>Granulocyte Colony-Stimulating Factor” OR “Recombinant Methionyl Human<br>Granulocyte Colony Stimulating Factor” OR “G-CSF Recombinant, Human<br>Methionyl” OR “G CSF Recombinant, Human Methionyl” OR  “R-metHuG-CSF”<br>OR “R metHuG CSF” OR Zarxio OR “Filgrastim-sndz” OR “Tbo-Filgrastim”<br>OR “Tbo Filgrastim” OR Granix OR Topneuter OR Neupogen)<br>#3 ("Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR "Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR "clinical trials as topic" [Mesh] OR "placebo"[tiab]<br>OR "randomly"[tiab] OR "clinical trial"[tiab] OR "double-blind method"[MeSH] OR<br>"double-blind"[tiab] OR "Systematic Reviews as Topic"[Mesh] OR “Systematic<br>Review as Topic” OR “Reviews Systematic as Topic” OR "Systematic Review"<br>[Publication Type] OR "Meta-Analysis" [Publication Type] OR "Meta-Analysis as<br>Topic"[Mesh])<br>#4 #1 AND #2 AND #3<br>Estratégia final:  #4 Filters applied: from 2013/1/1 - 2022/1/20||
|**Emba**<br>**se**|#1 ('neutropenia'/exp OR 'cyclic neutropaenia' OR 'cyclic neutropenia' OR<br>neutropaenia OR 'constitutional neutropenia')<br>#2 ('colony stimulating factor'/exp OR 'colony stimulating activity' OR 'colony<br>stimulating factors' OR 'colony-stimulating factors')<br>#3 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-<br>analysis' OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial' OR<br>'randomized controlled study' OR 'randomized controlled trial' OR 'trial, randomized|103|  
|**Base**<br>**de dados**|**Termos**|**Publicaçõe**<br>**s**|
|---|---|---|
||controlled' OR 'systematic review'/exp) AND [embase]/lim<br>#4  #1 AND #2 AND #3<br>Estratégia final:   #4 AND [01-01-2013]/sd NOT [19-01-2022]/sd||
|**Cochr**<br>**ane Reviews**|#1 MeSH descriptor: [Neutropenia] explode all trees<br>#2 Neutropenias<br>#3 #1 OR #2|6 Cochrane<br>Reviews<br>10 trials|
||#4 MeSH descriptor: [Granulocyte Colony-Stimulating Factor] explode all trees<br>#5 (G-CSF OR Filgrastim)<br>#6 #4 OR #5<br>#7 MeSH descriptor: [Blood Transfusion] explode all trees<br>#8 (“Blood Transfusions” OR “Transfusions, Blood” OR “Transfusion, Blood”)<br>#9 #7 OR #8<br>Estratégia final:  #3 AND #6 AND #9||  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com neutropenias constitucionais  
- (b) Tipo de intervenção: Tratamento com fator estimulador de granulócitos - G-CSF  
- (c) Tipos de estudos: para as bases MEDLINE via Pubmed e Cochrane foram considerados RS ou ECR; estudos  
- observacionais; relato e série de casos. Para a base Embase, RS ou ECR.  
- (d) Desfechos: Incidência de Infecções; sobrevida  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **<u>Resultados da busca</u>** -->
Após busca nas bases de dados, 511 publicações foram recuperadas, das quais 45 tratavam-se de duplicatas. Após triagem por título e resumo, duas foram lidas na íntegra e o estudo de Bongiovanni _et al_ ., (2019)<sup>7</sup> foi excluído por não apresentar dados que pudessem ser analisados. A meta-análise de Dale _et al.,_ (2018)<sup>8</sup> , lida na íntegra, foi o segundo estudo excluído por não apresentar desfechos não especificados para a população avaliada. Ao final, foi incluído 1 estudo identificado por outros métodos - referência de artigo do mesmo autor excluído da pesquisa (Dale _et al_ ., 2018)<sup>8</sup> .  O resultado de cada etapa do processo de seleção é apresentado na **Figura 3** .  
**Figura 3** - Fluxograma de seleção dos estudos incluídos para a PICO sobre fator estimulador de granulócitos no tratamento de neutropenias constitucionais (NC).  
<!-- Start of picture text -->
Identificadas (N=511) Duplicatas removidas Identificadas em — outras<br>EMBASE (n=392) (n=45) fontes (n=1)<br>CochraneMedline/Pubmed (n=16) (n=103) |<br>(n=467)<br>J Excluidas com justificativa<br>wa Dados no disponivels<br>(n=1)<br>Pela forma de<br>apresentagao dos<br>desfechos, populagdo nao<br>atende aos critérios da<br>PICO (n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resumo das evidências:** -->
O estudo de Dale _et al.,_ (1993)<sup>9</sup> subsidiou a elaboração do PCDT anterior, sendo a única publicação adicionada à busca e incluída na análise de evidências. Trata-se de um ECR, fase III, que incluiu 123 pacientes com infecções recorrentes e neutropenia crônica grave (contagem absoluta de neutrófilos menor que 0,5 × 10<sup>9</sup> /L), sendo 120 pacientes em uso do filgrastim. O estudo teve como objetivo determinar a capacidade do filgrastim em aumentar a mediana de contagem absoluta de neutrófilos (ANCs) dos pacientes com neutropenia crônica grave. O estudo apresentou três braços, sendo eles: Grupo A (n=62) composto por pacientes que iniciaram a terapia com filgrastim com um período de equilíbrio de dose de 1 mês para determinar a dose ideal necessária para atingir um ANC ≥ 1,5 × 10<sup>9</sup> /L, seguido por um período de tratamento de 4 meses; Grupo B (n=60), pacientes que iniciaram um período de observação de 4 meses e não receberam tratamento com filgrastim durante esse período; Grupo BX (n=58), pacientes do grupo B após a conclusão do período de observação que receberam terapia com filgrastim, conforme definido para pacientes do grupo A, começando com o período de equilíbrio de dose de 1 mês, seguido pelo período de tratamento de 4 meses(17).  
O estudo de Dale _et al_ ., (1993)<sup>9</sup> apresentou os seguintes resultados para mediana de contagem absoluta de neutrófilos (ANCs): 6,10 (0,03-19,44; p≤0,001) no grupo A; 0,21 (0,00-1,55) no grupo B e 8,67 (0,36-30,88; p≤0,001) no grupo BX. O tratamento com filgrastim resultou em um aumento superior a 16 vezes em ANCs para todos os diagnósticos nos grupos A e BX. Um objetivo secundário deste estudo foi determinar os efeitos do tratamento na incidência de eventos relacionados a infecções (número mediano) e os resultados foram: 0,20 (p≤0,001) no grupo A; 0,50 no grupo B e 0,33 (p≤0,05) no grupo BX. Desta maneira, os eventos relacionados à infecção foram significativamente reduzidos. Não foram apresentados resultados relacionados à sobrevida nem os valores de p referentes ao grupo B. Dentre os efeitos do uso do filgrastim, observou-se o aumento assintomático do baço (sem dados estatísticos). Os eventos adversos frequentemente relatados foram dor óssea, dor de cabeça e erupção cutânea, que foram geralmente leves e facilmente controláveis (sem dados estatísticos que pudessem relacionar frequência).

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por manter a recomendação publicada por meio da Portaria SAS/MS nº 113, de 4 de fevereiro de 2016 para pacientes com neutropenia crônica (constitucional) grave (neutropenia congênita ou idiopática) e neutropenia cíclica.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização de filgrastim é indicada em pacientes com NC, de  
acordo com os critérios de elegibilidade que serão descritos a seguir:  
Inclusão:  
- Pacientes (crianças, adolescentes e adultos) com diagnóstico de neutropenia crônica (constitucional) grave (neutropenia  
congênita ou idiopática) ou neutropenia cíclica, com contagem de neutrófilos abaixo de 200/mm<sup>3</sup> .  
- Exclusão:  
- Pacientes com hipersensibilidade conhecida ao filgrastim ou a qualquer componente da formulação.  
- Contraindicações:  
- Não deve ser usado durante a gestação ou lactação.  
Cuidados especiais:  
- Recomenda-se suspender o uso de filgrastim em caso de leucocitose (contagem de leucócitos superior a 10.000/mm<sup>3</sup> ).  
Nas condições em que não se prevê recuperação medular, como nas neutropenias congênitas e nas mielodisplasias, preconiza-se o uso da menor dose possível para manter a contagem de neutrófilos superior a 500/mm<sup>3</sup> .  
Esquemas de administração e tempos de tratamento:  
- A dose inicial recomendada é de 5 mcg/kg/dia, por via subcutânea, podendo ser dividida em duas administrações. A  
dose final deve ser titulada com aumento de 5 mcg/kg/dia a cada 3 a 5 dias para manter a contagem de neutrófilos acima de 1.000/µL.  
**QUESTÃO 4:** Devemos utilizar imunossupressão em primeira linha para tratamento de Aplasia Pura Adquirida Crônica  
de Série Vermelha (APSV)?  
**Recomendação:** Manteve-se a recomendação de utilizar imunossupressão em primeira linha para tratamento de Aplasia  
Pura Adquirida Crônica de Série Vermelha (APSV) no âmbito do SUS (recomendação não graduada).  
**A estrutura PICO para esta pergunta foi:**  
**População -** Pacientes com aplasia pura adquirida crônica de série vermelha - APSV  
**Intervenção -** Ciclosporina e Corticoides  
**Comparador -** Suporte Transfusional  
**Desfechos -** Resposta hematológica  
**Métodos e resultados da busca:**  
Com base na pergunta PICO estruturada, foram realizadas buscas nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 20 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro E** .  
Os resultados dessas bases foram exportados para a base RAYYAN<sup>®</sup> , permitindo que dois observadores independentes fizessem a avaliação dos artigos encontrados, sendo que as divergências foram posteriormente resolvidas, após a abertura do cegamento, em reunião presencial, e um terceiro pesquisador serviu para auxiliar em casos específicos.  
**Quadro E -** Estratégias de busca, de acordo com a base de dados, para identificação de estudos sobre o uso de imunossupressão em primeira linha para tratamento de aplasia pura adquirida crônica de série vermelha (APSV).  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
|**PUB**|#1 ("Red-Cell Aplasia, Pure"[Mesh] OR “Red Cell Aplasia, Pure” OR “Pure|99|
|**MED**|Red-Cell Aplasia” OR “Aplasia, Pure Red-Cell” OR “Pure Red Cell Aplasia” OR||
|**(Medline)**|“Pure Red-Cell Aplasias” OR “Red-Cell Aplasias, Pure” OR “Aplasia Pure Red Cell”||  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
||OR “Erythrocyte Aplasia” OR “Aplasia, Erythrocyte” OR “Aplasias, Erythrocyte”<br>OR “Erythrocyte Aplasias”)<br>#2<br>("Cyclosporine"[Mesh]<br>OR<br>Cyclosporine<br>OR<br>Cyclosporin<br>OR<br>"Cyclosporine A" OR "Cyclosporin A" OR Ciclosporin OR Cyclosporin OR Neoral<br>OR "Sandimmun Neoral" OR CyA-NOF OR "CyA NOF" OR Sandimmune OR<br>Sandimmun OR CsA-Neoral OR "CsA Neoral" OR CsANeoral OR "OL 27-400" OR<br>"OL 27 400" OR "OL 27400" OR "immunosuppressive therapy" OR<br>"immunosuppressive agents")<br>#3 ("Adrenal Cortex Hormones"[Mesh] OR “Hormones, Adrenal Cortex” OR<br>Corticosteroids OR Corticosteroid OR Corticoids OR Corticoid OR “Adrenal Cortex<br>Hormone” OR “Cortex Hormone, Adrenal” OR “Hormone, Adrenal Cortex”)<br>Estratégia final:  #1 AND #2 AND #3||
|**Emba**<br>**se**|#1 ('pure red cell anemia'/exp OR 'aplasia, erythrocyte' OR 'erythrocyte aplasia'<br>OR 'erythrocyte aplasia, pure' OR 'erythroid aplasia' OR 'pure red cell anaemia' OR<br>'pure red cell aplasia' OR 'pure red-cell aplasia' OR 'red cell aplasia' OR 'red cell<br>aplasia, pure' OR 'red-cell aplasia, pure')<br>#2 ('cyclosporine'/exp OR 'adi 628' OR adi628 OR cequa OR 'cgc 1072' OR<br>cgc1072 OR ciclomulsion OR cicloral OR ciclosporin OR 'ciclosporin a' OR<br>ciclosporine OR cipol OR 'cipol n' OR consupren OR cyclasol OR cyclokat OR<br>cyclosporin OR 'cyclosporin a' OR 'cyclosporin neoral' OR 'cyclosporine a' OR 'de<br>076' OR de076 OR deximune OR equoral OR gengraf OR ikervis OR iminoral OR<br>implanta OR imusporin OR 'lx 201' OR lx201 OR 'mc2 03' OR mc203 OR 'mtd 202'<br>OR mtd202 OR 'neoplanta (drug)' OR neural OR 'neoral sandimmun' OR 'neuro-stat<br>(drug)' OR 'neurostat (drug)' OR 'nm 0133' OR 'nm 133' OR nm0133 OR nm133 OR<br>'nova 22007' OR nova22007 OR 'ol 27400' OR ol27400 OR 'olo 400' OR olo500 OR<br>'opph 088' OR opph088 OR opsisporin OR optimmune OR 'otx 101' OR otx101 OR<br>'p 3072' OR p3072 OR padciclo OR papilock OR pulminiq OR restasis OR restaysis<br>OR sanciclo OR sandimmun OR 'sandimmun neural' OR sandimmune OR<br>'sandimmune neural' OR sandimun OR 'sandimun neural' OR sandimune OR 'sang 35'<br>OR sang35 OR sangcya OR seciera OR 'sp 14019' OR sp14019 OR 'sti 0529' OR<br>sti0529 OR 't 1580' OR t1580 OR vekacia OR verkazia OR 'zinograf me' OR<br>'immunosuppressive therapy')<br>#3 ('corticosteroid'/exp OR 'adrenal cortex hormone' OR 'adrenal cortex<br>hormones' OR 'adrenal cortical hormone' OR 'adrenal cortical hormones' OR 'adrenal<br>cortical steroid' OR 'adrenal steroid;' OR 'adrenal steroid hormone' OR 'adreno cortical<br>steroid' OR 'adreno corticosteroid' OR 'adrenocortical hormone' OR 'adrenocortical<br>steroid' OR adrenocorticosteroid OR 'cortical steroid' OR 'cortico steroid' OR<br>corticoid OR 'corticosteroid agent' OR 'corticosteroid calcium' OR 'corticosteroid<br>hormone' OR corticosteroids OR 'corticosteroids, inhalation' OR 'corticosteroids|15|  
|**Base**<br>**de dados**|**Termos**|**Publicações**|
|---|---|---|
||#4 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-<br>analysis' OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial' OR<br>'randomized controlled study' OR 'randomized controlled trial' OR 'trial, randomized<br>controlled' OR 'systematic review'/exp) AND [embase]/lim<br>Estratégia Final: #1 AND #2 AND #3 AND #4||
|**Coch**|#1 MeSH descriptor: [Red-Cell Aplasia, Pure] explode all trees|8 Cochrane|
|**rane**|#2 (“Pure Red Cell Aplasia” OR “Red-Cell Aplasias, Pure” OR “Erythrocyte|Reviews|
|**Reviews**|Aplasias” OR “Aplasias, Erythrocyte” OR “Aplasia, Pure Red-Cell” OR “Pure Red-<br>Cell Aplasia” OR “Erythrocyte Aplasia” OR “Red Cell Aplasia, Pure” OR “Aplasia<br>Pure Red Cell” OR “Pure Red-Cell Aplasias” OR “Aplasia, Erythrocyte”)<br>Estratégia Final:  #1 OR #2|24 trials|  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com APSV  
- (b) Tipo de intervenção: Ciclosporina e corticoides  
- (c) Tipos de estudos: para as bases MEDLINE via Pubmed e Cochrane foram considerados RS ou ECR; estudos  
- observacionais; relato e série de casos. Para a base Embase, RS ou ECR.  
- (d) Desfechos: Resposta Hematológica  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **<u>Resultados da busca e resumo das evidências</u>** -->
Após a atualização da busca nas bases de dados, 146 publicações foram recuperadas, das quais duas tratavam-se de duplicatas. Após a leitura de títulos e resumos, um estudo foi lido na íntegra. O estudo de Wu _et al.,_ (2019)<sup>10</sup> teve como objetivo avaliar se os pacientes adultos com aplasia eritrocitária pura adquirida (PRCA) poderiam se beneficiar mais do uso de ciclosporina A associada aos corticosteroides em comparação ao uso isolado de CsA ou CS. Desta maneira, como o comparador utilizado no estudo não responde à PICO definida, o artigo foi excluído. Assim, ao final, nenhum estudo respondeu à pergunta PICO. O resultado de cada etapa do processo de seleção é apresentado na **Figura 4** .  
De forma complementar, foram avaliadas as referências constantes do PCDT publicado por meio da Portaria SAS/MS nº 449, de 26 de abril de 2016 e que estariam relacionadas à questão em análise. Foram lidos três estudos na íntegra.  
O primeiro de Sawada _et al.,_ (2009)<sup>11</sup> apresentou resultados para ciclosporina e corticoide separadamente e demonstrou que as taxas de resposta à utilização da ciclosporina no tratamento da APSV variaram entre 65%-87%).  
Como Sawada _et al.,_ (2009)<sup>11</sup> citaram um estudo - Sawada _et al.,_ (2007)<sup>12</sup> - para análise da associação de conjunção da ciclosporina e corticóides, optou-se por incluir este estudo. Sawada _et al.,_ (2007)<sup>12</sup> realizaram um estudo retrospectivo proveniente de um registro nacional japonês, que incluiu 185 pacientes e análise de variadas terapias de imunossupressão - ciclosporina, ciclofosfamida, corticoides e globulina antimocítica. Não foram apresentados resultados sobre o uso de ciclosporina associada ao corticoide como primeira linha de tratamento.  O estudo relatou os efeitos do uso de ciclosporina em monoterapia: taxa de remissão de 74% e tempo médio de 82 dias livres de transfusão após o início do tratamento.  
O terceiro estudo (Mamiya _et al.,_ 1997)<sup>13</sup> também não apresentou resultados do uso da associação de ciclosporina ao corticoide como tratamento de primeira linha para APSV, sugerindo que a resposta clínica aos esquemas terapêuticos com ciclosporina em monoterapia seria maior e sustentada por um período mais longo.  
**Figura 4** - Fluxograma de seleção dos estudos incluídos para a PICO sobre imunossupressão em primeira linha para tratamento de aplasia pura adquirida crônica de série vermelha (APSV).  
<!-- Start of picture text -->
Identificadas (N=146) Duplicatas removidas Identificadas em — outras<br>EMBASE (n=15) (n=2) fontes (n=0)<br>Medline/Pubmed (n=99)<br>Cochrane (n=32)<br>Rastreadas (n=144) Excluidas (n=143)<br>t Excluidas com justificativa<br>- Comparador nao<br>Elegiveis (n=1) adequado (n=1)<br>| incusio Incluidos (n=0)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por manter a recomendação existente no PCDT publicado por meio da Portaria SAS/MS nº  
449, de 26 de abril de 2016.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que o uso associado de ciclosporina e corticoide é indicado em pacientes diagnosticados com APSV, de acordo com os critérios clínicos de elegibilidade que serão descritos a seguir:

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: Inclusão: -->
- Pacientes com diagnóstico de APSV idiopática que não entraram em remissão após um  mês ou;  
- Pacientes com diagnóstico de APSV secundária, que não tenham respondido ao tratamento da doença de base ou à  
- retirada do medicamento causador por pelo menos 1 mês.  
Exclusão:  
- Pacientes com intolerância ou hipersensibilidade ao medicamento.  
Contraindicações:  
- A ciclosporina está contraindicada em pacientes com creatinina basal superior a 3,0 mg/dL.  
- Esquemas de administração e tempos de tratamento:  
A ciclosporina para APSV deve ser iniciada na dose de 5 mg/kg/dia, por via oral, dividido em duas administrações. O ajuste de dose é baseado na concentração do nadir do medicamento que deve estar entre 150 e 400 ng/mL. Caso haja resposta, a dose da ciclosporina deve ser reduzida paulatinamente. Nos pacientes refratários ao tratamento, o medicamento deve ser suspenso.  
**QUESTÃO 5:** Devemos utilizar imunoglobulina humana para o tratamento de Aplasia Pura Adquirida Crônica de Série Vermelha (APSV)?  
**Recomendação:** Manteve-se a recomendação de utilizar imunoglobulina para casos especiais de pacientes com infecção por parvovírus B19 com APSV, em tratamento ambulatorial no âmbito do SUS (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com APSV e infecção por parvovírus B19 **Intervenção -** Imunoglobulina humana **Comparador -** Suporte transfusional **Desfechos -** Resposta hematológica **Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica.  
Com base na pergunta PICO estruturada, foram realizadas buscas nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 21 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro F** .  
Inicialmente, foram selecionadas as RSs com ou sem meta-análise ou ECRs. Dois revisores independentes selecionaram estudos para leitura na íntegra aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor procedeu à avaliação. Visto que não foram encontradas RSs com ou sem meta-análise ou ECRs, optou-se por buscar evidências adicionais utilizando a mesma estratégia de busca.  
**Quadro F -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de imunoglobulina humana em pacientes com APSV e infecção por parvovírus B19.  
|**Base**<br>**de dados**|**Termos**|**Publica**<br>**ções**|
|---|---|---|
|**PUB**|#1 ("Red-Cell Aplasia, Pure"[Mesh] OR “Red Cell Aplasia, Pure” OR “Pure Red-|18|
|**MED**<br>**(Medline)**|Cell Aplasia” OR “Aplasia, Pure Red-Cell” OR “Pure Red Cell Aplasia” OR “Pure Red-<br>Cell Aplasias” OR “Red-Cell Aplasias, Pure” OR “Aplasia Pure Red Cell” OR<br>“Erythrocyte Aplasia” OR “Aplasia, Erythrocyte” OR “Aplasias, Erythrocyte” OR<br>“Erythrocyte Aplasias”)<br>#2 ("Immunoglobulins"[Mesh] OR “Globulins, Immune” OR Immunoglobulin OR<br>“Immune Globulin” OR “Globulin, Immune” OR “Immune Globulins” OR “human<br>immunoglobulin*”)<br>#3 ("Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type]<br>OR<br>"Randomized<br>Controlled<br>Trial"[Publication<br>Type]<br>OR<br>"Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR "clinical trials as topic" [Mesh] OR "placebo"[tiab] OR<br>"randomly"[tiab] OR "clinical trial"[tiab] OR "double-blind method"[MeSH] OR<br>"double-blind"[tiab] OR "Systematic Reviews as Topic"[Mesh] OR “Systematic Review<br>as Topic” OR “Reviews Systematic as Topic” OR "Systematic Review" [Publication<br>Type] OR "Meta-Analysis" [Publication Type] OR "Meta-Analysis as Topic"[Mesh])<br>Estratégia final:  #1 AND #2 AND #3||
|**Emba**<br>**se**|#1 ('pure red cell anemia'/exp OR 'aplasia, erythrocyte' OR 'erythrocyte aplasia' OR<br>'erythrocyte aplasia, pure' OR 'erythroid aplasia' OR 'pure red cell anaemia' OR 'pure red<br>cell aplasia' OR 'pure red-cell aplasia' OR 'red cell aplasia' OR 'red cell aplasia, pure' OR<br>'red-cell aplasia, pure')<br>#2 ('immunoglobulin'/exp OR 'antibody protein' OR endobulin OR 'flebogamma<br>liquida' OR gamastan OR 'gamimmune n' OR gamimune OR 'gamma globulin' OR<br>'gamma globulin c' OR 'gamma immunoglobulin' OR 'gamma globulins' OR gammagee|36|  
|**Base**<br>**de dados**|**Termos**|**Publica**<br>**ções**|
|---|---|---|
||OR gammaglobulin OR gammaglobuline OR gammar OR gammimune OR gamulin OR<br>'gamulin rh' OR globuman OR 'glovenin i' OR ig OR igam OR igc OR 'immune gamma<br>globulin' OR 'immune globin' OR 'immune globulin' OR 'immune globuline' OR 'immune<br>globulins' OR 'immune serum globulin' OR immune OR 'immuno gamma globulin' OR<br>'immuno globulin' OR immunogammaglobulin OR immunoglobin OR 'immunoglobulin<br>17' OR 'immunoglobulin c' OR 'immunoglobulin c1' OR 'immunoglobulin chain' OR<br>'immunoglobulin gamma' OR 'immunoglobulin preparation' OR immunoglobulins OR<br>'immunoglobulins, intravenous' OR immunoprotein OR immunoproteins OR 'intraglobin<br>f' OR isiven OR iveegam OR ivega OR ivig OR panglobulin OR sandoglobin OR tegelin<br>OR tegeline OR veinoglobulin OR venoglobulin OR 'venoglobulin i')<br>#3 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial, randomized'<br>OR 'randomised controlled study' OR 'randomised controlled trial' OR 'randomized<br>controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled' OR<br>'systematic review'/exp) AND [embase]/lim<br>Estratégia final:  #1 AND #2 AND #3||
|**Cochr**<br>**ane Reviews**|#1 MeSH descriptor: [Red-Cell Aplasia, Pure] explode all trees<br>#2 (“Pure Red Cell Aplasia” OR “Red-Cell Aplasias, Pure” OR “Erythrocyte<br>Aplasias” OR “Aplasias, Erythrocyte” OR “Aplasia, Pure Red-Cell” OR “Pure Red-Cell<br>Aplasia” OR “Erythrocyte Aplasia” OR “Red Cell Aplasia, Pure” OR “Aplasia Pure Red<br>Cell” OR “Pure Red-Cell Aplasias” OR “Aplasia, Erythrocyte”)<br>Estratégia final:  #1 AND #2|8<br>Cochrane<br>Reviews<br>24 trials|  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com APSV e infecção por parvovírus B19  
- (b) Tipo de intervenção: Imunoglobulina humana  
- (c) Tipos de estudos: RS ou ECR; estudos observacionais; relato e série de casos.  
- (d) Desfechos: Resposta hematológica  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem  
Para responder à questão sobre uso de imunoglobulina humana para tratamento de APSV, após a atualização da busca nas bases de dados, 86 publicações foram recuperadas. Destas, sete tratavam-se de duplicatas e, após leitura de títulos e resumos, apenas uma foi lida na íntegra. Ao final, nenhum estudo respondeu à pergunta PICO. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 5** .  
**Figura 5** - Fluxograma de seleção dos estudos incluídos para a PICO sobre imunoglobulina humana para o tratamento de aplasia pura adquirida crônica de série vermelha (APSV).  
<!-- Start of picture text -->
Identificadas (N=86) Duplicatas removidas Identificadas em — outras<br>EMBASE (n=36) (n=7) fontes (n=0)<br>Medline/Pubmed (n=18)<br>Cochrane (n=32)<br>Rastreadas (n=79) Excluidas (n=78)<br>Excluidas com justificativa<br>— Estudo de braco unico sem<br>Elegiveis (n=1) comparador (n=1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resumo das evidências:** -->
Como não foram encontrados estudos que preenchessem os critérios de elegibilidade, foi realizada busca por evidência complementar, encontrando-se um relato de caso. Trata-se do estudo de Frickhofen _et al.,_ (1990)<sup>14</sup> , cujo objetivo foi determinar o papel do parvovírus B19 na APSV em pacientes infectados pelo HIV. Foram incluídos sete pacientes adultos e seis utilizaram imunoglobulina humana. O esquema terapêutico consistiu em 0,4 g/kg/dia de imunoglobulina por cinco ou 10 dias. Todos os pacientes tratados se recuperaram com a terapia, apresentando reticulocitose dentro de 10 dias do início das infusões. O **Quadro G** apresenta a resposta dos pacientes com infecção por parvovírus B19 ao tratamento com imunoglobulina.  
**Quadro G -** Resposta dos pacientes com infecção por parvovírus B19 ao tratamento com imunoglobulina.  
|**Paciente**|**Tratamento com**<br>**imunoglobulina**<br>**(g/kg de peso corporal)**|**Nível de**<br>**hemoglobina final**<br>**(g/L****_)_**|**Acompanhamento**|
|---|---|---|---|
|1|0,4 g/kg por 5 dias|125|Óbito 13 meses após o tratamento sem recaída de<br>aplasia pura de série vermelha.|
|2|0,4 g/kg por 10 dias|119|Recaída seis meses após o tratamento, segunda<br>remissão com tratamento de repetição com<br>imunoglobulina; óbito dois meses após por infecção<br>micobacteriana.|
|3|0,4 g/kg por 5 dias|123|Recaída três meses após o tratamento, segunda<br>remissão (mais de cinco meses) com tratamento de<br>repetição com imunoglobulina.|
|4|0,4 g/kg por 5 dias|126|Remissão por mais de sete meses.|
|5|0,4 g/kg por 10 dias|147|Remissão por mais de sete meses.|
|6|0,4 g/kg por 5 dias|132|Recaída sete semanas após o tratamento, segunda<br>remissão com tratamento de repetição com|  
imunoglobulina.  
Fonte: Frickhofen et. al., 1990<sup>14</sup> .  
Ainda, verificou-se que, no PCDT publicado por meio da Portaria SAS/MS nº 449, de 26 de abril de 2016, a recomendação foi baseada nos resultados de dois estudos de série de casos: Koduri _et al_ ., 1999<sup>15</sup> e Kurtzman _et al_ ., 1989<sup>16</sup> .  
O estudo de Koduri _et al_ . (1999)<sup>15</sup> é uma série de casos com o objetivo de determinar os efeitos da imunoglobulina humana no tratamento com infecção por parvovírus em AIDS. A terapia inicial de indução consistiu em 1 g/kg/dia de imunoglobulina humana durante 1 a 2 dias. As recidivas foram tratadas por 2 dias. A terapia de manutenção consistiu na administração de 0,4 a 1,0 g/kg de imunoglobulina a cada 4 semanas, administrada aos pacientes que desenvolveram uma segunda ou subsequente recaída. Os pacientes foram acompanhados por uma média de 27 meses (variação de 8 a 38 meses). Todos os pacientes responderam à terapia inicial com imunoglobulina. Seis pacientes com contagem de CD4 inferior a 80 células/mm<sup>3</sup> recaíram. A resposta foi de curta duração em dois pacientes com contagem de CD4 inferior a 80 células/mm3, os quais receberam uma única infusão de 1 g/kg de imunoglobulina como terapia inicial. Quatro pacientes receberam terapia de manutenção regular após uma segunda ou subsequente recaída e permaneceram em remissão. Dois pacientes cujas contagens de CD4 foram inferiores a 300 células/mm<sup>3</sup> permaneceram em remissão contínua não mantida por mais de 8 e 11 meses, respectivamente, após terapia de indução.  
O estudo de Kurtzman _et al.,_ (1989)<sup>16</sup> relatou o caso de um homem de 24 anos de idade com APSV e infecção por parvovírus. O paciente iniciou o tratamento com 400 mg/kg/dia de imunoglobulina humana por 10 dias. No final do primeiro período de tratamento, ocorreu uma reticulocitose, seguida de um retorno do nível de hemoglobina às concentrações normais. As infusões foram dadas periodicamente por vários meses e com sua suspensão, o nível de hemoglobina permaneceu entre 110 e 130 g/L. A infecção por parvovírus foi monitorada durante o tratamento com imunoglobulina. Em uma semana após o início do tratamento, o vírus não era mais detectável por técnicas convencionais de hibridização. No entanto, a amplificação com a reação em cadeia da polimerase mostrou pequenas quantidades de vírus em amostras de soro por vários meses. As infusões de imunoglobulinas foram interrompidas quando o DNA viral não foi mais detectado no sangue ou na medula óssea por qualquer uma das técnicas.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por manter a recomendação do PCDT publicado por meio da Portaria SAS/MS nº 449, de 26 de abril de 2016.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização de imunoglobulina é indicada em pacientes diagnosticados com APSV e infecção por parvovírus B19, em ambiente ambulatorial, de acordo com os critérios clínicos de elegibilidade que serão descritos a seguir:  
Inclusão:  
- Pacientes diagnosticados com APSV e infecção por parvovírus B19 e que estejam em tratamento de imunossupressão.  
- Exclusão:  
- Pacientes com intolerância ou hipersensibilidade à imunoglobulina humana.  
Contraindicações:  
- Não se sabe ao certo os riscos do uso da imunoglobulina na gravidez.  
Esquemas de administração e tempos de tratamento:  
- A dose recomendada é de 400 mg/kg/dia por 5 dias, via endovenosa.  
**QUESTÃO 6:** Devemos utilizar imunossupressão com ciclofosfamida para tratamento de Aplasia Pura Adquirida Crônica de Série Vermelha (APSV)?  
**Recomendação:** Manteve-se a recomendação de utilizar a imunossupressão com ciclofosfamida para tratamento de Aplasia Pura de Série Vermelha (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com APSV **Intervenção -** Ciclofosfamida **Comparador -** Suporte transfusional **Desfechos -** Resposta hematológica  
**Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foram realizadas buscas nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 21 de janeiro de 2022. Dois revisores independentes selecionaram estudos aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor procedeu à avaliação. As estratégias de busca estão descritas no **Quadro H** .  
**Quadro H** - Estratégias de busca, de acordo com a base de dados, para identificação de estudos sobre o uso de ciclofosfamida em pacientes com APSV.  
|**Base**<br>**de dados**|**Termos**|**Publicaç**<br>**ões**|
|---|---|---|
|**PUB**|#1 ("Red-Cell Aplasia, Pure"[Mesh] OR “Red Cell Aplasia, Pure” OR “Pure Red-|183|
|**MED**<br>**(Medline)**|Cell Aplasia” OR “Aplasia, Pure Red-Cell” OR “Pure Red Cell Aplasia” OR “Pure Red-<br>Cell Aplasias” OR “Red-Cell Aplasias, Pure” OR “Aplasia Pure Red Cell” OR<br>“Erythrocyte Aplasia” OR “Aplasia, Erythrocyte” OR “Aplasias, Erythrocyte” OR<br>“Erythrocyte Aplasias”)<br>#2 ("Cyclophosphamide"[Mesh] OR Sendoxan OR B-518 OR “B 518” OR B518<br>OR “Cyclophosphamide Anhydrous” OR “Cyclophosphamide, (R)-Isomer” OR<br>“Cyclophosphamide, (S)-Isomer” OR Cytophosphane OR<br>“Cyclophosphamide Monohydrate” OR Cytophosphan OR Cytoxan OR Endoxan<br>OR Neosar OR NSC-26271 OR “NSC 26271” OR NSC26271 OR Procytox OR “(+,-)-<br>2-(bis(2-Chloroethyl)amino)tetrahydro-2H-1,3,2-oxazaphosphorine<br>2-Oxide<br>Monohydrate” OR Cyclophosphane)<br>Estratégia final:  #1 AND #2||
|**Emba**|#1 ('pure red cell anemia'/exp OR 'aplasia, erythrocyte' OR 'erythrocyte aplasia'|20|
|**se**|OR 'erythrocyte aplasia, pure' OR 'erythroid aplasia' OR 'pure red cell anaemia' OR 'pure<br>red cell aplasia' OR 'pure red-cell aplasia' OR 'red cell aplasia' OR 'red cell aplasia, pure'<br>OR 'red-cell aplasia, pure')<br>#2 ('cyclophosphamide'/exp OR '2 [bis (2 chloroethyl) amino] tetrahydro (2h) 1,<br>3, 2 oxazaphosphorine 2 oxide' OR '2 [bis (beta chlorethyl) amino] 1 oxa 3 aza 2<br>phosphacyclohexan 2 oxid' OR '2 [bis (2 chloroethyl) amino] 1 oxa 3 aza 2<br>phosphacyclohexane' OR '2 [bis (2 chloroethyl) amino] (2h) 1, 3, 2 oxazaphosphorinane<br>2 oxide' OR '2h 1, 3, 2 oxazaphosphorine 2 [bis (2 chloroethyl) amino] tetrahydro 2 oxide'<br>OR alkyroxan OR 'b 518' OR 'b 518 asta' OR b518 OR 'b518 asta' OR carloxan OR<br>ciclofosfamida OR ciclolen OR cicloxal OR clafen OR 'cyclo cell' OR cycloblastin OR<br>cycloblastine OR 'cyclofos amide' OR cyclofosfamid OR cyclofosfamide OR cyclophar<br>OR cyclophosphamid OR 'cyclophosphamide isopac' OR cyclophosphamides OR||  
|**Base**<br>**de dados**|**Termos**|**Publicaç**<br>**ões**|
|---|---|---|
||cyclophosphan OR cyclophosphane OR cyclostin OR 'cyclostin n' OR cycloxan OR<br>cyphos OR cytophosphan OR cytophosphane OR cytoxan OR 'cytoxan lyophilized' OR<br>'endocyclo phosphate' OR endoxan OR 'endoxan asta' OR endoxana OR 'endoxon asta'<br>OR enduxan OR genoxal OR ledoxan OR ledoxina OR 'lyophilized cytoxan' OR mitoxan<br>OR 'n, n bis (2 chlorethyl) n o propylene phosphoric acid ester diamide' OR 'n, n bis (beta<br>chlorethyl) n ortho trimethylenphosphorsaureesterdiamid' OR neosan OR neosar OR<br>noristan OR 'nsc 26271' OR 'nsc 2671' OR procytox OR procytoxide OR semdoxan OR<br>sendoxan OR syklofosfamid)<br>#3 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial, randomized'<br>OR 'randomised controlled study' OR 'randomised controlled trial' OR 'randomized<br>controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled' OR<br>'systematic review'/exp) AND [embase]/lim<br>Estratégia final:  #1 AND #2 AND #3||
|**Cochr**|#1 MeSH descriptor: [Red-Cell Aplasia, Pure] explode all trees|8|
|**ane Reviews**|#2 (“Pure Red Cell Aplasia” OR “Red-Cell Aplasias, Pure” OR “Erythrocyte<br>Aplasias” OR “Aplasias, Erythrocyte” OR “Aplasia, Pure Red-Cell” OR “Pure Red-Cell<br>Aplasia” OR “Erythrocyte Aplasia” OR “Red Cell Aplasia, Pure” OR “Aplasia Pure Red<br>Cell” OR “Pure Red-Cell Aplasias” OR “Aplasia, Erythrocyte”)<br>Estratégia final:  #1 AND #2|Cochrane<br>Reviews<br>24 trials|  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com APSV  
- (b) Tipo de intervenção: Ciclofosfamida  
- (c) Tipos de estudos: para as bases MEDLINE via Pubmed e Cochrane foram considerados RS ou ECR; estudos  
observacionais; relato e série de casos. Para a base Embase, RS ou ECR.  
- (d) Desfechos: Resposta hematológica  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resultados da busca:** -->
Para responder à questão sobre uso de ciclofosfamida para APSV, após a atualização da busca nas bases de dados, 235 publicações foram recuperadas. Destas, seis eram duplicatas e, após leitura de títulos e resumos, 16 foram lidas na íntegra. Ao final, seis estudos responderam à pergunta PICO. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 6** .  
**Figura 6** - Fluxograma de seleção dos estudos incluídos para a PICO sobre imunossupressão com ciclofosfamida para tratamento de aplasia pura adquirida crônica de série vermelha (APSV).  
<!-- Start of picture text -->
Identificadas (N=235) Duplicatas removidas Identificadas em outras<br>EMBASE (n=20) (n=6) fontes (n=0)<br>Medline/Pubmed (n=183)<br>Cochrane (n=32)<br>if Excluidas com justificativa<br>, (N=10)<br>(n=8)<br>Auséncia de intervengao<br>de interesse(n=1)<br>Auséncia de desfecho de<br>interesse (n=1)<br>nui<br><!-- End of picture text -->  
**Resumo das evidências:**  
Foram encontrados seis estudos que preencheram os critérios de elegibilidade. Abaixo são apresentados as características e os resultados dos estudos incluídos ( **Quadro I** ).  
**Quadro I -** Características e resultados dos estudos incluídos para responder à questão clínica sobre imunossupressão com ciclofosfamida para tratamento de aplasia pura adquirida crônica de série vermelha (APSV).  
|**Autor, ano /**<br>**Desenho de**<br>**estudo**|**População (N)**|**Intervenção / Resultado**|
|---|---|---|
|Go_et al_., 2001<sup>17</sup>|Pacientes adultos com APSV|Ciclofosfamida 50-100 mg/dia, com ou sem corticosteroides|
|Estudo|associada à doença|(prednisona 1 mg/kg/dia) produziram uma melhor taxa de resposta|
|observacional do<br>tipo coorte<br>retrospectivo|linfoproliferativa de linfócitos<br>T granulares<br>N=15|global (resposta completa + resposta parcial) do que a prednisona<br>isolada (80%_versus_43%). Quando utilizados como terapias iniciais<br>e de resgate, ciclofosfamida e prednisona foram considerados em<br>associação. As taxas de resposta geral para prednisona e<br>ciclofosfamida com ou sem corticosteroides foram semelhantes<br>(60% e 50%, respectivamente).|
|Balasubramanian<br>_et al_., 2018<sup>18</sup>|Pacientes adultos com APSV<br>N=62|Os pacientes portadores de APSV foram tratados com<br>ciclofosfamida (não há descrição de dose e posologia) e obtiveram|
|Estudo||os seguintes resultados: taxa de resposta global de 45% (14/31), taxa|
|observacional do||de resposta completa em primeira linha 15% (1/7) e taxa de resposta|
|tipo coorte<br>retrospectivo||completa geral 27% (8/30).|  
|**Autor, ano /**<br>**Desenho de**<br>**estudo**|**População (N)**|**Intervenção / Resultado**|
|---|---|---|
|Al-Awami_et al.,_<br>1997<sup>19</sup><br>Relato de caso|Paciente de 34 anos com<br>aplasia eritrocitária pura<br>recorrente e evidência de<br>infecção por hepatite C<br>N=1|A paciente foi tratada com 20 mg/dia de prednisona oral, e<br>ciclofosfamida, inicialmente 50 mg/dia por 2 semanas, depois 100<br>mg/dia. Após 3 semanas de terapia, a paciente não necessitava mais<br>de transfusão. Após 10 semanas, o hematócrito estava normal e a<br>dose de prednisona foi reduzida, até ser suspensa. Suas hemácias<br>permaneceram macrocíticas, com valores de volume corpuscular<br>médio entre 105 fL e 115 fL. O tratamento com 100 mg/dia de<br>ciclofosfamida foi continuado por 4 meses.|
|Dhodapkar_et al_.,<br>1994<sup>20</sup>|Paciente de 28 anos com<br>Leucemia Linfocítica Granular|A administração oral de baixa dose de ciclofosfamida (50 mg/dia)<br>foi iniciada. A dose foi aumentada para 100 mg/dia com base na|
|Relato de caso|Grande de Células T e APSV<br>com histórico de falha<br>poliendócrina<br>N=1|tolerância do paciente. O nível de hemoglobina pré-tratamento foi<br>de 6,5 g/dL e pós-tratamento, 13,8 g/dL, com (valor de referência<br>11,6-14,9.  O volume corpuscular médio  pré-tratamento foi 90 fL e<br>pós-tratamento, 97 fL, com valor de referência 81-98.|
|Hansen_et al_.,<br>1986<sup>21</sup>|Paciente de 40 anos com<br>esplenomegalia, anemia|A ciclofosfamida (50-100 mg/dia) foi administrada por via oral<br>durante oito meses e resultou em uma contagem de leucócitos total|
|Relato de caso|macrocítica e APSV<br>N=1|normal com desaparecimento da linfocitose no sangue periférico e<br>melhora dos níveis de hemoglobina para 14,2 g/dL|
|Xiao_et al_.,<br>2021<sup>22</sup>|Paciente de 34 anos com<br>leucemia linfocítica granular|Ciclofosfamida (200 mg/dia) foi administrada como tratamento<br>único. O nível de hemoglobina inicial foi de 35 g/L e aumentou|
|Relato de caso|grande de células T γδ CD57-<br>negativas com APSV<br>N=1|gradualmente até 100 g/L após 3 meses.|  
Legenda: APSV: aplasia pura adquirida crônica de série vermelha. Fonte: Go et al., 2001<sup>17</sup> ; Balasubramanian et al., 2018<sup>18</sup> ; Al-Awami et al., 1997<sup>19</sup> ; Dhodapkar et al., 1994<sup>20</sup> ; Hansen et al., 1986<sup>21</sup> ; Xiao et al., 2021<sup>22</sup> . Nota: O estudo de Xiau et al., 2021<sup>22</sup> foi realizado na China. Os demais estudos foram realizados nos Estados Unidos.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por manter a recomendação do PCDT publicado por meio da Portaria SAS/MS nº 449, de 26 de abril de 2016.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que a utilização de imunossupressão com ciclofosfamida é indicada  
em pacientes com APSV, de acordo com os critérios clínicos de elegibilidade que serão descritos a seguir:  
Inclusão:  
● Pacientes com diagnóstico de APSV idiopática que não entrarem em remissão em um mês e, em caso de APSV secundária, que não tenham respondido ao tratamento da doença de base ou à retirada do medicamento causador por pelo menos um mês.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: Exclusão: -->
● Pacientes com intolerância ou hipersensibilidade à ciclofosfamida.  
Esquemas de administração e tempos de tratamento:  
● A dose inicial é de 50 a 100 mg/dia, via oral, podendo ser titulada até dose de 150 mg/dia. A mediana de resposta é de 12 semanas. Caso ocorra resposta, a dose da ciclofosfamida deve ser reduzida paulatinamente, sendo o tempo máximo de tratamento recomendado com ciclofosfamida de 6 meses.  
Casos especiais:  
● No tratamento de pacientes gestantes, deve-se considerar o risco benefício, visto que o uso da ciclofosfamida está relacionado à má formação congênita, perdas fetais e efeitos fetotóxicos no recém-nascido.  
**QUESTÃO 7:** Devemos utilizar ATG de coelho associado a ciclosporina em primeira linha para AAG?  
**Recomendação:** Manteve-se a recomendação de utilizar ATG de coelho associado a ciclosporina em primeira linha para o tratamento de anemia aplástica grave (recomendação não graduada).  
A estrutura PICO para esta pergunta foi: **População -** Pacientes com AAG **Intervenção -** ATG de coelho e ciclosporina **Comparador -** Ciclosporina **Desfechos -** Resposta hematológica **Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foram realizadas buscas nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 21 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro J** . Foram selecionadas as RS com ou sem meta-análise ou ECRs. Dois revisores independentes selecionaram estudos aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor procedeu à avaliação.  
**Quadro J -** Estratégias de busca, de acordo com a base de dados, para identificação de estudos sobre o uso de ATG de coelho associado a ciclosporina em pacientes com AAG.  
|**Base de**<br>**dados**|**Termos**|**Publicações**|
|---|---|---|
|**PUBMED**|#1 ("Anemia, Aplastic"[Mesh] OR “Aplastic Anemias” OR “Aplastic Anemia” OR|200|
|**(Medline)**|“Aplastic Anaemia” OR “Anaemia, Aplastic” OR “Aplastic Anaemias” OR “Anemia,<br>Hypoplastic” OR “Hypoplastic Anemia” OR “Hypoplastic Anemias” OR “severe<br>aplastic anemia”)<br>#2 ("Antilymphocyte Serum"[Mesh] OR "Antilymphocyte Serum" OR "Antilymphocyte<br>Serums" OR "Serum, Antilymphocyte" OR "Serums, Antilymphocyte" OR<br>"Antilymphocyte Antibodies" OR "Antibodies, Antilymphocyte" OR "Antibody,<br>Antilymphocyte" OR "Antilymphocyte Antibody" OR "Antilymphocyte Globulin" OR<br>"Antilymphocyte Globulins" OR "Globulin, Antilymphocyte" OR "Globulins,<br>Antilymphocyte" OR Pressimmune OR Antithymoglobulin OR Antithymoglobulins OR<br>"Antithymocyte<br>Globulin"<br>OR<br>"Antithymocyte<br>Globulins"<br>OR<br>"Globulin,<br>Antithymocyte" OR "Globulins, Antithymocyte" OR "Lymphocyte Immune Globulin,<br>Anti-Thymocyte Globulin" OR "Lymphocyte Immune Globulin, Anti Thymocyte<br>Globulin" OR "Anti-Thymocyte Globulin" OR "Anti Thymocyte Globulin" OR "Anti-<br>Thymocyte Globulins" OR "Globulin, Anti-Thymocyte" OR "Globulins, Anti-<br>Thymocyte" OR ATGAM OR "Lymphocyte Immune Globulin, Anti-Thymocyte||  
|**Base de**<br>**dados**|**Termos**|**Publicações**|
|---|---|---|
||Globulin<br>(Equine)"<br>OR<br>"Lymphocytotoxic<br>Antibodies"<br>OR<br>"Antibodies,<br>Lymphocytotoxic" OR "Antibody, Lymphocytotoxic" OR "Lymphocytotoxic Antibody"<br>OR "Antilymphoblast Globulins" OR "Antilymphoblast Globulin" OR "Globulin,<br>Antilymphoblast"<br>OR<br>"Globulins,<br>Antilymphoblast"<br>OR<br>"Antilymphocyte<br>Immunoglobulin" OR "Antilymphocyte Immunoglobulins" OR "Immunoglobulin,<br>Antilymphocyte" OR "Immunoglobulins, Antilymphocyte")<br>#3 ("Cyclosporine"[Mesh] OR Cyclosporine OR Cyclosporine OR "Cyclosporine A" OR<br>"Cyclosporin A" OR Ciclosporin OR Cyclosporin OR Neoral OR "Sandimmun Neoral"<br>OR CyA-NOF OR "CyA NOF" OR Sandimmune OR Sandimmun OR CsA-Neoral OR<br>"CsA Neoral" OR CsANeoral OR "OL 27-400" OR "OL 27 400" OR "OL 27400" OR<br>"immunosuppressive therapy" OR "immunosuppressive agents")<br>#4 ("Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication Type]<br>OR "Randomized Controlled Trial"[Publication Type] OR "Clinical Trial"[Publication<br>Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR "Random<br>Allocation"[Mesh] OR "clinical trials as topic" [Mesh] OR "placebo"[tiab] OR<br>"randomly"[tiab] OR "clinical trial"[tiab] OR "double-blind method"[MeSH] OR<br>"double-blind"[tiab] OR "Systematic Reviews as Topic"[Mesh] OR “Systematic Review<br>as Topic” OR “Reviews Systematic as Topic” OR "Systematic Review" [Publication<br>Type] OR "Meta-Analysis" [Publication Type] OR "Meta-Analysis as Topic"[Mesh])<br>Estratégia final:  #1 AND #2 AND #3 AND #4||
|**Embase**|<br>#1 ('aplastic anemia'/exp OR 'aplastic anemias' OR 'aplastic anemia' OR 'aplastic<br>anaemia' OR 'anaemia, aplastic' OR 'aplastic anaemias' OR 'anemia, hypoplastic' OR<br>'hypoplastic anemia' OR 'hypoplastic anemias' OR 'severe aplastic anemia')<br>#2 ('cyclosporine'/exp OR 'adi 628' OR adi628 OR cequa OR 'cgc 1072' OR cgc1072 OR<br>ciclomulsion OR cicloral OR ciclosporin OR 'ciclosporin a' OR ciclosporine OR cipol<br>OR 'cipol n' OR consupren OR cyclasol OR cyclokat OR cyclosporin OR 'cyclosporin a'<br>OR 'cyclosporin neoral' OR 'cyclosporine a' OR 'de 076' OR de076 OR deximune OR<br>equoral OR gengraf OR ikervis OR iminoral OR implanta OR imusporin OR 'lx 201' OR<br>lx201 OR 'mc2 03' OR mc203 OR 'mtd 202' OR mtd202 OR 'neoplanta (drug)' OR neural<br>OR 'neoral sandimmun' OR 'neuro-stat (drug)' OR 'neurostat (drug)' OR 'nm 0133' OR<br>'nm 133' OR nm0133 OR nm133 OR 'nova 22007' OR nova22007 OR 'ol 27400' OR<br>ol27400 OR 'olo 400' OR olo500 OR 'opph 088' OR opph088 OR opsisporin OR<br>optimmune OR 'otx 101' OR otx101 OR 'p 3072' OR p3072 OR padciclo OR papilock<br>OR pulminiq OR restasis OR restaysis OR sanciclo OR sandimmun OR 'sandimmun<br>neural' OR sandimmune OR 'sandimmune neural' OR sandimun OR 'sandimun neural'<br>OR sandimune OR 'sang 35' OR sang35 OR sangcya OR seciera OR 'sp 14019' OR<br>sp14019 OR 'sti 0529' OR sti0529 OR 't 1580' OR t1580 OR vekacia OR verkazia OR<br>'zinograf me' OR 'immunosuppressive therapy')<br>#3 ('lymphocyte antibody'/exp OR ahlbulin OR 'anti lymphocyte globulin' OR 'anti<br>lymphocyte immunoglobulin' OR 'anti lymphocyte serum' OR 'anti lymphocytic globulin'|25|  
|**Base de**<br>**dados**|**Termos**|**Publicações**|
|---|---|---|
||OR 'anti lymphocytic serum' OR 'anti mouse lymphocyte serum' OR 'antibody,<br>lymphocyte' OR 'antihuman lymphocyte globulin' OR 'antilymphocyte antibody' OR<br>'antilymphocyte antiserum' OR 'antilymphocyte globulin' OR 'antilymphocyte globuline'<br>OR 'antilymphocyte immunoglobulin' OR 'antilymphocyte serum' OR 'antilymphocyte<br>serum antibody' OR 'antilymphocytic globulin' OR 'antilymphocytic serum' OR<br>antilympholin OR 'antiserum, lymphocyte' OR 'horse antihuman thymocyte serum' OR<br>'horse antilymphocyte globulin' OR 'limphoser berna' OR 'lymphocyte antiserum' OR<br>'lymphocyte immune globulin n' OR 'lymphocyte membrane antibody' OR<br>'lymphocytotoxic antibody' OR lymphoglobulin OR lymphoglobuline OR lymphoser OR<br>pressimune OR 'rabbit anti mouse antilymphocyte serum' OR 'rabbit anti mouse<br>lymphocyte serum' OR 'rabbit antihuman lymphocyte globulin' OR 'rabbit antimouse<br>lymphocyte serum' OR 'serum antilymphocytic' OR 'serum, antilymphocyte' OR 'sheep<br>antidog antilymphocyte serum')<br>#4 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis' OR<br>'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial, randomized' OR<br>'randomised controlled study' OR 'randomised controlled trial' OR 'randomized<br>controlled study' OR 'randomized controlled trial' OR 'trial, randomized controlled' OR<br>'systematic review'/exp) AND [embase]/lim<br>Estratégia final:  #1 AND #2 AND #3 AND #4||
|**Cochrane**<br>**Reviews**|#1 MeSH descriptor: [Anemia, Aplastic] explode all trees<br>#2 (“Aplastic Anemia” OR “Anaemia, Aplastic” OR “Aplastic Anaemia” OR “Aplastic<br>Anemias” OR “Aplastic Anaemias” OR “Hypoplastic Anemia” OR “Anemia,<br>Hypoplastic” OR “Hypoplastic Anemias”)<br>#3 #1 OR #2<br>#4 MeSH descriptor: [Antilymphocyte Serum] explode all trees<br>#5 (Pressimmune OR “Antilymphocyte Immunoglobulin” OR “Immunoglobulins,<br>Antilymphocyte” OR “Immunoglobulin, Antilymphocyte” OR “Antilymphocyte<br>Immunoglobulins” OR “Antilymphocyte Globulins” OR “Antilymphocyte Globulin” OR<br>“Globulin, Antilymphocyte” OR “Globulins, Antilymphocyte” OR “Antithymocyte<br>Globulin” OR “Antithymocyte Globulins” OR “Globulin, Anti-Thymocyte” OR<br>Antithymoglobulins OR Antithymoglobulin OR “Anti Thymocyte Globulin” OR “Anti-<br>Thymocyte Globulins” OR “Globulins, Antithymocyte” OR “Anti-Thymocyte Globulin”<br>OR “Lymphocyte Immune Globulin, Anti-Thymocyte Globulin” OR “Globulins, Anti-<br>Thymocyte” OR “Lymphocyte Immune Globulin, Anti Thymocyte Globulin” OR<br>“Globulin, Antithymocyte” OR “Antilymphoblast Globulin” OR “Antilymphoblast<br>Globulins” OR “Globulin, Antilymphoblast” OR “Globulins, Antilymphoblast” OR<br>“Lymphocyte<br>Immune<br>Globulin,<br>Anti-Thymocyte<br>Globulin<br>(Equine)”<br>OR<br>“Antilymphocyte<br>Serums”<br>OR<br>“Serums,<br>Antilymphocyte”<br>OR<br>“Serum,<br>Antilymphocyte”<br>OR<br>ATGAM<br>OR<br>“Antibody,<br>Lymphocytotoxic”<br>OR<br>“Lymphocytotoxic<br>Antibody”<br>OR<br>“Antibodies,<br>Lymphocytotoxic”<br>OR|5 Cochrane<br>Reviews<br>62 trials|  
|**Base de**<br>**dados**|**Termos**|**Publicações**|
|---|---|---|
||“Lymphocytotoxic Antibodies” OR “Antibody, Antilymphocyte” OR “Antilymphocyte<br>Antibody” OR “Antibodies, Antilymphocyte” OR “Antilymphocyte Antibodies”)<br>#6 #4 OR #5<br>#7 MeSH descriptor: [Cyclosporins] in all MeSH products<br>#8 (Cyclosporines OR Cyclosporin OR “Cyclosporin A” OR “Cyclosporine A” OR<br>“Sandimmun Neoral” OR CsA-Neoral OR “CsA Neoral” OR Sandimmun OR<br>Sandimmune OR Ciclosporin OR Neoral)<br>#9 #7 OR #8<br>Estratégia final:  #3 AND #6 AND #9||  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos e crianças diagnosticados com AAG  
- (b) Tipo de intervenção: ATG de coelho associado a ciclosporina  
- (c) Tipos de estudos: RS ou ECR  
- (d) Desfechos: Resposta hematológica  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resultados da busca:** -->
Para responder à questão sobre uso de ATG de coelho associado a ciclosporina para AAG, após a atualização da busca nas bases de dados, 292 publicações foram recuperadas. Destas, 39 eram duplicatas e, após leitura de títulos e resumos, um estudo foi lido na íntegra e ao final, respondeu à pergunta PICO. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 7** .  
**Figura 7** -  Fluxograma de seleção dos estudos incluídos para responder à questão sobre ATG de coelho associado a ciclosporina em primeira linha para AAG.  
<!-- Start of picture text -->
Identificadas (N=292) Duplicatas removidas Identificadas em — outras<br>EMBASE (n=25) (n=39) fontes (n=0)<br>Medline/Pubmed (n=200)<br>Cochrane (n=67)<br>i Excluidas com justificativa<br>_ (N=0)<br>Elegiveis (n=1)<br>GED (eam<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Resumo das evidências:** -->
Foi encontrado um estudo que preencheu os critérios de elegibilidade (CHEN _et al_ ., 2006)<sup>23,</sup> o qual teve como objetivo avaliar a eficácia de tratamentos imunossupressores com ciclosporina isoladamente ou ATG associada à ciclosporina em crianças com AAG. Cinquenta e quatro pacientes foram tratados de janeiro de 1997 a junho de 2003, sendo 31 pacientes tratados com ATG associada à ciclosporina e 23 pacientes foram tratados apenas com ciclosporina.  
O tempo de resposta dos grupos ATG associado à ciclosporina e de ciclosporina em monoterapia foi de 2,5 meses e 3,5 meses, respectivamente (P<0,05); a taxa de resposta nos dois grupos foi de 81% (25/31) e 52% (12/23), respectivamente (P<0,05) e a taxa de recaída foi de 8% (2/25) e 50% (6/12), respectivamente (P<0,05). Não houve diferenças significativas quanto às reações adversas aos agentes imunossupressores. Os casos foram acompanhados por mais de um ano e a sobrevida livre de eventos em um ano nesses dois grupos foi de 81% (25/31) e 52% (12/23), respectivamente (P<0,01). Quarenta e sete casos foram acompanhados por mais de dois anos e a sobrevida livre de eventos foi de 74% (20/27) e 50% (10/20), respectivamente (P<0,01).

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por manter a recomendação do PCDT publicado por meio da Portaria SAS/MS nº 1.300, de 21  
de novembro de 2013.  
**Considerações gerais e para implementação:**  
O grupo elaborador das recomendações considerou que a utilização de ATG de coelho associada à ciclosporina é indicada  
em pacientes com AAG, de acordo com os critérios clínicos de elegibilidade que serão descritos a seguir:  
- Inclusão:  
- Pacientes com AA grave e muito graves, crianças ou adultos, não candidatos à TCTH alogênico.  
- Exclusão:  
- Pacientes com intolerância ou hipersensibilidade à ATG ou à ciclosporina.  
- Contraindicações:  
- Não se sabe ao certo os riscos do uso da ciclosporina na gravidez.  
Esquemas de administração e tempos de tratamento:  
- ATG: a dose recomendada é de 1 a 5 mg/kg/dia, por 5 dias, com infusão em 12 horas, via acesso venoso central. A dose  
- comumente utilizada é de 2,5 mg/kg/dia, por 5 dias.  
● Ciclosporina: a dose inicial é de 5 mg/kg/dia, via oral, dividida em duas administrações. O ajuste de dose é baseado na concentração do nadir do medicamento que deve estar entre 150 - 400 ng/mL e, caso haja resposta, a dose deve ser reduzida em 20% consecutivamente, após 180 dias (D+180); após 270 dias (D+270) e após 360 dias (D+360). Em seguida, esta dose deve ser administrada por mais 1 ano, totalizando 2 anos de uso de ciclosporina. Caso não haja resposta em 3 a 6 meses, o medicamento deve ser suspenso.  
Considerações adicionais  
A ATG só está disponível no âmbito do SUS para administração hospitalar. Sua utilização requer monitorização intensiva, uma vez que, dentre as complicações possíveis, estão anafilaxia, febre e infecções graves. Durante sua administração, deve ser oferecido aos pacientes suporte transfusional intensivo com concentrado de plaquetas.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **REFERÊNCIAS** -->
1. Zhu Y, Gao Q, Hu J, Liu X, Guan D, Zhang F. Allo-HSCT compared with immunosuppressive therapy for acquired aplastic anemia: a system review and meta-analysis. BMC Immunol. 2020;21(10):1-11.  
2. Peinemann F, Bartel C, Grouven U. First-line allogeneic hematopoietic stem cell transplantation of HLA-matched  
sibling donors compared with first-line ciclosporin and/or antithymocyte or antilymphocyte globulin for acquired severe aplastic anemia. Cochrane Database Syst Rev. 2013;2013(7):1-55.  
3. Peinemann F, Labeit AM. Stem cell transplantation of matched sibling donors compared with immunosuppressive  
therapy for acquired severe aplastic anaemia: a Cochrane systematic review. BMJ Open. 2014;4:e005039.  
4. Bacigalupo A, Brand R, Oneto R, et al. Treatment of acquired severe aplastic anemia: bone marrow transplantation  
compared with immunosuppressive therapy-The European Group for Blood and Marrow Transplantation experience. Semin Hematol. 2000;37(1):69-80.  
5. Bacigalupo A, Passweg J. Diagnosis and Treatment of Acquired Aplastic Anemia. Hematology/Oncology Clinics  
of North America. 1o de abril de 2009;23(2):159-70.  
6. Peffault de Latour R, Kulasekararaj A, Iacobelli S, Terwel SR, Cook R, Griffin M, et al. Eltrombopag Added to  
Immunosuppression in Severe Aplastic Anemia. N Engl J Med. 6 de janeiro de 2022;386(1):11–23.  
7. Bongiovanni A, Recine F, Fausti V, et al. Clinical role of filgrastim in the management of patients at risk of  
prolonged severe neutropenia: An evidence-based review. Int J Clin Pract. 2019;73(11):e13404.  
8. Dale DC, Crawford J, Klippel Z, et al. A systematic literature review of the efficacy, effectiveness, and safety of  
filgrastim. Support Care Cancer. 2018;26(1):7-20.  
9. Dale DC, Bonilla MA, Davis MW, Nakanishi AM, Hammond WP, Kurtzberg J, et al. A Randomized Controlled  
Phase III Trial of Recombinant Human Granulocyte Colony-Stimulating Factor (Filgrastim) for Treatment of Severe Chronic Neutropenia. Blood. 1993;81(10):2496.  
10. Wu X, Yang Y, Lu X, Yin H, Wang S, Wang S, Hong M, Zhu Y, Lu R, Qiao C, Wu Y, He G, Li J. Induced complete  
remission faster in adult patients with acquired pure red cell aplasia by combining cyclosporine A with corticosteroids. Medicine. 2019. Oct;98(41):e17425.  
11. Sawada K, Hirokawa M, Fujishima N. Diagnosis and management of acquired pure red cell aplasia. Hematol Oncol  
Clin North Am. 2009;23(2):249-259.  
12. Sawada K, Hirokawa M, Fujishima N, Teramura M, Bessho M, Dan K, et al. Long-term outcome of patients with  
acquired primary idiopathic pure red cell aplasia receiving cyclosporine A. A nationwide cohort study in Japan for the PRCA Collaborative Study Group. Haematologica. 2007;92(8):1021-8.  
13. Mamiya S, Itoh T, Miura AB. Acquired pure red cell aplasia in Japan. Eur J Haematol. 1997;59(4):199-205.  
14.  Frickhofen N, Abkowitz JL, Safford M, Berry JM, Antunez-de-Mayolo J, Astrow A, et al. Persistent B19 Parvovirus  
Infection in Patients Infected with Human Immunodeficiency Virus Type 1 (HIV-1): A Treatable Cause of Anemia in AIDS. Ann Intern Med. 1990;113(12):926-33.  
15.  Koduri PR, Kumapley R, Valladares J, Teter C. Chronic pure red cell aplasia caused by parvovirus B19 in AIDS:  
Use of intravenous immunoglobulin - A report of eight patients. American Journal of Hematology. 1999;61(1):16-20.  
16.  Kurtzman G, Frickhofen N, Kimball J, Jenkins DW, Nienhuis AW, Young NS. Pure Red-Cell Aplasia of 10 Years’  
Duration Due to Persistent Parvovirus B19 Infection and Its Cure with Immunoglobulin Therapy. New England Journal of Medicine. 1989;321(8):519-23.  
17.  Go RS, Li C-Y, Tefferi A, Phyliky RL. Acquired pure red cell aplasia associated with lymphoproliferative disease  
of granular T lymphocytes. Blood. 2001;98(2):483-5.  
18.  Balasubramanian SK, Sadaps M, Thota S, Aly M, Przychodzen BP, Hirsch CM, et al. Rational management  
approach to pure red cell aplasia. Haematologica. 2018;103(2):221-30.  
19.  Al-Awami Y, Sears DA, Carrum G, Udden MM, Alter BP, Conlon CL. Pure Red Cell Aplasia Associated With  
Hepatitis C Infection: The American Journal of the Medical Sciences. 1997;314(2):113-7.  
20.  Dhodapkar MV, Lust JA, Phyliky RL. T-Cell Large Granular Lymphocytic Leukemia and Pure Red Cell Aplasia in a Patient With Type I Autoimmune Polyendocrinopathy: Response to Immunosuppressive Therapy. Mayo Clinic Proceedings. 1994;69(11):1085-8.  
21.  Hansen RM, Lerner N, Abrams RA, Patrick CW, Malik MI, Keller R. T-cell chronic lymphocytic leukemia with pure red cell aplasia: Laboratory demonstration of persistent leukemia in spite of apparent complete clinical remission. American Journal of Hematology. 1986;22(1):79-86.  
22.  Xiao P-P, Chen X-Y, Dong Z-G, Huang J-M, Wang Q-Q, Chen Y-Q, et al. Treatment for CD57-negative γδ T-cell large granular lymphocytic leukemia with pure red cell aplasia: A case report. WJCC. 2021;9(26):7818-24.  
23.  Chen C, Fang J, Huang S, Zhong F. [Immunosuppressive therapy for 54 children patients with acquired severe aplastic anemia]. Zhonghua Er Ke Za Zhi. 2006;44(11):841–4.

---

<!-- METADADOS: doenca: Síndrome de Falência Medular | secao: **APÊNDICE 2** -->
HISTÓRICO DE ALTERAÇÕES DO PCDT  
|||**Tecnologias avaliadas pela C**|**onitec***|
|---|---|---|---|
|**Referência normativa**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Exclusão, não incorporação**<br>**ou não alteração no SUS**|
|Portaria Conjunta<br>SAES/SCTIE/MS nº<br>23/2022<br>Portaria SAS/MS nº<br>1.300/2013|Unificação dos PCDT de Anemia<br>Aplástica Adquirida, de Anemia<br>Aplástica, Mielodisplasia e<br>Neutropenias Constitucionais - Uso<br>de Fatores Estimulantes de<br>Crescimento de Colônia de<br>Neutrófilos e de Aplasia Pura<br>Adquirida Crônica da Série<br>Vermelha e atualização dos<br>respectivos conteúdos.<br>**PCDT da Anemia A**<br>Atualização.|Eltrombopague para o<br>tratamento adicional a<br>imunossupressor em<br>pacientes adultos com anemia<br>aplástica grave<br>(Portaria SCTIE/MS nº<br>47/2022)<br>**plástica Adquirida**<br>-|Imunoglobulina humana 3,0<br>g pó para solução injetável<br>ou solução injetável<br>(Portaria SCTIE/MS nº<br>83/2021)<br>-|
|Portaria SAS/MS nº<br>490/2010<br>**PCDT da Anemia**|Primeira versão.<br>**Aplástica, Mielodisplasia e Neutrop**<br>**Crescimento de Col**|-<br>**enias Constitucionais - Uso de**<br>**ônias de Neutrófilos**|-<br>**Fatores Estimulantes de**|
|Portaria SAS/MS nº<br>113/2016|Atualização, não preconizando o<br>medicamento molgramostim.||Molgramostrim 300mcg<br>injetável para o tratamento<br>da anemia aplástica,<br>mielodisplasia, neutropenias<br>constitucionais, doença pelo<br>HIV e transplante de medula<br>ou pâncreas|  
||||(Portaria SCTIE/MS nº<br>04/2016)|
|---|---|---|---|
|Portaria SAS/MS nº<br>212/2010|Atualização, não preconizando o<br>medicamento lenograstim.|-|-|
|Portaria SAS/MS nº<br>862/2002|Primeira versão.|-|-|
||**PCDT da Aplasia Pura Adquir**|**ida Crônica da S**|**érie Vermelha**|
|Portaria SAS/MS nº<br>449/2016|Atualização.|-|-|
|Retificação da Portaria<br>SAS/MS nº 227/2010|Retificação do Termo de<br>Esclarecimento e Responsabilidade<br>(TER).|-|-|
|Portaria SAS/MS nº<br>227/2010|Primeira versão.|-|-|  
* Refere-se às tecnologias em saúde avaliadas no âmbito do PCDT previamente à publicação da referência normativa listada à primeira coluna

---

