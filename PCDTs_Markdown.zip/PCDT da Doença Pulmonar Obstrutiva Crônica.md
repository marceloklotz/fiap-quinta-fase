<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE -->
PORTARIA CONJUNTA SAES/SCTIE Nº 29, DE 27 DE NOVEMBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença Pulmonar Obstrutiva Crônica.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE -->
**INOVAÇÃO EM SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025, e  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença Pulmonar Obstrutiva Crônica no Brasil e as diretrizes  
nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1046/2025 e o Relatório de Recomendação nº 1046/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura;  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença Pulmonar Obstrutiva Crônica.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Doença Pulmonar Obstrutiva Crônica, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença Pulmonar Obstrutiva Crônica.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta nº 19, de 16 de novembro de 2021, publicada no Diário Oficial da União (DOU) nº 218, em 22 de novembro de 2021, seção 1, página 210.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: FERNANDA DE NEGRI -->
1

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **1. INTRODUÇÃO** -->
A Doença Pulmonar Obstrutiva Crônica (DPOC) é uma condição pulmonar caracterizada pela presença de sintomas respiratórios crônicos, não totalmente reversíveis, associada a uma resposta inflamatória anormal, geralmente causada por inalação significativa de partículas ou gases nocivos, e influenciada por fatores individuais. Do ponto de vista fisiopatológico, a obstrução crônica ao fluxo de ar ocorre devido a alterações nas vias respiratórias (como bronquite e bronquiolite) e/ou nos alvéolos (como no enfisema), com impacto variável entre os indivíduos<sup>1,2</sup> .  
A DPOC resulta da interação entre predisposição genética e exposições nocivas ao longo da vida, comprometendo a função pulmonar de forma persistente e progressiva<sup>1,3</sup> . O tabagismo é o principal fator desencadeante, seguido pela exposição a poluentes ambientais e ocupacionais<sup>2,4,5</sup> . Além disso, fatores individuais, como alterações no desenvolvimento pulmonar e envelhecimento precoce dos pulmões, também podem influenciar o surgimento e a progressão da doença<sup>3</sup> .  
Os sintomas têm início insidioso e se tornam mais frequentes e intensos com o tempo, com episódios de exacerbações que podem durar alguns dias. Tosse crônica, expectoração e dispneia progressiva são os achados mais comuns. Inicialmente, a limitação ao fluxo aéreo pode ser leve e percebida apenas durante grandes esforços, mas com a progressão, a incapacidade respiratória torna-se evidente mesmo em atividades rotineiras. Nos estágios mais avançados, a DPOC compromete significativamente a qualidade de vida devido a exacerbações mais frequentes e graves, além da incapacidade funcional associada à insuficiência respiratória crônica. Fadiga, perda de peso, redução da massa muscular e caquexia também são comuns em casos graves, devido ao quadro inflamatório sistêmico<sup>2,6</sup> .  
A morbimortalidade por DPOC continua sendo um desafio significativo no Brasil, é a quinta causa de morte entre todas as idades. Nas últimas décadas, também foi a quinta maior causa de internação no Sistema Único de Saúde (SUS) entre pacientes com mais de 40 anos<sup>4</sup> , apesar da redução da taxa de mortalidade padronizada em 25,8% entre 2000 e 2019 e do aumento da idade média ao óbito de 73,2 para 76,0 anos<sup>5</sup> . No período, foram registrados 1.132.968 óbitos, representando 5,0% da mortalidade proporcional total de todos os óbitos registrados, sendo 67,6% como causa básica e 32,4% como associada. As principais causas básicas foram doenças respiratórias, enquanto insuficiência respiratória, pneumonia e septicemia se destacaram entre as causas associadas. A mortalidade foi maior durante o inverno, especialmente nas regiões Sudeste, Sul e Centro-Oeste, evidenciando a necessidade de estratégias preventivas mais eficazes<sup>5</sup> .  
A prevalência no país também apresentou uma redução de 13% nas últimas décadas, passando de 9.226,7 casos por 100.000 habitantes em 1990, para 8.025,3 casos por 100.000 habitantes em 2017. Nos anos analisados, a prevalência foi maior em mulheres do que em homens<sup>7</sup> . Anteriormente, o estudo PLATINO revelava uma prevalência de DPOC com taxas mais altas entre homens, idosos, tabagistas e pessoas com baixa escolaridade e maior exposição ocupacional a poeira<sup>6</sup> . Na população acima de 40 anos na região metropolitana de São Paulo, a prevalência foi de 15,8%, sendo maior entre os homens (18,0%) do que entre as mulheres (14,0%)<sup>8</sup> .  
Apesar da alta prevalência, a subnotificação da DPOC permanece elevada. No seguimento de nove anos do estudo PLATINO, verificou-se que 70% dos novos casos de DPOC não receberam diagnóstico médico, embora houvesse redução de 17,5% na taxa de subdiagnóstico em relação à fase inicial do estudo. Esse cenário reforça a necessidade da ampliação do uso da espirometria para melhorar a detecção e o tratamento precoce da doença<sup>9</sup> .  
2  
Projeções indicam que a prevalência e a carga global da DPOC voltarão a crescer nas próximas décadas, devido ao envelhecimento populacional e à persistente exposição a fatores de risco<sup>10,11</sup> . O número de casos de DPOC poderá atingir cerca de 600 milhões até 2050, representando um crescimento relativo de 23% em comparação com 2020<sup>12</sup> .  
Segundo o _Global Burden of Disease_ (GBD) 2017, a DPOC foi a terceira principal causa de morte por doenças crônicas no Brasil. Entre 1990 e 2017, houve uma redução de 42% na taxa de mortalidade padronizada por idade para ambos os sexos, embora a mortalidade tenha permanecido 30% maior entre os homens em comparação às mulheres. A doença também se manteve como a principal causa de anos de vida ajustados por incapacidade (DALYs) entre as doenças respiratórias crônicas, reforçando seu impacto na saúde pública do país<sup>7</sup> .  
Para identificação precoce da DPOC, é indicada a realização de espirometria em pacientes com sintomas respiratórios persistentes e/ou fatores de risco, como tabagismo prolongado (mais de 20 maços-ano), ex-tabagistas e infecções respiratórias recorrentes<sup>2</sup> .  
A prevenção primária envolve a identificação e redução da exposição a fatores de risco, sendo o tabagismo o principal determinante modificável da doença. A cessação do tabagismo é a intervenção mais eficaz para reduzir o risco de desenvolvimento e progressão da DPOC, devendo ser incentivada por meio de abordagens combinadas, como aconselhamento profissional e terapia medicamentosa. Além disso, a minimização da exposição a poluentes ambientais e ocupacionais, como poeiras, fumaça de biomassa e gases tóxicos, são definitivos na prevenção. Políticas públicas voltadas para a redução da poluição do ar e regulamentações para ambientes livres de tabaco são estratégias essenciais para mitigar o impacto desses fatores. A vacinação contra infecções respiratórias, como gripe e pneumonia, também contribui para a proteção da função pulmonar, especialmente em grupos vulneráveis<sup>2</sup> .  
O tratamento da DPOC é multidimensional, ou seja, combina abordagens não medicamentosas e medicamentosas. Entre as intervenções não medicamentosas, além da cessação do tabagismo, recomenda-se a redução da exposição a poluentes ambientais e ocupacionais, como fumaça de biomassa, poluição, poeiras e gases tóxicos. Também são recomendadas a prática de atividade física regular, alimentação adequada e saudável, educação em saúde e autocuidado, vacinação, reabilitação pulmonar e fisioterapia respiratória. Enquanto isso, a terapia medicamentosa é orientada pela avaliação dos sintomas e do risco de exacerbação, classificando os pacientes em três grupos (A, B e E). Essa abordagem permite a personalização do tratamento, garantindo o melhor controle da doença. Para os pacientes com obstrução grave ou muito grave (GOLD 3 e 4), a avaliação em atendimento especializado pode ser necessária para considerar opções terapêuticas avançadas, como o tratamento cirúrgico<sup>2</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde (APS) um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- J44.0 Doença pulmonar obstrutiva crônica com infecção respiratória aguda do trato respiratório inferior  
- J44.1 Doença pulmonar obstrutiva crônica com exacerbação aguda não especificada  
- J44.8 Outras formas especificadas de doença pulmonar obstrutiva crônica  
3

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **3. DIAGNÓSTICO** -->
O diagnóstico preciso da DPOC permite um cuidado terapêutico adequado, reduzindo sintomas, exacerbações e hospitalizações, além de melhorar a qualidade de vida e aumentar a sobrevida do paciente<sup>4</sup> . A avaliação deve ir além da obstrução ao fluxo aéreo, considerando a gravidade da doença, seu impacto funcional e o risco de eventos futuros. Comorbidades comuns, como doenças cardiovasculares, osteoporose e câncer de pulmão, devem ser identificadas e tratadas, pois afetam diretamente o prognóstico, independentemente do grau da obstrução<sup>2</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **3.1. Diagnóstico clínico** -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, racismo, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
O diagnóstico de DPOC deve ser considerado em pacientes tabagistas, ex-tabagistas ou com histórico de exposição ocupacional ou ambiental a agentes nocivos (forno a lenha, sílica, queima de biomassa, uso de carvão ou querosene para cozinhar ou aquecer), com mais de 40 anos<sup>13</sup> que apresentem sintomas respiratórios crônicos, incluindo tosse crônica, sibilância/chiado no peito, dispneia ao esforço e expectoração. No exame físico, sinais como cianose, tórax em barril/hiperinsuflação pulmonar e tiragem intercostal podem indicar doença em fase avançada<sup>2,14</sup> .  
Além da presença de sintomas respiratórios crônicos e fatores de risco, o diagnóstico clínico requer espirometria pósbroncodilatador, que confirma a presença de obstrução persistente ao fluxo aéreo quando a relação entre volume expiratório forçado em 1 segundo (VEF1) e a capacidade vital forçada (CVF) é um valor inferior a 0,7. Para valores entre 0,6 e 0,8, recomenda-se repetição da espirometria em outra ocasião, pois flutuações biológicas podem ocorrer<sup>2</sup> . Destaca-se a importância de investir em atividades de educação permanente e capacitação dos profissionais de saúde da atenção primária, a fim de garantir a realização de espirometrias de qualidade. A adequada formação contribui para reduzir falhas técnicas, aumentar a confiabilidade diagnóstica e fortalecer a resolutividade da APS.  
Em situações em que a espirometria não está disponível ou não pode ser realizada pelo paciente (idosos, déficit cognitivo, sarcopenia e/ou fragilidade, dificuldades para vedação bucal), podem ser utilizadas estratégias alternativas para apoiar o diagnóstico clínico. O uso do pico de fluxo expiratório (PEF), embora tenha baixa especificidade e não permita diferenciar padrões obstrutivos e restritivos de função pulmonar anormal, pode ser combinado com questionários clínicos validados para reforçar ou afastar a suspeita de DPOC<sup>15,16</sup> . Para interpretação dos resultados do PEF, recomenda-se utilizar os valores previstos derivados do padrão de Nunn & Gregg (1989) adotados nas linhas de cuidado do Ministério da Saúde<sup>17,18</sup> . Além disso, espirômetros eletrônicos portáteis pessoais podem ser fornecidos ao paciente, com a realização dos testes supervisionados por videochamada, quando possível<sup>19,20</sup> . Nessas circunstâncias, a avaliação diagnóstica deve considerar também a história clínica, sintomas e fatores de risco, podendo incluir exames de imagem como apoio à suspeita diagnóstica<sup>2</sup> .  
Em alguns casos, denominados ‘Pré-DPOC’, o indivíduo pode apresentar anormalidades estruturais ou funcionais, como enfisema, aprisionamento de ar ou declínio acelerado do VEF1, sem que haja obstrução ao fluxo aéreo (VEF1/CVF ≥ 0,7 pósbroncodilatador). O termo ‘PRISm’ (Espirometria com Relação Preservada e Alteração Funcional) também é utilizado para descrever pacientes com espirometria alterada, mas com relação VEF1/CVF normal. Esses pacientes devem ser considerados como tendo função pulmonar alterada e necessitam de seguimento clínico regular. Embora esses indivíduos tenham maior risco de desenvolver obstrução ao longo do tempo, nem todos evoluem para DPOC, e pesquisas são necessárias para definir a melhor abordagem terapêutica além da cessação do tabagismo<sup>2,21</sup> .  
4  
Em geral, as variações na relação VEF1/CVF pós-broncodilatador ocorrem conforme idade, sexo e altura. A aplicação indiscriminada do ponto de corte fixo (0,7) pode levar a sobrediagnóstico em idosos e subdiagnóstico em jovens. Isto porque o envelhecimento pulmonar reduz progressivamente o fluxo aéreo, podendo gerar falsos positivos em indivíduos mais velhos, enquanto em pacientes mais jovens com sintomas respiratórios crônicos e fatores de risco, uma relação VEF1/CVF ≥ 0,7, mas abaixo do limite inferior do previsto para idade e altura, pode indicar um estágio precoce da doença. Nessas situações, recomendase repetição da espirometria e, se necessário, avaliação por pneumologista para melhor elucidação diagnóstica<sup>2</sup> ( **Quadro 1** ). Sempre que possível, recomenda-se utilizar o limite inferior da normalidade (LLN) como referência para interpretação da relação VEF₁/CVF, por refletir com maior precisão os parâmetros esperados para a população brasileira.  
**Quadro 1 -** Elementos clínicos e funcionais para o diagnóstico de DPOC  
||**Elementos clínicos***|**Função pulmonar**|
|---|---|---|
|Sintomas respiratórios<br>crônicos|Fatores de risco|Distúrbio ventilatório obstrutivo|
|Tosse crônica<br>Expectoração<br>Sibilância<br>Dispneia<br>Respiração ofegante<br>Sensação de pressão torácica|Idade superior a 40 anos.<br>Externos: Tabagismo e exposição passiva ao tabaco,<br>poluição do ar e exposição a substâncias tóxicas<br>(vapores e poeiras químicas), inalação de gases<br>irritantes ou de material particulado em ambiente<br>ocupacional ou domiciliar, como fumaça de fogões a<br>lenha.<br>Genéticos: deficiência de alfa-1 antitripsina e história<br>familiar de DPOC.<br>Fatores relacionados à infância: prematuridade, baixo<br>peso ao nascer e infecções respiratórias na infância.<br>Outros: asma, tuberculose, HIV, infecções<br>broncopulmonares de repetição.|Espirometria: relação<br>VEF1/CVF inferior a 0,7 pós-<br>broncodilatador.|  
Legenda: CVF: capacidade vital forçada; DPOC: doença pulmonar obstrutiva crônica; HIV: vírus da imunodeficiência humana; VEF1: volume expiratório forçado em 1 segundo. *A gravidade da obstrução ao fluxo aéreo pode não refletir a intensidade dos sintomas ou o impacto na saúde, sendo necessária avaliação complementar com questionários validados. Fonte: Adaptado de GOLD 2025<sup>2</sup> .  
Na presença da relação VEF1/CVF inferior a 0,7, a severidade da obstrução do fluxo de ar é avaliada de acordo com a redução do VEF1 pós-broncodilatador, sendo classificada em leve, moderada, grave ou muito grave<sup>2,22,23</sup> . Entretanto, como o VEF1 não é bom preditor de sintomas e exacerbações, a gravidade da doença também deve ser avaliada com base no perfil de sintomas e na frequência das exacerbações ( **Quadro 2)** , com vistas à avaliação não somente do impacto da doença na qualidade de vida, mas também do risco de eventos futuros, como exacerbações e hospitalização<sup>2</sup> .  
**Quadro 2 -** Classificação espirométrica da gravidade da DPOC.  
|**Classificação**|**Espirometria**<br>VEF1/CVF inferior a 0,7|
|---|---|
|GOLD 1 (obstrução leve)|VEF1 ≥ 80% do previsto|
|GOLD 2 (obstrução moderada)|50% ≤ VEF1 < 80% do previsto|  
5  
|**Classificação**|**Espirometria**<br>VEF1/CVF inferior a 0,7|
|---|---|
|GOLD 3 (obstrução grave)|30% ≤ VEF1 < 50% do previsto|
|GOLD 4 (obstrução muito grave)|VEF1 < 30% do previsto|  
Legenda: CVF: capacidade vital forçada; VEF1: volume expiratório forçado em 1 segundo.  
Fonte: Adaptado de GOLD 2025<sup>2</sup> .  
A intensidade dos sintomas deve ser avaliada no momento do diagnóstico, pois é um fator a ser considerado na indicação do tratamento e na monitorização clínica. No entanto, a gravidade da obstrução do fluxo aéreo nem sempre se correlaciona diretamente com os sintomas relatados pelo paciente ou com o comprometimento de sua saúde, tornando necessária a avaliação formal por meio de questionários validados. Para este fim podem ser usadas as escalas mMRC (questionário de dispneia modificada do _British Medical Research Council_ )<sup>24</sup> ou CAT<sup>TM</sup> ( _COPD Assessment Test_ )<sup>25</sup> (Material Suplementar) podendo-se optar por aquela com maior familiaridade (Quadro 3). Além disso, é considerado de alto risco para exacerbações o paciente que apresentou duas ou mais exacerbações tratadas com antibiótico ou corticoide sistêmico no ambulatório (exacerbações moderadas) ou uma ou mais internações hospitalares por exacerbação (exacerbação grave) nos últimos 12 meses<sup>2,22</sup> .  
**Quadro 3 -** Classificação de risco da DPOC<sup>2</sup>  
|**Grupo**|**Perfil de sintomas/exacerbações**|
|---|---|
|Grupo A<br>Grupo de baixo risco|Pouco sintomáticos quando o resultado do mMRC está entre 0 e 1 e/ou do CAT é<br>menor que 10; nenhuma exacerbação ou uma moderada (sem hospitalização) nos<br>últimos 12 meses|
|Grupo B<br>Grupo de baixo risco|Muito sintomáticos quando o resultado do mMRC é igual ou maior a 2 e/ou do<br>CAT é igual ou maior que 10; nenhuma exacerbação ou uma moderada (sem<br>hospitalização) nos últimos 12 meses|
|Grupo E<br>Grupo de alto risco|Uma ou mais exacerbações graves (levando a hospitalização) OU duas ou mais<br>exacerbações moderadas nos últimos 12 meses, independentemente do grau de<br>sintomatologia (mMRC ou CAT).|  
Legenda: CAT<sup>TM</sup> : _COPD assessment test_ ; mMRC: questionário de dispneia modificada do _British Medical Reseach Council_  
A classificação ABE, anteriormente ABCD, é utilizada para classificar o grupo de risco e perfil sintomático para determinar o tratamento inicial da DPOC. Esse novo formato reestruturou os grupos englobando os pacientes dos grupos C e D em um grupo E, com maior risco de exacerbações<sup>2</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **3.2. Diagnóstico laboratorial** -->
**Hemograma completo:** é um exame útil para avaliar anemia (indicativa de deficiência nutricional, perda sanguínea ou doença crônica) e policitemia, indicativa de hipoxemia crônica. A anemia pode ser um fator agravante da dispneia e da baixa tolerância ao exercício. Fatores reversíveis, como uso prolongado de oxigênio, inibidores da enzima conversora de angiotensina, bloqueadores de receptor de angiotensina II e disfunção renal, devem ser investigados. Policitemia em pacientes com saturação periférica de oxigênio (SpO2) em vigília superior a 90% sugere hipoxemia durante o sono. Deve ser solicitado na primeira consulta, caso não tenha sido realizado nos últimos 4 a 6 meses<sup>2,25</sup> . A contagem de eosinófilos também pode ser útil para avaliar a resposta ao tratamento com corticoterapia inalatória (como terapia adicional ao broncodilatador de manutenção)<sup>2</sup> .  
**Oximetria em repouso:** preconiza-se a avaliação de SpO2 na primeira consulta e, sempre que possível, durante o acompanhamento clínico. Em pacientes com VEF1 < 50%, deve ser aferida em todas as consultas. Se SpO2 for menor que 92%, é indicada a gasometria arterial para avaliar a gravidade da hipoxemia e a necessidade de oxigenoterapia<sup>2</sup> .  
6  
**Dosagem de alfa-1-antitripsina:** deve ser considerada para casos de enfisema pulmonar panlobular com predomínio basal de início precoce (antes da 4ª década), especialmente em não tabagistas. A deficiência da atividade de alfa-1-antitripsina (AAT) é definida por nível sérico inferior a 11 micromol/L (menor que 80 mg/dL). Esta deficiência geralmente se encontra em combinação com o genótipo grave de AAT para os alelos deficientes mais comuns (S e Z) e alguns outros menos frequentes, mas que podem ser confundidos com o alelo M, como os alelos Mmalton ou Mprocida. Homozigotos para alelo Z apresentam nível sérico mais baixo de AAT (abaixo de 30 mg/dL) e têm maior risco de desenvolver enfisema grave. A genotipagem é indicada na presença de nível sérico compatível com deficiência, sendo realizada em amostra de sangue por meio da reação em cadeia da polimerase (PCR) ou análise da curva de fusão<sup>2,14,26–28</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **3.3. Diagnóstico diferencial** -->
Outras doenças podem apresentar quadro clínico semelhante à DPOC, como asma, insuficiência cardíaca e bronquiectasias, devendo ser excluídas como causa dos sintomas ( **Quadro 4** ).  
**Quadro 4 -** Principais diagnósticos diferenciais da DPOC<sup>2,23</sup>  
|**Diagnóstico**|**Aspectos comuns entre as doenças**|**Aspectos diferenciais**|
|---|---|---|
|Asma| Sintomas associados a obstrução do fluxo de<br>ar, de caráter crônico e com episódios de<br>agravamento;<br> Asmáticos com doença não controlada em<br>longo prazo podem ter obstrução do fluxo de<br>ar de caráter não reversível (remodelamento<br>brônquico).| Início na infância e presença de alergia<br>respiratória e/ou atopia na maioria dos casos;<br> História familiar de asma;<br> Obstrução ao fluxo de ar de caráter reversível;<br> Piora dos sintomas à noite ou pela manhã;<br> Diferente fisiopatologia, sem relação causal com<br>tabagismo;<br> Associada a obesidade;<br> Boa resposta à corticoterapia com melhor<br>prognóstico em longo prazo com tratamento<br>(espirometria sem evidência de obstrução ao<br>fluxo de ar após curso de tratamento exclui o<br>diagnóstico de DPOC).|
|| Tosse<br>com<br>expectoração<br>crônica,| Tomografia<br>de<br>tórax<br>revela<br>achado<br>de|
|Bronquiectasias|frequentemente purulenta;<br> Dispneia e obstrução do fluxo de ar.|bronquiectasias<br>com<br>base<br>fisiopatológica<br>diferente.|
|Bronquiolite<br>obliterante| Pode<br>iniciar<br>na<br>infância,<br>em<br>geral<br>desencadeada por infecções virais;<br> Pode ser causada por inalações tóxicas,<br>doenças autoimunes, após transplante de<br>pulmão ou de medula óssea.| Tomografia<br>de<br>tórax<br>pode<br>mostrar<br>bronquioloectasias, nódulos centrolobulares e<br>sinais de aprisionamento aéreo na expiração.|
||| Responde bem ao tratamento com diuréticos;|
|Insuficiência cardíaca<br>congestiva| Congestão pulmonar pode desencadear<br>dispneia, tosse e sibilos.| Apresenta tosse não produtiva ou mucoide;<br> Exames radiológicos com sinais de edema<br>pulmonar ou cardiomegalia.|  
7  
|**Diagnóstico**|**Aspectos comuns entre as doenças**|**Aspectos diferenciais**|
|---|---|---|
|Tuberculose| Tosse com expectoração purulenta ou com<br>sangue.| Radiografia ou tomografia de tórax pode mostrar<br>cavitações, infiltrações nos lobos superiores e<br>fibrose residual.|  
Fonte: Adaptado de GOLD 2025<sup>2</sup> e Sociedade Brasileira de Pneumologia e Tisiologia 2024<sup>23</sup> .  
A radiografia de tórax (posteroanterior e perfil) é utilizada para avaliar comprometimento pulmonar, como bronquite crônica e enfisema, e verificar a ocorrência de comorbidades associadas como nódulos pulmonares, sequela de tuberculose, sinais de insuficiência cardíaca, entre outros. Achados como espessamento brônquico, ou mesmo áreas de enfisema, não associados a limitação ventilatória e a sintomas de DPOC não são suficientes para o diagnóstico<sup>2,14,22</sup> . Preconiza-se a sua realização na primeira consulta, caso não tenha sido realizado nos últimos 12 meses<sup>23</sup> .  
A tomografia computadorizada é mais sensível e específica na identificação de alterações estruturais pulmonares, como enfisema, espessamento brônquico e aprisionamento aéreo. Esses achados, quando associados à história clínica e fatores de risco, podem reforçar a suspeita diagnóstica de DPOC, especialmente em casos de espirometria inconclusiva ou limítrofe. No entanto, alterações tomográficas isoladas, sem sintomas respiratórios ou evidência funcional de obstrução ao fluxo aéreo, não são suficientes para estabelecer o diagnóstico<sup>2</sup> .  
O eletrocardiograma em repouso e ecocardiograma são procedimentos indicados em caso de suspeita de hipertensão pulmonar e cor pulmonale (obstrução ao fluxo de ar que pode variar de moderada a grave, hipoxemia crônica e sinais clínicos de disfunção ventricular direita). Estão indicadas também para avaliar cardiopatias primárias, conforme suspeita clínica<sup>2,14</sup> .  
Recomenda-se a avaliação de estado nutricional e sintomas psiquiátricos, especialmente depressão e ansiedade, comorbidades frequentes e subdiagnosticadas na DPOC associadas a pior qualidade de vida. Preconiza-se avaliar o perfil de risco cardiovascular, frequentemente elevado nesses pacientes. Outras comorbidades comuns que devem ser identificadas e monitoradas incluem osteoporose, diabete melito, asma e refluxo gastroesofágico. Além disso, a doença periodontal, frequentemente associada ao tabagismo, aumenta o risco de infecções respiratórias e deve ser identificada e tratada para reduzir complicações pulmonares<sup>2,29</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com diagnósticos clínico e funcional de DPOC, definido pela presença de quadro clínico compatível (ver item 3. Diagnóstico) **e** distúrbio ventilatório de tipo obstrutivo apontado por espirometria **ou** por estratégias alternativas de apoio ao diagnóstico clínico, nas situações em que a espirometria não está disponível ou não pode ser realizada pelo paciente.  
Adicionalmente, para uso das associações duplas de um broncodilatador beta-2 agonista de longa ação com um antimuscarínico de longa ação (LAMA+LABA) e triplas de um LAMA/LABA com um corticoide inalatório (LAMA+LABA+ICS), indicadas neste Protocolo, o paciente deverá apresentar:  
- brometo de umeclidínio + trifenatato de vilanterol: DPOC sintomáticos do grupo B ou E, independentemente do grau  
- de obstrução;  
- tiotrópio monoidratado + cloridrato de olodaterol **ou** furoato de fluticasona + brometo de umeclidínio + trifenatato de  
- vilanterol **ou** dipropionato de beclometasona 100 µg + fumarato de formoterol di-hidratado 6 µg + brometo de glicopirrônio 12,5 µg: DPOC grave ou muito grave (grau de obstrução GOLD 3 e 4), com perfil exacerbador (grupo E);  
8  
Nota: Para pacientes com VEF1 menor que 50% e dificuldade no uso de inalador de pó seco, recomenda-se uso da apresentação em névoa suave da associação dupla tiotrópio monohidratado + cloridrato de olodaterol, uma vez que essa forma de administração pode melhorar a efetividade do tratamento.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo aqueles pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso dos respectivos medicamentos ou procedimentos preconizados para tratamento da DPOC.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **6. CASOS ESPECIAIS** -->
É incomum haver pacientes com DPOC gestantes ou que estejam amamentando, dada a faixa etária de início da doença. No caso de gestação intercorrente, recomenda-se o acompanhamento em centro de referência para gestação de alto risco.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7. TRATAMENTO** -->
De acordo com a gravidade dos sintomas e o risco de exacerbação, segundo a classificação ABE, determina-se o tratamento medicamentoso da DPOC, baseado na broncodilatação por via inalatória. Além disso, a contagem de eosinófilos sanguíneos deve ser considerada para orientar a indicação de corticoide inalatório (ICS), pois níveis elevados podem indicar maior benefício com essa classe de fármacos<sup>2</sup> .  
Complicações como hipoxemia e cor pulmonale são indicativos da necessidade de oxigenoterapia. As preferências do paciente e a presença de comorbidades devem ser consideradas na individualização do tratamento, respeitando-se as indicações preconizadas neste PCDT. O aconselhamento para cessação do tabagismo tem papel fundamental, em todos os níveis de atenção, uma vez que a manutenção está associada a pior prognóstico, e reduz significativamente a efetividade de intervenções medicamentosas, especialmente da corticoterapia inalatória<sup>2,13,30</sup> . Devido às particularidades da evolução da doença, pacientes com deficiência de alfa-1-antitripsina devem ser encaminhados para avaliação/acompanhamento em serviço especializado em pneumologia. Estudos de fase III que avaliaram a reposição da proteína nestes pacientes tiveram limitações metodológicas importantes, como a avaliação deficiente de desfechos de mortalidade e eventos adversos. Não houve diferença na qualidade de vida comparativamente ao placebo<sup>14,27,31</sup> .  
Para pacientes do Grupo A, o tratamento deve ser baseado no uso de broncodilatadores de curta ação ou longa ação. Para pacientes do Grupo B, recomenda-se como tratamento inicial preferencial a combinação de broncodilatadores de longa ação (LAMA+LABA), de brometo de umeclidínio + trifenatato de vilanterol, indicada para pacientes sintomáticos, independentemente do grau de obstrução. A monoterapia com LAMA ou LABA pode ser considerada em casos selecionados, como quando a combinação não for disponível, tolerada ou apropriada. Nos pacientes do Grupo E, a combinação LAMA+LABA também é a escolha preferencial. A associação umeclidínio + vilanterol pode ser utilizada nesse grupo conforme julgamento clínico, e não está condicionada à gravidade espirométrica. O uso de tiotrópio monoidratado + cloridrato de olodaterol é indicado para pacientes com grau de obstrução GOLD 3 ou 4 (VEF1 menor que 50%), com perfil exacerbador (Grupo E). Em pacientes com dificuldade no uso de inaladores de pó seco, é recomendada a apresentação em névoa suave<sup>2</sup> .  
O uso de LABA + ICS não é recomendado de forma geral, mas se o uso de ICS for indicado é preferível a combinação LAMA+LABA+ICS, especialmente em pacientes com contagem absoluta de eosinófilos no sangue igual ou maior que 300  
9  
células/µL, devido à correlação entre eosinofilia e resposta ao ICS. Em pacientes que já fazem uso contínuo de ICS, com boa resposta clínica e histórico de exacerbações, especialmente sob regime de terapia tripla aberta com múltiplos dispositivos, a reavaliação da contagem de eosinófilos não é necessária para justificar a manutenção do esquema terapêutico. Sempre que disponível, recomenda-se a utilização de combinações terapêuticas em um único dispositivo, com o objetivo de facilitar o uso, otimizar o tratamento e melhorar a adesão<sup>23</sup> . Além disso, todos os pacientes devem ter acesso a broncodilatadores de curta ação para alívio imediato dos sintomas<sup>2</sup> ( **Quadro 5** ).  
**Quadro 5 -** Tratamento medicamentoso e conduta complementar conforme diferentes níveis de sintomas e classificação de risco da DPOC em paciente clinicamente estável<sup>2</sup>  
|**Classificação**|**Tratamento medicamentoso**|**Conduta terapêutica complementar**|
|---|---|---|
|Grupo A|Broncodilatador de curta ou longa ação,<br>conforme necessidade:<br>- Considerar SAMA ou SABA para alívio<br>imediato de sintomas;<br>- Considerar LABA se sintomas frequentes,<br>conforme avaliação clínica.|- Realizar aconselhamento antitabagismo;<br>- Estimular a prática de atividades físicas regulares;<br>- Avaliar indicação de terapia medicamentosa para<br>cessação do tabagismo (sinais de dependência<br>elevada à nicotina)<sup>a</sup>;<br>- Avaliar e tratar comorbidades;<br>- Orientar medidas de autocuidado para exacerbações;<br>- Indicar vacinação, se apropriado;<br>- Monitorar sintomas e comprometimento funcional<br>(espirometria, escala mMRC), estado nutricional,<br>resposta e tolerância ao tratamento medicamentoso,<br>bem como revisar técnica de uso de dispositivos<br>inalatórios em cada consulta;<br>- Realizar tratamento preferencialmente na APS.|
|Grupo B|Broncodilatação de longa ação contínua:<br>- LAMA + LABA* em uso contínuo:<br>brometo de umeclidínio + trifenatato de<br>vilanterol;<br>- Considerar SAMA ou SABA para alívio<br>imediato de sintomas;|Todas as medidas do Grupo A e adicionalmente:<br>- Considerar avaliação por pneumologista<sup>b</sup>;<br>- Considerar reabilitação pulmonar de acordo com<br>disponibilidade;<br>- Revisar esquema vacinal.|
|Grupo E|**Tratamento inicial preferencial**:<br>LAMA + LABA* em uso contínuo:<br>- brometo de umeclidínio + trifenatato de<br>vilanterol independentemente do grau de<br>obstrução e perfil sintomático;<br>**ou**<br>- tiotrópio monoidratado + cloridrato de<br>olodaterol, quando grau de obstrução GOLD<br>3 ou 4 (VEF1 menor que 50%), com perfil|Todos as medidas dos Grupos A e B e adicionalmente:<br>- Avaliar trocas gasosas periodicamente (SpO2e<br>gasometria arterial);<br>- Excluir tabagismo ativo como causa de resposta<br>inadequada ao ICS;<br>- Avaliar função pulmonar completa (volumes e<br>capacidades pulmonares, difusão pulmonar, teste de<br>caminhada), especialmente na presença/suspeita de|
||exacerbador (Grupo E).|comorbidade<br>pulmonar<br>ou<br>cardiovascular<br>significativa;|  
10  
|**Classificação**|**Tratamento medicamentoso**|**Conduta terapêutica complementar**|
|---|---|---|
||**Tratamento com LAMA + LABA + ICS*,**<br>**quando indicado ICS:**<br>- Contagem de eosinófilos ≥ 300 células/µL;<br>- Exacerbações frequentes e contagem de<br>eosinófilos entre ≥ 100 e < 300 células/µL,<br>considerar ICS individualmente;<br>ou<br>- Exacerbações persistirem em uso de<br>LAMA + LABA.|- Avaliar sinais de depressão;<br>- Monitorar sinais de cor pulmonale;<br> Avaliar indicação de tratamento cirúrgico (cirurgia<br>redutora se enfisema bolhoso ou heterogêneo, ver<br>item 7.1.4);<br>- Recomendar<br>acompanhamento<br>em<br>serviço<br>especializado em Pneumologia.|
||Evitar ICS se:<br>- Contagem de eosinófilos < 100 células/µL<br>ou histórico de pneumonia.||
||- Considerar SAMA ou SABA, para alívio<br>imediato de sintomas.||  
Notas:<sup>a</sup> Aplicar o teste de Fagerström<sup>32</sup> e estágios de motivação para a cessação do tabagismo<sup>33</sup> (Material Suplementar).<sup>b</sup> A avaliação por um pneumologista é uma recomendação, quando clinicamente necessária, e não restringe o cuidado a essa especialidade médica. * A terapia com inalador único pode ser mais conveniente e aumentar a adesão ao tratamento, se comparado a múltiplos inaladores.  
Legenda: ICS: corticoide inalatório; LABA: broncodilatadores beta-2 agonistas de longa ação; LAMA: broncodilatadores antimuscarínicos de longa ação; mMRC: questionário de dispneia modificada do _British Medical Reseach Council;_ SABA: broncodilatadores beta-2 agonistas de curta ação; SAMA: broncodilatadores antimuscarínicos de curta ação; SpO2: saturação periférica de oxigênio.  
Quanto às exacerbações, na sua avaliação inicial deverão ser identificadas as causas (infecciosas ou não infecciosas) e os sinais de gravidade, bem como deverá ser ajustado o esquema de broncodilatadores de curta ação, iniciando-se com corticoides sistêmicos ou antibióticos se adequado<sup>2,14,34</sup> . A hospitalização deve ser indicada conforme a gravidade e os fatores de risco para complicações, quais sejam:  
- Resposta insatisfatória ao tratamento ambulatorial;  
- Piora significativa da dispneia;  
- Prejuízo no sono ou na alimentação devido aos sintomas;  
- Agravamento de hipoxemia (PaO₂ < 50 mmHg);  
- Agravamento da hipercapnia/acidose respiratória aguda (pH < 7,3);  
- Alteração no estado mental;  
- Incapacidade para o autocuidado ou falta de suporte domiciliar;  
- Incerteza diagnóstica; e  
- Comorbidades clinicamente significativas, como pneumonia, cardiopatia, diabete melito ou insuficiência renal.  
Recomenda-se a adoção de medidas educativas, incluindo planos escritos de ação, orientando os pacientes sobre medidas  
iniciais de autocuidado em caso de exacerbações e sobre quando procurar atendimento médico<sup>2</sup> .  
11

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1      Tratamento não medicamentoso** -->
O tratamento de fatores de risco faz parte das estratégias do governo federal, dispostas no Plano de Ações Estratégicas para o Enfrentamento das Doenças Crônicas Não Transmissíveis no Brasil para 2021-2030<sup>35</sup> . Para fortalecimento da integração entre a Atenção Primaria à Saúde (APS) e Atenção Especializada à Saúde, recomenda-se a utilização das Linhas de Cuidado do Ministério da Saúde<sup>4</sup> , os protocolos de regulação/encaminhamentos do Ministério da Saúde e o Telessaúde Brasil Redes (0800 644 6543).  A Rede de Atenção à Saúde (RAS) deve ser organizada para que a APS seja a principal porta de entrada do SUS e o centro de comunicação com toda a rede, coordenando o cuidado e ordenando as ações e serviços disponibilizados.  
As pessoas com DPOC devem ser acompanhadas pela atenção primária, o que inclui ações de promoção da saúde, prevenção primária e secundária e encaminhamento para diagnóstico e tratamento precoces, visando à equidade e à qualidade de vida e reduzindo as vulnerabilidades e os riscos relacionados aos determinantes sociais, econômicos, políticos, culturais e ambientais<sup>36,37</sup> .  
As equipes que atuam na APS podem ofertar ações para a promoção da prática de atividade física regular, alimentação adequada e saudável, educação em saúde e autocuidado, vacinação e reabilitação, que podem ser realizadas nas unidades de saúde ou em outros equipamentos sociais nos territórios. Recomenda-se estimular a autonomia dos pacientes, orientando sobre os fatores de risco, especialmente o tabagismo, além das características da doença, metas do tratamento, uso correto dos medicamentos e dispositivos inalatórios, reconhecimento e o tratamento de exacerbações e estratégias para minimizar as crises<sup>4</sup> .  
Os profissionais de saúde da APS podem estimular a redução dos seguintes fatores de risco: cessação do tabagismo; evitar a exposição à fumaça de cigarro passiva, poluição do ar, vapores químicos, fumaça tóxica de combustíveis de cozinha e aquecimento; utilizar equipamentos de proteção respiratória adequados no local de trabalho; e manter a ventilação adequada dentro de casa<sup>4</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.1.  Cessação do tabagismo** -->
A cessação do tabagismo é a intervenção mais eficaz para reduzir a progressão da DPOC e deve ser reforçada em todas as consultas. O aconselhamento sobre abandono do tabaco deve ser estruturado e considerar estratégias comportamentais, como abordagem mínima, terapia cognitivo-comportamental e programas intensivos de apoio<sup>2,14,38–40</sup> . O tratamento medicamentoso deve ser considerado nos casos com taxas elevadas de dependência à nicotina<sup>2,14,30</sup> , conforme o Protocolo Clínico e Diretrizes Terapêuticas do Tabagismo vigente<sup>32</sup> do Ministério da Saúde.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.2. Reabilitação pulmonar e fisioterapia respiratória** -->
A inserção de pacientes com DPOC em um programa de reabilitação pulmonar contribui para a melhora da qualidade de vida, e a participação precoce pode trazer benefícios sustentados a longo prazo, como redução de exacerbações, hospitalização e melhora da capacidade para realizar exercícios físicos. O programa de exercícios promove recondicionamento físico e cardiovascular, além de treinamento muscular de membros superiores e inferiores e de resistência física ( _endurance_ ). Neste programa devem ser priorizados os pacientes com dispneia associada à baixa tolerância ao exercício ou restrição para atividades diárias (pontuação na escala mMRC > 2)<sup>2,14,38–40</sup> . Em caso de indisponibilidade de serviços de reabilitação pulmonar, os profissionais de saúde devem estimular os pacientes com DPOC a praticar atividades físicas no domicílio ou em centros comunitários com acompanhamento profissional sempre que possível. As atividades recomendadas incluem caminhadas, subir e descer escadas, sentar e levantar da cadeira, usas pesos leves para fortalecimento de membros superiores e treinamento funcional baseado em atividades diárias<sup>2,41,42</sup> .  
12  
A telerreabilitação, como a promovida pelo Telessaúde Brasil Redes, emergiu como uma alternativa eficaz para pacientes sem acesso a programas presenciais. Modelos que incluem sessões online supervisionadas, vídeos educativos e monitoramento remoto demonstraram benefícios equivalentes à reabilitação tradicional<sup>41,42</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.3.  Oxigenoterapia** -->
A oxigenoterapia domiciliar contínua, por mais de 15 horas/dia, reduz a mortalidade em pacientes com hipoxemia grave crônica e está indicada para pacientes que preencham os critérios abaixo<sup>2,43</sup> :  
- PaO2 < 55 mmHg ou SpO2 < 88%, com ou sem hipercapnia, confirmado em duas ocasiões ao longo de um período de três semanas; ou  
- PaO2 entre 55 mmHg e 60 mmHg ou SpO2 igual a 88%, quando houver evidência de hipertensão pulmonar, edema periférico sugestivo de insuficiência cardíaca congestiva ou policitemia (hematócrito > 55%).  
Quando houver indicação de oxigenoterapia de longa duração, deve-se ajustar o fluxo de oxigênio necessário para manter PaO2 de pelo menos 50 mmHg e SpO2 ≥ 90%<sup>2</sup> , por meio de teste por pelo menos 30 minutos com cateter ou óculos nasais. Reavaliar a cada consulta, mensalmente. A duração mínima diária deve ser de 15 horas, utilizando-se também durante o sono e o exercício. De forma geral, incentiva-se o uso de equipamentos concentradores de oxigênio, por seu menor custo final. O fumo ativo é uma contraindicação relativa à oxigenoterapia domiciliar devido ao risco de explosão, e pacientes devem estar cientes dos riscos<sup>44.</sup>

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.4.  Tratamento cirúrgico** -->
Pacientes com obstrução grave ou muito grave (GOLD 3 ou 4), com idade elegível, conforme o Regulamento Técnico do Sistema Nacional de Transplante, tabagistas ou não, sem comorbidades graves, que permanecem muito sintomáticos após tratamento medicamentoso otimizado por 4 a 6 meses e reabilitação pulmonar, devem ser avaliados em serviços especializados (Pneumologia e Cirurgia Torácica) para verificar a  possibilidade de tratamento cirúrgico, como cirurgia redutora de volume e transplante pulmonar. Pacientes com enfisema bolhoso heterogêneo avaliados para necessidade de bulectomia, particularmente se a bolha estiver contribuindo significativamente para a limitação ventilatória. O transplante pulmonar deve ser considerado para casos de insuficiência respiratória grave e progressiva, quando não há resposta satisfatória às demais intervenções<sup>2,45</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.5.  Ventilação mecânica não invasiva** -->
A ventilação não invasiva (VNI), especialmente na forma de ventilação com pressão positiva (NPPV, na sigla em inglês), é uma estratégia consolidada no tratamento da DPOC em diferentes contextos clínicos:  
- Fase aguda: a VNI é considerada padrão de cuidado para pacientes hospitalizados com exacerbação da DPOC e insuficiência respiratória aguda, particularmente na presença de hipercapnia. Seu uso contribui para reduzir complicações, tempo de internação e mortalidade, quando comparado à ventilação mecânica invasiva precoce;  
- Uso crônico domiciliar: em pacientes com insuficiência respiratória crônica hipercápnica estável, a VNI de longo prazo pode ser indicada como medida complementar ao tratamento otimizado, desde que haja viabilidade de adesão ao suporte ventilatório;  
- Insuficiência respiratória aguda sobre crônica (IRpA/C): em pacientes com DPOC estável que apresentam exacerbação aguda e, após estabilização, mantêm hipercapnia persistente, a VNI pode ser utilizada de forma prolongada no domicílio. Nesses casos, níveis elevados de pressão inspiratória podem trazer benefícios clínicos, incluindo redução da morbimortalidade.  
13  
A decisão pelo uso da VNI deve ser individualizada e conduzida por equipe especializada, considerando a gravidade clínica, a resposta ao tratamento otimizado, a persistência de hipercapnia, a tolerância do paciente e a disponibilidade de recursos para monitoramento e seguimento adequados<sup>2</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.1.6.  Ventilação mecânica invasiva** -->
A ventilação mecânica invasiva (VMI) está indicada para pacientes com DPOC em situações de insuficiência respiratória aguda grave, quando não é possível tolerar a VNI ou diante de falha dessa estratégia. Outras indicações incluem: parada cardiorrespiratória ou pós-parada; rebaixamento do nível de consciência ou agitação psicomotora não controlada adequadamente por sedação; aspiração maciça ou vômitos persistentes; incapacidade persistente de remover secreções respiratórias; instabilidade hemodinâmica grave sem resposta a fluidos e medicamentos vasoativos; arritmias ventriculares ou supraventriculares graves; e hipoxemia grave em pacientes que não toleram VNI.  
Quando indicada, a VMI deve ser instituída preferencialmente em ambiente hospitalar com suporte de terapia intensiva, considerando a provável reversibilidade do evento precipitante, as condições clínicas do paciente, suas preferências e a disponibilidade de recursos especializados. Embora essencial em situações específicas, a VMI envolve riscos relevantes, como pneumonia associada à ventilação, barotrauma, volutrauma e necessidade de traqueostomia com ventilação prolongada.  
No âmbito do SUS, a VMI também está disponível para insuficiência respiratória crônica no Serviço de Atenção Domiciliar, do Programa Melhor em Casa. Nesses casos, a indicação deve seguir critérios clínicos específicos e fluxos assistenciais estabelecidos, assegurando acesso adequado e seguro a essa modalidade de suporte ventilatório.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.2      Tratamento medicamentoso** -->
O tratamento medicamentoso da DPOC é baseado no uso de broncodilatadores de longa ação, com ou sem corticoides inalatórios, dependendo da gravidade dos sintomas, do histórico de exacerbações e da presença de inflamação eosinofílica. A escolha da terapia deve ser individualizada, considerando não apenas a função pulmonar, mas também o impacto da doença nos sintomas e no risco de exacerbações. A abordagem segue o esquema ABE, que classifica os pacientes conforme a intensidade dos sintomas e a frequência de exacerbações<sup>2</sup> .  
A via inalatória deve ser a primeira escolha para administração de broncodilatadores e corticoides, e os dispositivos inalatórios devem ser adequados às habilidades do paciente. Nebulímetros dosimétricos (aerossóis) e cápsulas para inalação, são as apresentações preferenciais para a administração de medicamentos inalatórios, devido à portabilidade, menor custo de manutenção e menor risco de contaminação por agentes infecciosos. Entretanto, a escolha do dispositivo deve considerar a capacidade do paciente de gerar fluxo inspiratório suficiente para a inalação eficaz do medicamento<sup>2,46,47</sup> .  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.  
14

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Broncodilatadores beta-2 agonistas de curta ação (SABA):** -->
Os SABA, como **sulfato de salbutamol** e **bromidrato de fenoterol** , são indicados para o tratamento dos sintomas decorrentes da obstrução ao fluxo de ar (dispneia, sibilância, intolerância ao exercício). Seu efeito broncodilatador inicia-se em poucos minutos e pode durar de 4 a 6 horas. Esses medicamentos devem ser utilizados sob demanda, para controle de sintomas episódicos ou exacerbações, mas não são indicados para o tratamento de manutenção. Geralmente são empregados para alívio de sintomas agudos e podem ser indicados em qualquer fase da doença, como monoterapia nos casos com sintomas leves e intermitentes (grupo A) ou como terapia sintomática de adição ao tratamento de manutenção nos demais grupos. A falta de resposta espirométrica aguda ao broncodilatador não exclui um possível benefício em longo prazo<sup>2</sup> .  
Os eventos adversos mais comuns com o uso destes SABA incluem tremores, cefaleia, nervosismo, taquicardia, palpitações, câimbras musculares e irritação na boca e garganta. Também pode ocorrer hipocalemia, especialmente em doses elevadas ou em uso prolongado. Durante exacerbações moderadas a graves, pode haver piora transitória da oxigenação arterial. Eventos adversos menos frequentes, mas potencialmente graves, incluem arritmias cardíacas (como fibrilação atrial, taquicardia supraventricular e extrassístoles), broncoespasmo paradoxal, angioedema, urticária e outras reações de hipersensibilidade, como rash cutâneo<sup>48,49</sup> .  
As contraindicações do salbutamol incluem hipersensibilidade à substância ativa ou a qualquer um dos excipientes da fórmula. Já o fenoterol é contraindicado em casos de cardiomiopatias hipertróficas obstrutivas, taquiarritmias, e em pacientes com hipersensibilidade ao bromidrato de fenoterol ou a outros componentes da formulação. O uso de ambos os medicamentos deve ser feito com cautela em pacientes com doenças cardiovasculares, hipertireoidismo, diabete melito e em uso concomitante com outros simpatomiméticos<sup>48,49</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Broncodilatadores antimuscarínicos de curta ação (SAMA):** -->
O SAMA disponível no SUS é o **brometo de ipratrópio** , cujo mecanismo de ação é bloquear os receptores muscarínicos da árvore brônquica, com efeito broncodilatador relacionado ao bloqueio M3. Tem início de ação em 1 a 3 minutos e pico em 1,5 a 2 horas, com duração de ação de 4 a 6 horas, sendo mais lento do que os SABA<sup>50</sup> . O uso em esquema fixo, regular ou conforme necessário para alívio de dispneia leva à melhora sintomática e aumenta a tolerância ao exercício, podendo ser também usado em associação com um SABA durante as exacerbações<sup>2</sup> .  
Os eventos adversos mais comuns (1% a 10%) associadas ao uso de brometo de ipratrópio incluem tosse, boca seca, náusea, cefaleia, tontura, irritação na garganta e distúrbios gastrointestinais. Reações incomuns (0,1% a 1%) abrangem palpitações, taquicardia supraventricular, broncoespasmo, retenção urinária (especialmente em pacientes com hiperplasia prostática), rash cutâneo, prurido, visão turva e aumento da pressão intraocular. Eventos mais raros (< 0,1%) incluem fibrilação atrial, reação anafilática, edema orofaríngeo, glaucoma de ângulo fechado e complicações oculares graves secundárias à exposição acidental do aerossol nos olhos<sup>51</sup> .  
Esse medicamento é contraindicado em pacientes com hipersensibilidade ao próprio princípio ativo, à atropina ou seus derivados, ou a qualquer componente da fórmula. Deve ser utilizado com cautela em indivíduos com glaucoma de ângulo fechado, retenção urinária, hiperplasia prostática e distúrbios de motilidade gastrintestinal<sup>51</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Broncodilatadores beta-2 agonistas de longa ação (LABA):** -->
Os LABA são a base do tratamento de manutenção da DPOC, proporcionando alívio sustentado da dispneia e melhora da função pulmonar. São preferencialmente empregados no tratamento ambulatorial de pacientes com sintomas persistentes, reduzindo exacerbações e hospitalizações. Apenas o **fumarato de formoterol** está disponível no SUS e resulta em broncodilatação por até 12 horas<sup>2</sup> .  
Os eventos adversos mais comuns do uso de formoterol (ocorrendo em 1% a 10% dos casos) são cefaleia, tremor e palpitações. Reações incomuns (0,1% a 1%) incluem taquicardia, tontura, espasmos musculares, mialgia, agitação, ansiedade,  
15  
insônia, boca seca, broncoespasmo (incluindo broncoespasmo paradoxal) e irritação na garganta. Eventos muito raros (< 0,01%) incluem disgeusia, edema periférico, náusea, hipopotassemia, hiperglicemia, angina pectoris, arritmias cardíacas (como fibrilação atrial, taquiarritmia, extrassístoles), tosse e reações de hipersensibilidade como urticária, erupção cutânea, angioedema e prurido. Esse medicamento está contraindicado para pacientes com hipersensibilidade conhecida à substância ativa ou a qualquer um dos excipientes da formulação<sup>52</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Broncodilatadores antimuscarínicos de longa ação (LAMA):** -->
O **brometo de glicopirrônio** , **brometo de tiotrópio** e **brometo de umeclidínio** são LAMA que proporcionam broncodilatação sustentada e redução de exacerbações, sendo indicados para tratamento de manutenção em pacientes com sintomas persistentes ou exacerbações frequentes devido à duração do efeito broncodilatador de 22 a 24 horas. Estudos apontam que a broncodilatação dupla com um LABA pode ser benéfica na melhora de sintomas e da qualidade de vida, quando comparados com broncodilatação com qualquer dos agentes em uso isolado, sem aumento significativo nos eventos adversos<sup>53–</sup> 61. Inexistem evidências definitivas de superioridade clínica de um LAMA em relação a outro, de forma que a escolha pode ser feita com base na disponibilidade, nas preferências do paciente e nos custos<sup>2,62</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Terapia dupla (LAMA + LABA):** -->
As associações de LAMA+LABA incorporadas ao SUS são o **brometo de umeclidínio + trifenatato de vilanterol** e o **tiotrópio monoidratado + cloridrato de olodaterol**<sup>63</sup> . A associação umeclidínio + vilanterol é indicada para pacientes com DPOC sintomáticos pertencentes aos grupos B ou E, considerando que a recomendação de uso foi independente do grau de obstrução ao fluxo aéreo (VEF1), conforme avaliação clínica. Já a associação tiotrópio + olodaterol foi incorporada com critérios específicos, sendo uma alternativa para pacientes com DPOC grave ou muito grave (estágios 3 e 4), com perfil exacerbador (grupo E).  
Em estudos clínicos controlados, ambas as associações se mostraram eficazes em pacientes com doença grave e muito grave. Entretanto, a capacidade do paciente de atingir um fluxo inspiratório mínimo para executar a manobra inalatória de forma eficiente influencia a deposição pulmonar e consequentemente os resultados do tratamento. Dispositivos de pó seco oferecem maior resistência ao fluxo de ar, de forma que pacientes com fluxo inspiratório máximo muito diminuído podem se beneficiar do uso de dispositivo com resistência mais baixa, como é o caso do dispositivo Respimat<sup>®</sup> . Assim, a associação tiotrópio monoidratado + cloridrato de olodaterol é uma alternativa para pacientes com DPOC grave ou muito grave (estágios 3 e 4), com alto risco (grupo E), que apresentem VEF1 menor que 50% e dificuldade no uso de inalador de pó seco<sup>64–66</sup> .  
Entre os eventos adversos mais frequentes (1% a 10%) observados com uso do brometo de umeclidínio + trifenatato de vilanterol estão infecção do trato urinário, nasofaringite, sinusite, faringite, dor orofaríngea, tosse, constipação, boca seca e dor torácica. Eventos menos frequentes (0,1% a 1%) incluem taquicardia, arritmias, tremores, disgeusia, ansiedade, espasmos musculares, e reações cutâneas leves. Reações raras (0,01% a 0,1%) incluem anafilaxia, angioedema, urticária, broncoespasmo paradoxal, visão turva, aumento da pressão intraocular, retenção urinária, disúria e disfonia. O uso do medicamento é contraindicado em pacientes com hipersensibilidade ao umeclidínio, ao vilanterol ou a qualquer um dos componentes da fórmula, bem como àqueles com alergia grave à proteína do leite<sup>67</sup> .  
Os eventos adversos mais comuns do tiotrópio monoidratado + cloridrato de olodaterol incluem infecção do trato respiratório superior, tosse, bronquite, tontura, dor orofaríngea, dor nas costas e boca seca. Eventos menos comuns envolvem palpitações, taquicardia, ansiedade, insônia, distúrbios gastrointestinais (como náusea e constipação), retenção urinária e reações de hipersensibilidade, como rash cutâneo. Há relatos raros de broncoespasmo paradoxal e agravamento de glaucoma em pacientes predispostos. A associação é contraindicada para pacientes com hipersensibilidade ao tiotrópio, olodaterol, a qualquer componente da fórmula, ou à atropina e seus derivados (como ipratrópio). O produto não é indicado para o tratamento da asma 68.  
16

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Corticodes inalatórios (ICS):** -->
A monoterapia com ICS, **budesonida** ou **dipropronato de beclometasona** , não é recomendada na DPOC, pois o tratamento regular não altera o declínio do FEV1 nem reduz a mortalidade. Além disso, pacientes com histórico de pneumonia ou contagem absoluta de eosinófilos inferior a 100 células/µL, têm baixa probabilidade de resposta, devendo ser avaliados individualmente<sup>2</sup> .  
A combinação de ICS com um LABA mostrou-se mais eficaz do que os componentes isolados na melhora da função pulmonar, do estado de saúde e na redução de exacerbações. No entanto, a terapia com LABA+ICS não é encorajada como opção preferencial, pois o uso de LABA+LAMA+ICS demonstrou superioridade na redução de exacerbações<sup>2</sup> .  
O benefício dos ICS é considerado um efeito de classe, não havendo diferenças de eficácia entre seus representantes. As diferenças são farmacocinéticas, em que maior potência não significa maior eficácia clínica. Assim, neste Protocolo preconizase o uso da budesonida e da beclometasona. Nos casos em que há dúvidas sobre a efetividade, recomenda-se um período de teste de 12 a 24 semanas para avaliar a resposta clínica, com interrupção do uso caso não haja benefícios evidentes<sup>2</sup> .  
Os eventos adversos locais dos corticoides inalatórios são dose-dependentes e incluem candidíase oral, dispepsia, tosse e irritação na garganta. A melhora pode ser observada com a redução de dose, com medidas que reduzem a deposição do medicamento na orofaringe, como a adoção de espaçadores no caso de aerossol, a realização de gargarejos após a inalação e, em alguns casos, a troca do dispositivo inalatório. O risco de eventos adversos sistêmicos aumenta com a dose e o tempo de uso, sendo os mais comuns a supressão temporária hipotalâmica-hipofisária-adrenal, hiperglicemia, acne, glaucoma e catarata. Também foram relatados casos de retardo de crescimento em crianças<sup>69,70</sup> . Se as doses diárias de beclometasona ou budesonida não ultrapassarem a dose máxima de 800 mcg/dia, conforme recomendado neste Protocolo, não há alteração significativa no nível de cortisol plasmático matinal ou na excreção urinária de cortisol livre. Entretanto, doses elevadas de corticoides inalatórios estão associadas a aumento do risco de pneumonia. O uso crônico de doses superiores ao equivalente a 1.000 a 1.500 mcg/dia de budesonida pode estar associado ao aumento do risco para osteoporose e fraturas e, portanto, não é preconizado por este Protocolo<sup>2,71</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Terapia tripla (LABA + LAMA + ICS):** -->
A terapia tripla com LABA + LAMA + ICS é indicada para pacientes do Grupo E, especialmente na presença de eosinofilia sanguínea ≥ 300 células/µL ou quando há exacerbações frequentes, mesmo com uso de terapia dupla (LABA+LAMA)<sup>2</sup> . Essa associação mostrou benefícios na redução de exacerbações, redução do risco de pneumonia, melhora da função pulmonar e redução da mortalidade<sup>72,73</sup> . No SUS estão disponíveis as combinações<sup>74,75</sup> :  
- **furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol** em apresentação de pó para inalação por via oral em dispositivo único com dois compartimentos internos ( _strips_ de alumínio), um com fluticasona e o outro com umeclidínio + vilanterol; e  
- **dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio** em apresentação de solução aerossol em um único dispositivo spray pressurizado dosimetrado.  
Os eventos adversos de furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol mais comumente relatados (≥1%) incluem cefaleia, rinite, nasofaringite, faringite, dor orofaríngea, sinusite, tosse, disfonia, dor musculoesquelética, artralgia, câimbras musculares, dor torácica, infecção do trato urinário, constipação e boca seca. Eventos adversos menos frequentes, mas clinicamente relevantes, incluem tremores, palpitações, aumento da pressão intraocular, visão borrada, broncoespasmo paradoxal, arritmias cardíacas (como fibrilação atrial), e reações de hipersensibilidade, como rash cutâneo, urticária, angioedema e anafilaxia. Devido à presença de corticoide inalatório, também pode ocorrer aumento do risco de pneumonia em pacientes com DPOC, especialmente em idosos e naqueles com histórico prévio de infecções respiratórias. Essa combinação é contraindicada em pacientes com hipersensibilidade conhecida ao furoato de fluticasona, umeclidínio,  
17  
vilanterol ou a qualquer componente da fórmula, incluindo a lactose monoidratada. Também não deve ser utilizado no tratamento de crises agudas de broncoespasmo<sup>76</sup>  
Os eventos adversos de dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio mais comumente relatadas (≥1%) incluem tremor, cefaleia, taquicardia, boca seca, infecção do trato respiratório superior, nasofaringite, dor orofaríngea, faringite, disfonia, tosse, náusea e tontura. Podem ocorrer efeitos cardiovasculares, como palpitações e prolongamento do intervalo QT. Outros eventos relatados incluem erupções cutâneas, aumento da pressão intraocular, retenção urinária, visão borrada e broncoespasmo paradoxal.  
Assim como outros corticoides inalatórios, a beclometasona pode causar candidíase oral, especialmente se a higiene bucal após o uso não for adequada. A associação é contraindicada em pacientes com hipersensibilidade aos princípios ativos, a qualquer excipiente da fórmula, incluindo norflurano (HFA-134a), ou a outros medicamentos com estrutura similar, como atropina ou seus derivados (ex. ipratrópio, tiotrópio). Não é indicado para o alívio de crises agudas de broncoespasmo<sup>77</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Corticoides sistêmicos não inalatórios:** -->
Glicocorticoides sistêmicos, **prednisona, fosfato sódico de prednisolona** e **succinato sódico de hidrocortisona,** são eficazes para a melhora mais rápida dos sintomas, redução de hospitalização e prevenção de recaídas precoces em pacientes com exacerbações moderadas e graves. A via oral deve ser usada sempre que possível, uma vez que o uso parenteral está associado a maior risco de toxicidade<sup>78,79</sup> . Se realizado tratamento prolongado com corticoides sistêmicos deve-se monitorizar os níveis de glicose, devido ao risco acrescido de hiperglicemia. O risco de osteoporose também pode aumentar com o uso prolongado<sup>80</sup> .  
Os eventos adversos mais comuns incluem hipertensão, hiperglicemia, retenção de líquidos, ganho de peso, fraqueza muscular, insônia, alterações do humor (incluindo euforia, depressão ou psicose), acne, estrias, osteoporose, supressão adrenal, miopatia, aumento da suscetibilidade a infecções, alterações menstruais e retardo do crescimento em crianças. Eventos oculares como catarata e glaucoma podem ocorrer com o uso prolongado. A suspensão abrupta de corticoides após uso prolongado pode precipitar insuficiência adrenal; portanto, nesses casos, deve-se reduzir a dose gradualmente<sup>81–83</sup> .  
Indivíduos em tratamento prolongado (mais de 3 semanas) com doses superiores a 7,5 mg/dia de fosfato sódico de prednisolona ou equivalente devem receber doses de estresse de corticoides durante episódios agudos, infecções graves, cirurgias ou traumas<sup>81</sup> . A insuficiência adrenal pode persistir por mais de um ano após a suspensão do tratamento crônico com esteroides. O tratamento prolongado também está associado ao aumento do risco de osteoporose, sendo recomendada a avaliação periódica da densidade mineral óssea e adoção de medidas preventivas, conforme o Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose vigente do Ministério da Saúde<sup>84</sup> .  
Estão contraindicados em casos de hipersensibilidade aos componentes da fórmula, varicela, ceratite herpética, infecções fúngicas sistêmicas não tratadas; e infecções não controladas. O uso deve ser cauteloso em pacientes com comorbidades como úlcera péptica ativa, hipertensão grave, diabete melito descompensado, osteoporose severa, psicose prévia e tuberculose latente ou ativa não tratada<sup>81–83</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Outras terapias:** -->
O tratamento a longo prazo com corticoesteroides orais não é recomendado<sup>2</sup> . A teofilina exerce um efeito broncodilatador modesto que está associado à redução de dispneia na doença estável, mas o risco de toxicidade e a necessidade de monitorização do nível sérico limitam sua utilidade clínica, não devendo ser usada na rotina assistencial. Não devem ser prescritos antitússicos a pacientes com DPOC<sup>2</sup> .  
Antibióticos devem ser prescritos criteriosamente no tratamento das exacerbações infecciosas, com base no perfil de risco do paciente e, sempre que possível, na avaliação microbiológica, considerando o risco de indução de resistência bacteriana<sup>2</sup> . Alguns estudos referem o uso de azitromicina, particularmente em pacientes sem tabagismo ativo, cuja terapêutica a longo prazo demonstrou uma redução das exacerbações ao longo de um ano e não apresentam eosinofilia sanguínea (menos que 100  
18  
células/mm<sup>3</sup> ). O tratamento com um macrolídeo também pode ser instituído, considerados o risco de complicações cardiovasculares e o impacto no perfil de resistência bacteriana, tanto em nível individual como comunitário<sup>2,85,86</sup> . O uso de azitromicina por um período superior a um ano para prevenção de exacerbação de DPOC não foi avaliado e seu uso crônico de azitromicina pode resultar em redução da acuidade auditiva; assim, havendo suspeita de diminuição da acuidade auditiva durante o uso deste medicamento, deve-se solicitar avaliação audiométrica<sup>2</sup> .  
O dupilumabe, uma terapia-alvo biológica para o tratamento da DPOC associada à inflamação tipo 2 (contagem de eosinófilos ≥300 células/ μL) possui registro na Anvisa<sup>87</sup> . No entanto, essa tecnologia não está incorporada ao SUS para a indicação, e seu uso permanece restrito ao contexto de pesquisa ou prática privada.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.2.1.  Medicamentos** -->
- brometo de ipratrópio: solução para inalação de 0,25 mg/mL e solução com aerossol de 20 mcg/dose;  
- brometo de tiotrópio monoidratado + cloridrato de olodaterol: solução para inalação de 2,5 mcg + 2,5 mcg;  
- brometo de umeclidínio + trifenatato de vilanterol: pó inalatório de 62,5 mcg + 25 mcg;  
- bromidrato de fenoterol: solução aerossol de 100 mcg/dose;  
- budesonida: cápsula ou pó de inalação ou aerossol oral de 200 mcg e cápsula para inalação de 400 mcg ou pó inalante  
e aerossol oral de 200 mcg;  
- dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio: solução aerossol para  
- inalação oral de 100 µg + 6 µg + 12,5 µg;  
- diproprionato de beclometasona: cápsula para inalação ou pó para inalação de 200 mcg e 400 mcg e solução aerossol  
de 50 mcg/dose, 200 mcg/dose e 250 mcg/dose; suspensão para inalação nasal de 50 mcg/dose.  
- fumarato de formoterol + budesonida: cápsula ou pó para inalação de 6 mcg + 200 mcg e de 12 mcg + 400 mcg;  
- fumarato de formoterol: cápsula ou pó para inalação de 12 mcg;  
- furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol: pó para inalação oral 100 mcg + 62,5 mcg  
+ 25 mcg;  
- fosfato sódico de prednisolona: solução oral de 1,0 mg/mL e 3,0 mg/mL;  
- prednisona: comprimidos de 5 mg e 20 mg;  
- succinato sódico de hidrocortisona: pó para solução injetável de 100 mg e 500 mg;  
- sulfato de salbutamol: suspensão aerossol de 100 mcg/dose e solução para inalação de 5 mg/mL.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.2.2.  Esquemas de administração** -->
Os esquemas de administração dos medicamentos para tratamento da DPOC estão disponíveis no **Quadro 6** .  
**Quadro 6 -** Esquemas de administração dos tratamentos para DPOC.  
|**Classe**||
|---|---|
|**medicamentosa ou**<br>**associação**|**Esquema terapêutico**|
||**Alívio de broncoespasmo agudo ou antes de esforço físico:**|
|SABA|200 a 400 mcg de sulfato de salbutamol (2 a 4 jatos do aerossol dosimétrico), em dose única antes do<br>esforço ou a cada 4 a 6 horas até melhora dos sintomas; ou 100 a 200 mcg de bromidrato de fenoterol<br>(1 a 2 jatos do aerossol)<sup>48,49</sup>.|  
19  
|**Classe**<br>**medicamentosa ou**<br>**associação**|**Esquema terapêutico**|
|---|---|
||A nebulização com salbutamol (2,5 mg, diluído em 2 a 4 mL de cloreto de sódio 0,9% (soro<br>fisiológico) ou fenoterol (0,5 a 1 mg, equivalente a 10 a 20 gotas, diluído em 2 a 4 mL de cloreto de<br>sódio 0,9% pode ser utilizada em pacientes muito debilitados que não conseguem utilizar inaladores<br>adequadamente. A administração usual ocorre a cada 4 a 6 horas, mas, em exacerbações agudas, pode<br>ser repetida a cada 20 minutos nas primeiras horas, sob monitoramento médico. O tempo de<br>nebulização varia conforme a inalação completa do medicamento<sup>2</sup>.|
|SAMA|**Pacientes clinicamente estáveis:**<br>40 mcg (2 jatos do aerossol dosimétrico) de brometo de ipratrópio, por via inalatória, 3 a 4 vezes/dia.<br>A dose máxima não deve exceder 240 mcg/dia<sup>51</sup>.<br>Recomenda-se orientar o paciente quanto ao uso correto do dispositivo inalatório e sobre a<br>possibilidade de contato das partículas com os olhos. Sinais e sintomas oculares sugestivos de<br>glaucoma (dor ou desconforto, visão embaçada, visão de halos ou imagens coloridas em associação<br>com vermelhidão conjuntival) devem ser observados<sup>51</sup>. Para nebulização devem ser utilizados de 0,25<br>a 0,5 mg (20 a 40 gotas) a cada 4 a 6 horas até melhora clínica. A solução para nebulização deve ser<br>diluída em solução salina fisiológica até um volume final de 3 a 4 mL<sup>2,26,51</sup>.<br>**Alívio de broncoespasmo agudo:**<br>Não é recomendado devido à demora no início da ação quando comparado a fenoterol e salbutamol.|
|LABA|**Fumarato de formoterol:**<br>12 a 24 mcg, 2 vezes/dia.<br>Os pacientes devem ser orientados a inalar uma cápsula por vez e a não usar mais de 2 vezes/dia,<br>exceto quando houver recomendação médica, não ultrapassando a dose máxima diária recomendada<br>de 48 mcg/dia de formoterol<sup>52</sup>.|
|LABA+LAMA<br>(terapia dupla)|**Brometo de umeclidínio + trifenatato de vilanterol:**<br>Destinado somente para uso inalatório por via oral e tem como dose recomendada 62,5 mcg + 25 mcg,<br>uma vez ao dia, sempre no mesmo horário. Não é necessário ajuste de dose para pacientes idosos,<br>com insuficiência renal ou hepática leve a moderada<sup>67</sup>.<br>**Brometo de tiotrópio monoidratado + cloridrato de olodaterol:**<br>Também administrado por meio de inalação oral, a dose preconizada é de dois acionamentos<br>consecutivos (totalizando 5 mcg + 5 mcg) por meio do inalador específico, uma vez ao dia, sempre<br>no mesmo horário<sup>68</sup>.|  
20  
|**Classe**<br>**medicamentosa ou**<br>**associação**|**Esquema terapêutico**|
|---|---|
|ICS|Pacientes idosos ou com insuficiência hepática leve a moderada podem utilizar o medicamento sem<br>necessidade de ajuste de dose. Pacientes com insuficiência renal moderada a grave, embora possam<br>utilizá-lo na dose preconizada, devem ser submetidos a monitoramento cuidadoso da função renal<sup>68</sup>.<br>A dose de corticoide inalatório preconizada é de 800 mcg/dia de budesonida ou beclometasona<sup>69,70</sup>.<br>Há evidências de que uma dose menor de budesonida (400 mcg/dia) possa ser tão eficaz quanto a<br>recomendada para a redução de exacerbações, a menos em terapia tripla, devendo ser considerada<br>especialmente em pacientes com histórico ou outros fatores de risco de pneumonia. Não se preconiza<br>o uso isolado de corticoide inalatório (como monoterapia) na DPOC<sup>69</sup>.<br>No caso de nebulímetros dosimetrados, a utilização deve ser feita com o auxílio de espaçadores ou<br>aerocâmaras, com vistas a melhorar a coordenação entre o disparo e a inspiração, e aumentar a<br>deposição nas vias aéreas inferiores.<br>Em caso de dificuldade na execução da manobra inspiratória forçada e sustar a respiração pelo tempo<br>recomendado (10 segundos), recomenda-se a inalação em volume corrente (sem esforço e sem pausa<br>ao final da inspiração), executando-se 5 (cinco) inspirações/expirações após o disparo de cada jato.<br>Dispositivos de pó seco têm mecanismo de disparo esforçodependente, podendo não ter boa eficácia<br>em casos de obstrução muito grave (VEF1 < 30% a 40% e pico de fluxo inspiratório < 30 L/min).<br>Nesses casos, dispositivos cuja administração independe de esforço, como aerossol associado a<br>aerocâmara ou dispositivo de névoa suave podem ser mais adequados. Recomenda-se lavar a boca<br>(gargarejar e cuspir) após uso inalatório de corticoides.|
|LABA+LAMA+ICS<br>(terapia tripla)|Na**terapia tripla aberta**com múltiplos dispositivos, a budesonida é usada uma vez ao dia em doses<br>de 800 mcg/dia, podendo ser reduzida para 400 mcg/dia em pacientes com alto risco de pneumonia;<br>a beclometasona deve ser administrada duas vezes ao dia, na dose de 800 mcg/dia<sup>72,88</sup>:<br>**Brometo de umeclidínio + trifenatato de vilanterol**62,5 mcg + 25 mcg, uma vez ao dia +<br>**budesonida**400 a 800 mcg uma vez ao dia ou**beclometasona**400 mcg duas vezes ao dia<sup>72,88</sup>.<br>**ou**<br>**Brometo de tiotrópio monoidratado + cloridrato de olodaterol**5 mcg + 5 mcg/dia +**budesonida**<br>400 a 800 mcg uma vez ao dia ou**beclometasona**400 mcg duas vezes ao dia<sup>72,88</sup>.<br>Em pacientes com DPOC grave e perfil exacerbador recomenda-se uso das**terapias triplas com**<br>**combinação de dose fixa:**|
||**Dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de**<br>**glicopirrônio:**|  
21  
|**Classe**<br>**medicamentosa ou**<br>**associação**|**Esquema terapêutico**|
|---|---|
||100 mcg + 6 mcg + 12,5 mcg, duas inalações, duas vezes ao dia<sup>77</sup><br>**ou**<br>**Furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol:**<br>100 mcg + 62,5 mcg + 25 mcg, uma vez ao dia<sup>76</sup>|
||**Em exacerbações moderadas e graves:**<br>Corticoide sistêmico por 5 dias, preferencialmente por via oral. Em pacientes sem possibilidade de<br>uso por via oral, pode ser utilizado corticoide por via intravenosa<sup>34</sup>. Deve-se usar a menor dose por<br>menor tempo possível para prevenir eventos adversos deste tratamento.|
||**Corticoide oral:**<br>Prednisona ou fosfato sódico de prednisolona: 40 mg/dia<sup>34</sup>.|
|Corticoides<br>sistêmicos não<br>inalatórios|**Corticoide intravenoso:**<br>Succinato sódico de hidrocortisona por via intravenosa na dose de 200 mg a cada 6 horas, até ser<br>possível a transição para a via oral<sup>34</sup>.|
||Em caso de falha com esquema de 5 dias, verificada pela ausência de melhora de sintomas no quinto<br>dia, especialmente em exacerbações graves, pode-se aumentar o tempo de uso para 10 a 14 dias<sup>34</sup>.<br>Para pacientes que fizeram uso de corticoide sistêmico por mais de 3 semanas, deve ser feita a redução<br>gradual lenta (5 a 10 mg a cada 5 a 7 dias), a fim de permitir a recuperação da função adrenal. O<br>paciente deve ser orientado quanto a fazer uso do fármaco somente com prescrição, nas doses e nos<br>tempos previstos<sup>2,26,34</sup>.|

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.2.3.  Critérios de interrupção** -->
Uma vez indicado, o tratamento da DPOC deve ser feito por toda a vida, com acompanhamento médico regular, que inclua minimamente revisão do diagnóstico, comorbidades, mudanças de classificação da DPOC e surgimento de complicações relacionadas ao tratamento. Em caso de broncoespasmo paradoxal, os tratamentos com os seguintes medicamentos deverão ser interrompidos imediatamente e substituídos por outra terapia:  
- brometo de tiotrópio monoidratado + cloridrato de olodaterol;  
- brometo de umeclidínio + trifenatato de vilanterol;  
- bromidrato de fenoterol;  
- dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio;  
- dipropionato de beclometasona;  
- fumarato de formoterol + budesonida;  
- fumarato de formoterol;  
- furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol;  
22  
- sulfato de salbutamol.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.3.     Tratamento em populações específicas** -->
**Gestação/amamentação:** o uso de broncodilatadores deve ser avaliado individualmente, considerando a segurança dos medicamentos durante a gravidez<sup>2</sup> .  
**Idosos:** pacientes com mais de 65 anos apresentam um maior risco de eventos adversos a medicamentos, especialmente em indivíduos com comorbidades:  
- Broncodilatadores (beta-2 agonistas e antimuscarínicos): podem aumentar o risco de taquicardia e arritmias em  
- cardiopatas;  
- Corticoides sistêmicos e inalatórios: podem agravar o controle glicêmico em diabéticos e aumentar o risco de  
- osteoporose e fraturas;  
- Antimuscarínicos: devem ser utilizados com cautela em pacientes com hiperplasia prostática benigna (HPB) ou retenção  
- urinária, pois podem agravar sintomas urinários<sup>2</sup> .  
Também é recomendada uma abordagem individualizada, com atenção especial à função cognitiva, capacidade de manuseio de dispositivos inalatórios e fragilidade. A escolha do tratamento deve considerar a eficácia e a facilidade de uso dos dispositivos inalatórios, além da avaliação da necessidade de suporte nutricional e reabilitação pulmonar<sup>2</sup> .  
**Concomitância de asma e DPOC:** considerando que asma e DPOC podem coexistir em um mesmo paciente<sup>2</sup> , em caso de suspeita ou diagnóstico confirmado, o tratamento medicamentoso do paciente deve seguir, prioritariamente, o Protocolo Clínico e Diretrizes Terapêuticas da Asma vigente do Ministério da Saúde<sup>89</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.4.     Vacinas** -->
Com o objetivo de reduzir as complicações decorrentes de infecção concomitante, preconizam-se as seguintes vacinas, conforme o Programa Nacional de Imunizações, especialmente em idosos<sup>2,14</sup> :  
- vacina anti-influenza (anual): todos os pacientes com DPOC; e  
- vacinas pneumocócicas 13 - conjugada e polissacarídica (23-valente): pacientes com DPOC sintomáticos e exacerbadores; pacientes de qualquer grupo de risco da doença com comorbidades associadas a maior risco de doença pneumocócica grave (diabete melito, insuficiência renal, insuficiência cardíaca, etc.).  
Aplicar as duas vacinas com intervalo de seis meses, iniciando pela vacina pneumocócica 13 conjugada. Recomendado o reforço para a vacina 23-valente em cinco anos ou, se iniciada após os 65 anos, em dose única<sup>90</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **7.5.     Fluxo de tratamento** -->
A **Figura 1** apresenta o fluxograma de tratamento para pacientes diagnosticados com DPOC que tenham sido avaliados por espirometria e classificados quanto à gravidade da obstrução do fluxo aéreo (GOLD 1 a GOLD 4) e ao risco de exacerbações, com base na frequência de exacerbações e no grau de sintomas, avaliados pelas escalas mMRC e CAT. Destaca-se que em qualquer mudança no tratamento, seja na fase inicial ou de manutenção, deve-se considerar:  
- **revisar** sintomas (dispneia, impacto na qualidade de vida, entre outros) e o risco de exacerbações (histórico prévio,  
- contagem de eosinófilos, entre outros);  
- **avaliar** técnica inalatória e adesão ao tratamento (uso correto dos dispositivos) e papel das estratégias não  
- medicamentosas (cessação do tabagismo, reabilitação pulmonar, autocuidado, etc.); e  
- **ajustar** a terapia de escolha, incluindo escalonamento e descalonamento:  
23  
 _escalonamento_ (adição de ICS): pacientes com exacerbações frequentes e contagem de eosinófilos ≥ 300 células/µL);  
 _descalonamento_ (retirada do ICS): pacientes sem benefício clínico esperado, especialmente quando a contagem de eosinófilos for inferior a 100 células/ µL, não houver histórico de exacerbações frequentes ou houver ocorrência de eventos adversos relacionados ao ICS, como pneumonia, candidíase oral, ou outras condições que contraindiquem seu uso.  
Além disso pode ser necessário trocar medicamentos dentro da mesma classe, reavaliar a via de administração ou o tipo de inalador, sempre com base na resposta clínica e tolerabilidade.  
A combinação LABA + ICS era uma das opções iniciais para determinados perfis de pacientes com DPOC, conforme o PCDT publicado em 2021. Assim, alguns pacientes podem já estar utilizando esse esquema terapêutico e apresentar bom controle clínico, sem exacerbações recentes. Nesses casos, de acordo com o GOLD 2025, não há necessidade de alteração imediata, especialmente quando há histórico prévio de resposta favorável ao ICS e ausência de eventos adversos relevantes. Recomendase a manutenção do tratamento, com monitoramento clínico regular e reavaliação periódica, considerando a contagem de eosinófilos, o histórico de exacerbações e a tolerabilidade<sup>2</sup> . O trecho do fluxograma referente a esses pacientes foi nomeado “Reavaliação de tratamento baseado no PCDT anterior”.  
24  
**Figura 1 -** Fluxograma de tratamento para pacientes diagnosticados com DPOC  
<!-- Start of picture text -->
Reavaliacdo de tratamento baseado no PCDT anterior<br>Individuo com Roa<br>ddiagnéstico de DPOC tratamento com<br>LABA+ ICS<br>‘sim / Diagnéstico de asma Nao ‘Sem ocorréncia de -<br>concnamaries exacerbages sem stone ce Com ocorréncia de<br>a Resposta positiva de See exacerbacbes<br>tratamentos prévios*<br>Tratar conforme 2 ;<br>er Coo Reree Dispneia Dispneia Nao’ Eosinéfios = 100 \Sim<br>controlada"* persistente eeLee<br>Considerar<br>tratamento<br>Continuar UES Considerar<br>tratamento escalonamento<br>LABA+ ICS<br>LAMA+ LABA+ ICS<br>Tratamento<br>inicialf N3o/ Eosinéfilos=célulasiyl 300? Sim<br>H LABA LAMA +LABA.<br>i (formoterol) (UMEC + Vi) LAMA+LABA<br>(UMEC + VI ou AMA<br>TIO + OLO *)<br>BS + LABA+ ICS<br>{alivio‘SAMAde ousintomasSABA povereseeseeseeseoy<br>nos Grupos<br>: A, B e E) Avalir(se os adeséo, intrferéncajerem presentes, de comorbdades seguira via de exacerbacdes)e floc radominania | | rataSe iagnosticadas comorbidades<br>: Resposta a0 -<br>i |tratamento adequada’ Dispneia Exacerbacdes<br>; a Eosin6filos = 300 células/yl ou<br>H pcre ical LAMA + LABA® N0/’ Eosinéfilos entre = 100 e < 300 célulasiul ou SS<br>H sil Me Exacerbacdes persistentes em LAMA+LABA<br>Hy ‘Investigar (e tratar) outras! A<br>Tratamento H H LAMA + LABAP LAMA+ LABA + ICS®<br>One  causas de dispneia i<br>{DescalonamentodeicSse:st—=<=s*~si‘s*‘SAS<br>{ Eosinéfilos < 100 células/uL’ io. -<br>! = Indica baixa probabilidade de beneficio do ICS, portanto seu ; Nao, Eosinéfilos= 100, Sim<br>tuso pode no ser necessério. Hi células/pl ?<br>! Auséncia de exacerbacSes recorrentes: {<br>| -Paciente estd estavel e sem exacerbacdo por um periodo<br>‘significative. H —<br>} Efeitos adversos atribuiveis ao ICS: H Adicionar<br>| - Por exemplo: pneumonia, candidiase oral recorrente, ou azitromicina para<br><!-- End of picture text -->  
Nota: * Paciente que anteriormente apresentou exacerbações e respondeu ao tratamento com LABA+ICS.  
25  
** Se paciente já estiver em tratamento e houver melhora;  
a A indicação da associação tiotrópio + olodaterol deve respeitar os critérios já estabelecidos neste protocolo, sendo restrita a pacientes com DPOC grave ou muito grave (VEF1 < 50%), com perfil exacerbador (Grupo E). Considerar ainda a dificuldade no uso de inaladores de pó seco; b Se os sintomas persistirem, considere trocar o dispositivo inalatório ou as moléculas antes de escalar o tratamento;  
c Se as exacerbações persistirem, considerar a troca da molécula de ICS ou do inalador.  
Legenda: ICS: corticoide inalatório; LABA: broncodilatadores beta-2 agonistas de longa ação; LAMA: broncodilatadores antimuscarínicos de longa ação; SABA: broncodilatadores beta-2 agonistas de curta ação; SAMA: broncodilatadores antimuscarínicos de curta ação; UMEC+VI: brometo de umeclidínio + trifenatato de vilanterol; TIO+OLO: tiotrópio monoidratado + cloridrato de olodaterol.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **8. MONITORAMENTO** -->
O acompanhamento contínuo do paciente com DPOC é essencial para monitorar a progressão da doença, ajustar o tratamento e prevenir exacerbações. A abordagem deve ser individualizada, considerando a gravidade da obstrução ao fluxo aéreo, a presença de exacerbações e as comorbidades associadas<sup>2</sup> . Após exacerbações, recomenda-se uma avaliação inicial dentro de um período de uma a quatro semanas, seguida de uma nova consulta entre doze e dezesseis semanas para reavaliação funcional completa. Esse intervalo permite um ajuste mais adequado do cuidado, considerando as possíveis repercussões da exacerbação e a necessidade de intervenções adicionais<sup>91</sup> .  
A monitorização dos pacientes deve incluir parâmetros clínicos e funcionais, sendo a espirometria um dos principais exames utilizados para avaliar a evolução da função pulmonar<sup>2,91–99</sup> . A medição do VEF1 permite detectar um possível declínio acelerado da capacidade respiratória, sendo recomendada como estratégia de acompanhamento em pacientes com doença estável, mas não deve ser interpretada como exame obrigatório para continuidade do tratamento, considerando o risco de interromper a terapia. A avaliação dos sintomas também é essencial e pode ser realizada por meio de escalas padronizadas, como o CAT<sup>TM</sup> e a mMRC, que possibilitam quantificar a intensidade dos sintomas e monitorar o impacto da doença na qualidade de vida<sup>2,91,92,98,99</sup> .  
A oxigenação arterial deve ser monitorada por meio da oximetria de pulso, sendo recomendada conforme avaliação de risco<sup>4</sup> . Em pacientes com VEF₁ menor que 50%, a SpO₂ em repouso deve ser medida em todas as consultas. Valores de SpO₂ ≤ 92% indicam a necessidade de realização de gasometria arterial para avaliação mais detalhada da hipoxemia e da retenção de dióxido de carbono, auxiliando na decisão sobre a indicação de oxigenoterapia domiciliar de longo prazo. Além da avaliação em repouso, a SpO₂ deve ser medida durante o esforço em pacientes com DPOC grave ou quando houver suspeita clínica de hipoxemia (por exemplo, policitemia). Isso pode ser feito por meio do teste de caminhada de seis minutos (TC6), quando disponível, ou por meio da simulação de esforço leve, como subir e descer um degrau ou realizar marcha estacionária por 3 a 5 minutos, visando a atingir uma frequência cardíaca entre 100 e 110 bpm. Caso seja confirmada hipoxemia em repouso ou durante o esforço, o paciente deve ser encaminhado a serviço especializado em pneumologia<sup>2,4</sup> .  
A avaliação do risco cardiovascular deve ser incorporada ao seguimento dos pacientes com DPOC, uma vez que essa população apresenta maior incidência de eventos cardiovasculares adversos. Atualmente, para pessoas com idade entre 40-74 anos, recomenda-se a avaliação anual com o uso da calculadora da Iniciativa HEARTS/OPAS/OMS, que utiliza parâmetros definidos a partir do _Global Burden Disease_ , por ser a ferramenta melhor calibrada para a população brasileira, no momento<sup>100,101</sup> . O risco de infarto agudo do miocárdio, acidente vascular cerebral e morte cardiovascular é elevado, sobretudo nos primeiros 90 dias após uma exacerbação da doença. Assim, a realização de eletrocardiograma e ecocardiograma deve ser considerada<sup>2,4</sup> .  
Além disso, a monitorização do estado nutricional é essencial, visto que a desnutrição e a perda de massa muscular são frequentes na DPOC grave. Pacientes com baixo IMC < 21 kg/m² apresentam pior prognóstico, e a perda de peso involuntária pode indicar necessidade de suporte nutricional. O rastreamento de sarcopenia e fragilidade, incluindo avaliação da força de preensão manual e da composição corporal (por exemplo, por bioimpedância), deve ser considerado para identificar pacientes  
26  
de alto risco. A suplementação calórica e proteica pode ser indicada para melhorar a força muscular e a tolerância ao exercício, especialmente em indivíduos com perda de peso progressiva<sup>2,102</sup> . A monitorização da atividade física na vida diária também deve ser incentivada<sup>2</sup> .  
Por fim, a adesão ao tratamento deve ser monitorada em todas as consultas, especialmente o uso correto dos dispositivos inalatórios<sup>2,4,91</sup> . A técnica inalatória inadequada compromete a deposição do medicamento nas vias aéreas, levando a um controle insatisfatório dos sintomas, maior necessidade de uso de medicamentos de resgate e aumento do risco de eventos adversos. Por isso, a escolha do dispositivo deve ser individualizada, considerando fatores como a habilidade do paciente na administração do medicamento e o acesso ao tratamento. Para inaladores dosimetrados pressurizados, o uso de espaçadores melhora a distribuição do fármaco, além de reduzir eventos adversos locais, como disfonia e candidíase oral, especialmente no caso dos corticoides inalatórios. Pacientes devem ser treinados sobre a correta utilização dos dispositivos, preferencialmente com demonstração física e reavaliação periódica da técnica, garantindo a eficácia do tratamento<sup>4</sup> .

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Por ser uma doença progressiva, é imprescindível o acompanhamento do quadro clínico dos pacientes com DPOC, com cuidados ofertados de acordo com a sua necessidade e ao longo do tempo. Da mesma forma, o cuidado deve ser articulado entre a APS e os outros níveis de atenção, a fim de que pacientes que necessitem de cuidados mais complexos tenham acesso a serviços e informações em outros pontos de atenção da RAS, sem perder o vínculo e o acompanhamento na APS.  
As ações ofertadas na APS devem fazer parte do tratamento multidimensional de pacientes com DPOC, principalmente os classificados como Grupo A. Ações de prevenção de fatores de risco, de avaliação dos sintomas, reconhecimento e classificação de risco de exacerbação (Grupos A, B ou E), manutenção do tratamento e ações de promoção da saúde podem ser ofertadas a todos os pacientes com DPOC na APS. Pacientes com DPOC classificados a partir do GOLD 3 também devem ser acompanhados por pneumologista em serviço especializado.  
Pacientes com DPOC devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de reações adversas.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Como parte da rede de Atenção Primária à Saúde, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de  
27  
modos de vida saudáveis; promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
Em relação às PICS, estas práticas foram institucionalizadas pela PNPIC. Uma das ideias centrais dessa abordagem é uma visão ampliada do processo saúde e doença, assim como a promoção do cuidado integral do ser humano, especialmente do autocuidado. As indicações às práticas se baseiam no indivíduo como um todo, considerando seus aspectos físicos, emocionais, mentais e sociais. As PICS não substituem o tratamento tradicional e podem ser indicadas por profissionais específicos conforme as necessidades de cada caso.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **11.      REFERÊNCIAS** -->
1. Celli B, Fabbri L, Criner G, et al. Definition and Nomenclature of Chronic Obstructive Pulmonary Disease: Time for Its Revision. _Am J Respir Crit Care Med_ 2022; 206: 1317–1325.  
2. Global Initiative for Chronic Obstructive Lung Disease (GOLD). Global Strategy for Diagnosis, Management, and Prevention of Chronic Obstructive Pulmonary Disease, https://goldcopd.org/wp-content/uploads/2024/11/GOLD-2025Report-v1.0-15Nov2024_WMV.pdf (2025, accessed 1 July 2025).  
3. Agustí A, Melén E, DeMeo DL, et al. Pathogenesis of chronic obstructive pulmonary disease: understanding the contributions of gene–environment interactions across the lifespan. _Lancet Respir Med_ 2022; 10: 512–524.  
4. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Doenças respiratórias crônicas / Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Doença Pulmonar Obstrutiva Crônica (DPOC). _Ministério da Saúde - Linhas de Cuidado_ , https://linhasdecuidado.saude.gov.br/portal/doenca-pulmonar-obstrutiva-cronica/ (2022, accessed 12 March 2025).  
5. Santo AH, Fernandes FLA. Chronic Obstructive Pulmonary Disease-Related Mortality in Brazil, 2000–2019: A Multiple-Cause-of-Death Study. _COPD: Journal of Chronic Obstructive Pulmonary Disease_ 2022; 19: 216–225.  
6. Menezes AMB, Perez-Padilla R, Jardim JB, et al. Chronic obstructive pulmonary disease in five Latin American cities (the PLATINO study): a prevalence study. _The Lancet_ 2005; 366: 1875–1881.  
7. Leal LF, Cousin E, Bidinotto AB, et al. Epidemiology and burden of chronic respiratory diseases in Brazil from 1990 to 2017: analysis for the Global Burden of Disease 2017 Study. _Revista Brasileira de Epidemiologia_ ; 23. Epub ahead of print 2020. DOI: 10.1590/1980-549720200031.  
8. Menezes AMB, Perez-Padilla R, Jardim JB, et al. Chronic obstructive pulmonary disease in five Latin American cities (the PLATINO study): a prevalence study. _The Lancet_ 2005; 366: 1875–1881.  
28  
9. Moreira GL, Manzano BM, Gazzotti MR, et al. PLATINO, a nine-year follow-up study of COPD in the city of São Paulo, Brazil: the problem of underdiagnosis. _Jornal Brasileiro de Pneumologia_ 2014; 40: 30–37.  
10. López‐Campos JL, Tan W, Soriano JB. Global burden of COPD. _Respirology_ 2016; 21: 14–23.  
11. Safiri S, Carson-Chahhoud K, Noori M, et al. Burden of chronic obstructive pulmonary disease and its attributable risk factors in 204 countries and territories, 1990-2019: results from the Global Burden of Disease Study 2019. _BMJ_ 2022; e069679.  
12. Boers E, Barrett M, Su JG, et al. Global Burden of Chronic Obstructive Pulmonary Disease Through 2050. _JAMA Netw Open_ 2023; 6: e2346598.  
13. Sociedade Brasileira de Pneumologia e Tisiologia. _II Consenso Brasileiro sobre Doença Pulmonar Obstrutiva Crônica - DPOC_ . Brasília, 2004.  
14. NICE. Chronic obstructive pulmonary disease in over 16s: diagnosis and management. _NICE guideline [NG115]_ , https://www.nice.org.uk/guidance/ng115/resources/chronic-obstructive-pulmonary-disease-in-over-16s-diagnosis-andmanagement-pdf-66141600098245 (2018, accessed 9 March 2025).  
15. Martins SM, Adams R, Rodrigues EM, et al. Living with COPD and its psychological effects on participating in community-based physical activity in Brazil: a qualitative study. Findings from the Breathe Well group. _NPJ Prim Care Respir Med_ 2024; 34: 33.  
16. Martinez FJ, Mannino D, Leidy NK, et al. A New Approach for Identifying Patients with Undiagnosed Chronic Obstructive Pulmonary Disease. _Am J Respir Crit Care Med_ 2017; 195: 748–756.  
17. Ministério da Saúde. Medidor de Pico de Fluxo Expiratório (PFE) - (“Peak Flow”). _Linhas de Cuidado_ , https://linhasdecuidado.saude.gov.br/portal/asma/medidor-de-pico-fluxo-expiratorio/ (accessed 1 August 2025).  
18. Nunn AJ, Gregg I. New regression equations for predicting peak expiratory flow in adults. _BMJ_ 1989; 298: 1068–1070.  
19. Hospital de Clínicas da Universidade Federal de Minas Gerais, EBSERH. Tele-Espirometria para Suporte ao Atendimento de Doenças Pulmonares Crônicas na Atenção Primária à Saúde, https://telessaude.hc.ufmg.br/projeto/espirometria/ (2020, accessed 1 August 2025).  
20. Fórum Intersetorial de CCNTs no Brasil. Tele-espirometria para Condições Respiratórias Crônicas na Atenção Primária à Saúde, https://www.forumdcnts.org/post/cobertura-evento-gestores-2024 (2024, accessed 1 August 2025).  
21. Martinez FJ, Agusti A, Celli BR, et al. Treatment Trials in Young Patients with Chronic Obstructive Pulmonary Disease and Pre–Chronic Obstructive Pulmonary Disease Patients: Time to Move Forward. _Am J Respir Crit Care Med_ 2022; 205: 275–287.  
22. Pereira CA de C, Sato T, Rodrigues SC. Novos valores de referência para espirometria forçada em brasileiros adultos de raça branca. _Jornal Brasileiro de Pneumologia_ 2007; 33: 397–406.  
23. Sociedade Brasileira de Pneumologia e Tisiologia. Doença Pulmonar Obstrutiva Crônica - Diagnóstico e Tratamento. _Manual para os Profissionais da Rede Básica de Saúde_ , https://d1xe7tfg0uwul9.cloudfront.net/sbpt-portal/wpcontent/uploads/2024/10/29004701/SBPT_MANUAL_DPOC_FINAL_25_OUT_2024.pdf (2024, accessed 11 March 2025).  
24. Kovelis D, Segretti NO, Probst VS, et al. Validação do Modified Pulmonary Functional Status and Dyspnea Questionnaire e da escala do Medical Research Council para o uso em pacientes com doença pulmonar obstrutiva crônica no Brasil. _Jornal Brasileiro de Pneumologia_ 2008; 34: 1008–1018.  
25. Jones PW, Harding G, Berry P, et al. Development and first validation of the COPD Assessment Test. _European Respiratory Journal_ 2009; 34: 648–654.  
26. Han M, Dransfield M. Stable COPD: Initial pharmacologic management. _UpToDate_ .  
29  
27. Gøtzsche PC, Johansen HK. Intravenous alpha-1 antitrypsin augmentation therapy for treating patients with alpha-1 antitrypsin deficiency and lung disease. _Cochrane Database of Systematic Reviews_ ; 2016. Epub ahead of print 20 September 2016. DOI: 10.1002/14651858.CD007851.pub3.  
28. Feitosa PHR, Castellano MVC de O, Costa CH da, et al. Recommendations for the diagnosis and treatment of alpha-1 antitrypsin deficiency. _Jornal Brasileiro de Pneumologia_ 2024; e20240235.  
29. Lin P, Liu A, Tsuchiya Y, et al. Association between periodontal disease and chronic obstructive pulmonary disease. _Japanese Dental Science Review_ 2023; 59: 389–402.  
30. van Eerd EA, van der Meer RM, van Schayck OC, et al. Smoking cessation for people with chronic obstructive pulmonary disease. _Cochrane Database of Systematic Reviews_ ; 2019. Epub ahead of print 20 August 2016. DOI: 10.1002/14651858.CD010744.pub2.  
31. Barros-Tizón JC, Torres ML, Blanco I, et al. Reduction of severe exacerbations and hospitalization-derived costs in alpha-1-antitrypsin-deficient patients treated with alpha-1-antitrypsin augmentation therapy. _Ther Adv Respir Dis_ 2012; 6: 67–78.  
32. Ministério da Saúde. Protocolo Clínico e Diretrizes Terapêuticas do Tabagismo. _Portaria Conjunta n_<sup>_o_</sup> _10, de 16 de abril de 2020_ .  
33. Prochaska JO, DiClemente CC. Stages of change in the modification of problem behaviors. _Prog Behav Modif_ 1992; 28: 183–218.  
34. Leuppi JD, Schuetz P, Bingisser R, et al. Short-term vs Conventional Glucocorticoid Therapy in Acute Exacerbations of Chronic Obstructive Pulmonary Disease. _JAMA_ 2013; 309: 2223.  
35. Brasil. Ministério da Saúde. Plano de Ações Estratégicas para o Enfrentamento das Doenças Crônicas Não Transmissíveis no Brasil para 2021-2030 (Plano de Dant), https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/svsa/doencas-cronicas-nao-transmissiveis-dcnt/09-plano-de-dant-2022_2030.pdf/view (2021, accessed 31 July 2025).  
36. World Health Organization (WHO). Health promotion and disease prevention through population-based interventions, including action to address social determinants and health inequity . _World Health Organization (WHO)._ , https://www.emro.who.int/aboutwho/public-health-functions/health-promotion-disease-prevention.html (2023, accessed 21 April 2025).  
37. Brasil. Ministério da Saúde. Política Nacional de Promoção da Saúde: PNPS: Anexo I da Portaria de Consolidação no 2, de 28 de setembro de 2017, que consolida as normas sobre as políticas nacionais de saúde do SUS. _Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Secretaria de Atenção à Saúde_ , https://bvsms.saude.gov.br/bvs/publicacoes/politica_nacional_promocao_saude.pdf (2018, accessed 21 April 2025).  
38. Bhatt SP, Patel SB, Anderson EM, et al. Video Telehealth Pulmonary Rehabilitation Intervention in Chronic Obstructive Pulmonary Disease Reduces 30-Day Readmissions. _Am J Respir Crit Care Med_ 2019; 200: 511–513.  
39. Zhang D, Zhang H, Li X, et al. Pulmonary Rehabilitation Programmes Within Three Days of Hospitalization for Acute Exacerbation of Chronic Obstructive Pulmonary Disease: A Systematic Review and Meta-Analysis. _Int J Chron Obstruct Pulmon Dis_ 2021; Volume 16: 3525–3538.  
40. Moore E, Palmer T, Newson R, et al. Pulmonary Rehabilitation as a Mechanism to Reduce Hospitalizations for Acute Exacerbations of COPD. _Chest_ 2016; 150: 837–859.  
41. Neves LF, Reis MH dos, Gonçalves TR. Home or community-based pulmonary rehabilitation for individuals with chronic obstructive pulmonary disease: a systematic review and meta-analysis. _Cad Saude Publica_ ; 32. Epub ahead of print 2016. DOI: 10.1590/0102-311X00085915.  
30  
42. Pradella CO, Belmonte GM, Maia MN, et al. Home-Based Pulmonary Rehabilitation for Subjects With COPD: A Randomized Study. _Respir Care_ 2015; 60: 526–532.  
43. Cranston JM, Crockett A, Moss J, et al. Domiciliary oxygen for chronic obstructive pulmonary disease. _Cochrane Database of Systematic Reviews_ ; 2008. Epub ahead of print 19 October 2005. DOI: 10.1002/14651858.CD001744.pub2.  
44. Gupta D, Agarwal R, Aggarwal A, et al. Guidelines for diagnosis and management of chronic obstructive pulmonary disease: Joint ICS/NCCP (I) recommendations. _Lung India_ 2013; 30: 228.  
45. Benzo R, Farrell MH, Chang C-CH, et al. Integrating Health Status and Survival Data. _Am J Respir Crit Care Med_ 2009; 180: 239–246.  
46. Ahn JH, Chung JH, Shin K-C, et al. The effects of repeated inhaler device handling education in COPD patients: a prospective cohort study. _Sci Rep_ 2020; 10: 19676.  
47. Jang JG, Chung JH, Shin K-C, et al. Comparative Study of Inhaler Device Handling Technique and Risk Factors for Critical Inhaler Errors in Korean COPD Patients. _Int J Chron Obstruct Pulmon Dis_ 2021; Volume 16: 1051–1059.  
48. _Aerolin ® sulfato de salbutamol  [bula de medicamento]_ . 2024.  
49.  
- _Berotec ® bromidrato de fenoterol [bula de medicamento]_ . 2024.  
50. Appleton S, Jones T, Poole P, et al. Ipratropium bromide versus long-acting beta-2 agonists for stable chronic obstructive pulmonary disease. _Cochrane Database of Systematic Reviews_ . Epub ahead of print 19 July 2006. DOI: 10.1002/14651858.CD006101.  
51. _Atrovent ® brometo de ipratrópio [bula de medicamento]_ . 2025.  
52.  
- _Fluir ® fumarato de formoterol di-hidratado [bula de medicamento]_ . 2021.  
53. Cheyne L, Irvin-Sellers MJ, White J. Tiotropium versus ipratropium bromide for chronic obstructive pulmonary disease. _Cochrane Database Syst Rev_ 2015; 2015: CD009552.  
54. Oba Y, Sarva ST, Dias S. Efficacy and safety of long-acting β-agonist/long-acting muscarinic antagonist combinations in COPD: a network meta-analysis. _Thorax_ 2016; 71: 15–25.  
55. Rodrigo GJ, Price D, Anzueto A, et al. LABA/LAMA combinations versus LAMA monotherapy or LABA/ICS in COPD: a systematic review and meta-analysis. _Int J Chron Obstruct Pulmon Dis_ 2017; Volume 12: 907–922.  
56. Kardos P, Worsley S, Singh D, et al. Randomized controlled trials and real-world observational studies in evaluating cardiovascular safety of inhaled bronchodilator therapy in COPD. _Int J Chron Obstruct Pulmon Dis_ 2016; Volume 11: 2885–2895.  
57. Calverley P, Vlies B. A rational approach to single, dual and triple therapy in COPD. _Respirology_ 2016; 21: 581–589.  
58. Calzetta L, Rogliani P, Ora J, et al. LABA/LAMA combination in COPD: a meta-analysis on the duration of treatment. _European Respiratory Review_ 2017; 26: 160043.  
59. Fukuda N, Horita N, Kaneko A, et al. Long-acting muscarinic antagonist (LAMA) plus long-acting beta-agonist (LABA) versus LABA plus inhaled corticosteroid (ICS) for stable chronic obstructive pulmonary disease. _Cochrane Database of Systematic Reviews_ ; 2023. Epub ahead of print 5 June 2023. DOI: 10.1002/14651858.CD012066.pub3.  
60. Horita N, Goto A, Shibata Y, et al. Long-acting muscarinic antagonist (LAMA) plus long-acting beta-agonist (LABA) versus LABA plus inhaled corticosteroid (ICS) for stable chronic obstructive pulmonary disease (COPD). _Cochrane Database of Systematic Reviews_ ; 2018. Epub ahead of print 10 February 2017. DOI: 10.1002/14651858.CD012066.pub2.  
61. Petite SE. Role of Long-Acting Muscarinic Antagonist/Long-Acting β-2-Agonist Therapy in Chronic Obstructive Pulmonary Disease. _Annals of Pharmacotherapy_ 2017; 51: 696–705.  
31  
62. Calzetta L, Rogliani P, Matera MG, et al. A Systematic Review With Meta-Analysis of Dual Bronchodilation With LAMA/LABA for the Treatment of Stable COPD. _Chest_ 2016; 149: 1181–1196.  
63. Ministério da Saúde. _Combinação de um β2-agonista de longa duração (LABA) e um anticolinérgico de longa duração (LAMA)_ . Brasília, 2020.  
64. Grant AC, Walker R, Hamilton M, et al. The ELLIPTA ® Dry Powder Inhaler: Design, Functionality, In Vitro Dosing Performance and Critical Task Compliance by Patients and Caregivers. _J Aerosol Med Pulm Drug Deliv_ 2015; 28: 474– 485.  
65. Prime D, de Backer W, Hamilton M, et al. Effect of Disease Severity in Asthma and Chronic Obstructive Pulmonary Disease on Inhaler-Specific Inhalation Profiles Through the ELLIPTA ® Dry Powder Inhaler. _J Aerosol Med Pulm Drug Deliv_ 2015; 28: 486–497.  
66. Baloira A, Abad A, Fuster A, et al. Lung Deposition and Inspiratory Flow Rate in Patients with Chronic Obstructive Pulmonary Disease Using Different Inhalation Devices: A Systematic Literature Review and Expert Opinion. _Int J Chron Obstruct Pulmon Dis_ 2021; Volume 16: 1021–1033.  
67. _Anoro ® Ellipta ® brometo de umeclidínio + trifenatato de vilanterol [bula de medicamento]_ . 2023.  
68. _Spiolto ® brometo de tiotrópio monoidratado + cloridrato de olodaterol [bula de medicamento]_ . 2025.  
69.  
70.  
- _Clenil ® dipropionato de beclometasona [bula de medicamento]_ . 2024.  
- Para B, De Saúde P. _Busonid ® budesonida [bula de medicamento]_ . 2022.  
71. Loke YK, Cavallazzi R, Singh S. Risk of fractures with inhaled corticosteroids in COPD: systematic review and metaanalysis of randomised controlled trials and observational studies. _Thorax_ 2011; 66: 699–708.  
72. Martinez FJ, Rabe KF, Ferguson GT, et al. Reduced All-Cause Mortality in the ETHOS Trial of Budesonide/Glycopyrrolate/Formoterol for Chronic Obstructive Pulmonary Disease. A Randomized, Double-Blind, Multicenter, Parallel-Group Study. _Am J Respir Crit Care Med_ 2021; 203: 553–564.  
73. Lipson DA, Crim C, Criner GJ, et al. Reduction in All-Cause Mortality with Fluticasone Furoate/Umeclidinium/Vilanterol in Patients with Chronic Obstructive Pulmonary Disease. _Am J Respir Crit Care Med_ 2020; 201: 1508–1516.  
74. Ministério da Saúde. _Tripla combinação fixa em um único dispositivo spray de dipropionato de beclometasona 100 µg fumarato de formoterol di-hidratado 6 µg e brometo de glicopirrônio 12,5 µg no tratamento da DPOC grave (30% ≤ VEF1 < 50%) e muito grave (VEF1 < 30%) grupo C e grupo D_ . Brasília, 2024.  
75. Ministério da Saúde. _Furoato de fluticasona/brometo de umeclidínio/trifenatato de vilanterol para o tratamento da Doença Pulmonar Obstrutiva Crônica (DPOC) grave a muito grave (GOLD 3 e 4) com perfil exacerbador e sintomático (Grupo D)_ . Brasília, 2024.  
76. _Trelegy ® furoato de fluticasona/brometo de umeclidínio/trifenatato de vilanterol [bula de medicamento]_ . 2023.  
77. _Trimbow ® diproprionato de beclometasona + fumarato de formoterol di-hidratado +brometo de glicopirrônio [bula de medicamento]_ . 2023.  
78. Ma Z, Zhang W. Short-term versus longer duration of glucocorticoid therapy for exacerbations of chronic obstructive pulmonary disease. _Pulm Pharmacol Ther_ 2016; 40: 84–90.  
79. Walters JA, Tan DJ, White CJ, et al. Systemic corticosteroids for acute exacerbations of chronic obstructive pulmonary disease. _Cochrane Database of Systematic Reviews_ ; 2014. Epub ahead of print 1 September 2014. DOI: 10.1002/14651858.CD001288.pub4.  
80. Recio Iglesias J, Díez-Manglano J, López García F, et al. Management of the COPD Patient with Comorbidities: An Experts Recommendation Document. _Int J Chron Obstruct Pulmon Dis_ 2020; Volume 15: 1015–1037.  
32  
81. _Predsim ® prednisolona_ . 2023.  
82. _Crispred ® prednisona_ . 2022.  
83. _Gliocort ® succinato sódico de hidrocortisona_ . 2024.  
84. Ministério da Saúde. _Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose_ . Brasília.  
85. Taylor SP, Sellers E, Taylor BT. Azithromycin for the Prevention of COPD Exacerbations: The Good, Bad, and Ugly. _Am J Med_ 2015; 128: 1362.e1-1362.e6.  
86. Albert RK, Connett J, Bailey WC, et al. Azithromycin for Prevention of Exacerbations of COPD. _New England Journal of Medicine_ 2011; 365: 689–698.  
87. Anvisa. Dupilumabe 200mg/ 300mg. Dupixent. Bula Profissional. Sanofi Medley Farmacêutica Ltda.  
88. Rabe KF, Martinez FJ, Ferguson GT, et al. Triple Inhaled Therapy at Two Glucocorticoid Doses in Moderate-to-VerySevere COPD. _New England Journal of Medicine_ 2020; 383: 35–48.  
89. Ministério da Saúde. Protocolos Clínicos e Diretrizes Terapêuticas da Asma . _PORTARIA CONJUNTA SAES/SECTICS N_<sup>_o_</sup> _32, de 20 de DEZEMBRO de 2023_ , https://www.gov.br/conitec/pt-br/midias/relatorios/portaria/2023/portariaconjunta-saes-sectics-no-32-pcdt-asma.pdf (2023, accessed 18 February 2025).  
90. Ministério da Saúde. _Manual dos Centros de Referência para Imunobiológicos Especiais_ . 6a edição. Brasília: Ministério da Saúde, http://bvsms.saude.gov.br/bvs/publicacoes/manual_centros_referencia_imunobiologicos_6ed.pdf (2023).  
91. Ministerio de Salud. Lineamientos técnicos para el abordaje integral de enfermedades respiratorias crónicas, asma en personas mayores o iguales a 12 años y Enfermedad Pulmonar Obstructiva Crónica (EPOC). _Gobierno de El Salvador_ .  
92. Soler-Cataluña JJ, Piñera P, Trigueros JA, et al. Actualización 2021 de la guía española de la EPOC (GesEPOC). Diagnóstico y tratamiento del síndrome de agudización de la EPOC. _Arch Bronconeumol_ 2022; 58: 159–170.  
93. Bourbeau J, Bhutani M, Hernandez P, et al. 2023 Canadian Thoracic Society Guideline on Pharmacotherapy in Patients With Stable COPD. _Chest_ 2023; 164: 1159–1183.  
94. Stevermer J, Fisher L, Liu K, et al. Pharmacologic Management of COPD Exacerbations: A Clinical Practice Guideline from the AAFP. _Am Fam Physician_ 2021; 104: 103A-103L.  
95. Cheng S-L, Lin C-H, Chu K-A, et al. Update on guidelines for the treatment of COPD in Taiwan using evidence and GRADE system-based recommendations. _Journal of the Formosan Medical Association_ 2021; 120: 1821–1844.  
96. Zysman M, Baptista BR, Soumagne T, et al. Position paper of the French Society of Respiratory Diseases regarding pharmacological treatment optimization for stable COPD in 2021. _Respir Med Res_ 2022; 81: 100889.  
97. Miravitlles M, Calle M, Molina J, et al. [Translated article] Spanish COPD guidelines (GesEPOC) 2021: Updated pharmacological treatment of stable COPD. _Arch Bronconeumol_ 2022; 58: T69–T81.  
98. Cosío BG, Hernández C, Chiner E, et al. [Translated article] Spanish COPD Guidelines (GesEPOC 2021): Nonpharmacological Treatment Update. _Arch Bronconeumol_ 2022; 58: T345–T351.  
99. Lopez-Campos JL, Almagro P, Gómez JT, et al. Actualización de la Guía Española de la EPOC (GesEPOC): comorbilidades, automanejo y cuidados paliativos. _Arch Bronconeumol_ 2022; 58: 334–344.  
100. Pedroso Camargos A, Barreto S, Brant L, et al. Performance of contemporary cardiovascular risk stratification scores in Brazil: an evaluation in the ELSA-Brasil study. _Open Heart_ 2024; 11: e002762.  
101. Brasil. Ministério da Saúde. Estratégia de Saúde Cardiovascular na Atenção Primária à Saúde: instrutivo para profissionais e gestores. _Ministério da Saúde. Brasília_ , http://bvsms.saude.gov.br/bvs/publicacoes/estrategia_saude_cardiovascular_inst rutivo_profissionais.pdf (2022, accessed 21 April 2025).  
33  
102. Justel Enríquez A, Rabat-Restrepo JM, Vilchez-López FJ, et al. Practical Guidelines by the Andalusian Group for Nutrition Reflection and Investigation (GARIN) on Nutritional Management of Patients with Chronic Obstructive Pulmonary Disease: A Review. _Nutrients_ 2024; 16: 3105.  
34  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**  
- BROMETO DE IPRATRÓPIO, BROMETO DE TIOTRÓPIO MONOIDRATADO + CLORIDRATO DE OLODATEROL, BROMETO DE UMECLIDÍNIO + TRIFENATATO DE VILANTEROL, BROMIDRATO DE FENOTEROL,  
- BUDESONIDA, DIPROPIONATO DE BECLOMETASONA + FUMARATO DE FORMOTEROL DI-HIDRATADO + BROMETO DE GLICOPIRRÔNIO, DIPROPRIONATO DE BECLOMETASONA, FUMARATO DE FORMOTEROL,  
- FUMARATO DE FORMOTEROL + BUDESONIDA, FUROATO DE FLUTICASONA + BROMETO DE UMECLIDÍNIO + TRIFENATATO DE VILANTEROL, FOSFATO SÓDICO DE PREDNISOLONA, PREDNISONA, SUCCINATO SÓDICO DE HIDROCORTISONA, SULFATO DE SALBUTAMOL  
Eu, _______________________________________________________________________________________nome  
do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **brometo de ipratrópio, brometo de tiotrópio monoidratado + cloridrato de olodaterol, brometo de umeclidínio + trifenatato de vilanterol, bromidrato de fenoterol, budesonida, dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio, diproprionato de beclometasona, fumarato de formoterol, fumarato de formoterol + budesonida, furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol, fosfato sódico de prednisolona, prednisona, succinato sódico de hidrocortisona, sulfato de salbutamol,** indicada para o tratamento de doença pulmonar obstrutiva crônica (DPOC).  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
_______________________________________________________________________________________________ (nome  
do (a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- diminuição das internações hospitalares;  
- diminuição das faltas ao trabalho em virtude da doença;  
- melhora da condição de saúde; e  
- melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- **budesonida** , **prednisona, bromidrato de fenoterol e brometo de ipratrópio** são classificados na gestação como  
- categoria B de risco;  
- **succinato sódico de hidrocortisona, fosfato sódico de prednisolona, brometo de tiotrópio monoidratado +**  
- **cloridrato de olodaterol, dipropionato de beclometasona, fumarato de formoterol, sulfato de salbutamol, fumarato de formoterol + budesonida, brometo de umeclidínio + trifenatato de vilanterol, dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio, furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol** são classificado na gestação como categoria C de risco;  
- **eventos adversos mais comuns da budesonida:** palpitações, síncope, taquicardia, hipocalemia, ganho de peso, náusea,  
- equimose, leucocitose, artralgia e mialgia, dor de cabeça, doença infecciosa, doença viral, otite média, disfonia, infecção do trato respiratório, sinusite, febre, dor e boca seca;  
- **eventos adversos mais comuns do diproprionato de beclometasona:** laringite, faringite, candidíase oral, náusea e  
- dispepsia;  
35  
• **eventos adversos mais comuns do fumarato de formoterol, bromidrato de fenoterol, fumarato de formoterol + budesonida e sulfato de salbutamol:** dor de cabeça, tremor, palpitações e tosse;  
• **eventos adversos da prednisona, fosfato sódico de prednisolona e succinato sódico de hidrocortisona:** retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, osteoporose, problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, manifestação de diabete melito, mascaramento de infecções, ativação de infecções latentes, infecções oportunistas e supressão da reação a testes cutâneos;  
- **eventos adversos mais comuns do brometo de ipratrópio:** cefaleia, tontura, irritação na garganta, tosse, boca seca,  
- náusea e distúrbios da motilidade gastrintestinal;  
- **eventos adversos mais comuns do brometo de tiotrópio monoidratado + cloridrato de olodaterol:** boca seca  
- (geralmente leve), tontura, taquicardia, tosse e disfonia;  
- **eventos adversos mais comuns do brometo de umeclidínio + trifenatato de vilanterol:** nasofaringite, pneumonia,  
- infecção do trato respiratório superior, bronquite, faringite, rinite, sinusite, gripe, candidíase oral e de faringe, infecção do trato urinário, infecção viral do trato respiratório, cefaleia, tosse, dor orofaríngea, disfonia, artralgia, dorsalgia, constipação;  
• **eventos adversos mais comuns do dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio:** pneumonia, faringite, candidíase oral, infecção do trato urinário, nasofaringite, dor de cabeça e disfonia;  
- **eventos adversos mais comuns do furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol:**  
- infecção do trato urinário, sinusite, nasofaringite, faringite, infecção do trato respiratório superior, tosse, dor orofaríngea, constipação, boca seca e dor torácica;  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) brometo de ipratrópio  
- (    ) brometo de tiotrópio monoidratado + cloridrato de olodaterol  
- (    ) brometo de umeclidínio + trifenatato de vilanterol  
- (    ) bromidrato de fenoterol  
- (    ) budesonida  
- (  ) dipropionato de beclometasona + fumarato de formoterol di-hidratado + brometo de glicopirrônio  
- (    ) diproprionato de beclometasona  
- (    ) fumarato de formoterol  
- (    ) fumarato de formoterol + budesonida  
- (    ) furoato de fluticasona + brometo de umeclidínio + trifenatato de vilanterol  
- (    ) fosfato sódico de prednisolona  
- (    ) prednisona  
36  
- (    ) succinato sódico de hidrocortisona  
(    ) sulfato de salbutamol  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
37

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **ESCALA DE DISPNEIA MODIFICADA** -->
|**Classificação**|**Características**|
|---|---|
|Grau 0|Falta de ar surge quando realiza atividade física intensa (correr, nadar, praticar esporte).|
|Grau 1|Falta de ar surge quando caminha de maneira apressada no plano ou quando caminha em subidas|
|Grau 2|Anda mais devagar do que pessoas da mesma idade devido à falta de ar; ou quando caminha no<br>plano, no próprio passo, precisa parar para respirar.|
|Grau 3|Após andar menos de 100 metros ou alguns minutos no plano, precisa parar para respirar.|
|Grau 4|Falta de ar impede que saia de sua casa; tem falta de ar quando troca de roupa.|  
Fonte: Medical Research Council (mMRC)<sup>24</sup>  
38  
**TESTE DE AVALIAÇÃO DA DPOC**

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: Nome: -->
|**Exemplo:**|Pontuação|
|---|---|
|Estou muito feliz|Estou muito triste<br>**1**|  
|Assinale com um X a resposta mais|adequada para cada situação clí|nica:|
|---|---|---|
|Eu nunca tenho tosse|~~DIETEEOIE~~<br>|Tenho tosse o tempo todo<br>~~[|~~<br>|
|Não tenho nenhum catarro||O meu peito está cheio de<br><br>|
|(secreção) no peito|~~OUVaIaG~~<br>|catarro (secreção)<br>~~fo~~<br>|
|Não sinto nenhuma pressão no||Sinto uma grande pressão no<br><br>|
|peito||peito<br><br>|
|Não sinto falta de ar quando subo||Sinto bastante falta de ar quando<br><br>|
|uma ladeira ou um andar de<br>escada|~~OOVaaH~~|subo uma ladeira ou um andar<br>de escada<br>~~a~~|
|Não sinto nenhuma limitação nas||Sinto-me muito limitado nas<br><br>|
|minhas atividades em casa||minhas atividades em casa<br>|
|Sinto-me confiante para sair de||Não me sinto nada confiante<br><br>|
|casa, apesar da minha doença<br>pulmonar|~~OOVaaH~~|para sair de casa, por causa da<br>minha doença pulmonar<br><br>~~|~~|
|||Não durmo profundamente<br>|
|Durmo profundamente||devido à minha doença<br>pulmonar|
|Tenho muita energia (disposição)|~~OOVaaH~~|Não tenho nenhuma energia<br>(disposição)<br>~~|~~|
|||**Pontuação total**<br>|  
Fonte: COPD Assessment Test - CAT<sup>TM25</sup>  
39

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **TESTE DE FAGERSTRÖM** -->
1. Quanto tempo após acordar você fuma seu primeiro cigarro? Dentro de 5 minutos (3) Entre 6 e 30 minutos (2) Entre 31 e 60 minutos (1) Após 60 minutos (0)  
2. Você acha difícil não fumar em lugares proibidos, como igrejas, bibliotecas, etc.? Sim (1) Não (0) 3. Que cigarro do dia traz mais satisfação? O primeiro da manhã (1) Outros (0)  
4. Quantos cigarros você fuma por dia? Menos de 10 (0) de 11 a 20 (1) de 21 a 30 (2) Mais de 31 (3)  
5. Você fuma mais frequentemente pela manhã? Sim (1) Não (0)  
6. Você fuma, mesmo doente, quando precisa ficar de cama a maior parte do tempo? Sim (1) Não (0)  
**Grau de Dependência:**  
0 – 2 pontos = muito baixo 3 – 4 pontos = baixo 5 pontos = médio  
6 – 7 pontos = elevado  
8 – 10 pontos = muito elevado  
Fonte: Brasil, Ministério da Saúde<sup>32</sup>  
40  
**ESTÁGIOS DE MOTIVAÇÃO PARA A CESSAÇÃO DO TABAGISMO**  
- Pré-contemplação: estágio em que não há intenção de mudança nem mesmo uma crítica a respeito do conflito  
- envolvendo o comportamento-problema.  
- Contemplação: estágio que se caracteriza pela conscientização de que existe um problema, no entanto há uma  
- ambivalência quanto à perspectiva de mudança.  
- Ação: estágio em que o paciente escolhe uma forma de mudar e toma uma atitude neste sentido.  
- Manutenção: estágio em que se trabalham a prevenção à recaída e a consolidação dos ganhos obtidos durante o estágio  
Ação  
Fonte: Prochaska e Di Clemente<sup>33</sup>  
41

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria Conjunta SAES-SCTIE/MS nº 29/2025, impôs-se um ajuste do Protocolo Clínico e Diretrizes Terapêuticas da Doença Pulmonar Obstrutiva Crônica, pela necessidade de corrigir as menções aos números dos itens sobre “Diagnóstico” (item 3) na parte dos “Critérios de Inclusão” e do “Tratamento cirúrgico” (item 7.1.4) citado no Quadro 5.  
O tema foi apresentado como informe à 132ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 13 de janeiro de 2025.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **1.        Escopo e finalidade do Protocolo** -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Doença Pulmonar Obstrutiva Crônica (DPOC) foi incluir:  
- a combinação de furoato de fluticasona/brometo de umeclidínio/trifenatato de vilanterol para o tratamento de DPOC grave a muito grave com perfil exacerbador e sintomático, incorporada ao SUS conforme Portaria SECTICS/MS nº 46, de 07 de outubro de 2024, e o Relatório de Recomendação nº 935, de 07 de outubro de 2024; e  
- a tripla combinação fixa em um único dispositivo spray de dipropionato de beclometasona 100 µg fumarato de formoterol di-hidratado 6 µg e brometo de glicopirrônio 12,5 µg no tratamento da DPOC grave e muito grave, incorporada ao SUS conforme Portaria SECTICS/MS nº 44, de 07 de outubro de 2024 e o Relatório de Recomendação nº 936, de 07 de outubro de 2024.  
Considerando a versão do PCDT da DPOC, publicado por meio da Portaria Conjunta SCTIE/SAES/MS nº 19, de 22 de novembro de 2021, esta atualização rápida focou na inclusão das associações supracitadas no âmbito do SUS.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **2.        Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Doença Pulmonar Obstrutiva Crônica foi apresentada na 124ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em abril de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES); Secretaria de Atenção Primária à Saúde (SAPS); Secretaria de Vigilância em Saúde e Ambiente (SVSA); e Secretaria de Saúde Indígena (SESAI). A proposta foi aprovada para avaliação da Conitec.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **3.        Consulta pública** -->
A Consulta Pública nº 35/2025, do Protocolo Clínico e Diretrizes Terapêuticas da Doença Pulmonar Obstrutiva Crônica, foi realizada entre os dias 30 de maio de 2025 e 18 de junho de 2025. Foram recebidas 382 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2025/contribuicao-da-cp-35_2025-pcdt-paradoenca-pulmonar-obstrutiva-cronica</u>

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **4.       Busca da evidência e recomendações** -->
42  
As evidências e pergunta de pesquisa avaliadas no momento da incorporação das associações de furoato de fluticasona/brometo de umeclidínio/trifenatato de vilanterol e dipropionato de beclometasona/fumarato de formoterol dihidratado /brometo de glicopirrônio, incluídas nesta atualização, encontram-se nos Relatório de Recomendação nº 935/2024, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacao-no-935-furoato-defluticasona e nº 936/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/relatorio-de-recomendacaono-936-beclometasona, respectivamente.</u>  
Com o objetivo de atualizar as informações fornecidas a versão do PCDT da DPOC publicada por meio da Portaria Conjunta SCTIE/SAES/MS nº 19/2021, foram realizadas buscas sistemáticas da literatura para identificação de diretrizes de práticas clínicas nacionais ou internacionais para atualização do texto do PCDT.  
A pergunta de pesquisa foi construída com base no acrônimo PCC (População, Conceito, Contexto), descrito no **Quadro**  
**A** :  
**Quadro A -** Pergunta de pesquisa PCC para busca de diretrizes nacionais e internacionais sobre DPOC  
|**População**|Pacientes com DPOC|
|---|---|
|**Conceito**|Publicações que abordem o cuidado ou aspectos relacionados à DPOC|
|**Contexto**|Diretrizes nacionais e internacionais|  
Fonte: autoria própria  
As buscas foram conduzidas nas bases Medline (via PubMed), EMBASE e Lilacs (via BVS) em 14/01/2025. Não foram utilizadas restrições de idioma e a data de publicação foi restringida ao ano de 2021 em diante, data de publicação do PCDT da DPOC a ser atualizado. As estratégias de busca para cada base estão descritas no **Quadro B.**  
**Quadro B -** Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes nacionais e internacionais sobre DPOC  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
|Medline<br>(via|("Pulmonary Disease, Chronic Obstructive"[Mesh]) OR ("Chronic Obstructive|110|
|PubMed)|Pulmonary Diseases"[Text Word] OR COPD[Text Word] OR "Chronic<br>Obstructive Lung Disease"[Text Word] OR "Chronic Obstructive Pulmonary<br>Disease"[Text Word] OR COAD[Text Word] OR "Chronic Obstructive Airway<br>Disease"[Text Word] OR "Airflow Obstruction, Chronic"[Text Word] OR<br>"Airflow<br>Obstructions,<br>Chronic"[Text<br>Word]<br>OR<br>"Chronic<br>Airflow<br>Obstructions"[Text<br>Word]<br>OR<br>"Chronic<br>Airflow<br>Obstruction"[Text<br>Word]) Filters: in the last 10 years, Guideline, Practice Guideline||
|EMBASE|#1 'chronic obstructive lung disease'/exp OR 'chronic airflow obstruction' OR<br>'chronic airway obstruction' OR 'chronic obstructive bronchopulmonary disease'<br>OR 'chronic obstructive lung disease' OR 'chronic obstructive lung disorder' OR<br>'chronic obstructive pulmonary disease' OR 'chronic obstructive pulmonary<br>disorder' OR 'chronic obstructive respiratory disease' OR 'chronic pulmonary<br>obstructive disease' OR 'chronic pulmonary obstructive disorder' OR 'copd' OR<br>'lung chronic obstructive disease' OR 'lung disease, chronic obstructive' OR<br>'obstructive chronic lung disease' OR 'obstructive chronic pulmonary disease'|324|  
43  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
||OR 'obstructive lung disease, chronic' OR 'pulmonary disease, chronic<br>obstructive' OR 'pulmonary disorder, chronic obstructive'<br>#2 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)<br>#3 AND (2021:py OR 2022:py OR 2023:py OR 2024:py OR 2025:py)<br>#4 AND 'practice guideline'/de<br>#5 AND 'article'/it||
|Lilacs (via BVS)|(mh:("Doença Pulmonar Obstrutiva Crônica")) OR ("Pulmonary Disease,<br>Chronic Obstructive") OR ("Enfermedad Pulmonar Obstructiva Crónica") OR<br>(coad OR copd OR "Doença Obstrutiva Crônica das Vias Aéreas" OR "Doença<br>Obstrutiva Crônica do Pulmão" OR "Doença Obstrutiva Crônica Pulmonar" OR<br>"Doenças Pulmonares Obstrutivas Crônicas" OR dpoc OR "Obstrução Crônica<br>do Fluxo Respiratório" OR "Obstrução do Fluxo Respiratório Crônica") AND<br>db:("LILACS" OR "colecionaSUS") AND type_of_study:("guideline") AND<br>(year_cluster:[2015 TO 2025]) AND instance:"lilacsplus"|110|  
Fonte: autoria própria  
A elegibilidade dos estudos identificados por meio de busca sistemática foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> ¹. Na segunda etapa, realizouse a leitura de texto completo, mantendo-se documentos que considerem o diagnóstico, tratamento ou monitoramento, cuidados ou qualquer outro aspecto de interesse sobre a DPOC. As divergências foram resolvidas por terceiro revisor.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Resultados da busca** -->
Foram identificadas 544 publicações. Após a exclusão das duplicatas (n = 22) e triagem pela leitura de títulos e resumos, 13 publicações foram selecionadas para a leitura do texto completo ( **Figura A** ). Três estudos foram excluídos por leitura de texto completo após constatar que eram as diretrizes mais antigas do conjunto, publicadas antes da versão do PCDT da DPOC (2021). Os estudos excluídos são descritos no **Quadro C.** No total, foram incluídas 10 publicações, descritas no **Quadro D.**  
44

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Resultados da busca** -->
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:  Referências removidas antes do<br>Bases de dados (n = 544)  processo de seleção:<br>PubMed (n = 110)  Duplicatas (n = 22)<br>Embase (n = 324)<br>LILACS (n = 110)<br>Referências excluídas<br>(n = 509)<br>Referências avaliadas por título e<br>resumo<br>(n = 522)<br>Referências cujo texto completo não<br>foi identificado<br>(n = 0)<br>Referências incluídas para avaliação<br>por texto completo<br>(n = 13)<br>Referências avaliadas por texto<br>completo (n = 13)  Referências excluídas: (n = 3)<br>Estudos incluídos na revisão<br>(n = 10)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
45  
Fonte: autoria própria  
**Quadro C -** Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.  
|**Diretrizes excluídas pela data de publicação**|
|---|
|Guía Peruana de EPOC -2016. Documento base del Proyecto de Capacitación y Estudio Epidemiológico de la EPOC en el|
|Perú (PER –EPOC). Sociedad Peruana de Neumología. Publicación Oficial de la Asociación Latinoamericana de Tórax<br>(ALAT)|
|Lim, T. K., Chee, C., Chow, P., Chua, G., Eng, S. K., Goh, S. K., et al. Ministry of health clinical practice guidelines: chronic<br>obstructive pulmonary disease. 2018.|
|Stolz, D., Barandun, J., Borer, H., Bridevaux, P. O., Brun, P., Brutsche, M., Tamm, M. Diagnosis, prevention and treatment|
|of stable COPD and acute exacerbations of COPD: the Swiss recommendations 2018. Respiration, 2018:96(4), 382-398.|
|Fonte: autoria própria|  
Considerando que as diretrizes identificadas na literatura correspondem a países diferentes, o **Quadro D** elenca o país e ano de publicação. Ressalta-se que documentos com objetivos diferentes, para diagnóstico, tratamento e monitorização foram publicados pela Espanha e foram consideradas na mesma coluna da matriz de informações. A recomendação global da matriz consiste na concordância do conteúdo das diretrizes consultadas.  
46  
**Quadro D -** Matriz de recomendações das diretrizes clínicas sobre DPOC  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
|Diagnóstico<br>clínico|Os principais<br>sintomas são<br>dispneia<br>progressiva,<br>tosse crônica e<br>produção de|A DPOC é<br>caracterizada por<br>limitação do fluxo<br>aéreo e sintomas<br>respiratórios<br>crônicos,|A DPOC é<br>caracterizada por<br>limitação<br>persistente ao<br>fluxo aéreo e<br>sintomas|A DPOC deve ser<br>considerada em<br>pacientes com<br>dispneia, tosse<br>crônica ou produção<br>de escarro,|A espirometria<br>pós-<br>broncodilatador é<br>essencial para o<br>diagnóstico de<br>DPOC, sendo|Pacientes com<br>dispneia, tosse<br>crônica, produção<br>de catarro<br>(expectoração) e<br>histórico de|O diagnóstico<br>da DPOC<br>deve incluir<br>avaliação<br>nutricional,<br>pois a perda|A DPOC deve ser<br>considerada em<br>pacientes com<br>dispneia, tosse<br>crônica e produção<br>de escarro,|
||escarro. O<br>diagnóstico deve<br>ser baseado na<br>história clínica,|incluindo tosse e<br>dispneia.<br>A espirometria<br>pós-|respiratórios<br>crônicos, como<br>dispneia, tosse e<br>produção de|independentemente<br>do histórico de<br>exposição a fatores<br>de risco.|confirmada<br>quando a relação<br>FEV1/FVC <<br>0,70.|exposição a<br>fatores de risco<br>(tabagismo,<br>poluição do ar,|de peso é um<br>fator de risco<br>para pior<br>prognóstico.|independentemente<br>do histórico de<br>exposição a fatores<br>de risco. O|
||incluindo<br>exposição a<br>fatores de risco<br>como tabagismo,<br>poluição do ar e|broncodilatador é<br>essencial para<br>confirmar o<br>diagnóstico da<br>DPOC.|escarro.<br>O exame de<br>referência para<br>confirmação<br>diagnóstica é a|Pacientes com<br>histórico de<br>tabagismo<br>prolongado ou<br>exposição a|A severidade da<br>obstrução deve<br>ser avaliada pelo<br>grau de redução<br>do FEV1.|entre outros).<br>Outros<br>parâmetros de<br>avaliação incluem<br>a Escala de|Medidas de<br>bioimpedân<br>cia e força<br>de preensão<br>manual são|diagnóstico deve<br>ser confirmado por<br>espirometria pós-<br>broncodilatador,<br>com relação|
||exposições|A relação|espirometria,|poluentes|Dispneia e|Dispneia|sugeridas|VEF1/CVF < 0,70.|
||ocupacionais.|FEV1/FVC < 0,70|demonstrando um|ambientais devem|intolerância ao|(mMRC) e o|para||
||Espirometria|é o critério|VEF1/CVF < 0,70|ser avaliados.|esforço físico são|Questionário|estratificaçã||
||com relação|diagnóstico aceito|após|Espirometria pós-|os sintomas mais|CAT|o do risco||
||VEF1/CVF <<br>0,7 pós-|para definir a<br>presença de|broncodilatador.|broncodilatador é o<br>método padrão para|comuns|Espirometria é<br>essencial para o|nutricional||
||broncodilatador|limitação ao fluxo<br>aéreo||confirmar a DPOC||diagnóstico,<br>sendo definida|||  
47  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||confirma o<br>diagnóstico|||(VEF1/CVF <<br>0,70).||pela relação<br>VEF1/CVF <<br>0,70 após o uso<br>de<br>broncodilatador|||
|Diagnóstico<br>laboratorial|Gasometria<br>arterial é<br>indicada para<br>pacientes com<br>suspeita de<br>insuficiência<br>respiratória<br>crônica.<br>Radiografia e<br>tomografia<br>computadorizada<br>de tórax são<br>úteis para<br>descartar<br>diagnósticos<br>diferenciais e<br>avaliar a||Outros exames<br>podem incluir<br>gasometria<br>arterial,<br>especialmente<br>para casos graves,<br>e tomografia<br>computadorizada<br>para avaliar<br>enfisema ou<br>excluir outras<br>doenças<br>pulmonares.|Gasometria arterial,<br>principalmente para<br>pacientes com<br>suspeita de<br>insuficiência<br>respiratória.<br>Radiografia ou<br>tomografia<br>computadorizada do<br>tórax, especialmente<br>para diferenciar<br>fenótipo<br>enfisematoso ou<br>brônquico crônico.<br>Contagem de<br>eosinófilos no<br>sangue com níveis<br>elevados (> 300|Os níveis de<br>eosinófilos no<br>sangue podem<br>ajudar a guiar a<br>terapia com<br>corticoides<br>inalatórios (CI),<br>já que contagens<br>≥ 300 células/mL<br>estão associadas a<br>melhor resposta<br>terapêutica|.<br>Gasometria<br>arterial para<br>avaliar hipoxemia<br>e hipercapnia.<br>Radiografia ou<br>tomografia de<br>tórax para<br>diferenciar de<br>outras doenças<br>pulmonares.<br>Teste de alergia e<br>IgE sérica para<br>descartar asma|Marcadores<br>nutricionais<br>como<br>albumina<br>sérica e índice<br>de massa<br>corporal<br>(IMC) devem<br>ser incluídos<br>na avaliação<br>inicial.|Gasometria arterial é<br>indicada para<br>pacientes com<br>suspeita de<br>insuficiência<br>respiratória.<br>Radiografia ou<br>tomografia de tórax<br>são úteis para<br>descartar<br>diagnósticos<br>diferenciais. A<br>contagem de<br>eosinófilos no sangue<br>(> 300 células/μL)<br>pode guiar o uso de<br>corticoides<br>inalatórios.|  
48  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||presença de<br>enfisema.<br>Eosinofilia<br>sanguínea pode<br>indicar resposta<br>aos corticoides<br>inalatórios.|||células/μL) podem<br>indicar melhor<br>resposta a<br>corticoides<br>inalatórios.<br>Testes de alfa-1<br>antitripsina, em<br>casos suspeitos de<br>deficiência genética.|||||
|Diagnóstico<br>diferencial|Asma:<br>Espirometria<br>com<br>broncodilatador:<br>melhora ≥ 12% e<br>≥ 200 mL no<br>VEF1 sugere<br>asma.<br>Insuficiência<br>Cardíaca):<br>Ecocardiograma<br>para avaliar<br>disfunção<br>ventricular.|Asma:  A<br>espirometria com<br>teste<br>broncodilatador é<br>essencial para<br>diferenciação.<br>Bronquiectasias:<br>A TCAR é<br>recomendada para<br>a diferenciação.<br>Doença pulmonar<br>intersticial: Testes<br>de função<br>pulmonar podem<br>ajudar a|Pacientes com<br>exacerbações<br>frequentes podem<br>ter asma<br>sobreposta, e a<br>contagem de<br>eosinófilos no<br>sangue pode<br>ajudar na<br>diferenciação.<br>Tomografia de<br>tórax pode ser útil<br>para excluir<br>fibrose pulmonar|Contagem de<br>eosinófilos e testes<br>de broncodilatação<br>podem ajudar a<br>identificar pessoas<br>com asma<br>sobreposta.<br>Radiografia e<br>tomografia<br>computadorizada<br>podem ser úteis<br>para diferenciar<br>DPOC de<br>bronquiectasias,|Asma: Pacientes<br>com asma<br>geralmente<br>apresentam<br>reversibilidade<br>significativa da<br>obstrução ao<br>fluxo aéreo após<br>o uso de<br>broncodilatadores<br>, ao contrário da<br>DPOC.<br>Doença pulmonar<br>intersticial:<br>Doenças|||A espirometria com<br>broncodilatador é<br>essencial para<br>diferenciar DPOC de<br>asma. Insuficiência<br>cardíaca deve ser<br>descartada com<br>ecocardiograma e<br>BNP. Tomografia de<br>alta resolução pode<br>auxiliar na<br>diferenciação de<br>bronquiectasias e<br>doenças pulmonares<br>intersticiais.|  
49  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||Doença<br>Pulmonar<br>Intersticial:<br>Tomografia de<br>alta resolução<br>(TCAR)<br>apresenta padrão<br>reticular, fibrose.<br>Bronquiectasias:<br>a TCAR mostra<br>dilatação<br>brônquica e a<br>cultura de<br>escarro: pode<br>detectar<br>_Pseudomonas._|diferenciar essas<br>condições.<br>Pacientes com<br>DPOC apresentam<br>redução do<br>FEV1/FVC,<br>enquanto aqueles<br>com doença<br>pulmonar<br>intersticial<br>geralmente<br>apresentam<br>redução<br>proporcional da<br>capacidade<br>pulmonar total e<br>do volume<br>residual.<br>Insuficiência<br>cardíaca: é<br>recomendável a<br>medição de BNP e<br>ecocardiograma<br>em pacientes com|e outras condições<br>estruturais.|fibrose pulmonar e<br>tuberculose.|pulmonares<br>intersticiais<br>podem ter<br>sintomas<br>semelhantes à<br>DPOC, mas a<br>TCAR pode<br>ajudar a<br>diferenciá-las.<br>Insuficiência<br>cardíaca<br>congestiva:<br>Dispneia também<br>é um sintoma<br>comum da<br>insuficiência<br>cardíaca, e a<br>diferenciação<br>pode ser feita por<br>meio de<br>ecocardiografia e<br>BNP (peptídeo<br>natriurético tipo<br>B)||||  
50  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
|||dispneia<br>persistente para<br>excluir<br>insuficiência<br>cardíaca|||.||||
|Tratamento não<br>medicamentoso|Reabilitação<br>pulmonar é<br>recomendada<br>para todos os<br>pacientes<br>sintomáticos,<br>reduz dispneia e<br>melhora a<br>capacidade<br>funcional.<br>Atividade física<br>com prática<br>regular, adaptada<br>à condição<br>clínica do<br>paciente.<br>Pacientes<br>desnutridos<br>devem receber|Programas de<br>reabilitação<br>pulmonar,<br>fisioterapia<br>torácica e<br>suplementos<br>nutricionais são<br>considerados, mas<br>há evidências<br>limitadas para sua<br>eficácia.|Cessação do<br>tabagismo.<br>Reabilitação<br>pulmonar.<br>Recomenda-se<br>vacinação contra<br>influenza e<br>pneumococo para<br>reduzir<br>exacerbações e<br>hospitalizações.<br>Oxigenoterapia<br>domiciliar é<br>indicada para<br>pacientes com<br>hipoxemia crônica<br>grave.<br>Ventilação não<br>invasiva pode ser|Cessação do<br>tabagismo.<br>Vacinação contra<br>influenza e<br>pneumococo reduz<br>exacerbações e<br>hospitalizações.<br>Reabilitação<br>pulmonar melhora a<br>capacidade<br>funcional e<br>qualidade de vida,<br>reduzindo sintomas<br>e internações.<br>Suplementação<br>nutricional pode ser<br>necessária para<br>pacientes<br>desnutridos.|Atividade física<br>regular reduz<br>hospitalizações e<br>mortalidade na<br>DPOC.|Cessação do<br>tabagismo que<br>pode ser<br>combinada com<br>terapia de<br>reposição de<br>nicotina (TRN),<br>bupropiona ou<br>vareniclina..<br>Reabilitação<br>pulmonar.<br>Vacinação contra<br>Influenza e<br>antipneumocócica<br>são recomendadas<br>para reduzir<br>exacerbações.|Intervenção<br>nutricional<br>personalizada<br>para todos os<br>pacientes e<br>suplementaçã<br>o proteico-<br>calórica pode<br>ser necessária<br>para pacientes<br>com<br>sarcopenia.<br>Atividade<br>física<br>supervisionad<br>a melhora a<br>capacidade<br>funcional.|A cessação do<br>tabagismo é<br>fundamental. A<br>reabilitação pulmonar<br>melhora a qualidade<br>de vida e reduz<br>exacerbações. A<br>vacinação contra<br>influenza e<br>pneumococo é<br>recomendada.<br>Oxigenoterapia<br>domiciliar é indicada<br>para pacientes com<br>hipoxemia grave<br>(PaO₂ < 55 mmHg).|  
51  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||suporte<br>nutricional,<br>enquanto a<br>obesidade pode<br>impactar<br>negativamente a<br>doença.<br>Oxigenoterapia<br>domiciliar é<br>indicada para<br>pacientes com<br>PaO₂ < 55<br>mmHg em<br>repouso.<br>A ventilação não<br>invasiva é<br>recomendada<br>para pacientes<br>com hipercapnia<br>crônica.||utilizada em casos<br>específicos de<br>insuficiência<br>respiratória<br>crônica.|Ventilação não<br>invasiva pode ser<br>indicada para casos<br>graves com<br>hipercapnia.|||||
|Tratamento<br>medicamentoso|A base do<br>tratamento são<br>os<br>broncodilatadore|Antibióticos<br>sistêmicos são<br>recomendados<br>para exacerbações|O tratamento é<br>baseado em<br>broncodilatadores<br>de longa ação|Broncodilatadores<br>de longa ação<br>(LAMA e LABA)|Broncodilatadores<br>de longa ação<br>(LABA/LAMA)<br>são|Broncodilatadores<br>de curta duração:<br>(salbutamol e<br>ipratrópio) e de|Suplementaçã<br>o vitamínica<br>pode ser<br>necessária|Broncodilatadores de<br>longa ação (LAMA<br>e/ou LABA) são a<br>base do tratamento.|  
52  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||s de longa ação<br>(LABA e<br>LAMA).<br>Estratégia de<br>Tratamento por<br>Fenótipo:<br>Não exarcebador|agudas para<br>melhorar a taxa de<br>cura clínica e<br>reduzir falhas no<br>tratamento.<br>Corticoides<br>sistêmicos são|(LAMA e/ou<br>LABA), sendo o<br>pilar da terapia.<br>Corticoides<br>inalatórios são<br>indicados em<br>casos de|são a base do<br>tratamento.<br>LAMA é preferido<br>em pacientes com<br>risco elevado de<br>exacerbação.<br>LABA pode ser|recomendados<br>para todos os<br>pacientes<br>sintomáticos.<br>Para pacientes<br>com dispneia<br>moderada a grave|longa duração<br>(formoterol,<br>salmeterol,<br>tiotrópio,<br>glicopirrônio).<br>Corticoides<br>inalatórios são|para pacientes<br>com<br>deficiência de<br>vitamina D.|Pacientes com<br>exacerbações<br>frequentes e<br>eosinofilia elevada (><br>300 células/μL)<br>devem receber<br>corticoides|
||- LAMA +<br>LABA<br>(broncodilatador<br>es de longa<br>ação).<br>Exacerbador|recomendados<br>para reduzir falhas<br>no tratamento,<br>mas não há<br>evidências<br>suficientes para|exacerbações<br>frequentes e na<br>presença de<br>eosinofilia<br>periférica (> 300<br>células/μL).|utilizado<br>isoladamente, mas a<br>combinação LABA<br>+ LAMA é<br>recomendada para<br>pacientes com|e alto risco de<br>exacerbações, a<br>terapia tripla<br>(LAMA/LABA/C<br>I) é indicada.<br>O uso de|indicados para<br>pacientes com<br>exacerbações<br>frequentes e<br>eosinófilos > 300<br>células/µl.||inalatórios.|
||Eosinofílico -<br>LABA +|definir dose, via<br>de administração|Inibidores da<br>fosfodiesterase-4|sintomas<br>persistentes.|macrolídeos,<br>roflumilaste ou|Terapia tripla<br>(LAMA/LABA/C|||
||Corticoide|ou duração ideais.|(roflumilaste)|Corticoides|N-acetilcisteína|I) é recomendada|||
||Inalatório (ICS)<br>(se eosinófilos ><br>300<br>células/mm³).|Broncodilatadores<br>de curta ação são<br>amplamente<br>utilizados para|podem ser<br>considerados em<br>pacientes com<br>exacerbações|inalatórios (CI) são<br>indicados para<br>pacientes com<br>exacerbações|pode ser<br>considerado para<br>subgrupos<br>específicos.|para pacientes<br>com alto risco de<br>exacerbações.<br>Antibióticos são|||
||Exacerbador|alívio sintomático|frequentes e|frequentes e||indicados apenas|||
||Não Eosinofílico|durante|bronquite crônica.|eosinofilia elevada||em exacerbações|||
||- LABA +<br>LAMA (ICS só|exacerbações.|Macrolídeos<br>(azitromicina)|(> 300 células/μL).||com sinais de<br>infecção.|||  
53  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||se eosinófilos ><br>100<br>células/mm³).<br>Outros<br>medicamentos:<br>Roflumilaste<br>para<br>exacerbações<br>frequentes<br>associadas a<br>bronquite<br>crônica.<br>Macrolídeos<br>(azitromicina<br>500 mg<br>3x/semana) para<br>pacientes com ≥<br>3 exacerbações<br>no último ano.||podem ser usados<br>como terapia<br>preventiva em<br>pacientes<br>específicos.<br>O uso de teofilina<br>tem indicação<br>limitada devido ao<br>risco de eventos<br>adversos.|Inibidores da<br>fosfodiesterase-4<br>(roflumilaste)<br>podem ser<br>considerados em<br>pacientes com<br>bronquite crônica e<br>exacerbações<br>frequentes.<br>Macrolídeos<br>(azitromicina,<br>eritromicina) podem<br>ser usados como<br>terapia preventiva<br>em pacientes com<br>exacerbações<br>recorrentes.<br>Teofilina pode ser<br>usada como terapia<br>adjunta, mas com<br>cautela devido ao<br>risco de eventos<br>adversos.|||||  
54  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
|Educação do|Treinamento da|A educação sobre|Adoção de|Treinamento no uso|A adesão ao|Treinamento no|Programas|Treinamento no uso|
|paciente|técnica correta<br>de inalação.<br>Orientação<br>quanto à<br>identificação<br>precoce de<br>exacerbações<br>Cessação do<br>tabagismo.|cessação do<br>tabagismo e<br>vacinação contra<br>pneumococo e<br>influenza são<br>estratégias<br>essenciais na<br>prevenção de<br>exacerbações|estratégias para<br>adesão ao<br>tratamento,<br>incluindo<br>treinamento no<br>uso correto dos<br>inaladores.<br>Monitoramento de<br>sintomas e<br>exacerbações,<br>incentivando o<br>paciente a<br>reconhecer sinais<br>precoces de piora.<br>Importância da<br>reabilitação<br>pulmonar e<br>atividade física.|correto dos<br>inaladores é<br>essencial para<br>eficácia do<br>tratamento.<br>Pacientes devem ser<br>orientados a<br>reconhecer sinais de<br>exacerbação e<br>buscar atendimento<br>precocemente.<br>Acompanhamento<br>contínuo para<br>ajustes terapêuticos<br>e prevenção de<br>complicações.|tratamento,<br>especialmente à<br>terapia inalatória,<br>é fundamental<br>para o controle da<br>doença.<br>A combinação de<br>CI com<br>LAMA/LABA<br>em um único<br>inalador melhora<br>a adesão e reduz<br>erros na técnica<br>inalatória.|uso correto dos<br>inaladores para<br>melhorar a adesão<br>ao tratamento.<br>Monitoramento<br>da sintomatologia<br>e do plano de<br>ação para<br>exacerbações.<br>Mudança de<br>hábitos como<br>cessação do<br>tabagismo e<br>prática regular de<br>atividade física.|educativos<br>com foco em<br>nutrição e<br>atividade<br>física são<br>recomendados<br>.|correto dos<br>inaladores melhora a<br>adesão ao tratamento.<br>Pacientes devem ser<br>orientados a<br>reconhecer sinais de<br>exacerbação e buscar<br>atendimento<br>precocemente.<br>Acompanhamento<br>contínuo permite<br>ajustes terapêuticos e<br>prevenção de<br>complicações.|
|Casos especiais|Pacientes com<br>comorbidades:<br>doenças<br>cardiovasculares,<br>osteoporose,||Pacientes com<br>hipoxemia crônica<br>podem necessitar<br>de oxigenoterapia<br>domiciliar.|Pessoas com DPOC<br>e asma sobreposta<br>podem se beneficiar<br>do uso de|Em pacientes com<br>fenótipo<br>bronquítico<br>crônico e alto<br>risco de|Pessoas com<br>DPOC e asma<br>sobreposta devem<br>receber<br>corticoides||Pacientes com DPOC<br>e asma sobreposta<br>devem receber<br>corticoides<br>inalatórios e LABA.|  
55  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||ansiedade e<br>depressão devem<br>ser monitoradas<br>e tratadas<br>simultaneamente<br>.<br>Pacientes em<br>cuidados<br>paliativos: foco<br>na qualidade de<br>vida, controle<br>sintomático e<br>possível uso de<br>opioides para<br>dispneia<br>refratária.<br>Pacientes com<br>deficiência de<br>alfa-1<br>antitripsina:<br>devem ser<br>rastreados e, se<br>indicado, receber||Em indivíduos<br>com fenótipo<br>exacerbador,<br>recomenda-se<br>abordagem<br>personalizada com<br>corticoides<br>inalatórios e/ou<br>antibióticos<br>profiláticos.<br>Pacientes com<br>DPOC e<br>insuficiência<br>cardíaca exigem<br>ajuste da terapia<br>para evitar<br>interações<br>medicamentosas e<br>exacerbações.|corticoides<br>inalatórios.<br>Pacientes com<br>hipoxemia crônica<br>podem necessitar de<br>oxigenoterapia<br>domiciliar.<br>DPOC e COVID-<br>19: pacientes com<br>DPOC têm maior<br>risco de<br>complicações e<br>devem ser<br>vacinados.|exacerbações,<br>recomenda-se<br>considerar<br>roflumilaste ou<br>N-acetilcisteína.<br>A interrupção do<br>CI pode ser<br>considerada em<br>pacientes de<br>baixo risco de<br>exacerbação, mas<br>deve ser feita com<br>cautela.|inalados e LABA<br>como primeira<br>linha.<br>Pacientes com<br>comorbidades<br>como<br>insuficiência<br>cardíaca e<br>osteoporose<br>devem ter<br>abordagem<br>integrada.||Indivíduos com<br>deficiência de alfa-1<br>antitripsina devem<br>ser rastreados.<br>Pacientes com<br>hipoxemia crônica<br>podem necessitar de<br>oxigenoterapia<br>domiciliar.|  
56  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||reposição da<br>enzima.<br>Pacientes com<br>enfisema severo<br>e<br>hiperinsuflação:<br>podem se<br>beneficiar de<br>técnicas de<br>redução de<br>volume<br>pulmonar.<br>Pacientes com<br>hipertensão<br>pulmonar:<br>requerem<br>avaliação com<br>ecocardiograma<br>e possível uso de<br>oxigenoterapia<br>crônica.||||||||
|Monitoramento|Para aqueles<br>com DPOC leve<br>a moderada e|Monitoramento<br>clínico e funcional<br>contínuo é|Avaliação<br>periódica dos<br>sintomas e da|Avaliação periódica<br>da função pulmonar<br>e dos sintomas.|A piora da função<br>pulmonar,<br>aumento da|O<br>acompanhamento<br>deve ocorrer em 1|Monitorament<br>o do estado<br>nutricional|Acompanhamento<br>deve incluir<br>espirometria anual,|  
57  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||baixo risco de<br>complicações,<br>recomenda-se<br>uma avaliação<br>anual, incluindo<br>espirometria,<br>questionários de<br>sintomas e<br>revisão da<br>adesão ao<br>tratamento. Já<br>pacientes com<br>DPOC grave ou<br>alto risco de<br>exacerbações<br>deve ser<br>monitorados a<br>cada três a seis<br>meses, com<br>avaliações mais<br>detalhadas,<br>incluindo<br>exames<br>laboratoriais e|essencial para<br>avaliar a<br>progressão da<br>doença e prevenir<br>novas<br>exacerbações.<br>Há limitações nas<br>evidências para<br>determinar a<br>melhor estratégia<br>de<br>acompanhamento<br>ambulatorial.|função pulmonar<br>para ajustes<br>terapêuticos.<br>Uso de<br>espirometria anual<br>para acompanhar<br>a progressão da<br>doença.<br>Monitoramento de<br>eventos adversos<br>dos<br>medicamentos,<br>especialmente<br>corticoterapia<br>prolongada.|Monitoramento da<br>adesão ao<br>tratamento e dos<br>eventos adversos<br>dos medicamentos.<br>Uso de<br>biomarcadores,<br>como eosinófilos no<br>sangue, pode<br>auxiliar na escolha e<br>ajuste da terapia.|frequência de<br>exacerbações e<br>declínio do estado<br>geral devem ser<br>monitorados<br>regularmente.<br>Pacientes<br>hospitalizados por<br>exacerbações<br>graves<br>apresentam risco<br>aumentado de<br>reinternação e<br>devem ter<br>acompanhamento<br>rigoroso.|a 4 semanas após<br>exacerbações e 12<br>a 16 semanas para<br>avaliação<br>funcional<br>completa.<br>Indicadores de<br>controle incluem:<br>VEF1 pela<br>espirometria.<br>CAT ou mMRC<br>para avaliar<br>sintomas.<br>Avaliação do uso<br>correto dos<br>dispositivos<br>inalatórios|deve ser feito<br>regularmente.|avaliação de<br>sintomas (CAT ou<br>mMRC) e revisão da<br>adesão ao tratamento.<br>Pacientes com alto<br>risco de exacerbações<br>deve ser monitorados<br>a cada três meses.|  
58  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||acompanhament<br>o da função<br>respiratória. Nos<br>casos de<br>pacientes que<br>apresentam<br>exacerbações<br>frequentes, o<br>acompanhament<br>o deve ocorrer a<br>cada três meses,<br>permitindo<br>ajustes mais<br>rápidos no<br>tratamento para<br>prevenir novas<br>crises.||||||||
|Recomendações<br>negativas|Corticoides<br>sistêmicos de<br>longa duração<br>não são<br>recomendados<br>devido aos|O uso de<br>corticoides<br>sistêmicos deve<br>ser limitado<br>devido ao risco de<br>eventos adversos.|Monoterapia com<br>corticoide<br>inalatório não é<br>recomendada<br>devido ao risco<br>aumentado de<br>pneumonia.|Não utilizar<br>corticoides<br>inalatórios como<br>monoterapia devido<br>ao risco de<br>pneumonia.|O uso de CI<br>isoladamente não<br>é recomendado<br>para pacientes<br>com DPOC<br>estável.||Dieta<br>hipocalórica<br>não é<br>recomendada<br>para pacientes<br>com IMC|Corticoides<br>inalatórios não<br>devem ser usados<br>isoladamente devido<br>ao risco aumentado<br>de pneumonia.<br>Teofilina tem|  
59  
|**Item**|**Espanha, 2021**<sup>**2-**</sup><br>**5**|**EUA, 2021**<sup>**6**</sup>|**França, 2021**<sup>**7**</sup>|**Taiwan, 2021**<sup>**8**</sup>|**Canadá, 2023**<sup>**9**</sup>|**El Salvador,**<br>**2023**<sup>**10**</sup>|**Andalusia,**<br>**2024**<sup>**11**</sup>|**Recomendação**<br>**global**|
|---|---|---|---|---|---|---|---|---|
||eventos<br>adversos.<br>Antibióticos não<br>devem ser<br>utilizados<br>rotineiramente<br>na fase estável<br>da DPOC.<br>Oxigenoterapia<br>suplementar para<br>pacientes sem<br>hipoxemia grave<br>não demonstrou<br>benefícios<br>significativos.<br>O uso<br>indiscriminado<br>de CI deve ser<br>evitado em<br>pacientes sem<br>exacerbações<br>frequentes e<br>baixos níveis de<br>eosinófilos|O uso de oxigênio<br>em alto fluxo<br>pode ser<br>prejudicial e<br>aumentar a<br>mortalidade.|Antibióticos<br>contínuos não<br>devem ser usados<br>rotineiramente,<br>exceto em casos<br>específicos.<br>Teofilina tem uso<br>restrito devido ao<br>risco de<br>toxicidade.<br>Uso<br>indiscriminado de<br>oxigenoterapia<br>pode ser<br>prejudicial, sendo<br>necessário<br>monitoramento<br>rigoroso.|Teofilina deve ser<br>evitada como<br>tratamento de<br>primeira linha<br>devido aos eventos<br>adversos.<br>Uso indiscriminado<br>de antibióticos não<br>é recomendado,<br>salvo em casos de<br>exacerbações<br>bacterianas.<br>Ventilação não<br>invasiva de rotina<br>não é indicada para<br>todos os pacientes,<br>sendo recomendada<br>apenas em casos<br>específicos de<br>insuficiência<br>respiratória<br>hipercápnica grave.|Corticoides<br>sistêmicos<br>(prednisona) não<br>devem ser usados<br>para tratamento<br>crônico.<br>Teofilina não é<br>recomendada<br>devido à baixa<br>eficácia e alto<br>risco de eventos<br>adversos.||normal ou<br>baixo.|indicação restrita<br>devido aos eventos<br>adversos.<br>Antibióticos não<br>devem ser utilizados<br>rotineiramente,<br>exceto em<br>exacerbações<br>bacterianas<br>documentadas.<br>Oxigenoterapia em<br>pacientes sem<br>hipoxemia grave não<br>demonstrou<br>benefícios.|  
60  
Também foi elaborada uma segunda pergunta de pesquisa com base no acrônimo PCC (População, Conceito, Contexto), descrito no **Quadro E** :  
**Quadro E -.** ergunta de pesquisa PCC para busca de diretrizes nacionais e internacionais sobre a síndrome de sobreposição asma-DPOC  
|**População**|Pacientes com síndrome de sobreposição asma-DPOC|
|---|---|
|**Conceito**|Publicações que abordem o cuidado ou aspectos relacionados à síndrome de sobreposição asma-|
||DPOC|
|**Contexto**|Diretrizes nacionais e internacionais|  
Fonte: autoria própria  
As buscas foram conduzidas nas bases Medline (via PubMed), EMBASE e Lilacs (via BVS) em 14/01/2025. Não foram  
utilizadas restrições de idioma e data. As estratégias de busca para cada base estão descritas no **Quadro F.**  
**Quadro F** -Estratégias de busca, de acordo com a base de dados, para identificação de diretrizes nacionais e internacionais sobre a síndrome de sobreposição asma-DPOC  
|**Base de dados**|**Estratégia**|**Resultados**|
|---|---|---|
|Medline<br>(via<br>PubMed)|(("Pulmonary Disease, Chronic Obstructive"[Mesh]) OR ("Chronic Obstructive<br>Pulmonary Diseases"[Text Word] OR COPD[Text Word] OR "Chronic<br>Obstructive Lung Disease"[Text Word] OR "Chronic Obstructive Pulmonary<br>Disease"[Text Word] OR COAD[Text Word] OR "Chronic Obstructive Airway<br>Disease"[Text Word] OR "Airflow Obstruction, Chronic"[Text Word] OR<br>"Airflow<br>Obstructions,<br>Chronic"[Text<br>Word]<br>OR<br>"Chronic<br>Airflow<br>Obstructions"[Text Word] OR "Chronic Airflow Obstruction"[Text Word]))<br>AND<br>(("Asthma-Chronic<br>Obstructive<br>Pulmonary<br>Disease<br>Overlap<br>Syndrome"[Mesh]) OR ("Asthma Chronic Obstructive Pulmonary Disease<br>Overlap Syndrome"[Text Word] OR "Asthma-COPD Overlap Syndrome"[Text<br>Word] OR "Asthma COPD Overlap Syndrome"[Text Word])) Filters: Clinical<br>Trial, Phase III, Clinical Trial, Phase IV, Controlled Clinical Trial, Guideline,<br>Meta-Analysis, Practice Guideline, Randomized Controlled Trial, Systematic<br>Review|11|
|EMBASE|#1 'asthma-chronic obstructive pulmonary disease overlap syndrome'/exp OR<br>'asthma-chronic obstructive pulmonary disease overlap syndrome' OR 'asthma-<br>copd overlap syndrome'<br>#2 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)<br>#3 AND 'practice guideline'/de|23|
|Lilacs (via BVS)|("Síndrome de Sobreposição da Doença Pulmonar Obstrutiva Crônica e Asma")<br>OR ("Síndrome da Sobreposição da Doença Pulmonar Obstrutiva Crônica e da<br>Asma" OR "Síndrome de Sobreposição Asma-COPD") OR ("Asthma-Chronic<br>Obstructive Pulmonary Disease Overlap Syndrome") OR ("Síndrome de<br>Superposición de la Enfermedad Pulmonar Obstructiva Crónica-Asmática")<br>AND db:("LILACS" OR "colecionaSUS") AND instance:"lilacsplus"|6|  
Fonte: autoria própria  
61  
A elegibilidade dos estudos identificados por meio de busca sistemática foi realizada em duas etapas. A primeira etapa consistiu na avaliação de título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI<sup>®</sup> ¹. Na segunda etapa, realizouse a leitura de texto completo, mantendo-se documentos que considerem o diagnóstico, tratamento ou monitoramento, cuidados ou qualquer outro aspecto de interesse sobre a DPOC. As divergências foram resolvidas por terceiro revisor.

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **Resultados da busca** -->
Foram identificadas 40 publicações. Não foram identificadas duplicatas e a triagem pela leitura de títulos e resumos identificou 5 publicações para a leitura do texto completo ( **Figura B** ). Dois estudos foram excluídos por leitura de texto completo após constatar que se tratava de resumos de congresso ( **Quadro G** ) **.** No total, foram incluídas três publicações, descritas no **Quadro H** , de acordo com as recomendações identificadas para o cuidado da síndrome de sobreposição asma-DPOC.  
62  
**Figura B.** Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
Identificação de estudos a partir de bases de dados e registros<br>Referências identificadas em:<br>Referências removidas antes do<br>Bases de dados (n = 40)<br>processo de seleção:<br>PubMed (n = 11)<br>Duplicatas (n = 0)<br>Embase (n = 23)<br>LILACS (n = 6)<br>Referências avaliadas por título e<br>Referências excluídas<br>resumo<br>(n = 35)<br>(n = 40)<br>Referências incluídas para avaliação  Referências cujo texto completo não<br>por texto completo   foi identificado<br>(n = 5)  (n = 0)<br>Referências avaliadas por texto<br>Referências excluídas: (n = 2)<br>completo (n = 5)<br>Estudos incluídos na revisão<br>(n = 3)<br>Identificação<br>Seleção<br>Inclusão<br><!-- End of picture text -->  
Fonte: autoria própria  
**Quadro G -** Lista de referências excluídas após leitura do texto completo, de acordo com a razão de exclusão.  
**Referências excluídas por consistirem em resumos de congresso** Day, G. L., Jackson, N. J., & Buhr, R. G. Health Care Disparity in Asthma-COPD Overlap Syndrome: Social Determinants for Readmission. 2020. In B102. CARING FOR LUNG DISEASES IN UNDERSERVED AND VULNERABLE POPULATIONS (pp. A4287-A4287). American Thoracic Society. Tokyay, D. A., Yarkin, T., Ozmen, I., Yıldırım, E., & Ogur. Asthma-COPD overlap syndrome: prevalence and clinical characteristics. 2017.  
Fonte: autoria própria  
63  
**Quadro H -** Matriz de recomendações das diretrizes clínicas sobre síndrome de sobreposição asma-DPOC  
||**Wu, 2019**<sup>12</sup>|**Queiroz, 2021**<sup>13</sup>|**Zhou, 2021**<sup>14</sup>|
|---|---|---|---|
|**Diagnóstico**|Avaliação da função pulmonar,<br>exacerbações, fatores de risco e<br>sugere<br>que<br>marcadores<br>inflamatórios e resposta ao<br>tratamento<br>com<br>corticoides<br>podem ser úteis no diagnóstico<br>diferencial.|Diagnóstico<br>baseado<br>em<br>critérios de função pulmonar,<br>histórico de asma, resposta ao<br>broncodilatador, eosinofilia e<br>IgE elevada (> 100 kU/L).|Considera<br>biomarcadores<br>inflamatórios para suporte<br>ao diagnóstico.|
|**Tratamento**|Regime<br>de<br>corticoides<br>inalatórios e broncodilatadores<br>de longa ação.|Sugere<br>personalização<br>do<br>tratamento de acordo com o<br>fenótipo clínico do paciente.<br>Enfatiza<br>uso<br>de<br>broncodilatadores e corticoides<br>inalatórios para pacientes com<br>eosinofilia.|Recomenda<br>abordagem<br>personalizada baseada em<br>uso<br>direcionado<br>de<br>corticoides e moduladores<br>da inflamação.|
|**Monitoramento**|Sugere que o monitoramento<br>deve incluir controle rigoroso de<br>exacerbações<br>e<br>acompanhamento<br>regular<br>da<br>função pulmonar.|Monitoramento<br>baseado<br>em<br>espirometria, testes de função<br>pulmonar e avaliação contínua<br>da<br>resposta<br>ao<br>tratamento,<br>incluindo<br>exacerbações<br>e<br>necessidade<br>de<br>corticoides<br>sistêmicos.|Acompanha evolução do<br>paciente<br>por<br>meio<br>de<br>marcadores<br>inflamatórios,<br>resposta<br>terapêutica<br>e<br>incidência de exacerbações.|

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **5.        Equipe de elaboração e partes interessadas** -->
Colaboração externa  
O Protocolo foi atualizado pelo Núcleo de Avaliação de Tecnologias em Saúde da Universidade Federal de São Paulo,  
Campus Diadema - NUD.  
Declaração e Manejo de Conflitos de Interesse  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro I** ).  
**Quadro I -** Questionário de conflitos de interesse das diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramen<br>a) Reembolso por comparecimento a eventos na área de interesse da diretriz|te algum dos benefícios abaixo?<br>(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|  
64  
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|---|---|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|  
65

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **6. REFERÊNCIAS** -->
1. Mourad Ouzzani, Hossam Hammady, Zbys Fedorowicz, and Ahmed Elmagarmid. Rayyan — a web and mobile app for systematic reviews. Systematic Reviews (2016) 5:210, DOI: 10.1186/s13643-016-0384-4.  
2. Soler-Cataluña JJ, Piñera P, Trigueros JA, Calle M, Casanova C, Cosío BG, et al. Actualización 2021 de la guía española de la EPOC (GesEPOC). Diagnóstico y tratamiento del síndrome de agudización de la EPOC. Arch Bronconeumol. 2022;58(2):159-70.  
3. Soler-Cataluña JJ, Piñera P, Trigueros JA, Calle M, Casanova C, Cosío BG, et al. Actualización 2021 de la guía española de la EPOC (GesEPOC). Diagnóstico y tratamiento del síndrome de agudización de la EPOC. Arch Bronconeumol. 2022;58(2):159-70.  
4. Miravitlles M, Calle M, Molina J, Almagro P, Gómez JT, Trigueros JA, et al. [Translated article] Spanish COPD guidelines (GesEPOC) 2021: Updated pharmacological treatment of stable COPD. Arch Bronconeumol. 2022;58(1):T69T81.  
5. Miravitlles M, Calle M, Molina J, Almagro P, Gómez JT, Trigueros JA, et al. Actualización 2021 de la Guía Española de la EPOC (GesEPOC). Tratamiento farmacológico de la EPOC estable. Arch Bronconeumol. 2022;58(1):69-81.  
6. Stevermer JJ, Fisher L, Lin KW, Liu R, Goodenberger D, Schellhase K, et al. Pharmacologic management of COPD exacerbations: a clinical practice guideline from the AAFP. Am Fam Physician. 2021;104(1).  
7. Zysman M, Baptista BR, Soumagne T, da Silva VM, Martin C, de Menonville CT, et al. Position paper of the French Society of Respiratory Diseases regarding pharmacological treatment optimization for stable COPD in 2021. Respir Med Res. 2022;81:100889.  
8. Cheng SL, Lin CH, Chu KA, Chiu KL, Lin SH, Lin HC, et al. Update on guidelines for the treatment of COPD in Taiwan using evidence and GRADE system-based recommendations. J Formos Med Assoc. 2021;120(10):1821-44.  
9. Bourbeau J, Bhutani M, Hernandez P, Aaron SD, Beauchesne MF, Kermelly SB, et al. 2023 Canadian Thoracic Society guideline on pharmacotherapy in patients with stable COPD. Chest. 2023;164(5):1159-83.  
10. Ministerio de Salud. Lineamientos técnicos para el abordaje integral de enfermedades respiratorias crónicas, asma en personas mayores o iguales a 12 años y Enfermedad Pulmonar Obstructiva Crónica (EPOC). Gobierno de El Salvador; [ano não informado].  
11. Enríquez AJ, Rabat-Restrepo JM, Vilchez-López FJ, Tenorio-Jiménez C, García-Almeida JM, Rocamora JAI, et al. Practical Guidelines by the Andalusian Group for Nutrition Reflection and Investigation (GARIN) on Nutritional Management of Patients with Chronic Obstructive Pulmonary Disease: A Review. Nutrients. 2024;16(18):3105.Wu JJ, Xu HR, Zhang YX, Li YX, Yu HY, et al. The characteristics of the frequent exacerbators with chronic bronchitis phenotype and the asthma-chronic obstructive pulmonary disease overlap syndrome phenotype in chronic obstructive pulmonary disease patients: A meta-analysis and system review. Medicine (Baltimore). 2019;98(46):e17996.  
12. Queiroz APA, Fonseca FR, Rê A, Maurici R. Características clínicas, laboratoriais e funcionais da sobreposição asmaDPOC em pacientes previamente diagnosticados com DPOC. J Bras Pneumol. 2021;47(1):e20200033.  
13. Zhou XL, Zhao LY. Comparison of clinical features and outcomes for asthma-COPD overlap syndrome vs. COPD patients: A systematic review and meta-analysis. Eur Rev Med Pharmacol Sci. 2021;25(4):1495-1510.  
66  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: PCDT da Doença Pulmonar Obstrutiva Crônica | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do Relatório da**<br>||**Tecnologias avaliadas p**|**ela Conitec**<br>|
|---|---|---|---|
|**diretriz clínica (Conitec)**<br>**ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ou não**<br>**alteração ou exclusão no**<br>**SUS**|
||Ajuste das menções à<br>numeração dos itens no<br>texto|-|-|
|Relatório<br>de<br>Recomendação<br>nº<br>1046/2025|Atualização<br>dos<br>critérios<br>diagnósticos<br>GOLD|Furoato<br>de<br>fluticasona/brometo<br>de<br>umeclidínio/trifenatato de vilanterol para<br>o<br>tratamento<br>da<br>doença<br>pulmonar<br>obstrutiva crônica grave a muito grave<br>(GOLD 3 e 4) com perfil exacerbador,<br>conforme Protocolo Clínico do Ministério<br>da Saúde. [Portaria SECTICS/MS nº<br>46/2024; Relatório de Recomendação nº<br>965/2024]<br>Dipropionato<br>de<br>beclometasona<br>+<br>fumarato de formoterol dihidratado +<br>brometo de glicopirrônio para tratamento<br>da doença pulmonar obstrutiva crônica<br>grave<br>e<br>muito<br>grave<br>com<br>perfil<br>exacerbador, conforme Protocolo Clínico<br>do<br>Ministério<br>da<br>Saúde.<br>[Portaria<br>SECTICS/MS nº 44/2024; Relatório de<br>Recomendação nº 936/2024]||
|Portaria<br>SAES/SECTICS/MS n º<br>19/2021<br>[Relatório<br>de<br>Recomendação<br>nº<br>651/2021]|Atualização do PCDT|Brometo de umeclidínio + trifenatato de<br>vilanterol para o tratamento de pacientes<br>com doença pulmonar obstrutiva e<br>brometo de tiotrópio monoidratado +<br>cloridrato de olodaterol para o tratamento<br>de pacientes com doença pulmonar<br>obstrutiva crônica graves e muito graves<br>(estágio 3 e 4), com alto risco (C e D)<br>[Portaria<br>SCTIE/MS<br>nº<br>66/2020;<br>Relatório de Recomendação nº 585/2020]|Xinafoato<br>de<br>salmeterol<br>aerossol bucal 50 mcg para<br>tratamento da Asma e da<br>Doença<br>Pulmonar<br>Obstrutiva<br>Crônica<br>(DPOC), no âmbito do<br>Sistema Único de Saúde –<br>SUS [Portaria SCTIE/MS nº<br>16/2021;<br>Relatório<br>de<br>Recomendação<br>nº<br>606/2021]|  
67  
|**Número do Relatório da**||**Tecnologias avaliadas p**|**ela Conitec**|
|---|---|---|---|
|**diretriz clínica (Conitec)**|||**Não incorporação ou não**|
|<br>**ou Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|<br>**alteração ou exclusão no**<br>**SUS**|
||Alteração<br>pós<br>publicação (correção do<br>Termo<br>de<br>Esclarecimento<br>e<br>Responsabilidade)|||
||Alteração<br>pós<br>publicação (correção do<br>tratamento<br>medicamentoso-<br>brometro de tiotrópio)|||
||||Propionato de fluticasona<br>para o tratamento da asma<br>no Sistema Único de Saúde<br>(SUS) [Portaria SCTIE/MS|
|Portaria<br>SAS/MS<br>nº<br>609/2013|Primeira<br>versão<br>do<br>documento|Budesonida, Beclometasona, Fenoterol,<br>Salbutamol, Formoterol e Salmeterol; a<br>Vacina contra Influenza; a Oxigenoterapia<br>domiciliar e os Exames Diagnósticos para<br>Deficiência de Alfa-1 Antitripsina para o<br>tratamento<br>da<br>Doença<br>Pulmonar<br>Obstrutiva Crônica no Sistema Único de<br>Saúde (SUS) [Portaria SCTIE/MS nº<br>29/2012; Relatório de Recomendação<br>nº30/2012]|nº 35/2013; Relatório de<br>Recomendação nº 65/2013]<br>Brometo de tiotrópio para o<br>tratamento<br>da<br>doença<br>pulmonar obstrutiva crônica<br>no Sistema Único de Saúde<br>(SUS) [Portaria SCTIE/MS<br>nº 36/2013; Relatório de<br>Recomendação nº 68/2013]<br>Indacaterol<br>para<br>o<br>tratamento<br>da<br>Doença<br>Pulmonar<br>Obstrutiva<br>Crônica no Sistema Único<br>de Saúde (SUS). [Portaria<br>SCTIE/MS<br>nº<br>7/2013;<br>Relatório de Recomendação<br>nº 39/2013]|  
68

---

