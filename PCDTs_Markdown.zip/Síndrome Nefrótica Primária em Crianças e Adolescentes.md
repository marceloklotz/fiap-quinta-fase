<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA CONJUNTA Nº 01, DE 10 DE JANEIRO DE 2018  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome Nefrótica Primária em Crianças e Adolescentes.  
A SECRETÁRIA DE ATENÇÃO À SAÚDE - Substituta e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a síndrome nefrótica primária em crianças e adolescentes no Brasil e diretrizes nacionais para o diagnóstico, tratamento e acompanhamento dos indivíduos com esta síndrome;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 286/2017 e o Relatório de Recomendação nº 304 – Agosto de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Síndrome Nefrótica Primária em Crianças e Adolescentes.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da síndrome nefrótica primária em crianças e adolescentes, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, dos Municípios e do Distrito Federal na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da síndrome nefrótica primária em crianças e adolescentes.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa síndrome em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 459/SAS/MS, de 21 de maio de 2012, publicada no Diário Oficial da União - DOU nº 98, de 22 de maio de 2012, seção 1, páginas 102-107.  
CLEUSA RODRIGUES DA SILVEIRA BERNARDO

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: ANEXO -->
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS  
SÍNDROME NEFRÓTICA PRIMÁRIA EM CRIANÇAS E ADOLESCENTES

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **1 INTRODUÇÃO** -->
A síndrome nefrótica (SN) é caracterizada por proteinúria maciça, hipoalbuminemia, edema e hiperlipidemia e ocorre pelo aumento da permeabilidade da membrana basal glomerular. Pode ser dividida em secundária, quando causada por alguma outra doença, ou primária (idiopática).  
Em crianças, a síndrome nefrótica idiopática (SNI) representa 90% dos casos diagnosticados antes dos 10 anos de idade e 50% dos que se apresentam após essa idade. Apesar de menos frequente, a avaliação inicial deve afastar a presença de causas secundárias, como doenças sistêmicas, infecções, neoplasias e uso de medicamentos (1).  
Histologicamente, a SNI revela apagamento difuso dos podócitos à microscopia eletrônica e alterações mínimas à microscopia ótica, sendo então diferenciada em SN por lesões mínimas (SNLM) ou glomeruloesclerose segmentar e focal (GESF) (2). Até 1940, a taxa de mortalidade de crianças com SN era cerca de 40%, principalmente devido à ocorrência de infecções, mas foi significativamente reduzida com a introdução do tratamento com glicocorticoides e antibióticos. O prognóstico em longo prazo tem melhor correlação com a resposta à terapia com corticosteroide do que com os achados histopatológicos. Os pacientes que respondem à terapia com glicocorticoide têm excelente prognóstico e raramente evoluem para insuficiência renal (3).  
Os pacientes com SN podem ser definidos por sua resposta à terapia inicial em sensíveis (SNSC) ou resistentes ao corticosteroide (SNRC). Entre os sensíveis, a maior parte apresenta SNLM, embora a GESF possa ocorrer. Entre os resistentes, a maioria apresenta GESF e a minoria, SNLM (4,5). Os que não respondem ao curso inicial de glicocorticoide devem ser submetidos à biópsia renal para determinar o diagnóstico histopatológico e orientar novas indicações terapêuticas. Nas últimas três décadas, há evidências de um aumento na proporção de crianças com GESF, sugerindo um aumento de pacientes com SNRC (6).  
Dados epidemiológicos mais antigos e amplamente aceitos mostram que a incidência anual de SN é estimada em 2-7 novos casos por 100.000 crianças e a prevalência de 16 casos por 100.000 crianças. O pico de apresentação da SN é aos 2 anos de idade, e 70%-80% dos casos ocorrem em crianças com menos de 6 anos (7,8). Estudos prospectivos em crianças com a primeira manifestação de SN em países como Holanda, Austrália e Nova Zelândia mostraram uma incidência de 1,12-1,9/100.000 crianças até 16 anos (9-11). A incidência é mais alta em crianças asiáticas, afroamericanas e árabes. Em crianças do norte da Inglaterra, a incidência é de 7,4/100.000 crianças/ano para crianças sul-asiáticas, comparado com 1,6 para crianças não asiáticas (12).  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos de crianças com SN. A metodologia de busca e avaliação das evidências estão detalhadas no Apêndice 1.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- N04.0 Síndrome nefrótica - anormalidade glomerular minor  
- N04.1 Síndrome nefrótica - lesões glomerulares focais e segmentares  
- N04.2 Síndrome nefrótica - glomerulonefrite membranosa difusa  
- N04.3 Síndrome nefrótica - glomerulonefrite proliferativa mesangial difusa  
- N04.4 Síndrome nefrótica - glomerulonefrite proliferativa endocapilar difusa  
- N04.5 Síndrome nefrótica - glomerulonefrite mesangiocapilar difusa  
- N04.6 Síndrome nefrótica - doença de depósito denso  
- N04.7 Síndrome nefrótica - glomerulonefrite difusa em crescente  
- N04.8 Síndrome nefrótica - outras

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **3 DIAGNÓSTICO** -->
O diagnóstico de SNI em crianças e adolescentes é baseado nos seguintes critérios clínicos e laboratoriais, e o paciente deverá apresentar todos os critérios eles:  
- Edema;  
- proteinúria nefrótica: proteinúria acima de 50 mg/kg/dia ou acima de 40 mg/m<sup>2</sup> /h ou acima de 3,5  
- g/24 h/1,73 m<sup>2</sup> ou índice proteinúria/creatininúria (IPC) acima de 2,0;  
- hipoalbuminemia: albumina sérica abaixo de 2,5 g/dL; e  
- hiperlipidemia: colesterol total igual ou acima de 240 mg/dL ou triglicerídeos igual ou acima 200  
mg/dL.  
Além desses critérios, causas secundárias devem ser afastadas e, para isso, os exames sorológicos para doenças infecciosas (HBsAg, anti-HCV, anti-HIV e toxoplasmose) e o fator antinuclear (FAN) devem ser negativos. Também deve ser excluído o uso de medicamentos (por exemplo, anti-inflamatórios não esteroides, ouro, penicilamina e captopril).  
A biópsia renal está indicada nos casos de pacientes com (13):  
- Hematúria macroscópica ou hipertensão sustentada, ou complemento sérico diminuído;  
- SNRC, isto é, com ausência de resposta a prednisona oral por 8 semanas ou a prednisona oral por 4 semanas mais pulsoterapia com metilprednisona intravenosa (3 a 6 pulsos em dias alternados);  
- menos de 1 ano de idade, nos quais predomina a incidência de SN congênita com lesão histopatológica de tipo finlandês e esclerose mesangial difusa; pacientes com esses achados não respondem a nenhuma terapia;  
- mais de 8 anos, quando a possibilidade de SNLM é menor, podendo-se optar pelo tratamento inicial para avaliar a sensibilidade ao corticosteroide ou biopsiá-los já no início. Adolescentes devem ser biopsiados precocemente, já que a possibilidade de outro diagnóstico que não SNLM aumenta com a idade.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **4 CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes com até 18 anos de idade e com diagnóstico clínico e laboratorial de SNI. O estudo histopatológico somente será um critério de inclusão dos pacientes cuja biópsia renal está indicada conforme o Item 3 Diagnóstico.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **5 CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que apresentarem SN associada às causas secundárias abaixo relacionadas:  
- Doenças infecciosas: hepatite C, hepatite B e HIV;  
- doenças sistêmicas: púrpura de Henoch-Schönlein, lúpus eritematoso sistêmico, diabete melito de longa evolução (mais de 5 anos, em que a proteinúria pode ser causada pela doença de base) e sarcoidose; ou  
- tumores: leucemia e linfoma.  
Também serão excluídos os pacientes que apresentarem intolerância, hipersensibilidade ou contraindicação aos medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **6 CASOS ESPECIAIS** -->
O tacrolimo somente está indicado neste Protocolo para os pacientes que tenham desenvolvido hipertricose ou hiperplasia gengival associada ao uso de ciclosporina. Esses efeitos deverão ser comprovados mediante laudo médico, respectivamente, de dermatologista ou de dentista ou cirurgião bucomaxilofacial.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **7 TRATAMENTO** -->
Os pacientes são classificados de acordo com a resposta ao tratamento nas seguintes categorias:  
- Em remissão completa: exame qualitativo de urina (EQU) com proteína indetectável por mais de 3 dias ou IPC igual ou acima de 0,3;  
- em remissão parcial: presença de qualquer dos itens a seguir: proteinúria entre 0,3 e 3,5 g/1,73 m<sup>2</sup> /24h ou IPC acima de 0,3 e abaixo de 2,0 ou redução da proteinúria abaixo de 50% do valor basal;  
- com resistência ao glicocorticoide: falência em atingir remissão completa com uso de prednisona por 8 semanas na dose recomendada ou por 4 semanas associada a pulsoterapia com metilprednisolona em 3 doses de 1.000 mg/1,73 m<sup>2</sup> ou 20-30 mg/kg com máximo de 1 g, em dias alternados, em 3 a 6 doses;  
- com recidiva: proteinúria acima de 50 mg/kg/dia ou acima de 3,5 g/1,73 m<sup>2</sup> /24h ou IPC acima de 2,0 após um período de remissão completa;  
- com recidivas frequentes: 2 ou mais recidivas em até 6 meses ou 4 recidivas no período de 1 ano após o término do tratamento;  
- com dependência ao corticosteroide: 2 ou mais recidivas durante o uso de glicocorticoide ou em até 14 dias após o término do tratamento;  
- com resistência ao corticosteroide (não responsivo inicial): resistência ao glicocorticoide no primeiro episódio;  
- com resistência ao corticosteroide (não responsivo tardio): resistência ao glicocorticoide em pacientes que previamente responderam ao glicocorticoide.  
Esquematicamente, o tratamento será dividido em:  
- Tratamento inicial (primeiro episódio);

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: - Síndrome nefrótica sensível ao corticosteroide - SNSC: -->
- a) primeiras recidivas;  
b) recidivas frequentes ou dependência ao corticosteroide;  
- Síndrome nefrótica resistente ao corticosteroide - SNRC;  
- Controle dos sintomas e prevenção das complicações da SN.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **<u>Tratamento inicial</u>** -->
A terapia com glicocorticoide pode ser iniciada em crianças e adolescentes com alta probabilidade de SNLM, sem confirmação por biópsia renal, já que mais de 90% dos pacientes irão responder à terapia com corticosteroide dentro de 8 semanas (3,7).  
O início dessa terapia pode ser adiado por até 1 semana, pois a remissão espontânea ocorre em até 5% dos casos (7). A SNI é sensível ao corticosteroide na maioria das crianças (3). Aproximadamente 30% dos pacientes tratados não terão nenhuma recidiva e, portanto, estarão curados após o curso inicial da terapia (7). Aproximadamente 10%-20% terão uma recidiva vários meses após a suspensão do tratamento com glicocorticoide, mas terão menos de quatro recidivas responsivas ao corticosteroide antes que a remissão completa ocorra. No entanto, 30%-40% dos pacientes terão recidivas frequentes, isto é, duas ou mais recidivas em até 6 meses ou quatro recidivas em 1 ano após o término do tratamento (3).  
Os pacientes com recidivas frequentes ou dependentes de corticosteroide, muitas vezes, requerem cursos múltiplos ou prolongados e têm risco aumentado de toxicidade. O aumento na duração do curso inicial de glicocorticoide, que inclui períodos de uso diário e em dias alternados, parece reduzir o risco de recidiva e diminuir a dose cumulativa de corticosteroide (14-17), dado trazido por uma meta-análise que incluiu 12 ensaios clínicos (15). Nessa meta-análise, estudando 6 ensaios clínicos, o tratamento com prednisona por 3-7 meses reduziu o risco de recidivas 12 e 24 meses pós-terapia quando comparado com um esquema de 2 meses de tratamento (RR 0,70; IC 95% = 0,58-0,84). Não houve diferença na dose cumulativa de corticosteroide. Na análise conjunta de 4 ensaios com 382 crianças, o risco de recidiva foi menor com 6 _versus_ 3 meses de tratamento (RR 0,57; IC 95% 0,45-0,71). Não houve diferença na dose cumulativa de corticosteroide. A redução do risco de recidiva foi associada a aumento tanto na duração quanto na dose do glicocorticoide (15).  
Outra meta-análise de 7 ensaios clínicos controlados, comparando a duração do tratamento inicial com glicocorticoides, mostrou resultados bastante semelhantes, reforçando que seu uso por 3-7 meses reduziu significativamente o risco de recidiva em 12 e 24 meses em relação ao uso por 2 meses (RR 0,73; IC 95% 0,6-0,89), sem aumentar os efeitos adversos. Já a frequência das recidivas não foi influenciada pela duração do tratamento, o que foi demonstrado pela análise de 5 ensaios controlados. Não foi verificada diferença no uso de dose fracionada ou única diária (18).  
No entanto, essas meta-análises sumarizam pequenos estudos com baixo poder estatístico, não eliminando o risco de vieses.  
Resultados similares foram observados em um estudo randomizado controlado a partir do _Arbeitsgemeinshaft fur Pädiatrische Nephrologie_ (APN), que comparou o tratamento padrão inicial de prednisona (60 mg/m<sup>2</sup> /dia por 4 semanas seguido de 40 mg/m<sup>2</sup> /48h por mais 4 semanas) a um esquema inicial de 6 semanas de prednisona de 60 mg/m<sup>2</sup> /dia seguido de 6 semanas de prednisona 40 mg/m<sup>2</sup> /48h (14). A taxa de recidiva em 12 meses após o término do tratamento foi menor com o curso prolongado da terapia em relação ao tratamento padrão (36% _versus_ 61%).  
Além disso, a redução lenta do uso de glicocorticoide para evitar a supressão adrenal pode ser importante para manter a remissão em longo prazo. Um estudo em crianças sugere que a supressão da função adrenal moderada a grave pós-prednisona foi associada a risco aumentado de recidiva (19).  
Por outro lado, uma nova revisão da Cochrane, de 2015, mostrou que não há aumento no risco de desenvolver recidivas frequentes com tratamento inicial de corticoides por tempo mais curto (de 2-3 meses). Paralelamente, foi demonstrado que o risco de recidiva em crianças com recidivas frequentes era menor com uso de corticoide diário nos episódios de infecção de vias aéreas em comparação com uso em dias alternados ou não uso (15).  
Outra meta-análise incluindo 26 ensaios clínicos randomizados (ECR) que compararam tratamentos mais curtos de 2-3 meses com corticoides com mais prolongados de 3-7 meses não encontrou diferenças entre número de recidivas e recidivas frequentes, concluindo não haver benefício em estender o tratamento inicial além de 2-3 meses (20). Sendo assim, este Protocolo indica o tratamento inicial com glicocorticoide por, no máximo, 3 meses.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **<u>Síndrome nefrótica sensível ao corticosteroide - SNSC</u>** -->
Quase todos os pacientes respondem inicialmente à terapia com glicocorticoide. Após a resposta inicial, a conduta é focada na detecção e terapêutica precoce das recidivas para minimizar as complicações da SN. Cerca de 40%-50% dos pacientes sensíveis ao corticosteroide que desenvolvem recidivas frequentes ou se tornam dependentes do medicamento apresentam os maiores desafios terapêuticos.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **a) Primeiras recidivas** -->
O tratamento mais utilizado é prednisona oral na dose de 60 mg/m<sup>2</sup> /dia ou 2 mg/kg/dia (dose única diária, pela manhã, máximo de 60 mg/dia). O uso diário do medicamento é recomendado até a proteinúria desaparecer por 3 dias (IPC menor que 0,3). Em seguida, a dose é ajustada para 40 mg/m<sup>2</sup> /48h ou 1,5 mg/kg/48h, mantida por 30 dias e reduzida gradualmente ao longo de 6-8 semanas.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **b) Recidivas frequentes ou dependência ao corticosteroide (SNDC)** -->
Dois diferentes esquemas de glicocorticoide têm sido usados para tratar pacientes com recidivas frequentes ou dependentes de corticosteroide.  
O _International Study of Kidney Disease in Children_ (ISKDC) recomenda uma dose de prednisona de 60 mg/m<sup>2</sup> /dia (máximo de 60 mg/dia), iniciada quando o paciente apresentar recidiva e mantida até 3 dias após a urina tornar-se livre de proteínas. A dose é reduzida para 40 mg/m<sup>2</sup> /48h e administrada por 4 semanas (21).  
Outra conduta recomenda o tratamento de recidivas com prednisona (60 mg/m<sup>2</sup> /48h) até o desaparecimento da proteinúria por 3 dias. A dose do medicamento é reduzida até 15-20 mg/m<sup>2</sup> /48h ou de acordo com o limiar de glicocorticoide do paciente (ou seja, a dose em que a recidiva ocorreu). Este esquema é mantido por 12-18 meses com redução gradual no final do tratamento (22).  
O primeiro esquema permite uma melhor definição em termos de recidivas, mas está associado a um maior número de ocorrências em razão da menor duração da terapia, resultando em maior dose cumulativa de glicocorticoide. Desta forma, recomenda-se o segundo esquema terapêutico: prednisona (60 mg/m<sup>2</sup> /48h) até o desaparecimento da proteinúria por 3 dias.  
Entretanto, é importante ressaltar, especialmente quando se consideram outros agentes terapêuticos, que quase todos os pacientes com recidivas frequentes apresentam redução progressiva do número de recidivas ao longo do tempo e, geralmente, entram em remissão permanente (22).  
Infecções virais são um fator desencadeante documentado para recidiva em crianças com SN responsiva a corticosteroide (23). No tratamento dos pacientes recidivantes frequentes, uma alteração da dose em curto prazo - diária ao invés de dias alternados - pode reduzir o risco de recidiva. Outros dois estudos mostraram redução do risco de recidiva durante infecções virais quando as doses de manutenção de prednisona foram aumentadas em 5 mg/dia durante 7 dias seguidos ou em 0,5 mg/kg/dia durante 5 dias consecutivos (24,25).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclofosfamida** -->
A ciclofosfamida é um agente alquilante que pode induzir remissões mais duradouras do que prednisona em pacientes com recidivas frequentes ou dependentes de corticosteroides (26-29).  
Uma meta-análise de ECR comparou a eficácia de agentes alquilantes com prednisona isoladamente na manutenção da remissão em crianças com SNSC. Em 3 ensaios de 102 pacientes, ciclofosfamida oral em comparação com prednisona reduziu o risco de recidiva em 6-12 meses (RR 0,44; IC 95% 0,26-0,73) (29).  
Dados da literatura sugerem que a terapia com ciclofosfamida aumenta a remissão sustentada nos pacientes com recidivas frequentes ou dependentes de corticosteroide em 67%-93% em 1 ano, em 36%-66% em 5 anos e em aproximadamente 25% em 10 anos (7,26,30).  
A resposta à ciclofosfamida é maior nos pacientes com recidivas frequentes do que nos dependentes de corticosteroide. Setenta por cento daqueles com recidivas frequentes tiveram remissão prolongada após um curso de ciclofosfamida oral por 8 semanas enquanto a remissão ocorreu em apenas 30% dos dependentes de corticosteroide (31).  
Em um seguimento de longo prazo (tempo médio de 6 anos) de 93 pacientes dependentes de corticosteroide com SNLM, comprovada por biópsia, apenas 35% permaneceram em remissão sustentada após um curso de ciclofosfamida, 30% tiveram mais de 5 recidivas e 20% tiveram 5 ou menos. Em 13% o seguimento foi perdido (32).  
O efeito da ciclofosfamida pode depender da duração do tratamento, especialmente em crianças dependentes de corticosteroide. Isto foi demonstrado em um estudo alemão, no qual 18 crianças receberam um curso de 12 semanas de ciclofosfamida oral (2 mg/kg/dia) (33). Em comparação com controles históricos tratados por 8 semanas, um número maior de pacientes tratados por 12 semanas estava em remissão após 2 anos (67% _versus_ 30%). No entanto, outros estudos não encontraram diferenças no tempo de remissão entre cursos de 8 ou 12 semanas (29,34,35).  
Não está claro se a ciclofosfamida intravenosa é tão eficaz quanto à ciclofosfamida oral na manutenção da remissão. Um estudo relatou que ciclofosfamida intravenosa não foi eficaz na prevenção de recidiva em pacientes dependentes de corticosteroide (35). Em contraste, um estudo randomizado de 47 pacientes concluiu que o risco de recidiva em 6 meses foi menor com ciclofosfamida intravenosa (6 doses mensais) do que com um curso de 12 semanas de ciclofosfamida oral, embora este benefício não tenha persistido durante os 2 anos de seguimento (36).  
Em pacientes com sinais de toxicidade pelo uso de corticosteroide, um curso de 12 semanas de ciclofosfamida oral na dose de 2 mg/kg/dia é indicado, por ter menos risco de efeitos adversos e facilidade de administração.  
Estudos adicionais são necessários para esclarecer se há um papel para ciclofosfamida intravenosa em crianças com SN, razão por que não está sendo indicada neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclosporina** -->
A ciclosporina é eficaz em induzir ou manter a remissão em pacientes com recidivas frequentes ou dependentes de corticosteroide (37-43). A hipercolesterolemia pode inibir a eficácia do medicamento, requerendo doses mais elevadas para atingir resultados semelhantes (44,45).  
Um estudo prospectivo multicêntrico realizado no Japão comparou a eficácia de dois esquemas de ciclosporina após os pacientes terem sido tratados por 6 meses com nível sanguíneo de vale de 80-100 ng/mL. O nível terapêutico desejado até a próxima dose é estabelecido pelo chamado “nível de vale”, quando o sangue para dosagem do medicamento é coletado 1 hora antes de o paciente ingerir a próxima dose. O grupo A recebeu uma dose suficiente para manter o nível sérico (vale) de 60-80 ng/mL enquanto o grupo B recebeu uma dose fixa de 2,5 mg/kg/dia. Após 2 anos, o número de pacientes em remissão sustentada foi significativamente maior no grupo A (46).  
Uma revisão da literatura, que incluiu 129 crianças, demonstrou que ciclosporina induziu ou manteve a remissão em 85% dos pacientes, permitindo assim a retirada de prednisona (39). A dose recomendada é de 150 mg/m<sup>2</sup> /dia ou 6 mg/kg/dia divididos em 2 tomadas. A dose deve ser ajustada para manter níveis sanguíneos entre 100-200 ng/mL. Via de regra, recomenda-se pelo uso de inicial de ciclofosfamida em pacientes com recidivas frequentes e corticodependentes, uma vez que este medicamento, quando há boa resposta, possibilita a suspensão completa do corticoide e a manutenção da remissão sem o seu uso. No entanto, apenas uma parte dos pacientes respondem à ciclosporina e esta resposta muitas vezes não é mantida a longo prazo. A ciclosporina, assim, é reservada para os pacientes que não responderam à ciclofosfamida.  
A remissão induzida por ciclosporina, entretanto, não é duradoura e a maioria dos pacientes terá uma recidiva dentro dos primeiros meses após a interrupção do tratamento (38). Assim, seu uso pode ser necessário durante longos períodos, expondo os pacientes a uma potencial nefrotoxicidade. Os níveis séricos de creatinina devem ser monitorados regularmente. Biópsias de rim seriadas demonstraram o aparecimento de lesões histológicas decorrentes da nefrotoxicidade sem evidências clínicas de comprometimento da função renal. Assim, alguns autores sugerem biopsiar pacientes assintomáticos após 18 meses de tratamento, independentemente da elevação da creatinina sérica, para afastar lesões causadas pelo uso prolongado do medicamento (41). A tendência atual é biopsiar cada vez menos. Biópsias de monitoramento justificam-se apenas se o paciente vem apresentando aumentos de creatinina não responsivos à redução da dose de ciclosporina.  
Pacientes que recidivam após a retirada de ciclosporina frequentemente respondem mal a um segundo ou terceiro curso de tratamento. O uso de uma baixa dose de prednisona em dias alternados, em combinação com ciclosporina pode ser uma melhor opção para estes pacientes.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Outros medicamentos** -->
O **micofenolato de mofetila** (MMF) é um inibidor da purino-sintetase, que inibe a síntese de linfócitos T e B. Trata-se de um agente imunomodulador. Sua utilização em glomerulopatias é relativamente recente. Na SN dependente de corticosteroide (SNDC) e na SN de recidivas frequentes, o MMF tem sido empregado em associação com doses decrescentes de prednisona, por 12-24 meses. Vem sendo indicado em caso de reações adversas à ciclosporina, como nefrotoxicidade, hipertricose ou hiperplasia gengival, julgadas deletérias à adesão terapêutica de pacientes sensíveis à ciclosporina. Dados limitados sugerem que o MMF pode prolongar o tempo de remissão em crianças com SNI; no entanto, na maioria dos casos, ocorrem recidivas após a interrupção do tratamento em pacientes dependentes de corticosteroide (47-51).  
Um estudo aberto, prospectivo e multicêntrico avaliou 33 pacientes com recidivas frequentes que, enquanto em remissão, receberam MMF na dose de 600 mg/m<sup>2</sup> /dia (dose máxima de 1 g) por 6 meses e  
tiveram redução gradual da dose de prednisona (em dias alternados) durante as primeiras 16 semanas do estudo (49). Um paciente recidivou 2 dias após o início do tratamento. Dos 32 pacientes que completaram o estudo, 24 permaneceram em remissão durante os 6 meses de tratamento com MMF, 16 recidivaram quando MMF foi interrompido e 8 permaneceram em remissão por 18-30 meses após a suspensão do medicamento.  
Em um pequeno estudo randomizado comparando MMF (1.200 mg/m<sup>2</sup> /dia) com ciclosporina (4-5 mg/kg/dia), a remissão completa e sustentada foi atingida em 7 dos 12 pacientes que receberam MMF e em 11 dos 12 pacientes tratados com ciclosporina, sugerindo que ciclosporina é mais eficaz do que MMF (52). Embora o MMF tenha demostrado menor incidência de efeitos adversos (53), mais estudos clínicos controlados são necessários para determinar se existe um papel para o uso de MMF no tratamento de crianças e adolescentes dependentes de corticosteroide, razão por que não está indicado neste Protocolo.  
Estudo randomizado multicêntrico alemão incluindo 60 crianças recidivantes frequentes que foram tratadas com ciclosporina ou MMF, com _crossover_ após 1 ano, mostrou mais recidivas com MMF no primeiro ano, mas não no segundo ano. O MMF foi inferior à ciclosporina na prevenção de recidivas; no entanto, pacientes que utilizaram MMF apresentaram melhor função renal. Embora o MMF pareça ser menos nefrotóxico, mais estudos são necessários para incluí-lo no arsenal terapêutico (54).  
Nos últimos anos, o anticorpo monoclonal anti-CD20 **rituximabe** (RTX) tem sido estudado como terapia de resgate em pacientes com SNDC persistente. A eficácia e a segurança do RTX para este fim foram avaliadas em um estudo prospectivo multicêntrico e em uma série de casos (55,56).  
Em um estudo francês, o RTX foi administrado após remissão da proteinúria em 15 dos 22 pacientes e na vigência de proteinúria nos restantes. A duração média da doença previamente ao uso de RTX foi de 11 anos. O medicamento foi eficaz nos pacientes que o receberam na vigência de proteinúria negativa e em 3 dos 7 pacientes aos quais foi administrado na vigência de proteinúria nefrótica (53). Apesar de a SNDC persistente poder ser controlada após indução com uma dose do medicamento, há relatos tanto de evolução bem-sucedida em longo prazo, como da necessidade de outras doses para controle de recidiva da doença que, em geral, ocorre após recuperação da contagem de células CD20 (56,57).  
Em um estudo clínico controlado, 54 crianças com SNDC em uso de inibidores de calcineurina foram randomizadas para manter a terapia com as doses usuais de inibidor de calcineurina e corticosteroide ou adicionar RTX a um esquema de dose baixa destes imunossupressores. Ao fim de 3 meses, a taxa de recorrência foi de 18,5% no grupo que usou RTX e de 48,1% no grupo que manteve o tratamento padrão (p = 0,029). A probabilidade de estar sem medicamento em 3 meses foi de 62,9% e de 3,7% respectivamente, e metade dos pacientes que receberam RTX permaneciam em remissão sustentada e livres de medicamento ao fim de 9 meses (58). O pouco tempo de seguimento limita a interpretação dos dados desse estudo. Mais recentemente, um ECR duplo-cego, envolvendo 48 crianças com recidivas frequentes ou dependentes de corticoide que receberam RTX ou placebo quando em remissão, mostrou que o grupo que recebeu RTX apresentou maior período livre de recorrências (267 _versus_ 101dias), menor taxa de recorrência (1,54 _versus_ 4,17 recidivas/paciente/ano) e menor uso diário de prednisona que os controles. No entanto, essa diferença desapareceu com o tempo, e com 19 meses, todos os pacientes recidivaram (59).  
Meta-análise envolvendo três ECR e dois estudos comparativos controlados, com o total de 184 pacientes, sendo 89 que usaram RTX e 95 controles, mostrou que o RTX aumentou significativamente o intervalo livre de recidivas e reduziu a ocorrência de proteinúria. No entanto, entre os estudos selecionados havia um envolvendo pacientes resistentes a corticoide, que constituem um grupo diferente e não comparável aos dependentes de corticoide e recidivantes frequentes (60).  
Embora vários estudos e relatos mostrem o potencial do RTX em manter períodos livres de recidiva, possibilitando redução e até suspensão do uso de corticoide e outros imunossupressores, esse efeito tem sido descrito como temporário, e novas doses são frequentemente necessárias após a recuperação das células B (57,61-67). Paralelamente, alguns autores acreditam que resultados positivos têm sido relatados com muito maior frequência do que os negativos, resultando em um viés importante (68).  
Embora a maioria dos estudos não mencione efeitos adversos importantes além de reações relacionadas à infusão com o uso de RTX, há relatos de leucoencefalopatia causada pelo vírus JC, infecções por _Pneumocystis carinii_ e doença ulcerativa gastrointestinal nos pacientes tratados com o RTX para outras indicações, deixando dúvidas relativas à segurança com o uso desse medicamento. Em virtude disso, seu uso não é indicado neste Protocolo.  
O **tacrolimo** (TAC) é um inibidor da calcineurina largamente utilizado na prevenção da rejeição aguda no transplante de órgãos. Trata-se de um antibiótico macrolídeo, que inibe a ativação de um fator de transcrição essencial para a produção de citocinas pelo linfócito CD4, resultando em diminuição de produção de interleucina-2 (IL-2) e interferona-gama.  
Em um estudo retrospectivo de 10 crianças com SNDC, a comparação de períodos de tratamento com ciclosporina e com TAC em relação ao número de recidivas, dose cumulativa de prednisona, perda de ritmo de filtração glomerular e hipertensão arterial não apresentou diferença significativa (69).  
Na SNDC, a única indicação do TAC seria frente a uma reação adversa a ciclosporina, como hipertricose ou hiperplasia gengival, cuja magnitude interfira na adesão do paciente ao tratamento, ou ofereça complicações odontológicas significativas, como gengivite recorrente de difícil tratamento. (Ver o item 6 - Casos Especiais).  
Outro fármaco eventualmente utilizado na SNDC é o levamisol, sendo, contudo, necessário usá-lo por longo período. Seu efeito não é sustentado isoladamente (64). Este medicamento tem sido empregado como agente poupador de corticosteroide em pacientes com SNDC. A _British Association for Paediatric Nephrology_ realizou um estudo multicêntrico no qual 61 crianças receberam levamisol (2,5 mg/kg em dias alternados até a dose máxima de 150 mg) ou placebo. Quatorze pacientes do grupo do levamisol e apenas 4 do grupo controle ainda estavam em remissão 4 meses após a suspensão do corticosteroide. Entretanto, a maioria dos pacientes teve recidiva após a suspensão do tratamento (29,70). Não se indica, portanto, o uso de levamisol neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **<u>Síndrome nefrótica resistente ao corticosteroide - SNRC</u>** -->
A SNRC é definida pela ausência de resposta ao tratamento inicial com prednisona oral na dose de 60 mg/m<sup>2</sup> /dia ou 2 mg/kg/dia por 8 semanas ou prednisona durante 4 semanas, seguido de pulsoterapia com metilprednisolona em 3 doses de 1.000 mg/1,73 m<sup>2</sup> ou 20-30 mg/kg em dias alternados por 3-6 doses. Nestes casos, a biópsia renal está indicada.  
O tratamento geralmente é de suporte com uso de inibidores da enzima conversora da angiotensina (IECA) e bloqueadores dos receptores da angiotensina II (BRA), além do uso de fármacos hipolipemiante conforme o Protocolo Clínico e Diretrizes Terapêuticas da Dislipidemia para a prevenção de eventos cardiovasculares e pancreatite, do Ministério da Saúde.  
A terapia com corticosteroide deve ser suspensa até que o resultado da biópsia esteja disponível, já que os efeitos adversos são frequentemente intensos e o tratamento, ineficaz.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclofosfamida** -->
Inexistem dados que demonstrem um efeito benéfico de agentes alquilantes em crianças com SNRC. Remissões parciais ou completas foram relatadas em 20% dos casos após um curso de ciclofosfamida, o que é semelhante à taxa de remissão espontânea em pacientes não tratados ou naqueles que continuam a receber tratamento com corticosteroide isoladamente (7,71,72).  
Um estudo randomizado do _International Study of Kidney Disease in Children_ (ISKDC) comparou ciclofosfamida mais prednisona _versus_ prednisona isoladamente em pacientes com SNRC e GESF (72). A mesma proporção de crianças nos dois grupos entrou em remissão por 6 meses.  
Portanto, não há evidência que sugira que os agentes alquilantes devam ser indicados no tratamento de crianças com SNRC. Não se recomenda o uso de ciclofosfamida para pacientes com SNRC.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclosporina** -->
A eficácia da ciclosporina na SNRC em crianças está confirmada em vários estudos (73-80). Em um estudo realizado pela Sociedade Francesa de Nefrologia Pediátrica, 65 crianças com SNRC foram tratadas com ciclosporina (150-200 mg/m<sup>2</sup> /dia) em combinação com prednisona (30 mg/m<sup>2</sup> /dia durante 1 mês seguida de prednisona oral em dias alternados durante 5 meses). A remissão completa foi observada em 42% das crianças, 48% com SNLM e 30% com GESF. Metade dos pacientes que responderam entraram em remissão no primeiro mês de tratamento. Oito dos 27 respondedores tornaram-se sensíveis ao corticosteroide quando recidivaram posteriormente. Em 17 pacientes, a remissão completa e parcial durou de 5 meses a 3 anos. Nenhum dos respondedores evoluiu para insuficiência renal terminal e apenas 2 persistiram com SN. Complicações ocorreram em 12 dos 31 respondedores e em 15 dos 34 não respondedores. Entre os pacientes com má evolução, a maioria apresentava GESF (73).  
Em um pequeno estudo, ciclosporina foi mais eficaz do que ciclofosfamida na indução de uma remissão parcial em crianças com SNRC (79).  
Em outro estudo, 15 crianças com SNRC foram tratadas com doses moderadas de ciclosporina (dose média de 6,3 mg/kg/dia) mais prednisona. A dose de ciclosporina foi ajustada para manter o nível sanguíneo (vale) entre 70-120 ng/mL. Treze pacientes entraram em remissão após uma duração média de tratamento de 2 meses (74).  
Em um estudo randomizado, o uso de ciclosporina foi comparado com a terapia de suporte. Dos 22 pacientes tratados com ciclosporina, 7 entraram em remissão completa e 6 em remissão parcial após 6 meses; em comparação, nenhum paciente entre aqueles não tratados entrou em remissão completa e remissão parcial ocorreu em apenas 3 de 19 pacientes (76).  
Em um estudo retrospectivo de 25 crianças com GESF tratadas com ciclosporina (150 mg/m<sup>2</sup> /dia) em combinação com metilprednisolona intravenosa em pulsos (300-1.000 mg/m<sup>2</sup> /dia durante 3-8 dias) seguidos de prednisona oral (40 mg/m<sup>2</sup> /dia após o término da pulsoterapia), observou-se taxa de remissão completa e parcial de 84% em comparação com 64% nas 27 crianças com GESF tratados com ciclosporina mais prednisona oral (40 mg/m<sup>2</sup> a cada 2 dias). Todos os 14 pacientes com SNLM incluídos nesse estudo entraram em remissão, independentemente do esquema terapêutico adotado (80).  
Um estudo sugeriu que ciclosporina pode reduzir o risco de progressão para insuficiência renal nestes pacientes. Em um período de 5 anos, a taxa de progressão para insuficiência renal terminal foi de 24% nos tratados com ciclosporina em comparação com 78% nos controles históricos com GESF que não responderam a ciclofosfamida (78).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Outros medicamentos** -->
O tacrolimo foi estudado por Loeffler _et al_ . (81) em estudo retrospectivo de 16 crianças com SNRC. Ocorreu remissão completa ou parcial em 81% e em 13% dos casos respectivamente, alguns deles após falha terapêutica da ciclosporina. Subsequentemente, Bhimma _et al_ . (82), em estudo prospectivo de 20 crianças com SNRC por GESF, observaram que a introdução de TAC e prednisona em dose baixa por 12 meses induziu remissão parcial ou completa, respectivamente, em 45% e 40% dos casos. Após a suspensão do medicamento, a maior parte dos pacientes teve recidiva da SN.  
Gulati _et al_ . (83) avaliaram prospectivamente a eficácia de TAC em 22 crianças consecutivas com SNRC. Prednisona foi utilizada conjuntamente em todos os casos. Nove pacientes apresentaram biópsia renal compatível com lesões glomerulares mínimas, 11 com GESF e dois com proliferação mesangial. O TAC foi suspenso em três pacientes por efeitos adversos. Das 19 crianças remanescentes, remissão completa ocorreu em 16, remissão parcial em duas e houve uma falha terapêutica. Em um pequeno ensaio clínico no qual o TAC foi comparado com ciclosporina em pacientes com SNRC, as taxas de remissão completa e parcial entre os dois agentes foram semelhantes após 6 e 12 meses; no entanto foi demonstrado um risco de recorrência significativamente menor nos pacientes que usaram tacrolimo. Todos os pacientes foram tratados com enalapril e prednisona em dias alternados (84).  
São frágeis os estudos para a utilização de TAC como medicamento imunossupressor acessório na SNRC após falha terapêutica. No entanto, em vista da ampla disponibilidade da ciclosporina e de resposta semelhante à obtida com TAC, opta-se pela indicação do TAC neste Protocolo somente em casos de pacientes que tenham desenvolvido hipertricose ou hiperplasia gengival associada ao uso de ciclosporina (ver o item 6 Casos Especiais).  
Inexistem dados convincentes que demonstrem benefício da administração do MMF em pacientes com SNRC, como demonstrado nos trabalhos de pequeno porte descritos abaixo.  
Em um estudo de 5 pacientes com SNRC, apenas 1 deles atingiu remissão completa após a administração do MMF (85). Em outro, com 18 adultos com SNRC, houve redução na proteinúria nos 8 pacientes que foram aleatoriamente designados para MMF em comparação com placebo. No entanto, a remissão completa não foi atingida em nenhum paciente (86).  
A utilização de MMF em conjunto com prednisona em pacientes com SNRC e GESF demonstrou possibilidade de remissão parcial em menos de 50% dos casos (86). A possibilidade de remissão completa com este agente na SNRC é rara; o seu uso não é recomendado neste Protocolo.  
O benefício de RTX em pacientes com SNRC foi avaliado em um número muito limitado de pacientes (87-89). Na primeira série de 2 casos, uma dose inicial de RTX (375 mg/m<sup>2</sup> ) induziu remissão completa no primeiro e remissão parcial no segundo paciente. O segundo paciente atingiu a remissão completa 5 meses após a segunda dose (88). Na segunda série de casos, 5 crianças com SNRC (3 com resistência inicial e 2 com resistência tardia) receberam 4 doses semanais do medicamento. Quatro obtiveram remissão completa e 1 obteve remissão parcial. A remissão completa foi persistente em 3 pacientes (89). No entanto, também há relatos de pacientes que não responderam ao RTX, não podendo ser indicado neste Protocolo para crianças e adolescentes com SNRC. Um estudo clínico randomizado em 31 crianças com SNCR sem resposta a inibidores de calcineurina não mostrou redução na proteinúria nos pacientes que receberam duas doses de RTX (90).  
Pacientes que não respondem ao tratamento e mantêm proteinúria maciça e hipoalbuminemia apresentam risco elevado de complicações da SN. Nestes pacientes, o uso de agentes antiproteinúricos não imunológicos reduz parcialmente a perda proteica (91). Estudos em adultos mostram que este tipo de  
intervenção pode prolongar a sobrevida renal. Entre os agentes antiproteinúricos destacam-se os inibidores da enzima de conversão da angiotensina (IECA) e os bloqueadores dos receptores da angiotensina (BRA). Entre os primeiros foram utilizados especialmente o enalapril e o lisinopril e entre os BRA destacam-se a losartana e a candesartana. Dados similares em crianças mostram que o uso desses medicamentos também reduz a proteinúria (92,93).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **<u>Controle dos sintomas e prevenção das complicações da SN</u> Progressão para insuficiência renal** -->
Vários estudos em adultos demonstraram que o uso de IECA e BRA podem reduzir a taxa de progressão da insuficiência renal crônica em pacientes com proteinúria. Embora não existam dados semelhantes para crianças e adolescentes, o uso destes medicamentos em crianças com SNRC e proteinúria persistente está justificado com base nas evidências em adultos com doença renal crônica e proteinúria.  
Em uma série de 9 crianças com GESF resistente ao corticosteroide, a combinação de IECA ou BRA e MMF foi testada com redução da proteinúria (94), entretanto mais pesquisas são necessárias para embasar essa conduta.  
Os IECA e BRA devem ser evitados em casos de hiperpotassemia ou quando ocorrer aumento na concentração de creatinina (> 30% do valor inicial).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Infecções** -->
Crianças com SN têm risco aumentado para infecções virais e bacterianas (pneumonia, peritonite e sepse) por bactérias encapsuladas em razão da redução na concentração de imunoglobulinas, da redução da imunidade celular e do uso da terapia imunossupressora (95). _Streptococcus pneumoniae_ e _Escherichia coli_ são as bactérias mais frequentes (96).  
Apesar da redução na resposta imunológica, pacientes que receberam vacina para pneumococo no início do tratamento da SN, mesmo em uso de doses elevadas de corticosteroide, aumentaram em 10 vezes os títulos de anticorpos (94).  
Recomenda-se que estas crianças recebam vacinas contra pneumococo e varicela, idealmente quando em remissão e sem que estejam fazendo uso de corticosteroide.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Tromboembolia** -->
Pacientes com SN e hipoalbuminemia grave têm risco elevado para o desenvolvimento de complicações tromboembólicas devido à hemoconcentração e perda de antitrombina III (AT III) na urina.  
Alguns autores sugerem o uso de anticoagulação sistêmica profilática com varfarina em pacientes considerados de alto risco, ou seja, nos que apresentam albumina sérica abaixo de 2 mg/dL, fibrinogênio acima de 6 g/L ou AT III abaixo de 70%, porém, por dificuldade de monitorização, risco elevado de sangramento e necessidade de punções frequentes para coletas de sangue, não está recomendado o uso de anticoagulação profilática neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Edema** -->
O uso de diuréticos deve ser evitado na maioria dos pacientes pelo risco de precipitar uma piora na função renal nestes pacientes já frequentemente com hipovolemia, estando reservado para crianças em anasarca e com sinais de congestão circulatória, derrame pleural ou ascite. Deve-se preferir o uso oral ao intravenoso (97).  
Recomenda-se restrição de sal em torno de 500-700 mg/dia para crianças de aproximadamente 10 kg de peso e em até 2 g/dia para crianças maiores.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Hiperlipidemia** -->
A hiperlipidemia secundária a SN é reversível e normaliza-se com a remissão da doença. O tratamento ideal não está estabelecido. A modificação da dieta traz pouco benefício.  
Os medicamentos que demonstraram maior benefício em adultos com SN persistente são as estatinas, que podem reduzir os níveis de colesterol total.  
Com base em estudos na população adulta e em crianças com hipercolesterolemia familiar, recomenda-se o uso de estatinas para crianças com proteinúria persistente com hiperlipidemia, conforme PCDT de Dislipidemia para a prevenção de eventos cardiovasculares e pancreatite, do Ministério da Saúde. As estatinas também possuem efeitos anti-inflamatórios, podendo proporcionar redução ainda maior da proteinúria (98).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **7.1 FÁRMACOS** -->
- Prednisona: comprimidos de 5 e 20 mg;  
- Metilprednisolona: ampola de 500 mg;  
- Ciclosporina: cápsulas de 10, 25, 50 e 100 mg e solução oral de 100 mg/ml 50 ml;  
- Ciclofosfamida: drágeas de 50 mg;  
- Tacrolimo: cápsulas de 1 e 5 mg;  
- Enalapril: comprimidos de 5, 10 e 20 mg;  
- Losartana: comprimidos de 50 mg.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Tratamento inicial** -->
Deve ser administrada prednisona oral, em dose única diária, pela manhã, de 60 mg/m<sup>2</sup> /dia ou 2 mg/kg/dia (máximo de 60 mg/dia) por 4 semanas.  
Se o paciente não entrar em remissão completa, a mesma dose deve ser mantida por 8 semanas.  
Após as primeiras 4 semanas de tratamento e caso o paciente apresente remissão completa, a dose deve ser reduzida para 40 mg/m<sup>2</sup> /48h ou 1,5 mg/kg/48h durante mais 4 semanas, e depois reduzida rapidamente. Com base nos estudos randomizados publicados recentemente, a primeira manifestação pode ser tratada por um período total de 2-3 meses.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Primeira recidiva** -->
Deve ser administrada prednisona oral, em dose única diária, pela manhã, de 60 mg/m<sup>2</sup> /dia ou 2 mg/kg/dia (máximo de 60 mg/dia) até atingir a remissão completa por 3 dias.  
Após a remissão por 3 dias, a dose deve ser reduzida para 40 mg/m2/48h ou 1,5 mg/kg/48h durante mais 4 semanas. A redução é feita de forma similar à proposta no item anterior.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Recidivas frequentes/dependência de corticosteroide** -->
Deve ser administrada prednisona oral, em dose única diária, pela manhã, de 60 mg/m2/dia ou 2 mg/kg/dia (máximo de 60 mg/dia) até atingir a remissão completa por 3 dias. A dose é então reduzida para 40 mg/m<sup>2</sup> /48h e administrada por 4 semanas. Outra conduta recomenda o tratamento de recidivas com  
prednisona (60 mg/m2/48h) até o desaparecimento da proteinúria por 3 dias. A dose do medicamento é reduzida até 15-20 mg/m2/48h ou de acordo com o limiar de glicocorticoide do paciente (ou seja, a dose em que a recidiva ocorreu). Este esquema é mantido por 12-18 meses com redução gradual no final do tratamento.  
Se o paciente apresentar efeitos adversos ao uso de corticosteroide ou recidivar com dose relativamente elevada (por exemplo mais de 0,5 mg/kg/48h), sugere-se o uso associado de medicamentos alternativos: ciclofosfamida ou ciclosporina.  
A ciclofosfamida oral deve ser iniciada somente após o paciente entrar em remissão completa. A dose é 2 mg/kg/dia durante 12 semanas até uma dose cumulativa máxima de 168 mg, e a dose total diária não deve exceder a 2,5 mg/kg. Não deve ser administrado um segundo curso de ciclofosfamida.  
A ciclosporina deve ser iniciada na dose de 150 mg/m<sup>2</sup> ou 6 mg/kg/dia em duas doses diárias para manter o nível sanguíneo de vale entre 150-200 ng/ml nos primeiros 6 meses e entre 100-150 ng/mL após 6 meses). Inexiste, atualmente, recomendação de tempo de tratamento, já que grande parte dos pacientes tornase dependente do medicamento. Sugere-se redução gradual da dose até o mínimo capaz de manter o paciente em remissão, sem necessidade de uso frequente de corticosteroide. Alcançada a dose mínima, recomenda-se manter o medicamento por longo prazo (99).  
Alternativamente, o tacrolimo, indicado somente nos casos de hipertricose ou hiperplasia gengival associado ao uso da ciclosporina, deve ser iniciada na dose de 0,1 a 0,2 mg/kg/dia, em duas administrações diárias.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Resistência ao corticosteroide** -->
Em pacientes resistentes ao corticosteroide (após biópsia renal), deve-se iniciar a administração de ciclosporina na dose de 100-150 mg/m<sup>2</sup> ou 4-6 mg/kg/dia (em 2 doses diárias para manter o nível sérico de vale entre 150-200 ng/mL nos primeiros 6 meses e entre 100-150 ng/mL após 6 meses) ou na menor dose possível para manter o paciente em remissão.  
Administração de prednisona oral 30 mg/m<sup>2</sup> /dia por 30 dias e 30 mg/m<sup>2</sup> /48h durante os 5 meses subsequentes é recomendada em associação com ciclosporina. Havendo resposta, o medicamento deve ser mantido por longo prazo, com redução da dose, quando possível. Para manter o medicamento por tempo superior a 2 anos, recomenda-se fazer nova biópsia renal para investigar a presença de nefropatia crônica secundária ao uso de ciclosporina.  
Alternativamente, o tacrolimo, indicado somente nos casos de hipertricose ou hiperplasia gengival associado ao uso da ciclosporina, deve ser utilizado na dose de 0,1 a 0,2 mg/kg/dia, em 2 administrações diárias. Na remissão parcial, o tratamento deve ser mantido por pelo menos 12 meses. Se não houver resposta após 3-6 meses com as doses recomendadas e nível sérico adequado, deve-se suspender o tratamento. Nos casos de resistência a ciclosporina, o uso de IECA e BRA deve ser mantido por longo prazo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Casos de proteinúria maciça e hipoalbuminemia** -->
**Enalapril:** 0,2 a 0,6 mg/kg/dia em 1 a 2 administrações. Dose mais alta é mais efetiva e deve ser utilizada se houver boa tolerância (93).  
**Losartana:** 0,4 a 1,4 mg/kg/dia em dose única diária (100).  
Para ambos os medicamentos, o aumento da dose inicial deve ser feito se não houver efeitos adversos, principalmente hiperpotassemia e hipotensão e se a proteinúria não cair abaixo de 50% do valor basal.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **- Corticosteroide** -->
Pacientes que desenvolvem obesidade, estrias, hipertensão arterial, catarata ou retardo de crescimento deverão ter o tratamento interrompido.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **- Ciclofosfamida** -->
O risco de toxicidade medular por agentes alquilantes exige monitoramento de leucograma a cada 2 semanas. Se a contagem de leucócitos for < 3.000/mm<sup>3</sup> , o medicamento deve ser suspenso até que a contagem se normalize. O tratamento também deve ser interrompido na vigência de infecção para ser reiniciado somente após a resolução da mesma. Há relatos de casos de alta morbidade e mortalidade associados à ocorrência de varicela. Nesses casos, aciclovir deve ser administrado imediatamente, e ciclofosfamida, interrompida durante a vigência da infecção (28).

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **- Ciclosporina** -->
Pacientes com aumento superior a 30% dos níveis de creatinina sérica apesar de redução da dose e nível sérico adequado e com ausência de resposta terapêutica após 3-6 meses devem ter o tratamento interrompido.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: - **Tacrolimo** -->
Pacientes com aumento superior a 30% dos níveis de creatinina sérica apesar de redução da dose e nível sérico adequado e com ausência de resposta terapêutica após 3-6 meses devem ter o tratamento interrompido.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **7.4 BENEFÍCIOS ESPERADOS** -->
- Prevenção da evolução para insuficiência renal crônica, que pode culminar na necessidade de terapia renal substitutiva (hemodiálise e transplante renal);  
- normalização do crescimento nos casos que atingem remissão;  
- correção do hipotireoidismo secundário à perda de hormônios;  
- redução do risco de infecções secundárias à redução na síntese de IgG, redução na função do  
- linfócito T e perda urinária do fator B;  
- redução do risco de trombose arterial ou venosa.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **8 MONITORIZAÇÃO** -->
Pacientes com SNP devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica, bem como ao ajuste de doses conforme necessário e ao controle de efeitos adversos.  
A monitorização do tratamento será realizada por meio de avaliações clínicas e laboratoriais. Enquanto se mantiver a SN, as avaliações devem ser mensais ou em intervalos ainda menores nos pacientes que utilizam citotóxicos, principalmente para detecção imediata de leucopenia, quando o medicamento deverá ser suspenso pelo risco de infecções bacterianas, virais ou fúngicas oportunistas, complicações essas associadas ao grande potencial de morbidade e mortalidade no paciente nefrótico. Recomenda-se a  
imunização para pneumococo e varicela, preferencialmente quando o paciente estiver em remissão e sem uso de corticosteroide.  
Nos pacientes em remissão completa, as avaliações podem ser feitas 4 vezes ao ano ou antes em caso de recidiva dos sintomas. Os exames básicos para avaliação incluem creatinina sérica, albumina sérica, colesterol total, triglicerídeos, hemograma, glicose, exame qualitativo de urina (EQU) e índice proteína/creatinina em amostra de urina. A solicitação de outros exames deve ser individualizada.  
Nos pacientes em uso de ciclosporina, a avaliação da creatinina e do nível sanguíneo de ciclosporina deverá ser realizada semanalmente no primeiro mês de tratamento e, após, a cada 4 semanas, para evitar nefrotoxicidade aguda ou crônica associada ao inibidor da calcineurina, que é causa de insuficiência renal progressiva por fibrose do tecido renal. Na fase inicial do tratamento (6 meses), considera-se aceitável a concentração de 150-200 ng/mL; na fase de manutenção (após 6 meses), a meta terapêutica é de 100-150 ng/mL para evitar nefrotoxicidade. Deve-se ajustar a dose diária sempre em bases individuais, pois o metabolismo do medicamento é extremamente variável.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Corticosteroide** -->
Complicações secundárias à terapia prolongada com corticosteroide são bem conhecidas e podem ser observadas em crianças com SN, especialmente naquelas com recidivas frequentes ou nas dependentes de corticosteroide. Os efeitos adversos associados ao uso de corticosteroide em crianças com SN encontram a seguir elencadas:  
- Retardo de crescimento - mais frequente com a terapia prolongada e uso diário de corticosteroide (101). Terapia em dias alternados pode interferir no crescimento (102). A recuperação do crescimento pode ocorrer com frequência quando a terapia com corticosteroide é interrompida (103);  
- Catarata - o uso prolongado de corticoides pode levar a opacificações do cristalino e desenvolvimento de catarata. Revisões oftalmológicas anuais são necessárias em crianças em uso crônico de corticoides (104,105);  
- Ganho excessivo de peso, que pode persistir na idade adulta (106);  
- Osteoporose - embora tenha sido relatada em adultos com SNSC, um estudo que comparou adolescentes e crianças com SN sensível ao corticosteroide não encontrou efeitos em longo prazo da exposição intermitente a corticosteroide sobre a massa óssea (106);  
- Supressão do eixo hipotálamo-pituitária-adrenal (HPA) - em uma série de 32 casos (idade média de 9,7 anos) tratados com corticosteroide em dias alternados, 20 deles tiveram evidência de supressão de HPA, definido como um pico de concentração de cortisol sérico abaixo de 18 mcg/dL em resposta à estimulação por cortrosina (0,5 mcg) (107). Os autores sugerem que a supressão do eixo HPA tenha aumentado o risco de recidiva, porém a contribuição da supressão do eixo HPA é incerta porque os pacientes, nesse pequeno estudo, receberam múltiplos esquemas de tratamento.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclofosfamida** -->
O uso de agentes alquilantes pode ser associado às seguintes complicações (46,47,108):  
- Neutropenia e infecção - o risco de toxicidade medular exige monitoramento semanal do leucograma, com ajuste de dose para evitar leucopenia grave (deve-se procurar manter os leucócitos acima de 3.000/mm<sup>3</sup> ). Há relatos de casos de alta morbidade e mortalidade relacionados à ocorrência de varicela durante o uso de ciclofosfamida. Na presença de varicela, aciclovir deve ser administrado prontamente, e a ciclofosfamida, interrompida;  
- Toxicidade gonadal - o desenvolvimento de toxicidade gonadal, resultando em infertilidade, geralmente acontece com dose total acima de 200-300 mg/kg de ciclofosfamida, que é maior do que a dose cumulativa recomendada de 168 mg/kg (46,47);  
- Neoplasia - há um único caso relatado de neoplasia (leucemia linfoblástica aguda) associado a ciclofosfamida administrada em uma criança com SN, na qual tenha sido adotado o esquema especificado acima (109). A ampla utilização deste esquema em crianças com SN, com apenas um único caso relatado de malignidade, sugere que não há risco clinicamente significativo de aumento na incidência de tumores em comparação com a população pediátrica geral;  
- Alopecia e cistite hemorrágica raramente ocorrem quando são usadas as doses recomendadas para tratar crianças com SN.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Ciclosporina** -->
Os principais efeitos colaterais da ciclosporina incluem:  
- Nefrotoxicidade - o aumento da creatinina sérica mais de 30% do nível basal requer redução na dose. A elevação gradativa da creatinina sérica, com piora da proteinúria e elevação dos níveis tensionais, sugere nefropatia crônica secundária aos inibidores de calcineurina. No caso de glomerulopatia, biópsia renal pode esclarecer o diagnóstico diferencial e orientar o tratamento;  
- Hipertensão arterial;  
- Dislipidemia;  
- Efeitos cosméticos - modificações faciais, hipertricose, muitas vezes grave, e hiperplasia gengival, efeitos colaterais especialmente indesejáveis em adolescentes e pré-adolescentes.  
- Convulsões;  
- Infecções.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **Tacrolimo** -->
Os principais efeitos colaterais do tacrolimo incluem:  
- Nefrotoxicidade: o aumento da creatinina sérica mais de 30% do nível basal requer redução na dose. A elevação gradativa da creatinina sérica, com piora da proteinúria e elevação dos níveis tensionais, sugere nefropatia crônica secundária aos inibidores de calcineurina. No caso de glomerulopatia, biópsia renal pode esclarecer o diagnóstico diferencial e orientar o tratamento;  
- Hipertensão arterial;  
- Dislipidemia;  
- Hiperglicemia/diabete;  
- Convulsões;  
- Infecções.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **9 ACOMPANHAMENTO PÓS-TRATAMENTO** -->
Quando o paciente responde ao tratamento com corticosteroide, é necessário o acompanhamento da proteinúria para, precocemente, se detectar recidiva e reiniciar a terapia, minimizando as complicações associadas à SNI.  
Os pacientes e seus responsáveis devem ser instruídos para que o peso seja verificado com frequência e para que os níveis de proteína na urina sejam monitorados toda vez que os pacientes apresentarem ganho de  
peso ou edema (110). Aumento da concentração de proteína urinária normalmente é a primeira indicação de recidiva. Quando isso ocorre, a família deve procurar atendimento médico para reiniciar o tratamento. Após normalização ou redução da proteinúria, redução ou desaparecimento do edema e suspensão dos imunossupressores, as consultas deverão ser feitas a cada 3 meses até o final do primeiro ano. Após esse período, o paciente deverá ser reavaliado anualmente.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **10 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas, a adequação de uso dos medicamentos e o acompanhamento pós-tratamento.  
É recomendável que os pacientes sejam acompanhados, especialmente na fase aguda, em serviços especializados em nefrologia, para seu adequado diagnóstico, inclusão no Protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **11 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
Sugere-se cientificar o paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **12 REFERÊNCIAS** -->
1. Nephrotic syndrome in children: predriction of histopathology from clinical and laboratory characteristics at time of diagnosis. A report of the International Study of Kidney Disease in Children. Kidney Int. 1978;13(2):159-65.  
2. Kashgarian M, Hayslett JP, Siegel NJ. Lipoid nephrosis and focal sclerosis distinct entities or spectrum of disease. Nephron. 1974;13(2):105-8.  
3. The primary nephrotic syndrome in children. Identification of patients with minimal change nephrotic syndrome from initial response to prednisone. A report of the International Study of Kidney Disease in Children. J Pediatr. 1981;98(4):561-4.  
4. Habib R, Gubler MC. Focal sclerosing glomerulonephritis. Perspect Nephrol Hypertens. 1973;1 Pt 1:26378.  
5. Siegel NJ, Gur A, Krassner LS, Kashgarian M. Minimal-lesion nephrotic syndrome with early resistance to steroid therapy. J Pediatr. 1975;87(3):377-80.  
6. Borges FF, Shiraichi L, da Silva MP, Nishimoto EI, Nogueira PC. Is focal segmental glomerulosclerosis increasing in patients with nephrotic syndrome? Pediatr Nephrol. 2007;22(9):1309-13.  
7. Tarshish P, Tobin JN, Bernstein J, Edelmann CM Jr. Prognostic significance of the early course of minimal changes nephrotic syndrome: report of the International Study of Kidney Disease in Children. J Am Soc Nephrol. 1997;8(5):769-76.  
8. Tune BM, Mendoza SA. Treatment of the idiopathic nephrotic syndrome: regimens and outcomes in children and adults. J Am Soc Nephrol. 1997;8(5):824-32.  
9. El Bakkali L, Rodrigues Pereira R, Kuik DJ, Ket JC, van Wijk JA. Nephrotic syndrome in The Netherlands: a population-based cohort study and a review of the literature. Pediatr Nephrol. 2011;26(8):1241-6.  
10. Wong W. Idiopathic nephrotic syndrome in New Zealand children, demographic, clinical features, initial management and outcome after twelve-month follow-up: results of a three-year national surveillance study. J Paediatr Child Health. 2007;43(5):337-41.  
11. Fletcher JT, Hodson EM, Willis NS, Puckeridge S, Craig JC. Population-based study of nephrotic syndrome: incidence, demographics, clinical presentation and risk factors [Abstract]. Pediatr Nephrol. 2004;19:C96.  
12. McKinney PA, Feltbower RG, Brocklebank JT, Fitzpatrick MM. Time trends and ethnic patterns of childhood nephrotic syndrome in Yorkshire, UK. Pediatr Nephrol. 2001;16(12):1040-4.  
13. Fogo AB. Renal Pathology. In: Avner ED, Harmon WE, editors. Pediatric Nephrology. 6th ed.: SpringerVerlag; 2009. p. 565.  
14. Short versus standard prednisone therapy for initial treatment of idiopathic nephrotic syndrome in children. Lancet. 1988;331(8582):380-3.  
15. Hodson EM, Knight JF, Willis NS, Craig JC. Corticosteroid therapy for nephrotic syndrome in children. Cochrane Database Syst Rev. 2005;(1):CD001533.  
16. Brodehl J. The treatment of minimal change nephrotic syndrome: lessons learned from multicentre cooperative studies. Eur J Pediatr. 1991;150(6):380-7.  
17. Hiraoka M, Tsukahara H, Matsubara K, Tsurusawa M, Takeda N, Haruki S, et al. A randomized study of two long-course prednisolone regimens for nephrotic syndrome in children. Am J Kidney Dis. 2003;41(6):1155-62.  
18. Filler G. Treatment of nephritic syndrome in children and controlled trials. Nephrol Dial Transplant. 2003;18 Suppl 6:vi75-8.  
19. Leisti S, Koskimies O. Risk of relapse in steroid-sensitive nephrotic syndrome: effect of stage of postprednisone adrenocortical suppression. J Pediatr. 1983;103(4):553-7.  
20. Zolotas E, Leontsinis I. Treatment of the first episode of childhood idiopathic nephrotic syndrome: A systematic review and meta-analysis. Nephrol Dial Transplant 2016;31 (Suppl 1):i81.  
21. Early identification of frequent relapsers among children with minimal change nephrotic syndrome. A report of the International Study of Kidney Disease in Children. J Pediatr. 1982;101(4):514-8.  
22. Broyer M, Meyrier A, Niaudet P, Habib R. Minimal changes and focal and segmental glomerular sclerosis. In: Cameron JS, Davison MA, Grunfeld JP, et al., editors. Oxford Textbook of Clinical Nephrology, Oxford Medical Publications; 1992. p. 298.  
23. MacDonald NE, Wolfish N, McLaine P, Phipps P, Rossier E. Role of respiratory viruses in exacerbations of primary nephrotic syndrome. J Pediatr. 1986;108(3):378-82.  
24. Abeyagunawardena AS, Trompeter RS. Increasing the dose of prednisolone during viral infections reduces the risk of relapse in nephrotic syndrome: a randomised controlled trial. Arch Dis Child. 2008;93(3):226-8.  
25. Mattoo TK, Mahmoud MA. Increased maintenance corticosteroids during upper respiratory infection decrease the risk of relapse in nephrotic syndrome. Nephron. 2000;85(4):343-5.  
26. Cameron JS, Chantler C, Ogg CS, White RH. Long-term stability of remission in nephrotic syndrome after treatment with cyclophosphamide. Br Med J. 1974;4(5935):7-11.  
27. Chiu J, Drummond KN. Long-term follow-up of cyclophosphamide therapy in frequent-relapsing minimal lesion nephrotic syndrome. J Pediatr. 1974;84(6):825-30.  
28. McDonald J, Murphy AV, Arneil GC. Long-term assessment of cyclophosphamide therapy for nephrosis in children. Lancet. 1974;2(7887):980-2.  
29. Durkan A, Hodson EM, Willis NS, Craig JC. Non-corticosteroid treatment for nephrotic syndrome in children. Cochrane Database Syst Rev. 2005;(2):CD002290.  
30. Vester U, Kranz B, Zimmermann S, Hoyer PF. Cyclophosphamide in steroid-sensitive nephrotic syndrome: outcome and outlook. Pediatr Nephrol. 2003;18(7):661-4. 31. Effect of cytotoxic drugs in frequently relapsing nephrotic syndrome with and without steroid dependence. N Engl J Med. 1982;306(8):451-4.  
32. Kyrieleis HA, Levtchenko EN, Wetzels JF. Long-term outcome after cyclophosphamide treatment in children with steroid-dependent and frequently relapsing minimal change nephrotic syndrome. Am J Kidney Dis. 2007;49(5):592-7.  
33. Cyclophosphamide treatment of steroid dependent nephrotic syndrome: comparison of eight week with 12 week course. Report of Arbeitsgemeinschaft für Pädiatrische Nephrologie. Arch Dis Child. 1987;62(11):1102-6.  
34. Ueda N, Kuno K, Ito S. Eight and 12 week courses of cyclophosphamide in nephrotic syndrome. Arch Dis Child. 1990;65(10):1147-50.  
35. Donia AF, Gazareen SH, Ahmed HA, Moustafa FE, Shoeib AA, Ismail AM, et al. Pulse cyclophosphamide inadequately suppresses reoccurrence of minimal change nephrotic syndrome in corticoid-dependent children. Nephrol Dial Transplant. 2003;18(10):2054-8.  
36. Prasad N, Gulati S, Sharma RK, Singh U, Ahmed M. Pulse cyclophosphamide therapy in steroiddependent nephrotic syndrome. Pediatr Nephrol. 2004;19(5):494-8.  
37. Niaudet P. Comparison of cyclosporin and chlorambucil in the treatment of steroid-dependent idiopathic nephrotic syndrome: a multicentre randomized controlled trial. The French Society of Paediatric Nephrology. Pediatr Nephrol. 1992;6(1):1-3.  
38. Niaudet P, Habib R. Cyclosporine in the treatment of idiopathic nephrosis. J Am Soc Nephrol. 1994;5(4):1049-56.  
39. Niaudet P, Broyer M, Habib R. Treatment of idiopathic nephrotic syndrome with cyclosporin A in children. Clin Nephrol. 1991;35 Suppl 1:S31-6.  
40. Tejani AT, Butt K, Trachtman H, Suthanthiran M, Rosenthal CJ, Khawar MR. Cyclosporine A induced remission of relapsing nephrotic syndrome in children. Kidney Int. 1988;33(3):729-34.  
41. Kano K, Kyo K, Yamada Y, Ito S, Ando T, Arisaka O. Comparison between pre- and posttreatment clinical and renal biopsies in children receiving low dose cyclosporine-A for 2 years for steroid-dependent nephrotic syndrome. Clin Nephrol. 1999;52(1):19-24.  
42. Mahmoud I, Basuni F, Sabry A, El-Husseini A, Hassan N, Ahmad NS, et al. Single-centre experience with cyclosporin in 106 children with idiopathic focal segmental glomerulosclerosis. Nephrol Dial Transplant. 2005;20(4):735-42.  
43. Habib R, Niaudet P. Comparison between pretreatment and posttreatment renal biopsies in children receiving cyclosporine for idiopathic nephrosis. Clin Nephrol. 1994;42(3):141-6.  
44. Hirano T, Kawamura T, Fukuda S, Kohsaka S, Yoshikawa N, Yoshida M et al. Implication of cholesterol in cyclosporine pharmacodynamics in minimal change nephrotic syndrome. Clin Pharmacol Ther. 2003;74(6):581-90.  
45. Ingulli E, Tejani A. Severe hypercholesterolemia inhibits cyclosporin A efficacy in a dose-dependent manner in children with nephrotic syndrome. J Am Soc Nephrol. 1992;3(2):254-9.  
46. Ishikura K, Ikeda M, Hattori S, Yoshikawa N, Sasaki S, Iijima K, et al. Effective and safe treatment with cyclosporine in nephrotic children: a prospective, randomized multicenter trial. Kidney Int. 2008;73(10):1167-73.  
47. Bagga A, Hari P, Moudgil A, Jordan SC. Mycophenolate mofetil and prednisolone therapy in children with steroid-dependent nephrotic syndrome. Am J Kidney Dis. 2003;42(6):1114-20.  
48. Novak I, Frank R, Vento S, Vergara M, Gauthier B, Trachtman H. Efficacy of mycophenolate mofetil in pediatric patients with steroid-dependent nephrotic syndrome. Pediatr Nephrol. 2005;20(9):1265-8.  
49. Hogg RJ, Fitzgibbons L, Bruick J, Bunke M, Ault B, Baqi N, et al. Mycophenolate mofetil in children with frequently relapsing nephrotic syndrome: a report from the Southwest Pediatric Nephrology Study Group. Cin J Am Soc Nephrol. 2006;1(6):1173-8.  
50. Fujinaga S, Ohtomo Y, Umino D, Takemoto M, Shimizu T, Yamashiro Y, et al. A prospective study on the use of mycophenolate mofetil in children with cyclosporine-dependent nephrotic syndrome. Pediatr Nephrol. 2007;22(1):71-6.  
51. Afzal K, Bagga A, Menon S, Hari P, Jordan SC. Treatment with mycophenolate mofetil and prednisolone for steroid-dependent nephrotic syndrome. Pediatr Nephrol. 2007;22(12):2059-65.  
52. Dorresteijn EM, Kist-van Holthe JE, Levtchenko EN, Nauta J, Hop WC, van der Heijden AJ. Mycophenolate mofetil versus cyclosporine for remission maintenance in nephrotic syndrome. Pediatr Nephrol. 2008;23(11):2013-20.  
53. George J. Mycophenolate mofetil in primary glomerular diseases. J Assoc Physicians India. 2011;59:1036.  
54. Gellermann J, Weber L, Pape L, Tönshoff B, Hoyer P, Querfeld U. Mycophenolate mofetil versus cyclosporin A in children with frequently relapsing nephrotic syndrome. J Am Soc Nephrol. 2013 Oct;24(10):1689-97.  
55. Guigonis V, Dallocchio A, Baudouin V, Dehennault M, Hachon-Le Camus C, Afanetti M, et al. Rituximab treatment for severe steroid- or cyclosporine-dependent nephrotic syndrome: a multicentric series of 22 cases. Pediatr Nephrol. 2008;23(8):1269-79.  
56. Gilbert RD, Hulse E, Rigden S. Rituximab therapy for steroid-dependent minimal change nephrotic syndrome. Pediatr Nephrol. 2006;21(11):1698-700.  
57. Kamei K, Ito S, Nozu K, Fujinaga S, Nakayama M, Sako M, et al. Single dose of rituximab for refractory steroid-dependent nephrotic syndrome in children. Pediatr Nephrol. 2009;24(7):1321-8.  
58. Ravani C, Magnasco A, Edefonti A, Murer L, Rossi R, Ghio L, et al. Short term effects of rituximab in children with steroid- and calcineurin-dependent nephrotic syndrome: a randomized controlled trial. Clin J Am Soc Nephrol. 2011;6(6):1308-15.  
59. Iijima K, Sako M, Nozu K, Mori R, Tuchida N, Kamei K, et al. Rituximab for childhood-onset, complicated, frequently relapsing nephrotic syndrome or steroid-dependent nephrotic syndrome: a multicentre, double-blind, randomised, placebo-controlled trial. Lancet. 2014; 384(9950):1273-81.  
60. Zhao Z, Liao G, Li Y, Zhou S, Zou H. The efficacy and safety of rituximab in treating childhood refractory nephrotic syndrome: a meta-analysis. Sci Rep. 2015;5:8219.  
61. Sellier-Leclerc AL, Macher MA, Loirat C, Guérin V, Watier H, Peuchmaur M, et al. Rituximab efficiency in children with steroid-dependent nephrotic syndrome. Pediatr Nephrol. 2010;25(6):1109-15. 62. Haffner D, Fischer DC. Nephrotic syndrome and rituximab: facts and perspectives. Pediatr Nephrol. 2009;24(8):1433-8.  
63. Schulman SL, Kaiser BA, Polinsky MS, Srinivasan R, Baluarte HJ. Predicting the response to cytotoxic therapy for childhood nephrotic syndrome: superiority of response to corticosteroid therapy over histopathologic patterns. J Pediatr. 1988;113(6):996-1001.  
64. Fujinaga S, Hirano D, Nishizaki N, Kamei K, Ito S, Ohtomo Y, et al. Single infusion of rituximab for persistent steroid-dependent minimal-change nephrotic syndrome after long-term cyclosporine. Pediatr Nephrol. 2010;25(3):539-44.  
65. van Husen M, Kemper MJ. New therapies in steroid-sensitive and steroid-resistant idiopathic nephrotic syndrome. Pediatr Nephrol. 2011;26(6):881-92.  
66. Sugiura H, Takei T, Itabashi M, Tsukada M, Moriyama T, Kojima C, et al. Effect of single-dose rituximab on primary glomerular diseases. Nephron Clin Pract. 2011;117(2):c98-105.  
67. Ravan P, Magnasco A, Edefonti A, Murer L, Rossi R, Ghio L, et al. Short-term effects of rituximab in children with steroid- and calcineurin-dependent nephrotic syndrome: a randomized controlled trial. Clin J Am Soc Nephrol. 2011;6(6):1308-15.  
68. Otukesh H, Hoseini R, Rahimzadeh N, Fazel M. Rituximab in the treatment of nephrotic syndrome: a systematic review. Iran J Kidney Dis. 2013;7(4):249-56.  
69. Sinha MD, MacLeod R, Rigby E, Clark AG. Treatment of severe steroid-dependent nephrotic syndrome (SDNS) in children with tacrolimus. Nephrol Dial Transplant. 2006;21(7):1848-54.  
70. Levamisole for corticosteroid-dependent nephrotic syndrome in childhood. British Association for Paediatric Nephrology. Lancet. 1991;337(8757):1555-7.  
71. Tarshish P, Tobin JN, Bernstein J, Edelmann CM Jr. Cyclophosphamide does not benefit patients with focal segmental glomerulosclerosis. A report of the International Study of Kidney Disease in Children. Pediatr Nephrol. 1996;10(5):590-3.  
72. Geary DF, Farine M, Thorner P, Baumal R. Response to cyclophosphamide in steroid-resistant focal segmental glomerulosclerosis: a reappraisal. Clin Nephrol. 1984;22(3):109-13.  
73. Niaudet P. Treatment of childhood steroid-resistant idiopathic nephrosis with a combination of cyclosporine and prednisone. French Society of Pediatric Nephrology. J Pediatr. 1994;125(6 Pt 1):981-6.  
74. Gregory MJ, Smoyer WE, Sedman A, Kershaw DB, Valentini RP, Johnson K, et al. Long-term cyclosporine therapy for pediatric nephrotic syndrome: a clinical and histologic analysis. J Am Soc Nephrol. 1996;7(4):543-9.  
75. Ponticelli C, Edefonti A, Ghio L, Rizzoni G, Rinaldi S, Gusmano R, et al. Cyclosporin versus cyclophosphamide for patients with steroid-dependent and frequently relapsing idiopathic nephrotic syndrome: a multicentre randomized controlled trial. Nephrol Dial Transplant. 1993;8(12):1326-32. 76. Lieberman KV, Tejani A. A randomized double-blind placebo-controlled trial of cyclosporine in steroidresistant focal segmental glomerulosclerosisin children. J Am Soc Nephrol. 1996;7(1):56-63.  
77. Ingulli E, Singh A, Baqi N, Ahmad H, Moazami S, Tejani A. Aggressive, long-term cyclosporine therapy for steroid-resistant focal segmental glomerulosclerosis. J Am Soc Nephrol. 1995;5(10):1820-5.  
78. Chishti AS, Sorof JM, Brewer ED, Kale AS. Long-term treatment of focal segmental glomerulosclerosis in children with cyclosporine given as a single daily dose. Am J Kidney Dis. 2001;38(4):754-60.  
79. Plank C, Kalb V, Hinkes B, Hildebrandt F, Gefeller O, Rascher W. Cyclosporin A is superior to cyclophosphamide in children with steroid-resistant nephrotic syndrome-a randomized controlled multicentre trial by the Arbeitsgemeinschaft für Pädiatrische Nephrologie. Pediatr Nephrol. 2008;23(9):1483-93.  
80. Ehrich JH, Geerlings C, Zivicnjak M, Franke D, Geerlings H, Gellermann J. Steroid-resistant idiopathic childhood nephrosis: overdiagnosed and undertreated. Nephrol Dial Transplant. 2007;22(8):2183-93.  
81. Loeffler K, Gowrishankar M, Yiu V. Tacrolimus therapy in pediatric patients with treatment-resistant nephrotic syndrome. Pediatr Nephrol. 2004;19(3):281-7.  
82. Bhimma R, Adhikari M, Asharam K, Connolly C. Management of steroid-resistant focal segmental glomerulosclerosis in children using tacrolimus. Am J Nephrol. 2006;26(6):544-51.  
83. Gulati S, Prasad N, Sharma RK, Kumar A, Gupta A, Baburaj VP. Tacrolimus: a new therapy for steroidresistant nephrotic syndrome in children. Nephrol Dial Transplant. 2008;23(3):910-3.  
84. Choudhry S, Bagga A, Hari P, Sharma S, Kalaivani M, Dinda A. Efficacy and safety of tacrolimus versus cyclosporine in children with steroid-resistant nephrotic syndrome: a randomized controlled trial. Am J Kidney Dis. 2009;53(5):760-9.  
85. Mendizábal S, Zamora I, Berbel O, Sanahuja MJ, Fuentes J, Simon J. Mycophenolate mofetil in steroid/cyclosporine-dependent/resistant nephrotic syndrome. Pediatr Nephrol. 2005;20(7):914-9.  
86. Cattran DC, Wang MM, Appel G, Matalon A, Briggs W. Mycophenolate mofetil in the treatment of focal segmental glomerulosclerosis. Clin Nephrol. 2004;62(6):405-11.  
87. Benz K, Dötsch J, Rascher W, Stachel D. Change of the course of steroid-dependent nephrotic syndrome after rituximab therapy. Pediatr Nephrol. 2004;19(7):794-7  
88. Nakayama M, Kamei K, Nozu K, Matsuoka K, Nakagawa A, Sako M, et al. Rituximab for refractory focal segmental glomerulosclerosis. Pediatr Nephrol. 2008;23(3):481-5.  
89. Bagga A, Sinha A, Moudgil A. Rituximab in patients with the steroid-resistant nephrotic syndrome. N Engl J Med. 2007;356(26):2751-2.  
90. Magnasco A, Ravani P, Edefonti A, Murer L, Ghio L, Belingheri M. Rituximab in children with resistant idiopathic nephrotic syndrome. J Am Soc Nephrol. 2012;23(6):1117-24.  
91. Kurkus J, Thysell H. Reduction of albuminuria after angiotensin converting enzyme inhibition in various renal disorders. Scand J Urol Nephrol. 1990;24(1):63-8.  
92. Ellis D, Vats A, Moritz ML, Reitz S, Grosso MJ, Janosky JE. Long-term antiproteinuric and renoprotective efficacy and safety of losartan in children with proteinuria. J Pediatr. 2003;143:89-97.  
93. Bagga A, Mudigoudar BD, Hari P, Vasudev V. Enalapril dosage in steroid-resistant nephrotic syndrome. Pediatr Nephrol. 2004;19:45-50.  
94. Wilkes JC, Nelson JD, Worthen HG, Morris M, Hogg RJ. Response to pneumococcal vaccination in children with nephrotic syndrome. Am J Kidney Dis. 1982;2(1):43-6.  
95. Harris RC, Ismail N. Extrarenal complications of the nephrotic syndrome. Am J Kidney Dis. 1994;23(4):477-97.  
96. Krensky AM, Ingelfinger JR, Grupe WE. Peritonitis in childhood nephrotic syndrome: 1970-1980. Am J Dis Child. 1982;136(8):732-6.  
97. Haws RM, Baum M. Efficacy of albumin and diuretic therapy in children with nephritic syndrome. Pediatrics. 1993;91(6):1142-6.  
98. McPherson R, Tsoukas C, Baines MG, Vost A, Melino MR, Zupkis RV, et al. Effects of lovastatin on natural killer cell function and other immunological parameters in man. J Clin Immunol. 1993;13(6):439-44.  
99. Gregory MJ, Smoyer WE, Sedman A, Kershaw DB, Valentini RP, Johnson K, et al. Long-term cyclosporine therapy for pediatric nephrotic syndrome: a clinical and histologic analysis. J Am Soc Nephrol. 1996;7(4):543-9.  
100. Webb NJ, Lam C, Loeys T, Shainfar S, Strehlau J, Wells TG, et al. Randomized, double-blind, controlled study of losartan in children with proteinuria. Clin J Am Soc Nephrol. 2010;5(3):417-24. 101. Hyams JS, Carey DE. Corticosteroids and growth. J Pediatr. 1988;113(2):249-54.  
102. Polito C, Oporto MR, Totino SF, La Manna A, Di Toro R. Normal growth of nephrotic children during long-term alternaté-day prednisone therapy. Acta Paediatr Scand. 1986;75(2):245-50.  
103. Fleisher DS, McCrory WW, Rapoport M. The effects of intermittent doses of adrenocortical steroids on the statural growth of nephrotic children. J Pediatr. 1960;57:192-8.  
104. Brocklebank JT, Harcourt RB, Meadow SR. Corticosteroid-induced cataracts in idiopathic nephrotic syndrome. Arch Dis Child. 1982;57(1):30-4.  
105. Ng JS, Wong W, Law RW, Hui J, Wong EN, Lam DS. Ocular complications of paediatric patients with nephrotic syndrome. Clin Exp Ophthalmol. 2001;29(4):239-43.  
106. Fakhouri F, Bocquet N, Taupin P, Presne C, Gagnadoux MF, Landais P, et al. Steroid-sensitive nephrotic syndrome: from childhood to adulthood. Am J Kidney Dis. 2003;41(3):550-7.  
107. Abeyagunawardena AS, Hindmarsh P, Trompeter RS. Adrenocortical suppression increases the risk of relapse in nephrotic syndrome. Arch Dis Child. 2007;92(7):585-8.  
108. Montané B, Abitbol C, Chandar J, Strauss J, Zilleruelo G. Novel therapy of focal glomerulosclerosis with mycophenolate and angiotensin blockade. Pediatr Nephrol. 2003;18(8):772-7.  
109. Hogg RJ, Portman RJ, Milliner D, Lemley KV, Eddy A, Ingelfinger J. Evaluation and manangement of proteinúria abd nephritic syndrome in children recommendations from a pediatric nephrology panel established at the National Kidney Foundation conference on proteinúria, albuminuria, risk assessment, detection and elimination (PARADE). Pediatrics. 2000;105(6):1242-9.  
110. Müller W, Brandis M. Acute leukemia after cytotoxic treatment for nonmalignant disease in childhood. A case report and review of the literature. Eur J Pediatr. 1981;136(1):105-8.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
CICLOFOSFAMIDA, CICLOSPORINA, ENALAPARIL, LOSARTANA, METILPREDNISOLONA, PREDNISONA E TACROLIMO.  
Eu, _______________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **ciclofosfamida, ciclosporina, enalapril, losartana, metilprednisolona, prednisona  e tacrolimo,** indicados para o tratamento da **síndrome nefrótica primária em crianças e adolescentes** .  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo médico ______________________________________________  (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber pode(m) trazer as seguintes melhoras:  
- melhora dos sintomas e sinais do “estado nefrótico”;  
- diminuição da quantidade de proteínas na urina;  
- prevenção da insuficiência renal aguda e da insuficiência renal crônica progressiva.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso destes medicamentos:  
- ciclosporina e tacrolimo: medicamentos classificados na gestação como fator de risco C (estudos em animais mostraram anormalidades nos descendentes, porém não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos);  
- ciclofosfamida: medicamento classificado na gestação como fator de risco X (seu uso é contraindicado para gestantes ou para mulheres planejando engravidar);  
- enalapril e losartana: medicamentos classificados na gestação como categoria D quando utilizados no terceiro trimestre de gestação ou próximo ao parto (há evidências de risco ao feto, mas um benefício potencial pode ser maior do que os riscos);  
- prednisona: medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- efeitos adversos mais comuns da ciclofosfamida: náusea, vômitos, queda de cabelo, risco aumentado de infecções, anemia, toxicidade para medula óssea, infecções na bexiga, risco de sangramento (redução do número de plaquetas), risco de infertilidade;  
- efeitos adversos mais comuns da ciclosporina: problemas nos rins e no fígado, tremores, aumento da quantidade de pelos no corpo, pressão alta, crescimento da gengiva, aumento dos níveis de colesterol e triglicerídeos, formigamentos, dor no peito, batimentos rápidos do coração, convulsões, confusão, ansiedade, depressão, fraqueza, dores de cabeça, unhas e cabelos quebradiços, coceira, espinhas, náusea, vômitos, perda de apetite, soluços, inflamação na boca, dificuldade para engolir, sangramentos, inflamação do pâncreas, prisão de ventre, desconforto abdominal, diminuição das células brancas do sangue, linfoma, calorões, aumento da quantidade de cálcio, magnésio e ácido úrico no sangue, toxicidade para os músculos, problemas respiratórios, sensibilidade aumentada à temperatura e aumento das mamas;  
- efeitos adversos mais comuns do enalapril: tontura, dor de cabeça, cansaço, fraqueza, queda de pressão, desmaio, náusea, diarreia, cãibras musculares, alterações na pele e tosse;  
- efeitos adversos mais comuns da losartana: tontura, cansaço, atordoamento, alterações na pele, urticária, alteração de paladar, vômitos, aumento da sensibilidade da pele ao sol;  
- efeitos adversos da metiprednisolona: retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, e manifestação de diabete mélito;  
- efeitos adversos da prednisona - alterações nos ossos e músculos: fraqueza, perda de massa muscular, osteoporose, além de ruptura do tendão, lesões de ossos longos e vértebras e piora dos sintomas de miastenia gravis; alterações hidroeletrolíticas: inchaço, aumento da pressão arterial; alterações no estômago e intestino: sangramento; alterações na pele: demora em cicatrizar machucados, suor em excesso, petéquias e equimoses, urticária e até dermatite alérgica; alterações no sistema nervoso: convulsões, tontura; dor de cabeça; alterações nas glândulas: irregularidades menstruais,  manifestação de diabete mélito; alterações nos  
olhos: catarata, aumento da pressão dentro dos olhos; alterações psiquiátricas: alterações do humor; depressão e dificuldade para dormir;  
- efeitos adversos mais comuns do tacrolimo: tremores, dor de cabeça, diarreia, pressão alta, náusea, disfunção renal, dor no peito, pressão baixa, palpitações, formigamentos, falta de ar, amarelão, diarreia, prisão de ventre, vômitos, diminuição do apetite, azia, dor no estômago, gases, hemorragia, dano hepático, agitação, ansiedade, convulsão, depressão, tontura, alucinações, incoordenação motora, psicose, sonolência, neuropatia, queda de cabelo, aumento da quantidade de pelos no corpo, vermelhidão de pele, coceiras, anemia, aumento ou diminuição das células brancas do sangue, diminuição das plaquetas do sangue, desordens na coagulação, síndrome hemolítico-urêmica, edema periférico, alterações metabólicas (hipo ou hiperpotassemia, hiperglicemia, hipomagnesemia, hiperuricemia), diabete mélito, elevação de enzimas hepáticas, toxicidade renal, diminuição relevante do volume da urina, febre, acúmulo de líquido no abdômen e na pleura, fraqueza, dor lombar, osteoporose, dores no corpo, peritonite, fotossensibilidade, alterações visuais;  
- contraindicados em casos de hipersensibilidade (alergia) aos medicamentos;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que o(s) medicamento(s) somente pode(m) ser utilizado(s) por mim, comprometendome a devolvê-lo(s) caso não queira ou não possa utilizá-lo(s) ou se o tratamento for interrompido. Sei também que continuarei ser atendido(a), inclusive em caso de desistir de usar o(s) medicamento(s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.    (    ) Sim (    ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (    ) ciclofosfamida  
- (    ) ciclosporina  
- (    ) enalapril  
- (    ) losartana  
- (    ) metilprednisolona  
- (    ) prednisona.  
- (    ) tacrolimo  
|Local:                                                             Data:|
|---|
|Nome dopaciente:|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|  
||Assinatura dopaciente ou do responsáve|l legal||
|---|---|---|---|
|Médico responsável:||CRM:|UF:|
||Assinatura e carimbo do médico|||
||Data:|||  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A administração intravenosa de metilprednisolona é contemplada pelo procedimento 0303020016 - PULSOTERAPIA I (POR APLICAÇÃO), da Tabela de Procedimentos, Medicamentos e OPM do SUS.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **1) LEVANTAMENTO DE INFORMAÇÕES PARA PLANEJAMENTO DA REUNIÃO COM OS ESPECIALISTAS** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME), sítio eletrônico da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e Sistema de Gerenciamento da Tabela de Procedimentos, Medicamentos e OPM do SUS (SIGTAP) para identificação das tecnologias disponíveis e tecnologias demandadas ou recentemente incorporadas e o Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Ministério da Saúde (MS) vigente para a síndrome nefrótica primária em crianças e adolescentes.  
A partir das consultas realizadas foi possível identificar:  
- O tratamento no SUS segue o orientado no PCDT da Síndrome Nefrótica Primária em Crianças e Adolescentes, conforme a Portaria SAS/MS nº 459, de 21 de maio de 2012, e os medicamentos atualmente disponíveis são: prednisona, metilprednisolona, ciclosporina, ciclofosfamida, tacrolimo, enalapril e losartana.  
- Não há solicitação de nenhuma nova tecnologia na CONITEC.  
Na enquete pública realizada pelo Ministério da Saúde sobre os PCDT foram identificados os seguintes aspectos a serem considerados na atualização do PCDT:  
- Obrigatoriedade de realização de biópsia renal e  
- escalonamento de medicamentos.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **2) REUNIÃO COM ESPECIALISTAS:** -->
Em 08/07/2016, às 8h na sala da COMEX - HCPA (Comissão de medicamentos excepcionais e de fontes limitadas - Hospital de Clínicas de Porto Alegre), foi realizada reunião de escopo com as consultoras especialistas e metodologistas do comitê elaborador dos PCDT, na qual foram apresentados os resultados do levantamento de informações realizados pelos metodologistas.

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **3) BUSCAS NA LITERATURA PARA ATUALIZAÇÃO DO PCDT:** -->
A fim de guiar a revisão do PCDT vigente foi realizada busca na literatura sobre intervenções terapêuticas baseadas em evidências definidas pela seguinte pergunta PICO (Quadro 1):

---

<!-- METADADOS: doenca: Síndrome Nefrótica Primária em Crianças e Adolescentes | secao: **<u>Quadro 1 -</u>** Pergunta PICO -->
|População|Crianças e adolescentes com síndrome nefróticaprimária|
|---|---|
|Intervenção|Tratamento clínico|
|Comparação|Sem restrição de comparadores|
|Desfechos|Segurança e eficácia|
|Tipos de estudos|Meta-análises e revisões sistemáticas|  
As estratégias de busca foram utilizadas, buscando artigos publicados nos últimos cinco anos, considerando que a versão do Protocolo atual fora publicada em 2012, estão descritas no Quadro 2.  
**Quadro 2** - Buscas sobre intervenções terapêuticas - Revisões sistemáticas e meta-análises  
|**Base**|**Estratégia**|**Localizado**<br>**s**|**Selecionados**|
|---|---|---|---|
|MEDLIN<br>E<br>(via<br>PubMed)<br>Data da<br>busca:<br>04/04/201<br>7|"Nephrotic<br>Syndrome"[Mesh]<br>AND<br>((Meta-Analysis[ptyp]<br>OR<br>systematic[sb])<br>AND<br>"2012/04/06"[PDat]<br>:<br>"2017/04/04"[PDat]<br>AND<br>("infant"[MeSH Terms] OR<br>"child"[MeSH Terms] OR<br>"adolescent"[MeSH<br>Terms]))|21|2<br>**Motivo das exclusões:**<br>- Artigos localizados na busca Cochrane:<br>6<br>-_Guidelines_: 6<br>- Revisões simples/estudos retrospectivos:<br>4<br>- Artigos em chinês/italiano: 2<br>- Artigo que não respondia à pergunta<br>PICO: 1|
|Embase|'nephrotic syndrome'/exp or<br>'nephrotic syndrome' and<br>([systematic review]/lim or<br>[meta<br>analysis]/lim)<br>and<br>([infant]/lim or [child]/lim<br>or<br>[preschool]/lim<br>or<br>[school]/lim<br>or<br>[adolescent]/lim) and [2012-<br>2016]/py|22|1<br>**Motivo das exclusões:**<br>- Artigos que não respondiam à pergunta<br>PICO: 11<br>- Artigos sem dados relevantes ao<br>Protocolo: 5<br>- Artigos duplicados ou republicados: 3<br>- Medicamento sem registros no Brasil: 2|
|Cochrane<br>Library|"MeSH<br>descriptor:<br>[Nephrotic<br>Syndrome]<br>explode<br>all<br>trees<br>in<br>Cochrane Reviews"|9|1<br>**Motivo das exclusões:**<br>- Artigos sobre as complicações da<br>doença: 5<br>- Artigo que não respondia à pergunta<br>PICO: 1<br>- Artigo em adultos: 1<br>- Medicamento sem registros no Brasil: 1|  
A fim de guiar a revisão do PCDT vigente, foi realizada busca na literatura sobre diagnóstico nos consensos e _guidelines_ internacionais. O Quadro 3 apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**Quadro 3** - Busca por consensos e _<u>guidelines internacionais</u>_ sobre diagnóstico  
|**Base**|**Estratégia**|**Localizado**<br>**s**|**Selecionados**|
|---|---|---|---|
|Medline|"Nephrotic Syndrome/diagnosis"[Mesh] AND|2|0|
|(via|((Practice Guideline[ptyp] OR Guideline[ptyp]||**Motivo das**|
|PubMed)|OR Government Publications[ptyp] OR||**exclusões:**|  
|Data da<br>busca:<br>24/04/2017|Consensus Development Conference,<br>NIH[ptyp] OR Consensus Development<br>Conference[ptyp]) AND "2012/04/26"[PDat] :<br>"2017/04/24"[PDat] AND "humans"[MeSH<br>Terms] AND ("infant"[MeSH Terms] OR<br>"child"[MeSH Terms] OR "adolescent"[MeSH<br>Terms]))||**-**Dois protocolos<br>que não avaliaram<br>diagnóstico.|
|---|---|---|---|
|National<br>Guideline<br>Clearingho<br>use|www.guideline.gov/search?q=Nephrotic+Syndr<br>ome&f_Age_of_Target_Population=Adolescen<br>t+(13+to+18+years)%3bChild+(2+to+12+years<br>)&page=1|2|0<br>**Motivo das**<br>**exclusões:**<br>**-**Dois protocolos já<br>citados.|  
Para informações adicionais de dados nacionais sobre a doença, também foi realizada uma busca, conforme o Quadro 4, que apresenta as estratégias de buscas realizadas, bem como o número de artigos localizados e o número de selecionados.  
**Quadro 4** - Busca por dados nacionais sobre a doença  
|**Base**|**Estratégia**|**Localizado**<br>**s**|**Selecionados**|
|---|---|---|---|
|MEDLINE<br>(via<br>PubMed)<br>Data da<br>busca:<br>24/04/2017|"Nephrotic Syndrome"[Mesh] AND<br>"Brazil"[Mesh] AND ("2012/04/26"[PDat] :<br>"2017/04/24"[PDat] AND "humans"[MeSH<br>Terms] AND ("infant"[MeSH Terms] OR<br>"child"[MeSH Terms] OR "adolescent"[MeSH<br>Terms]))|3|0<br>**Motivo das**<br>**exclusões:**<br>- Uma série de caso;<br>- um artigo sobre<br>mutações;<br>- um artigo sobre<br>nefropatia<br>membranosa em<br>japoneses.|  
Foram também utilizados como referência a base de dados _UpToDate_ , versão 25.1, livros texto de medicina, 4 meta-análises/revisões sistemáticas e 6 referências de conhecimento dos autores. Considerando a versão anterior do PCDT, 100 referências foram mantidas e 10 acrescentadas.

---

