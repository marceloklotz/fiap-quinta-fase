<!-- METADADOS: doenca: Ictioses Hereditárias | secao: Geral -->
<!-- Start of picture text -->
oa<br>Ris”<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 12, DE 13 DE JUNHO DE 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Ictioses Hereditárias.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre as Ictioses Hereditárias no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com estas doenças;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 636/2021 e o Relatório de Recomendação nº 641 - junho de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Ictioses Hereditárias.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral das Ictioses Hereditárias, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter</u> nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento das Ictioses Hereditárias.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essas doenças em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SCTIE/MS nº 12, de 27 de julho de 2021, publicada no Diário Oficial da União nº 146, de 04 de agosto de 2021, seção 1, páginas 169.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **1. INTRODUÇÃO** -->
As Ictioses Hereditárias e doenças correlatas são doenças genéticas causadas pela presença de variantes patogênicas em diversos genes envolvidos no processo de queratinização ou corneificação da epiderme. Este processo corresponde à diferenciação das células da epiderme a partir da camada mais profunda, denominada camada basal, até a camada mais externa, formada por células córneas ou lamelares<sup>1</sup> . As Ictioses adquiridas, por sua vez, são aquelas secundárias a neoplasias e a doenças autoimunes, inflamatórias e infecciosas, entre outras<sup>2</sup> .  
A classificação das diferentes formas de Ictiose é feita de acordo com o quadro clínico do indivíduo<sup>3</sup> . Existem, atualmente, 36 tipos de Ictioses, as quais podem ser divididas em subgrupos, de acordo com a presença de manifestações extracutâneas, a frequência da doença e o padrão de herança<sup>4</sup> . O exame histopatológico e a avaliação do modo de herança e da variante gênica podem ser necessários para um diagnóstico preciso<sup>3</sup> .  
As Ictioses Hereditárias e adquiridas não são doenças infecto-contagiosas<sup>1</sup> . Em geral, as formas com acometimento exclusivo da pele são chamadas Ictioses não sindrômicas. Quando o estado ictiosiforme se associa a malformações e manifestações em outros órgãos, são chamadas de Ictioses sindrômicas<sup>2,5</sup> . Quando presentes desde o nascimento, são chamadas Ictioses congênitas (Ictiose lamelar e Ictiose arlequim, entre outras). Em outros casos, a doença pode se desenvolver durante a infância (Ictiose vulgar e Ictiose queratinopática, entre outras). Em ambas as situações, a condição persiste durante toda a vida, o que pode representar enorme impacto na qualidade de vida dos indivíduos<sup>5–7</sup> .  
As Ictioses Hereditárias apresentam grande variabilidade clínica, com diferentes frequências na população. A Ictiose vulgar é a forma mais comum, com uma incidência de até 1:100. Já a Ictiose ligada ao cromossomo X tem frequência estimada de 1:2.000 – 4.000. As demais variantes, em geral, são raras, com uma incidência estimada de 1:100.000 – 500.000, como é o caso das Ictioses congênitas autossômicas recessivas (1:100.000)<sup>3,8</sup> .  
As Ictioses Hereditárias têm impactos significativos em diferentes setores da vida dos doentes e de suas famílias, lhes exigem cuidados extensivos e que consomem bastante tempo<sup>6,7</sup> . Além dos impactos funcionais (dificuldade de regulação térmica, perdas calóricas e alterações de mobilidade, entre outras), há aspectos emocionais e sociais associados à doença. Existem relatos de que crianças com Ictioses Hereditárias podem ser vítimas de discriminação e _bullying_ , resultando-lhes em prejuízos adicionais à interação social. Quando adultos, os pacientes podem manter dificuldade de relacionamento com vizinhos, colegas ou até mesmo parentes. Por vezes, ter o diagnóstico da doença pode afetar diretamente algumas decisões relacionadas a questões ocupacionais ou pessoais, como ter ou não filhos<sup>6</sup> . O indivíduo com Ictiose deve ser orientado, estimulado e apoiado na participação em atividades sociais<sup>1</sup> .  
Embora as Ictioses Hereditárias sejam raras em sua maioria, o impacto negativo em diferentes aspectos da qualidade vida de pacientes e de suas famílias as tornam um grave problema de saúde. Ademais, a heterogeneidade clínica pode resultar em dificuldade de diagnóstico preciso e tratamento adequado<sup>3</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa estabelecer os critérios diagnósticos e terapêuticos das Ictioses Hereditárias. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID 10)** -->
- Q80.0 Ictiose vulgar  
- Q80.1 Ictiose ligada ao cromossomo X  
- Q80.2 Ictiose lamelar  
- Q80.3 Eritrodermia ictiosiforme bolhosa congênita  
- Q80.8 Outras ictioses congênitas  
- Q80.9 Ictiose congênita não especificada

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3. CLASSIFICAÇÃO DAS ICTIOSES** -->
A seguir, são descritas as Ictioses Hereditárias não sindrômicas e sindrômicas, considerando seu padrão de herança, principais genes envolvidos e principais manifestações clínicas.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1      Ictioses não sindrômicas** -->
Uma vez que as manifestações clínicas das Ictioses Hereditárias se sobrepõem nas diferentes classificações da doença, uma nova nomenclatura simplificada foi adotada, englobando as diferentes variantes, agrupadas majoritariamente pelo padrão de herança que essas doenças apresentam<sup>1,2,5</sup> . A classificação de Ictiose não sindrômica com a nomenclatura atual, modo de herança, genes envolvidos e função do produto dos genes encontram-se no **Quadro 1.**  
**Quadro 1 -** Classificação atual das Ictioses não sindrômicas, padrão de herança, genes envolvidos e produto do gene.  
|**Ictiose**|**Padrão**<br>**Herança**|**de**|**Gene**|**Proteína codificada**|**Principais manifestações clínicas**|
|---|---|---|---|---|---|
|Ictiose vulgar|SD||_FLG_|Filagrina.|Presença de xerose, descamação, prurido<br>e<br>eritema.<br>Frequentemente<br>associada<br>a<br>manifestações de atopia.|
|Ictiose ligada ao X<br>recessiva|LXR||_STS_|Esteroide<br>sulfatase<br>(enzima do metabolismo<br>lipídico da pele).|Alterações cutâneas simétricas nas<br>extremidades, tronco e região cervical.<br>Presença de escamas largas, achatadas,<br>poligonais e escuras.|
||||_TGM1_<br>_ALOXE3_||Apresentam<br>grande<br>variabilidade<br>fenotípica, agrupada em quatro grupos:|
|Ictioses<br>congênitas<br>autossômicas<br>recessivas|AR||_ALOX12B_<br>_NIPAL4_<br>_ST14_<br>_CYP4F22_<br>_ABCA12_<br>_CERS3_<br>_SDR9C7_<br>_PNPLA1_<br>_LIPN_|Enzimas do metabolismo<br>lipídico<br>da<br>pele<br>(proteases).|Ictiose<br>lamelar:<br>descamação<br>generalizada da pele, com escamas<br>espessas e achatadas. Pode ocorrer<br>ectrópio<br>e<br>eclábio.<br>Eritrodermia ictiosiforme congênita não<br>bolhosa: Pode se manifestar desde o<br>nascimento como bebê colódio ou pela<br>presença de eritema nos primeiros meses<br>de<br>vida.|
||||_CASP14_||Ictiose arlequim: Pele recoberta por|  
|**Ictiose**|**Padrão**<br>**de**<br>**Herança**|**Gene**|**Proteína codificada**|**Principais manifestações clínicas**|
|---|---|---|---|---|
|||_SULT2B1_<br>_SLC27A4/FATP_<br>_4_||placa espessa e lisa, que sofre fissuras<br>com padrão losângico; eritema intenso e<br>forte descamação; intolerância ao calor.<br>Ictiose pleomórfica: descamação da pele<br>que sofre influência de condições<br>ambientais.|
|Ictioses<br>queratinopáticas|AD|KRT2<br>KRT10<br>KRT1|Queratina<br>2<br>Queratina<br>1<br>(citoesqueleto)|Presença de eritema e lesões bolhosas ou<br>verrucosas de modo localizado ou<br>generalizado; pele espessa, com escamas<br>escuras.|
|Eritroqueratodermia<br>s|AD|_GJB3_<br>_GJB4_<br>_CARD14_|Proteínas<br>dos<br>queratinócitos|Associação de placas hiperqueratóticas<br>com áreas circunscritas de eritema|
||AR|_GJB3_<br>_NIPAL4_<br>_KDSR_|Proteínas<br>dos<br>queratinócitos|migratório ou fixo.|
|Síndrome da pele<br>decídua|AR|_CDSN_|Proteases, inibidores de<br>proteases e enzimas do<br>metabolismo lipídico.|Descamação superficial periódica e não<br>dolorosa da pele; pode ser restrita às<br>extremidades ou generalizada.|  
**Legenda:** AD = autossômica dominante; AR = autossômica recessiva; LXR= ligada ao X recessiva. Baseado em Rivitti-Machado & Oliveira (2018)<sup>1</sup> ; Mazereeuw-Hautier J et al. (2019)<sup>5</sup> ; Oji, et al. (2017)<sup>9</sup> ; Fischer & Bourrat (2020)<sup>10</sup> ; Aliazami, et al. (2020)<sup>11</sup> ; Chaferddini, et al. (2021)<sup>12</sup> ;  Pilz, et al. (2022)<sup>13</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.1   Ictiose Vulgar** -->
A Ictiose Vulgar recebe essa denominação por ser a forma mais frequente de Ictiose, podendo ser hereditária ou estar associada a outras doenças. No primeiro caso, tem padrão de herança autossômica dominante com penetrância incompleta e expressão variável entre as famílias<sup>1,9</sup> . Tipicamente, escamas muito finas, achatadas e poligonais são evidentes nas superfícies extensoras das extremidades. As dobras do corpo tendem a ser poupadas e a descamação da pele geralmente não é perceptível ao nascimento ou nos primeiros meses de vida. O quadro costuma se iniciar na primeira infância (entre 3 e 12 meses), podendo se agravar em clima seco. O exame histopatológico mostra diminuição da camada granulosa<sup>1</sup> .  
A Ictiose Vulgar está frequentemente associada a manifestações de atopia: asma, rinite alérgica e dermatite atópica, sendo encontrada em 25% a 50% dos pacientes que apresentam essas comorbidades<sup>14</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.2   Ictiose Ligada ao Cromossomo X** -->
A Ictiose Ligada ao Cromossomo X, ou Ictiose Ligada ao X Recessiva (ILXR), é uma doença que se evidencia quase que exclusivamente em indivíduos do sexo masculino. Essa forma está associada com mutações (deleções em 90% dos casos) no gene da esteroide-sulfatase ou arilsulfatase C (gene _STS_ ). As mulheres afetadas usualmente são heterozigotas para a variante gênica, e as manifestações clínicas costumam ser muito discretas<sup>1,2</sup> .  
Cerca de 90% dos homens com variantes patogênicas no gene envolvido apresentam manifestações da doença algumas semanas após o nascimento. A distribuição das alterações cutâneas nesta doença é simétrica nas extremidades, tronco e região cervical. As escamas são largas, achatadas, poligonais e escuras. Áreas flexurais podem ou não ser afetadas, mas a região cervical é frequentemente acometida. As palmas, plantas e face geralmente são poupadas, com exceção da região pré-auricular com acometimento ocasional, porém muito característico<sup>1</sup> .  
Opacificações assintomáticas da córnea ocorrem em 50% dos pacientes afetados e em 25% das mulheres heterozigotas, surgindo entre os 10 e 30 anos de idade. Os homens acometidos podem apresentar criptorquidia<sup>1</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.3   Ictioses Congênitas Autossômicas Recessivas (ICAR)** -->
Em 1966, foi introduzido o termo Ictiose Lamelar para todas as formas autossômicas recessivas de Ictioses não bolhosas. Posteriormente, este grupo foi dividido em dois distintos fenótipos: Ictiose Lamelar (IL) e Eritrodermia Ictiosiforme Congênita não Bolhosa (EIC). No entanto, existe considerável superposição entre a apresentação clínica dessas duas formas. Já está demonstrado que a mesma mutação pode se relacionar tanto à IL como à EIC e a outras apresentações menos comuns, como Ictiose do Tronco e Ictiose Acral, o que motivou o agrupamento sob o nome Ictioses Congênitas Autossômicas Recessivas (ICAR)<sup>1,2,9</sup> . Nesse grupo também foram agregadas as Ictioses Pleomórficas<sup>1</sup> .  
As ICAR comprometem a pele e são geneticamente heterogêneas, isto é, podem ser causadas por diferentes genes. Quase sempre são transmitidas de modo autossômico recessivo, algumas das quais ainda não têm a base molecular conhecida<sup>5</sup> . Apresentam-se com diferentes fenótipos, agrupados do ponto de vista clínico em quatro grupos: IL, EIC, Ictiose Arlequim e Ictioses Pleomórficas<sup>1</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.3.1. Ictiose Lamelar** -->
A Ictiose Lamelar caracteriza-se por eritema muito discreto e descamação da pele com escamas poligonais espessas, achatadas, aderidas pelo centro e com bordas elevadas, de coloração clara ou acastanhada, acometendo todo o corpo. O acometimento da pele da face leva ao ectrópio e eclábio. O desenvolvimento de queratodermia palmoplantar moderada é constante. Alopecia difusa também pode ser uma manifestação clínica de IL. As unhas são uniformemente espessadas. Em climas quentes ou na ocorrência de febre, há intolerância ao calor, com piora do eritema e descamação<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.3.2. Eritrodermia Ictiosiforme Congênita não Bolhosa** -->
A EIC pode se apresentar desde o nascimento como bebê colódio ou se iniciar somente nos primeiros meses de vida, com eritema de intensidade variável. A descamação da pele é fina, clara e menos evidente na face. Ectrópio não é frequente e, quando presente, é menos pronunciado do que nos doentes de Ictiose Lamelar. Queratodermia palmoplantar de moderada intensidade pode estar presente. Entre as características clínicas da EIC, as unhas geralmente são espessas e curvas<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.3.3. Ictiose Arlequim** -->
Forma mais grave de apresentação das Ictioses, a Ictiose Arlequim foi considerada fatal até o surgimento de novas técnicas de suporte de vida nas unidades de cuidados intensivos neonatais e com o uso de terapia medicamentosa efetiva desde os primeiros dias de vida. É doença extremamente rara, de transmissão autossômica recessiva na maioria das vezes<sup>1,2,9</sup> .  
Após o nascimento, geralmente prematuro, o recém-nato com essa condição apresenta a pele recoberta por placa muito espessada, lisa, brilhante e opaca que sofre fissuras losângicas que lembram a roupa do arlequim. Caracteristicamente, os indivíduos com Ictiose Arlequim desenvolvem, marcadamente, ectrópio e eclábio. Além disso, nesses indivíduos os pavilhões auriculares raramente são visíveis, encobertos pelas placas hiperqueratósicas, sendo frequentemente hipoplásicos. A hipoplasia também pode comprometer os dedos das mãos e pés e a pirâmide nasal.  Nessa condição, as unhas são espessadas, os cabelos  
são rarefeitos e a intolerância ao calor é intensa. Ao longo da vida, a pele apresenta eritema intenso e forte descamação, inclusive nas palmas e plantas dos pés e das mãos<sup>1,2,9</sup> .  
Como consequência precoce da Ictiose Arlequim, a pele espessada dificulta os movimentos e leva a criança a desenvolver uma postura de semiflexão. Aliada à dificuldade de movimentos, incluindo movimentos de sucção prejudicados, a restrição respiratória dificulta a alimentação, o que pode comprometer o crescimento e desenvolvimento infantil<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.3.4. Ictioses Pleomórficas** -->
As Ictioses Pleomórficas compreendem um grupo de ictioses com quadro mais intenso ao nascimento e que melhora com o passar do tempo, sofrendo influência de condições do ambiente como temperatura e umidade. Estão incluídos nesse grupo a ictiose-prematuridade, a ictiose em roupa de banho e a ictiose acral. Nas duas últimas, a denominação indica as regiões em que as escamas da pele são mais evidentes<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.4.  Ictioses Queratinopáticas** -->
As Ictioses Queratinopáticas, antes denominadas eritrodermia ictiosiforme bolhosa congênita de Brocq ou hiperqueratose epidermolítica, é uma doença rara, transmitida por herança autossômica dominante, com casos esporádicos, decorrentes de mutações novas ou espontâneas<sup>1,2,9</sup> .  
Os pacientes com Ictioses Queratinopáticas podem apresentar quadro generalizado ou localizado, sendo de distribuição linear ou em faixas, seguindo as linhas de Blaschko. O quadro é chamado de nevo verrucoso quando acomete pequenas áreas; quando acometem áreas de pele sã e áreas de lesões verrucosas de modo alternado, são denominadas Ictiose Histrix. Esse termo designa lesões presentes em um segmento corporal, um hemicorpo ou todo o corpo. Alguns autores denominam Ictiose Histrix qualquer forma de Ictiose Queratinopática e até mesmo a síndrome KID<sup>1</sup> .  
Nas formas localizadas, ditas nevoides, a mutação está presente somente nas células dos locais acometidos, fenômeno denominado mosaicismo, definido como a coexistência de populações celulares geneticamente distintas em um mesmo indivíduo<sup>1,2,9</sup> .  
Nas formas generalizadas, em uma parcela dos casos, no nascimento ou nos primeiros dias, podem ser notados eritema e bolhas superficiais muito frágeis e fugazes, deixando áreas de exulceração com fundo róseo brilhante, muito semelhante à epidermólise bolhosa<sup>1,2,9</sup> . Ao longo das primeiras semanas de vida, a pele sofre espessamento, assumindo o aspecto típico da doença, com escamas escuras, muito espessas, poliédricas; o eritema subjacente pode ser discreto ou muito intenso. Ocasionalmente as escamas se destacam deixando áreas exulceradas, de fundo eritematoso e brilhante. Em geral, a região central da face é poupada<sup>1</sup> .  
Geralmente, há odor peculiar e intenso, constante, resultante do acúmulo de restos celulares e proliferação bacteriana nas criptas da pele espessada. Parte dos doentes têm queratodermia palmoplantar acentuada, com formação de bolhas que causam dificuldade de locomoção e manipulação de objetos<sup>1</sup> .  
O exame histopatológico da pele é característico, evidenciando degeneração granular, composta por vacuolização das células granulosas e malpighianas altas, com grande quantidade de finos grânulos de querato-hialina dispersos pela camada granulosa vacuolizada. Ocorre hiperqueratose acentuada, papilomatose e acantose<sup>1</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.5.  Eritroqueratodermias** -->
As Eritroqueratodermias caracterizam-se pela associação de placas hiperqueratóticas com áreas circunscritas de eritema, de caráter migratório ou fixo, podendo se associar a queratodermia palmoplantar<sup>1,2,9</sup> .  
Os dois principais fenótipos descritos são a Eritroqueratodermia Variabilis (EKV) e Eritroqueratodermia Simétrica Progressiva (EKSP). Como mutações no mesmo gene podem ser responsáveis tanto pela EKV quanto pela EKSP, e há  
superposição entre os quadros - outra denominação que tem sido empregada é Eritroqueratodermia Variável e Progressiva, incluindo também a Síndrome de Greiter ou Queratodermia Palmoplantar Transgressiva e Progressiva, uma vez que membros da mesma família e portadores da mesma mutação apresentaram quadro correspondente à EKV, EKSP e Greiter<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.1.6.  Síndrome da pele decídua** -->
A Síndrome da pele decídua era denominada “ _peeling skin syndrome_ ”, anteriormente. Doentes com esta rara síndrome de herança autossômica recessiva apresentam descamação superficial periódica e não dolorosa da pele, exacerbada por calor ou umidade. As áreas com descamação apresentam eritema residual e têm resolução em alguns dias. Há formas restritas às extremidades e formas generalizadas, que podem se apresentar apenas com descamação ou com descamação, eritema e prurido intenso na pele. A histologia característica mostra clivagem da epiderme na altura da camada granulosa<sup>1,2,9</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.2.     Bebê colódio** -->
O bebê colódio constitui um fenótipo transitório de apresentação de diferentes distúrbios da queratinização sindrômico e não sindrômicos<sup>1,2,9</sup> . O exame histopatológico revela hiperqueratose e acantose de intensidade variável sendo, portanto, pouco específico<sup>1</sup> . Parte dos casos de ICARS se apresenta ao nascimento como bebê colódio. Nesta condição, a pele apresenta espessamento da camada córnea, formando um envoltório espesso, brilhante, pouco flexível e translúcido, permitindo a visualização do eritema subjacente e responsável pelo ectrópio e eclábio típicos<sup>1</sup> .  
Pode haver ainda hipoplasia da pirâmide nasal, dos pavilhões auriculares ou dos dedos. A função de barreira da pele é deficiente, favorecendo a desidratação, o desequilíbrio hidroeletrolítico, infecções e a absorção aumentada de tópicos, podendo haver intoxicações<sup>1,2</sup> . A pele espessa e pouco flexível sofre fissuras e descamação característica, com escamas largas ao longo das seis as dez primeiras semanas de vida. Após este período, os doentes apresentam as características da forma de ictiose que herdaram, sendo as mais comuns as ICAR. Pode ocorrer de forma isolada e autolimitada, embora outras genodermatoses e erros inatos do metabolismo também possam se apresentar como bebê colódio: a síndrome de Netherton, a tricotiodistrofia, a síndrome de Sjögren-Larsson, a ictiose em confete, a doença de Gaucher e, também, há casos autoinvolutivos<sup>1,2,9</sup> . Pelo risco de estar associado a quadro sindrômico ou apresentarem, na maioria dos casos, padrão de herança autossômica recessivo, recomenda-se que todos os bebês colódios sejam também avaliados por médico geneticista.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3.3.     Ictioses sindrômicas** -->
As Ictioses sindrômicas constituem um grupo raro, com heterogeneidade genética e diversas manifestações clínicas. Em termos de herança, podem apresentar padrão autossômico recessivo, autossômico dominante ou ligado ao X dominante. Ao estado ictiosiforme se associa o acometimento significante do cabelo ou de um ou mais órgãos, como cérebro, esqueleto e  fígado, com consequente comprometimento do desenvolvimento do sistema nervoso central, da estatura e de possíveis disfunções metabólicas, distribuindo-se em diversos quadros sindrômicos, como descrito no **Quadro 2**<sup>5,9,10</sup> . Algumas ictioses sindrômicas de curso fatal, como a Doença de Gaucher tipo II, alguns casos da Síndrome de Netherton, entre outras, corroboram a necessidade do diagnóstico correto, por se tratarem de condições autossômicas recessivas e, portanto, com alto risco de recorrência na prole.  
**Quadro 2 -** Classificação das ictioses sindrômicas, apresentação clínica, padrão de herança e genes envolvidos.  
|**Ictioses sindrômicas**|**Padrão de**<br>**herança**|<br>**Gene**|**Principais manifestações clínicas**|
|---|---|---|---|
|Ictiose folicular-alopecia-fotofobia|LXR|_MBTPS2_|Alopecia, onicodistrofia.|  
|**Ictioses sindrômicas**|**Padrão de**<br>**herança**|**Gene**|**Principais manifestações clínicas**|
|---|---|---|---|
|Forma sindrômica recessiva ligada ao<br>X||STS|Condrodisplasia punctacta, dismorfias.|
|Síndrome de Conradi-Hünermann-||_EBP_|Condrodisplasia punctacta, dismorfias.|
|Happle|||Acomete meninas, letal em meninos.|
||LXD||Déficit de crescimento.|
|CHILD Syndrome||_NSDHL_|Hemidisplasia congênita com eritrodermia<br>ictiosiforme e defeitos de membros.|
|||_SPINK5_||
|Síndrome<br>de<br>Netherton||_ST14_|Anormalidades<br>proeminentes<br>dos|
|<br> <br> <br>Síndrome de Ictiose e Hipotricose|AR|_ERCC2 / XPD_|cabelos, atraso no desenvolvimento,|
|||_ERCC3 / XPB_|déficit de crescimento.|
|||_GTF2H5 / TTDA/ TTDN1_||
|Síndrome de Refsum|AR|_PHYH / PEX7_||
|Síndrome de MEDNIK (do inglês||||
|_Mental_<br>_retardation-enteropathy-_<br>_deafness-neuropathy-ichthyosis-_<br>_keratodermia_, ou retardo mental-<br>enteropatia-surdez-neuropatia-ictiose-<br>keratodermia|AR|_AP1S1_|Anormalidades graves do sistema nervoso|
|Síndrome de CEDNIK (do inglês<br>_cerebral_<br>_dysgnesis-neuropathy-_<br>_ichthyosis-keratodermia palmoplantar_||_SNAP29_|central.|
|ou<br>disgenesia<br>cerebral-neuropatia-<br>ictiose-keratodermia palmoplantar)||||
|Síndrome de CHIME (PIGL-CDG)|AR|_PIGL_||
|Desordens congênita da glicosilação<br>tipos Iq (CDG1Q)|AR|SRD5A3||  
**Legenda:** AR = autossômica recessiva; LXD= ligada ao X dominante; LXR= ligada ao X recessiva. Baseado em Mazereeuw-Hautier J et al. (2019)<sup>5</sup> ; Oji, et al. (2017)<sup>9</sup> ; Fischer & Bourrat (2020)<sup>10</sup> ; Ramphul, et al. (2022)<sup>15</sup> ; Mah-Som, et al. (2021)<sup>16</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **4. DIAGNÓSTICO** -->
O diagnóstico de Ictiose Hereditária baseia-se no quadro clínico cutâneo, caracterizado por eritema, hiperqueratose e descamação<sup>3,17</sup> . O médico com especialização em dermatologia é o especialista mais indicado para proceder ao diagnóstico inicial da doença, diferenciando-a de outras que podem cursar manifestações clínicas características das Ictioses Hereditárias. Havendo manifestações extracutâneas, como déficit de crescimento, alterações em unhas, cabelos, esqueleto e sistema nervoso central, atendimentos por outros especialistas como radiologistas e neurologistas podem ser necessários para diagnóstico mais preciso. Consulta com o médico geneticista, especialmente nas formas de bebê arlequim ou nas apresentações sindrômicas, é fundamental para uma maior precisão diagnóstica e melhor orientação sobre a doença e seu tratamento. Exames laboratoriais complementares, que incluem, mas não se limitam ao exame histopatológico da pele, podem ser necessários, sendo indicados  
caso a caso e sujeitos à disponibilidade. Entre esses exames, encontram-se, por exemplo, a pesquisa por exames de imagens nos quadros possivelmente associados a síndromes malformativas, sendo assim indicada a realização de ultrassonografia transfontanela e abdominal. Tendo em vista a heterogeneidade genética (diversos genes associados) e distintos riscos de recorrência nas formas supracitadas, está indicada a realização de testes genéticos moleculares, sempre que disponíveis<sup>9</sup> . Os testes genéticos específicos encontram-se descritos no **Quadro 2** .  
Em algumas situações, pode ser necessária a solicitação de exames bioquímicos específicos para determinar o tipo de Ictiose Hereditária. Nos casos em que houver suspeita de ictiose ligada ao cromossomo X, recomenda-se a medida da atividade da arilsulfatase C. No caso de bebês colódios, deve ser realizada a medida da atividade da enzima beta-glicosidase, para exclusão do diagnóstico de doença de Gaucher<sup>9</sup> . Sempre que possível, os casos com apresentação clínica de bebê colódio ou Ictiose Arlequim ou com suspeita de formas sindrômicas raras, a exemplo das descritas no **Quadro 2** , devem também ser adequadamente documentados em fotos e avaliados por médico geneticista, para a correta conduta de diagnóstico etiológico e provisão do aconselhamento genético, considerando seus diversos níveis de prevenção – especialmente secundária e terciária. A prevenção primária é a ação tomada para remover causas e fatores de risco de um problema de saúde individual ou populacional antes do desenvolvimento de uma doença, em que, no contexto das ictioses, inclui-se o aconselhamento pré-concepcional para casais ou famílias identificadas como de risco, nos quais já foram identificados indivíduos afetados por alguma forma de ictiose, especialmente as formas mais graves, de alto risco de recorrência na prole ou na família. A prevenção secundária é a ação realizada para detectar um problema de saúde em estágio inicial ou muito precoce, muitas vezes em estágio subclínico, no indivíduo ou na população. Incluem o diagnóstico pré-natal e medidas para mitigar danos, como planejamento do tipo de parto mais adequado para o feto, rastreamento neonatal e interrupção de gestação em formas graves de ictiose, medida última não contemplada pela legislação brasileira. A prevenção terciária é a ação implementada para reduzir em um indivíduo ou população os prejuízos funcionais consequentes de um problema agudo ou crônico, incluindo reabilitação. No caso das ictioses, a prevenção terciária já contempla o conjunto de medidas pós natais para cuidados clínicos (dermatológicos, oftalmológicos) adequados específicos e medidas de reabilitação física e psicológica, reduzindo assim os  danos  ao indivíduo afetado<sup>18</sup> . A prevenção quaternária, por sua vez, procura evitar <mark>intervenções desnecessárias, buscando reduzir os danos aos pacientes por meio de práticas qualificadas, personalizadas e humanizadas de cuidado.</mark>

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com diagnóstico de Ictioses Hereditárias comprovado por laudo médico, emitido preferencialmente por dermatologista.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo pacientes com ictioses adquiridas, que incluem, mas não se limitam, a quadros resultantes de distúrbios endocrinológicos, metabólicos, infecciosos, tumorais e linfoproliferativos e pele seca sazonal. Além disso, intolerância, hipersensibilidade ou contraindicação são critérios de exclusão ao uso do respectivo medicamento preconizado neste Protocolo (ver em 8.7 Interações medicamentosas).

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **7. CASOS ESPECIAIS** -->
Para mulheres em idade fértil (entre 10 e 49 anos)<sup>19</sup> , o uso de acitretina deve ser considerado com cautela e, se optado por iniciar tratamento, preconiza-se o uso de duas formas distintas de contracepção (mecânica e hormonal), iniciadas um mês antes do tratamento e suspensas três anos após o seu término, bem como teste de gravidez negativo antes de cada nova prescrição<sup>20</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8. TRATAMENTO** -->
O tratamento tem por objetivo reduzir os sintomas e melhorar a qualidade de vida do paciente. Objetivamente, o alvo dos tratamentos tópico e sistêmico é reduzir as escamas da pele, que podem ter características diversas e ocorrer em quantidade variáveis a espessura da camada córnea, a inflamação da pele, a falha da barreira cutânea, as infecções secundárias, a obstrução de ductos anexiais e a rigidez da pele e dos anexos cutâneos. Todos esses sinais geram os principais sintomas e complicações apresentados pelos pacientes: xerose ocular ou cutânea, descamação, fissuras e erosões na pele, ceratodermia, eritema, prurido local ou generalizado e dor decorrente das lesões cutâneas, hipo-hidrose e ectrópio<sup>2</sup> .  
O paciente e sua família devem receber, pela equipe multidisciplinar, orientação sobre a natureza da doença e a importância de cuidados tópicos contínuos. Idealmente, psicoterapia de apoio deve ser ofertada. A modalidade, individual ou em grupo, dependerá da indicação e das preferências do paciente. Um acompanhamento multidisciplinar, incluindo geneticistas com vistas a possível aconselhamento genético e consultas com oftalmologistas para prevenção de complicações oculares, são fundamentais. Outros especialistas podem ser consultados, a depender das manifestações clínicas, especialmente nas formas sindrômicas elencadas no **Quadro 2** : na presença de malformações do sistema nervoso central ou acometimento do sistema nervoso, o neurologista deverá ser acionado; quando houver acometimento ocular relevante, o oftalmologista se faz necessário; nos casos de acometimento auditivo, o acompanhamento com otorrinolaringologista; nos casos associados a enteropatia, orientações do gastroenterologista serão necessárias<sup>5</sup> . A depender da gravidade das alterações, podem ser necessárias consultas com cirurgiões plásticos e ortopedistas, para indicação e adoção da conduta adequada.  
A higienização da pele e couro cabeludo deve ser feita com sabões e xampus neutros, reservando-se sabões antissépticos apenas para casos de infecções recorrentes. Quando houver escamas aderentes no couro cabeludo ou em áreas localizadas na pele, podem ser aplicados óleo mineral e vaselina durante o dia ou à noite para facilitar a remoção<sup>5</sup> .  
A hidratação da pele duas vezes ao dia por meio de cremes e loções emolientes e hidratantes à base de petrolatos, parafina, ácidos graxos essenciais, alfa-hidroxiácidos em baixas concentrações, óleos vegetais, propilenoglicol ou ceramidas deve ser constante, em todos os tipos de Ictiose Hereditária, por toda a vida, independentemente da utilização de terapia sistêmica concomitante. Preconiza-se evitar produtos com fragrâncias e corantes, pelo risco de desencadearem alergias de contato. Devese evitar o uso de produtos que contenham ureia em sua composição, nas flexuras e nas áreas inflamadas e erosadas<sup>5</sup> .  
Infecções fúngicas e bacterianas são comuns e devem ser tratadas especificamente com antimicrobianos, de acordo com grau de acometimento<sup>5,17</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.1 Tratamento tópico** -->
O tratamento tópico visa à hidratação, lubrificação, ceratólise e modulação da diferenciação celular epidérmica. As Ictioses Vulgar e ligada ao cromossomo X, formas mais frequentes das Ictioses Hereditárias, apresentam manifestações clínicas consideradas leves e podem ser controladas com cuidados tópicos. Neste tipo de tratamento, além da hidratação corporal contínua, são preconizados ceratolíticos para dar mais conforto a pacientes que tenham áreas de pele muito espessadas, como o ácido salicílico. No entanto, não se deve usá-lo em recém-nascidos e crianças pequenas, nem em áreas de pele de adultos muito extensas, pelo risco de absorção sistêmica (salicilismo)<sup>5,9</sup> . Chama-se salicilismo o <mark>envenenamento por salicilato, que pode causar vômitos, zumbido, confusão mental, hipertermia, desequilíbrios eletrolíticos (alcalose respiratória e acidose metabólica) e insuficiência de múltiplos órgãos.</mark>

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.2. Tratamento sistêmico** -->
A terapia sistêmica é reservada para casos graves. A acitretina é o único medicamento aprovado e disponível no Brasil para o tratamento de distúrbios da queratinização ou corneificação. É um retinoide sintético de segunda geração, monoaromático, que substituiu o etretinato no tratamento da psoríase e distúrbios da queratinização. É um análogo da vitamina A, estrutural e funcionalmente, que atua regulando a transcrição de genes por meio de seus receptores nucleares, no desenvolvimento  
embrionário, na diferenciação e proliferação celular. Como terapia complementar, outros fármacos que podem auxiliar no controle dos sintomas incluem colírios lubrificantes (hipromelose) e anti-histamínicos por via oral (dexclorfeniramina ou loratadina)<sup>5</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.3. Aconselhamento Genético** -->
Considerando que os distúrbios congênitos da queratinização ou corneificação compreendem um grupo geneticamente heterogêneo com padrões de herança variáveis – autossômico dominante, autossômico recessivo ou ligado ao cromossomo X, o aconselhamento genético deve ser ofertado, idealmente, para todo paciente com Ictiose Hereditária<sup>4</sup> . O aconselhamento genético é um procedimento no qual são providas informações ao indivíduo ou famílias acerca do diagnóstico, causa, evolução e riscos de recorrência de determinada doença ou condição genética, visando a medidas preventivas primárias, secundárias e terciárias, conferindo maior esclarecimento para as famílias afetadas, sem perder de vista a autonomia reprodutiva dos indivíduos e respeitando valores éticos, culturais e religiosos<sup>21</sup> .  
Trata-se de um processo comunicativo e que envolve a obtenção do histórico familiar quanto à presença de consanguinidade parental ou a ocorrência de casos semelhantes, contando com a avaliação clínica e evolutiva do paciente, heredograma e testes diagnósticos disponíveis, se indicados. O aconselhamento, de preferência, deve ocorrer como um atendimento multidisciplinar que assegure o entendimento sobre os aspectos relacionados à doença, incluindo o seu diagnóstico, o curso provável da doença e a conduta disponível, além de oferecer suporte ao consulente e sua família<sup>9,21</sup> .  
O processo do aconselhamento genético poderá ser efetuado mais adequadamente a partir da definição etiológica apurada do caso, utilizando-se testes genéticos, recomendados especialmente para as formas mais graves ou sindrômicas de ictioses, mediante disponibilidade<sup>9</sup> .  
Os resultados dos testes genéticos devem sempre ser comunicados por médicos geneticistas<sup>9</sup> . A ausência de uma definição da causa genética do distúrbio de queratinização ou corneificação não é impeditiva, no entanto, para se proceder ao tratamento adequado do caso, com o devido acesso ao medicamento, como os indicados neste Protocolo.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.4. Fármacos** -->
- Ácido salicílico: pomada a 5%.  
- Acitretina: cápsulas de 10 mg e 25 mg.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.5. Esquemas de administração** -->
<u>Pomada com ácido salicílico a 5%: A pomada deve ser aplicada nas lesões, à noite, e retirada pela manhã</u><sup>22</sup> , devendo ser indicada para áreas limitadas, como palmas das mãos, plantas dos pés, cotovelos e joelhos. Formas farmacêuticas ceratolíticas contendo ácido salicílico devem ser utilizadas de forma ponderada e por curtos períodos, apenas em áreas hiperceratósicas localizadas, em especial na criança pequena, por causa do risco de salicilismo<sup>5,9</sup> .  
<u>Acitretina: Considerando-se as diferenças individuais na absorção e na velocidade do metabolismo da acitretina, a dose</u> deve ser ajustada individualmente. A dose diária deve ser ingerida de preferência uma vez ao dia, com alimentos ou com um pouco de leite. Em geral, a posologia para adultos é de uma dose inicial diária de 25 a 30 mg durante 2 a 4 semanas. A dose de manutenção deve ser estabelecida de acordo com a eficácia e tolerabilidade. Em geral, os melhores resultados são obtidos com doses diárias de 25 a 50 mg tomadas durante seis a oito semanas adicionais. A dose máxima é de 75 mg/dia. A dose em crianças é de acordo com o peso, sendo indicada 0,5 a 1 mg/kg/dia, com a dose máxima de 35 mg/dia. Uma vez obtida melhora clínica, a dose deve ser reduzida até a menor dose clinicamente eficaz, devido aos possíveis eventos secundários de longo prazo. Em genodermatoses, como nas ictioses, o tratamento é de uso contínuo, observando-se a necessidade de ajuste das doses em função de eventuais efeitos colaterais.<sup>5,20</sup> .  
O tratamento não tem tempo predeterminado.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.6. Benefícios esperados** -->
Os benefícios do tratamento combinado (tópico e sistêmico) são:  
- Redução do prurido;  
- melhora da descamação da pele e redução das escamas e do ectrópio;  
- maior elasticidade cutânea; e  
- maior tolerância ao calor com tendência à melhora da sudorese.  
Os resultados são variáveis e dependem do tipo de ictiose, sendo as formas mais graves também de mais difícil resposta clínica<sup>1</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **8.7.     Interações medicamentosas** -->
Deve-se atentar para as potenciais interações medicamentosas. Para evitar a hipervitaminose A, não se deve administrar concomitantemente vitamina A e outros retinoides. A acitretina reduz parcialmente a ligação proteica da fenitoína. Interações com tetraciclinas podem provocar hipertensão intracraniana; já interações com o metotrexato podem provocar hepatite (6. Critérios de Exclusão)<sup>20</sup> .

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **9. MONITORAMENTO** -->
O tratamento de indivíduos com Ictioses Hereditárias é multidisciplinar, e a composição da equipe variará de acordo com as alterações apresentadas e suas necessidades. Preferencialmente, deve-se iniciar sob orientação de um dermatologista, quanto aos cuidados com a pele e a introdução de tratamento sistêmico, conforme a sua avaliação médica. No caso de tratamento medicamentoso específico, exames de controle, a seguir descritos em maior detalhe, devem ser realizados. Acompanhamento com outros especialistas, como ortopedistas, neurologistas, oftalmologistas e psicólogos, entre outros, poderá ser indicado de acordo com a necessidade que o caso apresente.  
Os pacientes com Ictioses Hereditárias devem ter a resposta terapêutica e os eventos adversos monitorados. Para cada um dos medicamentos, devem ser observadas as contraindicações relativas e absolutas, considerando o risco e o benefício de seu uso. Diante de efeitos adversos ou complicações da doença propriamente dita, o tratamento deverá ser interrompido ou modificado.  
Os efeitos adversos relacionados ao tratamento com a acitretina incluem queilite (i <mark>nflamação aguda ou crônica dos lábios)</mark> , alteração na textura do cabelo, alopecia (perda de pelos ou de cabelo), alteração na textura do cabelo, xerose (pele seca), prurido (coceira), descamação cutânea, fragilidade cutânea, dermatite ( <mark>inflamação da pele que gera vermelhidão, coceira e bolhas),</mark> cheiro anormal da pele, xeroftalmia (ou <mark>queratomalacia, produção de lágrimas deficiente em qualidade ou quantidade)</mark> , fotofobia (sensibilidade aumentada à luz solar), cegueira noturna, boca seca, alteração do paladar (disgeusia),  inflamação de mucosas, estomatite ( <mark>inflamação da mucosa bucal)</mark> , paroníquia ( <mark>inflamação da pele em torno da unha),</mark> eritema (vermelhidão da pele), unhas quebradiças, parestesias ( <mark>sensação de dormência ou formigamento parte ou partes do corpo)</mark> , cefaleia (dor de cabeça), cansaço, sudorese, tontura, _pseudotumor cerebri_ (hipertensão intracraniana, mais comum quando associado a tetraciclinas), sede não usual, náusea, vômitos, dor abdominal, constipação intestinal, diarreia, pancreatite, dor articular (artralgia), mialgia (dor muscular), edema periférico, hiperlipidemia (aumento das gorduras – lipídeos – no sangue), alterações de provas de função hepática e hepatite<sup>19,23</sup> .  
Os retinoides podem causar alterações ósseas como hiperostose ( <mark>crescimento excessivo de um osso)</mark> , encurtamento de espaços intervertebrais, osteoporose, calcificação de tendões e ligamentos, adelgaçamento de ossos longos, reabsorção óssea, fechamento precoce das epífises (extremos de um osso longo) e retardo no crescimento em crianças<sup>23</sup> .  
A hiperlipidemia é proporcional à dose de acitretina. O maior aumento é visto nos triglicerídeos (20% a 40%), seguido de hipercolesterolemia (10% a 30% às custas de VLDL – _very low density lipoprotein_ e LDL – _low density lipoprotein_ ) e redução de HDL – _high density lipoprotein_ – em até 40% dos casos<sup>24</sup> .  
Na monitorização do tratamento, o perfil lipídico (colesterol total, HDL e triglicerídeos) e glicemia de jejum devem ser solicitados a cada 2 a 4 semanas nas primeiras 8 semanas e, após, a cada 3 meses<sup>5</sup> .  
Pelo risco de pancreatite, a acitretina deve ser interrompida se os triglicerídeos alcançarem níveis próximos a 800 mg/dL. Os pacientes que apresentarem hiperlipidemia durante o tratamento devem ser tratados com dieta e fármacos para sua condição e deve ser considerada redução da dose de acitretina. Pacientes com triglicerídeos superiores a 400 mg/dL devem ser encaminhados para investigação de outras causas associadas (consumo de álcool, lúpus eritematoso sistêmico, diabete melito e hipotireoidismo, entre outros)<sup>5</sup> .  
Transferases/transaminases hepáticas séricas devem ser dosadas a cada duas a quatro semanas nos primeiros dois meses de tratamento e, após, a cada três meses. Elevações leves dos níveis dessas enzimas são comuns. Se os níveis excederem duas vezes o limite normal, preconiza-se aumentar a frequência das coletas semanais para as suas dosagens; se excederem três vezes o limite ou bilirrubina total superior a 3 mg/dL ou se a aspartatoamino transferase/transaminase glutâmico oxalacética (AST/TGO) for maior que 200 UI/L, deve-se suspender o tratamento<sup>25,26</sup> .  
Em crianças, o monitoramento radiológico inicial é necessário para avaliar alterações ósseas e consiste em exame radiológico da coluna cervical e lombar, ossos longos, mãos e punhos para idade óssea<sup>23</sup> . Não se preconizam radiografias seriadas, pelo risco associado da exposição à radiação na infância, mas recomenda-se observar a curva de crescimento e repetir a investigação em pacientes com alterações nessa curva que sugiram retardo de crescimento ósseo. Em caso de alteração do crescimento, a manutenção ou suspensão do tratamento deve ser avaliada sempre considerando o risco e o benefício. Em caso de adultos, preconiza-se apenas investigação radiológica de pacientes sintomáticos<sup>24,25</sup> .  
O risco de deficiência de vitamina D em pacientes com Ictioses Hereditárias é bem documentado, sobretudo em crianças. Embora se desconheça o mecanismo exato que leve a essa alteração, acredita-se que a pigmentação da pele, a gravidade da doença e climas quentes e frios estejam associados à deficiência de vitamina D. Assim, recomenda-se que seja solicitada a dosagem sérica de vitamina D a pacientes com fatores de risco para esta condição, que devem repeti-la semestral ou anualmente<sup>7</sup> . Em caso de osteoporose por deficiência de vitamina D, os indivíduos devem ser tratados de acordo com o PCDT de Osteoporose, do Ministério da Saúde<sup>27</sup> .  
Os indivíduos devem ser reavaliados por profissional médico após a realização dos exames indicados. Entretanto, o período para realização das consultas varia de acordo com avaliação clínica, segundo as necessidades individuais dos usuários.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **10. ACOMPANHAMENTO PÓS-TRATAMENTO** -->
Devido à alta teratogenicidade da acitretina, a anticoncepção das mulheres em idade fértil deve ser mantida por três anos após o tratamento.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **11. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento e do acompanhamento pós-tratamento.  
Doentes de ictiose devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Idealmente, o diagnóstico deve ser feito por médico dermatologista, com complementação por geneticista clínico. O tratamento de manifestações cutâneas deve ser inicialmente acompanhado por dermatologista; no caso de manifestações  
extracutâneas, médicos especialistas (ortopedistas, oftalmologistas e neurologistas, entre outros) e outros profissionais da saúde podem ser indicados para avaliação e tratamento adequados.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Devem ser observadas as normas para dispensação de acitretina estabelecidas pela Agência Nacional de Vigilância Sanitária (ANVISA). O fornecimento do medicamento a crianças deve ser vinculado a uma receita atualizada com dose adequada ao peso corporal.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **12. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **13. REFERÊNCIAS** -->
1. Belda Junior W, Di Chiacchio N, Criado P. Tratado de Dermatologia. 3 ed.  Atheneu; 2018. Capítulo, Distúrbios hereditários da queratinização - Ictioses e queratodermias palmoplantares; 1699–1729.  
2. <mark>Oji V, Tadini G, Akiyama M, Bardon CB, Bodemer C, Bourrat E, et al. Revised nomenclature and classification of inherited ichthyoses: results of the First Ichthyosis Consensus Conference in Sorèze 2009.</mark> _<mark>Journal of the American Academy of Dermatology</mark>_ <mark>. 2010;</mark> _<mark>63</mark>_ <mark>(4):607-641.</mark>  
3. Vahlquist A, Fischer J, Törmä H. Inherited Nonsyndromic Ichthyoses: An Update on Pathophysiology, Diagnosis and Treatment. Am. J. Clin. Dermatol. 2018; 19(1):51–66.  
4. Almendra NV, Duran LA. Ictiosis hereditaria: desafío diagnóstico y terapéutico. Revista chilena de pediatría. 2016;87(3):213–223.  
5. <mark>Mazereeuw‐Hautier J, Vahlquist A, Traupe H, Bygum A, Amaro C, Aldwin M, et al. Management of congenital</mark>  
<mark>ichthyoses: European guidelines of care, part one.</mark> _<mark>British Journal of Dermatology</mark>_ <mark>. 2019;</mark> _<mark>180</mark>_ <mark>(2):272-281.</mark>  
6. Gånemo A, Lindholm C, Lindberg M, Sjödén PO, Vahlquist A. Quality of life in adults with congenital ichthyosis. J. Adv. Nurs. 2003;44(4):412–419.  
7. Gånemo A. Quality of life in Swedish children with congenital ichthyosis. Dermatology reports. 2010; 2(1):e7–e7.  
8. Süßmuth K, Traupe H, Metze D, Oji V. Ichthyoses in everyday practice: management of a rare group of diseases. J. der Dtsch. Dermatologischen Gesellschaft. 2020;18(3):225–243.  
9. <mark>Oji V, Preil ML, Kleinow B, Wehr G, Fischer J, Hennies HC, et al. S1‐Leitlinie zur Diagnostik und Therapie der Ichthyosen–Aktualisierung.</mark> _<mark>JDDG: Journal der Deutschen Dermatologischen Gesellschaft</mark>_ <mark>. 2017;</mark> _<mark>15</mark>_ <mark>(10),1053-1065.</mark>  
10. Fischer J, Bourrat E. Genetics of Inherited Ichthyoses and Related Diseases. Acta dermato-venereologica. 2020; 100.  
11. Aliazami F, Farhud D, Zarif-Yeganeh M, Salehi S,Hosseinipour A, Sasanfar R, et al. Gjb3 Gene Mutations in NonSyndromic Hearing Loss of Bloch, Kurd, and Turkmen Ethnicities in Iran. Iran J Public Health. 2020 Nov;49(11):2128-2135.  
12. Charfeddine C, Laroussi N, Mkaouar R, Jouini R, Khayat O, Redissi A, et al. Expanding the clinical phenotype associated with NIPAL4 mutation: Study of a Tunisian consanguineous family with erythrokeratodermia variabilisLike Autosomal Recessive Congenital Ichthyosis.  PLoS One. 2021 Oct;16(10):e0258777.  
13. Pilz R, Opálka L , Majcher A, Grimm E, Van Maldergem L, Mihalceanu S, et al. Formation of keto-type ceramides in palmoplantar keratoderma based on biallelic KDSR mutations in patients. Human Molecular Genetics, 2022 apr;31(7):1105– 1114.  
14. Bremmer SF, Hanifin JM, Simpson EL. Clinical detection of ichthyosis vulgaris in an atopic dermatitis clinic: implications for allergic respiratory disease and prognosis. J. Am. Acad. Dermatol. 2008; 59(1):72–78.  
15. Ramphul K, Kota V , Mejias SG. Child Syndrome. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing; 2022.  
16. Mah-Som A, Skrypnyk C, Guerin A, Jadah RHS, Vardhan VN, McKinstry RC, et al. New Cohort of Patients With CEDNIK Syndrome Expands the Phenotypic and Genotypic Spectra. Neurol Genet. 2021;7(1):e553.  
17. <mark>Schmuth M, Martinz V, Janecke AR, Fauth C, Schossig A, Zschocke J, et al. Inherited ichthyoses/generalized Mendelian disorders of cornification.</mark> _<mark>European Journal of Human Genetics</mark>_ <mark>. 2013;</mark> _<mark>21</mark>_ <mark>(2):123-133.</mark>  
18. Brasil. Cadernos de Atenção Primária no. 29 - Rastreamento. Brasília: Ministério da Saúde, 2010. 95 p.  
19. Brasil. Manual dos Comitês de Mortalidade Materna. 3 ed. Brasília: Ministério da Saúde, 2009. 104 p.  
20. NEOTIGASON® (acitretina) [bula de medicamento]. (2017).  
21. American Society of Human Genetics. Genetic counseling. Am. J. Hum. Genet. 1975;27: 240–242.  
22. Brasil. Formulário Nacional Da Farmacopeia Brasileira. 2 ed. Brasília: Anvisa, 2012. 224p.  
23. Brito MFM, Sant’Anna IP, Figueiroa F. Avaliação laboratorial dos efeitos colaterais pelo uso da acitretina em crianças  
- portadoras de ictiose lamelar: seguimento por um ano. Anais Brasileiros de Dermatologia. 2004;79(3)283–288.  
24. Ormerod AD, Campalani E, Goodfield MJD. British Association of Dermatologists guidelines on the efficacy and use of  acitretin in dermatology. Br. J. Dermatol.2010;162(5):952–963.  
25. Sarkar R, Chugh S, Garg VK. Acitretin in dermatology. Indian J. Dermatol. Venereol. Leprol.2013; 79(6):759–771.  
- 26 <mark>. Menter A, Korman NJ, Elmets CA, Feldman SR, Gelfand JM, Gordon KB, et al. Guidelines of care for the management of psoriasis and psoriatic arthritis: section 4. Guidelines of care for the management and treatment of psoriasis with traditional systemic agents.</mark> _<mark>Journal of the American Academy of Dermatology</mark>_ <mark>. 2009;</mark> _<mark>61</mark>_ <mark>(3):451-485.</mark>  
27. Brasil. Portaria nº 451, de 9 de junho de 2014. Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose. 2014. 17p.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: ACITRETINA E POMADA DE ÁCIDO SALICÍLICO. -->
Eu, _________________________________________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso da acitretina e da pomada de ácido salicílico, indicadas para o tratamento das Ictioses Hereditárias.  
|Os|termos|médicos|foram|explicados|e<br>todas|as|minhas|dúvidas|foram|resolvidas|pelo|médico|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|_________|_______|_________|_______|___________|_________|____|________|________|_______|__________|______|(nome|  
do médico que prescreve).  
Assim declaro que fui claramente informado(a) de que o(s) medicamento(s) que passo a receber podem trazer os seguintes benefícios:  
- melhora da descamação e redução das escamas da pele;  
- maior elasticidade cutânea; e  
- maior tolerância ao calor com tendência a melhora da sudorese.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: <u>Acitretina:</u> -->
- medicamento contraindicado na gestação ou para mulheres que planejam engravidar e em casos de alergia ao fármaco  
- e à vitamina A e seus derivados;  
- os efeitos adversos incluem dores musculares (mialgias), dores nas articulações (artralgias), dor de cabeça (cefaleia), tontura, náusea, vômitos, dor abdominal, constipação intestinal (prisão-de-ventre), diarreia, secura e inflamação das mucosas (estomatite, no caso da mucosa bucal; queilite, no caso dos lábios), pele seca (xerose), vermelhidão da pele (eritema), coceira (prurido),  descamação cutânea, fragilidade cutânea, dermatite ( <mark>inflamação da pele que gera vermelhidão e coceira), p</mark> erda de cabelo e pelos (alopecia), alteração na textura do cabelo, sede não usual, irritação, secura nos olhos (xeroftalmia), cegueira noturna, alteração do paladar (disgeusia), sensibilidade aumentada à luz solar (fotofobia), unhas quebradiças, <mark>inflamação da pele em torno da unha</mark> (paroníquia), cansaço, sudorese (aumento do suor), edema periférico, <mark>crescimento excessivo de um osso</mark> (hiperostose <mark>), osteoporose, e</mark> ncurtamento de espaços entre as vértebras, calcificação de tendões e ligamentos, adelgaçamento de ossos longos, reabsorção óssea, fechamento precoce das epífises (extremos de um osso longo) e retardo no crescimento em crianças, <mark>sensação de dormência ou formigamento em parte ou partes do corpo (p</mark> arestesias), elevação do colesterol e triglicérides (hiperlipidemia). Os efeitos mais raros incluem cheiro anormal da pele, alergias na pele, inflamação da garganta, _pseudotumor cerebri_ (hipertensão intracraniana, mais comum quando associado a tetraciclinas), inflamação do pâncreas (pancreatite), alterações de provas de função hepática e inflamação do fígado (hepatite); e  
- o risco de ocorrência de efeitos adversos aumenta com a superdosagem.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: <u>Pomada de ácido salicílico:</u> -->
- medicamento contraindicado para crianças com menos de 2 anos de idade e para indivíduos com hipersensibilidade a  
- salicilatos;  
- medicamento indicado para aplicação sobre feridas ou inflamações cutâneas;  
- os efeitos adversos incluem irritação local, dermatite, ressecamento da pele, queimadura, ardor, prurido e salicilismo;  
- o salicilismo é o envenamento por salicilato, que pode também se dar pela absorção transcutânea do ácido salicílico,  
- sendo geralmente observado após a aplicação excessiva da pomada, particularmente em crianças; e  
- o <mark>envenenamento por salicilato pode causar vômitos, zumbido, confusão mental, hipertermia (febre), desequilíbrios</mark>  
- <mark>eletrolíticos (alcalose respiratória e acidose metabólica) e insuficiência de múltiplos órgãos.</mark>  
Estou ciente de que estes medicamentos somente podem ser utilizados por mim, comprometendo-me a devolvê-los caso  
não queira ou não possa utilizá-los ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive em caso de eu desistir de usar os medicamentos.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (   ) Sim    (   ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (   ) Pomada de ácido salicílico  
- (   ) Acitetrina  
|Local:|Data:||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do re|sponsável legal:||
|___________________________<br>Assinatura do paciente ou do resp|__________<br>onsável legal||
|Médico Responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontram os medicamentos preconizados neste Protocolo.  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **1. ESCOPO E FINALIDADE DO PROTOCOLO** -->
A versão vigente do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Ictioses Hereditárias é de 2015. Assim, sua atualização foi demandada pela Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde do Ministério da Saúde, em cumprimento ao Decreto nº 7.508, de 28 de junho de 2011, que estabelece que os PCDT serão atualizados a cada dois anos. A partir da definição do tema, foi conduzida uma reunião presencial para delimitação do escopo do PCDT. Essa reunião contou com a presença de nove membros do Grupo Elaborador, sendo quatro especialistas (duas dermatologistas e duas geneticistas), uma representante de uma organização de pacientes com ictioses e quatro metodologistas e quatro representantes do Comitê Gestor.  
As discussões tidas à reunião tiveram como base o texto do PCDT vigente (Portaria SAS/MS nº 1.162, de 18/11/2015), e a estrutura de PCDT foi definida conforme a Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT publicado em 2015 foi discutida entre os grupos Elaborador e Gestor, com o objetivo de revisar as condutas diagnósticas e terapêuticas e identificar as tecnologias que poderiam ser consideradas nas recomendações para as ictioses.  
A partir dessa reunião, ficou estabelecido que as recomendações diagnósticas, de tratamento ou de acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas, por se tratar de práticas assistenciais estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidade de desinvestimento de tecnologias ou procedimentos recomendados na versão vigente do PCDT.  
Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais e diretrizes atuais que consolidam a prática assistencial e a atualizar os dados epidemiológicos descritos no Protocolo vigente, de forma que o atualizado estabeleça os critérios para diagnóstico e tratamento das Ictioses Hereditárias, bem como de acompanhamento dos pacientes com esta condição.  
Após a publicação da Portaria Conjunta SAES/SCTIE/MS nº 12, de 27 de julho de 2021, que aprovou o Protocolo Clínico e Diretrizes Terapêuticas das Ictioses Hereditárias, foram acolhidas evidências que justificaram a atualização do Quadro 1 - Classificação atual das ictioses não sindrômicas, padrão de herança, genes envolvidos e produto do gene; e do Quadro 2 - Classificação das ictioses sindrômicas, apresentação clínica, padrão de herança e genes envolvidos. As alterações realizadas a partir das evidências científicas apresentadas foram apreciadas pelos membros da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas presentes à sua 99ª Reunião Ordinária e pelo Plenário da Conitec à sua 109ª Reunião Ordinária, com recomendação favorável às modificações propostas.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **2. EQUIPE DE ELABORAÇÃO E PARTES INTERESSADAS** -->
A equipe responsável pelo desenvolvimento deste PCDT incluiu metodologistas, especialistas geneticistas e dermatologistas, bem como os representantes do Ministério da Saúde que acompanharam o processo de elaboração e apresentação do PCDT.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **2.1.     Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta do PCDT foi apresentada à 84ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 25 de novembro de 2020, com a participação de áreas técnicas do Ministério da Saúde que decidiram, por unanimidade, pautar o tema na reunião da Conitec.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **2.2.     Consulta pública** -->
A Consulta Pública nº 40/2021, do Protocolo Clínico e Diretrizes Terapêuticas de Ictioses Hereditárias, ficou disponibilizada entre os dias 27 de maio de 2021 a 15 de junho de 2021. Foram recebidas 6 (seis) contribuições, as quais foram avaliadas em sua totalidade, de modo quantitativo e qualitativo. As contribuições dadas não trouxeram bases para alteração do texto do PCDT posto à consulta.  
O conteúdo integral das contribuições encontra-se disponível na página da Conitec em: http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20210616_CP_CONITEC_40_2021_PCDT_Ictioses.pdf.

---

<!-- METADADOS: doenca: Ictioses Hereditárias | secao: **3. BUSCA DA EVIDÊNCIA E RECOMENDAÇÕES** -->
Para auxiliar na atualização do PCDT, foram feitas buscas nas bases de dados PUBMED e Embase, conforme estratégias de busca ilustradas no **Quadro A** .  
Considerando que o PCDT vigente é de 2015, foram realizadas buscas, sem restrições, a partir do ano de 2014 para recuperar os estudos que tenham sido publicados desde então. Ressalta-se que este levantamento bibliográfico não foi sistematizado. Todos os resultados foram avaliados por um único pesquisador em termos de título e resumo, quanto à pertinência e adequabilidade às Ictioses Hereditárias. Além das buscas nas bases de dados, as especialistas foram consultadas quanto à existência de estudos relevantes que, porventura, não tivessem sido identificados por meio das estratégias de busca.  
Cinquenta e seis estudos foram localizados nas bases de dados. Destes, dois estavam duplicados. Assim, cinquenta e quatro estudos foram triados pelo título e pelo resumo e três foram lidos na íntegra para subsidiar a atualização do PCDT. Os demais estudos utilizados são condizentes com literatura estabelecida sobre as Ictioses Hereditárias ou a documentos indicados pelos especialistas.  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline (via|"Ichthyosis"[Mesh]<br>AND<br>((Guideline[ptyp]<br>OR<br>Clinical|6|2|3|
|PUBMED)|Trial[ptyp] OR Randomized Controlled Trial[ptyp] OR Meta-<br>Analysis[ptyp])<br>AND<br>("2014/11/20"[PDAT]<br>:||||
|Data da busca:|"3000/12/31"[PDAT]))||||
|03/03/2020|||||
|Embase|'ichthyosis'/exp AND ([cochrane review]/lim OR [systematic|50|||
||review]/lim OR [meta analysis]/lim OR [controlled clinical||||
|Data da busca:|trial]/lim<br>OR<br>[randomized<br>controlled<br>trial]/lim)<br>AND||||
|03/03/2020|[embase]/lim AND [2014-2020]/py||||

---

