<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Geral -->
SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 21, DE 24 de SETEMBRO DE  2018.  
Aprova as Diretrizes Brasileiras para o Tratamento de Fratura do Colo do Fêmur em Idosos.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre fratura do colo do fêmur no idoso no Brasil e diretrizes nacionais para o seu tratamento;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 305/2017 e o Relatório de Recomendação nº 323 – Novembro de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º Ficam aprovadas, na forma do Anexo, disponível no sítio:http://portalms.saude.gov.br/protocolos-e-diretrizes,as “Diretrizes Brasileiras para o Tratamento de Fratura do Colo do Fêmur em Idosos”.  
Parágrafo único. As diretrizes de que trata este artigo, que contêm as recomendações para o tratamento da fratura do fêmur no idoso, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a científicação do paciente, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao tratamento da fratura do colo fêmur no idoso.  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
MARCO ANTÔNIO DE ARAÚJO FIREMAN

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: ANEXO -->
DIRETRIZES BRASILEIRAS PARA O TRATAMENTO DA FRATURA DO COLO DO FÊMUR EM IDOSOS

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **<mark>RESUMO EXECUTIVO</mark>** -->
|Pré – Operatório|Recomendação|Evidência<br>Científica|
|---|---|---|
|Imagens<br>Avançadas|Para fraturas ocultas que não foram diagnosticadas em<br>raios- X simples de quadril em três incidências, a ressonância<br>magnética é o método diagnóstico indicado para fratura oculta<br>doquadril.|Força da<br>Recomendação:<br>Moderada|
|Tempo<br>Recomendado para<br>Abordagem<br>Cirúrgica|O tratamento cirúrgico da fratura do colo do fêmur deve ser<br>realizado com a maior brevidade possível, desde que o<br>paciente encontre-se clínicamente apto para a cirurgia<br>proposta<br>(osteossíntese<br>ou<br>artroplastia),<br>evitando-se<br>ultrapassar um período superior a 48 horas, a partir da<br>ocorrência da fratura.|Força da<br>Recomendação:<br>Moderada|
|Analgesia Pré e<br>Pós- Operatória|É recomendada a analgesia inicialmente com analgésico<br>simples (paracetamol ou dipirona) e, após avaliação, o<br>bloqueio de nervo regional para o controle da dor.|Força da<br>Recomendação para<br>o Bloqueio de Nervo<br>Regional: Forte|
|Anestesia|A<br>evidência<br>científica<br>não<br>demonstrou<br>diferença<br>significante nos desfechos para a anestesia geral ou<br>raquidiana, sendo recomendada a anestesia regional,<br>preferencialmente, por apresentar menor incidência de<br>complicações pulmonares e  de     mortalidade<br>intra-hospitalar.|Força da<br>Recomendação:<br>Forte|
|Fraturas de Colo<br>de Fêmur não<br>Desviadas|As fraturas do colo do fêmur não desviadas têm indicação<br>de tratamento cirúrgico. As situações em que não são<br>indicadas as cirurgias devem ser claramente definidas e<br>discutidaspor, pelo menos,dois ortopedistas.|Força da<br>Recomendação:<br>Moderada|
|Fraturas de Colo<br>de Fêmur<br>Desviadas|As fraturas desviadas do colo de fêmur apresentam<br>melhores resultados funcionais e menores taxas de reoperação<br>quando tratadas por meio de artroplastia em detrimento da<br>redução com fixação interna.|Força da<br>Recomendação:<br>Forte|
|Tração Pré-<br>Operatória no<br>Membro Fraturado|O uso de tração pré-operatória nos pacientes com fraturas<br>do colo do fêmur não justificou a sua indicação, após a análise<br>e a conclusão de que os riscos desse procedimento são<br>superiores aos benefícios.|Força da<br>Recomendação:<br>Moderada|
|Exames –<br>Creatinina e<br>Albumina|O exame de creatinina deverá ser solicitado como rotina<br>pré-operatória para todos os pacientes e a albumina deve ser<br>solicitada caso necessário, após a avaliação clínica do<br>paciente.|Força da<br>Recomendação:<br>Limitada|
|Tratamento|Recomendação|Evidência Científica|  
2  
|Prótese Bipolar<br>versus Unipolar|As próteses unipolares e bipolares não apresentam<br>diferenças significativas no resultado funcional do   paciente,<br>sendo mais recomendadas as próteses unipolares   em razão<br>de o seu custo ser inferior ao das bipolares.|Força da<br>Recomendação:<br>Moderada|
|---|---|---|
|Hemiartroplastia<br>versus Artroplastia<br>Total de Quadril|A artroplastia total do quadril é a indicada para os pacientes<br>idosos com fratura do colo do fêmur desviada que apresentam<br>sinais de coxartrose (artrose do quadril),  demanda funcional<br>comunitária, ou seja, aqueles que realizam atividades<br>comunitárias além das atividades domésticas;   que têm<br>capacidade cognitiva, tais como atenção, juízo, raciocício,<br>memória e linguagem   e   que apresentam condições clínicas<br>favoráveis.<br>Por outro lado, a artroplastia parcial do quadril é a indicada<br>para os pacientes que apresentam uma demanda funcional<br>comunitária de forma parcial, isto é, aqueles que realizam<br>somente atividades domésticas; não possuem uma boa<br>capacidade cognitiva e que apresentam condições clínicas<br>favoráveis.|Força da<br>Recomendação:<br>Moderada|
|Haste Femoral<br>Cimentada|Os estudos revisados nas duas diretrizes não apresentaram<br>diferença estatística e clínica entre as técnicas cimentadas e<br>não cimentadas. Como o risco de causar fraturas na haste não<br>cimentada é maior na população idosa, a artroplastia total<br>cimentada é a melhor opção para o tratamento de pacientes<br>idosos com fraturas desviadas do colo do fêmur.|Força da<br>Recomendação:<br>Moderada|
|Abordagem<br>Cirúrgica|O tratamento cirúrgico da fratura do colo do fêmur deve ser<br>realizado com a maior brevidade possível, desde que o<br>paciente encontre-se clínicamente apto para a cirurgia<br>proposta<br>(osteossíntese<br>ou<br>artroplastia),<br>evitando-se<br>ultrapassar um período    superior a 48 horas, a partir da<br>ocorrência da fratura.|F orça da<br>Recomendação:<br>Moderada a Baixa|
|Infecção Cirúrgica|A infecção cirúrgica poderá ser evitada pela degermação<br>das mãos da equipe cirúrgica e pela orientação para o paciente<br>tomar banho antes da cirurgia. Tais procedimentos devem ser<br>realizados com antisséptico padronizado na instituição. Além<br>disso, é fundamental que haja paramentação da equipe<br>cirúrgica com gorro ou touca, máscara cirúrgica, ausência de<br>adornos, avental cirúrgico estéril, luva estéril e utilização de<br>campo cirúrgico estéril para o procedimento cirúrgico.<br>A profilaxia antibiótica para cirurgias ortopédicas eletivas<br>com implantes ou manipulação óssea e próteses deve ser feita<br>com Cefazolina 2 g IV até 60 minutos antes da incisão<br>cirúrgica e seguida por 1g IV de    8 em 8 horas  no pós-<br>operatório até   24 horas,    ou seja, mais duas doses no pós-<br>operatório..<br>As bandejas materiais e equipamentos cirúrgicos que vão<br>fazer parte do procedimento cirúrgico devem ser estéreis e<br>com indicadores de esterilidade|Qualidade da<br>Evidência:<br>Moderada|
|Indicação da<br>Transfusão|A transfusão deve ser sempre baseada na clínica e nos<br>exames<br>laboratoriais,<br>evitando<br>a<br>transfusão<br>quando<br>hemoglobina≥8g/dl.|Força da<br>Recomendação: Alta|  
3  
|Profilaxia de TVP|Em cirurgias de artroplastia do quadril total, parcial e<br>osteossíntese, deve ser realizada a profilaxia medicamentosa.<br>A profilaxia mecânica deve ser utilizada sempre que houver<br>contraindicação para o uso de anticoagulantes, sendo indicada<br>a profilaxia medicamentosa estendida após a alta hospitalar<br>por umperíodo de 28 a 30 dias.|Qualidade da<br>Evidência:<br>Moderada|
|---|---|---|
|Cuidados Pós-<br>Operatórios|Recomendação|Evidência Científica|
|Reabilitação e<br>Cuidado<br>Interdisciplinar|O programa de reabilitação interdisciplinar promove<br>melhor resultado e adequação funcional do paciente no pós-<br>operatório de fratura do quadril, atuando na proposta<br>preventiva e nos cuidados básicos de saúde, tais como<br>adequação do ambiente doméstico e a reinserção na<br>sociedade.|Força da<br>Recomendação:<br>Forte|
|Fisioterapia|A fisioterapia precoce (dentro das 48 horas) no pós-<br>operatório, com continuidade e supervisionada por um<br>fisioterapeuta, demonstra uma melhora na mobilização e<br>independência do idoso.|Força da<br>Recomendação:<br>Forte|
|Frequência da<br>Fisioterapia|Ambas as diretrizes da AAOS e NICE recomendam um<br>programa de fisioterapia regular domiciliar e ambulatorial<br>para a recuperação funcional do idoso, após a alta hospitalar.|Força da<br>Recomendação:<br>Moderada|
|Terapia<br>Ocupacional|É indicada a avaliação da terapia ocupacional na internação<br>do paciente, para a avaliação do seu status funcional (AVD e<br>AIVD) antes da fratura.<br>No pré- operatório, o terapeuta atua na estimulação e ou<br>orientação do paciente e do cuidador para a manutenção da<br>sua capacidade funcional.<br>No primeiro dia do pós-operatório, a intervenção do<br>terapeuta é iniciada com orientações ou treino especifico para<br>a realização das AVDS pelo paciente.<br>De acordo com a avaliação do terapeuta, é recomendado o<br>acompanhamento domiciliar com orientação para o paciente e<br>o cuidador com reavaliaçõesperiódicas.|Força da<br>Recomendação:<br>Moderada|
|Nutrição|Para o cuidado e prevenção de fraturas, em especial a de<br>fêmur, em pacientes idosos, é fundamental, portanto, aplicar<br>na prática clínica as seguintes medidas: avaliação do estado<br>nutricional com ferramentas confiáveis, como o questionário<br>da MAN; avaliar se a ingestão de alimentos atende as<br>necessidades nutricionais recomendadas (DRI); em caso de<br>ingestão nutricional inadequada, o que é muito comum nesta<br>faixa etária.|Força da<br>Recomendação:<br>Moderada|
|Cálcio e Vitamina<br>D|Para a redução da perda de densidade mineral óssea (DMO)<br>e, consequentemente,  para a diminuição do risco de<br>incidência de fraturas ósseas  osteoporóticas, é aconselhável a<br>suplementação nutricional de Ca (1200 mg) e Vitamina D<br>(600 UI), principalmente levando-se em consideração o<br>consumo dietético, idade, sexo, pigmentação da pele e<br>exposição solar dos indivíduos, por 15 minutos diários e 2<br>vezes por semana (esta via terapêutica contribuiu para<br>adequada produção de vitamina D) em pacientes que não<br>tenham contraindicação dermatológica.|Força da<br>Recomendação:<br>Moderada|  
4  
|Osteoporose|Medidas profiláticas devem ser consideradas em todos os<br>pacientes, com indicação de uso ou que já estejam usando<br>fármacos ou que apresentem as doenças potencialmente<br>indutoras de osteoporose.<br>Ao paciente com fratura de colo de fêmur por fragilidade<br>óssea<br>deve<br>ser<br>administrado<br>bifosfonados,<br>estando<br>contraindicado para pacientes com insuficiência renal crônica<br>com clearence de creatina ≤ 30ml/min.<br>O ácido zoledrônico não está indicado, pelo PDCT de<br>Osteoporose do Brasil, por insuficiência de evidências de<br>superioridade aos demais bifosfonados.|Força da<br>Recomendação:<br>Moderada|
|---|---|---|
|Geriatra|A avaliação do geriatra inclui a Avaliação Geriátrica<br>Ampla (AGA) nos pacientes de eleição. Após esta avaliação,<br>as condutas serão tomadas para um tratamento personalizado<br>(cognição, humor, capacidade, funcional, avaliação social e<br>suporte familiar).|Força da<br>Recomendação:<br>Moderada|
|Atendimento<br>Domiciliar|O atendimento domiciliar multiprofissional ao idoso<br>proporciona vantagens qualitativas, ao permitir que sejam<br>identificados diversas ações, tais como: identificar o “estresse<br>ambiental” modificável e a  suspeita de maus-tratos, orientar,<br>informar, instrumentalizar o idoso para o seu autocuidado e<br>também os familiares oucuidadores e promover maior<br>independência nas atividades de vida diária (pentear o cabelo,<br>comer sozinho).|Força da<br>Recomendação:<br>Forte|
|Lesão por Pressão|Aplicar e reaplicar as escalas preditivas para identificação<br>dos pacientes em risco para o desenvolvimento de lesão por<br>pressão pelo enfermeiro. É da competência do profissional da<br>saúde orientar o cuidador do paciente quanto à adoção de<br>medidaspreventivaspara evitar a lesãoporpressão.|Força da<br>Recomendação:<br>Moderada|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **INTRODUÇÃO** -->
Nos últimos anos, a população de idosos no Brasil vem crescendo de forma rápida, estimandose que, em 2030, ela representará  13,44%<sup>1</sup> do total da população. No censo do Instituto Brasileiro de Geografia e Estatística (IBGE)<sup>1</sup> de 2010,o número de idosos era de 20.438.561, representando 11,8% da população. Desse percentual, 45,12% tem entre 70 e 79 anos, percentual maior do que o observado nas estatísticas anteriores, demonstrando o aumento da expectativa de vida, que hoje é de 74 anos. A razão de dependência dos idosos em 2014 era de 11,1 % e, em 2030, estima-se que será de 19,49%.  
O estudo ¨Saúde, Bem-estar e Envelhecimento (SABE)¨<sup>2</sup> ,  realizado no município de São Paulo, verificou que 28,6% dos idosos se referiam a  quedas, que aumentavam com a faixa etária. Foi observado que 26,2% dessas quedas ocorreram em pessoas entre 60 e 74 anos e  36,9%  em pessoas acima de 75 anos, sendo  mais frequentes nas mulheres (33,0%) do que nos homens (22,3%).  
5  
As ocorrências de quedas constituem um agravo importante nos idosos e as fraturas, em particular as de fêmur (de colo ou outras partes), podem levar a vários tipos de complicações, inclusive à morte. No mesmo estudo, foram identificadas limitações das atividades e o conjunto artrite/reumatismo/artrose (31,7%), como principais responsáveis por esse quadro. Desses idosos, 62,6% informaram ter algum tipo de limitação, sendo 22,1% muito limitados e 40,5% com pouca limitação. No estudo de Siqueira et al<sup>3,</sup> foram entrevistados 6.616 idosos, moradores em áreas urbanas de 100 municípios de 23 estados brasileiros, sendo verificada a prevalência de quedas  de 27,6% e 11% dos idosos entrevistados relataram fratura decorrente da queda .  
O Centro de Estudos do Envelhecimento da Universidade Federal de São Paulo (Unifesp)<sup>4</sup> realizou um estudo de coorte para avaliar os fatores associados a quedas e suas recorrências em uma população de idosos da comunidade. Dos 1.415 idosos avaliados, 32,7% referiram ter sofrido queda em, pelo menos, um dos inquéritos e 13,9% disseram ter sofrido quedas tanto no primeiro quanto  no segundo inquérito.  
No Instituto Nacional de Traumatologia e Ortopedia (INTO), do Ministério da Saúde, no ano de 2015 foram realizadas 281 cirurgias para tratamento de fraturas de idosos.  Dessas cirurgias, 3,91% foram de alta complexidade e 96,09% foram de média complexidade, sendo que 40 (14,23%) foram fraturas do colo do fêmur (12 artroplastia do quadril e 28 osteossíntese do colo do fêmur)<sup>5</sup>  
As fraturas proximais do fêmur são a principal causa de morte relacionada a quedas nos idosos, responsáveis por cerca de 340.000 internações/ano nos Estados Unidos, a um custo aproximado de três bilhões de dólares<sup>6,7</sup> .  Atingem,  com maior frequência,  a população de idosos, sendo 95% acima de 60 anos e do sexo feminino (75%)<sup>4</sup> .  Tais fraturas têm como principal causa a fragilidade óssea devido à desmineralização ou processos tumorais. Em virtude da frequente ocorrência de doenças associadas nesses pacientes, a taxa de mortalidade nos primeiros 30 dias atinge de 5% a 10%, chegando a 15% a 30% no primeiro ano<sup>6,7,8,9</sup> . Nos Estados Unidos (EUA), a frequência dos procedimentos de ATQ, seja primaria ou secundária a fratura de fêmur, sofre aumento significativo, alcançando o número de 322 000 intervenções por ano.  
As diretrizes têm como finalidade traçar recomendações para o tratamento de adultos, com 60 anos ou mais<sup>10</sup> , que apresentem fratura do colo do fêmur com trauma de baixo impacto (baixa energia). Os capítulos relacionados à fratura do colo de fêmur do idoso por baixo impacto serão abordados no período do pré-operatório, tratamento e acompanhamento pós- cirúrgico. Foi utilizada a ferramenta ADAPTE<sup>11</sup> para a adaptação das diretrizes para a realidade brasileira e para as respostas das 16 questões que foram formuladas no escopo. Para a avaliação da qualidade metodológica dos artigos,  foi utilizada a ferramenta GRADE<sup>12</sup> .  
Foram formuladas 16 perguntas para o desenvolvimento das diretrizes pelo grupo. Foram selecionadas 9 diretrizes, sendo que cinco diretrizes foram excluídas por não se enquadrarem ao  
6  
escopo das diretrizes  e, das quatro selecionadas,  duas foram excluídas  por serem  atualização das diretrizes originais. Sendo escolhidas as diretrizes  do National Clínical Guideline Centre (NICE) - National Clínical Guideline Centre,  The Management of Hip Fracture in Adults London: National Clínical Guideline Centre. Available from: <u>www.ncgc.ac.uk</u><sup>13</sup> e da American Academy of Orthopedic Surgeons (AAOS) - Management of Hip Fractures in the Elderly Evidence- Based Clínical Practice Guideline adopted by the American Academy of Orthopedic Surgeons,September5,2014. _<u>http://www.aaos.org/research/guidelines/HipFxGuideline.pdf</u>_<sup>1</sup> **.** Sendo avaliadas quanto a sua qualidade metodológica, por cinco componentes independentes e mascarados, utilizando o instrumento AGREE<sup>15</sup> .

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **ESCOPO E OBJETIVO** -->
O Instituto Nacional de Traumatologia e Ortopedia (INTO) recebeu uma demanda do Ministério da Saúde para que fossem elaboradas Diretrizes para o Tratamento da Fratura do Colo do Fêmur em Idoso. O Núcleo de Avaliação de Tecnologia em Saúde (NATS) definiu que uma componente do NATS e dois ortopedistas do Centro de Atenção do Trauma (CAE) seriam designados para o desenvolvimento das Diretrizes. Após   definidas as metodologias para o desenvolvimento das diretrizes, foram formuladas 16 perguntas pelo grupo visando a direcionar o desenvolvimento da mesma. O Grupo Elaborador e os membros consultivos das diretrizes estão discriminados no Apêndice 1.    Tais diretrizes têm como finalidade traçar recomendações para o tratamento de adultos, com 60 ou mais anos, que apresentem fratura do colo do fêmur. Os capítulos relacionados à fratura do colo de fêmur do idoso serão abordados no período do pré-operatório, tratamento e acompanhamento pós-cirúrgico.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **PÚBLICO-ALVO** -->
Profissionais da saúde  
- Médicos ortopedistas, clínicos gerais ou geriatras, equipes de enfermagem, multidisciplinares, que prestam cuidados aos pacientes que apresentem fratura do colo do fêmur por fragilidade, auditores e supervisores hospitalares.  
Usuários  
_Os usuários com idade ≥ 60 anos, que chegarem para atendimento em um serviço de saúde com suspeita de fratura do colo do fêmur._  
- Familiares e cuidadores dos idosos que apresentam fratura de colo do fêmur.  
7  
O ESCOPO CLÍNICO DAS DIRETRIZES  
- a) Identificar alternativas de exames de imagem para confirmar ou excluir a suspeita da fratura de colo de fêmur em pacientes com radiografias iniciais aparentemente sem alterações indicativas de fratura.  
- b) Verificar o fluxo de atendimento por um médico ortopedista, clínico geral ou geriatra, equipe de enfermagem e multidisciplinar no cuidado de pacientes apresentando fratura do colo de fêmur.  
- c) Critérios de indicação para realizar uma cirurgia precoce (dentro de 48 horas).  
- d) Pré-operatório ideal e analgesia pós-operatória (alívio da dor), incluindo o uso de bloqueio de nervo periférico.  
- e) Anestesia geral ou regional em pacientes submetidos à cirurgia de fratura de quadril.  
- f) Para fratura intracapsular desviadas:  
- A fixação interna contra a artroplastia (substituição cirúrgica do quadril)  
- A substituição total do quadril contra hemiartroplastia (substituindo a cabeça do fêmur apenas).  
- g) Implante cimentado versus não cimentado na artroplastia.  
- h) Reabilitação multidisciplinar de idosos que foram submetidos à cirurgia de fratura do colo do fêmur.  
i) A transferência precoce para a reabilitação multidisciplinar baseada na comunidade para os idosos que tenham sido submetidos à cirurgia de fratura do colo do fêmur.  
Considera-se fora do escopo destas Diretrizes:  
- a)  Pessoas  com idade inferior a 60 anos.  
b)  Pessoas com fraturas extracapsulares ou da cabeça do fêmur

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **MÉTODOS** -->
O Ministério da Saúde define os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT)<sup>10</sup> como documentos oficiais que estabelecem para várias doenças como devem ser feitos o diagnóstico, o tratamento (com critérios de inclusão e exclusão definidos) e o acompanhamento dos pacientes. Devem ser utilizados pelos profissionais de saúde e gestores. Os PCDT são elaborados com evidência científica confiável, podendo ser desenvolvidos ou adaptados para o território brasileiro por meio de outras diretrizes existentes. Podendo ser escolhida uma ou disponibilizar todas as diretrizes de alta qualidade que atendam o problema de saúde em questão. Para adaptação, pode ser utilizada a metodologia ADAPTE<sup>11</sup> , que utiliza várias ferramentas para garantir a melhor evidência científica. Fases do Desenvolvimento das diretrizes:  
8  
- Designado o grupo que será responsável por redigir as diretrizes, desenvolver a adaptação e as recomendações (Apêndice 1). Constituir o grupo consultivo que deverá ser formado por uma equipe multiprofissional com experiência na área de ortopedia (Apêndice 1)  
- Definição do escopo das diretrizes pelo grupo elaborador para a escolha das questões que serão abordadas nas diretrizes.  
- As estratégias de busca foram definidas a partir de questões-chave, que são perguntas contendo a seguinte informação: qual a população, intervenção tecnológica, comparação tecnológica, desfechos/resultados e desenho do estudo a ser avaliado. A estrutura da pergunta de pesquisa nesse formato é conhecida como pergunta PICOS. Foi priorizada a seleção de sínteses da literatura no formato de diretrizes clínicas ( _guidelines_ ).  
- As buscas na literatura foram realizadas pelos bibliotecários do INTO,    por meio das  bases MEDLINE/PubMed, por meio da interface MeSH (Medical Subject Heading); na base LILACS,  por meio das interfaces DeCS (Descritores em Ciências da Saúde) e na base Cochrane Library. Para a definição da estratégia de   busca  referente a cada pergunta,  foram adotados os seguintes critérios: definição dos descritores de assunto, mais a sensibilização dos termos, com a utilização dos “entry terms” e operadores booleanos referentes à população em abrangência _"Aged” [Mesh] or Elderly_ , ao problema em evidência "Osteoarthritis, Hip” [Mesh] OR hip osteoarthritis OR osteoarthritides, hip OR coxarthros* [tiab] OR osteoarthritis of the hip, à exclusão de estudos não relevantes (animal [mH] NOT human [mh]) OR cadaver [mh] OR cadaver* [tiab], às intervenções adotadas “Radiography” [Mesh], mais entry terms Nonpharmacological [tiab], mais entry terms; "Drug Therapy” [Mesh], mais entry terms; "Arthroplasty, Replacement, Hip” [Mesh], mais entry terms, desfechos _"Quality of Life” [Mesh], mais entry terms_ e aos filtros _systematic [sb] OR "Guideline" [pt] OR “MetaAnalysis” [pt]_ relevantes a cada estudo.  
- A descrição detalhada da busca para cada pergunta, referente às presentes Diretrizes, encontra-se descrita no **Apêndice 2** .  
- O corpo de evidências relativo a cada desfecho das perguntas formuladas teve sua qualidade avaliada segundo os critérios do sistema GRADE (Grading of Recommendations Assessment, Development and Evaluation)<sup>12</sup> e foi uma das bases para a elaboração das  recomendações, sendo que tais recomendações basearam-se na avaliação das diretrizes (AAOS e NICE) e na experiência da equipe interdisciplinar do INTO.  
Foram selecionadas 9 diretrizes, sendo que cinco delas foram excluídas por não se enquadrarem no escopo das  Diretrizes.  Das quatro selecionadas,   duas foram excluídas por serem  atualização de diretrizes originais,  e  duas dessas Diretrizes foram selecionadas  para serem avaliadas  quanto a sua qualidade metodológica, por cinco componentes independentes  
9  
e mascarados, utilizando o instrumento AGREE<sup>15</sup> (Apêndice 3).  Após avaliação e consenso com o grupo,    foram escolhidas as diretrizes do National Clínical Guideline Centre (NICE) - National Clínical Guideline Centre,  The Management of Hip Fracture in Adults]London: National Clínical Guideline Centre. Available from: <u>www.ncgc.ac.uk</u><sup>13</sup> e da American Academy of Orthopaedic Surgeons (AAOS) - Management of Hip Fractures in the Elderly Evidence- Based Clínical Practice Guideline adopted by the American    Academy of Orthopaedic Surgeons, september 5, 2014. _<u>http://www.aaos.org/research/guidelines/HipFxGuideline.pdf</u>_<sup>_14_</sup>  
- Sendo iniciada a adaptação das diretrizes para a realidade brasileira e para as respostas das 16 questões que foram formuladas no escopo – Apêndice 4  
 O NICE realizou uma busca sistemática na literatura para responder as perguntas das diretrizes, nas bases de dados MEDLINE, Embase, Cochrane Library e específicos como PsycInfo ( para opiniões dos pacientes e questões de educação do paciente) e para avaliação econômica. A busca na literatura cinza ou artigos não publicados não foi realizado, sendo restringida aos artigos publicados no idioma inglês e atualizadas até 31 de agosto de 2010 (no Apêndice D – NICE)<sup>13</sup> . A qualidade da evidência dos estudos incluídos (estudos randomizados, observacionais, diagnósticos e qualitativos), foi avaliada com a metodologia GRADE<sup>12</sup> (na Tabela 3.1, 3.2, 3.3 - NICE), sempre que possível foi realizada meta-análise para combinar os resultados de estudos para cada pergunta de revisão, usando o software Cochrane Review Mananger ( _RevMan_ 5),  foi calculada as razões de risco (risco relativo) para os desfechos binários, para os desfechos contínuos foi utilizado o método de variância inversa para agrupamento de diferença de média ponderada e para os estudos que tiveram escalas diferentes foi utilizada a diferença de média padronizada. Foi avaliada a heterogeneidade estatística com o teste Qui- quadrado para significância de p< 0,05,  a análise de sensibilidade com base na qualidade dos estudos, com atenção para a alocação sigilosa e perda de acompanhamento. Mais detalhes no Apêndice C – NICE<sup>13</sup> .  
A AAOS<sup>14</sup> realizou uma busca para a revisão sistemática na literatura, em quatro bases de dados eletrônicos _PubMed, EMBASE, CINAHL e The Cochrane Central Register of Controlled Trials_ . A busca eletrônica foi complementada com uma busca manual e os artigos incluídos foram publicados antes de Abril de 2013 (Apêndice V – AAOS). A qualidade da evidência dos estudos incluídos na revisão sistemática ou meta-análise foram avaliados e classificados de acordo com o sistema de avaliação da AAOS, como de alta qualidade se nenhum domínio ou um é falho, se dois ou três domínios são falhos é classificado como moderado e se quatro ou cinco domínios são falhos é rebaixada para baixa qualidade e se seis ou mais domínios são falhos é rebaixada como de muito baixa qualidade, sendo excluídos das  
10  
diretrizes (na tabela 1 – AAOS).O domínio poder estatístico é considerado falho se o tamanho da amostra é muito pequeno para detectar pelo menos um efeito pequeno de 0,2. Para avaliar a qualidade metodológica dos estudos incluídos foi utilizado o sistema GRADE. A aplicabilidade ou validade externa dos estudos (um dos fatores utilizados para determinar a força de uma recomendação) foi avaliada pelo instrumento PRECIS (na Tabela 2 e 3 – AAOS), que é desenhado para ensaio clínico randomizado (ECR), mais também pode ser utilizado para outros desenhos de estudos. O instrumento possui 10 perguntas, quatro domínios e de acordo com os resultados a sua aplicabilidade é classificada como “alta”, “moderada” ou “baixa”. Os estudos de triagem e teste diagnóstico foram avaliados com o instrumento QUADAS (na Tabela 4 – AAOS), que possui seis domínios e sendo caracterizado que um estudo não tem falhas em qualquer de seus domínios como sendo de "alta" qualidade, um estudo que tem um domínio falho como sendo de qualidade "Moderada", com dois domínios falhos como sendo de “baixa” qualidade e com três ou mais domínios falhos como sendo de "Muito baixa" qualidade. Os estudos de prognóstico foram avaliados com uma estratégia baseada em cinco domínios conduzidos usando uma série de perguntas _a priori_ , e marcado por um programa de computador e caracterizados os elementos como sendo de alta qualidade se não há falhas em qualquer um dos domínios relevantes, sendo de qualidade "Moderada" se um dos domínios é falho, de baixa qualidade se houver dois domínios falhos, e como muito baixa qualidade, se três ou mais domínios relevantes são falhos.  Mais detalhes no apêndice  VI e XII da AAOS 14. Foi utilizado o programa estatístico STATA 12, para determinar a magnitude, e / ou intervalos de confiança de 95% e o efeito do tratamento. A análise estatística para determinar a acurácia dos dados de diagnósticos foi calculada a razão de verossimilhança, sensibilidade, especificidade e intervalos de confiança de 95%, baseados em tabelas de contingência dois por dois, extraídas dos estudos incluídos. Para os dados reportados a significância, a diferença de média entre os grupos e o intervalo de confiança de 95% foi calculado e um teste t bicaudal de grupos independentes foi utilizado para determinar a significância estatística. Nos estudos que relatam o  erro padrão ou intervalo de confiança o desvio padrão foi calculado pelos autores e nos estudos que não relatam as medidas de dispersão o teste estatístico foi realizado pelos autores e o resultado considerado como evidência. foram considerados estatisticamente significativos os valores de p <0,05. As metaanálises foram realizadas utilizando o método de efeitos aleatórios de DerSimonian e Laird e sendo necessário no mínimo quatro estudos. A heterogeneidade foi avaliada utilizando o teste I2, sendo considerado como evidência o I2 menor que 50% e o I2 maior que 50%, não foi considerado como evidência para as meta-análises.Todas as meta-análises foram realizadas  
11  
usando STATA 12 e o comando "Metan". Foi calculado o número necessário para tratar e o Odds ratio.  
- Foram desenvolvidos vídeos educativos e uma cartilha com o intuito de orientar os pacientes e seus familiares sobre os cuidados pós-cirúrgicos, buscando a redução de possíveis complicações.  
Figura 1  Níveis da Qualidade da Evidência  
_Fonte: Elaboração GRADE working group – http:// www.gradeworkinggroup.org_

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1– Avaliações por Imagem** -->
A radiografia simples é o exame radiológico inicial em todos os grandes centros hospitalares  
<u>para o diagnóstico de fratura.  É consenso mundial o seu uso para esse diagnóstico, portanto as duas</u>  
|Si<br>|gnificado dosQuatro Níveis daqualidade da Evidê<br>|ncia<br>|
|---|---|---|
|Nível daQualidade|Descrição|Implicações<br>|
|ALTA|Estamos muito confiantes de que o verdadeiro<br>efeito fica perto da estimativa de efeito.|É improvável que pesquisa<br>adicional<br>mude<br>nossa<br>confiança na estimativa do<br>efeito.|
|MODERADA|Estamos<br>moderadamente<br>confiantes<br>na<br>estimativa de efeito. O verdadeiro efeito é<br>susceptível de ser próximo da estimativa do<br>efeito, mas existe a possibilidade que seja<br>substancialmente diferente.|Mais<br>pesquisas<br>são<br>susceptíveis de ter um<br>impacto importante sobre a<br>nossa<br>confiança<br>na<br>estimativa de efeito e pode<br>mudar a estimativa.|
|BAIXA|A nossa confiança na estimativa de efeito é<br>limitada.<br>O<br>verdadeiro<br>efeito<br>pode<br>ser<br>substancialmente diferente da estimativa do<br>efeito.|Mais pesquisas são<br>susceptíveis de ter um<br>impacto muito importante<br>sobre a nossa confiança<br>na estimativa de efeito e<br>pode mudar a estimativa.|
|MUITO BAIXA|Temos muita pouca confiança na estimativa de<br>efeito. O verdadeiro efeito provável é<br>substancialmente diferente da estimativa de<br>efeito.|Qualquer estimativa do<br>efeito é incerta.|  
diretrizes que serviram como fontes não analisaram estudos com evidência científica em relação a este exame.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Recomendação do NICE</u> -->
Com o intuito de obter um estudo radiológico simples com a maior qualidade possível, para avaliar a fratura do colo do fêmur; a imagem do quadril a ser avaliado na incidência anteroposterior deve ser realizada com o posicionamento do membro inferior  
12  
submetido a uma pequena rotação interna desse membro (10º), buscando,  com isso,  deixar o colo do fêmur paralelo à mesa radiológica (nessa posição, normalmente o pequeno trocanter fica menos  
evidente na cortical femoral medial). Quanto maior a rotação externa do membro mais evidente se  
**Considerações: A radiografia simples é o exame de escolha para o diagnóstico inicial das fraturas do quadril, devendo o paciente ser avaliado na incidência anteroposterior com o posicionamento do membro inferior com uma pequena rotação interna (10º).** <mark>CS</mark> tornará o pequeno trocanter.  Sendo importante também a obtenção de uma radiografia panorâmica da bacia, buscando avaliar outros possíveis sítios de lesão e uma incidência em perfil (“ _Cross Table_ ”).

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.2 – Radiografia simples do quadril em três incidências** -->
A maioria das fraturas de quadril pode ser facilmente diagnosticada por meio de radiografias. Em relação à fratura do colo de fêmur, o paciente deverá ser colocado em posição supina. <u>Evidência Científica:</u>  
NICE: Com evidência científica de sensibilidade de 90% a 98% na radiografia do quadril, enfatizando a obtenção de uma terceira incidência radiográfica (10º de rotação interna), aumenta a acurácia. AAOS: Recomenda para pacientes com suspeita de fratura de colo do fêmur que os eles  sejam inicialmente avaliados com radiografias nas seguintes incidências: imagem panorâmica de bacia em anteroposterior (AP) e uma imagem lateral do quadril a ser avaliado (“ _Cross Table_ ”).  
<u>Evidência  Científica:</u>  
As duas diretrizes não classificaram a qualidade da evidência científica devido ao fato de o  
**Considerações: Os pacientes com suspeita de fratura de quadril devem ser avaliados inicialmente com radiografias simples com três incidências (anterior, posterior e uma imagem lateral) para uma melhor visualização do colo do fêmur.** ~~<mark>S</mark>~~ <mark>S</mark> Raio-X  simples ser um exame reconhecido mundialmente por sua acurácia e sensibilidade de 90% a 98% na radiografia do quadril.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.3- Fratura Oculta** -->
A prevalência de fraturas ocultas do colo do fêmur está estimada como sendo de 3% a 9% (NICE), em algumas séries (esta variação pode estar relacionada à avaliação radiográfica inicial com um padrão inadequado na obtenção das imagens).  Devemos lembrar que o atraso no diagnóstico está invariavelmente  associado a piores resultados clínicos.  
<u>Evidência Científica:</u>  
13  
NICE: Recomenda que a radiografia inicial para suspeita de fratura de colo de fêmur seja na posição AP de toda a pelve, juntamente com a projeção lateral do quadril e, caso não se evidencie nenhuma fratura, uma terceira incidência  deverá ser realizada centrada no quadril e com 10º de rotação interna para posicionar o colo do fêmur em 90º em relação ao feixe de  raios-X, para uma melhor visualização do colo de fêmur.  
AAOS: Recomenda para pacientes com suspeita de fratura de colo do fêmur que eles sejam inicialmente avaliados com radiografias nas seguintes incidências:  imagem panorâmica de bacia em  
**Considerações: Para pacientes com suspeita de fratura do colo do fêmur é indicada imagem radiográfica em três incidências: panorâmica da bacia em AP, perfil do quadril (“Cross Table”) e  AP do quadril com 10º de rotação interna.**  
anterior e posterior (AP) e uma imagem lateral do quadril a ser avaliado (“ _Cross Table_ ”).

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.4-Ressonância Magnética** -->
Qualidade da Evidência: Moderada (AAOS)

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e NICE estão Relacionados no Apêndice 5  -  Tabela 1** -->
AAOS: A RM é o método de imagem avançada de escolha para o diagnóstico de fratura de quadril presumida e não aparente nas radiografias iniciais.  
NICE: A RM é o método de imagem de escolha para fratura oculta com alta precisão e  sensibilidade de 100% e com especificidade entre  93% e 100%, dependendo da experiência e da habilidade do radiologista interpretar as imagens.  
<u>Evidência Científica:</u>  
AAOS - Avaliou cinco estudos com baixa qualidade, sendo evidenciado que,  para avaliar pacientes com história clínica de fraturas com radiografias negativas, a RM demonstra capacidade de identificar fraturas,   especialmente em pacientes mais idosos. Três estudos que abordaram custos e desconforto do paciente com uma RM “limitada”  puderam  identificar fratura oculta do quadril (esses exames limitados foram obtidos com menor custo e menor duração que uma RM normal).  
NICE - Não identificou estudos que atendessem os critérios de inclusão.  
<u>Riscos e Danos da Implementação:</u>  
14  
Não deve ser utilizada em pacientes com implantes ou materiais metálicos, assim como naqueles pacientes que não toleram a realização do exame devido à sensação de claustrofobia (NICE).  
**Considerações: A ressonância magnética é o método de imagem de escolha para o diagnóstico da fratura oculta do colo de fêmur, que não foi diagnosticada nas radiografias simples, com uma sensibilidade de 100% e com especificidade entre 93% e 100% (dependendo da experiência do radiologista).** <mark>_ll</mark>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.5 - Tomografia Computadorizada** -->
AAOS: Não recomenda para fratura oculta de quadril devido à baixa qualidade dos estudos avaliados e pela exposição à radiação.  
NICE: Considera a Tomografia Computadorizada, na ausência da RM nas primeiras 24 horas, evitando retardo na cirurgia. **Considerações: A tomografia computadorizada deverá ser a imagem de escolha na ausência da ressonância magnética, nas primeiras 24 horas da ocorrência da fratura, para se evitar o retardo da cirurgia e complicações clínicas para o paciente.** <mark>_</mark>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.6 - Cintilografia Óssea Evidência Científica:** -->
AAOS: Um estudo com baixa qualidade metodológica que avaliou a sensibilidade da cintilografia óssea em fraturas ocultas do colo do fêmur relata precisão equivalente quando comparada a RM, a qual demonstra uma melhor resolução espacial e fornece um melhor diagnóstico nas primeiras 24h, comparativamente à cintilografia óssea obtida com 72h.  
NICE: Dois estudos clínicos de baixa qualidade metodológica avaliaram que ocorre, comparando-se  
**Considerações: A cintilografia óssea é um método de imagem com precisão equivalente à RM nas fraturas ocultas de colo de fêmur, porém sendo necessário aguardar 72 horas para que o exame possa ser realizado (evitar exames falso-negativos), causando um retardo na cirurgia. No Brasil, não costuma estar disponível a cintilografia óssea na maior parte dos hospitais de emergência, o que torna inviável a sua utilização para o diagnóstico da fratura oculta do colo do fêmur.** <mark>le</mark> a sensibilidade da cintilografia óssea com a RM, uma variação de 75% a 98%, sendo que a especificidade para a cintilografia óssea é de 100%.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.1.7 - Ultrassonografia (US)** -->
15

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Evidência Científica:</u> -->
NICE: Recomenda a US por estar disponível na maior parte dos hospitais e fora do horário do expediente,  por não utilizar radiação ionizante  e   por ser de baixo custo.   Para realização e interpretação adequada do exame,  é necessário um profissional habilitado. Esse exame pode detectar irregularidades na superfície óssea, derrame ou hemorragia em pacientes com fraturas.  Para isso,  é necessária uma confirmação por ressonância magnética ou tomografia computadorizada.  
Sensibilidade: Em comparação com a RM, a US foi de 100% e especificidade de 65%,  significando que todos os pacientes que apresentavam fraturas foram diagnosticados, e 35% desses pacientes com diagnóstico positivo não apresentavam fraturas. O exame apresenta uma alta porcentagem de falsos positivos,  sendo que os pacientes que tinham diagnóstico negativo realmente não apresentavam fraturas.  
<u>Evidência Científica:  Foi identificado um estudo que compara a RM com  a  US com baixa qualidade</u> metodológica. AAOS: Não indicou a ultrassonografia. **Considerações: A ultrassonografia é um método de imagem barato e não utiliza radiação, com sensibilidade de 100% comparada à RM e especificidade de 65%, sendo que necessita de um profissional habilitado e treinado para interpretação adequada. No momento, a US não está sendo indicada, por não ser uma técnica disseminada e por não haver número satisfatório de profissionais habilitados para a interpretação.** <mark>«<_<,</mark>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Estudos Futuros de Imagem:** -->
Pelo NICE e pela AAOS, a ressonância magnética foi indicada como o padrão ouro para o diagnóstico da fratura oculta do colo do fêmur (presença de suspeita clínica de fratura com radiografias iniciais negativas). O NICE indica a tomografia computadorizada (TC) nos seguintes casos: o paciente **Considerações: Para pacientes com radiografias iniciais negativas para fratura de colo de fêmur, porém com suspeita clínica de fratura, uma alternativa para os serviços de saúde que não possuem acesso às tecnologias diagnósticas recomendadas ao atendimento (RM e TC) é a mobilização com bloqueio de nervo, com realização de manobras de tração e rotação interna e externa, associada à radiografia simples.** <mark>——_</mark> apresenta fatores que contraindicam a realização de RM (Ex.: marca-passo, implante metálico) ou na impossibilidade de acesso ao exame, nas primeiras 24h.  E a AAOS não recomenda a realização da TC.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.2 – Tempo Recomendado para Abordagem Cirúrgica** -->
**Evidência Científica:  Os estudos da AAOS e  do NICE estão Relacionados no Apêndice 5 - Tabela 2**  
16  
Há pouca evidência científica sobre o tempo adequado para o paciente ser submetido à cirurgia após fratura do colo do fêmur, segundo as avaliações das diretrizes do NICE e a da AAOS. Estudos com evidência científica moderada demonstram que em,  até 48h,  o paciente deve ser operado para aliviar a dor,  possibilitar melhor reabilitação  e  evitar complicações.  De acordo com a AAOS e o NICE,   o ideal seria o paciente ser operado em até 36h.  
O retardo injustificado na realização do tratamento cirúrgico contribui, de maneira significativa,  para o aumento da morbiletalidade segundo meta-análise e revisão sistemática envolvendo 257.367 pacientes<sup>8</sup> .  No Canadá, 65% das fraturas proximais do fêmur são operadas nos dois primeiros dias de internação. Esse índice chega a 93% na Noruega<sup>8,9</sup> .  Nos artigos brasileiros que analisaram as fraturas do fêmur, os pacientes que tiveram uma abordagem cirúrgica em até 48 horas após a lesão  apresentaram melhores resultados,  independentemente do segmento do fêmur acometido<sup>9,16,17</sup> .  
O NICE recomenda que comorbidades comuns nos idosos sejam tratadas com a maior brevidade possível, visando a evitar o atraso da cirurgia dos pacientes com fratura de colo de fêmur. E destaca os seguintes achados:  
- Anemia  
- Anticoagulação  
- A depleção volumétrica  
- Desequilíbrio eletrólitos  
- Diabetes não controlada  
- Insuficiência cardíaca não controlada  
- Arritmia cardíaca ou Isquemia controlada  
- Infecção Pulmonar Aguda  
- Exacerbação de Doenças Pulmonares Crônicas

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Evidência Científica:</u> -->
AAOS: Avaliou nove estudos com evidência científica moderada que observaram a recuperação do paciente em relação ao tempo para a realização da cirurgia, à mortalidade, à dor, a complicações ou ao  tempo de permanência, sendo que a cirurgia realizada até 48 horas após a internação está associada a melhores resultados.  
NICE:  Avaliou dez estudos com evidência científica baixa que  observaram a eficácia clínica da cirurgia precoce (com intervalo de 24, 36 e 48 h) em relação à incidência de complicações, tais como mortalidade, pneumonia, lesão por pressão, disfunção cognitiva e maior tempo de internação.  
17  
As duas diretrizes (AAOS e NICE) recomendam que a  cirurgia precoce realizada em até 48h após a fratura do colo do fêmur  representa a forma mais eficaz para o alívio da dor, acelerando a reabilitação e reduzindo as complicações.  
<u>Riscos e Benefícios:</u>  
Riscos: Desenvolvimento de pneumonia, lesão por pressão, dificuldades para mobilização no leito, delirium, aumento da mortalidade.  
Benefícios: Alivio da dor, mobilização e inicio da fisioterapia precoce, menor tempo de internação  
**Considerações:**  
**O tratamento cirúrgico da fratura do colo do fêmur deve ser realizado com a maior brevidade possível, desde que o paciente se encontre clínicamente apto para a cirurgia proposta (osteossíntese ou artroplastia).  É fundamental que se evite ultrapassar um período superior há 48h, a partir da ocorrência da fratura.**  
hospitalar e reintegração familiar e na sociedade.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 3** -->
A analgesia visa a eliminar ou minimizar a dor a níveis toleráveis em pré e pós- operatório, contribuindo para uma satisfatória evolução clínica, reabilitação fisioterápica e alta hospitalar precoce.  
O cuidado multidisciplinar precoce referente a aspectos como analgesia sem uso do opioides, hidratação, fisioterapia respiratória e demais cuidados clínicos  reduz  significativamente a mortalidade nos primeiros 30 dias e  até no período de um ano<sup>17,18</sup> .  
Ambas as diretrizes do NICE e da AAOS  recomendam a analgesia  pré- e pós- operatória por diminuir o sofrimento do paciente;  por possibilitar um atendimento mais efetivo pela equipe de enfermagem e o bem-estar do paciente;   por reduzir o risco de delírium  e, finalmente,  por facilitar o retorno à mobilidade e à independência. Os nervos que suprem o fêmur proximal  também podem ser bloqueados pela injeção de anestésico local (NICE).  
A administração de um anestésico local resulta em perda temporária da função nervosa na fáscia ilíaca femoral ou compartimento do quadril lesionado, com redução significativa da dor préoperatória relatada em uma escala analógica visual, redução na incidência de delirium pós-operatório (AAOS). Essas administrações são conhecidas como bloqueio de nervo e são administradas aos pacientes para reduzir a dor  quando  os analgésicos simples e opioides não forem suficientes.  
Analgésicos sistêmicos utilizados para o alívio da dor em fratura do colo do fêmur incluem analgésicos simples,  tais como o paracetamol e opioides. O NICE e a AAOS não descrevem o uso  
18  
de anti-inflamatórios não esteroides, apesar de terem incluído estudos que comparam o uso deles com bloqueios anestésicos.  Os anti-inflamatórios não esteroides são contraindicados devido ao risco que os idosos correm de desenvolver eventos adversos, como hemorragia gastrointestinal, nefrotoxicidade e retenção de líquidos.  
O NICE e a AAOS recomendam avaliar a dor do paciente nestas situações:  
- Imediatamente após a apresentação no hospital;  
- Após a administração de analgesia inicial,   a avaliação da dor deve ser feita em até 30 minutos;  
- Até que esse paciente seja internado na enfermaria, ele deve ser avaliado, em relação à dor,  de hora em hora;  
- Durante todo o período de internação, tal avaliação deve ser feita regularmente como parte das observações de rotina de enfermagem;  
O bloqueio, que é um procedimento empregado para diminuir a dor,  não deve ser utilizado para retardar a cirurgia.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Evidência Científica:</u> -->
AAOS: Avaliou seis estudos de alta qualidade metodológica e um de qualidade metodológica moderada, que observaram o efeito da analgesia regional na redução da dor pré- operatória após a fratura do colo do fêmur em hospitais de emergência.  Seis estudos avaliaram a analgesia local com anestésico administrado na fáscia ilíaca femoral ou no compartimento do quadril fraturado, por profissionais de especialidades diferentes (médicos de emergência, anestesiologistas e cirurgiões ortopédicos). O sétimo estudo avaliou a administração da anestesia epidural no pré-operatório em pacientes após fratura do quadril com doença cardíaca ou com risco elevado para doença cardíaca, sendo observada uma redução em eventos de isquemia miocárdica no pré-operatório.  Os estudos não relataram complicações com o uso de anestésico que resulta na perda temporária da função nervosa no compartimento do quadril fraturado.  
NICE: Avaliou uma revisão sistemática Cochrane, na qual foram incluídos 17 estudos randomizados e quase randomizados que observaram pacientes com fratura proximal do fêmur submetidos a bloqueios nervosos (incluindo epidural) _versus_ ausência de bloqueios nervosos. No grupo do bloqueio foram incluídos qualquer tipo de bloqueio de nervos (subcostal, lateral cutâneo, femoral, triplo, psoas) e no grupo da ausência de bloqueio (analgésicos sistêmicos ou placebo). Ficou evidenciado que o bloqueio periférico é melhor. O NICE considera que o uso de analgésico simples (paracetamol) representa a primeira opção para o controle clínico da dor, sendo o uso de analgésicos de ação central e bloqueios anestésicos opções subsequentes na linha terapêutica.  
<u>Riscos e Benefícios:</u>  
Riscos: Reação alérgica, hipotensão, lesão neurológica.  
19  
Benefícios: Melhora da dor,  mobilização para exames e cuidados de enfermagem,   diminuição da mortalidade.  
**Considerações:**  
**É importante a reavaliação da intensidade da dor após a administração de um protocolo analgésico que deve ser realizada entre 30 e 60 minutos, após administração do analgésico. Inicialmente, deve ser realizada com a administração de analgésicos simples, como paracetamol ou a dipirona. A dipirona (analgésico simples) 19, 20, 21, 22, 23, 24,25 é largamente utilizada no Brasil, substituindo o paracetamol, desde 1922, e é administrada para analgesia e como antitérmico, não sendo comercializada nos EUA e nos países europeus, devido a ter como evento adverso a granulocitose. A ANVISA realizou, em 2001, um “Painel Internacional de Avaliação da Segurança da Dipirona” 20, baseado em evidências científicas, com o objetivo de promover um amplo esclarecimento sobre os aspectos de segurança desse medicamento. Como resultado desse evento, houve consenso de que os dados científicos disponíveis não apontam a ocorrência, em nossa população, de riscos suficientes para contraindicar a utilização de tal analgésico.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 – Tabela 4** -->
A proposta cirúrgica deve ser discutida previamente com toda a equipe médica, considerandose a condição clínica do paciente, a capacidade prévia de deambulação e o status mental.  
Todo empenho deve ser feito para que a cirurgia seja realizada nas primeiras 48 horas, uma vez que, após esse período, observou-se maior tempo de internação e aumento da morbiletalidade<sup>8,</sup> 26.  Certas condições justificam algum atraso cirúrgico visando à estabilização fisiológica do paciente<sup>26</sup> .  
São causas aceitáveis para postergar a cirurgia<sup>7,27</sup>  
- Concentração de hemoglobina <9 g/dl-1 ou 10 g/dl-1  e  na presença de coronariopatia;  
- Concentração de sódio plasmático < 120 ou > 150 mmol/L  oude  Potássio < 2.8 ou > 6.0 mmol/L;  
- Diabetes mélito descompensada;  
- Falência ventricular aguda ou não compensada;  
- Arritmia cardíaca passível de correção com frequência ventricular > 120 min;  
- Infecção pulmonar com sepse;  
- Alteração reversível da coagulação.  
A analgesia deve ser estabelecida precocemente  ainda no pré-operatório,  por meio de bloqueio do nervo femoral. A dipirona ou o paracetamol deve ser utilizado, salvo contraindicações,  
20  
devendo-se evitar o uso de anti-inflamatórios não hormonais e opioides em virtude de seus paraefeitos. Deve-se considerar, ainda, que cerca de 40% dos pacientes com fratura do colo do fêmur apresentam disfunção renal, 35% possuem uma comorbidade  e 17% as duas, estando o comprometimento cardiovascular presente em 35% dos casos<sup>7</sup> .  
Embora o eletrocardiograma deva ser realizado rotineiramente, o ecocardiograma,  visando estabelecer a função cardíaca, deve ser restrito aos pacientes com dispneia em repouso ou a pequenos esforços ou na suspeita de estenose aórtica.  A sua realização não deve ser motivo para postergar a cirurgia<sup>27</sup> .  
O perfil eletrolítico, hematológico e a ureia plasmática devem ser analisados de rotina enquanto o estudo da coagulação e a radiografia do tórax somente são justificáveis se clínicamente indicados<sup>7</sup> .  
A anemia pré-operatória ocorre em aproximadamente 40% dos pacientes,  podendo dar-se devido à  fratura,  à doença crônica, ao mau estado nutricional ou à hemodiluição.  A transfusão sanguínea prévia deve ser considerada se o nível de hemoglobina for menor que 9 g/dl -1 ou,  10 g/dl -1  na presença de portador de  doença isquêmica cardíaca<sup>7,27</sup> .  
As fraturas do colo do fêmur têm o sangramento parcialmente contido pela cápsula articular, o que não ocorre com as transtrocanterianas e subtrocanterianas em que o hematoma,  a partir do foco de fratura, pode envolver perda superior a um litro de sangue<sup>7</sup> . Das fraturas proximais do fêmur,  cerca de 50% são extracapsulares, e as demais intracapsulares<sup>7</sup> . Os pacientes em uso de tromboprofilaxia devem ter a conduta anestésica balizada pelos protocolos estabelecidos para as diferentes drogas anticoagulantes (para a escolha do tipo de anestesia), nas cirurgias de emergência em que a anticoagulação não foi suspensa 24 horas antes da cirurgia. Evidências mostram que o uso da aspirina e do clopidogrel não deve ser justificativa para postergar a cirurgia. A AAOS avaliou seis estudos de baixa qualidade  que não apresentaram nenhuma diferença em atrasar ou não a cirurgia de fratura de colo de fêmur  em pacientes com terapia antiplaquetária ( **Apêndice 5 -  Tabela 4.1** - Clopidogrel e Aspirina).  
<u>Evidência Científica:</u>  
AAOS: Avaliou dois estudos de alta qualidade científica e sete de qualidade moderada que comparam a anestesia geral com a raquianestesia em pacientes submetidos à cirurgia de fratura de quadril, evidenciando que os desfechos são semelhantes para a anestesia geral e raquianestesia para pacientes idosos submetidos à cirurgia de colo do fêmur.  
NICE: Avaliou uma revisão Cochrane (Parker et al 2004),  que incluiu 22 ensaios clínicos randomizados com baixa qualidade científica, com um total de 2.567 participantes que foram submetidos à cirurgia do colo do fêmur, em que foram analisados desfechos, como mortalidade, tempo de permanência hospitalar, confusão mental aguda, pneumonia, infarto agudo do miocárdio,  
21  
embolia pulmonar e trombose venosa profunda, sendo evidenciada uma redução estatística e clínicamente significativa na mortalidade precoce (até para 1 mês) em pacientes com a anestesia regional em comparação com aqueles que foram submetidos à anestesia geral. Houve uma melhora clínica, mas não na confusão mental  pós-operatória e na  redução da incidência de trombose venosa profunda em doentes que receberam anestesia regional em comparação com a geral. E não houve diferença estatisticamente significativa na duração da estadia hospitalar, vômitos, pneumonia, infarto do  miocárdio e embolia pulmonar.  
<u>Riscos e Benefícios:</u>  
Riscos: Hipotensão, reação alérgica, depressão sensorial e respiratória. Benefícios: Melhora da dor, mobilização e recuperação precoce.  
**Considerações:**  
- **Anestesia – A opção pela técnica anestésica deve considerar o procedimento cirúrgico e o estado clínico do paciente. O bloqueio do nervo femoral deve ser realizado para analgesia pré-operatória o mais precocemente possível, seja em dose única ou com infusão contínua de AL (anestésico local). A utilização de opioide não é recomendada por promover depressão sensorial e respiratória. Este, quando utilizado, deve ter suas doses reduzidas em pelo menos 50% devido à diminuição da função hepática e renal do idoso.**  
- **A monitorização per-anestésica de rotina deve ser observada, podendo incluir a diurese, pressão arterial invasiva, pressão venosa central e outros parâmetros hemodinâmicos, desde que as condições clínicas e cirúrgicas requeiram. É o caso, por exemplo, dos portadores de função ventricular esquerda limitada submetida à cirurgias de revisão ou fraturas periprotéticas.**  
- **O índice biespectral (BIS) auxilia na orientação da profundidade do plano anestésico, porém deve-se considerar que pode apresentar níveis iniciais anormalmente baixos nos casos de demência ou uso abusivo de álcool.**  
- **O acompanhamento da perda sanguínea e do teor hemoglobina de forma seriada indicará a necessidade de reposição de hemácias.**  
- **O posicionamento na mesa cirúrgica deve ser supervisionado pelo anestesista visando à boa acomodação do paciente. O membro superior homolateral ao cirúrgico deve permanecer sobre o tronco de forma contida, para possibilitar o curso do intensificador de imagem no per-operatório.**  
- **Como a mesa de tração é normalmente utilizada, deve-se observar para que o posicionamento do paciente seja adequado, protegendo-se a genitália e acomodando-se os membros superiores de forma confortável. O membro inferior contralateral não deve permanecer em nível inferior ao do tórax, pois pode levar à diminuição do retorno venoso devido à estase sanguínea, agravando a hipotensão arterial potencializada pela anestesia.**  
- **É importante o uso de dispositivos que minimizem a perda calórica, inclusive, com o aquecimento das soluções infundidas.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.4.1 Técnicas Anestésicas** -->
**Bloqueios do neuroeixo** -  Mostram-se adequados e preferenciais na maioria dos casos, notadamente o subaracnoide. É importante a realização prévia do bloqueio do nervo femoral, para que o paciente  
22  
possa ser posicionado em decúbito lateral de forma confortável, sem ocorrência de dor para sua execução.  
Uma coorte que analisou 18.158 pacientes com média de idade de 82 anos e submetidos a tratamento cirúrgico de fraturas proximais do fêmur, por meio de fixação interna, hemiartroplastia ou artroplastia total do quadril,  inferiu que  os desfechos avaliados foram mortalidade intra-hospitalar, complicações pulmonares (pneumonia por aspiração ou infecciosa, insuficiência respiratória) e complicações cardiovasculares (infarto agudo do miocárdio, insuficiência cardíaca congestiva ou parada cardíaca), sendo observado que os pacientes submetidos à anestesia regional tiveram uma menor chance de complicações pulmonares (OR: 0,752, IC 95% 0,637-0,887 _P_ < 0,0001) e uma menor  probabilidade de mortalidade intra-hospitalar (OR: 0,710, IC 95% 0,541 - 0,932 _p_ = 0,014) e não sendo encontrada  complicações cardiovasculares (OR: 0,877, IC 95%   0,748 – 1,029 _p_ = 0,107) 28 .  
Uma meta-análise que envolveu 18.715 pacientes submetidos a cirurgias de fraturas proximais do fêmur recomendou a anestesia regional como técnica preferencial<sup>28</sup> devido aos seus melhores resultados,.  
As doses de AL (anestésico local) devem ser criteriosas, pois bloqueios que atingem níveis altos produzirão bloqueio simpático extenso com hipotensão arterial grave piorada pelo precário estado de hidratação que pode estar presente.  Essa ocorrência é deletéria ao idoso nos aspectos cardíaco, renal e neurológico, devido à presença frequente de disfunção vascular.  Seu tratamento deve ser imediato, sendo que o uso de vasopressores deve ser criterioso, pois podem agravar uma disfunção renal pré-existente. A hidratação pré e peroperatória, respeitando-se a condição funcional cardíaca, associada a doses adequadas do anestésico local minimizam esse evento. Devem ser considerados os aspectos cirúrgicos, as condições clínicas e a estatura do paciente no estabelecimento da dose.  
**Bloqueio subaracnoide** - Na ausência de contraindicações, é a técnica preconizada e utilizada no INTO. O uso da bupivacaína isobárica possibilita menor dispersão cefálica da solução anestésica com consequente menor bloqueio simpático, desde que doses adequadas desta sejam utilizadas.  Na maioria dos casos,  situam-se entre 5-12 mg quando utilizada a bupivacaína<sup>7,29</sup> .  Um bloqueio sensitivo a partir de T12 é suficiente para a manipulação cirúrgica.  
Após a injeção da solução anestésica, a manutenção do paciente em decúbito lateral por alguns minutos permite uma maior fixação do AL no lado do membro afetado, desde que respeitada a baricidade da solução.  A mobilização do paciente para a mesa de tração frequentemente utilizada deve ser cuidadosa para que se evite dispersão cefálica da solução anestésica,  produzindo hipotensão arterial importante.  
23  
Estudo que envolveu 1.131<sup>29</sup> pacientes submetidos à osteossíntese proximal do fêmur, sendo 51,1% destes sob raquianestesia e 43,2% sob anestesia geral, observou queda na pressão arterial > 20% da basal ou < 90 mmHg em 29,4% e 34,2%, respectivamente. Entretanto, nesses pacientes em que o volume de bupivacaína hiperbárica utilizado foi > 1,5mL a hipotensão arterial (> 20% da basal) ocorreu em 83,9% dos casos, enquanto nos que receberam volume ≤ 1,5mL esta incidência foi de 26,8%. Os autores preconizam a utilização de menores volumes de anestésico local para que se minimize o uso de vasopressores e não seja necessária a infusão de maiores volumes de soluções para correção da hipotensão arterial, o que levará à hemodiluição.  
**Anestesia Peridural** – Não preconizamos essa técnica para anestesia no idoso,  pois implica maiores riscos de acidentes como injeção acidental intravascular ou subaracnoide e hematoma peridural. A necessidade de maiores doses de AL que serão somadas àquelas do bloqueio do nervo femoral realizado previamente para analgesia e posicionamento do paciente para o bloqueio no neuroeixo  é outro inconveniente. A dispersão peridural do AL no idoso é, frequentemente, errática,  podendo atingir níveis altos e bloqueio motor precário. A colocação e retirada de cateter peridural devem obedecer a critérios protocolares quando houver o uso de anticoagulantes.  
**Bloqueios Periféricos** – A área cirúrgica das fraturas proximais do fêmur pode envolver os nervos femoral, isquiático, obturatório, cutânea femoral lateral e subcostal.  
Para os pacientes com contraindicação aos bloqueios do neuroeixo e também para os portadores de doença cardíaca grave como a estenose aórtica grave, o bloqueio do plexo lombar associado ao do nervo isquiático via transglútea pode ser uma opção à anestesia geral.  
Entretanto, para os pacientes com idade avançada, distróficos, com grave comprometimento sensorial e do estado geral, em que o bloqueio simpático produzido pela anestesia no neuroeixo pode implicar grave descompensação hemodinâmica, pode-se utilizar como técnica anestésica apenas o bloqueio do nervo femoral e a infiltração local, acompanhados de sedação leve e ou pequenas doses de cetamina para a fixação das fraturas transtrocanterianas por procedimentos cirúrgicos pouco invasivos e de curta duração, como o uso de hastes bloqueadas ou parafusos.  
**Anestesia Geral** – Deve ser utilizada em pacientes com comprometimento da função pulmonar com necessidade de apoio ventilatório. A intubação traqueal deve ser realizada, para que se evite o risco de aspiração pulmonar de conteúdo gástrico,  que pode ocorrer por regurgitação silenciosa devido à incontinência gastroesofágica, frequente no idoso. A associação da anestesia geral com o bloqueio do nervo femoral é recomendada para analgesia per e pós-operatória.  
A maior facilidade de titulação da anestesia geral pode torná-la melhor opção, associada ao bloqueio do nervo femoral, nos pacientes muito debilitados incapazes de suportar a interferência simpática dos bloqueios neuroaxiais.  
24  
A associação da anestesia geral ao bloqueio do neuroeixo no paciente idoso  pode resultar em queda significativa da pressão arterial, o que é indesejável, devendo ser evitado<sup>29</sup> .  
**Pós-operatório** –  Deve ocorrer em unidade que proporcione adequada vigilância e controle das condições clínicas, com especial atenção à analgesia, devendo ser evitado o uso de anti-inflamatórios não hormonais. A administração de opioides deve ser criteriosa, respeitando-se as comorbidades e o estado geral do paciente, em função de sua metabolização e efeito depressivo central.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do  NICE estão Relacionados no Apêndice 5 - Tabela 5** -->
As fraturas do colo do fêmur se dividem em dois grupos,  se levarmos  em consideração o deslocamento dos fragmentos ósseos,  fator esse que apresenta repercussão na escolha do tratamento cirúrgico a ser adotado.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.5.1 - Fraturas de Colo de Fêmur não Desviadas** -->
Nesse tipo de fraturas, independentemente da idade cronológica ou fisiológica,  a modalidade de tratamento indicada consiste na realização de um procedimento de preservação, optando-se pela realização de osteossíntese com aplicação de implantes extramedulares (parafusos ou sistema de placa e parafuso deslizante com ângulo fixo).  
<u>Evidência Científica:</u>  
AAOS: Um estudo com alta qualidade científica indica que o tratamento por meio de fixação cirúrgica das fraturas não desviadas do colo do fêmur nos pacientes idosos é mais benéfico do que o tratamento não cirúrgico.  
NICE: Avaliou três coortes com evidência científica moderada,  evidenciando que o tratamento cirúrgico supera o conservador,  sendo o planejamento do procedimento cirúrgico proposto o fator de maior relevância para obtenção dos melhores resultados no pós- operatório.  
<u>Riscos e Benefícios:</u>  
Riscos: Encontram-se diretamente relacionados ao procedimento cirúrgico (anestesia, infecção na ferida operatória, falha de cicatrização, sangramento excessivo).  
Benefícios:  Melhor controle da dor,  menor tempo de internação, menos complicações respiratórias e cutâneas e melhora da mobilidade do paciente.  
25  
**As fraturas do colo do fêmur não desviadas têm indicação de tratamento cirúrgico.  Tal tratamento não se aplica caso o paciente não o aceite ou as condições clínicas não o permitam (risco> benefício).**  
**Considerações:**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.5.2 - Fraturas de Colo de Fêmur Desviadas** -->
Nesse grupo, a modalidade do tratamento indicado consiste na realização de um procedimento de substituição, podendo realizar-se uma artroplastia parcial ou uma artroplastia total, dependendo das características individuais do idoso a ser tratado: idosos com boa capacidade cognitiva, como atenção, juízo, raciocínio, memória e linguagem; com uma demanda funcional comunitária, ou seja, aqueles que realizam atividades comunitárias além das atividades domésticas e, finalmente, idosos sem fatores clínicos que impeçam a realização de um procedimento mais amplo   deverão ter como opção para o tratamento a realização de uma artroplastia total do quadril. O grupo de idosos que apresenta uma baixa capacidade cognitiva e uma baixa demanda funcional ou parcial, isto é, aqueles que realizam somente atividades domésticas e com fatores clínicos que levam à necessidade de um procedimento com menor tempo cirúrgico terá como opção para o tratamento a artroplastia parcial do quadril.  
<u>Evidência Científica:</u>  
AAOS: Avaliou seis estudos de alta qualidade e dezenove estudos com qualidade moderada que compararam diretamente a artroplastia (hemi- ou artroplastia total do quadril) com a fixação interna, demonstrando que a cirurgia de substituição apresentou melhores resultados.  
NICE: Avaliou três revisões sistemáticas de ensaios clínicos randomizados. No primeiro ensaio, foi avaliada a hemiartroplastia com a fixação interna;  no segundo,  a artroplastia total com a fixação interna  e, no terceiro,  a artroplastia total com a artroplastia parcial.  Nos dois primeiros ensaios,  foi evidenciada a artroplastia total,  sendo superior à fixação interna e,  no terceiro estudo,  a artroplastia total do quadril demonstrou-se superior à artroplastia parcial no grupo de idosos que apresentaram maior grau de demanda funcional.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios do Tratamento Cirúrgico:</u> -->
Riscos: Encontram-se diretamente relacionados ao procedimento cirúrgico (anestesia, infecção na ferida operatória, falha de cicatrização,  sangramento excessivo).  
Benefícios: Melhor controle da dor, menor tempo de internação, menos complicações respiratórias e cutâneas e melhora da mobilidade do paciente.  
26  
**Considerações: As fraturas desviadas do colo de fêmur apresentam melhores resultados funcionais e menores taxas de reoperação quando tratadas por artroplastia, em comparação com aquelas submetidas à redução aberta e fixação interna.** <mark>a</mark> **1.6 - Tração Pré-Operatória no Membro Fraturado Evidência Científica: Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 6**  
A tração pode ser aplicada de forma transesquelética ou cutânea no 1/3 proximal da tíbia, buscando reduzir a possibilidade de infecção no osso que será abordado cirurgicamente no futuro.  O objetivo da instalação de tração é  promover melhor controle em relação ao quadro álgico e encurtamento dos tecidos moles.  
<u>Evidência Científica:</u>  
AAOS:  Analisou sete estudos de qualidade moderada,  não observando redução da dor ou das doses de analgésicos, independentemente  do uso ou não de tração no período pré-operatório e também  um estudo de alta qualidade,  não evidenciando diferença no alivio da dor e  no número de analgésicos administrados, quando se compara  a tração esquelética.   A metade dos pacientes do grupo da tração acharam a aplicação dela  muito dolorosa.  
NICE: Não avaliou a evidência científica do uso da tração  pré-operatória.  
<u>Riscos e Benefícios:</u>  
Riscos:  Complicações locais no sitio de instalação da tração.  
Benefícios: Não evidenciados.  
**Considerações: O uso de tração pré-operatória nos pacientes com fraturas do colo do fêmur não está indicada, uma vez que os riscos desse procedimento mostraram-se superiores aos benefícios.** ~~<mark>—</mark>~~ <mark>_|</mark>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **1.7 - Exames** -->
**Evidência Científica:  Os estudos da AAOS e  do NICE estão  relacionados no Apêndice 5 – Tabela 20**  
**Avaliação pré- operatória dos níveis séricos de albumina e creatinina para avaliação de risco dos pacientes com fratura de quadril** .  
Albumina:  
AAOS: Avaliou um estudo com evidência científica moderada e quatro de prognóstico com baixa qualidade, que avaliaram o efeito dos níveis da albumina nos pacientes após a cirurgia do quadril, sendo evidenciado, em três deles, que níveis baixos de albumina têm uma correlação estatisticamente  
27  
positiva com a mortalidade e, em um deles, que a albumina está associada aos riscos maior de infecção e úlceras de pressão.  Foi também constatado que  o aumento de 1g/dl do nível de albumina sérica na alta está associada a uma melhora de 8,4% na medida de independência funcional após a reabilitação. NICE: O  NICE não avaliou a albumina e a creatinina separadamente. Creatinina:  
AAOS: Avaliou três estudos de baixa qualidade científica, nos quais foram avaliados os níveis de creatinina no pós-operatório de fratura de quadril, sendo evidenciado que o nível elevado de creatinina no 1º dia de pós-operatório aumentou significativamente as chances de mortalidade e que os níveis pré-operatórios e os do 4º dia de pós-operatório não foram preditores significativos de morte.  
NICE: O  NICE  não avaliou a albumina e a creatinina separadamente.  
**Considerações: O exame de creatinina deve ser solicitado como rotina pré-operatória para todos os pacientes, e a albumina deve ser solicitada caso necessário, após a avaliação clínica do paciente.** ~~—~~ <mark>|</mark>  
**CAPITULO 2 – TRATAMENTO**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 7** -->
A artroplastia parcial do quadril apresenta-se como uma opção no tratamento das fraturas desviadas do colo do fêmur do idoso, com tendência a ser usada em pacientes que apresentem a cartilagem acetabular preservada, uma menor demanda funcional oua necessidade de um tempo cirúrgico menor. Em relação aos resultados funcionais e radiográficos,  estudos de qualidade elevada e moderada evidenciaram equivalência no caso de implante, sendo a única diferença apresentada o custo mais elevado dos implantes bipolares.  
AAOS: Avaliou um estudo com qualidade científica alta e sete com qualidade moderada, nos quais foi comparada a hemiartroplastia unipolar com a bipolar.  
NICE: Não chegou a uma conclusão na analise comparativa entre a Prótese Bipolar versus a Unipolar. <u>Riscos  e Benefícios do Tratamento Cirúrgico:</u>  
Inexistem diferenças significativas quando comparamos os procedimentos cirúrgicos envolvendo as artroplastias unipolares e as bipolares.  
**Considerações:**  
**As próteses unipolares e bipolares não apresentam diferenças significativas no resultado funcional do paciente, sendo recomendadas as próteses unipolares por terem um custo menor.**  
28

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do  NICE estão relacionados no Apêndice 5 - Tabela 8** -->
A artroplastia total do quadril está indicada para pacientes idosos que apresentem fratura desviada do colo de fêmur, desgaste da cavidade acetabular, demanda funcional comunitária, condições clínicas e cognitivas que não contraindiquem a realização do procedimento.  Artroplastia parcial será usada em idosos com baixa demanda funcional, cavidade acetabular preservada e que apresentem condições cognitivas e clínicas que contraindiquem a cirurgia de substituição articular total.  
AAOS: Avaliou um estudo de alta qualidade e quatro de qualidade moderada, que compararam os dois procedimentos.  
NICE:  Avaliou uma revisão sistemática com sete ensaios clínicos de baixa à moderada qualidade científica que compararam a artroplastia parcial com a total.  
Os estudos das diretrizes americana (AAOS) e da britânica (NICE)  demonstram que ambas as artroplastias correspondem a boas opções de tratamento, sendo importante selecionar o implante de acordo com as características clínico-funcionais do idoso.  
<u>Riscos e Benefícios do Tratamento Cirúrgico:</u>  
Riscos: Encontram-se diretamente relacionados ao procedimento cirúrgico (anestesia, infecção na ferida operatória, falha de cicatrização, sangramento excessivo).  
Benefícios: Melhor controle da dor, menor tempo de internação, menos complicações respiratórias e  
cutâneas e melhora da mobilidade do paciente.  
**Considerações:**  
**A artroplastia total do quadril deve ser indicada para os pacientes idosos com fratura do colo do fêmur desviada que apresentem sinais de coxartrose (artrose do quadril), que têm demanda funcional comunitária (aqueles que podem realizar atividades comunitárias, além das atividades domésticas) e boa capacidade cognitiva (atenção, juízo, raciocínio, memória, linguagem), desde que existam condições clínicas favoráveis. Por outro lado, para os pacientes que apresentem uma demanda funcional comunitária de forma parcial (aqueles que realizam somente atividades domésticas), não possuem uma boa capacidade cognitiva e apresentem condições clínicas menos favoráveis ao procedimento cirúrgico mais prolongado, a hemiartroplastia do quadril deve ser a indicada.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **2.3 - Haste Femoral Cimentada** -->
**Evidência Científica:  Oos estudos da AAOS e do NICE estão relacionados no Apêndice 5 –**  
**Tabela 9**  
29  
Em relação à fixação da haste femoral, ela pode ser realizada por meio do uso de metilmetacrilato (cimento ósseo) ou  por meio de encaixe sob pressão ( _Press Fit_ ).  Estudos evidenciaram  não haver diferenças clínicas significativas em ambas  as  modalidades.  
AAOS: Avaliou oito estudos clínicos randomizados de qualidade moderada, que compararam a utilização do cimento ou do encaixe sob pressão na artroplastia em idosos,   não  sendo evidenciada diferença entre as duas técnicas, com exceção de fratura nas hastes com encaixe,  sendo evidenciada essa diferença num estudo e,  nos demais,  tal evidência se deu de forma pouco frequente.. NICE:  Avaliou uma revisão sistemática com seis estudos clínicos randomizados de qualidade baixa ou moderada, que compararam o uso de haste cimentada com não cimentada em artroplastia do quadril,  não sendo demonstrada diferença entre as duas técnicas. O  NICE recomenda a haste cimentada devido ao custo- benefício,  embora os resultados dos estudos não sejam estatisticamente significativos.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Riscos e Benefícios do Tratamento Cirúrgico:s** -->
Com exceção de um maior risco de ocorrência de fratura durante a colocação do implante nas artroplastia não cimentadas,  os demais riscos e benefícios são semelhantes quando comparamos as  
**Considerações: Os estudos revisados nas duas diretrizes não apresentaram diferença estatística e clínica entre as técnicas cimentadas e não cimentadas. Como o risco de ocorrerem fraturas do fêmur, ao serem usadas hastes não cimentadas é maior na população idosa, a artroplastia total cimentada é a melhor opção para o tratamento de pacientes idosos com fraturas desviadas do colo do fêmur.**  
duas técnicas no tratamento de pacientes idosos com fraturas desviadas do colo do fêmur  (artroplastia cimentada _versus_ não cimentada).

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 10** -->
Em relação à via de acesso cirúrgico,  as comparações ocorrem entre as vias  anterior, anterolateral, lateral e a posterior. Vários fatores devem ser levados em consideração quando falamos dos riscos de complicações que podem estar relacionados ao acesso cirúrgico, entre eles, os seguintes: a experiência do cirurgião com determinada via, o posicionamento da prótese  e  os cuidados per e pós-operatórios. Destaque-se que os estudos com evidencia moderada e baixa apresentam maior índice de luxações relacionadas ao uso de uma abordagem pela via posterior.  
AAOS: Avaliou dois estudos de qualidade moderada, que compararam a abordagem posterior à abordagem ânterolateral para artroplastia de fratura de colo femoral,  sendo favorecida a abordagem anterolateral (Hardinge Modificada).  
30  
NICE:  Avaliou uma revisão sistemática de um estudo clínico randomizado e um estudo de coorte, sendo ambas  de qualidade muito baixa,  que compararam  a abordagem cirúrgica posterior à abordagem ânterolateral. O grupo do NICE indica a abordagem anterolateral.  
<u>Riscos e Benefícios do Tratamento Cirúrgico:</u>  
Riscos:  A opção pela via de acesso posterior pode apresentar maior índice de luxação da prótese e formação de ossificação heterotópica quando comparada  às demais vias.  
Benefícios: Com exceção da via de aceso posterior, as demais dispensam o uso de aparelho abdutor (triângulo) no período pós- operatório.  
**Considerações:**  
**O sucesso da escolha da via de acesso está intimamente relacionado à experiência do cirurgião na sua execução, pois a abordagem ânterolateral é mais adequada, segundo os estudos avaliados nas duas diretrizes consideradas (NICE e AAOS).**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 11** -->
Segundo a Agência Nacional de Vigilância Sanitária (ANVISA)<sup>30</sup> ,  as infecções que atingem os materiais de implantes (especialmente próteses)  são decorrentes da contaminação durante o ato cirúrgico,  da disseminação a partir do foco contiguo (principalmente da ferida operatória)  ou,  ainda, da disseminação hematogênica de focos infecciosos à distância,  associados a infecções do trato urinário,  respiratório,  cutâneos e dentários, s endo orientada uma avaliação pré-operatória criteriosa (comorbidades,  estados de imunodeficiência  e  procura de focos infecciosos).  
O “segundo desafio global<sup>31</sup> Cirurgias Seguras Salvam Vidas”, lançado pela Organização Mundial da Saúde (OMS) e desenvolvido no Brasil pela Secretária de Atenção à Saúde (SAS/MS) recomenda,  no objetivo 6, o banho antisséptico;  o aparamento dos pelos,  ao invés de raspar,  somente se a presença desses pelos for interferir na cirurgia;   o preparo da pele  e   a escovação das mãos e antebraços para a assepsia cirúrgica e  para redução das taxas de infecção.  No caso da necessidade da remoção dos pelos,  eles  devem ser tricotomizados com menos de duas horas antes da cirurgia. A antissepsia das mãos deve ser com técnica de escovação,  utilizando antissépticos corretos e com a escovação de mãos e antebraços por 2 a 5 minutos.  A equipe cirúrgica deve utilizar touca ou gorros para cobrir os cabelos e estar aparamentada com capotes e luvas estéreis durante a cirurgia.  O ambiente da sala de operações com  a esterilização de instrumentais,  os campos estéreis,  a profilaxia antibiótica,  além da duração da cirurgia e da técnica cirúrgica asséptica, dois princípios mais importantes,  podem reduzir as taxas de infecção. As unidades de saúde devem possuir um processo de esterilização, com indicadores de processo para  verificação da esterilidade , que devem  ser checados  antes dos instrumentais,  materiais e equipamentos serem entregues à equipe cirúrgica. O  
31  
profissional de enfermagem responsável deve checar a esterilidade das bandejas cirúrgicas pela avaliação dos indicadores de esterilidade, antes da indução anestésica e comunicar ao cirurgião e ao anestesista qualquer problema.  A profilaxia antimicrobiana deve ser administrada  por via endovenosa até 60 minutos antes da incisão cirúrgica, para alcançar melhores níveis séricos e teciduais.   Se o tempo do procedimento cirúrgico for maior que três a quatro horas e houver evidência de sangramento transoperatório excessivo,   deve ser considerada a repetição da profilaxia antimicrobiana,  devendo ser interrompida com 24 horas  após a cirurgia,  independentemente do procedimento da cirurgia eletiva.  
**Evidência Científica:** O NICE avaliou estudo sobre  Banho Pré-Operatório  e  sobre  Antissepsia das Mãos para Cirurgia

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **2.5.1 Banho Pré- Operatório** -->
O NICE analisou uma meta-análise (Chlebicki et al. 2013), incluindo 16 estudos que avaliaram o banho pré-operatório com clorexidina 4% versus placebo ou nenhum banho, sendo concluído que o banho com clorexidina não reduziu,  de forma significativa,  a infecção no sitio cirúrgico quando comparada ao placebo ou comparada ao não tomar banho.  O NICE também avaliou duas revisões sistemáticas (Toon et al. 2013  e  Dayton et al. 2013),  sendo que   a primeira avaliou o banho pós- operatório imediato comparado com o banho tardio em pacientes pós-cirúrgicos com feridas fechadas, não encontrando  nenhuma diferença estatística em relação à  infecção cirúrgica entre os dois grupos.  A segunda revisão comparou  pacientes  que  molharam  a sutura cirúrgica  e outros pacientes que tomaram banho  mantendo o local da sutura seco,  antes da remoção da sutura, não sendo encontrada nenhuma diferença estatística entre os dois grupos em relação ao desenvolvimento de infecção cirúrgica.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **2.5.2 Antissepsia das Mãos para Cirurgia** -->
Foi avaliado um Cluster de Kenyan  de  ¨Estudos Clínicos Randomizados (Nthumba et al. 2010)¨  que comparou a eficácia do sabão simples com água  com a  fricção das mãos com álcool gel para a preparação da mão cirúrgica.   Uma revisão Cochrane (Tanner et al 2008)  avaliou os efeitos entre fricção das mãos com álcool,  composto por ingredientes ativos adicionais e fricção com soluções aquosas para redução de infecções do sítio cirúrgico.  Os dois estudos não encontraram diferenças entre as duas soluções. No entanto, alguns estudos verificaram a quantidade de bactérias nas mãos antes e após o procedimento cirúrgico e perceberam melhor resultado com a solução de clorexidina aquosa em relação à solução de iodopovidona aquosa.  
32

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **2.5.3     Antibiótico Sistêmico e Cimento Ósseo com ou sem Antibiótico** -->
Uma revisão da Cochrane (Gillespie e Walenkamp 2010) avaliou o uso de antibióticos profiláticos em pessoas submetidas a tratamento cirúrgico de artroplastia do quadril ou outras fraturas fechadas de ossos longos e a possibilidade de esses antibióticos reduzirem a incidência de infecção no sítio cirúrgico e de outras infecções hospitalares, sendo verificado que uma dose única de profilaxia antibiótica reduziu significativamente a infecção cirúrgica profunda,  infecções de sítio cirúrgico superficial,  infecções urinárias  e  infecções do trato respiratório.  Uma meta-análise (Wang 2013),   que avaliou a eficácia antimicrobiana e a segurança do cimento ósseo impregnado com antibiótico para o uso profilático na artroplastia total  primária da articulação,  concluiu que o cimento ósseo impregnado com antibiótico  não diminuiu a taxa de infecção superficial,  mas houve diferenças significativas na taxa de infecção profunda entre o grupo do cimento ósseo com antibiótico e o controle.  Para a análise de gentamicina e subgrupos de cefuroxime,  a gentamicina foi superior à cefuroxime na redução da taxa de infecção profunda.  
O NICE aconselha que  o paciente (acamado ou não) deve  tomar banho de chuveiro,  de banheira ou no leito com sabão no dia anterior ou no dia da cirurgia e, como parte da higiene diária, antes da remoção da sutura.  As diretrizes afirmam que a profilaxia com antibióticos deve ser prescrita aos pacientes antes da cirurgia limpa que envolva a colocação de uma prótese ou implante. <u>Mais Informações:</u>  
Surgical site infection. NICE clínical guideline CG74 (2008). Available from www.nice.org.uk/CG7432.  
AAOS:  Não avaliou a infecção cirúrgica  
<u>Riscos e Benefícios:</u>  
Riscos: Contaminação do paciente e desenvolvimento de infecção cirúrgica, levando ao aumento da internação hospitalar e dos custos.  
Benefícios: Segurança do paciente, nível baixo de infecção hospitalar.  
33

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **2.5.3     Antibiótico Sistêmico e Cimento Ósseo com ou sem Antibiótico** -->
- **O paciente que vai ser submetido à cirurgia de prótese ou osteossíntese deve ser orientado a tomar banho, pela manhã antes do procedimento cirúrgico, com antisséptico padronizado na instituição para diminuir o risco de infecção**<sup>30</sup><sup>**,31,**</sup> **.**  
- **É indicada a higienização das mãos dos membros da equipe cirúrgica com antisséptico antes do procedimento cirúrgico para a redução do crescimento bacteriano e do risco de infecção.**  
- **A equipe cirúrgica deve estar aparamentada com gorro ou touca, máscara cirúrgica, ausência de adornos, avental cirúrgico estéril, luva estéril e deve utilizar o campo cirúrgico estéril para o procedimento cirúrgico.**  
- **A profilaxia antibiótica, que segue a orientação da ANVISA**<sup>**31**</sup> **, no caso de cirurgias ortopédicas eletivas com implantes ou manipulação óssea e próteses, deve ser feita com Cefazolina 2 g IV**<sup>**33**</sup> **até 60 minutos antes da incisão cirúrgica e ser seguida por 1g IV de 8/8h no pós-operatório até 24 horas, ou seja, mais duas doses no pósoperatório.   Em cirurgias longas, o profissional deve fazer o repique intraoperatório do antibiótico com 1g de Cefazolina 4 horas após a primeira dose. Como alternativa, é indicada a Cefuroxima 1,5 g IV até 60 minutos antes da incisão, seguida de  1,5 g IV de 8/8 h por 24 horas.  Também no caso de cirurgias longas, esse profissional deve fazer o repique intraoperatório do antibiótico com 750mg de cefuroxime 6 horas após a primeira dose. Para pacientes alérgicos aos Beta-Lactâmicos é indicada a Clindamicina 900mg IV no pré-operatório, seguida por 600mg IV de 6/6h por 24 horas ou Vancomicina 1g (ou 15mg/kg) IV em 1 a 2 horas antes da incisão (correr lento em 1 hora), seguida por vancomicina 1g IV de 12/12h por 24 horas. Os estudos analisados pelo NICE concluíram que a gentamicina foi superior à cefuroxima e subgrupos na redução da taxa de infecção profunda.**  
- **O cimento ósseo com antibiótico é indicado na cirurgia de artroplastia total de revisão para a profilaxia e diminuição da taxa de infecção profunda.**  
- **As bandejas, materiais e equipamentos cirúrgicos que vão fazer parte do procedimento cirúrgico devem ser estéreis e com indicadores de esterilidade.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e  do NICE estão  relacionados no Apêndice 5 - Tabela 12** -->
Há uma tendência mundial de realizar o mínimo necessário de transfusões sanguíneas. Essa prática ganha reforço no contexto do número decrescente de  doadores  de sangue  em todo o Brasil.  
Com relação à transfusão no paciente idoso que realizará cirurgia de fratura de fêmur, os estudos (AAOS e NICE) sugerem a necessidade de transfusão de sangue quando o valor da hemoglobina for menor que 7g/dl.   Entre 7 e 9g/dl, a transfusão deverá ser avaliada caso a caso, de acordo com as condições clínicas do paciente, como sinais de insuficiência coronariana,  cardíaca ou respiratória ou alterações neurológicas.   O paciente deverá ser reavaliado após a transfusão de cada concentrado de hemácias,  tendo como alvo o valor de hemoglobina entre 7 e 9g/dl e melhora clínica. O uso de medicações que estimulam a produção sanguínea, como sulfato ferroso e ácido fólico,   deve ser indicado,  assim como o uso do ácido tranexâmico para reduzir o sangramento.  
34  
Há uma tendência mundial de realizar o mínimo necessário de transfusões sanguíneas. Essa prática ganha reforço no contexto do número decrescente de doadores de sangue em todo o Brasil. <u>Evidência Científica:</u>  
AAOS: Avaliou dois estudos com alta qualidade. O FOCUS é o estudo maior com 2016 pacientes. Nele, foi considerado um limite restritivo de 8g/dl de hemoglobina em pacientes com fratura de quadril assintomáticos, com doença ou fatores de riscos cardiovasculares e hipotensão  que não responde à reposição de líquidos.  
NICE: Recomenda transfusão quando o valor da hemoglobina for menor que  7g/dl  ou 8g/dl nos pacientes com doença coronariana aguda.  Pacientes com anemia crônica  que necessitam de transfusões regulares deverão ser avaliados individualmente. A reposição de sulfato ferroso deverá ser feita para pessoas com deficiência de ferro. Eritropoietina está indicada apenas para pacientes com anemia que recusam transfusão de sangue ou quando houver dificuldade técnica para se conseguir sangue compatível,  como nos pacientes com anticorpos irregulares.  O ácido tranexâmico é recomendado para as cirurgias com perda sanguínea prevista maior que 500 ml. O uso do equipamento recuperador de sangue  (Cell Save) associado ao ácido tranexâmico pode ser utilizado no intraoperatório em cirurgias nas quais se prevê a possibilidade de uma perda sanguínea muito elevada, como, por exemplo, na cirurgia cardíaca e vascular complexas,  nos principais procedimentos obstétricos,   reconstrução pélvica   e  cirurgia de escoliose. (Diretrizes para Transfusão sanguínea - NICE)<sup>34</sup> .

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios do Tratamento Cirúrgico:</u> -->
Riscos da hemotransfusão: Reações transfusionais, que vão desde o desenvolvimento de anticorpos irregulares até hemólise intravascular aguda, seguida de óbito.  
Benefícios: Melhora das condições clínicas para viabilizar o procedimento cirúrgico.  
|**Considerações:**|
|---|
|<br>**A transfusão deve ser sempre baseada nos dados clínicos e nos exames laboratoriais, evitando a**<br>**transfusão quando hemoglobina ≥ 8g/dl. Utilizar medidas para evitar a transfusão, como o uso de**<br>**medicamentos para estimular a produção de sangue (sulfato ferroso e ácido fólico)**<sup>**35**</sup>**ou para reduzir a**<br>**perda sanguínea (ácido tranexâmico) e técnicas cirúrgicas e anestésicas para minorar o sangramento.**|
|**Essa recomendação é baseada na evidência científica das duas diretrizes, que demonstram a segurança**|
|**da transfusão restritiva.****_Guidelines_ europeus e americanos recomendam considerar hemoglobina de 7**<br>**g/dl como gatilho para transfusão em pacientes sem doença coronariana aguda.**|
|<br>**O uso de medicamentos para estimular a produção e reduzir a perda de sangue baseia-se nas diretrizes**<br>**do programa de “patient blood management” da Associação Americana de Bancos de Sangue (AABB)**<sup>**36**</sup>**e**<br>**do NICE.**|  
35

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 13** -->
O tromboembolismo venoso (TEV) é uma doença frequente de etiologia multifatorial, representada clínicamente pela trombose venosa profunda (TVP) e pelo  tromboembolismo pulmonar (TEP).  Em pacientes cirúrgicos,  a chance de desenvolvimento de TEV depende da idade do paciente, do tipo de cirurgia  e da presença de fatores de risco associados.  Pacientes jovens, sem fatores de risco adicionais e submetidos a procedimentos de pequeno porte,  não necessitam de profilaxia específica para TEV.  Já pacientes idosos, particularmente na presença de fatores de risco  ou submetidos a procedimentos considerados por si só de alto risco, como as artroplastia de quadril (ATQ) ou joelho (ATJ) e cirurgias de fratura de quadril,  apresentam alto risco por serem consideradas cirurgias de grande porte.  
O risco de TEV em cirurgia ortopédica de grande porte, em particular a ATQ e a fratura de quadril,  situa-se entre os maiores quando comparados com outras especialidades cirúrgicas.  E o risco de morte por TEV ainda persiste,  apesar das recomendações quanto ao uso de profilaxia.  
Com relação ao TEP não fatal após procedimento de ATQ,  existem diferenças nas taxas de incidência de acordo com diferentes estudos, variando de 0,7% a 30%.  Com relação ao TVP,  a taxa de incidência situa-se em torno de 30%.  Segundo o Estudo _ENDORSE_<sup>37</sup> ,  no total dos trinta e dois países avaliados, envolvendo mais de 30.000 doentes cirúrgicos, 64% dos doentes com risco tromboembólico recebiam profilaxia, encontrando-se o Brasil abaixo dessa média com 46%. Além disso, de acordo com as recomendações de 2004 do _American College of Chest Physicians_ (ACCP) 38, a média de doentes cirúrgicos do estudo que recebeu a profilaxia é de 59%,  realçando a baixa taxa de adesão do Brasil.  
As recomendações das diretrizes para profilaxia de TEV em pacientes cirúrgicos ortopédicos, apresentadas no 9° Consenso do _American College of Chest Physicians_ (ACCP) 2012<sup>38</sup> , apresentam indicações, para a artroplastia de quadril, sendo recomendadas:  
- Conforme a padronização e protocolo hospitalares de exclusiva responsabilidade do hospital: Heparina de baixo peso molecular (HPBM), fondaparinux, apixabana, dabigatrana<sup>40,42,43,44</sup> , rivaroxabana<sup>42,43</sup> , heparina não fracionada (HNF) e antagonista da vitamina K, com Força de evidência Grau 1B.  
- A Compressão pneumática intermitente (CPI), com   Força de evidência Grau 1C.  
- A profilaxia farmacológica que deve ser estendida por 30 a 35 dias, com Força de evidência 2B.  
- Se houver  risco aumentado de sangramento,  sugere CPI em lugar de nenhuma profilaxia, com Força de evidência 2C.  
36  
- Não sendo recomendada a colocação de filtro de veia cava (FVC) como forma de profilaxia, a menos que haja risco aumentado de sangramento ou contraindicação para profilaxia farmacológica ou mecânica, com Força de evidência 2C .  
- O _American Academy of Orthopedic Surgeons_ (AAOS)<sup>44</sup> , 2011, recomenda :  
- Avaliar cada paciente para o risco de sangramento.  
- Suspender o agente  antiplaquetário  no período de 7 a 10 dias antes da cirurgia eletiva (com moderada evidência), avaliando o risco/benefício da descontinuação  antiplaquetária.  
- Associar profilaxia farmacológica e mecânica em caso de história prévia de TEV, por ser um consenso.  
- Utilizar profilaxia mecânica isolada em casos de risco aumentado de sangramento.  
- Mobilizar o mais rapidamente possível  no pós-operatório.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Evidência Científica:</u> -->
AAOS:  Avaliou um estudo de alta qualidade, três de qualidade moderada e oito de baixa qualidade, que compararam várias intervenções farmacológicas com placebo, sendo evidenciado que o uso da profilaxia diminui significativamente o risco de tromboembolismo venoso e complicações como trombose venosa profunda e tromboembolismo pulmonar.  Um estudo (Lahnborg et al) evidenciou mais hematoma  no  grupo da profilaxia que no placebo.  
NICE<sup>45</sup> : Avaliou seis revisões sistemáticas de ensaios clínicos randomizados de pacientes com fratura de colo de fêmur, sendo recomendada a profilaxia mecânica, com o uso de dispositivos de compressão pneumática intermitente, de dispositivos de impulso de pé e de meias elásticas, na altura da coxa ou do joelho, na admissão do paciente e até a recuperação da mobilidade,principalmente nos pacientes sem profilaxia farmacológica. A profilaxia farmacológica deve ser adicionada desde que não haja contraindicações e não tenha risco de hemorragia, conforme a padronização e protocolo hospitalares de exclusiva responsabilidade do hospital:  
- Heparina de baixo peso molecular - Pode ser iniciada na admissão e suspensa 12 horas antes da cirurgia, devendo ser iniciada 12 horas após a cirurgia, desde que a hemostasia tenha sido restabelecida.  
- Heparina não fracionada para pacientes com insuficiência renal - A partir da admissão, parando 12 horas antes da cirurgia e reiniciar 6-12 horas após a cirurgia, desde que a hemostasia tenha sido restabelecida.  
- Profilaxia farmacológica contínua durante 28-35 dias, como prevenção para o tromboembolismo venoso.  
37

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios:</u> -->
Riscos:  Encontram-se diretamente relacionados ao uso de anticoagulantes.  A complicação temida, neste caso,  é o sangramento no pós-operatório.  
Benefícios: Prevenir a ocorrência do tromboembolismo venoso (TEV), representado pela trombose venosa profunda (TVP) e tromboembolismo pulmonar (TEP) e também outras complicações, tais como a síndrome pós-trombótica e a hipertensão pulmonar, que essas doenças podem acarretar.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios:</u> -->
- **Em cirurgias de artroplastia do quadril total e parcial e osteossíntese, é feita a profilaxia medicamentosa em todos os pacientes.**  
- **A profilaxia mecânica deve ser utilizada sempre que houver contraindicação para o uso de anticoagulantes.**  
- **A profilaxia medicamentosa deve ser estendida após a alta hospitalar por um período de 28 a 30 dias.**  **A profilaxia medicamentosa deve ser prescrita de acordo com o protocolo institucional.**  **A profilaxia mais adequada é a que associa métodos mecânicos e químicos.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 14** -->
A reabilitação do idoso após fratura do colo do fêmur deverá ser avaliada por uma equipe multidisciplinar durante a sua internação, para que a sua reabilitação no lar e na sociedade possa ocorrer o mais rápido possível, evitando,  assim,  a ocorrência ou o agravamento de comorbidades, como pneumonia, infecção hospitalar, úlcera por pressão e  restrição ao leito.  A equipe interdisciplinar deve ser composta por médicos clínicos ou geriatras, enfermagem, fisioterapeutas, terapeuta ocupacional, fonoaudiólogas, nutricionistas, psicólogos e  assistentes sociais.  É importante que a equipe tenha conhecimento do processo de envelhecimento e de suas complicações para uma intervenção eficaz,  portanto sugere-se que todos os membros da equipe participem de discussão de casos clínicos, por meio de análise crítica de artigos científicos  a qual  possibilite uma intervenção com maior efetividade.  
AAOS: Avaliou dois estudos de alta qualidade científica e sete de qualidade moderada, que observaram um programa de reabilitação interdisciplinar e de prevenção de quedas em pacientes com fratura de quadril no pós-operatório.  Os estudos concluíram que um programa de assistência interdisciplinar apresenta melhores resultados funcionais e prevenção de quedas  em pacientes idosos pós- cirúrgicos de fratura de colo de fêmur. As maiores diferenças foram encontradas no grupo de pacientes com demência suave à moderada.  
38  
NICE: Avaliou seis estudos clínicos randomizados com sérias limitações, como tempo de acompanhamento e falta de análise de sensibilidade.  A qualidade de vida relacionada à saúde não foi calculada e nenhuma análise incremental foi conduzida. Os estudos concluíram que a alta planejada por uma equipe interdisciplinar  ajuda na prevenção de queda,  na saúde óssea  e nos cuidados primários.  
**Considerações: O programa de reabilitação interdisciplinar promove melhor resultado e funcionalidade do paciente no pós-operatório de fratura do quadril, atuando na proposta preventiva e nos cuidados básicos de saúde, tais como adequação do ambiente doméstico e a reinserção na sociedade.** <mark>—|</mark>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 15** -->
AAOS: Foram avaliados três estudos de evidência científica alta e seis estudos com evidência científica moderada, sendo evidenciado que a fisioterapia continua mostrou ser eficaz para a melhora funcional do idoso pós- fratura do quadril e que a fisioterapia domiciliar do paciente é superior à fisioterapia ambulatorial para a melhora física e mobilidade do idoso.  
NICE: Avaliou um estudo com evidência científica moderada que comparou a fisioterapia precoce (dentro de 48h) versus a mobilização retardada, sendo evidenciado que os pacientes que não tinham nenhuma contraindicação para a fisioterapia precoce tiveram uma mobilidade e uma independência de transferência melhor em relação à mobilização retardada.  
<u>Riscos e Benefícios:</u>  
Riscos:  Exceder quantitativamente os exercícios propostos pela fisioterapia,  podendo causar fadiga e lesões musculares.  
Benefícios: Orientação dos familiares no cuidado do paciente,  adequação do ambiente à nova  
**Considerações: A fisioterapia precoce (dentro das 48h) no pós-operatório, com continuidade e supervisionada por um fisioterapeuta demonstra uma melhora na mobilização e independência do idoso.** condição funcional do paciente e realização dos exercícios propostos de forma supervisionada. <mark>—_|</mark> **3. 3 – Frequência da Fisioterapia Evidência Científica:   Os estudos da AAOS e  do NICE estão  relacionados no Apêndice 5 - Tabela 16**  
39  
Evidência Científica:  
AAOS: Avaliou dois estudos de qualidade científica alta e dois estudos de qualidade moderada que observaram os benefícios da fisioterapia intensificada na alta hospitalar em pacientes idosos com fratura de quadril.  Os estudos evidenciaram melhora funcional,  fortalecimento das pernas, equilíbrio, mobilidade e melhora das atividades da vida diária na residência.  O seguimento dos pacientes  nos estudos variou  de três a  seis meses.  
NICE: Avaliou três estudos clínicos randomizados com evidência científica de baixa à alta qualidade, com desfechos diferentes. Os estudos evidenciaram que não há diferença estatisticamente significativa em testes de desempenho funcional,  qualidade de vida, velocidade de caminhada ou dor com o exercício de apoio,   peso e treinamento de marcha,  força do extensor do joelho,  força do musculo adutor ou tempo de permanência no hospital com um aumento no  número de sessões de fisioterapia por dia, em comparação com o controle.  O seguimento dos pacientes variou  de três meses a 14 meses.  O  NICE recomenda que a fisioterapia diária apresente benefícios potenciais de melhoria da mobilidade e equilíbrio,  o aumento da independência  e a redução da necessidade de cuidados institucionais e sociais.  
<u>Riscos e Benefícios:</u>  
Riscos: Intensificar o quantitativo de exercícios diários pode causar lesões musculoesqueléticas. Benefícios: Melhorar  as atividades de vida diária, recreacionais e ocupacionais.  
**Considerações:**  
**Ambas as diretrizes da AAOS e do NICE recomendam um programa de fisioterapia regular domiciliar e ambulatorial para a recuperação funcional do idoso, após a alta hospitalar.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 15** -->
A intervenção terapêutica ocupacional tem no desempenho ocupacional do idoso com fratura de fêmur proximal seu foco. O processo do envelhecimento é complexo.   A função e a incapacidade têm  um papel fundamental na atenção à saúde do idoso e  o conceito de saúde está intimamente ligada ao de capacidade funcional.  Saúde para o idoso envolve a saúde física e mental,  independência nas AVDs,  integração social,  suporte familiar  e  independência econômica.  As fraturas de fêmur proximal  são uma das causas  mais importantes para a perda da capacidade funcional dele. O terapeuta ocupacional identifica e analisa como os componentes sensoriomotores,  cognitivos, físicos,  psicológicos  e  psicossociais   podem interferir na realização das atividades de vida diária,  
40  
nas atividades instrumentais desse tipo de vida,  nas atividades  produtivas e de lazer e  também identifica e analisa em que contexto essas atividades são realizadas.  Esses dados norteiam uma intervenção precoce eficaz e possibilitam, por meio de cuidados específicos,  minimizar os efeitos do trauma e da internação, otimizar as capacidades remanescentes do idoso, prevenindo a perda da capacidade funcional  e outras comorbidades como _delirium_ , depressão e síndrome de imobilidade. Também são importantes os cuidados com a segurança, os riscos de quedas e as modificações ambientais  e  também é importante a  indicação de treino quando necessário, adaptações  e  órteses para a execução das atividades  com segurança,  além da orientação  ao cuidador. <u>Evidência Científica:</u>  
AAOS: Foram avaliados três estudos de evidência científica alta e seis estudos com evidência científica moderada, que observaram que a terapia ocupacional iniciada durante a internação e sendo mantida na residência melhora os resultados funcionais,  como  a Atividade de Vida Diária (AVD), Atividades Instrumentais de Vida Diária (IADL), _<mark>Health-Related Quality Of Life</mark>_ (HRQOL)  e redução de quedas.  Os estudos incluídos para a Fisioterapia e para a  Terapia Ocupacional foram os mesmos.  
NICE: Avaliou os estudos selecionados para fisioterapia e terapia ocupacional em conjunto e recomenda que um  rápido restabelecimento das funções físicas e o autocuidado  são  fundamentais para a recuperação da fratura de quadril,  especialmente quando o objetivo é devolver o paciente aos níveis pré-operatórios anteriores a sua função na residência.  
<u>Riscos e Benefícios:</u>  
Riscos:  Não apresenta.  
Benefícios:  Prevenir quedas  e    proporcionar  independência nas atividades da vida diária,  lazer  e integração social.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 15** -->
- **É indicada a avaliação da terapia ocupacional na internação do paciente para a avaliação do seu status funcional (AVD e AIVD) antes da fratura.**  
- **No pré-operatório, o terapeuta atua na estimulação ou orientação do paciente e do cuidador para a manutenção da sua capacidade funcional.**  
- **No primeiro dia do pós-operatório, a intervenção do terapeuta é iniciada com orientações ou treino especifico para a realização das AVD pelo paciente.**  
- **E, de acordo com a avaliação do terapeuta, é recomendado o acompanhamento domiciliar com orientação para o paciente e o cuidador com reavaliações periódicas.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **3.5 - Nutrição** -->
41

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e  do NICE estão  relacionados no Apêndice 5 - Tabela 17** -->
O cuidado nutricional desempenha um papel fundamental para o alcance e manutenção da Massa Óssea (MO) máxima e para a redução do risco de osteoporose.  Uma alimentação balanceada que forneça quantidades suficientes de proteínas, vitaminas e minerais, entre esses  as vitamina D e K,  o cálcio,  o magnésio  e o fósforo   influenciam  positivamente a saúde óssea<sup>46,47,48,49,50</sup> .  
Acredita-se que 30 kcal/kg/dia sejam suficientes para a manutenção dos gastos calóricos da pessoa idosa, em atividade regular. A maior parte da oferta calórica é conseguida à custa de hidratos de carbono. Recomenda-se, inclusive, que ocorra uma maior ingestão de hidratos de carbono complexos (fibras). A gordura, preferencialmente, deve ser fornecida na forma de uma mistura de ácidos graxos saturados e insaturados. O percentual de 30%-40% da energia total não proteica ingerida deve ser obtido pela ingestão de gordura. Tal ingestão torna a dieta mais palatável, o que serve para diminuir a anorexia.  A ingestão recomendada de proteína é semelhante à recomendada ao jovem adulto: 0,8 g/kg/dia. De maneira análoga à energia, situações,  como trauma e doenças, em geral, podem estar associadas a uma maior necessidade proteica<sup>51</sup> . O estado nutricional de pacientes idosos internados com fratura de quadril e fêmur parece afetar sua recuperação, tendo os mais bem nutridos uma reabilitação clínica melhor e mais rápida. Deve-se manter uma dieta hipercalórica e hiperproteica e com suplementação de líquido rico em proteína<sup>51</sup> .  
Nos idosos frágeis, o uso de suplementos nutricionais pode melhorar ou manter o estado nutricional desses pacientes<sup>52,53,54,55</sup> . A desnutrição constitui problema comum no envelhecimento, que se origina de uma combinação de fatores. Diversos estudos demonstram que o estado nutricional dos idosos está diretamente relacionado à imunocompetência do organismo durante o processo de senescência.  
A baixa ingestão de proteína é frequentemente observada em pacientes com fratura de quadril<sup>56</sup> . Segundo o _Institute of Medicine_ – IOM<sup>57</sup> , há insuficientes evidências para o estabelecimento de ingestão máxima tolerável para a proteína dietética. Dietas com teor proteico de 1,0  a  1,5g/kg peso/dia  são associadas ao  metabolismo de cálcio normal, não afetando a homeostase esquelética, já que dietas hiperprotéicas também podem ser deletérias à saúde óssea<sup>58</sup> .  O suplemento calórico-proteico é fundamental, portanto, quando a ingestão alimentar do paciente idoso não cobre a quantidade de proteínas e de calorias  recomendadas e necessárias.  
Antes de definir a terapia nutricional a ser implementada para cada paciente, é importante determinar o estado nutricional do idoso. Uma importante ferramenta de avaliação nutricional para pacientes acima de 60 anos é a Mini Avaliação Nutricional (MAN). O questionário da MAN foi desenvolvido e validado para realizar uma simples e rápida avaliação do estado nutricional de  
42  
pacientes idosos de clínicas, hospitais e instituições asilares, permitindo a detecção de risco de desnutrição e intervenção nutricional quando necessária<sup>59</sup> .

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Evidência Científica:</u> -->
AAOS: Avaliou um estudo de alta qualidade científica e dois de baixa qualidade, que observaram a relação entre a suplementação nutricional e o resultado desta em pacientes idosos com fratura de quadril, sendo evidenciado que a suplementação nutricional reduz a mortalidade e melhora o estado nutricional dos pacientes idosos com fratura de colo de fêmur. Essa recomendação foi classificada como moderada.  
NICE: Avaliou seis estudos clínicos randomizados e uma revisão sistemática com meta-análise, com limitadas evidências científicas  evidenciaram que um programa de alta com orientação nutricional, apoio com dieta energética e proteína (no hospital) e suplemento oral, vitamina D e cálcio no pós a alta (foi utilizada a Ferramenta de Mini Avaliação Nutricional)   melhora o estado nutricional e  reduz a mortalidade dos pacientes idosos. Foi incluído um estudo clínico randomizado com limitada evidência, que avaliou o suporte nutricional oral em pacientes idosos com fratura de quadril osteoporótica de baixo impacto. Foi evidenciado que os suplementos nutricionais por via oral parecem prevenir a perda de peso após a cirurgia de fratura de quadril em pacientes idosos com um índice de massa corporal inferior a 25 kg/m<sup>2</sup> e pode reduzir o tempo de internação.  O grupo de avaliadores do NICE<sup>60</sup> recomenda a triagem dos pacientes para investigar a desnutrição e, se for necessário, fornecer apoio nutricional.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios:</u> -->
Riscos: A má nutrição específica se caracteriza pela deficiência isolada ou múltipla de vitaminas, de minerais ou de oligoelementos, podendo ocorrer, isolada ou associada à má nutrição calórica ou proteica.  
Benefícios: Melhora do estado nutricional e redução de risco de novas fraturas.  
**Considerações: Para o cuidado e prevenção de fraturas, em especial a de fêmur em pacientes idosos, é fundamental aplicar, na prática clínica, as seguintes medidas: avaliar o estado nutricional com ferramentas confiáveis, como o questionário da MAN, e avaliar se a ingestão de alimentos atende a ingestão diária recomendada (IDR) própria para a faixa etária.  Em caso de ingestão nutricional inadequada, o que é muito comum nessa faixa etária, o profissional deve introduzir suplementação de Cálcio (1.200mg) e Vitamina D (600 UI)**<sup>**61**</sup> **, normalmente comercializados na forma de cápsulas, comprimidos e soluções. Pode ser fundamental também o uso de suplementação nutricional para melhor atingir às necessidades de calorias e proteínas diárias do paciente idoso.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:  Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 18** -->
43  
Suplemento de cálcio e alimentos fortificados é uma fonte importante de cálcio. Os suplementos de cálcio são disponíveis em vários tipos de sal.  Alguns deles são ( **Tabela 1** ):  
**Tabela 1** – Composição de cálcio elementar  (%) em diferentes tipos de sal  
|**Sal**|**Cálcio**<br>**elementar(%)**|
|---|---|
|**Carbonato**|40|
|**Citrato**|21|
|**Lactato**|13|
|**Gluconato**|9|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: _FONTE: CONSENSO BRASILEIRO DE OSTEOPOROSE, 2002._ -->
A absorção do citrato de cálcio é menos dependente da presença de ácido gástrico, e o carbonato de cálcio necessita da presença do ácido gástrico para sua dissolução.  Para melhorar a absorção,  recomenda-se que não se administre mais do que 500 mg de cálcio por dose tomada.  Em alguns pacientes, náusea, dispepsia e constipação podem associar-se à suplementação com sais de cálcio, diminuindo a aderência ao tratamento.  Por isso, recomenda-se a ingestão de cálcio pela dieta 62 .  
As principais fontes de cálcio são leite, queijo, coalhada, brócolis, couve, ovos, peixes com espinha (sardinha, salmão), amêndoas e avelãs<sup>62</sup> .   As RDI 1999 (Recomendações Diárias de Ingestão) preconizam consumo de 1200 mg de cálcio por dia para os idosos<sup>63</sup> .  
O Grupo DIPART<sup>62</sup> (2010 - total de 68 517 participantes) recomenda,  como dose de vitamina D,  no mínimo 10 µg (400 UI) diariamente, combinada com 1.000 mg de cálcio.  Em pacientes de alto risco,  deve-se utilizar bisfosfonatos ou outros medicamentos antiosteoporóticos,  de acordo com orientações nacionais e internacionais. O estudo  conclui que a vitamina D,  administrada isoladamente em doses de 10-20 µg,  não é eficaz na prevenção de fraturas,  porém,  quando administrada em conjunto com o cálcio,  reduziu fraturas de quadril e fraturas totais e provavelmente fraturas vertebrais, independentemente da idade,  sexo  ou fraturas prévias<sup>64</sup> .  A redução do  risco de quedas e fraturas osteoporóticas de fêmur e não vertebrais  parece ser beneficiada por concentrações séricas de 25 (OH)D a partir de 30ng/mL<sup>65</sup> .  Os ensaios usando a vitamina D com cálcio mostraram um risco reduzido global de fratura (taxa de risco 0,92, 95% de intervalo de confiança, 0,86 a 0,99, p = 0,025) e da fratura de quadril (todos os estudos: 0,84, 0,70 a 1,01, p = 0,07; e estudos usando 10 ug de vitamina D administrada com cálcio: 0,74, 0,60 a 0,91, p = 0,005).  
44  
Os alimentos ricos em vitamina D na dieta são os óleos de fígado de peixes,  peixes de água salgada, especialmente os de alto teor de óleo (salmão, sardinha e arenque),  gema de ovo, leite e derivados<sup>66</sup> .  Para uma adequada produção de colecalciferol (vitamina D3) pelo organismo<sup>67</sup> , recomenda-se exposição ao sol em torno de 15 minutos<sup>68</sup> pelo menos  duas a quatro vezes por semana,  o que é suficiente para todos os tipos de pele.  Essa exposição equivale a aproximadamente 25% do que viria a causar uma resposta de eritema mínima, ou seja, uma ligeira coloração rosa para a pele.  Após essa exposição, a aplicação de um protetor solar com FPS (fator de proteção solar) maior ou igual a 15 é recomendada, para evitar danos à pele devido à exposição excessiva à luz solar. Uma maneira satisfatória de se aproximar das necessidades de vitamina D exigida pelo corpo seria aumentando a ingestão de alimentos que contêm  vitamina D,  incluindo o leite, o suco de laranja, cereais e óleo de peixe<sup>69</sup> .  
<u>Evidência CientÍfica:</u>  
AAOS: Avaliou quatro estudos com evidência científica moderada, que demonstraram os benefícios de suplementação de cálcio e Vitamina D para reduzir o risco de quedas e prevenir fraturas em idosos. NICE: Três estudos clínicos randomizados com limitada evidência avaliaram a suplementação dietética, que evidenciou uma melhora significativa nas limitações funcionais.  O NICE não avaliou o cálcio e a vitamina D separados.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Risco e Benefícios:</u> -->
Riscos:  Uma dieta pobre em nutrientes, cálcio e vitamina D pode acarretar desnutrição e acelerar a perda de massa óssea nos idosos e pode provocar calcificação óssea e litíase renal.  
Benefícios: Otimizar o consumo de micronutrientes essenciais para a manutenção da saúde óssea, como cálcio e vitamina D, torna-se uma alternativa promissora na redução dos danos causados pela senilidade (aumento da calcificação óssea e a fragilidade óssea).

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Risco e Benefícios:</u> -->
- **Para a redução da perda de densidade mineral óssea (DMO) e, consequentemente, para a diminuição do risco de incidência de fraturas ósseas osteoporóticas, é aconselhável a suplementação nutricional de cálcio e vitamina D, principalmente em se considerando o consumo dietético, idade, sexo, pigmentação da pele e exposição solar dos indivíduos. Tal exposição contribui para adequada produção de vitamina D.**  
- **É recomendada a reposição de cálcio e vitamina D no paciente idoso, com deficiência de colecalciferol.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **3.7 - Osteoporose** -->
**Evidência Científica:  Os estudos da AAOS e do NICE estão  relacionados no Apêndice 5 - Tabela 19**  
45  
De acordo com os dados encontrados na pesquisa de Schiavo et al.<sup>69</sup> ,  o consumo mediano das calorias e dos macronutrientes dos pacientes esteve abaixo das recomendações feitas pela DRI para uma população idosa.   Esses resultados estão de acordo com dados sobre consumo alimentar obtido pela Pesquisa _Brazilian Osteoporosis Study_<sup>70</sup> , em que 90% dos entrevistados ingerem 1/3 do valor preconizado de cálcio pela IDR<sup>69</sup> .  
AAOS: Avaliou dois estudos,  um com evidência científica moderada e o outro com evidência científica de baixa qualidade, com desfechos diferentes.  Um estudo avaliou a eficácia do Ácido Zoledrônico versus placebo combinado com pré- tratamento com Vitamina D e evidenciou que o grupo do tratamento apresentou uma redução estatisticamente significativa nas taxas de mortalidade e de novas fraturas (vertebrais e não vertebrais).  O segundo estudo avaliou a eficácia de um teste para a observação da densidade mineral óssea e tratamento específico para osteoporose com bifosfonados no pós-alta de fratura do quadril.  E o terceiro observou  um grupo com risco de osteoporose por meio de testes de avaliação da densitometria mineral óssea outratamento especifico com Bifosfonados entre o grupo que recebeu orientação sobre o risco da osteoporose no pósoperatório e um grupo que recebeu um panfleto antiqueda, não sendo evidenciada diferença entre os dois grupos.  
NICE: Avaliou a utilidade do FRAX e do QFracture para a detecção de risco de fratura por fragilidade em idosos com causas secundárias para osteoporose e para reavaliação do risco de fratura no final da terapia medicamentosa. Algumas pessoas permanecem em alto risco de fraturar e requerem tratamento continuado,  ao passo que outras podem  beneficiar-se  de um período de _“Férias da Droga_ ” por  um ou mais anos.  O NICE recomenda considerar, na avaliação de risco de fraturas em mulheres com menos de 65 anos e homens com menos de 75 anos,  qualquer um dos seguintes fatores de risco: fratura por fragilidade anterior;    utilização frequente, no presente ou no passado, de glicocorticoides oral;   história de quedas; história familiar defratura de quadril; baixo índice de massa corporal (IMC) inferior a 18,5 Kg/m<sup>2,</sup> e  outras causas secundárias à osteoporose, como  fumar mais de 10 cigarros por dia e consumir álcool diariamente.  
<u>Mais Informações:</u>  
Osteoporosis:  Assessing the risk of fragility fracture,  NICE guideline,  Draft  for consultation, February  2012<sup>71</sup> .  
<u>Risco e Benefícios:</u>  
Riscos: Alguns estudos mostram que a associação entre o uso de bifosfonatos e fraturas atípicas do fêmur é altamente provável, aumentando o risco com a duração do tratamento.  
46  
Benefícios: A incidência de fraturas atípicas é muito baixa, sobretudo se comparada com as fraturas osteoporóticas típicas, mantendo-se positiva a relação benefício/risco do uso de bifosfonatos e

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **3.7 - Osteoporose** -->
- **Medidas profiláticas devem ser consideradas em todos os pacientes com indicação de uso ou que já estejam usando fármacos ou que apresentem as doenças potencialmente indutoras de osteoporose. Esses medicamentos devem ter indicação precisa e ser utilizados na menor dose efetiva e durante o menor tempo necessário.**  
- **As recomendações gerais relacionadas ao estilo de vida (nutrição adequada, atividade física, exposição solar, consumo de álcool e tabagismo) são as mesmas mencionadas para a prevenção da osteoporose primária.**  
- **No paciente com fratura de colo de fêmur por fragilidade óssea, devem ser administrados bifosfonados, que são contraindicados para pacientes com insuficiência renal crônica com clearence de creatina ≤ 30ml/min.**  
- **A versão vigente do Protocolo Clínico e Diretrizes Terapêuticas da Osteoporose não incorporou o ácido zoledrônico, por insuficiência de evidências de superioridade aos demais bifosfonados.**<sup>**71, 72.**</sup>  
prevenção de novas fraturas e melhora da qualidade óssea.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:   Os estudos da AAOS e  do NICE estão relacionados no Apêndice 5 - Tabela 21** -->
A avaliação do geriatra inclui a Avaliação Geriátrica Ampla (AGA) nos pacientes de eleição. As condutas serão tomadas visando a um tratamento personalizado.  
Com o intuito de que todas as informações das condições de saúde e sociais levantadas pela equipe interdisciplinar e pelo geriatra possam ser registradas e  acompanhadas de forma longitudinal, o Ministério da Saúde (MS) criou a Caderneta da Saúde  do Idoso<sup>73</sup> .  Link para acesso  à  cartilha do idoso:  
<u>http://bvsms.saude.gov.br/bvs/publicacoes/caderneta_saude_pessoa_idosa_3ed.pdf</u>  
<u>Evidência Científica:</u>  
AAOS:  Avaliou dois estudos,  um com evidência científica alta e o outro moderada,  sendo demonstrada a importância do geriatra na alta hospitalar e no acompanhamento pós-operatório. NICE: Avaliou três estudos clínicos randomizados com limitada evidência científica, que  
**Considerações:**  
**É indicado o acompanhamento da pessoa idosa pelo geriatra e pela equipe interdisciplinar, desde a admissão, com o intuito de identificar as pessoas idosas mais vulneráveis e de aplicar a avaliação geriátrica ampla (AGA) nos pacientes de eleição.  As condutas serão tomadas visando a um tratamento personalizado e multidisciplinar (cognição, humor, capacidade funcional,  avaliação social e suporte familiar).**  
evidenciaram a importância do geriatra e do ortogeriatra (especialidade médica na Inglaterra) para  
avaliação do paciente desde admissão e até o seguimento.  
47

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:   Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 22** -->
O atendimento da equipe multidisciplinar no domicílio do paciente idoso procura prestar um cuidado mais humanizado, evitar as reinternações hospitalares,  diminuir a permanência do idoso no hospital após cirurgia e, com isso,  evitar o risco de infecção, problemas respiratórios,  imobilidade e lesão por pressão.  No Brasil, o Programa de Atenção Domiciliar  (Programa Melhor em Casa)<sup>74</sup> , foi reorganizado pelo Ministério da Saúde em 2011, tendo como duas de suas diretrizes, as seguintes: “Adotar modelo de atenção centrada no trabalho de equipes multiprofissionais e interdisciplinares¨ e  ¨estimular a participação ativa dos profissionais de saúde envolvidos, do usuário, da família e do cuidador”.   Esse  Programa possui prontuário eletrônico, por meio da ferramenta de tecnologia E- SUS . Demonstrando a importância desse acompanhamento domiciliar,  os dados do levantamento anual de 2014 da UDOMI (Unidade de Atendimento Domiciliar) do INTO indicam que,  dos 744 pacientes que foram acompanhados,  109 eram do trauma do idoso e 45  pacientes  sofreram fraturas do colo do fêmur.   E,  quando analisado o  percentual  da condição de deambulação do paciente e de lesão por pressão na admissão e na alta (UDOMI),  foi observada uma significativa melhora em relação ao paciente  não deambulador ( na admissão  eram 23,35%  e na alta 3,19%) ,  deambulador não funcional   (na admissão  eram 62,28% e na alta 1,79%),  deambulador domiciliar  (na admissão eram  9,98%  e na alta 47,31%)  e deambulador comunitário  (na admissão  eram 4,39%  e na alta 47,71%)  e na lesão por pressão (na admissão  eram 7,29%  e na alta 0,74%). <u>Evidência Científica:</u>  
O NICE destacou a importância da opinião do paciente idoso (os pacientes relatam que sentem medo, dor e, em alguns casos, sofrem de _delirium_ ) em todo o atendimento hospitalar, no domicilio, casas de repouso ou asilo.  O envolvimento do cuidador (cônjuge, familiar ou um cuidador contratado),  em todo o processo de cuidado,  demonstrou uma recuperação do paciente mais rápida e a diminuição das taxas de reinternação hospitalar.  Força da Recomendação: Forte  
AAOS: Avaliou dois estudos de alta qualidade e sete estudos de qualidade moderada,  evidenciando que um programa de reabilitação interdisciplinar alcança melhores resultados funcionais e prevenção de queda.  Os melhores resultados foram encontrados no grupo de demência suave e moderada.  
NICE: Avaliou sete estudos com evidência limitada, que observaram que um programa de reabilitação interdisciplinar reduz o  tempo de internação hospitalar e as taxas de readmissão, proporciona o retorno precoce das funções    e  melhora o nível de financiamento do sistema de saúde para os cuidados de enfermagem necessários.  
48

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica:   Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 22** -->
- **Apresentar vantagens qualitativas, em que podem ser identificados os “estresses ambientais” modificáveis e a suspeita de maus-tratos.**  
- **Orientar, informar e instrumentalizar o idoso para o seu autocuidado e também os familiares ou cuidadores e promover maior independência nas atividades de vida diária (pentear o cabelo, comer sozinho).**  
- **Orientar e corrigir os fatores de riscos ambientais (como, por exemplo, instalação de barra de apoio no banheiro e colocação de piso antiderrapante).**  
- **Orientar para evitar atividades de maior risco para os idosos frágeis desacompanhados, como descer escadas, promover condições seguras no domicílio, local de maior parte das quedas dos idosos.**  
- **Reintegração ao ambiente familiar e social. As duas diretrizes avaliaram a importância do atendimento domiciliar do paciente no pós-operatório de fratura de colo de fêmur no idoso com o cuidado interdisciplinar e destacaram a importância da consulta do geriatra e o planejamento da alta por essa equipe para melhor reabilitação do idoso, diminuindo a incidência de** **_delirium_ , lesão por pressão e tratamento de fatores de risco de quedas.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Evidência Científica: Os estudos da AAOS e do NICE estão relacionados no Apêndice 5 - Tabela 23** -->
Lesão por pressão é uma lesão localizada na pele ouno tecido subjacente, normalmente sobre uma proeminência óssea, como resultado da pressão ou de uma combinação entre a pressão e o cisalhamento   (NPUAP/EPUAP-2014) NEW 2014 Prevention and Treatment of Pressure Ulcers: Clínical Practice Guideline - National Pressure Ulcer Advisory Panel (NPUAP),   European Pressure Ulcer Advisory Panel (EPUAP) and Pan Pacific Pressure Injury Alliance (PPPIA)<sup>75</sup> .   Muitos fatores contribuem para o desenvolvimento das lesões por pressão e os pacientes mais suscetíveis ao desenvolvimento dessas lesões são aqueles que estão restritos ao leito ou  a cadeira de rodas,  que se encontram com imobilidade ou mobilidade prejudicada,  déficit cognitivo,  nutricional  e  de sensibilidade  e, finalmente, os que estão em uso de dispositivos médicos, como aparelhos gessados, fixadores,  sondas,  tubos,  cateteres,  colar cervical,  entre outros.  
O tratamento é determinado a partir da classificação da lesão e reavaliado periodicamente, considerando a interface da ferida e o aspecto geral da exsudação,  odor  e  dor. NICE<sup>76</sup> : Todos os pacientes potencialmente estão em risco de desenvolver uma lesão por pressão. Na internação,  deve ser avaliado e identificado o risco com uma ferramenta validada ou não. Utilizam-se os termos "em risco"  e  "de alto risco"  para identificar as pessoas que podem desenvolver  
49  
uma lesão por pressão.  Deve ser utilizada uma escala validada para a avaliação do risco de lesão por pressão, como exemplo a Escala de Braden, a Waterlow ou a Escala de Avaliação de Risco de Norton. A pele do paciente deve ser avaliada por um profissional treinado,  devendo ser observada a integridade da pele nas zonas de pressão, mudança da coloração ou descoloração da pele, variações de calor, firmeza e  umidade.  Os pacientes que estão em risco de desenvolver lesão por pressão devem ser incentivados a mudar de decúbito em,  pelo menos,  a cada seis horas e,  na incapacidade de mudarem sozinhos,   esse procedimento deve ser realizado pelo profissional de saúde ou pelo cuidador,  sendo documentada a mudança de decúbito,  e,  para os pacientes que estão com alto risco, a mudança de decúbito deve ser realizada,  pelo menos,  a cada quatro horas.  Deve ser oferecido suplementos nutricionais e hidratação aos  pacientes que estão com déficit nutricional e desidratados. <u>Evidência Científica:</u>  
AAOS: Não avaliou a lesão por pressão separada.  
NICE: Avaliou nove estudos de coorte com qualidade científica muito baixa a baixa,  observando o risco para predição de lesão por pressão das Escala de Waterlow, Braden, Braden Q, a sensibilidade e especificidade.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios:</u> -->
Riscos: A falta da mudança de decúbito e da avaliação correta do paciente pode acarretar o desenvolvimento e agravar a lesão por pressão.  
Benefícios: Ocorre a melhora da circulação sanguínea local e a redução da pressão nos locais de maiores proeminências ósseas.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: <u>Riscos e Benefícios:</u> -->
- **A identificação dos pacientes em risco, por meio da aplicação de escalas preditivas de risco, favorece a implementação de estratégias de prevenção precocemente.  As escalas de Braden, Braden Q e Waterlow são as escalas validadas no Brasil, sendo utilizadas desde a admissão até a alta dos pacientes internados, e os resultados obtidos determinam as ações relacionadas à prevenção dos agravos.**  
- **Fazem-se necessários a adequação do estado nutricional; a manutenção de pele limpa e seca; o reposicionamento do paciente, com cabeceira a 30**<sup>**o**</sup> **e superfícies de apoio adequadas ao peso corporal e nível de mobilização; o uso de coxins para manutenção de calcâneos elevados e flutuantes   e a limitação do tempo em que o paciente permanece sentado sem alívio de pressão.**  
- **É recomendada a mudança de decúbito de quatro em quatro horas para pacientes de baixo risco e de duas em duas horas para pacientes de alto e altíssimo risco de desenvolver lesão por pressão.**  
- **Para o cuidado local é preconizada a avaliação do profissional especializado.**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **GLOSSÁRIO** -->
AAOS - American Academy of Orthopaedic Surgeons  
50  
ACCP - American College of Chest Physicians ADAPTE –   Resource Toolkit Guideline Adaptation ADOMI - Área de Atenção Domiciliar AGA  - Avaliação Geriátrica Ampla AGREE -   Appraisal of Guidelines for Research &  Evaluation AL – Anestesia Local ANVISA  - Agência Nacional de Vigilância Sanitária AP -  Anteroposterior ATJ – Artroplastia Total do Joelho ATQ – Artroplastia Total do Quadril AVD -  Atividade de Vida Diária BIS -  Índice Biespectral CAE -  Centro de Atenção do Trauma CO – Cintilografia Óssea DeCS  - Descritores em Ciências da Saúde DIPART - Vitamin D Individual Patient Analysis of Randomized Trials DMO – Densidade   mineral  óssea DRI - Necessidades nutricionais recomendadas ECR – Ensaio Clínico Randomizado EPO -  Eritropoietina EPUAP -  European Pressure Ulcer Advisory Panel EUA – Estados Unidos da América FPS -  Fator de proteção solar GRADE – Grading of Recommendations Assessment, Development and Evaluation HRQOL - Health-Related Quality Of Life IADL - Atividades Instrumentais de Vida Diária IBGE – Instituto Brasileiro de Geografia e Estatística INTO  - Instituto Nacional de Traumatologia e Ortopedia IOM - Institute  of Medicine IV –    Intravenosa MAN – Mini Avaliação Nutricional MeSH  -  Medical Subject Heading MO – Massa Óssea MS – Ministério da Saúde NATS  - Núcleo de Avaliação de Tecnologias em Saúde  
51  
NICE -  National Clínical Guideline Centre NPUAP - National Pressure Ulcer Advisory Panel OMS - Organização Mundial de Saúde PCDT - Protocolos Clínicos e Diretrizes  Terapêuticas PPPIA - Pan Pacific Pressure Injury Alliance QUADAS - Quality Assessment of Diagnostic Accuracy Studies RDI - Recomendações Diárias de Ingestão RM - Ressonância Magnética SABE - Saúde, Bem-estar e Envelhecimento SAS - Secretária de Atenção à Saúde SBEM –  Sociedade Brasileira de Endocrinologia e Metabologia (SBEM) SUS – Sistema Único de Saúde TC – Tomografia Computadorizada TEP -  Tromboembolismo Pulmomar TEV  -  Tromboembolismo venoso TVP – Trombose Venosa Profunda UNIFESP -  Universidade Federal de São Paulo US – Ultrassonografia

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **DECLARAÇÃO DE CONFLITO DE INTERESSES E FINANCIAMENTO** -->
O coordenador, o grupo elaborador e o grupo consultivo declararam não ter nenhum conflito de interesse.  
O grupo elaborador e o revisor receberam bolsa financiada pela carta acordo OPAS nº Carta Acordo OPAS/MS BR/LOA/1500003.001.  O grupo consultutivo não recebeu bolsa ou qualquer outra forma de remuneração.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **REFERÊNCIAS** -->
1- Evolução dos Grupos Etários 2000-2030. IBGE, BRASIL. Disponível em: <u>www.ibge.gov.br.</u> Acesso em 05  Fev 2015.  
2 -Saúde, bem- estar e envelhecimento: estudo SABE no município de São Paulo, Lebrão, M.L. et al.,  Revista Brasileira de Epidemiologia 2005; 8(2): 127-41  
52  
3 - **Siqueira FV et al.** Prevalence of falls in elderly in Brazil: a countrywide Analysis **Prevalência. Cad. Saúde Pública, Rio de Janeiro, 27(9):1819-1826, set, 2011**  
4 - Rodrigues M P e Ramos L R. Fatores associados a quedas em uma coorte de idosos residentes na comunidade, Centro de Estudos do Envelhecimento da Universidade Federal de São Paulo (Unifesp). São Paulo, SP, Brasil, Rev. Saúde Pública 2002; 36(6): 709-16.  
5 – MV PORTAL. Instituto Nacional de Traumatologia e Ortopedia (INTO), Rio de janeiro. Disponível em: <http://painel.into.saude.gov.br/Painel/Privado/Default.aspx> acesso  em 15 jun. 2016.  
6  - Porter SE, Russel JV, Qin Z, Graves ML. Operative Fixation of Acetabular Fractures in the Pregnant Patient. _J Orthop Trauma_ 2008;22:508-516.  
7 - Griffiths R, Alper J, Beckingsale A, Goldhill D, Heyburn G et al. Management of proximal femoral fractures 2011 Association of Anaesthetists of Great Britain and Ireland. _Anaesthesia_ 2012;67:85–98  
8 - Shiga T, Wajima Z, Ohe Y. Is operative delay associated with Increased mortality of hip fracture patients? Systematic  review, meta-analysis, and meta-regression. _Can J Anesth_ 2008;55:146–154.  
9 - Bryson GL. Waiting for hip fracture repair - Do outcomes and patients suffer? _Can J Anesth_ 2008;55:135–139.  
10 - Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Gestão e Incorporação de Tecnologias em Saúde. Diretrizes metodológicas: elaboração de diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Gestão e Incorporação de Tecnologias em Saúde. – Brasília: Ministério da Saúde, 2016. Disponível em: <http://conitec.gov.br/index.php/protocolos>>. Acesso em 20 jan2016.  
11- Diretrizes metodológicas: ferramentas para adaptação de diretrizes clínicas/ Ministério da Saúde, Secretária de Ciências, Tecnologia e Insumos estratégicos, Departamento de Ciências e TecnologiaBrasília: Ministério da Saúde, 2014. 108p: II.  
12- Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde/ Ministério da Saúde, Secretária de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia – Brasília: Ministério da Saúde, 2014.  
13- National Clínical Guideline Centre (NICE) - National Clínical Guideline Centre, (2011) The Management of Hip Fracture in Adults]London: National Clínical Guideline Centre.Disponível em: <www.ncgc.ac.uk>. Acesso em: 17 ago 2015.  
14- American Academy of Orthopaedic Surgeons ( AAOS) - Management of Hip Fractures in the Elderly Evidence- Based Clínical Practice Guideline adopted by the American Academy of Orthopaedic Surgeons, september 5, 2014. Disponível em: <u><</u> _<u>http://www.aaos.org/research/guidelines/HipFxGuideline.pdf</u>_ <u>></u> _<u>.</u>_ <u>Acesso em: 15 jul 2015.</u>  
15- AGREE Next Steps Consortium (2009). The AGREE II Instrument – disponível em: http:// <u>www.agreetrust.org. Acesso: 20 jun 2015.</u>  
16- Foss NB, Kehlet H. Mortality analysis in hip fracture patients: implications for design of future outcome trials. _Br J Anaesth_ 2005; 94:24-29.  
17- Pederson JP, Borgbjerg FM, Schousboe B, Pederson BD, Jorgensen HL et al. A comprehensive Hip Fracture Program Reduces Complication Rates and Mortality. _Journal of the American Geriatrics Society_ 2008; 56:1831:1838.  
53  
18- Kalore NV, Guay J, Eastman JM, Nishimori M, Singh JA. Nerve blocks or no nerve blocks for pain control after elective hip replacement (arthroplasty) surgery in adults (Protocol). The Cochrane Library 2015, Issue 3.  Disponível em: <http://www.thecochranelibrary.com>. Acesso em: 14 dez 2015.  
19- Kötter T, Costa B R., Fässler M, Eva, Blozik K L, Peter Jüni, Stephan Reichenbach, Martin Scherer. Metamizole-Associated Adverse Events: A Systematic Review and Meta-Analysis. PLOS ONE | DOI:10.1371/journal.pone.0122918 April 13, 2015.  
20- Painel Internacional de Avaliação da Segurança da Dipirona.  ANVISA – Ministério da Saúde. Brasília, 3 e 4 de julho de 2001.  
21- Derry S, Faura C, Edwards J, McQuay HJ, Moore RA. Single dose dipyrone for acute postoperative pain (Review). Cochrane Library 2010, Issue 9. Disponível em: <u><http://www.thecochranelibrary.com>. Acesso em: 15 dez 2015.</u>  
22 - Moore RA, Wiffen PJ, Derry S, Maguire T, Roy YM, Tyrrell L. Non-prescription (OTC) oral analgesics for acute pain – an overview of Cochrane reviews (Review). The Cochrane Library  2015, Issue 11  
23 - Dall'Olio G, Betti E, Machado P L R C, Guimarães S O, Feder D. Agranulocitose induzida por dipirona. RBM Revista Brasileira de Medicina, Moreira Jr Editora, 21/12/2015.  
24 - Wannmacher L. Paracetamol versus Dipirona: como mensurar o risco?, Uso racional de medicamentos: temas selecionados. Vol. 2, Nº5, Brasília, abril de 2005, ISSN 1810-0791.  
25 - Vale N. Desmistificando o Uso da Dipirona. Medicina Perioperatória, Capitulo 126, 107-126p.  
26- White SM, Griffiths R, Holloway J, Shannon A.Anaesthesia for proximal femoral fracture in the UK: first report from the NHS Hip Fracture Anaesthesia; Network. _Anaesthesia_ 2010; 65 :243–248.  
27- Kearns RJ,Moss L, Kinsella J.A comparison of clínical practice guidelines for proximal femoral Fracture. _Anaesthesia_ 2013;68:159–166.  
28- Neuman M, Silber J, Elkassabany N, Ludwig J, Fleisher L.Comparative Effectiveness of Regional versus General Anesthesia for Hip Fracture Surgery in Adults. _Anesthesiology_ 2012; 117:72–92.  
29 -Wood R, White SM. Anaesthesia for 1131 patients undergoing proximal femoral fracture repair: effects on blood pressure, fluid administration and perioperative anaemia. _Anaesthesia_ 2011; 66:1017–22.  
30 - Medidas de Prevenção de Infecção Relacionada à Assistência à Saúde - Série  Segurança do Paciente e Qualidade em Serviços de Saúde. Agência Nacional de Vigilância Sanitária -  ANVISA – MS – 1º edição, 2013  
31- Assistência Segura: Uma Reflexão Teórica Aplicada à Prática -  Série Segurança do Paciente e Qualidade em Serviços de Saúde. Agência Nacional de Vigilância Sanitária -  ANVISA – MS – 1º edição, 2013  
32- Surgical site infection. NICE clínical guideline CG74 (2008). Disponível em: <u><www.nice.org.uk/CG74>. Acesso em: 21 dez 2015.</u>  
33- Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Assistência Farmacêutica e Insumos Estratégicos. Relação Nacional de Medicamentos Essenciais – Rename / Ministério da Saúde, Secretaria de Ciência, Tecnologia e  
54  
Insumos Estratégicos. Departamento de Assistência Farmacêutica e Insumos Estratégicos – – Brasília: Editora do Ministério da Saúde, 2008  
34- Transfusion Blood transfusion.NICE guideline NG24. Methods, evidence and recommendations, November 2015 _._ Disponível em:<https://www.nice.org.uk/guidance/ng2> Acesso em: 22 dez 2015.  
35- Yang Y, Li H, Li B, Wang Y, Jiang S, Jiang L.  Department of Orthopedics, Xinhua Hospital, The School of Medicine, Jiao Tong University, Shanghai, China. Dezembro 2011 Volume 171, Issue 2, Pages E201-E207. Disponível em DOI: <http://dx.doi.org/10.1016/j.jss.2011.08.025>.Acesso em: 16 dez 2015.  
36- Carson, J.L. et al. Red Blood Cell Transfusion: A Clínical Practice Guideline From the AABB. _Ann Intern Med._ 2012;157(1):49-58.  
37 - Cohen AT, Tapson VF, Bergmann JF, Goldhaber SZ, Kakkar AK, Deslandes B, Huang W, Zayaruzny M, Emery L, Anderson FA Jr; ENDORSE Investigators. Venous thromboembolism risk and prophylaxis in the acute hospital care setting (ENDORSE study): a multinational cross-sectional study. Lancet. 2008 Feb 2;371(9610):387-94.  
38- Geerts WH, Pineo GF, Heit JA, Bergqvist D, Lassen MR, Colwell CW, Ray JG. Prevention of venous thromboembolism: the Seventh ACCP Conference on Antithrombotic and Thrombolytic Therapy. Chest. 2004; 126(Suppl 3):338S-400.  
39- Falck-Ytter Y, Francis C W, Johanson N A, Curley C, Dahl O E, Schulman S, Ortel T L, Pauker S G and Colwell Jr C W. Prevention of VTE in Orthopedic Surgery Patients: Antithrombotic Therapy and Prevention of Thrombosis, 9th ed: American College of Chest Physicians Evidence –Based Clínical Practice Guidelines. Chest 2012; 141; e278-e325S.  
40- Eriksson BI, Dahl OE, Huo MH, Kurth AA, Hantel S, Hermansson K, Schnee JM, Friedman RJ. Oral dabigatran versus enoxaparin for thromboprophylaxis after primary total hip arthroplasty (RENOVATE II*). A randomized, double-blind, non-inferiority trial. RE-NOVATE II Study Group. Thromb Haemost. 2011; Apr; 105(4):721-9.  
41- Eriksson BI, Dahl OE, Rosencher N, Kurth AA, van Dijk CN, Frostick SP, Prins MH, Hettiarachchi R, Hantel S, Schnee J, Büller HR. Dabigatran etexilate versus enoxaparin for prevention of venous thromboembolism after total hip replacement: a randomized, double-blind, non-inferiority trial. RE-NOVATE Study Group. Lancet. 2007 Sep 15; 370(9591):949-56.  
42- Eriksson BI, et al. Rivaroxaban versus enoxaparin for thromboprophylaxis after hip arthroplasty. N Engl J Med. 2008; 358:2765-2775. RECORD 1 TRIAL.  
43- Kakkar AK et al. (2008) Extended duration rivaroxaban versus short-term enoxaparin for the prevention of venous thromboembolism after total hip arthroplasty: a double blind, randomized controlled trial. Lancet 372: 31–39. RECORD 2 TRIAL  
44- American Academy of Orthopaedic Surgeons.Total hip replacement. American Academy of Orthopaedic Surgeons. Disponível em:http://orthoinfo.aaos.org/topic. cfm/topic = a00377. Acesso em: 17 dez 2015.  
45-Venous thromboembolism – reducing the risk. NICE clínical guideline CG92 (2010). Disponível em: <http://guidance.nice.org.uk/CG92>.  Acesso em: 08 dez 2015.  
46- Morais GQ, Burgos M GPA. Impacto dos nutrientes na saúde óssea: novas tendências. Revista Brasileira de Ortopedia, São Paulo, v. 42, n. 7, p. 189-194, 2007.  
55  
47- Jorge R A, Rodrigues C. S. C. Papel dos nutrientes na prevenção e no tratamento da osteoporose. Revista Brasileira de Nutrição Clínica, Porto Alegre, v. 24, n. 1, p. 66-71, 2009.  
48- Lanham-New, S. A. Importance of calcium, vitamin D and vitamin K for osteoporosis prevention and treatment. Proceedings of the Nutrition Society, v. 67, p. 163–176, 2008  
49- Peters B S E, MARTINI, L. A. Nutritional aspects of the prevention and treatment of osteoporosis. Arquivos Brasileiros de Endocrinologia e Metabologia, São Paulo, v. 54, n. 2, p. 179-185, 2010.  
50- Guiding Principles for Nutrition Labeling and FortificationCommittee on Use of Dietary Reference Intakes in Nutrition LabelingFood and Nutrition Board.Institute Of Medicine (IOM).The National Academies The National Academies Press. Washington DC. Disponível em: <http://www.nap.edu/read/10872/chapter/1>. Acesso em: 14 maio 2013.  
51- MarchinI JS, Ferrioli E & Moriguti J C. Suporte nutricional no paciente idoso: definição, diagnóstico, avaliação e intervenção. Medicina, Ribeirão Preto, n.31, p. 54-61, jan./mar, 1998.  
52- Guimarães  JM, Vaz M, Ono NK, Pires  OGN, Falavinha RS, Queiroz RD, Skaf AY. Fratura do colo femoral no idoso: osteossíntese e artroplastia. Associação Médica Brasileira e Conselho Federal de Medicina / Projeto Diretrizes, nov., 2007  
53- Espaulella J, Guyer H, Dias-Escriu F, Mellado-Navas J A,  Castells M,  Pladevall M. Nutritional supplementation of elderly hip fracture patients. A randomized, double-blind, placebo-controlled trial. Age Ageing, n.29, p.425-431, 2000.  
54-   Lawson R M, Doshi M K, Ingoe LE, Colligan JM, Barton J R,  Cobden I. Compliance of orthopedic patients with postoperative oral nutritional supplementation. Clínical Nutrition, n.19, p.171-175, 2000.  
55-  Gariballa SE, Parker SG, Taub N, Castlede CM. A randomized, controlled, singleblind. Trial of nutritional supplementation after acute stroke. Journal of Parenteral and Enteral Nutrition (JPEN), n.22, p.315-319, 1998.  
56- Celano RMG,  Loss SH, Negrão RJN. Terapia Nutricional para pacientes na senescência (geriatria). Projeto Diretrizes/Associação Médica Brasileira e Conselho Federal de Medicina, set. 2011.  
57- Bonjour JP. Dietary protein: an essential nutrient for boné health. Journal of the American College of Nutrition, n.24 (6 Suppl), p.526S-536S, 2005.  
58- Morais GQ, Burgos MGPA. Impacto dos nutrientes na saúde óssea: novas tendências. Revista Brasileira de Ortopedia, v.42, n.7, p.189-94, 2007.  
59- Vellas B _et al.._ The Mini Nutritional Assessment (MNA) and this use in grading the nutritional state of elderly patients. Nutrition **,** Burbank, v.15, n.2, p.116-122, Feb, 1999.  
60- “Nutrition Support in Adults. NICE Clínical Guideline 32” e atualização de 2013 Disponível em: <u><https://www.nice.org.uk/guidance/cg32/evidence/evidence-update194887261>.Acesso em: 05 dez</u> 2015.  
61- Consenso Brasileiro de Osteoporose 2002. Revista Brasileira de Medicina.Morereira J. Disponível  em: <http://www.moreirajr.com.br/revistas.asp?id_materia=2599&fase=imprime>. Acesso em: 21 dez 2015.  
56  
62- Pacheco M. Tabela de Equivalentes, Medidas Caseiras e Composição Química dos Alimentos, Editora Rubio, Rio de Janeiro, 672 p., 2006.  
63- DIPART GROUP (Vitamin D Individual Patient Analysis Of Randomized Trials Group). Patient level pooled analysis of 68500 patients from seven major vitamin D fracture trails in US and Europe. Cite this as: BMJ 2010, 340:b5463 doi:10.1136/bmj.b5463. 2010  
64- Food And Nutrition Board/Institute Of Medicine. Dietary reference intake for calcium, phosphorus, magnesium, vitamin D and fluoride. Washigton D.C.: National Academies Press, 448p., 1999.  
65- Recomendações da Sociedade Brasileira de Endocrinologia e Metabologia (SBEM) para o diagnóstico e tratamento da hipovitaminose D , Arquivo  Brasileiro Endocrinologia Metabologia - 2014;58/5, São Paulo- Brasil , recebido em 31/Mar/2014, aceito em 18/jun/2014  
66 -  Althoff MEWS, Ramos DMB, Silva  DMWS, Neto PES. A importância da vitamina D na prevenção de fraturas em adultos acima de 45 anos. Revista Brasileira de Nutrição Esportiva, São Paulo, v.3, n.13, p.50-62, Jan/Fev, 2009.  
67 - Protocolo Clínico e Diretrizes Terapêuticas:  Osteoporose , Portaria SAS/MS nº 451, de 9 de junho de 2014, republicada em 9 de junho de 2014 e retificada em 18 de junho de 2014. / Ministério da Saúde, Secretária de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia – Brasília: Ministério da Saúde, 2014.  
68 -  Holick MF. Sunlight and vitamin D for bone health and prevention of autoimmune diseases, cancers, and cardiovascular disease. The American Journal of Clínical Nutrition, n.80 (suppl.), p. 1678S – 1688S, 2004.  
69 - Schiavo GMN, Vaz EC,Ravelli MN, Kihara KA, Saullo CM, Corrente JE, Nogueira CR. Perfil do consumo nutricional de pacientes com massa óssea diminuída. Revista Ciência em Extensão, v.10, n.2, p.7-18, 2014.  
70 -  Pinheiro MM, Schuch NJ, Genaro OS, Cicconeli RM, Ferraz MB, Martini LA. Nutrient intakes related to osteoporotic fractures in men and women – THE BRAZILIAN OSTEOPOROSIS STUDY (BRAZOS). Nutrition Journal **,** v.8, n.6, p. 1-8, 2009.  
71 - Assessing the risk of fragility fracture, NICE guideline, Draft for consultation, February 2012.Disponivel em:<http://www.nice.org.uk/guidance/cg146/documents/osteoporosis-fragilityfracture-risk-nice-guideline2>.Acessado em: 08 dez 2015.  
72 - Gonçalves JR, Lins C; Parecer Técnico Científico: Eficácia e Segurança de Ácido Zoledrônico para o Tratamento da Osteoporose. Centro Colaboradores do SUS:  Avaliação de Tecnologias e Excelência em Saúde – CCATES,  Faculdade de Farmácia UFMG, Brasil.  PTC 14/2014.  
73 - Ministério da Saúde Secretaria de Atenção à Saúde,Departamento de Atenção Especializada e Temática,Caderneta de Saúde da Pessoa Idosa,3ª edição, Brasília – DF, 2014. Disponível em: http://bvsms.saude.gov.br/bvs/publicacoes/caderneta_saude_pessoa_idosa_3ed.pdf> acesso em 10/08/2017.  
74- Melhor em Casa. Coordenação Geral de Atenção Domiciliar. Departamento de Atenção Básica/ DAB. Ministério da Saúde, 8 de novembro de 2011 – Disponível em: <dab. saude.gov.br/portaldab/ape_melhor_em_casa.php>. Acesso em: 21 dez 2015.  
57  
75- NEW 2014 Prevention and Treatment of Pressure Ulcers: Clínical Practice Guideline - National Pressure Ulcer Advisory Panel (NPUAP), European Pressure Ulcer Advisory Panel (EPUAP) and Pan Pacific Pressure Injury Alliance (PPPIA) – Disponível em: <http://www.npuap.org/resources/educational-and-clínical-resources/prevention-and-treatment-ofpressure-ulcers-clínical-practice-guideline/>.  Acesso em: 23 jan 2016.  
76- Pressure ulcers: prevention and management -NICE guidelines [CG179] Published date: April 2014 <https://www.nice.org.uk/guidance/cg179/evidence/full-guideline-management547610510>. Acesso em : 23 jan 2016.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Apêndice 1 - Membros do Grupo avaliador e Grupo Consultivo** -->
|**COORDENADOR  DAS  DIRETRIZES**|
|---|
|Tito Henrique de Noronha Rocha -  Médico ortopedista|
|**GRUPO ELABORADOR DAS DIRETRIZES**|
|Carlos Alexandre de Oliveira - Médico ortopedista|
|Leandro Albuquerque Lemgruber  Kropf -   Médico ortopedista|
|Verônica Clemente – Enfermeira|
|**GRUPO CONSULTIVO**|
|Airton Stein   -  Revisor|
|**Busca Sistemática**|
|Carlos José Bastos Saldanha – Bibliotecário<br>Letícia Krauss Provenzano -  Bibliotecário|
|**Analgesia e Anestesia**|
|Affonso Henrique de Vasconcellos Zugliani -  Médico  Anestesista|
|Márcio Curi Rondinelli  -     Médico  - Clínica da Dor|
|**Infecção Cirúrgica**|
|Juliana Arruda de Matos  -  Médica Infectologista|
|**Indicação de Transfusão**|
|Fernanda Azevedo Silva -  Médica Hematologista|
|**Profilaxia de TVP**|
|Maria Celia de Andrade   - Médica Intensivista (in memoriam)<br>Ricardo Castro  -  Cirurgião Vascular|
|**Reabilitação**|
|**Fisioterapia**|
|Marcia Maria Botino Guimarães|
|**Terapia Ocupacional**|
|Doralice das Graças de Melo Calvo  - Terapeuta Ocupacional<br>Gledson Nunes da Silva - Terapeuta Ocupacional|
|**Pedagoga **|
|Marcia Theophilo Lima costa|
|**Cálcio, Vitamina D e Osteoporose**|
|Luciana Lopes de Souza Soares  -  Nutricionista|
|Maria Isabel Bordallo -   Médica Reumatologista|
|**Geriatra e Exames**|
|Ana Lúcia Vilela  - Médica  Geriatra|
|Salo Buksman    -   Médico Geriatra|
|**Atendimento Domiciliar**|
|Claudia Mendes de Araújo  - Enfermeira ( Visita Domiciliar)<br>Luciana de Almeida Marques Oliveira  -  Enfermeira(Visita Domiciliar)|
|**Lesãopor Pressão**|  
58  
<mark>Amanda Campos Macedo Ramos – Enfermeira Flavia Gomes de Aguiar Canatto  - Enfermeira Patricia de Souza Nogueira – Enfermeira Renata Alves Teixeira da Costa  - Enfermeira</mark>  
**<u><mark>Revisão Linguistica</mark></u>** <mark>Vicente de Paulo Góes da Silva   - Professor  de   Língua   Portuguesa</mark>  
59

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 1** -->
Para pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur a radiografia é acurada para o diagnóstico de fratura oculta de colo de fêmur?

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 2** -->
Para pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur a radiografia é acurada para o diagnóstico de fratura desviada de colo de fêmur?  
((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab] OR displaced fracture of neck of femur[tiab] OR displaced femoral neck fractur*[tiab] OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND ((“Radiography"[Mesh] OR X-Ra*[tiab] OR xra*[tiab] OR "Femoral Neck Fractures/radiography”[M esh] OR “Hip Fractures/radiography”[M esh]))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA AS PERGUNTAS 3 E 4._ Pergunta 3** -->
Para pacientes idosos com (sintomatologia) sugestiva de fratura de colo de fêmur a radiografia sob tração com rotação externa e interna é acurada para o diagnóstico de fratura oculta de colo de fêmur?

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 4** -->
Para pacientes idosos com (sintomatologia) sugestiva de fratura de colo de fêmur oculta o bloqueio regional comparado à analgesia é eficaz e seguro, na radiografia sob tração com rotação externa e interna?  
((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND ((((“Radiography"[Mesh] OR X-Ra*[tiab] OR xra*[tiab] OR "Femoral Neck Fractures/radiography”[M esh] OR “Hip Fractures/radiography”[M esh]))) AND ((Internal rotation[tiab] OR external rotation[tiab])))) AND ((randomized controlled trial [pt] OR controlled clínical trial [pt] OR randomized controlled trials [mh] OR  
60  
random allocation [mh] OR double-blind method [mh] OR single-blind method [mh] OR clínical trial [pt] OR clínical trials[mh] OR (“clínical trial”[tw]) OR ((singl*[tw] OR doubl*[tw] OR trebl*[tw] OR tripl*[tw]) AND (mask*[tw] OR blind*[tw])) OR (placebos [mh] OR placebo* [tw] OR random* [tw] OR research design [mh:noexp] OR comparative study [pt] OR evaluation studies as topic [mh] OR follow-up studies [mh] OR prospective studies [mh] OR control* [tw] OR prospective* [tw] OR volunteer* [tw]) NOT (animals [mh] NOT humans [mh])))

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 5** -->
Para pacientes idosos com sintomatologia sugestiva de fratura oculta de colo de fêmur a analgesia com anti-inflamatório é indicada?  
((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND (((((("Anti-Inflammatory Agents"[Mesh] OR Anti Inflammatory Agents OR Agents, Antiinflammatory OR Antiinflammatories OR Antiinflammatory Agents OR Agents, AntiInflammatory OR Agents, Anti Inflammatory OR Anti-Inflammatories OR Anti Inflammatories OR antiinflammatory analgesi*[tiab] OR antiinflammatory analgesi*[tiab]))) OR ("Analgesia"[Mesh] OR Analgesias))) OR ("Pain Management"[Mesh] OR Management, Pain))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 6_ Pergunta 6** -->
Para pacientes idosos com fratura de colo de fêmur, o tratamento cirúrgico com osteossíntese ou artroplastia é eficaz quando comparado ao tratamento não operatóriopara o controle da dor,  
aumentar a mobilidade e melhorar a qualidade de vida do paciente?  
(((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND (“Arthroplasty, Replacement"[Mesh] OR "Arthroplasty, Replacement, Hip"[Mesh] OR Joint Prosthesis Implantation OR Implantation, Joint Prosthesis OR Implantations, Joint Prosthesis OR Joint Prosthesis Implantations OR Prosthesis Implantation, Joint OR Prosthesis Implantations, Joint OR Replacement Arthroplasty OR Arthroplasties, Replacement OR Replacement Arthroplasties OR Arthroplasties, Replacement, Hip OR Arthroplasty, Hip Replacement OR Hip Prosthesis Implantation OR Hip Prosthesis Implantations OR Implantation, Hip Prosthesis OR Implantations, Hip Prosthesis OR Prosthesis Implantation, Hip OR Prosthesis Implantations, Hip OR Hip Replacement Arthroplasty OR Replacement Arthroplasties, Hip OR Replacement Arthroplasty, Hip OR Arthroplasties, Hip Replacement OR Hip Replacement Arthroplasties OR Hip Replacement, Total OR Replacement, Total Hip OR Hip Replacements, Total OR  
61  
Replacements, Total Hip OR Total Hip Replacements OR Total Hip Replacement OR "Hemiarthroplasty"[Mesh ] OR Hemi Arthroplast* OR Hemi-Arthroplast* OR Hemiarthroplasty[tiab])) AND (("Quality of Life"[Mesh] OR Life Qualit* OR "Pain Management"[Mesh] OR Management, Pain OR pain relief OR pain reduction OR mobility[tiab]))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 7_ Pergunta 7** -->
Para pacientes idosos com fratura de colo de fêmur a profilaxia com heparina de baixo peso molecular é eficaz para prevenir a trombose venosa profunda?  
(((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND ("Heparin, LowMolecular-Weight"[Mesh] OR Heparin, Low Molecular Weight OR LMWH OR Low Molecular Weight Heparin OR LowMolecular-Weight Heparin)) AND ("Venous Thrombosis"[Mesh] OR Thrombosis, Venous OR Thromboses, Venous OR Venous Thromboses OR Phlebothrombosis OR Phlebothromboses OR Deep Vein Thrombosis OR Deep Vein Thromboses OR Thromboses, Deep Vein OR Vein Thromboses, Deep OR Vein Thrombosis, Deep OR Thrombosis, Deep Vein OR Deep-Venous Thrombosis OR DeepVenous Thromboses OR Thromboses, DeepVenous OR Thrombosis, Deep-Venous OR Deep Venous Thromboses OR Thromboses, Deep Venous OR Thrombosis, Deep Venous OR Venous Thromboses, Deep OR Venous Thrombosis, Deep OR Deep-Vein Thrombosis OR Deep-Vein Thromboses OR Thromboses, Deep-Vein OR Thrombosis, DeepVein)) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 8** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico de osteossíntese, artroplastia parcial ou total, a avaliação da densidade mineral óssea influência na evolução clínica?  
(((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND (("Densitometry"[Mesh]) AND ("Bone Density"[Mesh] OR Bone Densities OR Density, Bone OR Bone Mineral Density OR Bone Mineral Densities OR Density, Bone Mineral OR Bone Mineral Content OR Bone Mineral Contents)))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 9_** -->
62

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 9** -->
Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento cirúrgico osteossíntese, com artroplastia parcial ou total, a reposição de cálcio e vit D, melhora a densidade mineral óssea?  
((((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck 18 Artigos 03 Artigo s #1 (tw:(Aged OR Anciano OR Idoso OR Elderly)) #2 Femoral Neck Fractures OR Fracturas del Cuello Femoral OR Fraturas do Colo Femoral #3 (tw:((tw:(Aged OR Anciano OR Idoso OR Elderly)))) AND (tw:(Femoral Neck Fractures OR Fracturas del Cuello Femoral OR Fraturas do Colo Femoral)) #4 Calcium OR Calcio OR Cálcio OR Vitamin D OR Vitamina D #5 #3 AND 4 130 Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab])))) AND <u>(("Calcium"[Mesh]) AND "Vitamin D"[Mesh])) AND systematic[sb]</u>

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 10** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico osteossíntese, com artroplastia parcial ou total, o uso de bifosfonados é indicado?  
((((Aged OR Anciano OR Idoso OR Elderly)) AND (Femoral Neck Fractures OR Fracturas del Cuello Femoral OR Fraturas do Colo Femoral)) AND (Osteoporosis OR Osteoporosis OR Osteoporose)) AND (Therapeutics OR Terapéutica OR Terapêutica)

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 11_ Pergunta 11** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com osteossíntese, o acompanhamento (por X tempo) é eficaz para detecção de alterações póscirúrgicas?  
((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND (("Fracture Fixation, Internal"[Mesh] OR Fixation, Internal Fracture OR Fracture Fixations, Internal OR Internal Fracture Fixation* OR Osteosynthes*, Fracture OR Fracture Osteosynthes* OR Osteosynthes*[tiab]))) AND ((follow up[tiab] OR followup[tiab]))) AND systematic[sb]  
63

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 12** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com artroplastia parcial, o acompanhamento (por x tempo) é eficaz para detecção de alterações relacionadas à prótese?

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Pergunta 13** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com artroplastia total o acompanhamento (por x tempo) é eficaz para detecção de alterações relacionadas à prótese?  
((((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND ((“Arthroplasty, Replacement"[Mesh] OR "Arthroplasty, Replacement, Hip"[Mesh] OR Joint Prosthesis Implantation OR Implantation, Joint Prosthesis OR Implantations, Joint Prosthesis OR Joint Prosthesis Implantations OR Prosthesis Implantation, Joint OR Prosthesis Implantations, Joint OR Replacement Arthroplasty OR Arthroplasties, Replacement OR Replacement Arthroplasties OR Arthroplasties, Replacement, Hip OR Arthroplasty, Hip Replacement OR Hip Prosthesis Implantation OR Hip Prosthesis Implantations OR Implantation, Hip Prosthesis OR Implantations, Hip Prosthesis OR Prosthesis Implantation, Hip OR Prosthesis Implantations, Hip OR Hip Replacement Arthroplasty OR Replacement Arthroplasties, Hip OR Replacement Arthroplasty, Hip OR Arthroplasties, Hip Replacement OR Hip Replacement Arthroplasties OR Hip Replacement, Total OR Replacement, Total Hip OR Hip Replacements, Total OR Replacements, Total Hip OR Total Hip Replacements OR Total Hip Replacement OR "Hemiarthroplasty"[Mesh ] OR Hemi Arthroplast* OR Hemi-Arthroplast* OR Hemiarthroplasty[tiab]))) AND ((follow up[tiab] OR follow-up[tiab]))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 14_ Pergunta 14** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com osteossíntese, artroplastia parcial ou total, a mobilização e a carga com auxílio precoce, acelera a  
recuperação?  
(((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND <u>((((("Early Ambulation"[Mesh] OR Mobilization[tiab]))) AND ("Weight-</u>  
64  
Bearing"[Mesh] OR Weight Bearing OR Weightbearing OR Loadbearing OR Load (((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND ((((("Early Ambulation"[Mesh] OR Mobilization[tiab]))) AND ("WeightBearing"[Mesh] OR Weight Bearing OR Weightbearing OR Loadbearing OR Load Bearing OR LoadBearing))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 15_ Pergunta 15** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com osteossíntese, artroplastia parcial ou total, o fortalecimento muscular reduz as recidivas de queda?  
(((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND ("Resistance Training"[Mesh] OR strength training[tiab] OR muscle strenght[tiab] OR improvement of muscle strenght[tiab])) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **_ABAIXO, ESTRATÉGIA FORMULADA PARA A PERGUNTA 16_ Pergunta 16** -->
Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com osteossíntese, artroplastia parcial ou total, o acompanhamento com equipe multidisciplinar  
influência na evolução pós-operatória?  
(((("Aged"[Mesh] or Elderly))) AND (("Femoral Neck Fractures"[Mesh] OR Femoral Neck Fractur*[tiab] OR Femur Neck Fractur*[tiab] OR suspected femoral neck fracture[tiab] OR occult fractured neck of femur[tiab] OR occult femoral neck fractur*[tiab]))) OR "Hip Fractures"[Mesh] OR hip fracture*[tiab]))) NOT (((animal[mh] NOT human[mh]) OR cadaver[mh] OR cadaver*[tiab]))) AND ((((("Early Ambulation"[Mesh] OR Mobilization[tiab]))) AND ("WeightBearing"[Mesh] OR Weight Bearing OR Weightbearing OR Loadbearing OR Load Bearing OR LoadBearing))) AND systematic[sb]

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Apêndice 3 – Busca das Diretrizes** -->
|Nome da Organização|URL|Recursos /Referências|Avaliaçã<br>o|
|---|---|---|---|  
65  
|NICE National<br>Institute for Health and<br>Care Excellence -<br>Inglaterra|http://www.nice.org.uk/gu<br>idance/cg124/evidence/cg<br>124-hip-fracture-full-<br>guideline2|Hip fracture The management of hip<br>fracture in adults 2011|Incluída|
|---|---|---|---|
|NICE National<br>Institute for Health and<br>Care Excellence -<br>Inglaterra|https://arms.evidence.nhs.<br>uk/resources/.../attachmen<br>t|Evidence Update A summary of selected<br>new evidence relevant to NICE clínical<br>guideline 124 ‘The management of hip<br>fracture in adults’(2011)March 2013|Incluída|
|NICE National<br>Institute for Health and<br>Care Excellence -<br>Inglaterra|http://www.nice.org.uk/gu<br>idance/cg124|Hip fractureThe management of hip<br>fracture in adults Issued: June 2011 last<br>modified: March 2014|Incluída|
|AAOS - American<br>Academy of<br>Orthopaedic Surgeons<br>- EUA|http://www.aaos.org/Rese<br>arch/guidelines/HipFxGui<br>deline.pdf|Manegement of Hip Fractures in the<br>Elderly - Evidence- Based Clínical<br>Practice  Guideline  Adopted by the<br>American Academy of Orthopaedic<br>Surgeons  Board of Directors  September<br>5,2014|Incluída|
|ANZHFR - Australian<br>and New Zealand Hip<br>Fracture Registry -<br>Nova Zelândia e<br>Australia|http://www.anzhfr.org/gui<br>delines-and-standards/|Improving Outcomes in Hip Fracture<br>Management  of Adults  - Diretrizes se<br>baseiam nas diretrizes clínicas do NICE -<br>Guideline 124 ‘The management of hip<br>fracture in adults’(2011)|Excluída|
|SIGN - Scottish<br>Intercollegiate<br>Guidelines Network  -<br>Escócia|http://www.sign.ac.uk/gui<br>delines/fulltext/111/|Management of hip fracture  in older<br>people    A national clínical Guideline<br>june 2009|Excluída|
|GPC-Guía dePráctica<br>Clínica -México|www.cenetec.salud.gob.m<br>x/interior/gpc.html|Tratamiento de Fractura  Desplazada<br>Dell Cuello Femoral com Artroplastia<br>Total   En Adultos   Mayores del 65 años<br>Guías de Práctica Clínica:  IMSS 573-12<br>-2009|<br>Excluída|
|GPC  -Guía de<br>Práctica Clínica -<br>México|http://www.cenetec.salud.<br>gob.mx/descargas/gpc/Cat<br>alogoMaestro/115_GPC_<br>Fxintracextproxfemur/Fxf<br>emurEVR_CENETEC.pdf|Diagnóstico y Tratamiento de Fracturas<br>Intracapsulares del Extremo  Proximal<br>del Fémur - Evidencias e<br>Recomendaciones ; IMSS- 115-08 - 2009|Excluída|
|GPC  -Guía de<br>Práctica Clínica -<br>México|http://www.cenetec.salud.<br>gob.mx/descargas/gpc/Cat<br>alogoMaestro/236_GPC_<br>Manejo_medico_integral_<br>fractura_de_cadera_adult<br>o_mayor/236GRR.pdf|Manejo Médico Integral  DE<br>FRACTURA DE CADERA  En  el<br>Adulto Mayor Evidencias y<br>Recomendaciones   Catálogo Maestro de<br>Guías de Práctica Clínica:  IMSS-236-14<br>-  2014|Excluída|  
**Apêndice 4 – Avaliação das Diretrizes com a Ferramenta AGREE II**  
|**Avaliadores das Diretrizes no AGREE**|
|---|
|**II**|
|**Carlos  Alexandre de Oliveira**|
|**Cristiane Rocha de Oliveira**|  
66  
**Leandro  Albuquerque Lemgruber Kropf Quenia Cristina Persiliana Dias** **<mark>Verônica Clemente</mark>**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: AVALIAÇÃO GLOBAL DAS DIRETRIZES CLÍNICAS -->
Para cada pergunta, por favor, escolha a resposta que melhor caracteriza a avaliação da  diretriz  
1. Classifique a qualidade global dessas diretrizes.  
Qualidade mais  baixa possível          1      2      3      4       5     6    7          Qualidade mais  alta possível  
A Avaliação Crítica de: **MANAGEMENT OF HIP FRACTURES IN THE ELDERLY (AAOS)**  
Usando  o  instrumento  AGREE II

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Avaliação Geral** -->
Titulo:  MANAGEMENT OF HIP FRACTURES IN THE ELDERLY  
Qualidade geral destas diretrizes: 6/7  
A Avaliação Crítica de: **Hip fracture: The management of hip fracture in adults   (NICE)**  
Usando  o  instrumento  AGREE II  
Titulo:  Hip fracture: The management of hip fracture in adults Qualidade geral destas diretrizes: 6/7

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Perguntas PICO** -->
67  
Pergunta 1 →  Para pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur a radiografia é acurada para o diagnóstico de fratura  de colo de fêmur?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur I-  Radiografia  
C- Sem Radiografia  
O- Diagnóstico acurado  
Perguntas 2→ Para pacientes idosos com sintomatologia sugestiva de para fratura de colo de fêmur e radiografia  negativa, qual o melhor exame para confirmar o diagnóstico? Na impossibilidade da RM, qual o  exame diagnóstico com maior acurácia?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  com RX negativo ,  
na impossibilidade da ressonância  
I - Radiografia  
C – Sem Radiografia O -  Diagnóstico acurado  
Pergunta 3→Para pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur a  
radiografia sob tração com rotação externa e interna é acurada para o diagnóstico de fratura oculta de colo de fêmur?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  
I-   radiografia sob tração com rotação externa e interna  
C-  radiografia simples  de quadril  
O - Diagnóstico acurado  
Pergunta 4 → Para pacientes idosos com (sintomatologia) sugestiva de fratura de colo de fêmur oculta o bloqueio  regional comparado a analgesia é eficaz e seguro, na radiografia sob tração com rotação externa e interna?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  oculta  
I-    Bloqueio Regional  
C - Analgesia  
O -  Eficácia e Segurança  
68

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **TRATAMENTO** -->
Pergunta 5 → Para pacientes idosos com sintomatologia sugestiva de fratura oculta de colo de fêmur a analgesia com anti-inflamatório é indicada?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  oculta I-   Analgesia  
C – Anti- inflamatório  
O -  Eficácia e Segurança  
Pergunta 6 → Para pacientes idosos com fratura do colo do fêmur , o tratamento cirúrgico com osteossíntese ou artroplastia é eficaz  quando comparado com o tratamento não operatório para controle da dor, aumentar a mobilidade, diminuir a mortalidade e melhorar a qualidade de vida do paciente?  
P- Pacientes idosos com de fratura de colo de fêmur  submetidos à tratamento cirúrgico de  
osteossíntese,  artroplastia parcial ou total  
I-   Osteossíntese e artroplastia parcial e total  
C-   Tratamento não cirúrgico O - controle da dor, aumentar a mobilidade, diminuir a mortalidade e melhorar a qualidade de vida do paciente.  
Pergunta 7→ Para pacientes idosos com fratura de colo de fêmur a profilaxia com heparina de baixo peso molecular é eficaz para prevenir a trombose venosa profunda?  
P- Pacientes idosos com  de fratura de colo de fêmur  
I-   Heparina de baixo peso molecular  
C-   Placebo  
O -  prevenir trombose venosa profunda , mortalidade  
69  
Pergunta  8 → Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico por  osteossíntese,  artroplastia parcial ou total, a avaliação e tratamento da redução da densidade mineral óssea influência na evolução clínica?  
P- Pacientes idosos com  fratura de colo de fêmur   submetidos à tratamento cirúrgico de  
osteossíntese,  artroplastia parcial ou total  
I-   Avaliação e tratamento da redução da densidade mineral óssea  
C-  Sem intervenção  
O – osteopenia, osteoporose, taxa de fraturas e quedas.  
Pergunta  9  → Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento  
cirúrgico por osteossíntese,  artroplastia parcial ou total, a reposição de cálcio e vit D, melhora a densidade mineral óssea?  
P- Pacientes idosos com fratura de colo de fêmur  submetidos à tratamento cirúrgico de  
osteossíntese,  artroplastia parcial ou total I-reposição de Cálcio e VitaminaD  
C-  sem intervenção  
O -  Fratura  
Pergunta 10 → Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento cirúrgico por osteossíntese,  artroplastia parcial ou total, o uso de bifosfonados  é indicado? P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  submetidos à  
tratamento cirúrgico de  osteossíntese,  artroplastia parcial ou total  
I-   Bifosfonados  
C-  sem intervenção  
O - densidade mineral óssea, redução das fraturas,  osteoporose.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **ACOMPANHAMENTO  PÓS – CIRURGICO** -->
Pergunta 11→Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com osteossíntese , o acompanhamento  ( por X tempo)  é eficaz para detecção de alterações póscirúrgicas?  
P- Pacientes idosos com sintomatologia sugestiva de fratura de colo de fêmur  submetidos à tratamento cirúrgico com  osteossíntese  
I  - Acompanhamento ( por x tempo)  
C- sem acompanhamento  
70  
O -  Evolução no processo de consolidação, Presença ou não de sinais de necrose avascular póstraumática (NAV)  
Pergunta 12→ Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento cirúrgico com artroplastia parcial o acompanhamento (por x tempo) é eficaz para detecção de alterações relacionadas à prótese?  
P- Pacientes idosos com  fratura de colo de fêmur  submetidos à tratamento de artroplastia parcial I-  Acompanhamento ( por x tempo)  
C-  sem acompanhamento O -  posicionamento da prótese e desgaste do acetábulo  
Pergunta 13→ Para pacientes idosos com fratura de colo de fêmur submetidos à tratamento cirúrgico com  artroplastia total o acompanhamento (por x tempo) é eficaz para detecção de alterações relacionadas à prótese?                                                                P- Pacientes idosos com fratura de colo de fêmur submetidos à tratamento da artroplastia total  
I-  Acompanhamento ( por x tempo)                                                                                               C-  
sem acompanhamento  
O - posicionamento da prótese  e desgaste do acetábulo  
Pergunta 14 →Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento  
cirúrgico com  osteossíntese, artroplastia parcial ou total, a mobilização e a carga com auxílio precoce, acelera a recuperação ?  
P- Pacientes idosos com  fratura de colo de fêmur submetidos à tratamento cirúrgico com  
osteossíntese, artroplastia parcial ou total  
I-   mobilização e a carga com auxilio precoce  
C-   Mobilização e a carga com auxilio tardia  
O -  tempo  da recuperação, fortalecimento muscular.  
Pergunta 15 → Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento cirúrgico com osteossíntese, artroplastia parcial ou total, o fortalecimento muscular reduz as recidivas de queda?  
P- Pacientes idosos com  fratura de colo de fêmur  submetidos  à tratamento cirúrgico com  
osteossíntese, artroplastia parcial ou total  
I-    Fortalecimento muscular  
C-    Sem intervenção  
71  
O -   Reduzir  recidivas de quedas  
Pergunta 16→ Para pacientes idosos com fratura de colo de fêmur submetidos a tratamento  
cirúrgico com osteossíntese, artroplastia parcial ou total, o acompanhamento com equipe multidisciplinar influência na evolução pós-operatória?  
P- Pacientes idosos com  fratura de colo de fêmur submetidos à tratamento cirúrgico com  
osteossíntese, artroplastia parcial ou total I-   acompanhamento com equipe multidisciplinar  
C-  sem acompanhamento  
O -  tempo de recuperação, menor taxa de reinternação hospitalar

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Apêndice 6 – Questões  Respondidas nas Diretrizes** -->
|**PERGUNTAS**<br>**DIAGNÓSTICO**|**DIRETRIZ   AAOS**|**DIRETRIZ NICE**|
|---|---|---|
|Pergunta 1→Para pacientes idosos com sintomatologia sugestiva de<br>fratura de colo de fêmur a radiografia é acurada para o diagnóstico de<br>fratura  de colo de fêmur?|Pacientes com fratura de quadril presumida seja<br>inicialmente avaliadas com radiografias baixa e incluir<br>anteroposterior (AP) da pelve e uma tabela de exames<br>com exibição lateral|Sensibilidade  de 90 a 98% na radiografia, enfatizando a<br>obtenção de uma terceira incidência radiográfica (10º de<br>rotação interna) aumenta a acurácia.|
|Perguntas 2→Para pacientes idosos com sintomatologia sugestiva de<br>fratura de colo de fêmur e radiografia  negativa, qual o melhor exame<br>para confirmar diagnóstico? Na impossibilidade da RM, qual o exame<br>diagnóstico com maior acurácia?|Evidência moderada - A  Ressonância Magnética como a<br>imagem de escolha avançada para o diagnóstico de<br>fratura de quadril presumida e não aparente nas<br>radiografias iniciais. Na ausência da RM é indicada a<br>cintilografia.<br>Força de recomendação: Moderada|A Ressonância Magnética com 100% de sensibilidade e 93 a<br>100% de especificidade. Na ausência da RM é indicada a TC de<br>quadril, para se evitar retardo na cirurgia, por 48h para<br>realização da Cintilografia Óssea.|
|Pergunta 3→Para pacientes idosos com (sintomatologia) sugestiva de<br>fratura de colo de fêmur a radiografia sob tração com rotação externa e<br>interna é acurada para o diagnóstico de fratura oculta de colo de fêmur?|Não responde|Não responde|
|Pergunta 4→Para pacientes idosos com (sintomatologia) sugestiva de<br>fratura de colo de fêmur oculta o bloqueio de nervo é eficaz e seguro, na<br>radiografia sob tração com rotação externa e interna?|O Bloqueio Regional melhora a dor pré-operatória<br>Evidência: Forte|<br>Recomenda para o alivio da dor para movimentos passivo para<br>investigações<br>e<br>para<br>procedimentos<br>radiológicos<br>e<br>posteriormente, para a mobilização ativa.|
|**Tratamento**|||
|Pergunta 5→Para pacientes idosos com sintomatologia sugestiva de<br>fratura oculta de colo de fêmur a analgesia com anti-inflamatório é<br>indicada?|A AAOS, não descreve o uso de drogas anti-<br>inflamatórias não esteroides para idosos, apesar de ter<br>incluído estudos que as compara com o bloqueio.|Não é recomendada devido ao risco que a população idosa corre<br>de<br>desenvolver<br>eventos<br>adversos,<br>como<br>hemorragia<br>gastrointestinal superior, nefrotoxicidade e retenção de líquidos.|
|Pergunta 6→Para pacientes idosos com fratura do colo do fêmur , o<br>tratamento cirúrgico com osteossíntese ou artroplastia é eficaz  quando<br>comparado com o tratamento não operatório para controle da dor,<br>aumentar a mobilidade, diminuir a mortalidade e melhorar a qualidade<br>de vida dopaciente?|O tratamento através de fixação cirúrgica das fraturas<br>estáveis do colo do fêmur nos pacientes idosos é mais<br>benéfico do que o tratamento não cirúrgico.<br>Força da Recomendação: Moderada|<br>O tratamento cirúrgico supera o conservador e sendo o<br>planejamento do procedimento cirúrgico proposto o fator de<br>maior relevância para obtenção dos melhores resultados no pós-<br>operatório.<br>Evidência Cientifica: Moderada|
|Pergunta 7→Para pacientes idosos com fratura de colo de fêmur a<br>profilaxia com heparina de baixo peso molecular é eficaz para prevenir a<br>trombose venosa profunda?|A profilaxia farmacológica diminui significativamente o<br>risco de tromboembolismo venoso e complicações como<br>trombose venosa profunda e tromboembolismo<br>pulmonar.<br>Evidência: Moderada|<br>Profilaxia farmacológica continua durante 28-35 dias como<br>prevenção para o tromboembolismo venoso.|
|Pergunta  8→Para pacientes idosos com fratura de colo de fêmur<br>submetidos à tratamento cirúrgico de  osteossíntese,  artroplastia parcial<br>ou total, a avaliação e tratamento da redução da densidade mineral óssea<br>influência na evolução clínica?|Os estudos avaliados demonstram a importância do<br>tratamento para a redução da densidade mineral óssea.|<br>Os estudos avaliados demonstram a importância do tratamento<br>para a redução da densidade mineral óssea.|
|Pergunta  9→Para pacientes idosos com fratura de colo de fêmur<br>submetidos à tratamento cirúrgico de osteossíntese, com artroplastia<br>parcial ou total, a reposição de cálcio e vit D, melhora a densidade<br>mineral óssea?|Os<br>estudos<br>demonstraram<br>os<br>benefícios<br>de<br>suplementação de cálcio e Vitamina D para reduzir o<br>risco de quedas e prevenir fraturas em idosos.<br>Evidência: Moderada|<br>Os estudos avaliaram que a  suplementação dietética  melhora de<br>forma<br>significativa<br>nas<br>limitações<br>funcionais.<br>Evidência: Limitada|
|Pergunta 10→Para pacientes idosos com fratura de colo de fêmur<br>submetidos à tratamento cirúrgico osteossíntese, com artroplastia parcial<br>ou total, o uso de bifosfonados  é indicado?|Recomenda que os pacientes sejam avaliados e tratados<br>para osteoporose após uma fatura de quadril.<br>Evidência: Moderada|<br>O NICE avaliou o tratamento com bifosfonados em um Guideline<br>separado para mulheres pós-menopausa. Recomenda que os<br>pacientes sejam avaliados com o FRAX  no término do<br>tratamento medicamentoso.|
|**ACOMPANHAMENTO PÓS- CIRURGICO**|||
|Pergunta 11→Para pacientes idosos com fratura de colo de fêmur<br>submetidos<br>à<br>tratamento<br>cirúrgico com<br>osteossíntese<br>,<br>o<br>acompanhamento  ( por X tempo)  é eficaz para detecção de alterações<br>pós-cirúrgicas?|72<br>A AAOS não determinou o tempo para acompanhamento,<br>avaliou vários estudos com desfechos e o uso de Score<br>diferentes.|O NICE  recomenda  um acompanhamento por um período de<br>um ano.|
|Pergunta 12→Para pacientes idosos com fratura de colo de fêmur<br>submetidos à tratamento cirúrgico com artroplastia parcial o<br>acompanhamento (por x tempo) é eficaz para detecção de alterações|não responde|não responde|  
**Apêndice 7 - Estudos Incluídos pela  AAOS  e  NICE**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 1 -  Imagem Radiológica.** -->
|Tabela - 1    ESTUDOS DE IMAGEM RADIO|LÓGICA|
|---|---|
|RESSONÂNCIA MAGNÉTICA   -   AAOS|RESSONÂNCIA MAGNÉTICA   -<br>NICE|
|1 - Chana R, Noorani A, Ashwood N, Chatterji<br>U, Healy J, Baird P. The role of MRI in the<br>diagnosis of proximal femoral fractures in  the<br>elderly.<br>Injury<br>2006;37(2):185-189.<br>PM:16249001|Não identificou estudos que atendesse os<br>critérios de inclusão.|
|2 - Haramati N, Staron RB, Barax C, Feldman<br>F. Magnetic resonance imaging of occult<br>fractures of the proximal femur. Skeletal<br>Radiol 1994;23(1):19-22. PM:8160031||
|3 - Kirby MW, Spritzer C. Radiographic<br>detection of hip and pelvic fractures in the<br>emergency department. AJR Am J Roentgenol<br>2010;194(4):1054-1060. PM:20308510||
|4 - Lim KB, Eng AK, Chng SM, Tan AG,<br>Thoo FL, Low CO. Limited magnetic<br>resonance imaging (MRI) and the occult hip<br>fracture.<br>Ann<br>Acad<br>Med<br>Singapore<br>2002;31(5):607-610. PM:12395646||
|5 - APandey R, McNally E, Ali A, Bulstrode<br>C. The role of MRI in the diagnosis of occult<br>hip<br>fractures.<br>Injury<br>1998;29(1):61-63.<br>PM:9659484||
|6 - Iwata T, Nozawa S, Dohjima T et al. The<br>value of T1-weighted coronal MRI scans in<br>diagnosing occult fracture of the hip. J Bone<br>Joint<br>Surg<br>Br<br>2012;94(7):969-973.<br>PM:22733955||
|7 - Quinn SF, McCarthy JL. Prospective<br>evaluation of patients with suspected hip<br>fracture and indeterminate radiographs: use of<br>T1-<br>weighted<br>MR<br>images.<br>Radiology<br>1993;187(2):469-471. PM:8475292||  
73  
|**TOMOGRAFIA COMPUTADORIZADA -**<br>**AAOS**|**TOMOGRAFIA**<br>**COMPUTADORIZADA -   NICE**|
|---|---|
|Não recomenda para fratura oculta de quadril<br>devido à baixa qualidade dos estudos<br>avaliados e pela exposição à radiação|Não<br>foram<br>identificados<br>estudos<br>comparando<br>diretamente<br>a<br>acurácia<br>diagnóstica da TC com a RM e que<br>atendam os critérios de inclusão|
|**CINTILOGRÁFIA ÓSSEA  -  AAOS**|**CINTILOGRÁFIA ÓSSEA  -   NICE**|
|8 - Lee KH, Kim HM, Kim YS et al. Isolated<br>fractures of the greater trochanter with occult<br>intertrochanteric extension. Arch Orthop<br>Trauma<br>Surg<br>2010;130(10):1275-1280.<br>PM:20499242|9 - Evans JG, Prudham D, Wandless I. A<br>prospective study of fractured proximal<br>femur:  factors predisposing to survival.<br>Age and Ageing 1979, 8(4):246-50.<br>(Guideline Ref ID:  EVANS1979)|
|**ULTRASONOGRAFIA  -   AAOS**|**ULTRASONOGRAFIA  -   NICE**|
|Não avaliou  a ultrassonografia.|10 - Safran O, Goldman V, Applbaum Y,<br>Milgrom C, Bloom R, Peyser A et al.<br>Posttraumatic  painful hip: sonography as a<br>screening test for occult hip fractures.<br>Journal of Ultrasound in Medicine 2009,<br>28(11):1447-52.<br>(Guideline<br>Ref<br>ID:<br>SAFRAN2009)|
|RESSONÂNCIA<br>MAGNÉTICA<br>vs<br>CINTILOGRÁFIA ÓSSEA  -   AAOS|RESSONÂNCIA MAGNÉTICA   vs<br>CINTILOGRÁFIA ÓSSEA  -   NICE|
|11 - Rizzo PF, Gould ES, Lyden JP, Asnis SE.<br>Diagnosis of occult fractures about the hip.<br>Magnetic resonance imaging compared with<br>bone-scanning. J Bone Joint Surg Am<br>1993;75(3):395-401. PM:8444918|11 - Rizzo PF, Gould ES, Lyden JP, Asnis<br>SE. Diagnosis of occult fractures about the<br>hip.<br>Magnetic<br>resonance<br>imaging<br>compared with bone-scanning. Journal of<br>Bone & Joint Surgery - American Volume<br>1993, 75(3):395-401. (Guideline Ref ID:<br>RIZZO1993)|
||12 - Evans PD, Wilson C, Lyons K.<br>Comparison of MRI with bone scanning for<br>suspected hip fracture in elderly patients.<br>Journal of Bone & Joint Surgery - British<br>Volume 1994, 76(1):158-9. (Guideline Ref<br>ID: EVANS1994) .|  
**Tabela 2-Tempo Recomendado para a Abordagem Cirúrgica**

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Tabela 2 - TEMPO  RECOMENTADO PARA  ABORDAGEM  CIRÚRGICA -->
|**AAOS**|**NICE**|
|---|---|  
74  
|13  Elliott J, Beringer T, Kee F, Marsh D, Willis<br>C, Stevenson M. Predicting survival after<br>treatment for fracture of the proximal femur and<br>the effect of delays to surgery. J Clin<br>Epidemiology<br>2003;56(8):788-795.<br>PM:12954472.|22   Al-Ani AN, Samuelsson B, Tidermark J,<br>Norling A, Ekstrom W, Cederholm T et al. Early<br>operation on patients with a hip fracture<br>improved the ability to return to independent<br>living. A prospective study of 850 patients.<br>Journal of Bone & Joint Surgery - American<br>Volume 2008, 90A(7):1436-42. (Guideline Ref.<br>ID: ALANI2008).|
|---|---|
|14  Fox HJ, Pooler J, Prothero D, Bannister GC.<br>Factors affecting the outcome after proximal<br>femoral fractures. Injury  1994;25(5):297-300.<br>PM:8034346|23   Bergeron E, Lavoie A, Moore L, Bamvita<br>JM, Ratte S, Gravel C et al. Is the delay to<br>surgery for isolated hip fracture predictive of<br>outcome in efficient systems? Journal of<br>Trauma-Injury Infection & Critical Care 2006,<br>60(4):753-7.<br>(Guideline<br>Ref<br>ID:<br>BERGERON2006)|
|15  McGuire KJ, Bernstein J, Polsky D, Silber<br>JH. The 2004 Marshall. Urist award: delays until<br>surgery after hip fracture increases  mortality.<br>Clin Orthop Relat Res 2004;(428):294-301.<br>PM:15534555|24   Bottle A, Aylin P. Mortality associated with<br>delay<br>in<br>operation<br>after<br>hip<br>fracture:<br>observational study. British Medical Journal<br>2006, 332(7547):947-51. (Guideline Ref ID:<br>BOTTLE2006)|
|16- Moran CG, Wenn RT, Sikand M, Taylor<br>AM. Early mortality after hip fracture: is delay<br>before surgery important? J Bone Joint  Surg<br>Am 2005;87(3):483-489. PM:15741611|25  Bottle A, Jarman B, Aylin P, Taylor R.<br>Some way to go for consistent implementation<br>of guidance on hip fracture. British Medical<br>Journal 2004, 328(7448):1097. (Guideline Ref.<br>ID: BOTTLE2004)|
|17 Novack V, Jotkowitz A, Etzion O, Porath A.<br>Does delay in surgery after hip fracture lead to<br>worse outcomes? A multicenter  survey. Int J<br>Qual<br>Health<br>Care<br>2007;19(3):170-176.<br>PM:17309897|26  Grimes JP, Gregory PM, Noveck H, Butler<br>MS, Carson JL. The effects of time-to-surgery<br>on mortality and morbidity in patients following<br>hip fracture. American Journal of  Medicine<br>2002, 112(9):702-9. (Guideline Ref. ID:<br>GRIMES2002A)|
|18  Orosz GM, Magaziner J, Hannan EL et al.<br>Association of timing of surgery for hip fracture<br>and<br>patient<br>outcomes.<br>JAMA<br>2004;291(14):1738-1743. PM:15082701|<br>27  Lefaivre KA, Macadam SA, Davidson DJ,<br>Gandhi R, Chan H, Broekhuyse HM. Length of<br>stay, mortality, morbidity and delay to surgery<br>in hip fractures. Journal of Bone & Joint<br>Surgery - British Volume 2009, 91(7):922-7.<br>(Guideline Ref ID: LEFAIVRE2009)|
|19 Parker MJ, Pryor GA. The timing of surgery<br>for proximal femoral fractures. JBone Joint Surg<br>Br 1992;74(2):203-205.  PM:1544952|28 Majumdar SR, Beaupre LA, Johnston DWC,<br>Dick DA, Cinats JG, Jiang HX. Lack of<br>association between mortality and timing of<br>surgical fixation in elderly patients with hip|  
75  
||fracture: results of a retrospective pop<br>based cohort study. Medical Care<br>44(6):552-9.<br>(Guideline<br>Ref<br>MAJUMDAR2006)|ulation-<br>2006,<br>ID:|
|---|---|---|
|20 Radcliff TA, Henderson WG, Stoner TJ,<br>Khuri SF, Dohm M, Hutt E. Patient risk factors,<br>operative care, and outcomes among  older<br>community-dwelling male veterans with hip<br>fracture. J Bone Joint Surg Am 2008;90(1):34-<br>42. PM:18171955|29   Moran CG, Wenn RT, Sikand M,<br>AM. Early mortality after hip fracture:<br>before surgery important? Journal of<br>Joint Surgery - American Volume<br>87A(3):483-9.<br>(Guideline<br>Ref<br>MORAN2005)|Taylor<br>is delay<br>Bone &<br>2005,<br>ID:|
|21 Siegmeth AW, Gurusamy K, Parker MJ.<br>Delay to surgery prolongs hospital stay in<br>patients with fractures of the proximal femur. J<br>Bone Joint Surg Br    2005;87(8):1123-1126.<br>PM:16049251|30  Orosz GM, Magaziner J, Hann<br>Morrison RS, Koval K, Gilbert M<br>Association of timing of surgery for hip<br>and<br>patient<br>outcomes.<br>JAMA<br>291(14):1738-43.<br>(Guideline<br>Ref<br>OROSZ2004)|an EL,<br>et al.<br>fracture<br>2004,<br> <br>ID:|
||31  Siegmeth AW, Gurusamy K, Par<br>Delay to surgery prolongs hospital<br>patients with fractures of the proximal<br>Journal of Bone & Joint Surgery -<br>Volume 2005, 87(8):1123-6. (Guideline<br>SIEGMETH2005A)|ker MJ.<br>stay in<br>femur.<br>British<br>Ref ID:|
||32   Weller I, Wai EK, Jaglal S, Kreder<br>effect of hospital type and surgical d<br>mortality after surgery for hip fracture.<br>of Bone & Joint Surgery - British Volum<br> <br> <br>|HJ. The<br>elay on<br>Journal<br>e 2005,<br>|
||87B(3):361-6.<br>(Guideline<br>Ref<br>WELLER2005)|ID:|
||33  Weller I, Wai EK, Jaglal S, Kreder<br>effect of hospital type and surgical d<br>mortality after surgery for hip fracture.<br>of Bone & Joint Surgery - British Volum<br>87B(3):361-6.<br>(Guideline<br>Ref<br>WELLER2005)|HJ. The<br>elay on<br>Journal<br>e 2005,<br>ID:|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 3 – Analgesia Pré - Operatória** -->
Tabela 3 - ANALGÉSIA PRÉ-OPERATÓRIA  
|AAOS|NICE|
|---|---|  
76  
|34 Fletcher AK, Rigby AS, Heyes FL. Three-<br>in-one femoral nerve block as analgesia for<br>fractured neck of femur in the emergency<br>department: a randomized, controlled trial.<br>Ann Emerg Med 2003;41(2):227-233.<br>PM:12548273|41 Parker MJ, Griffiths R, Appadu B. Nerve<br>blocks (subcostal, lateral cutaneous,<br>femoral, triple, psoas) for hip fractures.<br>Cochrane Database of Systematic Reviews<br>2002, Issue 1:CD001159. (Guideline Ref<br>ID: PARKER2002A)|
|---|---|
|35 Foss NB, Kristensen BB, Bundgaard M et<br>al. Fascia iliaca compartment blockade for<br>acute pain control in hip fracture patients: a<br>randomized, placebo-controlled trial.<br>Anesthesiology 2007;106(4):773-778.<br>PM:17413915||
|36 Haddad FS, Williams RL. Femoral nerve<br>block in extra capsular femoral neck fractures.<br>J Bone Joint Surg Br 1995;77(6):922-923.<br>PM:7593107||
|37  Monzon DG, Vazquez J, Jauregui JR,<br>Iserson KV. Pain treatment in post-traumatic<br>hip fracture in the elderly: regional block vs.<br>systemic non-steroidal analgesics. Int J Emerg<br>Med 2010;3(4):321-325. PM:21373300.||
|38  Mouzopoulos G, Vasiliadis G, Lasanianos<br>N, Nikolaras G, Morakis E, Kaminaris M.<br>Fascia iliaca block prophylaxis for hip<br>fracture patients at risk for delirium: a<br>randomized placebo-controlled study. J Orthop<br>Traumatol 2009;10(3):127-133. PM:19690943.||
|39  Yun MJ, Kim YH, Han MK, Kim JH,<br>Hwang JW, Do SH. Analgesia before a spinal<br>block for femoral neck fracture: fascia iliaca<br>compartment block. Acta Anaesthesiol Scand<br>2009;53(10):1282-1287. PM:19650803||
|40  Matot I, Oppenheim-Eden A, Ratrot R et<br>al. Preoperative cardiac events in elderly<br>patients with hip fracture randomized to<br>epidural or conventional analgesia.<br>Anesthesiology 2003;98(1):156-163.<br>PM:12502992||

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 4 - Anestesia** -->
77  
|Tabela   4  -   ANESTESIA||
|---|---|
|AAOS|NICE|
|42 - Casati A, Aldegheri G, Vinciguerra E,<br>Marsan A, Fraschini G, Torri G. Randomized<br>comparison between sevoflurane  anaesthesia and<br>unilateral spinal anaesthesia in elderly patients<br>undergoing orthopaedic surgery. Eur J<br>Anaesthesiol 2003;20(8):640- 646. PM:12932066|51 -  Parker MJ, Handoll HHG, Griffiths<br>R. Anaesthesia for hip fracture surgery in<br>adults.  Cochrane Database of Systematic<br>Reviews 2004, Issue 4:CD000521.<br>(Guideline Ref ID:  PARKER2004B|
|43 - Davis FM, Laurenson VG. Spinal anaesthesia<br>or general anaesthesia for emergency hip surgery<br>in elderly patients. Anaesth  Intensive Care<br>1981;9(4):352-358. PM:6797318||
|44 -  de V, V, Picart F, Le JR, Legrand A, Savry<br>C, Morin V. Combined lumbar and sacral plexus<br>block compared with plain  bupivacaine spinal<br>anesthesia for hip fractures in the elderly. Reg<br>Anesth Pain Med 2000;25(2):158-162.<br>PM:10746528||
|45 - Honkonen K, Tarkkanen L, Julkunen H.<br>Femoral neck fracture during and after surgery,<br>with special reference to the type of  anaesthesia<br>used. Acta Med Scand 1971;189(3):173-178.<br>PM:5090201||
|46 - Koval KJ, Aharonoff GB, Rosenberg AD,<br>Bernstein RL, Zuckerman JD. Functional outcome<br>after hip fracture. Effect of general  versus<br>regional anesthesia. Clin Orthop Relat Res<br>1998;(348):37-41. PM:9553531||
|47 -  Koval KJ, Aharonoff GB, Rosenberg AD,<br>Schmigelski C, Bernstein RL, Zuckerman JD. Hip<br>fracture in the elderly: the effect of  anesthetic<br>technique. Orthopedics 1999;22(1):31-34.<br>PM:9925195||
|48 -  McKenzie PJ, Wishart HY, Smith G. Long-<br>term outcome after repair of fractured neck of<br>femur. Comparison of subarachnoid  and general<br>anaesthesia. Br J Anaesth 1984;56(6):581-585.<br>PM:6721969||  
78  
<!-- Start of picture text -->
49 -  Sutcliffe AJ, Parker M. Mortality after spinal<br>and general anaesthesia for surgical fixation of hip<br>fractures. Anaesthesia  1994;49(3):237-240.<br>PM:8147519<br>50 -  Valentin N, Lomholt B, Jensen JS, Hejgaard<br>N, Kreiner S. Spinal or general anaesthesia for<br>surgery of the fractured hip? A  prospective study<br>of mortality in 578 patients. Br J Anaesth<br>1986;58(3):284-291. PM:3947489<br>Tabela 4.1 -  Clopidogrel e Aspirina<br>AAOS  NICE<br>52 Chechik O, Amar E, Khashan M, Kadar A,  Não avaliou<br>Rosenblatt Y, Maman E. In support of early surgery<br>for hip fractures sustained by elderly patients<br>taking clopidogrel: a retrospective study. Drugs<br>Aging 2012;29(1):63-68. PM:22191724<br>53   Maheshwari R, Acharya M, Monda M,<br>Pandey R. Factors influencing mortality in<br>patients on antiplatelet agents presenting with<br>proximal femoral fractures. J Orthop Surg (Hong<br>Kong) 2011;19(3):314-316. PM:22184161<br>54   Manning BJ, O'Brien N, Aravindan S, Cahill<br>RA, McGreal G, Redmond HP. The effect of<br>aspirin on blood loss and transfusion requirements<br>in patients with femoral neck fractures. Injury<br>2004;35(2):121-124. PM:14736467<br>55  Thaler HW, Frisee F, Korninger C. Platelet<br>aggregation inhibitors, platelet function testing,<br>and blood loss in hip fracture surgery. J Trauma<br>2010;69(5):1217-1220. PM:21068622<br>56  Hossain FS, Rambani R, Ribee H, Koch L. Is<br>discontinuation of clopidogrel necessary for<br>intracapsular hip fracture surgery? Analysis of 102<br>hemiarthroplasties. J Orthop Traumatol 2013.<br>PM:23563577<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 5 -  Fraturas** -->
Tabela 5 -  FRATURAS  
79

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: FRATURAS DE COLO DE FÊMUR NÃO DESVIADAS -->
|AAOS|NICE|
|---|---|
|52 - Cserhati P, Kazar G, Manninger J, Fekete K,<br>Frenyo S. Non-operative or operative treatment for<br>undisplaced femoral neck  fractures: a comparative<br>study of 122 non-operative and 125 operatively<br>treated<br>cases.<br>Injury<br>1996;27(8):583-588.<br>PM:8994566||
|FRATURAS DE COLO DE FÊMUR DESVIADAS<br>|<br>|
|AAOS|NICE|
|ALTA      EVIDÊNCIA||
|56-  Davison JN, Calder SJ, Anderson GH et al.<br>Treatment for displaced intracapsular fracture of<br>the proximal femur. A prospective,  randomized<br>trial in patients aged 65 to 79 years. The Journal<br>of bone and joint surgery British volume<br>2001;83):206-212.|81 - Frihagen F, Nordsletten L, Madsen JE.<br>Hemiarthroplasty or internal fixation for<br>intracapsular displaced femoral neck fractures:<br>randomised controlled trial. British  Medical<br>Journal 2007, 335(7632):1251-4. (Guideline<br>Ref ID: FRIHAGEN2007)|
|57 -  Keating JF, Grant A, Masson M, Scott NW,<br>Forbes JF. Displaced intracapsular hip fractures in<br>fit, older people: a randomized  comparison of<br>reduction and fixation, bipolar hemiarthroplasty<br>and total hip arthroplasty. Health Technol Assess<br>2005;9(41):iii-x, 1.  PM:16202351|82 -    Macaulay W, Nellans KW, Garvin KL,<br>Iorio R, Healy WL, Rosenwasser MP et al.<br>Prospective randomized clínical trial<br>comparing hemiarthroplasty to total hip<br>arthroplasty in the treatment of displaced<br>femoral neck fractures: winner of the Dorr<br>Award. Journal of Arthroplasty 2008, 23(6<br>Suppl 1):2-8. (Guideline Ref ID:<br>MACAULAY2008)|
|58 -  Johansson T, Jacobsson SA, Ivarsson I,<br>Knutsson A, Wahlstrom O. Internal fixation<br>versus total hip arthroplasty in the treatment  of<br>displaced femoral neck fractures: a prospective<br>randomized study of 100 hips. Acta Orthop Scand<br>2000;71(6):597-602.  PM:11145387|83 -  Mouzopoulos G, Stamatakos M, Arabatzi<br>H, Vasiliadis G, Batanis G, Tsembeli A et al.<br>The  four-year functional result after a<br>displaced subcapital hip fracture treated with<br>three  different surgical options. International<br>Orthopaedics 2008, 32(3):367-73. (Guideline<br>Ref  ID: MOUZOPOULOS2008)|
|59 -  Bray TJ, Smith-Hoefer E, Hooper A,<br>Timmerman L. The displaced femoral neck<br>fracture. Internal fixation versus bipolar<br>endoprosthesis. Results of a prospective,<br>randomized comparison. Clin Orthop Relat Res<br>1988;(230):127-140. PM:3365885||  
80  
60 -  Frihagen F, Nordsletten L, Madsen JE. Hemiarthroplasty or internal fixation for intracapsular displaced femoral neck fractures: randomized controlled trial. BMJ 2007;335(7632):1251-1254. PM:18056740 61 -  Sikorski JM, Barrington R. Internal fixation versus hemiarthroplasty for the displaced subcapital fracture of the femur. A prospective randomised study. J Bone Joint Surg Br 1981;63B(3):357-361. PM:7263746 MODERADA EVIDÊNCIA <mark>62 - Ravikumar KJ, Marsh G. Internal fixation</mark> versus hemiarthroplasty versus total hip arthroplasty for displaced subcapital fractures  of femur--13 year results of a prospective randomised study. Injury 2000;31(10):793-797. PM:11154750 63 -  Rogmark C, Carlsson A, Johnell O, Sernbo I. A prospective randomized trial of internal fixation versus arthroplasty for displaced  fractures of the neck of the femur. Functional outcome for 450 patients at two years. J Bone Joint Surg Br 2002;84(2):183-188.  PM:11922358 64 -  Tidermark J, Ponzer S, Svensson O, Soderqvist A, Tornkvist H. Internal fixation compared with total hip replacement for  displaced femoral neck fractures in the elderly. A randomized, controlled trial. J Bone Joint Surg Br 2003;85(3):380-388.  PM:12729114 65 -  Chammout GK, Mukka SS, Carlsson T, Neander GF, Helge Stark AW, Skoldenberg OG. Total Hip Replacement Versus Open  Reduction and Internal Fixation of Displaced Femoral Neck Fractures: A Randomized Long-Term Follow-up Study. J Bone Joint Surg  Am 2012. PM:23014835  
66 -  Bachrach-Lindstrom M, Johansson T, Unosson M, Ek AC, Wahlstrom O. Nutritional status and functional capacity after femoral  neck fractures: a prospective randomized one-year follow-up study. Aging (Milano ) 2000;12(5):366374. PM:11126523  
67   Calder SJ, Anderson GH, Harper WM, Jagger C, Gregg PJ. A subjective health indicator for follow-up. A randomised trial after  treatment of displaced intracapsular hip fractures. J Bone Joint Surg Br 1995;77(3):494-496. PM:7744944  
81  
68 - El-Abed K, McGuinness A, Brunner J, Dallovedova P, O'Connor P, Kennedy JG. Comparison of outcomes following  uncemented hemiarthroplasty and dynamic hip screw in the treatment of displaced subcapital hip fractures in patients aged greater  than 70 years. Acta Orthop Belg 2005;71(1):48-54. PM:15792207  
<mark>69 -  Johansson T, Risto O, Knutsson A,</mark> Wahlstrom O. Heterotopic ossification following internal fixation or arthroplasty for  displaced femoral neck fractures: a prospective randomized study. Int Orthop 2001;25(4):223-225. PM:11561495  
70 -  Johansson T, Bachrach-Lindstrom M, Aspenberg P, Jonsson D, Wahlstrom O. The total costs of a displaced femoral neck fracture: comparison of internal fixation and total hip replacement. A randomised study of 146 hips. Int Orthop 2006;30(1):1-6 . PM:16374651  
71 -  Jonsson B, Sernbo I, Carlsson A, Fredin H, Johnell O. Social function after cervical hip fracture. A comparison of hook-pins and total hip replacement in 47 patients. Acta Orthop Scand 1996;67(5):431-434.  
72- Mouzopoulos G, Stamatakos M, Arabatzi H et al. The four-year functional result after a displaced subcapital hip fracture treated  with three different surgical options. Int Orthop 2008;32(3):367-373. PM:17431621  
<mark>73 -  Neander G, Adolphson P, von SK, Dahlborn</mark> M, Dalen N. Bone and muscle mass after femoral neck fracture. A controlled quantitative computed tomography study of osteosynthesis versus primary total hip arthroplasty. Arch Orthop Trauma Surg 1997;116(8):470-474. PM:9352040  
<mark>74 -  Parker MJ. Internal fixation or arthroplasty for</mark> displaced subcapital fractures in the elderly? Injury 1992;23(8):521-524.  PM:1286902  
75 -  Parker MJ, Khan RJ, Crawford J, Pryor GA. Hemiarthroplasty versus internal fixation for displaced intracapsular hip fractures in the elderly. A randomised trial of 455 patients. J Bone Joint Surg Br 2002;84(8):1150-1155. PM:12463661  
82  
76 -  Parker MJ, Pryor G, Gurusamy K. Hemiarthroplasty versus internal fixation for displaced intracapsular hip fractures: a long-term follow-up of a randomised trial. Injury 2010;41(4):370-373. PM:19879576 77 -  Roden M, Schon M, Fredin H. Treatment of displaced femoral neck fractures: a randomized minimum 5-year follow-up study of screws and bipolar hemiprostheses in 100 patients. Acta Orthop Scand 2003;74(1):42-44. PM:12635791 <mark>78 -  Skinner P, Riley D, Ellery J, Beaumont A,</mark> Coumine R, Shafighian B. Displaced subcapital fractures of the femur: a prospective randomized comparison of internal fixation, hemiarthroplasty and total hip replacement. Injury 1989;20(5):291293. PM:2693355 79 -  van Dortmont LM, Douw CM, van Breukelen AM et al. Cannulated screws versus hemiarthroplasty for displaced intracapsular femoral neck fractures in demented patients. Ann Chir Gynaecol 2000;89(2):132-137. PM:10905680 80 - Waaler Bjornelv GM, Frihagen F, Madsen JE, Nordsletten L, Aas E. Hemiarthroplasty compared to internal fixation with percutaneous cannulated screws as treatment of displaced femoral neck fractures in the elderly: cost-utility analysis performed alongside a randomized, controlled trial. Osteoporos Int 2012;23(6):1711-1719. PM:21997224  
**Tabela 6 – Tração  Pré- Operatória**  
|Tabela 6  -  TRAÇÃO PRÉ- OPERATÓRIA||
|---|---|
|AAOS|NICE|
|Moderada Evidência||
|84 -  Anderson GH, Harper WM, Connolly CD,<br>Badham J, Goodrich N, Gregg PJ. Preoperative skin<br>traction for fractures of the  proximal femur. A<br>randomised prospective trial. J Bone Joint Surg Br<br>1993;75(5):794-796. PM:8376442|Não avaliou a Tração Pré-<br>Operatória|
|85 -  Finsen V, Borset M, Buvik GE, Hauke I.<br>Preoperative traction in patients with hip fractures.<br>Injury 1992;23(4):242-244.  PM:1618564||  
83  
|86 -  Needoff M, Radford P, Langstaff R.<br>Preoperative traction for hip fractures in the elderly: a<br>clínical trial. Injury 1993;24(5):317- 318.<br>PM:8349341|
|---|
|87 -  Resch S, Bjãrnetoft. Preoperative skin traction or<br>pillow nursing in hip fractures: a prospective,<br>randomized study in 123  patients. 2005<br>http://www.nzgg.org.nz/search?search=acute+manage<br>ment;http://dx.doi.org/10.1080/096382805 00055800;<br>http://www.ncbi.nlm.nih.gov/pubmed/16278188;<br>http://www.ingentaconnect.com/content/apl/tids|
|88 -  Rosen JE, Chen FS, Hiebert. Efficacy of<br>preoperative skin traction in hip fracture patients: a<br>prospective,<br>randomized<br>study.2001.http://www.nzgg.org.nz/search?search=acu<br>te+management;http://dx.doi.org/10.1080/1103812031<br>0004475;<br>http://informahealthcare.com/loi/occ|
|89 -  Saygi B, Ozkan K, Eceviz E, Tetik C, Sen C.<br>Skin traction and placebo effect in the preoperative<br>pain control of patients with<br>collum and intertrochanteric femur fractures. Bull<br>NYU Hosp Jt Dis 2010;68(1):15-17. PM:20345356|
|90 -  Yip DK, Chan CF, Chiu PK, Wong JW, Kong<br>JK. Why are we still using preoperative skin traction<br>for hip fractures? Int Orthop 2002;26(6):361-364.<br>PM:12466869|
|Alta Evidência|
|91 -  Resch S, Thorngren KG. Preoperative traction<br>for hip fracture: a randomized comparison between<br>skin and skeletal traction in 78  patients. Acta Orthop<br>Scand 1998;69(3):277-279. PM:9703402|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 7 - Prótese Bipolar versus Unipolar** -->
|Tabela 7 -  PRÓTESE  BIPOLAR  versus UNIPOLAR||
|---|---|
|AAOS|NICE|
|ALTA EVIDÊNCIA||  
84  
|56-  Davison JN, Calder SJ, Anderson GH et al.|Não comparou a Prótese Bipolar versus a|
|---|---|
|Treatment for displaced intracapsular fracture of the<br>proximal femur. A prospective,  randomised trial in<br>patients aged 65 to 79 years. The Journal of bone<br>and joint surgery British volume 2001;83):206-212.|<br>Unipolar. Fez um comparativo entre o<br>tratamento com artroplastia total do<br>quadril versus a artroplastia parcial<br>unipolar.|
|MODERADA EVIDÊNCIA||
|67   Calder SJ, Anderson GH, Harper WM, Jagger<br>C, Gregg PJ. A subjective health indicator for<br>follow-up. A randomised trial after  treatment of<br>displaced intracapsular hip fractures. J Bone Joint<br>Surg Br 1995;77(3):494-496. PM:7744944||
|92 - Raia FJ, Chapman CB, Herrera MF, Schweppe<br>MW, Michelsen CB, Rosenwasser MP. Unipolar or<br>bipolar hemiarthroplasty for  femoral neck fractures<br>in the elderly? Clin Orthop Relat Res<br>2003;(414):259-265. PM:12966301||
|93 -  Cornell CN, Levine D, O'Doherty J, Lyden J.<br>Unipolar versus bipolar hemiarthroplasty for the<br>treatment of femoral neck  fractures in the elderly.<br>Clin Orthop Relat Res 1998;(348):67-71.<br>PM:9553535||
|95-  Calder SJ, Anderson GH, Jagger C, Harper<br>WM, Gregg PJ. Unipolar or bipolar prosthesis for<br>displaced intracapsular hip fracture<br>in octogenarians: a randomised prospective study. J<br>Bone Joint Surg Br 1996;78(3):391-394.<br>PM:8636172||
|96 -  Hedbeck CJ, Blomfeldt R, Lapidus G,<br>Tornkvist H, Ponzer S, Tidermark J. Unipolar<br>hemiarthroplasty versus bipolar  hemiarthroplasty in<br>the most elderly patients with displaced femoral<br>neck fractures: a randomised, controlled trial. Int<br>Orthop 2011.  PM:21301830||
|97 -  Kenzora JE, Magaziner J, Hudson J et al.<br>Outcome after hemiarthroplasty for femoral neck<br>fractures in the elderly. Clin Orthop<br>Relat Res 1998;(348):51-58. PM:9553533||  
**Tabela 8 – Hemiartroplastia versus Artroplastia Total**  
85

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Tabela 8-  HEMIARTROPLASTIA vs ARTROPLASTIA TOTAL -->
AAOS NICE ALTA  EVIDÊNCIA <mark>57 -  Keating JF, Grant A, Masson M, Scott NW, 102 -Parker MJ, Gurusamy KS,</mark> Forbes JF. Displaced intracapsular hip fractures Azegami S. Arthroplasties (with and in fit, older people: a randomised  comparison of without bone cement) for  proximal reduction and fixation, bipolar hemiarthroplasty femoral fractures in adults. Cochrane and total hip arthroplasty. Health Technol Assess Database of Systematic Reviews 2005;9(41):iii-x, 1.  PM:16202351 2010,  6:CD001706. (Guideline Ref ID: PARKER2010A) MODERADA EVIDÊNCIA 98 - Blomfeldt R, Tornkvist H, Ponzer S, Soderqvist A, Tidermark J. Internal fixation versus hemiarthroplasty for displaced fractures of the femoral neck in elderly patients with severe cognitive impairment. J Bone Joint Surg Br 2005;87(4):523-529. PM:15795204 99 -  Hedbeck CJ, Enocson A, Lapidus G et al. Comparison of bipolar hemiarthroplasty with total hip arthroplasty for displaced  femoral neck fractures: a concise four-year follow-up of a randomized trial. J Bone Joint Surg Am 2011;93(5):445-450. PM:21368076 100 -  Macaulay W, Nellans KW, Iorio R, Garvin KL, Healy WL, Rosenwasser MP. Total hip arthroplasty is less painful at 12 months compared with hemiarthroplasty in treatment of displaced femoral neck fracture. HSS J 2008;4(1):48-54. PM:18751862 <mark>101 -  van den Bekerom MP, Hilverdink EF,</mark> Sierevelt IN et al. A comparison of hemiarthroplasty with total hip replacement for displaced intracapsular fracture of the femoral neck: a randomised controlled multicentre trial in patients aged 70 years and over. J  Bone Joint Surg Br 2010;92(10):1422-1428. PM:20884982

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 9 - Haste Cimentada** -->
86  
Tabela 9 -  HASTE CIMENTADA AAOS NICE <mark>103 - van den Bekerom MP, Hilverdink EF, 102 -Parker MJ, Gurusamy KS, Azegami S.</mark> Sierevelt IN et al. A comparison of Arthroplasties (with and without bone cement) for hemiarthroplasty with total hip replacement proximal femoral fractures in adults. Cochrane for displaced intracapsular fracture of the Database of Systematic Reviews 2010, femoral neck: a randomised controlled 6:CD001706. (Guideline Ref ID: multicentre trial in patients aged 70 years and PARKER2010A) over. J Bone Joint Surg Br 2010;92(10):14221428. PM:20884982 <mark>104 - Deangelis JP, Ademi A, Staff I, Lewis</mark> CG. Cemented versus uncemented hemiarthroplasty for displaced femoral neck fractures: a prospective randomized trial with early follow-up. J Orthop Trauma 2012;26(3):135-140. PM:22198652 105 - Figved W, Opland V, Frihagen F, Jervidalo T, Madsen JE, Nordsletten L. Cemented versus uncemented hemiarthroplasty for displaced femoral neck fractures. Clin Orthop Relat Res 2009;467(9):2426-2435. PM:19130162 106 - Taylor F, Wright M, Zhu M. Hemiarthroplasty of the Hip with and without Cement: A Randomized Clínical Trial. J Bone Joint Surg Am 2012;999(2):577-583. PM:23064652 <mark>107 - Santini S, Rebeccato A, Bolgan I, Turi</mark> G. Hip fractures in elderly patients treated with bipolar hemiarthroplasty: Comparison between cemented and cementless implants. Journal of Orthopaedics and Traumatology 2005;6(2):80-87. 108 - Lennox IA, McLauchlan J. Comparing the mortality and morbidity of cemented and uncemented hemiarthroplasties. Injury 1993;24(3):185-186. PM:8509191 109 - Parker MI, Pryor G, Gurusamy K. Cemented versus uncemented hemiarthroplasty for intracapsular hip  
87  
fractures: A randomised controlled trial in 400 patients. J Bone Joint Surg Br 2010;92(1):116-122. PM:20044689 <mark>110 -Sonne HS, Walter S, Jensen JS. Moore</mark> hemi-arthroplasty with an without bone cement in femoral neck fractures. A clínical controlled trial. Acta Orthop Scand 1982;53(6):953-956. <mark>111 - Singh GK, Deshmukh RG. Uncemented</mark> Austin-Moore and cemented Thompson unipolar hemiarthroplasty for displaced fracture neck of femur--comparison of complications and patient satisfaction. Injury 2006;37(2):169-174. PM:16413024  
**Tabela 10 - Abordagem Cirúrgica**  
|Tabela 10 - ABORDAGEM CIRÚRGICA||
|---|---|
|AAOS|NICE|
|112 - Bieber R, Brem M, Singler K, Moellers M,<br>Sieber C, Bail HJ. Dorsal versus transgluteal<br>approach for hip hemiarthroplasty: an analysis of<br>early complications in seven hundred and four<br>consecutive cases. Int Orthop 2012;36(11):2219-<br>2223. PM:22872411|114 - Parker MJ, Pervez H. Surgical<br>approaches for inserting hemiarthroplasty of<br>the hip. Cochrane Database of Systematic<br>Reviews 2002, Issue 3:CD001707. (Guideline<br>Ref ID: PARKER2002B)|
|113 -  Skoldenberg O, Ekman A, Salemyr M,<br>Boden H. Reduced dislocation rate after hip<br>arthroplasty for femoral neck fractures when<br>changing from posterolateral to anterolateral<br>approach. Acta Orthop 2010;81(5):583-587.<br>PM:20860452||

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 11 – Infecção Cirúrgica** -->
|Tabela 11 -     INFECÇÃO CIRÚRGICA|
|---|
|AAOS<br>NICE|  
88  
|A  AAOS não avaliou a infecção<br>cirúrgica.|115 - Chlebicki, M.P., Safdar, N., O'Horo, J.C., & Maki,<br>D.G. 2013. Preoperative chlorhexidine shower or bath<br>for prevention of surgical site infection: a meta-analysis.<br>American Journal of Infection Control, 41, (2) 167-173|
|---|---|
||116- Dayton, P., Feilmeier, M., & Sedberry, S. 2013.<br>IDoes postoperative showering or bathing of a surgical<br>site increase the incidence of infection?  A systematic<br>review of the literature. Journal of Foot & Ankle Surgery,<br>52, (5) 612-614|
||117- Gillespie, W.J. & Walenkamp, G.H. 2010.<br>Antibiotic prophylaxis for surgery for proximal femoral<br>and other closed long bone fractures.  Cochrane database<br>of systematic reviews (Online), 3|
||118-   Nthumba, P.M., Stepita-Poenaru, E., Poenaru, D.,<br>Bird, P., Allegranzi, B., Pittet, D., & Harbarth, S. 2010.<br>Cluster-randomized, crossover trial of the efficacy of<br>plain soap and water versus alcohol-based rub for<br>surgical hand preparation in a rural hospital in Kenya.<br>British<br>Journal<br>of<br>Surgery, 97, (11) 1621-1628|
||119 -  Tanner, J., Swarbrook, S., & Stuart, J. 2008,<br>"Surgical hand antisepsis to reduce surgical site<br>infection. Cochrane Database of Systematic Reviews:<br>Reviews," In Cochrane Database of Systematic Reviews<br>2008 Issue1|
||120 -    Toon, C.D., Sinha, S., Davidson, B.R., &<br>Gurusamy, K.S. 2013. Early versus delayed post-<br>operative bathing or showering to prevent wound<br>complications. Cochrane Database of Systematic<br>Reviews, 10, CD010075|
||121 - Toon, C.D., Ramamoorthy, R., Davidson, B.R., &<br>Gurusamy, K.S. 2013. Early versus delayed dressing<br>removal after primary closure of clean  and clean-<br>contaminated surgical wounds. Cochrane Database of<br>Systematic Reviews, 9, CD010259|
||122 - Wang, J.Z. 2013. A systematic review and meta-<br>analysis of antibiotic-impregnated bone cement use in<br>primary total hip or knee arthroplasty. PLoS ONE<br>[Electronic Resource], 8, (12)|  
89

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 12 - Indicação de Transfusão** -->
Tabela 12  -   INDICAÇÃO DA TRANSFUSÃO SANGUINEA  
|AAOS|NICE|
|---|---|
|123 -   Carson JL, Terrin ML, Noveck H et<br>al. Liberal or restrictive transfusion in high-<br>risk patients after hip surgery. N Engl J Med<br>2011;365(26):2453-2462. PM:22168590|<br>125-  Bisbe E,    Molto L, Arroyo R, Muniesa JM,<br>Tejero M. Randomized trial comparing ferric<br>carboxymaltose vs oral ferrous glycine sulphate for<br>postoperative anaemia after total knee arthroplasty.<br>British Journal of Anaesthesia. 2014; 113(3):402-<br>409|
|124-    Carson JL, Terrin ML, Barton FB et<br>al. A pilot randomized trial comparing<br>symptomatic vs. hemoglobin-level-driven<br>red blood cell transfusions following hip<br>fracture.Transfusion(Paris)1998;38(6):522-<br>529. PM:9661685|126<br>-<br>Canadian<br>Orthopedic<br>Perioperative<br>Erythropoietin Study Group. Effectiveness of<br>perioperative recombinant human erythropoietin in<br>elective<br>hip<br>replacement.<br>Lancet.<br>1993;<br>341(8855):1227-1232|
||127 - Faris PM, Ritter MA, Abels RI. The effects of<br>recombinant human erythropoietin on perioperative<br>transfusion requirements in patients having a major<br>orthopaedic<br>operation.<br>The<br>American<br>Erythropoietin Study Group. Journal of Bone and<br>Joint Surgery American Volume. 1996; 78(1):62-72|
||128-  Karkouti K, McCluskey SA, Ghannam M,<br>Salpeter MJ, Quirt I, Yau TM. Intravenous iron and<br>recombinant erythropoietin for the treatment of<br>postoperative<br>anemia.<br>Canadian<br>Journal<br>of<br>Anaesthesia. 2006; 53(1):11-19|
||129- Luporsi E, Mahi L, Morre C, Wernli J, de<br>Pouvourville G, Bugat R. Evaluation of cost savings<br>with ferric carboxymaltose in anemia treatment<br>through its impact on erythropoiesis-stimulating<br>agents and blood transfusion: French healthcare<br>payer perspective. Journal of Medical Economics.<br>2012; 15(2):225-232|
||130- Olijhoek G, Megens JG, Musto P, Nogarin L,<br>Gassmann-Mayer C, Vercammen E et al. Role of<br>oral versus IV iron supplementation in the<br>erythropoietic response to rHuEPO: a randomized,<br>placebo-controlled<br>trial.<br>Transfusion.<br>2001;<br>41(7):957-963|
||131-  Parker MJ. Iron supplementation for anemia<br>after hip fracture surgery: a randomized trial of 300<br>patients. Journal of Bone and Joint Surgery<br>American Volume. 2010; 92(2):265-269|  
90  
|132-  Parker MJ. Iron supplementation for anemia<br>after hip fracture surgery: a randomized trial of 300<br>patients. Journal of Bone and Joint Surgery<br>American Volume. 2010; 92(2):265-269|
|---|
|133- Parris E, Grant-Casey J. Promoting safer blood<br>transfusion practice in hospital. Nursing Standard.<br>2007; 21(41):35-38|
|134-  Pentti J, Syrjala M, Pettila V. Computerized<br>quality assurance of decisions to transfuse blood<br>components<br>to<br>critically<br>ill<br>patients.<br>Acta<br>Anaesthesiologica Scandinavica. 2003; 47(8):973-<br>978|
|135- Serrano-Trenas JA, Ugalde PF, Cabello LM,<br>Chofles LC, Lazaro PS, Benitez PC. Role of<br>perioperative intravenous iron therapy in elderly hip<br>fracture patients: a single-center randomized<br>controlled trial. Transfusion. 2011; 51(1):97-104|
|136-   Sutton PM, Cresswell T, Livesey JP, Speed K,<br>Bagga T. Treatment of anaemia after joint<br>replacement.<br>A<br>double-blind,<br>randomised,<br>controlled trial of ferrous sulphate versus placebo.<br>Journal of Bone and Joint Surgery British Volume.<br>2004; 86(1):31-33|
|137- BJW, den Hollander PHC, Kaptijn HH,<br>Nelissen RGHH, Pilot P. Autologous wound drains<br>have no effect on allogeneic blood transfusions in<br>primary total hip and knee replacement: a three-arm<br>randomised trial. Bone and Joint Journal. 2014; 96-<br>B(6):765-771|
|138-  Thomassen BJW, Pilot P, Scholtes VAB,<br>Grohs JG, Holen K, Bisbe E et al. Limit allogeneic<br>blood use with routine reuse of patient's own blood:<br>a prospective, randomized, controlled trial in total<br>hip surgery. PloS One. 2012; 7(9):e44503|
|138-      Weatherall  M, Maling TJ. Oral iron therapy<br>for anaemia after orthopaedic surgery: randomized<br>clínical trial. ANZ Journal of Surgery. 2004;<br>74(12):1049-1051|
|138- Wurnig C, Schatz K, Noske H, Hemon Y,<br>Dahlberg G, Josefsson G et al. Subcutaneous low-<br>dose epoetin beta for the avoidance of transfusion in<br>patients scheduled for elective surgerynot eligible|  
91  
|for autologous blood donation. European Surgical<br>Research. 2001; 33(5-6):303-310|
|---|
|139-   Ácido Tranexâmico vs Cell Save Carless PA,<br>Henry DA, Moxey AJ, O'Connell D, Brown T,<br>Fergusson DA. Cell salvage for minimising<br>perioperative<br>allogeneic<br>blood<br>transfusion.<br>Cochrane Database of Systematic Reviews. 2010;<br>Issue 4:CD001888|
|140 -  Henry DA, Carless PA, Moxey AJ, O'Connell<br>D, Stokes BJ, Fergusson DA et al. Antifibrinolytic<br>use for minimising perioperative allogeneic blood<br>transfusion. Cochrane Database of Systematic<br>Reviews. 2011; Issue 3:CD001886|
|141-  Ker K, Prieto-Merino D, Roberts I. Systematic<br>review, meta-analysis and meta-regression of the<br>effect of tranexamic acid on surgical blood loss.<br>British Journal of Surgery. 2013; 100(10):1271-<br>1279|
|142 -  Ker K, Beecher D, Roberts I. Topical<br>application of tranexamic acid for the reduction of<br>bleeding.<br>Cochrane<br>Database<br>of<br>Systematic<br>Reviews.<br>2013;<br>Issue<br>7:CD010562.<br>DOI:10.1002/14651858.CD010562.pub2|
|143-   Lemay E, Guay J, Cote C, Roy A. Tranexamic<br>acid reduces the need for allogenic red blood cell<br>transfusions in patients undergoing total hip<br>replacement. Canadian Journal of Anaesthesia.<br>2004; 51(1):31-37|
|144-   Perel P, Ker K, Morales Uribe CH, Roberts I.<br>Tranexamic acid<br>for reducing mortality in<br>emergency and urgent surgery. Cochrane Database<br>of Systematic Reviews. 2013; Issue 1:CD010245|
|145- Smith LK, Williams DH, Langkamer VG. Post-<br>operative<br>blood<br>salvage<br>with<br>autologous<br>retransfusion in primary total hip replacement.<br>Journal of Bone and Joint Surgery British Volume.<br>2007; 89(8):1092-1097|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 13 – Profilaxia de TEV** -->
92

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Tabela 13 -  PROFILAXIA PARA TROMBOEMBOLISMO VENOSO -->
|AAOS|NICE|
|---|---|
|ALTA QUALIDADE||
|146- Prevention of pulmonary embolism<br>and deep vein thrombosis with low dose<br>aspirin: Pulmonary Embolism Prevention<br>(PEP) trial. Lancet 2000;355(9212):1295-<br>1302. PM:10776741<br>QUALIDADE MODERADA|158- Antiplatelet Trialists' Collaboration.<br>Collaborative overview of randomised trials of<br>antiplatelet therapy--III: Reduction in venous<br>thrombosis and pulmonary embolism by<br>antiplatelet prophylaxis among surgical and<br>medical<br>patients.<br>Antiplatelet<br>Trialists'<br>Collaboration. British Medical Journal 1994,<br>308(6923):235-46.<br>(Guideline<br>Ref<br>ID:<br>ANTIPLATELET1994)|
|147-<br>Moskovitz,P.A.,<br>Ellenberg,S.S.,<br>Feffer,H.L., Kenmore,P.I., Neviaser,R.J.,<br>Rubin,B.E.,<br>Varma,V.M.<br>Low-dose<br>heparin<br>for<br>prevention<br>of<br>venous<br>thromboembolism in total hip arthroplasty<br>and surgical repair of hip fractures. J Bone<br>Joint Surg Am 1978/12; 8: 1065-1070|159-    Collins R, Scrimgeour A, Yusuf S, Peto<br>R. Reduction in fatal pulmonary embolism and<br>venous<br>thrombosis<br>by<br>perioperative<br>administration<br>of<br>subcutaneous<br>heparin.<br>Overview of results of randomized trials in<br>general, orthopedic, and urologic surgery.<br>New England Journal of Medicine 1988,<br>318(18):1162-73.<br>(Guideline<br>Ref<br>ID:<br>COLLINS1988)|
|148-  Xabregas,A., Gray,L., Ham,J.M.<br>Heparin<br>prophylaxis<br>of<br>deep<br>vein<br>thrombosis in patients with a fractured neck<br>of the femur. Med J Aust. 1978/6/3; 11:<br>620-622<br>148 Morris,G.K., Mitchell,J.R. Warfarin<br>sodium in prevention of deep venous<br>thrombosis and pulmonary embolism in<br>patients with fractured neck of femur.<br>1976/10/23; 7991: 869-872|160- Koch A, Bouges S, Ziegler S, Dinkel H,<br>Daures JP, Victor N. Low molecular weight<br>heparin<br>and<br>unfractionated<br>heparin<br>in<br>thrombosis prophylaxis after major surgical<br>intervention: update of previous meta-<br>analyses. British Journal of Surgery 1997,<br>84(6):750-9. (Guideline Ref ID: KOCH1997)|
|BAIXA QUALIDADE||
|149- Prevention of pulmonary embolism<br>and deep vein thrombosis with low dose<br>aspirin: Pulmonary Embolism Prevention<br>(PEP) trial. Lancet 2000;355(9212):1295-<br>1302. PM:10776741|161- Mismetti P, Laporte S, Zufferey P, Epinat<br>M, Decousus H, Cucherat M. Prevention of<br>venous<br>thromboembolism<br>in<br>orthopedic<br>surgery with vitamin K antagonists: a<br>metaanalysis. Journal of Thrombosis and|  
93  
Haemostasis : JTH 2004, 2(7):1058-70. (Guideline Ref ID: MISMETTI2004) <mark>150- Chotanaphuti T, Jareonarpornwatana 162- Roderick P, Ferris G, Wilson K, Halls H,</mark> A, Laoruengthana A. The mortality rate Jackson D, Collins R et al. Towards after thromboembolism prophylaxis in the evidencebased guidelines for the prevention of hip fracture surgery. J Med Assoc Thai venous thromboembolism: systematic reviews 2009;92 Suppl6):S115-S119. of mechanical methods, oral anticoagulation, PM:20120672 dextran and regional anaesthesia as thromboprophylaxis. Health Technology Assessment 2005, 9(49). (Guideline Ref ID: RODERICK2005) 151- Sasaki S, Miyakoshi N, Matsuura H, 163- Zufferey P, Laporte S, Quenet S, Molliex Saitoh H, Kudoh D, Shimada Y. S, Auboyer C, Decousus H et al. Optimal Prospective randomized controlled trial on lowmolecular-weight  heparin regimen in the effect of fondaparinux sodium for major orthopaedic surgery. A meta-analysis of prevention of venous thromboembolism randomised trials. Thrombosis and after hip fracture surgery. J Orthop Sci Haemostasis 2003, 90(4):654-61. (Guideline 2009;14(5):491-496. PM:19802659 Ref ID: ZUFFEREY2003) 152- Sasaki S, Miyakoshi N, Matsuura H et al. Prospective study on the efficacies of fondaparinux and enoxaparin in preventing venous thromboembolism after hip fracture surgery. J Orthop Sci 2011;16(1):64-70. 153-  Checketts RG, Bradley JG. Low-dose heparin in femoral neck fractures. Injury 1974;6(1):42-44. PM:4418947 <mark>154-  Jorgensen PS, Knudsen JB, Broeng L</mark> et al. The thromboprophylactic effect of a low-molecular-weight heparin (Fragmin) in hip fracture surgery. A placebocontrolled study. Clin Orthop Relat Res 1992;(278):95-100. PM:1314147 155 Hinman RS, Crossley KM. Patellofemoral joint osteoarthritis: an important subgroup of knee osteoarthritis. Rheumatology (Oxford) 2007;46(7):10571062. PM:17500072 156-  Kew J, Lee YL, Davey IC, Ho SY, Fung KC, Metreweli C. Deep vein thrombosis in elderly Hong Kong Chinese  
94  
<mark>with hip fractures detected with</mark> compression ultrasound and Doppler imaging: incidence and effect of low molecular weight heparin. Arch Orthop Trauma Surg 1999;119(3-4):156-158. PM:10392509 <mark>157- Eskeland G, Solheim K, Skjorten F.</mark> Anticoagulant prophylaxis, thromboembolism and mortality in elderly patients with hip fractures. Acta Chir Scand 1966;131):16-29.

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Tabela 14 - REABILITAÇÃO E  CUIDADO INTERDISCIPLINAR -->
AAOS NICE ALTA QUALIDADE 164- Berggren M, Stenvall M, Olofsson B, 173- Cameron ID, Lyle DM, Quine S. Cost Gustafson Y. Evaluation of a fall-prevention effectiveness of accelerated rehabilitation program in older people after femoral neck after proximal femoral fracture. Journal of fracture: a one-year follow-up. Osteoporos Int Clínical Epidemiology 1994, 47(11):13072008;19(6):801-809. PM:18030411 13. (Guideline Ref ID: CAMERON1994A) 165- Marcantonio ER, Flacker JM, Wright RJ, 174- Farnworth MG, Kenny P, Shiell A. The Resnick NM. Reducing delirium after hip fracture: costs and effects of early discharge in the a randomized trial. J Am Geriatr Soc management of fractured hip. Age and 2001;49(5):516-522. PM:11380742 Ageing 1994, 23(3):190-4. (Guideline Ref ID:FARNWORTH1994) QUALIDADE MODERADA <mark>166- Huusko TM, Karppi P, Avikainen V, 175- Galvard H, Samuelsson SM. Orthopedic</mark> Kautiainen H, Sulkava R. Intensive geriatric or geriatric rehabilitation of hip fracture rehabilitation of hip fracture patients: a patients: a prospective, randomized, randomized, controlled trial. Acta Orthop Scand clínically controlled study in Malmo, 2002;73(4):425-431. PM:12358116. Sweden.Aging-Clínical & Experimental Research 1995, 7(1):11-6. (Guideline Ref ID:GALVARD1995) 167- Huusko TM, Karppi P, Avikainen V, 176- Hollingworth W, Todd C, Parker M, Kautiainen H, Sulkava R. Randomised, clínically Roberts JA, Williams R. Cost analysis of controlled trial of intensive geriatric rehabilitation early in patients with hip fracture: subgroup analysis of discharge after hip fracture. British Medical  
95  
|patients<br>with<br>dementia.<br>BMJ<br>2000;321(7269):1107-1111. PM:1106173.|Journal 1993, 307(6909):903-6. (Guideline<br>Ref ID: HOLLINGWORTH1993).|
|---|---|
|168- Krichbaum K. GAPN postacute care<br>coordination improves hip fracture outcomes.<br>West<br>J<br>Nurs<br>Res<br>2007;29(5):523-544.<br>PM:17526868|177- Huusko TM, Karppi P, Avikainen V,<br>Kautiainen H, Sulkava R. Intensive geriatric<br>rehabilitation of hip fracture patients: a<br>randomized,<br>controlled<br>trial.<br>Acta<br>Orthopaedica Scandinavica 2002, 73(4):425-<br>31. (Guideline Ref ID: HUUSKO2002A)|
|169- Shyu YI, Liang J, Wu CC et al.<br>Interdisciplinary intervention for hip fracture in<br>older Taiwanese: benefits last for 1 year. J<br>Gerontol A Biol Sci Med Sci 2008;63(1):92-97.<br>PM:1824576.|178- Lieberman D, Friger M, Lieberman D.<br>Inpatient rehabilitation outcome after hip<br>fracture surgery in elderly patients: a<br>prospective cohort study of 946 patients.<br>Arch Phys Med Rehabil 2006;87(2):167-171.<br>PM:16442967.|
|170-  Shyu YI, Liang J, Wu CC et al. Two-year<br>effects of interdisciplinary intervention for hip<br>fracture in older Taiwanese. J Am Geriatr Soc<br>2010;58(6):1081-1089. PM:20722845|179-  O'Cathain A. Evaluation of a Hospital<br>at Home scheme for the early discharge of<br>patients with fractured neck of femur. Journal<br>of<br>Public<br>Health<br>Medicine<br>1994,<br>16(2):205-10.<br>(Guideline<br>Ref<br>ID:<br>OCATHAIN1994)|
|171- Shyu YI, Liang J, Tseng MY et al.<br>Comprehensive Care Improves Health Outcomes<br>Among Elderly Taiwanese Patients With Hip<br>Fracture. J Gerontol A Biol Sci Med Sci 2012.<br>PM:22960477|179- Parker MJ, Pryor GA, Myles JW. Early<br>discharge after hip fracture. Prospective 3-<br>year study of 645 patients. Acta Orthopaedica<br>Scandinavica 1991, 62(6):563-6. (Guideline<br>Ref  ID: PARKER1991)|
|172- Stenvall M, Olofsson B, Lundstrom M et al.<br>A multidisciplinary, multifactorial intervention<br>program reduces postoperative falls and injuries<br>after femoral neck fracture. Osteoporos Int<br>2007;18(2):167-175.PM:17061151||  
|**Tabela 15-  Fisioterapia e Terapia Ocupacional**||
|---|---|
|Tabela 15 - FISIOTERAPIA E TERAPIA OCUPACIONAL||
|AAOS|NICE|
|ALTA QUALIDADE||  
96  
<mark>180- Ziden L, Kreuter M, Frandin K. Long188Galvard H, Samuelsson SM.</mark> term effects of home rehabilitation after hip Orthopedic or geriatric rehabilitation of hip fracture - 1-year follow-up of functioning, fracture patients: a prospective, balance confidence, and health-related quality randomized, clínically controlled study in of life in elderly people. Disabil Rehabil Malmo, Sweden. Aging-Clínical & 2010;32(1):18-32. PM:19925273. Experimental Research 1995, 7(1):11-6. (Guideline Ref ID:GALVARD1995) <mark>181- Crotty M, Whitehead CH, Gray S, 189- Hollingworth W, Todd C, Parker M,</mark> Finucane PM. Early discharge and home Roberts JA, Williams R. Cost analysis of rehabilitation after hip fracture achieves early discharge after hip fracture. British functional improvements: a randomized Medical Journal 1993, 307(6909):903-6. controlled trial. Clin Rehabil 2002;16(4):406(Guideline Ref 413. PM:12061475 ID:HOLLINGWORTH1993) QUALIDADE MODERADA 182- Binder EF, Brown M, Sinacore DR, 190- O'Cathain A. Evaluation of a Hospital Steger-May K, Yarasheski KE, Schechtman at Home scheme for the early discharge of KB. Effects of extended outpatient patients with fractured neck of femur. rehabilitation after hip fracture: a randomized Journal of Public Health Medicine 1994, controlled trial. JAMA 2004;292(7):837-846. 16(2):205-10. (Guideline Ref ID: PM:15315998 OCATHAIN 1994) <mark>183- Hagsten B, Svensson O, Gardulf A.</mark> Early individualized postoperative occupational therapy training in 100 patients improves ADL after hip fracture: a randomized trial. Acta Orthop Scand 2004;75(2):177-183. PM:15180233 <mark>184-  Hagsten B, Svensson O, Gardulf A.</mark> Health-related quality of life and self-reported ability concerning ADL and IADL after hip fracture: a randomized trial. Acta Orthop 2006;77(1):114-119. PM:16534710 185-  Tsauo JY, Leu WS, Chen YT, Yang RS. Effects on function and quality of life of postoperative home-based physical therapy for patients with hip fracture. Arch Phys Med Rehabil 2005;86(10):1953-1957. PM:16213237  
97  
<mark>186- Bischoff-Ferrari HA, Dawson-Hughes.</mark> Effect of high-dosage cholecalciferol and extended physiotherapy on complications after hip fracture: a randomized controlled trial. 2010. http://www.nzgg.org.nz/search?search=acute +management;http://dx.doi.org/10.1001/archi nternmed.2010.67;http://www.ncbi.nlm.nih.g ov/pubmed/20458090;http://archinte.amaassn .org/contents-by-date.0.dtl <mark>187- Ziden L, Frandin K, Kreuter M. Home</mark> rehabilitation after hip fracture. A randomized controlled study on balance confidence, physical function and everyday activities. Clin Rehabil 2008;22(12):1019-1033. PM:19052241  
**Tabela 16 - Frequência da  Fisioterapia**  
Tabela 16 - FREQUÊNCIA DA  FISIOTERAPIA  
|AAOS|NICE|
|---|---|
|ALTA QUALIDADE|QUALIDADE ALTA A BAIXA|
|191- Mangione KK, Craik RL, Palombaro KM,<br>Tomlinson SS, Hofmann MT. Home-based leg-<br>strengthening exercise improves function 1 year<br>after hip fracture: a randomized controlled<br>study. J Am Geriatr Soc 2010;58(10):1911-<br>1917. PM:2092946|194- Moseley AM, Sherrington C, Lord<br>SR, Barraclough E, St George RJ, Cameron<br>ID. Mobility training after hip fracture: a<br>randomised controlled trial. Age and<br>Ageing 2009, 38(1):74-80. (Guideline Ref<br>ID: MOSELEY2009)|
||195- Hauer K, Rost B, Rutschle K, Opitz<br>H, Specht N, Bartsch P et al. Exercise<br>training for rehabilitation and secondary<br>prevention of falls in geriatric patients with<br>a history of injurious falls. Journal of the<br>American<br>Geriatrics<br>Society<br>2001,<br>49(1):10-20.<br>(GuidelineRef<br>ID:<br>HAUER2001)|
||196- Karumo I. Recovery and rehabilitation<br>of elderly subjects with femoral neck<br>fractures.<br>Annales<br>Chirurgiae<br>et<br>Gynaecologiae<br>1977,<br>66(3):170-6.<br>(Guideline Ref ID: KARUMO1977A|  
98  
QUALIDADE MODERADA 192- Allegrante JP, Peterson MG, Cornell CN, MacKenzie CR, Robbins. Methodological challenges of multiplecomponent intervention: lessons learned from a randomized controlled trial of functional recovery following hip fracture. 2007.http://www.nzgg.org.nz/search?search=a cute+management;http://www.ncbi.nlm.nih.go v/pubmed/22842835;http://www.kurtis.it/aging /en/previous.cfm 193- Ryan T, Enderby P, Rigby AS. A randomized controlled trial to evaluate intensity of community-based rehabilitation provision following stroke or hip fracture in old age. Clin Rehabil 2006;20(2):123-131. PM:16541932

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 17 – Nutrição** -->
|Tabela 17 -  NUTRIÇÃO||
|---|---|
|AAOS|NICE|
|ALTA QUALIDADE|EVIDÊNCIA LIMITADA|
|197- Duncan DG, Beck SJ, Hood K,<br>Johansen A. Using dietetic assistants to<br>improve the outcome of hip fracture: a<br>randomised controlled trial of nutritional<br>support in an acute trauma ward. Age Ageing<br>2006;35(2):148-153. PM:16354710|200- Feldblum I, German L, Castel H et al.<br>(2011)<br>Individualized<br>nutritional<br>intervention during and after hospitalization:<br>the nutrition intervention study clínical trial.<br>Journal<br>of<br>the<br>American<br>Geriatrics<br>Society59:10–17|
||201- Neelemaat F, Bosmans JE, Thijs A et<br>al. (2011) Post-discharge nutritional support<br>in<br>malnourished<br>elderly<br>individuals<br>improves functional limitations. Journal of<br>the American Medical Directors Association<br>12: 295–301|
||202- Neelemaat F, Bosmans JE, Thijs A et<br>al. (2012) Oral nutritional support in<br>malnourished elderly decreases functional|  
99  
||limitations with no extra costs. Clínical<br>Nutrition 31: 183–90|
|---|---|
||203- Norman K, Pirlich M, Smoliner C et al.<br>(2011) Cost-effectiveness of a 3-month<br>intervention<br>with<br>oral<br>nutritional<br>supplements in disease-related malnutrition:<br>a<br>randomised<br>controlled<br>pilot<br>study.<br>European Journal of Clínical Nutrition 65:<br>735–42|
||204- Nuijten M, Mittendorf T (2012) The<br>health economic impact of oral nutritional<br>supplements (ONS) in Germany. Aktuelle<br>Ernährungsmedizin 37: 126–33|
||205- Holyday M, Daniells S, Bare M et al.<br>(2012) Malnutrition screening and early<br>nutrition intervention in hospitalised patients<br>in acute aged care: a randomised controlled<br>trial. Journal of Nutrition, Health & Aging<br>16: 562–8|
|BAIXA QUALIDADE|REVISÃO SISTEMÁTICA COM META-<br>ANÁLISE|
|198- Eneroth M, Olsson UB, Thorngren KG.<br>Nutritional supplementation decreases hip<br>fracture-related complications. Clin Orthop<br>Relat<br>Res<br>2006;451):212-217.<br>PM:16770284|206- Beck AM, Holst M, Rasmussen HH<br>(2013) Oral nutritional support of older (65<br>years+) medical and surgical patients after<br>discharge from hospital: systematic review<br>and meta-analysis of randomized controlled<br>trials. Clínical Rehabilitation 27: 19–27|
|199-  Espaulella J, Guyer H, Diaz-Escriu F,<br>Mellado-Navas JA, Castells M, Pladevall M.<br>Nutritional supplementation of elderly hip<br>fracture patients. A randomized, double-<br>blind, placebo-controlled trial. Age Ageing<br>2000;29(5):425-431. PM:11108415||
||EVIDÊNCIA LIMITADA -   IDOSOS COM<br>FRATURA DE QUADRIL|
||207- Myint MW, Wu J, Wong E et al. (2013)<br>Clínical<br>benefits<br>of<br>oral<br>nutritional<br>supplementation for elderly hip fracture|  
100  
patients: a single blind randomised controlled trial. Age and Ageing 42: 39–45

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 18 – Cálcio e Vitamina D** -->
|Tabela 18 -  CÁLCIO E  VITAMINA D||
|---|---|
|AAOS|NICE|
|QUALIDADE MODERADA|Evidência Limitada|
|208- Bischoff-Ferrari HA, Dawson-Hughes B,<br>Platz A et al. Effect of high dosage<br>cholecalciferol and extended physiotherapy on<br>complications after hip fracture: a randomized<br>controlled<br>trial.<br>Arch<br>Intern<br>Med<br>2010;170(9):813-820. PM:20458090|212- Neelemaat F, Bosmans JE, Thijs A et al.<br>(2011) Post-discharge nutritional support in<br>malnourished elderly individuals improves<br>functional limitations. Journal of the American<br>Medical Directors Association  12: 295–301|
|209-  Prince RL, Devine A, Dhaliwal SS, Dick<br>IM. Effects of calcium supplementation on<br>clínical fracture and bone structure: results of a<br>5-year, double-blind, placebo-controlled trial in<br>elderly<br>women.<br>Arch<br>Intern<br>Med<br>2006;166(8):869-875. PM:16636212|213-Neelemaat F, Bosmans JE, Thijs A et al.<br>(2012) Oral nutritional support in malnourished<br>elderly<br>decreases functional limitations with no extra<br>costs. Clínical Nutrition 31: 183–90|
|210-  Harwood RH, Sahota O, Gaynor K, Masud<br>T, Hosking DJ. A randomised, controlled<br>comparison of different calcium and vitamin D<br>supplementation regimens in elderly women<br>after hip fracture: The Nottingham Neck of<br>Femur<br>(NONOF)<br>Study.<br>Age<br>Ageing<br>2004;33(1):45-51. PM:14695863|214- Myint MW, Wu J, Wong E et al. (2013)<br>Clínical<br>benefits<br>of<br>oral<br>nutritional<br>supplementation for elderly hip fracture<br>patients: a single blind randomised controlled<br>trial. Age and Ageing 42: 39–45|
|211- Chapuy MC, Arlot ME, Duboeuf F et al.<br>Vitamin D3 and calcium to prevent hip fractures<br>in the elderly women. N Engl J Med<br>1992;327(23):1637-1642. PM:1331788||

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 19 -  Osteoporose** -->
|Tabela 19 -  Osteoporose||
|---|---|
|AAOS|NICE|
|215- Lyles KW, Colon-Emeric CS, Magaziner JS<br>et al. Zoledronic acid and clínical fractures and|218- FRAX, the WHO fracture risk assessment<br>tool, is available from www.shef.ac.uk/FRAX<br>QFracture is available from www.qfracture.org|  
101  
|mortality after hip fracture. N Engl J Med<br>2007;357(18):1799-1809. PM:17878149|An intervention threshold is the level of risk at<br>which an intervention is recommended.<br>Patients whose risk is in the region from just<br>below to just above the threshold may be<br>reclassified if BMD is added to assessment.|
|---|---|
|216- Majumdar SR, Beaupre LA, Harley CH et<br>al. Use of a case manager to improve osteoporosis<br>treatment after hip fracture: results of a<br>randomized controlled trial. Arch Intern Med<br>2007;167(19):2110-2115. PM:17954806|219- National Institute for Health and Clínical<br>Excellence. (2010) Alendronate, etidronate,<br>risedronate, raloxifene and strontium ranelate<br>for the primary prevention of osteoporotic<br>fragility fractures in postmenopausal women.<br>London:<br>National<br>Institute<br>for Health and Clínical Excellence. (Guideline<br>Ref ID: NICE2010).|
|217-  Gardner MJ, Brophy RH, Demetrakopoulos<br>D et al. Interventions to improve osteoporosis<br>treatment following hip fracture: A prospective,<br>randomized trial. Journal of Bone and Joint<br>Surgery - Series A 2005;87(1):3-7.|220- National Institute for Health and Clínical<br>Excellence. (2010) Alendronate, etidronate,<br>risedronate, raloxifene, strontium ranelate and<br>teriparatide for the secondary prevention of<br>osteoporotic<br>fragility<br>fractures<br>in<br>postmenopausal<br>women.<br>London:<br>National Institute for Health and Clínical<br>Excellence. (Guideline Ref ID: NICE2010A)|
||221-   National Institute for Health and Clínical|
||Excellence. (2010)<br>Denosumab for the<br>prevention<br>of<br>osteoporotic<br>fractures<br>in<br>postmenopausal women. London: National<br>Institute for Health and Clínical Excellence.<br>(Guideline Ref ID: NICE2010B)|

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 20 - Exames** -->
|Tabela 20  -  EXAMES||
|---|---|
|AAOS|NICE|
|**ALBUMINA**||
|Evidência Moderada||
|222- Mosfeldt M, Pedersen OB, Riis T et al. Value of<br>routine blood tests for prediction of mortality risk in hip<br>fracture patients. Acta  Orthop 2012;83(1):31-35.<br>PM:22248167|O NICE não avaliou a albumina<br>e a creatinina separadamente.|
|Baixa Evidência||
|223- Burness R, Horne G, Purdie G. Albumin levels and<br>mortality in patients with hip fractures. N Z Med J<br>1996;109(1016):56-57.  PM:8598940||  
102  
224-   Formiga F, Chivite D, Mascaro J, Ramon JM, Pujol R. No correlation between mini-nutritional assessment (short form) scale   and clínical outcomes in 73 elderly patients                      admitted for hip fracture. Aging Clin Exp Res 2005;17(4):343-346. PM:16285202 225- Ozturk A, Ozkan Y, Akgoz S, Yalcin N, Aykut S, Ozdemir MR. The effect of blood albumin and total lymphocyte count on  short-term results in elderly patients with hip fractures. Ulus Travma Acil Cerrahi Derg 2009;15(6):546-552. PM:20037871 <mark>226-   Lieberman D, Friger M, Lieberman D. Inpatient</mark> rehabilitation outcome after hip fracture surgery in elderly patients: a prospective cohort study of 946 patients. Arch Phys Med Rehabil 2006;87(2):167-171. PM:16442967 **CREATININA** Baixa Evidência 227- Mosfeldt M, Pedersen OB, Riis T et al. Value of routine blood tests for prediction of mortality risk in hip fracture patients. Acta  Orthop 2012;83(1):31-35. PM:22248167                         Talsnes O, Hjelmstedt F, Dahl OE, Pripp AH, Reikeras O. Biochemical lung, liver and kidney markers and early death among  elderly following hip fracture. Arch Orthop Trauma Surg 2012;132(12):1753-1758. PM:22996053 228- Bjorkelund KB, Hommel A, Thorngren KG, Lundberg D, Larsson S. Factors at admission associated with 4 months outcome in  elderly patients with hip fracture. AANA J 2009;77(1):49-58. PM:19263829

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: **Tabela 21 – Geriatra** -->
|Tabela 16 - FREQUÊNCIA DA  FISIOTERA|PIA|
|---|---|
|AAOS|NICE|
|ALTA QUALIDADE|QUALIDADE ALTA A BAIXA|
|229- Mangione KK, Craik RL, Palombaro|232- Moseley AM, Sherrington C, Lord|
|KM, Tomlinson SS, Hofmann MT. Home-|SR, Barraclough E, St George RJ,|
|based leg-strengthening exercise improves|Cameron ID. Mobility training after hip|
|function 1 year after hip fracture: a|fracture: a randomised controlled trial.|
|randomized controlled study. J Am Geriatr|Age and Ageing 2009, 38(1):74-80.|
|Soc 2010;58(10):1911-1917. PM:20929467|(Guideline Ref ID: MOSELEY2009)|  
103  
<!-- Start of picture text -->
233- Hauer K, Rost B, Rutschle K, Opitz<br>H, Specht N, Bartsch P et al. Exercise<br>training for rehabilitation and secondary<br>prevention of falls in geriatric patients<br>with a history of injurious falls. Journal of<br>the American Geriatrics Society 2001,<br>49(1):10-20. (Guideline<br>Ref ID: HAUER2001)<br>234- Karumo I. Recovery and<br>rehabilitation of elderly subjects with<br>femoral neck fractures. Annales<br>Chirurgiae et Gynaecologiae 1977,<br>66(3):170-6. (Guideline Ref ID:<br>KARUMO1977A)<br>QUALIDADE MODERADA<br>230- Allegrante JP, Peterson MG, Cornell<br>CN, MacKenzie CR, Robbins.<br>Methodological challenges of<br>multiplecomponent intervention: lessons<br>learned from a randomized controlled trial of<br>functional recovery following hip fracture.<br>2007.<br>http://www.nzgg.org.nz/search?search=acute<br>+management;http://www.ncbi.nlm.nih.gov/p<br>ubmed /22842835;<br>http://www.kurtis.it/aging/en/previous.cfm<br>231- Ryan T, Enderby P, Rigby AS. A<br>randomized controlled trial to evaluate<br>intensity of community-based rehabilitation<br>provision following stroke or hip fracture in<br>old age. Clin Rehabil 2006;20(2):123-131.<br>PM:16541932<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Fratura do Colo do Fêmur em Idosos (Linha de Cuidado) | secao: Tabela 22  -   ATENDIMENTO DOMICILIAR -->
|AAOS|NICE|
|---|---|
||EVIDÊNCIA LIMITADA|  
104  
|A AAOS avaliou o atendimento domiciliar,<br>junto com o programa de atendimento<br>interdisciplinar|235- Cameron ID, Lyle DM, Quine S. Cost<br>effectiveness of accelerated rehabilitation after<br>proximal femoral fracture. Journal of Clínical<br>Epidemiology 1994, 47(11):1307-13. (Guideline<br>Ref ID: CAMERON1994A)|
|---|---|
||236- Farnworth MG, Kenny P, Shiell A. The costs<br>and effects of early discharge in the management<br>of fractured hip. Age and Ageing 1994, 23(3):190-<br>4. (Guideline Ref ID: FARNWORTH1994).|
||237- Galvard H, Samuelsson SM. Orthopedic or<br>geriatric rehabilitation of hip fracture patients: a<br>prospective, randomized, clínically controlled<br>study in Malmo, Sweden. Aging-Clínical &<br>Experimental<br>Research<br>1995,<br>7(1):11-6.<br>(Guideline Ref ID: GALVARD1995).|
||238- Hollingworth W, Todd C, Parker M, Roberts<br>JA, Williams R. Cost analysis of early discharge<br>after hip fracture. British Medical Journal 1993,<br>307(6909):903-6.<br>(Guideline<br>Ref<br>ID:<br>HOLLINGWORTH1993) .|
||239- Huusko TM, Karppi P, Avikainen V,<br>Kautiainen H, Sulkava R. Intensive geriatric<br>rehabilitation<br>of<br>hip<br>fracture<br>patients:<br>a<br>randomized, controlled trial. Acta Orthopaedica<br>Scandinavica 2002, 73(4):425-31. (Guideline Ref<br>ID: HUUSKO2002A).|
||240- O'Cathain A. Evaluation of a Hospital at<br>Home scheme for the early discharge of patients<br>with fractured neck of femur. Journal of Public<br>Health Medicine 1994, 16(2):205-10. (Guideline<br>Ref ID: OCATHAIN1994)|
||241- Parker MJ, Pryor GA, Myles JW. Early<br>discharge after hip fracture. Prospective 3-year<br>study of 645 patients. Acta Orthopaedica<br>Scandinavica 1991, 62(6):563-6. (Guideline Ref<br>ID: PARKER1991)|  
**Tabela 23 –  Lesão por  Pressão**  
|Tabela 23  - LESÃO  POR PRESS|ÃO||
|---|---|---|
|AAOS|NI|CE|
|Não avaliou a Lesão por pressão.|242- Bergstrom N, Braden BJ<br>Braden Scale for Predicting<br>Research. 1987; 36(4):205-210|, Laguzza A, Holman V. The<br>Pressure Sore Risk. Nursing<br>|  
105  
|243- Anthony D, Reynolds T, Russell L, Anthony D, Reynolds<br>T, Russell L. A regression analysis of the Waterlow score in<br>pressure ulcer risk assessment. Clínical Rehabilitation.<br>England 2003; 17(2):216-223|
|---|
|244-Chan WS, Pang SM, Kwong EW. Assessing predictive<br>validity of the modified Braden scale for prediction of pressure<br>ulcer risk of orthopaedic patients in an acute care setting.<br>Journal of Clínical Nursing. England 2009; 18(11):1565-1573|
|245- Compton F, Hoffmann F, Hortig T, Strauss M, Frey J,<br>Zidek W et al. Pressure ulcer predictors in ICU patients:<br>nursing skin assessment versus objective parameters. Journal<br>of Wound Care. 2008; 17(10):417-424|
|246- Schoonhoven L, Haalboom JRE, Bousema MT, Algra A,<br>Grobbee DE, Grypdonck MH et al.Prospective cohort study of<br>routine use of risk assessment scales for prediction of pressure<br>ulcers. BMJ. 2002; 325(7368):797|
|247- Serpa LF, de Gouveia Santos VL, Gomboski G, Rosado<br>SM. Predictive validity of Waterlow Scale for pressure ulcer<br>development risk in hospitalized patients. Journal of Wound,<br>Ostomy and Continence Nursing. United States 2009;<br>36(6):640-646|
|248-  Serpa LF, Santos VL, Campanili TC, Queiroz M.<br>Predictive validity of the Braden scale for pressure ulcer risk in<br>critical<br>care<br>patients.<br>Revista<br>Latino-Americana<br>De<br>Enfermagem. Brazil 2011; 19(1):50-57|
|249- Pancorbo-Hidalgo PL, Garcia-Fernandez FP, Lopez-<br>Medina IM, Alvarez-Nieto C. Risk assessment scales for<br>pressure ulcer prevention: a systematic review. Journal of<br>Advanced Nursing. 2006; 54(1):94-110|
|250- Jalali R, Rezaie M. Predicting pressure ulcer risk:<br>comparing the predictive validity of 4 scales. Advances in Skin<br>and Wound Care. United States 2005; 18(2):92-97|  
106

---

