<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 17, DE 08 DE SETEMBRO DE 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Osteogênese Imperfeita.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre a Osteogênese Imperfeita no Brasil e diretrizes nacionais para  
diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 747/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 750 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Osteogênese Imperfeita.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Osteogênese Imperfeita, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas</u> Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Osteogênese Imperfeita.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 1.306, de 22 de novembro de 2013, publicada no Diário Oficial da União nº 228, de 25 de novembro de 2013, seção 1, página 58.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
**ANEXO**

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A Osteogênese Imperfeita (OI), também conhecida como doença dos ossos de vidro ou quebradiços e doença de Lobstein, é caracterizada por fragilidade e deformidades ósseas, além de fraturas por mínimo trauma. Em 90% dos casos, a OI é causada por mutações em um dos dois genes (COL1A1 e COL1A2) que codificam as cadeias alfa do colágeno tipo 1 sintetizado pelos osteoblastos, resultando em defeito na mineralização da matriz óssea<sup>1,2</sup> .  
A classificação da OI tem sido revisada e ampliada à medida que se acumula conhecimento sobre a doença. As diferentes classificações da OI consideram aspectos clínicos, gravidade (leve, moderada, grave e letal perinatal), gene acometido e tipo de mutação. Em 2019, foram descritos 19 tipos genéticos de OI (I a XIX), os quais podem se apresentar com diferentes características clínicas. Alguns dos sintomas característicos entre os tipos de OI são: escleróticas azuladas, dentinogênese imperfeita, hiperextensibilidade articular, déficit auditivo, entre outros<sup>3–7</sup> .  
Considerada doença rara, apresenta prevalência incerta, estimada entre 1:10.000 a 1:20.000 nascidos em países como Estados Unidos<sup>5</sup> . Ainda não é clara a prevalência da doença e dos tipos (segundo classificação) no Brasil, pois não foram encontrados dados sobre o total de casos diagnosticados em plataformas oficiais<sup>8</sup> .  
No Brasil, os pacientes com OI são cadastrados e tratados em Centros de Referência para Osteogênese Imperfeita (CROI), os quais foram instituídos pela Portaria GM/MS nº 2.305/2001<sup>9</sup> . Nestes centros, os pacientes podem ser atendidos por profissionais geneticistas, endocrinologistas, fisioterapeutas e ortopedistas. A referida Portaria também estabeleceu as condições para que uma instituição se torne um CROI e publicou o Protocolo de Indicação de Tratamento Clínico da Osteogenesis Imperfecta com pamidronato sódico, que foi posteriormente substituído pelo Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de OI (Portaria SAS/MS nº 714, de 17/12/2010<sup>10</sup> , revogada pela Portaria SAS/MS nº 1306, de 22/11/2014<sup>11</sup> , que aprovou o PCDT que ora mais uma vez se atualiza). Em 2008, o procedimento de internação para a administração do pamidronato para OI também foi unificado e, segundo os dados do Sistema de Informações Hospitalares do SUS, de janeiro de 2015 a dezembro de 2021, foram aprovadas 6.851 autorizações de internação hospitalar (AIH) para este procedimento em todo território nacional, sendo a região nordeste responsável por mais de 37,67% destas internações<sup>12</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da Osteogênese Imperfeita. A metodologia de  
busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
- Q78.0 Osteogênese Imperfeita.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O diagnóstico de OI é frequentemente feito na infância, podendo ocorrer tardiamente na idade adulta. Além das múltiplas fraturas ocasionadas por trauma mínimo, indivíduos com OI podem apresentar deformidades ósseas em crânio, cintura pélvica e ossos longos como fêmur, tíbia e úmero. Outros sinais e sintomas são: dor óssea, baixa estatura, esclera azulada, articulações  
hiperextensíveis, dentinogênese imperfeita, aplasia ou hipoplasia pulmonar. Podem também apresentar morbidades ao longo da vida como, por exemplo, escoliose grave com comprometimento respiratório, mobilidade prejudicada, alterações cardiovasculares, prolapso de válvula mitral, anomalias oculares e surdez<sup>13–16</sup> . O **Quadro 1** apresenta  a classificação da OI proposta por Mortier e colaboradores<sup>6</sup> , considerando algumas características fenotípicas da doença.  
**Quadro 1 -** Principais características clínicas segundo a classificação da OI e mutações associadas  
|**Tipo**|**Gravidade**|**Características**|**Tipo genético**|
|---|---|---|---|
|1|LEVE|Não deformante, com  esclera<br>persistentemente azul|OI tipo I|
|2|LETAL|Forma letal perinatal|OI tipos II, VII, VIII e IX|
|3|GRAVE|Progressivamente deformante|OI tipos III, V, VI, VII, VIII, IX, X, XI, XIII, XIV,<br>XV, XVI, XVII e XVIII|
|4|MODERADA|Em adultos sempre, esclera normal|OI tipos IV, XV, V, VII, IX, XI e XII|
|5|MODERADA|Calcificação das membranas interósseas ou<br>calo hipertrófico|-|  
Fonte: adaptado de Mortier e colaboradores, 20196.  
Para o diagnóstico de OI, devem ser observados os sinais e sintomas, os quais também devem ser monitorados para  
avaliação de resultados terapêuticos. Contudo, pacientes com OI tipo 1 podem não apresentar sintomas clínicos muito claros para o diagnóstico<sup>13–16</sup> .

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Além do exame clínico, a avaliação do metabolismo do cálcio - por meio das dosagens séricas de cálcio, fósforo, fosfatase alcalina e paratormônio (PTH) - é utilizada para confirmar o diagnóstico e avaliar o resultados da terapêutica medicamentosa 1,4,14–20.  
Os testes genéticos para confirmação e identificação da mutação associada são considerados relevantes para o aconselhamento genético e o direcionamento da terapêutica. Esses exames devem ser preferencialmente solicitados pelos profissionais que prestam assistência ao paciente com OI nos Centros de Referência em Osteogenesis Imperfecta (CROI), cadastrados segundo as normas estabelecidas pelo Anexo III da Portaria GM/MS nº 2.305/2001<sup>9</sup> , e poderão ser realizados pelos serviços de atenção especializada e serviços de referência em doenças raras, de acordo com o Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017<sup>21</sup> e com a Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017<sup>22</sup> , relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras, uma vez que a OI é uma doença rara genética que cursa com o grupo de anomalias congênitas ou de manifestações tardias constituinte do Eixo 1 dessa Política<sup>23</sup> .

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
As radiografias (“raios-X”) indicadas para identificar fraturas, calos ósseos e deformidades são:  
- radiografia simples dos ossos longos, nas incidências anteroposterior (AP) e perfil;  
- radiografia panorâmica da coluna em AP e perfil.  
Embora também esteja indicada a radiografia do crânio em perfil para identificar ossos wormianos, verifica-se que não há utilidade deste exame na prática clínica, uma vez que tal deformidade não é tratada.  
Além das radiografias simples, algumas diretrizes clínicas apontam a absorciometria por raios-X com dupla energia (DXA), do inglês _Dual-Energy X-ray absorptiometry_ , como exames auxiliares para o diagnóstico de OI<sup>1,4,9,11,17,18</sup> .  
A DXA corresponde a um método de mensuração da densidade mineral óssea (DMO) por meio da emissão de feixes de raio-X com diferentes níveis de energia para o corpo de um indivíduo<sup>24</sup> . É considerado um método rápido, preciso e com exposição reduzida à radiação. Essas características fazem do DXA o método preferido para avaliar DMO<sup>24–26</sup> . Por outro lado, em crianças e adolescentes, a DXA apresenta algumas limitações, tais como a ausência de bancos de dados de referência robustos para crianças menores de cinco anos; falta de resultados clínicos significativos relacionados às medidas densitométricas; imprecisões e artefatos devido às mudanças no tamanho e composição corporal relacionadas ao crescimento. Ademais, o método faz uso de radiação do tipo ionizante, mesmo que em níveis reduzidos, e requer imobilidade para realização do procedimento, o que pode ser um desafio em crianças menores de 4 anos quando não se lança mão de sedativos<sup>24</sup> . Em revisão de literatura, verifica-se que ensaios clínicos randomizados (ECR) e estudos de coortes utilizam a DXA para avaliar a DMO como resultado dos tratamentos<sup>19,20,27–29</sup> . No entanto, não foram encontradas evidências sobre o uso de DXA como exame diagnóstico para a OI, tampouco sobre a sua validade no monitoramento do tratamento, não sendo possível preconizar o uso desta tecnologia neste PCDT.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A OI deve ser considerada em qualquer criança com fraturas de repetição por traumas mínimos. Contudo, como existem outras doenças que se manifestam por fragilidades ósseas, hereditárias ou não, estas devem ser consideradas no diagnóstico diferencial da OI como, por exemplo, a osteoporose idiopática juvenil<sup>30</sup> . Formas leves de OI podem ser confundidas com a ocorrência de maus-tratos, acrescentando a necessidade da avaliação social, além da avaliação clínica e radiológica<sup>30</sup> . Ainda exames laboratoriais para avaliação do metabolismo do cálcio permitem afastar a hipótese de hipocalcemia ou hiperparatireoidismo pré-existentes.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Serão incluídos neste Protocolo adultos e crianças de ambos os sexos com diagnóstico de OI de todos os tipos conhecidos, elegíveis para o tratamento medicamentoso com bisfosfonatos (pamidronato dissódico ou alendronato) e carbonato de cálcio associado ao colecalciferol, além daqueles com possíveis necessidades de tratamento cirúrgico por presença de deformidades ósseas decorrentes da doença.  
Para o uso de **alendronato** , o paciente deve ser maior de 18 anos, possuir diagnóstico de fenótipos moderados a graves (tipos 3, 4 ou 5); ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidade óssea, com comprovação radiológica; apresentar alterações no metabolismo do cálcio e ser capaz de manter o ortostatismo após a administração do medicamento.  
Para o uso de **pamidronato** em pacientes menores de 18 anos, o paciente deve possuir diagnóstico de fenótipos leves a graves (tipos 1, 3, 4 ou 5); ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidades ósseas com comprovação radiológica e apresentar dor crônica, independentemente do tipo de OI.  
Para o uso de **pamidronato** em pacientes maiores de 18 anos, o paciente deve possuir diagnóstico de fenótipos leves a graves (tipos 1, 3, 4 ou 5); ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidades ósseas com  
comprovação radiológica, apresentar dor crônica e ser impossibilitado de utilizar bisfosfonato oral devido à intolerância (dispepsia, refluxo gastresofágico, hérnia de hiato) ou incapacidade de manter ortostatismo.  
Para o uso de **carbonato de cálcio + colecalciferol** , o paciente deve ter idade maior que 4 anos, estar em uso de bisfosfonato e apresentar alterações no metabolismo de cálcio.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou  
contraindicações absolutas ao uso do respectivo medicamento ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
<mark>Devido às deformidades ósseas, ao risco aumentado de fraturas recorrentes em ossos longos (fêmur, tíbia e úmero), bem como às limitações de mobilidade, os tratamentos ortopédico e fisioterápico em centros especializados devem ser avaliados e indicados para pacientes portadores de OI</mark><sup>1,31</sup> .

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
<mark>A intervenção cirúrgica desempenha importante papel de proteção à região intramedular, visto que atua no realinhamento e na prevenção de deformidades, o que propicia a redução da ocorrência de fraturas e estimula a deambulação. Assim, para que o tratamento cirúrgico seja eficaz, o implante intramedular deve atuar como um dispositivo de reforço, transformando o segmento ósseo em uma estrutura mais resistente e alinhada</mark><sup>1,32</sup> .  
<mark>Para deformidades de ossos longos de valor angular maior que 20</mark><sup>०</sup> <mark>, o tratamento cirúrgico com hastes intramedulares é indicado</mark><sup>33</sup> <mark>. Estão disponíveis no SUS as hastes flexíveis para uso infantil, o fio de Kirschner e o fio de Steinmann rosqueado.</mark>  
<mark>O tratamento cirúrgico de deformidades ósseas provenientes da OI também pode envolver o uso da haste intramedular telescópica, desenvolvida para acompanhar o crescimento progressivo dos ossos longos, por isso chamada de extensível</mark><sup>33,34</sup> . A <mark>incorporação desta tecnologia no SUS foi avaliada pela Conitec, conforme Relatório de Recomendação nº 697/2022, com deliberação final desfavorável à incorporação. Portanto, seu uso não é preconizado neste Protocolo.</mark>

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O tratamento medicamentoso está indicado aos pacientes com OI que possuam deformidades de ossos longos, fraturas por compressão vertebral e que tenham sofrido duas mais fraturas por ano e consiste no uso de bisfosfonatos (alendronato oral e pamidronato dissódico de uso intravenoso), além da suplementação com cálcio e vitamina D.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O pamidronato dissódico é um medicamento antirreabsortivo de administração intravenosa (IV) da classe dos bisfosfonatos, que tem demonstrado eficácia no aumento da DMO. O efeito deste medicamento no osso é dependente de vários fatores como composição da matriz, quantidade e distribuição dos ossos cortical e trabecular, como também da geometria óssea<sup>35</sup> .  
Em pacientes com OI menores de 18 anos, um ensaio clínico randomizado e não cego demonstrou que o uso do pamidronato na dose de 10 mg/m²/dia durante três dias a cada 3 meses, associado ao suplemento de cálcio, incrementou a DMO individual no primeiro ano de seguimento, além de promover maior alteração na DMO da coluna L1 – L4 e maior aumento, em 12 meses, da altura média e área vertebral (L1-L4) em relação ao grupo controle. Também houve redução de incidência de fratura nos membros superiores no primeiro ano de tratamento (p=0,04). Como evento adverso, as crianças apresentaram febre com o primeiro ciclo de infusão, porém, nenhuma outra complicação foi observada<sup>35</sup> .  
Coortes comparativas também demonstraram melhora da média do escore Z da DMO da coluna após o tratamento com pamidronato, em comparação ao estado inicial ou linha de base, além de alguma melhora na função motora<sup>36–38</sup> . Dessa forma, o uso do bisfosfonato intravenoso pamidronato é preconizado para tratamento de pacientes com diagnóstico de OI menores de 18 anos e que apresentam dor crônica, deformidades ósseas ou fraturas.  
A história natural das fraturas na OI demonstra maior incidência na pré-puberdade, com diminuição após a puberdade, aumentando novamente quando os pacientes envelhecem, a partir dos 50 a 60 anos<sup>39</sup> . Pode-se supor que a taxa de fratura diminui no período pós-tratamento, refletindo a história natural das fraturas na OI e, portanto, o uso de bisfosfonatos não traria benefícios clínicos importantes para a população adulta.  
Para pacientes maiores de 18 anos com OI, o estudo comparativo de coortes retrospectivas de Shapiro e colaboradores (2010)<sup>39</sup> avaliou o uso do pamidronato, comparado a não utilização de bisfosfonatos. Nos resultados do estudo, pacientes que usaram pamidronato apresentaram aumento da taxa da DMO da coluna lombar (L1-L4) comparado aos pacientes não tratados, embora o resultado não seja estatisticamente significativo. Quanto à DMO no quadril total, não houve diferença dos resultados comparados entre os grupos. No que tange às fraturas, o resultado do uso do pamidronato para pacientes adultos com OI não foi conclusivo. Entre os pacientes com OI tipos 3 ou 4, a redução de fratura entre os períodos pré e pós-tratamento foi favorável ao pamidronato, porém, não significativo. Já para os pacientes com OI tipo 1, o uso do pamidronato não resultou em redução da proporção de fraturas, sendo esta até maior do que a proporção de fraturas nos pacientes não tratados, embora não estatisticamente significativa<sup>39</sup> .  
Devido às limitações metodológicas, a evidência sugere que o pamidronato pode incrementar a DMO da coluna lombar e quadril nos adultos com OI dos tipos 1, 3 ou 4, embora tenha efeito inconclusivo quanto à redução de fraturas, com possível efeito apenas nos pacientes dos tipos 3 ou 4. Assim, pacientes com OI maiores de 18 anos devem utilizar pamidronato para redução das fraturas na fase adulta. Além disso, o pamidronato é uma possibilidade terapêutica para pacientes que não possam fazer uso do bisfosfonato oral.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O alendronato é um bisfosfonato oral, inibidor da reabsorção óssea, que é capaz de aumentar a DMO da coluna e do quadril e reduzir a incidência de fraturas vertebrais, do quadril e do antebraço em mulheres na pós-menopausa, assim como, a incidência de fraturas vertebrais e do quadril em homens com osteoporose<sup>40</sup> .  
Estudos clínicos buscaram avaliar os efeitos dos bisfosfonatos orais na DMO e na incidência de fraturas em crianças e adolescentes com OI<sup>41–43</sup> . Porém, o medicamento não apresenta indicação em bula para esta população. O estudo de Dimeglio e colaboradores (2005)<sup>44</sup> comparou especificamente o efeito do alendronato de administração oral versus pamidronato intravenoso em pacientes pediátricos com OI quanto ao incremento na DMO corporal total e da coluna lombar, incidência de fratura e eventos adversos. Em dois anos de tratamento, foi observado que tanto o alendronato quanto o pamidronato incrementaram a DMO corporal total acima do esperado para o crescimento esquelético normal **.** Houve melhor resposta na DMO e no crescimento em crianças com OI mais leve (tipo 1, p ≤ 0,001) em relação àquelas portadoras de OI mais graves (tipos 3 e 4; p = 0,02), porém, sem efeitos significativos quanto à idade e estágio puberal. O aumento da DMO da coluna lombar também foi equivalente entre os grupos e a incidência de fratura sofreu diminuição significativa entre o pré e pós-tratamento em ambos os grupos. No grupo que utilizou pamidronato intravenoso, houve relatos de febre, mialgia e vômito no segundo dia do primeiro ciclo de infusão. Não foram observados eventos adversos no grupo que recebeu tratamento oral com alendronato<sup>44</sup> .  
As evidências demonstram resultados equivalentes entre os bisfosfonatos alendronato e pamidronato em pacientes pediátricos com OI. No entanto, no que diz respeito ao aumento da DMO e à redução de fraturas, os estudos não avaliaram desfechos que justificassem a substituição do medicamento intravenoso pelo oral, tais como conforto ou preferências do paciente e familiares. Assim, considerando a baixa qualidade da evidência, a ausência de superioridade do alendronato em comparação  
ao pamidronato para população infantil com OI, bem como ausência de indicação em bula para essa população, o uso de alendronato não é preconizado neste Protocolo para pacientes com OI menores de 18 anos.  
Para pacientes maiores de 18 anos com OI, o estudo comparativo de coortes de Shapiro e colaboradores (2010)<sup>39</sup> também avaliou o uso dos bisfosfonatos orais (alendronato ou risedronato) e o intravenoso (pamidronato). A DMO da coluna e quadril e a incidência de fratura foram os desfechos analisados. Não houve diferença significativa entre os resultados dos tratamentos para aumento de DMO de coluna lombar e quadril. No entanto, a evidência sugere um incremento um pouco maior nos pacientes adultos com OI tipo 1, 3 ou 4 com o uso dos bisfosfonatos orais (alendronato ou risedronato). Os bisfosfonatos orais não foram associados a uma diminuição de incidência de fratura pré e pós-tratamento, tanto nos pacientes tipo 1 quanto tipos 3 ou 4, enquanto o pamidronato se mostrou eficaz na redução de fraturas nos pacientes dos tipos 3 ou 4<sup>39</sup> . Embora se deva considerar os vários anos de acompanhamento dos pacientes neste estudo, algumas limitações introduziram incertezas nos resultados, como: o número limitado de pacientes, o que conduziu a análise dos resultados agregados dos tipos de OI (3 ou 4); além da combinação de resultados do alendronato e do risedronato, podendo influenciar na estimativa de efeito individual de cada medicamento. Mesmo considerando as limitações metodológicas da evidência, este Protocolo preconiza o uso do alendronato para população maior de 18 anos com OI.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O ácido zoledrônico é um bisfosfonato de terceira geração com potência antirreabsortiva superior aos outros bisfosfonatos e que não necessita internação hospitalar para sua administração. Este medicamento tem sido estudado para o tratamento de adultos com osteoporose e de crianças com vários distúrbios ósseos, incluindo Síndrome de McCune-Albright, osteoporose induzida por esteroides, Doenças de Perthes, necrose avascular e OI (tipos 1, 3 e 4)<sup>19,45–48</sup> .  
Os ensaios clínicos controlados de Barros e colaboradores (2012)<sup>19</sup> e Elekwachi e Lubas (2008)<sup>48</sup> compararam o uso do ácido zoledrônico e do pamidronato no tratamento de OI (tipos 1, 3 e 4) em pacientes menores de 18 anos, em estágio pré-puberal e puberal. No estudo de Barros e colaboradores (2012)<sup>19</sup> , além do diagnóstico clínico de OI, a população apresentava ao menos uma fratura por trauma mínimo no último ano antes da randomização e foi tratada com 4 ciclos de bisfosfonato além da suplementação diária de cálcio e vitamina D em doses adequadas à idade. Os resultados demonstraram aumento na média da DMO da coluna lombar, tanto com o uso do pamidronato quanto com o uso do ácido zoledrônico. Ao final do tratamento, o Z escore da coluna lombar foi maior nos pacientes que receberam ácido zoledrônico. Já o ensaio clínico de Elekwachi e Lubas (2008)<sup>48</sup> demonstrou que o percentual de mudança entre a DMO da linha de base e 12 meses após tratamento foi maior no grupo do ácido zoledrônico (46%) em comparação com o pamidronato (41%). No entanto, não houve diferença no número total de pacientes com fraturas entre os dois tratamentos, tampouco entre os grupos no tempo até a primeira fratura clínica. Assim, os resultados dos estudos demonstram a não inferioridade do ácido zoledrônico em relação ao pamidronato, uma vez que não foi possível demonstrar sua superioridade de forma consistente.  
Para a população com OI acima de 18 anos, não foram encontrados estudos que compararam o tratamento do ácido zoledrônico com o pamidronato<sup>48</sup> .  
Tendo em vista que as evidências atualmente disponíveis não demonstram a superioridade do ácido zoledrônico e o fato deste medicamento não ter indicação aprovada em bula para tratamento de OI, este Protocolo não preconiza seu uso no tratamento de crianças, adolescentes e adultos com OI.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
- Alendronato: comprimidos de 10mg e 70 mg  
- Pamidronato: frasco-ampola de 60 e 90 mg.  
- Carbonato de cálcio + colecalciferol: comprimido de 500 mg + 400 UI ou comprimido de 500 mg + 200 UI.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
- Alendronato: Pacientes com 35 kg ou mais devem utilizar dose de 70 mg/semana ou 10 mg/dia, por via oral, ingerida em jejum pela manhã com água (200 mL), pelo menos meia hora antes da primeira refeição e de outros medicamentos. O paciente deve manter a posição ortostática (sentado ou em pé) por, no mínimo, 30 minutos após a administração do medicamento. Pacientes com menos de 35 kg, devem utilizar 30 mg ou 40 mg/semana, a critério médico. A apresentação de 10 mg, inclusive, permite o uso diário do alendronato.  
<mark>- Pamidronato: em crianças menores de 2 anos, a dose preconizada é de 0,5 mg/kg/dia por 3 dias a cada dois meses. Em crianças de 2 a 3 anos, preconiza-se 0,75 mg/kg/dia por 3 dias a cada 3 meses. Pacientes maiores de 3 anos, devem utilizar 1,0 mg/kg/dia por 3 dias a cada 4 meses. As doses devem ser administradas por via intravenosa. O volume de infusão não deve exceder a 60 mg/h e a concentração na solução de infusão não deve exceder a 90 mg/250 mL. A dose máxima é de 90 mg e o medicamento não deve ser administrado em bolus.</mark>  
<mark>- Carbonato de cálcio + colecalciferol: A dose preconizada é de 1.000 a 2.000 mg de cálcio por dia e 400 a 800 UI de colecalciferol</mark>  
<mark>(vitamina D), a serem administrados, preferencialmente, após as refeições ou conforme orientação médica.</mark>

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Preconiza-se que os pacientes sejam tratados por 2 anos após o período em que não apresentarem mais fraturas.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
- Redução do número de fraturas;  
- redução da dor crônica;  
- redução global do nível de incapacidade física.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A periodicidade das consultas para monitoramento clínico deve ser determinada considerando a idade do paciente, o tratamento medicamentoso e o resultado dos exames laboratoriais e radiológicos.  
Considerando a faixa etária, a periodicidade do monitoramento clínico deve ser:  
- Crianças até 2 anos de idade: a cada 2 meses.  
- Crianças de 2-3 anos: a cada 3 meses.  
- Crianças com mais de 3 anos: a cada 4 meses.  
- Adultos: a cada 6 meses.  
Já em relação ao tratamento medicamentoso, os resultados obtidos podem ser analisados pelos seguintes parâmetros:  
- Número de fraturas e dor óssea registrados pelo paciente ou familiar no período e informado à equipe assistente, podendo ser complementada com a avaliação radiológica a critério clínico<sup>9,11</sup> .  
- Resultados de exames bioquímicos em pacientes com mais de 18 anos (cálcio, fósforo e fosfatase alcalina, creatinina, PTH, e 25-hidroxivitamina D), preferencialmente a cada ciclo de pamidronato ou a cada 4 a 6 meses, quando administrado alendronato. Para o monitoramento da formação e reabsorção óssea, também devem ser avaliados as dosagens séricas de cálcio e creatinina<sup>9,11</sup> .  
A periodicidade das consultas em pacientes com OI do tipo 3 e 4 também deve considerar o diagnóstico e monitoramento de manifestações ósseas (anomalias crânio vertebrais) e extraósseas (perda auditiva, disfunção respiratória, anomalias oculares, anomalias cardiológicas e anomalias dentárias). Caso sejam observadas quaisquer alterações, o paciente deve realizar exames complementares já disponíveis no SUS, como: audiometria, prova de função pulmonar, topografia de córnea e  
ecocardiografia<sup>13,14,18</sup> .  
O monitoramento clínico também deve incluir os possíveis eventos adversos do tratamento medicamentoso da OI que incluem síndrome influenza- _like_ (febre, mialgia, mal-estar, _rash_ cutâneo e vômitos), geralmente após a primeira infusão, além de uveíte e insuficiência respiratória em pacientes com menos de 2 anos. Outros eventos adversos que podem ocorrer são hipocalcemia e leucopenia moderadas, aumento transitório da dor óssea e diminuição transitória da mineralização óssea. Os efeitos em longo prazo são desconhecidos e sugere-se que o uso em excesso possa prejudicar o reparo de microdanos ósseos e de fraturas<sup>49,50</sup> .  
A avaliação radiológica para confirmação de novas fraturas e deformidades ósseas pode ser realizada com a radiografia simples de ossos longos e a panorâmica de coluna vertebral, anualmente ou a critério clínico. Pacientes sem indicação de tratamento medicamentoso ou pós-tratamento devem ser monitorados clinicamente, ao menos, anualmente. Pacientes que voltem a apresentar fraturas ou dor óssea devem ser reavaliados clínica e radiologicamente e, se preencherem novamente os critérios de inclusão para o uso dos medicamentos, devem retornar ao tratamento.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de OI devem ser atendidos em serviços especializados com capacidade de atendimento médico, inclusive ortopédico e fisioterápico, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de atenção especializada em doenças raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de referência em doenças raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao componente federal para o pagamento desses serviços, _para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica_ , o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os serviços de atenção especializada em doenças raras.  
Como já mencionado, os testes genéticos para confirmação e identificação da mutação associada são considerados relevantes para o aconselhamento genético e o direcionamento da terapêutica. Esses exames devem ser preferencialmente solicitados pelos profissionais que prestam assistência ao paciente com OI nos Centros de Referência em Osteogenesis Imperfecta (CROI), cadastrados segundo as normas estabelecidas pelo Anexo III da Portaria GM/MS nº 2.305/2001<sup>9</sup> , e poderão ser realizados pelos serviços de atenção especializada e serviços de referência em doenças raras, de acordo com o Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017<sup>21</sup> e com a Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017<sup>22</sup> , relativas à Política Nacional de Atenção Integral às Pessoas com Doenças  
Raras, uma vez que a OI é uma doença rara genética que cursa com o grupo de anomalias congênitas ou de manifestações tardias constituinte do Eixo 1 dessa Política<sup>23</sup> .  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
1. Ralston SH, Gaston MS. Management of Osteogenesis Imperfecta. Front Endocrinol (Lausanne). 2019;10:924.  
2. Rauch F, Lalic L, Roughley P, Glorieux FH. Relationship between genotype and skeletal phenotype in children and adolescents with osteogenesis imperfecta. J Bone Miner Res. 2010;25:1367–74.  
3. Van Dijk FS, Sillence DO. Osteogenesis imperfecta: Clinical diagnosis, nomenclature and severity assessment. Am J Med Genet. 2014;164:1470–81.  
4. Marini JC, Cabral WA. Osteogenesis Imperfecta. Em: Genetics of Bone Biology and Skeletal Disease [Internet]. Elsevier; 2018 [citado 29 de setembro de 2021]. p. 397–420. Disponível em: https://linkinghub.elsevier.com/retrieve/pii/B978012804182600023X  
5. Bonafe L, Cormier-Daire V, Hall C, Lachman R, Mortier G, Mundlos S, et al. Nosology and classification of genetic skeletal disorders: 2015 revision. Am J Med Genet. 2015;167:2869–92.  
6. Mortier GR, Cohn DH, Cormier‐Daire V, Hall C, Krakow D, Mundlos S, et al. Nosology and classification of genetic skeletal disorders: 2019 revision. Am J Med Genet. 2019;179:2393–419.  
7. Robinson ME, Rauch F. Mendelian bone fragility disorders. Bone. 2019;126:11–7.  
8. Lima MA de FD de, Horovitz DDG. Contradições das políticas públicas voltadas para doenças raras: o exemplo do Programa de Tratamento da Osteogênese Imperfeita no SUS. Ciênc saúde coletiva. 2014;19:475–80.  
9. Brasil, Ministério da Saúde (MS). Portaria n.<sup>o</sup> 2305/GM    Em 19 de dezembro de 2001.Aprova o protocolo de Indicação de Tratamento Clínico da osteogenesis imperfecta com pamidronato dissódico no âmbito do Sistema Único de Saúde – SUS. dez 20, 2001.  
10.  Secretaria de Atenção à Saúde, Ministério da Saúde. Portaria n<sup>o</sup> 714.  Aprova na forma do Anexo o Protocolo de Indicação de Tratamento Clínico da Osteogenesis Imperfecta. [Internet]. 2010. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/sas/2010/prt0714_17_12_2010.html  
11.  Brasil, Ministério da Saúde (MS), Secretaria de Atenção à Saúde. PORTARIA N<sup>o</sup> 1.306, DE 22 DE NOVEMBRO DE 2013 Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Osteogênese Imperfeita. [Internet]. PORTARIA N<sup>o</sup> 1.306 nov 22, 2013. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/sas/2013/prt1306_22_11_2013.html  
12.  Brasil, Ministério da Saúde (MS), Tabnet DATASUS. Ministério da Saúde. DATASUS. . Departamento de informática do SUS . [Internet]. DATASUS. Disponível em: https://datasus.saude.gov.br/acesso-a-informacao/producao-hospitalarsih-sus/  
13.  Forlino A, Marini JC. Osteogenesis imperfecta. The Lancet. 2016;387:1657–71.  
14.  Otavio AC da C, Teixeira AR, Machado MS, Costa SS da. Alteração auditiva em osteogênese imperfeita: revisão sistemática de literatura. Audiol, Commun Res. 2019;24:e2048.  
15.  Steiner RD, Basel D. COL1A1/2 Osteogenesis Imperfecta. Em: Adam MP, Ardinger HH, Pagon RA, Wallace SE, Bean LJ, Stephens K, et al., organizadores. GeneReviews(®). Seattle (WA): University of Washington, Seattle; 1993.  
16.  Chin TW, Kataria N. Pediatric Pulmonary Hypoplasia. Pediatric Pulmonary Hypoplasia: Background, Pathophysiology, Epidemiolog [Internet]. 2017; Disponível em: https://emedicine.medscape.com/article/1005696-overview#showall  
17.  Simm PJ, Biggin A, Zacharin MR, Rodda CP, Tham E, Siafarikas A, et al. Consensus guidelines on the use of bisphosphonate therapy in children and adolescents. J Paediatr Child Health. 2018;54:223–33.  
18.  Mueller B, Engelbert R, Baratta-Ziska F, Bartels B, Blanc N, Brizola E, et al. Consensus statement on physical rehabilitation in children and adolescents with osteogenesis imperfecta. Orphanet J Rare Dis. 2018;13:158.  
19.  Barros ER, Saraiva GL, de Oliveira TP, Lazaretti-Castro M. Safety and efficacy of a 1-year treatment with zoledronic acid compared with pamidronate in children with osteogenesis imperfecta. J Pediatr Endocrinol Metab. 2012;25:485–91.  
20.  Lv F, Liu Y, Xu X, Song Y, Li L, Jiang Yan, et al. Zoledronic Acid Versus Alendronate In The Treatment of Children With Osteogenesis Imperfecta: A 2-Year Clinical Study. Endocrine Practice. 2018;24:179–88.  
21.  Ministério da Saúde, Gabinete do Ministro. Portaria de Consolidação n<sup>o</sup> 2. Consolidação das normas sobre as políticas nacionais de saúde do Sistema Único de Saúde. [Internet]. 2017. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html#CAPITULOI  
22.  Ministério da Saúde, Gabinete do Ministro. Portaria de Consolidação n<sup>o</sup> 6. Consolidação das normas sobre o financiamento e a transferência dos recursos federais para as ações e os serviços de saúde do Sistema Único de Saúde. [Internet]. 2017. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.html#TITULOI  
23.  Ministério da Saúde, Gabinete do Ministro. Portaria GM/MS n<sup>o</sup> 981/2014. Política Nacional de Atenção Integral às Pessoas com Doenças Raras. 981 2014.  
24.  Pezzuti IL, Kakehasi AM, Filgueiras MT, de Guimarães JA, de Lacerda IAC, Silva IN. Imaging methods for bone mass evaluation during childhood and adolescence: an update. J Pediatr Endocrinol Metab. 2017;30:485–97.  
25.  Bachrach LK. Consensus and controversy regarding osteoporosis in the pediatric population. Endocr Pract. 2007;13:513– 20.  
26.  Bachrach LK. Dual energy X-ray absorptiometry (DEXA) measurements of bone density and body composition: promise and pitfalls. J Pediatr Endocrinol Metab. 2000;13 Suppl 2:983–8.  
27.  DiMeglio LA, Peacock M. Two-year clinical trial of oral alendronate versus intravenous pamidronate in children with osteogenesis imperfecta. J Bone Miner Res. 2006;21:132–40.  
28.  Xu XJ, Ma DD, Lv F, Wang JY, Liu Y, Xia WB, et al. The clinical characteristics and efficacy of bisphosphonates in audlt patients with osteogenesis impergecta. Endocr Pract. 2016;22:1267–76.  
29.  Pavón de Paz I, Rosado Sierra JA, Pérez Blanco C, Modroño Móstoles N, Guijarro de Armas G, Navea Aguilera C. Acute and long-term effects of zoledronate in adult patients with osteogenesis imperfecta. An observational Spanish study with five years of follow-up. Endocrinol Diabetes Nutr. 2019;66:108–16.  
30.  National Institute for Health and Care Excellence. Child maltreatment: when to suspect maltreatment in under 18s (CG89) [Internet]. NICE 2020; 2017. (NICE guideline). Disponível em: www.nice.org.uk/guidance/cg89  
31.  Lafage-Proust MH, Courtois I. The management of osteogenesis imperfecta in adults: state of the art. Joint Bone Spine. 2019;86:589–93.  
32.  Behera P, Santoshi JA, Geevarughese NM, Meena UKK, Selvanayagam R. Dislodgement of Telescopic Nail from the Epiphysis: A Case Report with an Analysis of Probable Mechanism. Cureus. 2020;12:e7130.  
33.  Fassier A. Telescopic rodding in children: Technical progression from Dubow–Bailey to Fassier–Duval<sup>TM</sup> . Orthopaedics & Traumatology: Surgery & Research. 2021;107:102759.  
34.  Spahn KM, Mickel T, Carry PM, Brazell CJ, Whalen K, Georgopoulos G, et al. Fassier-Duval Rods are Associated With Superior Probability of Survival Compared With Static Implants in a Cohort of Children With Osteogenesis Imperfecta Deformities. J Pediatr Orthop. 2019;39:e392–6.  
35.  Letocha AD, Cintas HL, Troendle JF, Reynolds JC, Cann CE, Chernoff EJ, et al. Controlled trial of pamidronate in children with types III and IV osteogenesis imperfecta confirms vertebral gains but not short-term functional improvement. J Bone Miner Res. 2005;20:977–86.  
36.  Aström E, Jorulf H, Söderhäll S. Intravenous pamidronate treatment of infants with severe osteogenesis imperfecta. Arch Dis Child. 2007;92:332–8.  
37.  Land C, Rauch F, Montpetit K, Ruck-Gibis J, Glorieux FH. Effect of intravenous pamidronate therapy on functional abilities and level of ambulation in children with osteogenesis imperfecta. J Pediatr. 2006;148:456–60.  
38.  Munns CFJ, Rauch F, Travers R, Glorieux FH. Effects of intravenous pamidronate treatment in infants with osteogenesis imperfecta: clinical and histomorphometric outcome. J Bone Miner Res. 2005;20:1235–43.  
39.  Shapiro JR, Thompson CB, Wu Y, Nunes M, Gillen C. Bone mineral density and fracture rate in response to intravenous and oral bisphosphonates in adult osteogenesis imperfecta. Calcif Tissue Int. 2010;87:120–9.  
40.  Chevrel G, Schott AM, Fontanges E, Charrin JE, Lina-Granade G, Duboeuf F, et al. Effects of oral alendronate on BMD in adult patients with osteogenesis imperfecta: a 3-year randomized placebo-controlled trial. J Bone Miner Res. 2006;21:300–6.  
41.  Ward LM, Rauch F. Oral bisphosphonates for paediatric osteogenesis imperfecta? Lancet. 2013;382:1388–9.  
42.  Bishop NJ, Walsh JS. Osteogenesis imperfecta in adults. J Clin Invest. 2014;124:476–7.  
43.  Lv F, Liu Y, Xu X, Wang J, Ma D, Jiang Y, et al. Effects of long-term alendronate treatment on a large sample of pediatric patients with osteogenesis imperfecta. Endocr Pract. 2016;22:1369–76.  
44.  Dimeglio LA, Ford L, McClintock C, Peacock M. A comparison of oral and intravenous bisphosphonate therapy for children with osteogenesis imperfecta. J Pediatr Endocrinol Metab. 2005;18:43–53.  
45.  Högler W, Yap F, Little D, Ambler G, McQuade M, Cowell CT. Short-term safety assessment in the use of intravenous zoledronic acid in children. The Journal of Pediatrics. 2004;145:701–4.  
46.  Vuorimies I, Toiviainen-Salo S, Hero M, Mäkitie O. Zoledronic acid treatment in children with osteogenesis imperfecta. Horm Res Paediatr. 2011;75:346–53.  
47.  Munns CF, Rajab MH, Hong J, Briody J, Högler W, McQuade M, et al. Acute phase response and mineral status following low dose intravenous zoledronic acid in children. Bone. 2007;41:366–70.  
48.  Elekwachi O, Lubas W. Statistical  review and  evaluation: clinical studies.treatment of children with osteogenesis imperfecta (oi). [Internet]. USA: U.S. Department of Health and Human Services Food and Drug Administration; 2008 [citado 22 de novembro de 2021]. (Study 2202). Report No.: NDA/Serial Number:21-223 /SE5-016. Disponível em: https://www.fda.gov/media/71577/download  
49.  Ralston SH, Gaston MS. Management of Osteogenesis Imperfecta. Front Endocrinol. 2020;10:924.  
50.  Rauch F, Glorieux FH. Osteogenesis imperfecta. Lancet. 2004;363:1377–85.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
PAMIDRONATO, ALENDRONATO E CARBONATO DE CÁLCIO + COLECALCIFEROL.  
Eu,_____________________________________________________________________________________________  
(nome do(a) paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de:  
(  ) pamidronato (  ) alendronato (  ) carbonato de cálcio + colecalciferol, indicados para o tratamento de Osteogênese Imperfeita.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)_______________________  
(nome do(a) médico(a) que prescreve). Também foi esclarecido como realizar a guarda dos medicamentos.  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Redução da frequência de fraturas.  
- Prevenção de deformidades nos ossos dos membros superiores e inferiores e da coluna.  
- Redução da dor.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos, e  
estou ciente de que na manifestação de eventos adversos diferentes daqueles já esperados, deverei informar meu médico.  
- **Uso na Gravidez** : as evidências disponíveis são inconclusivas ou inadequadas para determinar o risco fetal quando **pamidronato ou alendronato** são usados em mulheres grávidas. O **carbonato de cálcio + colecalciferol** apresentou evidências de risco fetal humano. Assim, mulheres que desejam engravidar, que já estão grávidas ou amamentando devem comunicar estas condições ao seu médico.  
- Os eventos adversos mais comuns do **pamidronato** são: dor de garganta, calafrios e ondas de calor, semelhante aos sintomas da gripe, nas primeiras 48 horas da infusão.  
- O **pamidronato** também pode causar sintomas menos comuns como: febre e queda do nível de cálcio e potássio no sangue, prisão de ventre (obstipação), perda do apetite, náusea, vômito, dor óssea, ansiedade e reação no local da aplicação. Consultas e exames durante o tratamento são necessários.  
- Os eventos adversos mais comuns do **alendronato** são: dificuldade de deglutir alimentos ou líquidos (disfagia); sensação de dor ao engolir alimentos (odinofagia); dor no peito (retroesternal); azia; úlcera esofagiana e distensão abdominal.  
- O **alendronato** também pode causar sintomas menos comuns como: vermelhidão na pele e dor nos ossos, músculos e articulações; prisão de ventre (constipação), diarreia, gases abdominais (flatulência) e dor de cabeça.  
- Os eventos adversos mais comuns do **carbonato de cálcio + colecalciferol** (vitamina D) em uso prolongado é a prisão de ventre. Raramente podem ocorrer distúrbios gastrintestinais leves, perda de peso e de apetite com uso de vitaminaD.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Foi-me informado que os medicamentos devem ser conservados em suas embalagens originais, protegidos da luz, em ambiente livre de umidade ou calor excessivo (ideal entre 15°C e 30°C).  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Pamidronato  
- (    ) Alendronato  
- (    ) Carbonato de cálcio + colecalciferol  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
NOTA 2: O medicamento pamidronato deve sempre ser administrado por infusão intravenosa lenta, em hospital ou em hospital-dia, após diluição, sendo compatível com o procedimento 03.03.04.002-5 Internação para o tratamento medicamentoso da osteogenesis imperfecta, da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Osteogênese Imperfeita (OI), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
Para a atualização deste PCDT, foi realizada uma reunião de escopo no dia 23 de março de 2021, com a participação de representantes do Ministério da Saúde, do NATS do Instituto Nacional de Traumatologia e Ortopedia (INTO), do NATS Hospital Moinhos de Vento (HMV), especialistas e representante de pacientes. A dinâmica da reunião incluiu a discussão de cada seção do PCDT vigente (Portaria SAS/MS nº 1.306/2013), bem como das condutas clínicas e tecnologias que poderiam ser priorizadas para realização de revisão sistemática das evidências com ou sem formulação de recomendações – sendo norteada por uma revisão prévia de diretrizes internacionais e revisões sistemáticas recentemente publicadas. Nesta reunião, foram evidenciadas as dúvidas clínicas quanto ao: diagnóstico, desfechos, tratamento medicamentoso, tratamento não medicamentoso, monitoramento e tratamentos adicionais para OI. Assim, foram priorizadas 11 questões clínicas e foram elencados pelos especialistas a ordem de prioridade e os desfechos a serem considerados: fraturas, dor, densidade mineral óssea, crescimento, mobilidade, qualidade de vida e desfechos funcionais.  
Posteriormente, verificou-se que, para três questões priorizadas, as dúvidas discutidas durante a reunião de escopo estavam relacionadas ao acesso a tecnologias já disponíveis no âmbito do Sistema Único de Saúde. Desse modo, uma vez que estas dúvidas não eram clínicas, foram desconsideradas três questões, referentes aos testes genéticos, à dosagem de vitamina D e à suplementação de vitamina D + cálcio.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O grupo desenvolvedor deste PCDT foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde, da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS). O painel de especialistas incluiu médicos geneticistas, endocrinologistas (pediátrico/adulto) e cirurgião ortopedista pediátrico.  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?|
|---|  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim|
||(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|  
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|---|---|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser a<br>atividade na elaboração ou revisão da diretriz?|fetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A proposta de atualização do PCDT de Osteogênese Imperfeita foi apresentada à 98ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 19 de abril de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE), Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). Após os ajustes solicitados, a proposta foi apresentada aos membros do Plenário da CONITEC em sua 108ª reunião ordinária, ocorrida em maio de 2022, que deliberaram que a matéria fosse disponibilizada em consulta pública com recomendação preliminar favorável à publicação da atualização  
deste Protocolo.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O processo de desenvolvimento deste PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias ( **Quadro B** )<sup>1</sup> .  
**Quadro B -** Níveis de evidências de acordo com o sistema GRADE  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele<br>estimado|É improvável que trabalhos adicionais irão modificar a confiança<br>na estimativa do efeito.|
|**Moderado**|Há confiança moderada no efeito<br>estimado.|Trabalhos futuros poderão modificar a confiança na estimativa<br>de efeito, podendo, inclusive, modificar a estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto importante<br>em nossa confiança na estimativa de efeito.|
|**Muito baixo**|A confiança na estimativa de efeito é<br>muito limitada.<br>Há um importante grau de incerteza<br>nos achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para cada dúvida clínica, foi elaborada uma pergunta de pesquisa, conforme acrônimo PICO. Para cada uma destas questões, procedeu-se com busca estruturada nas seguintes bases de dados: _Medical Literature Analysis and Retrieval System Online_ (MEDLINE) via Pubmed, _Excerpta medica database_ (EMBASE) via Elsevier e _Cochrane Central Register of Controlled Trials_ via Cochrane Library (CENTRAL). Também foram realizadas buscas em repositórios de diretrizes clínicas para identificar possíveis atualizações no que diz respeito ao cuidado de pacientes com OI.  
Para responder cada questão, foram elaboradas revisões sistemáticas “ _de novo”_ ou foram adotadas ou adaptadas recomendações de protocolos de boas práticas e consenso de especialistas.  
A seleção dos artigos foi realizada conforme critérios de elegibilidade pré-estabelecidos para cada uma das perguntas. Dessa forma, foram elaboradas tabelas de evidências na plataforma GRADEpro GDT para cada questão clínica estruturada (PICO), sendo considerados avaliação do risco de viés, inconsistência entre os estudos, presença de evidência indireta (como população ou desfecho diferente da questão PICO proposta), imprecisão dos resultados (incluindo intervalos de confiança amplos e pequeno número de pacientes ou eventos) e efeito relativo e absoluto para cada questão.  
Após a síntese das evidências, uma reunião de recomendações foi realizada em 13 de dezembro de 2021 com o painel de especialistas. Para a elaboração das recomendações foram considerados os riscos e os benefícios das condutas propostas,  
incluindo nível de evidências, custos, uso de recursos, aceitabilidade pelos profissionais e demais barreiras para implementação. A recomendação poderia ser a favor ou contra a intervenção proposta, e ainda ser uma recomendação forte (o grupo está bastante confiante que os benefícios superam os riscos) ou fraca (a recomendação ainda gera dúvidas quanto ao balanço entre benefício e risco). Dessa forma, a direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião. Buscouse consenso em relação à recomendação e esse foi obtido por unanimidade.  
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE ( **Quadro C** ). Contribuições adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou outros esclarecimentos, foram documentadas ao longo do texto.  
**Quadro C –** Implicações da força da recomendação para profissionais, pacientes e gestores em saúde  
|**Público-alvo**|**Forte**|**Condicional**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das<br>partes interessadas.|
|**Pacientes**|A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno número não aceitaria essa<br>recomendação|Grande parte dos indivíduos desejaria que a<br>intervenção fosse indicada; contudo considerável<br>número não aceitaria essa recomendação.|
|||O profissional deve reconhecer que diferentes|
|**Profissionais**<br>**da saúde**|A maioria dos pacientes deve receber a<br>intervenção recomendada.|escolhas serão apropriadas para cada paciente para<br>definir uma decisão consistente com os seus valores e<br>preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel, recomendações de outras diretrizes, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
**(DXA) para avaliar indicação de tratamento e monitorar resposta ao tratamento em pacientes com OI?**  
**Recomendação:** Embora a DXA seja um exame considerado na rotina de diagnóstico e no monitoramento da DMO, as evidências encontradas quanto ao seu uso em pacientes com OI não permitiram emitir recomendação, por não terem avaliado os desfechos de acurácia de forma comparativa.  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com Osteogênese Imperfeita de todos os tipos, maiores e menores de 18 anos.  
**Intervenção:** Densitometria óssea (por meio DXA).  
**Comparador:** Acompanhamento clínico (radiografia simples ou outros).  
**Desfechos:** Acurácia para medir densidade mineral óssea (DMO) – sensibilidade, especificidade, razão de verossimilhança, Valor Preditivo Positivo (VPP), Valor Preditivo Negativo (VPN), Verdadeiro Positivo (VP), Verdadeiro  
Negativo (VN), Falso negativo (FN) e Falso positivo (FP).

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Foi realizada busca sistematizada da literatura nas bases de dados PubMed, Embase e Cochrane Library, até 09 de junho de 2021. As estratégias de busca para cada base estão descritas no **Quadro D** .  
**Quadro D –** Estratégias de busca de evidências nas bases de dados para identificação de estudos sobre densitometria óssea por meio de DXA  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|**Pubmed**|#1 “Osteogenesis Imperfecta”[Mesh] OR “Osteogenesis Imperfecta” OR “Brittle Bone<br>Disease” OR “Fragilitas Ossium” OR “Ossiums, Fragilitas” OR “Lobstein’s Disease”<br>OR “Disease, Lobstein’s” OR “Lobsteins Disease” OR “Osteogenesis Imperfecta, Type<br>I” OR “Osteogenesis Imperfecta with Blue Sclerae” OR “Osteogenesis Imperfecta,<br>Type 1” OR “Lobstein Disease” OR “Disease, Lobstein” OR “Osteogenesis<br>Imperfecta Tarda” OR “Osteogenesis Imperfecta Tardas”<br>#2 “Absorptiometry, Photon”[Mesh] OR “Absorptiometry, Photon” [All Fields]  OR<br>“Photon Absorptiometry” OR “Densitometry, X-Ray” OR “Densitometry, X Ray” OR<br>“X-Ray Densitometry” OR “Photodensitometry, X-Ray” OR “Photodensitometry, X<br>Ray” OR “X-Ray Photodensitometry” OR “X Ray Photodensitometry” OR<br>“Densitometry, Xray” OR “Xray Densitometry” OR “Single-Photon Absorptiometry”<br>OR “Absorptiometry, Single-Photon” OR “Single Photon Absorptiometry” OR “Dual-<br>Energy X-Ray Absorptiometry Scan” OR “Dual Energy X Ray Absorptiometry Scan”<br>OR “DXA Scan” OR “DXA Scans” OR “Scan, DXA” OR “Scans, DXA” OR “DEXA<br>Scan” OR “DEXA Scans” OR “Scan, DEXA” OR “Scans, DEXA” OR “Dual-Photon<br>Absorptiometry”<br>OR<br>“Absorptiometry,<br>Dual-Photon”<br>OR<br>“Dual<br>Photon<br>Absorptiometry” OR “Radiographic Absorptiometry, Dual-Energy” OR “Radiographic<br>Absorptiometry, Dual Energy” OR “Absorptiometry, Dual-Energy Radiographic” OR<br>“Absorptiometry, Dual Energy Radiographic” OR “Dual-Energy Radiographic<br>Absorptiometry”<br>OR<br>“Dual<br>Energy<br>Radiographic<br>Absorptiometry”<br>OR<br>“Absorptiometry, X-Ray” OR “Absorptiometry, X Ray” OR “X-Ray Absorptiometry”<br>OR “X Ray Absorptiometry” OR “Dual-Energy X-Ray Absorptiometry” OR “Dual<br>Energy X Ray Absorptiometry” OR “X-Ray Absorptiometry, Dual-Energy” OR “X Ray<br>Absorptiometry, Dual Energy” OR “DPX Absorptiometry” OR “Absorptiometries,<br>DPX” OR “Absorptiometry, DPX” OR “Absorptiometry, Dual X-Ray” OR<br>“Absorptiometry, Dual X Ray” OR “X-Ray Absorptiometry, Dual”<br>OR<br>“Absorptiometry, Dual-Energy X-Ray” OR “Absorptiometry, Dual Energy X Ray” OR<br>“Dual X-Ray Absorptiometry’ OR “Dual X Ray Absorptiometry”<br>#3 #1 AND #2|**121**|
|**Embase**|#1 (‘osteogenesis imperfecta’/exp OR ‘bruck syndrome’ OR ‘brittle bone’ OR|**31**|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||‘fibrogenesis imperfecta ossium’ OR ‘idiopathic osteopsathyrosis’ OR ‘lobstein<br>disease’ OR ‘lobstein syndrome’ OR ‘osteogenesis imperfecta’ OR ‘osteopsathyrosis’<br>OR ‘periostal aplasia’ OR ‘fragilitas ossium’/exp)||
||#2 (‘photon absorptiometry’/exp OR ‘absorptiometry, photon’ OR ‘photon<br>absorptiometry’<br>OR<br>‘radiodensitometry’/exp<br>OR<br>‘densitometry,<br>radio’<br>OR<br>‘densitometry, tomo’ OR ‘densitometry, x-ray’ OR ‘radiodensitometry’ OR ‘radiologic<br>densitometry’ OR ‘roentgen densimetry’ OR ‘roentgen densitometry’ OR<br>‘roentgendensimetry’ OR ‘tomodensitometry’ OR ‘x-ray densitometry’)<br>#3 #1 AND #2||
|**Cochrane**|#1<br>MeSH descriptor: [Osteogenesis Imperfecta] explode all trees<br>#2<br>“Osteogenesis Imperfecta”<br>#3<br>#1 OR #2<br>#4<br>MeSH descriptor: [Absorptiometry, Photon] explode all trees<br>#5<br>“Absorptiometry, Photon”<br>#6<br>#4 OR #5<br>#7<br>#3 AND #6|**9**|  
Foram incluídas revisões sistemáticas de ensaios clínicos randomizados com ou sem meta-análise, ensaios clínicos randomizados (ECR) e estudos comparativos não randomizados. Não houve restrições para idiomas. Os resultados das buscas foram exportados para o aplicativo Rayyan QCRI ( _Inteligent Sistematic Review_ ), na qual foram excluídas as duplicatas e selecionados os estudos segundo títulos e resumos, por dois avaliadores independentes. O terceiro revisor atuou na resolução dos conflitos e divergências.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Foram identificados 161 registros nas bases de dados. Após remoção de 25 duplicatas, 10 estudos foram selecionados por título e resumo para leitura de textos completos. Observou-se que, embora atendessem aos critérios de elegibilidade, os estudos não avaliaram a acurácia diagnóstica da DXA. Assim, nenhum estudo foi incluído nesta revisão, conforme mostra a **Figura 1** .  
**Figura 1 –** Fluxograma de seleção dos estudos incluídos sobre densitometria óssea por meio de absorciometria por raios-X com dupla energia (DXA) para avaliar indicação de tratamento e monitorar resposta ao tratamento em pacientes com OI.  
<!-- Start of picture text -->
Medline/Pubmed (n=121) Duplicatas removidas fontes (n=0)<br>EMBASE (n=31) (n=25)<br>Cochrane (n=9)<br>Referéncias excluidas:<br>[Etegives (n=10)_] deNaoacurav a cl ia ramdiagnésticadesfechos(n<br>=10)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
**Recomendação:** Recomendamos o uso de pamidronato para tratamento de pacientes menores de 18 anos com diagnóstico  
de OI que apresentem dor crônica, deformidades ósseas ou fraturas (recomendação forte, nível de evidência muito baixa). A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com osteogênese imperfeita de todos os tipos e **menores** de 18 anos.  
**Intervenção:** Pamidronato dissódico.  
**Comparador:** Não utilizar bisfosfonatos.  
**Desfechos:** Densidade mineral óssea (DMO), fratura, dor, função motora e eventos adversos.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Foi realizada busca sistematizada da literatura nas bases de dados PubMed, Embase e Cochrane Library, até 28 de junho de 2021. As estratégias de busca para cada base estão descritas no **Quadro E** e foram utilizadas para todas as perguntas de pesquisa relacionadas com o uso dos bisfosfonatos para pacientes com OI (questões 2, 3, 4, 5 e 6). Inicialmente, a estratégia de busca foi restringida para ECR. Visto o número limitado de ECR encontrados, optou-se por buscar evidências adicionais utilizando a mesma estratégia de busca.  
**Quadro E –** Estratégias de busca de acordo com a base de dados, para identificação de estudos clínicos sobre o uso de bisfosfonatos para tratamento da OI.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Pubmed|#1 “Osteogenesis Imperfecta” [Mesh] OR “Osteogenesis Imperfecta” OR “Brittle Bone<br>Disease” OR “Fragilitas Ossium OR Ossiums, Fragilitas” OR “Lobstein’s Disease” OR|69|
||“Disease, Lobstein’s” OR “Lobsteins Disease” OR “Osteogenesis Imperfecta, Type I” OR<br>“Osteogenesis Imperfecta with Blue Sclerae” OR “Osteogenesis Imperfecta, Type 1” OR||
||“Lobstein Disease OR Disease, Lobstein” OR “Osteogenesis Imperfecta Tarda” OR<br>“Osteogenesis Imperfecta Tardas”||
||#2<br>“Alendronate”<br>[Mesh]<br>OR<br>“Alendronate”<br>[All<br>Fields]<br>OR<br>“4-Amino-1-||
||Hydroxybutylidene 1,1- Biphosphonate” OR “Aminohydroxybutane Bisphosphonate” OR||  
|**Bases de**<br>**dados**|**Estratégia de busca**<br>“MK-217” OR “MK 217” OR “MK217” OR “Alendronate Monosodium Salt, Trihydrate”<br>OR<br>“Alendronate<br>Sodium<br>OR<br>Fosamax”<br>OR<br>“Diphosphonates”[Mesh]<br>OR<br>“Diphosphonates” OR “Bisphosphonates” OR “Bisphosphonate” OR “Pamidronate”[Mesh]<br>OR “Pamidronate” OR “Amino-1-hydroxypropane-1,1-diphosphonate” OR “Amino 1<br>hydroxypropane<br>1,1<br>diphosphonate”<br>OR<br>“AHPrBP”<br>OR<br>“Aminopropanehydroxydiphosphonate”<br>OR<br>“Amidronate”<br>OR<br>“(3-Amino-1-<br>hydroxypropylidene)-1,1-biphosphonate”<br>OR<br>“Aminohydroxypropylidene<br>Diphosphonate” OR “1-Hydroxy-3-aminopropane-1,1-diphosphonic acid” OR “1 Hydroxy<br>3 aminopropane 1,1 diphosphonic acid” OR “Pamidronic Acid” OR “Pamidronate<br>Monosodium” OR “Pamidronate Calcium” OR “Pamidronate Disodium” OR “Aredia” OR<br>“Risedronic Acid”[Mesh] OR “Risedronic Acid” OR “1-Hydroxy-2-(3-pyridyl)ethylidene<br>diphosphonate” OR “Atelvia” OR “Risedronate Sodium” OR “2-(3-pyridinyl)-1-<br>hydroxyethylidene-bisphosphonate”<br>OR<br>“2-(3-pyridinyl)-1-<br>hydroxyethylidenebisphosphonate” OR “Risedronic Acid, Monosodium Salt” OR<br>“Actonel” OR “Risedronate” OR “Bisphosphonate Risedronate Sodium” OR “Risedronate<br>Sodium, Bisphosphonate” OR “Sodium, Bisphosphonate Risedronate” OR “Zoledronic<br>Acid”[Mesh] OR “Zoledronic Acid” OR “2-(Imidazol-1-yl)-1-hydroxyethylidene-1,1-<br>bisphosphonic acid” OR “CGP 42446A” OR “CGP-42446” OR “CGP 42446” OR<br>“CGP42446” OR “CGP-42’446” OR “CGP42’446” OR “CGP 42’446” OR “Zometa” OR<br>“Zoledronic Acid Anhydrous” OR “Zoledronate”<br>#3 (Randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized<br>controlled trials[mh] OR random allocation[mh] OR double-blind method[mh] OR single-<br>blind method[mh] OR clinical trial[pt] OR clinical trials[mh] OR (“clinical trial”[tw]) OR<br>((singl*[tw] OR doubl*[tw] OR trebl*[tw] OR tripl*[tw]) AND (mask*[tw] OR<br>blind*[tw])) OR (“latin square”[tw]) OR placebos[mh] OR placebo*[tw] OR random*[tw]<br>OR research design[mh:noexp] OR follow-up studies[mh] OR prospective studies[mh] OR<br>cross-over studies[mh] OR control*[tw] OR 22midazole22e*[tw] OR volunteer*[tw])<br>#4 #1 AND #2 AND #3|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Embase|#1 (‘osteogenesis imperfecta’/exp OR ‘bruck syndrome’ OR ‘brittle bone’ OR ‘fibrogenesis<br>imperfecta ossium’ OR ‘idiopathic osteopsathyrosis’ OR ‘lobstein disease’ OR ‘lobstein<br>syndrome’ OR ‘osteogenesis imperfecta’ OR ‘osteopsathyrosis’ OR ‘periostal aplasia’)<br>#2 ‘alendronic acid’/exp OR ‘4 amino 1 hydroxy 1, 1 butanebisphosphonic acid’ OR ‘4<br>amino 1 hydroxy 1, 1 butanediphosphonic acid’ OR ‘4 amino 1 hydroxybutane 1, 1<br>diphosphonate’ OR ‘4 amino 1 hydroxybutane 1, 1 diphosphonic acid’ OR ‘4 amino 1<br>hydroxybutylidene 1, 1 bisphosphonate’ OR ‘4 amino 1 hydroxybutylidene 1, 1<br>bisphosphonic acid’ OR ‘4 amino 1 hydroxybutylidene 1, 1 diphosphonate’ OR ‘4 amino 1<br>hydroxybutylidene 1, 1 diphosphonic acid’ OR ‘alenato’ OR ‘alend’ OR ‘alendronate’ OR<br>‘alendronate sodium’ OR ‘alendronate sodium trihydrate’ OR ‘alendronic acid’ OR<br>‘alendros’ OR ‘alovell’ OR ‘arendal’ OR ‘bifemelan’ OR ‘bifosa’ OR ‘binosto’ OR|383|  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||‘bonapex’ OR ‘defixal’ OR ‘dronal’ OR ‘endronax’ OR ‘eucalen’ OR ‘fixopan’ OR<br>‘fosalan’ OR ‘fosamac’ OR ‘fosamax’ OR ‘fosmin’ OR ‘fosval’ OR ‘marvil’ OR<br>‘maxibone’ OR ‘maxibone 70’ OR ‘mk 0217’ OR ‘mk 217’ OR ‘mk0217’ OR ‘mk217’ OR<br>‘neobon’ OR ‘oncalst’ OR ‘onclast’ OR ‘osdron’ OR ‘osdronat’ OR ‘oseotenk’ OR ‘osficar’<br>OR ‘oslene’ OR ‘osteofar’ OR ‘osteofos’ OR ‘osteopor’ OR ‘osteosan’ OR ‘osteovan’ OR<br>‘osticalcin’ OR ‘porosal’ OR ‘sodium alendronate’ OR ‘teiroc’ OR ‘tibolene’ OR ‘voroste’<br>OR ‘bisphosphonic acid derivative’/exp OR ‘biphosphonate’ OR ‘biphosphonates’ OR<br>‘bisphosphonate’<br>OR<br>‘bisphosphonate<br>derivative’<br>OR<br>‘bisphosphonates’<br>OR<br>‘bisphosphonic acid derivative’ OR ‘diphosphonate derivative’ OR ‘diphosphonate series’<br>OR ‘diphosphonates’ OR ‘diphosphonic acid derivative’ OR ‘pamidronic acid’/exp OR ‘(3<br>amino 1 hydroxypropylidene) 1, 1 diphosphonic acid’ OR ‘1 hydroxy 3 aminopropylidene<br>1, 1 bisphosphonate’ OR ‘3 amino 1 hydroxy 1, 1 propanediphosphonic acid’ OR ‘3 amino<br>1 hydroxypropane 1, 1 diphosphonate’ OR ‘3 amino 1 hydroxypropane 1, 1 diphosphonic<br>acid’ OR ‘3 amino 1 hydroxypropylidene 1, 1 bisphosphonate’ OR ‘3 amino 1<br>hydroxypropylidene 1, 1 bisphosphonic acid’ OR ‘3 amino 1 hydroxypropylidene 1, 1<br>diphosphonate’ OR ‘3 amino 1 hydroxypropylidene 1, 1 diphosphonic acid’ OR ‘3 amino 1<br>hydroxypropylidine 1, 1 diphosphonate’ OR ‘3 amino 1, 1 diphosphonopropanol’ OR ‘3<br>aminohydroxypropylidene<br>1,<br>1<br>diphosphonate’<br>OR<br>‘3<br>hydroxy<br>3,<br>3<br>diphosphonopropylamine’ OR ‘amidronate’ OR ‘aminohydroxypropanediphosphonic acid’<br>OR<br>‘aminohydroxypropyldiphosphonate’<br>OR<br>‘aminohydroxypropylidene<br>1,<br>1<br>diphosphonate’<br>OR<br>‘aminohydroxypropylidene<br>diphosphonate’<br>OR<br>‘aminohydroxypropylidenebisphonic acid’ OR ‘aminohydroxypropylidenebisphosphonate’<br>OR ‘aminohydroxypropylidenediphosphonate’ OR ‘aminomux’ OR ‘apd’ OR ‘aredia’ OR<br>‘aredronet’ OR ‘cgp 23339’ OR ‘cgp 23339a’ OR ‘cgp23339’ OR ‘cgp23339a’ OR<br>‘disodium 3 amino 1 hydroxypropylidene 1, 1 bisphosphonate’ OR ‘disodium 3 amino 1<br>hydroxypropylidene 1, 1 diphosphonate’ OR ‘disodium pamidronate’ OR ‘ostepam’ OR<br>‘pamidrin’ OR ‘pamidro cell’ OR ‘pamidro-cell’ OR ‘pamidrocell’ OR ‘pamidromyl’ OR<br>‘pamidronat’ OR ‘pamidronate’ OR ‘pamidronate disodium’ OR ‘pamidronate disodium<br>novaplus’ OR ‘pamidronate sodium’ OR ‘pamidronato’ OR ‘pamidronic acid’ OR<br>‘pamifos’ OR ‘pamimed’ OR ‘paminject’ OR ‘pamipro’ OR ‘pamired’ OR ‘pamisol’ OR<br>‘pamitor’ OR ‘panolin’ OR ‘panorin’ OR ‘ribodronat’ OR ‘sodium pamidronate’ OR<br>‘texpami’ OR ‘risedronic acid’/exp OR ‘1 hydroxy 2 (3 pyridinyl) ethylidene 1, 1<br>bisphosphonic acid’ OR ‘1 hydroxy 2 (3 pyridyl) 1, 1 ethanebisphosphonic acid’ OR ‘1<br>hydroxy 2 (3 pyridyl) ethylidene 1, 1 bisphosphonate’ OR ‘1 hydroxy 2 (3 pyridyl)<br>ethylidene 1, 1 bisphosphonic acid’ OR ‘2 (3 pyridinyl) 1 hydroxyethylidene 1, 1<br>bisphosphonic acid’ OR ‘acrel’ OR ‘actonel’ OR ‘actonel once a week’ OR ‘atelvia’ OR<br>‘benet’ OR ‘ne 58019’ OR ‘ne 58095’ OR ‘ne58019’ OR ‘ne58095’ OR ‘optinate’ OR<br>‘ribastamin’ OR ‘risedronate’ OR ‘risedronate monosodium hemipentahydrate’ OR<br>‘risedronate sodium’ OR ‘risedronic acid’ OR ‘zoledronic acid’/exp OR ‘1 hydroxy 2 (1||  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||imidazolyl) 1, 1 ethanebisphosphonic acid’ OR ‘1 hydroxy 2 (1h 24midazole 1 yl)<br>ethylidenebisphosphonic acid’ OR ‘1 hydroxy 2 (24midazole 1 yl) ethylidenebisphosphonic<br>acid’ OR ‘aclasta’ OR ‘cgp 42446’ OR ‘cgp 42446a’ OR ‘cgp42446’ OR ‘cgp42446a’ OR<br>‘orazol’ OR ‘reclast’ OR ‘zol 446’ OR ‘zol446’ OR ‘zoledronate’ OR ‘zoledronate<br>disodium’ OR ‘zoledronate trisodium’ OR ‘zoledronic acid’ OR ‘zoledronic acid disodium<br>salt hydrate’ OR ‘zoledronic acid hydrate’ OR ‘zoledronic acid monohydrate’ OR ‘zomera’<br>OR ‘zometa’<br>#3 ‘crossover procedure’/exp AND [embase]/lim OR (‘prospective study’/exp AND<br>[embase]/lim) OR (‘follow up’/exp AND [embase]/lim) OR (‘placebo’/exp AND<br>[embase]/lim) OR (‘clinical trial’/exp AND [embase]/lim) OR (‘single blind procedure’/exp<br>AND [embase]/lim) OR (‘double blind procedure’/exp AND [embase]/lim) OR<br>(‘randomization’/exp AND [embase]/lim) OR (‘controlled clinical trial’/exp AND<br>[embase]/lim) OR (‘randomized controlled trial’/exp AND [embase]/lim)<br>#1 AND #2 AND #3||
|Cochrane<br>Library|#1 MeSH descriptor: [Osteogenesis Imperfecta] explode all trees<br>#2 “Osteogenesis Imperfecta”<br>#3 MeSH descriptor: [Alendronate] explode all trees<br>#4 “Alendronate”<br>#5 “Pamidronate”<br>#6 MeSH descriptor: [Pamidronate] explode all trees<br>#7 MeSH descriptor: [Risedronic Acid] explode all trees<br>#8 “Risedronic Acid”<br>#9 MeSH descriptor: [Zoledronic Acid] explode all trees<br>#10 “Zoledronic Acid”<br>#11 #1 OR #2<br>#12 #3 OR #4 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10<br>#13 #11 AND #12|58|  
Foram incluídas revisões sistemáticas de ECR com ou sem meta-análise, ECR e estudos comparativos não randomizados. Não houve restrições para idiomas. Após a exclusão dos estudos duplicados, a seleção foi realizada por pares de revisores, utilizando o aplicativo Rayyan QCRI ( _Inteligent Sistematic Review_ ). O terceiro revisor atuou na resolução dos conflitos e divergências.  
Foram identificados 710 estudos, dos quais 152 foram removidos por duplicidade, restando 558 estudos para serem avaliados em relação a títulos e resumos. Destes, foram excluídos 462, totalizando 96 para serem submetidos a leitura de texto completa. Foram excluídos 9 estudos por não apresentarem o texto completo. A análise de elegibilidade excluiu 83 estudos, sendo 45 por desenhos metodológicos e 38 por apresentarem intervenções diferentes, restando 1 ECR e 3 coortes que foram incluídos nesta revisão, conforme mostra a **Figura 2** .  
**Figura 2 –** Fluxograma de seleção dos estudos incluídos sobre pamidronato no tratamento de pacientes com OI menores de 18 anos.  
<!-- Start of picture text -->
Medline/Pubmed (n=269) Duplicatas removidas fontes (n=0)<br>EMBASE (n=383) (n=152)<br>(n5s8) Excluidas (n=462)<br>Referéncias excluidas:<br>Etegiveis (n=96) Desenho de estudo (n =45)<br>ECR (n =1)<br>Coortes (n = 3)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Como os estudos apresentaram delineamentos diferentes, não foram realizadas meta-análises. Assim, os resultados foram descritos narrativamente.  
Letocha e colaboradores<sup>2</sup> desenvolveram um ensaio clínico controlado e não cego que incluiu 18 crianças entre 4 e 16 anos, com uma média de idade para entrada no grupo de tratamento de 11,05 (variação: 7-13 anos) e para o grupo de controle foi de 9,97 anos (variação: 4-13 anos). Para o grupo de tratamento, foram designadas 9 crianças, sendo 5 delas portadoras de OI tipo IV e 4 com OI tipo III. Das 9 crianças que participaram do grupo controle, 5 possuíam OI tipo III e 4 eram portadoras de OI tipo IV. Nenhuma das crianças havia recebido tratamento prévio com bisfosfonato. No início do estudo, todos os pacientes apresentaram compressão vertebral em radiografias da coluna lateral, porém, nenhum tinha histórico cirúrgico da coluna lombar.  
O pamidronato intravenoso (IV) foi administrado por três dias com dose de 1 mg/Kg a cada três meses no grupo tratado. Em ambos os grupos os pacientes receberam suplementação de cálcio (500 mg/dia para menores de 10 anos e 100 mg/dia para maiores de 10 anos). Quatro pacientes de ambos os grupos foram co-inscritos em um protocolo para receberem injeções de hormônio de crescimento recombinante (rGH) (0,06 mg/kg/dia por 6 dias/semana). Os desfechos avaliados foram densidade mineral óssea (DMO), medidas de área e altura vertebral (L1 -L4), medidas funcionais, incidência de fratura e dor. A DMO foi mensurada por meio da DXA da coluna lombar. Tomografia computadorizada quantitativa (TCQ) foi usada para medir área e altura vertebrais. A soma da altura foi calculada pela soma das alturas vertebrais médias (cm) e a soma da área foi calculada pela soma (cm<sup>2</sup> ) das áreas vertebrais de L1-L4.  As alterações da DXA e TCQ foram medidas por escores z comparados a crianças não acometidas por OI, pareadas por idade e sexo. Um z escore é o número de desvios padrão da estimativa média da população de referência. O cálcio ionizado sérico foi analisado pela manhã, antes de cada infusão de pamidronato. O escore BAMF ( _Brief Assessment of Motor Function_ ) foi utilizado para avaliação da função motora. O BAMF é uma avaliação de 10 pontos préambulatorial, sendo um método quantitativo de avaliação da função motora que mostrou confiabilidade e validade concorrente em crianças com uma variedade de distúrbios neurológicos e musculoesqueléticos. Além desta escala, foi usado o teste muscular manual (TMM), o qual foi realizado em cada visita, pelo mesmo fisioterapeuta e fisiatra. Este teste avalia a força dos músculos abdominais e das extremidades inferiores, incluindo a avaliação dos levantamentos bilaterais das pernas retas, abdução, extensão e flexão do quadril e extensão do joelho (1-10 pontos cada). Para avaliação da dor, foi usada uma autoavaliação, o _NIH Functional Assessment Pain Score_ , composto de quatro pontos: 4 = sem dor, 3 = dor não interferindo nas atividades funcionais, 2 = dor interferindo nas atividades funcionais, 1 = dor intratável. As principais características do ensaio clínico de Letocha et al. (2005)  
> 2 incluído na revisão sistemática estão descritas no **Quadro F** .  
**Quadro F –** Principais características do ensaio clínico que avaliou o pamidronato no tratamento de pacientes com OI menores de 18 anos  
|**Estudo/**<br>**Desenho**|**Características da**<br>**população**|**Intervenção e**<br>**Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|**Letocha et**|Pacientes (n=18)|**Pamidronato**10mg/m<sup>2</sup>/dia por três dias a|**Densidade mineral óssea e**|
|**al (2005)**<sup>2</sup>||cada 3 meses +**suplemento de cálcio**|**área/altura da coluna**|
||Idade 4 a 16 anos|(n=5)|**lombar**- mensurada por|
|ECR|OI tipo III (50%) e IV<br>(50%)<br>Sem tratamento prévio|**Pamidronato**10mg/m<sup>2</sup>/dia por três dias a<br>cada 3 meses +**hormônio de crescimento**|meio do de DXA e TCQ e<br>avaliada por escore z.|
||com bisfosfonatos|recombinante (rGH) (0,06 mg/kg/dia por 6|**Fratura:**Incidência em|
||Todos com compressão<br>vertebral em radiografias|dias/semana)**e suplemento de cálcio**(n=4)|ossos longos|
||da coluna lateral sem|**Hormônio de crescimento**recombinante|**Função motora**–|
||histórico de procedimento<br>cirúrgico na coluna<br>2 anos|(rGH) (0,06 mg/kg/dia por 6 dias/semana) e<br>**suplemento de cálcio**(n=4)<br>**Suplemento de cálcio**(n=5)|mensurada por meio do<br>BAMF (_Brief Assessment of_<br>_Motor Function_)<br>**Dor**– mensurada por meio<br>de NIH_Functional_<br>_Assessment Pain Score_|  
Na linha de base, o grupo controle teve uma pontuação Z média da DXA praticamente igual à do grupo tratado com pamidronato. As pontuações do escore Z da DXA para o grupo tratado aumentaram de forma constante com cada infusão ao longo de 12 meses, com mudança individual variando de 0,1 a 2,75 desvio padrão (DP) sobre a média da população de referência (1,4 ± 0,7). Porém, este aumento não foi constante ao longo dos 24 meses de seguimento do estudo. Todos os pacientes tinham compressões vertebrais basais. As alterações na altura e área vertebral (L1-L4) foram significativas no primeiro ano de tratamento com pamidronato: altura na linha de base de 2,03 cm (± 1,28) versus, após 12 meses, 2,5 cm (± 1,03), p=0,018; área na linha de base de 1,35 cm<sup>2</sup> (± 0,95) versus, após 12 meses, 1,74 cm<sup>2</sup> (± 0,99), p=0,006. Este aumento se manteve após o segundo ano de tratamento, mas não foi estatisticamente significativo: altura chegando a 2,86 cm (± 0,75) aos 24 meses, p=0,25; área, 1,76 cm<sup>2</sup> (± 0,59), p=0,11. A alteração do intervalo do escore Z da TCQ foi significativamente maior no tratamento do que no grupo controle (0,51 ± 0,49 vs. −0,06 ± 0,59, p=0,05).  
<mark>Não houve mudança significativa em relação à incidência de fratura de ossos longos nos membros inferiores comparadas à linha de base do primeiro e segundo ano de tratamento (p</mark> =0,09 e p=0,29, respectivamente). Nos membros superiores, houve redução significativa no índice de fratura no primeiro ano de tratamento (p=0,04), porém, no segundo ano, não houve alteração (p=0,84). O teste-t bicaudal para o tempo médio da primeira fratura entre os grupos de tratamento e controle foi de 11,3 e 9,3 meses, respectivamente, com p=0,6.  
Em relação aos níveis funcionais e de atividade, não houve alteração com uso do pamidronato. Inclusive, para a escala BAMF, os dois grupos (tratamento e controle) permaneceram na categoria funcional de deambulação com auxílios máximos para marcha. Na avaliação da soma da força dos membros inferiores e força muscular abdominal, pela escala TMM, não houve diferença tanto no início quanto no final dos dois anos de estudos (p=0,49), para ambos os grupos. Para o desfecho dor, não  
houve mudança na autoavaliação nos dois grupos, embora os pacientes tenham relatado aumento da resistência ou diminuição do desconforto nas costas pela manhã, sem nenhuma mudança perceptível. No grupo tratado, as crianças apresentaram reações de fase aguda (febre) com o primeiro ciclo de infusão. Nenhuma outra complicação foi observada.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Como evidência adicional, foram incluídos 3 estudos, sendo uma coorte prospectiva e duas retrospectivas, comparadas com coortes históricas pareadas quanto ao sexo, faixa etária e tipo de OI. As principais características dos estudos adicionais estão descritas no **Quadro G** .  
**Quadro G –** Principais características dos estudos adicionais sobre pamidronato no tratamento de pacientes com OI menores de 18 anos  
|**Estudo/ Desenho**|**Características da população**|**Intervenção e Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|**Aström****_et al_. **<br>**(2006)**<sup>3</sup>|Pacientes (n=22)<br>Idade mediana de 3,6 meses<br>(variação 3 a 13) no início do|**Pamidronato**10 mg/m²      por<br>3 meses, 20 mg/m<sup>2</sup>por 3 meses,<br>e, seguidas por 30 mg/m<sup>2</sup><br>(n=11).|**Densidade mineral óssea**–<br>mensurada por meio do<br>escore Z de DXA lombar|
|Coorte prospectiva|tratamento e 4,8 no final<br>(variação 3,25 a 6,25)<br>OI tipo I, III e IV<br>Todas as crianças tinham fratura<br>por compressão da coluna<br>lombar adquirida de forma<br>recente no início do tratamento<br>Tempo de seguimento: 3 a 6<br>anos|**Coorte histórica pareada**<br>(n=11)<br>Pareamento por sexo, faixa<br>etária e tipo de OI.|**Função motora:**<br>mobilidade<br>**Eventos adversos**|
|**Land****_et al_. **<br>**(2006)**<sup>4</sup>|Pacientes (n=132)<br>Faixa etária de 0,1 a 16,7 anos|**Pamidronato**dose anual do<br>medicamento era a mesma em<br>todas as idades (9 mg/kg)|**Densidade mineral óssea –**<br>mensurada por meio do<br>escore Z da lombar|
|Coorte<br>retrospectiva|OI tipo I, III e IV<br>Grupo controle sem tratamento<br>prévio com bisfosfonatos até a<br>avaliação radiológica lombar<br>Tempo de seguimento: 2 a 4<br>anos|dividida em 3 ciclos. O<br>momento e a dose desses ciclos<br>de 3 dias variaram com a idade<br>(n=66)<br>**Coorte histórica pareada**<br>(n=66)<br>Pareamento por sexo, faixa<br>etária e tipo de OI|**Metabolismo ósseo**<br>**Altura na região da coluna**<br>**lombar**– mensurada por<br>análises de imagens<br>radiológicas.|
|**Munns****_et al_. **<br>**(2005)**<sup>5</sup>|Pacientes (n=58)<br>A média de idade no grupo|**Pamidronato**dose anual do<br>medicamento era a mesma em<br>todas as idades (9 mg/kg)|**Densidade mineral óssea –**<br>mensurada por meio do<br>escore Z de DXA lombar e|  
|**Estudo/ Desenho**|**Características da população**|**Intervenção e Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|Coorte|tratamento foi de 3,7 anos (0,6)|dividida em 3 ciclos. O|histomorfometria do osso|
|retrospectiva|e no grupo controle 3,7 (0,9).|momento e a dose desses ciclos|ilíaco|
||Início do tratamento antes de 2|de 3 dias variaram com a idade||
||anos|(n=29)|**Função motora:**|
||OI tipo III e IV|**Coorte histórica pareada**<br>(n=29)|mobilidade|
||Todas as crianças sem|Pareamento por sexo, faixa||
||tratamento prévio com|etária e tipo de OI||
||bisfosfonatos|||
||Tempo de seguimento: 3 anos|||  
Entre outros desfechos, estes estudos observacionais avaliaram os resultados do pamidronato na DMO e função motora. A descrição dos principais achados dos estudos observacionais incluídos é apresentada no **Quadro H** .  
**Quadro H –** Principais resultados dos estudos adicionais sobre pamidronato no tratamento de pacientes com OI menores de 18 anos  
|**Estudo**|**Principais Resultados**|
|---|---|
|**Aström****_et al_. **<br>**(2006)**<sup>3</sup>|**Densidade Mineral Óssea**– houve melhora da média escore Z após o tratamento com pamidronato.<br>Mudança do escore Z de -3,95 no início do tratamento para -0,96 ao final de 2 anos.|
||**Função motora –**todas as crianças tratadas melhoraram sua capacidade de locomoção, aprenderam a<br>andar, e na última avaliação, cinco crianças tinham mobilidade normal para a idade. Em<br>contrapartida, no grupo controle dois conseguiram andar e seis perderam suas habilidades<br>anteriores.|
|**Munns****_et al_. **<br>**(2005)**<sup>5</sup>|**Densidade Mineral Óssea –**não foi avaliada segundo o escore Z. Aumento da área da coluna lombar<br>(+110), DMO volumétrica (+96%) e pelo volume ósseo da coluna lombar maior (+96%) da DMO.<br>Na histomorfometria do osso ilíaco a taxa de formação óssea por superfície óssea do grupo tratado<br>foi de 17% em relação aos não tratados**.**|
||**Função motora –**tanto a pontuação motora PEDI quanto a pontuação de mobilidade (escala Bleck)<br>foram significativamente maiores no grupo tratado (p< 0,001).|
|**Land****_et al_. **<br>**(2006)**<sup>4</sup>|**Densidade Mineral Óssea –**houve melhora do escore Z após dois anos de tratamento, sendo que     no<br>início do tratamento o escore Z era -5,6 ± 1,3 e ao final Z passou a -2,2 ±1,2.|  
Para avaliação da qualidade metodológica do ensaio clínico de Letocha e colaboradores (2005), foi usada a ferramenta da Cochrane _risk-of-bias tool for randomized trials_ (ROB 2), conforme **Figura 3** . Em relação ao risco de viés, o ensaio clínico de  
Letocha e colaboradores apresentou alto risco de viés global para todos os desfechos avaliados (DMO, fratura, dor e função motora). Houve penalizações nos domínios processo de randomização e desvio da intervenção pretendida. O estudo relatou que somente os avaliadores dos exames foram cegados. O processo de randomização não ficou claro, pois apesar de os autores relatarem que ocorreu de maneira aleatória, a ausência de detalhes compromete a avaliação geral do risco de viés.  
**Figura 3 –** Resultado da avaliação de risco de viés do estudo de Letocha e colaboradores (2005) para os desfechos DMO, fratura, dor e função motora, segundo ferramenta RoB2.  
<!-- Start of picture text -->
Overall<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fonte: Elaboracao Prépria<br>Dominio 1 - Viés decorrente do processo de randomizag3o :<br>DominioDominio 23 -- ViésViés devidodevido a desviosa dados faltantes da intervengdode resultado intencional e@ Baixo<br>Dominio 4 - Viés na medi¢o do resultado eS Moderado<br>Dominio 5 - Viés na selec do resultado relatado @ serio<br><!-- End of picture text -->  
Para avaliação da qualidade metodológica dos estudos observacionais adicionais foi usada a ferramenta da Cochrane _Risk Of Bias In Non-randomized Studies – of Interventions_ (ROBINS-I), conforme **Figura 4** . No estudo de Astrom, os desfechos de DMO, função motora e eventos adversos foram avaliados com risco de viés global sério e foram penalizados os domínios de viés devido ao confundimento e viés devido aos resultados relatados. Já o estudo de Munns avaliou os desfechos DMO e função motora, apresentando risco global sério, penalizando os domínios de viés devido ao confundimento, viés na classificação das intervenções, viés devido à falta de dados e viés devido aos resultados relatados. Land avaliou o desfecho DMO, apresentando risco de viés global crítico, sendo penalizados os domínios de viés devido ao confundimento, viés devido à seleção dos participantes, viés devido a desvios das intervenções pretendidas, viés devido à falta de dados e viés na mensuração dos resultados.  
**Figura 4 –** Resultado da avaliação de risco de viés dos estudos de Astrom, Munns e Land para os desfechos de DMO, função motora e eventos adversos segundo a ferramenta ROBINS- I.  
<!-- Start of picture text -->
Fonte: Elaboracao Prépria<br>D1- Viés devido<br>D2 a confusao<br>D3 -- Viés Viés devidona classificagao a selecdodas de participantesintervencées r ) Baixo<br>D4DS -- ViésViés devidodevido aa desviosfalta de dasdados intervencées pretendidas @ Moderado<br>D 67 - Viés na  mediosele¢do do dosresultado resultados relatado r ) Sério<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A qualidade da evidência foi avaliada como muito baixa para os desfechos: aumento da DMO, redução da incidência de fratura, dor e melhora da função motora com o seguimento de 2 anos; avaliado com a Escala de _Brief Assessment of Motor Function_ – BAMF e variação de teste muscular manual (TMM). Ainda, a qualidade da evidência foi avaliada como baixa para o desfecho melhora da função motora com o seguimento de 3 anos; avaliado com a Escala Bleck. Apesar disso, segundo o painel de especialistas, a recomendação foi forte a favor do uso do pamidronato nesta população e, neste cenário, por identificarem que os benefícios são maiores que os riscos e por este medicamento já ser disponibilizado aos pacientes, com custo já gerenciado.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
O grupo elaborador das recomendações considerou que o uso de pamidronato é indicado em pacientes com OI menores  
de 18 anos, de acordo com os critérios de inclusão que serão descritos a seguir:  
- portadores de fenótipos leve a graves (tipos 1,3,4 ou 5) com dor crônica;  
- ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidades ósseas com comprovação radiológica e apresentar dor crônica, independentemente do tipo de OI.  
A experiência clínica faz com que os especialistas acreditem que os resultados sejam maiores do que os apresentados na evidência e que o evento de hipertermia é comum apenas na 1ª infusão do medicamento no paciente. A internação do paciente para a administração do pamidronato foi considerada como necessária, porém, já pode ser feita em curta permanência no hospitaldia, quando encaminhado ao centro habilitado. O custo da internação pode ser compensado pelo baixo preço do medicamento.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A **Tabela A** apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos: DMO, fratura e dor.  
**Tabela A** – Pamidronato comparado a não utilizar bisfosfonato para o tratamento da OI em menores de 18 anos  
||<br> <br>**Risco**|**Confiança nas ev**|**idências**<br>||||||
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Densida**<br>|**Delineamento**<br>**do estudo**<br>**de**<br>**viés**<br>**de Mineral Óssea (avaliad**<br> <br>|**Inconsistência**<br>**o com: Z escore p**<br>|**Evidência**<br>**indireta**<br>**or meio de D**<br>|**Imprecisão**<br>**XA coluna ve**<br>|**Outras**<br>**considerações**<br>**rtebral)**<br>|**Impacto**<br>|**Confiança**<br>|**Importância**<br>|
|1|ECR<br>Grave<br>a|Não grave|Não grave|Muito<br>grave<sup>b</sup>|Nenhum|**Letocha (2005)**O Z escore para<br>mensuração da DMO pela DXA em L1-<br>L4 aumentou significativamente em<br>pacientes tratados em comparação com<br>o grupo controle por análise de medidas<br>repetidas (p<0,001). A mudança de<br>pontuação Z individual no primeiro ano<br>de estudo variou de 0,1–2,75 DP, com<br>uma média de 1,4 ± 0,7 DP. As<br>pontuações do escore Z para o grupo<br>tratado aumentaram de forma constante<br>em cada infusão.<br>O grupo controle teve uma pontuação Z<br>média indistinguível do grupo de<br>tratamento no início do estudo, mas não<br>mostrou um aumento sobre a linha de<br>base no escore Z durante o estudo.<br>Presença de co-intervenção (hormônio<br>do crescimento em ambos os grupos).|⨁◯◯◯<br>Muito<br>baixa|IMPORTANTE|
|**Densida**|**de Mineral Óssea (avaliad**|**o com: Z escore –**|**DXA colun**|**a vertebral) (a**|**valiado com: (av**|**aliado com: Z escore – DXA coluna vert**|**ebral))**||  
|||**Risco**|**Confiança nas ev**|**idências**<br>||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
|3|Estudo<br>observacional|Grave<br>c|Grave<sup>d</sup>|não grave|Grave<sup>e</sup>|nenhum|Todos os estudos relataram melhora da<br>DMO com o uso do pamidronato.<br>**Astrom (2006)**(n=22) – houve melhora<br>da média escore Z após o tratamento<br>com pamidronato. Mudança do escore Z<br>de -3,95 no início do tratamento para -<br>0,96 ao final de 2 anos.<br>**Munns (2005)**(n=58) – não avaliou<br>DMO segundo o escore Z. Aumento da<br>área da coluna lombar (+110), DMO<br>volumétrica (+96%) e pelo volume<br>ósseo da coluna lombar maior (+96%)<br>da DMO. Na histomorfometria do osso<br>ilíaco a taxa de formação óssea por<br>superfície óssea do grupo tratado foi de<br>17% em relação aos não tratados.<br>**Land (2006)**(n=132) – escore Z no<br>início do tratamento era -5,6 (DP 1,3) e<br>ao final de 2 anos escore Z passou a -2,2<br>(DP 1,2).|⨁◯◯◯<br>Muito<br>baixa|IMPORTANTE|  
**Incidência de fraturas (avaliado com: número de fraturas em 2 anos)**  
|||<br>**Risco**|**Confiança nas ev**|**idências**<br>||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
|1<br>**DOR (av**<br>|ECR<br>**aliado com: NIH**<br>|Grave<br>a<br>**-****_Functio_**<br>|Não grave<br>**_nal Assessment P_**<br>|Não grave<br>**_ain Score_) **<br>|Muito<br>grave<sup>b</sup><br>|nenhum<br>|A incidência de fraturas dos MMSS<br>diminuiu<br>significativamente<br>no<br>primeiro ano de tratamento (p= 0,04),<br>mas não teve a mesma redução no<br>segundo ano (p=0,84). O tempo médio<br>para a primeira fratura de MMII entre os<br>grupos tratamento e controle foi de 11,3<br>contra 9,3 meses respectivamente. No<br>grupo de tratamento, a incidência de<br>fraturas<br>de<br>MMII<br>não<br>mudou<br>significativamente em comparação com<br>a linha de base, no primeiro (p=0,09) e<br>segundo ano (p=0,29).<br>|⨁◯◯◯<br>Muito<br>baixa<br>|CRÍTICO<br>|
|1|ECR|Grave<br>a|Não grave|Não grave|Muito<br>grave<sup>b</sup>|nenhum|A avaliação no estado de dor feita por<br>meio do score NIH, não produziu<br>nenhuma mudança na autoavaliação dos<br>grupos de tratamento ou controle. A<br>maioria dos pacientes não relatou<br>nenhuma mudança perceptível.|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
**Função motora (seguimento: 2 anos; avaliado com: Escala de** **_Brief Assessment of Motor Function_ – BAMF e variação de teste muscular manual TMM)**  
|||<br>**Risco**|**Confiança nas ev**|**idências**<br>||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
|1<br>**Função**<br>|ECR<br>**motora (seguimen**<br>|Grave<br>a<br>**to: 3 an**<br>|não grave<br>**os; avaliado com:**<br>|não grave<br>**Escala Bleck**<br>|Muito<br>grave<sup>b</sup><br>**)**<br>|nenhum<br>|Em relação aos níveis funcionais de<br>atividade não houve alteração com o uso<br>de pamidronato, ambos os grupos<br>permaneceram na categoria funcional<br>de deambulação com auxílios máximos<br>para marcha. Não havendo também<br>diferença em relação à força muscular<br>ao final dos dois anos.<br>|⨁◯◯◯<br>Muito<br>baixa<br>|IMPORTANTE<br>|
|2|Estudo<br>observacional|Grave<br>c|não grave|não grave|Grave<sup>e</sup>|nenhum|Em ambos os grupos todas as crianças<br>tratadas apresentaram melhora quanto a<br>capacidade de locomoção. No estudo de<br>Munns, tanto a pontuação motora PEDI<br>quanto a pontuação de mobilidade<br>(escala Bleck) foram significativamente<br>maiores no grupo tratado (p< 0,001). No<br>estudo de Astrom todas as crianças<br>tratadas melhoraram sua capacidade de<br>locomoção, aprenderam a andar e na<br>última avaliação 5 crianças tinham<br>mobilidade normal para a idade. Em<br>contrapartida, no grupo controle dois|⨁⨁◯◯<br>Baixa|IMPORTANTE|  
||||**Confiança nas evi**|**dências**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
||||||||conseguiram andar e 6 haviam perdido<br>suas habilidades anteriores.|||  
Explicações:  
a. Presença de viés de seleção (randomização não descrita, sem garantia de que houve sigilo de alocação) e provável relato seletivo de desfecho.  
- b. Desfecho avaliado em único estudo com pequeno tamanho amostral.  
- c. Presença de fatores de confusão inerentes ao delineamento do estudo.  
- d. Foram observadas variações na idade dos pacientes, na dose de administração e posologia do pamidronato e no tempo de seguimento.  
- e. Estudos com pequeno tamanho amostral.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A **Tabela B** apresenta o processo de tomada de decisão sobre o uso do pamidronato para o tratamento da OI para pacientes menores de 18 anos, baseando-se nas contribuições do painel de especialistas e na síntese de evidências realizada pelo grupo elaborador sobre essa tecnologia.  
**Tabela B** - Processo de tomada de decisão referente ao uso de pamidronato para tratamento OI em pacientes menores de 18 anos  
|**Item da EtD**|**Julgamento**<br>**painelistas**|**dos**|**Justificativa**|
|---|---|---|---|
|**Benefícios**:|Grande||Benefício foi julgado pelos especialistas como grande, com base<br>nos resultados observados na prática clínica, com melhora<br>significativa da DMO da coluna e redução de fratura da coluna<br>lombar.<br>Painelistas não concordaram que a redução na taxa de fratura ocorra<br>somente em MMSS como apresentado na evidência.|
|**Riscos:**|Pequeno||Painelistas referem ser sintoma comum apenas na 1ª infusão do<br>pamidronato no paciente.|
|**Balanço dos riscos e**<br>**benefícios:**|Favorece<br>intervenção|a|Benefícios são muito maiores que os riscos.|
|**Certeza**<br>**da**<br>**evidência:**|Muito baixa||Painelistas referem que na experiência de mundo real os valores<br>seriam diferentes e os resultados maiores. Maior benefício do uso<br>do pamidronato neste cenário.|
|**Custos:**|Negligenciáveis||O medicamento apresenta um custo incorporado e pequeno.<br>Embora a necessidade de internação aumente o custo do<br>tratamento, este já pode ser feito em hospital DIA, desde que os<br>pacientes sejam encaminhados para Centros habilitados.|
|**Viabilidade**<br>**de**<br>**implementação:**|Sim||Tendo em vista que o tratamento já é ofertado pelo SUS, as<br>questões de implementação já estão consolidadas. O painel de<br>especialistas considerou que o pamidronato já é um medicamento<br>disponível no SUS e apresenta evidências de efetividade e<br>segurança quando utilizado em pacientes com OI.|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
**Recomendação:** Recomendamos o uso do bisfosfonato intravenoso pamidronato para tratamento de pacientes maiores de 18 anos com diagnóstico de OI quando houver intolerância ou contraindicação clínica ao tratamento com bisfosfonato oral alendronato (recomendação forte, nível de evidência baixa).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com osteogênese imperfeita de todos os tipos, **maiores** de 18 anos. **Intervenção:** Pamidronato dissódico. **Comparador:** Não utilizar bisfosfonatos.  
**Desfechos:** Densidade mineral óssea (DMO), Fratura, Dor, Função Motora e Eventos Adversos.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Foi mantida a mesma estratégia de busca para todas as questões relacionadas com o uso de bisfosfonatos já descrita no **Quadro E** . Foram elegíveis revisões sistemáticas de ECR com ou sem meta-análise, ECR e estudos comparativos não randomizados. Não houve restrições para idiomas.  
Foram identificadas 710 referências, sendo 152 removidas por duplicidade, restando 558 estudos para serem avaliados em relação ao título e resumo por dois revisores. Destes, 552 foram excluídos, totalizando 6 para serem avaliados segundo os critérios de elegibilidade da pergunta PICO 3. As divergências entre a dupla de revisores também foram analisadas pelo terceiro revisor e resolvidas por meio de consenso e discussão. Foram excluídos 4 estudos por não terem o texto completo identificado, permanecendo 2 estudos para avaliação do texto completo. Após análise, um estudo foi excluído por desenho metodológico, restando um estudo observacional comparativo, como demonstra a **Figura 5.**  
**Figura 5** – Fluxograma de seleção dos estudos incluídos sobre uso de bisfosfonato intravenoso pamidronato no tratamento de pacientes com OI maiores de 18 anos.  
<!-- Start of picture text -->
Identificadas (N=710) Identificadas em  outras<br>Medline/Pubmed (n=269) Duplicatas removidas fontes (n=0)<br>EMBASE (n=383) (n=152)<br>Cochrane (n=58)<br>(ssa)<br>(n=558) Excluidas (n=552)<br>[Eeeves oe) _] T xtoRDesenho e ferénciascompl tode e estudoxclui n d as:otenticado(n =1)  (n=4)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Foi selecionado um estudo observacional comparativo de coortes retrospectivas, Shapiro et al. (2010)<sup>6</sup> , desenvolvido no Instituto Kennedy Krieger (EUA) e que incluiu 90 adultos com OI tratados com pamidronato intravenoso (n=28), alendronato oral (n=10), risedronato oral (n=17), além dos pacientes não tratados (n=35). Havia 63 pacientes com OI do tipo I, 15 do tipo III e 12 do tipo IV. Os pacientes não haviam recebido tratamento com bisfosfonatos anteriormente.  
A decisão de tratar foi baseada nos seguintes critérios: a frequência de fraturas pós-púberes e uma pontuação básica da DXA por escore Z ou pontuação T, na coluna lombar ou quadril total, de -1,5 ou inferior (com o fator de risco adicional da OI), conforme recomendado pela Associação Americana de Endocrinologia.  
Após a seleção para o tratamento, o paciente pôde escolher entre o uso do pamidronato intravenoso ou bisfosfonatos orais. Pacientes com OI dos tipos III ou IV formaram um único grupo. Da mesma forma, as intervenções de alendronato e risedronato formaram uma única categoria de bisfosfonatos orais. Os resultados da DMO foram observados por até 161 meses e uma média de 52 meses de tratamento. A incidência de fratura foi determinada por um período de 5 anos antes do tratamento inicial com bisfosfonatos e 5 anos após o início do tratamento.  
A dose intravenosa de pamidronato foi de 1,5 mg/kg de peso corporal até um máximo de 60 mg/infusão, administrados como uma dose única durante 4 horas em solução salina normal a cada 3-4 meses, dependendo da adesão aos cronogramas. As principais características do estudo incluído na revisão sistemática estão descritas no **Quadro I** .  
**Quadro I –** Principais características do estudo sobre uso do pamidronato para tratamento de pacientes maiores de 18 anos com diagnóstico de OI  
|**Estudo/**<br>**Desenho**|**Características da população**|**Intervenção e**<br>**Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|**Shapiro****_et al._**<br>**(2010)**<sup>6</sup>|Pacientes (n=90)<br>**Pacientes em uso de pamidronato**|**Pamidronato**<br>**intravenoso (n = 28)**|**Densidade mineral óssea**–<br>mensurada por DXA em 3 sítios de<br>análise: L1 – L4, quadril total e|
|Coorte<br>retrospectiva|– média 42,2 anos (DP=12,1) e<br>67,9% eram homens, 17 com OI<br>tipo I e 11 dos tipos III/IV. Sem<br>tratamento prévio com<br>bisfosfonatos.<br>Pacientes**não tratados**– média<br>38,2 anos (DP=11,6) e 62,9% eram<br>homens. 26 apresentavam OI tipo I<br>e 9 dos tipos III/IV<br>Tempo de seguimento: 3 a 161<br>meses|**Não tratados (n = 35)**<br>Alendronato oral<br>(n = 10)<br>Risedronato oral<br>(n = 17)|colo do fêmur<br>**Fratura**- A incidência de fratura 5<br>anos antes do tratamento inicial<br>com bisfosfonatos e 5 anos após<br>início do tratamento|  
Os 35 indivíduos não tratados tiveram mensuradas a DMO basais por DXA e foram acompanhados em intervalos mais longos do que os 55 pacientes tratados com bisfosfonatos, devido ao cumprimento do cronograma. Dezenove destes pacientes não tratados tiveram apenas medições de DMO basais. Para os outros 16 pacientes não tratados, o período de observação variou de 3 a 118 meses, média de 39,5 meses para todos os pacientes não tratados, incluindo aqueles com DMO apenas basal.  
Para cada categoria de OI, uma análise binomial negativa foi usada para estimar as taxas relativas de fraturas entre os grupos de tratamento e entre os pacientes tratados e não tratados, ajustando para sexo e idade no início da varredura DXA, com as contagens de fraturas de 5 anos pré e pós-tratamento em 51 indivíduos tratados e 22 não tratados, pareados para a idade em que o bisfosfonato foi administrado pela primeira vez ao grupo tratado.  
A descrição geral dos principais achados do estudo Shapiro e colaboradores (2010)<sup>6</sup> se encontra no **Quadro J** .  
**Quadro J –** Principais resultados dos estudos adicionais sobre pamidronato no tratamento de pacientes com OI maiores de 18 anos  
|**Estudo**||**Principais Resultados**|
|---|---|---|
|**Shapiro****_et al_. **|**Densidade Mineral Óssea**||
|**(2010)**<sup>6</sup>|||  
|**Estudo**|**Principais Resultados**<br>**Para pacientes OI tipo I:**<br>O uso do**pamidronato**mostrou uma**taxa anual marginal de aumento na** **DMO da coluna**<br>**lombar L1-L4**de**0,006 gm/cm²/ano**(IC 95% 0,008 a 0,012; p=0,03) e**taxa anual de aumento**<br>**da DMO no quadril**total 0,005 gm/cm²/ano (IC de 95% -0,003 a 0,013; p=0,2),**não significativa**.<br>No grupo**não tratado**,**não houve mudança significativa na DMO da coluna lombar**de L1 – L4<br>(-0,002 gm/cm²/ano; IC 95% -0,009 a 0,006; p=0,6)**como também na DMO do quadril total**(-<br>0,005 gm/cm²/ano; IC 95% -0,012 a 0,003; p=0,2).<br>Pacientes que usaram pamidronato apresentaram o resultado superior em 0,008 gm/cm²/ano (IC<br>95% - 0,0009 – 0,018; p = 0,08) no aumento**na taxa da DMO da coluna lombar (L1-L4)**<br>comparado aos não tratados.**Quanto a DMO no quadril**total, a comparação dos resultados<br>também foi favorável ao pamidronato com resultado superior em 0,009 gm/cm²/ano (IC 95% -<br>0,0019 a 0,02; p=0,08).<br>**Para os pacientes OI tipos III/IV**:<br>O uso do**pamidronato**mostrou um**aumento significativo crescente na taxa da DMO da coluna**<br>**lombar**(L1-L4) de**0,016 gm/cm²/ano**(IC 95% 0,008 a 0,023; p<0,001) e uma taxa de**aumento**<br>**da** **DMO no quadril**total**0,011 gm/cm²/ano**(IC 95% 0,0002 a 0,02; p=0,046).<br>No grupo**não tratado, não houve mudança significativa na DMO da coluna lombar**de L1–L4<br>(0,0045 gm/cm²/ano; IC 95% -0,01 a 0,02; p=0,6) como também na**DMO do quadril**com (0,009<br>gm/cm²/ano; IC de 95% -0,04 a 0,06; p=0,7).<br>Pacientes que usaram pamidronato apresentaram resultado superior em 0,011 gm/cm²/ano (IC 95%<br>-0,005 a 0,027; p=0,18) no aumento da taxa da**DMO da coluna lombar (L1-L4)**comparado aos<br>pacientes não tratados, embora não estatisticamente significativo.**Quanto a DMO no quadril**total<br>**não houve diferença dos resultados comparados entre os grupos**.<br>**Fratura**<br>**Para pacientes OI tipo I:**<br>O uso do**pamidronato**mostrou**razão de fratura**entre o período pré e pós-tratamento de 1,67 (IC<br>95% 0,78 a 3,58; p=0,19**), aumento não estatisticamente significativo.**<br>Pacientes**não tratados**com bisfosfonatos apresentaram nos 5 anos pré-tratamento**razão de**|
|---|---|  
|**Estudo**|**Principais Resultados**|
|---|---|
||**fratura com redução não significativa de**0,65 (IC 95% 0,35 a 1,21; p=0,18).<br>Ao comparar os resultados, a proporção de fraturas pré e pós-tratamento para pacientes tipo I<br>tratados com pamidronato foi maior do que a apresentada pelos pacientes não tratados (2,55; IC<br>95% 0,96 a 6,81; p=0,06) porém, não estatisticamente significativa.<br>**Para os pacientes OI tipos III/IV:**<br>O uso do**pamidronato**mostrou**razão de fratura com redução significativa**de 0,42 (IC  95%<br>0,18 a 0,999; p=0,05)|
||Pacientes**não tratados**com bisfosfonatos apresentaram nos 5 anos pré-tratamento**razão de**<br>**fratura com redução não significativa de**0,48 (IC 95% 0,14 a 1,70; p=0,26).<br>Ao comparar os resultados, a taxa de redução de fratura foi favorável à intervenção, porém, com<br>resultado estatisticamente não significativo de 0,89 (IC 95% 0,19 a 4,06; p=0,88).|  
Segundo os autores do estudo, os resultados demonstraram que o pamidronato intravenoso pode ter um efeito positivo na DMO da coluna lombar L1-L4 anual após um mínimo de 13 meses de tratamento, tanto para os pacientes com OI tipo I quanto aqueles com os tipos III ou IV. Na DMO anual do quadril, o efeito positivo do pamidronato pode ocorrer nos pacientes com os tipos III ou IV.  
O estudo não foi desenvolvido para permitir aferir um efeito específico do local de tratamento em fraturas vertebrais, de quadril ou não vertebrais. O pamidronato levou a uma diminuição significativa na taxa de fratura apenas nos pacientes do tipo III ou IV durante o período de observação de 5 anos, porém, a resposta à fratura dos adultos com OI ao tratamento com bisfosfonatos não foi conclusiva.  
Shapiro e colaboradores (2010)<sup>6</sup> discutiram que a história natural das fraturas em adultos com OI indica que estas são relativamente frequentes na pré-puberdade, mas que a incidência diminui após a puberdade, aumentando novamente quando os pacientes estão na faixa entre 50 e 60 anos. Pode-se supor que a taxa de fratura foi baixa no período pós-tratamento, refletindo a história natural das fraturas em pacientes com OI e que a adição de bisfosfonatos não influenciaria na redução das fraturas. Como a resposta de adultos e crianças é diferente, a decisão clínica deve considerar se o tratamento com bisfosfonatos é apropriado para um paciente individual.  
Para avaliação da qualidade metodológica do estudo incluído foi usada a ferramenta ROBINS I ( **Figura 6** ). O estudo de Shapiro e colaboradores apresentou risco de viés global crítico, sendo penalizados os domínios de viés devido ao confundimento, estudo observacional sem ajuste para confundidores e viés na seleção dos participantes, uma vez que os pacientes foram selecionados segundo resultados do DXA.  
**Figura 6 –** Avaliação do risco de viés segundo a ferramenta ROBINS I para os desfechos DMO e incidência de fraturas.  
<!-- Start of picture text -->
Dominios avatiados: Julgamentos:<br>D1: Viés devido a0 confundimento<br>02: Viés na selesSo dos participantes<br>D3: Viés na classificacdo das intervencies e@ Critico<br>A: Viés por desvio das intervencBes pretendidas ;<br>05: Viés por dados faltantes e@ Baixo<br>06: Viés na mensuracSo dos desfechos<br>07: Viés na selesSo dos resultados relatados<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Devido às limitações metodológicas, a qualidade da evidência foi considerada baixa, sugerindo que o pamidronato pode incrementar a DMO da coluna lombar e quadril nos adultos com OI dos tipos I, III ou IV e ter efeito inconclusivo quanto à redução de fraturas, com possível efeito apenas nos pacientes dos tipos III ou IV. A recomendação foi forte a favor do uso do pamidronato em adultos, considerando a história natural da doença, com redução das fraturas na fase adulta e a possibilidade de garantir tratamento aos pacientes que não possam utilizar bisfosfonato oral.  
Foi julgado pelos especialistas que o benefício do uso de pamidronato por adultos com OI é grande considerando os resultados observados na prática clínica com melhora significativa da DMO da coluna e redução de fratura da coluna lombar. Além disso, o pamidronato pode ser alternativa de tratamento para os pacientes maiores de 18 anos com intolerância ou contraindicações ao tratamento oral com bisfosfonatos.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
Para o uso de pamidronato em pacientes maiores de 18 anos, o paciente deve possuir diagnóstico de fenótipos leves a graves (tipos I, III ou IV); ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidades ósseas com comprovação radiológica, apresentar dor crônica e ser impossibilitado de utilizar bisfosfonato oral, devido à intolerância (dispepsia, refluxo gastroesofágico, hérnia de hiato) ou incapacidade de manter ortostatismo.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A **Tabela C** apresenta os resultados e a avaliação da certeza da evidência (GRADE) para os desfechos DMO e fratura.  
**Tabela C** – Pamidronato comparado a não utilizar bisfosfonatos para o tratamento da OI em pacientes maiores de 18 anos  
||||**Confiança na ev**|**idência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
|1<br>(n=62)|Estudo<br>observacional|Grave<br>a|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|**Pacientes OI tipo I**que usaram<br>**pamidronato**apresentaram o resultado<br>superior em 0,008 gm/cm²/ano (IC 95% -<br>0,0009 – 0,018), [p = 0,08] no aumento na<br>taxa da**DMO da coluna lombar (L1-L4**)<br>comparado aos**não tratados**. Quanto a<br>**DMO no quadril total**, a comparação dos<br>resultados também foi favorável ao<br>pamidronato com resultado superior em<br>0,009 gm/cm²/ano (IC 95% -0,0019 a<br>0,02), [p=0,08]).<br>**Pacientes OI tipo III/IV**que usaram<br>**pamidronato**apresentaram resultado<br>superior em 0,011 gm/cm²/ano (IC95% -<br>0,005 a 0,027), [p=0,18]) no aumento da<br>taxa da**DMO da coluna lombar (L1-L4)**<br>comparado aos pacientes**não tratados**,<br>embora**não estatisticamente**<br>**significativ**o.**Quanto a DMO no**<br>**quadril**total**não houve diferença dos**|⨁⨁◯◯Baixa|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|  
<!-- Start of picture text -->
Confiança na evidência<br>Risco<br>№ dos  Delineamento  Evidência  Outras  Impacto Confiança Importância<br>de  Inconsistência Imprecisão<br>estudos do estudo indireta considerações<br>viés<br>resultados comparados entre os grupos<br>0,002 gm/cm²/ano (IC 95% -0,47 a 0,05),<br>[p=0,94]).<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
|1<br>(n=62)|Estudo<br>observacional|Grave<br>a|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|**Pacientes OI tipo I**a proporção de<br>fraturas pré e pós-tratamento para<br>pacientes tratados com**pamidronato**foi<br>marginalmente maior do que a proporção<br>de pacientes**não tratados**2,55 (IC 95%<br>0,96 a 6,81 [p=0,06]).<br>**Pacientes OI tipo III/IV**a proporção de<br>fraturas pré e pós-tratamento com<br>pamidronato foi favorável à intervenção<br>por refletir redução, porém, com resultado<br>estatisticamente não significativo 0,89 (IC<br>95% 0,19 a 4,06 [p=0,88])|⨁⨁◯◯Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|  
Explicações:  
a.   Conforme avaliação do risco de viés feita por meio da ferramenta ROBINS I, a evidência foi penalizada no domínio D1 por presença de viés de confusão e domínio D2 devido a presença de viés de seleção (seleção de pacientes de acordo com o resultado do DXA).  
b.  Desfecho avaliado em único estudo com tamanho amostral pequeno.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: Geral -->
A **Tabela D** apresenta o processo de tomada de decisão sobre o uso do pamidronato para o tratamento da OI em pacientes maiores de 18 anos baseando-se nas contribuições do painel de especialistas e na síntese da evidência realizada pelo grupo elaborador sobre essa tecnologia.  
**Tabela D** – Processo de tomada de decisão referente ao uso do pamidronato para o tratamento da OI em pacientes maiores de 18 anos  
|**Item da EtD**||**Julgamento**<br>**dos**<br>**painelistas**|**Justificativa**|
|---|---|---|---|
|**Benefícios**:||Grande|O benefício foi julgado pelos especialistas como grande com base nos<br>resultados observados na prática clínica com melhora significativa da<br>DMO da coluna e redução de fratura da coluna lombar, para pacientes<br>adultos. Ademais, o pamidronato pode ser alternativa de tratamento para<br>os pacientes maiores de 18 anos com intolerância ou contraindicações<br>ao tratamento oral.|
|**Riscos:**||Pequeno|Os painelistas consideraram pequenos os riscos em relação à<br>intervenção. Os riscos observados no estudo foram: turnover ósseo e<br>aumento de fraturas para os menos graves (tipo I).|
|**Balanço dos risc**<br>**benefícios:**|**os e**|Favorece<br>a<br>intervenção|Benefícios são muito maiores que os riscos. Painelistas referem que o<br>fenótipo I pode ser acrescentado para a prescrição de pamidronato.<br>Considerar a intolerância ou impossibilidade do bisfosfonato oral.|
|**Certeza**<br>**evidência:**|**da**|Baixa|Devido às limitações metodológicas, a qualidade da evidência foi<br>considerada baixa.|
|**Custos:**||Negligenciáveis|O custo do medicamento está incluído no valor da internação. Embora a<br>necessidade de internação aumente o custo do tratamento, este já pode<br>ser feito em hospital DIA, desde que os pacientes sejam encaminhados<br>para Centros habilitados.|
|**Viabilidade**<br>**implementação**:|**de**|Sim|Tendo em vista que o tratamento já é ofertado pelo SUS, as questões de<br>implementação já estão consolidadas. O painel de especialistas<br>considerou que o pamidronato já é um medicamento disponível no SUS<br>e apresenta evidências de efetividade e segurança quando utilizado em<br>pacientes com OI.|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **QUESTÃO 4: Devemos usar o bisfosfonato oral alendronato versus bisfosfonato intravenoso pamidronato para pacientes com osteogênese imperfeita, menores de 18 anos?** -->
**Recomendação:** Por não haver indicação aprovada para o uso de alendronato em pacientes com OI menores de 18 anos, este medicamento não é preconizado neste Protocolo. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.  
O alendronato ainda não apresenta indicação em bula para população pediátrica. Embora a evidência demonstre resultados equivalentes entre os bisfosfonatos alendronato e pamidronato em pacientes pediátricos com OI, tanto quanto ao incremento da  
DMO, como para redução de fraturas, sua recomendação deve estar pautada na avaliação de desfechos que justifiquem a substituição do medicamento intravenoso pelo oral, como conforto ou preferências do paciente e dos familiares. Além disso, deve ser considerada possível intolerância e contraindicações ao uso do bisfosfonato oral como a impossibilidade de ortostatismo em crianças com OI mais graves.  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes menores de 18 anos com osteogênese imperfeita.  
**Intervenção:** Bisfosfonato oral alendronato.  
**Comparador:** Pamidronato.  
**Desfechos:** DMO, Fratura, dor e eventos Adversos.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **QUESTÃO 4: Devemos usar o bisfosfonato oral alendronato versus bisfosfonato intravenoso pamidronato para pacientes com osteogênese imperfeita, menores de 18 anos?** -->
Foi mantida a mesma estratégia de busca para todas as questões relacionadas com o uso de bisfosfonatos **Quadro E** . Foram incluídas revisões sistemáticas de ECR com ou sem meta-análise, ECR e estudos comparativos não randomizados. Não houve restrições para idiomas.  
Foram identificados 710 estudos, dos quais 152 foram removidos por duplicidade, restando 558 estudos para serem avaliados em relação aos títulos e resumos. Destes, foram excluídos 462, totalizando 96 para serem submetidos aos critérios de elegibilidade com a leitura do texto completo. Destes, 9 estudos não foi identificado texto completo. Todo processo de seleção foi realizado por dois revisores. Um terceiro revisor resolveu os conflitos por discussão e consenso. A análise de elegibilidade excluiu 86 estudos, sendo 47 por desenhos de estudos e 39 por apresentarem intervenções diferentes e de modo que 1 ECR foi incluído, conforme mostra a **Figura 7** .  
**Figura 7 -** Fluxograma de seleção dos estudos incluídos sobre bisfosfonato oral alendronato versus bisfosfonato intravenoso pamidronato para pacientes com osteogênese imperfeita, menores de 18 anos.  
<!-- Start of picture text -->
Identificadas (N=710) Identificadas em outras<br>Mediine/Pubmed (n=269) Duplicatas removidas fontes (n=O)<br>EMBASE (=383) (n=152)<br>Cochrane (n=58)<br>Rastreadas ae<br>feos) Excluidas (n=462)<br>Referéncias excluidas:<br>.<br>Elegivels(0=96) ‘Texto completo nao identificado (n = 9)<br>Desenho de estudo (n =47)<br>Outras intervengées (n =39)<br>(RRR [ircicos 2)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **QUESTÃO 4: Devemos usar o bisfosfonato oral alendronato versus bisfosfonato intravenoso pamidronato para pacientes com osteogênese imperfeita, menores de 18 anos?** -->
O ECR aberto de Di Meglio e Peacock<sup>7</sup> comparou a segurança e eficácia do bisfosfonato oral alendronato em comparação ao intravenoso pamidronato para os desfechos a DMO corporal total, DMO da coluna lombar, incidência de fratura e eventos adversos. Para tanto, foram selecionadas dezoito crianças com idade superior a três anos com diagnóstico de OI. A idade média foi de 8,7 anos, com média de 1,7 fraturas/ano no grupo oral e para o grupo intravenoso a média de idade foi de 8,4 anos e 2,1 fraturas/ano. Os pacientes foram estratificados por idade óssea, estágio puberal e tipo de OI e, em seguida, randomizadas para o  
tratamento, sendo 9 para alendronato oral e 9 para pamidronato intravenoso. As crianças do grupo do bisfosfonato oral receberam 1 mg/kg de alendronato por dia e, no grupo pamidronato intravenoso, foram administrados 3 mg/kg por 3 dias consecutivos de 4 em 4 meses. Ambos os grupos passaram por avaliação a cada 4 meses. Durante os 24 meses, foi observada retenção esquelética estimada de 3,5 µg/kg/dia no grupo que utilizou alendronato e de 125 µg/kg/dia, no grupo que utilizou pamidronato. As dezoito crianças completaram os 2 anos de tratamento. No **Quadro K** estão descritas as principais características do estudo incluído na revisão sistemática.  
**Quadro K -** Principais características do estudo Di Meglio e Peacock (2005)<sup>7</sup> sobre bisfosfonatos intravenosos e orais no tratamento de pacientes com OI menores de 18 anos.  
|**Estudo/ Desenho**|**Características da população**|**Intervenção e**<br>**Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|**Di Meglio e**<br>**Peacock (2005)**<sup>7</sup>|Pacientes (n=18)<br>Estratificadas por idade óssea,|**Pamidronato**intravenoso 3<br>mg/kg em 3 dias<br>consecutivos de 4 em 4|**DMO corporal total**<br>**DMO da coluna lombar**|
|**ECR**<br>|estágio puberal e tipo de OI.<br>Idade superior a 3 anos.<br>Média de idade de 8,7 anos no<br>grupo Alendronato.<br>Média de idade de 8,4 anos no<br>grupo do Pamidronato.<br>2 anos de tratamento|meses**(n=9)**<br>**Alendronato**1 mg/kg/dia<br>**(n=9)**|**Incidência de fratura**<br>**Eventos adversos**|  
Analisando a DMO corporal total, observou-se um Z escore médio de -1,5 (-3,8 a 0,9), classificado como baixo para a idade cronológica. Em dois anos de tratamento, tanto com alendronato quanto com pamidronato, foram observados aumento na DMO, sendo esse acima do esperado para o crescimento esquelético normal. Não houve diferença significativa nas variáveis densitométricas entre os grupos. Em ambos os tratamentos foi observada melhor resposta na DMO e no crescimento em crianças com OI mais leve (tipo I, p ≤ 0,001) em relação àquelas portadoras de OI mais grave (tipos III e IV, p = 0,02), porém, sem efeitos significativos quanto à idade e estágio puberal. Para DMO de L2-L4, observou-se um Z escore médio de -3,4 (-5,7 a -1,6). Houve aumento equivalente da DMO da coluna lombar com ambos os tratamentos.  
Ambos os grupos apresentaram redução estatisticamente significativa na incidência de fraturas, sendo menor entre crianças com OI leve (tipo I) antes e durante o tratamento, quando comparadas às crianças com OI mais grave (tipos III e IV). Antes do tratamento, o número de fraturas/ano foi de 1,3 (± 1,0) fraturas/ano em pacientes com OI tipo I e de 3,1 (± 1,4) fraturas/ano em pacientes com OI tipo III e IV. Durante a terapia, as taxas de fraturas para o grupo de OI na forma leve foram de 0,6 (± 0,7) fraturas/ano e de 2,2 (± 1,5) fraturas/ano para o grupo de OI grave (p<0,01).  
Os eventos adversos encontrados durante o tratamento com pamidronato intravenoso, no segundo dia do primeiro ciclo de infusão, foram: febre, mialgia e vômito. Não foram observados eventos adversos (dor abdominal, sangramento ou sangue oculto nas fezes) no grupo que recebeu tratamento oral com alendronato. No **Quadro L** é apresentada a descrição geral dos principais resultados do estudo.  
**Quadro L -** Principais resultados do estudo de Di Meglio e Peacock (2005)<sup>7</sup> sobre pamidronato versus alendronato no tratamento de pacientes com OI menores de 18 anos.  
|**Estudo**|**Principais Resultados**|
|---|---|
|**Di Meglio e**|**Densitometria Mineral Óssea (DMO) corporal total -**Foi observado que em dois anos de|
|**Peacock**<br>**(2005)**<sup>7</sup>|tratamento,**não houve diferença significativa nas variáveis densitométricas entre os grupos**. Com o<br>**alendronato**a DMO passou de -1,1 (DP=1,4) para -0,5 (DP=1,5) (p<0,05), em 12 meses, e para -0,1<br>(DP=1,6) (p<0,01), após 24 meses. Com o**pamidronato**a DMO passou de -1,8 (DP=1,3) para -1,4<br>(DP=1,5) (p<0,05) após 12 meses, chegando a -0,9 (DP=1,9) (p<0,05), após 24 meses. Foi observada<br>melhor resposta na DMO e no crescimento em crianças com OI mais leve (tipo I, ρ ≤ 0,001) em relação<br>àquelas portadoras de OI mais grave (tipos III e IV, ρ = 0,02), porém, sem efeitos significativos quanto<br>à idade e estágio puberal.|
||**DMO da coluna lombar -**Houve aumento equivalente com ambos os tratamentos. Com o<br>**alendronato**a DMO passou de -3,2 (DP=1,0) para -1,8 (DP=1,2) após 12 meses de tratamento<br>(p<0,01) e para -1,1 (DP=1,2) (p<0,05), após 24 meses de tratamento. Com o**pamidronato**<br>aumentou de -3,2 (DP=1,3) para -2,1 (DP=1,8) (p<0,05) após 12 meses; e para -1,3 (DP=2,0)<br>(p<0,01), após 24 meses de tratamento.|
||**Fratura: a incidência de fratura sofreu diminuição significativa em ambos os grupos:**<br>Alendronato, a taxa anual de fratura antes do tratamento foi de 1,7 (DP=1,1). Durante o tratamento a<br>taxa foi de 1,4 (DP=1,5). Pamidronato, a taxa anual de fratura foi de 2,1 (DP=1,7) e durante o<br>tratamento foi de 0,9 (DP=0,9). No resultado geral dos tratamentos, grupos combinados, a taxa anual<br>de fraturas passou de 1,9(DP=1,4) para 1,1 (DP=1,2); p<0,05.|
||**Eventos adversos:**no segundo dia do primeiro ciclo de infusão, no grupo do pamidronato<br>intravenoso ocorreu febre, mialgia e vômito. Não foram observados eventos adversos (dor abdominal,<br>sangramento ou sangue oculto nas fezes) no grupo que recebeu tratamento oral com alendronato.|  
Em relação ao risco de viés, o estudo de Di meglio e Peacock (2005)<sup>7</sup> apresentou alto risco de viés global para todos os desfechos avaliados (DMO, fraturas e eventos adversos). Houve penalizações nos domínios de viés decorrente do processo de randomização, uma vez que o processo de randomização não foi descrito e não há garantia de que houve sigilo de alocação, e viés devido à desvios da intervenção intencional já que não houve cegamento dos participantes ( **Figura 8** ).  
**Figura 8 -** Avaliação do Risco de viés para os desfechos fratura e eventos adversos, segundo a ferramenta RoB2, do estudo de Di meglio e Peacock (2005)<sup>7</sup> .  
<!-- Start of picture text -->
Overall<br>err  Fonte: Elaboração Própria  TT y JOlc l }<br>Domínios avaliados:<br>+  Baixo<br>Domínio 1 - Viés decorrente do processo de randomização<br>Domínio 2 - Viés devido aos desvios da intervenção intencional<br>Domínio 3 - Viés devido aos dados faltantes de resultado  -  Moderado<br>Domínio 4 - Viés na medição do resultado<br>Sério<br>Domínio 5 - Viés devido à seleção dos resultados reportados  X<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **QUESTÃO 4: Devemos usar o bisfosfonato oral alendronato versus bisfosfonato intravenoso pamidronato para pacientes com osteogênese imperfeita, menores de 18 anos?** -->
A **Tabela E** apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos DMO da coluna lombar, DMO corporal total e incidência de fraturas.  
**Tabela E** - Certeza da evidência segundo sistema GRADE para alendronato versus pamidronato no tratamento OI em pacientes menores de 18 anos  
|||**C**|**onfiança nas ev**|**idências**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Alendro-**<br>**nato**|**Pamidro-**<br>**nato**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(95% IC)**|**Confiança**|**Importância**|  
**DMO coluna lombar (seguimento: 2 anos; avaliado com: Z escore)**  
|1<br>(n=18)|ECR|Grave<br>a|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|Houve aumento da DMO (escore Z da coluna<br>lombar) em ambos os grupos.<br>**Alendronato**de -3,2 (DP=1,0) para -1,8<br>(DP=1,2) após 12 meses de tratamento (p<0,01) e<br>para -1,1 (DP=1,2) (p<0,05) após 24 meses de<br>tratamento.<br>**Pamidronato**aumentou de -3,2 (DP=1,3) para -<br>2,1 (DP=1,8) após 12 meses (p<0,05) e para -1,3<br>(DP=2,0) (p<0,01), após 24 meses de tratamento.|<br>⨁⨁◯◯<br>Baixa|IMPORTAN<br>TE|
|---|---|---|---|---|---|---|---|---|---|  
**DMO corporal total (seguimento: 2 anos; avaliado com: Z escore)**  
|1<br>(n=18)|ECR|Grave<br>a|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|Nos dois grupos foi observado aumento Z escore<br>da DMO corporal total.<br>**Alendronato**- no início do tratamento DMO<br>passou de -1,1 (DP=1,4) -0,5 (DP=1,5) (p<0,05)<br>em 12 meses, e aos 24 meses para -0,1 (DP=1,6)<br>(p<0,01).|<br> <br> <br> <br>⨁⨁◯◯<br>Baixa|IMPORTAN<br>TE|
|---|---|---|---|---|---|---|---|---|---|  
|||**C**|**onfiança nas ev**|**idências**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Alendro-**<br>**nato**|**Pamidro-**<br>**nato**|**Relativo**<br>**(IC 95%)**|**Absoluto**<br>**(95% IC)**|**Confiança**|**Importância**|
||||||||**Pamidron**<br>-1,8 (DP=1<br>meses,<br>j<br>(DP=1,9)(p|**ato**- início do<br>,3) para -1,4<br>á<br>em<br>2<br><0,05).|tratamento<br>(DP=1,5) (p<br>4<br>meses|a DMO foi de<br><0,05) aos 12<br>para<br>-0,9|||  
**Fratura (seguimento: 2 anos; avaliado com: Ocorrência/ Taxa anual)**  
|1<br>(n=18)<br>ECR|Grave<br>a|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|**Alendronato**a taxa anual de fratura antes do<br>tratamento foi de 1,7 (DP=1,1). Durante o<br>tratamento a taxa foi de 1,4 (DP=1,5).<br>**Pamidronato**a taxa anual de fratura foi de 2,1<br>(DP=1,7) e durante o tratamento foi de 0,9<br>(DP=0,9).<br>Sem diferenças significativas entre os grupos.<br>Redução na fratura geral foi 1,9 (DP=1,4) para<br>1,1(DP=1,2); (p < 0,05).|<br> <br> <br> <br> <br> <br>⨁⨁◯◯<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
Explicações:  
a. Viés decorrente do processo de randomização e devido a desvios de intervenção intencional (ausência de cegamento).  
b. Desfecho foi avaliado por único estudo com pequeno tamanho amostral

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
**Recomendação:** Recomendamos o uso de bisfosfonato oral alendronato para pacientes maiores de 18 anos com OI quando não houver intolerância ou contraindicação clínica ao seu uso (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes com osteogênese imperfeita de todos os tipos, **maiores** de 18 anos. **Intervenção:** Alendronato.  
**Comparador:** Pamidronato dissódico.  
**Desfechos:** DMO, Fratura, Dor e Eventos Adversos.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
Foi mantida a mesma estratégia de busca para todas as questões relacionadas com o uso de bisfosfonatos ( **Quadro E** ). Após a exclusão dos estudos duplicados, foi realizada a triagem, por pares de revisores, por meio do aplicativo Rayyan QCRI ( _Inteligent Sistematic Review_ ). O terceiro revisor atuou na resolução dos conflitos e divergências. Foram incluídas revisões sistemáticas de ECR com ou sem meta-análise, ECR e estudos comparativos não randomizados. Não houve restrições para idiomas.  
Utilizando os mesmos resultados das estratégias de buscas realizadas para as questões relacionadas com bisfosfonatos, 152 estudos foram removidos por duplicidade, restando 558 estudos para serem avaliados em relação ao título e resumo por dois revisores. Destes, 552 foram excluídos, totalizando 6 para serem avaliados segundo os critérios de elegibilidade. Foram excluídos 4 estudos por não terem o texto completo identificado e selecionados 2 artigos com população maior de 18 anos. As divergências entre a dupla de revisores também foram analisadas pelo terceiro revisor e resolvidas por meio de consenso e discussão. Após análise, um estudo foi excluído por desenho metodológico, restando um estudo observacional comparativo, como demonstra a **Figura 5** .

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
Shapiro e colaboradores<sup>6</sup> avaliaram o uso dos bisfosfonato endovenoso pamidronato comparado ao uso dos bisfosfonatos orais alendronato/risedronato em pacientes adultos com OI. Os desfechos analisados no estudo foram DMO da coluna e quadril, além da incidência de fratura por meio da comparação de coortes retrospectivas. Foram incluídos 90 pacientes divididos nos grupos: pamidronato intravenoso (n=28), alendronato oral (n=10), risedronato oral (n=17) e não tratados (n=35). Os pacientes não haviam recebido tratamento com bisfosfonatos anteriormente. A frequência de fraturas pós-púberes e uma pontuação básica do DXA por meio do escore Z ou pontuação T na coluna lombar ou quadril total de -1,5 ou inferior (com o fator de risco adicional de OI) foram os critérios para iniciar tratamento, conforme recomendado pela Associação Americana de Endocrinologia. A dose intravenosa de pamidronato foi de 1,5 mg/kg de peso corporal até um máximo de 60 mg/infusão, administrada como dose única durante 4 horas em solução salina a cada 4 meses. A dose de 70 mg de alendronato ou 35 mg de risedronato foi administrada semanalmente, de acordo com as instruções do fabricante. A dieta foi suplementada com 800 a 1.200 mg de cálcio/dia e com 400 UI de vitamina D/dia.  
No **Quadro O** estão descritas as principais características do estudo incluído na revisão sistemática na comparação pamidronato versus alendronato.  
**Quadro M -** Principais características do estudo Shapiro et al (2010) sobre a comparação entre pamidronato e bisfosfonatos orais para pacientes com OI maiores de 18 anos.  
|**Estudo/**<br>**Desenho**|**Características da população**|**Intervenção e**<br>**Comparador**|**Desfechos mensurados**|
|---|---|---|---|
|**Shapiro et al.**<br>**(2010)**<sup>6</sup>|Pacientes (n=90)<br>**Pamidronato**- média 42,2 anos|**Pamidronato**<br>**intravenoso (n = 28)**|**Densidade mineral óssea**–<br>mensurada por DXA em 3 sítios de<br>análise: L1 – L4, quadril total e colo|
|Coorte<br>retrospectiva|(DP=12,1) e 67,9% eram<br>homens, 17 com OI tipo I e 11<br>dos tipos III/IV<br>**Alendronato –**média 35,1 anos<br>(DP=9,9) e 50% eram homens, 7<br>com OI tipo I e 3 dos tipos III/IV|**Alendronato oral**<br>**(n = 10)**<br>Risedronato oral (n =<br>17)<br>Não tratados (n = 35)|do fêmur<br>**Fratura**- incidência de fratura 5<br>anos antes do tratamento inicial com<br>bisfosfonatos e 5 anos após início do<br>tratamento.|
||Risedronato - média 40 anos<br>(DP=9,1) e 82,4% eram homens,<br>13 com OI tipo I e 4 dos tipos<br>III/IV<br>3 a 161 meses|||  
A incidência de fratura foi determinada por períodos de 5 anos antes e após o início do tratamento com bisfosfonatos. Os resultados foram coletados dos relatórios ortopédicos presentes nos prontuários dos pacientes e dos exames de imagem raios-X e DXA. Apenas os resultados dos exames realizados no aparelho Hologic 4500 foram relatados, considerando como locais de escaneamento para análise: L1 – L4, quadril total e colo do fêmur. Foram comparadas as taxas anuais de mudança de DMO entre os grupos de tratamento em relação aos resultados iniciais dos exames de DXA, ajustando para sexo e idade.  
Para pacientes com OI tipo I, o tratamento com pamidronato mostrou uma taxa anual marginal, porém estatisticamente significativa, de mudança na DMO da coluna lombar L1-L4 desde o início do tratamento de 0,006 gm/cm<sup>2</sup> /ano (IC 95% 0,008 a 0,012; p=0,03) e da DMO no quadril total 0,005 gm/cm<sup>2</sup> /ano (IC 95% -0,003 a 0,013; p=0,2]), não estatisticamente significativa.  
O tratamento com bisfosfonatos orais (alendronato e risedronato) também mostrou uma taxa anual marginal e estatisticamente significativa de aumento na DMO da coluna lombar L1 – L4 de 0,004 gm/cm<sup>2</sup> /ano (IC 95% 0,0006 a 0,008; p=0,047). O aumento estatisticamente significativo também ocorreu na taxa anual da DMO total do quadril com 0,006 gm/cm<sup>2</sup> /ano (IC 95% 0,002 a 0,011; p= 0,003). A DMO do colo femoral não apresentou mudanças significativas no grupo do pamidronato com resultado de 0,001 gm/cm²/ano (IC 95% -0,008 a 0,008; p=0,98) como também no grupo dos bisfosfonatos orais com resultado de -0,009 gm/cm²/ano (IC 95% -0,007 a 0,005; p=0,8). No grupo não tratado de pacientes tipo I, não houve mudança significativa na DMO da coluna lombar de L1 – L4 (-0,002 gm/cm<sup>2</sup> /ano; IC 95% -0.009 a 0,006; p=0,6) como também na DMO no quadril total (-0,005 gm/cm<sup>2</sup> /ano; IC 95% -0,012 a 0,003; p=0,2).  
Para o grupo de pacientes com OI dos tipos III e IV, o tratamento com pamidronato mostrou uma taxa anual crescente de mudança na DMO da coluna lombar L1-L4 de 0,016 gm/cm<sup>2</sup> /ano (IC 95% 0,008 a 0,023; p<0,001) e para DMO no quadril total de 0,011 gm/cm<sup>2</sup> /ano (IC 95% 0,0002 a 0,02; p=0,046). Os bisfosfonatos orais não demonstraram resultados significativos na  
DMO L1 – L4 (0,003 gm/cm<sup>2</sup> /ano; IC 95% -0,006 a 0,012; p=0,5) como também para a DMO total do quadril (0,003 gm/cm<sup>2</sup> /ano; IC 95% -0,014 a 0,02; p=0,8). A DMO do colo femoral não apresentou mudanças significativas no grupo do pamidronato com resultado de -0,005 gm/cm<sup>2</sup> /ano (IC 95% -0,017 a 0,01; p=0,4) como também no grupo dos bisfosfonatos orais com resultado de 0,003 gm/cm<sup>2</sup> /ano (IC 95% -0,013 a 0,019; p=0,7). No grupo não tratado, não ocorreram mudanças significativas na DMO da coluna lombar de L1 – L4 com 0,0045 gm/cm<sup>2</sup> /ano (IC 95% -0,01 a 0,02; p=0,6) como também na DMO do quadril com 0,009 gm/cm<sup>2</sup> /ano (IC 95% -0,04 a 0,06; p=0,7) e na DMO do colo femoral com 0,009 gm/cm<sup>2</sup> /ano (IC 95% -0,054 a 0,07; p=0,8).  Ao comparar os resultados do tratamento dos bisfosfonatos orais (alendronato e risedronato) versus pamidronato para o aumento na taxa da DMO da coluna lombar (L1-L4), tanto para os pacientes com OI do tipo I (-0,002 gm/cm<sup>2</sup> /ano; IC 95% -0,009 a 0,004; p=0,49) quanto para os dos tipos III e IV (-0,013 gm/cm<sup>2</sup> /ano; IC 95% -0,024 a -0,001; p=0,03), não houve diferença significativa entre os resultados. O mesmo ocorreu nos resultados da DMO total do quadril para os pacientes com OI do tipo I e dos tipos III e IV com 0,001 gm/cm<sup>2</sup> /ano (IC 95% -0,007 a 0,01; p= 0,74) e -0,009 gm/cm<sup>2</sup> /ano (IC 95% -0,029 a 0,012; p= 0,41). Foi mensurada a variação percentual na DMO L1-L4 para pacientes do tipo I e tipo III e IV por tipo de tratamento. Os pacientes do tipo III e IV tratados com pamidronato tiveram uma mudança média de 15,9% (mediana de 7,2%) na DMO L1-L4 ao longo de um período de tratamento de 31 meses, enquanto os pacientes com OI do tipo I apresentaram uma variação média (mediana) de 4,3% (3,6%). No entanto, a resposta média dos pacientes com OI tipo III e IV ao bisfosfonato oral foi maior (6,2%) em comparação com os pacientes com OI do tipo I (3,1%).  
Em relação a fraturas, para pacientes com OI do tipo I o tratamento com pamidronato resultou em razão de fratura entre os períodos pré e pós-tratamento de 1,67 (IC 95% 0,78 a 3,58 [p=0,19]), porém, não estatisticamente significativa. O tratamento com bisfosfonatos orais (alendronato e risedronato) mostrou razão de fratura entre os períodos pré e pós-tratamento de 1,44 (IC 95% 0,69 a 3,02; p=0,33), não estatisticamente significativa. Pacientes não tratados com bisfosfonatos apresentaram, nos 5 anos anteriores ao tratamento, razão de fratura de 0,65 (IC 95% 0,35 a 1,21; p=0,18), porém, uma redução não estatisticamente significativa.  
Para os pacientes com OI do tipo III ou IV o tratamento com pamidronato resultou em razão de fratura entre os períodos pré e pós-tratamento de 0,42 (IC 95% 0,18 a 0,999; p=0,05) indicando uma redução estatisticamente significativa. Já o tratamento com bisfosfonatos orais (alendronato e risedronato) mostrou uma razão de fratura entre os períodos pré e pós-tratamento de 0,79 (IC 95% 0,26 a 2,39; p=0,67), não estatisticamente significativa. Os pacientes não tratados com bisfosfonatos apresentaram razão de fratura com redução não significativa 0,48 (IC 95% 0,14 a 1,70; p=0,26). Ao comparar o tratamento dos bisfosfonatos orais (alendronato e risedronato) versus pamidronato para os pacientes com OI do tipo I e para os dos tipos III ou IV, a razão de fratura foi de 0,86 (IC 95% 0,30 a 2,49 [p=0,79]) e de 1,83 (IC 95% 0,45 a 7,39; p=0,40), respectivamente. Ambas não são estatisticamente significativas. Assim, pacientes com o tipo I de OI não apresentaram redução significativa de fratura com nenhum bisfosfonato (oral ou intravenoso). A razão de fratura pré e pós-tratamento também não teve redução significativa em pacientes dos tipos III ou IV após tratamento com bisfosfonato oral, tendo o pamidronato apresentado resultado mais significativo para estes pacientes. Segundo os dados da evidência, ainda se faz necessário avaliar se o tratamento com bisfosfonatos é apropriado para todos os pacientes com OI maiores de 18 anos.  
Shapiro e colaboradores<sup>6</sup> ressaltaram que a proporção de fraturas pós ou pré-tratamento diminuiu, mas não de forma significativa, em todos os grupos, incluindo o grupo sem tratamento, exceto para pacientes com OI do tipo I com tratamento com pamidronato ou bisfosfonato oral, nos quais a proporção aumentou ligeiramente. Os autores ressaltaram que a diminuição do risco de fratura pode estar relacionada com a inclusão do paciente em um programa clínico estruturado que incentiva, entre outras coisas, a melhora da ingestão de vitamina D e cálcio.  
O estudo possui limitações relacionadas ao desenho observacional não randomizado, a natureza retrospectiva dos dados, cuja qualidade das informações coletadas é desconhecida. Além disso, embora o estudo tenha relatado vários anos de acompanhamento, a pequena amostra de pacientes introduziu outras limitações, como fusão de grupos de OI (III ou IV) para  
análise. Foi possível observar desequilíbrios das características da linha de base, sendo que a maioria dos pacientes tinha OI tipo I, de menor gravidade. Outras limitações a serem consideradas são: a seleção do paciente com base nos resultados de gravidade e DXA; a apresentação de resultados agrupados para alendronato e risedronato, o que pode influenciar no efeito individual dos medicamentos.  
A avaliação da qualidade metodológica do estudo Shapiro e colaboradores (2010) foi realizada por meio da ferramenta ROBINS I. A qualidade global do estudo para os desfechos de DMO e incidência de fratura foi crítica, sendo penalizados os domínios de viés devido ao confundimento, estudo observacional retrospectivo sem ajuste para potenciais fatores de confundimento e viés na seleção dos participantes, uma vez que os participantes foram selecionados com base na gravidade e resultados de DXA ( **Figura 9** ).  
**Figura 9 -** Avaliação do risco de viés do estudo de Shapiro et al. (2010) para os desfechos de DMO e incidência de fratura segundo a ferramenta ROBINS I.  
<!-- Start of picture text -->
Dominios avaliados: Julgamentos:<br>D1: Viés devido ao confundimento<br>D2: Viés na seleco dos participantes<br>D3: Viés na classificagdo das intervengdes @o Critico<br>D4:DS: ViésViés por por dados desvio faltantes das intervengSes pretendidas 2) Ban:|<br>D6: Viés na mensuracdo dos desfechos<br>7: Viés na seleco dos resultados relatados<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
O alendronato já está disponível no SUS e já era recomendado no PCDT de OI publicado por meio da Portaria SAS/MS nº 1.306, de 22 de novembro de 2013.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
Para o uso de alendronato, o paciente deve ser maior de 18 anos, possuir diagnóstico de fenótipos moderados a graves (tipos III ou IV); ter sofrido, pelo menos, 2 fraturas por ano, fraturas de vértebras ou deformidade óssea, com comprovação radiológica; apresentar alterações no metabolismo do cálcio e ser capaz de manter o ortostatismo após a administração do medicamento.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
A **Tabela F** apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos DMO da coluna lombar, DMO do quadril e fratura.  
**Tabela F -** Avaliação da certeza da evidência segundo sistema GRADE para alendronato versus pamidronato no tratamento OI em pacientes maiores de 18 anos  
|||**C**|**onfiança na evid**|**ência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
|1<br>(n=55)|Estudo<br>observacional|Grave<sup>a</sup>|Não grave|Grave<sup>b</sup>|Grave<sup>c</sup>|Nenhum|**Alendronato**<br>**oral**<br>**(n**<br>**=**<br>**10)**<br>**e**<br>**Risedronato oral (n = 17):**<br>**OI tipo I:**taxa anual de aumento na<br>**DMO da coluna lombar**L1 – L4 de<br>0,004gm/cm<sup>2</sup>/ano(IC 95% 0,0006 a<br>0,008; p=0,047) e taxa anual da**DMO**<br>**total do quadril**com 0,006gm/cm<sup>2</sup>/ano<br>(IC 95% 0,002 a 0,011; p= 0,003),**ambas**<br>**estatisticamente significativas.**<br>**OI tipo III/IV:** **não demonstraram**<br>**resultados significativos**na**DMO de**<br>**coluna lomba**r L1 – L4 com 0,003 gm<br>/cm2/ano (IC 95% -0,006 a 0,012;<br>p=0,5]) e na**DMO total do quadril**<br>0,003gm /cm2/ano (IC 95% -0,014 a<br>0,02; p=0,8).<br>**Pamidronato intravenoso (n = 28)**|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>⨁◯◯◯<br>Muito<br>Baixa|IMPORTAN<br>TE|
|---|---|---|---|---|---|---|---|---|---|  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|<br>**Risco de**<br>**viés**|**Confiança na evid**<br>**Inconsistência**|**ência**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
||||||||**OI tipo I:**taxa anual de aumento na<br>**DMO da coluna lombar**L1-L4 de 0,006<br>gm/cm<sup>2</sup>/ano(IC 95% 0,008 a 0,012;<br>p=0,03) estatisticamente**significativa**e<br>taxa anual de aumento da**DMO no**<br>**quadril**total 0,005gm/cm2/ano (IC 95%<br>-0,003 a 0,013;p=0,2)**não significativa.**<br>**OI tipo III/IV:**aumento crescente na<br>taxa**da DMO da coluna lombar**(L1-<br>L4) de 0,016gm/cm<sup>2</sup>/ano(IC 95% 0,008<br>a 0,023; p<0,001) e taxa de aumento da<br>**DMO**<br>**no**<br>**quadril**<br>total<br>0,011<br>gm/cm2/ano (IC 95% 0,0002 a 0,02;<br>p=0,046),<br>ambas<br>**estatisticamente**<br>**significativas**<br>Não houve diferença estatisticamente<br>significativa entre os resultados dos<br>bisfosfonatos orais e intravenoso para<br>DMO em nenhum dos sítios avaliados.|||  
||||**Confiança na evid**|**ência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
|1<br>(n=55)|Estudo<br>observacional|Grave<sup>a</sup>|Não grave|Grave<sup>b</sup>|Grave<sup>c</sup>|Nenhum|**Alendronato**<br>**oral**<br>**(n**<br>**=**<br>**10)**<br>**e**<br>**Risedronato oral (n = 17):**<br>**Para pacientes OI tipo I:**razão de<br>fratura pré e pós tratamento de 1,44 (IC<br>95% 0,69 a 3,02; p=0,33) aumento da<br>incidência<br>não<br>estatisticamente<br>significativa<br>**Pamidronato intravenoso (n = 28)**<br>**Para pacientes OI tipo I**: razão de<br>fratura pré e pós-tratamento de 1,67 (IC<br>95% 0,78 a 3,58; p=0,19) aumento da<br>incidência<br>não<br>estatisticamente<br>significativa.<br>**Para os pacientes OI tipos III/IV:**razão<br>de fratura pré e pós tratamento de 0,42<br>(IC 95% 0,18 a 0,999; p=0,05) redução da<br>incidência estatisticamente significativa.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>⨁◯◯◯<br>Muito<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|  
||||**Confiança na evid**|**ência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Confiança**|**Importância**|
||||||||**Para os pacientes OI tipos III/IV:**razão<br>de fratura pré e pós tratamento de 0,79<br>(IC  95% 0,26 a 2,39; p=0,67), redução da<br>incidência<br>não<br>estatisticamente<br>significativa.<br>O tratamento com bisfosfonatos orais não<br>foi associado a uma diminuição na taxa<br>de incidência de fratura pré e pós-<br>tratamento tanto nos pacientes tipo I<br>quanto tipos III/IV. O pamidronato<br>apresentou resultado significativo para<br>redução de fratura nos tipos III/IV.|||  
IC: intervalo de confiança; OI, Osteogênese Imperfeita  
a. Conforme avaliação do risco de viés feita por meio da ferramenta ROBINS I, a evidência foi penalizada no domínio D1 por presença de viés de confusão e domínio D2 devido a presença de viés de seleção (seleção de pacientes de acordo com o resultado do DXA).  
b. No estudo o pamidronato foi administrado em dose única a cada 3-4 meses, diferente da posologia adotada no Brasil.  
c. Desfecho avaliado por único estudo com pequeno tamanho amostral.  
d. No estudo o pamidronato foi comparado com o alendronato e risedronato

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
**Recomendação:** Por não haver indicação aprovada para o uso de ácido zoledrônico em pacientes com OI menores de 18 anos, este medicamento não é preconizado neste Protocolo. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes menores de 18 anos com osteogênese imperfeita.  
**Intervenção:** Ácido zoledrônico.  
**Comparador:** Pamidronato.  
**Desfechos:** Densitometria Mineral Óssea (DMO), fraturas e eventos adversos.  
A seleção dos estudos foi realizada por meio da leitura de títulos e resumos utilizando o software Rayyan QCRI ( _Inteligent Systematic Review_ ), com posterior leitura de texto completo. As duas etapas foram desempenhadas por dois revisores independentes. Na presença de discordâncias, um terceiro revisor participou na resolução dos conflitos. Foram incluídas revisões sistemáticas de ECR com ou sem meta-análise, ECR e estudos comparativos não randomizados. Não houve restrições para idiomas.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
Foram identificados 710 estudos nas bases de dados. Após excluir 152 duplicatas, 85 estudos foram selecionados por título e resumos, dos quais não foi possível localizar texto completo para 11, por serem resumos de conferências ou anais de congresso. Após a leitura do texto completo, 8 foram excluídos por não contemplarem os elementos da pergunta de pesquisa quanto à população e à intervenção. Outros 65 estudos foram excluídos por serem observacionais. Um estudo foi identificado na busca por referências e citações, de modo que foram incluídos para esta revisão sistemática dois ensaios clínicos controlados<sup>8,9</sup> . A **Figura 10** apresenta de forma esquemática o fluxograma para inclusão de estudos nesta revisão.  
**Figura 10 -** Fluxograma dos estudos incluídos sobre o uso de ácido zoledrônico versus pamidronato em pacientes com OI menores de 18 anos.  
<!-- Start of picture text -->
EMBASE (n=383) (n=152) Busca de citagdes (n =1)<br>Cochrane (n=58)<br>| Referéncias incluidas para<br>feo(res5e) Excluidas (n=473)<br>Tames oc<br>Outras intervengdes (n=6)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
Um ECR conduzido no Brasil comparou o uso do ácido zoledrônico versus o pamidronato em 23 pacientes menores de 18 anos com diagnóstico clínico de OI associada à presença de, pelo menos, uma fratura por trauma mínimo no último ano antes da randomização. Foram alocadas aleatoriamente 11 crianças no grupo do pamidronato e 12 crianças no grupo do ácido  
zoledrônico. Neste estudo, o grupo pamidronato recebeu 1 mg/kg/dia do medicamento por 2 dias consecutivos a cada 3 meses para crianças menores de 3 anos e a cada 4 meses para crianças maiores de 3 anos. No grupo do ácido zoledrônico, crianças menores de 3 anos receberam a dose de 0,025 mg/kg/dia por 2 dias consecutivos, a cada 3 meses, enquanto crianças maiores de 3 anos receberam a dose de 0,05 mg/kg por 2 dias consecutivos, a cada 4 meses. Nenhuma criança tinha sido submetida a tratamento anterior com bisfosfonatos e todas receberam suplementação diária de cálcio e vitamina D em doses adequadas à idade. Antes do início do tratamento e de cada infusão, foram coletadas amostras de sangue em jejum para determinar os níveis de marcadores do metabolismo ósseo como cálcio, fósforo, hormônio da paratireoide (PTH) e marcadores de remodelação óssea. Foram coletadas medidas antropométricas de peso e altura, convertidas para o escore Z específico para idade e sexo, com uso de um _software_ apropriado. A densidade mineral óssea foi mensurada por meio do raio X de dupla energia ( _Dual energy X- Ray Absorptiometry_ - DXA).  
O desfecho primário do estudo consistiu na avaliação da média da DMO da coluna lombar medida em g/cm<sup>2</sup> por meio do DXA realizada para compor a linha de base e após a quarta ou quinta infusão de qualquer uma das intervenções. O exame foi realizado na coluna lombar anteroposterior (vértebras lombares L1 -L4) e corpo total. Também foi mensurado o conteúdo mineral ósseo (CMO em g) e calculado o Z escore da coluna lombar. A segunda densitometria foi realizada em até 30 dias após a última infusão dos bisfosfonatos. Os resultados demonstraram um aumento na média da DMO da coluna lombar de 51,8% (p = 0,053) no grupo do pamidronato e de 67,6% (p = 0,003) no grupo do ácido zoledrônico. Também houve melhora do Z escore nos grupos que receberam pamidronato e ácido zoledrônico, com pontuações de - 5,3 a - 3,8 (p = 0,032) e - 4,8 a - 2,3 (p = 0,007), respectivamente. Ao final do tratamento, o Z escore da coluna lombar foi maior nos pacientes que receberam ácido zoledrônico, entretanto a significância estatística foi limítrofe (p = 0,053).  
Considerados desfechos secundários, a taxa anual de fratura nos pacientes foi medida em ambos os grupos, assim como a incidência antes e depois do tratamento. Todo tipo de evento adverso foi relatado e mensurado.  
<u>Elekwachi e Lubas (2008)</u><sup>9</sup>  
Um ECR, multicêntrico, aberto, de não inferioridade, comparou a eficácia e a segurança do uso do ácido zoledrônico com as do uso do pamidronato em pacientes com OI grave e idade entre 1 e 17 anos. Um terço dos pacientes tinha idade entre 1 e 8 anos, sendo todos acompanhados durante um ano. Foram incluídos pacientes com OI tipos III e IV e pacientes com OI tipo I, desde que apresentassem, pelo menos, 3 fraturas por traumas mínimos nos últimos dois anos ou história de deformidade com necessidade de intervenção cirúrgica. Os desfechos avaliados foram mudança no percentual de DMO da coluna lombar em 12 meses e número de fraturas clínicas ao longo de um ano. Foram randomizados 155 pacientes, dos quais 152 contribuíram para a análise de segurança (74 no grupo ácido zoledrônico e 78 no grupo pamidronato) e 131, para análise de eficácia primária das tecnologias na análise por intenção de tratar (ITT) (63 pacientes no grupo ácido zoledrônico e 68 no grupo pamidronato).  
O grupo que fez uso do ácido zoledrônico foi composto por crianças com idade inferior a 3 anos que receberam dose de 0,025 mg/kg do medicamento, durante 30-45 minutos, a cada 3 meses; para os maiores de 3 anos foi administrado 0,05 mg/kg de ácido zoledrônico, por 30 minutos, a cada 3 meses. O grupo pamidronato incluiu crianças com idade inferior a 2 anos, que receberam 0,5 mg/kg/dia do medicamento durante 3 dias, com tempo de infusão superior a 4 horas a cada 2 meses; crianças com idade entre 2 e 3 anos, que receberam 0,75 mg/kg/dia de pamidronato durante 3 dias, com infusão superior a 4 horas a cada 3 meses e pacientes com idade entre 3 e 17 anos, que receberam dose de 1,0 mg/kg/dia a cada 3 dias com tempo de infusão maior que 4 horas, a cada 3 meses.  
Os principais resultados obtidos pelos estudos de Barros et al. (2012)<sup>8</sup> e de Elekwachi e Lubas (2008)<sup>9</sup> encontram-se no **Quadro N** .  
**Quadro N** - Resumo dos principais resultados dos estudos considerados na questão 6.  
|**Estudo**|**Principais Resultados**|
|---|---|
|**Barros et al.**<br>**(2012)**<sup>8</sup>|**DMO**<br>Aumento na média da DMO da coluna lombar de 51,8% (p = 0,053) no grupo do pamidronato e de 67,6%<br>(p = 0,003) no grupo do ácido zoledrônico. Melhora do Z escore nos grupos que receberam pamidronato<br>[- 5,3 a - 3,8 (p = 0,032)] e ácido zoledrônico [- 4,8 a - 2,3 (p = 0,007)].<br>**Taxa de fraturas**<br>Ambos os grupos apresentaram diminuição da taxa de fraturas (pamidronato p = 0,025 e ácido<br>zoledrônico p = 0,048).<br>**Eventos adversos (EA)**<br>Foram leves e semelhantes entre os grupos, tendo ocorrido apenas na primeira infusão. O EA mais<br>frequente foi febre (38 ° C - 39 ° C), ocorrendo em todos os pacientes do estudo, seguido de vômitos,<br>náusea, mialgia, epigastralgia e erupção cutânea.|
|**Elekwachi**<br>**e**<br>**Lubas (2008)**<sup>9</sup>|**DMO**<br>Percentual de mudança da DMO da linha de base e aos 12 meses após tratamento foi maior no grupo do<br>ácido zoledrônico (46%) em comparação com o pamidronato (41%) em um ano de tratamento.<br>**Fratura**<br>Não houve diferença no número total de pacientes com fraturas: 32 (43%) no grupo ácido zoledrônico<br>versus 31 (41%) no grupo pamidronato. Também não houve diferença entre os grupos no tempo até a<br>primeira fratura clínica (curva de Kaplan-Meier). Houve numericamente mais pacientes OI Tipo I com<br>fraturas no grupo ácido zoledrônico (n=19; 50%) em comparação com 10 (29%) no grupo pamidronato<br>(Hazard ratio 2,1, p = 0,09, não estatisticamente significativo) e mais pacientes com OI Tipo III e IV<br>combinado com fraturas no grupo pamidronato (n=21; 51%) em comparação com 13 (36%) no grupo<br>ácido zoledrônico (Hazard ratio 1,7, p=0,25, também não estatisticamente significativo).<br>**Eventos adversos**<br>**Eventos adversos comuns (>10%):**com ácido zoledrônico 71/74(95,9%) versus 76/78(97,4%) com<br>pamidronato. Entre os eventos mais comuns relatados temos pirexia, dor nas extremidades, vômitos, dor<br>de cabeça, nasofaringe e náusea.<br>**Eventos adversos graves**(fratura de fêmur, úmero ou crânio; hipocalcemia; pirexia): mais frequentes<br>no grupo ácido zoledrônico (24/74=32%) em comparação ao grupo pamidronato (15/78=19%),<br>especialmente devido a taxas mais altas de fratura de fêmur e hipocalcemia no grupo ácido zoledrônico.|  
Quanto às questões de segurança, no estudo de Elekwachi e Lubas (2008)<sup>9,</sup> o Comitê de Monitoramento de Dados recomendou a interrupção do tratamento dos pacientes com OI tipo I, independentemente do grupo de tratamento do estudo, uma vez que foi observado um aumento da incidência de fratura femoral nesses pacientes durante o período de avaliação. Portanto, nenhum paciente com OI tipo I foi tratado depois de 13 de dezembro de 2006. O estudo foi concluído em 9 de maio de 2007.  
Em relação à avaliação da qualidade metodológica, no estudo de Barros et al (2012)<sup>8</sup> , não houve descrição do processo de randomização, tampouco garantia de que o sigilo da alocação foi mantido. Embora o estudo tenha sido randomizado, observou-se a presença de desequilíbrio em algumas características demográficas, como o estado puberal e idade média dos participantes. O tamanho amostral do estudo foi pequeno, não tendo poder para detectar diferenças estatísticas significativas. Assim, foi realizada avaliação do risco de viés, por meio da ferramenta RoB2 ( _Risk Of Bias_ ), resultando em alto risco de viés global para os desfechos de DMO e fratura, sendo penalizados como alto risco os seguintes domínios: processo de randomização, desvios das intervenções pretendidas, dados de resultados perdidos; e como risco moderado para o desfecho de eficácia o domínio da seleção do resultado relatado, considerando a análise por intenção de tratar.  
Já no estudo de Elekwachi e Lubas (2008)<sup>9</sup> , o processo de randomização também não foi descrito, não houve cegamento dos pacientes, aproximadamente 50% das crianças incluídas no estudo tinham OI do tipo I (menos grave). Além disso, foi possível observar desequilíbrios das características demográficas na linha de base entre os grupos, com a maior porcentagem de casos com os tipos mais graves de OI no grupo do pamidronato. Ao ser avaliado por meio da ferramenta RoB2 para os desfechos de DMO e fraturas, o estudo foi penalizado nos domínios do processo de randomização, desvios das intervenções pretendida; e como risco moderado a seleção dos resultados relatados, tendo avaliação global de alto risco, considerando a análise por intenção de tratar ( **Figura 11** ).  
**Figura 11 -** Avaliação do risco de viés do estudo de Barros et al (2012)<sup>8</sup> e Elekwachi e Lubas (2008)<sup>9</sup> para os desfechos DMO e fratura (avaliação de eficácia - ITT).  
<!-- Start of picture text -->
@<br>‘tm<br><!-- End of picture text -->  
D1: Viés devido ao processo de randomização; D2: Viés devido aos desvios da intervenção pretendida; D3: Viés devido a dados perdidos; D4: Viés na mensuração do desfecho; D5: Viés na seleção dos resultados relatados.  
Para avaliação de segurança, foi considerada a análise por protocolo, sendo ambos os estudos avaliados como alto risco de viés global, com alta penalização no estudo de Barros et al (2012)<sup>8</sup> nos seguintes domínios: processo de randomização, desvios das intervenções pretendidas, dados de resultados perdidos; e como moderada no domínio de seleção dos resultados relatados. Já o estudo de Elekwachi e Lubas (2008)<sup>9</sup> teve alto risco de viés global, sendo penalizados apenas com risco moderado os domínios do processo de randomização, desvios das intervenções pretendidas e seleção dos resultados relatados ( **Figura 12** ).  
**Figura 12 -** Avaliação do risco de viés do estudo de Barros et al (2012)<sup>8</sup> e Elekwachi e Lubas (2008)<sup>9</sup> para eventos adversos (análise de segurança - análise por protocolo).  
<!-- Start of picture text -->
ats© @ © oe@ © @<br><!-- End of picture text -->  
D1: Viés devido ao processo de randomização; D2: Viés devido aos desvios da intervenção pretendida; D3: Viés devido a dados perdidos; D4: Viés na mensuração do desfecho; D5: Viés na seleção dos resultados relatados.  
Devido à elevada heterogeneidade dos estudos quanto à idade, estágio puberal, fenótipo da OI e posologia das terapias não foi possível realizar meta-análise.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **para pacientes com OI maiores de 18 anos?** -->
<mark>A viabilidade de implementação da tecnologia pode ser considerada como um aspecto favorável para o uso do ácido zoledrônico, uma vez que ele tem uma posologia mais confortável e não há necessidade de internação hospitalar para seu uso, o que traz impacto em redução de custos. Entretanto, a evidência disponível é frágil para justificar o seu uso no cenário de crianças e adolescentes com OI, uma vez que a confiança nas evidências é muito baixa como apresentada na tabela GRADE abaixo.</mark>  
**<mark>Perfil de evidências:</mark>**  
<mark>A</mark> **<mark>Tabela G</mark>** <mark>apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos: DMO da coluna</mark>  
<mark>lombar, fraturas e eventos adversos.</mark>  
**Tabela G** - Certeza da evidência segundo sistema GRADE para ácido zoledrônico comparado a pamidronato, no tratamento de osteogênese imperfeita em pacientes menores de 18 anos  
|**Ava**<br>**№**<br>**dos**<br>**estudos**<br>**Densidade**|**liação da certez**<br>**Delineamento**<br>**do estudo**<br>**mineral óssea d**|**a da evidênci**<br>**Risco de**<br>**viés**<br>**e coluna lom**|**a**<br>**Inconsistênc**<br>**bar (seguime**<br>|**ia**<br>**Evidênci**<br>**a indireta**<br>**nto: média 1 an**|**Imprecisão**<br>**os)**|**Outras**<br>**considerações**|**Impacto**<br> <br>|**Certeza**<br>|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|2<br>(n=178)<br>**Fratura (**|ECR<br>**seguimento: mé**|Muito<br>grave<sup>a</sup><br>**dia 1 ano)**|Grave<sup>b</sup><br>|Não grave|Não grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Pamidronato**aumentou DMO**da<br>coluna lombar média em 51,8% (p<br>= 0,053)<br>Ácido<br>zoledrônico<br>**aumentou**<br>**DMO**da coluna lombar média<br>67,6% (p = 0,003).<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Ácido zoledrônico foi não inferior<br>ao<br>pamidronato<br>na<br>variação<br>percentual em relação ao baseline<br>na**DMO**da coluna lombar após 12<br>meses.<br>|⨁◯◯◯<br>Muito<br>baixa<br>|IMPORTANT<br>E<br>|
|2<br>(n=178)|ECR|Muito<br>grave<sup>a</sup>|Grave<sup>b</sup>|Não grave|Não grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Pamidronato:**tx de fratura**anual<br>no início do tratamento 3,24 ±<br>2,24.<br>No<br>final<br>do<br>período|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
|**Ava**|**liação da certeza**|**da evidênci**|**a**|||||||
|---|---|---|---|---|---|---|---|---|---|
||||||||**Imacto**|**Certeza**|**Imortância**|
|**№**<br>**dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsist**|**ência**<br>**Evidênci**<br>**a indireta**|**Imprecisão**|**Outras**<br>**considerações**|**p**||**p**|
||||||||diminuição na taxa de fratura (p =<br>0,025)<br>Ácido zoledrônico:**tx.de fratura**<br>anual no início do tratamento 3,73<br>± 4,01. No final do período<br>diminuição na taxa de fratura (p=<br>0,048)<br>Sem diferenças significativas entre<br>os grupos (p = 0,657).<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Pamidronato:**taxa de fratura**<br>anual reduziu em média -1,55 (±<br>2,08)<br>Ácido zoledrônico:**tx.de fratura**<br>anual reduziu em média -1,96 (±<br>3,84;       p= 0,4, sugerindo não<br>inferioridade.|<br>||
|**Eventos**|**adversos**|||||||||
|2<br>(n=152<br>)|ECR|Muit<br>grave<sup>a</sup>|Grave<br>b|Não grave|Não<br>grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Os<br>eventos<br>adversos<br>foram<br>observados na primeira infusão|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
|**Ava**|**liação da certeza**|**da evidênci**|**a**|||||||
|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidênci**<br>**a indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
||||||||em ambos os grupos.<br>Não houve diferença significativa<br>na predominância dos eventos<br>entre os grupos.<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Quatro pacientes, dois em cada<br>grupo, suspenderam o tratamento<br>por eventos adversos.|||  
Explicações:  
a. Barros et al. (2012): conduziram estudo com alto risco de viés devido a limitações no processo de randomização, desvios da intervenção pretendida, dados perdidos; enquanto o reporte de Elekwachi e Lubas (2008) apresentou alto risco de viés devido a limitações no processo de randomização, desvios da intervenção pretendida, dados perdidos e seleção de resultado reportado.  
b. Os estudos são heterogêneos quanto à idade, estágio puberal, fenótipo da osteogênese imperfeita e posologia das terapias.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
**Recomendação:** Por não haver indicação aprovada para o uso de ácido zoledrônico em pacientes adultos com OI, este medicamento não é preconizado neste Protocolo. No entanto, por se tratar de uma dúvida clínica, a síntese e a avaliação crítica das evidências desta tecnologia foram realizadas.  
Pergunta de pesquisa estruturada conforme estratégia PICO:  
**População:** Pacientes adultos (acima de 18 anos) com osteogênese imperfeita. **Intervenção:** Ácido zoledrônico. **Comparador:** Pamidronato dissódico.  
**Desfechos:** Fraturas, dor e densidade mineral óssea.  
**Métodos e resultados da busca**  
Foi mantida a mesma estratégia de busca para todas as questões relacionadas com o uso de bisfosfonatos descrita no **Quadro E** . Os estudos recuperados nas bases de dados pesquisadas foram exportados para o _software_ Rayyan, utilizado para identificação de duplicatas e processo cego de triagem por leitura de título e resumo executado por dois pesquisadores independentes. As divergências foram resolvidas por um terceiro pesquisador. Os estudos triados foram selecionados para leitura de texto completo por pares de revisores. Adicionalmente, foi realizada busca por registro de estudos na base _Clinical trials_ por meio dos termos “Osteogenesis imperfecta”. Foram incluídas revisões sistemáticas de ECR com ou sem meta-análise, ECR ou não, e estudos observacionais. Não houve restrições para idiomas.  
Na tentativa de recuperar estudos para responder a pergunta de pesquisa, uma nova busca mais específica foi realizada nas bases de dados PubMed, EMBASE (via PICO), Lilacs e Cochrane, sem restrição de idioma, tipo de estudo ou qualquer outro filtro. Foram assumidos os mesmos critérios de elegibilidade da busca inicial. O **Quadro O** apresenta a estratégia de busca adicional utilizada.  
**Quadro O -** Estratégia de busca adicional segundo base de dados pesquisada  
|**Bases de dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|Pubmed<br>16/12/2021|#1("Osteogenesis Imperfecta"[Mesh] OR "Brittle Bone Disease" or "Fragilitas<br>Ossium" or "Ossiums, Fragilitas" or "Lobstein's Disease" or "Disease, Lobstein's" or<br>"Lobsteins Disease"or "Disease, Lobstein")<br>#2 ("Zoledronic Acid"[Mesh]OR "Zoledronic Acid" OR Zometa OR "Zoledronic<br>Acid Anhydrous" OR "Zoledronate")<br>#1 AND #2|66|
|Embase<br>16/12/2021|#1 ('osteogenesis imperfecta'/exp OR 'bruck syndrome' OR 'brittle bone' OR<br>'fibrogenesis imperfecta ossium' OR 'idiopathic osteopsathyrosis' OR 'lobstein<br>disease' OR 'lobstein syndrome' OR 'osteogenesis imperfecta' OR 'osteopsathyrosis'<br>OR 'periostal aplasia')|330|
||#2 ('zoledronic acid'/exp OR '1 hydroxy 2 (1 imidazolyl) 1, 1 ethanebisphosphonic||  
|||**Número de**|
|---|---|---|
|**Bases de dados**|**Estratégia de busca**|**resultados**<br>**encontrados**|
||acid' OR '1 hydroxy 2 (1h imidazol 1 yl) ethylidenebisphosphonic acid' OR '1<br>hydroxy 2 (imidazol 1 yl) ethylidenebisphosphonic acid' OR 'aclasta' OR 'cgp<br>42446' OR 'cgp 42446a' OR 'cgp42446' OR 'cgp42446a' OR 'orazol' OR 'reclast' OR<br>'zol 446' OR 'zol446' OR 'zoledronate' OR 'zoledronate disodium' OR 'zoledronate<br>trisodium' OR 'zoledronic acid' OR 'zoledronic acid disodium salt hydrate' OR<br>'zoledronic acid hydrate' OR 'zoledronic acid monohydrate' OR 'zomera' OR<br>'zometa')||
||#1 AND #2||
|Cochrane<br>Library<br>16/12/2021|#1        MeSH descriptor: [Osteogenesis Imperfecta] explode all trees<br>#2        MeSH descriptor: [Zoledronic Acid] explode all trees<br>#3        #1 and # 2|37|
|LILACS<br>16/12/2021|( mh:("Zoledronic Acid")) AND "osteogenesis imperfecta"|39|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
Foram recuperados 767 títulos nas bases de dados: PubMed, EMBASE e Cochrane e 57 registros no _Clinical Trials._ Destes, 152 foram excluídos por duplicidade e 555 por leitura de título e resumo. Três estudos foram selecionados para leitura de texto completo. Entretanto, nenhum deles atendeu aos critérios de elegibilidade. O fluxograma de seleção de estudos é demonstrado na **Figura 13** .  
**Figura 13** - Fluxograma de seleção dos estudos sobre o uso de ácido zoledrônico versus pamidronato em pacientes com osteogênese imperfeita maiores de 18 anos.  
<!-- Start of picture text -->
Identificadas (N=767) Identificadas em  outras<br>Medline/Pubmed (n=269) fontes (n=0)<br>Cochrane (n=58) _<br>Clinical Trials (n=57)<br>(n=615)<br>Referéncias excluidas:<br>[Elegiveis (n=3) | SemNao comparadoravaliou a intervencdo(n=2) de interesse_<br>(n=1)<br>isto<br><!-- End of picture text -->  
A busca adicional resultou na recuperação de 472 títulos. Destes, 119 duplicatas foram retiradas. Dos 353 estudos triados  
por leitura de título e resumo, nenhum foi incluído para leitura de texto completo por não atenderem aos critérios de elegibilidade.  
A **Figura 14** ilustra o processo adicional de seleção de estudos.  
**Figura 14 -** Fluxograma de seleção dos estudos referentes à busca adicional sobre uso de ácido zoledrônico versus pamidronato em pacientes com osteogênese imperfeita maiores de 18 anos.  
<!-- Start of picture text -->
Identificadas (N=472) Identificadas em  outras<br>Medline/PubmedEas 0) (n=66) Depts;  emo, fontes (n=0)<br>Cochrane (n=37)<br>LILACS (n=39)<br>(n=353)an) [excuidas (n=353)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
Não foram encontrados estudos que respondessem à pergunta de pesquisa proposta nesta revisão. Entretanto, considerando que também foi realizada busca para avaliar o uso do ácido zoledrônico versus pamidronato em pacientes com OI <u>menores de 18 anos, decidiu-se por considerar o mesmo estudo como evidência indireta para população maior de 18 anos.</u>

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
O tratamento com ácido zoledrônico apresenta maior comodidade posológica em relação ao pamidronato, já que necessita de intervalos de infusão a cada seis meses, enquanto o pamidronato é utilizado com intervalos de dois a quatro meses. A administração de ácido zoledrônico não requer internação para infusão, ao contrário do que ocorre com uso de pamidronato. Entretanto, até o momento, não há evidências de eficácia e segurança na população com OI com idade superior a 18 anos que sustentem uma recomendação a favor de seu uso. Ademais, o ácido zoledrônico não possui indicação aprovada em bula para tratamento da OI.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
A **Tabela H** apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos DMO da coluna lombar, fraturas e eventos adversos com base nas evidências encontradas para responder à Questão 7.  
**Tabela H -** Avaliação da certeza da evidência segundo sistema GRADE no uso de ácido zoledrônico versus pamidronato no tratamento de OI em maiores de 18 anos  
|||**Avaliaç**|**ão da certeza da**|**evidência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|**Densidade**<br>2<br>(n=178)|**mineral óssea d**<br>Ensaios<br>clínicos<br>randomizado<br>s|**e coluna lom**<br>Muito<br>grave<sup>a</sup>|**bar (seguimento:**<br>Grave<sup>b</sup>|**média 1 ano**<br>Grave<sup>c</sup>|**s)**<br>Não grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Pamidronato**aumentou DMO**da<br>coluna lombar média em 51,8% (p =<br>0,053)<br>Ácido zoledrônico**aumentou DMO**<br>da coluna lombar média 67,6% (p =<br>0,003).<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Ácido zoledrônico não foi inferior ao<br>pamidronato na variação percentual<br>em relação ao baseline na**DMO**da<br>coluna lombar após 12 meses.|⨁◯◯◯<br>Muito<br>baixa|IMPORTA<br>NTE|
|**Fratura (s**|**eguimento: médi**|**a 1 ano)**||||||||
|2<br>(n=178)|Ensaios<br>clínicos<br>randomizado|Muito<br>grave<sup>a</sup>|Grave<sup>b</sup>|Grave<sup>c</sup>|Não grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Pamidronato:**taxa de fratura**anual|⨁◯◯◯<br>Muito<br>baixa|CRÍTICO|  
|||**Avaliaç**|**ão da certeza da**|**evidência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
||s||||||no início do tratamento 3,24 ± 2,24.<br>No final do período diminuição na<br>taxa de fratura (p = 0,025)<br>Ácido zoledrônico:**taxa de fratura**<br>anual no início do tratamento 3,73 ±<br>4,01. No final do período diminuição<br>na taxa de fratura (p= 0,048)<br>Sem diferenças significativas entre os<br>grupos (p = 0,657).<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Pamidronato:**taxa de fratura**anual<br>reduziu em média -1,55 (DP=2,08)<br>Ácido zoledrônico:**taxa de fratura**<br>anual reduziu em média -1,96<br>(DP=3,84)<br>p= 0,4, sugerindo não inferioridade.|||
|**Eventos a**|**dversos**|||||||||
|2<br>(n=152<br>)|Ensaios<br>clínicos<br>randomizad|Muito<br>grave<sup>a</sup>|Grave<sup>b</sup>|Grave<sup>c</sup>|Não<br>grave|Nenhum|**Barros et al. (2012)**<sup>8</sup>**:**<br>Os eventos adversos foram<br>observados na primeira infusão em|⨁◯◯<br>◯<br>Muito|CRÍTICO|  
|||**Avaliaç**|**ão da certeza da**|**evidência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
||os||||||ambos os grupos.<br>Não houve diferença significativa na<br>predominância dos eventos entre os<br>grupos.<br>**Elekwachi e Lubas (2008)**<sup>9</sup>**:**<br>Quatro pacientes, dois em cada<br>grupo, suspenderam o tratamento por<br>eventos adversos.|baixa||  
Explicações:  
a. Barros et al. (2012)<sup>8</sup> conduziram estudo com alto risco de viés devido às limitações no processo de randomização, desvios da intervenção pretendida, dados perdidos; enquanto o estudo de Elekwachi e Lubas (2008)<sup>9</sup> apresentou alto risco de viés devido às limitações no processo de randomização, desvios da intervenção pretendida, dados perdidos e seleção de resultado reportado.  
b. Os estudos são heterogêneos quanto à idade, estágio puberal, fenótipo da osteogênese imperfeita e posologia das terapias.  
c. Evidência indireta, pois, os estudos incluídos foram realizados em crianças e não em população acima de 18 anos.  
**QUESTÃO 8: O uso de hastes intramedulares telescópicas (extensíveis) do tipo Fassier Duval (FD) é seguro e eficaz para correção de deformidades ósseas, redução da incidência de fraturas, revisões e complicações cirúrgicas, além de incremento dos resultados de avaliações funcionais, em crianças e adolescentes em fase de**  
**crescimento com diagnóstico de OI, comparadas com hastes intramedulares e outros implantes não extensíveis?**  
**Recomendação:** Não foi elaborada recomendação sobre o uso das hastes intramedulares telescópicas (extensíveis) do tipo Fassier Duval (FD), pois a incorporação dessa tecnologia no SUS foi avaliada pela CONITEC, conforme Relatório de Recomendação nº 697/2022, com deliberação final desfavorável.  
A estrutura PICO para esta pergunta foi:  
**População:** Crianças (acima de 2 anos) e adolescentes com diagnóstico de osteogênese imperfeita, em fase de crescimento, elegíveis para procedimento cirúrgico ortopédico para correção de deformidades ou fraturas.  
**Intervenção:** Hastes intramedulares telescópicas (extensíveis) tipo Fassier Duval (FD).  
**Comparador:** Hastes intramedulares não extensíveis, fio de Kirschner ou fio de Steinmann ou nada.  
**Desfechos:** Deformidades; fraturas ou refraturas; complicações (revisão cirúrgica e sobrevida do implante); capacidade  
de deambulação e resultados de avaliações funcionais.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
A síntese de evidências referentes a esta PICO foram apresentadas no Relatório de Recomendação nº 697/2022 relativo à proposta de incorporação das hastes telescópicas para o tratamento de deformidades ósseas e prevenção de fraturas em pacientes com OI em fase de crescimento. <mark>Foi realizada busca nas bases de dados Medline (PubMed), Cochrane Library e Embase e</mark> Lilacs <mark>até o dia 16 de dezembro de 2021.</mark>  
<mark>Foi incluída 1 coorte comparativa retrospectiva. Os demais estudos observacionais provenientes da estratégia de busca, 12 séries e 3 relatos de casos, foram avaliados como estudos adicionais, devido à escassez de estudos, por se tratar de um procedimento cirúrgico, em população infantil, além da condição rara da doença.</mark>

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
O único estudo elegível encontrado e que respondeu à pergunta de pesquisa proposta foi Spahn et al. (2019)<sup>10</sup> , por comparar hastes telescópicas (extensível) de Fassier Duval e outros implantes não extensíveis. Entretanto, em caráter complementar, foram apresentadas evidências oriundas de séries de casos e relatos de casos que avaliaram a intervenção de interesse sem qualquer comparador. Tal medida se deu devido à escassez de estudos comparativos e ainda, pelo fato da condição estudada, osteogênese imperfeita, ser uma condição rara, o que significa estudos com um tamanho amostral pequeno e, consequentemente, propensão para menor precisão e confiabilidade.  
A recomendação final da CONITEC foi desfavorável à incorporação das hastes telescópicas para correção de deformidades e prevenção de fraturas em crianças e adolescentes em fase de crescimento com Osteogênese Imperfeita.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
Foi julgado pelos especialistas que o benefício das hastes telescópicas FD é grande com base nos resultados observados na prática clínica com melhora significativa de deformidades, redução de fraturas e maior tempo de sobrevida livre de revisão comparado aos implantes não extensíveis. Os especialistas consideraram que há menor incidência de complicações - que podem ou não levar à revisão cirúrgica, tais como: afrouxamento ou soltura da fixação, flexão (dobramento) e migração intra-articular da haste - com o uso de hastes telescópicas FD quando comparadas aos implantes não extensíveis. Assim, o painel de especialistas recomendou o uso de hastes telescópicas FD, condicionado à sua incorporação no SUS.  
Porém, na ausência de recomendações em outras agências de Avaliação de Tecnologias em Saúde, a busca por evidências resultou na seleção de uma pequena coorte comparativa retrospectiva e estudos observacionais não comparativos. Embora tais evidências tenham sugerido menor risco de falha, menor taxa de revisão cirúrgica, e sobrevida superior das hastes FD quando  
comparadas aos implantes não extensíveis no tratamento de deformidades de ossos longos presentes na OI, esses resultados estavam sujeitos às limitações metodológicas dos estudos encontrados. Assim, a evidência que embasou a avaliação foi insuficiente para garantir maior eficácia da haste telescópica FD.  
Além disso, os indicadores de eficiência e de viabilidade orçamentária, como a razão de custo-efetividade incremental e o impacto orçamentário da incorporação, apresentaram importantes incertezas que só serão neutralizadas com o desenvolvimento  
e a disseminação de evidências de maior validade interna e externa.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
Diante de melhores evidências, no caso de futura incorporação das hastes telescópicas, os serviços que já realizam os procedimentos cirúrgicos para inserção dos implantes não extensíveis não precisarão de incremento estrutural ou de equipamentos para inserção das hastes FD. O treinamento dos cirurgiões ortopedistas para a técnica será necessário.

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
A evidência sugeriu em seus resultados que a haste FD tem menor risco para revisão por falha e maior taxa de sobrevida livre de revisão, comparado com o risco dos implantes não extensíveis. A confiança global da evidência foi respectivamente muito baixa e baixa. Os resultados da avaliação da certeza da evidência (GRADE) para os desfechos de revisão cirúrgica por falha e a sobrevida dos implantes livre de revisão podem ser visualizados na **Tabela I** .  
**Tabela I** - Certeza da evidência segundo sistema GRADE para hastes telescópicas FD comparado a implantes intramedulares não extensíveis  
|||**Co**|**nfiança nas**|**evidências**|||**№ de**|**pacientes**|**Efe**|**ito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsis-**<br>**tência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Hastes**<br>**telescópicas**<br>**(extensíveis)**<br>**Fassier**<br>**Duval (FD)**|**Hastes**<br>**intramedulares**<br>**não extensíveis,**<br>**fio de**<br>**kirschnner ou**<br>**pino de**<br>**Steinmann**|**Relativo**<br>**(IC**<br>**95%)**|**Absoluto**<br>**(IC**<br>**95%)**|**Confiança**|**Importância**|

---

<!-- METADADOS: doenca: Osteogênese Imperfeita | secao: **imperfeita maiores de 18 anos?** -->
|1<br>Estudo<br>Grave|Não|Grave<sup>b</sup>|Grave<sup>c</sup>|Nenhum|4/26 (15.4%)|26/38 (68.4%)|**RR 0.22**|**534**|⨁◯◯◯||
|---|---|---|---|---|---|---|---|---|---|---|
|observacional<br>a|grave||||||(0.09|**menos**|Muito|IMPORTANTE|
||||||||para<br>0.57)|**por**<br>**1.000**<br>(de 623<br>menos<br>para 294<br>menos)|baixa||  
**Sobrevida do implante (seguimento: 4 anos; avaliado com: tempo decorrido e falha do implante)**  
<!-- Start of picture text -->
Confiança nas evidências  № de pacientes  Efeito<br>Hastes<br>Hastes  intramedulares<br>Risco  telescópicas  não extensíveis,  Relativo  Absoluto<br>№ dos  Delineamento  Inconsis- Evidência  Outras  Confiança  Importância<br>de  Imprecisão  (extensíveis)  fio de  (IC  (IC<br>estudos  do estudo  tência  indireta  considerações<br>viés  Fassier  kirschnner ou  95%)  95%)<br>Duval (FD)  pino de<br>Steinmann<br>1  Estudo  Grave  Não  Não grave  Grave  c, e Nenhum  Taxa de sobrevida das hastes FD em :  ⨁⨁◯◯<br>observacional  a, d grave  12 meses= 96,2% (75,7 a 99,4%)  Baixa  IMPORTANTE<br>24 meses= 92,3% (72,6 a 98%)<br>36 meses= 92,3% (72,6 a 98%)<br>48 meses= 88,1% (67,5 a 96%)<br>Taxa de sobrevida dos implantes não extensíveis em:<br>12 meses= 89,5% (74,3 a 96%)<br>24 meses=60,5% (43,3 a 74%)<br>36 meses=52,4% (35,5 a 66,8%)<br>48 meses= 40,7% (25 a 56%)<br><!-- End of picture text -->  
**Explicações:**  
a. Estudo retrospectivo com busca de dados em prontuários com possibilidades de dados incompletos. Viés de seleção dos casos, excluiu membros com menos de 2 anos de seguimento e aqueles tratados em outra instituição ou com pobre documentação.  
b. Domínio penalizado por evidência indireta, uma vez que o desfecho sobrevida livre de revisão cirúrgica é um desfecho de sobrevida livre de complicação  
c. Desfecho baseado em único estudo com “n” amostral pequeno.  
d. Desfechos medidos a partir da revisão cirúrgica. Falhas de implantes não revisados não foram computadas.  
e. O risco de falha do implante de hastes não extensíveis foi 13,2 vezes o risco de falha da haste FD, com IC 95% muito amplo, variando de 2,5 a 69,6.  
**Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD)**  
A **Tabela J** apresenta o processo de tomada de decisão sobre o uso de hastes intramedulares telescópicas (extensíveis) tipo Fassier Duval (FD) baseando-se nas contribuições do painel de especialistas e na síntese de evidências realizada pelo grupo elaborador sobre essa tecnologia.  
**Tabela J -** Processo de tomada de decisão referente ao uso de Hastes intramedulares telescópicas (extensíveis) tipo Fassier Duval (FD) para redução da incidência de revisões e complicações cirúrgicas em pacientes com OI.  
|**Item da EtD**|**Julgamento**<br>**dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios**:|Grande|Foi julgado pelos especialistas que o benefício das hastes FD é grande por<br>reduzir a incidência de revisão cirúrgica para troca do implante por falha,<br>aumentando a taxa de sobrevida, com base na evidência e, principalmente,<br>nos resultados observados na prática clínica com melhora significativa de<br>deformidades, redução de fraturas e maior tempo de sobrevida livre de<br>revisão comparado aos implantes não extensíveis.|
|**Riscos**|Pequeno|Especialistas julgam que os riscos e complicações que levam ou não à<br>revisão como afrouxamento ou soltura da fixação, flexão (dobramento),<br>migração intra-articular da haste são menores com as hastes FD|
|**Balanço dos riscos**<br>**e benefícios:**|Favorece<br>a<br>intervenção|Os benefícios são muito maiores que os riscos.|
|**Certeza**<br>**da**<br>**evidência**:|Não concorda|Especialistas acreditam que a metodologia para avaliar a qualidade dos<br>estudos ainda não está adequada para tratar das limitações relacionadas às<br>doenças raras. Ponderam que além da condição rara, o procedimento<br>cirúrgico em população de criança e adolescente também refletirá no<br>pequeno tamanho da amostra da população. Metodologia deveria adequar<br>critérios para as condições raras.|
|**Custos:**|Grande|As tecnologias não seriam igualmente comparáveis em termos de custo,<br>uma vez que o princípio das hastes telescopadas é diferenciado|
|**Aceitabilidade:**||Espera-se que os implantes de FD sejam aceitos pela comunidade médica<br>e por familiares dos pacientes uma vez que é esperado menos revisão<br>cirúrgica e um acréscimo no tempo livre de falhas para hastes FD em<br>comparação com os implantes atualmente disponíveis no SUS.|
|**Viabilidade**<br>**de**<br>**implementação:**<br>**Outras**|Não|O procedimento cirúrgico para implante das hastes FD podem ser<br>realizadoss utilizando a capacidade instalada dos centros que já os realizam<br>com implantes não extensíveis mediante treinamento de cirurgiões.<br>O implante de FD exige expertise e treinamento.|  
|**Item da EtD**|**Julgamento**<br>**painelistas**|**dos**|**Justificativa**|
|---|---|---|---|  
**considerações:**  
**5. REFERÊNCIAS**  
1. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento de Ciência e Tecnologia.  Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde [Internet]. Brasília: Ministério da Saúde; 2014. 72 p.  
2. Letocha AD, Cintas HL, Troendle JF, Reynolds JC, Cann CE, Chernoff EJ, et al. Controlled trial of pamidronate in children with types III and IV osteogenesis imperfecta confirms vertebral gains but not short-term functional improvement. J Bone Miner Res. 2005; 20:977–86.  
3. Aström E, Jorulf H, Söderhäll S. Intravenous pamidronate treatment of infants with severe osteogenesis imperfecta. Arch Dis Child. 2007; 92:332–8.  
4. Land C, Rauch F, Montpetit K, Ruck-Gibis J, Glorieux FH. Effect of intravenous pamidronate therapy on functional abilities and level of ambulation in children with osteogenesis imperfecta. J Pediatr. 2006; 148:456–60.  
5. Munns CFJ, Rauch F, Travers R, Glorieux FH. Effects of intravenous pamidronate treatment in infants with osteogenesis imperfecta: clinical and histomorphometric outcome. J Bone Miner Res. 2005; 20:1235–43.  
6. Shapiro JR, Thompson CB, Wu Y, Nunes M, Gillen C. Bone mineral density and fracture rate in response to intravenous and oral bisphosphonates in adult osteogenesis imperfecta. Calcif Tissue Int. 2010; 87:120–9.  
7. DiMeglio LA, Peacock M. Two-Year Clinical Trial of Oral Alendronate Versus Intravenous Pamidronate in Children with Osteogenesis Imperfecta. J Bone Miner Res [Internet]. 2005 [citado 21 de dezembro de 2021]; 21:132–40. Disponível em: http://doi.wiley.com/10.1359/JBMR.051006  
8. Barros ER, Saraiva GL, de Oliveira TP, Lazaretti-Castro M. Safety and efficacy of a 1-year treatment with zoledronic acid compared with pamidronate in children with osteogenesis imperfecta. J Pediatr Endocrinol Metab [Internet]. 2012; 25:485–91. Disponível em: https://pubmed.ncbi.nlm.nih.gov/22876543/  
9. Elekwachi O, Lubas W. Statistical review and evaluation: clinical studies. Treatment of children with osteogenesis imperfecta (oi). [Internet]. USA: U.S. Department of Health and Human Services Food and Drug Administration; 2008. (Study 2202). Report No.: NDA/Serial Number:21-223 /SE5-016. Disponível em: https://www.fda.gov/media/71577/download  
10.  Spahn KM, Mickel T, Carry PM, Brazell CJ, Whalen K, Georgopoulos G, et al. Fassier-Duval Rods are Associated with Superior Probability of Survival Compared with Static Implants in a Cohort of Children With Osteogenesis Imperfecta Deformities. J Pediatr Orthop [Internet]. 2019;39:e392–6. Disponível em: https://pubmed.ncbi.nlm.nih.gov/30589679/

---

