<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: Geral -->
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: Geral -->
Aprova as Diretrizes Diagnósticas e Terapêuticas do Carcinoma de Esôfago.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o carcinoma de esôfago no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que as diretrizes diagnósticas e terapêuticas são resultado de consenso técnico-científico e são formuladas dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando a Consulta Pública n<sup><u>o</u></sup> 19/SAS/MS, de 30 de outubro de 2014; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC) e da Assessoria Técnica da SAS/MS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo a esta Portaria, disponível no sitio: www.saude.gov.br/sas, as Diretrizes Diagnósticas e Terapêuticas – Carcinoma de Esôfago.  
Parágrafo único. As Diretrizes de que trata este artigo, que contêm o conceito geral do câncer esofagiano, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do carcinoma esofagiano.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
FAUSTO PEREIRA DOS SANTOS

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
1. Metodologia de busca e avaliação da literatura  
Foi realizada busca nas bases de dados do Medline/Pubmed, Embase e Cochrane para opções terapêuticas do carcinoma de esôfago.  
No Medline/Pubmed, a busca foi realizada no dia 10/03/2014 e utilizada a seguinte estratégia: termos "Esophageal Neoplasms/diet therapy"[Mesh] OR "Esophageal Neoplasms/drug therapy"[Mesh] OR "Esophageal Neoplasms/radiotherapy"[Mesh] OR "Esophageal Neoplasms/surgery"[Mesh] OR "Esophageal Neoplasms/therapy"[Mesh], restringindo-se para estudos em humanos, meta-análises e revisões sistemáticas em inglês, português e espanhol,  identificaram-se 257 referências. Foram retirados 34 artigos que fugiam ao escopo destas Diretrizes. Dos 223 artigos restantes, 121 eram revisões sistemáticas dos mais variados enfoques.  
No Embase, a busca foi realizada no dia 10/03/2014 e utilizada a seguinte estratégia: termos 'esophagus cancer'/exp OR 'esophagus carcinoma'/exp AND 'therapy'/exp restringindo-se para estudos em humanos, meta-análises e revisões sistemáticas em inglês, português e espanhol, identificaram-se 393 estudos. Destes, 180 foram retirados porque fugiam ao escopo destas Diretrizes. Dos 213 artigos, 99 eram revisões sistemáticas.  
Além disso, 59 artigos foram encontrados tanto no PUBMED quanto no EMBASE.  
Na base de dados Cochrane, a busca foi realizada no dia 10/03/2014 com o termo “Esophagus cancer” e foram identificadas 10 revisões sistemáticas sobre esta doença. Destas, uma foi retirada por não tratar diretamente da conduta para câncer de esôfago(#9).  
Foram utilizadas nestas Diretrizes as revisões sistemáticas e artigos de 2005 a 2014, totalizando 40 artigos, visto que estes se repetem sistematicamente quanto aos seus resultados. Para os tópicos que não possuem meta-análises e revisões sistemáticas publicadas, foi utilizada a base de dados UpToDate.  
Os artigos referentes aos fatores de risco raros para o câncer de esôfago foram identificados de forma não sistemáticas, a fim de citar as revisões mais recentes na língua portuguesa ou não.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O câncer de esôfago afeta mais de 450 mil pessoas a cada ano. A Organização Mundial da Saúde (OMS) estimou para o ano de 2012, 323 mil novos casos em homens e 132 mil em mulheres no mundo todo. As taxas de mortalidade se aproximam das de incidência, dado o mau prognóstico deste câncer, sendo esperadas 400 mil mortes por ano decorrentes deste câncer. A diferença entre os países pode ser de até 20 vezes, e as regiões mais afetadas são as menos desenvolvidas, onde ocorrem 80% dos novos casos e das mortes. Em todas as regiões ocorre mais em homens do que em mulheres numa razão de aproximadamente 2:1.(1)  
No Brasil, as estimativas para 2014 preveem 8.000 casos entre os homens e 2.700 entre as mulheres, aproximadamente, o que corresponde uma taxa de incidência de 8,18 por 100 mil homens  e 2,7 por 100 mil mulheres.(2)  
O câncer de esôfago pode ser do tipo histopatológico epidermoide e do tipo adenocarcinoma. O primeiro é mais comumente associado ao abuso de fumo e álcool e hábitos alimentares inadequados e é a maioria nos países de alta incidência, localizando-se mais frequentemente no esôfago médio e proximal. Já o segundo está mais relacionado ao refluxo gastresofágico crônico, doença de Barret e obesidade e ocorre mais frequentemente no esôfago distal e junção esofagogástrica (JEG).(3).  
Estas diferenças levam a crer que os dois tipos histológicos representem na verdade duas doenças distintas que acometem a mesma topografia com patogênese, comportamento biológico e resposta ao tratamento diferentes. Os principais fatores de risco modificáveis para o câncer de esôfago são fumo, álcool e obesidade(4,5). São fatores de risco menos frequentes: a tilose ou Síndrome de Howel-Evans(6,7), síndrome hereditária caracterizada por hiperceratose palmoplantar; Síndrome de PlummerVinson (8,9), síndrome provavelmente associada a deficiência de ferro e que tem como característica a tríade disfagia, anemia ferropriva e membranas esofágicas; e acalasia(10), uma desordem neurodegenerativa da motilidade do esôfago que compromete o peristaltismo e  evolui para a perda da função do esfíncter inferior do esôfago e faz parte das alterações encontradas na Doença de Chagas.  
O esôfago de Barret é fator de risco para o adenocarcinoma de esôfago. É uma alteração definida como a transformação do epitélio escamoso do esôfago distal para o epitélio colunar especializado, a metaplasia intestinal (epitélio glandular).(11) Supõe-se que esta alteração se dá por exposição

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
prolongada ao refluxo gastroesofágico. Se não prevenida ou tratada, esta metaplasia evolui para displasia de baixo e alto grau, que, quando presente, pode ser considerada a lesão precursora do adenocarcinoma de esôfago (12,13).  
Inexistem evidências de que a utilização de suplementos com efeitos antioxidantes, como suplementos vitamínicos e selênio, tenha efeito sobre a incidência de câncer de esôfago (RR 1,06, 95% CI 0,89 a 1,28, I2 = 0%)(14).  
Revisões sistemáticas (RS) de estudos observacionais reportaram efeito protetor com alguns suplementos ou medicamentos (como aspirina e antiinflamatórios não esteroidais - AINE) ou dieta rica em fibra, porém com força de evidência inferior à RS da Cochrane, que inclui apenas ensaios clínicos contra placebo ou observação(15-18), razão pela qual não se recomenda esta intervenção preventiva.  
Inexistem ensaios clínicos randomizados que determinem a eficácia de rastreamento de câncer de esôfago. Conforme RS da Cochrane, baseada em estudos observacionais, concluiu que ensaios clínicos não randomizados relataram melhora na sobrevida, porém a análise crítica identifica que este resultado pode ter sido afetado pelo viés de duração de tempo, viés de tempo ganho e viés de seleção.(19)  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
3. Classificação estatística internacional de doenças e problemas relacionados à saúde (cid-10)  
- C15.0 Neoplasia maligna da porção cervical do esôfago (esôfago cervical)  
- C15.1 Neoplasia maligna da porção torácica do esôfago (esôfago torácico)  
- C15.2 Neoplasia maligna da porção abdominal do esôfago (esôfago abdominal)  
- C15.3 Neoplasia maligna do terço superior do esôfago  
- C15.4 Neoplasia maligna do terço médio do esôfago  
- C15.5 Neoplasia maligna do terço inferior do esôfago  
- C15.8 Neoplasia maligna do esôfago com lesão invasiva  
- C15.9 Neoplasia maligna do esôfago, não especificado

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A maioria dos pacientes diagnosticados com câncer de esôfago apresenta disfagia progressiva como primeiro sintoma. Assim, todo paciente que inicia com este sintoma deve submeter-se a uma endoscopia alta. Esta recomendação é particularmente importante caso o paciente apresente ou se exponha a algum fator de risco ou se tiver sintomas associados, como odinofagia e perda de peso.  
4.1 DIAGNÓSTICO CLÍNICO E CIRÚRGICO  
Tumor na mucosa do esôfago visto na endoscopia digestiva alta (EDA) é patognomônico do câncer de esôfago. Mesmo assim, biópsia para comprovação anatomopatológica e definição do subtipo histológico é mandatória. A adição da coleta de espécime para citologia aumenta a acurácia do diagnóstico.(20,21)  
Porém, é comum o paciente com câncer de esôfago ser diagnosticado com um quadro avançado da neoplasia e, neste caso, os sintomas associados a disfagia grave ou obstrução do trato digestivo são claros, como perda de peso, desnutrição e odinofagia.  
4.2. Diagnóstico por Imagem  
O diagnóstico por imagem do câncer de esôfago tem por objetivo definir o estadiamento, ou seja, determinar a profundidade da invasão do tumor na parede do esôfago (T), o acometimento linfonodal locorregional (N) e a presença de metástase(s) à distância (M). Porém, não há método de imagem ideal para o estadiamento pré-tratamento nem para avaliação de resposta após tratamento. Em parte esta dificuldade se dá pela variabilidade de apresentações e prognóstico deste grupo de tumores, o que dificulta a padronização da avaliação da acurácia do teste nos estudos disponíveis. A broncoscopia ou a ecoendoscopia faz parte da avaliação da extensão (estadiamento) dos tumores localizados acima da carina em alguns centros. Mas, sempre que houver suspeita de fístula esôfagobrônquica, a broncoscopia é o método diagnóstico de eleição <mark>.(22)</mark>  
Outros exames podem ser utilizados para o estadiamento: a tomografia computadorizada (TC) de tórax e abdômen superior, exame endoscópico (esofagiano e mediastinal) e ultrassonografia (US) endoscópica (com ou sem biópsia aspirativa com agulha fina de linfonodos aumentados). A acurácia destes exames é variável, e estudos com qualidade metodológica adequada estão em andamento.  
<!-- Start of picture text -->
y Fs Ne 5<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Alguns centros incluem a laparoscopia para aumentar a precisão da avaliação da extensão tumoral, já que os adenocarcinomas dão metástases preferencialmente para a cavidade abdominal e o carcinoma epidermoide, intratorácicas. Porém, inexiste evidência suficiente para recomendar a laparoscopia como definitivamente necessária para o estadiamento do câncer de esôfago. A identificação de metástase(s) a distância é fundamental para evitar procedimentos cirúrgicos de grande porte que comprometam a qualidade de vida do paciente sem benefício em termos de sobrevida do doente.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Inexistem exames de patologia clínica para o diagnóstico do câncer de esôfago, e não há recomendação de se solicitar marcadores tumorais (como o CEA e CA19.9, entre outros) para diagnóstico, avaliação prognóstica, seguimento de pacientes e avaliação da resposta terapêutica.  
4.4 Estadiamento  
Os critérios de estadiamento do câncer de esôfago são os adotados pela União Internacional contra o Câncer (UICC) em TNM - Classificação de Tumores Malignos(23):  
|TUMO|R(T)|
|---|---|
|T1|Lâmina própria (T1a), submucosa (T1b).|
|T2|Muscularprópria.|
|T3|Adventícia.|
|T4a|Pleura, pericárdio, diafragma.|
|T4b|Aorta, corpo vertebral, traqueia.|
|LINFO|NODO(N)|
|N1|1a2 linfonodosregionais.|
|N2|3 a 6linfonodosregionais.|
|N3<br>|7 oumaislinfonodosregionais.<br>|
|METÁ|STASE A DISTÂNCIA(M)|
|M0|Sem metástase a distância.|
|M1|Com metástase a distância.|

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|Estádio 0|Tis|N0|M0|
|---|---|---|---|
|Estádio IA|T1|N0|M0|
|EstádioIB|T2|N0|M0|
|EstádioIIA|T3|N0|M0|

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|Estádio IIB|T1,T2|N1|M0|
|---|---|---|---|
||T4a|N0|M0|
|Estádio IIIA|T3|N1|M0|
||T1,T2|N2|M0|
|EstádioIIIB|T3|N2|M0|
||T4a|N1, N2|M0|
|Estádio IIIC|T4b|Qualquer N|M0|
||Qualquer T|N3|M0|
|EstádioIV|Qualquer T|QualquerN|M1|  
A incorporação de variáveis não anatômicas, como localização e grau de diferenciação histológica, se deu a partir da 7ª edição e modifica a distribuição dos tumores T1 e T2 nos estágios iniciais. Os gráficos que se seguem facilitam a visualização destas diferenças entre os tipos histopatológicos mais comuns do carcinoma de esôfago(24):

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|~~a~~|T|N|M|Grau|*Localização|
|---|---|---|---|---|---|
|Grupo 0<br>~~a~~<br>|Tis<br>~~a~~|0|0|1|Qualquer|
|Grupo IA<br>~~a~~<br>|1|0|0|1,X|Qualquer|
|Grupo IB<br>~~a~~<br>|1<br>|0<br>|0<br>|2,3<br>|Qualquer<br>|
||2,3<br>|0<br>|0<br>|1,X<br>|Inferior,X<br>|
|Grupo IIA<br>~~ee~~<br>|2, 3<br>~~ee~~<br>|0<br>~~e~~|0<br>|1, X<br>|Superior/<br>Médio<br>~~e~~|
|<br>|2,3<br>  <br>|0<br>|0<br>|2,3<br>|Inferior,X<br>|
|Grupo IIB<br>~~ee~~<br>|2, 3<br>~~ee~~<br>|0<br>|0|2, 3|Superior/<br>Médio|
|<br>~~a~~<br>|1,2<br> <br>~~a~~<br>|1<br>|0|Qualquer|Qualquer|
|Grupo IIIA<br>~~a~~<br>|1,2<br><br>|2|0|Qualquer|Qualquer|
|~~a~~<br>|3<br><br>|1|0|Qualquer|Qualquer|
|~~a~~<br>|4a<br><br><br>|0|0|Qualquer|Qualquer|
|Grupo IIIB<br>~~a~~<br>|3<br><br>~~a~~<br>|2<br>|0|Qualquer|Qualquer|
|Grupo IIIC<br>~~a~~|4a<br>~~a~~|1,2<br>|0|Qualquer|Qualquer|
|~~a~~<br>|4b<br><br>|Qualquer|0|Qualquer|Qualquer|
|~~a~~<br>|Qualquer<br><br>|3|0|Qualquer|Qualquer|
|Grupo IV<br>~~a~~|Qualquer<br>|Qualquer|1|Qualquer|Qualquer|  
*Superior, médio e inferior correspondem aos terços intratorácicos do esôfago.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
|~~a~~<br>|T|N|M|Grau|
|---|---|---|---|---|
|Grupo 0<br>~~a~~<br>|Tis|0|0|1|
|Grupo IA<br>~~a~~<br>|1<br>|0|0|1,2,X|
|Grupo IB<br>~~a~~<br>|1<br>~~a~~<br>|0<br>|0<br>|3<br>|
|~~a~~|2<br>|0<br>|0<br>|1,2,X<br>|
|Grupo IIA<br><br>|2<br>|0<br>|0<br>|3<br>|
|Grupo IIB<br>~~a~~<br>|3<br>|0|0|Qualquer|
|~~a~~<br>|1,2<br>~~a~~<br><br>|1<br>|0<br>|Qualquer|
|Grupo IIIA<br>~~a~~<br>|1,2<br><br><br>|2<br>|0<br>|Qualquer|
|~~a~~<br>|3<br><br>|1|0|Qualquer|
|~~a~~<br>|4a<br><br>|0|0|Qualquer|
|Grupo IIIB<br>~~aa~~<br>|3<br>~~a~~<br><br>|2<br>|0<br>|Qualquer|
|Grupo IIIC<br> <br>~~a~~<br>|4a<br> <br><br><br>|1,2<br>|0<br>|Qualquer|
|~~a~~<br>|4b<br><br>|Qualquer|0|Qualquer|
|~~a~~<br>|Qualquer<br><br>|3|0|Qualquer|
|Grupo IV<br>~~a~~|Qualquer<br>|Qualquer|1|Qualquer|

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Hospitais gerais com serviço de cirurgia ou de cirurgia oncológica podem realizar o diagnóstico, tratamento cirúrgico e acompanhamento de doentes com achado incidental de tumores esofagianos. Já os hospitais habilitados como UNACON ou CACON têm as condições para o tratamento cirúrgico e clínico de doentes com câncer de esôfago em todos os estágios da doença.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento do câncer de esôfago é interdisciplinar. O planejamento das modalidades terapêuticas deve ser feito tão logo o diagnóstico esteja definido quanto ao seu tipo histopatológico, localização (cervical, torácico ou distal) e estadiamento(25). A cirurgia deve ser feita em hospital cuja equipe cirúrgica tenha experiência nas diversas técnicas e em que a qualidade dos resultados seja avaliada periodicamente(22).  
Apesar de não haver ensaio clínico randomizado (ECR) ou revisão sistemática (RS) que definam o papel da nutrição adequada antes de iniciar o tratamento do câncer de esôfago, é importante garantir uma via de alimentação adequada e avaliar periodicamente o estado nutricional do paciente.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O câncer de esôfago inicial são tumores classificados como Tis (displasia de alto-grau, que inclui todas as lesões neoplásicas não invasivas (também denominados tumores in situ) e os tumores T1, divididos em T1a (lesões

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
que invadem até a camada da mucosa) e T1b (lesões até a submucosa). O risco de envolvimento linfonodal nos tumores Tis ou T1a é vitualmente zero, com exceção de algumas séries que descrevem a possibilidade deste acometimento quando o tumor que envolve somente a mucosa chega até a camada muscular da mucosa e apresenta invasão linfovascular à histopatologia(26).  
Uma RS da Cochrane, atualizada em abril de 2012, descreveu que não há ensaios ECRs que comparam o melhor tratamento para lesões pré-malignas ou malignas iniciais (definidas como esôfago de Barret, displasia de alto grau, carcinomas com invasão superficial (T1a e T1b)). O critério de inclusão de artigos para essa RS incluía neoplasias de linhagem epitelial e glandular, e para tipos histopatológicos menos comuns a ausência de estudos é semelhante para todos os subtipos. A decisão de usar métodos de resseção endoscópicas ou esofagectomia deve ser tomada a critério da equipe assistencial multidisciplinar que assiste o paciente(27). 6.2 Cirurgia do carcinoma esofagiano  
Todo o paciente com câncer de esôfago deve ser avaliado quanto a sua ressecabilidade (que inclui a localização do tumor e a avaliação de metástase(s) a distância).  
Casos de tumores cervicais em que não é possível garantir margem proximal adequada devem receber tratamento não cirúrgico (radioterapia) exclusivo(28).  
Casos de tumor avançado (T4a) que envolve o pericárdio, pleura ou diafragma podem ser operados. Tumores que invadem outros órgãos como coração, grandes vasos, traqueia e órgãos adjacentes (T4b) são irresecáveis. Assim como não devem ser abordados cirurgicamente os tumores da junção esofagogástrica com acometimento linfonodal supraclavicular ou em estágio clínico IV, ou seja, com metástase(s) a distância mesmo que só linfonodal(ais).(29)  
A técnica cirúrgica deve ser definida pela localização do tumor, condições do paciente, a experiência da equipe cirúrgica e a preferência do paciente, devidamente esclarecido sobre os resultados da cirurgia.(30-32)  
Inexiste ECR ou RS que definam o número mínimo de linfonodos que devem ser ressecados nos pacientes com cirurgia primária para o câncer de esôfago. Porém, análise de séries de casos demonstram que a extensão da linfadenectomia se relaciona positivamente com a sobrevida. (33,34,35,36) Inexistem evidências sobre o número necessário para aqueles que  
receberam tratamento préoperatório, mas um número semelhante deve ser buscado.

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O tratamento inicial para a maioria dos pacientes que se apresentam com tumor em estágio clínico IB a III (tumores que invadem a muscular própria – T2 – ou mais ou que tenham acometimento linfonodal – N positivo) é a quimiorradioterapia concomitante ou quimioterapia peri-operatória.  
O benefício de quimioterapia e radioterapia concomitantes seguidos ou não de cirurgia pode ser evidenciado em todos os estágios clínicos do carcinoma de esôfago, e esta modalidade de tratamento deve ser recomendada sempre que o paciente apresentar condições clínicas e não tiver metástase(s) a distâncias que devam ser tratadas com outra modalidade terapêutica.  
O esquema ideal de quimioterapia exclusiva ou em combinação com outras modalidades terapêuticas não está definido. Porém, os esquemas de tratamento mais comumente usados incluem a 5-fluoruracila infusional e cisplatina, com ou sem um terceiro antineoplásico(37).  
Uma meta-análise de 10 ensaios clínicos randomizados, comparando quimiorradioterapia prévia a cirurgia com cirurgia exclusiva, mostrou um ganho absoluto em sobrevida de 13% em 2 anos para o tratamento combinado (HR, 0,81; 95% CI, 0,70-0,93; p=0,002).(38)  
Duas meta-análises de 2009 e 2011 também demonstraram redução da mortalidade por câncer de esôfago em pacientes que recebem quimio- e radioterapia concomitantes sem cirurgia. A revisão da Cochrane demonstrou um beneficio relativo de 27% (HR 0,73 (95% CI 0,64 a 0,84) sem cirurgia após. O beneficio absoluto foi de 9% em 1 ano (95% CI 5% a 12%) e 4% em 2 anos (95% CI 3% a 6%). Porém, este tratamento combinado foi associado a eventos adversos significativos.(39,40)  
Os ensaios clínicos em que a quimioterapia e a radioterapia eram sequenciais não demonstraram beneficio em sobrevida ou controle local, além de agregarem muita toxicidade.(37)  
Quimioterapia e radioterapia concomitantes previamente à cirurgia para adenocarcinoma de esôfago (e estômago) aumenta a sobrevida (SV) quando comparado com cirurgia isolada e deve ser oferecida a todos os pacientes em condições clínicas de a elas se submeterem. A RS com metaanálise atualizada em 2014, que demonstrou este impacto na sobrevida, demonstra maior beneficio nos casos do câncer que tem origem na junção esôfagogástrica (JEG) do que nas outras localizações anatômicas. Além  
<!-- Start of picture text -->
Afr<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
disso, a associação de quimio- e radioterapia também tem mais impacto sobre a SV do que quimioterapia isolada nos casos de tumor localizado na JEG e no esôfago. Porém, nem todos os estudos que foram incluídos no resultado global da meta-análise tinha a identificação da localização topográfica. Na sub-análsie por topografia, apenas 70% dos pacientes puderam ser incluídos. Destes, 26% eram casos de adenocarcinomas de esôfago distal, e a meta-análise não mostrou beneficio na sobrevida global (HR 0,87 [ 0.73, 1,05 ]). Esta RS demonstrou uma interação entre idade e efeito do tratamento, demonstrando que quanto mais jovem o paciente mais beneficio sobre a SV, e que pacientes idosos não se beneficiam(41). 6.4 Quimioterapia prévia ou adjuvante  
Quimioterapia prévia (sem radioterapia) parece aumentar a sobrevida de pacientes com neoplasia de esôfago torácico ressecável, quando comparado com cirurgia. Esta evidência é baseada em RS da Cochrane publicada em 2009 (atualizada pela última vez em fevereiro de 2010), que demonstrou vantagem em SV, porém com significância estatística limítrofe (HR 0,88; 95% CI 0,75 a 1,04).(42) Esta evidência é apoiada também por metaanálise atualizada em 2011(43) e outra de pacientes individuais publicada somente em formato de resumo de congresso(44). Este benefício é particularmente significativo em análises de alguns subgrupos, como pacientes com linfonodos positivos ou que responderam a quimioterapia antes da cirurgia.  
Quimioterapia exclusiva adjuvante (pós-operatória) não impacta na sobrevida dos doentes de carcinoma esofagiano(37).  
6.5  Radioterapia  
Ensaios clínicos não demonstraram beneficio em sobrevida com a radioterapia exclusiva pré-(45) ou pós-operatória(46-48), quando comparada com cirurgia exclusiva. A Tabela 1 resume o tratamento do carcinoma esofagiano de localização torácica e distal.  
Tabela 1 - Resumo <u>dos tratamentos de carcinomas torácicos e distais</u>  
|OPÇÕES<br>TERAPÊUTICAS<br>PARA PACIENTESEM<br>METÁSTASE(S) A<br>DISTÂNCIA|EC I<br>E – T1-3N0<br>A – T1-2N0|ECII<br>E – T1-2N1<br>A – T3 N0<br>+ T1-2N1|ECIII<br>E – T3-4-<br>2N1-3<br>A – T3 N1<br>mais qualquer<br>T4 mais<br>qualquer N2-3|
|---|---|---|---|

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde** -->
|Cirurgiaexclusivamente|X|X||
|---|---|---|---|
|Quimioterapia e<br>radioterapia<br>concomitantes||X|X|
|Quimioterapia e<br>radioterapia<br>concomitanteprévias a<br>cirurgia|X|X|X|  
Abreviaturas: E = Carcinoma epidermoide  A = Adenocarcinoma

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde** -->
A maioria dos pacientes com câncer de esôfago ou com câncer da transição esofagogástrica é diagnosticada em estágios avançados. O principal objetivo do tratamento nesta situação é o controle dos sintomas, principalmente disfagia. Apesar de ter evoluído, a melhor opção para melhorar a disfagia não foi ainda estabelecida. Stent metálico autoexpansível é seguro, efetivo e rápido na resolução do sintoma. Stent e braquiterapia são comparáveis a outras modalidades, como dilatação, ablação endoscópica e quimio- e radioterapia concomitantes(46-48).  
6.7 Tratamento de paciente com carcinoma metastático (M1) ou recidivado Dois ECR com um total de 42 participantes compararam quimioterapia paliativa com cuidados paliativos exclusivos (best supportive care) para o tratamento de pacientes com câncer de esôfago avançado. Nenhum beneficio em sobrevida foi demonstrado com a quimioterapia. Cinco ECR com um total de 1.242 participantes compararam diferentes esquemas de quimioterapia. Devido à variabilidade dos pacientes e dos esquemas de tratamento não foi possível fazer uma análise conjunta dos resultados. Nenhum esquema de quimioterapia específico se demonstrou superior, e a revisão recomenda que se faça ECR específicos para se responder a essas perguntas e se fazer uma recomendação com nível de evidência estatisticamente significante. Além disso, estudos que avaliem qualidade de vida em pacientes em que o tratamento tem intuito paliativo devem ser desenvolvidos.(49)  
- 7   Monitorização do tratamento  
- 7.1 Avaliação da resposta terapêutica  
A resposta patológica completa é o principal fator prognóstico após tratamento neoadjuvante, e peças operatórias com remissão completa são as que predizem melhor sobrevida.(50)

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A utilização de meios diagnósticos nucleares (PET) associados ou não à TC têm sido utilizado para avaliar a resposta ao tratamento neoadjuvante visto sua alta sensibilidade; porém, a sua superioridade sobre outros métodos, como a ecografia endoscópica, não está definida.(51)  
Inexistem exames de imagem ideal para avaliar a resposta terapêutica, e os exames utilizados para o estadiamento devem ser repetidos para avaliar a efetividade do tratamento.  
7.2 Critérios de interrupção do tratamento  
Inexistem estudos que definam critérios de interrupção de tratamento. Assim, a relação custo-benefício deve ser avaliada individualmente após ter sido instituído o tratamento padrão e houver falha de resposta ou sofrimento desproporcional relacionado ao tratamento.  
8  Acompanhamento Pós-Tratamento  
Inexiste estudo que demonstre o impacto sobre a sobrevida dos doentes com seguimento sistemático com exames após os tratamentos. Recomendam-se consultas a cada 3 a 6 meses pelos primeiros 1 a 2 anos; então, a cada 6 a 12 meses durantes 3 a 5 anos e, após, anualmente. Apesar de não haver a necessidade de se repetir a EDA regularmente, esta e outros exames de imagem devem ser realizados conforme os sintomas apresentados pelo paciente. Pacientes com câncer inicial que tiveram ressecção endoscópica devem submeter-se à endoscopia a cada 3 meses por pelo menos 1 ano e, após, anualmente.(29)

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes com diagnóstico de câncer esofagiano devem ser atendidos em hospitais habilitados em oncologia com porte tecnológico suficiente para diagnosticar, tratar e realizar o seu acompanhamento.  
Além da familiaridade que esses hospitais guardam com o estadiamento, o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados. Os procedimentos radioterápicos e quimioterápicos (Grupo 03, Subgrupo 04) e cirúrgicos (Grupo 04 e os vários subgrupos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento ou nome do procedimento e por código da CID – Classificação Estatística Internacional

---

<!-- METADADOS: doenca: Carcinoma de Esôfago - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no SIGTAP-Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente disponibilizada.  
São os seguintes os procedimentos da tabela do SUS para a quimioterapia de adultos com câncer de esôfago:  
QUIMIOTERAPIA PALIATIVA – ADULTO 03.04.02.017-6 - Quimioterapia Paliativa do Carcinoma Epidermoide/Adenocarcinoma de Esôfago avançado (doença metastática ou recidivada) QUIMIOTERAPIA PRÉVIA/CONCOMITANTE À RADIOTERAPIA – ADULTO  
03.04.04.011-8 – Quimioterapia de Carcinoma Epidermoide ou Adenocarcinoma de Esôfago em estádio de I até IVA  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações de controle e avaliação.  
Ações de controle e avaliação incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; e o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos).  
Ações de auditoria devem verificar in loco, por exemplo, a existência e observância da regulação do acesso assistencial; a qualidade da autorização; a conformidade da prescrição e da dispensação e administração de medicamento(s) (tipos e doses); a compatibilidade do procedimento codificado com o diagnóstico de câncer esofagiano e perfil clínico do doente (capacidade funcional, estadiamento, indicação clínica para tratamento), o esquema terapêutico e as doses diárias prescritas e fornecidas; a compatibilidade do registro dos procedimentos com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Exceto pela Talidomida para o tratamento de Mieloma Múltiplo, pelo Mesilato de Imatinibe para a quimioterapia do Tumor do Estroma Gastrointestinal (GIST), da Leucemia Mieloide Crônica, Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo e Síndrome Hipereosinofílica e pelo Trastuzumabe para a quimioterapia do carcinoma de mama inicial e locorregionalmente avançado, o Ministério da Saúde e as  
Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos[46].  
10. Termo de Esclarecimento e Responsabilidade (TER) É obrigatória a informação ao paciente ou ao seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao tratamento do câncer esofagiano, notadamente no uso de medicamento antineoplásico.  
11  Referências  
1. Ferlay J, Soerjomataram I, Ervik M, Dikshit R, Eser S, Mathers C, et al. Cancer Incidence and Mortality Worldwide: IARC CancerBase No. 11 [Internet]. Lyon, <country-region>France</country-region>: International Agency for Research on Cancer; 2013. Disponível em: <u>http://globocan.iarc.fr (acessado em 06/04/2014). GLOBOCAN2012.</u> 2. Brasil. Ministério da Saúde. Instituto Nacional de Câncer. Estimativa 2014. Incidência do Câncer no Brasil Rio de Janeiro. INCA, 2014. 124p.il.col.,mapas.  
3. Jemal A, Bray F, Center MM, Ferlay J, Ward E, Forman D. Global cancer statistics. CA Cancer J Clin. 2011;61(2):69-90.  
4. Freedman ND, Abnet CC, Leitzmann MF, Mouw T, Subar AF, Hollenbeck AR, et al. A prospective study of tobacco, alcohol, and the risk of esophageal and gastric cancer subtypes. Am J Epidemiol. 2007;165(12):1424-33.  
5. Lindkvist B, Johansen D, Stocks T, Concin H, Bjorge T, Almquist M, et al. Metabolic risk factors for esophageal squamous cell carcinoma and adenocarcinoma: a prospective study of 580,000 subjects within the MeCan project. BMC Cancer. 2014;14:103.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
6. O'Mahony MY, Ellis JP, Hellier M, Mann R, Huddy P. Familial tylosis and carcinoma of the oesophagus. J R Soc Med. 1984;77(6):514-7.  
7. de Souza CA, Santos Ada C, Santos Lda C, Carneiro AL. [Hereditary tylosis syndrome and esophagus cancer]. An Bras Dermatol. 2009;84(5):527-9.  
8. Novacek G. Plummer-Vinson syndrome. Orphanet J Rare Dis. 2006;1:36.  
9. Oliveira A, Teixeira D, Ferronatto G. Síndrome de Plummer-Vinson: Relato de caso e revisão da literatura. Rev. Med. Res., Curitiba, v.15, n.22013. p. 138-42.  
10. O'Neill OM, Johnston BT, Coleman HG. Achalasia: a review of clinical diagnosis, epidemiology, treatment and outcomes. World J Gastroenterol. 2013;19(35):5806-12.  
11. Winberg H, Lindblad M, Lagergren J, Dahlstrand H. Risk factors and chemoprevention in Barrett's esophagus--an update. Scand J Gastroenterol. 2012;47(4):397-406.  
12. Risk factors and chemoprevention in Barrett's esophagus - An update [Internet]. 2012.  
13. Singh S, Manickam P, Amin AV, Samala N, Schouten LJ, Iyer PG, et al. Incidence of esophageal adenocarcinoma in Barrett's esophagus with low-grade dysplasia: a systematic review and meta-analysis. Gastrointest Endosc. 2014;79(6):897-909.e4; quiz 83.e1, 83.e3.  
14. Bjelakovic G, Nikolova D, Simonetti RG, Gluud C. Antioxidant supplements for preventing gastrointestinal cancers. Cochrane Database Syst Rev. 2008(3):Cd004183.  
15. Ge XX, Xing MY, Yu LF, Shen P. Carotenoid intake and esophageal cancer risk: a meta-analysis. Asian Pac J Cancer Prev. 2013;14(3):1911-8.  
16. Sivarasan N, Smith G. Role of aspirin in chemoprevention of esophageal adenocarcinoma: a meta-analysis. J Dig Dis. 2013;14(5):22230.  
17. Coleman HG, Murray LJ, Hicks B, Bhat SK, Kubo A, Corley DA, et al. Dietary fiber and the risk of precancerous lesions and cancer of the esophagus: a systematic review and meta-analysis. Nutr Rev. 2013;71(7):474-82.  
18. Sun L, Yu S. Meta-analysis: non-steroidal anti-inflammatory drug use and the risk of esophageal squamous cell carcinoma. Dis Esophagus. 2011;24(8):544-9.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
19. Yang S, Wu S, Huang Y, Shao Y, Chen XY, Xian L, et al. Screening for oesophageal cancer. Cochrane Database Syst Rev. 2012;12:Cd007883. 20. Zargar SA, Khuroo MS, Jan GM, Mahajan R, Shah P. Prospective comparison of the value of brushings before and after biopsy in the endoscopic diagnosis of gastroesophageal malignancy. Acta Cytol. 1991;35(5):549-52.  
21. Batra M, Handa U, Mohan H, Sachdev A. Comparison of cytohistologic techniques in diagnosis of gastroesophageal malignancy. Acta Cytol. 2008;52(1):77-82.  
22. Allum WH, Blazeby JM, Griffin SM, Cunningham D, Jankowski JA, Wong R. Guidelines for the management of oesophageal and gastric cancer. Gut. 2011;60(11):1449-72.  
23. União Internacional Contra o Câncer. TNM: classificação de tumores malignos. Ministério da Saúde. Instituto Nacional de Câncer. 7a Edição. Rio de Janeiro, Inca2012. xxv, 325p.  
24. Rice TW, Blackstone EH. Esophageal cancer staging: past, present, and future. Thorac Surg Clin. 2013;23(4):461-9.  
25. Stahl M, Mariette C, Haustermans K, Cervantes A, Arnold D. Oesophageal cancer: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2013;24 Suppl 6:vi51-6.  
26. Wright CD, Saltzman J <mark>R Management of superficial esophageal cancer. UpToDate, 2014 versão24.0</mark>  
27. Bennett C, Green S, De Caestecker J, Almond M, Barr H, Bhandari P, et al. Surgery versus radical endotherapies for early cancer and high-grade dysplasia in Barrett's oesophagus. Cochrane Database of Systematic Reviews In: The Cochrane Library [Internet]. (2).  
28. Choi N, Gibson M. Radiation therapy, chemoradiotherapy, neoadjuvant approaches, and postoperative adjuvant therapy for localized cancers of the esophagus. UpToDate 40.0 [Internet].2014.  
29. NCCN Guidelines Esophageal and Esophagogastric Junction Câncers. version 1.2014 Disponível em <u>http://www.nccn.org/professionals/physician_gls/pdf/esophageal.pdf.</u> 30. Uzunoglu FG, Reeh M, Kutup A, Izbicki JR. Surgery of esophageal cancer. Langenbecks Arch Surg. 2013;398(2):189-93.  
31. Dantoc M, Cox MR, Eslick GD. Evidence to support the use of minimally invasive esophagectomy for esophageal cancer: a meta-analysis. Arch Surg. 2012;147(8):768-76.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
32. Watanabe M, Baba Y, Nagai Y, Baba H. Minimally invasive esophagectomy for esophageal cancer: an updated review. Surg Today. 2013;43(3):237-44.  
33. Peyre CG, Hagen JA, DeMeester SR, Altorki NK, Ancona E, Griffin SM, et al. The number of lymph nodes removed predicts survival in esophageal cancer: an international study on the impact of extent of surgical resection. Ann Surg. 2008;248(4):549-56.  
34. Greenstein AJ, Litle VR, Swanson SJ, Divino CM, Packer S, Wisnivesky JP. Effect of the number of lymph nodes sampled on postoperative survival of lymph node-negative esophageal cancer. Cancer. 2008;112(6):1239-46.  
35. Rizk NP, Ishwaran H, Rice TW, Chen LQ, Schipper PH, Kesler KA, et al. Optimum lymphadenectomy for esophageal cancer. Ann Surg. 2010;251(1):46-50.  
36. Schwarz RE, Smith DD. Clinical impact of lymphadenectomy extent in resectable esophageal cancer. J Gastrointest Surg. 2007;11(11):1384-93; discussion 93-4.  
37. Forde PM, Kelly RJ. Chemotherapeutic and targeted strategies for locally advanced and metastatic esophageal cancer. J Thorac Oncol. 2013;8(6):673-84.  
38. Gebski V, Burmeister B, Smithers BM, Foo K, Zalcberg J, Simes J. Survival benefits from neoadjuvant chemoradiotherapy or chemotherapy in oesophageal carcinoma: a meta-analysis. Lancet Oncol. 2007;8(3):226-34.  
39. Wong RK, Malthaner R. Combined chemotherapy and radiotherapy (without surgery) compared with radiotherapy alone in localized carcinoma of the esophagus. Cochrane Database of Systematic Reviews. In: The Cochrane Library; (2).  
40. Kranzfelder M, Schuster T, Geinitz H, Friess H, Buchler P. Metaanalysis of neoadjuvant treatment modalities and definitive non-surgical therapy for oesophageal squamous cell cancer. Br J Surg. 2011;98(6):76883.  
41. Ronellenfitsch U, Schwarzbach M, Hofheinz R, Kienle P, Kieser M, Slanger T, et al. Perioperative chemo (radio)therapy versus primary surgery for resectable adenocarcinoma of the stomach, gastroesophageal junction, and lower esophagus.; (2).  
42. Vogt K, Fenlon D, Rhodes S, Malthaner R. Preoperative chemotherapy for resectable thoracic esophageal cancer. Cochrane Database of Systematic Reviews. In: The Cochrane Library,; (2).  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
43. Sjoquist KM, Burmeister BH, Smithers BM, Zalcberg JR, Simes RJ, Barbour A, et al. Survival after neoadjuvant chemotherapy or chemoradiotherapy for resectable oesophageal carcinoma: an updated meta-analysis. Lancet Oncol. 2011;12(7):681-92.  
44. Thirion SM A, Le Maître J. Tierney Abstract: Individual patient databased meta-analysis assessing pre-operative chemotherapy in resectable oesophageal carcinoma P. G. on behalf of the MetaAnalysis of Chemotherapy in Esophagus Cancer Collaborative Group Journal of Clinical Oncology, 2007 ASCO Annual Meeting Proceedings (PostMeeting Edition). Vol 25, No 18S (June 20 Supplement), 2007: 45122007; 25.  
45. Arnott SJ, Duncan W, Gignoux M, Girling D, Hansen H, Launois B, et al. Preoperative radiotherapy for esophageal carcinoma. Cochrane Database of Systematic Reviews. In: The Cochrane Library.  
46. Zieren HU, Muller JM, Jacobi CA, Pichlmaier H, Muller RP, Staar S. Adjuvant postoperative radiation therapy after curative resection of squamous cell carcinoma of the thoracic esophagus: a prospective randomized study. World J Surg. 1995;19(3):444-9.  
47. Fok M, Sham JS, Choy D, Cheng SW, Wong J. Postoperative radiotherapy for carcinoma of the esophagus: a prospective, randomized controlled study. Surgery. 1993;113(2):138-47.  
48. Ténière P, Hay J, Fingerhut A, Fagniez P. Postoperative radiation therapy does not increase survival after curative resection for squamous cell carcinoma of the middle and lower esophagus as shown by a multicenter controlled trial. French University Association for Surgical Research. Surg Gynecol Obstet.1991. p. 123-30.  
49. Homs Marjolein Y, van der Gaast A, Siersema Peter D, Steyerberg EW, J. KE. Chemotherapy for metastatic carcinoma of the esophagus and gastro-esophageal junction. Cochrane Database of Systematic Reviews. In: The Cochrane Library,; (2).  
50. Chirieac LR, Swisher SG, Ajani JA, Komaki RR, Correa AM, Morris JS, et al. Posttherapy pathologic stage predicts survival in patients with esophageal carcinoma receiving preoperative chemoradiation. Cancer. 2005;103(7):1347-55.  
51. Ngamruengphong, V K S, B N, Das. A. Assessment of response to neoadjuvant therapy in esophageal cancer: an updated systematic review of diagnostic accuracy of endoscopic ultrasonography and  
fluorodeoxyglucose positron emission tomography. Dis. Esophagus2010. p. 216-31.

---

