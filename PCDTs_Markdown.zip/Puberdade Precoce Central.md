<!-- METADADOS: doenca: Puberdade Precoce Central | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 13, de 27 de JULHO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Puberdade Precoce Central.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a puberdade precoce central no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 735/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 738 – Junho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Puberdade Precoce Central.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da puberdade precoce central, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Puberdade Precoce Central.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS/SCTIE/MS n<sup>o</sup> 3, de 08 de junho de 2017, publicada no Diário Oficial da União nº 110, de 09 de junho de 2017, seção 1, página 95.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: SANDRA DE CASTRO BARROS -->
ANEXO

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **1. INTRODUÇÃO** -->
A puberdade é o processo de maturação biológica que, pelas modificações hormonais, culmina no aparecimento de caracteres sexuais secundários, na aceleração da velocidade de crescimento e, por fim, na aquisição de capacidade reprodutiva da vida adulta. É resultado do aumento da secreção do hormônio liberador das gonadotrofinas (GnRH), o qual estimula a secreção dos hormônios luteinizante (LH) e folículo-estimulante (FSH), que por sua vez estimularão a secreção dos esteroides sexuais e promoverão a gametogênese<sup>1,2</sup> .  
Considera-se precoce o aparecimento de caracteres sexuais secundários antes dos 8 anos em meninas e antes dos 9 anos em meninos<sup>3,4</sup> . Em 80% dos casos, a precocidade sexual é dependente de gonadotrofinas (também chamada de puberdade precoce central ou verdadeira)<sup>2</sup> . A puberdade precoce dependente de gonadotrofinas é em tudo semelhante à puberdade normal, com ativação precoce do eixo hipotálamo-hipófise-gônadas. A manifestação inicial em meninas é o surgimento do botão mamário e em meninos o aumento do volume testicular maior ou igual a 4 mL (estágios de Tanner 2 para ambos os sexos). A evolução puberal segue os critérios de Tanner e caracteriza-se como puberdade completa em estágio de Tanner 5 ( **Apêndice 1** )<sup>5,6,7.</sup> . A secreção prematura dos hormônios sexuais leva à aceleração do crescimento e à fusão precoce das epífises ósseas, o que antecipa o final do crescimento e pode comprometer a estatura final [previsão de altura final abaixo do percentil 2,5; previsão de altura final abaixo da estatura-alvo (± 8 cm); desvio-padrão (dp) da altura para a idade óssea abaixo de -2; perda de potencial de altura durante o seguimento]<sup>3</sup> . Porém, mesmo com início prematuro, em algumas crianças, a puberdade é de lenta evolução e não compromete a altura final<sup>1,8,9</sup> . Por isso, a avaliação da progressão por 3 a 6 meses pode auxiliar na definição de necessidade ou não de tratamento nos casos de estágio iniciais de puberdade, especialmente em meninas entre 6 a 8 anos<sup>3</sup> .  
Considerada uma condição rara, a puberdade precoce é de 10 a 23 vezes mais frequente em meninas do que em meninos<sup>4,6,10,11</sup> . A incidência verificada em um estudo populacional na Dinamarca é de 20/23 casos para cada 10.000 meninas e de menos de 5 casos para cada 10.000 meninos<sup>11</sup> . É frequentemente associada a alterações neurológicas, como tumores do sistema nervoso central (SNC), hamartomas hipotalâmicos, hidrocefalia, doenças inflamatórias ou infecções do SNC. Em meninas, a maior parte dos casos é idiopática. Em meninos, 2/3 dos casos estão associados a anormalidades neurológicas e, destes, 50% dos casos estão relacionados a tumores<sup>2,12</sup> . Seu diagnóstico é baseado no exame físico, exames laboratoriais e de imagem.  
Em um número menor de casos, a precocidade sexual decorre de produção de esteroides sexuais não dependente de gonadotrofinas. Nessa situação, também há o aparecimento de características sexuais secundárias e aceleração de crescimento/idade óssea, mas tais manifestações não caracterizam a puberdade precoce verdadeira, podendo ser decorrentes de tumores ou cistos ovarianos, tumores testiculares, hiperplasia adrenal congênita, tumores adrenais, Síndrome de McCune Albright, hipotireoidismo grave, entre outras doenças<sup>3,4,6,13,14</sup> .  
O desenvolvimento isolado das mamas (telarca precoce) ou dos pelos pubianos (pubarca precoce) também é uma forma de precocidade sexual que não caracteriza puberdade. Tem sido relatado que entre 21% e 64% das meninas que começam a desenvolver um broto mamário antes dos 8 anos apresentam telarca isolada e não evoluem para puberdade precoce central<sup>15</sup> . Todavia, em 18% a 20% dos casos, o aparecimento de mamas ou de pelos pode ser o primeiro sinal de puberdade precoce verdadeira. Deve-se acompanhar a evolução desses quadros<sup>3,4,6,14</sup> . A maioria dos casos com suspeita de puberdade precoce são variedades precoces ou transitórias do desenvolvimento puberal e não requerem tratamento. Em caso de suspeita clínica, o diagnóstico oportuno da puberdade precoce central requer a interpretação conjunta da evolução clínica e parâmetros bioquímicos, bem como a avaliação das possíveis consequências e da resposta esperada ao tratamento para cada caso em  
particular<sup>2</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da puberdade precoce central. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 2** .

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E22.8 Outras hiperfunções da hipófise – puberdade precoce central.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **3.1.     Diagnóstico clínico** -->
O principal elemento diagnosticado na puberdade precoce central (PPC) é o desenvolvimento puberal antes dos 8 anos nas meninas e antes dos 9 anos nos meninos. Dessa forma, define-se como desenvolvimento puberal precoce presença de mamas, com ou sem desenvolvimento de pelos pubianos ou axilares, antes dos 8 anos nas meninas e aumento do volume testicular maior ou igual a 4 mL, com ou sem pelos pubianos ou axilares, antes dos 9 anos nos meninos.  
Além disso, é importante que seja documentada a progressão da puberdade a cada 3 a 6 meses, uma vez que parte dos pacientes apresentará puberdade de progressão lenta ou até não progressão do quadro, e esses pacientes alcançam altura final normal, mesmo sem tratamento medicamentoso<sup>3</sup> . Do contrário, progressão rápida, ou seja, mudança do estádio puberal (estágios de Tanner) num período menor que 3 meses, caracteriza quadros de puberdade rapidamente progressiva, acompanhados, geralmente, de um crescimento acelerado (velocidade de crescimento maior que 6 cm/ano). Dependendo da etapa do desenvolvimento puberal em que a criança se encontra, observa-se aceleração do crescimento.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **3.2.     Diagnóstico laboratorial** -->
O diagnóstico laboratorial confirma a suspeita clínica de PPC. Utiliza-se a dosagem de LH, com limite de detecção de no mínimo 0,1 unidades internacionais (UI)/L<sup>3</sup> . Em ambos os sexos, valores basais de LH maiores que 0,3 UI/L por ensaio imunoquiminulométrico (ICMA)<sup>16,17</sup> e maiores que 0,6 UI/L por ensaio imunofluorométrico (IFMA)<sup>18,19</sup> confirmam o diagnóstico de PPC (são considerados níveis puberais). Contudo, em meninas pode existir sobreposição importante de valores de LH basal pré-puberal e puberal inicial<sup>3,18</sup> . É, então, indicado para diagnóstico o teste de estímulo com 100 mcg de GnRH endovenoso, com aferições 0, 30 e 60 minutos após, tanto em meninos quanto em meninas acima de 3 anos de idade. Valores de pico do LH maiores que 5 UI/L confirmam o diagnóstico em ambos os sexos com os ensaios laboratoriais acima referidos<sup>1,3,20,21</sup> . Na impossibilidade de realização do teste do GnRH, pode ser realizado o teste com um agonista do GnRH (leuprorrelina), com dosagem de LH 2 a 3 horas após estímulo com 3,75 mg, com resposta puberal sugerida quando o valor for maior que 10,0 UI/L por IFMA ou maior que 8,0 UI/L por quimio e eletroquimioluminescencia<sup>13,17–23</sup> .  
A relação LH/FSH maior que 1 também é mais frequente em indivíduos púberes e pode auxiliar na diferenciação entre PPC progressiva e não progressiva<sup>3,14,24</sup> .

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **3.3. Exames de imagem** -->
Os exames de imagem necessários ao diagnóstico da puberdade precoce central são:  
- Radiografia de mãos e punhos: para avaliação da idade óssea segundo método de Greulich-Pyle, considerando-  
se avanço de pelo menos 1 ano ou 2 desvios-padrão acima da idade cronológica compatível com o diagnóstico de puberdade precoce;  
Ultrassonografia pélvica: tamanho uterino maior que 35 mm de comprimento, volume maior que 2 mL, aspecto piriforme e aumento da espessura endometrial<sup>4,6</sup> sugerem estímulo estrogênico persistente. Ovários com volume maior que 1 cm<sup>3</sup> sugerem fortemente estimulação gonadotrófica persistente<sup>3,25,26</sup> . Esse dado é especialmente útil em meninas menores de 3 anos, quando os valores basais de LH e mesmo o teste de GnRH são menos confiáveis. A ultrassonografia pélvica é considerada um exame adicional ao diagnóstico em meninas de todas as idades, porém não obrigatório. Pode ser solicitada como exame adicional em situações de dúvida diagnóstica;  
- Ressonância magnética de SNC: pelo risco de lesões tumorais ou malformações de SNC<sup>17</sup> é recomendada em todos os meninos e em meninas menores de 6 anos com diagnóstico clínico e laboratorial de PPC. Em meninas entre 6 e 8 anos também deve ser realizada quando houver suspeita clínica de alteração do SNC<sup>3</sup> .

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes que apresentarem início do quadro de puberdade precoce de acordo com as seguintes definições:  
- Meninas menores de 3 anos: sinais clínicos de puberdade rapidamente progressiva (mudança nos estágios de Tanner em menos de 3 meses), idade óssea avançada (conforme descrito no item 3.3), aumento da velocidade de crescimento (acima de 6 cm/ano), LH em níveis puberais (conforme descrito no item 3.2), ultrassonografia com aumento do tamanho ovariano e uterino (conforme descrito no item 3.3);  
- Meninas entre 3 e 5 anos: sinais clínicos de puberdade, idade óssea avançada, aumento da velocidade de crescimento, LH basal ou no teste de estímulo em níveis puberais (conforme descrito no item 3.2), ultrassonografia com aumento do tamanho ovariano e uterino (conforme descrito no item 3.3);  
- Meninas entre 6 e 8 anos: sinais clínicos de puberdade rapidamente progressiva (mudança nos estágios de Tanner em menos de 3 meses), idade óssea avançada (conforme descrito no item 3.3), aumento da velocidade de crescimento (acima de 6 cm/ano), comprometimento da estatura final [previsão de altura final abaixo do percentil 2,5; previsão de altura final abaixo da estatura-alvo (± 8 cm); desvio- padrão (dp) da altura para a idade óssea abaixo de -2; perda de potencial de altura durante o seguimento], LH no teste de estímulo em nível puberal (conforme descrito no item 3.2), ultrassonografia com aumento do tamanho ovariano e uterino (conforme descrito no item 3.3);  
- Meninas entre 8 e 10 anos: início puberal antes dos 8 anos ou em idade limítrofe (entre 8 e 9 anos), preenchendo os critérios de puberdade rapidamente progressiva (mudança nos estágios de Tanner em menos de 3 meses), menarca iminente e com comprometimento da estatura final, especialmente se foram nascidas pequenas para idade gestacional;  
- Meninos menores de 9 anos: sinais clínicos de puberdade, aumento da velocidade de crescimento, idade óssea avançada, comprometimento da estatura final, LH basal ou no teste de estímulo em nível puberal (estes últimos conforme descrito no item 3);  
- Meninos entre 9 e 10 anos: presença dos critérios acima, puberdade rapidamente progressiva (mudança nos estágios de Tanner em menos de 3 meses) e prejuízo da altura final [previsão de altura final abaixo do percentil 2,5; previsão de altura final abaixo da estatura-alvo (± 8 cm); desvio-padrão (dp) da altura para a idade óssea abaixo de -2; perda de potencial de altura durante o seguimento].  
**5. CRITÉRIOS DE EXCLUSÃO**  
Serão excluídos deste Protocolo pacientes que apresentarem, pelo menos uma das seguintes situações:  
- Pubarca precoce isolada (aparecimento isolado de pelos pubianos antes dos 8 anos nas meninas e antes dos 9 anos nos meninos);  
- Telarca precoce isolada (aparecimento isolado de mamas antes dos 8 anos nas meninas, sem evolução puberal completa);  
- Produção de esteroides não estimulados por gonadotrofinas: tumores ou cistos ovarianos, tumores testiculares, hiperplasia adrenal congênita, tumores adrenais, Síndrome de McCune Albright (vide casos especiais);  
- Puberdade precoce lentamente progressiva, sem comprometimento da estatura final, em meninas de 6 a 8 anos;  
- Idade óssea acima de 12 anos em meninas e de 13 anos em meninos;  
- Toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **6. CASOS ESPECIAIS** -->
Pacientes com puberdade precoce não estimulada por gonadotrofinas (puberdade precoce periférica), especialmente com baixo controle terapêutico da doença de base e estímulo hormonal periférico persistente, podem desenvolver ativação do eixo gonadotrófico e apresentarem concomitância de puberdade precoce central, como ocorre frequentemente nos casos de hiperplasia adrenal congênita (vide o PCDT da Hiperplasia Adrenal Congênita, do Ministério da Saúde).  
Além disso, crianças nascidas pequenas para idade gestacional podem fazer quadros de puberdade rapidamente progressiva, necessitando de bloqueio no caso de grave prejuízo à altura adulta (crescimento abaixo do percentil 5 da curva de crescimento).  
Nestas duas situações, pode ser necessário o tratamento conforme preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **7. TRATAMENTO** -->
O tratamento da puberdade precoce central é feito com agonistas de GnRH. Estes medicamentos têm como objetivo bloquear a evolução puberal e, com isso, promover a regressão dos caracteres sexuais secundários, diminuir a velocidade de crescimento e a progressão da idade óssea. Atuam suprimindo a secreção de gonadotrofinas hipofisárias e assim evitam a produção de esteroides sexuais<sup>24</sup> . Estudos não comparativos longitudinais demonstraram que o tratamento promove a regressão das caracte rísticas sexuais secundárias<sup>27</sup> .  
Estudos demonstram que meninas tratadas antes dos 6 anos parecem ser o grupo que mais se beneficia desse tratamento, com ganho estatural de cerca de 9 a 10 cm. No caso de meninas com idade de início da puberdade de 6 a 8 anos, este benefício é atenuado (ganho de cerca de 4 a 7 cm), e para meninos esse benefício não está claramente demonstrado<sup>3</sup> .  
Quando houver causa anatômica identificada (p. ex., tumores do SNC), o problema deve ser avaliado e tratado pelo especialista da área. Adicionalmente, e quando não há causa anatômica identificada, utilizam-se agonistas de longa duração do GnRH. Não há evidência de benefício ou ausência de eventos adversos do uso do agonista de GnRH em crianças com autismo, em tratamento quimioterápico, com baixa estatura idiopática, com deficiência de hormônio do crescimento ou com hipotireoidismo grave<sup>3,28</sup> . Portanto, não está preconizado nessas situações.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **7.1. Fármacos** -->
- Acetato de medroxiprogesterona: suspensão injetável com 150 mg/mL ou 50 mg/mL;  
- Acetato de ciproterona: comprimidos de 50 mg;  
- Acetato de gosserrelina: implante subcutâneo de 3,6 mg e 10,8 mg.  
- Acetato de leuprorrelina: pó para suspensão injetável com 3,75 mg, 11,25 mg e 45 mg;  
Triptorrelina: pó para suspensão injetável com 3,75 mg, 11,25 mg e 22,5 mg.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **7.2. Esquemas de administração** -->
Os esquemas de administração dos fármacos usados no tratamento da Puberdade Precoce Central encontram-se discriminados na **Tabela 1** .  
**Tabela 1** - Esquema de administração dos fármacos usados no tratamento da Puberdade Precoce Central  
|**Medicamento**|**Frequência**|**Posologia**|**Via de**<br>**administração**|
|---|---|---|---|
|Acetato de ciproterona|diária|50 a 100 mg/m<sup>2</sup>|VO|
|Acetato de medroxiprogesterona|mensal|50 a 150 mg|IM|
|Att d rrlin|mensal|3,6 mg|SC|
|ceao e gosseea|trimestral|10,8 mg|SC|
|Acetato de leurorrelina|mensal|3,75 mg<br>7,5 mg<sup>a</sup>|IM<br>IM|
|p|trimestral|11,25 mg|IM|
||semestral|45 mg|SC|
|Tritorrelina|mensal|3,75 mg<br>7,5 mg<sup>a</sup>|IM<br>IM|
|p|trimestral|11,25 mg|IM|
||semestral|22,5 mg|IM|  
Nota:<sup>a</sup> Apenas em caso de controle clínico ou laboratorial insatisfatório.  
Legenda: VO = via oral; IM= via intramuscular.  
Anteriormente, o tratamento com agonistas de GnRH de depósito mensal era usado com mais frequência. No entanto, formulações adicionais de uso a cada 3 meses e 6 meses, bem como implantes subcutâneos, tornaram-se disponíveis nos últimos anos. As opções de depósitos são formulações de liberação sustentada administradas em várias doses e intervalos<sup>28</sup> . Não há superioridade terapêutica entre as três modalidades: uso mensal, trimestral e semestral<sup>3,4,6,29,30</sup> . Logo, o início de tratamento pode ser feito com qualquer uma das posologias. Em caso de controle clínico ou laboratorial insatisfatório, pode-se aumentar a dose da leuprorrelina e da triptorrelina de 3,75 mg para 7,5 mg mensal<sup>18,27</sup> . Inexistem estudos sobre doses maiores na ausência de adequado controle<sup>31,32</sup> nas posologias vigentes da gosserrelina, não sendo preconizados neste Protocolo. O uso de leuprorrelina 45 mg e de triptorrelina 22,5 mg apresenta benefícios acerca da vantagem posológica, que pode possibilitar maior adesão ao tratamento<sup>29,30,33</sup> .

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **7.3. Benefícios esperados** -->
- Regressão dos caracteres sexuais secundários (estágios de Tanner);  
- Diminuição da velocidade de crescimento;  
- Regressão dos níveis de gonadotrofinas para valores pré-puberais;  
- Não progressão da idade óssea.  
- **7.4. Tempo de tratamento – critérios de interrupção**  
O tratamento é realizado do período do diagnóstico até idade cronológica normal para o desenvolvimento de puberdade,  
considerando idade óssea, idade estatural, previsão de estatura final e aspectos psicossociais. Sugere-se avaliar interrupção do tratamento com idade óssea próxima de 12,5 anos nas meninas e de 13,5 anos nos meninos. A decisão de suspender o tratamento deve ser individualizada, sendo apropriado indagar sobre a percepção dos pais e do paciente sobre a prontidão para interromper o tratamento, pois pode-se prever que a maturação puberal será retomada dentro de meses, sendo razoável interromper a terapia em um momento em que a puberdade progrida concomitantemente com a dos pares da criança<sup>12,14,28</sup> . Após a interrupção do tratamento, os pacientes deverão ser acompanhados clinicamente por endocrinologistas pediátricos ou endocrinologistas a cada 6 meses para medidas antropométricas e avaliação da retomada da puberdade até o término do crescimento longitudinal.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **8. MONITORAMENTO** -->
Pacientes com puberdade precoce central devem ser avaliados de cada 3 a 6 meses em relação à eficácia do tratamento e ao desenvolvimento de toxicidade aguda ou crônica. A monitorização do tratamento com agonistas de GnRH deverá ser feita a partir de consultas clínicas com avaliação do estágio puberal (Tanner), do crescimento linear e da tolerância ou eventos adversos do tratamento<sup>14</sup> . Deve-se realizar radiografia simples de mãos e punhos para monitorização da idade óssea a cada 12 meses. Nos primeiros 3 a 6 meses de tratamento (antes da dose seguinte), novas dosagens de LH após estímulo são recomendadas, com o objetivo de evidenciar o bloqueio da secreção de gonadotrofinas. Além de valores de LH em níveis prépuberais, espera-se valores basais de estradiol no sexo feminino e da testosterona no sexo masculino na faixa pré-puberal durante o tratamento, ou seja, abaixo do limite de detecção do método utilizado para dosagem<sup>17</sup> ; a dosagem de LH após o uso de agonistas de GnRH (mensal, trimestral ou semestral) deve ser mantida em valores inferiores a 4 mUI/mL [IFMA, ICMA ou eletroquimioluminescência (electrochemiluminescence immunoassay, ECLIA)<sup>22,34–36</sup> . Em caso de adequado controle clínicolaboratorial, a mesma posologia pode ser mantida. Em caso de controle clínico ou laboratorial insatisfatórios, pode-se indicar a redução do intervalo entre as doses ou o aumento de dose de leuprorrelina ou triptorrelina para 7,5 mg mensal<sup>17,34</sup> .  
Os análogos de GnRH são considerados bem tolerados em crianças e adolescentes. Na primeira administração, pode haver sangramento vaginal. Ocasionalmente, podem ocorrer cefaleia e fogachos, mas de curta duração. Reações locais podem ser vistas em 10% a 15% dos indivíduos e, em menor proporção, podem ocasionar abscessos estéreis<sup>14,24</sup> . Raros casos de anafilaxia foram descritos.  
Em situações de reação alérgica local, formação de abcesso estéril com uso do análogo de GnRH ou anafilaxia, o acetato de medroxiprogesterona (MPA) ou acetato de ciproterona (CPA) representam opções terapêuticas<sup>17</sup> , devendo ser reservados exclusivamente para estas situações, uma vez que não atuam na fisiopatologia da PPC<sup>17</sup> . Ambos, MPA e CPA, são úteis no bloqueio da progressão da puberdade, mas não têm impacto benéfico sobre a altura final<sup>14,37</sup> . O MPA é administrado por via intramuscular (injeção de depósito) e sua dose varia de 50 mg a 150 mg mensal. É de baixo custo, porém pelo efeito semelhante aos de glicocorticoides, pode causar eventos adversos como hipertensão e depósito de gordura troncular (hábito cushingoide). O CPA é de uso oral, diário, e sua dose varia de 50 a 100 mg/m<sup>2</sup> /dia<sup>14</sup> . Tem efeito antiandrogênico, pode levar a quadros de ginecomastia no sexo masculino e causar efeitos gastrointestinais<sup>37</sup> . A monitorização de aminotransferases/transaminases (ALT/TGP e AST/TGO) e de bilirrubinas é recomendada antes do início do tratamento com CPA e, após, a cada 3 a 6 meses. Em caso de elevação acima de 3 vezes o valor normal da AST, reavaliar (ou suspender) o tratamento.  
Apesar de dados limitados na literatura, não há relato de prejuízo da função ovariana ou de infertilidade após suspensão do tratamento<sup>3</sup> . Os pacientes devem ter avaliação diagnóstica e acompanhamento terapêutico por endocrinologistas pediátricos, endocrinologistas ou pediatras, cuja avaliação periódica deve ser condição para a dispensação do(s) medicamento(s).

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e  
do acompanhamento pós-tratamento. Pacientes com puberdade precoce central devem ser atendidos em serviços especializados em endocrinologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **11. REFERÊNCIAS** -->
1. Palmert MR, Malin H V, Boepple PA. Unsustained or slowly progressive puberty in young girls: initial presentation and long-term follow-up of 20 untreated patients. _J Clin Endocrinol Metab_ . 1999;84(2):415–423.  
2. Parent A-S, Teilmann G, Juul A, Skakkebaek NE, Toppari J, Bourguignon J-P. The timing of normal puberty and the age limits of sexual precocity: variations around the world, secular trends, and changes after migration. _Endocr Rev_ . 2003;24(5):668–693.  
3. Carel J-C, Eugster EA, Rogol A, Ghizzoni L, Palmert MR. Consensus statement on the use of gonadotropin-releasing hormone analogs in children. _Pediatrics_ . 2009;123(4):e752–e762.  
4. Saenger P, Snyder PJ, Kirkland JL, Crowley WF, Hoppin AG, Martin KA. Overview of precocious puberty. _UpToDate available from http//www uptodateonline com_ . Published online 2009.  
5. Tanner JM. Growth at adolescence. Published online 1962.  
6. Carel J-C, Léger J. Precocious puberty. _N Engl J Med_ . 2008;358(22):2366–2377.  
7. Sociedade Brasileira de Pediatria. Desenvolvimento Puberal de Tanner. Disponível em https://www.sbp.com.br/departamentos/endocrinologia/desenvolvimento-puberal-de-tanner/. Acesso em 26/07/2022.  
8. Palmert MR, Boepple PA. Variation in the timing of puberty: clinical spectrum and genetic investigation. _J Clin Endocrinol Metab_ . 2001;86(6):2364–2368.  
9. Léger J, Reynaud R, Czernichow P. Do all girls with apparent idiopathic precocious puberty require gonadotropinreleasing hormone agonist treatment? _J Pediatr_ . 2000;137(6):819–825.  
10. Bridges NA, Christopher JA, Hindmarsh PC, Brook CG. Sexual precocity: sex incidence and aetiology. _Arch Dis Child_ . 1994;70(2):116–118.  
11. Teilmann G, Pedersen CB, Jensen TK, Skakkebæk NE, Juul A. Prevalence and incidence of precocious pubertal development in Denmark: an epidemiologic study based on national registries. _Pediatrics_ . 2005;116(6):1323–1328.  
12. Partsch C, Heger S, Sippell WG. Management and outcome of central precocious puberty. _Clin Endocrinol (Oxf)_ . 2002;56(2):129–148.  
13. Eugster EA. Peripheral precocious puberty: causes and current management. _Horm Res Paediatr_ . 2009;71(Suppl. 1):64– 67.  
14. Brito VN, Latronico AC, Arnhold IJP, Mendonça BB. Update on the etiology, diagnosis and therapeutic management of sexual precocity. _Arq Bras Endocrinol Metabol_ . 2008;52:18–31.  
15. Miranda-Lora AL, Torres-Tamayo M, Zurita-Cruz JN, et al. Diagnosis of precocious puberty: clinical guideline for the diagnosis and treatment of precocious puberty. _Bol Med Hosp Infant Mex_ . 2020;77:7–14.  
16. Sathasivam A, Garibaldi L, Shapiro S, Godbold J, Rapaport R. Leuprolide stimulation testing for the evaluation of early female sexual maturation. _Clin Endocrinol (Oxf)_ . 2010;73(3):375–381.  
17. Brito VN, Spinola-Castro AM, Kochi C, Kopacek C, Silva PCA da, Guerra-Júnior G. Central precocious puberty: revisiting the diagnosis and therapeutic management. _Arch Endocrinol Metab_ . 2016;60:163–172.  
18. Resende E, Lara BHJ, Reis JD, Ferreira BP, Pereira GA, Borges MF. Assessment of basal and gonadotropin-releasing hormone-stimulated gonadotropins by immunochemiluminometric and immunofluorometric assays in normal children. _J Clin Endocrinol Metab_ . 2007;92(4):1424–1429.  
19. Brito VN, Batista MC, Borges MF, et al. Diagnostic value of fluorometric assays in the evaluation of precocious puberty. _J Clin Endocrinol Metab_ . 1999;84(10):3539–3544.  
20. Neely EK, Hintz RL, Wilson DM, et al. Normal ranges for immunochemiluminometric gonadotropin assays. _J Pediatr_ . 1995;127(1):40–46.  
21. Bizzarri C, Spadoni GL, Bottaro G, et al. The response to gonadotropin releasing hormone (GnRH) stimulation test does not predict the progression to true precocious puberty in girls with onset of premature thelarche in the first three years of life. _J Clin Endocrinol Metab_ . 2014;99(2):433–439.  
22. Brito VN, Latronico AC, Arnhold IJP, Mendonca BB. A single luteinizing hormone determination 2 hours after depot leuprolide is useful for therapy monitoring of gonadotropin-dependent precocious puberty in girls. _J Clin Endocrinol Metab_ . 2004;89(9):4338–4342.  
23. Freire AV, Escobar ME, Gryngarten MG, et al. High diagnostic accuracy of subcutaneous T riptorelin test compared with Gn RH test for diagnosing central precocious puberty in girls. _Clin Endocrinol (Oxf)_ . 2013;78(3):398–404.  
24. Tonini G, Marinoni S, Forleo V, Rustico M. Local reactions to luteinizing hormone releasing hormone ananlog therapy. _J Pediatr_ . 1995;126(1):159.  
25. Monte O, Longui CA, Calliari LEP. Puberdade precoce: dilemas no diagnóstico e tratamento. _Arq Bras Endocrinol Metabol_ . 2001;45(4):321–330.  
26. Herter LD, Golendziner E, Flores JAM, et al. Ovarian and uterine findings in pelvic sonography: comparison between prepubertal girls, girls with isolated thelarche, and girls with central precocious puberty. _J Ultrasound Med_ . 2002;21(11):1237–1246.  
27. Neely EK, Hintz RL, Parker B, et al. Two-year results of treatment with depot leuprolide acetate for central precocious puberty. _J Pediatr_ . 1992;121(4):634–640.  
28. Bangalore Krishna K, Fuqua JS, Rogol AD, et al. Use of Gonadotropin-Releasing Hormone Analogs in Children: Update by an International Consortium. _Horm Res Paediatr_ . 2019;91(6):357–372. doi:10.1159/000501336  
29. Klein KO, Freire A, Gryngarten MG, et al. Phase 3 trial of a small-volume subcutaneous 6-month duration leuprolide acetate treatment for central precocious puberty. _J Clin Endocrinol Metab_ . 2020;105(10):e3660–e3671.  
30. Brasil. Ministério da Saúde. Secretaria de Ciência T. _Acetato de leuprorrelina subcutânea 45mg para tratamento de puberdade precoce central. Relatório de Recomendação n°666_ .; 2021.  
31. Isaac H, Patel L, Meyer S, et al. Efficacy of a monthly compared to 3-monthly depot GnRH analogue (goserelin) in the treatment of children with central precocious puberty. _Horm Res Paediatr_ . 2007;68(4):157–163.  
32. Trueman JA, Tillmann V, Cusick CF, et al. Suppression of puberty with long‐acting goserelin (Zoladex‐LA): effect on gonadotrophin response to GnRH in the first treatment cycle. _Clin Endocrinol (Oxf)_ . 2002;57(2):223–230.  
33. Brasil. Ministério da Saúde S de C Tecnologia e Insumos Estratégicos. _Embonato de triptorrelina 22,5 mg administração semestral para o tratamento de puberdade precoce central. PORTARIA SCTIE/MS N_<sup>_o_</sup> _27_ .; 2022.  
34. Badaru A, Wilson DM, Bachrach LK, et al. Sequential comparisons of one-month and three-month depot leuprolide regimens in central precocious puberty. _J Clin Endocrinol Metab_ . 2006;91(5):1862–1867.  
35. Bhatia S, Neely EK, Wilson DM. Serum luteinizing hormone rises within minutes after depot leuprolide injection: implications for monitoring therapy. _Pediatrics_ . 2002;109(2):e30–e30.  
36. Acharya S V, Gopal RA, George J, Bandgar TR, Menon PS, Shah NS. Utility of single luteinizing hormone determination 3 h after depot leuprolide in monitoring therapy of gonadotropin-dependent precocious puberty. _Pituitary_ . 2009;12(4):335–338.  
37. Kumar M, Mukhopadhyay S, Dutta D. Challenges and controversies in diagnosis and management of gonadotropin dependent precocious puberty: an Indian perspective. _Indian J Endocrinol Metab_ . 2015;19(2):228.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: MEDROXIPROGESTERONA, CIPROTERONA, GOSSERRELINA, LEUPRORRELINA E TRIPTORRELINA. -->
Eu,  
_______________________________________________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso do(s) medicamento(s) gosserrelina, leuprorrelina, triptorrelina e ciproterona, indicados para o tratamento da Puberdade Precoce Central.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a)  
(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- regressão do amadurecimento sexual (caracteres sexuais secundários);  
- diminuição da velocidade de crescimento;  
- regressão dos níveis de hormônios (gonadotrofinas).  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais  eventos adversos e riscos:  
- seu uso é contraindicado em gestantes ou em mulheres planejando engravidar;  
- - seu uso é contraindicado para mulheres amamentando;  
- os eventos adversos já relatados são:  
- gosserrelina: calorões, distúrbios menstruais, visão borrada, diminuição da libido, cansaço, dor de cabeça, náusea, vômitos, dificuldade para dormir, ganho de peso, vaginite. Os mais raros incluem angina ou infarto do miocárdio, tromboflebites.  
- leuprorrelina: calorões, diarreia, distúrbios menstruais, arritmias cardíacas, palpitações, boca seca, sede, alterações do apetite, ansiedade, náusea, vômitos, desordens de personalidade, desordens da memória, diminuição da libido, ganho de peso, dificuldades para dormir, delírios, dor no corpo, perda de cabelo e distúrbios oftalmológicos.  
- triptorrelina: calorões, dores nos ossos, impotência, dor no local da injeção, hipertensão, dores de cabeça, dores nas pernas, fadiga, vômitos, insônia, tonturas, diarreia, retenção urinária, infecção do trato urinário, anemia, prurido.  
- ciproterona: cansaço, diminuição da vitalidade e da capacidade de concentração, toxicidade hepática;  
- - medroxiprogesterona: presença ou histórico de tromboflebite, distúrbios tromboembólicos e cerebrovasculares. Insuficiência hepática grave. Presença ou suspeita de doença maligna de órgãos genitais. Sangramento vaginal de causa não diagnosticada.  
- medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos;  
- o risco de ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei tam bém que continuarei a ser atendido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações rela tivas ao meu tratamento, desde que assegurado o anonimato.  
( ) Sim ( ) Não  
O meu tratamento constará do seguinte medicamento:  
- ( ) gosserrelina  
- ( ) leuprorrelina  
- ( ) triptorrelina  
- ( ) ciproterona  
- ( ) medroxiprogesterona  
<!-- Start of picture text -->
Local:  Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:  CRM:  UF:<br>Assinatura e carimbo do médico Data:<br><!-- End of picture text -->  
Nota: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: EVOLUÇÃO PUBERAL CONFORME OS CRITÉRIOS DE TANNER -->
**Figura 1** – Estágios de Tanner no sexo feminino (estádios da mama e pilificação).  
Fonte: Sociedade Brasileira de Pediatria<sup>7</sup> . Disponível em https://www.sbp.com.br/fileadmin/user_upload/2016/10/EstgioPuberal.TannerMeninas.pdf.  
**Figura 2 -** Estágios de Tanner no sexo masculino (evolução gonadal, peniana, pilificação e volume testicular). Fonte: Sociedade Brasileira de Pediatria<sup>7</sup> . Disponível em <u>https://www.sbp.com.br/fileadmin/user_upload/2016/10/EstgioPuberal.TannerMeninos.pdf</u>  
<!-- Start of picture text -->
DesenvolvimentoCritérios dePuberalTanner Feminino<br>‘Mamas Péos pubianos<br>t ey,<br>\<br>— aa<br>W<br>Sennier aaa ei ele<br>wae!<br>Ener Ca in<br>aitimace MO —————<br><!-- End of picture text -->  
<!-- Start of picture text -->
Genitalia DesenvolvimentoCritériosPuberalde Tanner MasculinoPélos pubianos<br>SE 7<br>wyy *<br>" UO7<br>cacalama lalate<br>wea<br>l<br>i<br>|es<br>Sacrtenanveen eabewse | |Sommers<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **APÊNDICE 2** -->
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Puberdade Precoce Central foi motivada, inicialmente, pela incorporação da nova apresentação no SUS do medicamento leuprorrelina, por meio da Portaria SCTIE/MS nº 69, de 28 de outubro de 2021. Conforme o Relatório de Recomendação nº 666, de 28 de setembro de 2021<sup>29</sup> , a Conitec recomendou a incorporação do acetato de leuprorrelina subcutânea 45mg para o tratamento de puberdade precoce central.  
A deliberação da Conitec, conforme reportado no Relatório de Recomendação nº 666 – Acetato de leuprorrelina subcutânea 45 mg para tratamento de puberdade precoce central (Portaria SCTIE/MS nº 69/2021) foi de recomendar a incorporação no SUS do acetato de leuprorrelina subcutânea 45 mg para tratamento de puberdade precoce central em pacientes com idade igual ou superior a 2 anos de idade. Além de ressaltados os benefícios acerca da vantagem posológica, que possibilitam maior adesão ao tratamento.  
Durante a atualização do documento, ocorreu também a incorporação de nova apresentação do medicamento embonato de triptorrelina para o tratamento da puberdade precoce central, por meio da Portaria SCTIE/MS nº 27, de 16 de março de 2022. Conforme o Relatório de Recomendação nº 717/2022 – a Conitec recomendou a incorporação do embonato de triptorrelina 22,5 mg para o tratamento da puberdade precoce central conforme estabelecido no Protocolo Clínico e Diretrizes Terapêuticas (PCDT), no âmbito SUS.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **2. Equipe de elaboração e partes interessadas** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) com a revisão externa de especialista.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **3. Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Puberdade Precoce Central foi apresentada à 97ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em março de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES), Secretaria de Atenção Primária à Saude (SAPS) e Secretaria de Vigilância em Saúde (SVS). Não houve questionamentos acerca da proposta apresentada e o PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **4. Consulta Pública** -->
A Consulta Pública nº 20/2022, do Protocolo Clínico e Diretrizes Terapêuticas de Puberdade Precoce Central, foi realizada entre os dias 14/04/2022 e 03/05/2022. Foram recebidas 35 contribuições, que podem ser verificadas em: <u>http://conitec.gov.br/images/Consultas/Relatorios/2022/20220413_PCDT_PuberdadePrecoceCentral_cp20.pdf></u>

---

<!-- METADADOS: doenca: Puberdade Precoce Central | secao: **5. Busca da evidência e recomendações** -->
Para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Puberdade Precoce Central, em 2017, foram realizadas buscas nas bases descritas a seguir até a data limite de 15 de outubro de 2009. Foram encontrados alguns ensaios clínicos randomizados para agonistas do hormônio liberador de gonadotrofinas ( _gonadotropin-releasing hormone_ , GnRH), mas que, por não contemplarem a faixa etária adequada, por indicação diversa de puberdade precoce, por associarem outro medicamento ao tratamento, como hormônio do crescimento, ou ainda por serem análises retrospectivas, não foram, portanto, incluídos. Dessa forma, foram avaliados os estudos mais relevantes disponíveis nas bases descritas, incluindo _guidelines_ e consensos. Em 04/12/2014, foi realizada atualização da busca na literatura com os critérios de inclusão  originalmente empregados.  
Na base MEDLINE/PubMed, foram realizadas duas buscas. A primeira utilizou a estratégia ("Puberty, Precocious"[Mesh]) AND "Diagnosis"[Mesh] com os filtros ensaio clínico, ensaio clínico randomizado, meta-análise, revisão sistemática, humanos. Nessa busca, foram localizados 23 estudos e nenhum foi incluído neste Protocolo Clínico e Diretrizes Terapêuticas (PCDT). A segunda busca foi realizada com os termos ("Puberty, Precocious"[Mesh]) AND "Therapeutics"[Mesh]e com os mesmos limites da busca anteriormente descrita. Nessa busca foram localizados 9 estudos, e nenhum foi incluído neste PCDT.  
Na base Embase também foram realizadas duas buscas. A primeira utilizou a estratégia 'precocious puberty'/exp AND 'diagnosis'/exp AND ([cochrane review]/lim OR [systematic review]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [2009-2014]/py. Nessa busca, foram identificados 8 estudos, e um foi incluído no PCDT. A segunda busca utilizou a estratégia 'precocious puberty'/exp AND 'therapy'/exp AND ([cochrane review]/lim OR [systematic review]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [2009-2014]/py. Essa busca identificou 11 estudos, e nenhum foi incluído na revisão do PCDT.  
Também foi realizada uma busca por revisões sistemáticas da Cochrane com o termo “puberty, precocious” no título, resumo ou palavras-chave, não havendo recuperação de nenhuma revisão completa.  
Foi ainda consultada a base de dados UpToDate 19.3 e foram incluídos artigos de conhecimento dos autores. Foram excluídos estudos com desfechos não clínicos, avaliando métodos de tratamento alternativos ou técnicas ou produtos não aprovados no Brasil, com problemas metodológicos ou resultados inconclusivos ou insuficientes para resultar em nova recomendação. Com o objetivo de responder aos questionamentos da consulta pública de setembro de 2016 e incluir os medicamentos medroxiprogesterona e ciproterona, foram incluídas mais quatro referências.  
Já para a presente atualização, focou-se nas informações referentes às tecnologias incorporadas, conforme os relatórios de recomendação da Conitec, estudos e diretrizes internacionais, mantendo-se a mesma estrutura metodológica.  
As perguntas de pesquisa avaliadas no momento da incorporação da nova apresentação dos medicamentos incluídos nesta atualização estão nos **quadros 1** e **2** .  
**Quadro 1 -** Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO)  
|Acetato de leuprorrelina subcut|ânea 45 mg para tratamento de puberdade precoce central|
|---|---|
|População|Pacientes diagnosticados com puberdade precoce central (PPC)|
|Intervenção (tecnologia)|Pacientes diagnosticados com puberdade precoce central (PPC)|
|Comparação|Leuprorrelina (em qualquer dose, frequência e via de administração) ou sem comparador.|
|Desfechos (Outcomes)|Eficácia:<br>• Desfecho primário:<br> Valor do hormônio luteinizante (LH) < 4 UI/L.<br>• Desfechos secundários:<br> Regressão dos caracteres sexuais secundários (estágios de Tanner),<br> Diminuição da velocidade de crescimento,<br> Regressão dos níveis de gonadotrofinas para valores pré-puberais,<br> Não progressão da idade óssea,<br> Satisfação com o tratamento,<br> Qualidade de vida.<br>Segurança: eventos adversos.|  
Tipo de estudo Revisões sistemáticas de ensaios clínicos, ensaios clínicos primários. Pergunta: Os diferentes esquemas terapêuticos de leuprorrelina apresentam equivalência em relação à eficácia e segurança no tratamento de pacientes com puberdade precoce central, com ênfase no esquema de 45 mg subcutâneo a cada 6 meses? **Fonte:** Conitec - Relatório Recomendação nº 666 setembro/2021. Disponível em: <u>http://conitec.gov.br/images/Relatorios/2021/20211103_Relatorio_666_Leuprorrelina_puberdade.pdf</u>  
**Quadro 2 -** Pergunta estruturada para elaboração do relatório de recomendação da tecnologia (PICO)  
|Embonato de triptorrelina 22,5 mg para o tratamento da puberdade precoce central|
|---|
|População<br>Pacientes diagnosticados com puberdade precoce central (PPC)|
|Intervenção (tecnologia)<br>Triptorrelina 22,5 mg|
|Comparador<br>Em aberto|
|Desfechos (Outcomes)<br>Eficácia e segurança|
|Tipo de estudo<br>Estudo clínico, revisão sistemática com ou sem meta-análise|
|Pergunta de pesquisa: A triptorrelina de 22,5 mg é eficaz e segura para o tratamento de puberdade precoce central?|  
**Fonte:** Conitec - Relatório Recomendação nº 717/2022. Disponível em:  
<u>http://conitec.gov.br/images/Relatorios/2022/20220317_Relatorio_717_triptorrelina_225mg_puberdade_precoce_central.pdf</u>

---

