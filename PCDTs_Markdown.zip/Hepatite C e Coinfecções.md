<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA SCTIE/MS Nº 39, DE 20 DE JULHO DE 2026  
Torna pública a decisão de atualizar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Hepatite C e Coinfecções.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe confere o art. 68 do Decreto nº 11.798, de 28 de novembro de 2023, e o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica atualizado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Hepatite C e Coinfecções.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico:  
https://www.gov.br/conitec/pt-br.  
Art. 3º Fica revogada a Portaria SCTIE/MS nº 84, de 19 de dezembro de 2018, publicada no Diário Oficial da União nº 244, de 20 de dezembro de 2018, Seção 1, pág. 187.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: FERNANDA DE NEGRI -->
1  
ANEXO

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1. INTRODUÇÃO -->
A hepatite C é a inflamação do fígado causada pelo _Hepacivirus hominis_ , conhecido popularmente como vírus da hepatite C (HCV). Trata-se de um vírus transmitido pela via sanguínea, em situações que incluem práticas inseguras de procedimentos com instrumentos contaminados que penetram na pele, transfusão de sangue ou hemoderivados não testados e uso de drogas injetáveis. As vias de transmissão vertical e sexual são menos comuns<sup>1</sup> .  
A hepatite C aguda é assintomática na maioria das pessoas que se infectam. Já a hepatite C crônica é caracterizada pela persistência do HCV por mais de seis meses, ocorre na maioria dos casos em adultos e constitui uma das principais causas de cirrose e carcinoma hepatocelular (CHC). O risco é agravado por diversos cofatores, como idade avançada no momento da infecção, sexo masculino, estado pós-menopausa, coinfecção por HIV ou vírus da hepatite B (HBV), HCV genótipo 3, abuso de bebidas alcoólicas, diabetes e obesidade<sup>1</sup> .  
O tratamento da hepatite C teve avanços transformadores a partir de 2010, e a infecção, antes conhecida por prognóstico reservado, tornou-se curável, na maioria dos casos, com a utilização de antivirais de administração oral de curta duração, que apresentam excelente eficácia, tolerância e segurança.  
Apesar de ser uma infecção para a qual não há vacina, as tecnologias disponíveis para o diagnóstico e tratamento da hepatite C no Sistema Único de Saúde (SUS) tornam possível alcançar a meta da Organização Mundial da Saúde (OMS), prevista na Estratégia Global do Setor de Saúde para as Hepatites Virais, de eliminar a hepatite C como problema de saúde pública até 2030<sup>2</sup> , da qual o Brasil é signatário. Portanto, o desafio atual é associar estratégias diagnósticas aos esquemas de tratamento simplificados e acessíveis no SUS, visando a identificar as pessoas assintomáticas que desconhecem seu status em relação ao HCV e tratá-las de forma simplificada. Essas medidas poderão auxiliar na redução de novos casos da infecção e minimizar as complicações tardias relacionadas, como a cirrose e o CHC.  
É imprescindível que esse esforço seja feito em todo o Brasil e com a maior celeridade possível. Para este objetivo, este PCDT fornece recomendações atualizadas, baseadas nas melhores evidências disponíveis, visando a subsidiar as equipes de saúde do país de forma simplificada e possibilitar a aplicação e adaptação das recomendações do tratamento da hepatite C às particularidades de seus territórios. Assim, espera-se ampliar o diagnóstico e tratamento da hepatite C no Brasil para tornar realidade a meta desafiadora da OMS de eliminar a hepatite C como problema de saúde pública na próxima década, o que certamente beneficiará milhares de pessoas vivendo com esta doença/infecção silenciosa no nosso país.  
A Atenção Primária à Saúde (APS), como porta de entrada preferencial e ordenadora do cuidado na rede de atenção à saúde, exerce papel fundamental na promoção da saúde, na prevenção de doenças, na identificação de fatores de risco e na detecção precoce, oportunizando, desta forma, a promoção de intervenções oportunas e o encaminhamento adequado para o nível especializado de atenção à saúde quando necessário. O vínculo contínuo com os usuários e a atuação direta no território, princípios e diretrizes basilares da APS, possibilitam uma abordagem longitudinal e integral, favorecendo, por conseguinte, melhores desfechos terapêuticos e o prognóstico dos casos, além de fortalecer a coordenação do cuidado ao longo do tempo.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1.1. Epidemiologia -->
Segundo estimativas da OMS, cerca de 50 milhões de pessoas viviam cronicamente infectadas pelo HCV em todo mundo até 2022, com aproximadamente um milhão de novas infecções por ano. Para o  
2  
mesmo ano, cerca de 242.000 pessoas morreram em decorrência da hepatite C, principalmente devido à cirrose e ao CHC. Até 2022, 12,5 milhões de pessoas foram tratadas, abaixo da meta global<sup>1</sup> .  
No Brasil, de 2000 a 2024, foram registrados 342.328 casos confirmados de hepatite C no Sistema de Informação de Agravos de Notificação (Sinan). Em 2024, a taxa de detecção dos casos confirmados de hepatite C no país foi de 9,1 casos por 100 mil habitantes<sup>3</sup> . Dentre todas as notificações, há o predomínio de homens com hepatite C acima de 40 anos, contudo 42,8% dos casos são mulheres. A região com a maior detecção de casos no país é a Sul, e a menor taxa de detecção é observada na região Nordeste<sup>3</sup> . A partir de 2015, a taxa de detecção de hepatite C no Brasil aumentou significativamente devido à mudança no critério de notificação para teste sorológico (anti-HCV reagente) ou molecular (HCV RNA detectado), tornando-o mais sensível. Verifica-se que, no período de 2000 a 2024, foram identificados no Brasil 476.528 casos com pelo menos um dos marcadores de hepatite C – anti-HCV ou HCV-RNA – reagente. Em 2024, a maior proporção de casos foi observada no Sudeste (50,0%), seguido das regiões Sul (28,4%), Nordeste (9,8%), Centro-Oeste (5,5%) e Norte (5,5%)<sup>3</sup> .  
A alta proporção de fontes ou mecanismo de infecção declarado como ignorado no Sinan (70,3%, em 2024)<sup>3</sup> tem dificultado a análise dos principais fatores de risco para a hepatite C no Brasil. No entanto, considerando-se apenas os casos com provável fonte de infecção conhecida entre 2000 e 2024 (135.975 casos), observou-se a seguinte distribuição dos fatores de risco: uso de drogas (26,1%), transfusão sanguínea (21,1%) e relação sexual (23,7%). Em 2024, os casos de infecções por via sexual foram duas vezes maiores que os casos de infecções relacionadas ao uso de drogas e quatro vezes superiores aos de infecções por via transfusional<sup>3</sup> , sugerindo mudança no perfil epidemiológico dos fatores de risco para aquisição da hepatite C no país. Salienta-se ainda a possibilidade de transmissão vertical do HCV, motivo pelo qual a sorologia para essa infecção se tornou obrigatória no pré-natal realizado no SUS.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1.2. Vigilância epidemiológica da hepatite C -->
A APS é a principal porta de entrada do SUS e desempenha papel estratégico na vigilância das hepatites virais, desde a identificação e testagem até o acompanhamento longitudinal dos casos e de seus contactantes. O vínculo contínuo com os usuários e a atuação direta no território possibilitam a detecção precoce, o encaminhamento oportuno e a coordenação do cuidado, além de contribuir para a produção de informações qualificadas sobre o comportamento dessas infecções e para o fortalecimento das ações de prevenção e promoção da saúde.  
Como parte integrante das ações de vigilância em saúde, recomenda-se o registro sistemático das informações de testagem, acompanhamento e tratamento das pessoas com hepatite C no Prontuário Eletrônico e-SUS APS, assegurando a rastreabilidade das condutas, o acompanhamento longitudinal e a integração dos dados clínicos e epidemiológicos. O registro no e-SUS APS não substitui a notificação no Sinan; ambos são complementares e interdependentes, compondo o sistema nacional de vigilância das hepatites virais e qualificando as informações utilizadas para a tomada de decisão em nível local e nacional.  
As hepatites virais são agravos de notificação compulsória desde 1996 por representarem um sério problema de saúde pública no Brasil. O objetivo geral da vigilância epidemiológica é monitorar o comportamento dessas infecções e seus fatores condicionantes e determinantes, com a finalidade de recomendar e adotar medidas de prevenção e controle, bem como avaliar seu impacto.  
Todos os casos confirmados e surtos devem ser notificados e registrados no Sinan por meio da “Ficha de Investigação das Hepatites Virais”, seguindo o fluxo local estabelecido. O prazo recomendado para a inserção dos dados no sistema, é de até sete dias após a notificação.  
As principais unidades de notificação incluem serviços de saúde públicos e privados, hemocentros e bancos de sangue, clínicas de hemodiálise, laboratórios públicos e privados, comunidade, escolas e creches, consultórios privados, entre outras. Após o preenchimento, as fichas de notificação/investigação devem ser encaminhadas à instância hierarquicamente superior (níveis municipal, regional, estadual ou federal) responsável pela vigilância epidemiológica. Todas as fichas e os respectivos instrutivos de  
3  
preenchimento estão disponíveis no Portal do Sinan: http://www.portalsinan.saude.gov.br/doencas-eagravos.  
Para fins de vigilância, considera-se um caso de infecção pelo HCV quando há resultados reagentes para um ou mais marcadores da infecção pelo vírus (ex.: anticorpos anti-HCV e HCV-RNA). No entanto, para a conclusão diagnóstica dos casos em que são realizados testes que detectam anticorpos (e não o vírus C), é mandatória a complementação através da detecção do HCV-RNA (ver seção _Diagnóstico laboratorial_ ).  
Além disso, os casos confirmados por testes moleculares ou por critério de óbito devem ter essa informação registrada na ficha de notificação, conforme as orientações do Guia de Vigilância em Saúde vigente.  
Após a notificação, deve-se iniciar a investigação epidemiológica com o preenchimento completo da Ficha de Notificação/Investigação das Hepatites Virais do Sinan. Todos os campos devem ser preenchidos, inclusive aqueles com informação negativa. Informações adicionais podem ser inseridas no campo de observações conforme as peculiaridades de cada caso. Durante a investigação, é necessário coletar dados clínicos e epidemiológicos, incluindo histórico de exposições de risco (como compartilhamento de objetos perfurocortantes, uso de drogas injetáveis, inaláveis ou pipadas, práticas de escarificação, tatuagens, piercings, procedimentos cirúrgicos, odontológicos, hemodiálise, transfusões anteriores a 1993, acidente com material biológico, acupuntura, endoscopias e outras práticas invasivas com possível falha de biossegurança), bem como antecedentes de relações sexuais desprotegidas ou de violência sexual. Deve-se ainda investigar contatos e comunicantes para identificar possíveis casos assintomáticos, prevenir a disseminação da doença e evitar surtos<sup>4</sup> .  
É importante reforçar a importância da atuação proativa das equipes de saúde na realização de ações de vigilância em saúde voltadas às hepatites virais, contemplando as etapas: identificação de casos, notificação oportuna, medidas de promoção, prevenção e controle. Essas ações incluem o reconhecimento de fatores de risco no território, a oferta de testagem rápida na comunidade e o diagnóstico precoce dos casos de hepatite C crônica. Outra ação importante é a celeridade no encaminhamento das pessoas diagnosticadas para o atendimento especializado, de acordo com os protocolos e fluxos locais.  
O reconhecimento do cenário epidemiológico local, contribui para a identificação e busca de populações prioritárias ou com fatores de risco para realizar a testagem, bem como a busca ativa de contatos e a promoção de ações extramuros, também são exemplos de atuação da APS no processo de redução de danos e eliminação da hepatite C em seu respectivo território. Destaca-se a importância da informação qualificada para o diagnóstico e monitoramento dos casos. Deve-se buscar a notificação correta dos casos com o preenchimento adequado dos campos, promovendo a confiabilidade dos dados informados, visando a subsidiar a elaboração de estratégias adequadas à realidade e a tomada de decisões assertivas para o sistema de saúde.  
Além da coleta e notificação, destaca-se a importância da análise regular dos dados. Recomendase que os registros do Sinan sejam avaliados pelo menos uma vez ao ano, com base em indicadores como: taxa de detecção de hepatite C e percentual de coinfecção de C com HIV. O uso de informações qualificadas e atualizadas permite o diagnóstico situacional e o monitoramento dos casos, subsidiando a elaboração de estratégias adequadas à realidade local e a tomada de decisões assertivas para o sistema de saúde<sup>4</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1.3. História natural da hepatite C -->
Por ser um vírus hepatotrópico, o HCV circulante entra nas células hepáticas, onde ocorre o processo de replicação viral ( **Figura 1** ), resultando em inflamação e necrose celular por diversos mecanismos. A imunidade inata do indivíduo atua como primeira defesa, mas é insuficiente para curar a infecção na maioria d  
os casos, resultando em infecção crônica seis meses após a infecção aguda<sup>5</sup> .  
4  
Figura 1 – Ciclo replicativo do vírus da hepatite C  
<!-- Start of picture text -->
oe2@ SS<br>= oO a (RNA © ~~<br>2 Q9) CAV AV AVE? ea “<br>yypw® AoS > < 73, @ »\<br>{ \)) zi Eg “4A N<br>\ \ MY ay (RNA |<br>\ 0 Reticul Se<br>A) e < n( ey Aa= (RNA *  ed- yy<br>eto REL SUVA Tela 4<br>° a Membranosa~~<br>=<br>°<br><!-- End of picture text -->  
Fonte: Adaptado de Moradpour, Penin e Rice, 2007<sup>5</sup> .  
Legenda: (a) Contato de internalização do vírion na célula; (b) liberação do RNA viral no citoplasma; (c) tradução e processamento da poliproteína viral; (d) replicação do RNA viral; (e) empacotamento do RNA viral e montagem da partícula; (f) maturação do vírion e liberação.  
Considerando que apenas 15% a 45% das pessoas eliminam espontaneamente o vírus no período de seis meses, entre 55% a 85% dos que adquirem a infecção aguda evoluem para a hepatite C crônica<sup>6</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1.3.1. Hepatite C aguda -->
Conceitualmente, a hepatite C aguda é definida como a infecção adquirida há menos de seis meses. Aproximadamente 80% das pessoas com infecção aguda não apresentam manifestações clínicas. Para os 20% sintomáticos, o período entre a exposição e o início das manifestações clínicas varia de duas a 12 semanas. As manifestações clínicas incluem principalmente febre, fadiga, náusea, vômito, diarreia, dor abdominal, urina escura e icterícia. Como as manifestações clínicas são geralmente leves e inespecíficas, o diagnóstico da hepatite C aguda pode passar despercebido<sup>7</sup> .  
Devido à dinâmica dos marcadores da infecção (anti-HCV e HCV-RNA), o diagnóstico nessa fase apresenta algumas particularidades<sup>7,8</sup> . O melhor método de diagnóstico na fase aguda é a detecção do HCV RNA. A sorologia pode demorar semanas para se tornar reagente (50 a 70 dias, até 6 meses).  
Embora a maioria das pessoas com infecção aguda pelo HCV tenha persistência viral e evolua para infecção crônica, cerca de 15% a 45% apresentam clareamento espontâneo do vírus no período de até seis meses. Vários fatores virais e do hospedeiro, incluindo sexo, raça, coinfecção por HIV ou HBV, apresentação de icterícia, polimorfismo da interleucina-28B, antígenos leucocitários humanos de classe II (HLA), resposta de células T específicas, genótipo viral, nível máximo de RNA do HCV e diversidade de quais espécies virais podem afetar o curso e o resultado da infecção aguda pelo HCV<sup>7</sup> .  
O diagnóstico da hepatite C aguda é um desafio na prática clínica. A infecção aguda, assintomática na maioria dos casos, não contribui, portanto, para a suspeita diagnóstica na ausência de outras manifestações clínicas. Por esta razão, o diagnóstico da hepatite C aguda requer ações proativas dos profissionais de saúde, como a verificação de fatores de risco e vulnerabilidade e a oferta de testagem. Para informações relacionadas ao diagnóstico da hepatite C aguda, ver seção _Diagnóstico da hepatite C aguda_ .  
5

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1.3.2. Hepatite C crônica -->
A hepatite C crônica é uma infecção causada pelo HCV, caracterizada pela persistência do RNA viral e do anti-HCV por mais de seis meses. Trata-se de uma condição que frequentemente apresenta evolução silenciosa, uma vez que a maioria dos indivíduos permanece assintomática ou apresenta sintomas inespecíficos (como fadiga, mal-estar e desconforto abdominal leve), configurando um quadro oligossintomático<sup>9</sup> . Essa característica contribui para o diagnóstico tardio, muitas vezes realizado apenas em fases avançadas da doença, quando já se instalaram complicações como fibrose hepática, cirrose ou carcinoma hepatocelular. A ausência de sintomas específicos na fase inicial faz da hepatite C crônica um importante problema de saúde pública, reforçando a necessidade de estratégias de rastreamento populacional e diagnóstico precoce para reduzir a morbimortalidade associada.  
A hepatite C crônica não tratada pode evoluir para doença hepática progressiva, com risco de cirrose, insuficiência hepática, CHC e morte. Cerca de 14% a 19% das pessoas com hepatite C crônica desenvolvem cirrose em até 20 anos<sup>10</sup> . Em média, há risco anual de 7% das pessoas com cirrose apresentarem descompensação hepática, como ascite, sangramento gastrointestinal ou encefalopatia. A incidência anual de CHC em pessoas com cirrose pelo HCV pode atingir 4%<sup>11</sup> .  
Em pessoas com hepatite C crônica, os dois marcadores anti-HCV e HCV-RNA são positivos. Após conclusão do tratamento, havendo resposta virológica sustentada (RVS), o HCV-RNA torna-se indetectável e o anti-HCV permanece reagente por tempo indeterminado. Dessa forma, para o diagnóstico de reinfecção correto, deve-se confirmar a viremia (HCV-RNA detectável), não se utilizando o imunoensaio que detecta anticorpos anti-HCV. A coinfecção com o HIV tende a acelerar a progressão da fibrose hepática, conferindo particular importância para os sistemas de saúde<sup>6,8</sup> . Os medicamentos disponíveis no SUS para o tratamento da hepatite C podem ser usados concomitantemente à terapia antirretroviral (TARV), considerando as particularidades abordadas na seção _Coinfecção com HIV_ . Para mais informações sobre o cuidado de pessoas com coinfecção pelo HIV e HCV, consulte também o PCDT de Manejo da Infecção pelo HIV em Adultos, Módulo 2 - Coinfecções e Infecções Oportunistas vigente, disponível em <u>http://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u> e <u>https://www.gov.br/conitec/ptbr/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas.</u>

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 2. METODOLOGIA -->
O processo de desenvolvimento desse PCDT seguiu recomendações das Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 4. CRITÉRIOS DE INCLUSÃO -->
Estão incluídas neste Protocolo as pessoas que atendam a um dos seguintes critérios:  
6  
 Populações mais vulnerabilizadas à infecção pelo HCV, para fins de testagem e diagnóstico, conforme item _Populações prioritárias para rastreio;_  
 Possuam diagnóstico confirmado de infecção aguda ou crônica pelo HCV, conforme os critérios estabelecidos no item _Diagnóstico laboratorial_ . De forma geral, todas as pessoas com infecção pelo HCV têm indicação de tratamento, independentemente da presença e estadiamento da fibrose hepática, doença renal crônica e coinfecção com HIV ou HBV, entre outros.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 5. CRITÉRIOS DE EXCLUSÃO -->
Estão excluídas deste Protocolo as pessoas que atendam a um dos seguintes critérios:  
- Crianças com idade inferior a três anos;  
- Pacientes oncológicos com cirrose Child-Pugh B ou C, ou cuja expectativa de vida seja inferior a 12 meses, sem remissão da doença (nos casos de doença em remissão, a indicação de tratamento poderá ser individualizada);  
- Pacientes adultos com cirrose descompensada e indicação de transplante hepático com MELD score ≥ 20, ainda não submetidos a transplante hepático. Caso o tempo de espera na fila para o transplante seja superior a seis meses, a indicação do tratamento medicamentoso poderá ser discutida individualmente;  
- Pacientes cuja expectativa de vida for inferior a 12 meses, devido à existência de comorbidades ou de hepatopatia que não pode ser remediada por tratamento de hepatite C ou transplante hepático<sup>12</sup> ;  
Ainda, pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a qualquer dos medicamentos preconizados neste Protocolo deverão ser excluídos ao uso do respectivo medicamento.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 6. TRANSMISSÃO -->
O HCV é um vírus transmitido pela via sanguínea e, na maioria das vezes, a infecção ocorre em cenários em que há contato com material biológico contendo sangue contaminado<sup>1,6</sup> .  
**As formas de transmissão da hepatite C podem ser resumidas em quatro categorias principais: a) uso de drogas ou medicamentos injetáveis; b) relações sexuais desprotegidas e atividades sexuais de risco; c) transmissão associada a procedimentos médicos invasivos ou estéticos (como manicure, tatuagens, piercings) com material contaminado; e d) transmissão vertical**<sup>1</sup> **.**  
As características da transmissão do HCV aumentam as chances de infecção de algumas pessoas que podem estar em maior vulnerabilidade, como aquelas que injetam drogas, aquelas que têm contato frequente com serviços ou procedimentos de saúde (como diálise e procedimentos invasivos), profissionais de saúde, contatos domiciliares de pessoas com hepatite C, pessoas vivendo com HIV/aids (PVHA), crianças nascidas de mães com hepatite C, trabalhadores(as) sexuais, homens que fazem sexo com homens (HSH), pessoas transexuais e população privada de liberdade, entre outras<sup>13,14</sup> .  
Ainda com base nas características da transmissão do HCV, as formas de prevenção incluem medidas rígidas de biossegurança em hemocentros, na doação de órgãos e tecidos, nas unidades de saúde e no manuseio de material biológico, no uso e descarte corretos de equipamentos de biossegurança, no fornecimento programático de agulhas e seringas estéreis para pessoas que injetam drogas e em políticas de incentivo ao uso de preservativos durante a atividade sexual<sup>8</sup> .  
7  
O risco de transmissão vertical do HCV é de aproximadamente 3% a 5%, mas aumenta significativamente se a mãe for coinfectada pelo HIV (19%)<sup>15</sup> . O parto cesáreo não diminui a chance de transmissão vertical e não há evidências de transmissão do vírus pelo leite materno<sup>16,17</sup> ; portanto, não há contraindicação para o aleitamento materno. Os medicamentos disponíveis no SUS para o tratamento da hepatite C não estão aprovados para uso em gestantes. Por isso, é muito importante que pessoas em idade fértil, sobretudo as que planejam ter filhos, sejam testadas para hepatite C. As mulheres vivendo com HCV devem ser tratadas antes da gestação, idealmente.  
Para mais informações sobre estratégias de prevenção da hepatite C consulte o PCDT para Profilaxia Pré Exposição ao HIV (PrEP), o PCDT para Profilaxia Pós-Exposição (PEP) de Risco à Infecção pelo HIV, IST e Hepatites Virais, e o PCDT para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais, em <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u> e <u>https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-ediretrizes-terapeuticas.</u>

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 7. PREVENÇÃO DA HEPATITE C -->
A implementação de ações de prevenção busca a redução de riscos à saúde da população, além da promoção da redução das desigualdades sociais e da eliminação dos obstáculos para sua consecução, contribuindo assim para o fortalecimento do direito universal à saúde. A maneira mais eficaz de prevenir a hepatite C consiste em evitar principalmente o contato com sangue contaminado e com outros fluídos corporais.  
As estratégias recomendadas para prevenir a hepatite C incluem o uso seguro e adequado de instrumentos para os diversos procedimentos de saúde, o manuseio e descarte seguros de seringas, agulhas e demais resíduos passíveis de contaminação, a oferta de ações de redução de danos para pessoas que usam drogas por via injetável, inalável ou as fumadas, incluindo programas de troca de seringas, realização de rastreio em bancos de sangue e esterilização de materiais utilizados em procedimentos cirúrgicos, odontológicos e de hemodiálise.  
Também é importante orientar as pessoas sobre a importância de evitar o compartilhamento de objetos pessoais de higiene que possam conter sangue, como lâminas de barbear, navalhas e demais instrumentos de depilação, escovas de dentes e materiais utilizados na manicure e pedicure (alicates de cutícula, lixas, espátulas etc.).  
Ademais, as pessoas que fazem uso de drogas injetáveis, inaláveis ou fumadas devem ser informadas acerca da necessidade de não compartilhar agulhas, seringas, canudos ou cachimbos e outros objetos utilizados para fumar o crack. Recomenda-se ainda a utilização de preservativos internos (vaginais) ou externos (penianos) durante a relação sexual, como medida eficaz na prevenção. Para usuários infectados, recomenda-se garantir o esquema completo das vacinas para as hepatites A e B, além do tratamento antiviral completo para obtenção da cura e, para os contatos, ofertar a vacina para hepatite B, caso sejam suscetíveis. Outras recomendações são evitar compartilhar objetos perfurocortantes e de higiene pessoal, cobrir feridas e limpar respingos de sangue. Pessoas com hepatite C não podem doar sangue ou esperma<sup>4</sup> .  
Já os profissionais de saúde devem cumprir rigorosamente as normas universais de biossegurança e promover ações educativas. Assim, além das medidas de controle específicas para as hepatites virais, é imprescindível implementar programas de educação continuada e permanente destinados aos profissionais de saúde, bem como as atividades de educação em saúde voltadas à comunidade em geral, com ênfase especial nos segmentos mais vulneráveis às hepatites virais<sup>18</sup> .  
8

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 7.1. Prevenção direcionada em populações mais vulnerabilizadas -->
Algumas populações apresentam um risco elevado de infecção pelo HCV, em decorrência de vulnerabilidades enfrentadas por esses grupos. Entre eles, encontram-se as pessoas privadas de liberdade, pessoas em situação de rua, pessoas que usam álcool e outras drogas, bem como populações indígenas, quilombolas e ribeirinhas. Ademais, destaca-se também as pessoas trans e travestis, trabalhadoras do sexo, homens gays e demais homens que fazem sexo com homens (HSH), pessoas vivendo com HIV/aids, pessoas em diálise, profissionais de saúde bucal, bem como trabalhadores(as) de serviços como manicures, pedicures, colocadores de piercing corporal e tatuadores e, principalmente as pessoas que utilizam esses serviços.  
Dessa forma, torna-se imprescindível que a equipe multiprofissional possua um sólido conhecimento técnico acerca do tema. A oferta de testes rápidos deve ser realizada de maneira oportuna e executada de acordo com as recomendações do fabricante. A realização de testes de triagem e a confirmação diagnóstica do HCV, especialmente para populações mais vulnerabilizadas, é fundamental para o controle da doença.  
Nesse processo, as equipes da APS, em especial os Consultórios na Rua e as Equipes de Saúde Prisional, desempenham papel estratégico na ampliação do acesso às ações de prevenção, diagnóstico e cuidado. Sua inserção territorial e abordagem centrada nas necessidades das populações mais vulneráveis possibilitam a identificação precoce de casos, a vinculação ao cuidado e o acompanhamento longitudinal, contribuindo para a efetividade das estratégias de eliminação das hepatites virais no Brasil.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 7.2. Prevenção da reinfecção -->
A reinfecção pelo HCV pode ocorrer em indivíduos que previamente tiveram contato com o vírus e alcançaram a cura espontânea, ou a resposta virológica sustentada após tratamento, especialmente quando permanecem expostos aos mesmos fatores de risco associados à transmissão<sup>19</sup> . Esses fatores incluem o compartilhamento de agulhas, seringas e outros instrumentos utilizados para consumo de drogas, a reutilização ou inadequada esterilização de equipamentos médicos, odontológicos ou de estética, bem como o uso de materiais não esterilizados em procedimentos de tatuagem e colocação de piercings. Embora seja menos frequente, a reinfecção por via sexual também pode acontecer, sobretudo em contextos de relações desprotegidas, assim como por transmissão vertical em uma proporção menor. Dessa forma, a manutenção de medidas preventivas é essencial mesmo após a obtenção da cura da hepatite C, considerando que o anticorpo anti-HCV não confere imunidade à infecção<sup>19</sup> .  
É imprescindível que todas as pessoas tratadas para o HCV sejam orientadas quanto ao risco da reinfecção. Nesse sentido, devem ter acesso às orientações sobre todas as formas de transmissão do vírus e os comportamentos com exposição de risco a uma nova infecção. Nesse contexto, a educação em saúde assume papel fundamental, assim como a elaboração conjunta de um projeto terapêutico singular, considerando o contexto de vida de cada usuário(a). Isso viabiliza a compreensão dos modos de transmissão do vírus e a adoção de comportamentos preventivos. Dessa forma, o acesso a informações precisas e contínuas deve ser considerado um componente essencial do cuidado em saúde, garantindo a efetividade do tratamento e contribuindo para a diminuição das taxas de reinfecção.  
9

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 7.3. Vacina para HAV e HBV para pessoas suscetíveis -->
A imunização constitui medida essencial na prevenção de coinfecções virais em pessoas com infecção pelo HCV. Embora ainda não exista vacina específica para o HCV, é fundamental avaliar a suscetibilidade às hepatites A e B e ofertar a vacinação aos indivíduos não imunes, conforme o esquema vigente do Programa Nacional de Imunizações (PNI).  
**Pessoas com hepatite C têm indicação de vacinação para hepatite A, se estiverem suscetíveis** 21 **.**  
**A vacinação para hepatite B no Brasil é indicada para todas as pessoas, em todas as idades.**

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: **Vacina para hepatite A** -->
A vacina para hepatite A é indicada para todas as crianças a partir de 15 meses de idade, em dose única (podendo ser aplicada até 4 anos, 11 meses e 29 dias). Entretanto, para crianças com hepatopatia crônica ou infecção pelo HCV, a recomendação é realizar o esquema completo de duas doses (com intervalo de 6 meses entre elas), mediante prescrição médica e comprovação da condição clínica<sup>20</sup> .  
Esta vacina também é indicada para algumas situações especiais, incluindo as pessoas com infecção pelo HCV que tenha sorologia negativa para anti-HAV IgG. O esquema vacinal para pessoas com infecção pelo HCV consiste em duas doses, com intervalo de seis meses entre elas<sup>20</sup> . A aplicação pode ser realizada em qualquer unidade integrante da Rede de Imunobiológicos para Pessoas com Situações Especiais (RIE), composta pelos Centros de Referência em Imunobiológicos Especiais (CRIE), Centros Intermediários de Imunobiológicos Especiais (CIIE) e as salas de vacina do SUS<sup>21</sup> .  
Considerando que alguns imunobiológicos originalmente destinados a situações especiais já são ofertados nas UBS cadastradas na rede, essas unidades também devem ser reconhecidas como parte ativa da RIE, assim, quando o imunobiológico estiver disponível no estoque local, a imunização pode ser realizada diretamente na sala de vacina. Essa estratégia amplia o acesso da população, evita encaminhamentos desnecessários aos CRIE e reforça a equidade na oferta de imunização para pessoas com condições clínicas especiais.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: **Vacina para hepatite B** -->
A vacina da hepatite B tem indicação universal e está disponível para todas as pessoas, em todas as faixas etárias. De forma geral, para crianças, a vacina para hepatite B deve ser administrada preferencialmente ainda no período neonatal (nas primeiras 12 horas a 24 horas do nascimento), conforme calendário vacinal preconizado pelo PNI. O esquema básico consiste em três doses (0, 1 e 6 meses), podendo ser realizada em formulação monovalente ou combinada (penta ou hexa)<sup>22</sup> .  
Esta dose do período neonatal constitui uma etapa essencial, sobretudo para a profilaxia de crianças expostas ao vírus da hepatite B para a prevenção da transmissão vertical. No entanto, a recomendação é aplicável a todas as crianças, independentemente do contexto. Recomenda-se que a criança receba a vacina nas primeiras horas de vida. Caso a criança não seja atendida dentro do período recomendado, poderá receber a primeira dose até os 30 dias de vida. Se essa administração não ocorrer nesse intervalo, a vacinação não será mais realizada neste momento, e a imunização subsequente para hepatite B deverá ser efetuada aos 2, 4 e 6 meses de idade, por meio da vacina pentavalente. Para informações adicionais acerca do calendário vacinal, recomenda-se consultar o site do Ministério da Saúde (https://www.gov.br/saude/pt-br/vacinacao/calendario).  
Crianças imunossuprimidas, em uso de tratamento imunomodulador ou com doença hepática avançada podem necessitar de dose dobrada ou reforço sorológico, conforme avaliação clínica individualizada e orientações do Manual dos CRIE.  
10  
Para adultos não imunizados e suscetíveis à hepatite B (HBsAg, anti-HBc e anti-HBs não reagentes), utiliza-se o esquema de três doses, com intervalos de um e cinco meses entre elas. Em casos de imunossupressão ou doença hepática avançada, recomenda-se o esquema com dose dobrada, conforme avaliação clínica<sup>20</sup> . O **Quadro 1** sumariza os esquemas vacinais das hepatites A e B para crianças com hepatite C e o **Quadro 2** , para adultos com hepatite C.  
Quadro 1 - Esquema vacinal de hepatites A e B recomendado para crianças com hepatite C  
|**Vacina**|**Indicação**|**Esquema vacinal**|**Disponibilidade no**<br>**SUS**|
|---|---|---|---|
|Hepatite B|Crianças<br>e<br>adolescentes<br>com<br>infecção pelo HCV<br>suscetíveis (HBsAg,<br>anti-HBc e anti-HBs<br>não reagentes).|Esquema de 3 doses (intervalos: 0, 1<br>e 6 meses).<br>Recém-nascidos:<br>1ª<br>dose<br>ao<br>nascimento (monovalente), seguida<br>de<br>três<br>doses<br>subsequentes<br>combinadas (penta ou hexa, aplicadas<br>com 2, 4 e 6 meses de idade).<br>Crianças não vacinadas ou com<br>esquema<br>incompleto<br>devem<br>completar o esquema padrão.<br>Em casos de imunossupressão ou<br>doença hepática avançada, considerar<br>dose dobrada (40 µg) e controle<br>sorológico pós-vacinação (anti-HBs ≥<br>10 mUI/mL).|Disponível<br>rotineiramente nas salas<br>de vacinação das UBS.|
|Hepatite A|Crianças ≥ 12 meses<br>com<br>infecção<br>crônica pelo HCV e<br>sorologia<br>negativa<br>para anti-HAV IgG.|Esquema de 2 doses (intervalo: 0 e 6<br>meses).<br>Crianças com hepatopatia crônica ou<br>HCV devem receber o esquema<br>completo de 2 doses, mediante<br>prescrição médica.|Disponível na RIE, que<br>inclui<br>as<br>salas<br>de<br>vacinação<br>das<br>UBS,<br>bastando comprovação<br>da condição (prescrição<br>médica).|  
Fonte: Adaptado de Ministério da Saúde (Manual CRIE; Nota Técnica nº 58/2025; Calendário de Vacinação)<sup>20–22</sup> .  
11  
Quadro 2 - Esquema vacinal de hepatites virais recomendado para adultos com hepatite C  
|**Vacina**|**Indicação**|**Esquema vacinal**|**Disponibilidade no SUS**|
|---|---|---|---|
|Hepatite B|Pessoas com infecção<br>pelo HCV suscetíveis<br>(HBsAg, anti-HBc e<br>anti-HBs<br>não<br>reagentes).|Três doses (intervalos: 0, 1 e 6<br>meses). Em imunossuprimidos<br>ou<br>com<br>doença<br>hepática<br>avançada,<br>considerar<br>dose<br>dobrada.|Disponível na RIE, que<br>inclui as salas de vacinação<br>das UBS.|
|Hepatite A|Pessoas com infecção<br>crônica pelo HCV e<br>sorologia<br>negativa<br>para anti-HAV IgG.|Duas doses, com intervalo de<br>seis meses entre elas (0 e 6<br>meses).|Disponível na RIE, que<br>inclui as salas de vacinação<br>das<br>UBS,<br>bastando<br>comprovação da condição<br>(prescrição médica).|  
Podem ser administradas concomitantemente a outras vacinas do calendário vacinal preconizado pelo PNI, independentemente do intervalo entre as aplicações.  
Fonte: Adaptado de Ministério da Saúde (Manual CRIE; Nota Técnica nº 58/2025; Calendário de Vacinação)<sup>20–22</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: **Registro e monitoramento** -->
O registro das doses aplicadas deve ser realizado no Prontuário Eletrônico e-SUS APS, ou na Coleta de Dados Simplificada - CDS; ou, ainda, nos sistemas próprios ou de terceiros devidamente integrados à Rede Nacional de Dados em Saúde (RNDS), no âmbito da APS<sup>23</sup> . Nos casos de vacinação realizada em maternidades e outros pontos da RIE, o registro deve ocorrer no Sistema de Informação do Programa Nacional de Imunizações (SI-PNI)<sup>20</sup> . É essencial que o sistema utilizado para o registro das vacinas esteja integrado à RNDS, que promove a interoperabilidade das informações em todo o território nacional, viabilizando o monitoramento das coberturas vacinais e fortalecendo a gestão das ações de imunização no país. A APS tem papel estratégico nesse processo, sendo responsável pela identificação de suscetíveis, imunização, orientação e acompanhamento da adesão vacinal. O fortalecimento dessas ações é fundamental para a prevenção de complicações hepáticas e para o cumprimento das metas de eliminação das hepatites virais como problema de saúde pública<sup>18</sup> .  
Por fim, a análise das coberturas vacinais é de suma importância para identificar regiões com populações suscetíveis às hepatites A e B, o que possibilita o desenvolvimento de estratégias específicas que promovam o aumento da vacinação e a diminuição da vulnerabilidade dessas comunidades.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 8. POPULAÇÕES PRIORITÁRIAS PARA RASTREIO -->
Com o objetivo de eliminar a hepatite C como problema de saúde pública até 2030, é fundamental ampliar o acesso ao diagnóstico e ao tratamento em todo o território nacional. Para isso, a oferta de testes diagnósticos deve ser feita de forma estratégica, considerando as particularidades dos grupos populacionais de maior risco e demais grupos. Com a disponibilização dos esquemas de tratamento seguros e altamente eficazes, o diagnóstico das pessoas que desconhecem seu status de infecção pelo HCV tornou-se o maior desafio no SUS.  
12  
Em abril de 2020, o Centro de Controle e Prevenção de Doenças ( _CDC -  Centers for Disease Control and Prevention)_ atualizou a normativa do rastreio do HCV, recomendando realizar o rastreio, pelo menos uma vez na vida, em todos os adultos com idade igual ou maior que 18 anos, e testar as pessoas grávidas (em cada gravidez), exceto em locais onde a prevalência do HCV é menor que 0,1%. A justificativa inclui a análise da relação custo-eficácia, a maior detecção de casos, a mudança no perfil epidemiológico com infecções incidentes em adultos jovens e a disponibilidade de tratamento antiviral seguro e econômico. Além disso, considerou-se que a triagem universal é um componente essencial e necessário de qualquer estratégia de eliminação do HCV<sup>24</sup> .  
Portanto, considerando que a prevalência estimada de hepatite C no Brasil é 0,3%<sup>25</sup> e com base no projeto de eliminação das hepatites virais da OMS, do qual o Brasil é signatário, este Protocolo recomenda que todas as pessoas a partir de 18 anos sejam testadas pelo menos uma vez na vida para o HCV. Reforça-se a importância de estratégias de intensificação da testagem oportuna e/ou busca ativa para a faixa etária de 40 anos ou mais, devido ao maior risco acumulado de exposição. **Enfatiza-se que pessoas com qualquer fator de risco ou que manifestem desejo de serem testadas devem realizar o exame, independentemente da idade** .  
Além disso, recomenda-se a testagem de gestantes no pré-natal em cada gestação. Profissionais de saúde e demais trabalhadores devem ser testados em todas as situações de acidente ou exposição a materiais com risco biológico<sup>26</sup> . Para pessoas que mantém vulnerabilidade à infecção, recomenda-se a testagem anual daqueles com anti-HCV não reagente. Já para os que eliminaram espontaneamente a infecção ou foram curados, recomenda-se a realização do HCV-RNA. As condições estão descritas a seguir:  
As condições, atividades e exposições a seguir configuram situações de vulnerabilidade aumentada para a infecção pelo HCV, nas quais a testagem deve ser estimulada e ofertada oportunamente<sup>26,27</sup> :  
- Pessoas que usam drogas ilícitas injetáveis, pipadas (p.ex. crack) ou inaladas (p.ex. cocaína);  
- Homens que fazem sexo com homens (HSH);  
- Pessoas que praticam de sexo químico (uso intencional de drogas não-prescritas para a realização de prática sexual, como forma de facilitar ou intensificar a experiência sexual);  
-  
- Pessoas em hemodiálise;  
- Crianças nascidas de mães com hepatite C;  
- Pessoas privadas de liberdade (PPL);  
- Pessoas que fizeram transfusão de sangue ou hemoderivados antes de 1992;  
- Pessoas que realizaram procedimentos estéticos, como piercings, tatuagens, entre outros;  
- Pessoas com outras hepatopatias crônicas, independentemente da etiologia;  
- Pessoas com diabete melito ou outras condições crônicas;  
- Pessoas com evidências clínicas de possíveis manifestações extra-hepáticas, como úlcera corneana (úlcera de Mooren), tireoidopatias, fibrose pulmonar, síndrome de Sjögren, doença renal crônica, vasculite sistêmica (poliarterite nodosa, poliangeíte microscópica), artralgias, mialgias, poliartrite inflamatória, trombocitopenia autoimune e disfunção neurocognitiva, entre outras.  
Em 2024, os casos de infecção adquirido por via sexual corresponderam a 41,5% das fontes de transmissão dispostas na ficha de notificação<sup>3</sup> , correspondendo a uma mudança no perfil epidemiológico dos fatores de risco para hepatite C no país. Por sua maior vulnerabilidade à exposição ao HCV, e com base nessa tendência de mudança, devem ser testadas pelo menos uma vez ao ano, ou em intervalo menor; se clinicamente indicado, as pessoas com uma ou mais das seguintes condições:  
- Pessoas vivendo com HIV/aids (PVHA);  
- Pessoas sexualmente ativas prestes a iniciar ou em uso de PrEP para o HIV (a indicação de testagem seguirá o protocolo de PrEP);  
- Pessoas trans;  
13  
- Trabalhadoras(es) do sexo;  
- Pessoas em situação de rua;  
- Pessoas que usam álcool e outras drogas (inaláveis, fumáveis ou injetáveis).  
Ressalta-se que os usuários de PrEP para o HIV têm indicação de realizar anti-HCV com frequência quadrimestral<sup>24,28</sup> .  
Pessoas diagnosticadas com hepatite C devem ser orientadas quanto às estratégias de prevenção combinada ao HIV e às demais IST, considerando o contexto de vulnerabilidade compartilhada para diferentes infecções sexualmente transmissíveis. O aconselhamento e a oferta integrada de medidas de prevenção, incluindo testagem regular para HIV e outras IST, PrEP e PEP, vacinação quando indicada e uso de preservativos, conforme os próprios protocolos vigentes do Ministério da Saúde, sempre devem ser enfatizados. Essa proposta visa a fortalecer o cuidado integral centrado na pessoa e articular as políticas de HIV e/ou aids, hepatites virais e IST, em consonância com a atual mudança do perfil epidemiológico da hepatite C.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 9. DIAGNÓSTICO LABORATORIAL -->
As diretrizes para o diagnóstico da infecção pelo HCV estão descritas no **Manual Técnico para o Diagnóstico das Hepatites Virais** , disponível no link: <u>https://www.gov.br/aids/pt-br/central-deconteudo/manuais-tecnicos-para-diagnostico.</u>  
O **Quadro 3** descreve os principais métodos diagnósticos disponíveis e que devem ser utilizados de forma combinada, formando fluxogramas em série, conforme as recomendações do Manual. A combinação de testes sequenciais tem por objetivo aumentar o valor preditivo positivo de um resultado reagente no teste inicial.  
Quadro 3 - Métodos diagnósticos utilizados no diagnóstico da hepatite C  
|**Imunoensaios**|**Teste molecular**|
|---|---|
|**Pesquisa de anticorpos (anti-HCV):**<br>Pode ser realizada por teste rápido ou imunoensaio<br>laboratorial.<br>A presença do anti-HCV nestes testes indica contato prévio<br>com o vírus.<br>O anti-HCV pode permanecer positivo mesmo após a cura.<br>Sua função principal é de rastreio.|**Quantificação HCV-RNA**<br>Confirma a infecção ativa (replicação<br>viral).<br>Em princípio, todas as pessoas com<br>HCV-RNA detectável têm indicação de<br>tratamento medicamentoso.|
|**Pesquisa de antígenos (HCV-Ag):**<br>Teste laboratorial.||
|Confirma a infecção ativa.<br>Sua função principal é complementar o diagnóstico em caso<br>de resultado anti-HCV reagente.||  
Fonte: elaboração própria com base no Manual Técnico para o Diagnóstico das Hepatites Virais<sup>29</sup>  
O anti-HCV é o anticorpo produzido pelo sistema imunológico em resposta à infecção viral. Em geral, todas as pessoas infectadas pelo HCV produzem anti-HCV, com exceção de alguns casos específicos de imunodeficiência. Os anticorpos são detectados, em média, entre um e três meses após a exposição ao  
14  
vírus e costumam persistir por toda a vida independentemente da cura da infecção. Dessa forma, os testes que detectam anticorpos anti-HCV, em especial os testes rápidos pela agilidade nos resultados, são os recomendados para a investigação inicial da infecção. Em caso de amostra anti-HCV reagente, por teste rápido (TR) ou imunoensaio laboratorial, a investigação da infecção ativa deve ser complementada por teste de biologia molecular para a detecção do RNA viral ou por imunoensaio que detecte o antígeno do core do HCV.  
Em caso de resultado reagente para anti-HCV com resultado não detectável para HCV-RNA ou não reagente para HCV-Ag é considerado contato prévio ou infecção passada pelo HCV, sendo ainda possível uma infecção prévia curada por meio de tratamento.  
Se o resultado for não reagente para o anti-HCV e, caso a suspeita de infecção pelo HCV persista, sugere-se que uma nova amostra seja coletada 30 dias após a data da primeira amostra e o teste seja realizado novamente.  
**Os TR e imunoensaios laboratoriais que detectam anti-HCV são equivalentes**<sup>30</sup> **.** Dessa forma, após a realização do TR anti-HCV, cujo resultado for reagente, não há necessidade de confirmação adicional com utilização de ensaio laboratorial.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 9.1. Diagnóstico da hepatite C aguda e crônica -->
Os testes que detectam anticorpos anti-HCV geralmente tornam-se reagentes próximo do início das manifestações clínicas, em média entre um e três meses após a exposição<sup>31</sup> , razão pela qual são considerados testes limitados para o diagnóstico da infecção aguda<sup>6,31</sup>  
Já o HCV-RNA pode ser detectado no soro entre a primeira e a segunda semana após a exposição. A variação da viremia tem sido classificada em três fases:  
1) fase de pré-aceleração (2 a 14 dias após a exposição), com nível de detecção de RNA baixo ou indetectável;  
2) fase de elevação da viremia (8 a 10 dias seguintes à primeira fase), com aumento exponencial dos níveis séricos de RNA; e  
3) fase de platô da viremia (45 a 68 dias após a segunda fase), com estabilidade dos níveis séricos de HCV-RNA<sup>6</sup> .  
De modo geral, nos casos em que há suspeita de infecção aguda pelo HCV, o **Manual Técnico para o Diagnóstico das Hepatites Virais**<sup>29</sup> recomenda a realização de testes moleculares. O **Quadro 4** descreve critérios a serem considerados para o diagnóstico da hepatite C aguda e o **Quadro 5** descreve os critérios para definição de hepatite C crônica.  
15  
Quadro 4 – Critérios diagnósticos de hepatite C aguda  
|**Critérios**|**Descrição**|
|---|---|
|Imunológico¹|Paciente com resultado de exame anti-HCV prévio comprovadamente negativo (há<br>menos de seis meses) E<br>·    Anti-HCV reagente no início das manifestações clínicas OU<br>·    Anti-HCV reagente no momento da exposição OU<br>·    Anti-HCV reagente no segundo teste realizado com intervalo de 90 dias|
|Virológico²|HCV-RNA detectável na vigência de exame prévio documentado de anti-HCV não<br>reagente|  
Fonte: adaptado de Liu e Kao<sup>32</sup> . Legenda: HCV, vírus da hepatite C (do inglês _Hepatitis C virus_ ); RNA, ácido ribonucleico; ALT, alanina aminotransferase; LSN, limite superior da normalidade.  
Notas:<sup>1</sup> Em caso de anti-HCV reagente o diagnóstico deverá ser concluído com teste molecular. 2 No caso de teste molecular detectável o diagnóstico só será concluído após soroconversão para anti-HCV, a considerar o período de janela imunológica.  
A suspeição do diagnóstico de hepatite viral aguda baseia-se na identificação de manifestações clínicas e laboratoriais indicativas de dano hepático, caracterizadas por elevação de alanina aminotransferase (ALT), acompanhadas ou não de febre, náuseas, vômitos, diarreia, dor abdominal, fadiga, icterícia, colúria e acolia fecal. O reconhecimento de sinais, sintomas e alterações laboratoriais compatíveis com lesão hepática aguda é essencial para o direcionamento da investigação etiológica, que deve contemplar a pesquisa de marcadores sorológicos e a exclusão de causas não virais, como hepatite autoimune, doença hepática alcoólica, hepatotoxicidade medicamentosa e obstrução biliar.  
<u>Quadro 5 - Definição de Hepatite C crônica</u>  
|Hepatite C crônica é definida|Presença de Anti-HCV reagente por mais de seis meses|
|---|---|
|pela<br>associação<br>das<br>duas<br>condições:|HCV-RNA detectável por mais de seis meses|  
No contexto brasileiro, a pesquisa de coinfecções e a avaliação de fatores de risco epidemiológicos (transfusão sanguínea anterior a 1993, uso de drogas injetáveis, exposição ocupacional e procedimentos invasivos sem esterilização adequada) orientam a suspeição clínica e contribuem para o diagnóstico diferencial. A identificação precoce do agente etiológico é determinante para a instituição do cuidado terapêutico oportuno, a interrupção da cadeia de transmissão e a prevenção da progressão para fibrose hepática avançada, cirrose e carcinoma hepatocelular.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 9.2. Investigação laboratorial da criança exposta ao HCV -->
Todas as pessoas gestantes devem ser testadas para hepatite C pelo menos uma vez durante a gestação. Considera-se criança exposta ao HCV aquela que nasceu de mãe infectada pelo vírus, independentemente de apresentar sintomas ou alterações laboratoriais no período neonatal. Toda criança exposta ao HCV deve realizar um teste molecular entre 3 e 6 meses de idade.  
Se a carga viral for detectável, deve-se notificar o caso como HCV e a criança deve ser acompanhada como exposta. Aos 18 meses, a investigação com teste anti-HCV (laboratorial ou teste rápido) e carga viral HCV-RNA deve ser repetida.  
Se a carga viral for indetectável entre 3 e 6 meses, a criança deve continuar em acompanhamento como exposta ao HCV. Aos 18 meses de idade, deve ser realizado um teste anti-HCV (laboratorial ou teste rápido):  
16  
Aos 18 meses, se o anti-HCV for não reagente, a infecção pelo HCV é descartada. Caso ele seja reagente, deve-se realizar novamente o teste molecular para detecção da carga viral HCV-RNA. Caso seja confirmada a infecção, o caso deve ser notificado como hepatite C e a criança deve ser acompanhada como tal. A **Figura 2** apresenta a conduta para investigação laboratorial da criança exposta ao HCV.  
Figura 2 - Fluxograma de investigação laboratorial da criança exposta ao HCV  
<!-- Start of picture text -->
Crianca exposta ao virus da hepatite C (HCV)<br>Realizar o teste molecular de<br>carga viral HCV-RNA entre 0s 3<br>meses e 6 meses de idade<br>| Gee | HCV-RNAsoci<br>, , Notiicar para HCV<br>napeC= omutatn comoe canacontinuar<br>exposta ao HCV<br>fas is meses ee ‘Aosrealizar 18 meses teste ant-HCV de idade,<br>(laboratorial ou teste répido)cra (aboratorialHCVLANA, ou teste répido) e<br>.<br>| Ant-HCV no reagente |f Anti-HCV reagente | r HCV-RNA: |{ eesHCV-RNA<br>Descartar infecc3o ° Descartar notificacao e Dar seguimento como<br>pelo HCV EST infecco pelo HCV crianca com hepatite C<br>HCV-RNA HCV-RNA<br>indetectavel detectavel<br>ae Caae ‘seguimentoNotiicarcom parahepatite comoHCV crianca C e dar<br><!-- End of picture text -->  
Fonte: adaptado de DCCI/SVS/MS<sup>33</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10. TRATAMENTO DA HEPATITE C EM ADULTOS -->
Desde 2010, a hepatite C foi uma das doenças infecciosas cujo tratamento mais evoluiu. Estão disponíveis no SUS tratamentos utilizados por curtos períodos, orais, altamente eficazes, com poucos ou nenhum efeito adverso e com praticidade posológica. **As chances de cura superam 90%,** independentemente do genótipo do HCV. Caso seja necessário retratar o paciente, em razão de não ter ocorrido cura da infecção em um primeiro tratamento, há medicamentos disponíveis no SUS igualmente  
17  
eficazes. Portanto, pode-se afirmar que, no SUS, há alternativas terapêuticas que permitem discutir de forma realista a eliminação da hepatite C como problema de saúde pública até 2030.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.1. Indicações de tratamento -->
**Todas as pessoas com infecção aguda ou crônica pelo HCV têm indicação de tratamento.** Portanto, o tratamento não está limitado a pessoas com infecção crônica, nem deve ser adiado até que a infecção se torne crônica; o paciente com hepatite aguda deve ser tratado assim que o diagnóstico for confirmado. Pessoas com expectativa de vida curta (menos que 12 meses), em razão de comorbidades ou complicações hepáticas, porém que ainda apresentem benefício evidente com o tratamento da hepatite C, devem ser tratadas em centros de referência para doenças hepáticas.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.2. Objetivos do tratamento -->
O objetivo do tratamento da hepatite C é curar a infecção pelo HCV, avaliada pela supressão sustentada da replicação viral a partir de **12 semanas do término do esquema terapêutico** , a chamada **resposta virológica sustentada (RVS).** Assim, pode-se afirmar que, se há RVS, a pessoa está curada daquela infecção. A RVS é geralmente associada à normalização das enzimas hepáticas e melhora ou regressão da atividade necroinflamatória e fibrose, resultando em melhora da função hepática. Há redução, mas não eliminação, do risco de carcinoma hepatocelular e, portanto, pacientes com cirrose hepática com RVS devem ser acompanhados em serviços especializados por tempo indeterminado.  
Os medicamentos disponíveis no SUS conferem RVS em mais de 95% dos pacientes. Após a confirmação da RVS, não é necessário realizar novos testes diagnósticos, exceto se houver suspeita de reinfecção, visto que não há evidências de reativação viral futura após RVS<sup>36,37</sup> .  
As condições de tratamento da hepatite C no Brasil favorecem o alcance da meta da OMS, prevista na Estratégia Global do Setor de Saúde para as Hepatites Virais de, com base nos dados de 2020, curar 80% das pessoas vivendo com hepatite C até 2030<sup>38</sup> .  
A cura da infecção pelo HCV resulta em inequívocos benefícios para as pessoas, como redução da atividade inflamatória sistêmica e hepática, regressão da fibrose e redução do risco de CHC em pessoas com cirrose hepática. Além disso, há evidências de redução da mortalidade por todas as causas<sup>1,37,39–42</sup> e melhora das manifestações extra-hepáticas.  
**Pessoas com resposta virológica sustentada, ou seja, HCV-RNA indetectável a partir de doze semanas após o fim do tratamento, são consideradas curadas da infecção pelo HCV.**

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.3. Avaliação pré-tratamento -->
A etapa pré-tratamento tem como propósito garantir que a pessoa com infecção pelo HCV esteja em condições clínicas, sociais e psicossociais adequadas para iniciar e manter o tratamento com segurança  
18  
e adesão. Deve ser conduzida de forma multiprofissional na APS, reunindo médico, enfermeiro, farmacêutico, nutricionista, assistente social, psicólogo, agente comunitário de saúde (ACS) ou técnico em agente comunitário de saúde (TACS), entre outros profissionais, conforme suas atribuições, expertise e vínculo com o usuário.  
Essa atuação integrada é essencial para assegurar o cuidado integral, identificar fatores que possam comprometer a efetividade terapêutica, como comorbidades, vulnerabilidades sociais, uso de substâncias hepatotóxicas, dificuldades de adesão medicamentosa e ausência de planejamento reprodutivo adequado, além de favorecer o seguimento longitudinal no âmbito da APS.  
No componente clínico e laboratorial, devem ser confirmadas a infecção ativa pelo HCV (HCVRNA detectável) e o grau de comprometimento hepático, com avaliação do estágio de fibrose e de possíveis coinfecções, incluindo hepatites A e B, HIV e sífilis. Também se recomenda verificar a função renal, as condições metabólicas associadas e o uso de medicamentos com potencial de interação farmacológica, ajustando condutas conforme necessário.  
O aconselhamento reprodutivo deve ocorrer antes do início da terapia antiviral, com realização de teste de gravidez e discussão sobre métodos contraceptivos seguros. A gestação durante o uso de antivirais de ação direta (DAA, do inglês _Direct-Acting Antiviral_ ) é contraindicada, e a escolha do método deve considerar a segurança em casos de doença hepática crônica, evitando combinações hormonais com estrogênio em pessoas com cirrose avançada, conforme critérios de elegibilidade segundo a OMS<sup>43</sup> .  
O componente psicossocial busca reconhecer barreiras que possam dificultar o acesso e a adesão, como limitações de transporte, vulnerabilidade social, uso abusivo de álcool e outras drogas ou ausência de apoio familiar. Quando identificadas, essas situações devem ser acompanhadas em articulação com a assistência social e demais serviços da Rede de Atenção à Saúde (RAS), garantindo suporte contínuo.  
Aspectos nutricionais e de estilo de vida também devem ser observados, com incentivo à prática regular de atividade física, alimentação equilibrada, controle de obesidade e síndrome metabólica, e redução ou abstinência do consumo de álcool, considerando seu potencial hepatotóxico.  
A busca ativa e testagem de contactantes domiciliares e parcerias sexuais constitui uma ação complementar à avaliação pré-tratamento e às estratégias de vigilância em saúde. A testagem sorológica para HCV, HBV e HIV deve ser ofertada a pessoas que compartilham o mesmo domicílio ou apresentem exposição potencial a sangue, como o uso comum de lâminas, alicates ou escovas de dente, além de parceiros sexuais estáveis. Também é indicada a atualização vacinal dos contactantes e o reforço de orientações sobre práticas seguras e prevenção da transmissão.  
De forma articulada, essas ações permitem estruturar um plano de cuidado individualizado e contínuo, com definição de responsabilidades entre os diferentes níveis de atenção, agendamento de consultas e exames subsequentes e registro adequado no prontuário eletrônico. A condução sistematizada dessa etapa fortalece a integração entre vigilância, assistência e promoção da saúde, favorecendo o alcance da RVS e a interrupção de novos ciclos de transmissão do HCV.  
Quadro 6 – Atividades no pré e pós tratamento da hepatite C por profissional  
|**Atividade Pré-Tratamento**|**Médico**|**Enfermeiro**|**Farmacêutico**|
|---|---|---|---|
|Educação em saúde, e orientação<br>inicial|✔|✔|✔|
|Busca ativa e sensibilização para<br>testagem (populações-chave,<br>vulneráveis e contactantes)|✔|✔|✔|
|Realização de testagem rápida anti-<br>HCV(paciente e contactantes)|✔|✔|✔|
|Solicitação de exames de imagens e<br>laboratoriais (HCV-RNA,<br>bioquímica, sorologias,<br>hemograma)|✔|✔|✔Exames<br>Bioquímico e<br>Hemograma<br>(acompanhamento<br>farmacoterapêutico)|  
19  
|**Atividade Pré-Tratamento**|**Médico**|**Enfermeiro**|**Farmacêutico**|
|---|---|---|---|
|||Exames previstos<br>em Notas Técnicas<br>complementares||
|Coleta de material para exames<br>laboratoriais (venoso)|✔(quando ato<br>diagnóstico)|✔|✔(Farmacêutico<br>com habilitação em<br>análises clínicas)|
|Coleta de material para teste rápido<br>(capilar/oral)|✔|✔|✔(quando<br>capacitado)|
|Cálculo e registro do escore<br>APRI/FIB-4|✔<br>(interpretação<br>clínica)|✔(Cálculo/ registro<br>conforme Notas<br>Técnicas<br>complementares)|✔(Cálculo/ registro<br>para<br>acompanhamento)|
|Classificação da fibrose hepática e<br>decisão terapêutica|✔(atividade<br>privativa)|✔Apoio (registro/<br>encaminhamento)|✔Apoio<br>(elegibilidade para<br>dispensação/<br>checagem)|
|Prescrição do tratamento antiviral<br>conforme o PCDT vigente|✔(atividade<br>privativa)|||
|Avaliação de interações<br>medicamentosas e contraindicações|✔(análise<br>clínica)|✔(apoio clínico)|✔(análise técnico-<br>farmacêutica)|
|Aconselhamento e adesão<br>terapêutica|✔|✔|✔|
|Dispensação dos medicamentos<br>antivirais no SICLOM-HV||✔(apoio<br>administrativo)|✔(responsável<br>técnico)|
|Orientação sobre uso correto,<br>eventos adversos e medidas de<br>adesão|✔|✔|✔|
|Farmacovigilância e notificação de<br>eventos adversos|✔(registro<br>clínico/conduta)|✔(monitoramento e<br>registro)|✔(monitoramento e<br>registro)|
|Acompanhamento do tratamento|✔|✔|✔|
|Seguimento pós-cura (solicitação<br>de exames de imagem ou<br>laboratoriais)|✔|✔(Exames simples,<br>sob protocolo da<br>APS)|✔Exames<br>bioquímico e<br>Hemograma<br>(acompanhamento)|
|Busca ativa de pacientes em atraso,<br>abandono ou falha de adesão|✔|✔|✔|  
Fonte: elaboração própria, com base nas seguintes legislações, diretrizes e documentos oficiais: (Lei nº 7.498, de 25/06/1986<sup>44</sup> . Decreto nº 94.406, de 08/06/1987<sup>45</sup> . Lei nº 12.842, de 10/07/2013<sup>46</sup> . Lei nº 13.021, de 80/08/2014<sup>47</sup> . Resolução COFEN nº 195, de 18/02/1997<sup>48</sup> . Resolução COFEN nº 564, de 06/11/2017<sup>49</sup> . Resolução CFF nº 585, de 29/08/2013<sup>50</sup> . Resolução CFF nº 509, de 29/07/2009<sup>51</sup> . Portaria GM/MS nº 2.436, de 21/09/2017<sup>52</sup> . PCDT da Hepatite C e Coinfecções, 2019<sup>53</sup> . Nota Técnica nº 5/2025 – CGHV/DATHI/SVSA/MS<sup>54</sup> . Manual Técnico para o Diagnóstico das Hepatites Virais, 2018<sup>29</sup> , Nota Técnica nº 369/2020-CGAHV/.DCCI/SVS/MS<sup>55</sup> )<sup>29,44–55</sup> .  
O cuidado às pessoas com hepatite C no âmbito do SUS deve ocorrer de forma multiprofissional e integrada, assegurando que diferentes saberes e práticas colaborem para um acompanhamento resolutivo e humanizado. Além de médicos, enfermeiros e farmacêuticos, **outros profissionais da saúde — como assistentes sociais, psicólogos, nutricionistas, dentistas, fisioterapeutas, agentes comunitários de saúde, equipes de saúde mental e outros — podem atuar em diversas etapas do cuidado, de acordo**  
20  
**com as normativas e competências definidas por seus respectivos conselhos profissionais e protocolos oficiais.**  
A busca ativa de contactantes e populações-chave é essencial para ampliar o acesso ao diagnóstico e romper a cadeia de transmissão, sobretudo entre grupos em situação de maior vulnerabilidade historicamente mais expostos. A atenção deve também considerar as vulnerabilidades sociais das pessoas que enfrentam barreiras relacionadas à pobreza, estigma, privação de liberdade, uso de álcool e outras drogas ou dificuldades de acesso aos serviços de saúde.  
Dessa forma, uma abordagem centrada na pessoa, articulada entre os diferentes níveis de atenção e respaldada pelas diretrizes do SUS, fortalece a adesão terapêutica, a integralidade, a equidade e a efetividade das ações de controle da hepatite C no país.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.3.1. Exames complementares -->
Os exames complementares recomendados no **Quadro 7** visam a contribuir para a avaliação global do paciente e devem incluir testes de lesão e função hepática para o estadiamento não invasivo da hepatopatia, a pesquisa de outras infecções, como HBV, HAV, sífilis e HIV, e possíveis condições que possam influenciar o tratamento ou requer acompanhamento posterior.  
Portanto, os exames complementares têm três objetivos principais:  
- Confirmar a infecção ativa pelo HCV;  
- Estimar o estágio da doença hepática; e  
- Identificar comorbidades ou manifestações extra-hepáticas que possam afetar o tratamento e a evolução da hepatopatia.  
Cada profissional deve considerar as limitações ou necessidades específicas de cada pessoa ao solicitar os exames complementares. É fundamental o conhecimento das condições clínicas prévias dos pacientes, visto que será necessário monitorar eventual descompensação hepática durante o tratamento, garantir a continuidade do tratamento antidiabético, da dislipidemia, obesidade e anti-hipertensivo, entre outros, visando a manter o controle clínico durante o uso dos DAA, evitar interrupções e descontinuidade durante o tratamento.  
Quadro 7 – Recomendações de exames complementares pré-tratamento  
|**Objetivo**|**Exames**|**Observações**|
|---|---|---|
|Confirmar infecção<br>ativa|HCV-RNA (carga viral)|O HCV-RNA detectável é o marcador de infecção<br>em atividade.<br>Todos os pacientes devem ter confirmação de<br>infecção ativa para receber tratamento (ver<br>_Diagnóstico_).|
||Hemograma, tempo de<br>protrombina/RNI, ALT,<br>AST,<br>GGT,<br>FA,|Testes que permitirão avaliar a função hepática e<br>o estadiamento não invasivo da hepatopatia.|
|Avaliar lesão/função<br>hepática e estadiar a<br>hepatopatia crônica|bilirrubina total e frações,<br>proteínas totais e frações<br>Exames<br>de<br>imagem<br>(elastografia,<br>ultrassonografia<br>abdominal superior)|Podem ser necessários na avaliação pré-tratamento<br>de casos específicos, principalmente se houver<br>evidências clínicas de hepatopatia avançada,<br>comorbidades, e no seguimento pós-cura.<br>Não são necessários para prescrição do tratamento<br>na maioria dos casos.|  
21  
|**Objetivo**|**Exames**|**Observações**|
|---|---|---|
|Propedêutica<br>complementar nos<br>casos de suspeita<br>clínica ou alterações<br>hepáticas na<br>ultrassonografia<br>abdominal|Tomografia<br>computadorizada (TC) ou<br>ressonância<br>magnética<br>(RM)|São métodos importantes para esclarecimento<br>diagnóstico de lesões hepáticas suspeitas, como<br>cistos complexos ou nódulos, particularmente em<br>pacientes com cirrose hepática e hipertensão portal<br>clinicamente significativa. Por serem exames de<br>alto custo, nesses casos, os pacientes devem ser<br>encaminhados para serviços especializados para<br>avaliação diagnóstica.|
|Investigar outras<br>condições relevantes|Testes rápidos para HIV,<br>HBV e sífilis; anti-HAV<br>Beta-HCG<br>Alfafetoproteína<br>Glicemia<br>de<br>jejum,<br>creatinina, TSH e perfil<br>lipídico|Todas as pessoas com infecção confirmada pelo<br>HCV devem ser testadas para HIV, HAV, HBV e<br>sífilis visto sua importância no âmbito da saúde<br>coletiva.<br>O tratamento atualmente é contraindicado em<br>pessoas gestantes.<br>Indicado para pacientes com cirrose hepática.<br>Esses exames devem ser individualizados. Seus<br>resultados não contraindicam o tratamento de<br>forma geral, mas podem identificar condições<br>importantes para a atenção integral e adequada do<br>paciente. A estimativa da função renal é<br>particularmente importante para tratamento de<br>PVHA em uso de TDF com o velpatasvir.|  
Legenda: HCV-RNA, ácido ribonucleico do vírus da hepatite C; HIV, vírus da imunodeficiência humana; HAV, vírus da hepatite A, HBV, vírus da hepatite B; RNI, relação normatizada internacional; ALT, alanina aminotransferase; AST, aspartato aminotransferase; GGT, gama glutamil transferase; FA, fosfatase alcalina; TSH, hormônio tireoestimulante; PVHA, pessoas vivendo com HIV/aids; TDF, fumarato de tenofovir desoproxila.  
Fonte: elaboração própria.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.3.2. Estadiamento da doença hepática -->
O estadiamento da doença hepática é recomendado na abordagem inicial de todas as pessoas com doenças hepáticas e, nesse caso, naquelas com hepatite C, coinfectadas ou não pelo HIV, de modo a caracterizar ausência ou presença de doença hepática avançada. Esta medida é necessária para definir a linha de cuidado e o esquema terapêutico mais adequado para cada situação. Portanto, o estadiamento da hepatopatia tem impacto direto no planejamento terapêutico e no seguimento após a cura.  
Diante dos desafios da capilarização de métodos de estadiamento na saúde pública em diversos contextos, é possível organizar estratégias assertivas baseadas em métodos simples, visando a eliminação de barreiras no cuidado, particularmente para o cuidado de populações vulnerabilizadas.  
Há métodos não invasivos, como os escores APRI e FIB-4 e a elastografia hepática, amplamente utilizados na prática clínica, e a biópsia hepática, método invasivo desnecessário e dispensável para indicar o tratamento da hepatite C mediante o desempenho dos métodos não invasivos, ficando reservada para casos complexos com indicação de sua realização por especialistas.  
**Os métodos não invasivos apresentam acurácia suficiente para serem utilizados como primeira escolha para o estadiamento** , visando a simplificar o cuidado do(a) paciente e o acesso ao tratamento<sup>56,57</sup> . A **estratégia de estadiamento hepático recomendada por este PCDT tem como ponto de partida o escore APRI** , modelado para hepatite C como método simplificado de predição de cirrose e fibrose avançada<sup>35,57</sup> . Portanto, a aplicação desse escore como método inicial de estadiamento hepático configura estratégia simples, adequada e de baixa complexidade.  
22  
Os valores de sensibilidade e especificidade de APRI ≥ 1 para predição de cirrose são 89% e 75%, respectivamente. Considerando a prevalência de 23% de cirróticos por hepatite C crônica na população brasileira **, o valor de APRI < 1 exclui a cirrose corretamente em 91% das vezes** . Portanto, no contexto do tratamento da hepatite C, este PCDT estabelece, com base em evidência científica, que o ponto de corte para excluir o diagnóstico de doença hepática avançada é APRI < 1.  
Os resultados do APRI ou FIB-4 podem facilmente ser calculadas por meio das a seguir:  
Idade (anos)X AST (UI/L) Para calcular o FIB4: FIB4= Contagem de plaquetas (10<sup>9</sup> )X √ALT(UI/L)  
Os valores de APRI e FIB-4 podem facilmente ser obtidos por meio de calculadoras gratuitas, disponíveis em:  
<u>https://sbhepatologia.org.br/associados/calculadoras/APRI/</u>  
<u>https://www.mdcalc.com/calc/2200/fibrosis-4-fib-4-index-liver-fibrosis</u>  
A correlação dos resultados do APRI e FIB-4 com a escala Metavir está representada no **Quadro 8** .  
Quadro 8 – Caracterização da fibrose hepática conforme valores de APRI e FIB-4  
||**APRI – Avali**|**ação de cir**|**rose hepática**||
|---|---|---|---|---|
|**Resultado**|**< 1,0**||**1,0 – 1,49**|**≥ 2,0**|
|Interpretação|Baixa probabilidade de<br>cirrose (F4)|Zona cinz<br>acurácia,<br>hepática|a – não determina, com<br>o estádio da fibrose|Ata probabilidade<br>de cirrose (F4)|
|**FIB-4 - Avaliaçã**|**o de fibrose hepática avanç**|**ada ou cir**|**rose**||
|**Resultado**|**< 1,45**||**1,45 – 3,24**|**≥ 3,25**|
|Interpretação|Baixa probabilidade de<br>fibrose F2, F3 ou F4|Zona cinz<br>acurácia,<br>hepática|a – não determina, com<br>o estádio da fibrose|Alta probabilidade<br>de F3 ou F4|  
Legenda: APRI, índice de relação aspartato aminotransferase (AST) sobre plaquetas (AST- _to-platelet ratio index_ ); FIB-4, Fibrosis-4 score.  
Fonte: adaptado de DIAHV/SVS/MS<sup>58</sup> .  
A elastografia hepática é um método de ultrassom que mede a velocidade de propagação de ondas de baixa frequência pelo parênquima hepático e estima o estádio da fibrose. Suas vantagens incluem a rápida execução, possibilidade de realização em ambiente ambulatorial e satisfatória curva de aprendizado para os operadores que não necessitam ser especialistas em radiologia<sup>59,60</sup> . Constitui, portanto, um método não invasivo de grande importância na prática clínica, amplamente validado para avaliação da hepatopatia por vírus C e já disponível em alguns serviços no país.  
Os pontos de corte da elastografia para a classificação do estádio da fibrose hepática são variáveis de acordo com os diversos equipamentos de imagem disponíveis atualmente para esta finalidade, como  
23  
ultrassonografia, elastografia hepática transitória e ressonância magnética. Caso o paciente não seja classificado como F3 ou F4 pelos escores APRI ou FIB-4, a elastografia hepática poderá ser indicada a critério do médico assistente responsável.  
É importante ressaltar que os **pacientes com valores de APRI ≥ 1 devem ter avaliação não invasiva adicional para o estadiamento da hepatopatia:**  
- Ultrassom de abdômen;  
- Rigidez hepática estimada por elastografia transitória;  
- Rigidez hepática estimada por elastografia por ultrassom;  
- Rigidez hepática estimada por elastografia por ressonância magnética.  
O **Quadro 9** apresenta os resultados que definem fibrose avançada segundo o método de avaliação.  
Quadro 9 - Resultados que definem fibrose avançada segundo o método de avaliação  
|**Método de avaliação**|**Resultado equivalente a fibrose**<br>**avançada**|
|---|---|
|Avaliação não invasiva|Estádios de fibrose F3 ou F4 da escala<br>METAVIR|
|Rigidez hepática estimada por elastografia transitória|≥ 10 kPa|
|Rigidez hepática estimada por elastografia por ultrassom<br>(pSWE e 2D-SWE)|≥ 9 kPa|
|Rigidez hepática estimada por elastografia por<br>ressonância magnética|≥ 4 kPa|  
Fonte: adaptado de DIAHV/SVS/MS<sup>58</sup> .  
**A biópsia hepática fica reservada para diagnóstico diferencial da hepatite viral com outras hepatopatias, devendo ser solicitada por especialista focal.**  
A cirrose hepática representa o estágio avançado da hepatopatia crônica e caracteriza-se pela distorção da arquitetura do órgão em razão da substituição do parênquima hepático normal por tecido cicatricial não funcional como consequência da inflamação hepática contínua. Pode ser classificada em cirrose compensada ou descompensada.  
A cirrose compensada é definida como a ausência de eventos de descompensação atuais ou prévios. Os eventos que definem descompensação em um paciente com cirrose compensada são a presença de ascite (ou derrame pleural e gradiente de albumina soro-ascite [GASA] igual ou maior que 1,1 g/dL), encefalopatia hepática (grau West Haven igual ou maior que II) e sangramento por varizes gastroesofágicas 61.  
A transição do estado compensado para descompensado está associada ao aumento do risco de morte. A classificação de Child-Turcotte-Pugh (usualmente Child-Pugh)<sup>62</sup> é amplamente utilizada na prática não apenas como determinante prognóstico e definidor de encaminhamento para transplante hepático, mas também para decisão de tratamento e esquema terapêutico. Ela é obtida pela somatória de pontos de acordo com cinco fatores, com resultado variando entre 5 e 15. O resultado de 5 ou 6 é considerado Child A; de 7 a 9, como Child B, e; maior que 9, Child C.  
**A descompensação hepática é indicada por um escore de Child-Pugh maior ou igual a 7** (Child B ou C) ( **Quadro 10** ).  
24  
Quadro 10 – Classificação de Child-Pugh da cirrose hepática  
|**Parâmetros**|**+ 1 ponto**|**+2 pontos**|**+3 pontos**|
|---|---|---|---|
|Bilirrubina sérica (mg/dL)|< 2,0|2,0 a 3,0|> 3,0|
|Albumina sérica (g/dL)|> 3,5|2,8 a 3,5|< 2,8|
|Ascite|Ausente|Leve|Moderada|
|Encefalopatia|Ausente|Leve|Moderada|
|Tempo de protrombina (segundos acima do<br>controle) **OU**RNI|0-4<br>< 1,7|4-6<br>1,7-2,3|> 6<br>> 2,3|  
Legenda: RNI, razão normatizada internacional. Fonte: elaboração própria, com base em Tsoris & Marlar, 2023<sup>62</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.4. Tratamento -->
As alternativas terapêuticas para o tratamento da hepatite C com registro no Brasil e incorporadas no SUS apresentam alta efetividade terapêutica. De forma geral, a efetividade dos esquemas, mensurada pelas taxas de RVS, é comparável. Algumas características específicas os diferenciam, como a possibilidade de uso quando o paciente possui determinadas condições clínicas, comodidade posológica, necessidade da realização de exames e o preço.  
Essa similaridade na eficácia terapêutica permite que, no SUS, a oferta dos esquemas seja baseada na **custo-minimização** , ou seja, na priorização das alternativas que implicam em menor impacto financeiro ao sistema garantindo o acesso a terapias seguras e eficazes às pessoas com hepatite C. Esta estratégia ampliou o acesso ao tratamento medicamentoso para todas as pessoas vivendo com hepatite C no país.  
**O Ministério da Saúde atualizará quais tecnologias estarão disponíveis no SUS, de acordo com as indicações deste PCDT e o critério de custo-minimização, por meio de Nota Técnica específica** .  
Os medicamentos atuais para o tratamento da hepatite C aguda ou crônica são os DAA.  
Como esses medicamentos são altamente eficazes em todos os genótipos do vírus, ou seja, são pangenotípicos **, a genotipagem não é mais necessária para a definição do esquema terapêutico** . Ao eliminar a necessidade de genotipagem, simplificar o processo entre o diagnóstico e o tratamento é menor, simplificando as cadeias de aquisição e fornecimento e expandindo o acesso ao tratamento.  
**Não é necessário solicitar o exame de genotipagem do HCV para o tratamento inicial ou retratamento com DAA.**  
Os DAA atualmente disponíveis no SUS são: sofosbuvir (SOF), velpatasvir (VEL), daclatasvir (DCV), voxilaprevir (VOX), pibrentasvir (PIB) e glecaprevir (GLE). Estes medicamentos são sempre utilizados em combinação, em diferentes esquemas, visando a aumentar a eficácia antiviral e evitar o surgimento de cepas resistentes.  
O velpatasvir é um potente inibidor pangenotípico da região NS5A do genoma viral, enquanto o sofosbuvir é um análogo de nucleotídeo inibidor da polimerase NS5B. A apresentação é de um comprimido coformulado, bem tolerado, que pode ser indicado para pacientes com cirrose em qualquer estágio e para pacientes com doença renal crônica, independentemente do uso prévio de terapia com interferon.  
25  
O daclatasvir é um inibidor da região NS5A, assim como o velpatasvir, e seu uso combinado com sofosbuvir resulta em um esquema pangenotípico bem tolerado que pode ser utilizado para o tratamento de pacientes com doença renal crônica ou com disfunção hepática. Não há uma apresentação associada de sofosbuvir e daclatasvir; portanto, este esquema implica na tomada de dois comprimidos.  
O glecaprevir e o voxilaprevir são inibidores da protease NS3/4A, enquanto o pibrentasviré um inibidor da região NS5A.  
Os esquemas terapêuticos recomendados consistem na associação de DAA e são indicados tanto para **adultos quanto para crianças a partir de 12 anos ou com pelo menos 30 kg, na forma farmacêutica de comprimidos. Para crianças entre 3 e 11 anos, pesando entre 17 e 29,99 kg são indicados DAA na forma farmacêutica granulado** (para informações específicas para a população pediátrica, ver _Crianças e adolescentes_ ).  
A escolha do esquema terapêutico é baseada no estadiamento hepático simplificado (vide _Estadiamento da doença hepática_ ) **calculado pelo escore APRI e pela avaliação clínico-laboratorial de doença hepática descompensada** (Child-Pugh ≥ 7 ou outro sinal de descompensação). Portanto, o principal fator determinante para a escolha do tratamento, tanto inicial quanto retratamento, deve ser o **estadiamento da doença hepática**<sup>11,63</sup> , conforme detalhado nos **Quadros 8** e **9** .  
Caso a pessoa com hepatite C apresente baixo risco de cirrose (escore APRI < 1) e não possua as comorbidades graves abaixo relatadas, poderá ser tratada e acompanhada pelos médicos da APS. Contudo, caso apresente qualquer uma das condições elencadas a seguir, deverá ser encaminhada para acompanhamento na Atenção Especializada:  
- coinfecção HCV-HIV;  
- coinfecção HCV-HBV;  
- gestação;  
- idade inferior a 18 anos;  
- insuficiência renal crônica com clearance de creatinina < 30 mL/min/1,73m<sup>3</sup> ;  
- uso de quimioterapia;  
- recebimento de transplante;  
- hepatocarcinoma ou outras neoplasias;  
- uso de anticonvulsivantes de primeira geração (carbamazepina, oxcarbazepina, fenitoína e fenobarbital) ou amiodarona;  
- manifestações extra-hepáticas graves: vasculites sistêmicas, glomerulopatias;  
- falha ao tratamento prévio com DAA.  
Para pessoas que apresentam alguma das condições, a APS deve solicitar os exames complementares para definição de diagnóstico e acompanhamento clínico para então encaminhar o paciente aos serviços especializados.  
Os casos tratados na APS ou no serviço especializado devem ser avaliados periodicamente quanto à adesão ao tratamento e ao desenvolvimento de efeitos adversos. O processo matricial facilita a condução do tratamento, incluindo o ajuste de medicamentos para evitar interações medicamentosas, quando necessário.  
A seleção do esquema será determinada pela disponibilidade dos medicamentos na Rede, de acordo com critérios de **custo-minimização** , os quais serão comunicados por documento normativo do Ministério da Saúde e deverão ser selecionados de acordo com o tratamento proposto - **inicial** (primeiro tratamento) ou **retratamento** .  
26

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.4.1. Medicamentos e esquemas de administração -->
O Quadro 11 elenca os medicamentos disponíveis no SUS para o tratamento da hepatite C e seus esquemas de administração em adultos.  
Quadro 11 – Medicamentos para o tratamento da hepatite C e seus esquemas de administração em  
adultos  
|**MEDICAMENTO**|**ESQUEMAS DE ADMINISTRAÇÃO**|
|---|---|
|Sofosbuvir 400 mg/velpatasvir 100 mg|1 comprimido uma vez ao dia (dose fixa combinada), por<br>via oral|
|Glecaprevir 100 mg/pibrentasvir 40 mg|3 comprimidos uma vez ao dia (dose fixa combinada), por<br>via oral|
|Sofosbuvir<br>400<br>mg/velpatasvir<br>100<br>mg/<br>voxilaprevir 100 mg|1 comprimido uma vez ao dia (dose fixa combinada), por<br>via oral|
|Sofosbuvir 400 mg + daclatasvir 60 mg|1 comprimido de sofosbuvir e 1 comprimido de daclatasvir,<br>por via oral, uma vez ao dia tomados juntos<sup>a</sup>|
|Sofosbuvir 400 mg + daclatasvir 30 mg|1 comprimido de sofosbuvir e 2 comprimidos de<br>daclatasvir, por via oral, uma vez ao dia tomados juntos<sup>a</sup>|  
Fonte: elaboração própria.  
Nota:<sup>a</sup> Os pacientes devem ser informados de que os comprimidos de sofosbuvir e daclatasvir devem ser tomados juntos, uma vez ao dia.  
O **Quadro 12** elenca o medicamento disponível no SUS para o tratamento da hepatite C e seus esquemas de administração em crianças entre 3 e 11 anos, 11 meses e 29 dias, pesando entre 17 e 29,99 kg  
Quadro 12 – Medicamento para o tratamento da hepatite C e seu esquema de administração em crianças entre 3 e 11 anos, 11 meses e 29 dias, pesando entre 17 e 29,99 kg  
|**MEDICAMENTO**|**ESQUEMAS DE ADMINISTRAÇÃO**|
|---|---|
|Sofosbuvir 200 mg/velpatasvir 50 mg|1 sachê (grânulos) uma vez ao dia (dose fixa combinada),<br>por via oral|  
Fonte: elaboração própria.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.4.2. Avaliação de possíveis interações medicamentosas -->
Os DAA apresentam um perfil de interações com outros medicamentos bastante favorável, podendo ser administrados concomitantemente com a maioria dos medicamentos utilizados pela população. Quando há interações impeditivas, há possibilidade de tratamento alternativo.  
As estatinas em geral não devem ser utilizadas com os DAA que são inibidores de protease, como glecaprevir e voxilaprevir; porém, os fibratos podem ser usados com todos os DAA disponíveis.  
Entre os medicamentos utilizados para cardiopatias, a amiodarona apresenta interações medicamentosas potencialmente graves com os antivirais para hepatite C disponíveis no SUS, com risco de eventos adversos como arritmias cardíacas. Assim, o uso de amiodarona deve ser evitado, substituindo por outro antiarritmico sempre que possível, conforme interações descritas no **Material Suplementar Interações medicamentosas** .  
27  
Medicamentos contendo etinilestradiol, como contraceptivos hormonais, assim como estatinas, não devem ser usados com glecaprevir ou voxilaprevir.  
Nenhum dos DAA disponíveis pode ser utilizado em conjunto com rifampicina, rifabutina, rifapentina, carbamazepina, oxcarbazepina, fenitoína ou fenobarbital. Para o tratamento de pacientes que utilizam esses medicamentos, deve-se solicitar a avaliação de especialistas focais para decidir sobre a substituição (temporária ou definitiva) ou interrupção dos medicamentos que têm interações medicamentosas impeditivas com os DAA.  
Outras interações menores não contraindicam o uso, mas tornam necessários alguns ajustes na posologia dos medicamentos para possibilitar o tratamento da hepatite C. Mais informações sobre interações medicamentosas com os medicamentos utilizados no tratamento da hepatite C estão nos Materiais Suplementares deste PCDT ou em www.hep-druginteractions.org.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: **Recomenda-se a avaliação de interações medicamentosas com os DAA de todos os medicamentos prescritos e não prescritos, de uso contínuo ou não, antes e durante o tratamento, visando a evitar toxicidades e falhas terapêuticas.** -->
10.4.3. Esquemas terapêuticos recomendados para o tratamento inicial ou reinfecção da hepatite C  
**Recomenda-se que sejam utilizados esquemas que associem duas classes distintas de DAA, independentemente do estágio da fibrose hepática** . Os esquemas consistirão na administração por via oral em dose única de sofosbuvir (1 comprimido) e daclatasvir (1 comprimido) para pacientes com APRI < 1 ou sem cirrose por 12 semanas. **Estes medicamentos não são combinados em um único comprimido e devem ser ingeridos juntos** .  
Para pacientes com APRI ≥ 1 ou com cirrose compensada (Child A), o tratamento recomendado é a administração oral da dose combinada de sofosbuvir e velpatasvir uma vez ao dia por 12 semanas. Se o paciente apresentar cirrose descompensada, o tratamento com a dose combinada de sofosbuvir e velpatasvir deverá ser realizado por 24 semanas.  
O **Quadro 13** e as **Figuras 3** e **4** sistematizam as indicações de tratamento inicial e reinfecção para hepatite C em pacientes com pelo menos 12 anos de idade ou com pelo menos 30 kg.  
Quadro 13 - Tratamento inicial ou reinfecção da hepatite C com medicamentos pangenotípicos com base no estadiamento da fibrose hepática em pacientes com pelo menos 12 anos ou com pelo menos 30 kg  
|**Estadiamento hepático**|**Combinação de DAA**|**Posologia**|**Duração**|
|---|---|---|---|
|Escore APRI < 1 E<br>sem cirrose|Sofosbuvir + daclatasvir|1 comprimido de sofosbuvir +<br>1 comprimido de daclatasvir,<br>1x/dia|12<br>semanas|
|Escore APRI ≥ 1 OU<br>cirrose compensada<br>(Child A)|Sofosbuvir/<br>velpatasvir|1 comprimido de sofosbuvir/<br>velpatasvir, 1x/dia|12<br>semanas|
|Cirrose descompensada<br>(Child B ou C)|Sofosbuvir/<br>velpatasvir|1 comprimido de sofosbuvir/<br>velpatasvir,1x/dia|24<br>semanas|
|Fonte: elaboração própria||||  
28  
Figura 3 – Abordagem clínica e terapêutica de pacientes com hepatite C e APRI < 1, sem cirrose, maiores de 12 anos ou pesando pelo menos 30 kg, **sem tratamento prévio** com DAA para a mesma infecção  
<!-- Start of picture text -->
Paciente com teste rapido indicando anti-HCV positivo<br>Realizar HCV-RNA, dosagem de AST e<br>~ contagem de plaquetas - APRI<br>s<br>Bo<br>Se<br>so 5<br>°& 5 HCV-RNA+ e APRI< 1| HCV-RNA+ e APRI > 1] HCV-RNA-<br>=e<br>S<br>=s Encaminhar para ‘Sem infecc&o atual<br>‘servigo especializado pelo HCV<br>Avaliar interagées medicamentosas, educacdo<br>2 sobre transmissao, adesdo, reinfeccao e alcool<br>5=<br>£s<br>e ‘Sofosbuvir e daclatasvir, via oral,<br>ingeridos juntos por 12 semanas<br>2 HCV-RNA 12 semanas apés 0 término do tratamento<br>E<br>2£<br>3a “<br>= HCV-RNA- HCV-RNA+<br>€8<br>@<br>2<br>sS RVS ou cura da infeccao Encaminhar para servico<br>= ALTA com medidas especializado e avaliacdo<br>z preventivas de retratamento<br><!-- End of picture text -->  
Fonte: elaboração própria  
29  
- Figura 4 – Abordagem clínica e terapêutica de pacientes com hepatite C e APRI **≥** 1 ou cirrose compensada ou descompensada, maiores de 12 anos ou pesando pelo menos 30 kg, **sem tratamento prévio** com DAA para a mesma infecção  
<!-- Start of picture text -->
Paciente com hepatite C e APRI > 1 ou cirrose compensada ou cirosse descompensada<br>ote2<br>fee (Calcular Child-Pugh, MELD, avaliar funco renal, comorbidades,<br>ges indicacdo de transplante, presenca de carcinoma<br>FEge<br>Consultar interagdes medicamentosas, garantir adeso ao tratamento,<br>avaliar transmissao, risco de infec¢do e abstencao ao alcool<br>2<br>=E5 -.<br>2<br>5 | Child A | L Child B ou C<br>C 1 J 1 )<br>Sofosbuvir/velpastavir por 12 semanas Sofosbuvir/velpastavir por 24 semanas<br>2<br>z HCV-RNA 12 semanas apés o término do tratamento<br>=s<br>2 a . P .<br>3 l HCV-RNA- J| | HCV-RNA+ }<br>=<br>8<br>°<br>8s RVS ou cura da infeccao Soap<br>$ Adogao de medidas preventivas, bore paveseo<br>4 rastreamento semestral de carcinoma Geawater ent<br>hepatocelutar indicagao ‘spl epatico<br><!-- End of picture text -->  
Fonte: elaboração própria

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.4.4. Avaliação da resposta ao tratamento da hepatite C -->
O parâmetro utilizado para avaliar a resposta e o sucesso terapêutico é a RVS, caracterizada pela quantificação da carga viral do HCV-RNA a partir de 12 semanas após o término do tratamento. Um resultado **indetectável** é considerado **cura da infecção** , enquanto um resultado **detectável** é interpretado como **falha terapêutica** . A detectabilidade do HCV-RNA após a RVS caracteriza reinfecção e, nesses casos, os pacientes devem ser tratados novamente com o esquema de tratamento inicial, ou seja, como se não tivessem sido tratados previamente.  
30

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 10.5. Esquemas recomendados para o retratamento da hepatite C -->
Os esquemas para o retratamento de pacientes sem RVS (falha ao tratamento inicial com DAA) também são pangenotípicos. Portanto, **não há necessidade de genotipagem para o retratamento. Recomenda-se que sejam utilizados esquemas que associem três classes distintas de DAA** , com exceção das pessoas com cirrose descompensada. Assim, pessoas com cirrose Child B ou C devem ser tratadas com o esquema de sofosbuvir/velpatasvir por 24 semanas, devendo-se evitar os inibidores de protease, como o glecaprevir e o voxilaprevir.  
Paciente com histórico de múltiplas falhas, ou seja, sem RVS após retratamento com sofosbuvir/velpatasvir/voxilaprevir (SOF/VEL/VOX) ou sofosbuvir+glecaprevir/pibrentasvir (SOF+GLE/PIB) podem ter o tempo de tratamento estendido para 24 semanas.  
Os esquemas de retratamento encontram-se sumarizados no **Quadro 14** e na **Figura 5** .  
Quadro 14 – Retratamento da hepatite C em caso de falha com antivirais de ação direta (DAA) em pacientes com pelo menos 12 anos ou 30 kg  
|**Estadiamento hepático**|**Esquema DAA**|**Posologia**|**Duração**|
|---|---|---|---|
|Escore APRI < 1 OU<br>sem cirrose|SOF/VEL/VOX|1<br>comprimido<br>de<br>SOF/VEL/VOX, 1x/dia|12 semanas|
|Escore APRI ≥ 1 OU<br>cirrose compensada (Child<br>A)|SOF/VEL/VOX|1<br>comprimido<br>de<br>SOF/VEL/VOX, 1x/dia|12 semanas|
|Cirrose<br>descompensada<br>(Child B ou C)|SOF/VEL|1 comprimido de SOF/VEL,<br>1x/dia|24 semanas|  
Legenda: SOF: sofosbuvir; VEL: velpatasvir; VOX: voxilaprevir; GLE: glecaprevir; PIB: pibrentasvir. Fonte: elaboração própria.  
31  
Figura 5 – Abordagem clínica e terapêutica para o retratamento da hepatite C de pacientes com idade igual ou superior a 18 anos  
<!-- Start of picture text -->
Paciente adulto com hepatite C e indicacao de retratamento<br>es eRe APRI = 1 ou cirrose compensada<br>3s ‘ou cirosse descompensada<br>Es<br>Avaliar = Determinar Child-Pugh, MELD, funcao renal,<br>[SLIT funcaoESethepatica, OSSrenal, indicacdoafastar decarcinoma transplantehepatocelular,hepatico, comorbidades,risco de<br>medicamentosas,reinfeccao, interacéesabuso de alcool_ sangramento por varizes<br>° Child A Child B ou C<br>2<br>2 Sofosbuvir/Velpatasvir/Voxilaprevir por<br>B 12 semanas<br>= ‘Sofosbuvir/Velpatasvir/Voxilaprevir Sofosbuvirivelpastavir<br>por 12 semanas por 24 semanas<br>, HCV-RNA 12 semanas apés 0 término do tratamento<br>3<br>£Se<br>se<br>2s [ HCV-RNA- ] [ HCV-RNA+ }<br>85 J<br>8<br>E< RVS ou cura da infeccdo Avaliagdo individualizada por<br>Adoc&o de medidas preventivas especialistas<br><!-- End of picture text -->  
Fonte: elaboração própria.  
11. TRATAMENTO DA HEPATITE C EM POPULAÇÕES ESPECIAIS  
Os esquemas atuais de tratamento têm se mostrado bastante toleráveis na maioria dos contextos, independentemente de a pessoa ter condições crônicas concomitantes.  
- 11.1. Crianças e adolescentes  
Estima-se que de três a cinco milhões de crianças e adolescentes até 18 anos estão vivendo com HCV no mundo, sendo a transmissão vertical a principal forma de infecção nessa faixa etária<sup>64</sup> . A maioria das crianças é assintomática e a evolução da doença é, em geral, benigna, com enzimas hepáticas normais  
32  
ou pouco elevadas, e mínima atividade inflamatória ou fibrose. A resolução espontânea pode ocorrer de 25% a 40% dos lactentes, sendo menor em pré-escolares – cerca de 6% a 12% – e rara em crianças em idade escolar<sup>64–66</sup> .  
A cirrose na infância é rara, ocorrendo em 1% a 2% dos casos<sup>65</sup> . O estágio de fibrose correlacionase com a idade e a duração da infecção. Ao atingir a idade adulta, a doença pode evoluir para cirrose e CHC, e estima-se que a evolução para o óbito aumente em até 26 vezes nos adultos que adquiriram o HCV na infância, seja por transmissão vertical ou parenteral<sup>67</sup> . Em relação ao diagnóstico na infância, todas as crianças nascidas de pessoas diagnosticadas com hepatite C devem realizar o teste molecular (carga viral da hepatite C) entre 3 e 6 meses de vida. O objetivo deste exame é vincular os lactentes ao serviço de saúde e identificar aqueles com maior risco de infecção. O diagnóstico confirmatório ocorre a partir dos 18 meses de vida com o teste sorológico<sup>68</sup> , conforme descrito no PCDT da Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais vigente, disponível em www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts e <u>https://www.gov.br/conitec/ptbr/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-e-diretrizes-terapeuticas.</u>  
Aqueles lactentes com sorologia reagente a partir dos 18 meses de vida devem realizar carga viral para hepatite C. Se a carga viral for detectável, deve-se notificar e repetir o exame após 6 meses para definir hepatite C crônica. Estes lactentes devem ser preferencialmente encaminhados para seguimento em serviço de referência.  
Devido às altas taxas de eventos adversos e à baixa eficácia, a literatura internacional não recomenda uso de alfapeginterferona e ribavirina em nenhuma faixa etária<sup>35,69,70</sup> . Como os DAA utilizados no Brasil são eficazes para todos os genótipos, não há necessidade de genotipagem em qualquer faixa etária. Crianças menores de três anos não têm indicação de tratamento medicamentoso, devendo ser acompanhadas em serviços de referência e avaliadas periodicamente.  
A partir de 3 anos de idade e 17 kg de peso corporal, todas as crianças com diagnóstico confirmado de hepatite C crônica deverão ser tratadas com DAA. O esquema consiste na combinação de sofosbuvir 200 mg e velpatasvir 50 mg granulado, por 12 semanas. Após a prescrição do tratamento, a equipe de saúde deve orientar os cuidadores sobre possíveis interações medicamentosas e reforçar a importância da adesão ao tratamento medicamentoso. A equipe deve avaliar, também, se a criança tolerou o uso do medicamento. É importante ressaltar que não se deve usar dipirona durante o tratamento. Caso a família encontre dificuldade durante o tratamento, deve ser orientada a retornar ao serviço de saúde. **O Quadro 15** apresenta informações sobre o DAA para essa população pediátrica no SUS.  
Quadro 15 - Esquema de tratamento da hepatite C de crianças e adolescentes sem cirrose ou com cirrose compensada (entre 3 e 11 anos, 11 meses e 29 dias de idade, pesando entre 17 e 29,99 kg).  
|**Peso (kg)**|**Idade**|**Forma**<br>**farmacêutica**|**Dose**|**Duração do**<br>**tratamento**|
|---|---|---|---|---|
||||Sofosbuvir 200 mg/||
|≥ 17 a < 30|3 - 11 anos|Granulado|velpatasvir 50 mg, uma vez<br>ao dia|12 semanas|  
Fonte: elaboração própria.  
Algumas orientações importantes a serem dadas às famílias sobre o uso de sofosbuvir/velpatasvir granulado são:  
- O medicamento é de uso oral (tomar pela boca, com ou sem alimentos);  
- Os grânulos devem ser engolidos inteiros. Não mastigue os grânulos;  
- Não abra o sachê de grânulos orais até o momento de uso;  
- Para crianças com menos de 6 anos, tomar os grânulos orais com alimentos, utilizando uma ou mais colheradas de alimento macio não ácido;  
- Não utilizar o medicamento com alimentos quentes;  
- Se for tomar os grânulos orais de SOF/VEL com alimentos, despeje cuidadosamente todo o conteúdo do sachê de grânulos orais sobre o alimento na tigela e misture delicadamente com uma colher, sem dissolver os grânulos. Tome a mistura de grânulos orais de  
33  
SOF/VEL e alimento dentro de 15 minutos no máximo, sem mastigar, para evitar um sabor amargo;  
- Se for tomar os grânulos orais diretamente pela boca, despeje todo o conteúdo do sachê diretamente na boca e engula sem mastigar, para evitar um sabor amargo. Caso necessário, pode-se beber água após engolir os grânulos;  
- Certifique-se de que todos os grânulos orais de SOF/VEL foram ingeridos. Verifique se não ficaram grânulos orais no sachê ou no alimento.  
Em pediatria, o monitoramento após o tratamento deve ser realizado com **exame de carga viral 12 semanas após término do tratamento, assim como para os adultos** . Se a carga viral estiver abaixo do limite de detecção e a criança ou adolescente não apresentar sinais de cirrose ou fibrose hepática, pode receber alta, sendo considerado curado.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.2. Coinfecção com HIV -->
O tratamento da hepatite C está indicado para todos os pacientes coinfectados pelo HIV, independentemente do estádio da fibrose hepática ou da contagem de linfócitos T-CD4 +. As indicações terapêuticas são as mesmas recomendadas para pacientes monoinfectados<sup>13,28,71</sup>  
Aconselha-se iniciar a terapia antirretroviral em todas as pessoas vivendo com HIV, independentemente da contagem de linfócitos T-CD4+, uma vez que o tratamento do HIV contribui para reduzir a inflamação sistêmica, preservar a função imune e retardar a progressão da doença hepática. O tratamento da hepatite C deve ser indicado a todas as pessoas com infecção ativa pelo HCV, sendo fundamental avaliar previamente as potenciais interações medicamentosas entre os DAA e os antirretrovirais utilizados pelo paciente. Quando necessário, o esquema antirretroviral deverá ser ajustado para evitar interações indesejáveis e garantir a segurança e a eficácia de ambos os tratamentos<sup>72</sup> .  
Os esquemas combinados de DAA não devem ser usados em conjunto com inibidores de transcriptase reversa não-análogos de nucleosídeo (ITRNN), como efavirenz, nevirapina e etravirina, pois esses medicamentos reduzem significativamente a concentração sérica dos DAA. Nesses casos, a TARV precisa ser revista para possibilitar o tratamento da hepatite C. No entanto, esta contraindicação tem sido contornada recentemente com a tendência de redução do uso dos ITRNN e a migração para TARV inibidores de integrase, como o dolutegravir, ou IP/r, como o darunavir.  
Outras interações relevantes no contexto da coinfecção HCV/HIV incluem a restrição do uso de glecaprevir e voxilaprevir com atazanavir ou darunavir. Merece atenção a interação entre velpatasvir e tenofovir desoproxila (TDF), pois essa associação pode levar à piora da função renal devido à potencialização do efeito colateral do tenofovir, quase sempre reversível, mas que deve ser monitorado atentamente. Essa interação não ocorre com o tenofovir alafenamida (TAF), que não apresenta interação com os DAA. Portanto, deve-se atentar para os esquemas contendo velpatasvir que devem ser evitados em pacientes que utilizam TDF com taxa de filtração glomerular menor que 60 mL/min.  
Sofosbuvir, daclatasvir e glecaprevir/pibrentasvir não têm interação significativa com os inibidores de transcriptase reversa análogos de nucleosí(t)deo (ITRN) disponíveis. Nos casos de substituições no esquema TARV, com necessidade de retorno ao esquema original após o tratamento com DAA, deve-se aguardar pelo menos duas semanas após o término do tratamento<sup>72</sup> . A extensão do uso do esquema modificado de TARV é necessária devido à meia-vida prolongada de alguns DAA e ao potencial risco de interações medicamentosas caso a TARV seja substituída precocemente.  
Atazanavir + ritonavir (ATV/r) e darunavir + ritonavir (DRV/r) não devem ser utilizados em conjunto com glecaprevir e voxilaprevir, devido ao significativo aumento na concentração sérica desses últimos. No caso da interação específica entre voxilaprevir e DRV/r, caso o esquema de DRV/r seja de dose  
34  
única diária, não há contraindicação formal para a associação. Se o paciente usar DRV/r duas vezes ao dia, a associação com voxilaprevir deve ser evitada.  
Em razão de a apresentação do daclatasvir 30 mg não estar disponível, deve-se trocar o esquema contendo ATV/r. Não há evidências de interações clinicamente significativas entre dolutegravir ou raltegravir e os DAA. De forma geral, pacientes com infecção pelo HCV que estejam usando TARV que os impeça de tratar a hepatite C devem ser avaliados quanto à possibilidade de troca da TARV para um esquema baseado em dolutegravir, devido ao melhor perfil de interações medicamentosas.  
As principais interações medicamentosas entre a TARV e os DAA estão sumarizadas no **Material Suplementar** . Para mais informações sobre o cuidado de pessoas com coinfecção pelo HIV e HCV, consulte o PCDT para Manejo da Infecção pelo HIV em Adultos, disponível em <u>www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts e https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-emsaude/protocolos-clinicos-e-diretrizes-terapeuticas. Outras informações poderão ser consultadas no link https://interacoeshiv.huesped.org.ar/.</u>

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.3. Coinfecção com o vírus da hepatite B -->
Todos os pacientes infectados pelo HCV devem ser testados para hepatite B (HBsAg e anti-HBc). Pacientes com coinfecção HBV/HCV requerem cuidados específicos durante seu acompanhamento, tanto pelo risco aumentado de doença hepática avançada e CHC, quanto pelo risco de reativação do HBV durante o tratamento da hepatite C<sup>72,73</sup> .  
O tratamento dos pacientes coinfectados deve seguir as mesmas recomendações dos monoinfectados. Portanto, as indicações de tratamento da hepatite B em pacientes com coinfecção devem seguir as recomendações do PCDT da Hepatite B e coinfecções vigente. A terapia com análogos nucleos(t)ídeos pode ser instituída de forma concomitante ao tratamento da hepatite C, visando a reduzir o risco de reativação do HBV<sup>35</sup> .  
Se o paciente apresentar HBsAg reagente sem indicação de tratamento conforme recomendado no PCDT da Hepatite B e coinfecções vigente, deve-se realizar o tratamento profilático contra reativação do HBV durante o tratamento da hepatite C com DAA<sup>35,74</sup> , que deverá ser mantido até 12 semanas após o término do tratamento, ou seja, na ocasião da coleta de sangue para o exame de HCV-RNA para avaliar a RVS<sup>35</sup> .  
Em pessoas com HBsAg não reagente, mas anti-HBc reagente, deve-se monitorar os níveis de ALT mensalmente durante o uso dos DAA devido ao risco de reativação do HBV e, caso ocorra, deve-se iniciar prontamente o tratamento da hepatite B.  
Recomenda-se que os pacientes coinfectados HBV/HCV sejam acompanhados por especialistas. Para mais informações, consultar o PCDT da Hepatite B e coinfecções vigente em <u>www.gov.br/aids/ptbr/centrais-de-conteudo/pcdts e https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-emsaude/protocolos-clinicos-e-diretrizes-terapeuticas.</u>

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.4. Coinfecção com o vírus da hepatite A -->
A infecção pelo vírus da hepatite A (HAV) ocorre predominantemente por via fecal-oral, por meio da ingestão de água ou alimentos contaminados, ou pelo contato direto entre pessoas em condições de higiene precária<sup>75</sup> . Em países de média e alta endemicidade, a infecção é mais frequente na infância, geralmente de forma assintomática ou autolimitada. No entanto, em adolescentes e adultos, especialmente aqueles com doença hepática crônica preexistente, o curso clínico tende a ser mais grave<sup>76</sup> .  
No Brasil e no mundo, há também relatos de casos e surtos que ocorrem em populações com prática sexual que envolve contato oral-anal, especialmente em HSH. A adoção de medidas preventivas, como o uso de preservativos e higiene adequada, deve ser reforçada nessas situações<sup>77</sup> .  
35  
Entre pessoas com hepatite C, a coinfecção pelo HAV está associada a maior risco de descompensação hepática, hepatite fulminante e mortalidade aumentada<sup>78</sup> . Como não há tratamento antiviral específico para a hepatite A, o cuidado baseia-se em medidas de suporte clínico e monitoramento da função hepática.  
A vacinação contra o HAV é a principal medida preventiva e deve ser indicada a todos os indivíduos com hepatopatia crônica, incluindo aqueles com infecção pelo HCV, preferencialmente antes do desenvolvimento de fibrose avançada, devido à possível resposta imunológica reduzida em estágios mais graves ou após transplante hepático<sup>75</sup> .  
Além da imunização, recomenda-se adotar medidas gerais de prevenção da transmissão fecal-oral, como o consumo de água potável, higienização adequada das mãos, manipulação segura de alimentos e saneamento básico. A orientação sobre práticas sexuais seguras é igualmente relevante, especialmente em populações com maior risco de exposição oro-anal, como HSH, devendo-se reforçar o uso de preservativos e o cuidado com a higiene íntima antes e após as relações. Em ambientes coletivos e contextos de surto, é fundamental intensificar as ações de vigilância epidemiológica, garantir o acesso à vacina e promover a educação em saúde voltada à prevenção da hepatite A, com ênfase em higiene pessoal e segurança alimentar.  
Nos casos de exposição recente ao vírus (contato com caso confirmado), pessoas com hepatite C que não possuam imunidade prévia devem receber a profilaxia pós-exposição com a vacina contra o HAV em até 14 dias após contato<sup>20,75,79</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.5. Gestação e puerpério -->
O tratamento do HCV é contraindicado durante a gravidez, uma vez que não há estudos em larga escala que confirmem a segurança do uso de DAA nesta condição. Portanto, apesar de alguns estudos iniciais recentes revelarem boa resposta terapêutica, sem eventos adversos importantes com sofosbuvir<sup>80,81</sup> , indicando possíveis modificações no horizonte do tratamento de gestantes com HCV, o tratamento da hepatite C não deve ser realizado em grávidas.  
Toda gestante diagnosticada com hepatite C deve ser notificada e encaminhada para serviço de pré-natal de risco para acompanhamento conjunto com a APS. Não há evidência de transmissão do HCV pelo leite materno e, portanto, o aleitamento pode ser realizado desde que não haja lesões nos mamilos ou coinfecção pelo HIV.  
O uso DAA não é recomendado durante o aleitamento materno devido à ausência de dados robustos de comprovem sua segurança nesse período. Assim, recomenda-se, sempre que possível, aguardar o término do período de amamentação para o início do tratamento. Em puérperas com hepatite C que apresentem quadro clínico de maior gravidade ou outras condições que justifiquem intervenção imediata, a indicação de início da terapia deve ser avaliada de forma individualizada, considerando-se a relação entre riscos e benefícios do tratamento e a suspensão do aleitamento materno. Caso seja instituído tratamento com DAA, a amamentação deverá ser formalmente contraindicada durante todo o período de uso da terapia<sup>82</sup> .  
Para mais informações, orienta-se consultar o PCDT para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais vigente em <u>www.gov.br/aids/pt-br/centrais-de-conteudo/pcdts</u> e <u>https://www.gov.br/conitec/pt-br/assuntos/avaliacao-de-tecnologias-em-saude/protocolos-clinicos-ediretrizes-terapeuticas.</u>  
36

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.6. Doença renal crônica -->
A infecção pelo HCV é considerada um importante fator de risco para doença renal crônica (DRC) e, por isso, o cuidado desses pacientes envolve atenção. **Todos os esquemas de DAA, incluindo aqueles a base de sofosbuvir, são seguros e eficazes para tratar a hepatite C em pessoas com DRC, mesmo aquelas que estão em hemodiálise, sem necessidade de ajuste de doses** ou modificações nos esquemas recomendados para pacientes sem DRC<sup>83–85</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.7. Hepatite C em transplantados de órgãos sólidos -->
Os DAA apresentam elevada eficácia e boa tolerância em pacientes receptores de transplantes de órgãos sólidos, incluindo o transplante hepático, com perfil de interações favoráveis em relação aos imunossupressores usuais.  
O uso de órgãos provenientes de doadores com anti-HCV reagente, especialmente de doadores falecidos, tem se mostrado uma estratégia efetiva em diversos países para ampliar o acesso ao transplante de órgãos e tecidos, contribuindo para a redução do tempo e da mortalidade em lista de espera<sup>74</sup> . Em conformidade com o Regulamento Técnico do Sistema Nacional de Transplantes, nos casos de doador soropositivo para o HCV, os órgãos poderão ser utilizados, devendo ser realizada a testagem do HCV-RNA quantitativo. Nesses casos, é necessária a garantia de disponibilidade imediata de tratamento antiviral para o receptor sempre que o resultado do HCV-RNA for detectável ou ainda não estiver disponível logo após o transplante. Em casos de transplante hepático, recomenda-se não utilizar enxertos hepáticos de doadores HCV RNA detectável com fibrose moderada (F2) ou avançada (F3)<sup>35</sup> .  
É exigida a obtenção de termo de consentimento livre e esclarecido no momento da oferta de órgãos provenientes de doadores com sorologia anti-HCV reagente, bem como a organização de logística assistencial que assegure o acesso aos antivirais de ação direta no período pós-operatório imediato.  
É recomendado que o receptor de órgão de doador HCV-RNA detectável inicie o tratamento para HCV o mais cedo possível, com início preferencial dentro da primeira semana pós-transplante<sup>74</sup> , já que nessas situações, apesar de o risco de transmissão do HCV é elevado, há taxas muito altas de RVS após o uso de DAA<sup>35</sup> . Nesses cenários, o esquema terapêutico preconizado é a combinação de sofosbuvir 400 mg + velpatasvir 100 mg, 1 comprimido ao dia por 12 semanas, com monitorização de HCV-RNA em 12 semanas após o fim do tratamento. Em casos de crianças receptoras de órgãos entre 3 e 11 anos, o esquema indicado é sofosbuvir 200 mg + velpatasvir 50 mg granulado, na posologia de 1 sachê ao dia por 12 semanas.  
Na situação em que a coleta de HCV-RNA de um doador de órgão com sorologia anti-HCV reagente tenha sido realizada, porém o resultado do exame permaneça indisponível até o término da primeira semana após o transplante, recomenda-se o início do tratamento antiviral, com posterior avaliação quanto à manutenção ou interrupção do esquema terapêutico, conforme o resultado laboratorial.  
Quando, na avaliação pré-transplante, o resultado do HCV-RNA quantitativo do doador for não detectável, não há indicação de início do uso de antivirais. Nessas situações, o transplante poderá ser realizado, devendo ser assegurado o monitoramento clínico e laboratorial do receptor no período póstransplante.  
A condução do tratamento deve considerar cuidadosamente as potenciais interações medicamentosas entre os DAA e os imunossupressores utilizados no pós-transplante. A **Figura 6** resume as recomendações mencionadas nesse capítulo.  
37  
Figura 6: Planejamento de transplante de órgão sólido de doador com sorologia anti-HCV reagente.  
<!-- Start of picture text -->
Coleta de HCV-RNA do doador<br>Obtenco de TCLE<br>HCV-RNA indetectavel | HCV-RNA detectavel semana apésprimeira transplante<br>Monitoramento pés- Iniciar 1 comprimido/dia<br>Cee Paciente hospitalizado { Paciente desospitalizado de sofosbuvir<br>necessidade de uso de eS<br>ants Iniciar/manter 4100manutenc3o mg e reavaliarapis 0a<br>develpatasvir‘ambientesofosbuvir1 comprimido‘diahospitalar100400mg,mg em+ ‘Encaminhar‘ambulatorialpaciente especializadopara servico| resultadode HCV-RNA<br>Programar tratamento durante Iniciar’manter 1 comprimidovdia<br>especializado12ambulatorial semanas nae seguimentoemaltaservico hospitalar preferencialmentede‘semanavelpatasvir sofosbuvirpés transplante 100mg,400na mg primeira + Interromper tratamentomonitoramentomanter pés- €<br>transplante<br>Realizar carga viral (HCV-RNA)| Programar tratamento durante 12<br>tratamento12 semanas para averiguarapés fim do RVS SSS‘semanase seguimentoEEE S<br>especializado<br>Realizar carga viral (HCV-RNA)<br>12 semanas apés fim do<br>tratamento para averiguar RVS<br><!-- End of picture text -->  
Fonte: Nota técnica conjunta nº 1/2026-CGHV/.DATHI/SVSA/MS  
Legenda: TCLE: termo de consentimento livre esclarecido; RVS: resposta virológica sustentada  
**Doadores de órgãos com anti-HCV detectável devem realizar a testagem de HCV-RNA. Caso o resultado do HCV-RNA seja detectável ou ainda não estiver disponível na primeira semana após o transplante, o doador deve iniciar o esquema sofosbuvir 400 mg + velpatasvir 100 mg, 1 comprimido ao dia por 12 semanas.**

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 11.8. Recorrência da infecção pelo HCV em receptores de transplante hepático -->
A recorrência da infecção pelo HCV é universal em receptores de transplante hepático que já apresentavam HCV-RNA detectável antes do transplante. Assim, o receptor segue virêmico após o transplante, caso já fosse virêmico no pré-transplante. A cura da infecção prévia aumenta significativamente a sobrevida após o procedimento. Todos os pacientes com HCV receptores de transplante devem ser tratados o mais precocemente possível, tão logo estejam estabilizados<sup>86–88</sup> .  
O tratamento da recorrência da hepatite C depende do tratamento prévio e da sua resposta e está sumarizado nos itens _Esquemas recomendados para o retratamento da hepatite C_ .  
38

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 12. MANIFESTAÇÕES EXTRAHEPÁTICAS -->
Além da doença hepática, a hepatite C crônica está associada a maior risco de manifestações extrahepáticas, em razão de o HCV ser, além de hepatotrópico, linfotrópico. Assim, é possível o desenvolvimento de doenças neoplásicas e autoimunes, como linfoma de células B, crioglobulinemia, porfiria cutânea tardia, líquen plano, neuropatias e glomerulopatias<sup>89</sup> .  
Também são relatadas úlcera corneana (úlcera de Mooren), tireoidopatias, fibrose pulmonar, síndrome de Sjögren, doença renal crônica, diabete melito tipo 2, vasculite sistêmica (poliarterite nodosa, poliangeíte microscópica), artralgias, mialgias, poliartrite inflamatória, trombocitopenia autoimune e disfunção neurocognitiva, entre outras<sup>89,90</sup> .  
Portanto, diante de alguma dessas condições na prática clínica, é fundamental solicitar o teste diagnóstico de hepatite C, visto que a cura da infecção pelo HCV poderá resultar em cura ou melhora dessas complicações.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 13. MONITORAMENTO DURANTE O TRATAMENTO -->
Não há recomendação específica quanto ao número de consultas durante o tratamento com DAA. Os pacientes devem manter vínculo com o serviço de saúde suficiente para permitir o controle das condições clínicas concomitantes, a avaliação da adesão e de eventuais eventos adversos, o que deve ser definido individualmente pelos prescritores.  
Não é necessário solicitar exame de carga viral (HCV-RNA quantitativo) durante o curso do tratamento<sup>35,91</sup> . A RVS deverá ser avaliada por meio de exame de carga viral (HCV-RNA quantitativo) de 12 a 24 semanas após o término da terapia medicamentosa. Pacientes com comorbidades devem ter o monitoramento clínico-laboratorial individualizado.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 13.1. Eventos adversos -->
O tratamento da hepatite C com os atuais DAA é bem tolerado, com eventos adversos raros, leves e autolimitados, como cefaleia, fadiga e cansaço. Portanto, é importante orientar os pacientes para que não interrompam o tratamento desnecessariamente. Deve-se atentar para o risco de descompensação hepática durante o tratamento de pacientes com hepatopatia avançada.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 13.2. Adesão à terapia medicamentosa -->
A adesão ao tratamento medicamentoso constitui um fenômeno dinâmico e multifatorial, influenciado por condições socioeconômicas, características do tratamento, particularidades da pessoa, aspectos relacionados à condição de saúde/doença e fatores ligados ao(à) profissional, ao serviço e/ou à equipe de saúde, os quais podem estar interrelacionados.  
Esses cinco eixos compõem o modelo multidimensional de adesão proposto pela OMS<sup>92</sup> e devem ser considerados de forma integrada no cuidado às pessoas com hepatite C, reconhecendo que cada dimensão pode ser abordada por estratégias específicas no contexto da atenção à saúde.  
Ressalta-se a importância do acompanhamento dos usuários quanto ao uso dos medicamentos preconizados neste PCDT, a fim de garantir resultados terapêuticos positivos, bem como identificar e  
39  
resolver possíveis problemas relacionados à farmacoterapia. Nesse contexto, o Cuidado Farmacêutico contribui diretamente para o alcance dos melhores resultados em saúde, ao oferecer orientação, educação em saúde e monitoramento contínuo, promovendo o uso racional de medicamentos eficazes e seguros, além de estimular a adesão ao tratamento por meio do fornecimento de informações e apoio que fortalecem a autonomia e o autocuidado dos pacientes. Considerando que a adesão é determinante para o sucesso terapêutico, torna-se essencial que, no momento da dispensação, sejam disponibilizadas orientações claras sobre o uso racional dos medicamentos, potenciais interações e reações adversas e condutas a serem adotadas diante de seu surgimento. Assim, a integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é essencial para assegurar uma assistência à saúde mais segura, efetiva e centrada na pessoa, contemplando de maneira abrangente as necessidades de cada indivíduo<sup>93</sup> .  
Para ter acesso a estratégias para otimizar a adesão ao tratamento medicamentoso em casos de hepatites virais, consulte o Guia para atuação farmacêutica na promoção da adesão ao tratamento das pessoas com hepatites virais<sup>94</sup> .  
- 13.3. Interrupção de tratamento  
Em caso de interrupção do tratamento **por até 7 (sete) dias** , independentemente de o paciente ter completado ou não o primeiro mês de terapia, orienta-se **retomar o uso do medicamento e completar o tempo inicialmente previsto (12 ou 24 semanas)** .<sup>95</sup>  
Caso a interrupção ocorra por um período **maior que 7 (sete) dias antes da conclusão do primeiro mês de tratamento** , **orienta-se retomar o uso do medicamento e realizar o exame de carga viral imediatamente.**<sup>95</sup>  
a. Se a carga viral for indetectável, deve-se completar o tempo inicialmente recomendado (12 ou 24 semanas).  
b. Se a carga viral for detectável, ou na impossibilidade de realização do exame, deve-se completar o tempo restante acrescido de mais 4 (quatro) semanas de tratamento.  
Em caso de interrupção por um período **de 8 (oito) a 20 (vinte) dias após a conclusão de pelo menos 1 (um) mês de tratamento, orienta-se retomar a terapia e realizar o exame de carga viral no momento do reinício.**<sup>95</sup>  
- c. Se o resultado for indetectável, deve-se completar o tempo recomendado (12 ou 24 semanas).  
- d. Caso a carga viral esteja detectável, ou na impossibilidade de realização do exame, o tratamento deve ser interrompido e o paciente deve ser tratado como falha terapêutica e seguir para retratamento.  
Para interrupções por período **igual ou superior a 21 (vinte e um) dias, desde que a pessoa tenha completado ao menos 1 (um) mês de tratamento, recomenda-se realizar o exame de carga viral a partir de 12 (doze) semanas após a suspensão para avaliação da RVS.**<sup>95</sup>  
- a. O resultado indetectável confirma a RVS, não sendo necessário retomar o tratamento.  
- b.            Se a carga viral for detectável, ou na impossibilidade de realização do exame, recomendase tratar o caso como falha terapêutica e seguir para retratamento.  
Recomenda-se que a dispensação de esquemas terapêuticos para hepatite C seja realizada somente quando houver garantia de fornecimento do tratamento completo, em dispensação única, conforme a duração indicada (12 ou 24 semanas), de modo a evitar interrupções não programadas.  
A **Figura 7** evidencia a conduta a ser adotada nos possíveis cenários de interrupção de tratamento.  
40  
Figura 7 – Fluxograma de conduta frente à interrupção de tratamento  
<!-- Start of picture text -->
Paciente interrompe o tratamento<br>[ Esquema terapéutico utiizado por Esquema terapéutico utlizado por pelo<br>menos de um més menos um més<br>Interrupgdo de até 7 dias Interrupgdo acima de 7 dias Interrupgo de até 7 dias |_| Interrupcdo entre 8 e 20 dias meeae fied<br>Retomaro tratamento e Nao retomar<br>Retomarcompletar o tratamento eo tempo realizarRetomarcarga o tratamento eviral (HCV- | Retomar‘completar o tratamento  o tempo e realizar carga viral (HCV- carga viral (HCV-RNA)o tratamento a partir e realizar de 12<br>inicialmente previsto RNA) imediatamente inicialmente previsto RNA) imediatamente ‘semanas apés a interrupgao<br>Carga viral detectavel ou Carga viral Carga viral Carga viral detectavel ou Carga viral<br>indisponivel indetectavel indetectavel indisponivel indetectavel<br>eee cles Completar o tempo Completaro tempo | | Considerar como falha<br>etl Sie inicialmente previsto iniciaimente previsto terapéutica Cura (RVS)<br>ve de tratamento de tratamento (retratamento)<br><!-- End of picture text -->  
Fonte: elaboração própria, com base em Alghamdi _et al_ . 2024<sup>95</sup> .  
41

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 14. CARCINOMA HEPATOCELULAR -->
A hepatite C crônica é uma causa importante de carcinoma hepatocelular (CHC) em pacientes com cirrose. A cura da infecção viral em pacientes cirróticos reduz, mas não elimina o risco de CHC, particularmente em pacientes com comorbidades, como diabete melito, síndrome metabólica e consumo abusivo de álcool. Na atualidade, alguns indicadores não invasivos, como o APRI, o FIB-4 e a elastografia hepática transitória, combinados a outros parâmetros clínicos, têm sido utilizados para predizer o risco de CHC em pessoas após a RVS, mas ainda carecem de validação e padronização<sup>96</sup> .  
Pessoas incluídas em lista de espera para transplante hepático podem ser tratadas conforme o tempo estimado de permanência na lista ou, alternativamente, ter o tratamento postergado para o período pós-transplante. Já o tratamento de pessoas com CHC em estágio avançado deve ser individualizado e conduzido por especialistas<sup>10,96,97</sup> .

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 15. ACOMPANHAMENTO APÓS A CURA -->
A alta após a RVS pode ser programada para pacientes sem fibrose significativa (F0 a F2, ou seu equivalente em APRI < 1 e FIB4 < 1,45), devendo ser realizado aconselhamento quanto ao risco de reinfecção pelo HCV e à necessidade de evitar exposições, comportamentos ou condições clínicas associadas a potencial dano hepático. Pessoas com estadiamento de fibrose F2, que apresentam outros fatores de risco para a progressão da doença hepática (alcoolismo, coinfecção com HIV e/ou HBV, obesidade, diabetes, entre outros) deverão ser acompanhados ambulatorialmente, a critério do médico assistente.  
As pessoas com estadiamento de fibrose F3 e F4 não devem receber alta após a RVS e devem manter vigilância de CHC a cada seis meses. O rastreamento semestral de CHC de pessoas com cirrose hepática, por ultrassonografia de abdome superior complementada com a dosagem de alfafetoproteína, deve ser realizado semestralmente, de forma sistemática. Portanto, o seguimento de pacientes com fibrose significativa (F3-F4) ou com comorbidades que aceleram a progressão da fibrose hepática deve ser realizado em serviços especializados. A duração do rastreamento de CHC em pacientes com fibrose avançada ou cirrose com RVS é indefinida<sup>97,98</sup> . O uso de medicamentos potencialmente hepatotóxicos deve ser evitado em todos os pacientes com hepatopatias crônicas, incluindo aqueles com RVS.  
Em pacientes com cirrose após RVS, a endoscopia digestiva deve ser realizada se varizes foram diagnosticadas no exame pré-tratamento ou se houver queda da contagem de plaquetas abaixo de 150.000/mL e se o resultado da elastografia for superior a 20 kPa<sup>98</sup> .  
Na ausência de cofatores, os pacientes com cirrose que alcançam a RVS e mostram melhorias póstratamento consistentes com valores de elastografia abaixo de 12 kPa e contagem de plaquetas acima de 150.000/mL podem ser considerados sem hipertensão portal e, portanto, sem maior risco de descompensação hepática, não sendo necessário repetir a endoscopia digestiva alta. No entanto, o rastreamento do CHC deve ser mantido por tempo indeterminado<sup>98</sup> .  
Todas as pessoas devem ter conhecimento de que a hepatite C é uma infecção que não confere imunidade; portanto, há risco de reinfecção após a cura. O profissional assistente deve reforçar as vias de transmissão e formas de prevenção da hepatite C (ver seção _Transmissão_ ). Além disso, as pessoas identificadas com fatores de vulnerabilidade para reinfecção viral devem manter acompanhamento semestral ou anual com investigação de viremia pelo HCV-RNA. Em caso de reinfecção, o paciente deve ser tratado com o esquema de tratamento inicial.  
A APS desempenha papel fundamental na manutenção do vínculo e no acompanhamento póstratamento das pessoas curadas da hepatite C, especialmente daquelas que permanecem em situação de vulnerabilidade ou risco de reinfecção. O acompanhamento longitudinal permite identificar precocemente sinais de reinfecção, reforçar medidas de prevenção e promover o cuidado integral. Nesse contexto, o  
42  
ACS/TACS tem atuação estratégica ao identificar, orientar e encaminhar essas pessoas para avaliação pela equipe multiprofissional, fortalecendo a vigilância ativa e a continuidade do cuidado no território.  
Pacientes com RVS sem fibrose ou com fibrose hepática leve (Metavir < 2, APRI <1 ou FIB-4 < 1,3) devem manter o controle clínico caso apresentem fatores de risco de evolução da hepatopatia, como síndrome metabólica, alcoolismo, coinfecções com HIV ou HBV ou outras hepatopatias. A regularidade desse acompanhamento deve ser individualizada.  
**Pacientes sem fibrose avançada, sem fatores de risco relevantes para reinfecção do HCV e sem fatores de risco concomitantes para agravamento da hepatopatia podem receber alta do acompanhamento após a cura. Em caso de reinfecção, devem ser tratados com o esquema inicial.**

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 16. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, a verificação periódica das doses de medicamentos prescritas e dispensadas, a adequação do uso dos fármacos e o acompanhamento pós-tratamento.  
Os pacientes com hepatite C, coinfecções, comorbidades graves e APRI ≥ 1 devem ser atendidos em serviços especializados para o adequado diagnóstico, a inclusão no protocolo de tratamento e o acompanhamento. A existência de serviços especializados facilita o tratamento em si, bem como o ajuste de doses, caso necessário, e o controle de eventos adversos.  
A APS é a principal porta de entrada e a coordenadora do cuidado da Rede de Atenção à Saúde (RAS), atuando de forma territorializada e próxima às comunidades. Cabe a ela a detecção precoce de sinais e sintomas sugestivos de condições clínicas, relacionados aos fatores de risco e à vulnerabilidade, viabilizando intervenções oportunas e resolutivas. Além do acolhimento e atendimento clínico, a APS promove ações de educação em saúde voltadas a pacientes e familiares, abordando os riscos, a adesão ao tratamento e o reconhecimento de sinais de agravamento. É também o espaço privilegiado para o acompanhamento longitudinal, com monitoramento periódico do controle clínico, ajuste de condutas terapêuticas e identificação de comorbidades que possam impactar a evolução da saúde. Por meio de ações de promoção à saúde, tais como o incentivo à prática de atividade física segura, a alimentação saudável e o controle ambiental, a atenção primária contribui para minimizar ou eliminar fatores de risco que determinam a patogênese, prevenir o agravamento de doenças e melhorar a qualidade de vida das pessoas.  
A organização e a regulação dos fluxos de encaminhamento para a atenção especializada devem assegurar que casos de maior complexidade, suspeitas diagnósticas ou demandas por terapias específicas sejam avaliados em tempo oportuno. A articulação com os demais pontos da Rede de Atenção à Saúde fortalece a coordenação do cuidado, promove o uso racional dos recursos e contribui para melhores desfechos clínicos.  
Assim, o fortalecimento da APS no cuidado das condições de saúde amplia o acesso, qualifica a resolutividade e consolida uma abordagem integral, contínua e centrada na pessoa, em consonância com as diretrizes nacionais e a organização da rede assistencial.  
É necessário verificar, na Relação Nacional de Medicamentos Essenciais (Rename) vigente, em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar essas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do SUS (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por  
43  
código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
17. REFERÊNCIAS  
1. Global hepatitis report 2024: action for access in low- and middle-income countries, https://www.who.int/publications/i/item/9789240091672 (accessed 11 August 2025).  
2. Hepatitis, https://www.who.int/multi-media/details/elimination-of-hepatitis-by-2030 (accessed 12 November 2025).  
3. Boletim Epidemiológico de Hepatites Virais - Número Especial | Jul. 2025 — Ministério da Saúde, https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/boletins/epidemiologicos/especiais/2025/boletim-epidemiologico-dehepatites-virais.pdf/view (accessed 11 August 2025).  
4. Guia de vigilância em saúde: volume 2 (6<sup>a</sup> edição - revisada) — Ministério da Saúde, https://www.gov.br/saude/pt-br/centrais-de-conteudo/publicacoes/svsa/vigilancia/guia-devigilancia-em-saude-volume-2-6a-edicao/view (accessed 8 August 2025).  
5. Moradpour D, Penin F, Rice CM. Replication of hepatitis C virus. _Nat Rev Microbiol_ 2007; 5: 453– 463.  
6. Lingala S, Ghany MG. Natural History of Hepatitis C. _Gastroenterol Clin North Am_ 2015; 44: 717– 734.  
7. Liu C-H, Kao J-H. Acute hepatitis C virus infection: clinical update and remaining challenges. _Clin Mol Hepatol_ 2023; 29: 623–642.  
8. Omata M, Kanda T, Wei L, et al. APASL consensus statements and recommendations for hepatitis C prevention, epidemiology, and laboratory testing. _Hepatol Int_ 2016; 10: 681–701.  
9. Hepatitis C, https://www.who.int/news-room/fact-sheets/detail/hepatitis-c (accessed 12 November 2025).  
10.  Thein H-H, Yi Q, Dore GJ, et al. Estimation of stage-specific fibrosis progression rates in chronic hepatitis C virus infection: a meta-analysis and meta-regression. _Hepatol Baltim Md_ 2008; 48: 418– 431.  
11.  Sangiovanni A, Prati GM, Fasani P, et al. The natural history of compensated cirrhosis due to hepatitis C virus: A 17-year cohort study of 214 patients. _Hepatol Baltim Md_ 2006; 43: 1303–1310.  
12.  AASLD-IDSA HCV Guidance Panel. Hepatitis C Guidance 2018 Update: AASLD-IDSA Recommendations for Testing, Managing, and Treating Hepatitis C Virus Infection. _Clin Infect Dis Off Publ Infect Dis Soc Am_ 2018; 67: 1477–1492.  
13.  Consolidated guidelines on HIV, viral hepatitis and STI for key populations - 2022, https://www.who.int/publications/i/item/9789240052390 (accessed 17 November 2025).  
14.  Schillie S, Wester C, Osborne M, et al. CDC Recommendations for Hepatitis C Screening Among Adults — United States, 2020. _MMWR Recomm Rep_ 2020; 69: 1–17.  
15.  Arshad M, El-Kamary SS, Jhaveri R. Hepatitis C virus infection during pregnancy and the newborn period--are they opportunities for treatment? _J Viral Hepat_ 2011; 18: 229–236.  
16.  El-Shabrawi MHF, Kamal NM, Mogahed EA, et al. Perinatal transmission of hepatitis C virus: an update. _Arch Med Sci AMS_ 2019; 16: 1360–1369.  
44  
17.  HCV in Pregnancy – HCV Guidance. _https://www.hcvguidelines.org/_ , https://www.hcvguidelines.org/guidance/hcv-in-pregnancy/ (accessed 18 November 2025).  
18.  Guia para Eliminação das Hepatites Virais no Brasil — Departamento de HIV, Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis, https://www.gov.br/aids/pt-br/central-deconteudo/publicacoes/2025/guia-para-eliminacao-das-hepatites-virais-no-brasil.pdf/view (accessed 18 November 2025).  
19.  Terrault NA. Care of Patients Following Cure of Hepatitis C Virus Infection. _Gastroenterol Hepatol_ 2018; 14: 629–634.  
20.  Saúde M da. _Manual dos Centros de Referência para Imunobiológicos Especiais_ . 6th ed. Brasília, DF: Ministério da Saúde, 2024.  
21.  Nota Técnica n<sup>o</sup> 58/2025-CGICI/DPNI/SVSA/MS — Ministério da Saúde, https://www.gov.br/saude/pt-br/centrais-de-conteudo/publicacoes/notas-tecnicas/2025/nota-tecnicano-58-2025-cgici-dpni-svsa-ms/view (accessed 11 November 2025).  
22.  Calendário de Vacinação. _Ministério da Saúde_ , https://www.gov.br/saude/ptbr/vacinacao/calendario/calendario (accessed 12 November 2025).  
23.  Nacional I. PORTARIA GM/MS N<sup>o</sup> 5.663, DE 31 DE outubro DE 2024 - DOU - Imprensa Nacional, https://www.in.gov.br/en/web/dou/-/portaria-gm/ms-n-5.663-de-31-de-outubro-de-2024-593693777 (accessed 1 December 2025).  
24.  CDC. Hepatitis C Basics. _Hepatitis C_ , https://www.cdc.gov/hepatitis-c/about/index.html (2025, accessed 15 December 2025).  
25.  Painel Polaris – Fundação CDA, https://cdafound.org/polaris/dashboard/ (accessed 15 December 2025).  
26.  Hepatitis C, https://www.who.int/news-room/fact-sheets/detail/hepatitis-c (accessed 15 December 2025).  
27.  Priorities in planning person-centred hepatitis B and C testing services: operational guide, https://www.who.int/publications/i/item/9789240104082 (accessed 15 December 2025).  
28.  Schillie S, Wester C, Osborne M, et al. CDC Recommendations for Hepatitis C Screening Among Adults — United States, 2020. _MMWR Recomm Rep_ 2020; 69: 1–17.  
29.  Manual Técnico - Diagnóstico das Hepatites Virais — Ministério da Saúde, https://www.gov.br/saude/pt-br/centrais-de-conteudo/publicacoes/svsa/hepatites/manual-tecnicodiagnostico-das-hepatites-virais/view (accessed 15 December 2025).  
30.  Priorities in planning person-centred hepatitis B and C testing services: operational guide, https://www.who.int/publications/i/item/9789240104082 (accessed 15 December 2025).  
31.  Moradpour D, Penin F, Rice CM. Replication of hepatitis C virus. _Nat Rev Microbiol_ 2007; 5: 453– 463.  
32.  Liu C-H, Kao J-H. Acute hepatitis C virus infection: clinical update and remaining challenges. _Clin Mol Hepatol_ 2023; 29: 623–642.  
33.  Fluxogramas para manejo clínico das Infecções Sexualmente Transmissíveis 2021.  
34.  Guidelines for the prevention, diagnosis, care and treatment for people with chronic hepatitis B infection.  
35.  European Association for the Study of the Liver. Electronic address: easloffice@easloffice.eu, Clinical Practice Guidelines Panel: Chair:, EASL Governing Board representative:, et al. EASL  
45  
recommendations on treatment of hepatitis C: Final update of the series☆. _J Hepatol_ 2020; 73: 1170– 1218.  
36.  Simmons B, Saleem J, Hill A, et al. Risk of Late Relapse or Reinfection With Hepatitis C Virus After Achieving a Sustained Virological Response: A Systematic Review and Meta-analysis. _Clin Infect Dis Off Publ Infect Dis Soc Am_ 2016; 62: 683–694.  
37.  Sarrazin C, Isakov V, Svarovskaia ES, et al. Late Relapse Versus Hepatitis C Virus Reinfection in Patients With Sustained Virologic Response After Sofosbuvir-Based Therapies. _Clin Infect Dis Off Publ Infect Dis Soc Am_ 2017; 64: 44–52.  
38. _Global Health Sector Strategies on, Respectively, HIV, Viral Hepatitis and Sexually Transmitted Infections for the Period 2022-2030_ . 1st ed. Geneva: World Health Organization, 2022.  
39.  Bang CS, Song IH. Impact of antiviral therapy on hepatocellular carcinoma and mortality in patients with chronic hepatitis C: systematic review and meta-analysis. _BMC Gastroenterol_ 2017; 17: 46.  
40.  Backus LI, Belperio PS, Shahoumian TA, et al. Impact of Sustained Virologic Response with DirectActing Antiviral Treatment on Mortality in Patients with Advanced Liver Disease. _Hepatol Baltim Md_ 2019; 69: 487–497.  
41.  Morgan RL, Baack B, Smith BD, et al. Eradication of hepatitis C virus infection and the development of hepatocellular carcinoma: a meta-analysis of observational studies. _Ann Intern Med_ 2013; 158: 329–337.  
42.  van der Meer AJ, Veldt BJ, Feld JJ, et al. Association between sustained virological response and all-cause mortality among patients with chronic hepatitis C and advanced hepatic fibrosis. _JAMA_ 2012; 308: 2584–2593.  
43. _Elegibilidade Dos Contraceptivos para Mulheres Com Alto Risco de Infecção Pelo HIV. Diretriz: Recomendações Sobre o Uso de Métodos Contraceptivos Por Mulheres Com Alto Risco de Infecção Pelo HIV_ . 1st ed. Geneva: World Health Organization, 2020.  
44.  L7498, https://www.planalto.gov.br/ccivil_03/leis/l7498.htm (accessed 11 February 2026).  
45.  D94406, https://www.planalto.gov.br/ccivil_03/decreto/1980-1989/d94406.htm (accessed 11 February 2026).  
46.  L12842, https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2013/lei/l12842.htm (accessed 11 February 2026).  
47.  L13021, https://www.planalto.gov.br/ccivil_03/_ato2011-2014/2014/lei/l13021.htm (accessed 11 February 2026).  
48.  ASCOM. RESOLUÇÃO COFEN-195/1997 - Cofen. _Cofen -_ , https://www.cofen.gov.br/resoluocofen-1951997/ (2011, accessed 11 February 2026).  
49.  ASCOM. RESOLUÇÃO COFEN N<sup>o</sup> 564/2017 - Cofen. _Cofen -_ , https://www.cofen.gov.br/resolucao-cofen-no-5642017/ (2017, accessed 11 February 2026).  
50.  CONSELHO FEDERAL DE FARMÁCIA (CFF). Resolução n<sup>o</sup> 585, de 29 de agosto de 2013. Regulamenta as atribuições clínicas do farmacêutico e dá outras providências. Brasília, DF: CFF, 2013.  
51.  CONSELHO FEDERAL DE FARMÁCIA (CFF). Resolução n<sup>o</sup> 509, de 29 de julho de 2009. Regula a atuação do farmacêutico em centros de pesquisa clínica, organizações representativas de pesquisa clínica, indústria ou outras instituições que realizem pesquisa clínica. Brasília, DF: CFF, 2009.  
46  
52.  Nacional I. PORTARIA N<sup>o</sup> 2.436, DE 21 DE SETEMBRO DE 2017 - Imprensa Nacional, https://www.in.gov.br/materia/-/asset_publisher/Kujrw0TZC2Mb/content/id/19308123/do1-201709-22-portaria-n-2-436-de-21-de-setembro-de-2017-19308031 (accessed 11 February 2026).  
53.  PCDT da Hepatite C — Ministério da Saúde, https://www.gov.br/saude/pt-br/centrais-deconteudo/publicacoes/svsa/hepatites/pcdt-da-hepatite-c/view (accessed 12 November 2025).  
54.  NOTA TÉCNICA N<sup>o</sup> 5_2025_CGHV_DATHI_SVSA_MS.pdf — Departamento de HIV, Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis, https://www.gov.br/aids/ptbr/central-de-conteudo/notas-tecnicas/2025/nota-tecnica-no-5_2025_cghv_dathi_svsa_ms.pdf/view (accessed 22 August 2025).  
55.  BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Coordenação-Geral de Vigilância do HIV/AIDS e das Hepatites Virais. Nota Técnica n<sup>o</sup> 369/2020-CGAHV/DCCI/SVS/MS: orientações sobre a atuação da(o) enfermeira(o) para a ampliação estratégica do acesso da população brasileira ao diagnóstico das hepatites B e C e encaminhamento de casos detectados para tratamento. Brasília, DF: Ministério da Saúde, 2020.  
56.  Rungta S, Kumari S, Deep A, et al. APRI and FIB-4 performance to assess liver fibrosis against predefined Fibroscan values in chronic hepatitis C virus infection. _J Fam Med Prim Care_ 2021; 10: 4082.  
57.  Wai C-T, Greenson JK, Fontana RJ, et al. A simple noninvasive index can predict both significant fibrosis and cirrhosis in patients with chronic hepatitis C. _Hepatol Baltim Md_ 2003; 38: 518–526.  
58.  Protocolo Clínico e Diretrizes Terapêuticas para Hepatite C e Coinfecções — Departamento de HIV, Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis, https://www.gov.br/aids/pt-br/central-de-conteudo/pcdts/2017/hepatitesvirais/pcdt_hepatite_c_06_2019_isbn.pdf/view (accessed 14 August 2025).  
59.  Afdhal NH, Bacon BR, Patel K, et al. Accuracy of fibroscan, compared with histology, in analysis of liver fibrosis in patients with hepatitis B or C: a United States multicenter study. _Clin Gastroenterol Hepatol Off Clin Pract J Am Gastroenterol Assoc_ 2015; 13: 772-779.e1–3.  
60.  Castéra L, Foucher J, Bernard P-H, et al. Pitfalls of liver stiffness measurement: a 5-year prospective study of 13,369 examinations. _Hepatol Baltim Md_ 2010; 51: 828–835.  
61.  de Franchis R, Bosch J, Garcia-Tsao G, et al. Baveno VII - Renewing consensus in portal hypertension. _J Hepatol_ 2022; 76: 959–974.  
62.  Tsoris A, Marlar CA. Use Of The Child Pugh Score In Liver Disease. In: _StatPearls [Internet]_ . StatPearls Publishing, https://www.ncbi.nlm.nih.gov/books/NBK542308/ (2023, accessed 15 December 2025).  
63.  Pawlotsky J-M, Negro F, Aghemo A, et al. EASL recommendations on treatment of hepatitis C: Final update of the series☆. _J Hepatol_ 2020; 73: 1170–1218.  
64.  Updated recommendations on treatment of adolescents and children with chronic HCV infection, https://www.who.int/publications/i/item/9789240052710 (accessed 13 November 2025).  
65.  Bortolotti F, Verucchi G, Cammà C, et al. Long-term course of chronic hepatitis C in children: from viral clearance to end-stage liver disease. _Gastroenterology_ 2008; 134: 1900–1907.  
66.  Iorio R, Giannattasio A, Sepe A, et al. Chronic hepatitis C in childhood: an 18-year experience. _Clin Infect Dis Off Publ Infect Dis Soc Am_ 2005; 41: 1431–1437.  
67.  Guidelines for the Use of Antiretroviral Agents in Adults and Adolescents With HIV.  
47  
68.  Saúde M da. _Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais_ . Brasília, DF: Ministério da Saúde, 2022.  
69.  Terrault NA, Lok ASF, McMahon BJ, et al. Update on Prevention, Diagnosis, and Treatment of Chronic Hepatitis B: AASLD 2018 Hepatitis B Guidance. _Clin Liver Dis_ 2018; 12: 33.  
70.  Updated recommendations on treatment of adolescents and children with chronic HCV infection, and HCV simplified service delivery and diagnostics, https://www.who.int/publications/i/item/9789240052734 (accessed 1 December 2025).  
71.  Liu C-H, Kao J-H. Acute hepatitis C virus infection: clinical update and remaining challenges. _Clin Mol Hepatol_ 2023; 29: 623–642.  
72.  Council(OARAC) HP on AG for A and A-AWG of the O of ARA. Guidelines for the Use of Antiretroviral Agents in Adults and Adolescents with HIVS. In: _ClinicalInfo.HIV.gov [Internet]_ . US Department of Health and Human Services, https://www.ncbi.nlm.nih.gov/books/NBK586306/ (2024, accessed 13 August 2025).  
73.  Pol S, Haour G, Fontaine H, et al. The negative impact of HBV/HCV coinfection on cirrhosis and its consequences. _Aliment Pharmacol Ther_ 2017; 46: 1054–1060.  
74.  Bhattacharya D, Aronsohn A, Price J, et al. Hepatitis C Guidance 2023 Update: American Association for the Study of Liver Diseases– Infectious Diseases Society of America Recommendations for Testing, Managing, and Treating Hepatitis C Virus Infection. _Clin Infect Dis_ 2023; ciad319.  
75.  Hepatitis A vaccines: WHO position paper, October 2022, https://www.who.int/publications/i/item/who-wer9740-493-512 (accessed 11 November 2025).  
76.  Hepatitis A, https://www.who.int/news-room/fact-sheets/detail/hepatitis-a (accessed 11 November 2025).  
77.  Hepatitis A virus infection in adults: Epidemiology, clinical manifestations, and diagnosis - UpToDate, https://www.uptodate.com/contents/hepatitis-a-virus-infection-in-adults-epidemiologyclinical-manifestations-and-diagnosis (accessed 11 November 2025).  
78.  Kanda T, Sasaki R, Masuzaki R, et al. Co-Occurrence of Hepatitis A Infection and Chronic Liver Disease. _Int J Mol Sci_ 2020; 21: 6384.  
79.  CDC. Chapter 9: Hepatitis A. _Epidemiology and Prevention of Vaccine-Preventable Diseases_ , https://www.cdc.gov/pinkbook/hcp/table-of-contents/chapter-9-hepatitis-a.html (2025, accessed 11 November 2025).  
80.  Chappell CA, Scarsi KK, Kirby BJ, et al. Ledipasvir plus sofosbuvir in pregnant women with hepatitis C virus infection: a phase 1 pharmacokinetic study. _Lancet Microbe_ 2020; 1: e200–e208.  
81.  Yattoo GN, Shafi SM, Dar GA, et al. Safety and efficacy of treatment for chronic hepatitis C during pregnancy: A prospective observational study in Srinagar, India. _Clin Liver Dis_ 2023; 22: 134–139.  
82.  Freriksen JJM, van Seyen M, Judd A, et al. Review article: direct‐acting antivirals for the treatment of HCV during pregnancy and lactation ‐ implications for maternal dosing, foetal exposure, and safety for mother and child. _Aliment Pharmacol Ther_ 2019; 50: 738–750.  
83.  Borgia SM, Dearden J, Yoshida EM, et al. Sofosbuvir/velpatasvir for 12 weeks in hepatitis C virusinfected patients with end-stage renal disease undergoing dialysis. _J Hepatol_ 2019; 71: 660–665.  
84.  Gaur N, Malhotra V, Agrawal D, et al. Sofosbuvir-Velpatasvir Fixed Drug Combination for the Treatment of Chronic Hepatitis C Infection in Patients With End-Stage Renal Disease and Kidney Transplantation. _J Clin Exp Hepatol_ 2020; 10: 189–193.  
48  
85.  Li M, Chen J, Fang Z, et al. Sofosbuvir-based regimen is safe and effective for hepatitis C infected patients with stage 4-5 chronic kidney disease: a systematic review and meta-analysis. _Virol J_ 2019; 16: 34.  
86.  Berenguer M, Palau A, Aguilera V, et al. Clinical benefits of antiviral therapy in patients with recurrent hepatitis C following liver transplantation. _Am J Transplant Off J Am Soc Transplant Am Soc Transpl Surg_ 2008; 8: 679–687.  
87.  Forman LM, Lewis JD, Berlin JA, et al. The association between hepatitis C infection and survival after orthotopic liver transplantation. _Gastroenterology_ 2002; 122: 889–896.  
88.  Prieto M, Berenguer M, Rayón JM, et al. High incidence of allograft cirrhosis in hepatitis C virus genotype 1b infection following transplantation: relationship with rejection episodes. _Hepatol Baltim Md_ 1999; 29: 250–256.  
89.  Cacoub P, Saadoun D. Extrahepatic Manifestations of Chronic HCV Infection. _N Engl J Med_ 2021; 384: 1038–1052.  
90.  Wilson SE, Lee WM, Murakami C, et al. Mooren’s Corneal Ulcers and Hepatitis C Virus Infection. _N Engl J Med_ 1993; 329: 62–62.  
91.  Guidelines for the prevention, diagnosis, care and treatment for people with chronic hepatitis B infection.  
92.  Adherence to long-term therapies : evidence for action, https://iris.who.int/items/bf8058c0-03b24b47-838f-5534849927fb (accessed 15 December 2025).  
93.  Minist�rio da Sa�de, https://bvsms.saude.gov.br/bvs/saudelegis/gm/2024/prt4379_17_06_2024.html (accessed 15 December 2025).  
94.  Saúde M da. _Guia para atuação farmacêutica na promoção da adesão ao tratamento de pessoas com hepatites virais_ . Brasília, DF: Ministério da Saúde, 2025.  
95.  Alghamdi AS, Alghamdi H, Alserehi HA, et al. SASLT guidelines: Update in treatment of hepatitis C virus infection, 2024. _Saudi J Gastroenterol Off J Saudi Gastroenterol Assoc_ 2024; 30: S1–S42.  
96.  Sangiovanni A, Prati GM, Fasani P, et al. The natural history of compensated cirrhosis due to hepatitis C virus: A 17-year cohort study of 214 patients. _Hepatol Baltim Md_ 2006; 43: 1303–1310.  
97.  Erradicação da infecção pelo vírus da hepatite C e desenvolvimento de carcinoma hepatocelular: uma meta-análise de estudos observacionais: Annals of Internal Medicine: Vol 158, No 5_Part_1, https://www.acpjournals.org/doi/10.7326/0003-4819-158-5-201303050-00005?url_ver=Z39.882003&rfr_id=ori:rid:crossref.org&rfr_dat=cr_pub%20%200pubmed (accessed 15 December 2025).  
98.  Pawlotsky J-M, Negro F, Aghemo A, et al. EASL recommendations on treatment of hepatitis C: Final update of the series☆. _J Hepatol_ 2020; 73: 1170–1218.  
99.  Liverpool HEP Interactions, https://hep-druginteractions.org/checker# (accessed 25 August 2025).  
49

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: MATERIAL SUPLEMENTAR – INTERAÇÕES MEDICAMENTOSAS -->
|**Medicamento**|**SOF/VEL**<br>**GLE/PIB**<br>**SOF/VEL/VOX**<br>**ANTIARRÍTMICOS**|**SOF**|**DCV**|
|---|---|---|---|
|Amiodarona||||
|Digoxina||||
|Lidocaína||||
|Propafenona||||
||**ANTIBIÓTICOS**<br>|||
|Amoxicilina<br>||||
|Azitromicina<br>||||
|Benzilpenicilina||||
|Cefalexina||||
|Ciprofloxacino||||
|Clavulanato||||
|Clindamicina||||
|Levofloxacino||||
|Metronidazol||||
|Nitrofurantoína||||
|SMX/TMP||||
||**ANTICOAGULANTES E ANTIAGREGANTES**|||
|Clopidogrel||||
|Dabigatrana||||
|Enoxaparina||||
|Rivaroxabana||||
|Varfarina||||
||**ANTICONVULSIVANTES**<br>|||
|Carbamazepina<br>||||
|Gabapentina<br>||||
|Lamotrigina<br>||||
|Fenobarbital<br><br>||||
|Fenitoína<br>||||
|Valproato<br>||||  
50  
|**Medicamentos**|**SOF/V**|**EL**<br>**GLE/PIB**<br>**SOF/V**|**EL/VOX**|**SOF**|**DCV**|
|---|---|---|---|---|---|
|||**ANTIDEPRESSIV**|**OS**|||
|Amitriptilina||||||
|Bupropiona||||||
|Citalopram||||||
|Escitalopram||||||
|Fluoxetina||||||
|Paroxetina||||||
|Sertralina||||||
|Venlafaxina||||||
|||**ANTIDIABÉTICOS**||||
|Glibenclamida||||||
|Insulina||||||
|Metformina||||||
|||**ANTIHISTAMÍNICOS**||||
|Desloratadina||||||
|Hidroxizina||||||
|Loratadina||||||
|Prometazina||||||
|||**ANTIPSICÓTICOS**||||
|Clorpromazina||||||
|Haloperidol||||||
|Quetiapina||||||
|Risperidona||||||
||**A**|**NSIOLÍTICOS E HIPNÓTI**|**COS**|||
|Alprazolam||||||
|Bromazepam||||||
|Diazepam||||||
|Lorazepam||||||
|Midazolam||||||
|Zolpidem||||||
|||**BETABLOQUEADORES**||||
|Atenolol||||||
|Bisoprolol||||||
|Carvedilol||||||
|Metoprolol||||||
|Propranolol||||||  
51  
|**Medicamentos**|**SOF/VE**|**L**<br>**GLE/PIB**|<br>**SOF/VEL/VOX**|**SOF**|**DCV**|
|---|---|---|---|---|---|
|||**INIBIDORES**|**DE CANAL DE CÁLCI**|**O**||
|Anlodipino||||||
|Diltiazem||||||
|Nifedipino||||||
|Verapamil||||||
|||**AGENTES GAS**|**TROINTESTINAIS**|||
|Antiácidos||||||
|Domperidona||||||
|Omeprazol||||||
|Simeticona||||||
|||**ANTI-HIP**|**ERTENSIVOS**|||
|Captopril||||||
|Clonidina||||||
|Doxazosina||||||
|Enalapril||||||
|Furosemida||||||
|Hidroclorotiazida||||||
|Losartana||||||
|Espironolactona||||||
|||**HIPOLI**|**PEMIANTES**|||
|Atorvastatina||||||
|Fenofibrato||||||
|Rosuvastatina||||||
|Sinvastatina||||||  
Legenda: SOF: sofosbuvir; DCV: daclatasvir; VEL: velpatasvir; VOX: voxilaprevir; GLE: glecaprevir;  
PIB: pibrentasvir.  
Fonte: Liverpool HEP Drug Interactions<sup>99</sup>  
: nenhuma interação significativa é esperada.  
- : necessidade de ajuste de dose, horário de administração ou monitoramento adicional.  
- : esses medicamentos não devem ser coadministrados.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: MATERIAL SUPLEMENTAR - INTERAÇÕES MEDICAMENTOSAS COM IMUNOSSUPRESSORES -->
Os medicamentos utilizados para o tratamento da infecção pelo HCV em pacientes receptores de transplante, incluindo transplante de fígado, apresentam bom perfil de interações com os medicamentos imunossupressores. No entanto, é necessário monitorar possíveis interações.  
O esquema sofosbuvir/velpatasvir pode interferir na farmacocinética do tacrolimo, everolimo e ciclosporina. Os esquemas glecaprevir/pibrentasvir e sofosbuvir/velpatasvir/voxilaprevir podem interferir  
52  
na farmacocinética do tacrolimo, sirolimo e everolimo. Portanto, é recomendado o monitoramento cuidadoso desses imunossupressores nesses casos.  
A associação de glecaprevir e pibrentasvir com ciclosporina leva ao aumento dos níveis séricos dessa associação. Com a dose de ciclosporina de até 100 mg/dia, esse aumento não é clinicamente significativo, mas o uso desse esquema de DAA é contraindicado se doses maiores de ciclosporina forem utilizadas. Já a associação do esquema sofosbuvir/velpatasvir/voxilaprevir com ciclosporina é contraindicada.  O **Quadro S1** descreve as principais interações entre imunossupressores e medicamentos para a hepatite C.  
**Quadro S1.** Principais interações entre imunossupressores e medicamentos para hepatite C  
|**Imunossupressores**|**SOF/VEL**|**GLE/PIB**|**SOF/VEL/VOX**|**SOF + DCV**|
|---|---|---|---|---|
|**Azatioprina**|||||
|**Ciclosporina**|||||
|**Tacrolimo**|||||
|**Sirolimo**|||||
|**Everolimo**|||||
|**Micofenolato**|||||
|**Prednisona**|||||
|**Metilprednisolona**|||||  
Legenda: DCV: daclatasvir; SOF: sofosbuvir; VEL: velpatasvir; VOX: voxilaprevir; GLE: glecaprevir; PIB: pibrentasvir.  
Fonte: Adaptado de EASL, 2020<sup>98</sup> .  
- : nenhuma interação significativa é esperada.  
- : necessidade de ajuste de dose, horário de administração ou monitoramento adicional (checar o texto).  
- : potencial interação.  
- : esses medicamentos não devem ser coadministrados.  
MATERIAL SUPLEMENTAR - INTERAÇÕES MEDICAMENTOSAS COM ANTIRRETROVIRAIS  
O **Quadro S2** descreve as principais interações entre antirretrovirais e medicamentos para a hepatite C.  
**Quadro S2.** Principais interações entre antirretrovirais e medicamentos para hepatite C  
|**Medicamentos**||_IT_|_RN_||_INI_|_IP_|_/r_|_IT_|_RNN_|
|---|---|---|---|---|---|---|---|---|---|
|**para hepatite C**|TDF|3TC|AZT|ABC|DTG|DRV/r|ATV/r|EFV|NVP|
|SOF/VEL||||||||||
|GLE/PIB||||||||||  
53  
|**Medicamentos**<br>**para hepatite C**|TDF|_IT_<br>3TC|_RN_<br>AZT|ABC|_INI_<br>DTG|_IP_<br>DRV/r|_/r_<br>ATV/r|_IT_<br>EFV|_RNN_<br>NVP|
|---|---|---|---|---|---|---|---|---|---|
|SOF/VEL/VOX||||||||||
|SOF||||||||||
|DCV||||||||||  
Legenda: ITRN, inibidor de transcriptase reversa análogo de nucleo(t)sídeo; INI, inibidor de integrase; IP/r, inibidor de protease com reforço de ritonavir; ITRNN, inibidor de transcriptase reversa não-análogo de nucleosídeo; TDF, fumarato de tenofovir desoproxila; 3TC, lamivudina; AZT, zidovudina; ABC, abacavir; DTG, dolutegravir; DRV/r, darunavir + ritonavir; ATV/r, atazanavir + ritonavir; EFV, efavirenz;  
NVP, nevirapina.  
Fonte: Adaptado de EASL, 2020<sup>98</sup> .  
- : nenhuma interação significativa é esperada.  
- : necessidade de ajuste de dose, horário de administração ou monitoramento adicional (checar o texto).  
- : esses medicamentos não devem ser coadministrados.  
MATERIAL SUPLEMENTAR - INTERAÇÕES MEDICAMENTOSAS COM AGENTES HORMONAIS  
No que concerne às interações medicamentosas, os agentes hormonais e os diferentes esquemas de antivirais de ação direta (DAA) apresentam, de modo geral, um perfil favorável de coadministração. A maioria das combinações avaliadas não demonstra interações clinicamente significativas, o que sugere a manutenção da eficácia terapêutica e baixo risco de alterações farmacocinéticas relevantes. Todavia, o acetato de ciproterona requer cautela, pois observa-se interação potencial fraca com daclatasvir (DCV) e glecaprevir/pibrentasvir (GLE/PIB).  
54

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 1. Escopo e finalidade do Protocolo -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Hepatite C e coinfecções contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de HIV/AIDS, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis (Dathi/SVSA/MS), que incluiu médicos infectologistas, hepatologistas, especialistas em transplante hepático, pediatria e transplante hepático infantil, hepatite Delta, medicina da família e comunidade e imunização.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 2. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas -->
A proposta de atualização do PCDT da Hepatite C e coinfecções foi apresentada na 134ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em março de 2026. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE); Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). Os membros da Subcomissão apontaram que a testagem de adultos já inclui aqueles acima de 40 anos, sugerindo redação que reforce que eles são um grupo de atenção especial.

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 3. Consulta pública -->
A Consulta Pública nº 35/2026, do Protocolo Clínico e Diretrizes Terapêuticas da Hepatite C e Coinfecções, foi realizada entre os dias 14/05/2026 a 25/05/2026. Foram recebidas 12 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2026/contribuicoes-cp-35-2026-pcdt-para-hepatite-c-e-coinfeccoes

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: 4. Busca da evidência e recomendações -->
Para atualização das recomendações do PCDT da Hepatite C e coinfecções foram realizadas buscas sistematizadas por diretrizes clínicas, revisões sistemáticas ou ensaios clínicos randomizados sobre o tema conforme as especificidades das seções. A partir de uma análise prévia das evidências, estas foram comparadas com as recomendações do PCDT publicado por meio da Portaria SCTIE/MS nº 84/2018 e foram elencados os pontos de divergências, os critérios para início de tratamento mais recentes segundo a literatura internacional, as estratégias atuais de enfrentamento a essa doença e as condutas em relação ao monitoramento clínico e profilaxias.  
55  
Com isso, foi possível destacar os principais pontos para atualização do PCDT e elaborar a primeira proposta de escopo para motivar a discussão com o painel de especialistas. Os especialistas receberam a proposta inicial de escopo de atualização, elaborado pela CGHV/DATHI/SVSA/MS, que elencava os pontos chave para atualização do PCDT. Complementarmente, durante o processo, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas sobre recomendações específicas que apresentavam diferenças de parâmetros na literatura.  
As discussões que permearam as reuniões para atualização do PCDT contemplaram todas as etapas da linha de cuidado e suas especificidades, considerando a complexidade da infecção pelo HCV e particularidades das populações mais vulneráveis.  
Os principais pontos de atualização foram:  
a) Atualização da linha de cuidado da hepatite C, com retirada da recomendação do exame de genotipagem do HCV;  
b) Exclusão dos medicamentos não pangenotípicos para tratamento da hepatite C (elbasvir 50 mg/grazoprevir 100 mg e ledipasvir 90 mg/sofosbuvir 400 mg), conforme Portaria SCTIE/MS nº 93, de 29 de dezembro de 2025;  
c) Inclusão do escore APRI como critério para prescrição de tratamento inicial para hepatite C;  
d) Incorporação do medicamento sofosbuvir/velpatasvir/voxilaprevir para o retratamento da hepatite C em pacientes com ou sem cirrose compensada conforme Portaria SCTIE/MS nº 163, de 02 de dezembro de 2022;  
e) Incorporação do medicamento sofosbuvir/velpatasvir em grânulos para o tratamento da hepatite C em crianças de 3 a 11 anos, conforme Portaria SCTIE/MS nº 95, de 29 de dezembro de 2025;  
f) Atualização das recomendações terapêuticas, deixando de recomendar o tratamento da hepatite C à base de alfapeginterferona 2a e ribavirina;  
g) Atualização das recomendações sobre transplante de órgãos de doadores anti-HCV reagente, conforme a Portaria GM/MS nº 8.041, de 25 de setembro de 2025;  
h) Inclusão de recomendações quanto à interrupção de tratamento da hepatite C.  
5. Equipe de elaboração e partes interessadas  
Colaboração externa  
Os participantes do processo de atualização do referido PCDT estão descritos no **Quadro A** .  
Quadro A. Participantes do processo de atualização do PCDT.  
|**Participantes**|
|---|
|Adalgiza de Souza Paiva Ferreira|
|Alessandro Aldrin Pinheiro Chagas|
|Alice TungWan Song|
|Aline Almeida da Silva|
|Aline Alves da Silva|
|Aline Gonzalez Vigani<br>|
|Álisson Bigolin|
|Ana Catharina de Seixas Santos Nastri|
|Ana Cláudia Philippus|
|Ana Cristina Garcia Ferreira|  
56  
|**Participantes**<br>Ana Mônica de Mello|
|---|
|Ana Paula Maciel Gurski|
|Camila Francisca Tavares Chacarolli|
|Carina Bernardes Sousa|
|Carla Francisca dos Santos Cruz|
|Carlos Alberto de Albuquerque Almeida Júnior|
|Carlos Norberto Varaldo|
|Carolina Simone Souza Adania<br>|
|CirleyMaria de Oliveira Lobato|
|Draurio Barreira Cravo Neto|
|Edson Abdala<br>|
|Elton Carlos de Almeida|
|Fernanda Fernandes de Souza|
|Flavia Kelli Alvarenga Pinto|
|Francisco José Dutra Souto|
|Gilda Porta<br>|
|Giovanni Faria Silva|
|Heber Dobis Bernarde|
|Hugo Cheinquer|
|Isabelle Cristine de Jesus Macedo|
|João Marcello de Araújo Neto|
|João Vítor da Mota Silva|
|Jonathan David Amaral Fernandes|
|Jordana Soares Iankoski|
|José Anatans Dias Pinheiro|
|José Nilton Neris Gomes|
|Juan Miguel Villalobos Salcedo|
|Karen Cristine Tonini<br>|
|Kycia Maria Rodrigues do Ó|
|Leila Maria Moreira Beltrão Pereira|
|Leonardo Cançado Monteiro Savassi|
|Leonardo Carrara Matsuura|
|Leonardo Weissmann|
|Loraine Melissa Dal-Ri|
|Marcelo Simão Ferreira|
|Maria Cássia Jacintho Mendes Correa|
|Maria Fernanda Badue Pereira|
|Mario Peribañez Gonzalez|
|Mário Reis Alvares-da-Silva|
|Marta da Cunha Lobo Souto Maior|
|Michelle Flaviane Soares Pinto|
|Moyra Machado Portilho|
|Munik Pereira Santos Teixeira|
|Nathália da Silva Cruz|
|Paulo Roberto Abrão Ferreira|
|Raquel Silveira Bello Stucchi|
|Raymundo Paraná Ferreira Filho|
|Roberto José Carvalho Filho|
|Rosângela Teixeira|
|Salete Saionara dos Santos Barbosa|
|Sarah Yasmin Lucena Gomes<br>|
|Sheila Rodrigues Rodovalho|
|Silvana Aparecida Tasso|
|TaniaQueiroz Reuter|
|Thais Piazza de Melo|
|Themis Reverbel da Silveira|  
57  
|**Participantes**|
|---|
|Thor Oliveira Dantas|
|Tiemi Arakawa|
|Vencelau Jackson da Conceição Pantoja|
|Vinicius da Motta de Mello|
|Wendel Alencar de Oliveira|

---

<!-- METADADOS: doenca: Hepatite C e Coinfecções | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro B).  
**Quadro B** . Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|**Perguntas**|**Respostas**|**Caso tenha respondido sim, informar:**|
|---|---|---|
|**1.**<br>**Considerando o tema, responda: v**<br>**avós, netos ou irmãos):**|**ocê, seu cônju**|**ge ou familiar de até 2° grau (pais, filhos,**|
|a.<br>Possui diagnóstico da doença?*|(   ) Sim<br>(   ) Não|Quem possui o diagnóstico (se é você ou<br>qual seu vínculo com a pessoa<br>diagnosticada).|
|b.<br>Já fez, faz ou pretende usar alguma<br>tecnologia relacionada ao tema ou tem<br>expectativa de benefício direto com o tema?*|(   ) Sim<br>(   ) Não|Se faz uso atualmente ou quando fez o<br>uso; e quem fez ou faz uso da tecnologia<br>(se é você ou qual seu vínculo com a<br>pessoa que faz ou fez uso da tecnologia<br>em avaliação).|
|c.<br>Participa ou participou de associação<br>de pacientes ou sociedade médica relacionada<br>à condição clínica no tema?|(   ) Sim<br>(   ) Não|Nome da associação de pacientes ou<br>sociedade médica; quem participa ou<br>participou (se é você ou qual seu vínculo<br>com o membro da associação); e se<br>participa atualmente ou nos últimos 24<br>meses.|
|d.<br>Participa ou participou de associação<br>de pacientes ou sociedade médica relacionada<br>à condição clínica em análise as quais<br>recebem recursos da empresa detentora do<br>registro de tecnologia no tema?|(   ) Sim<br>(   ) Não|Nome da associação de pacientes ou<br>sociedade médica; quem participa ou<br>participou (se é você ou qual seu vínculo<br>com o membro da associação); e se<br>participa atualmente ou nos últimos 24<br>meses.|
|e.<br>Recebe ou recebeu doação de<br>empresa detentora do registro de tecnologia<br>relacionada no tema?|(   ) Sim<br>(   ) Não|Quem recebeu a doação (se foi você ou<br>qual seu vínculo com quem recebeu), o<br>nome da empresa e quando foi realizada a<br>doação.|
|f.<br>Participa ou participou de pesquisa<br>clínica<br>primária<br>relacionada<br>direta<br>ou<br>indiretamente ao tema?|(   ) Sim<br>(   ) Não|Quem participa ou participou da pesquisa<br>(se foi você ou qual seu vínculo com o<br>participante), se a pesquisa está em<br>andamento ou quando foi e quais são as<br>tecnologias e a condição clínica<br>analisadaspelapesquisa.|
|**2.**<br>**Considerando o tema, responda: v**<br>**avós, netos ou irmãos), atualmente ou nos úl**|**ocê, seu cônju**<br>**timos 24 mes**|**ge ou familiar de até 2° grau (pais, filhos,**<br>**es:**|
|a.<br>Participou de congressos, simpósios,<br>palestras, ou demais eventos, referentes ao<br>tema em avaliação, mas sem apoio financeiro<br>da<br>empresa<br>detentora<br>do<br>registro<br>de<br>tecnologia no tema|(   ) Sim<br>(   ) Não|Tipo de conflito e quem possui o conflito<br>(se é ou foi você ou qual seu vínculo com<br>a pessoa)|
|b.<br>Atua profissionalmente ou possui<br>participação acionária ou investimentos<br>financeiros diretos em empresaque fabrica,|(   ) Sim<br>(   ) Não|Tipo do conflito, o nome da empresa e<br>quem possui o conflito (se é ou foi você<br>ouqual seu vínculo com apessoa).|  
58  
|**Perguntas**|**Respostas**|**Caso tenha respondido sim, informar:**|
|---|---|---|
|comercializa ou concorre com produtos<br>relacionados à atividade fim da organização e<br>possui interesses diretos no tema?|||
|c.<br>Recebe<br>ou<br>recebeu<br>honorários<br>periódicos para prestação de consultoria ou<br>palestras de empresa detentora do registro de<br>tecnologiapara a condição de saúde?|(   ) Sim<br>(   ) Não|Tipo de conflito, o nome da empresa e<br>quem possui o conflito (se é ou foi você<br>ou qual seu vínculo com a pessoa).|
|d.<br>Recebe ou recebeu financiamento de<br>empresa com interesse comercial no tema<br>(empresa detentora do registro de tecnologia<br>para a condição de saúde)?|(   ) Sim<br>(   ) Não|Quem possui o conflito (se é ou foi você<br>ou qual seu vínculo com a pessoa) e o<br>nome da empresa ou origem do<br>financiamento.|
|e.<br>Possui ou possuiu cargo de gestão ou<br>representação em empresa detentora do<br>registro de tecnologia para a condição de<br>saúde?|(   ) Sim<br>(   ) Não|Quem possui o conflito (se é ou foi você<br>ou qual seu vínculo com a pessoa), o<br>cargo e o nome da empresa.|
|f.<br>Possui ou possuiu patente ou<br>royalties de tecnologia para a condição de<br>saúde?|(   ) Sim<br>(   ) Não|Quem possui o conflito (se é ou foi você<br>ou qual seu vínculo com a pessoa), a<br>tecnologia compatente ou royalties.|
|g.<br>Recebe<br>ou<br>recebeu<br>suporte<br>financeiro ou fomento à pesquisa ou<br>financiamento para redação de artigos ou<br>editoriais provenientes de empresa detentora<br>do registro de tecnologia relacionada ao tema?|(   ) Sim<br>(   ) Não|Quem possui o conflito (se é ou foi você<br>ou qual seu vínculo com a pessoa) e o<br>nome da empresa ou origem do<br>financiamento e atividade de destino do<br>financiamento.|
|h.<br>Recebe ou recebeu apoio financeiro<br>de viagens (para curso, viagem, entre outros<br>eventos)de empresa interessada no tema?|(   ) Sim<br>(   ) Não|Tipo de conflito e quem possui o conflito<br>(se é ou foi você ou qual seu vínculo com<br>apessoa)|
|**3.**<br>**Há algum outro fato ou situação**<br>**não elencada anteriormente que possa**<br>**interferir na imparcialidade das suas**<br>**atividades desenvolvidas no âmbito da**<br>**Conitec?**|(   ) Sim<br>(   ) Não|Descrever a situação.|  
* De acordo com a Lei nº 14.289/2022, que garante sigilo sobre condições de saúde específicas (HIV, hepatites crônicas - HBV e HCV -, hanseníase e tuberculose), não é necessário declarar ter a doença ao informar o conflito de interesse.  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador está na **Quadro C** .  
Quadro C. Declaração de conflitos de interesse dos membros do Grupo Elaborador do PCDT.  
||**Confli**|**tos de interesses declarados**|**Decisão**|
|---|---|---|---|
|**arcane**||||
||**Questão**|**Descrição geral**|**tomada**|
|Adalgiza de Souza Paiva Ferreira|-|-|Declarar e<br>participar|
|Alessandro Aldrin Pinheiro<br>Chagas|-|-|Declarar e<br>participar|
|Alice Tung Wan Song|-|-|Declarar e<br>participar|
|Aline Almeida da Silva|-|-|Declarar e<br>participar|
|Aline Alves da Silva|||Declarar e<br>participar|
|Aline Gonzalez Vigani|2a|Participou de congressos como<br>palestrante e participante mas não<br>recebeu apoio ou recursos<br>financeiros de empresas<br>detentoras dos registros de<br>tecnologia|Declarar e<br>participar|  
59  
|**Participante**|**Confl**<br>**Questão**|**itos de interesses declarados**<br>**Descrição geral**|**Decisão**<br>**tomada**|
|---|---|---|---|
|Álisson Bigolin|<br>-|<br>-|Declarar e<br>participar|
|Ana Catharina de Seixas Santos<br>|-|-|Declarar e<br>|
|Nastri|||participar|
|Ana Cláudia Philippus|-|-|Declarar e<br>participar|
|Ana Cristina Garcia Ferreira|-|-|Declarar e<br>participar|
|Ana Mônica de Mello|-|-|Declarar e<br>participar|
|Ana Paula Maciel Gurski|2a|Participou do_Global Hepatitis_<br>_Summit_em Los Angeles em<br>março de 2025, com apoio<br>financeiro somente do Ministério<br>da saúde e da OPAS/OMS.|Declarar e<br>participar|
|Camila Francisca Tavares|||Declarar e|
|Chacarolli|-|-|participar|
|Carina Bernardes Sousa|-|-|Declarar e<br>participar|
|Carla Francisca dos Santos Cruz|2a|Participou de eventos ministrando<br>palestras representando a CGHV,<br>mas não recebeu apoio financeiro<br>de empresa detentora do registro<br>de tecnologia no tema.|Declarar e<br>participar|
|Carlos Alberto de Albuquerque<br>|-|-|Declarar e<br>|
|Almeida Junior|||participar|
|Carlos Norberto Varaldo|1c|Participa do Grupo Otimismo de<br>Apoio aos Portadores de<br>Hepatites.|Declarar e<br>participar|
|Carolina Simone Souza Adania|2a|Participou dos congressos: 14º<br>Congresso Brasileiro de Saúde<br>Coletiva (2025) e XVIII<br>Congresso Latino-americano de<br>Medicina Social e Saúde Coletiva<br>– Alames (2025), apresentando<br>trabalhos sobre o tema hepatites<br>virais. Como ouvinte, do VI<br>Congresso Latino-Americano<br>IST/HIV/AIDS; XV Congresso<br>da Sociedade Brasileira de DST e<br>XI Congresso Brasileiro de AIDS<br>(2025).|Declarar e<br>participar|
|Cirley Maria de Oliveira Lobato|-|-|Declarar e<br>participar|
|Draurio Barreira Cravo Neto|-|-|Declarar e<br>participar|
|Edson Abdala|-|-|Declarar e<br>participar|
|Elton Carlos de Almeida|-|-|Declarar e<br>participar|
|Fernanda Fernandes Souza|-|-|Declarar e<br>participar|
|Flávia Kelli Alvarenga Pinto|-|-|Declarar e<br>participar|
|Francisco José Dutra Souto|1c<br>1d<br>2a|Participa da administração da<br>Sociedade Brasileira de<br>Hepatologia(SBH). A SBH|60<br><br>Declarar e<br>participar|  
|**Participante**|**Confl**<br>**Questão**|**itos de interesses declarados**<br>**Descrição geral**|**Decisão**<br>**tomada**|
|---|---|---|---|
|||<br>negocia espaço para expositores<br>em seus eventos, com o intuito de<br>realiza-los. Participou de eventos<br>relacionados ao tema sem ser<br>financiadopor indústria.||
|Gilda Porta|-|-|Declarar e<br>participar|
|Giovanni Faria Silva|1c|Participa da Sociedade Brasileira<br>de Hepatologia como membro<br>titular.|Declarar e<br>participar|
|Heber Dobis Bernarde|-|-|Declarar e<br>participar|
|Hugo Cheinquer|-|-|Declarar e<br>participar|
|Isabelle Cristine de Jesus Macedo|2a|Participou do Congresso<br>Brasiliense de Medicina de<br>Família e Comunidade e o<br>Congresso da Sociedade<br>Brasileira de Medicina Tropical,<br>sem apoio financeiro de empresa<br>detentora de registro.|Declarar e<br>participar|
|João Marcello de Araujo Neto|1c|Membro titular da Sociedade<br>Brasileira de Hepatologia.|Declarar e<br>participar|
|João Vitor da Mota Silva|-|-|Declarar e<br>participar|
|Jonathan David Amaral|-|-|Declarar e|
|Fernandes|||participar|
|Jordana Soares Iankoski|-|-|Declarar e<br>participar|
|José Anatans Dias Pinheiro|-|-|Declarar e<br>participar|
|José Nilton Neris Gomes|-|-|Declarar e<br>participar|
|Juan Miguel Villalobos Salcedo|1f|Participou da Pesquisa Clínica<br>com bemnifosbuvir com ruzasvir<br>em 2024 pelo Centro de Pesquisa<br>em Medicina Tropical de<br>Rondônia|Declarar e<br>participar|
|Karen Cristine Tonini|-|-|Declarar e<br>participar|
|Kycia Maria Rodrigues do Ó|1c|Diretora médica da AIGA –<br>Grupo de Apoio aos Pacientes<br>com Hepatites. Membro titular do<br>Grupo de Fígado do Rio de<br>Janeiro. Membro da Sociedade<br>Brasileira de Hepatologia.<br>Membro emérito do EASL<br>(Associação Europeia para<br>Estudos do Fígado)|Declarar e<br>participar|
|Leila Maria Moreira Beltrão||.|Declarar e|
|Pereira|-|-|participar|
|Leonardo Cançado Monteiro|||Declarar e|
|<br>Savassi|-|-|participar|
|Leonardo Carrara Matsuura|-|-|Declarar e<br>participar|
|Leonardo Weissmann|1c|Associado da Sociedade<br>Brasileira de Infectologia(SBI).|61<br><br>Declarar e<br>participar|  
|**Participante**|**Confl**<br>**Questão**|**itos de interesses declarados**<br>**Descrição geral**|**Decisão**<br>**tomada**|
|---|---|---|---|
|Loraine Melissa Dal-Ri|<br>-|<br>-|Declarar e<br>participar|
|Marcelo Simão Ferreira|-|-|Declarar e<br>participar|
|Maria Cassia Jacintho Mendes|-|-|Declarar e|
|Correa<br>||<br>|participar|
|Maria Fernanda Bádue Pereira|2a|Como infectologista pediatra,<br>participou do Congresso<br>Brasileiro de em 2025|Declarar e<br>participar|
|Mário Peribañez Gonzalez|2a|Participou de diversos eventos<br>como palestrante sobre o tema,<br>por ser área de concentração<br>acadêmica e expertise clínico.|Declarar e<br>participar|
|Mario Reis Alvares-da-Silva|1d<br>2a|Membro da Sociedade Brasileira<br>de Hepatologia. Participou do<br>EASL Congress 2026, AASLD<br>The Liver Meeting 2025,<br>Congresso da Sociedade<br>Brasileira de Hepatologia 2025,<br>EASL Congress 2025.|Declarar e<br>participar|
|Marta da Cunha Lobo Souto<br>Maior|-|-|Declarar e<br>participar|
|Michelle Flaviane Soares Pinto|-|-|Declarar e<br>participar|
|Moyra Machado Portilho|-|-|Declarar e<br>participar|
|Munik Pereira Santos Teixeira|-|-|Declarar e<br>participar|
|Nathália da Silva Cruz|-|-|Declarar e<br>participar|
|Paulo Roberto Abrão Ferreira|1c|Presidente da Sociedade Paulista<br>de Infectologia|Declarar e<br>participar|
|Raquel Silveira Bello Stucchi|-|-|Declarar e<br>participar|
|Raymundo Paraná Ferreira Filho|1f|Foi pesquisador em ensaios<br>clínicos de fase 2 e fase 3 em<br>Hepatite B e Hepatite C. ROCHE<br>/ BNS / JANSEN / GILLAD no<br>núcleo de ensaios clínicos do<br>Hospital Universitário da UFBA.|Declarar e<br>participar|
|Roberto José de Carvalho Filho|1c|Participante atual das seguintes<br>sociedades médicas: Federação<br>Brasileira de Gastroenterologia<br>(FBG); Sociedade Brasileira de<br>Hepatologia (SBH); Associação<br>Paulista para o Estudo do Fígado<br>(APEF).|Declarar e<br>participar|
|Rosângela Teixeira|-|-|Declarar e<br>participar|
|Salete Saionara dos Santos|||Declarar e|
|Barbosa|-|-|participar|
|Sarah Yasmin Lucena Gomes|-|-|Declarar e<br>participar|
|Sheila Rodrigues Rodovalho|-|-|Declarar e<br>participar|
|Silvana Aparecida Tasso|-|-|62<br>Declarar e<br>participar|  
|**Particiante**|**Confli**|**tos de interesses declarados**|**Decisão**|
|---|---|---|---|
|**p**|**Questão**|**Descrição geral**|**tomada**|
|Tania Queiroz Reuter|1c|Participa da Sociedade Brasileira<br>de Infectologia(SBI).|Declarar e<br>participar|
|Thais Piazza de Melo|-|-|Declarar e<br>participar|
|Themis Reverbel da Silveira|2a|Participação em congressos e<br>simpósios relacionados ao tema<br>hepatite C sem qualquer apoio<br>financeiro de empresas<br>interessadas no tema.|Declarar e<br>participar|
|Thor Oliveira Dantas|-|-|Declarar e<br>participar|
|Tiemi Arakawa|2a|Participou da 5ª Cúpula Mundial<br>de Hepatites Virais 2026 e de<br>workshop pré-conferência sobre<br>hepatites virais organizado OMS,<br>em Bangcoc – Tailândia, sendo o<br>afastamento com ônus para o<br>Ministério da Saúde publicado na<br>Portaria de Pessoal SE nº<br>441/2026. A atividade foi<br>custeada pelo Ministério da<br>Saúde, ou seja, sem apoio<br>financeiro de empresa detentora<br>de registro de tecnologia ou<br>interessada no tema.|Declarar e<br>participar|
|Vencelau Jackson da Conceição<br>Pantoja|-|-|Declarar e<br>participar|
|Vinicius da Motta de Mello|-|-|Declarar e<br>participar|
|Wendel Alencar de Oliveira|-|-|Declarar e<br>participar|  
Ressalta-se que o Comitê Técnico Assessor em Hepatites Virais (CTA-HV) foi originalmente instituído pela Portaria SVS/MS nº 94, de 10 de outubro de 2008, com caráter consultivo. Em 2024, sua estrutura e competências foram atualizadas pela Portaria GM/MS nº 3.098, de 18 de janeiro de 2024, que incorporou o CTA-HV ao conjunto de colegiados de assessoramento técnico à Política Nacional de Vigilância em Saúde. A Portaria SVSA/MS nº 65, de 28 de junho de 2024 designou seus integrantes e, na data de publicação de PCDT, há alterações na composição do CTA-HV, as quais aguardam as medidas de publicação.  
A proposta de PCDT da Hepatite C e coinfecções foi discutida com o CTA-HV, de modo que seus membros também declararam seu conflito de interesse com o tema.  
63  
APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO  
|**Número do Relatório**<br>**da diretriz clínica**||**Tecnologias avali**|**adaspela Conitec**|
|---|---|---|---|
|<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Exclusão, não incorporação ou**<br>**não alteração no SUS**|
||Ausência de necessidade de<br>exame de genotipagem do<br>|Sofosbuvir/velpatasvir<br>em<br>grânulos para o tratamento da<br>hepatite C em crianças de 3 a 11<br>anos<br>[Relatório<br>de<br>Recomendação nº 1058/2025;<br>Portaria SCTIE/MS nº 95 2025]|Elbasvir 50 mg/grazoprevir 100<br>mg<br>e<br>ledipasvir<br>90<br>mg/sofosbuvir<br>400<br>mg<br>[Relatório de Recomendação nº<br>1059/2025; Portaria SCTIE/MS<br>nº 93/2025]|
|Portaria SCTIE/MS nº<br>39/2026 [Relatório de<br>Recomendação<br>nº<br>1110/2026]|<br>HCV; inclusão do escore<br>APRI como critério para<br>prescrição de tratamento<br>inicial; não recomendação<br>de alfapeginterferona 2a e<br>ribavirina;<br>orientações<br>quanto à interrupção de<br>tratamento da hepatite C.|Sofosbuvir/velpatasvir/<br>voxilaprevir para o retratamento<br>da hepatite C em pacientes com<br>ou<br>sem<br>cirrose<br>compensada<br>[Relatório de Recomendação nº<br>782/2022; Portaria SCTIE/MS nº<br>163/2022]<br>Testagem universal para hepatite<br>C em gestantes no primeiro<br>trimestre de gravidez durante o<br>pré-natal<br>[Relatório<br>de<br>Recomendação<br>nº<br>545/2020;<br>Portaria SCTIE/MS nº 32/2020]|Ombitasvir 12,5 mg/ veruprevir<br>75<br>mg/<br>ritonavir<br>50<br>mg<br>comprimido e dasabuvir 250 mg<br>comprimido para o tratamento da<br>Hepatite<br>C<br>[Relatório<br>de<br>Recomendação<br>nº<br>429/2019;<br>Portaria SCTIE/MS nº 44/2019]<br>Simprevir para o tratamento da<br>hepatite<br>C<br>[Relatório<br>de<br>Recomendação<br>nº<br>428/2019;<br>Portaria SCTIE/MS nº 13/2019]|
|Portaria SCTIE/MS nº<br>84/2018 [Relatório de<br>Recomendação<br>nº<br>408/2018]|Critério<br>de<br>custo-<br>minimização dos antivirais|Sofosbuvir<br>em<br>associação<br>a<br>velpatasvir<br>para<br>hepatite<br>C<br>crônica<br>[Relatório<br>de<br>Recomendação<br>nº<br>398/2018;<br>Portaria SCTIE/MS nº 46/2018]<br>Glecaprevir<br>associado<br>à<br>pibrentasvir<br>para<br>hepatite<br>C<br>crônica<br>[Relatório<br>de<br>Recomendação<br>nº<br>374/2018;<br>Portaria SCTIE/MS nº 33/2018]<br>Elbasvir associado a grazoprevir<br>no tratamento de adultos com<br>hepatite C crônica infectados<br>pelos genótipos 1 e 4 [Relatório<br>de Recomendação nº 361/2018;<br>Portaria SCTIE/MS nº 11/2018]<br>Ledipasvir associado a sofosbuvir<br>para o tratamento de pacientes<br>adultos com hepatite C crônica<br>infectados por vírus de genótipo<br>[Relatório de Recomendação nº|-|  
64  
|**Número do Relatório**<br>**da diretriz clínica**||**Tecnologias avali**|**adas pela Conitec**|
|---|---|---|---|
|<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Exclusão, não incorporação ou**<br>**não alteração no SUS**|
|||363/2018; Portaria SCTIE/MS nº<br>12/2018]||
|Portaria SCTIE/MS nº<br>13/2018 [Relatório de<br>Recomendação<br>nº<br>360/2018]|Orientações<br>para<br>retratamento de pacientes|-|-|
|Portaria SCTIE/MS nº<br>33/2017 [Relatório de<br>Recomendação<br>nº<br>275/2017]|Revisão do tratamento com<br>os antivirais de ação direta|Veruprevir, ritonavir, ombitasvir<br>e dasabuvir para o tratamento de<br>hepatite C crônica causada por<br>infecção pelo genótipo 1 do HCV<br>[Relatório de Recomendação nº<br>233/2016; Portaria SCTIE/MS nº<br>40/2016]<br>Sofosbuvir,<br>daclatasvir<br>e<br>simeprevir para o tratamento da<br>hepatite viral C crônica [Relatório<br>de Recomendação nº 164/2015;<br>Portaria SCTIE/MS nº 29/2015]|Telaprevir,<br>boceprevir,<br>filgrastim e alfaepoetina para o<br>tratamento<br>da<br>hepatite<br>C<br>[Relatório de Recomendação nº<br>222/2016; Portaria SCTIE/MS nº<br>20/2016]<br>Veruprevir, ritonavir, ombitasvir<br>e dasabuvir para o tratamento de<br>hepatite C crônicacausada por<br>infecção pelo genótipo 1 do HCV<br>[Relatório de Recomendação nº<br>197/2015; Portaria SCTIE/MS nº<br>66/2015]|
|Portaria SCTIE/MS nº<br>37/2015 [Relatório de<br>Recomendação<br>nº<br>171/2015]|Inclusão de boceprevir e<br>telaprevir|-|-|
|Portaria<br>SVS/MS<br>nº<br>221/2011<br>e<br>Portaria<br>SVS/MS n º 25/2013|Inclusão das coinfecções e<br>publicação de suplemento<br>sobre fibrose avançada|Teste de amplificação de ácidos<br>nucléicos (NAT) para detecção<br>dos vírus da imunodeficiência<br>humana (HIV) e da hepatite<br>(HCV)<br>[Relatório<br>de<br>Recomendação<br>nº<br>26/2013;<br>Portaria SCTIE/MS nº 25/2013]<br>Inibidores de protease, telaprevir<br>e boceprevir, para tratamento da<br>hepatite crônica [Relatório de<br>Recomendação<br>nº<br>1/2012;<br>Portaria SCTIE/MS nº 20/2012]|-|
|Portaria<br>SVS/MS<br>nº<br>34/2007|Inclusão<br>de<br>informações<br>sobre a redução da dose de<br>ribavirina e de cuidado à<br>plaquetopenia|-|-|
|Portaria<br>SVS/MS<br>nº<br>24/2005|Inclusão da hepatite viral<br>aguda C|-|-|  
65  
|**Número do Relatório**<br>||**Tecnologias avali**|**adas pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais alterações**|**Incorporação ou alteração do**<br>**uso no SUS**|**Exclusão, não incorporação ou**<br>**não alteração no SUS**|
|Portaria<br>SAS/MS<br>nº<br>863/2002|Inclusão<br>do<br>alfa-peg-<br>interferona no tratamento|-|-|
|Portaria<br>GM/MS<br>nº<br>639/2000|Primeira versão da diretriz|-|-|  
66

---

