<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: Geral -->
**Ministério da Saúde Secretaria de Atenção à Saúde**  
PORTARIA Nº 957, DE 26 DE SETEMBRO DE 2014.  
Aprova as Diretrizes Diagnósticas e Terapêuticas do Câncer de Pulmão.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre o câncer de pulmão no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que as Diretrizes Diagnósticas e Terapêuticas (DDT) são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública n<sup>o</sup> 28/SAS/MS, de 25 de agosto de 2010;  
Considerando o Registro de Deliberação nº 76, de 05 de dezembro de 2013, da Comissão Nacional de Incorporação de Tecnologias no SUS – CONITEC;  
Considerando a Portaria SCTIE/MS n.º 7 de 22 de abril de 2014; e  
Considerando a avaliação da Assessoria Técnica da Secretaria de Atenção à Saúde - SAS, resolve:  
Art. 1º  Ficam aprovadas, na forma do Anexo desta Portaria, as Diretrizes Diagnósticas e Terapêuticas – Carcinoma de Pulmão.  
§ 1º  As Diretrizes, objeto deste Artigo, que contêm o conceito geral do carcinoma de pulmão, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
§ 2º  É obrigatória a cientificação ao paciente, ou ao seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizado para o tratamento do carcinoma de pulmão.  
§ 3º  Os gestores estaduais e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 2º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 3º  Fica revogada a Portaria nº 600/SAS/MS, de 26 de junho de 2012, publicada no Diário Oficial da União nº 124, de 28 de junho de 2012, seção 1, páginas 210-210.  
FAUSTO PEREIRA DOS SANTOS  
**Ministério da Saúde Secretaria de Atenção à Saúde**

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
DIRETRIZES DIAGNÓSTICAS E TERAPÊUTICAS EM ONCOLOGIA CARCINOMA DE PULMÃO

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Foi realizada em 16/01/2012 uma busca na base eletrônica Medline, acessada via PubMed, utilizando os descritores de interesse para câncer de pulmão no adulto: (systematic review [ti] OR meta-analysis [pt] OR meta-analysis [ti] OR systematic literature review [ti] OR (systematic review [tiab] AND review [pt]) OR consensus development conference [pt] OR practice guideline [pt] OR cochrane database syst rev [ta] OR acp journal club [ta] OR health technol assess [ta] OR evid rep technol assess summ [ta]) OR ((evidence based[ti] OR evidence-based medicine [mh] OR best practice* [ti] OR evidence synthesis [tiab]) AND (review [pt] OR diseases category[mh] OR behavior and behavior mechanisms [mh] OR therapeutics [mh] OR evaluation studies[pt] OR validation studies[pt] OR guideline [pt])) OR ((systematic [tw] OR systematically [tw] OR critical [tiab] OR (study selection [tw]) OR (predetermined [tw] OR inclusion [tw] AND criteri* [tw]) OR exclusion criteri* [tw] OR main outcome measures [tw] OR standard of care [tw] OR standards of care [tw]) AND (survey [tiab] OR surveys [tiab] OR overview* [tw] OR review [tiab] OR reviews [tiab] OR search* [tw] OR handsearch [tw] OR analysis [tiab] OR critique [tiab] OR appraisal [tw] OR (reduction [tw]AND (risk [mh] OR risk [tw]) AND (death OR recurrence))) AND (literature [tiab] OR articles [tiab] OR publications [tiab] OR publication [tiab] OR bibliography [tiab] OR bibliographies [tiab] OR published [tiab] OR unpublished [tw] OR citation [tw] OR citations [tw] OR database [tiab] OR internet [tiab] OR textbooks [tiab] OR references [tw] OR scales [tw] OR papers [tw] OR datasets [tw] OR trials [tiab] OR meta-analy* [tw] OR (clinical [tiab] AND studies [tiab]) OR treatment outcome [mh] OR treatment outcome [tw])) NOT (letter [pt] OR newspaper article [pt] OR comment [pt]).

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Entre 749 referências encontradas, as 480 mais recentes (últimos cinco anos) foram revisadas e identificaram-se 96 estudos clínicos e meta-análises elegíveis; e não foram incluídos 112 estudos de ciência básica ou pré-clínica, 106 revisões narrativas ou estudos opinativos, 110 artigos sobre doenças ou condições clínicas fora do escopo destas Diretrizes, 29 relatos de diretrizes internacionais de tratamento, 22 textos sobre produtos sem registro na ANVISA e 5 estudos farmacoeconômicos de outros países.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O câncer de pulmão é uma das principais causas de morte evitável em todo o mundo, pois, em 90% dos casos diagnosticados, está associado ao tabagismo. Altamente letal, a sobrevida média cumulativa total em cinco anos varia entre 13% e 21% em países desenvolvidos e entre 7% e 10% nos países em desenvolvimento. No Brasil, entre 2005-2009, foi o tipo de câncer que mais fez vítimas entre os homens e foi o segundo mais letal entre as mulheres[1-3].  
O fator de risco mais importante para ocorrência do câncer de pulmão é o tabagismo. Fumantes têm o risco decuplicado de desenvolver a doença, em relação aos não fumantes, risco que está relacionado à quantidade de cigarros consumida, duração do hábito e idade em que iniciou o tabagismo. A cessação do tabagismo a qualquer tempo resulta na diminuição do risco de desenvolver câncer de pulmão. O tabagismo passivo, exposição ambiental ao gás radônio e exposição ocupacional prévia à mineração de amianto constituem fatores de risco adicionais para a doença[3].  
Estas Diretrizes compreendem a conduta terapêutica geral para o câncer de pulmão, compreendendo os seguintes tipos histológicos: carcinoma de pequenas células, carcinoma epidermoide, adenocarcinoma, carcinoma de grandes células, carcinoma adenoescamoso e carcinoma indiferenciado, classificados para fins terapêuticos e prognósticos em dois grupos: o carcinoma de pequenas células (CPPC) e os carcinomas de células não pequenas (CPCNP). A história natural de neoplasias como o carcinoma pleomórfico ou sarcomatoide, carcinoma mucoepidermoide e carcinoma

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
adenocístico é pouco conhecida, e as modalidades terapêuticas aqui recomendadas são aplicáveis a estas doenças, a critério médico. Os tumores carcinoides constituem um grupo de doenças à parte, enquadrados para fins terapêuticos, entre os cânceres neuroendócrinos[3a].  
A seleção do tratamento deverá ser adequada ao estadiamento clínico da doença (classificação TNM), capacidade funcional (escala ECOG/Zubrod), condições clínicas e preferência do doente. A extensão da doença nos casos de câncer de pulmão de pequenas células é classificada para fins terapêuticos em doença localizada e doença extensa. Doença localizada é aquela confinada ao hemitórax de origem, mediastino e linfonodos supraclaviculares ispilaterais, passíveis de tratamento por um mesmo campo de irradiação. A presença de derrame pleural ipsilateral enseja prognóstico intermediário entre casos de doença localizada e doença extensa. Doença extensa é aquela disseminada além da fossa supraclavicular ipsilateral, incluindo-se os casos de metástases à distância[4,5].  
Os hospitais credenciados para atendimento em oncologia devem, por sua responsabilidade, dispor de protocolo clínico institucional complementar, adequado a estas Diretrizes, destinado a orientar a tomada de decisão por doentes e médicos, avaliar e garantir qualidade na assistência, orientar a destinação de recursos na assistência à saúde e fornecer elementos de boa prática médica [5a].  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID)  
C34 BRÔNQUIOS E PULMÕES:  
C34.0 Brônquio principal, carina, hilo do pulmão;  
C34.1 Lobo superior do pulmão, brônquio do lobo superior, língula;  
C34.2 Lobo médio do pulmão, brônquio do lobo médio;  
C34.3 Lobo inferior do pulmão, brônquio do lobo inferior;  
C34.8 Lesão sobreposta do pulmão;  
C34.9 Pulmão, bronquíolo, broncogênico – sem outra especificação.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
O diagnóstico presuntivo de câncer de pulmão é feito na investigação de sintomas respiratórios (tosse, dispneia, dor torácica, hemoptise) e constitucionais (fadiga e emagrecimento), ou por achado radiológico atípico em exame realizado com outro propósito. Mesmo para fumantes, não é recomendado o rastreamento radiológico (radiografia de tórax ou tomografia computadorizada de baixa dose) para indivíduos assintomáticos; apesar de resultados promissores verificados no National Lung Screening Trial (NLST), permanecem indefinidas questões como a reprodutibilidade do método de aquisição e leitura das imagens, frequência do exame e população sob risco apropriada para a intervenção no Brasil [6-8].  
O diagnóstico definitivo é firmado pelo exame histopatológico ou citológico de espécime tumoral obtido por broncoscopia, mediastinoscopia, biópsia pleural ou biópsia pleuropulmonar a céu aberto ou vídeo-assistida. Eventualmente, o diagnóstico será feito após estudo anatomopatológico de peça cirúrgica - segmento, lobo pulmonar ou pulmão. A citologia de escarro não é recomendada rotineiramente, porém pode ser útil no diagnóstico de tumores de localização central[9,10].  
Como já mencionado, usa-se agrupar em dois grupos os casos de câncer de pulmão, segundo o tipo histopatológico, para fins terapêuticos e prognósticos: câncer de pulmão de pequenas células (CPPC) e câncer de pulmão de células não pequenas (CPCNPC).  O primeiro grupo (15%) corresponde aos casos de carcinoma de pequenas células, doença de evolução clínica mais agressiva, enquanto o segundo grupo (85%) agrega os demais tipos histopatológicos. No entanto, a experiência clínica acumulada com medicamentos antineoplásicos introduzidos na última década para tratamento do CPCNP demonstra que a segurança e eficácia deles podem guardar relação com o subtipo histopatológico e características moleculares, sendo importante diferenciar, minimamente, os subtipos escamoso e não escamoso do CPCNP, bem como,

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
idealmente, identificar a presença de mutação do receptor para o fator de crescimento epitelial (EGFR) nos casos de adenocarcinoma [11,12].  
Uma vez obtida a confirmação da malinidade e do tipo histopatológico tumoral, procede-se ao estadiamento clínico por meio de tomografia computadorizada (TC) de tórax e abdome superior, com contraste. A cintilografia óssea com Tecnécio-99m é indicada para doentes com câncer de pulmão de pequenas células e, nos demais casos, quando há queixa de dor óssea. A cintilografia óssea apresenta boa sensibilidade para o diagnóstico de metástases, mas elevada taxa de resultados falso positivos por doenças degenerativas osteoarticulares ou trauma ósseo. Achados anormais à cintilografia devem ser confirmados por outros exames de imagem para se estabelecer o diagnóstico de metástase óssea. A investigação por TC ou ressonância magnética (RM) do cérebro não é indicada rotineiramente como parte do estadiamento clínico do CPCNP, devendo ser empregada para doentes com câncer de pulmão de pequenas células e, nos demais casos, quando houver suspeita clínica de metástase no sistema nervoso central[13].  
A indicação de PET-CT deve ser feita para o estadiamento clínico do câncer de pulmão de células não pequenas potencialmente ressecável. Esse exame apresenta maior sensibilidade para o diagnóstico de acometimento linfonodal mediastinal e hilar se comparado à TC, permitindo maior acurácia no diagnóstico da doença localizada (estágio I)[14,15]. No entanto, o desempenho do exame é inferior para doentes em áreas endêmicas para tuberculose, pelo que, se há linfonodos mediastinais aumentados à TC (16 mm ou maior), faz-se necessária a abordagem cirúrgica complementar, por mediastinoscopia cervical ou toracoscopia, para minimizar a indicação de toracotomias desnecessárias[5,16,17].  
5. OPÇÕES TERAPÊUTICAS  
5.1. CÂNCER DE PULMÃO DE PEQUENAS CÉLULAS  
5.1.1. CIRURGIA  
O tratamento cirúrgico não é recomendado para este tipo de neoplasia, pelo seu comportamento biológico de propensão precoce a originar metástases à distância. Quando este diagnóstico é firmado após uma ressecção cirúrgica pulmonar, o doente deve receber tratamento sistêmico complementar compatível com o estadiamento da doença. O papel da cirurgia não foi estudado prospectivamente nesta neoplasia, mas doentes operados com tumor localizado lograram melhor prognóstico, em séries históricas, quando comparados aos tratados por radioquimioterapia [18-20].

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A irradiação torácica aumenta a sobrevida de doentes com câncer de pulmão de pequenas células, sendo costumeiramente indicada. A irradiação craniana com finalidade profilática (25 Gy em 10 frações de 250 cGy) previne a recorrência da doença no sistema nervoso central, sendo indicada para doentes que obtiveram controle da doença torácica, e permite o controle temporário de sintomas de metástases no sistema nervoso central[21,22].  
5.1.3. QUIMIOTERAPIA  
A quimioterapia aumenta a sobrevida de doentes com câncer de pulmão de pequenas células (CPCP), sendo indicada em associação à radioterapia para doentes com doença localizada (quimioterapia prévia) e isoladamente para doentes com doença avançada ou metastática (quimioterapia paliativa). No entanto, mesmo com a assistência terapêutica integral poucos doentes são curados e a expectativa de sobrevida em 5 anos para doentes com doença limitada e extensa é de 10% e 5%, respectivamente[23]. Nos casos de CPCP inexiste benefício com quimioterapia de manutenção ou com intensificação de dose[24].  
O esquema terapêutico, quimioterápico, padrão envolve a associação de derivado da platina (cisplatina ou carboplatina) e o etoposido. Outros esquemas que produzem resultados similares e toxicidade variável incluem: ciclofosfamida, doxorrubicina e vincristina (CAV); ciclofosfamida, doxorrubicina e etoposido; ciclofosfamida, etoposido e vincristina; cisplatina e topotecano; cisplatina e

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
irinotecano; ifosfamida, cisplatina e etoposido; carboplatina e paclitaxel; carboplatina e gemcitabina[25-28].  
A neoplasia na maioria dos doentes responde inicialmente a quimioterapia, mas recidiva em geral no primeiro ano após o início do tratamento. A chance de resposta à quimioterapia de 2ª linha varia segundo a resposta obtida ao tratamento inicial: doentes responsivos com recidiva 60-90 dias após o término do tratamento inicial (doença sensível) têm maior possibilidade de resposta à quimioterapia de 2ª linha. Doentes responsivos com recidiva dentro de 60-90 dias do término do tratamento inicial (doença refratária) ou que não respondem ou progridem na vigência do tratamento inicial (doença quimiorresistente) apresentam menor chance de benefício à quimioterapia de 2ª linha. O esquema de quimioterapia de 1ª linha pode ser repetido nos casos de “doença sensível”, especialmente quando a recidiva ocorre tardiamente (acima de seis meses). Pacientes com “doença refratária” ou “quimiorresistente” raramente logram benefício de quimioterapia paliativa de 2ª linha; quando indicada, podem ser usados esquemas baseados nos antineoplásicos não utilizadas no tratamento de 1ª linha, em monoterapia ou em associação, sendo maior a experiência clínica acumulada com uso do topotecano ou do esquema CAV [29,30].  
5.1.4. OPÇÕES TERAPÊUTICAS  
Doença localizada:  
Quimioterapia sistêmica associada à irradiação torácica, com ou sem irradiação craniana nos casos de resposta clínica completa no pulmão.  
Quimioterapia sistêmica, com ou sem irradiação craniana nos casos de resposta clínica completa no pulmão.  
Ressecção cirúrgica, seguida por quimioterapia sistêmica ou quimioterapia associada à irradiação torácica, com ou sem irradiação craniana, para doentes no estágio I.  
Doença extensa:  
Quimioterapia sistêmica, com ou sem irradiação craniana nos com resposta clínica completa no pulmão.  
Radioterapia paliativa torácica ou para metástases cerebrais, epidurais ou ósseas.  
5.2. CÂNCER DE PULMÃO DE CÉLULAR NÃO PEQUENAS  
5.2.1. CIRURGIA  
A cirurgia é a modalidade terapêutica com maior potencial curativo para os casos de carcinoma pulmonar de células não pequenas (CPCNP), nos doentes com doença localizada ao diagnóstico realizada por toracotomia ou toracoscopia vídeoassistida[31,32]. No intra-operatório, o cirurgião optará, dependendo da extensão real do tumor e da necessidade de se preservar a função pulmonar, pela ressecção em cunha, segmentectomia, lobectomia ou mesmo pneumectomia com ressecção das cadeias linfáticas regionais[33]. Enquanto nos ensaios clínicos com doentes em estágio I o prognóstico após lobectomia ou uma ressecção menor parece ser similar, dados acumulados da prática clínica sugerem que os resultados oncológicos são inferiores com ressecções em cunha e segmentectomias[34,35]. Em casos selecionados de metástase cerebral isolada, sincrônica ou metacrônica, a ressecção cirúrgica completa da lesão enseja prognóstico mais favorável que o tratamento paliativo exclusivo[36].  
5.2.2. RADIOTERAPIA  
A radioterapia externa (teleterapia) tem indicação nos casos de CPCNP em qualquer estágio tumoral, com finalidade curativa ou paliativa e em uso associado ou combinado com a cirurgia ou a quimioterapia.  
A irradiação ablativa estereotática (83,2 Gy a 146 Gy) é uma modalidade de radioterapia que pode ser indicada para doentes no estádio I que não apresentem condições clínicas para tratamento cirúrgico [37-39].  
A irradiação torácica associada à quimioterapia sistêmica promove a cura de uma pequena parcela de doentes com doença localizada inoperável[40,41]. A irradiação craniana profilática não é indicada para casos de CPCNP[42].  
Sintomas de progressão locorregional ou de acometimento metastático ósseo ou do sistema nervoso podem ser paliados com a teleterapia; a braquiterapia  
endoluminal pode ser empregada na paliação de sintomas respiratórios, mas não parece conferir vantagem adicional à radioterapia externa [43].  
5.2.3. QUIMIOTERAPIA  
O esquema terapêutico padrão para a quimioterapia prévia ou adjuvante do CPCP é associação de cisplatina com o etoposido.  
A quimioterapia adjuvante confere maior sobrevida para doentes com doença localizada operados[44,45]. Alguns doentes com doença localmente avançada logram benefício com quimioterapia prévia à cirurgia, tratamento associado ou não à radioterapia[46-48]. Em doentes com doença avançada ou metastática ao diagnóstico, a quimioterapia paliativa resulta em modesto incremento na sobrevida mediana (2-3 meses), com possibilidade de controle temporário dos sintomas, mas sem expectativa de cura, [49-53].  
Muitos esquemas de quimioterapia sistêmica podem ser usados com finalidade paliativa, contendo medicamentos tais como cisplatina, carboplatina, etoposido, mitomicina C, vimblastina, vinorelbina, gemcitabina, docetaxel, paclitaxel, pemetrexede, erlotinibe, gefitinibe, bevacizumabe e cetuximabe, em monoterapia ou em associações, por até três linhas de tratamento[49].  A seleção do tratamento deve considerar as características fisiológicas e capacidade funcional individuais, tipo histológico, perfil de toxicidade clínica, preferências do doente e protocolos terapêuticos institucionais.  
Recomenda-se que a quimioterapia paliativa de 1ª linha seja indicada para doentes com capacidade funcional 0, 1 ou 2 na escala de Zubrod. Quando medicamente possível, o tratamento deve ser feito com esquema terapêutico contendo cisplatina ou carboplatina, associada com um segundo agente antineoplásico[54,55]. Em um único ensaio clínico, a adição de bevacizumabe à quimioterapia de 1ª linha com carboplatina e paclitaxel promoveu aumento de sobrevida (diferença de 2 meses no tempo mediano de sobrevida) para um subgrupo selecionado de doentes: capacidade funcional 0 ou 1, subtipo histológico não  
escamoso, sem metástase cerebral, sem hemoptise, e à custa de maior toxicidade[56]. Inexiste evidência de benefício semelhante para a associação de bevacizumabe a outros esquemas de quimioterapia de 1ª linha, e revisões sistemáticas dos estudos de fase III publicados são contraditórias quanto a haver alguma vantagem para tratamentos contendo bevacizumabe[57-59]. A adição de cetuximabe à quimioterapia de 1ª linha com cisplatina e vinorelbina promoveu aumento de sobrevida (diferença de 1,2 meses) para um subgrupo selecionado de doentes (capacidade funcional 0 ou 1, tumores com expressão do receptor para o fator de crescimento epitelial) e à custa de maior toxicidade[60,61]. Apesar de que tal benefício não foi observado com o cetuximabe em associação ao esquema carboplatina e paclitaxel[62], revisões sistemáticas de estudos controlados de fase II-III sugerem incremento de sobrevida com cetuximabe associado a esquemas contendo cisplatina - diferença de 6% na taxa de sobrevida em 1 ano [63,64]. Há necessidade de corroboração dos resultados de eficácia e segurança das pesquisas clínicas com bevacizumabe e cetuximabe no tratamento do câncer de pulmão, antes que seu uso possa ser adotado rotineiramente.  
A presença da mutação do gene que codifica o receptor para o fator de crescimento epitelial (EFGR) é um fator preditivo de resposta aos inibidores do sítio da tirosina-quinase associada ao EGFR, tais como o erlotinibe e o gefitinibe. Nesta condição, monoterapia com um destes medicamentos é uma opção terapêutica aceitável para quimioterapia paliativa inicial ou após falha a outro esquema terapêutico[65-68].  
Recomenda-se que a quimioterapia paliativa de 2ª linha ou 3ª linha seja realizada apenas para doentes com capacidade funcional 0 ou 1 na escala de Zubrod. Inexiste evidência científica de que o tratamento antineoplásico paliativo de 2ª ou 3ª linha seja seguro ou eficaz para doentes com capacidade funcional comprometida (nível igual ou maior que 2 na escala de Zubrod). O esquema quimioterápico deve ser selecionado segundo o esquema usado anteriormente e o perfil de segurança e eficácia então  
observados, indicando-se preferencialmente medicamentos antineoplásicos em monoterapia[49,69,70]. O início imediato da quimioterapia de 2ª linha após o término da quimioterapia inicial ou “tratamento de manutenção”, com erlotinibe ou pemetrexede[71,72], parece conferir vantagem sobre o mesmo tratamento quando iniciado após a progressão clínica da doença, mas há necessidade de corroboração dos resultados de eficácia iniciais e melhor definição do perfil de doentes que se beneficiariam, antes que esta conduta possa ser generalizada como rotina[73-75].  
5.2.4. OPÇÕES TERAPÊUTICAS POR ESTÁGIO CLÍNICO  
Estágio 0:  
Ressecção cirúrgica conservadora: segmentectomia ou ressecção em cunha.  
Estágio I:  
Ressecção cirúrgica conservadora: lobectomia, segmentectomia ou ressecção em  
cunha;  
Radioterapia torácica radical, para doentes com contraindicação médica para  
cirurgia.  
Estágio II:  
Ressecção cirúrgica: pneumectomia, lobectomia ou ressecção segmentar pulmonar;  
Radioterapia torácica radical, para doentes com contraindicação médica para cirurgia;  
Quimioterapia adjuvante, após a cirurgia;  
Radioterapia torácica associada ou não à quimioterapia, seguida ou não por ressecção cirúrgica (tumor do ápice pulmonar – tumor de Pancoast - ou invasão de parede torácica).  
Estágio IIIA:  
Ressecção cirúrgica (T3N1M0): pneumectomia, lobectomia ou ressecção  
segmentar pulmonar;  
Radioterapia torácica radical associada à quimioterapia, para doentes com  
invasão linfática N2 ou contraindicação médica para cirurgia;  
Radioterapia torácica radical, para doentes com contra-indicação médica para  
quimiorradioterapia;  
Quimioterapia adjuvante, após cirurgia;  
Radioterapia torácica associada ou não à quimioterapia, seguida ou não por  
ressecção cirúrgica (tumor de Pancoast ou invasão de parede torácica).  
Estágio IIIB, IV e doença recidivada:  
Radioterapia torácica associada ou não à quimioterapia;  
Quimioterapia paliativa;  
Ressecção cirúrgica de metástase cerebral isolada, seguida ou não por radioterapia craniana;  
Radioterapia externa, associada ou não à radioterapia intersticial, para lesões endobrônquicas sintomáticas;  
Radioterapia paliativa, com finalidade antiálgica ou hemostática.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A avaliação da resposta ao tratamento antineoplásico sistêmico deve ser feita  
pelos critérios RECIST, sempre que aplicáveis[76].

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
A quimioterapia deve ser suspensa, temporária ou definitivamente, na ocorrência de[55,77,78]:  
Toxicidade clínica graus 3 e 4, conforme os parâmetros propostos pelo National Cancer Institute (EUA), de uso internacional;  
Redução da capacidade funcional do doente para os níveis 2, 3 ou 4 da escala de  
Zubrod;  
Ausência de resposta após o 4º ciclo de quimioterapia;

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Após 6 ciclos de quimioterapia, nos doentes responsivos;  
A qualquer tempo, na evidência de progressão neoplásica;  
Falta de aderência ao tratamento;  
Manifestação voluntária do doente, após esclarecimento dos riscos envolvidos.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes tratados com intenção curativa devem ser reavaliados quanto a complicações relacionadas aos procedimentos médicos em um prazo de 3-4 meses após o término do tratamento. No seguimento, recomenda-se a realização de consulta médica e exames de imagem (radiografia de tórax ou TC de tórax) a cada 6 meses por 2 anos e, então, anualmente. Exames laboratoriais, marcadores tumorais, citologia de escarro, broncoscopia e PET-CT não devem ser indicados para fins de acompanhamento pós-tratamento[79].  
Doentes que são fumantes devem ser encorajados a abandonar hábito e ser encaminhados para tratamento antitabágico – comportamental e de apoio farmacoterápico.

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
Doentes com diagnóstico de câncer de pulmão devem ser atendidos em hospitais habilitados em oncologia com serviço de radioterapia e com porte tecnológico suficiente para diagnosticar, tratar e realizar o seu acompanhamento.  
Além da familiaridade que esses hospitais guardam com o estadiamento, o tratamento, o manejo das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos doentes, e muito facilita as ações

---

<!-- METADADOS: doenca: Câncer de Pulmão - DDT | secao: **Ministério da Saúde Secretaria de Atenção à Saúde** -->
de controle e avaliação. Ações de controle e avaliação incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos); a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos doentes.  
Exceto pela Talidomida para o tratamento de Mieloma Múltiplo e pelo Mesilato de Imatinibe para a quimioterapia do Tumor do Estroma Gastrointestinal (GIST), da Leucemia Mieloide Crônica e Leucemia Linfoblástica Aguda cromossoma Philadelphia positivo, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento.  Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do  
medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos radioterápicos (Grupo 03, Subgrupo 01) e cirúrgicos (Grupo 04 e os vários subgrupos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento ou nome do procedimento e por código da CID – Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no SIGTAP-Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente disponibilizada.  
São os seguintes os procedimentos da tabela do SUS para a quimioterapia do câncer de pulmão:  
QUIMIOTERAPIA PALIATIVA – ADULTO  
03.04.02.021-4 - Quimioterapia do carcinoma pulmonar de células não pequenas  
avançado  
03.04.02.022-2 - Quimioterapia do carcinoma pulmonar indiferenciado de células  
pequenas avançado  
QUIMIOTERAPIA PRÉVIA (NEOADJUVANTE) - ADULTO  
03.04.04.009-6 - Quimioterapia do carcinoma pulmonar de células não pequenas (prévia)  
03.04.04.010-0 - Quimioterapia do carcinoma pulmonar indiferenciado de células  
pequenas (prévia)  
QUIMIOTERAPIA ADJUVANTE (PROFILÁTICA) – ADULTO  
03.04.05.017-2 - Quimioterapia do carcinoma pulmonar de células não pequenas  
(adjuvante)  
03.04.05.018-0 - Quimioterapia de carcinoma pulmonar indiferenciado de células pequenas (adjuvante)  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
9. REFERÊNCIAS BIBLIOGRÁFICAS  
1 - BRASIL. Ministério da Saúde. Atlas de Mortalidade por Câncer. Instituto Nacional de Câncer 2012.  
2 - Jemal A, Bray F, Center MM, Ferlay J, Ward E, Forman D. Global cancer statistics. CA Cancer J Clin. 2011 Mar-Apr;61(2):69-90.  
3 - Ferlay J, Shin HR, Bray F, Forman D, Mathers C, Parkin DM. Estimates of worldwide burden of cancer in 2008: GLOBOCAN 2008. International journal of cancer. 2010 Dec 15;127(12):2893-917.  
3a-Novaes FT et al Câncer de pulmão: histologia, estádio, tratamento e sobrevida <u>http://www.scielo.br/scielo.php?script=sci_arttext&pid=S180637132008000800009</u> - nt. J. bras. pneumol. vol.34 no.8 São Paulo Aug. 2008. (Disponível em <u>http://www.scielo.br/scielo.php?script=sci_arttext&pid=S180637132008000800009)</u>  
4 - Rami-Porta R, Crowley JJ, Goldstraw P. The revised TNM staging system for lung cancer. Ann Thorac Cardiovasc Surg. 2009 Feb;15(1):4-9.  
5 - Kalemkerian GP. Staging and imaging of small cell lung cancer. Cancer Imaging. 2011;11:253-8.  
5a-BRASIL, Ministério da Saúde. Manual de Bases Técnicas da Oncologia – SIA/SUS - Sistema de Informações Ambulatoriais. 13 ed. Brasília: MS/SAS/DRAC/CGSI, 2011. 110p.  
6 - Aberle DR, Adams AM, Berg CD, Black WC, Clapp JD, Fagerstrom RM, et al. Reduced lung-cancer mortality with low-dose computed tomographic screening. N Engl J Med. 2011 Aug 4;365(5):395-409.  
7 - Bach PB. Inconsistencies in findings from the early lung cancer action project studies of lung cancer screening. Journal of the National Cancer Institute. 2011 Jul 6;103(13):1002-6.  
8 - Gopal M, Abdullah SE, Grady JJ, Goodwin JS. Screening for lung cancer with low-dose computed tomography: a systematic review and meta-analysis of the  
baseline findings of randomized controlled trials. J Thorac Oncol. 2010 Aug;5(8):12339.  
9 - Vansteenkiste J, Dooms C, De Leyn P. Early stage non-small-cell lung cancer: challenges in staging and adjuvant treatment: evidence-based staging. Ann Oncol. 2010 Oct;21 Suppl 7:vii189-95.  
10 - Darling GE, Dickie AJ, Malthaner RA, Kennedy EB, Tey R. Invasive mediastinal staging of non-small-cell lung cancer: a clinical practice guideline. Curr Oncol. 2011 Dec;18(6):e304-10.  
11 - Travis WD, Brambilla E, Noguchi M, Nicholson AG, Geisinger KR, Yatabe Y, et al. International association for the study of lung cancer/american thoracic society/european respiratory society international multidisciplinary classification of lung adenocarcinoma. J Thorac Oncol. 2011 Feb;6(2):244-85.  
12 - Paech DC, Weston AR, Pavlakis N, Gill A, Rajan N, Barraclough H, et al. A systematic review of the interobserver variability for histology in the differentiation between squamous and nonsquamous non-small cell lung cancer. J Thorac Oncol. 2011 Jan;6(1):55-63.  
13 - Silvestri GA, Gould MK, Margolis ML, Tanoue LT, McCrory D, Toloza E, et al. Noninvasive staging of non-small cell lung cancer: ACCP evidenced-based clinical practice guidelines (2nd edition). Chest. 2007 Sep;132(3 Suppl):178S-201S.  
14 - Lv YL, Yuan DM, Wang K, Miao XH, Qian Q, Wei SZ, et al. Diagnostic performance of integrated positron emission tomography/computed tomography for mediastinal lymph node staging in non-small cell lung cancer: a bivariate systematic review and meta-analysis. J Thorac Oncol. 2011 Aug;6(8):1350-8.  
15 - Wang J, Welch K, Wang L, Kong FM. Negative predictive value of positron emission tomography and computed tomography for stage T1-2N0 non-small-cell lung cancer: a meta-analysis. Clinical lung cancer. 2012 Mar;13(2):81-9.  
16 - Lee JW, Kim BS, Lee DS, Chung JK, Lee MC, Kim S, et al. 18F-FDG PET/CT in mediastinal lymph node staging of non-small-cell lung cancer in a tuberculosis-  
endemic country: consideration of lymph node calcification and distribution pattern to improve specificity. Eur J Nucl Med Mol Imaging. 2009 Nov;36(11):1794-802.  
17 - Al-Sarraf N, Aziz R, Doddakula K, Gately K, Wilson L, McGovern E, et al. Factors causing inaccurate staging of mediastinal nodal involvement in non-small cell lung cancer patients staged by positron emission tomography. Interact Cardiovasc Thorac Surg. 2007 Jun;6(3):350-3.  
18 - Koletsis EN, Prokakis C, Karanikolas M, Apostolakis E, Dougenis D. Current role of surgery in small cell lung carcinoma. Journal of cardiothoracic surgery. 2009;4:30.  
19 - Schreiber D, Rineer J, Weedon J, Vongtama D, Wortham A, Kim A, et al. Survival outcomes with the use of surgery in limited-stage small cell lung cancer: should its role be re-evaluated? Cancer. 2010 Mar 1;116(5):1350-7.  
20 - Lim E, Belcher E, Yap YK, Nicholson AG, Goldstraw P. The role of surgery in the treatment of limited disease small cell lung cancer: time to reevaluate. J Thorac Oncol. 2008 Nov;3(11):1267-71.  
21 - Le Pechoux C, Dunant A, Senan S, Wolfson A, Quoix E, Faivre-Finn C, et al. Standard-dose versus higher-dose prophylactic cranial irradiation (PCI) in patients with limited-stage small-cell lung cancer in complete remission after chemotherapy and thoracic radiotherapy (PCI 99-01, EORTC 22003-08004, RTOG 0212, and IFCT 99-01): a randomised clinical trial. The lancet oncology. 2009 May;10(5):467-74.  
22 - Herrmann MK, Bloch E, Overbeck T, Koerber W, Wolff HA, Hille A, et al. Mediastinal radiotherapy after multidrug chemotherapy and prophylactic cranial irradiation in patients with SCLC--treatment results after long-term follow-up and literature overview. Cancer Radiother. 2011 Apr;15(2):81-8.  
23 - Pelayo Alvarez M, Gallego Rubio O, Bonfill Cosp X, Agra Varela Y. Chemotherapy versus best supportive care for extensive small cell lung cancer. Cochrane database of systematic reviews (Online). 2009(4):CD001990.  
24 - Rossi A, Garassino MC, Cinquini M, Sburlati P, Di Maio M, Farina G, et al. Maintenance or consolidation therapy in small-cell lung cancer: a systematic review and meta-analysis. Lung cancer (Amsterdam, Netherlands). 2010 Nov;70(2):119-28.  
25 - Amarasena IU, Walters JA, Wood-Baker R, Fong K. Platinum versus nonplatinum chemotherapy regimens for small cell lung cancer. Cochrane database of systematic reviews (Online). 2008(4):CD006849.  
26 - Lee SM, James LE, Qian W, Spiro S, Eisen T, Gower NH, et al. Comparison of gemcitabine and carboplatin versus cisplatin and etoposide for patients with poorprognosis small cell lung cancer. Thorax. 2009 Jan;64(1):75-80.  
27 - de Jong WK, Groen HJ, Koolen MG, Biesma B, Willems LN, Kwa HB, et al. Phase III study of cyclophosphamide, doxorubicin, and etoposide compared with carboplatin and paclitaxel in patients with extensive disease small-cell lung cancer. Eur J Cancer. 2007 Nov;43(16):2345-50.  
28 - Lima JP, dos Santos LV, Sasse EC, Lima CS, Sasse AD. Camptothecins compared with etoposide in combination with platinum analog in extensive stage small cell lung cancer: systematic review with meta-analysis. J Thorac Oncol. 2011 Dec;5(12):1986-93.  
29 - Cheng S, Evans WK, Stys-Norman D, Shepherd FA. Chemotherapy for relapsed small cell lung cancer: a systematic review and practice guideline. J Thorac Oncol. 2007 Apr;2(4):348-54.  
30 - Riemsma R, Simons JP, Bashir Z, Gooch CL, Kleijnen J. Systematic Review of topotecan (Hycamtin) in relapsed small cell lung cancer. BMC cancer. 2010;10:436.  
31 - Yan TD, Black D, Bannon PG, McCaughan BC. Systematic review and metaanalysis of randomized and nonrandomized trials on safety and efficacy of videoassisted thoracic surgery lobectomy for early-stage non-small-cell lung cancer. J Clin Oncol. 2009 May 20;27(15):2553-62.  
32 - Whitson BA, Groth SS, Duval SJ, Swanson SJ, Maddaus MA. Surgery for early-stage non-small cell lung cancer: a systematic review of the video-assisted  
thoracoscopic surgery versus thoracotomy approaches to lobectomy. Ann Thorac Surg. 2008 Dec;86(6):2008-16; discussion 16-8.  
33 - Hughes MJ, Chowdhry MF, Woolley SM, Walker WS. In patients undergoing lung resection for non-small cell lung cancer, is lymph node dissection or sampling superior? Interact Cardiovasc Thorac Surg. 2011 Sep;13(3):311-5.  
34 - Whitson BA, Groth SS, Andrade RS, Maddaus MA, Habermann EB, D'Cunha J. Survival after lobectomy versus segmentectomy for stage I non-small cell lung cancer: a population-based analysis. Ann Thorac Surg. 2011 Dec;92(6):1943-50.  
35 - Fan J, Wang L, Jiang GN, Gao W. Sublobectomy versus lobectomy for stage I non-small-cell lung cancer, a meta-analysis of published studies. Ann Surg Oncol. 2012 Feb;19(2):661-8.  
36 - Modi A, Vohra HA, Weeden DF. Does surgery for primary non-small cell lung cancer and cerebral metastasis have any impact on survival? Interact Cardiovasc Thorac Surg. 2009 Apr;8(4):467-73.  
37 - Lagerwaard FJ, Verstegen NE, Haasbeek CJ, Slotman BJ, Paul MA, Smit EF, et al. Outcomes of stereotactic ablative radiotherapy in patients with potentially operable stage I non-small cell lung cancer. International journal of radiation oncology, biology, physics. 2012 May 1;83(1):348-53.  
38 - Zhang J, Yang F, Li B, Li H, Liu J, Huang W, et al. Which is the optimal biologically effective dose of stereotactic body radiotherapy for Stage I non-small-cell lung cancer? A meta-analysis. International journal of radiation oncology, biology, physics. 2011 Nov 15;81(4):e305-16.  
39 - Palma D, Lagerwaard F, Rodrigues G, Haasbeek C, Senan S. Curative treatment of Stage I non-small-cell lung cancer in patients with severe COPD: stereotactic radiotherapy outcomes and systematic review. Int J Radiat Oncol Biol Phys. 2012 Mar 1;82(3):1149-56.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
40 - O'Rourke N, Roque IFM, Farre Bernado N, Macbeth F. Concurrent chemoradiotherapy in non-small cell lung cancer. Cochrane database of systematic reviews (Online). 2010(6):CD002140.  
41 - Auperin A, Le Pechoux C, Rolland E, Curran WJ, Furuse K, Fournel P, et al. Meta-analysis of concomitant versus sequential radiochemotherapy in locally advanced non-small-cell lung cancer. J Clin Oncol. 2010 May 1;28(13):2181-90.  
42 - Gore EM, Bae K, Wong SJ, Sun A, Bonner JA, Schild SE, et al. Phase III comparison of prophylactic cranial irradiation versus observation in patients with locally advanced non-small-cell lung cancer: primary analysis of radiation therapy oncology group study RTOG 0214. J Clin Oncol. 2011 Jan 20;29(3):272-8.  
43 - Cardona AF, Reveiz L, Ospina EG, Ospina V, Yepes A. Palliative endobronchial brachytherapy for non-small cell lung cancer. Cochrane database of systematic reviews (Online). 2008(2):CD004284.  
44 - Stuschke M, Pottgen C. Chemotherapy: Effectiveness of adjuvant chemotherapy for resected NSCLC. Nature reviews. 2010 Nov;7(11):613-4.  
45 - Arriagada R, Auperin A, Burdett S, Higgins JP, Johnson DH, Le Chevalier T, et al. Adjuvant chemotherapy, with or without postoperative radiotherapy, in operable non-small-cell lung cancer: two meta-analyses of individual patient data. Lancet. 2010 Apr 10;375(9722):1267-77.  
46 - Burdett SS, Stewart LA, Rydzewska L. Chemotherapy and surgery versus surgery alone in non-small cell lung cancer. Cochrane database of systematic reviews (Online). 2007(3):CD006157.  
47 - Gilligan D, Nicolson M, Smith I, Groen H, Dalesio O, Goldstraw P, et al. Preoperative chemotherapy in patients with resectable non-small cell lung cancer: results of the MRC LU22/NVALT 2/EORTC 08012 multicentre randomised trial and update of systematic review. Lancet. 2007 Jun 9;369(9577):1929-37.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
48 - Bakir M, Fraser S, Routledge T, Scarci M. Is surgery indicated in patients with stage IIIa lung cancer and mediastinal nodal involvement? Interact Cardiovasc Thorac Surg. 2011 Sep;13(3):303-10.  
49 - Younes RN, Pereira JR, Fares AL, Gross JL. Chemotherapy beyond first-line in stage IV metastatic non-small cell lung cancer. Rev Assoc Med Bras. 2011 Dec;57(6):686-91.  
50 - Baggstrom MQ, Stinchcombe TE, Fried DB, Poole C, Hensing TA, Socinski MA. Third-generation chemotherapy agents in the treatment of advanced non-small cell lung cancer: a meta-analysis. J Thorac Oncol. 2007 Sep;2(9):845-53.  
51 - NSCLCCG. Chemotherapy and supportive care versus supportive care alone for advanced non-small cell lung cancer. Cochrane database of systematic reviews (Online). 2010(5):CD007309.  
52 - NCCLCCG. Chemotherapy in addition to supportive care improves survival in advanced non-small-cell lung cancer: a systematic review and meta-analysis of individual patient data from 16 randomized controlled trials. J Clin Oncol. 2008 Oct 1;26(28):4617-25.  
53 - Pat K, Dooms C, Vansteenkiste J. Systematic review of symptom control and quality of life in studies on chemotherapy for advanced non-small cell lung cancer: how CONSORTed are the data? Lung cancer (Amsterdam, Netherlands). 2008 Oct;62(1):126-38.  
54 - Delbaldo C, Michiels S, Rolland E, Syz N, Soria JC, Le Chevalier T, et al. Second or third additional chemotherapy drug for non-small cell lung cancer in patients with advanced disease. Cochrane database of systematic reviews (Online). 2007(4):CD004569.  
55 - Goffin J, Lacchetti C, Ellis PM, Ung YC, Evans WK. First-line systemic chemotherapy in the treatment of advanced non-small cell lung cancer: a systematic review. J Thorac Oncol. 2010 Feb;5(2):260-74.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
56 - Sandler A, Gray R, Perry MC, Brahmer J, Schiller JH, Dowlati A, et al. Paclitaxel-carboplatin alone or with bevacizumab for non-small-cell lung cancer. N Engl J Med. 2006 Dec 14;355(24):2542-50.  
57 - Reck M, von Pawel J, Zatloukal P, Ramlau R, Gorbounova V, Hirsh V, et al. Overall survival with cisplatin-gemcitabine and bevacizumab or placebo as first-line therapy for nonsquamous non-small-cell lung cancer: results from a randomised phase III trial (AVAiL). Ann Oncol. 2010 Sep;21(9):1804-9.  
58 - Botrel TE, Clark O, Clark L, Paladini L, Faleiros E, Pegoretti B. Efficacy of bevacizumab (Bev) plus chemotherapy (CT) compared to CT alone in previously untreated locally advanced or metastatic non-small cell lung cancer (NSCLC): systematic review and meta-analysis. Lung cancer (Amsterdam, Netherlands). 2011 Oct;74(1):89-97.  
59 - Lima AB, Macedo LT, Sasse AD. Addition of bevacizumab to chemotherapy in advanced non-small cell lung cancer: a systematic review and meta-analysis. PloS one. 2011;6(8):e22681.  
60 - Pirker R, Pereira JR, von Pawel J, Krzakowski M, Ramlau R, Park K, et al. EGFR expression as a predictor of survival for first-line chemotherapy plus cetuximab in patients with advanced non-small-cell lung cancer: analysis of data from the phase 3 FLEX study. The lancet oncology. 2012 Jan;13(1):33-42.  
61 - Pirker R, Pereira JR, Szczesna A, von Pawel J, Krzakowski M, Ramlau R, et al. Cetuximab plus chemotherapy in patients with advanced non-small-cell lung cancer (FLEX): an open-label randomised phase III trial. Lancet. 2009 May 2;373(9674):152531.  
62 - Lynch TJ, Patel T, Dreisbach L, McCleod M, Heim WJ, Hermann RC, et al. Cetuximab and first-line taxane/carboplatin chemotherapy in advanced non-small-cell lung cancer: results of the randomized multicenter phase III trial BMS099. J Clin Oncol. 2010 Feb 20;28(6):911-7.  
63 - Ibrahim EM, Abouelkhair KM, Al-Masri OA, Chaudry NC, Kazkaz GA. Cetuximab-based therapy is effective in chemotherapy-naive patients with advanced and metastatic non-small-cell lung cancer: a meta-analysis of randomized controlled trials. Lung. 2011 Jun;189(3):193-8.  
64 - Lin H, Jiang J, Liang X, Zhou X, Huang R. Chemotherapy with cetuximab or chemotherapy alone for untreated advanced non-small-cell lung cancer: a systematic review and meta-analysis. Lung cancer (Amsterdam, Netherlands). 2010 Oct;70(1):5762.  
65 - Gao G, Ren S, Li A, Xu J, Xu Q, Su C, et al. Epidermal growth factor receptortyrosine kinase inhibitor therapy is effective as first-line treatment of advanced nonsmall-cell lung cancer with mutated EGFR: A meta-analysis from six phase III randomized controlled trials. International journal of cancer. 2011 Dec 13.  
66 - Petrelli F, Borgonovo K, Cabiddu M, Barni S. Efficacy of EGFR tyrosine kinase inhibitors in patients with EGFR-mutated non-small-cell lung cancer: a metaanalysis of 13 randomized trials. Clinical lung cancer. 2011 Mar;13(2):107-14.  
67 - Wang F, Wang LD, Li B, Sheng ZX. Gefitinib Compared with Systemic Chemotherapy as First-line Treatment for Chemotherapy-naive Patients with Advanced Non-small Cell Lung Cancer: A Meta-analysis of Randomised Controlled Trials. Clinical oncology (Royal College of Radiologists (Great Britain)). 2011 Oct 22.  
68 - Ku GY, Haaland BA, de Lima Lopes G, Jr. Gefitinib vs. chemotherapy as firstline therapy in advanced non-small cell lung cancer: meta-analysis of phase III trials. Lung cancer (Amsterdam, Netherlands). 2011 Dec;74(3):469-73.  
69 - Qi WX, Shen Z, Yao Y. Meta-analysis of docetaxel-based doublet versus docetaxel alone as second-line treatment for advanced non-small-cell lung cancer. Cancer chemotherapy and pharmacology. 2011 Jan;69(1):99-106.  
70 - Di Maio M, Chiodini P, Georgoulias V, Hatzidaki D, Takeda K, Wachters FM, et al. Meta-analysis of single-agent chemotherapy compared with combination  
chemotherapy as second-line treatment of advanced non-small-cell lung cancer. J Clin Oncol. 2009 Apr 10;27(11):1836-43.  
71 - Petrelli F, Borgonovo K, Cabiddu M, Barni S. Erlotinib as maintenance therapy in patients with advanced non-small cell lung cancer: a pooled analysis of three randomized trials. Anti-cancer drugs. 2011 Nov;22(10):1010-9.  
72 - Greenhalgh J, McLeod C, Bagust A, Boland A, Fleeman N, Dundar Y, et al. Pemetrexed for the maintenance treatment of locally advanced or metastatic nonsmall cell lung cancer. Health technology assessment (Winchester, England). 2011 Oct;14(Suppl. 2):33-9.  
73 - Zhang X, Zang J, Xu J, Bai C, Qin Y, Liu K, et al. Maintenance therapy with continuous or switch strategy in advanced non-small cell lung cancer: a systematic review and meta-analysis. Chest. 2011 Jul;140(1):117-26.  
74 - Coudert B, Ciuleanu T, Park K, Wu YL, Giaccone G, Brugger W, et al. Survival benefit with erlotinib maintenance therapy in patients with advanced non-small-cell lung cancer (NSCLC) according to response to first-line chemotherapy. Ann Oncol. 2012 Feb;23(2):388-94.  
75 - Velez M, Belalcazar A, Domingo G, Blaya M, Raez LE, Santos ES. Accelerated second-line or maintenance chemotherapy versus treatment at disease progression in NSCLC. Expert Rev Anticancer Ther. 2010 Apr;10(4):549-57.  
76 - Eisenhauer EA, Therasse P, Bogaerts J, Schwartz LH, Sargent D, Ford R, et al. New response evaluation criteria in solid tumours: revised RECIST guideline (version 1.1). Eur J Cancer. 2009 Jan;45(2):228-47.  
77 - Trotti A, Colevas AD, Setser A, Rusch V, Jaques D, Budach V, et al. CTCAE v3.0: development of a comprehensive grading system for the adverse effects of cancer treatment. Semin Radiat Oncol. 2003 Jul;13(3):176-81.  
78 - BRASIL, Ministério da Saúde. Cuidados paliativos oncológicos: controle de sintomas. Rio de Janeiro: INCA, 2001. 130p.  
**Ministério da Saúde Secretaria de Atenção à Saúde**  
79 - Rubins J, Unger M, Colice GL. Follow-up and surveillance of the lung cancer patient following curative intent therapy: ACCP evidence-based clinical practice guideline (2nd edition). Chest. 2007 Sep;132(3 Suppl):355S-67S.

---

