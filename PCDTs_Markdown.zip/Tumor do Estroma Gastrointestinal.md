<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: Geral -->
<!-- Start of picture text -->
x<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 494, DE 18 DE JUNHO DE 2014  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Tumor do Estroma Gastrointestinal.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o tumor do estroma gastrointestinal no Brasil e de se estabelecerem diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) são resultado de consenso técnico-científico e formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando as sugestões dadas à Consulta Pública n<sup>o</sup> 05/SAS/MS, de 20 de fevereiro de  
2014; e  
Considerando a avaliação técnica da Comissão Nacional de Incorporação de Tecnologias do SUS - CONITEC e da Assessoria Técnica da Secretaria de Atenção à Saúde, do Ministério da Saúde - SAS/MS, resolve:  
Art. 1º  Fica aprovado, na forma do Anexo desta Portaria, o Protocolo Clínico e Diretrizes Terapêuticas – Tumor do Estroma Gastrointestinal.  
Parágrafo único. O Protocolo, objeto desta Portaria, que contém o conceito geral de tumor do estroma gastrointestinal, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do tumor do estroma gastrointestinal.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: FAUSTO PEREIRA DOS SANTOS -->
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS  
TUMOR DO ESTROMA GASTROINTESTINAL (GIST)

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 1 METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA -->
Foram realizadas buscas nas bases de dados Medline/Pubmed e Embase em 02/04/2013.  
Na base de dados Medline/Pubmed, utilizando-se os termos “ _Gastrointestinal Stromal Tumors”_ [ _Mesh_ ], com os limites _Humans, Meta-Analysis, Randomized Controlled Trial, Clinical Trial, Phase III, Systematic Reviews,_ foram encontrados 110 artigos.  
Na base de dados Embase, utilizando-se os termos _‘gastrointestinal stromal tumors’_ / _exp AND_ ‘ _therapy_ ’/ _exp AND_ [ _meta analysis_ ]/ _lim OR_ [ _randomized controlled trial_ ]/ _lim OR_ [ _systematic review_ ]/ _lim_ ) _AND_ ([ _english_ ]/ _lim OR_ [ _portuguese_ ]/ _lim OR_ [ _spanish_ ]/ _lim_ ) _AND_ [ _humans_ ]/ _lim AND_ [ _embase_ ]/ _lim_ , foram encontrados 159 artigos.  
Primeiramente, foram selecionadas meta-análises e revisões sistemáticas relativas a opções de tratamento do tumor do estroma gastrointestinal, excluindo-se artigos não relacionados ao assunto e estudos cujos desfechos não tivessem relevância clínica; em seguida, estudos de fase III publicados após as meta-análises e revisões sistemáticas selecionadas.  
Foi utilizada ainda a base de dados _UpToDate_ 2013, com o termo GIST, e diretrizes clínicas de sociedades internacionais de especialistas.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 2 INTRODUÇÃO -->
Os tumores do estroma gastrointestinal ( _gastrointestinal stromal tumors_ – GIST) são neoplasias raras, tipicamente subepiteliais. Compreendem vários subtipos molecularmente distintos de sarcomas que coletivamente representam os tumores mesenquimais mais comuns do trato gastrointestinal. Afetam, em 75% dos casos, o estômago e intestino delgado proximal, mas podem ocorrer em qualquer segmento do trato digestivo, como cólon, reto e apêndice. Os GIST extragastrointestinais são raros e podem se originar no omento, mesentério ou retroperitônio (1).  
Os GIST manifestam-se em ambos os sexos e em qualquer faixa etária; entretanto mais comumente afetam pessoas com mais de 40-50 anos, com idade ao diagnóstico variando de 58 a 63 anos. Esses tumores correspondem a aproximadamente 1% das neoplasias primárias do trato digestivo. Estima-se que a incidência anual seja de 7-20 casos por milhão de pessoas (1,2). Em mais jovens, estima-se que a incidência seja de 0,06 a cada 100.000 pessoas entre 20-29 anos e de 0,02 por milhão de crianças com menos de 14 anos (3).  
A maioria dos casos parece ser esporádica, já que fatores de risco epidemiológicos não foram identificados até o momento. Há, porém, uma predisposição à ocorrência de GIST em crianças e adultos jovens com certas síndromes hereditárias, tais como GIST familiar (múltiplos GIST no estômago e no intestino delgado), neurofibromatose tipo 1, tríade de Carney (GIST gástrico, paraganglioma extraadrenal e condroma pulmonar) e síndrome de Carney-Stratakis (GIST gástrico e paraganglioma) (2,3).  
A etiologia do GIST parece estar relacionada às células intersticiais de Cajal (CIC) do plexo mioentérico envolvidas na peristalse. As CIC e as células do GIST apresentam similaridades ultraestruturais, como a expressão em comum do receptor transmembrana da tirosinoquinase KIT (receptor KIT) (4).  
Normalmente esse receptor desempenha papel fundamental no desenvolvimento e na manutenção das CIC, sendo um produto do proto-oncogene c-KIT. Um experimento-chave para a  
compreensão molecular da patogênese da doença foi realizado em 1998 e confirmou a teoria vigente de que, no GIST, certas mutações no c-KIT induzem uma ativação não controlada do receptor KIT, com consequente proliferação e aumento da sobrevida celular (isto é, crescimento neoplásico) (4).  
A identificação por imuno-histoquímica do antígeno CD117, que constitui parte do receptor KIT e, portanto, funciona como um marcador de sua presença, representou um passo essencial no diagnóstico diferencial do GIST em relação aos outros sarcomas do trato gastrointestinal.  
Embora 90% ou mais dos GIST apresentem positividade para a expressão do receptor KIT (isto é, são CD117 positivos), alguns subtipos podem sofrer mutações em outros genes. Mutações no gene de outra tirosinoquinase, como o receptor alfa do fator de crescimento derivado das plaquetas ( _plateletderived growth fator receptor alpha-PDGFRA),_ são encontradas em menos de 5% dos GIST CD117 negativos.  
Em geral, 5% dos GIST não apresentam quinases com mutações detectáveis, sendo chamados GIST de tipo selvagem ( _wild type_ ). Nessa situação, até um terço dos GIST c-KIT, PDGFRA e com GIST tipo selvagem podem apresentar mutações em outras vias moleculares não relacionadas com as tirosinoquinases (5).  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 3 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10) -->
- C15.0 Neoplasia maligna da porção cervical do esôfago (esôfago cervical)  
- C15.1 Neoplasia maligna da porção torácica do esôfago (esôfago torácico)  
- C15.2 Neoplasia maligna da porção abdominal do esôfago (esôfago abdominal)  
- C15.3 Neoplasia maligna do terço superior do esôfago  
- C15.4 Neoplasia maligna do terço médio do esôfago  
- C15.5 Neoplasia maligna do terço inferior do esôfago  
- C15.8 Neoplasia maligna do esôfago com lesão invasiva  
- C15.9 Neoplasia maligna do esôfago, não especificada  
- C16.0 Neoplasia maligna da cárdia  
- C16.1 Neoplasia maligna do fundo do estômago  
- C16.2 Neoplasia maligna do corpo do estômago  
- C16.3 Neoplasia maligna do antro pilórico  
- C16.4 Neoplasia maligna do piloro  
- C16.5 Neoplasia maligna da pequena curvatura do estômago, não especificada  
- C16.6 Neoplasia maligna da grande curvatura do estômago, não especificada  
- C16.8 Neoplasia maligna do estômago com lesão invasiva  
- C16.9 Neoplasia maligna do estômago, não especificada  
- C17.0 Neoplasia maligna do duodeno  
- C17.1 Neoplasia maligna do jejuno  
- C17.2 Neoplasia maligna do íleo  
- C17.3 Neoplasia maligna do divertículo de Meckel  
- C17.8 Neoplasia maligna do intestino delgado com lesão invasiva  
- C17.9 Neoplasia maligna do intestino delgado, não especificada  
- C18.0 Neoplasia maligna do ceco  
- C18.1 Neoplasia maligna do apêndice (vermiforme)  
- C18.2 Neoplasia maligna do cólon ascendente  
- C18.3 Neoplasia maligna da flexura (ângulo) hepática(o)  
- C18.4 Neoplasia maligna do cólon transverso  
- C18.5 Neoplasia maligna da flexura (ângulo) esplênica(o)  
- C18.6 Neoplasia maligna do cólon descendente  
- C18.7 Neoplasia maligna do cólon sigmoide  
- C18.8 Neoplasia maligna do cólon com lesão invasiva  
- C18.9 Neoplasia maligna do cólon, não especificada  
- C19 Neoplasia maligna da junção retossigmoide  
- C20 Neoplasia maligna do reto  
- C26.8 Lesão invasiva do aparelho digestivo  
- C47.4 Neoplasia maligna dos nervos periféricos do abdômen  
- C48.1 Neoplasia maligna de partes especificadas do peritônio  
- C49.3 Neoplasia maligna do tecido conjuntivo e tecidos moles do tórax

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 4.1 DIAGNÓSTICOS CLÍNICO E LABORATORIAL -->
Os GIST (aproximadamente 70%) se apresentam com sintomas inespecíficos, que podem incluir sangramento, perfuração e, menos frequentemente, obstrução. Cerca de 20% dos casos são assintomáticos, sendo encontrados fortuitamente durante endoscopias, exames de imagem do abdômen ou procedimentos cirúrgicos, como gastrectomia.  
Em estágios avançados, os tumores mais agressivos costumam metastatizar para o fígado e o peritônio. Metástases para linfonodos são raras em adultos, mas 4reqüentes em pacientes pediátricos. Outros sítios de metástases incluem ossos, pulmões, partes moles ou pele (2,6). No estadiamento inicial, está indicada tomografia computadorizada (TC) de tórax e abdômen. Em razão de as metástases pulmonares serem raras, cerca de 2%, e inexistindo evidência de doença pulmonar, uma nova TC de tórax está indicada se houver progressão de doença abdominal.  
Em casos iniciais de doença localizada e ressecável, um alto grau de suspeita e a familiaridade com a aparência radiológica do tumor bastam para o diagnóstico pré-operatório. Nessa situação, podese dispensar a biópsia antes do tratamento cirúrgico. No entanto, uma biópsia será necessária para confirmação de GIST se houver suspeita de metástase ou se a quimioterapia com mesilato de imatinibe estiver indicada para tumor localmente avançado (1,6,7).  
Morfologicamente, os GIST podem ser divididos em três categorias: fusiforme (70%) epitelioide (20%) e misto (10%). De modo geral, alguns estudos mostram que o subtipo histológico não tem impacto no prognóstico, mas sim nas particularidades de localização da neoplasia. Por exemplo, as lesões epitelioides ocorrem mais comumente no estômago do que nos outros sítios. Quanto às demais, não há localização predominante.  
A avaliação imuno-histoquímica complementar é recomendada para todos os casos suspeitos de GIST. Um painel imuno-histoquímico apropriado geralmente é suficiente para estabelecer o diagnóstico definitivo. A expressão de KIT (CD117), presente em 95% dos casos, é a mais específica e sensível característica do GIST, considerando um painel de diagnóstico diferencial padronizado. Outros marcadores, com suas respectivas positividades, utilizados comumente nos painéis incluem: CD34 (60%-70%), ACAT2 (30%-40%), S100 (5%), desmina (1%-2%) e queratina (1%-2%). A genotipagem dos GIST KIT-positivos não é recomendada de rotina (1,2,8). O DOG1 ( _discovered on GIST1_ ) representa um novo e promissor marcador, pois é expresso em cerca de um terço dos GIST KIT-negativos. A proteína transmembrana DOG1, identificada recentemente, tem se mostrado tanto sensível quanto específica para GIST e independe das expressões de c-KIT ou PDGFR. O verdadeiro papel desse novo marcador ainda permanece desconhecido. De modo geral, é recomendado utilizar o CD117 para confirmação diagnóstica de GIST (9).  
O comportamento clínico dos GIST é bastante variável, e diversas classificações na literatura tentam estratificar os subtipos com pior prognóstico. Conforme consenso estabelecido em 2002, tamanho do tumor, atividade mitótica e localização anatômica são as principais informações na estratificação do risco de recidiva e de desenvolvimento de metástases (Tabela 1). Os estudos mostram que GIST gástricos com menos de 2 cm com atividade mitótica baixa (menos de 5 mitoses/50 campos de grande aumento) têm risco muito baixo de recidiva. Por outro lado, em conjunto, os GIST com mais de 2 cm apresentam algum risco de recidivar. Segundo a atividade mitótica tumoral, essa estratificação divide os tumores em com menos de 5 ou com mais de 5 mitoses/50 campos de grande aumento.  
Quanto menor o número de mitoses, menor o risco. O risco final deve ser avaliado em conjunto com o tamanho do tumor em todos os casos de GIST após ressecção cirúrgica ou biópsia (nos casos de tumores não ressecáveis ou metastáticos) (1,2,10-13).  
TABELA 1 – Proposta para definir o risco da agressividade do comportamento dos GIST  
|Risco|Tamanho<br>do tumor<br>em cm<br>(*)|Taxa<br>mitótica/campos<br>de grande<br>aumento(**)|
|---|---|---|
|Muito baixo<br>risco|Menor<br>de 2|Menos de 5/50|
|Baixo risco|2-5|Menos de 5/50|
|Risco<br>intermediário|Menor<br>de 5<br>5-10|6-10/50<br>Menos de 5/50|
|Alto risco|Maior de<br>5<br>Maior de<br>10<br>Qualquer<br>tamanho|Mais de 5/50<br>Qualquer<br>taxa<br>mitótica<br>Mais de 10/50|  
(*) O tamanho representa a dimensão isolada maior. Admite-se que varie antes e depois da fixação e entre observadores. Existe consenso de que talvez o limiar para o comportamento agressivo deva ser menos de 1-2 cm para o intestino delgado do que para outros locais.  
(**) Idealmente, a contagem de mitoses deve ser padronizada de acordo com a superfície examinada (baseada no tamanho dos campos de grande aumento (HPF)), mas não existem acordos definidos sobre isto. Apesar da subjetividade no reconhecimento das mitoses e da variabilidade das áreas de HPF, essas contagens são úteis (12).  
Além dos fatores mencionados para predizer o prognóstico, a localização anatômica também afeta o risco de recidiva da doença. Em geral, GIST intestinais são muito mais agressivos do que os localizados na região gástrica. Algumas séries de casos mostram que a mortalidade por GIST de intestino delgado foi maior que o dobro da registrada na série com tumores gástricos (13). A Tabela 2 apresenta dados de estudos a longo prazo de 1.055 casos de cânceres gástricos, 629 de intestino delgado, 144 de duodeno e 111 de reto. Esses estudos tiveram seguimentos variáveis de 2,5 até 40 anos com tempo médio de 17 anos.  
TABELA 2 – Taxas de sobrevida livre de progressão dos casos de GIST em estômago, intestino delgado e reto agrupados pelas taxas de mitoses e pelo tamanho do tumor. (*)  
||Taxa<br>mitose/c|Per<br>paci<br>prog|centa<br>entes<br>ressão|gem<br>livres<br>dura|de<br>de<br>nte|
|---|---|---|---|---|---|
|Tamanho|ampos||lon|go||
|do tumor|de|acom|panh|amen|to –|
|em cm|grande|sí|tiopri|mário||
||aument|Estô|Jeju|Du|Ret|
||o|mag|no-|ode|o|
|||o|íleo|no||  
|Menor ou<br>igual a 2|Menor<br>ou igual<br>a 5/50|100|100|100|100|
|---|---|---|---|---|---|
|2-5|Menor<br>ou igual<br>a 5/50|98,1|95,7|91,<br>7|91,<br>7|
|5-10|Menor<br>ou igual<br>a 5/50|96,4|76|66<br>(*)|43<br>(*)|
|Maior que<br>10|Menor<br>ou igual<br>a 5/50|88|48|||
|Menor ou<br>igual a 2|Maior<br>que<br>5/50|100<br>(**)|50<br>(**)||46|
|2-5|Maior<br>que<br>5/50|84|27|50|48|
|5-10|Maior<br>que<br>5/50|45|15|14<br>(*)|29<br>(*)|
|10|Maior<br>que<br>5/50|14|10|||  
(*) Dados combinados para tumores com mais de 5 cm.  
(**) Pequeno número de casos. (13)

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 4.2 DIAGNÓSTICO POR IMAGEM -->
A TC de abdômen ou de pelve é o exame de escolha inicial para a avaliação do tumor primário e estadiamento da doença (14).  
Endoscopia digestiva alta geralmente é realizada e pode ser um meio útil para caracterizar melhor as lesões gástricas, demonstrando eventualmente ulcerações associadas. Durante o procedimento, podem ser realizadas biópsias das áreas suspeitas ou ulceradas. Como o GIST é um tumor submucoso e de crescimento mais endofítico, a aspiração endoscópica guiada por agulha fina permite a biópsia de material mais adequado para o diagnóstico do tumor primário, assim como a diferenciação de lesões semelhantes, como o leiomioma (15).  
Cabe ressaltar que as lesões dos GIST são frágeis, e procedimentos com biópsia podem causar hemorragia e mesmo disseminação tumoral (6). Por isso, são necessários cirurgiões ou endoscopistas experientes para a realização do procedimento a fim de que não ocorra disseminação para outros sítios ou ruptura da pseudocápsula do tumor.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 4.3 ESTADIAMENTO -->
O estadiamento do GIST é determinado pela classificação da UICC (União Internacional Contra o Câncer) ou da AJCC ( _American Joint Committee on Cancer_ ) (Tabelas 3A e 3B) (16).  
TABELA 3A - Estadiamento TNM para GIST em todos os locais  
|Tumor<br>primário (T)<br>TX|O tumor primário não pode<br>ser avaliado.|
|---|---|
|T0|Não há evidência de tumor<br>|
|T1|primário.<br>Tumor com até 2 cm.|
|T2<br>T3|Tumor com mais de 2 cm e<br>com até 5 cm em sua maior<br>dimensão.<br>Tumor com mais de 5 cm e<br>com até 10|
|T4|cm<br>em<br>sua<br>maior<br>dimensão.|
||Tumor com mais de 10 cm<br>em sua maior dimensão.|
|Linfonodos<br>regionais (N)<br>NX|Os linfonodos regionais não<br>podem ser avaliados (*).|
|N0|Ausência de metástase em<br>linfonodos regionais.|
|N1|Metástases em linfonodos<br>regionais.|
|Metástases à<br>distância (M)||
|M0<br>M1|Ausência de metástase à<br>distância.|
||Metástase à distância.|  
(*) NX: O acometimento de linfonodos regionais nos GIST é raro e, assim, os casos que não podem ser avaliados, pela clínica ou pela análise patológica, devem ser considerados N0, ao invés de NX ou pNX.  
A gradação histopatológica (G) para o GIST depende da atividade mitótica:  
- Baixa atividade mitótica: até 5 mitoses/50 campos de grande aumento;  
- Alta atividade mitótica: mais de 5 mitoses/50 campos de grande aumento.  
A atividade mitótica no GIST é melhor expressa como o número de mitoses/50 campos de grande aumento, usando-se a objetiva de 40x (área total 5 mm2 em 50 campos).

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: TABELA 3B - Grupamento por Estádios -->
|Está<br>dio|T|N|M|Atividade<br>mitótica|
|---|---|---|---|---|
||GI<br>|ST GÁSTR<br>|ICO(*)<br>||
|IA|T1,T2|N0|M0|Baixa|
|IB|T3|N0|M0|Baixa|
|II|T1,T2|N0|M0|Alta|
||T4|N0|M0|Baixa|
|IIIA|T3|N0|M0|Alta|
|IIIB|T4|N0|M0|Alta|
|IV|Qualq<br>uer T|N1|M0|Qualquer|
||Qualq<br>uer T|Qualq<br>uer N|M1|Qualquer|
|G|IST DE IN|TESTINO|DELGA|DO(**)|
|I|T1 ou<br>T2|N0|M0|Baixa|
|II|T3|N0|M0|Baixa|
||T1|N0|M0|Alta|
|IIIA|T4|N0|M0|Baixa|
|IIIB|T2, T3,<br>T4|N0|M0|Alta|
||Qualq<br>uer T|N1|M0|Qualquer|
|IV|Qualq<br>uer T|Qualq<br>uer N|M1|Qualquer|  
- (*) Os critérios também podem ser aplicados para GIST solitários primários de omento.  
(**) Os critérios também podem ser aplicados para localizações anatômicas menos comuns, como esôfago, cólon, reto e mesentério.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 5 CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo de tratamento com mesilato de imatinibe pacientes com diagnóstico dos seguintes tipos de GIST:  
- GIST irressecável;  
- GIST metastático ou recidivado após tratamento cirúrgico; e  
- GIST de alto risco de recidiva pós-operatória.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 6 CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo de tratamento com mesilato de imatinibe pacientes que apresentarem muito baixo ou baixo risco de recidiva pós-operatória e puderem ser tratados cirúrgica ou conservadoramente.  
Serão também excluídos os que apresentarem intolerância, hipersensibilidade ou contraindicação ao uso do medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 7 TRATAMENTO -->
O GIST é raro em crianças e adultos jovens (1,4%). Na falta de estudos prospectivos e, portanto, de consenso quanto ao tratamento padrão, a conduta em caso de GIST pediátrico deve ser feita por uma equipe multidisciplinar em serviços especializados em Oncologia pediátrica. Em menos de 15% dos pacientes com mutações dos proto-oncogenes KIT ou PDGFRA, sugere-se que a conduta terapêutica siga as preconizadas para o GIST em adultos.  
As opções terapêuticas para o GIST em adultos incluem ressecção cirúrgica, radioterapia e utilização do inibidor da tirosinoquinase, o mesilato de imatinibe. As opções de tratamento variam de acordo com o estadiamento da doença por ocasião do diagnóstico e com os grupos prognósticos (Tabelas 3A e 3B) (17).

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: CIRURGIA -->
Embora exista consenso de que GIST com mais de 2 cm devam ser ressecados, a ressecção de tumores com menos de 2 cm é tema controverso, não havendo consenso na literatura internacional. Na ausência de achados de alto risco à endoscopia (foco ecogênico, ulceração, margens irregulares), sugere-se que os pacientes sejam acompanhados com exames de imagens e endoscopias de controle.  
O tratamento de escolha para a doença localizada é a ressecção cirúrgica completa, sem violação da pseudocápsula, a fim de reduzir o risco de disseminação tumoral local. O objetivo do tratamento cirúrgico é ressecção total da lesão com margens livres, sem necessidade de linfadenectomia, uma vez que o GIST raramente apresenta envolvimento de linfonodos (2,8,10-12,18,19). Reintervenção cirúrgica geralmente não está indicada quando as margens são positivas microscopicamente ao exame anatomopatológico definitivo (6). Apesar da ressecção cirúrgica completa, somente metade dos pacientes permanece livre de recidiva em 5 anos ou mais (1,2). Portanto, um cuidado meticuloso do cirurgião é mandatório uma vez que a ressecção incompleta do tumor ou sua ruptura parecem ser preditores independentes de pior prognóstico de recidiva (18,20).  
Os GIST localmente avançados, mesmo que ressecados, apresentam altas taxas de recidiva, independentemente da técnica cirúrgica utilizada. Portanto, ressecções cirúrgicas complexas (multiviscerais) devem ser evitadas a favor de procedimentos com mínima morbidade. A quimioterapia com mesilato de imatinibe deve ser considerada em casos de maior risco cirúrgico ou com baixa probabilidade de obtenção de margens negativas (6). Por exemplo, cirurgias mutilantes podem ser evitadas nos casos de GIST primários do reto e da junção gastroesofágica que mostrem regressão com imatinibe pré-operatório.  
O fígado e o peritônio são os locais de metástases mais comuns, e cerca de 30% dos pacientes com doença recidivada ou metastática apresentam GIST potencialmente ressecável. Mesmo na ausência de estudos randomizados, a cirurgia em pacientes selecionados com doença metastática parece aumentar o controle da doença em longo prazo, quando há resposta ao tratamento inicial com imatinibe (isto é, resposta parcial, doença estável ou somente progressão focal). Nesses casos, o imatinibe deve ser mantido após a ressecção, mesmo se esta for completa.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: RADIOTERAPIA -->
Radioterapia localizada é uma opção de tratamento para os pacientes não candidatos à cirurgia por quaisquer motivos, nos quais se deseja controlar localmente a progressão da doença. Entretanto, não há comprovação de benefício em termos de sobrevida geral (21).  
O emprego de radioterapia também pode ser considerado nos casos de intolerância ou resistência a inibidor de tirosinoquinase, assim como no tratamento paliativo de pacientes sintomáticos (22).

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: TRATAMENTO MEDICAMENTOSO -->
A terapia medicamentosa do GIST com mesilato de imatinibe abrange: a) a quimioterapia adjuvante, após o tratamento cirúrgico com ou sem ressecção microscópica completa do tumor primário, e b) a quimioterapia paliativa da doença avançada primariamente irressecável (que pode, ou não, tornar-se ressecável e operável) e da doença metastática ou recidivada.  
Quimioterapia adjuvante (profilática ou pós-operatória)  
O fundamento da quimioterapia adjuvante do GIST com mesilato de imatinibe inclui o fato de que a taxa de recidiva do tumor, independentemente da obtenção de margens negativas com a cirurgia, é de 50%. Além disso, a terapia adjuvante com outros antineoplásicos ou radioterapia não são efetivas no GIST (12,23). Taxas de resposta ao redor de 5% têm sido observadas com quimioterapia com outros antineoplásicos. A radioterapia é raramente utilizada face à dificuldade de proteger os tecidos normais adjacentes.  
Na expectativa de que mais pesquisas venham corroborar as conclusões iniciais de dois estudos randomizados recentes, o uso de imatinibe adjuvante por 3 anos pode ser considerado para pacientes com alto risco de recidiva (24-26).  
O primeiro estudo controlado _versus_ placebo, envolvendo 713 pacientes, demonstrou aumento da sobrevida livre de doença em 1 ano de 15% (98% _versus_ 83%) no grupo de pacientes de alto risco tratados com imatinibe adjuvante (400 mg/dia) (24). Esse estudo randomizado de fase III alocou pacientes adultos com diagnóstico de GIST primário localizado, com ao menos 3 cm de diâmetro, positivos para proteína KIT (CD117) por imuno-histoquímica, para receber de forma duplo-cega 400 mg/dia de imatinibe ou placebo durante 1 ano. A alocação foi realizada de forma a distribuir igualmente, entre os grupos, pacientes com diferentes tamanhos de tumor. Dos 778 casos registrados, 713 foram randomizados. A intervenção foi iniciada até 84 dias após a ressecção cirúrgica, independentemente de comprometimento microscópico da margem cirúrgica. Havendo recidiva tumoral, o cegamento era quebrado, permitindo-se a troca de braço para imatinibe no caso de pacientes que vinham recebendo placebo ou que já haviam terminado o tempo de tratamento com imatinibe, ou o aumento de dose para 800 mg/dia no grupo em tratamento com imatinibe.  
Durante o estudo, o desfecho primário, originalmente a sobrevida total, foi modificado para sobrevida livre de doença, uma vez que o desenho, ao permitir a troca de braço no caso de recidiva e exposição de ambos os grupos ao agente em estudo, não favoreceria a demonstração de diferença na sobrevida total. A recidiva foi definida como recidiva tumoral (não detalhados critérios ou óbito por qualquer causa). Análise interina determinou interrupção da inclusão de novos pacientes antes de se completar o tempo de seguimento previsto, por ter sido atingido o limiar de eficácia pré-estabelecido. Com um seguimento médio de 19,7 meses, a sobrevida livre de doença foi de 98% no grupo imatinibe e de 83% no grupo placebo. Não foi verificada diferença na sobrevida total, tendo sido observadas 8 mortes (2,3%) no grupo placebo (5 atribuídas ao GIST) e 5 mortes no grupo imatinibe (nenhuma atribuída ao GIST). Análise de eficácia foi estratificada pelo tamanho do tumor, tendo sido demonstrado benefício em tumores com mais de 6 cm.  
O estudo apresentou vários e graves problemas metodológicos, a começar pela randomização. Entre os 713 pacientes randomizados, 65 (9,1%) foram considerados inelegíveis (33 no grupo placebo e 32 no grupo imatinibe), mas tiveram seus dados incluídos na análise por intenção de tratar. A ocorrência de cruzamento entre os grupos prejudicou a avaliação da evolução do grupo placebo em termos de sobrevida. A interrupção do estudo também não permitiu avaliar a evolução em longo prazo, bem como a ocorrência de possíveis falhas tardias ao imatinibe. O estudo não foi capaz de demonstrar diferença na sobrevida total entre o grupo que empregou imatinibe logo após a ressecção cirúrgica e o grupo que fez uso após a recidiva.  
Outra limitação deste estudo foi a falta de avaliação de possíveis diferenças na qualidade de vida ou demanda por serviços assistenciais nos dois grupos. O desfecho sobrevida livre de doença, cada vez  
mais usado em estudos oncológicos, tem relevância clínica relativa na medida em que pode não ser acompanhado de melhora da qualidade de vida ou de redução significativa na morbidade (hospitalizações, complicações infecciosas, demanda por serviços assistenciais, etc.). Considerando-se o número cinco vezes maior de retirada do estudo no grupo tratado por efeitos adversos e a ocorrência de eventos adversos de graus 3 ou 4 em 30% dos casos tratados, o perfil de toxicidade do imatinibe deve ser avaliado na decisão de tratar. Curiosamente, as causas de óbito não foram descritas e, apesar de os autores afirmarem que não houve óbitos relacionados ao GIST no grupo imatinibe, a tabela de efeitos adversos aponta 3 casos de efeitos adversos grau 5 (óbito diretamente causado pelo tratamento). Pode-se argumentar que, mesmo tendo causado diretamente a morte de 3 pacientes, isso não repercutiu na redução da mortalidade total, mas esse dado levanta sérios questionamentos, principalmente se essas mortes ocorreram no grupo de baixo risco. Apesar desses dados, essa é a melhor evidência disponível que justifica o uso de imatinibe nos pacientes classificados como de alto risco (25,26).  
O estudo mais recente com cerca de 400 pacientes, comparou o uso de imatinibe adjuvante (400 mg/dia) por 1 ou 3 anos. Os resultados confirmaram o benefício do fármaco em relação à sobrevida livre de doença e, pela primeira vez, foi demonstrado aumento da sobrevida geral. Os pacientes com alto risco de recidiva da doença tratados por 36 meses comparados aos que utilizaram o fármaco por 12 meses apresentaram sobrevida geral em 5 anos de 92% e 81,7%, respectivamente (27).  
Em suma, conforme a evidência disponível, ao se considerar a quimioterapia adjuvante com imatinibe, é essencial a seleção adequada de pacientes com alto risco de recidiva tomando-se por base o especificado na Tabela 1, que contempla um dos três esquemas de estratificação de risco validados (12,13,28).  
Adicionalmente, um nomograma prognóstico recentemente validado pode ser utilizado para avaliar a sobrevida livre de doença em 2 e 5 anos de pacientes com GIST primário localizado e completamente ressecado (29).  
A indicação de tratamento adjuvante para pacientes com risco intermediário é mais controversa. Entretanto, para fins da prática clínica, essa questão geralmente é contornável. Com a utilização da classificação modificada do Instituto Nacional de Saúde dos EUA (critérios de Joensuu), pode-se reestratificar a maioria dos pacientes com risco intermediário para baixo ou alto risco e, assim, auxiliar na tomada de decisão sobre quando tratar os pacientes com risco intermediário (28).  
Quimioterapia da doença avançada  
Quimioterapia da doença primariamente irressecável  
Embora não existam estudos randomizados, o uso de imatinibe pode tornar ressecável doença primariamente irressecável ou com risco de morbidade significativa (10). Os GIST primários do reto ou da junção gastroesofágica, por exemplo, podem responder ao imatinibe e, assim, possibilitar tratamentos cirúrgicos mais conservadores (30).  
- Quimioterapia da doença metastática ou recidivada  
Dois estudos randomizados, incluindo cerca de 1.700 pacientes com GIST avançado, demonstraram uma taxa de resposta em torno de 50% com o uso paliativo de imatinibe, não havendo diferença significativa entre os dois níveis de dose testados (400 mg/dia _versus_ 800 mg/dia). Após 3 anos de acompanhamento, a sobrevida livre de doença e a sobrevida geral não foram maiores no grupo que usou a dose maior. Tais dados, associados a uma menor toxicidade, confirmaram 400 mg/dia como a dose inicial apropriada para a maioria dos pacientes. O aumento da dose-padrão (400 mg, duas vezes ao dia) pode ser prescrito se houver progressão da doença em pacientes com boa tolerância ao tratamento, ou seja, na ausência de reações adversas graves ao imatinibe (6,30,31).  
A manutenção do imatinibe faz-se necessária nos casos de GIST sem progressão tumoral, já que a maioria dos pacientes apresenta recidiva da doença após a interrupção do medicamento. Também se aplica com o intuito de manter a intensidade da dose e o controle excelente dos sintomas relacionados aos efeitos adversos do fármaco antes de se considerar uma redução da dose-padrão diária (400 mg/dia), para uma dose mínima de 200 mg/dia (32).  
A presença e o local da mutação em c-KIT ou em PDGFRA são fatores preditivos de resposta ao imatinibe em casos de doença avançada ou metastática (33,34). Esse fármaco tem seu papel principal estabelecido no tratamento do GIST avançado, mas alguns pacientes podem desenvolver resistência (35).  
A resistência primária é definida como a presença de progressão da doença durante os primeiros 6 meses de tratamento com imatinibe e é mais frequentemente encontrada nos pacientes com as mutações em c-KIT éxons 9, 13, 17, em PDGFRA éxon 18 e com GIST tipo selvagem (6,36).  
A resistência secundária é detectada quando há progressão da doença após 6 meses de tratamento com imatinibe, depois de uma resposta inicial, e ocorre mais frequentemente pela aquisição de novas mutações em c-KIT. Nesses casos, diversos estudos avaliaram se o aumento da dose de 400 mg/dia para 800 mg/dia era seguro e eficaz. Em um deles, o aumento da dose proporcionou estabilização da doença em 27% dos pacientes avaliados e sobrevida geral em 18,1% ao final do primeiro ano, à custa de maior toxicidade (37-39).  
O maleato de sunitinibe, um inibidor da fosforilação de múltiplas tirosinoquinases, foi testado na quimioterapia de segunda linha do GIST em um ensaio clínico _versus_ placebo, que incluiu 312 pacientes com doença avançada, intolerantes ou resistentes ao imatinibe. No estudo, o cegamento foi suspenso precocemente após análise interina ter demonstrado diferença estatisticamente significativa entre os grupos no desfecho primário, definido por tempo até progressão radiológica. O tempo até progressão de doença foi significativamente maior no grupo tratado (27,3 semanas, IC 95% 16-32,1 semanas _versus_ 6,4 semanas, IC 95% 4,4-10 semanas; HR 0,33, IC 95% 0,23-0,47; p<0,0001). A sobrevida total foi descrita como superior no grupo tratado com sunitinibe, no entanto valores absolutos não são relatados; e, como mais da metade dos pacientes estavam vivos no momento da análise, a sobrevida mediana não pôde ser calculada. Taxas de resposta objetiva (redução do tumor) foram baixas em ambos os grupos (7% no grupo sunitinibe _versus_ 0% no placebo; CI 95% 3,7-11,1; p = 0,006). Eventos adversos graves foram observados mais frequentemente no grupo sunitinibe (20% _versus_ 5%). O delineamento, permitindo a suspensão do cegamento e a troca do grupo placebo para o grupo intervenção, uma vez identificada a progressão, não é adequado para mostrar efeito da intervenção na sobrevida. Qualidade de vida não foi avaliada, sendo o critério de progressão basicamente radiológico.  
A principal crítica a esse estudo consiste no fato de haver evidências de que a suspensão do imatinibe está associada a aumento do risco de progressão acelerada da doença, o que pode ter impactado negativamente nos desfechos observados no grupo placebo. De fato, a sobrevida livre de progressão no grupo placebo foi de 6 semanas, enquanto a sobrevida livre de doença estimada com escalonamento de dose de imatinibe foi de cerca de 11,6 semanas. Esse dado aponta para um aspecto que pode ser criticável do ponto de vista ético. Não foi descrito quantos pacientes entre os definidos como resistentes tinham espaço para o escalonamento. Assim, a duração de estabilidade da doença, apontada como superior no grupo sunitinibe, como igual ou superior a 22 semanas observada em 17% dos pacientes que receberam sunitinibe e em 2% do grupo placebo, não pode ser aceita como verdadeira (40-43).  
Os efeitos adversos comuns do sunitinibe incluem diarreia (40%), astenia (37%), fadiga (33%), hipertensão (28%) e náusea (27%), além de hipotireoidismo, anemia, neutropenia, trombocitopenia, linfocitopenia e diminuição da fração de ejeção ventricular (40, 44).  
Assim, diante da natureza da evidência disponível, recomenda-se aguardar novos e mais adequados estudos para que o sunitinibe possa ser devidamente avaliado pela Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC), inclusive quanto ao custo-efetividade de considerá-lo terapia de segunda linha para GIST (44-47).  
Por tais razões, o sunitinibe não está indicado neste Protocolo.  
O mesilato de imatinibe é comprado pelo Ministério da Saúde e fornecido pelas Secretarias Estaduais de Saúde aos hospitais credenciados no SUS e habilitados em Oncologia.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 7.1 FÁRMACO -->
Mesilato de imatinibe: comprimidos de 100 mg e 400 mg.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 7.2 ESQUEMA DE ADMINISTRAÇÃO -->
Mesilato de imatinibe: 400 mg/dia por via oral, em dose única diária. A dose pode ser aumentada para 600 mg/dia ou 800 mg/dia na ausência de reações adversas e se houver resposta insuficiente à terapia com a dose-padrão. O comprimido deve ser ingerido durante as refeições com baixo teor de gordura para minimizar o risco de efeitos gastrointestinais, com um copo grande de água. Doses de 400 mg ou 600 mg devem ser administradas em dose única diária, enquanto a de 800 mg deve ser dividida em duas administrações diárias, pela manhã e à noite.  
Os comprimidos podem ser dissolvidos em um copo de água ou suco de maçã para pacientes com dificuldade de deglutição. O número de comprimidos necessários deverá ser colocado em um volume apropriado (aproximadamente 50 ml para um comprimido de 100 mg e 200 ml para um comprimido de 400 mg) e misturando com auxílio de uma colher. A suspensão deve ser ingerida imediatamente após a dissolução completa do(s) comprimido(s).  
A dose do mesilato de imatinibe para tratamento de crianças e adolescentes com GIST não está determinada, mas autores recomendam a mesma faixa de doses utilizadas na quimioterapia da leucemia mieloide crônica e linfoblástica aguda cromossoma Philadelphia positivo, em tomada única. Na falta dessa determinação e considerando a raridade do GIST em crianças e adolescentes, bem como o grave evento adverso de retardo do crescimento com o uso crônico do imatinibe por doentes nessa faixa etária, aqui se protocola a dose de 300 mg/m2/dia.  
Para o cálculo da dose, utiliza-se o peso real ou o ideal, aquele que for menor. Os comprimidos de 100 mg ou de 400 mg podem ser fracionados e diluídos com água. A proporção de água é de 50 ml para cada 100 mg. A mistura diluída deverá ser administrada imediatamente após a dissolução completa do medicamento. Recomenda-se a ingestão após a maior refeição do dia.

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 7.3 EFEITOS ADVERSOS -->
O Imatinibe é razoavelmente tolerado, e os efeitos adversos geralmente são de intensidade leve a moderada, melhorando com a continuação do tratamento. Os mais comuns são retenção hídrica, câimbras, náusea, fadiga, dor abdominal, diarreia e _rash_ cutâneo.  
Retenção hídrica com edema periférico e, ocasionalmente, derrame pleural e ascite são comuns em pacientes mais idosos e nos com comprometimento cardíaco. Edema periorbital é mais frequente e não responde a diuréticos, sendo mais acentuado pela manhã e melhorando ao longo do dia. As câimbras musculares são o efeito colateral mais desagradável, afetando panturrilhas, pés e mãos. Náusea, vômitos e dispepsia são amenizados com a ingestão do imatinibe com alimentos de baixo teor de gordura, o que não diminui a absorção. Podem ser utilizados antiácidos e bloqueadores da bomba de prótons. Dor abdominal e diarreia são comuns e tratadas sintomaticamente. _Rash_ cutâneo é usualmente maculopapular e leve e se resolve com a continuação do tratamento (48).  
A toxicidade hematológica compreende anemia grau 3 em até 42% e grau 4 em até 11% dos pacientes. Macrocitose pode ocorrer, e seu mecanismo é desconhecido. Neutropenia e plaquetopenia podem ocorrer em menos de 10%, com duração média de 3 semanas. Para a continuidade do uso do medicamento, o número absoluto de neutrófilos deve estar acima de 1.000 células/mm3. Ginecomastia e toxicidades hepática, pulmonar e cardíaca foram relatadas ocasionalmente. Sangramento gastrointestinal pode ocorrer em 5% dos pacientes com tumores grandes, não estando associado a trombocitopenia. Uma queda da hemoglobina igual ou superior a 2 g/dl deve levar à suspensão do imatinibe e imediata avaliação do paciente quanto à possibilidade de sangramento (48).  
7.4 TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO  
O tratamento deverá ser interrompido em casos de falta ou falha de resposta, toxicidade ou progressão da doença, evidenciadas por acompanhamento clínico e por exames de imagem.  
A interrupção do imatinibe resulta em progressão rápida da doença na maioria dos pacientes com GIST avançado e não deve ser recomendada, a menos que haja toxicidade intolerável. Em estudo comparativo com sunitinibe, a intolerância ao imatinibe foi definida como qualquer grau 4 de toxicidade ou toxicidade inaceitável induzida pela dose-padrão (400 mg/dia) (45).  
Conforme evidência atual, é recomendada quimioterapia paliativa contínua até a progressão da doença em casos de GIST avançado (metastático ou recidivado) e por 3 anos se a finalidade da quimioterapia for adjuvante (48).  
Durante o tratamento medicamentoso, o paciente deve ser avaliado com relação a sintomas e sinais de toxicidade e ser submetido regularmente a exames laboratoriais (hemograma, contagem de plaquetas e dosagens de aminotransferases/transaminases - AST/TGO e ALT/TGP, ureia, creatinina, sódio e potássio), a cada 1-2 meses.  
Deve-se buscar exaustivamente a ocorrência de possíveis interações de quaisquer medicamentos com imatinibe. Não se recomenda a prescrição concomitante de medicamentos que utilizam as enzimas CYP para seu metabolismo (por exemplo, paracetamol, varfarina e derivados azólicos).

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 8.1 AVALIAÇÃO DA RESPOSTA TERAPÊUTICA -->
Preferencialmente, devem ser selecionadas para avaliação as lesões fixas, bem definidas e não confluentes (até duas por órgão).  
A TC com contraste é o método de imagem-padrão para pacientes com GIST. A resposta ao imatinibe pode ser definida pela ausência de recidiva ou progressão da doença na primeira avaliação por TC, a ser realizada em torno de 3 meses após o início do tratamento. Em relação ao seguimento, recomenda-se controle a cada 3-6 meses, ou a utilização do método de acompanhamento desenvolvido por Joensuu e colaboradores, baseado na estimativa do risco de recorrência, que demonstrou reduzir o número total de exames, sem comprometer a capacidade de detecção precoce de recidiva (49). Diferentemente de outros quimioterápicos antineoplásicos, para a avaliação da resposta aos inibidores de tirosinoquinase têm sido utilizados os critérios introduzidos por Choi, que considera a redução da densidade do tumor além da diminuição do volume de doença mensurável (RECIST - _Response Evaluation Criteria in Solid Tumors_ ). Assim, a evidência sugere que uma diminuição de pelo menos 10% do tamanho ou de pelo menos 15% da densidade do tumor seja considerada uma resposta parcial ao tratamento com imatinibe (50). A máxima redução do tamanho do tumor pode ocorrer após 6-12 meses de tratamento.  
Além do aparecimento de novas lesões ou aumento do tamanho de alguma lesão, ocasionalmente pode ocorrer a formação de novo(s) nódulo(s) hiperatenuado(s) dentro de uma massa aparentemente estável. Essas formas de progressão real no GIST devem ser diferenciadas de uma pseudoprogressão que ocorre, por exemplo, quando uma lesão aumenta devido à hemorragia intratumoral ou degeneração mixoide.  
Em razão de sua melhor sensibilidade para avaliar lesões pequenas, a ressonância magnética do abdômen está indicada se houver intenção de ressecção de metástase(s) hepática(s).  
Detecção de progressão da doença a despeito do tratamento indica resistência primária, e detecção de progressão após uma resposta clínica inicial, resistência secundária (51).  
9 ACOMPANHAMENTO APÓS TRATAMENTO CIRÚRGICO E QUIMIOTERAPIA ADJUVANTE  
Após a suspensão da quimioterapia adjuvante, está indicada TC de 3/3 meses por 2 anos, a cada 6 meses por mais 3 anos e anualmente até o 10<sup>o</sup> ano pós-tratamento. Depois disso, a recorrência é rara, e não há mais benefício no controle por exames de imagem (52).

---

<!-- METADADOS: doenca: Tumor do Estroma Gastrointestinal | secao: 10 REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Pacientes com diagnóstico de GIST devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, tratar e realizar o acompanhamento.  
Além da familiaridade que esses hospitais guardam com o estadiamento, tratamento, manejo das doses e controle dos efeitos adversos, eles dispõem de toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos pacientes, facilitando as ações de controle e avaliação. Incluem-se, entre essas ações: manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); autorização prévia dos procedimentos; monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente - primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, existência e observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod); compatibilidade da cobrança com os serviços executados; abrangência e integralidade assistenciais; e grau de satisfação dos pacientes.  
Excetuando-se a talidomida para o tratamento do mieloma múltiplo, o mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo e o trastuzumabe para a quimioterapia do carcinoma de mama inicial e locorregionalmente avançado, o Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. Os procedimentos quimioterápicos da tabela do SUS não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas estão indicadas. Ou seja, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento do medicamento antineoplásico é desse hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos radioterápicos e quimioterápicos (Grupo 03, Subgrupo 04) e cirúrgicos (Grupo 04 e os vários subgrupos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e OPM do SUS podem ser acessados, por código do procedimento ou nome do procedimento e por código da CID – Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde – para a respectiva neoplasia maligna, no Sistema de Gerenciamento dessa Tabela <u>(http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp) com versão mensalmente</u> disponibilizada.  
Os procedimentos da tabela do SUS para a quimioterapia de adultos com GIST, com o mesilato de imatibe, são os seguintes:  
- Quimioterapia paliativa – adulto  
- 03.04.02.031-1– Quimioterapia do tumor do estroma gastrointestinal  
- Quimioterapia adjuvante (pós-operatória, profilática) – adulto  
- 03.04.05.033-4– Quimioterapia do tumor do estroma gastrointestinal  
NOTA: O mesilato de imatinibe é adquirido pelo Ministério da Saúde e fornecido pelas Secretarias Estaduais de Saúde aos hospitais credenciados no SUS e habilitados em Oncologia. Para crianças e adolescentes, não pode ser autorizada APAC com procedimento de quimioterapia para tumores na infância e adolescência e para uso isolado de mesilato de imatinibe para quimioterapia paliativa ou adjuvante de GIST. Neste caso, o atendimento ambulatorial pode ser ressarcido como consulta especializada.  
11 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER  
É obrigatória a informação ao paciente ou a seu responsável legal dos benefícios potenciais riscos e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo.  
12 REFERÊNCIAS BIBLIOGRÁFICAS  
1. Demetri GD, Morgan J, Raut CP. Epidemiology, classification, clinical presentation, prognostic features, and diagnostic work-up of gastrointestinal mesenchymal neoplasms including GIST: UpToDate; 2012 [May 23, 2014]. Available from: http://www.uptodate.com/contents/epidemiologyclassification-clinical-presentation-prognostic-features-and-diagnostic-work-up-of-gastrointestinalmesenchymal-neoplasms-including-gist.  
2. Rubin BP, Heinrich MC, Corless CL. Gastrointestinal stromal tumour. Lancet. 2007;369(9574):1731-41.  
3. Benesch M, Wardelmann E, Ferrari A, Brennan B, Verschuur A. Gastrointestinal stromal tumors (GIST) in children and adolescents: A comprehensive review of the current literature. Pediatr Blood Cancer. 2009;53(7):1171-9.  
4. Hirota S, Isozaki K, Moriyama Y, Hashimoto K, Nishida T, Ishiguro S, et al. Gain-of-function mutations of c-kit in human gastrointestinal stromal tumors. Science. 1998;279(5350):577-80.  
5. Janeway KA, Kim S, Lodish M, Nose V, Dahia P, Rustin P, et al. Succinate dehydrogenase in KIT/PDGFRA wild-type gastrointestinal stromal tumors. J Clin Oncol. 2010;28(15S):A10008.  
6. Guidelines NCCN Clinical Practice Guidelines in Oncology - Soft Tissue Sarcoma 2012. Available from: http://www.nccn.org/professionals/physician_gls/f_guidelines.asp.  
7. Avritscher R, Gupta S. Gastrointestinal stromal tumor: role of interventional radiology in diagnosis and treatment. Hematol Oncol Clin North Am. 2009;23(1):129-37, ix.  
8. Ploner F, Zacherl J, Wrba F, Langle F, Bareck E, Eisterer W, et al. Gastrointestinal stromal tumors: Recommendations on diagnosis, therapy and follow-up care in Austria. Wien Klin Wochenschr. 2009;121(23-24):780-90.  
9. Liegl B, Hornick JL, Corless CL, Fletcher CD. Monoclonal antibody DOG1.1 shows higher sensitivity than KIT in the diagnosis of gastrointestinal stromal tumors, including unusual subtypes. Am J Surg Pathol. 2009;33(3):437-46.  
10. Samelis GF, Ekmektzoglou KA, Zografos GC. Gastrointestinal stromal tumours: clinical overview, surgery and recent advances in imatinib mesylate therapy. Eur J Surg Oncol. 2007;33(8):94250.  
11. Nowain A, Bhakta H, Pais S, Kanel G, Verma S. Gastrointestinal stromal tumors: clinical profile, pathogenesis, treatment strategies and prognosis. J Gastroenterol Hepatol. 2005;20(6):818-24.  
12. Fletcher CD, Berman JJ, Corless C, Gorstein F, Lasota J, Longley BJ, et al. Diagnosis of gastrointestinal stromal tumors: A consensus approach. Hum Pathol. 2002;33(5):459-65.  
13. Miettinen M, Lasota J. Gastrointestinal stromal tumors: pathology and prognosis at different sites. Semin Diagn Pathol. 2006;23(2):70-83.  
14. Scarpa M, Bertin M, Ruffolo C, Polese L, D'Amico DF, Angriman I. A systematic review on the clinical diagnosis of gastrointestinal stromal tumors. J Surg Oncol. 2008;98(5):384-92.  
15. Tio TL, Tytgat GN, den Hartog Jager FC. Endoscopic ultrasonography for the evaluation of smooth muscle tumors in the upper gastrointestinal tract: an experience with 42 cases. Gastrointest Endosc. 1990;36(4):342-50.  
16. Câncer UICo. [TNM : classificação dos tumores malignos]. 7 ed. Rio de Janeiro: Instituto Nacional de Câncer; 2012.  
17. Reddy P, Boci K, Charbonneau C. The epidemiologic, health-related quality of life, and economic burden of gastrointestinal stromal tumours. J Clin Pharm Ther. 2007;32(6):557-65.  
18. Rutkowski P, Nowecki ZI, Michej W, Debiec-Rychter M, Wozniak A, Limon J, et al. Risk criteria and prognostic factors for predicting recurrences after resection of primary gastrointestinal stromal tumor. Ann Surg Oncol. 2007;14(7):2018-27.  
19. Loong HH. Gastro-intestinal stromal tumours: a review of current management options. Hong Kong Med J. 2007;13(1):61-5.  
20. Hohenberger P, Ronellenfitsch U, Oladeji O, Pink D, Strobel P, Wardelmann E, et al. Pattern of recurrence in patients with ruptured primary gastrointestinal stromal tumour. Br J Surg. 2010;97(12):1854-9.  
21. Raut CP, George S, Demetri GD. Surgical treatment and other localized therapy for metastatic soft tissue sarcoma: UpToDate; 2012 [May 23, 2014]. Available from: http://www.uptodate.com/contents/surgical-treatment-and-other-localized-therapy-for-metastaticsoft-tissue-sarcoma.  
22. Knowlton CA, Brady LW, Heintzelman RC. Radiotherapy in the treatment of gastrointestinal stromal tumor. Rare Tumors. 2011;3(4):e35.  
23. Cirocchi R, Farinella E, La Mura F, Cavaliere D, Avenia N, Verdecchia GM, et al. Efficacy of surgery and imatinib mesylate in the treatment of advanced gastrointestinal stromal tumor: a systematic review. Tumori. 2010;96(3):392-9.  
24. Dematteo RP, Ballman KV, Antonescu CR, Maki RG, Pisters PW, Demetri GD, et al. Adjuvant imatinib mesylate after resection of localised, primary gastrointestinal stromal tumour: a randomised, double-blind, placebo-controlled trial. Lancet. 2009;373(9669):1097-104.  
25. Keun Park C, Lee EJ, Kim M, Lim HY, Choi DI, Noh JH, et al. Prognostic stratification of highrisk gastrointestinal stromal tumors in the era of targeted therapy. Ann Surg. 2008;247(6):1011-8.  
26. US National Institutes of Health. Imatinib Mesylate or Observation Only in Treating Patients Who Have Undergone Surgery for Localized Gastrointestinal Stromal Tumo 2010 [May 23, 2014]. Available from: http://clinicaltrials.gov/show/NCT00103168.  
27. Joensuu H, Eriksson M, Sundby Hall K, Hartmann JT, Pink D, Schutte J, et al. One vs three years of adjuvant imatinib for operable gastrointestinal stromal tumor: a randomized trial. JAMA. 2012;307(12):1265-72.  
28. Rutkowski P, Bylina E, Wozniak A, Nowecki ZI, Osuch C, Matlok M, et al. Validation of the Joensuu risk criteria for primary resectable gastrointestinal stromal tumour - the impact of tumour rupture on patient outcomes. Eur J Surg Oncol. 2011;37(10):890-6.  
29. Gold JS, Gonen M, Gutierrez A, Broto JM, Garcia-del-Muro X, Smyrk TC, et al. Development and validation of a prognostic nomogram for recurrence-free survival after complete surgical resection of localised primary gastrointestinal stromal tumour: a retrospective analysis. Lancet Oncol. 2009;10(11):1045-52.  
30. Bamboat ZM, Dematteo RP. Updates on the management of gastrointestinal stromal tumors. Surg Oncol Clin N Am. 2012;21(2):301-16.  
31. Blanke CD, Rankin C, Demetri GD, Ryan CW, von Mehren M, Benjamin RS, et al. Phase III randomized, intergroup trial assessing imatinib mesylate at two dose levels in patients with unresectable or metastatic gastrointestinal stromal tumors expressing the kit receptor tyrosine kinase: S0033. J Clin Oncol. 2008;26(4):626-32.  
32. Eisenberg BL, Pipas JM. Gastrointestinal stromal tumor--background, pathology, treatment. Hematol Oncol Clin North Am. 2012;26(6):1239-59.  
33. Lasota J, Miettinen M. Clinical significance of oncogenic KIT and PDGFRA mutations in gastrointestinal stromal tumours. Histopathology. 2008;53(3):245-66.  
34. Heinrich MC, Corless CL, Demetri GD, Blanke CD, von Mehren M, Joensuu H, et al. Kinase mutations and imatinib response in patients with metastatic gastrointestinal stromal tumor. J Clin Oncol. 2003;21(23):4342-9.  
35. Chen P, Zong L, Zhao W, Shi L. Efficacy evaluation of imatinib treatment in patients with gastrointestinal stromal tumors: a meta-analysis. World J Gastroenterol. 2010;16(33):4227-32.  
36. Benjamin RS, Debiec-Rychter M, Le Cesne A, Sleijfer S, Demetri GD, Joensuu H, et al. Gastrointestinal stromal tumors II: medical oncology and tumor response assessment. Semin Oncol. 2009;36(4):302-11.  
37. Gastrointestinal Stromal Tumor Meta-Analysis Group. Comparison of two doses of imatinib for the treatment of unresectable or metastatic gastrointestinal stromal tumors: a meta-analysis of 1,640 patients. J Clin Oncol. 2010;28(7):1247-53.  
38. Zalcberg JR, Verweij J, Casali PG, Le Cesne A, Reichardt P, Blay JY, et al. Outcome of patients with advanced gastro-intestinal stromal tumours crossing over to a daily imatinib dose of 800 mg after progression on 400 mg. Eur J Cancer. 2005;41(12):1751-7.  
39. Patel S, Zalcberg JR. Optimizing the dose of imatinib for treatment of gastrointestinal stromal tumours: lessons from the phase 3 trials. Eur J Cancer. 2008;44(4):501-9.  
40. Demetri GD, van Oosterom AT, Garrett CR, Blackstein ME, Shah MH, Verweij J, et al. Efficacy and safety of sunitinib in patients with advanced gastrointestinal stromal tumour after failure of imatinib: a randomised controlled trial. Lancet. 2006;368(9544):1329-38.  
41. Rutkowski P, Przybyl J, Zdzienicki M. Extended adjuvant therapy with imatinib in patients with gastrointestinal stromal tumors : recommendations for patient selection, risk assessment, and molecular response monitoring. Mol Diagn Ther. 2013;17(1):9-19.  
42. Blay JY, Le Cesne A, Ray-Coquard I, Bui B, Duffaud F, Delbaldo C, et al. Prospective multicentric randomized phase III study of imatinib in patients with advanced gastrointestinal stromal tumors comparing interruption versus continuation of treatment beyond 1 year: the French Sarcoma Group. J Clin Oncol. 2007;25(9):1107-13.  
43. Le Cesne A, Ray-Coquard I, Bui BN, Adenis A, Rios M, Bertucci F, et al. Discontinuation of imatinib in patients with advanced gastrointestinal stromal tumours after 3 years of treatment: an open-label multicentre randomised phase 3 trial. Lancet Oncol. 2010;11(10):942-9.  
44. George S, Blay JY, Casali PG, Le Cesne A, Stephenson P, Deprimo SE, et al. Clinical evaluation of continuous daily dosing of sunitinib malate in patients with advanced gastrointestinal stromal tumour after imatinib failure. Eur J Cancer. 2009;45(11):1959-68.  
45. Rock EP, Goodman V, Jiang JX, Mahjoob K, Verbois SL, Morse D, et al. Food and Drug Administration drug approval summary: Sunitinib malate for the treatment of gastrointestinal stromal tumor and advanced renal cell carcinoma. Oncologist. 2007;12(1):107-13.  
46. Contreras-Hernandez I, Mould-Quevedo JF, Silva A, Salinas-Escudero G, Villasis-Keever MA, Granados-Garcia V, et al. A pharmaco-economic analysis of second-line treatment with imatinib or sunitinib in patients with advanced gastrointestinal stromal tumours. Br J Cancer. 2008;98(11):1762-8.  
47. Younus J, Verma S, Franek J, Coakley N, Sacroma Disease Site Group of Cancer Care Ontario's Program in Evidence-Based C. Sunitinib malate for gastrointestinal stromal tumour in imatinib mesylate-resistant patients: recommendations and evidence. Curr Oncol. 2010;17(4):4-10.  
48. Demetri GD, Jeffrey Morgan M. Tyrosine kinase inhibitor therapy for advanced gastrointestinal stromal tumors: UpToDate; 2012 [May 23, 2014]. Available from: http://www.uptodate.com/contents/tyrosine-kinase-inhibitor-therapy-for-advanced-gastrointestinalstromal-tumors?source=see_link.  
49. Joensuu H, Reichardt P, Eriksson M, Sundby Hall K, Vehtari A. Gastrointestinal stromal tumor: a method for optimizing the timing of CT scans in the follow-up of cancer patients. Radiology. 2014;271(1):96-103.  
50. Choi H, Charnsangavej C, Faria SC, Macapinlac HA, Burgess MA, Patel SR, et al. Correlation of computed tomography and positron emission tomography in patients with metastatic gastrointestinal stromal tumor treated at a single institution with imatinib mesylate: proposal of new computed tomography response criteria. J Clin Oncol. 2007;25(13):1753-9.  
51. Le Cesne A, Van Glabbeke M, Verweij J, Casali PG, Findlay M, Reichardt P, et al. Absence of progression as assessed by response evaluation criteria in solid tumors predicts survival in advanced GI stromal tumors treated with imatinib mesylate: the intergroup EORTC-ISG-AGITG phase III trial. J Clin Oncol. 2009;27(24):3969-74.  
52. Verweij J. Adjuvant Treatment of Gastrointestinal Stromal Tumor: The Proof, The Pro, and the Practice. Am Soc Clin Oncol Educ Book. 2012;32:659-62.  
TERMO DE ESCLARECIMENTO E RESPONSABILIDADE MESILATO DE IMATINIBE  
Eu,   (nome do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do mesilato de imatinibe, indicado para o tratamento do tumor do estroma gastrointestinal (GIST).  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico   (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- ausência de progressão da doença;  
- redução do tamanho do tumor;  
- redução do aparecimento de novas lesões ou aumento do tamanho de alguma lesão.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- risco de uso do imatinibe na gravidez; portanto, caso engravide, devo avisar imediatamente o médico;  
- interação do imatinibe com, por exemplo, anticonvulsivantes, antidepressivos, alguns antitérmicos, remédios contra fungos, entre outros, o que exige a leitura detalhada das recomendações descritas pelo fabricante;  
- efeitos adversos mais comuns: diminuição da produção de glóbulos brancos, vermelhos e plaquetas, problemas no fígado e nos ossos, dores articulares e musculares, náusea, vômitos, alteração do metabolismo ósseo, certa diminuição da velocidade do crescimento, problemas respiratórios e cardíacos;  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco;  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendome a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (    ) Sim (    ) Não  
|Local:                                                             Data:|
|---|
|Nome do paciente:|
|Cartão Nacional de Saúde:|
|Nome do responsável legal:|
|Documento de identificação do responsável<br>legal:|  
<!-- Start of picture text -->
_____________________________________<br>Assinatura do paciente ou do responsável<br>legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
Observação: Este Termo é obrigatório ao se solicitar o fornecimento de mesilato de imatinibe e deverá ser preenchido em duas vias: uma será arquivada no prontuário, e a outra, entregue ao usuário ou a seu responsável legal.  
Nota: O mesilato de imatinibe é comprado pelo Ministério da Saúde e fornecido pelas Secretarias Estaduais de Saúde aos hospitais credenciados no SUS e habilitados em Oncologia.

---

