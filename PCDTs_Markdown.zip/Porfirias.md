<!-- METADADOS: doenca: Porfirias | secao: Geral -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS  Nº 21, DE 01 DE SETEMBRO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Porfirias.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE, no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre as Porfirias no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 955/2024 e o Relatório de Recomendação nº 958, de 12/2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas das Porfirias.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral das Porfirias, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou  
eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento das Porfirias.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Porfirias | secao: Geral -->
1  
**ANEXO PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS DAS PORFIRIAS**

---

<!-- METADADOS: doenca: Porfirias | secao: Geral -->
As porfirias constituem um conjunto de doenças metabólicas raras, herdadas ou adquiridas, causadas por deficiências de enzimas envolvidas na biossíntese do heme, que resultam no acúmulo de precursores do heme ou de porfirinas em diferentes tecidos<sup>1</sup> .  
O heme está envolvido em diversos processos celulares, como: conferir à hemoglobina e à mioglobina a capacidade de transportar oxigênio<sup>2</sup> ; transporte de elétrons, geração de energia e transformação química nos citocromos; ativação ou inativação do peróxido de hidrogênio nas peroxidases e catalases, respectivamente; catalisação da oxidação do triptofano na triptofano pirrolase, além de papéis em sistemas enzimáticos, como ciclooxigenase e óxido nítrico sintase<sup>3</sup> .  
Embora a biossíntese do heme esteja presente em todos os tipos de células, a maior parte (80%) é produzida na medula óssea, atendendo aos requisitos de hemoglobinização dos eritrócitos. O heme sintetizado no fígado (20%) é utilizado nos citocromos P450, que oxidam diversas substâncias, incluindo fármacos, esteroides endógenos, vitaminas, ácidos graxos e prostaglandinas<sup>1</sup> .  
Oito enzimas estão envolvidas na síntese de heme: ácido delta-aminolevulínico sintase (ALAS1/ALAS2), ácido deltaaminolevulínico desidratase (ALAD), porfobilinogênio desaminase (PBGD), uroporfirinogênio III sintase (UROS), uroporfirinogênio descarboxilase (UROD); coproporfirinogênio oxidase (CPOX), protoporfirinogênio oxidase (PPO) e ferroquelatase (FECH) ( **Figura 1** ). Com exceção da Protoporfiria Eritropoiética ligada ao X (PLX), que é causada pelo aumento da atividade de ALAS2, todas as porfirias são causadas pela diminuição da atividade de uma das enzimas da via<sup>4</sup> . Embora existam oito enzimas envolvidas na biossíntese do heme, já foram descritos dez tipos de porfiria. A harderoporfiria é uma forma variante da coproporfiria hereditária (CPH), extremamente rara, apresentando-se predominantemente na primeira infância, principalmente com anormalidades hematológicas. A origem dessa forma é uma variante genética bialélica disfuncional ou um alelo nulo no éxon 6 do gene CPOX<sup>5</sup> . Do mesmo modo, a porfiria hepatoeritropoiética (PHE) constitui uma forma bialélica da porfiria cutânea tardia (PCT)<sup>6</sup> .  
2  
**Figura 1.** Biossíntese de heme  
<!-- Start of picture text -->
MITOCONDRIA CITOSOL<br>Glicina + Acido delta-<br>a > . oe ——->  Porfobilinogénio<br>Succinil-CoA MASAI aminolevulinico (law ]<br>’ na ‘=<br>fe Hidroximetilbilano<br>HEME<br>] FeCH is enaimaticaEtapa n3o<br>Protoporfirina IX Uroporfirinogénio III Uroporfirinogénio |<br>= |__urop_ |<br>[| (on— | roi |<br>Protoporfirinogénio IX © <—————_ Coproporfirinogénio 111 Coproporfirinogénio |<br><!-- End of picture text -->  
Fonte: autoria própria.  
Através da atividade de oito enzimas (destaque cinza), Succinil-CoA e glicina são convertidos em heme, que é transportado para fora da mitocôndria e usado para a formação das hemoproteínas. As porfirias (destaque roxo) são causadas por alterações na atividade dessas enzimas, como resultado do acúmulo dos precursores de heme e porfirinas em diferentes tecidos. No fígado, o heme regula a ALAS1 por meio de feedback negativo. A isoforma ALAS2 é específica para eritrócitos. ALAS, ácido delta-aminolevulínico sintase; PLX, Protoporfiria Eritropoiética ligada ao X; ALAD, ácido delta-aminolevulínico desidratase; PALAD, porfiria por deficiência de ácido delta-aminolevulínico desidratase; PBGD, porfobilinogênio desaminase; PAI, porfiria aguda intermitente; UROS, uroporfirinogênio III sintase; PEC, porfiria eritropoiética congênita; UROD, uroporfirinogênio descarboxilase; PCT, porfiria cutânea tardia; PHE, porfiria hepatoeritropoiética;  CPOX, coproporfirinogênio oxidase; CPH, coproporfiria hereditária;  PPOX, protoporfirinogênio oxidase; PV, porfiria variegata; FECH, ferrochelatase; PPE, protoporfiria eritropoiética.  
Além do local em que há a deficiência enzimática (fígado ou eritrócito), as características químicas das substâncias que se acumulam são determinantes para as características clínicas das diferentes porfirias. Quando o bloqueio da via leva ao acúmulo de ácido delta-aminolevulínico (ALA) e porfobilinogênio (PBG), conhecidos como precursores de porfirinas, os sintomas são neuroviscerais, dando origem às porfirias hepáticas agudas. Já o acúmulo de porfirinas leva, especialmente, a manifestações cutâneas<sup>5</sup> . O **Quadro 1** resume as principais características dos diferentes tipos de porfirias, classificadas em três grupos: porfirias hepáticas agudas, porfirias eritropoiéticas cutâneas e porfirias hepáticas cutâneas.  
3  
**<u>Quadro 1.</u>** Principais características das porfirias  
|**Grupo**|**Porfiria**|**Enzima**<sup>**4,5**</sup><br>|**Gene**<sup>**4,7**</sup>|**Herança**<br>**genética**<sup>**4,7**</sup>|**Frequência**<sup>**4,8-10**</sup>|**Apresentação**<br>**clínica**<sup>**4,5**</sup>|**Início usual dos**<br>**sintomas**<sup>**4,6,7,11-16**</sup>|
|---|---|---|---|---|---|---|---|
||Porfiria por deficiência de ácido<br>delta-aminolevulínico desidratase<br>(PALAD)|Ácido delta-<br>aminolevulínico<br>desidratase(ALAD)|_ALAD_|AR|Extremamente rara (10<br>casos descritos no<br>mundo)|Neurovisceral aguda|Infância ou juventude|
|Porfirias|Porfiria aguda intermitente (PAI)|Porfobilinogênio<br>desaminase(PBGD)|_HMBS_|AD|0,13:1.000.000<sup>b</sup>|Neurovisceral aguda|3ª-4ª década de vida|
|hepáticas<br>agudas|Coproporfiria hereditária (CPH)|Coproporfirinogênio<br>oxidase (CPOX)|_CPOX_|AD|0,02: 1.000.000<sup>b</sup>|Neurovisceral aguda<br>e cutânea|Os ataques agudos<br>são mais frequentes<br>em mulheres entre 16<br>|
||Porfiria variegata (PV)|Protoporfirinogênio<br>oxidase (PPOX)|_PPOX_|AD|0,08:1.000.000<sup>b</sup>|Neurovisceral aguda<br>e cutânea|e 45 anos de idade<br>(os anos de ovulação<br>ativa)|
||Protoporfiria Eritropoiética ligada<br>ao X (PLX)|Ácido delta-<br>aminolevulínico sintase 2<br>(ALAS2)|_ALAS2_|Ligada ao<br>X|<1:1.000 000<sup>c</sup>|Cutânea e raramente<br>hepática|Primeira infância ou<br>infância|
|Porfirias<br>eritropoiéticas<br>cutâneas|Porfiria eritropoiética congênita<br>(PEC)|Uroporfirinogênio III<br>sintase (UROS)|_UROS_<br>_GATA1_<sup>_a_</sup>|AR<br>Ligada ao<br>X|<1:1.000 000<sup>c</sup>|Cutânea e anemia<br>hemolítica|Nascimento ou<br>primeira infância|
||Protoporfiria eritropoiética (PPE)|Ferrochelatase (FECH)|_FECH_|AR|0,12:1.000.000<sup>b</sup>|Cutânea e raramente<br>hepática|Primeira infância ou<br>infância|
|Porfirias|Porfiria cutânea tardia(PCT)|||AD|2–5:1.000.000<sup>b</sup>|Cutânea|4ª-5ª década de vida|
|<br>hepáticas<br>cutâneas|Porfiria hepatoeritropoiética<br>(PHE)|Uroporfirinogênio<br>descarboxilase (UROD)|_UROD_|AR|Extremamente rara<br>(<100 casos descritos no<br>mundo)|Cutânea|Primeira infância|  
> a Variantes patogênicas no gene _GATA1_ representam aproximadamente 1% dos casos de PEC. B Incidência. C Prevalência. AR, autossômica recessiva; AD, autossômica dominante.  
Fonte: Adpatado de Erwin _et al_ . (2021), Stölzel _et al_ . (2019), Erwin _et al_ . (2013), Rudnick _et al_ . (2013), Balwani _et al_ . (2013), Rudnick _et al_ . (2013), Sardh _et al_ . (2005), Wang _et al_ . (2012), Singal _et al_ . (2013), Balwani _et al_ . (2012), Elder _et al_ . (2013), Orphanet (2021) e Orphanet (2021)<sup>4-16</sup> .  
4  
As **porfirias hepáticas agudas** incluem a porfiria por deficiência de ácido delta-aminolevulínico desidratase (ALAD), a porfiria aguda intermitente (PAI), a coproporfiria hereditária (CPH) e a porfiria variegata (PV). A PALAD é considerada extremamente rara, com poucos casos descritos em todo o mundo<sup>4</sup> . Um registro brasileiro<sup>17</sup> identificou que a PAI é o tipo mais frequente no país, representando 59,4% dos casos de porfiria. Já as CPH, PV e PALAD correspondem a, respectivamente, 4,3%, 2,5% e 0,4% dos pacientes brasileiros<sup>18</sup> . Essas doenças são doenças clinicamente heterogêneas e com potencial risco de morte.  
De forma geral, as porfirias hepáticas agudas não se manifestam antes da puberdade. Apesar de afetar ambos os sexos, sua prevalência é maior entre mulheres jovens<sup>19</sup> . As mulheres podem sofrer com ataques mensais, relacionados ao ciclo menstrual. Os ataques cíclicos têm início geralmente na fase lútea, quando os níveis de progesterona estão mais elevados, e costumam terminar com o início da menstruação<sup>5,20</sup> . Como os sintomas podem ser inespecíficos, as porfirias hepáticas agudas são frequentemente confundidas com outras doenças mais comuns, como infecção urinária, gastroenterocolite, endometriose e doença inflamatória pélvica, sendo tratadas inadequadamente<sup>20</sup> .  
Já as **porfirias eritropoiéticas cutâneas** são caracterizadas principalmente pela fotossensibilidade cutânea, devido ao acúmulo de porfirinas. As lesões cutâneas na PLX e na PPE não se apresentam bolhosas, enquanto a PEC<sup>21</sup> caracteriza-se pela formação de bolhas em áreas expostas ao sol ou à luz<sup>4</sup> . De acordo com um registro brasileiro, as protoporfirias eritropoiéticas representam 4,1% dos casos de porfiria no Brasil, embora não se saiba se essa frequência inclui apenas PPE ou uma combinação de PPE e PLX. A PEC corresponde a 1,1% dos casos<sup>18</sup> . A PPE possui penetrância completa, mas expressividade variável, e afeta igualmente homens e mulheres. Na PLX, devido à herança ligada ao X, todos os homens são afetados e, frequentemente, de forma grave. Em contrapartida, o fenótipo nas mulheres pode variar de assintomático a grave<sup>22</sup> .  
A fotossensibilidade cutânea na PPE e na PLX é clinicamente indistinguível e se manifesta com dor, queimação, eritema e edema. Podem ocorrer petéquias ou, menos comumente, púrpura. As alterações crônicas podem incluir onicólise, hiperqueratose (especialmente no dorso das mãos e nas articulações dos dedos) e cicatrizes leves. A hepatopatia, devido ao acúmulo expressivo de protoporfirina IX, é uma complicação potencialmente fatal de qualquer protoporfiria<sup>1</sup> . Sabe-se que até 5% dos pacientes com PPE podem desenvolver doença hepática mais avançada<sup>1,11</sup> . No entanto, é desafiador determinar com precisão se a doença hepática ocorre com a mesma frequência e gravidade na PLX, uma vez que sua história natural não é tão conhecida<sup>6</sup> . Pacientes com hepatopatia protoporfírica grave podem desenvolver neuropatia motora grave semelhante à observada nas porfirias agudas. Cálculos biliares são comuns e podem exigir colecistectomia. Devido à impossibilidade de exposição ao sol, pacientes com protoporfirias são propensos à deficiência de vitamina D<sup>1,11</sup> .  
Na PEC, a coloração avermelhada da urina é comumente considerada o primeiro sinal clínico, ocorrendo frequentemente na primeira infância<sup>4</sup> . Este tipo de porfiria é caracterizado por fotossensibilidade crônica grave com anemia hemolítica. As lesões cutâneas são bolhosas e semelhantes às encontradas nas porfirias hepáticas cutâneas, no entanto, devido aos níveis de porfirina bastante elevados, as lesões de pacientes com PEC costumam ser mais graves<sup>1</sup> . As bolhas estão sujeitas à ruptura e apresentam um alto risco de infecção. Podem ocorrer deformidades, com desfiguração das características faciais e dos dedos. A anemia hemolítica leve a grave é comum, podendo levar à dependência de transfusão<sup>1,4,7</sup> . Outras manifestações clínicas da PEC são: úlceras e cicatrizes na córnea, que podem evoluir para cegueira; manchas marrom-avermelhadas nos dentes devido à deposição de porfirinas (eritrodontia); perda de massa óssea; hiperplasia da medula óssea; e deficiência de vitamina D, assim como nas protoporfirias, devido à impossibilidade de exposição ao sol<sup>7</sup> .  
As **porfirias hepáticas cutâneas** incluem porfiria cutânea tardia (PCT) e porfiria hepatoeritropoiética (PHE). Um registro brasileiro mostram que a PCT é a segunda porfiria mais comum no Brasil, representando 22,1% dos casos<sup>18</sup> , enquanto a PHE  
5  
aparece de forma muito menos expressiva, sendo apenas 0,9% dos casos. Apesar da PCT aparentemente afetar mais homens ao redor do mundo<sup>12</sup> , os registros mostraram uma maior frequência para mulheres (68% dos casos)<sup>18</sup> . Em contrapartida, a PHE parece afetar igualmente ambos os sexos<sup>6</sup> .  
A PCT é originada pela inibição da enzima UROD, levando a um aumento acentuado de uroporfirinas e porfirinas heptacarboxil no plasma e na urina, em conjunto com quantidades menores de coproporfirina. Pode ser dividida em três tipos: adquirida ou esporádica (tipo I), na qual o déficit de atividade UROD é restrito ao fígado; familiar ou hereditária (tipo II), na qual o déficit de atividade UROD é cerca de 50% em todos os tecidos por uma variante genética no gene _UROD_ ; e um tipo familiar rara (tipo III), sem variante genética da enzima afetada, em que o déficit de atividade UROD é também restrito ao fígado, como no tipo I, mas com familiares acometidos<sup>23</sup> . Quando herdada, a PCT possui penetrância incompleta<sup>1</sup> . Aproximadamente 80% dos pacientes com PCT apresentam o tipo I e menos de 5% apresentam o tipo III<sup>23</sup> .  
Os fatores precipitantes conhecidos que induzem a PCT são o consumo excessivo de álcool, infecção pelo vírus da hepatite C, infecção pelo vírus da imunodeficiência humana (HIV), ingestão de estrogênio, doença renal avançada e tabagismo<sup>23,24</sup> . A hemocromatose hereditária é considerada um fator hereditário que pode predispor a PCT, contribuindo para a formação de um inibidor da enzima UROD<sup>5,23</sup> . O ferro promove a formação de espécies reativas de oxigênio que oxidam o uroporfirinogênio, substrato da enzima UROD, gerando uroporfirinas e uroporfometileno. Este último inibe a atividade enzimática de UROD devido à sua capacidade competitiva de adaptação ao sítio catalítico da enzima<sup>23</sup> . A natureza rara da PHE torna difícil a identificação de fatores precipitantes para a doença. Acredita-se, no entanto, que sejam os mesmos da PCT<sup>6</sup> .  
Clinicamente, os tipos I e II da PCT são indistinguíveis e as lesões cutâneas são bolhosas, semelhantes às da PEC<sup>24</sup> . As bolhas formadas pela exposição à luz solar se rompem facilmente, tornando-as propensas à infecção. Ocorrem frequentemente a formação de crostas e cicatrizes na pele, _milium_ , hipertricose e hiperpigmentação facial. Não há sintomas neurológicos na PCT<sup>1</sup> . O quadro clínico na PHE também é semelhante ao da PEC, incluindo anemia hemolítica, fototoxicidade grave com bolhas, cicatrizes, eritrodontia e urina de cor avermelhada<sup>4,24</sup> .  
Independentemente do tipo de porfiria, a identificação de fatores de risco, sinais e sintomas em estágio inicial, assim como o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde (APS) um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer critérios diagnósticos, de tratamento e de monitoramento de pacientes com porfirias no âmbito do Sistema Único de Saúde (SUS).

---

<!-- METADADOS: doenca: Porfirias | secao: Geral -->
- E80.0: Porfiria hereditária eritropoiética;  
- E80.1: Porfiria cutânea tardia;  
- E80.2: Outras porfirias.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
6  
As porfirias são diagnosticadas e diferenciadas por padrões bioquímicos específicos de porfirinas e precursores de porfirina elevados na urina, fezes e sangue<sup>5</sup> . A solicitação de exames laboratoriais para investigação deve ser baseada no quadro clínico, história médica e familiar e exame físico abrangente<sup>26</sup> . Em geral, as principais manifestações clínicas das porfirias são neurológicas, geralmente na forma de ataques neuroviscerais agudos, ou cutâneas, resultantes da fototoxicidade (fotossensibilidade cutânea com ou sem bolhas)<sup>26,27</sup> .  
Para o diagnóstico da doença, a rede de atenção à saúde inclui a pesquisa de PBG na urina, a dosagem de ALA na urina e a dosagem de porfirinas na urina. Além disso, a análise quantitativa de PBG urinário para confirmação diagnóstica ou prognóstico de porfirias hepáticas agudas foi incorporada ao SUS conforme Portaria SECTICS/MS nº 17/2024<sup>28</sup> . Adicionalmente, a pesquisa de coproporfirina na urina, inicialmente destinada à detecção de metais pesados, principalmente chumbo, pode ser empregada para o diagnóstico diferencial em situações clínicas suspeitas tanto de intoxicação por chumbo quanto de porfirias agudas. Tais exames, bem como outros testes específicos para o diagnóstico de porfirias, devem ser solicitados conforme a disponibilidade no serviço de saúde. Exames gerais e complementares podem ser necessários de acordo com a evolução do quadro clínico.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Quando sintomáticas, esse grupo de porfirias caracterizam-se por ataques neuroviscerais agudos, que envolvem dor abdominal, náusea, vômito, constipação, febre, distúrbios da sudorese, polineuropatia, taquicardia, arritmia cardíaca, hipotensão postural ou hipertensão arterial, hiponatremia, encefalopatia aguda, síndrome de encefalopatia posterior reversível, convulsões, estado de mal epiléptico, vasoespasmo e vasoconstrição cerebral, psicose aguda e insônia<sup>19</sup> . Os episódios são extremamente dolorosos, e o nível de dor pode ser descrito pelos pacientes como "não compatível com a vida"<sup>29</sup> . Os ataques agudos podem ocorrer de forma isolada, no entanto, aproximadamente 5% dos pacientes sintomáticos os apresentam de forma recorrente (mais que 4 vezes por ano)<sup>29</sup> . Todos os pacientes com porfiria hepática aguda, especialmente aqueles que sofrem ataques frequentes, são particularmente susceptíveis a complicações crônicas, que incluem hipertensão, dor crônica, disfunção autonômica, insuficiência renal e carcinoma hepatocelular<sup>4</sup> .  
A penetrância e a gravidade são particularmente influenciados por uma combinação de fatores ambientais e fisiológicos<sup>4</sup> . Diversos fatores precipitantes podem desencadear ataques agudos, incluindo bebidas alcoólicas, medicamentos porfirinogênicos (considerados precipitantes de crises em pessoas com porfirias agudas), jejum prolongado, dietas restritivas com baixo teor de carboidratos, incluindo dieta Atkins, tabagismo, agentes anestésicos, exercícios físicos extenuantes, estresse emocional, gravidez e puerpério<sup>19</sup> . A PAI e PALAD são os únicos tipos de porfiria cuja apresentação clássica não envolve fototoxicidade cutânea, uma vez que as deficiências enzimáticas ocorrem antes da formação de porfirinas. No entanto, sintomas cutâneos podem ocorrer em pacientes com PAI e doença renal avançada<sup>29</sup> . Na PV e na CPH, bolhas cutâneas crônicas, _milium_ , áreas pigmentadas e cicatrizes podem ocorrer na pele exposta ao sol<sup>20</sup> . A urina de cor escura, marrom-avermelhada ou arroxeada, característica clínica que origina o termo _porfirio_ , pode não estar presente na urina recém-eliminada em pacientes com PAI ou PALAD, pois os precursores do heme são incolores. Só quando há exposição à luz em temperatura ambiente é que a urina se torna escura pela formação de porfobilina. Uma outra alteração na coloração da urina ocorre devido à pigmentação intrínseca das porfirinas, ocorrendo em CPH e PV, na urina recém eliminada durante ataques agudos<sup>30</sup> .  
Considera-se porfiria aguda em pacientes com sintomas abdominais, neurológicos, psiquiátricos e cardiovasculares, quando diagnósticos alternativos são desconsiderados após a avaliação clínica inicial<sup>5,31</sup> . Durante as crises porfíricas, a dor  
7  
abdominal aguda grave é o sintoma mais comum, sendo difusa, inespecífica e refratária a analgésicos comuns. Pode ocorrer náusea, vômito, constipação ou diarreia. Diferentemente de outras condições agudas no abdômen, o exame físico abdominal é geralmente normal<sup>5,30</sup> . A suspeita diagnóstica de porfiria aguda é intensificada pela presença de sintomas adicionais, como urina avermelhada, marrom-avermelhada ou roxa, hipertensão, taquicardia, hiponatremia, fraqueza muscular proximal, convulsões ou dor associada com a fase luteínica do ciclo menstrual. Ainda assim, essas observações são inespecíficas e não devem ser consideradas suficientes para o diagnóstico<sup>31,32</sup> .  
Os ataques agudos de porfiria podem ser investigados pela dosagem urinária quantitativa de PBG e ALA (testes de primeira linha) e dosagem urinária de porfirinas totais e frações (testes de segunda linha), com resultados normalizados para creatinina urinária medida na mesma amostra<sup>20,33</sup> . A dosagem de porfirinas totais amplia a sensibilidade dos testes primários, visto que os níveis de PBG e ALA frequentemente se elevam menos e retornam aos limites normais de maneira mais rápida, especialmente em casos de PV e CPH, enquanto o aumento das porfirinas na urina tende a ser mais duradouro<sup>31</sup> .  
O diagnóstico diferencial das porfirias agudas é desafiador devido ao seu caráter raro, aos sintomas e apresentações inespecíficas, como dor abdominal aguda ou recorrente, e à solicitação e interpretação inadequada dos testes laboratoriais<sup>31</sup> . A **Figura 2** destaca as principais diferenças clínicas e laboratoriais entre as quatro porfirias hepáticas agudas.  
**Figura 2.** Diagnóstico diferencial das Porfirias Hepáticas agudas.  
<!-- Start of picture text -->
Tivo) Sintomas, DosagemdePBG  DosagemdeALA _Porfirinasurina  na plasma/eritrécitosPorfirinas no Porfirinas;  nas fezes<br>PorfiriaPalpeaaiaypor P PBG urinario Porfirina Porfirinas aumentada<br>catrtioaltyien ae ie ligeiramente aumentado especialmente protoporfirina IX aumento<br>desidratase (PALAD) ao aumentado coproporfirina Ill eritrocitaria<br>Porfirias aguda Pererasintom PBGurinrio | ALAurinario | aumentadPorfirin a ss, Normal ou leve<br>intermitente stitial aumentado | aumentado | especialmente aumento<br>judo uroporfirina |<br>TECoproporfiriaCTME agudoselescescutaneasbaht aecialeybolhosas }| PBGurinarioaumentado || ALAurinarioaumentado | aumentadas.SsPeciaimenneon aumentadas,ciated:pecaine?<br>solani ara coproporfirina Il coproporfirina Ill<br>pacientes)<br>Sintoma Porfirinas<br>eimmomss orfirin: aumentadas, sendoa<br>SOULE cutdneas bolhosas | aumentado sSmroporfrina mi | Co™UM pico em torno sca ected<br>cerca de 50% dos GEPREaiin de 626 nm acter]<br>pacientes)<br><!-- End of picture text -->  
Fonte: Anderson _et al._ (2021), Woolf _et al._ (2016), Brito Avô _et al._ (2023), Stein _et al._ (2013) e Souza _et al._ (2020)<sup>19,31-34</sup> .  
As amostras de urina para testes bioquímicos devem ser coletadas, preferencialmente, durante ou logo após uma suspeita de ataque agudo, quando os níveis de PBG, ALA e porfirinas estão mais elevados. Ressalta-se que a maioria dos estudos descreve sobre o uso de uma amostra de urina aleatória e não de 24 horas. A amostra de urina deve ser refrigerada a 4 ºC desde seu envio ao laboratório até o momento da análise e mantida ao abrigo de luz (utilizando frasco âmbar, opaco ou protegido por papel  
8  
alumínio), a fim de evitar resultados falso-negativos, uma vez que a luz estimula a isomerização não enzimática e a conversão de PBG e ALA em porfirinas e outros metabólitos. Além disso, a amostra deve ser analisada idealmente em até 24 horas<sup>35,36</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
As porfirias eritropoiéticas e hepáticas cutâneas se diferenciam das porfirias hepáticas agudas pela ausência de sintomas neuroviscerais e presença de fotossensibilidade, acompanhada ou não de bolhas<sup>31</sup> . Em todas elas, os locais comuns de envolvimento são o dorso da mão e a face, além de outras áreas frequentemente expostas ao sol<sup>5,37,38</sup> .  
A PPE é causada por uma deficiência parcial do gene _FECH_ , que catalisa a etapa final da síntese do heme, levando, principalmente, ao aumento dos níveis de protoporfirina IX (PPIX) livre de metal nos eritrócitos. A PLX é caracterizada por variantes genéticas hipermórficas de ganho de função na enzima ALAS2. O aumento da atividade enzimática de ALAS2 ocasiona o acúmulo eritrocitário de PPIX livre de metal e ligada ao zinco. O diagnóstico diferencial de PPE e PLX é um desafio, uma vez que ambas compartilham características clínicas e bioquímicas, como fotossensibilidade aguda, geralmente grave, e aumento de protoporfirina total<sup>5</sup> .  
O diagnóstico de PPE e PLX pode ser baseado no aumento de protoporfirinas no eritrócito. A porcentagem de PPIX livre de metal é tipicamente superior a 90% na PPE e de 50% a 85% na PLX, em relação à zinco PPIX. As porfirinas podem estar aumentadas ou normais no plasma, enquanto geralmente estão normais na urina e nas fezes<sup>38</sup> . No entanto, com a deterioração da função hepática, a excreção urinária de coproporfirina pode aumentar<sup>5</sup> .  
A PEC é caracterizada pela fotossensibilidade grave com lesões cutâneas bolhosas em áreas expostas ao sol, que, quando infectadas, levam à fotomutilação progressiva. Na pele ainda pode haver espessamento, aumento da friabilidade, hipo e hiperpigmentação, além de hipertricose da face e extremidades<sup>39</sup> . A maioria dos pacientes com PEC apresenta urina de cor vermelha, sendo esse um dos primeiros sinais da doença, que costuma se manifestar ao nascimento ou na primeira infância<sup>5</sup> .  
A anemia hemolítica é uma manifestação clínica comum na PEC com um amplo espectro de gravidade. A esplenomegalia secundária à anemia hemolítica pode estar presente, e, além de piorar o quadro de anemia, pode levar à leucopenia e trombocitopenia. Outras manifestações clínicas incluem: úlceras e cicatrizes na córnea, descoloração marrom-avermelhada dos dentes (eritrodontia), osteopenia e expansão da medula óssea. Casos graves podem se manifestar através da hidropisia fetal não imune no útero. Em relação às manifestações bioquímicas, os indivíduos apresentam níveis marcadamente elevados de uroporfirina I e coproporfirina I na urina, eritrócitos ou líquido amniótico, bem como altas concentrações fecais de coproporfirina I<sup>39</sup> .  
A PCT, por sua vez, se apresenta como fotossensibilidade com lesões cutâneas bolhosas. As manifestações na pele também envolvem uma maior fragilidade, levando à descamação mesmo em resposta a traumas muito leves, e atrasos na cicatrização de feridas em áreas expostas à luz solar. Raramente, os olhos podem ser afetados por complicações como necrose escleral, cicatrizes na córnea e conjuntiva e ectrópio<sup>37</sup> .  
A maioria dos pacientes com PCT apresenta sobrecarga de ferro leve a moderada e elevação das enzimas hepáticas. O perfil bioquímico inclui elevação das porfirinas plasmáticas e urinárias com predominância de uroporfirina e heptacarboxilporfirina. As porfirinas fecais geralmente permanecem normais ou levemente aumentadas, mas, em alguns casos, podem apresentar elevação acentuada. A concentração de ALA é normal ou levemente aumentada e a de PBG é normal, auxiliando no diagnóstico diferencial de porfirias hepáticas agudas com manifestações cutâneas (PV ou CPH)<sup>37</sup> .  
9  
A PHE, uma outra porfiria hepática cutânea, tende a manifestar sintomas cutâneos de forma mais precoce e intensa quando comparada à PCT, tendendo a se assemelhar à PEC. Anemia leve associada à hemólise e hepatoesplenomegalia, assim como alterações leves e inespecíficas na função hepática são comuns. O perfil das porfirinas se assemelha à PCT, mas com aumento expressivo de zinco PPIX eritrocitária<sup>27</sup> . A **Figura 3** apresenta as principais diferenças clínicas e laboratoriais das porfirias cutâneas.  
**Figura 3.** Diagnóstico diferencial das porfirias cutâneas. PPIX: protoporfirina IX.  
<!-- Start of picture text -->
Tipo Sintomas Dosagemdeaa Dosagemdemin _Porfirinasaaa  na eensPorfirinas no Porfirinasnas fezes<br>itrocito (PPIX<br>Protoporfiria r ciescutan protoporfirinas n<br>Eritropoiética‘ao X (PLX)ligada sights: alles oe Normal Normal Normal. metalNo e plasma,ligadaas porfirinasao zinco).livre de Normat<br>_— podem estar normais ou<br>Porfirina; No eritrécito,a:<br>ereee aa Normal Normal sealbeslinehis porfirinasjumentada:este 2 orfirinasae<br>congénita (PEC) (uroporfirinaproporfirina| ¢ D coproporfirinaey I) aumentad<br>umentode<br>Protoporfiria raramente Normal Normal Normal bales mle ce Normal<br>eritropoiética (PPE) Eee metal). No plasma. a<br>Normal ou. aumentada: Ne, pert aos Doe ene<br>tardia (PCT) olhosas grave aumlev e mententada Normat heptacarboxilport(uroporfirinapales heptacarboxilporfirin{uroporfirina<br>Porfiria Porfirinas<br>hepatoeritropoiética sumentadas | No eritrdcito, aumento<br>reptacarboxilporf gada ao zinco<br>(PHE) Normal Normat (uroporfirina expressivo de PPIX<br><!-- End of picture text -->  
Fonte: Singal (2019), Dickey _et al._ (2023), Stolzel _et al._ (2019), Anderson _et al._ (2021), Erwin _et al._ (2019) e Ramanujam _et al._ (2015)<sup>5,27,31,37-39</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Entre os dez tipos de porfirias, há aquelas com herança autossômica dominante, autossômica recessiva e ligada ao cromossomo X ( **Quadro 1** )<sup>24</sup> . O diagnóstico das porfirias é baseado no quadro clínico e testes bioquímicos com amostras apropriadas, preferencialmente durante ou logo após o início dos sintomas<sup>34,40,41</sup> . Os testes genéticos são úteis para confirmação diagnóstica, nos casos em que a caracterização completa do quadro não é possível por outros recursos; avaliação prognóstica; e para identificação de familiares pré-sintomáticos, para que possam ser aconselhados sobre como reduzir o risco de ataques agudos, minimizando, desta forma, complicações da doença com medidas preventivas. No entanto, neste último caso, é importante ressaltar que a baixa penetrância clínica nas porfirias autossômicas dominantes significa que a identificação de uma mutação não representa necessariamente o desenvolvimento de uma porfiria ativa<sup>41</sup> .  
10  
O sequenciamento de Sanger e a análise por _Multiplex Ligation-dependent Probe Amplification_ (MLPA)<sup>13,40</sup> correspondem aos métodos utilizados para o diagnóstico molecular das porfirias e disponíveis no SUS. Na necessidade de tais exames, sugere-se priorizar o mapeamento dos nove principais genes de interesse ( **Quadro 1** ).  
Os serviços devem disponibilizar aos pacientes com porfiria e seus familiares aconselhamento genético, com um profissional devidamente habilitado na área, para que sejam orientados sobre a causa da doença, suas características e chances de recorrência em familiares e opções reprodutivas<sup>40,42</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
As manifestações clínicas das porfirias hepáticas agudas podem assemelhar-se a outras condições gastrointestinais agudas, neurológicas/neuropsiquiátricas, ginecológicas ou abdominais. Além disso, ataques agudos de porfiria podem lembrar emergências abdominais, como apendicite ou colecistite, levando a cirurgias desnecessárias e ao atraso no diagnóstico definitivo. Em casos suspeitos de porfiria, o tratamento deve ser iniciado imediatamente, até que se obtenha um diagnóstico conclusivo, a fim de evitar maiores complicações<sup>19,43</sup> .  
Em pacientes com neuropatia periférica grave nas porfirias agudas, o diagnóstico diferencial mais importante é a síndrome de Guillain-Barré, seguida por polineuropatia desmielinizante inflamatória crônica e intoxicação por chumbo, arsênio ou tálio. Quando há sinais de encefalopatia difusa, devem ser excluídas encefalite infecciosa e autoimune, trombose venosa sinusal e encefalopatia metabólica<sup>44</sup> . Na síndrome de Guillain-Barré, sintomas como neuropatia e paralisia da musculatura assemelhamse aos ataques graves de porfiria. Porém, os níveis de PBG e ALA apresentam-se normais<sup>33</sup> . Além disso, a fraqueza muscular na síndrome de Guillain-Barré é, geralmente, ascendente, com alterações eletroneuromiográficas comumente desmielinizantes motoras e sensitivas. Nas porfirias agudas, a fraqueza é geralmente descendente, com alterações eletroneuromiográficas comumente axonais<sup>45</sup> .  
A enzima ALAD pode ser inibida na intoxicação por chumbo, um metal pesado que ocasiona neuropatia idêntica à observada na porfiria<sup>46</sup> . Os pacientes com PALAD ou intoxicação por chumbo têm um aumento em mais de dez vezes do nível de ALA urinário, na ausência de um aumento significativo de PBG<sup>5</sup> . Em geral, uma história de exposição ao chumbo e níveis aumentados do metal no sangue e na urina esclarecem o diagnóstico<sup>5,46</sup> . A tirosinemia tipo 1 também pode causar o aumento de ALA, com sintomas semelhantes às porfirias agudas<sup>5</sup> . Salienta-se, no entanto, que a tirosinemia geralmente se manifesta na infância, enquanto as porfirias agudas costumam se manifestar após a puberdade<sup>34</sup> .  
Nas crises porfíricas pré-menstruais, os sintomas podem ser confundidos com dor de etiologia ginecológica, como a endometriose<sup>43,47</sup> . Os sintomas neuropsiquiátricos dos ataques porfíricos podem levar à suspeita de transtornos psiquiátricos primários, encefalite autoimune, tumor cerebral e outros distúrbios neurometabólicos hereditários. A coloração alterada da urina pode ser confundida com alterações causadas por medicamentos, colúria, litíase renal e infecção do trato urinário<sup>19</sup> .  
É possível que porfirias com elevação de zinco PPIX sejam confundidas com deficiência de ferro, intoxicação por chumbo ou anemia hemolítica, pois todas podem aumentar esse marcador<sup>5</sup> . A presença de leves alterações na protoporfirina, principalmente zinco PPIX, ou um aumento menor que três vezes o limite superior normal, não é suficiente para o diagnóstico de porfiria<sup>38</sup> .  
Nas porfirias cutâneas, a origem das lesões pode ser confundida com epidermólise bolhosa congênita, distúrbios bolhosos autoimunes, eritema multiforme, necrólise epidérmica tóxica, pênfigo paraneoplásico, penfigoide bolhoso, vasculite sistêmica e síndrome da pele escaldada estafilocócica<sup>19</sup> .  
11

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Serão incluídos pacientes com suspeita ou diagnóstico das porfirias hepáticas agudas, porfirias eritropoiéticas cutâneas e porfirias hepáticas cutâneas.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Serão excluídos deste Protocolo pacientes com condições clínicas que mimetizam porfirias, após confirmação diagnóstica.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Quando uma crise aguda de porfiria hepática é diagnosticada, o paciente deve ser tratado o mais precocemente possível<sup>42</sup> . A precisão e a rapidez no diagnóstico de uma crise são de suma importância, uma vez que a demora no tratamento pode ocasionar lesões neurológicas ou óbito. Durante os episódios de crises agudas, o tratamento dos sintomas e das complicações deve ser priorizado, assim como o restabelecimento da homeostase do heme<sup>30,42,48</sup> . Devido ao seu caráter raro e seus sinais e sintomas inespecíficos, o diagnóstico das porfirias é desafiador e pode resultar em atrasos significativos no tratamento, ressaltando a necessidade de profissionais de saúde e a população em geral conhecerem a doença<sup>49</sup> .  
Uma vez diagnosticada, a avaliação da gravidade da crise de porfiria aguda pode auxiliar os profissionais a delimitarem os sintomas e o prognóstico do paciente. Em episódios leves, os pacientes apresentam disautonomia leve, enquanto nos episódios moderados, os sinais incluem disautonomia e hiponatremia, letargia, convulsões ou paralisia flácida, sem necessidade de ventilação mecânica<sup>19</sup> . Contudo, um consenso _Delphi_ internacional sugeriu cautela na classificação dos ataques não as definindo em leves e moderados, por serem extremamente angustiantes para os pacientes e porque os sintomas podem piorar rapidamente, tornando-se graves ou até fatais<sup>50</sup> .  
Nos episódios graves, os pacientes podem apresentar as seguintes manifestações: disautonomia grave e paralisia flácida, paralisia bulbar, necessidade de ventilação mecânica, hiponatremia grave e estupor/coma. Episódios críticos são caracterizados por disautonomia grave, comprometimento motor grave, coma, necessidade de ventilação mecânica prolongada e alto risco de morte. A presença de convulsões refratárias em episódios agudos, neuropatia motora aguda progressiva, hiponatremia grave e distúrbios autonômicos precoces representam sinais de alerta, indicando risco de morte e a necessidade de tratamento em unidade de terapia intensiva<sup>19</sup> . Já o consenso _Delphi_ internacional definiu que um ataque de porfiria aguda grave está associado a uma ou mais das seguintes características: hiponatremia significativa, neuropatia periférica, retenção ou incontinência urinária, envolvimento do sistema nervoso central e arritmias<sup>50</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O tratamento não medicamentoso das porfirias hepáticas agudas envolve a prevenção das manifestações primárias pela retirada de fatores precipitantes, como medicamentos potencialmente nocivos (inseguros), consumo de bebidas alcoólicas,  
12  
tabagismo, restrição calórica (ex, dieta cetogênica e cirurgia bariátrica) e jejum. Em casos de jejum pré-operatório ou préprocedimento, é essencial que seja realizado o monitoramento do período de jejum para segurança do paciente. Além disso, é importante a adoção de práticas seguras, como a manutenção de uma dieta regular e balanceada, vigilância de quadros infecciosos e redução do estresse<sup>13,15,51</sup> .  
Uma alternativa é o transplante hepático<sup>48</sup> , recomendado para pacientes com sintomas intratáveis e para pacientes com doença hepática crônica associada às porfirias agudas<sup>19</sup> . Os níveis urinários de ALA e PBG costumam normalizar após o transplante e também há melhora nos sintomas crônicos<sup>43</sup> . Se o paciente apresentar doença renal terminal secundária às porfirias agudas, o transplante renal é recomendado. A terapia imunossupressora pós-transplante é geralmente bem tolerada<sup>43</sup> .  
Recomenda-se a inclusão de fisioterapia e terapia ocupacional como parte do cuidado de pacientes com porfirias que apresentam fraqueza muscular e/ou paralisia. A fisioterapia intensiva deve ser iniciada o mais precocemente possível para otimizar a recuperação da função<sup>5,32,34</sup> . A terapia ocupacional, por sua vez, desempenha um papel importante no auxílio à conquista da independência e na redução da incapacidade a longo prazo<sup>32</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O tratamento inicial das porfirias agudas inclui a retirada de todos os medicamentos potencialmente nocivos (inseguros) para esses pacientes, assim como outros possíveis fatores precipitantes. A ABRAPO<sup>17</sup> e da _American Porphyria Foundation_ (APF)<sup>52</sup> listam os medicamentos e seus perfis de segurança. Uma lista de medicamentos seguros para uso por pacientes com porfiria hepática aguda, de acordo com pesquisadores brasileiros da Universidade Federal de São Paulo, encontra-se no Apêndice 2<sup>19</sup> .  
O tratamento de suporte geral para corrigir distúrbios eletrolíticos, como hiponatremia e hipomagnesemia, e a abordagem de sintomas como dor, náusea, agitação e ansiedade, convulsões e outros, devem ser iniciados precocemente, utilizando apenas medicamentos considerados seguros para pacientes com porfirias<sup>19,32,38,40</sup> . Para mitigar as dores abdominais, pode-se adotar o uso de medicamentos não porfirinogênicas, como clorpromazina, que simultaneamente podem aliviar outros sintomas associados a descompensação metabólica<sup>20</sup> . Além disso, a analgesia pode ser efetivamente obtida com o uso de opioides, como codeína. Os beta-bloqueadores podem ser empregados para minimizar a hiperatividade adrenérgica, enquanto doses _baixas_ de benzodiazepínicos são seguras para tratar ansiedade e insônia (devendo haver cautela, especialmente no uso prolongado)<sup>19,53</sup> . Se o paciente apresentar convulsões, o tratamento deve ser feito com cautela porque muitos anticonvulsivantes, como carbamazepina e ácido valproico, são contraindicados na porfiria aguda. Sulfato de magnésio, benzodiazepínicos (cautela) e gabapentina são opções consideradas seguras<sup>19,43,53</sup> .  
O tratamento específico envolve hidratação e sobrecarga de glicose<sup>38-40</sup> . A abordagem terapêutica estabelecida para o tratamento inicial dos ataques porfíricos é baseada no mecanismo de regulação da biossíntese do heme. Estudos sugerem que a administração dose-dependente de glicose é capaz de amenizar os ataques agudos ou cessar ataques moderados devido à sua ação regulatória sobre a enzima ALAS1 via inibição do coativador-1α do receptor ativado por proliferadores de peroxissoma gama (PGC-1α), diminuindo a formação de precursores de porfirina<sup>54-56</sup> .  
Embora os estudos disponíveis tenham uma amostra populacional limitada, especialmente devido à raridade de porfirias hepáticas agudas, em geral, demonstram respostas clínicas favoráveis ao uso de glicose. Um estudo realizado em 11 pacientes com porfiria hepática aguda, tratados com infusão intravenosa de aproximadamente 500 mg por 24 horas de glicose, demonstrou que a excreção urinária de precursores de porfirina e porfirinas foi reduzida entre 28 e 99% dos valores iniciais antes da terapia.  
13  
O declínio médio relativo observado foi de 73% para ALA, 85% para PBG e 70% para porfirinas, evidenciando uma resposta bioquímica significativa e detectável entre 24 e 72 horas após a intervenção<sup>57</sup> . A terapia inicia-se com infusão intravenosa e, em seguida, é possível continuar a reposição de glicose em domicílio, procurando-se incrementar aporte calórico com 200 g, por via oral, associada a uma dieta rica em carboidratos<sup>58</sup> .  
A inibição da secreção de gonadotrofina nas porfirias agudas é investigada em pequenos estudos, com uma avaliação da eficácia ainda inconsistente<sup>5</sup> . Alguns autores sugerem o uso de análogos do hormônio liberador de gonadotrofina (GnRH) para ataques recorrentes relacionados ao período perimenstrual em mulheres. Os análogos de GnRH não possuem registro sanitário para essa indicação no Brasil e não foram submetidos à avaliação pela Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) para esta indicação, não sendo recomendados neste Protocolo<sup>59</sup> .  
O controle de ataques agudos porfíricos ainda é possível por meio da administração de hemina, disponível no Brasil apenas em pó liofilizado para solução injetável. A hemina é uma fonte exógena de grupos hemes caracterizados por ser uma porfirina, especificamente uma protoporfirina IX, contendo um íon férrico com um ligante de cloreto<sup>60-62</sup> . No Brasil, a hemina possui indicação em bula restrita para o tratamento dos ataques recorrentes de porfiria aguda intermitente, temporariamente relacionados com o ciclo menstrual em mulheres afetadas, quando o tratamento inicial com glicose é inadequado<sup>60</sup> . A hemina foi avaliada pela Conitec, conforme o Relatório de Recomendação nº 771/2022, com recomendação desfavorável, devido às evidências escassas e de baixa qualidade acerca da eficácia e segurança do medicamento<sup>63</sup> .  
Ainda, a givosirana sódica, uma pequena molécula sintética de RNA de interferência (siRNA) que regula negativamente o mRNA de ALAS1, possui indicação de uso na prevenção de ataques porfíricos agudos<sup>29</sup> . O medicamento foi avaliado pela Conitec, conforme Relatório de Recomendação nº 639/2021, para o tratamento profilático de pacientes adultos com porfirias hepáticas agudas, com recomendação desfavorável à sua incorporação no SUS, devido à sua razão de custo-efetividade incremental<sup>64</sup> .  
Assim, este Protocolo recomenda o tratamento com glicose para o manejo de ataques porfíricos, uma vez que as demais tecnologias não foram incorporadas ou não foram avaliadas pela Conitec no SUS.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
- Glicose 5%: solução injetável de 50 mg/mL  
- Glicose 10%: solução injetável de 100 mg/mL  
- Glicose 50%: solução injetável de 500 mg/mL

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
A quantidade de glicose necessária para o controle de ataques porfíricos agudos varia conforme a resposta clínica de cada paciente<sup>65</sup> . O principal esquema recomendado pelas diretrizes clínicas internacionais é a infusão de 300 a 500 mg de glicose hipertônica 10% reconstituída em solução salina 0,45%, por via intravenosa, com fluxo de distribuição contínuo de 24 horas<sup>32,56</sup> .  
Em pacientes clinicamente aptos ao consumo oral de glicose ou em situações de baixa tolerabilidade à infusão intravenosa, a dose de glicose pode ser complementada com uma dieta rica em carboidratos<sup>55,56</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
14  
A melhora clínica pode ser observada com a administração de glicose por 2 a 6 dias<sup>57</sup> , embora as evidências sejam escassas e a conduta ocorra a critério médico.  
A hiponatremia leve a grave é um fenômeno bastante comum (25% a 60%) durante os ataques agudos de porfiria. Nesse sentido, um ajuste no tratamento em pacientes com sinais de hiponatremia deve ser avaliado, uma vez que a infusão de glicose pode agravar o quadro clínico do paciente e ocasionar outros distúrbios eletrolíticos, causando edema e desmielinização osmótica<sup>55,56,66,67</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
As porfirias cutâneas, durante a sua fase sintomática, dependem da adoção de medidas de proteção solar, como o uso de acessórios adequados ou aplicação tópica de protetores solares opacos. A interrupção dos fatores desencadeantes, no entanto, pode não resultar em uma melhora significativa<sup>68</sup> .  
Assim como nas porfirias hepáticas agudas, pacientes com PPE e PLX podem desenvolver doença hepática terminal secundária à porfiria, sendo elegíveis ao transplante hepático. No entanto, este transplante não corrige o defeito genético nas protoporfirias, uma vez que ambas são ocasionadas pela falha da biossíntese do heme na medula óssea<sup>5,24,68</sup> . Por outro lado, o transplante alogênico de células-tronco hematopoiéticas parece reduzir expressivamente a PPIX, diminuindo o dano inflamatório no fígado, se realizado antes ou depois do transplante hepático<sup>5</sup> . Ainda que a plasmaferese seja indicada por alguns autores para a redução dos níveis de protoporfirina<sup>5,68</sup> , as evidências são escassas.  
Na PEC, a esplenectomia pode beneficiar alguns pacientes com anemia. No entanto, devido à variabilidade das apresentações clínicas, que incluem a necessidade de transfusões e as complicações associadas ao aumento do baço, a decisão de realizar a esplenectomia deve ser individualizada. O transplante alogênico de células-tronco hematopoiéticas também pode ser útil para casos selecionados de PEC<sup>5</sup> .  
Na PCT, é importante evitar a exposição a fatores precipitantes, como bebidas alcoólicas e o tabagismo<sup>6,12</sup> . O transplante é considerado quando há doença hepática estabelecida por abuso de álcool concomitante ou pelo quadro de hepatite C<sup>68</sup> . A morbidade e a mortalidade pós-transplante estão diretamente relacionadas ao grau de complicações pré-operatórias e danos nos órgãos<sup>32</sup> .  
Como medida não medicamentosa, a sobrecarga de ferro na PCT tem sido tratada por meio de flebotomia<sup>11,37</sup> . Esse procedimento visa a esgotar os depósitos de ferro corporais, impedindo seu reacúmulo na fase de manutenção<sup>69</sup> . Geralmente, são necessárias sessões de flebotomia a cada duas semanas, envolvendo a retirada de aproximadamente 450 mL de sangue, com vigilância dos níveis de hematócrito, ferritina sérica e perfil bioquímico das porfirinas. Recomenda-se interromper a flebotomia quando os níveis de ferritina sérica atingirem o limite inferior (20 ng/mL)<sup>70</sup> . A frequência das sessões de flebotomia deve ser ajustada conforme a necessidade e gravidade da sobrecarga de ferro. Evidências indicam melhora da função hepática e das alterações cutâneas após a remissão bioquímica<sup>37</sup> . A flebotomia geralmente é ineficaz em indivíduos com PHE<sup>6</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Nas porfirias hepáticas cutâneas, a exposição a fatores hepatotóxicos deve ser evitada, como o uso de estrogênios orais e medicamentos indutores do sistema citocromo P450, devido ao potencial acúmulo de porfirinas e seus precursores<sup>6,12</sup> . Isso ocorre  
15  
porque esses fatores interferem na função hepática da enzima UROD por meio de um mecanismo ferro-dependente, catalisando a oxidação do uroporfirinogênio a coproporfirinogênio, um inibidor da enzima UROD<sup>37,71</sup> .  
Para a PCT, o uso de baixas doses de agentes antimaláricos, como cloroquina e hidroxicloroquina, emerge na literatura como uma possibilidade para estimular a excreção de uroporfirinas<sup>6,12</sup> . Ambos os agentes parecem ser eficazes, mas a hidroxicloroquina é preferida devido à sua maior experiência clínica e perfil de segurança. Ressalta-se que a contraindicação de hidroxicloroquina para pacientes com porfirias, descrita em bula, refere-se aos casos de porfirias hepáticas agudas, devido ao risco de exacerbação dos ataques porfíricos<sup>37,72-74</sup> . Além de as evidências descritas não serem robustas, a hidroxicloroquina não possui recomendação em bula para porfirias cutâneas<sup>74</sup> e cloroquina possui registro na Anvisa para doenças de fotossensibilidade como a porfiria cutânea tardia<sup>75</sup> . A incorporação das tecnologias para esta indicação não foi submetida à avaliação da Conitec e não é recomendada neste PCDT.  
Nas porfirias eritropoiéticas, as evidências divergem em relação à indicação do betacaroteno como medida para auxiliar na redução da fotossensibilidade<sup>5</sup> . Independentemente das evidências, no Brasil, o seu uso ainda não foi aprovado como substância isolada, apenas em associação com outras vitaminas e suplementos minerais. A administração de afamelanotide, aprovada em 2014 na Europa e, posteriormente, pela _Food and Drug Administration (_ FDA) em 2019, tornou-se uma alternativa para prevenir a fototoxicidade em pacientes adultos com PPE e PLX<sup>5,76</sup> . Trata-se de um análogo de longa duração do hormônio estimulante de melanócitos que leva ao aumento da produção de eumelanina, a cada 60 dias, via implante subcutâneo<sup>77</sup> . No entanto, o seu uso ainda não foi aprovado pela Anvisa.  
A imunização contra hepatite A e B pode ser útil na prevenção de lesões hepáticas na PPE e na PLX<sup>16,22</sup> e o SUS disponibiliza ambas as vacinas<sup>78</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Sugere-se a realização de exame físico completo, incluindo a avaliação minuciosa da pele para verificar a presença de fotossensibilidade, fotomutilação e alterações cutâneas secundárias, como espessamento, hiper ou hipopigmentação e hipertricose<sup>6,12</sup> .  
Também é importante realizar uma avaliação clínica de manifestações neuroviscerais agudas, com avaliação de fatores desencadeantes de crise, como o uso de medicamentos, dieta e condições concomitantes que podem afetar a gravidade da doença. Não há um limiar de PBG que esteja diretamente correlacionado com o início dos sintomas, portanto, os resultados devem ser avaliados no contexto do quadro clínico geral, preferencialmente em consulta com um especialista em porfiria<sup>32</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O monitoramento regular dos pacientes com porfirias hepáticas agudas é essencial, incluindo a avaliação da intensidade da dor, da função neurológica, hepática e renal, dos níveis de eletrólitos no sangue, hemograma e dos parâmetros vitais (frequência cardíaca, pressão arterial.). É importante destacar que a educação ao paciente é um fator fundamental na gestão das crises porfíricas a longo prazo<sup>34,43</sup> .  
Independentemente da gravidade dos sintomas, os pacientes com porfirias agudas devem ser monitorados regularmente para detecção precoce de carcinoma hepatocelular, a partir dos 50 anos de idade, com ultrassonografia hepática a cada 6 meses, principalmente os diagnosticados com PAI, visto que o risco é aumentado nestes indivíduos<sup>43</sup> .  
16  
Apesar de o aumento das enzimas hepáticas nas porfirias agudas estar frequentemente associado ao tratamento com givosirana e hemina, pacientes assintomáticos também podem apresentar resultados alterados para estes marcadores. Neste cenário, é recomendado que esses pacientes sejam monitorados quanto à função hepática, independentemente do tratamento adotado ou da presença de sintomas<sup>43</sup> . Há poucas diretrizes baseadas em evidências sobre porfirias e a maior parte das referências apresenta recomendações sobre o monitoramento hepático para pacientes em tratamento específico. No entanto, um consenso português recomendou que, mesmo os pacientes assintomáticos, sejam monitorados anualmente<sup>34</sup> .  
Além do envolvimento hepático, os pacientes com porfirias, especialmente aqueles com ataques recorrentes, enfrentam uma carga elevada de condições crônicas, incluindo náuseas crônicas, fadiga, neuropatia, doença renal e hipertensão arterial sistêmica. O impacto negativo das porfirias na qualidade de vida leva a altas taxas de depressão, ansiedade e insônia, quadros que devem ser avaliados e monitorados<sup>43</sup> .  
Diante da complexidade do quadro clínico e da possibilidade de complicações que impactam consideravelmente a saúde e a qualidade de vida, os pacientes devem ser submetidos a avaliações regulares<sup>43</sup> . De acordo com o Consenso Português de Porfirias Agudas, os parâmetros de monitorização podem ser avaliados em intervalos regulares e, para alguns, durante as crises agudas. Esses parâmetros envolvem dosagem de ALA e PBG urinários, hemograma completo, marcadores de função hepática e renal, monitorização ambulatorial da pressão arterial, ecocardiograma, ultrassonografia abdominal e renal. A função renal deve ser monitorada pelo menos anualmente. Outros exames podem ser necessários, de acordo com o quadro clínico<sup>34</sup> .  
Um consenso _Delphi_ internacional destacou um grupo de pacientes que merecem atenção devido ao risco aumentado de ataques: os excretores alto assintomáticos, ou seja, aqueles indivíduos com porfiria aguda confirmada que não apresentaram manifestações relacionadas à porfiria durante os últimos 2 anos e cuja proporção PBG/creatinina na urina é pelo menos 4 vezes o limite superior do normal. Para ser caracterizado como um excretor alto assintomático, o indivíduo pode, ou não, ter apresentado um ataque de porfiria no passado<sup>50</sup> .  
O mesmo consenso define também os excretores altos sintomáticos, também chamados de excretores altos crônicos, que são os indivíduos com porfiria aguda confirmada que não tiveram nenhum ataque agudo nos últimos 2 anos, mas têm longo histórico de dor ou de outras manifestações relacionadas à porfiria, na ausência de outras explicações prováveis e uma relação PBG/creatinina na urina de pelo menos 4 vezes o limite superior do normal<sup>50</sup> .  
Ainda, há pacientes com ataques recorrentes de PAI que tendem a apresentar resultados de PBG persistentemente elevados. Nestes casos, quando apresentam novos sintomas, a interpretação do aumento da excreção de PBG urinário pode não ser simples. Os resultados da dosagem de PBG devem ser avaliados em conjunto com o quadro clínico completo do paciente, preferencialmente por um profissional especializado em porfirias<sup>33</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
É importante monitorar os níveis de porfirinas e realizar exames do perfil de ferro, com hemograma completo e ferritina, para detectar a presença de anemia e avaliar os estoques de ferro. Nas porfirias eritropoiéticas cutâneas, além da avaliação dermatológica minuciosa, é importante também realizar avaliações oftalmológicas regulares para úlceras e cicatrizes da córnea e outras manifestações oculares<sup>7</sup> . A avaliação da função hepática e dos níveis de vitamina D deve ser realizada pelo menos anualmente<sup>38</sup> .  
Na PEC, a avaliação hematológica deve incluir perfil de ferro, contagem de reticulócitos e bilirrubinas para avaliação de hemólise. Indivíduos que recebem transfusão precisam de monitoramento mais intensivo. Além disso, também se sugere uma  
17  
avaliação periódica das porfirinas urinárias e, quando disponível, eritrocitárias e monitorar os níveis de vitamina D<sup>7,11,16</sup> . O monitoramento da função hepática na PEC é enfatizado devido ao potencial risco de desenvolvimento de hepatopatia associada ao acúmulo de ferro em pacientes dependentes de transfusão<sup>7</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O monitoramento de porfirias hepáticas inclui a avaliação clínica e bioquímica anual de porfirinas. Também é recomendada a avaliação anual da função hepática, com exame ultrassonográfico<sup>37</sup> . Considerando as evidências escassas, por seu caráter raro, o monitoramento do câncer hepatocelular nas porfirias hepáticas cutâneas pode ser avaliado por meio da alfafetoproteína sérica e da ultrassonografia hepática, ressonância magnética ou tomografia computadorizada<sup>12</sup> .  
A avaliação laboratorial de acompanhamento da resposta à flebotomia também inclui hemograma completo, ferritina sérica e perfil sérico de ferro<sup>37</sup> . Devido aos relatos de associação com diabete melito, a dosagem da glicemia de jejum pode ser útil, particularmente na presença de hipertensão arterial. Por fim, é necessário monitorar a presença de infecções por hepatites virais e pelo HIV<sup>12</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamentos prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Os pacientes com porfirias devem ser, preferencialmente, atendidos em estabelecimentos de saúde localmente designados como centros de referência para a investigação diagnóstica das pessoas com suspeita da doença e para o acompanhamento das pessoas com a doença. Cabe destacar que, sempre que possível, o atendimento da pessoa com porfiria deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio, conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03), de transplante de órgãos, tecidos e células (Grupo 05) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a condição clínica, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
A indicação de transplante deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
18  
Os receptores submetidos a transplante originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras<sup>79,80</sup> . A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela APS e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A APS é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da APS.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras. Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os Serviços de Atenção Especializada em Doenças Raras e para os Serviços de Referência em Doenças Raras.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
1. Phillips JD. Heme biosynthesis and the porphyrias. Mol Genet Metab. 2019;128(3):164-177.  
19  
2. Ferreira GC. Encyclopedia of Biological Chemistry: Second Edition. Heme Synthesis. GeneReviews®. 2013.  
3. Chiabrando D, Vinchi F, Fiorito V, Mercurio S, Tolosano E. Heme in pathophysiology: a matter of scavenging,  
metabolism and trafficking across cell membranes. Front Pharmacol. 2014;5:61.  
4. Erwin AL, Balwani M. Porphyrias in the Age of Targeted Therapies. Diagnostics (Basel). 2021;11(10).  
5. Stölzel U, Doss MO, Schuppan D. Clinical Guide and Update on Porphyrias. Gastroenterology. 2019;157(2):365-  
- 381 e364.  
6. Rudnick S, Phillips J, Bonkovsky H, Porphyrias Consortium of the Rare Diseases Clinical Research Network.  
Hepatoerythropoietic Porphyria - Synonym: UROD-Related Hepatoerythropoietic Porphyria. GeneReviews®. 2013 (atualizado em 2022).  
7. Erwin A, Balwani M, Desnick RJ. Congenital Erythropoietic Porphyria. Synonym: Günther Disease.  
GeneReviews®. 2013 (atualizado em 2021).  
8. Elder G, Harper P, Badminton M, Sandberg S, Deybach JC. The incidence of inherited porphyrias in Europe. Journal  
of inherited metabolic disease. 2013;36(5):849-857.  
9. Orphanet, 2021. X-linked erythropoietic protoporphyria. Disponível em: https://www.orpha.net/consor/cgi-  
bin/OC_Exp.php?lng=EN&Expert=443197.  
10. Orphanet, 2021. Congenital erythropoietic porphyria. Disponível em:  
https://www.orpha.net/en/disease/detail/79277.  
11. Balwani M, Desnick R. X-Linked Protoporphyria. GeneReviews®. 2013 (atualizado em 2019).  
12. Rudnick S, Phillips J, Bonkovsky H, Porphyrias Consortium of the Rare Diseases Clinical Research Network.  
Familial Porphyria Cutanea Tarda - Synonyms: Familial PCT (F-PCT); Porphyria Cutanea Tarda, Type II (Type II PCT); URODRelated Porphyria Cutanea Tarda. GeneReviews®. 2013 (atualizado em 2022).  
13. Sardh E, Barbaro M. Acute Intermittent Porphyria - Synonyms: PBGD Deficiency, Porphobilinogen Deaminase  
Deficiency. GeneReviews®. 2005 (atualizado em 2024).  
14. Wang B, Bissell DM. Hereditary Coproporphyria. GeneReviews®. 2012 (atualizado em 2022).  
15. Singal AK, Anderson KE. Variegate Porphyria - Synonym: Porphyria Variegata. GeneReviews®. 2013 (atualizado  
- em 2019).  
16. Balwani M, Bloomer J, Desnick R, Porphyrias Consortium of the NIH-Sponsored Rare Diseases Clinical Research  
Network. Erythropoietic Protoporphyria, Autosomal Recessive. GeneReviews®. 2012 (atualizado em 2017).  
17. Associação Brasileira de Porfiria (ABRAPO), 2023. Lista de medicamentos. Disponível em:  
http://www.porfiria.org.br/medicamentos.htm.  
18. Dorr AM, Picharski GL, Osternack BR. Porphyria: analysis of register from Brazilian Association of Porphyria  
(ABRAPO). Hematology & Transfusion International Journal. 2016;2(6):112‒114.  
19. Souza PVS, Badia BML, Farias IB, Goncalves EA, Pinto WBVR, Oliveira ASB. Acute hepatic porphyrias for the  
neurologist: current concepts and perspectives. Arquivos de Neuropsiquiatria. 2021;79(1):68-80.  
20. Balwani M, Wang B, Anderson KE, Bloomer JR, Bissell DM, Bonkovsky HL, et al. Acute hepatic porphyrias:  
Recommendations for evaluation and long-term management. Hepatology. 2017;66(4):1314-1322.  
20  
21. Ministério da Saúde, Secretaria de Atenção Especializada à Saúde, Departamento de Atenção Especializada e  
- Temática, 2016. Triagem Neonatal. Disponível em:  
https://bvsms.saude.gov.br/bvs/publicacoes/triagem_neonatal_biologica_manual_tecnico.pdf.  
22. Balwani M. Erythropoietic Protoporphyria and X-Linked Protoporphyria: pathophysiology, genetics, clinical  
manifestations, and management. Mol Genet Metab. 2019;128(3):298-303.  
23. Cabezas Arteaga JE, Vieira FMJ, Silva Dos Reis VM. Experience in management of porphyria cutanea tarda in a  
tertiary referral Brazilian hospital from 2002 to 2017. Int J Dermatol. 2019;58(8):925-932.  
24. Yasuda M, Chen B, Desnick RJ. Recent advances on porphyria genetics: Inheritance, penetrance & molecular  
heterogeneity, including new modifying/causative genes. Mol Genet Metab. 2019;128(3):320-331.  
25. Ministério da Saúde, Tecnologia Secretaria de Ciência, Inovação e Complexo da Saúde , Departamento de Gestão  
e Incorporação de Tecnologias em Saúde, 2023. Diretrizes Metodológicas - Elaboração de Diretrizes Clínicas. Disponível em: https://www.gov.br/conitec/pt-br/midias/artigos_publicacoes/diretrizes/diretrizes-metodologicas-elaboracao-de-diretrizesclinicas-2020.pdf.  
26. Muschalek W, Hermasch MA, Poblete-Gutierrez P, Frank J. The Porphyrias. Journal der Deutschen  
Dermatologischen 2022;20(3):316-331.  
27. Ramanujam VS, Anderson KE. Porphyria Diagnostics-Part 1: A Brief Overview of the Porphyrias. Curr Protoc  
Hum Genet. 2015;86:17 20 11-17 20 26.  
28. Ministério da Saúde, Tecnologia Secretaria de Ciência, Inovação e Complexo da Saúde - SECTICS, Departamento  
de Gestão e Incorporação de Tecnologias em Saúde - DGITS, Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas - CGPCDT, 2024. Relatório de Recomendação - Dosagem de porfobilinogênio urinário para confirmação diagnóstica ou prognóstico de porfirias hepáticas agudas. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2024/dosagem-de-porfobilinogenio-urinario-para-confirmacao-diagnostica-ou-prognostico-de-porfiriashepaticas-agudas. Acesso em: 15 de julho.  
29. National Institute for Health and Care Excellence (NICE), 2021. Highly Specialised Technology Evaluation  
Givosiran for treating acute hepatic porphyria [ID1549] (Evaluation Report). Disponível em: https://www.nice.org.uk/guidance/hst16/documents/committee-papers.  
30. Bissell DM, Anderson KE, Bonkovsky HL. Porphyria. N Engl J Med. 2017;377(9):862-872.  
31. Anderson KE, Lobo R, Salazar D, Schloetter M, Spitzer G, White AL, et al. Biochemical Diagnosis of Acute  
Hepatic Porphyria: Updated Expert Recommendations for Primary Care Physicians. Am J Med Sci. 2021;362(2):113-121.  
32. Stein P, Badminton M, Barth J, Rees D, Stewart MF. Best practice guidelines on clinical management of acute  
attacks of porphyria and their complications. Annals of Clinical Biochemistry. 2013;50(Pt 3):217-223.  
33. Woolf J, Marsden JT, Degg T, Whatley S, Reed P, Brazil N, et al. Best practice guidelines on first-line laboratory  
testing for porphyria. Annals of Clinical Biochemistry. 2017;54(2):188-198.  
34. Brito Avô L, Pereira L, Oliveira A, Ferreira F, Filipe P, Coelho Rodrigues I, et al. Portuguese Consensus on Acute  
Porphyrias: Diagnosis, Treatment, Monitoring and Patient Referral. Acta Med Port 2023;36(11):753-764.  
35. Schulenburg-Brand D, Stewart F, Stein P, Rees D, Badminton M. Update on the diagnosis and management of the  
autosomal dominant acute hepatic porphyrias. J Clin Pathol. 2022.  
21  
36. Neeleman RA, Wensink D, Wagenmakers MAEM, Mijnhout GS, Friesema ECH, Langendonk JG. Diagnostic and  
therapeutic strategies for porphyrias. Neth J Med. 2020;78(4):149-160.  
37. Singal AK. Porphyria cutanea tarda: Recent update. Mol Genet Metab. 2019;128(3):271-281.  
38. Dickey AK, Naik H, Keel SB, Levy C, Beaven SW, Elmariah SB, et al. Evidence-based consensus guidelines for  
the diagnosis and management of erythropoietic protoporphyria and X-linked protoporphyria. J Am Acad Dermatol. 2023;89(6):1227-1237.  
39. Erwin AL, Desnick RJ. Congenital erythropoietic porphyria: Recent advances. Mol Genet Metab.  
2019;128(3):288-297.  
40. Di Pierro E, De Canio M, Mercadante R, Savino M, Granata F, Tavazzi D, et al. Laboratory Diagnosis of Porphyria.  
Diagnostics (Basel). 2021;11(8):1343.  
41. Whatley SD, Badminton MN. Role of genetic testing in the management of patients with inherited porphyria and  
their families. Annals of Clinical Biochemistry. 2013;50(3):204-216.  
42. Edel Y, Mamet R. Porphyria: What is it and who should be evaluated? Rambam Maimonides Med J. 2018;9(2).  
43. Wang B, Bonkovsky HL, Lim JK, Balwani M. AGA Clinical Practice Update on Diagnosis and Management of  
Acute Hepatic Porphyrias: Expert Review. Gastroenterology. 2023;164(3):484-491.  
44. Gerischer LM, Scheibe F, Numann A, Kohnlein M, Stolzel U, Meisel A. Acute porphyrias - A neurological  
perspective. Brain Behav. 2021;11(11):e2389.  
45. Bellanti R, Rinaldi S. Guillain-Barre syndrome: a comprehensive review. Eur J Neurol. 2024;31(8):e16365.  
46. Schwambach FW, Piaskowy PA, Santos MCR, Pilger CG, Frandoloso GA. Porfiria aguda: o que precisamos saber.  
Revista Médica da Universidade Federal do Paraná. 2014;1(1):15-20.  
47. Onyechi A, Ohemeng-Dapaah J, Shaba W, Oyenuga M, Lacasse A, Sandeep S, et al. Needle in a Haystack: Acute  
Intermittent Porphyria, an Often-missed Differential Diagnosis of Abdominal Pain. J Community Hosp Intern Med Perspect. 2023;13(5):82-85.  
48. Anderson KE, Bloomer JR, Bonkovsky HL, Kushner JP, Pierach CA, Pimstone NR, et al. Recommendations for  
the diagnosis and treatment of the acute porphyrias. Ann Intern Med. 2005;142(6):439-450.  
49. Simon A, Pompilus F, Querbes W, Wei A, Strzok S, Penz C, et al. Patient Perspective on Acute Intermittent  
Porphyria with Frequent Attacks: A Disease with Intermittent and Chronic Manifestations. Patient. 2018;11(5):527-537.  
50. Stein PE, Edel Y, Mansour R, Mustafa RA, Sandberg S, Panel Members of the Acute Porphyria Expert. Key terms  
and definitions in acute porphyrias: Results of an international Delphi consensus led by the European porphyria network. J Inherit Metab Dis. 2023;46(4):662-674.  
51. Wang B. The acute hepatic porphyrias. Transl Gastroenterol Hepatol. 2021;6:24.  
52. American Porphyria Foundation, 2024. Banco de dados de medicamentos. Disponível em:  
https://porphyriafoundation.org/drugdatabase/.  
53. Anderson KE. Acute hepatic porphyrias: Current diagnosis & management. Mol Genet Metab. 2019;128(3):219-  
227.  
54. Handschin C, Lin J, Rhee J, Peyer AK, Chin S, Wu PH, et al. Nutritional regulation of hepatic heme biosynthesis  
and porphyria through PGC-1alpha. Cell. 2005;122(4):505-515.  
22  
55. Harper P, Sardh E. Management of acute intermittent porphyria. Expert Opinion on Orphan Drugs. 2014;2(4):349-  
368.  
56. Pischik E, Kauppinen R. An update of clinical management of acute intermittent porphyria. Appl Clin Genet.  
2015;8:201-214.  
57. Doss M, Verspohl F. The "glucose effect" in acute hepatic porphyrias and in experimental porphyria. Klin  
Wochenschr. 1981;59(13):727-735.  
58. Bustad HJ, Kallio JP, Vorland M, Fiorentino V, Sandberg S, Schmitt C, et al. Acute Intermittent Porphyria: An  
Overview of Therapy Developments and Future Perspectives Focusing on Stabilisation of HMBS and Proteostasis Regulators. Int J Mol Sci. 2021;22(2).  
59. Schulenburg-Brand D, Gardiner T, Guppy S, Rees DC, Stein P, Barth J, et al. An Audit of the Use of Gonadorelin  
Analogues to Prevent Recurrent Acute Symptoms in Patients with Acute Porphyria in the United Kingdom. JIMD Rep. 2017;36:99-107.  
60. Recordati Rare Diseases Comércio de Medicamentos Ltda - ME, 2021. Bula PANHEMATIN® (Hemina).  
Disponível em: https://uploads.consultaremedios.com.br/drug_leaflet/pro/Bula-PANHEMATIN-Profissional-Consulta-  
Remedios.pdf.  
61. Recordati Rare Diseases Comércio de Medicamentos Ltda - ME, 2019. Bula Normosang® (Hemina). Disponível em: https://www.medicines.org.uk/emc/files/pil.6235.pdf.  
62. Agência Nacional de Vigilância Sanitária (ANVISA), 2019. Registro PANHEMATIN® Hemina. Disponível em:  
https://consultas.anvisa.gov.br/#/documentos/tecnicos/25351722767201791/.  
63. Ministério da Saúde, Tecnologia Secretaria de Ciência, Inovação e Insumos Estratégicos em Saúde - SCTIE, Departamento de Gestão e Incorporação de Tecnologias em Saúde - DGITS, Coordenação-Geral de Avaliação de Tecnologias em Saúde - CGATS, Coordenação de Monitoramento de Tecnologias em Saúde - CMTS, 2022. Relatório de Recomendação - Hemina para o tratamento de mulheres com ataques de porfiria aguda intermitente relacionados com o ciclo menstrual. Disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2022/20220927_relatorio_771_hemina_pai.pdf.  
64. Ministério da Saúde, Tecnologia Secretaria de Ciência, Inovação e Insumos Estratégicos em Saúde, Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde, Coordenação-Geral de Gestão de Tecnologias em Saúde, Coordenação de Monitoramento e Avaliação de Tecnologias em Saúde, 2021. Relatório de Recomendação - Givosirana para o tratamento pacientes adultos com  
porfirias hepáticas agudas. Disponível em: https://www.gov.br/conitec/pt-  
br/midias/relatorios/2021/20210712_relatorio_639_givosirana_porfiriahepatica_p38.pdf.  
65. Tschudy DP, Valsamis M, Magnussen CR. Acute intermittent porphyria: clinical and selected research aspects.  
Ann Intern Med. 1975;83(6):851-864.  
66. Stein PE, Badminton MN, Rees DC. Update review of the acute porphyrias. Br J Haematol. 2017;176(4):527-538.  
67. Petrides PE. Therapy Follows Diagnosis: Old and New Approaches for the Treatment of Acute Porphyrias, What  
We Know and What We Should Know. Diagnostics (Basel). 2022;12(7).  
68. Singal AK, Parker C, Bowden C, Thapar M, Liu L, McGuire BM. Liver transplantation in the management of porphyria. Hepatology. 2014;60(3):1082-1089.  
23  
69. European Association for the Study of the Liver (EASL). EASL Clinical Practice Guidelines on haemochromatosis. J Hepatol. 2022;77(2):479-502.  
70. Di Padova C, Marchesi L, Cainelli T, Gori G, Podenzani SA, Rovagnati P, et al. Effects of phlebotomy on urinary  
porphyrin pattern and liver histology in patients with porphyria cutanea tarda. Am J Med Sci. 1983;285(1):2-12.  
71. Sánchez CMF, Navarrete CJ, Buchroithner HC. Porfiria cutánea tarda: revisión de la literatura a propósito de un  
caso / Porphyria cutanea tarda: a case report and literature review. Rev chil dermatol. 2015;31(3):265-271.  
72. Singal AK, Kormos-Hallberg C, Lee C, Sadagoparamanujam VM, Grady JJ, Jr DHF, et al. Low-dose  
hydroxychloroquine is as effective as phlebotomy in treatment of patients with porphyria cutanea tarda. Clin Gastroenterol Hepatol. 2012;10(12):1402-1409.  
73. Dawe R. An overview of the cutaneous porphyrias [version 1; peer review: 2 approved]. F1000Research.  
2017;6:1906.  
74. Sanofi Medley Farmacêutica Ltda, 2024. Bula PLAQUINOL® (sulfato de hidroxicloroquina). Disponível em:  
https://sm.far.br/pdfshow/bula_183260379_4459968223_p.pdf.  
75. Fundação Oswaldo Cruz/ Instituto de Tecnologia em Fármacos, 2021. Bula Cloroquina. Disponível em:  
https://www.far.fiocruz.br/wp-content/uploads/2018/06/Farmanguinhos-cloroquina_Bula_Profissional.pdf.  
76. National Center for Advancing Translational Sciences, Genetic and Rare Diseases Information Center (GARD),  
2024. Autosomal erythropoietic protoporphyria. Disponível em: https://rarediseases.info.nih.gov/diseases/4527/erythropoieticprotoporphyria.  
77. Langendonk JG, Balwani M, Anderson KE, Bonkovsky HL, Anstey AV, Bissell DM, et al. Afamelanotide for  
Erythropoietic Protoporphyria. N Engl J Med. 2015;373(1):48-59.  
78. Ministério da Saúde, Secretaria de Vigilância em Saúde, Coordenação-Geral de Desenvolvimento da  
Epidemiologia em Serviços, 2019. Guia de Vigilância em Saúde (3ª edição). Disponível em:  
https://bvsms.saude.gov.br/bvs/publicacoes/guia_vigilancia_saude_3ed.pdf.  
79. Ministério da Saúde, Brasil, 2017. Portaria de Consolidação GM/MS nº6, de 28 de setembro de 2017. Disponível  
em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0006_03_10_2017.htmlA.  
80. Ministério da Saúde, Brasil, 2017. Portaria de Consolidação GM/MS nº2, de 28 de setembro de 2017. Disponível  
em: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html.  
24

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) das Porfirias contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo EconômicoIndustrial da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos das especialidades de genética e neurologia, além de representantes do Ministério da Saúde e metodologistas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
O público-alvo deste PCDT é composto por profissionais de saúde envolvidos no atendimento de pacientes com porfiria, em especial clínicos gerais, pediatras, neurologistas, dermatologistas, geneticistas, além de gestores/farmacêuticos envolvidos na disponibilização das intervenções apresentadas. Os pacientes com suspeita ou diagnóstico de porfiria são a população-alvo destas recomendações.  
O processo iniciou-se com uma reunião para delimitação do pré-escopo da elaboração do referido documento, realizada virtualmente com o uso de videoconferência, no dia 14 de junho de 2022. Então, nos dias 15 de julho e 14 de setembro de 2022 ocorreu a reunião de escopo, onde foram discutidas as condutas clínicas e tecnologias que poderiam ser priorizadas para elaboração de revisão sistemática das evidências com ou sem formulação de recomendações, sendo norteada por uma revisão prévia de diretrizes clínicas e de revisões sistemáticas recentemente publicadas. Na referida reunião, foi definido que o texto do PCDT deveria ser elaborado para incluir evidências sobre a epidemiologia, critérios diagnósticos, tratamento e monitorização da doença. As tecnologias com registro válido junto à Agência Nacional de Vigilância Sanitária (Anvisa) para o tratamento de porfirias já haviam sido avaliadas previamente pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (CONITEC), com decisão de não incorporação ao Sistema Único de Saúde (SUS).  
As demais tecnologias mapeadas não possuíam registro válido para a indicação. Assim, foi priorizada a avaliação de incorporação da dosagem de porfobilinogênio (PBG) urinário (dPBGu – análise quantitativa) para a confirmação diagnóstica ou prognóstico de pacientes com suspeita ou diagnóstico confirmado de porfiria hepática aguda pelo painel de especialistas. Após avaliação pela Conitec, conforme Relatório de Recomendação nº 889, o procedimento foi incorporado ao SUS.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O Protocolo foi elaborado pelo Núcleo de Avaliação de Tecnologias em Saúde da Universidade Federal de São Paulo – Diadema (NUD).  
**Declaração e Manejo de Conflitos de Interesse**  
25  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A.** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum do|s benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afe<br>atividade na elaboração ou revisão da diretriz?|tados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim|  
26  
||(   ) Não|
|---|---|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever|(   ) Sim|
|e que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa|(   ) Sim|
|afetar sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
A proposta de elaboração do PCDT das Porfirias foi apresentada na 118ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 17 de setembro de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e da Secretaria de Atenção Especializada em Saúde (SAES). O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
A Consulta Pública nº 72/2024, do Protocolo Clínico e Diretrizes Terapêuticas das Porfirias, foi realizada entre os dias 16 de outubro de 2024 a 04 de novembro de 2024. Foram recebidas 112 contribuições que podem ser verificadas em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2024/contribuicoes-da-consulta-publica-72-2024-protocoloclinico-e-diretrizes-terapeuticas-de-porfirias.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
O processo de elaboração desse PCDT incluiu uma busca abrangente na literatura científica para embasar o texto do documento. Inicialmente, a busca teve como objetivo identificar diretrizes clínicas nacionais e internacionais e revisões sistemáticas sobre porfirias. Devido à escassez de evidências sobre o assunto, os critérios de inclusão foram amplos, sem limitações aos desenhos de estudo.  
Foi conduzida também revisão sistemática sobre o uso do teste de dPBGu para confirmação diagnóstica ou prognóstico de pacientes com suspeita ou diagnóstico confirmado de porfiria hepática aguda, considerando a análise qualitativa desse parâmetro como padrão de referência. Para a identificação de estudos sobre dPBGu, foi utilizada a seguinte pergunta de pesquisa, considerando o acrônimo PIROS (População, “ _Index test_ ” [teste índice], “ _Reference standard_ ” [padrão de referência], " _Outcomes_ " [desfecho] e Delineamento dos estudos):  
**Qual é a acurácia diagnóstica do teste de dPBGu para o diagnóstico ou o prognóstico de porfirias hepáticas agudas?**  
27  
**População:** Pacientes e/ou amostras de urina com diagnóstico confirmado ou suspeito de porfiria hepática aguda.  
**Teste-índice:** Dosagem de PBG urinário (dPBGu) – análise quantitativa.  
**Padrão de referência:** Pesquisa de PBG urinário (pPBGu) – análise qualitativa.  
**Desfechos:** Sensibilidade (verdadeiros positivos); Especificidade (verdadeiros negativos); Razão de verossimilhança;  
Valores preditivos positivos e negativos.  
**Delineamento de estudo:** Estudos transversais de teste diagnóstico e outros observacionais (exceto séries/relatos de casos).  
Métodos e resultados da busca  
Foi realizada busca sistematizada da literatura nas bases de dados MEDLINE (via PubMed), Embase, Cochrane Library e outras, via Biblioteca Virtual em Saúde. A busca foi realizada no dia 03 de agosto de 2022, sem restrições para tipos de porfiria, comparadores, desfechos, tipos de estudo e ano de publicação. As estratégias de busca para cada base estão descritas no **Quadro B** .  
**Quadro B.** Estratégias de busca, de acordo com a base de dados, sobre o uso do teste de dPBGu para o diagnóstico ou o prognóstico de porfiria hepática aguda  
|**Base de dados**|**Estratégia de busca**|
|---|---|
||#1         MeSH descriptor: [Porphyrias] explode all trees|
||#2         MeSH descriptor: [Porphyrias, Hepatic] explode all trees|
||#3         MeSH descriptor: [Coproporphyria, Hereditary] explode all trees|
||#4         MeSH descriptor: [Porphyria, Acute Intermittent] explode all trees<br>#5         MeSH descriptor: [Porphyria, Variegate] explode all trees|
||#6         (Porphyrias) OR (Porphyrin Disorder) OR (Disorder, Porphyrin) OR (Disorders, Porphyrin) OR<br>(Porphyrin Disorders) OR (Porphyria)|
||#7         (Porphyrias, Hepatic) OR (Hepatic Porphyrias) OR (Porphyria, Hepatic) OR (Hepatic Porphyria)<br>OR (Acute Hepatic Porphyria) OR (Porphyria, Acute Hepatic) OR (ALAD Deficiency) OR (Delta-<br>Aminolevulinate Dehydratase Deficiency) OR (Porphobilinogen Synthase Deficiency) OR (Doss|
|Cochrane Library<br>(44)|Porphyria) OR (ALAD porphyria) OR (ALA dehydratase porphyria) OR (Ala Dehydratase Deficiency) OR<br>(Aminolevulinic acid dehydratase deficiency)<br>#8         (Coproporphyria, Hereditary) OR (Hereditary Coproporphyria) OR (Coproporphyrinogen Oxidase<br>Deficiency) OR (Deficiency, Coproporphyrinogen Oxidase)|
||#9         (Porphyria, Acute Intermittent) OR (Acute Intermittent Porphyria) OR (Acute Intermittent<br>Porphyrias) OR (Intermittent Porphyria, Acute) OR (Intermittent Porphyrias, Acute) OR (Porphyrias, Acute<br>Intermittent) OR (Acute Porphyria) OR (Acute Porphyrias) OR (Porphyria, Acute) OR (Porphyrias, Acute)<br>OR (Hydroxymethylbilane Synthase Deficiency) OR (Deficiencies, Hydroxymethylbilane Synthase) OR<br>(Deficiency, Hydroxymethylbilane Synthase) OR (Hydroxymethylbilane Synthase Deficiencies) OR<br>(Synthase Deficiencies, Hydroxymethylbilane) OR (Synthase Deficiency, Hydroxymethylbilane) OR<br>(Uroporphyrinogen Synthase Deficiency) OR (Deficiencies, Uroporphyrinogen Synthase) OR (Deficiency,<br>Uroporphyrinogen Synthase) OR (Synthase Deficiencies, Uroporphyrinogen) OR (Synthase Deficiency,|
||Uroporphyrinogen) OR (Uroporphyrinogen Synthase Deficiencies) OR (Porphyria, Swedish Type) OR|  
28  
|**Base de dados**|**Estratégia de busca**|
|---|---|
||(Porphyrias, Swedish Type) OR (Swedish Type Porphyria) OR (Swedish Type Porphyrias) OR (Type<br>Porphyria, Swedish) OR (Type Porphyrias, Swedish) OR (UPS Deficiency) OR (Deficiencies, UPS) OR<br>(Deficiency, UPS) OR (UPS Deficiencies) OR (PBGD Deficiency) OR (Deficiencies, PBGD) OR<br>(Deficiency, PBGD) OR (PBGD Deficiencies) OR (Porphobilinogen Deaminase Deficiency) OR<br>(Deaminase Deficiencies, Porphobilinogen) OR (Deaminase Deficiency, Porphobilinogen) OR<br>(Deficiencies, Porphobilinogen Deaminase) OR (Deficiency, Porphobilinogen Deaminase) OR<br>(Porphobilinogen Deaminase Deficiencies) OR (Porphyria, Acute Intermittent)<br>#10<br>(Porphyria, Variegate) OR (Variegate Porphyria) OR (Porphyria, South African Type) OR<br>(Ppox Deficiency) OR (Deficiency, Ppox) OR (Ppox Deficiencies) OR (Porphyria Variegata) OR<br>(Protoporphyrinogen Oxidase Deficiency) OR (Porphyria Variegate)<br>#11<br>MeSH descriptor: [Porphobilinogen] explode all trees<br>#12<br>(Porphobilinogen)<br>#13<br>MeSH descriptor: [Aminolevulinic Acid] explode all trees<br>#14<br>(Aminolevulinic Acid) OR (Acid, Aminolevulinic) OR (Delta Aminolevulinic Acid) OR<br>(Acid, Delta Aminolevulinic) OR (Levulan) OR (5 Aminolaevulinate) OR (5 Aminolevulinate) OR<br>(Aminolevulinic Acid Hydrochloride) OR (Acid Hydrochloride, Aminolevulinic) OR (Hydrochloride,<br>Aminolevulinic Acid)<br>#15<br>#1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10<br>#16<br>#11 OR #12 OR #13 OR #14<br>#17<br>#15 AND #16|
|Embase<br>(587)|('porphyria'/exp OR 'porphyrias or' OR 'hepatic porphyria'/exp OR 'hepatic porphyria' OR 'hepatic<br>porphyrias' OR 'hepatogenic porphyria' OR 'liver porphyria' OR 'porphyria hepatica' OR 'porphyria, hepatic'<br>OR 'porphyrias, hepatic' OR 'coproporphyria'/exp OR 'coproporphyria' OR 'coproporphyria, hereditary' OR<br>'hereditary coproporphyria' OR 'mckusick 12130' OR 'acute intermittent porphyria'/exp OR 'acute<br>intermittent porphyria' OR 'acute porphyria' OR 'porphobilinogen deaminase deficiency syndrome' OR<br>'porphyria, acute' OR 'porphyria, acute intermittent' OR 'porphyria variegata'/exp OR 'porphyria variegata'<br>OR 'porphyria, variegate' OR 'variegate porphyria') AND ('porphobilinogen'/exp OR 'porphobilinogen' OR<br>'aminolevulinic acid'/exp OR 'aminolevulinic acid' OR 'aminolevulinic acid' OR 'aminolevulinic acid' OR<br>'acid, aminolevulinic' OR 'delta-aminolevulinic acid' OR 'acid, delta-aminolevulinic' OR 'delta<br>aminolevulinic acid' OR 'levulan' OR '5-aminolaevulinate' OR '5 aminolaevulinate' OR '5-aminolevulinate'<br>OR '5 aminolevulinate' OR 'aminolevulinic acid hydrochloride' OR 'acid hydrochloride, aminolevulinic' OR<br>'hydrochloride, aminolevulinic acid') AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|
|Medline<br>(via Pubmed)<br>(1872)|(("Porphyrias"[Mesh]) OR (Porphyrin Disorder) OR (Disorder, Porphyrin) OR (Disorders, Porphyrin) OR<br>(Porphyrin Disorders) OR (Porphyria) OR (Porphyrias) OR ("Porphyrias, Hepatic"[Mesh]) OR (Hepatic<br>Porphyrias) OR (Porphyria, Hepatic) OR (Hepatic Porphyria) OR (Acute Hepatic Porphyria) OR<br>(Porphyrias, Hepatic) OR (Porphyria, Acute Hepatic [Supplementary Concept]) OR (ALAD Deficiency)|  
29  
|**Base de dados**|**Estratégia de busca**|
|---|---|
||OR (Delta-Aminolevulinate Dehydratase Deficiency) OR (Porphobilinogen Synthase Deficiency) OR (Doss<br>Porphyria) OR (ALAD porphyria) OR (ALA dehydratase porphyria) OR (Ala Dehydratase Deficiency) OR<br>(Aminolevulinic acid dehydratase deficiency) OR ("Coproporphyria, Hereditary"[Mesh]) OR (Hereditary<br>Coproporphyria) OR (Coproporphyrinogen Oxidase Deficiency) OR (Deficiency, Coproporphyrinogen<br>Oxidase) OR (Coproporphyria, Hereditary) OR ("Porphyria, Acute Intermittent"[Mesh]) OR (Acute<br>Intermittent Porphyria) OR (Acute Intermittent Porphyrias) OR (Intermittent Porphyria, Acute) OR<br>(Intermittent Porphyrias, Acute) OR (Porphyrias, Acute Intermittent) OR (Acute Porphyria) OR (Acute<br>Porphyrias) OR (Porphyria, Acute) OR (Porphyrias, Acute) OR (Hydroxymethylbilane Synthase<br>Deficiency) OR (Deficiencies, Hydroxymethylbilane Synthase) OR (Deficiency, Hydroxymethylbilane<br>Synthase) OR (Hydroxymethylbilane Synthase Deficiencies) OR (Synthase Deficiencies,<br>Hydroxymethylbilane) OR (Synthase Deficiency, Hydroxymethylbilane) OR (Uroporphyrinogen Synthase<br>Deficiency) OR (Deficiencies, Uroporphyrinogen Synthase) OR (Deficiency, Uroporphyrinogen Synthase)<br>OR (Synthase Deficiencies, Uroporphyrinogen) OR (Synthase Deficiency, Uroporphyrinogen) OR<br>(Uroporphyrinogen Synthase Deficiencies) OR (Porphyria, Swedish Type) OR (Porphyrias, Swedish Type)<br>OR (Swedish Type Porphyria) OR (Swedish Type Porphyrias) OR (Type Porphyria, Swedish) OR (Type<br>Porphyrias, Swedish) OR (UPS Deficiency) OR (Deficiencies, UPS) OR (Deficiency, UPS) OR (UPS<br>Deficiencies) OR (PBGD Deficiency) OR (Deficiencies, PBGD) OR (Deficiency, PBGD) OR (PBGD<br>Deficiencies) OR (Porphobilinogen Deaminase Deficiency) OR (Deaminase Deficiencies, Porphobilinogen)<br>OR (Deaminase Deficiency, Porphobilinogen) OR (Deficiencies, Porphobilinogen Deaminase) OR<br>(Deficiency, Porphobilinogen Deaminase) OR (Porphobilinogen Deaminase Deficiencies) OR (Porphyria,<br>Acute Intermittent) OR ("Porphyria, Variegate"[Mesh]) OR (Variegate Porphyria) OR (Porphyria, South<br>African Type) OR (Ppox Deficiency) OR (Deficiency, Ppox) OR (Ppox Deficiencies) OR (Porphyria<br>Variegata) OR (Protoporphyrinogen Oxidase Deficiency) OR (Porphyria Variegate) OR (Porphyria,<br>Variegate)) AND ((“Porphobilinogen”[Mesh]) OR (Porphobilinogen) OR (“Aminolevulinic Acid”[Mesh])<br>OR (Aminolevulinic Acid) OR (Acid, Aminolevulinic) OR (Delta-Aminolevulinic Acid) OR (Acid, Delta-<br>Aminolevulinic) OR (Delta Aminolevulinic Acid) OR (Levulan) OR (5-Aminolaevulinate) OR (5<br>Aminolaevulinate) OR (5-Aminolevulinate) OR (5 Aminolevulinate) OR (Aminolevulinic Acid<br>Hydrochloride) OR (Acid Hydrochloride, Aminolevulinic) OR (Hydrochloride, Aminolevulinic Acid))|
|Bases via BVS|(((mh:("Porfirias") OR (porfirias) OR (porphyrias) OR (porphyrin disorder) OR (disorder, porphyrin) OR<br>(disorders, porphyrin) OR (porphyrin disorders) OR (porphyria)) OR (mh:("PorfiriasHepáticas") OR|
|LILACS (68)<br>IBECS (37)<br>BINACIS (17)<br>BRISA/<br>RedETSA (2)|(porfiriashepáticas) OR (porfiriahepática) OR (porphyrias, hepatic) OR (hepatic porphyrias) OR (porphyria,<br>hepatic) OR (hepatic porphyria) OR (acute hepatic porphyria) OR (porphyria, acute hepatic) OR (alad<br>deficiency) OR (delta-aminolevulinate dehydratase deficiency) OR (porphobilinogen synthase deficiency)<br>OR (doss porphyria) OR (alad porphyria) OR (ala dehydratase porphyria) OR (ala dehydratase deficiency)<br>OR (aminolevulinic acid dehydratase deficiency)) OR (mh:("CoproporfiriaHereditária") OR|
|CUMED<br>(2)|(coproporfiriahereditária) OR (coproporphyria, hereditary) OR (coproporfiriahereditaria) OR (hereditary<br>coproporphyria) OR (coproporphyrinogen oxidase deficiency) OR (deficiency, coproporphyrinogen|  
30  
|**Base de dados**|**Estratégia de busca**|
|---|---|
|MedCaribe (2)|oxidase)) OR (mh:("PorfiriaAgudaIntermitente") OR (porfiriaagudaintermitente) OR (porphyria, acute|
|Sec. Est. Saúde|intermittent) OR (porfiriaintermitenteaguda) OR (deficiência de hidroximetilbilanosintase) OR (deficiência|
|(2)|de uroporfirinogêniosintase) OR (acute intermittent porphyria) OR (acute intermittent porphyrias) OR<br>(intermittent porphyria, acute) OR (intermittent porphyrias, acute) OR (porphyrias, acute intermittent) OR<br>(acute porphyria) OR (acute porphyrias) OR (porphyria, acute) OR (porphyrias, acute) OR<br>(hydroxymethylbilane synthase deficiency) OR (deficiencies, hydroxymethylbilane synthase) OR<br>(deficiency, hydroxymethylbilane synthase) OR (hydroxymethylbilane synthase deficiencies) OR (synthase<br>deficiencies, hydroxymethylbilane) OR (synthase deficiency, hydroxymethylbilane) OR (uroporphyrinogen<br>synthase deficiency) OR (deficiencies, uroporphyrinogen synthase) OR (deficiency, uroporphyrinogen<br>synthase) OR (synthase deficiencies, uroporphyrinogen) OR (synthase deficiency, uroporphyrinogen) OR<br>(uroporphyrinogen synthase deficiencies) OR (porphyria, swedish type) OR (porphyrias, swedish type) OR<br>(swedish type porphyria) OR (swedish type porphyrias) OR (type porphyria, swedish) OR (type porphyrias,<br>swedish) OR (ups deficiency) OR (deficiencies, ups) OR (deficiency, ups) OR (ups deficiencies) OR (pbgd<br>deficiency) OR (deficiencies, pbgd) OR (deficiency, pbgd) OR (pbgd deficiencies) OR (porphobilinogen<br>deaminase deficiency) OR (deaminase deficiencies, porphobilinogen) OR (deaminase deficiency,<br>porphobilinogen) OR (deficiencies, porphobilinogen deaminase) OR (deficiency, porphobilinogen<br>deaminase) OR (porphobilinogen deaminase deficiencies)) OR (mh:("PorfiriaVariegada") OR<br>(porfiriavariegada) OR (porphyria, variegate) OR (porfiriavariegata) OR (porfiriatiposul-africana) OR<br>(porfiriavariegata) OR (variegate porphyria) OR (porphyria, south african type) OR (ppox deficiency) OR<br>(deficiency, ppox) OR (ppox deficiencies) OR (porphyria variegata) OR (protoporphyrinogen oxidase<br>deficiency) OR (porphyria variegate) OR (porphyria, variegate))) AND ((mh:("Porphobilinogen") OR<br>(porphobilinogen)) OR (mh:("Aminolevulinic Acid") OR (aminolevulinic acid) OR (acid, aminolevulinic)<br>OR (delta-aminolevulinic acid) OR (acid, delta-aminolevulinic) OR (delta aminolevulinic acid) OR<br>(levulan) OR (5-aminolaevulinate) OR (5 aminolaevulinate) OR (5-aminolevulinate) OR (5<br>aminolevulinate) OR (aminolevulinic acid hydrochloride) OR (acid hydrochloride, aminolevulinic) OR<br>(hydrochloride, aminolevulinic acid)))|  
Fonte: autoria própria.  
A elegibilidade dos estudos identificados foi realizada em duas etapas por dois revisores independentes e as discrepâncias, quando necessário, foram resolvidas por um terceiro revisor. A primeira etapa consistiu na avaliação por título e resumo de cada estudo, utilizando a plataforma Rayyan QCRI®<sup>1</sup> . Na segunda etapa, realizou-se a leitura de texto completo, mantendo-se estudos transversais de teste diagnóstico e outros observacionais (exceto séries e relatos de casos), desde que apresentassem comparação de uma técnica quantitativa à outra qualitativa, em pacientes e/ou amostras de urina com diagnóstico confirmado ou suspeito de porfiria hepática aguda.  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Pacientes e/ou amostras de urina com diagnóstico confirmado ou suspeito de porfiria hepática aguda.  
31

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Dosagem de PBG urinário (dPBGu) – análise quantitativa (teste índice).

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Estudos transversais de teste diagnóstico e outros observacionais (exceto séries e relatos de casos).

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Sensibilidade (verdadeiros positivos); Especificidade (verdadeiros negativos); Razão de verossimilhança; Valores  
preditivos positivos e negativos.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Inglês, português ou espanhol.  
Foram identificados inicialmente 2.633 registros. Após a exclusão das duplicatas (n=140) e triagem pela leitura de títulos e resumos, 63 publicações foram selecionadas para a leitura do texto completo, sendo incluídas quatro publicações. Uma publicação não foi encontrada. A Figura A, adaptada do modelo de fluxograma disponibilizado pela plataforma PRISMA<sup>2</sup> , esquematiza o processo de seleção das evidências científicas.  
**Figura A.** Fluxograma de seleção dos estudos incluídos. <mark>*Mital RN, Gautam A. Porphyria. J Assoc Physicians India. 1984;32(3):294-5.</mark>  
<!-- Start of picture text -->
Referéncias identificadas em:<br>Bases de dados (n=2.633)<br>PubMed (n=1.872)<br>Embase (n=587)<br>3 Cochrane Library (n=44) Referéncias removidas antes do<br>LILACS (via BVS) (n=68) processo de sele¢do:<br>IBECS (via BVS) (n=37) Duplicatas retirada automaticas<br>BINACIS (via BVS) (n=17) por Mendeley (n=140)<br>BRISA— RedETSA (via BVS) (n=2)<br>CUMED (n=2)<br>MedCaribe (n=2)<br>Sec.Est.Satide (n=2)<br>aid avaliadas por titulo e ediasiiewlencendlidlilen<br>(n=2.493) (ne2i50)<br>Referéncias incluidas para avaliacao Referéncias cujo texto completo<br>por texto completo néo foi identificado<br>(n=63) (n=1)*<br>Referéncias avaliadas por texto<br>completo Referéncias excluidas (n=58)<br>(n=62)<br>Estudos incluidos na revisio<br>(n=4)<br><!-- End of picture text -->  
Fonte: autoria própria.  
32

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Na avaliação do risco de viés, foi utilizada a segunda versão da ferramenta _Quality Assessment of Diagnostic Accuracy Studies (QUADAS-2)_<sup>3</sup> , elaborada pela _University of Bristol_ . Para representação da análise, foi utilizado o gráfico de “semáforo” gerado pelo _software Review Manager_ (RevMan) V.5.4.1 da Cochrane<sup>4</sup> . Considerando os desfechos de interesse avaliados (sensibilidade e especificidade), os estudos transversais de teste diagnóstico apresentaram preocupações na avaliação do risco de viés (alto risco de viés), principalmente por problemas relacionados ao tamanho da amostra, falta de relato sobre cegamento para interpretação dos resultados dos testes e intervalo de tempo entre as análises, ausência de mensuração adequada das medidas de desempenho e dados de análise estatística incompletos. A avaliação completa do risco de viés é apresentada na Figura B.  
**Figura B.** Avaliação do risco de viés dos estudos de teste diagnóstico sobre dosagem de porfobilinogênio urinário para diagnóstico ou prognóstico de porfirias hepáticas agudas  
<!-- Start of picture text -->
Preocupacées com<br>Risco de Viés Aplicabilidade<br>2ro 83<br>Ss <<br>g && g ss<br>525<br>3© 3 o<br>é Sg é 8<br>zouoé 3gs SFww EE cb4é 3®gs 8<br>ge £ &€ @ ge«e<br>oS 2 2 9 oS @ @<br>3s 3 3 5 3 3B<br>a £ ££ = a £<br>conn»oun [elec  le[@] elale<br>rox2001 [alo|@/@|@/@|lele] lelele|elele|<br>Schreiber,| 1989 @ a<br>@ Alto ?) Incerto @ Baixo<br><!-- End of picture text -->  
**a.** Foi avaliada amostra de apenas um paciente com porfiria, além de não relatar sobre os critérios de inclusão/exclusão de amostras no estudo. **b.** Não há clareza se os resultados do teste índice foram interpretados sem o conhecimento dos resultados do teste padrão de referência, o que é importante porque a proposta do estudo foi trazer uma modificação de um teste quantitativo para ser utilizado como qualitativo. **c.** Critérios de inclusão/exclusão de amostras/pacientes no estudo não foram relatados e as amostras foram anormalmente pigmentadas nas análises. **d.** Metade das amostras foi testada utilizando o kit Trace (semi-quantitativo) e a outra pelo método Watson-Schwartz (qualitativo), portanto nem todas as amostras foram incluídas em todas as análises. **e.** Foram avaliadas somente amostras de dois pacientes com porfiria, além de não relatar os critérios de inclusão/exclusão. **f.** Não há clareza se todas as amostras foram incluídas em todas as análises, além de não relatar intervalo entre os testes. **g.** A proposta do estudo foi avaliar um teste em desenvolvimento. Fonte: autoria própria a partir do _software Review Manager_ (RevMan) V.5.4.1<sup>4</sup> .  
Nenhum estudo relatou curva ROC ou tabela de contingência 2x2 na apresentação dos resultados. Apesar disso, considerando o estudo de Deacon (1998)<sup>5</sup> , foi possível extrair os dados e calcular a sensibilidade e especificidade dos testes. Não foi possível realizar meta-análise ou qualquer outro tipo de análise estatística para sintetizar os resultados dos estudos  
33  
identificados devido à divergência na apresentação dos dados e limitação na mensuração e no relato dos desfechos. Os resultados foram descritos de acordo com as características do teste diagnóstico avaliadas e os desfechos de interesse da pergunta de pesquisa.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
No total, foram incluídos quatro estudos de teste diagnóstico, todos avaliando a acurácia diagnóstica do teste índice dPBGu. Para a dPBGu, a sensibilidade e a especificidade encontradas foram de 95,3% (IC 95% 91,6% a 99,0%) e 81,3% (IC 95% 73,3% a 89,3%), respectivamente. Para a pPBGu, a sensibilidade relatada foi de 37,8% (IC 95% 29,1% a 46,5%) e a especificidade, de 77,4% (IC 95% 68,8% a 86,0%). Não foi possível a condução de meta-análise ou qualquer outro tipo de análise estatística para sintetizar os resultados dos estudos identificados devido à divergência na apresentação dos dados e limitação na mensuração e no relato dos desfechos. Além disso, considerando os desfechos de interesse avaliados (sensibilidade e especificidade), os estudos transversais de teste diagnóstico apresentaram alto risco de viés, principalmente por problemas relacionados ao tamanho da amostra, falta de cegamento na interpretação dos resultados, ausência no relato do intervalo de tempo entre as análises dos testes e dados de análise estatística incompletos.  
Contudo, houve consenso entre os estudos que o diagnóstico de porfirias não é totalmente conclusivo apenas com testes qualitativos para PBG urinário (pPBGu), porque estes apresentam recorrentes falso-positivos ou falso-negativos. Entende-se, portanto, a necessidade de complementar a análise do diagnóstico a partir da dosagem desse parâmetro pela melhor sensibilidade e especificidade que esse método oferece. O Quadro C apresenta as principais características dos estudos incluídos.

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
A qualidade geral da evidência foi avaliada utilizando o sistema da abordagem GRADE<sup>2,9,10</sup> . Os Quadros D e E apresentam os resultados da avaliação da certeza da evidência para os desfechos sensibilidade e especificidade.  
34  
**Quadro C.** Características dos estudos incluídos  
|**Estudo**|**Delineamento**|**Objetivo**|**População e cenário**<br>**(tamanho da amostra)**|**Técnica utilizada na**<br>**dosagem de PBG**<br>**urinário (teste índice)**|**Técnica utilizada como**<br>**teste qualitativo de PBG**<br>**urinário (teste padrão de**<br>**referência)**|**Desfechos**<br>**avaliados**|
|---|---|---|---|---|---|---|
|**Castrow**<br>**(1970)**<sup>**6**</sup>|Estudo de Teste<br>Diagnóstico|Descrever uma modificação qualitativa de<br>um teste quantitativo para PBG.|**População:**uma amostra<br>de urina de um paciente<br>com porfiria hepática<br>aguda<br>**Cenário:**Laboratorial|Coluna preenchida com<br>resina de troca aniônica<br>(Dowex 1-X8)<br>Mauzerall e Granick<br>(coluna de troca iônica)<br>(controle)|Watson-Schwartz|Sensibilidade|
|||Comparar método semi-quantitativo com o|**População:**520 amostras|Kit Trace de PBG (semi-<br>quantitativo)|||
|**Deacon**<br>**(1998)**<sup>**5**</sup>|Estudo de Teste<br>Diagnóstico|método de triagem qualitativo, utilizando<br>outro método quantitativo como padrão<br>referência.|de urina de pacientes com<br>PAI<br>**Cenário:**Laboratorial|Mauzerall e Granick<br>(coluna de troca iônica)<br>(controle)|Watson-Schwartz|Sensibilidade<br>Especificidade|
|**Ford**<br>**(2001)**<sup>**7**</sup>|Estudo de Teste<br>Diagnóstico|Desenvolver método alternativo para<br>análise de PBG que se utiliza<br>cromatografia líquida acoplada à<br>espectrometria de massas e diluição de<br>isótopos estáveis (sem derivatização).|**População:**246 amostras<br>de 11 pacientes com<br>porfiria hepática aguda<br>**Cenário:**Laboratorial|Cromatografia Líquida<br>Acoplada à<br>Espectrometria de Massas<br>Mauzerall e Granick<br>(coluna de troca aniônica)<br>(controle)|Watson-Schwartz|Sensibilidade<br>Especificidade|  
35  
|**Estudo**|**Delineamento**|**Objetivo**|**População e cenário**<br>**(tamanho da amostra)**|**Técnica utilizada na**<br>**dosagem de PBG**<br>**urinário (teste índice)**|**Técnica utilizada como**<br>**teste qualitativo de PBG**<br>**urinário (teste padrão de**<br>**referência)**|**Desfechos**<br>**avaliados**|
|---|---|---|---|---|---|---|
|**Schreiber**<br>**(1989)**<sup>**8**</sup>|Estudo de Teste<br>Diagnóstico|Desenvolver método de triagem com nova<br>resina de troca iônica para separação de<br>PBG e estabelecer critérios<br>espectrofotométricos objetivos para<br>diferenciar resultados positivos e negativos<br>e aumentar a sensibilidade.|**População:**duas<br>amostras de urina de duas<br>mulheres com PAI<br>**Cenário:**Laboratorial|Mauzerall e Granick<br>(coluna de troca iônica)|Watson-Schwartz|Sensibilidade|  
PAI: porfiria aguda intermitente; PBG: porfobilinogênio.  
Fonte: autoria própria.  
36  
**Quadro D.** Certeza do conjunto de evidências a partir do sistema da abordagem GRADE para o desfecho de sensibilidade  
|||**Avaliaçã**|**o da certeza das evi**|**dências**|||**Sumário de R**|**esultados**|
|---|---|---|---|---|---|---|---|---|
|**Estudos**|||**Evidência**||**Viés de**|**Certeza geral**|||
|**(amostras)**|**Risco de viés**|**Inconsistência**|**indireta**|**Imprecisão**|**publicação**|<br>**de evidência**|**Impacto**|**Importância**|
||||**Sensi**|**bilidade**|||||
|4 estudos|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|⨁⨁◯◯|Todos os estudos|CRÍTICO|
|transversais de<br>teste<br>diagnóstico<br>(n=769)<sup>5-8</sup>||||||BAIXA|foram favoráveis ao<br>uso de testes<br>quantitativos por<br>considerá-los mais<br>sensíveis aos<br>qualitativos. Os<br>resultados indicaram<br>que, idealmente, as<br>amostras de urina<br>devem ser<br>quantificadas para<br>PBG urinário a fim<br>de se obter<br>confirmação<br>diagnóstica de<br>pacientes com<br>porfirias. O estudo de<br>Castrow (1970)<br>comentou também<br>que a dosagem||  
37  
|**Avaliação da certeza das evidências**|**Sumário de Resultados**|
|---|---|
||permite identificar o<br>estágio da doença nos<br>pacientes e que os<br>testes qualitativos<br>têm interferências nas<br>análises. Os outros<br>estudos mostraram<br>maior proporção de<br>casos positivos<br>detectados pelos<br>testes quantitativos<br>em relação aos<br>qualitativos quando<br>analisadas amostras<br>sabidamente com<br>níveis altos de PBG<br>urinário e/ou de<br>pacientes com<br>porfirias.<br>De acordo com o<br>estudo Deacon<br>(1998), a<br>sensibilidade da<br>dPBGu é maior<br>quando comparada à|  
38  
|**Avaliação da certeza das evidências**|**Sumário de Resultados**|
|---|---|
||pPBGu, 95,3%<br>_versus_37,8%.|  
**a.** Dois estudos tinham ausência de informações sobre critérios de inclusão/exclusão e a maioria dos estudos não deixa claro se as análises do teste índice foram realizadas com conhecimento dos resultados do teste padrão de referência.  
**b.** Os estudos não realizaram análises para estabelecer uma comparação concreta entre os resultados para os testes analisados, sendo realizada apenas por relato descritivo e/ou observação dos dados obtidos. Ainda, dois estudos tinham o objetivo de desenvolver novo teste diagnóstico (o que implicou em apresentar dados para o desfecho de forma secundária), enquanto o outro não incluiu todas as amostras em todas as análises. Fonte: autoria própria.  
39  
**Quadro E.** Certeza do conjunto de evidências a partir do sistema da abordagem GRADE para o desfecho de especificidade  
|||**Avalia**|**ção da certeza das e**|**vidências**|||**Sumário de**|**Resultados**|
|---|---|---|---|---|---|---|---|---|
|**Estudos**<br>**(amostras)**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés de**<br>**publicação**|**Certeza geral**<br>**de evidência**|**Impacto**|**Importância**|
|**Especificidade**|||||||||
|2 estudos<br>transversais de|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|⨁⨁◯◯<br>BAIXA|Ambos os estudos<br>apresentaram que os|CRÍTICO|
|teste|||||||testes<br>quantitativos||
|diagnóstico|||||||possuem<br>maior||
|(n=766)<sup>5,7</sup>|||||||especificidade<br>em<br>relação<br>aos<br>qualitativos,<br>identificando melhor<br>os casos negativos,<br>embora Ford (2001)<br>tenha indicado que o<br>qualitativo||
||||||||apresentou<br>4,4%<br>resultados<br>positivos||
||||||||quando eram para ser<br>negativos, enquanto<br>9,4% para o teste<br>analisado<br>que<br>não||
||||||||estava<br>sendo<br>desenvolvido.||  
40  
|**Avaliação da certeza das evidências**|**Sumário de Resultados**|
|---|---|
||De acordo com o<br>estudo<br>Deacon|
||(1998),<br>a|
||especificidade<br>da|
||dPBGu<br>é<br>maior<br>quando comparada à<br>pPBGu, 81,3%_versus_<br>77,4%.|  
**a.** Um dos estudos<sup>5</sup> , apesar do bom tamanho amostral, apresentou problemas referentes à seleção das amostras e do fluxo e tempo, pois os testes foram aplicados separadamente sem relato do intervalo entre eles. **b.** Um dos estudos<sup>7</sup> tinha  
o objetivo de desenvolver novo teste diagnóstico (o que implicou em apresentar dados para o desfecho de forma secundária) e indicou que apenas o teste quantitativo desenvolvido tinha melhor especificidade que o qualitativo (isso não foi verificado para o outro teste quantitativo utilizado nas análises). O outro estudo<sup>5</sup> , por sua vez, não incluiu todas as amostras nas análises.  
Fonte: autoria própria.  
41

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
1. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan — a web and mobile app for systematic reviews.  
Systematic reviews. 2016;5:210.  
2. Schünemann H, Brożek J, Guyatt G, Oxman A, 2013. The GRADE Handbook. Disponível em:  
https://training.cochrane.org/resource/grade-handbook.  
3. University of Bristol, 2022. Quality Assessment of Diagnostic Accuracy Studies (QUADAS-2). Disponível em:  
https://www.bristol.ac.uk/population-health-sciences/projects/quadas/quadas-2/.  
4. The Cochrane Collaboration, 2022. Software RevMan (Review Manager) Disponível em:  
https://training.cochrane.org/online-learning/core-software-cochrane-reviews/revman.  
5. Deacon AC, Peters TJ. Identification of acute porphyria: evaluation of a commercial screening test for urinary  
porphobilinogen. Annals of clinical biochemistry. 1998;35:720-732.  
6. Castrow FF. New urinary porphobilinogen screening test: modified Mauzerall-Granick test. Southern medical  
journal. 1970;63(5).  
7. Ford RE, Magera MJ, Kloke KM, Chezick PA, Fauq A, McConnell JP. Quantitative measurement of  
porphobilinogen in urine by stable-isotope dilution liquid chromatography-tandem mass spectrometry. Clinical chemistry. 2001;47(9).  
8. Schreiber WE, Jamani A, Pudek MR. Screening tests for porphobilinogen are insensitive. The problem and its  
solution. American journal of clinical pathology. 1989;92(5).  
9. Ministério da Saúde, Tecnologia e Insumos Estratégicos Secretaria de Ciência, Departamento de Ciência e  
Tecnologia, 2014. Diretrizes Metodológicas - Sistema GRADE - Manual de Graduação da Qualidade da Evidência e Força de Recomendação para Tomada de Decisão em Saúde. Disponível em: .  
10. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus  
on rating quality of evidence and strength of recommendations. BMJ. 2008;336(7650):924-926.  
42

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
Esta lista representa uma relação de medicamentos seguros para pacientes com porfirias agudas, de acordo com a literatura científica. Ressalta-se que a presença de um mecicamento na lista não está relacionada à sua disponibilidade ou indicação no Sistema Único de Saúde.  
|**Medicamentos s**|**eguros e opções terapêuticas para o tratamento de pacientes com porfiria hepática aguda****|
|---|---|
|**Anestésicos**|Anestesia geral: Isoflurano, Propofol, Sevoflurano; Uso local: Bupivacaína, Prilocaína,<br>Tetracaína; Bloqueadores neuromusculares: Pancurônio, Succinilcolina, Vecurônio.|
|**Agentes**<br>**antineoplásicos**|Iodo radioativo (I-131), Asparaginase, Bleomicina, Carboplatina, Cisplatina, Citarabina,<br>Doxorrubicina, Fludarabina, Tioguanina.|
|**Agentes**<br>**antimicrobianos**|Aminoglicosídeos (Amicacina, Gentamicina, Estreptomicina, Tobramicina); Agentes antifúngicos<br>(Anfotericina B, Caspofungina, Nistatina); Antimaláricos (Cloroquina, Mefloquina, Primaquina,<br>Pirimetamina); Agentes antimicobacterianos (Etambutol); Medicamentos antirretrovirais<br>(Abacavir); Antivirais (Aciclovir, Fanciclovir, Ganciclovir, Ribavirina, Valaciclovir,<br>Valganciclovir, Zanamivir); Carbapenêmicos (Meropenem); Cefalosporinas (Cefaclor, Cefazolina,<br>Cefepima, Cefoxitina, Ceftazidima, Ceftriaxona, Cefuroxima, Cefalexina); Fluoroquinolonas<br>(Ciprofloxacino); Penicilinas (Amoxicilina, Amoxicilina/Clavulanato, Ampicilina, Penicilina,<br>Ticarcilina); Vancomicina.|
|**Terapias**<br>**cardiovasculares**|Medicamentos anti-hipertensivos (Benazepril, Captopril, Enalapril, Lisinopril, Ramipril;<br>Candesartana, Losartana, Olmesartana, Valsartana, Irbesartana, Telmisartana), Medicamentos<br>hipolipemiantes (Colestiramina, Ezetimiba, Rosuvastatina), Betabloqueadores (Atenolol,<br>Carvedilol, Esmolol, Metoprolol, Propranolol, Sotalol, Timolol), Diuréticos (Acetazolamida,<br>Furosemida); Medicamentos antiarrítmicos (Adenosina, Digoxina), Dinitrato de isossorbida,<br>Diazóxido, Vasopressores (Dobutamina, Dopamina, Efedrina).|
|**Tratamento**<br>**hematológico**|Anticoagulantes (Heparina não fracionada, Dabigatrana, Enoxaparina, Protamina, Varfarina),<br>Agentes hemostáticos (Ácido aminocapróico); Enzimas trombolíticas (Alteplase, Tenecteplase);<br>ácido tranexâmico, Clopidogrel, Hidroxietilamido para reposição plasmática, Filgrastim,<br>Alfaepoetina, Cianocobalamina.|
|**Terapia hormonal**|Corticosteroides (Betametasona, Fludrocortisona, Hidrocortisona, Prednisona, Triancinolona),<br>Estrogênios conjugados, Agonistas de LHRH / GnRH (Gosserelina), Estimulantes de ovulação<br>(Clomifeno), Hormônios hipofisários (vasopressina/desmopressina, menotropina,<br>metilergometrina, ocitocina, urofolitropina), gonadotropina coriônica, terapias para tireoide<br>(levotiroxina, propiltiouracila), octreotida, calcitonina.|  
43  
|**Medicamentos se**|**guros e opções terapêuticas para o tratamento de pacientes com porfiria hepática aguda****|
|---|---|
|**Imunoterapia e**<br>**vacinas**|Abatacepte, Adalimumabe, Belimumabe, Certolizumabe, Denosumabe, Etanercepte,<br>Golimumabe, Infliximabe, Natalizumabe, Rituximabe; Interferon Alfa 2A ou 2B; Vacinas<br>antimicrobianas: influenza, hepatite A e B, Sarampo, Caxumba, Rubéola, Pneumocócica,<br>Poliomelite, Varicela; toxoides (Difteria, Tétano, Coqueluche); Antivenenos**; Azatioprina**.|
|**Medicamentos**<br>**gastrointestinais**|Antagonistas do receptor H2 (Cimetidina, Ranitidina), Antieméticos (Meclozina, Ondansetrona),<br>Bisacodil, Esomeprazol, Omeprazol, Pantoprazol, Escopolamina, Atropina, Loperamida, Senna.|
|**Medicamentos**<br>**neuropsiquiátricos**|Antidepressivos (Amitriptilina, Citalopram, Fluoxetina, Mirtazapina), Medicamentos<br>antiepilépticos (Gabapentina, Levetiracetam, Pregabalina, Vigabatrina), Agentes antimiastênicos<br>(Neostigmina, Piridostigmina), Medicamentos antiparkinsonianos (Amantadina, Entacapona,<br>Levodopa/carbidopa, Pramipexol), Benzodiazepínicos (Clobazam, Lorazepam – cautela,<br>especialmente no uso prolongado), Hipnóticos (Zolpidem), Neurolépticos e outros<br>(Clorpromazina, Clozapina, Flufenazina, Haloperidol, Lítio, Tioridazina), Tróspio, Baclofeno.|
|**Terapia para dor**|Antiinflamatórios não esteroides (Ácido acetilsalicílico, Ibuprofeno, Indometacina, Cetoprofeno,<br>Naproxeno), Narcóticos (Alfentanila, Buprenorfina, Codeína, Petidina, Metadona, Morfina,<br>Nalbufina, Oxicodona); Drogas antiepilépticas.|
|**Agentes**<br>**respiratórios**|Acetilcisteína, Salbutamol, Beclometasona, Budesonida, Cetirizina, Dextrometorfano,<br>Difenidramina, Fexofenadina, Fluticasona, Guaifenesina, Ipratrópio, Levocetirizina, Loratadina,<br>Prometazina, Montelucaste, Fenilefrina, Pseudoefedrina, Terbutalina.|
|**Diversos**|Medicamentos antidiabéticos (Metformina, Insulina), Alopurinol, Colchicina, Penicilamina;<br>Alendronato, Ácido zoledrônico; Agentes de contraste (Gadopentetato, Iodixanol, Ioexol,<br>Iopromida), Gadobutrol; Doxazosina, Finasterida; Naloxona.|  
**Os resultados da avaliação de segurança de medicamentos baseada em evidências variam entre centros, fundações (por exemplo, ABRAPO) e opiniões de especialistas, e são frequentemente atualizados de acordo com novas evidências experimentais e clínicas. Todos os medicamentos e opções terapêuticas citados têm o seu próprio risco de eventos adversos e o seu próprio potencial de indução porfirinogênica.  
Medicamentos de uso tópico são considerados seguros e podem ser usados em membranas mucosas e pele sem comprometimento da integridade.  
Não consta na lista os medicamentos que não possuem registro na Agência Nacional de Vigilância Sanitária (Anvisa).  
Fonte: Adaptado de _United Kingdom Porphyria Medicines Information Service_ (UKPMIS), _Cardiff Porphyria Service_ e _National Acute Porphyria Service_ (NAPS) (2024), _American Porphyria Foundation_ (2024) e Souza _et al_ . (2021)<sup>1-3</sup> .

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
1. Souza PVS, Badia BML, Farias IB, Goncalves EA, Pinto WBVR, Oliveira ASB. Acute hepatic porphyrias for the neurologist: current concepts and perspectives. Arquivos de Neuropsiquiatria. 2021;79(1):68-80.  
2. UK Porphyria Medicines Information Service (UKPMIS), Cardiff Porphyria Service, National Acute Porphyria Service (NAPS), 2024. LISTA SEGURA 2024: Medicamentos considerados SEGUROS para uso nas porfirias agudas.  
44  
Disponível em: https://www.wmic.wales.nhs.uk/wp-content/uploads/2024/07/Safe-list-Alphabetical-green-May-24FINAL.pdf.  
3. American Porphyria Foundation, 2024. Banco de dados de medicamentos. Disponível em: https://porphyriafoundation.org/drugdatabase/.  
45  
**APÊNDICE 3**

---

<!-- METADADOS: doenca: Porfirias | secao: **3.1     Diagnóstico clínico e laboratorial** -->
|**Número do Relatório**||**Tecnologias av**|**aliadas pela Conitec**|
|---|---|---|---|
|**da diretriz clínica**<br>**(Conitec) ou Portaria**<br>**de Publicação**|**Principais**<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não alteração no**<br>**SUS**|
|Relatório de<br>Recomendação nº<br>958/2024|Primeira versão<br>do Protocolo|Dosagem de porfobilinogênio<br>urinário para confirmação<br>diagnóstica ou prognóstico de<br>porfirias hepáticas agudas<br>[Relatório de Recomendação nº<br>889/2024, Portaria SECTICS/MS nº<br>17/2024]|Givosirana para o tratamento de<br>pacientes adultos com porfirias hepáticas<br>agudas [Relatório de Recomendação nº<br>639/2021, Portaria SCTIE/MS nº<br>38/2021]<br>Hemina para o tratamento de mulheres<br>com ataques de porfiria aguda<br>intermitente relacionados com o ciclo<br>menstrual [Relatório de Recomendação<br>nº 771/2022, Portaria SCTIE/MS nº<br>110/2022]|  
46

---

