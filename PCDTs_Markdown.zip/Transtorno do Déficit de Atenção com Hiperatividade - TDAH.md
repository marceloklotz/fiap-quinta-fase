<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 14, de 29 de JULHO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Transtorno do Déficit de Atenção com Hiperatividade.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre o Transtorno do Déficit de Atenção com Hiperatividade no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 718/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 722 – Maio de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Transtorno do Déficit de Atenção com Hiperatividade.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Transtorno do Déficit de Atenção com Hiperatividade, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de</u> caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Transtorno do Déficit de Atenção com Hiperatividade.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
MAÍRA BATISTA BOTELHO  
SANDRA DE CASTRO BARROS  
ANEXO

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **1. INTRODUÇÃO** -->
De acordo com o Manual Diagnóstico e Estatístico de Transtornos Mentais, quinta edição (DSM-5)<sup>1</sup> , da Associação Americana de Psiquiatria (APA), o Transtorno do Déficit de Atenção com Hiperatividade (TDAH) é considerado uma condição do neurodesenvolvimento, caracterizada por uma tríade de sintomas envolvendo desatenção, hiperatividade e impulsividade em um nível exacerbado e disfuncional para a idade<sup>2–4</sup> . Os sintomas iniciam-se na infância, podendo persistir ao longo de toda a vida.  
A prevalência mundial de TDAH estimada em crianças e adolescentes é de 3% a 8%<sup>5–9</sup> , dependendo do sistema de classificação utilizado. Embora o TDAH seja frequentemente diagnosticado durante a infância, não é raro o diagnóstico ser feito posteriormente. As evidências científicas sustentam sua continuidade na idade adulta, com uma prevalência estimada entre 2,5% a 3%<sup>10–12</sup> . No Brasil, a prevalência de TDAH é estimada em 7,6% em crianças e adolescentes com idade entre 6 e 17 anos, 5,2% nos indivíduos entre 18 e 44 anos e 6,1% nos indivíduos maiores de 44 anos apresentando sintomas de TDAH<sup>9-13</sup> .  
Os sintomas e o comprometimento do TDAH são frequentemente graves durante a infância e podem evoluir ao longo da vida<sup>14,15</sup> . Por se tratar de um transtorno de neurodesenvolvimento, as dificuldades muitas vezes só se tornam evidentes a partir do momento em que as responsabilidades e independência se tornam maiores, como quando a criança começa a ser avaliada no contexto escolar ou quando precisa se organizar para alguma atividade ou tarefa sem a supervisão dos pais<sup>9</sup> . Os indivíduos com TDAH também apresentam dificuldades nos domínios das funções cognitivas, como resolução de problemas, planejamento, orientação, flexibilidade, atenção prolongada, inibição de resposta e memória de trabalho<sup>16–18</sup> . Outras dificuldades envolvem componentes afetivos, como atraso na motivação e regulação do humor<sup>2,16</sup> .  
Em médio e longo prazo, crianças e adolescentes com TDAH podem apresentar dificuldades no desempenho acadêmico, nas interações interpessoais e autoestima baixa. Crianças com TDAH têm mais chances de apresentar obesidade quando comparadas com as crianças sem TDAH<sup>19</sup> . Problemas de conduta podem aparecer no final do período da pré-adolescência<sup>4,20,21</sup> . Além disso, pessoas com TDAH podem apresentar comportamentos sexuais de alto risco e gravidez precoce indesejada<sup>22</sup> , dificuldades no trabalho, abuso de drogas ou álcool, maior probabilidade a acidentes<sup>23</sup> , e criminalidade na fase adulta<sup>24,25</sup> . O TDAH também está associado a resultados psicológicos negativos, com um maior risco de desenvolver transtornos do humor (unipolar ou bipolar), distúrbios de personalidade, especialmente, transtorno de personalidade _borderline_ e antissocial<sup>7,11,14,26</sup> , e possivelmente condições psicóticas<sup>27</sup> .  
Apesar de ter se tornado uma condição bastante conhecida nos últimos anos, o diagnóstico de TDAH não é simples, pois os seus principais sintomas se confundem com outras condições clínicas e com características normais do desenvolvimento do indivíduo. Assim, torna-se necessária a utilização de critérios operacionais que são estabelecidos a partir da realização da avaliação clínica por profissionais capacitados e experientes. Tanto o diagnóstico equivocado e incorreto, quanto, principalmente, a ausência de diagnóstico traz para o indivíduo sérias consequências.  
Os conceitos dos profissionais de saúde sobre o TDAH são diversos, colocando os indivíduos com diagnóstico de TDAH em maior risco de serem rotulados pela sociedade<sup>23,28,29</sup> . A liga canadense para a pesquisa do TDAH, _Canadian ADHD Resource Alliance_ (CADDRA)<sup>23</sup> , orienta que os estereótipos e mitos acerca do TDAH sejam explorados na consulta com o paciente e sua família, na tentativa de se obter esclarecimentos, a fim de evitar prejuízos e tratamentos inadequados. Os estigmas do TDAH podem afetar crianças e adultos com o diagnóstico da doença, além de parentes ou pessoas próximas. Além disso, podem influenciar as atitudes das autoridades em relação a esses pacientes. Esse estigma provêm da incerteza do público quanto à  
confiabilidade/validade de um diagnóstico de TDAH, da avaliação diagnóstica relacionada e do desconhecimento da população em como interagir com indivíduos com TDAH<sup>23,28,29</sup> . O TDAH apresenta uma demanda crescente por serviços de saúde mental e está associado a outras condições de saúde, problemas familiares e escolares em comparação com a população em geral ou controles clínicos<sup>20</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do TDAH. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
F 90.0 – Distúrbios da atividade e da atenção  
F 90.1 – Transtorno hipercinético de conduta  
F 90.8 – Outros transtornos hipercinéticos  
F 90.9 – Transtorno hipercinético não especificado

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **3. DIAGNÓSTICO** -->
Em casos de suspeita de TDAH, deve ser realizada uma avaliação clínica e psicossocial completa. O diagnóstico deve ser realizado por um médico psiquiatra, pediatra ou outro profissional de saúde (como neurologista ou neuropediatra). Cabe ressaltar que, para adequada avaliação e gerenciamento da doença, é fundamental o envolvimento de equipe multidisciplinar. O profissional deve ser devidamente qualificado, com treinamento e experiência em TDAH. A confirmação do diagnóstico, tanto em crianças como em adultos, pode ser baseada em 18 sintomas indicativos de desatenção excessiva, hiperatividade e impulsividade.  
Os principais sistemas de classificação de diagnóstico são: 1) Classificação Estatística Internacional de Doenças e Problemas Relacionados com a Saúde, décima edição (CID-10), relativamente ao código F90, conforme publicação da Organização Mundial de Saúde (OMS)<sup>34</sup> ; e 2) Manual Diagnóstico e Estatístico de Transtornos Mentais, quinta edição (DSM5)<sup>1</sup> , da Associação Americana de Psiquiatria (APA)<sup>35</sup> . Esses sistemas de classificação de diagnóstico são bastante similares, embora os critérios da APA estejam mais atualizados do que os critérios presentes na CID-10 da OMS<sup>34</sup> . Apesar disso, os critérios para diagnóstico de TDAH, adotados formalmente pelo Ministério da Saúde seguem as recomendações da CID-10 e estão descritos no **Quadro 1** .  
**Quadro 1 –** Características e comportamentos frequentes  
**Definição:** Esse grupo de transtornos é caracterizado por início precoce, uma combinação de comportamento hiperativo e pobremente modulado com desatenção marcante e falta de envolvimento persistente nas tarefas, conduta invasiva nas situações e persistência no tempo dessas características de comportamento. **Características:** Transtornos hipercinéticos sempre têm início em fases iniciais do desenvolvimento, usualmente nos primeiros cinco anos de vida. Suas principais características são falta de persistência em atividades que requeiram envolvimento cognitivo e uma tendência a mudar de uma atividade para outra sem completar nenhuma, juntamente com movimentos excessivos do corpo de forma descoordenada. Esses problemas usualmente persistem através dos anos escolares e mesmo na vida adulta, embora muitos indivíduos afetados mostrem uma melhora gradual no controle dos movimentos hipercinéticos e na atenção.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Características adicionais:** -->
Crianças hipercinéticas são assiduamente imprudentes e impulsivas, propensas a acidentes e incorrem em problemas disciplinares por infrações não premeditadas de regras (em vez de desafio deliberado). Seus relacionamentos com adultos são, com frequência, socialmente desinibidos, com uma falta de precaução e reserva normais; elas são impopulares com outras crianças e podem se tornar isoladas. Comprometimento cognitivo é comum e atrasos específicos do desenvolvimento motor e da linguagem são desproporcionalmente frequentes.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Complicações secundárias:** -->
Incluem comportamento antissocial e baixa autoestima. Em consonância, há considerável sobreposição entre hipercinesia e outros padrões de comportamento destrutivos, tais como o “transtorno de conduta não socializado”. Todavia, evidências atuais favorecem a separação de um grupo no qual a hipercinesia é o problema principal.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Diferenças entre gêneros:** -->
Transtornos hipercinéticos são mais frequentes em meninos do que em meninas. Dificuldades de leitura associada a outros problemas escolares são comuns.  
Fonte: CID-10 – OMS<sup>34</sup> .  
Os critérios da CID-10 exigem que a desatenção excessiva, a hiperatividade e a impulsividade sejam vistas em várias situações por pelo menos seis meses e estejam presentes antes dos seis anos de idade<sup>34</sup> , ao passo que segundo o DSM-5 essas características podem ser detectadas até os 12 anos<sup>1</sup> . Além disso, algumas deficiências resultantes desses sintomas devem ser observadas em dois ou mais contextos (casa, escola e ambiente clínico)<sup>9,36</sup> . O comprometimento clinicamente significativo do funcionamento social, acadêmico ou ocupacional também deve ser evidente.  
O DSM-5 fornece três subtipos diferentes para identificar e classificar sintomas particulares: 1) tipo predominantemente desatento; 2) tipo predominantemente hiperativo-impulsivo; ou 3) tipo combinado, apresentando sintomas hiperativosimpulsivos e desatentos<sup>37</sup> . O subtipo é determinado pela quantidade de manifestações clínicas encontradas em cada modalidade. O subtipo predominantemente hiperativo-impulsivo (18% dos casos) ocorre quando há seis ou mais sintomas de hiperatividadeimpulsividade, mas menos de seis sintomas de desatenção. O subtipo predominantemente desatento (27% dos casos) é diagnosticado quando há seis ou mais sintomas de desatenção, mas menos de seis sintomas de hiperatividade-impulsividade. O subtipo combinado (55% dos casos) ocorre quando seis ou mais sintomas de desatenção e seis ou mais sintomas de hiperatividade-impulsividade são apontados<sup>5,35,38,39</sup> .  
Para a definição do diagnóstico são consideradas as informações advindas da família/cuidadores/responsáveis e da escola, no caso de pacientes em idade escolar<sup>9,40,41</sup> . Em todas as faixas etárias, devem ser considerados para diagnóstico os critérios dos sintomas ajustados à fase de desenvolvimento e, sempre que possível, os pontos de vista da pessoa com TDAH<sup>8,42</sup> . O profissional poderá fazer uso de diferentes escalas de avaliação (como a SNAP-IV, descrito no **Apêndice 2** ) e empregá-las para se obter maior rigor em sua prática profissional<sup>43</sup> , servindo também como medida de seguimento para avaliar se as intervenções propostas (medicamentosas, comportamentais, escolares e cognitivas ou sociais) estão sendo bem-sucedidas ou se precisam ser repensadas. Nesse contexto, em se tratando de indivíduos no contexto escolar, a escala SNAP-IV poderá ser aplicada pela equipe pedagógica em caráter auxiliar, que deverá comunicar aos pais ou responsáveis para que sejam tomadas as providências cabíveis.  
Durante a avaliação, o profissional deve considerar, principalmente, a tríade de sintomas característica do quadro de TDAH envolvendo desatenção, hiperatividade e impulsividade<sup>2,17,25</sup> . A literatura descreve o déficit de atenção como a constante interrupção de tarefas e atividades, prematuramente ou inacabadas, com frequente perda de interesse em uma atividade, desviando-se para outras atividades que possam parecer mais interessantes. A dificuldade de manter a atenção é persistente e compromete o desenvolvimento global da criança, trazendo sérios prejuízos nas diferentes atividades do dia a dia. No entanto, essa dificuldade de atenção não deve ser confundida com dificuldades intelectuais ou de outra natureza<sup>2,17,25</sup> . A  
hiperatividade/impulsividade implica inquietação psicomotora intensa em ambientes onde é necessário ou se esperaria que mantivesse a calma, e envolvimento em atividades motoras intensas e por vezes sem controle, havendo clara dificuldade em permanecer parado ou quieto. Esse comprometimento está além do esperado para o nível de desenvolvimento da criança ou adolescente e traz também sérios prejuízos nas diferentes situações e atividades cotidianas. Observa-se, além das características descritas anteriormente, dificuldades na realização de atividades estruturadas de maneira calma e organizada, em um padrão comportamental persistente e de pouco controle por parte do indivíduo, mesmo quando há compreensão de sua inadequação e desejo voluntário de controle<sup>2,17,25</sup> .  
Entre as dificuldades funcionais elencadas podemos citar prejuízos acadêmicos, problemas de socialização e de organização, resistência em aderir a rotinas ou atividades monótonas, além de cobranças e punições. Essas dificuldades geram baixa autoestima, problemas de comportamento e risco para comorbidades e transtornos psiquiátricos associados, como depressão, ansiedade, transtorno de conduta e oposição à autoridade, uso de substâncias psicoativas, abandono escolar precoce, envolvimento em atividades de risco e práticas delitivas<sup>2,17,25</sup> .  
Durante a avaliação, o profissional deve estar ciente de que pessoas nos seguintes grupos podem ter maior prevalência de  
TDAH em comparação com a população em geral<sup>29</sup> :  
- pessoas nascidas prematuras;  
- crianças e jovens com diagnóstico de transtorno desafiador de oposição ou transtorno de conduta;  
- crianças e jovens com transtornos de humor (por exemplo, ansiedade e depressão);  
- pessoas com um familiar próximo com diagnóstico de TDAH;  
- pessoas com epilepsia;  
- pessoas com transtornos de neurodesenvolvimento (por exemplo, transtorno do espectro do autismo); e  
- pessoas com histórico de uso indevido de substâncias psicoativas<sup>29</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **3.1 Diagnóstico diferencial** -->
A avaliação da história pessoal e uma revisão funcional completa, acompanhadas por um exame físico, geralmente confirmam as condições físicas subjacentes. Em certos casos, exames laboratoriais são necessários para eliminar a suspeita de outra doença. No entanto, a maioria dos indivíduos com TDAH não precisa de investigações laboratoriais como parte de sua avaliação diagnóstica.  
Algumas investigações adicionais podem ser relevantes, incluindo polissonografia ou eletroencefalograma. No geral, os testes psicológicos são frequentemente úteis porque abordam quaisquer problemas de aprendizagem e ajudam a determinar componentes específicos do funcionamento cognitivo que se sobrepõem ao funcionamento executivo (por exemplo, memória de trabalho e velocidade de processamento)<sup>23,29</sup> . Outros testes, como avaliação de personalidade ou teste projetivo, podem ser úteis para estabelecer traços de personalidade e avaliar o contato com a realidade. O **Quadro 2** mostra as principais condições que podem se assemelhar a sintomas de TDAH<sup>23,29</sup> .  
**Quadro 2 -** Principais condições que podem se assemelhar a sintomas de TDAH  
|**Condição**|**Sinais e sintomasnãocaracterísticos de TDAH**|
|---|---|
|**_Desordens psiquiátricas_**||
|Transtorno de ansiedade generalizada|Preocupação incontrolável por seis ou mais meses; falta de energia;|
||humor ansioso e sintomas de ansiedade somática.|
|Transtorno obsessivo-compulsivo|Presença de obsessões ou compulsões que interferem no nível de<br>funcionamento.|  
|**Condição**|**Sinais e sintomasnãocaracterísticos de TDAH**|
|---|---|
|Transtorno bipolar I ou II (episódio maníaco ou<br>hipomaníaco)|Sintomas psicóticos; discurso sob pressão de grandiosidade.|
|Transtorno do espectro do autismo|Comprometimento qualitativo nas interações sociais, comunicação ou<br>comportamentos excêntricos.|
|Transtorno opositivo-desafiador|Perda da paciência; irritabilidade.|
|Transtorno de tique/síndrome de_Tourette_(TS)|Presença de tiques vocais ou motores|
|**_Relacionado a medicamentos_**||
|Medicamento com evento adverso de entorpecimento|cognitivo (como o uso de estabilizadores de humor)|
|Medicamento com ativação psicomotora (por exemplo|, descongestionantes, beta-agonista)|
|**_Condições médicas gerais_**||
|Disfunção tireoidiana|Os níveis de TSH indicam hipotireoidismo ou hipertireoidismo|
|Hipoglicemia|Níveis anormalmente baixos de glicose no sangue confirmam o<br>diagnóstico|
|Distúrbios do sono|A avaliação do laboratório do sono confirma o diagnóstico|  
Elaborado a partir de informações obtidas das diretrizes canadense<sup>23</sup> .  
As dificuldades em reconhecer os sintomas do TDAH resultam em diagnóstico incorreto ou em fatores de compensação alternativos pouco efetivos. Por exemplo, a hiperatividade é mais frequentemente internalizada por sensações de inquietação e os sintomas de desatenção podem ser mascarados por sintomas de ansiedade ou o paciente pode utilizar-se de estratégias obsessivas de compensação dos sintomas. É fundamental que o clínico responsável consiga fazer o diagnóstico diferencial e das comorbidades presentes, visto que o tratamento e prognósticos são bastante distintos entre essas condições<sup>44,45</sup> . A avaliação da presença de comorbidades é crucial, considerando os seguintes aspectos:  
- 50% a 90% das crianças com TDAH têm pelo menos uma condição comórbida;  
- Aproximadamente 50% das crianças com TDAH têm pelo menos duas comorbidades; e  
- 85% dos adultos com TDAH atendem aos critérios de comorbidade<sup>44,45</sup> .  
Em crianças podem aparecer simultaneamente distúrbios de humor, conduta, aprendizado, controle motor, linguagem e  
comunicação. Esses distúrbios abrangem um amplo espectro, entre os quais:  
- Transtornos do humor (unipolar ou bipolar);  
- Transtornos de ansiedade;  
- Transtornos do desenvolvimento neurológico;  
- Transtornos de personalidade, especialmente, transtorno de personalidade _borderline_ e antissocial;  
- Transtornos por uso de substâncias psicoativas, como consequência da impulsividade e desregulação emocional ou como tentativa de autotratamento; e  
- Distúrbios do sono, especialmente a síndrome das pernas inquietas e a hipersonolência, podem compartilhar mecanismos fisiopatológicos comuns com o TDAH<sup>44,45</sup> .  
Os sintomas relacionados à comorbidade são responsáveis por comprometimento funcional grave, em vários domínios, levando a consequências acadêmicas, sociais, vocacionais e familiares<sup>4,45,46</sup> .  
**4. CRITÉRIOS DE INCLUSÃO**  
Todas as pessoas com diagnóstico de TDAH, segundo o critério do CID-10 ou o diagnóstico proposto pelo DSM-5 descrito na seção Diagnóstico serão incluídas neste Protocolo.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Pessoas com desordens psiquiátricas que podem ser confundidas com TDAH, como transtorno de ansiedade generalizada, transtorno obsessivo-compulsivo, transtorno bipolar ou transtorno do espectro do autismo, não são contempladas por este Protocolo.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **6. CASOS ESPECIAIS** -->
A apresentação dos subtipos de TDAH e dos transtornos comórbidos mais comuns muda com o tempo e com o estágio de desenvolvimento<sup>4,23,47–49</sup> . Os transtornos comórbidos mais comuns na primeira infância são os transtornos desafiadores de oposição (TDO), distúrbios de linguagem e enurese. Muitas crianças com TDAH têm um distúrbio de aprendizagem específico. O TDAH é duas a três vezes mais comuns em crianças com deficiências de desenvolvimento ou com deficiência intelectual limítrofe. No meio da idade escolar, sintomas de ansiedade ou transtornos do espectro de tiques também podem ser observados. Os transtornos do humor tendem a ser mais observáveis no início da adolescência<sup>4,23,47–49</sup> . No **Quadro 3** estão descritas as principais comorbidades que podem dificultar a avaliação e o tratamento do TDAH.  
**Quadro 3** - Comorbidades que podem dificultar a avaliação e o tratamento do TDAH  
|**Problemas psiquiátricos**|**Aspectos clínicos a serem considerados**|
|---|---|
|**_Alterações de humor_**||
||<br>Preconiza-se que seja tratado primeiro o distúrbio mais prejudicial.<br><br>A depressão moderada a grave deve ser tratada primeiro e a tendência ao<br>suicídio deve ser avaliada em todos os casos.|
|Depressão grave|<br>Distimia e depressão leve podem se beneficiar primeiro com o tratamento do<br>TDAH.<br><br>Os estimulantes podem ser combinados com a maioria dos antidepressivos<br>quando monitorados.|
||<br>Preconiza-se tratar primeiro o transtorno bipolar.|
|Transtorno bipolar|<br>O tratamento do TDAH pode ser oferecido quando o transtorno bipolar estiver<br>estabilizado.|
|**_Transtornos de ansiedade_**||
|Transtorno de ansiedade generalizada|<br>Tratar primeiro o distúrbio mais prejudicial.|
|Transtorno de pânico|<br>Alguns pacientes podem apresentar agravamento da ansiedade.|
|Fobia social|<br>Os tratamentos de TDAH podem ser menos tolerados em alguns indivíduos|
|Transtorno<br>obsessivo-compulsivo|dessa população.|
|(TOC)|<br>Observar as possíveis interações farmacológicas com medicamentos|
|Transtorno de estresse pós-traumático|metabolizados por meio do sistema CYT2D6.|
||<br>Os tratamentos para TDAH podem ser menos tolerados em alguns indivíduos|
|Transtorno do espectro do autismo|dessa população, mas podem ser muito úteis no tratamento geral.<br><br>Consultar um especialista para intervenções específicas.|
|Transtornos psicóticos|<br>Tratar primeiro o transtorno psicótico.|  
|**Problemas psiquiátricos**|**Aspectos clínicos a serem considerados**|
|---|---|
||<br>Consultar um especialista: o tratamento do TDAH pode desencadear uma<br>recaída psicótica em um paciente predisposto.<br><br>Pacientes estáveis que estão em remissão podem se beneficiar do tratamento<br>de TDAH.|
||<br>Tratar ambas as condições.|
||<br>O transtorno de oposição precisa de intervenções psicossociais.|
|Transtorno de oposição|<br>Os casos moderados e graves podem exigir combinações de psicoestimulantes|
|Transtorno de conduta|e um agonista Alfa 2.<br><br>A adição de um antipsicótico pode melhorar os sintomas de transtorno de<br>conduta, de acordo com alguns casos citados na literatura.|
|**_Problemas médicos_**||
||<br>Tratar primeiro a epilepsia, depois o TDAH.|
|Epilepsia|<br>Um novo início de convulsão deve ser tratado com medicamento<br>antiepiléptico.|
|Tiques|<br>A adição de antipsicótico pode ser necessária em casos graves.|
||<br>Tratar primeiro o distúrbio primário.|
|Apneia do sono|<br>Os psicoestimulantes podem reduzir a sonolência residual e melhorar a função<br>diária na apneia do sono e narcolepsia, com ou sem TDAH.|
||<br>Preconiza-se realizar um exame físico antes do tratamento (medida de pressão<br>arterial, pulso e ausculta cardíaca).|
|Problemas cardiovasculares|<br>Em caso de história cardíaca positiva ou doença cardíaca estrutural, consultar<br>um especialista.<br><br>Controlar sinais vitais e os eventos adversos cardíacos durante o tratamento.|
||<br>Discutir hábitos saudáveis de alimentação e sono.|
|Obesidade|<br>Introduzir a prática de exercícios.<br><br>O tratamento do TDAH pode melhorar a capacidade do paciente de<br>implementar mudanças no estilo de vida.|
|**_Outros problemas_**||
||<br>O tratamento do TDAH pode melhorar a atenção, permitindo a melhora nas|
|Transtornos de aprendizado|habilidades de aprendizagem.<br><br>Adaptações escolares, estudo e habilidades organizacionais acadêmicas<br>devem ser consideradas e oferecidas quando necessário.|
|Transtornos de fala|<br>Consultar um fonoaudiólogo para intervenções específicas.|
|Dispraxia|<br>Consultar um terapeuta ocupacional ou fisioterapeuta para intervenções<br>específicas.|  
Elaborado a partir de informações obtidas das diretrizes canadense<sup>23</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.1.     Tratamento não medicamentoso** -->
No que tange ao gerenciamento do TDAH, dada à complexidade dessa condição, preconiza-se a intervenção multimodal, incluindo intervenções não medicamentosas (precisamente intervenções cognitivas e comportamentais) para melhora dos sintomas deste transtorno, no controle executivo e no funcionamento ocupacional e social<sup>26,50–57</sup> . As diretrizes propostas pelo _National Institute for Health and Care Excellence_ (NICE)<sup>29</sup> preconizam que, no plano de tratamento, os profissionais devem enfatizar o valor de uma dieta equilibrada, boa nutrição e exercício físico regular para crianças, jovens e adultos com TDAH.  
Muitos adultos desenvolvem estratégias compensatórias para lidar melhor com o impacto do TDAH em suas vidas. O tratamento do adulto deve utilizar essas estratégias de enfrentamento e avaliar como elas funcionam em situações específicas, como rotinas diárias, cuidando de si mesmos, no trabalho e na vida familiar. A literatura atual enfatiza que as intervenções psicossociais, <mark>comportamentais e de habilidades sociais são essenciais para crianças e adultos com TDAH.</mark> Dentre as intervenções psicossociais, destaca-se a terapia cognitivo comportamental (TCC)<sup>54,56,58</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.1.1.  Terapia cognitivo comportamental** -->
Terapia cognitivo comportamental (TCC) é um termo genérico que contempla várias abordagens do modelo cognitivo comportamental. As técnicas da TCC possibilitam que o paciente (criança ou adulto) seja capaz de reestruturar suas crenças a partir de perspectivas mais adaptativas, suprimindo ou amenizando os comportamentos condicionados, mal adaptativos e modificando suas crenças, pensamentos, emoções e, consequentemente, suas sensações. Com isso, espera-se desenvolver habilidades comportamentais que podem perdurar por toda a vida<sup>27,57</sup> .  
As técnicas utilizadas para o tratamento do TDAH podem ser divididas didaticamente em cognitivas e comportamentais, embora na prática, ambas sejam utilizadas de forma complementar. Dentre as técnicas cognitivas mais utilizadas, destacam-se: reestruturação cognitiva, solução de problemas, diálogo interno, treinamento de autocontrole, autorreforço e treino de autoinstrução. Já dentre as técnicas comportamentais, destacam-se: automonitoramento e autoavaliação, sistema de recompensas, sistema de fichas, custo de resposta, punições, tarefas de casa, modelagem, dramatizações<sup>42</sup> , além de treinamento de comunicação social, planejamento e cronogramas<sup>55,57</sup> .  
As intervenções comportamentais são a forma de tratamento psicológico mais bem estabelecido, recomendado e amplamente utilizado. O gerenciamento de contingências ocorre por meio da análise funcional do comportamento, que possibilita ao paciente dar sentido aos seus sintomas por meio da identificação dos estímulos que mantêm a frequência desses comportamentos<sup>59</sup> . A psicoeducação visa proporcionar, tanto ao paciente quanto à família, informações compartilhadas de maneira compreensível sobre o diagnóstico do TDAH, os sintomas, tratamento e o ensino de estratégias compensatórias, capacitando-os a lidar com o transtorno, facilitando assim o processo de mudanças comportamentais. Essa aprendizagem é efetiva e se estende para além do período de tratamento<sup>60</sup> .  
Na infância, a intervenção geralmente assume a forma de treinamento dos pais<sup>14,44</sup> . Abordagens focais melhoram áreas específicas do funcionamento diário, como a social<sup>61</sup> e habilidades organizacionais<sup>62–64</sup> . Além dessas abordagens para crianças com TDAH, a TCC e o treinamento de habilidades de manejo de situações de vida são preconizados para pacientes adolescentes e adultos<sup>8,65</sup> .  
Na vida adulta e na fase infanto-juvenil, a literatura atual mostra que a TCC associada a medicamentos quando comparada ao uso de medicamentos isolados é superior ao controle de sintomas de TDAH autorreferidos, assim como diminuição nos níveis de ansiedade autorrelatados e uma tendência a ter menor depressão autorreferida. Esses dados apoiam a hipótese de que a TCC para adultos com TDAH com sintomas residuais é uma abordagem de tratamento da próxima etapa viável, aceitável e potencialmente eficaz, digna de mais testes.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.2.     Tratamento medicamentoso** -->
Os medicamentos metilfenidato e lisdexanfetamina para tratamento de crianças e adolescentes com TDAH foram avaliados pela Conitec<sup>66</sup> . A comissão considerou que as evidências que sustentam a eficácia e a segurança destes tratamentos para TDAH são frágeis dada sua baixa/muito baixa qualidade, bem como o elevado aporte de recursos financeiros apontados na análise de impacto orçamentário. Ainda, após consulta pública os membros presentes entenderam que não houve argumentação suficiente para alterar a recomendação inicial. Desta forma, a Conitec recomedou a não incorporação do metilfenidato e da lisdexanfetamina para o tratamento de TDAH em crianças e adolescentes.  
O tratamento de adultos com TDAH também foi avaliado pela Conitec, desta vez somente o tratamento com lisdexanfetamina<sup>67</sup> . Mais uma vez a comissão deliberou que a matéria fosse disponibilizada em Consulta Pública com recomendação preliminar desfavorável à incorporação de dimesilato de lisdexanfetamina no SUS. Os membros da Conitec consideraram o número pequeno de participantes da maioria dos estudos primários, o curto tempo de acompanhamento (máximo 20 semanas), o grau de confiança das evidências (avaliado como baixo e muito baixo) e o elevado impacto orçamentário para a tomada de decisão. Essa decisão foi mantida após as contribuições da consulta pública.  
Assim, o uso desses medicamentos não é preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.3.1. Ambiente escolar** -->
Crianças com diagnóstico de TDAH, com frequência, apresentam piores resultados educacionais: deixam a escola mais cedo, têm mais faltas não justificadas e são mais propensas a serem excluídas entre os colegas da escola<sup>68–70</sup> . O TDAH envolve uma grande pluralidade de dimensões: comportamentais, intelectuais, sociais e emocionais e se configura como um grande desafio para pais, professores e especialistas<sup>70,71,72,42</sup> . Os sintomas do TDAH podem contribuir para uma trajetória de fracasso escolar, haja vista que no contexto acadêmico a transição de um período escolar para outro demanda um maior nível de funcionamento executivo, principalmente nas habilidades de planejamento, autocontrole e resolução de problemas<sup>16,68–70</sup> .  
Do ponto de vista teórico ou conceitual, seria difícil projetar um ambiente mais problemático para indivíduos com TDAH do que a típica sala de aula do ensino fundamental. Espera-se que os alunos fiquem quietos, ouçam a instrução acadêmica, sigam as instruções em várias etapas, concluam o trabalho de forma independente, esperem sua vez e se comportem de maneira adequada com os colegas e professores. Em particular, espera-se que eles demorem a responder e pensem antes de agir. Esses requisitos são excepcionalmente desafiadores para alunos com TDAH, devido às dificuldades subjacentes em atrasar sua resposta ao ambiente, à motivação e ao funcionamento executivo<sup>16,68–70</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.3.2. Intervenções escolares** -->
Diferentes tipos de intervenções têm sido usadas para tratar os sintomas e prejuízos exibidos por alunos do ensino fundamental com TDAH, incluindo estratégias comportamentais, acadêmicas e de autorregulação<sup>16,68–70</sup> .  
As intervenções comportamentais visam substituir o comportamento socialmente indesejável (por exemplo, gritar) por um comportamento socialmente apropriado (por exemplo, trabalhar em silêncio). Do ponto de vista comportamental, cada comportamento deve ser entendido no contexto de seus antecedentes e consequências. Mais especificamente, o comportamento é teorizado para servir a uma das quatro funções principais: (1) escapar ou evitar uma atividade ou ambiente não preferencial, (2) ganhar atenção, (3) obter acesso a materiais ou ambientes preferenciais, ou (4) estimulação sensorial.  
As intervenções comportamentais proativas visam os antecedentes de comportamentos disruptivos, tornando os alunos menos propensos a se envolverem em tais comportamentos (por exemplo, revisar as expectativas da sala de aula). Por outro lado, as intervenções comportamentais reativas visam as consequências de um determinado comportamento, reforçando o comportamento desejável e ignorando ou punindo os comportamentos interferentes (por exemplo, advertência verbal por gritar).  
Intervenções bem-sucedidas são aquelas que facilitam a função (por exemplo, atenção) do comportamento interferente do aluno (por exemplo, gritar), reforçando um comportamento de substituição socialmente apropriado (por exemplo, levantando a mão)<sup>16,68–70</sup> .  
O uso de dicas e avisos aumenta a conformidade com o comportamento desejado. Ao fornecer aos alunos regras adequadas à idade e não duvidosas em relação às expectativas da sala de aula, os professores podem melhorar o comportamento desses indivíduos em sala de aula. A atenção diferencial do professor também é considerada eficaz para alunos com TDAH. Os professores devem dar atenção positiva ao comportamento socialmente desejável. O elogio deve ocorrer imediatamente após o comportamento desejado e deve ser de natureza específica. Além disso, os professores podem extinguir comportamentos perturbadores menores (por exemplo, tocar um lápis) não dando muita atenção a tais ações. As evidências atuais sugerem que as advertências dos professores podem ser eficazes na redução de comportamentos de interferência. Os redirecionamentos devem ser breves e específicos e devem ser feitos de forma consistente, imediatamente após o comportamento negativo de uma maneira calma e silenciosa<sup>16,68–70</sup> .  
O reforço simbólico é uma estratégia reativa que fornece aos alunos um reforço imediato (por exemplo, um adesivo) para atingir uma expectativa comportamental específica (por exemplo, preencher uma planilha). Esses reforçadores ou fichas iniciais são trocados por reforçadores de reserva (por exemplo, tempo adicional no computador) no final do dia ou no final da semana. Os programas de reforço são particularmente úteis para alunos com TDAH, que geralmente exigem _feedback_ imediato e recompensa para mudar o comportamento. Além disso, o reforço de fichas oferece flexibilidade valiosa, pois os critérios para ganhar reforçadores imediatos e de reserva podem ser cada vez mais rigorosos para ajudar a obter períodos mais longos ou níveis mais elevados de comportamento apropriado<sup>16,68–70</sup> .  
Incentivar a família a fortalecer as parcerias ajuda o processo de gerenciamento do TDAH. Os tratamentos psicossociais, que incluem esforços de coordenação na escola e em casa podem aumentar os efeitos. Quanto mais informados são os familiares e o paciente, melhores são suas escolhas e a resposta ao tratamento<sup>60,71–73</sup> .  
Essas intervenções sugeridas não necessariamente resolvem o transtorno, mas auxiliam a criança a se organizar. A família deve saber que se trata de um problema crônico, e que, apesar de não haver cura, é possível reorganizar comportamentos e viabilizar atitudes para que a criança (e, posteriormente, o jovem e o adulto) seja funcional na família, na escola e na sociedade<sup>60,71–73</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.4. Orientação para pacientes** -->
Após um diagnóstico de TDAH, é aconselhável que o profissional de saúde proporcione uma discussão estruturada com os pacientes (na presença de seus familiares ou cuidadores, conforme apropriado) sobre como o TDAH pode afetar suas vidas. Essa conversa deve incluir os seguintes aspectos:  
- Esclarecer sobre os impactos positivos de receber um diagnóstico;  
- melhorar a compreensão dos sintomas, identificando e construindo pontos fortes individuais;  
- orientar sobre os impactos negativos de receber um diagnóstico, como estigma e rotulagem;  
- informar sobre a importância das modificações ambientais para reduzir o impacto das questões de educação de sintomas de TDAH (por exemplo, ajustes razoáveis na escola e faculdade);  
- orientar sobre as questões de emprego (por exemplo, impacto nas escolhas de carreira e direitos a ajustes razoáveis no local de trabalho);  
- explicar os desafios do relacionamento social e orientar formas de gerenciar o TDAH; e  
- orientar quanto ao aumento do risco de uso indevido de substâncias e automedicação<sup>29</sup> .

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.5. Orientações para familiares** -->
Os pais precisam ser informados sobre como o quadro clínico do TDAH possivelmente afetará a criança/adolescente. Também é importante informar que todos os aspectos da vida da pessoa devem ser tratados por meio de uma abordagem multimodal que considere as questões sociais, emocionais, comportamentais e acadêmicas<sup>29</sup> . O debate sobre algumas questões pode auxiliar as famílias, por exemplo:  
- Perguntar às famílias ou cuidadores de pessoas com TDAH como isso os afeta diretamente e como afeta outros membros da família e discutir quaisquer preocupações que eles tenham;  
- incentivar os familiares ou cuidadores de pessoas com TDAH a buscar uma avaliação de suas necessidades pessoais, sociais e de saúde mental e a ingressar em grupos de autoajuda e apoio, se apropriado;  
- Pensar nas necessidades de um pai ou uma mãe com TDAH que também tem um filho ou uma filha com TDAH, incluindo se eles precisam de apoio extra com estratégias organizacionais (por exemplo, adesão ao tratamento e rotinas escolares diárias).

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **7.6. Hábitos alimentares** -->
Ainda não existe consenso na literatura a respeito da associação entre consumo de açúcar e o agravamento dos sintomas do TDAH. Alguns estudos identificaram efeitos protetores com a maior ingestão de ferro, zinco e ácidos graxos poli-insaturados; e eventos adversos devido à maior ingestão de corantes alimentares, conservantes e açúcar em pacientes com TDAH<sup>19,74</sup> . Alguns autores também têm mostrado que crianças com TDAH têm hábitos alimentares irregulares, apresentando maior prevalência de compulsão alimentar<sup>19,74</sup> . Contudo, mais estudos se fazem necessários para comprovar essa associação.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **8. MONITORAMENTO** -->
O acompanhamento de pessoas com TDAH em tratamento, o monitoramento dos efeitos das medidas terapêuticas instituídas e o acompanhamento das condições de saúde associadas são aspectos muito importantes e necessita de um cuidado multidisciplinar. A equipe responsável pelo cuidado à pessoa com TDAH, sempre que possível, deve ser composta por médico, psicólogo, fonoaudiólogo e educadores, entre outros especialistas, conforme o caso.  
O monitoramento contínuo garante que o tratamento do paciente seja adequado aos sintomas atuais e às circunstâncias familiares, sociais e culturais. Para avaliar a resposta ao tratamento e a revisão periódica do progresso é aconselhado o uso de questionários baseados em evidências, como por exemplo, as escalas de TDAH / DSM-IV.  
Para um melhor controle dos sintomas, há necessidade de consultas mais próximas no início do tratamento. O ideal é que as primeiras consultas não ocorram com intervalos superiores a 30 dias, podendo ampliar para a cada três ou quatro meses, se o caso tiver boa evolução. O tratamento não medicamentoso (atendimento psicológico, orientação aos pais, apoio escolar) deve ser iniciado precocemente, com frequência semanal, cuja demanda deve ser periodicamente avaliada.  
Em relação ao desempenho escolar, a equipe multidisciplinar deve fornecer informações à família e à criança sobre o transtorno e tratamento  do TDAH, assim como ajudá-los a atingir metas específicas e atingíveis durante o tratamento. Algumas das metas que podem ser sugeridas são: (1) o melhor relacionamento com pais, professores, irmãos e colegas; (2) melhora das notas no colégio; e (3) maior seguimento de regras.  
Devido às necessidades mutáveis dos pacientes com TDAH, é imprescindível a prestação de cuidados clínicos ideais à medida que eles fazem a transição na escola e na vida adulta<sup>75</sup> . Os sintomas de TDAH vistos na primeira infância podem não, necessariamente, permanecer na mesma intensidade na adolescência. Por exemplo, o comportamento hiperativo pode diminuir ou desaparecer mais tarde na vida, enquanto o comportamento desatento tende a ser mais constante ao longo do desenvolvimento.  
Um jovem com TDAH recebendo tratamento e cuidados em serviços pediátricos deve ser reavaliado na idade de deixar a escola para estabelecer a necessidade de continuar o tratamento até a idade adulta. Se o tratamento for necessário, devem ser  
feitos arranjos para uma transição suave para os serviços de adultos, com detalhes do tratamento previsto e dos serviços que o jovem necessitará. O tempo preciso dos arranjos pode variar localmente, mas geralmente deve ser concluído quando o jovem tiver 18 anos<sup>29</sup> . No **Quadro 4** consta a composição de uma equipe multiprofissional que pode estar envolvida no tratamento e acompanhamento dos usuários com TDAH e exames que podem ser solicitados, de acordo com as necessidades individuais. Quanto à periodicidade de avaliação, esta deve ser constante e realizada a cada sessão terapêutica cuja frequência deve ser determinada pelo profissional-terapeuta (psicólogo ou fonoaudiólogo ou terapeuta ocupacional. Exames não são preconizados como prática cotidiana. Estes devem ser solicitados por profissional de saúde quando houver necessidade.  
**Quadro 4** - Equipe multidisciplinar, avaliações e exames complementares  
|**AVALIAÇÃO**|
|---|
|Médico psiquiatra|
|Médico de família e comunidade|
|Psicólogo|
|Fonoaudiólogo|
|Psicopedagogo|
|Assistente social|
|**AVALIAÇÃO CLÍNICA**|
|Primeiras consultas- intervalos inferiores à 30 dias, podendo se ampliar para a cada três ou quatro meses.|
|**EXAMES COMPLEMENTARES**|
|Nenhum específico|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Diante da complexidade que envolve a problemática de saúde do TDAH, são necessários o envolvimento e a articulação dos entes federados na organização dos serviços, a fim de ofertar cuidado multidisciplinar adequado, integral e longitudinal, por meio de abordagens individuais e coletivas. Essas abordagens devem envolver ações direcionadas tanto para o usuário quanto para a família, o que exige a organização do processo de trabalho em toda a rede de atenção à saúde, assim como nos demais setores envolvidos (educação e assistência social, por exemplo). Os serviços de saúde devem ser compostos por equipes multidisciplinares especializadas em TDAH para que possam fornecer diagnóstico, tratamento e acompanhamento para pacientes com essa condição clínica.  
Atualmente, existem políticas governamentais que apoiam pacientes que necessitam de cuidados relacionados a saúde mental. A Política Nacional de Saúde Mental é uma ação do Governo Federal, coordenada pelo Ministério da Saúde, por meio da Coordenação-Geral de Saúde Mental, Álcool e outras Drogas, que define as diretrizes adotadas pelo Ministério da Saúde para organizar de forma interfederativa com municípios e estados, a promoção do cuidado integral e longitudinal às pessoas com transtornos mentais ou com problemas e necessidades em decorrência do uso de substâncias psicoativas, como álcool, cocaína, crack e outras drogas. A legislação federal relacionada à atenção integral às pessoas com TDAH está listada no **Apêndice 1** .  
A Rede de Atenção Psicossocial (RAPS) foi instituída pela Portaria de Consolidação n° 03, de 28 de setembro de 2017 (Origem: PRT MS/GM 3.088 2011) que prevê a criação, a ampliação e articulação de pontos de atenção à saúde para pessoas com sofrimento ou transtorno mental e com necessidades decorrentes do uso de crack, álcool e outras drogas no âmbito do SUS. É uma rede prioritária para constituição das regiões de saúde nos Estados como determina o Decreto nº 7.508, de 28 de junho de 2011, que regulamenta a Lei nº 8.080, de 19 de setembro de 1990, para dispor sobre a organização do SUS, o planejamento da saúde, a assistência à saúde e a articulação interfederativa.  
Em 2017, a RAPS foi ampliada, com a inclusão de novos pontos de atenção, por meio da Portaria MS/GM n° 3.588/2017 que “Altera as Portarias de Consolidação nº 3 e nº 6, de 28 de setembro de 2017". Com a ampliação, a RAPS passa a contar com a Equipe Multiprofissional de Atenção Especializada em Saúde Mental tipo I, II e III e os Centros de Atenção Psicossocial (CAPS) IV AD, Hospital Dia e Hospital Especializado em Psiquiatria, além dos serviços já existentes, com o objetivo de ampliar o acesso à atenção psicossocial e da variedade de oferta de cuidados, regidos pelas normas da Lei Federal nº 10.216/2001.  
A porta de entrada para o cuidado em saúde mental são os serviços da Atenção Primária à Saúde, os CAPS e os serviços de urgência e emergência, onde as pessoas são acolhidas, sejam elas referenciadas ou por demanda espontânea. O cuidado de crianças e adolescentes gravemente comprometidos psiquicamente, como os pacientes com TDAH, autismo, psicoses, neuroses graves e todos aqueles que, por sua condição psíquica, estão impossibilitados de manter ou estabelecer laços sociais e realizar projetos de vida, seja em situações de crise ou nos processos de reabilitação psicossocial, é realizado gratuitamente nos serviços especializados - Centros de Atenção Psicossocial infantil (CAPSi).

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **10. REFERÊNCIAS** -->
1. American Psychiatric Association. Manual Diagnóstico e Estatístico dos Transtornos Mentais - 5a Edição. In: Espectro da Esquizofrenia e Outros Transtornos Psicóticos. 2013.  
2. Nigg JT, Casey BJ. An integrative theory of attention-deficit/hyperactivity disorder based on the cognitive and affective neurosciences. Dev Psychopathol. 2005.17(3):785–806.  
3. Diaz JH. Hypothesis: angiotensin-converting enzyme inhibitors and angiotensin receptor blockers may increase the risk of severe COVID-19. J Travel Med. 2020;27(3):taaa041  
4. Weibel S, Menard O, Ionita A, Boumendjel M, Cabelguen C, Kraemer C, et al. Practical considerations for the evaluation and management of Attention Deficit Hyperactivity Disorder (ADHD) in adults. Encephale. 2020;46(1):30-40  
5. Polanczyk G V., Willcutt EG, Salum GA, Kieling C, Rohde LA. ADHD prevalence estimates across three decades: An updated systematic review and meta-regression analysis. Int J Epidemiol. 2014;43(2):434–42.  
6. P Polanczyk G, de Lima MS, Horta BL, Biederman J, Rohde LA. The worldwide prevalence of ADHD: a systematic review and metaregression analysis. Am J Psychiatry. 2007;164(6):942-8.  
7. Willcutt EG. The Prevalence of DSM-IV Attention-Deficit/Hyperactivity Disorder: A Meta-Analytic Review. Neurotherapeutics. 2012;9(3):490–9.  
8. Lima Teles da Hora AF, Silva SS da C, Ramos MFH, Pontes FAR, Nobre JP dos S. A prevalência do Transtorno do Déficit de Atenção e Hiperatividade (TDAH): uma revisão de literatura. Psicologia. 2015;29(2):47–62.  
9. Arruda MA, Querido CN, Bigal ME, Polanczyk G V. ADHD and Mental Health Status in Brazilian School-Age Children. J Atten Disord. 2015;19(1):11–7.  
10. Jernelöv S, Larsson Y, Llenas M, Nasri B, Kaldo V. Effects and clinical feasibility of a behavioral treatment for sleep problems in adult attention deficit hyperactivity disorder (ADHD): a pragmatic within-group pilot evaluation. BMC Psychiatry. 2019;19(1):226.  
11. Fayyad J, Sampson NA, Hwang I, Adamowski T, Aguilar-Gaxiola S, Al-Hamzawi A, et al. The descriptive epidemiology of DSM-IV Adult ADHD in the World Health Organization World Mental Health Surveys. ADHD Atten Deficit Hyperact Disord. 2017;9(1):47-65.  
12. Simon V, Czobor P, Bálint S, Mészáros Á, Bitter I. Prevalence and correlates of adult attention-deficit hyperactivity disorder: Meta-analysis. British Journal of Psychiatry. 2009;194(3):204-11  
13. Schulz E, Fleischhaker C, Hennighausen K, Heiser P, Oehler KU, Linder M, et al. A double-blind, randomized, placebo/active controlled crossover evaluation of the efficacy and safety of Ritalin® la in children with attentiondeficit/hyperactivity disorder in a laboratory classroom setting. J Child Adolesc Psychopharmacol. 2010;20(5):377–85.  
14. Weibel S, Menard O, Ionita A, Boumendjel M, Cabelguen C, Kraemer C, et al. Practical considerations for the evaluation and management of Attention Deficit Hyperactivity Disorder (ADHD) in adults. Encephale. 2019;46(1):30–40.  
15. Banaschewski T, Soutullo C, Lecendreux M, Johnson M, Zuddas A, Hodgkins P, et al. Health-related quality of life and functional outcomes from a randomized, controlled study of lisdexamfetamine dimesylate in children and adolescents with attention deficit hyperactivity disorder. CNS Drugs. 2013;27(10):829–40.  
16. Castellanos FX, Sonuga-Barke EJS, Milham MP, Tannock R. Characterizing cognition in ADHD: Beyond executive dysfunction. Trends Cogn Sci. 2006;10(3):117–23.  
17. Cortese S, Adamo N, Del Giovane C, Mohr-Jensen C, Hayes AJ, Carucci S, et al. Comparative efficacy and tolerability of medications for attention-deficit hyperactivity disorder in children, adolescents, and adults: a systematic review and network meta-analysis. Lancet Psychiatry. 2018;5(9):727–38.  
18. Liu Y, Yang Y, Zhang C, Huang F, Wang F, Yuan J, et al. Clinical and biochemical indexes from 2019-nCoV infected patients linked to viral loads and lung injury. Sci China Life Sci. 2020;63(3):364–74.  
19. Del-ponte B, Anselmi L, Cec M, Assunc F, Tovo-rodrigues L, Munhoz TN, et al. Sugar consumption and attentiondeficit/hyperactivity disorder (ADHD): A birth cohort study. J Affect Disord. 2018;243:290-296  
20. Vibert S. Your attention please: the social and economical impact of ADHD. London: Demos; 2018.  
21. Gobbo MA, Louzã MR. Influence of stimulant and non-stimulant drug treatment on driving performance in patients with attention deficit hyperactivity disorder: A systematic review. Eur Neuropsychopharmacol. 2014;24(9):1425-43  
22. Chen MH, Hsu JW, Huang KL, Bai YM, Ko NY, Su TP, et al. Sexually Transmitted Infection Among Adolescents and Young Adults With Attention-Deficit/Hyperactivity Disorder: A Nationwide Longitudinal Study. J Am Acad Child Adolesc Psychiatry. 2018;57(1):48–53.  
23. CADDRA. Canadian ADHD Resource Alliance (CADDRA): Canadian ADHD Practice Guidelines. Fourth Edition. Toronto On. Toronto; 2018.  
24. Barkley RA, Mcmurray MB, Edelbrock CS, Robbins K. Side Effects of Metlyiphenidate in Children With Attention Deficit Hyperactivity Disorder. Pediatrics. 1990;86(2).  
25. Storebø OJ, Pedersen N, Ramstad E, Kielsholm ML, Nielsen SS, Krogh HB, et al. Methylphenidate for attention deficit hyperactivity disorder (ADHD) in children and adolescents - assessment of adverse events in non-randomised studies. Cochrane Database Syst Rev. 2018;2018(5).  
26. Crescenzo F De, Cortese S, Adamo N, Janiri L. Pharmacological and non-pharmacological treatment of adults with ADHD : a meta-review. Evid Based Ment Heal. 2017;20(1):4–11.  
27. López-Villalobos JA, Sacristán-Martín AM, Garrido-Redondo M, Martínez-Rivera MT, López-Sánchez MV, Rodríguez-Molinero L, et al. Health-related quality of life in cases of attention deficit hyperactivity disorder with and without pharmacological treatment. An Pediatría. 2019;90(5):272–9.  
28. Mueller AK, Fuermaier ABM, Koerts J, Tucha L. Stigma in attention deficit hyperactivity disorder. ADHD Attention Deficit and Hyperactivity Disorders. 2012;4(3):101-14.  
29. NICE. Attention deficit hyperactivity disorder: diagnosis and management (NICE Guideline). NICE - National Institute for Health and Care Excellence. 2018.  
30. Ministério da Saúde. Manual de Desenvolvimento de Diretrizes da Organização Mundial da Saúde. 2020.  
31. BRASIL. Protocolo Clínico e Diretrizes Terapêuticas (PCDT). Ministério da Saúde. Secretaria de Vigiliância em Saúde. Departamento de DST, Aids e Hepatites Virais. 2015.  
32. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008;336(7650):924–6.  
33. McMaster University. GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. Evidence Prime, Inc.  
2015.  
34. OMS - Organização Mundial de Saúde. Classificação de Transtornos Mentais e de Comportamento da CID-10: Descrições Clínicas e Diretrizes Diagnósticas. Porto Alegre: Artes Médicas. 1993.  
35. APA. AMERICAN PSYCHIATRIC ASSOCIATION. Manual Diagnóstico e Estatístico de Transtornos Mentais - DSM5. Porto Alegre: Artmed, 5<sup>a</sup> edição, 2014. Artmed. 2014.  
36. Scahill L, Schwab-Stone M. Epidemiology of ADHD in school-age children. Child Adolesc Psychiatr Clin N Am. 2000;9(3):541–55.  
37. Storebø OJ, Krogh HB, Ramstad E, Moreira-Maia CR, Holmskov M, Skoog M, et al. Methylphenidate for attentiondeficit/hyperactivity disorder in children and adolescents: Cochrane systematic review with meta-analyses and trial sequential analyses of randomised clinical trials. BMJ. 2015;351:h5203.  
38. Ptacek R, Kuzelová H. P-323 - Developmental changes in children with ADHD. Eur Psychiatry. 2012;27:1.  
39. Keen D, Hadijikoumi I. ADHD in children and adolescents. BMJ clinical evidence. 2011;2011:0312.  
40. Soto-Insuga V, Calleja ML, Prados M, Castaño C, Losada R, Ruiz-Falcó ML. Utilidad del hierro en el tratamiento del trastorno por déficit de atención e hiperactividad. An Pediatr. 2013;79(4):230–5.  
41. Graham P, People Y. Attention Deficit Hyperactivity Disorder The NICE Guideline on Diagnosis and Management. National Clinical Practice Guideline. 2009.  
42. Dias TGC, Kieling C, Graeff-Martins AS, Moriyama TS, Rohde LA, Polanczyk G V. Developments and challenges in the diagnosis and treatment of ADHD. Rev Bras Psiquiatr. 2013;35(suppl 1):S40-S50.  
43. Barkley RA. Transtorno do Déficit de Atenção/Hiperatividade: Manual para Diagnóstico e Tratamento. Porto Alegre: Artmed. 2008.  
44. López-Soler C, Romero Medina A. TDAH y trastornos del comportamiento en la infancia y la adolescencia: clínica, diagnóstico, evaluación y tratamiento. Ediciones. Madrid. 2013.  
45. Louzã Neto MR. TDAH ao longo da vida. Porto Alegre: Artmed; 2010.  
46. Sadock BJ, Sadock VA, Ruiz P. Compêndio de psiquiatria: ciências do comportamento e psiquiatria clínica. 11th ed. Porto Alegre: Artmed; 2016.  
47. Antshel KM, Faraone S V. Attention deficit/hyperactivity disorder. In: The Curated Reference Collection in Neuroscience and Biobehavioral Psychology. 2016.  
48. Hennissen L, Bakker MJ, Banaschewski T, Carucci S, Coghill D, Danckaerts M, et al. Cardiovascular Effects of Stimulant and Non-Stimulant Medication for Children and Adolescents with ADHD: A Systematic Review and MetaAnalysis of Trials of Methylphenidate, Amphetamines and Atomoxetine. CNS Drugs. 2017;31(3):199-215.  
49. Biederman J, Monuteaux MC, Spencer T, Wilens TE, Faraone S V. Do stimulants have a protective effect on the development of psychiatric disorders in youth with ADHD? A ten-year follow-up study. Pediatrics. 2009;124(1):71–8.  
50. Boyer BE, Geurts HM, Prins PJM. Two novel CBTs for adolescents with ADHD : the value of planning skills Two novel CBTs for adolescents with ADHD : the value of planning skills. Eur Child Adolesc Psychiatry. 2014;24(April 2015):1075–90.  
51. Chan E, Fogler JM, Hammerness PG. Treatment of Attention-Deficit/Hyperactivity Disorder in Adolescents A Systematic Review. JAMA. 2016;315(18):1997–2008.  
52. Dittner AJ, Hodsoll J, Rimes KA, Russell AJ, Chalder T. Cognitive – behavioural therapy for adult attention-deficit hyperactivity disorder : a proof of concept randomised controlled trial. Acta Psychiatr Scand. 2018;137:125–37.  
53. Huang F, Qian Q, Wang Y. Cognitive behavioral therapy for adults with attention-deficit hyperactivity disorder : study protocol for a randomized controlled trial. Trials. 2015;16(161):1–8.  
54. Lopez PL, Torrente FM, Ciapponi A, Lischinsky AG, Cetkovich-Bakmas M, Rojas JI, et al. Cognitive-behavioural  
interventions for attention deficit hyperactivity disorder ( ADHD ) in adults ( Review ). Cochrane Database Syst Rev. 2018;CD010840(3):1–123.  
55. Solanto M V, Surman CB, Ma J. The efficacy of cognitive – behavioral therapy for older adults with ADHD : a randomized controlled trial. ADHD Atten Deficit Hyperact Disord. 2018;10(3):223–35.  
56. Manfred Do ̈pfner EI, Metternich-Kaizman TW, , Stephanie Schu ̈rmann, Christiane Rademacher DB. Adaptive Multimodal Treatment for Children with Attention- Deficit-/Hyperactivity Disorder: An 18 Month Follow-Up. Psychiatry Hum Dev. 2015;46:44–56.  
57. Ahmad S, Ali KNM, Fatima S, Asghar A, Shahid H, Ishfaq B, et al. Effect of Cognitive Behavioral Therapy in Children Affected by Attention Deficit Hyperactivity Disorder: A Meta-Analysis. Int J Res Stud Med Heal Sci. 2018;3(7):10–23.  
58. Higgins JPT, Thomas J, Chandler J, Cumpston M, Li T, Page MJ, Welch VA (editors). Cochrane Handbook for Systematic Reviews of Interventions version 6.3 (updated February 2022). Cochrane, 2022. Available from www.training.cochrane.org/handbook.  
59. Friedberg R, Mcclure J, Garcia J. Técnicas de Terapia cognitiva para crianças e adolescentes: Ferramentas para aprimorar a prática. Porto Alegre: Artmed; 2011.  
60. Pinheiro M. Manual educativo sobre transtorno do déficit de atenção/hiperatividade. Curitiba UFPR/Setor Educ. 2015. 61. Abikoff HB, Vitiello B, Riddle MA, Cunningham C, Greenhill LL, Swanson JM, et al. Methylphenidate effects on functional outcomes in the Preschoolers with Attention-Deficit/Hyperactivity Disorder Treatment Study (PATS). J Child Adolesc Psychopharmacol. 2007;17(5):581–92.  
62. Malone MA, Swanson JM. Effects of Methylphenidate on Impulsive Responding in Children With Attention-Deficit Hyperactivity Disorder. J Child Neurol. 1993;8(2):157–63.  
63. Martins FAG, Ladislau ÁJ, Vilchez MK, Fiamoncini GM, Ferreira M de AN, Karpinski DM, et al. Metilfenidato em crianças no Brasil: Análise crítica de publicações científicas de 2004 a 2014. Rev Neurociencias. 2015;23(2):190–204.  
64. Padilha SCOS, Virtuoso S, Tonin FS, Borba HHL, Pontarolo R. Efficacy and safety of drugs for attention deficit hyperactivity disorder in children and adolescents: a network meta-analysis. Eur Child Adolesc Psychiatry. 2018;27(10):1335–45.  
65. Carvalho NG de, Novelli CVL, Colella-Santos MF. Fatores na infância e adolescência que podem influenciar o processamento auditivo: revisão sistemática. Rev CEFAC. 2015;17(5):1590-1603.  
66. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Metilfenidato e lisdexanfetamina para indivíduos com Transtorno do Déficit de Atenção com Hiperatividade: Relatório de Recomendação. 2021. Disponível em  
- http://conitec.gov.br/images/Relatorios/2021/20210319_Relatorio_601_metilfenidato_lisdexanfetamina_TDAH.pdf.  
67. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Dimesilato de lisdexanfetamina para indivíduos adultos com Transtorno do Déficit de Atenção com Hiperatividade: Relatório de Recomendação. 2020. Disponível em  
http://conitec.gov.br/images/Relatorios/2021/20210602_Relatorio_610_Lisdexanfetamina_TDAH_P_20.pdf .  
68. DuPaul G, Weyandt L. School-based intervention for children with attention deficit hyperactivity disorder: Effects on academic, social, and behavioural functioning. Int J Disabil Dev Educ. 2006;53(2):161-176.  
69. Weyandt LL, DuPaul G. ADHD in college students. Journal of Attention Disorders. 2006; 10(1):9-19  
70. DuPaul GJ, Weyandt LL, Janusis GM. Adhd in the classroom: Effective intervention strategies. Theory Pract. 2011;50(1):35-42.  
71. MUZETTI, C.M.G., DE LUCA-VINHAS MC. Influencia do déficit de atenção e hiperativiade na aprendizagem em escolares. Psicol Argum. 2011;29(65):242  
72. ROHDE L. A. Mattos P. Princípios e Práticas em TDAH. Porto Alegre: Artmed. 2003.  
73. ROTTA NT et al. Transtornos de aprendizagem. Porto Alegre: Artmed. 2006.  
74. Hontelez S, Stobernack T, Pelsser LM, Baarlen P Van, Frankena K, Groefsema MM, et al. Correlation between brain function and ADHD symptom changes in children with ADHD following a few ‑ foods diet : an open ‑ label intervention trial. Sci Rep. 2021;1–12.  
75. NH and MRC. Clinical practice points on the diagnosis, assessment and management of attention deficit hyperactivity disorder in children and adolescents. Australian Government, National Health and Medical Research Council; 2012.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: LEGISLAÇÃO FEDERAL RELACIONADA À ATENÇÃO INTEGRAL ÀS PESSOAS COM TRANSTORNO DO DÉFICIT DE ATENÇÃO COM HIPERATIVIDADE -->
Normativas publicadas no âmbito da Gestão Federal relacionadas à Atenção Integral às pessoas com Transtorno do Déficit de Atenção com Hiperatividade no Sistema Único de Saúde.  
**Normativas** Brasil. Presidência da República. Lei nº 10.216, de 6 de abril de 2001. Dispõe sobre a proteção e os direitos das pessoas portadoras de transtornos mentais e redireciona o modelo assistencial em saúde mental. Diário Oficial da União, Brasília, DF, 9 abr 2001 [acesso em 26 out 2020]. Disponível em: http://www.planalto.gov.br/ccivil_03/leis/leis_2001/l10216.htm. <mark>Brasil. Ministério da Educação. Parecer CNE/CEB nº 13/2009, aprovado em 3 de junho de 2009 – Diretrizes Operacionais para o atendimento educacional especializado na  Educação Básica, modalidade Educação Especial.</mark> Disponível em: http://portal.mec.gov.br/dmdocuments/pceb013_09_homolog.pdf <mark>Brasil. Ministério da Educação. Secretaria de Educação Especial. Política Nacional de Educação Especial na Perspectiva da Educação Inclusiva. Documento elaborado pelo Grupo de Trabalho nomeado pela Portaria Ministerial nº 555, de 5 de junho de 2007, prorrogada pela Portaria nº 948, de 09 de outubro de 2007.</mark> Disponível em: http://portal.mec.gov.br/dmdocuments/pceb013_09_homolog.pdf <mark>Brasil.</mark> Câmara dos Deputados. Projeto de Lei nº 7.081/2010, acompanhamento integral para educandos com dislexia ou Transtorno do Déficit de Atenção com Hiperatividade (TDAH). Diário da Câmara dos Deputados, Brasília, 22 de junho de 2013, pp. 25849-25858. Disponível em: https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao=472404 Brasil. Ministério da Saúde. Projeto de Lei 3092 de 14/02/2012. Dispõe sobre a obrigatoriedade de fornecimento de medicamentos gratuitos pelo SUS para tratar TDHA em crianças portadoras da síndrome sem distinção de classe, nem mesmo aqueles pacientes que não se enquadram como os mais carentes poderão ser excluídos do benefício. Disponível em: https://www.camara.leg.br/proposicoesWeb/fichadetramitacao?idProposicao=533790 Brasil. Ministério da Saúde. Projeto de Lei C nº 118 de 08/11/2011. Dispõe sobre a obrigatoriedade de exame físico e mental p/ detectar o TDAH em motociclistas (Altera a Lei nº 9503 de 23/09/1997 (C. T. B.) Disponível em: <u>https://www25.senado.leg.br/web/atividade/materias/-/materia/99558</u>  
**APÊNDICE 2**

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: Questionário SNAP-IV -->
<!-- Start of picture text -->
[NOM<br>[SERIE DADE<br>T — Nao consegue prestarQUESTOESmuita atencao a detalhes ou comete | "souce’ | peucoSéum | SereBastante | Pome<br>[=|[ewspordesantonmstabohesdasscsncuwems eens de3 —Parece naolazer. estar ouvindo quando sefaladiretamentecomele,|[ [TT  [TTIN IE<br>4 — Nao segue instrucdes até o fim e ndo termina deveres de<br>[escomtrcascamngaaes| 5 —Tem dificuldade para organizartarefaseatividades.Crees |T[ T TP<br>TTexigem esforco mental prolongado.<br>——<br>[tmnguessdevewsdneseomtapeaummenybrinquedos, deveres da escola, lapis ou livros | fT<br>||| 8—Distrai-se 9—E10 —Mexe esque c omido comestimulosextemos.as em maos atividadeou o s  dodiaadiapés ouseremexenacadera PPPT[TP<br>etespera que fique sentado.<br>—<br>situagGes em que isso é inapropriado.<br>ae eet<br>Fleihan<br>| lazer14—Nao de formpar a  calma.oucostumaestara‘milporhora TPA<br>[15—Falaemexcesso.<br>16 — Responde as perguntas de forma precipitada antes que elas<br>tenham sido terminadas.<br>| 17—Tem dificuldade paraesperarsuavez, TP<br>elem conversas/jogos}<br>‘se a<br>de desatencdo que o esperado numa crianca ou adolescente.<br>sintomas de hiperatividade e impulsividade que o esperado numa crianca ou adolescente.<br><!-- End of picture text -->  
Adaptado de Marcon e colaboradores (2016)<sup>1</sup>  
> 1. Marcon GTG, Sardagna HV, Schussler D. O questionário SNAP-IV como auxiliar psicopedagógico no diagnóstico preliminar do Transtorno de Déficit de Atenção e Hiperatividade (TDAH). Construção Psicopedag. 2016;24(25):99–118.  
**Referência**  
**APÊNDICE 3**

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **1. Escopo e finalidade do Protocolo Clínico e Diretrizes Terapêuticas (PCDT)** -->
O Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para TDAH teve início com reunião presencial para delimitação do escopo do PCDT. Esta reunião foi composta por cinco membros do Departamento de Gestão, Incorporação de tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS) e da Coordenação de Saúde do Adolescente e do Jovem (COSAJ/DAPES/SAPS); por cinco especialistas (psiquiatras, psicóloga, educadora e assistente social), um representante da sociedade civil organizada ( <mark>Associação Brasileira do Déficit de Atenção)</mark> e; e por três metodologistas e administradores do grupo elaborador.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do protocolo, embasado no disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009<sup>1</sup> e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no SUS, novas tecnologias puderam ser identificadas. Deste modo, o grupo de especialistas foi orientado a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (Anvisa) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DGITIS. Dentre os nove membros do grupo elaborador, cinco eram especialistas (dois psiquiatras, uma psicóloga, uma educadora, uma assistente social), dois metodologistas e a coordenadora administrativa do Projeto no Grupo Elaborador. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade ( **Quadro A** ).  
**Quadro A** - Questionário de conflitos de interesse diretrizes clínico-assistenciais  
|1. V|ocê já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente a|lgum dos benefícios abaixo?|
|---|---|---|
|a)|Reembolso por comparecimento a eventos na área de interesse da diretriz|( ) Sim<br>( ) Não|
|b)|Honorários por apresentação, consultoria, palestra ou atividades de ensino|( ) Sim<br>( ) Não|
|c)|Financiamento para redação de artigos ou editorias|( ) Sim<br>( ) Não|
|d)|Suporte para realização ou desenvolvimento de pesquisa na área|( ) Sim<br>( ) Não|
|e)|Recursos ou apoio financeiro para membro da equipe|( ) Sim|
|||( ) Não|  
|f)<br>Algum outro benefício financeiro|( ) Sim|
|---|---|
||( ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|( ) Sim<br>( ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|( ) Sim<br>( ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|( ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afet<br>atividade na elaboração ou revisão da diretriz?|ados pela sua|
|a) Instituição privada com ou sem fins lucrativos|( ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|( ) Sim<br>( ) Não|
|c) Produtor, distribuidor ou detentor de registro|( ) Sim<br>( ) Não|
|d) Partido político|( ) Sim<br>( ) Não|
|e) Comitê, sociedade ou grupo de trabalho|( ) Sim<br>( ) Não|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A versão preliminar do texto foi pautada na 95ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, que ocorreu em 25 de novembro de 2021. Participaram desta reunião representantes da Secretaria de Atenção Especializada em Saúde (SAES/MS), da Secretaria de Vigilância em Saúde (SVS/MS), da Secretaria Especial de Saúde Indígena (SESAI), do DGITIS/SCTIE, do Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS) e do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS). Os membros da Subcomissão presentes na reunião recomendaram pautar a apreciação do documento na Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec).

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **4. Busca da evidência** -->
Este PCDT foi desenvolvido conforme processos preconizados pela Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ( **Figura 1** ). Durante a reunião de escopo deste PCDT duas questões de pesquisa foram levantadas ( **Quadro B** ).  
**Figura 1** - Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
<!-- Start of picture text -->
*Intervenc¢ao, no caso de estudos experimentais, A<br>*Fator de exposi¢ao, em caso de estudos observacionais<br>Teste indice, nos casos de estudos de acuracia<br>diagnostica<br>EEE<br>*Controle,do fator/exames de acordo disponiveis com tratamento/niveis no SUS de exposic¢o<br>*Desfechos: sempre que possivel, definidos a priori, de<br>acordo com sua importancia<br><!-- End of picture text -->  
**Quadro B -** Questões PICO elencadas para elaboração do PCDT  
|**PICO**|**Pergunta**|**Material**<br>**Suplementar**|
|---|---|---|
|1|Qual a eficácia e a segurança do metilfenidato e da lisdexanfetamina em crianças com<br>transtorno do déficit de atenção com hiperatividade?|1|
|2|Qual a eficácia e a segurança da Terapia cognitivo-comportamental no tratamento de|2|
||crianças, adolescentes e adultos com Transtorno do Déficit de Atenção com Hiperatividade?||  
A equipe de metodologistas envolvida no processo foi responsável pela busca e avaliação de evidências, segundo metodologia GRADE. A busca na literatura foi realizada nas bases de dados PubMed e Embase, bem como no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizados e não padronizados para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e checada por outro, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem dos estudos por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com metaanálise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas  
e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto deste Apêndice 3.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>3</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>4</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>5</sup> . Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas as estratégias de busca, síntese e avaliação das evidências para cada as duas questões PICO realizadas para o presente PCDT.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **5. Recomendações** -->
Em cada pergunta PICO, a qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios GRADE ( _Grading of Recommendations, Assessment, Development and Evaluation_ )<sup>6</sup> . O conjunto de evidências foi avaliado para cada desfecho considerado neste protocolo, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles. Posteriormente, ainda de acordo com a Metodologia GRADE, foi elaborada a tabela _Evidence to Decision_ (EtD), que sumariza os principais achados do processo de avaliação da tecnologia segundo aspectos que devem ser levados em consideração no momento de tomada de decisão sobre a incorporação do produto (magnitude do problema, benefícios, danos, balanço entre danos e benefícios, certeza na evidência, aceitabilidade, viabilidade de implementação, uso de recursos, custo-efetividade, equidade, valores e preferências dos pacientes)<sup>7</sup> . Esta última etapa foi realizada em reunião de consenso em agosto de 2019 com a participação do grupo elaborador (metodologistas e especialistas) e por membros do comitê gestor (DGITIS e áreas técnicas do Ministério da Saúde).  
A relatoria das seções do PCDT foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **PERGUNTA PICO 1** -->
**Questão de pesquisa** : “Qual a eficácia e a segurança do metilfenidato e da lisdexanfetamina em crianças com transtorno do déficit de atenção com hiperatividade?  
Nesta pergunta, pacientes (P) eram indivíduos com idade entre 6 e 17 anos completos; intervenções (I) eram metilfenidato e lisdexanfetamina; comparadores (C) eram placebo, outras apresentações de metilfenidato ou lisdexanfetamina.; e desfechos (O) Melhora clínica, melhora do desempenho escolar; menor uso de drogas; melhor relacionamento pessoal; funcionalidade; qualidade de vida

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Estratégia de busca** -->
As estratégias de busca estão especificadas no **Quadro C** .  
**Quadro C -** Estratégias de busca nas bases de dados PubMed e Embase  
|**Base de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**Medline via PubMed**|"attention deficit disorder with hyperactivity"[MeSH Terms] OR<br>("attention" [All Fields] AND "deficit"[All Fields] AND "disorder"[All<br>Fields] AND "hyperactivity"[All Fields]) OR "attention deficit disorder<br>with hyperactivity"<br>[All Fields] OR "adhd"[All Fields]<br>AND ((rubifen OR lisdexamphetamine OR vyvanse OR Medikinet OR<br>Focalin OR Daytrana OR Centedrin OR Ritalin OR Concerta OR<br>Methylin OR Equasym OR metadate<br>OR methylphenidate))<br>**Data do acesso: 06/01/2020**|5.224|
||exp "Attention Deficit and Disruptive Behavior Disorders"/ adhd.ti,ab.<br>OR addh.ti,ab. OR adhs.ti,ab.OR. (ad adj hd).ti,ab. OR ((attention$ OR<br>behav$) adj3 (defic$ OR dysfunc$ or disorder$)).ti,ab. ((disrupt$ adj3<br>disorder$) OR (disrupt$ adj3 behav$) OR (defian$ adj3 disorder$) OR<br>(defian$ adj3<br>behav$)).ti,ab.<br>AND<br>Methylphenidate.mp.<br>or||
|**EMBASE**|Methylphenidate/70.<br>Methyl<br>phenidat*.mp<br>OR<br>Methyl<br>phenidylacetat*.mp. OR Methylfenid*.mp OR  Methylin.mp. OR<br>Methylofenidan.mp.OR Methylphenid*.mp. OR Methyl phenidyl<br>acetat*.mp.OR<br>Methypatch.mp.<br>OR<br>Metilfenidato.mp<br>OR<br>Concerta.mp.OR Ritalin*.mp OR lisdexamphetamine<br>**Data do acesso: 06/01/2020**|9.938|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Seleção das evidências** -->
A busca das evidências resultou em 15.162 referências (5.224 no MEDLINE e 9.938 no EMBASE). Destas, 2.593 foram excluídas por estarem duplicadas. Um total de 12.569 referências foram triadas por meio da leitura de título e resumos, das quais 122 tiveram seus textos completos avaliados para avaliação da elegibilidade ( **Figura 2** ). Por fim, 17 estudos clínicos comparativos atenderam aos critérios de inclusão.  
**Figura 2 -** Fluxograma de seleção dos estudos **.**  
<!-- Start of picture text -->
bases de gatos:<br>2 pustieo «5224<br>A naseeoese<br>ry Estudos avallados pelo titulo e pelo resumo:12559<br>a<br>luo: 12.448<br>2 publica elutionexchsto:105 segundo ets de<br>stistas de estudos excidsejustifeatvas<br>apresentadas<br>no Material Siplementar 1<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Descrição dos estudos e resultados** -->
A descrição sumária dos estudos incluídos encontra-se na **Tabela A** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela B** . Resultados de eficácia encontram-se na **Tabela C** . Os resultados de segurança encontram-se na **Tabela D** .  
**Tabela A -** Características dos estudos incluídos  
|**Estudo**<br>**(Autor/Ano)**<br>**MPH vs. PLA**|**Desenho/ Local**<br>**de estudo**<br>|**Objetivos**|**Faixa etária**<br>**participantes**|**Intervenção**|**Comparad**<br>**or**|**Dose ótima média**<br>**(DP)**|**Tempo de**<br>**intervenção**|**Tempo de**<br>**seguimento médio**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|
|**Biederman**<br>**et al., 2003**<sup>8</sup>|ECR paralelo<br>multicêntrico/<br>EUA|Avaliar a eficácia e segurança<br>de formulação de metilfenidato<br>de liberação prolongada<br>(sistema SODAS™),<br>comparado ao placebo, em<br>crianças com TDAH em um<br>cenário naturalístico.|6 – 14 anos|Metilfenidato de<br>liberação<br>prolongada<br>(Sistema<br>SODAS®)|Placebo|A maioria dos<br>participantes recebeu<br>entre 30 e 40 mg|2 semanas|13 semanas (sem<br>informação de média<br>e DP por grupo);<br>considerado período<br>total para as fases pré<br>e pós-randomização.|
|**Findling et**<br>**al., 2006**<sup>9</sup>|ECR paralelo e<br>multicêntrico/<br>EUA, Canadá e<br>Austrália|Comparar a eficácia de uma<br>formulação de MPH de<br>liberação prolongada<br>comparado ao MPH de<br>liberação imediata<br>administrada 2x ao dia em<br>crianças com TDAH em<br>ambiente comunitário e<br>comparara a segurança e<br>tolerabilidade das duas<br>apresentações de MPH e<br>placebo|6 – 12 anos|Metilfenidato de<br>liberação imediata<br>(2x/ dia)|Placebo|A maioria das<br>crianc1as recebeu<br>entre 20 (44,7%) e 40<br>mg (45,6%)|3 semanas|NR|
|**Findling et**<br>**al., 2008**<sup>10</sup>|ECR paralelo e<br>multicêntrico/<br>NR|Avaliar a eficácia e segurança<br>de apresentação de MPH|6 – 12 anos|MPH de liberação<br>prolongada<br>(sistema OROS®)|Placebo|MPH 18 mg: 4,4%<br>MPH 27 mg: 19,1%|7 semanas|NR|  
|||transdérmico comparado ao<br>MPH ER OROS™ e placebo.||||MPH 36 mg: 32,4%<br>MPH 54 mg: 44,1%|||
|---|---|---|---|---|---|---|---|---|
|**Rapport et**<br>**al., 1994**<sup>11</sup>|ECR<br>(crossover)/EU<br>A|Avaliar a magnitude e o<br>significado clínico dos efeitos<br>do metilfenidato (MPH) no<br>comportamento e desempenho<br>acadêmico de 76 crianças com<br>TDAH|6-11 anos|Metilfenidato de<br>liberação imediata<br>em diferentes<br>doses:<br>5 mg ( 0,10 a 0,26<br>mg / kg),<br>10 mg (0,20 a<br>0,52 mg / kg),<br>15 mg (0,30 a<br>0,79 mg / kg)<br>20 mg (0,40 a 1,1<br>mg / kg).|<br> <br> <br> <br>Placebo|NR|7 dias de<br>placebo e 6<br>dias<br>consecutivos<br>com cada dose<br>(24 dias)|6 semanas|
|**Rapport et**<br>**al., 2008**<sup>12</sup>|ECR<br>(crossover) com<br>duas<br>intervenções/<br>EUA|Examinar os efeitos<br>inesperados relacionados ao<br>metilfenidato (MPH)|6-11 anos|Metilfenidato de<br>liberação imediata<br>(5 mg, 10 mg, 15<br>mg e 20 mg)|Placebo|NR|7 dias de<br>placebo e 6<br>dias<br>consecutivos<br>com cada dose<br>(24 dias)|6 semanas|
|**Schulz et al.,**<br>**2010**<sup>13</sup>|ECR<br>(crossover)<br>multicêntrico e<br>com 3<br>intervenções/|O objetivo principal deste<br>estudo foi demonstrar a<br>eficácia de MPH SODAS®<br>20mg, mostrando<br>superioridade ao placebo. Os|6-14 anos|MPH ER<br>(SODAS® e<br>Medikinet®)20<br>mg uma vez ao<br>dia|Placebo|NR|Fase de pré-<br>randomização<br>e 3 períodos<br>de tratamento<br>de 7 dias cada.|Os escores do<br>SKAMP foram<br>classificados 1,5, 3,0,<br>4,5, 6,0 e 7,5 horas<br>após a ingestão do|
||Alemanha|objetivos secundários incluíam||||||medicamento (no|  
|||segurança / tolerabilidade e<br>outros parâmetros de eficácia.||||||sétimo dia de cada<br>intervenção).|
|---|---|---|---|---|---|---|---|---|
|**Simonoff et**<br>**al., 2013**<sup>14</sup>|ECR|Avaliar a eficácia e a<br>segurança do medicamento<br>estimulante ao longo de 16<br>semanas|7-15 anos|MPH IR.(0,5, 1,0<br>e 1,5 20 mg/kg)|Placebo|0,5 mg/kg: 13,1%<br>1,0 mg/kg: 23,0%<br>1,5 mg/kg: 45,9%<br>Nenhuma: 18,0%<br>(pacientes cuja<br>designação de dose<br>ótima foi nenhum e<br>que não fizeram uso<br>regular de MPH)|16 semanas|16 semanas|
|**Tucha et al.,**<br>**2006**<sup>15</sup>|Em um estudo<br>cruzado, duplo-<br>cego, controlado<br>por placebo|O objetivo do presente estudo<br>foi monitorar o efeito do MPH<br>em várias medidas de atenção<br>em crianças com TDAH|7-14 anos|Metilfenidato<br>19 mg (10-50 mg)|Placebo|NR|NR|NR|
|**Wilens et al.,**<br>**2006**<sup>16</sup>|ECR paralelo<br>multicêntrico/E<br>UA|Relatar os resultados de um<br>estudo controlado<br>multicêntrico entre<br>adolescentes com TDAH,<br>avaliando a eficácia e<br>tolerabilidade do MPH ER<br>OROS.|13-18 anos|MPH ER OROS<br>(18, 36, 54, ou 72<br>mg)|Placebo|18 mg: 7,4%<br>36 mg: 28%<br>54 mg: 28%<br>72 mg: 37%|2 semanas|8 semanas|
|**Wolraich et**<br>**al., 2001**<sup>17</sup>|ECR|Determinar a segurança e<br>eficácia do MPH ER OROS|6 -12 anos|MPH ER OROS|Placebo|Todos os pacientes<br>começaram a adotar<br>uma OROS MPH de<br>18 mg por dia e este<br>foi aumentado para|**Apenas**<br>**reportado**<br>**como fim do**<br>**tratamento**|**28 dias**|  
|**MPH IR vs.**|**MPH ER**|||||36 mg por dia e<br>depois para 54 mg<br>por dia, conforme<br>necessário. A dose<br>diária total média<br>para pacientes do<br>grupo foi de 29,5 mg<br>por dia (0,9 0,4 mg /<br>kg / d) para MPH IR<br>e 34,3 mg por dia<br>(1,1 0,5 mg / kg / d)<br>para OROS MPH.|||
|---|---|---|---|---|---|---|---|---|
|**Pelham et**<br>**al., 2001**<sup>18</sup>|ECR crossover<br>unicêntrico/<br>EUA|Avaliar a evolução temporal, a<br>eficácia, efetividade e<br>segurança do MPH ER<br>OROS®|6 – 12 anos|MPH ER OROS®|MPH IR 3x/<br>dia<br>Placebo|NR|1 semana|4 semanas|
|**Steele et al.,**<br>**2007**<sup>13</sup>|ECR paralelo<br>multicêntrico/C<br>anadá|Avaliar a eficácia e<br>tolerabilidade MPH ER<br>OROS® em relação aos<br>cuidados usuais com   MPH IR<br>em crianças com TDAH|6 -12 anos|MPH ER OROS|Cuidado<br>usual +<br>MPH IR|MPH OROS®: 37,8<br>(11,9) mg<br>MPH IR: 33,3 (13,2)<br>mg|8 semanas|4 semanas, 8 semanas<br>e_endpoint_|
|**Wolraich et**<br>**al., 2001**<sup>17</sup>|ECR|Determinar a segurança e<br>eficácia do MPH ER OROS|6 -12 anos|MPH ER OROS|Placebo<br>MPH IR|Todos os pacientes<br>começaram a adotar<br>uma MPH ER OROS<br>de 18 mg por dia e<br>este foi aumentado|**Apenas**<br>**reportado**<br>**como fim do**<br>**tratamento**|**28 dias**|  
|||||||para 36 mg por dia e<br>depois para 54 mg<br>por dia, conforme<br>necessário. A dose<br>diária total média<br>para pacientes do<br>grupo locais foi de<br>29,5 mg por dia (0,9<br>0,4 mg / kg / d) para<br>MPH IR e 34,3 mg<br>por dia (1,1 0,5 mg /<br>kg / d) para MPH ER<br>OROS|||
|---|---|---|---|---|---|---|---|---|
|**LDX vs. PLA**|||||||||
|**Biederman**<br>**et al., 2007**<sup>18</sup>|ECR paralelo<br>multicêntrico/<br>EUA|Avaliar a eficácia e<br>tolerabilidade de LDX em dose<br>única diária em crianças em<br>idade escolar com TDAH<br>tratadas na comunidade e<br>comparar a duração de ação da<br>LDX ao placebo.|6 – 12 anos|Lisdexanfetamina|Placebo|LDX 30 mg: n=71;<br>LDX 50 mg: n=74;<br>LDX 70 mg: n=73|4 semanas|6 semanas|
|**Findling et**<br>**al., 2011**<sup>19</sup>|ECR paralelo<br>multicêntrico/<br>EUA|Avaliar a segurança e a<br>eficácia da lisdexanfetamina<br>comparada ao placebo em<br>adolescentes com sintomas<br>moderados de TDAH|13 – 17 anos|Lisdexanfetamina|Placebo|LDX 30 mg: n=78;<br>LDX 50 mg: n=77;<br>LDX 70 mg: n=78|4 semanas|NR|  
|**Coghill et**<br>**al., 2013**<sup>20</sup>|ECR paralelo<br>multicêntrico/<br>Europa|Avaliar eficácia e segurança de<br>lisdexanfetamina comparada<br>ao MPH ER OROS em<br>crianças e adolescentes com<br>TDAH no mínimo moderada|6 – 17 anos|Lisdexanfetamina|MPH ER<br>OROS<br>Placebo|LDX: 53,8 (15,6) mg/<br>dia<br>MPH: 45,4 (12,7)<br>mg/ dia|<br>7 semanas|8 semanas (sem<br>informação de média<br>e DP por grupo)|
|---|---|---|---|---|---|---|---|---|
|**Wigal et al.,**<br>**2009**<sup>21</sup>|ECR<br>(crossover)|Avaliar a eficácia e a duração<br>da eficácia da LDX comparada<br>a placebo|6-12 anos|Lisdexanfetamina<br>(30, 50, 70<br>mg/dia)|Placebo|30 mg: 39,3%<br>50 mg: 42,7%<br>70 mg: 18,0%|Fase cruzada<br>de 2 vias (1<br>semana cada)|30 dias|
|**LDX vs. MPH**|||||||||
|**Newcorn et**<br>**al., 2017**<sup>22</sup>|2 ECR paralelos<br>e multicêntricos<br>(fase IV)|Avaliar a eficácia e segurança<br>da lisdexanfetamina vs.  MPH<br>ER OROS® no tratamento de<br>TDAH|13 – 17 anos|Lisdexanfetamina|MPH ER<br>OROS<br>Placebo|Dose flexível:<br>LDX: 50,15 (12,50)<br>mg/ dia<br>MPH: 44,47 (12,75)<br>mg/dia|||
|||||||Eventos de segurança<br>– dose flexível<br>LDX 30 mg: 7,1%<br>LDX 50mg: 25,5%<br>LDX 70 mg: 51,1%<br>MPH 36 mg: 16,8%<br>MPH 54 mg: 20,7%<br>MPH 72 mg: 41,3%<br>No estudo de dose<br>forçada, todos os<br>pacientes tiveram<br>incrementos até|8 semanas|13 semanas|  
|chegar à dose|
|---|
|máxima (LDX 70 mg|
|e MPH OROS®|
|72mg)|  
**Tabela B -** Caracterização dos participantes de cada estudo  
|**Estudo**<br>**(Autor/Ano)**<br>**MPH vs. PLA**|<br>**Participantes**<br>**(n)**<br>|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|**Biederman**<br>**et al., 2003**<sup>8</sup>|Pacientes com<br>TDAH (136)<br>MPH: n=65<br>PLA: n=71|MPH: 9,5<br>(1,75)<br>PLA: 9,5<br>(1,95)|76,5%<br>MPH:<br>80,0%<br>PLA:73,2%|Alterações<br>comportamentais<br>foram as mais<br>frequentes<br>MPH: 24,6%<br>PLA: 25,4%|37,9%<br>utilizaram<br>MPH<br>(outros<br>medicamentos<br>não<br>informados)|Combinada<br>MPH: 64,6%<br>PLA: 84,5%|NR|CADS – T<br>geral:<br>MPH: 27,2 (15,45)<br>PLA: 28,3 (15,83)<br>desatenção:<br>MPH: 14,9 (8,38)<br>PLA: 14,9 (7,94)<br>hiperatividade/ impulsividade:<br>MPH: 12,3 (8,06)<br>PLA: 13,4 (8,83)|NR|
|**Findling et**<br>**al., 2006**<sup>9</sup>|Pacientes com<br>TDAH em<br>tratamento<br>estável com<br>MPH nas|MPH: 9,5<br>(1,75)<br>PLA: 9,5<br>(1,95)|MPH:<br>78,9%<br>PLA: 76,1%|NR|100% em uso<br>de MPH (dose<br>estável nas<br>últimas 3<br>semanas)|Combinada<br>MPH: 70,7%<br>PLA: 69,6%|CGI<br>leve ou<br>moderada<br>MPH: 52,5%<br>PLA: 53,9%|Iowa Conners’ e Snap-IV:<br>MPH: 3,0 (3,71)<br>PLA: 1,8 (2,63)|NR|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||últimas 3<br>semanas (327)<br>MPH IR:<br>n=133<br>PLA: n=46|||||||||
|**Findling et**<br>**al., 2008**<sup>10</sup>|Pacientes com<br>TDAH sem<br>outras<br>comorbidades<br>associadas<br>(exceto<br>ODD),<br>virgens de<br>tratamento ou<br>que tenham<br>reposta a<br>estimulantes<br>conhecida.<br>(282)<br>MPH OROS:|8,8 (1,94)<br>MPH: 8,8<br>(1,94)<br>PLA: 8,5<br>(1,81)|MPH: 66%<br>PLA: 73,9%|NR|MPH: 13%<br>PLA: 12%|Combinada<br>MPH: 86,2%<br>PLA: 70,5%|NR|ADHD-RS-IV:<br>MPH: 43,8<br>PLA: 41,9|NR|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||n=89<br>PLA: n=85|||||||||
|**Rapport et**<br>**al., 1994**<sup>11</sup>|Pacientes com<br>TDAH (76)|8,51 anos|86,8%|Mania|NR|NR|NR|NR|102.17<br>(10.87)|
|**Rapport et**<br>**al., 2008**<sup>12</sup>|Pacientes com<br>TDAH (65)|8,56 anos<br>(1,25)|89,2%|NR|8 crianças já<br>haviam<br>experimentado<br>terapia<br>estimulante nos<br>últimos quatro<br>anos. Nenhuma<br>utilizou<br>psicoestimulant<br>e<br>imediatamente<br>antes do início<br>do presente<br>estudo|NR|NR|**Sintomas comportamentais e**<br>**físicos- classificação das crianças**<br>Comer menos 0,23 (20%)<br>Mais bebidas 1,22 (53,1%)<br>Boca seca  0,59 (35,9%)<br>Mais movimentos intestinais 0,09<br>(6,3%)<br>Menos movimentos intestinais<br>0,36 (21,9%)<br>Movimentos intestinais mais<br>difíceis 0,05 (4,9%)<br>**_Queixas comuns a todas as_**<br>**_crianças_**<br>Dores estomacais 0,46 (33,8%)<br>Cãibras 0,31 (20%)<br>Dores de cabeça 0,50 (23,4%)<br>Tontura 0,23 (13,8%)|<br> <br>102,8<br>(10,0)|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||Cansaço/fadiga  0,60 (32,3%)<br>Dores musculares 0,34 (25%)||
|**Schulz et al.,**<br>**2010**<sup>23</sup>|Pacientes com<br>TDAH (147)|10,2 anos<br>(1,8)|80,9%|10 (6,8%)<br>Distúrbios no<br>comportamento<br>social (n=4)<br>Insônia inicial<br>(n=2)<br>Distúrbio<br>definitivo de<br>oposição (n=2)<br>Disfemia (n=1)<br>Encoprese (n=1)|<br> <br> <br> <br> <br>Nenhum 0<br>(0%)<br>MPH ER 80<br>(54%)<br>MPH IR55<br>(37%)<br>Outros 12 (8%)|<br> <br> <br>Desatento 54<br>(37%)<br>Hiperativo-<br>impulsivo 12<br>(8%)<br>Combinado 81<br>(55%)|<br> <br>NR|NR|NR|
|**Simonoff et**<br>**al., 2013**<sup>14</sup>|Pacientes com<br>TDAH (122)<br>PLA: 36 (59)<br>MPH:37 (61)|<br>PLA: 11,5<br>MPH: 10,8|70%<br>PLA: 66%<br>MPH: 74%|<br>NR|NR|NR|NR|**Índice Conners de TDAH para**<br>**pais (M, DP)**<br>PLA: 27,8 (5,1) MPH: 27,4 (6,6)<br>**Índice Conners de TDAH (M,**<br>**DP)**<br>PLA: 19,7 (9,7) MPH: 21,5 (9,3)|PLA: 53<br>(10,5)<br>MPH: 54<br>(9,6)|  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||**Escala Conners de**<br>**hiperatividade dos pais  (M, SD)**<br>PLA: 12,1 (3,7) MPH: 12,0 (4,0)<br>**Escala Conners de**<br>**hiperatividade de professor (M,**<br>**DP)**<br>PLA: 9,6 (5,8) MPH: 10,1 (6,0)<br>**Subescala de hiperatividade**<br>**ABC (M, DP)**<br>PLA: 32,6 (9,7) MPH: 30,8 (8,7<br>**Subescala de hiperatividade do**<br>**professor ABC (M, DP)**<br>PLA: 20,5 (13,7) MPH: 21,9<br>(13,0)<br>**Índice de estresse parental (M,**<br>**DP)**<br>PLA: 104,1 (20,1) MPH: 107,8<br>(23,8)||  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|**Tucha et al.,**<br>**2006**<sup>15</sup>|Pacientes com<br>TDAH (58)|10,81 anos<br>(EP=0,30<br>anos)|84,5%|Os participantes<br>não<br>apresentavam<br>comorbidades<br>psiquiatricas|NR|NR|NR|**Prontidão tônica [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**295,57 (±8,20)<br>**PLA:**302,84 (±8,06)<br>**Atenção fásica [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**273,30 (±5,95)<br>**PLA:**281,00 (±7,43)<br>**Vigilância [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**273,30 (±5,95)<br>**PLA:**281,00 (±7,43)<br>**Atenção focalizada [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**535,72 (±16,62)<br>**PLA:**549,69 (±17,95)<br>**Integração de informações**|<br>98,09|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||**sensoriais [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**515,80 (±14,60)<br>**PLA:**537,27 (±16,25)<br>**Flexibilidade [média (DP)]**<br>Tempo de reação (em ms)-<br>**MPH:**1076,40 (±45,33)<br>**PLA:**1073,99 (±42,94)||
|**Wilens et al.,**<br>**2006**<sup>16</sup>|<br>Pacientes com<br>TDAH (136)<br>MPH: n=87<br>PLA: n=90|14,6 anos|MPH:= 64<br>(73,6)<br>PLA: 78<br>(86,7)|NR|NR|NR|NR|**ADHD RS score média (DP)**<br>**_Investigador_** <br>MPH= 31,55 ± 9,42<br>PLA=  30,99 ± 9,64<br>**_Pais_ **<br>MPH=  30,65 ± 9,81<br>PLA=  30,99 ± 11,55<br>**Índice de conflitos entre pais e**<br>**filhos**<br>MPH= 0,286 ± 0,174<br>PLA= 0,259 ± 0,182<br>**Escala  de auto relato de**<br>**sintomas para adolescentes**|<br> <br> <br> <br>NR|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||**Conners-Wells Índice de conflito**<br>**infantil**<br>MPH=89,81 ± 41,44<br>PLA=  94,02 ± 49,20|<br>|
|**Wolraich et**<br>**al., 2001**<sup>17</sup>|Pacientes com<br>TDAH (282)<br>MPH ER<br>OROS n= 95<br>MPH IR n=<br>97<br>Placebo n=90|<br>9,0 (1,8)<br>MPH ER<br>OROS =<br>8,8 [1,7],<br>IRMPH=<br>9,1 [1,9],<br>placebo=<br>8,9 [1,8)|<br> <br> <br>82,6%<br>OROS<br>MPH=<br>77,9%<br>IRMPH=<br>86,6%<br>placebo=<br>83,3%|<br> <br> <br>**Distúrbio de**<br>**oposição**<br>**(41,8%)**<br>MPH ER OROS<br>=35 (36,8) %<br>MPH IR = 40<br>(41,2)%<br>placebo= 43<br>(47.8)%<br>T**ranstorno de**<br>**conduta**<br>**(11,3%),**<br>MPH ER OROS<br>=9 (9,5) %<br>MPH IR = 9<br>(9,3)8%<br>placebo= 14|<br> <br> <br> <br> <br>**Nenhum**<br>MPH ER<br>OROS =20<br>(21,1)<br>MPH IR =18<br>(18,6)<br>Placebo= 19<br>(21,1)<br>**Sem**<br>**medicamentos**<br>MPH ER<br>OROS = 3<br>(3,2)<br>IRMPH= 9<br>(9,3)<br>placebo= 6<br>(6,7)|<br> <br> <br> <br> <br> <br>Combinado=73,4<br>%<br>Hiperativo-<br>impulsivo=<br>7,1%,<br>Desatento=<br>19,5%|NR|**Escala IOWA média (DP)-**<br>**Professores**<br>**_Desatenção / Hiperatividade_**<br>MPH ER OROS: 9,74 (4,1)<br>IR MPH: 9,94 (3,7)<br>Placebo: 10,28 (3,8)<br>**_Oposição / Desafio (SD)_**<br>MPH ER OROS:4,34 (4,2)<br>IR MPH: 3,83 (4,4)<br>Placebo: 5,44 (4,5)<br>**Escala IOWA média (DP)-  Pais**<br>**_Desatenção / Hiperatividade_**<br>MPH ER OROS: 11,08 (2,6)<br>IR MPH: 9,90 (3,2)<br>Placebo: 10,44 (3,0)<br>**_Oposição / Desafio (SD)_**<br>MPH ER OROS: 8,15 (4,4)|<br> <br> <br> <br> <br> <br> <br>> 70|
|||||(15,6)%|<br>**Sem-MPH**|||MPH IR: 7,34 (4,0)||  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||**Transtorno de**<br>**tiques (5,3%),**<br>MPH ER OROS<br>= 6 (6,3)%<br>MPH IR =5<br>(5,2)%<br>placebo= 4<br>(4,4)% <br>**Transtorno de**<br>**ansiedade**<br>**(1,4%)**<br>MPH ER OROS<br>= 0<br>MPH IR = 0<br>placebo= 4<br>(4,4)%<br>**Depressão**<br>**(0,7%)**<br>MPH ER OROS<br>= 0<br>MPH IR = 1<br>(1,0)%|<br> <br> <br> <br> <br> <br> <br> <br>MPH ER<br>OROS = 3<br>(3,2)<br>IRMPH= 8<br>(8,2)<br>placebo=5 (5,6)<br>**MPH**<br>MPH ER<br>OROS =69<br>(72,6)<br>MPH IR = 62<br>(63,9)<br>placebo= 60<br>(66,7)|<br> <br> <br> <br>||Placebo: 8,19 (3,8)<br>**_Hiperatividade / Impulsividade-_**<br>**_SNAP-IV  (SD)_**<br>MPH ER OROS: 1,60 (0,9)<br>MPH IR: 1,62 (0,8)<br>Placebo 1,00 (0,8)<br>**_Transtorno Opositor-desafiador-_**<br>**_SNAP-IV_**<br>MPH ER OROS: 0,89 (0,9)<br>MPH IR: 0,76 (0,8)<br>Placebo: 0,96 (0,8)<br>**_Eficácia Global_**<br>MPH ER OROS:  1,42 (0,97)<br>MPH IR:  1,43 (1,01)<br>Placebo: 0,62|<br> <br> <br> <br> <br> <br> <br> <br>|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||placebo= 1<br>(1,0)%||||||
|**MPH IR vs.**|**MPH ER**|||||||||
|**Pelham et**<br>**al., 2011**<sup>24</sup>|Crianças com<br>TDAH em uso<br>de MPH (70)|9,1 (1,6)|89%|43% TOD<br>37% TC|100% MPH|NR|NR|Leitura (WIAT): 104,1 (13,2)<br>Matemática (WIAT): 98,8 (12,9)<br>Soletração (WIAT): 96,3 (12,9)<br>IOWA Conners’ Rating –<br>Professores:<br>D/H: 9,68 (3,81)<br>O/D: 4,07 (4,28)<br>IOWA Conners’ Rating  - Pais<br>D/H: 10,42 (3,02)<br>O/D: 7,28 (4,00)<br>SNAP – Professores:<br>D: 2,04 (0,63)<br>H/I: 1,62 (0,89)<br>O/D: 1,56 (0,68)<br>SNAP – Pais:<br>D: 2,26 (0,40)<br>H/I: 1,96 (0,70)<br>O/D: 1,56 (0,68)<br>DBD – Professores:|NR|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||D: 1,82 (0,79)<br>H/I: 1,47 (0,86)<br>O/D: 0,75 (0,73)<br>DBD – Pais:<br>D: 2,15 (0,46)<br>H/I: 1,47 (0,86)<br>O/D: 0,75 (0,73)||
|**Steele et al.,**<br>**2007**<sup>13</sup>|Pacientes com<br>TDAH (147)<br>MPH ER<br>OROS: 72<br>MPH IR: 73|<br> <br>MPH ER<br>OROS =<br>9,0 (± 2,1)<br>MPH IR =<br>9,1 (± 1,8)|<br>86,3%<br>MPH ER<br>OROS = 61<br>(84,7%)<br>MPH IR =<br>60 (82,2%)|<br> <br>**Distúrbio de**<br>**oposição de**<br>**oposição**<br>MPH ER OROS<br>= 31 (43,1%)<br>MPH IR= 28<br>(38,4%)<br>**transtorno de**<br>**conduta (0,7%)**<br>MPH ER OROS<br>= 1 (1,4%)<br>MPH IR= 0<br>**ansiedade**<br>**(4,1%)**<br>MPH ER|<br> <br> <br> <br>**NR**|**Combinado**<br>**(79,3%)**<br>OROS-MPH= 57<br>(79,2%)<br>MPH IR=  58<br>(79,5%)<br>H**iperativo-**<br>**impulsivo**<br>**(2,1%)**<br>OROS-MPH= 2<br>(2,8%)<br>MPH IR=  1<br>(1,4%)<br>D**esatento**<br>**(18,6%)**|NR|**Escala SNAP-IV item 26 (itens**<br>**ADHD + ODD):**<br>MPH ER OROS**=**51,5 (± 13,1 )<br>**IR-MPH=**51,5 (± 12,4)<br>**Escala SNAP-IV  item 18**<br>**(ADHD items)**<br>MPH ER OROS**=**38,0 (± 9,60<br>**IR-MPH=**38,8 (± 9,6)<br>**Escala de Classificação dos Pais**<br>**da IOWA:**<br>MPH ER OROS**=**20,2 (± 6,1)<br>**IR-MPH=**19,9 (± 5,5)<br>**Escala de classificação dos pais**<br>**da IOWA, subescala de**|<br> <br> <br>> 70|  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|**LDX vs. PLA**||||OROS= 4 (5,5%)<br>MPH IR= 2<br>(2,7%)||OROS-MPH=<br>13 (18%)<br>MPH IR= 14<br>(19,1%)||**desatenção / superatividade**<br>**OROS-MPH**=10,9 (± 3,0)<br>MPH IR**=**11,2 (±2,7)<br>**Escala de classificação dos pais-**<br>**Conners**<br>MPH ER OROS**=**55,8 (± 14,1)<br>MPH IR**=**55,5 (± 11,8)<br>**Índice de Estresse dos Pais,**<br>**Formato Curto:**<br>MPH ER OROS**=**117,9 (± 22,2)<br>MPH IR**=**116,8 (± 19,4)<br>**Escala visual analógica (mm):**<br>**lição de casa**<br>MPH ER OROS**=**67,0 (± 24,8)<br>MPH IR**=**67,2 (± 23,6)<br>**Escala visual (mm): Interação**<br>**Social**<br>MPH ER OROS**=**44,6 (± 27,6)<br>MPH IR**=**42,7 (± 29,9)<br>**CGI-I:**MPH ER OROS**=**2,4 (±<br>1,3) MPH IR**=**2,7 (± 1,4)|<br> <br> <br> <br> <br> <br>|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|**Biederman**<br>**et al., 2007**<sup>18</sup>|Pacientes com<br>TDAH<br>combinada ou<br>impulsiva/<br>hiperativa<br>com escore de<br>ADHD-RS-IV<br>≥ 28 (290)<br>LDX 30 mg:<br>n=71; LDX<br>50 mg: n=74;<br>LDX 70 mg:<br>n=73; PLA:<br>n=72|9,0 (1,8)<br>LDX 30<br>mg: 9,0<br>(1,9)<br>LDX 50<br>mg: 8,9<br>(1,8)<br>LDX 70<br>mg: 8,7<br>(1,8)<br>PLA: 9,4<br>(1,7)|69,3%<br>LDX 30<br>mg: 74,6%;<br>LDX 50<br>mg: 62,2%<br>LDX 70<br>mg: 71,2%<br>PLA: 69,4%|NR|LDX 30 mg:<br>40,8%<br>LDX 50 mg:<br>35,1%<br>LDX 70 mg:<br>30,1%<br>PLA: 36,1%|Combinada<br>LDX 30 mg:<br>94,4%<br>LDX 50 mg:<br>95,9%<br>LDX 70 mg:<br>97,3%<br>PLA: 95,8%|(De acordo com<br>escore CGI)<br>**Leve:**<br>LDX 30 mg: 0<br>LDX 50 mg:<br>1,4%<br>LDX 70 mg: 0<br>PLA: 0<br>**Moderado:**<br>LDX 30 mg:<br>36,6%<br>LDX 50 mg:<br>33,8%<br>LDX 70 mg:<br>34,2%<br>PLA: 37,5%<br>**Grave:**<br>LDX 30 mg:<br>12,7%<br>LDX 50 mg:<br>12,2%<br>LDX 70 mg:|NR|NR|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||21,9%<br>PLA: 15,3%<br>**Extremo:**<br>LDX 30 mg: 0<br>LDX 50 mg:<br>4,1%<br>LDX 70 mg: 0<br>PLA: 1,4%|||
|**Findling et**<br>**al., 2011**<sup>19</sup>|Adolescentes<br>com sintomas<br>moderados de<br>TDAH|14,6 (1,31)|70,30%|NR|NR|Combinada<br>LDX: 63,9%<br>PLA: 70,1%||ADHD – RS -IV<br>37,8 (6,88)<br>LDX 30 mg: 38,3 (6,71)|LDX:<br>79,5<br>(12,24)<br>LDX 30|
||(ADHD-RS-|||||||LDX 50 mg: 37,3 (6,33)|mg: 79,0|
||IV ≥ 28) (314)|||||||LDX 70 mg: 37,0 (7,30)|(10,03)|
||LDX: n=235;|||||||PLA: 38,5 (7,11)|LDX 50|
||PLA: n=79|||||||CGI<br>LDX 30 mg: 4,5 (0,55)<br>LDX 50 mg: 4,5 (0,62)<br>LDX 70 mg: 4,5 (0,60)<br>PLA: 4,5 (0,62)|mg: 80,5<br>(10,63)<br>LDX 70<br>mg: 78,8<br>(15,38)<br>PLA:|  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||||79,2<br>(11,08)|
|**Coghill et**<br>**al., 2013**<sup>20</sup>|Pacientes com<br>TDAH pelo<br>menos<br>moderada<br>(336)<br>LDX: n=113;<br>PLA: n=111,<br>MPH: n=112|10,9 (2,8)<br>LDX: 10,9<br>(2,9)<br>PLA: 11,0<br>(2,8)<br>MPH: 10,9<br>(2,6)|LDX:<br>78,4%<br>PLA: 82,7%<br>MPH:<br>81,1%|LDX: 17,1%<br>PLA: 18,2%<br>MPH: 26,1%|Sim|Combinada<br>LDX: 77,5%<br>PLA: 79,1%<br>MPH: 86,4%|NR|**ADHD-RS-IV**<br>LDX: 41,0 (7,3)<br>PLA: 41,2 (7,2)<br>MPH: 40,4 (6,8)<br>**CGI**<br>LDX: 5,0 (0,8)<br>PLA: 4,9 (0,8)<br>MPH: 5,0 (0,8)|NR|
|**Wigal et al.,**<br>**2009**<sup>25</sup><br>**LDX vs. MPH**|Pacientes com<br>TDAH (117)<br>|10,1 (1,5)<br>30 mg/dia=<br>9,8 (1,5)<br>50 mg/dia=<br>10,2 (1,3)<br>70 mg/dia=<br>10,4 (1,9)|<br> <br> <br>98 (76)<br>30 mg/dia=<br>44 (75,9)<br>50mg/dia=<br>37 (74,0)<br>70 mg/dia=<br>17 (81,0)|<br> <br> <br>Pacientes com<br>comorbidades<br>foram excluídos|Otimização da<br>dose durante 4<br>semanas (30,<br>50, 70 mg/dia)|NR|NR|**Escore total do TDAH-RS-IV-**<br>**média (DP)**<br>30 mg/d= 40,5 (6,7)<br>50 mg/d= 43,4 (7,5)<br>70 mg/d=45,7 (5,7)<br>**SKAMP-Total- LS média (SE)**<br>**Pré-dose**<br>LDX= 1,68 (0,07)<br>PLA= 1,22 (0,07)|<br> <br> <br> <br> <br>>80|  
|**Estudo**<br>**(Autor/Ano)**|<br>**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
|**Newcorn et**<br>**al., 2017**<sup>22</sup>|Dose flexível<br>Pacientes com<br>TDAH no<br>mínimo<br>moderada<br>(ADHD-RS-<br>IV ≥ 28)<br>(n=464)<br>LDX: n=186;<br>MPH: n=185;<br>PLA: n=93|LDX: 14,7<br>(1,38)<br>MPH: 14,7<br>(1,32)<br>PLA: 14,8<br>(1,43)|LDX:<br>66,3%<br>MPH:<br>66,3%<br>PLA: 67%|NR|NR|Combinado:<br>LDX: 50,0%<br>MPH: 64,1%<br>PLA: 54,9%<br>Predomínio de<br>desatenção:<br>LDX: 49,5%<br>MPH: 33,7%<br>PLA: 45,1%|Levemente<br>doente:<br>LDX: 0,5%<br>MPH: 0<br>PLA: 0<br>Moderadamente<br>doente:<br>LDX: 60,9%<br>MPH: 56,0%<br>PLA: 52,7%<br>Notavelmente<br>doente:<br>LDX: 37,5%<br>MPH: 40,8%<br>PLA: 39,6%<br>Gravemente<br>doente:<br>LDX: 1,1%<br>MPH: 3,3%<br>PLA: 7,7%|ADHD-RS-IV:<br>LDX: 36,6 (6,34)<br>MPH: 37,8 (6,06)<br>PLA: 38,3 (6,89)|NR|
|**Newcorn et**<br>**al., 2017**<sup>22</sup>|Dose forçada<br>Pacientes com|LDX: 14,6<br>(1,38)|LDX:<br>61,9%|NR|NR|Combinado:<br>LDX: 67,0%|Doença<br>Borderline:|ADHD-RS-IV:<br>LDX: 37,2 (6,46)|NR|  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||TDAH no<br>mínimo<br>moderada<br>(ADHD-RS-<br>IV ≥ 28)<br>(n=549)<br>LDX: n=219;<br>MPH: n=220;<br>PLA: n=110|MPH: 14,7<br>(1,42)<br>PLA: 14,7<br>(1,37)|MPH:<br>68,5%<br>PLA: 69,1%|||MPH: 65,8%<br>PLA: 61,8%<br>Predomínio de<br>desatenção:<br>LDX: 32,1%<br>MPH: 32,4%<br>PLA: 36,4%|LDX: 0<br>MPH: 0<br>PLA: 0,9<br>Levemente<br>doente:<br>LDX: 1,8%<br>MPH: 1,8%<br>PLA: 0,5%<br>Moderadamente<br>doente:<br>LDX: 42,7%<br>MPH: 52,5%<br>PLA: 54,5%<br>Notavelmente<br>doente:<br>LDX: 48,6%<br>MPH: 41,1%<br>PLA: 37,3%<br>Gravemente<br>doente:<br>LDX: 6,9%|MPH: 36,9 (6,42)<br>PLA: 38,3 (6,89)||  
|**Estudo**<br>**(Autor/Ano)**|**Participantes**<br>**(n)**|**Idade**<br>**média**<br>**(DP) anos**|**Sexo**<br>**M (%)**|**Comorbidades**<br>**média (DP)**|**Tratamento**<br>**prévio**|**Subtipo TDAH**|**Grau TDAH**|**Sintomatologia média (DP)**|**Qualida**<br>**de de**<br>**Vida**<br>**média**<br>**(DP)**|
|---|---|---|---|---|---|---|---|---|---|
||||||||MPH: 5,9%<br>PLA: 5,5%|||  
**Tabela C -** Desfechos de eficácia dos estudos incluídos  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**MPH vs. PLA**|||||
||**CADS-T [média (DP)]**<br>MPH: 16,3 (12,12)<br>PLA: 31,3 (15,37)<br>Mudança na linha de base:|NR|NR|NR|
|**Biederman et**<br>**al., 2003**<sup>8</sup>|MPH: -10,7 (15,86)<br>PLA: 2,8 (10,59)<br>MPH vs. PLA: <0,0001<br>Tamanho do efeito:<br>MPH: 0,90<br>**CADS-P**||||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||Mudança média na linha de base:<br>MPH: -6,3<br>PLA: 0,5<br>MPH vs. PLA: p<0,0043<br>**CGI-I (pacientes que apresentaram melhora):**<br>MPH (n=63): 69,8%<br>PLA (n=71): 40%<br>MPH vs. PLA: p=0,0009||||
||**Iowa Conners’ – desatenção:**<br>Professores: Grupo placebo apresentou aumento nos escores da escala,<br>enquanto grupo MPH apresentou reduções (p≤0,05).<br>Pais: Grupo placebo apresentou escores estáveis, enquanto grupo MPH<br>apresentou reduções (p≤0,05).<br>**Iowa Conners’ – hiperatividade:**<br>Professores: Grupo placebo apresentou aumento nos escores da escala,|NR|NR|NR|
|**Findling et al.,**<br>**2006**<sup>9</sup>|enquanto grupo MPH apresentou reduções (p≤0,05).<br>Pais: Grupo placebo apresentou aumento discreto nos escores, enquanto<br>grupo MPH apresentou reduções (p≤0,05).<br>**CGI (bastante melhor ou muito melhor):**<br>MPH (n=120): 31,7%; PLA (n=39): 13,2%, p<0,001<br>**CGI (melhoria)**<br>MPH (n=120): 58,4%; PLA (n=39):18,5%, p<0,001<br>**PGA (moderadamente melhor ou muito melhor):**<br>MPH: 40,3%; PLA: 10,3%||||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**Findling et al.,**<br>**2008**<sup>10</sup>|**ADHD-RS-IV [MMQ (IC 95%)]:**<br>MPH: -21,6<br>PLA: -10,3<br>MPH vs. PLA: -13,3 (-15,6 a -7,1), p<0,0001<br>**CTRS-R**<br>Endpoint [média (DP)]:<br>MPH: 13,8 (14,4)<br>PLA: 31,6 (20,1)<br>Diferença [MMQ (EP)]:<br>MPH: -17,5 (1,75)<br>PLA: -5,1 (1,78)<br>MPH vs. PLA [Diferença (IC 95%)]: -12,4 (17,3 a -8,5), p<0,0001<br>**CPRS-R**<br>Endpoint manhã [média (DP)]:<br>MPH: 28,4 (21,1)<br>PLA: 37,0 (24,4)<br>Diferença manhã [MMQ (EP)]:<br>MPH: -23,5 (2,1)<br>PLA: -14,2 (2,3)<br>MPH vs. PLA manhã [Diferença (IC 95%)]: -9,2 (-15,4 a -3,1), p<0,0032<br>Endpoint tarde [média (DP)]:<br>MPH: 29,1 (20,8)<br>PLA: 37,7 (23,5)<br>Diferença tarde [MMQ (EP)]:<br>MPH: -22,0 (2,3)|NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||PLA: -15,0 (2,3)<br>MPH vs. PLA [Diferença (IC 95%)]: -7,0 (-13,3 a -0,3), p<0,0288<br>**CGI-I (melhoria)**<br>MPH (n=89): 66,3%<br>PLA (n=85): 23,5%<br>MPH vs. PLA: p<0,0001<br>**PGA (melhoria)**<br>MPH: 60,7%<br>PLA: 24,7%||||
||MPH vs. PLA: p<0,0001||||
||**1 Taxas de normalização**<br>Atenção|NR|**1. Taxa de normalização**<br>_Eficiência acadêmica_|<br>NR|
||PLA= 10%||_PLA: 0%_||
||5mg= 25%||_5mg=  15%_||
||10mg= 35%||_10mg= 30%_||
||15mg= 45%||_15mg= 32%_||
|**Rt t l**|20mg= 50%||_20mg= 30%_||
|**appor e a.,**<br>**1994**<sup>11</sup>|**2. Taxas de melhora**<br>Atenção||_Escala de classificação de_<br>_professores_||
||PLA= 3%||_PLA=12%_||
||5mg= 0%||_5mg=  30%_||
||10mg= 5%||_10mg= 50%_||
||15mg= 2%||_15mg= 55%_||
||20mg= 7%||_20mg= 60%_||
||**3.Taxa de deterioração**||**2. Taxas de melhoria**||  
|**Estudo**<br>**(autor-ano)**||**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|---|
||Atenção<br>PLA: 25%<br>5mg= 5%<br>10mg=0%<br>15mg= 1%<br>20mg=0%|<br> <br> <br>|<br> <br> <br>|_Eficiência acadêmica_<br>PLA: 1%<br>5mg=  0%<br>10mg= 2%<br>15mg= 0%<br>20mg= 5%<br>_Escala de classificação de_<br>_professores_<br>PLA=19%||
|||||5mg=  32%<br>10mg= 25%<br>15mg= 25%<br>20mg= 20%<br>**3. Taxas de deterioração**<br>_Eficiência acadêmica_<br>PLA= 32%<br>5mg= 10%<br>10mg=0%<br>15mg= 1%<br>20mg=0%<br>_Escala de classificação de_<br>_professores_<br>PLA= 32%<br>5mg= 12%||
|||||10mg= 10%||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||||15mg= 5%<br>20mg= 10~~%~~||
|**Rapport et al.,**<br>**2008**<sup>12</sup>|Queixas físicas e comportamentais reportadas pelos pacientes<br>Dificuldade para ficar parado: PLA: 6,6%; 5mg: 8,2%; 10mg: 9,5%; 15mg:<br>7,8%; 20 mg: 3,2%<br>Dificuldade para dormir: PLA: 12,9%; 5mg: 14,1%; 10mg: 14,1%; 15mg:<br>14,1%; 20 mg: 9,7%<br>Sono reduzido: PLA: 9,7%; 5mg: 12,5%; 10mg: 10,9%; 15mg: 4,7%; 20 mg:<br>6,7%<br>Choro: PLA: 6,5%; 5mg: 1,5%; 10mg: 3,2%; 15mg: 3,1%; 20 mg: 0%<br>Dificuldade de atenção: PLA: 11,5%; 5mg: 4,8%; 10mg: 6,3%; 15mg: 6,3%;<br>20 mg: 1,7%<br>Mais falante: PLA: 15%; 5mg: 18%; 10mg: 17,5%; 15mg: 12,7%; 20 mg:<br>13,1%<br>Dificuldade em esportes: PLA: 3,3%; 5mg: 1,6%; 10mg: 1,6%; 15mg: 1,6%;<br>20 mg: 1,6%<br>Dificuldade na relação com os pais: PLA: 11,1%; 5mg: 6,2%; 10mg: 6,3%;<br>15mg: 3,1%; 20 mg: 3,3%<br>Dificuldade no relacionamento com pares: PLA: 12,7%; 5mg: 8,1%; 10mg:<br>6,3%; 15mg: 8,2%; 20 mg: 6,5%<br>Raiva: PLA: 6,5%; 5mg: 3,1%; 10mg: 6,3%; 15mg: 11,1%; 20 mg: 4,8%|NR|NR|NR|
|**Schulz et al.,**|SKAMP<br>1,5 h MPH= 0,90 Placebo=1,33   p <0.0001|<br>**NCBRF-TIQ:**<br>**Subescala social**|**Testes de matemática**<br>**(tentativas)**|NR|
|**2010**<sup>23</sup>|3,0 h MPH = 0,76 Placebo= 1,45  p <0.0001|<br>**positiva Rastreio**|1,5h Placebo= 110,1 MPH=||
||4,5h MPH= 0,95  Placebo= 1,62 p <0.0001|<br>**[média (DP)]**|134,0 p<0,0001||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||6,0h  MPH= 1,05 Placebo=1,50  p <0,0001<br>7,5h MPH=1,11 Placebo= 1,56 p <0,0001<br>Média 1,5 a 4,5h MPH= 0,86 Placebo=1,49 p<0,0001|<br> <br>MPH= 18,2 ( 4,9)<br>PLA= 18,2 (4,9)<br>**NCBRF-TIQ:**<br>**composto total**<br>**(população ITT)**<br>MPH= 44.5<br>(23.1)PLA= 44.5 (23.1)|<br>3,0h Placebo= 106,2 MPH=<br>140,7  p<0,0001<br>4,5h Placebo=99,1<br>MPH=127,3  p<0,0001<br>**Testes de matemática**<br>**resolvido**<br>1.5h MPH= 128,7 Placebo=<br>104,9 p<0,0001<br>3.0h MPH= 135.7 Placebo=<br>101.6 p<.0001<br>4.5h MPH=122.2 Placebo=<br>91.7 p<.0001|<br> <br> <br>|
|**Simonoff et al.,**<br>**2013**<sup>14</sup>|**Índice Conners de TDAH para pais (M, DP)**<br>PLA: 22.4 (1.1) MPH: 19.1 (1.4)  *-3.8 (-6.7, -0.9)<br>**Índice Conners de TDAH para professores (M, DP)**<br>PLA: 18.6 (1.3) MPH: 14.5 (1.2)  *-5.1 (-7.9,-2.2)<br>**Escala Conners de hiperatividade dos pais  (M, SD)**<br>PLA: 12,1 (3,7) MPH: 12,0 (4,0)  *-1.8 (-3.4, -0.2)<br>**Escala Conners de hiperatividade de professor (M, DP)**<br>PLA: 9,6 (5,8) MPH: 10,1 (6,0)   * -3.2 (-4.9, -1.5)<br>**Subescala pai de hiperatividade ABC (M, DP)**<br>PLA: 32,6 (9,7) MPH: 30,8 (8,7) *-6.8 (-10.2, -3.5)<br>**Subescala de hiperatividade do professor ABC (M, DP)**<br>PLA: 20,5 (13,7) MPH: 21,9 (13,0) *-6.7 (10.0, 3.3)|<br> <br> <br> <br> <br>NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**Tucha et al.,**<br>**2006**<sup>15</sup>|**Prontidão tônica – tamanho do efeito para diferenças entre grupos**<br>Tempo de reação: 0.14<br>Variabilidade do tempo de reação; 0.05<br>Número de erros de omissão-  0.01<br>**Atenção fásica -  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação- 0.03<br>Variabilidade do tempo de reação- 0.09<br>Número de erros de omissão- 0.17<br>**Vigilância-  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação – 0.01<br>Variabilidade do tempo de reação- 0.08<br>Número de erros de omissão- 0.25<br>**Atenção dividida  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação- 0.16<br>Variabilidade do tempo de reação- 0.10<br>Número de erros de omissão- 0.18<br>**Inibição-  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação- 0.02<br>Variabilidade do tempo de reação- 0.03<br>Número de erros de omissão- 0.15<br>**Atenção focalizada-  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação- 0.05<br>Variabilidade do tempo de reação- 0.03<br>**Integração de informações sensoriais-  tamanho do efeito para diferenças**<br>**entre grupos**|<br> <br> <br> <br> <br> <br>NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||Tempo de reação- 0.07<br>Variabilidade do tempo de reação- 0.14<br>Número de erros de omissão- 0.21<br>**Flexibilidade-  tamanho do efeito para diferenças entre grupos**<br>Tempo de reação- 0.00<br>Variabilidade do tempo de reação – 0.12|<br> <br>|||
|**Wilens et al.,**<br>**2006**<sup>16</sup>|**ADHD RS score**média (DP)<br>**_Investigador_**<br>MPH=  16.62 ± 11.03<br>PLA= 21.40 ± 13.44<br>**_Pais_**<br>MPH=  16.65 ± 11.07<br>PLA= 20.84 ± 13.58<br>**Índice de conflitos entre pais e filhos**<br>MPH= 0.188 ± 0.145<br>PLA= 0.247 ± 0.206<br>**Escala  de auto relato de sintomas para adolescentes  Conners-Wells**<br>**Índice de conflito infantil**<br>MPH=  57.57 ± 41.07<br>PLA= 75.32 ± 52.20<br>**_Investigador_**<br>**ADHD RS  (%)**<br>MPH=73.3<br>PLA=  56.2|<br> <br> <br> <br> <br> <br> <br> <br> <br>NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||**Avaliação global de efetividade**<br>MPH=  51.2<br>PLA =   32.6<br>**Subescala de impressão da melhoria clínica global**<br>MPH= 51.8<br>PLA =  31.0<br>**Escala  de auto relato de sintomas para adolescentes  Conners-Wells**<br>**Índice de conflito infantil**<br>MPH=  62.8<br>PLA =  41.6|<br> <br> <br> <br>|||
|**Wolraich et al.,**<br>**2001**<sup>17</sup>|**Escala IOWA média (DP)-  Professores**<br>**Desatenção / Hiperatividade**<br>MPH ER OROS: 5.98 (3.91); MPH IR: 6.35 (2.81); Placebo: 9.77 (4.02)<br>**Oposição / Desafio (SD)**<br>MPH ER OROS: 2.74 (3.73); MPH IR: 2.50 (3.70); Placebo: 5.38 (5.13)<br>**Escala IOWA média (DP)-  Pais** <br>**Desatenção / Hiperatividade**<br>MPH ER OROS:6.29 (3.54); MPH IR: 6.17 (3.19); Placebo: 10.11 (3.92)<br>**Oposição / Desafio (SD)**<br>MPH ER OROS: 4.91 (3.93) ; MPH IR: 4.98 (3.81); Placebo: 8.60 (4.82)<br>**AVALIAÇÃO DOS PROFESSORES** <br>**Interação entre pares  (SD)**<br>MPH ER OROS: 0.55 (0.59); MPH IR: 0.48 (0.61); Placebo: 0.96 (0.78)<br>**Desatenção SNAP-IV (SD**<br>MPH ER OROS: 1.34 (0.84); IR MPH: 1.26 (0.79); Placebo 1.97 (0.79)|<br> <br> <br>NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**MPH IR vs. MP**|**Hiperatividade / Impulsividade- SNAP-IV  (SD)**<br>MPH ER OROS: 0.96 (0.79); MPH IR: 0.93 (0.79); Placebo  1.57 (0.89)<br>**Transtorno Opositor-desafiador-** **SNAP-IV**<br>MPH ER OROS:  0.53 (0.69); MPH IR:  0.44  (0.61); Placebo 0.95 (0.87)<br>**Eficácia Global**<br>MPH ER OROS:  1.42 (0.97); IR MPH:  1.43 (1.0); Placebo: 0.62 (0.81)<br>**AVALIAÇÃO DOS PAIS**<br>**Desatenção SNAP-IV (SD)**<br>MPH ER OROS: 1.38 (0.68); MPH IR: 1.39 (0.73); Placebo: 2.00 (0.78)<br>**Hiperatividade / Impulsividade- SNAP-IV  (SD)**<br>MPH ER OROS: 1.11 (0.65); MPH IR: 1.10 (0.69); Placebo 1.83 (0.89)<br>**Transtorno Opositivo-desafiador- SNAP-IV**<br>MPH ER OROS:  0.91(0.66); IR MPH: 0.95 (0.67); Placebo  1.54 (0.94)<br>**Eficácia Global**<br>MPH ER OROS:  1.47 (1.07); MPH IR: 1.28 (0.93); Placebo: 0.61 (0.93)<br>**INVESTIGADORES**<br>**_Impressão clínica global_**<br>MPH ER OROS: 4,24 (1,34); MPH IR: 4,19 (1,45); Placebo: 2.48 (1,67)<br>**Efeito geral do tratamento**<br>**_Impressão clínica global_**<br>**_(% de pacientes melhor / muito melhorados)_**<br>MPH ER OROS (n=94): 46,7%; MPH IR (n=84): 47,2%; Placebo (n=89):<br>16,7%<br>**H ER**|<br> <br> <br> <br>|||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**Pelham et al.,**<br>**2001**<sup>24</sup>|IOWA Conners’ Rating – Professores:<br>D/H:<br>MPH IR: 5,0 (3,69); MPR ER: 4,69 (3,31); PLA: 10,34 (4,21)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>O/D:<br>MPH IR: 1,99 (3,03); MPR ER: 1,81 (2,98); PLA: 5,09 (4,85)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Conners Breve:<br>MPH IR: 7,94 (5,83); MPR ER: 7,82 (5,92); PLA: 16,40 (7,74)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Interação entre os pares:<br>MPH IR: 4,03 (4,74); MPR ER: 3,41 (4,67); PLA: 4,29 (4,63)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>IOWA Conners’ Rating  - Pais<br>D/H:<br>MPH IR: 5,93 (3,09); MPR ER: 4,78 (2,86); PLA: 10,59 (3,28)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05; MPH IR vs. MPH ER:<br>p<0,005<br>O/D:<br>MPH IR: 5,26 (3,85); MPR ER: 4,82 (4,00); PLA: 8,85 (4,04)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Conners Breve:<br>MPH IR: 11,41 (6,23); MPR ER: 9,49 (6,50); PLA: 19,91 (6,02)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05; MPH IR vs. MPH ER:<br>p<0,05|NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||Frequências de comportamento – medidas diárias<br>Seguir regras<br>MPH IR: 60,2% (22,3); MPR ER: 61,3% (23,2); PLA: 47,5% (25,8)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Ausência de conformidade<br>MPH IR: 2,73 (9,16); MPR ER: 2,14 (5,45); PLA: 5,76 (16,53)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Interrupção<br>MPH IR: 10,5 (17,04); MPR ER: 17,71 (10,58); PLA: 21,60 (39,07)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Reclamação<br>MPH IR: 6,95 (13,37); MPR ER: 6,67 (17,04); PLA: 15,45 (28,29)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Comportamento positivo entre os pares<br>MPH IR: 9,86 (5,43); MPR ER: 9,20 (6,24); PLA: 10,52 (7,99)<br>Problemas de Conduta<br>MPH IR: 1,53 (6,53); MPR ER: 0,60 (2,02); PLA: 3,81 (13,52)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05<br>Verbalizações negativas<br>MPH IR: 9,29 (31,68); MPR ER: 7,14 (26,03); PLA: 18,27(37,26)<br>MPH IR vs. PLA: p<0,05; MPH ER vs. PLA: p<0,05||||
|**Steele et al.,**<br>**2007**<sup>13</sup>|**_Escala SNAP-IV item 26 (itens ADHD + ODD):_**<br>**Semana 4**MPH ER OROS**=**-24.1 ± 16.8 MPH IR = -18.1 ± 16.5<br>**Semana 8**MPH ER OROS =-26.4± 18.3  MPH IR = -17.9 ± 15.3<br>**Final do estudo**MPH ER OROS =-25.5 ± 18.7  MPH IR = -17.5 ± 15.2|<br> <br> <br>**Escala Visual (mm):**<br>**social play**<br>**Semana 4**|<br>**Escala visual analógica**<br>**(mm): lição de casa**<br>**Semana 4**|<br>**NR**|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||**_Escala SNAP-IV  item 18 (ADHD items)_  **<br>**Semana 4**MPH ER OROS =-18.4 ± 13.1   MPH IR = -14.8 ± 12.3<br>**Semana 8**MPH ER OROS =-20.2 ±13.7  MPH IR = -14.5 ± 11.4<br>**Final do estudo**MPH ER OROS =-19.6 ± 13.9  MPH IR = -14.3 ±11.6<br>**_Escala de Classificação dos Pais da IOWA:_**<br>**Semana 4**MPH ER OROS =-8.6 ± 7.4  MPH IR = -6.3 ± 6.2<br>**Semana 8**MPH ER OROS =-10.3 ± 8.1  MPH IR = -6.1 ± 5.8<br>**Final do estudo**MPH ER OROS =-9.4 ± 8.5  MPH IR = -6.0 ± 5.9<br>**_Escala de classificação dos pais da IOWA, Subescala de desatenção /_**<br>**_superatividade_**<br>**Semana 4**MPH ER OROS =-4.8 ± 4.0 MPH IR = -4.2 ± 3.5<br>**Semana 8 O**ROS-MPH=-5.9 ± 4.4  MPH IR = -4.0 ± 3.1<br>**Final do estud**o  MPH ER OROS =-5.4 ± 4.5  MPH IR = -3.9  ± 3.2<br>**_Escala de classificação dos pais- Conners_**<br>**Semana 4**MPH ER OROS =-25.7 ± 19.2  MPH IR = -18.8 ± 15.6<br>**Semana 8**MPH ER OROS =-30.0 ± 20.5  MPH IR = -19.2 ± 15.7<br>**Final do estudo**MPH ER OROS =-27.5 ± 21.9  MPH IR =-19.2 ± 15.6<br>**_Índice de Estresse dos Pais, Formato Curto:_**<br>**Final do estudo**MPH ER OROS =+14.0 ± 19.2 MPH IR = +6.1 ± 14.8<br>**_CGI-I:_** <br>**Semana 4**MPH ER OROS =2.4 (± 1.3 ) MPH IR**= 2.7**(± 1.4)<br>**Semana 8**MPH ER OROS =1.8 (± 1.1 )  MPH IR = 2.5 (± 1.3)<br>**Final do estudo**MPH ER OROS =2.0 (± 1.2 )  MPH IR = 2.6 (± 1.4)<br>CGI (melhorado ou muito melhorado)<br>MPH ER OROS: 57/70; IR-MPH: 45/73|<br> <br> <br>MPH ER OROS =-<br>33.1 ± 28.<br>MPH IR = -19.7 ± 33.5<br>**Semana 8**<br>MPH ER OROS =-36.2<br>± 31.1<br>MPH IR = -26.5 ±<br>27.9<br>**Final do estudo**<br>MPH ER OROS =-31.8<br>± 29.6<br>MPH IR = -23.0 ± 33.8|<br>MPH ER OROS =51.5 (±<br>13.1)<br>MPH IR = 51.5 (± 12.4)<br>**Semana 8**<br>MPH ER OROS =51.5 (±<br>13.1)<br>MPH IR = 51.5 (± 12.4)<br>**Final do estudo**<br>MPH ER OROS =51.5 (±<br>13.1)<br>MPH IR = 51.5 (± 12.4**)**||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
|**Wolraich et al.,**<br>**2001**<sup>17</sup>|**Escala IOWA média (DP)-  Professores**<br>**Desatenção / Hiperatividade**<br>MPH ER OROS: 5.98 (3.91); MPH IR: 6.35 (2.81); Placebo: 9.77 (4.02)<br>**Oposição / Desafio (SD)**<br>MPH ER OROS: 2.74 (3.73); MPH IR: 2.50 (3.70); Placebo: 5.38 (5.13)<br>**Escala IOWA média (DP)-  Pais** <br>**Desatenção / Hiperatividade**<br>MPH ER OROS:6.29 (3.54); MPH IR: 6.17 (3.19); Placebo: 10.11 (3.92)<br>**Oposição / Desafio (SD)**<br>MPH ER OROS: 4.91 (3.93) ; MPH IR: 4.98 (3.81); Placebo: 8.60 (4.82)<br>**AVALIAÇÃO DOS PROFESSORES** <br>**Interação entre pares  (SD)**<br>MPH ER OROS: 0.55 (0.59); MPH IR: 0.48 (0.61); Placebo: 0.96 (0.78)<br>**Desatenção SNAP-IV (SD**<br>MPH ER OROS: 1.34 (0.84); MPH IR: 1.26 (0.79); Placebo 1.97 (0.79)<br>**Hiperatividade / Impulsividade- SNAP-IV  (SD)**<br>MPH ER OROS: 0.96 (0.79); MPH IR: 0.93 (0.79); Placebo  1.57 (0.89)<br>**Transtorno Opositor-desafiador-** **SNAP-IV**<br>MPH ER OROS:  0.53 (0.69); MPH IR:  0.44  (0.61); Placebo 0.95 (0.87)<br>**Eficácia Global**<br>MPH ER OROS:  1.42 (0.97); MPH IR:  1.43 (1.0); Placebo: 0.62 (0.81)<br>**AVALIAÇÃO DOS PAIS**<br>**Desatenção SNAP-IV (SD)**<br>MPH ER OROS: 1.38 (0.68); MPH IR: 1.39 (0.73); Placebo: 2.00 (0.78)<br>**Hiperatividade / Impulsividade- SNAP-IV  (SD)**|<br> <br> <br> <br> <br>NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||MPH ER OROS: 1.11 (0.65); MPH IR: 1.10 (0.69); Placebo 1.83 (0.89)<br>**Transtorno Opositivo-desafiador- SNAP-IV**<br>MPH ER OROS:  0.91(0.66); MPH IR: 0.95 (0.67); Placebo  1.54 (0.94)<br>**Eficácia Global**<br>MPH ER OROS:  1.47 (1.07); MPH IR: 1.28 (0.93); Placebo: 0.61 (0.93)<br>**INVESTIGADORES**<br>**_Impressão clínica global_**<br>MPH ER OROS: 4,24 (1,34); MPH IR: 4,19 (1,45); Placebo: 2.48 (1,67)<br>**Efeito geral do tratamento**<br>**_Impressão clínica global_**<br>**_(% de pacientes muito / muito melhorados)_**<br>MPH ER OROS (n=94): 46,7%; MPH IR(n=94): 47,2%; Placebo (n=89):<br>16,7%<br>Tratamento ativo vs. placebo: p<0,001|<br> <br>|||
|**LDX vs. PLA**|||||
|**Biederman et**<br>**al., 2007**<sup>18</sup>|**ADHD – RS – IV global [média (EP)]**<br>Melhorias para todas as doses de LDX comparada ao placebo<br>LDX 30 mg: ~22,0 (EP – NA)<br>LDX 50mg: ~24,0 (EP – NA)<br>LDX 70 mg: -26,7 (1,54)<br>PLA: -6,2 [1,56]<br>Tamanho do efeito:<br>LDX 30 mg: 1,21<br>LDX 50 mg: 1,34<br>LDX 70 mg: 1,60|NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||**CPRS-R**<br>Para os três horários de avaliação, pacientes que receberam MPH tiveram<br>melhora estatisticamente significativa (p<0,01) em relação ao placebo<br>**CGI (melhorado ou muito melhorado)**<br>LDX (n=213): ≥ 70%<br>PLA (n=72): 18%||||
|**Findling et al.,**<br>**2011**<sup>19</sup>|**ADHD-RS-IV global [MMQ(SE)]**<br>Diferença final – baseline:<br>LDX 30 mg: -18,3 (1,25)<br>LDX 50 mg: -21,1 (1,28)<br>LDX 70 mg: -20,7 (1,25)<br>PLA: -12,8 (1,25)<br>**CGI-I**<br>LDX (n=232) vs. PLA: (n=77) 69,1% vs. 39,5%, respectivamente (p<0,0001)<br>LDX 30 mg: 57,9%<br>LDX 50 mg: 73,6%; LDX 70 mg: 76,0%|NR|BR|LDX: 81,2 (12,53)<br>LDX 30mg: 81,1 (11,09)<br>LDX 50 mg: 81,3 (11,86)<br>LDX 70 mg: 81,3 (14,66)<br>PLA: 81,3 (12,16)<br>p≤0,0056|
|**Coghill et al.,**<br>**2013**<sup>20</sup>|**ADHD-RS-IV global [MMQ(SE)]**<br>Diferença final – baseline:<br>LDX: -24,3 (1,2)<br>PLA: -5,7 (1,1)<br>MPH: -18,7 (1,1)<br>LDX vs. PLA: -18,6; IC95%: [-21,5 a -15,7], p<0,001)<br>MPH vs. PLA: -13,0; IC95%: [-15,9 a -10,2]; p<0,001)<br>**Tamanho do efeito (medicamento ativo vs. Placebo) pelo ADHD-RS-IV:**|NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||LDX:1,80<br>MPH: 1,26<br>CGI [% (IC95%)]<br>LDX: 78% (70-86)<br>PLA: 14% (8-21)<br>MPH: 61% (51-70)<br>LDX vs. PLA: p<0,001<br>MPH vs. PLA: p<0,001<br>**Proporção de pacientes que apresntaram melhora ou muita melhora no**<br>**CGI (IC 95%):**<br>LDX (n=104): 78% (70 a 86)<br>PLA (n=106): 14% (8-21)<br>MPH (n=107): 61% (51-70)<br>LDX vs. PLA: p<0,001<br>MPH vs. PLA: p<0,001||||
|**Wigal et al.,**<br>**2009**<sup>21</sup>|**Atenção e comportamento- SKAMP-Total score  [média (SE)]**<br>Predose<br>LDX: 1.68 (0.07)<br>PLA: 1.22 (0.07)<br>1.5 h<br>LDX: 1.15 (0.08)<br>PLA:1.62 (0.08)<br>13 horas<br>LDX: 1.43 (0.08)|<br> <br> <br>NR|**Produtividade acadêmica-**<br>**PERMP**<br>**PERMP- A [média (SE)]**<br>Predose<br>LDX= 85.54 (4.88)<br>1.5 h  LDX vs placebo=<br>16,97 (9,39 a 24,56)|<br>NR|
||PLA:1.85 (0.08)||13 horas  LDX vs placebo=||  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||**SKAMP-Qualidade do trabalho  [média (SE)]**<br>Predose<br>LDX: 2.90 (0.08)<br>PLA: 1.72 (0.08)<br>1.5 h<br>LDX:  1.75 (0.09)<br>PLA: 1.95 (0.09)<br>13 horas<br>LDX: 2.13 (0.10)†<br>PLA:2.46 (0.10)<br>LDX versus placebo=  -0,74 (-0,85, -0,63; P <0,0001)|<br> <br> <br>|28,28 (21,51 a 35,04)<br>**PERMP- C  [média (SE)]**<br>Predose<br>LDX: 81.6 (4.84)<br>PLA:99.17 (4.84)<br>1.5 h  LDX vs placebo 19,10<br>(12,25 a 25,94)<br>13 horas  LDX vs placebo<br>28,14 (21,46 a 34,83)||
|**MPH vs. LDX**|||||
|**Newcorn et al.,**<br>**2017**<sup>**22**</sup><br>**(dose flexível)**|**ADHD-RS-IV [Alteração MMQ (SE)]**<br>LDX (n=139):  -25,6 (0,82)<br>MPH (n=152): -23,5 (0,80)<br>PLA (n=67): -13,4 (1,19)<br>Comparações [MMQ (IC 95%)]:<br>LDX vs. MPH: -2,1 (-4,3 a 0,2); DF = 414, estatística t= 1,81; p=0,717;<br>Tamanho do efeito = -0,20<br>LDX vs. PLA: -12,2 (-15,1 a -9,4); DF = 428; estatística t = 8,44, p<0,0001;<br>Tamanho do efeito: = -1,16<br>MPH vs. PLA: -10,1 (-13,0 a 7,3); DF = 427; estatística t = -7,07; p<0,0001,<br>tamanho do efeito = -0,97<br>**CGI -I (melhora):**<br>LDX (n=178): 83,1%|NR|NR|NR|  
|**Estudo**<br>**(autor-ano)**|**Controle de Sintomas**|**Interação social**|**Performance acadêmica**|**Qualidade de Vida**|
|---|---|---|---|---|
||MPH (n=184): 81%<br>PLA (n=89): 34,8%<br>LDX vs. MPH: DF = 1; estatística CMH = 0,2508; p=0,6165<br>LDX vs. PLA: DF = 1, estatística CMH = 60,0783; p<0,0001<br>MPH vs. PLA: DF = 1; estatística CHM = 56,6112; p<0,0001||||
|**Newcorn et al.,**<br>**2017**<sup>**22**</sup><br>**(dose forçada)**|**ADHD-RS-IV [Alteração MMQ (SE)]**<br>LDX (n=175):  -25,4 (0,74)<br>MPH (n=181): -22,1 (0,73)<br>PLA (n=93): -17,0 (1,03)<br>Comparações [MMQ (IC 95%)]:<br>LDX vs. MPH: -3,4 (-5,4 a -1,3); DF = 499, estatística t= 3,23; p=0,0013;<br>Tamanho do efeito = -0,33<br>LDX vs. PLA: -8,5 (-11,0 a -6,0); DF = 491; estatística t = 6,67, p<0,0001;<br>Tamanho do efeito: = -0,82<br>MPH vs. PLA: -5,1 (-7,6 a -2,6); DF = 492; estatística t = -4,04; p<0,0001,<br>tamanho do efeito = -0,50<br>**CGI -I (melhora):**<br>LDX (n=171): 81,4%<br>MPH (n=216): 71,3%<br>PLA (n=106): 50%<br>LDX vs. MPH: DF = 1; estatística CMH = 5,5157; p=0,0188<br>LDX vs. PLA: DF = 1, estatística CMH = 32,6389; p<0,0001<br>MPH vs. PLA: DF = 1; estatística CHM = 13,8434; p=0,0002||||  
**Tabela D -** Desfechos de segurança dos estudos incluídos  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|**MPH vs. PLA**|||||
|**Biederman et al., 2003**<sup>8</sup>|MPH (n=65): 24,6%|Anorexia|NR|Pré randomização (27/161):|
||PLA (n=71): 23,9%|MPH: 3,1%<br>PLA: 0||Efeitos terapêuticos insatisfatórios (7/27);<br>Retirada de consentimento (7/27);|
||Eventos adversos|Insônia||Eventos adversos (4/27);|
||relacionados ao|MPH: 3,1%||Problemas administrativos (4/27);|
||medicamento:|PLA:0||Perda de seguimento (3/37);|
||MPH: 9,2%|Dor de garganta:||Violação de protocolo (2/27)|
||PLA: 4,2%|MPH: 0<br>PLA: 4,2%|||
|||Cefaleia:||Pós randomização (7/137):|
|||MPH: 1,5%||Eventos adversos (3/7);|
|||PLA: 2,8%||Efeitos terapêuticos insatisfatórios (2/7);|
|||Vômitos:||Retirada de consentimento (1/7);|
|||MPH: 0<br>PLA: 2,8%||Problemas administrativos (1/7)|
|**Findling et al., 2006**<sup>9</sup>|MPH (n=133): 53,4%|Cefaleia:|NR|Exacerbação da doença:|
||PLA (n=46): 82,6%|MPH: 13,5%; PLA: 4,3% (p=0,059)||MPH: 9,5%; PLA: 33%|
|||Anorexia:||Eventos adversos|
||Relacionados ao MPH:|MPH: 3,0%; PLA: 0 (p=0,131)||MPH: 9,5%; PLA: 33%|
||35,3%|Dor em andar superior de abdome:||Não adesão ao protocolo|
|||MPH: 6,8%; PLA: 6,5% (p=0,951)||MPH: 5%|
|||TDAH:||Retirada de consentimento pelo participante/|
|||MPH: 4,5%; PLA: 34,8% (p<0,001)||guardião legal|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Nasofaringite:<br>MPH: 1,5%; PLA: 6,5% (p=0,098)<br>Insônia:<br>MPH: 3,8%; PLA: 0 (p=0,497)<br>Dor abdominal não especificada:<br>MPH: 4,5%; PLA: 0 (p=0,416)<br>Redução de apetite não especificada:<br>MPH: 2,3%; PLA: 0 (p=0,564)<br>Faringite:<br>MPH: 3,0%; PLA: 0 (p=0,784)<br>Comportamento anormal:<br>MPH: 2,3%; PLA:4,3% (p=0,730)<br>Febre:<br>MPH: 0,8%; PLA: 6,5% (p=0,077)<br>Infrecção de VAS não especificada:<br>MPH: 4,5%; PLA: 2,2% (p=0,562)<br>Vômitos não especificados:<br>MPH: 3,0%; PLA: 4,3% (p=0,657)<br>Irritabilidade:<br>MPH: 3,8%; PLA: 2,2% (p=0,499)<br>Tosse<br>MPH: 3,0%; PLA: 4,3% (p=0,323)<br>Aumento de apetite, rash e infecções virais não<br>especificadas e tics:||MPH: 11,9%; PLA: 16,7%<br>Decisão médica<br>MPH: 2,4%; PLA: 11,9%<br>Perda de seguimento<br>MPH: 2,4%|
|||MPH: 0; PLA: 4,3% (p=0,021)|||  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|**Findling et al., 2008**<sup>10</sup>|MPH (n=91): 69,2%|99% leves a moderados|NR|MPH: 27,5%|
||PLA (n=85): 57,6%|Redução de Apetite<br>MPH: 18,7%; PLA: 4,7%||PLA: 62,3%|
|||Insônia||Eventos adversos:|
|||MPH: 7,7%; PLA: 4,7%||MPH: 2,2%; PLA: 1,2%|
|||Náusea:||Violação de protocolo:|
|||MPH: 7,7%; PAL: 2,4%||MPH: 1,1%; PLA: 3, %|
|||Vômitos:||Retirada de consentimento:|
|||MPH: 9,8; PLA: 4,7%||MPH:4,4%; PLA: 5,9%|
|||Perda de peso:<br>MPH: 7,7; PLA: 0||Perda de seguimento: MPH: 0; PLA: 2,3%<br>Continuidade a longo prazo: 18,9%; PLA: 36,5%|
|||Tique:||Decisão do patrocinador:|
|||MPH: 1,1; PLA: 0||MPH: 1,1%; PLA: 0|
|||Labilidade afetiva:||Outros:|
|||MPH: 3,3; PLA: 0<br>Congestão nasal:||MPH:0; PLA: 12,9%|
|||3,3%; PLA: 1,2%|||
|||Anorexia: 3,3%; PLA: 1,2%<br>Nasofaringite:|||
|||MPH: 4,4%; PLA: 2,4%|||
|**Rapport et al., 1994**<sup>11</sup>|NR|NR|NR|NR|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|**Rapport et al., 2008**<sup>12</sup>|NR|Comer menos<br>Placebo 0.20 (10%) 5mg 0.11 (4,8%)10mg 0.30<br>(10,9%) 15mg 0.16 (6,3%) 20mg 0.14 (7,9%)<br>Beber mais<br>Placebo  0.32 (11,7%) 5mg 0.21 (9,7%) 10mg 0.27<br>(9,4%) 15mg 0.32 (12,7%) 20mg 0.26 (11,3%)<br>Boca seca<br>Placebo 0.37 (14,5%) 5mg 0.31 (13,8%) 10mg 0.20<br>(10,9%) 15mg 0.27 (14,1%) 20 mg 0.21 (11,5%)<br>Mais movimentos intestinais<br>Placebo 0.12 (6,7%) 5mg 0.11 (4,7%) 10mg 0.17<br>(6,3%) 15mg 0.05 (1,6%) 20mg 0.03 (3,3%)<br>Menos movimentos intestinais<br>Placebo 0.31 (13,1%) 5mg 0.20 (7,8%) 10mg 0.17<br>(7,9%) 15mg 0.19 (7,8%) 20mg 0.12 (5,0%)<br>Movimentos intestinais mais difíceis<br>Placebo 0.11 (4,8%) 5mg 0.11 (4,8%) 10mg 0.05<br>(1,6%) 15mg 0.00 (0,0%) 20mg 0.02 (1,7%)<br>Movimentos intestinais mais suaves<br>Placebo 0.24 (12,9%) 5mg 0.11 (4,8%) 10mg 0.36<br>(12,5%) 15mg 0.19 (6,3%) 20mg 0.15 (6,8%)<br>Dor estomacal<br>Placebo 0.21 (11,3%) 5mg 0.18 (9,2%) 10mg 0.27<br>(14,1%) 15mg 0.25 (12,7%) 20mg 0.23 (9,7%)<br>Poliuréia|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>NR|NR|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Placebo 0.11 (6,6%) 5mg 0.09 (4,7%) 10mg 0.11<br>(4,7%) 15mg 0.00 (0,0%) 20mg 0.07 (3,3%)<br>**_Queixas comuns a todas as crianças_**<br>Dores estomacais<br>Placebo 0.21 (11,3%) 5mg 0.23 (13,8%) 10mg 0.25<br>(14,1%) 15mg 0.25 (15,9%) 20mg 0.25 (12,7%)<br>Cãibras<br>Placebo 0.18 (9,8%) 5mg 0.18 (6,5%) 10mg 0.13<br>(6,3%) 15mg 0.16 (9,7%) 20mg 0.23 (9,7%)<br>Dores de cabeça<br>Placebo 0.18 (9,7%) 5mg 0.18 (9,2%) 10mg 0.38<br>(18,8%) 15mg 0.25 (14,1%) 20mg 0.21 (11,1%)<br>Tontura<br>Placebo 5mg0.02 (1,6%) 10mg 0.08 (4,7%) 15mg<br>0.02 (1,6%) 20mg 0.16 (9,7%)<br>Cansaço / fadiga<br>Placebo 0.37 (16,1%) 5mg 0. 33 (17,2%) 10mg 0.38<br>(15,6%) 15mg 0 .36 (18,8%) 20mg 0.18 (11,5%)<br>Dores musculares.<br>Placebo 0.09 (6,3%) .5mg 0.06 (4,6%) 10mg 0.06<br>(3,1%) 15mg 0.09 (6,2%)20mg 0 .12 (6,2%)|<br> <br> <br> <br> <br>||
|**Schulz et al., 2010**<sup>23</sup>|90 (61%)<br>PLA (n=146) = 38 (26%)<br>Ritalina (n=147) = 44 (30%)|<br> <br>Dor de cabeça<br>PLA=5 (3,4); MPH=7 (4,8)<br>Agressão<br>PLA= 5 (3,4); MPH=1 (0,7)|<br> <br> <br> <br>comportamento<br>agressivo<br>MPH: 0 PLA: 2;|<br> <br>Não houve abandono|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Insônia|<br>falta de atenção||
|||PLA=0 (0,0) MPH=0 (0,0)|<br>MPH: 0 PLA: 1||
|||Dor abdominal<br>PLA=0 (0,0); MPH=1 (0,7)<br>Anorexia|<br> <br>||
|||PLA=2 (1,4); MPH= 3 (2,0)|||
|**Simonoff et al., 2013**<sup>14</sup>|NR|Dificuldade em dormir MPH: 13 (21) PLA: 2(3),<br>p<0,01<br>Pouco apetite MPH: 9 (15) PLA: 1 (2), p=0,02<br>Parece triste / miserável MPH:2 (3) PLA: 3 (5),<br>p=1,00<br>Chora MPH: 0 PLA: 1(2), p=1,00<br>Parece ansiosa MPH: 2 (3) PLA:1 (2), p=0,99<br>Comportamento repetitivo sem sentido MPH: 4 (7)<br>PLA: 4 (7), p=1,00<br>Fala menos com outras crianças MPH: 3 (5) PLA:1<br>(2), p=0,66|<br> <br> <br> <br> <br> <br>NR|16 participantes desistiram do estudo antes da<br>semana 16; 5 dos participantes que desistiram<br>estavam fazendo uso do medicamento|
|**Tucha et al., 2006**<sup>15</sup>|NR|NR|NR|Não houve abandono|
|**Wilens et al., 2006**<sup>16</sup>|NR|Dor de cabeça MPH=3 (3,4) PLA= 6 (6,7)|NR|**fase de titulação:**27 indivíduos (12%) retiraram-se|
|||Diminuição do apetite MPH= 2 (2,3) PLA= 0<br>Insônia MPH= 4 (4,6) PLA= 0||da dose pelos seguintes motivos:<br>eventos adversos (8 sujeitos),|
|||Dor abdominal MPH= 1 (1,1) PLA= 2 (2,2)||retirada do consentimento (7 sujeitos),|
|||Náusea MPH=1 (1,1)   PLA= 2 (2,2)||violações do protocolo (6 sujeitos),|
|||||motivos administrativos (3 sujeitos),|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Astenia MPH=0 PLA= 2 (2,2)<br>Diarréia MPH=2 PLA= (2,3) 0||perda de seguimento (2 sujeitos)<br>incapacidade de engolir o medicamento (1 sujeito).<br>**fase de acompanhamento de rótulo aberto:3**se<br>retiraram por falta de eficácia|
|**Wolraich et al., 2001**<sup>17</sup>|Geral - qualquer evento:<br>126 (41,2%)<br>MPH IR|Cefaleia:<br>MPH ER: 14,4%; MPH IR: 5,8%; PLA: 10,2%<br>Redução de apetite|NR|71 crianças interromperam o tratamento<br>prematuramente MPH ER OROS, n= 15; MPH IR,<br>n= 13; placebo, n= 43);|
||40 (38,5%)<br>MPH ER<br>43(40,9%)<br>PLA<br>31 (31,9%)|MPH ER: 22,5%; MPH IR: 18,8%; PLA: 12,0% -<br>p<0,001<br>Dor abdominal:<br>MPH ER: 6,7%; MPH IR: 5,8%; PLA: 1,0%<br>Tiques<br>MPH ER: 0; MPH IR: 1,1%; PLA: 4,5%||- 59 suspenderam por falta de eficácia,<br>- 38 do grupo placebo, 11 do grupo MPH ER OROS<br>e 10 do grupo MPH IR.<br>- 3 pacientes suspenderam por não adesão,<br>- 2 por EAs / doenças intercorrentes e<br>- 2 por violações do protocolo.<br>-1 paciente suspendeu por um dos seguintes<br>motivos: EA que requer redução da dose, perdeu no<br>acompanhamento, não retornou, não conseguiu<br>engolir as pílulas e tomou MPH suplementar.|
|**MPH IR vs. MPH ER**|||||
|**Pelham et al., 2001**<sup>24</sup>|NR|Redução do apetite:<br>MPH IR: 24%; MPH ER: 18%; PLA: 4%<br>Cefaleia:<br>MPH IR: 15,9%; MPH ER: 11,8%; PLA: 23,2%<br>Dor abdominal:<br>MPH IR: 17,4%; MPH ER: 13,2%; PLA: 11,6%<br>Infecção de VAS:|0|NR|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||MPH IR: 4,3%; MPH ER: 2,9%; PLA: 4,3%<br>Lesões acidentais:<br>MPH IR: 4,3%; MPH ER: 1,5%; PLA: 2,9%<br>Vômitos:<br>MPH IR: 2,9%; MPH ER: 2,9%; PLA: 2,9%<br>Espasmos:<br>MPH IR: 5,8%; MPH ER: 0%; PLA: 0<br>Diarreia:<br>MPH IR: 2,9%; MPH ER: 0; PLA: 1,4%<br>Faringite:<br>MPH IR: %2,9; MPH ER: 1,5%; PLA: 0<br>Rinite:<br>MPH IR: 2,9%; MPH ER: 1,5%; PLA: 0<br>Tontura:<br>MPH IR: 1,4%; MPH ER: 2,9%; PLA: 0<br>Incontinência urinária:<br>MPH IR: 1,4%; MPH ER: 0%; PLA: 2,9%<br>Sono de má qualidade:|||
|||MPH IR: 7%; MPH ER: 16%; PLA: 10%|||
|**Steele et al., 2007**<sup>13</sup>|**Qualquer evento**<br>MPH ER OROS = 59 (82%)<br>MPH IR = 60 (82%)<br>**Qualquer evento**<br>**possivelmente relacionado**|<br>**Eventos mais comuns (≥10% em qualquer grupo)**<br>**_Diminuição do apetite_**<br>MPH ER OROS= 17 (24%)    R- MPH= 23 (32%)<br>**_Dor de cabeça_**|<br>NR|MPH ER OROS: 12;<br>MPH IR: 12|
||**a medicamentos**|MPH ER OROS= 14 (19%)   R- MPH= 12 (16%)|||  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
||MPH ER OROS = 46 (64%)<br>MPH IR = 38 (52%)|<br>**_Insônia_**<br>MPH ER OROS:12 (17%)   R- MPH= 10 (14%)<br>**_Dor abdominal_**<br>MPH ER OROS:10 (14%)   R- MPH= 9 (12%)<br>**_Nervosismo_**<br>MPH ER OROS9 (13%)   R- MPH= 9 (12%)<br>**_Labilidade emocional_**<br>MPH ER OROS* 9 ( 13%)    R- MPH= 2 (3%)<br>**_Agitação_**<br>MPH ER OROS8 (11%)   R- MPH= 5 (7%)<br>**_Fadiga_**<br>MPH ER OROS7 (10%)    R- MPH= 2 (3%)<br>**_Sintomas semelhantes aos da gripe_**<br>MPH ER OROS7 (10%)    R- MPH= 7 (10%)<br>**_Distúrbio do sono_**<br>MPH ER OROS3 (4% )    R- MPH= 7 (10%)|<br> <br> <br> <br> <br> <br>||
|**Wolraich et al., 2001**<sup>17</sup>|Geral - qualquer evento:|Cefaleia:|NR|71 crianças interromperam o tratamento|
||126 (41,2%)|MPH ER: 14,4%; MPH IR: 5,8%; PLA: 10,2%||prematuramente (MPH ER OROS:n= 15; MPH IR,|
||MPH IR|Redução de apetite||n= 13; placebo, n= 43); 59 suspenderam por falta de|
||40 (38,5%)|MPH ER: 22,5%; MPH IR: 18,8%; PLA: 12,0% -||eficácia, 38 do grupo placebo, 11 do grupo OROS|
||MPH ER|p<0,001||MPH e 10 do grupo MPH IR. Três pacientes|
||43(40,9%)|Dor abdominal:||suspenderam por não adesão, 2 por EAs / doenças|
||PLA|MPH ER: 6,7%; MPH IR: 5,8%; PLA: 1,0%||intercorrentes e 2 por violações do protocolo. Além|
||31 (31,9%)|Tiques||disso, 1 paciente suspendeu por um dos seguintes|
|||MPH ER: 0; MPH IR: 1,1%; PLA: 4,5%||motivos: EA que requer redução da dose, perdeu no|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||||acompanhamento, não retornou, não conseguiu<br>engolir as pílulas e tomou MPH suplementar.|
|**LDX vs. PLA**|||||
|**Biederman et al.,**<br>**2007**<sup>18</sup>|LDX 30 mg: 71,8%<br>LDX 50 mg: 67,6%<br>LDX 70 mg: 83,6%<br>PLA: 47,2%|Redução de apetite:<br>LDX 30 mg: 36,6%; LDX 50 mg: 31,1%; LDX 70<br>mg: 49,3%; PLA: 4,2% (p≤0,05)<br>Insônia:<br>LDX 30 mg: 15,5%; LDX 50 mg: 16,2%; LDX 70<br>mg: 24,7%; PLA: 2,8% (p≤0,05)<br>Dor abdominal:<br>LDX 30 mg: 14,1%; LDX 50 mg: 6,8%; LDX 70 mg:<br>15,1%; PLA: 5,6% (p>0,05)<br>Irritabilidade:<br>LDX 30 mg: 11,3%; LDX 50 mg: 8,1%; LDX 70 mg:<br>9,6%; PLA: 0 (p≤0,05)<br>Cefaleia:<br>LDX 30 mg: 9,9%; LDX 50 mg: 9,5%; LDX 70 mg:<br>16,4%; PLA: 9,7% (p>0,05)<br>Tontura:<br>LDX 30 mg: 7,0%; LDX 50 mg: 5,4%; LDX 70 mg:<br>2,7%; PLA: 0 ( LDX 30 mg vs. PLA: p≤0,05)<br>Vômito:<br>LDX 30 mg: 7,0%; LDX 50 mg: 5,4%; LDX 70 mg:<br>13,7%; PLA: 4,2% (LDX 70 mg vs. PLA: p≤0,05)|0|LDX 30 mg: 21,1%<br>LDX 50 mg: 18,9%<br>LDX 70 mg: 17,8%<br>PLA: 25%<br>Falta de eficácia:<br>LDX 30 mg: 1,4%; LDX 50 mg: 0; LDX 70 mg:<br>1,4%; PLA: 17,4%<br>Retirada de consentimento:<br>LDX 30 mg: 2,8%; LDX 50 mg: 1,3%; LDX 70 mg:<br>0; PLA: 2,8%<br>Eventos Adversos:<br>LDX 30 mg: 8,4%; LDX 50 mg: 5,4%; LDX 70 mg:<br>13,7%; PLA: 1,4%<br>Perda de seguimento:<br>LDX 30 mg: 5,6%; LDX 50 mg: 5,4%; LDX 70 mg:<br>2,7%; PLA: 1,4%<br>Violação de protocolo:<br>LDX 30 mg: 0; LDX 50 mg: 2,7%; LDX 70 mg: 0;<br>PLA: 1,4%<br>Decisão médica:|
|||Nasofaringite:||LDX 30 mg: 0; LDX 50 mg: 2,7%; LDX 70 mg: 0;|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||LDX 30 mg: 5,6%; LDX 50 mg: 4,1%; LDX 70 mg:<br>5,5%; PLA: 5,6% (p>0,05)<br>Perda de peso:<br>LDX 30 mg: 5,6%; LDX 50 mg: 2,7%; LDX 70 mg:<br>19,2%; PLA: 1,4% (LDX 70 mg vs. PLA: p≤0,05)||PLA: 0<br>Outros:<br>LDX 30 mg: 2,8%; LDX 50 mg: 1,3%; LDX 70 mg:<br>1,4%; PLA: 1,4%|
|**Findling et al., 2011**<sup>19</sup>|LDX: 68,7%<br>LDX 30 mg: 65,4%<br>LDX 50 mg: 68,8%<br>LDX 70 mg: 71,8%|Leves: LDX: 38,2%; PLA: 40,3%<br>Moderados: LDX: 28,8%; PLA: 15,6%<br>Redução de apetite:<br>LDX 30 mg: 37,2%; LDX 50 mg: 27,3%; LDX 70<br>mg: 37,2%; PLA: 2,6%<br>Tontura:|LDX: 1,7%<br>PLA: 2,6%|15,6%<br>Perda de follow-up:<br>LDX: 2,1%; PLA: 1,3%<br>EA relacionados ao tratamento:<br>LDX: 4,2%; PLA: 1,3%|
||PLA: 58,4%|LDX 30 mg: 1,3%; LDX 50 mg: 5,2%; LDX 70 mg:<br>6,4%; PLA: 3,9%<br>Boca seca:<br>LDX 30 mg: 0; LDX 50 mg: 7,8%; LDX 70 mg:<br>5,1%; PLA: 1,3%<br>Fadiga;<br>LDX 30 mg: 5,1%; LDX 50 mg: 2,6%; LDX 70 mg:<br>5,1%; PLA: 2,6%<br>Cefaleia:<br>LDX 30 mg: 11,5%; LDX 50 mg: 16,9%; LDX 70<br>mg: 15,4%; PLA: 13,0%<br>Insônia:<br>LDX 30 mg: 9,0%; LDX 50 mg: 10,4%; LDX 70 mg:<br>14,1%; PLA: 3,9%||Má-adesão:<br>LDX: 1,7%; PLA: 3,8%<br>Retirada de consentimento:<br>LDX: 1,7%; PLA: 0<br>Falta de eficácia:<br>LDX: 1,9%; PLA: 5,1%<br>Outros:<br>LDX: 4,2%; PLA: 1,3%|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Irritabilidade:<br>LDX 30 mg: 7,7%; LDX 50 mg: 2,6%; LDX 70 mg:<br>10,3%; PLA: 3,9%<br>Congestão Nasal:<br>LDX 30 mg: 1,3%; LDX 50 mg: 0; LDX 70 mg:<br>6,4%; PLA: 1,3%<br>Nasofaringite:<br>LDX 30 mg: 2,6%; LDX 50 mg: 5,2%; LDX 70 mg:<br>1,3%; PLA: 1,3%<br>Náusea:<br>LDX 30 mg: 1,3%; LDX 50 mg: 3,9%; LDX 70 mg:<br>6,4%; PLA: 2,6%<br>Infecção de VAS:<br>LDX 30 mg: 2,6%; LDX 50 mg: 5,2%; LDX 70 mg:<br>5,1%; PLA: 7,8%<br>Vômitos:<br>LDX 30 mg: 0; LDX 50 mg: 1,3%; LDX 70 mg:<br>2,6%; PLA: 5,2%<br>Redução de peso:<br>LDX 30 mg: 3,8%; LDX 50 mg: 9,1%; LDX 70 mg:<br>15,4%; PLA: 0|||
|**Coghill et al., 2013**<sup>20</sup>|LDX: 72,1%<br>PLA: 57,3%|Redução de apetite:<br>LDX: 25,2%; PLA: 2,7%; MPH: 15,3%|LDX: 2,7%<br>(Síncope, DRGE,|41,7%|
||MPH: 64,9%|Cefaleia:<br>LDX: 14,4%; PLA: 2,0%; MPH: 19,8%|apendicite)<br>PLA: 2,7%|Falta de eficácia:<br>LDX: 9,7%; PLA: 48,6%; MPH: 19,6%|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||Insônia:|(perda de|Má-adesão:|
|||LDX: 14,4%; PLA: 0; MPH: 8,1%|consciência,|LDX: 2,6%; PLA: 1,8%; MPH: 2,7%|
|||Redução de peso:|hematoma,|Retirada de consentimento:|
|||LDX: 13,5%; PLA: 0; MPH: 4,5%|fratura de|LDX: 3,5%; PLA: 3,6%; MPH: 4,5%|
|||Náusea:|clavícula)|Perda de follow-up:|
|||LDX: 10,8%; PLA: 2,7%; MPH: 7,2%|MPH: 1,8%|MPH: 0,9%|
|||Anorexia:|(overdose e|Eventos Adversos:|
|||LDX: 10,8%; PLA: 1,8%; MPH: 5,4%<br>Nasofaringite:|síncope)|LDX: 4,5%; PLA: 3,6%; MPH: 1,8%<br>Outros:|
|||LDX: 7,2%; PLA: 7,3%; MPH: 12,6%<br>Dor abdominal:<br>LDX: 12,6%; PLA: 10,9%; MPH: 11,7%<br>Alterações do sono:<br>LDX: 8,1%; PLA: 1,8%; MPH: 8,1%<br>Tosse:<br>LDX: 2,7%; PLA: 0,9%; MPH: 6,3%<br>Morte:||LDX: 8,8%; PLA: 3,6%; MPH: 4,5%|
|||LDX: 0; PLA: 0; MPH: 0|||
|**Wigal et al., 2009**<sup>25</sup>|LDX todas as doses= 38<br>(33.0) 22 (19.1)|Diminuição do apetite- 47%,<br>Insônia- 27%,|<br> <br>NR|**Evento adverso: 9 (7.0)**<br>30 mg/d LDX= 8 (13.8);|
|||Dor de cabeça- 17%<br>Irritabilidade 16%,|<br>|50 mg/d= 1 (2.0);<br>70 mg/d= 0|
|||Dor supra abdominal- 16%,||**Violação do protocolo: 2 (1.6)**|
|||labilidade emocional- 10%||30 mg/d LDX= 1 (1.7);<br>50 mg/d= 1 (2.0);|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||||70 mg/d= 0<br>**Consentimento retirado= 5 (3.9)**<br>30 mg/d LDX= 3 (5.2);<br>50 mg/d= 1 (2.0);<br>70 mg/d= 1 (4.8)<br>**Perda do FU= 2 (1.6)**<br>30 mg/d LDX= 2 (3.4);<br>50 mg/d= 1 (2.0);<br>70 mg/d= 0|
|**MPH vs. LDX**|||||
|**Newcorn et al., 2017**<sup>22</sup>||Redução de apetite:|EA graves:|LDX: 15,6%; MPH: 14,6%; PLA: 24,7%|
|**(dose flexível)**|Qualquer EA|LDX: 53,3%;MPH: 41,8%;PLA: 7,7%|LDX: 5,4%;||
||LDX (n=184): 83,2%|Redução de peso:|MPH: 3,8%;|Eventos adversos:|
||MPH (n=184): 82,1%|LDX: 20,1%;MPH: 13,0%;PLA: 1,1%|PLA:2,2%|LDX: 7,6%; MPH: 1,6%; PLA: 3,3%|
||PLA (n=91): 63,7%|Irritabilidade:||Falta de eficácia:|
|||LDX: 20,1%;MPH: 7,6%;PLA: 9,9%|EA sérios:|LDX: 0,5%; MPH: 2,1%; PLA: 8,6%|
||EA relacionados ao|Cefaleia:|LDX: 0,5%|Perda de seguimento:|
||medicamento:|LDX: 15,2%;MPH: 15,2%;PLA: 7,7%|(ideação suicida);|LDX: 3,2%; MPH: 2,7%; PLA: 4,3%|
||LDX (n=184): 73,9%|Insônia:|MPH: 0,5% (cisto|Violação de protocolo:|
||MPH (n=184): 66,3%|LDX: 8,7%;MPH: 8,2%;PLA: 0|renal);|LDX: 2,1%; MPH: 2,2%; PLA: 0|
||PLA (n=91): 30,8%|Insônia inicial:|PLA: 0|Retirada:|
|||LDX: 8,2%;MPH: 6,5%;PLA: 2,2%||LDX: 2,1%; MPH: 2,7%; PLA: 6,4%|
|||Boca seca:|EA fatais:|Outros:|
|||LDX: 8,2%;MPH: 6,0%;PLA: 1,1%<br>Náusea:|LDX: 0; MPH: 0;<br>PLA: 0|LDX: 0; MPH: 3,2%; PLA: 2,1%|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
|||LDX: 7,6%;MPH: 8,2%;PLA: 4,4%<br>Dor abdominal (superior):<br>LDX: 6,5%;MPH: 5,4%;PLA: 4,4%<br>Tontura:<br>LDX: 6,5%;MPH: 4,3%;PLA: 1,1%<br>Nasofaringite:<br>LDX: 6,0%;MPH: 7,1%;PLA: 1,1%<br>Sonolência:<br>LDX: 5,4%;MPH: 3,3%;PLA: 4,4%<br>Fadiga:<br>LDX: 5,4%;MPH: 2,7%;PLA: 3,3%<br>Infecção de VAS:<br>LDX: 4,9%;MPH: 3,3%;PLA: 8,8%<br>Aumento de frequência cardíaca:<br>LDX: 4,3%;MPH: 6,0%;PLA: 0|||
|**Newcorn et al., 2017**<sup>22</sup>||Redução de apetite:|EA graves:|LDX: 16,9%; MPH: 15%; PLA: 12,8%|
|**(dose forçada)**|Qualquer EA|LDX: 31,7%;MPH: 23,3%;PLA: 10,0%|LDX: 1,4%;||
||LDX (n=218): 66,5%|Cefaleia:|MPH: 2,7%;|Eventos adversos:|
||MPH (n=219): 58,9%|LDX: 15,1%;MPH: 16,0%;PLA: 8,2%|PLA:0,9%|LDX: 7,3%; MPH: 6,8%; PLA:0,9%|
||PLA (n=110): 44,5%|Redução de peso:||Falta de eficácia:|
|||LDX: 10,6%;MPH: 5,0%;PLA: 0|EA sérios:|LDX: 1,4%; MPH: 0,4%; PLA: 3,6%|
||EA relacionados ao|Insônia:|LDX: 0,4%|Perda de seguimento:|
||medicamento:|LDX: 7,8%;MPH: 7,8%;PLA: 2,7%|(ideação suicida);|<br>LDX: 1,4%; MPH: 2,7%; PLA: 0,9%|
||LDX (n=218): 53,7%|Boca seca:|MPH: 0,4%|Violação de protocolo:|
|||LDX: 7,3%;MPH: 3,2%;PLA: 0,9%|(apendicite);|LDX: 1,4%; MPH: 1,4%; PLA: 2,7%|  
|**Estudo (autor-ano)**|**Eventos adversos gerais**|**Eventos Adversos**|**Eventos**<br>**adversos graves**|**Abandono de tratamento por qualquer causa**|
|---|---|---|---|---|
||MPH (n=219): 44,7%|Tontura:|PLA: 0,9%|Retirada:|
||PLA (n=110): 28,2%|LDX: 5,5%;MPH: 5,0%;PLA: 0|(distúrbio|LDX: 4,1%; MPH: 2,7%; PLA: 0,9%|
|||Irritabilidade:|psicótico)|Outros:|
|||LDX: 5,0%;MPH: 6,8%;PLA: 6,4%||LDX: 1,8%; MPH: 1,4%; PLA: 2,7%|
|||Náusea:|EA fatais:||
|||LDX: 5,0%;MPH: 5,0%;PLA: 2,7%|LDX: 0; MPH: 0;||
|||Dor abdominal (superior):|PLA: 0||
|||LDX: 5,0%;MPH: 3,7%;PLA: 1,8%|||

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Risco de viés dos estudos incluídos** -->
Os ensaios clínicos incluídos foram avaliados pela ferramenta de risco de viés da Cochrane (RoB 2.0)<sup>26</sup> . Os itens mais frequentemente comprometidos foram à randomização e o relato seletivo de desfechos. No geral, os estudos apresentaram alto risco de viés ( **Figura 3** ).  
**Figura 3** – Avaliação do riso de viés dos estudos incluídos  
<!-- Start of picture text -->
Biederman et al., 2003<br>? + + + + !<br>Biederman et al., 2007<br>+ ? + + + !<br>Coghill et al., 2013<br>+ — ? + + —<br>Newcorn et al., 2017 (flex_dose)<br>? — + + + —<br>Findling et al., 2006<br>? ? + + + !<br>Findling et al., 2008<br>+ + ? + + !<br>Findling et al., 2011<br>? + + + + !<br>Newcorn et al., 2017 (forc_dose)<br>? — + + + —<br>Rapport et al., 1994<br>— ? — — — —<br>Rapport et al., 2008<br>— + + — — —<br>Schulz et al., 2010<br>? + + — — —<br>Simonoff et al., 2013<br>+ + + + — !<br>Tucha et al., 2006<br>+ — — + — —<br>Wilens et al., 2006<br>? + + ? — —<br>Steele et al., 2007<br>+ + + ? — —<br>Wolraich et al., 2001<br>+ — — — — —<br>Wigal et al., 2009<br>+ + — — — —<br>Randomização  Desvios das intervenções  Desfechos incompletos  Medida dos desfechos  Relato seletivo dos desfechos  Geral<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **_<u>Melhora clínica global</u>_** -->
**Figura 4 -** Rede de comparações para o desfecho de melhora clínica  
<!-- Start of picture text -->
PLACEBO<br>1<br>LDX<br>MPH_IR<br>7 \ 2<br>4 [~~ MPH_ER_OROS<br>MPH_ER_SODAS<br><!-- End of picture text -->  
Legenda: LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata.  
Para o desfecho de melhora clínica, observa-se que tanto para comparações diretas quanto indiretas, houve superioridade dos quatro tratamentos ativos (MPH nas três apresentações ou LDX) em relação ao placebo. A **Figura 5** ilustra os resultados das meta-análises em rede da comparação entre os diferentes medicamentos para TDAH em relação ao placebo. Não foi observada heterogeneidade substancial entre os estudos (τ=0,21). Quando as terapias ativas foram comparadas entre si, não foi observada diferença significante em melhora clínica ( **Quadro D** ). A avaliação da inconsistência entre análises diretas e indiretas por comparação para o desfecho de melhora clínica é demonstrada no **Quadro E** .  
**Figura 5 –** Meta-análise em rede das comparações entre tratamentos medicamentosos e placebo para o desfecho de melhoria clínica  
<!-- Start of picture text -->
Comparison: other vs 'Placebo'<br>Treatment (Random Effects Model) RR 95%-Cl<br>LDX —B— 2.52 [2.02; 3.16]<br>MPH_ER_OROS —— 2.33 [1.86; 2.92]<br>MPH_ER_SODAS —_—+—_ 177 [1.05; 3.00]<br>MPH_IR —+— 211 [1.48; 3.02]<br>Placebo 1.00<br>0.5 1 2<br><!-- End of picture text -->  
Desvio padrão entre estudos (τ): 0,21. Número de estudos: 10. Número de tratamentos: 5. Todos os tratamentos são contra o tratamento referência (placebo). Legenda: CI, intervalo de confiança; LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – sistema SODAS®; MPH_IR, metilfenidato de liberação imediata; RR. Risco relativo.  
**Quadro D -** Resultados de efeito de tratamento para todos os pares de comparações para o desfecho de melhora clínica  
|**LDX**||1,14 [0,89|; 1,46]|.||.||2,42 [1,91; 3,07]|Me|
|---|---|---|---|---|---|---|---|---|---|
|1,08 [0,8<br>m rede|6; 1,36]|**MPH_ER**|**_OROS**|1,17 [0,83;|1,64]|.||2,35 [1,83; 3,01]|ta-anál|
|1,19 [0,8<br>nálise e|2; 1,73]|1,10 [0,80|; 1,51]|**MPH_IR**||.||2,67 [1,56; 4,58]|ise_pairw_|
|1,43 [0,8<br>Meta-a|0; 2,53]|1,32 [0,74|; 2,33]|1,19 [0,63;|2,25]|**MPH**|**_ER_SODAS**|1,77 [1,05; 3,00]|_ise_|
|2,52 [2,0|2; 3,16]|2,33 [1,86|; 2,92]|2,11 [1,48;|3,02]|1,77|[1,05; 3,00]|**Placebo**||
|egenda: LDX, lisde<br>rolongada – Sistem<br>**Quadro E -**Avaliaç|xanfetamina;<br>a SODAS®;<br>ão da inconsis<br>**Número**|MPH_ER_OR<br>MPH_IR, meti<br>tência entre an<br>|OS, metilfenid<br>lfenidato de lib<br>álises diretas e|ato de liberação<br>eração imediata.<br>indiretas por co|prolongada<br> <br>mparação p|– Siste<br>ara o de|ma OROS®; MPH_ER_<br>sfecho de melhora clínic<br>**Diferença do**|SODAS, metilfenidato d<br>a<br>**Diferença do**|e liberaçã<br>|
|**Comparação**|**de**<br>**estudos**|**NMA**|**Direta**|**Indireta**|**Difer**|**ença**|**limite inferior**<br>**do IC 95%**|**limite superior**<br>**do IC 95%**|**Valor**<br>**de p**|
|LDX<br>MPH_ER_OR<br>OS|3|0,08|0,13|-0,18|0,31||-0,30|0,93|0,32|
|LDX<br>MPH_ER_SO<br>DAS|0|0,35|ND|0,35|ND||ND|ND|ND|
|LDX<br>MPH_IR|0|0,18|ND|0,18|ND||ND|ND|ND|
|LDX<br>Placebo|5|0,93|0,88|1,27|-0,39||-1,11|0,33|0,29|
|MPH_ER_OR<br>OS<br>MPH_ER_SO<br>DAS|0|0,27|ND|0,27|ND||ND|ND|ND|
|MPH_ER_OR<br>OS<br>MPH_IR|2|0,10|0,15|-0,23|0,38||-0,51|1,27|0,40|
|MPH_ER_OR||||||||||
|OS<br>Placebo|5|0,84|0,85|0,80|0,05||-0,57|0,67|0,88|
|MPH_ER_SO<br>DAS|0|-0,18|ND|-0,18|ND||ND|ND|ND|  
Legenda: LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata.  
**Quadro E -** Avaliação da inconsistência entre análises diretas e indiretas por comparação para o desfecho de melhora clínica  
|**Comparação**|**Número**<br>**de**<br>**estudos**|**NMA**|**Direta**|**Indireta**|**Diferença**|**Diferença do**<br>**limite inferior**<br>**do IC 95%**|**Diferença do**<br>**limite superior**<br>**do IC 95%**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|
|MPH_IR|||||||||
|MPH_ER_SO|||||||||
|DAS|1|0,57|0,57|NA|ND|ND|ND|ND|
|Placebo|||||||||
|MPH_IR<br>Placebo|2|0,75|0,98|0,57|0,42|-0,30|1,13|0,25|  
Legenda: IC, intervalo de confiança; LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata; ND, não disponível.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **<u>Eventos adversos gerais</u>** -->
**Figura 5 -** Rede de comparações para o desfecho de eventos adversos gerais.  
<!-- Start of picture text -->
PLACEBO<br>1<br>LDX<br>MPH_IR<br>7 \ 2<br>4[x MPH_ER_OROS<br>MPH_ER_SODAS<br><!-- End of picture text -->  
Legenda: LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata.  
**Figura 6 -** Meta-análise em rede das comparações entre tratamentos medicamentosos e placebo para o desfecho eventos adversos gerais  
<!-- Start of picture text -->
Comparison: other vs 'Placebo'<br>Treatment (Random Effects Model) RR 95%-Cl<br>LDX —fB— 2.52 [2.02: 3.16]<br>MPH_ER_OROS —— 2.33 [1.86; 2.92]<br>MPH_ER_SODAS —_—+——__ 177 [1.05; 3.00]<br>MPH_IR —+— 2.11 [1.48; 3.02]<br>Placebo 1.00<br>0.5 1 2<br><!-- End of picture text -->  
Desvio padrão entre estudos (τ): 0,15. Número de estudos: 10. Número de tratamentos: 5. Todos os tratamentos são contra o tratamento referência (placebo). Legenda: CI, intervalo de confiança; LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – sistema SODAS®; MPH_IR, metilfenidato de liberação imediata; RR. Risco relativo.  
Os resultados de efeito de tratamento para todos os pares de comparações para o desfecho de eventos adversos gerais encontram-se no **Quadro F** e a avaliação da inconsistência entre análises diretas e indiretas por comparação para o desfecho de eventos adversos gerais, no **Quadro G.**  
**Quadro F** - Resultados de efeito de tratamento para todos os pares de comparações para o desfecho de eventos adversos gerais  
|**Placebo**<br>de|1,17 [0,88; 1,54]|0,97 [0,50; 1,89]|0,81 [0,69; 0,96]|0,74 [0,63; 0,87]||
|---|---|---|---|---|---|
|1,01 [0,81; 1,25]<br>e em re|**MPH_IR**|.|1,04 [0,80; 1,35]|.|Meta-an|
|0,97 [0,50; 1,89]<br>a-anális|0,97 [0,48; 1,94]|**MPH_ER_SODAS**|.|.|álise _pa_|
|0,87 [0,74; 1,01]<br>Met|0,86 [0,70; 1,07]|0,89 [0,45; 1,76]|**MPH_ER_OROS**|0,93 [0,77; 1,12]|_irwise_|
|0,77 [0,66; 0,90]|0,76 [0,60; 0,98]|0,79 [0,40; 1,56]|0,89 [0,75; 1,05]|**LDX**||  
Legenda: LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata.  
**Quadro G -** Avaliação da inconsistência entre análises diretas e indiretas por comparação para o desfecho de eventos adversos gerais  
|**Comparação**|**Número**<br>**de**<br>**estudos**|**NMA**|**Direta**|**Indireta**|**Diferença**|**Diferença do**<br>**limite inferior**<br>**do IC 95%**|**Diferença do**<br>**limite superior**<br>**do IC 95%**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|
|LDX<br>MPH_ER_OROS|3|0,12|0,08|0,28|-0,20|-0,61|0,20|0,32|
|LDX<br>MPH_ER_SODAS|0|0,24|ND|0,24|ND|ND|ND|ND|
|LDX<br>MPH_IR|0|0,27|ND|0,27|ND|ND|ND|ND|
|LDX<br>Placebo|5|0,26|0,29|-0,04|0,34|-0,19|0,87|0,21|
|MPH_ER_OROS<br>MPH_ER_SODAS|0|0,12|ND|0,12|ND|ND|ND|ND|
|MPH_ER_OROS<br>MPH_IR|**2**|**0,15**|**-0,04**|**0,55**|**-0,59**|**-1,05**|**-0,13**|**0,01**|
|MPH_ER_OROS<br>Placebo|5|0,14|0,21|-0,15|0,36|-0,04|0,75|0,08|
|MPH_ER_SODAS<br>MPH_IR|0|0,03|ND|0,03|ND|ND|ND|ND|
|MPH_ER_SODAS<br>Placebo|1|0,03|0,03|ND|ND|ND|ND|ND|
|MPH_IR|2|-0,01|-0,15|0,23|-0,39|-0,83|0,06|0,09|  
|**Comparação**|**Número**<br>**de**<br>**estudos**|**NMA**|**Direta**|**Indireta**|**Diferença**|**Diferença do**<br>**limite inferior**<br>**do IC 95%**|**Diferença do**<br>**limite superior**<br>**do IC 95%**|**Valor**<br>**de p**|
|---|---|---|---|---|---|---|---|---|
|Placebo|||||||||  
Legenda: IC, intervalo de confiança; LDX, lisdexanfetamina; MPH_ER_OROS, metilfenidato de liberação prolongada – Sistema OROS®; MPH_ER_SODAS, metilfenidato de liberação prolongada – Sistema SODAS®; MPH_IR, metilfenidato de liberação imediata; ND, não disponível.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Avaliação da Qualidade da Evidência** -->
O perfil de evidências encontra-se especificado na **Tabela E** .  
**Tabela E –** Tabela perfil de evidências (SOF)  
||||**Avaliação da ce**|**rteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**Número**<br>**de**<br>**estudos**|**Desenho de**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**Indireta**|**Imprecisão**|**Outras**<br>**Considerações**|**Impacto**|**Certeza**|**Importância**|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Melhora Clínica** -->
|10|Ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a</sup>|não grave|grave<sup>b, c</sup>|não grave|associação forte|Comparado ao placebo, todos<br>os medicamentos foram<br>superiores ao placebo em<br>melhora clínica, sendo que<br>LDX, MPH ER OROS e<br>MPH IR apresentaram grande<br>magnitude de efeito<br>(RR=2,52; IC 95%: [2,02;<br>3,16]; RR=2,33 [IC 95%:<br>1,86; 2,92]; e RR=2,11 [IC<br>95%: 1,48; 3,02],<br>respectivamente), porém sem<br>diferença entre os<br>medicamentos ativos. Não<br>houve inconsistência<br>significativa entre os achados<br>das meta-análises em rede e<br>pairwise.|⨁⨁◯◯<br>BAIXA|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|  
**Eventos adversos gerais**  
|**Número**|||**Avaliação da ce**|**rteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|<br>**de**<br>**estudos**|**Desenho de**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**Indireta**|**Imprecisão**|**Outras**<br>**Considerações**|**Impacto**|**Certeza**|**Importância**|
|10|Ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>a</sup>|grave d|grave<sup>b</sup>|não grave|nenhuma|Placebo e metilfenidato<br>estiveram associados a menor<br>risco de eventos adversos<br>gerais comparados à LDX<br>(RR=0,77 [IC 95%: 0,66;<br>0,90] e RR= 0,76 [IC 95%:<br>0,60; 0,98], respectivamente)<br>nas metas análises em rede.<br>As demais comparações não<br>apresentaram diferença.<br>Inconsistência foi verificada<br>apenas para a comparação<br>MPH ER OROS e MPH IR<br>indicando que as meta-<br>análises pairwise e em rede<br>apresentaram resultados<br>discordantes, em direções<br>diferentes (RR=1,04 [IC<br>95%: 0,80; 1,35] e RR=0,86<br>[IC 95%: 0,70; 1,07],<br>respectivamente), embora<br>sem significância estatística.|⨁◯◯◯<br>MUITO BAIXA|IMPORTANTE|  
Legenda: IC, Intervalo de confiança; RR, Risco Relativo. Explicações: a. Alto risco de viés pela ferramenta RoB-2 da Cochrane; b. Evidência proveniente de comparações diretas e indiretas; c. Desfecho substituto para avaliação de resposta ao tratamento; d. Inconsistência entre achados da meta-análise em rede e pairwise na comparação MPH ER OROS – MPH IR

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Pergunta** -->
|**Deve-se usar metilfenid**|**ato ou lisdexanfetamina para o tratamento de TDAH em crianças e adolescentes de 6 a 17 anos?**|
|---|---|
|**População:**|Crianças com idade entre 6 e 17 anos com TDAH|
|**Intervenção:**|Metilfenidato (liberações prolongada ou imediata) ou lisdexanfetamina|
|**Comparação:**|Comparação dos medicamentos e apresentações entre si|
|**Principais desfechos:**|Melhora clínica e eventos adversos gerais|
|**Perspectiva:**|SISTEMA ÚNICO DE SAÚDE (SUS)|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Avaliação** -->
|**Problema**<br>**O problema é uma priorid**|**́  ade?**||
|---|---|---|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**<br>**ADICIONAIS**|
|○ Não|· TDAH é o tipo de transtorno do neurodesenvolvimento mais comum na infância, podendo também estar presente na||
|○ Provavelmente não|idade adulta;||
|○ Provavelmente sim<br>● Sim|· A prevalência mundial estimada em crianças e adolescentes é de 3% a 8%, dependendo do sistema de classificação<br>utilizado.||
|○ Há variabilidade|· No Brasil, os dados de prevalência são semelhantes aos relatados em todo o mundo, com 7,6% de crianças e adolescentes||
|○ Não é possível dar uma|entre de 6 a 17 anos com sintomas de TDAH;||
|resposta|· O TDAH gera uma demanda crescente por serviços de saúde mental e está associado a mais sintomas, problemas<br>familiares e escolares em comparação com a população em geral;||  
||· O TDAH também está associado a resultados psicológicos negativos, como um risco aumentado de desenvolver<br>distúrbios de personalidade e possivelmente condições psicóticas.||
|---|---|---|
|**Efeitos desejáveis**<br>**Quão substanciais (consid  ̃**|**̃  erados importantes) são os efeitos esperados desejaveis**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**<br>**ADICIONAIS**|
|○ Não relevante|· Melhora na sintomatologia:||
|○ Pequeno|- Todos os tratamentos ativos foram superiores ao placebo.||
|● Moderado|- MPH OROS vs. MPH IR: MPH OROS superior ao IR na taxa de remissão e na gravidade dos sintomas, IOWA-||
|○ Grande<br>○ Há variabilidade|Conners' e CGI (Steele et al., 2007); O estudo de Wolraich et al., 2001 não encontrou diferenças em sintomatologia<br>quando avaliado pelo IOWA Conners';||
|○ Não é possível dar uma<br>resposta|- LDX vs. MPH: Nos estudos de Newcorn et al., 2007, pacientes em uso de LDX apresentaram maior redução de<br>sintomas.||
||· Melhora clínica (todos os medicamentos foram superiores ao placebo, mas não diferentes entre si);||  
<!-- Start of picture text -->
FIGURA4. META-ANAUISE EM REDE DAS COMPARACOES ENTRE TRATAMENTOS FARMACOLOGICOSE PLACEBO PARAO<br>DESFECHO DE MELHORIA CLINICA,<br>Comparison: other vs 'Placebo'<br>Treatment (Random Effects Model) RR = 95%-Cl<br>LDX —E- 2.52 (2.02; 3.16]<br>MPH_ER_OROS —#— 233 [1.86; 292]<br>MPH_ER_SODAS. \——+—— 1177 [1.05; 3.00]<br>MPH_IR —#— 2.11 [1.48; 3.02]<br>Placebo 1.00<br>05 1 2<br>Between-study standard deviation: 0.21 , Number of studies:<br>10,Numberof treatments: 5<br>All outcomes are versus the reference treatment (treatment<br>labelled 4)<br>‘QUADRO 5, RESULTADOS DE EFEITO DE TRATAMENTO PARA TODOS 0S PARES DE COMPARAGOES PARA O DESFECHO DE<br>MELHORA CLINICA<br><!-- End of picture text -->  
· Muito frequentemente podem ocorrer nasofaringite, diminuição do apetite, nervosismo, insônia, náusea e boca seca. · Comumente, podem ocorrer ansiedade, inquietação, distúrbio do sono agitação, discinesia, tontura, tremores, cefaleia, sonolência, tosse, _rash_ cutâneo, prurido, urticaria, febre, queda de cabelo, hiperidrose, artralgia, nervosismo, diminuição de peso, fenômeno de Raynaud e sensação de frio em extremidades.  
<!-- Start of picture text -->
Figura 6. Meta-andlise em rede das comparacdes entre tratamentos farmacoldgicos e placebo<br>para o desfecho de eventos adversos gerais.<br>Comparison: other vs 'Placebo!<br>Treatment (Random Effects Model) RR = 95%-Cl<br>LDX —_ 1.30 [1.12; 1.52]<br>MPH_ER_OROS 1.15 (0.99; 1.34]<br>MPH_ER_SODAS 1.03 [0.53; 1.99]<br>MPH_IR —_ 0.99 [0.80; 1.24]<br>Placebo 1.00<br>075 1 15<br>Between-study standard deviation: 0.15 , Number of studies:<br>10 , Number of treatments: 5<br>‘All outcomes are versus the reference treatment (treatment<br>labelled 1)<br><!-- End of picture text -->  
<!-- Start of picture text -->
QUADROEVENTOS7.ADVERSOSRESULTADOSGERAIS DE EFEITO DE TRATAMENTO PARA TODOS OS PARES DE COMPARACOES PARAO DESFECHO DE<br>Se FS<br>e Ff<br>3 8<br>{[[orcson|ommeo|<br>ones | omanse | oe |<br><!-- End of picture text -->  
|**Efeitos indesejáveis**|||
|---|---|---|
|**Quão substanciais (consi  ̃**|**̃  derados importantes) são os efeitos esperados indesejaveis?**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**|
|||**ADICIONAIS**|  
|○ Grande|· Melhora na sintomatologia:|
|---|---|
|● Moderado|- Todos os tratamentos ativos foram superiores ao placebo.|
|○ Pequeno|- MPH OROS vs. MPH IR: MPH OROS superior ao IR na taxa de remissão e na gravidade dos sintomas, IOWA-Conners'|
|○ Não relevante|e CGI (Steele et al., 2007); O estudo de Wolraich et al., 2001 não encontrou diferenças em sintomatologia quando|
|○ Varies|avaliado pelo IOWA Conners';|
|○ Não é possível dar uma|- LDX vs. MPH: Nos estudos de Newcorn et al., 2007, pacientes em uso de LDX apresentaram maior redução de|
|resposta|sintomas.|
||· Melhora clínica (todos os medicamentos foram superiores ao placebo, mas não diferentes entre si);|  
<!-- Start of picture text -->
FIGURA 4. META-ANALISE EM REDE DAS COMPARACOES ENTRE TRATAMENTOS FARMACOLOGICOS E PLACEBO PARA O<br>DESFECHO DE MELHORIA CLINICA.<br>Comparison: other vs 'Placebo'<br>Treatment (Random Effects Model) RR 95%-Cl<br>LDX TE 2.52 [2.02; 3.16]<br>MPH_ER_OROS Ee 233 [1.86; 2.92]<br>MPH_ER_SODAS |_———+———._ 177 [1.05; 3.00]<br>MPH_IR —*— 2.11 [1.48; 3.02]<br>Placebo 1.00<br>0s 1 2<br>Between-study standard deviation: 0.21 , Number of studies:<br>10 , Number<br>of treatments: 5<br>All outcomes are versus the reference treatment (treatment<br>labelled 1)<br>QUADROMELHORA5.CLINICARESULTADOS DE EFEITO DE TRATAMENTO PARA TODOS OS PARES DE COMPARACOES PARAO DESFECHO DE<br>t mrnenonos [ariossixea[| 2s ta6sisou<br>g RB<br><!-- End of picture text -->  
· Muito frequentemente podem ocorrer nasofaringite, diminuição do apetite, nervosismo, insônia, náusea e boca seca. · Comumente, podem ocorrer ansiedade, inquietação, distúrbio do sono agitação, discinesia, tontura, tremores, cefaleia, sonolência, tosse, _rash_ cutâneo, prurido, urticaria, febre, queda de cabelo, hiperidrose, artralgia, nervosismo, diminuição de peso, fenômeno de Raynaud e sensação de frio em extremidades.  
<!-- Start of picture text -->
Figura 6. Meta-andlise em rede das comparacGes entre tratamentos farmacoldgicos e placebo<br>para o desfecho de eventos adversos gerais.<br>Comparison: other vs 'Placebo'<br>Treatment (Random Effects Model) RR  95%-Cl<br>LDX oo 1.30 [1.12; 1.52]<br>MPH_ER_OROS 1.15 (0.99; 1.34]<br>MPH_ER_SODAS 1.03 [0.53; 1.99]<br>MPH_IR — 0.99 [0.80; 1.24]<br>Placebo 1.00<br>075 1 15<br>Between-study standard deviation: 0.15 , Number of studies:<br>10 , Number of treatments: 5<br>‘All outcomes are versus the reference treatment (treatment<br>labelled 1)<br><!-- End of picture text -->  
<!-- Start of picture text -->
EVENTOS‘QUADRO7.ADVERSOSRESULTADOS GERAIS DE EFEITO DE TRATAMENTO PARA TODOS OS PARES DE COMPARAGOESPARAO DESFECHO DE<br>z<br>:<br>sHy<br><!-- End of picture text -->  
|**Certeza da evidência**|||
|---|---|---|
|**Qual é a certeza geral da ̂**|**́     evidência dos efeitos?**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**|
|||**ADICIONAIS**|  
|○ Muito baixo|· A qualidade geral da evidência foi baixa para o desfecho de melhora clínica, embora a maioria das medidas de efeito||
|---|---|---|
|● Baixo|tenham sido de grande magnitude. A avaliação foi penalizada pelo alto risco de viés dos estudos e pela evidência indireta.||
|○ Moderado<br>○ Alto<br>○ Nenhum estudo incluído<br>**Valores e preferências**<br>**Existe uma incerteza impor**|· Já para o desfecho de eventos adversos gerais, a qualidade geral da evidência foi muito baixa, considerando os mesmos<br>fatores para_downgrade_, como também pela inconsistência observada em uma das comparações.<br>**tante sobre a variabilidade (enquanto) como as pessoas que valorizam o resultado principal?**<br>|<br>|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**<br>**ADICIONAIS**|
|○ Importante incerteza ou<br>variabilidade|· Todos os medicamentos considerados são de administração por via oral, o que representa maior comodidade e facilidade<br>de uso.||
|● Possivelmente incerteza<br>ou variabilidade importante<br>○ Provavelmente não há<br>incerteza ou variabilidade<br>importante<br>○ Nenhuma incerteza ou<br>variabilidade importante|· O metilfenidato está disponível em diversas apresentações. O medicamento de liberação imediata deve ser administrado<br>em dois períodos, mais comumente de manhã e no início da tarde, podendo haver maior risco de esquecimento de doses.<br>· Ambas as apresentações de metilfenidato ER (SODAS® e OROS®) e lisdexanfetamina são medicamentos<br>administrados uma vez ao dia, o que confere maior praticidade e reduz a chance de esquecimento de doses subsequentes.<br>· Poucos estudos reportaram adesão ao tratamento. Em um deles, discute-se que a substituição de um medicamento em<br>esquema de múltiplas doses para administração uma vez ao dia pode aumentar a adesão ao tratamento em<br>aproximadamente 25%. Entretanto, esta discussão foi baseada em resultados para outras condições clínicas, que não<br>TDAH. Ademais, neste estudo a adesão ao tratamento foi de 100% em todos os braços de tratamento. Em um ensaio<br>clínico randomizado, observou-se que a proporção de pacientes que perderam uma dose do medicamento no grupo que<br>recebeu metilfenidato uma vez ao dia foi inferior ao que recebeu metilfenidato de duas a três vezes ao dia (56% vs. 84%,<br>respectivamente)49. Este estudo, entretanto, não apresentou nenhuma análise estratificada de acordo com esta variável,<br>de modo que não podem ser tiradas conclusões definitivas acerca de eficácia e adesão ao medicamento.<br>· Frequentemente ocorrem anorexia, cefaleia, insônia e irritabilidade, fatores que podem resultar em dificuldades por<br>parte do usuário.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|
|**Equilíbrio dos efeitos**|||  
**O equilíbrio entre efeitos desejáveis e efeitos indesejáveis favorece a intervenção ou a comparação?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**||**CONSIDERAÇÕES**|
|---|---|---|---|
||||**ADICIONAIS**|
|○ Favorecer a comparação|Conforme observado em efeitos desejáveis e indesejáveis:|||
|○ Provavelmente favorece a<br>comparação|· Metilfenidato (em suas diferentes apresentações) e lisdexanfetamina resultam em melhora clínica q<br>ao placebo, mas não apresentam diferenças significativas entre si.|uando comparado||
|○ Não favorece a|· Quanto à segurança, os resultados sugerem que há maior risco de eventos adversos gerais com a|lisdexanfetamina||
|intervenção ou a<br>comparação|quando comparada ao placebo e ao metilfenidato de liberação imediata.|||
|● Provavelmente favorece a||||
|intervenção||||
|○ Favorece a intervenção<br>○ Há variabilidade||||
|○ Não é possível dar uma||||
|resposta||||
|**Recursos necessários***<br>**Quão grande são os requisit**|**̃  ̃  os de recursos (custos)?**|||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇ**|**ÕES ADICIONAIS**|
|● Grandes custos|·**Valor base:**preço unitário mínimo pago em compras federais no ano de 2019-2020 (BPS/SIASG)|||
|○ Custos moderados|**Metilfenidato:**10 mg- R$ 0,51|* Após a reunião|de consenso, os custos|
|○ necessidade de recursos|40mg- R$ 5,71|dos medicamen|tos foram atualizados|
|similares|54mg- R$ 6,29|para apresenta|ção ao plenário da|
|○ Economia moderada|**Lisdexanfetamina:**50mg- R$ 8,85|Conitec, resulta|ndo em alterações no|
|○ Grande economia||impacto orçam|entário discutido em|
|○ Há variabilidade|**Acesso 100% (com preços PMVG18%).**|consenso.||  
|○ Não é possível dar uma|·**Ano 1**|
|---|---|
|resposta|MPH IR: R$ 2.055.797.743,04<br>MPH ER: R$ 6.063.614.977,68<br>LDX: R$ 9.260.973.486,69<br>Mix: R$ 6.152.468.928,21<br>·**5 anos:**<br>MPH IR: R$ 10.196.884.253,80<br>MPH ER: R$ 30.075.906.200,50<br>LDX: R$ 45.935.002.624,07<br>Mix: R$ 30.516.627.303,58|
||**Acesso 100% (com preços SIASG)**<br>·**Ano 1**<br>MPH IR: R$ 2.016.263.171,06<br>MPH ER: R$ 5.930.185.797,24<br>LDX: R$ 8.747.024.050,93<br>Mix: R$ 5.944.121.733,86<br>·**5 anos:**<br>MPH IR: R$ 10.000.790.325,84<br>MPH ER: R$ 29.414.089.193,64<br>LDX: R$ 43.385.781.560,62<br>Mix: R$ 29.483.212.303,25|
||**Acesso variável: 30 a 50% (com preços PMVG18%)**<br>·**Ano 1**<br>MPH IR: R$ 616.739.322,91<br>MPH ER: R$ 1.819.084.493,30|  
||LDX: R$ 2.778.292.046,01<br>Mix: R$ 1.845.740.678,46<br>·**5 anos:**<br>MPH IR: R$ 4.075.282.855,19<br>MPH ER: R$ 12.020.125.152,20<br>LDX: R$ 18.358.365.554,37<br>Mix: R$ 12.196.263.579,45||
|---|---|---|
||**Acesso variável: 30 a 50% (com preços SIASG)**<br>·**Ano 1**<br>MPH IR: R$ 604.878.951,32<br>MPH ER: R$ 1.779.055.739,17<br>LDX: R$ 2.624.107.215,28<br>Mix: R$ 1.783.236.520,16<br>·**5 anos:**<br>MPH IR: R$ 3.996.912.031,05<br>MPH ER: R$ 11.755.623.620,73<br>LDX: R$ 17.339.544.840,58<br>Mix: R$ 11.783.249.336,24||
|**Custo efetividade**<br>**A custo-efetividade da ̧̃   ̧̃   ̧̃**|**intervenção favorece a intervenção ou a comparação?**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|  
|● Favorece a comparação|· Considerando-se que para o desfecho de melhora clínica (avaliado pela escala CGI-I) não houve||
|---|---|---|
|○ Provavelmente favorece a<br>comparação<br>○ Não favorece a<br>intervenção ou a<br>comparação<br>○ Provavelmente favorece a<br>intervenção<br>○ Favorece a intervenção<br>○ Há variabilidade<br>○ Nenhum estudo incluído|diferença entre os tratamentos medicamentosos, realizou-se análise de custo-minimização para<br>comparação entre os tratamentos.<br>· Considerando-se o menor preço pago em compras públicas pelo governo federal em 2019, a<br>lisdexanfetamina, comparada ao metilfenidato de liberação prolongada e imediata, resultou em custos<br>incrementais de R$ 1.040,25 e R$ 2.485,65, respectivamente, em um ano, por paciente adicional que<br>apresentou melhora clínica.<br>O metilfenidato de liberação prolongada, comparada ao de liberação imediata, resultou em custo<br>incremental de R$ 1.445,40 por paciente que apresentou melhora clínica.||
|**Equidade**<br>**Qual seria o impacto na equ  ́**|**idade em saúde?**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**<br>**ADICIONAIS**|
|○ Reduziria<br>○ Provavelmente reduziria<br>○ Provavelmente sem<br>impacto<br>● Provavelmente<br>aumentaria<br>○ Aumentaria<br>○ Há variabilidade<br>○ Não é possível dar uma<br>resposta|· Famílias com menor renda, atualmente, não teriam condição de arcar com o tratamento;<br>· Atualmente não existem medicamentos disponíveis no SUS para o tratamento de TDAH.||  
|**Aceitabilidade**<br>**A intervenção é compatíve**|**̧̃ ́ ́l com as principais partes interessadas?**||
|---|---|---|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ Não<br>○ Provavelmente não|· Atualmente o SUS não disponibiliza nenhum medicamento para TDAH, assim pressupõe-se que a<br>incorporação de um ou mais medicamentos seja bem aceita para pacientes, pais e demais envolvidos;||
|● Provavelmente sim<br>○ Sim<br>○ Há variabilidade<br>○ Não é possível dar uma<br>resposta|· Deve-se ressaltar que o tratamento medicamentoso alcança melhores resultados se acompanhados de<br>intervenções não medicamentosas como terapia e apoio educacional.||
|**Viabilidade**<br>**A intervenção é viável par**<br>|**̧̃ ́ ́ a implementar?**<br>||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES**<br>**ADICIONAIS**|
|○ Não|· O medicamento é facilmente disponível em farmácias;||
|○ Provavelmente não|· O fornecimento dos medicamentos deverá ser feito por meio de prescrição de medicamentos controlados;||
|● Provavelmente sim<br>○ Sim<br>○ Há variabilidade<br>○ Não é possível dar uma<br>resposta|· Na modalidade liberação imediata, será necessária articulação entre pais e professores para auxílio e s<br>administração da dose do medicamento da tarde.|upervisão na|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Resumo dos julgamentos** -->
|**PROBLEMA**|**JULGAMEN**<br>Não|**TO**<br>Provavelmente<br>não|Provavelmente<br>sim|**Sim**||Há<br>variabilidade|<br>Não é<br>possível<br>dar uma<br>resposta|
|---|---|---|---|---|---|---|---|
|**EFEITOS**<br>**DESEJÁVEIS**|Não<br>relevante|Pequeno|**Moderado**|Grande||Há<br>variabilidade|<br>Não é<br>possível<br>dar uma<br>resposta|
|**EFEITOS**<br>**INDESEJÁVEIS**|Grande|**Moderado**|Pequeno|Não relevante||Varies|Não é<br>possível<br>dar uma<br>resposta|
|**CERTEZA DA**<br>**EVIDÊNCIA**|Muito baixo|**Baixo**|Moderado|Alto|||Nenhum<br>estudo<br>incluído|
|**VALORES E**<br>**PREFERÊNCIAS**|Importante<br>incerteza ou<br>variabilidade|**Possivelmente**<br>**incerteza ou**<br>**variabilidade**<br>**importante**|Provavelmente<br>não há<br>incerteza ou<br>variabilidade<br>importante|Nenhuma<br>incerteza ou<br>variabilidade<br>importante||||
|**EQUILÍBRIO DOS**<br>**EFEITOS**|Favorecer a<br>comparação|Provavelmente<br>favorece a<br>comparação|Não favorece a<br>intervenção ou<br>a comparação|**Provavelmente**<br>**favorece a**<br>**intervenção**|Favorece a<br>intervenção|Há<br>variabilidade|<br>Não é<br>possível<br>dar uma<br>resposta|
|**RECURSOS**<br>**NECESSÁRIOS**|**Grandes**<br>**custos**|Custos<br>moderados|necessidade de<br>recursos<br>similares|Economia<br>moderada|Grande<br>economia|Há<br>variabilidade|<br>Não é<br>possível<br>dar uma<br>resposta|
|**CUSTO**<br>**EFETIVIDADE**|**Favorece a**<br>**comparação**|Provavelmente<br>favorece a<br>comparação|Não favorece a<br>intervenção ou<br>a comparação|Provavelmente<br>favorece a<br>intervenção|Favorece a<br>intervenção|Há<br>variabilidade|<br>Nenhum<br>estudo<br>incluído|
|**EQUIDADE**|Reduziria|Provavelmente<br>reduziria|Provavelmente<br>sem impacto|**Provavelmente**<br>**aumentaria**|Aumentaria|Há<br>variabilidade|<br>Não é<br>possível<br>dar uma<br>resposta|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **JULGAMENTO** -->
|**ACEITABILIDADE**<br>**VIABILIDADE**|Não<br>Não|Provavelmente<br>não<br>Provavelmente<br>não|**Provavelmente**<br>**sim**<br>**Provavelmente**<br>**sim**|Sim<br>Sim|Há<br>variabilidade<br>Há<br>variabilidade|Não é<br>possível<br>dar uma<br>resposta<br>Não é<br>possível<br>dar uma<br>resposta|
|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Tipo de recomendação** -->
|Recomendação forte|Recomendação|Recomendação|**Recomendação**|Recomendação forte a|
|---|---|---|---|---|
|contra a intervenção (a|fraca/condicional contra|fraca/condicional, sendo|**fraca/condicional a**|favor da intervenção|
|favor do comparador)|a intervenção (a favor do<br>comparador)|<br>indiferente à intervenção<br>ou ao comparador|<br>**favor da intervenção**<br>**(contra o comparador)**|(contra o comparador)|
|○|○|○|**●**|○|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **RECOMENDAÇÃO** -->
O painel recomendou fracamente o MPH IR em relação às demais opções de tratamento ativo. Durante o processo o grupo levantou a necessidade de outras opções terapêuticas a depender do quadro clínico de cada indivíduo. Ademais foi enfatizada a necessidade de um posicionamento ativo em psicoeducação, para que se tenha maior efetividade no tratamento clínico da condição.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **PERGUNTA PICO 2** -->
**Questão de pesquisa:** Qual a eficácia e a segurança da Terapia cognitivo-comportamental no tratamento de crianças, adolescentes e adultos com Transtorno do Déficit de Atenção com Hiperatividade?  
Nesta pergunta, pacientes (P) eram crianças, adolescentes e adultos com Transtorno do Déficit de Atenção com Hiperatividade (I) a intervenção foi Terapia cognitivo-comportamental; comparadores (C) foram Lista de espera ou cuidados habituais, Intervenções medicamentosas ou outras intervenções não-medicamentosas e desfechos (O) foram Melhora dos sintomas de TDAH (eficácia) e eventos adversos (segurança).

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Estratégia de busca** -->
As estratégias de busca adotadas encontram-se no **Quadro H** .  
**Quadro H -** Estratégias de busca de evidências em base de dados  
|**Bases**|**Estratégia de Busca**|**Número**<br>**de**<br>**Artigos**|
|---|---|---|
|||**Recuperados**|  
|**MEDLINE**<br>**PubMed**|**via**|(((cognitive behavioral therapy mesh OR cognitive psychotherapy OR<br>cognition therapy OR behavioral therapy psychotherapy OR cognition<br>therapy OR cognitive psychotherapy))) AND ((((((ADDH) OR ADHD) OR<br>ADDH) OR ADHS)) AND (((((Attention Deficit Disorder) OR Oppositional<br>Defiant Disorder) OR disruptive Behavior Disorder) OR (Attention Deficit<br>and Disruptive Behavior Disorder)) OR Attention Deficit-Hyperactivity<br>Disorder))<br>**Data de acesso:**06/01/2020|1.529|
|---|---|---|---|
|**EMBASE**||(('cognitive behavioral therapy'/exp OR 'cognitive behavioral therapy') AND<br>[embase]/lim OR ('cognition therapy' AND [embase]/lim) OR ('cognitive<br>psychotherapy' AND [embase]/lim)) AND (('attention deficit disorder'/exp<br>OR 'attention deficit disorder') AND [embase]/lim OR (('adhd'/exp OR adhd)<br>AND [embase]/lim) OR (addh AND [embase]/lim))<br>**Data de acesso:**06/01/2020|2.621|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Seleção das evidências** -->
A busca das evidências resultou em 4.274 referências (1.529 no MEDLINE e 2.745 no EMBASE) e outras 8 recuperadas por busca manual. Destas, 124 foram excluídas por estarem duplicadas. Um total de 4.158 referências foram triadas por meio da leitura de título e resumos, das quais 43 tiveram seus textos completos avaliados para avaliação da elegibilidade ( **Figura 6** ). Por fim, 16 estudos clínicos comparativos atenderam aos critérios de inclusão.  
**Figura 6 -** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
(—) Artigos identificadospor meio de buses<br>3<br>§<br>;<br>tocolo<br>i m<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Descrição dos estudos e resultados** -->
A descrição sumária dos estudos incluídos encontra-se na **Tabela F** . A caracterização dos participantes de cada estudo pode ser vista na **Tabela G** . Resultados de eficácia encontram-se na **Tabela H e Tabela I** . As figuras ( **Figura 7, 8, 9, 10, 11,**  
**12, 13, 14, 15** ) apresentam os resultados da meta-análise e risco de viés ( **Figuras 16, 17, 18, 19** ).  
**Tabela F -** Características dos estudos clínicos incluídos na revisão  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|**TCC em crian**|**ças ou adolescentes**|||||
|**TCC em grup**|**o vs. lista de espera**|||||
|Vidal et al.,<br>2015<sup>27</sup>|ECR multicêntrico|Determinar a eficácia da TCC em grupo,<br>em adolescentes com TDAH que estavam<br>em tratamento medicamentoso, mas ainda<br>apresentavam sintomas persistentes.|<br>119 adolescentes com<br>idade entre 15 e 21 anos<br>com diagnóstico de TDAH| TCC em grupo<br>12 sessões semanais| Lista de espera<br>Tratamento<br>psicofarmacológico de<br>rotina|
|**TCC vs. Outr**|**a intervenção não far**|**macológica**||||
|Banaschewski|<br>ECR_crossover_|Avaliar a eficácia do treinamento sensório|<br>12 crianças entre 7 e 10| Treinamento| Treinamento sensório-|
|et al., 2001<sup>28</sup>|AB-BA|motor comparado com terapia cognitivo<br>comportamental (TCC) em crianças com<br>TDAH.|anos com diagnóstico de<br>TDAH|cognitivo-<br>comportamental em<br>grupo<br>`o`<br>20 sessões (50<br>min cada),<br>2x/semana<br>Duração: 4 meses|motor em grupo<br>`o`<br>20 sessões (50 min<br>cada), 2x/semana<br>Duração: 4 meses|
|**TCC associad**|**o a terapia familiar vs**<br>|**. lista de espera**||||
|Sprich et al.,<br>2016<sup>29</sup>|ECR c_rossover_<sup>_b_</sup>|Testar a TCC para sintomas persistentes de<br>TDAH em uma amostra de adolescentes já<br>tratados com medicamentos.|<br>46 adolescentes entre 14 a<br>18 anos, com TDAH e<br>sintomas clinicamente<br>significativos, apesar do<br>tratamento medicamentoso<br>estável.| TCC individual<br>associado a TCC<br>familiar (n=24)<br>12 sessões, sendo 10<br>entre o terapeuta e<br>adolescente, e duas<br>sessões que incluíram<br>os pais.| Lista de espera (n=22)<br>`o`<br>Pacientes recebiam<br>tratamento<br>psicofarmacológico<br>de rotina<br>Após a avaliação de quatro<br>meses estes participantes|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|---|
||||||foram autorizados a cruzar<br>para receber a intervenção.|
|**TCC associad**|**o a terapia familiar v**|**s. Outra intervenção não farmacológica**||||
|Fehlings et<br>al., 1991<sup>30</sup>|ECR|Avaliar a eficácia da TCC na melhora do<br>comportamento doméstico de crianças com<br>TDAH|<br>25 meninos com idade<br>entre 7 e 13 anos com<br>diagnóstico de TDAH.| TCC individual<br>associado a TCC<br>familiar<br>`o`<br>TCC individual:<br>12 sessões<br>individuais com<br>a criança (60<br>min cada),<br>2x/semana.<br>TCC familiar: 8 sessões<br>de 2h a cada 2 semanas<br>com a família.| Terapia de suporte<br>`o`<br>Terapia individual:<br>12 sessões<br>individuais com a<br>criança (60 min<br>cada), 2x/semana.<br>`o`<br>Terapia familiar: 8<br>sessões de 2h a cada<br>2 semanas com a<br>família.<br>Não houve instruções de<br>estratégias cognitivas-<br>comportamentais.|
|**TCC em adul**|**tos**|||||
|**TCC vs. Lista**|**de espera**|||||
|Huang et al.,<br>2019<sup>31</sup> **(A)**|ECR|Investigar a eficácia da TCC comparado<br>com controle em chineses com TDAH|<br>108 adultos entre 18 e 65<br>anos com diagnóstico de<br>TDAH| TCC (n = 43)<br>12 sessões (120 min<br>cada) semanais em<br>grupo|Controle (lista de espera) (n<br>= 22)|
|Virta et al.,<br>2010<sup>32</sup> **(A)**|ECR – piloto, cego<br>(avaliador)|Avaliar a viabilidade e a eficácia da TCC<br>individual de curto prazo em adultos com<br>TDAH e seus impactos nos sintomas,|<br>29 adultos entre 18 e 49<br>anos com diagnóstico de<br>TDAH| TCC individual de<br>curto prazo (n = 10)| Controle - não<br>especificado (n = 10)|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|**TCC associad**<br>|**o a medicamento vs.**<br>|humor, qualidade de vida e desempenho<br>cognitivo do TDAH<br>**Cuidados usuais associado a medicamento**<br>||`o`<br>10 sessões<br>semanais, 60<br>min cada<br> Co-intervenção<br>`o`<br>5 participantes<br>com<br>farmacoterapia<br>específica para o<br>TDAH<br>| Co-intervenção<br>7 participantes em uso de<br>farmacoterapia específica<br>para TDAH e 3 sem)<br>|
|Corbisiero et<br>al., 2018<sup>33</sup>|ECR|Avaliar a eficácia da terapia multimodal<br>(medicamento + psicoterapia) em<br>comparação com ao medicamento isolado<br>em indivíduos adultos com TDAH.<br>Analisar a contribuição da psicoterapia no<br>tratamento de adultos com TDAH|<br>43 adultos entre 18 e 49<br>anos com diagnóstico de<br>TDAH| TCC + farmacoterapia<br>[MPH] (n = 23)<br> Entre 10 a 12 sessões<br>(cada sessão de TCC<br>durava cerca de 120<br>min).| TAU + farmacoterapia<br>[MPH]<br>(n = 20)<br> Entre 10 a 12 sessões de<br>tratamento clínico padrão<br>associado a metilfenidato.|
|Dittner AJ et<br>al., 2017<sup>34</sup>|ECR|Investigar a eficácia, aceitabilidade do<br>paciente e a viabilidade da TCC para<br>adultos com TDAH.|<br>60 adultos entre 18 e 65<br>anos com diagnóstico de<br>TDAH| TAU + TCC (n = 30)<br> 15 sessões de TCC<br>associada a cuidados<br>usuais.| TAU/MED (n = 30)<br> Isso incluiu visitas ao<br>médico para o<br>gerenciamento do TDAH<br>(medicamentos e em<br>questões relacionadas,<br>como eventos adversos).|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|Emilsson B et<br>al., 2011<sup>35</sup>|ECR|Avaliar a eficácia da TCC em grupo, a<br>partir de um programa recentemente<br>desenvolvido para tratar sintomas de<br>TDAH e comorbidades comuns.|<br>54 adultos entre 18 e 65<br>anos com TDAH| TCC/MED (n = 27)<br> 15 sessões, duas vezes<br>por semana, cada uma<br>com duração de 90<br>minutos) +<br>farmacoterapia|<br> <br> TAU/MED (n = 27)<br> Pacientes receberam<br>tratamento<br>psicofarmacológico|
|Safren et al.,<br>2005<sup>36</sup>|ECR|Examinar a eficácia potencial, a<br>aceitabilidade do paciente e a viabilidade<br>de uma nova TCC para adultos com TDAH<br>que foram estabilizados com<br>medicamentos, mas ainda mostram<br>sintomas clinicamente relevantes.|<br>31 adultos entre 18 e 65<br>anos com diagnóstico de<br>TDAH| TCC +<br>psicofarmacologia<br>continuada (n = 16)<br> Entre 12 a 15 sessões<br>semanais de TCC| Psicofarmacologia<br>continuada (n = 15)<br> Dose e momento da<br>administração da<br>farmacoterapia não foram<br>especificados|
|Young et al.,<br>2015<sup>37</sup>|ECR|Avaliar a eficácia de um tratamento<br>multimodal envolvendo TCC e tratamento<br>medicamentoso| 95 adultos com TDAH que já<br>estavam sendo tratados com<br>medicamento (MED)| TCC / MED (n = 48)<br> TCC: 15 sessões<br>2x/semana (90<br>minutos cada,<br>excluindo uma pausa<br>no meio da sessão)| TAU / MED (n = 47)<br> Incluía tratamentos<br>medicamentosos e não<br>medicamentosos|
|Young et al.,<br>2017<sup>38</sup>|ECR|Investigar os resultados funcionais de um<br>tratamento multimodal oferecido a adultos<br>com TDAH que estavam em uso de<br>medicamentos.| 95 adultos com TDAH que já<br>estavam sendo tratados com<br>MED| TCC/MED (n = 48)<br>`o`<br>Sessões em<br>grupo:<br>2x/semana (total:<br>8 semanas e<br>`o`<br>Sessões<br>individuais:| TAU / MED (n = 47)<br> Incluía tratamentos<br>medicamentosos e não<br>medicamentosos|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|||||ocorreram entre<br>cada sessão de<br>grupo<br> Objetivo: ajudar os<br>participantes a<br>transferir as<br>habilidades<br>aprendidas no grupo<br>para suas vidas diárias||
|**TCC vs. Inter**|**venções não medicam**|**entosas**||||
|van Emmerik-<br>van|ECR aberto|Comparar a eficácia de um tratamento<br>integrado de TCC à outra terapia| 119 adultos entre 18 e 65 anos,<br>com qualquer distúrbio de uso|<br> TCC integrada<br>`o`<br>TCC entregue| TCC SUD<br>`o`<br>Terapia entregue|
|Oortmerssen||direcionada apenas ao distúrbio de uso de|de substâncias (SUD), senão|individualmente,|individualmente,|
|et al., 2019<sup>39</sup>||substâncias (SUD) em pacientes adultos<br>com SUD e TDAH|apenas a dependência da<br>nicotina, e diagnóstico de<br>TDAH.|projetado para<br>tratar o TDAH e<br>o SUD.<br>15 sessões semanais|projetado para tratar<br>somente SUD.<br>10 sessões quinzenais|
|Huang et al.,<br>2019<sup>31</sup> **(B)**|ECR|Investigar a eficácia da TCC comparado<br>com controle em chineses com TDAH|<br>108 adultos entre 18 e 65<br>anos com diagnóstico de<br>TDAH| TCC (n = 43)<br>12 sessões (120 min<br>cada) semanais em<br>grupo|TCC + reforço (n = 43)<br><br>12 sessões (120 min<br>cada) semanais em<br>grupo|
|Virta et al.,|ECR – piloto, cego|Avaliar a viabilidade e a eficácia da TCC|<br>29 adultos entre 18 e 49| TCC individual de| Treinamento cognitivo -|
|2010<sup>32</sup> **(B)**|(avaliador)|comparada a Terapia comportamental (TC)<br>individuais de curto prazo em adultos com|anos com diagnóstico de<br>TDAH|curto prazo (n = 10)|TC (n = 9)|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|<br>**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|**TCC associa**<br>|**do a medicamento vs. O**<br>|TDAH e seus impactos nos sintomas,<br>humor, qualidade de vida e desempenho<br>cognitivo do TDAH<br>**utras intervenções associadas a medicame**<br>|**nto**|`o`<br>10 sessões<br>semanais, 60<br>min cada<br> Co-intervenção<br>`o`<br>5 participantes<br>com<br>farmacoterapia<br>específica para o<br>TDAH|`o`<br>20 sessões,<br>2x/semana, 60 min<br>cada<br> Co-intervenção<br>`o`<br>5 participantes em<br>uso de<br>farmacoterapia<br>específica para<br>TDAH|
|Philipsen et<br>al., 2015<sup>40</sup>|ECR fatorial<br>multicêntrico<sup>a</sup>|Avaliar a eficácia da psicoterapia<br>cognitivo-comportamental em grupo<br>(TCC) em comparação com o tratamento<br>clínico individual (CM) ambos os grupos<br>associados a placebo (PCB) ou MPH.|<br>433 adultos entre 18 a 60<br>anos, com diagnóstico de<br>TDAH.| TCC + MPH<br> TCC + placebo<br>`o`<br>Sessões de TCC<br>em grupo: 120<br>minutos cada<br>sessão<br>`o`<br>Sessões<br>semanais até a<br>12 semana<br>`o`<br>Sessões mensais<br>entre a 13 à 22<br>sessão| CM + MPH<br> CM + placebo<br>`o`<br>Sessões de CM em<br>grupo: 15 a 20<br>minutos cada sessão<br>`o`<br>Sessões semanais até<br>a 12 semana<br>`o`<br>Sessões mensais<br>entre a 13 à 22 sessão|  
|**Autor**|**Desenho do estudo**|**Objetivo**|**Número**<br>**de**<br>**participantes**<br>**incluídos**|**Intervenção**|**Controle**|
|---|---|---|---|---|---|
|||||Os pacientes receberam<br>metilfenidato ou<br>placebo por 1 ano.|Os pacientes receberam<br>metilfenidato ou placebo por<br>1 ano.|
|Safren et al.,<br>2010<sup>41</sup>|ECR|Testar a TCC para o TDAH em adultos<br>tratados com medicamentos, mas que ainda<br>apresentam sintomas clinicamente<br>significativos.|<br>86 adultos entre 18 e 65<br>anos, com TDAH, cuja<br>gravidade ≥ 3 na escala de<br>Impressão Clínica Global e<br>estabilizados com<br>psicotrópicos| TCC individual (n =<br>43)<br>12 sessões (50 min<br>cada) semanais +<br>farmacologia| Relaxamento com Suporte<br>Educacional (n = 43)<br>12 sessões (50 min cada)<br>semanais + farmacologia|
|Vidal et al.,<br>2013<sup>42</sup>|ECR|Avaliar a eficácia da psicoeducação em<br>comparação a TCC em grupo em adultos<br>com TDAH que estão em tratamento<br>medicamentoso, mas ainda apresentam<br>sintomas significativos.|<br>32 adultos acima de 18<br>anos com diagnóstico de<br>TDAH, que estão em<br>tratamento<br>medicamentoso, mas ainda<br>apresentam sintomas<br>significativos| Psicoeducação (n =<br>17)<br>Sessões de 2h cada, por<br>12 semanas| TCC (n = 15)<br>Sessões de 2h cada, por 12<br>semanas|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Descrição dos estudos e resultados** -->
MPH: metilfenidato; TAU: tratamento usual; MED: medicamento; DUS: distúrbio de uso de substâncias; TCC: terapia cognitivo comportamental; CM: tratamento  clínico individual. aTriplo cego para tratamento medicamentoso  e unicego para psicoterapia ou tratamento  clínico (cego para os avaliadores) bO estudo originalmente tinha 8 meses de seguimento, porém foram utilizados os dados de 4meses apenas, já que os pacientes alocados inicialmente para a lista de espera seriam cruzados para o braço tratamento após 4 meses [15 pacientes da lista de espera foram cruzados para a TCC].  
**Tabela G -** Características das amostras dos estudos clínicos incluídos na revisão  
|**Autor e**<br>|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|**Ano**||||||
|**TCC em cria**|**nças ou adolescen**|**tes**||||
|**TCC vs. lista**|**de espera**|||||
|Vidal et al.,<br>2015<sup>27</sup>|TCC: 59<br>Lista de espera:<br>60|TCC: 17,5 (1,88)<br>Lista de espera: 16,9<br>(1,75)|TCC: 20 (33,9%)<br>Lista de espera: 18<br>(30%)| Transtorno desafiador de oposição (TDO):<br>`o`<br>TCC: 7/59 vs. Lista de espera: 8/60<br> Distúrbios de aprendizagem como dislexia:<br>`o`<br>TCC: 2/59 vs. Lista de espera: 3/60| Indivíduos que não estavam em<br>tratamento medicamentoso foram<br>excluídos do estudo<br> Farmacoterapia:<br>`o`<br>MPH:<br>TCC: 54 vs. Lista de espera:<br>47<br>`o`<br>Atomoxetina:<br>TCC: 9 vs. Lista de espera:<br>13|
|**TCC vs. Out**|**ra intervenção não**|**farmacológica**||||
|Banaschews<br>ki et al.,<br>2001<sup>28</sup>|TCC: 12<br>Sensório motor:<br>12|8,8<sup>a</sup>|2 (16,7%)<sup>a</sup>| Não menciona| Cinco crianças receberam MPH<br>que permaneceu estável durante o<br>estudo.|
|**TCC associa**|**do a terapia famili**|**ar vs. lista de espera**||||
||TCC + família:|TCC+ família: 15,17|TCC+ família: 6| 56,4% possuía pelo menos uma| Todos os pacientes incluídos|
|Sprich et al.,|24|(1,01)|(25%)|comorbidade:|tomavam um medicamento, cuja|
|2016<sup>29</sup>|Lista de espera:|Lista de espera: 15,09|Lista de espera: 4|`o`<br>Transtorno desafiador de oposição: 12|dose não foi alterada por pelo|
||22|(1,11)|(18,2%)|`o`<br>Fobia específica: 6|menos 2 meses|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|**TCC associa**|**do a terapia famili**|**ar vs. Outra intervenção nã**|**o farmacológica**|`o`<br>Fobia social: 6<br>`o`<br>Transtorno de ansiedade generalizada:<br>3<br>`o`<br>Transtorno de tiques: 2<br>`o`<br>Distimia: 1||
|Fehlings et<br>al., 1991<sup>30</sup>|TCC + família:<br>12<br>Terapia suporte:<br>13|TCC + família: 9,3 (1)<br>Terapia de suporte: 9,6<br>(2)|TCC + família: 0<br>Terapia de suporte: 0| Os pacientes incluídos não poderiam ter<br>transtornos de conduta ou transtornos<br>psiquiátricos identificados na entrevista<br>inicial| NR|
|**TCC em ad**<br>**TCC vs. Li**|**ultos**<br>**sta de espera**|||||
|Huang et<br>al., 2019<sup>31</sup><br>**(A)**|TCC: 43<br>Controle: 22|TCC: 26,68 (5,01)<br>Controle = 26,91 (6,15)|TCC: 13 (30,2%)<br>Controle: 10<br>(45,5%)| ≥1 Distúrbio clínico (ansiedade, compulsão<br>alimentar, afetiva): TCC: 20 (46,5%) vs.<br>Controle: 2 (9,1%)<br>`o`<br>Transtornos afetivos:  TCC: 8 (18.6%)<br>vs. Controle: 2 (9.1%)<br>`o`<br>Transtornos de ansiedade: TCC: 4<br>(9.3%) vs. Controle: 1 (4.5%)<br> ≥1 Transtorno de personalidade (negativista,<br>dependente, outros):TCC: 14 (32,6%) vs.<br>Controle: 12 (54,4%)| Tratamento psicofarmacológico<br>(≥ 1 medicamento) no_baseline:_<br>TCC: 16 (37,2%) vs. Controle: 6<br>(27,3%)<br>`o`<br>MPH: TCC: 10 (23.3%) vs.<br>Controle: 3 (13.6%)<br>`o`<br>Atomoxetina: TCC: 5 (11.6)<br>vs. Controle: 2 (9.1%)<br>`o`<br>Antidepressivos: TCC: 3<br>(7.05%) vs. Controle: 1<br>(4.5%)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|Virta et al.,<br>2010<sup>32</sup> **(A)**<br>**TCC associa**|TCC: 10<br>Controle :10<br>**do a medicamento**|TCC: 38,2 [25-49]<br>Controle: 34,0 [22-49]<br>**vs. Cuidados usuais associa**|TCC: 10<br>Controle: 10<br>**do a medicamento**|`o`<br>Evitação: TCC: 2 (4.7%) vs. Controle:<br>3 (13.6%)<br>`o`<br>Obsessivo-compulsivo: TCC: 3 (7.0%)<br>vs. Controle: 3 (13.6%)<br>`o`<br>Negativista: TCC: 1 (2.3%) vs.<br>Controle: 0<br>`o`<br>Outros: TCC: 1 (2.3%) vs. Controle: 0<br> Qualquer comorbidade psiquiátrica<br>(depressão, ansiedade e desordem de<br>personalidade):<br>TCC: 7 (70%) vs. Controle: 3 (33,3%)| Indivíduos que tomavam<br>medicamento: TCC: 5 MPH<br>(50%) Controle: 7 (70%)<br>`o`<br>MPH: TCC: 5 (50%)<br>Controle: 5 (50%)<br>`o`<br>Modafinil: TCC: 0 (0%) vs.<br>Controle: 1 (10%)<br>`o`<br>Atomoxetina: TCC: 0 (0%)<br>vs. Controle: 1 (10%)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|Corbisiero<br>et al.,<br>2018<sup>33</sup>|TCC+MPH: 20<br>TAU+MPH: 23|TCC+MPH: 34,05 (9,34)<br>TAU+MPH: 30,04 (7,21)|TCC+MPH = 9<br>(45%)<br>TAU+MPH: 10<br>(43,5%)| 12 pacientes foram avaliados com<br>comorbidades:<br>`o`<br>Abuso de álcool: 1<br>`o`<br>Dependência/abuso de Cannabis: 2 (1<br>em cada grupo)<br>`o`<br>Episódio depressivo: 2 (1 em cada<br>grupo)<br>`o`<br>Fobia social: 1<br>`o`<br>Fobia específica: 1<br>`o`<br>Estresse pós-traumático: 1<br>`o`<br>Transtornos da Personalidade: 8| Ambos os grupos receberam<br>tratamento medicamentoso com<br>metilfenidato antes da<br>randomização.<br> Outros medicamentos (que não<br>MPH) eram permitidos desde que<br>o paciente o usasse em doses<br>estáveis há 3 meses.|
|Dittner et<br>al., 2017<sup>34</sup>|TCC: 30<br>TAU: 30|TCC: 35,7 (9)<br>TAU: 36,1 (10,4)|TCC: 7 (20,7%)<br>TAU: 12 (40%)| Depressão moderada a grave: TCC: 1 vs.<br>TAU: 4<br> Ansiedade moderada a grave: TCC: 14 vs.<br>TAU: 14| Medicamento para TDAH:<br>TCC: 19/30(63,3%) vs. TAU:<br>26/30 (86,7%)<br>`o`<br>MPH: TCC: 16 (53,3%) vs.<br>TAU: 18 (60,0%)<br>`o`<br>Anfetamina: TCC: 1 (3,3%)<br>vs. TAU: 7 (23,3%)<br>`o`<br>Anfetamina e modafinil:<br>TCC: 1 (3,3%) vs. TAU: 0<br>(0,0%)<br>`o`<br>Atomoxetina: TCC: 1 (3,3%)<br>vs. TAU: 1 (3,3%)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
||||||`o`<br>Outros medicamentos: TCC:<br>3 (10,0%) vs. TAU: 8<br>(26,7%)<br> Outros medicamentos<br>psicotrópicos:<br>`o`<br>ISRS: TCC: 2 (6,7%) vs.<br>TAU: 8 (26,7%)<br>`o`<br>Benzodiazepínico: TCC: 1<br>(3,3%) vs. TAU: 0 (0,0%)|
|Emilsson B<br>et al.,<br>2011<sup>35</sup>|TCC / MED: 27<br>TAU / MED: 27|34,1 (10,9)<sup>a</sup>|34 (63%)| Depressão: 35 (64,8%)<br> Transtorno de ansiedade: 20 (37%)<br> Histórico de abuso de álcool/drogas: 12<br>(22,2%)<br> Outro problema psiquiátrico: 9 (16,7%)| MPH: 42 (77,8%)<br> Atomoxetina: 11 (20,4%)<br> Bupropiona: 5 (9,3%)<br> Anfetamina: 1 (1,9%)<br> Apenas um medicamento: 13<br>(24,1%)<br> Dois medicamentos: 16 (29,6%)<br> Três ou mais medicamentos: 25<br>(46,3%)|
|Safren et al.,<br>2005<sup>36</sup>|<br>TCC / MED: 16<br>TAU / MED: 15|45,5 (10,6)<sup>a</sup>|17 (54,8%)|NR| Todos os pacientes incluídos<br>foram estabilizados<sup>b</sup>com<br>medicamentos para TDAH ou<br>sintomas relacionados.|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|Young et<br>al., 2015<sup>37</sup>|TCC / MED: 48<br>TAU / MED: 47|TCC + MED: 34,2 (10,6)<br>TAU + MED: 36,2<br>(12,75)|TCC + MED: 30<br>(62,5%)<br>TAU + MED: 32<br>(68,1%)| Depressão: 63,2%<br> Ansiedade: 36,8%<br> Histórico de abuso de álcool/drogas: 15,8%<br> Distúrbio de personalidade/Síndrome de<br>Asperger: 7,4%<br> Transtorno de estresse pós-traumático: 4,2%<br> Transtorno alimentar: 2,1%| Todos os pacientes incluídos<br>tomavam um medicamento para<br>TDAH estavam estáveis por pelo<br>menos 1 mês.<br>`o`<br>MPH: 79 (83,2%)<br>`o`<br>Atomoxetina: 16 (16,8%)<br>`o`<br>Bupropiona: 5<br>`o`<br>Outros (antidepressivos,<br>benzodiazepínicos, insulina e<br>ibuprofeno): 63 (66,3%)|
|Young et<br>al., 2017<sup>38</sup><br>**TCC vs. In**|TCC / MED: 48<br>TAU / MED: 47<br>**tervenções não med**|TCC + MED: 34,2 (10,6)<br>TAU + MED: 36,2<br>(12,75)<br>**icamentosas**|TCC + MED: 30<br>(62,5%)<br>TAU + MED: 32<br>(68,1%)| Depressão: 63,2%<br> Ansiedade: 36,8%<br> Histórico de abuso de álcool/drogas: 15,8%<br> Distúrbio de personalidade/Síndrome de<br>Asperger: 7,4%<br> Transtorno de estresse pós-traumático: 4,2%<br>Transtorno alimentar: 2,1%| Todos os pacientes incluídos<br>tomavam um medicamento para<br>TDAH estavam estáveis por pelo<br>menos 1 mês.<br>`o`<br>MPH: 79 (83,2%)<br>`o`<br>Atomoxetina: 16 (16,8%)<br>`o`<br>Bupropiona: 5<br>`o`<br>Outros (antidepressivos,<br>benzodiazepínicos, insulina e<br>ibuprofeno): 63 (66,3%)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
||||| Todos os pacientes apresentavam abuso de<br>substâncias:<br>`o`<br>Abuso Álcool: TCC Integrado: 31<br>(51,7%) vs. TCC/SUD: 26 (44,1%)|Medicamentos estimulantes para<br>TDAH:<br> Desde o início do estudo|
|Van<br>Emmerik–<br>van et al.,<br>2019<sup>39</sup>|TCC integrada:<br>60<br>TAU/SUD: 60|TCC integrada: 35,4 (8,8)<br>TAU/SUD: 34,7 (9,1)|<br>TCC integrado: 10<br>(16,7%)<br>TAU/SUD: 10<br>(16,9%)|`o`<br>Abuso de Cannabis: TCC Integrado: 15<br>(25,0%) vs. TCC/SUD: 15 (25,4%)<br>`o`<br>Abuso de Estimulantes: TCC<br>Integrado: 12 (20,0%) vs. TCC/SUD:<br>16 (27,1%)<br>`o`<br>Abuso de Opiáceos: 0 (0,0)<br>`o`<br>Outros abusos: TCC Integrado: 2<br>(3,3%) vs. TCC/SUD: 2 (3,4%)|(prescrição inalterada no_Follow-_<br>_up_): TCC Integrado: 4 (6,7%) vs.<br>TCC/SUD: 1 (1,7%)<br> Iniciaram após o tratamento e<br>antes do final do seguimento: TCC<br>Integrado: 2 (3,3%) vs. TCC/SUD:<br>1 (1,7%)|
|Huang et<br>al., 2019<sup>31</sup><br>**(B)**|TCC : 43<br>TCC + Reforço:<br>43|TCC: 26,68 (5,01)<br>TCC + Reforço: 26,23<br>(4,96)|TCC: 13 (30,2%)<br>TCC + Reforço: 18<br>(41,9%)| ≥1 Distúrbio clínico (ansiedade, compulsão<br>alimentar, afetiva): TCC: 20 (46,5%) vs.<br>TCC + Reforço: 20 (46,5%)<br>`o`<br>Transtornos afetivos: TCC + Reforço: 5<br>(11.6%) vs. TCC: 8 (18.6%)<br>`o`<br>Transtornos de ansiedade: TCC: 4<br>(9.3%) vs. TCC + Reforço: 4 (9.3%)<br>`o`<br>Outros: TCC: 0 vs. TCC + Reforço: 1<br>(2.3%)<br> ≥1 Transtorno de personalidade (negativista,<br>dependente, outros): TCC: 14 (32,6%) vs.<br>TCC + Reforço: 12 (27,9%)| Tratamento psicofarmacológico (≥<br>1 medicamento) no_baseline:_<br>TCC: 16 (37,2%) vs. TCC +<br>Reforço: 20 (46,5%)<br>`o`<br>MPH: TCC: 10 (23.3%) vs.<br>TCC + reforço: 9 (20.9%)<br>`o`<br>Atomoxetina: TCC: 5<br>(11.6%) vs. TCC + reforço: 5<br>(11.6%)<br>`o`<br>Antidepressivos: TCC: 3<br>(7.05%) vs, TCC + reforço: 5<br>(11.6%)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|||||`o`<br>Evitação: TCC + Reforço: 2 (4.7%) vs.<br>TCC: 2 (4.7%)<br>`o`<br>Obsessivo-compulsivo: TCC +<br>Reforço: 3 (7.0%) vs. TCC: 3 (7.0%)<br>`o`<br>Negativista: TCC + Reforço: 1 (2.3%)<br>vs. TCC: 1 (2.3%)<br>`o`<br>Outros: TCC + Reforço: 0 vs. TCC: 1<br>(2.3%)||
|Virta et al.,|TCC = 10|TCC: 38,2 [25-49]|TCC: 10| Qualquer comorbidade psiquiátrica<br>(depressão, ansiedade e desordem de| Indivíduos que tomavam<br>medicamento: TCC: 5 MPH<br>(50%) MPH vs. TC: 5 (55,5%)<br>`o`<br>MPH: TCC: 5 (50%) vs. TC:<br>4 (44,4%)|
|2010<sup>32</sup> **(B)**<br>**TCC associa**|TC = 9<br>**do a medicamento**|TC: 32,0 [21-44]<br>**vs. Outras intervenções as**|TC: 9<br>**sociadas a medicamen**|personalidade): TCC: 7 (70%) vs. TC: 4<br>(40%)<br>**to**|`o`<br>Modafinil: TCC: 0 (0%) vs.<br>TC: 1 (11,1%)<br>`o`<br>Atomoxetina: TCC: 0 (0%)<br>vs. TC: 0 (0%)|
|Philipsen et<br>al., 2015<sup>40</sup>|TCC + MPH: 103<br>TCC + PCB: 106<br>CM + MPH: 107<br>CM + PCB: 103|TCC + MPH: 35 (10)<br>TCC + PCB: 35 (11)<br>CM + MPH: 35 (10)<br>CM + PCB: 35 (10)|TCC + MPH = 50<br>(48,5%)<br>TCC + PCB = 48<br>(45,3%)| Pelo menos um tipo de distúrbio clínico no<br>_baseline_(Afetivo, ansiedade, entre outros):<br>TCC + MPH = 35 (34.0%) vs. TCC + PCB<br>= 38 (35.8%) vs. CM + MPH = 38 (35.5%)<br>vs. CM + Placebo = 48 (46.6%)| Medicamentos<br>psicofarmacológicos:<br>`o`<br>**≥1**: TCC + MPH = 44<br>(42.7%) vs. TCC + PCB = 53<br>(50.0%) vs. CM + MPH = 50|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
||||CM + MPH = 53<br>(49,5%)<br>CM + PCB = 58<br>(56,3%)|`o`<br>Afetivo: TCC + MPH: 24 (23.3%) vs.<br>TCC + PCB: 23 (21.7%) vs. CM +<br>MPH: 23 (21.5%) vs. CM + Placebo:<br>36 (35.0%)<br>`o`<br>Ansiedade: TCC + MPH: 17 (16.5%)<br>vs. TCC + PCB: 19 (17.9%) vs. CM +<br>MPH: 20 (18.7%) vs. CM + Placebo:<br>21 (20.4%)<br>`o`<br>Outras: TCC + MPH: 3 (2.9%) vs. TCC<br>+ PCB: 5 (4.7%); vs. CM + MPH: 2<br>(1.9%) vs. CM + Placebo: 6 (5.8%)<br> Pelo menos um tipo de distúrbio de<br>personalidade: TCC + MPH = 22 (21.4%)<br>vs. TCC + PCB = 17 (16.0%) vs. CM +<br>MPH = 16 (15.0%) vs. CM + PCB = 20<br>(19.4%)<br>`o`<br>Esquizoide, paranoico: TCC + MPH: 1<br>(1.0%) vs. TCC + PCB: 0; CM + MPH:<br>0; CM + PCB: 4 (3.9%)<br>`o`<br>Borderline, narcisista: TCC + MPH: 4<br>(3.9%) vs. TCC + PCB: 4 (3.8%) vs.<br>CM + MPH: 7 (6.5%) vs. CM + PCB: 4<br>(3.9%)|(46.7%) vs. CM + PCB = 53<br>(51.5%)<br>`o`<br>Antidepressivos: TCC +<br>MPH: 25 (24.3%); TCC +<br>PCB: 33 (31.1%); CM +<br>MPH: 36 (33.6%); CM +<br>PCB: 31 (30.1%)<br>`o`<br>MPH, anfetamina, outros<br>psicoestimulantes: TCC +<br>MPH: 23 (22.3%); TCC +<br>PCB: 26 (24.5%); CM +<br>MPH: 17 (15.9%); CM +<br>PCB: 24 (23.3%)<br>`o`<br>Sedativos, neurolépticos,<br>atomoxetina, estabilizantes<br>de humor, outros: TCC +<br>MPH: 10 (9.7%); TCC +<br>PCB: 17 (16.0%); CM +<br>MPH: 16 (15.0%); CM +<br>PCB: 17 (16.5%)<br> Tratamentos psiquiátricos ou<br>psicoterapêuticos:<br>`o`<br>Ambulatorial Psiquiátrico:<br>TCC + MPH: 30 (29,1%);<br>TCC + PCB: 38 (35,8%);|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|||||`o`<br>Esquivo, obsessivo-compulsivo,<br>dependente: TCC + MPH: 18 (17.5%)<br>vs. TCC + PCB: 11 (10.4%) vs. CM +<br>MPH: 10 (9.3%) vs. CM + PCB: 13<br>(12.6%)<br>`o`<br>Depressivos, negativistas: TCC +<br>MPH: 3 (2.9%) vs. TCC + PCB: 4<br>(3.8%) vs. CM + MPH: 4 (3.7%) vs.<br>CM + PCB: 4 (3.9%)|CM + MPH: 36 (33,6%); CM<br>+ PCB: 44 (42,7%)<br>`o`<br>Ambulatorial<br>Psicoterapêutico: TCC +<br>MPH: 61 (59,2%); TCC +<br>PCB: 57 (53,8%); CM +<br>MPH: 55 (51,4%); CM +<br>PCB: 50 (48,5%)<br>`o`<br>Ambulatorial psiquiátrico-<br>psicoterapêutico: TCC +<br>MPH: 72 (69,9%) vs. TCC +<br>PCB: 72 (67,9%) vs. CM +<br>MPH: 69 (64,5%) vs. CM +<br>PCB: 68 (66,0%)<br>`o`<br>Não Ambulatorial<br>(Internação): TCC + MPH:<br>23 (22,3%); TCC + PCB: 18<br>(17,0%); CM + MPH: 22<br>(20,6%); CM + PCB: 20<br>(19,4%)<br>`o`<br>1/3 (138/419 [32,9%]) nunca<br>foi submetido a tratamento<br>psiquiátrico ou<br>psicoterapêutico|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|Safren et al.,<br>2010<sup>41</sup>|<br>TCC + MED: 43<br>Relaxamento<br>com Suporte<br>Educacional +<br>MED: 43|TCC + MED: 42,3 (10,3)<br>Relaxamento com<br>Suporte Educacional +<br>MED: 44 (12,3)|TCC + MED: 19<br>(44,2%)<br>Relaxamento com<br>Suporte Educacional<br>+ MED: 19 (44,2%)|NR<br>Critério de exclusão| Tratamento baseado em<br>estimulantes:<br>`o`<br>Monoterapia: TCC + MED:<br>27 (62,8) vs. Relaxamento<br>com Suporte Educacional +<br>MED: 25 (58,1)<br>`o`<br>Duoterapia: TCC + MED: 6<br>(14) vs. Relaxamento com<br>Suporte Educacional + MED:<br>7 (16,3)<br>`o`<br>Bupropiona + estimulante:<br>TCC + MED: 6 (14) vs.<br>Relaxamento com Suporte<br>Educacional + MED: 5<br>(11,6)<br>`o`<br>Atomoxetina + estimulante:<br>TCC + MED: 1 (2,3) vs.<br>Relaxamento com Suporte<br>Educacional + MED: 1 (2,3)<br> Tratamento não estimulante:<br>`o`<br>Apenas bupropiona: TCC +<br>MED: 2 (4,7) vs.<br>Relaxamento com Suporte<br>Educacional + MED: 3 (7)|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
||||||`o`<br>Bupropiona + modafanil:<br>TCC + MED: 0 vs.<br>Relaxamento com Suporte<br>Educacional + MED: 1 (2,3)<br>`o`<br>Apenas atomoxetina: TCC +<br>MED: 0 vs. Relaxamento<br>com Suporte Educacional +<br>MED: 1 (2,3)<br>`o`<br>Atomoxetina + bupropiona:<br>TCC + MED: 1 (2.3) vs.<br>Relaxamento com Suporte<br>Educacional + MED: 0|
|Vidal et al.,<br>2013<sup>42</sup>|Psicoeducação:<br>17<br>TCC: 15<br>Apenas 26<br>completaram o<br>seguimento|Psicoeducação: 39,53<br>(5,91)<br>TCC: 39,40 (9,30)|Psicoeducação: 11<br>(64,7%)<br>TCC: 6 (40%)| Não especifica<br>`o`<br>Critérios de exclusão: histórico de<br>abuso de substâncias (últimos 6 meses)<br>ou outros distúrbios (atual) do eixo I ou<br>II do DSM-IV.<br>`o`<br>Foram incluídos pacientes com<br>sintomas significativos de depressão e<br>ansiedade que não cumpriram os<br>critérios de transtornos afetivos<br>medidos pela Entrevista Clínica<br>Estruturada (SCID-I).| Todos os pacientes estavam em<br>tratamento psicofarmacológico<br>estável (por 2 meses):<br>`o`<br>MPH: 81.3%;<br>Psicoeducação: 13 (76.47%)<br>vs. TCC: 13 (86.66%)<br>`o`<br>Atomoxetina: 15.6%;<br>Psicoeducação: 3 (17.64%)<br>vs. TCC: 2 (13.33%)<br>`o`<br>Bupropiona: 3.1%;<br>Psicoeducação: 1 (5.88%) vs.<br>TCC: 0|  
|**Autor e**<br>**Ano**|**Amostra**|**Média de idade (DP)**|**Sexo F (%)**|**Comorbidades**|**Tratamento prévio**|
|---|---|---|---|---|---|
|||||`o`<br>Foram incluídos pacientes com||
|||||histórico de comorbidade psiquiátrica,||
|||||desde que os sintomas estivessem<br>estabilizados no momento do estudo.||  
**Legenda:** EC: Ensaio Clínico; DP: Desvio Padrão; n: número da amostra; IQR: Intervalo Interquartil; TC: Treinamento cognitivo, MPH: metilfenidato; CM: tratamento clínico individual; PCB: Placebo; NR: não relatada. a O estudo não estratifica as características dos participantes por grupo  
b A estabilização dos medicamentos foi definida como uma alteração não superior a 10% na dose do medicamento ao longo de um período de dois meses, com evidências clínicas de melhora em comparação com o status não medicado dos pacientes  
**Tabela H -** Desfechos de eficácia dos estudos que avaliaram TCC em crianças e adolescentes  
|**Estudo**<br>**Sintomas de**<br>**TDAH**|**Comprometimento**<br>**Funcional**|**Desatenção**|**Hiperatividade**<br>**Impulsividade**|**Ansiedade**|**Depressão**|**Qualidade**<br>**de Vida**|**Outros**|
|---|---|---|---|---|---|---|---|
|**TCC em grupo Vs. Cuidados**|**usuais**|||||||
|**Vidal, 2015**<br>N=119,idade: 15 a 21 anos<br>_ADHD-RS_<br>a. Autoavaliação:<br>ES: 7,56 (IC95%: -<br>9,56 a -5,36; d: 7,5);<br>Cohen’s d: 7.5; p <<br>0.001<br>b. Avaliado pelos<br>pais: ES: -9,11<br>(IC95%: -11,48 a -<br>6,75, d: 8,38);<br>Cohen’s d: 8.38;<br>p<0.001|_CGI-S _<br>a. Autoavaliação:<br>ES: -0,68 (IC95%: -0,98 a -<br>0,39; d: 3,75); Cohen’s d:<br>3.75; p < 0.001<br>_b._Avaliado pelo clínico: ES: -<br>0,79 (IC95%: -0,95 a -0,62;<br>d:7,71); Cohen’s d: 7.71; p <<br>0.001<br>_WFIRS_ [avaliado pelos pais]:<br>ES: 4,02 (IC95%: -7,76 a -<br>0,29; d: 2,29); Cohen’s d:<br>2.29; p < 0.05<br>_GAF_:[avaliador]<br>ES: - 7,58 (IC95%: -9,1 a -<br>6,05; d: 7,51); Cohen’s d:<br>7.51; p<0.001|NR|NR|_STA_I<br>Cohen’s d:<br>0.35 (NS)|_BDI_<br>F(4.15) =<br>22,02;<br>p=0,000;<br>Cohen’s d:<br>0.0 (NS)|NR|Melhora dos sintomas<br>_(CGI-I)_<br>a. CGI-I auto relatado:<br>F (9.21): 0,001; p=0,000; Cohen’s d:<br>3.75; p<0.001<br>b. CGI-I avaliado pelo clínico:<br>F (13.02): 2,45; p=0,000; Cohen’s d:<br>7.71; p<0.001<br>Expressão de raiva<br>_(STAXI-2)_<br>a. STAXI estado: F(2,4) = 4,58; p =<br>0,03; Cohen’s d: 0.36 (NS)<br>b. STAXI traço:  F(2.5) = 4,16;<br>p=0,04; Cohen’s d: 0.1 (NS)<br>c. STAXI expressão:  F (3.34) = 9,89;<br>p=0,002; Cohen’s d: 0.08 (NS)|
|**TCC em grupo Vs. Outra int**|**ervenção não farmacológica**|||||||  
|**Estudo**<br>**Sintomas de**<br>**TDAH**|**Comprometimento**<br>**Funcional**|**Desatenção**|**Hiperatividade**<br>**Impulsividade**|**Ansiedade**|**Depressão**|**Qualidade**<br>**de Vida**|**Outros**|
|---|---|---|---|---|---|---|---|
|**Banaschewski, 2001**<br>N=12,idade: 7 a 10 anos<br>NR|NR|NR|NR|NR|NR|NR|Habilidades sensório-motoras:<br>SIPT: t8= 0,56, ns<br>Avaliação cognitiva<br>MFFT<br>a.Score de impulsividade: t8 = 1,52, p<br><0,09<br>b.Erros totais: t8=2.05, p = 0,04;<br>c.Impulso cognitivo: t, =2.93, p <<br>0,01<br>Psicopatologia/ Comportamento<br>infantil<br>a. ASQ geral: t8, = 2,01, p <0,04<br>_b. ASQ_agressivo: t8, = 1,65, p <0,07<br>_c. ASQ_sintomas ansiosos/<br>depressivos: t8 = 1,81, p <0,0|
|**TCC associado a terapia fa**|**miliar Vs. Cuidados usuais**|||||||  
|**Estudo**<br>**Sintomas de**<br>**TDAH**|**Comprometimento**<br>**Funcional**|**Desatenção**|**Hiperatividade**<br>**Impulsividade**|**Ansiedade**|**Depressão**|**Qualidade**<br>**de Vida**|**Outros**|
|---|---|---|---|---|---|---|---|
|**Sprich, 2016**<br>N= 46,idade: 4 a 18 anos<br>NR<br>**TCC associado a terapia fa**|_CGI_<br>ES: 1,17 (IC 95%: 1,39, .94; p<br>< .0001)<br>_ARS [avaliador)_<br>a. Resultado dos Pais: ES:<br>10,93 (IC 95%: 12,93, 8,93; p<br>< .0001)<br>b. Resultados dos<br>Adolescentes:<br>ES: 5,24 (IC 95%: 7,21, 3,28;<br>p < .0001)<br>**miliar Vs. Outra intervenção não**|NR<br>**farmacológica**|NR<br>|NR|NR|NR|Status de resposta categórico<br>Redução de 30% na escala de<br>classificação do TDAH<br>a. Dados do relatório dos pais:<br>TCC: 18/36 (50%) vs. lista de espera:<br>4/22 (18%); [x2 (1) = 8,98, p =0.00].<br>b. Dados dos adolescentes:<br>TCC: 21/36 (58%) vs. lista de espera:<br>4/22 (18%); [x2 (1) = 5,87, p =0.02)|  
|**Estudo**|**Sintomas de**<br>**TDAH**|**Comprometimento**<br>**Funcional**|**Desatenção**|**Hiperatividade**<br>**Impulsividade**|**Ansiedade**|**Depressão**|**Qualidade**<br>**de Vida**|**Outros**|
|---|---|---|---|---|---|---|---|---|
|**91**<br>13 anos|||BPC-AP:<br>Avaliado<br>pelos pais:<br>F: 1,49; df<br>1,68,|||||Autocontrole<br>SCRS:<br>Avaliado pelos pais:<br>F: 2,16; df 1,67; p>0,05<br>Avaliado pelos professores:<br>F: 1,41; df 1,68; p<0,24<br>Atividade da criança em casa|
|**Fehlings, 19**<br>N=25;idade: 7 a|NR|NR|p>0,05<br>Avaliado<br>pelos<br>professores:<br>F: 3,78; df<br>1,68;<br>p<0,056|NR|NR|NR|NR|MWWAS: F: 4,7; df 1,68; p<0,03<br>Avaliação cognitiva(autorrelato)<br>a. MFFT latência: F: 0,94; df 1,68;<br>p>0,05<br>b. MFFT erros totais: F: 0,34; df<br>1,68; p>0,05<br>Autoconceito<br>PHSCS: F: 4,62; df 1,67; p<0,035|  
**Tabela I** - Desfechos de eficácia dos estudos que avaliaram TCC em adultos para TDAH  
|**Estudo**|**Sintomas de TDAH**|**Comprometim**<br>**ento Funcional**|**Desatenção**|**Hiperatividade**<br>**Impulsividade**|**Ansiedade**|**Depressão**|**Qualidade de Vida**|**Outros**|
|---|---|---|---|---|---|---|---|---|
|**TCC vs. L**|**ista de espera**||||||||
|**Huang, 2019**<br>N=108, idade: 18 a 65|ADHD-RS total<br>12sem:<br>ES: 0.46 [IC95%:<br>−0.06 a 0.98],<br>p=0.003<br>ADHD-RS score:<br>Tx de resposta ao<br>tratamento foi de<br>60.6% (20/33) no<br>grupo TCC vs. 18.8%<br>(3/16) no grupo<br>controle<br>_CAARS(_frequência)<br>12sem:<br>Escore total: ES: 0.23<br>[IC95%: −0.29 a<br>0.74], p=0.085<br>CAARS sintomas:<br>ES: 0.20 [IC95%:<br>−031 a 072]|NR|ADHD-RS<br>desatenção:<br>12sem:<br>ES: 0.73<br>[IC95%: 0.20<br>a 1.26],<br>p=0.005<br>ADHD-RS<br>desatenção:<br>24sem:<br>ES: −0.12<br>[IC95%:<br>−0.54 a 0.30],<br>p=0.218|ADHD-RS<br>impulsividade e<br>imperatividade:<br>12sem:<br>ES: −0.08 [IC95%<br>−0.60 a 0.43],<br>p=0.031<br>_BIS_<br>12sem<br>a. BIS Fator de<br>atenção<br>ES: 0.15 [IC95%<br>−0.36 a 0.67],<br>p=0.248<br>b. BIS Fator motor<br>ES: 0.24 [IC95%<br>−0.28 a 0.75], p=<br>0.045<br>c. BIS Fator de não|_SAS_<br>12sem:<br>ES: 0.20 [IC95%<br>−0.31 a 0.72], p=<br>0.212<br>_SAS_<br>24sem:<br>ES: −0.01 [IC95%<br>−0.44 a 0.14],<br>p=0.712|_SDS_<br>12sem:<br>ES: 0.16<br>[IC95% −0.36<br>a 0.67],<br>p=0.752<br>_SDS_<br>24sem:<br>ES: −0.11<br>[IC95% −0.53<br>a 0.31],<br>p=0.685|**Domínio Físico:**<br>ES: 0.05 [IC95% −0.47<br>a 0.56], p=0.621<br>b. Domínio psicológico:<br>ES: −0.34 [IC95% −0.86<br>a 0.18], p=0.170<br>**Domínio social:**<br>ES: −0.15 [IC95% −0.66<br>a 0.36], p=0.640<br>**Domínio**<br>**comportamental**:<br>ES: −0.36 [IC95% −0.88<br>a 0.15], p= 0.362<br>_WHOQOL-BREF_<br>24sem:<br>**Domínio Físico:**<br>ES: −0.11 [IC95%<br>−0.53, 0.31], p=0.702<br>**Domínio psicológico:**|Autoestima<br>_SES_<br>12sem: ES: 0.06 [IC95%<br>−0.45 a 0.58], p=0.594<br>_SES_<br>24sem: ES: −0.15 [IC95%<br>−0.57 a 0.27], p=0.504<br>Funcionamento executivo<br>e autorregulação no<br>ambiente cotidiano<br>_BRIEF-A _<br>_12 sem_<br>ES: 0.14 (-0.28, 0.57),<br>p=0.141<br>_BRIEF-A _<br>24sem<br>ES:-0.18 (-0.61, 0.24),<br>p=0.065|
||.  .,<br>p=0.065|||planejamento|||ES: −0.07 [IC95%<br>−0.49, 0.36], p=0.441|Planejamento<br>espacial,<br>memória e atenção|  
||CAARS índex: ES:<br>0.23 [IC95%: −0.28 a<br>0.75], p=0.130|||ES: −0.65 [IC95%<br>−0.58 a 0.45],<br>p=0.592<br>d. BIS Pontuação<br>total<br>ES: 0.11 [−0.40,<br>0.62], p=0.187||**Domínio social:**<br>ES: −0.42 [IC95%<br>−0.85, 0.007], p= 0.320<br>**Domínio**<br>**comportamental:**<br>ES: −0.26 [IC95%<br>−0.69, 0.16], p=0.151|_CANTAB (12 sem)_<br>_Total misses_<br>ES: -0.20 (-0.82, 0.42)<br>_Probability of hits_<br>ES: -0.21 (-0.83, 0.41)|
|---|---|---|---|---|---|---|---|
|**Virta, 2010**<br>N=29 pacientes, idade: 18 e 49|_BADDS_(autorrelato)<br>a. BADDS escore<br>total: F<br>(1,18)=6.32, P <<br>0.05; ηp2 = 0.26<br>b. BADDS ativação:<br>p > 0,10<br>c. BADDS esforço: p<br>> 0,10<br>d. BADDS afeto: p ><br>0,10<br>e. BADDS memória:<br>F<br>(1,18)=6.32, P <0.05;<br>ηp2 = 0.26|_CGI_(avaliador)<br>χ2 = 3,20, df =<br>1, P = 0,07|BADDS<br>atenção:<br>F (1,18) =<br>7.24, P <<br>0.05; ηp2 =<br>0.29|NR|NR<br>_BDI-II_<br>(autorrelatado)<br>: p> 0,10|Q-LES-Q(autorrelato)<br>F (1,11) = 4,28, P= 0,06;<br>ηp2 = 0.28|SCL-90(autorrelatado):<br>p> 0,10<br>CNSVS: p> 0,10|
||ARSR(avaliador)<br>F  (1,18) = 1,67, P =<br>ns; ηp2 = 0.09; não|||||||  
|**TCC asso**|houve interação<br>estatística<br>**ciado a medicamento v**|**s. Cuidados**|**usuais associado a med**|**icamento**||||
|---|---|---|---|---|---|---|---|
|**Corbisiero,**2018<br>N=43, idade: 18 a 49|ADHD-SR<br>(autorrelato)<br>F(3, 96)= 0,67 (η<sup>2</sup>=<br>0,021)|NR|ADHD-SR<br>(Subscala<br>atenção):<br>F(3, 96)= 0,51<br>(η<sup>2</sup>= 0,016)|ADHD-SR<br>(Subscala<br>Hiperatividade):<br>F(3, 96)= 0,69 (η<sup>2</sup>=<br>0,021)<br>ADHD-SR<br>(Subscala<br>Impulsividade):<br>F(3, 96)= 1,39 (η<sup>2</sup>=<br>0,042)|NR<br>NR|NR|Sintomas emocionais:<br>F(3, 96)= 0.88 (η<sup>2</sup>= 0.027)<br>Fator de<br>comprometimento 1<br>F(3, 72)= 0,18 (η<sup>2</sup>= 0,007)<br>Fator de<br>comprometimento 2<br>F(3, 72)= 0,56 (η<sup>2</sup>= 0,023)|  
|**Dittner, 2017**<br>N=60; idade: 18 a 65 anos|CSS<br>30<sup>a</sup>sem (final tto):<br>DMA= -10,2<br>IC95% -14,25 a -10,2<br>AES*= -1.52, P<br><0.001<br>42<sup>a</sup>sem (final_Follow-_<br>_up_):<br>DMA= -8,8<br>IC95% -13,1 a -4,6<br>AES*= -1.31, P<br><0.001|WSAS<br>30<sup>a</sup>sem (final<br>tto):<br>DMA= -6,6<br>IC95% -10,4 a -<br>2,8<br>AES*= - 0.82, P<br>= 0.002<br>42<sup>a</sup>sem (final<br>_Follow-up_):<br>DMA= -6,6<br>IC95% -10.3 a -<br>3.0<br>AES*= - 0.82, P<br>= 0.003|NR|NR|HADS<br>30<sup>a</sup>sem (final tto):<br>DMA= -2,21<br>IC95% -3,89 a -<br>0,52<br>AES*= - 0.62, P =<br>0.015<br>42<sup>a</sup>sem (final<br>_Follow-up_):<br>DMA= -2,3<br>IC95%: -3,9 a -0,6<br>AES*=- 0.6, P =<br>0.012|HADS<br>30<sup>a</sup>sem (final<br>tto):<br>DMA= - 2,04<br>IC95% -3,46 a<br>-0,63<br>AES*= -0.61,<br>P = 0006<br>42<sup>a</sup>sem (final<br>_Follow-up_):<br>DMA = - 2,2<br>IC95%-3,6 a-<br>0,8<br>AES*= -0.66,<br>P = 0.002|NR<br>Bem estar psicológico<br>CORE-OM<br>30<sup>a</sup>sem (final tto):<br>DMA= -9,77; IC95% -<br>18,49 a -1,03<br>AES*= -0.52<br>42<sup>a</sup>sem (final_Follow-up_):<br>DMA = -9,8; IC95% -18,3<br>a -1,3<br>AES*= -0.52<br>Melhora (autoavaliada)<br>CGI<br>30<sup>a</sup>sem (final tto):<br>OR= 41,6; IC95% 0,9 a<br>2005<br>42<sup>a</sup>sem (final_Follow-up)_<br>OR=23,1; IC95% 2,8 a<br>1089; P<0.001<br>Satisfação (autoavaliada)<br>CGI<br>30<sup>a</sup>sem (final tto):<br>OR= 35,0; IC95% 0,4 a<br>429<br>42<sup>a</sup>sem (final_Follow-up_):|
|---|---|---|---|---|---|---|---|  
|||||||||OR=23,2; IC95% 4,1 a<br>190,2; P<0.001|
|---|---|---|---|---|---|---|---|---|
||_BCS_total<br>[autorrelato]<br>Após tto:<br>Cohen's d: 0,76;<br>F(1,32)=10,45,<br>p<0,01<br>_Follow-up_após 3<br>|_K-SADS-PL_<br>_[_avaliador]<br>Após tto:<br>Cohen's d: 1,03;<br>F(1,31)=11,02,<br>p<0,01<br>_Follow-up_após<br>3|BCS<br>desatenção<br>[autorrelato]<br>Após tto:<br>Cohen's d:|BCS<br>hiperatividade/<br>impulsividade<br>[autorrelato]|_BAI_<br>Aó tt|_BDI_<br>Após tto:<br>Ch' d  =|NR|Controle emocional<br>RATE-S Controle<br>emocional<br>Após tto:<br>Cohen's d p = 0,48<br>_Follow-up_após 3 meses:<br>Cohen's d 1,12;<br>F(1,28)= 6.35, p < 0,05)<br>Comportamento<br>antissocial|
|**Emilsson, 2011**<br>N=54; idde:18 e 65|meses:<br>Cohen's d: 1,08;<br>F(1,29)=17,36,<br>p<0,001<br>RATE-S Sintomas de<br>TDAH:<br>Após tto:<br>Cohen's d p = 0,16<br>_Follow-up_após 3<br>meses:<br>Cohen's d: 1,08;<br>F(1,28)= 11.83, p <<br>0,01|meses:<br>Cohen's d: 1,17;<br>F(1,18)=7,60,<br>p<0,05<br>CGI:<br>Após tto:<br>Cohen's d p =<br>0,06<br>_Follow-up_após<br>3 meses:<br>Cohen's d: 1,31;<br>F(1,18)=9,16,<br>p<0,05|0,94 F(1,32)<br>= 8,73,<br>p<0,05<br>_Follow-up_<br>após 3 meses:<br>Cohen's d:<br>1,15<br>F(1,29)=10,7<br>0, p<0,01|Após tto:<br>Cohen's d: 0,32<br>F(1,32)=7,27;<br>p<0,05<br>_Follow-up_após 3<br>meses:<br>Cohen's d: 0,58<br>F(1,29)=20,30,<br>p<0,001|ps o:<br>Cohen's d p = 0,46<br>_Follow-up_após 3<br>meses:<br>Cohen's d: 0,83;<br>F(1,29)=4,61,<br>p<0,05|oens  p<br>0,052<br>_Follow-up_<br>após 3 meses:<br>Cohen's d:<br>1,32;<br>F(1,29)=5,86,<br>p<0,05||RATE-S comportamento<br>antissocial:<br>Após tto:<br>Cohen's d: 0,84<br>F(1,31) = 4.75, p<0,05<br>_Follow-up_após 3 meses:<br>Cohen's d: 0,89<br>F(1,29)=7.28, p < 0,05<br>Funcionamento Social<br>RATE-S<br>funcionamento<br>social:<br>Após tto:<br>Cohen's d: p =0,09<br>_Follow-up_após 3 meses:<br>Cohen's d: 1,24|  
|||||||||F(1,28)=10.88, p < 0,01|
|---|---|---|---|---|---|---|---|---|
|||||||||Avaliação<br>Processo<br>Terapêutico<br>RATE-S total:<br>Após tto:<br>Cohen's d p =0,07<br>_Follow-up_após 3 meses:<br>Cohen's d: 1,46<br>F(1,28)=14,77, p<0,001|
|**Safren, 2005**<br>**N=**31, idade: 18 a 65|_CSS_ [autorrelato]<br>F (1; 28) = 22:76;<br>p<0,0001; ES: 1,7|ARS[avaliador]<br>F (1; 28) = 8,72;<br>p<0,01; ES: 1,2<br>CGI[avaliador]<br>F (1; 28) =<br>12,95; p<0,002;<br>ES: 1,4<br>Resposta ao tto:<br>TCC + MED:<br>9/16 (56%) vs.<br>MED: 2/15<br>(13%)<br>X<sup>2</sup>(1) = 6,23;<br>p<0,02;<br>ES: 1,2|NR|NR|HAM-A<br>[avaliador]<br>F (1; 28) = 4,82;<br>p<0,04; ES=0,55<br>BAI[autorrelato]<br>F (1; 28) = 5,00;<br>p<0,04; ES=0,43|HAM-D<br>[avaliador]<br>F (1; 28) =<br>8,72; p<0,01;<br>ES=0,65<br>BDI<br>[autorrelato]<br>F (1; 28) =<br>3,84; p= 0,06;<br>ES=0,39|NR|NR|  
|**Young, 2015**<br>N= 95 ≥ 18 anos|_K-SADS_<br>Total: ES: −5.4; p<br><0.001, IC95%:<br>−7.43 a −3.38<br>_CSS_(autorrelato):<br>Combinada: ES:<br>−6.60; p<0.001;<br>IC95%: −9.19 a<br>−3.99|_CGI_<br>ES: −0.79; p<br><0.001; IC95%:<br>−1.12 a −0.46|_K-SADS_<br>_desatenção_<br>ES: −3.2; p<br><0.001;<br>IC95%: −4.6<br>a −1.84<br>_CSS_<br>_desatenção_<br>ES: −3.63;<br>p<0.001;<br>IC95%:<br>−5.21 a −2.06|_K-SADS_<br>hiperatividade/<br>impulsividade<br>ES: −2.11; p<br><0.001; IC95%:<br>−3.29 a −0.93<br>_CSS_<br>_hiperatividade/_<br>_impulsividade_<br>ES: −3.10;<br>p<0.001; IC95%:<br>−4.50 a −1.63|_BAI_(autorrelato):<br>ES: −3.11; p=<br>0.071; IC95%:<br>−6.49 a 0.26<br>Z = -2,53, p =<br>0,011, d = 0,58|_BDI_<br>ES: −4.84; p=<br>0.001; IC95%:<br>−7.79 a −1.89<br>Z = -2,2, p =<br>0,025, d =<br>0,52|_QOLS_<br>ES: 3.36; p=0.180;<br>IC95%: −1.55 a 8.26<br>Z = 2,47, p = 0,014, d =<br>0,56|NR|
|---|---|---|---|---|---|---|---|---|
|||||||||Resultados funcionais e<br>Satisfação com a vida|
|||||||||RATE-S|
||_RATE-S _sintomas de|||||||_a. Score_composto:|
||TDAH|||||||β=-16,98 (EP: 4,04),|
|**Yo\ung, 2017**<br>N= 95 ≥ 18 anos|β=-5,64 (EP: 1,58),<br>p<0,001 (IC 95%<br>−8,75 a -2,53); d=<br>0,55<br>t(89) = 0.563, p =<br>0.575|_GCI_<br>t(90) = 0.231, p<br>= 0.818|NR|NR|NR|NR|NR|p<0,001 (IC 95% -24,90 a<br>-9,06); d= 0,54<br>t(89) = − 0.452, p = 0.652<br>_b. RATE-S_controle<br>emocional:<br>β=-4,61 (EP: 1,92),<br>p=0,017 (IC 95% −8,38 a<br>-0,84); d= 0,32|
|||||||||t(89) = − 0.515, p = 0.608|  
|**TCC vs. I**|**ntervenções nã**|**o medicamentosas**||||||_c. RATE-S_comportamento<br>antissocial:<br>β=-1,4 (EP: 0,43),<br>p=0,001 (IC 95% -2,24 a -<br>0,56); d= 0,50<br>t(89) = − 0.929, p = 0.355<br>_d. RATE-S_funcionamento<br>social:<br>β=-5,31 (EP: 1,48),<br>p<0,001 (IC 95% −8,21 a<br>-2,41); d= 0,41<br>t(89) = − 0.857, p = 0.394|
|---|---|---|---|---|---|---|---|---|
|**van Emmerik-van , 2019**<br>N=119, idade: 18 e 65|NR|_ARS_<br>Pós tto:<br>Cohen’s d =<br>0,34;<br>F = 4,739, df =<br>1,282, p = 0,030<br>_Follow-up_<br>(após 2 meses)<br>Cohen’s d =<br>0,30<br>F= 3,165, df =<br>1,282, p = 0,076|NR|NR|_BAI_(autorrelato)<br>Pós tto:<br>Cohen’s d p= 0.782<br>_Follow-up_(após 2<br>meses)<br>Cohen’s d p= 0.906|_BDI_<br>(autorrelato)<br>Pós tto:<br>Cohen’s d p=<br>0.366<br>_Follow-up_<br>(após 2 meses)<br>Cohen’s d p=<br>0.612|_EQ-5D_ (autorrelato)<br>Pós tto:<br>Cohen’s d p= 0.564<br>_Follow-up_(após 2<br>meses)<br>Cohen’s d p= 0.536|Resposta ao tratamento<br>≥ 30% de redução dos<br>sintomas na ARS<br>Pós tto:<br>OR = 1,58; IC 95% 0,64–<br>3,90<br>NNT: 11,1<br>_Follow-up_(após 2 meses)<br>OR = 2,05; IC 95% 0,77-<br>5,50<br>NNT: 7,1|  
||_BADDS_(autorrelato)<br>a. BADDS escore<br>total: F (1,17) =|||||||SCL-90(autorrelatado):<br>p> 0,10<br>SCL-16** [F(1,17) = 4.20,|
|---|---|---|---|---|---|---|---|---|
||4,20, P = 0,06, ηp2 =<br>0,20|||||||P = 0.06, ηp2 = 0.20]|
|e 49|b. BADDS ativação:||BADDS|||||CNSVS: p> 0,10; não há|
|**irta, 2010 (B)**<br>ientes, idade: 18|p> 0,10<br>c. BADDS esforço: p<br>> 0,10<br>d. BADDS afeto: p >|_CGI_(avaliador)<br>χ2 = 4,34, df =<br>1, P <0,05|atenção<br>(autorrelato)<br>F (1,17) =<br>3,12, P =|NR|NR|_BDI-II_<br>(autorrelatado)<br>: p> 0,10|Q-LES-Q(autorrelato)<br>p> 0,10|interação estatística<br>significativa|
|**V**<br>pac|0,10||0,09, ηp2 =|||||******um escore de soma de|
|N=29|e. BADDS memória:<br>p> 0,10||0,15|||||16 itens (SCL-16),<br>refletindo as<br>características|
||ARSR(avaliador)|||||||proeminentes do TDAH,|
||F (1,17) = 2,52, P =|||||||foi calculado a partir do|
||ns, ηp2 = 0,13|||||||SCL-90.|
||ADHD-RS total||ADHD-RS|ADHD-RS||_SDS_|_WHOQOL-BREF_|Autoestima|
|<br>65|<br>24sem: ES: −005||desatenção:|impulsividade e|_SAS_|24sem:|24sem:|_SES_|
|**(B)**<br>8 a|.<br>||24sem:|imperatividade:|24sem:|<br>|Domínio Físico:|24sem: ES: −0.15 [IC95%|
|**019**<br>de: 1|[IC95%: −0.48,<br>037 0355|–|ES: −0.12|24sem:|ES: −0.01 [IC95%|ES: −0.11<br>IC95% −053|ES: −0.11 [IC95%|−0.57 a 0.27], p=0.504|
|**Huang, 2**<br>N=108, ida|.]; p=.<br>_CAARS(_frequência)<br>24sem:||[IC95%:<br>−0.54 a 0.30],<br>p=0.218|ES: 0.11 [IC95%<br>−0.32 a 0.53],<br>P=0.484|−0.44 a 0.14],<br>p=0.712|[ .<br>a 0.31],<br>p=0.685|−0.53, 0.31], p=0.702<br>b. Domínio psicológico:<br>ES: −0.07 [IC95%<br>−0.49, 0.36], p=0.441|Funcionamento executivo<br>e autorregulação no<br>ambiente cotidiano<br>_BRIEF-A _|  
|**TCC asso**|Escore total: ES:<br>−0.13 [IC95%: −0.56<br>a 0.29], p=0.223<br>CAARS sintomas:<br>ES: −0.004 [IC95%:<br>−0.43 a 0.42],<br>p=0.243<br>CAARS índex: ES:<br>−0.35 [IC95%: −0.78<br>a 0.08], p=0.479<br>**ciado a medicamento vs**|**. Outras intervenç**|**ões associadas a**|_BIS_<br>24sem:<br>a. BIS Fator de<br>atenção<br>ES: −0.35 [−0.77,<br>0.08], p=0.430<br>b. BIS Fator motor<br>ES: −0.05 [−0.47,<br>0.37], p=0.541<br>c. BIS Fator de não<br>planejamento<br>ES: 0.30 [−0.12,<br>0.73], p= 0.575<br>d. BIS Pontuação<br>total<br>ES: −0.01 [IC95%<br>−0.43 a 0.41],<br>p=0.35<br>**medicamento**||c.<br>Domínio social:<br>ES: −0.42 [IC95%<br>−0.85, 0.007], p= 0.320<br>d.<br>Domínio<br>comportamental:<br>ES: −0.26 [IC95%<br>−0.69, 0.16], p=0.151|24sem<br>ES:-0.18 (-0.61, 0.24),<br>p=0.065|
|---|---|---|---|---|---|---|---|
|**Philipsen, 2015**<br>N=433, idade: 18 a 60|CARRS<br>ADHD Index<br>3 meses<br>Observador: MD: -<br>0,6; IC95%: -2,2 a<br>0,9; P = 0,43<br>_CAARS_<br>ADHD Index|_CGI_<br>12sem do tto<br>intensivo<br>a. CGI -<br>Gravidade: OR:<br>0.94 (IC95%<br>0.64 a 1.39), p =<br>0,76|CAARS-<br>problemas de<br>desatenção/<br>memória<br>3 meses<br>MD: 0.8<br>(IC95% −0.4|CAARS–<br>hiperatividade/<br>inquietação<br>3 meses<br>MD: 0.4 (IC95%<br>0.7 a 1.6), p = 0,47|NR<br>_BDI_<br>12sem do tto<br>intensivo<br>MD: 0.4<br>(IC95% −0.8 a<br>1.6), p = 0,54|NR|CAARS-problemas com<br>o autoconceito<br>3 meses<br>MD: 0.3 (IC95% -0.4 a<br>1.0), p = 0,41<br>24sem (manutenção)|  
|3 meses|b. CGI -|a 2.0), p =|24sem|24sem|MD: 0.3 (IC95% −0.5 a|
|---|---|---|---|---|---|
|Autorrelato: MD: 1.1|Mudança|0,18|(manutenção)|(manutenção)|1.1), p = 0,49|
|(IC95% 0.0 a 2.2), p|Global:||MD: −0.1 (IC95%|MD: 0.0||
|= 0,06|OR: 0.71|24sem|−1.3 a 1.2), p =|(IC95% −1.4 a|52sem (final do tto)|
||(IC95% 0.48 a|(manutenção)|0,92|1.4), p > 0,99|MD: −0.3 (IC95% −1.1 a|
|12sem do tto|1.05), p = 0,08|MD: 0.4|||0.5), p = 0,49|
|intensivo|c. CGI -|(IC95% −0.9|52sem (final do tto)|52sem (final||
|Autorrelato: MD: 1.0|Avaliação|a 1.7), p =|MD: −0.3 (IC95%|do tto)||
|(IC95% −0.2 a 2.2), p|global da|0,56|−1.6 a 1.0), p =|MD: −0.7||
|= 0,09|eficácia: OR:||0,68|(IC95% −2.2 a||
|Observador: OR:|2.22 (IC95%|52sem (final||0.7), p = 0,31||
|0.55 (IC95% 0.35 a|1.50 a 3.28), p <|do tto)|CAARS-|||
|0.86; p=0.009|0,001|MD: −0.8<br>(IC95% −2.1|impulsividade e<br>labilidade|||
|24sem (manutenção)|24sem|a 0.5), p =|emocional|||
|Autorrelato: MD: 0.7|(manutenção)|0,21|3 meses|||
|(IC95% −0.5 a 1.9), p|a- CGI -||MD: 1.4 (IC95%|||
|= 0,23|Gravidade: OR:||0.2 a 2.6), p = 0,02|||
|Observador: MD: 0.5|1.03 (IC95%|||||
|IC95% (0.6 a 1.7), p|0.68 a 1.56), p =||24sem|||
|= 0,36|0,87||(manutenção)|||
|OR: 0.71 (IC95%:|b- CGI -||MD: 0.5 (IC95%|||
|0.44 a 1.12); p=0.14|Mudança<br>Global: OR:||−0.9 a 1.8), p =<br>0,50|||
|52sem (final do tto)|0.74 (IC95%|||||
||0.48 a 1.13), p =<br>0,16||52sem (final do tto)|||  
|Autorrelato: MD:|c- CGI -|MD: −0.8 (IC95%|
|---|---|---|
|−0.4 (IC95% −1.7 a|Avaliação|−2.0 a 0.5), p =|
|0.9), p = 0,56|global da|0,23|
|Observador: MD:|eficácia: OR:||
|−0.4 (IC95% −1.6 a|1.99 (IC95%||
|0.8), p = 0,56<br>OR: 0.91 (IC95%:<br>0.54 a 1.53); p=0.72|1.30 a 3.04), p =<br>0,001<br>52sem (final do<br>tto)<br>a- CGI -<br>Gravidade: OR:<br>0.75 (IC95%<br>0.47 a 1.20), p =<br>0,23<br>b- CGI -<br>Mudança<br>Global: OR:<br>0.62 (IC95%<br>0.38 a 0.99), p =<br>0,047<br>c- CGI -<br>Avaliação<br>global da<br>eficácia: OR:||
||2.72 (IC95%||  
|||1.67 a 4.45), p <<br>0,001|||||||
|---|---|---|---|---|---|---|---|---|
|**Vidal, 2013**<br>N= 32: idade ≥ 18 anos|ADHD-RS<br>Cohen’s d: 0.12; p ><br>0.01 intragrupo,<br>porém não houve<br>diferença entre<br>grupos|CGI-S<br>Autorrelato:<br>Cohen’s d: 0,32;<br>p < 0.01<br>Avaliador:<br>Cohen’s d: 0,34;<br>p < 0.01<br>Intragrupo,<br>porém não<br>houve diferença<br>entre grupos|CAARS-S<br>Desatenção<br>Cohen’s d:<br>0.15; p < 0.01<br>intragrupo,<br>porém, não<br>houve<br>diferença<br>entre grupos|CAARS-S<br>hiperatividade<br>Cohen’s d: 0,19; p<br>< 0.01<br>CAARS-S<br>impulsividade<br>Cohen’s d: 0.32; p<br>< 0.05<br>intragrupo, porém<br>não houve<br>diferença entre<br>grupos|STAI-S<br>Cohen’s d: 0.35; p<br>< 0.01<br>intragrupo, porém<br>não houve<br>diferença entre<br>grupos|BDI<br>Cohen’s d:<br>0.10; p < 0.01<br>intragrupo,<br>porém não<br>houve<br>diferença<br>entre grupos|QLESQ<br>Cohen’s d: 0.33; p <0.05<br>intragrupo, porém não<br>houve diferença entre<br>grupos|CAARS-S autoestima<br>Cohen’s d: 0,12; p < 0.05<br>intragrupo, porém não<br>houve diferença entre<br>grupos|
|**Safren, 2010**<br>N= 86, idade: 18 a 65|ADHD rating scale<br>−4,63 [IC de 95%,<br>−8,30 a −0,96]; t<br>23,73 = −2,36, P  =<br>0,02; d  = 0,60<br>CSS(autorrelato)|ARS<br>ES: -4,63<br>[IC95% -8,30 a<br>-0,96]; P = 0,02<br>Responderam ao<br>tratamento:<br>67% vs 33%;<br>OR= 4.29|NR|NR|NR|NR|NR|NR|  
|β=−0.41|[IC95% 1.74 to|
|---|---|
|[IC95%:−0.64 a|10.58]; p=0.002|
|−0.17]; P<.001||
||CGI|
||ES: -0,53 [IC|
||95% -1,01 a -|
||0,05]; P = 0,03|
||Responderam ao|
||tto:|
||53% vs 23%;|
||OR= 3.80|
||[IC95% 1.50 a|
||9.59]; P=0,01|  
**Legenda:**  
DMA: Diferença média ajustada; sem: semana; tto: tratamento; AES: Tamanho do efeito ajustado (do inglês _: Adjusted Effect size_ ); EP: erro padrão; ES: estimativa de efeito; d: tamanho do efeito; PCB: placebo; NR: não relatado  
* O tamanho do efeito ajustado padronizado é derivado da diferença média do grupo ajustado dividida pelo desvio padrão da linha de base da medida.  
**Figura 7 -** Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento Desfecho: Sintomas de TDAH a curto prazo (pós-tratamento).  
<!-- Start of picture text -->
StudyLI  orSubgroupDominio DesatengloTEC associado__Mean_—_—SD__—‘To a medicamen t oal CuidadosMean usuals associadoso a medicamentT tal o Weight Mean_1V,Random, Difference95% Cl IN,MeanRandom, Difference95% C1<br>Diner 2017 Bl 39 oF 187 49 19 326% -6,601-9,73, 3,47] —<br>Emison 2011 w2 488 7 519 17 31.6% | -4501-7,70,-130] —<br>‘Young 2015 6 0443 137 mn 35 357% 3101-605, -0.15]<br>‘Subtotal (95% Cl) 79 71 1000% — -4,69[-6,70, -2,67) ><br>Heteragerey: Tai = 0,69; Ch = 2,55, of = 2 = 0,28; = 22%<br>Test for overall effect 2 » 455 @ < 0.000011<br>1.12 Dominio Hipertividade<br>DinerEison2017 2012 gl71 5744 89a8 4762 1917 334%26.9% -480[-7.81,-173)-1701-5,28, 1.88) —<br>‘Young 2015 e 5M 79 59 35 396% 1201-378 138]<br>‘Subtotal (95% C) 79 71 1000% — -2,54 [-4,82, -0,26) ><br>Heterageney. Tai? = 1,68; Ch = 3,40, of» 2 0,18; = 41%<br>Test for overall effet 2 » 2,18 @ = 0,031<br>Diner1.13 Sintomas2017 combinados236? 328 78 19 245% -11,30(-16,62,-5,98) ~=§——*——<br>Emisson 2011 v2 782 235 88 17 235% -630[-11,77, 0.83] —.—_<br>SafrenYoungsubtotal2018200595% CD) 278732075894 208ais 10897 853415 100(0%337%18.2% | -5,60(-12,08,-430[-845,-014)-6,72 [-9385,-3.59]0.88) ><br>Heterageny, Tau! = 3,05; Chit = 4,28, of = 3 = 0,23, = 308<br>Test for overall effet 2 = 421.6 < 0.0001)<br>to to i %<br>‘Tes fr subgroundterences: Chi = 4,74, of = 2. = 0091, = 57,8 Favous TCC MED) Fevous (Colas sia]<br><!-- End of picture text -->  
**Figura 8 -** Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento Desfecho: Sintomas de TDAH a médio prazo (até 6 meses após o tratamento).  
<!-- Start of picture text -->
‘TCC associado a medicamento Culdados usuas assocado a medicamento Mean Difference Mean Difference<br>Study<br>21 DominioorSubgroupDesaiengi Mean SD__Total Mean so Total Weight _ 1, Random,95% C1 IW, Random,95% Cl<br>Diner 2017 22560? 167 47 17 364% -450(-757, -143] —<br>YoungEmisson 20152011 ge96 58S53 % 162142 5758 3217 224%412% -6,40{-1032,-4601-7.49, 2.48)-171] ——_<br>Subtotal @5% cD) @ 66 100(0% ~4,97 -6,82,-3,11) as<br>Heterogeneity Tau? = 0,00; Chit = 0,66, of = 2 @ = 0,721; = O%<br>Testor overl tfc 2 = 5,25 ( < 0.00001)<br>1122 Dominio Hipertividade<br>EnmlssonDiner 20172011 5942Bs 42 57 12389 4B54 1817 269%214% -3,70[-6,24,-1,16]-3,001-8,33, 033] =<br>Young 2015 S10 41 82 5a 32 417% -3101-5,49, 071] ><br>‘Subtotal (95% C1) o7 67 100,0% -3,30 [-4,84, -1,76] Sd<br>Hetergenety Tau = 0,00, Ch = 0,15, of = 2 @ = 0931 F = 0%<br>Testor overal etfect = 4,19 ( < 0.0001)<br>1123 Sintomas combinados<br>ErnlssonDiner 20172011 2870 a7887 2925 7s85 1717 356%23,78 -830(-13,17,-930|-15,28 343]2.32] ————<br>YoungSubtotal201595% CD 4783 725 23 92 3266 100.0%40,7% -7,601-12,15,-825 [-11,16, -305]-5,34] —_><br>Heterogeney Tau? = 0,00; Chi? = 0,20, of = 2 @ = 0,92; P = 0%<br>Test for overal elect 2 » 5,56 @ < 0.00001)<br>“toto Ib 2<br>Test for subaroup dferences: Chi?» 8.94, of = 2(P = 0.01), P= 77.6% Favours [7CC + MED} Favours [Cudados usuais)<br><!-- End of picture text -->  
**Figura 9 -** Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento  
Desfecho: Melhora Clínica Global a curto e médio prazo  
<!-- Start of picture text -->
TCC assocado<br>Study a medicamento _Culdados usuals associado a medicamento Mean Difference ‘Mean Difference<br>3,3 Cutoor Subgroupprazo (p65 ratamentoMean imedlato)SD_—Total Mean x Total Weight 1, Random,95% C1 1V,Random,95% Cl<br>Emisson 2011 318 Lora 3,88 07 17 188% -0,70[-131, 0,09] |<br>Satren 2005 a) 6 487 049 1S 210% —0331-0,17, 083)<br>YoungSubtotalHeterogenety2015 95%Tau!CD = 0,33; Ch?304088= 1,60, df» 2 = 0,0036 F » 63%379 on 6634 620%22.2% -0,761-120,-022]-037(-109, 034) ~<br>Test for veal eet 2 » 1,03 = 030)<br>134 Médio prazo (até 6 meses pbs trtamento)<br>Emison 2011 2 076 8 408 086 13 17,08 -108[-1,78, -038] _<br>Young 2015 324 mek 38 0.96 27 211% -0.56|-106, -0,06)<br>Subtotal (95% Ct) 29 40 380% -0,76 [-125, -0,26) ><br>Heteropenety Taut = 0,04; Ch = 140, of = 1 P = 0,24) F = 29%<br>Test<br>for overal eect Z = 3,00 P= 0,003),<br>Total (95% C) 9% 106 1000% -0,53 [-1,00, -007) ><br>TestHeterogeneity Tau = 0,20; Chi = 14,92, df= 4 P = 0,005 F = 73% 4—<br>for veal eect: 2 = 2,24 = 0,02) Favours<br>for subgroup diterences: Chi? = 0,75, of = 1. = 0,391 F = 0%<br>Test [TCC + MED) Favous [Cudados usual)<br><!-- End of picture text -->  
**Figura 10** - Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento  
Desfecho: Sintomas de depressão a curto e médio prazo.  
<!-- Start of picture text -->
Study4.  orSubgroupCurto prazo (pbs‘TCCtratamento associado__Mean____SD__‘ToTediato) amedicamen t oal CuidadosMean usuais assodadoso a medicamentoTotal Weight _1V,MeanRandom, Difference95% Cl IV,Mean Random, Difference95% Cl<br>Emisson 2011 722 684 18 14 94 17 157% -8,191-13,76, -2,621 =<br>Young 2015 838 69934 4 1045 35 27.8% -5,62-9,80, -144] =<br>Subtotal 65% cD 52 52 435% 655 [-989, -320] ><br>Heteragenety Tau? = 0,00, Ch? «0,52, df= 1 @ = 0,471 # = OK<br>Test for overal effet 2 = 3,84. = 0,0001)<br>114.2 Médio prazo (até<br>Emisson2015 6 meses50856 pbs tratamento) Bu 7:98 32 390% 810[-1163, -457] =<br>Young 2011 5577 5 543 935 17 175% -10,43 [-15,71, 5,15] —<br>Subtotal (95% C1) 40 49 565% -8,82 [-11,76, -5,88] ><br>Heteragenety Tau? = 0,00, Ch? «0,52, df = 1 @ = 0,474 = OX<br>Testor overal effet 2 = 5,89 < 0.00001)<br>Total (95% C) 2 101 1000% | -7,83 [-10,04, -5,63] ind<br>Heterogeneity Tau? = 0,00; Ch? = 2,04, df = 3 @ = 0561 = OX 315 tt<br>TexTestor for eral subgroup  ee atferencs: 2» 696  Chi?» 6 < 0.00000 1,00, of = 1(P = 0.32) : = 0.2% Favours [TOC+ MED) Favours [Caldados uss}<br><!-- End of picture text -->  
**Figura 11 -** Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento  
Desfecho: Sintomas de ansiedade a curto e médio prazo.  
<!-- Start of picture text -->
Study1.5.1 CurtoorSubgroupprazo (p65TCCatamento associadoMean Tmediato) a medicamento——SD_—_—‘Total CuidadosMean usuais associaso a medicamentoTotal Weight _ WV,Random,Mean Difference95%C1 1W,Me R an  Differencedom, 95%Cl<br>Erisson 2011 11 1081 8 15,29 10.72 17 95% -4291-1136, 2,78]<br>YoungSubtotal201505% CO) 14th 3452 1437 10.87 35°52. 218%313% -406-3,961-8,63, [-7,96, -0,16]0,71) ><br>Heterogeneity Tau® = 0,00; Chit = 0,01, df= 1, = 0,941 F = 0%<br>Test for overall eer: 2 = 2,04  « 0,04)<br>1.5.2 Médio prazo (até<br>Erisson 6 meses pds tratamento)<br>623453 25 12.8 785 32 46.7% -5,84[-903, 2.65] =<br>‘YoungSubtotal 2015  95%2011 725 53h 5 12,89 1S 17 220% -5,64[-10,28, 0,99] a<br>Heterogeneity Tau?C1) = 0,00; Chit = 0,00, df= 1, = 0,94140 F = 0% 49° 687% -5,78[-841,-3,14) ><br>Test for overall eect 2 = 4,30 @ < 0.0001)<br>Total (95%Cl) 2 101 100,0% -5,24 [-7,42, -3,06] ><br>Heterogeneity<br>Test Testor  for  subgroup overallefiet:Tau!  diterences  = 0,00;2 = 4,71Chi® Chit  P= 0,52,< = 051, 0.00001) df= of = 3. 1(P = 047), = 0,911; F = = 0%  0% th FavowsITCC+ ‘ MED] Favours [Cuaos +  wil] i)a<br><!-- End of picture text -->  
**Figura 12** - Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento  
Desfecho: Impacto do TDAH a curto prazo.  
<!-- Start of picture text -->
Stuiy ‘Tec asscado amediamento_Coldados uss assocado a medicaments Mean oierence Mean oiterence.<br>or subgroup" ean "30" Tous_ “han a weight ‘Nando, 95%Ct standom, 9581<br>Soha seco 0 32 ooo -ayst'ea0-0a7 ><br>142 Domile prolemasemecionals<br>Sokal sxc 30 32 woos siz 'e26-098) =<br>163 Domini comportamente asec<br>mason O11 Stas ay t076 239 Yr 3mm see t296, 032<br>Subtoral Osx cn 50 52 ooge “125 (-202,-o8) 4<br>1.84 Dominio funionament socal<br>ShaHecrogerety osxenTa? = 200: CH? = 0.2, ol « 1 = 0684FA + O8 52 room “nat (1335, -a331 =<br>185 sintomas combinados ota<br>fous so47 be En 2 ami Be 8 ime atsstiew Sal a<br>Soba seen Fy 33 000% “ios 290,997 —_<br>‘Test for subgroup differences: Chi? = 30,51, df = 4(P < 0.00002), F = 86,9% ‘Favours TEE + MED). Favours (Cuidacios wsuais)<br><!-- End of picture text -->  
**Figura 13 -** Meta-análise da comparação entre TCC associado a medicamento vs. cuidados usuais associado a medicamento  
Desfecho: Impacto do TDAH a médio prazo (acompanhamento de até 6 meses após o tratamento).  
<!-- Start of picture text -->
TeCassociado<br>‘Study6.1Enison ofDominio Subgroup2011 Sintomasde‘Meanvar TDAH a medicamento.SD Total Culdados‘MeanAG usuas associaSD.a medicamentoTotalV7 Weight225% -5690-1272,2,351MeanIV, Random, Difference 95%CI IV,Mean Random, Difference 95% Cl<br>YoungSubtotal2017 @5%.cn usr 2 50 AST 3552 100%675% -4751-934,-0471-4301-988, 124] 2<br>Heterogeneity Tau’ = 0,00; Chi? = 0,08, df = 1(P = 0,781, = 0%<br>Test for oral eect 2 = 2,03 @ = 0,04)<br>1.62 Domino problemas emecionas<br>snisonYoung 20172011 MeoM303394 T4086 3517 638%366% -626(-13.07,4471-967, 0581<br>‘Subtotal (95% CI) 50 ‘52 100,0% 5,12 [-9,26, -0,98)073] ><br>Heterogeneity Tau? = 0,00; Chi? = 0,16, of = 1 (P = 0,69), = 0%<br>Test for orl eect 2 = 242 @ = 0,02)<br>163 Domino comporamentoansocial<br>YeungEmissn20172001 oz9281321028sla? 1076 238238 3517 339%66.1% -168-L05(-199,-01]2.96, -0321<br>‘Subtotal (95% Cl) 50 52 100,0% — -1,25 [-2,02, -0,48] 4<br>Heterogeneity Tau? = 0,00; Chi? = 0,51, df = 1(P = 0,481, = 0%<br>Test for orallefert 2 = 3,19 @ = 00D<br>1.64 Domino funcionamento socal<br>Enissn 2021 26769283847 1076 17 324% -971,-16,46,-296) —<br>Yeung 2017 23083609048 35 670% -7791-1246, 3.12 *<br>Subtotal @5% cD) 50 52 100% “gai 1825, 4571 es<br>Heterogeneity Tat «0,00; Chi = 0.21, df « 10 « 0651 P= ox<br>Test for ovral fect 7= 429 0 < 0000<br>16 Sintomas combinaos Got)<br>Emigsn 2021 se MAS 808 Wy 372k -23,1113399,-723] |——#——<br>‘Young‘SubtotalHeteragenty2017(95%Tait»Cl) 0,00;99,52Ch? «0.28,25,77af « 168 « 5952B50 P= O&uz, 25,46 35$2 100,0%62,9% -17,59[-29,77,-19,64 [-29,30, -9,97]-5,41] ——=><br>Test for ower tert 2» 3,98 < 0.000%)<br>soos, 8698 tofvous [TCC + MM ED ]} F avours avours [Cudados(CuE wal), 36<br><!-- End of picture text -->  
**Figura 14 -** Meta-análise da comparação entre TCC vs. Intervenções não medicamentosas  
Desfecho: Sintomas de depressão a curto prazo (pós tratamento).  
<!-- Start of picture text -->
Study2.1.1 Curtoor Subgroupprazo (p65 tratamentoMean Tecimediato)SD Total___MeanIntervencBes no medicamentosasSD____Total Weight 1V,MeanRandom, Difference95% Cl IV,Mean Random, Difference95% Cl<br>ViraVan Emmerik-vanet al, 2010 2019(8) 8399 10,5683 409 98748 10,2558 4010 41,3%58,7% 4,20[-2,31,-1,48 [-6,04,10,71]3,08]<br>Subtotal (95%<br>Heterogeneity. Tau’Cl) = 7,91; Chi? = 1,96, of 49= 1 (P = 0,16); /? = 49% 50 100,0% 0,87 [-4,61, 6.35]<br>Test for overall eect Z = 0,31 (P = 0,76)<br>Total (95% Cl) 49 50 100,0% 0,87 [-4,61, 6,35]<br>TestTestHeterogeneity. forfor subaroupoverall eect:Tau’aifferences:= 7,91;Z = 0,31Chi?Not(P==applicable 1,96,0,76)of = 1 (P = 0,16); /? = 49% ato Favours [TCC]tr Favoursth fintervencdoS/M]<br><!-- End of picture text -->  
**Figura 15 -** Meta-análise da comparação entre TCC associado a medicamento vs. Outras intervenções associadas a medicamento Desfecho: Melhora clínica Global a curto prazo (pós tratamento).  
<!-- Start of picture text -->
Study TCC assocadoa medicamento Outrasintervencbes associadoa medicamento Mean Difference Mean Difference<br>SLI Curtor Subgroupprazo (65s WatamentoTedlato)___Mean__—_—SD_—Total Mean Ey Total_Weight_1V, Random,95% Cl Iv Random, 95% Cl<br>Satren 2010 32 Sa 37 a3 37 $1,2% -0531-108, 003]<br>Vidal 2013 46 mB 4 dol 7 488% 0291-032, 030]<br>Subtotal 95%) 56 54 1000% 0,13 [-093, 0671<br>Heteragenety Tau! = 0,25; Ch? «3,79, of = 1(P = 0,05) P = 74%<br>Test for veal eect 2 = 0,52 = 075)<br>Total 95% CD 56 54 1000% -0,3 [-093, 0671<br>Heteragenety Tau! = 0,25; Ch? «3,79, of = 1(P = 0,05) P = 74% 4—<br>Test for veal eect: 2 = 0,52 = 075) Favours [TOC + MED] Favours [Oars + MED]<br>Test for subgroup dierences: Not applicable<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Risco de viés dos estudos incluídos** -->
**Figura 16 -** Risco de viés dos ensaios clínicos com população infanto-juvenil  
<!-- Start of picture text -->
2<br>Bot<br>€<br>2<br>& 2 3<br>=58<br>433g5£25$35<br>85 s 2 8<br>8a =2 3@ Rags a2<br>c € € ° @<br>gs £ 8 5 =<br>8 ‘o 3 = ‘S<br>3 2 ro) 5 c<br>€ 3 0 5 Ss =<br>6 = s 2 € =<br>Study ID Outcome @&2 &¢ 52 =F&§ &# 6&<br>Banaschewski 2011 Sintomas de TDAH t ) e@ e@ e@ U e@ @ Low risk<br>Fehlings 1991 Sintomas, de TDAH >®CCC@ Some concerns<br>Sprich 2016 Sintomas de TDAH ® ; (>) @ ? @ r High risk<br>Vidal 2015 Sintomas de TDAH <)) z (3) @ e @<br><!-- End of picture text -->  
**Figura 17 -** Resumo e gráfico do risco de viés dos ensaios clínicos com população infanto-juvenil  
<!-- Start of picture text -->
As percentage (intention-to-treat)<br>Overall Bias fl<br>Selection of the reported result a<br>Measurement of the outcome ee<br>Mising outcome data ———<br>Deviations from intended interventions a<br>Randomization process DO es<br>1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral<br>sa Low risk Some concerns High risk<br><!-- End of picture text -->  
**Figura 18 -** Risco de viés dos ensaios clínicos com população adulta  
<!-- Start of picture text -->
3<br>3fog<br>plaad<br>5s § § @ 2<br>B 2 3 € 8<br>Study 1D Outcome € 8 = £$ 3 6<br>cosieo2018 — sitomascero © @ @ @ @ @ @ wis<br>pieiner 2017 sitomas ceo» @ @ @ OD @ Q_  |®@y sae concems<br>tmisson2011 —sintomascetos® @ @ @ @ @ QO S©@ ages<br>tuarg 2019 Sitomaseetosr @ @ @ @ ® @<br>rritgeen 2015 sitomasetoar © © @ @ @ @<br>satren2005  stomaseerons @ © @ @ @ @<br>safren2010 —sintomaserour © @ © @ @ @<br>vantmmerk sintomascero © @ © @ @ @<br>Vidal 2013 sinromascerosr @ © @ @ @ @<br>wa200 Ss Sintomascetoes ©@ @ @ @ @ @<br>vore2015 someon @ © © @ @ @<br>vorg2017impacrocoon @ © @ © @ @<br><!-- End of picture text -->  
**Figura 19 -** Resumo e gráfico do risco de viés dos ensaios clínicos com população infantil e juvenil  
<!-- Start of picture text -->
As percentage (intention-to-treat)<br>Overall Bias<br>Selection of the reported result<br>Measurement of the outcome<br>Mising outcome data<br>Deviations from intended interventions<br>Randomization process<br>1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral1900ral<br>Low risk Some concerns High risk<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Avaliação da Qualidade da Evidência** -->
**Tabela J** - Sumarização das evidências, organizadas de acordo com o layout da tabela _Evidence to Decision_ (EtD)- metodologia GRADE.  
**Pergunta** : TCC em grupo comparado a cuidados usuais para TDAH em população infanto-juvenil  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|**Sintoma**<br>1|**s de TDAH**<br>ensaios|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|TDAH-RS: mensurado pelos adolescentes: -7,46 (-|⨁⨁◯◯|CRÍTICO|
||clínicos||||||9,56 a -5,36); mensurado pelos pais: -9,11 (-11,48|BAIXA||
||randomizados||||||a -6,75)|||  
a. Estudo com risco de viés incerto avaliado pelo ROB 2.0. Problemas na randomização, alto percentual de perda de dados dos desfechos.  
b. Amostra de 119 pacientes, no entanto, considerada inferior ao número optimal para avaliar desfechos contínuos.  
**Pergunta** : TCC em grupo comparado a outras intervenções não farmacológicas para TDAH em população infanto-juvenil  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**comport**|**Delineamento**<br>**do estudo**<br>**amentos ansioso**|**Risco**<br>**de**<br>**viés**<br>**-depres**|**Inconsistência**<br>**sivo e hiperativi**|<br>**Evidência**<br>**indireta**<br>**dade**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|1|ensaios|muito|não grave|não grave|muito grave|nenhum|Ansioso-depressivo: t8 = 1,81, p<0,05;|⨁◯◯◯|CRÍTICO|
||clínicos|grave<sup>a</sup>|||b||Agressivo: t8 = 1,65, p <0,07;|MUITO||
||randomizados||||||Impulsividade: t = 2,93, p <0,01;|BAIXA||
||(crossover)||||||Hiperatividade t8 = 1,52, p <0,09|||  
a. Estudo com alto risco de viés na maioria dos domínios, avaliado pelo ROB 2.0. Não houve randomização adequada, não houve cegamento de pacientes, clínicos ou avaliadores, além de co-intervenções em muitos pacientes.  
b. Pequeno tamanho amostral (12 participantes).  
**Pergunta** : TCC + terapia familiar comparado a cuidados usuais para TDAH em população infanto-juvenil  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|**Sintoma**|**s de TDAH**|||||||||
|1|ensaios|grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|ADHD-RS avaliação dos pais: - 10,93 (IC95%: -|⨁⨁◯◯|CRÍTICO|
||clínicos||||||12,93 a -8,93; p <0,001); ADHD-RS avaliações|BAIXA||
||randomizados||||||dos adolescentes: - 5,24 (IC95%: -7,21 a -3,28; p|||
||crossover||||||<0,001)|||  
a. Estudo com risco de viés incerto avaliado pelo ROB 2.0. Não houve cegamento de pacientes e clínicos.  
b. Estudo com amostra pequena (n=46).  
**Pergunta** : TCC + terapia familiar comparado a outras intervenções não farmacológicas para TDAH em população infanto-juvenil  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|**Sintoma**<br>1|**s de TDAH**<br>ensaios|grave<sup>a</sup>|grave<sup>b</sup>|não grave|muito grave|nenhum|Hiperatividade em casa: F: 4,7; df 1,68; p<0,03.|⨁◯◯◯|CRÍTICO|
||clínicos||||c||Desatenção e impulsividade: não houve diferença|MUITO||
||randomizados||||||estatística entre os grupos|BAIXA||  
a. Estudo com alto risco de viés na maioria dos domínios, avaliado pelo ROB 2.0. Viés de desfechos incompletos e relato seletivo de desfechos.  
b. Inconsistência entre as medidas do desfecho (intra-estudo)  
c. Pequeno tamanho amostral (25 participantes).  
**Pergunta** : TCC + medicamento comparado a cuidados usuais + medicamento para TDAH em adultos  
||||**Avaliação da**|**Certeza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|<br>**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|<br>**TCC +**<br>**medicamento**|**cuidados**<br>**usuais +**<br>**medicamento**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|  
**Sintomas de TDAH a curto prazo (pós tratamento imediato)**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**TCC +**<br>**medicamento**|**cuidados**<br>**usuais +**<br>**medicamento**|**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|
|4|ensaios<br>clínicos<br>randomizados|grave<br>a|não grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|94|85|-|MD 6.72<br>**menor**<br>(9.85<br>menor<br>para 3.59<br>menor)|⨁⨁◯◯<br>BAIXA|IMPORTANTE|  
**Sintomas de TDAH a médio prazo (até 6 meses pós tratamento)**  
|3|ensaios<br>clínicos<br>randomizados|grave<br>a|não grave|não grave  não grave|nenhum|67|66|-<br>MD**8.25**<br>**menor**<br>(11.16<br>menor<br>para 5.34<br>menor)|⨁⨁⨁◯<br>MODERADA|<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|  
**Melhora clínica Global (CGI) - Curto prazo (pós tratamento imediato)**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**TCC +**<br>**medicamento**|**cuidados**<br>**usuais +**<br>**medicamento**|**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|
|3<br>**Melhor**|ensaios<br>clínicos<br>randomizados<br>**a clínica Global**|grave<br>a<br>**(CGI) -**|muito grave<sup>d</sup><br>**Médio prazo (at**|não grave<br>**é 6 meses p**|muito grave<br>e<br>**ós tratament**|nenhum<br>**o)**|66|66|-|MD**0.37**<br>**menor**<br>(1.09<br>menor<br>para 0.34<br>mais<br>alto)|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|
|2|ensaios<br>clínicos<br>randomizados|grave<br>a|não grave|não grave|grave<sup>f</sup>|nenhum|29|40|-|MD**0.76**<br>**menor**<br>(1.25<br>menor<br>para 0.26<br>menor)|⨁⨁◯◯<br>BAIXA|IMPORTANTE|  
**Depressão (BDI) - Médio prazo (até 6 meses pós tratamento)**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**TCC +**<br>**medicamento**|**cuidados**<br>**usuais +**<br>**medicamento**|**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|
|2<br>**Ansieda**|ensaios<br>clínicos<br>randomizados<br>**de (BAI) - Médi**|grave<br>a<br>**o prazo**|não grave<br>**(até 6 meses pó**|não grave<br>**s tratament**|grave<sup>f</sup><br>**o)**|nenhum|40|49|-|MD**8.82**<br>**menor**<br>(11.76<br>menor<br>para 5.88<br>menor)|⨁⨁◯◯<br>BAIXA|IMPORTANTE|
|2|ensaios<br>clínicos<br>randomizados|grave<br>a|não grave|não grave|grave<sup>f, g</sup>|nenhum|40|49|-|MD**5.78**<br>**menor**<br>(8.41<br>menor<br>para 3.14<br>menor)|⨁⨁◯◯<br>BAIXA|IMPORTANTE|  
**Impacto do TDAH a médio prazo (até 6 meses pós tratamento)**  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**TCC +**<br>**medicamento**|<br>**cuidados**<br>**usuais +**<br>**medicamento**|**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|
|2|ensaios<br>clínicos<br>randomizados|grave<br>a|não grave|não grave|grave<sup>g</sup>|nenhum|39|49|-|MD<br>**34.55**<br>**menor**<br>(50.66<br>menor<br>para<br>18.44<br>menor)|⨁⨁◯◯<br>BAIXA|CRÍTICO|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Avaliação da Qualidade da Evidência** -->
**CI:** Intervalo de Confiança; **MD:** Diferença de médias  
a. Estudos classificados como risco de viés incerto ou alto de acordo com a ROB 2.0.  
b. Heterogeneidade da medida geral: I2 49%. Nos subgrupos, varia de 22 a 41%. Inconsistência observada para o domínio hiperatividade, mas não é grave.  
- c. No domínio sintomas combinados, há estudos com intervalos de confiança amplos. No domínio hiperatividade, há estudos cujos IC geram resultado diferente (tanto não mostram diferença entre os braços de tratamento quanto favorecem a intervenção)  
- d. Heterogeneidade alta: I2 de 83%, diferenças elevadas nas estimativas de efeitos.  
- e. Estudos com direções de efeitos opostas e baixo número amostral na comparação.  
f. Número amostral considerado inferior ao número optimal para avaliar desfechos contínuos, que seriam 400 participantes por comparação.  
- g. Estudos com intervalos de confiança amplos.  
**Pergunta** : TCC + medicamento comparado a outras intervenções + medicamento para TDAH em adultos  
||||**Avaliação da C**|**erteza**|||**№ de p**|**acientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Melhora**|**Delineamento**<br>**do estudo**<br>**Clínica Global**|**Risco**<br>**de**<br>**viés**<br>**(Escala**|**Inconsistência**<br>**– CGI a curto**|**Evidência**<br>**indireta**<br>**prazo)**|**Imprecisão**|**Outras**<br>**considerações**|**TCC +**<br>**medicamentos**|**outras**<br>**intervenções**<br>**+**<br>**medicamentos**|**Relativo**<br>**(95%**<br>**CI)**|<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certeza**|**Importância**|
|2|ensaios<br>clínicos<br>randomizados|grave<br>a|muito grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|56|54|-|MD**0.13**<br>**menor**<br>(0.93<br>menor<br>para 0.67<br>mais<br>alto)|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|  
**CI:** Confidence interval; **MD:** Mean difference  
a. Estudos com n amostral pequeno e indícios de viés na randomização e desvio das intervenções, julgados como risco de viés incerto  
b. Heterogeneidade alta entre os estudos I2 de 74%  
c. Intervalos de confiança que apontam desde benefício da intervenção a não efeito.  
**Pergunta** : TCC comparado a intervenção não farmacológica para TDAH em adultos  
||||**Avaliação da C**|**erteza**|||**№**|**de pacientes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Depressã**|**Delineamento**<br>**do estudo**<br>**o (escala BDI)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**TCC**|**intervenção**<br>**não**<br>**farmacológica**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|2|ensaios clínicos<br>randomizados|grave<br>a|grave<sup>b</sup>|não grave|grave<sup>c</sup>|nenhum|49|50|-|MD**0.87**<br>**mais alto**<br>(4.61<br>menor<br>para 6.35<br>mais alto)|<br>⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|  
**CI:** Confidence interval; **MD:** Mean difference  
a. Dois estudos com n amostral pequeno (um deles com 29 apenas) e vieses metodológicos (pontuados com viés incerto nos domínios: randomização, desvio das intervenções e relato seletivo de desfechos), um deles com problemas também na mensuração dos desfechos.  
b. Heterogeneidade entre os estudos - I2 de 49%  
c. Intervalos de confiança amplos.  
**Pergunta** : TCC comparado a Lista de espera para TDAH em adultos  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|<br>**Evidência**<br>**indireta**|<br>**Imprecisão**|<br>**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Sintomas de TDAH** -->
|2|ensaios|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|Huang (2019): ADHD-RS: ES=0,46; IC95% -0,06|<br>⨁⨁◯◯|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|
||clínicos||||||a 0,98|BAIXA||
||randomizados||||||Virta (2010): BADDS: F (1,18) = 6,32; p=0,05 /<br>ARSS: F (1,18) = 1,67, p: não significativo|||  
**Legenda:**  
**CI:** Confidence interval; **MD:** Mean difference  
a. Estudos com n amostral pequeno e indícios de viés de relato seletivo de desfechos e desvio das intervenções.  
b. Estudos heterogêneos, desfecho mensurado por escalas diferentes entre os estudos e com resultados diferentes, desde favorecendo a intervenção quanto não mostrando benefício.  
**Pergunta** : TCC + medicamento ou tratamento habitual comparado a outras intervenções para TDAH em adultos  
||||**Avaliação da C**|**erteza**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Eventos**|<br>**Delineamento**<br>**do estudo**<br>**adversos**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|3|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|**Dittner** **(2017):**5 pessoas no grupo TCC e 3<br>pessoas no grupo TAU apresentaram EA. A<br>diferença foi significativa, seja por pessoa (p =<br>0,99) ou por sintoma (p = 0,49). Dois eventos,<br>ambos do grupo TCC, foram considerados graves,<br>mas não relacionados ao tratamento.<br>**Emilsson (2011):**27 EA foram registrados durante<br>o estudo. Um participante do grupo TCC relatou<br>sofrimento grave ao final do tratamento, este não<br>foi avaliado no seguimento.<br>**Philipsen (2015):**62% dos pacientes do grupo<br>TCC associado a placebo relatou ao menos um EA,<br>dos quais 3,9% apresentaram evento grave. Já no<br>grupo comparador, 94% dos pacientes relataram<br>EA, sendo 7,7% graves.|⨁⨁◯◯<br>BAIXA|CRÍTICO|  
**Legenda:** a. Estudo com n amostral pequeno e com risco de viés incerto a alto; b. Estudos heterogêneos, com seguimentos diferentes.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **PERGUNTA** -->
|**Qual a eficácia e a segurança da t**|**erapia cognitivo comportamental –TCC para TDAH em população infanto-juvenil?**|
|---|---|
|POPULAÇÃO:|TDAH em população infanto-juvenil|
|INTERVENÇÃO:|TCC|
|COMPARAÇÃO:|cuidados usuais|
|PRINCIPAIS DESFECHOS:|Sintomas de TDAH;|
|CENÁRIO:|Usuários do SUS.|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Problema** -->
**O problema é uma prioridade?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|---|---|
|○ Não|- TDAH é o tipo de transtorno do neurodesenvolvimento mais comum na infância, podendo|
|○ Provavelmente não|também estar presente na idade adulta;|
|○ Provavelmente sim|- As estimativas mundiais de prevalência variam consideravelmente, com dados apontando|
|● Sim|aproximadamente 5% em crianças e variação de 2,1% a 4,4% em adultos;|
|○ Varia|- O TDAH gera uma demanda crescente por serviços de saúde mental e está associado a mais|
|○ Incerto|sintomas, problemas familiares e escolares em comparação com a população em geral;<br>- O TDAH também está associado a resultados psicológicos negativos, como um risco<br>aumentado de desenvolver distúrbios de personalidade e possivelmente condições psicóticas.|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Efeitos desejáveis** -->
**Quão substanciais são os efeitos desejáveis?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|---|---|
|○ Trivial|**TCC em grupo vs. Cuidados usuais**|
|● Pequeno|Um ECR mostrou que a TCC em grupo associada ao tratamento medicamentoso apresentou|
|○ Moderado|maior redução dos sintomas de TDAH (TDAH-RS avaliado pelos adolescentes: -7,46 [IC95%:|
|○ Grande|-9,56 a -5,36]; TDAH-RS avaliado pelos pais: -9,11 [IC95%: -11,48 a -6,75]) e resultados|
|○ Varia|superiores d pelo clínico: -0,79 [IC95%: -0,95 a -0,62]) em comparação à lista de espera e|
|○ Incerto|melhora clínica global (CGI-S autorrelato: -0,68 [IC95%: -0,98 a -0,39]; CGI-S avaliado|
||**TCC em grupo vs. Outra intervenção não farmacológica**<br>A evidência gerada a partir de um estudo_crossover_mostrou que a TCC em grupo melhorou o<br>controle cognitivo dos impulsos pré e pós teste (Erros: p = 0,04; Impulsividade: p <0,01), porém<br>não foi melhor que o treinamento sensório motor para hiperatividade (p: ns). A TCC também<br>não foi superior ao treinamento sensório motor para o comportamento agressivo (p: ns).<br>Contudo, nos sintomas gerais, avaliados pelo_Conners' Abbreviated Symptom Questionnaire,_os<br>tratamentos diferiram (p<0,04). Não houve efeito significativo da ordem de tratamento.|
||**TCC associado a terapia familiar vs. Cuidados usuais**<br>Um ECR mostrou que o tratamento com TCC associado a terapia familiar e farmacoterapia foi<br>superior à lista de espera e farmacoterapia em adolescentes. Houve redução da gravidade da<br>doença avaliada pelos dos pais (ADHD-RS: -10,93; IC95%: -12,93 a -8,93) e nas auto<br>avaliações (ADHD-RD: -5,24; IC95%: -7,21 a -3,28). A TCC também foi superior no<br>comprometimento funcional (CGI): média de 1,17 menor (IC95%: -1,39 a -0,94).|
||**TCC associado a terapia familiar Vs. Outra intervenção não farmacológica**|  
|A TCC associada a terapia familiar foi superior à terapia de suporte tanto para a autoestima da|
|---|
|criança (F: 4,62; df 1,67; p<0,03) quanto para a hiperatividade, sob a perspectiva dos pais (F:|
|4,7; df 1,68; p<0,03). Em contrapartida, desatenção e impulsividade não mostraram diferença<br>estatística entre os grupos. Os resultados foram provenientes de um ECR.|
|Não foram reportados resultados de segurança nestes estudos.|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Efeitos indesejáveis** -->
**Quão substanciais são os efeitos indesejáveis?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|---|---|
|○ Grande|**TCC em grupo vs. Cuidados usuais**|
|○ Moderado|Um ECR mostrou que a TCC em grupo associada ao tratamento medicamentoso apresentou|
|○ Pequeno|maior redução dos sintomas de TDAH (TDAH-RS avaliado pelos adolescentes: -7,46 [IC95%:|
|○ Trivial|-9,56 a -5,36]; TDAH-RS avaliado pelos pais: -9,11 [IC95%: -11,48 a -6,75]) e resultados|
|○ Varia|superiores d pelo clínico: -0,79 [IC95%: -0,95 a -0,62]) em comparação à lista de espera e|
|● Incerto|melhora clínica global (CGI-S autorrelato: -0,68 [IC95%: -0,98 a -0,39]; CGI-S avaliado|
||**TCC em grupo vs. Outra intervenção não farmacológica**<br>A evidência gerada a partir de um estudo_crossover_mostrou que a TCC em grupo melhorou o<br>controle cognitivo dos impulsos pré e pós teste (Erros: p = 0,04; Impulsividade: p <0,01), porém<br>não foi melhor que o treinamento sensório motor para hiperatividade (p: ns). A TCC também<br>não foi superior ao treinamento sensório motor para o comportamento agressivo (p: ns).<br>Contudo, nos sintomas gerais, avaliados pelo_Conners' Abbreviated Symptom Questionnaire,_os<br>tratamentos diferiram (p<0,04). Não houve efeito significativo da ordem de tratamento.|
||**TCC associado a terapia familiar vs. Cuidados usuais**|  
|Um ECR mostrou que o tratamento com TCC associado a terapia familiar e farmacoterapia foi<br>superior à lista de espera e farmacoterapia em adolescentes. Houve redução da gravidade da|
|---|
|doença avaliada pelos dos pais (ADHD-RS: -10,93; IC95%: -12,93 a -8,93) e nas auto<br>avaliações (ADHD-RD: -5,24; IC95%: -7,21 a -3,28). A TCC também foi superior no<br>comprometimento funcional (CGI): média de 1,17 menor (IC95%: -1,39 a -0,94).|
|**TCC associado a terapia familiar Vs. Outra intervenção não farmacológica**|
|A TCC associada a terapia familiar foi superior à terapia de suporte tanto para a autoestima da|
|criança (F: 4,62; df 1,67; p<0,03) quanto para a hiperatividade, sob a perspectiva dos pais (F:|
|4,7; df 1,68; p<0,03). Em contrapartida, desatenção e impulsividade não mostraram diferença<br>estatística entre os grupos. Os resultados foram provenientes de um ECR.|
|Não foram reportados resultados de segurança nestes estudos.|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Certeza na evidência** -->
**Qual é a certeza geral na evidência sobre os efeitos?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|---|---|
|○ Muito baixa|A qualidade geral da evidência foi baixa para os desfechos: sintomas de TDAH (mensurado em|
|●  baixa|duas comparações: i) TCC em grupo vs. cuidados usuais e ii) TCC + terapia familiar vs. outras|
|○ Moderado|intervenções não farmacológicas e comportamentos ansioso-depressivo e hiperatividade|
|○ Alta|(mensurado apenas na comparação TCC em grupo vs. outras intervenções não farmacológicas).|
|○  Sem estudos incluídos|Em ambos, a avaliação foi penalizada pelo alto risco de viés dos estudos. Nos sintomas de<br>TDAH, a qualidade geral da evidência também foi rebaixada por imprecisão (na primeira<br>comparação) e inconsistência (na segunda comparação). Quanto aos comportamentos ansioso-<br>depressivo e hiperatividade, o alto risco de viés na maioria dos domínios e o pequeno tamanho<br>amostral levaram ao_downgrade_duplo do desfecho.|  
|**Valores**<br>**Existe incerteza ou variabilida**|Já a gravidade da doença, mensurada apenas na comparação TCC + terapia familiar comparado<br>a cuidados usuais, a qualidade geral da evidência foi moderada, tendo sino penalizado pelo risco<br>de viés - estudo com n pequeno e com viés incerto quanto ao relato seletivo de desfechos.<br>**de importante no modo como as pessoas avaliam os principais desfechos?**||
|---|---|---|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ Incerteza ou variabilidade<br>importante<br>○ Possivelmente incerteza ou<br>variabilidade importante<br>● Provavelmente não Incerteza<br>ou variabilidade importante<br>○ Sem Incerteza ou<br>variabilidade importante|Melhora da sintomatologia e da condição clínica são essenciais para o desenvolvimento da<br>criança e do adolescente, considerando diferentes aspectos: sociais, emocionais, acadêmicos,<br>laborais, entre outros.<br>Nenhum dos quatros estudos realizados na população infanto-juvenil relatou desfechos de<br>segurança no tratamento com TCC. Portanto, não é possível afirmar se a TCC pode ou não<br>causar alguma reação adversa do cuidado em crianças e adolescentes.<br>TCC pode ser realizada individual ou em grupo, assim como, em monoterapia eu associada aos<br>medicamentos específicos para o TDAH, como por exemplo o metilfenidato.|Ainda existe incerteza na forma da<br>avaliação dos pacientes com TDAH, sendo<br>que dos 4 estudos incluídos para a<br>população infanto-juvenil, várias escalas<br>avaliaram os desfechos mais importantes.<br>Diante dessa diversidade, a sumarização<br>dos resultados, assim como a comparação<br>entre os estudos fica prejudicada.<br>Há necessidade de elencar os principais<br>desfechos para ser avaliados em pacientes<br>com TDAH, assim como, as principais<br>escalas que devem ser utilizadas para<br>avaliar estes pacientes. A escolha da escala<br>deve levar em consideração as propriedades<br>de medida, sendo que há necessidade da<br>escala apresentar boa validade de construto,|  
alta confiabilidade e responsividade e ser reprodutível.

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Balanço dos efeitos** -->
**O equilíbrio entre efeitos desejáveis e indesejáveis favorece a intervenção ou a comparação?**  
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|---|---|
|○ Favorece a comparação|Dados de 202 crianças e adolescentes foram sumarizados, contudo houve heterogeneidade|
|● Provavelmente favorece a|clínica entre os participantes e as intervenções, o que dificulta a comparação entre os estudos.|
|comparação|Apesar da baixa qualidade metodológica, os resultados mostram que a TCC em grupo e|
|○ Não favorece um e nem o<br>outro|associada a farmacoterapia foi superior a lista de espera para a redução dos sintomas de TDAH<br>e funcionalidade, porém não foi superior ao treinamento sensório motor.|
|○ Provavelmente favorece a<br>intervenção|Por outro lado, quando a TCC foi realizada individualmente, entre o terapeuta e a criança ou o<br>adolescente, um programa de TCC combinada com algumas sessões de terapia familiar foi|
|○ Favorece a intervenção<br>○ Varia|superior a lista de espera na redução de sintomas de TDAH e melhora clínica global. A TCC<br>individual também foi superior quando comparada a sessões de terapia de suporte para os|
|○ Incerto|desfechos de autoestima e hiperatividade das crianças. No entanto, os desfechos de desatenção<br>e impulsividade não mostraram diferença entre os grupos. Nenhum dado de segurança foi<br>reportado nessa população, não é possível afirmar se a TCC pode causar ou não alguma reação<br>adversa em crianças e adolescentes.|
|**Equidade**<br>**Qual seria o impacto na equida**|**de em saúde?**|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|○ Reduzida|No SUS, a psicoterapia já é ofertada à população, independentemente da modalidade (individual|
|○ Provavelmente reduzida|ou em grupo/ abordagem)|
|● Provavelmente não impacta||  
|○ Provavelmente aumentada<br>○ Aumentada<br>○ Varia<br>○ Incerto||
|---|---|
|**Aceitabilidade**<br>**A intervenção é aceitável par**|**a os principais interessados?**|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|○ Não|O tratamento psicológico deve ofertar suporte estruturado, focado no TDAH, com|
|○ Provavelmente não|acompanhamento regular e envolver um programa de TCC completo.|
|● Provavelmente sim|Os riscos e os benefícios (por exemplo, como o tratamento pode ter um efeito positivo nos|
|○ Sim|sintomas de TDAH) da TCC devem ser ponderados. Assim como as possíveis barreiras à adesão|
|○ Varia|e à continuidade do tratamento, as estratégias para lidar com aquelas identificadas (como|
|○ Incerto|agendamento de sessões para minimizar inconvenientes) e a importância da adesão a longo<br>prazo.<br>É necessário que haja comprometimento do paciente com a terapia (inclusive fora das sessões)<br>e que haja disponibilidade do paciente para participar do acompanhamento de apoio e sustentar<br>as estratégias aprendidas.<br>O possível efeito do aumento da autoconsciência e da responsabilidade sobre o tratamento e o<br>impacto desafiador que isso pode gerar sobre o paciente e as pessoas ao seu redor.|
|**Viabilidade**<br>**A intervenção é viável de ser i**|**mplementada?**|
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**<br>**CONSIDERAÇÕES ADICIONAIS**|
|○ Não|Não serão necessárias muitas ações com relação à viabilidade, já que a psicoterapia já é ofertada|
|○ Provavelmente não|pelo SUS à população.|  
|● Provavelmente sim|
|---|
|○ Sim|
|○ Varia|
|○ Incerto|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Resumo dos julgamentos** -->
||**JULGAMENTO**|||||||
|---|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**|Varia||Incerto|
|**EFEITOS**<br>**DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande|Varia||Incerto|
|**EFEITOS**<br>**INDESEJÁVEIS**|Grande|Moderado|Pequeno|Trivial|Varia||**Incerto**|
|**CERTEZA DA**<br>**EVIDÊNCIA**|Muito baixa|**Baixa**|Moderado|Alta|Sem estudos in|cluídos||
|**VALORES**|Incerteza ou<br>variabilidade<br>importante|Possivelmente incerto<br>ou variabilidade<br>importante|**Provavelmente sem**<br>**Incerteza ou**<br>**variabilidade**<br>**importante**|Sem incerteza ou<br>variabilidade<br>importante||||
|**BALANÇO DOS**<br>**EFEITOS**|Favorece a<br>comparação|**Provavelmente**<br>**favorece a**<br>**comparação**|Não favorece um e<br>nem o outro|Provavelmente<br>favorece a intervenção|Favorece a<br>intervenção|Varia|<br>Incerto|
|**EQUIDADE**|Reduzida|Provavelmente<br>reduzida|**Provavelmente sem**<br>**impacto**|Provavelmente<br>aumentada|Aumentada|Varia|<br>Incerto|
|**ACEITABILIDADE**|Não|Provavelmente não|**Provavelmente sim**|Sim|Varia||Incerto|
|**VIABILIDADE**|Não|Provavelmente não|**Provavelmente sim**|Sim|Varia||Incerto|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **TIPO DE RECOMENDAÇÃO** -->
|Recomendação forte contra a|Recomendação condicional contra<br>Não favorece uma ou outra|**Recomendação condicional a**|Recomendação forte a favor da|
|---|---|---|---|
|intervenção|a intervenção|**favor da intervenção**|intervenção|
|○|○<br>○|**●**|○|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Recomendação** -->
O painel recomendou fracamente a aplicação de abordagens de base comportamental (Terapia Cognitivo-comportamental e outras terapias de base comportamental) como componente do tratamento multimodal de TDAH. (Acrescentar o parágrafo de técnicas disponível no PCDT de TDAH)

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Qual a eficácia e a segurança da terapia cognitivo comportamental para adultos com TDAH?** -->
|**POPULAÇÃO:**|Adultos (> 18 anos) com TDAH|
|---|---|
|**INTERVENÇÃO:**|TCC monoterapia ou TCC combinada com medicamento|
|**COMPARAÇÃO:**|Lista de espera; intervenção farmacológica; ou intervenção não farmacológica|
|**PRINCIPAIS DESFECHOS:**|Sintomas de TDAH; desatenção; hiperatividade/impulsividade; melhora clínica global; qualidade de vida; ansiedade; e depressão.|
|**CENÁRIO**|Usuários do SUS.|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Avaliação** -->
|**Problema**<br>**O problema é uma pri**|**oridade?**||
|---|---|---|
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ No<br>○ Provavelmente não|· O TDAH, também chamado de Síndrome Hipercinética, é um distúrbio neurobiológico crônico,<br>multifatorial, que afeta crianças, adolescentes e adultos;||
|○ Provavelmente sim<br>● Sim<br>○ Varia<br>○ Incerto|· As estimativas mundiais de prevalência variam consideravelmente, com dados apontando variação de<br>2,1% a 4,4% em adultos;<br>· Os sintomas do TDAH são considerados comportamentais difusos, característicos de impulsividade,<br>hiperatividade ou inquietude e desatenção;<br>· É comum (principalmente em adultos) estar associado a comorbidades neuropsiquiátricas, como<br>distúrbios de ansiedade, depressão, abuso de substâncias e comportamento antissocial.||
|**Efeitos desejáveis**<br>**Quão substanciais são**|**os efeitos desejáveis?**||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ Trivial|**Pergunta 1: TCC Vs. lista de espera (**Huang 2019 e Virta 2010 mostram que a TCC foi superior a lista|**Pergunta 1: TCC Vs. lista de espera**|
|● Pequeno|de espera para os desfechos: sintomas de TDAH e desatenção. Não houve diferença entre os grupos nos|-Sintomas de TDAH:|
|○ Moderado|desfechos hiperatividade e qualidade de vida.)|Huang 2019, aponta que a TCC melhorou os|
|○ Grande||sintomas de TDAH (ADHD-RS) em relação|
||**TCC vs intervenções não medicamentosas**|ao grupo controle (estimativa de efeito de|  
|○ Varia|Figura 9. Meta-andise da comparagdoentre TCC vs. IntervengSesno medicamentosas, DesfechoSintomasde<br>depressdo|0,46 [IC95%: 0,06 a 0,98]; p=0,003); Porém|
|---|---|---|
|○ Incerto|a curto prazo(péstratamento).<br>Ce<br>eee<br>sntec<br>sty<br>stan "50 tot<br>hae<br>SO<br>Ta wig todo98<br>tndon 981<br>~~a~~<br>iment<br>ea)<br>4838<br>ae<br>ae GetamLTY<br>ao<br>Votmeseastly 039108<br>a8<br>HU<sup>“Lacan</sup><br>goal<br>s<br>Shoutomen<br>ro<br>$0 aoaok Sar 45.035)<br>_<br>ep<br>Ta#79:8»1,1«036<br>=a<br><br> <br>|não houve diferença entre os grupos quando<br>os sintomas de TDAH foram mensurados<br>com o questionário CAARS (p=0,08).|
||<br> <br>Terwrownea<br>=i1¢a7<br>Tou xen<br>®<br>50 10008 047-461,635<br>><br>epee<br>Ta «79: 8»16,= «036 «a<br>SS<br>Teterowa cea2-319707<br>A<br>Teenegoee heeee|Virta 2010, também mostrou que a TCC foi<br>superior ao controle nos sintomas de TDAH<br>avaliados pelo BADDS - total [F(1,18) =|
||**Pergunta 2: TCC + medicamento Vs. cuidados usuais + medicamento (**Nesta pergunta foi possível<br>realizar meta-análise devido a homogeneidade dos ECR incluídos. Os resultados foram superiores para a<br>TCC associada a medicamento nos desfechos: sintomas de TDAH, desatenção, hiperatividade, melhora<br>clínica global, impacto social e comportamental do TDAH, ansiedade e depressão. Não houve diferença|6,32; p=0,05; ηp2 =0,26]. Já quando<br>mensurado pela escala ASRS, que também<br>mensura sintomas de TDAH, não houve<br>diferença estatística entre os grupos.|
||entre os grupos apenas na melhora clínica global a curto prazo)|-Desatenção|
||**TCC + medicamento vs. cuidados usuais + medicamento**|Huang 2019, aponta que o grupo tratado<br>com TCC foi superior ao controle em 12|
||Figura2.Meta-anilisedacomparacao entreTCC associado a medicamento vs. cuidados usuais associado a<br>medicamento, Desfecho: SintomasdeTDAH<br>acurto prazo(péstratamento)<br>TC  <br><br><br>|semanas, usando a escala ADHD-RS<br>desatenção: (ES: 0,73 [IC95%: 0,20, 1,26];|
||<br> mdam**e**ts Coldsvis talesete<br>stata<br>sen tence<br>a<br>fr<br>ien<br>oT<br>wig<br>aneKC<br>stanton90|p=0,005).|
||<br>Kicarona<br>a<br>i soamn<br>“Aba{ “a,<br>=<br>|Virta 2010, também aponta que o grupo<br>tratado com TCC foi superior ao controle,|
||112Domini pentane<br>Comnaoit<br>HOU<br>8<br>OR<br>8<br>2 Rm “Apidae te<br>Saal 5X0<br>x<br>7 redox<br>-250("4an,026)<br>><br>|usando a escala BADDS atenção: F (1,18) =<br>7,24, p < 0,05; ηp2 = 0,29.|
||123Stacombines<br>Sia ncn<br>*<br>3 stan<br>“Saban aon<br>=><br>‘Test for overall effec: 2'» 4,21% < 0.0001)<br>.|-Hiperatividade / Impulsividade<br>Huang 2019, mostra que não houve|
||OT<br>raves<br>TI+ MED}FavursKadenwns)|diferença entre os grupos, usando a escala|  
<!-- Start of picture text -->
Figura‘medicamento.3. Meta-andliseDesfecho:da comparacioSintomas de TDAHentre TCCa médioassociado a medicamento vs. cuidados usuais associado a<br>set eCsmncaeametcanet» Claes na scaprazoamdm(até 6 meses apésan0 tratamento}tence un tect<br>00 moss eo Yee 450179710 —_<br>temenmewenn eaeopr BR aorete TasBakohne mit dationManoneaaaCI =afandom 381<br>Seca oxen 6 6 toon “rb Sh) ><br>FenroganyWorwrowavesTe = 0; 00 «066 02 «O72 +<br>122 bonita Moenfo5s5¢ coco<br>mero ee eT dean 3701-624 138 =<br>Emmet 8 8 & BS ote “aorahen :<br>Set O58 e 6 wan “apo “i78) -<br>ewnpoes Ta = 00,0 038,0-2@ 2050 =o<br>Emmettme 207 Mee8ems8 fe OG 36PRR aneny.201Soesx ss =| —<br>Seal 95x o ~ 6 sodion “a2 C16, “S341 ><br>teeny Ta + 90,0 020 0020 2031 =O<br>Termremaceea fs35¢0 <0sben)<br>A ut e+ Fee<br>a<br><!-- End of picture text -->  
<!-- Start of picture text -->
Figura4. Meta-anslise da comparacdo entre TCC associado a medicamento vs. cuidados usuais associado a<br>‘medicamento. Desfecho: Melhora Clinica Global a curtoe médio prazo.<br>‘TeCamodae<br>Seay a medicamemo Colds va toads medicament an ote ean tence<br>201 pera a7 17 aga -070/-121,-009 o<br>sSieag2018 e n0s eanceSoom Toul a enteowagSO Toul3nmWeight2 _Notadon-areiaz0-o31env.9580om) nando=  9581<br>Setaecpneny954) “ 66 in “Oar iton a4<br>Testor Tas = 0.29; « 160,029«tO, # = K<br>134 mara ete 2 103 P= 30<br>Yoofren2015201prs ot 6 mesesao ps e r  vate)a eyBee 2D170Hix -aset-toe1001178 0 03 8 —<br>Stalnpn, 654 3s So Shon “ape(-A3s 361 -<br>TentrmaraTa = 04 n+ 140, 1-024«28<br>Tulewriaty osx ened 2100 = 051 % 106 1000% -053(-100,-087 ><br>Testor Tas?» 020,08 = 14938 49 = 05, # = THK ——<br>nara eed 22246 =) Fes C+ DF or<br>Tentenopow deuce: OF +07,61016 +030, F 8 recom) "<br><!-- End of picture text -->  
ADHD-RS impulsividade e imperatividade: (ES: -0,08 [IC95% −0,60 a 0,43], p=0,031). - Qualidade de vida Huang 2019, mostra que não houve diferença entre os grupos avaliados pelo WHOQOL-BREF, em nenhum dos domínios avaliados (físico, psicológico, social e comportamental) em 12 semanas e em 24 semanas; p>0,10. Virta 2010, também mostra que não houve diferença entre os grupos, avaliado pelo Q- LES-Q (p = 0,06). **<u>Pergunta 2: TCC + medicamento Vs. cuidados usuais + medicamento</u>** - <u>Sintomas de TDAH (desatenção; hiperatividade / impulsividade):</u> A meta-análise realizada mostrou que os resultados a curto prazo foram superiores para o grupo TCC associado a medicamento, seja no escore de desatenção [MD = -4,69; IC 95%: (-6,70 a -2,67); I2 = 22%]; no escore de hiperatividade [MD = - 2,54; IC 95%: (-4,86 a -0,26); I2 = 41%]; ou no escore da combinação dos sintomas [MD  
<!-- Start of picture text -->
Figura_medicamento.5. Meta-andliseDesfecho:da comparacioSintomas de depressioentre TCC associado @ medicamento vs. cuidados usuais associado a<br>a sen TEC tocean amidcinens50 ToulCaosMeanstaan mcsa curto eoud mamta médio prazo| actadon ieee 98 hatea eee9580<br>reson 201, Pree Ye AED 201 —<br>Yeo 015 GoM ca) Rm Sarge iw ——<br>Sohalein,Tenternaraees 560 To «00% 02 52.0» 19 = GareFy ok 8 ASLAMel ><br>142 Mpa at2 6 mee806 =60000vane)<br>fon 201 Sosy ks vy sx -mersnsiy<br>‘oa 015 su BB Tae 2 dom -aiocine 457) =<br>Soa x00 Fy ese “Ute aa) =><br>frownsTentrardtes Tt = 0 052.0017 04 Ok<br>Tews oxcn 25836 00500 2 11 tam -783(1006-91 ad<br>Hep Ta 0 Oo «204 03 Sc a<br>Testromateata napStee 2-636 oA «0000d= 19 «O22 : 2028 Fame+ MO} Foes ae a<br><!-- End of picture text -->  
<!-- Start of picture text -->
Figura 6. Meta-andlise da comparaco entre TCC associado @ medicamento vs. cuidados usuais associado a<br>medicamento. Desfecho: Sintomas de ansiedade a curto e médio prazo|<br>orSubgroup ‘TCCasocado amediamento Coldados esuas associa a mediamente ean Diterence ean Diterence<br>SobolisonYours5: Coo 2015, 95%2011 pacer Watame towateanom n 8187SOeda) Totl_——2 ewMean sD Toul793%3523K21a I,-4291-1136,2781-406,-7963961-863, andon, 95401,- 36) 0 711 Random,>  95801<br>Haroerty Tas 0,0,» 0.01, «19 = 0.980 # «OF<br>Testor ora eet 2 = 2,04 6 = 004<br>152isanYoung Mio20152011 paz att 6 meses753 ps trataments)Sah43 BRBSRD 7687s 172M220% 5641-10285541901 -0.9)265) —=<br>Sabir 9580 « 49 6AMK 578-861, -26) ><br>Heteroerny Tas = 0,0,» 0.00, = 1# = 0.981 # = OF<br>Testor ora eet 2 = 430 < 00001)<br>Tou 95xc0 2 401 10008 -524(-742,-2061 -<br>Herrageety Tas» 00, Chi!» 052, t= 3 = 0.916 =O tot ES<br>TesterTester owra ees 2» 4716 <0 C000 menitcs vu<br>poup otros Ce = O51. ot « 10 = 047, # = Ob Fes TCC + MED)Fao (oadon asl<br><!-- End of picture text -->  
= -6,72; IC 95%: (-9,85 a -3,59); I2 = 30%], avaliados pelo CSS. Após 6 meses após do tratamento, o grupo TCC associado a medicamento também foi superior, tanto no escore de desatenção [MD = -4,97; IC 95%: (-6,62 a -3,11); I2 = 0%] quanto no escore de hiperatividade [MD = - 3,30; IC 95%: (-6,62 a -3,11); I2 = 0%] e no da combinação dos sintomas [MD = -8,25; IC 95%: (-11,16 a -5,34); I2 = 0%]. - Melhora clínica global: A meta-análise realizada mostrou que os resultados a curto prazo não apresentaram diferença entre os grupos [MD = -0,37; IC 95%: (-1,09 a 0,34); I2 = 83%]. Após 6 meses após do tratamento, os resultados foram superiores para o grupo TCC associado a medicamento [MD = -0,37; IC 95%: (-1,25 a -0,26); I2 = 29%], avaliado pelo CGI. - Impacto do TDAH: A meta-análise realizada mostrou que o grupo TCC associado a medicamento foi superior ao grupo Cuidados usuais associado a medicamento em todos os  
<!-- Start of picture text -->
FiguraImeicamesta7. Mets Deseco:ands da Impactocomparastoentre TCC asaciado a medcamento vs. cudados usualsastociedo 8<br>do TDAM a eto paz.<br>rhea Sg ST Ee TT =a<br>a a 3.88 Sas ES<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fleursrmecamento,Desfeco:#. Met-anle da comparaImpacto do TDAHentremédioprazoacompanhiamentoTCE assoiado a medcamentodevs.atécuados6 meses pésotratamento)was associat 2<br>r es ne es Te =a<br>eT<br>142 pa at Te ;<br>wes) a) tet & Gia Iotue sit =<br>na 3 Bam Aaa =<br>Sina A Be et<br>ee eee ee<br><!-- End of picture text -->  
domínios avaliados (a) sintomas de TDAH; b) problemas emocionais; c) comportamento antissocial; d) funcionamento social; e e) todos os sintomas combinados); tanto a curto prazo (a) MD = -4,75; IC 95%: (-9,34 a -0,17); I2 = 0%; b) MD = -5,12; IC 95%: (-9,26 a - 0,98); I2 = 0%; c) MD = -1,25; IC 95%: (- 2,02 a -0,48); I2 = 0%; d) MD = -8,41; IC 95%: (-12,25 a -4,57); I2 = 0%; e) MD = - 19,64; IC 95%: (-29,30 a -9,97); I2 = 0%; como a longo prazo ( a) MD = 10,68; IC 95%: (-16,50 a -4,87); I2 = 25%; b) MD = - 10,75; IC 95%: (-15,67 a -5,83); I2 = 0%; c) MD = -2,63; IC 95%: (-3,90 a -1,35); I2 = 0%; d) MD = -9,17; IC 95%: (-13,57 a - 4,77); I2 = 19%; e) MD = -34,55; IC 95%: (-50,66 a -18,44); I2 = 45%), avaliados pela escala RATE-S. **<u>Pergunta 4: TCC + medicamento Vs. outras intervenções + medicamento</u>** - Sintomas de TDAH Philipsen, 2015 mostrou que não houve diferença entre a terapia cognitivocomportamental em grupo (TCC) em  
|**Pergunta 3: TCC Vs. intervenção não farmacológica**(van Emmerik-van, 2019, Virta, 2010 e Huang,|comparação com o tratamento clínico|
|---|---|
|2019 mostram que não houve diferença entre TCC a outra intervenção farmacológica (treinamento|individual (CM), usando a CARRS avaliada|
|cognitivo ou reforço da TCC) nos desfechos: sintomas de TDAH, desatenção, hiperatividade e qualidade|por um avaliador (p = 0,43) ou por|
|de vida, sendo que ambos os grupos melhoraram)|autorrelato (p = 0,06) após o tratamento.|
|- Sintomas de TDAH|Vidal, 2013 mostrou que não houve|
|Virta, 2010 mostra que não houve diferença entre os grupos em 24 semanas, avaliados pela BADDS de<br>autorrelato (p = 0,06); ou avaliado pelo avaliador usando a ARSR (p> 0,10).|diferença entre a TCC e psicoeducação,<br>usando a ADHD-RS (o estudo apresenta|
|Huang, 2019 mostra que também não houve diferença entre os grupos em 24 semanas, quando avaliado<br>pela ADHD-RS total (p= 0,355); ou quando avaliado pela CAARS (p= 0,223).|apenas o resultado do tamanho do efeito<br>intragrupo pré e pós tratamento, sendo<br>Cohen’s d: 0.12; p < 0,01 para o grupo|
|- Comprometimento Funcional|TCC).|
|van Emmerik-van, 2019 mostra que o grupo TCC foi superior a intervenção comparadora (TCC<br>relacionada ao distúrbio de uso de substâncias (SUD)) tanto após o tratamento (Cohen’s d = 0,34; F =|Safren, 2010 mostra que o grupo TCC foi<br>superior a relaxamento com<br>suporte|
|4,739, df = 1,282, p = 0,030) quanto após dois meses (Cohen’s d = 0,30; F= 3,165, df = 1,282, p = 0,076).<br>Virta, 2010 já mostra que treinamento cognitivo foi superior a TCC quando avaliou o comprometimento<br>funcional usando a CGI (avaliador): χ2 = 4,34, df = 1, p <0,05.|educacional no pós tratamento (−4,63 [IC de<br>95%, −8,30 a −0,96]; t 23,73 = −2,36, p =<br>0,02; d = 0,60), usando a ADHD rating<br>scale.|
|- Desatenção||
|Virta, 2010 mostra que não houve diferença entre o grupo TCC vs. treinamento cognitivo na subescala|-Melhora clínica global|
|de BADDS atenção (p = 0,09).|Foi<br>realizada<br>uma<br>meta-análise|
|Huang, 2019 também aponta que não houve diferença entre o grupo TCC vs. TCC + reforço em 24<br>semanas (p=0,218).|apresentando, que não houve diferença<br>entre os grupos [MD = -0,13; IC 95%: (-<br>0,93 a 0,67); I2 = 49%] a curto prazo,|
|- Hiperatividade / Impulsividade|avaliados pelo CGI.|
|Huang, 2019 apontou que não houve diferença entre o grupo TCC vs. TCC + reforço em 24 semanas na<br>subescala de ADHD-RS impulsividade e imperatividade: p= 0,484; assim como não houve diferença<br>entre os grupos utilizando o BIS em 24 semanas: p=0,35.|-Desatenção|  
||Philipsen, 2015 mostra que não houve|
|---|---|
|- Qualidade de vida|diferença entre os grupos em 3 meses (p =|
|van Emmerik-van, 2019 mostra que não houve diferença entre os grupos, usando o_EQ-5D_,tanto após o|0,18); em 24 semanas (p = 0,56); e em 52|
|tratamento (p= 0,564), como após dois meses (p= 0,536).|semanas (p = 0,21), utilizando a subescala|
|Virta, 2010 também mostra que não houve diferença entre os grupos, usando o Q-LES-Q: p> 0,10.|CAARS<br>-<br>problemas<br>de|
|Huang, 2019 também mostra que não houve diferença entre os grupos, usando o WHOQOL-BREF em|desatenção/memória.|
|24 semanas, em todos os domínios avaliados; domínio físico (p=0,702); domínio psicológico (p= 0,441);<br>domínio social (p= 0,320); e domínio comportamental (p=0,151).|Vidal, 2013 também aponta que não houve<br>diferença entre os grupos utilizando a<br>subescala CAARS-S Desatenção, após o|
|**Pergunta 4: TCC + medicamento Vs. outras intervenções + medicamento (**Philipsen, 2015; Vidal,|tratamento (porém, apresenta o tamanho do|
|2013; e Safren, 2010 mostram que TCC + medicamento foi superior a outra intervenção + medicamento|efeito, apenas intragrupo que foi positivo|
|para o desfecho: sintomas de TDAH (apenas em 1 ECR de 3 que avaliaram) e para hiperatividade (apenas|Cohen’s d: 0,15; p < 0,01).|
|1 estudo de dois que avaliaram. Os estudos não mostraram diferença entre os grupos avaliados para os||
|desfechos: sintomas de TDAH (em 2 ECR de 3 que avaliaram), melhora clínica global, desatenção,|-Hiperatividade / Impulsividade|
|hiperatividade (1 de 2 estudos que avaliaram) e qualidade de vida).|Philipsen, 2015 mostra que não houve<br>diferença entre grupos em 3 meses (p =|
|**TCC + medicamento vs. Outras intervenções + medicamento**|0,47), usando a subescala CAARS –<br>hiperatividade; porém o grupo TCC em|
|Figura 10. Meta-analise da comparacdo entre TCC associado a medicamento vs. Outras intervengGes associadas<br>a medicamento. Desfecho: Melhora clinica Global a curto prazo(péstratamento)..<br> <br> <br> <br> <br>|grupo foi superior ao grupo tratamento<br>clínico individual (CM) na subescala|
|TCC assocadoamedicamento _Outrasintervencbes<br>associa amedicamento<br>MeanDifference<br>eanDifference<br>_SwwtyorSubgroup<br>__Mean___SD__‘Toul<br>ean<br>$0<br>Toal_Weight1,Random,<br>95%C1<br>NvRandom,<br>95%C1<br>SLICateprazo(bswatamenoiediato)<br> <br><br><br><br>|CAARS - impulsividade em 3 meses (1,4|
|<br>    <br>Saten201<br>OL<br>an<br>ut<br>37 $42% -0531-109,0,03<br>Vial<br>2013<br>Moms<br>a7<br>Lot<br>17 gx<br>0291-032 0.90)<br>Sabtoal @5x.c9<br>56<br>$4 10008 0,13[-093,067)<br>Heteropenety Tas!<br>« 025; Ch = 379,d=<br>1=<br>**0**517<br>= 74%<br>Testforovereect2=032<br>@=075|(IC95% 0,2 a 2,6), p = 0,02).<br>Vidal, 2013 também aponta que não houve|
|<br><br> <br>     <br>  <br>Toul950<br>56<br>$4 100%<br>-0,13[-093,0671<br><br>   <br><br><br>|diferença entre os grupos utilizando a|
|Heseropenety Tat!<br>«025; Ch = 3.79, df=1» 0051 F«74%<br>4$—+—F<br>+<br>Texforoweraleec: 2 «032<br>@ =<br>075<br>2<br>u<br>aversTCC + MED} Favs[Ours+ MED<br>‘Test for subgroup differences: Not applicable<br>u<br>J<br>J|subescala CAARS-S hiperatividade ou<br>CARS impulsividade (porém, apresenta o<br>tamanho do efeito, apenas intragrupo que|  
||**Segurança**:<br>Dos estudos que avaliaram e relataram Efeitos indesejáveis, nenhum era TCC em monoterapia, mas sim<br>TCC associada a medicamento. Portanto ainda não foi possível relatar efeitos indesejáveis, específicos<br>para TCC.<br>Dittner e colaboradores (2017) relatou 8 eventos adversos em 5 pessoas do grupo TCC associada ao<br>tratamento usual e 3 eventos em 3 pessoas do grupo tratamento usual, que contemplava uso de<br>medicamentos.<br>Emilsson e colaboradores (2011), relatou que um participante do grupo TCC associado ao uso de<br>psicofármacos relatou sofrimento grave ao final do tratamento, devido a alterações nas condições<br>pessoais, e não foi avaliado no seguimento.<br>Philipsen e colaboradores (2015) mostrou que o braço que recebeu TCC em grupo associado a<br>metilfenidato ou um medicamento placebo, relatou pelo menos um evento adverso em 89,8% dos<br>pacientes, sendo que 3,9% destes relataram evento adverso grave. Já o grupo que recebeu tratamento<br>clínico habitual associado a metilfenidato ou medicamento placebo, relatou pelo menos um evento<br>adverso, em 94,2% dos pacientes, sendo que 7,7% deste grupo apresentou evento adverso grave. Os<br>autores não descrevem quais foram os eventos adversos relatados.|foi positivo e foram, respectivamente,<br>Cohen’s d: 0,19; p < 0,01; e Cohen’s d:<br>0,32; p < 0,05)<br>-Qualidade de vida<br>Vidal, 2013 mostra que não houve diferença<br>entre grupos utilizando a escala QLESQ<br>(porém, apresenta o tamanho do efeito,<br>apenas intragrupo que foi positivo Cohen’s<br>d: 0,33; p < 0,05).<br>Devido a TCC se tratar de uma intervenção<br>psicológica, comportamental e social, que<br>envolve, por exemplo, o ensino de técnicas<br>de gerenciamento de humor, habilidades<br>organizacionais, autorregulação emocional,<br>entre outras abordagens que apresentam<br>baixo risco de eventos adversos, a maioria<br>dos estudos não avaliam desfechos de<br>segurança.|
|---|---|---|
|**Efeitos indesejáveis**<br>**Quão substanciais são**|**os efeitos indesejáveis?**||
|**JULGAMENTO**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|  
<!-- Start of picture text -->
○ Trivial  Pergunta 1: TCC Vs. lista de espera  (Huang 2019 e Virta 2010 mostram que a TCC foi superior a lista  Devido a TCC se tratar de uma intervenção<br>● Pequeno  de espera para os desfechos: sintomas de TDAH e desatenção. Não houve diferença entre os grupos nos  psicológica, comportamental e social, que<br>○ Moderado  desfechos hiperatividade e qualidade de vida.) envolve, por exemplo, o ensino de técnicas<br>○ Grande  de gerenciamento de humor, habilidades<br>○ Varia  TCC vs intervenções não medicamentosas organizacionais, autorregulação emocional,<br>○ Incerto  entre outras abordagens que apresentam<br>Figura 9. Meta-andlise da comparacao entre TCC vs. Intervencdes nao medicamentosas. Desfecho: Sintomas de<br>depressioa curto prazo (pés tratamento). baixo risco de eventos adversos, a maioria<br>dos estudos não avaliam desfechos de<br>SabiotalStudyLIVraea20100VanEnmerkovan2019Hetergeney Coro orSubgroup__Mean65% prazo CD (65s Watamento83999rec105683SD Total409871035*mela)9 IncervengbesMean4858 no medicamentosasSD Total405010 1000%413%S87%Weight 1,Mean420(-231,"087-1481-6,04, andom, Diterence[-481,635] 95%1070308) INMeanRandom,Diterence95% C1 segurança.<br>Testor overt eectTal = 2»791; Oh»031.9= 0761.96, of = 1 = 0.16, = 458<br>Teal 95%.C0 ry 50 1000% 087[-481, 6351<br>Hetrgeney<br>TestlorTettr owratsyrup eectTalerences«791:Z» 031.0 Ch?»Not  1.96,agpicae= 076 of 1 = 0.16,48% Ssvous Ce TCC) Fva rereCT<br>ees ree ces areca sat<br>Pergunta 2: TCC + medicamento Vs. cuidados usuais + medicamento  (Nesta pergunta foi possível<br>realizar meta-análise devido a homogeneidade dos ECR incluídos. Os resultados foram superiores para a<br>TCC associada a medicamento nos desfechos: sintomas de TDAH, desatenção, hiperatividade, melhora<br>clínica global, impacto social e comportamental do TDAH, ansiedade e depressão. Não houve diferença<br>entre os grupos apenas na melhora clínica global a curto prazo)<br>TCC + medicamento vs. cuidados usuais + medicamento<br><!-- End of picture text -->  
imecamento,Figura2 Meta-andize daDesfecho comparagioSintomas de entreTOAM aTCC curtoprazoassociado (psa ratamento)medicament vi cidadoswsinsassociado a  
<!-- Start of picture text -->
Figura 3. Meta-andlie da comparaio entre TCC associa @ medicamento vs. cuidads ustasastciado @<br>medicamento. Desfecho:pete enoneSintomasdeCain TDAH a médionyseprazo (até 6 meses apésre o tratamento}, a<br>ase<br>Savinrans, mo ByBo finaBBR lateiS en =:<br>a nr el<br><!-- End of picture text -->  
<!-- Start of picture text -->
imediamento, iiDeseo:ic Melora Chica ba acura ie élih raze cA i is<br>ig naaNi nmi —<br>ce, eng, ona, ee =<br>pemoamniaroaany<br>pre *.. me ahaa -<br>Fiera-medicamento.5, Meta-andlseDesfecho:daSintomascomprarde depressioentre TC aassoidocurto e médio3 medicaments prazo vs. cuiadoswsiisasoido 2<br>atten Sigetentiaatee meio nates<br>suranoae “Seeger, Satan cata<br>See 8D 2 Pomerat =><br>sssenepetttemme<br>omens<br>— 2 sv may ab -<br>medicament, DesfchoSintmas de arsiedade a curt e méoparo]<br>sees SEs a ge ST ———<br>‘sp np)<br>a H 3 an Bag ><br>=o : moe iene :<br><!-- End of picture text -->  
<!-- Start of picture text -->
Fgura 7. Mets ansize da comparao ete TEC aioe medeamento i cos unas asda 3<br>redeament Desteco! mga do TDAH co par.<br>eS Oe ae TT Fro<br>oo i Boe Seg =<br>Be 2 Seg =<br>Ee. 2 #8 2S =<br>Be OF PSRs oS<br>Fgura.medcamento MeansDeterda InpactocompragodoTOAHa etre TCC no atocadorao(acompanhomentmedicament deve. ate ciddor meses umaaso asadatrate)3<br>erent Ss ee wae ET Proc<br>lino 2 sat Sse<br>1 pin mca<br>ino 3 ies A :<br>ino 2 peer e<br>lino 3 Bh GEA =<br>lino s ee<br>pee C+D) Foe ana<br><!-- End of picture text -->  
|**Pergunta 3: TCC Vs. intervenção não farmacológica**(van Emmerik-van, 2019, Virta, 2010 e Huang,|
|---|
|2019 mostram que não houve diferença entre TCC a outra intervenção farmacológica (treinamento<br>cognitivo ou reforço da TCC) nos desfechos: sintomas de TDAH, desatenção, hiperatividade e qualidade<br>de vida, sendo que ambos os grupos melhoraram)<br>- Sintomas de TDAH|
|Virta, 2010 mostra que não houve diferença entre os grupos em 24 semanas, avaliados pela BADDS de<br>autorrelato (p = 0,06); ou avaliado pelo avaliador usando a ARSR (p> 0,10).|
|Huang, 2019 mostra que também não houve diferença entre os grupos em 24 semanas, quando avaliado<br>pela ADHD-RS total (p= 0,355); ou quando avaliado pela CAARS (p= 0,223).|
|- Comprometimento Funcional<br>van Emmerik-van, 2019 mostra que o grupo TCC foi superior a intervenção comparadora (TCC<br>relacionada ao distúrbio de uso de substâncias (SUD)) tanto após o tratamento (Cohen’s d = 0,34; F =<br>4,739, df = 1,282, p = 0,030) quanto após dois meses (Cohen’s d = 0,30; F= 3,165, df = 1,282, p = 0,076).<br>Virta, 2010 já mostra que treinamento cognitivo foi superior a TCC quando avaliou o comprometimento<br>funcional usando a CGI (avaliador): χ2 = 4,34, df = 1, p <0,05.|
|- Desatenção<br>Virta, 2010 mostra que não houve diferença entre o grupo TCC vs. treinamento cognitivo na subescala<br>de BADDS atenção (p = 0,09).|
|Huang, 2019 também aponta que não houve diferença entre o grupo TCC vs. TCC + reforço em 24<br>semanas (p=0,218).|
|- Hiperatividade / Impulsividade|
|Huang, 2019 apontou que não houve diferença entre o grupo TCC vs. TCC + reforço em 24 semanas na<br>subescala de ADHD-RS impulsividade e imperatividade: p= 0,484; assim como não houve diferença<br>entre os grupos utilizando o BIS em 24 semanas: p=0,35.|  
|- Qualidade de vida|
|---|
|van Emmerik-van, 2019 mostra que não houve diferença entre os grupos, usando o_EQ-5D_,tanto após o<br>tratamento (p= 0,564), como após dois meses (p= 0,536).|
|Virta, 2010 também mostra que não houve diferença entre os grupos, usando o Q-LES-Q: p> 0,10.|
|Huang, 2019 também mostra que não houve diferença entre os grupos, usando o WHOQOL-BREF em|
|24 semanas, em todos os domínios avaliados; domínio físico (p=0,702); domínio psicológico (p= 0,441);<br>domínio social (p= 0,320); e domínio comportamental (p=0,151).|
|**Pergunta 4: TCC + medicamento Vs. outras intervenções + medicamento**(Philipsen, 2015; Vidal,|
|2013; e Safren, 2010 mostram que TCC + medicamento foi superior a outra intervenção + medicamento<br>para o desfecho: sintomas de TDAH (apenas em 1 ECR de 3 que avaliaram) e para hiperatividade (apenas<br>1 estudo de dois que avaliaram. Os estudos não mostraram diferença entre os grupos avaliados para os<br>desfechos: sintomas de TDAH (em 2 ECR de 3 que avaliaram), melhora clínica global, desatenção,<br>hiperatividade (1 de 2 estudos que avaliaram) e qualidade de vida).|
|**TCC + medicamento vs. Outras intervenções + medicamento**|  
<!-- Start of picture text -->
Figura 10. Meta-andlise da comparacao entre TCC associado a medicamento vs. Outras intervencdes associadas<br>a medicamento. Desfecho: Melhora clinica Global a curto prazo (pés tratamento).<br>TCC associadoa medicamento —_Outras intervencbes<br>saren2010‘Study3.1.1ved  Curto or2013 prazoD (pds tratamentoMeanae2imediato)om0 TotalaS Mean47an associadoLotreso a medicamento_Total_Weight1737. 483%S12% IV,‘Mean Difference-0531-108,0291-032,Random,95%030)003)Ci IN,‘MeanRandom, Difference95% Cl<br>‘Subtotal (95% Cl) 6 ‘54 100,0% -0,13 [-0,93, 067)<br>HererogenenyTestor eralTau?ee= 20,25,= 032Chi? P== 3,79,075)df = 1 = 0,05), = 74x<br>Total (95% CD 6 54 000% -0,13 [-0,93, 0,67)<br>Heterogenety<br>TestorTestor subgroaperalTau!eetdterences: = 0,25;= 032 ChitNat =6  3,79,apple= 075) f= 1, = 0,05; F = 74x +—ee ee+<br><!-- End of picture text -->  
||**Segurança**:||
|---|---|---|
||Dos estudos que avaliaram e relataram Efeitos indesejáveis, nenhum era TCC em monoterapia, mas sim<br>TCC associada a medicamento. Portanto ainda não foi possível relatar efeitos indesejáveis, específicos<br>para TCC.||
||Dittner e colaboradores (2017) relatou 8 eventos adversos em 5 pessoas do grupo TCC associada ao<br>tratamento usual e 3 eventos em 3 pessoas do grupo tratamento usual, que contemplava uso de<br>medicamentos.<br>Emilsson e colaboradores (2011), relatou que um participante do grupo TCC associado ao uso de<br>psicofármacos relatou sofrimento grave ao final do tratamento, devido a alterações nas condições<br>pessoais, e não foi avaliado no seguimento.<br>Philipsen e colaboradores (2015) mostrou que o braço que recebeu TCC em grupo associado a<br>metilfenidato ou um medicamento placebo, relatou pelo menos um evento adverso em 89,8% dos<br>pacientes, sendo que 3,9% destes relataram evento adverso grave. Já o grupo que recebeu tratamento<br>clínico habitual associado a metilfenidato ou medicamento placebo, relatou pelo menos um evento<br>adverso, em 94,2% dos pacientes, sendo que 7,7% deste grupo apresentou evento adverso grave. Os<br>autores não descrevem quais foram os eventos adversos relatados.||
|**Certeza na evidência**<br>**Qual é a certeza geral**|**na evidência sobre os efeitos?**||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|  
|○ Muito baixa|Pergunta 1: TCC Vs. lista de espera:A qualidade da evidência foi baixa para todos os desfechos||
|---|---|---|
|●  baixa|avaliados. Os fatores inconsistência e risco de viés foram os considerados para a redução do nível de||
|○ Moderado|evidências.||
|○ Alta|||
|○  Sem estudos|Pergunta 2: TCC + medicamento Vs. cuidados usuais + medicamento:A qualidade da evidência foi||
|incluídos|moderada para o desfecho: sintomas de TDAH a médio prazo. Mas a qualidade da evidência foi baixa<br>para os desfechos: sintomas de TDAH a curto prazo, melhora clínica global a médio prazo, depressão,<br>ansiedade e impacto da doença. E foi classificado como muito baixa qualidade da evidência o desfecho<br>melhora clínica global a curto prazo. O risco de viés foi o fator ponderado para a redução do nível do<br>conjunto das evidências. É importante destacar que os mesmos desfechos quando mensurados a curto<br>prazo, geraram menor qualidade da evidência.<br>Pergunta 3: TCC Vs. intervenção não farmacológica:A qualidade da evidência foi muito baixa para todos<br>os desfechos avaliados. Os fatores inconsistência, imprecisão e risco de viés foram os considerados para<br>a redução do nível de evidências.||
||Pergunta 4: TCC + medicamento Vs. outras intervenções + medicamento:A qualidade da evidência foi<br>muito baixa para todos os desfechos avaliados. Isto devido a heterogeneidade dos estudos, e alto risco de<br>viés.||
|**Valores e preferênc**<br>**Existe incerteza ou**|**ias dos pacientes**<br>**variabilidade importante no modo como as pessoas avaliam os principais desfechos?**||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|  
|○ Incerteza ou|Melhoria de sintomas (incluindo de depressão, ansiedade, desatenção e hiperatividade) e melhora clínica|Ainda existe incerteza na forma da|
|---|---|---|
|variabilidade|são essenciais para melhor desempenho acadêmico, profissional, na vida social e afetiva.|avaliação dos pacientes com TDAH, sendo|
|importante||que de 12 estudos incluídos neste relatório,|
|○ Possivelmente<br>incerto ou|A TCC pode ser realizada individual ou em grupo, assim como, em monoterapia eu associada aos<br>medicamentos específicos para o TDAH, como por exemplo o metilfenidato. Não há estudos com|observamos mais de 30 escalas que avaliam<br>os desfechos mais importantes. Diante dessa|
|variabilidade|comparação direta entre estas formas de administração, portanto, com a evidência apresentada até o|diversidade a sumarização dos resultados,|
|importante|presente momento não é possível afirmar a forma mais eficaz. Apesar disso, de forma indireta, parece|assim como a comparação entre os estudos|
|● Provavelmente sem|que o tamanho do efeito de benefício para os pacientes aumenta quando a TCC é associada a|fica prejudicada.|
|incerteza ou|medicamentos.|Há necessidade de elencar os principais|
|variabilidade||desfechos para ser avaliados em pacientes|
|importante||com TDAH, assim como, as principais|
|○ Sem incerteza ou<br>variabilidade||escalas que devem ser utilizadas para<br>avaliar estes pacientes. A escolha da escala|
|importante||deve levar em consideração as propriedades<br>de medida, sendo que há necessidade da<br>escala apresentar boa validade de construto,<br>alta confiabilidade e responsividade e ser<br>reprodutível.|
|**Balanço dos efeitos**|||
|**O balanço entre efeitos**|**desejáveis e indesejáveis favorece a intervenção ou a comparação?**||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|  
|○ Favorece a<br>comparação<br>○ Provavelmente<br>favorece a comparação<br>○ Não favorece um e<br>nem o outro<br>● Provavelmente<br>favorece a intervenção<br>○ Favorece a<br>intervenção<br>○ Varia<br>○ Incerto|Na comparação de TCC mais farmacoterapia versus cuidados usuais associado a uso de medicamento, a<br>qualidade da evidência foi moderada para o desfecho: sintomas de TDAH a médio prazo. Mas a qualidade<br>da evidência foi baixa para os desfechos: sintomas de TDAH a curto prazo, melhora clínica global a<br>médio prazo, depressão, ansiedade e impacto da doença. E foi classificado como muito baixa qualidade<br>da evidência o desfecho melhora clínica global a curto prazo. O risco de viés foi o fator ponderado para<br>a redução do nível do conjunto das evidências. É importante destacar que os mesmos desfechos quando<br>mensurados a curto prazo, geraram menor qualidade da evidência.<br>A qualidade da evidência foi muito baixa para as comparações: i) TCC versus intervenção não<br>farmacológica e ii) TCC mais farmacoterapia versus outras intervenções mais medicamentos. Os fatores<br>inconsistência, imprecisão e risco de viés foram os considerados para a redução do nível de evidências.<br>Já para a comparação de TCC em relação à lista de espera, a certeza foi baixa. Neste caso, o risco de viés<br>e a inconsistência foram os responsáveis pelo rebaixamento da qualidade.||
|---|---|---|
|**Equidade**<br>**Qual seria o impacto n**|**a equidade em saúde?**||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ Reduzida<br>○ Provavelmente<br>reduzida<br>● Provavelmente sem<br>impacto<br>○ Provavelmente<br>aumentada<br>○ Aumentada<br>○ Varia<br>○ Incerto|No SUS, a psicoterapia já é ofertada à população, contudo não há especificação sobre a modalidade.||  
|**Aceitabilidade**<br>**A intervenção é aceitá**|**vel para os principais interessados?**||
|---|---|---|
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ No|O tratamento psicológico deve ofertar suporte estruturado, focado no TDAH, com acompanhamento||
|○ Provavelmente não|regular e envolver um programa de TCC completo.||
|● Provavelmente sim<br>○ Sim<br>○ Varia<br>○ Incerto|Os riscos e os benefícios (por exemplo, como o tratamento pode ter um efeito positivo nos sintomas de<br>TDAH) da TCC devem ser ponderados. Assim como as possíveis barreiras à adesão e à continuidade do<br>tratamento, as estratégias para lidar com aquelas identificadas (como agendamento de sessões para<br>minimizar inconvenientes) e a importância da adesão a longo prazo.<br>É necessário que haja comprometimento do paciente com a terapia (inclusive fora das sessões) e que haja<br>disponibilidade do paciente para participar do acompanhamento de apoio e sustentar as estratégias<br>aprendidas.<br>O possível efeito do aumento da autoconsciência e da responsabilidade sobre o tratamento e o impacto<br>desafiador que isso pode gerar sobre o paciente e as pessoas ao seu redor.||
|**Viabilidade**<br>**A intervenção é viável**<br>|**de ser implementada?**<br>||
|**Julgamento**|**EVIDÊNCIAS DE PESQUISA**|**CONSIDERAÇÕES ADICIONAIS**|
|○ Não|A TCC é um método de terapia executada por profissional de nível superior, geralmente, com duração||
|○ Provavelmente<br>não|<br>de 60 minutos cada sessão. Nos estudos incluídos neste relatório, o número de sessões de TCC variou||
|● Provavelmente<br>sim|<br>entre 10 a 20 sessões para tratamento.||
|○ Sim|A TCC é, normalmente, realizada em consultórios já disponibilizados na prática clínica comum, não||
|○ Varia|sendo necessários reajustes para que o tratamento seja realizado. Entretanto, é necessário que a TCC seja||
|○ Incerto|feita por um profissional da saúde com conhecimento específico da terapia e da doença TDAH, além da<br>adesão do paciente ao tratamento.||

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Resumo dos julgamentos** -->
||**JULGAMENTO**||||||
|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelmente não|Provavelmente sim|**Sim**|Varia|Incerto|
|**EFEITOS**<br>**DESEJÁVEIS**|Trivial|**Pequeno**|Moderado|Grande|Varia|Incerto|
|**EFEITOS**<br>**INDESEJÁVEIS**|Grande|Moderado|**Pequeno**|Trivial|Varia|Incerto|
|**CERTEZA DA**<br>**EVIDÊNCIA**|Muito baixa|**Baixa**|Moderado|Alta|Sem estudos|incluídos|
|**VALORES**|Incerteza ou variabilidade<br>importante|Possivelmente incerto<br>ou variabilidade<br>importante|**Provavelmente incerto ou**<br>**variabilidade importante**|Sem Incerteza ou<br>variabilidade importante|||
|**BALANÇO DOS**<br>**EFEITOS**|Favorece a comparação|Provavelmente<br>favorece a comparação|Não favorece nem a<br>intervenção e nem a<br>comparação|**Provavelmente favorece**<br>**a intervenção**|Favorece a<br>intervenção|Varia|
|**ACEITABILIDADE**|Não|Provavelmente não|**Provavelmente sim**|Sim||Varia|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Tipo de recomendação** -->
|**Recomendação forte contra a**|**Recomendação contra a**|**Não favorece uma ou outra**|**Recomendação condicional a**|<br>**Recomendação forte a favor da**|
|---|---|---|---|---|
|**intervenção**|**intervenção**||**favor da intervenção**|**intervenção**|
|○|○|○|**●**|○|

---

<!-- METADADOS: doenca: Transtorno do Déficit de Atenção com Hiperatividade - TDAH | secao: **Conclusões** -->
**Recomendação**  
O painel recomendou fracamente a aplicação de abordagens de base comportamental (Terapia Cognitivo-comportamental e outras terapias de base comportamental) como componente do tratamento multimodal de TDAH em adultos. (Acrescentar o parágrafo de técnicas disponível no PCDT de TDAH)  
**Referências**  
1. BRASIL. Portaria N<sup>o</sup> 375/SAS/MS, de 10 de novembro de 2009. Diário Oficial da União. 2009.  
2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.  
3. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: A critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;358:j4008.  
- 4, Higgins JPT, Altman DG, Gøtzsche PC, Jüni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. BMJ. 2011;343:d5928.  
5. Wells GA, Shea B, O’Connell D, Peterson J, Welch V, Losos M  et al. The Newcastle-Ottawa Scale (NOS) for assessing the quality if nonrandomized studies in meta-analyses. 2012.  
6. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008;336(7650):924–6.  
7. Moberg J, Oxman AD, Rosenbaum S, Schunemann HJ, Guyatt G, Flottorp S, et al. The GRADE Evidence to Decision (EtD) framework for health system and public health decisions. Heal Res policy Syst. 2018;16(1):45.  
8. Biederman J, Quinn D, Weiss M, Markabi S, Weidenman M, Edson K, et al. Efficacy and Safety of Ritalin® LA<sup>TM</sup> , a New, Once Daily, Extended-Release Dosage Form of Methylphenidate, in Children with Attention Deficit Hyperactivity Disorder. Pediatr Drugs. 2003;5(12):833–41.  
9. Findling RL, Quinn D, Hatch SJ, Cameron SJ, DeCory HH, McDowell M. Comparison of the clinical efficacy of twicedaily Ritalin® and once-daily Equasym<sup>TM</sup> XL with placebo in children with Attention Deficit/Hyperactivity Disorder. Eur Child Adolesc Psychiatry. 2006;15(8):450–9.  
10. Findling RL, Bukstein OG, Melmed RD, López FA, Sallee FR, Arnold LE, et al. A randomized, double-blind, placebocontrolled, parallel-group study of methylphenidate transdermal system in pediatric patients with attentiondeficit/hyperactivity disorder. J Clin Psychiatry. 2008;69(1):149–59.  
11. RAPPORT MD, DENNEY C, DuPAUL GJ, GARDNER MJ. Attention Deficit Disorder and Methylphenidate: Normalization Rates, Clinical Effectiveness, and Response Prediction in 76 Children. J Am Acad Child Adolesc Psychiatry. 1994;33(6):882–93.  
12. Rapport MD, Kofler MJ, Coiro MM, Raiker JS, Sarver DE, Alderson RM. Unexpected effects of methylphenidate in attention-deficit/hyperactivity disorder reflect decreases in core/secondary symptoms and physical complaints common to all children. J Child Adolesc Psychopharmacol. 2008;18(3):237–47.  
13. Steele M, Weiss M, Swanson J, Wang J, Prinzo RS, Binder CE. A randomized, controlled, effectiveness trial of orosmethylphenidate compared to usual care with immediate-release methylphenidate in attention deficit- hyperactivity disorder. Can J Clin Pharmacol. 2006; 13(1):e50-62  
14. Simonoff E, Taylor E, Baird G, Bernard S, Chadwick O, Liang H, et al. Randomized controlled double-blind trial of optimal dose methylphenidate in children and adolescents with severe attention deficit hyperactivity disorder and intellectual disability. J Child Psychol Psychiatry Allied Discip. 2013;54(5):527–35.  
15. Tucha O, Prell S, Mecklinger L, Bormann-Kischkel C, Kübber S, Linder M, et al. Effects of methylphenidate on multiple components of attention in children with attention deficit hyperactivity disorder. Psychopharmacology (Berl). 2006;185(3):315–26.  
16. Wilens TE, McBurnett K, Bukstein O, McGough J, Greenhill L, Lerner M, et al. Multisite controlled study of OROS methylphenidate in the treatment of adolescents with attention-deficit/hyperactivity disorder. Arch Pediatr Adolesc Med. 2006;160(1):82–90.  
17. Wolraich ML, Greenhill LL, Pelham W, Swanson J, Wilens T, Palumbo D, et al. Randomized, controlled trial of OROS  
methylphenidate once a day in children with attention-deficit/hyperactivity disorder. Pediatrics. 2001;108(4):883-92  
18. Biederman J, Krishnan S, Zhang Y, McGough JJ, Findling RL. Efficacy and tolerability of lisdexamfetamine dimesylate (NRP-104) in children with attention-deficit/hyperactivity disorder: A Phase III, multicenter, randomized, double-blind, forced-dose, parallel-group study. Clin Ther. 2007;29(3):450-63.  
19. Findling RL, Childress AC, Cutler AJ, Gasior M, Hamdani M, Ferreira-Cornwell MC, et al. Efficacy and safety of lisdexamfetamine dimesylate in adolescents with attention-deficit/hyperactivity disorder. J Am Acad Child Adolesc Psychiatry. 2011;50(4):395-405  
20. Coghill D, Banaschewski T, Lecendreux M, Soutullo C, Johnson M, Zuddas A, et al. European, randomized, phase 3 study of lisdexamfetamine dimesylate in children and adolescents with attention-deficit/hyperactivity disorder. Eur Neuropsychopharmacol. 2013;23(10):1208-18.  
21. Wigal SB, Kollins SH, Childress AC, Squires L, Brams M, Childress A, et al. A 13-hour laboratory school study of lisdexamfetamine dimesylate in school-aged children with attention-deficit/hyperactivity disorder. Child Adolesc Psychiatry Ment Health. 2009;3:1–15.  
22. Newcorn JH, Nagy P, Childress AC, Frick G, Yan B, Pliszka S. Randomized, Double-Blind, Placebo-Controlled Acute Comparator Trials of Lisdexamfetamine and Extended-Release Methylphenidate in Adolescents With AttentionDeficit/Hyperactivity Disorder. CNS Drugs. 2017;31(11):999–1014.  
23. Schulz E, Fleischhaker C, Hennighausen K, Heiser P, Oehler KU, Linder M, et al. A double-blind, randomized, placebo/active controlled crossover evaluation of the efficacy and safety of Ritalin® la in children with attentiondeficit/hyperactivity disorder in a laboratory classroom setting. J Child Adolesc Psychopharmacol. 2010;20(5):377–85.  
24. Pelham WE, Waschbusch DA, Hoza B, Pillow DR, Gnagy EM. Effects of methylphenidate and expectancy on performance, self-evaluations, persistence, and attributions on a social task in boys with ADHD. Exp Clin Psychopharmacol. 2001;9(4):425-37  
25. Wigal T, Greenhill L, Chuang S, McGough J, Vitiello B, Skrobala A, et al. Safety and tolerability of methylphenidate in preschool children with ADHD. J Am Acad Child Adolesc Psychiatry. 2006;45(11):1294–303.  
26. Higgins JPT, Thomas J, Chandler J, Cumpston M, Li T, Page MJ, Welch VA (editors). Cochrane Handbook for Systematic Reviews of Interventions version 6.3 (updated February 2022). Cochrane, 2022. Available from www.training.cochrane.org/handbook.  
27. Vidal R, Castells J, Richarte V, Palomar G, García M, Nicolau R, et al. Group therapy for adolescents with attentiondeficit/hyperactivity disorder: A randomized controlled trial. J Am Acad Child Adolesc Psychiatry. 2015;54(4):275–82.  
28. Banaschewski T, Besmens F, Zieger H, Rothenberger A. Evaluation of Sensorimotor Training. Percept Mot Skills. 2001;92:137–49.  
29. Sprich SE, Safren SA, Finkelstein D, Remmert JE, Hammerness P. A randomized controlled trial of cognitive behavioral therapy for ADHD in medication-treated adolescents. J Child Psychol Psychiatry Allied Discip. 2016;57(11):1218–26.  
30. Fehlings DL, Roberts W, Humphries T, Dawe G. Attention deficit hyperactivity disorder: does cognitive behavioral therapy improve  home behavior? J Dev Behav Pediatr. 1991;12(4):223–8.  
31. Huang F, Tang Y, Zhao M, Wang Y, Pan M, Wang Y, et al. Cognitive-Behavioral Therapy for Adult ADHD : A Randomized Clinical Trial in. 2019;23(9):1035-1046  
32. Virta. Short cognitive behavioral therapy and cognitive training for adults with ADHD &ndash; a randomized controlled pilot study. Neuropsychiatr Dis Treat. 2010;6:443-53.  
33. Corbisiero S, Bitto H, Newark P, Abt-Mörstedt B, Elsässer M, Buchli-Kammermann J, et al. A Comparison of CognitiveBehavioral Therapy and Pharmacotherapy vs. Pharmacotherapy Alone in Adults With Attention-Deficit/Hyperactivity Disorder (ADHD)—A Randomized Controlled Trial. Front Psychiatry. 2018;9:1–14.  
34. Dittner AJ, Hodsoll J, Rimes KA, Russell AJ, Chalder T. Cognitive – behavioural therapy for adult attention-deficit hyperactivity disorder : a proof of concept randomised controlled trial. Acta Psychiatr Scand. 2018;137:125–37.  
35. Emilsson B, Gudjonsson G, Sigurdsson JF, Baldursson G, Einarsson E, Olafsdottir H, et al. Cognitive behaviour therapy in medication-treated adults with ADHD and persistent Symptoms: A randomized controlled trial. BMC Psychiatry. 2011;11(1):116.  
36. Safren SA, Otto MW, Sprich S, Winett CL, Wilens TE, Biederman J. Cognitive-behavioral therapy for ADHD in medication-treated adults with continued symptoms. Behav Res Ther. 2005;43(7):831–42.  
37. Young S, Khondoker M, Emilsson B, Sigurdsson JF, Philipp-Wiegmann F, Baldursson G, et al. Cognitive-behavioural therapy in medication-treated adults with attention-deficit/hyperactivity disorder and co-morbid psychopathology: A randomized controlled trial using multi-level analysis. Psychol Med. 2015;45(13):2793–804.  
38. Young S, Emilsson B, Sigurdsson JF, Khondoker M, Philipp-Wiegmann F, Baldursson G, et al. A randomized controlled trial reporting functional outcomes of cognitive–behavioural therapy in medication-treated adults with ADHD and comorbid psychopathology. Eur Arch Psychiatry Clin Neurosci. 2017;267(3):267–76.  
39. van Emmerik-van Oortmerssen K, Vedel E, Kramer FJ, Blankers M, Dekker JJM, van den Brink W, et al. Integrated cognitive behavioral therapy for ADHD in adult substance use disorder patients: Results of a randomized clinical trial. Drug Alcohol Depend. 2019;197:28–36.  
40. Philipsen A, Jans T, Graf E, Matthies S, Borel P, Colla M, et al. Effects of group psychotherapy, individual counseling, methylphenidate, and placebo in the treatment of adult attention-deficit/hyperactivity disorder a randomized clinical trial. JAMA Psychiatry. 2015;72(12):1199–210.  
41. Safren SA, Sprich S, Mimiaga MJ, Knouse L, Groves M, Otto MW. CBT VS relaxation w educationl support for Adult adhd on meds. 2010;304(8):875–80.  
42. Vidal R, Bosch R, Nogueira M, Gómez-Barros N, Valero S, Palomar G, et al. Psychoeducation for adults with attention deficit hyperactivity disorder vs.  cognitive behavioral group therapy: a randomized controlled pilot study. J Nerv Ment Dis. 2013;201(10):894–900.

---

