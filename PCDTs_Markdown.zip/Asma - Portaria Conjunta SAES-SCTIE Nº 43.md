<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE  
PORTARIA CONJUNTA SAES/SCTIE Nº 43, DE 24 DE MARÇO DE 2026.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Asma.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO EM SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, e,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Asma no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Relatório de Recomendação nº 1078/2025 e o Registro de Deliberação nº 1079/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Asma.  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Asma, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Asma.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SECTICS/MS nº 32, de 20 de dezembro de 2023, publicada no Diário Oficial da União nº 243, de 22 de dezembro de 2023, seção 1, pág. 168.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MOZART JULIO TABOSA SALES  
FERNANDA DE NEGRI  
1

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **1. INTRODUÇÃO** -->
A asma é uma doença respiratória crônica, heterogênea e complexa. É caracterizada por inflamação das vias aéreas, que desempenha papel central em sua patogênese, e por sintomas respiratórios recorrentes, como sibilância, dispneia, opressão torácica e tosse, que variam em intensidade e flutuam ao longo do tempo. Esses sintomas estão associados a um fluxo aéreo expiratório variável, que pode se tornar persistente. A doença também envolve hiperresponsividade brônquica, que contribui para os sintomas, embora essa não seja essencial para o diagnóstico<sup>1–3</sup> .  
A exemplo do cenário global, a asma configura-se como um relevante problema de saúde pública no Brasil. De acordo com dados recentes, o país ocupa a quinta posição em prevalência de asma entre adultos (4,6% da população) na América do Sul, mas sobe para a segunda posição quando se consideram os casos em crianças (12,1% da população)<sup>4</sup> . Na última década, tem-se observado uma tendência de redução nas hospitalizações por asma no país<sup>5,6</sup> . Dados do Sistema de Informações Hospitalares (SIH) indicam uma queda no número anual de internações no SUS, de 134.222 em 2013 para 87.707 em 2023, com tempo médio de permanência hospitalar em torno de 3 dias ao longo do período analisado. Em 2020, observou-se um declínio acentuado nas hospitalizações, possivelmente relacionado à pandemia de COVID-19. No entanto, em 2023, os números retornaram ao padrão do período pré-pandêmico<sup>6</sup> . Esses dados sugerem que, apesar da tendência de queda nas hospitalizações, a asma ainda representa uma carga significativa para o sistema de saúde e para a sociedade<sup>6</sup> .  
A mortalidade por asma no Brasil apresentou uma prevalência média de 1,16 casos por 100.000 habitantes/ano, no período de 2014 a 2021, segundo dados do Sistema de Informações sobre Mortalidade (SIM). A maior proporção de óbitos ocorreu entre mulheres (64%) e em pessoas com 60 anos ou mais. Já crianças e adolescentes (<18 anos) representaram 2% dos óbitos, com tendência estável no período<sup>7</sup> . Há ainda que se considerar uma notável heterogeneidade no cenário epidemiológico entre as regiões do Brasil, associada à variabilidade da situação socioeconômico<sup>4</sup> . Esses dados revelam que a mortalidade por asma no Brasil continua alta, com uma média de 6 mortes por asma/dia<sup>7</sup> .  
Apesar dos avanços terapêuticos, o controle da asma ainda enfrenta múltiplos desafios. Barreiras relacionadas à adesão inadequada ao tratamento, uso incorreto dos dispositivos inalatórios e dificuldade de percepção da gravidade da doença são comuns. Fatores ambientais, como poluição e exposição ocupacional, também contribuem para descompensações, assim como aspectos psicossociais<sup>3</sup> . Pacientes com asma grave apresentam maior morbimortalidade e são responsáveis pela maior parte da utilização dos recursos em saúde relacionados à doença. Neste contexto, o papel da equipe de saúde é fundamental ao compartilhar com o paciente os objetivos e a importância da terapia. Evidências nacionais demonstram que intervenções em centros de referência, com acompanhamento especializado e oferta de medicamentos, melhoram o controle da asma e reduz significativamente os custos para as famílias e para o SUS<sup>8</sup> .  
O principal objetivo do tratamento da asma é alcançar o controle da doença. O conceito de controle da asma compreende dois aspectos distintos: o controle das limitações clínicas atuais e a redução de riscos futuros<sup>1,3</sup> . O primeiro compreende poucos ou nenhum sintoma de asma, ausência de distúrbios do sono devido à asma e ausência de limitação em atividades físicas. Já o segundo contempla nenhuma exacerbação, função pulmonar ideal estável ou melhorada, ausência da necessidade de corticoides sistêmicos contínuos, ausência de eventos adversos dos medicamentos. Espera-se, ao atingir este objetivo, alcançar os melhores desfechos possíveis de longo prazo para o paciente<sup>3</sup> .  
Com base nesses parâmetros, a asma pode ser classificada em controlada, parcialmente controlada e não controlada, cuja avaliação, em geral, é feita em relação às últimas quatro semanas<sup>1,3</sup> . Ainda que essencial, a classificação de controle não deve  
2  
ser utilizada isoladamente. Deve-se considerar os fatores de risco para desfechos adversos futuros, como histórico de exacerbações, função pulmonar, adesão ao tratamento, técnica inalatória e exposições ambientais. Isso porque o controle dos sintomas e o risco de agravamento da doença podem ser discordantes: pacientes com sintomas mínimos ou ausentes ainda podem apresentar exacerbações graves ou fatais<sup>3</sup> .  
O conceito de controle é frequentemente confundido com o conceito de gravidade. Enquanto o controle da asma referese à intensidade com que as manifestações da doença são suprimidas pelo tratamento, a gravidade, por sua vez, está relacionada à quantidade de medicamento necessária para atingir o controle, indicando uma característica intrínseca da doença e que pode ser alterada lentamente com o tempo<sup>1</sup> . Os termos “asma leve” e “asma grave” são frequentemente usados para se referir à frequência ou intensidade dos sintomas, sem considerar o tratamento necessário para controlá-los. Como consequência, pacientes com sintomas esporádicos podem ser classificados como portadores de asma leve, ainda que necessitem de tratamento contínuo, enquanto sintomas mais frequentes, mesmo que sob baixa carga inflamatória, podem ser interpretados como sinal de gravidade. Garantir essa distinção conceitual é fundamental para orientar adequadamente as decisões terapêuticas. A gravidade da asma deve ser avaliada retrospectivamente, após pelo menos 2 a 3 meses de tratamento<sup>3</sup> . O **Quadro 1** apresenta a classificação da gravidade da asma, de acordo com a _Global Initiative for Asthma_ (GINA) 2025<sup>3</sup> .  
**Quadro 1 -** Classificação de gravidade da asma, de acordo com a _Global Initiative for Asthma_ (GINA) 2025.  
|**Gravidade**|**Definição**|
|---|---|
||bem controlada com tratamento de baixa intensidade, como corticoide inalatório (CI) com|
|Asma Leve|formoterol em baixa dose sob demanda ou CI em baixa dose diária de manutenção + beta2-<br>agonista de curta duração (SABA) sob demanda.|
||se mantém bem controlada com tratamento nas etapas 3 ou 4, por exemplo, com CI associado a|
|Asma Moderada|beta2-agonista de longa duração (CI-LABA) em dose baixa ou moderada, em qualquer uma das<br>trilhas terapêuticas recomendadas.|
|Asma Grave|não controlada apesar do uso otimizado de CI-LABA em dose alta, ou que exige esse nível de<br>tratamento para evitar perda do controle. É necessário diferenciar a asma grave da asma de difícil<br>controle decorrente de tratamento inadequado ou insuficiente, baixa adesão ou presença de<br>comorbidades, como rinossinusite crônica ou obesidade, pois essas condições exigem abordagens<br>terapêuticas distintas daquelas indicadas para casos de asma verdadeiramente refratária ao uso de<br>CI-LABA em altas doses ou mesmo a corticoides orais. Antes de definir a asma como grave, é<br>necessário excluir fatores modificáveis como baixa adesão, técnica inalatória incorreta ou<br>comorbidades não tratadas.|  
Fonte: Adaptado de Gina, 2025<sup>3</sup> .  
Segundo o GINA 2025, a asma só pode ser classificada como leve após vários meses de tratamento com corticoide inalatório, e apenas se estiver bem controlada com corticoide inalatório em baixa dose ou com corticoide inalatório - formoterol sob demanda em baixa dose. Essa definição não se aplica a pacientes com sintomas descontrolados ou parcialmente descontrolados em uso de beta2-agonista de curta duração (SABA)<sup>3</sup> .  
Além da classificação de controle e gravidade, a asma pode ser classificada pelo seu fenótipo, na tentativa de individualizar o tratamento, principalmente em casos mais complexos. Os principais fenótipos clínicos atualmente reconhecidos são<sup>3</sup> :  
3  
 **Asma alérgica:** com início geralmente na infância e associação frequente ao histórico pessoal ou familiar de condições alérgicas. Na avaliação pré-tratamento, é comum identificar inflamação eosinofílica das vias aéreas por meio da análise do escarro induzido. Em geral, pacientes com esse perfil apresentam boa resposta ao uso de corticoide inalatório;  
 **Asma não alérgica:** esse fenótipo se manifesta em indivíduos cuja asma não está relacionada a mecanismos alérgicos. A análise do escarro pode revelar um padrão inflamatório variado — com predomínio de neutrófilos, eosinófilos ou, em alguns casos, a presença de algumas células inflamatórias (perfil paucigranulocítico). Pacientes com esse tipo de asma tendem a apresentar resposta limitada ao tratamento com corticoide inalatório;  
 **Asma com predominância de tosse:** em determinados casos, tanto em crianças quanto em adultos, a tosse crônica pode ser a única manifestação clínica da asma. Nessa apresentação, conhecida como asma variante da tosse, os demais sintomas típicos da doença podem estar ausentes, sendo detectados apenas por meio de testes de provocação brônquica. Em alguns pacientes, ao longo do tempo, surgem sibilância e resposta positiva ao uso de broncodilatadores;  
 **Asma de início tardio:** em alguns casos, a asma pode ter início na idade adulta, sendo mais comum entre mulheres. Esses pacientes geralmente não apresentam perfil alérgico e, com frequência, requerem doses mais elevadas de corticoide inalatório ou demonstram resposta limitada a esse tipo de tratamento. Nesses quadros, é fundamental considerar e excluir diagnósticos diferenciais, como asma induzida por exposições ocupacionais;  
 **Asma com limitação persistente do fluxo de ar:** em pacientes com asma de longa duração, pode ocorrer o desenvolvimento de limitação do fluxo aéreo que se torna persistente ou parcialmente reversível. Esse achado costuma estar relacionado a alterações estruturais nas vias aéreas, conhecidas como remodelamento brônquico;  
 **Asma associada à obesidade:** em indivíduos com obesidade, a asma pode se manifestar com sintomas respiratórios intensos, apesar de um padrão inflamatório distinto. Nesses casos, observa-se geralmente baixa presença de eosinófilos nas vias aéreas, sugerindo mecanismos fisiopatológicos diferentes daqueles observados nos fenótipos clássicos da doença.  
No contexto da asma grave, os fenótipos inflamatórios mais reconhecidos são o da asma **eosinofílica** (relacionada a inflamação **tipo 2** [ **T2 alta** ]) e asma **não eosinofílica** (associada a inflamação, conhecida como **T2 baixa** ou **não T2 alta** )<sup>8</sup> .  
Na **asma grave eosinofílica** ( **T2 alta** ) **alérgica** , os pacientes são atópicos, apresentam inflamação eosinofílica e geralmente boa resposta ao corticoide inalatório. Já na **asma eosinofílica** ( **T2 alta** ) **não alérgica** , observa-se início tardio da doença, eosinofilia sem atopia e menor resposta aos corticoides. Esses dois grupos costumam responder bem à medicamentos direcionados à via inflamatória T2<sup>1,8</sup> .  
Em contrapartida, a **asma grave não eosinofílica** ( **T2 baixa** ) abrange um grupo heterogêneo de pacientes, que pode ser subclassificado nos fenótipos **asma neutrofílica** ou **asma paucigranulocítica** . Esses pacientes geralmente apresentam início tardio da doença, ausência de atopia e resposta frequentemente insatisfatória tanto ao corticoide quanto às terapias imunobiológicas voltadas ao bloqueio da inflamação T2<sup>1,8</sup> .  
Na caracterização da asma grave, também pode ser considerado o endótipo, que se refere a uma via fisiopatológica específica responsável pelo fenótipo. Por exemplo, na asma eosinofílica, isso envolveria identificar qual endótipo estaria associado ao aumento dos eosinófilos. No entanto, para que o endótipo seja clinicamente útil, ele deve ser identificado com base em um mecanismo molecular plausível, apresentar estabilidade longitudinal, correlacionar-se com desfechos clínicos relevantes, estar associado a um biomarcador representativo dessa via fisiopatológica (que possa ser mensurado na prática clínica), além de responder à terapia-alvo<sup>8,9</sup> . Atualmente, tais caracterizações ainda não estão disponíveis na prática clínica de forma rotineira e, por esse motivo, não serão abordadas no PCDT.  
A Atenção Primária à Saúde (APS), como porta de entrada preferencial e ordenadora do cuidado na rede de atenção à saúde, exerce papel fundamental na promoção da saúde, na prevenção de doenças, na identificação de fatores de risco e na detecção precoce, oportunizando, desta forma, a promoção de intervenções oportunas e o encaminhamento adequado para o nível  
4  
especializado de atenção à saúde quando necessário. O vínculo contínuo com os usuários e a atuação direta no território, princípios e diretrizes basilares da APS, possibilitam uma abordagem longitudinal e integral, favorecendo, por conseguinte, melhores desfechos terapêuticos e o prognóstico dos casos, além de fortalecer a coordenação do cuidado ao longo do tempo.  
Este Protocolo visa a estabelecer os critérios para diagnóstico, acompanhamento e tratamento de pacientes com asma no âmbito do SUS.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- J45.0 - Asma predominante alérgica  
- J45.1 - Asma não alérgica  
- J45.8 - Asma mista

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3. DIAGNÓSTICO** -->
É fundamental que o profissional possa identificar e reconhecer marcadores de determinantes sociais como identidade de gênero, de raça, orientação sexual, etnia, questões laborais e iniquidades sociais e econômicas como os indicadores de saúde que podem contribuir ou desenvolver situações de agravos e condições de adoecimento.  
O diagnóstico de asma ocorre mediante a identificação tanto de critérios clínicos quanto funcionais, obtidos pela anamnese, exame físico e exames de função pulmonar e deve ser baseado, sempre que possível, na combinação desses elementos ( **Quadro 2** )<sup>3</sup> .  
Determinados padrões clínicos aumentam a probabilidade diagnóstica de asma. São considerados sugestivos sintomas respiratórios, como sibilância, dispneia, tosse e/ou sensação de aperto no peito que apresentem variação ao longo do tempo e em intensidade, com piora típica durante a noite ou nas primeiras horas da manhã. Esses sintomas costumam ser desencadeados por infecções virais, exercício físico, exposição a alérgenos, mudanças climáticas, riso ou irritantes ambientais, como fumaça, poluentes ou odores fortes. Por outro lado, algumas manifestações clínicas são menos compatíveis com o diagnóstico de asma, como produção crônica de escarro, falta de ar associada a tontura ou parestesias, dor torácica e dispneia induzida por exercício com ruído inspiratório. A presença desses achados sugere a necessidade de investigação de diagnósticos diferenciais<sup>3</sup> .  
Pode ser necessária a repetição ou a realização de mais de um tipo de teste objetivo para avaliação da função pulmonar para confirmar a asma ou excluir outras causas dos sintomas respiratórios<sup>3</sup> . Quando o teste de função pulmonar não confirmar um fluxo aéreo expiratório variável, recomenda-se repeti-lo em diferentes circunstâncias, como: 1) durante o período de sintomas, 2) nas primeiras horas da manhã, ou 3) após a suspensão do broncodilatador pelo tempo recomendado, caso isso não tenha ocorrido. Nesses casos também pode-se considerar a realização de testes adicionais. Da mesma forma, em casos de exacerbações graves ou infecções virais, a resposta ao broncodilatador pode estar temporariamente ausente, sendo indicada a aplicação de testes alternativos para investigação (Quadro 2)<sup>3</sup> .  
A combinação dos testes em uma única consulta, cuja necessidade será determinada pelo quadro clínico do paciente, pode tornar o processo mais eficiente, reduzindo o tempo de deslocamento do paciente, os custos indiretos com cuidados infantis e as ausências no trabalho<sup>10.</sup> .  
É recomendado, sempre que viável, que a confirmação diagnóstica da asma ocorra antes do início do tratamento com corticoide inalatório. Isso porque a introdução precoce dessa terapia pode reduzir a variabilidade dos sintomas e das alterações funcionais, dificultando a identificação dos critérios clínicos e funcionais típicos da doença<sup>3</sup> . Em situações em que o paciente já  
5  
faz uso de medicamentos para asma, a necessidade de suspendê-los temporariamente para realização de determinados testes diagnósticos pode gerar insegurança e ansiedade. Portanto, é necessário fornecer orientações claras sobre quais medicamentos interromper e por quanto tempo<sup>10</sup> .  
**Quadro 2** - Critérios clínicos e funcionais para o diagnóstico de asma em adultos, adolescentes e crianças com idade maior ou igual a 6 anos.  
|**Fator diagnóstico**|**Critérios para diagnóstico de asma**|
|---|---|
|**Histórico de sintomas respiratórios variáveis típico**|**s**|
|| Os sintomas variam ao longo do tempo e em intensidade.<br> Os sintomas pioram à noite ou nas primeiras horas da|
|Sibilância, falta de ar, aperto no peito e/ou tosse.|manhã.|
|Termos podem variar, por exemplo, crianças podem| Os sintomas são frequentemente desencadeados por|
|descrever como respiração pesada.|exercício, riso, alérgenos, ar frio;<br> Os sintomas podem aparecer ou piorar com infecções<br>virais.|
|**Confirmação de fluxo aéreo expiratório variável**||
|Variabilidade excessiva do fluxo aéreo expiratório<br>(**um ou mais dos testes abaixo**)|Quanto maiores e mais frequentes forem as variações, maior a<br>confiabilidade no diagnóstico. Se o resultado inicial for negativo, os<br>testes podem ser repetidos durante os sintomas ou nas primeiras horas<br>da manhã. Se a espirometria não for possível, o PFE pode ser utilizado,<br>embora seja menos confiável.|
|Teste positivo de responsividade ao broncodilatador<br>(reversibilidade) com espirometria (ou PFE<sup>a</sup>)| **Adultos:**aumento no VEF₁ ou CVF ≥ 12% e ≥ 200 mL em<br>relação ao basal, com maior confiabilidade se o aumento for ≥ 15% e<br>≥ 400 mL; ou aumento no PFE ≥ 20% se a espirometria não estiver<br>disponível.<br> **Crianças:**aumento no VEF₁ ≥ 12% em relação ao basal (ou<br>no PFE ≥ 15%).<br>Medir 10 a 15 minutos após a inalação de 200 a 400 mcg de<br>salbutamol ou equivalente, comparando com os valores antes do<br>broncodilatador. O teste é mais confiável se o broncodilatador tiver<br>sido suspenso antes:<br>Beta2-agonista de curta duração (SABA) ≥ 4 horas; beta2-<br>agonista de longa duração (LABA) 24 a 48 horas<sup>b</sup>.|
|Variação excessiva no PFE medido duas vezes ao<br>dia, durante duas semanas<sup>c,d</sup>.| **Adultos:**variabilidade média diária no PFE > 10%.<br> **Crianças:**variabilidade média diária no PFE > 13%.|
|| **Adultos:**aumento no VEF₁ ≥ 12% e ≥ 200 mL (ou no PFE|
|Aumento da função pulmonar após 4 semanas de<br>tratamento com Corticoide inalatório|≥ 20%) em relação ao basal.<br> **Crianças:**aumento no VEF₁ ≥ 12% (ou no PFE ≥ 15%) em<br>relação ao basal.|  
6  
|**Fator diagnóstico**|**Critérios para diagnóstico de asma**|
|---|---|
|Teste de provocação brônquica positivo| **Adultos:**queda no VEF₁ ≥ 20% com dose padrão de<br>metacolina, ou ≥ 15% com hiperventilação padronizada, teste com<br>solução salina hipertônica ou manitol, ou > 10% e > 200mL com<br>desafio provocação por exercício padronizado.<br> **Crianças:**queda em relação à linha de base no VEF1de ><br>12% do previsto (ou no PFE de > 15%).|
||Se o VEF1diminuir durante um teste de provocação, verifique<br>se a relação VEF1/CVF também diminuiu, uma vez que a inalação<br>incompleta, por exemplo, devido à obstrução laríngea induzível ou<br>esforço insuficiente, pode resultar em uma falsa redução do VEF1.|
|| **Adultos:**variação no VEF1≥ 12% e ≥ 200 mL (ou no PFE|
|Variabilidade excessiva da função pulmonar entre<br>consultas (Boa especificidade e baixa sensibilidade).|de ≥ 20%) entre consultas.<br> **Crianças:**variação no VEF1≥ 12% (ou ≥ 15% no PFE†)<br>entre as consultas.|
|**Papel de biomarcador do tipo 2 no diagnóstico da**|**asma**|  
Em paciente com sintomas típicos de asma, mas teste de função pulmonar negativo, valores dos eosinófilos sanguíneos acima do intervalo de referência regional podem apoiar o diagnóstico de asma tipo 2, mas também podem ser decorrentes de condições não relacionadas à asma. Níveis mais baixos de eosinófilos sanguíneos **não excluem o diagnóstico de asma** . A contagem de eosinófilos sanguíneos pode variar significativamente conforme sexo, idade e horário da coleta, sendo geralmente mais elevada pela manhã.  
CVF = Capacidade Vital Forçada; PFE = Pico de fluxo expiratório;  
VEF1 = volume expiratório forçado no primeiro segundo.  
a. PFE é menos sensível do que a espirometria e deve ser utilizado apenas quando a espirometria não estiver disponível;  
b. Para testes de responsividade ao broncodilatador, utilize qualquer SABA ou um Corticoide inalatório associado a LABA, porém de início rápido;  
Tempo de suspensão do broncodilatador: SABA: 4 horas; formoterol, salmeterol: 24 horas; tiotrópio, umeclidínio, glicopirrônio: 36–48 horas;  
c. Para cada medição de PFE, use a maior das 3 leituras. Use o mesmo medidor de PFE todas as vezes, pois o PFE pode variar em até 20% entre medidores diferentes;  
d. A variabilidade diária do PFE diurno é calculada com base em duas medições realizadas por dia (para cada medição, devem ser feitas três leituras consecutivas, considerando-se a maior delas como o valor final). Com os dois valores obtidos, calcula-se inicialmente a diferença entre o maior e o menor valor do dia (maior valor − menor valor). Em seguida, essa diferença é dividida pela média entre os dois valores [(maior valor − menor valor) ÷ ((maior valor + menor valor) ÷ 2)]. Esse cálculo resulta na variabilidade do PFE para aquele dia. Após realizar esse procedimento durante 14 dias consecutivos, calcula-se a média dos 14 valores obtidos: soma-se a variabilidade diária de cada dia e divide-se o total por 14. Esse resultado representa a variabilidade média do PFE ao longo das duas semanas. A resposta ao broncodilatador pode ser temporariamente ausente durante exacerbações graves ou infecções virais, e a limitação do fluxo aéreo pode se tornar persistente com o tempo. Se a reversibilidade não estiver presente na avaliação inicial, o próximo passo dependerá da disponibilidade de outros testes e da urgência da necessidade de tratamento. Em situações clínicas urgentes, o tratamento da asma pode ser iniciado imediatamente, e os testes diagnósticos devem ser realizados nas semanas seguintes.  
Fonte: Gina (2025)<sup>3</sup> .  
O **Quadro 3** apresenta o processo para confirmar o diagnóstico em pacientes que já estão em tratamento com corticoide inalatório, de acordo com os sintomas e a função pulmonar do paciente.  
7  
**Quadro 3** - Etapas para confirmar o diagnóstico de asma em pacientes em tratamento com corticoide inalatório (CI)  
|**Situação atual**|**Etapas para confirmar o diagnóstico de asma**|
|---|---|
|Sintomas respiratórios variáveis|**Diagnóstico de asma confirmado.**Avaliar o nível de controle da asma e revisar o|
|e fluxo aéreo expiratório variável|tratamento com CI.|
||**Considerar repetir espirometria**(ou PFE<sup>a</sup>) após a suspensão do broncodilatador ou<br>durante os sintomas. Verificar variabilidade do VEF1, entre as consultas, e resposta ao<br>broncodilatador. Se ainda assim os resultados forem normais, considerar outros<br>diagnósticos.|
|Sintomas respiratórios variáveis,<br>mas sem fluxo aéreo expiratório<br>variável|**Se o VEF1 (ou PFE**<sup>**a**</sup>**) > 70% do previsto**: considerar reduzir o tratamento com CI e<br>reavaliar em 2 a 4 semanas, então considerar o teste de provocação brônquica ou repetir<br>o teste de responsividade ao broncodilatador.<br>**Se o VEF1 (ou PFE**<sup>**a**</sup>**) < 70% do previsto**: considerar iniciar ou intensificar o tratamento<br>de manutenção contendo CI por 3 meses, então reavaliar os sintomas e a função pulmonar.<br>Se não houver resposta, retomar a dose anterior de CI e encaminhar o paciente para<br>diagnóstico e investigação.|
||**Considerar repetir o teste de resposta ao broncodilatador.**Se normal, considerar a<br>investigação para diagnósticos alternativos.**Considerar reduzir o tratamento com CI**:|
|Poucos sintomas respiratórios,|Se os sintomas surgirem e a função pulmonar cair: asma é confirmada. Aumentar o|
|função pulmonar normal e sem<br>fluxo aéreo expiratório variável|tratamento com CI para a menor dose efetiva anterior; Se não houver alteração nos<br>sintomas ou na função pulmonar na menor etapa de controle: considerar interromper o<br>tratamento de manutenção com CI ou mudar para CI-formoterol sob demanda e monitorar<br>o paciente por pelo menos 12 meses.|
||**Considerar intensificar o tratamento com CI por 3 meses**, então reavaliar os sintomas|
|Falta de ar persistente e limitação|e a função pulmonar. Se não houver resposta, retomar a dose anterior de CI e encaminhar|
|persistente do fluxo aéreo|o paciente para investigação e tratamento adicionais, ou tratar da mesma forma que<br>pacientes com sobreposição asma-DPOC.|  
CI: Corticoide inalatório;  
PFE: Pico de fluxo expiratório;  
VEF1: Volume expiratório forçado no primeiro segundo;  
DPOC: Doença pulmonar obstrutiva crônica.  
a. PFE é menos sensível do que a espirometria e deve ser utilizado apenas quando a espirometria não estiver disponível. Para cada medição de PFE, use a maior das 3 leituras. Use o mesmo medidor de PFE todas as vezes, pois o PFE pode variar em até 20% entre medidores diferentes.  
Fonte: Gina (2025)<sup>3</sup> .  
O processo diagnóstico da asma envolve além da aplicação de critérios clínicos e testes objetivos, a vivência subjetiva do paciente diante de um momento frequentemente marcado por incertezas e inseguranças. Compreender essas experiências e escutar as recomendações dos pacientes pode contribuir para aprimorar a abordagem clínica, promover uma comunicação mais efetiva e fortalecer a relação entre profissional de saúde e paciente. Frente às principais percepções dos pacientes adultos sobre o processo diagnóstico da asma, os profissionais de saúde devem<sup>10</sup> :  
- Explicar de forma transparente ao paciente que o diagnóstico da asma não se baseia em um único exame definitivo e que, em muitos casos, será necessário realizar uma combinação de avaliações em diferentes momentos;  
8  
- Estar abertos a considerar as preferências e necessidades do paciente quanto à quantidade de testes realizados em uma única consulta;  
- Incluir intervalos de descanso entre os testes, sempre que possível, a fim de tornar a experiência do paciente mais confortável e menos exaustiva;  
- Considerar fatores como sazonalidade e exposições relacionadas ao ambiente de trabalho, especialmente quando os resultados dos testes não refletem plenamente os sintomas relatados pelo paciente;  
- Explicar os riscos envolvidos na interrupção dos medicamentos e informar quais ações serão tomadas caso os sintomas se intensifiquem.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.1. Exame físico e histórico de saúde** -->
O exame físico de indivíduos com asma pode, frequentemente, não apresentar alterações. Quando presentes, os achados mais comuns incluem sibilos expiratórios à ausculta pulmonar, embora esses possam estar ausentes ou audíveis apenas durante a expiração forçada<sup>3,11</sup> . Em situações de exacerbação grave, a ausência de sibilância também pode ocorrer devido à obstrução extrema do fluxo aéreo, sendo frequentemente acompanhado por outros sinais clínicos de insuficiência respiratória<sup>3</sup> .  
É importante destacar que a sibilância pode não ser exclusiva da asma, estando também presente em outras condições, como obstrução laríngea funcional, doença pulmonar obstrutiva crônica (DPOC), infecções respiratórias, traqueomalácia e aspiração de corpo estranho. Achados como estertores (crepitações) ou sibilância inspiratória, por sua vez, não são típicos da asma. A avaliação das vias aéreas superiores pode fornecer pistas adicionais, como sinais de rinite alérgica ou presença de pólipos nasais<sup>3</sup> .  
O surgimento de sintomas respiratórios ainda na infância, a presença atual ou pregressa de rinite alérgica ou eczema, bem como o histórico familiar de asma ou alergias, são fatores que aumentam a probabilidade de os sintomas respiratórios estarem relacionados à asma. Entre esses fatores, destaca-se a forte associação entre doenças das vias aéreas superiores e inferiores, sendo comum a presença concomitante de rinite alérgica em pacientes com asma<sup>3</sup> . A rinite alérgica se caracteriza por inflamação da mucosa nasal, com manifestação de sintomas como espirros, congestão nasal, prurido nasal e rinorreia, além de sintomas oculares<sup>3,12</sup> . Cabe ressaltar, contudo, que esses fatores não são exclusivos da doença e podem não estar presentes em todos os seus fenótipos<sup>3</sup> .  
Deve-se investigar ainda a presença/história de tosse, dispneia ou sensação de aperto no peito, além de possíveis variações em sua ocorrência, como piora noturna, nas primeiras horas da manhã ou em determinadas estações do ano. É igualmente importante identificar fatores desencadeantes que agravem os sintomas<sup>11</sup> .  
Em indivíduos com asma de início na vida adulta, asma previamente controlada que se tornou mal controlada, ou reaparecimento de sintomas de asma iniciada na infância, deve-se investigar a possibilidade de componente ocupacional. Para isso, é importante questionar se os sintomas permanecem os mesmos, melhoram ou pioram nos dias em que a pessoa está afastada do trabalho, como fins de semana, feriados, férias ou períodos de intervalo entre turnos. Todas as respostas devem ser registradas de forma sistemática para análise clínica e revisão em consultas futuras<sup>3,11</sup> . O **Quadro 2** apresenta informações adicionais sobre a investigação do histórico de sintomas típicos.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.2. Testes de função pulmonar** -->
A avaliação da função pulmonar é preferencialmente realizada por meio da espirometria, com a análise do VEF1 e da relação entre o VEF1 e a capacidade vital forçada (VEF1/CVF). A espirometria deve ser realizada por profissionais devidamente  
9  
capacitados, utilizando equipamentos em boas condições de funcionamento, com manutenção e calibração regulares, além do uso de filtro para minimizar o risco de transmissão de infecções<sup>3</sup> .  
A dificuldade de acesso à espirometria, especialmente em regiões remotas, é um desafio que pode levar a subdiagnósticos e dificuldades no monitoramento adequado da asma<sup>3,13</sup> . Iniciativas de tele-espirometria e espirometria na APS têm surgido como estratégia de enfrentamento para desafios de acesso<sup>13</sup> .  
Na indisponibilidade deste teste, a avaliação do Pico de Fluxo Expiratório (PFE) - (“ _Peak Flow_ ”), embora menos precisa, pode ser considerada<sup>3</sup> . Instruções sobre a aplicação do teste PFE e sobre a leitura dos valores estão disponíveis na Linha de Cuidado da Asma<sup>14</sup> . A decisão de iniciar o tratamento na falta da espirometria deve considerar a probabilidade de asma, conforme os achados clínicos, e a urgência do tratamento. A avaliação por espirometria deve ser realizada assim que possível.  
A medida do PFE serve para avaliar a variabilidade da obstrução e auxilia na monitorização clínica e na detecção precoce de crises, especialmente em pacientes com baixa percepção dos sintomas de obstrução. Na falta de espirometria, uma mudança de, pelo menos, 20% no PFE é indicativa de asma, sendo especialmente útil no diagnóstico de asma ocupacional<sup>1,3,8.</sup> Já uma variabilidade elevada no PFE pode também ser observada nos casos de sobreposição de sintomas de asma e DPOC<sup>15</sup> .  
Os parâmetros para avaliação da espirometria e do PFE são apresentados no **Quadro 2** .  
A “variabilidade” refere-se à melhora ou piora dos sintomas e da função pulmonar. Variabilidade excessiva pode ser identificada no curso de um dia (variabilidade diurna), de um dia para o outro, de uma visita para a outra, sazonalmente ou a partir de um teste de resposta. O conceito de responsividade, anteriormente denominada "reversibilidade", refere-se, em geral, à melhora rápida do VEF1 ou do PFE observada minutos após a administração de um broncodilatador de ação rápida ou à melhora progressiva ao longo de dias ou semanas após o início do tratamento com corticoide inalatório<sup>3</sup> .  
Nos casos em que a espirometria não confirmar o diagnóstico de asma, o teste de provocação brônquica pode ser especialmente útil<sup>3,16</sup> , sobretudo em indivíduos sintomáticos<sup>16</sup> . A provocação com metacolina, por exemplo, apresenta alto valor preditivo negativo, sendo eficaz para descartar o diagnóstico de asma<sup>3,16</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.3. Exames Complementares** -->
**Os exames de imagem não fazem parte da rotina diagnóstica da asma** . Porém, podem ser necessários em situações específicas, especialmente diante da suspeita de comorbidades ou diagnósticos diferenciais em adultos com asma de difícil controle.  
A radiografia simples de tórax também pode ser solicitada à avaliação inicial para diagnóstico diferencial. A tomografia computadorizada (TC) dos pulmões ou do tórax pode revelar alterações como bronquiectasias, enfisema, nódulos pulmonares e espessamento das paredes das vias aéreas. Em adultos, a presença de enfisema identificado por imagem pode auxiliar na diferenciação entre asma e DPOC, embora essas condições possam coexistir e não exista um limite radiológico bem estabelecido para essa distinção. O aprisionamento de ar, por sua vez, pode ser observado tanto na asma quanto no envelhecimento pulmonar, o que dificulta sua interpretação isolada<sup>3</sup> .  
A utilização de exames de imagem torácica não é recomendada para avaliar declínio da função pulmonar ou resposta ao tratamento. Por outro lado, a TC dos seios da face pode ser útil na identificação de alterações compatíveis com rinossinusite crônica, com ou sem presença de pólipos nasais. Em pacientes com asma grave, essa informação pode contribuir na definição da terapia biológica mais adequada<sup>3</sup> .  
A contagem de eosinófilos não é utilizada como critério diagnóstico inicial da asma, sendo uma ferramenta complementar na definição do fenótipo inflamatório na asma grave, sobretudo no perfil T2 alto<sup>10</sup> . O hemograma é útil para excluir anemia como  
10  
causa ou fator agravante de dispneia, bem como para auxiliar na identificação do fenótipo eosinofílico e identificar eventuais anormalidades da série branca.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.3.1. Investigação da sensibilização IgE específica** -->
A IgE exerce papel central na patogênese da asma alérgica, o fenótipo mais frequente da asma. A exposição a alérgenos ambientais pode iniciar uma cascata inflamatória mediada por interleucinas, IL-4, IL-5 e IL-13, além de promover a ativação de diversas células inflamatórias. Entre esses mediadores, a IL-4 e a IL-13 estimulam a produção de IgE pelos linfócitos B<sup>8</sup> .  
A investigação da sensibilização IgE específica aos aero alérgenos é realizada por meio de testes cutâneos de leitura imediata (testes de puntura ou _prick test_ ), com extratos alergênicos padronizados ou pela dosagem de IgE específica no soro. O teste cutâneo com alérgenos ambientais comuns é de realização simples e rápida, e, quando realizado por profissional experiente com extratos padronizados, apresenta alta sensibilidade e baixo custo. A medição de IgE específica não é mais confiável do que o teste cutâneo, além de ser mais onerosa, mas pode ser preferida em situações específicas, como em pacientes não cooperativos, com doenças dermatológicas extensas ou quando há risco potencial de anafilaxia conforme a história clínica. No entanto, tanto um teste cutâneo positivo quanto uma IgE específica elevada não confirmam, por si só, que o alérgeno é responsável pelos sintomas — a relação entre a exposição ao alérgeno e os sintomas clínicos deve ser confirmada pela história do paciente<sup>3</sup> .  
Na impossibilidade de acesso a métodos para a investigação da sensibilização IgE específica, dados da anamnese e exame físico podem fornecer indicativos de asma alérgica. Esse fenótipo costuma estar associado a um histórico de eczema e rinite alérgica e, potencialmente, à alergia alimentar. É mais comum em homens do que em mulheres e, geralmente, tem início na infância. Exacerbações sazonais são mais frequentes nesse fenótipo. Embora seja incomum no primeiro ano de vida, uma vez que a sensibilização a alérgenos raramente ocorre antes dos 2 anos, a prevalência da asma alérgica tende a aumentar ao longo da infância e da adolescência. Trata-se, em geral, de uma forma persistente de asma, com elevada probabilidade de continuidade na vida adulta<sup>17</sup> .  
Pacientes com asma eosinofílica alérgica grave compõem um grupo que se beneficia especialmente da avaliação de IgE, para orientação do tratamento. A fisiopatologia desse fenótipo é marcada pela ativação da via inflamatória T2 alta, desencadeada pela exposição repetida a alérgenos em indivíduos geneticamente suscetíveis, levando à produção de IgE. Diante desse mecanismo imunológico bem estabelecido, o uso de terapias anti-IgE pode ser particularmente relevante nesse grupo, desde que o diagnóstico seja confirmado por evidência objetiva de atopia e eosinofilia no sangue periférico (≥ 150 células/µL) ou no escarro induzido (≥ 2 a 3%). Já em pacientes com o fenótipo de asma grave eosinofílica não alérgica, verificam-se os mesmos parâmetros de elevação dos eosinófilos (sanguíneos ou no escarro), porém sem evidência de atopia. O reconhecimento preciso desses fenótipos é essencial para otimizar o uso de medicamentos imunobiológicos e melhorar os desfechos clínicos desses pacientes<sup>8</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.4. Critérios para identificação de asma grave** -->
Após a exclusão de fatores modificáveis como baixa adesão ao tratamento, técnica inalatória incorreta ou comorbidades não tratadas, serão considerados pacientes com asma grave aqueles que apresentarem um dos seguintes critérios:  
- Tratamento contínuo com altas doses de corticoide inalatório (budesonida, ou equivalente, superior a 800 mcg/dia  
para adultos e adolescentes ≥ 12 anos e superior a 400 mcg/dia para crianças entre 6 a 11 anos) associado a um LABA, independente do uso de outro agente controlador, no ano anterior;  
- Uso de corticoide oral com dose equivalente a, pelo menos, 5 mg diários de prednisolona, pelo menos, metade dos dias do ano anterior, para prevenir o descontrole;  
- Pacientes que permanecem com asma não controlada apesar do uso de corticoide inalatório em alta dose.  
11

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.1.5. Avaliação do controle da asma** -->
O controle da asma deve ser avaliado com base na frequência dos sintomas diurnos e noturnos, na limitação das atividades e, nos usuários de SABA na frequência de seu uso. Ferramentas como o _Asthma Control Test_ (ACT), o _Asthma Control Questionnaire_ (ACQ) e o _GINA assessment of asthma control_ podem apoiar essa avaliação no curto prazo (até 4 semanas)<sup>3</sup> . Um comparativo entre essas ferramentas está disponível no material suplementar). O ACQ possui três versões disponíveis, sendo recomendado pela GINA o uso preferencial da versão com cinco itens (ACQ-5).  
É importante avaliar separadamente os fatores de risco para exacerbações, mesmo com sintomas controlados. Entre eles, destacam-se: histórico de ≥ 1 exacerbação no último ano, tratamento exclusivo com SABA, uso excessivo de SABA, baixa adesão ao tratamento ou técnica incorreta ao utilizar o inalador com corticoide inalatório, VEF1 reduzido, tabagismo, eosinofilia e vulnerabilidades sociais. Ainda inexistem instrumentos validados para estimar o risco de exacerbação<sup>3</sup> .  
Também devem ser considerados os fatores de risco para desenvolvimento de limitação persistente do fluxo aéreo, destacando o histórico de nascimento prematuro ou baixo peso ao nascer; a ausência de tratamento com corticoides inalatórios em pacientes com histórico de exacerbação grave; e a exposição a substâncias nocivas. Adicionalmente, os fatores de risco para eventos adversos dos medicamentos, sobretudo o uso frequente dos corticoides orais e o uso prolongado de corticoide inalatório em altas doses. Aspectos relacionados ao tratamento, (incluindo a adesão e a técnica inalatória), a presença de comorbidades e as preferências do paciente também exigem atenção. Após o diagnóstico, a espirometria deve ser usada para monitorar o risco futuro, sendo recomendada no início do tratamento, entre 3 a 6 meses<sup>3</sup> .  
Manter o controle da asma pode ser desafiador diante de exposições a alérgenos, irritantes, poluentes ambientais, tabagismo, agentes ocupacionais e determinados medicamentos. Como esses fatores comprometem o alcance e a manutenção do controle clínico, devem ser sistematicamente identificados e abordados em todos os pacientes com asma, especialmente naqueles com asma de difícil controle<sup>8</sup> . Na avaliação do controle dos sintomas, é fundamental adotar questionamentos direcionados, já que a percepção do paciente sobre a frequência ou intensidade dos sintomas pode não refletir os objetivos terapêuticos atuais e varia conforme o indivíduo. Por exemplo, uma pessoa com estilo de vida sedentário pode não relatar incômodos mesmo apresentando função pulmonar reduzida, o que pode levar à impressão equivocada de bom controle dos sintomas da doença<sup>3</sup> .  
A identificação e o tratamento adequado de comorbidades que potencialmente afetam o controle da asma são parte fundamental da abordagem multidisciplinar da asma. Muitas comorbidades são tratáveis, e seu controle pode contribuir para a redução da necessidade de medicamentos, melhoria do controle da doença, da qualidade de vida e diminuição das exacerbações. Há uma alta prevalência de comorbidades em pacientes com asma grave, sendo as mais comuns: rinite, doença do refluxo gastroesofágico (DRGE), apneia obstrutiva do sono e hipertensão arterial<sup>8</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.2.1. Exame físico e histórico de saúde** -->
Embora desafiador, o diagnóstico de asma pode ser realizado em crianças ≤ 5 anos. A avaliação nessa faixa etária é essencialmente clínica, incluindo anamnese completa e exame físico para identificar sinais e sintomas compatíveis com a asma e excluir outras doenças respiratórias, especialmente aquelas associadas a infecções virais, bacterianas ou anomalias congênitas<sup>3</sup> .  
- Para a confirmação do diagnóstico, os três critérios a seguir devem ser preenchidos:  
- **Episódios de sibilância aguda recorrentes, com ou sem sintomas semelhantes aos da asma entre os episódios**  
Os episódios são caracterizados pela ocorrência de pelo menos **dois** episódios agudos de sibilância nos últimos **12** meses **ou** pelo menos **um** episódio agudo de sibilância **mais** sinais/sintomas intermitentes em outro momento<sup>3</sup> .  
Esses episódios agudos de sibilância podem ser caracterizados por sibilos na expiração, uso de musculatura acessória, falta de ar, respiração difícil e/ou pesada, cada um com duração superior a 24 horas, e podem ocorrer com ou sem infecção das  
12  
vias aéreas superiores e/ou em resposta a outros gatilhos, como exposição a alérgenos ou irritantes, sendo necessária a confirmação da sibilância ao menos uma vez<sup>3</sup> .  
Os sinais ou sintomas intermitentes que ocorrem entre os episódios agudos podem incluir tosse seca ou crises de tosse com ou sem sibilância, respiração difícil ou pesada, ou falta de ar que piora durante o sono ou após rir, chorar ou realizar atividades, com duração de alguns minutos ou horas<sup>3</sup> .  
- **Exclusão de outros diagnósticos como causa dos sintomas respiratórios**  
Para preenchimento desse critério, a avaliação clínica deve indicar que os sinais e sintomas são **improváveis** de serem explicados por um diagnóstico alternativo. É imprescindível considerar e excluir causas alternativas que possam levar a sintomas de sibilância, tosse e falta de ar (por exemplo, infecções respiratórias virais, alergias, entre outros), antes de confirmar um diagnóstico de asma. A exclusão de diagnósticos alternativos deve basear-se em uma história clínica detalhada e em um exame físico completo<sup>3</sup> .  
- **Resposta clínica oportuna ao tratamento da asma**  
A resposta clínica oportuna pode ocorrer durante um **episódio de sibilância aguda** ou durante um período de **teste terapêutico** de **2 a 3 meses** com beta2-agonista de ação curta para alívio dos sintomas (conforme necessário) ou com corticoide inalatório de manutenção mais beta2-agonista de ação curta (conforme necessário)<sup>3</sup> .  
Considera-se uma resposta clínica oportuna em episódios de sibilância aguda quando os sinais ou sintomas melhoram dentro de 20 a 60 minutos após a administração do beta2-agonista de ação curta. Em exacerbação moderada ou grave que necessite do beta2-agonista de ação curta e corticoides orais, os sinais ou sintomas melhoram dentro de 3 a 4 horas após o início do tratamento<sup>3</sup> .  
Para o teste terapêutico com beta2-agonista de ação curta (conforme necessário), uma resposta clínica significa melhora dos sinais ou sintomas dentro de 20 a 60 minutos, sendo essencial revisar a técnica de inalação e considerar diagnósticos alternativos nos casos de resposta insatisfatória. Se episódios agudos e sintomas intermitentes ocorrerem durante um tratamento adequadamente conduzido, ou se um episódio agudo exigir tratamento médico urgente, recomenda-se mudar para um período de teste com corticoide inalatório diário em baixa dose associado ao beta2-agonista de ação curta (conforme necessário)<sup>3</sup> .  
O teste terapêutico com corticoide inalatório diário associado ao beta2-agonista de ação curta (conforme necessário) deve ser considerado para crianças com histórico de um ou mais episódios agudos semelhantes à asma que tenham exigido atendimento de urgência, uso de corticoides orais ou hospitalização no último ano, e para crianças com sintomas semelhantes aos da asma que ocorrem mais de duas vezes por semana. Para este cenário, considera-se como resposta clínica oportuna quando os pais ou cuidadores relatam uma diminuição na gravidade ou frequência dos episódios agudos de sibilância da criança ou dos sintomas semelhantes à asma entre os episódios agudos. A resposta clínica ao corticoide inalatório deve ser avaliada pela frequência e gravidade dos sintomas intermitentes (diurnos e noturnos) e dos episódios semelhantes à asma<sup>3</sup> .  
Com relação à dose do corticoide inalatório para o teste terapêutico é importante destacar que a dose utilizada nos estudos que apoiam a recomendação atual (200 mcg/dia de propionato de fluticasona ou equivalente) são mais altas do que as doses recomendadas para o tratamento da asma em crianças dessa faixa etária. Sendo assim, sugere-se utilizar a dose usual inicial do dipropionato de beclometasona (100 mcg a cada 12 horas<sup>18</sup> ), mas reduzi-la para a dose diária baixa (50 mcg a cada 12 horas) assim que houver resposta clínica que indique o diagnóstico de asma<sup>3</sup> .  
Devido à natureza variável da asma, um período de teste é mais informativo quando conduzido em estações nas quais a criança apresenta mais sintomas. A resposta ao tratamento deve ser revisada antes de decidir se o tratamento será mantido ou ajustado. Uma melhora clínica acentuada durante o tratamento com corticoide inalatório apoia o diagnóstico de asma. Se a resposta clínica for convincente e os dois primeiros critérios diagnósticos tiverem sido cumpridos, o diagnóstico de asma pode  
13  
ser estabelecido. Após a conclusão do período de teste, recomenda-se reduzir a dose de corticoide inalatório para a dose mínima eficaz<sup>3</sup> .  
Se a resposta clínica estiver ausente ou for subótima, deve-se revisar a adesão ao tratamento e verificar a técnica de inalação. Se ambos forem adequados, reavaliar diagnósticos alternativos, pois a falta de resposta ao corticoide inalatório pode indicar outra condição ou asma grave. Se os episódios agudos voltarem a ocorrer, ou se os sintomas intermitentes retornarem ou piorarem após a interrupção do período de teste, isso reforça ainda mais o diagnóstico de asma<sup>3</sup> .  
Um diagnóstico definitivo nem sempre é possível em crianças pequenas. Se um ou mais dos critérios acima ainda não tiverem sido atendidos, deve-se atribuir um diagnóstico provisório de suspeita de asma e considerar o tratamento, com reavaliações periódicas para documentar a resposta ao tratamento e/ou alterações nos sintomas ao longo do tempo<sup>3</sup> .  
O **Quadro 2** apresenta informações adicionais sobre a investigação do histórico de sintomas típicos para crianças a partir de 6 anos de idade.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.2.2. Testes de função pulmonar** -->
A espirometria deve ser solicitada para pacientes a partir dos 6 anos de idade, mas é possível sua realização em crianças menores. É um exame limitado para diagnóstico de asma na infância pois, na maioria das vezes, o resultado é normal mesmo havendo doença em atividade<sup>2,3</sup> .  
Para a realização do exame, o ideal é que o paciente não esteja sob efeito de broncodilatadores. Orienta-se a suspensão do broncodilatador antes da espirometria, desde que o paciente tolere a retirada. A espirometria não deve ser realizada em indivíduos com suspeita de tuberculose. Na ausência de avaliação funcional pulmonar, a decisão de iniciar o tratamento deve considerar a probabilidade clínica de asma e a urgência terapêutica. Nesses casos, recomenda-se realizar a espirometria assim que possível<sup>2</sup> . O **Quadro 2** apresenta informações sobre a avaliação da função pulmonar por espirometria ou PFE para crianças a partir de 6 anos de idade. Nos pacientes em uso contínuo de medicamentos por asma persistente, preconiza-se espirometrias a cada 6 meses para acompanhamento clínico.  
O teste de broncoprovocação pode ser utilizado no processo diagnóstico em pacientes com mais de 5 anos de idade que apresentem sintomas compatíveis com asma, mas espirometria normal<sup>2</sup> . Devido à incapacidade da maioria das crianças ≤ 5 anos de realizar manobras expiratórias reproduzíveis, o teste de provocação brônquica tem utilidade restrita no diagnóstico de asma nessa idade<sup>3</sup>

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.2.3. Exames Complementares** -->
Teste cutâneo de puntura ( _prick test_ ) ou dosagem de IgE específica no soro são testes complementares úteis na avaliação de crianças ≤ 5 anos, assim como para outras faixas etárias. No entanto, a ausência de sensibilização a aeroalérgenos comuns não descarta o diagnóstico de asma. Embora raramente indicadas, se houver dúvida sobre o diagnóstico de asma em uma criança com chiado ou tosse, uma radiografia simples de tórax pode ajudar a excluir anormalidades estruturais, infecções crônicas como tuberculose, corpo estranho inalado ou outros diagnósticos<sup>3</sup> . O hemograma é útil para excluir anemia como causa ou fator agravante de dispneia, bem como identificar eventuais anormalidades da série branca e eosinofilia.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.2.4. Avaliação do controle de asma** -->
A avaliação do controle dos sintomas de asma em crianças de 6 a 11 anos deve considerar a presença de sintomas, o grau de limitação nas atividades diárias e o uso de medicamento de resgate. É importante investigar como a asma impacta a participação da criança em brincadeiras, atividades físicas, vida social e frequência escolar. Muitas vezes, crianças com controle  
14  
inadequado evitam esforço físico, o que pode mascarar o descontrole da doença e levar à baixa aptidão física e ao aumento do risco de obesidade<sup>3</sup> .  
As manifestações clínicas podem ser sutis, já que a percepção dos sintomas varia entre as crianças, e reduções importantes na função pulmonar podem ocorrer antes que os pais ou cuidadores percebam. Mudanças de comportamento, como irritabilidade, cansaço ou alterações de humor, são sinais frequentemente relatados em situações de controle inadequado. É fundamental combinar as informações fornecidas pela criança com aquelas relatadas pelos pais ou responsáveis, já que as crianças tendem a se lembrar apenas dos sintomas mais recentes<sup>3</sup> .  
Diversas ferramentas padronizadas estão disponíveis para avaliar o controle recente da asma nessa faixa etária, como o _Childhood Asthma Control Test_ (c-ACT), que inclui seções específicas para pais/cuidadores e crianças, e o _Asthma Control Questionnaire_ (ACQ). Um comparativo entre essas ferramentas está disponível no material suplementar. Outras escalas utilizadas incluem o _Test for Respiratory and Asthma Control in Kids_ (TRACK) e o _Composite Asthma Severity Index_ (CASI), que também incorporam histórico de exacerbações. Apesar das limitações, essas ferramentas, assim como a classificação GINA, apresentam boa correlação entre si e com a classificação clínica do controle dos sintomas. Além da análise dos sintomas, é importante considerar o risco futuro de exacerbações, declínio da função pulmonar e eventos adversos do tratamento, uma vez que o controle dos sintomas, por si só, não reflete completamente o risco de desfechos clínicos indesejáveis e pode ser influenciado por múltiplos fatores, como uso inadequado de medicamentos, comorbidades, percepção alterada dos sintomas ou exposições ambientais<sup>3</sup> .  
A avaliação do controle dos sintomas em crianças ≤ 5 anos depende majoritariamente de informações fornecidas por familiares e profissionais de saúde, que nem sempre reconhecem a frequência dos sintomas ou queixas respiratórias como manifestações de asma não controlada. Existem poucas ferramentas objetivas validadas para essa faixa etária, especialmente para menores de 4 anos. Para crianças entre 4 e 11 anos, pode-se utilizar o c-ACT. Já o questionário TRACK é validado para uso por pais ou cuidadores de crianças em idade pré-escolar com sintomas compatíveis com asma, abrangendo tanto o controle atual quanto o histórico de uso de corticoides sistêmicos no último ano. Há ainda uma ferramenta de classificação GINA especialmente para crianças ≤ 5 anos<sup>3</sup> .  
Mesmo em crianças ≤ 5 anos sem sintomas entre as crises, o risco de exacerbações pode estar presente. A avaliação do controle nessa faixa etária deve considerar os sintomas recentes, o nível de atividade habitual da criança, a necessidade de uso de medicamentos de resgate e a presença de fatores de risco para desfechos adversos. Ainda não há instrumentos validados para avaliação do controle por períodos superiores a 4 semanas, mas é importante perguntar aos pais ou cuidadores se o estado recente da criança corresponde ao que consideram normal para ela<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.3. Diagnóstico diferencial** -->
O diagnóstico diferencial da asma varia com a idade. Além disso, pode haver sobreposição de qualquer um desses diagnósticos alternativos e a asma. O **Quadro 4** apresenta os principais diagnósticos diferenciais da asma e os sintomas presentes em cada um deles, com base na GINA 2025<sup>3</sup> .  
**Quadro 4** - Diagnóstico diferencial da asma  
|**Sintomas**|**Condição**|
|---|---|
|**≤ 5 anos**||
|Tosse, coriza e congestão nasal por <10 dias; sem sintomas entre as infecções|Infecções virais recorrentes do trato<br>respiratório|  
15  
|**Sintomas**|**Condição**|
|---|---|
|Tosse ao alimentar-se; infecções torácicas recorrentes; vomita facilmente,<br>especialmente após grandes mamadas; resposta fraca aos medicamentos para asma|Refluxo gastroesofágico|
|Episódio de tosse abrupta e intensa e/ou estridor durante a alimentação ou<br>brincadeira; infecções torácicas recorrentes e tosse; sinais pulmonares focais|Aspiração de corpo estranho|
|Paroxismos prolongados de tosse, geralmente com estridor e vômitos|Coqueluche|
|Tosse úmida persistente; resposta ruim aos medicamentos para asma|Bronquite bacteriana persistente|
|Respiração ruidosa ao chorar ou comer, ou durante infecções das vias aéreas<br>superiores (inspiração ruidosa se extratorácica ou expiração se intratorácica); tosse<br>forte; retração inspiratória ou expiratória; sintomas frequentemente presentes desde<br>o nascimento; resposta ruim aos medicamentos para asma|Traqueomalácia|
|Respiração ruidosa e tosse persistentes; febre que não responde aos antibióticos<br>normais; linfonodos aumentados; resposta ruim aos broncodilatadores ou<br>corticoides inalatórios; contato com alguém que tem tuberculose|Tuberculose|
|Sopro cardíaco; cianose ao comer; retardo de crescimento; taquicardia; taquipneia<br>ou hepatomegalia; resposta insatisfatória aos medicamentos para asma|Doença cardíaca congênita|
|Tosse que começa logo após o nascimento; infecções recorrentes no peito;<br>deficiência de crescimento (má absorção); fezes soltas, gordurosas e volumosas|Fibrose cística|
|Tosse e infecções torácicas recorrentes; dificuldade respiratória neonatal, infecções<br>crônicas de ouvido e secreção nasal persistente desde o nascimento; resposta ruim<br>aos medicamentos para asma;_situs inversus_ocorre em cerca de 50% das crianças<br>com essa condição|Discinesia ciliar primária|
|Respiração persistentemente ruidosa; resposta ruim aos medicamentos para asma|Anel vascular|
|Recém-nascido prematuro; peso muito baixo ao nascer; necessita de ventilação<br>mecânica prolongada ou oxigênio suplementar; dificuldade respiratória presente<br>desde o nascimento|Displasia broncopulmonar|
|Febre e infecções recorrentes (incluindo não respiratórias); atraso no<br>desenvolvimento|Deficiência imunológica|
|**6 a 11 anos**||
|Espirros, coceira, nariz entupido, pigarro|Síndrome da tosse das vias aéreas<br>superiores|
|Início súbito de sintomas, sibilância unilateral|Corpo estranho inalado|
|Infecções recorrentes, tosse produtiva|Bronquiectasia|
|Infecções recorrentes, tosse produtiva, sinusite|Discinesia ciliar primária|
|Sopros cardíacos|Doença cardíaca congênita|
|Prematuridade, sintomas desde o nascimento|Displasia broncopulmonar|
|Tosse excessiva e produção de muco, sintomas gastrointestinais<br>**12 a 39 anos**|Fibrose cística|  
16  
|**Sintomas**|**Condição**|
|---|---|
|Espirros, coceira, nariz entupido, pigarro|Síndrome da tosse das vias aéreas<br>superiores|
|Dispneia, sibilância inspiratória (estridor)|Obstrução laríngea induzida|
|Tontura, parestesia, suspiros|Hiperventilação,<br>respiração<br>disfuncional|
|Tosse produtiva, infecções recorrentes|Bronquiectasia|
|Tosse excessiva e produção de muco|Fibrose cística|
|Sopros cardíacos|Doença cardíaca congênita|
|Falta de ar, história familiar de enfisema precoce|Deficiência de alfa1-antitripsina|
|Início súbito dos sintomas|Corpo estranho inalado|
|**40 anos ou mais**||
|Dispneia, sibilância inspiratória (estridor)|Obstrução laríngea induzida|
|Tontura, parestesia, suspiros|Hiperventilação,<br>respiração<br>disfuncional|
|Tosse, expectoração, dispneia aos esforços, tabagismo ou exposição nociva|Doença Pulmonar Obstrutiva Crônica<br>(DPOC)|
|Tosse produtiva, infecções recorrentes|Bronquiectasia|
|Dispneia com esforço, sintomas noturnos, edema de tornozelo|Insuficiência cardíaca|
|Tratamento com inibidor da enzima conversora de angiotensina (ECA)|Tosse relacionada a medicamentos|
|Dispneia com esforço, tosse não produtiva, baqueteamento digital|Doença pulmonar parenquimatosa|
|Início súbito de dispneia, dor no peito|Embolia pulmonar|
|Dispneia não responsiva a broncodilatadores|Obstrução das vias aéreas centrais|
|**Todas os pacientes ≥ 6 anos**||
|Tosse crônica, hemoptise, dispneia, fadiga, febre, suores noturnos, anorexia, perda<br>de peso|Tuberculose|
|Paroxismos prolongados de tosse, às vezes com estridor|Coqueluche|  
Fonte: Gina (2025)<sup>3</sup> .  
Há ainda outras condições que podem se manifestar de forma semelhante à asma e que precisam ser descartadas, incluindo pneumonia, doença do refluxo gastroesofágico, sinusite crônica, disfunção das pregas vocais, anafilaxia, doença respiratória exacerbada por ácido acetilsalicílico (tríade de Samter), câncer de pulmão, sarcoidose, pneumonite por hipersensibilidade, hipertensão arterial pulmonar, linfangioleiomiomatose e doenças pulmonares eosinofílicas. O acompanhamento clínico contínuo é fundamental, especialmente nos casos em que a evolução do quadro não é compatível com o padrão esperado de asma ou quando não há resposta adequada ao tratamento instituído<sup>19</sup> .  
Em atletas, o diagnóstico de asma deve ser confirmado por meio de testes objetivos, preferencialmente com teste de provocação brônquica. É fundamental excluir outras condições que podem imitar ou coexistir com a asma nesse grupo, como rinite, obstrução laríngea induzível (frequente em atividades de alta intensidade), respiração disfuncional, cardiopatias e os efeitos do excesso de treinamento<sup>3</sup> .  
17

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3.3.1. Sobreposição asma-DPOC** -->
A sobreposição asma-DPOC constitui um fenótipo clínico em que coexistem características de ambas as condições respiratórias, particularmente relevante a partir dos 40 anos. Como compartilham muitos dos principais sintomas, o diagnóstico torna-se ainda mais complexo, exigindo uma avaliação clínica cuidadosa para diferenciar os quadros e orientar o tratamento adequado<sup>3,19</sup> . Diferenciar asma e DPOC pode ser ainda mais desafiador em idosos e tabagistas<sup>3</sup> .  
O processo diagnóstico deve ser conduzido de forma sistemática e por etapas. A investigação inicial considera a probabilidade de o paciente apresentar doença crônica das vias aéreas; depois é realizada a caracterização fenotípica, a fim de diagnosticar a presença de asma, DPOC ou manifestações de ambas e/ou sobreposição de outras condições. A avaliação da função pulmonar é fundamental para confirmar a presença de obstrução persistente ao fluxo aéreo. No entanto, também é possível identificar variações na obstrução por meio de medições seriadas do pico de fluxo expiratório ou testes realizados antes e após o uso de broncodilatadores<sup>3</sup> .  
Para o diagnóstico, a avaliação clínica deve considerar a natureza e o padrão dos sintomas respiratórios: se apresentam de forma persistente ou variável. É importante investigar a presença atual ou pregressa de asma, inclusive com a idade de início, bem como exposições relevantes, como tabagismo e outros fatores de risco ambientais ou ocupacionais associados à DPOC<sup>3</sup> .  
Em relação ao tratamento, o uso de broncodilatadores de ação prolongada isoladamente é recomendado para o tratamento inicial na DPOC, mas não na asma, uma vez que há risco de exacerbações graves e morte<sup>3</sup> . O **Quadro 5** aborda o tratamento inicial em pacientes com asma e/ou DPOC<sup>3</sup> .  
**Quadro 5 -** Tratamento inicial em pacientes com asma e/ou DPOC.  
|**Sobreposição Asma-DPOC**|||
|---|---|---|
|**Fenótipos**|||
|**Altamente provável ser asma**se várias||**Provável ser DPOC**se várias|
|das seguintes características estiverem<br>presentes|**Características de asma e DPOC**|das<br>seguintes<br>características<br>estiverem presentes|
|**Tratar como Asma**|**Tratar como Asma**|**Tratar como DPOC**|
|**Histórico**|**Histórico**|**Histórico**|
|1. Sintomas variam ao longo do tempo e<br>em intensidade|1. Sintomas intermitentes ou episódicos<br>Pode ter início antes ou após os 40 anos|1.<br>Dispneia<br>persistente<br>(na<br>maioria dos dias)|
|Desencadeantes podem incluir riso,<br>exercício, alérgenos, sazonalidade|2. Pode haver histórico de tabagismo ou outras<br>exposições tóxicas ou história de baixo peso ao|Início após os 40 anos;<br>Limitação da atividade física;|
|Início antes dos 40 anos|nascer ou histórico de doenças respiratórias|Pode ter sido precedida por|
|Sintomas melhoram espontaneamente|(como tuberculose)|tosse/expectoração|
|ou com broncodilatadores (minutos) ou|3. Presença de qualquer característica de asma|2. Histórico de tabagismo ou|
|CI (dias a semanas)|(por exemplo, gatilhos comuns; sintomas que|exposições tóxicas ou história de|
|2. Diagnóstico atual de asma ou|melhoram<br>espontaneamente<br>ou<br>com|baixo peso ao nascer ou histórico|
|diagnóstico de asma na infância|broncodilatadores ou CI; diagnóstico atual de<br>asma ou diagnóstico de asma na infância)|de doenças respiratórias (como<br>tuberculose)<br>3. Sem histórico atual ou prévio<br>de asma|
|**Função pulmonar**|**Função pulmonar**|**Função pulmonar**|  
18  
<!-- Start of picture text -->
Sobreposição Asma-DPOC<br>Fenótipos<br>Altamente provável ser asma  se várias  Provável ser DPOC  se várias<br>das seguintes características estiverem  Características de asma e DPOC  das  seguintes  características<br>presentes  estiverem presentes<br>1. Limitação variável do fluxo aéreo  1. Limitação persistente do fluxo aéreo  1. Limitação persistente do fluxo<br>respiratório  respiratório  aéreo respiratório<br>2. Pode haver limitação persistente do  2.  Com  ou  sem  reversibilidade  ao  2. Com ou sem reversibilidade ao<br>fluxo aéreo broncodilatador broncodilatador<br>Tratamento farmacológico inicial<br>Tratamento com CI é essencial para  Tratamento com CI é essencial para reduzir<br>reduzir o risco de exacerbações  o risco de exacerbações graves e morte.<br>-<br>graves e morte.  A adição de LABA e/ou LAMA<br>- CI-formoterol em baixa dose  geralmente é necessária<br>-<br>sob demanda, com ou sem tratamento de  Tratamento adicional para DPOC<br>manutenção contendo CI-formoterol  conforme PCDT da DPOC<br>- Não administrar LABA  - Não administrar LABA ou LAMA<br>Tratamento conforme PCDT<br>sem CI  sem CI<br>da DPOC<br>- Corticoide  oral  de  - Corticoide oral de manutenção<br>manutenção  apenas  como  último  apenas como último recurso<br>recurso<br>Tratamento conforme PCDT da  Tratamento conforme PCDT da Asma;<br>Asma  Se necessário tratamento adicional para<br>DPOC com LAMA, seguir o PCDT da<br>DPOC.<br>Reavaliar o paciente após 2 a 3 meses. Encaminhar para atendimento especializado se houver incerteza diagnóstica ou resposta<br>inadequada<br><!-- End of picture text -->  
DPOC: Doença Pulmonar Obstrutiva Crônica;  
CI: Corticoide Inalatório; LABA: Beta2-agonista de longa duração; LAMA: Antagonista muscarínico de longa duração; PCDT: Protocolo Clínico e Diretrizes Terapêuticas. Fonte: adaptado de GINA (2025)<sup>3</sup> .  
Os pacientes devem receber orientações sobre a redução de fatores de risco modificáveis, como cessação do tabagismo, além do tratamento adequado de comorbidades. Estratégias não medicamentosas, como a prática regular de atividade física, e, nos casos de DPOC ou sobreposição asma-DPOC, a reabilitação pulmonar, também devem ser incentivadas, de acordo com o PCDT da DPOC vigente. É fundamental promover o autocuidado por meio de estratégias de autogerenciamento e garantir acompanhamento clínico regular<sup>3</sup> .  
19

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Devem ser incluídos nesse PCDT todos os pacientes que apresentarem sinais e sintomas compatíveis com o diagnóstico de asma, tendo sido excluídas outras condições que possam simular a doença.  
Adicionalmente, para o uso dos medicamentos biológicos, o paciente deverá apresentar os seguintes critérios específicos:  
- **Omalizumabe** (Anti-IgE): pacientes com idade > 6 anos, peso entre 20 e 150 kg, IgE total sérica entre 30 e 1.500 UI/mL e com asma alérgica grave não controlada apesar do uso de corticoide inalatório em dose alta associado a um LABA, de acordo com as tabelas de dose para a faixa etária aplicável;  
- **Mepolizumabe** (Anti-IL-5): pacientes com idade ≥ 6 anos com asma eosinofílica grave refratária ao tratamento com corticoide inalatório em dose alta + LABA e com contagem de eosinófilos no sangue periférico maior ou igual a 150 células/μL (crianças, adolescentes ou adultos em uso contínuo de corticoide oral) ou maior ou igual a a 300 células/μL (adultos);  
- **Benralizumabe** (Anti-IL-5Rα): pacientes adultos com asma eosinofílica grave refratária e contagem de eosinófilos no sangue periférico maior ou igual a 300 células/ μL. Pacientes adultos em uso contínuo de corticoide oral, são incluídos se apresentarem asma eosinofílica grave refratária e contagem de eosinófilos no sangue periférico maior ou igual a 150 células/µL;  
- **Dupilumabe** (Anti-IL-4 ): pacientes com idade ≥ 6 anos, com asma alérgica grave com fenótipo T2 alto não controlada apesar do uso de corticoide inalatório-LABA, pelo menos uma exacerbação grave no ano anterior com necessidade de curso de corticoide oral, confirmação de alergia mediada por IgE por meio de teste cutâneo ou IgE específica positiva para pelo menos um aeroalérgeno (IgE sérica igual ou superior a 30 UI/mL).  
**Nota** : Nos casos em que não houver resposta ao imunobiológico após 6 meses de uso e a introdução de outra terapia imunobiológica for indicada, recomenda-se considerar, para fins de elegibilidade, a contagem de eosinófilos realizada antes do início do imunobiológico em uso.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Confirmado o diagnóstico de asma e respeitados os critérios de inclusão deste Protocolo, bem como as indicações em bula aprovadas no Brasil para todos os medicamentos citados, serão excluídos os pacientes que apresentarem intolerância, hipersensibilidade ou contraindicação aos medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **6.1. Crianças ≤ 5 anos** -->
A faixa etária de crianças ≤ 5 anos ainda representa um grande desafio no cuidado, por dificuldades de diagnóstico específico de asma, assim como na escolha terapêutica. Alguns aspectos são importantes para explicar essas dificuldades no cuidado desse grupo etário são:  
- O diagnóstico de asma nessa faixa etária é dificultado pela sobreposição de sintomas com outras condições respiratórias comuns, como infecções virais, e pela presença de múltiplas causas de sibilância não relacionada à asma. A limitação na realização de testes objetivos, como espirometria, reduz a acurácia diagnóstica, sendo necessária a avaliação clínica criteriosa baseada na recorrência e padrão dos sintomas, histórico familiar e resposta ao tratamento. Ferramentas validadas para avaliação de sintomas são escassas, especialmente para menores de 4 anos, o que exige interpretação cuidadosa das informações fornecidas pelos cuidadores<sup>3,11</sup> .  
20  
- O tratamento medicamentoso é limitado pela escassez de fármacos com aprovação para uso nessa faixa etária. A administração do medicamento requer o uso de espaçadores apropriados, cuja qualidade da técnica inalatória pode ser variável, impactando a eficácia da terapia. A dificuldade em avaliar objetivamente o controle dos sintomas e o risco de exacerbações aumenta a complexidade da gestão clínica, demandando acompanhamento individualizado e, em casos de resposta inadequada, encaminhamento para avaliação especializada<sup>3,11</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **6.2. Gestantes** -->
Os níveis de controle da asma podem ser alterados durante a gestação, com pacientes apresentando melhora, piora ou manutenção do quadro clínico. A piora tende a ocorrer principalmente na metade do período gestacional e está associada à gravidade prévia da doença. A asma mal controlada aumenta o risco de complicações maternas e fetais, incluindo parto prematuro, baixo peso ao nascer, malformações, hipertensão e diabetes gestacionais, entre outras, ressaltando a importância de um acompanhamento rigoroso durante toda a gestação<sup>20</sup> . Diante deste cenário, mulheres grávidas ou que estejam planejando engravidar devem ser ativamente questionadas quanto à presença de asma, para que possam receber orientações adequadas sobre o tratamento da doença e o uso seguro de medicamentos<sup>3</sup> .  
A confirmação diagnóstica deve ser feita sempre que possível com base clínica e em testes objetivos. Entretanto, se o histórico for compatível com asma e outros diagnósticos parecerem improváveis, o tratamento com corticoide inalatório deve ser iniciado mesmo na ausência de confirmação por teste de resposta ao broncodilatador. Exames diagnósticos adicionais, como o teste de provocação brônquica (contraindicado na gestação), devem ser postergados para o período pós-parto<sup>3</sup> .  
É fundamental reforçar a importância do controle adequado da asma durante a gravidez, destacando que a manutenção do tratamento reduz os riscos de complicações tanto para a mãe quanto para o bebê. A interrupção do uso de medicamentos de manutenção, especialmente corticoides inalatórios, não é recomendada<sup>11</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **6.3. Idosos** -->
A asma em idosos é frequentemente subdiagnosticada devido à percepção reduzida dos sintomas, aceitação da dispneia como parte do envelhecimento e presença de múltiplas comorbidades. Condições como DPOC, doenças cardiovasculares e insuficiência cardíaca podem apresentar sintomas semelhantes, dificultando o diagnóstico. A sobreposição asma-DPOC também deve ser considerada, especialmente em pessoas com histórico de tabagismo ou exposição à queima de biomassa<sup>3</sup> .  
Avaliações complementares, como eletrocardiograma, radiografia de tórax, ecocardiograma e biomarcadores cardíacos, podem ser úteis na diferenciação diagnóstica. Barreiras econômicas e dificuldade de acesso a medicamentos impactam negativamente o controle da asma nessa população<sup>3</sup> . Apesar de a experiência sugerir superioridade de medicamentos em spray para essa população, a Conitec entendeu que não existem evidências robustas de que o uso dessa apresentação resulte em maior adesão do que a apresentação já fornecida pelo SUS por grupos específicos (Relatório de Recomendação nº 607, de abril de 2021).

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7. TRATAMENTO** -->
O tratamento da asma tem por principal objetivo atingir e manter o controle da doença, que é definido como a intensidade com que as manifestações da doença são suprimidas pelo tratamento. Compreende dois domínios distintos: o controle das limitações clínicas atuais, ou seja, sintomas mínimos durante o dia e ausência de sintomas à noite e ausência de limitação das atividades físicas e, um segundo domínio, de redução dos riscos futuros, ou seja, estabilização da função pulmonar, ausência do uso de corticoides sistêmicos contínuos e ausência dos eventos adversos do tratamento.  
21  
A avaliação desse controle deve ser feita de maneira objetiva e periódica, utilizando-se instrumentos, como o questionário de controle da asma da GINA ou o teste de controle da asma (como o ACT).  
O gerenciamento efetivo da asma começa com o estabelecimento de uma parceria entre a pessoa com asma (ou seus pais, responsáveis ou cuidadores) e a equipe de saúde. Essa relação colaborativa é essencial para alcançar o controle sustentado da doença e prevenir exacerbações<sup>3,11</sup> .  
Para isso, é necessário que os profissionais de saúde estejam capacitados a se comunicar de forma clara, empática e acessível, promovendo um ambiente no qual as dúvidas possam ser esclarecidas e as decisões clínicas sejam compartilhadas. O desenvolvimento de habilidades de comunicação tem impacto direto na satisfação do paciente, nos desfechos clínicos e na redução da utilização de serviços de saúde. Outro aspecto a ser considerado é o reconhecimento da alfabetização em saúde (também chamada de literacia ou letramento) do paciente, que se refere a sua capacidade de obter, processar e entender as informações relacionadas ao cuidado com a asma<sup>3</sup> .  
As expectativas e metas terapêuticas devem partir de uma definição conjunta. O objetivo do tratamento deve ser alcançar os melhores resultados possíveis a longo prazo, o que inclui o controle sustentado dos sintomas (ausência ou mínima frequência de sintomas, noites sem interrupções por crises asmáticas, capacidade plena para a práticas de atividades físicas) e a redução do risco a longo prazo de mortalidade relacionada à asma, exacerbações, limitação persistente do fluxo de ar e eventos adversos do tratamento<sup>3</sup> .  
O tratamento da asma deve seguir um ciclo contínuo de avaliação, intervenção e revisão da resposta do paciente, considerando tanto o controle dos sintomas quanto o risco futuro de exacerbações e eventos adversos, assim como as preferências individuais do paciente. As recomendações terapêuticas baseiam-se nos esquemas terapêuticos preferenciais das etapas 1 a 5, que variam conforme a faixa etária (adultos/adolescentes, crianças de 6 a 11 anos) e das etapas 1 a 4 para crianças menores de 5 anos. Na Etapa 5, há diferentes recomendações em nível populacional dependendo do fenótipo inflamatório. Cada etapa fornece a melhor relação risco/benefício para controle dos sintomas e redução de risco<sup>3</sup> .  
No cuidado individualizado, a tomada de decisão compartilhada deve considerar características clínicas e fenotípicas do paciente, exposições ambientais, risco de exacerbações ou outros eventos adversos, bem como preferências, preocupações e questões práticas como técnica inalatória, adesão, acesso e custo do tratamento<sup>3</sup> . Para fortalecimento da integração entre a APS e Atenção Especializada (AE), recomenda-se a utilização das Linhas de Cuidado do Ministério da Saúde<sup>2</sup> , os protocolos de regulação/encaminhamentos do Ministério da Saúde e o Telessaúde Brasil Redes (0800 644 6543).

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.1. Tratamento não medicamentoso** -->
O tratamento não medicamentoso envolve diferentes ações educativas e cuidados ambientais importantes para o controle da doença. A educação do paciente e familiares é parte fundamental da terapêutica da asma. Deve-considerar aspectos culturais e orientar sobre a importância do tratamento da inflamação das vias aéreas em longo prazo, incluindo um plano de ação por escrito e individualizado, orientando o uso correto do dispositivo inalatório e revisando a técnica inalatória em cada consulta.  
No tratamento não medicamentoso da asma, a cessação do tabagismo (conforme PCDT do Tabagismo vigente) e a redução da exposição à fumaça de tabaco são medidas fundamentais<sup>3,8</sup> . Em todas as consultas, deve-se incentivar fortemente as pessoas com asma que fumam cigarros ou utilizam dispositivos eletrônicos para fumar (DEF) a interromper o seu uso, oferecendo, sempre que possível, acesso a aconselhamento e programas de apoio. Pais, responsáveis e cuidadores de crianças com asma devem ser orientados a não fumar, bem como a não permitir que isso ocorra em ambientes frequentados pela criança, como cômodos da casa ou veículos<sup>3</sup> .  
A investigação e a gestão de exposições ocupacionais a alérgenos e irritantes também devem ser parte do tratamento não medicamentoso da asma. Evitar alérgenos internos ou domésticos, como poeira, ácaro e pelos de animais, é apenas uma das  
22  
recomendações nos cuidados ambientais, além da remediação de umidade e mofo, que pode trazer benefícios clínicos. Para pacientes sensibilizados, a redução da exposição a alérgenos externos e internos, como pólen, pode ser orientada durante períodos de maior concentração<sup>3</sup> .  
No contexto da asma ocupacional, a identificação precoce e a eliminação dos agentes sensibilizantes são fundamentais. Pacientes sensibilizados devem ser removidos de qualquer exposição adicional o mais rapidamente possível<sup>3,8</sup> . Sempre que houver suspeita ou confirmação de asma ocupacional, o encaminhamento para avaliação e orientação especializada é recomendado, se disponível.  
A atividade física deve ser incentivada de forma rotineira para pessoas com asma, em razão dos seus benefícios amplos à saúde geral<sup>3,8</sup> . A prática regular está associada à melhora da aptidão cardiopulmonar e pode contribuir positivamente para o controle da asma e a função pulmonar. Em adultos com asma moderada a grave, intervenções estruturadas com atividade física demonstram impacto positivo nos sintomas e na qualidade de vida. Embora não haja evidência suficiente para recomendar uma modalidade específica de exercício, é fundamental orientar os pacientes sobre estratégias para prevenir a broncoconstrição induzida pelo exercício, como o uso de corticoides inalatórios-formoterol em baixa dose conforme necessário e antes da atividade física, ou o uso regular de corticoides inalatórios diários. Medidas adicionais incluem aquecimento prévio e, quando indicado, o uso de SABA ou combinação corticoides inalatórios-SABA antes do exercício. O “Guia de atividade física para a população brasileira”<sup>21</sup> , do Ministério da Saúde, traz recomendações no contexto da asma, sendo um recurso relevante para o incentivo à prática adequada de atividade física. Adicionalmente, os pacientes devem ser orientados a adotar uma alimentação saudável e, nos casos de obesidade, estimulados à perda de peso<sup>3</sup> . A equipe de saúde deve se organizar junto aos profissionais especializados, como os componentes das equipes multiprofissionais, para mapear locais no território ou desenvolver ações e programas relacionados às práticas corporais e atividades físicas dentro dos estabelecimentos de saúde e polos do Programa Academia da Saúde na APS.  
Outra medida que deve ser considerada é o incentivo para que os pacientes lidem com o estresse emocional, se isso piorar sua asma. Sempre que possível, os pacientes devem ser encaminhados para serviços de apoio que possam auxiliá-los a lidar com os impactos da doença e do tratamento, incluindo no período pós-exacerbações. A avaliação da necessidade de encaminhamento para acompanhamento psicológico ou psiquiátrico deve ser parte da abordagem clínica, particularmente em pacientes com sintomas de ansiedade ou depressão<sup>3</sup> .  
Para crianças, adultos e idosos com asma, é fundamental seguir e manter o calendário vacinal local atualizado, incluindo imunizações contra influenza e covid-19, dada a sua importância na prevenção de exacerbações e complicações respiratória<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.2. Tratamento medicamentoso** -->
Antes de iniciar ou ajustar qualquer tratamento medicamentoso, é essencial garantir que o paciente compreenda sua condição e saiba como utilizar corretamente os recursos terapêuticos disponíveis. A alfabetização em saúde e o treinamento são parte fundamental do cuidado com a asma, pois aumentam a eficácia do tratamento e reduzem o risco de complicações. Todos os pacientes com asma devem<sup>3</sup> :  
- Receber tratamento individualizado, de acordo com o controle e gravidade da doença, preferências do paciente e  
- acesso aos medicamentos;  
- Receber informações claras sobre a doença e os objetivos do tratamento;  
- Ser treinados para usar corretamente os dispositivos inalatórios, que são a principal forma de administração dos  
- medicamentos, e revisar a técnica inalatória e cada consulta;  
- Aprender a reconhecer sinais de piora e a utilizar um plano de ação por escrito para manejar os sintomas de forma  
- autônoma.  
23  
A via inalatória é sempre a preferida para o tratamento de manutenção e de alívio, por utilizar uma dose menor de medicamento, com maior efeito local e menos eventos adversos sistêmicos.  
Os medicamentos para o tratamento da asma podem ser divididos em medicamentos de controle ou alívio. Os medicamentos de controle são a base do tratamento da asma persistente e possuem atividade anti-inflamatória. Além do corticoide inalatório, os corticoides orais, os LABA (sempre associados ao corticoide inalatório) e os imunobiológicos também são considerados medicamentos controladores. Os medicamentos de alívio são aqueles usados de acordo com a necessidade do paciente, atuando rapidamente no alívio dos sintomas e na reversão da broncoconstrição, sendo os SABA os representantes desta classe no PCDT<sup>3</sup> .  
A escolha do inalador deve considerar a disponibilidade do dispositivo no sistema de saúde, a capacidade do paciente em utilizá-lo corretamente após o treinamento e o impacto ambiental dos diferentes tipos de dispositivos (sempre que possível). A técnica inalatória deve ser verificada com frequência e o paciente deve ser submetido a revisões regulares. Além disso, a adesão ao tratamento com corticoide inalatório deve ser estimulada, mesmo em pessoas com sintomas pouco frequentes<sup>3</sup> .  
O tratamento da asma envolve diversos termos técnicos que podem parecer complexos à primeira vista. Expressões como medicamento de alívio e controle, além de acrônimos e siglas, são frequentemente utilizadas na literatura, consultas e prescrições. Entender o significado e a função desses termos é fundamental para profissionais, pacientes e familiares/cuidadores. O **Quadro 6** apresenta os principais termos utilizados no tratamento medicamentoso da asma, com uma explicação simplificada para cada um deles.  
**Quadro 6 -** Terminologia para o tratamento medicamentoso da asma.  
|**Termo**|**Significado**|**Função no Tratamento da asma**|
|---|---|---|
|CI (_em inglês, ICS_)|Corticoide inalatório|Reduz a inflamação dos brônquios; previne sintomas e<br>exacerbações. Os CI disponíveis no SUS são a<br>beclometasona e a budesonida.|
|SABA|Beta2-agonista de curta duração|Alívio rápido dos sintomas. Os SABA disponíveis no<br>SUS são o salbutamol e fenoterol.|
|LABA|Beta2-agonista de longa duração|Relaxamento prolongado dos brônquios; usado com CI.<br>O LABA disponível no SUS é o formoterol.|
|Corticoides sistêmicos|Corticoide<br>de<br>uso<br>sistêmico<br>administrado por via oral ou injetável.|O tratamento de curto prazo é importante no tratamento<br>de exacerbações agudas graves, com efeitos principais<br>observados após 4 a 6 horas.|
|Terapia complementar|Variam conforme o fenótipo, idade e<br>características<br>clínicas,<br>incluem<br>medicamentos imunobiológicos|Tratamento adicional para pacientes com sintomas<br>persistentes ou exacerbações, apesar da técnica<br>inalatória correta e boa adesão ao tratamento da Etapa<br>4.|
|CI-formoterol|Combinação de Corticoide inalatório<br>com formoterol (LABA de início de<br>ação rápida)|Pode ser usado como controle diário e para alívio dos<br>sintomas.|
|Medicamento de alívio<br>_(em inglês, Reliever)_|Medicamento<br>usado<br>quando<br>há<br>sintomas ou antes do exercício. Às|Alivia rapidamente a obstrução das vias aéreas.|  
24  
|**Termo**|**Significado**|**Função no Tratamento da asma**|
|---|---|---|
||vezes são chamados de inaladores de<br>resgate.||
|Medicamento<br>de<br>controle|Medicamento de uso contínuo, mesmo<br>sem sintomas|Mantém a doença sob controle e reduz risco de<br>exacerbações, além de reduzir a inflamação das vias<br>aéreas.|
||Terapia de Manutenção e Alívio (com||
|MART|CI-formoterol). A MART também é às<br>vezes chamada de SMART (terapia de<br>manutenção e alívio de inalador único)|Regime em que o mesmo medicamento é usado<br>regularmente e sob demanda, para as etapas 3 e 4.|
|AIR|Uso de um medicamento de alívio com<br>ação anti-inflamatória: Inalador de<br>alívio que contém um CI de baixa dose<br>e um SABA ou formoterol (LABA de<br>início de ação rápida)|Regime usado sob demanda quando há sintomas ou<br>antes do exercício/exposição a alérgenos.|
|Etapas do tratamento<br>(Steps)|Níveis progressivos de tratamento (1 a<br>4 ou 1 a 5, conforme a faixa etária)|Determinam a intensidade do tratamento com base no<br>controle da asma.|
|Regimes de tratamento<br>(Tracks)|Possíveis<br>regimes<br>de<br>tratamento<br>baseados no tipo de medicamento de<br>alívio usado|A GINA apresenta dois regimes principais: Regime 1<br>(preferencial, com CI-formoterol) e Regime 2<br>(alternativo, com SABA como alívio)|  
ICS: _Inhaled Corticosteroid_ (CI, em inglês);  
AIR: Anti-inflammatory Reliever; GINA: _Global Initiative for Asthma_ ; Fonte: Sociedade Brasileira de Pneumologia e Tisiologia<sup>1</sup> , GINA (2025)<sup>3</sup> .  
O tratamento da asma deve seguir alguns princípios básicos<sup>3</sup> :  
- **Não é recomendado** tratar a asma **apenas com SABA** , devido ao risco aumentado de exacerbações graves e morte<sup>3,11</sup> ;  
- **Todos** os pacientes devem receber tratamento contendo **corticoide inalatório** , com o objetivo de reduzir o risco de  
- exacerbações graves e controlar os sintomas;  
- A **prevenção de exacerbações graves** deve ser considerada **prioridade** em todas as etapas do tratamento, a fim de reduzir riscos para os pacientes; minimizar a sobrecarga ao sistema de saúde e diminuir a necessidade de uso de corticoides orais, cujos eventos adversos se acumulam com o uso prolongado;  
- O tratamento para adultos e adolescentes é organizado em **dois regimes (tracks)** , com base principalmente na escolha do medicamento de alívio. O tratamento pode ser intensificado ou reduzido dentro de um mesmo regime, mantendo o mesmo medicamento de alívio em cada etapa. Também é possível mudar de um regime para outro, conforme as necessidades individuais do paciente;  
- A **intensificação do tratamento** deve ser considerada apenas se a asma permanecer não controlada, apesar da boa adesão ao tratamento e da técnica inalatória adequada. Antes de qualquer aumento de etapa: Confirmar que os sintomas são realmente de asma; identificar e corrigir técnica inalatória inadequada, falta de adesão, exposição a alérgenos, presença de multimorbidades; e fornecer medidas de educação sobre asma;  
- Após o controle adequado da asma ser alcançado e mantido por um período razoável de estabilidade clínica, pode-se  
- considerar a **redução** gradual do tratamento. O objetivo é identificar a menor dose eficaz que controle tanto os sintomas quanto as exacerbações. Ainda não há consenso sobre o tempo ideal de estabilidade clínica para iniciar essa redução. Sugere-se que  
25  
diminuir as doses de corticoide inalatório em 25 a 50% em intervalos de 3 meses é viável e seguro para a maioria dos pacientes adolescentes e adultos. Por outro lado, especialistas destacam a necessidade de um período mais prolongado, entre 9 e 12 meses, o qual possibilitaria a avaliação longitudinal de outros parâmetros clínicos, como a hiperresponsividade brônquica. Assim, recomenda-se que a redução deve ser feita sempre a critério médico e de forma individual, após estabilidade clínica mínima de 3 meses;  
- A dose e o esquema de administração dos **medicamentos de controle** devem ser **otimizados** para minimizar o risco de eventos adversos e reduzir a necessidade de corticoides orais;  
- Uso **excessivo de SABA** (ex.: mais de três frascos de 200 doses ao ano, o que corresponde a uso médio superior a diário) aumenta o risco de exacerbações da asma e aumenta o risco de controle inadequado dos sintomas. É importante destacar que o SABA é um medicamento essencial no controle de exacerbações graves, porém seu uso excessivo no alívio de sintomas diários indicam a necessidade de reavaliação do tratamento de controle;  
- Combinações de **corticoides inalatórios com LABA que não contenham formoterol não devem ser usadas como medicamento de alívio** devido ao início de ação mais lento (ex.: corticoides inalatórios-salmeterol) e a falta de segurança ou eficácia com uso mais de uma vez ao dia (ex.: corticoides inalatórios-vilanterol, corticoides inalatórios-indacaterol);  
- Os **corticoides inalatórios-formoterol não devem ser utilizados como medicamento de alívio** em pacientes que fazem uso regular de corticoides inalatórios-LABA com um **LABA que não seja o formoterol** devido à falta de evidência clínica sobre segurança e eficácia dessa associação;  
- **Não interromper completamente o uso de corticoide inalatório** , exceto quando for necessário temporariamente para confirmar o diagnóstico de asma;  
- Para a maioria dos pacientes com asma, corticoides inalatórios em **baixa dose** proporcionam a maior parte dos benefícios clínicos esperados. Alguns podem necessitar de **dose média** se a asma permanecer descontrolada ou se houver exacerbações recorrentes, mesmo com boa adesão e técnica inalatória adequada. Uma **dose alta** de corticoides inalatórios, isoladamente ou em combinação com LABA, é indicada apenas para uma minoria de pacientes e, quando utilizada por longos períodos, está associada a maior risco de eventos adversos locais e sistêmicos.  
- Ainda é importante considerar que certos medicamentos podem **interferir na resposta ao tratamento da asma** , como anti-inflamatórios não esteroides e betabloqueadores. Portanto, a decisão de uso deve ser individualizada, avaliando riscos e benefícios<sup>1,3</sup>

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **Adultos e adolescentes** -->
O **Quadro 7** apresenta a conduta clínica para adultos e adolescentes com asma, de acordo com as diretrizes GINA (2025)<sup>3</sup> .  
**Quadro 7 -** Conduta inicial em caso de adultos e adolescentes (≥12 anos) com asma  
|**Apresentação inicial dos sintomas**|**Regime 1 (preferencial)**|**Regime 2**<sup>**a**</sup>|||
|---|---|---|---|---|
|||CI de baixa<br>usado,<br>em|dose sempre que o SAB<br> <br>inaladores<br>combinados|A for<br> <br>ou|
|Sintomas de asma infrequentes (por exemplo, 1<br>a 2 dias/semana ou menos)|CI-formoterol de dose<br>baixa, sob demanda<sup>b</sup><br>**(Etapa 1 e 2)**|separados,<br>probabilidad<br>Considerar,<br>combinação,<br>imediatamen<br>**(Etapa 1)**|para<br>pacientes<br>com<br>e de aderência ao CI diário.<br>preferencialmente,<br>ou com o CI admini<br>te após o SABA|baixa<br> <br>em<br>strado|  
26  
|**Apresentação inicial dos sintomas**|**Regime 1 (preferencial)**|**Regime 2**<sup>**a**</sup>|
|---|---|---|
|||CI de baixa dose (controle) + SABA sob|
|Sintomas de asma menos de 3 a 5 dias por<br>semana, com função pulmonar normal ou<br>levemente reduzida||demanda. Antes de escolher essa opção,<br>considerar a provável baixa adesão ao CI<br>diário<br>**(Etapa 2)**|
|Sintomas de asma na maioria dos dias (por<br>exemplo, 4 a 5 dias/semana ou mais); ou<br>acordando devido à asma uma vez por semana<br>ou mais, ou função pulmonar baixa;<br>**Condições adicionais ao iniciar na Etapa 3:**ou<br>tabagismo ativo; ou baixa percepção de<br>broncoconstrição; ou exacerbação grave recente<br>ou histórico de exacerbação com risco de vida;|CI-formoterol de dose<br>baixa em MART<br>**(Etapa 3)**|CI-LABA de baixa dose (controle) + SABA<br>ou CI+ SABA sob demanda; ou CI de média<br>dose (controle) + SABA ou CI-SABA sob<br>demanda. Considere a provável adesão ao<br>tratamento de manutenção diária<br>**(Etapa 3)**|
|ou hiperresponsividade grave das vias aéreas; ou|||
|exposição atual a gatilho alérgico sazonal.|||
|||CI-LABA de dose média + SABA ou CI-<br>SABA sob demanda. Considere a provável|
|Sintomas diários de asma, acordando à noite com|CI-formoterol de dose|adesão ao tratamento de manutenção diária. CI|
|sintomas uma vez por semana ou mais, com|média<br>em<br>MART|de alta dose + SABA sob demanda é outra|
|baixa função pulmonar|**(Etapa 4)**|opção, mas a adesão é pior do que com ICS-<br>LABA em combinação|
|||**(Etapa 4)**|  
Legenda: CI: Corticoide inalatório; SABA: Beta2-agonista de curta duração; LABA: Beta2-agonista de longa duração; a. o regime 2 é uma alternativa quando o regime 1 não é viável ou o paciente está clinicamente estável, com boa adesão ao tratamento atual e sem exacerbações no último ano; b. O CI-formoterol de baixa dose é chamado de anti-inflamatório de alívio ( _AIR_ ) porque alivia os sintomas e reduz a inflamação. Fonte: adaptado do GINA(2025)<sup>3</sup>

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **Etapas de tratamento** -->
Para crianças de 6 a 11 anos, o tratamento inicial da asma também deve ser adaptado à frequência e à gravidade dos sintomas. Para aquelas com sintomas infrequentes, como 1 a 2 dias por semana ou menos, recomenda-se o uso de corticoide inalatório de baixa dose sempre que o SABA for utilizado, podendo ser administrados em inaladores combinados ou separados ( **etapa 1** )<sup>3</sup> .  
Quando os sintomas ocorrem de 2 a 5 dias por semana, uma das opções é o uso de corticoide inalatório de baixa dose (controle) com SABA sob demanda ( **etapa 2** ). Também é possível considerar o uso de corticoide inalatório sempre que o SABA for utilizado. A adesão ao tratamento diário deve ser considerada na escolha<sup>3</sup> .  
Se a criança apresenta sintomas na maioria dos dias da semana (4 a 5 dias por semana) ou acorda à noite por causa da asma pelo menos uma vez por semana, o tratamento pode incluir corticoide inalatório-LABA de baixa dose (controle) com SABA sob demanda ou corticoide inalatório de média dose (controle) com SABA sob demanda ( **etapa 3** )<sup>3</sup> .  
27  
Em casos de sintomas diários e despertares noturnos com função pulmonar reduzida pelo menos uma vez por semana, é indicado o uso de corticoide inalatório-LABA de dose média (controle) com SABA sob demanda ( **etapa 4** )<sup>3</sup> .  
Se a apresentação inicial da asma ocorrer durante uma exacerbação aguda, a orientação é tratar como uma crise. Deve-se iniciar o tratamento imediatamente, enquanto se realiza uma breve anamnese e exame físico direcionado. Se houver sinais de gravidade ou risco iminente de exacerbação, iniciar SABA, oxigênio controlado e corticoide sistêmico, e providenciar transferência urgente para unidade de atendimento especializado. Exacerbações leves podem ser tratadas na APS, conforme os recursos disponíveis<sup>3</sup> .  
O exame físico deve avaliar sinais de gravidade (nível de consciência, sinais vitais, uso de musculatura acessória, sibilos), possíveis complicações (como pneumonia ou pneumotórax) e causas alternativas de dispneia aguda (como insuficiência cardíaca ou obstrução laríngea). A oximetria de pulso deve ser realizada, considerando saturação < 90% como indicativo de tratamento intensivo. Em maiores de 5 anos, o PFE pode ser usado como medida complementar<sup>3</sup> .  
Na alta após o controle da exacerbação, deve-se iniciar o tratamento conforme as etapas 3 ou 4. O paciente deve receber prescrição de tratamento de manutenção regular contendo corticoide inalatório, medicamento de alívio sob demanda e um curto curso de corticoide oral. O uso exclusivo de SABA não é recomendado. Recomenda-se agendar uma consulta de seguimento entre 2 e 7 dias após a alta, considerando o contexto clínico e social. Nessa revisão, o profissional deve avaliar se a crise foi resolvida e se o corticoide oral pode ser suspenso. Também é necessário verificar o controle dos sintomas, os fatores de risco, investigar a possível causa da exacerbação e revisar ou fornecer um plano de ação por escrito. O tratamento de manutenção com corticoide inalatório geralmente pode ser reduzido aos níveis anteriores após 2 a 4 semanas, mas, se a crise foi precedida por sinais de controle cronicamente inadequado, e a técnica inalatória e adesão estiverem adequadas, pode ser necessário intensificar o tratamento<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **Etapa 5: terapias adicionais** -->
Pacientes de qualquer idade com sintomas persistentes ou exacerbações, apesar da técnica inalatória correta e boa adesão ao tratamento da Etapa 4, devem ser avaliados por especialistas em asma grave, quando disponíveis. Esses pacientes devem realizar fenotipagem e terapias adicionais devem ser consideradas. Para isso, é necessário otimizar a terapia em uso, tratar fatores de risco modificáveis e comorbidades<sup>3</sup> .  
A combinação de altas doses de corticoide inalatório isolado ou associado ao LABA pode ser considerada em adultos e adolescentes, quando: o controle não é alcançado com MART em dose média ou corticoide inalatório em dose média + LABA. No entanto, para a maioria dos pacientes, o aumento da dose de corticoide inalatório tende a oferecer benefício clínico limitado, enquanto eleva o risco de eventos adversos, como a supressão adrenal. Por isso, o uso de dose alta deve ser administrado por tempo limitado, geralmente entre 3 a 6 meses, com reavaliação cuidadosa da resposta clínica<sup>3</sup> . Para crianças entre 6 e 11 anos de idade, também pode-se optar pelo aumento da dose de corticoide inalatório-LABA para uma dose pediátrica alta do CI. Essa abordagem deve ser conduzida por um curto período, com reavaliação entre 2 e 3 meses, além de monitoramento atento de possíveis eventos adversos<sup>3</sup>  
Se o paciente estiver usando MART com dose média e precisar iniciar imunobiológico, não é recomendado trocar para corticoide inalatório-LABA convencional + SABA sob demanda, pois isso pode aumentar o risco de exacerbações. Há evidência limitada sobre iniciar MART em pacientes que já usam LAMA ou imunobiológico<sup>3</sup> .  
Para identificação do fenótipo inflamatório, a eosinofilia sanguínea a partir de 150/μl ou a sensibilização IgE específica positiva são sugestivas de inflamação T2 alta em pacientes com asma grave. É importante destacar que pode haver variabilidade na contagem de eosinófilos sanguíneos por diferentes causas, como pelo uso de corticoide oral, pelo tabagismo e pelo horário da coleta, estando geralmente mais elevados no período da manhã. Assim, quando não houver evidência de eosinofilia, recomendase repetir a coleta até três vezes, em momentos como durante a piora da asma e antes da administração de corticoide oral, ou  
28  
entre 1 e 2 semanas após um curso desse medicamento ou ainda na menor dose possível tolerada pelo paciente, antes de se concluir que o paciente não apresenta esse fenótipo<sup>3</sup> .  
Ressalta-se que esses não são critérios de elegibilidade para os imunobiológicos, mas sim os parâmetros utilizados para a identificação inicial do fenótipo da asma grave. Assim, as recomendações da GINA<sup>3</sup> sobre terapia biológica para asma, adaptadas à disponibilidade no SUS, estão disponíveis no **Quadro 8** .  
29  
**Quadro 8 -** Medicamentos imunobiológicos para tratamento da asma no Sistema Único de Saúde (SUS).  
|**Imunobiológico**|**Alvo**|**Idade aprovada**|**Indicação Principal**|**Outros critérios de Elegibilidade**|**Via**|**Eventos Adversos Comuns**|
|---|---|---|---|---|---|---|
|Omalizumabe|Anti-IgE|Acima de 6 anos|asma alérgica (T2<br>alto)<br>grave<br>não<br>controlada|Peso entre 20 e 150 kg; IgE total sérica entre 30-1.500<br>UI/mL; pelo menos uma exacerbação grave no ano anterior<br>com necessidade de curso de<br>corticoide oral.|Subcutânea|Reações no local da injeção;<br>anafilaxia<br>em<br>aproximadamente 0,2% dos<br>pacientes.|
|Mepolizumabe|Anti-IL-5|A partir de 6<br>anos|asma<br>eosinofílica<br>grave<br>(T2<br>alto)<br>refratária|Contagem de eosinófilos no sangue periférico ≥ 300<br>células/µL ou ≥ 150 células/µL (para aqueles em uso<br>contínuo de corticoide oral), em adultos, a partir dos 18<br>anos; e ≥ 150 células/µL, e/ou eosinófilos detectados no<br>escarro em uma proporção ≥ 2%, em crianças entre 6 e 11<br>anos e adolescentes entre 12 e 17 anos; pelo menos, uma<br>exacerbação grave no ano anterior com necessidade de<br>curso de corticoide oral.|Subcutânea|Em adultos, reações no local da<br>injeção e anafilaxia rara. Em<br>crianças,<br>distúrbios<br>da<br>pele/tecido subcutâneo e do<br>sistema nervoso (por exemplo,<br>dor<br>de<br>cabeça,<br>tontura,<br>síncope).|
|Benralizumabe|Anti-IL-5Rα|Adultos|asma<br>eosinofílica<br>grave refratária|Contagem de eosinófilos no sangue periférico ≥ 300<br>células/µL, ou ≥ 150 células/µL (para aqueles em uso<br>contínuo de corticoide oral); pelo menos uma exacerbação<br>grave no ano anterior com necessidade de curso de<br>corticoide oral.|Subcutânea|Dor de cabeça e reações no<br>local da injeção são comuns,<br>mas leves.|
|Dupilumabe|Anti-IL-4α|A partir de 6<br>anos|asma alérgica grave<br>com fenótipo T2-<br>alto, não controlada|Pelo menos uma exacerbação grave no ano anterior com<br>necessidade de curso de corticoide oral; confirmação de<br>alergia mediada por IgE por meio de teste cutâneo ou IgE<br>específica positiva para pelo menos um aeroalérgeno (IgE<br>sérica igual ou superior a 30 UI/mL).|Subcutânea|Reações locais comuns e leves;<br>eosinofilia transitória (4 a<br>13%);<br>raros<br>casos<br>de<br>granulomatose<br>eosinofílica<br>com<br>poliangiite<br>após<br>redução/suspensão<br>de<br>corticoide oral.|  
IgE: Imunoglobulina E; IL-5: Interleucina 5; IL-5Rα: Subunidade alfa do receptor da interleucina-5IL-4α: Subunidade alfa do receptor de interleucina 4; UI/mL: Unidades Internacionais por mililitro; µL: Microlitro. Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
30  
Ao escolher entre as terapias imunobiológicas disponíveis, considere se: o paciente satisfaz os critérios de elegibilidade de uso, comorbidades do tipo 2-alto, preditores de resposta à asma (exacerbações, controle de sintomas, função pulmonar, eventos adversos, intensidade do tratamento e satisfação do paciente), frequência de uso, via de administração e preferência do paciente. É importante considerar também que **não se deve suspender completamente o tratamento com corticoide inalatório**<sup>3</sup> .  
Os preditores de resposta aos imunobiológicos variam conforme o agente utilizado. Para o omalizumabe, embora eosinófilos no sangue periférico ≥ 260 células/µL tenha sido sugerido como preditor, o ponto de corte é controverso e não universalmente aceito. A resposta ao mepolizumabe tende a ser melhor em pacientes com eosinófilos no sangue periférico ≥ 150 células/µL, exacerbações prévias, asma de início na idade adulta e polipose nasal. O benralizumabe apresenta melhor resposta em pacientes com uso contínuo de corticoides orais, polipose nasal, VEF1 < 65% do previsto e asma de início tardio. Já para o dupilumabe, entre os principais preditores estão os níveis elevados de eosinófilos no sangue periférico<sup>8</sup> , embora seja importante destacar que pacientes com contagem basal de eosinófilos maior que 1.500 células/μL não foram incluídos nos estudos de fase 3, de modo que, até o momento, não há dados de segurança para o uso nesse grupo<sup>8</sup> .  
O uso adicional de corticoides orais em baixa dose (até 7,5 mg/dia de prednisona ou equivalente) pode ser considerado como **último recurso** no tratamento da asma grave em adultos. Essa decisão deve ser tomada apenas após a exclusão de causas contribuintes e a tentativa de outras terapias adicionais, incluindo medicamentos imunobiológicos. O uso crônico de corticoides orais está associado a riscos importantes, como supressão adrenal e osteoporose, que tendem a aumentar com a exposição cumulativa, inclusive em pacientes com asma leve ou moderada, frequentemente expostos a cursos desnecessários fora do contexto de exacerbação. Estratégias voltadas ao uso racional e seguro desses medicamentos são essenciais para minimizar sua utilização inadequada e seus impactos negativos. Quando o tratamento se estender por três meses ou mais, recomenda-se orientação sobre mudanças no estilo de vida e a prescrição de medidas preventivas para osteoporose e fraturas<sup>3,8,22</sup> .  
Brometo de tiotrópio foi avaliado pela Conitec, e obteve recomendação final de não incorporação para tratamento da asma moderada e grave em pacientes adultos e crianças (com idade de 6 anos ou mais), conforme Relatório de Recomendação n° 612/2021 da Conitec. Na ocasião da avaliação, a Conitec considerou que, ao passo que há evidência do benefício do tiotrópio considerando função pulmonar e outros desfechos intermediários, há escassez de evidências que demonstrem a superioridade do tiotrópio frente ao tratamento já disponível no SUS (combinação de LABA + corticoide inalatório – formoterol + budesonida), considerando desfechos primordiais, como exacerbações graves, hospitalização ou qualidade de vida<sup>3</sup> .  
As **Figuras 1 e 2** apresentam as etapas de tratamento da asma em adolescentes (12 anos ou mais) e adultos, e crianças entre 6 e 11 anos de idade, respectivamente.  
31  
**Figura 1** - Etapas de tratamento da asma em adolescentes (12 anos de idade ou mais) e adultos.  
<!-- Start of picture text -->
Dose média ou alta’ deCl + FORMRegime diaria 4 (preferencial)": e dose baixa de Cl + FORM sob demanda<br>Etapas "Regime| Dose média ou alta’ de Cl + LABA e SABAzialternativoy’:; (ou Cl dose baixa ——SSSSS~S~+ SABA) sob demanda |<br>[——____AdlicionarFenotipar: caso de asma alérgicaCO em dosegrave: baixa (ultimaassociar omalizumabe opcdo)_  (anti-Ig&)<br>caso de asma eosinofilica grave: associar mepolizumabe (Anti-IL-5) ou<br>benralizumabe (Anti-receptor « de ILS); caso de asma alérgica grave com fendtipo<br>Te alto: associar dupilumabe (Anti-IL-4a)<br>Etapa4 Dose média de Cl + FORMRegimediria e1 dose(preferencial:baixa de Cl + FORM sob demanda<br>i Regime 2 (alternative): |<br>| Dose média de Cl + LABA diaria e SABA (ou Cl dose baixa + SABA) sob demandaOU |<br>Cl dose alta diaria<br>e SABA (ou Cl dose baixa + SABA) sob demanda |<br>Regime 4 (preferencial:<br>Dose baixa de Cl + FORM didria e sob demanda (MART)<br>Etapa3 |i Regime2 (alternativo): |<br>ii Dose baixaDose médiade Cl  de+ LABA Cl didriadiria e SABAe SABA (ou(ouClCldose dosebaixa baixa+ SABA)+ SABA) sob sob demanda demanda OU ||<br>: Regime (preferenciab:<br>tapa2 Dose baixa de Cl + FORM sob demanda<br>| Regime 2 (alternativo): i<br>| Dose baixa de Cl diaria<br>e SABA (ou Cl dose baixa + SABA) sob demanda |<br>Etapat Dose baixaRegimede Cl1 (preferencial):+ FORM sob demanda<br>ee Regimezialternative: SSS<br>| Dose baixa de Cl + SABA sob demanda (dose baixa de Cl sempre que usar SABA) i<br>TODOS OS ASMATICOS<br>Controle ambiental + rever controle da asma e risco futuro regularmente<br><!-- End of picture text -->  
CI – corticoide inalatório; SABA – beta2-agonista de curta duração; FORM – formoterol; LABA – beta2-agonista de longa duração; MART – terapia de manutenção e alívio; CO – corticoide oral; IgE – Imunoglobulina E; IL-5 – interleucina 5; IL-4α - Subunidade alfa do receptor de interleucina 4; *Recomendada apenas por um período limitado de 3 a 6 meses, quando um bom controle não foi obtido com dose média de CI + FORM ou CI+LABA. Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
32  
**Figura 2** - Etapas de tratamento da asma em crianças entre 6 e 11 anos de idade.  
<!-- Start of picture text -->
Dose média ou alta’ de Cl + LABA e SABA sob demanda<br>Etapa5 Adicionar CO em dose baixa em tiltima op¢ao<br>Fenotipar: caso de asma alérgica grave: associar omalizumabe (anti-IgE);<br>caso de asma eosinofilica grave: associar mepolizumabe (Anti-IL-5); caso de<br>asma alérgica grave com fenstipo Tz alto: associar dupilumabe (Anti-IL-4a)<br>Etapa4 ¢ Dose média de Cl + LABA diria e SABA sob demanda<br>Etapa 3 Dose baixa de Cl + LABA diaria e SABA sob demanda, OU<br>Dose média de Cl didria e SABA sob demanda<br>Preferencial<br>Etapa2 Le eee een eae eee<br>| Alternativo: i<br>| Cl dose baixa + SABA sob demanda (dose baixa de Cl sempre que usar SABA) i<br>Etapa1 ¢ Cl dose baixa + SABA sob demanda (dose baixa de Cl sempreque usar SABA) 2<br>TODOS OS ASMATICOS<br>Controle ambiental + rever controle da asma e risco futuro regularmente<br><!-- End of picture text -->  
CI – corticoide inalatório; SABA – beta2-agonista de curta duração; LABA – beta2-agonista de longa duração; CO – corticoide oral; IgE – Imunoglobulina E; IL-5 – interleucina 5; IL-4α - Subunidade alfa do receptor de interleucina 4; *Recomendada apenas por um período limitado de 2 a 3 meses, com monitoramento de eventos adversos. Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
33  
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento e o uso correto dos dispositivos inalatórios, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes. Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis reações adversas. A integração do Cuidado Farmacêutico aos protocolos clínicos e diretrizes terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.2.1. Dispositivos inalatórios** -->
Os medicamentos inalatórios estão disponíveis em várias apresentações, incluindo soluções para nebulização, pMDI (spray dosimetrado) e dispositivos de pó. A escolha do dispositivo inalatório deve considerar a disponibilidade local, o custo para o paciente e a possibilidade de usar um inalador combinado quando mais de um medicamento for necessário. A idade também é um fator relevante: dispositivos de pó não são adequados para a maioria das crianças ≤ 5 anos e para alguns idosos, sendo preferível o uso de pMDI com espaçador nesses casos<sup>3</sup> .  
É fundamental avaliar se o paciente consegue utilizar corretamente o dispositivo após o treinamento, considerando aspectos como destreza, fluxo inspiratório, coordenação e cognição. Inaladores diferentes exigem técnicas distintas de inalação, por isso deve-se evitar prescrever pMDI e DPI simultaneamente. Técnicas incorretas aumentam o risco de exacerbações. A preferência do paciente pelo inalador que consegue usar corretamente deve ser valorizada, pois isso favorece a adesão, melhora o controle da asma e reduz riscos. Nas consultas de seguimento, é essencial revisar o controle dos sintomas, exacerbações, eventos adversos e a técnica inalatória<sup>3,11</sup> .  
Recursos educativos, como vídeos, podem auxiliar na orientação sobre a técnica inalatória correta e o uso adequado dos dispositivos inalatórios. Nesse sentido, a Linha de Cuidado em Asma do Ministério da Saúde disponibiliza uma seção com orientações e materiais explicativos<sup>2</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.3.1. Crianças ≤ 5 anos** -->
Os objetivos do tratamento da asma em crianças ≤ 5 anos são semelhantes aos de outras faixas etárias, com foco em alcançar o melhor controle possível dos sintomas, manter níveis normais de atividades e minimizar o risco de exacerbações, de prejuízo ao desenvolvimento pulmonar e de eventos adversos aos medicamentos<sup>3</sup> .  
Todas as crianças com asma ou suspeita de asma devem receber beta2-agonista de curta duração inalatório para alívio dos sintomas diários. Para crianças que apresentam sintomas de asma mais de duas vezes por semana ou que tiveram uma ou mais exacerbações graves com necessidade de atendimento médico não programado no último ano, recomenda-se iniciar terapia de controle diário com corticoide inalatório ( **Quadro 9** ). A resposta ao tratamento deve ser reavaliada antes de decidir pela manutenção ou ajuste da terapia. Nos casos de resposta clínica insatisfatória, é fundamental revisar a técnica inalatória, a adesão, os fatores de risco, os possíveis diagnósticos alternativos e as comorbidades que possam contribuir para as exacerbações. Quando houver boa resposta ao corticoide inalatório por um período de 2 a 3 meses, pode-se considerar a redução da dose<sup>3</sup> .  
34  
**Quadro 9 -** Doses baixas de corticoides inalatórios, para uso diário  
|**Corticoide**|**Dose baixa mcg/dia**|
|---|---|
|**Dipropionato de beclometasona**<br>(pMDI, partícula padrão, HFA)|100|
|**Dipropionato de beclometasona**<br>(pMDI, partícula extrafina<sup>a</sup>, HFA)|50 (a partir de 5 anos)|  
Nota:<sup>a</sup> Apresentação ainda não disponível no Brasil; pMDI: dispositivo inalatorio pressurizado dosimetrado (Spray dosimetrado); HFA: hidrofluoralcano. Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
O tratamento nesta faixa etária é organizado em etapas de 1 a 4 ( **Figura 3** ). A **etapa 1** é indicada para crianças com sibilância viral infrequente, sem sintomas ou com poucos sintomas respiratórios nos intervalos entre os episódios. O uso diário de medicamento de controle ainda não é indicado, devendo-se considerar curso intermitente de corticoide inalatório no início de infecções virais. Crianças nesta faixa etária, cujos sintomas não estejam bem controlados ou que tenham apresentado uma ou mais exacerbações graves no último ano, devem ser tratadas, preferencialmente, com uso diário de corticoides inalatórios em baixa dose, administrado inicialmente por pelo menos 2 a 3 meses, a fim de estabelecer a resposta clínica. Alternativamente, podem usar corticoides inalatórios intermitente iniciado com sintomas respiratórios ( **etapa 2** ). Crianças com asma caracterizada por sibilância frequente induzida por vírus e sintomas intermitentes entre os episódios também se esquadram na etapa 2, mas um teste terapêutico com corticoide inalatório diário em baixa dose deve ser realizado primeiro<sup>3</sup> .  
Na **etapa 3** os pacientes são tratados com o dobro da dose de corticoide inalatório em baixa dose. Devem ser consideradas para esta etapa as crianças com diagnóstico de asma e sintomas não bem controlados com corticoides inalatórios em baixa dose. Caso o controle dos sintomas permaneça inadequado ou as exacerbações persistam, a criança deve ser encaminhada para avaliação especializada. Na **etapa 4** estão os pacientes com asma não controlada que estão recebendo a dose aumentada de corticoide inalatório prevista na etapa 3. Estes pacientes devem ser referenciados ao especialista, enquanto o tratamento é mantido. O melhor tratamento para essa população não foi estabelecido. Com orientação especializada, pode ser considerado o uso de corticoide inalatório - LABA (evidência em crianças ≥4 anos). A necessidade de tratamento adicional deve ser reavaliada em cada visita e mantida pelo menor tempo possível, considerando riscos, benefícios e viabilidade, sempre em diálogo com a família. De modo geral, antes de intensificar o tratamento, devem ser verificados diagnósticos alternativos, exposições a alérgenos e habilidades/adesão ao uso dos medicamentos prescritos. **Em todas as etapas de tratamento, o medicamento de alívio é o SABA sob demanda**<sup>3</sup> .  
35  
**Figura 3** - Etapas de tratamento da asma em crianças com até 5 anos de idade.  
<!-- Start of picture text -->
Asma nao bem controlada com dose baixa de Cl em dobro:<br>Tratamento Preferencial:<br>Etapa 4 Continuar controlador e encaminhar para avaliacao de especialista<br>Alternativo"<br>Associar LABA ao Cl (criangas com 24 anos)<br>Ftapa3 Asma nao bem controlada com dose baixa de Cl: )<br>(considere encaminhar ao especialista)<br>€ Dose baixa de Cl em dobro, diaria + SABA sob demanda<br>2) Criangas cujo os sintomas nao estejam bem controlados E/OU que tenham<br>apresentado uma ou mais exacerbaces graves no tiltimo ano;<br>Etapa2 2) Criangas com asmasintomas caracterizada intermitentes por sibilancia entre os frequente episédios’. induzida por viruse<br>Tratamento Preferencial:.<br>Dose baixa de Cl didria + SABA sob demanda<br>Alternativo:<br>Curso intermitente de Cl no inicio de infeccées virais respiratérias + SABA sob demanda<br>Etapa1 Criangas com sibilancia viral infrequente, sem sintomasou com poucos sintomas<br>¢ Curso intermitente derespiratoriosCl no inicio  entrede infeccéesos episddios:virais + SABA sob demanda<br>TODOS OS ASMATICOS<br>Controle ambiental + rever controle da asma e risco futuro regularmente<br><!-- End of picture text -->  
CI – corticoide inalatório; SABA – beta2-agonista de curta duração; LABA – beta2-agonista de longa duração; *Um teste terapêutico com corticoide inalatório diário em baixa dose deve ser realizado primeiro; **Em orientação especializada, com monitoramento de eventos adversos. Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
Em crianças pequenas, os sinais iniciais de exacerbação incluem aumento da tosse (especialmente noturna), intensificação dos sintomas, letargia, redução da atividade, piora na alimentação e resposta insatisfatória ao medicamento de alívio (SABA). O tratamento domiciliar, conforme plano de ação escrito, deve iniciar com SABA inalatório e reavaliação em até 1 hora. Procurar atendimento se a criança estiver prostrada, não responder ao SABA ou piorar, sobretudo se for menor de 1 ano; e no mesmo dia forem necessários ≥ 4 jatos de SABA inalatório para alívio dos sintomas em um período de 4 horas ou o SABA for necessário em mais de 3 ocasiões nas primeiras 12 horas. Não há evidência para que o corticoide oral seja iniciado em domicílio a critério dos cuidadores<sup>3</sup> .  
A escolha do dispositivo inalatório deve respeitar a idade e a capacidade da criança. A transição da máscara para o bocal deve ser feita assim que a criança demonstrar técnica adequada<sup>3</sup> .  
Sugere-se, idealmente, agendar reavaliação em 1 a 2 dias. A necessidade de tratamento deve ser reavaliada com frequência, uma vez que sintomas semelhantes à asma podem remitir em muitas crianças pequenas. É importante orientar pais e cuidadores de que os sintomas podem retornar mais tarde na vida<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.3.2. Gestantes** -->
O uso dos seguintes medicamentos é considerado seguro durante a gestação: SABA e LABA, corticoides inalatórios, teofilinas orais e, quando necessários para o controle da doença, antagonistas do receptor de leucotrieno (os dois últimos não estão incorporados no SUS para asma). Durante o período de amamentação, os medicamentos utilizados no tratamento da asma podem ser mantidos, visto que não há contraindicações relevantes associadas à sua utilização nesse contexto<sup>11</sup> .  
Durante a gravidez, a redução da intensificação do tratamento não deve ser prioridade, independentemente do método de avaliação de controle. A suspensão de corticoide inalatório não é recomendada<sup>3</sup> . O uso de medicamentos imunobiológicos para  
36  
asma em gestantes deve ser cuidadosamente avaliado, considerando-se a relação entre os potenciais riscos fetais e os benefícios esperados para o controle da doença materna. De forma geral, não há evidência de efeitos teratogênicos em estudos com animais para omalizumabe, mepolizumabe, benralizumabe e dupilumabe, porém os dados em humanos ainda são limitados. Todos esses medicamentos são classificados na categoria B de risco na gravidez, com recomendação de não serem utilizados durante a gestação sem orientação médica. De acordo com os fabricantes, o omalizumabe pode ser considerado em casos selecionados, e há registros de uso na gravidez sem aumento comprovado de malformações. O uso de mepolizumabe, benralizumabe e dupilumabe deve ser restrito a situações em que os benefícios superem os riscos potenciais<sup>23–26</sup> .  
Exacerbações agudas devem ser tratadas com agressividade para prevenir hipóxia fetal, utilizando SABA, oxigênio e corticoides sistêmicos precocemente. Infecções respiratórias devem ser monitoradas e tratadas adequadamente. Durante o parto, o medicamento manutenção deve ser mantido, e o broncoespasmo induzido por hiperventilação pode ser tratado com SABA. Caso doses elevadas de SABA sejam utilizadas nas 48 horas anteriores ao parto, recomenda-se monitorar a glicemia do recémnascido, especialmente em prematuros, nas primeiras 24 horas de vida<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.3.3. Idosos** -->
Idosos são frequentemente excluídos de ensaios clínicos, o que limita a evidência sobre eficácia dos medicamentos nessa população. Eventos adversos são mais frequentes, incluindo: cardiotoxicidade com beta2-agonistas, equimoses, osteoporose, fraturas por fragilidade e catarata com corticoides, e acúmulo de teofilina devido à menor depuração. É fundamental revisar todos os medicamentos em uso, incluindo colírios, e considerar interações medicamentosas. Fatores como artrite, fraqueza muscular, visão reduzida e baixo fluxo inspiratório devem orientar a escolha do inalador, e a técnica inalatória deve ser verificada em todas as consultas. Evitar esquemas complexos e múltiplos dispositivos inaladores sempre que possível. Materiais escritos devem ter letra ampliada, e pacientes com déficit cognitivo podem necessitar de cuidador para uso correto dos medicamentos<sup>3</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.4. Medicamentos** -->
- **Benralizumabe:** solução injetável de 30 mg/mL **;**  
- **Bromidrato de fenoterol:** aerossol de 100 mcg;  
- **Budesonida:** cápsula inalante de 200 mcg e 400 mcg e pó inalante ou aerossol bucal de 200 mcg;  
- **Dipropionato de beclometasona:** cápsula inalante ou pó inalante de 200 mcg e 400 mcg e aerossol ou spray de 50  
- mcg e 250 mcg;  
- **Dupilumabe:** seringa preenchida com 300mg/2mL 200 mg/1,14mL  
- **Fosfato sódico de prednisolona:** solução oral de 1 mg/mL e 3 mg/mL;  
- **Fumarato de formoterol:** cápsula ou pó inalante de 12 mcg;  
- **Fumarato de formoterol + budesonida:** cápsula ou pó inalante de 12 mcg/400 mcg e de 6 mcg/200 mcg;  
- **Omalizumabe:** seringa preenchida de 150mg/mL e 75 mg/0,5mL;  
- **Mepolizumabe:** solução injetável de 100 mg/mL e 40 mg/0,4 mL;  
- **Prednisona:** comprimidos de 5 mg e de 20 mg;  
- **Sulfato de salbutamol:** aerossol de 100 mcg e solução inalante de 5 mg/mL.  
Observar que, apesar de a maioria das apresentações consistir em um medicamento, este Protocolo não preconiza monoterapia de SABA ou LABA, mas sim a combinação a critério do médico e respeitadas as condições, quando especificadas.  
37  
**Nota:** Estão disponíveis por meio do Programa “Aqui Tem – Farmácia Popular” os seguintes medicamentos para o tratamento da asma: dipropionato de beclometasona 200 mcg, 250 mcg e 50 mcg e sulfato de salbutamol 100 mcg e 5 mg.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.4.1. Esquemas de administração** -->
- **Beclometasona e budesonida:** doses diárias totais sugeridas para corticoides inalatórios, dividida em doses baixa, média e alta, estão discriminadas no **Quadro 10**<sup>3</sup> .  
**Quadro 10 -** Doses baixas, médias e altas de corticoides inalatórios, para uso diário, isoladamente ou com beta2-agonista de longa duração (LABA)  
|**Corticoide**|**Dose**<br>**baixa**<sup>**a**</sup>**mcg/dia**|**Dose**<br>**média mcg/dia**|**Dose alta**<sup>**b**</sup><br>**mcg/dia**|
|---|---|---|---|
|**≥ 12 anos**||||
|**Dipropionato de beclometasona**(pMDI, partícula<br>padrão, HFA)|200-500|><br>500-<br>1.000|> 1.000|
|**Dipropionato de beclometasona**<br>(DPI ou pMDI, partícula extrafina<sup>c</sup>, HFA)|100-200|> 200-400|> 400|
|**Budesonida**<br>(DPI ou pMDI, partícula padrão, HFA)|200-400|> 400-800|> 800|
|**Crianças 6 a 11 anos**||||
|**Dipropionato de beclometasona**(pMDI, partícula<br>padrão, HFA)|100-200|> 200-400|> 400|
|**Dipropionato de beclometasona**(pMDI, partícula<br>extrafina<sup>c</sup>, HFA)|50-100|> 100-200|> 200|
|**Budesonida**<br>(DPI ou pMDI, partícula padrão, HFA)|100-200|> 200-400|> 400|  
Nota: a. Dose padrão para iniciar e manter o tratamento da maioria dos pacientes; b. Aumentam a frequência e intensidade dos efeitos colaterais sistêmicos; c. Apresentação ainda não disponível no Brasil; pMDI: dispositivos de dose medida pressurizada; DPI: Dispositivo de pó inalatório. HFA: hidrofluoralcano. Fonte: adaptado da GINA (2025)<sup>3</sup>  
- **Prednisona e prednisolona:** para adolescentes e adultos, a dose recomendada de prednisolona (ou equivalente de prednisona) é de 40 a 50 mg/dia por 5 a 7 dias para exacerbações graves. O uso adicional de corticoides orais em baixa dose (até 7,5 mg/dia de prednisona ou equivalente) pode ser considerado como último recurso no manejo da asma grave em adultos. Para crianças de 6 a 11 anos, preconiza-se 1 a 2 mg/kg/dia de prednisolona, com máximo de 40 mg/dia, por 3 a 5 dias. A GINA recomenda administração em dose única diária, para adultos. A administração matinal é geralmente preferida para minimizar eventos adversos sobre o eixo hipotálamo-hipófise-adrenal. Não é necessário desmame de corticoide oral se o uso for por menos de 2 semanas<sup>3</sup> .  
- **Formoterol + budesonida** : para adultos e adolescentes, recomenda-se geralmente a formulação de 200/6 mcg por dose medida (equivalente a 160/4,5 mcg de dose administrada), disponível em pó inalável. Em crianças de 6 a 11 anos, utilizase preferencialmente a apresentação de 100/6 mcg por dose medida (80/4,5 mcg de dose administrada), em dispositivo de pó inalável. Para o uso sob demanda, os pacientes devem inalar 1 a 2 doses ao surgimento dos sintomas, ou antes da prática de exercícios ou exposição a alérgenos, conforme a apresentação prescrita e orientação médica. Diferentemente do SABA, não é  
38  
necessário aguardar um intervalo mínimo entre as doses de alívio. No entanto, deve-se respeitar o limite máximo diário de formoterol, considerando tanto as doses de manutenção quanto as de alívio. O **Quadro 11** apresenta a dose e frequência de formoterol + budesonida para estratégia AIR e MART em adolescentes ≥ 12 anos e adultos, no regime de tratamento preferencial.  
**Quadro 11 -** Dose e frequência de formoterol + budesonida para estratégia AIR e MART em adolescentes ≥ 12 anos e adultos no regime preferencial.  
|**Medicamento**|**Dose e frequência para terapia AIR* e**<br>**MART****|**Número máximo de inalações**<br>**ao dia**|
|---|---|---|
|Fumarato de formoterol + budesonida<br>- 6/200 mcg por inalação<br>- Cápsula ou pó inalante|**Etapa 1**<sup>*****</sup>**:**01 inalação sob demanda;<br>**Etapa 2**<sup>*****</sup>**:**01 inalação sob demanda;<br>**Etapa 3**<sup>******</sup>**:**01 inalação, uma ou duas vezes<br>ao dia (diárias) + 01 inalação sob demanda;<br>**Etapa 4**<sup>******</sup>**:**02 inalações, duas vezes ao dia<br>(diárias) + 01 inalação sob demanda;<br>**Etapa 5**<sup>******</sup>**:**02 inalações, duas vezes ao dia<br>(diárias) + 01 inalação sob demanda.|**12**inalações<br>(totalizando<br>72<br>mcg<br>de<br>formoterol)|  
AIR – terapia de alívio com ação antinflamatória; MART – terapia de alívio e manutenção.  
Fonte: Adaptado de GINA (2025)<sup>3</sup> .  
- **Salbutamol ou fenoterol:** em casos de exacerbações leves a moderadas, o salbutamol pode ser administrado na dose de 4 a 10 jatos (100 mcg cada) a cada 20 minutos durante a primeira hora. Após esse período inicial, a frequência pode ser ajustada conforme a resposta clínica, variando entre 4 a 10 jatos a cada 3 a 4 horas ou 6 a 10 jatos a cada 1 a 2 horas. A via preferencial de administração é pMDI com espaçador. O uso excessivo de SABA para alívio diário de sintomas, fora do contexto de tratamento de exacerbações graves, está associado a maior risco de exacerbações e até de morte relacionada à asma<sup>3</sup> .  
- **Mepolizumabe** <u>: em adultos e adolescentes a partir de 12 anos, a dose preconizada é de 100 mg administradas por via</u> subcutânea, a cada 4 semanas. Para crianças de 6 a 11 anos, 40 mg, a cada 4 semanas. A segurança e a eficácia do mepolizumabe não foram estabelecidas em crianças com idade inferior a 6 anos<sup>23</sup> .  
- **Omalizumabe:** dose e frequência são determinadas pelo nível sérico basal de IgE (UI/mL), medido antes do início do tratamento, e pelo peso corpóreo (kg). Com base nessas medidas, 75 a 600 mg (1 a 4 injeções) devem ser necessários em cada administração. Omalizumabe deve ser administrado com suporte para o tratamento de reações anafiláticas imediatas. As 3 primeiras doses devem ser administradas por um profissional de saúde ou sob supervisão dele. Após isso, pode haver orientação médica para autoadministração. Pacientes cujo nível basal de IgE ou peso corpóreo em kg estiverem fora dos limites da tabela de dose não devem receber o medicamento<sup>25</sup> . Os **Quadros 12** e **13** apresentam, respectivamente, as doses de omalizumabe administradas a cada quatro e a cada duas semanas. Considerando-se a existência de duas apresentações do medicamento, devese atentar quanto ao volume adequado a ser administrado para atingir a dose necessária.  
39  
**<u>Quadro 12 -</u>** Doses de omalizumabe (mg <u>por dose) via subcutânea, a cada 4 semanas</u>  
|**Nível de**|**Peso (k**|**g)**|||||||||
|---|---|---|---|---|---|---|---|---|---|---|
|**IgE**<br>**basal**<br>**(UI/mL)**|**≥20 -**<br>**25**|**>25-30**|**>30-40**|**>40-50**|**>50-60**|**>60-70**|**>70-80**|**>80-90**|**>90-**<br>**125**|**>125-**<br>**150**|
|≥ 30-<br>100|75|75|75|150|150|150|150|150|300|300|
|> 100-<br>200|150|150|150|300|300|300|300|300|450|600|
|> 200-<br>300|150|150|225|300|300|450|450|450|600||
|> 300-<br>400|225|225|300|450|450|450|600|600|||
|> 400-<br>500|225|300|450|450|600|600|||||
|> 500-<br>600|300|300|450|600|600|Administ|ração a cad|a 2 semanas|(ver a**Q**|**uadro 11**)|
|> 600-<br>700|300||450|600|||||||  
Fonte: Bula do medicamento<sup>25</sup> .  
**Quadro 13 -** Doses de omalizumabe (mg por dose) via subcutânea, a cada 2 semanas  
|**Nív**|**el de**|**Peso (kg)**||||||
|---|---|---|---|---|---|---|---|
|**IgE**<br>**bas**<br>**(UI**|<br>**al**<br>**/mL)**|**≥20**<br>**-**<br>**25**<br>**>25– 30**<br>**>30– 40**<br>**>40– 50**<br>**>50– 60**|**>60– 70**|**>70– 80**|**>80– 90**|**>90**<br>**125**|**–**<br>**>125**<br>**-**<br>**150**|
|≥ 3|0-100|||||||
|>|100-|||||||
|200||||||||
|><br>300|200-<br>|Administração a cada 4 semanas (ver**Quadr**|**o 10**)||||375|
|><br>400|300-<br>|||||450|525|
|><br>500|400-<br>|||375|375|525|600|
|><br>600|500-<br>||375|450|450|600||
|><br>700|600-<br>|225<br>375|450|450|525|||  
40  
**Nível de Peso (kg)**  
|**IgE**<br>**basal**<br>**(UI/mL)**|**≥20**<br>**25**|**-**|**>25– 30**|**>30– 40**|**>40– 50**|**>50– 60**|**>60– 70**|**>70– 80**|**>80– 90**|**>90**<br>**–**<br>**125**<br>**>125**<br>**-**<br>**150**|
|---|---|---|---|---|---|---|---|---|---|---|
|><br>700-<br>800|225||225|300|375|450|450|525|600||
|><br>800-<br>900|225||225|300|375|450|525|600|||
|><br>900-<br>1.000|225||300|375|450|525|600||||
|> 1.000-<br>1.100|225||300|375|450|600||Não admi|nistrar||
|> 1.100-<br>1.200|300||300|450|525|600|||||
|> 1.200-<br>1.300|300||375|450|525||||||
|> 1.300-<br>1.500|300||375|525|600||||||  
Fonte: Bula do medicamento<sup>25</sup> .  
- **Benralizumabe** : 30 mg por injeção subcutânea a cada 4 semanas nas três primeiras doses e, a partir de então, a cada 8 semanas. Nenhum ajuste de dose é necessário para pacientes idosos, com disfunção renal ou hepática<sup>24</sup> .  
- **Dupilumabe:** em pacientes adultos e adolescentes (≥12 anos) com asma grave e que estão fazendo uso de corticoides oral é recomendada uma dose inicial de 600 mg (duas injeções de 300 mg), seguida de uma dose de 300 mg administrada a cada duas semanas sob a forma de injeção subcutânea. Para todos os outros pacientes, é recomendada uma dose inicial de 400 mg (duas injeções de 200 mg), seguida de uma dose de 200 mg administrada a cada duas semanas sob a forma de injeção subcutânea. Para uso em crianças (6 a 11 anos) de 15 até < 30 kg, 300 mg, a cada 4 semanas; ≥ 30 kg, 200 mg, a cada 2 semanas<sup>26</sup> . Para pacientes entre 6 e 11 anos com asma **e** dermatite atópica grave, recomenda-se seguir as orientações de tratamento do dupilumabe conforme o Protocolo Clínico e Diretrizes Terapêuticas de Dermatite Atópica<sup>26</sup> .  
Pacientes em uso de terapia imunobiológica, que utilizam concomitantemente corticoide oral, podem ter a dose deste reduzida, desde que haja evidência de melhora clínica. No entanto, essa redução deve ser feita de forma **gradual** e sempre sob supervisão médica. Nunca se deve interromper o uso de corticoide oral de maneira abrupta<sup>23–26</sup> .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **7.4.2. Critérios de interrupção** -->
O corticoide inalatório não deve ser completamente interrompido, sob risco aumentado de exacerbações. Se não houver resposta em um período mínimo de 6 meses, o imunobiológico deve ser interrompido e o paciente reavaliado para uma possível introdução de outra terapia imunobiológica<sup>8</sup> . Em caso de resposta incerta à terapia biológica complementar, recomenda-se estender o teste de tratamento por 6 a 12 meses antes de considerar a interrupção<sup>3</sup> .  
Para avaliação da resposta clínica, considera-se três perfis<sup>8</sup> :  
41  
- Respondedores: melhora de pelo menos 2 critérios, como diminuição de 0,5 ponto no ACQ e/ou aumento ≥ 3 pontos no ACT; redução ≥50 % em exacerbações; e/ou ≥ 50% na dose diária de corticoide oral,  
- super-respondedores: asma controlada por 6 meses, com < 1,5 pontos no ACQ ou ≥ 20 no ACT, sem exacerbações e redução ≥80% na dose de corticoide oral); e  
- não respondedores: não atingem ao menos dois dos critérios anteriores.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **8. MONITORAMENTO** -->
O monitoramento da asma deve ser contínuo e incluir avaliação do controle dos sintomas, risco futuro (exacerbações, limitação do fluxo aéreo, eventos adversos), comorbidades, técnica e adesão ao uso do inalador, além das preferências do paciente. As avaliações devem ocorrer periodicamente, após 3 a 6 meses do início ou ajuste do tratamento, e após exacerbações. Em pacientes de alto risco, a frequência deve ser maior<sup>3</sup> . A função pulmonar (espirometria ou PFE) deve ser registrada no diagnóstico, após 3 a 6 meses de tratamento, e então pelo menos uma vez a cada 1 a 2 anos, mas com mais frequência em pacientes sob maior risco e naqueles com asma grave. Planos de ação escritos para asma são essenciais e devem ser revisados a cada visita. Após exacerbação grave, idealmente, deve-se realizar uma reavaliação em 2 a 7 dias (1 a 2 dias para crianças). Se a exacerbação for autogerenciada (sem hospitalização), recomenda-se reavaliar o paciente, antes de suspender o corticoide oral<sup>3</sup> .  
Para pacientes em uso de terapia complementar, recomenda-se revisar a resposta clínica após 3 a 4 meses e, posteriormente, a cada 3 a 6 meses ( **Figura 4** ). A avaliação deve incluir controle dos sintomas, frequência e gravidade das exacerbações, necessidade de corticoide oral, função pulmonar e evolução de comorbidades relacionadas ao tipo 2 alto (como pólipos nasais e dermatite atópica)<sup>3</sup> . É importante que essa avaliação também considere os desfechos relevantes sob a perspectiva dos pacientes, uma vez que, para eles, as melhorias significativas vão além do controle dos sintomas respiratórios, envolvendo também os impactos da doença na vida profissional, social e familiar. Embora essa perspectiva possa variar entre os indivíduos, considerando diferentes contextos sociais e culturais, os principais desfechos valorizados pelos pacientes incluem a redução de exacerbações, a melhora da qualidade de vida (como diminuição de limitações e maior capacidade de manter-se ativo), a redução do uso de medicamentos de alívio e corticoides orais, a melhora do sono e a diminuição de preocupações e medos relacionados à doença<sup>27–29</sup> .  
42  
**Figura 4 -** Fluxo para avaliação da resposta ao tratamento com imunobiológicos.  
<!-- Start of picture text -->
PPaciente em inicio de tratamento com imunobiologico<br>‘Avaliar critéios de resposta 20<br>‘ratamento apés 3.4 4 meses<br>Paciente apresenta:; Paciente atinge 2 ou mais crtérios:‘ Pacientecpap néo atingealleao menos<br>‘Asma controladaE  por6meses 41) Diminuigao de 0.5 ponto no ACQ e/ou Uscomitieneh<br>ACQ < 1,5 ou ACT = 20 pontos ‘aumento = 3 pontos no ACT, 1<br>E<br>Sem exacerbacies 2) Redugio= 50 % em exacerbacBes; elou =|a |<br>RReduco de 80% na doseE didria de coticoide oral 3) Reducdo = 50% naoraldose diéria de corticoide J<br>il ii Mantero trtamento até completar 6<br>meses e reavalia os critéios de resposta<br>‘Super respondedor | Respondedor | ——<br>Sim_/ Paciente aingiu \_Ndo<br>Mantero tratamento e reavaliar os lt?<br>cotrios de resposta<br>em 3.2 6 meses Eareavaliar os critérios de ———cconsiderar<br>tespostameses em 3.26 outroelegiblidade imunobiolégicopara<br><!-- End of picture text -->  
A maioria dos pacientes com asma não apresenta eventos adversos com o uso dos medicamentos. O risco aumenta com doses mais altas, especialmente de corticoides inalatórios, sendo necessário apenas em poucos casos. Ainda assim, ressalta-se a importância do monitoramento contínuo dos eventos adversos associados ao tratamento da asma, com o objetivo de mitigá-los sempre que possível, e sua respectiva notificação à Agência Nacional de Vigilância Sanitária, por meio do respectivo sistema de registro. Entre os principais estão<sup>3</sup> :  
- **Corticoide inalatório:** a maioria dos pacientes não apresenta eventos adversos. Quando presentes, os mais comuns são candidíase orofaríngea e disfonia, que podem ser minimizados com o uso de espaçador em pMDIs e enxágue com água e cuspir após a inalação. O uso prolongado de altas doses está associado a maior risco de efeitos sistêmicos, como osteoporose, catarata e glaucoma. É indicada a avaliação por densitometria óssea em pacientes com de alta dose desses medicamentos, a longo prazo, bem como a adoção de estratégias preventivas e corretivas. Além disso, a administração concomitante de inibidores do citocromo P450 pode elevar o risco de eventos adversos, incluindo supressão adrenal;  
- **LABA** : pode estar associado a taquicardia, cefaleia ou cãibras musculares. No entanto, o LABA é considerado seguro no tratamento da asma quando utilizado em combinação com corticoide inalatório. Ressalta-se que LABA não devem ser utilizados isoladamente em pacientes com asma, ou com sobreposição asma-DPOC, devido ao risco aumentado de desfechos adversos graves;  
- **SABA:** pode provocar eventos adversos como tremor e taquicardia, especialmente no início do tratamento. Com o uso regular por apenas 1 a 2 semanas, desenvolve-se tolerância. O uso excessivo ou a resposta insatisfatória ao SABA indicam controle inadequado da asma e maior risco de exacerbações;  
- **Corticoide sistêmico (oral ou injetável):** a curto prazo está associado a sepse, tromboembolismo, insônia, refluxo gastroesofágico, aumento do apetite, hiperglicemia e alterações de humor. Quando utilizados de forma repetida, há aumento cumulativo do risco de eventos adversos graves, como diabetes, osteoporose, catarata, glaucoma e insuficiência cardíaca. O uso contínuo pode levar à catarata, glaucoma, hipertensão arterial, diabetes, supressão adrenal e osteoporose. Ressalta-se que o corticoide sistêmico tem seu uso restrito aos casos descritos anteriormente, sendo indicada a avaliação por densitometria óssea  
43  
em pacientes que como último recurso necessitem de seu uso contínuo ou frequente, bem como a adoção de estratégias preventivas e corretivas. Além da avaliação regular da osteoporose, outros testes podem ser necessários, conforme suspeitas clínicas<sup>3</sup> .  
- **Medicamentos imunobiológicos:** ver **Quadro 8** .

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
A APS é a principal porta de entrada e coordenadora do cuidado no SUS, sendo responsável por realizar a detecção precoce de sinais e sintomas sugestivos da doença, estabelecer o diagnóstico inicial e iniciar o tratamento conforme o Protocolo vigente. Além do atendimento, a APS é responsável por promover educação em saúde direcionada a pacientes e familiares, abordando fatores de risco, técnica inalatória adequada, adesão ao tratamento e reconhecimento de sinais de agravamento.  
A APS também é o espaço privilegiado para o acompanhamento longitudinal dos casos, monitorando periodicamente o controle da doença, ajustando condutas terapêuticas e identificando comorbidades que possam interferir na evolução clínica. Por meio de ações de promoção à saúde, como incentivo à atividade física segura, controle ambiental e alimentação saudável, a APS contribui para a prevenção de crises e para a melhoria da qualidade de vida das pessoas com asma.  
Assim, o fortalecimento da APS no controle da asma não apenas amplia o acesso e a resolutividade, mas também consolida uma abordagem integral, contínua e centrada no paciente, alinhada às diretrizes nacionais e à organização da rede assistencial.  
Cabe a APS o papel de organizar e regular o fluxo de encaminhamentos para a atenção especializada, garantindo que casos de difícil controle, suspeita de diagnóstico alternativo ou necessidade de terapias específicas sejam avaliados em tempo oportuno. A integração com outros pontos da Rede de Atenção à Saúde potencializa a coordenação do cuidado, otimiza o uso dos recursos e favorece desfechos clínicos mais satisfatórios.  
Pacientes com asma devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos.  
Pessoas com asma de difícil controle, bem como os casos para os quais este PCDT recomenda avaliação especializada, devem ser atendidos em serviços especializados que contem, preferencialmente, com pneumologista, alergista ou pediatra.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Como parte da rede de APS, o Programa Academia da Saúde é uma estratégia de promoção da saúde e produção do cuidado que funciona com a implantação de espaços públicos conhecidos como polos, voltados ao desenvolvimento de ações culturalmente inseridas e adaptadas aos territórios locais e que adotam como valores norteadores de suas atividades o desenvolvimento de autonomia, equidade, empoderamento, participação social, entre outros. Nesse sentido, deve ser observado o artigo 7° da Portaria de Consolidação nº 5, de 28 de setembro de 2017, que estabelece os seguintes eixos de ações para serem desenvolvidos nos polos do programa: Práticas corporais e Atividades físicas; produção do cuidado e de modos de vida saudáveis;  
44  
promoção da alimentação saudável; PICS; práticas artísticas e culturais; educação em saúde; planejamento e gestão; e mobilização da comunidade.  
A prescrição de imunobiológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **11. REFERÊNCIAS** -->
1.  Pizzichini MMM, Carvalho-Pinto RM de, Cançado JED, Rubin , Adalberto Sperb, Cerci Neto A, Cardoso AP, et al. 2020 Brazilian Thoracic Association recommendations for the management of asthma. Jornal Brasileiro de Pneumologia. 2020;46(1).  
2.  Brasil. Linhas de cuidado: Asma [Internet]. [cited 2025 Mar 31]. Available from: https://linhasdecuidado.saude.gov.br/portal/asma/  
3.  Global Initiative for Asthma. Global Strategy for Asthma Management and Prevention (2025 update) [Internet]. [cited 2025 Nov 20]. Available from: www.ginasthma.org  
4.  Forno E, Brandenburg DD, Castro-Rodriguez JA, Celis-Preciado CA, Holguin F, Licskai C, et al. Asthma in the Americas: An Update: A Joint Perspective from the Brazilian Thoracic Society, Canadian Thoracic Society, Latin American Thoracic Society, and American Thoracic Society. Ann Am Thorac Soc. 2022 Apr;19(4):525–35.  
5.  Halen Araújo Pinheiro1 D, Hermógenes de Souza1 JV, Oliveira Justo2 AF, Carvalho-Pinto3 RM, Francisco de Lima1 F, R F Carvalho1 C. Asthma in the Brazilian Unified Health Care System: an epidemiological analysis from 2008 to 2021. Jornal Brasileiro de Pneumologia. 2024 Jun 4;e20230364.  
6.  da Rocha Oliveira Cardoso1 A, Galvão Ferreira1 AC, Fouad Rabahi1 M. Asthma-related deaths in Brazil: data from an ecological study. Jornal Brasileiro de Pneumologia. 2024 Dec 20;e20240296.  
7.  Brum1 M, Henz1 J, Boeira1 M, Soares1 S, Friedrich1 F, Márcio Pitrez2 P. Recent increase in asthma mortality in Brazil: a warning sign for the public health system. Jornal Brasileiro de Pneumologia. 2024 Nov 21;e20240138. 8.  de Carvalho-Pinto1 RM, Delfini Cançado2 JE, Menezes Pizzichini3 MM, Fiterman4 J, Sperb Rubin5 6, Adalberto, Cerci Neto7 8, Alcindo, et al. 2021 Brazilian Thoracic Association recommendations for the management of severe asthma. Jornal Brasileiro de Pneumologia. 2021 Dec 31;e20210273.  
9.  Ray A, Camiolo M, Fitzpatrick A, Gauthier M, Wenzel SE. Are We Meeting the Promise of Endotypes and Precision Medicine in Asthma? Physiol Rev. 2020 Jul 1;100(3):983–1017.  
10.  Louis R, Satia I, Ojanguren I, Schleich F, Bonini M, Tonia T, et al. European Respiratory Society guidelines for the diagnosis of asthma in adults. European Respiratory Journal. 2022 Sep;60(3):2101585.  
45  
11.  National Institute for Health and Care Excellence (NICE) BTS (BTS) and SIGN (SIGN). Asthma: diagnosis, monitoring and chronic asthma management (BTS, NICE, SIGN) [Internet]. 2024 [cited 2025 Mar 31]. Available from: https://www.nice.org.uk/guidance/ng245/chapter/recommendations#feno-test  
12.  Bousquet J, Anto JM, Bachert C, Baiardini I, Bosnic-Anticevich S, Walter Canonica G, et al. Allergic rhinitis. Nat Rev Dis Primers. 2020 Dec 3;6(1):95.  
13.  Corrêa RA, Mancuzo EV, Rezende CF, Ribeiro ALP. Increasing patient access to spirometry in the Unified Health System in Brazil: no longer a dream but a near reality. J Bras Pneumol [Internet]. 2024 [cited 2025 Dec 5];49(6). Available from: https://pubmed.ncbi.nlm.nih.gov/38232256/  
14.  Brasil. Medidor de Pico de Fluxo Expiratório (PFE) - (“Peak Flow”) [Internet]. [cited 2025 Aug 21]. Available from: https://linhasdecuidado.saude.gov.br/portal/asma/medidor-de-pico-fluxo-expiratorio/  
15.  Pellegrino R, Viegi G, Brusasco V, Crapo RO, Burgos F, Casaburi R, et al. Interpretative strategies for lung function tests. European Respiratory Journal. 2005 Nov;26(5):948–68.  
16.  Coates AL, Wanger J, Cockcroft DW, Culver BH, Carlsen KH, Diamant Z, et al. ERS technical standard on bronchial challenge testing: general considerations and performance of methacholine challenge tests. European Respiratory Journal. 2017 May;49(5):1601526.  
17.  Akar-Ghibril N, Casale T, Custovic A, Phipatanakul W. Allergic Endotypes and Phenotypes of Asthma. J Allergy Clin Immunol Pract. 2020 Feb;8(2):429–40.  
18.  Anvisa. Bula do medicamento: dipropionato de beclometasona. [Internet]. [cited 2025 Dec 5]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
19.  Johnson J, Abraham T, Sandhu M, Jhaveri D, Hostoffer R, Sher T. Differential Diagnosis of Asthma. In: Allergy and Asthma. Cham: Springer International Publishing; 2019. p. 383–400.  
20.  Wang H, Li N, Huang H. Asthma in Pregnancy: Pathophysiology, Diagnosis, Whole-Course Management, and Medication Safety. Can Respir J. 2020 Feb 24;2020:1–10.  
21.  Brasil, Ministério da Saúde, Secretaria de Atenção Primária à Saúde, Departamento de Promoção da Saúde. Guia de Atividade Física para a População Brasileira [recurso eletrônico] [Internet]. Brasília; 2021 [cited 2025 Jul 13]. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/guia_atividade_fisica_populacao_brasileira.pdf  
22.  Stanley B, Chapaneri J, Khezrian M, Maslova E, Patel S, Gurnell M, et al. Predicting Risk of Morbidities Associated with Oral Corticosteroid Prescription for Asthma. Pragmat Obs Res. 2025 Mar;Volume 16:95–109.  
23.  Anvisa. Bula do medicamento: mepolizumabe [Internet]. [cited 2025 Apr 6]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
24.  Anvisa. Bula do medicamento: benralizumabe [Internet]. [cited 2025 Apr 6]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
25.  Anvisa. Bula do medicamento: omalizumabe [Internet]. [cited 2025 Apr 6]. Available from: https://consultas.anvisa.gov.br/#/medicamentos/  
26.  Anvisa. Bula do medicamento: dupilumabe [Internet]. [cited 2025 Apr 6]. Available from:  
https://consultas.anvisa.gov.br/#/medicamentos/  
27.  Ainsworth B, Chatburn E, Bansal AT, Fulton O, Hamerlijnck D, Coleman C, et al. What bothers severe asthma patients most? A paired patient–clinician study across seven European countries. ERJ Open Res. 2023 May;9(3):00717– 2022.  
28.  Clark VL, Gibson PG, McDonald VM. What matters to people with severe asthma? Exploring add-on asthma medication and outcomes of importance. ERJ Open Res. 2021 Jan;7(1):00497–2020.  
46  
29.  Lanario JW, Cartwright L, Jones RC, Sayers R, Hyland ME, Masoli M. “Life-changing”: the experience of superresponders to biologics in severe asthma. BMC Pulm Med. 2022 Nov 28;22(1):445.  
47  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE**

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **BENRALIZUMABE, BROMIDRATO DE FENOTEROL, BUDESONIDA, DIPROPIONATO DE BECLOMETASONA, DUPILUMABE, FOSFATO SÓDICO DE PREDNISOLONA, FUMARATO DE FORMOTEROL, FUMARATO DE FORMOTEROL + BUDESONIDA, OMALIZUMABE, MEPOLIZUMABE, PREDNISONA, SULFATO DE SALBUTAMOL** -->
Eu,_________________________________________________________________________________________  
_________________________________________________(nome do [a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de benralizumabe, bromidrato de fenoterol, budesonida, dipropionato de beclometasona, dupilumabe, fosfato sódico de prednisolona, fumarato de formoterol, fumarato de formoterol + budesonida, omalizumabe, mepolizumabe, prednisona, sulfato de salbutamol indicado para o tratamento da asma.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
________________________________________________________________________________________________ (nome  
do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Controle dos sintomas; - melhora da qualidade de vida;  
- normalização ou estabilização da função pulmonar;  
- redução do absenteísmo escolar e ao trabalho; e  
- redução da utilização de serviços de saúde, incluindo hospitalizações.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
**Riscos na gravidez e na amamentação:** estudos em animais não mostraram malformações relacionadas ao uso de dupilumabe, omalizumabe, mepolizumabe e benralizumabe. O uso de fumarato de formoterol, sulfato de salbutamol, bromidrato de fenoterol, beclometasona e budesonida é considerado seguro para o tratamento da asma. Embora ainda existam poucos dados em mulheres grávidas, esses medicamentos podem ser utilizados durante a gestação quando, após avaliação médica, os benefícios para a saúde da mãe forem considerados maiores do que eventuais riscos;  
**Efeitos adversos da beclometasona e budesonida** : a maioria dos pacientes não apresenta efeitos adversos. Quando presentes, os mais comuns são candidíase orofaríngea e disfonia, que podem ser minimizados com o uso de espaçador e enxágue com água e cuspir após a inalação. O uso prolongado de altas doses está associado a maior risco de efeitos sistêmicos, como osteoporose, catarata e glaucoma. Além disso, a administração concomitante de inibidores do citocromo P450 pode elevar o risco de eventos adversos, incluindo supressão adrenal;  
**Efeitos adversos do formoterol:** pode estar associado a taquicardia, cefaleia ou cãibras musculares. No entanto, são considerados seguros no tratamento da asma quando utilizado em combinação com corticoide inalatório;  
**Efeitos adversos do salbutamol e fenoterol** : pode provocar efeitos adversos como tremor e taquicardia, especialmente no início do tratamento. Com o uso regular por apenas 1 a 2 semanas, desenvolve-se tolerância. O uso excessivo ou a resposta insatisfatória aos medicamentos indicam controle inadequado da asma e maior risco de exacerbações;  
**Efeitos adversos da prednisona e prednisolona:** a curto prazo está associado sepse, tromboembolismo, insônia, refluxo gastroesofágico, aumento do apetite, hiperglicemia e alterações de humor. Quando utilizados de forma repetida, há aumento  
48  
cumulativo do risco de eventos adversos graves, como diabetes, osteoporose, catarata, glaucoma e insuficiência cardíaca. O uso contínuo pode levar à catarata, glaucoma, hipertensão arterial, diabetes, supressão adrenal e osteoporose.  
**Efeitos adversos do omalizumabe:** reações no local da injeção; anafilaxia em aproximadamente 0,2% dos pacientes. O risco da ocorrência de efeitos adversos aumenta com a superdosagem e com o uso concomitante de outros medicamentos;  
- **Efeitos adversos do mepolizumabe:** em adultos, reações no local da injeção e anafilaxia rara. Em crianças, distúrbios  
- da pele/tecido subcutâneo e do sistema nervoso (por exemplo, dor de cabeça, tontura, síncope);  
**Efeitos adversos do dupilumabe:** reações locais comuns e leves; eosinofilia transitória (4–13%); raros casos de granulomatose eosinofílica com poliangiite após redução/suspensão de corticoide oral;  
**Efeitos adversos do benralizumabe:** dor de cabeça e reações no local da injeção são comuns, mas leves. Efeitos graves incluem síndrome de liberação de citocinas, midríase, pneumonia e urticária.  
Os medicamentos fumarato de formoterol, sulfato de salbutamol e bromidrato de fenoterol e devem ser sempre utilizados em associação com budesonida ou beclometasona. Seu uso sozinho pode ocasionar efeitos adversos graves, incluído morte.  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (   ) Benralizumabe  
- (   ) Bromidrato de fenoterol  
- (   ) Budesonida  
- (   ) Dipropionato de beclometasona  
- (   ) Dupilumabe  
- (   ) Fosfato sódico de prednisolona  
- (   ) Fumarato de formoterol  
- (   ) Fumarato de formoterol + budesonida  
- (   ) Omalizumabe  
- (   ) Mepolizumabe  
- (   ) Prednisona  
- (   ) Sulfato de salbutamol  
49  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico(a) responsável:  CRM:  UF:<br>___________________________________________________________<br>Assinatura e carimbo do(a) médico(a)<br>Data:____________________<br><!-- End of picture text -->  
Nota 1: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Nota 2: A prescrição de imunobiológicos dependerá da disponibilidade desses medicamentos no âmbito da Assistência Farmacêutica do SUS.  
50

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: MATERIAL SUPLEMENTAR -->
**<u>Quadro suplementar 1 -</u>** Ferramentas para avaliação do controle da asma.  
|**Quadro suplementar 1 -**Ferramentas para<br>avaliação do controle da asma.**Instrumento / Itens**|**Faixa**<br>**etária**|**Período**<br>**d**<br>**referência**|**e**<br>**Asma**<br>**controlada**|**Asma**<br>**parcialmente**<br>**controlada**|**Asma**<br>**não-**<br>**controlada**|
|---|---|---|---|---|---|
|**GINA**(_Global Initiative for Asthma)_**|**Adultos e<br>crianças||||||
|Sintomas diurnos > 2 vezes por semana||||||
|Despertares noturnos por asma<br>Medicamento de resgate > 2 vezes por semana|≥ 6 anos|4 semanas|Nenhum item|1-2 itens|3-4 itens|
|Limitação das atividades por asma||||||
|**GINA**(_Global Initiative for Asthma)_**|**Crianças<br>pequenas||||||
|Sintomas diurnos por mais de alguns minutos e > 1<br>vez por semana||||||
|Limitação de atividades por asma|≤ 5 anos|4 semanas|Nenhum item|1-2 itens|3-4 itens|
|SABA de resgate > 1 vez por semana||||||
|Despertar ou tosse noturna||||||
|**ACQ-5**_(Asthma Control Questionnaire with 5_<br>_items)_||||||
|Número de despertares noturnos/noite||||||
|Intensidade dos sintomas||||||
|Limitação das atividades por asma|≥ 12 anos|7 dias|< 0.75|0.75 a  1.5|> 1,5|
|Intensidade da dispneia||||||
|Sibilância (quanto tempo)||||||
|**ACT**(_Asthma Control Test)_||||||
|Limitação das atividades por asma||||||
|Dispneia||||||
|Despertares noturnos por asma|≥ 12 anos|4 semanas|≥ 20|-|-|
|Medicação de resgate||||||
|Autoavaliação do controle da asma||||||
|**c-ACT**(_Childhood Asthma Control Test)_||||||
|Autoavaliação do controle da asma (crianças)||||||
|Limitação das atividades por asma (crianças)||||||
|Frequência de tosse (crianças)|4<br> <br>11|||||
|Despertares noturnos por asma (crianças)|<br>a<br> <br>|4 semanas|> 19|-|-|
|Sintomas da asma durante o dia (pais)|anos|||||
|Frequência de chiado (pais)<br>Despertares noturnos por asma (pais)||||||  
Legenda: ACQ-5 – escore 0 – 6 por item; ACT – escore 1 – 5 por item; c-ACT – escore 0 -  3 nos itens respondidos pela criança e escore 0 – 5 nos itens respondidos pelos pais ou responsáveis.  
51  
**APÊNDICE 1 - METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria Conjunta SAES-SCTIE/MS nº 43/2026, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Asma, pela necessidade de se corrigir o item 3.1.4. _Critérios para identificação de asma grave_ .  
Conforme apontado por meio do Ofício nº 040/2026 – SBPT, o trecho “Tratamento contínuo com altas doses de corticoide inalatório (budesonida, ou equivalente, igual ou superior a 800 mcg/dia para adultos e adolescentes ≥ 12 anos e 400 mcg/dia para crianças entre 6 a 11 anos) associado a um LABA, independente do uso de outro agente controlador, no ano anterior” foi corrigido para “Tratamento contínuo com altas doses de corticoide inalatório (budesonida, ou equivalente, superior a 800 mcg/dia para adultos e adolescentes ≥ 12 anos e superior a 400 mcg/dia para crianças entre 6 a 11 anos) associado a um LABA, independente do uso de outro agente controlador, no ano anterior”.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **1. Escopo e finalidade do Protocolo** -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Asma foi incluir:  
- o **mepolizumabe** para o tratamento de pacientes com idade entre 6 e 17 anos com asma eosinofílica grave refratária, conforme a Portaria SECTICS/MS Nº 22, de 18 de abril de 2024;  
- o **benralizumabe** para o tratamento adjuvante de manutenção para asma grave com fenótipo eosinofílico em pacientes adultos, conforme portaria SECTICS/MS Nº 8, de 31 de janeiro de 2025;  
- o **dupilumabe** para o tratamento da asma grave com fenótipo T2 alto alérgica, não controlada apesar do uso de corticoide inalatório associado a beta2-agonista de longa duração e manter o **omalizumabe** com incorporação da apresentação 75 mg/mL, solução injetável em seringa pré-preenchida, para tratamento da asma alérgica grave não controlada apesar do uso de corticoide inalatório associado a beta2-agonista de longa duração (LABA), conforme a Portaria SECTICS/MS Nº 3, de 31 de janeiro de 2025.  
Considerando a versão do PCDT da Asma, publicado por meio da Portaria Conjunta SAES/SECTICS Nº 32, de 20 de dezembro de 2023, esta atualização teve como foco a inclusão, ampliação ou manutenção das tecnologias supracitadas no âmbito do SUS. Ademais, a atualização também se faz necessária para assegurar a conformidade das recomendações de cuidado com a versão mais recente das diretrizes da _Global Initiative for Asthma_ (GINA), bem como com outras diretrizes clínicas nacionais e internacionais reconhecidas, garantindo alinhamento com as melhores práticas baseadas em evidências.

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **2. Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT da Asma foi apresentada na Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação em Saúde (SCTIE), Secretaria de Atenção Especializada (SAES) e Secretaria de Atenção Primária a Saúde (SAPS).  
Após a Reunião da Subcomissão Técnica, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Comitê de PCDT da Comissão Nacional de Incorporação de Tecnologias no SUS (Conitec) em sua 144ª Reunião, os quais recomendaram favoravelmente ao texto.  
52

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **3. Busca de evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (Quadro A)  
**Quadro A** – Níveis de evidências de acordo com o sistema GRADE.  
|Nível|Definição|Implicações|
|---|---|---|
|Alto|Há forte confiança de que o verdadeiro<br>efeito esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|Moderado|Há confiança moderada no efeito estimado.|Trabalhos futuros poderão modificar a confiança na<br>estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|Baixo|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
|Muito baixo|A confiança na estimativa de efeito é muito<br>limitada.<br>Há importante grau de incerteza nos<br>achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Foram adotadas as recomendações da Conitec para as seguintes tecnologias:

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **QUESTÃO 1: Mepolizumabe é eficaz e seguro no tratamento da asma eosinofílica grave refratária em pacientes com idade entre 6 e 17 anos?** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a ampliação de uso no SUS de mepolizumabe para o tratamento de pacientes com idade entre 6 e 17 anos com asma eosinofílica grave refratária, conforme Relatório de Recomendação nº 886/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/ampliacao-de-uso-domepolizumabe-para-o-tratamento-de-pacientes-com-idade-entre-6-e-17-anos-com-asma-eosinofilica-grave-refrataria

---

<!-- METADADOS: doenca: Asma - Portaria Conjunta SAES-SCTIE Nº 43 | secao: **QUESTÃO 2: O benralizumabe é eficaz e seguro comparado ao mepolizumabe para pacientes adultos com asma eosinofílica grave refratária ao tratamento com corticoide inalatório (CI) em dose alta + beta 2-agonista de longa duração (LABA) e e com contagem de eosinófilos no sangue periférico maior ou igual a 300 células/mL??** -->
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação do benralizumabe para o tratamento adjuvante de manutenção para asma grave com fenótipo eosinofílico em pacientes adultos conforme Protocolo Clínico do Ministério da Saúde. Para essa decisão foi considerada a vantagem posológica e econômica identificada para o benralizumabe  
53  
em relação ao seu comparador, conforme Relatório de Recomendação nº 959/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de-recomendacao-no-959-benralizumabe  
**QUESTÃO 3: Dupilumabe é eficaz e seguro como terapia adicional ao tratamento padrão em pacientes com asma alérgica grave do tipo 2 alto não controlada, apesar do uso de corticosteroide inalatório associado a β2 agonista longa duração, quando comparado ao omalizumabe?**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar: i) a incorporação do dupilumabe para o tratamento da asma grave com fenótipo T2 alto alérgica, não controlada apesar do uso de corticoide inalatório associado a β2 agonista de longa duração, conforme PCDT do Ministério da Saúde , considerando sua efetividade em populações não atendidas, como pacientes com IgE elevado e/ou sobrepeso, ii) A manutenção do omalizumabe, com incorporação do omalizumabe 75mg/mL de solução injetável em seringa pré-preenchida, para tratamento da asma alérgica grave não controlada apesar do uso de corticoide inalatório associado a β2 agonista de longa duração, devido à sua comprovada eficácia e elevada vantagem econômica.conforme Relatório de Recomendação nº 963/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2025/relatorio-de- <u>recomendacao-no-963-dupilumabe-omalizumabe</u>  
A atualização também se faz necessária para assegurar a conformidade das recomendações de cuidado, garantindo alinhamento com as melhores práticas baseadas em evidências, preconizadas nos seguintes documentos:  
- Relatório _Global Strategy for Asthma Management and Prevention_ (2024) da _Global Initiative for Asthma_ (GINA);  
- Recomendações para o tratamento da asma (2020) da Sociedade Brasileira de Pneumologia e Tisiologia;  
- Recomendações para o manejo da asma grave (2021) da Sociedade Brasileira de Pneumologia e Tisiologia;  
- Diretrizes de diagnóstico _da European Respiratory Society_ (2022);  
- Recomendações para diagnóstico, monitoramento e tratamento da asma crônica (2024) do _National Institute for_  
- _Health and Care Excellence_ (NICE).  
54  
**APÊNDICE 2 – HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO**  
|**Número do**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Relatório da diretriz**|**Principais**|||
|**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|Relatório<br>de<br>Recomendação<br>nº<br>1078/2025|Atualização<br>devido<br>à<br>incorporação<br>de<br>tecnologias<br>no<br>SUS|Benralizumabe para o tratamento<br>adjuvante de manutenção para asma<br>grave com fenótipo eosinofílico em<br>pacientes<br>adultos.<br>[Relatório<br>de<br>Recomendação nº 959/2025;. Portaria<br>SECTICS/MS nº 8/2025)<br>Dupilumabe para o tratamento da<br>asma grave com fenótipo T2 alto<br>alérgica, não controlada apesar do uso<br>de corticosteroide inalatório associado<br>a b2 agonista de longa duração,<br>conforme<br>Protocolo<br>Clínico<br>do<br>Ministério da Saúde. (Relatório de<br>Recomendação nº 963/2025; Portaria<br>SECTICS/MS nº 3/2025)<br>Manter<br>a<br>incorporação<br>do<br>omalizumabe com incorporação da<br>apresentação 75 mg/mL, solução<br>injetável em seringa pré-preenchida,<br>para tratamento da asma alérgica grave<br>não controlada apesar do uso de<br>corticoide inalatório associado a b2<br>agonista de longa duração. (Relatório<br>de<br>Recomendação<br>nº<br>963/2025;<br>Portaria SECTICS/MS nº 3/2025)<br>Ampliação de uso do mepolizumabe<br>para o tratamento de pacientes com<br>idade entre 6 e 17 anos com asma<br>eosinofílica grave refratária. (Relatório|-|  
55  
|**Número do**<br>**Relatório da diretriz**|**Principais**|**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
|||de<br>Recomendação<br>n°886/2024;<br>Portaria SECTICS/MS n° 22/2024)||
|Relatório<br>de<br>Recomendação<br>nº<br>825/2023|Atualização<br>devido<br>à<br>ampliação de uso<br>de tecnologias no<br>SUS|Inclusão de nova apresentação de<br>omalizumabe (150 mg/mL) solução<br>injetável em seringa preenchida para<br>tratamento da asma alérgica grave não<br>controlada apesar do uso de corticoide<br>inalatório (CI) associado a um beta2-<br>agonista de longa ação (LABA).<br>(Relatório<br>de<br>Recomendação<br>nº<br>777/2022; Portaria SCTIE/MS nº<br>143/2022)|-|
|Relatório<br>de<br>Recomendação<br>nº<br>650/2021<br>Portaria<br>Conjunta<br>SAES-SCTIE/MS nº<br>14/2021|Atualização<br>devido<br>à<br>incorporação<br>de<br>tecnologias<br>no<br>SUS|Omalizumabe para o tratamento de<br>asma alérgica grave não controlada<br>apesar do uso de corticoide inalatório<br>associado a um beta-2 agonista de<br>longa<br>ação<br>(Relatório<br>de<br>Recomendação<br>nº<br>499;<br>Portaria<br>SCTIE/MS nº 64/2019)<br>Mepolizumabe no tratamento da asma<br>eosinofílica<br>grave<br>refratária<br>em<br>pacientes com idade de 18 anos ou<br>mais (Relatório de Recomendação<br>nº 613/2021; Portaria SCTIE/MS nº<br>65/2019]|Benralizumabe o tratamento da<br>asma eosinofílica grave refratária<br>em pacientes com idade de 18 anos<br>ou mais (Portaria SCTIE/MS nº<br>65/2019)<br>Tiotrópio para tratamento da Asma<br>Moderada e grave em pacientes<br>adultos e crianças (com idade de 6<br>anos<br>ou<br>mais)<br>(Relatório<br>de<br>Recomendação<br>nº<br>612<br>/2021;<br>Portaria SCTIE/MS nº 19/2021)<br>Spray de Formoterol + Budesonida<br>para<br>o<br>tratamento<br>da<br>Asma<br>(Relatório de Recomendação nº|  
56  
|**Número do**<br>**Relatório da diretriz**|**Principais**|**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||||607/2021; Portaria SCTIE/MS nº<br>17/2021)<br>Propionato de fluticasona/ xinafoato<br>de salmeterol para tratamento da<br>asma em pacientes a partir de 4 anos<br>(Relatório<br>de<br>Recomendação<br>676/2021;<br>Portaria<br>SCTIE/MS<br>nº 74/2021)|
||||Exclusão<br>do<br>Xinafoato<br>de<br>Salmeterol aerossol bucal 50 mcg<br>para tratamento da**Asma**e da<br>Doença<br>Pulmonar<br>Obstrutiva<br>Crônica<br>(Relatório<br>de<br>Recomendação<br>nº<br>606/<br>2021;<br>Portaria SCTIE/MS nº 16/2021)|
||||Omalizumabe para o tratamento da<br>asma<br>grave<br>(Relatório<br>de<br>Recomendação nº 25/ 2013; Portaria|
|Portaria SAS/MS nº<br>1.317,<br>de<br>25<br>de<br>novembro de 2013|Atualização<br>de<br>conteúdo-<br>tempo<br>de documento|-|SCTIE/MS nº 14/2013)<br>Fluticasona para o tratamento da<br>asma (Relatório de Recomendação<br>nº 66/2013; Portaria SCTIE/MS nº<br>34/2013)|
|Portaria SAS/MS nº|Atualização<br>de|||
|709,<br>de<br>17<br>de<br>dezembro de 2010,|conteúdo-<br>tempo<br>de documento|-|-|
|Portaria SAS/MS nº|Primeira versão do<br>Protocolo Clínico|||
|1.012,<br>de<br>23<br>de<br>dezembro de 2002|e<br>Diretrizes<br>Terapêuticas<br>da<br>Asma.|-|-|  
57

---

