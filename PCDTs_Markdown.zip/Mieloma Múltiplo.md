<!-- METADADOS: doenca: Mieloma Múltiplo | secao: SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE -->
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 27, DE 05 DE DEZEMBRO DE 2023.  
Aprova as Diretrizes Diagnósticas e Terapêuticas do Mieloma Múltiplo.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Mieloma Múltiplo no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 759/2022 e o Relatório de Recomendação nº762 – Agosto de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas do Mieloma Múltiplo.  
Parágrafo único. As Diretrizes objeto deste artigo, que contêm o conceito geral do Mieloma Múltiplo, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio https://www.gov.br/saude/ptbr/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Mieloma Múltiplo.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAES/MS nº 708, de 06 de agosto de 2015, publicada no Diário Oficial da União nº 150, de 07 de agosto de 2015, seção 1, página 38.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
HELVÉCIO MIRANDA MAGALHÃES JÚNIOR

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **1. INTRODUÇÃO** -->
<mark>O mieloma múltiplo (MM) é uma neoplasia maligna de plasmócitos provenientes da medula óssea que, de</mark> acordo com a Agência Internacional para Pesquisa em Câncer da Organização Mundial de Saúde (OMS), em 2020, foi responsável por 176.404 novos casos e 117.077 óbitos. A incidência mundial, neste mesmo ano, foi de 1,8 casos/100 mil habitantes com taxa de mortalidade mundial de 1,1 óbitos/100 mil habitantes. Na América do Sul, a incidência foi de 2,0 casos/100 mil habitantes e a taxa de mortalidade foi de 1,5 óbitos a cada 100 mil habitantes<sup>1</sup> . No Brasil, dados do Painel Oncologia Brasil<sup>2</sup> mostram que, entre 2013 e 2019, foram diagnosticados cerca de 2.600 casos de MM, anualmente, estimando-se 1,24 casos/100 mil habitantes<sup>2</sup> .  
<mark>Os principais fatores de risco para MM são idade, sexo masculino, etnia e histórico familiar. Em relação à idade, apenas 15% dos diagnósticos são realizados em pessoas com menos de 55 anos, enquanto mais de 60% dos diagnósticos acontecem em adultos com mais de 65 anos. A incidência de MM é 1,5 vezes maior em homens do que em mulheres; 2 vezes maior em pessoas afro-americanas do que em caucasianas, enquanto asiáticos e nascidos nas i</mark> lhas do Pac <mark>ífico Sul apresentam riscos menores. Também existe forte associação de risco entre parentes de primeiro grau, especialmente em homens e afro-americanos</mark><sup>3,4</sup> <mark>.</mark> No Brasil, dados do Observatório de Oncologia apontam uma mediana de idade destes pacientes de 63 anos, com variação de 18 a 100 anos<sup>5</sup> .  
<mark>Algumas condições clínicas também estão associadas ao maior risco de desenvolver MM, tais como a gamopatia monoclonal de significado indeterminado (GMSI), o plasmocitoma solitário e o MM latente. Indivíduos com GMSI, com mais de 1,5 g/dL de proteína M e razão alterada de dosagem de cadeias kappa/lambda leves livres séricas, apresentam risco aumentado entre 20% e 30% de desenvolverem MM ativo em 20 anos</mark><sup>6,7</sup> <mark>.</mark> O <mark>plasmocitoma solitário, em especial o plasmocitoma ósseo, apresenta risco maior que o plasmocitoma extramedular na evolução para o MM (35% e 7%, respectivamente, em dois anos)</mark><sup>7</sup> <mark>. Já o MM latente apresenta um risco de progressão entre 70% e 80% em dois anos, com taxas decrescentes em função do tempo</mark><sup>7</sup> <mark>.</mark>  
O MM é classicamente descrito como síndrome “CRAB”, acrônimo, do inglês, que resume as principais manifestações clínicas da doença: hipercalcemia ( **_C_** _alcium elevation_ ), insuficiência renal ( **_R_** _enal failure_ ), anemia ( **_A_** _nemia_ ) e doença óssea ( **_B_** _one disease_ ). A doença é caracterizada pela proliferação descontrolada de plasmócitos, que pode causar sinais e sintomas localizados, de acordo com o sítio de proliferação (principalmente ossos), e sistêmicos, que ocorrem pelo excesso dessas células na corrente sanguínea. Cerca de 73% dos pacientes apresentam anemia ao diagnóstico, que está associada à fadiga em 32% dos casos. Outras manifestações observadas são dores ósseas (58%), perda de peso (28%), parestesia (5%) e febre (0,7%)<sup>8</sup> .  
<mark>Por apresentar grande carga de sintomas, o MM pode comprometer a qualidade de vida e a capacidade funcional dos pacientes, desde os estágios iniciais da doença, até os mais avançados. Os pacientes relatam alterações em todos os domínios relacionados à qualidade de vida, como aspectos emocionais, capacidade física (mobilidade, lazer, passatempo e atividade sexual), aspectos cognitivos e sociais (rede de apoio familiar; institucional e financeiro)</mark><sup>9,10</sup> <mark>. As principais queixas físicas incluem formigamento nas mãos e nos pés, dores osteomuscu</mark> lares e tontura<sup>10</sup> , além de ansiedade, depressão e fadiga que requerem atenção dos profissionais de saúde<sup>11</sup> .  
A atenção à saúde do paciente com MM no Sistema Único de Saúde (SUS) envolve diferentes níveis de complexidade, desde a identificação precoce de sinais e sintomas que levam à suspeita clínica, preferencialmente na Atenção Primária, até a confirmação diagnóstica em um centro de referência em oncologia, acompanhada do planejamento do tratamento<sup>12</sup> . De acordo com a Política Nacional para a Prevenção e Controle do Câncer na Rede de Atenção à Saúde das Pessoas com Doenças Crônicas no âmbito do SUS<sup>13</sup> , a atenção ao paciente oncológico, incluindo os pacientes com MM, deve ser realizada de forma  
multiprofissional e envolve diferentes especialidades como ortopedia, fisiatria, nefrologia, enfermagem, odontologia, psicologia, fisioterapia, cuidados paliativos, radiologia, além de serviços de procedimentos diagnósticos especializados.  
A apresentação clínica inicial do paciente com MM pode variar, cabendo aos profissionais da Atenção Primária o encaminhamento à Unidade de Assistência de Alta Complexidade em Oncologia (UNACON) ou ao Centro de Assistência de Alta Complexidade em Oncologia (CACON) a partir das características epidemiológicas, da avaliação clínica e dos exames complementares<sup>13</sup> . Em alguns casos, pacientes com sintomas agudos ou subagudos podem procurar a Rede de Urgência e Emergência, principalmente por fraturas, dores osteomusculares, infecções, fraqueza e perda de peso<sup>14</sup> . Diante da suspeita clínica, estes pacientes devem ter seu referenciamento assegurado e, se necessário, serem transferidos ao hospital geral de referência<sup>13</sup> .  
O fluxo de atendimento e encaminhamento do paciente com suspeita de MM pode variar nas diversas regiões do país, de acordo com suas especificidades regionais e dimensionamento das ofertas de serviços em saúde, a fim de otimizar tanto a celeridade do encaminhamento quanto a utilização dos recursos disponíveis<sup>15</sup> . O painel mínimo sugerido, visando sensibilidade e celeridade do processo de referenciamento, inclui hemograma e eletroforese de proteínas, a fim de documentar os sinais de anemia e pico monoclonal<sup>16</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos do Mieloma Múltiplo, com o objetivo de orientar o que é válido e não válido técnico-cientificamente, com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-11)** -->
- C90.0 Mieloma múltiplo

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3.1. Diagnóstico clínico** -->
A avaliação do paciente com suspeita de MM inclui a história clínica completa com investigação dos sintomas iniciais, os quais dependem das lesões de órgãos-alvo. Dor óssea (doença óssea), anemia, infecções (disfunção leucocitária) e alteração da função renal são sinais e sintomas comuns. Ainda, sintomas constitucionais e neurológicos também devem ser investigados<sup>12</sup> .  
A doença óssea pode se apresentar como dores osteomusculares, fraturas de fragilidade e sintomas neurológicos por lesões vertebrais. A alteração da função renal, causada pelo excesso de proteína-M e pela hipercalcemia, pode ocasionar oligúria e outros sintomas inespecíficos como náusea, fraqueza e sonolência. A disfunção de linfócitos B pode cursar com quadros infecciosos recorrentes. Já a síndrome de hiperviscosidade pode provocar sintomas relacionados à diminuição do fluxo sanguíneo para o sistema nervoso central e eventos tromboembólicos com consequentes tontura, confusão mental, ou sintomas específicos relacionados a um possível acidente vascular cerebral<sup>19</sup> .  
A história clínica deve incluir antecedentes como infecção, doença crônica, exposição a substâncias carcinogênicas (solventes, herbicidas, inseticidas) e radiação, bem como imunossupressão e histórico familiar de MM<sup>12</sup> .  
Os achados de exame físico no MM são inespecíficos e se relacionam também à lesão de órgão alvo. Sinais como palidez cutânea e taquicardia podem ser provenientes da anemia. A doença óssea pode cursar com alterações musculoesqueléticas, dificuldades na marcha, alteração da mobilidade e sinais de fratura. A avaliação neurológica permite identificar lesão vertebral acometendo o sistema nervoso periférico motor, sensorial ou central. Outros achados incluem hepatomegalia, esplenomegalia e  
linfonodomegalia<sup>8</sup> . Escores como _International Myeloma Working Group_ (IMWG) e o modelo _Fried_ para avaliação de fragilidade<sup>20</sup> , podem ser utilizados para mensurar a fragilidade clínica.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3.2. Diagnóstico laboratorial, citogenético e radiológico** -->
A investigação inicial de pacientes com suspeita de MM inclui exames de sangue, urina, aspirado de medula óssea e de imagem, com objetivo de identificar lesões de órgão-alvo (hipercalcemia, anemia, insuficiência renal e lesões ósseas), presença de proteína monoclonal tumoral (sérica e urinária) e infiltração plasmocitária na medula-óssea<sup>12,21</sup> . A triagem inicial dos pacientes deve considerar o hemograma completo (contagem celular e esfregaço), níveis séricos de ureia e creatinina, cálcio, eletroforese e imunofixação de proteínas séricas e urinárias, dosagem sérica de imunoglobulinas (IgA, IgM, IgG e IgE), dosagem de cadeias leves (kappa e lambda) livres, albumina e desidrogenase láctica (DHL)<sup>12,21</sup> .  
Se a suspeita diagnóstica de MM for apoiada pela investigação inicial, devem ser realizados exames complementares, que incluem: beta-2 microglobulina, proteína C reativa (PCR), velocidade de hemossedimentação (VHS), eletroforese de proteínas e imunofixação na urina de 24 horas (se não realizada na investigação inicial), proteinúria de 24h, mielograma, biópsia de medula óssea e imunofenotipagem (citogenética convencional ou, preferencialmente, teste citogenético por Hibridização _in Situ_ por Fluorescência - FISH) no aspirado da medula óssea.  
<mark>A avaliação citogenética é obrigatória para o diagnósti</mark> co. A técnica FISH está disponível para identificação das alterações moleculares e avaliação do prognóstico dos pacientes com MM recém-diagnosticado. O painel mínimo de investigação permite avaliar a presença de alterações moleculares de importância prognóstica como t(4;14), del17p13, t(14;16) e, quando disponível, deve-se realizar o painel ampliado para identificação das alterações de amplificação do 1q, t(11;14).  
Na confirmação do diagnóstico do MM, exames adicionais devem ser realizados para auxiliar o planejamento terapêutico. Estes exames incluem tempo de protrombina (TP) e tempo de tromboplastina parcial ativada (TTPa), fibrinogênio, d-dímero, bilirrubina total (BT) e frações, fosfatase alcalina, aminotransferases/transaminases, gama-glutamil transferase, ácido úrico e glicemia<sup>12</sup> . Se o nível de proteína-M estiver elevado (maior que 5 g/dL) ou o paciente apresentar sintomas sugestivos de hiperviscosidade, recomenda-se a dosagem da viscosidade sérica. Quando a dosagem da viscosidade sérica não estiver disponível, deve-se realizar o exame do fundo do olho simples ou retinografia fluorescente, por ser um método diagnóstico sensível para hiperviscosidade com repercussão clínica quando hemorragias retinianas, papiledema, distensão e dilatação de vasos (forma de salsicha) são detectados<sup>22</sup> . A avaliação laboratorial renal e hepática são necessárias para ajuste das doses de medicamentos e controle dos eventos adversos do tratamento<sup>12</sup> .  
Ao diagnóstico, a avaliação esquelética é obrigatória para o estadiamento do MM e deve ser repetida quando houver suspeita de progressão da doença. Os exames recomendados incluem ressonância nuclear magnética (RNM) e tomografia computadorizada (TC) de baixa dose de corpo inteiro<sup>23</sup> . A TC deve incluir avaliação do tórax, coluna, pelve e outras áreas esqueléticas relacionadas àquelas em que o paciente apresenta sintomas e a RNM de corpo inteiro é obrigatória no caso da TC de corpo inteiro negativa<sup>21</sup> .  
Na suspeita de recidiva, recomenda-se repetir os exames laboratoriais iniciais incluindo hemograma completo (contagem celular e esfregaço), níveis séricos de ureia e creatinina, cálcio, eletroforese e imunofixação de proteínas séricas e urinárias, dosagem sérica de imunoglobulinas (IgA, IgM, IgG e IgE), dosagem de cadeias kappa/lambda leves livres séricas monoclonais, albumina e desidrogenase láctica (DHL)<sup>21</sup> . O mielograma é opcional, entretanto, recomenda-se a avaliação citogenética por FISH para investigação das alterações moleculares. A TC de corpo inteiro é recomendada para avaliação dos pacientes com suspeita de recidiva.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3.3. Critérios Diagnósticos** -->
A atualização dos critérios diagnósticos publicados em 2014 pela IMWG ( _International Myeloma Working Group_ ) incluiu, além das lesões de órgão alvo classicamente utilizadas (CRAB), três biomarcadores de malignidade (aspirado de medula óssea, cadeias leves livres e lesões focais à ressonância magnética) que são avaliados a partir da biópsia de medula óssea, dosagem de cadeias kappa/lambda leves livres séricas e lesões focais. O acréscimo destes três eventos definidores de doença aumenta a sensibilidade do diagnóstico e possibilita a identificação precoce e o início oportuno do tratamento, antes que lesões de órgão alvo potencialmente graves se estabeleçam<sup>24</sup> . De acordo com a nova classificação, o diagnóstico do MM será confirmado com a presença de lesão de órgão alvo conforme critérios CRAB ou pela presença de, pelo menos, um evento definidor de doença<sup>24</sup> ( **Quadro 1** ).  
**Quadro 1 -** Critérios diagnósticos para mieloma múltiplo.  
|**CRAB**|**Parâmetro diagnóstico**|
|---|---|
|**Hipercalcemia**|Nível de cálcio sérico 0,25 mmol/L (1 mg/dL) ou mais acima do limite superior de<br>normalidade ou maior que 2,75 mmol/L (11 mg/dL).|
|**Insuficiência renal**|Clearance de creatinina menor que 40 mL/min ou creatinina sérica maior que 177<br>mmol/L (2 mg/dL).|
|**Anemia**|Nível de hemoglobina 2 g/dL ou mais abaixo do limite da normalidade ou hemoglobina<br>menor que 10 g/dL.|
|**Lesões ósseas**|Uma ou mais lesões osteolíticas à radiografia óssea, TC ou PET/CT*.|
|**Biomarcadores**|**Parâmetro diagnóstico**|
|**Aspirado de medula óssea**|Presença de 60% ou mais de células clonais na avaliação medular.|
|**Cadeias**<br>**kappa/lambda**<br>**leves**<br>**livres séricas**|Razão entre níveis séricos de cadeias leves envolvidas e não envolvidas maior ou igual<br>a 100, desde que o nível sérico de cadeias leves envolvidas seja de, pelo menos, 100<br>mg/L.|
|**Lesões focais à ressonância**<br>**magnética**|Mais de uma lesão focal à RNM de, pelo menos, 5 mm de tamanho.|  
<mark>Nota:</mark> *Na presença de menos de 10% de células plasmáticas clonais em medula óssea, são necessárias duas lesões para o diagnóstico diferencial com plasmocitoma solitário com acometimento medular mínimo.  
Legenda: CRAB - hipercalcemia, insuficiência renal, anemia e doença óssea.  
Fonte: Rajkumar, 2016.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3.4. Estratificação de risco e estadiamento** -->
O estadiamento e a estratificação do risco prognóstico dos pacientes com MM podem ser realizados por meio da versão revisada do Sistema de Estadiamento Internacional Revisado (R-ISS). Os pacientes são classificados, de acordo com alterações específicas encontradas no teste de hibridização _in situ_ por fluorescência (FISH), como alto risco, risco padrão e baixo risco<sup>25</sup> .  
A R-ISS destaca três alterações genéticas das células neoplásicas - t(4;14), t(14;16) e deleção 17p13 - que cursam com pior sobrevida global em cinco anos e pior sobrevida livre de progressão<sup>26,27</sup> . As menores taxas de sobrevida associadas ao alto risco citogenético tem gerado esforços para identificação de tratamentos e associações de medicamentos que possam melhorar o prognóstico destes pacientes<sup>27,28</sup> .  
Pacientes classificados como alto risco têm sobrevida global de 24,5 meses versus 50,5 meses para pacientes com risco padrão. As informações citogenéticas podem ainda ser utilizadas na tomada de decisão sobre início do tratamento, momento do transplante e esquema terapêutico a ser utilizado<sup>8,25</sup> ( **Quadro 2** ).  
**Quadro 2 -** Estratificação de risco prognóstico, conforme o Estadiamento Internacional Revisado para pacientes com mieloma múltiplo e relação com sobrevida global em cinco anos e sobrevida livre de progressão.  
|**R-ISS**|**Critérios**|**Sobrevida global estimada**<br>**em 5 anos (%)**|**Sobrevida livre de**<br>**progressão (meses)**|
|---|---|---|---|
|I|β2 -microglobulina <3,5mg/L<br>Albumina sérica≥3,5g/dL<br>Ausência de marcadores citogenéticos<br>LDH normal|82|66|
|II|Sem critérios de estágio I ou III|62|42|
||β2 -microglobulina≥5,5mg/L|||
|III|Presença de t(4;14), t(14;16) ou del17p13<br>LDH acima do limite superior|40|29|  
Legenda: LDH – Lactato desidrogenase. Fonte: Adaptado de Palumbo et al. 2015.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3.5. Diagnóstico diferencial** -->
Por ser uma doença proliferativa de plasmócitos, o diagnóstico diferencial do MM deve avaliar outras doenças proliferativas que envolvam essas células, tais como: GMSI não-IgM, GMSI IgM, GMSI de cadeias leves, MM latente, plasmocitoma solitário, plasmocitoma solitário com acometimento medular mínimo, leucemia de células plasmáticas, macroglobulinemia de Waldenström, amiloidose de cadeia leve (primária) e síndrome POEMS (polineuropatia, organomegalia, endocrinopatia, proteína M, alterações dermatológicas). O **Quadro 3** descreve os principais critérios para o diagnóstico diferencial de outras doenças<sup>29</sup> .  
**Quadro 3 -** Critérios diagnósticos para doenças de células plasmáticas.  
|**Diagnóstico**<br>**diferencial**|**Critérios diagnósticos**|
|---|---|
|**Gamopatia**<br>**Monoclonal de**<br>**Significado**<br>**Indeterminado não-**<br>**IgM**|**Todos os critérios abaixo devem ser atendidos:**<br>(1) Proteína monoclonal sérica (não-IgM) menor que 3 g/dL.<br>(2) Plasmócitos clonais na medula óssea menores que 10%.<br>(3) Ausência de evidência de outra doença proliferativa de células B.<br>(4) Ausência de lesão de órgão ou tecido alvo relacionado ao mieloma ou critérios CRAB que<br>possam ser atribuídos à outra doença proliferativa de células plasmáticas.|
||**Todos os critérios abaixo devem ser atendidos:**|
|**Gamopatia**|(1) Proteína monoclonal sérica (IgM) menor que 3 g/dL.|
|**Monoclonal de**|(2) Infiltração linfoplasmocitária de medula óssea menor que 10%.|
|**Significado**|(3) Ausência de evidência de outra doença proliferativa de células B.|
|**Indeterminado IgM**|(4) Ausência de sintomas constitucionais, linfadenopatia, hepatoesplenomegalia, anemia ou<br>hiperviscosidade que possam ser atribuídas a outra doença proliferativa de células plasmáticas.|
|**Gamopatia**|**Todos os critérios abaixo devem ser atendidos:**|
|**Monoclonal de**|(1) Razão anormal de cadeias leves (menor que 0,25 ou maior que 1,65).|
|**Significado**|(2) Níveis aumentados da cadeia leve envolvida (cadeia leve livre kappa aumentada em pacientes|
|**Indeterminado de**<br>**cadeias leves**|com razão maior que 1,65 e cadeia leve livre lambda aumentada em pacientes com razão menor<br>que 0,26).|  
||(3) Ausência de expressão de imunoglobulinas de cadeia pesada à imunofixação.<br>(4) Ausência de lesão de órgão ou tecido alvo relacionado ao mieloma ou critérios CRAB que<br>possam ser atribuídos a uma doença proliferativa de células plasmáticas.<br>(5) Proteína monoclonal urinária abaixo de 500 mg/24 horas.|
|---|---|
||**Todos os critérios abaixo devem ser atendidos:**|
|**Mieloma múltiplo**|(1) Proteína monoclonal sérica igual ou maior que 3 g/dL ou proteína monoclonal urinária igual|
|**latente**|ou maior que 500 mg/24 horas, ou 10 a 60% de plasmócitos monoclonais na medula óssea.<br>(2) Ausência de eventos definidores de mieloma ou amiloidose.|
||**Todos os critérios abaixo devem ser atendidos:**<br>(1) Lesão óssea ou de tecido mole única documentada em biópsia sem evidência de células<br>plasmáticas clonais.|
|**Plasmocitoma solitário**|(2) Medula óssea normal sem evidências de plasmócitos clonais.<br>(3) Avaliação esquelética normal à radiografia convencional e ausência de lesão espinhal e pélvica<br>à RNM ou TC, exceto pela lesão única primária.<br>(4) Ausência de lesão de órgão ou tecido alvo relacionado ao mieloma ou critérios CRAB que<br>possam ser atribuídos à outra doença proliferativa de células linfoplasmocíticas.|
||**Todos os critérios abaixo devem ser atendidos:**<br>(1) Lesão óssea ou de tecido mole única documentada em biópsia sem evidência de plasmócitos<br>|
|**Plasmocitoma solitário**<br>**com acometimento**<br>**medular mínimo**|clonais.<br>(2) Plasmócitos clonais na medula óssea menor que 10%.<br>(3) Avaliação esquelética normal à radiografia convencional e ausência de lesão espinhal e pélvica<br>à RNM ou TC, exceto pela lesão única primária.<br>(4) Ausência de lesão de órgão ou tecido alvo relacionado ao mieloma ou critérios CRAB que<br>possam ser atribuídos à outra doença proliferativa de células linfoplasmocíticas.|
||(1) Plasmócitos clonais circulantes em sangue periférico maiores que 2.000/µL (2 x 10⁹/L) ou 20%|
|**Leucemia de células**|de leucócitos.|
|**plasmáticas**|(2) Presença de proteína monoclonal, infiltração de medula óssea ou lesão de órgão ou tecido alvo<br>relacionado ao mieloma ou critérios CRAB complementam o diagnóstico, mas não são necessários.|
||**Ambos os critérios abaixo devem ser atendidos:**<br>(1) Gamopatia monoclonal IgM.|
|**Macroglobulinemia de**|(2) Infiltração linfoplasmocitária na medula maior ou igual a 10%.|
|**Waldenström**|**Outros possíveis achados:**<br>(1) Infiltrado linfoplasmocitário com expressão imunofenotípica típica.<br>(2) Anemia, hepatoesplenomegalia e sintomas sistêmicos tipicamente presente.|
||**Todos os critérios abaixo devem ser atendidos:**<br>(1) Presença de síndromes sistêmicas relacionadas à proteína amiloide (e.g., acometimento dos|
|**Amiloidose de cadeias**<br>**amiloides leves**<br>**(primária)**|sistemas nervoso periférico, renal, hepático, cardíaco ou gastrointestinal) que podem ser atribuídos<br>a uma doença proliferativa de células plasmáticas monoclonais.<br>(2) Marcação positiva de amiloide por vermelho Congo em qualquer tecido (e.g., aspirado adiposo,<br>medula óssea ou biópsia de órgãos) ou a presença de fibrilas amiloides à microscopia eletrônica.|
||(3) Evidência de que a proteína amiloide está relacionada a cadeias leves, determinada pela<br>avaliação direta da proteína amiloide com análise proteômica por espectrometria ou microscopia|  
||imunoeletrônica.<br>(4) Evidência de doença proliferativa de células plasmáticas monoclonal (e.g., presença de proteína<br>monoclonal sérica ou urinária, razão anormal de cadeias leves séricas ou células plasmáticas<br>clonais na medula óssea)|
|---|---|
|**Síndrome POEMS**<br>(polineuropatia,<br>organomegalia,<br>endocrinopatia, proteína<br>M, alterações<br>dermatológicas)|**Ambos os critérios abaixo devem ser atendidos:**<br>(1) Polineuropatia.<br>(2) Doença proliferativa de plasmócitos monoclonais.<br>**Ao menos um dos seguintes critérios maiores deve ser atendido:**<br>(1) Lesões osteoescleróticas ou mistas (esclerótica e lítica) com tamanho maior ou igual a 0,8 cm<br>em sua maior extensão.<br>(2) Doença de Castleman (hiperplasia linfonodal gigante, hiperplasia linfonodal angiofolicular).<br>(3) Níveis de fator de crescimento endotelial vascular elevados em, ao menos, três a quatro vezes<br>o limite superior de normalidade.<br>**Ao menos um dos seguintes critérios menores deve ser atendido:**<br>(1) Organomegalia (esplenomegalia, hepatomegalia ou linfadenopatia).<br>(2) Sobrecarga de volume extravascular (edema periférico, ascite ou derrame pleural).<br>(3) Endocrinopatia (exceto diabetes melito ou hipotireoidismo).<br>(4) Alterações dermatológicas (hiperpigmentação, hipertricose, acrocianose, pletora, hemangioma,<br>telangiectasia).<br>(5) Papiledema.|
||(6) Trombocitose ou policitemia.|  
Legenda: CRAB: acrônimo para hipercalcemia, insuficiência renal, anemia e doença óssea. Fonte: Traduzido e adaptado de Michels, 2017.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Devem ser incluídos nestas DDT todos os pacientes com diagnóstico de MM com idade igual ou superior a 19 anos.  
A indicação de transplante de células-tronco hematopoéticas (TCTH) deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, devendo todos os potenciais receptores estar inscritos no Sistema Nacional de Transplantes (SNT)<sup>30</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Não estão contemplados nestas DDT os pacientes com diagnóstico de plasmocitoma solitário, mieloma osteoesclerótico ou leucemia de células plasmáticas.  
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados nestas Diretrizes.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.1. Tratamento não medicamentoso** -->
- **6.1.1. Transplante de células-tronco hematopoéticas (TCTH)**  
O TCTH autólogo é o padrão ouro no tratamento do paciente com MM e a avaliação da sua indicação deve ser considerada precocemente no planejamento terapêutico<sup>12,31</sup> . A elegibilidade ao procedimento é regulada pela Política Nacional de Transplantes e inclui pacientes com idade inferior a 75 anos, níveis de bilirrubina direta até 2,0 mg/dL e creatinina sérica até 2,5 mg/dL, exceto se o paciente estiver em terapia renal substitutiva crônica e estável; capacidade funcional 0, 1 ou 2 pela escala Zubrod, exceto se comprometida principalmente por dor óssea, e, função cardíaca preservada, conforme classe funcional I ou II da _New York Heart Association_<sup>12,30</sup> . O TCTH alogênico não é recomendado, mas pode ser considerado para pacientes de alto risco<sup>32</sup> .  
Um segundo TCTH autólogo não é rotineiramente recomendado, mas pode ser considerado para pacientes que não alcançaram, no mínimo, resposta parcial muito boa após o primeiro transplante; para pacientes com alto risco citogenético ou para pacientes que recaíram 18 meses após o primeiro TCTH<sup>12,21</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.1. Pacientes elegíveis ao TCTH** -->
O objetivo terapêutico para os pacientes com MM elegíveis ao TCTH é a indução de máxima resposta, sem toxicidade limitante<sup>31</sup> . As etapas consistem em terapia de indução, coleta de células-tronco hematopoiéticas, condicionamento com quimioterapia em alta dose, TCTH autólogo e terapia de manutenção<sup>12,21,32</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.1.1. Terapia de indução** -->
O melhor tratamento disponível deverá ser utilizado para indução, priorizando-se o uso de terapia tripla que inclua, pelo menos, inibidor de proteassoma e corticoide<sup>21</sup> . Outros medicamentos disponíveis para a terapia de indução são agentes alquilantes (ciclofosfamida e cisplatina), antraciclinas (doxorrubicina e doxorrubicina lipossomal), inibidores da topoisomerase (etoposido) e alcaloides da vinca (vincristina)<sup>12</sup> . Especificamente em relação ao inibidor de proteassoma, conforme a Portaria SCTIE/MS nº 43/2020, o bortezomibe foi incorporado no âmbito do SUS para uso em combinação com outros medicamentos no tratamento de pacientes com MM, recém-diagnosticado, elegíveis ao transplante de células-tronco hematopoiéticas<sup>30</sup> . O número de ciclos de indução para os pacientes elegíveis ao TCTH não está definido, mas deve ser de, pelo menos, 3 ou 4 ciclos<sup>12,32</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.1.2. Condicionamento pré-TCTH** -->
<mark>O esquema de condicionamento pré-TCTH recomendado é melfalana 200 mg/m</mark><sup>2</sup> <mark>em dose única, a ser administrada no dia -1 ou -2, conforme protocolo institucional. A infusão das células tronco é realizada posteriormente no dia 0</mark><sup>12,21,32–35</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.1.3. Consolidação** -->
A terapia de consolidação é definida como esquema terapêutico fixo, administrado após o transplante, com finalidade de aumentar a resposta terapêutica<sup>12</sup> . No entanto, a consolidação não deve ser considerada rotineiramente. A indicação desta etapa do tratamento deve ser individualizada<sup>21,32</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.1.4. Manutenção** -->
Os pacientes submetidos ao TCTH podem receber a terapia de manutenção, que consiste na administração prolongada de medicamentos com baixa toxicidade na tentativa de prevenir a progressão da doença<sup>36</sup> . O objetivo da manutenção é aumentar o tempo de remissão da doença com boa qualidade de vida. Os imunomoduladores são indicados para terapia de manutenção. A talidomida é o imunomodulador disponível no âmbito do SUS, mas os eventos adversos associados a este medicamento podem limitar a duração do tratamento e não há estudos que demonstrem aumento da sobrevida global<sup>12</sup> .  
A utilização de lenalidomida para terapia de manutenção em pacientes submetidos ao TCTH autólogo foi avaliada para esta Diretriz. Na síntese de evidências para atualização deste documento, a estimativa de efeito da comparação indireta entre lenalidomida e talidomida não mostrou diferença entre as duas tecnologias para o desfecho sobrevida global [ _Hazard ratio_ (HR) de 0,58; Intervalo de Confiança de 95% (IC95%) de 0,30 a 1,11]. Em relação à sobrevida livre de progressão, o resultado da meta-análise foi favorável à lenalidomida, indicando que esta é 36% superior à talidomida (HR de 0,64; IC95% de 0,48 a 0,86). Quanto aos eventos adversos, não houve diferença na ocorrência de eventos adversos graus 3 e 4 entre a lenalidomida e a talidomida [Risco Relativo (RR) de 0,75; IC95% de 0,20 a 2,86]. Quanto aos eventos adversos neurológicos, incluindo a neuropatia periférica, a estimativa de efeito indireta também se apresentou inconclusiva quanto à superioridade da lenalidomida (RR de 0,33; IC95% de 0,73 a 3,11). O medicamento foi avaliado pela Conitec, entretanto, após recomendação desfavorável à incorporação, o medicamento não foi incorporado ao SUS para esta indicação, conforme Portaria SCTIE/MS nº 21/2022<sup>37</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.2. Pacientes inelegíveis ao TCTH** -->
Pacientes inelegíveis ao TCTH podem iniciar terapia de indução completa com imunomoduladores e inibidores de proteassoma<sup>31</sup> . O bortezomibe pode ser utilizado, uma vez que foi incorporado no âmbito do SUS para uso em combinação com outros medicamentos no tratamento de pacientes com MM, recém-diagnosticado, inelegíveis ao transplante de células-tronco hematopoiéticas, de acordo com a Portaria SCTIE/MS nº 45/2020<sup>38</sup> . Conforme a tolerância destes pacientes, a dose de talidomida pode ser modificada, a fim de minimizar eventos associados à toxicidade, uma vez que o medicamento deve ser mantido até a progressão da doença<sup>12,39</sup> . A combinação de bortezomibe, lenalidomida e dexametasona apresenta bons resultados em relação à sobrevida global e livre de progressão.  
A utilização de lenalidomida para pacientes inelegíveis ao TCTH foi avaliada pela Conitec. Na síntese de evidências elaborada para esta atualização, em relação aos eventos adversos, a comparação entre os esquemas RDc (lenalidomida e dexametasona) e TDc (talidomida e dexametasona), em relação à sobrevida global, foi avaliada por três revisões sistemáticas, que mostraram uma superioridade para o esquema de RDc quando comparado ao TDc (HR de 0,32; IC95% de 0,20 a 0,52), (HR de 0,44; IC95% de 0,20 a 0,97) e (HR de 0,36; IC95% de 0,23 a 0,55). A comparação da sobrevida global entre os esquemas MPR-R (melfalana, prednisona e lenalidomida com manutenção de lenalidomida) e MPT-T (melfalana, prednisona e talidomida com manutenção de talidomida) também foi avaliada pelas mesmas revisões sistemáticas e em nenhuma delas houve diferença entre os dois esquemas (HR de 1,08; IC95% de 0,90 a 1,30), (HR 0,89; IC95% de 0,66 a 1,21) e (HR de 0,91; IC95% de 0,75 a 1,10])<sup>40</sup> . Considerando os eventos adversos avaliados, pacientes tratados com MPR-R apresentaram menor risco de EA graves do que aqueles tratados com MPT-T (RR de 0,79; IC95% de 0,67 a 0,93). Pacientes tratados com RDc apresentaram menor risco de EA neurológicos graus 3 e 4 do que aqueles tratados com TDc (RR 0,02; IC95% de 0,004 a 0,12). Ademais, pacientes tratados com MPR-R apresentaram menor risco de polineuropatia graus 3 e 4 do que aqueles tratados com MPT-T (RR de 0,13; IC95% de 0,05 a 0,32). Não houve diferença entre os esquemas RDc versus TDc e MPR-R versus MPT-T (RR de 0,29; IC95% de 0,05 a 1,65) e (RR 0,79; IC95% de 0,50 a 1,24), respectivamente) em relação à taxa de suspensão do tratamento<sup>40</sup> . O medicamento foi avaliado pela Conitec, entretanto, após recomendação desfavorável à incorporação, o medicamento não foi incorporado ao SUS para esta indicação, conforme Portaria SCTIE/MS nº 16/2022<sup>40</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.3. Pacientes refratários ou em recidiva** -->
Apesar dos avanços terapêuticos nos últimos anos, o MM permanece uma doença incurável e quase todos os casos se tornam refratários aos tratamentos padrão<sup>41</sup> . O objetivo terapêutico para os pacientes com MM recidivado ou refratário é <mark>controlar a progressão da doença, com eventos adversos aceitáveis, e manter a qualidade de vida do paciente pelo maior tempo possível</mark><sup>42</sup> <mark>.</mark>  
A recidiva pode ser classificada como clínica ou como bioquímica isolada. Pacientes com recidiva clínica são sintomáticos e apresentam piora da lesão de órgão alvo, como evolução das lesões ósseas ou surgimento de novas lesões, plasmocitomas,  
anemia, insuficiência renal ou hipercalcemia<sup>43</sup> . Nestes casos, recomenda-se que a terapia de resgate seja iniciada imediatamente<sup>32</sup> .  
Já a recidiva bioquímica isolada se apresenta com aumento assintomático dos níveis séricos do componente monoclonal<sup>44,45</sup> . A observação cuidadosa é apropriada para pacientes com recidiva lentamente progressiva, requerendo monitoramento dos sintomas e da função dos órgãos e avaliação frequente dos níveis de paraproteína do mieloma. Entretanto, o tratamento pode ser considerado naqueles pacientes com alto risco citogenético, doença extramedular, recidiva após transplante ou terapia inicial ou evidência de rápido aumento nos seguintes marcadores de MM<sup>12,32</sup> :  
a) Duplicação da componente M em duas medidas consecutivas, separadas por até dois meses;  
b) aumento nos níveis absolutos da proteína M sérica maior ou igual a 1 g/dL;  
c) aumento da proteína M urinária maior ou igual a 500 mg/24h; ou  
d) aumento dos níveis da cadeia leve livre envolvida maior ou igual a 20 mg/dL e uma razão de dosagem de cadeias kappa/lambda leves livres séricas anormal em duas medidas consecutivas separadas por até dois meses.  
O tratamento deve ser individualizado e a escolha deve considerar fatores relacionados ao paciente, como idade, comorbidades (neuropatia, insuficiência renal), _performance status_ e preferências do paciente _;_ relacionados à doença, como a sua natureza (comportamento indolente ou agressivo), duração da resposta aos tratamentos prévios, risco citogenético e características da recidiva; e relacionados ao tratamento, como os medicamentos já utilizados anteriormente e a resposta do paciente a eles, bem como as reações adversas apresentadas, número de tratamentos, via de administração e a disponibilidade do medicamento<sup>32,46</sup> .  
<mark>Os diferentes tipos de tratamentos do MM recidivado ou refratário incluem novo TCTH autólogo, repetição do uso de medicamentos anti-mieloma já utilizados anteriormente ou uso de outros medicamentos não utilizados na primeira linha</mark><sup>12,21,46</sup> <mark>.</mark> Até o momento, não há um consenso sobre qual é a melhor sequência e combinação de medicamentos a ser utilizada por estes pacientes<sup>46</sup> . No entanto, na primeira recidiva, esquemas com três medicamentos, envolvendo aqueles não utilizados na terapia prévia, são recomendados<sup>12,32,47</sup> . Os esquemas podem incluir inibidores de proteassoma (bortezomibe), agentes alquilantes (ciclofosfamida e cisplatina), corticosteroides (dexametasona), antraciclinas (doxorrubicina e doxorrubicina lipossomal), inibidores da topoisomerase (etoposido) e alcaloides da vinca (vincristi <mark>na). O</mark> bortezomibe está disponível no âmbito do SUS para uso em combinação com outros medicamentos no tratamento de pacientes com MM recidivados ou refratários, conforme a Portaria SCTIE/MS nº 44/2020<sup>48</sup> .  
A utilização de daratumumabe para pacientes com mieloma múltiplo recidivado ou refratário já foi avaliada pela Conitec. Na síntese de evidências, foi incluído apenas um ensaio clínico que identificou superioridade de daratumumabe + bortezomibe + dexametasona comparado a bortezomibe + dexametasona para sobrevida livre de progressão (16,7 vs. 7,1 meses; HR de 0,31; IC 95% de 0,31 a 0,39) (qualidade da evidência moderada), taxa de resposta geral (83,9% vs. 60,7%; p < 0,001), taxa de resposta completa (28,2% vs. 8,9%; p < 0,0001) e taxa de resposta parcial muito boa (60,9% vs. 29,2%; p < 0,0001). A mediana da sobrevida global não foi alcançada e por isso não foi reportada. A qualidade de vida relacionada à saúde foi mantida para os pacientes de ambos os grupos (p > 0,05) (qualidade da evidência alta) entre o início e o final do estudo. Considerando os desfechos de segurança reportados, daratumumabe não parece aumentar o risco de suspensão (7,4% para esquema com daratumumabe vs. 9,3% para esquema sem daratumumabe) (qualidade da evidência alta) ou a incidência de eventos adversos (98,8% vs. 95,4%)<sup>49</sup> . O medicamento foi avaliado pela Conitec para esta indicação. No entanto, após recomendação desfavorável à incorporação, o medicamento não foi incorporado ao SUS para esta indicação, conforme Portaria SCTIE/MS nº 18/2022<sup>49</sup> .  
O fluxo de diagnóstico e tratamento do Mieloma Múltiplo está descrito na **Figura 1** .  
**Figura 1 -** Fluxo de diagnóstico e tratamento do Mieloma Múltiplo.  
<!-- Start of picture text -->
—<br>INESPECIFICOS(1)<br>Ma DIFERENCIAL<br>Suspeita clinica suspeita de DIAGNOsTICO<br>a Ak Sern ie = vo<br>O ECA<br>pasted soRaTORNs <> O<br>so<br>ASSINTOMATICOS<br>3<br>° nal<br>2 LABORATORIAIS<br>Es cee<br>3 | oe<br>F var<br>& | 8 | | conrimmacko Nao<br>@ |3)| Suenomde<br>2 |S<br>383\2 ,<br>z= prrate<br>2 MEDULA OSSEA (6)<br>Z<br>g<br>§& iwoveo><br>g EXAMES pon<br>2 on ee<br>ae<br>sim<br>TSIADIAMENTOE FUNDO DE OLHO Ege 0 TnuiachooA<br>PLANAMENTOmes OU RETINOGRAFIAee oe oaRESPOSTA<br>ro<br>=<br>:<br>es<br>o<br>REPLANEJAMENTOse sim Nio<br>sorter<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.3. Pacientes refratários ou em recidiva** -->
1. Fadiga, perda de peso, infecções recorrentes, dispneia, náusea, vômito, sangramento, compressão medular.  
2. Dor óssea, lesão osteolítica, fratura patológica.  
3. Alterações laboratoriais, hipercalcemia, falência renal, proteína.s totais elevadas, proteinemia monoclonal.  
4. Hemograma, ureia, creatinina, eletrólitos, proteínas totais, albumina, cálcio, urina, eletroforese sérica e urinária com imunofixação, dosagem de imunoglobulinas, dosagem de cadeias kappa/lambda leves livres séricas, lactato desidrogenase.  
5. Beta-2 microglobulina, proteína-C reativa, velocidade de hemossedimentação, proteinúria de 24 horas.  
6. Mielograma e imunofenotipagem por FISH.  
7. Tempo de atividade de protrombina, tempo de tromboplastina parcial ativada, fibrinogênio, d-dímero, bilirrubina total e frações, fosfatase alcalina,  
transaminases, gama-glutamil transferase, ácido úrico, glicemia, viscosidade sérica (se proteína-M > 5 g/dL).  
8. Ressonância magnética nuclear, tomografia computadorizada incluindo coluna, tórax e pelve.  
9. Idade igual ou inferior a 75 anos, bilirrubina total até 2 mg/dL, creatinina sérica até 2,5 mg/dL, capacidade funcional 0, 1 ou 2 (Escala Zubrod), função cardíaca preservada (NYHA classe funcional I ou II).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.4. Medicamentos e esquemas de administração** -->
<mark>Diversos medicamentos são utilizados para o tratamento do MM e as opções terapêuticas foram ampliadas nos últimos anos. O</mark> **Quadro 4** re <mark>sume os principais medicamentos e doses recomendadas para composição dos esquemas terapêuticos</mark><sup>12</sup> . As <mark>doses, frequências de utilização e dias de administração dos medicamentos deverão ser avaliadas conforme o protocolo institucional.</mark>  
**Quadro 4 -** Medicamentos utilizados no tratamento de pacientes com mieloma múltiplo, tratados pelo Sistema Único de Saúde*.  
|**Agentes**|**Via de administração**|**Dose**|**Frequência**|
|---|---|---|---|
|**Imunomoduladores**||||
|Talidomida<sup>a</sup>|Oral|50-200 mg|1 x ao dia**|
|**Inibidores de proteassoma**||||
|Bortezomibe<sup>b</sup>|IntravenosoSubcutâneo|1,3 mg/m<sup>2</sup>|2 x semana ou1 x semana|
|**Alquilantes**||||
|Ciclofosfamida<sup>c,d</sup>|Oral|300 mg/m<sup>2</sup>|1 x semana|
||Intravenoso|400 mg/m<sup>2</sup>|1 x dia**|
||Oral|9 mg/m<sup>2</sup>|1 x ao dia**|
|Melfalana<sup>e</sup>|Intravenoso|200 mg/m<sup>2</sup>|Dose<br>única<br>para<br>condicionamento pré-TCTH|
|Cisplatina<sup>d</sup>|Intravenoso|10 mg/m<sup>2</sup>|1 x dia**|
|**Esteroides**||||
|Dexametasona<sup>f</sup>|Oral|40 mg|1 x dia **|
|Prednisona<sup>e</sup>|Oral|60 mg/m<sup>2</sup>|1 x ao dia**|
|**Antraciclinas**||||
|Doxorrubicina<sup>f</sup>|Intravenoso|9 mg/m<sup>2</sup>|1 x dia**|
|Doxorrubicina lipossomal<sup>g</sup>|Intravenoso|30 mg/m<sup>2</sup>|Dose única por ciclo**|
|<br>**Inibidores da topoisomerase**||||
|Etoposido<sup>d</sup>|Intravenoso|40 mg/m<sup>2</sup>|1 x dia**|
|**Alcaloides da vinca**||||
|Vincristina<sup>f</sup>|Intravenoso|0,4 mg|1 x dia**|  
<mark>Nota: *As doses e frequências de utilização dos medicamentos listados deverão ser avaliadas conforme o protocolo institucional. Os ajustes das doses conforme</mark>  
<mark>idade, exames laboratoriais ou toxicidade</mark> **<u><mark>não</mark></u>** <mark>estão descritos neste Quadro. **Atenção aos dias de administração dos medicamentos propostos nos protocolos de tratamento específicos.</mark>  
Fontes: a. Brasil 2015<sup>12</sup> , Rosiñol et al. 2012<sup>50</sup> ; b. VELCADE, 2017<sup>51</sup> ; c. Reeder et al. 2014<sup>52</sup> ; d. Park et al. 2014<sup>53</sup> ; e. San Miguel et al. 2008<sup>54</sup> ; f. Anderson et al. 1995<sup>55</sup> ; g. Orlowski et al. 2007<sup>56</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.5. Prevenção e tratamento das lesões ósseas** -->
A doença óssea é uma das principais manifestações clínicas do MM, ocorre em consequência da destruição óssea e pode se manifestar como lesões osteolíticas ou osteopenia, causando dor intensa, fraturas, compressão da medula espinhal e hipercalcemia<sup>44,57</sup> . A destruição óssea ocorre pelo aumento da atividade osteoclástica (reabsorção óssea) por meio de fatores ativadores dos osteoclastos que são produzidos pelas células tumorais e não tumorais na medula óssea<sup>44</sup> .  
A prevenção de fratura patológica é importante no paciente com MM, por meio da terapia profilática com a administração de inibidores da osteólise (bisfosfonatos). O uso de bisfosfonatos é recomendado em todos os pacientes, independente do diagnóstico de doença óssea, embora os benefícios de seu uso em pacientes sem doença óssea diagnosticada pelo PET-CT ou RM de corpo inteiro, sejam questionáveis<sup>21</sup> .  
O ácido zoledrônico é o bisfosfonato mais indicado para pacientes recém diagnosticados com MM sem acometimento ósseo<sup>58</sup> e a dose de 4 mg deve ser administrada por via intravenosa, uma vez ao mês<sup>12,59</sup> . Uma vez que ele tenha sido utilizado por, pelo menos, 12 meses e que a resposta clínica obtida tenha sido parcial, muito boa ou completa, pode-se considerar reduzir a frequência do tratamento (a cada três meses, a cada seis meses ou anualmente) ou suspende-lo<sup>58</sup> . O tempo máximo de uso do medicamento é de 24 meses. No entanto, apenas pacientes que não alcançaram resposta parcial após tratamento inicial do MM podem utilizar por tempo superior. Na recidiva, o ácido zoledrônico pode ser reiniciado<sup>21</sup> . Quando o ácido zoledrônico não estiver disponível ou quando for contraindicado, o pamidronato, outro bisfosfonato, pode ser utilizado<sup>58</sup> . A dose recomendada do <mark>pamidronato é de 90 mg, uma vez por mês, por via intravenosa, diluída em 500 mL de solução de infusão livre de cálcio e administrada em quatro horas</mark><sup>12,60</sup> <mark>.</mark>  
Todos os pacientes com MM acometidos por doença óssea no momento do diagnóstico devem ser tratados com bisfosfonatos (ácido zoledrônico ou pamidronato), de acordo com o esquema de administração preconizado nesta Diretriz<sup>21,58</sup> .  
<mark>A suplementação oral com vitamina D (400 UI/dia, via oral) e cálcio (500 mg/dia, via oral) é mandatória para evitar hipocalcemia induzida por bisfosfonatos. Em pacientes que apresentem hipercalcemia, a suplementação deve ser iniciada,</mark> após a normalização de cálcio sérico<sup>12,21,58,59</sup> . Pacientes com insuficiência renal e que tenham recebido suplementação de cálcio devem ser monitorados<sup>58</sup> .  
Os bisfosfonatos são potencialmente nefrotóxicos<sup>21,57</sup> . <mark>Deve-se monitorar, mensalmente, o clearance de creatinina e os níveis de eletrólitos séricos nos pacientes que usam</mark> pamidronato ou outro bisfosfonato. A dosagem da albumina urinária deve ser feita, também mensalmente, quando o pamidronato estiver sendo utilizado<sup>58</sup> . Ajustes de dose, a depender do clearance de creatinina, podem ser necessários e devem ser feitos de acordo com a bula do medicamento registrada na ANVISA. Pacientes com clearance de creatinina inferior a 30 mL/min não devem utilizar bisfosfonatos<sup>21,57</sup> .  
Os pacientes devem ser aconselhados quanto ao reconhecimento e relato de eventos adversos aos medicamentos<sup>58</sup> . Nesse sentido, a equipe multiprofissional, destacando os farmacêuticos e enfermeiros, desempenha papel importante.  
A avaliação por ortopedista deve ser solicitada em caso de fratura iminente ou atual de ossos longos, de compressão óssea da medula espinhal ou de instabilidade da coluna vertebral<sup>12</sup> , situações em que procedimentos cirúrgicos ortopédicos podes ser recomendados<sup>21</sup> . A indicação do procedimento cirúrgico deve ocorrer em decisão conjunta com o hematologista, ortopedista ou neurocirurgião, para determinar quando o tratamento do MM pode ser reiniciado com segurança<sup>12</sup> . A cifoplastia com balão pode ser considerada para fraturas de compressão vertebral sintomáticas<sup>21,58</sup> . Ademais, baixas doses de radiação (até 30 Gy) podem ser usadas para paliação da dor não controlada, fratura patológica iminente ou compressão de coluna espinhal iminente por MM<sup>21</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.6. Prevenção e tratamento da insuficiência renal** -->
A insuficiência renal é uma complicação comum e grave do MM, considerada emergência médica e fator de mau prognóstico. Estima-se que ela afete de 20% a 30% dos pacientes no momento do diagnóstico, podendo atingir até 50% dos pacientes durante o curso da doença e levar até 12% dos pacientes a necessitar de terapia renal substitutiva<sup>21,61,62</sup> .  
As causas da insuficiência renal no paciente com MM incluem dano tubular causado pela excreção de imunoglobulinas de cadeias leves e, consequentemente, nefropatia obstrutiva (também conhecida como “rim do mieloma”). Esta insuficiência também pode estar associada a outras causas, como hipercalcemia, sepse, desidratação, uso de medicamentos nefrotóxicos e contraste endovenoso<sup>63,64</sup> . Por isso, devem ser adotadas medidas para prevenção da insuficiência renal: monitoramento da ingesta  
hídrica e promoção do uso racional de medicamentos potencialmente nefrotóxicos (aminoglicosídeos, anti-inflamatórios não esteroidais, inibidores da enzima conversora de angiotensina, anfotericina B, diuréticos de alça, bisfosfonatos e contraste iodado venoso). Também deve ser realizado um acompanhamento rigoroso da função renal (creatinina sérica, ureia, sódio, potássio, cálcio, taxa de filtração glomerular, exame de urina de 24 horas) e das concentrações de cadeia leve<sup>12,61,63–65</sup> .  
Além das medidas preventivas, o paciente deve ser acompanhado por nefrologista, caso a função renal não seja <mark>restabelecida até 48 horas após as intervenções iniciais. Deve haver uma comunicação clara entre o médico assistente e nefrologista para otimizar o resultado terapêutico</mark><sup>12</sup> <mark>. A biópsia renal é desejável para ajudar na decisão terapêutica, mas não é essencial</mark><sup>12,61</sup> <mark>. A plasmaférese ou hemofiltração tem sido sugerida para remoção física das cadeias leves, entretanto, seu papel permanece controverso</mark><sup>12,61,66,67</sup> <mark>.</mark>  
<mark>A hidratação adequada é essencial e deve ser assegurada em todos os pacientes com MM e insuficiência renal</mark><sup>65</sup> <mark>. A administração de soluções salinas hipotônicas pode ser mais va</mark> ntajosa do que as soluções fis <mark>iológicas, já que a formação de cilindros na alça de Henle é favorecida quando a concentração de cloreto de sódio está acima de 80 mmol/L</mark><sup>12</sup> <mark>.</mark>  
O tratamento do paciente com MM e insuficiência renal deve ser iniciado o mais precocemente possível, preferencialmente com esquemas de tratamento que incluem bortezomibe, associado a altas doses de dexametasona durante o primeiro mês. Não há informações sobre esquemas específicos para pacientes em terapia renal substitutiva. A talidomida é efetiva em pacientes com MM com insuficiência renal e pode ser administrada sem alteração de dose. Para os pacientes que recebem altas doses de quimioterapia como condicionamento para o TCTH, a dose de melfalana deve ser restrita a 100 a 140 mg/m<sup>2 21</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.7. Profilaxia e controle das infecções** -->
As infecções relacionadas à imunossupressão (da doença e seu tratamento) são uma importante causa de morbimortalidade em pacientes com MM, de modo que todas as medidas para evitá-las devem ser instituídas<sup>68</sup> .  
Os pacientes com MM que apresentam alto risco de desenvolver infecções graves podem receber profilaxia antimicrobiana segundo protocolos institucionais. Contudo, sua indicação deve ser individualizada de acordo com o histórico de infecções, idade, atividade da doença, tipo e duração dos tratamentos prévios, nível de imunossupressão e comorbidades. Portanto, a profilaxia antimicrobiana não deve ser recomendada como rotina e deve ter indicação individualizada<sup>12,69</sup> .  
Os pacientes tratados com inibidores de proteassoma (bortezomibe), altas doses de corticoide ou altas doses de melfalana seguida de TCTH autólogo deverão receber profilaxia com aciclovir, a fim de reduzir o risco de reativação do vírus varicela zoster<sup>68,69</sup> .  
Quando o paciente com mieloma apresentar hipogamaglobulinemia e sofrer infecções graves ou recorrentes, pode-se considerar a reposição de imunoglobulinas. No entanto, a profilaxia de infecções não é recomendada rotineiramente<sup>12</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.2.8. Vacinação** -->
Os pacientes devem ser vacinados o mais cedo possível<sup>68</sup> . Recomenda-se que os pacientes que iniciarão o tratamento do MM devam ser vacinados, pelo menos, 14 dias antes do início do tratamento, antes da mobilização e coleta de células-tronco; quando o paciente atingir a melhor resposta à terapia; três a seis meses após a conclusão da quimioterapia ou TCTH autólogo, e; seis a 12 meses após o TCTH alogênico<sup>12,68</sup> . A vacinação entre os ciclos de quimioterapia não é recomendada, devido à provável redução da sua eficácia<sup>12</sup> .  
As vacinas recomendadas para pacientes com neoplasias submetidos à quimioterapia, radioterapia ou corticoterapia e pessoas que convivem com esses pacientes estão descritas no **Quadro 5**<sup>70</sup> . Preferencialmente, o paciente com MM deverá receber vacinas inativadas, enquanto as vacinas vivas podem ser consideradas para pacientes com GMSI ou MM assintomático (latente), bem como nos demais pacientes que se encontrarem em remissão da doença, três a seis meses após o término da quimioterapia<sup>12,68</sup> .  
Para os pacientes submetidos ao TCTH, o esquema vacinal deverá ser planejado, de acordo com o Manual dos <mark>Centros de Referência para Imunobiológicos Especiais (C</mark> RIE)<sup>70</sup> .  
**Quadro 5 -** Vacinas recomendadas para pacientes com MM, cuidadores e familiares, conforme as recomendações do Manual dos Centros de Referência para Imunobiológicos Especiais, para pacientes submetidos à quimioterapia, radioterapia ou corticoterapia<sup>a</sup> .  
||**Paci**|**entes**||
|---|---|---|---|
|**Vacinas**|**Antes do**<br>**tratamento**|**Durante o**<br>**tratamento**|**Convivente**<sup>**d**</sup>|
|Bacilo de Calmette-Guérin (BCG)|Não|Não||
|Vacina adsorvida difteria, tétano e pertussis (DPT)/ Vacina<br>adsorvida difteria e tétano adulto (dT)/ Vacina adsorvida<br>difteria, tétano e pertussis (acelular adulto) (dTpa)|Sim|Sim||
|Vacina poliomielite 1, 3 atenuada oral (VOP)|Não|Não|Não|
|Vacina poliomielite 1, 2, 3 inativada, injetável (VIP)|Sim|Sim|Sim|
|Vacina hepatite B (HB)|Sim|Sim||
|Vacina tríplice viral|Sim<sup>c</sup>|Não|Sim<sup>b</sup>|
|Vacina Varicela (VZ)|Sim<sup>c</sup>, se suscetível|Não|Sim, se<br>suscetível|
|Vacina Febre Amarela (FA)|Sim<sup>c</sup>|Não||
|Vacina influenza inativada (INF)|Sim|Sim|Sim|
|Vacina hepatite A (HA)|Sim|Sim||
|Vacina meningocócica C conjugada (Meningo C) (2 doses)|Sim|Sim||
|HPV (3 doses)|Sim (9 a 26 anos)|Sim (9 a 26 anos)||
|Vacina pneumocócica 13-valente (conjugada) (PCV13) ou<br>Vacina pneumocócica 23-valente (de polissacarídeos)<br>(PCV23)|Sim|Sim||  
Notas: a. Seguir sempre que possível, os intervalos do calendário vacinal de rotina do Programa Nacional de Imunizações. b. De acordo com as normas de vacinação de rotina do Programa Nacional de Imunizações. c. Se não houver doenças que contraindicam o uso de vacinas vivas. d. Além das vacinas aqui recomendadas, aqueles que convivem com estes pacientes deverão receber as vacinas do calendário normal de vacinação do Programa Nacional de Imunizações, conforme idade. A vacinação contra rotavírus e tuberculose, devido à faixa etária restrita, dificilmente serão aplicáveis a estes indivíduos, mas não estão contraindicadas para os conviventes domiciliares de pacientes imunossuprimidos. Fonte: Adaptado de BRASIL, 2019.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.3. Avaliação da resposta terapêutica** -->
A monitorização do tratamento inclui a dosagem de proteína-M, avaliação esquelética e biópsia de medula óssea para avaliação da resposta completa. Os critérios de resposta, de acordo com as diretrizes anteriores e as recomendações do IMWG<sup>12,45</sup> , estão descritos no **Quadro 6** .  
**Quadro 6 -** Critérios de resposta ao tratamento.  
|**Resposta**|**Critérios**|
|---|---|
||- Imunofixação sérica e urinária negativas.|
|Resposta completa|- Desaparecimento de plasmocitoma de tecidos moles.|
||- Até 5% de plasmócitos na Medula Óssea (MO).|  
||- Critérios de resposta completa atendidos.|
|---|---|
|Resposta completa estrita|- Relação de cadeias kappa/lambda leves livres séricas normal.<br>- Ausência de plasmócitos clonais na MO por imuno-histoquímica.|
|Resposta parcial muito boa|- Componente-M sérico e urinário detectável por imunofixação, mas não por eletroforese de<br>proteínas.<br>- Redução igual ou maior que 90% da proteína-M sérica.<br>- Redução da proteína-M urinária para menos de 100 mg/24h.|
|Resposta parcial|- Redução igual ou maior que 50% na proteína-M sérica.<br>- Redução igual ou maior que 90% na proteína-M urinária ou para menos de 200 mg/24h<br>OU redução igual ou maior que 50% da diferença entre cadeias leves livres envolvidas e não<br>envolvidas, quando não for possível obter o critério de redução de proteína-M<br>OU redução igual ou maior que 50% dos plasmócitos da MO (se basal for igual ou maior<br>que 30%) e redução igual ou maior que 50% no tamanho de plasmocitomas de tecidos moles<br>identificados previamente.|
|Resposta mínima|- Redução de 25% a 49% na proteína-M sérica.<br>- Redução de 50 a 89% na proteína-M urinária.<br>- Redução de 50% do tamanho de plasmocitoma de tecidos moles, se identificados<br>previamente.|
||Qualquer um dos critérios abaixo:<br>**A)** **Aumento de 25% do menor valor de resposta confirmado em, pelo menos, um dos**<br>**critérios:**<br>● Proteína- M Sérica (Aumento absoluto de proteína-M sérica igual ou maior que 0,5 g/dL);<br>● proteína-M sérica (Aumento igual ou maior que 1g/dL, se o menor componente M era igual<br>ou maior que 5g/dL);<br>● proteína-M urinária (Aumento absoluto de proteína-M urinária igual ou maior que 200<br>mg/24h);<br>● em pacientes sem níveis mensuráveis de proteína-M sérica ou urinária, a diferença entre|
|Doença progressiva|cadeias leves livres envolvidas e não envolvidas deve ter aumento absoluto igual ou maior<br>que 10mg/dL;<br>● em pacientes sem níveis mensuráveis de proteína-M sérica ou urinária e sem níveis<br>mensuráveis da relação de cadeias kappa/lambda leves livres séricas, deve haver aumento<br>absoluto de plasmócitos na medula óssea igual ou maior que 10%, independente do nível<br>basal.<br>**B)** **Aparecimento de nova lesão ou aumento de igual ou maior que 50% na lesão de**<br>**maior diâmetro.**<br>**C) Aumento igual ou maior que 50% nos plasmócitos circulantes (mínimo de 200**<br>**células/microL).**|
|Recaída após resposta<br>completa|- Reaparecimento de proteína-M sérica ou urinária por eletroforese ou imunofixação<br>- Aparecimento de plasmócitos na MO igual ou maior que 5% OU qualquer outro sinal de<br>progressão (novo plasmocitoma, lesão óssea lítica ou hipercalcemia).|
|Recaída clínica|- Desenvolvimento de novos plasmocitomas ou lesões ósseas.<br>- Aumento do tamanho dos plasmocitomas existentes ou das lesões ósseas (igual ou maior|  
|que 50% ou 1 cm).|
|---|
|- Hipercalcemia (igual ou maior que 11 mg/dL).|
|- Diminuição da hemoglobina igual ou maior que 2 g/dL, não relacionada à terapia ou outras|
|condições não relacionadas ao mieloma.|
|- Aumento de 2 mg/dL na creatinina sérica inicial que seja atribuído ao mieloma.|
|- Hiperviscosidade relacionada à paraproteína sérica.|  
Nota: Todas as categorias de resposta ou recaída devem ter duas avaliações consecutivas feitas a qualquer momento antes da sua classificação final (resposta, progressão de doença, recaída) ou início de nova terapia. Avaliações de medula óssea não precisam ser confirmadas. Fonte: Kumar, 2016.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6.4. Critérios de interrupção** -->
Durante a quimioterapia, a cada ciclo, o paciente deve ser avaliado com relação aos sintomas e sinais clínicos de toxicidade e deve ser submetido a exames laboratoriais, conforme protocolo de tratamento selecionado. Os critérios mínimos de monitoramento e interrupção da terapia devem seguir os protocolos institucionais estabelecidos.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **7.1. Avaliação da resposta terapêutica e seguimento** -->
O acompanhamento da resposta ao tratamento deve ser feito pela dosagem da proteína-M, com frequência mensal no primeiro ano e bimensal a partir do segundo ano. Orienta-se a realização da eletroforese de proteínas séricas e urinárias, dosagem de cadeias leves (kappa e lambda) livres, ureia, creatinina e dosagem sérica de imunoglobulinas (IgA, IgM, IgG e IgE)<sup>12,21</sup> . A avaliação da medula óssea é obrigatória apenas para identificar se houve resposta completa ao tratamento. A investigação de alterações moleculares, por meio do FISH ou citogenética convencional, bem como a RNM ou TC de corpo inteiro não são necessárias para avaliação da resposta terapêutica, podendo ser realizadas na presença de queixas clínicas<sup>12,21</sup> . Além da avaliação odontológica e clínica, contemplando fragilidade clínica, controle adequado de doenças crônicas e comorbidades, o paciente deve ter acompanhamento psicológico, familiar e social, disponibilizados no âmbito da Atenção Primária. Após o diagnóstico e durante o tratamento, o cuidado do paciente com MM na Atenção Primária deve continuar, de forma paralela, coordenada e síncrona ao acompanhamento especializado. Neste sentido, cabe aos profissionais envolvidos, em todos os níveis da atenção, salientar a importância da continuidade do acompanhamento na Atenção Primária. Além do tratamento de sintomas, doenças crônicas e comorbidades, a equipe de saúde da Atenção Primária tem papel fundamental na detecção precoce de complicações da doença e do tratamento, principalmente infecções e eventos adversos do tratamento<sup>71</sup> . A utilização do sistema de referência e contrarreferência e os contatos formais entre as equipes responsáveis pela Atenção Primária e especializada devem ser encorajados<sup>13</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **7.2. Avaliação odontológica** -->
A administração de bisfosfonatos ao paciente com MM pode causar eventos adversos secundários, em especial a osteonecrose da mandíbula<sup>57</sup> . Antes de iniciar a terapia com bisfosfonatos, orienta-se que os pacientes sejam encaminhados para avaliação odontológica, tanto para detecção de possível doença periodontal e infecções ativas, como para receberem orientação sobre higiene bucal.  
Sugere-se avaliação odontológica anual, se houver sinais e sintomas de acometimento dental e antes do início do tratamento com bisfosfonato a fim de reduzir a incidência de osteonecrose de mandíbula<sup>58,72</sup> . Como a extração dentária é um fator de risco para osteonecrose da mandíbula, não se recomenda a sua realização ou a de outros procedimentos invasivos (como implante dentário ou procedimento cirúrigco na mandíbula) durante o tratamento com bisfosfonatos. Se estes procedimentos forem necessários, recomenda-se suspender o uso de bisfosfonatos 90 dias antes da sua realização.  O tratamento com  
bisfosfonato só deverá ser reiniciado após o procedimento dentário<sup>58,73</sup> . Se o paciente desenvolver osteonecrose da mandíbula, o uso de bisfosfonatos deve ser interrompido e, após a recuperação da osteonecrose, pode-se retornar ao uso do medicamento<sup>21</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes destas Diretrizes, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Casos de mieloma múltiplo devem ser atendidos em hospitais habilitados em oncologia e com porte tecnológico suficiente para diagnosticar, estadiar, tratar e acompanhar os pacientes. Além da familiaridade que tais hospitais guardam com o estadiamento, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e a garantia do atendimento aos pacientes e muito facilita as ações de controle e avaliação. Entre tais ações incluem-se a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES), a autorização prévia dos procedimentos, o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos) e a verificação dos percentuais da frequência dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda e segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e a observância da conduta ou do protocolo adotados no hospital, a regulação do acesso assistencial, a qualidade da autorização, a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses), a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod), a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais e o grau de satisfação dos doentes.  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a poliquimioterapia do linfoma folifcular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama, que são adquiridos pelo Ministério da Saúde e fornecidos aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde. Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais as terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados pelo SUS e habilitados em oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento de medicamento antineoplásico é do hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos (Grupo 03, Subgrupo 04), cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, devendo todos os potenciais receptores estar inscritos no Sistema Nacional de Transplantes (SNT).  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores submetidos a TCTH originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **9. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
É obrigatória a informação ao paciente ou ao seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso quando preconizado nestas Diretrizes do medicamento talidomida, consoante normas sanitárias vigentes<sup>74</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **10. REFERÊNCIAS BIBLIOGRÁFICAS** -->
1.  Sung H, Ferlay J, Siegel RL, Laversanne M, Soerjomataram I, Jemal A, et al. Global Cancer Statistics 2020: GLOBOCAN Estimates of Incidence and Mortality Worldwide for 36 Cancers in 185 Countries. CA Cancer J Clin [Internet]. 2021 May 4;71(3):209–49. Available from: https://onlinelibrary.wiley.com/doi/10.3322/caac.21660  
2.  Brasil. Ministério da Saúde. DATASUS. Painel-Oncologia - BRASIL [Internet]. 2021 [cited 2021 Oct 15]. Available from: http://tabnet.datasus.gov.br/cgi/dhdat.exe?PAINEL_ONCO/PAINEL_ONCOLOGIABR.def  
3.  Kazandjian D. Multiple myeloma epidemiology and survival: A unique malignancy. Semin Oncol [Internet]. 2016 Dec;43(6):676–81. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0093775416300951  
4.  Padala SA, Barsouk A, Barsouk A, Rawla P, Vakiti A, Kolhe R, et al. Epidemiology, Staging, and Management of Multiple Myeloma. Med Sci [Internet]. 2021 Jan 20;9(1):3. Available from: https://www.mdpi.com/2076-3271/9/1/3  
5.  Melo N. Observatório de Oncologia. Epidemiologia do Mieloma Múltiplo e distúrbios relacionados no Brasil [Internet]. [cited 2022 Mar 14]. Available from: https://observatoriodeoncologia.com.br/epidemiologia-do-mielomamultiplo-e-disturbios-relacionados-no-brasil/  
6.  Kyle RA, Rajkumar S V. Criteria for diagnosis, staging, risk stratification and response assessment of multiple myeloma. Leukemia [Internet]. 2009 Jan 30;23(1):3–9. Available from: http://www.nature.com/articles/leu2008291  
7.  Hillengass J, Usmani S, Rajkumar SV, Durie BGM, Mateos M-V, Lonial S, et al. International myeloma working group consensus recommendations on imaging in monoclonal plasma cell disorders. Lancet Oncol [Internet]. 2019 Jun;20(6):e302–12. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1470204519303092 8.  Kyle RA, Gertz MA, Witzig TE, Lust JA, Lacy MQ, Dispenzieri A, et al. Review of 1027 Patients With Newly Diagnosed Multiple Myeloma. Mayo Clin Proc [Internet]. 2003 Jan;78(1):21–33. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0025619611618272  
9.  Molassiotis A, Wilson B, Blair S, Howe T, Cavet J. Unmet supportive care needs, psychological well-being and quality of life in patients living with multiple myeloma and their partners. Psychooncology [Internet]. 2011 Jan;20(1):88–97. Available from: https://onlinelibrary.wiley.com/doi/10.1002/pon.1710  
10. Mols F, Oerlemans S, Vos AH, Koster A, Verelst S, Sonneveld P, et al. Health-related quality of life and diseasespecific complaints among multiple myeloma patients up to 10 yr after diagnosis: results from a population-based study using the PROFILES registry. Eur J Haematol [Internet]. 2012 Oct;89(4):311–9. Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.1600-0609.2012.01831.x  
11. Ramsenthaler C, Osborne TR, Gao W, Siegert RJ, Edmonds PM, Schey SA, et al. The impact of disease-related symptoms and palliative care concerns on health-related quality of life in multiple myeloma: a multi-centre study. BMC Cancer [Internet]. 2016 Dec 7;16(1):427. Available from: http://bmccancer.biomedcentral.com/articles/10.1186/s12885-0162410-2  
12. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria n<sup>o</sup> 708 de 6 de agosto de 2015. Aprova as Diretrizes Diagnósticas e Terapêuticas do Mieloma Múltiplo. [Internet]. 2015. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/sas/2011/prt0708_25_10_2011.html  
13. Brasil. Ministério da Saúde.Gabinete do Ministro. Portaria de Consolidação n<sup>o</sup> 02, de 3 de outubro de 2017. Anexo IX - Política Nacional para Prevenção e Controle do Câncer (PNPCC) [Internet]. 2017. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0002_03_10_2017.html#ANEXOIX  
14. Moreau P, San Miguel J, Sonneveld P, Mateos MV, Zamagni E, Avet-Loiseau H, et al. Multiple myeloma: ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up. Ann Oncol [Internet]. 2017 Jul;28:iv52–61. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0923753419421455  
15. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria SAS/MS n<sup>o</sup> 140, de 27 de fevereiro de 2014.  
[Internet]. 2014. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/sas/2014/prt0140_27_02_2014.html  
16. Prefeitura de São Paulo. Secretaria Municipal de Saúde. Protocolo Clínico de Regulação de Acesso para Tratamento de Alta Complexidade em Oncologia. Volume II. [Internet]. 2019. Available from: https://docs.bvsalud.org/biblioref/2019/02/970214/protocolo-v-2-atendimento-paciente-oncologico.pdf  
17. Ministério da Saúde. Diretrizes Metodológicas - Elaboração de diretrizes clínicas. [Internet]. 2<sup>a</sup> ed. Brasília; 2020. 144 p. Available from: http://conitec.gov.br/images/Relatorios/2021/Diretrizes-Metodologicas-Elaboracao-de-DiretrizesClinicas-2020.pdf  
18. GRADE Guidance Group. Grading of Recommendations Assessment, Development, and Evaluation. [Internet]. [cited 2022 Mar 15]. Available from: https://www.gradeworkinggroup.org/  
19. Snowden JA, Greenfield DM, Bird JM, Boland E, Bowcock S, Fisher A, et al. Guidelines for screening and management of late and long-term consequences of myeloma and its treatment. Br J Haematol [Internet]. 2017 Mar;176(6):888–907. Available from: https://onlinelibrary.wiley.com/doi/10.1111/bjh.14514  
20. Murillo A, Cronin AM, Laubach JP, Hshieh TT, Tanasijevic AM, Richardson PG, et al. Performance of the International Myeloma Working Group myeloma frailty score among patients 75 and older. J Geriatr Oncol [Internet]. 2019 May;10(3):486–9. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1879406818303436  
21. Dimopoulos MA, Moreau P, Terpos E, Mateos MV, Zweegman S, Cook G, et al. Multiple myeloma: EHA-ESMO Clinical Practice Guidelines for diagnosis, treatment and follow-up†. Ann Oncol [Internet]. 2021 Mar;32(3):309–22. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0923753420431692  
22. Fung S, Selva D, Leibovitch I, Hsuan J, Crompton J. Ophthalmic Manifestations of Multiple Myeloma. Ophthalmologica [Internet]. 2005;219(1):43–8. Available from: https://www.karger.com/Article/FullText/81782  
23. Messiou C, Kaiser M. Whole-Body Imaging in Multiple Myeloma. Magn Reson Imaging Clin N Am [Internet]. 2018 Nov;26(4):509–25. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1064968918300461  
24. Rajkumar SV. Updated Diagnostic Criteria and Staging System for Multiple Myeloma. Am Soc Clin Oncol Educ B [Internet]. 2016 May;(36):e418–23. Available from: https://ascopubs.org/doi/10.1200/EDBK_159009  
25. Palumbo A, Avet-Loiseau H, Oliva S, Lokhorst HM, Goldschmidt H, Rosinol L, et al. Revised International Staging System for Multiple Myeloma: A Report From International Myeloma Working Group. J Clin Oncol [Internet]. 2015 Sep 10;33(26):2863–9. Available from: https://ascopubs.org/doi/10.1200/JCO.2015.61.2267  
26. Avet-Loiseau H, Hulin C, Campion L, Rodon P, Marit G, Attal M, et al. Chromosomal Abnormalities Are Major Prognostic Factors in Elderly Patients With Multiple Myeloma: The Intergroupe Francophone du Myélome Experience. J Clin Oncol [Internet]. 2013 Aug 1;31(22):2806–9. Available from: http://ascopubs.org/doi/10.1200/JCO.2012.46.2598  
27. Sonneveld P, Avet-Loiseau H, Lonial S, Usmani S, Siegel D, Anderson KC, et al. Treatment of multiple myeloma with high-risk cytogenetics: a consensus of the International Myeloma Working Group. Blood [Internet]. 2016 Jun 16;127(24):2955–62. Available from: https://ashpublications.org/blood/article/127/24/2955/35445/Treatment-of-multiplemyeloma-with-highrisk  
28. Abdallah N, Rajkumar SV, Greipp P, Kapoor P, Gertz MA, Dispenzieri A, et al. Cytogenetic abnormalities in multiple myeloma: association with disease characteristics and treatment response. Blood Cancer J [Internet]. 2020 Aug 11;10(8):82. Available from: https://www.nature.com/articles/s41408-020-00348-5  
29. Michels TC, Petersen KE. Multiple Myeloma: Diagnosis and Treatment. Am Fam Physician [Internet]. 2017 Mar 15;95(6):373–83. Available from: http://www.ncbi.nlm.nih.gov/pubmed/28318212  
30. Brasil. Ministério da Saúde. Portaria n<sup>o</sup> 43 de 25 de setembro de 2020. Torna pública a decisão de incorporar, no âmbito do SUS, o bortezomibe para o tratamento de pacientes adultos com mieloma múltiplo, não previamente tratados, elegíveis ao transplante autólogo de células-tronco hema hematopoiéticas [Internet]. 2020. Available from:  
https://www.in.gov.br/en/web/dou/-/portaria-sctie/ms-n-43-de-25-de-setembro-de-2020-279711981  
31. Medical Scientific Advisory Group (MSAG). Clinical practice guideline - multiple myeloma. [Internet]. 2019. Available from: https://myeloma.org.au/wp-content/uploads/2019/10/myeloma_clinical_practice_guideline_oct19.pdf  
32. Mikhael J, Ismaila N, Cheung MC, Costello C, Dhodapkar M V., Kumar S, et al. Treatment of Multiple Myeloma: ASCO and CCO Joint Clinical Practice Guideline. J Clin Oncol [Internet]. 2019 May 10;37(14):1228–63. Available from: https://ascopubs.org/doi/10.1200/JCO.18.02096  
33. Palumbo A, Bringhen S, Bruno B, Falcone AP, Liberati AM, Grasso M, et al. Melphalan 200 mg/m2 versus melphalan 100 mg/m2 in newly diagnosed myeloma patients: a prospective, multicenter phase 3 study. Blood [Internet]. 2010 Mar 11;115(10):1873–9. Available from: https://ashpublications.org/blood/article/115/10/1873/26830/Melphalan-200mgm2-versus-melphalan-100-mgm2-in  
34. Kardduss-Urueta A, Gale RP, Gutierrez-Aguirre CH, Herrera-Rojas MA, Murrieta-Álvarez I, Perez-Fontalvo R, et al. Freezing the graft is not necessary for autotransplants for plasma cell myeloma and lymphomas. Bone Marrow Transplant [Internet]. 2018 Apr 12;53(4):457–60. Available from: http://www.nature.com/articles/s41409-017-0047-7  
35. Sarmiento M, Ramírez P, Parody R, Salas M, Beffermann N, Jara V, et al. Advantages of non-cryopreserved autologous hematopoietic stem cell transplantation against a cryopreserved strategy. Bone Marrow Transplant [Internet]. 2018 Aug 13;53(8):960–6. Available from: http://www.nature.com/articles/s41409-018-0117-5  
36. Rajkumar VS. Multiple myeloma: Use of autologous hematopoietic cell transplantation. [Internet]. 2021 [cited 2021 Feb 6]. Available from: https://www.uptodate.com/contents/multiple-myeloma-use-of-autologous-hematopoietic-celltransplantation?search=mieloma múltiplo  
manutenção&source=search_result&selectedTitle=2~150&usage_type=default&display_rank=2#H13.  
37. Brasil. Ministério da Saúde. Portaria SCTIE/MS n<sup>o</sup> 21, de 11 de março de 2022. Torna pública a decisão de não incorporar, no âmbito do SUS, a lenalidomida para terapia de manutenção em pacientes adultos com mieloma múltiplo submetidos ao transplante de células-tronco hematopoiéticas [Internet]. 2022. Available from: http://conitec.gov.br/images/Relatorios/Portaria/2022/20220314_Portaria_21.pdf  
38. Brasil. Ministério da Saúde. Portaria n<sup>o</sup> 45 de 25 de setembro de 2020. Torna pública a decisão de incorporar, no âmbito do Sistema Único de Saúde - SUS, o bortezomibe para o tratamento de pacientes adultos com mieloma múltiplo, não previamente tratados, inelegíveis ao transplante autólogo [Internet]. 2020. Available from: https://www.in.gov.br/en/web/dou/-/portaria-sctie/ms-n-45-de-25-de-setembro-de-2020-279712043 39. FUNED. Talidomida: comprimido [Internet]. Belo Horizonte; 2021. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?numeroRegistro=112090031 40. Brasil. Ministério da Saúde. Portaria SCTIE/MS n<sup>o</sup> 16, de 11 de março de 2022 Torna pública a decisão de não incorporar, no âmbito do SUS, a lenalidomida para pacientes adultos com mieloma múltiplo inelegíveis ao transplante de células-tronco hematopoiéticas. 2022; Available from:  
http://conitec.gov.br/images/Relatorios/Portaria/2022/20220314_Portaria_16.pdf  
41. Jeryczynski G, Bolomsky A, Agis H, Krauth M-T. Stratification for RRMM and Risk-Adapted Therapy: Sequencing of Therapies in RRMM. Cancers (Basel) [Internet]. 2021 Nov 23;13(23):5886. Available from:  
https://www.mdpi.com/2072-6694/13/23/5886  
42. Bazarbachi AH, Al Hamed R, Malard F, Harousseau J-L, Mohty M. Relapsed refractory multiple myeloma: a comprehensive overview. Leukemia [Internet]. 2019 Oct 27;33(10):2343–57. Available from: http://www.nature.com/articles/s41375-019-0561-2  
43. Durie BGM, Harousseau J-L, Miguel JS, Bladé J, Barlogie B, Anderson K, et al. International uniform response criteria for multiple myeloma. Leukemia [Internet]. 2006 Sep 1;20(9):1467–73. Available from:  
http://www.nature.com/articles/2404284  
44. Hungria VTM. Tratamento do Mieloma Múltiplo recidivado. Rev Bras Hematol Hemoter [Internet]. 2007 Mar;29(1). Available from: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S151684842007000100011&lng=pt&nrm=iso&tlng=pt  
45. Kumar S, Paiva B, Anderson KC, Durie B, Landgren O, Moreau P, et al. International Myeloma Working Group consensus criteria for response and minimal residual disease assessment in multiple myeloma. Lancet Oncol [Internet]. 2016 Aug;17(8):e328–46. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1470204516302066  
46. Durer C, Durer S, Lee S, Chakraborty R, Malik MN, Rafae A, et al. Treatment of relapsed multiple myeloma: Evidence-based recommendations. Blood Rev [Internet]. 2020 Jan;39:100616. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0268960X19300402  
47. Rajkumar SV. Multiple myeloma: 2020 update on diagnosis, risk‐stratification and management. Am J Hematol [Internet]. 2020 May 13;95(5):548–67. Available from: https://onlinelibrary.wiley.com/doi/10.1002/ajh.25791  
48. Brasil. Ministério da Saúde. Portaria n<sup>o</sup> 44 de 25 de setembro de 2020. Torna pública a decisão de incorporar, no âmbito do Sistema Único de Saúde - SUS, o bortezomibe para o tratamento de pacientes adultos com mieloma múltiplo previamente tratados, conforme estabelecido pelo Ministério da Saúde [Internet]. 2020. Available from: https://www.in.gov.br/en/web/dou/-/portaria-sctie/ms-n-44-de-25-de-setembro-de-2020-279712041  
49. Brasil. Ministério da Saúde. Portaria SCTIE/MS n<sup>o</sup> 18, de 11 de março de 2022 Torna pública a decisão de não incorporar, no âmbito do SUS, o daratumumabe em monoterapia ou associado à terapia antineoplásica para o controle do mieloma múltiplo recidivado ou refratário. 2022; Available from: http://conitec.gov.br/images/Relatorios/Portaria/2022/20220314_Portaria_18.pdf  
50. Rosiñol L, Oriol A, Teruel AI, Hernández D, López-Jiménez J, de la Rubia J, et al. Superiority of bortezomib, thalidomide, and dexamethasone (VTD) as induction pretransplantation therapy in multiple myeloma: a randomized phase 3 PETHEMA/GEM study. Blood [Internet]. 2012 Aug 23;120(8):1589–96. Available from: https://ashpublications.org/blood/article/120/8/1589/30806/Superiority-of-bortezomib-thalidomide-and  
51. Janssen-Cilag. VELCADE: pó liofilizado. São José dos Campos; 2017.  
52. Reeder CB, Reece DE, Kukreti V, Mikhael JR, Chen C, Trudel S, et al. Long-term survival with cyclophosphamide, bortezomib and dexamethasone induction therapy in patients with newly diagnosed multiple myeloma. Br J Haematol [Internet]. 2014 Nov;167(4):563–5. Available from: https://onlinelibrary.wiley.com/doi/10.1111/bjh.13004  
53. Park S, Lee SJ, Jung CW, Jang JH, Kim SJ, Kim WS, et al. DCEP for relapsed or refractory multiple myeloma after therapy with novel agents. Ann Hematol [Internet]. 2014 Jan 16;93(1):99–105. Available from: http://link.springer.com/10.1007/s00277-013-1952-5  
54. San Miguel JF, Schlag R, Khuageva NK, Dimopoulos MA, Shpilberg O, Kropff M, et al. Bortezomib plus Melphalan and Prednisone for Initial Treatment of Multiple Myeloma. N Engl J Med [Internet]. 2008 Aug 28;359(9):906– 17. Available from: http://www.nejm.org/doi/abs/10.1056/NEJMoa0801479  
55. Anderson H, Scarffe J, Ranson M, Young R, Wieringa G, Morgenstern G, et al. VAD chemotherapy as remission induction for multiple myeloma. Br J Cancer [Internet]. 1995 Feb;71(2):326–30. Available from: http://www.nature.com/articles/bjc199565  
56. Orlowski RZ, Nagler A, Sonneveld P, Bladé J, Hajek R, Spencer A, et al. Randomized Phase III Study of Pegylated Liposomal Doxorubicin Plus Bortezomib Compared With Bortezomib Alone in Relapsed or Refractory Multiple Myeloma: Combination Therapy Improves Time to Progression. J Clin Oncol [Internet]. 2007 Sep 1;25(25):3892–901. Available from: http://ascopubs.org/doi/10.1200/JCO.2006.10.5460  
57. Panaroni C, Yee AJ, Raje NS. Myeloma and Bone Disease. Curr Osteoporos Rep [Internet]. 2017 Oct  
31;15(5):483–98. Available from: http://link.springer.com/10.1007/s11914-017-0397-5  
58. Terpos E, Zamagni E, Lentzsch S, Drake MT, García-Sanz R, Abildgaard N, et al. Treatment of multiple myelomarelated bone disease: recommendations from the Bone Working Group of the International Myeloma Working Group. Lancet Oncol [Internet]. 2021 Mar;22(3):e119–30. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1470204520305593  
59. Eurofarma. Ácido Zoledrônico: solução injetável. [Internet]. São Paulo; 2021. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=ácido zoledrônico  
60. Eurofarma. Pamidronato dissódico: pó liofilizado para solução injetável. [Internet]. 2021. Available from: https://consultas.anvisa.gov.br/#/bulario/q/?nomeProduto=pamidron  
61. Terpos E, Kleber M, Engelhardt M, Zweegman S, Gay F, Kastritis E, et al. European Myeloma Network Guidelines for the Management of Multiple Myeloma-related Complications. Haematologica [Internet]. 2015 Oct 1;100(10):1254–66. Available from: http://www.haematologica.org/cgi/doi/10.3324/haematol.2014.117176  
62. Courant M, Orazio S, Monnereau A, Preterre J, Combe C, Rigothier C. Incidence, prognostic impact and clinical outcomes of renal impairment in patients with multiple myeloma: a population-based registry. Nephrol Dial Transplant [Internet]. 2021 Feb 20;36(3):482–90. Available from: https://academic.oup.com/ndt/article/36/3/482/5643867  
63. Maiolino A, Magalhães RJP. Mieloma Múltiplo e insuficiência renal. Rev Bras Hematol Hemoter [Internet]. 2007 Mar;29(1). Available from: http://www.scielo.br/scielo.php?script=sci_arttext&pid=S151684842007000100016&lng=pt&nrm=iso&tlng=pt  
64. Heher EC, Rennke HG, Laubach JP, Richardson PG. Kidney Disease and Multiple Myeloma. Clin J Am Soc Nephrol [Internet]. 2013 Nov 7;8(11):2007–17. Available from: https://cjasn.asnjournals.org/lookup/doi/10.2215/CJN.12231212  
65. Dimopoulos MA, Kastritis E, Rosinol L, Bladé J, Ludwig H. Pathogenesis and treatment of renal failure in multiple myeloma. Leukemia [Internet]. 2008 Aug 5;22(8):1485–93. Available from: http://www.nature.com/articles/leu2008131  
66. Gupta D, Bachegowda L, Phadke G, Boren S, Johnson D, Misra M. Role of plasmapheresis in the management of myeloma kidney: A systematic review. Hemodial Int [Internet]. 2010 Oct;14(4):355–63. Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.1542-4758.2010.00481.x  
67. Premuzic V, Batinic J, Roncevic P, Basic-Jukic N, Nemet D, Jelakovic B. Role of Plasmapheresis in the Management of Acute Kidney Injury in Patients With Multiple Myeloma: Should We Abandon It? Ther Apher Dial [Internet]. 2018 Feb;22(1):79–86. Available from: https://onlinelibrary.wiley.com/doi/10.1111/1744-9987.12606  
68. Ludwig H, Boccadoro M, Moreau P, San-Miguel J, Cavo M, Pawlyn C, et al. Recommendations for vaccination in multiple myeloma: a consensus of the European Myeloma Network. Leukemia [Internet]. 2021 Jan 19;35(1):31–44. Available from: https://www.nature.com/articles/s41375-020-01016-0  
69. Ludwig H, Miguel JS, Dimopoulos MA, Palumbo A, Garcia Sanz R, Powles R, et al. International Myeloma Working Group recommendations for global myeloma care. Leukemia [Internet]. 2014 May 9;28(5):981–92. Available from: http://www.nature.com/articles/leu2013293  
70. Brasil. Ministério da Saúde. Secretaria de vigilância em Saúde. Departamento de Imunização e Doenças Transmissíveis. Manual dos Centros de Referência para Imunobiológicos Especiais. [Internet]. 2019. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/manual_centros_imunobiologicos_especiais_5ed.pdf  
71. Beltrao T., Ramalho MNA, Barros MBSC, Silva FM., Oliveira SHS. Acompanhamento de pessoas com câncer por enfermeiros da atenção primária. Rev Cubana Enferm [Internet]. 2019;35(4). Available from: http://scielo.sld.cu/scielo.php?script=sci_arttext&pid=S0864-03192019000400006  
72. Bacci C, Cerrato A, Dotto V, Zambello R, Barilà G, Liço A, et al. The Importance of Alliance between  
Hematologists and Dentists: A Retrospective Study on the Development of Bisphosphonates Osteonecrosis of the Jaws (Bronj) in Multiple Myeloma Patients. Dent J [Internet]. 2021 Jan 20;9(2):11. Available from: https://www.mdpi.com/23046767/9/2/11  
73. Terpos E, Morgan G, Dimopoulos MA, Drake MT, Lentzsch S, Raje N, et al. International Myeloma Working Group Recommendations for the Treatment of Multiple Myeloma–Related Bone Disease. J Clin Oncol [Internet]. 2013 Jun 20;31(18):2347–57. Available from: http://ascopubs.org/doi/10.1200/JCO.2012.47.7901  
74. Brasil. Ministério da Saúde. Agência Nacional de Vigilância Sanitária. Resolução nº 11, de 22 de março de 2011. Dispõe sobre o controle da substância Talidomida e do medicamento que a contenha. [Internet] 2011. Disponível em: https://bvsms.saude.gov.br/bvs/saudelegis/anvisa/2011/rdc0011_22_03_2011.html.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **1. Escopo e finalidade das Diretrizes** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) do Mieloma Múltiplo (MM) contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto das DDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados. O processo de atualização deste documento baseou-se na versão das DDT do Mieloma Múltiplo publicada por meio da Portaria SAS/MS nº 708, de 6 de agosto de 2015<sup>1</sup> .  
O público-alvo destas DDT é composto por profissionais da saúde envolvidos no atendimento de pacientes com MM. Os pacientes adultos com idade maior ou igual a 19 anos e diagnóstico de MM são a população-alvo destas recomendações.  
A atualização desse documento foi iniciada em 17 de março de 2021, com a realização da reunião de escopo, no qual as perguntas de pesquisa que direcionaram a atualização destas Diretrizes foram elaboradas. As reuniões de recomendação, com a presença dos especialistas, foram realizadas nos dias 7, 15 e 20 de dezembro de 2021.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor destas Diretrizes foi composto por um painel de especialistas sob coordenação do Departamento  
de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde do Ministério da Saúde (DGITS/SECTICS/MS). O painel de especialistas incluiu médicos da especialidade de oncologia.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse ( **Quadro A** ), que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
**Quadro A -** Questionário de conflitos de interesse Diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos ben|efícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|  
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma|(   ) Sim|
|---|---|
|tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim|
||(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetado<br>atividade na elaboração ou revisão da diretriz?|s pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar|(   ) Sim|
|sua objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **3. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização das DDT de MM foi apresentada na 98ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 19 de abril de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). As DDT foram aprovadas para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 108ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **4. Busca da evidência e recomendações** -->
O processo de desenvolvimento dessas DDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde, que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), que classifica a qualidade da informação ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>2</sup> .  
Foram elencadas e priorizadas sete dúvidas clínicas pelo painel de especialistas e, para cada dúvida, foi elaborada uma pergunta de pesquisa, conforme acrônimo PICO. Para cada uma das perguntas de pesquisa, foi realizada a busca estruturada nas bases de dados _Medical Literature Analysis and Retrieval System Online_ (MEDLINE) via Pubmed e via OVID, Excerpta medica database (EMBASE), Cochrane Library e Literatura latino-americana em ciências da saúde (LILACS) via Biblioteca Virtual de Saúde. Também foram realizadas buscas em repositórios de diretrizes clínicas para identificar possíveis atualizações em relação às boas práticas no cuidado aos pacientes com MM.  
A seleção dos artigos foi realizada por dois pesquisadores conforme critérios de elegibilidade pré-estabelecidos para cada pergunta. De forma geral, foram selecionadas revisões sistemáticas com meta-análise (RSMA), que posteriormente foram atualizadas pelo grupo elaborador. Na ausência de RS de qualidade, foram selecionados ensaios clínicos randomizados (ECR).  
As RSs foram avaliadas com a utilização da ferramenta AMSTAR 2.0 ( _A MeaSurement Tool to Assess Systematic Reviews_ )<sup>3</sup> e os ECRs foram avaliados por meio da ferramenta RoB 2 ( _A revised tool for assessing risk of bias in randomised trials)_<sup>4</sup> . A avaliação de estudos de acurácia diagnóstica foi realizada com uso da ferramenta QUADAS-2 ( _Quality Assessment of Diagnostic Accuracy Studies_ (QUADAS-2)<sup>5</sup> . A extração dos dados foi realizada por dois pesquisadores por meio de ficha de extração padronizada e desenvolvida pelo grupo elaborador. Os resultados foram apresentados por meio de estimativas de _risk difference_ (RD), risco relativo (RR), _Odds Ratio_ (OR) e _hazard ratio_ (HR), com seus respectivos intervalos de confiança (IC) de 95%. O modelo de efeitos aleatórios foi utilizado nas meta-análises.  
Após a avaliação dos resultados, foi utilizado o sistema GRADE<sup>2</sup> para avaliação da certeza da evidência. A interpretação dos níveis de evidência de acordo com o GRADE é apresentada no **Quadro B**<sup>6</sup> .  
**Quadro B -** Níveis de evidências de acordo com o sistema GRADE.  
|**Nível**|**Definição**|**Implicações**|
|---|---|---|
|**Alto**|Há forte confiança de que o verdadeiro efeito<br>esteja próximo daquele estimado|É improvável que trabalhos adicionais irão modificar a<br>confiança na estimativa do efeito.|
|||Trabalhos futuros poderão modificar a confiança na|
|**Moderado**|Há confiança moderada no efeito estimado.|estimativa de efeito, podendo, inclusive, modificar a<br>estimativa.|
|**Baixo**|A confiança no efeito é limitada.|Trabalhos futuros provavelmente terão um impacto<br>importante em nossa confiança na estimativa de efeito.|
||A confiança na estimativa de efeito é muito||
|**Muito baixo**|limitada.<br>Há um importante grau de incerteza nos achados.|Qualquer estimativa de efeito é incerta.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **5. Desenvolvimento da recomendação** -->
Para cada recomendação, foram discutidas a direção do curso da ação (realizar ou não realizar a ação proposta) e a força da recomendação, definida como forte ou condicional, de acordo com o sistema GRADE ( **Quadro C** )<sup>6</sup> .  
**Quadro C -** Implicações da força da recomendação para profissionais, pacientes e gestores em saúde.  
|**Público-alvo**|**Forte**|**Condicional**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada como<br>política de saúde na maioria das situações|É necessário debate substancial e envolvimento das<br>partes interessadas.|  
|**Pacientes**||A maioria dos indivíduos desejaria que a<br>intervenção fosse indicada e apenas um<br>pequeno<br>número<br>não<br>aceitaria<br>essa<br>recomendação|Grande parte dos indivíduos desejaria que a<br>intervenção fosse indicada; contudo considerável<br>número não aceitaria essa recomendação.|
|---|---|---|---|
||||O profissional deve reconhecer que diferentes|
|**Profissionais**|**da**|A maioria dos pacientes deve receber a|escolhas serão apropriadas para cada paciente para|
|**saúde**||intervenção recomendada.|definir uma decisão consistente com os seus valores e<br>preferências.|  
Fonte: Diretrizes metodológicas: Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. – Brasília: Ministério da Saúde, 2014.  
Para a elaboração das recomendações, foram considerados os riscos e os benefícios das condutas propostas, incluindo nível de evidências, custos, uso de recursos, aceitabilidade pelos profissionais e demais barreiras para implementação. De acordo com o sistema GRADE, a recomendação pode ser a favor ou contra a intervenção proposta, bem como pode ser forte (quando o painel de especialistas está bastante confiante que os benefícios superam os riscos) ou condicional/fraca (quando a recomendação ainda gera dúvidas quanto ao benefício e risco). Colocações adicionais sobre as recomendações, como potenciais exceções às condutas propostas ou outros esclarecimentos, foram documentadas ao longo do texto. Dessa forma, a direção e a força da recomendação, assim como sua redação, foram definidas durante a reunião e obtidas por meio de consenso.  
Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel, recomendações de outras diretrizes, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **6. Recomendações** -->
Para cada uma das questões clínicas foram apresentadas as perguntas de pesquisa, recomendações do painel dos especialistas, métodos, resultados das buscas, resumo das evidências, tabelas do perfil de evidências de acordo com a metodologia GRADE e tabela para tomada de decisão.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **QUESTÃO 1: Deve-se utilizar a citogenética por Hibridização** **_In Situ_ por Fluorescência (FISH) versus citogenética convencional para detectar as alterações t(4:14), del(17p13) e t(14:16) em pacientes com mieloma múltiplo?** -->
**<u>Recomendação 1:</u>** Sugerimos a utilização da hibridização _in situ_ por fluorescência (FISH) para identificação das alterações moleculares para avaliação do prognóstico dos pacientes com mieloma múltiplo recém-diagnosticado e nos pacientes com recidiva, condicionada a decisão de ampliação do uso da tecnologia (qualidade da evidência muito baixa, recomendação condicional).  
A estrutura PICO para esta pergunta foi:  
**População:** <mark>Pacientes adultos, com diagnóstico de MM</mark> .  
**Intervenção:** <mark>Citogenética por Hibridização</mark> _<mark>In Situ</mark>_ <mark>por Fluorescência (FISH) (molecular) para detecção de alterações citogenéticas de alto risco (t4:14, t14:16 e del17p3).</mark>  
**Comparador:** <mark>Citogenética convencional</mark> .  
**Desfechos:** <mark>Sensibilidade, Especificidade, Razão de verossimilhança, Verdadeiro negativo (VN), Verdadeiro positivo</mark>  
<mark>(VP), Falso negativo (FN), Falso positivo (FP).</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca:** -->
Para tomada de decisão, foram consideradas as evidências incluídas nas DDT de MM<sup>1</sup> e foi estruturada e realizada uma busca sistematizada da literatura por RS atualizadas, de adequada qualidade metodológica. As buscas foram realizadas nas bases de dados Embase<sup>®</sup> , Medline (via Pubmed), Cochrane Library e LILACS. Para a elaboração das estratégias de busca, foram utilizados termos provenientes dos tesauros Mesh (Medline), Emtree<sup>®</sup> (Embase<sup>®</sup> ) e DeCS (LILACS), além de termos livres provenientes de estudos indexados sobre o tema. As buscas foram realizadas em 25 de junho de 2021 e não houve restrição em relação ao período de indexação. As bases de dados utilizadas, as estratégias de busca detalhadas e o número de documentos recuperados estão presentes no **Quadro D** .  
**Quadro D -** Bases de dados, estratégias de busca e resultados recuperados.  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**Medline (via**<br>**PubMed)**|(((Multiple Myeloma[MeSH Terms]) OR (Multiple Myelomas OR Myelomas, Multiple OR<br>Myeloma, Multiple OR Myeloma, Plasma-Cell OR Myeloma, Plasma Cell OR Myelomas,<br>Plasma-Cell OR Plasma-Cell Myeloma OR Plasma-Cell Myelomas OR Myelomatosis OR<br>Myelomatoses OR Plasma Cell Myeloma OR Cell Myeloma, Plasma OR Cell Myelomas,<br>Plasma OR Myelomas, Plasma Cell OR Plasma Cell Myelomas OR Kahler Disease OR<br>Disease, Kahler OR Myeloma-Multiple OR Myeloma Multiple OR Myeloma-Multiples))<br>AND ((In Situ Hybridization, Fluorescence[MeSH Terms]) OR (Hybridization in Situ,<br>Fluorescent OR FISH Technique OR FISH Techniques OR Technique, FISH OR<br>Techniques, FISH OR Fluorescent in Situ Hybridization OR FISH Technic OR FISH<br>Technics OR Technic, FISH OR Technics, FISH OR Hybridization in Situ, Fluorescence<br>OR In Situ Hybridization, Fluorescent))) AND (((sensitiv*[Title/Abstract] OR sensitivity<br>and specificity[MeSH Terms] OR diagnose[Title/Abstract] OR diagnosed[Title/Abstract]<br>OR diagnoses[Title/Abstract] OR diagnosing[Title/Abstract] OR diagnosis[Title/Abstract]<br>OR<br>diagnostic[Title/Abstract]<br>OR<br>diagnosis[MeSH:noexp]<br>OR<br>(diagnostic<br>equipment[MeSH:noexp]<br>OR<br>diagnostic<br>errors[MeSH:noexp]<br>OR<br>diagnostic<br>imaging[MeSH:noexp]<br>OR<br>diagnostic<br>services[MeSH:noexp])<br>OR<br>diagnosis,<br>differential[MeSH:noexp] OR diagnosis[Subheading:noexp])))|544|
|**Embase**|#1 'multiple myeloma'/exp OR 'multiple myeloma' (94,560)<br>#2 'fluorescence in situ hybridization' (78,811)<br>#3 'systematic review' (381,788)<br>#4 'meta analysis' (321,879)<br>#5 #1 AND #2 (2,149)<br>#6 #3 OR #4 (531,851)<br>#7 #5 AND #6 (23)<br>#8 'diagnostic procedure' (106,348)<br>#9 'diagnostic method' (13,687)<br>#10 'diagnostic techniques' (12,181)<br>#11 'diagnostic techniques and procedures' (611)<br>#12 'diagnosis' (5,951,800)<br>#13 'diagnostic tool' (42,960)<br>#14 #8 OR #9 OR #10 OR #11 OR #12 OR #13 (5,997,208)<br>#15 #5 AND #14 (1,024)|1038|  
||#16 #7 OR #15 (1,038)||
|---|---|---|
|**Cochrane**|("Multiple Myeloma" OR "Myeloma, Plasma-Cell") AND ("In Situ Hybridization,|14|
|**Library**|Fluorescence") in All Text||
|**LILACS**|("Multiple Myeloma" OR "Mieloma Múltiple" OR "Mieloma múltiplo") AND ("In Situ|111|
||Hybridization, Fluorescence" OR "Hibridização in Situ Fluorescente")||
|**TOTAL**||**1.707**|  
<mark>Após a etapa da busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. As etapas de seleção por títulos e resumos, bem como, após leitura na íntegra, foram realizadas de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>  
<mark>Foram considerados como critérios de elegibilidade:</mark>  
- (a) <mark>População: A</mark> dultos, com diagnóstico de MM e idade igual ou superior a 19 anos. Não houve restrição quanto ao  
- estadiamento da doença ou momento de realização do teste (diagnóstico ou seguimento).  
- <mark>(b) Intervenção: Avaliação de amostras de medula óssea ou sangue periférico de pacientes com MM, por meio do teste</mark>  
<mark>FISH, e que utilizaram sondas para identificação de alterações cromossômicas t(4;14), del(17p13) e t(14;16).</mark>  
- (c) <mark>Comparador: C</mark> itogenética convencional.  
- (d) Desfechos: Avaliações de sensibilidade, especificidade e razão de verossimilhança, verdadeiro negativo (VN),  
- verdadeiro positivo (VP), falso negativo (FN) e falso positivo (FP).  
- (e) Tipos de estudos: RSs de estudos de acurácia, ECRs e não randomizados, bem como estudos observacionais.  
- (f) Idioma e data de publicação: Sem restrição

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **<u>Resultados da busca</u>** -->
A busca nas bases de dados resultou na identificação de 1.707 relatos, dos quais 433 foram excluídos por serem duplicatas. Foram triados 1.274 títulos e resumos, dos quais 35 foram selecionados para leitura do texto completo. Destes, 12 relatos, publicados como resumos em eventos científicos, foram excluídos por não apresentarem artigos completos, mesmo após o contato com os autores correspondentes. Para avaliação da elegibilidade, 23 relatos foram avaliados na íntegra. Ao final, 13 relatos de 11 estudos atenderam aos critérios de elegibilidade<sup>7–17</sup> ( **Figura A** ).  
**Figura A -** Fluxograma de seleção de artigos.  
<!-- Start of picture text -->
Identificagao dos estudos por meio das bases de dados e registros<br>2 Registros identificados: aegis removidos antes da<br>S Bases de dados (n=4)<br>§8 = Duplicatas removidas<br>g Registros (n=1.707) (33)<br>=<br>5<br>3<br>Registros analisados Registros excluidos<br>(n=1.274) (n=1.239)<br>Relatos _selecionados para Relatos nao recuperados<br>recuperagdo (n=35) (n=0)<br>Relatos avaliados quanto a Relatos excluidos:<br>elegibilidade Duplicata (n=1)<br>(n=23) Idioma (n=1)<br>Populacdo inelegivel (n=3)<br>Resultados duplicados (n=1)<br>Teste indice inelegivel (n=3)<br>Desfecho inelegivel (n=1)<br>8 Estudos incluidos na reviséo<br>3 (n=11)<br>3 Relatos dos estudos incluidos<br>£ (n=13)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **<u>Análise e apresentação dos resultados:</u>** -->
Não foi possível calcular a sensibilidade e a especificidade dos testes pela ausência de padrão-ouro com o qual os dois exames - citogenética convencional e FISH - pudessem ser comparados. Pela ausência de especificidade, também não foi possível calcular a razão de verossimilhança e os valores preditivos. Os testes diagnósticos foram comparados de forma descritiva e por meta-análise.  
Não foi possível mensurar os desfechos elencados na pergunta de pesquisa porque o comparador disponível no Brasil, citogenética convencional, possui sensibilidade e especificidade inferiores ao teste índice (FISH)<sup>18</sup> . Como desfechos substitutos, foram calculadas as medidas de efeito, com diferenças de risco (RD) com IC de 95%, que foram combinados por meio da metaanálise e foram apresentados por meio dos gráficos de floresta. A diferença de risco descreve a diferença de risco real dos eventos observados em cada um dos grupos.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
Os estudos incluídos analisaram amostras de 781 pacientes com MM. Destes, 653 foram avaliadas pelo método FISH e 719 pela citogenética convencional. A t(4;14) foi detectada em 11,3% (58/518) das amostras por FISH e 0,17% (1/607) por citogenética convencional. Os resultados da meta-análise mostraram que o FISH aumentou em 12% a detecção da t(4;14) quando comparado a citogenética convencional (RD: 0,12 [IC 95%: 0,06-0,19]; p < 0,0001; I<sup>2</sup> : 52%) ( **Figura B** ).  
**Figura B -** Gráfico de floresta para as diferenças de risco para detecção da translocação (4;14) pelo teste FISH quando comparado à citogenética  
convencional.  
<!-- Start of picture text -->
FISH Citogenética convencional Risk Difference Risk Difference<br>Study or Subgroup Events. Total Events Total_Weight_IV, Random, 95% Cl 1V, Random,<br>‘Aydin 2020 22 263 1 381 34.9% 0.08 (0.05, 0.12} 7 95% Cl<br>Chang 2004 9 25 0 15 7.5% 0.36 0.16, 0.56] =<br>Gole 2014 3 20 0 20 9.8% 0.15 (0.02, 0.32]<br>HamdaouitkbalKishimoto2020 2016 2020 1322 93356 000 45°368 24.5%21.2%22% 0.060.330.14 (0.06,0.03,f-0.07, 0.74]0.15)0.22] ~~<br>Total (95% Cl) 432 502 100.0% 0.12 [0.06, 0.19} °°<br>Total events 5 1<br>Heterogenelty: Tau<br>Test = 0.00; Chit= 10.49, df= 5 (P = 0.06); = 82% 5 =e $ os 7<br>for overall effect: Z= 3.94 (P « 0.0001) Citogenética convencional FISH<br><!-- End of picture text -->  
Legenda: FISH: Hibridização _In Situ_ por Fluorescência.  
Em relação à del(17p13), esta foi detectada em 12,2% (80/653) das amostras por FISH e 1,6% (10/607) por citogenética convencional. O FISH aumentou em 12% a detecção da del(17p13) em comparação à citogenética convencional (RD: 0,12 [IC 95%: 0,04-0,20]; p < 0,0001; I<sup>2</sup> : 77%) ( **Figura C** ).  
**Figura C -** Gráfico de floresta para as diferenças de risco para detecção da deleção 17p13 pelo teste FISH quando comparado à citogenética convencional.  
citogenética convencional.  
<!-- Start of picture text -->
Study or Subgroup EventsFISH Total CitogenéticaEvents convencionalTotal_Weight_1V,Risk Random,Difference 95% Cl IV,Risk Random,Difference 95% Cl<br>‘Ashok 2017 3. 40 1 40 146% 0.05 F-0.04, 0.14)<br>‘Ayain‘Chang2020 2004 152531 253 14 38115 17.7%71% — 0.110.5310.30,(0.07,0.15) 0.76) - —_—<br>Gole 2014 1 20 1 20 120% 0.005014, 0.14)<br>HeHamdaoul2013, 2020 1919365 i)3 45°65 14.4%13.5% 0.080.291018,(-0.08,0.18)0.40) _<br>‘kal 2020 2 35 0 35 14.9% 0.06 [-0.03, 0.15)<br>Kishimoto 2016 0 6 0 6 5.8% 0.00 (0.27, 0.27)<br>Total (95% Cl) 537 G07 100.0% 0.12 0.04, 0.20] ><br>Total events 82 10<br>Heterogeneity: Tau?=<br>‘Test for overall effect Z=0.01; Chit=3.03 (P= 0.03 0 .56,2) df= 7 ( < 0.0001); P= 77% Citogenética5  convencional.ots t FISH ae 7<br><!-- End of picture text -->  
Legenda: FISH: Hibridização _In Situ_ por Fluorescência.  
A t(14;16) foi detectada em 0,42% (2/478) das amostras por FISH e 0,17% (1/607) por citogenética convencional. Não houve diferença entre o FISH e a citogenética convencional para detecção da t(14;16) (RD: 0,00 [IC 95%: -0,01-0,02]; p = 0,41; I<sup>2</sup> : 0%) ( **Figura D** ).  
**Figura D -** Gráfico de floresta para as diferenças de risco para detecção da translocação (14;16) pelo teste FISH quando comparado à citogenética convencional.  
<!-- Start of picture text -->
FISH Citogenética convencional Risk Difference Risk Difference<br>Study or Subgroup__Events Total Events Total_Weight_IV, Random, 95% Cl IV, Random, 95% Cl<br>‘AydinChang2020 2004 02 25325 01 38115 923%1.3% — 0.00(-0.10,0.01 £0.01, 0.02]0.10)<br>Gole 2014 0 20 0 20 1.6% — 0.00(-0.03, 0.09]<br>tkbal 2020 a 38 0 35 46% 0.00 -0.05, 0.05)<br>Kishimoto 2016 0 6 0 6 0.2%  0.00F0.27,0.27]<br>Total (95% Cl) 339 457 100.0% 0.00 [-0.01, 0.02]<br>Total events 2 1<br>Heterogeneity. Tau?<br>Test for overall effect:= Z= 0.00; 0.82Chi*= (P = 0.41)0.06, df= 4 (P = 1.00); P= 0% Citogenética5 ateconvencional + FISH a 7<br><!-- End of picture text -->  
Legenda: FISH: Hibridização _In Situ_ por Fluorescência.  
As **Figuras E e F** apresentam, respectivamente, o risco de viés avaliado pela ferramenta QUADAS-2<sup>1</sup> e as questões de aplicabilidade para cada um dos 11 estudos incluídos<sup>7,8,17,9–16</sup> .A maioria dos estudos apresentou risco de viés incerto, exceto para o domínio Fluxo e Temporalidade, em que apenas dois estudos não apresentaram baixo risco de viés.  
**Figura E -** Percentuais de risco de viés e aplicabilidade dos estudos incluídos, de acordo com os domínios do QUADAS-2.  
<!-- Start of picture text -->
Patient Selection Os aay<br>cts EE) Ls<br>Reference Standard i) ey<br>Flow<br>and nin TD<br>0% 28% 50% 746 100% 0% 2% 50% 746 100%<br>Riskof Bias Applicability Concerns<br>Bion Bunciear How<br><!-- End of picture text -->  
**Figura F -** Resumo do risco de viés e aplicabilidade dos testes nos estudos incluídos, de acordo com o domínio do QUADAS-2.  
<!-- Start of picture text -->
Risk of Bias ‘Applicability Concerns<br>5 3<br>2 a@:f ¢ 28<br>Bzee!)sd BEes<br>ee bs FES<br>28 82 25 ¢<br>& tee &te<br>wee2012[@|@[@[@] [elele<br>wan] @[@[@[@| [@l@le|<br>‘vin 0201 @|@|@|@] |@/ele|<br>onze @[@ [ele] [wlele|<br>om s@[@|@[@| [alee<br>ransom] @[@|@[@| [@[ee<br>re2013/@/@/@/@| lelele|<br>sour]<br>rome 2s[@[@@ [ele][ele] [@lelo|[e[ele|<br>wne2o|@[@|@/@| [elele|<br>vwwor|@[@|@[@] [elele|<br>ition (®@ unclear @iow<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que o FISH deve ser priorizado para avaliação prognóstica do paciente com MM em relação à citogenética convencional, a qual apresenta limitações técnicas para identificação das alterações moleculares em amostras de medula óssea de pacientes com mieloma múltiplo.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Considerações gerais e para implementação:** -->
O teste FISH já está disponível no âmbito do Sistema Único de Saúde (SUS) para o diagnóstico de outras doenças. No Brasil, os laboratórios de referência para doenças raras possuem a infraestrutura necessária para a realização dos exames e seria necessária a ampliação do uso do exame por meio do SUS. Do ponto de vista da implementação, a capacitação de recursos humanos é um fator de extrema importância, uma vez que a maioria destes laboratórios, atualmente, não possui pessoal capacitado especificamente para analisar amostras de pacientes com mieloma múltiplo. O FISH deve ser realizado como parte dos exames diagnósticos necessários para o estadiamento citogenético e a tomada de decisão quanto à estratégia terapêutica a  
> 1 A denominação em português de cada domínio, apresentada em itálico, teve como fonte a tradução não validada das "Diretrizes Metodológicas: Elaboração de revisão sistemática e meta-análise de estudos de acurácia diagnóstica” do Ministério da Saúde, 2014.  
ser empregada diante da classificação de risco dos pacientes com mieloma múltiplo. Sugere-se que seja realizado o painel mínimo para detecção das alterações moleculares t(4;14), del17p13, t(14;16), com possibilidade de realizar o painel ampliado para identificação das alterações amplificação do 1q, t(11;14).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
O perfil de evidências, de acordo com o sistema GRADE, sobre o uso do FISH para detecção de alterações moleculares de alto risco em pacientes com mieloma múltiplo foi avaliado por dois pesquisadores e as discordâncias foram consensuadas com a participação de um terceiro pesquisador. Os resultados para os desfechos detecção da t(4;14), del 17p13, e t(14;16) estão apresentados na **Tabela A** .  
**Tabela A -** Avaliação da certeza de evidência do uso do FISH para detecção de alterações citogenéticas de alto risco, comparado a citogenética convencional.  
|**Avaliação da certe**|**za**||||||**Sumário de Res**|**ultados**||
|---|---|---|---|---|---|---|---|---|---|
|**Participantes**<br>**(estudos)**<br>**Detecção transloca**|**Risco**<br>**de**<br>**viés**<br>**ção (4;14)**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Viés**<br>**de**<br>**publicação**|**Certeza**<br>**geral**<br>**da**<br>**evidência**|**Taxas de even**<br>**(%)**<br>**Com**<br>**citogenética**<br>**convencional**|**tos do estudo**<br>**Com FISH**|**Efeito**<br>**relativo**<br>**(IC 95%)**|
|934<br>(6<br>estudos<br>observacionais)|muito<br>grave<sup>a</sup>|não grave<sup>b</sup>|não grave|não grave|nenhum|⨁◯◯◯<br>Muito<br>baixa|1/502 (0,2%)|51/432<br>(11,8%)|**Diferença de risco 0,12**<br>(0,06 para 0,19)|
|**Detecção deleção (**|**17p13)**|||||||||
|1144<br>(8<br>estudos<br>observacionais)|muito<br>grave<sup>a</sup>|grave<sup>c</sup>|não grave|não grave|nenhum|⨁◯◯◯<br>Muito<br>baixa|10/607 (1,6%)|82/537<br>(15,3%)|**Diferença de risco 0,12**<br>(0,04 para 0,20)|
|**Detecção da transl**|**ocação (14;16)**|||||||||
|796<br>(5<br>estudos<br>observacionais)|muito<br>grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁◯◯◯<br>Muito<br>baixa|1/457 (0,2%)|2/339 (0,6%)|**Diferença de risco 0,00**<br>(-0,01 para 0,02)|  
**Legenda: IC:** Intervalo de confiança

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
a. Risco de viés, avaliado pela ferramenta QUADAS-2, apresentou risco muito grave.  
b. A qualidade da evidência não foi rebaixada por inconsistência, pois todas as medidas favorecem o teste-índice.  
c. Os intervalos de confiança não se sobrepõem e o I<sup>2</sup> = 77%.  
Referências: Aras et al. 2012<sup>7</sup> , Ashok et al. 2017<sup>8</sup> , Aydin et al. 2020<sup>10</sup> , Chang et al. 2004<sup>11</sup> , Gole et al. 2014<sup>12</sup> , Hamdaoui et al. 2020<sup>13</sup> , He et al. 2013<sup>14</sup> , Ikbal et al. 2020<sup>15</sup> , Kishimoto et al. 2016<sup>16</sup> , Legües et al. 2019<sup>17</sup> , Yu et al. 2020<sup>19</sup> , Yuregir et al. 2009<sup>9</sup> .  
**Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):**  
O **Quadro E** apresenta o processo de tomada de decisão sobre o uso do FISH para a detecção de alterações citogenéticas  
de alto risco, baseando-se nas contribuições do painel de especialistas e na síntese de evidências realizada pelo grupo elaborador.  
**Quadro E** - Processo de tomada de decisão referente ao uso de FISH para detecção das alterações <mark>citogenéticas de alto risco (t4:14, t14:16 e del17p3)</mark> .  
|**Item da EtD**|**Julgamento dos painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios**|Grande|Todos os membros do painel julgaram que os efeitos desejáveis<br>são substanciais, e que o FISH é o método de escolha para<br>identificação de alterações citogenéticas em pacientes com<br>mieloma múltiplo.|
|**Riscos**|Trivial|Todos os membros do painel julgaram que o risco para<br>realização do exame é trivial.|
|**Balanço dos riscos e**<br>**benefícios**|Favorece a intervenção|Os membros julgam que o balanço é favorável à intervenção.|
|**Certeza da evidência**|Muito baixa|-|
|**Custos**|Economia moderada|-|
|**Viabilidade de**<br>**implementação**|Provavelmente sim|Tecnologia disponível no SUS para pacientes com doenças<br>raras, mas que pode ser ampliada para pacientes com mieloma<br>múltiplo.|  
O painel sugere a realização de um painel mínimo de investigação das alterações citogenéticas, que **Outras considerações** incluem a pesquisa da t(4;14), del17p13, t(14;16), com possibilidade de realizar o painel ampliado para identificação da amplificação do 1q, t(11;14).  
Fonte: Autoria própria.  
**QUESTÃO 2: Deve-se utilizar bortezomibe associado aos esquemas terapêuticos usuais em vez dos esquemas terapêuticos usuais na terapia de indução de pacientes com mieloma múltiplo elegíveis ao TCTH?**  
**<u>Recomendação 2:</u>** <mark>Recomendamos o uso de combinações baseadas em bortezomibe para pacientes com mieloma múltiplo, recém-diagnosticado, elegíveis ao transplante de células-tronco hematopoiéticas</mark> (qualidade da evidência alta, recomendação forte).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos, com MM, elegíveis ao TCTH **Intervenção:** Bortezomibe + esquema terapêutico usual  
**Comparador:** Esquema terapêutico usual  
**Desfechos:** Sobrevida global (SG), sobrevida livre de progressão (SLP), eventos adversos (EA)

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca** -->
A seleção das evidências foi realizada em duas etapas:  
**Etapa 1** : foram selecionadas revisões sistemáticas com meta-análise (RSMA) que avaliam o efeito do bortezomibe em  
pacientes com MM elegíveis ao TCTH.  
**Etapa 2** : foi realizada a seleção dos ECRs, publicados a partir da RS selecionada para atualização.  
Na **Etapa 1** , as buscas foram realizadas nas bases de dados Embase<sup>®</sup> , Medline (via Pubmed), Cochrane Library e LILACS. Para a elaboração das estratégias de busca, foram utilizados termos provenientes dos tesauros Mesh (Medline), Emtree<sup>®</sup> (Embase<sup>®</sup> ) e DeCS (LILACS), além de termos livres provenientes de estudos indexados sobre o tema. As buscas foram realizadas em 26 de maio de 2021 e não houve restrição em relação ao período de indexação ( **Quadro F** ).  
**Quadro F -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas sobre o uso bortezomibe em pacientes com mieloma múltiplo elegíveis ao TCTH.  
|**Bases de**<br>**dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline<br>(via Pubmed)|((("Multiple Myeloma"[Mesh Terms] OR "Multiple Myelomas" OR "Myelomas, Multiple"<br>OR "Myeloma, Multiple" OR "Myeloma, Plasma-Cell" OR "Myeloma, Plasma Cell" OR<br>"Myelomas, Plasma-Cell" OR "Plasma-Cell Myeloma" OR "Plasma-Cell Myelomas" OR<br>"Myelomatosis" OR "Myelomatoses" OR "Plasma Cell Myeloma" OR "Cell Myeloma,<br>Plasma" OR "Cell Myelomas, Plasma" OR "Myelomas, Plasma Cell" OR "Plasma Cell<br>Myelomas" OR "Kahler Disease" OR "Disease, Kahler" OR "Myeloma-Multiple" OR<br>"Myeloma Multiple" OR "Myeloma-Multiples")) AND ("Bortezomib"[Mesh] OR "LDP-<br>341" OR "LDP 341" OR "LDP341" OR "PS 341" OR "341, PS" OR "PS-341" OR "PS341"<br>OR "Velcade") AND ((((systematic review[tiab] OR systematic literature review[tiab] OR<br>systematic scoping review[tiab] OR systematic narrative review[tiab] OR systematic<br>qualitative review[tiab] OR systematic evidence review[tiab] OR systematic quantitative<br>review[tiab] OR systematic meta-review[tiab] OR systematic critical review[tiab] OR<br>systematic mixed studies review[tiab] OR systematic mapping review[tiab] OR systematic<br>search and review[tiab] OR systematic integrative review[tiab] OR meta-analysis[tiab] OR<br>Network Meta-Analysis[tiab] OR Network Meta-Analyses [tiab]) NOT comment[pt] NOT<br>(protocol[ti] OR protocols[ti])) NOT MEDLINE [subset]) OR systematic review[pt] OR<br>meta-analysis[pt])|58|
|EMBASE|#1. 'multiple myeloma' (94,023)<br>#2. 'bortezomib' (33,825)<br>#3. 'velcade' (3,593)<br>#4. 'systematic review' (374,884)<br>#5. 'meta analysis' (317,590)<br>#6. #2 OR #3 (33,862)<br>#7. #1 AND #6 (18,674)<br>#8. #4 OR #5 (523,876)<br>#9. #7 AND #8 (547)|547|
|The Cochrane<br>Library|("Multiple Myeloma" OR "Myeloma, Plasma-Cell") AND ("Bortezomib" OR "Velcade")<br>All text|6|
|LILACS<br>**TOTAL**|("Multiple Myeloma" OR "Mieloma Múltiple" OR "Mieloma Múltiplo") AND<br>("Bortezomib" OR "Bortezomibe" OR "Velcade")|37<br>**648**|  
<mark>Após a busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra foram realizadas de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Revisões sistemáticas selecionadas</u> -->
Para os pacientes elegíveis ao TCTH, após a busca na literatura por estudos que atendessem aos critérios de elegibilidade, cinco RSMAs de ECRs foram selecionadas<sup>20–24</sup> ( **Figura G** ). Os motivos de exclusão das demais RSs são apresentados no **Quadro G** .  
**Figura G -** Fluxograma de seleção das revisões sistemáticas incluídas  
<!-- Start of picture text -->
Registros identificados:<br>Pubmed (n=58) .<br>EMBASE (n=547) fees removidos antes da<br>Cochrane (n=6) , 7<br>LILACS (n=37) Duplicatas removidas (n=60)<br>TOTAL (n=648)<br>Relatos analisados |__| Relatos excluidos<br>(n= 588 ) (n =575 )<br>Relatos selecionados para =<br>tecuperagao (n= 14) Hn |<br>Relatos avaliados para<br>elegibilidade (n = 14 ) ———*| Relatos excluidos (n=9)<br>Intervengdo incorreta(n =1 )<br>Dados insuficientes (n =2)<br>Populagao incorreta (n = 5)<br>Comparador incorreto (n=1)<br>Estudos incluidos (n =5 )<br><!-- End of picture text -->  
**Quadro G -** Estudos excluídos e motivos de exclusão na busca e seleção de revisões sistemáticas.  
|**Autor ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Kumar et al.|_Thalidomide versus bortezomib based regimens as first-line therapy for_|População inelegível|
|2010|_patients with multiple myeloma: a systematic review_||
|Peru et al. 2015|_Dictamen Preliminar de Evaluación de Tecnología Sanitaria_|População inelegível|
|Wang et al. 2012|_(Bortezomib plus lenalidomide/thalidomide)- vs (bortezomib or_<br>_lenalidomide/thalidomide)-containing regimens as induction therapy in newly_<br>_diagnosed multiple myeloma: a meta-analysis of randomized controlled trials_|População inelegível|  
|Wang et al. 2016|_Efficacy and Safety of Novel Agent-Based Therapies for Multiple Myeloma: A_<br>_Meta-Analysis_|População inelegível|
|---|---|---|
|Zou et al. 2014|_Bortezomib and lenalidomide as front-line therapy for multiple myeloma_|População inelegível|
|Kouroukis et al.<br>2014|_Bortezomib in multiple myeloma: systematic review and clinical_<br>_considerations_|Intervenção ou<br>comparador<br>inelegíveis|
|Li et al. 2019|_Characteristics and risk factors of bortezomib induced peripheral_<br>_neuropathy: A systematic review of phase III trials_|Intervenção ou<br>comparador<br>inelegíveis|
|Kuhr et al. 2014|_First-Line Therapy for Patients With Multiple Myeloma: Direct and Indirect_<br>_Comparison of Treatment Regimens on the Existing Market_|Estudos primários<br>incluídos em revisão<br>sistemática mais<br>recente|
|Zou et al. 2013|_Continuous treatment with new agents for newly diagnosed multiple myeloma_|Estudos primários<br>incluídos em revisão<br>sistemática mais<br>recente|

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Avaliação da qualidade metodológica e caracterização das RS</u> -->
A avaliação da qualidade metodológica das RS foi realizada utilizando a ferramenta AMSTAR 2.0 ( _A MeaSurement Tool to Assess Systematic Reviews_ )<sup>3</sup> . A revisão de Scott _et al._ (2016)<sup>20</sup> não apresentou nenhuma falha crítica ( **Quadro H** ) e, por este motivo, foi selecionada para atualização.  
**Quadro H -** Caracterização e avaliação da qualidade metodológica das revisões sistemáticas com meta-análise de ensaios clínicos randomizados, selecionadas na Etapa  
|**Autor e**<br>**ano**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Número de**<br>**falhas críticas**<br>**(AMSTAR 2.0)**|
|---|---|---|---|---|---|
|Scott et al.|Pacientes com MM com|Esquemas|Esquemas|SLP, SG, TRG,|0|
|2016|diagnóstico recente<br>(elegíveis ou inelegíveis<br>ao TCTH) ou refratários|terapêuticos com<br>bortezomibe|terapêuticos sem<br>bortezomibe|TRC, TRP, EA,<br>morte relacionada<br>ao tratamento,<br>QV||
|Nooka et<br>al. 2013|Pacientes com MM com<br>diagnóstico recente<br>elegíveis ao TCTH|Esquemas<br>terapêuticos com<br>bortezomibe|Esquemas<br>terapêuticos sem<br>bortezomibe|TRC,TRPMB,<br>TRG, SG, SLP,<br>EA|5|
|Sekineet<br>al.2019|Pacientes com MM com<br>diagnóstico recente<br>elegíveis ao TCTH|Múltiplos esquemas<br>terapêuticos|Múltiplos<br>esquemas<br>terapêuticos|SG, SLP, SLE,<br>TRC, TRG, EA|3|
|Zenget al.|Pacientes com MM com|Esquemas|Esquemas|SG, TTP, SLP,|2|
|2013|diagnóstico recente não<br>tratados previamente|terapêuticos com<br>bortezomibe|terapêuticos sem<br>bortezomibe ou|TRC, TRG, EA||  
||||placebo||
|---|---|---|---|---|
|Zenget al.|Pacientes com MM com|Múltiplos esquemas|Múltiplos|TRG, SG, SLP<br>4|
|2017|diagnóstico recente|terapêuticos|esquemas||
||elegíveis ao TCTH||terapêuticos||  
Legenda: <mark>EA (evento adverso), MM (mieloma múltiplo), SG (sobrevida global), SLP (sobrevida livre de progressão), SLE (Sobrevida Livre de Eventos), TCTH (transplante de células tronco hematopoiéticas), TRC (taxa de resposta completa), TRG (taxa de resposta global), TRP (taxa de resposta parcial), TRPMB (taxa de resposta parcial muito boa), TTP (tempo até progressão).</mark>  
Na **Etapa 2** , foi realizada atualização da estratégia de busca do estudo de Scott _et al._ (2016)<sup>20</sup> nas bases de dados <mark>Medline (via Ovid), Embase e Cochrane no dia 26 de outubro de 2021</mark> ( **Quadro I** ). Com a utilização do filtro de data, as potenciais publicações posteriores a <mark>27 de janeiro de</mark> 2016 foram recuperadas.  
**Quadro I -** Estratégias de busca, de acordo com a base de dados, para identificação de ensaios clínicos randomizados do uso de bortezomibe para pacientes <mark>com mieloma múltiplo elegíveis ao TCTH.</mark>  
|**Bases de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|Medline (via<br>OVID)|#1 exp MULTIPLE MYELOMA/(43741)<br>#2 myelom$.kf,ot,tw.(61910)<br>#3 exp PLASMACYTOMA/(8715)<br>#4 plasm?cytom$.kf,ot,tw.(7501)<br>#5 plasmozytom$.kf,ot,tw.(389)<br>#6 plasm$ cell myelom$.kf,ot,tw.(747)<br>#7 myelomatosis.kf,ot,tw.(754)<br>#8 Leukemia, Plasma Cell/(1030)<br>#9 (plasma$ adj3 neoplas$).kf,ot,tw.(1801)<br>#10 kahler.kf,ot,tw.(250)<br>#11 #1 or #2 or #3 or #4 or #5 or #6 or #7 or #8 or #9 or #10(76892)<br>#12 (proteasom$ adj2 inhibitor$).kf,ot,tw.(9724)<br>#13 bortezomib$.kf,ot,nm,tw.(8659)<br>#14 proscript$.kf,ot,nm,tw.(255)<br>#15 (PS-341 or PS341).kf,ot,nm,tw.(410)<br>#16 (LDP-341 or LDP341 or MLN-341 or MLN341 or MG-341 or<br>MG341).kf,ot,nm,tw.(14)<br>#17 velcad$.kf,ot,tw.(502)<br>#18 #12 or #13 or #14 or #15 or #16 or #17(15733)<br>#19 #11 and #18(5686)<br>#20 randomized controlled trial.pt.(546325)<br>#21 controlled clinical trial.pt.(94441)<br>#22 randomi?.ab,ed.(29)<br>#23 placebo.ab.(202138)<br>#24 clinical trials as topic.sh.(197755)<br>#25 randomly.ab.(312341)<br>#26 trial.ti.(216744)|269|  
||#27 #20 or #21 or #22 or #23 or #24 or #25 or #26(1099368)<br>#28 humans.sh.(19783026)<br>#29 #27 and #28(987544)<br>#30 #19 and #29(718)<br>#31 limit 30 to yr="2016 -Current"(268)||
|---|---|---|
|EMBASE|#27. #11 AND #18 AND #25 AND [2016-2021]/py (1,227)<br>#26. #11 AND #18 AND #25 (2,436)<br>#25. #19 or #20 or #21 or #22 or #23 or #24  (42,391)<br>#24. 'ldp 341'/exp OR 'ldp341'/exp OR 'mln 341'/exp OR<br>'mln341'/exp OR 'mg 341'/exp OR 'mg341'/exp (34,278)<br>#23. 'ps 341'/exp OR 'ps341'/exp (34,278)<br>#22. velcad* ( 3,656)<br>#21. 'velcade'/exp (34,278)<br>#20. 'bortezomib'/exp  (34,278)<br>#19. 'proteasome'/exp AND inhibitor (10,425)<br># 18. #12 or #13 or #14 or #15 or #16 or #17 (154,240)<br>#17. plasma* NEAR/3 neoplas* (3,744)<br>#16. 'plasma'/exp AND 'cell'/exp AND 'leukemia'/exp (1,335)<br>#15. plasm* AND 'cell'/exp AND myelom*  (19,264)<br>#14. 'plasmacytoma'/exp (13,733)<br>#13. myelom* (143,741)<br>#12. multiple AND 'myeloma'/exp  (91,406)<br>#11 #1 or #2 or #3 or #4 or #5 or #6 or #7 or #8 or #9 or #10 (1,985,288)<br>#10. randomized AND controlled AND trial (972,796)<br>#9. volunteer* (285,666)<br>#8. allocat*  (189,829)<br>#7. assign* ( 435,751)<br>#6. single AND 'blind'/exp AND 'procedure'/exp   (2,544)<br>#5. double AND 'blind'/exp AND 'procedure'/exp  (807)<br>#4. 'placebo'/exp  (380,062)<br>#3. crossover AND 'procedure'/exp   (112,636)<br>#2. factorial AND design (21,836)<br>#1. 'randomization'/exp (92,330)|1229|
|The Cochrane<br>Library<br>(CENTRAL)|#1 [Multiple Myeloma] exp (1687)<br>#2 myelom*(6715)<br>#3 [Plasmacytoma] expl (87)<br>#4 plasm*cytom* (312)<br>#5 plasmozytom* (8)<br>#6 plam* cell myelom* (1)<br>#7 myelomatosis (40)<br>#8 [Leukemia, Plasma Cell] expl (3)<br>#9 plasma* near/3 neoplas* (711)|1097|  
||#10 kahler* (329)<br>#11 #1 or #2 or #3 or #4 or #5 or #6 or #7 or #8 or #9 or #10 (7223)<br>#12 proteasom* near/2 inhibitor* (610)<br>#13 bortezomib* (2183)<br>#14 proscript* (17)||
|---|---|---|
||#15 PS-341* or PS341*) (38)<br>#16 LDP-341* or LDP341* or MLN-341* or MLN341* or MG-341* or MG341* (3)<br>#17 velcad* (287)||
||#18 #12 or #13 or #14 or #15 or #16 or #17 (2496)<br>#19 #11 and #18 (1958)||
||#20 #19 with Publication Year from 2016 to 2021, with Cochrane Library publication<br>date Between Jan 2016 and Oct 2021, in Trials (1097)||
|**TOTAL**||**2.595**|  
<mark>Após a busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra foram realizadas de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos com MM elegíveis ao TCTH.  
- (b) Tipo de intervenção: Bortezomibe associado aos esquemas terapêuticos usuais, previstos em bula.  
- (c) Tipo de comparador: Esquemas terapêuticos usuais.  
- (d) Desfechos: SG, SLP, EA.  
- (e) Tipos de estudos: ECRs.  
- (f) Idioma e data de publicação: Sem restrição.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Resultados da busca</u> -->
Para os pacientes com MM elegíveis ao TCTH, não houve inclusão de novos ECRs além dos três ECRs já incluídos por Scott _et al._ (2016)<sup>20</sup> , que atenderam aos critérios de elegibilidade desta RS. Foram incluídos apenas relatos com dados de seguimento de um ECR já contemplado na RS original ( **Figura H** ). Os motivos de exclusão dos demais ECRs estão descritos no **Quadro J** .  
**Figura H -** Fluxograma de seleção de ensaios clínicos randomizados para atualização da revisão sistemática publicada por Scott et al. 2016.  
<!-- Start of picture text -->
Estudos incluidos na Regisiros identificados de Relatos excluidos antes da<br>‘vorsiio previa da revis’io Mediine (via Ovid) (n = 268) selegdo:<br>(n=3) Embase (n= 1229) Duplicatas removidas (n =<br>Cochrane (n = 1097) 855)<br>Relatos analisados Relatos excluidos<br>(n= 1740) (n= 1739)<br>Relatos selecionados para Relatos no recuperados<br>recuperagaa (n = 8) (n=0)<br>Relatos avaliados quanto a Relatos excluidos (n = 5)<br>eligibilidade (n= 9)<br>Novos relatos incluidos na<br>revisdo (n = 4)<br>Estudos incluides na revisio (n = 3)<br>Relaios incluicos na revisdo (n=10)<br><!-- End of picture text -->  
**Quadro J -** Motivos de exclusão dos demais ensaios clínicos (n = 5).  
|**Autor ano**|**Título**|**Motivo de**<br>**exclusão**|
|---|---|---|
|Goldschmidt et<br>al. 2018|_Bortezomib before and after high-dose therapy in myeloma: long-term results from_<br>_the phase III HOVON-65/GMMG-HD4 trial_|Intervenção<br>inelegível|
|Rosiñol et al.<br>2017|_Bortezomib and thalidomide maintenance after stem cell transplantation for multiple_<br>_myeloma: a PETHEMA/GEM trial_|Intervenção<br>inelegível|
|Roussel et al.|_Bortezomib and high-dose melphalan Vs. High-dose melphalan as conditioning_|Intervenção|
|2017|_regimen before autologous stem cell transplantation in de novo multiple myeloma_<br>_patients: A phase 3 study of the intergroupe francophone du myelome (IFM 2014-02)_|inelegível|
|Scheid et al.<br>2019|_Bortezomib-Based Induction and Maintenance Overcomes the Negative Prognostic_<br>_Impact of Renal Impairment and del17p in Transplant-Eligible Myeloma Patients:_<br>_Long Term Results from the Phase III HOVON-65/GMMG-HD4 Study after Median_<br>_137 Months Follow up_|Intervenção<br>inelegível|
|El-Ghammaz et<br>al. 2016|_Bortezomib-based induction improves progression-free survival of myeloma patients_<br>_harboring 17p deletion and/or t(4;14) and overcomes their adverse prognosis_|População<br>inelegível|  
<u>Análise e apresentação dos resultados</u>  
A avaliação do risco de viés apresentada por Scott et al. (2016)<sup>20</sup> foi realizada por meio da ferramenta _RoB 1.0_<sup>25</sup> . O julgamento do risco de viés foi avaliado pelos pesquisadores e adotado nesta revisão. O agrupamento dos dados foi realizado utilizando o modelo de efeitos aleatórios e as medidas sumárias foram apresentadas utilizando Peto _Odds Ratio_ (Peto OR), _Odds Ratio_ (OR) e HR, com os respectivos IC de 95%. Os resultados foram apresentados por meio de gráficos de floresta.  
Resumo das Evidências:  
Três ECRs incluídos na RS de _Scott et al._ (2016)<sup>20</sup> incluem esquemas terapêuticos contemplados em bula ( **Tabela B** ). Nos resultados, foram incluídos apenas a análise dos estudos GEM05MENOS65<sup>26</sup> , GIMEMA-MMY-3006<sup>27–34</sup> e IFM 2005-01<sup>35</sup> .  
**Tabela B -** Caracterização dos ensaios clínicos randomizados (n = 3).  
|**Estudo**|**Autor,**<br>**ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|GEM05MENOS65|Rosiñol<br>2012|ECR<br>fase III|Pacientes com MM<br>recém<br>diagnosticados<br>sintomáticos não<br>tratados.|Esquema = VTD: V 1,3 mg/m2 nos<br>dias 1, 4, 8, e 11 + T até dose diária de<br>200 mg, com dose escalonada de 50<br>mg dia 1 a 14, seguido de T 100 mg<br>dias 15 a 28 + D 40 mg VO dias 1-4,<br>dias 9-12 em 6 ciclos de 4 semanas.<br>Duração da indução de 24 semanas.<br>N = 130<br>Homens, N (%) = 72 (55)<br>Idade em anos, mediana = 56<br>ISS, N (%) = NR<br>Alterações genéticas de alto risco, N<br>(%) = 24 (18)|Esquema = TD (T até dose diária<br>de 200 mg, com dose escalonada de<br>50 mg dias 1 a 14, seguido de T<br>100 mg dias 15 a 28 + D 40 mg VO<br>dias 1-4, dias 9-12 em 6 ciclos de 4<br>semanas). Duração da indução de<br>24 semanas.<br>N = 127<br>Homens, N (%) = 68 (54)<br>Idade em anos, mediana = 56<br>ISS, N (%) = NR<br>Alterações genéticas de alto risco,<br>N (%) = 22 (18)|SLP, SG,<br>EA|PETHEMA<br>Foundation,<br>Janssen-Cilag e<br>Pharmion|
||Cavo 2010|||Indução: 3 ciclos de 21 dias de VTD|Indução: 3 ciclos de 21 dias de TD|||
||Cavo|||(V 1,3 mg/m² EV dias 1, 4, 8, e 11 +T|(T 100 mg/dia nas primeiras duas|||
||2012a|||100 mg/dia nas primeiras duas|semanas, seguida de 200 mg/dia|||
||Cavo|||semanas, seguida de 200 mg/dia|posteriormente + D320 mg por||Seràgnoli Institute|
|GIMEMA-MMY-<br>3006|2012b<br>Cavo 2013<br>Brioli<br>2016|ECR<br>fase III|Pacientes com MM<br>sintomáticos<br>elegíveis ao TCTH|posteriormente + D 320 mg por ciclo)<br>Consolidação: 2 ciclos de 35 dias de<br>VTD (V 1,3 mg/m² EV dias 1, 8, 15, e<br>22 +T 100 mg/ dia + D 320 mg por|ciclo)<br>Consolidação: 2 ciclos de 35 dias<br>de TD (T 100 mg/ dia + D 320 mg<br>por ciclo)|SLP, SG,<br>EA|of Hematology na<br>Universidade de<br>Bologna, Janssen|
||Tacchetti|||ciclo)|N = 238|||
||2018|||N = 236|Homens, N (%) = 136 (57)|||
||Tacchetti|||Homens, N (%) = 137 (58)|Idade em anos, mediana|||  
|**Estudo**|**Autor,**<br>**ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
||2019<br>Tacchetti<br>2020|||Idade em anos, mediana (intervalo)=<br>58 (52 a 62)<br>ISS, N (%) =<br>I:107 (45)<br>II: 91 (39)<br>III: 38 (16)<br>Alterações genéticas de alto risco, N<br>(%) =<br>del(13q): 103/218 (47)<br>t(4;14) ou del(17p): 53/218 (24)|(intervalo)= 57 (51 a 62)<br>ISS, N (%) =<br>I:107 (45)<br>II: 92 (39)<br>III: 39 (16)<br>Alterações genéticas de alto risco,<br>N (%) = del(13q): 103/223 (46)<br>t(4;14) ou del(17p): 57/2226 (26)|||
|IFM 2005-01|Harosseau<br>2010|ECR<br>fase III|Pacientes com MM<br>sintomáticos e não<br>tratados menores de<br>65 anos|VD: 4 ciclos de 3 semanas (V 1,3<br>mg/m<sup>2</sup>EV dias 1,4,8 e 11 + D 40 mg<br>D1-4(todos os ciclos) e dias 9-12<br>(ciclos 1 e 2).<br>N = 240<br>Homens, N (%) = 139 (57,9)<br>Idade em anos, mediana (intervalo) =<br>57,2 (NR)<br>ISS, N (%) =<br>I: 102 (42,5)<br>II: 81 (33,8)<br>III: 52 (21,7)<br>Indeterminado: 5 (2,1)<br>Alterações genéticas de alto risco, N<br>(%) =|VAD: 4 ciclos de 4 semanas<br>(vincristina 0,4 mg/d +<br>doxorubicina 9 mg/m<sup>2</sup>/d em infusão<br>contínua D1-4 +D 40 mg VO dias<br>1-4 (todos os ciclos) e dias 9-12 e<br>D17-20 (ciclos 1 e 2)<br>N = 242<br>Homens, N (%) = 127 (52,5)<br>Idade em anos, mediana<br>(intervalo)= 57,1 (NR)<br>ISS, N (%) =<br>I: 97/242 (40,1)<br>II: 82/242 (33,9)<br>III: 54/242 (22,3)<br>Indeterminado: 9/242 (3,7)|SLP, SG,<br>EA|Nantes University<br>Hospital|  
|**Estudo**|**Autor,**<br>**ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|||||del (13): 101 (42,1)<br>t(4;14) ou del(17p): 40 (16,7)|Alterações genéticas de alto risco,<br>N (%) =|||
||||||del (13): 103 (42,6)<br>t(4;14) ou del(17p): 29 (12)|||  
<mark>Legenda: D (dexametasona), EA (evento adverso), ECR (ensaio clínico randomizado), ISS (Sistema Internacional de Estadiamento), EV (intravenoso), MM (mieloma múltiplo), N (número de participantes), NR (não relatado),</mark>  
<mark>SG (sobrevida global), SLP (sobrevida livre de progressão), T (talidomida), TCTH (transplante de células-tronco hematopoiéticas), TRC (taxa de resposta completa), V (bortezomibe), VO (via oral). *Dentre os desfechos de interesse para a presente revisão.</mark>  
Para o desfecho **SG** , não foi possível demonstrar benefício dos esquemas terapêuticos com bortezomibe (Peto OR = 0,76, IC de 95% 0,46 a 1,26), pois a mediana de sobrevida não foi alcançada em dois estudos - GEM05MENOS65<sup>26</sup> e IFM 2005-01<sup>35</sup> ( **Figura I** ). O estudo GIMEMA-MMY-3006 possui análise da SG após 124 meses de acompanhamento, com benefício do bortezomibe em comparação aos esquemas terapêuticos sem bortezomibe (com bortezomibe= 60% vs sem bortezomibe: 46%; HR = 0,68, IC de 95% 0,51 a 0,90)<sup>27–34</sup> .  
**Figura I -** Gráfico de floresta para as razões de chance de Peto para SG para pacientes em uso de esquemas baseados em bortezomibe quando comparado a esquemas sem bortezomibe  
<!-- Start of picture text -->
‘Study or Subgroup Events Total Events Total__O-£ Variance Weight Exp{(O-£) / VJ, Fixed, 95% Cl Exp{{O-£) / VJ, Fixed, 95% Cl<br>cewwewexosss Tetorimal<br>rotsTeal evrs 8 a ao sea ore(04s 126<br>Testo ol eee 2-106 @=028 a<br><!-- End of picture text -->  
Para **SLP** , houve benefício dos esquemas terapêuticos com bortezomibe em relação aos esquemas sem o medicamento  
(Peto OR = 0,71, IC de 95% 0,59 a 0,86, I<sup>2</sup> = 17%) ( **Figura J** ).  
**Figura J -** Gráfico de floresta para sobrevida livre de progressão para pacientes em uso de esquemas baseados em bortezomibe quando comparado a esquemas sem bortezomibe.  
<!-- Start of picture text -->
Study or Subgroup Events Total Events Total__O-E Variance Weight_Expf{O-£) / VJ, Fixed, 95% Cl Expi{O-£) | V), Fixed, 95% Cl<br>SENESVENGES rr Teterimal<br>Total (95% Cl) 476 480 100.0% 0.74 (0.59, 0.86] a<br>Totten iio is<br><!-- End of picture text -->  
Não houve diferença entre os esquemas com e sem bortezomibe na incidência de **EA graus 3 e 4** (OR = 1,92, IC 95%=1,00 a 3,71, I<sup>2</sup> = 87%) ( **Figura K** ). Quanto à **neuropatia periférica** , houve maior chance de ocorrência deste evento em pacientes que receberam esquemas terapêuticos associados a bortezomibe (OR = 2,68, IC 95%=1,61 a 4,48, I<sup>2</sup> = 35%) ( **Figura L** ). Já em relação à **suspensão por EA** , não houve diferença entre os esquemas com e sem bortezomibe (OR=1,54; IC 95% = 1,02 a 2,33; I<sup>2</sup> = 0%) ( **Figura M** ).  
**Figura K -** Gráfico de floresta para a ocorrência de eventos adversos graus 3 e 4 em pacientes em uso de esquemas baseados em bortezomibe quando comparado a esquemas sem bortezomibe.  
<!-- Start of picture text -->
GEMOSMENOS6S 93 130 60 127 31.1% 2.81 [1.67, 4.70] =_<br>rwznos01 m0 eo tas om tosmratan<br>Honey To*=028,Cht'= 1396 o=7<br>Testor oral eect: 2=1.95 = 095) @= 00006, P=8T 1 cqvorecsbortezomibeFavorece corte"<br><!-- End of picture text -->  
**Figura L -** Gráfico de floresta para a ocorrência de neuropatia periférica em pacientes em uso de esquemas baseados em bortezomibe quando comparado a esquemas sem bortezomibe.  
<!-- Start of picture text -->
oe =<br>ie Eh<br>a ee a<br>GIMEMA-MIMY-3006 23 236 5 238 206% 5.03 [1.88, 13.47) _———<br>iFM 2005-01 105 239 66 239 §8.2% 2.05[1.40, 3.01) -<br>Total (95% C) 605 604 100.0% 2.68 (1.61, 4.48] ><br>two :<br>Heterogeneity: Tau?= 0.08; Chi?= 3.06, df= 2(P = 0.22); F= 35%<br>Testor overalefect-Z= 377 = 0.002) 801 soracebotszamibe Favorececontole<br><!-- End of picture text -->  
**Figura M -** Gráfico de floresta para a suspensão por eventos adversos em pacientes em uso de esquemas baseados em bortezomibe quando comparado a esquemas sem bortezomibe.  
<!-- Start of picture text -->
SE =<br>ie ES,<br>a ee<br><< et ate aa<br><< 2 2 2 Bae gee<br>voton . - sans tana<br>TestorHeterogeneity: overalefectTau?= 0.00;Z= 204Chi?== 008)0.47, df= 2 (P = 0.79); F= 0% 801 soracebotszamibe Favorececontole<br><!-- End of picture text -->  
A avaliação do risco de viés está descrita na **Figura N** . Os três estudos foram avaliados com alto risco de viés quanto à falta de cegamento dos participantes e profissionais envolvidos. O estudo GEM05MENOS65<sup>26</sup> foi avaliado com algumas preocupações quanto ao relato seletivo de desfechos, devido ao relato de apenas alguns EA.  
**Figura N-** Risco de viés dos ensaios clínicos randomizados selecionados avaliado pela ferramenta RoB.  
<!-- Start of picture text -->
cenosmenoses [@/@(@[@/@[@[@|fs [2 [s [als [eo [| © sinoricoaevis<br>eae! OOOOOO @ Aleumas preocupacdes<br>ruroorat— [@[@[O[@[O[O[2)  @ mormsene<br><!-- End of picture text -->  
Legenda: 1: Geração de sequência aleatória, 2: Sigilo de alocação, 3: Cegamento dos participantes e profissionais, 4: Cegamento dos avaliadores dos desfechos, 5: Desfechos incompletos, 6: Relato seletivo dos desfechos, 7: Outros vieses. Fonte: Traduzido de Scott _et al._ (2016).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que os efeitos desejáveis são grandes e que os efeitos indesejáveis podem estar superestimados, pois os estudos clínicos contemplados não refletem a posologia e a via de administração utilizadas na prática clínica atual (administração semanal por via subcutânea).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Considerações gerais e para implementação:** -->
O bortezomibe para o tratamento de pacientes adultos com MM, elegíveis ao TCTH, não tratados previamente, no âmbito do Sistema Único de Saúde, foi incorporado por meio da Portaria SCTIE/MS nº 43, publicada em 28 de setembro de 2020.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
A **Tabela C** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para os desfechos SG, SLP, EA graus 3 e 4, suspensão por EA e neuropatia periférica.  
**Tabela C -** Avaliação da certeza da evidência do uso de esquemas terapêuticos com bortezomibe para pacientes com mieloma múltiplo elegíveis ao TCTH.  
<!-- Start of picture text -->
Certeza da evidência  № de pacientes  Efeito<br>Certeza<br>№ dos  Delineamento  Risco  Evidência  Outras  Esquemas  Esquemas  Relativo  Absoluto  geral  da  Importância<br>Inconsistência  Imprecisão  com  sem  (IC  evidência<br>estudos  do estudo  de viés  indireta  considerações  (IC 95%)<br>bortezomibe  bortezomibe  95%)<br>Sobrevida Global (Seguimento: mediana de 124 meses)<br>HR 0,68  CRÍTICO<br>não  236  238  (0,51  ⨁⨁⨁⨁<br>1  ECR  não grave  não grave  não grave  nenhum<br>grave  participantes  participantes  para  Alta<br>0,90)<br>Sobrevida Livre de Progressão (Seguimento: mediana 36 meses)<br>Peto OR<br>0,71<br>não  110/476  128/480  ⨁⨁⨁⨁<br>3  ECR  não grave  não grave  não grave  nenhum  (0,59  CRÍTICO<br>grave  (23,1%)  (26,7%)  Alta<br>para<br>0,86)<br>Eventos adversos graus 3 e 4 (Seguimento: mediana de 32, 2 a 36 meses)<br>162 mais<br>OR 1,92  por 1.000<br>337/605  249/604  (1,00  (de  0  ⨁⨁◯◯<br>3  ECR  grave a,b  grave c  não grave  não grave  nenhum  IMPORTANTE<br>(55,7%)  (41,2%)  para  menos  Baixa<br>3,71)  para  310<br>mais)<br><!-- End of picture text -->  
<!-- Start of picture text -->
Certeza da evidência  № de pacientes  Efeito<br>Certeza<br>№ dos  Delineamento  Risco  Evidência  Outras  Esquemas  Esquemas  Relativo  Absoluto  geral  da  Importância<br>Inconsistência  Imprecisão  com  sem  (IC  evidência<br>estudos  do estudo  de viés  indireta  considerações  (IC 95%)<br>bortezomibe  bortezomibe  95%)<br>Suspensão por Evento Adverso (Seguimento: mediana de 32, 2 a 36 meses)<br>34  mais<br>OR 1,54<br>por 1.000<br>63/605  (1,02  ⨁⨁⨁◯<br>3  ECR  grave a não grave  não grave  grave d  nenhum  43/604 (7,1%)  (de 1 mais  IMPORTANTE<br>(10,4%)  para  Moderada<br>para  80<br>2,33)<br>mais)<br>Neuropatia periférica (Seguimento: mediana de 32, 2 a 36 meses)<br>154 mais<br>OR 2.68<br>por 1.000<br>145/605  77/604  (1,61  ⨁⨁⨁◯<br>3  ECR  grave a  não grave  não grave  não grave  nenhum  (de  63  IMPORTANTE<br>(24,0%)  (12,7%)  para  Moderada<br>mais para<br>4,48)<br>268 mais)<br><!-- End of picture text -->  
Legenda: ECR: ensaios clínicos randomizados; OR: _odds ratio_ ; HR: _hazard ratio_ .  
Explicações:  
a. A falta de cegamento dos avaliadores pode comprometer a avaliação deste desfecho. Apenas 1 ECR descreve a reavaliação externa e centralizada da classificação dos eventos adversos (GIMEMA-MMY-3006).  
b. No estudo GEM05MENOS65 há suspeita de relato seletivo dos eventos adversos relatados.  
c. Os intervalos de confiança não se sobrepõem e o I<sup>2</sup> =87%.  
d. O intervalo de confiança passa pelo efeito nulo.  
Referências: Brioli et al. 2016<sup>31</sup> , Cavo et al. 2010<sup>27</sup> , Cavo et al. 2012a<sup>28</sup> , Cavo et al. 2012b<sup>29</sup> , Cavo et al. 2013<sup>30</sup> , Harousseau et al. 2010<sup>35</sup> , Rosiñol et al. 2012<sup>26</sup> , Tacchetti et al. 2018<sup>32</sup> , Tacchetti et al. 2019<sup>33</sup> , Tacchetti et al. 2020<sup>34</sup> .  
**Tabela para tomada de decisão (** **_Evidence to Decision table- EtD_ ):**  
O **Quadro K** apresenta o processo de tomada de decisão sobre o uso de bortezomibe para a terapia de indução de pacientes com MM elegíveis ao TCTH, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador, informações das DDT do MM<sup>1</sup> e bula do bortezomibe<sup>36</sup> , aprovado para uso no Brasil.  
**Quadro K -** Processo de tomada de decisão referente ao uso de esquemas terapêuticos com bortezomibe para tratamento de indução de pacientes com mieloma múltiplo elegíveis ao TCTH.  
|**Item da EtD**|**Julgamento dos painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios**|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são<br>substanciais, com aumento da SLP.|
|||O painel considerou que os eventos adversos podem estar<br>superestimados, pois os ECRs contemplados não refletem a|
|**Riscos**|Moderado|posologia e via de administração de bortezomibe utilizadas na|
|||prática clínica atual (administração semanal, por via<br>subcutânea).|
|**Balanço dos riscos e**<br>**benefícios**|Favorece a intervenção|Os membros julgam que o balanço é favorável à intervenção.|
|**Certeza da evidência**|Alta|Julgamento baseado na avaliação da certeza da evidência dos<br>desfechos críticos de SG e SLP.|
|**Recursos requeridos**|Custos e economia<br>negligenciáveis|Foi considerado que o medicamento já foi incorporado no<br>SUS.|
|**Custo efetividade**|Favorece a intervenção|-|
|**Outras considerações**|Não foram reportadas outras co|nsiderações.|  
Fonte: Autoria própria.  
**QUESTÃO 3: Deve-se utilizar bortezomibe associado aos esquemas terapêuticos usuais em vez dos esquemas terapêuticos usuais isolados na terapia de indução de pacientes com mieloma múltiplo inelegíveis ao TCTH?**  
**<u>Recomendação 3:</u>** Recomendamos o uso de combinações baseadas em bortezomibe para pacientes com mieloma múltiplo, recém-diagnosticado, inelegíveis ao transplante de células-tronco hematopoiéticas (qualidade de evidência moderada, recomendação forte).  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos, com MM, inelegíveis ao TCTH.  
**Intervenção:** Bortezomibe + esquema terapêutico usual.  
**Comparador:** Esquemas terapêuticos usuais previstos em bula e disponíveis no SUS.  
**Desfechos:** SG, qualidade de vida ou outros desfechos relatados pelos pacientes ( _patient related outcomes - PRO_ ), SLP, taxa de resposta completa (TRC), EA.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca** -->
A seleção das evidências foi realizada em duas etapas:  
**Etapa 1** : foram selecionadas RSMA que avaliam o efeito do uso de bortezomibe isolado ou associado aos esquemas  
terapêuticos usuais versus esquemas terapêuticos usuais nos pacientes com MM inelegíveis ao TCTH.  
**Etapa 2** : foi realizada a seleção dos ECR, publicados a partir da RS selecionada para atualização.  
Na **Etapa 1** , foram utilizadas as mesmas estratégias de busca realizadas para a questão 2, e foram apresentadas no Quadro E. Após a busc <mark>a nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra foram realizadas de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Revisões sistemáticas selecionadas</u> -->
Para os pacientes inelegíveis ao TCTH, após a busca na literatura por estudos que atendessem aos critérios de elegibilidade, quatro RSMA de ECR foram selecionadas<sup>20,37–39</sup> ( **Figura O** ). Os motivos de exclusão das demais RSs são apresentados no **Quadro L** , organizados por motivo de exclusão.  
**Figura O -** Fluxograma de seleção dos estudos (revisões sistemáticas com meta-análise de ensaios clínicos randomizados).  
<!-- Start of picture text -->
Registros identificados:<br>Pubmed (n = 58) Registros removidos antes da<br>EMBASE (n = 547) selecao:<br>Cochrane (n = 6) Duplicatas removidas (n =<br>LILACS (n = 37) 60)<br>Total (n = 648)<br>Registros analisados Registros excluidos<br>(n= 588) (n = 569)<br>Relatos selecionados para y<br>recuperacao >| Relatos ndo recuperados<br>(n= 19) (n=0)<br>Relatos avaliados para<br>cleaibnidade(n= 19) >| RelatosDesenho excluidosde estudo (n = 15)incorreto<br>(n=9)<br>Intervencéo ou comparador<br>incorretos (n = 6)<br>Estudos incluidos na revisio<br>(n=4)<br><!-- End of picture text -->  
**Quadro L -** Motivos de exclusão das demais revisões sistemáticas (n = 15).  
|**Autor, ano**|**Título**|**Motivo de**<br>**exclusão**|
|---|---|---|
|Abdullah et al.|_Treatment Options for Newly Diagnosed Frail and Transplant-Ineligible_|Desenho do|
|2020|_Patients with Multiple Myeloma: A Systematic Review_|estudo inelegível|
|Burchberger et al.|_Treatment Strategies for Elderly Patients with Newly Diagnosed Multiple_|Desenho do|
|2015|_Myeloma: A Meta-Analysis and Indirect Treatment Comparison._|estudo inelegível|
|Burchberger et al.|_Comparative Effectiveness of Treatment Strategies for Multiple Myeloma in_|Desenho do|
|2016|_Elderly Patients:: A Network Meta-Analysis._|estudo inelegível|  
|**Autor, ano**|**Título**|**Motivo de**<br>**exclusão**|
|---|---|---|
|Jansen et al. 2010|_Complete Response and Survival Outcomes with Bortezomib-Melphalan-_<br>_Prednisone: An Indirect Comparison Thalidomide-Based Regimen for the Front_<br>_Line Treatment of Multiple Myeloma._|Desenho do<br>estudo inelegível|
|Kuhr et al. 2016|_First-line therapy for non-transplant eligible patients with multiple myeloma:_<br>_direct and adjusted indirect comparison of treatment regimens on the existing_<br>_market in Germany._|Desenho do<br>estudo inelegível|
|Mateos et al. 2020|_The effects of different schedules of bortezomib, melphalan, and prednisone for_<br>_patients with newly diagnosed multiple myeloma who are transplant ineligible:_<br>_a matching-adjusted indirect comparison._|Desenho do<br>estudo inelegível|
|Rafae et al. 2020|_Maintenance Therapy in Newly Diagnosed and Transplant Ineligible Multiple_<br>_Myeloma Patients: A Meta-Analysis._|Desenho do<br>estudo inelegível|
|Siddiqui et al. 2019|_Three Drug Regimens for Newly Diagnosed Multiple Myeloma Transplant-_<br>_Ineligible Elderly Patients - a Systematic Review._|Desenho do<br>estudo inelegível|
|Wang et al. 2014|_Bortezomib-Containing Regimens for Multiple Myeloma Maintenance Therapy:_<br>_a Meta-Analysis._|Desenho do<br>estudo inelegível|
|Abdullah et al.<br>2019|_Advancements in Treatment for Newly Diagnosed Frail and Elderly Myeloma_<br>_Patients: A Systematic Review._|Intervenção ou<br>comparador<br>inelegíveis|
||_Efficacy Of Bortezomib-Based Regimens With Or Without An_|Intervenção ou|
|Atkins et al. 2013|_Immunomodulatory Agent In Older Adults With Multiple Myeloma: A_<br>_Systematic Review and Meta-Analysis._|comparador<br>inelegíveis|
|Balitsky et al. 202|_Maintenance therapy in transplant ineligible adults with newly-diagnosed_<br>_multiple myeloma: A systematic review and meta-analysis._|Intervenção ou<br>comparador<br>inelegíveis|
|Rodriguez et al.<br>2009|_First line therapy for patients with newly diagnosed multiple myeloma ineligible_<br>_for autologous stem cell transplantation: a systematic review and meta-analysis_<br>_(hemo-oncolgroup study)._|Intervenção ou<br>comparador<br>inelegíveis|
|Rodriguez et al.<br>2012|_Tratamiento de primera línea para pacientes con mieloma múltiple no elegibles_<br>_para trasplante autólogo de células progenitoras : revisión sistemática y meta-_<br>_análisis (estudio del Hemo-ONCOLGroup)._|Intervenção ou<br>comparador<br>inelegíveis|
||_Bayesian Network Meta-Analysis (NMA): Safety of Bortezomib, Thalidomide or_|Intervenção ou|
|Satta et al. 2015|_Lenalidomide Containing Regimens for Transplant Ineligible Multiple Myeloma_<br>_(MM) Patients._|comparador<br>inelegíveis|

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Avaliação da qualidade metodológica e caracterização das revisões sistemáticas</u> -->
A avaliação da qualidade metodológica das RS foi realizada utilizando a ferramenta AMSTAR 2.0<sup>3</sup> . As revisões de Scott et al. 2016<sup>20</sup> e Piechotta et al. 2019<sup>38</sup> não apresentaram nenhuma falha crítica, enquanto as revisões de Blommenstein et al. 2019<sup>37</sup> e Sekine et al. 2019<sup>39</sup> apresentaram 4 e 2 falhas críticas, respectivamente ( **Quadro M** ). Assim, optou-se pela atualização do estudo de Scott et al. 2016<sup>20</sup> , que apresenta os resultados por meio de meta-análise direta.  
**Quadro M -** Avaliação da qualidade metodológica e caracterização das revisões sistemáticas com meta-análise de ensaios clínicos randomizados (n = 4).  
|**Autor, ano**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Número de**<br>**falhas críticas**<br>**(AMSTAR 2.0)**|
|---|---|---|---|---|---|
|Blommenstein et<br>al. 2019|Pacientes adultos<br>com MM recém-<br>diagnosticados<br>inelegíveis ao<br>TCTH|Múltiplos<br>esquemas<br>terapêuticos<br>avaliados em<br>rede|Dexametasona|SLP|4|
|Piechotta et al.<br>2019|Pacientes adultos<br>com MM recém<br>diagnosticados<br>inelegíveis ao<br>TCTH|Múltiplos<br>esquemas<br>terapêuticos<br>avaliados em<br>rede|Múltiplos<br>esquemas<br>terapêuticos<br>avaliados em<br>rede|SG<br>SLP<br>EA graus 3 e 4<br>QV|0|
|Scott et al.<br>2016|Pacientes com MM<br>com diagnóstico<br>recente (elegíveis ou<br>inelegíveis ao<br>TCTH) ou<br>refratários|Esquemas<br>terapêuticos com<br>bortezomibe|Esquemas<br>terapêuticos sem<br>bortezomibe|SG<br>SLP<br>Taxa de<br>resposta<br>QV<br>EA<br>Morte<br>relacionada ao<br>tratamento<br>TRG<br>TRC<br>TRP<br>TTP<br>Intervalo sem<br>tratamento|0|
|Sekine et al. 2019|Pacientes adultos<br>com MM recém-<br>diagnosticados<br>inelegíveis ao<br>TCTH|Múltiplos<br>esquemas<br>terapêuticos|Múltiplos<br>esquemas<br>terapêuticos|SG<br>SLP<br>TRC<br>TRG<br>Toxicidade<br>SLE<br>Tempo até o<br>próximo<br>tratamento|2|  
Legenda: <mark>EA (evento adverso), MM (mieloma múltiplo), SG (sobrevida global), SLP (sobrevida livre de progressão), SLE (Sobrevida Livre de Eventos), TCTH (transplante de células-tronco hematopoiéticas), TRC (taxa de resposta completa), TRG (taxa de resposta global), TRP (taxa de resposta parcial), TTP (tempo até progressão).</mark>  
Na **Etapa 2** , foi realizada atualização da estratégia de busca do estudo de Scott et al. 2016<sup>20</sup> nas bases de dados <mark>Medline (via Ovid), Embase e Cochrane no dia 26 de outubro de 2021, conforme descrito anteriormente, para a questão 2</mark> ( **QuadroL** ). Com a utilização do filtro de data, as potenciais publicações posteriores a <mark>27 de janeiro de 2016 foram</mark> recuperadas.  
<mark>Após a busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra, foi realizada de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos com MM inelegíveis ao TCTH.  
- (b) Tipo de intervenção: Bortezomibe associado aos esquemas terapêuticos usuais, previstos em bula, disponíveis no SUS.  
- (c) Tipo de comparador: Esquemas terapêuticos usuais disponíveis no SUS.  
- (d) Desfechos: SG, SLP, TRC, EA grave, neuropatia periférica grau 3 e 4, suspensão devido à EA e qualidade de vida.  
- (e) Tipos de estudos: ECR.  
- (f) Idioma e data de publicação: Sem restrição.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Resultados da busca</u> -->
Para os pacientes com MM inelegíveis ao TCTH, não houve inclusão de novos ECRs além daqueles incluídos pela RS publicada por Scott et al. 2016<sup>20</sup> . Entre os ECR utilizados no estudo de Scott et al. 2016, somente o ECR VISTA (bortezomibe, melfalana e prednisona vs. melfalana e prednisona, 9 ciclos a cada 6 semanas)<sup>40</sup> inclui o esquema terapêutico com bortezomibe previsto em bula ( **Figura P** ).  
**Figura P -** Fluxograma de seleção dos estudos (ensaios clínicos randomizados).  
<!-- Start of picture text -->
| | Estudos incluidos na Registros identificados de: Relatos excluidos antes da<br>g revisdo publicada por ‘Medline (via Ovid) (n = 269) selecdo:<br>al5 Scott et al. 2016 (n = 1) CochraneEmbase (n(n= =1229)1097) 855)Duplicatas removidas (n =<br>3<br>Relatos analisados Relatos excluidos<br>(n= 1740) (n= 1740)<br>Relatos selecionados para Relatos ndo recuperados<br>recuperacdo (n = 0) (n=0)<br>Relatos avaliados quanto a Relatos excluidos (n = 0)<br>eligibilidade (n = 0)<br>Novos estudos incluidos na<br>revisdo (n = 0)<br>Total de estudos incluidos na<br>revisdo (n = 1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Análise e apresentação dos resultados</u> -->
A avaliação do risco de viés do estudo VISTA<sup>40</sup> foi realizada previamente por Scott et al. 2016<sup>20</sup> , utilizando a ferramenta RoB 1.0<sup>25</sup> . Os julgamentos do risco de viés foram avaliados e adotados nestas Diretrizes. Os resultados foram apresentados por desfecho, com estimativas do Peto OR e OR, com respectivos IC de 95%.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
O ECR VISTA<sup>40</sup> , incluído na RS de Scott et al. (2016)<sup>20</sup> , incluiu esquema terapêutico previsto em bula e foi avaliado para tomada de decisão. As características deste estudo foram apresentadas na **Tabela D** . O estudo apresentou alto risco de viés para o domínio “cegamento do paciente e dos profissionais”, pois se trata de um ECR aberto; baixo risco de viés para os domínios “geração da sequência de randomização”, <mark>“cegamento de avaliadores de desfecho” (SG e outros desfechos), “desfechos incompletos” e “relato de desfecho seletivo” e; r</mark> isco de viés não claro para os domínios “ocultação da alocação” e “outras fontes de vieses”.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que os efeitos desejáveis são grandes e que os efeitos indesejáveis podem estar superestimados, pois os estudos clínicos contemplados não refletem a posologia e a via de administração utilizadas na prática clínica atual (administração semanal por via subcutânea).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Considerações gerais e para implementação:** -->
O bortezomibe foi incorporado no âmbito do Sistema Único de Saúde para o tratamento de pacientes adultos com MM, inelegíveis ao TCTH, não tratados previamente, por meio da Portaria SCTIE/MS nº 45, publicada em 28 de setembro de 2020.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
A **Tabela E** apresenta os resultados da avaliação da certeza da evidência (GRADE) para os desfechos SG, SLP, resposta  
completa, neuropatia periférica graus 3 e 4, EA graus 3 e 4 e suspensão por EA.  
**Tabela D -** Caracterização do ensaio clínico randomizado (n = 1).  
|**Estudo**|**Autor,**<br>**ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|VISTA|San<br>Miguel et<br>al. 2008|ECR fase<br>III|Pacientes com MM<br>recém diagnosticados<br>inelegíveis ao TCTH|VMP (M 9 mg/m<sup>2</sup>/d e P 60 mg/m<sup>2</sup>d1-4 + V<br>1,3 mg/m<sup>2</sup>/d d1, d4, d8, d11, d22, d25, d29,<br>d32 nos ciclos 1 ao 4 e d1, d8, d22, d29 nos<br>ciclos 5 a 9 - 9 ciclos de 6 semanas)<br>N = 344<br>Homens, N (%) = 175 (51)<br>Idade em anos, mediana (intervalo)= 71 (57<br>a 90)<br>ISS, N (%) =<br>I: 64 (19)<br>II: 161 (47)<br>III: 119 (35)<br>Alterações genéticas de alto risco, N (%) =<br>NR|MP (M 9 mg/m<sup>2</sup>/d e<br>P 60 mg/m<sup>2</sup>d1-4 )<br>N = 121<br>Homens, N (%) =<br>166 (49)<br>Idade em anos,<br>mediana (intervalo)=<br>71 (48 a 91)<br>ISS, N (%) =<br>I: 23 (19)<br>II: 57 (47)<br>III: 41 (34)<br>Alterações genéticas<br>de alto risco, N (%)<br>= NR|**SG**<br>Peto OR: 0,70<br>(IC de 95% 0,57<br>a 0,85)<br>**SLP**<br>Peto OR: 0,56<br>(IC de 95% 0,44<br>a 0,71)<br>**RC**<br>OR 11,54 (IC de<br>95% 6,20 a<br>21,48)<br>**Neuropatia**<br>**periférica graus**<br>**3 e 4**<br>OR 101,31 (IC<br>de 95% 6,21 a<br>1652,18)<br>**Eventos**<br>**adversos graus**|Millennium<br>Pharmaceuticals|  
|**3 e 4**|
|---|
|OR 1,78 (IC de|
|95% 1,24 a 2,55)|
|**Suspensão por**|
|**EA**|
|OR 1,05 (IC de|
|95% 0,69 a 1,69)|  
<mark>Legenda: ECR (ensaio clínico randomizado), MM (mieloma múltiplo), V (bortezomibe), M (melfalana), P (prednisona), TCTH (transplante de células-tronco hematopoiéticas), NR (não reportado), ISS (Sistema Internacional</mark>  
<mark>de Estadiamento), N (número de participantes), SG (sobrevida global), SLP (SLP), RC (resposta completa), EA (eventos adversos), TTP (tempo até progressão), IC (Intervalo de Confiança), OR (Odds Ratio).</mark>  
**Tabela E -** Avaliação da certeza da evidência do uso de esquemas terapêuticos com bortezomibe para pacientes com mieloma múltiplo inelegíveis ao TCTH.  
|**AVALIA**|**ÇÃO**||||||**№ de pacientes**||**Efeito**|**Certeza**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**<br>**Sobrevid**|<br>**Delineamento**<br>**do estudo**<br>**a Global (Seguimen**|**Risco**<br>**de viés**<br>**to: media**|**Inconsistência**<br>**na de 16,3 mese**|<br>**Evidência**<br>**indireta**<br>**s)**|**Imprecisão**|**Outras**<br>**considerações**|**Esquemas com**<br>**bortezomibe**|**Esquemas sem**<br>**bortezomibe**|<br>**Relativo**<br>**(IC95%)**|**geral**<br>**da**<br>**evidência**|<br>**Importância**|
|1<br>**Sobrevid**<br>1<br>**Resposta**|ensaios clínicos<br>randomizados<br>**a Livre de Progress**<br>ensaios clínicos<br>randomizados<br>**completa (Seguime**|grave<sup>a</sup><br>**ão (Segui**<br>grave<sup>a</sup><br>**nto: medi**|não grave<br>**mento: mediana**<br>não grave<br>**ana de 16,3 mes**|não grave<br>**de 16,3 mese**<br>não grave<br>**es)**|não grave<br>**s)**<br>não grave|nenhum<br>nenhum|176/344<br>(51,2%)<br>111/344<br>(32,3%)|211/338<br>(62,4%)<br>172/338<br>(50,9%)|**Peto**<br>**OR**<br>**0,70**<br>(0,57 para<br>0,85)<br>**Peto**<br>**OR**<br>**0,56**<br>(0,44 para<br>0,71)|⨁⨁⨁◯<br>Moderada<br>⨁⨁⨁◯<br>Moderada|CRÍTICO<br>CRÍTICO|
|1|ensaios clínicos<br>randomizados|grave<sup>a,b</sup>|não grave|não grave|grave<sup>c</sup>|nenhum|102/337<br>(30,3%)|12/331<br>(3,6%)|**OR 11,54**<br>(6,20 para<br>|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|**Neuropa**<br>1|**tia periférica graus**<br>ensaios clínicos<br>randomizados|**3 e 4 (Seg**<br>grave<sup>a,b</sup>|**uimento: media**<br>não grave|**na 16,3 meses**<br>não grave|**)**<br>muito<br>grave<sup>d</sup>|nenhum|44/340<br>(12,9%)|0/337<br>(0,0%)|21,48)<br>**OR 101,31**<br>(6,21 para<br>1652,18)|⨁◯◯◯<br>Muito baixa|IMPORTANTE|  
|**AVALIA**|**ÇÃO**||||||**№ de pacientes**||**Efeito**|**Certeza**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Esquemas com**<br>**bortezomibe**|**Esquemas sem**<br>**bortezomibe**|**Relativo**<br>**(IC95%)**|**geral**<br> <br>**evidência**|**da**<br>**Importância**|
|**Eventos a**<br>1|**dversos graus 3 e 4**<br>ensaios clínicos<br>randomizados|**(Seguime**<br>grave<sup>a,b</sup>|**nto: mediana 16**<br>não grave|**,3 meses)**<br>não grave|não grave|nenhum|277/340<br>(81,5%)|240/337<br>(71,2%)|**OR 1,78**<br>(1,24 para<br>2,55)|⨁⨁⨁◯<br>Moderada|IMPORTANTE|
|**Suspensã**<br>1|**o por eventos adver**<br>ensaios clínicos<br>randomizados|**sos (Segu**<br>grave<sup>a,b</sup>|**imento: median**<br>não grave|**a 16,3 meses)**<br>não grave|grave<sup>e</sup>|nenhum|50/344<br>(14,5%)|47/338 (13,9%)|**OR 1,05**<br>(0,69 para<br>1,69)|⨁⨁◯◯<br>Baixa|IMPORTANTE|  
Legenda: OR (odds ratio)  
Explicações:  
a. Não é possível afirmar que houve sigilo na alocação dos participantes.  
b. Não houve cegamento, ensaio clínico randomizado aberto.  
c. Intervalo de confiança amplo.  
d. Intervalo de confiança amplo, rebaixado dois graus de evidência.  
e. Intervalo de confiança passa pelo efeito nulo. Referências: San Miguel et al. 2008<sup>40</sup>  
**Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):**  
O **Quadro N** apresenta o processo de tomada de decisão sobre o uso bortezomibe para o tratamento de pacientes com MM inelegíveis ao TCTH, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador, informações das DDT do MM<sup>1</sup> e bula do bortezomibe<sup>36</sup> , aprovado para uso no Brasil.  
**Quadro N -** Processo de tomada de decisão referente ao uso de esquemas terapêuticos com bortezomibe para tratamento de indução de pacientes com mieloma múltiplo inelegíveis ao TCTH.  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios**|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são<br>substanciais, com aumento da SLP e SG.|
|**Riscos**|Moderado|O painel considerou que os efeitos indesejáveis podem estar<br>superestimados, pois os ECRs contemplados não refletem a posologia e<br>via de administração de bortezomibe utilizadas na prática clínica atual<br>(administração semanal, por via subcutânea).|
|**Balanço dos riscos e**<br>**benefícios**|Favorece a<br>intervenção|Os membros julgam que que o balanço é favorável à intervenção.|
|**Certeza da evidência**|Moderada|Julgamento baseado na avaliação da certeza da evidência dos desfechos<br>críticos de SG e SLP.|
|**Recursos requeridos**|Custos e economia<br>negligenciáveis|Foi considerado que o medicamento já foi incorporado no SUS.|
|**Custo efetividade**|Favorece a<br>intervenção|-|
|**Outras considerações**|Não foram reportadas|outras considerações.|  
Fonte: Autoria própria.  
**QUESTÃO 4:** **<mark>Deve-se utilizar bortezomibe isolado ou associado aos esquemas usuais</mark>** **_<mark>versus</mark>_** **<mark>esquemas terapêuticos usuais isolados como terapia de segunda linha em pacientes com mieloma múltiplo recidivado ou refratário?</mark>**  
**<u>Recomendação 4:</u>** <mark>Recomendamos a utilização de bortezomibe para pacientes com mieloma múltiplo recidivados ou refratários</mark> (quali <mark>dade de evidência alta, recomendação forte).</mark>  
A estrutura PICO para esta pergunta foi:  
**População:** <mark>Pacientes adultos, com MM, recidivado ou refratário.</mark>  
**Intervenção:** Bortezomibe isolado ou associado aos esquemas terapêuticos usuais previstos em bula e disponíveis no  
SUS.  
**Comparador:** Esquemas terapêuticos usuais previstos em bula e disponíveis no SUS.  
**Desfechos:** <mark>SG, SLP, TRC, EA graus 3 e 4, neuropatia periférica graus 3 e 4, s</mark> uspensão <mark>devido a EA, qualidade de vida</mark>  
ou outros desfechos relatados pelos pacientes ( _patient related outcomes - PRO_ ).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca:** -->
A seleção das evidências foi realizada em duas etapas:  
**Etapa 1** : foram selecionadas RSMA de ECR que avaliaram o efeito de bortezomibe isolado ou associado aos esquemas  
terapêuticos usuais _<mark>versus</mark>_ <mark>esquemas terapêuticos usuais isolados</mark> nos pacientes <mark>com MM recidivado ou refratário</mark> .  
**Etapa 2** : foi realizada a seleção dos ECR, publicados a partir da RS selecionada para atualização.  
Na **Etapa 1** , foram utilizadas as mesmas estratégias de busca realizadas para a questão 2, conforme **Quadro F** . Após a busca nas bases de dados, a exclusão das duplicatas e a seleção dos estudos foram realizadas por meio do _software_ Rayyan<sup>®</sup> . A seleção por títulos e resumos, e após leitura na íntegra, foi realizada de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Revisões sistemáticas selecionadas</u> -->
Para os pacientes inelegíveis com doença refratária ou recidiva, após a busca na literatura por estudos que atendessem aos critérios de elegibilidade, quatro RSMA de ECR foram selecionadas<sup>20,41–43</sup> ( **Figura Q** ). Os motivos de exclusão das demais RS estão presentes no **Quadro O** , organizados por motivo de exclusão.  
**Figura Q -** Fluxograma de seleção dos estudos (revisões sistemáticas com meta-análise de ensaios clínicos randomizados).  
<!-- Start of picture text -->
° Registros identificados<br>% Pubmed (n= 58) Registros removidos antes da<br>& EMBASE (n = 547) selecdo:<br>= Cochrane (n =6) Duplicatas removidas (n =<br>5 LILACS (n = 37) 60)<br>2 Total (n= 648)<br>Registros analisados Registros excluidos<br>(n= 588) (n =575)<br>Relatos selecionados para «<br>recuperacdo |__| Relatos nao recuperados<br>(n= 13) (n=0)<br>elegibilidade +] Relatos excluidos (n = 9)<br>(n=13) Desenho<br>(n= 4) de estudo incorreto<br>Intervencdo ou comparador<br>incorretos (n = 3)<br>Tipo de publicacdo incorreta<br>(n=2)<br>Estudos incluidos na revisdo<br>(n=4)<br><!-- End of picture text -->  
**Quadro O -** Estudos excluídos e motivos de exclusão na busca e seleção de revisões sistemáticas (n = 9).  
|**Autor, ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Kouroukis et|_Bortezomib in multiple myeloma: systematic review and clinical considerations._|Desenho do estudo|
|al. 2014||inelegível|
|Knopf et al.|_Meta-analysis of the efficacy and safety of bortezomib re-treatment in patients_|Desenho do estudo|
|2014|_with multiple myeloma._|inelegível|  
|**Autor, ano**|**Título**|**Motivo de exclusão**|
|---|---|---|
|Sparano et al.<br>2018|_Patient-reported outcomes in relapsed/refractory multiple myeloma: a_<br>_systematic review._|Desenho do estudo<br>inelegível|
|Teh et al. 2016|_Infection risk with immunomodulatory and proteasome inhibitor-based_<br>_therapies across treatment phases for multiple myeloma: A systematic review_<br>_and meta-analysis._|Desenho do estudo<br>inelegível|
|Sun et al. 2017|_Triplet versus doublet combination regimens for the treatment of relapsed or_<br>_refractory multiple myeloma: A meta-analysis of phase III randomized_<br>_controlled trials._|Intervenção ou<br>comparador<br>inelegíveis|
|van Beurden-<br>Tan et al. 2017|_Systematic Literature Review and Network Meta-Analysis of Treatment_<br>_Outcomes in Relapsed and/or Refractory Multiple Myeloma._|Intervenção ou<br>comparador<br>inelegíveis|
|Maiese et al.<br>2018|_Comparative Efficacy of Treatments for Previously Treated Multiple Myeloma:_<br>_A Systematic Literature Review and Network Meta-analysis._|Intervenção ou<br>comparador<br>inelegíveis|
|Scott et al.<br>2015|_Bortezomib for the treatment of multiple myeloma: a systematic review and_<br>_meta-analysis._|Tipo de publicação|
|Ruggeriet al.<br>2015|_Estimating the Relative Effectiveness of Treatments in Relapsed/Refractory_<br>_Multiple Myeloma through a Systematic Review and Network Meta-Analysis._|Tipo de publicação|

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Avaliação da qualidade metodológica e caracterização das revisões sistemáticas</u> -->
A avaliação da qualidade metodológica das RS foi realizada utilizando a ferramenta AMSTAR 2.0<sup>3</sup> . A revisão de Scott et al _._ (2016)<sup>20</sup> não apresentou nenhuma falha crítica, enquanto as demais revisões apresentaram entre três e dez falhas críticas<sup>41–</sup> 43 ( **Quadro P** ). Portanto, a RS de Scott et al _._ (2016)20 foi selecionada para atualização. O **Quadro P** apresenta as características das quatro RS.  
**Quadro P-** Avaliação da qualidade metodológica e caracterização das revisões sistemáticas com meta-análise de ensaios clínicos randomizados (n = 4).  
|**Autor,**<br>**ano**|**Desenh**<br>**o**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Tipo de**<br>**estudo**<br>**incluído**|**Número**<br>**de falhas**<br>**críticas**<br>**(AMSTA**<br>**R 2)**|
|---|---|---|---|---|---|---|---|
|Botta et<br>al. 2017|RS com<br>MA em<br>rede|Pacientes<br>com MM<br>em<br>recidiva ou<br>refratários|Esquemas<br>terapêuticos não<br>convencionais/novo<br>s|Esquemas<br>terapêuticos<br>convencionais/padrã<br>o (esquemas<br>terapêuticos<br>baseados em<br>bortezomibe ou<br>esquemas<br>terapêuticos|SG, SLP,<br>TRG,<br>TRPMB,<br>TRC, EA|ECR|4|  
|**Autor,**<br>**ano**|**Desenh**<br>**o**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Tipo de**<br>**estudo**<br>**incluído**|**Número**<br>**de falhas**<br>**críticas**<br>**(AMSTA**<br>**R 2)**|
|---|---|---|---|---|---|---|---|
|||||baseados em<br>imunomodulador)||||
|Luo et<br>al. 2018|RS com<br>MA em<br>rede|Pacientes<br>com MM<br>em<br>recidiva ou<br>refratários|Múltiplos esquemas<br>terapêuticos|Múltiplos esquemas<br>terapêuticos|SG, SLP,<br>TTP, taxa<br>de não<br>resposta|ECR|10|
|Schmit<br>z et al.<br>2018|RS com<br>MA em<br>rede|Pacientes<br>com MM<br>em<br>recidiva ou<br>refratários|Múltiplos esquemas<br>terapêuticos|Múltiplos esquemas<br>terapêuticos|SG, SLP,<br>TTP|ECR e<br>outros<br>tipos.<br>Entretanto<br>, apresenta<br>meta-<br>análise só<br>de ECR.|3|
|Scott et<br>al. 2016|RS com<br>MA|Pacientes<br>com MM<br>com<br>diagnóstic<br>o recente<br>(elegíveis<br>ou<br>inelegíveis<br>ao TCTH)<br>ou<br>refratários|Esquemas<br>terapêuticos com<br>bortezomibe|Esquemas<br>terapêuticos sem<br>bortezomibe|SLP, SG,<br>TRG,<br>TRC, TRP,<br>EA, morte<br>relacionad<br>a ao<br>tratamento,<br>QV|ECR|0|  
Legenda: <mark>EA (evento adverso), ECR (ensaio clínico randomizado), MA (meta-análise), MM (mieloma múltiplo), QV (qualidade de vida), RS (revisão</mark>  
<mark>sistemática), SG (sobrevida global), SLP (sobrevida livre de progressão), TCTH (transplante de células tronco hematopoiéticas), TRC (taxa de resposta completa), TRG (taxa de resposta global), TRP (taxa de resposta parcial), TRPMB (taxa de resposta parcial muito boa), TTP (tempo até progressão).</mark>  
Na **Etapa 2** , foi atualizada a estratégia de busca do estudo de Scott _et al._ (2016)<sup>20</sup> nas bases de dados <mark>Medline (via Ovid), Embase e Cochrane no dia 26 de outubro de 2021, conforme descrito anteriormente, para a questão 2</mark> ( **Quadro E** ). Com a utilização do filtro de data, as potenciais publicações posteriores a <mark>27 de janeiro de 2016 foram</mark> recuperadas.  
<mark>Após a busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra, foi realizada de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: <mark>Pacientes adultos, com MM, recidivado ou refratário.</mark>  
- (b) Tipo de intervenção: Bortezomibe em monoterapia, conforme previsto em bula.  
- (c) Tipo de comparador: Esquemas terapêuticos usuais disponíveis no SUS.  
- (d) Desfechos: <mark>SG, SLP, TRC, EA graus 3 e 4, neuropatia periférica graus 3 e 4, s</mark> uspensão <mark>devido a EA e qualidade de</mark>  
<mark>vida.</mark>  
- <mark>(e) Tipos de estudo: ECRs.</mark>  
- (f) Idioma e data de publicação: <mark>Sem restrição.</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Resultados da busca</u> -->
Como a bula do bortezomibe para pacientes em recidiva ou doença refratária prevê seu uso em monoterapia, apenas o estudo APEX<sup>44</sup> atende aos critérios de elegibilidade e foi incluído pela revisão publicada por Scott et al. (2016)<sup>20</sup> .  
A atualização da RS não identificou nenhum ECR adicional ( **Figura R** ). O único estudo avaliado na íntegra foi excluído, pois o braço intervenção consistiu de bortezomibe associado à dexametasona<sup>45</sup> ( **Tabela F** ).  
**Figura R -** Fluxograma de seleção dos estudos (ensaios clínicos randomizados).  
<!-- Start of picture text -->
fevisaoScottEstudoset al.publicada;incluldas2016(n napor= 1) Registros‘MediineCochraneEmbase identifica (via(n(n= Ovi =1229) 1097) d )os (n de: = 269) sR el egao:atosDuplicatas855) excluidosremovidas antes da(n =<br>Relatos analisados Relatos excluidos<br>(n= 1740) (n= 1739)<br>Relatos selecionados para Relatos nao recuperados<br>recuperagao (n = 1) (n=0)<br>Relatos avaliados quanto a Relatos excluldos¢ (n = 1) -<br>sigblidade (a= 1)<br>Novos estudos incluidos na<br>revisao (n = 0)<br>Total de estudos incluidos na<br>revisdo (n = 1)<br><!-- End of picture text -->  
**Tabela F -** Caracterização do ensaio clínico randomizado (n = 1).  
|**Estudo**|**Autor, ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|APEX|Richardson<br>et al. 2005|ECR fase III,<br>multicêntrico,<br>aberto|Pacientes com MM<br>com progressão da<br>doença após um a três<br>tratamentos prévios,<br>não tratados<br>previamente com<br>bortezomibe|V (V 1,3 mg/m<sup>2</sup>IV nos<br>dias 1, 4, 8, 11 dos<br>ciclos 1 a 8 (ciclo a cada<br>28 dias) e nos dias 1, 8,<br>15, 22 dos ciclos 9 a 11<br>(ciclo a cada 35 dias).<br>N = 333<br>Homens, N (%) = 188<br>(56)<br>Idade em anos, mediana<br>(intervalo) = 62 (48-74)<br>ISS, N (%) = NR<br>Alterações genéticas de<br>alto risco, N (%) = NR|D (D 40 mg VO nos<br>dias 1-4, 9-12, 17-20<br>dos ciclos 1 ao 4 (ciclo a<br>cada 35 dias) e dias 1-4<br>dos ciclos 5 ao 9 (ciclo a<br>cada 28 dias)).<br>N = 336<br>Homens, N (%) = 200<br>(60)<br>Idade em anos, mediana<br>(intervalo) = 61 (47-73)<br>ISS, N (%) = NR<br>Alterações genéticas de<br>alto risco, N (%) = NR|**SG**<br>Peto OR: 0,49 (IC de 95%<br>0,35 a 0,69)<br>**SLP**<br>Peto OR: 0,44 (IC de 95%<br>0,29 a 0,66)<br>**TRC**<br>OR: 14,53 (IC de 95% 3,42<br>a 61,65)<br>**EA graus 3 e 4**<br>OR: 2,02 (IC de 95% 1,45 a<br>2,82)<br>**NP graus 3 e 4**<br>OR: 14,07 (IC de 95% 3,31<br>a 59,76)<br>**DEA**<br>OR: 1,42 (IC de 95% 1,02 a<br>1,96)|Millennium<br>Pharmaceuticals|  
|**Estudo**|**Autor, ano**|**Desenho**|**População**|**Intervenção**|**Comparador**|**Desfechos**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|||||||**QV**<br>Diferença significativa nos<br>escores de QV avaliados<br>pelas ferramentas EORTC<br>QLQ-C30 e FACT/GOG-<br>NTX (p < 0.05), melhor QV<br>nos pacientes tratados com<br>bortezomibe||  
<mark>Legenda: D (dexametasona), DEA (s</mark> uspensã <mark>o devido a eventos adversos), EA (evento adverso), ECR (ensaio clínico randomizado), ISS (Sistema Internacional de Estadiamento), IV (intravenoso), MM (mieloma múltiplo), N (número de</mark>  
<mark>participantes), NP (neuropatia periférica), NR (não relatado), QV (qualidade de vida), SG (sobrevida global), SLP (sobrevida livre de progressão), TRC (taxa de resposta completa), V (bortezomibe), VO (via oral).</mark>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>Análise e apresentação dos resultados</u> -->
A avaliação do risco de viés do estudo APEX<sup>44</sup> foi realizada previamente por Scott et al _._ (2016)<sup>20</sup> utilizando a ferramenta RoB 1.0<sup>25</sup> . Os julgamentos do risco de viés foram avaliados e adotados nestas Diretrizes. Os resultados foram apresentados por desfecho, com estimativas do Peto OR e OR, com respectivos IC de 95%.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
O ECR APEX<sup>44</sup> , incluído na RS de Scott et al. (2016)<sup>20</sup> , incluiu esquema terapêutico previsto em bula e foi avaliado para tomada de decisão. Os resultados deste estudo foram apresentados de acordo com os desfechos avaliados ( **Tabela 5** ). O risco de viés do estudo APEX foi alto para o domínio “cegamento do paciente e dos profissionais” pois se trata de um ECR aberto; baixo, para os domínios “geração da sequência de randomização”, “cegamento de avaliadores de desfecho” (SG e outros desfechos), <mark>“desfechos incompletos” e “relato de desfecho seletivo”; e</mark> foi não claro para os domínios “ocultação da alocação” e “outras fontes de vieses”.  
Para o desfecho **SG** em 12 meses, o estudo APEX mostrou uma superioridade para o bortezomibe em relação à dexametasona (Peto OR 0,49, IC de 95% 0,35 a 0,69).  
Para **SLP** em 12 meses, o estudo APEX mostrou uma superioridade para o bortezomibe em relação à dexametasona (Peto OR 0,44, IC de 95% 0,29 a 0,66).  
Para o desfecho **resposta completa** , o estudo APEX mostrou uma superioridade para o bortezomibe em relação à dexametasona (OR = 14,53, IC de 95% 3,42 a 61,65).  
Para o desfecho **EA graus 3 e 4** , o estudo APEX mostrou que pacientes em uso de bortezomibe têm uma maior chance de desenvolver EA graus 3 e 4 do que aqueles tratados com dexametasona (OR = 2,02, IC de 95% 1,45 a 2,82).  
Para **neuropatia periférica graus 3 e 4** , os pacientes em uso de bortezomibe têm uma maior chance de apresentar neuropatia periférica graus 3 e 4 em relação àqueles tratados com dexametasona (OR = 14,07, IC de 95% = 3,31 a 59,76).  
Para o **desfecho suspensão devido a EA** , o estudo APEX mostrou que pacientes em uso de bortezomibe têm uma maior chance de suspensão de tratamento do que aqueles tratados com dexametasona (OR 1,42, IC de 95% 1,02 a 1,96).  
O estudo APEX apresentou resultados de qualidade de vida relacionada à saúde que foi mensurada usando os instrumentos _European Organisation for Research and Treatment of Cancer_ (EORTC) _Quality of Life Questionnaire – Core_ (QLQ-C30) e _Functional Assessment of Cancer Therapy/Gynecologic Oncology Group–Neurotoxicity_ (FACT/GOG-NTX). Os questionários foram aplicados antes do início do tratamento e a cada seis semanas até completar 42 semanas. Os pacientes que receberam bortezomibe apresentaram pontuações médias de saúde global do EORTC QLQ-C30 significativamente superior do que aqueles que receberam dexametasona, além de melhores pontuações nos domínios de saúde física, de função, cognição, funcionamento emocional, menor dispneia e sintomas relacionados ao sono. Além disso, também apresentaram melhores pontuações no questionário FACT/GOG-NTX. Estes resultados mostram que o bortezomibe está associado com uma qualidade de vida melhor comparado à dexametasona, corroborando os melhores resultados clínicos vistos com o uso de bortezomibe<sup>46</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Justificativa para a recomendação:** -->
O painel de especialistas considerou que os efeitos desejáveis são grandes e que os eventos adversos podem estar superestimados, pois o estudo clínico contemplado não reflete a posologia e a via de administração utilizadas na prática clínica atual (administração semanal por via subcutânea).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Considerações gerais e para implementação:** -->
O bortezomibe para o tratamento de pacientes adultos com MM, com doença refratária ou em recidiva, previamente tratados, no âmbito do Sistema Único de Saúde, foi incorporado por meio da Portaria SCTIE/MS nº 44, publicada em 28 de  
setembro de 2020<sup>47</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
A **Tabela G** apresenta a avaliação da certeza da evidência (GRADE) para os desfechos SG, SLP, TRC, EA graus 3 e 4,  
neuropatia periférica graus 3 e 4, suspensão do tratamento devido a EA e qualidade de vida relacionada à saúde.  
**Tabela G -** Certeza da evidência (GRADE) para os desfechos sobrevida global, sobrevida livre de progressão, taxa de resposta completa, eventos adversos graus 3 e 4, neuropatia periférica graus 3 e 4, suspensão do tratamento devido a eventos adversos e qualidade de vida relacionada à saúde (estudo APEX, bortezomibe _versus_ dexametasona).  
|**Avaliaç**|**ão da certeza**||||||**№ de pacientes**||**Efeito**|**Certeza**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**Sobrevi**|<br>**Delineamento**<br>**do estudo**<br>**da Global (segui**|**Risco**<br>**de viés**<br>**mento: 12**|**Inconsistência**<br>**meses)**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Esquema**<br>**COM**<br>**bortezomibe**|**Esquema SEM**<br>**bortezomibe**|**Relativo**<br>**(IC 95%)**|**geral**<br>**da**<br>**evidência**|<br>**Importância**|
|1<br>**Sobrevi**<br>1<br>**Taxa de**|Ensaio clínico<br>randomizado<br>**da Livre de Prog**<br>Ensaio clínico<br>randomizado<br>**Resposta Compl**|não<br>grave<br>**ressão (s**<br>não<br>grave<br>**eta (segu**|não grave<br>**eguimento: 12 m**<br>não grave<br>**imento: median**|não grave<br>**eses)**<br>não grave<br>**a 22 meses)**|não grave<br>não grave|nenhum<br>nenhum|66/333 (19,8%)<br>263/333<br>(79,0%)|114/336<br>(33,9%)<br>302/336<br>(89,9%)|**Peto OR**<br>**0,49**<br>(0,35 para<br>0,69)<br>**Peto OR**<br>**0,44**<br>(0,29 para<br>0,66)|⨁⨁⨁⨁<br>Alta<br>⨁⨁⨁⨁<br>Alta|CRÍTICO<br>CRÍTICO|
|1|Ensaio clínico<br>randomizado|não<br>grave|não grave|não grave|muito<br>grave<sup>a</sup>|nenhum|27/315 (8,6%)|2/312<br>(0,6%)|**OR 14,53**<br>(3,42 para<br>|⨁⨁◯◯<br>Baixa|IMPORTANTE|
|**Eventos**|**Adversos Graus**|**3 e 4 (se**|**guimento: media**|**na 8,3 mese**|**s)**||||61,65)|||
|1|Ensaio clínico|grave<sup>b,c</sup>|não grave|não grave|não grave|nenhum|248/331|198/332|**OR 2,02**|⨁⨁⨁◯|IMPORTANTE|  
|**Avaliaçã**|**o da certeza**||||||**№ de pacientes**||**Efeito**|**Certeza**||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Esquema**<br>**COM**<br>**bortezomibe**|**Esquema SEM**<br>**bortezomibe**|**Relativo**<br>**(IC 95%)**|**geral**<br>**da**<br>**evidência**|<br>**Importância**|
|**Neuropa**|randomizado<br>**tia Periférica Gr**<br>Ensaio clínico|**aus 3 e 4**|**(seguimento: m**|**ediana 8,3 m**|**eses)**<br>muito||(74,9%)|(59,6%)|(1,45 para<br>2,82)<br>**OR 14,07**|Moderada<br>⨁◯◯◯||
|1<br>**Suspens**|<br>randomizado<br>**ão do tratamento**<br>|grave<sup>b,c</sup><br>**devido a**|não grave<br>**Eventos Adver**|não grave<br>**sos (seguime**|<br>grave<sup>a</sup><br>**nto: mediana**|nenhum<br>**8,3 meses)**|26/331 (7,9%)<br>|2/332 (0,6%)|(3,31 para<br>59,76)<br>**OR 1,42**|Muito<br>baixa<br>|IMPORTANTE|
||Ensaio clínico||||||121/331|||⨁⨁⨁||
|1<br>**Qualida**<br>1|randomizado<br>**de de Vida relaci**<br>Ensaios<br>clínicos<br>randomizados|grave<sup>b,c</sup><br>**onada à**<br>grave<sup>b,c</sup>|não grave<br>**Saúde (seguimen**<br>não grave|não grave<br>**to: 42 sema**<br>não grave|não grave<br>**nas)**<br>não grave|nenhum<br>nenhum|(36,6%)<br>A qualidade de<br>mensurada usan<br>_Organisation fo_<br>_Cancer_<br>_(EOR_<br>_Questionnaire –_<br>_Assessment of_<br>_Oncology Group_|96/332 (28,9%)<br>vida relacionada<br>do os instrumento<br>_r Research and T_<br>_TC)_<br>_Quality_<br>_Core_(QLQ-C30) e<br>_Cancer Therapy/G_<br>_–Neurotoxicity_(F|(1,02 para<br>1,96)<br>à saúde foi<br>s_European_<br>_reatment of_<br>_of_<br>_Life_<br> _Functional_<br>_ynecologic_<br>ACT/GOG-|Moderada<br>⨁⨁⨁◯<br>Moderada|IMPORTANTE<br>IMPORTANTE|  
|**Avaliaçã**|**o da certeza**<br>||||||**№ de pacientes**<br>**Efeito**<br>**Esquema**<br> <br>|**Certeza**<br>**eral**<br>**da**|**Imortância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|<br>**COM**<br>**bortezomibe**<br>**Esquema SEM**<br>**bortezomibe**<br>**Relativo**<br>**(IC 95%)**|**g**<br> <br>**evidência**|**p**|
||||||||NTX). Os questionários foram aplicados antes<br>do início do tratamento e a cada seis semanas<br>até completar 42 semanas. Os pacientes que<br>receberam<br>bortezomibe<br>apresentaram<br>pontuações médias de saúde global do EORTC<br>QLQ-C30 significativamente superior do que<br>aqueles que receberam dexametasona, além de<br>melhores pontuações nos domínios de saúde<br>física, de função, cognição, funcionamento<br>emocional,<br>menor<br>dispneia<br>e<br>sintomas<br>relacionados ao sono. Ademais, também<br>apresentaram<br>melhores<br>pontuações<br>no<br>questionário<br>FACT/GOG-NTX.<br>Estes<br>resultados mostram que o bortezomibe está<br>associado com uma qualidade de vida melhor<br>comparado à dexametasona, corroborando os<br>melhores resultados clínicos vistos com o uso<br>de bortezomibe.|||  
Legenda: EORTC _(European Organisation for Research and Treatment of Cancer_ ); FACT/GOG-NTX ( _Functional Assessment of Cancer Therapy/Gynecologic Oncology Group–Neurotoxicity_ ), QLQ-C30 ( _Quality of Life Questionnaire – Core); OR (odds ratio_ ).  
Explicações: a. Intervalo de confiança amplo, rebaixado dois graus de evidência; b. Não é possível afirmar que houve sigilo na alocação dos participantes; c. Não houve cegamento, ensaio clínico randomizado aberto <mark>Referências: Richardson et al. 2005</mark><sup>44</sup> <mark>, L</mark> ee et al. 2008<sup>46</sup>  
**Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):**  
O **Quadro Q** apresenta o processo de tomada de decisão sobre o uso de bortezomibe em monoterapia para o tratamento MM recidivado ou refratário baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
**Quadro Q -** Processo de tomada de decisão referente ao uso de bortezomibe para o tratamento do mieloma múltiplo recidivado ou refratário.  
|**Item da EtD**|**Julgamento dos painelistas**|**Justificativa**|
|---|---|---|
|**Benefícios**|Grande|A maioria dos painelistas julgou que os efeitos desejáveis são<br>substanciais, com aumento da SLP, SG e da TRC.|
|**Riscos**|Grande|Os efeitos indesejáveis podem estar superestimados, pois os<br>estudos clínicos contemplados não refletem a posologia e a via de<br>administração utilizadas na prática clínica atual - administração<br>semanal, por via subcutânea.|
|**Balanço dos riscos e**<br>**benefícios**|Favorece a intervenção|O painel entende que o balanço é favorável à intervenção.|
|||Atualmente, o bortezomibe é utilizado em combinação com|
|**Certeza da evidência**|Alta|outros medicamentos. A avaliação considerou o estudo pivotal,<br>com a utilização do bortezomibe por via intravenosa.|
|**Custos**|Moderado|-|
|**Outras considerações**|Preferencialmente, devem s<br>|er utilizados esquemas terapêuticos baseados em bortezomibe em<br>|  
Preferencialmente, devem ser utilizados esquemas terapêuticos baseados em bortezomibe em combinação com outros medicamentos.  
Fonte: Autoria própria.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **QUESTÃO 5: Devemos utilizar lenalidomida versus talidomida para pacientes com mieloma múltiplo, durante a manutenção?** -->
**<u>Recomendação 5:</u>** <mark>Por não ter sido incorporada no âmbito do SUS para o tratamento de MM, estas Diretrizes não preconizam o uso desta tecnologia. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.</mark>  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos com MM, submetidos ao TCTH, em terapia de manutenção.  
**Intervenção:** Lenalidomida.  
**Comparador:** Talidomida.  
**Desfechos:** SG, SLP, EA, EA graus 3 e 4 (alterações hematológicas, cardiovasculares, gastrointestinais, musculoesqueléticas, neurológicas, do sistema reprodutivo, pele e subcutâneo, infecções), EA neurológicos, suspensão devido a EA.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca:** -->
Para responder essa pergunta, foram utilizadas as referências de cinco ECRs e síntese de evidências apresentadas no Relatório de Recomendação nº 700/2022<sup>48</sup> , relativo à proposta de incorporação da lenalidomida para terapia de manutenção em pacientes com MM submetidos ao TCTH.  
A seleção das evidências foi realizada em duas etapas:  
**Etapa 1** : foram selecionadas RSMA de ECR que avaliaram o efeito da lenalidomida comparada à talidomida em pacientes com MM, elegíveis ao TCTH, em terapia de manutenção.  
**Etapa 2** : foi realizada a seleção dos ECR, publicados a partir da RS publicada por Gay et al. 2018<sup>49</sup> , selecionada para atualização.  
<mark>Nas duas etapas, após a busca nas bases de dados, a exclusão das duplicatas e seleção dos estudos foram realizadas por meio do</mark> _<mark>software</mark>_ <mark>Rayyan</mark><sup>®</sup> <mark>. A seleção por títulos e resumos, bem como após leitura na íntegra, foi realizada de forma independente por dois pesquisadores. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por consenso.</mark>  
Na **etapa 1** , a avaliação da qualidade metodológica das RS foi realizada utilizando a ferramenta AMSTAR 2.0<sup>3</sup> . As duas RS selecionadas<sup>49,50</sup> , foram avaliadas quanto à qualidade metodológica com a ferramenta AMSTAR 2.0<sup>3</sup> e os ECR incluídos foram mapeados. Apesar das duas RS possuírem falhas metodológicas em domínios críticos, a RS publicada por Gay et al. 2018<sup>49</sup> foi selecionada para atualização devido à amplitude e a reprodutibilidade da busca realizada.  
Na **etapa 2** , a busca realizada não identificou ECR adicionais, mantendo os cinco ECR incluídos na RS publicada por Gay et al. 2018<sup>49</sup> , denominados MYELOMA IX<sup>51,52</sup> , CALGB 100104<sup>53–55</sup> , IFM 2005-02<sup>55,56</sup> , RV-MM-PI-209<sup>55,57</sup> e MYELOMA XI<sup>58</sup> . Foram identificadas duas novas publicações dos estudos incluídos na RS, republicação dos dados do estudo CALGB 100104<sup>59</sup> e do MYELOMA XI<sup>60</sup> , totalizando cinco ECR (MYELOMA IX, CALGB 100104, IFM 2005-02, RV-MM-PI-209, MYELOMA XI) e 10 publicações<sup>51–60</sup> . Os ECR foram avaliados quanto ao risco de viés, com a ferramenta RoB 2.0<sup>4</sup> . Todos os ECR foram classificados como baixo risco de viés para os desfechos SG, SLP, EA graus 3 e 4 e EA neurológicos. A comparação entre lenalidomida e talidomida foi realizada considerando apenas evidência indireta, sendo placebo/observação o comparador comum. A descrição <mark>detalhada dos métodos e resultados da busca está disponível no Relatório de R</mark> ecomendação nº 700, de fevereiro de 2022<sup>48</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
<mark>Para a</mark> **<mark>SG</mark>** <mark>, a estimativa de efeito da comparação indireta entre lenalidomida e talidomida (HR: 0,58; IC de 95%: 0,30 a 1,11) não mostrou diferença entre as duas tecnologias para o desfecho SG (</mark> **<mark>F</mark> igura** **<mark>S</mark>** <mark>). Segundo o ranqueamento realizado para este desfecho (</mark> **<mark>Q</mark> uadro R** <mark>), a lenalidomida foi considerada o tratamento com maior benefício para SG, seguida da talidomida.</mark>  
**Figura S -** Gráfico de floresta referente ao desfecho da sobrevida global.  
<!-- Start of picture text -->
Comparacao HazardRatio HR IC 95% daevidénciaQualidade<br>Lenalidomida x Placebo 0.75 [0.55; 1.01] | Moderada<br>Talidomida x Placebo 1.29 [0.83;2.00] Moderada<br>Lenalidomida x Talidomida 0.58 [0.30:1.11] — Baixa<br>02 0751 15<br><!-- End of picture text -->  
Nota: Utilizada a medida da meta-análise em pares nas comparações com placebo e da análise em rede na comparação de lenalidomida e talidomida.  
**Quadro R -** Ranqueamento dos tratamentos quanto ao desfecho sobrevida global, de acordo com as estimativas obtidas na meta-análise em rede.  
|**Rank**|**Tratamentos**|**p-score**<br>**(efeitos randômicos)**|
|---|---|---|
|1|Lenalidomida|0,96|
|2|Talidomida|0,42|
|3|Placebo|0,12|  
<mark>Em relação à</mark> **<mark>SL</mark> P** , o resultado da meta-análise foi favorável à lenalidomida, indicando que esta é 36% superior à talidomida (HR: 0,64; IC de 95%: 0,48 a 0,86), com qualidade da evidência moderada ( **Figura T** ). Em relação à SLP, o ranqueamento ( **Quadro S** ) também mostrou superioridade da lenalidomida em relação à talidomida.  
**Figura T -** Gráfico de floresta referentes ao desfecho da sobrevida livre de progressão.  
<!-- Start of picture text -->
Comparagao HazardRatio HR IC 95% daevidénciaQualidade<br>Lenalidomida x Placebo = =——=—— 0.48 [0.41; 0.56] Alta<br>Talidomida x Placebo —i—_- 0.74 [0.60; 0.91] Alta<br>Lenalidomida x Talidomida —s —— 0.64 [0.48;0.86] Moderada<br>04 09114<br><!-- End of picture text -->  
Nota: Utilizada a medida da meta-análise em pares nas comparações com placebo e da análise em rede na comparação de lenalidomida e talidomida.  
**Quadro S -** Ranqueamento dos tratamentos quanto ao desfecho sobrevida livre de progressão, de acordo com as estimativas obtidas na meta-análise em rede.  
|**Rank**|**Tratamentos**|**p-score**<br>**(efeitos randômicos)**|
|---|---|---|
|1|Lenalidomida|0,99|
|2|Talidomida|0,49|
|3|Placebo|0,00|  
A **Figura U** mostra que não houve diferença na ocorrência de EA graus 3 e 4 <mark>entre a lenalidomida e a talidomida (RR: 0,75; IC de 95%: 0,20 a 2,86). Quanto à avaliação do ranqueamento da rede, houve superioridade de lenalidomida, seguida de talidomida (</mark> **<mark>Q</mark> uadro T** ).  
**Figura U -** Gráfico de floresta referentes ao desfecho de eventos adversos graus 3 e 4.  
<!-- Start of picture text -->
Risco Qualidade<br>Comparacgao Relativo RR IC95% _ daevidéncia<br>Lenalidomida x Placebo —_a—_ 2.28 [1.18; 4.41] Alta<br>Talidomida x Placebo ——— 3.01 [1.30; 6.96] Alta<br>Lenalidomida x Talidomida 0.75 [0.20; 2.86] Baixa<br>04 1 2 7<br><!-- End of picture text -->  
Nota: Utilizada a medida da meta-análise em pares nas comparações com placebo e da análise em rede na comparação de lenalidomida e talidomida.  
**Quadro T -** Ranqueamento dos tratamentos quanto ao desfecho eventos adversos graus 3 e 4, de acordo com as estimativas obtidas na meta-análise em rede.  
|**Rank**|**Tratamentos**|**p-score**<br>**(efeitos randômicos)**|
|---|---|---|
|1|Placebo|0,99|
|2|Lenalidomida|0,50|
|3|Talidomida|0,00|  
<mark>Quanto aos</mark> **<mark>EA neurológicos,</mark>** <mark>incluindo a neuropatia periférica, a estimativa de efeito indireta também se apres</mark> entou inconclusiva quanto à superioridade da lenalidomida (RR: 0,33; IC de 95%: 0,73 a 3,11) ( **Figura V** ).  
Por fim, em relação aos EA neurológicos, o ranqueamento ( **Quadro U** ) evidenciou superioridade da lenalidomida em relação à talidomida.  
**Figura V -** Gráfico de floresta referentes ao desfecho de eventos adversos neurológicos.  
<!-- Start of picture text -->
Risco Qualidade<br>Comparacao Relativo RR IC 95% daevidéncia<br>Lenalidomida x Placebo 1.97 [0.89; 4.35] Moderada<br>Talidomida x Placebo 6.02 [0.73; 49.67] Baixa<br>Lenalidomida x Talidomida 0.33 [0.03; 3.11] Baixa<br>0102 05 1 2 5 10<br><!-- End of picture text -->  
Nota: Utilizada a medida da meta-análise em pares nas comparações com placebo e da análise em rede na comparação de lenalidomida e talidomida.  
**Quadro U -** Ranqueamento dos tratamentos quanto ao desfecho de eventos neurológicos, de acordo com as estimativas obtidas na meta-análise em rede.  
|**Rank**|**Tratamentos**|**p-score**<br>**(efeitos randômicos)**|
|---|---|---|
|1|Placebo|0,95|
|2|Lenalidomida|0,44|
|3|Talidomida|0,11|  
<mark>Não foi possível realizar meta-análise em rede que comparasse a lenalidomida e a talidomida quanto à suspensão</mark> por EA. O único estudo encontrado contendo a talidomida em um dos braços, MYELOMA IX<sup>51,52</sup> , utilizou desenho fatorial dividido em duas fases. Na primeira fase, os pacientes foram randomizados entre terapia de indução intensiva (com TCTH) e terapia de indução não-intensiva (sem TCTH). Na segunda fase, ambos os grupos foram randomizados para receber manutenção ou não com talidomida. Assim, a taxa de suspensão apresentada pelo estudo (52,2%) não diz respeito somente aos pacientes em terapia de manutenção pós TCTH<sup>51,52</sup> .  
Em consenso do _International Myeloma Working Group_ (IMWG) sobre terapia de manutenção no MM<sup>61</sup> , foi apresentada uma tabela descritiva com seis ECRs que avaliaram a taxa de suspensão devido a EA, em que a talidomida pós-TCTH configurava em um dos braços da comparação. Na referida revisão, a taxa de suspensão da talidomida variou entre 30% e 80%, incluindo a taxa apresentada pelo estudo MYELOMA IX<sup>51,52</sup> . Este mesmo consenso apresentou também uma tabela descritiva com três ECR que utilizaram a lenalidomida em um dos braços e a taxa de suspensão por EA no grupo de pacientes que receberam lenalidomida variou entre 12% e 21%<sup>61</sup> .  
<mark>A recomendação da Conitec foi desfavorável à incorporação</mark> da lenalidomida para terapia de manutenção em pacientes com MM submetidos ao TCTH<sup>48</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
A avaliação da qualidade da evidência foi realizada a partir dos dados obtidos na meta-análise em rede deste parecer para os desfechos SG, SLP, EA graus 3 e 4 e EA neurológicos. A **Tabela H** contém as estimativas e avaliação da qualidade das evidências diretas, indiretas e da rede, e as justificativas para cada avaliação. A certeza da evidência foi considerada moderada para o desfecho SLP e, para os desfechos SG, EA graus 3 e 4 e EA neurológicos foi julgada baixa.  
**Tabela H -** Avaliação da qualidade da evidência da comparação entre lenalidomida e talidomida para os desfechos sobrevida global, sobrevida livre de progressão, eventos adversos graus 3 e 4, eventos adversos neurológicos.  
|**Intervençã**<br>|**Intervençã**<br>|**Efe**|**Estimativ**<br>**ito relativ**<br>**IC**|**a direta**<br>**o**<br>**IC**|**GRAD**|<br>**Efe**|**Estimativa**<br>**ito relativ**|**indireta**<br>**o**<br>**IC**|**GRAD**|**Estimati**<br>**Efe**|**va da met**<br>**ito relativ**<br>**IC**|**a-análise e**<br>**o**<br>**IC**|**m rede**<br>**GRAD**|**Justificativa**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**o 1**|**o 2**|**Estimativ**||||**Estimativ**|**IC**|||**Estimativ**|||||
|||**a de efeito**|**inferio**|**superio**|**E**|**a de efeito**|<br>**inferior**|**superi**|**E**|**a de efeito**|**inferio**|**superio**|**E**||
|**Lenalidomid**<br>**a**|Placebo|HR 0,75|**r**<br>0,55|**r**<br>1,01|Moderada|**Sobre**<br>NA|**vida Glob**<br>NA|**or**<br>**al**<br>NA|NA|HR 0,75|**r**<br>0,55|**r**<br>1,01|Moderada|<br>Imprecisão|
|**Talidomida**|Placebo|HR 1,29|0,83|1,99|Moderada|NA|NA|NA|NA|HR 1,29|0,72|2,31|Moderada|<br>Imprecisão|
|**Lenalidomid**<br>**a**<br>**Lenalidomid**<br>**a**|**Talidomida**<br>Placebo|**NA**<br>HR 0,47|**NA**<br>0,41|**NA**<br>0,55|**NA**<br>Alta|**HR 0,58**<br>**Sobrevida l**<br>NA|**0,30**<br>**ivre de pro**<br>NA|**1,11**<br>**gressão**<br>NA|**Baixa**<br>NA|**HR 0,58**<br>HR 0,47|**0,30**<br>0,40|**1,11**<br>0,54|**Baixa**<br>Alta|**Imprecisão e**<br>**intransitividad**<br>**e**|
|**Talidomida**|Placebo|HR 0,74|0,6|0,9|Alta|NA|NA|NA|NA|HR 0,74|0,57|0,95|Alta||
|**Lenalidomid**|**Talidomida**|**NA**|**NA**|**NA**|**NA**|**HR 0,64**|**0,48**|**0,86**|**Moderad**|**HR 0,64**|**0,48**|**0,86**|**Moderad**|**Intransitividad**|
|**a**<br>**Lenalidomid**<br>**a**|Placebo|RR 2,28|1,18|4,41|Alta|**Eventos ad**<br>NA|**versos gra**<br>NA|**us 3 e 4**<br>NA|**a**<br>NA|RR 2,27|1,21|4,26|**a**<br>Alta|**e**|
|**Talidomida**|Placebo|RR 3,01|1,3|6,96|Alta|NA|NA|NA|NA|RR 3,01|0,93|9,78|Moderada|<br>Imprecisão|
|**Lenalidomid**|**Talidomida**|**NA**|**NA**|**NA**|**NA**|**RR 0,75**|**0,20**|**2,86**|**Baixa**|**RR 0,75**|**0,20**|**2,86**|**Baixa**|**Imprecisão e**|  
||||**Estimativ**|**a direta**|||**Estimativa**|**indireta**||**Estimati**|**va da met**|**a-análise e**|**m rede**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Intervençã**|**Intervençã**|**Efe**|**ito relativ**<br>|**o**<br>|**GRAD**|**Efe**|**ito relativo**|<br>|**GRAD**|**Efe**|**ito relativ**<br>|**o**<br>|**GRAD**|**Justificativa**|
||||**IC**|**IC**||||**IC**|||**IC**|**IC**|||
|**o 1**|**o 2**|**Estimativ**<br>**a de efeito**|**inferio**<br>**r**|**superio**<br>**r**|**E**|**Estimativ**<br>**a de efeito**|**IC**<br>**inferior**|**superi**<br>**or**|**E**|**Estimativ**<br>**a de efeito**|**inferio**<br>**r**|**superio**<br>**r**|**E**||
|**a**||||||**Eventos adv**|**ersos neur**|**ológicos**||||||**intransitividad**<br>**e**|
|**Lenalidomid**<br>**a**|Placebo|RR 1,97|0,89|4,35|Moderada|NA|NA|NA|NA|RR 1,97|0,89|4,35|Moderada|<br>Imprecisão|
|**Talidomida**|Placebo|RR 6,02|0,73|49,67|Baixa|NA|NA|NA|NA|RR 6,02|0,73|49,67|Baixa|Imprecisão|
|**Lenalidomid**<br>**a**|**Talidomida**|**NA**|**NA**|**NA**|**NA**|**RR 0,33**|**0,03**|**3,11**|**Baixa**|**RR 0,33**|**0,03**|**3,11**|**Baixa**|**Imprecisão e**<br>**intransitividad**<br>**e**|  
Legenda: IC - intervalo de confiança; NA - não avaliado; HR - hazard ratio; RR: risco relativo.  
Notas: a. A certeza da evidência foi rebaixada em um nível, pois o intervalo de confiança da medida passa pelo efeito nulo. b. A certeza da evidência foi rebaixada um ponto devido às diferenças das populações do estudo quanto ao estadiamento da doença e protocolos de tratamento administrados antes da etapa de manutenção. c. A certeza da evidência foi rebaixada dois níveis, pois o intervalo de confiança da medida passa pelo efeito nulo e é amplo. Referências: Attal et al. 2012<sup>56</sup> , Jackson et al. 2017<sup>58</sup> , Jackson et al. 2021<sup>60</sup> , Morgan et al. 2012<sup>51</sup> , Morgan et al. 2013<sup>52</sup> , Holstein et al 2017<sup>53</sup> , McCarthy et al. 2012<sup>54</sup> , McCarthy et al. 2017<sup>55</sup> , McCarthy et al. 2018<sup>59</sup> , Palumbo et al. 2014<sup>57</sup>  
**<mark>QUESTÃO 6: D</mark> evemos utilizar esquemas com dois ou três medicamentos que incluam a lenalidomida** **_versus_ esquemas terapêuticos com dois ou três medicamentos contendo talidomida para o tratamento de pacientes com mieloma múltiplo inelegíveis ao TCTH?**  
**<u>Recomendação 6:</u>** <mark>Por não ter sido incorporada no âmbito do SUS para o tratamento de MM, estas Diretrizes não preconizam o uso desta tecnologia. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.</mark>  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos, com MM e inelegíveis ao TCTH.  
**Intervenção:** Esquemas com dois ou três medicamentos que incluem lenalidomida.  
**Comparador:** Esquemas com dois ou três medicamentos que incluem talidomida.  
**Desfechos:**  
<u>Eficácia: SG, SLP, qualidade de vida ou outros desfechos relatados pelos pacientes (</u> _patient related outcomes - PRO)._  
<u>Segurança:</u> EA: EA graves, polineuropatia, eventos neurológicos, eventos hematológicos, neutropenia, anemia, trombocitopenia, tromboembolismo, eventos cardiovasculares, eventos gastrointestinais e infecções (graus 3 e 4) e suspensão do tratamento por evento adverso.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca:** -->
Para responder essa pergunta, foram utilizadas as referências de cinco RS e síntese de evidências apresentadas no Relatório de Recomendação nº 701/2022<sup>62</sup> , relativo à proposta de incorporação da lenalidomida para tratamento de pacientes com MM inelegíveis ao TCTH.  
Foi realizada busca estruturada nas bases MEDLINE (via Pubmed), EMBASE, Cochrane Library, Epistemonikos e LILACS em 10 de agosto de 2021. A seleção dos estudos e a extração dos dados foram realizadas por dois pesquisadores independentes. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por meio do consenso. A estratégia de busca localizou 758 publicações e, ao final, foram selecionadas sete RS<sup>37–39,63–66</sup> que satisfizeram a pergunta de pesquisa, por meio de meta-análise em rede (indireta). A avaliação da qualidade metodológica dos estudos foi realizada com a ferramenta AMSTAR-2<sup>3</sup> . Os resultados foram sintetizados numa _Overview_ das RS selecionadas. A descrição detalhada dos métodos e resultados da busca estão no Relatório de Recomendação nº 701/2022<sup>62</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
<mark>Os resultados foram divididos em duas comparações principais: esquemas de dois medicamentos, RDc</mark> (lenalidomida e dexametasona até progressão da doença) _<mark>versus</mark>_ <mark>TDc (t</mark> alidomida e dexametasona até progressão da doença), <mark>e esquemas de três medicamentos, MPR-R (m</mark> elfalana, prednisona e lenalidomida, seguido de manutenção com lenalidomida <mark>)</mark> _<mark>versus</mark>_ <mark>MPT-T</mark> (melfalana, prednisona e talidomida, seguido de manutenção com talidomida). A síntese dos resultados foi baseada em cinco RSs<sup>37–39,64,65</sup> , as quais incluíram os esquemas descritos acima. A avaliação da qualidade metodológica das RS apontou entre duas e cinco falhas metodológicas nas RS. A revisão publicada por Piechotta et al. 2019<sup>38</sup> foi a única que não apresentou falhas críticas.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>RDc versus TDc (</u> **Tabela I** ) -->
Para **SG** , três RS<sup>38,39,64</sup> mostraram superioridade para o esquema RDc quando comparado ao TDc.  
Para **SLP,** houve divergência entre os resultados, uma RS<sup>38</sup> não apresentou diferença entre os esquemas, enquanto outras duas RS<sup>39,64</sup> mostraram superioridade ao esquema RDc quando comparado ao TDc.  
Na análise da **suspensão por EA** (DEA), uma RS<sup>38</sup> mostrou que não houve diferença entre os dois esquemas; outra RS<sup>39</sup>  
mostrou que pacientes tratados com RDc apresentam menor risco para **EA neurológicos** .  
<u><mark>MPR-R versus MPT-T (</mark></u> **<mark>Tabela I</mark>** <mark>)</mark>  
Os esquemas MPR-R e MPT-T foram comparados em relação à **SG** e **SLP** por três<sup>38,39,64</sup> e cinco RS<sup>37–39,64,65</sup> , respectivamente. Em nenhuma delas houve diferença entre os dois esquemas. Duas RS<sup>38,39</sup> apresentaram resultados de EA cujos achados apontaram que pacientes tratados com MPR-R apresentam menor risco para EA graves, como polineuropatia.  
**Tabela I -** Sobrevida global, sobrevida livre de progressão, eventos adversos neurológicos e suspensão por eventos adversos na comparação RDc versus TDc em pacientes inelegíveis ao transplante de células-tronco hematopoiéticas.  
|**Autor, ano**|**SG**<br>**HR**|**IC de 95%**|**SLP**<br>**HR**|**IC de 95%**|**EA Gra**<br>**RR**|**ves**<br>**IC de 95%**|**EA Neuro**<br>**RR**|**lógicos**<br>**IC de 95%**|**Suspensão**<br>**RR**|**por EA**<br>**IC de 95%**|
|---|---|---|---|---|---|---|---|---|---|---|
|Liu et al. 2017|0,32|0,20 a 0,52|0,32|0,13 a 0,76|-|-|-|-|-|-|
|Sekine et al. 2019|0,36|0,23 a 0,55|0,41|0,30 a 0,55|-|-|0,02|0,00 a 0,12|-|-|
|Piechotta et al. 2019|0,44|0,20 a 0,94|0,63|0,33 a 1,21|-|-|-|-|0,29|0,05 a 1,65|  
**Tabela I -** Sobrevida global, sobrevida livre de progressão, eventos adversos graves, eventos adversos neurológicos e suspensão por eventos adversos na comparação MPR-R versus MPT-T em pacientes inelegíveis ao transplante de células-tronco hematopoiéticas.  
|**Autor ano**|**SG**||**SLP**||**EA Grav**|**es**|**EA Neuro**|**lógicos**|**Suspensã**|**o por EA**|
|---|---|---|---|---|---|---|---|---|---|---|
|**,**|**HR**|**IC de 95%**|**HR**|**IC de 95%**|**RR**|**IC de 95%**|**RR**|**IC de 95%**|**RR**|**IC de 95%**|
|Liu et al. 2017|1,08|0,90 a 1,30|0,81|0,58 a 1,12|-|-|-|-|-|-|
|Sekine et al. 2019|0,91|0,75 a 1,10|0,95|0,81 a 1,09|-|-|-|-|-|-|
|Piechotta et al. 2019|0,89|0,66 a 1,21|0,90|0,70 a 1,15|0,79|0,67 a 0,93|0,13|0,05 a 0,32|0,79|0,50 a 1,24|
|Blommestein et al. 2019|-|-|0,83|0,63 a 1,10|-|-|-|-|-|-|
|Gil-Guerra et al. 2020|-|-|0,96|0,83 a 1,11|-|-|-|-|-|-|

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
Para avaliação da qualidade da evidência, foram utilizados os resultados publicados por Piechotta et al. 2019<sup>38</sup> , cujo  
estudo apresenta melhor qualidade metodológica, conforme descrito acima.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>RDc versus TDc</u> -->
A **Tabela J** apresenta os resultados da certeza da evidência (GRADE) da comparação entre RDc versus TDc para os desfechos SG, SLP, suspensão por EA. Para SG, a certeza da evidência foi considerada baixa e, para os desfechos, SLP e suspensão por EA, a qualidade da evidência foi julgada como muito baixa.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: <u>MPR-R versus MPT-T</u> -->
A **Tabela K** apresenta os resultados da avaliação da certeza da evidência (GRADE) da comparação entre MPR-R versus MPT-T para os desfechos SG, SLP, EA graves e suspensão por EA. Na SG, SLP e suspensão por EA, a certeza da evidência foi considerada baixa e, para o desfecho EA graves, a certeza da evidência foi considerada moderada.  
**Tabela J -** Avaliação da qualidade da evidência da comparação entre lenalidomida e dexametasona (RDc) versus talidomida e dexametasona (TDc) quanto aos desfechos sobrevida global, sobrevida livre de progressão, suspensão por eventos adversos*.  
|**#**|**Intervenção**|**Intervenão 2**|**Estima**<br>**Estim**|**tiva direta**<br>**tiva**<br>**de**||**Estimativa indireta**||**Estimativa da met**<br>**rede**|**a-análise em**|**Justificativa**|
|---|---|---|---|---|---|---|---|---|---|---|
||**1**|**ç**||<br>||**Eii**<br>**d**||**Eii**<br>**d**|||
||||**efeito**||**GRADE**|**stmatva**<br>**e**<br>**efeito [IC 95%]**|**GRADE**|**stmatva**<br>**e**<br>**efeito [IC 95%]**|**GRADE**||
||||**[IC 95**|**%]**|||||||
|**Sobrevi**|**da Global**||||||||||
||||HR|0,98[0,59-|||||||
|**1**|RDc|MPR-R|1,64]||Moderada|NA|NA|NA|NA|Imprecisão<sup>a</sup>|
|**2**|MPR-R|MPT-T|HR<br>1,33]|0,95[0,67-|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>b</sup>|
|3|MPT-T|MPc|HR<br>1,32]|0,92[0,66-|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>c</sup>|
|4|MPc|TDc|HR<br>1,11]|0,65[0,38-|Moderada|NA|NA|NA|NA|Imprecisão<sup>a</sup>|
|5|**RDc**|**TDc**|**NA**||**NA**|**HR**<br>**0,44**<br>**[0,20-**<br>**0,97]**|**Baixa**|**HR**<br>**0,44**<br>**[0,20-**<br>**0,97]**|**Baixa**|**Risco de viés**<sup>**b,c**</sup><br>**Intransitividade**<br>**d**|
|**Sobrevi**|**da livre de progr**|**essão**|||||||||
||||HR|1,24[0,83-|||||||
|**1**|RDc|MPR-R|1,86]||Moderada|NA|NA|NA|NA|Imprecisão<sup>a</sup>|
|**2**|MPR-R|MPT-T|HR 1,0|[0,76-1,32]|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>b</sup>|
|**3**|MPT-T|MPc|HR<br>1,11]|0,84[0,63-|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>c</sup>|
|**4**|MPc|TDc|HR|0,77[0,49-|Moderada|NA|NA|NA|NA|Imprecisão<sup>a</sup>|  
|5<br>**Suspe**|**RDc**<br>**nsão por evento**|**TDc**<br>**adverso**|1,21]<br>**NA**<br>RR<br>2,11<br>[1,20-|**NA**|**HR**<br>**0,63**<br>**[0,33-**<br>**1,21]**|**Muito**<br>**baixa**|**HR**<br>**0,63**<br>**[0,33-**<br>**1,21]**|**Muito**<br>**baixa**|**Imprecisão**<sup>**a**</sup><br>**Risco de viés**<sup>**b,c**</sup><br>**Intransitividade**<br>**d**<br>|
|---|---|---|---|---|---|---|---|---|---|
|**1**|RDc|MPR-R|<br><br>3,70]|Moderada|NA|NA|NA|NA|Risco de viés<sup>f</sup>|
|**2**|MPR-R|MPT-T|RR<br>0,85<br>[0,52-<br>1,39]|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>g</sup>|
|**3**|MPT-T|MPc|RR<br>3,45<br>[2,08-<br>5,56]|Moderada|NA|NA|NA|NA|Risco de viés<sup>c</sup>|
|**4**|MPc|TDc|RR 0,76[0,16-3,45]|Baixa|NA|NA|NA|NA|Imprecisão<sup>a</sup><br>Risco de viés<sup>b</sup>|
|**5**|**RDc**|**TDc**|**NA**|**NA**|**RR 3,44**<br>**[0,61-20]**|**Muito**<br>**baixa**|**RR 3,44**<br>**[0,61-20]**|**Muito**<br>**baixa**|**Imprecisão**<sup>**e**</sup><br>**Risco de viés**<sup>**b,c**</sup><br>**Intransitividade**<br>**d**|  
*A comparação de interesse está sinalizada em negrito. As demais comparações contribuem para a medida da comparação de interesse.  
Legenda: IC - intervalo de confiança; NA - não avaliado; HR - hazard ratio; RR: risco relativo; RDc: lenalidomida e dexametasona até progressão da doença; TDc: talidomida e dexametasona até progressão da doença; MPR-R: melfalana, prednisona e lenalidomida com manutenção de lenalidomida; MPT-T: melfalana, prednisona e talidomida com manutenção de talidomida; MP: melfalana e prednisona até progressão.  
Notas:  
a. A certeza da evidência foi rebaixada em um nível, pois o intervalo de confiança da medida passa pelo efeito nulo.  
b. A certeza da evidência foi rebaixada um nível, devido ao risco de viés do ensaio clínico <mark>HOVON87MM</mark><sup>67</sup> <mark>.</mark>  
c. A certeza da evidência foi rebaixada um nível, devido ao risco de viés do ensaio clínico HOVON 49<sup>68</sup> .  
d. A certeza da evidência foi rebaixada um nível, devido às diferenças das populações do estudo quanto ao estadiamento da doença.  
e. A certeza da evidência foi rebaixada dois níveis por imprecisão, pois o intervalo de confiança da medida passa pelo efeito nulo e é amplo.  
- f. A certeza da evidência foi rebaixada um nível, devido ao risco de viés de detecção do ensaio clínico EMN01<sup>69</sup> .  
g. Rebaixado um nível devido ao risco de viés de detecção do estudo ECOG E1A06<sup>70</sup> e por viés de seleção e detecção no estudo HOVON87MM<sup>67</sup> .  
**Tabela K -** Avaliação da qualidade da evidência da comparação entre melfalana, prednisona e lenalidomida com manutenção de lenalidomida (MPR-R) versus melfalana, prednisona e talidomida com manutenção de talidomida (MPTT) quanto aos desfechos sobrevida global, sobrevida livre de progressão, eventos adversos graves, suspensão por eventos adversos*.  
|||**Intervenção**|**Estimativa direta**||**Estimativa indireta**||**Estimativa da meta**<br>**rede**|**-análise em**||
|---|---|---|---|---|---|---|---|---|---|
|**#**|**Intervenção**|**1**<br> <br>**2**|**Estimativa**<br>**de**||**Estimativa**<br>**de**||**Estimativa**<br>**de**||**Justificativa**|
||||**efeito**<br>**[IC 95%]**|**GRADE**|**efeito**<br>**[IC 95%]**|**GRADE**|**efeito**<br>**[IC 95%]**|**GRADE**||
|**Sobrev**|**ida Global**|||||||||
|**1**|MPR-R|MP|HR 0,95 [0,54-1,67]|Moderada|NA|NA|NA|NA|**Imprecisão**<sup>**a**</sup>|
|**2**|MP|MPT-T|HR 0,94 [0,57-1,56]|Moderada|NA|NA|NA|NA|**Imprecisão**<sup>**a**</sup>|
|3|**MPR-R**|**MPT-T**|**HR**<br>**0,95**<br>**[0,67-**<br>**1,33]**|**Baixa**|**HR**<br>**0,71**<br>**[0,36-**<br>**1,38]**|**Baixa**|**HR**<br>**0,89**<br>**[0,66-**<br>**1,21]**|**Baixa**|**Imprecisão**<sup>**a**</sup><br>**Risco de viés**<sup>**b**</sup>|
||||||||||**Intransitividade**<sup>**c**</sup>|
|**Sobrev**|**ida livre de pr**|**ogressão**||||||||
|**1**|MPR-R|MP|HR 0,40 [0,25-0,64]|Alta|NA|NA|NA|NA||
|**2**|MP|MPT-T|HR 1,61 [1,07-2,43]|Alta|NA|NA|NA|NA||
|**3**|**MPR-R**|MPT-T|**HR 1,0 [0,76-1,32]**|**Baixa**|**HR**<br>**0,59**<br>**[0,34-**<br>**1,03]**|**Baixa**|**HR**<br>**0,90**<br>**[0,70-**<br>**1,15]**|**Baixa**|**Imprecisão**<sup>**a**</sup><br>**Risco de viés**<sup>**b**</sup><br>**Intransitividade**<sup>**c**</sup>|
|**Evento**|**s adversos gra**|**ves**||||||||
|**1**|MPR-R|MPT-T|**RR 0,79 [0,67-0,93]**|**Moderad**|**NA**|**NA**|**RR 0,79 [0,67-0,93]**|**Moderad**|**Risco de viés**<sup>**d**</sup>|
|||||**a**||||**a**||
|**Suspen**|**são por evento**|**adverso**||||||||
|**1**|MPR-R|MP|3,03 [1,28-7,14]|Alta|NA|NA|NA|NA||
|**2**|MP|MPT-T|0,26 [0,09-0,71]|Moderada|NA|NA|NA|NA|Risco de viés<sup>e</sup>|
|3|**MPR-R**|**MPT-T**|**0,85 [0,52-1,39]**|**Baixa**|**0,50 [ 0,15-1,69]**|**Muito**|**0,79 [0,50-1,24]**|**Baixa**|**Imprecisão**<sup>**a**</sup>|  
|**baixa**|**Risco de viés**<sup>**f**</sup>|
|---|---|
||**Intransitividade**<sup>**c**</sup>|  
***** A comparação de interesse está sinalizada em negrito. As demais comparações contribuem para a medida da comparação de interesse.  
Legenda: IC - intervalo de confiança; NA - não avaliado; HR - hazard ratio; RR: risco relativo; MPR-R: melfalana, prednisona e lenalidomida com manutenção de lenalidomida; MPT-T: melfalana, prednisona e talidomida com manutenção de talidomida; MP: melfalana e prednisona.  
Notas:  
a. A certeza da evidência foi rebaixada em um nível, pois o intervalo de confiança da medida passa pelo efeito nulo.  
b. A certeza da evidência foi rebaixada um nível, devido ao risco de viés do ensaio clínico <mark>HOVON87MM</mark><sup>67</sup> <mark>.</mark>  
c. A certeza da evidência foi rebaixada um nível, devido às diferenças das populações do estudo quanto ao estadiamento da doença.  
d. A certeza da evidência foi rebaixada um nível pelo risco de viés de detecção, devido a falta de cegamento do estudo ECOG E1A06<sup>70</sup> .  
e. A certeza da evidência foi rebaixada um nível pelo risco de viés de detecção, devido à falta de cegamento do estudo GIMEMA<sup>71</sup> .  
- f. Rebaixado um nível devido ao risco de viés de detecção do estudo ECOG E1A06 (16) e por viés de seleção e detecção no estudo HOVON87MM<sup>67</sup>

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **QUESTÃO 7: Deve-se utilizar anticorpos monoclonais (daratumumabe) em monoterapia ou associado a outros medicamentos no paciente com mieloma múltiplo, em recidiva ou doença refratária?** -->
**<u>Recomendação 7:</u>** <mark>Por não ter sido incorporada no âmbito do SUS para o tratamento de MM, estas Diretrizes não preconizam o uso desta tecnologia. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.</mark>  
A estrutura PICO para esta pergunta foi:  
**População:** Pacientes adultos, com RS, em recidiva ou doença refratária  
**Intervenção:** Anticorpos monoclonais (daratumumabe) em monoterapia ou associado a outros medicamentos **Comparador:** Esquemas terapêuticos sem anticorpos monoclonais  
**Desfechos:** SG, SLP, qualidade de vida (QV), TRC, taxa de resposta parcial muito boa (RPMB) e EA.

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Métodos e resultados da busca:** -->
Para responder essa pergunta, foi utilizada a referência de um ECR e a síntese de evidências foi apresentada no Relatório de Recomendação nº 702/2022<sup>72</sup> , relativo à proposta de incorporação do daratumumabe em monoterapia ou associado à terapia antineoplásica para o controle do mieloma múltiplo recidivado ou refratário.  
Foi realizada busca estruturada nas bases MEDLINE (via Pubmed), EMBASE, Cochrane Library e manual em julho de 2021. A seleção dos estudos e a extração dos dados foram realizadas por dois pesquisadores independentes. As discordâncias foram avaliadas por um terceiro pesquisador e resolvidas por meio do consenso. A estratégia de busca localizou 961 publicações e, ao final, foram selecionadas <mark>dez</mark> RS<sup>42,43,73–80</sup> e um ECR - CASTOR<sup>81–85</sup> que satisfizeram a pergunta de pesquisa. A avaliação da qualidade metodológica das RS foi realizada com a ferramenta AMSTAR-2<sup>3</sup> e do ECR foi realizada por meio da ferramenta RoB 2<sup>4</sup> . Os resultados foram apresentados e sintetizados, baseados apenas no estudo CASTOR, por ser o único a incluir o esquema previsto em bula<sup>86</sup> . A descrição detalhada dos métodos e resultados da busca estão no Relatório de Recomendação nº 702/2022<sup>72</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Resumo das evidências:** -->
Os resultados do estudo CASTOR<sup>81–85</sup> foi considerado para síntese de evidências e comparou o esquema daratumumabe, bortezomibe e dexametasona (DVD) versus bortezomibe e dexametasona (VD). A avaliação geral do risco de viés foi de ‘algumas preocupações’ quanto ao risco de viés para os desfechos de eficácia (SLP, QV, RC e RPMB) e de ‘alto risco’ para o desfecho EA. O tempo de seguimento das publicações consideradas variou de 12 a 48 meses.  
A **SG** não pode ser avaliada pois a mediana não foi alcançada.  
Para **SLP** (16,7 vs. 7,1 meses; HR 0,31, IC de 95% 0,24 a 0,39), **RC** (28,2% vs. 8,9%; p < 0,0001) e **RPMB** (60,9% vs. 29,2%; p < 0,0001), houve benefício para os pacientes que receberam daratumumabe.  
Em relação à **QV** , não houve diferença entre os escores de avaliados pelas ferramentas EORTC QLQ-C30 (p=0,9163) e EQ-5D-5L (p=0,8072) no início e no final do estudo.  
Considerando os desfechos de segurança, daratumumabe não parece aumentar o risco de **suspensão por EA** (7,4% para esquema com daratumumabe vs. 9,3% para esquema sem daratumumabe) ou a incidência de **EA** (98,8% vs. 95,4%).

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **Perfil de evidências:** -->
<mark>Para avaliação da qualidade da evidência, foram utilizados os resultados do estudo CASTOR. O</mark> s resultados da certeza da evidência (GRADE) da comparação entre DVD versus VD para o desfecho QV e suspensão por EA foi considerada alta. Para os desfechos SLP, a evidência foi considerada moderada ( **Tabela L** ).  
**Tabela L -** Avaliação da qualidade da evidência para daratumumabe, bortezomibe e dexametasona comparado a bortezomibe e dexametasona para controle do mieloma múltiplo recidivado ou refratário.  
|**Avaliação de c**<br>**Participantes**|**onfiança**<br>|<br>||**Viés**<br>**de**|**Confianç**<br>|**Sumário de**<br>**Taxas de**<br>**estudo (%)**<br>**Com**|**Resultados**<br>**eventos do**<br> <br>**Efeito**<br>**Com**<br>**daratumu**|**Efeitos abso**<br>**Risco com**|**lutos potenciais**<br>**Diferença de**<br>|
|---|---|---|---|---|---|---|---|---|---|
|**(estudos)**<br>**Seguimento**<br>**Sobrevida glob**|**Risco**<br>**de viés**<br>**al - não m**|**Inconsistênci**<br>**a**<br>**ensurados**|**Evidência**<br>**indireta**<br>**Imprecisão**|**publicaçã**<br>**o**|**a**<br>**da**<br>**evidência**<br>**geral**|**bortezom**<br>**ibe**<br>**+**<br>**dexameta**<br>**sona**|**relativo**<br>**(IC 95%)**<br>**mabe**<br>**+**<br>**bortezomib**<br>**e**<br>**+**<br>**dexametaso**<br>**na**|**bortezomi**<br>**be**<br>**+**<br>**dexametas**<br>**ona**|**risco**<br>**com**<br>**daratumumab**<br>**e**<br>**+**<br>**bortezomibe +**<br>**dexametasona**|
|-<br>**Qualidade de v**<br>|-<br>**ida relaci**<br>|-<br>**onada à saúde (**<br>|-<br>-<br>**seguimento: mediana 19,4**<br> <br>|-<br>**meses)**<br>|-<br>|-<br>|-<br>-<br>|-<br>|-<br>|
|498<br>(1 ECR)|não<br>grave|não grave|não grave<br>não grave|nenhum|⨁⨁⨁⨁<br>ALTA|As ferramen<br>foi mantida<br>permanecer<br>nas alteraçõ<br>DARA+BO<br>pontuações<br>pontuação<br>observada a<br>a pontuação<br>significativa<br>observada p<br>0,99; IC de<br>diferença si|tas EORTC QLQ-C30 e EQ-<br>durante o tratamento para os pa<br>am no estudo. Não foram obse<br>es médias dos mínimos qua<br>RT+DEXA e BORT+DEXA<br>do estado de saúde global<br>do utilitário EQ-5D-5L. Um<br>penas na semana 21 em favor<br>da escala visual analógica (p<br>no estado de saúde globa<br>ara o tempo médio de melho<br>95%, 0,76-1,29; p = 0,9163<br>gnificativa no tempo médio d|5D-5L mostrar<br>cientes de am<br>rvadas diferen<br>drados da lin<br>em nenhum<br>do EORTC<br>a diferença<br>de DARA+BO<br>= 0,0185). Ne<br>l do EORT<br>ra (5,0 versus<br>). Da mesma<br>e melhora foi|am que a QVRS<br>bos os grupos que<br>ças significativas<br>ha de base entre<br>momento para as<br>QLQ-C30 ou a<br>significativa foi<br>RT+DEXA para<br>nhuma diferença<br>C QLQ-C30 foi<br>5,1 meses; HR,<br>forma, nenhuma<br>observada para o|  
|**Avaliação de c**<br>**Participantes**<br>**(estudos)**|**onfiança**<br>**Risco**<br>**de viés**|<br>**Inconsistênci**<br>**a**|**Evidência**<br>**indireta**<br>**Imprecisão**|**Viés**<br>**de**<br>**publicaçã**|**Confianç**<br>**a**<br>**da**<br>**evidência**|**Sumário de**<br>**Taxas de**<br>**estudo (%)**<br>**Com**<br>**bortezom**|**Resultados**<br>**eventos do**<br> <br>**Com**<br>**daratumu**<br>**mabe**<br>**+**|**Efeito**<br>**relativo**|**Efeitos abso**<br>**Risco com**<br>**bortezomi**|**lutos potenciais**<br>**Diferença de**<br>**risco**<br>**com**<br>**daratumumab**|
|---|---|---|---|---|---|---|---|---|---|---|
|**Seguimento**<br>**Suspensão por**|**evento a**|**dverso (seguimen**|**to: mediana 7,4 meses)**|**o**|**geral**|**ibe**<br>**+**<br>**dexameta**<br>**sona**<br>_EQ-5D-5L_<br>1,08; p = 0,<br>meses; HR,|**bortezomib**<br>**e**<br>**+**<br>**dexametaso**<br>**na**<br>_Utility Score_(7,<br>1469) ou o esc<br>1,03; IC 95%,|**(IC 95%)**<br>7 versus 3,5 me<br>ore da escala v<br>0,79-1,35; p = 0|**be**<br>**+**<br>**dexametas**<br>**ona**<br>ses; HR, 0,82;<br>isual analógic<br>,8072).|**e**<br>**+**<br>**bortezomibe +**<br>**dexametasona**<br>IC de 95%, 0,62-<br>a (5,0 versus 5,0|
|471|não|não grave|não grave<br>não grave|nenhum|⨁⨁⨁⨁|22/237|17/234|não|93<br>por||
|(1 ECR)|grave||||ALTA|(9,3%)|(7,3%)|estimável|1.000||
|**Evento adverso**|**grave -**|**não mensurados**|||||||||
|-<br>**Sobrevida livre**|-<br>**de prog**|-<br>**ressão**|-<br>-|-|-|-|-|-|-|-|
|498|não|não grave|grave a<br>não grave|nenhum|⨁⨁⨁|247|251|**HR**<br>**0,31**|**Baixo**||
|(1 ECR)|grave||||MODER<br>ADA|participant<br>es|participante<br>s|(0,24 para<br>0,39)<br>[Progressão<br>ou morte]|81<br>por<br>1.000|**378 mais por**<br>**1.000**<br>(de 294 mais<br>para 466 mais)|  
Legenda: BORT (Bortezomibe), DARA (Daratumumabe), DEXA (Dexametasona), ECR (ensaio clínico randomizado), HR (Hazard ratio)  
Explicações:  
a - Evidência indireta, uma vez que sobrevida livre de progressão não é desfecho validado para predição de sobrevida global no contexto do mieloma múltiplo. Referências: Palumbo et al. 2016<sup>81</sup> , Spencer et al. 2018<sup>82</sup> , Mateos et al. 2020<sup>83</sup> , Mateos et al. 2020a<sup>84</sup> e Weisel et al. 2020<sup>85</sup> .

---

<!-- METADADOS: doenca: Mieloma Múltiplo | secao: **7. REFERÊNCIAS** -->
1.  Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Portaria n<sup>o</sup> 708 de 6 de agosto de 2015. Aprova as  
Diretrizes Diagnósticas e Terapêuticas do Mieloma Múltiplo. [Internet]. 2015. Available from: https://bvsms.saude.gov.br/bvs/saudelegis/sas/2011/prt0708_25_10_2011.html  
2.  GRADE Guidance Group. Grading of Recommendations Assessment, Development, and Evaluation. [Internet]. [cited 2022 Mar 15]. Available from: https://www.gradeworkinggroup.org/  
3.  Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ [Internet]. 2017 Sep 21;j4008. Available from: https://www.bmj.com/lookup/doi/10.1136/bmj.j4008  
4.  Higgins J, Savović J, Page M, Elbers R, Sterne J. Assessing risk of bias in a randomized trial. In: Cochrane Handbook for Systematic Reviews of Interventions version 62 [Internet]. 2021. Available from: www.training.cochrane.org/handbook.  
5.  Whiting PF. QUADAS-2: A Revised Tool for the Quality Assessment of Diagnostic Accuracy Studies. Ann Intern Med [Internet]. 2011 Oct 18;155(8):529. Available from: http://annals.org/article.aspx?doi=10.7326/0003-4819-155-8201110180-00009  
6.  Ministério da Saúde. Diretrizes Metodológicas. Sistema GRADE – manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde. [Internet]. Brasília; 2014. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/diretrizes_metodologicas_sistema_grade.pdf  
7.  Durak Aras B, Akay OM, Sungar G, Bademci G, Aslan V, Caferler J, et al. Conventional and molecular cytogenetic analyses in Turkish patients with multiple myeloma. Turkish J Hematol [Internet]. 2011 Aug 1; Available from: http://www.journalagent.com/z4/download_fulltext.asp?pdir=tjh&plng=eng&un=TJH-24993  
8.  Ashok V, Ranganathan R, Chander S, Damodar S, Bhat S, S NK, et al. Comparison of Diagnostic Yield of a FISH Panel Against Conventional Cytogenetic Studies for Hematological Malignancies: A South Indian Referral Laboratory Analysis Of 201 Cases. Asian Pac J Cancer Prev [Internet]. 2017 Dec 29;18(12):3457–64. Available from: http://www.ncbi.nlm.nih.gov/pubmed/29286619  
9.  Yuregir OO, Sahin FI, Yilmaz Z, Kizilkilic E, Karakus S, Ozdogu H. Fluorescent in situ hybridization studies in multiple myeloma. Hematology [Internet]. 2009 Apr 18;14(2):90–4. Available from: https://www.tandfonline.com/doi/full/10.1179/102453309X385250  
10. Aydin C, Ulas T, Hangul C, Yucel OK, Iltar U, Salim O, et al. Conventional Cytogenetics and Interphase Fluorescence In Situ Hybridization Results in Multiple Myeloma: A Turkey Laboratory Analysis of 381 Cases. Indian J Hematol Blood Transfus [Internet]. 2020 Apr 25;36(2):284–91. Available from: http://link.springer.com/10.1007/s12288-019-01215-5  
11. Chang H, Li D, Zhuang L, Nie E, Bouman D, Stewart AK, et al. Detection of Chromosome 13q Deletions and IgH Translocations in Patients with Multiple Myeloma by FISH: Comparison with Karyotype Analysis. Leuk Lymphoma [Internet]. 2004 May 3;45(5):965–9. Available from: http://www.tandfonline.com/doi/full/10.1080/10428190310001638832  
12. Gole L, Lin A, Chua C, Chng WJ. Modified cIg-FISH protocol for multiple myeloma in routine cytogenetic laboratory practice. Cancer Genet [Internet]. 2014 Jan;207(1–2):31–4. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2210776213001683  
13. Hamdaoui H, Benlarroubia O, Ait Boujmia OK, Mossafa H, Ouldim K, Belkhayat A, et al. Cytogenetic and FISH analysis of 93 multiple myeloma Moroccan patients. Mol Genet Genomic Med [Internet]. 2020 Sep 23;8(9). Available from: https://onlinelibrary.wiley.com/doi/10.1002/mgg3.1363  
14. He J, Yang L, Meng X, Wei G, Wu W, Han X, et al. A Retrospective Analysis of Cytogenetic and Clinical Characteristics in Patients With Multiple Myeloma. Am J Med Sci [Internet]. 2013 Feb;345(2):88–93. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0002962915307321  
15. Ikbal Atli E, Gurkan H, Onur Kirkizlar H, Atli E, Demir S, Yalcintepe S, et al. Pros and cons for fluorescent in situ hybridization, karyotyping and next generation sequencing for diagnosis and follow-up of multiple myeloma. Balk J Med Genet [Internet]. 2021 Mar 23;23(2):59–64. Available from: https://www.sciendo.com/article/10.2478/bjmg-2020-0020  
16. Kishimoto RK, de Freitas SLVV, Ratis CA, Borri D, Sitnik R, Velloso EDRP. Validation of interphase fluorescence in situ hybridization (iFISH) for multiple myeloma using CD138 positive cells. Rev Bras Hematol Hemoter [Internet]. 2016 Apr;38(2):113–20. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1516848416000086  
17. Legües ME, Morales P, Valenzuela M, Encina A, Martí MJ, Bascuñán C, et al. Características citogenéticas y detección de anormalidades de alto riesgo en mieloma múltiple. Rev Med Chil [Internet]. 2019;147(1):61–4. Available from: http://www.scielo.cl/scielo.php?script=sci_arttext&pid=S0034-98872019000100061&lng=en&nrm=iso&tlng=en  
18. Boneva T, Brazma D, Gancheva K, Howard-Reeves J, Raynov J, Grace C, et al. Can genome array screening replace FISH as a front-line test in multiple myeloma? Genes, Chromosom Cancer [Internet]. 2014 Aug;53(8):676–92. Available from: https://onlinelibrary.wiley.com/doi/10.1002/gcc.22178  
19. Yu Y, Brown Wade N, Hwang AE, Nooka AK, Fiala MA, Mohrbacher A, et al. Variability in Cytogenetic Testing for Multiple Myeloma: A Comprehensive Analysis From Across the United States. JCO Oncol Pract [Internet]. 2020;16(10):e1169–80. Available from: http://www.ncbi.nlm.nih.gov/pubmed/32469686  
20. Scott K, Hayden PJ, Will A, Wheatley K, Coyne I. Bortezomib for the treatment of multiple myeloma. Cochrane Database Syst Rev [Internet]. 2016 Apr 20; Available from: https://doi.wiley.com/10.1002/14651858.CD010816.pub2  
21. Nooka AK, Kaufman JL, Behera M, Langston A, Waller EK, Flowers CR, et al. Bortezomib-containing induction regimens in transplant-eligible myeloma patients. Cancer [Internet]. 2013 Dec 1;119(23):4119–28. Available from: https://onlinelibrary.wiley.com/doi/10.1002/cncr.28325  
22. Sekine L, Ziegelmann PK, Manica D, Fonte Pithan C, Sosnoski M, Morais VD, et al. Frontline treatment for transplant‐eligible multiple myeloma: A 6474 patients network meta‐analysis. Hematol Oncol [Internet]. 2019 Feb 20;37(1):62– 74. Available from: https://onlinelibrary.wiley.com/doi/10.1002/hon.2552  
23. Zeng Z, Lin J, Chen J. Bortezomib for patients with previously untreated multiple myeloma: a systematic review and meta-analysis of randomized controlled trials. Ann Hematol [Internet]. 2013 Jul 2;92(7):935–43. Available from: http://link.springer.com/10.1007/s00277-013-1711-7  
24. Zeng Z-H, Chen J-F, Li Y-X, Zhang R, Xiao L-F, Meng X-Y. Induction regimens for transplant-eligible patients with newly diagnosed multiple myeloma: a network meta-analysis of randomized controlled trials. Cancer Manag Res [Internet]. 2017 Jul;Volume 9:287–98. Available from: https://www.dovepress.com/induction-regimens-for-transplant-eligiblepatients-with-newly-diagnos-peer-reviewed-article-CMAR  
25. Higgins J, Altman DG, Sterne J. Assessing risk of bias in included studies. In: Cochrane Handbook for Systematic Reviews of Interventions. 5.1.0. 2011.  
26. Rosiñol L, Oriol A, Teruel AI, Hernández D, López-Jiménez J, de la Rubia J, et al. Superiority of bortezomib, thalidomide, and dexamethasone (VTD) as induction pretransplantation therapy in multiple myeloma: a randomized phase 3 PETHEMA/GEM study. Blood [Internet]. 2012 Aug 23;120(8):1589–96. Available from: https://ashpublications.org/blood/article/120/8/1589/30806/Superiority-of-bortezomib-thalidomide-and  
27. Cavo M, Tacchetti P, Patriarca F, Petrucci MT, Pantani L, Galli M, et al. Bortezomib with thalidomide plus dexamethasone compared with thalidomide plus dexamethasone as induction therapy before, and consolidation therapy after, double autologous stem-cell transplantation in newly diagnosed multiple myeloma: a randomised phase 3. Lancet [Internet]. 2010 Dec;376(9758):2075–85. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0140673610614249  
28. Cavo M, Galli M, Pantani L, Di Raimondo F, Crippa C, Offidani M, et al. Bortezomib-ThalidomideDexamethasone Incorporated Into Autotransplantation Is Associated with More Favorable Outcomes After Relapse in  
Comparison with Thalidomide-Dexamethasone Plus Autotransplantation in Multiple Myeloma. Blood [Internet]. 2012 Nov 16;120(21):4210–4210. Available from:  
https://ashpublications.org/blood/article/120/21/4210/86776/BortezomibThalidomideDexamethasone-Incorporated  
29. Cavo M, Pantani L, Petrucci MT, Patriarca F, Zamagni E, Donnarumma D, et al. Bortezomib-thalidomidedexamethasone is superior to thalidomide-dexamethasone as consolidation therapy after autologous hematopoietic stem cell transplantation in patients with newly diagnosed multiple myeloma. Blood [Internet]. 2012 Jul 5;120(1):9–19. Available from: https://ashpublications.org/blood/article/120/1/9/30142/Bortezomibthalidomidedexamethasone-is-superior-to  
30. Cavo M, Galli M, Pezzi A, Di Raimondo F, Crippa C, Offidani M, et al. Persistent Improvement In Clinical Outcomes With Bortezomib-Thalidomide-Dexamethasone Vs Thalidomide-Dexamethasone Incorporated Into Double Autologous Transplantation For Multiple Myeloma: An Updated Analysis Of Phase 3 Gimema-MMY-3006 Study. Blood [Internet]. 2013 Nov 15;122(21):2090–2090. Available from: https://ashpublications.org/blood/article/122/21/2090/11751/Persistent-Improvement-In-Clinical-Outcomes-With  
31. Brioli A, Pezzi A, Mügge L, Derudas D, Petti MC, Zannetti B., et al. Jahrestagung der -Deutschen, Österreichischen und -Schweizerischen -Gesellschaften für Hämatologie und -Medizinische Onkologie, Leipzig, 14.–18. Oktober 2016: Abstracts. Oncol Res Treat [Internet]. 2016;39(3):1–348. Available from: https://www.karger.com/Article/FullText/449050  
32. Tacchetti P, Patriarca F, Petrucci MT, Galli M, Pantani L, Dozza L, et al. A triplet bortezomib-and immunomodulator-based therapy before and after double ASCT improves overall survival of newly diagnosed mm patients: final analysis of phase 3 gimema-MMY-3006 study [Internet]. Vol. 2, HemaSphere. 23rd Congress of the European Hematology Association Stockholm, Sweden; 2018. p. 1–1113. Available from: https://journals.lww.com/02014419-201806001-00001  
33. Tacchetti P, Zamagni E, Patriarca F, Petrucci MT, Dozza L, Galli M, et al. Bortezomib-thalidomidedexamethasone and double autologous stem cell transplantation for newly diagnosed multiple mieloma: Final results of the phase 3 GIMEMA-MMY-3006 trial. Haematologica. 47th Congress of the Italian Society of Hematology; 2019.  
34. Tacchetti P, Pantani L, Patriarca F, Petrucci MT, Zamagni E, Dozza L, et al. Bortezomib, thalidomide, and dexamethasone followed by double autologous haematopoietic stem-cell transplantation for newly diagnosed multiple myeloma (GIMEMA-MMY-3006): long-term follow-up analysis of a randomised phase 3, open-label study. Lancet Haematol [Internet]. 2020 Dec;7(12):e861–73. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2352302620303239  
35. Harousseau J-L, Attal M, Avet-Loiseau H, Marit G, Caillot D, Mohty M, et al. Bortezomib Plus Dexamethasone Is Superior to Vincristine Plus Doxorubicin Plus Dexamethasone As Induction Treatment Prior to Autologous Stem-Cell Transplantation in Newly Diagnosed Multiple Myeloma: Results of the IFM 2005-01 Phase III Trial. J Clin Oncol [Internet]. 2010 Oct 20;28(30):4621–9. Available from: http://ascopubs.org/doi/10.1200/JCO.2009.27.9158  
36. Janssen-Cilag. VELCADE: pó liofilizado. São José dos Campos; 2017.  
37. Blommestein HM, van Beurden-Tan CHY, Franken MG, Uyl-de Groot CA, Sonneveld P, Zweegman S. Efficacy of first-line treatments for multiple myeloma patients not eligible for stem cell transplantation: a network meta-analysis. Haematologica [Internet]. 2019 May;104(5):1026–35. Available from:  
http://www.haematologica.org/lookup/doi/10.3324/haematol.2018.206912  
38. Piechotta V, Jakob T, Langer P, Monsef I, Scheid C, Estcourt LJ, et al. Multiple drug combinations of bortezomib, lenalidomide, and thalidomide for first-line treatment in adults with transplant-ineligible multiple myeloma: a network meta-analysis. Cochrane Database Syst Rev [Internet]. 2019 Nov 25; Available from: https://doi.wiley.com/10.1002/14651858.CD013487  
39. Sekine L, Ziegelmann PK, Manica D, Pithan C da F, Sosnoski M, Morais VD, et al. Upfront treatment for newly diagnosed transplant-ineligible multiple myeloma patients: A systematic review and network meta-analysis of 14,533  
patients over 29 randomized clinical trials. Crit Rev Oncol Hematol [Internet]. 2019 Nov;143:102–16. Available from: https://linkinghub.elsevier.com/retrieve/pii/S1040842818304955  
40. San Miguel JF, Schlag R, Khuageva NK, Dimopoulos MA, Shpilberg O, Kropff M, et al. Bortezomib plus Melphalan and Prednisone for Initial Treatment of Multiple Myeloma. N Engl J Med [Internet]. 2008 Aug 28;359(9):906–17. Available from: http://www.nejm.org/doi/abs/10.1056/NEJMoa0801479  
41. Botta C, Ciliberto D, Rossi M, Staropoli N, Cucè M, Galeano T, et al. Network meta-analysis of randomized trials in multiple myeloma: efficacy and safety in relapsed/refractory patients. Blood Adv [Internet]. 2017 Feb 28;1(7):455–66. Available from: https://ashpublications.org/bloodadvances/article/1/7/455/16025/Network-metaanalysis-of-randomized-trialsin  
42. Luo X-W, Du X-Q, Li J-L, Liu X-P, Meng X-Y. Treatment options for refractory/relapsed multiple myeloma: an updated evidence synthesis by network meta-analysis. Cancer Manag Res [Internet]. 2018 Aug;Volume 10:2817–23. Available from: https://www.dovepress.com/treatment-options-for-refractoryrelapsed-multiple-myeloma-an-updated-e-peerreviewed-article-CMAR  
43. Schmitz S, Maguire Á, Morris J, Ruggeri K, Haller E, Kuhn I, et al. The use of single armed observational data to closing the gap in otherwise disconnected evidence networks: a network meta-analysis in multiple myeloma. BMC Med  
Res Methodol [Internet]. 2018 Dec 28;18(1):66. Available from:  
https://bmcmedresmethodol.biomedcentral.com/articles/10.1186/s12874-018-0509-7  
44. Richardson PG, Sonneveld P, Schuster MW, Irwin D, Stadtmauer EA, Facon T, et al. Bortezomib or HighDose Dexamethasone for Relapsed Multiple Myeloma. N Engl J Med [Internet]. 2005 Jun 16;352(24):2487–98. Available from: http://www.nejm.org/doi/abs/10.1056/NEJMoa043445  
45. Iida S, Wakabayashi M, Tsukasaki K, Miyamoto K, Maruyama D, Yamamoto K, et al. Bortezomib plus dexamethasone vs thalidomide plus dexamethasone for relapsed or refractory multiple myeloma. Cancer Sci [Internet]. 2018 May 17;109(5):1552–61. Available from: https://onlinelibrary.wiley.com/doi/10.1111/cas.13550  
46. Lee SJ, Richardson PG, Sonneveld P, Schuster MW, Irwin D, San Miguel J-F, et al. Bortezomib is associated with better health-related quality of life than high-dose dexamethasone in patients with relapsed multiple myeloma: results from the APEX study. Br J Haematol [Internet]. 2008 Sep; Available from: https://onlinelibrary.wiley.com/doi/10.1111/j.13652141.2008.07378.x  
47. Brasil. Ministério da Saúde. Portaria n<sup>o</sup> 44 de 25 de setembro de 2020. Torna pública a decisão de incorporar, no âmbito do Sistema Único de Saúde - SUS, o bortezomibe para o tratamento de pacientes adultos com mieloma múltiplo previamente tratados, conforme estabelecido pelo Ministéri [Internet]. 2020. Available from: https://www.in.gov.br/en/web/dou/-/portaria-sctie/ms-n-44-de-25-de-setembro-de-2020-279712041  
48. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 700. Lenalidomida para terapia de manutenção em pacientes com mieloma múltiplo submetidos ao transplante de células-tronco hematopoiéticas. [Internet]. 2022. Available from: http://conitec.gov.br/images/Relatorios/2022/20220314_Relatorio_700_lenalidomida_elegiveis_mieloma_multiplo_.pdf. 49. Gay F, Jackson G, Rosiñol L, Holstein SA, Moreau P, Spada S, et al. Maintenance Treatment and Survival in Patients With Myeloma. JAMA Oncol [Internet]. 2018 Oct 1;4(10):1389. Available from: http://oncology.jamanetwork.com/article.aspx?doi=10.1001/jamaoncol.2018.2961  
50. Li J-L, Fan G-Y, Liu Y-J, Zeng Z-H, Huang J-J, Yang Z-M, et al. Long-Term Efficacy of Maintenance Therapy for Multiple Myeloma: A Quantitative Synthesis of 22 Randomized Controlled Trials. Front Pharmacol [Internet]. 2018 Apr 30;9. Available from: http://journal.frontiersin.org/article/10.3389/fphar.2018.00430/full  
51. Morgan GJ, Gregory WM, Davies FE, Bell SE, Szubert AJ, Brown JM, et al. The role of maintenance thalidomide therapy in multiple myeloma: MRC Myeloma IX results and meta-analysis. Blood [Internet]. 2012 Jan 5;119(1):7–  
15. Available from: https://ashpublications.org/blood/article/119/1/7/125748/The-role-of-maintenance-thalidomide-therapy-in 52. Morgan GJ, Davies FE, Gregory WM, Bell SE, Szubert AJ, Cook G, et al. Long-term Follow-up of MRC Myeloma IX Trial: Survival Outcomes with Bisphosphonate and Thalidomide Treatment. Clin Cancer Res [Internet]. 2013 Nov 1;19(21):6030–8. Available from: http://clincancerres.aacrjournals.org/lookup/doi/10.1158/1078-0432.CCR-12-3211  
53. Holstein SA, Jung S-H, Richardson PG, Hofmeister CC, Hurd DD, Hassoun H, et al. Updated analysis of CALGB (Alliance) 100104 assessing lenalidomide versus placebo maintenance after single autologous stem-cell transplantation for multiple myeloma: a randomised, double-blind, phase 3 trial. Lancet Haematol [Internet]. 2017 Sep;4(9):e431–42. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2352302617301400  
54. McCarthy PL, Owzar K, Hofmeister CC, Hurd DD, Hassoun H, Richardson PG, et al. Lenalidomide after Stem-Cell Transplantation for Multiple Myeloma. N Engl J Med [Internet]. 2012 May 10;366(19):1770–81. Available from: http://www.nejm.org/doi/abs/10.1056/NEJMoa1114083  
55. McCarthy PL, Holstein SA, Petrucci MT, Richardson PG, Hulin C, Tosi P, et al. Lenalidomide Maintenance After Autologous Stem-Cell Transplantation in Newly Diagnosed Multiple Myeloma: A Meta-Analysis. J Clin Oncol [Internet]. 2017 Oct 10;35(29):3279–89. Available from: https://ascopubs.org/doi/10.1200/JCO.2017.72.6679  
56. Attal M, Lauwers-Cances V, Marit G, Caillot D, Moreau P, Facon T, et al. Lenalidomide Maintenance after Stem-Cell Transplantation for Multiple Myeloma. N Engl J Med [Internet]. 2012 May 10;366(19):1782–91. Available from: http://www.nejm.org/doi/abs/10.1056/NEJMoa1114138  
57. Palumbo A, Cavallo F, Gay F, Di Raimondo F, Ben Yehuda D, Petrucci MT, et al. Autologous Transplantation and Maintenance Therapy in Multiple Myeloma. N Engl J Med [Internet]. 2014 Sep 4;371(10):895–905. Available from: http://www.nejm.org/doi/10.1056/NEJMoa1402888  
58. Jackson G, Davies F., Pawlyn C, Cairns D, Striha A, Hockaday A, et al. Lenalidomide Maintenance Significantly Improves Outcomes Compared to Observation Irrespective of Cytogenetic Risk: Results of the Myeloma XI Trial. Blood [Internet]. 2017;130(Supplement 1):436. Available from: https://ashpublications.org/blood/article/130/Supplement 1/436/72685/Lenalidomide-Maintenance-Significantly-Improves  
59. McCarthy PL, Richardson P, Suman V, Cooper M, Saunders O, Dhanasiri S, et al. Survival Analysis from the CALGB Study of Lenalidomide Maintenance Therapy in Newly Diagnosed Multiple Myeloma Post-Autologous Stem Cell Transplantation Adjusted for Crossover (Alliance 100104). Blood [Internet]. 2018 Nov 29;132(Supplement 1):4737–4737. Available from: https://ashpublications.org/blood/article/132/Supplement 1/4737/262206/Survival-Analysis-from-the-CALGBStudy-of  
60. Ludwig H, Boccadoro M, Moreau P, San-Miguel J, Cavo M, Pawlyn C, et al. Recommendations for vaccination in multiple myeloma: a consensus of the European Myeloma Network. Leukemia [Internet]. 2021 Jan 19;35(1):31– 44. Available from: https://www.nature.com/articles/s41375-020-01016-0  
61. Ludwig H, Durie BGM, McCarthy P, Palumbo A, San Miguel J, Barlogie B, et al. IMWG consensus on maintenance therapy in multiple myeloma. Blood [Internet]. 2012 Mar 29;119(13):3003–15. Available from: https://ashpublications.org/blood/article/119/13/3003/29610/IMWG-consensus-on-maintenance-therapy-in-multiple 62. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 701. Lenalidomida para pacientes com mieloma múltiplo inelegíveis ao transplante de células-tronco hematopoiéticas. [Internet]. 2022. Available from: http://conitec.gov.br/images/Relatorios/2022/20210314_Relatorio_701_lenalidomida_inelegiveis_mieloma_multiplo.pdf.  
63. Weisel K, Doyen C, Dimopoulos M, Yee A, Lahuerta JJ, Martin A, et al. A systematic literature review and network meta-analysis of treatments for patients with untreated multiple myeloma not eligible for stem cell transplantation. Leuk Lymphoma [Internet]. 2017 Jan 2;58(1):153–61. Available from: https://www.tandfonline.com/doi/full/10.1080/10428194.2016.1177772  
64. Liu X, Chen J, He Y, Meng X, Li K, He C, et al. Comparing efficacy and survivals of initial treatments for elderly patients with newly diagnosed multiple myeloma: a network meta-analysis of randomized controlled trials. Onco Targets Ther [Internet]. 2016 Dec;Volume 10:121–8. Available from: https://www.dovepress.com/comparing-efficacy-and-survivals-ofinitial-treatments-for-elderly-pat-peer-reviewed-article-OTT  
65. Gil‐Sierra MD, Gimeno‐Ballester V, Fenix‐Caballero S, Alegre‐Del Rey EJ. Network meta‐analysis of first‐ line treatments in transplant‐ineligible multiple myeloma patients. Eur J Haematol [Internet]. 2020 Jul 15;105(1):56–65. Available from: https://onlinelibrary.wiley.com/doi/10.1111/ejh.13407 66. Ramasamy K, Dhanasiri S, Thom H, Buchanan V, Robinson S, D’Souza VK, et al. Relative efficacy of treatment options in transplant-ineligible newly diagnosed multiple myeloma: results from a systematic literature review and network meta-analysis. Leuk Lymphoma [Internet]. 2020 Feb 23;61(3):668–79. Available from: https://www.tandfonline.com/doi/full/10.1080/10428194.2019.1683736  
67. Zweegman S, van der Holt B, Mellqvist U-H, Salomo M, Bos GMJ, Levin M-D, et al. Melphalan, prednisone, and lenalidomide versus melphalan, prednisone, and thalidomide in untreated multiple myeloma. Blood [Internet]. 2016 Mar 3;127(9):1109–16. Available from: https://ashpublications.org/blood/article/127/9/1109/126469/Melphalan-prednisone-andlenalidomide-versus 68. Wijermans P, Schaafsma M, Termorshuizen F, Ammerlaan R, Wittebol S, Sinnige H, et al. Phase III Study of the Value of Thalidomide Added to Melphalan Plus Prednisone in Elderly Patients With Newly Diagnosed Multiple Myeloma: The HOVON 49 Study. J Clin Oncol [Internet]. 2010 Jul 1;28(19):3160–6. Available from: http://ascopubs.org/doi/10.1200/JCO.2009.26.1610  
69. Magarotto V, Bringhen S, Offidani M, Benevolo G, Patriarca F, Mina R, et al. Triplet vs doublet lenalidomide-containing regimens for the treatment of elderly patients with newly diagnosed multiple myeloma. Blood [Internet]. 2016 Mar 3;127(9):1102–8. Available from: https://ashpublications.org/blood/article/127/9/1102/126446/Triplet-vs-doubletlenalidomidecontaining-regimens  
70. Stewart AK, Jacobus S, Fonseca R, Weiss M, Callander NS, Chanan-Khan AA, et al. Melphalan, prednisone, and thalidomide vs melphalan, prednisone, and lenalidomide (ECOG E1A06) in untreated multiple myeloma. Blood [Internet]. 2015 Sep 10;126(11):1294–301. Available from: https://ashpublications.org/blood/article/126/11/1294/34394/Melphalanprednisone-and-thalidomide-vs-melphalan  
71. Palumbo A, Bringhen S, Liberati AM, Caravita T, Falcone A, Callea V, et al. Oral melphalan, prednisone, and thalidomide in elderly patients with multiple myeloma: updated results of a randomized controlled trial. Blood [Internet]. 2008 Oct 15;112(8):3107–14. Available from: https://ashpublications.org/blood/article/112/8/3107/114920/Oral-melphalanprednisone-and-thalidomide-in  
72. Brasil. Ministério da Saúde. Relatório de Recomendação n<sup>o</sup> 702. Daratumumabe em monoterapia ou associado à terapia antineoplásica para o controle do mieloma múltiplo recidivado ou refratário. [Internet]. 2022. Available from: http://conitec.gov.br/images/Relatorios/2022/20220314_Relatorio_702_daratumumabe_mieloma_multiplo.pdf.  
73. Arcuri LJ, Americo AD. Treatment of relapsed/refractory multiple myeloma in the bortezomib and lenalidomide era: a systematic review and network meta-analysis. Ann Hematol [Internet]. 2021 Mar 11;100(3):725–34. Available from: http://link.springer.com/10.1007/s00277-021-04404-3  
74. Botta C, Martino EA, Conticello C, Mendicino F, Vigna E, Romano A, et al. Treatment of Lenalidomide Exposed or Refractory Multiple Myeloma: Network Meta-Analysis of Lenalidomide-Sparing Regimens. Front Oncol [Internet]. 2021 Apr 14;11. Available from: https://www.frontiersin.org/articles/10.3389/fonc.2021.643490/full  
75. Dhakal B, Narra RK, Giri S, Szabo A, Smunt TL, Ghose S, et al. Association of adverse events and associated cost with efficacy for approved relapsed and/or refractory multiple myeloma regimens: A Bayesian network meta‐analysis of  
phase 3 randomized controlled trials. Cancer [Internet]. 2020 Jun 15;126(12):2791–801. Available from: https://onlinelibrary.wiley.com/doi/10.1002/cncr.32831  
76. Weisel K, Sonneveld P, Spencer A, Beksac M, Rizzo M, Xu Y, et al. A comparison of the efficacy of immunomodulatory-free regimens in relapsed or refractory multiple myeloma: a network meta-analysis. Leuk Lymphoma [Internet]. 2019 Jan 2;60(1):151–62. Available from: https://www.tandfonline.com/doi/full/10.1080/10428194.2018.1466392  
77. Zheng Y, Shen H, Xu L, Feng J, Tang H, Zhang N, et al. Monoclonal Antibodies versus Histone Deacetylase Inhibitors in Combination with Bortezomib or Lenalidomide plus Dexamethasone for the Treatment of Relapsed or Refractory Multiple Myeloma: An Indirect-Comparison Meta-Analysis of Randomized Controlled Trial. J Immunol Res [Internet]. 2018 Jun 27;2018:1–20. Available from: https://www.hindawi.com/journals/jir/2018/7646913/  
78. Maiese EM, Ainsworth C, Le Moine J-G, Ahdesmäki O, Bell J, Hawe E. Comparative Efficacy of Treatments for Previously Treated Multiple Myeloma: A Systematic Literature Review and Network Meta-analysis. Clin Ther [Internet]. 2018 Mar;40(3):480-494.e23. Available from: https://linkinghub.elsevier.com/retrieve/pii/S014929181830047X  
79. Zhang T, Wang S, Lin T, Xie J, Zhao L, Liang Z, et al. Systematic review and meta-analysis of the efficacy and safety of novel monoclonal antibodies for treatment of relapsed/refractory multiple myeloma. Oncotarget [Internet]. 2017 May 16;8(20):34001–17. Available from: https://www.oncotarget.com/lookup/doi/10.18632/oncotarget.16987  
80. van Beurden-Tan CHY, Franken MG, Blommestein HM, Uyl-de Groot CA, Sonneveld P. Systematic Literature Review and Network Meta-Analysis of Treatment Outcomes in Relapsed and/or Refractory Multiple Myeloma. J Clin Oncol [Internet]. 2017 Apr 20;35(12):1312–9. Available from: https://ascopubs.org/doi/10.1200/JCO.2016.71.1663  
81. Palumbo A, Chanan-Khan A, Weisel K, Nooka AK, Masszi T, Beksac M, et al. Daratumumab, Bortezomib, and Dexamethasone for Multiple Myeloma. N Engl J Med [Internet]. 2016 Aug 25;375(8):754–66. Available from: http://www.nejm.org/doi/10.1056/NEJMoa1606038  
82. Spencer A, Lentzsch S, Weisel K, Avet-Loiseau H, Mark TM, Spicka I, et al. Daratumumab plus bortezomib and dexamethasone versus bortezomib and dexamethasone in relapsed or refractory multiple myeloma: updated analysis of CASTOR. Haematologica [Internet]. 2018 Dec;103(12):2079–87. Available from: http://www.haematologica.org/lookup/doi/10.3324/haematol.2018.194118  
83. Mateos M-V, Spencer A, Nooka AK, Pour L, Weisel K, Cavo M, et al. Daratumumab-based regimens are highly effective and well tolerated in relapsed or refractory multiple myeloma regardless of patient age: subgroup analysis of the phase 3 CASTOR and POLLUX studies. Haematologica [Internet]. 2020 Feb;105(2):468–77. Available from: http://www.haematologica.org/lookup/doi/10.3324/haematol.2019.217448  
84. Mateos M-V, Sonneveld P, Hungria V, Nooka AK, Estell JA, Barreto W, et al. Daratumumab, Bortezomib, and Dexamethasone Versus Bortezomib and Dexamethasone in Patients With Previously Treated Multiple Myeloma: Threeyear Follow-up of CASTOR. Clin Lymphoma Myeloma Leuk [Internet]. 2020 Aug;20(8):509–18. Available from: https://linkinghub.elsevier.com/retrieve/pii/S2152265019320105  
85. Weisel K, Spencer A, Lentzsch S, Avet-Loiseau H, Mark TM, Spicka I, et al. Daratumumab, bortezomib, and dexamethasone in relapsed or refractory multiple myeloma: subgroup analysis of CASTOR based on cytogenetic risk. J  
Hematol Oncol [Internet]. 2020 Dec 20;13(1):115. Available from: https://jhoonline.biomedcentral.com/articles/10.1186/s13045-020-00948-5 86. Janssen-Cilag. Dalinvi: Solução para diluição para infusão. São José dos Campos; 2020.

---

