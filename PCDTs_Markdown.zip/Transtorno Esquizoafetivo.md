<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 07, DE 14 DE MAIO DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Transtorno Esquizoafetivo.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o transtorno esquizoafetivo no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com este transtorno;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 599/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 604 – Abril de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Transtorno Esquizoafetivo.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do transtorno esquizoafetivo, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é</u> de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do transtorno esquizoafetivo.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais  
e estabelecer os fluxos para o atendimento dos indivíduos com esse transtorno em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.203/SAS/MS, de 4 de novembro de 2014, publicada no Diário Oficial da União nº 214, de 05 de novembro de 2014, seção 1, página 36.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: SERGIO YOSHIMASA OKANE -->
HÉLIO ANGOTTI NETO  
ANEXO

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **1. INTRODUÇÃO** -->
A definição de transtorno esquizoafetivo ainda precisa de maior consenso, podendo ser uma variante da esquizofrenia, na qual os sintomas do humor são excepcionalmente proeminentes e comuns; uma forma grave de transtorno depressivo ou bipolar, na qual os sintomas psicóticos não cedem completamente entre os episódios de humor; ou duas doenças psiquiátricas relativamente comuns concomitantes, a esquizofrenia e um transtorno de humor (transtorno depressivo maior ou transtorno bipolar)<sup>1-3</sup> .  
As controvérsias no diagnóstico do transtorno esquizoafetivo podem ser vistas nos diferentes critérios usados pelos dois maiores sistemas de diagnóstico e classificação em psiquiatria<sup>4,5</sup> . De acordo com os critérios do capítulo F da décima revisão da Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde (CID-10), este diagnóstico requer a presença de sintomas que preencham os critérios de diagnóstico de transtorno de humor (afetivo) em maníaco, depressivo ou misto, de manifestação moderada a grave, e de sintomas que preencham também o diagnóstico de esquizofrenia e que ocorram simultaneamente, pelo menos por algum período de tempo (duas semanas). Já os critérios diagnósticos da quinta edição do Manual Diagnóstico e Estatístico de Transtornos Mentais (DSM5) da Associação Psiquiátrica Americana requerem um episódio de transtorno de humor com sintomas da fase ativa da esquizofrenia ocorrendo concomitantemente, antecedidos ou seguidos por, pelo menos, duas semanas de delírios ou alucinações, sem sintomas proeminentes de humor. Adicionalmente, a DSM-5 preconiza um diagnóstico longitudinal para este transtorno, uma vez que ele só pode ser feito se episódios de humor tenham ocorrido na maior parte do tempo da doença e desde o início dos sintomas psicóticos. Para ambas as classificações, os episódios psicóticos e de humor não podem preencher os critérios das doenças isoladas, nem serem consequência do uso de substâncias psicoativas ou de outras doenças<sup>5</sup> .  
Uma similaridade entre os dois sistemas de classificação<sup>4,5</sup> é que o diagnóstico de transtorno esquizoafetivo está incluído na categoria de esquizofrenia e não em transtornos de  
humor. Possivelmente, a inclusão na categoria de doenças psicóticas influencia a escassez de estudos sobre o tratamento específico sobre o transtorno esquizoafetivo. A grande maioria dos estudos de tratamento medicamentoso da esquizofrenia inclui pacientes com transtorno esquizoafetivo e isso também influi na literatura médica descrita neste Protocolo<sup>1</sup> .  
Além da definição difícil e da necessária exclusão dos diagnósticos de esquizofrenia e de transtorno de humor isolados, o diagnóstico de transtorno esquizoafetivo apresenta pouca estabilidade, pois, conforme o estudo de Santelmann, que avaliou pacientes em um seguimento médio de 2 anos, 19% dos casos migraram para o diagnóstico de esquizofrenia, 14% para transtornos de humor e 6% para outros transtornos<sup>6</sup> . De todo modo, o diagnóstico de transtorno esquizoafetivo representa uma parcela significativa de casos na clínica psiquiátrica que apresentam, simultaneamente, alterações relevantes de humor e de psicose e que requerem medicamentos adequados para o controle dos sintomas<sup>4,5,7,8</sup> .  
As causas dos transtornos esquizofrênicos são, certamente, multifatoriais. Cada paciente apresenta sucessivos fatores de risco que atuam de forma sinérgica, predispondo para a doença. Atualmente, identificam-se fatores genéticos que contribuem com múltiplos genes e interagindo com vários agentes ambientais, desde a formação embrionária primordial. Essas interações podem levar a alterações mediadas pelo desenvolvimento da neuroplasticidade cerebral que se manifestam em uma cascata de disfunções de citocinas, de elementos do sistema imunológico, de neurotransmissores, de circuitos sinápticos e de migração neuronal prejudicada. É aventado que o período gestacional, a infância e adolescência são críticos, pois representam fases do desenvolvimento encefálico em que um ou vários gatilhos podem ter alta relevância para o início do transtorno<sup>1,3,9,10</sup> . Vários fatores ambientais, como infecções virais maternas pré-natais ou complicações obstétricas com hipóxia ou estresse durante o neurodesenvolvimento, foram identificados como detentores de papel causal na esquizofrenia e no transtorno bipolar, possivelmente contribuindo também para o transtorno esquizoafetivo<sup>9,10</sup> .  
As estimativas de prevalência do transtorno esquizoafetivo correspondem à metade da prevalência estimada para esquizofrenia, afetando, assim, aproximadamente 0,5% da população (0,3%-1,5%), dependendo dos critérios diagnósticos utilizados. Inexiste evidência de diferença entre os sexos. No Brasil, em estudos de 1992 e de 2012, realizados em São Paulo, foram encontradas prevalências de psicose em geral de 0,3%-2,4% na população<sup>11-13</sup> .  
A identificação de fatores de risco e do transtorno em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do transtorno esquizoafetivo. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 2** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- F25.0 - Transtorno esquizoafetivo do tipo maníaco  
- F25.1 - Transtorno esquizoafetivo do tipo depressivo  
- F25.2 - Transtorno esquizoafetivo do tipo misto

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **3. DIAGNÓSTICO** -->
O diagnóstico é clínico e baseado nos critérios operacionais da CID-10<sup>4</sup> . Esse formato de classificação descreve critérios gerais (nomeados com a letra G e numerados de 1 a 4), que precisam ser atendidos em todos os casos. O primeiro deles (G1) é a presença de sintomas de humor; o segundo (G2), a presença de sintomas de psicose; o terceiro (G3), a simultaneidade desses sintomas; e o quarto (G4), a exclusão de outras condições semelhantes<sup>4</sup> . Os critérios estabelecidos no DSM-5, mencionados anteriormente, podem ser considerados na avaliação para maior precisão diagnóstica.  
É importante ressaltar que o diagnóstico, a indicação terapêutica e o acompanhamento dos pacientes devem ser realizados por médico psiquiatra, qualificado e com experiência com transtornos esquizoafetivos, dada a sua complexidade e gravidade.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **Diretrizes Operacionais da CID-10 para o diagnóstico de Transtorno Esquizoafetivo** -->
O diagnóstico depende de uma avaliação clínica criteriosa que busque identificar um equilíbrio aproximado entre o número, a gravidade e a duração dos sintomas. Sempre que possível, preconiza-se que a história clínica seja obtida de mais de uma fonte e, na persistência de dúvidas, ela deve ser complementada com documentos prévios de atendimentos médicos.  
<u>Passos para o diagnóstico:</u>  
**Passo 1** – Verificar a presença dos critérios gerais. Todos devem ser atendidos.  
**- G1 -** O transtorno satisfaz os critérios básicos de um dos transtornos de humor (afetivos) de grau moderado ou grave, conforme especificado para cada subtipo de transtorno esquizoafetivo na CID-10. Os subtipos são F25.0, F25.1 e F25.2 - maníaco, depressivo e misto, respectivamente (ver o **Quadro 1** )<sup>14</sup> .  
**- G2 -** Os sintomas de, pelo menos, um dos grupos listados a seguir estão claramente presentes durante a maior parte do tempo por um período de, pelo menos, duas semanas (praticamente os mesmos da esquizofrenia):  
1) eco de pensamento, inserção ou retração de pensamento, irradiação de pensamento;  
2) delírios de controle, influência ou passividade claramente relacionados a movimento de corpo, de membros ou sobre pensamentos, ações ou sensações específicas;  
3) vozes alucinatórias que fazem comentários sobre o comportamento do paciente ou discutem entre si; ou outros tipos de vozes alucinatórias advindas de alguma parte do corpo (cabeça, tronco, mãos etc.);  
4) delírios persistentes de outros tipos que são culturalmente inapropriados e completamente impossíveis, porém, não meramente megalomaníacos ou persecutórios (por exemplo, visita a outros mundos, o poder de controlar as nuvens inspirando e expirando, o poder de comunicar-se com animais ou plantas sem precisar falar, etc.);  
5) fala totalmente irrelevante ou incoerente ou uso frequente de neologismos;  
6) surgimento intermitente, porém frequente, de algumas formas de comportamento catatônico, tais como postura inadequada, flexibilidade cérea e negativismo.  
**- G3 -** Os critérios G1 e G2 devem ser satisfeitos **dentro do mesmo episódio do transtorno e simultaneamente durante, pelo menos, algum tempo do episódio** . Sintomas tanto dos critérios G1 como dos G2 devem ser proeminentes no quadro clínico.  
**- G4 -** Os critérios de exclusão mais comumente utilizados consideram o fato de o transtorno não ser atribuível à doença cerebral orgânica, à intoxicação, à dependência ou abstinência relacionada a álcool ou outras drogas.  
**Passo 2 -** Além dos critérios gerais que permitem o uso do código F25 da CID-10, o paciente será classificado em um de três tipos específicos, que receberá um dígito adicional após o número 25.  
O **Quadro 1** descreve os sintomas necessários para preenchimento do critério G1 (Transtornos de humor-afetivo) e definidores dos subtipos de transtorno esquizoafetivo, conforme a CID-10.  
**Quadro 1 -** Sintomas necessários para o preenchimento do critério G1 (transtornos de humor-afetivo) e definidores dos subtipos de transtorno esquizoafetivo, conforme a CID-10.  
|Código da<br>CID-10|Critérios básicos|Tempo<br>mínimo(dias)|Critérios adicionais|
|---|---|---|---|
|F25.0<br>Esquizo<br>Maníaco|(a)<br>Elevado/expansí<br>vel/<br>Irritável e<br>claramente<br>anormal|7|Pelo menos 3 dos abaixo (4 se humor<br>irritável):<br>(b) atividade aumentada/inquietação física;<br>(c) loquacidade aumentada;<br>(d) fuga de ideias/experiência de<br>pensamentos acelerados;<br>(e) perda de inibições/comportamento<br>inapropriado;<br>(f) diminuição da capacidade de sono;<br>(g) autoestima infladagrandiosidade;<br>(h) distratibilidade/mudança rápida de<br>planos;<br>(i) comportamento temerário/imprudente;<br>(j) energia sexual marcante/indiscrição sexual.|
|F25.1<br>Esquizo<br>Depressivo|Pelo menos 2<br>de (a), (b), (c):<br>(a) humor<br>deprimido<br>anormal;<br>(b) perda de<br>interesse/pr<br>azer;<br>(c) energia<br>diminuída.|14|Pelo menos 1 ou mais de:<br>(d) perda de confiança ou autoestima;<br>(e) sentimentos irracionais de auto-<br>reprovação/culpa;<br>(f) pensamentos de<br>morte/suicídio/comportamento suicida;<br>(g) queixas ou evidências de indecisão;<br>(h) desatenção;<br>(i) diminuição da concentração;<br>(j) alteração psicomotora: agitação ou<br>lentidão;<br>(k) alterações do sono/apetite com alteração<br>de peso|
|F25.2<br>Esquizoafetiv<br>o<br>Misto|Pelo menos 1<br>de (a), (b):<br>(a) sintomas<br>maníacos e<br>depressivos<br>simultâneos<br>.<br>(b) sintomas<br>maníacos e<br>depressivos<br>com<br>alternância<br>rápida.|14|Passado com pelo menos 1 de (a), (b), (c):<br>(a) episódio afetivo maníaco;<br>(b) hipomaníaco;<br>(c) misto.|  
Os quadros de humor e os sintomas de mania e de depressão devem ser medidos por escalas de uso público ( _Patient Health Questionnaire – PHQ_<sup>9</sup> _, Escala de Mania de Young) para o_ diagnóstico do transtorno esquizoafetivo<sup>15-19</sup> . Essas escalas estão incluídas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nesse Protocolo os pacientes que preencherem os critérios para o diagnóstico de transtorno esquizoafetivo descritos no item 3. Diagnóstico, acima, e com a adesão ao serviço de atendimento psiquiátrico ambulatorial ou de internação indicado. No caso de paciente com grave prejuízo funcional e perda da autonomia, que exija tratamento em regime de internação, é necessária a presença de um familiar ou responsável legal. No caso de paciente cronicamente asilado, é requerida a presença de um familiar ou funcionário da instituição disponível e capaz de controlar fatores estressores do ambiente de forma contínua.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos do tratamento medicamentoso os pacientes com diagnóstico de transtorno esquizoafetivo que apresentarem intolerância, hipersensibilidade ou contraindicação ao respectivo fármaco preconizado neste Protocolo, psicose alcoólica ou tóxica, dependência ou abuso atual de fármacos psicoativos e impossibilidade de adesão ao tratamento ou de acompanhamento contínuo. Esses pacientes deverão participar de programas que motivem a adesão e os tornem elegíveis ao tratamento medicamentoso.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **6. CASOS ESPECIAIS** -->
O tratamento medicamentoso em pacientes grávidas deve ser avaliado de acordo com o risco de piora do transtorno esquizoafetivo ao longo da gestação, bem como o risco de uso de determinados fármacos para o desenvolvimento do feto, já que existem desfechos negativos para recém-nascidos de mães com sintomatologia psicótica ativa. Nos casos em que se fizer necessário, usar antipsicótico. Os mais indicados, conforme a categoria de risco são: haloperidol, risperidona e olanzapina<sup>20, 21</sup> .  
O diagnóstico de transtorno esquizoafetivo em crianças e adolescentes é ainda mais complexo do que em adultos. Aqueles pacientes em que haja hipótese diagnóstica devem ser encaminhados para a avaliação em serviços especializados em pródomos de transtornos psicóticos e ambulatórios de primeiro episódio de transtornos psicóticos. A mesma complexidade  
adicional se aplica ao tratamento do transtorno esquizoafetivo nessas faixas etárias.  
Idosos devem ser avaliados de forma particularizada, dada à alta prevalência de comorbidades clínicas e o risco de interação medicamentosa entre diversos fármacos.  
Os pacientes com risco de suicídio devem ser avaliados criteriosamente e tratados de acordo com a gravidade do caso, de modo compatível com o preconizado no Protocolo de Prevenção do Suicídio do Ministério da Saúde<sup>22</sup> .

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **7.1. Tratamento não medicamentoso** -->
Existem evidências favoráveis do efeito de diferentes modalidades de terapia sobre o curso do transtorno esquizoafetivo e do transtorno esquizofrênico, como por exemplo, as terapias cognitivas, físicas, psicológicas, educacionais e de estimulação cognitiva<sup>23</sup> , mas o escopo deste Protocolo é abordar exclusivamente o tratamento medicamentoso do transtorno esquizoafetivo.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **7.2. Tratamento medicamentoso** -->
Na última década do século XX e na primeira do atual, amplo debate foi realizado sobre a superioridade dos novos medicamentos antipsicóticos no tratamento da esquizofrenia e do transtorno esquizoafetivo. Os ensaios clínicos de tratamento medicamentoso agrupam pacientes com esquizofrenia e com transtorno esquizoafetivo e chegaram ao consenso de que a eficácia de todos os antipsicóticos é semelhante na maior parte dos pacientes, com exceção da clozapina<sup>14,15,24-39</sup> . Sendo assim, os antipsicóticos podem ser utilizados **<u>sem</u>** ordem de preferência no tratamento do transtorno esquizoafetivo em pacientes que preencham os critérios de inclusão deste PCDT.  
Para grupos especiais, como crianças, adolescentes e pessoas idosas, a eficácia dos medicamentos é semelhante e deverão ser observados os critérios de indicação de acordo com características do paciente e acesso aos medicamentos disponíveis. Inexiste superioridade do uso de combinações de antipsicóticos _versus_ monoterapia, apenas diferenças na tolerância<sup>40-42</sup> . O tratamento, portanto, deve ser feito com antipsicótico, considerando o perfil de segurança e a tolerabilidade do fármaco e as características individuais do paciente.  
A clozapina é considerada superior para pacientes não responsivos a outros antipsicóticos e sua indicação permanece para esses casos. Assim, ela pode ser utilizada frente à refratariedade a, pelo menos, dois medicamentos utilizados por, no mínimo, seis semanas, em  
doses adequadas e sem melhora de, ao menos, 30% na Escala Breve de Avaliação Psiquiátrica - _Brief Psychiatric Rating Scale_ ( _BPRS)_<sup>43</sup> (ver no **Apêndice 1** ). Também pode ser utilizada em caso de alto risco de suicídio, agressividade intensa e discinesia tardia, mesmo antes de se completarem seis semanas de tratamento ou de se observar melhora de 30% no quadro<sup>44-49</sup> . Caso haja intolerância por agranulocitose, após indicação por refratariedade, a clozapina poderá ser trocada por olanzapina, quetiapina, risperidona ou ziprasidona; preferencialmente por aquelas que não foram utilizadas nos dois tratamentos iniciais. Inexiste evidência de que a adição de um segundo antipsicótico, após o uso da clozapina, possa trazer benefícios aos pacientes<sup>1</sup> .  
O decanoato de haloperidol é um antipsicótico de ação prolongada (APAP) de uso intramuscular (IM) para tratamento de manutenção do transtorno esquizoafetivo e pode ser a primeira linha de tratamento em pacientes com problemas de adesão ao tratamento medicamentoso. É importante ressaltar que, comparado aos outros antipsicóticos de ação prolongada existentes, a eficácia do decanoato de haloperidol é semelhante, mas é importante ficar-se atento à tolerabilidade e aos eventos adversos. Por esse motivo, seu uso é recomendável em pacientes já estabilizados com formulações orais do mesmo fármaco.  
Quanto aos estabilizadores do humor, apesar de o lítio ser muito utilizado, não existe evidência para o seu uso no transtorno esquizoafetivo. Uma meta-análise relata alguma evidência de lítio como terapia adjunta nos transtornos esquizoafetivos do tipo esquizomaníaco, porém recomenda mais estudos nos pacientes com este transtorno<sup>50</sup> .  
Os antidepressivos, embora também frequentemente utilizados nos quadros de transtorno esquizoafetivo do tipo esquizodepressivo, demonstraram, em uma meta-análise, eficácia com evidência fraca para os inibidores seletivos de serotonina e imipramina<sup>51</sup> . Quanto aos inibidores de recaptação de noradrenalina, outra meta-análise mostrou que eles não são efetivos<sup>52</sup> .  
Nos casos de insônia acentuada associada ao transtorno esquizoafetivo, as condutas terapêuticas da insônia primária e secundária podem ser seguidas. Deve ser investigado se o transtorno da insônia está associado à persistência de delírios, depressão ou mania e, neste caso, a insônia deve ser tratada com o ajuste da dose do antipsicótico utilizado. Caso a insônia esteja associada a estressores ambientais ou à má higiene de sono, medidas gerais de controle desses fatores devem ser adotadas. Deve-se evitar hábitos que desregulam o ciclo circadiano do paciente, tais como: ficar muito tempo na cama, ausência de exposição à luz, baixa atividade física, exposição à televisão e a equipamentos eletrônicos (computador, celular, tablet) durante à  
noite. Também deve-se evitar ao máximo o uso de medicamentos benzodiazepínicos, devido ao seu potencial de dependência química.  
**Nota:** A adoção de hábitos e atividades que induzem e melhoram a qualidade do sono constitui a higiene do sono. Assim, é saudável adotar refeição leve ou em hora distante da de dormir e evitar, à noite, a ingestão de bebida que contenha cafeína ou de bebida alcoólica, a prática de atividade física intensa e o uso do celular ou equipamento similar antes de se deitar.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **7.3. Fármacos** -->
- Biperideno: comprimido de 2 e 4 mg.  
- Clorpromazina: comprimidos de 25 e 100 mg; solução oral de 40 mg/mL.  
- Clozapina: comprimidos de 25 e 100 mg.  
- Decanoato de haloperidol: solução injetável 50 mg/mL.  
- Haloperidol: comprimido de 1 e 5 mg; solução oral 2 mg/mL.  
- Olanzapina: comprimidos de 5 e 10 mg.  
- Propranolol: comprimido de 10 e 40 mg.  
- Quetiapina: comprimidos de 25, 100 e 200 e 300 mg.  
- Risperidona: comprimidos de 1, 2 e 3 mg.  
- Ziprasidona: cápsulas de 40 e 80 mg.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **7.4. Esquemas de administração** -->
**Biperideno:** Poderá ser utilizado na dose de 1 a 16 mg, divididos em 1 a 4 administrações ao dia, dependendo da intensidade dos sintomas. Aprovado para uso adulto e pediátrico acima de três anos.  
**Clorpromazina:** Iniciar com doses pequenas, entre 50 e 100 mg por via oral (VO), 2 a 3 vezes ao dia, para atenuar possíveis efeitos adversos. Sua meia-vida de 24 horas permite administrações uma vez ao dia. Doses médias diárias variam entre 400 e 800 mg, sendo 1 g a dose máxima preconizada. Doses abaixo de 150 mg estão relacionadas a maior chance de recidiva de sintomas. Após 2 a 5 dias alcança equilíbrio de concentração no sangue. Diferentes substâncias, como café, cigarro e antiácidos, diminuem sua absorção. No caso de insucesso na redução ou suspensão dessas substâncias, pode-se considerar a administração de doses maiores, respeitando a dose máxima preconizada. Aprovado para uso adulto e pediátrico acima de dois anos.  
**Clozapina:** Iniciar com a dose de 12,5 mg VO, em tomada única à noite, podendo ser aumentada em 25 mg a cada 1 a 2 dias, até a dose de 300 a 400 mg/dia, conforme resposta e  
tolerância. Após 30 dias sem melhora, pode-se aumentar 50 mg a cada 3 a 4 dias até 800 mg/dia. Doses acima de 400 mg podem ser fracionadas em 2 a 3 administrações para aumentar a tolerância do paciente. Aprovado para uso adulto.  
**Decanoato de haloperidol:** A dose indicada é de 150-200 mg/mês, para a maioria dos casos, aplicada por via intramuscular profunda a cada 4 semanas e, em casos mais graves, até 2 vezes ao mês. Sua meia-vida é de cerca de 3 semanas, levando entre 3 e 6 meses para estabilizar sua concentração plasmática. Por tal motivo, pode-se iniciar com doses maiores de até 400 mg/mês e com frequência semanal nos primeiros meses. Alternativamente, pode-se iniciar com doses usuais e suplementar com haloperidol oral até a dose máxima de 15 mg/dia, conforme tolerância, no primeiro mês. Aprovado para uso adulto.  
**Haloperidol:** Iniciar com doses fracionadas de 0,5 a 2 mg VO, 2 a 3 vezes ao dia para minimizar efeitos adversos, até a dose máxima de 15 mg/dia, em situações agudas e, de 10 mg/dia, para manutenção. Pode ser administrado uma vez ao dia, pois tem meia-vida de 24 horas. Doses maiores parecem não ter benefício e aumentam a incidência de efeitos adversos. As doses devem ser reduzidas até o nível mais baixo de efetividade. Pacientes idosos geralmente requerem doses menores. Aprovado para uso adulto.  
**Olanzapina:** Iniciar com 5 mg à noite VO. Aumentar em 5 mg após um mínimo de 7 dias, até uma dose total diária de 20 mg/dia, independente das refeições. Não há evidências de que doses acima de 20 mg/dia em pacientes não refratários sejam mais eficazes. Não é necessário ajuste de dose em casos de insuficiência renal ou hepática. Pacientes fisicamente debilitados ou emagrecidos devem receber, no máximo, 5 mg/dia. A olanzapina pode ser utilizada até a dose de 30 mg/dia quando for substituir a clozapina na vigência de efeitos adversos graves, como agranulocitose, cardiopatia e oclusão intestinal e sem condições de reintrodução da mesma<sup>19,55,56</sup> . Aprovado para uso adulto.  
**Propranolol:** Poderá ser utilizado na dose de 40 a 160 mg em 2 a 3 vezes por dia. Aprovado para uso adulto e pediátrico.  
**Quetiapina:** Iniciar com 25 mg, 2 vezes ao dia VO. Aumentar a dose em 25 a 50 mg por dia nos primeiros 4 dias, com o objetivo de alcançar 300 a 450 mg/dia entre o quarto e sétimo dia de tratamento. A dose total pode ser dividida em 2 ou 3 vezes ao dia. O ajuste pode ser feito com incrementos ou diminuições de 25 a 50 mg, 2 vezes ao dia ou em intervalo de 2 dias, dependendo da resposta clínica e da tolerabilidade do paciente. A dose máxima fica entre 750 e 800 mg/dia<sup>18</sup> . Aprovado para uso adulto.  
**Risperidona:** Iniciar com 1 mg, 2 vezes ao dia por VO, para evitar efeito de primeira dose (bloqueio alfa-adrenérgico). Aumentar em 1 mg, 2 vezes ao dia, até que uma dose-alvo de 6 mg/dia seja alcançada no terceiro dia (3 mg, 2 vezes ao dia). As doses preconizadas de manutenção são de 3-6 mg/dia. Se o uso for suspenso, a administração deve ser reiniciada conforme a primeira dose. Em pacientes com insuficiência renal ou hepática, a dose máxima preconizada é de 3 mg/dia. A administração simultânea com alimentos não interfere na biodisponibilidade do medicamento<sup>53, 54</sup> . Aprovado para uso adulto e pediátrico acima de 5 anos. **Ziprasidona:** Iniciar com 40 mg, 2 vezes ao dia VO, com alimentos. Aumentar a dose em intervalos superiores a 2 dias até a dose máxima de 160 mg/dia (80 mg, 2 vezes ao dia). A dose de manutenção ideal é de 40 mg, 2 vezes ao dia. A dose máxima de 160 mg/dia pode ser alcançada no terceiro dia de tratamento, se necessário. Aprovado para uso adulto.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **7.5. Benefícios esperados** -->
Melhora do quadro clínico em seus aspectos psicopatológicos como sintomas psicóticos, afetivos, cognitivos e a restauração da funcionalidade do indivíduo. A melhora pode ser avaliada por meio de entrevista que fornece informações para o preenchimento de uma escala clínica com 18 itens, dos quais 8 são preenchidos pela observação e 10 por questões guia, com descritores de gravidade de cada sintoma. Espera-se uma diminuição de, pelo menos, 30% nos escores da escala _BPRS-A_ . As escalas de avaliação do humor _PHQ_<sup>9</sup> e de mania _Young Beck e Calgary_ devem também ser aplicadas<sup>4</sup> . Essas escalas estão incluídas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **8. MONITORAMENTO** -->
Para cada um dos medicamentos deste Protocolo, devem ser observadas as contraindicações relativas e absolutas, considerando a relação entre o risco e o benefício de seu uso. Diante de efeitos adversos ou complicações do transtorno propriamente dito, o tratamento deverá ser interrompido ou modificado. Uma conduta conservadora do tratamento é a introdução lenta do medicamento, com o aumento progressivo até a dose-alvo, que não será, necessariamente, a dose máxima. Essa estratégia pode efetivamente reduzir efeitos adversos no início do tratamento, porém pode também retardar a obtenção de reposta terapêutica. De um modo geral, os pacientes que não melhoram após seis semanas de tratamento com dose máxima de um dos medicamentos, que não aderem ao tratamento ou não apresentam melhora mínima de 30% nos escores da BPRS, também devem ter seu tratamento interrompido ou modificado.  
Na presença de discinesia tardia significativa, o antipsicótico em uso deve ser substituído por clozapina. Caso contrário, deve ser feito o diagnóstico diferencial com discinesia aguda e outros efeitos extrapiramidais que surgem a curto prazo no tratamento. Quanto ao suicídio, seu risco deve ser avaliado continuamente e alterações da medicação devem ser feitas, mesmo antes de tentativas de suicídio. Nos pacientes que apresentam alto risco de suicídio, ou tentativas, o antipsicótico em uso deve ser substituído por clozapina. Frente à má adesão à terapia, o antipsicótico oral deve ser substituído por decanoato de haloperidol.  
Antes do início do tratamento com qualquer um dos medicamentos, é obrigatória a avaliação dos seguintes aspectos: idade, medidas antropométricas (peso, altura, circunferência abdominal e do quadril), três medidas de pressão arterial e de pulso em datas diferentes, hemograma, concentração de sódio e potássio, contagem de plaquetas e dosagens de colesterol total e frações e triglicerídios e glicemia de jejum.  
Enquanto o doente estiver sintomático, o tratamento com antipsicótico será contínuo, sob supervisão médica, familiar ou institucional, como também para prevenção de recaídas. A melhora clínica é definida por meio de entrevista que forneça informações para o preenchimento de escalas clínica e de avaliação de humor, sendo esperada a diminuição de, pelo menos, 30% nos escores, conforme mencionado no item 7.5. Benefícios Esperados _._ As escalas de humor _PHQ9_<sup>16</sup> e de mania de _Young_<sup>17</sup> (ver no **Apêndice 1** ) devem ser aplicadas para monitorar sintomas depressivos e maníacos concomitantes.  
Durante o tratamento, devem ser repetidas as medidas antropométricas, da pressão arterial e de pulso em três, seis e doze meses. Os exames laboratoriais, com determinação perfil lipídico, da glicemia de jejum e de eletrólitos, devem ser feitos em três e doze meses. Após o seguimento de doze meses, a monitorização deve ser repetida anualmente. Em caso de alterações significativas, deverá ser feita uma avaliação clínica, com discussão sobre o risco e o benefício do tratamento, em conjunto com a família e o paciente, já que comorbidades podem acontecer na vigência do uso de um antipsicótico (hipertensão arterial, ganho de peso significativo, diabete mélito, secreção inadequada de hormônio antidiurético com hiponatremia persistente, cardiopatia com prejuízo significativo, síndrome metabólica persistente e insônia). Estas comorbidades podem ser controladas com a troca por outro antipsicótico e com o tratamento específico, se necessário<sup>1,57,58</sup> .  
Após a melhora clínica, deve-se estipular, para todos os medicamentos indicados neste Protocolo, a redução cuidadosa da dose para a fase de manutenção ou a manutenção do tratamento com a mesma dose utilizada para se obter o melhor efeito clínico. Em ambos os casos,  
a escolha deve ser feita com base no histórico do paciente, acompanhamento clínico e psiquiátrico, além de avaliações objetivas com medidas de sintomas e comportamentos (escala BPRS-A). O tratamento deve ser continuamente reavaliado quanto à eficácia e segurança pelo médico responsável.  
A dosagem do nível sérico de prolactina deverá ser solicitada sempre que houver sinais e sintomas sugestivos de alterações hormonais, como diminuição da libido, alterações menstruais, impotência, ginecomastia e galactorreia. Se houver aumento do nível sérico de prolactina acima de 25 ng/mL nas mulheres ou acima de 20 ng/mL nos homens, acompanhado ou não de sintomas, há indicação de troca de antipsicótico. A relação entre o risco e o benefício da troca deve ser sempre avaliado<sup>1</sup> .  
Podem ocorrer sintomas adversos extrapiramidais motores, descritos como a ocorrência de, pelo menos, um dos seguintes grupos: distonia, discinesia, acatisia e parkinsonismo (tremor, rigidez e bradicinesia) e que aparecem nos três primeiros meses de tratamento, normalmente nas primeiras semanas. Na presença desses efeitos adversos e após ajuste de dose, prometazina, biperideno ou propranolol são indicados como terapêutica. Na persistência dos sintomas, a substituição por outro antipsicótico com menos efeitos extrapiramidais, como olanzapina, quetiapina ou ziprasidona, é indicada. Preconiza-se a avaliação dos sintomas extrapiramidais pelas escalas de sintomas extra-piramidais<sup>59</sup> , _Barnes Akathisia Rating Scale e Abnormal Involuntary Movement Scale (AIMS)_<sup>60</sup> .  
Os medicamentos antipsicóticos têm sido relacionados com a Síndrome Neuroléptica Maligna (SNM), uma reação idiossincrática rara caracterizada por hipertermia, rigidez muscular generalizada, instabilidade autonômica (pulso ou pressão arterial irregular, taquicardia, diaforese e arritmia cardíaca), alteração da consciência e elevação sérica dos níveis de creatininofosfoquinase. Outros sinais podem incluir, ainda, mioglobinúria (rabdomiólise) e insuficiência renal aguda, que são potencialmente fatais. Hipertermia é geralmente um sinal precoce dessa síndrome. A avaliação diagnóstica dos pacientes é complicada. Para chegar a um diagnóstico, é importante excluir outras complicações e doenças graves. O tratamento antipsicótico deve ser suspenso imediatamente e a terapia intensiva de suporte instituída com monitoramento cauteloso. Inexiste consenso sobre o tratamento medicamentoso específico para SNM. Se um paciente necessitar de tratamento com medicamento antipsicótico após sua recuperação, a reintrodução deve ser cuidadosamente considerada e o paciente deve ser monitorado, tendo em vista o risco de reaparecimento da síndrome<sup>61</sup> .  
As características a serem observadas antes e durante a utilização de cada  
medicamento estão descritas no **Quadro 2** .

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: Esquizoafetivo -->
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|Clorpromazin<br>a:<br>300-1000<br>mg/dia|-glaucoma de<br>ângulo fechado;<br>-risco de retenção<br>urinária;<br>-uso<br>concomitante de<br>levodopa;<br>-comas<br>barbitúricos e<br>etílico;<br>-sensibilidade às<br>fenotiazinas;<br>-doença cardíaca<br>grave;<br>-depressão do<br>SNC;<br>-discrasia<br>sanguíneas;<br>-câncer de mama;<br>-doenças<br>hepática, de<br>Parkinson,<br>epilepsia e úlcera<br>péptica.|-Observação<br>de sinais e<br>sintomas<br>clínicos.|-distonia<br>significativa;<br>-sintomas<br>extrapiramidais<br>resistentes ao<br>tratamento com<br>biperideno ou<br>propranolol;<br>-<br>hiperprolactinemia<br>com sintomas;<br>-depressão grave<br>do SNC.|-ganho de peso;<br>-sedação, sonolência,<br>síndrome<br>extrapiramidal, efeitos<br>atropínicos;<br>-hipotensão<br>ortostática;<br>-discinesias tardias que<br>podem ser observadas,<br>assim como para todos<br>os neurolépticos,<br>durante tratamentos<br>prolongados.|  
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|Clozapina:<br>300-800<br>mg/dia|-pacientes<br>incapazes de<br>realizarem<br>hemogramas<br>regulares;<br>-antecedente de<br>granulocipenia /<br>agranulocitose<br>tóxica ou<br>idiossicrática e<br>distúrbios<br>hematopoiéticos;<br>-epilepsia não<br>controlada;<br>-psicoses alcóolica<br>e tóxica;<br>-colapso<br>circulatório ou<br>depressão do SNC;<br>-doenças cardíaca,<br>renal ou hepática<br>graves;<br>-íleo paralítico.|-sintomas<br>típicos de<br>gripe, febre,<br>dor de<br>garganta;<br>-hemograma<br>semanal nas<br>primeiras 18<br>semanas;<br>-febre<br>persistente;<br>- taquicardia<br>e cansaço:<br>ecocardiogra<br>ma ou<br>enzimas<br>cardíacas;<br>-hábito<br>intestinal.|-<br>citopenias(leucócit<br>os < 3.000/mm<sup>3</sup>;<br>neutropenia <<br>1.500/mm<sup>3</sup>;<br>plaquetopenia <<br>100.000/mm<sup>3</sup>);<br>-possibilidade de<br>reação<br>inflamatória de<br>origem imune<br>(miocardiopatia,<br>pericardite,<br>pleurite,<br>panserosite);<br>-sintomas<br>extrapiramidais<br>resistentes ao<br>tratamento com<br>biperideno ou<br>propranolol;<br>-convulsões;<br>-constipação com<br>risco de obstrução<br>intestinal;.<br>-gravidez e<br>amamentação.|-sonolência/sedação,<br>vertigem;<br>-taquicardia;<br>-constipação;<br>-hipersalivação.|
|Haloperidol:<br>5-15 mg/dia|-estados<br>comatosos;<br>-depressão do<br>SNC por álcool ou<br>outras drogas;<br>-doença de<br>Parkinson;<br>-lesão de gânglios<br>de base.|- Observação<br>de sinais e<br>sintomas<br>clínicos.|- distonia<br>significativa;<br>- sintomas<br>extrapiramidais<br>resistentes ao<br>tratamento com<br>biperideno ou<br>propranolol.|-distúrbios<br>extrapiramidais;<br>-hipercinesia<br>(movimentação<br>excessiva e atípica do<br>corpo e membros).|  
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|Olanzapina:<br>Até 20<br>mg/dia|-<br>hipersensibilidade<br>conhecida a<br>qualquer um dos<br>componentes da<br>formulação do<br>medicamento.|-peso;<br>-pressão<br>arterial;<br>-glicemia;<br>-lipídios.|-ganho de peso<br>acima de 7% do<br>seu peso;<br>-desenvolvimento<br>de obesidade;<br>-hipertensão<br>arterial;<br>-dislipidemia;<br>-diabete melito;<br>-resistência<br>insulínica;<br>-gravidez ou<br>lactação.|-ganho de peso;<br>-boca seca;<br>-aumento de apetite;<br>-aumento de tremores;<br>-hipotensão<br>ortostática;<br>-sonolência;<br>-aumento da<br>prolactina;<br>-colesterol total de<br>jejum limítrofe a<br>elevado (≥ 200 mg/dL e<br>< 240 mg/dL a ≥ 240<br>mg/dL);<br>-triglicérides de jejum<br>limítrofe a elevado (≥<br>150 mg/dL e < 200<br>mg/dL a ≥ 200 mg/dL);<br>-glicemia de jejum<br>limítrofe a elevada (≥<br>100 mg/dL e < 126<br>mg/dL a ≥ 126 mg/dL).|
|Quetiapina:<br>Até 800<br>mg/dia|-<br>hipersensibilidade<br>conhecida a<br>qualquer um dos<br>componentes da<br>formulação do<br>medicamento.|-peso;<br>-pressão<br>arterial;<br>-glicemia;<br>-lipídios;|-ganho<br>de<br>peso<br>acima de 7% do seu<br>peso;<br>-desenvolvimento<br>de obesidade;<br>-hipertensão<br>arterial;<br>-dislipidemia;<br>-diabete melito;<br>-resistência<br>insulínica;<br>-gravidez ou<br>lactação.|-sonolência;<br>-tontura;<br>-boca seca;<br>-sintomas<br>de<br>abstinência<br>por<br>suspensão;<br>-elevação<br>nos<br>níveis<br>séricos de triglicérides;<br>-elevação no colesterol<br>total<br>(predominantemente<br>no LDL);<br>-redução do colesterol<br>HDL;<br>-aumento de peso;|  
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|||||-redução<br>da<br>hemoglobina;<br>-sintomas<br>extrapiramidais.|  
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|Risperidona:<br>Até 6 mg/dia|-<br>hipersensibilidade<br>conhecida a<br>qualquer um dos<br>componentes da<br>formulação do<br>medicamento.|-pressão<br>arterial;<br>-glicemia;<br>-peso;<br>-eletrólitos;<br>-lipídios.|-<br>hiperprolactinemia<br>;<br>-sintomas<br>extrapiramidais<br>resistentes ao<br>tratamento com<br>biperideno ou<br>propranolol;<br>-gravidez ou<br>amamentação.|*Efeitos adversos que<br>ocorremem mais que<br>5% dos pacientes:<br>-vômito;<br>-constipação;<br>-boca seca;<br>-náusea;<br>-hipersecreção salivar;<br>-fadiga;<br>-febre;<br>-sede;<br>-nasofaringite;<br>-rinite;<br>-infecção do trato<br>respiratório superior;<br>-aumento de peso;<br>-aumento de apetite;<br>-sedação;<br>-incontinência salivar;<br>-cefaleia;<br>-tremor;<br>-tontura;<br>-sintomas<br>extrapiramidais;<br>-enurese (incontinência<br>urinária);<br>-tosse, coriza,<br>congestão nasal;<br>-erupção cutânea.|  
|**Medicament**<br>**o e dose**<br>**máxima**|**Contraindicações**<br>**para uso**|**Monitorizaçã**<br>**o na**<br>**utilização**|**Interrupção do**<br>**tratamento**|**Efeitos adversos muito**<br>**comuns (>10%)**|
|---|---|---|---|---|
|Ziprasidona:<br>Até 160<br>mg/dia|-Pacientes com<br>intervalo QT<br>prolongado<br>conhecido<br>(síndrome<br>congênita de QT<br>prolongado,<br>infarto cardíaco<br>recente,<br>insuficiência<br>cardíaca<br>descompensada,<br>arritmias, uso de<br>antiarrítmicos).|-<br>Eletrocardiog<br>rama|-prolongamento do<br>intervalo QT > 500<br>ms;<br>-gravidez e<br>amamentação.|-insônia;<br>-sonolência;<br>-cefaleia;<br>-mania;<br>-agitação;<br>-ansiedade;<br>- distonia;<br>-distúrbio<br>extrapiramidal;<br>-discinesia tardia;<br>-discinesia;<br>-hipertonia;<br>-acatisia;<br>-tremor;<br>-tontura;<br>-sedação;<br>-taquicardia;<br>-vômito;<br>-constipação;<br>-náusea;<br>-hipersecreção salivar;<br>-boca seca;<br>-dispepsia;<br>-disfunção sexual<br>masculina;<br>-astenia;<br>-fadiga;<br>-aumento de peso (1%<br>a 10% dos pacientes).|

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
O atendimento dos pacientes com transtorno esquizoafetivo deve seguir os critérios, normas e diretrizes estabelecidos pelo Ministério da Saúde para a Rede de Atenção à  
Saúde Psicossocial (RAPS)<sup>62</sup> . A proposta da RAPS é garantir a livre circulação das pessoas com problemas mentais pelos serviços, pela comunidade e pela cidade. A RAPS estabelece os pontos de atenção para o atendimento de pessoas com problemas mentais, incluindo os efeitos nocivos do uso de crack, álcool e outras drogas e é composta por serviços e estabelecimentos variados, tais como: os Centros de Atenção Psicossocial (CAPS); os Serviços Residenciais Terapêuticos (SRT); os Centros de Convivência e Cultura; as Unidade de Acolhimento (UA); e os leitos de atenção integral (em Hospitais Gerais, nos CAPS III). Também faz parte dessa política o programa de Volta para Casa, que oferece bolsas para pacientes egressos de longas internações em hospitais psiquiátricos<sup>62</sup> .  
Um dos serviços que compõe a RAPS que pode ser destacado são os CAPS nas suas diferentes modalidades. Os serviços de saúde ofertados nos CAPS são de caráter aberto, comunitário e constituído por equipe multiprofissional. O CAPS atua sob a ótica interdisciplinar e oferece, prioritariamente, o atendimento às pessoas com sofrimento ou transtorno mental, incluindo aquelas com necessidades decorrentes do uso de álcool e outras drogas, em sua área territorial, seja em situações de crise ou nos processos de reabilitação psicossocial, e são substitutivos dos asilos<sup>63</sup> .  
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento. Devem também ser observadas as condições de boa adesão e possibilidade de acompanhamento contínuo do paciente e de seu familiar ou responsável legal.  
Para o uso de clozapina, preconiza-se a realização de hemograma completo a intervalos semanais e a cada aumento da dose nas primeiras 18 semanas de tratamento e, após, a intervalos mensais ao longo de todo o tratamento, assim como consultas médicas mensais.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **11. REFERÊNCIAS** -->
1. The International Psychopharmacology Algorithm Project. Disponível em: www.ipap.org. Acesso em: 15 Maio 2010.  
2. Miller JN, Black DW. Schizoaffective disorder: A review. Ann Clin Psychiatry. 2019;31(1):4753.  
3. Stroup TS, MPHStephen Marder. Pharmacotherapy for schizophrenia: Acute and maintenance phase treatment. https://www.uptodate.com/contents/pharmacotherapy-for- <u>schizophrenia-acute-and-maintenance-phase-treatment2014.</u>  
4. Organização Mundial de Saúde. Classificação de transtornos mentais e de comportamento da CID-10: Descrições clínicas e diretrizes diagnósticas. Porto Alegre: Artes Médicas. 1993.  
5. Manual diagnóstico e estatístico de transtornos mentais  [recurso eletrônico] : DSM-5 / [American Psychiatric  Association ; tradução: Maria Inês Corrêa Nascimento  ... et al.] ; revisão técnica: Aristides Volpato Cordioli ...  [et al.]. – 5. ed. – Dados eletrônicos. – Porto Alegre :  Artmed, 2014.  Editado também como livro impresso em 2014.  ISBN 978-85-8271-089-0  1. Psiquiatria. 2. Transtornos mentais. I. American  Psychiatric Association.  
6. Santelmann H, Franklin J, Bußhoff J, Baethge C. Diagnostic shift in patients diagnosed with schizoaffective disorder: a systematic review and meta-analysis of rediagnosis studies. Bipolar Disord. 2016;18(3):233-46.  
7. Abrams DJ, Rojas DC, Arciniegas DB. Is schizoaffective disorder a distinct categorical diagnosis? A critical review of the literature. Neuropsychiatr Dis Treat. 2008;4(6):1089-109.  
8. Elkis H. A evolução do conceito de esquizofrenia neste século. Brazilian Journal of Psychiatry. 2000;22:23-6.  
9. Radhakrishnan R, Kaser M, Guloksuz S. The Link Between the Immune System, Environment, and Psychosis. Schizophr Bull. 2017;43(4):693-7.  
10. Depino AM. Perinatal inflammation and adult psychopathology: From preclinical models to humans. Semin Cell Dev Biol. 2018;77:104-14.  
11. Mari JJ, Leitão RJ. A epidemiologia da esquizofrenia. Brazilian Journal of Psychiatry. 2000;22:15-7.  
12. Almeida Filho Nd, Mari JdJ, Coutinho E, França JF, Fernandes JG, Andreoli SB, et al. Estudo multicêntrico de morbidade psiquiátrica em áres urbanas brasileiras (Brasília, Säo Paulo, Porto Alegre) / Psychiatric morbidity survey in urban areas in Brazil (Brasília, São Paulo, Porto Alegre). Rev. ABP-APAL;14(3)1992. p. 93-104.  
13. Andrade L, Walters EE, Gentil V, Laurenti R. Prevalence of ICD-10 mental disorders in a catchment area in the city of Sao Paulo, Brazil. Soc Psychiatry Psychiatr Epidemiol. 2002;37(7):316-25.  
14. Davis JM, Chen N, Glick ID. A meta-analysis of the efficacy of second-generation antipsychotics. Arch Gen Psychiatry. 2003;60(6):553-64.  
15. Leucht S, Corves C, Arbter D, Engel RR, Li C, Davis JM. Second-generation versus firstgeneration antipsychotic drugs for schizophrenia: a meta-analysis. Lancet. 2009;373(9657):31-41. 16. Santos IS, Tavares BF, Munhoz TN, Almeida LSPd, Silva NTBd, Tams BD, et al. Sensibilidade e especificidade do Patient Health Questionnaire-9 (PHQ-9) entre adultos da população geral. Cadernos de Saúde Pública. 2013;29:1533-43.  
17. Vilela JAA, Crippa JAS, Del-Ben CM, Loureiro SR. Reliability and validity of a Portuguese version of the Young Mania Rating Scale. Brazilian Journal of Medical and Biological Research. 2005;38:1429-39.  
18. Sparshatt A, Jones S, Taylor D. Quetiapine: dose-response relationship in schizophrenia. CNS Drugs. 2008;22(1):49-68; discussion 9-72.  
19. Meltzer HY, Bobo WV, Roy A, Jayathilake K, Chen Y, Ertugrul A, et al. A randomized, doubleblind comparison of clozapine and high-dose olanzapine in treatment-resistant patients with schizophrenia. J Clin Psychiatry. 2008;69(2):274-85.  
20. Hasan A, Falkai P, Wobrock T, Lieberman J, Glenthøj B, Gattaz WF, et al. World Federation of Societies of Biological Psychiatry (WFSBP) Guidelines for Biological Treatment of Schizophrenia. Part 3: Update 2015 Management of special circumstances: Depression, Suicidality, substance use disorders and pregnancy and lactation. World J Biol Psychiatry. 2015;16(3):142-70.  
21. McAllister-Williams RH, Baldwin DS, Cantwell R, Easter A, Gilvarry E, Glover V, et al. British Association for Psychopharmacology consensus guidance on the use of psychotropic medication preconception, in pregnancy and postpartum 2017. J Psychopharmacol. 2017;31(5):519-52.  
22. Saúde Md. Prevenção do suicídio. https://www.saude.gov.br/component/tags/tag/prevencao-do-suicidio.  
23. Mueser KT, Deavers F, Penn DL, Cassisi JE. Psychosocial treatments for schizophrenia. Annu Rev Clin Psychol. 2013;9:465-97. 24. Geddes J, Freemantle N, Harrison P, Bebbington P. Atypical antipsychotics in the treatment of schizophrenia: systematic overview and meta-regression analysis. Bmj. 2000;321(7273):13716.  
25. Leucht S, Wahlbeck K, Hamann J, Kissling W. New generation antipsychotics versus lowpotency conventional antipsychotics: a systematic review and meta-analysis. Lancet. 2003;361(9369):1581-9.  
26. Davis JM, Chen N. Dose response and dose equivalence of antipsychotics. J Clin Psychopharmacol. 2004;24(2):192-208. 27. Davis JM, Chen N. Old versus new: weighing the evidence between the first- and secondgeneration antipsychotics. Eur Psychiatry. 2005;20(1):7-14. 28. Leucht S, Cipriani A, Spineli L, Mavridis D, Orey D, Richter F, et al. Comparative efficacy and tolerability of 15 antipsychotic drugs in schizophrenia: a multiple-treatments meta-analysis. Lancet. 2013;382(9896):951-62.  
29. Jones PB, Barnes TR, Davies L, Dunn G, Lloyd H, Hayhurst KP, et al. Randomized controlled trial of the effect on Quality of Life of second- vs first-generation antipsychotic drugs in schizophrenia: Cost Utility of the Latest Antipsychotic Drugs in Schizophrenia Study (CUtLASS 1). Arch Gen Psychiatry. 2006;63(10):1079-87.  
30. Kahn RS, Fleischhacker WW, Boter H, Davidson M, Vergouwe Y, Keet IP, et al. Effectiveness of antipsychotic drugs in first-episode schizophrenia and schizophreniform disorder: an open randomised clinical trial. Lancet. 2008;371(9618):1085-97.  
31. Rabinowitz J, Levine SZ, Barkai O, Davidov O. Dropout rates in randomized clinical trials of antipsychotics: a meta-analysis comparing first- and second-generation drugs and an examination of the role of trial design features. Schizophr Bull. 2009;35(4):775-88.  
32. Napryeyenko O, Burba B, Martinez G, Neznanov NG, Fischel T, Bayle FJ, et al. Risperidone long-acting injectable in recent-onset schizophrenia examined with clinician and patient selfreport measures. Journal of Clinical Psychopharmacology. 2010;30(2):200-2.  
33. Rummel C, Hamann J, Kissling W, Leucht S. New generation antipsychotics for first episode schizophrenia. Cochrane Database Syst Rev. 2003(4):Cd004410. 34. Woodward ND, Purdon SE, Meltzer HY, Zald DH. A meta-analysis of cognitive change with haloperidol in clinical trials of atypical antipsychotics: dose effects and comparison to practice effects. Schizophr Res. 2007;89(1-3):211-24.  
35. Stahl SM, Morrissette DA, Citrome L, Saklad SR, Cummings MA, Meyer JM, et al. “Metaguidelines” for the management of patients with schizophrenia. CNS Spectr. 2013;18(3):150-62. 36. Hartling L, Abou-Setta AM, Dursun S, Mousavi SS, Pasichnyk D, Newton AS. Antipsychotics in adults with schizophrenia: comparative effectiveness of first-generation versus second-  
generation medications: a systematic review and meta-analysis. Ann Intern Med. 2012;157(7):498-511.  
37. Soares-Weiser K, Bechard-Evans L, Lawson AH, Davis J, Ascher-Svanum H. Time to all-cause treatment discontinuation of olanzapine compared to other antipsychotics in the treatment of schizophrenia: a systematic review and meta-analysis. Eur Neuropsychopharmacol. 2013;23(2):118-25.  
38. Kishimoto T, Agarwal V, Kishi T, Leucht S, Kane JM, Correll CU. Relapse prevention in schizophrenia: a systematic review and meta-analysis of second-generation antipsychotics versus first-generation antipsychotics. Mol Psychiatry. 2013;18(1):53-66.  
39. Marriott RG, Neil W, Waddingham S. Antipsychotic medication for elderly people with schizophrenia. Cochrane Database Syst Rev. 2006(1):Cd005580.  
40. Sarkar S, Grover S. Antipsychotics in children and adolescents with schizophrenia: a systematic review and meta-analysis. Indian J Pharmacol. 2013;45(5):439-46.  
41. Essali A, Ali G. Antipsychotic drug treatment for elderly people with late-onset schizophrenia. Cochrane Database Syst Rev. 2012(2):CD004162.  
42. Correll CU, Rummel-Kluge C, Corves C, Kane JM, Leucht S. Antipsychotic combinations vs monotherapy in schizophrenia: a meta-analysis of randomized controlled trials. Schizophr Bull. 2009;35(2):443-57.  
43. Romano F, Elkis H. Tradução e adaptação de um instrumento de avaliação psicopatológica das psicoses: a Escala Breve de Avaliação Psiquiátrica - versão Ancorada (BPRS-A). Jornal Brasileiro de Psiquiatria. 1996:43-9.  
44. Meltzer HY, Alphs L, Green AI, Altamura AC, Anand R, Bertoldi A, et al. Clozapine treatment for suicidality in schizophrenia: International Suicide Prevention Trial (InterSePT). Arch Gen Psychiatry. 2003;60(1):82-91.  
45. Lewis S, Barnes T, Davies L, Murray R, Dunn G, Hayhurst Kea. Randomized controlled <st1:citation w:st="on">trial of effect of prescription of clozapine <st1:citation w:st="on">versus other second-generation antipsychotic drugs in resistant schizophrenia. 2006:[715-23 pp.].  
46. Souza JS, Kayo M, Tassell I, Martins CB, Elkis H. Efficacy of olanzapine in comparison with clozapine for treatment-resistant schizophrenia: evidence from a systematic review and metaanalyses. CNS Spectr. 2013;18(2):82-9.  
47. Chakos M, Lieberman J, Hoffman E, Bradford D, Sheitman B. Effectiveness of secondgeneration antipsychotics in patients with treatment-resistant schizophrenia: a review and metaanalysis of randomized trials. Am J Psychiatry. 2001;158(4):518-26.  
48. Cipriani A, Boso M, Barbui C. Clozapine combined with different antipsychotic drugs for treatment resistant schizophrenia. Cochrane Database Syst Rev. 2009(3):Cd006324.  
49. Hennen J, Baldessarini RJ. Suicidal risk during treatment with clozapine: a meta-analysis. Schizophr Res. 2005;73(2-3):139-45.  
50. Leucht S, Helfer B, Dold M, Kissling W, McGrath JJ. Lithium for schizophrenia. Cochrane Database Syst Rev. 2015(10):Cd003834.  
51. Gregory A, Mallikarjun P, Upthegrove R. Treatment of depression in schizophrenia: systematic review and meta-analysis. Br J Psychiatry. 2017;211(4):198-204.  
52. Matthews PRL, Horder J, Pearce M. Selective noradrenaline reuptake inhibitors for schizophrenia. Cochrane Database Syst Rev. 2018;1:Cd010219.  
53. Li C, Xia J, Wang J. Risperidone dose for schizophrenia. Cochrane Database Syst Rev. 2009(4):Cd007474.  
54. Kim CY, Shin YW, Joo YH, Hong JP, Lee GH, Choi SK. Risperidone dosing pattern and clinical outcome in psychosis: an analysis of 1713 cases. J Clin Psychiatry. 2005;66(7):887-93.  
55. Kumra S, Kranzler H, Gerbino-Rosen G, Kester HM, De Thomas C, Kafantaris V, et al. Clozapine and "high-dose" olanzapine in refractory early-onset schizophrenia: a 12-week randomized and double-blind comparison. Biol Psychiatry. 2008;63(5):524-9.  
56. Citrome L, Kantrowitz JT. Olanzapine dosing above the licensed range is more efficacious than lower doses: fact or fiction? Expert Rev Neurother. 2009;9(7):1045-58.  
57. Every-Palmer S, Newton-Howes G, Clarke MJ. Pharmacological treatment for antipsychotic-related constipation. Cochrane Database Syst Rev. 2017;1:Cd011128.  
58. Mukundan A, Faulkner G, Cohn T, Remington G. Antipsychotic switching for people with schizophrenia who have neuroleptic-induced weight or metabolic problems. Cochrane Database Syst Rev. 2010(12):Cd006629.  
59. Chouinard G, Ross-Chouinard A, Annable L, B J. Extrapyramidal Symptom Rating Scale. Can J Neurol Sci. 1980:233-9.  
60. Barnes TR. A rating scale for drug-induced akathisia. Br J Psychiatry. 1989;154:672-6. 61. Strawn JR, Keck PE, Caroff SN. Neuroleptic malignant syndrome. Am J Psychiatry. 2007;164(6):870-6.  
62. Saúde Md. Rede de Atenção Psicossocial - RAPS. https://www.saude.gov.br/acoes-e- <u>programas/rede-de-atencao-psicossocial-raps  .</u>  
63. Saúde Md. Centro de Atenção Psicossocial - CAPS. https://www.saude.gov.br/noticias/693-acoes-e-programas/41146-centro-de-atencao- <u>psicossocial-caps</u>

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
BIPERIDENO, CLORPROMAZINA, CLOZAPINA, DECANOATO DE HALOPERIDOL, HALOPERIDOL, OLANZAPINA, PROPRANOLOL, QUETIAPINA, RISPERIDONA E ZIPRASIDONA.  
Eu,_____________________________________________________________ (nome do [a]  
paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de biperideno, clorpromazina, clozapina, decanoato de haloperidol, haloperidol, olanzapina, propranolol, quetiapina, risperidona e ziprasidona, que são indicados para o tratamento do transtorno esquizoafetivo.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico  
____________________________________________________________ (nome do médico que  
prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- redução dos sintomas e da frequência das crises; e  
- redução das internações hospitalares.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
**Risperidona, quetiapina, ziprasidona e olanzapina:** medicamentos classificados na gestação como categoria C (pesquisas em animais mostraram anormalidades nos descendentes, porém, não há estudos em humanos; o risco para o bebê não pode ser descartado, mas um benefício potencial pode ser maior do que os riscos).  
**Clozapina** : medicamento classificado na gestação como categoria B (pesquisas em animais não mostraram anormalidades nos descendentes, porém, não há estudos em humanos; risco para o bebê é muito improvável). Contraindicado nos casos de leucopenia (contagem de células brancas do sangue abaixo de 3.500 células/mm3). São necessários controles periódicos com hemogramas semanais nas primeiras 18 semanas e mensal após.  
**Biperideno** : Contraindicado nos casos de glaucoma de ângulo fechado, retenção urinária, hipertrofia prostática, miastenia grave e estenose ou obstrução mecânica do trato gastrintestinal, megacólon.  
**Propranolol** : Contraindicado nos casos de hipersensibilidade ao propranolol, hipotensão, insuficiência cardíaca descompensada, choque cardiogênico, bradicardia, síndrome do nó  
sinoatrial, bloqueio atrioventricular de 2º e 3º graus, asma brônquica ou broncoespamos, acidose metabólica, angina de Prinzmetal, doença arterial periférica grave, distúrbios graves da circulação arterial periférica; feocromocitoma não tratado (com um antagonista do receptor alfaadrenérgico) e após jejum prolongado.  
**Biperideno, propranolol, haloperidol e clorpromazina** : medicamentos classificados na gestação como categoria C (raras anomalias, icterícia fetal, efeitos anticolinérgicos fetais no nascimento).  
Os efeitos adversos mais comuns do **biperideno** são: obstipação, náusea, xerostomia, visão borrada, retenção urinária, confusão mental, excitação, delírio, tontura, déficit de memória, alucinações, agitação, sonolência, taquicardia, arritmias e hipotensão postural.  
Os efeitos adversos mais comuns do **propranolol** são: distúrbios gastrintestinais, insuficiência cardíaca congestiva, hipotensão, bradicardia, transtorno na condução, broncoespasmo, com piora de asma e DPOC, claudicação intermitente, fenômeno de Raynaud, depressão mental, insônia, pesadelos, fadiga, cefaleia, disfunção sexual, aumento do risco de hipoglicemia em diabéticos dependentes de insulina.  
Os efeitos adversos mais comuns da **risperidona** são: agitação, nervosismo, alterações de visão, disfunção sexual, tonturas, alterações na menstruação, tremores, movimentos involuntários, insônia, distúrbios urinários, agressividade, diminuição da concentração e da memória, vermelhidão e coceira na pele, fraqueza, cansaço, prisão de ventre, tosse, boca seca, diarreia, sonolência, dor de cabeça, má digestão, náusea, ganho de peso.  
Os efeitos adversos mais comuns da **quetiapina** : prisão de ventre, vertigens, sonolência, boca seca, indigestão, aumento de peso, tontura ao levantar.  
Os efeitos adversos mais comuns da **ziprasidona** : sonolência, insônia, tonturas, pressão baixa, tremores, alterações cardíacas, fraqueza, dor de cabeça, prisão de ventre, boca seca, aumento da salivação, náusea, vômitos, nervosismo, agitação.  
Os efeitos adversos mais comuns da **olanzapina** : dor de cabeça, sonolência, insônia, agitação, nervosismo, ansiedade, boca seca, tonturas ao levantar, taquicardia, inchaço, amnésia, febre, vermelhidão na pele, inquietação, prisão de ventre, dor abdominal, ganho de peso, aumento do apetite, rigidez na nuca, dores no corpo.  
Os efeitos adversos mais comuns da **clozapina** são: aumento da frequência cardíaca, palpitações, tonturas, prisão de ventre, febre, dor de cabeça, cansaço, sonolência, produção aumentada ou diminuída de saliva, aumento de suor, náusea, vômitos, enjoo, visão  
turva, aumento de peso, alteração das células do sangue (agranulocitose, eosinofilia, granulocitopenia, leucopenia, trombocitopenia).  
Os efeitos adversos do **haloperidol** são: tremores, rigidez, salivação, tonturas, movimentos involuntários, inquietação, alterações menstruais, coágulos.  
Os efeitos adversos da **clorpromazina** são: tremores, movimentos involuntários, irregularidades menstruais, disfunção sexual, retenção urinária, aumento de peso, sonolência. Não deve ser usado em quem tem glaucoma, problemas urinários ou doença grave do coração.  
Esses medicamentos podem causar aumento da pressão arterial, da glicose, do peso, além de alterações das gorduras do sangue. Consultas e exames durante o tratamento são necessários.  
Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este (s) medicamento (s) somente pode (m) ser utilizado (s) por mim, comprometendo-me a devolvê-lo (s) caso não queira ou não possa utilizá-lo (s) ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim     (    ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (   ) biperideno  
- (   ) propranolol  
- (   ) clozapina  
- (   ) clorpromazina  
- (   ) decanoato de haloperidol  
- (   ) haloperidol  
- (   ) olanzapina  
- (   ) quetiapina  
- (   )  risperidona  
- (   ) ziprasidona  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA - Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: ESCALAS E TESTES DE AVALIAÇÃO -->
Escala Breve de Avaliação Psiquiátrica - BPRS Ancorada com sugestão de perguntas Versão Ancorada - BPRS-A (Woerner, 1998, trad. Romano e Elkis, 1996) mais Entrevista Clínica Estruturada<sup>43</sup>  
Paciente: Número: Data: Entrevistador: Fase: Instruções: A Escala é composta de 18 itens a serem avaliados. Os itens assinalados com OBSERVAÇÃO (3, 4, 7, 13, 14, 16, 17, 18) devem ser avaliados tomando por base OBSERVAÇÕES feitas durante a entrevista. Os itens assinalados com RELATO DO PACIENTE devem ser avaliados a partir de informação RELATADA (ou seja, SUBJETIVA) referente ao período escolhido (em geral 1 semana). As perguntas-guia em negrito devem ser formuladas diretamente nos itens em que se avalia o relato do paciente. Início da entrevista: Comece com estas perguntas e utilize as mesmas para completar o item 18 (Orientação): Qual seu nome completo? E sua idade? Onde você mora? Está trabalhando atualmente? (Já trabalhou anteriormente? Em quê?) Quanto tempo faz que você está aqui? Conte-me por que motivo você foi internado. Quando isso começou? O que aconteceu depois? Você pode me dizer que dia é hoje (semana-mês-ano)?  
|1|RELATO<br>DO PACIENTE|PREOCUPAÇÃO SOMÁTICA: Grau de preocupação com a saúde física. Avaliar o grau no qual a saúde<br>física é percebida como um problema pelo paciente, quer as queixas sejam baseadas na realidade<br>ou não. Não pontuar o simples relato de sintomas físicos. Avaliar apenas apreensão (ou<br>preocupação)sobreproblemas físicos(reais ou imaginários).|
|---|---|---|
|||Como costuma ser sua saúde física (do corpo)? Como esteve sua saúde no último ano? Você está|
|Pergunta-guia||preocupado com algum problema de saúde agora? Você sente que tem alguma coisa incomum<br>acontecendo com seu corpo ou cabeça?|  
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Ocasionalmente fica levemente preocupado com o corpo, sintomas ou doenças físicas.<br>Leve: Ocasionalmente fica preocupado com o corpo de forma moderada ou frequentemente fica<br>levemente apreensivo.<br>Moderado: Ocasionalmente fica muito preocupado ou moderadamente preocupado com<br>frequência.<br>Moderadamente grave: Frequentemente fica muito preocupado.<br>Grave: Fica muito preocupado a maior parte do tempo.<br>Muitograve: Fica muitopreocupadopraticamente o tempo todo.|
|---|---|---|
|2|RELATO<br>DO PACIENTE|ANSIEDADE: Preocupação, medo ou preocupação excessiva acerca do presente ou futuro. Pontuar<br>somente a partir de relato verbal das experiências subjetivas do paciente. Não inferir ansiedade a<br>partir de sinais físicos ou mecanismos de defesa neuróticos. Não pontuar se restrito a preocupação<br>somática.|
|Pergunta-guia||Você está preocupado com alguma coisa? Você tem se sentido tenso ou ansioso a maior parte do<br>tempo? (Quando se sente assim, você consegue saber o porquê? De que forma suas ansiedades ou<br>preocupações afetam o seu dia a dia? Existe algo que ajuda a melhorar essa sensação?)|
||0<br>1<br>2<br>3<br>4<br>5|Não relatado.<br>Muito leve: Ocasionalmente se sente levemente ansioso.<br>Leve: Ocasionalmente se sente moderadamente ansioso ou frequentemente se sente levemente<br>ansioso.<br>Moderado: Ocasionalmente se sente muito ansioso ou frequentemente se sente moderadamente<br>ansioso.<br>Moderadamente grave: Frequentemente se sente muito ansioso<br>Grave: Sente-se muito ansioso a maiorparte do tempo.|
|3|OBSERVAÇÃO<br>DO PACIENTE|RETRAIMENTO AFETIVO: Deficiência no relacionamento com o entrevistador e na situação da<br>entrevista. Manifestações evidentes dessa deficiência incluem: falta de contato visual (troca de<br>olhares); o paciente não se aproxima do entrevistador; apresenta uma falta de envolvimento e<br>compromisso com a entrevista. Diferenciar de AFETO EMBOTADO, no qual são pontuadas<br>deficiências na expressão facial, gestualidade e tom de voz. Pontuar a partir de observações feitas<br>durante a entrevista.|  
|0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Ocasionalmente deixa de encarar o entrevistador.<br>Leve: Como acima, porém mais frequente.<br>Moderado: Demonstra dificuldade em encarar o entrevistador, mas ainda parece engajado na<br>entrevista e responde apropriadamente a todas as questões.<br>Moderadamente grave: Olha fixamente o chão e afasta-se do entrevistador, mas ainda parece<br>moderadamente engajado na entrevista.<br>Grave: Como acima, porém, mais persistente e disseminado.<br>Muito grave: Parece estar “aéreo”, “nas nuvens” ou “viajando” (total ausência de vínculo<br>emocional) e desproporcionalmente não envolvido ou não comprometido com a situação da<br>entrevista.(Nãopontuar se explicadopela desorientação).|
|---|---|
|4<br>OBSERVAÇÃO<br>DO PACIENTE|DESORGANIZAÇÃO CONCEITUAL: Grau de incompreensibilidade da fala. Incluir qualquer tipo de<br>desordem formal de pensamento (por exemplo, associações frouxas, incoerência, fuga de ideias,<br>neologismos). NÃO incluir mera circunstancialidade ou fala maníaca, mesmo que acentuada. NÃO<br>pontuar a partir de impressões subjetivas do paciente (por exemplo, “meus pensamentos estão<br>voando”, “não consigo manter o pensamento”, “meus pensamentos se misturam todos”). Pontuar<br>SOMENTE apartir de observações feitas durante a entrevista.|
|0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Levemente vago, todavia de significação clínica duvidosa.<br>Leve: Frequentemente vago, mas é possível prosseguir a entrevista.<br>Moderado: Ocasionalmente faz afirmações irrelevantes, uso infrequente de neologismos ou<br>associações moderadamente frouxas.<br>Moderadamente grave: Como acima, porém mais frequente.<br>Grave: Desordem formal do pensamento presente a maior parte da entrevista, tornando-a muito<br>difícil.<br>Muitograve: Muitopouca informação coerentepode ser obtida.|
|5<br>RELATO<br>DO PACIENTE|SENTIMENTOS DE CULPA: Preocupação ou remorso desproporcional pelo passado. Pontuar a partir<br>das experiências subjetivas de culpa evidenciadas por meio de relato verbal. Não inferir<br>sentimentos de culpa apartir de depressão,ansiedade ou defesas neuróticas.|  
|Pergunta-guia||Nos últimos dias você tem se sentido um peso para sua família ou colegas? Você tem se sentido<br>culpado por alguma coisa feita no passado? Você acha que o que está passando agora é um tipo de<br>castigo?(Porque você acha isso?)|
|---|---|---|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Ocasionalmente se sente levemente culpado.<br>Leve: Ocasionalmente se sente moderadamente culpado ou frequentemente se sente levemente<br>culpado.<br>Moderado: Ocasionalmente se sente muito culpado ou frequentemente se sente moderadamente<br>culpado.<br>Moderadamente grave: Frequentemente se sente muito culpado.<br>Grave: Sente-se muito culpado a maior parte do tempo ou apresenta delírio de culpa encapsulado.<br>Muito grave: Apresenta sentimento de culpa angustiante e constante ou delírios de culpa<br>disseminados.|
|6|OBSERVAÇÃO<br>DO PACIENTE|TENSÃO: Avaliar inquietação motora (agitação) observada durante a entrevista. Não pontuar a<br>partir de experiências subjetivas relatadas pelo paciente. Desconsiderar patogênese presumida<br>(por exemplo,discinesia tardia).|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Fica ocasionalmente agitado.<br>Leve: Fica frequentemente agitado.<br>Moderado: Agita-se constantemente ou frequentemente; torce as mãos e puxa a roupa.<br>Moderadamente grave: Agita-se constantemente; torce as mãos e puxa a roupa.<br>Grave: Não consegue ficar sentado, isto é, precisa andar.<br>Muito grave: Anda de maneira frenética.|
|7|OBSERVAÇÃO<br>DO PACIENTE|MANEIRISMOS E POSTURA: Comportamento motor incomum ou não natural. Pontuar apenas<br>anormalidade de movimento. NÃO pontuar aqui simples aumento da atividade motora. Considerar<br>frequência,duração egrau do caráter bizarro. Desconsiderarpatogênesepresumida.|  
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Comportamento estranho, mas de significação clínica duvidosa (por exemplo, um riso<br>imotivado ocasional, movimentos de lábio infrequentes).<br>Leve: Comportamento estranho, mas não obviamente bizarro (por exemplo, às vezes balança a<br>cabeça ritmadamente de um lado para outro, movimenta os dedos de maneira anormal<br>intermitentemente).<br>Moderado: Adota posição de ioga por um breve período, às vezes põe a língua para fora, balança o<br>corpo.<br>Moderadamente grave: Como acima, porém mais frequente, intenso ou disseminado.<br>Grave: Como acima, porém mais frequente, intenso ou disseminado.<br>Muito grave: Postura bizarra durante a maior parte da entrevista, movimentos anormais constantes<br>em várias áreas do corpo.|
|---|---|---|
|8|RELATO<br>DO PACIENTE|IDEIAS DE GRANDEZA: Autoestima (autoconfiança) exagerada ou apreciação desmedida dos<br>próprios talentos, poderes, habilidades, conquistas, conhecimento, importância ou identidade.<br>NÃO pontuar mera qualidade grandiosa de alegações (por exemplo, “sou o pior pecador do<br>mundo”, “todo o país está tentando me matar”) a menos que a culpa/persecutoriedade esteja<br>relacionada a algum atributo especial exagerado do indivíduo. O paciente deve declarar atributos<br>exagerados; se negar talentos, poderes, etc., mesmo que afirme que outros digam que ele possui<br>tais qualidades, este item não deve ser pontuado. Pontuar a partir de informação relatada, ou seja,<br>subjetiva.|
|Pergunta-guia||Nos últimos dias você tem se sentido com algum talento ou habilidade que a maioria das pessoas<br>não tem? (Como você sabe disso?) Você acha que as pessoas têm tido inveja de você? Você tem<br>acreditadoque tenha alguma coisa importantepara fazer no mundo?|  
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: É mais confiante do que a maioria, mas isso é apenas de possível significância clínica.<br>Leve: Autoestima definitivamente aumentada ou talentos exagerados de modo levemente<br>desproporcional às circunstâncias.<br>Moderado: Autoestima aumentada de modo claramente desproporcional às circunstâncias, ou<br>suspeita-se de delírio de grandeza.<br>Moderadamente grave: Um único (e claramente definido) delírio de grandeza encasulado ou<br>múltiplos delírios de grandeza fragmentários (claramente definidos).<br>Grave: Um único e claro delírio / sistema delirante ou múltiplos e claros delírios de grandeza com<br>os quais o paciente parece preocupado.<br>Muito grave: Como acima, mas a quase totalidade da conversa é dirigida aos delírios de grandeza<br>dopaciente.|
|---|---|---|
|9|RELATO<br>DO PACIENTE|HUMOR DEPRESSIVO: Relato subjetivo de sentimento de depressão, tristeza, “estar na fossa”, etc.<br>Pontuar apenas o grau de depressão relatada. Não pontuar inferências de depressão feitas a partir<br>de lentificação geral e queixas somáticas. Pontuar a partir de informação relatada, ou seja,<br>subjetiva.|
|Pergunta-guia||Como tem estado seu humor (alegre, triste, irritável)? Você acredita que pode melhorar? (Como<br>esse sentimento tem afetado seu dia a dia?)|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Ocasionalmente se sente levemente deprimido.<br>Leve: Ocasionalmente se sente moderadamente deprimido ou frequentemente se sente levemente<br>deprimido.<br>Moderado: Ocasionalmente se sente muito deprimido ou frequentemente se sente<br>moderadamente deprimido.<br>Moderadamente grave: Frequentemente se sente muito deprimido.<br>Grave: Sente-se muito deprimido a maior parte do tempo.<br>Muitograve: Sente-se muito deprimidoquase todo o tempo.|
|10|RELATO<br>DO PACIENTE|HOSTILIDADE: Animosidade, desprezo, agressividade, desdém por outras pessoas fora da situação<br>da entrevista. Pontuar somente a partir de relato verbal de sentimentos e atos do paciente em<br>relação aos outros. Não inferir hostilidade a partir de defesas neuróticas, ansiedade ou queixas<br>somáticas.|  
|Pergunta-guia||Nos últimos dias você tem estado impaciente ou irritável com as outras pessoas? (Conseguiu<br>manter o controle? Tolerou asprovocações? Chegou a agredir alguém ouquebrar objetos?)|
|---|---|---|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Ocasionalmente sente um pouco de raiva.<br>Leve: Frequentemente sente um pouco de raiva ou ocasionalmente sente raiva moderada.<br>Moderado: Ocasionalmente sente muita raiva ou frequentemente sente raiva moderada.<br>Moderadamente grave: Frequentemente sente muita raiva.<br>Grave: Expressou sua raiva tornando-se verbal ou fisicamente agressivo em uma ou duas ocasiões.<br>Muitograve: Expressou sua raiva em várias ocasiões.|
|11|RELATO<br>DO PACIENTE|DESCONFIANÇA: Crença (delirante ou não) de que outros têm agora ou tiveram no passado<br>intenções discriminatórias ou maldosas em relação ao paciente. Pontuar apenas se o paciente<br>relatar verbalmente desconfianças atuais, quer elas se refiram a circunstâncias presentes ou<br>passadas. Pontuar apartir da informação relatada,ou seja,subjetiva.|
|Pergunta-guia||Você tem tido a impressão de que as outras pessoas estão falando ou rindo de você? (De que<br>forma você percebe isso?) Você tem achado que tem alguém com más intenções contra você ou se<br>esforçadopara lhe causarproblemas?(Quem? Porquê? Como você sabe disso?)|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Raras circunstâncias de desconfiança que podem ou não corresponder à realidade.<br>Leve: Situações de desconfiança ocasionais que definitivamente não correspondem à realidade.<br>Moderado: Desconfiança mais frequente ou ideias de referência passageiras.<br>Moderadamente grave: Desconfiança disseminada ou ideias de referência frequentes.<br>Grave: Claros delírios de perseguição ou referência não totalmente disseminados (por exemplo, um<br>delírio encapsulado).<br>Muitograve: Como acima, porém mais abrangente,frequente ou intenso.|
|12|RELATO<br>DO PACIENTE|COMPORTAMENTO ALUCINATÓRIO (ALUCINAÇÕES): Percepções (em qualquer modalidade dos<br>sentidos) na ausência de um estímulo externo identificável. Pontuar apenas as experiências que<br>ocorreram na última semana. NÃO pontuar “vozes na minha cabeça” ou “visões em minha mente”<br>a menosque opaciente saiba diferenciar entre essas experiências e seuspensamentos.|  
|Pergunta-guia||Você tem tido experiências incomuns que a maioria das pessoas não tem? Você tem escutado<br>coisas que as outras pessoas não podem ouvir? (Você estava acordado nesse momento? O que<br>você ouvia - barulhos, cochichos, vozes conversando com você ou conversando entre si? Com que<br>frequência? Interferem no seu dia a dia?) Você tem visto coisas que a maioria das pessoas não<br>pode ver? (Você estava acordado nesse momento? O que você via - luzes, formas, imagens? Com<br>que frequência? Interferem no seu dia a dia?)|
|---|---|---|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Apenas se suspeita de alucinação.<br>Leve: Alucinações definidas, porém insignificantes, infrequentes ou transitórias.<br>Moderado: Como acima, porém mais frequentes (por exemplo, frequentemente vê a cara do diabo;<br>duas vozes travam uma longa conversa).<br>Moderadamente grave: Alucinações são vividas quase todo o dia ou são fontes de incômodo<br>extremo.<br>Grave: Como acima e exercem impacto moderado no comportamento do paciente (por exemplo,<br>dificuldades de concentração que levam a um comprometimento no trabalho).<br>Muito grave: Como acima, com grave impacto (por exemplo, tentativas de suicídio como resposta a<br>ordens alucinatórias).|
|13|OBSERVAÇÃO<br>DO PACIENTE|RETARDAMENTO MOTOR: Redução do nível de energia evidenciada por movimentos mais lentos.<br>Pontuar apenas a partir de comportamento observado no paciente. NÃO pontuar a partir de<br>impressões subjetivas dopaciente sobre seupróprio nível de energia.|
||0<br>1<br>2<br>3<br>4<br>5|Não observado.<br>Muito leve: Significação clínica duvidosa.<br>Leve: Conversa um pouco mais lentamente, movimentos levemente mais lentos.<br>Moderado: Conversa notavelmente mais lenta, mas não arrastada.<br>Moderadamente grave: Conversa arrastada, movimenta-se muito lentamente.<br>Grave: É difícil manter a conversa, quase não se movimenta.|
||6|Muitograve: Conversaquase impossível,não se move durante toda a entrevista.|  
|14|OBSERVAÇÃO<br>DO PACIENTE|FALTA DE COOPERAÇÃO COM A ENTREVISTA: Evidência de resistência, indelicadeza, ressentimento<br>e falta de prontidão para cooperar com os entrevistados. Pontuar exclusivamente a partir das<br>atitudes do paciente e das reações ao entrevistador e à situação de entrevista. NÃO pontuar a<br>partir de relato de ressentimento e recusa à cooperação fora de situação de entrevista.|
|---|---|---|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Não parece motivado.<br>Leve: Parece evasivo em certos assuntos.<br>Moderado: Monossilábico, fracassa em cooperar espontaneamente.<br>Moderadamente grave: Expressa ressentimento e é indelicado durante a entrevista.<br>Grave: Recusa-se a responder a algumas questões.<br>Muitograve: Recusa-se a responder à maiorparte dasquestões.|
|15|RELATO<br>DO PACIENTE|ALTERAÇÃO DE CONTEÚDO DO PENSAMENTO (DELÍRIOS): Gravidade de qualquer tipo de delírio.<br>Considerar convicção e seu efeito em ações. Pressupor convicção total se o paciente agiu baseado<br>em suas crenças. Pontuar a partir de informação relatada, ou seja, subjetiva.|
|Pergunta-guia||Você tem acreditado que alguém ou alguma coisa fora de você esteja controlando seus<br>pensamentos ou suas ações contra a sua vontade? Você tem a impressão de que o rádio ou a<br>televisão mandam mensagens para você? Você sente que alguma coisa incomum esteja<br>acontecendo ou está para acontecer?|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não relatado.<br>Muito leve: Suspeita-se ou há probabilidade de delírio.<br>Leve: Às vezes o paciente questiona suas crenças (delírios parciais).<br>Moderado: Plena convicção delirante, porém delírios têm pouca ou nenhuma influência sobre o<br>comportamento.<br>Moderadamente grave: Plena convicção delirante, porém os delírios têm impacto apenas ocasional<br>sobre o comportamento.<br>Grave: Delírios têm efeito significativo (por exemplo, negligencia responsabilidades por causa de<br>preocupações com a crença de que é Deus).|  
|||Muito grave: Delírios têm impacto marcante (por exemplo, para de comer porque acredita que a<br>comida está envenenada).|
|---|---|---|
|16|OBSERVAÇÃO<br>DO PACIENTE|AFETO EMBOTADO: Responsividade afetiva diminuída, caracterizada por déficits na expressão<br>facial, gestualidade e tom de voz. Diferenciar de RETRAIMENTO AFETIVO no qual o foco está no<br>comprometimento interpessoal mais do que no afetivo. Considerar grau e consistência no<br>comprometimento. Pontuar a partir de observações feitas durante a entrevista.|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Ocasionalmente parece indiferente a assuntos que são normalmente acompanhados<br>por demonstração de emoção.<br>Leve: Expressão facial levemente diminuída ou voz levemente monótona ou gestualidade<br>levemente limitada.<br>Moderado: Como acima, porém de forma mais intensa, prolongada ou frequente.<br>Moderadamente grave: Achatamento de afeto, incluindo pelo menos duas ou três características<br>(falta acentuada de expressão facial, voz monótona ou gestualidade limitada).<br>Grave: Profundo achatamento de afeto.<br>Muito grave: Voz totalmente monótona e total falta de gestualidade expressiva durante toda a<br>avaliação.|
|17|OBSERVAÇÃO<br>DO PACIENTE|EXCITAÇÃO: Tom emocional aumentado, incluindo irritabilidade e expansividade (afeto<br>hipomaníaco). Não inferir afeto de afirmações a partir de delírios de grandeza. Pontuar a partir de<br>observações feitas durante a entrevista.|
||0<br>1<br>2<br>3<br>4<br>5<br>6|Não observado.<br>Muito leve: Significação clínica duvidosa.<br>Leve: Às vezes irritadiço ou expansivo.<br>Moderado: Frequentemente irritadiço ou expansivo.<br>Moderadamente grave: Constantemente irritadiço ou expansivo, às vezes enfurecido ou eufórico.<br>Grave: Enfurecido ou eufórico durante maior parte da entrevista.<br>Muito grave: Como acima, porém de tal modo que a entrevista precisa ser interrompida<br>prematuramente.|
|18|OBSERVAÇÃO<br>DO PACIENTE|DESORIENTAÇÃO: Confusão ou falta de orientação adequada em relação a pessoas, lugares e<br>tempo. Pontuar apartir de observações feitas durante a entrevista.|  
|Pergunta-guia||Qual seu nome completo? E sua idade? Onde você mora? Está trabalhando atualmente? (Já<br>trabalhou anteriormente? Em quê?) Quanto tempo faz que você está aqui? Conte-me por que<br>motivo você foi internado. Quando isso começou? O que aconteceu depois? Você pode me dizer<br>que dia é hoje (semana-mês- ano)? Você tem conseguido se concentrar? Como está sua memória?<br>(Caso necessário, faça exame específico.)<br>Reentrevista: Você pode me dizer que dia é hoje (semana-mês-ano)? Você pode me dizer o que<br>tinha ontem nojantar?|
|---|---|---|
||0<br>1<br>2<br>3|Não observado.<br>Muito leve: Parece um pouco confuso.<br>Leve: Indica 2003 quando é na verdade 2004.<br>Moderado: Indica 1992.|
||4|Moderadamente grave: Não sabe ao certo onde está.|
||5|Grave: Não faz ideia de onde está.|
||6|Muitograve: Não sabequem é.|

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: Folha de Respostas -->
Paciente Idade Sexo <mark>Escores: 0 (Não relatado), 1 (Muito leve), 2 (Leve), 3 (Moderado), 4 (Moderadamente grave), 5 (Grave), 6</mark> <u>(Muito grave)</u>  
|Data|Esc<br>ore|Esc<br>ore|Esc<br>ore|Esc<br>ore|Es<br>co<br>re<br>Es<br>c<br>or<br>e|Es<br>c<br>or<br>e|Es<br>co<br>re<br>Esco<br>re|Esco<br>re|Esco<br>re|Esc<br>ore|Esc<br>ore|Esco<br>re|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1. Preocupação somática|||||||||||||
|2. Ansiedade|||||||||||||
|3. Retraimento afetivo|||||||||||||
|4. Desorganização conceitual|||||||||||||
|5. Sentimento de culpa|||||||||||||
|6. Tensão|||||||||||||
|7. Maneirismos epostura|||||||||||||
|8. Ideias de<br>grandeza|||||||||||||
|9. Humor depressivo|||||||||||||
|10. Hostilidade|||||||||||||
|11. Desconfiança|||||||||||||
|12. Comportamento alucinatório(alucinações)|||||||||||||
|13. Retardamentopsicomotor/motor|||||||||||||
|14. Falta de cooperação com a entrevista|||||||||||||
|15. Alteração de conteúdo do<br>pensamento(delírios)|||||||||||||
|16. Afeto embotado|||||||||||||
|17. Excitação|||||||||||||  
|18. Desorientação|
|---|
|Escore Total|  
Escalas de Depressão (PHQ<sup>9</sup> ), Estado misto depressivo-maníaco (DMX<sup>12</sup> ), Ansiedade Generalizada (GAD<sup>7</sup> )<sup>16</sup>  
|Nas últ|imas d|uas semanas,comque frequência você esteve inc|omodado(a) po|r:|||
|---|---|---|---|---|---|---|
||||0|1|2|3|
||||EM NENHUM<br>MOMENTO|UM POUCO<br>ALGUNS<br>DIAS|MAIS<br>DA<br>METADE<br>DOS DIAS|TODOS<br>QUASE<br>TODOS<br>OS DIAS|
||1|Pouco interesse ouprazer em fazer as coisas|||||
||2|Sensação de depressão-desesperança|||||
||3|Não conseguir iniciar ou seguir dormindo,<br>dormir demais.|||||
||4|Cansaço, pouca energia|||||
|PHQ<sup>9</sup>|5|Pouco apetite ou comer demais|||||
||6|Sentir-se mal,um fracasso oupara baixo.|||||
||7|Problema para se concentrar ler jornal, assistir<br>TV.|||||
||8|Se mexer ou falar tão devagar que outros<br>notaram.<br>Ou o oposto, inquieto, se mexendo muito mais<br>doque o usual.|||||
||9|Pensamentos de morrer,ou de se machucar.|||||
|||Total 1 a 9|||||
||1|Sou muito sensível e vulnerável a comentários<br>e atitudes dos outros|||||  
|2|Reajo a coisas triviais de forma mais intensa<br>doque as outraspessoas|
|---|---|
|DMX<sup>12</sup><br>3|Sou facilmente distraído/a e incapaz de me<br>concentrar em uma tarefa|
|4|Tendo a correr riscos depropósito|
|5|Meu humor muda rapidamente em pouco<br>tempo|
|6|Eu me sinto tão tenso/a que não consigo<br>relaxar|
|7|Eu me sinto mal por sentimentos<br>desagradáveis e desconfortáveis|
|8|Tenho muitos pensamentos diferentes de<br>coisas pouco práticas passando rápido na<br>mente|
|9|Sinto-me inquieto/a e incapaz de ficar<br>parado/a|
|10|Eu sinto vontade de agir impulsivamente sem<br>levar em conta consequências|
|11|Eu fico facilmente irritado/a sem motivo|
|12|Quando alguém discorda tenho vontade de<br>brigar ou bater nele|
||Total 1 a 12|
|1|Me sinto nervoso/a,ansioso/a ou no limite.|
|2|Não sou capaz de parar ou de controlar a<br>preocupação|
|GAD7<br>3|Mepreocupo muito com coisas diferentes|
|4|Tenhoproblemaspara relaxar|
|5|Se sinto tão inquieto/a que tenho dificuldade<br>de ficarparado/a|
|6|Fico facilmente irritado/a ou irritável|
|7|Sinto medo como se algo terrível vai acontecer|  
Total 1 a 7

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: Escala de Mania de Young<sup>17</sup> -->
Uma das mais frequentes escalas para avaliar sintomas de mania. Um escore acima de 20 tem valor preditivo positivo de 74,6% para episódio maníaco agudo e intenso. Versão em Português validada por Dr. José Antonio Alves Vilela.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: 1. Humor e afeto elevados -->
- (0) Ausência de elevação do humor ou afeto  
- (1) Humor ou afeto discreta ou possivelmente aumentados, quando questionado  
- (2) Relato subjetivo de elevação clara do humor; mostra-se otimista, autoconfiante, alegre; afeto apropriado ao conteúdo do pensamento  
- (3) Afeto elevado ou inapropriado ao conteúdo do pensamento; jocoso  
- (4) Eufórico; risos inadequados, cantando  
2. Atividade motora - energia aumentada  
- (0) Ausente  
- (1) Relato subjetivo de aumento da energia ou atividade motora  
- (2) Apresenta-se animado ou com gestos aumentados  
- (3) Energia excessiva; às vezes hiperativo; inquieto (mas pode ser acalmado)  
- (4) Excitação motora; hiperatividade contínua (não pode ser acalmado)

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: 3. Interesse sexual -->
- (0) Normal; sem aumento  
- (1) Discreta ou possivelmente aumentado  
- (2) Descreve aumento subjetivo, quando questionado  
- (3) Conteúdo sexual espontâneo; discurso centrado em questões sexuais; autorrelato de hipersexualidade  
- (4) Relato confirmado ou observação direta de comportamento explicitamente sexualizado, pelo entrevistador ou outras pessoas

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: 4. Sono -->
- (0) Não relata diminuição do sono  
- (1) Dorme menos que a quantidade normal, cerca de 1 hora a menos do que o seu habitual  
- (2) Dorme menos que a quantidade normal, mais que 1 hora a menos do que o seu habitual  
- (3) Relata diminuição da necessidade de sono  
(4) Nega necessidade de sono  
5. Irritabilidade  
- (0) Ausente  
(1)  
- (2) Subjetivamente aumentada  
- (3)  
(6) Irritável em alguns momentos durante a entrevista; episódios recentes (nas últimas 24 horas) de ira ou irritação na enfermaria  
- (5)  
(6) Irritável durante a maior parte da entrevista; ríspido e lacônico o tempo todo  
- (7)  
(8) Hostil; não cooperativo; entrevista impossível  
6. Fala (velocidade e quantidade)  
(0) Sem aumento  
(0)  
(0) Percebe-se mais falante do que o seu habitual  
- (3)  
- (4) Aumento da velocidade ou quantidade da fala em alguns momentos; verborreico, às vezes (com solicitação, consegue-se interromper a fala) (5)  
(6) Quantidade e velocidade constantemente aumentadas; dificuldade para ser interrompido (não atende a solicitações; fala junto com o entrevistador)  
(7)  
- (8) Fala pressionada, ininterruptível, contínua (ignora a solicitação do entrevistador)  
7. Linguagem  
- (0) Sem alterações  
- (1) Circunstancial; pensamentos rápidos  
- (2) Perde objetivos do pensamento; muda de assuntos frequentemente; pensamentos muito acelerados  
- (3) Fuga de ideias; tangencialidade; dificuldade para acompanhar o pensamento; ecolalia consonante  
- (4) Incoerência; comunicação impossível  
8. Conteúdo (0) Normal (1) (2) Novos interesses e planos compatíveis com a condição sociocultural do paciente, mas questionáveis (3) (4) Projetos especiais totalmente incompatíveis com a condição socioeconômica do paciente; hiper-religioso (5) (6) Ideias supervalorizadas (7) (8) Delírios  
9. Comportamento disruptivo agressivo  
(0) Ausente, cooperativo (1)  
(2) Sarcástico; barulhento, às vezes, desconfiado (3) (4) Ameaça o entrevistador; gritando; entrevista dificultada (5) (6) Agressivo; destrutivo; entrevista impossível  
10. Aparência (0) Arrumado e vestido apropriadamente  
- (1) Descuidado minimamente; adornos ou roupas minimamente inadequados ou exagerados (2) Precariamente asseado; despenteado moderadamente; vestido com exagero  
- (3) Desgrenhado; vestido parcialmente; maquiagem extravagante  
(4) Completamente descuidado; com muitos adornos e adereços; roupas bizarras  
11. Insight (discernimento)  
- (0) Insight presente: espontaneamente refere estar doente e concorda com a necessidade de tratamento (1) Insight duvidoso: com argumentação, admite possível doença e necessidade de tratamento  
- (2) Insight prejudicado: espontaneamente admite alteração comportamental, mas não a relaciona com a doença, ou discorda da necessidade de tratamento  
- (3) Insight ausente: com argumentação, admite de forma vaga alteração comportamental, mas não a relaciona com a doença e discorda da necessidade de tratamento  
- (4) Insight ausente: nega a doença, qualquer alteração comportamental e necessidade de tratamento.  
Escala de movimentos involuntários anormais  
Antes ou depois de completar o escore, os médicos devem observar o seguinte:  
1. Observar a marcha no caminho para a sala.  
2. Fazer o paciente jogar fora goma de mascar ou remover dentadura, caso esta esteja mal encaixada.  
3. Determinar se o paciente está ciente de cada movimento.  
- 4.Fazer o paciente se sentar em uma cadeira firme e sem braços, com as mãos sobre os joelhos, as pernas ligeiramente afastadas e os pés nivelados no chão. Nesse momento e durante todo o exame, procurar movimentos no corpo inteiro.  
5. Fazer o paciente se sentar com as mãos não apoiadas, pendentes sobre os joelhos.  
6. Pedir ao paciente para abrir a boca duas vezes. Procurar movimentos linguais.  
7. Pedir para o paciente protrair a língua duas vezes.  
8. Pedir para o paciente bater o polegar contra cada dedo da mão por 15 s em cada mão. Observar face e pernas.  
9. Fazer com que o paciente fique de pé com os braços estendidos para frente.  
Graduar cada um dos itens a seguir em escala de 0 a 4 com relação à maior gravidade observada:  
- 0 = nenhuma  
- 1 = mínima, podendo ser normal extremo  
- 2 = leve  
- 3 = moderada  
- 4 = grave  
Os movimentos que ocorrem somente após a ativação merecem um ponto a menos que os que ocorrem espontaneamente.  
|Categoria|Item|Intervalo dos escorespossíveis|
|---|---|---|
|Movimentos faciais e orais|Músculos de expressão facial|0 1 2 3 4|
||Lábios e áreaperioral(ao redor da boca e nariz)|0 1 2 3 4|
||Maxilares|0 1 2 3 4|
||Língua|0 1 2 3 4|  
|Movimentos das<br>extremidades|Braços|0 1 2 3 4|
|---|---|---|
||Pernas|0 1 2 3 4|
|Movimentos do tronco|Pescoço, ombros equadris|0 1 2 3 4|
|Julgamentoglobal|Gravidade dos movimentos|0 1 2 3 4|
||Anormais Percepção dopaciente em|0 1 2 3 4|
||Consciência do paciente dos movimentos anormais (0 = não ciente; 4 = desconforto<br>grave)|0 1 2 3 4|  
Adaptado de Guy W: ECDEU [Early Clinical Drug Evaluation Unit] Assessment Manual for Psychopharmacology. Rockville (MD), National Institute of Health, Psychopharmacology Research Branch, 1976. Copyright 1976 por US Department of Health, Education and Welfare.  
**APÊNDICE 2**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **1. Escopo e finalidade do Protocolo** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Transtorno Esquizoafetivo foi iniciada com reunião presencial para delimitação do escopo e com o objetivo da sua atualização, no dia 24/05/2019, em Brasília.  
A reunião presencial teve a participação de cinco membros do Grupo Elaborador – dois especialistas e três metodologistas –, além de uma representante de sociedade médica, a Coordenadora Geral de Saúde Mental, Álcool e Outras Drogas do Ministério da Saúde e quatro representantes do Comitê Gestor (DGITIS).  
A dinâmica da reunião foi conduzida com base no PCDT de Transtorno Esquizoafetivo vigente (Portaria SAS/MS nº 1.203 de 04/11/2014) e na estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida pelos participantes, com o objetivo de atualizar o texto, revisar as condutas clínicas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Os especialistas foram nomeados como relatores e responsáveis pela redação e atualização do texto, que foi distribuído entre eles. Foi-lhes dada orientação de referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica, atualizando os dados epidemiológicos descritos no PCDT vigente.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Por questões operacionais, foi decido que o escopo deste PCDT seria delimitado ao tratamento medicamentoso do Transtorno Esquizoafetivo. Na reunião, foram levantados inúmeros medicamentos para incorporação, entretanto, todos eram _off label_ para a indicação proposta, exceto o zuclopentixol.  
O zuclopentixol é um antipsicótico disponível em apresentações que facilitam sua administração (injetável, oral e decanoato) em emergências psiquiátricas, mas deve ser visto com cuidado. Foram realizadas buscas na literatura médica que mostraram pouquíssimos estudos comparativos com haloperidol. Os estudos são pequenos, com achados mal relatados e falhas  
metodológicas importantes. Não há evidência de que seja mais ou menos eficaz no controle da psicose aguda com agressividade ou na prevenção de efeitos adversos do que o haloperidol intramuscular, sendo que nenhum dos dois têm um início rápido de ação. O uso de acetato de zuclopentixol pode resultar em menor número de injeções coercitivas e a dose baixa pode ser tão eficaz quanto a dose mais alta do medicamento. Seu uso na forma de decanoato requer igual frequência de medicamentos antiparkisonianos no controle de efeitos colaterais que o decanoato de haloperidol. Apesar de requerer menor número de injeções coercivas na fase aguda, não mostrou superioridade em médio e longo prazo. Em virtude da qualidade metodológica dos estudos, os especialistas concordaram em não elaborar um parecer técnico-científico para submissão à Conitec.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **Colaboração externa** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **Avaliação da Subcomissão de Protocolos Clínicos e Diretrizes Terapêuticas** -->
O PCDT foi apresentado na 82ª reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada no dia 08 de setembro de 2020, com a participação de áreas deste Ministério que decidiram, por unanimidade, pautar o tema na reunião da Conitec.

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **Consulta Pública** -->
A Consulta Pública nº 55/2020, do Protocolo Clínico e Diretrizes Terapêuticas de Transtorno Esquizoafetivo, foi realizada entre os dias 04/11/2020 a 30/11/2020. Foram recebidas 159 contribuições, as quais foram avaliadas em sua totalidade, de modo quantitativo e qualitativo.  O conteúdo integral das contribuições encontra-se disponível na página da Conitec em: http://conitec.gov.br/images/Consultas/Relatorios/2020/20201104_PCDTTranstorno_Esquizoafetivo_CP55.pdf

---

<!-- METADADOS: doenca: Transtorno Esquizoafetivo | secao: **3. Busca da evidência e recomendações** -->
À reunião de escopo realizada em 24/05/2019 para a atualização deste Protocolo, ficou decidido que as buscas se limitariam às meta-análises publicadas a partir de 2014, ano da publicação do último PCDT.  
Em 10 de janeiro de 2020, foram realizadas buscas na literatura na base de dados Medline via Pubmed, com o termo _Schizoaffective disorders_ e foram encontradas 38 meta-análises. Na base de dados Embase, com o termo _Schizoaffective Psychosis_ , foram encontradas 102 meta-análises. Foram excluídas as 16 duplicatas e foram selecionados apenas dois artigos, conforme **Quadro A** .  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline<br>(via<br>PUBMED)<br>Data da<br>busca:<br>10/01/202<br>0|"Schizoaffective<br>disorder"AND Meta-<br>Analysis[ptyp] AND<br>"2014/01/01"[PDat]<br>"2020/01/10"[PDat])|38|**16**|2<br>**Motivo das**<br>**exclusões:**<br>**Não relacionados**<br>**ao PCDT, não**<br>**relevantes,**<br>**tratamentos não**|
|Embase<br>Data da<br>busca:<br>10/01/202<br>0|'schizoaffective<br>psychosis'/exp AND<br>[meta analysis]/lim AND<br>[2014-2020]/py|102||**medicamentosos,**<br>**estudos**<br>**genéticos,**<br>**outras doenças,**|  
Os seguintes foram estudos selecionados a partir da busca:  
Santelmann H, Franklin J, Bußhoff J, Baethge C. Diagnostic shift in patients diagnosed with schizoaffective disorder: a systematic review and meta-analysis of rediagnosis studies. Bipolar Disord. 2016;18(3):233-46 – referência 6.  
Matthews PRL, Horder J, Pearce M. Selective noradrenaline reuptake inhibitors for schizophrenia. Cochrane Database Syst Rev. 2018;1:Cd010219 – referência 52.  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização deste PCDT.

---

