<!-- METADADOS: doenca: Doença de parkinson | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 16, DE 1 DE AGOSTO DE 2025.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Doença de Parkinson.  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 4 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Doença de Parkinsin no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup>º</sup> 954/2024 e o Relatório de Recomendação n<sup>°</sup> 957 de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Doença de Parkinson.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Doença de Parkinson, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Doença de Parkinson.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria conjunta SAS/SCTIE nº 291, de 31 de outubro de 2017, publicada no Diário Oficial da União (DOU) nº 215, de 09 de novembro de 2017, seção 1, página 60.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: FERNANDA DE NEGRI -->
1

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **1.        INTRODUÇÃO** -->
A doença de Parkinson (DP) é uma doença crônica, progressiva e degenerativa, cuja apresentação típica inclui incapacidade progressiva para os pacientes afetados<sup>1</sup> . As características da doença incluem sintomas motores, como tremor de repouso, bradicinesia, rigidez com roda denteada e anormalidades posturais, e não motores, como alterações do olfato, distúrbios do sono, constipação, mudanças emocionais, depressão, ansiedade, sintomas psicóticos, prejuízos cognitivos e demência<sup>1</sup> . A DP ocorre devido à degeneração das células situadas na substância negra (uma região do cérebro), que produzem o neurotransmissor dopamina. Assim, a degeneração celular leva à falta ou à diminuição da produção de dopamina, afetando os movimentos e provocando os sintomas da doença<sup>1</sup> .  
A taxa de incidência global de DP em pessoas com 40 anos ou mais foi de 37,55 por 100.000 pessoas-ano em mulheres e 61,21 por 100.000 pessoas-ano em homens. As taxas de incidência em mulheres variaram de 3,26 por 100.000 pessoas-ano, na faixa etária de 40 a 49 anos, a 103,48 com mais de 80 anos. Entre os homens, as taxas de incidência aumentam de 3,57 por 100.000 pessoas-ano na faixa etária de 40 a 49 para 258,47 na idade superior a 80 anos<sup>2</sup> .  
No Brasil, existem poucos dados de base populacional acerca da DP. Um estudo conduzido na cidade de Bambuí estimou a prevalência de 3,3% para DP entre os maiores de 64 anos<sup>3</sup> . Outro estudo transversal conduzido em Caeté encontrou prevalência de parkinsonismo de 10.656/100.000 indivíduos e, para DP, prevalência bruta foi de 3.100/100.000 indivíduos<sup>4</sup> .  
Em 2016, os distúrbios neurológicos foram a principal causa de anos de vida ajustados por incapacidade (DALYs) no mundo (276 milhões [IC 95% 247 a 308]) e a segunda principal causa de mortes (9,0 milhões [IC 95% 8,8 a 9,4]). Dentre esses distúrbios, os casos de DP são os que mais aumentam. Ao longo da última geração, a carga global da DP mais que dobrou devido ao aumento do número de pessoas idosas, o aumento da expectativa de vida e fatores ambientais. Por exemplo, profissionais expostos a pesticidas e inseticidas têm duas vezes mais chances de desenvolver DP tardia (OR 2,2; IC 95% 1,1 a 4,3)<sup>5,6</sup> . Assim, alguns fatores, como os demográficos e ambientais, podem aumentar substancialmente a carga futura da DP<sup>7</sup> . Outros fatores de risco associados com o desenvolvimento de DP são: ser do sexo masculino e ter distúrbios afetivos, como ansiedade e depressão<sup>8</sup> .  
Apesar de ser uma doença degenerativa, o curso clínico é muito variável e desigual entre os pacientes. Na maioria dos pacientes, a progressão individual é regular e sem mudanças rápidas. O prognóstico da DP está relacionado com as múltiplas variantes da doença, como por exemplo, a idade de início dos sintomas, a gravidade dos sintomas motores e não motores e a resposta terapêutica.  
É possível estratificar os pacientes com DP de acordo com três grupos:  
- Indivíduos com predominância motora leve (49% a 53% dos indivíduos com DP): apresentam sintomas leves, boa  
- resposta aos medicamentos dopaminérgicos e progressão mais lenta da doença<sup>9</sup> ;  
- Indivíduos com subtipo intermediário (35% a 39% dos indivíduos com DP): a idade de início dos sintomas, a gravidade  
- dos sintomas e a resposta aos medicamentos são intermediárias<sup>9</sup> ;  
- Indivíduos com subtipo maligno difuso (9% a 16% dos indivíduos com DP): apresentam sintomas motores e não  
- motores precoces proeminentes, má resposta aos medicamentos e progressão mais rápida da doença<sup>9</sup> .  
Com a evolução da doença, cerca de 25% a 40% dos pacientes com DP eventualmente desenvolvem demência, devido ao comprometimento cortical<sup>10</sup> . Estudos epidemiológicos sugerem que a DP reduz a expectativa de vida<sup>11–13</sup> , estimando um tempo médio de 15 anos desde o diagnóstico até a morte<sup>14</sup> .  
2  
A prevenção primária da DP apresenta vários desafios e limitações. Porém, há relatos de que o exercício físico apresenta benefícios não só para DP, mas para doenças crônicas no geral<sup>15</sup> . A prevenção secundária (por exemplo, dieta saudável e rica em antioxidantes, consumo de cafeína, atividades cognitivas e sociais), uma vez que a DP tenha sido diagnosticada, busca reduzir a taxa de progressão, parar ou mesmo reverter a morte neuronal<sup>16–18</sup> .  
A identificação de fatores de risco da DP e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer critérios diagnósticos, de tratamento e monitoramento de pacientes com DP.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **2.       CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- G20 Doença de Parkinson.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **3.        DIAGNÓSTICO** -->
O quadro clínico da DP é muito diverso. A evolução, gravidade e progressão dos sintomas variam enormemente de um paciente para outro. Como, até o momento, inexiste exame ou teste diagnóstico para esta doença, o seu diagnóstico permanece sendo eminentemente clínico.  
Em 2015, a _Movement Disorder Society_ (MDS) publicou os critérios clínicos para facilitar e harmonizar o diagnóstico da DP<sup>21</sup> , definidos por um consenso entre especialistas (Quadro 1). Se possível, recomenda-se considerar os critérios prodrômicos propostos pela MDS, em 2019<sup>22,23</sup> .  
Para o diagnóstico de DP é indispensável que o paciente apresente parkinsonismo (i.e., presença de bradicinesia em combinação com tremor de repouso ou rigidez) e os demais critérios a seguir, conforme diagnóstico **:**  
Para o diagnóstico estabelecido de DP:  
**I-** Ausência de critérios de exclusão; e  
**II-** Presença de pelo menos 2 critérios de suporte; e  
**III-** Ausência de sinais de alerta, os chamados _red flags._  
Para o diagnóstico de DP provável:  
**I-** Ausência de critérios de exclusão; e  
**II-** Presença de sinais de alerta contrabalanceado pela presença de critérios de suporte:  
- Se há um sinal de alerta, deve haver pelo menos um critério de suporte;  
- Se há dois sinais de alerta, dois critérios de suporte são necessários.  
Observação: Não mais que dois sinais de alerta são permitidos nesta categoria.  
Os critérios de suporte, de exclusão, os sinais de alerta (red flags) são descritos no Quadro 1.  
**Quadro 1 -** Critérios clínicos para o diagnóstico da doença de Parkinson.  
|**Crité**|**rios de suporte**|
|---|---|
||Resposta dramática à terapia dopaminérgica;|
||Presença de discinesias induzidas pela levodopa;|
||Tremor de repouso em membros;|  
3  
 Presença de perda olfatória ou denervação simpática cardíaca por cintilografia

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Critérios de exclusão** -->
- Anormalidade cerebelar inequívoca;  
- Paralisia supranuclear no olhar vertical para baixo ou lentificação das sácades verticais para baixo;  Diagnóstico de provável demência frontotemporal, variante comportamental ou afasia primária progressiva, de acordo com os critérios atuais<sup>24</sup> , dentro dos primeiros 5 anos da síndrome parkinsoniana;  Sintomas parkinsonianos restritos aos membros inferiores por mais de 3 anos;  Tratamento com medicamentos bloqueadores dopaminérgicos ou agentes depletores de dopamina em doses e por tempo suficiente para causar parkinsonismo induzido por medicamento;  Ausência de resposta observável a altas doses de levodopa em pacientes com sintomas parkinsonianos pelo menos moderado;  Perda sensorial cortical inequívoca (ou seja, grafestesia, estereognosia com modalidades sensoriais primárias intactas), apraxia ideomotora de membro ou afasia;  Neuroimagem funcional normal do sistema dopaminérgico pré-sináptico;  Documentação de uma condição alternativa conhecida por produzir parkinsonismo e plausivelmente ligada aos sintomas do paciente ou avaliação de especialista sugerindo que uma síndrome alternativa é mais provável do que a DP.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Sinais de alerta (** **_red flags_ )** -->
- Rápida progressão do comprometimento da marcha exigindo uso regular de cadeira de rodas dentro de 5 anos após  
- o início dos sintomas;  Ausência completa de progressão dos sintomas ou sinais motores ao longo de 5 ou mais anos, a menos que a estabilidade esteja relacionada ao tratamento;  Disfunção bulbar precoce: disfonia grave ou disartria (fala ininteligível na maioria das vezes) ou disfagia grave (necessita de alimentos moles, uso de sonda nasogástrica ou alimentação por gastrostomia) nos primeiros 5 anos;  Disfunção respiratória inspiratória: estridor inspiratório diurno ou noturno ou suspiros inspiratórios frequentes;  Insuficiência autonômica grave nos primeiros 5 anos de doença, que pode incluir hipotensão ortostática (i.e., diminuição ortostática da pressão arterial dentro de 3 minutos em pé por pelo menos 30 mm Hg sistólica ou 15 mm Hg diastólica, na ausência de desidratação, uso de medicamentos ou outras doenças que possam explicar de forma plausível a disfunção autonômica) ou retenção urinária grave ou incontinência urinária nos primeiros 5 anos de doença (excluindo incontinência de esforço de longa duração ou pequena quantidade em mulheres), que não é simplesmente incontinência funcional. Nos homens, a retenção urinária não deve ser atribuída à doença da próstata e deve estar associada à disfunção erétil;  Quedas recorrentes (mais de 1 por ano) devido ao equilíbrio prejudicado dentro de 3 anos do início;  Anterocolo desproporcional (distônico) ou contraturas de mãos ou pés nos primeiros 10 anos;  Ausência de qualquer uma das características não motoras comuns da doença, apesar de 5 anos de duração da doença. Estes incluem disfunção do sono (insônia de manutenção do sono, sonolência diurna excessiva, sintomas de distúrbio comportamental do sono REM), disfunção autonômica (constipação, urgência urinária diurna, hipotensão ortostática), hiposmia ou disfunção psiquiátrica (depressão, ansiedade ou alucinações);  
- Sinais do trato piramidal inexplicáveis, definidos como fraqueza piramidal ou hiperreflexia patológica clara  
- (excluindo assimetria reflexa leve e resposta plantar extensora isolada);  
- Parkinsonismo simétrico bilateral.  
Legenda: DP: doença de Parkinson. Fonte: Postuma, 2015<sup>21</sup>  
4

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Demência** -->
A prevalência de demência em pacientes com DP situa-se em torno de 25% a 30%, o que representa cerca de seis vezes mais que a frequência observada na população geral<sup>25</sup> . A demência na DP (DDP) pode afetar domínios cognitivos fundamentais, como atenção, habilidades visuoespaciais, funções executivas e memória<sup>26</sup> . Sintomas comportamentais como apatia, alucinações visuais e delusões também são frequentes nos parkinsonianos com demência<sup>26</sup> . Os principais fatores associados ao aparecimento da DDP são a idade avançada e a duração da doença. Além desses, outros fatores de risco importantes são: a gravidade do parkinsonismo, o aparecimento de comprometimento cognitivo leve e a presença de problemas neuropsiquiátricos, especialmente a psicose, mas também ansiedade e depressão<sup>26</sup> .  
A demência proporciona uma perda adicional na qualidade de vida do paciente e de seus familiares e cuidadores. Além disso, está associada a aumento na mortalidade e dos custos gerais do tratamento.  
Para o diagnóstico da DDP, o paciente deverá apresentar<sup>27,28</sup> :  
1. Diagnóstico de DP segundo os critérios da MDS (Quadro 1)<sup>21</sup> ; **e**  
2. DP com início, pelo menos, um ano antes dos sintomas de demência; **e**  
3. Escore anormal no miniexame do estado mental (MEEM) (notas de corte sugeridas para a população brasileira  
segundo seus níveis de escolaridade); **e**  
4. Comprometimento das atividades de vida diária pela perda cognitiva; **e**  
5. Ausência de depressão maior; **e**  
6. Ausência de delírio; **e**  
7. Ausência de outras condições clínicas que justifiquem a perda cognitiva.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **4.        CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os indivíduos com suspeita e diagnóstico provável ou estabelecido de DP.  
Para o tratamento medicamentoso, serão incluídos os pacientes que apresentarem diagnóstico provável ou estabelecido de DP. Em relação à **cirurgia de implante de estimulador cerebral profundo** , serão considerados candidatos pacientes que apresentem todos os seguintes critérios<sup>29–38</sup> :  
- Diagnóstico estabelecido da DP; **e**  
- Complicações motoras incapacitantes da DP que não são bem controladas com o tratamento medicamentoso  
- disponível e para tremor refratário; **e**  
- Sintomas responsivos à levodopa (exceto pacientes cujo sintoma predominante é o tremor, que podem se beneficiar  
de tratamento cirúrgico independentemente de resposta prévia à levodopa); **e**  
- Evolução de cinco anos de doença, diminuindo assim a possibilidade de tratar-se de parkinsonismo atípico, situação  
em que a cirurgia não está indicada (exceção a este critério são os tremores incapacitantes não responsivos ao tratamento medicamentoso); **e**  
- Expectativa de melhora de sintomas motores do tipo tremor, bradicinesia e rigidez; **e**  
- Facilidade de acesso ao centro para que façam ajustes periódicos na programação do estimulador.  
Observação: Embora não haja limite de idade, pacientes jovens têm maior chance de obter benefício cirúrgico. A presença  
de comorbidades e a expectativa de vida devem ser avaliadas em todos os pacientes candidatos à cirurgia.  
5

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **5.        CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentarem contraindicação, hipersensibilidade ou intolerância a um dos medicamentos preconizados neste Protocolo estarão excluídos do uso do respectivo medicamento.  
Não serão considerados para cirurgia de implante de estimulador cerebral profundo os pacientes que apresentarem algum dos seguintes critérios<sup>29–38</sup> :  
- Comorbidades cardiovasculares, oncológicas de mau prognóstico, cerebrovasculares e infecções ativas; **ou**  
- Parkinsonismo-plus; **ou**  
- Significativa atrofia cerebral, microangiopatia significativa ou outras lesões estruturais significativas no exame de  
imagem; **ou**  
- Déficits cognitivos relevantes, demência, depressão maior, doença psiquiátrica grave não controlada ou sintomas psicóticos atuais ou passados espontâneos ou induzidos por levodopa. Embora a presença de sintomas psicóticos seja um critério de exclusão para cirurgia, eles não são caracterizados como um critério de exclusão se ocorrerem isoladamente na vigência de um quadro de intercorrência clínica ( _delirium_ ) ou induzidos por fármacos comumente relacionados como indutores de psicose.  
- Controle de sintomas axiais, especialmente da marcha, instabilidade postural, _freezing_ do período _on_ e distúrbios da fala que não respondem à levodopa, pois tais sintomas não responderão bem à cirurgia

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.        TRATAMENTO** -->
A natureza progressiva da DP e suas manifestações clínicas (motoras e não motoras), associada aos eventos adversos precoces e tardios da intervenção terapêutica, tornam o tratamento da doença bastante complexo. Até o momento, inexiste tratamento preventivo da DP.  
Estima-se que a taxa de morte dos neurônios dopaminérgicos da substância negra se situe ao redor de 10% ao ano<sup>39</sup> . Consequentemente, com o tempo, a sintomatologia parkinsoniana piora e a necessidade de medicamentos sintomáticos aumenta. O grau de resposta aos medicamentos vai decrescendo com a progressão da doença e novos sintomas surgem. Um objetivo desejado é reduzir ou interromper essa progressão<sup>16–18</sup> .

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.1.    Tratamento não medicamentoso** -->
A equipe multiprofissional de saúde tem papel importante no cuidado de pacientes com DP. Para o monitoramento e avaliação contínua destes pacientes, é possível usar ferramentas disponíveis, como por exemplo, a Classificação Internacional de Funcionalidade, Incapacidade e Saúde (CIF).  
A adoção da CIF é uma mudança de paradigma, pois é uma prática centrada no paciente e em sua condição de saúde, que influencia e é influenciada por diferentes domínios. O uso de instrumentos de avaliação, baseados em evidências científicas, permite aos profissionais da saúde conhecerem as necessidades de cada paciente e, então, estabelecerem as metas e condutas terapêuticas específicas. A avaliação do estado funcional do indivíduo com DP é essencial para o adequado planejamento da intervenção terapêutica e para determinar o impacto dessas intervenções. Nesse sentido, é imprescindível que o profissional de saúde selecione os instrumentos e medidas antes que as intervenções sejam definidas, para que os resultados sejam analisados e interpretados, direcionando as intervenções mais adequadas para cada paciente.  
Como a CIF permite conhecer a funcionalidade humana na perspectiva biopsicossocial, os profissionais da saúde que lidam com as pessoas com DP devem selecionar avaliações que contemplem os seus domínios da CIF:  
6  
- Estrutura e função do corpo: para o componente “Estruturas”, são consideradas todas as partes anatômicas, tais como:  
- membros, órgãos ou seus componentes. Já como “Funções” são consideradas as funções fisiológicas dos sistemas orgânicos, incluindo as psicológicas;  
- Atividades: são consideradas tarefas ou ações realizadas por um indivíduo, desde as áreas mais simples até as mais  
- complexas da vida;  
- Participação: consiste no envolvimento de um indivíduo em situação da vida real;  
- Fatores ambientais: incluem atitudes sociais, características arquitetônicas, estruturas legais e sociais e podem ser  
- consideradas como barreiras ou facilitadores;  
- Fatores pessoais: incluem a forma como a incapacidade é experimentada pelo indivíduo pelos fatores de gênero, idade,  
- educação, ocupação, experiências atuais e passadas<sup>40,41</sup> .  
O cuidado centrado nos pacientes com DP tem como premissa a participação e o envolvimento de vários profissionais da saúde para promoção do bem-estar, considerando a natureza complexa da doença<sup>42</sup> . A participação de profissionais da saúde varia de acordo com a evolução da doença e as prioridades das pessoas com DP<sup>43</sup> .  
No SUS, os Centros Especializados de Reabilitação (CER) possuem diferentes profissionais da saúde que podem promover o cuidado centrado nos pacientes, compartilhando a responsabilidade com os profissionais da Atenção Primária à Saúde (APS). A Política Nacional de Humanização (PNH), publicada em 2003, impulsiona mudanças nos modos de gerir e cuidar dos diferentes serviços da Rede de Atenção à Saúde, visando a atender os princípios do SUS.  
Nesse contexto, a Atenção Especializada em Reabilitação deve produzir, em conjunto com o usuário, seus familiares e acompanhantes, um Projeto Terapêutico Singular (PTS), baseado em avaliações multidisciplinares das necessidades e capacidades das pessoas com deficiência, incluindo dispositivos e tecnologia assistiva e com foco na produção da autonomia e o máximo de independência em diferentes aspectos da vida<sup>44</sup> .  
O PTS é um instrumento de organização e sistematização do cuidado construído entre equipe de saúde e usuário, considerando singularidades do sujeito e a complexidade de cada caso. Nota-se, portanto, que o PTS é um conjunto de propostas de condutas terapêuticas articuladas, para um sujeito individual ou coletivo, resultado da discussão coletiva de uma equipe de saúde<sup>45</sup> . Digno de nota que, ainda que os profissionais da saúde não atuem em equipe, é importante a consciência de cuidado multiprofissional para as pessoas com a DP e, sempre que necessário, deve-se referenciar o paciente para avaliação de outros profissionais e para condutas necessárias.  
O PTS envolve estratégias de avaliação e tratamentos não medicamentosos, baseados em evidência científica e indicados para a DP.  
No contexto da fisioterapia, os testes de avaliação da DP estão descritos no **Quadro 2** . As principais ações terapêuticas incluem: i) fisioterapia convencional (8 a 26 semanas, 2 a 3 vezes por semana e 15 a 60 minutos por sessão), ii) treinamento de esteira ergométrica (4 a 6 semanas, 3 vezes por semana e 45 minutos por sessão), e iii) Tai chi (10 a 24 semanas, 1 a 2 vezes por semana, 60 minutos por sessão). Estas estratégias são recomendadas pelos benefícios na velocidade para caminhar, força muscular, congelamento de marcha, equilíbrio, padrão da marcha, distância da caminhada e comprimento da passada. Outras estratégias, com menos benefícios relatados em literatura e, em alguns casos, contraindicadas, são as pistas auditivas e visuais, dança e sequências motoras complexas<sup>43</sup> .  
**Quadro 2** - Áreas centrais de avaliação em fisioterapia na doença de Parkinson.  
|**Área central**|**Nível da CIF**|**Teste validado para a doença de Parkinson**|
|---|---|---|
|Equilíbrio||Escala de Equilíbrio de Berg<sup>46–57</sup>|  
7  
|**Área central**|**Nível da CIF**|**Teste validado para a doença de Parkinson**|
|---|---|---|
||Capacidade|Teste de Alcance Funcional<sup>54,58–60</sup>|
||de equilíbrio|Índice de Marcha Dinâmica<sup>50,54,59,61,62</sup>|
|||MiniBESTest<sup>48,49,55,56,63–65</sup>|
|||Teste de predição de quedas em 3 etapas<sup>66–68</sup>|
||Desempenho<br>de equilíbrio|Escala de Confiança de Equilíbrio específica de atividades<sup>48–52,63,69,70</sup>|
|Marcha|Capacidade|Teste de Caminhada de 10 m<sup>58</sup>|
||de caminhar|Teste de Caminhada de 6 minutos<sup>71–73</sup>|
||Desempenho<br>ao caminhar|_Freezing of Gait Questionnaire_(FOG-Q), tradução livre “Questionário de<br>congelamento da marcha”. O_New_FOG-Q não tem as propriedades de medidas<br>testadas para a versão em português.<sup>57,58,74–76</sup>|
|Marcha, Equilíbrio<br>e<br>Mudança<br>de|Capacidade<br>de mobilidade|_Timed Get-Up and Go_(TUG), tradução livre “Teste do Levante e Vá<br>cronometrado”.<sup>54,59,77</sup>|
|posturas|funcional|_Parkinson Activity Scale_(PAS), tradução livre “Escala de Atividade em Parkinson”<br>(A versão em português não está disponível na revista científica)<sup>78,79</sup>|
|Mudança<br>de|Capacidade|Sentado para de pé 5 vezes<sup>80</sup>|
|posturas|de mobilidade<br>funcional|_Parkinson Activity Scale_(PAS), tradução livre “Escala de Atividade em Parkinson”<br>(A versão em português não está disponível na revista científica)<sup>78,79</sup>|
|Atividades manuais|Carregar,|Teste dos nove pinos e buracos<sup>81</sup>|
||mover<br>e<br>manusear|_Test d'Evaluation des Membres Superieurs Des Personnes Agees_" (TEMPA),<br>tradução livre “Teste de Avaliação dos membros Superiores em Pessoas Idosas”<sup>82</sup>|
||objetos|_Purdue Pegboard Test_, tradução livre “Placa de Purdue”<sup>83</sup>|
|||Teste dos quadrados<sup>84,85</sup>|
|Outras|Funções<br>de<br>movimento|_Movement Disorders Society – Unified Parkinson’s Disease Rating Scale_(MDS-<br>UPDRS), tradução livre “Escala Unificada de Estadiamento da doença de Parkinson<br>da Sociedade de Transtornos do Movimento”<sup>86–88</sup>|
||Qualidade de<br>vida|_Parkinson’s Disease Questionnaire-39_(PDQ-39), tradução livre “Questionário da<br>doença de Parkinson 39 itens”<sup>89,90</sup>|  
Fonte: Modificado de Keus et al. (2014)<sup>43</sup>  
As intervenções modificam a natureza, o tempo e duração das atividades, tornando-as menos intensas no método e sequência, e transformando ações complexas em subtarefas simples. Com isso, a terapia ocupacional contribui para o encorajamento da pessoa com DP no autocuidado, a lidar com o estresse e pressão do tempo no desempenho de atividade, a otimizar a prática de habilidades motoras braço/mão, a aplicar estratégias com foco, a aplicar estratégias cognitivas de movimento, a minimizar duplas tarefas e a otimizar o ambiente físico. Portanto, a terapia ocupacional é indicada quando as pessoas com DP experimentam limitações nas atividades relacionadas a cuidados pessoais, mobilidade funcional, limpeza, cuidado de familiares e animais de estimação, trabalho, lazer; e quando os cuidadores têm problemas para supervisionar ou apoiar a pessoa com DP nas atividades diárias<sup>91</sup> .  
8  
O tratamento da disartria hipocinética na DP pode ser realizado por profissionais da fonoaudiologia considerando a técnica de Lee Silverman _Voice Treatment_ (LSVT) (16 sessões de 50 minutos cada por 4 semanas). O tratamento tem benefícios em pressão sonora e função laríngea<sup>92</sup> . Entretanto, como este método precisa de um profissional especializado com acreditação para conduzi-lo, outras estratégias recomendadas para tratar a disfagia são a retração cervical, exercícios para língua, pescoço, ombros, fonação e sialorreia, deglutição com esforço, consistência de néctar e consistência de mel. Para tratamento da sialorreia (i.e., produção excessiva de saliva), recomenda-se o uso de metrônomo (i.e., paciente tem que engolir com cada “bip” por 4 semanas, meia hora por dia).  
As intervenções no contexto da enfermagem incluem informação e educação em saúde, cuidado dos sintomas (por exemplo, urgência/emergência urinária), orientação sobre armazenamento e horários de uso de medicamentos, apoio para cuidadores, coordenação de cuidados e cuidados paliativos para as pessoas com DP<sup>93</sup> .  
As intervenções em psicologia incluem a terapia cognitivo-comportamental individual ou em grupo, intervenções baseadas em consciência plena (mindfulness), psicodrama e programa de educação<sup>94</sup> .  
Quanto à nutrição, o cuidado considera o estágio da doença (Quadro 3).  
**Quadro 3** - Possibilidades de atuação de Nutricionista nos cuidados das pessoas com doença de Parkinson.  
|**Estágio da DP**|**Cuidado nutricional**|
|---|---|
|Diagnóstico<br>e|Medidas antropométricas (massa corporal, estatura, índice de massa corporal)|
|estágio inicial|Avaliação nutricional por meio de escala e da ingestão dietética|
||Informações escrita e verbal que incluam: Orientação de dieta saudável, peso ideal, aconselhamento<br>dietético para outras comorbidades (diabetes, doença cardíaca etc.), dieta rica em fibras para prevenir a<br>constipação|
||Ausência de evidência para recomendação de suplementação com antioxidantes ou coenzima Q10|
|Estágio avançado|Além das orientações do estágio inicial, atentar para: perda de peso não intencional, diminuição de<br>ingestão oral, dificuldades de deglutição, aumento da frequência de discinesias, disfunção do trato<br>gastrointestinal, eventos adversos dos medicamentos, dificuldades físicas, avaliação óssea, sobrepeso<br>pós-DBS (_deep brain stimulation -_estimulação cerebral profunda; recomendações: dieta com baixo teor<br>de gordura e rica em fibras, estabelecer peso saudável ideal, exercício regular).|
||Suporte nutricional oral (fortificação de alimentos, alta energia/proteína, refeições pequenas e regulares<br>com alta densidade energética, alimentos orais, conselhos sobre dietas de textura modificada) ou enteral<br>(Gastrostomia Endoscópica Percutânea/dietas de textura modificada)<br>Pode-se considerar a manipulação de proteínas na dieta para flutuações motoras descontroladas.|
|Estágio terminal|Além das orientações dos estágios anteriores, atentar para: suporte nutricional, prognóstico,<br>aconselhamento para equipe de cuidados paliativos e decisão da equipe multidisciplinar.|
||O suporte nutricional artificial pode ser retirado se causar desconforto ou angústia, ou de não interesse<br>do paciente.|
||Reduzir o volume de alimentação enteral para evitar sobrecarga de fluidos.|
||A alimentação oral pode ser oferecida desde que não haja riscos de aspiração ou asfixia.|  
Fonte: Modificado de Green (2021)<sup>95</sup>  
9

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.2      Tratamento medicamentoso** -->
O tratamento sintomático deve ser introduzido no momento do diagnóstico da DP com o objetivo de diminuir significativamente os sintomas, reduzindo a incapacidade e melhorando a qualidade de vida do paciente. O médico deve considerar a cronicidade da doença e a necessidade de tratamento longo, avaliando a oportunidade do aumento de doses e da associação de medicamentos. O tratamento medicamentoso da DP é complexo, envolvendo o uso concomitante de vários medicamentos em múltiplas administrações diárias.  
A escolha do medicamento ou da associação de medicamentos mais adequada depende do estágio da doença, da sintomatologia presente, da idade do paciente, da eficácia e dos potenciais eventos adversos, da comodidade posológica, suas disponibilidades, seus custos, e a opção do paciente após o devido esclarecimento pelo médico.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.2.1   Critérios para início do tratamento** -->
O momento para se iniciar o tratamento sintomático, medicamentoso, na DP ainda é controverso. Há autores que advogam que o tratamento medicamentoso deve ser iniciado quando o paciente percebe interferência dos sintomas nas suas atividades diárias<sup>96</sup> . Outros acreditam que o início precoce, assim que o diagnóstico é realizado e independente do impacto nas atividades diárias dos pacientes, inibiria mecanismos compensatórios cerebrais devido à diminuição de dopamina que poderia agravar a evolução da doença a médio e longo prazo<sup>97</sup> .  
Em suma, a literatura sugere que o tratamento sintomático da DP seja iniciado assim que o diagnóstico é confirmado, sendo obrigatório para os pacientes com incapacidade funcional causada por sintomas parkinsonianos. A incapacidade funcional deve ser definida individualmente, pois cada paciente apresentará distintas implicações funcionais<sup>98</sup> .

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Sintomas leves com ou sem prejuízo funcional** -->
<mark>A eficácia do medicamento para a DP inicial pode ser mensurada pela demonstração de benefício por estudo randomizado de alta qualidade, sem outro estudo com resultado conflitante</mark><sup>99</sup> <mark>. Cinco medicamentos podem ser usados em monoterapia nessa etapa do tratamento clínico: levodopa em associação com carbidopa ou benserazida; agonistas dopaminérgicos (pramipexol); e um inibidor da MAO-B (rasagilina)</mark><sup>99–102</sup> <mark>.</mark>  
<mark>A produção de s</mark> elegilina, um inibidor da MAO-B como rasagilina, foi descontinuada no Brasil. Pacientes em uso de selegilina e com resposta adequada devem passar a utilizar rasagilina, não sendo necessária a redução gradual de dose de selegilina. No caso de interrupção de selegilina 10 mg ao dia sem a substituição por rasagilina, recomenda-se reduzir a dose para 5 mg ao dia e, após uma semana, suspender o tratamento; no caso de interrupção de selegilina 5 mg ao dia sem substituição por rasagilina, não há necessidade de redução gradual.  
<mark>Habitualmente, se utiliza a levodopa com intervalo entre cinco a três horas durante o dia, pelo menos uma hora antes ou depois das refeições ou diminuindo a ingestão proteica, assim reduzindo a latência do início de seu efeito</mark><sup>103,104</sup> <mark>. Um estudo clínico elencou os eventos adversos que foram significativamente mais comuns entre aqueles que receberam levodopa 600 mg/dia na comparação com placebo, e incluem discinesias, náusea, infecção, hipertonia e cefaleia</mark><sup>105</sup> <mark>.</mark>  
<mark>Outros medicamentos com ação anticolinérgica foram utilizados nas fases iniciais da DP (triexifenidil, biperideno e amantadina). O triexifenidil, especialmente em jovens, é possivelmente eficaz nas doses orais diárias de 2 a 8 mg, mas seus eventos adversos (como prejuízo cognitivo, alucinações, boca seca, visão turva e retenção urinária) fazem com que não seja mais uma alternativa de primeira escolha. Os estudos referentes à sua possível ação, especialmente contra o tremor, são conflitantes</mark><sup>99–</sup> 103 <mark>. Já sobre a amantadina, os estudos sobre seu uso em doses diárias de 100 a 300 mg nas fases iniciais da doença são pouco</mark>  
10  
<mark>conclusivos. Além disso, seus eventos adversos já conhecidos, como declínio cognitivo, alucinações, edema de membros inferiores, não permitem que ela seja uma alternativa de primeira escolha</mark><sup>99–102</sup> <mark>. O biperideno por sua vez é um anticolinérgico utilizado no tratamento dos sintomas de rigidez e tremor em pacientes com doença de Parkinson, especialmente em fases iniciais</mark><sup>106,107</sup> <mark>.</mark>  
<mark>Com a progressão da doença e aumento da sintomatologia, há necessidade de aumento da dose da levodopa ou dos agonistas dopaminérgicos ou a associação de dois ou mais medicamentos com mecanismos de ação diferentes. Levodopa, pramipexol e rasagilina são eficazes no tratamento combinado nas fases iniciais e estáveis da doença</mark><sup>99–102</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Prevenção de flutuações motoras e discinesias** -->
<mark>As flutuações motoras são modificações na resposta à terapia dopaminérgica, que aparecem com a progressão da doença. As mais frequentes são encurtamento da duração do efeito (fenômeno</mark> _<mark>wearing off</mark>_ <mark>) e interrupção súbita de sua ação, levando a uma situação de resposta/falta de resposta ao medicamento (fenômeno</mark> _<mark>on-off</mark>_ <mark>). Discinesias no pico da dose também são complicações dos medicamentos dopaminérgicos.</mark>  
<mark>O tempo com a doença e a dose de levodopa ou dos agonistas dopaminérgicos são diretamente proporcionais à frequência de flutuações motoras e discinesias. As complicações motoras podem atingir cerca de 80% dos pacientes jovens e 44% dos mais velhos após 5 anos de tratamento</mark><sup>108</sup> <mark>.</mark>  
<mark>O uso de pramipexol nas fases iniciais da doença, atrasando a introdução ou o aumento da dose da levodopa, é eficaz no retardo do aparecimento de flutuações motoras e discinesias</mark><sup>99,100</sup> <mark>. Todavia, mesmo não iniciando o tratamento com levodopa, a maioria dos pacientes necessita utilizá-la após dois anos do início dos sintomas</mark><sup>103</sup> <mark>.</mark>  
<mark>Ainda, mais de 40% dos pacientes em uso de agonistas dopaminérgicos, especialmente pramipexol, apresentam transtornos de controle de impulso, como jogo patológico, comportamento sexual e alimentar anormal, compulsão para compras e hobbismo. Estes são fatores de interrupção do uso dos agonistas dopaminérgicos, junto com alucinações e alterações cognitivas</mark><sup>102–104,109</sup> <mark>.</mark>  
<mark>Em pacientes com mais de 70 anos, pacientes com múltiplas comorbidades e pacientes com déficit cognitivo a levodopa/carbidopa ou levodopa/benserazida são as opções de escolha.</mark>  
**Fase avançada da doença e tratamento das flutuações motoras**  
<mark>Muitas vezes, o uso de vários medicamentos antiparkinsonianos é necessário na fase avançada da doença para controle das suas complicações motoras e não motoras.</mark>  
<mark>Pacientes tratados com levodopa apresentam maior número de flutuações motoras e discinesias do que os tratados com agonistas dopaminérgicos</mark><sup>110,111</sup> <mark>. No entanto, essas diferenças entre agonistas e levodopa parecem desaparecer a longo prazo, pois estudos com mais de uma década de seguimento sugerem que os pacientes apresentam a mesma frequência de complicações motoras, independentemente do tratamento que receberam nos primeiros anos da doença</mark><sup>112,113</sup> <mark>. Assim, tem sido recomendado que indivíduos mais jovens iniciem o tratamento sintomático com os agonistas da dopamina, uma vez que apresentam um maior risco de complicações motoras com o uso de levodopa. Porém, se os sintomas motores não forem bem controlados com doses adequadas de agonistas dopaminérgicos, a levodopa deve ser logo adicionada ao tratamento</mark><sup>114–116</sup> <mark>.</mark>  
<mark>Para tratamento das flutuações motoras, em associação com levodopa, são mais eficazes: pramipexol (agonistas dopaminérgicos); rasagilina (inibidores da MAO-B) e entacapona (inibidor da COMT)</mark><sup>99–102</sup> <mark>.</mark>  
<mark>Ainda, para o tratamento de discinesias, a amantadina 300 mg, de uma a três vezes ao dia, é eficaz</mark><sup>99–103</sup> <mark>.</mark>  
<mark>A levodopa (combinada à carbidopa ou bensezarida) é o medicamento mais eficaz nas fases avançadas da doença.</mark>  
11

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.3      Tratamento cirúrgico** -->
Para um grupo selecionado de pacientes cujo tratamento medicamentoso não trouxe controle adequado dos sintomas motores, a cirurgia de implante de estimulador cerebral profundo (DBS) no núcleo subtalâmico (STN) ou no globo pálido interno (GPi) deve ser considerada. Este procedimento cirúrgico é considerado relativamente seguro e eficaz<sup>117,118</sup> . O implante do DBS tem como objetivos: redução da intensidade dos períodos OFF, aumento do tempo ON, redução das discinesias<sup>118</sup> . Quando a indicação é para tremor refratário, a estimulação do tálamo, no núcleo ventral intermédio (VIM), deve ser considerada<sup>119,120</sup> . O procedimento cirúrgico deve sempre ter em foco a melhora no desempenho das atividades de vida diária e na qualidade de vida do paciente.  
A correta seleção do paciente, o posicionamento preciso dos eletrodos na área-alvo ideal e a programação eficaz dos dispositivos de DBS após a cirurgia são determinantes para o sucesso do procedimento<sup>121</sup> .  
Embora a cirurgia com implante de DBS seja um tratamento eficaz para os sintomas motores da DP, ela não é curativa e não interrompe a progressão da doença. Sendo assim, somente deverá ser considerada em pacientes que não conseguem obter um controle adequado com terapia otimizada<sup>122,123</sup> .  
Ressalta-se que o uso indiscriminado de medicamentos, como entacapona, com o intuito de induzir discinesias e aumentar a chance de indicação cirúrgica não é indicado e nem recomendado.  
Para uma correta identificação dos pacientes com indicação do tratamento cirúrgico com implante de DBS, deve-se atentar ao cumprimento dos seus respectivos critérios de elegibilidade<sup>38</sup> .

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Sintomas psicóticos** -->
Sintomas psicóticos são caracterizados pela presença de alucinações ou delírios e sua frequência na DP aumenta à medida que a doença progride. Podem atingir graves proporções, sendo causa relevante de institucionalização e internação hospitalar, além de sinalizar alta taxa de mortalidade nos próximos anos de vida do paciente<sup>124,125</sup> .  
Alguns medicamentos, como anticolinérgicos, amantadina, inibidores da MAO, agonistas dopaminérgicos e inibidores da COMT devem ser interrompidos ou sua dose deve ser reduzida na tentativa de melhorar o estado mental. Esta decisão deve ser individualizada conforme o julgamento médico.  
Quando os sintomas forem persistentes ou graves, medicamentos antipsicóticos devem ser utilizados. Neurolépticos com maior afinidade por receptores D2, tais como os de primeira geração (haloperidol, clorpromazina, levopromazina etc) são contraindicados na DP, pois exacerbam o parkinsonismo de forma intensa. Mesmo os antipsicóticos de segunda geração, que apresentam menor bloqueio dopaminérgico de receptores D2, tais como risperidona, olanzapina, ziprasidona e aripiprazol, também exacerbam o parkinsonismo, oferecendo riscos ao paciente com DP.  
A exceção é a clozapina, que permite o controle de sintomas psicóticos sem piora do parkinsonismo. Estudos controlados com placebo demonstraram que a clozapina é eficaz no controle dos sintomas psicóticos associados à DP<sup>126</sup> . Os eventos adversos motores da clozapina são semelhantes aos do placebo. No entanto, este medicamento pode causar agranulocitose (incidência anual de 1,3%) e exige, portanto, controle hematológico regular. Conforme a recomendação de bula do medicamento<sup>127</sup> , os pacientes que estiveram em tratamento com clozapina por mais de 18 semanas e tenham interrompido o tratamento por mais de 3 dias, mas menos de 4 semanas, devem realizar a contagem dos glóbulos brancos e total de neutrófilos, semanalmente, por mais 6 semanas. Se não ocorrer anormalidade hematológica, pode ser retomado o monitoramento em intervalos não superiores a 4 semanas. Se o tratamento com clozapina tiver sido interrompido por 4 semanas ou mais, é necessário o controle hematológico semanal nas 18 semanas seguintes do tratamento medicamentoso.  
12  
Com relação à quetiapina, em estudos controlados com placebo, o medicamento não se mostrou superior ao placebo no controle de sintomas psicóticos em pacientes com DP<sup>128,129</sup> .  
Assim, com relação ao controle dos sintomas psicóticos presentes na DP, até o momento, a clozapina é o medicamento disponível, com evidência de eficácia, sendo o tratamento de escolha para psicose na DP.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Demência** -->
Na abordagem do paciente com DDP, antes de iniciar o tratamento medicamentoso específico, deve-se excluir doenças sistêmicas, depressão e possíveis eventos adversos de medicamentos, em especial daqueles com propriedades anticolinérgicas. Portanto, o uso desses medicamentos deve ser interrompido, assim como os antidepressivos tricíclicos e benzodiazepínicos<sup>26</sup> .  
Para o tratamento específico dos sintomas cognitivos na DDP, vários estudos foram realizados com o intuito de avaliar os efeitos dos inibidores da acetilcolinesterase – rivastigmina<sup>130,131</sup> , donepezila<sup>132</sup> e galantamina<sup>133</sup> – e da memantina, antagonista do receptor NMDA<sup>134</sup> . Contudo, os resultados destes estudos apontaram o benefício com o uso da rivastigmina, sendo a única aprovada para o tratamento dos pacientes com DP e demência leve a moderada<sup>26</sup> .

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Sintomas não motores** -->
Apesar de presentes em quase todos os pacientes, os sintomas não motores da DP podem não ser avaliados nas consultas  
de rotina. O Quadro 4 sumariza as principais condutas recomendadas, segundo sintoma não motor.  
**Quadro 4 -** Condutas para sintomas não motores de condições especiais na doença de Parkinson.  
|**Sintomas**<br>**não**<br>**motores**|**Condutas**|
|---|---|
|Alterações no sono|Uma boa higiene do sono deve ser aconselhada para as pessoas com DP com quaisquer alterações do<br>sono. Considerar as seguintes condutas:<br>Aconselhamento para evitar estimulantes (por exemplo, café, chá, cafeína) à noite, adoção de roupa de<br>cama e temperatura confortáveis, promover restrição de cochilos no final da tarde e início da noite,<br>orientar prática de exercícios físicos regulares e apropriados para induzir um melhor sono. Pessoas<br>com DP que apresentam sonolência diurna ou início súbito de sono devem ser aconselhadas a não<br>dirigir e considerar quaisquer riscos ocupacionais.<br>Os medicamentos devem ser ajustados para reduzir as ocorrências das alterações no sono citadas.<br>Considerar prescrição de baixas doses de antidepressivos sedativos para sintomas de insônia. Cuidados<br>devem ser tomados para identificar e gerenciar a síndrome das pernas inquietas e alteração do sono.|
|Constipação<br>intestinal|Recomenda-se o aumento da ingestão de líquidos e fibras.<br>O aumento da prática do exercício físico pode ser benéfico. Laxantes osmóticos (por exemplo,<br>lactulose) são recomendados.<br>Considerar diminuição de dose ou interrupção de uso de medicamento anticolinérgico.|
|Disfunção cognitiva|Para demência na DP, rivastigmina pode ser adicionada.<br>Não há evidências sobre alguma intervenção que reduza o risco da progressão dos sintomas cognitivos<br>leves na DP, mas modificações no estilo de vida, como o envolvimento em atividades cognitivas e<br>sociais e exercícios físicos são incentivados.|
|Disfunção erétil|Medicamentos associados à disfunção erétil (por exemplo, α-bloqueadores) ou anorgasmia (por<br>exemplo, inibidores da recaptação da serotonina) devem ser interrompidos.|  
13  
|**Sintomas**<br>**não**<br>**motores**|**Condutas**|
|---|---|
|Hipotensão<br>ortostática|Evitar fatores agravantes como grandes refeições, álcool, exposição a um ambiente quente e<br>medicamentos conhecidos por causar hipotensão ortostática, como diuréticos ou anti-hipertensivos.<br>Aumentar a ingestão de sal na hipotensão ortostática sintomática. Inclinar a cabeceira da cama à noite.<br>Usar meias elásticas de compressão. Atentar para hipotensão ortostática pós-prandiais.|
|Psicose|Para pacientes com psicose, deve-se reduzir a quantidade de medicamentos utilizada.<br>O uso de antidepressivos anticolinérgicos, ansiolíticos ou sedativos deve ser reduzido ou interrompido.<br>O uso de medicamentos antiparkinsonianos anticolinérgicos, como triexifenidil, agonistas<br>dopaminérgicos, como pramipexol, os inibidores de MAO-B, como rasagilina, e inibidores de COMT,<br>como entacapona, devem ser reduzidos ou interrompidos.<br>A clozapina é indicada, mas requer monitoramento. Todos os outros antipsicóticos devem ser evitados<br>na psicose na DP.|
|Síndrome das pernas<br>inquietas|Investigar deficiência de ferro.|
|Urgência urinária|Evitar ingestão de café e líquidos antes de dormir.<br>Noctúria: Evitar consumo de líquidos próximo ao horário de dormir.<br>Dormir com a cabeceira da cama inclinada para reduzir a produção de urina.<br>Para urgência urinária (bexiga hiperativa), medicamentos anticolinérgicos ou antiespasmódicos podem<br>ser úteis, mas deve-se ter cuidado com os efeitos adversos centrais.|  
Fonte: Modificado de Grimes et al. (2019)<sup>102</sup>  
Legenda: DP: doença de Parkinson.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Cuidados paliativos** -->
A DP é um distúrbio neurodegenerativo multissistêmico, lentamente progressivo, sem tratamento modificador da doença disponível. A doença está associada a sintomas motores e não motores que levam ao comprometimento da qualidade de vida, incapacidade e sofrimento significativo do cuidador. Assim, os pacientes com DP se beneficiam dos cuidados paliativos, que fornecem uma abordagem holística para atender às suas necessidades multifacetadas, incluindo controle de sintomas, necessidades de comunicação e suporte do cuidador.  
Nesse sentido, algumas recomendações devem ser observadas:  
- considerar a oferta de cuidados paliativos para as pessoas com DP em todas as fases da doença;  
- caso necessário, as pessoas com DP e seus familiares e cuidadores devem ter oportunidades para discutir o prognóstico  
- do paciente, a fim de promover a definição de prioridades, a tomada de decisão compartilhada e a escolha de cuidados centrados no paciente;  
- os profissionais de saúde devem fornecer instruções verbais e por escrito sobre: progressão da doença, possíveis  
eventos adversos de medicamentos, planejamento antecipado de cuidados, incluindo procuração para finanças, saúde e assistência social, o que pode acontecer ao final da vida e programa de atendimento domiciliar à pessoa idosa (PADI)<sup>102</sup> .

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.5     Medicamentos** -->
- Amantadina: comprimidos de 100 mg;  
- Biperideno: comprimidos de 2 mg e comprimidos de liberação controlada de 4 mg;  
14  
- Clozapina: comprimidos de 25 e 100 mg;  
- Entacapona: comprimidos de 200 mg;  
- Levodopa + benserazida: cápsulas de 100 mg + 25 mg, comprimidos de 100 mg + 25 mg e de 200 mg + 50 mg;  
- Levodopa + carbidopa: comprimidos de 200 mg + 50 mg e de 250 mg + 25 mg;  
- Pramipexol: comprimidos de 0,125 mg, 0,25 mg e 1 mg;  
- Rasagilina: comprimidos de 1 mg;  
- Rivastigmina: cápsulas de 1,5 mg, 3 mg, 4,5 mg e 6 mg; adesivo transdérmico de 9 mg (equivalente a 4,6 mg por 24  
horas), 18 mg (equivalente a 9,5 mg por 24 horas); solução oral de 2 mg/mL;  
- Triexifenidil: comprimidos de 5 mg.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.6      Esquemas de administração** -->
Os esquemas de administração segundo medicamentos estão representados no Quadro 5.  
**Quadro 5 -** Medicamentos disponíveis no SUS para tratamento da doença de Parkinson.  
|**Medicamento**|**Fase**<br>**Inicial**|**Fase**<br>**Avançada**|**Condições**<br>**especiais**|**Posologia**|
|---|---|---|---|---|
|Levodopa<br>+<br>benserazida|X|X|NA|A dose recomendada é de 200/50 mg por dia, dividida<br>em pelo menos duas administrações. As doses vão<br>sendo ajustadas subsequentemente de acordo com a<br>resposta clínica. A dose média eficaz para a maioria<br>dos pacientes é de 600-750 mg/dia de levodopa.<br>Dependendo da tolerância e resposta clínica a dose<br>pode ser aumentada até o máximo de 2.000 mg/dia.<br>A levodopa/benserazida é disponibilizada em<br>diferentes formulações. A forma de comprimido<br>padrão é de 100/25 e 200/50. Esta apresentação<br>apresenta início de ação em torno de 20-40 minutos e<br>duração de 2 a 4 horas; a forma em cápsula apresenta<br>um início de ação de 30-60 minutos e duração de 3 a<br>6 horas. A forma dispersível para diluição em água<br>possui início de ação mais rápido (10-20 minutos) e<br>menor<br>duração<br>(0,5-1<br>hora).<br>Apesar<br>destas<br>variabilidades farmacocinéticas, não há evidências<br>clínicas (estudos clínicos) que mostrem de forma<br>convincente superioridade entre as apresentações. A<br>apresentação dispersível é uma forma útil em<br>pacientes com disfagia ou sonda de alimentação<br>enteral.|
|Levodopa<br>+<br>carbidopa|X|X|NA|A dose inicial recomendada é de 250/25 mg por dia,<br>dividida em pelo menos duas administrações. A dose<br>máxima recomendada de levodopa é de 2.000 mg/dia.|  
15  
|**Medicamento**|**Fase**<br>**Inicial**|**Fase**<br>**Avançada**|**Condições**<br>**especiais**|**Posologia**|
|---|---|---|---|---|
|Pramipexol|X|X|NA|Inicial: 0,375 mg/dia, subdividida em três doses<br>diárias, e deve ser aumentada a cada 5 a 7 dias. Se<br>houver necessidade de aumento da dose, acrescentar<br>semanalmente 0,75 mg à dose diária até atingir a dose<br>máxima de 4,5 mg/dia (aumento sucessivo para 0,75<br>mg; 1,5 mg; 2,25 mg; 3,0 mg; e 4,5 mg/dia);<br>Manutenção: a dose individual deve situar-se no<br>intervalo entre 0,375 mg/dia e a dose máxima de 4,5<br>mg/dia.|
|Rasagilina|X|X|NA|1 mg ao dia.|
|Amantadina|X|X|NA|A dose comum é de 100 mg, de 12/12 horas, quando<br>usado isoladamente. Em indivíduos portadores de<br>outras doenças sérias associadas, ou em pacientes que<br>estejam recebendo outros medicamentos anti-<br>parkinsonianos, a dose inicial deve ser de 100 mg/dia<br>e pode ser aumentada para 200 mg/dia (100 mg de<br>12/12 horas), se necessário, após observação do<br>quadro. Alguns pacientes que não respondem à dose<br>de 200 mg/dia podem se beneficiar de um aumento<br>até 400 mg/dia em doses divididas (200 mg de 12/12<br>horas). A dose não deve ser suspensa abruptamente<br>(a retirada deve ser gradual, em 1-2 semanas).|
|Entacapona||X|NA|Administra-se um comprimido de 200 mg com cada<br>dose de levodopa/inibidor da dopa descarboxilase. A<br>dose máxima recomendada é de 200 mg 10 vezes por<br>dia, isto é, 2 g de entacapona.|
|||||A dose inicial recomendada é de 0,5 mg a 1 mg, 2<br>vezes/dia, com incrementos a cada 3-5 dias até atingir<br>2 mg, três vezes/dia. A dose máxima diária é de 15|
|Triexifenidil|X|X|NA|mg/dia, mas a maioria dos pacientes se beneficia com<br>esquemas de até 10 mg/dia. Não deve ser<br>interrompido abruptamente devido ao risco de efeito<br>rebote e piora do parkinsonismo.|
|Biperideno|X|X|NA|A dose terapêutica situa-se entre 2 mg/dia e 8 mg/dia,<br>iniciando com 1 mg, duas vezes/dia. Não deve ser<br>interrompido abruptamente devido ao risco de efeito<br>rebote e piora do parkinsonismo.|  
16  
|**Medicamento**|**Fase**<br>**Inicial**|**Fase**<br>**Avançada**|**Condições**<br>**especiais**|**Posologia**|
|---|---|---|---|---|
|Clozapina|||X|A dose inicial é de 12,5 mg/dia e pode ser aumentada<br>em 12,5 mg por vez, devendo ocorrer no máximo dois<br>aumentos em uma semana, sem ultrapassar a dose de<br>50 mg/dia. A dose média efetiva fica geralmente<br>entre 25,0 e 37,5 mg/dia. No caso em que o<br>tratamento, por pelo menos uma semana, com a dose<br>de 50 mg/dia não obteve resposta terapêutica<br>satisfatória,<br>a dose pode ser cuidadosamente aumentada em 12,5<br>mg/semana. A dose de 50 mg/dia só deve ser<br>ultrapassada em casos excepcionais. A dose máxima<br>de 100 mg/dia nunca deverá ser ultrapassada|
|Rivastigmina|||X|Inicial: 1,5 mg duas vezes ao dia (cápsula ou solução)<br>e 9 mg uma vez ao dia (adesivo)<br>Máxima: 6 mg duas vezes ao dia (cápsula ou solução)<br>e 18 mg uma vez ao dia (adesivo)|  
NA: não se aplica  
No uso de adesivos transdérmicos, inicia-se com a apresentação de 9 mg.  Após no mínimo 4 semanas de tratamento, havendo boa tolerância, deve-se passar para o adesivo de 18 mg, que é a dose considerada efetiva. Aplica-se um adesivo a cada 24 horas em um dos lados da parte superior do braço, do peito ou da parte superior ou inferior das costas. Caso o paciente não tolere o uso do adesivo de 9 mg, outra alternativa terapêutica deve ser buscada pelo médico assistente.  
Pacientes tratados com rivastigmina por via oral podem ser transferidos para o tratamento com adesivos transdérmicos da  
seguinte forma:  
- Pacientes que estão recebendo uma dose menor que 6 mg/dia de rivastigmina oral podem migrar para o adesivo de 9  
mg e, após 4 semanas de uso, passar para o de 18 mg, em caso de boa tolerância;  
- Pacientes que estão recebendo uma dose de 6-12mg/dia de rivastigmina por via oral podem migrar diretamente para o  
- adesivo de 18mg. A aplicação do primeiro adesivo deve ser feita um dia após a última dose oral.  
O Quadro 6 descreve o tratamento medicamentoso para doença de Parkinson conforme a fase da doença.  
**Quadro 6 -** Tratamento medicamentoso para doença de Parkinson conforme a fase da doença.  
|**Pacientes com sintomas leves com ou**<br>**sem prejuízo funcional**|**Paciente em fase avançada e**<br>**tratamento das flutuações motoras**|**Tratamento (independente da fase**<br>**da doença)**|
|---|---|---|
|Levodopa/carbidopa|Levodopa/carbidopa|**Demência**:|
|Levodopa/benserazida|Levodopa/benserazida|Rivastigmina|
|**Para indivíduos mais jovens, com**|**Para tratamento de flutuações**|**Prevenção de flutuações motoras e**|
|**risco de complicações motoras com**|**motoras:**|**discinesias:**|
|**levodopa:**|Associar levodopae:|- Pramipexol|
|||17|  
|**Pacientes com sintomas leves com ou**|**Paciente em fase avançada e**|**Tratamento (independente da fase**|
|---|---|---|
|**sem prejuízo funcional**|**tratamento das flutuações motoras**|**da doença)**|
||Pramipexol||
|Pramipexol|Rasagilina|Se paciente possui mais de 70 anos ou|
|Rasagilina|Entacapona|comorbidades ou déficit cognitivo:|
||Triexifenidil|Levodopa/carbidopa|
|**Alternativas**||Levodopa/benserazida|
||**Para tratamento de discinesias:**|**Psicose na DP:**|
|Triexifenidil|Amantadina|Clozapina|
|Biperideno|||
|Amantadina|||

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.7      Tratamento em populações específicas** -->
<mark>A levodopa (combinada à carbidopa ou benserazida) é o medicamento recomendado para uso durante a gravidez. O uso de amantadina é contraindicado na gravidez e em mulheres que pretendam engravidar, por se tratar de medicamento teratogênico.</mark>  
<mark>Dados referentes aos agonistas dopaminérgicos, inibidores da MAO-B, inibidores da COMT e triexifenidil são insuficientes, de modo que estes medicamentos não devem ser utilizados na gravidez. Como os dados sobre o uso desses medicamentos durante a amamentação são insuficientes, eles devem ser evitados</mark><sup>135–137</sup> <mark>.</mark>

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **6.8      Critérios de interrupção de medicamentos** -->
O tratamento medicamentoso pode ser interrompido, a critério médico, considerando a efetividade ou segurança subótima. Recomenda-se a redução da dose ou interrupção de medicamentos antiparkinsonianos, dos agonistas dopaminérgicos, dos inibidores de MAO-B e COMT, em caso de psicose. Os medicamentos também devem ser interrompidos nas seguintes situações:  
- **clozapina:** em caso de síndrome neuroléptica maligna, contagem dos glóbulos brancos inferior a 3.000/mm<sup>3</sup> ou se a contagem total de neutrófilos for inferior a 1.500/mm<sup>3</sup> durante as 18 primeiras semanas de tratamento ou se a contagem de glóbulos brancos for inferior a 2.500/mm<sup>3</sup> ou a contagem total de neutrófilos for inferior a 1.000/mm<sup>3</sup> após as primeiras 18 semanas de tratamento; e  
- **rasagilina** : em caso de progressão da insuficiência hepática (deve-se ter cautela ao iniciar o tratamento em pacientes com insuficiência hepática leve, evitado em  pacientes com insuficiência hepática moderada, e contraindicado em casos de insuficiência hepática grave).  
A selegilina, um inibidor da MAO-B, teve a sua produção descontinuada no Brasil. Recomenda-se que pacientes em uso de selegilina e com resposta adequada passem a utilizar rasagilina, sem necessidade de redução gradual de dose. No caso de interrupção de selegilina 10 mg ao dia sem a substituição por rasagilina, recomenda-se reduzir a dose para 5 mg ao dia e, após uma semana, suspender o tratamento. Caso o paciente esteja em uso de selegilina 5 mg ao dia no momento da interrupção e não haja substituição por rasagilina, não há necessidade de redução gradual da dose.  
A **rivastigmina** deve ser interrompida temporariamente se reações adversas gastrintestinais e/ou piora dos sintomas extrapiramidais existentes (por ex.: tremor) forem observadas.  
18

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **7.        MONITORAMENTO** -->
A monitorização dos eventos adversos deve ser feita por meio de anamnese. Caso o paciente apresente eventos adversos significativos que comprometam a sua qualidade de vida, deve ser feito ajuste de dose, interrupção de tratamento ou troca de medicamento. Os eventos adversos mais comuns para cada medicamento são:  
- **Amantadina** : alucinações visuais, confusão mental, insônia, alterações do sono como pesadelos, livedo reticular e edema dos membros inferiores. Deve- se ter cuidado na administração da amantadina em pacientes que apresentem função renal alterada, pois 90% da sua excreção ocorre pela urina.  
- **Levodopa:** em curto prazo, são náusea, vômitos, anorexia, sonolência, hipotensão postural, insônia e agitação. Em longo prazo, ocorrem flutuações motoras e discinesias.  
- **Levodopa + benserazida:** movimentos involuntários, episódios psicóticos, angina pectoris, constipação, perda de peso e falta de ar.  
- **Levodopa + carbidopa:** náusea, discinesias, incluindo os movimentos coreiformes, distônicos e outros movimentos involuntários.  
- **Pramipexol** : náusea, vômitos, anorexia, hipotensão postural, edema, tontura, alucinações, delírios, sonolência excessiva diurna e transtornos do impulso (jogo patológico, hipersexualidade e outras formas de compulsão). Na presença de alucinações, sonolência excessiva diurna e transtornos do impulso, está recomendada em casos graves a redução das doses ou até a interrupção de uso do medicamento.  
- **Biperideno e triexifenidil** : secura da boca, turvação visual e retenção urinária. Os eventos adversos centrais são alteração de memória, confusão mental e alucinações. Portanto, o uso em pacientes idosos deve ser evitado.  
- **Rasagilina** : dor de cabeça, síndrome semelhante a quadro gripal, mal-estar, dor cervical, dispepsia, boca seca, artralgias e conjuntivite. Pode haver exacerbação das discinesias; dor abdominal, hipotensão postural, constipação intestinal, erupção cutânea, vômitos, alteração do sono e perda de peso.  
- **Clozapina** : taquicardia, hipotensão postural, constipação intestinal, hipertermia, cefaleia, tonturas, astenia, sonolência, sialorreia, boca seca, sudorese, náusea, vômitos, visão turva e aumento de peso. É contraindicada nos casos de leucopenia (contagem de leucócitos inferior a 3.500 células/mm<sup>3</sup> ). São necessários controles periódicos de hemograma (semanal nas primeiras 18 semanas e mensal, após). Também podem ocorrer alteração no eletrocardiograma, hipertensão, dor no peito, agitação, inquietação, desconforto abdominal, azia, ressecamento de mucosas, tremores, desmaios, confusão e delírio. Os eventos adversos raros incluem convulsões, discinesia tardia, acatisia, síndrome neuroléptica maligna, hepatite, icterícia colestática, pancreatite aguda, impotência sexual, alteração das células do sangue (agranulocitose, eosinofilia, granulocitopenia, leucopenia, trombocitopenia) e rigidez muscular.  
- **Entacapona** : discinesia, alucinações, confusão, náusea e hipotensão ortostática. Esses eventos podem ser reduzidos com a diminuição da dose de levodopa; diarreia ocorre em cerca de 5% dos casos e é frequentemente não responsiva a antidiarreicos; elevação das enzimas hepáticas ocorre raramente, mas pela potencial gravidade recomenda-se a monitorização da função hepática a cada 2 semanas durante os primeiros 6 meses de uso; coloração alaranjada da urina pode ocorrer.  
- **Rivastigmina** : os eventos adversos relatados mais comumente são gastrointestinais, incluindo náusea (38%) e vômitos (23%). Outros eventos muito comuns ou comuns incluem: distúrbios psiquiátricos (agitação, confusão, pesadelos, ansiedade), distúrbios do sistema nervoso (tontura, dor de cabeça, sonolência e tremor), outros distúrbios gastrointestinais (diarreia e perda do apetite, dor abdominal e dispepsia).  
19  
Ainda, a associação de rasagilina com fluoxetina e fluvoxamina é contraindicada. A associação com os demais inibidores  
de receptação da serotonina, embora dita como segura, requer que o paciente seja monitorado clinicamente.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **8.        REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão das pessoas com DP neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses de medicamento (s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Pacientes com DP devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do (s) medicamento (s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (Bnafar), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **9.        TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **10.     REFERÊNCIAS** -->
1. Bloem BR, Okun MS, Klein C. Parkinson’s disease. Lancet. junho de 2021;397(10291):2284–303.  
2. Hirsch L, Jette N, Frolkis A, Steeves T, Pringsheim T. The Incidence of Parkinson’s Disease: A Systematic Review and Meta-Analysis. Neuroepidemiology. 2016;46(4):292–300.  
3. Barbosa MT, Caramelli P, Maia DP, Cunningham MCQ, Guerra HL, Lima-Costa MF, et al. Parkinsonism and Parkinson’s disease in the elderly: a community-based survey in  Brazil (the Bambuí study). Mov Disord. junho de 2006;21(6):800–8.  
4. Vale TC, Barbosa MT, Resende E de PF, Maia DP, Cunningham MCQ, Guimarães HC, et al. Parkinsonism in a population-based study of individuals aged 75+ years: The Pietà  study. Parkinsonism Relat Disord. novembro de 2018;56:76–81.  
5. Hou Y, Dan X, Babbar M, Wei Y, Hasselbalch SG, Croteau DL, et al. Ageing as a risk factor for neurodegenerative disease. Nat Rev Neurol. outubro de 2019;15(10):565–81.  
6. Elbaz A, Clavel J, Rathouz PJ, Moisan F, Galanaud JP, Delemotte B, et al. Professional exposure to pesticides and Parkinson disease. Ann Neurol. outubro de 2009;66(4):494–504.  
7. Collaborators GBD 2016 PD. Global, regional, and national burden of Parkinson’s disease, 1990-2016: a systematic analysis for the Global Burden of Disease Study 2016. Lancet Neurol. 2018/10/01. novembro de 2018;17(11):939–53.  
8. Delamarre A, Meissner WG. Epidemiology, environmental risk factors and genetics of Parkinson’s disease. Presse Med. março de 2017;46(2 Pt 1):175–81.  
20  
9. Armstrong MJ, Okun MS. Diagnosis and Treatment of Parkinson Disease: A Review. JAMA. 11 de fevereiro de 2020;323(6):548–60.  
10. Emre M. Dementia associated with Parkinson’s disease. Lancet Neurol. abril de 2003;2(4):229–37.  
11. Herlofson K, Lie SA, Arsland D, Larsen JP. Mortality and Parkinson disease: A community based study. Neurology. março de 2004;62(6):937–42.  
12. Hughes TA, Ross HF, Mindham RHS, Spokes EGS. Mortality in Parkinson’s disease and its association with dementia and depression. Acta Neurol Scand. agosto de 2004;110(2):118–23.  
13. de Lau LML, Schipper CMA, Hofman A, Koudstaal PJ, Breteler MMB. Prognosis of Parkinson disease: risk of dementia and mortality: the Rotterdam Study. Arch Neurol. agosto de 2005;62(8):1265–9.  
14. Katzenschlager R, Head J, Schrag A, Ben-Shlomo Y, Evans A, Lees AJ. Fourteen-year final report of the randomized PDRG-UK trial comparing three initial treatments in PD. Neurology. agosto de 2008;71(7):474–80.  
15. Chomistek AK, Cook NR, Flint AJ, Rimm EB. Vigorous-intensity leisure-time physical activity and risk of major chronic disease in men. Med Sci Sports Exerc.outubro de 2012;44(10):1898–905.  
16. Lang AE. When and how should treatment be started in Parkinson disease? Neurology. fevereiro de 2009;72(7 Suppl):S39-43.  
17. Olanow CW, Stern MB, Sethi K. The scientific and clinical basis for the treatment of Parkinson disease (2009). Neurology. maio de 2009;72(21 Suppl 4):S1-136.  
18. Rascol O, Goetz C, Koller W, Poewe W, Sampaio C. Treatment interventions for Parkinson’s disease: an evidence based assessment. Lancet. maio de 2002;359(9317):1589–98.  
19. Belo Tavares Ferreira C. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Revista Brasileira de Cancerologia. 30 de junho de 2016;62(2):165–6.  
20. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. abril de 2008;336(7650):924– 6.  
21. Postuma RB, Berg D, Stern M, Poewe W, Olanow CW, Oertel W, et al. MDS clinical diagnostic criteria for Parkinson’s disease. Mov Disord. outubro de 2015;30(12):1591–601.  
22. Heinzel S, Berg D, Gasser T, Chen H, Yao C, Postuma R. Prodromal PD Calculator. 2019 [citado 14 de janeiro de 2023]; Disponível em: https://www.movementdisorders.org/MDS/Members-Only/Prodromal-PDCalculator.htm  
23. Heinzel S, Berg D, Gasser T, Chen H, Yao C, Postuma RB; MDS Task Force on the Definition of Parkinson’s Disease. Update of the MDS research criteria for prodromal Parkinson’s disease. Mov Disord. 2019 Oct;34(10):1464-1470.  
24. Rascovsky K, Hodges JR, Knopman D, et al. Sensitivity of revised diagnostic criteria for the behavioural variant of frontotemporal dementia. Brain. 2011 Sep;134(Pt 9):2456-77. .  
25. Aarsland D, Zaccai J, Brayne C. A systematic review of prevalence studies of dementia in Parkinson’s disease. Mov Disord. outubro de 2005;20(10):1255–63.  
26. Hanagasi HA, Tufekcioglu Z, Emre M. Dementia in Parkinson’s disease. J Neurol Sci. março de 2017;374:26– 31.  
27. Emre M, Aarsland D, Brown R, Burn DJ, Duyckaerts C, Mizuno Y, et al. Clinical diagnostic criteria for dementia associated with Parkinson’s disease. Mov Disord. setembro de 2007;22(12):1689–707; quiz 1837.  
21  
28. Barbosa EReis, Ferraz HB, Tumas V. Doença de Parkinson: Recomendações. 2 ed. Omnifarma, organizador. São Paulo; 2014. 89–106 p.  
29. Rezai AR, Kopell BH, Gross RE, Vitek JL, Sharan AD, Limousin P, et al. Deep brain stimulation for Parkinson’s disease: surgical issues. Mov Disord. junho de 2006;21 Suppl 1:S197-218.  
30. Klostermann F, Ehlen F, Vesper J, Nubel K, Gross M, Marzinzik F, et al. Effects of subthalamic deep brain stimulation on dysarthrophonia in Parkinson’s  disease. J Neurol Neurosurg Psychiatry. maio de 2008;79(5):522–9.  
31. Volkmann J, Albanese A, Kulisevsky J, Tornqvist AL, Houeto JL, Pidoux B, et al. Long-term effects of pallidal or subthalamic deep brain stimulation on quality of  life in Parkinson’s disease. Mov Disord. junho de 2009;24(8):1154–61.  
32. Lang AE, Houeto JL, Krack P, Kubu C, Lyons KE, Moro E, et al. Deep brain stimulation: preoperative issues. Mov Disord. junho de 2006;21 Suppl 1:S171-96.  
33. Moro E, Lang AE. Criteria for deep-brain stimulation in Parkinson’s disease: review and analysis. Expert Rev Neurother. novembro de 2006;6(11):1695–705.  
34. Krack P, Batir A, Van Blercom N, Chabardes S, Fraix V, Ardouin C, et al. Five-year follow-up of bilateral stimulation of the subthalamic nucleus in advanced  Parkinson’s disease. N Engl J Med. novembro de 2003;349(20):1925–34.  
35. Voon V, Kubu C, Krack P, Houeto JL, Tröster AI. Deep brain stimulation: neuropsychological and neuropsychiatric issues. Mov Disord. junho de 2006;21 Suppl 1:S305-27.  
36. Hariz MI, Johansson F, Shamsgovara P, Johansson E, Hariz GM, Fagerlund M. Bilateral subthalamic nucleus stimulation in a parkinsonian patient with  preoperative deficits in speech and cognition: persistent improvement in mobility but increased dependency: a case study. Mov Disord. janeiro de 2000;15(1):136–9.  
37. Saint-Cyr JA, Albanese A. STN DBS in PD: selection criteria for surgery should include cognitive and  psychiatric factors. Vol. 66, Neurology. United States, United States; 2006. p. 1799–800.  
38. Saba RA, Maia DP, Cardoso FEC, Borges V, F Andrade LA, Ferraz HB, et al. Guidelines for Parkinson’s disease treatment: consensus from the Movement  Disorders Scientific Department of the Brazilian Academy of Neurology - motor symptoms. Arq Neuropsiquiatr. março de 2022;80(3):316–29.  
39. Morrish PK, Rakshi JS, Bailey DL, Sawle G V, Brooks DJ. Measuring the rate of progression and estimating the preclinical period of  Parkinson’s disease with [18F]dopa PET. J Neurol Neurosurg Psychiatry. março de 1998;64(3):314–9.  
40. Organização Mundial da Saúde (OMS). CIF: Classificação Internacional de Funcionalidade, Incapacidade e Saúde [Internet]. São Paulo: Editora da Universidade de São Paulo; 2008 [citado 13 de janeiro de 2023]. Disponível em: https://apps.who.int/iris/bitstream/handle/10665/42407/9788531407840_por.pdf?sequence=111  
41. Cordeiro E. Implantando a CIF. O que Acontece na Prática? 2017.  
42. Capato T, Domingos J, de Almeida L. Versão em portugués da Diretriz Européia de Fisioterapia para a doença de Parkinson [Internet]. São Paulo: Editora e Eventos Omnifarma; 2015 [citado 13 de janeiro de 2023]. Disponível em:  
https://www.parkinsonnet.nl/app/uploads/sites/3/2019/11/diretriz_dp_brasil_versao_final_publicada.pdf  
43. Keus S, Munneke M, Graziano M, Paltamaa J, Pelosin E, Domingos J, et al. European Physiotherapy Guideline for Parkinson’s disease: Information for clinicians. KNGF/ParkinsonNet. 2014;1.  
22  
44. Brasil / Ministério da Saúde. Portaria MS/GM no 793, de 24 de abril de 2012. Institui a Rede de cuidados à pessoa com deficiência no âmbito do Sistema Único de Saúde. https://bvsms.saude.gov.br/bvs/saudelegis/gm/2012/prt0793_24_04_2012.html; 2012.  
45. Brasil / Ministério da Saúde. HumanizaSUS - Caderno de textos cartilhas da política nacional de humanização. 2011 [citado 13 de janeiro de 2023]; Disponível em: https://bvsms.saude.gov.br/bvs/publicacoes/caderno_textos_cartilhas_politica_humanizacao.pdf  
46. Scalzo PL, Nova IC, Perracini MR, Sacramento DRC, Cardoso F, Ferraz HB, et al. Validation of the Brazilian version of the berg balance scale for patients with Parkinson’s disease. Arq Neuropsiquiatr. 2009;67(3 B).  
47. Steffen T, Seney M. Test-retest reliability and minimal detectable change on balance and ambulation tests, the 36-Item Short-Form Health Survey, and the Unified Parkinson Disease Rating Scale in people with parkinsonism. Phys Ther. 2008;88(6).  
48. Leddy AL, Crowner BE, Earhart GM. Utility of the mini-BESTest, BESTest, and BESTest sections for balance assessments in individuals with Parkinson disease. Journal of Neurologic Physical Therapy. 2011;35(2).  
49. Leddy AL, Crowner BE, Earhart GM. Functional gait assessment and balance evaluation system test: Reliability, validity, sensitivity, and specificity for identifying individuals with parkinson disease who fall. Phys Ther. 2011;91(1).  
50. Landers MR, Backlund A, Davenport J, Fortune J, Schuerman S, Altenburger P. Postural instability in idiopathic parkinson’s disease: Discriminating fallers from nonfallers based on standardized clinical measures. Journal of Neurologic Physical Therapy. 2008;32(2).  
51. Mak MKY, Pang MYC. Fear of falling is independently associated with recurrent falls in patients with Parkinson’s disease: A 1-year prospective study. J Neurol. 2009;256(10).  
52. Peretz C, Herman T, Hausdorff JM, Giladi N. Assesing fear of failing: Can a short version of the activitiesspecific balance confidence scale be useful? Movement Disorders. 2006;21(12).  
53. Barbieri FA, Rinaldi NM, Santos PCR, Lirani-Silva E, Vitório R, Teixeira-Arroyo C, et al. Functional capacity of Brazilian patients with Parkinson’s disease (PD): Relationship between clinical characteristics and disease severity. Arch Gerontol Geriatr. março de 2012;54(2):e83–8.  
54. Dibble LE, Christensen J, Ballard DJ, Foreman KB. Diagnosis of Fall Risk in Parkinson Disease: An Analysis of Individual and Collective Clinical Balance Test Interpretation. Phys Ther. 1<sup>o</sup> de março de 2008;88(3):323– 32.  
55. Duncan RP, Earhart GM. Randomized Controlled Trial of Community-Based Dancing to Modify Disease Progression in Parkinson Disease. Neurorehabil Neural Repair. 29 de fevereiro de 2012;26(2):132–43.  
56. Duncan RP, Leddy AL, Cavanaugh JT, Dibble LE, Ellis TD, Ford MP, et al. Accuracy of Fall Prediction in Parkinson Disease: Six-Month and 12-Month Prospective Analyses. Parkinsons Dis. 2012;2012:1–7.  
57. Kerr GK, Worringham CJ, Cole MH, Lacherez PF, Wood JM, Silburn PA. Predictors of future falls in Parkinson disease. Neurology. 2010;75(2).  
58. Tan D, Danoudis M, McGinley J, Morris ME. Relationships between motor aspects of gait impairments and activity limitations in people with Parkinson’s disease: A systematic review. Vol. 18, Parkinsonism and Related Disorders. 2012.  
59. Dibble LE, Lange M. Predicting Falls In Individuals with Parkinson Disease. Journal of Neurologic Physical Therapy. junho de 2006;30(2):60–7.  
23  
60. Behrman AL, Light KE, Flynn SM, Thigpen MT. Is the functional reach test useful for identifying falls risk among individuals with Parkinson’s disease? Arch Phys Med Rehabil. abril de 2002;83(4):538–42.  
61. Dibble LE, Hale TF, Marcus RL, Droge J, Gerber JP, LaStayo PC. High-intensity resistance training amplifies muscle hypertrophy and functional gains in persons with Parkinson’s disease. Movement Disorders. setembro de 2006;21(9):1444–52.  
62. Huang SL, Hsieh CL, Wu RM, Tai CH, Lin CH, Lu WS. Minimal detectable change of the timed “up & go” test and the dynamic gait index in people with parkinson disease. Phys Ther. 2011;91(1).  
63. King LA, Mancini M, Priest K, Salarian A, Rodrigues-De-Paula F, Horak F. Do clinical scales of balance reflect turning abnormalities in people With Parkinson’s disease? Journal of Neurologic Physical Therapy. 2012;36(1).  
64. Mak MKY, Auyeung MM. The mini-bestest can predict parkinsonian recurrent fallers: A 6-month prospective study. Vol. 45, Journal of Rehabilitation Medicine. 2013.  
65. Maia AC, Rodrigues-de-Paula F, Magalhães LC, Teixeira RLL. Cross-cultural adaptation and analysis of the psychometric properties of the balance evaluation systems test and MiniBESTest in the elderly and individuals with Parkinson’s disease: Application of the Rasch model. Braz J Phys Ther. 2013;17(3).  
66. Paul SS, Canning CG, Sherrington C, Lord SR, Close JCT, Fung VSC. Three simple clinical tests to accurately predict falls in people with Parkinson’s disease. Movement Disorders. 2013;28(5).  
67. Almeida LRS, Piemonte MEP, Cavalcanti HM, Canning CG, Paul SS. A Self‐Reported Clinical Tool Predicts Falls in People with Parkinson’s Disease. Mov Disord Clin Pract. 11 de abril de 2021;8(3):427–34.  
68. Myra RS, Koerich MHA da L, Gregório EC, Swarowsky A. Primary care for people with Parkinson’s disease in Brazil: A referral flowchart based on risk of falls. Front Public Health. 2022;10.  
69. Horak FB, Wrisley DM, Frank J. The balance evaluation systems test (BESTest) to differentiate balance deficits. Phys Ther. 2009;89(5).  
70. Mak MKY, Pang MYC. Balance confidence and functional mobility are independently associated with falls in people with Parkinson’s disease. J Neurol. 2009;256(5).  
71. ATS Statement. Am J Respir Crit Care Med. 1<sup>o</sup> de julho de 2002;166(1):111–7.  
72. Falvo MJ, Earhart GM. Six-Minute Walk Distance in Persons With Parkinson Disease: A Hierarchical Regression Model. Arch Phys Med Rehabil. junho de 2009;90(6):1004–8.  
73. Schenkman M, Ellis T, Christiansen C, Barón AE, Tickle-Degnen L, Hall DA, et al. Profile of functional limitations and task performance among people with early- and middle-stage Parkinson disease. Phys Ther. 2011;91(9).  
74. Baggio JAO, Curtarelli MB, Rodrigues GR, Tumas V. Validity of the Brazilian version of the freezing of gait questionnaire. Arq Neuropsiquiatr. agosto de 2012;70(8):599–603.  
75. Shine JM, Moore ST, Bolitho SJ, Morris TR, Dilda V, Naismith SL, et al. Assessing the utility of Freezing of Gait Questionnaires in Parkinson’s Disease. Parkinsonism Relat Disord. 2012;18(1).  
76. Giladi N, Shabtai H, Simon ES, Biran S, Tal J, Korczyn AD. Construction of freezing of gait questionnaire for patients with Parkinsonism. Parkinsonism Relat Disord. 2000;6(3).  
77. Brusse KJ, Zimdars S, Zalewski KR, Steffen TM. Testing Functional Performance in People With Parkinson Disease. Phys Ther. 1<sup>o</sup> de fevereiro de 2005;85(2):134–41.  
78. Santos MP, Ovando AC, Silva BA, Fontana SR, do Espírito Santo CC, Ilha J, et al. Parkinson Activity Scale: Cross-cultural adaptation and reliability of the Brazilian version. Geriatr Gerontol Int. 2015;15(1).  
24  
79. Keus SHJ, Nieuwboer A, Bloem BR, Borm GF, Munneke M. Clinimetric analyses of the Modified Parkinson Activity Scale. Parkinsonism Relat Disord. 2009;15(4).  
80. Duncan RP, Leddy AL, Earhart GM. Five Times Sit-to-Stand Test Performance in Parkinson’s Disease. Arch Phys Med Rehabil. setembro de 2011;92(9):1431–6.  
81. Haaxma CA, Bloem BR, Overeem S, Borm GF, Horstink MWIM. Timed motor tests can detect subtle motor dysfunction in early Parkinson’s disease. Movement Disorders. 2010;25(9).  
82. de Freitas PR, Lemos AE, Santos MP, Michaelsen SM, Corrêa CL, Swarowsky A. “Test D’évaluation Des Membres Supérieurs Des Personnes Âgées” (TEMPA) to assess upper limb activity in Parkinson’s disease. Journal of Hand Therapy. julho de 2017;30(3):320–7.  
83. Proud EL, Morris ME. Skilled Hand Dexterity in Parkinson’s Disease: Effects of Adding a Concurrent Task. Arch Phys Med Rehabil. 2010;91(5).  
84. Annett M. Five Tests of Hand Skill. Cortex. dezembro de 1992;28(4):583–600.  
85. Soke F, Colakoglu BD, Keskinoglu P, Genc A. Reliability, validity and responsiveness of the squares test for manual dexterity in people with Parkinson’s disease. Clin Neurol Neurosurg. 2019;186.  
86. Merello M, Gerschcovich ER, Ballesteros D, Cerquetti D. Correlation between the Movement Disorders Society Unified Parkinson’s Disease rating scale (MDS-UPDRS) and the Unified Parkinson’s Disease rating scale (UPDRS) during l-dopa acute challenge. Parkinsonism Relat Disord. 2011;17(9).  
87. Gallagher DA, Goetz CG, Stebbins G, Lees AJ, Schrag A. Validation of the MDS-UPDRS Part I for nonmotor symptoms in Parkinson’s disease. Movement Disorders. 2012;27(1).  
88. Goetz CG, Tilley BC, Shaftman SR, Stebbins GT, Fahn S, Martinez-Martin P, et al. Movement Disorder SocietySponsored Revision of the Unified Parkinson’s Disease Rating Scale (MDS-UPDRS): Scale presentation and clinimetric testing results. Movement Disorders. 2008;23(15).  
89. Souza RG, Borges V, Silva SMCDA, Ferraz HB. Quality of life scale in Parkinson’s disease: PDQ-39 - (Brazilian Portuguese version) to assess patients with and without levodopa motor fluctuation. Arq Neuropsiquiatr. 2007;65(3 B).  
90. Hagell P, Nygren C. The 39 item Parkinson’s disease questionnaire (PDQ-39) revisited: Implications for evidence based medicine. J Neurol Neurosurg Psychiatry. 2007;78(11).  
91. Sturkenboom IHWM, Thijssen MCE, Gons-van Elsacker JJ, Jansen IJH, Maasdam A, Schulten M, et al. Guidelines for Occupational Therapy in Parkinson’s Disease Rehabilitation. National Parkinson Foundation. 2011;Nijmegen/.  
92. J.G. K, B.J.M. DS, B.R. B. Guidelines for speech-language therapy in Parkinson’s disease. Vol. 25, Movement Disorders. 2010.  
93. Lennaerts H, Groot M, Rood B, Gilissen K, Tulp H, van Wensen E, et al. A Guideline for Parkinson’s Disease Nurse Specialists, with Recommendations for Clinical Practice. J Parkinsons Dis. 2017;7(4).  
94. The British Psychological Society. Psychological interventions  for people with  Huntington’s disease, Parkinson’s disease, motor neurone disease, and multiple sclerosis - Evidence-based guidance. 2020 [citado 13 de janeiro de 2023]; Disponível em: https://www.parkinsons.org.uk/sites/default/files/202102/The%20British%20Pyschological%20Society%20evided%20based%20guidance%20-  
- %20Psychological%20interventions%20for%20people%20with%20Huntingtons%2C%20Parkinsons%2C%20 motor%20neurone%20disease%2C%20multiple%20sclerosis.pdf  
25  
95. Green K. Best practice guideline for dietitians on the management of Parkinson’s. British Dietetic Association. 2021.  
96. Jankovic J, Poewe W. Therapies in Parkinson’s disease. Curr Opin Neurol. agosto de 2012;25(4):433–47.  
97. Schapira AH V, Obeso J. Timing of treatment initiation in Parkinson’s disease: a need for reappraisal? Ann Neurol. março de 2006;59(3):559–62.  
98. Löhle M, Ramberg CJ, Reichmann H, Schapira AH V. Early versus delayed initiation of pharmacotherapy in Parkinson’s disease. Drugs. abril de 2014;74(6):645–57.  
99. Fox SH, Katzenschlager R, Lim SY, Ravina B, Seppi K, Coelho M, et al. The Movement Disorder Society Evidence-Based Medicine Review Update: Treatments for the motor symptoms of Parkinson’s disease. Movement Disorders. outubro de 2011;26(S3):S2–41.  
100. Fox SH, Katzenschlager R, Lim SY, Barton B, de Bie RMA, Seppi K, et al. International Parkinson and movement disorder society evidence-based medicine review: Update on treatments for the motor symptoms of Parkinson’s disease. Vol. 33, Movement Disorders. 2018.  
101. Saba RA, Maia DP, Cardoso FEC, Borges V, Andrade LAF, Ferraz HB, et al. guidelines for Parkinson’s disease treatment: consensus from the movement disorders Scientific department of the Brazilian academy of neurology  
- motor symptoms. Arq Neuropsiquiatr. 2022;80(3).  
102. Grimes D, Fitzpatrick M, Gordon J, Miyasaki J, Fon EA, Schlossmacher M, et al. Canadian guideline for Parkinson disease. CMAJ. 2019;191(36).  
103. Jankovic J, Tan EK. Parkinson’s disease: Etiopathogenesis and treatment. J Neurol Neurosurg Psychiatry. 2020;91(8).  
104. Armstrong MJ, Okun MS. Diagnosis and Treatment of Parkinson Disease: A Review. Vol. 323, JAMA - Journal of the American Medical Association. 2020.  
105. Levodopa and the Progression of Parkinson’s Disease. New England Journal of Medicine. 2004;351(24).  
106. Kostelnik A, Cegan A, Pohanka M. Anti-Parkinson Drug Biperiden Inhibits Enzyme Acetylcholinesterase. Biomed Res Int [Internet]. 2017 [citado 19 de setembro de 2024];2017. Disponível em: /pmc/articles/PMC5530453/  
107. Corea N. Biperiden. xPharm: The Comprehensive Pharmacology Reference [Internet]. 20 de julho de 2017 [citado 19 de setembro de 2024];1–4. Disponível em: https://www.ncbi.nlm.nih.gov/books/NBK548257/  
108. Kostic V, Przedborski S, Flaster E, Sternic N. Early development of levodopa-induced dyskinesias and response fluctuations in young-onset parkinson’s disease. Neurology. 1991;41(2).  
109. Garcia-Ruiz PJ, Martinez Castrillo JC, Alonso-Canovas A, Herranz Barcenas A, Vela L, Sanchez Alonso P, et al. Impulse control disorder in patients with Parkinson’s disease under dopamine agonist therapy: A multicentre study. J Neurol Neurosurg Psychiatry. 2014;85(8).  
110. Rascol O, Brooks DJ, Korczyn AD, de Deyn PP, Clarke CE, Lang AE. A Five-Year Study of the Incidence of Dyskinesia in Patients with Early Parkinson’s Disease Who Were Treated with Ropinirole or Levodopa. New England Journal of Medicine. 2000;342(20).  
111. Rinne UK, Bracco F, Chouza C, Dupont E, Gershanik O, Marti Masso JF, et al. Early treatment of Parkinson’s disease with cabergoline delays the onset of motor complications. Results of a double-blind levodopa controlled trial. Em: Drugs. 1998.  
112. Hauser RA, Rascol O, Korczyn AD, Stoessl AJ, Watts RL, Poewe W, et al. Ten-year follow-up of Parkinson’s disease patients randomized to initial therapy with ropinirole or levodopa. Movement Disorders. 2007;22(16).  
26  
113. Katzenschlager R, Head J, Schrag A, Ben-Shlomo Y, Evans A, Lees AJ. Fourteen-year final report of the randomized PDRG-UK trial comparing three initial treatments in PD. Neurology. 2008;71(7).  
114. Koller WC. Treatment of early Parkinson’s disease. Vol. 58, Neurology. 2002.  
115. Silver DE, Ruggieri S. Initiating therapy for Parkinson’s disease. Vol. 50, Neurology. 1998.  
116. Miyasaki JM, Martin W, Suchowersky O, Weiner WJ, Lang AE. Practice parameter: Initiation of treatment for Parkinson’s disease: An evidence-based review: Report of the quality standards subcommittee of the American Academy of Neurology. Vol. 58, Neurology. 2002.  
117. Deuschl G, Schade-Brittinger C, Krack P, Volkmann J, Schäfer H, Bötzel K, et al. A randomized trial of deepbrain stimulation for Parkinson’s disease. N Engl J Med. agosto de 2006;355(9):896–908.  
118. Williams A, Gill S, Varma T, Jenkinson C, Quinn N, Mitchell R, et al. Deep brain stimulation plus best medical therapy versus best medical therapy alone  for advanced Parkinson’s disease (PD SURG trial): a randomised, open-label trial. Lancet Neurol. junho de 2010;9(6):581–91.  
119. Lee DJ, Lozano CS, Dallapiazza RF, Lozano AM. Current and future directions of deep brain stimulation for neurological and  psychiatric disorders. J Neurosurg. agosto de 2019;131(2):333–42.  
120. Krack P, Volkmann J, Tinkhauser G, Deuschl G. Deep Brain Stimulation in Movement Disorders: From Experimental Surgery to  Evidence-Based Therapy. Mov Disord. dezembro de 2019;34(12):1795–810.  
121. Ferreira JJ, Katzenschlager R, Bloem BR, Bonuccelli U, Burn D, Deuschl G, et al. Summary of the recommendations of the EFNS/MDS-ES review on therapeutic management  of Parkinson’s disease. Eur J Neurol. janeiro de 2013;20(1):5–15.  
122. Munhoz RP, Picillo M, Fox SH, Bruno V, Panisset M, Honey CR, et al. Eligibility Criteria for Deep Brain Stimulation in Parkinson’s Disease, Tremor, and  Dystonia. Can J Neurol Sci. julho de 2016;43(4):462–71.  
123. Pollak P. Deep brain stimulation for Parkinson’s disease - patient selection. Handb Clin Neurol. 2013;116:97– 105.  
124. Barone P, Antonini A, Colosimo C, Marconi R, Morgante L, Avarello TP, et al. The PRIAMO study: A multicenter assessment of nonmotor symptoms and their impact on quality of life in Parkinson’s disease. Movement Disorders. 2009;24(11):1641–9.  
125. Levy G, Tang MX, Louis ED, Côté LJ, Alfaro B, Mejia H, et al. The association of incident dementia with mortality in PD. Neurology. dezembro de 2002;59(11):1708–13.  
126. Pollak P, Tison F, Rascol O, Destée A, Péré JJ, Senard JM, et al. Clozapine in drug induced psychosis in Parkinson’s disease: a randomised, placebo  controlled study with open follow up. J Neurol Neurosurg Psychiatry. maio de 2004;75(5):689–95.  
127. Agência Nacional de Vigilância Sanitária (ANVISA). Clozapina (bula do medicamento). 2024.  
128. Rabey JM, Prokhorov T, Miniovitz A, Dobronevsky E, Klein C. Effect of quetiapine in psychotic Parkinson’s disease patients: a double-blind  labeled study of 3 months’ duration. Mov Disord. fevereiro de 2007;22(3):313– 8.  
129. Shotbolt P, Samuel M, Fox C, David AS. A randomized controlled trial of quetiapine for psychosis in Parkinson’s disease. Neuropsychiatr Dis Treat. 2009;5:327–32.  
130. Mamikonyan E, Xie SX, Melvin E, Weintraub D. Rivastigmine for mild cognitive impairment in Parkinson disease: a  placebo-controlled study. Mov Disord. junho de 2015;30(7):912–8.  
131. Emre M, Aarsland D, Albanese A, Byrne EJ, Deuschl G, De Deyn PP, et al. Rivastigmine for dementia associated with Parkinson’s disease. N Engl J Med. dezembro de 2004;351(24):2509–18.  
27  
132. Baik K, Kim SM, Jung JH, Lee YH, Chung SJ, Yoo HS, et al. Donepezil for mild cognitive impairment in Parkinson’s disease. Sci Rep. fevereiro de 2021;11(1):4734.  
133. Grace J, Amick MM, Friedman JH. A double-blind comparison of galantamine hydrobromide ER and placebo in Parkinson  disease. J Neurol Neurosurg Psychiatry. janeiro de 2009;80(1):18–23.  
134. Emre M, Tsolaki M, Bonuccelli U, Destée A, Tolosa E, Kutzelnigg A, et al. Memantine for patients with Parkinson’s disease dementia or dementia with Lewy  bodies: a randomised, double-blind, placebo-controlled trial. Lancet Neurol. outubro de 2010;9(10):969–77.  
135. Olivola S, Xodo S, Olivola E, Cecchini F, Londero A pietro, Driul L. Parkinson’s Disease in Pregnancy: A Case Report and Review of the Literature. Front Neurol. 2020;10.  
136. Seier M, Hiller A. Parkinson’s disease and pregnancy: An updated review. Vol. 40, Parkinsonism and Related Disorders. 2017.  
137. Post B, van den Heuvel L, van Prooije T, van Ruissen X, van de Warrenburg B, Nonnekes J. Young Onset Parkinson’s Disease: A Modern and Tailored Approach. Vol. 10, Journal of Parkinson’s Disease. 2020.  
138. Nicholas AP, Borgohain R, Chaná P, Surmann E, Thompson EL, Bauer L, et al. A randomized study of rotigotine dose response on “off” time in advanced Parkinson’s disease. J Parkinsons Dis. 2014;4(3):361‐373.  
139. Nomoto M, Mizuno Y, Kondo T, Hasegawa K, Murata M, Takeuchi M, et al. Transdermal rotigotine in advanced Parkinson’s disease: a randomized, double-blind, placebo-controlled trial. J Neurol. 2014;261(10):1887‐1893.  
28

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **AMANTADINA, BIPERIDENO, CLOZAPINA, ENTACAPONA, LEVODOPA + BENSERAZIDA, LEVODOPA + CARBIDOPA, PRAMIPEXOL, RASAGILINA, TRIEXIFENIDIL E RIVASTIGMINA** -->
Eu, _____________________________________________________________________________________ (nome do  
(a) paciente), declaro ter sido informado (a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de amantadina, biperideno, clozapina, entacapona, levodopa + benserazida, levodopa + carbidopa, pramipexol, rasagilina, triexifenidil e rivastigmina, indicados para o tratamento da **doença de Parkinson** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) ______________________  
_______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Diminuição dos sintomas;  
- Redução da incapacidade gerada pela doença;  
- Melhora da qualidade de vida.  
Fui também claramente informado (a) a respeito das seguintes contraindicações e potenciais eventos adversos:  
 **Amantadina** : é <u>contraindicada em casos de história de epilepsia, úlcera gástrica e úlcera duodenal. Os eventos adversos mais comuns incluem náusea, tontura e instabilidade, distúrbios do início e da manutenção do sono (insônias), episódios</u> depressivos, irritabilidade e mau humor, alucinações, confusão, anorexia, boca seca, constipação, ataxia não especificada, edema (de membros inferiores), livedo reticularis (afecções da pele e do tecido celular subcutâneo, não especificado), hipotensão ortostática, cefaleia, sonolência, nervosismo, pesadelos, agitação e inquietação, diarreia (alteração do hábito intestinal) e fadiga;  
 **Clozapina** : é contraindicada em pacientes incapazes de sofrerem hemogramas regulares, pacientes com antecedentes de granulocitopenia/agranulocitose tóxica ou idiossincrática (com exceção de granulocitopenia/agranulocitose causadas por quimioterapia prévia), transtornos hematopoiéticos, epilepsia não controlada, psicoses alcoólicas e tóxicas, intoxicação por drogas, afecções comatosas, colapso circulatório e/ou depressão do SNC de qualquer origem, transtornos renais ou cardíacos graves, hepatopatia ativa associada à náusea, anorexia ou icterícia, hepatopatia progressiva, insuficiência hepática, íleo paralítico, transtornos renais, hepatopatia ativa associada à náusea, anorexia ou icterícia, hepatopatia progressiva, insuficiência hepática. Os eventos adversos mais comuns incluem leucopenia/redução de glóbulos brancos/neutropenia, eosinofilia, leucocitose, ganho de peso, disartria, sonolência/sedação, vertigem, convulsões/abalos mioclônicos, sintomas extrapiramidais, acatisia, tremor, rigidez, dor de cabeça, visão borrada, taquicardia, alterações no eletrocardiograma, síncope, hipotensão postural, hipertensão, constipação, hipersalivação, náusea, vômito, boca seca, enzimas hepáticas elevadas, retenção urinária, incontinência urinária, hipertermia benigna, distúrbios na sudorese/regulação de temperatura, fadiga;  
 **Entacapona** : é <u>contraindicada em casos de disfunção hepática, pacientes com feocromocitoma por causa do risco</u> aumentado de crise hipertensiva, história prévia de síndrome neuroléptica maligna e/ou rabdomiólise não traumática, uso concomitante de entacapona com os inibidores não-seletivos da monoaminoxidase, uso concomitante de um inibidor seletivo de MAO-A com um inibidor seletivo de MAO-B e entacapona. Os eventos adversos mais comuns incluem discinesia, náusea, urina anormal, diarreia, agravamento do parkinsonismo, tontura, dor abdominal, insônia, boca seca, fadiga, alucinações, constipação, distonia, aumento da transpiração, hipercinesia, cefaleia, câimbras nas pernas, confusão, pesadelos, queda, hipotensão postural, vertigem e tremor;  
 **Levodopa + benserazida / levodopa + carbidopa** : é <u>contraindicada</u> no uso simultâneo com inibidores de monoaminoxidase-A. Os <u>eventos adversos mais comuns incluem náusea, discinesias, incluindo os movimentos coreiformes,</u>  
29  
distônicos e outros movimentos involuntários, outras reações são alterações comportamentais, incluindo ideação paranoide e episódios psicóticos, depressão com ou sem desenvolvimento de tendências suicidas e demência;  
 **Pramipexol** : os <u>eventos adversos mais comuns incluem tontura, discinesia, sonolência, náusea, comportamentos</u> anormais (refletindo sintomas de transtornos do controle dos impulsos e comportamento compulsivo), sonhos anormais, confusão, alucinações, insônia, cefaleia, distúrbios visuais incluindo diplopia, visão embaçada e acuidade visual reduzida, hipotensão, constipação, vômito, fadiga, edema periférico e perda de peso incluindo perda de apetite;  
 **Biperideno e triexifenidil:** reações alérgicas na pele, confusão, problemas na visão, prisão de ventre, dificuldade ou dor para urinar, boca seca, sensibilidade aumentada dos olhos à luz, náusea, vômitos. Reações menos frequentes ou raras incluem dor de cabeça, perda de memória, nervosismo, cansaço, tontura ao levantar, dor de estômago, inflamação da boca ou língua, dificuldade para dormir;  
 **Rasagilina** : é <u>contraindicada no uso simultâneo com outros inibidores da MAO, analgésicos narcóticos,</u> ciclobenzaprina, _Hypericum perforatum_ ; para pacientes com insuficiência hepática grave e feocromocitoma. Os eventos adversos mais comuns incluem cefaleia, depressão, vertigem e síndrome gripal (influenza e rinite), quando administrado em monoterapia; discinesia, hipotensão ortostática, queda, dor abdominal, náusea e vômito e boca seca, quando administrado em terapia adjunta com levodopa; dor musculoesquelética como dor nas costas e nuca, e artralgia em ambos os regimes;  
 **Rivastigimina** : O uso de rivastigmina é contraindicado em pacientes com: conhecida hipersensibilidade à rivastigmina, a outros derivados do carbamato ou aos excipientes da fórmula; ou histórico prévio de reações no local de aplicação sugestivas de dermatite alérgica de contato com rivastigmina sistema transdérmico. Os <u>eventos adversos relatados mais</u> comumente são gastrintestinais, incluindo náusea (38%) e vômitos (23%).  
Fui informado que todos os medicamentos são contraindicados em caso de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula e que o risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este (s) medicamento (s) somente pode (m) ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o (s) medicamento (s).  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
( ) Sim ( ) Não  
Meu tratamento constará de um ou mais dos seguintes medicamentos:  
- (  ) Amantadina                    (  ) Levodopa + carbidopa  
- ( ) Biperideno                       (  ) Pramipexol  
- (  ) Clozapina                         (  ) Rasagilina  
- (  ) Entacapona                       (  ) Triexifenidil  
(  ) Levodopa + benserazida    (  ) Rivastigmina  
30  
<!-- Start of picture text -->
Local:                                                                Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
**Nota** : Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
31

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **1.        Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Doença de Parkinson (DP), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
A elaboração do PCDT da Doença de Parkinson iniciou-se com a demanda pelo Ministério da Saúde (MS) e as reuniões de pré-escopo, de escopo e de priorização de perguntas realizadas entre 04/04/2021 e 22/06/2022.  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, os quais foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Os trabalhos foram conduzidos considerando as Diretrizes Metodológicas para Elaboração de Diretrizes Clínicas. Definiu-se que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não demandariam questões de pesquisa definidas por serem práticas clínicas estabelecidas, exceto em casos de incertezas sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Ainda, foram elencadas três novas questões de pesquisa para a elaboração do PCDT.  
- Para pacientes com DP e ‘sintomas noturnos, wearing off ou freezing’, a rotigotina (em monoterapia ou associada à levodopa) é segura e eficaz em comparação com o pramipexol (em monoterapia ou associada à levodopa) ou em comparação com placebo, mensurada pela _Unified Parkinson’s Disease Rating Scale_ (UPDRS), sintomas noturnos e wearing off?  
- Para pacientes com DP responsivos à levodopa e com indicação de terapia combinada, a safinamida associada a um ou mais medicamentos é segura e eficaz em comparação com medicamentos inibidores da MAO associados à levodopa, ou em comparação com tratamento padrão, ou mesmo placebo, mensurada pela escala UPDRS, sintomas de wearing off e dor?  
- Para pacientes com DP e demência, a rivastigmina (cápsula, solução oral ou adesivo transdérmico) é segura e eficaz comparada a placebo ou ao cuidado padrão, mensurada pela escala UPDRS, minimental e MoCA?

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **2.       Equipe de elaboração e partes interessadas.** -->
O Protocolo foi atualizado pela equipe do Hospital Alemão Oswaldo Cruz.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Declaração e Manejo de Conflitos de Interesse</u>** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse (Quadro A).  
32  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos be|nefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|<br>(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|<br>(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetad<br>na elaboração ou revisão da diretriz?|os pela sua atividade|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e|<br>(   ) Sim|
|que deveria ser do conhecimento público?|(   ) Não|  
33  
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua<br>(|) Sim|
|---|---|
|objetividade ou imparcialidade?<br>(|) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?<br>(<br>(|) Sim<br>) Não|

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **3.       Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT de Doença de Parkinson foi apresentada na 118ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 17/09 de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).  
Os membros do Comitê de PCDT, presentes na 134ª reunião da Conitec, realizada em 04 de outubro de 2024, deliberaram para que o tema fosse submetido à consulta pública com recomendação preliminar favorável à publicação deste Protocolo.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **4.       Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT seguiu as recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ou PIRO ( **Figura A** ).  
**Figura A -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.  
<!-- Start of picture text -->
FP | *Populacdo ou condi¢ao clinica<br>‘*Interven¢do, no caso de estudos experimentais<br>*Fator de exposi¢do, em caso de estudos observacionais<br>Teste indice, nos casos de estudos de acurdcia diagnéstica<br>Controle, de acordo com tratamento/niveis de exposi¢do do fator/exames<br>disponiveis no SUS<br>*Desfechos: sempre que possivel, definidos a priori, de acordo com sua<br>importancia<br><!-- End of picture text -->  
Durante a reunião de escopo deste PCDT três questões de pesquisa foram definidas. Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel, recomendações de outras diretrizes, um resumo das evidências e as tabelas de perfil de evidências de acordo com a metodologia GRADE.  
**Questão 1: Para pacientes com DP e ‘sintomas noturnos,** **_wearing off_ ou** **_freezing’_ , a rotigotina (em monoterapia ou associada à levodopa) é segura e eficaz em comparação com o pramipexol (em monoterapia ou associada à levodopa) ou em comparação com placebo, mensurada pela** **_Unified Parkinson’s Disease Rating Scale_ (UPDRS), sintomas noturnos e** **_wearing off_ ?**  
34  
**Recomendação:** O Protocolo não emitiu recomendação, uma vez que o medicamento não foi avaliado pela Conitec. Identificou-se que a rotigotina + levodopa em comparação ao placebo + levodopa parece ser capaz de promover benefícios relacionados à parte II e III da UPDRS, sem diferenças no perfil de segurança. Quando à associação rotigotina + levodopa, não foi encontrada diferenças estatisticamente significantes para nenhum desfecho, quando comparada a pramipexol + levodopa. Adicionalmente, a incorporação da rotigotina resultaria em aumento dos gastos para o sistema para prover uma alternativa terapêutica tão eficaz quanto às disponíveis no SUS. <mark>Dessa forma, verificou-se que sua avaliação pela Conitec não seria viável.</mark>

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>EVIDÊNCIAS CLÍNICAS</u>** -->
Com base na pergunta PICO que estabeleceu os critérios de elegibilidade da do PTC, foi realizada uma busca em agosto de 2022 nas seguintes plataformas: PubMed, EMBASE, Literatura Latino-Americana e do Caribe em Ciências da Saúde (LILACS) e The Cochrane Library. Para validação da estratégia de busca, uma busca no Epistemonikos e clinicaltrials foi realizada visando a identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões. O Quadro abaixo a seguir detalha as estratégias de busca conduzidas em cada plataforma.  
**Quadro B** . Estratégia de busca nas plataformas consultadas em agosto de 2022.  
|**Plataformas de**|**Estratégia de busca**|
|---|---|
|**busca**||
|**PubMed**|((((((((((((("Parkinson Disease"[Mesh]) OR ("Parkinson Disease"[Title/Abstract])) OR ("Idiopathic<br>Parkinson's Disease")) OR ("Lewy Body Parkinson's Disease")) OR ("Parkinson's Disease, Idiopathic"))<br>OR ("Parkinson's Disease, Lewy Body")) OR ("Parkinson Disease, Idiopathic")) OR ("Parkinson's<br>Disease")) OR ("Idiopathic Parkinson Disease")) OR ("Lewy Body Parkinson Disease")) OR ("Primary|
||Parkinsonism"))<br>OR<br>("Parkinsonism,<br>Primary"))<br>OR<br>("Paralysis<br>Agitans"))<br>AND<br>(((((((((((((((((((((("rotigotine" [Supplementary Concept]) OR (rotigotine[Title/Abstract])) OR (N 0437,<br>hydrochloride, (S)-isomer)) OR (N 0923)) OR (N-0923)) OR (N 0924)) OR (N-0924)) OR (rotigotine,<br>(+)-)) OR ((+)-5,6,7,8-tetrahydro-6-(propyl(2-(2-thienyl)ethyl)amino)-1-naphthol)) OR (Neupro)) OR (N<br>0437)) OR (N-0437)) OR (N 0437, (+-)-isomer)) OR (N 0437, (-)-isomer)) OR (N 0437, hydrochloride,<br>(R)-isomer)) OR (rotigotine, (+--)-)) OR (racemic N-0437)) OR (rotigotine (+-)-form)) OR (1-<br>naphthalenol, 5,6,7,8-tetrahydro-6-(propyl(2-(2-thienyl)ethyl)amino)-)) OR ((+--)-5,6,7,8-tetrahydro-6-<br>(propyl(2-(2-thienyl)ethyl)amino)-1-naphthol)) OR (N 0437, (R)-isomer)) OR (Rotigotine CDS))|
|**EMBASE**|('parkinson disease'/exp OR 'parkinson disease' OR 'lewy bodies of parkinson disease'/exp OR 'lewy bodies<br>of parkinson disease' OR 'lewy bodies of parkinsons disease'/exp OR 'lewy bodies of parkinsons disease'<br>OR 'paralysis agitans'/exp OR 'paralysis agitans' OR 'parkinson dementia complex'/exp OR 'parkinson<br>dementia complex' OR 'parkinsons disease'/exp OR 'parkinsons disease' OR 'primary parkinsonism'/exp<br>OR 'primary parkinsonism') AND ('rotigotine'/exp OR 'rotigotine' OR 'leganto'/exp OR 'leganto' OR<br>'n0437'/exp OR 'n0437' OR 'n0923'/exp OR 'n0923' OR 'n0924'/exp OR 'n0924' OR 'n437'/exp OR 'n437'<br>OR 'neupro'/exp OR 'neupro' OR 'rotigotin'/exp OR 'rotigotin' OR 'rotigotine hydrochloride'/exp OR<br>'rotigotine hydrochloride' OR 'spm962'/exp OR 'spm962') AND [embase]/lim|
|**LILACS**|((( mh:("Parkinson Disease"))) OR (idiopathic parkinson disease) OR (idiopathic parkinson's disease) OR<br>(lewy body parkinson disease) OR (lewy body parkinson's disease) OR (parkinson disease, idiopathic) OR<br>(parkinson's disease) OR (parkinson's disease, idiopathic) OR (parkinson's disease, lewy body) OR<br>(parkinsonism, primary) OR (primary parkinsonism)) AND ((rotigotine) OR (neupro))|  
35  
|**Plataformas de**|**Estrat**|**égia de busca**|
|---|---|---|
|**busca**|||
|**_The_**<br>**_Cochrane_**|#1|MeSH descriptor: [Parkinson Disease] explode all trees|
|**_Library_**|#2|"Parkinson Disease"|
|**(Apenas**|#3|"Paralysis Agitans"|
|**revisões)**|#4|"Lewy Body Parkinson Disease"|
||#5|"Parkinson's Disease, Lewy Body"|
||#6|"Parkinson's Disease"|
||#7|"Lewy Body Parkinson's Disease"|
||#8|"Idiopathic Parkinson Disease"|
||#9|"Parkinson's Disease, Idiopathic"|
||#10|" Parkinsonism, Primary"|
||#11|"Idiopathic Parkinson's Disease"|
||#12|"Primary Parkinsonism"|
||#13|"Parkinson Disease, Idiopathic"|
||#14|#1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11 OR #12 OR #13|
||#15|rotigotine|
||#16|"N 0437, hydrochloride, (S)-isomer"|
||#17|"N 0923"|
||#18|"N-0923"|
||#19|"N 0924"|
||#20|"N-0924"|
||#21|Neupro|
||#22|"N 0437"|
||#23|N-0437|
||#24|"racemic N-0437"|
||#25|"Rotigotine CDS"|
||#26<br>#27|#15 OR #16 OR #17 OR #18 OR #19 OR #20 OR #21 OR #22 OR #23 OR #24 OR #25<br>#14 AND #26|  
Extração de dados foi realizada por um único avaliador, usando planilhas do software Microsoft Office Excel®.  Todos os dados extraídos foram conferidos integralmente por um segundo revisor. Os seguintes dados foram obtidos dos estudos:  
i) Características dos estudos e intervenções: número no ClinicalTrials (NCT); acrônimo de identificação; país; número de centros; características gerais da população; alternativas comparadas quanto à dose, frequência e via de administração, tanto para tratamentos ativos, quanto placebo, quando pertinente; cointervenções; desenho do estudo; método de randomização e de sigilo de alocação se estudo randomizado; equilíbrio das características de baseline; cegamento de participantes; análise por intenção de tratar - Intention-to-treat analysis (ITT); desvios e desequilíbrio de cointervenções; desfechos incompletos; cegamento do avaliador; e reporte seletivo de resultado. Sempre que pertinente, as informações relativas ao risco de viés dos estudos foram extraídas segundo desfecho;  
ii) Características dos participantes: número de participantes por alternativa comparada, segundo sexo, idade média, duração da DP, tempo de off diário, total UPDRS, estágio Hoehn e Yahr e dose de levodopa;  
36  
iii) Desfechos e resultados: definição e time-point de avaliação do desfecho e resultados por alternativa para cada desfecho. Para desfechos contínuos: média, desvio-padrão (DP), n e valor de p; e para desfechos dicotômicos: n com evento, n com a alternativa (população ITT ou por protocolo [PP], a depender do reportado), odds ratio (OR), risco relativo (RR), intervalo de confiança (IC) ou valor de p. Para obtenção desses parâmetros, em alguns casos, foi necessário recorrer a cálculos, imputações e deduções (i.e., conversão de IC ou erro-padrão em DP, cálculo do DP da diferença a partir dos DP de início e final de tratamento).  
A síntese e análise dos dados foi feita, preferencialmente, por meta-análises complementadas representação individual dos resultados dos estudos. A avaliação de homogeneidade foi realizada por meio da comparação do acrônimo PICO de cada estudo (critérios de inclusão e exclusão da população, definições de subpopulações, intervenção e controles e definições dos desfechos). Sendo identificadas discrepâncias importantes, elas foram discutidas como potenciais limitações das meta-análises. A seguir apresentamos as principais características de cada síntese e análise, segundo tipo:  
 Síntese e representação individual dos resultados: As características do estudo, características dos participantes, resultados individuais e avaliação da qualidade dos estudos incluídos foram apresentadas de forma narrativa e a estatística descritiva (frequência absoluta e relativa, média e DP ou mediana e intervalo interquartil [IIQ]), incluindo tabelas para o auxílio na apresentação dos resultados. Os resultados narrativos foram agrupados por desfecho, fazendo destaque às alternativas comparadas. Para avaliação da heterogeneidade, métodos informais foram utilizados considerando inspeção visual de tabelas de características e resultados e potenciais modificadores (idade e densidade mineral óssea).  
 Meta-análises diretas: Meta-análises diretas foram conduzidas no software Review Manager. Para as meta-análises tradicionais de desfechos dicotômicos, foram calculadas medidas de efeito como odds ratio (OR), com intervalos de confiança de 95%, usando o método estatístico Mantel-Haenszel. Os desfechos contínuos foram analisados por diferença de média ± desvio padrão, considerando o método estatístico Mean difference.  
Para a avaliação do risco de viés dos ensaios clínicos randomizados foi utilizada a ferramenta Risk of Bias (RoB 2.0). Como preconizado pela ferramenta, a avaliação foi feita no nível do estudo, do desfecho e do resultado, quando pertinente. A qualidade ou confiança da evidência foi avaliada considerando Grading of Recommendations Assessment, Development and Evaluation (GRADE) Working Group.  
A revisão sistemática da literatura incluiu seis estudos, com 12 a 19 semanas de acompanhamento. Apenas um estudo comparou a rotigotina + levodopa _versus_ pramipexol + levodopa e os demais compararam placebo + levodopa e diferentes doses de rotigotina. Em todos os ECR os pacientes poderiam estar em uso de outros antiparkinsonianos nos dois braços de estudo, como parte do cuidado padrão. Nenhum dos estudos reportou resultados referentes a sintomas noturnos, _freezing_ e fadiga.  
37  
**Figura B -** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
egos eto de feasts removaos antes ca | | restos wenticados<br>cronGers? | ——>| aeletronicamentesncate(n = 399) enone | | MantesPesquisade citagéesoy(n = 0)<br>15753) j—r>| (n= 4721)<br>(n= |<br>Regisos procurados para Registos no recuperados Registios procurados para Registro<br>anal(n=32) Gaia (=o) no recuperados<br>Regisos — avaiados para Registios —avaiados para<br>elegiiidade —s elegidade Regisros excuidos<br>(32) (070) (070)<br>Registos exciidos:<br>Tipo de pacientes(n = 26)<br>Regios inludos no PTC<br>Sen=6) camer<br><!-- End of picture text -->  
Fonte: Traduzido e preenchido de Page MJ, McKenzie JE, Bossuyt PM, Boutron I, Hoffmann TC, Mulrow CD, et al. The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. BMJ 2021;372:n71. doi: 10.1136/bmj.n71. For more information, visit: http://www.prisma-statement.org/  
O desfecho esperado era o UPDRS - escore total e subescores (II, III e IV, respectivamente, atividades da vida diária on/off, exame motor e complicações da terapia); sintomas noturnos e _wearing off_ como desfechos primários; e _freezing_ , fadiga, sonolência diurna como desfechos secundários.  
Foi realizada uma meta-análise direta para o desfecho da mudança no escore de UPDRS parte III em tratamentos de 12 a 24 semanas. Essa meta-análise evidenciou a superioridade estatisticamente significante da rotigotina + levodopa quando comparado ao placebo + levodopa para esse desfecho (DM: -5,52 (IC95%: -7,25 a -3,79)) ( **Quadro C** ).  
Da mesma forma, foi realizada uma meta-análise direta para o desfecho da mudança no escore total UPDRS parte II em tratamentos de 12 a 24 semanas. Essa meta-análise evidenciou a superioridade estatisticamente significante da rotigotina + levodopa quando comparado ao placebo + levodopa para esse desfecho (DM: -2,12 (IC95%: -2,73 a -1,52))  
Apenas um estudo CLEOPATRA-PD (SP515) (NCT00244387, Poewe et al., 200716) comparou a rotigotina + levodopa ao pramipexol + levodopa e não foi observada diferença entre os dois tratamentos para mudança nos escores de UPDRS II (aspectos motores de atividade de vida diária) e III (avaliação motora).  
Para o desfecho de mudança no número de períodos “ _off_ ” em 19 a 24 semanas de tratamento, a meta-análise direta evidenciou a superioridade estatisticamente significativa (DM: -0,52 (IC95%: -1,03 a -0,001)), porém marginal, da rotigotina + levodopa quando comparado ao placebo + levodopa.  
Para o desfecho de mudança no estado do paciente após acordar (proporção de dias em que o paciente acordou “ _off_ ” em tratamentos de 12 a 24 semanas), a meta-análise direta evidenciou a superioridade estatisticamente significativa (DM: -9,62 (IC95%: -16,10 a -3,13)) da rotigotina + levodopa comparada ao placebo + levodopa.  
Para o desfecho de mudança no tempo absoluto gasto “ _off_ ” em horas em 19 a 24 semanas de tratamento, a meta-análise direta evidenciou a superioridade estatisticamente significante (DM: -1,29 (IC95%: -1,67 a -0,91)) da rotigotina + levodopa quando comparado ao placebo + levodopa.  
38  
Apenas um estudo comparou a rotigotina + levodopa ao pramipexol + levodopa, não sendo encontradas diferenças estatisticamente significativas entre os grupos em redução do número de períodos “ _off_ ” e da porcentagem de dias que os pacientes acordaram em estado “ _off_ ”. Para mudança absoluta no tempo em “ _off_ ”, a rotigotina + levodopa foi não inferior ao seu comparador, embora os resultados favoreçam o último (DM=0,35, IC 95%: -0,21 a 0,92).  
39  
**Quadro C** - Resultados para desfechos relativos à eficácia.  
|**Estudo**|**_Time-point_**<br>|**Alternativa**||**_N_**|**_Média (DP)_**|**_Alternativa_**|**_N_**|**_Média (DP)_**|**Direção do efeito**|
|---|---|---|---|---|---|---|---|---|---|
|**Mudança no escore tota**|**_(semanas)_**<br>**l UPDRS part**|**e III**||||||||
|LeWitt et al., 2007|24|Rotigotina 12 mg/dia + levodopa||81|-8,7 (NR)|Placebo + levodopa|92|-3,4 (NR)|Favorece rotigotina|
|Poewe et al., 2007|24|Rotigotina até 16 mg/dia + levodopa||204|–8,7 (8,0)|Pramipexol até 4,5 mg/dia + levodopa|201|–10,3 (8,7)|Sem diferença *|
|Nicholas et al., 2014|12|Rotigotina 8 mg/dia + levodopa||94|−5,9 (7,6)|Placebo + levodopa|105|−2,5 (8,2)|Favorece rotigotina|
|Nomoto et al., 2014|12|Rotigotina até 16 mg/dia + levodopa||86|-10,1 (9,0)|Placebo + levodopa|86|-4,4 (7,4)|Sem diferença *|
|Zhang et al., 2017|19|Rotigotina<br>até<br>16<br>mg/dia<br>levodopa/benserazida|+|170|-10,4 (10,4)|Placebo + levodopa/benserazida|168|-3,6 (9,8)|Favorece rotigotina|
|Bhidayasiri et al., 2017|12|Rotigotina até 16 mg/dia + levodopa||17|- 17,2 (11,2)|Placebo + levodopa|17|- 5,9 (12,0)|Sem diferença *|
|**Mudança no escore tota**|**l UPDRS part**|**e II**||||||||
|LeWitt et al., 2007|24|Rotigotina 12 mg/dia + levodopa||81|-3,2 (NR)|Placebo + levodopa|92|-0,5 (NR)|Sem diferença *|
|Poewe et al., 2007|24|Rotigotina até 16 mg/dia + levodopa||204|–4,2 (4,5)|Pramipexol até 4,5 mg/dia + levodopa|201|–4,6 (4,4)|Sem diferença *|
|Nicholas et al., 2014<sup>138</sup>|12|Rotigotina 8 mg/dia + levodopa||94|−2,1 (4,6)|Placebo + levodopa|105|−0,9 (3,7)|Favorece rotigotina|
|Nomoto et al., 2014<sup>139</sup>|12|Rotigotina até 16 mg/dia + levodopa||82|-3,8 (3,6)|Placebo + levodopa|82|-1,6 (2,6)|Favorece rotigotina|
|Zhang et al., 2017|19|Rotigotina<br>até<br>16<br>mg/dia<br>levodopa/benserazida|+|163|-4,2 (4,9)|Placebo + levodopa/benserazida|162|-1,4 (5,3)|Favorece rotigotina|
|**Mudança no número de**|**períodos “off**|**”**||||||||
|LeWitt et al., 2007|24|Rotigotina 12 mg/dia + levodopa||109|-1,3 (NR)|Placebo + levodopa|119|-0,7 (NR)|Favorece rotigotina|
|Poewe et al., 2007|24|Rotigotina até 16 mg/dia + levodopa||204|-1,4 (1,8)|Pramipexol até 4,5 mg/dia + levodopa|201|-1,4 (1,9)|Sem diferença *|
|Zhang et al., 2017|19|Rotigotina<br>até<br>16<br>mg/dia<br>levodopa/benserazida|+|170|-0,89 (1,32)|Placebo + levodopa/benserazida|168|-0,61 (1,59)|Favorece rotigotina|  
**Legenda: DP:** desvio-padrão **; N:** número **; *** sem diferença estatisticamente significativa.  
40  
O desfecho fadiga não foi relatado nos estudos incluídos.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Efeitos indesejáveis da tecnologia** -->
A meta-análise não revelou uma diferença estatisticamente significante entre a rotigotina (de 2 a 16 mg/24 horas) + levodopa e o placebo + levodopa em tratamentos de 12 a 24 semanas para o desfecho de eventos adversos (Quadro D).  
Os estudos que investigaram o desfecho sonolência diurna utilizaram a _Epworth Sleepiness Scale_ . O desfecho foi relatado em quatro estudos, sendo que em três deles a maior proporção de pacientes no grupo rotigotina + levodopa apresentou este evento, e em um não foi observada diferença significativa entre os grupos. A meta-análise não revelou uma diferença estatisticamente significativa entre a rotigotina (de 2 a 16 mg/24 horas) + levodopa e o placebo + levodopa em tratamentos de 12 a 24 semanas para o desfecho de sonolência diurna.  
Quatro estudos relataram eventos adversos graves. Três relataram proporções semelhantes entre os grupos, enquanto um estudo evidenciou maior proporção em pacientes do grupo placebo. A meta-análise não revelou uma diferença estatisticamente significante entre a rotigotina (de 2 a 16 mg/24 horas) + levodopa e o placebo + levodopa em tratamentos de 12 a 24 semanas para o desfecho de eventos adversos graves.  
Cinco estudos relataram o desfecho descontinuação por eventos adversos e, quando analisados individualmente, apresentaram resultados contraditórios. A meta-análise não revelou uma diferença estatisticamente significativa entre a rotigotina (de 2 a 16 mg/24 horas) + levodopa e o placebo + levodopa em tratamentos de 12 a 24 semanas para o desfecho.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Qualidade geral das evidências** -->
A qualidade foi moderada para a maioria dos desfechos. Os principais motivos para rebaixamento da qualidade da evidência foram o risco de viés e a inconsistência (Quadro E e F).  
41  
**Quadro D** - Resultados para desfechos relativos à segurança.  
|**Estudo**|**_Time-point_**<br>|**Alternativa**|**Total pts expostos (% com**<br>|**Alternativa**|**Total**|**pts**<br>**Direção do efeito**|
|---|---|---|---|---|---|---|
||**_(semanas)_**||**evento)**||**expostos**||
|**Descontinuação de**<br>|**tratamento devido a**<br>|**evento adverso**<br>|||||
|LeWitt et al., 2007|24|Rotigotina 12 mg/dia + levodopa|111 (15,3)|Placebo + levodopa|120 (9,2)|Favorece placebo|
|Poewe et al., 2007|24|Rotigotina até 16 mg/dia + levodopa|205 (5,0)|Pramipexol<br>até<br>4,5<br>mg/dia<br>+<br>levodopa|<br>202 (7,0)|Favorece<br>rotigotina|
|Nicholas<br>et<br>al.,<br>2014|12|Rotigotina 8 mg/dia + levodopa|94 (5,0)|Placebo + levodopa|108 (16,0)|Favorece<br>rotigotina|
|Nomoto<br>et<br>al.,<br>2014|12|Rotigotina até 16 mg/dia + levodopa|87 (12,6)|Placebo + levodopa|87 (8,0)|Favorece placebo|
|Zhang et al., 2017|19|Rotigotina<br>até<br>16<br>mg/dia<br>+<br>|174 (4,1)|Placebo + levodopa/benserazida|172 (4,6)|Sem diferença *|
|**Pacientes com even**|**to adverso grave**|levodopa/benserazida|||||
|Poewe et al., 2007|24|Rotigotina 12 mg/dia + levodopa|204 (9,0)|Placebo + levodopa|101 (9,0)|Sem diferença *|
|Nicholas<br>et<br>al.,<br>2014|12|Rotigotina 8 mg/dia + levodopa|94 (0,0)|Placebo + levodopa|108 (4,6)|Favorece<br>rotigotina|
|Nomoto<br>et<br>al.,<br>2014|12|Rotigotina 16 mg/dia + levodopa|87 (3,4)|Placebo + levodopa|8,7 (3,4)|Sem diferença *|
|Zhang et al., 2017|19|Rotigotina<br>até<br>16<br>mg/dia<br>+<br>|174 (3,4)|Placebo + levodopa/benserazida|172 (3,5)|Sem diferença *|
|<br>**Pacientes com even**|**to adverso**|levodopa/benserazida||<br>Pramipexol<br>até<br>4,5<br>mg/dia<br>+|<br>||
|Poewe et al., 2007|24|Rotigotina até 16 mg/día + levodopa|204 (69,0)|<br> <br> <br>levodopa|201 (69,0)|Sem diferença *|
|Nicholas<br>et<br>al.,<br>2014|12|Rotigotina 8 mg/dia + levodopa|94 (73,0)|Placebo + levodopa|108 (72,0)|Sem diferença *|  
**Legenda: pts** : pacientes; * sem diferença estatisticamente significativa.  
42  
**Quadro E -** Avaliação da qualidade da evidência da rotigotina versus placebo (GRADE).  
|**Avaliação da qualidad**|**e**||||||**Sumário**<br>**Resultados**|**de**<br>|
|---|---|---|---|---|---|---|---|---|
|**Comparação**<br>|<br>|||||**Confiança**|||
|**Participantes**<br>**(estudos)**<br>**Mudança no escore total UPDRS parte III**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**geral**<br>**da**<br>**evidência**|<br>**Impacto**||
|6<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|Nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|
|**Mudança no escore total UPDRS parte II**|||||||||
|4<br>ensaios<br>clínicos<br>randomizados<br>**Mudança no tempo absoluto gasto “off” em**|grave<sup>a</sup><br>**horas**|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|
|4<br>ensaios<br>clínicos<br>randomizados<br>**Descontinuação de tratamento devido a eve**|grave<sup>a</sup><br>**nto adverso**|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|
|5<br>ensaios<br>clínicos<br>randomizados<br>**Pacientes com evento adverso grave**|grave<sup>a</sup>|grave<sup>b</sup>|não grave|não grave|nenhum|⨁⨁◯◯<br>Baixa|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|  
43  
|**Avaliação da qualidad**|**e**||||||**Sumário**<br>**Resultados**|**de**<br>|
|---|---|---|---|---|---|---|---|---|
|**Comparação**<br>**Participantes**<br>**(estudos)**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**Confiança**<br>**geral**<br>**da**<br>**evidência**|<br>**Impacto**||
|4<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|
|**Pacientes com evento adverso**|||||||||
|4<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|
|**Sonolência diurna em tratamentos de 12 a 2**|**4 semanas**||||||||
|3<br>ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Sem<br>estatística<br>grupos.|diferença<br>entre<br>os|  
**Explicações**  
a. A maioria dos estudos apresentou ‘algumas preocupações’ para o risco de viés.  
b. Alguns estudos com direção dos resultados opostos.  
**Legenda: ECR:** ensaio clínico randomizado **; IC** : intervalo de confiança; **MD** : diferença média; **RR** : risco relativo.  
44  
**Quadro F -** Avaliação da qualidade da evidência da rotigotina versus pramipexol (GRADE).  
|**Comparação**|||**Av**|**aliação da qualid**<br>|**ade**||**Confiança**|**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**geral da**<br>**evidência**|**Impacto**|
|**Mudança no escor**<br>|**e total UPDRS parte III**<br> <br>|||||||<br>|
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Apenas<br>um<br>estudo<br>(CLEOPATRA-PD<br>(SP515)<br>NCT00244387 Poewe<br>et<br>al.,<br>20075)<br>comparou a rotigotina<br>ao pramipexol e não<br>foi<br>observada|
|||||||||diferença entre os dois<br>tratamentos<br>para<br>mudança nos escores<br>de<br>UPDRS<br>III<br>(avaliação motora).|
|**Mudança no escor**<br>|**e total UPDRS parte II**<br> <br>|||||||<br>|
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Apenas<br>um<br>estudo<br>(CLEOPATRA-PD<br>(SP515)<br>NCT00244387 Poewe|  
45  
|**Comparação**|||**Av**|**aliação da qualid**<br>|**ade**||**Confiança**|**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**geral da**<br>**evidência**|**Impacto**|
|||||||||et<br>al.,<br>20075)<br>comparou a rotigotina<br>ao pramipexol e não<br>foi<br>observada<br>diferença entre os dois<br>tratamentos<br>para<br>mudança nos escores<br>de<br>UPDRS<br>II<br>(aspectos motores de<br>atividade<br>de<br>vida<br>diária).|
|**Mudança no temp**<br>|**o absoluto gasto “off” em**<br> <br>|**horas**<br>||||||<br>|
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|Apenas<br>um<br>estudo<br>comparou a rotigotina<br>ao pramipexol, não<br>sendo<br>encontradas<br>diferenças<br>estatisticamente<br>significativas entre os<br>grupos em redução do|  
46  
|**Comparação**||||**Avaliação da qualida**<br>|**de**||**Confiança**|**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
||**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**geral da**<br>**evidência**|**Impacto**|
|**Descontinuação de**<br>|**tratamento devido a eve**<br> <br>|**nto adverso**||||||número de períodos<br>“_off_” e da porcentagem<br>de<br>dias<br>que<br>os<br>pacientes<br>acordaram<br>em estado “_off_”. Para<br>mudança absoluta no<br>tempo em “_off_”, a<br>rotigotina<br>foi<br>não<br>inferior<br>ao<br>seu<br>comparador,<br>embora<br>os<br>resultados<br>favoreçam o último<br>(DM=0,35, IC 95%: -<br>0,21 a 0,92).<br>|
|1|ensaios<br>clínicos|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯|não estimável|
|**Pacientes com even**<br>|randomizados<br>**to adverso grave**<br> <br>||||||Moderada<br>||
|1|ensaios<br>clínicos|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯|não estimável|
||randomizados||||||Moderada|47|  
||||**A**|**valiação da qualid**|**ade**|||**Sumário de**<br>**Resultados**|
|---|---|---|---|---|---|---|---|---|
|**Comparação**|**Participantes**<br>**(estudos)**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**Confiança**<br>**geral da**<br>**evidência**|**Impacto**|
|**Pacientes com eve**|**nto adverso**||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|não estimável|
|**Sonolência diurna**|**em tratamentos de 12 a 2**|**4 semanas**|||||||
|1|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|⨁⨁⨁◯<br>Moderada|não estimável|  
48

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Balanço entre efeitos desejáveis e indesejáveis** -->
Os estudos sugerem que, para a comparação rotigotina + levodopa vs placebo + levodopa, foi observada superioridade da primeira para os desfechos de UPDRS II (aspectos motores de atividade de vida diária), UPDRS III (função motora) e sintomas noturnos, com redução de períodos _“off”_ (% de dias em período _“off”_ e tempo absoluto gasto em período _“off”_ ), sem resultar em aumento da incidência de eventos adversos. Não foi observada diferença entre esses grupos no que diz respeito à sonolência diurna. Já para a comparação rotigotina + levodopa vs. pramipexol + levodopa, resultados de um único estudo sugerem não haver diferença entre os dois tratamentos tanto para eficácia quanto para segurança.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Avaliação econômica</u>** -->
Foi elaborada uma Análise de Custo-Minimização (ACM) no Microsoft Office Excel® (Microsoft Corporation, Redmond, WA, EUA) ( **Quadro G** ). O desenho do estudo seguiu premissas das Diretrizes Metodológicas de Avaliação Econômica do Ministério da Saúde (MS)<sup>6</sup> . Além disso, com a finalidade de aumentar a clareza e transparência do estudo, os principais aspectos são sumarizados conforme o checklist CHEERS Task Force Report<sup>7</sup> .  
**Quadro G** - Características da avaliação econômica.  
|**Título**|Análise de custo-minimização da rotigotina + levodopa comparada ao pramipexol + levodopa em<br>pacientes com Doença de Parkinson e sintomas noturnos,_wearing off_ou_freezing_|
|---|---|
|**Antecedentes**<br>**e**<br>**objetivos**|Considerando a pergunta norteadora do relatório, identificou-se evidência comparativa entre rotigotina<br>+ levodopa e pramipexol + levodopa a partir de um ensaio clínico randomizado_head-to-head_. Nesse<br>estudo, não foram identificadas diferenças entre os medicamentos quanto à benefícios clínicos e<br>segurança (mudança no escore de_Unified Parkinson’s Disease Rating Scale_(UPDRS) parte III<br>[avaliação de função motora] e parte II [avaliação de atividades de vida diária],_wearing off_, incidência<br>de eventos adversos gerais e graves e descontinuação do tratamento por eventos adversos), sendo<br>considerados equivalentes clinicamente. A presente análise tem como objetivo analisar a relação entre<br>os custos incrementais da rotigotina + levodopa comparada ao pramipexol + levodopa.|
|**População-alvo**|Pacientes com Doença de Parkinson e sintomas noturnos,_wearing off_ou_freezing_em fase avançada da<br>doença|
|**Perspectiva**<br>**da**<br>**análise**|Sistema Único de Saúde|
|**Comparação**|Pramipexol + levodopa|
|**Horizonte**<br>**temporal**|1 ano|
|**Taxa de desconto**|Não se aplica.|
|**Medida**<br>**de**<br>**efetividade**|Não se aplica.|
|**Estimativa**<br>**de**<br>**efetividade**|Poewe et al., 2007|
|**Estimativa**<br>**de**<br>**custos**|Custos de aquisição dos medicamentos|
|**Moeda**|Real (BRL; R$)|  
49  
|**Modelo escolhido**|Análise de custo-minimização|
|---|---|
|**Análise**<br>**de**|Análise de sensibilidade determinística.|
|**sensibilidade**||  
**Fonte:** elaboração própria.  
Foi observado que a incorporação da rotigotina levaria a um incremento de custo de R$ 3.464,73 em um ano de tratamento (Quadro H).  
**Quadro H** - Resultados da análise de custo-minimização.  
|**Medicamento**|**Custo anual**|**Custo incremental**|
|---|---|---|
|Pramipexol 1 mg + levodopa|R$ 579,47|R$ 3.464,73|
|Rotigotina 13,5 mg + levodopa|R$ 4.044,20||  
**Fonte** : Elaboração própria.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Análise de impacto orçamentário</u>** -->
**Quadro I** - Características da AIO  
|**Título**|Análise de impacto orçamentário da rotigotina para o tratamento de indivíduos com doença de|
|---|---|
||Parkinson e sintomas noturnos,_wearing off_ou_freezing_no Sistema Único de Saúde.|
|**Antecedentes**<br>**e**|Sintomas noturnos,_wearing off_ou f_reezing_são frequentemente reportados em pacientes com|
|**objetivos**|doença de Parkinson, sendo mais comuns em pacientes com doença em estágios mais avançados.<br>O tratamento recomendado pelo Protocolo Clínico e Diretrizes da Doença de Parkinson inclui a<br>utilização de levodopa associada a outras classes medicamentosas, incluindo os agonistas de<br>dopamina não ergolínicos. Atualmente, o único medicamento disponível no SUS pertencente a<br>esta classe de medicamentos é o pramipexol. De acordo com a revisão sistemática apresentada no<br>Material Suplementar 1, pramipexol e rotigotina não apresentam diferenças significativas tanto<br>para melhora destes sintomas quanto em segurança.|
||Entretanto, considerando-se os desafios em se atingir o controle da doença e as variações<br>individuais na resposta ao tratamento a rotigotina pode ser uma opção de tratamento para esses<br>pacientes. Assim, a presente análise de impacto orçamentário (AIO) tem como objetivo avaliar o<br>impacto incremental da incorporação de rotigotina para tratamento de pacientes com doença de<br>Parkinson e sintomas noturnos,_wearing off_ou f_reezing_em adição à levodopa.|
|**População-alvo**|Pacientes com doença de Parkinson e sintomas noturnos,_wearing off_ou_freezing_|
|**Perspectiva de análise**|Sistema Único de Saúde|
|**Comparação**|Cenário referência: Pramipexol + levodopa<br>Cenário alternativo: Rotigotina + levodopa e pramipexol + levodopa|
|**Horizonte mesral**|5 anos|  
50  
|**Taxa de desconto**|Não utilizada, conforme recomendado nas diretrizes metodológicas de análises de impacto<br>orçamentário.|
|---|---|
|**Estimativa de custos**|Na presente análise foram considerados somente os custos de aquisição dos medicamentos. Os|
||custos foram estimados a partir do menor preço pago em compras públicas federais.|
|**Moeda**|Real (R$)|
|**Modelo escolhido**|Estático|
|**Análise**<br>**de**|Foram conduzidas análises de sensibilidade determinísticas unidirecionais e multidirecionais|
|**sensibilidade**||  
A incorporação da rotigotina geraria um impacto orçamentário positivo ao longo de cinco anos (mais de R$ 93 milhões), como pode ser observado na Tabela A.  
**Tabela A** - Impacto orçamentário anual, considerando somente custos de aquisição.  
|**Medicamentos**|**2023**|**2024**|**2025**|**2026**|**2027**|
|---|---|---|---|---|---|
|**Cenário base**||||||
|Pramipexol<br>+<br>levodopa|R$ 10.240.983|R$ 10.712.862|R$ 11.184.742|R$ 11.656.621|R$ 12.128.501|
|Rotigotina<br>+<br>levodopa|R$ 0|R$ 0|R$ 0|R$ 0|R$ 0|
|Total|R$ 10.240.983|R$ 10.712.862|R$ 11.184.742|R$ 11.656.621|R$ 12.128.501|
|**Cenário Proposto**||||||
|Pramipexol<br>+<br>levodopa|R$ 9.216.884|R$ 9.105.933|R$ 8.947.793|R$ 8.742.466|R$ 8.489.950|
|Rotigotina<br>+<br>levodopa|R$ 9.370.499|R$ 14.703.403|R$ 20.468.077|R$ 26.664.521|R$ 33.292.734|
|Total|R$ 18.587.384|R$ 23.809.336|R$ 29.415.871|R$ 35.406.987|R$ 41.782.685|
|**IMPACTO ORÇAM**|<br>**ENTÁRIO INCR**|<br>**EMENTAL**||||
|Total|R$ 8.346.401|R$ 13.096.474|R$ 18.231.129|R$ 23.750.366|R$ 29.654.184|  
**Fonte** : Elaboração própria.  
Ao avaliar a incorporação da rotigotina, um impacto de mais de R$ 93 milhões ao longo de cinco anos foi identificado. Os resultados das análises de sensibilidade determinística variaram entre R$ 35.144.821 e R$ 240.157.907 pela incorporação de **rotigotina** , principalmente devido a variações da população elegível.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Referências</u>** -->
1. LeWitt PA, Lyons KE, Pahwa R. Advanced Parkinson disease treated with rotigotine transdermal system: PREFER Study. Neurology. 2007;68:1262‐1267.  
51  
2. Poewe WH, Rascol O, Quinn N, Tolosa E, Oertel WH, Martignoni E, et al. Efficacy of pramipexole and transdermal rotigotine in advanced Parkinson’s disease: a double-blind, double-dummy, randomised controlled trial. lancet Neurol. 2007;6:513‐520.  
3. Nicholas AP, Borgohain R, Chaná P, Surmann E, Thompson EL, Bauer L, et al. A randomized study of rotigotine  
dose response on “off” time in advanced Parkinson’s disease. J Parkinsons Dis. 2014;4:361‐373.  
4. Nomoto M, Mizuno Y, Kondo T, Hasegawa K, Murata M, Takeuchi M, et al. Transdermal rotigotine in advanced Parkinson’s disease: a randomized, double-blind, placebo-controlled trial. J Neurol. 2014;261:1887‐1893.  
5. Zhang ZX, Liu CF, Tao EX, Shao M, Liu YM, Wang J, et al. Rotigotine transdermal patch in Chinese patients with advanced Parkinson’s disease: a randomized, double-blind, placebo-controlled pivotal study. Parkinsonism Relat Disord. 2017;44:6‐12.  
6. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e, Tecnologia. Diretrizes metodológicas: Diretriz de Avaliação Econômica. 2a edição. Brasília: Ministério da Saúde; 2014.  
7. Husereau D, Drummond M, Augustovski F, de Bekker-Grob E, Briggs AH, Carswell C, et al. Consolidated Health Economic Evaluation Reporting Standards (CHEERS) 2022  Explanation and Elaboration: A Report of the ISPOR CHEERS II Good Practices Task Force. Value Heal  J Int Soc Pharmacoeconomics  Outcomes Res. 2022;25:10–31.  
**Questão 2: Para pacientes com DP responsivos à levodopa e com indicação de terapia combinada, a safinamida associada a um ou mais medicamentos é segura e eficaz em comparação com medicamentos inibidores da MAO associados à levodopa, ou em comparação com tratamento padrão, ou mesmo placebo, mensurada pela escala UPDRS, sintomas de** **_wearing off_ e dor??**  
**Recomendação:** O Protocolo não emitiu recomendação, uma vez que o medicamento não foi avaliado pela Conitec. A comparação entre os medicamentos disponíveis no SUS e esta tecnologia não foi possível por não terem sido identificados estudos de comparação direta ou que possibilitassem a comparação indireta, <mark>que tenham relatados os desfechos elencados pelos especialistas do grupo elaborador do PCDT da Doença de Parkinson. Adicionalmente, a safinamida resultaria em incremento no impacto orçamentário em cinco anos considerando-se os benefícios clínicos limitados. Dessa forma, verificou-se que sua avaliação pela Conitec não seria viável.</mark>

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Método** -->
Foi elaborada uma pergunta de pesquisa segundo o acrônimo PICOS ( **Quadro J** ).  
**Quadro J** - Pergunta PICOS (paciente, intervenção, comparação, _outcomes_ [desfecho] e _study type_ [tipos de estudos]).  
|**População**|Pacientes com DP, responsivos à levodopa e com indicação de terapia combinada|
|---|---|
|**Intervenção**|Safinamida associada a um ou mais medicamentos (especialmente levodopa)|
|**(tecnologia)**||
|**Comparação***|Inibidores da MAO (rasagilina ou selegilina) associados à levodopa<br>Inibidores da COMT (entacapona) associados à levodopa<br>Agonistas de dopamina (amantadina, bromocriptina ou pramipexol) associados à levodopa<br>Tratamento padrão + placebo|  
52  
|**Desfechos**|**Primários:**|
|---|---|
|**(****_Outcomes_)**|Escala UPDRS (escore total e subescores (i.e. II, III e IV, respectivamente, atividades da vida diária|
||on/off, exame motor e complicações da terapia);_wearing off_(relacionado à flutuação) e dor<br>**Secundários:**<br>Eventos adversos|
|**Tipo de estudo (****_Study_**|Ensaios clínicos randomizados e revisões sistemáticas|
|**_type_)**||  
**Legenda:** COMT, catecol-O-metiltransferase; DP, doença de Parkinson; MAO, monoamino-oxidase; UPDRS, _Unified Parkinson's disease rating scale_ . *Considerados somente comparadores disponíveis no SUS, apresentados entre parênteses para maior clareza.  
Com base na pergunta PICO estruturada acima, foi realizada uma busca em agosto de 2022 nas seguintes plataformas: PubMed, EMBASE, LILACS e The Cochrane Library. Para validação da estratégia de busca, uma busca no Epistemonikos e ClinicalTrials.gov foi realizada visando a identificação de potenciais revisões sistemáticas não recuperadas nas bases principais e estudos primários recuperados por essas revisões. O Quadro K detalha as estratégias de busca efetuadas em cada plataforma.  
**Quadro K** - Estratégia de busca nas plataformas consultadas em agosto de 2022.  
|**Plataformas de**<br>**busca**|**Estratégia de busca**|
|---|---|
|**PubMed**|((((((((((((("Parkinson Disease"[Mesh]) OR ("Parkinson Disease"[Title/Abstract])) OR ("Idiopathic<br>Parkinson's Disease")) OR ("Lewy Body Parkinson's Disease")) OR ("Parkinson's Disease, Idiopathic"))<br>OR ("Parkinson's Disease, Lewy Body")) OR ("Parkinson Disease, Idiopathic")) OR ("Parkinson's<br>Disease")) OR ("Idiopathic Parkinson Disease")) OR ("Lewy Body Parkinson Disease")) OR ("Primary<br>Parkinsonism")) OR ("Parkinsonism, Primary")) OR ("Paralysis Agitans")) AND (((((((((((((("safinamide"|
||[Supplementary<br>Concept])<br>OR<br>(safinamide[Title/Abstract]))<br>OR<br>(2-(4-(3-<br>fluorobenzyloxy)benzylamino)propionamide))<br>OR<br>((S)-2-((4-(3-<br>fluorobenzoxy)benzyl)amino)propanamide))<br>OR<br>(safinamide<br>methanesulfonate))<br>OR<br>(fbap<br>methanesulfonate)) OR (NW-1015)) OR (FCE 28073)) OR (FCE-28073)) OR (PNU 151774E)) OR (PNU-<br>151774E)) OR (Xadago)) OR (FCE 26743)) OR (FCE-26743))|
|**EMBASE**|('parkinson disease'/exp OR 'parkinson disease' OR 'lewy bodies of parkinson disease'/exp OR 'lewy bodies<br>of parkinson disease' OR 'lewy bodies of parkinsons disease'/exp OR 'lewy bodies of parkinsons disease'<br>OR 'paralysis agitans'/exp OR 'paralysis agitans' OR 'parkinson dementia complex'/exp OR 'parkinson<br>dementia complex' OR 'parkinsons disease'/exp OR 'parkinsons disease' OR 'primary parkinsonism'/exp<br>OR 'primary parkinsonism') AND ('safinamide'/exp OR 'safinamide' OR 'emd1195686'/exp OR<br>'emd1195686' OR 'equfina'/exp OR 'equfina' OR 'fce26743'/exp OR 'fce26743' OR 'fce28073'/exp OR<br>'fce28073' OR 'me 2125'/exp OR 'me 2125' OR 'nw1015'/exp OR 'nw1015' OR 'onstryv'/exp OR 'onstryv'<br>OR 'pnu151774'/exp OR 'pnu151774' OR 'safinamide mesylate'/exp OR 'safinamide mesylate' OR<br>'safinamide methanesulfonate'/exp OR 'safinamide methanesulfonate' OR 'xadago'/exp OR 'xadago') AND<br>[embase]/lim|
|**LILACS**|((( mh:("Parkinson Disease"))) OR (idiopathic parkinson disease) OR (idiopathic parkinson's disease) OR<br>(lewy body parkinson disease) OR (lewy body parkinson's disease) OR (parkinson disease, idiopathic) OR|  
53  
|**Plataformas de**<br>**busca**|**Estrat**|**égia de busca**|
|---|---|---|
||(parkin<br>(parkin<br>metha|son's disease) OR (parkinson's disease, idiopathic) OR (parkinson's disease, lewy body) OR<br>sonism, primary) OR (primary parkinsonism)) AND ((safinamide) OR (safinamide<br>nesulfonate) OR (fbap methanesulfonate))|
|**_The Cochrane_**|#1|MeSH descriptor: [Parkinson Disease] explode all trees|
|**_Library_**|#2|"Parkinson Disease"|
|**(Apenas**|#3|"Paralysis Agitans"|
|**revisões)**|#4|"Lewy Body Parkinson Disease"|
||#5|"Parkinson's Disease, Lewy Body"|
||#6|"Parkinson's Disease"|
||#7|"Lewy Body Parkinson's Disease"|
||#8|"Idiopathic Parkinson Disease"|
||#9|"Parkinson's Disease, Idiopathic"|
||#10|" Parkinsonism, Primary"|
||#11|"Idiopathic Parkinson's Disease"|
||#12|"Primary Parkinsonism"|
||#13|"Parkinson Disease, Idiopathic"|
||#14|#1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11 OR #12 OR #13|
||#15|safinamide|
||#16|"safinamide methanesulfonate"|
||#17|"fbap methanesulfonate"|
||#18|NW-1015|
||#19|"FCE 28073"|
||#20|FCE-28073|
||#21|"PNU 151774E"|
||#22|PNU-151774E|
||#23|Xadago|
||#24|"FCE 26743"|
||#25|FCE-26743|
||#26<br>#27|#15 OR #16 OR #17 OR #18 OR #19 OR #20 OR #21 OR #22 OR #23 OR #24 OR #25<br>#14 AND #26|  
A extração de dados foi realizada por um único avaliador, por meio planilhas software Microsoft Office Excel®.  Todos os dados extraídos foram conferidos integralmente por um segundo revisor. Os seguintes dados foram obtidos dos estudos:  
i) Características dos estudos e intervenções: número de registro no ClinicalTrials (NCT); acrônimo de identificação; país; número de centros; características gerais da população; alternativas comparadas quanto à dose, frequência e via de administração, tanto para tratamentos ativos, quanto placebo, quando pertinente; cointervenções; desenho do estudo; método de randomização e de sigilo de alocação se estudo randomizado; equilíbrio das características de baseline; cegamento de  
54  
participantes; análise por intenção de tratar - intention-to-treat analysis (ITT); desvios e desequilíbrio de cointervenções; desfechos incompletos; cegamento do avaliador; e reporte seletivo de resultado. Sempre que pertinente, as informações relativas ao risco de viés dos estudos foram extraídas segundo desfecho;  
ii) Características dos participantes: número de participantes por alternativa comparada, segundo sexo, idade, duração da doença, estágio H&Y, tempo total médio diário sem discinesia ou sem discinesia problemática e UPDRS-III;  
iii) Desfechos e resultados: definição e time-point de avaliação do desfecho e resultados por alternativa para cada desfecho. Para desfechos contínuos: média, desvio-padrão (DP), n e valor de p; e para desfechos dicotômicos: n com evento, n com a alternativa (população ITT ou por protocolo [PP], a depender do reportado), odds ratio (OR), risco relativo (RR), intervalo de confiança (IC) ou valor de p. Para obtenção desses parâmetros, em alguns casos, foi necessário recorrer a cálculos, imputações e deduções (i.e., conversão de IC ou erro-padrão em DP, cálculo do DP da diferença a partir dos DP de início e final de tratamento ou ainda obtenção de dados gráficos pelo WebPlotDigitizer.  
A síntese e análise dos dados foi feita por representação individual dos estudos, meta-análises diretas e em rede. Para condução das meta-análises, avaliação de homogeneidade e transitividade foi realizada por meio da comparação do acrônimo PICO de cada estudo (critérios de inclusão e exclusão da população, definições de subpopulações, intervenção e controles e definições dos desfechos). Sendo identificadas discrepâncias importantes, elas foram discutidas como potenciais limitações das meta-análises. A seguir apresentamos as principais características de cada síntese e análise, segundo tipo:  
 Síntese e representação individual dos resultados: As características do estudo, características dos participantes, resultados individuais e avaliação da qualidade dos estudos incluídos foram apresentadas de forma narrativa e a estatística descritiva (frequência absoluta e relativa, média e DP ou mediana e intervalo interquartil [IIQ]), incluindo tabelas para o auxílio na apresentação dos resultados. Os resultados narrativos foram agrupados por desfecho, fazendo destaque às alternativas comparadas. Para avaliação da heterogeneidade, métodos informais foram utilizados considerando inspeção visual de tabelas de características e resultados e potenciais modificadores de efeito.  
 Meta-análises diretas: Meta-análises diretas foram conduzidas no software Review Manager. Para as meta-análises tradicionais de desfechos dicotômicos, foram calculadas medidas de efeito como odds ratio (OR), com intervalos de confiança de 95% (IC 95%), usando o método estatístico Mantel-Haenszel. Os desfechos contínuos foram analisados por diferença de média ± desvio padrão. Resultados foram apresentados em figuras. Análises de subgrupo por estágio da doença / associação de medicamentos [inicial (safinamida + DA) e intermediário ou avançado (safinamida + levodopa)] foram previstas; análises de sensibilidade seriam realizadas para explorar heterogeneidade substancial ou considerável nas análises.  
 Meta-análises indireta e em rede: Meta-análises indiretas e em rede foram conduzidas no aplicativo da web Confidence In Network Meta-Analysis (CINEMA), considerando abordagem frequentista. As redes foram elaboradas considerando os diferentes tratamentos como os “nós”, conectados por linhas que representam as evidências diretas existentes na literatura. Inconsistência entre as evidências geradas por comparações diretas e indiretas seria realizada para redes com circuitos fechados e cálculo de valor de p para diferença entre as estimativas. Entretanto, pela inexistência de redes com circuitos fechados, essas análises não foram viáveis. Análises de subgrupo ou sensibilidade não foram planejadas para meta-análises indiretas e em rede, tendo em vista que a retirada de estudos impactaria em desconexão das redes. Os resultados foram expressos segundo RR e IC.  
Para a avaliação do risco de viés dos ensaios clínicos randomizados foi utilizada a ferramenta Risk of Bias (RoB 2.0). Como preconizado pela ferramenta, a avaliação foi feita no nível do estudo, do desfecho e do resultado, quando pertinente. A qualidade metodológica das revisões sistemáticas foi feita por meio da ferramenta Assessing the Methodological Quality of  
55  
Systematic Reviews (AMSTAR-2). Embora a ferramenta não tenha sido desenvolvida para avaliação de revisões sistemáticas com meta-análise em rede, na inexistência de uma ferramenta validada, optou-se por utilizá-la, apesar das limitações.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Estudos selecionados** -->
Foram recuperadas 796 publicações nas bases de dados consultadas, restando 554 após remoção de duplicatas identificadas eletronicamente. Durante a seleção, 538 registros foram considerados irrelevantes na triagem e 5 foram excluídos na etapa de leitura na íntegra. Dois estudos seriam potencialmente elegíveis para inclusão, correspondendo ao estudo principal e a sua extensão, registrados sob códigos diferentes no ClinicalTrials.Gov (MOTION; NCT00605683, NCT01028586). Entretanto, o primeiro, embora finalizado, não foi publicado e seus resultados não estão disponíveis na plataforma de registro; e o segundo, foi interrompido por um dos financiadores.  
Dessa forma, 10 registros foram incluídos, referentes nove estudos (duas revisões sistemáticas com meta-análise, seis ensaios clínicos randomizados e um estudo de extensão), registrados sob códigos distintos ClinicalTrials.Gov.  
**Figura C** - Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
Registros Registros _removidos Registros identificados<br>PubMed (n = 189) »| — Registros duplicados Websites (n= 0)<br>E identificados de: antes da triagem: de:<br>rf EmbaseCochrane (n(n= = 533)1.74) removidoseletronicamente (n = OrganizacéesPesquisa de citacdes (n = 0)<br>242) (a=0)<br>Registros triados Registros excluidos<br>(n= 554) (a= 538)<br>3 Registros procurados para ae<br>recuperacaomnperags ® RegistroPee ndo recuperado Registrospara recuperaco_procurados Registrosrecuperados no<br>(n= 16) (n=0) (n=0)<br>| Registro avaliados para Registros avaliados para Registros<br>| clegibitidade(a=14) |>| Resistros excluidos (n= | | clesibilidade excluidos<br>3) (a=0) (a=0)<br>2 Registros incluidos no PTC<br>| (n= 10)<br>3 Estudos(n=9) incluidos no PTC<br><!-- End of picture text -->  
56

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Efeitos desejáveis da tecnologia</u>** -->
O desfecho primário foi a escala UPDRS (escore total e subescores de atividades da vida diária [parte II], exame motor [parte III] e complicações da terapia [parte IV]), _wearing off_ e dor.  
Para pacientes com **DP em fase inicial** foi identificada redução significativa do escore II somente para os pacientes que receberam safinamida 100 mg/dia + agonista dopaminérgico (DA) comparado ao placebo + DA (p=0,0248) em 24 semanas<sup>13</sup> . Em 12 meses, não foi observada diferença entre safinamida (100 e 200 mg agrupados) + DA e placebo + DA (p=0,2997)<sup>14</sup> .  
Foi realizada meta-análise de dois estudos que relataram os resultados do subescore II para pacientes com DP intermediária a avançada (safinamida + levodopa) e verificou-se que não houve diferença estatisticamente significativa entre os pacientes que receberam safinamida e placebo (DM: -0,64; IC95%: -1,31 a 0,02), ambos associados à levodopa.  
Considerando-se a totalidade dos estudos, independentemente da associação ou estágio da doença considerado, safinamida proporcionou redução significativa no escore de UPDRS-II (DM: -0,58; IC 95%: - 1,04 a -0,11).  
Já as meta-análises conduzidas para avaliar o subscore III foram estratificadas em subgrupos por **DP em fase inicial** (safinamida + DA) ou **intermediária a avançada** (safinamida + levodopa). Em ambos os grupos houve uma redução maior, estatisticamente significante, nos pacientes em uso de safinamida, comparado ao placebo - fase inicial: DM: -2,83 (IC95%: -5,16 a -0,50); fase intermediária a avançada: DM: -2,77 (IC95%: -4,27 a -1,28). Contudo, foi verificada uma alta heterogeneidade no último subgrupo _I_<sup>2</sup> = 69%, valor de p= 0,04.  
Apenas um estudo relatou os resultados do subescore UPDRS-IV, não tendo sido encontrada diferença entre safinamida (100 ou 200 mg/dia) + DA vs. placebo + DA em pacientes com DP em fase inicial. A DM foi de -0,08, com IC 95%: -0,25 a 0,09 e valor de p: 0,3364<sup>14</sup> .  
Três estudos relataram resultados do escore total de UPDRS em pacientes com DP em estágio **intermediário a avançado** e puderam ser sintetizados quantitativamente. Os resultados da meta-análise não revelaram diferenças entre a safinamida + levodopa e o placebo + levodopa na redução do UPDRS total (DM: 0,03 (IC95%: -0,31 a 0,36)).  
Dois estudos que incluíram pacientes com DP intermediária a avançada relataram que a safinamida +levodopa reduziu significativamente o tempo de _wearing off_ comparado ao placebo + levodopa em 24 semanas de tratamento<sup>4,5</sup> .  
O desfecho dor foi relatado somente na revisão sistemática de Qureshi et al., 2018<sup>15</sup> [15], em que se observou que as maiores reduções na dor foram encontradas com o tratamento da safinamida quando comparada ao placebo (diferença média padronizada = –4,83, IC 95% [–5,07 a –4,59], p < 0,0001).  
Em meta-análise em rede atualizada a partir das análises de Binde et al., 2020<sup>16</sup> , considerando-se somente os resultados de comparação entre safinamida e medicamentos disponíveis no SUS (entacapona, pramipexol, selegilina e rasagilina), não foi observada diferença na proporção de respondedores segundo as escalas UPDRS-III (exame motor) ou CGI entre safinamida e entacapona (RR: 0,985; IC 95%: 0,617 a 1,571) ou rasagilina (RR: 0,921; IC 95%: 0,652 a 1,299), mas safinamida foi superior à selegilina (RR: 1,540, IC 95%: 1,011 a 2,345) e inferior a pramipexol (RR: 0,696; IC 95%: 0,507 a 0,955).  
Os resultados podem ser vistos nas **Tabelas B a D** .  
57  
**Tabela B -** Resultados para desfechos de eficácia priorizados extraídos a partir dos ensaios clínicos randomizados com safinamida.  
|**Estudo**|**_Time-point_**|**Alternativa**|**N**|**Média**|**DP**|**DM**|**Valor p**|**IC95%**|
|---|---|---|---|---|---|---|---|---|
|**Mudança no escore total U**|**PDRS parte I**|**II**|||||||
|NCT00643045||Safinamida 100 mg/dia +DA|90|-6,00|7,18|-1,9|0,419 vs. placebo|-3,7 a -0,1|
|Trial 015|Semana 24|Safinamida 200 mg/dia +DA|89|-3,90|6,01|-0,4|0,65 vs. placebo|-2,3 a -1,4|
|Stocchi et al., 2012||Placebo + DA|90|-3,60|7,08|-|-|-|
|NCT00642889||Safinamida 100 ou 200 mg/dia +DA|149|-3,0|7,80|-1,27|0,1893 vs. placebo|-3,18 a 0,63 vs. placebo|
|Trial 017<br>Schapira et al., 2013|Mês 12|Placebo + DA|78|-1,7|6,35|-|-|-|
|NCT01187966<br>Trial 016|Semana 24|Safinamida 50 mg/dia + levodopa|223|mudança: -6,1|NR|MMQ: -1,8|0,0138 vs placebo|-3,3 a -0,4<br>vs placebo|
|<br>Borohain et al 2014||Safinamida 100 mg/dia + levodopa|224|mudança: -6,9|NR|-2,6|0,0006 vs placebo|-4,1 a -1,1 vs placebo|
|g  .,||Placebo + levodopa|222|mudança: -4,3|NR|-|-|-|
|NCT00627640<br>SETTLE|Semana 24|Safinamida 100 mg+ levodopa|274|–3,43|7,72|–1,82|0,003 vs placebo|–3,01 a –0,62 vs placebo|
|Schapira et al., 2017||Placebo + levodopa|275|–1,83|8,23|-|-|-|
|JapicCTI-153056||Safinamida 50 mg/dia + levodopa|131|MMQ: - 5,24|EP: 0,53|MMQ<br>- 4,06|<0,0001 vs. placebo|-5,54 a -2,59|
|<br>Hattori et al., 2020|Semana 24|Safinamida 100 mg/dia + levodopa|128|MMQ: -5,35|EP: 0,53|MMQ:<br>- 4,18|<0,0001 vs. placebo|-5,66 a -2,69|
|||Placebo + levodopa|136|MMQ: -1,17|EP: 0,53|-|-|-|
|EudraCT 2017-003254-17|24 semanas|Safinamida 100 mg + DA|15|-3,6|8,0|−6,14|0,094 vs. placebo|(−13,4 a 1,11) vs. placebo|
|Kulisevsky et al., 2022||Placebo + DA|15|2,5|10,5|-|-|-|
|**Mudança no escore total U**|**PDRS parte I**|**I**|||||||
|NCT00643045|Semana 24|Safinamida 100 mg/dia +DA|90|-2,2|NR|NR|0,0248 vs. placebo|NR|  
58  
|**Estudo**|**_Time-point_**|**Alternativa**|**N**|**Média**|**DP**|**DM**|**Valor p**|**IC95%**|
|---|---|---|---|---|---|---|---|---|
|Trial 015||Safinamida 200 mg/dia +DA|89|-1,4|NR|NR|NS|NR|
|Stocchi et al., 2012||Placebo + DA|90|-1,2|NR|-|-|-|
|NCT00642889||Safinamida 100 ou 200mg/dia +DA|149|-1,1|3,37|0,47|0,2997 vs placebo|-1,36 a 0,42 vs placebo|
|Trial 017<br>Schapira et al., 2013|Mês 12|Placebo + DA|78|-0,8|4,18|-|-|-|
|NCT01187966||Safinamida 50 mg/dia + levodopa|223|-1,7|NR|NR|0,1253<br>vs. placebo|-1,2 a 0,2<br>vs placebo|
|Trial 016<br>Borgohain et al., 2014|Semana 24|Safinamida 100 mg/dia + levodopa|224|-2,2|NR|NR|0,0060<br>vs. placebo|-1,7 a -0,3<br>vs. placebo|
|||Placebo + levodopa|222|-1,2|NR|-|-|-|
|NCT00627640||Safinamida 100 mg/dia+ levodopa|274|-1,07|3,63|-0,43|0,15 vs placebo|-1,02 a 0,16 vs placebo|
|SETTLE<br>Schapira et al., 2017|Semana 24|Placebo + levodopa|275|-0,75|3,95|-|-|-|
|**Mudança no escore total**|**UPDRS parte I**|**V**|||||||
|NCT00642889<br>Trial 017|Mês 12|Safinamida 100 ou 200 mg/dia +DA|149|-0,1|(0,74)|-0,08|0,3364 vs placebo|-0,25 a 0,09<br>vs placebo|
|Schapira et al., 2013||Placebo + DA|78|-0,2|(0,77)|-|-|-|
|**Mudança no escore total**|**UPDRS**||||||||
|NCT01187966||Safinamida 50 mg/dia + levodopa|223|-0,3|2,52|NR|0,2431 vs placebo|NR|
|Trial 016|Semana 24|Safinamida 100 mg/dia + levodopa|224|-0,3|3,13|NR|0,1812 vs placebo|NR|
|Borgohain et al., 2014||Placebo + levodopa|222|-0,2|2,16|-|-|-|
|NCT01286935|Mê 24|Safinamida 50 mg/dia + levodopa|223|NR|NR|-0,51|NS|-1,32 a 0,29 vs placebo|
|Trial 018|s|Safinamida 100 mg/dia + levodopa|224|NR|NR|-0,59|NS|-1,40 a 0,21 vs placebo|  
59  
|**Estudo**|**_Time-point_**|**Alternativa**|**N**|**Média**|**DP**|**DM**|**Valor p**|**IC95%**|
|---|---|---|---|---|---|---|---|---|
|Borgohain et al., 2014||Placebo + levodopa|222|NR|NR|-|-|-|
|NCT00627640<br>||Safinamida 100 mg/dia + levodopa|274|-0,11|2,86|+0,23|0,22 vs placebo|–0,14 a +0,60 vs placebo|
|SETTLE<br>Schapira et al., 2017|Semana 24|Placebo + levodopa|275|-0,24|2,50|-|-|-|
|**_Wearing off_**|||||||||
|NCT01187966||Safinamida 50 mg/dia + levodopa|223|-1,1h|NR|-0,5h|0,0031 vs placebo|-0,9 a -0,2|
|Trial 016|Semana 24|Safinamida 100 mg/dia + Levodopa|224|-1,2h|NR|-0,6h|0,0011 vs placebo|-1,0 a -0,2|
|Borgohain et al., 2014||Placebo + Levodopa|222|-0,6h|NR|-|-|-|
|NCT00627640||Safinamida 100 mg/dia + levodopa|274|-0,26|0,59|-0,18h|<0,001 vs placebo|-0,28 a -0,09 vs placebo|
|SETTLE<br>Schapira et al., 2017|Semana 24|Placebo + levodopa|275|-0,09|0,79|-|-|-|  
**Legenda:** EP, erro padrão; h, horas; IC, intervalo de confiança; pts, pacientes; MMQ, média dos mínimos quadrados; n ou N, número; NR, não reportado; NS, não significativo; RR, risco relativo; vs, versus.  
*avaliados por escala UPDRS ou CGI  
60  
**Tabela C -** Proporção de respondedores segundo escala UPDRS-III (exame motor) e CGI extraídas a partir dos ensaios clínicos randomizados com safinamida.  
|**Estudo**|**_Timepoint_**|**Alternativa**|**N**|**UPDRS-II**<br>|**I**<br>|**CGI**||
|---|---|---|---|---|---|---|---|
|||||**N**|**%**|**n**|**%**|
|NCT00643045||Safinamida 100 mg/dia +DA|90|33|38%|56|62%|
|Trial 015|Semana 24|Safinamida 200 mg/dia +DA|89|31|36%|52|58%|
|Stocchi et al., 2012||Placebo + DA|90|22|25%|43|48%|
|NCT00642889||Safinamida 100 ou 200 mg/dia +DA|149|47|31,5%|NR|NR|
|Trial 017<br>Schapira et al., 2013|Mês 12|Placebo + DA|78|18|23,1%|NR|NR|
|NCT01187966||Safinamida 50 mg/dia + levodopa|223|NR|NR|148|66,4%|
|Trial 016|Semana 24|Safinamida 100 mg/dia + levodopa|224|NR|NR|144|64,3%|
|Borgohain et al., 2014||Placebo + levodopa|222|NR|NR|123|55,4%|
|NCT00627640<br>SETTLE|Semana 24|Safinamida 100 mg/dia + levodopa|274|NR|NR|158|57,7%|
|Schapira et al., 2017||Placebo + DA|275|NR|NR|115|41,8%|
|JaicCTI-153056||Safinamida 50 mg/dia + levodopa|131|59|45,0%|NR|NR|
|p<br>Hattori et al 2020|Semana 24|Safinamida 100 mg/dia + levodopa|128|54|42,2%|NR|NR|
|.,||Placebo + levodopa|136|23|16,9%|NR|NR|  
**Legenda:** CGI, Escala de Impressão Clínica Global; DA, agonista de dopamina; NR, não reportado; UPDRS, escala unificada de avaliação da doença de Parkinson.  
61  
**Tabela D -** Resultados reportados nas revisões sistemáticas incluídas sobre safinamida.  
|**Estudo**|**Alternativa**|**Dor**|**Respondedores segundo**<br>**CGI ou UPDRS**<sup>**†**</sup>|**Eventos adversos graves**|**Descontinuação por**<br>**eventos adversos**|
|---|---|---|---|---|---|
||Safinamida vs. placebo|ES: -4,83; IC 95%: -5,07 a -<br>4,59|NR|NR|NR|
|Qureshi et al., 2018 *|DA vs. placebo|ES: -0,27, IC 95%: -0,38 a -<br>0,15|NR|NR|NR|
||iCOMT vs. placebo|ES: -1,81; IC 95%: -1,94 a -<br>1,67|NR|NR|NR|
||Safinamida vs. placebo|NR|1,179; IC 95%:  1,031 a<br>1,352|1,043; IC 95%: 0,837 a 1,343|1,113; IC 95%: (0,782 a<br>1,571|
||Rasagilina vs. placebo|NR|1,584; IC 95%: 1,379 a 1,82|1,052; IC 95%: 0,812 a 1,405|0,903; IC 95%: 0,690 a<br>1,201|
|Binde et al., 2020*|Selegilina vs. placebo|NR|2,316; IC 95%: 1,819 a 2951)|1,045; IC 95%: 0,818 a 1,394|0,955; IC 95%: 0,774 a<br>1,159|
||Pramipexol vs. placebo|NR|2,091; IC 95%: 1,889 a 2,317|1,034; IC 95%: 0,806 a<br>1,337|0,616; IC 95%: 0,524 a<br>0,72|
||Rotigotina vs.placebo|NR|1,912; IC 95%: 1,716 a 2,129|1,030; IC 95%: (0,791 a<br>1,352|0,809; IC 95%: 0,690 a<br>0,945|  
**Legenda:** DA, agonistas de dopamina, ES, tamanho de efeito; IC 95%, intervalo de confiança de 95%; iCOMT, inibidores da <mark>catecol-O-metiltransferase, NR, não reportado.</mark><sup>†</sup> Proporção de respondedores de acordo com a escala UPDRS (redução de pelo menos 20% em relação à linha de base) ou CGI (minimamente melhor, muito melhor ou muitíssimo melhor). <mark>*Apresentadas somente as comparações de interesse para o presente PTC.</mark>  
62  
A **Figura D** ilustra a probabilidades de um medicamento ser melhor que outro em relação aos respondedores (avaliados pela escala CGI ou UPDRS).  
**Figura D** - Probabilidades de que um medicamento seja melhor que outro em relação aos respondedores (avaliados pela escala CGI ou UPDRS), em um modelo sem nível de dose, duração da doença ou duração do estudo.  
<!-- Start of picture text -->
PRA+LD ROP+LD ROT+LD CAB+LD RA+LD EN+LD SA+LD<br>SE+LD 0.76 ost 0.92 0.93 1 1 1<br>PRA+LD - 0.64 0.94 0.89 1 1 1<br>ROP+LD - - 0.83 0.86 1 1 1<br>ROT+LD 0.78 0.98 0.99 1<br>CAB+LD 0.56 0.76 0.94<br>RA+LD 0.87 1<br>EN+LD - 0.94<br><!-- End of picture text -->  
**Legenda:** RA, rasagilina; EM, safinamida; SE, selegilina; CAB, cabergolina; PRA, pramipexol; ROP, ropinirole; ROT, rotigotina; LD, levodopa; EM, entacapona  
**Fonte:** Binde et al., 2020

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Efeitos indesejáveis da tecnologia</u>** -->
Em meta-análise que comparou a proporção de pacientes com eventos adversos no grupo safinamida vs. placebo não houve diferença estatisticamente significante entre a safinamida e placebo, tanto no subgrupo de **pacientes com DP inicial** (safinamida + DA, OR: 1,04; IC95: 0,58 a 1,85), quanto no **subgrupo com DP intermediário a avançado** (safinamida + levodopa, OR: 0,95; IC 95%: 0,77 a 1,18).  
Considerando-se pacientes com DP em estágio inicial, menor proporção de pacientes que recebeu safinamida 100 mg/dia + DA apresentaram eventos adversos graves em 24 semanas quando comparados ao grupo safinamida 200 mg/ dia + DA e placebo + DA (2,2%, 10,1% e 6,5%, respectivamente)<sup>13</sup> . Em contraste, com 12 meses de tratamento, maior proporção de pacientes no primeiro grupo apresentou este desfecho quando comparado aos demais grupos (10%, 7,2% e 6,4%, respectivamente)<sup>14</sup> .  
Em meta-análise que comparou a proporção de pacientes com eventos adversos graves em **pacientes com DP intermediária a avançada** evidenciou que não houve diferença estatisticamente significante entre a safinamida + levodopa e placebo + levodopa (OR: 0,81; IC 95%:0,54 a 1,20)). Quando comparada indiretamente aos comparadores disponíveis no SUS (entacapona, rasagilina, selegilina e pramipexol) em meta-análises em rede, a safinamida não apresentou diferenças estatisticamente significantes.  
Em meta-análise que comparou safinamida a placebo observou-se que, para o desfecho descontinuação por eventos adversos, não houve diferença estatisticamente significante entre a safinamida e placebo, tanto no subgrupo de **pacientes com DP inicial** (safinamida + DA, OR: 1,28; IC95: 0,31 a 5,29), quanto no **subgrupo com DP intermediário a avançado** (safinamida + levodopa, OR: 0,94; IC 95%: 0,59 a 1,49).  
Similarmente, a meta-análise em rede atualizada evidenciou que não houve diferença significativa na descontinuação por eventos adversos graves entre safinamida e entacapona, rasagilina, selegilina e pramipexol, comparadores disponíveis no SUS.  
Os resultados de segurança extraídos dos estudos podem ser vistos na **Tabela E** .  
63  
**Tabela E** - Resultados para desfechos relativos à segurança da safinamida.  
|**Estudo**|**_Time-point_**|**Alternativa**|**n pts com evento**|**N pts total**|**% com evento**|**Valor de p**|
|---|---|---|---|---|---|---|
|**Descontinuação de tratamento**<br>|**devido a evento ad**|**verso**<br>|||||
|NCT00643045||Safinamida 100 mg/dia +DA|1|90|10%|NR|
|Trial 015|Semana 24|Safinamida 200 mg/dia +DA|3|89|21,3%|NR|
|Stocchi et al., 2012||Placebo + DA|2|90|10%|NR|
|NCT00642889||Safinamida 100 mg/dia + DA|3|80|3,8%|NR|
|Trial 017|Mês 12|Safinamida 200 mg/dia + DA|2|69|2,9%|NR|
|Schapira et al., 2013||Placebo + DA|3|78|3,8%|NR|
|NCT01187966||Safinamida 50 mg/dia + levodopa|11|223|4,9%|NR|
|Trial 016|Semana 24|Safinamida 100 mg/dia + levodopa|14|224|6,3%|NR|
|Borgohain et al., 2014||Placebo + levodopa|12|222|5,4%|NR|
|NCT01286935||Safinamida 50 mg/dia + levodopa|10|189|5,3%|NR|
|Trial 018|Mês 24|Safinamida 100 mg/dia + levodopa|12|180|6,7%|NR|
|Borgohain et al., 2014||Placebo + levodopa|10|175|5,7%|NR|
|NCT00627640<br>SETTLE|Semana 24|Safinamida 100 mg/dia + levodopa|12|274|4,4%|NR|
|Schapira et al., 2017||Placebo + levodopa|10|275|3,6%|NR|
|JapicCTI-153056||Safinamida 50 mg/dia + levodopa|6|133|4,5%|NR|
|<br>Hattori et al 2020|Semana 24|Safinamida 100 mg/dia + levodopa|6|132|4,5%|NR|
|.,||Placebo + levodopa|10|141|7,1%|NR|
|EudraCT 2017-003254-17|Semana 24|Safinamida 100 mg/dia + DA|2|15|13,3%|NR|
|Kulisevsky et al., 2022||Placebo + DA|1|15|6,7%|NR|
|**Pacientes com evento adverso**|**grave**||||||  
64  
|**Estudo**|**_Time-point_**|**Alternativa**|**n pts com evento**|**N pts total**|**% com evento**|**Valor de p**|
|---|---|---|---|---|---|---|
|NCT00643045||Safinamida 100 mg/dia +DA|2|90|2,2%|NR|
|Trial 015|Semana 24|Safinamida 200 mg/dia +DA|9|89|10,1%|NR|
|Stocchi et al., 2012||Placebo + DA|6|90|6,5%|NR|
|NCT00642889||Safinamida 100 mg/dia + DA|8|80|10,0%|NR|
|Trial 017|Mês 12|Safinamida 200 mg/dia + DA|5|69|7,2%|NR|
|Schapira et al., 2013||Placebo + DA|5|78|6,4%|NR|
|NCT01187966||Safinamida 50 mg/dia + levodopa|8|223|3,6%|NR|
|Trial 016|Semana 24|Safinamida 100 mg/dia + levodopa|22|224|9,8%|NR|
|Borgohain et al., 2014||Placebo + levodopa|18|222|8,1%|NR|
|NCT01286935||Safinamida 50 mg/dia + levodopa|32|189|16,9%|NR|
|Trial 018|Mês 24|Safinamida 100 mg/dia + levodopa|34|180|18,9%|NR|
|Borgohain et al., 2014||Placebo + levodopa|28|175|16,0%|NR|
|NCT00627640<br>SETTLE|Semana 24|Safinamida 100 mg/dia + levodopa|18|274|6,6%|NR|
|Schapira et al., 2017||Placebo + levodopa|26|275|9,5%|NR|
|JiCTI153056||Safinamida 50 mg/dia + levodopa|8|133|6,0%|NR|
|apc-<br>Hattori et al 2020|Semana 24|Safinamida 100 mg/dia + levodopa|7|132|5,3%|NR|
|.,||Placebo + levodopa|7|141|5,0%|NR|
|**Pacientes com evento adverso**|||||||
|NCT00642889||Safinamida 100 mg/dia + DA|61|80|76,3%|NR|
|Trial 017|Mês 12|Safinamida 200 mg/dia + DA|42|69|60,9%|NR|
|Schapira et al., 2013||Placebo + DA|54|78|69,2%|NR|  
65  
|**Estudo**|**_Time-point_**|**Alternativa**|**n pts com evento**|**N pts total**|**% com evento**|**Valor de p**|
|---|---|---|---|---|---|---|
|NCT01187966||Safinamida 50 mg/dia + levodopa|147|223|65,9%|NR|
|NCT01187966|Semana 24|Safinamida 100 mg/dia + levodopa|147|224|65,6%|NR|
|Trial 016<br>Borgohain et al., 2014||Placebo + levodopa|152|222|68,5%|NR|
|NCT01286935||Safinamida 50 mg/dia + levodopa|168|189|88,9%|NR|
|Trial 018|Mês 24|Safinamida 100 mg/dia + levodopa|163|180|90,6%|NR|
|Borgohain et al., 2014||Placebo + levodopa|160|175|91,4%|NR|
|NCT00627640||Safinamida 100 mg/ dia+ levodopa|186|274|67,9%|NR|
|SETTLE|Semana 24||||||
|Schapira et al., 2017||Placebo + levodopa|190|275|69,1%|NR|
|aicCTI-153056||Safinamida 50 mg/dia + levodopa|80|133|60,2%|NR|
|p<br>Hattori et al 2020|Semana 24|Safinamida 100 mg/dia + levodopa|81|132|61,4%|NR|
|.,||Placebo + levodopa|83|141|58,9%|NR|
|EudraCT 2017-003254-17|Semana 24|Safinamida 100 mg/dia + DA|2|15|13,3%|NR|
|Kulisevsky et al., 2022||Placebo + DA|1|15|6,7%|NR|  
**Legenda:** DA, agonista de dopamina; pts: pacientes; n ou N: número; NR: não reportado.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Qualidade geral da evidência** -->
A qualidade variou de moderada a alta para os desfechos de eficácia (UPDRS partes II e III, dor e _wearing off_ ) e foi baixa para os desfechos de segurança na comparação entre safinamida e placebo ( **Quadro L** ). Os principais motivos para rebaixamento da qualidade da evidência foram inconsistência, risco de viés e imprecisão.  
A qualidade da evidência proveniente de comparações indiretas entre safinamida e os comparadores disponíveis no SUS (pramipexol, entacapona, rasagilina e selegina) variou de baixa a muito baixa para os desfechos de eventos adversos graves ( **Quadro M** ) e descontinuação por eventos adversos ( **Quadro N** ). As principais razões para rebaixamento da qualidade foram imprecisão, incoerência e heterogeneidade.  
66  
**Quadro L -** Avaliação da qualidade da evidência para a comparação safinamida vs. placebo (GRADE).  
|**Avaliação**|**da certeza**||||||**№ de pacient**|**es**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Safinamida**<br>**100 mg/dia**|**Placebo**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importân**<br>**cia**|

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Mudança no escore total UPDRS parte III em 6-12 meses (safinamida vs. placebo)** -->
|5|ensaios clínicos<br>randomizados|não<br>grave|grave<sup>a</sup>|não grave<br>não grave|Nenhum|880|816|-<br>MD**2.79 menor**<br>(3.93 menor para<br>1.65 menor)|⨁⨁⨁◯<br>Moderada|Crítico|
|---|---|---|---|---|---|---|---|---|---|---|
|**Mudan**<br>3|**ça no escore total U**<br>ensaios clínicos<br>randomizados|**PDRS p**<br>não<br>grave|**arte II (safinam**<br>não grave|**ida vs. placebo)**<br>não grave<br>não grave|Nenhum|737|665|-<br>MD**0.58 menor**<br>(1.04 menor para<br>0.11 menor)|⨁⨁⨁⨁<br>Alta|Important<br>e|

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Wearing off (safinamida vs. placebo)** -->
67  
|**Avaliaçã**|**o da certeza**||||||**№ de pacientes**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Safinamida**<br>**100 mg/dia**<br>**Placebo**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importân**<br>**cia**|
|2|ensaios clínicos<br>randomizados|não<br>grave|grave<sup>b</sup>|não grave|não grave|Nenhum|Em 24 semanas, dois e<br>significativa de_weari_<br>safinamida<br>quando<br>independentemente da d<br>al., 2014 reportou difere<br>dose de 100 mg/dia, enq<br>al., reportou redução de<br>Heterogeneidade clínic<br>impedindo agrupar os da|studos evid<br>_ng off_em<br>comparado<br>ose conside<br>nça média d<br>uanto o est<br>0,18 horas c<br>a importan<br>dos em met|enciaram redução<br>horas no grupo<br> <br>ao<br>placebo,<br>rada. Borgohain et<br>e -0,6 horas para a<br>udo de Schapira et<br>om a mesma dose.<br>te foi observada,<br>a-análise.|⨁⨁⨁◯<br>Moderada|Important<br>e|
|**Eventos**<br>4|**adversos graves (s**<br>ensaios clínicos<br>randomizados|**afinamid**<br>grave<sup>c</sup>|**a vs. placebo)**<br>não grave|não grave|grave<sup>d</sup>|nenhum|74/1163<br>(6.4%)<br>57/728<br>(7.8%)|**OR 0.82**<br>(0.57<br>para<br>1.18)|**13 menos por**<br>**1.000**<br>(de 32 menos<br>para 13 mais)|⨁⨁◯◯<br>Baixa|Críitco|  
**Descontinuação de tratamento devido a eventos adversos (safinamida vs. placebo)**  
68  
|**Avaliação**|**da certeza**||||||**№ de pacien**|**tes**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Safinamida**<br>**100 mg/dia**|**Placebo**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importân**<br>**cia**|
|5|ensaios clínicos<br>randomizados|grave<sup>c</sup>|não grave|não grave|grave<sup>d</sup>|nenhum|55/1180<br>(4.7%)|35/743<br>(4.7%)|**OR 0.97**<br>(0.62<br>para<br>1.50)|**1**<br>**menos**<br>**por**<br>**1.000**<br>(de 17 menos<br>para 22 mais)|⨁⨁◯◯<br>Baixa|Crítico|
|**Dor (safi**<br>1|**namida vs. placeb**<br>ensaios clínicos<br>randomizados|**o)**<br>grave<sup>e</sup>|não grave|não grave|não grave|nenhum|A meta-análi<br>safinamida<br>padronizada<br>0,0001, sem|se de Qure<br>a placebo<br>= –4,83, I<br>heterogenei|shi et a., 20<br>evidenciou<br>C 95% [–5<br>dade estatís|18, que comparou<br>diferença média<br>,07 a –4,59], p <<br>tica significante.|⨁⨁⨁◯<br>Moderada|Important<br>e|  
**CI:** Confidence interval; **MD:** Mean difference; **OR:** Odds ratio

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Wearing off (safinamida vs. placebo)** -->
a. Heterogeneidade substancial (I<sup>2</sup> =47%), reduzida a 0% quando retirado o estudo de Hattori et al., 2020, que incluiu somente pacientes japoneses.  
b. Heterogeneidade clínica importante entre participantes dos estudos  
c. Dois estudos (Stocchi et al., 2012 e Schapira et al., 2013) apresentaram algumas preocupações no domínio de desvio das intervenções pretendidas.  
d. Intervalo de confiança de 95% contempla benefício e dano  
69  
**Quadro M** - Avaliação da qualidade da evidência para o desfecho de eventos adversos graves nos estudos com safinamida e os comparadores disponíveis no SUS (adaptado da ferramenta CINeMA).  
|**Comparação**|**Número de**<br>**estudos**|<br>**Risco de viés**|**Viés de relato**|**Evidência**<br>**indireta**<br>**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Confiança**|
|---|---|---|---|---|---|---|---|
|**PLA:SAF**|4|Algumas<br>preocupações|Baixo|Sem preocupações Algumas preocupações|Algumas preocupações|Sem preocupações|Muito baixo|
|**CAB:SAF**|0|Sem preocupações|Baixo|Sem preocupações Grave preocupação|Algumas preocupações|Sem preocupações|Muito baixo|
|**ENT:SAF**|0|Algumas<br>preocupações|Algumas<br>preocupações|Sem preocupações<br>Grave preocupação|Algumas preocupações|Sem preocupações|Muito baixo|
|**PRA:SAF**|0|Sem preocupações|Baixo|Sem preocupações<br>Grave preocupação|Algumas preocupações|Sem preocupações|Muito baixo|
|**RAS:SAF**|0|Algumas<br>preocupações|Baixo|Sem preocupações<br>Algumas preocupações|Algumas preocupações|Sem preocupações|Muito baixo|
|**ROP:SAF**|0|Sem preocupações|Baixo|Sem preocupações Grave preocupação|Algumas preocupações|Sem preocupações|Muito baixo|
|**ROT:SAF**|0|Sem preocupações|Baixo|Sem preocupações Grave preocupação|Algumas preocupações|Sem preocupações|Muito baixo|
|**SAF:SEL**|0|Algumas<br>preocupações|Baixo|Sem preocupações<br>Algumas preocupações|Algumas preocupações|Sem preocupações|Muito baixo|  
**Legenda:** CAB, cabergolina; ENT: entacapona; PRA, pramipexol; RAS, rasagilina; ROP, ropinirole; ROT, rotigotina; SAF, safinamida; SEL, selegilina.  
**Nota:** linhas destacadas em azul indicam comparações de safinamida com as tecnologias atualmente disponíveis no SUS (entacapona, pramipexol, rasagilina e selegilina).  
70  
**Quadro N** - Avaliação da qualidade da evidência para o desfecho de descontinuação por eventos adversos nos estudos com safinamida e os comparadores disponíveis no SUS (adaptado da ferramenta CINeMA).  
|**Comparação**|**Número de**<br>**estudos**|<br>**Risco de viés**|**Viés de relato**|**Evidência indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Confiança**|
|---|---|---|---|---|---|---|---|---|
|**PLA:SAF**|5|Sem preocupações|Baixo|Sem preocupações|Grave preocupação|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**CAB:SAF**|0|Sem preocupações|Baixo|Sem preocupações|Grave preocupação|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**ENT:SAF**|0|Sem preocupações|Algumas<br>preocupações|Sem preocupações|Grave preocupação|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**PRA:SAF**|0|Sem preocupações|Baixo|Sem preocupações|Algumas<br>preocupações|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**RAS:SAF**|0|Sem preocupações|Baixo|Sem preocupações|Grave preocupação|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**ROP:SAF**|0|Sem preocupações|Baixo|Sem preocupações|Sem preocupações|Algumas preocupações|Algumas<br>preocupações|Baixa|
|**ROT:SAF**|0|Sem preocupações|Baixo|Sem preocupações|Algumas<br>preocupações|Algumas preocupações|Algumas<br>preocupações|Muito baixa|
|**SAF:SEL**|0|Sem preocupações|Baixo|Sem preocupações|Grave preocupação|Algumas preocupações|Algumas<br>preocupações|Muito baixa|  
**Legenda:** CAB, cabergolina; ENT: entacapona; PRA, pramipexol; RAS, rasagilina; ROP, ropinirole; ROT, rotigotina; SAF, safinamida; SEL, selegilina.  
**Nota:** linhas destacadas em azul indicam comparações de safinamida com as tecnologias atualmente disponíveis no SUS (entacapona, pramipexol, rasagilina e selegilina).  
71  
Os resultados indicam que safinamida é superior ao placebo em redução dos escores de UPDRS-II e UPDRS-III, mas não foram observadas diferenças em UPDRS-IV ou no escore total de UPDRS. Dois estudos sugerem que os pacientes que utilizaram safinamida permanecem mais tempo com seus sintomas controlados antes da próxima dose do medicamento (maior redução de _wearing off_ ). Ademais, safinamida foi superior a placebo para o desfecho de redução de dor. Para os desfechos de segurança, ainda para a comparação entre safinamida e placebo, não foram encontradas diferenças entre os grupos para eventos adversos gerais, graves ou descontinuação por eventos adversos. Quando considerados outros comparadores disponíveis no SUS (entacapona, pramipexol, rasagilina e selegilina), não foram encontradas diferenças entre os tratamentos quanto à incidência de eventos adversos graves e descontinuação por eventos adversos.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: <u>EVIDÊNCIAS ECONÔMICAS</u> -->
Foram conduzidas Análise de Custo-Minimização (comparação de custos) e Análise de Custo-Efetividade (ACE) por meio de modelo de árvore de decisão (comparação de custo e eficácia): a primeira, tendo em vista a ausência de diferença clínica entre safinamida, rasagilina e entacopona; a segunda, tendo em vista a identificação de diferença significativa entre safinamida, selegilina e pramipexol na proporção de respondedores (segundo escala _Clinical Global Impression_ – CGI) minimamente melhor, muito melhor ou muitíssimo melhor; ou com pelo menos 20% de redução na pontuação UPDRS-III desde a linha de base até o final do estudo<sup>16</sup> .  
Valores de utilidade relacionadas a este desfecho não foram encontrados na literatura, de modo que não puderam ser considerados no modelo. Eventos adversos não foram considerados porque não foram identificadas diferenças significativas em incidência de eventos adversos graves ou descontinuação por eventos adversos para os tratamentos de interesse. Foram considerados indivíduos com DP em qualquer fase da doença (inicial, intermediária ou avançada) responsivos à levodopa e com indicação de terapia combinada no SUS.  
Ainda que tenham sido recuperados estudos que comparassem safinamida com placebo, não foram conduzidas avaliações econômicas (AE) para estas comparações porque segundo recomendação das Diretrizes Metodológicas de AE do Ministério da Saúde<sup>20</sup> , devem ser selecionados os comparadores disponíveis na perspectiva com maior uso e potencial de serem as opções mais custo-efetivas.  
Na ACE considerou-se um horizonte temporal de 12 meses, conforme estudo de Schapira et al., 2013<sup>14</sup> . Embora a DP seja uma doença de caráter crônico, não foi possível contemplar horizontes temporais mais longos, uma vez que 12 meses foi o tempo máximo de avaliação dos desfechos. Ademais, segundo opinião de especialistas, não há plausibilidade em pressupor que a eficácia dos tratamentos se mantenha inalterada ao longo do tempo<sup>21</sup> . Assim, reproduzir as probabilidades de sucesso ou falha das estratégias ao longo do tempo em um modelo poderiam fornecer resultados tendenciosos e, potencialmente, resultar em conclusões equivocadas.  
Já na análise de custo-minimização, safinamida foi comparada à rasagilina e à entacapona em um horizonte temporal de 12 meses.  
Nestas análises foram considerados somente os custos de aquisição dos medicamentos (safinamida 100 mg/dia; pramipexol 1 mg, três vezes ao dia; selegilina 5 mg, uma vez ao dia; rasagilina 1 mg uma vez ao dia; entacapona 200 mg a cada dose de levodopa). Custos com levodopa ou outros medicamentos e custos de acompanhamento não foram considerados por serem comuns a todos os braços de tratamento. As alternativas consideradas são de administração por via oral e, assim, custos de administração não foram incluídos.  
A utilização da safinamida se mostrou uma tecnologia dominada em relação ao pramipexol, ou seja, resultaria num custo incremental de R$ 2.850,65 para uma diminuição da efetividade na proporção de respondedores ( **Tabela F** ).  
72  
**Tabela F** - Resultados da análise de custo-efetividade da safinamida.  
|**Medicamento**|**Custo (R$)**|**Custo**<br>**incremental**<br>**(R$)**|**Efetividade**|**Efetividade**<br>**incremental**|**RCEI**|
|---|---|---|---|---|---|
|Selegilina 5 mg|372,30|-|0,20|-||
|Pramipexol 1mg|438,00|65,70|0,45|0,25|264,92|
|Safinamida cp 100 mg|3.471,03|2.850,65|0,32|-0,14|-20.656,88|  
**Fonte** : elaboração própria. **Nota:** *RCEI de safinamida vs. selegilina não é representado, uma vez que pramipexol é a opção mais custo-efetiva.  
A análise de sensibilidade determinística evidenciou que a variável que mais influenciou o modelo foi a probabilidade de resposta à selegilina podendo, potencialmente, ultrapassar o limiar de disposição a pagar estabelecido de R$ 40.000/QALY ganho. Este dado, entretanto, deve ser interpretado com extrema cautela, uma vez que valores de disposição a pagar variam de acordo com o desfecho considerado e, provavelmente, seria inferior para o desfecho de mudança global. Probabilidade de resposta à safinamida e o custo desta também influenciaram os resultados, embora não tenha ultrapassado o limiar de disposição a pagar.  
Na custo-minimização, identificou-se que a utilização de safinamida resultaria em custo incremental de R$ 2.478,23 e de R$ 580,23 quando comparada à rasagilina e à entacapona, respectivamente ( **Tabela G** ).  
**Tabela G -** Resultados da análise de custo-minimização da safinamida.  
|**Medicamento**|**Custo**|**Custo incremental**|
|---|---|---|
|Rasagilina 1 mg|R$ 992,80|-|
|Entacapona 200 mg|R$ 2.890,80|-|
|Safinamida cp 100 mg|R$ 3.471,03|vs. rasagilina: R$ 2.478,23<br>vs. entacapona: R$ 580,23|  
**Fonte** : elaboração própria.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Análise de impacto orçamentário</u>** -->
A população elegível foi estimada a partir de dados de demanda aferida, com uma média de 121.357 pacientes/ano. Considerou-se que todos os pacientes poderiam utilizar um inibidor da MAO, uma vez que a literatura sugere troca entre iMAOB e safinamida<sup>22</sup> .  
No cenário referência, considerou-se que 24,3% dos pacientes utilizariam rasagilina e 75,7% selegilina; no cenário proposto, a safinamida seria incorporada a uma taxa de difusão variando entre 17,4% e 37,4%, com incrementos anuais de 5%. Estas estimativas foram adotadas com base no estudo de Ronconi et al., 2022, sobre padrões de prescrição de inibidores da MAO para o tratamento de pacientes com DP na Itália<sup>22</sup> .  
Somente os custos de aquisição dos medicamentos foram considerados, uma vez que não foram evidenciadas diferenças significativas entre os tratamentos para os desfechos de eficácia e segurança priorizados pelos especialistas do grupo elaborador de PCDT. Os custos de levodopa não foram considerados visto que não haveria diferenças entre os grupos em relação à proporção de pacientes em uso ou à posologia.  
O impacto orçamentário estimado para o primeiro ano foi de cerca de 58 milhões de reais, enquanto o impacto acumulado em cinco anos foi de cerca de 497,7 milhões de reais ( **Tabela H** ).  
73  
**Tabela H** - Impacto orçamentário estimado da incorporação da safinamida.  
|**Cenário**|**Ano 1 (R$)**|**Ano 2 (R$)**|**Ano 3 (R$)**|**Ano 4 (R$)**|**Ano 5 (R$)**|
|---|---|---|---|---|---|
|Atual (rasagilina +<br>selegilina)|58.123.247|60.801.424|63.479.602|66.157.779|68.835.956|
|Proposto||||||
|(rasagilina<br>+<br>selegilina<br>+|115.139.350|137.588.533|161.472.717|186.939.327|213.916.240|
|safinamida)||||||
|Impacto<br>orçamentário|57.016.103|76.787.109|97.993.115|120.781.548|145.080.283|
|Total em 5 anos: + R|$ 497.658.159|||||  
**Fonte** : elaboração própria.  
A análise de sensibilidade determinística unidirecional observou que o impacto orçamentário incremental variou de mais de R$ 373.243.619 a mais de R$ 1.188.064.547, a depender do parâmetro considerado, mas principalmente em função do preço do medicamento. Cabe ressaltar que, além destas incertezas, é possível que a estimativa esteja superestimada, uma vez que se adotou a premissa de que todos os pacientes em uso de levodopa estariam em uso de um inibidor da MAO.

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **<u>Referências</u>** -->
1. Goetz CG, Tilley BC, Shaftman SR, Stebbins GT, Fahn S, Martinez-Martin P, et al. Movement Disorder Societysponsored revision of the Unified Parkinson’s Disease  Rating Scale (MDS-UPDRS): scale presentation and clinimetric testing results. Mov Disord. 2008;23:2129–70.  
2. Mello MPB de, Botelho ACG. Correlação das escalas de avaliação utilizadas na doença de Parkinson com aplicabilidade na fisioterapia. Fisioter. em Mov. scielo ; 2010.  
3. Stacy M, Hauser R, Oertel W, Schapira A, Sethi K, Stocchi F, et al. End-of-dose wearing off in Parkinson disease: a  
9-question survey assessment. Clin Neuropharmacol. 2006;29:312–21.  
4. Borgohain R, Szasz J, Stanzione P, Meshram C, Bhatt M, Chirilineau D, et al. Randomized trial of safinamide add-  
on to levodopa in Parkinson’s disease with motor fluctuations. Mov Disord. 2014;29:229–37.  
5. Schapira AH, Fox SH, Hauser RA, Jankovic J, Jost WH, Kenney C, et al. Assessment of Safety and Efficacy of Safinamide as a Levodopa Adjunct in Patients With Parkinson Disease and Motor Fluctuations: a Randomized Clinical Trial. JAMA Neurol. 2017;74:216‐224.  
6. CD B, IF T, JI G, Natvig B, Klemp M. Comparative effectiveness of dopamine agonists and monoamine oxidase type-B inhibitors for Parkinson’s disease: a multiple treatment comparison meta-analysis. Eur J Clin Pharmacol. 2020;76:1731– 43.  
7. Ouzzani M, Hammady H, Fedorowicz Z, Elmagarmid A. Rayyan—a web and mobile app for systematic reviews.  
Syst Rev. 2016;5:210.  
8. Rohatgi A. WebPlotDigitizer v.4.6. 2022.  
9. The Cochrane Collaboration. Cochrane Handbook for Systematic Reviews of Interventions. 2nd ed. Higgins JPT,  
Thomas J, Chandler J, Cumpston M, Li T, Page MJ, et al., editors. Hoboken, NJ: Wiley-Blackwell; 2019.  
74  
10. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;j4008.  
11. Nikolakopoulou A, Higgins JPT, Papakonstantinou T, Chaimani A, Del Giovane C, Egger M, et al. CINeMA: An  
approach for assessing confidence in the results of a network meta-analysis. PLOS Med. 2020;17:e1003082.  
12. Guyatt GH, Oxman AD, Vist GE, Kunz R, Falck-Ytter Y, Alonso-Coello P, et al. GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. BMJ. 2008;336:924–6.  
13. Stocchi F, Borgohain R, Onofrj M, AH S, Bhatt M, Lucini V, et al. A randomized, double-blind, placebo-controlled trial of safinamide as add-on therapy in early Parkinson’s disease patients. Mov Disord. 2012;27:106–12.  
14. AH S, Stocchi F, Borgohain R, Onofrj M, Bhatt M, Lorenzana P, et al. Long-term efficacy and safety of safinamide as add-on therapy in early Parkinson’s disease. Eur J Neurol. 2013;20:271–80.  
15. AR Q, AQ R, SH M, SFH R, Akhter S, Vannabouathong C, et al. Comprehensive Examination of Therapies for Pain in Parkinson’s Disease: A Systematic Review and Meta-Analysis. Neuroepidemiology. 2018;51:190–206.  
16. Binde CD, Tvete IF, Gåsemyr JI, Natvig B, Klemp M. Comparative effectiveness of dopamine agonists and monoamine oxidase type-B inhibitors for Parkinson’s disease: a multiple treatment comparison meta-analysis. Eur J Clin Pharmacol. 2020;76:1731–43.  
17. Hattori N, Tsuboi Y, Yamamoto A, Sasagawa Y, Nomoto M, Group M-3 S. Efficacy and safety of safinamide as an add-on therapy to L-DOPA for patients with Parkinson’s disease: A randomized, double-blind, placebo-controlled, phase II/III study. Parkinsonism Relat Disord. 2020;75:17–23.  
18. Kulisevsky J, Martinez-Horta S, Campolongo A, Pascual-Sedano B, Marin-Lahoz J, Bejr-kasem H, et al. A Randomized Clinical Trial to Evaluate the Effects of Safinamide on Apathetic Non-demented Patients With Parkinson’s Disease. Front Neurol. 2022;13.  
19. Borgohain R, Szasz J, Stanzione P, Meshram C, MH B, Chirilineau D, et al. Two-year, randomized, controlled study  
of safinamide as add-on to levodopa in mid to late Parkinson’s disease. Mov Disord. 2014;29:1273–80.  
20. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Departamento de Ciência e,  
Tecnologia. Diretrizes metodológicas: Diretriz de Avaliação Econômica. 2a edição. Brasília: Ministério da Saúde; 2014.  
21. CADTH. Canadian Agency for Drugs and Technologies in Health. No Title. 2019.  
22. Ronconi G, Calabria S, Piccinni C, Dondi L, Pedrini A, Esposito I, et al. Prescription Pattern of Monoamine Oxidase B Inhibitors Combined with Levodopa: A Retrospective Observational Analysis of Italian Healthcare Administrative Databases. Drugs - Real World Outcomes. 2022;9:391–401.  
**QUESTÃO 3: Para pacientes com DP e demência, a rivastigmina (cápsula, solução oral ou adesivo transdérmico) é segura e eficaz comparada a placebo ou ao cuidado padrão, mensurada pela escala UPDRS, minimental e MoCA??**  
Recomendação: Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS de rivastigmina para pacientes com DP e demência, conforme Relatório de Recomendação nº 902/2024, disponível em: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2024/rivastigmina-para-o-tratamento-em-individuos-com-doenca-deparkinson-e-demencia.</u>  
75  
A estrutura PICO para esta pergunta foi:  
|População|Pacientes com DP e demência|
|---|---|
|Intervenção (tecnologia)|Rivastigmina cápsula 1,5 mg a 6 mg, duas vezes ao dia|
|Comparação|Cuidado-padrão + placebo|
|Desfechos (_Outcomes_)|**Primários:**<br>Escala UPDRS (escore total e subescores (i.e., I e IV, respectivamente, estado mental,<br>comportamento e humor; e complicações da terapia);<br>Miniexame do Estado Mental (Mini-Mental) - total;<br>_Montreal Cognitive Assessment_(MoCA) - total.|
||**Secundários:**<br>Qualidade de vida (preferencialmente pela escala PDQ39);<br>Eventos adversos (gerais, graves e descontinuação por eventos adversos);<br>Subescala para função cognitiva do_Alzheimer’s Disease Assessment Scale_(ADAS-cog);<br>Melhora clínica, avaliada pela escala_Alzheimer’s Disease Cooperative Study –_<br>_Clinician’s Global Impression of Change_(ADCS-CGIC)|
|Tipo de estudo (_Study type_)|Ensaios clínicos randomizados e revisões sistemáticas|

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **Métodos e resultados da busca:** -->
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 902 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.  
76

---

<!-- METADADOS: doenca: Doença de parkinson | secao: **APÊNDICE 2** -->
**HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO**  
|**Número do Relatório da**|**Piii**|**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**diretriz clínica (Conitec)**<br>**ou Portaria de Publicação**|**rncpas**<br>**alterações**|**Incorporação ou alteração do uso**<br>**no SUS**|**Não incorporação ou exclusão**<br>**no SUS**|
|Relatório de Recomendação<br>nº 957/2024|Atualização<br>do<br>documento|Rivastigmina para o tratamento em<br>indivíduos com doença de Parkinson<br>e demência [Portaria SECTICS/MS<br>nº<br>27/2024;<br>Relatório<br>de<br>Recomendação nº 902/2024]||
||Alteração<br>pós<br>publicação|-|Tolcapona 100 mg comprimido e<br>do Cloridrato de selegilina 10 mg<br>comprimido [Portaria SCTIE/MS<br>nº 83, de 29/12/2021].|
|Relatório de Recomendação<br>nº 291, de agosto de 2017||Clozapina para psicose associada à<br>Doença de Parkinson [Relatório||
|Portaria<br>Conjunta<br>SAS-<br>SCTIE/MS nº 10, de 31 de<br>outubro de 2017.||Técnico n° 218 de 2016; Portaria<br>SCTIE/MS n°22/2016]<br>Mesilato<br>de<br>rasagilina<br>com<br>combinação<br>com<br>levodopa<br>[Relatório Técnico n° 280 de 2017;<br>Portaria SCTIE/MS n° 27/2017]|-|
|Portaria SAS/MS nº 228, de<br>10 de maio de 2010.|Primeira versão do<br>documento|-|-|  
77

---

