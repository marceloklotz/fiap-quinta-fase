<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 08, DE 12 DE SETEMBRO DE 2024.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla (EM).  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.036, de 28 de maio de 2024, e  
Considerando a necessidade de se estabelecerem os parâmetros sobre a esclerose múltipla no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os Registros de Deliberação nº 836 e nº 905 e os Relatórios de Recomendação nº 839 de agosto de 2023 e nº 908 de julho de 2024 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura;  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla (EM).  
Parágrafo único. O Protocolo objeto deste artigo, que contém o conceito geral da Esclerose Múltipla, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Esclerose Múltipla.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAES/SCTIE nº 1, DE 7 DE JANEIRO DE 2022, publicada no Diário Oficial da União (DOU) nº 21, de 31 de janeiro de 2022, seção 1, página 222.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
1

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A esclerose múltipla (EM) é uma doença imunomediada, inflamatória, desmielinizante e neurodegenerativa, que envolve a substância branca e a cinzenta do Sistema Nervoso Central (SNC). Sua etiologia não é bem compreendida, envolvendo fatores genéticos e ambientais. Até o momento, as interações entre esses vários fatores parece ser a principal razão para diferentes apresentações da EM, bem como diferentes respostas aos medicamentos<sup>1–3</sup> .  
Essa doença acomete usualmente adultos jovens, dos 20 aos 50 anos de idade, com pico aos 30 anos, sendo mais rara quando se inicia fora dessa faixa etária. Em média, é duas vezes mais frequente em mulheres e apresenta menor incidência na população afrodescendente, oriental e indígena<sup>4–6</sup> . Estima-se que, no mundo, cerca de 2,8 milhões de pessoas vivam com EM. A EM é desigualmente distribuída nas regiões do planeta, haja vista que a prevalência e a incidência tendem a aumentar com a latitude, tanto ao norte quanto ao sul da linha do equador, sendo mais alta na Europa e América do Norte e mais baixa na região da África e do Pacífico Ocidental. Fatores ambientais podem estar relacionados a essa diferença<sup>6</sup> . O Brasil apresenta uma prevalência média de 8,69/100.000 habitantes, e, assim como no mundo, a prevalência varia de acordo com a região de residência do paciente, sendo menor no Nordeste - 1,36 por 100 mil habitantes, e maior na região Sul - 27,2 por 100 mil habitantes<sup>7</sup> .  
A evolução da doença, gravidade e sintomas não são uniformes, daí a EM apresentar-se de diferentes formas clínicas (variações fenotípicas). O quadro clínico se manifesta, na maior parte das vezes, por surtos ou ataques agudos, podendo entrar em remissão de forma espontânea ou com o uso de corticosteroide<sup>3,8,9</sup> . Os sintomas podem ser graves ou parecer tão triviais que o paciente pode não procurar assistência médica por meses ou anos. Neurite óptica, diplopia, paresia ou alterações sensitivas e motoras de membros, disfunções de coordenação e equilíbrio, dor neuropática, espasticidade, fadiga, disfunções esfincterianas e cognitivo-comportamentais, de forma isolada ou em combinação, são os principais sintomas<sup>3,10</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da esclerose múltipla.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
- G35 - Esclerose Múltipla

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O diagnóstico de EM é complexo, uma vez que não existe marcador ou teste diagnóstico específico<sup>8</sup> . Ao longo da história, vários modelos foram esquematizados e propostos a fim de orientar e facilitar o diagnóstico dessa doença. Atualmente, os critérios de McDonald, descritos em 2001 e revisados em 2005, 2010 e 2017, são mais frequentemente utilizados<sup>11–14</sup> . Em geral, o diagnóstico é baseado na documentação de dois ou mais episódios sintomáticos, que devem durar mais de 24 horas e ocorrer de forma distinta, separados por período de no mínimo um mês<sup>3</sup> , ou seja, disseminados no tempo e no espaço<sup>13,14</sup> . Exames  
2  
radiológicos e laboratoriais, em especial a ressonância magnética (RM), podem, em conjunto com as evidências clínicas, ser essenciais para compor o diagnóstico e excluir outras doenças de apresentação semelhante<sup>11–14</sup> .  
O diagnóstico deve ser feito com base nos Critérios de McDonald revisados em 2017<sup>14</sup> , descritos no Quadro 1. De acordo com esses critérios, não são necessários exames adicionais quando o paciente apresenta dois ou mais surtos; entretanto, qualquer diagnóstico de EM pode contar com exame de neuroimagem (ressonância magnética) e utilizar a presença de bandas oligoclonais (imunoglobulina G - IgG) no líquor em substituição à demonstração de disseminação da doença no tempo.  
De acordo com os critérios de McDonald, é considerado surto todo evento reportado pelo paciente ou objetivamente observado que seja típico de um evento inflamatório desmielinizante agudo com duração de pelo menos 24 horas, na ausência de infecção ou febre. O evento deve ser documentado por exame neurológico realizado na mesma época da sua manifestação clínica. Alguns eventos históricos para os quais não haja achado neurológico documentado, mas que sejam típicos de EM, podem prover evidência suficiente de um evento desmielinizante prévio. Relatos de sintomas paroxísticos (históricos ou correntes) devem, no entanto, consistir em múltiplos episódios com ocorrência em período superior a 24 horas.  
Segundo os critérios McDonald (2017)<sup>14</sup> , a disseminação no espaço pode ser demonstrada na RM por ≥ 1 lesões hiperintensas em T2, sintomáticas ou assintomáticas, que são característicos de EM, em dois ou mais das seguintes quatro áreas do sistema nervoso central: periventricular, cortical/justacortical, infratentorial e medula espinhal. Já a disseminação no tempo pode ser demonstrada pela presença simultânea de lesões captantes de gadolíneo e lesões não captantes em qualquer exame de RM, ou nova lesão hiperintensa em T2 ou captante de gadolínio quanto comparada a um exame de RM prévio, independentemente do momento em que foi realizado<sup>14</sup> .  
**Quadro 1.** Critérios de McDonald 2017 revisados e adaptados  
|**Número de surtos**<sup>**(a)**</sup>|**Número de lesões com evidência clínica**<br>**objetiva**<sup>**(b)**</sup>|**Critérios adicionais para o diagnóstico de EM**|
|---|---|---|
|2 ou mais surtos|2 ou mais lesões|Nenhum<sup>**(c)**</sup>|
|2 ou mais surtos|1 lesão + evidência clara de surto anterior<br>envolvendo uma lesão em localização<br>anatômica distinta|Nenhum<sup>**(c)**</sup>|
|2 ou mais surtos|1 lesão|Disseminação no espaço demonstrada por:<br>●<br>Novo surto em localização diferente no SNC<br>**OU**<br>●<br>Ressonância Magnética<sup>**(d)**</sup>|
|1 surto|2 ou mais lesões|Disseminação no tempo demonstrada por:<br>●<br>Novo surto<br>**OU**<br>●<br>Ressonância Magnética<sup>**(e)**</sup><br>**OU**<br>●<br>Presença de bandas oligoclonais no LCR<sup>**(f)**</sup>|  
3  
|**Número de surtos**<sup>**(a)**</sup>|**Número de lesões com evidência clínica**<br>**objetiva**<sup>**(b)**</sup>|**Critérios adicionais para o diagnóstico de EM**|
|---|---|---|
|1 surto|1 lesão|Disseminação no espaço demonstrada por:<br>●<br>Novo surto em localização diferente no SNC<br>**OU**<br>●<br>Ressonância Magnética<sup>**(d)**</sup><br>**E**<br>Disseminação no tempo demonstrada por:<br>●<br>Novo surto<br>**OU**|
|||●<br>Ressonância Magnética<sup>**(e)**</sup><br>**OU**|
|||●<br>Presença de bandas oligoclonais no LCR<sup>**(f)**</sup>|  
Traduzido de Thompson et al., 2017<sup>14</sup>  
EM = Esclerose Múltipla; SNC = Sistema Nervoso Central; LCR = Exame do líquido cefalorraquidiano.  
(a) Definição de surto constantes na seção “Diagnóstico” deste PCDT;  
(b) O diagnóstico baseado em evidência clínica objetiva de duas lesões é o mais seguro. Evidência histórica de um surto prévio, na ausência de achados neurológicos objetivamente documentados, pode incluir eventos históricos com sintomas e evolução característicos de um evento desmielinizante inflamatório prévio. Pelo menos um surto, entretanto, deve ter seu suporte em achados objetivos. Na ausência de evidência objetiva residual, é necessária cautela;  
(c) Nos critérios de McDonald originais (revisão de 2017), não são necessários testes adicionais, entretanto, para efeito deste PCDT adotou-se que qualquer diagnóstico de EM deve ser realizado com acesso à neuroimagem;  
(d) Ressonância Magnética para disseminação no espaço conforme descrito na seção “Diagnóstico” deste PCDT;  
(e) Ressonância Magnética para disseminação no tempo conforme descrito na seção “Diagnóstico” deste PCDT;  
(f) A presença de bandas oligoclonais no líquor não demostra disseminação no tempo, contudo pode substituir a demonstração de disseminação no tempo.  
Após o estabelecimento do diagnóstico, a Escala Expandida do Estado de Incapacidade (EDSS, de _Expanded Disability Status Scale_ ) (Apêndice 1) deve ser utilizada para o estadiamento da doença, bem como o monitoramento do paciente<sup>10</sup> . Essa escala foi proposta por Kurtzke<sup>15</sup> e permite quantificar o comprometimento neuronal dentro de oito sistemas funcionais: piramidal, cerebelar, tronco cerebral, sensitivo, vesical, intestinal, visual, mental e outras funções agrupadas. O escore final da escala pode variar de 0 (normal) a 10 (morte), sendo que a pontuação aumenta 0,5 ponto conforme o grau de incapacidade do paciente<sup>15</sup> . É utilizada para o estadiamento da doença e para monitorar o seguimento do paciente.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A observação de que a evolução da doença segue determinados padrões clínicos levou à definição de terminologias para descrever os cursos clínicos da doença, de acordo com a ocorrência de surtos e progressão<sup>16</sup> . Atualmente, a EM pode ser classificada em<sup>16,17</sup> :  
● **Síndrome Clinicamente Isolada (** **_Clinically Isolated Syndrome - CIS_ )** , que consiste na primeira manifestação clínica que apresenta características de desmielinização inflamatória sugestiva de esclerose múltipla, mas incapaz de cumprir os critérios de disseminação no tempo por neuroimagem ou líquor.  
● **Esclerose Múltipla Remitente recorrente (EMRR)** , caracterizada por episódios de piora aguda do funcionamento neurológico (novos sintomas ou piora dos sintomas existentes) com recuperação total ou parcial e sem progressão aparente da doença.  
4  
- **Esclerose Múltipla Secundária Progressiva (EMSP)** , caracterizada pela fase após um curso inicial de remitente-  
- recorrente, no qual a doença se torna mais progressiva, com ou sem recidivas.  
- **Esclerose Múltipla Primária Progressiva (EMPP)** , caracterizada por agravamento progressivo da função  
- neurológica (acúmulo de incapacidade) desde o início dos sintomas.  
Esses fenótipos podem ainda ser estratificados de acordo com o prognóstico e atividade da doença. A atividade pode ser determinada pela instauração de episódios clínicos ou detecção de achados na ressonância magnética que indiquem lesões captantes de gadolínio ou lesões novas ou em T2. A atividade da doença reflete a existência de um processo neurodegenerativo ou inflamatório ativo, o qual pode afetar o prognóstico, bem como a terapia a ser implementada<sup>16</sup> .  
As formas recorrentes (EMRR) e progressivas (EMSP e EMPP) podem ser estratificadas em alta, moderada e baixa atividade. A EM de baixa ou moderada atividade é caracterizada por indícios de atividade da doença, contudo sem se enquadrar nos critérios para classificação como de alta atividade<sup>18</sup> . Caracteriza-se como EM de alta atividade quando o paciente apresenta: 1) dois ou mais surtos e pelo menos uma lesão captante de gadolínio ou aumento de pelo menos duas lesões em T2 no ano anterior em pacientes não tratados e 2) atividade da doença no ano anterior durante a utilização adequada de pelo menos um medicamento modificador do curso da doença (MMCD), na ausência de toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou não adesão ao tratamento, apresentando pelo menos um surto no último ano durante o tratamento, e evidência de pelo menos nove lesões hiperintensas em T2 ou pelo menos uma lesão captante de gadolínio.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A falha poderá ser definida como:  
- 1) Falha terapêutica: incidência de pelo menos um surto e evidência de, no mínimo, quatro novas lesões em T2 ao exame  
- de ressonância magnética no período de 12 meses, durante tratamento medicamentoso adequado;  
- 2) Intolerância ao medicamento;  
- 3) Reações adversas não controláveis; OU  
- 4) Falta de adesão ao tratamento.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Serão incluídos neste Protocolo os pacientes com diagnóstico de EM pelos critérios de McDonald revisados e adaptados<sup>14</sup> , nas formas remitente recorrente (EMRR) ou secundariamente progressiva (EMSP); com evidência de lesões desmielinizantes comprovadas por neuroimagem (ressonância magnética) e diagnóstico diferencial com exclusão de outras causas.  
São critérios de inclusão para o uso de **fingolimode:**  
- EMRR classificada como de baixa ou moderada atividade; **E**  
- Ocorrência prévia de falha a qualquer medicamento da primeira linha de tratamento.  
Serão classificadas com **EMRR altamente ativa** as pessoas que apresentarem um dos seguintes critérios<sup>18</sup> :  
 Incidência de dois ou mais surtos incapacitantes com resolução incompleta e evidência de pelo menos uma nova lesão captante no gadolínio ou aumento significativo da carga da lesão em T2 no ano anterior em pacientes não tratados; **OU**  
 Atividade da doença no ano anterior, durante a utilização adequada de pelo menos um MMCD, na ausência de toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou não adesão ao tratamento, apresentando pelo menos um surto no último ano durante o tratamento e evidência de pelo menos nove lesões hiper-intensas em T2 ou pelo menos uma nova lesão captante de gadolínio.  
Adicionalmente, são critérios de inclusão para o uso de **natalizumabe:**  
5  
- EMRR classificada como de alta atividade; **OU**  
- EMRR classificada como de baixa ou moderada atividade **E** falha ou contraindicação ao uso de fingolimode.  
Adicionalmente, são critérios de inclusão para o uso de **cladribina oral:**  
- EMRR classificada como de alta atividade; **E**  
- Ocorrência de falha ou contraindicação ao uso de natalizumabe **.**  
Adicionalmente, são critérios de inclusão para o uso de **alentuzumabe:**  
- EMRR classificada como de alta atividade; **E**  
- Ocorrência de falha ou contraindicação ao uso de cladribina oral.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Serão excluídos deste Protocolo os pacientes com algum dos critérios a seguir:  
- Intolerância, hipersensibilidade ou contraindicação ao uso do respectivo medicamento preconizado neste  
Protocolo;  
- Diagnóstico de EM na forma primariamente progressiva (EMPP);  
- Elevação basal das enzimas hepáticas e bilirrubina total acima do limite superior da normalidade (LSN): ALT/TGP  
e AST/TGO acima de 20 vezes o LSN, Gama GT acima de 10 vezes o LSN e icterícia ou bilirrubina total acima de 10 vezes o LSN;  
- Contagem de linfócitos no sangue periférico abaixo de 1.000/mm<sup>3</sup> . Especificamente, para cladribina, não deve  
- estar fora dos limites de normalidade, conforme valores de referência, antes do início do tratamento no ano 1; e antes do início do ano 2 de tratamento, a contagem de linfócitos no sangue periférico não deve estar abaixo de 800/mm3.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Caracteriza-se pela primeira manifestação clínica sugestiva de desmielinização inflamatória no SNC, em que o paciente apresente uma ou mais lesões típicas em T2 comprovadas por exame de ressonância magnética e inatribuível a outras doenças. Para esses pacientes, o risco de desenvolver EM varia de 48% a 81%, dependendo do número de lesões<sup>16,18</sup> . Nesta situação, o paciente deverá ser investigado para os diversos diagnósticos diferenciais, incluindo outras doenças autoimunes que acometem o SNC, doenças paraneoplásicas e infecções crônicas do SNC. O diagnóstico deve ser feito de acordo com os critérios de McDonald revisados e adaptados<sup>14</sup> . Existem evidências de que a utilização de MMCD, em especial os de primeira linha de tratamento, podem retardar a conversão da CIS (síndrome clinicamente isolada) em EM<sup>19–23</sup> .  
Em termos de tratamento, é importante considerar as quatro medidas principais da atividade da doença: (i) surtos, (ii) lesões à ressonância magnética, (iii) progressão da incapacidade e dano difuso por neurodegeneração e (iv) perda do volume cerebral. Além disso, devem-se considerar os perfis de risco, eficácia do mundo real, preocupações específicas de segurança e riscos associados ao uso de cada medicamento a longo prazo. Uma vez que o paciente tenha o diagnóstico de CIS, este Protocolo preconiza que o tratamento seja iniciado apenas após a confirmação de EM, conforme os critérios de inclusão nele estabelecidos, bem como que o paciente seja acompanhado a cada 3-6 meses com RM de crânio ou exame do líquor com banda oligoclonal, com o objetivo de identificar o surgimento de novas lesões desmielinizantes ou lesões impregnadas pelo contraste que não apresentavam esta característica antes ou, ainda, o aumento das dimensões de lesões previamente existentes. Qualquer das alterações descritas configura quadro evolutivo, permitindo o diagnóstico precoce de EM.  
6

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A Leucoencefalopatia Multifocal Progressiva (LEMP) é uma infecção oportunista causada pelo vírus JC (vírus John Cunningham ou vírus polioma) que acomete pacientes imunocomprometidos e pode ser fatal ou resultar em incapacidade grave. O teste do vírus JC positivo não determina necessariamente o desenvolvimento de LEMP, uma vez que o vírus é amplamente difundido na população.  
Alguns pacientes apresentam fatores que tornam o risco de desenvolver LEMP significativamente maior, tais como:  
- presença de anticorpos anti-JCV;  
- mais de 2 anos de tratamento com natalizumabe ou fingolimode; ou  
- terapia anterior com imunossupressor.  
O risco de desenvolver LEMP é ainda maior nos pacientes que:  
- Possuem os três fatores de risco para LEMP;  
- Apresentam altos índices de anticorpos anti-JCV e foram tratados por mais de 2 anos com natalizumabe, mesmo  
sem uso prévio de imunossupressor.  
Pacientes que apresentem **risco de desenvolver LEMP significativamente maior não estão excluídos do uso de natalizumabe** , **desde que os benefícios do tratamento superem seus riscos e sejam considerados individualmente pelo paciente e pela equipe de saúde** . Estes pacientes devem ser monitorados e o uso de natalizumabe deve ser mantido apenas enquanto os benefícios superarem os riscos.<sup>24</sup>  
**Se o paciente desenvolver LEMP, o tratamento com natalizumabe deve ser permanentemente interrompido.**

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O tratamento da EM pode ser complexo, envolvendo ação coordenada de múltiplos profissionais da saúde, com o uso de condutas medicamentosas e não medicamentosas.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O objetivo do tratamento medicamentoso é a melhora clínica, com aumento da capacidade funcional, redução de comorbidades e atenuação de sintomas. Os glicocorticoides são utilizados para tratar os surtos e mostram benefício clínico a curto prazo, ao reduzir a intensidade e duração dos episódios agudos<sup>3</sup> . As terapias modificadoras do curso da doença (MMCD) visam reduzir as células imunogênicas circulantes, suprimir a adesão destas ao epitélio e, consequentemente, reduzir a migração para o parênquima e a resposta inflamatória decorrente<sup>25</sup> . Existem ainda os medicamentos para o tratamento dos sintomas relacionados à EM.  
Especial atenção deve ser dada às condições de armazenamento, refrigeração e administração dos medicamentos, em especial os injetáveis. Para tal, instruções adequadas de uso devem ser compartilhadas aos pacientes e familiares pelos profissionais de saúde.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Deve ser considerado um surto ou recaída da EM o surgimento de novos sintomas ou piora dos sintomas existentes com duração superior a 24 horas, na ausência de febre, infecção ou qualquer outra causa, após um período estável de pelo menos um mês. Assim, um surto da EM só é diagnosticado após a exclusão de infecção, principalmente do trato urinário e respiratório, e a diferenciação entre uma recaída e a progressão da doença<sup>26,27</sup> .  
7  
O controle dos surtos é um componente crucial do tratamento da EM. A base do tratamento da recidiva envolve o uso de corticosteroide em altas doses para diminuir a inflamação e acelerar a recuperação do paciente<sup>26,28</sup> . A posologia de metilprednisolona intravenosa é 1 g diariamente durante 3-5 dias. A equipe multidisciplinar deve ser informada da frequência do surto para que possa avaliar a necessidade de alterar algum tratamento complementar em curso<sup>26,28</sup> . Ao médico assistente cabe a decisão de escolher e individualizar a duração do tratamento para cada paciente, levando-se em consideração os eventos adversos e seu controle.  
O paciente deve ser informado dos possíveis eventos adversos temporários do uso de corticosteroide em altas doses: hipertensão arterial, perturbações gastrointestinais, distúrbios do paladar, palpitação, retenção hídrica, dores no corpo, rubor facial, exacerbação da acne, hiperglicemia e particularmente os efeitos sobre a saúde mental, tais como insônia, labilidade emocional, depressão, confusão e agitação<sup>26,28</sup> . Os corticoides podem ainda diminuir a resistência imunitária, sendo necessário excluir infecção, principalmente do trato urinário, antes do início da pulsoterapia (metilprednisolona intravenosa em alta dose) e acompanhar o paciente, informando-o sobre a observância de qualquer sinal de infecção<sup>26</sup> .  
A plasmaférese como terapia adjuvante é eficaz no controle das exacerbações nas formas recorrentes de EM, com base em um único ensaio clínico de Fase I (risco baixo de viés e boa qualidade metodológica, de acordo com as Classes de Evidência - CoE). Com base em um único ensaio clínico de Fase II (risco moderadamente baixo de viés e moderada ou pobre qualidade de delineamento, de acordo com as mesmas CoE), a plasmaférese é possivelmente eficaz para doenças desmielinizantes agudas do SNC (incluindo esclerose múltipla, encefalomielite aguda disseminada, neuromielite óptica e mielite transversa) após não responderem ao tratamento com altas doses de corticosteroide. Contudo, este estudo não incluiu subgrupos de pacientes, o que possibilitaria identificar a eficácia em pacientes com diferentes doenças desmielinizantes<sup>29</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
**Este Protocolo não recomenda a associação de medicamentos modificadores do curso da doença (MMCD), que devem ser usados em monoterapia.**

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
As interferonas (IFN) são citocinas com funções antivirais, antiproliferativas e imunomoduladoras e podem ser divididas em três classes principais: tipo 1 (α e β), tipo 2 (γ) e tipo 3 (λ)<sup>30</sup> . Além disso, as IFN podem ser produzidas por diferentes tipos de células, dependendo da classe; no entanto, tipicamente, os fibroblastos produzem IFN-β e as células dendríticas, IFN-α<sup>31</sup> . As betainterferonas (IFN-β) disponíveis no SUS são: betainterferona 1a (IFN- β-1a) e betainterferona 1b (IFN- β-1b).  
Embora o mecanismo exato de ação das IFN-β não seja totalmente conhecido, acredita-se que as características antiinflamatórias, além de seus efeitos nas células endoteliais da barreira hematoencefálica, sejam a causa mais provável de melhora da EM<sup>32</sup> . Além disso, as IFN-β são capazes de promover o aumento da expressão de interleucina (IL-10), diminuição da proliferação de Th1 e microglia, diminuição da apresentação de antígenos, regulação negativa do complexo principal de histocompatibilidade (MHC) na microglia e limitação do trânsito de células inflamatórias no SNC<sup>32,33</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O acetato de glatirâmer (AG) medeia efeitos imunomoduladores pleiotrópicos capazes de alterar as respostas autoimunes específicas da EM<sup>34,35</sup> . O mecanismo de ação do AG ainda não está completamente elucidado, no entanto, sabe-se que a imunização repetida com AG promove o desenvolvimento de células apresentadoras de antígeno tipo II anti-inflamatórias (Th2) responsáveis pela secreção de interleucina (IL) 4, 5, 10,13,27 e fator β de transformação de crescimento (TGFβ)<sup>34,36</sup> . Ademais, estudos demonstraram que, além de induzir a produção de células Th2, o AG também aumenta a frequência e a função das células T reguladoras CD4+ CD25+ FoxP3+<sup>37–41</sup> .  
8  
Além disso, foi demonstrado que o AG diminui a diferenciação de células T17, considerada um dos principais fatores patogênicos para doenças autoimunes do SNC<sup>42</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A teriflunomida é um medicamento imunomodulador, com propriedades anti-inflamatórias, que inibe seletiva e reversivelmente a enzima mitocondrial di-hidro-orotato desidrogenase. Essa enzima ocupa a quarta posição na via biossintética da pirimidina, ocasionando, consequentemente, a inibição de nova síntese desta substância e um efeito citostático subsequente na proliferação de linfócitos T<sup>43,44</sup> . No entanto, o mecanismo de ação exato para efeitos terapêuticos em pacientes com EM ainda é desconhecido, e as evidências sugerem que envolve uma redução no número de linfócitos ativados capazes de migrarem para o SNC<sup>44–46</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O fumarato de dimetila (DMF, do inglês _Dimethyl Fumarate_ ) é um medicamento cujo mecanismo de ação pelo qual exerce efeito terapêutico na EM não é totalmente compreendido. No entanto, sua eficácia clínica tem sido atribuída, principalmente, a um efeito modulador nas células T. Foi demonstrado que o fumarato de dimetila diminui o número total de células T circulantes, com uma redução desproporcional do subconjunto CD8+<sup>47</sup> . Além desses efeitos diretos nas células T, estudos indicam que o DMF reduz a atividade pró-inflamatória das células apresentadoras de antígeno, como monócitos e células dendríticas<sup>48,49</sup> .  
Ademais, recentemente foi proposto que o mecanismo molecular chave do DMF pode ser decorrente de uma regulação negativa geral de glicólise, especialmente em células com alto _turnover_ metabólico, o que explica, de modo plausível, o motivo de o DMF afetar, principalmente, células T efetoras e de memória<sup>50</sup> . Além disso, presume-se que o DMF diminua as respostas inflamatórias por apresentar outras propriedades, incluindo a ativação do fator nuclear eritroide-2 relacionado ao fator 2 (Nrf2) da via de transcrição<sup>51,52</sup> .  
Os dados de efetividade avaliados indicam que o DMF não seja uma opção superior ao fingolimode e natalizumabe, embora haja potenciais benefícios em relação à segurança, além de um melhor perfil de adesão e eventos adversos<sup>53</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O fingolimode é indicado nos casos de toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou histórico de falha nas opções de primeira linha. Trata-se de um composto altamente lipofílico e um pró-fármaco que é metabolizado _in vivo_ pela enzima esfingosinaquinase no metabólito ativo fingolimode-fosfato ( _fingolimod-P_ ), um modulador não seletivo dos receptores de esfingosina-1-fosfato (S1PRs)<sup>54</sup> . Embora não totalmente esclarecida, a atividade moduladora do S1PR se traduz em um bloqueio da migração de linfócitos T dos linfonodos para o SNC, reduzindo assim a atividade inflamatória e as respostas autoimunes específicas da mielina<sup>54,55</sup> . Desse modo, o fingolimode reduz os surtos e atrasa a progressão da incapacidade em pacientes com EMRR<sup>54,56</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O natalizumabe é o medicamento preconizado como terceira linha de tratamento de pacientes com EMRR de baixa ou moderada atividade da doença em que se observou toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou falha terapêutica aos medicamentos de primeira e segunda linhas. Além disso, o natalizumabe é indicado como primeira opção de tratamento para casos de EMRR altamente ativa, sejam eles virgens de tratamento ou não (ou seja, aqueles que já estão em uso de outros MMCD).  
Trata-se de um anticorpo monoclonal humanizado que inibe seletivamente molécula de adesão e liga-se à subunidade α4β1 da integrina, altamente expressa na superfície de todos os leucócitos com exceção dos neutrófilos<sup>57</sup> . Esta ligação bloqueia a interação entre a integrina e seu receptor cognato, a molécula-1 de adesão às células vasculares (VCAM-1), que se expressa na superfície do endotélio vascular, e ligantes como a fibronectina e a osteopontina<sup>24,58</sup> .  
9  
O mecanismo de ação específico do natalizumabe na EM não foi totalmente definido. No entanto, sabe-se que no quadro da inflamação do SNC é a interação do α4β1 com a VCAM-1, CS-1 e a osteopontina que intermedeia a adesão e a transmigração de leucócitos para o parênquima cerebral, podendo perpetuar a cascata inflamatória no tecido do SNC<sup>24</sup> . O bloqueio das interações moleculares de α4β1 com os respectivos alvos reduz a atividade inflamatória presente no cérebro devido EM e inibe a progressão do recrutamento de células imunogênicas para os tecidos inflamados, reduzindo, assim, a formação ou o aumento das lesões resultantes da EM<sup>24</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A cladribina oral é preconizada para casos de EMRR com alta atividade da doença em que se observou falha ou contraindicação ao uso de natalizumabe.  
Trata-se de um nucleosídeo análogo da desoxiadenosina. Uma substituição de um átomo de cloro no anel de purina faz com que a molécula de cladribina torne-se resistente à degradação pela adenosina deaminase (ADA), aumentando o período de residência intracelular do pró-fármaco cladribina. A fosforilação subsequente da cladribina em sua forma ativa de trifosfato, 2- cloro-desoxiadenosina-trifosfato (Cd-ATP), é obtida nos linfócitos devido aos seus níveis altos de desoxicitidina cinase (DCK) e relativamente baixos de 5'-nucleotidase (5'-NTase). Uma razão elevada de DCK para 5'-NTase favorece o acúmulo de CdATP, tornando os linfócitos particularmente suscetíveis à morte celular. Por possuírem uma razão de DCK/5'-NTase mais baixa, as outras células derivadas da medula óssea são menos afetadas do que os linfócitos. A DCK é a enzima limitante da velocidade de conversão do pró-fármaco da cladribina em sua forma de trifosfato ativo, levando à depleção seletiva de células T e B em divisão e em repouso.  
O principal mecanismo de indução da apoptose da Cd-ATP tem ações diretas e indiretas na síntese de DNA e na função mitocondrial. Nas células em divisão, a Cd-ATP interfere com a síntese de DNA pela inibição de ribonucleotídeo redutase e compete com a desoxiadenosina trifosfato na incorporação no DNA pela DNA polimerase. Nas células em repouso, a cladribina provoca quebras nas cadeias simples de DNA, consumo rápido de dinucleotídeos de nicotinamida adenina, depleção de ATP e morte celular. Existe evidência de que a cladribina também pode causar apoptose direta dependente e independente de caspases por meio da liberação do citocromo c e do fator de indução de apoptose no citosol de células em repouso.  
O mecanismo pelo qual a cladribina exerce seus efeitos terapêuticos na EM não está totalmente elucidado, porém seu efeito predominante sobre os linfócitos T e B é possivelmente capaz de interromper a cascata de eventos imunes fundamentais para a EM.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O alentuzumabe é preconizado para casos de EMRR com alta atividade da doença em que se observou falha ou contraindicação ao uso de cladribina oral.  
Trata-se de um anticorpo monoclonal anti-CD52 IgG1 humanizado que tem o papel de inibir as células que expressam CD52 da circulação. O CD52 é uma glicoproteína de superfície celular ligada à membrana celular por uma âncora de glicosilfosfatidilinositol de 12 aminoácidos<sup>59</sup> . O CD52 é uma das glicoproteínas de membrana mais abundantes em linfócitos T e B e é expresso em células natural killer (NK), monócitos, macrófagos, células dendríticas e granulócitos eosinofílicos e em menor extensão em granulócitos neutrofílicos<sup>59,60</sup> .  
A função exata do CD52 é desconhecida, mas sugere-se que a molécula pode estar envolvida na coestimulação de linfócitos T, na indução de linfócitos T reguladores e na migração e adesão de linfócitos T. A administração de alentuzumabe causa uma depleção profunda de linfócitos T e B, células NK, células dendríticas, granulócitos e monócitos por três mecanismos: citotoxicidade dependente do complemento, citotoxicidade celular dependente de anticorpos e indução de apoptose<sup>61</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
10

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Para pacientes com EMRR de baixa ou moderada atividade é preconizado o tratamento conforme as seguintes linhas terapêuticas:  
**1ª linha:** Betainterferonas, glatirâmer ou teriflunomida ou fumarato de dimetila ou azatioprina, em casos de toxicidade (intolerância, hipersensibilidade ou outro evento adverso), falha terapêutica ou falta de adesão a qualquer medicamento da primeira linha de tratamento, é permitida a troca por outra classe de medicamento de primeira linha.  
A azatioprina é considerada uma opção menos eficaz e só deve ser utilizada em casos de pouca adesão às formas parenterais (intramuscular, subcutânea ou endovenosa).  
**2ª linha:** Fingolimode, indicado em casos de falha terapêutica, reações adversas ou resposta sub ótima a qualquer medicamento da primeira linha de tratamento.  
**3ª linha:** Natalizumabe, indicado em casos de falha ou contraindicação ao uso de fingolimode.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Para pacientes com EMRR altamente ativa é preconizado o tratamento conforme as linhas terapêuticas a seguir:  
**1ª linha:** Natalizumabe, indicado como primeira opção de tratamento para pacientes com EMRR em alta atividade da doença, com comprovação por meio de relatório médico e exame de neuroimagem (ressonância magnética), sejam eles virgens de tratamento ou estejam em qualquer outra linha de tratamento.  
- **2ª linha:** Cladribina oral, indicada em casos de falha no tratamento ou contraindicação ao uso de natalizumabe.  
- **3ª linha:** Alentuzumabe, indicado em casos de falha no tratamento ou contraindicação ao uso de cladribina oral.  
Após tratamento e controle da fase de alta atividade da doença, o paciente pode ser realocado para qualquer outra linha  
de tratamento da EM de baixa ou moderada atividade. A **Figura 1** esquematiza o tratamento medicamentoso com MMCD dos pacientes com EM.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A EM pode acometer crianças e adolescentes. Nestes casos, recomenda-se que o neurologista solicite uma avaliação para afastar leucodistrofias. Confirmada a doença, pode-se tratar com betainterferonas (qualquer representante da classe farmacêutica), fingolimode (se o paciente tiver mais de 10 anos de idade) ou glatirâmer. Inexistem ensaios clínicos que tenham incluído doentes desta faixa etária, sendo os melhores estudos de segurança do tratamento de crianças e adolescentes as séries de casos<sup>62–64</sup> em que se demonstra bom perfil de segurança. A teriflunomida, o fumarato de dimetila, o natalizumabe, a cladribina oral e o alentuzumabe não estão aprovados para uso por menores de 18 anos, não havendo ensaios clínicos com crianças e adolescentes<sup>24,45,51,55,61,65</sup> , razões pelas quais não são preconizados neste Protocolo para essa faixa etária.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Na gestação, as manifestações clínicas da doença ficam mais brandas, com redução relevante da taxa de surtos principalmente no primeiro trimestre; e aumento da incidência de surtos imediatamente após o puerpério<sup>66–69</sup> . Em casos de evolução favorável da doença (pontuação na EDSS classificada como estável e baixo, baixa taxa de surtos), preconiza-se não usar imunomodulador nem imunossupressor por possuírem perfil de segurança incerto na gestação.  
A teriflunomida e a cladribina oral são contraindicadas para uso por gestantes (categoria de risco X)<sup>45,65</sup> . Mulheres com potencial para engravidar devem evitar engravidar por meio de métodos contraceptivos eficazes durante tratamento com cladribina e por pelo menos 6 meses após a última dose. A betainterferona 1a é classificada na categoria de risco B para gravidez  
11  
e pode ser utilizada sob recomendação médica, se clinicamente necessário<sup>36-70</sup> . Com relação aos demais MMCD, seu uso deve ser considerado para casos em que a evolução clínica da doença se mostra desfavorável, de forma que os benefícios do tratamento para a mãe superem o risco para o feto.  
As evidências indicam não haver diferença entre mães expostas ou não expostas a MMCD (betainterferona 1b, glatirâmer e natalizumabe) para a incidência dos desfechos de morte fetal, aborto espontâneo, aborto induzido, anomalias congênitas, nascimentos prematuros e número de nascidos vivos. Na comparação específica entre mães expostas e não expostas ao betainterferona 1b, foi identificada maior incidência de aborto espontâneo entre as mães que utilizaram betainterferona 1b durante a gestação, apesar de os dados pós-comercialização do medicamento sugerirem frequências de aborto espontâneo e anomalias congênitas comparáveis com a experiência de risco estimado na população em geral. Similarmente, foram identificados mais casos de abortos induzidos entre mães expostas ao glatirâmer durante a gestação, comparativamente às não expostas. Evidências sobre a segurança do uso de fingolimode, fumarato de dimetila e alentuzumabe em mulheres grávidas não foram identificadas. A indicação do tratamento, à luz das evidências, deve ser feita pelo médico assistente, considerando tanto a saúde da mãe quanto a do bebê.  
Pacientes do sexo masculino devem adotar precauções para evitar engravidar sua parceira durante tratamento com cladribina e por pelo menos 6 meses após a última dose.  
Há dúvidas acerca dos riscos de amamentar, e os dados disponíveis na literatura sobre o assunto são escassos. Devido ao potencial de reações adversas graves nos lactentes, a amamentação é contraindicada durante o tratamento com cladribina oral e durante 1 semana após sua última dose<sup>65</sup> . Embora os dados da literatura sobre a transferência de betainterferona 1a para o leite materno sejam limitados, o benefício e o risco potencial da amamentação devem ser considerados juntamente com a necessidade terapêutica da mãe com o uso de betainterferona 1a<sup>70</sup> . Quanto aos demais MMCD, preconiza-se não amamentar durante o tratamento medicamentoso.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A EM é uma doença do SNC com sintomas variáveis em múltiplos outros sistemas. Entre as principais manifestações da EM estão déficits cognitivos e de memória, disfunção intestinal, tremores, ataxia, espasticidade (que engloba rigidez e espasmos musculares), mobilidade reduzida (a qual pode ocorrer com o declínio gradual da função, devido à fraqueza muscular, espasticidade, alterações de equilíbrio, coordenação e déficits visuais), e fadiga. O tratamento da EM envolve intervenções não medicamentosas que visam à redução da incapacidade e a melhoria da qualidade de vida, o que, em geral, requer uma equipe multidisciplinar que inclua fisioterapeuta, enfermeiros, psicólogo, terapeuta ocupacional, fonoaudiólogo e médicos de diferentes especialidades. A qualidade da evidência para as intervenções é insuficiente, não sendo possível preconizar condutas terapêuticas específicas para a maioria desses sintomas<sup>26</sup> .  
A avaliação e o acompanhamento multiprofissional e multidisciplinar incluem consultas com psicólogo e psiquiatra para tratar depressão e outras manifestações psíquicas, com fisioterapeuta e terapeuta ocupacional, incluindo aconselhamento sobre postura corporal; e com fonoaudiólogo, para distúrbios da fala e complicações afins. Os profissionais da saúde devem incentivar os pacientes a se exercitarem continuamente para obterem benefícios a longo prazo, alertando que exercícios não supervisionados e treinamento de resistência de alta intensidade se associam a risco de lesões. Mas programas de exercícios supervisionados envolvendo treinamento de resistência progressivo moderado, exercícios aeróbicos em caso de pacientes com mobilidade reduzida ou fadiga e reabilitação vestibular para aqueles com desordem do equilíbrio, além de alongamento e ioga, podem ser medidas benéficas. As necessidades das pessoas com EM e o tipo de reabilitação apropriada variam. Os fatores que influenciam a reabilitação apropriada incluem a disponibilidade de assistência domiciliar, a localização geográfica, as metas individuais e o tipo de reabilitação necessária. Porém, não se sabe até o momento qual tipo de reabilitação apresenta maior eficácia<sup>26,71,80,72–79</sup> .  
12  
Nos casos de fadiga, espasticidade, disfunção intestinal, disfunção erétil e disfunção vesical, devido à complexidade dos sintomas, diagnósticos diferenciais, comorbidades e especificidades da EM, recomenda-se preferencialmente encaminhar o doente para um serviço especializado e que a decisão terapêutica seja individualizada. O tratamento da infecção urinária em pacientes com EM é semelhante ao tratamento de outros pacientes com a mesma infecção. Em geral, o tratamento consiste em uma sucessão ou combinação de antimicrobianos. A determinação do melhor antimicrobiano irá depender dos resultados dos exames do paciente, como por exemplo a urocultura, e da escolha médica<sup>81–84</sup> .  
É estimado que a dor crônica afete mais de 40% dos pacientes com EM. Com relação à dor neuropática, os estudos apresentam alto risco de viés e evidência insuficiente. O Ministério da Saúde tem PCDT da Dor Crônica, inclusive da dor neuropática, e, quando necessário, deve-se encaminhar os pacientes para um serviço especializado no tratamento de dor. Devese avaliar a dor musculoesquelética, que é comum em pacientes com EM, sendo essa dor usualmente secundária a alterações de mobilidade e postura. A acupuntura é comumente utilizada no tratamento de distúrbios osteomusculares e de dor. Alguns benefícios para função e dor musculoesqueléticas foram demonstrados e alguns eventos adversos foram identificados. A qualidade da evidência para o tratamento com acupuntura foi considerada de nível baixo a muito baixo<sup>26,85</sup> .  
Todos os pacientes com EM devem ser questionados acerca do funcionamento intestinal. A origem da disfunção intestinal é muitas vezes multifatorial, envolvendo o uso de múltiplos medicamentos, eventos adversos de medicamentos, dieta pobre em fibras, sedentarismo, elementos comportamentais, dificuldade de acesso ao banheiro e alterações neurológicas. A intervenção inicial consiste em mudanças do estilo de vida, da alimentação e do hábito intestinal. Disfunção neurogênica intestinal ocorre em 50%-80% dos pacientes com EM devido a lesões na inervação do cólon e pode se manifestar com constipação ou incontinência fecal, que muitas vezes coexistem. A constipação decorre usualmente do tempo de trânsito colônico lento e pode ser exacerbada por dissinergia do assoalho pélvico. Ocorre atraso na transmissão do estímulo motor para o esfíncter anal, assemelhando-se aos pacientes com lesão da medula espinal. As primeiras medidas são conservadoras, como modificação da dieta com aumento de consumo de fibras e de líquidos, mas, em casos de constipação mais intensa e persistente, podem ser necessárias outras intervenções, inclusive invasivas<sup>81,84,86</sup> .  
Transtornos do humor, principalmente depressão e ansiedade, são comuns em pacientes com EM e são muitas vezes desencadeados ou agravados por uma dificuldade em lidar com a doença. O transtorno depressivo tem prevalência entre 36% e 54% e está associado com piora da qualidade de vida, dias de trabalho perdidos, diminuição de adesão ao tratamento e aumento do risco cumulativo de suicídio. O funcionamento cognitivo (processamento mental de memória, concentração, raciocínio e julgamento) também pode ser afetado. Portanto, meios de triagem, como o _Beck Depression Inventory_ e o 2-question tool, devem ser considerados para rastrear transtornos depressivos, assim como o _General Health Questionnaire_ para detectar transtornos emocionais mais amplos. A assistência psicológica pode ajudar as pessoas com EM inclusive no controle de sintomas como dor e fadiga.  
A gravidade da depressão melhorou em nove ensaios clínicos com assistência psicológica, e as intervenções variaram de aconselhamento motivacional à Terapia Cognitivo Comportamental (TCC) em grupo ou individual, sendo que a maioria dos estudos avaliou a TCC. Em meta-análise, foi calculada a média padronizada das diferenças (do inglês, _Standardized Mean Differences_ - SMD) e o tamanho do efeito encontrado ao se analisar os nove estudos (SMD= -0,45) indica que as intervenções psicológicas são ao menos moderadamente eficazes para tratar depressão em pacientes com EM [N=307; SMD= -0,45 (IC 95%: -0,74, -0,16)]. Não houve diferença quando se comparou a TCC com outra terapia (p=0,91). Com relação às evidências de intervenções medicamentosas, elas ainda são incipientes e os estudos apresentam pequeno tamanho amostral e muitas limitações. Por isso, muitas vezes os profissionais da saúde se baseiam na literatura da assistência psiquiátrica à população geral; porém, as características da EM podem afetar a segurança, a tolerabilidade e a efetividade do tratamento antidepressivo, sendo necessárias investigações direcionadas e específicas. Até o momento, apenas três Ensaios Clínicos Randomizados (ECR), controlados por  
13  
placebo, foram realizados para avaliar a eficácia do tratamento medicamentoso de transtornos depressivos na EM. Dois fármacos eram inibidores seletivos da recaptação da serotonina (ISRS) e um era tricíclico<sup>26,87,96–100,88–95</sup> .  
A labilidade emocional, também conhecida como efeito pseudobulbar, necessita ser diferenciada de transtorno de humor, pois requer conduta específica e pode ser debilitante, comprometer a funcionalidade e ser acompanhada de outros transtornos psiquiátricos. Um ECR cruzado avaliou a eficácia da amitriptilina comparado ao placebo. Foi demonstrado um benefício clínico relevante em relação ao placebo, sem eventos adversos relatados<sup>100–109</sup> .  
No SUS, para o tratamento do transtorno depressivo e da labilidade emocional, estão disponíveis os medicamentos tricíclicos e os inibidores seletivos da receptação de serotonina, tais como a amitriptilina, a nortriptilina e a fluoxetina. Recomenda-se que se individualize o tratamento de acordo com as especificidades do paciente, observando a resposta, a tolerabilidade e o acompanhamento clínico em cada caso. Além disso, recomenda-se o atendimento especializado dos pacientes com EM e transtorno depressivo. Há evidência suficiente de que o tratamento psicológico é eficaz em ajudar as pessoas com EM a lidar com a sua condição e em melhorar sintomas de transtornos depressivos<sup>26,88,93</sup> .  
Outras manifestações, como mobilidade prejudicada, oscilopsia, tontura e vertigem devem, se necessário, ser cuidadas conforme a manifestação e as alternativas disponíveis.  
**Figura 1.** Algoritmo do tratamento da esclerose múltipla com medicamentos modificadores do curso da doença **.**  
<!-- Start of picture text -->
SET<br>|e6 MeDonals rvsaaee| Bambnzo conmasone<br>|1 paixae MODERADA ATIVIDADE Nao '1 ‘Ata stvidace ‘Sim ! ALTA ATIVIDADE '<br>1 da doenca? 1<br>1 1 1 1<br>' ‘latiramerieou terifunomida ' Pam. 1<br>i ou tumaato de deta ou ! = i<br>1 | i 1 1<br>! ‘i 1 t<br>:![eRe EC sonesaner 2" gna p1'1<br>!<br>'1 / Howe tas Nao 1<br>' i Nao 1 \ contraingicago? 1<br>!11<br>1<br>'ii sim i)<br>'11<br>1<br>!<br>A<br>linha Il 1 t<br>; Fingolmode rmedicamento‘Substituir porde outro1*inna | i clocrtna‘P linhaoat i<br>;<br>' 1 1<br>! Il' 1 t<br>i] Nao ‘Sim __ Alta atividade_Sim 1 1<br>i' 1 ‘ido ' Houvefanar oo '<br>1! T 11 contraindicacdo? ‘tener 1'<br>! 1 t<br>Le<br>! cantandlcaggo‘ingolimode?,ag ________—jST t1 Ateatvigage= 1 sim '1<br>I<br>1<br>Vo eee ee ee ee ee ee ee ee ee ee eee a|<br><!-- End of picture text -->  
***FALHA** poderá ser definida como:  
1) Falha terapêutica (definida como a incidência de pelo menos um surto e evidência de, no mínimo, quatro novas lesões em T2 no período de 12 meses) 2) Intolerância ao medicamento  
3) Reações adversas não controláveis 4) Falta de adesão ao tratamento  
**Será considerada alta atividade de doença (com comprovação por exames clínicos e de imagem):**  
14  
- **a. Para virgens de tratamento** : incidência de dois ou mais surtos incapacitantes com resolução incompleta e evidência de pelo menos uma nova lesão captante no gadolínio ou aumento significativo da carga da lesão em T2 no ano anterior;  
**b. Para pacientes falhados a outro(s) Medicamento Modificador do Curso da Doença (MMCD):** atividade da doença nos últimos 12 meses, durante a utilização adequada de pelo menos um MMCD, na ausência de intolerância ou não adesão, apresentando pelo menos um surto no último ano durante o tratamento e indícios de pelo menos nove lesões hiperintensas em T2 ou pelo menos uma nova lesão captante de gadolínio. **Nota 1** : Após o tratamento e controle da fase de alta atividade da doença, o paciente pode ser realocado para qualquer outra linha de tratamento da EM de atividade baixa ou moderada.  
**Nota 2** : Na ocorrência de surtos, deve-se proceder com os cuidados e tratamento preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
- Acetato de glatirâmer: solução injetável de 20 mg e 40 mg;  
- Alentuzumabe: solução injetável de 10 mg/mL em frasco-ampola contendo 1,2 mL;  
- Azatioprina: comprimido de 50 mg;- Betainterferona 1A: solução injetável de 22 mcg (6.000.000 UI), 30 mcg  
(6.000.000 UI) e de 44 mcg (12.000.000 UI);  
- Betainterferona 1B: solução injetável de 300 mcg (9.600.000 UI);  
- Cladribina oral: comprimidos de 10 mg;  
- Fingolimode: cápsula de 0,5 mg;  
- Fumarato de dimetila: cápsula de 120 mg e 240 mg;  
- Metilprednisolona: pó para solução injetável de 500 mg;  
- Natalizumabe: solução injetável de 20 mg/mL; e  
- Teriflunomida: comprimido de 14 mg.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O **Quadro 2** apresenta os medicamentos disponíveis para o tratamento da esclerose múltipla remitente-recorrente (EMRR).  
**Quadro 2 -** Doses e principais eventos adversos dos medicamentos para EMRR  
|**FÁRMACO**|**VIA**<br>**DE**<br>**ADMINISTRAÇÃO**|**DOSE INICIAL**|**PRINCIPAIS**<br>**EVENTOS**<br>**ADVERSOS**|
|---|---|---|---|
|**TRATAMENTO DOS SUR**|**TOS**|||
|Metilprednisolona<sup>110</sup>|Via intravenosa|1g, 1x ao dia, por 3 ou<br>5 dias|Disfunção/distúrbio<br>miccional<br>gastrintestinal funcional, cefaleia,<br>meningite, paraparesia/ paraplegia,<br>convulsões, distúrbios sensitivos|
|**TRATAMENTO DA EMR**|**R DE BAIXA OU MODERAD**|**A ATIVIDADE**||
|**PRIMEIRA LINHA**||||
|Betainterferona 1a<sup>111</sup>|Via intramuscular|30 µg (6 MUI), 1x<br>semana|Mialgia, febre, calafrios, sudorese,|
|Betainterferona 1a<sup>112,38</sup>|Via subcutânea|22 µg (6 MUI), 3x<br>semana|astenia, cefaleia e náusea|  
15  
|**FÁRMACO**|**VIA**<br>**D**<br>**ADMINISTRAÇÃO**|**E**<br>**DOSE INICIAL**|**PRINCIPAIS**<br>**EVENTOS**<br>**ADVERSOS**|
|---|---|---|---|
|||44 µg (12 MUI), 3x<br>semana||
|||0,25 mg (8 milhões de||
|Betainterferona 1b<sup>113</sup>|Via subcutânea|MUI),<br>em<br>dias<br>alternados||
|Acetato de glatirâmer<sup>35</sup>|Via subcutânea|20 mg, 1x ao diaOU<br>40 mg, 3x por semana|Infecção, gripe, dispneia, náusea,<br>artralgia, dorsalgia, astenia, dor<br>torácica e algia|
||||Cefaleia, diarreia, náusea, alopecia e|
|Teriflunomida<sup>45</sup>|Via oral|14 mg, 1x ao dia|aumento<br>das<br>transaminases<br>hepáticas|
|Fumarato de dimetila<sup>51</sup>|Via oral|120 mg, 2x ao dia por<br>7 dias; e 240 mg, 2x ao<br>dia|Rubor e eventos gastrointestinais<br>(diarreia, náusea, dor abdominal,<br>dor abdominal superior)|
|Azatioprina<sup>114</sup>|Via oral|1-3 mg/kg de peso<br>corporal ao dia|Infecções<br>virais,<br>fúngicas<br>e<br>bacterianas; leucopenia, anemia,<br>colestase,<br>hipersensibilidade,<br>disfunção hepática|
|**SEGUNDA LINHA**||||
||||Tosse, diarreia, dor nas costas,|
|Fingolimode<sup>55</sup>|Via oral|0,5 mg, 1x ao dia|cefaleia,<br>infecções<br>virais<br>por<br>_influenza_, sinusite, elevação nas<br>enzimas hepáticas (aumento da<br>ALT, GGT, AST).|
|**TERCEIRA LINHA**||||
|Natalizumabe<sup>24</sup><br>**TRATAMENTO DA EMR**<br>**PRIMEIRA LINHA**|Via intravenosa<br>**R DE ALTA ATIVIDADE**|300 mg, a cada 4<br>semanas|Dor de cabeça, fadiga, artralgia,<br>infecção<br>do<br>trato<br>urinário<br>e<br>respiratório inferior, gastroenterite,<br>vaginite,<br>depressão,<br>dor<br>nas<br>extremidades,<br>desconforto<br>abdominal, diarreia e erupções<br>cutâneas|
|Natalizumabe<sup>24</sup>|Via intravenosa|300 mg, a cada 4<br>semanas|Dor de cabeça, fadiga, artralgia,<br>infecção<br>do<br>trato<br>urinário<br>e|  
16  
|**FÁRMACO**|**VIA**<br>**DE**<br>**ADMINISTRAÇÃO**|**DOSE INICIAL**|**PRINCIPAIS**<br>**EVENTOS**<br>**ADVERSOS**|
|---|---|---|---|
||||respiratório inferior, gastroenterite,<br>vaginite,<br>depressão,<br>dor<br>nas<br>extremidades,<br>desconforto<br>abdominal, diarreia e erupções<br>cutâneas|
|**SEGUNDA LINHA**||||
|Cladribina|Oral|3,5 mg/kg de peso<br>corporal em 2 anos|Linfopenia,<br>bolhas<br>nos<br>lábios<br>(herpes oral), herpes zoster com<br>manifestação na pele, erupção na<br>pele, queda de cabelo e pelos,<br>diminuição<br>do<br>número<br>de<br>neutrófilos|
|**TERCEIRA LINHA**||||
|Alentuzumabe<sup>61</sup>|Via intravenosa|12 mg/dia<br>Tratamento inicial:5<br>dias<br>consecutivos<br>(dose total de 60 mg)<br>Ciclos adicionais:3<br>dias<br>consecutivos<br>(dose total de 36 mg),<br>administrados<br>pelo<br>menos<br>12<br>meses<br>depois do tratamento<br>anterior|Linfopenia, leucopenia, taquicardia,<br>hipertireoidismo, náusea, pirexia,<br>fadiga, calafrios, infecção do trato<br>urinário,<br>infecção<br>do<br>trato<br>respiratório<br>superior,<br>cefaleia,<br>erupção cutânea, urticária, prurido,<br>erupção<br>cutânea<br>generalizada,<br>ruborização|  
**Nota 1:** O tratamento inicial com alentuzumabe contempla 2 ciclos de uso do medicamento com o intervalo de 12 meses entre eles. Em alguns pacientes, no entanto, pode ser necessário retratamento com ciclos adicionais (terceiro ou quarto ciclo de tratamento), que devem ser administrados, pelo menos, 12 meses depois do ciclo anterior.  
**Nota 2** : O tratamento com cladribina oral deve ser iniciado e supervisionado por médico com experiência no tratamento da esclerose múltipla.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
A dose cumulativa recomendada da cladribina oral é de 3,5 mg/kg de peso corporal em 2 anos, administrada como 1 ciclo de tratamento de 1,75 mg/kg por ano. Cada ciclo de tratamento consiste em 2 semanas de tratamento, uma no início do primeiro mês e outra no início do segundo mês do respectivo ano de tratamento. Cada semana de tratamento consiste em 4 ou 5 dias nos quais o paciente recebe 10 mg ou 20 mg (um ou dois comprimidos) como dose única diária, em função do peso corporal.  
A dose estimada por semana de tratamento é determinada conforme o peso do paciente (Quadro 3). Após definida a dose e a quantidade de comprimidos a ser administrada na semana, a periodicidade e o número de comprimidos a serem administrados devem seguir as orientações do Quadro 4.  
Após a conclusão dos 2 ciclos de tratamento, não são necessários tratamentos adicionais com cladribina nos anos 3 e 4.  
17  
**Quadro 3 -** Dose de cladribina oral por semana de tratamento e por peso de paciente em cada ano de tratamento  
|**Faixa de peso do paciente (kg)**|**Dose em mg (número de compri**|**midos de 10 mg) por semana de tratamento**|
|---|---|---|
||**Semana 1**|**Semana 2**|
|40 a <50|40 mg (4 comprimidos)|40 mg (4 comprimidos)|
|50 a <60|50 mg (5 comprimidos)|50 mg (5 comprimidos)|
|60 a <70|60 mg (6 comprimidos)|60 mg (6 comprimidos)|
|70 a <80|70 mg (7 comprimidos)|70 mg (7 comprimidos)|
|80 a <90|80 mg (8 comprimidos)|70 mg (7 comprimidos)|
|90 a <100|90 mg (9 comprimidos)|80 mg (8 comprimidos)|
|100 a <110|100 mg (10 comprimidos)|90 mg (9 comprimidos)|
|110 e acima|100 mg (10 comprimidos)|100 mg (10 comprimidos)|  
Fonte: Bula do medicamento cladribina oral<sup>65</sup>  
**Quadro 4 –** Periodicidade e quantidade de comprimidos de cladribina oral de 10 mg durante a semana de tratamento.  
|**Número**<br>**comprimid**|**total**<br>**de**<br>**os por semana**|**Dia 1**|**Dia 2**|**Dia 3**|**Dia 4**|**Dia 5**|
|---|---|---|---|---|---|---|
|4||1|1|1|1|0|
|5||1|1|1|1|1|
|6||2|1|1|1|1|
|7||2|2|1|1|1|
|8||2|2|2|1|1|
|9||2|2|2|2|1|
|10||2|2|2|2|2|  
Fonte: Bula do medicamento cladribina oral<sup>65</sup>

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Os medicamentos preconizados por este Protocolo são contraindicados para pessoas que apresentem:

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade conhecida ao acetato de glatirâmer ou manitol.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade à substância ativa ou a qualquer um dos excipientes;  
Vírus da Imunodeficiência Humana (HIV);  
Infecção ativa grave até a resolução completa da infecção;  
Hipertensão não controlada;  
História de dissecção arterial das artérias cervicocefálicas;  
História de acidente vascular cerebral;  
História de angina de peito ou infarto do miocárdio;  
Coagulopatia conhecida, em terapia antiplaquetária ou anticoagulante.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade conhecida à azatioprina ou a qualquer outro componente da fórmula. A hipersensibilidade à  
mercaptopurina deve alertar o médico quanto à provável hipersensibilidade a azatioprina.  
18

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade à betainterferona recombinante ou natural, ou a qualquer outro excipiente da formulação;  
Depressão grave e/ou ideação suicida.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
História de hipersensibilidade à betainterferona natural ou recombinante ou a qualquer excipiente do produto.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade à cladribina ou a qualquer um dos excipientes do comprimido;  
Infecção com o vírus da imunodeficiência humana (HIV);  
Infecção crônica ativa (tuberculose ou hepatite);  
Início do tratamento com cladribina em pacientes imunocomprometidos, incluindo pacientes atualmente recebendo  
terapia com imunossupressores ou mielossupressores;  
Malignidade ativa;  
Insuficiência renal moderada ou grave (depuração da creatinina < 60 mL/min);  
Gravidez e lactação.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Conhecida hipersensibilidade ao fingolimode ou a qualquer um dos excipientes;  
Ocorrência recente (últimos 06 meses) de infarto do miocárdio, derrame, angina instável, ataque isquêmico transitório,  
insuficiência cardíaca descompensada necessitando hospitalização, insuficiência cardíaca classe III/IV;  
Histórico ou presença de bloqueio atrioventricular de 2º grau com Mobitz tipo II ou 3º grau do bloqueio atrioventricular,  
doença do nó sinusal (exceto o paciente que faz uso de marca-passo);  
Hipertensão arterial não controlada, apneia do sono grave não tratada;  
Uso de medicamentos antiarrítmicos classe Ia ou classe III;  
Intervalo de QT maior ou igual a 500 ms;  
Insuficiência hepática grave ( _Child-Pugh_ classe C).

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade ao fumarato de dimetila ou a qualquer outro componente da fórmula;  
LEMP suspeita ou confirmada.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Infecções sistêmicas por fungos;  
Hipersensibilidade conhecida à metilprednisolona ou a qualquer componente da fórmula;  
O uso pelas vias de administração intratecal e epidural é contraindicado.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade ao natalizumabe, ou a qualquer outro componente da fórmula;  
LEMP;  
Pacientes que apresentem maior risco de manifestação de infecções oportunistas, incluindo pacientes imunocomprometidos (aqueles que estão atualmente em tratamento com medicamentos imunossupressores ou aqueles  
imunocomprometidos por terapias anteriores, por exemplo com mitoxantrona ou ciclofosfamida);  
A combinação de natalizumabe com betainterferonas e acetato de glatirâmer;  
Pacientes com câncer, exceto no caso de pacientes com carcinoma das células basais cutâneas.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Hipersensibilidade conhecida à teriflunomida, leflunomida ou a qualquer um dos componentes da formulação;  
19  
Insuficiência hepática grave;  
Mulheres grávidas, ou mulheres com potencial de engravidar e que não estejam utilizando métodos contraceptivos confiáveis, durante o tratamento com teriflunomida e por todo o tempo em que o nível plasmático esteja acima de 0,02 mg/L.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Serão considerados critérios de interrupção do uso do respectivo medicamento: a incapacidade do paciente de adesão ao tratamento, a impossibilidade de monitorização dos eventos adversos e a toxicidade (intolerância, hipersensibilidade ou outro evento adverso) do medicamento.  
O tempo de tratamento ou a troca de medicamento são determinados pela falha terapêutica ou pelo surgimento de eventos adversos intoleráveis, após considerar todas as medidas para sua atenuação.  
Considera-se falha terapêutica a incidência de pelo menos um surto e evidência de no mínimo quatro novas lesões em T2 ao exame de ressonância magnética no período de um ano, durante tratamento medicamentoso adequado<sup>115</sup> . Tais critérios são válidos para qualquer dos tratamentos preconizados.  
Pacientes de ambos os sexos que planejam conceber e engravidar devem observar as seguintes condutas de interrupção: pacientes masculinos e femininos em uso de teriflunomida e cladribina oral devem utilizar métodos contraceptivos eficazes para evitar a concepção devido à teratogenicidade desses medicamentos; pacientes em uso de fumarato de dimetila e fingolimode devem evitar engravidar enquanto estiverem utilizando estes medicamentos; pacientes que planejam a gravidez devem engravidar somente após dois meses de interrupção do tratamento com fingolimode, após quatro meses de interrupção do tratamento com alentuzumabe ou após seis meses de interrupção da cladribina; pacientes em uso de teriflunomida e que planejam a gravidez devem engravidar somente quando o nível sérico do fármaco for igual ou menor que 0,02 mcg/mL; pacientes masculinos e femininos devem adotar medidas contraceptivas adequadas em uso de azatioprina<sup>27,29–31,113</sup> .  
O aleitamento materno deve ser suspenso durante cada ciclo de tratamento com alentuzumabe e por quatro meses depois da última infusão de cada ciclo de tratamento.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
- Aumento da sobrevida global (considerando morte e surtos);  
- Aumento da sobrevida livre de surtos;  
- Ausência de progressão da incapacidade, medida pelo EDSS;  
- Ausência de eventos adversos graves, principalmente infecciosos (por exemplo, LEMP).  
- Melhora sintomática;  
- Diminuição da frequência e gravidade das recorrências; e  
- Redução do número de internações hospitalares.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Na maioria dos casos, o monitoramento dos pacientes é clínico-laboratorial. O monitoramento dos eventos adversos dos medicamentos ou classe de medicamentos deve ser feito de acordo com o medicamento específico em uso.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento dos pacientes é clínico-laboratorial. Observar as taxas e gravidades dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos. Os seguintes exames básicos devem ser solicitados: hemograma completo (eritrograma, leucograma e plaquetas), enzimas hepáticas (AST/TGO, ALT/TGP e fosfatase alcalina), bilirrubina total e TSH  
20  
(hormônio tireotrófico). As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses), relato de eventos adversos e resultados dos exames laboratoriais (a cada 30, 60 e 180 dias do início do uso do medicamento, seguida por monitorização a cada 6 meses).  
Os eventos adversos mais frequentes com o uso de betainterferona são: síndrome gripal ou uma combinação de febre, calafrios, mialgia, indisposição e sudorese; distúrbios psíquicos (depressão, ansiedade e instabilidade emocional); cefaleia; dor abdominal; incontinência urinária; alterações menstruais; erupção cutânea; reação no local de injeção (inflamação, abscesso, necrose ou outro tipo de complicação)<sup>70,111–113</sup> .  
**Alterações da função tireoidiana** . Alterações da função tireoidiana foram observadas em pacientes em uso de betainterferona<sup>116–120</sup> . Pacientes em tratamento com betainterferona podem ocasionalmente desenvolver ou agravar distúrbios da tireoide<sup>70,111–113</sup> . Recomenda-se a realização do exame de TSH e avaliação de função tireoidiana antes de iniciar-se o tratamento e o seu monitoramento, caso estejam fora dos limites normais.  
**Alterações de hemograma** . As anormalidades laboratoriais mais comumente observadas são linfopenia, neutropenia e leucopenia. Essas alterações raramente são graves e sempre reversíveis. Contagens sanguíneas completas e diferenciais devem ser obtidas antes do início do tratamento e acompanhadas regularmente pelo médico assistente. Se as alterações laboratoriais ficarem abaixo dos seguintes limites, a dose deverá ser temporariamente reduzida<sup>121–123</sup> :  
- hemoglobina menor de 10g/dL;  
- leucócitos abaixo de 3.000/mm<sup>3</sup> ;  
- neutrófilos abaixo de 1.500/mm<sup>3</sup> ;  
- linfócitos abaixo de 1.000/mm<sup>3</sup> ; e  
- plaquetas abaixo de 75.000/mm<sup>3</sup> .  
Se ocorrerem desvios extremos dos valores normais, preconiza-se a suspensão do medicamento. Quando os valores se normalizam, geralmente é possível um aumento gradual da dose, sem que ocorram complicações ou intercorrências<sup>123</sup> .  
**Alterações da função hepática** . O uso do medicamento pode causar disfunção hepática com elevação das enzimas e da bilirrubina. Casos de lesão hepática, incluindo hepatite, também foram relatados com o uso de betainterferona. A ocorrência de elevação nos níveis de enzimas hepáticas e da bilirrubina deve ser investigada e monitorada minuciosamente. Se os níveis se tornarem significativamente elevados ou se existirem sintomas ou sinais clínicos associados, como icterícia, deve-se considerar a interrupção do tratamento. Após a normalização laboratorial da função hepática e na ausência de evidência clínica de lesão hepática, pode-se considerar a reintrodução do medicamento com o acompanhamento apropriado<sup>70,111–113</sup> (Quadro 5).  
**Quadro 5 -** Orientações para monitoramento da função hepática de pacientes em uso de IFN-β  
|**Medicamentos**|**Alterações hepáticas**|**Monitoramento**|
|---|---|---|
|IFN-β (1a ou 1b):|Grau 1|Manter tratamento e monitorar.|
|- IFN-1a (22 mcg)|ALT 1 a ≤3 vezes (x) LSN||
|- IFN-1a (30 mcg)|AST 1 a ≤3 x LSN||
|- IFN-1a (44 mcg)|FA  1 a ≤2,5 x LSN||
|- IFN-1b (300 mcg)|BT  1 a ≤1,5 x LSN||
||Grau 2|Interromper a IFN-β, reiniciando seu uso|
||ALT 3 a 5 x LSN|quando as enzimas hepáticas estiverem: ALT e|
||AST 3 a 5 x LSN||  
21  
|**Medicamentos**|**Alterações hepáticas**|**Monitoramento**|
|---|---|---|
||FA  2,5 a 5 x LSN<br>BT  1,5 a 3 x LSN|AST abaixo de 3 x LSN; FA abaixo de 2,5 x<br>LSN; BT abaixo de 1,5 x LSN.|
||Grau 3<br>ALT >5 a 20 x LSN<br>AST >5 a 20 x LSN<br>FA >5 a 10 x LSN<br>BT >3 a 10 x LSN|Interromper a IFN-β, reiniciando seu uso<br>quando as enzimas hepáticas estiverem: ALT e<br>AST abaixo de 3 x LSN; FA abaixo de 2,5 x<br>LSN; BT abaixo de 1,5 x LSN. Grau 3 de forma<br>recorrente, suspender tratamento.|
||Grau 4<br>ALT >20 x LSN<br>AST >20 x LSN<br>FA >20 x LSN<br>BT ou icterícia >10 x LSN|Suspender tratamento.|  
Fonte: Elaboração própria<sup>70</sup>  
Legenda: AST/TGO: aspartato aminotransferase/transaminase glutâmico-oxalacética; ALT/TGP: alanina aminotransferase/transaminase glutâmico-pirúvica/; FA: Fosfatase Alcalina; BT: Bilirrubina Total; LSN: limite superior da normalidade.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento é clínico (taxa de surtos, EDSS e eventos adversos) e não são exigidos exames laboratoriais. O medicamento pode apresentar uma reação adversa imediata pós-injeção: vasodilatação, dor torácica, dispneia, palpitação ou taquicardia, ansiedade, sensação de fechamento da garganta e urticária. Em geral, estes sintomas aparecem vários meses após o início do tratamento, embora possam ocorrer no início do tratamento e certos pacientes possam apresentar um ou vários desses sintomas<sup>35</sup> . As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.  
As reações adversas mais frequentes são as que ocorrem no local da injeção: eritema, algia, nódulo, prurido, edema, inflamação, hipersensibilidade e ocorrências de lipoatrofia e necrose de pele. A lipoatrofia é do tipo involucional ou reação de corpo estranho, sendo considerada como permanente. Para auxiliar na possível diminuição desses eventos, o paciente deve ser orientado a seguir adequadamente as técnicas de injeção e fazer rodízio dos locais de injeção diariamente. Os pacientes devem ter os locais de aplicação frequentemente examinados por inspeção visual e palpação<sup>34,35</sup> .  
Os eventos adversos não localizados mais comuns podem ser agrupados de acordo com a seguinte convenção: muito comum (incidência ≥10%) e comum (incidência entre 1% e 10%). Os eventos adversos muito comuns são: infecção, gripe, ansiedade, depressão, vasodilatação, dispneia, náusea, rash cutâneo, artralgia, dorsalgia, astenia, dor torácica e outras algias. Os eventos adversos comuns são: linfadenopatia, aumento de peso, tremor, distúrbios oculares, palpitações, taquicardia, vômitos, distúrbios da pele, calafrios, edema da face e candidíase vaginal. O médico responsável deve considerar a gravidade desses eventos para reduzir a dose preconizada por um determinado período e, paulatinamente, proceder à sua recomposição<sup>34,35</sup> .  
A mudança de frequência na aplicação diária (glatirâmer 20 mg/mL) para três vezes por semana (glatirâmer 40 mg/mL) revelou uma diminuição em 60% na taxa de eventos adversos<sup>34</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
22  
O monitoramento dos pacientes é clínico-laboratorial. Observar taxas e gravidades dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos. Os exames laboratoriais básicos que devem ser solicitados são: hemograma completo (eritrograma, leucograma e plaquetas), enzimas hepáticas (AST/TGO, ALT/TGP e fosfatase alcalina) e bilirrubina total. As taxas de surtos e EDSS devem ser verificadas e relatadas a cada 3 meses. Os exames laboratoriais devem ser monitorados a cada 30, 60 e 180 dias do início do uso do medicamento, seguida por monitoramento a cada 6 meses. As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.  
As reações adversas mais frequentes (incidência ≥10%) são rubor e eventos gastrointestinais (diarreia, náusea, dor abdominal). Outras reações comuns (incidência entre 1% e 10%) são: leucopenia, linfopenia, sensação de queimação, fogacho, vômito, gastrite, prurido, eritema, proteinúria e aumento de transaminases/aminotransferases<sup>46,51</sup> .  
Há relato de ocorrência de LEMP em caso de linfopenia prolongada, moderada a grave, após a administração de fumarato de dimetila. A ocorrência de LEMP com o uso do fumarato de dimetila é considerado um evento adverso muito raro; contudo, ao primeiro sinal ou sintoma sugestivo de LEMP, o medicamento deve ser suspenso e uma investigação diagnóstica apropriada deve ser procedida<sup>51,53,124</sup> .  
**Alterações de hemograma** . Pacientes em tratamento com fumarato de dimetila podem desenvolver linfopenia. Assim, é recomendado o monitoramento frequente a partir de hemogramas completos, incluindo contagem de linfócitos. Recomenda-se atenção reforçada em pacientes com linfopenia, devido ao aumento do risco para desenvolver LEMP, conforme casos listados a seguir:  
**Quadro 6 -** Orientações para monitoramento da linfopenia em pacientes em uso de fumarato de dimetila  
|**Alterações hepáticas**|**Monitoramento**|
|---|---|
|Contagem de linfócitos abaixo do limite inferior do normal,<br>conforme definido pelo intervalo de referência do|Monitoramento regular da contagem absoluta de linfócitos.<br>Fatores adicionais que possam aumentar ainda mais o risco|
|laboratório local.|individual de LEMP devem ser considerados.|
|Reduções moderadas na contagem absoluta de linfócitos ≥|A relação benefício/risco do tratamento deve ser reavaliada.|
|0,5 x 10<sup>9</sup>/L e < 0,8 x 10<sup>9</sup>/L, persistentes por mais de seis||
|meses.||
|Linfopenia severa prolongada (contagens de linfócitos < 0,5|Suspender tratamento.|
|x 10<sup>9</sup>/L) persistente por mais de 6 meses.||  
Fonte: Elaboração própria<sup>51</sup>  
Legenda: L: litro; LEMP: Leucoencefalopatia Multifocal Progressiva.  
**Nota:** As contagens de linfócitos devem ser acompanhadas até sua recuperação. Após a recuperação e, em caso de ausência de tratamentos alternativos, a decisão de interromper ou continuar o tratamento com fumarato de dimetila deve ser baseado na avaliação clínica.  
**Alterações da função hepática** . Lesão hepática induzida por medicamento, incluindo o aumento das enzimas hepáticas (≥ 3 x LSN) e elevação dos níveis totais de bilirrubina (≥ 2 x LSN), podem ser consequências do tratamento com fumarato de dimetila. O tempo de início pode ser imediato, dentro de semanas ou tardio. A resolução dos eventos adversos tem sido observada após a descontinuação do tratamento. A avaliação de transaminases séricas (por exemplo, TGP e TGO) e níveis totais de bilirrubina é recomendada antes de iniciar o tratamento e durante o tratamento, conforme clinicamente indicado.  
**Teriflunomida**  
23  
O monitoramento é clínico-laboratorial. Monitorar a pressão sanguínea, proceder à anamnese e exame físico completos, com histórico de sinais e sintomas de infecção, e solicitar os exames básicos: hemograma completo (eritrograma, leucograma e plaquetometria), enzimas hepáticas (AST/TGO, ALT/TGP e fosfatase alcalina) e bilirrubina total. Observar taxas e gravidade dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos, que devem ser verificados e relatados a cada 3 meses. Os exames laboratoriais devem ser monitorados a cada 30, 60 e 180 dias do início do uso do medicamento; em seguida, monitoramento a cada 6 meses. As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.  
Doença intersticial pulmonar e piora da doença intersticial pulmonar pré-existente podem ocorrer de forma aguda a qualquer momento durante a terapia com a teriflunomida. Sintomas como tosse e dispneia, com ou sem febre associada, devem ser investigados e podem ser uma razão para a suspensão do medicamento. Outras reações adversas mais frequentes são: cefaleia, diarreia, náusea e alopecia<sup>45,46</sup> .  
A teriflunomida pode causar a alteração no valor da pressão arterial, que deve ser monitorada ao início e periodicamente durante o tratamento. Também pode causar uma diminuição na contagem das células brancas do sangue, principalmente de neutrófilos e linfócitos. As plaquetas também podem apresentar diminuição na sua contagem, comparativamente aos valores ao início do tratamento. A teriflunomida pode ainda causar elevação das enzimas hepáticas. Os mesmos cuidados de monitoramento do uso de betainterferona devem ser aplicados<sup>45,46</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento dos pacientes é clínico-laboratorial. Observar taxas e gravidade dos surtos; pontuação na escala de incapacidade (EDSS); história pregressa de condição cardíaca, infecções recorrentes e eventos adversos de medicamentos; e monitorar a pressão arterial e eletroencefalograma. Os exames que devem ser solicitados ao início e durante o tratamento: hemograma completo (eritrograma, leucograma e plaquetometria), enzimas hepáticas (AST/ TGO, ALT/ TGP e fosfatase alcalina) e bilirrubina total<sup>55,56</sup> . Taxas e gravidade dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos devem ser verificados e relatados a cada 3 meses. A avaliação laboratorial deve ser feita em 30, 60 e 180 dias do início do uso do medicamento, em seguida a cada 6 meses e após 2 meses do término do tratamento. As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.  
As reações adversas mais graves relacionadas com o uso de fingolimode são: infecções, edema macular e bloqueios atrioventriculares transitórios no início do tratamento. As reações adversas mais frequentes (incidência ≥ 10%) são: cefaleia, aumento das enzimas hepáticas, diarreia, tosse, gripe e dor nas costas<sup>55</sup> .  
O paciente deve ser monitorado com hemograma completo, antes, durante e após dois meses de finalizado o tratamento. Paciente com infecção ativa grave deve ter o tratamento postergado até a resolução do quadro infeccioso. Deve-se atentar para os sintomas ou resultados de imagem de ressonância magnética que podem ser sugestivos de LEMP. Nesses casos, o tratamento deve ser suspenso até que o diagnóstico de LEMP tenha sido totalmente excluído. Durante o tratamento e até os dois meses subsequentes, as vacinações podem ser menos eficazes<sup>22,55,125</sup> .  
Deve-se monitorizar as enzimas hepáticas e bilirrubina. Sinais e sintomas de disfunção hepática (náusea, vômito, dor abdominal, fadiga, anorexia ou icterícia inexplicados ou urina escura) devem ser averiguados com a repetição das dosagens dessas enzimas e da bilirrubina<sup>54</sup> . O tratamento com o fingolimode deve seguir o mesmo procedimento preconizado para as betainterferonas em relação a valores alterados.  
Devido ao risco de edema macular, pacientes com relato de distúrbios visuais durante a terapia com fingolimode devem ter o fundo dos olhos examinados, incluindo a mácula. Pacientes com histórico de uveíte ou com diabete melito concomitante à esclerose múltipla devem ser submetidos à avaliação oftálmica antes e durante o tratamento com fingolimode<sup>55</sup> .  
24  
O fingolimode é contraindicado em pacientes com infarto do miocárdio recente (ocorrência nos últimos 6 meses), acidente vascular cerebral, angina instável, ataque isquêmico transitório, insuficiência cardíaca descompensada que requer hospitalização, insuficiência cardíaca classe III/IV, histórico ou presença de bloqueio atrioventricular de 2º ou 3º grau com Mobitz tipo II, doença do nó sinusal (exceto o paciente que faz uso de marca-passo), hipertensão arterial não controlada, apneia do sono grave não tratada, uso de fármacos antiarrítmicos classe Ia ou classe III, intervalo de QT maior ou igual a 500 ms ou insuficiência hepática grave ( _Child-Pugh_ classe C)<sup>55</sup> .  
Preconiza-se a realização de eletrocardiograma (ECG) de repouso antes e após seis horas do término da administração do medicamento na primeira dose ou após 14 dias de suspensão do medicamento. Todos os pacientes devem ser observados, com aferição da pressão arterial e pulsação a cada hora, por um período de 6 horas, para os sinais e sintomas de bradicardia. Caso ocorram sintomas de bradicardia, ações apropriadas devem ser iniciadas e o paciente deve ser observado até a resolução dos sintomas. Se a intervenção medicamentosa for necessária neste período de observação, o paciente deve ser monitorado em um centro médico especializado por ocasião da primeira dose ou após 14 dias de suspensão do fingolimode. São também considerados eventos adversos para o monitoramento em serviço médico especializado<sup>55,56</sup> :  
 Se o ritmo cardíaco em seis horas após a aplicação da dose for abaixo de 45 batimentos por minuto ou for o menor valor pós-dose aplicada (sugerindo que o efeito farmacodinâmico máximo sobre o coração ainda não foi manifestado). Neste último caso, pode-se estender o período de observação por mais duas horas antes de encaminhar o paciente a algum serviço médico.  
 Se o ECG de seis horas após a aplicação da primeira dose mostrar novo início de bloqueio atrioventricular de  
segundo grau ou maior.  
 Se o ECG mostrar um intervalo QT igual ou acima de 500 milissegundos na sexta hora após a primeira dose, os pacientes devem ser monitorados por mais 12 horas.  
Todos os cuidados que se deve ter com a primeira dose do fingolimode também devem ser tomados na reintrodução do tratamento após 14 dias da interrupção.  
Finalmente, caso seja interrompido o tratamento com fingolimode, deve-se ter ciência de que a substância permanece na circulação sanguínea e possui efeitos farmacodinâmicos por até dois meses após a última dose<sup>55</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento é clínico-laboratorial. Observar taxas e gravidades dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos. Os seguintes exames devem ser solicitados antes e durante o tratamento: hemograma completo (eritrograma, leucograma e plaquetas), enzimas hepáticas (AST/ TGO, ALT/ TGP e fosfatase alcalina) e bilirrubina total. A avaliação da taxa de surtos e da pontuação na EDSS deve ser realizada e relatada a cada 3 meses. O hemograma deve ser realizado mensalmente antes de cada infusão. Em caso de alteração, deve-se repetir o exame a cada 15-30 dias até a melhora das contagens celulares; se não houver melhora, o medicamento não deve ser utilizado até que haja a sua normalização. Os outros exames laboratoriais devem ser monitorizados a cada 30, 60 e 180 dias do início do uso do medicamento, seguida por monitorização a cada 6 meses. As reavaliações deverão ser semestrais, sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.  
Para os pacientes que apresentem risco de desenvolver a LEMP, deve-se continuar o tratamento com natalizumabe somente se os benefícios superarem os riscos<sup>24,126</sup> .  
O médico deve avaliar o paciente a fim de determinar se os sintomas indicativos de disfunção neurológica são típicos da esclerose múltipla ou sugestivos de LEMP. Os exames periódicos de imagem e a ressonância magnética (RM) são os que evidenciam precocemente a LEMP. Deve-se proceder a uma avaliação minuciosa, incluindo imagens por RM preferencialmente com contraste (para comparação com imagens anteriores ao tratamento), e análise do líquido cefalorraquidiano para a detecção  
25  
de DNA viral de JC. Assim que o médico tiver excluído completamente a hipótese de LEMP, o tratamento com natalizumabe pode ser retomado<sup>24,126</sup> .  
Atenção especial deve ser dada ao uso de natalizumabe após o tratamento com terapias de reconstituição imunológica, pois há incertezas se a imunossupressão causada por essas terapias oferece um risco adicional para o desenvolvimento de LEMP em pacientes portadores do vírus JC. Alguns fatores deverão ser considerados para o caso de retorno ao tratamento com natalizumabe, conforme mencionado no item _Pacientes com maior risco de desenvolver Leucoencefalopatia Multifocal Progressiva_ . Em pacientes com maior risco de desenvolver LEMP, um controle mais rígido de monitoramento deve ser estabelecido, com pelo menos duas RM anuais, uma vez que a imunossupressão pode aumentar o risco do evento adverso.  
O vírus JC também pode provocar neuronopatia de células granulares (NCG), que tem sido relatada em pacientes tratados com natalizumabe. Os sintomas da NCG por JCV são semelhantes aos sintomas de LEMP<sup>24</sup> .  
As reações adversas mais comuns (incidência ≥ 10%) são: tontura, náusea, urticária, rigidez associada às infusões, dor de cabeça, fadiga, artralgia, gastroenterite, vaginite, depressão, dor nas extremidades, desconforto abdominal e diarreia inespecificada. As reações adversas graves mais comuns são: infecções, infecção do trato urinário, pneumonia, reações de hipersensibilidade aguda (inclusive anafilaxia), depressão e colelitíase. Apendicite também foi uma reação adversa comum em pacientes que receberam natalizumabe<sup>24</sup> .  
Lesão hepática grave, alteração das enzimas hepáticas e hiperbilirrubinemia podem ocorrer com uso desse medicamento, devendo-se adotar os mesmos critérios preconizados para as betainterferonas. Foram ainda relatados casos sérios e graves de anemia e anemia hemolítica em pacientes sob tratamento com natalizumabe, daí a necessidade do monitoramento por meio de hemograma mensal<sup>24</sup> .

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O modo de ação da cladribina oral está estreitamente ligado a uma redução na contagem de linfócitos. O efeito sobre a contagem de linfócitos é dose-dependente. Assim, é importante realizar o monitoramento hematológico com a contagem de linfócitos antes do início de cada ano de tratamento e após 2 e 6 meses do início de cada ano do tratamento. Se a contagem de linfócitos estiver inferior a 800 células/mm<sup>3</sup> antes do início do tratamento do ano 2, o ciclo do tratamento pode ser adiado por até 6 meses no máximo, para permitir a recuperação dos linfócitos. Caso essa recuperação demore mais de 6 meses, o paciente não deve voltar a ser tratado com cladribina oral.  
Durante o monitoramento hematológico, caso a contagem de linfócitos esteja abaixo de 500 células/mm<sup>3</sup> , o paciente deve ser ativamente monitorado, especialmente para sinais e sintomas sugestivos de infecções, em particular Herpes zoster. Caso esses sinais e sintomas ocorram, um tratamento anti-infeccioso deve ser iniciado, conforme a indicação clínica. A interrupção ou adiamento do tratamento com cladribina oral pode ser considerado até a resolução adequada da infecção.  
O monitoramento cuidadoso dos parâmetros hematológicos também é recomendado para pacientes após o uso de cladribina ou que estejam utilizando concomitantemente outros medicamentos que afetam o perfil hematológico, devido aos possíveis eventos adversos hematológicos aditivos.  
Se um paciente desenvolver sinais clínicos, incluindo elevações inexplicáveis das enzimas hepáticas ou sintomas sugestivos de disfunção hepática (por exemplo, náusea inexplicada, vômito, dor abdominal, fadiga, anorexia ou icterícia ou urina escura), as transaminases séricas e a bilirrubina total devem ser dosadas imediatamente e o tratamento com cladribina oral interrompido ou suspenso, o que for mais apropriado.  
Deve-se proceder, também, com a monitorização cuidadosa dos pacientes que fizerem uso concomitante de cladribina oral e inibidores potentes dos transportadores ENT1 (proteínas transportadoras de nucleosídeos equilibrativos), CNT3 (proteínas transportadoras de nucleosídeos concentrativos) e BCRP (proteína de resistência ao câncer de mama). O ideal é que a administração concomitante de inibidores potentes dos transportadores ENT1, CNT3 e BCRP seja evitada durante os 4 a 5 dias  
26  
de tratamento com a cladribina. Se não for possível, deve considerar-se a seleção de medicamentos concomitantes alternativos sem ou com o mínimo de propriedades inibidoras dos transportadores ENT1, CNT3 ou BCRP. Se não for possível, recomendase a redução da dose para a dose mínima obrigatória dos medicamentos contendo estes compostos, a separação dos períodos de administração e a monitorização cuidadosa do paciente.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento é clínico-laboratorial (taxa de surtos, pontuação na EDSS, eventos adversos, AST /TGO, ALT/TGP, bilirrubina, fosfatase alcalina, gama-GT e hemograma), realizado 30-60 dias após o início e depois de 6/6 meses. As mesmas condutas de monitorização para o uso de betainterferona devem ser seguidas. As reavaliações deverão ser semestrais<sup>114</sup> , sendo elaborado relatório médico que informe sobre a evolução do paciente (taxa de surtos e pontuação na EDSS calculada a cada 3 meses) e relato de eventos adversos.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
O monitoramento é clínico-laboratorial. Observar taxas e gravidades dos surtos, pontuação na escala de incapacidade (EDSS) e relatos de eventos adversos. Os seguintes exames laboratoriais devem ser conduzidos em intervalos periódicos antes e por até quarenta e oito meses (48 meses) depois do último ciclo de tratamento, a fim de monitorar os sinais iniciais de doença autoimune<sup>61</sup> :  
- hemograma completo com diferencial e transaminases séricas (antes do início do tratamento e em intervalos  
mensais subsequentes);  
- níveis de creatinina sérica (antes do início do tratamento e em intervalos mensais subsequentes);  
- exame de urina com contagem de células (antes do início do tratamento e depois em intervalos mensais); e  
- teste de função da tireoide, tal como nível de TSH (antes do início do tratamento e a cada três meses  
- subsequentemente).  
O tratamento com alentuzumabe pode resultar na formação de autoanticorpos e aumento do risco de condições mediadas por autoimunidade, que podem ser graves e com risco de vida. As condições autoimunes reportadas incluem distúrbios da tireoide, púrpura trombocitopênica idiopática (PTI), ou, raramente, nefropatias (por exemplo, doença antimembrana basal glomerular), hepatite autoimune (AIH), hemofilia adquirida A e púrpura trombocitopênica trombótica (PTT). Os pacientes que desenvolvem autoimunidade devem ser avaliados quanto a outras condições mediadas por esse tipo de imunidade. Pacientes e médicos devem estar informados sobre o potencial aparecimento tardio de distúrbios autoimunes após o período de monitoramento de 48 meses.  
Durante o uso pós-comercialização, foram relatados eventos adversos graves, às vezes fatais e imprevisíveis, de vários órgãos e sistemas. Foram relatados casos de hemorragia pulmonar alveolar, isquemia do miocárdio, infarto do miocárdio, acidente vascular cerebral (incluindo acidente vascular cerebral isquêmico e hemorrágico), dissecção arterial cervicocefálica (por exemplo, vertebral, carótida) e trombocitopenia. As reações podem ocorrer seguidas de qualquer dose durante o curso do tratamento. Na maioria dos casos, o início ocorreu dentro de 1-3 dias após a infusão de alentuzumabe. Os pacientes devem ser informados sobre os sinais e sintomas e aconselhados a procurar assistência médica imediatamente, se quaisquer desses sintomas ocorrerem.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: Geral -->
Infecções ocorreram em 71% dos pacientes tratados com alentuzumabe 12 mg comparado com 53% dos pacientes tratados com betainterferona 1a (IFNB-1a) em estudos clínicos controlados de EM com até dois anos de duração e foram de gravidade predominantemente leve a moderada. Além disso, as seguintes infecções devem ser rastreadas:  
- **HPV:** É recomendável realizar a triagem anualmente em pacientes do sexo feminino.  
27  
- **Herpes:** A profilaxia com agente oral anti-herpes deve ser iniciada no primeiro dia de tratamento com alentuzumabe e  
- mantida por, no mínimo, um mês depois de cada ciclo de tratamento.  
- **Citomegalovírus (CMV):** Em pacientes sintomáticos, a avaliação clínica deve ser realizada durante e por pelo menos  
- dois meses após cada ciclo de tratamento com alentuzumabe.  
- **Tuberculose** : A triagem para tuberculose (TB) deve ser realizada antes do início do tratamento, de acordo com as  
- orientações do Ministério da Saúde.  
**- Leucoencefalopatia multifocal progressiva:** O monitoramento com ressonância magnética (RM), incluindo antes do início do tratamento com alentuzumabe, pode ser útil para a detecção de sinais que podem ser consistentes com LEMP, e qualquer resultado suspeito deve levar a uma investigação mais aprofundada para possibilitar um diagnóstico precoce de LEMP, se presente.  
**Nota:** Pacientes em tratamento com alentuzumabe devem ser devidamente monitorados para garantir o cumprimento da proposta apresentada pelo fabricante no Relatório de Recomendação nº 609/2021 da Conitec, em que se comprometeu em fornecer, sem custos, os frascos adicionais para complementar o tratamento dos pacientes, caso o percentual de pessoas que necessite de um terceiro ciclo ultrapasse o teto de 30% ou o percentual que necessite de um quarto ciclo ultrapasse o teto de 16%.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Alguns medicamentos recomendados para a esclerose múltipla podem interferir no sistema imunológico do paciente e o predispor a um maior risco de infecções, sendo necessário o rastreamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) e a investigação da tuberculose ativa antes do início do tratamento.  
O medicamento **acetato de glatirâmer** e as **betainterferonas** são considerados seguros para a reativação da ILTB, não sendo necessário o rastreio dos pacientes. Além disso, visto que o Manual de Recomendações para o Controle da Tuberculose no Brasil indica o rastreamento para os casos de uso de corticosteroides em dose equivalente a mais que 15 mg/dia de prednisona por mais de 1 mês, o uso de **metilprednisolona** nas doses e nas frequências recomendadas para os surtos da EM não causam depleção do sistema imunológico com um risco significativo de ativação da tuberculose e, portanto, também não é necessário o rastreamento de ILTB prévio a seu uso.<sup>127</sup>  
Considerando as evidências existentes, antes do início do uso de **teriflunomida, cladribina oral** e **alentuzumabe** e com objetivo de realizar o planejamento terapêutico adequado, deve-se considerar as seguintes condutas. Ainda, devido à alta carga de tuberculose no Brasil, mesmo sendo os dados de segurança para a reativação da ILTB inconclusivos, as mesmas condutas se aplicam ao início de tratamento com **azatioprina** , **fingolimode** , **fumarato de dimetila** e **natalizumabe** :<sup>128,129</sup>  
- Deve-se pesquisar a ocorrência de tuberculose (TB) ativa e ILTB.  
- Além do exame clínico para avaliação de TB ativa e ILTB, exames complementares devem ser solicitados. A radiografia  
- simples de tórax deve ser realizada para excluir a possibilidade de TB ativa.  
- Para avaliação da ILTB, deve-se realizar a prova tuberculínica (PT, com o derivado proteico purificado – PPD) ou o teste de liberação de interferon-gama (IGRA), ressaltando-se que o IGRA está disponível para aqueles pacientes que atenderem aos critérios de indicação específicos para realização desse exame.  
- Deve-se iniciar o tratamento da ILTB em pacientes com PT ≥ 5 mm ou IGRA reagente, quando for excluída a possibilidade de TB ativa. Quando existirem alterações radiográficas compatíveis com TB prévia não tratada ou contato próximo com caso de TB pulmonar nos últimos dois anos, o tratamento da ILTB também deve ser iniciado, sem necessidade de realizar o IGRA ou a PT.  
- Os esquemas de tratamento para TB ativa e ILTB devem seguir o Manual de Recomendações para o Controle da Tuberculose no Brasil e demais orientações do Ministério da Saúde. Recomenda-se o início do uso de **teriflunomida, cladribina**  
28  
**oral, alentuzumabe** , **azatioprina** , **fingolimode** , **fumarato de dimetila** e **natalizumabe** após quatro semanas do início do tratamento de ILTB. No caso de TB ativa, à critério da equipe de saúde assistente, o início de uso de **teriflunomida, cladribina oral, alentuzumabe** , **azatioprina** , **fingolimode** , **fumarato de dimetila** e **natalizumabe** pode ocorrer concomitantemente ou após quatro semanas do início do tratamento da TB ativa.  
- Nos casos de troca de medicamentos, não é necessário repetir as condutas preconizadas para início de tratamento.  
Para fins de acompanhamento, deve-se considerar as seguintes condutas, ressaltando-se que a dispensação dos medicamentos para a doença de base não deve ser condicionada à apresentação desses exames:  
- Não se deve repetir a PT ou IGRA de pacientes com PT ≥ 5 mm ou IGRA reagente, pacientes que realizaram o tratamento para ILTB (em qualquer momento da vida) e sem nova exposição (novo contato), bem como de pacientes que já se submeteram ao tratamento completo da TB.  
- - Para que o uso dos teriflunomida, cladribina oral, alentuzumabe, azatioprina, fingolimode, fumarato de dimetila e natalizumabe não influencie o resultado dos exames, pacientes que realizaram a PT antes do início do tratamento com teriflunomida, cladribina oral, alentuzumabe, azatioprina, fingolimode, fumarato de dimetila e natalizumabe devem manter o monitoramento com a PT. Já pacientes que realizaram o IGRA antes do início do tratamento com teriflunomida, cladribina oral, alentuzumabe, azatioprina, fingolimode, fumarato de dimetila e natalizumabe devem manter o monitoramento com o IGRA. - Não se deve repetir o tratamento da ILTB em pacientes que já realizaram o tratamento para ILTB em qualquer momento da vida, bem como pacientes que já se submeteram ao tratamento completo da TB, exceto quando em caso de nova exposição.  
- Enquanto estiverem em uso de medicamentos com risco de reativação da ILTB, recomenda-se o acompanhamento periódico para identificação de sinais e sintomas de TB e rastreio anual da ILTB. No caso de pessoas com PT < 5 mm ou IGRA não reagente, recomenda-se repetir a PT ou IGRA anualmente, especialmente em locais com alta carga de tuberculose.  
- Deve-se repetir a radiografia simples de tórax apenas se houver suspeita clínica de TB ativa ou na investigação da ILTB quando PT ≥ 5 mm ou IGRA reagente. Nas situações em que o IGRA é indeterminado, como pode se tratar de problemas na coleta e transporte do exame, considerar repetir o exame em uma nova amostra.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
São exigidos relatório médico completo e exames de neuroimagem (ressonância magnética) para comprovação do diagnóstico utilizando os Critérios de McDonald de 2017<sup>14</sup> . A EDSS devidamente respondida também deve ser fornecida.  
Pacientes com esclerose múltipla devem ser atendidos em serviços especializados, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento, e ser avaliados periodicamente quanto à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. O **Quadro 6** indica em que condições pacientes com EM devem ser acompanhados na APS, em serviços especializados ou serem encaminhados a serviços de emergência.  
**Quadro 6 -** Níveis de atenção à saúde para pacientes com EM e encaminhamento para serviço especializado  
|Atenção primária à saúde (APS)|• tratamento sintomático (medicamentoso e não medicamentoso) da EM;|
|---|---|  
29  
|Serviço especializado|• suspeita de esclerose múltipla, com necessidade de exames clínicos com especialista,<br>exames de neuroimagem e diagnóstico diferencial;|
|---|---|
||• atividade da doença ou incidência de surto em pacientes já com tratamento clínico<br>otimizado dentro da linha de tratamento preconizado;|
||• episódio de internação hospitalar devido a surto;|
||• sequela de surto; ou|
||• cuidado de pacientes em uso de fingolimode com bradicardia.|
|Serviço de emergência|Suspeita de surto.|  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Quando da publicação deste PCDT, os pacientes que já estiverem em uso de medicamento biológico para esclerose múltipla deverão ser avaliados para manutenção do tratamento e inclusão neste Protocolo.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Recomenda-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
1. Comini-Frota ER, Vasconcelos CCF, Mendes MF. Guideline for multiple sclerosis treatment in Brazil: Consensus from the Neuroimmunology Scientific Department of the Brazilian Academy of Neurology. Arq Neuropsiquiatr. 2017 Jan;75(1):57–65.  
2. Gajofatto A, Benedetti MD. Treatment strategies for multiple sclerosis: When to start, when to change, when to stop? World J Clin Cases. 2015;3(7):545.  
3. HAUSER, S. L.; GOODIN D. Esclerose Múltilpla e Outras Doenças Desmielinizantes. In: BRAUNWALD, E.et al. Medicina Interna de Harisson. 18. ed. Porto Alegre: Artmed Editora. 2013. 3395–3409 p.  
4. Annibali V, Mechelli R, Romano S, Buscarinu MC, Fornasiero A, Umeton R, et al. IFN-β and multiple sclerosis: From etiology to therapy and back. Cytokine Growth Factor Rev. 2015 Apr;26(2):221–8.  
5. OLIVEIRA E, SOUZA N. Esclerose Múltipla. Rev Neurociências. 1998;6(3):114–8.  
6. A FI da EM. Atlas da EM [Internet]. Vol. 3<sup>a</sup> Edição. 2020. Available from: https://www.abem.org.br/wpcontent/uploads/2020/09/AtlasOfMS_3rdEdition_traduzido.pdf  
7. da Gama Pereira ABCN, Sampaio Lacativa MC, da Costa Pereira FFC, Papais Alvarenga RM. Prevalence of multiple sclerosis in Brazil: A systematic review. Mult Scler Relat Disord. 2015 Nov;4(6):572–9.  
30  
8. MACHADO et al. Recomendações Esclerose Multipla. São Paulo: Omnifarma. 2012. 112p p.  
9. NETTER, F. H; ROYDEN J (Ed. ). Esclerose Múltipla e Outros Transtornos Autoimunes do sistema Nervoso Central. In: In: NETTER, H et al Coleção Netter de Ilustrações Médicas: Sistema Nervoso -Cérebro -Parte I 2 edRio de Janeiro: Elsevier. 2014. p. 247–72.  
10. BRASIL. Secretaria de Atenção à Saúde. Portaria n<sup>o</sup> 391, de 5 de maio de 2015. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla. Brasília: Diário Oficial da União. 2015.  
11. McDonald WI, Compston A, Edan G, Goodkin D, Hartung HP, Lublin FD, et al. Recommended diagnostic criteria for multiple sclerosis: Guidelines from the international panel on the diagnosis of multiple sclerosis. Ann Neurol. 2001 Jul;50(1):121–7.  
12. Polman CH, Reingold SC, Edan G, Filippi M, Hartung HP, Kappos L, et al. Diagnostic criteria for multiple sclerosis: 2005 revisions to the “McDonald Criteria.” Ann Neurol. 2005 Dec;58(6):840–6.  
13. Polman CH, Reingold SC, Banwell B, Clanet M, Cohen JA, Filippi M, et al. Diagnostic criteria for multiple sclerosis: 2010 Revisions to the McDonald criteria. Ann Neurol. 2011 Feb;69(2):292–302.  
14. Thompson AJ, Banwell BL, Barkhof F, Carroll WM, Coetzee T, Comi G, et al. Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. Lancet Neurol. 2018 Feb;17(2):162–73.  
15. Kurtzke JF. Rating neurologic impairment in multiple sclerosis: An expanded disability status scale (EDSS). Neurology. 1983 Nov;33(11):1444–1444.  
16. Jacques FH, Lublin FD. Defining the clinical course of multiple sclerosis: The 2013 revisions. Neurology. 2015 Mar;84(9):963–963.  
17. COSTELLO et al. THE USE OF DISEASE-MODIFYING THERAPIES IN MULTIPLE SCLEROSIS: Principles and Current Evidence. A Consensus Paper by the Multiple Sclerosis Coalition. 2019.  
18. Marques VD, Passos GR dos, Mendes MF, Callegaro D, Lana-Peixoto MA, Comini-Frota ER, et al. Brazilian Consensus for the Treatment of Multiple Sclerosis: Brazilian Academy of Neurology and Brazilian Committee on Treatment and Research in Multiple Sclerosis. Arq Neuropsiquiatr. 2018 Aug;76(8):539–54.  
19. Comi G, Filippi M, Barkhof F, Durelli L, Edan G, Fernández O, et al. Effect of early interferon treatment on conversion to definite multiple sclerosis: a randomised study. Lancet. 2001 May;357(9268):1576–82.  
20. Comi G, Martinelli V, Rodegher M, Moiola L, Bajenaru O, Carra A, et al. Effect of glatiramer acetate on conversion to clinically definite multiple sclerosis in patients with clinically isolated syndrome (PreCISe study): a randomised, doubleblind, placebo-controlled trial. Lancet. 2009 Oct;374(9700):1503–11.  
21. Comi G, Martinelli V, Rodegher M, Moiola L, Leocani L, Bajenaru O, et al. Effects of early treatment with glatiramer acetate in patients with clinically isolated syndrome. Mult Scler J. 2013;19(8):1074–83.  
22. Butzkueven H, Kappos L, Wiendl H, Trojano M, Spelman T, Chang I, et al. Long-term safety and effectiveness of natalizumab treatment in clinical practice: 10 years of real-world data from the Tysabri Observational Program (TOP). J Neurol Neurosurg Psychiatry. 2020 Jun;91(6):660–8.  
23. Miller AE, Wolinsky JS, Kappos L, Comi G, Freedman MS, Olsson TP, et al. Oral teriflunomide for patients with a first clinical episode suggestive of multiple sclerosis (TOPIC): a randomised, double-blind, placebo-controlled, phase 3 trial. Lancet Neurol. 2014 Oct;13(10):977–86.  
24. BIOGEN Brasil Produtos Farmacêuticos Ltda. TYSABRI® natalizumabe. 2018;  
25. Tabansky I, Messina MD, Bangeranye C, Goldstein J, Blitz-Shabbir KM, Machado S, et al. Advancing drug delivery systems for the treatment of multiple sclerosis. Immunol Res. 2015 Dec;63(1–3):58–69.  
26. NICE. National Institute for Health and Care Excellence. Multiple sclerosis in adults: management. NICE Clin Guidel.  
31  
2014;(October):28.  
27. Oliveri RL, Sibilia G, Valentino P, Russo C, Romeo N, Quattrone A. Pulsed methylprednisolone induces a reversible impairment of memory in patients with relapsing-remitting multiple sclerosis. Acta Neurol Scand. 1998 Jun;97(6):366– 9.  
28. Kalincik T. Multiple Sclerosis Relapses: Epidemiology, Outcomes and Management. A Systematic Review. Neuroepidemiology. 2015;44(4):199–214.  
29. Cortese I, Chaudhry V, So YT, Cantor F, Cornblath DR, Rae-Grant A. Evidence-based guideline update: Plasmapheresis in neurologic disorders: Report of the Therapeutics and Technology Assessment Subcommittee of the American Academy of Neurology. Neurology. 2011 Jan;76(3):294–300.  
30. Knuth AK, Rösler S, Schenk B, Kowald L, van Wijk SJL, Fulda S. Interferons Transcriptionally Up-Regulate MLKL Expression in Cancer Cells. Neoplasia. 2019 Jan;21(1):74–81.  
31. Reder AT, Feng X. How Type I Interferons Work in Multiple Sclerosis and Other Diseases: Some Unexpected Mechanisms. J Interf Cytokine Res. 2014 Aug;34(8):589–99.  
32. Rafiee Zadeh A, Ghadimi K, Ataei A, Askari M, Sheikhinia N, Tavoosi N, et al. Mechanism and adverse effects of multiple sclerosis drugs: a review article. Part 2. Int J Physiol Pathophysiol Pharmacol. 2019;11(4):105–14.  
33. CCATES (Centro Colaborador do SUS). Boletim Esclerose Múltipla. Volume 6. 2016.  
34. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Relatório de recomendação: Acetato de Glatirâmer 40 mg no tratamento da Esclerose Múltipla Remitente Recorrente. 2018.  
35. TEVA Pharmaceuticals LTDA. Bula: COPAXONE (acetato de glatirâmer)®. 2014;  
36. Prod’homme T, Zamvil SS. The Evolving Mechanisms of Action of Glatiramer Acetate. Cold Spring Harb Perspect Med. 2019 Feb;9(2):a029249.  
37. Haas J, Korporal M, Balint B, Fritzsching B, Schwarz A, Wildemann B. Glatiramer acetate improves regulatory T-cell function by expansion of naive CD4+CD25+FOXP3+CD31+ T-cells in patients with multiple sclerosis. J Neuroimmunol. 2009 Nov;216(1–2):113–7.  
38. Hong J, Li N, Zhang X, Zheng B, Zhang JZ. Induction of CD4+CD25+ regulatory T cells by copolymer-I through activation of transcription factor Foxp3. Proc Natl Acad Sci. 2005 May;102(18):6449–54.  
39. Jee Y, Piao WH, Liu R, Bai XF, Rhodes S, Rodebaugh R, et al. CD4+CD25+ regulatory T cells contribute to the therapeutic effects of glatiramer acetate in experimental autoimmune encephalomyelitis. Clin Immunol. 2007 Oct;125(1):34–42.  
40. Traub J, Traffehn S, Ochs J, Häusser‐Kinzel S, Stephan S, Scannevin R, et al. Dimethyl fumarate impairs differentiated B cells and fosters central nervous system integrity in treatment of multiple sclerosis. Brain Pathol. 2019 Sep;29(5):640– 57.  
41. Weber MS, Prod’homme T, Youssef S, Dunn SE, Rundle CD, Lee L, et al. Type II monocytes modulate T cell–mediated central nervous system autoimmune disease. Nat Med. 2007 Aug;13(8):935–43.  
42. Aharoni R, Eilam R, Stock A, Vainshtein A, Shezen E, Gal H, et al. Glatiramer acetate reduces Th-17 inflammation and induces regulatory T-cells in the CNS of mice with relapsing–remitting or chronic EAE. J Neuroimmunol. 2010 Aug;225(1–2):100–11.  
43. Klotz L, Eschborn M, Lindner M, Liebmann M, Herold M, Janoschka C, et al. Teriflunomide treatment for multiple sclerosis modulates T cell mitochondrial respiration with affinity-dependent effects. Sci Transl Med. 2019 May;11(490):eaao5563.  
44. Scott LJ. Teriflunomide: A Review in Relapsing–Remitting Multiple Sclerosis. Drugs. 2019 Jun;79(8):875–86.  
32  
45. GENZYME A Sanofi Company. AUBAGIO® teriflunomida. 2016.  
46. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Teriflunomida para primeira linha de tratamento da Esclerose Múltipla Remitente Recorrente. Brasília -. 2017;  
47. Spencer CM, Crabtree-Hartman EC, Lehmann-Horn K, Cree BAC, Zamvil SS. Reduction of CD8 + T lymphocytes in multiple sclerosis patients treated with dimethyl fumarate. Neurol - Neuroimmunol Neuroinflammation. 2015 Jun;2(3):e76.  
48. Michell‐Robinson MA, Moore CS, Healy LM, Osso LA, Zorko N, Grouza V, et al. Effects of fumarates on circulating and CNS myeloid cells in multiple sclerosis. Ann Clin Transl Neurol. 2016 Jan;3(1):27–41.  
49. Schulze-Topphoff U, Varrin-Doyer M, Pekarek K, Spencer CM, Shetty A, Sagan SA, et al. Dimethyl fumarate treatment induces adaptive and innate immune modulation independent of Nrf2. Proc Natl Acad Sci. 2016 Apr;113(17):4777–82.  
50. Kornberg MD, Bhargava P, Kim PM, Putluri V, Snowman AM, Putluri N, et al. Dimethyl fumarate targets GAPDH and aerobic glycolysis to modulate immunity. Science (80- ). 2018 Apr;360(6387):449–53.  
51. BIOGEN Brasil Produtos Farmacêuticos Ltda. TECFIDERATM fumarato de dimetila. 2015;  
52. Linker RA, Lee DH, Ryan S, van Dam AM, Conrad R, Bista P, et al. Fumaric acid esters exert neuroprotective effects in neuroinflammation via activation of the Nrf2 antioxidant pathway. Brain. 2011 Mar;134(3):678–92.  
53. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Fumarato de dimetila no tratamento da Esclerose Múltipla Remitente Recorrente após falha com betainterferona ou glatirâmer. 2017;1–99.  
54. Volpi C, Orabona C, Macchiarulo A, Bianchi R, Puccetti P, Grohmann U. Preclinical discovery and development of fingolimod for the treatment of multiple sclerosis. Expert Opin Drug Discov. 2019 Nov;14(11):1199–212.  
55. NOVARTIS Biociências LTDA. GILENYA® cloridrato de fingolimode. 2015;  
56. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Fingolimode no tratamento da esclerose múltipla remitente recorrente após falha terapêutica com betainterferona ou glatirâmer. 2017;  
57. Engelhardt B, Kappos L. Natalizumab: Targeting α4-Integrins in Multiple Sclerosis. Neurodegener Dis. 2008;5(1):16– 22.  
58. Iannetta M, Zingaropoli MA, Latronico T, Pati I, Pontecorvo S, Prezioso C, et al. Dynamic changes of MMP-9 plasma levels correlate with JCV reactivation and immune activation in natalizumab-treated multiple sclerosis patients. Sci Rep. 2019 Dec;9(1):311.  
59. Van Der Zwan M, Baan CC, Teun Van Gelder •, Hesselink DA. Review of the Clinical Pharmacokinetics and Pharmacodynamics of Alemtuzumab and Its Use in Kidney Transplantation. Clin Pharmacokinet [Internet]. 2017 [cited 2021 Jul 15];57. Available from: https://doi.org/10.1007/s40262-017-0573-x  
60. Ambrose LR, Morel AS, Warrens AN. Neutrophils express CD52 and exhibit complement-mediated lysis in the presence of alemtuzumab. Blood [Internet]. 2009 Oct 1 [cited 2021 Jul 15];114(14):3052–5. Available from: http://ashpublications.org/blood/article-pdf/114/14/3052/1486668/zh804009003052.pdf  
61. ANVISA AN de VS. Bula do LEMTRADA® (alentuzumabe) [Internet]. 2019 [cited 2020 Dec 30]. Available from: https://consultas.anvisa.gov.br/api/consulta/medicamentos/arquivo/bula/parecer/eyJhbGciOiJIUzUxMiJ9.eyJqdGkiOiI xMzIwODgzMyIsIm5iZiI6MTYwOTM0NTUzOSwiZXhwIjoxNjA5MzQ1ODM5fQ.QKxyKkHmmgSAkQEcgMvwn OKPy790XXOx_s52ly-45_ED6Zzyy4O_KQ7HyL-L-ZOamfP_0AgRzlVrJ4YMsl5n  
62. Banwell B, Reder AT, Krupp L, Tenembaum S, Eraksoy M, Alexey B, et al. Safety and tolerability of interferon beta-  
33  
1b in pediatric multiple sclerosis. Neurology. 2006 Feb;66(4):472–6.  
63. Ghezzi A, Amato MP, Annovazzi P, Capobianco M, Gallo P, La Mantia L, et al. Long-term results of immunomodulatory treatment in children and adolescents with multiple sclerosis: the Italian experience. Neurol Sci. 2009 Jun;30(3):193–9.  
64. Tenembaum SN, Segura MJ. Interferon beta-1a treatment in childhood and juvenile-onset multiple sclerosis. Neurology. 2006 Aug;67(3):511–3.  
65. Merck S/A. MAVENCLAD® cladribina. Bula para o profissional de saúde. Comprimidos 10 mg. 2022.  
66. Alroughani R, Alowayesh MS, Ahmed SF, Behbehani R, Al-Hashel J. Relapse occurrence in women with multiple sclerosis during pregnancy in the new treatment era. Neurology. 2018 Mar;90(10):e840–6.  
67. Confavreux C, Hutchinson M, Hours MM, Cortinovis-Tourniaire P, Moreau T. Rate of Pregnancy-Related Relapse in Multiple Sclerosis. N Engl J Med. 1998 Jul;339(5):285–91.  
68. Finkelsztejn A, Brooks J, Paschoal F, Fragoso Y. What can we really tell women with multiple sclerosis regarding pregnancy? A systematic review and meta-analysis of the literature. BJOG An Int J Obstet Gynaecol. 2011 Jun;118(7):790–7.  
69. LORENZI, AR; FORD H. Neurology and Pregnancy. Marsh MS, Nashef L, Brex P, editors. Neurology and Pregnancy: Clinical Management. CRC Press; 2012. 214–221 p.  
70. Bio-Manguinhos. Betainterferona 1a Bio-Manguinhos Solução Injetável 22 mcg ou 44 mcg. 2020. p. 1–19.  
71. Prakash RS, Schirda B, Valentine TR, Crotty M, Nicholas JA. Emotion dysregulation in multiple sclerosis: Impact on symptoms of depression and anxiety. Mult Scler Relat Disord. 2019 Nov;36(March):101399.  
72. Gervasoni E, Cattaneo D, Jonsdottir J. Effect of treadmill training on fatigue in multiple sclerosis. Int J Rehabil Res. 2014 Mar;37(1):54–60.  
73. Velikonja O, Čurić K, Ožura A, Jazbec SŠ. Influence of sports climbing and yoga on spasticity, cognitive function, mood and fatigue in patients with multiple sclerosis. Clin Neurol Neurosurg. 2010 Sep;112(7):597–601.  
74. Romberg A, Virtanen A, Ruutiainen J. Long–term exercise improves functional impairment but not quality of life in multiple sclerosis. J Neurol. 2005 Jul;252(7):839–45.  
75. Bjarnadottir OH, Konradsdottir AD, Reynisdottir K, Olafsson E. Multiple sclerosis and brief moderate exercise. A randomised study. Mult Scler J. 2007 Jul;13(6):776–82.  
76. Ahmadi A, Arastoo AA, Nikbakht M, Zahednejad S, Rajabpour M. Comparison of the Effect of 8 weeks Aerobic and Yoga Training on Ambulatory Function, Fatigue and Mood Status in MS Patients. Iran Red Crescent Med J. 2013 Jun;15(6):449–54.  
77. Hayes K. Impact of extended-release dalfampridine on walking ability in patients with multiple sclerosis. Neuropsychiatr Dis Treat. 2011 Apr;7(1):229.  
78. Hebert JR, Corboy JR, Manago MM, Schenkman M. Effects of Vestibular Rehabilitation on Multiple Sclerosis–Related Fatigue and Upright Postural Control: A Randomized Controlled Trial. Phys Ther. 2011 Aug;91(8):1166–83.  
79. Francabandera FL, Holland NJ, Wiesel-Levison P, Scheinberg LC. Multiple Sclerosis Rehabilitation: Inpatient vs. Outpatient. Rehabil Nurs. 1988 Sep;13(5):251–3.  
80. Wiles CM. Controlled randomised crossover trial of the effects of physiotherapy on mobility in chronic multiple sclerosis. J Neurol Neurosurg Psychiatry. 2001 Feb;70(2):174–9.  
81. Coggrave M, Norton C, Cody JD. Management of faecal incontinence and constipation in adults with central neurological diseases. Cochrane Database Syst Rev. 2014 Jan;(1):CD002115.  
82. McClurg D, Goodman K, Hagen S, Harris F, Treweek S, Emmanuel A, et al. Abdominal massage for neurogenic bowel dysfunction in people with multiple sclerosis (AMBER — Abdominal Massage for Bowel Dysfunction Effectiveness  
34  
Research): study protocol for a randomised controlled trial. Trials. 2017 Dec;18(1):150.  
83. Preziosi G, Gordon-Dixon A, Emmanuel A. Neurogenic bowel dysfunction in patients with multiple sclerosis: prevalence, impact, and management strategies. Degener Neurol Neuromuscul Dis. 2018 Dec;Volume 8:79–90.  
84. Wiesel PH. Gut focused behavioural treatment (biofeedback) for constipation and faecal incontinence in multiple sclerosis. J Neurol Neurosurg Psychiatry. 2000 Aug;69(2):240–3.  
85. BRASIL. Ministério da Saúde. Secretaria de Atenção à Saúde. PORTARIA N<sup>o</sup> 1083, DE 02. DE OUTUBRO DE 2012. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Dor Crônica. Brasília. 2012 p. 1–25.  
86. Patel AS, Saratzis A, Arasaradnam R, Harmston C. Use of Antegrade Continence Enema for the Treatment of Fecal Incontinence and Functional Constipation in Adults. Dis Colon Rectum. 2015 Oct;58(10):999–1013.  
87. Thomas PW, Thomas S, Hillier C, Galvin K, Baker R. Psychological interventions for multiple sclerosis. Cochrane Database Syst Rev. 2006 Jan;(1).  
88. Minden SL, Feinstein A, Kalb RC, Miller D, Mohr DC, Patten SB, et al. Evidence-based guideline: Assessment and management of psychiatric disorders in individuals with MS: Report of the Guideline Development Subcommittee of the American Academy of Neurology. Neurology. 2014 Jan;82(2):174–81.  
89. Hind D, Cotter J, Thake A, Bradburn M, Cooper C, Isaac C, et al. Cognitive behavioural therapy for the treatment of depression in people with multiple sclerosis: a systematic review and meta-analysis. BMC Psychiatry. 2014 Dec;14(1):5.  
90. Graziano F, Calandri E, Borghi M, Bonino S. The effects of a group-based cognitive behavioral therapy on people with multiple sclerosis: a randomized controlled trial. Clin Rehabil. 2014 Mar;28(3):264–74.  
91. Larcombe NA, Wilson PH. An Evaluation of Cognitive-Behaviour Therapy for Depression in Patients with Multiple Sclerosis. Br J Psychiatry. 1984 Oct;145(4):366–71.  
92. Mohr DC, Likosky W, Bertagnolli A, Goodkin DE, Van Der Wende J, Dwyer P, et al. Telephone-administered cognitive–behavioral therapy for the treatment of depressive symptoms in multiple sclerosis. J Consult Clin Psychol. 2000;68(2):356–61.  
93. Mohr DC, Boudewyn AC, Goodkin DE, Bostrom A, Epstein L. Comparative outcomes for individual cognitive-behavior therapy, supportive-expressive group psychotherapy, and sertraline for the treatment of depression in multiple sclerosis. J Consult Clin Psychol. 2001;69(6):942–9.  
94. Mohr DC, Hart SL, Julian L, Catledge C, Honos-Webb L, Vella L, et al. Telephone-Administered Psychotherapy for Depression. Arch Gen Psychiatry. 2005 Sep;62(9):1007.  
95. Forman A, Lincoln N. Evaluation of an adjustment group for people with multiple sclerosis: a pilot randomized controlled trial. Clin Rehabil. 2010 Mar;24(3):211–21.  
96. Cooper CL, Hind D, Parry GD, Isaac CL, Dimairo M, O’Cathain A, et al. Computerised cognitive behavioural therapy for the treatment of depression in people with multiple sclerosis: external pilot trial. Trials. 2011 Dec;12(1):259.  
97. Lincoln NB, Yuill F, Holmes J, Drummond AE, Constantinescu CS, Armstrong S, et al. Evaluation of an adjustment group forpeople with multiple sclerosis and lowmood: a randomized controlled trial. Mult Scler J. 2011 Oct;17(10):1250–7.  
98. Nordin L, Rorsman I. Cognitive behavioural therapy in multiple sclerosis: A randomized controlled pilot study of acceptance and commitment therapy. J Rehabil Med. 2012 Jan;44(1):87–90.  
99. Bombardier CH, Ehde DM, Gibbons LE, Wadhwani R, Sullivan MD, Rosenberg DE, et al. Telephone-based physical activity counseling for major depression in people with multiple sclerosis. J Consult Clin Psychol. 2013;81(1):89–99.  
100. Raissi A, Bulloch AGM, Fiest KM, McDonald K, Jetté N, Patten SB. Exploration of Undertreatment and Patterns of Treatment of Depression in Multiple Sclerosis. Int J MS Care. 2015 Nov;17(6):292–300.  
35  
101. Pérez LP, González RS, Lázaro EB. Treatment of Mood Disorders in Multiple Sclerosis. Curr Treat Options Neurol. 2015 Jan;17(1):323.  
102. Skokou M, Soubasi E, Gourzis P. Depression in Multiple Sclerosis: A Review of Assessment and Treatment Approaches in Adult and Pediatric Populations. ISRN Neurol. 2012 Oct;2012:1–6.  
103. MARRIE et al. The burden of mental comorbidity in multiple sclerosis: frequent, underdiagnosed, and undertreated. Mult Scler. 2009 Mar;15(3):385–92.  
104. Koch MW, Glazenborg A, Uyttenboogaart M, Mostert J, De Keyser J. Pharmacologic treatment of depression in multiple sclerosis. Cochrane Database Syst Rev. 2011 Feb;(2).  
105. Fiest KM, Walker JR, Bernstein CN, Graff LA, Zarychanski R, Abou-Setta AM, et al. Systematic review and metaanalysis of interventions for depression and anxiety in persons with multiple sclerosis. Mult Scler Relat Disord. 2016 Jan;5:12–26.  
106. Ehde DM, Kraft GH, Chwastiak L, Sullivan MD, Gibbons LE, Bombardier CH, et al. Efficacy of paroxetine in treating major depressive disorder in persons with multiple sclerosis. Gen Hosp Psychiatry. 2008 Jan;30(1):40–8.  
107. Schiffer RB, Herndon RM, Rudick RA. Treatment of Pathologic Laughing and Weeping with Amitriptyline. N Engl J Med. 1985 Jun;312(23):1480–2.  
108. Siniscalchi A, Gallelli L, Tolotta GA, Loiacono D, De Sarro G. Open, uncontrolled, nonrandomized, 9-month, off-label use of bupropion to treat fatigue in a single patient with multiple sclerosis. Clin Ther. 2010 Nov;32(12):2030–4.  
109. Nathoo N, Mackie A. Treating depression in multiple sclerosis with antidepressants: A brief review of clinical trials and exploration of clinical symptoms to guide treatment decisions. Mult Scler Relat Disord. 2017 Nov;18(August):177–80.  
110. WYETH. SOLU-MEDROL® succinato sódico de metilprednisolona. 2018;1–6.  
111. BIOGEN Brasil Produtos Farmacêuticos Ltda. AVONEX® betainterferona 1a. 2017;  
112. MERCK S.A. Rebif® betainterferona-1a recombinante. 2014;1–12.  
113. BAYER S.A. Betaferon® betainterferona 1b. 2016;  
114. ASPEN Pharma Indústria Farmacêutica Ltda. IMURAN® azatioprina. 2014;1–8.  
115. Sormani MP, Rio J, Tintorè M, Signori A, Li D, Cornelisse P, et al. Scoring treatment response in patients with relapsing multiple sclerosis. Mult Scler J. 2013;19(5):605–12.  
116. Annunziata P, Lore’ F, Venturini E, Morana P, Guarino E, Borghi S, et al. Early synthesis and correlation of serum antithyroid antibodies with clinical parameters in multiple sclerosis. J Neurol Sci. 1999 Sep;168(1):32–6.  
117. Coles AJ, Wing M, Smith S, Coraddu F, Greer S, Taylor C, et al. Pulsed monoclonal antibody treatment and autoimmune thyroid disease in multiple sclerosis. Lancet. 1999 Nov;354(9191):1691–5.  
118. Durelli L. Thyroid Function and Autoimmunity during Interferon -1b Treatment: A Multicenter Prospective Study. J Clin Endocrinol Metab. 2001 Aug;86(8):3525–32.  
119. Karni A, Abramsky O. Association of MS with thyroid disorders. Neurology. 1999 Sep;53(4):883–883.  
120. Seyfert S, Klapps P, Meisel C, Fischer T, Junghan U. Multiple sclerosis and other immunologic diseases. Acta Neurol Scand. 2009 Jan;81(1):37–42.  
121. Bayas A, Rieckmann P. Managing the Adverse Effects of Interferon-?? Therapy in Multiple Sclerosis. Drug Saf. 2000;22(2):149–59.  
122. Moses H, Brandes DW. Managing adverse effects of disease-modifying agents used for treatment of multiple sclerosis. Curr Med Res Opin. 2008 Sep;24(9):2679–90.  
123. Walther EU, Hohlfeld R. Multiple sclerosis: Side effects of interferon beta therapy and their management. Neurology. 1999 Nov;53(8):1622–1622.  
36  
124. Linker RA, Haghikia A. Dimethyl fumarate in multiple sclerosis: latest developments, evidence and place in therapy. Ther Adv Chronic Dis. 2016 Jul;7(4):198–207.  
125. Cohen JA, Barkhof F, Comi G, Hartung HP, Khatri BO, Montalban X, et al. Oral Fingolimod or Intramuscular Interferon for Relapsing Multiple Sclerosis. N Engl J Med. 2010 Feb;362(5):402–15.  
126. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Natalizumabe 300mg (Tysabri®) para Esclerose Múltipla Remitente Recorrente em segunda linha de tratamento. 2013;  
127. Brasil M da SS de V em SD de V das DT. Manual de Recomendações para o Controle da Tuberculose no Brasil. Brasília, DF; 2019.  
128. Dantas LA, Pereira MS, Gauza A de M, Schulz MEB, Silva GF da, Martin MEM, et al. Latent tuberculosis infection reactivation in patients with multiple sclerosis in  use of disease-modifying therapies: A systematic review. Mult Scler Relat Disord. 2021 Oct;55:103184.  
129. Navas C, Torres-Duque CA, Munoz-Ceron J, Álvarez C, García JR, Zarco L, et al. Diagnosis and treatment of latent tuberculosis in patients with multiple  sclerosis, expert consensus. On behalf of the Colombian Association of Neurology, Committee of Multiple Sclerosis. Mult Scler J - Exp Transl Clin. 2018;4(1):2055217317752202.  
37

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Eu,___________________________________________________________________________ (nome do [a] paciente),  
declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de alentuzumabe, azatioprina, betainterferonas, cladribina oral, fingolimode, fumarato de dimetila, glatirâmer, natalizumabe e teriflunomida, indicados para o tratamento de esclerose múltipla.  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a)_______________________  
______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas;  
- redução do número de internações hospitalares.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos do uso do medicamento:  
- A teriflunomida e a cladribina oral são contraindicadas para uso por gestantes (categoria de risco X);  
- não se sabe ao certo os riscos do uso do fumarato de dimetila, fingolimode, natalizumabe e alentuzumabe na gravidez;  
- portanto, caso engravide, devo avisar imediatamente o médico;  
- há evidências de riscos ao bebê com o uso de azatioprina, mas um benefício potencial pode ser maior que os riscos;  
- é pouco provável que o glatirâmer apresente risco para o bebê; os benefícios potenciais provavelmente sejam maiores  
- que os riscos;  
- eventos adversos da azatioprina: diminuição das células brancas, vermelhas e plaquetas do sangue, náuseas, vômitos,  
- diarreia, dor abdominal, fezes com sangue, problemas no fígado, febre, calafrios, diminuição de apetite, vermelhidão de ele, queda de cabelo, aftas, dores nas juntas, problemas nos olhos (retinopatia), falta de ar, pressão baixa;  
- eventos adversos das betainterferonas: reações no local de aplicação, sintomas de tipo gripal, distúrbios menstruais, depressão (inclusive com ideação suicida), ansiedade, cansaço, perda de peso, tonturas, insônia, sonolência, palpitações, dor no peito, aumento da pressão arterial, problemas no coração, diminuição das células brancas, vermelhas e plaquetas do sangue, falta de ar, inflamação na garganta, convulsões, dor de cabeça e alterações das enzimas do fígado;  
- eventos adversos do glatirâmer: dor e irritação no local da injeção, dor no peito e dores difusas, aumento dos batimentos  
- do coração, dilatação dos vasos, ansiedade, depressão, tonturas, coceira na pele, tremores, falta de ar e suor;  
- eventos adversos da teriflunomida: cefaleia, diarreia, náusea, alopecia e aumento da enzima alanina aminotransferase  
- (ALT/TGP);  
- eventos adversos do fumarato de dimetila: rubor, eventos gastrointestinais (diarreia, náuseas, dor abdominal, dor abdominal superior), linfopenia, leucopenia, sensação de queimação, fogacho, vômito, gastrite, prurido, eritema, proteinúria e aumento de aminotransferases. LEMP reação adversa grave, já foi relatada, portanto, os pacientes devem ser monitorizados regularmente para que sejam detectados quaisquer sinais ou sintomas que possam sugerir LEMP, como infecções e reações de hipersensibilidade;  
- eventos adversos do fingolimode: dor de cabeça, dor nas costas, diarreia, tosse, tontura, fraqueza, queda de cabelo, falta de ar, elevação das enzimas do fígado, infecções virais, sinusite, problemas de visão e diminuição dos batimentos no coração que podem acontecer logo após a administração da primeira dose do medicamento e até seis horas após. LEMP, já foi relatada,  
38  
portanto, os pacientes devem ser monitorizados regularmente para que sejam detectados quaisquer sinais ou sintomas que possam sugerir LEMP, como infecções e reações de hipersensibilidade;  
- eventos adversos do natalizumabe: dor de cabeça, tontura, vômitos, náuseas, alergias, arrepios, cansaço e alterações nas enzimas do fígado. LEMP, já foi relatada, portanto, os pacientes devem ser monitorizados regularmente para que sejam detectados quaisquer sinais ou sintomas que possam sugerir LEMP, como infecções e reações de hipersensibilidade.  
- eventos adversos da cladribina oral: linfopenia, bolhas nos lábios (herpes oral), herpes zoster com manifestação na pele, erupção na pele, queda de cabelo e pelos, diminuição do número de neutrófilos.  
- eventos adversos do alentuzumabe: linfopenia, leucopenia, taquicardia, hipertireoidismo, náusea, pirexia, fadiga, calafrios, infecção do trato urinário, infecção do trato respiratório superior, cefaleia, erupção cutânea, urticária, prurido, erupção cutânea generalizada, ruborização. O tratamento com alentuzumabe pode resultar na formação de autoanticorpos e aumento do risco de condições mediadas por autoimunidade, que podem ser graves e com risco de vida. LEMP foi relatada na póscomercialização, portanto, os pacientes devem ser monitorizados regularmente para que sejam detectados quaisquer sinais ou sintomas que possam sugerir LEMP, como infecções e reações de hipersensibilidade  
Estou ciente de que o medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (  ) Sim                 (  ) Não  
O meu tratamento constará do seguinte medicamento:  
- (  ) alentuzumabe  
- (  ) azatioprina  
- (  ) betainterferona 1a  
- (  ) betainterferona 1b  
- (  ) cladribina oral  
- (  ) fingolimode  
- (  ) fumarato de dimetila  
- (  ) glatirâmer  
- (  ) natalizumabe  
- (  ) teriflunomida  
39  
<!-- Start of picture text -->
Local:                                                                                                                                     Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>____________________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:   CRM:   UF:<br>____________________________________________<br>Assinatura do médico responsável<br><!-- End of picture text -->  
**Nota 1** : Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2** : A administração intravenosa de metilprednisolona é compatível com o procedimento 03.03.02.001-6 - Pulsoterapia I (por aplicação), da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS.  
40

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|**FUNÇÕES PIRAMIDAIS:**||
|---|---|
|Normal.|0|
|Sinais anormais sem incapacidade.|1|
|Incapacidade mínima.|2|
|Discreta ou moderada paraparesia ou hemiparesia; monoparesia grave.|3|
|Paraparesia ou hemiparesia acentuada; quadriparesia moderada; ou monoplegia.|4|
|Paraplegia, hemiplegia ou acentuada quadriparesia.|5|
|Quadriplegia.|6|
|Desconhecido.|(*)|
|**FUNÇÕES CEREBELARES:**||
|Normal.|0|
|Sinais anormais sem incapacidade.|1|
|Ataxia discreta em qualquer membro.|2|
|Ataxia moderada de tronco ou de membros.|3|
|Incapaz de realizar movimentos coordenados devido à ataxia.|4|
|Desconhecido.|(*)|
|**FUNÇÕES DO TRONCO CEREBRAL:**||
|Normal.|0|
|Somente sinais anormais.|1|
|Nistagmo moderado ou outra incapacidade leve.|2|
|Nistagmo grave, acentuada paresia extraocular ou incapacidade moderada de outros cranianos.|3|
|Disartria acentuada ou outra incapacidade acentuada.|4|
|Incapacidade de deglutir ou falar.|5|
|Desconhecido.|(*)|
|**FUNÇÕES SENSITIVAS:**||
|Normal.|0|
|Diminuição de sensibilidade ou estereognosia em 1-2 membros.|1|
|Diminuição discreta de tato ou dor, ou da sensibilidade posicional ou diminuição moderada da vibratória ou|2|
|estereognosia em 1-2 membros; ou diminuição somente da vibratória em 3-4 membros.||
|Diminuição moderada de tato ou dor, ou posicional, ou perda da vibratória em 1-2 membros; ou diminuição discreta<br>de tato ou dor ou diminuição moderada de toda propriocepção em 3-4 membros.|3|
|Diminuição acentuada de tato ou dor, ou perda da propriocepção em 1-2 membros; ou diminuição moderada de tato<br>ou dor ou diminuição acentuada da propriocepção em mais de 2 membros.|4|
|Perda da sensibilidade de -2 membros; ou moderada diminuição de tato ou dor ou perda da propriocepção na maior<br>parte do corpo abaixo da cabeça.|5|
|Anestesia da cabeça para baixo.|6|
|Desconhecido.|(*)|
|**FUNÇÕES VESICAIS:**||  
41  
|Normal.|0|
|---|---|
|Sintomas urinários sem incontinência|1|
|Incontinência menor ou igual uma vez por semana.|2|
|Incontinência maior ou igual uma vez por semana.|3|
|Incontinência diária ou mais que uma vez por dia.|4|
|Caracterização contínua.|5|
|Grau 5 para bexiga e grau 5 para disfunção retal.|6|
|Desconhecido.|(*)|
|**FUNÇÕES INTESTINAIS:**||
|Normal.|0|
|Obstipação menos que diária sem incontinência.|1|
|Obstipação diária sem incontinência.|2|
|Incontinência menos de uma vez semana.|3|
|Incontinência mais de uma vez semana, mas não diária.|4|
|Sem controle de esfíncter retal.|5|
|Grau 5 para bexiga e grau 5 para disfunção retal.|6|
|Desconhecido.|(*)|
|**FUNÇÕES VISUAIS:**||
|Normal.|0|
|Escotoma com acuidade visual (AV) igual ou melhor que 20/30.|1|
|Pior olho com escotoma e AV de 20/30 a 20/59|2|
|Pior olho com grande escotoma, ou diminuição moderada dos campos, mas com AV de 20/60 a 20/99.|3|
|Pior olho com diminuição acentuada dos campos a AV de 20/100 a 20/200; ou grau 3 com AV do melhor olho igual<br>ou menor que 20/60.|4|
|Pior olho com AV menor que 20/200; ou grau 4 com AV do melhor olho igual ou menor que 20/60.|5|
|Grau 5 com AV do melhor olho igual ou menor que 20/60.|6|
|Desconhecido.|(*)|
|**FUNÇÕES MENTAIS:**||
|Normal.|0|
|Alteração apenas do humor.|1|
|Diminuição discreta da mentação|2|
|Diminuição normal da mentação.|3|
|Diminuição acentuada da mentação (moderada síndrome cerebelar crônica).|4|
|Demência ou grave síndrome cerebral crônica|5|
|Desconhecido.|(*)|
|**OUTRAS FUNÇÕES:**||
|Nenhuma.|0|
|Qualquer outro achado devido à EM.|1|
|Desconhecido.|(*)|  
42  
<!-- Start of picture text -->
A soma dos escores é expressa como (*), quando a informação é desconhecida e, portanto, não soma valor.<br><!-- End of picture text -->  
<!-- Start of picture text -->
INTERPRETAÇÃO DOS SISTEMAS FUNCIONAIS E ESCALA DE EDSS   EDSS<br>Exame neurológico normal (todos SF grau 0; Grau 1 SF mental é aceitável).  0<br>Nenhuma incapacidade, sinais mínimos em 1 SF. (por ex.: sinal de Babinski ou diminuição da sensibilidade<br>1<br>vibratória).<br>Nenhuma incapacidade, sinais mínimos em mais de 1 SF.  1,5<br>Incapacidade mínima em 1 SF (1 SF grau 2, outros 0 ou 1).  2,0<br>Incapacidade mínima em 2 SF (2 SF grau 2, outros 0 ou 1).  2,5<br>Incapacidade moderada em 1 SF (1 SF grau 3, outros 0 ou 1), ou incapacidade discreta em 3 ou 4 SF (3 ou 4 SF<br>3,0<br>grau 2, outros 0 ou 1).<br>Pode caminhar a distância que quiser. Incapacidade moderada em 1 SF (grau 3) e 1 ou 2 SF grau 2; ou 2 SF grau<br>3,5<br>3; ou 5 SF grau 2 (outros 0 ou 1).<br>Pode caminhar sem ajuda ou descanso até 500 m. Auto-suficiente. (1 SF grau 4 (outros 0 ou 1), ou vários graus 3<br>4,0<br>ou menores).<br>Pode caminhar sem ajuda ou descanso até 300 m. Hábil para trabalhar todo o dia, podendo apresentar alguma<br>limitação ou requerer mínima assistência. (1 SF grau 4 - outros 0 ou 1 - ou combinação de graus menores que  4,5<br>excedam limites de estágios anteriores).<br>Pode caminhar sem ajuda ou descanso até 200 m. Apresenta incapacidade que compromete as atividades diárias.<br>5,0<br>(1 SF grau 5 - outros 0 ou 1 - ou combinação de graus menores que excedam especificações para o grau 4).<br>Pode caminhar sem ajuda ou descanso até 100 m. Incapacidade grave suficiente para impedir a realização das<br>atividades diárias. (1 SF grau 5 - outros 0 ou 1 - ou combinação de graus menores que excedam especificações para  5,5<br>o grau 4).<br>Auxílio intermitente ou unilateral constante (bengalas, muletas) para caminhar cerca de 100m com ou sem<br>6,0<br>descanso. (Combinações de SF com mais de 2 com grau 3.)<br>Auxílio bilateral constante para caminhar 20 m sem descanso. (Combinações de SF com mais de 2 com grau 3.)   6,5<br>Incapacidade para caminhar mais de 5 m, mesmo com auxílio; uso de cadeira de rodas; capaz de entrar e sair da  7,0<br>cadeira sem ajuda. (Combinações com mais de 1 SF grau 4; mais raramente, SF piramidal grau 5 isolado.)<br>Não consegue dar mais do que alguns poucos passos, essencialmente restrito à cadeira de rodas; pode precisar de  7,5<br>ajuda para entrar e sair da cadeira; não consegue permanecer na cadeira de rodas comum o dia inteiro (somente na<br>motorizada). Combinações com mais de 1 SF grau 4.<br>Essencialmente confinado à cadeira de rodas ou à cama. Consegue se locomover com a cadeira de rodas, porém  8,0<br>não consegue ficar fora da cama por muito tempo. Consegue realizar algumas funções de sua higiene e mantém o<br>uso dos braços. (Combinações, geralmente grau 4 em várias funções.)<br>Permanece na cama a maior parte do dia; consegue realizar algumas funções para cuidar de sua própria higiene e  8,5<br>mantém algum uso dos braços. (Combinações, geralmente grau 4 em várias funções.)<br>Acamado e incapacitado; consegue se comunicar e comer. Não realiza higiene própria (combinações, geralmente  9,0<br>grau 4 em várias funções).<br>Totalmente incapacitado; não consegue se comunicar efetivamente ou de comer/engolir. (Combinações, geralmente  9,5<br>grau 4 em várias funções.)<br><!-- End of picture text -->  
43  
Morte devido envolvimento tronco ou falência respiratória; ou morte consequente longo tempo acamado no leito 10 com pneumonia, sepsis, uremia ou falência respiratória.  
Fonte: Chaves MLF, Finkelsztejn A, Stefani MA. Rotinas em Neurologia e Neurocirurgia. Porto Alegre. Artmed, 2008. Capítulo “Escalas em Neurologia”.  
44

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Depois da sua publicação, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Esclerose Múltipla, pela necessidade de atualizar o item de Monitoramento da infecção por tuberculose ativa e rastreio da infecção por tuberculose latente (ILTB), de modo a harmonizar a orientação em todos os PCDT que preconizam o uso de medicamentos modificadores do curso da doença (MMCD) biológicos ou MMCD sintéticos-alvo específico.  
O tema foi apresentado como informe à 125ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 20 de maio de 2025, e também à 141ª Reunião Ordinária da Conitec, em junho de 2025.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O objetivo desta atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Esclerose Múltipla foi incluir o medicamento cladribina oral para tratamento de pacientes com esclerose múltipla remitente-recorrente altamente ativa, incorporado ao SUS conforme Portaria SECTICS/MS nº 62, de 27 de outubro de 2023 e o Relatório de Recomendação nº 855, de setembro de 2023. Conforme a referida Portaria, foi incorporada, no âmbito do SUS, a cladribina oral para tratamento de pacientes com esclerose múltipla remitente-recorrente altamente ativa, conforme protocolo do Ministério da Saúde.  
Considerando a versão do PCDT de Esclerose Múltipla, recomendada por meio do Relatório de Recomendação nº 839/2023, esta atualização rápida focou na inclusão de cladribina no âmbito do SUS.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O Protocolo foi atualizado pela Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS) e por médicas especialistas no tema.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A proposta de atualização do PCDT de Esclerose Múltipla foi apresentada na 112ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 15 de fevereiro de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e da Secretaria de Atenção Especializada à Saúde (SAES). A proposta foi aprovada para avaliação pelo Comitê de PCDT da Conitec. **Consulta pública**  
A Consulta Pública nº 10/2024 do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla foi realizada entre os dias 22 de março e 10 de abril de 2024. Foram recebidas 792 contribuições, que podem ser verificadas em: http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20210930_CP_CONITEC_78_2021_PCDT_Esclerose.pdf

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Considerando a versão do PCDT de Esclerose Múltipla recomendada por meio do Relatório de Recomendação nº 839/2023 esta atualização rápida teve foco na inclusão de cladribina oral para tratamento de pacientes com esclerose múltipla remitente-recorrente altamente ativa.  
45  
As evidências e pergunta de pesquisa avaliadas no momento da incorporação de cladribina oral para tratamento de pacientes com esclerose múltipla remitente-recorrente altamente ativa, incluído nesta atualização, encontram-se no Relatório de Recomendação nº 855/2023, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2023/cladribina-oral-paratratamento-de-pacientes-com-esclerose-multipla-remitente-recorrente-altamente-ativa-conforme-protocolo-do-ministerio-dasaude.  
Assim, foram atualizadas todas as seções do PCDT para contemplar a nova tecnologia a ser disponibilizada no SUS.  
46

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do PCDT da Esclerose Múltipla contendo a descrição da metodologia utilizada, tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por técnicos do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde do Ministério da Saúde (DGITS/SECTICS/MS).  
A atualização do PCDT da Esclerose Múltipla foi motivada pela alteração de bula do medicamento betainterferona 1a das empresas Biogen Brasil (marca Avonex®) e Merck (marca Rebif®), em que houve a exclusão da contraindicação de uso em gestantes e lactantes e alteração da classificação de risco do fármaco para a categoria B. Também foram inseridas informações sobre o rastreio de tuberculose latente no monitoramento dos pacientes em uso de MMCD.  
Assim, foram atualizadas as seções: casos especiais, critérios de interrupção, além do Termo de Esclarecimento e Responsabilidade.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O Protocolo foi atualizado pela Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS).

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A atualização do PCDT da Esclerose Múltipla foi apresentada à 105ª Reunião da Subcomissão Técnica de Avaliação de PCDT, em 17 de janeiro de 2023, em que estiveram representantes da Secretaria de Atenção Especializada em Saúde (SAES), da Secretaria de Atenção Primária à Saúde (SAPS), da Secretaria de Vigilância Sanitária (SVS) e da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS). Não houve apontamentos quanto às alterações realizadas no texto. **Consulta pública**  
A Consulta Pública nº 08/2023, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla, foi realizada entre os dias 19/04/2023 e 08/05/2023. Foram recebidas 30 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2023/cp_conitec_008_2023_protocolo_clinico_e.pdf</u>  
As contribuições e os documentos recebidos na consulta pública acerca do rastreamento da tuberculose latente foram analisados conjuntamente com a área técnica do Ministério da Saúde responsável pelo controle da tuberculose (Coordenaçãogeral de Vigilância da Tuberculose, Micoses Endêmicas e Micobactérias não Tuberculosas/ DATHI/SVSA) tendo como base as bulas vigentes dos medicamentos e a menção à tuberculose, além de dois estudos científicos que avaliaram os tratamentos da esclerose múltipla e sua segurança quanto à reativação da tuberculose latente. Os medicamentos que se mostraram seguros em ambos os estudos e que não possuíam apontamento em bula sobre cuidados necessários em casos de ILTB foram alterados no PCDT como não sendo necessário o rastreamento da ILTB previamente ao início do tratamento. Considerando a alta carga de tuberculose no Brasil, foi mantida a recomendação do rastreamento da ILTB para os demais medicamentos, seja por não serem seguros seja por não possuírem evidências suficientes de segurança.  
47  
**Quadro A.** Avaliação da segurança para reativação da tuberculose latente dos medicamentos preconizados no PCDT da esclerose múltipla vigente  
|**Medicamentos**<br>**preconizados**|**Bulas**<br>**(versão**<br>**vigente**<br>**em**<br>**20/06/2023)**|**Dantas et al.**<sup>**a**</sup>|**Navas et al.**<sup>**b**</sup>||
|---|---|---|---|---|
|**Acetato**<br>**de**<br>**glatirâmer**|Não aborda|Seguro<br>para<br>ILTB,<br>sem<br>necessidade de rastreamento|Seguro<br>para<br>necessidade de|ILTB,<br>sem<br>rastreamento|
|**Alentuzumabe**|"Tuberculose<br>foi<br>relatada<br>em<br>pacientes tratados com LEMTRADA<br>e IFNB-1a em estudos clínicos<br>controlados. Tuberculose latente e<br>ativa foi relatada em 0,3% dos<br>pacientes<br>tratados<br>com<br>LEMTRADA, mais frequentemente<br>em regiões endêmicas. A triagem<br>para tuberculose deve ser realizada<br>antes do início de LEMTRADA, de<br>acordo com as diretrizes locais."|Altamente<br>recomendado<br>rastreamento para ILTB|Recomendado<br>para ILTB|rastreamento|
|**Azatioprina**|"Medicamentos<br>imunossupressores<br>podem ativar focos primários de<br>tuberculose.<br>Os<br>médicos<br>que<br>acompanham<br>pacientes<br>sob<br>imunossupressão devem estar alertas<br>à possibilidade de surgimento de<br>doença ativa, tomando, assim, todos<br>os cuidados para o diagnóstico<br>precoce e tratamento."|Altamente<br>recomendado<br>rastreamento para ILTB|Não avaliado||
|**Betainterferona 1A**|Não aborda|Seguro<br>para<br>ILTB,<br>sem<br>necessidade de rastreamento|Seguro<br>para<br>necessidade de|ILTB,<br>sem<br>rastreamento|
|**Betainterferona 1B**|Não aborda|Seguro<br>para<br>ILTB,<br>sem<br>necessidade de rastreamento|Seguro<br>para<br>necessidade de|ILTB,<br>sem<br>rastreamento|
|**Fingolimode**|Não aborda|Dados<br>inconclusivos,<br>considerar rastreamento|Recomendado<br>para ILTB|rastreamento|
|**Fumarato de dimetila**|Não aborda|Dados<br>inconclusivos,<br>considerar rastreamento|Recomendado<br>para ILTB|rastreamento|
|**Metilprednisolona**<sup>**c**</sup>|"O uso de corticosteroides em<br>tuberculose ativa deve ser restrito aos||||
|**Devido**<br>**à**<br>**peculiaridade**<br>**da**<br>**dosagem**<br>**e**<br>**da**<br>**frequência utilizada**<br>**para os casos de surto**|casos de tuberculose fulminante ou<br>disseminada, nos quais se utiliza o<br>corticosteroide<br>associado<br>a<br>um<br>adequado esquema antituberculose<br>para<br>controlar<br>a<br>doença.<br>Se<br>corticosteroides forem indicados em|Altamente<br>recomendado<br>rastreamento para ILTB|Seguro<br>para<br>necessidade de|ILTB,<br>sem<br>rastreamento|  
48  
|**Medicamentos**<br>**preconizados**|**Bulas**<br>**(versão**<br>**vigente**<br>**em**<br>**20/06/2023)**|**Dantas et al.**<sup>**a**</sup>|**Navas et al.**<sup>**b**</sup>||
|---|---|---|---|---|
||pacientes com tuberculose latente ou<br>reatividade à tuberculina, deve-se<br>exercer uma cuidadosa vigilância,<br>pois pode ocorrer reativação da<br>doença. Durante terapia prolongada<br>com corticosteroide, esses pacientes<br>devem receber quimioprofilaxia."<br>"Medicamentos<br>imunossupressores<br>podem ativar focos primários de<br>tuberculose.<br>Os<br>médicos<br>que<br>acompanham<br>pacientes<br>sob<br>imunossupressão devem estar alertas<br>quanto à possibilidade de surgimento<br>de doença ativa, tomando, assim,<br>todos os cuidados para o diagnóstico<br>precoce e tratamento"||||
|**Natalizumabe**|Não aborda|Seguro<br>para<br>ILTB,<br>sem<br>necessidade de rastreamento|<br>Recomendado<br>para ILTB|rastreamento|
|**Teriflunomida**|"Nos<br>estudos<br>clínicos<br>com<br>teriflunomida, foi observado casos de<br>tuberculose e reativação de hepatite<br>por<br>citomegalovírus."<br>"A segurança de teriflunomida em<br>indivíduos com tuberculose latente é<br>desconhecida, pois a triagem de<br>tuberculose<br>não<br>foi<br>realizada<br>sistematicamente<br>nos<br>estudos<br>clínicos. Para pacientes positivos na<br>triagem de tuberculose, tratar com a<br>prática médica padrão antes da<br>terapia com teriflunomida."|Altamente<br>recomendado<br>rastreamento para ILTB|<br>Recomendado<br>para ILTB|rastreamento|  
**Legenda** :  
> a <mark>Dantas LA, Pereira MS, Gauza AM, Schulz MEB, Silva GFD, Martin MEM, Medeiros Junior WLG, Gonçalves MVM. Latent tuberculosis infection reactivation in patients with multiple sclerosis in use of disease-modifying therapies: A systematic review. Mult Scler Relat Disord. 2021 Oct;55:103184. doi: 10.1016/j.msard.2021.103184. Epub 2021 Aug 1. PMID: 34384990.</mark>  
> b <mark>Navas C, Torres-Duque CA, Munoz-Ceron J, Álvarez C, García JR, Zarco L, Vélez LA, Awad C, Castro CA. Diagnosis and treatment of latent tuberculosis in patients with multiple sclerosis, expert consensus. On behalf of the Colombian Association of Neurology, Committee of Multiple Sclerosis. Mult Scler J Exp Transl Clin. 2018 Jan 17;4(1):2055217317752202. doi: 10.1177/2055217317752202. PMID: 29372069; PMCID: PMC5774739.</mark>  
> c <mark>Brasil M da SS de V em SD de V das DT. Manual de Recomendações para o Controle da Tuberculose no Brasil. Brasília, DF; 2019.</mark>  
49

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Os membros do Comitê de PCDT, presentes na 121ª Reunião da Conitec, realizada no dia 1º de agosto de 2023, deliberaram, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla. Foi assinado o Registro de Deliberação nº 836/2023.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A partir da versão do PCDT da Esclerose Múltipla publicada por meio da Portaria Conjunta SAES-SCTIE/MS nº 1/2022, foram alteradas as informações referentes à contraindicação do medicamento betainterferona 1a na gestação e amamentação, mantendo-se sua estrutura metodológica. Além disso, foram incluídas informações sobre o rastreamento da tuberculose latente.  
50

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Esclerose Múltipla foi motivada pela incorporação no SUS do medicamento alentuzumabe, por meio da Portaria SCTIE/MS nº 15, de 28 de abril de 2021 (Relatório de Recomendação Nº 609, de abril de 2021, da Conitec), como tratamento de pacientes com esclerose múltipla remitente recorrente com alta atividade da doença em falha terapêutica ao natalizumabe conforme estabelecido no Protocolo Clínico e Diretrizes Terapêuticas (PCDT).  
Assim, devido à inclusão desse medicamento, foram atualizadas as sessões: abordagem terapêutica, critérios de inclusão, critérios de exclusão, monitoramento, critérios de interrupção e Termo de Esclarecimento e Responsabilidade.  
Cabe destacar a atualização na sessão Abordagem terapêutica – Linhas de tratamento da EMRR com MMCD: partindo da premissa de que, na versão vigente do PCDT, foi contemplado o conceito de “linhas de tratamento” por “atividade da doença”, a sessão foi reorganizada com subtópicos a partir desses conceitos. Também foi inserido o medicamento alentuzumabe como segunda linha em caso de doença de alta atividade e revisado o fluxograma de tratamento com MMCD de forma a contemplar essas alterações.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O Protocolo foi atualizado pela Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) com a revisão externa de especialistas da área.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A atualização do PCDT da Esclerose Múltipla foi apresentada à 92ª Reunião da Subcomissão Técnica de Avaliação de PCDT, em 17 de agosto de 2021, da Conitec. Não houve apontamentos quanto às alterações realizadas no texto.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A Consulta Pública nº 78/2021 do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla foi realizada entre os dias 10 e 29 de setembro de 2021. Foram recebidas 358 contribuições, que podem ser verificadas em:  
http://conitec.gov.br/images/Consultas/Contribuicoes/2021/20210930_CP_CONITEC_78_2021_PCDT_Esclerose.pdf

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Os membros da Conitec presentes na 103ª Reunião Ordinária, realizada nos dias 10 e 11 de novembro de 2021, deliberaram, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla, encaminhando o tema para a decisão do Secretário da SECTICS. Foi assinado o Registro de Deliberação nº 676/2021.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Foi utilizada como base a versão vigente do PCDT da Esclerose Múltipla (Portaria Conjunta SAES-SCTIE/MS Nº 3, de 5 de fevereiro de 2021), a qual manteve sua estrutura metodológica e foram acrescentadas informações referentes à tecnologia incorporada (alentuzumabe), conforme o Relatório de Recomendação Nº 609, de abril de 2021, da Conitec, e diretrizes internacionais.  
Para efeito de registro, mantém-se o registro da atualização do PCDT em 2020, a seguir.  
51

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A atualização do PCDT da Esclerose Múltipla é uma demanda proveniente da Portaria SCTIE/MS nº 65, de 27 de dezembro de 2019, que incorporou o fumarato de dimetila para tratamento de primeira linha da esclerose múltipla remitenterecorrente no SUS (Relatório de Recomendação nº 582, da Conitec).  
As questões tratadas neste documento foram estabelecidas em reunião de escopo, realizada em setembro de 2019, que teve a participação de médicos neurologistas, representantes de sociedade médica e de pacientes, representantes do Ministério da Saúde (MS) e do grupo elaborador. O escopo deste PCDT foi redigido abrangendo 10 questões clínicas e foram validadas pelo painel de especialistas.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A reunião presencial para definição do escopo do Protocolo Clínico e Diretriz Terapêutica (PCDT) foi conduzida com a presença de membros do Grupo Elaborador e do Ministério da Saúde. Todos os participantes preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Além dos representantes do Ministério da Saúde do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/MS), participaram metodologistas do Centro Colaborador do SUS (CCATES/UFMG), colaboradores e especialistas no tema.  
**Quadro A.** Participantes na atualização do PCDT  
|**GRUPO ELABORADOR**||
|---|---|
|**Nome**|**Instituição**|
|Augusto Afonso Guerra Júnior|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|
|Juliana Álvares-Teodoro|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|
|Francisco de Assis Acúrcio|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|
|Isabella de Figueiredo Zuppo|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|
|Nélio Gomes Ribeiro Júnior|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|
|Carolina M. Fontes Ferreira Nader|Centro Colaborador do SUS/Universidade Federal de Minas Gerais, Belo<br>Horizonte/MG|  
52  
|**GRUPO ELABORADOR**|||
|---|---|---|
|**Nome**|**Instituição**||
|Natália Dias Brandão|Centro Colaborador do SUS/Universidade Federal de Minas Gerais,<br>Horizonte/MG|Belo|
|Pâmela Santos Azevedo|Centro Colaborador do SUS/Universidade Federal de Minas Gerais,<br>Horizonte/MG|Belo|
|Túlio Tadeu Rocha Sarmento|Centro Colaborador do SUS/Universidade Federal de Minas Gerais,<br>Horizonte/MG|Belo|
|Ludmila Peres Gargano|Centro Colaborador do SUS/Universidade Federal de Minas Gerais,<br>Horizonte/MG|Belo|
|**ESPECIALISTAS E COLABORAD**|**ORES**||
|Elizabeth Regina Comini Forte|Universidade Federal de Minas Gerais, Belo Horizonte/MG||
|Felipe von Glehn Silva|Universidade de Brasília, Brasília/DF||
|Gustavo San Martin|Amigos Múltiplos pela Esclerose, São Paulo/SP||
|Rodrigo Gonçalves Kleinpaul Vieira|Universidade Federal de Minas Gerais, Belo Horizonte/MG||
|Tarso Adoni|Associação Brasileira de Neurologia, São Paulo/SP||

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A proposta de atualização do PCDT da Esclerose Múltipla foi apresentada em reunião extraordinária da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada no dia 22 de setembro de 2020. A reunião teve a participação de representantes do Departamento de Gestão, Incorporação e Inovação de Tecnologias em Saúde (DGITIS/SECTICS), Departamento de Ciência e Tecnologia (DECIT/SECTICS), Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS), Secretaria de Vigilância em Saúde (SVS) e Secretaria de Atenção Especializada à Saúde (SAES). Após a subcomissão, os ajustes necessários foram realizados e, em seguida, a proposta foi apresentada aos membros do Plenário da Conitec em sua 91ª Reunião Ordinária, os quais recomendaram favoravelmente o texto.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A Consulta Pública nº 54 do PCDT da Esclerose Múltipla foi realizada entre os dias 27/10/2020 a 23/11/2020. Foram recebidas 165 contribuições no total e salienta-se que todas foram analisadas. O conteúdo integral das contribuições encontra-se  
disponível na página da Conitec em: http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_54_2020_PCDT_EscleroseMultipla.pdf.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Os membros da CONITEC presentes à reunião do plenário da Conitec, realizada nos dias 08 e 09 de dezembro de 2020, deliberaram, por unanimidade, recomendar a aprovação do Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla. O tema será encaminhado para a decisão do Secretário da SECTICS. Foi assinado o Registro de Deliberação nº 577/2020.  
53

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para elaborar este Protocolo, foram realizadas duas revisões sistemáticas (RS): uma sobre o uso de natalizumabe como primeira escolha de tratamento para a Esclerose Múltipla Remitente-recorrente (EMRR) em pacientes com alta atividade da doença (AA), e outra sobre a utilização dos medicamentos modificadores do curso da doença (MMCDs) em gestantes. As revisões for <mark>am realizadas por d</mark> ois revisores que avaliaram independentemente os títulos e resumos dos artigos, determinaram a elegibilidade e extraíram os dados. Os dados extraídos foram sumarizados. A evidência foi sintetizada narrativamente e resumida usando estatísticas descritivas. Quando possível, foi realizada meta-análise utilizando modelo de efeitos aleatórios, sendo realizadas análises de sensibilidade quando adequado. A heterogeneidade entre os estudos foi avaliada utilizando o teste I- quadrado.  
1. Para responder à questão sobre o uso de natalizumabe como primeira escolha para EMRR em pacientes com alta atividade da doença foi realizada uma RS com meta-análise. A busca de literatura foi realizada nas bases de dados MEDLINE (via PubMed), EMBASE e The Cochrane Library. Em caráter complementar, foi realizada a busca manual por estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão taxa anualizada e incidência de surtos, progressão da incapacidade, atividade radiológica, sobrevivência, incidência de eventos adversos graves e de leucoencefalopatia multifocal progressiva (Quadro A).  
2. Para responder à questão sobre uso de medicamentos modificadores do curso da doença para tratamento da EMRR em gestantes, foi realizada uma RS com meta-análise. A busca de literatura foi realizada nas bases de dados MEDLINE (via PubMed), EMBASE e The Cochrane Library. Em caráter complementar, foi realizada a busca manual por estudos relevantes entre as referências dos estudos inicialmente selecionados. Entre os desfechos avaliados estão mortalidade materna e fetal/neonatal, intercorrências na gestação, abortos, nascimentos prematuros, malformações (Quadro B). As estratégias de busca encontram-se descritas nos quadros C e D.  
**Quadro A -** Pergunta estruturada utilizada para responder à questão sobre uso de natalizumabe para EMRR em alta atividade  
|**P**|**População**|Pacientes adultos (> 18 anos) com esclerose múltipla remitente-recorrente (EMRR) em alta<br>atividade da doença|
|---|---|---|
|**I**|**Intervenção**|Natalizumabe|
|**C**|**Comparadores**|● Outros medicamentos modificadores da doença (MMDs) disponíveis no SUS:<br>`o` Betainterferonas (IFN-1a e 1b)<br>`o` Acetato de Glatirâmer (AG)<br>`o` Teriflunomida<br>`o` Fumarato de Dimetila (DMF)<br>`o` Fingolimode|
|**O**|**(****_Outcomes_) **<br>**Desfechos**|**Eficácia:**<br>● Taxa anualizada de surtos (definida como o número médio de surtos confirmados por<br>paciente, ajustada pela duração do acompanhamento para anualizá-la);<br>● Proporção de pacientes livres de progressão da incapacidade avaliada pelo EDSS;<br>● Proporção de pacientes sem evidência de atividade da doença (NEDA-3, do inglês_No_<br>_Evidence of Disease Activity_), um desfecho composto que avalia ausência de atividade<br>radiológica, surtos e progressão da incapacidade;|  
54  
|||● Outros desfechos relevantes de eficácia.<br>**Segurança:**<br>● Mortalidade;<br>● Eventos adversos graves;|
|---|---|---|
|||● Leucoencefalopatia Multifocal Progressiva (LEMP).|
|**S**|**(****_Study_) **|Revisões Sistemáticas (RS) com ou sem meta-análise, Ensaios Clínicos Randomizados (ECR)|
||**Tipo de estudo**|de fase III e estudos observacionais.|  
**Quadro B -** Pergunta estruturada utilizada para responder à questão sobre uso de medicamentos modificadores do curso da doença para tratamento da EMRR em gestantes  
|**P**|**População**|Mulheres adultas (≥ 18 anos), grávidas, diagnosticadas com EMRR|
|---|---|---|
|**I**|**Intervenção**|● Medicamentos modificadores da doença (MMDs) disponíveis no SUS, sem contra-<br>indicação em bula para uso por gestantes:<br>`o` Betainterferona (IFN-1b)<br>`o` Glatirâmer (AG)<br>`o` Natalizumabe<br>`o` Fumarato de dimetila (DMF)<br>`o` Fingolimode|
|**C**|**Comparadores**|● MMDs disponíveis no SUS, sem contra-indicação em bula para uso por gestantes;<br>● Não tratar.|
|**O**|**(****_Outcomes_) **<br>**Desfechos**|**Segurança:**<br>● Mortalidade;<br>● Intercorrências no bebê;<br>● Intercorrências na gestante.|
|**S**|**(****_Study_) **<br>**Tipo de estudo**|Revisões Sistemáticas (RS) com ou sem meta-análise, Ensaios Clínicos Randomizados (ECR)<br>de fase III e estudos observacionais.|  
**Quadro C -** Estratégias de busca de evidências nas bases de dados  
|**Bases**||**Estratégia de Busca**|**Artigos Recuperados**|
|---|---|---|---|
|Medline|(via|Search ((((“Multiple Sclerosis”[Mesh] OR “Sclerosis, Multiple” OR|666|
|Pubmed)||“Sclerosis, Disseminated” OR “Disseminated Sclerosis” OR “MS (Multiple||
|||Sclerosis)” OR “Multiple Sclerosis, Acute Fulminating” OR “Multiple||
|||Sclerosis, Relapsing-Remitting”[Mesh] OR “Multiple Sclerosis, Relapsing<br>Remitting” OR “Remitting-Relapsing Multiple Sclerosis” OR “Multiple||
|||Sclerosis, Remitting-Relapsing” OR “Remitting Relapsing Multiple||
|||Sclerosis” OR “Relapsing-Remitting Multiple Sclerosis” OR “Relapsing||
|||Remitting Multiple Sclerosis” OR “Multiple Sclerosis, Acute Relapsing” OR||  
55  
|**Bases**|**Estratégia de Busca**|**Artigos Recuperados**|
|---|---|---|
||“Acute Relapsing Multiple Sclerosis”))) AND ((“Natalizumab”[Mesh] OR<br>“Tysabri” OR “Antegren”))) AND (("Interferon beta-1b"[Mesh] OR “Beta-<br>IFN-1b” OR “Interferon beta 1b” OR “Betaseron” OR “Beta-Seron” OR “Beta<br>Seron” OR “Extavia” OR “Betaferon” OR "Interferon beta-1a"[Mesh] OR<br>“beta-1a, Interferon” OR “Interferon beta 1a” OR “beta 1a, Interferon” OR<br>“Avonex” OR “Rebif” OR “Avonex” OR "Glatiramer Acetate"[Mesh] OR<br>“Acetate, Glatiramer” OR “Copaxone” OR “Glatiramer” OR "Teriflunomide"<br>[Supplementary Concept] OR "Dimethyl Fumarate"[Mesh] OR “Fumarate,<br>Dimethyl” OR “Dimethylfumarate” OR “Tecfidera” OR "Fingolimod<br>Hydrochloride"[Mesh] OR “Hydrochloride, Fingolimod” OR “Fingolimod”<br>OR “Gilenia” OR “Gylenia”))||
|EMBASE|S1 Search for: ab(EMB.EXACT.EXPLODE("multiple sclerosis")) OR<br>(Multiple Sclerosis, Relapsing-Remitting) OR (Multiple Sclerosis, Relapsing<br>Remitting) OR (Remitting-Relapsing Multiple Sclerosis) OR (Multiple<br>Sclerosis, Remitting-Relapsing)<br>S2 Search for: EMB.EXACT.EXPLODE("natalizumab")<br>S3<br>Search<br>for:<br>ab(EMB.EXACT.EXPLODE("glatiramer")<br>OR|1716|
||EMB.EXACT.EXPLODE("recombinant<br>beta<br>interferon")<br>OR||
||EMB.EXACT.EXPLODE("interferon<br>beta<br>serine")<br>OR<br>EMB.EXACT.EXPLODE("teriflunomide")<br>OR<br>EMB.EXACT.EXPLODE("beta<br>interferon")<br>OR<br>EMB.EXACT.EXPLODE("fumaric<br>acid<br>dimethyl<br>ester")<br>OR<br>EMB.EXACT.EXPLODE("fingolimod")<br>OR<br>EMB.EXACT.EXPLODE("beta1a interferon") OR ("disease modifying<br>therapy"))<br>S4 Search for: S3 AND S2 AND S1||
|The Cochrane|#1<br>MeSH descriptor: [Multiple Sclerosis] this term only|23|
|Library|#2<br>MeSH descriptor: [Multiple Sclerosis, Relapsing-Remitting] explode<br>all trees<br>#3<br>#1 OR #2<br>#4<br>MeSH descriptor: [Natalizumab] explode all trees<br>#5<br>MeSH descriptor: [Interferon beta-1a] explode all trees<br>#6<br>MeSH descriptor: [Interferon beta-1b] explode all trees<br>#7<br>MeSH descriptor: [Glatiramer Acetate] explode all trees<br>#8<br>MeSH descriptor: [Dimethyl Fumarate] explode all trees<br>#9<br>MeSH descriptor: [Fingolimod Hydrochloride] explode all trees<br>#10<br>("teriflunomide") (Word variations have been searched)<br>#11<br>#5 OR #6 OR #7 OR #8 OR #9 OR #10<br>#12<br>#3 AND #4 AND #11||  
56  
**Quadro D -** Estratégias de busca de evidências nas bases de dados  
|**Bases**||**Estratégia de Busca**|**Artigos Recuperados**|
|---|---|---|---|
|Medline<br>Pubmed)|(via|Search ((((“Multiple Sclerosis”[Mesh] OR “Sclerosis, Multiple” OR<br>“Sclerosis, Disseminated” OR “Disseminated Sclerosis” OR “MS (Multiple<br>Sclerosis)” OR “Multiple Sclerosis, Acute Fulminating” OR “Multiple<br>Sclerosis, Relapsing-Remitting”[Mesh] OR “Multiple Sclerosis, Relapsing<br>Remitting” OR “Remitting-Relapsing Multiple Sclerosis” OR “Multiple<br>Sclerosis, Remitting-Relapsing” OR “Remitting Relapsing Multiple<br>Sclerosis” OR “Relapsing-Remitting Multiple Sclerosis” OR “Relapsing<br>Remitting Multiple Sclerosis” OR “Multiple Sclerosis, Acute Relapsing” OR<br>“Acute Relapsing Multiple Sclerosis”))) AND (("Pregnancy"[Mesh] OR<br>Pregnancies OR Gestation))) AND (((“Natalizumab”[Mesh] OR “Tysabri”<br>OR “Antegren”)) OR ("Interferon beta-1b"[Mesh] OR “Beta-IFN-1b” OR<br>“Interferon beta 1b” OR “Betaseron” OR “Beta-Seron” OR “Beta Seron” OR<br>“Extavia” OR “Betaferon” OR "Interferon beta-1a"[Mesh] OR “beta-1a,<br>Interferon” OR “Interferon beta 1a” OR “beta 1a, Interferon” OR “Avonex”<br>OR “Rebif” OR “Avonex” OR "Glatiramer Acetate"[Mesh] OR “Acetate,<br>Glatiramer” OR “Copaxone” OR “Glatiramer” OR "Teriflunomide"<br>[Supplementary Concept] OR "Dimethyl Fumarate"[Mesh] OR “Fumarate,<br>Dimethyl” OR “Dimethylfumarate” OR “Tecfidera” OR "Fingolimod<br>Hydrochloride"[Mesh] OR “Hydrochloride, Fingolimod” OR “Fingolimod”<br>OR “Gilenia” OR “Gylenia”))|172|
|EMBASE||#S1 Searched for: ((EMB.EXACT.EXPLODE("multiple sclerosis")) OR<br>(Multiple Sclerosis, Relapsing-Remitting) OR (Multiple Sclerosis, Relapsing<br>Remitting) OR (Remitting-Relapsing Multiple Sclerosis) OR (Multiple<br>Sclerosis, Remitting-Relapsing))|732|
|||#S2<br>Searched<br>for:<br>EMB.EXACT.EXPLODE("natalizumab")<br>OR||
|||(EMB.EXACT.EXPLODE("glatiramer")<br>OR||
|||EMB.EXACT.EXPLODE("recombinant<br>beta<br>interferon")<br>OR||
|||EMB.EXACT.EXPLODE("interferon<br>beta<br>serine")<br>OR||
|||EMB.EXACT.EXPLODE("teriflunomide")<br>OR||
|||EMB.EXACT.EXPLODE("beta<br>interferon")<br>OR||
|||EMB.EXACT.EXPLODE("fumaric<br>acid<br>dimethyl<br>ester")<br>OR<br>EMB.EXACT.EXPLODE("fingolimod")<br>OR||
|||EMB.EXACT.EXPLODE("beta1a interferon") OR ("disease modifying<br>therapy"))<br>#S3 Searched for: EMB.EXACT.EXPLODE("pregnancy")<br>#S4 Searched for: S3 AND S2 AND S1||
|The Cochr|ane|#1<br>MeSH descriptor: [Multiple Sclerosis] this term only|1|  
57  
|**Bases**|**Estrat**|**égia de Busca**|**Artigos Recuperados**|
|---|---|---|---|
|Library|#2<br>all tree|MeSH descriptor: [Multiple Sclerosis, Relapsing-Remitting] explode<br>s||
||#3|#1 OR #2||
||#4|MeSH descriptor: [Natalizumab] explode all trees||
||#5|MeSH descriptor: [Interferon beta-1a] explode all trees||
||#6|MeSH descriptor: [Interferon beta-1b] explode all trees||
||#7|MeSH descriptor: [Glatiramer Acetate] explode all trees||
||#8|MeSH descriptor: [Dimethyl Fumarate] explode all trees||
||#9|MeSH descriptor: [Fingolimod Hydrochloride] explode all trees||
||#10|("teriflunomide") (Word variations have been searched)||
||#11|#4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10||
||#12|MeSH descriptor: [Pregnancy] explode all trees||
||#13|#3 AND #11 AND #12||  
58

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Após a realização da busca nas bases de dados, 2.404 publicações foram recuperadas, 534 tratava-se de duplicatas e 59 foram lidas na íntegra. Dois revisores independentes selecionaram estudos para leitura na íntegra aplicando os critérios de elegibilidade e, nos casos de divergências, um terceiro revisor realizou a avaliação. Dos 59 estudos lidos na íntegra, 12 cumpriram os critérios de elegibilidade e foram incluídos na análise, sendo um estudo de eficácia (revisão sistemática de ensaios clínicos randomizados) e onze de efetividade (estudos observacionais) (Figura A).  
**Figura A -** Fluxograma de seleção dos estudos sobre o uso de natalizumabe para EMRR em alta atividade como primeira linha de tratamento.  
<!-- Start of picture text -->
Referências identificadas em fontes<br>Pai Publicacées identificadas através<br>PS: da pesquisa suplementares:<br>n = 2<br>Pe: n=nas2.402 bases de dade<br>PS:<br>foi Publicagdes<br>Pod duplicatas:aps remocio de<br>ia: n= 1.870<br>Penseeed Publicacées excluidas<br>oon<br>Poi segundoexclusdo:critérios1.811 de<br>igi Publicagdes selecionadas para<br>if: leitura completa:<br>$f:pu: Publicacdes excluidas-<br>poi segundo critérios<br>bod exclusaio: 47 de<br>fog Artigos completos incluidos na<br>tod anilise qualitativa:<br>Poi 2<br>igi:<br>PB:<br>Pe: Artigos completos incluidos na<br>3 : analise quantitativa (meta-analise):<br>H i 11<br><!-- End of picture text -->  
**Para responder à questão sobre uso de medicamentos modificadores do curso da doença para tratamento da EMRR em gestantes**  
A partir da busca na literatura, foram recuperadas 905 publicações, das quais 182 eram duplicatas. Após a seleção por títulos e resumos, 66 estudos passaram por análise do texto na íntegra, dos quais 16 cumpriram os critérios de elegibilidade e foram incluídos na análise. Toda a etapa de seleção foi realizada por dois revisores independentes e, nos casos de divergências, um terceiro revisor foi acionado. Foram excluídos os artigos nos quais as pacientes saíram do estudo no início da gestação e/ou os dados destas pacientes não foram apresentados. Também foram excluídos os estudos em que as pacientes usaram os  
59  
medicamentos apenas no período pré- ou pós-gestacional, ou os que avaliavam apenas desfechos relacionados à eficácia dos medicamentos, pois este não era o objetivo da revisão. ( **Figura B** )  
**Figura B -** Fluxograma de seleção dos estudos sobre o uso de MMCD para tratamento da EMRR em gestantes.  
<!-- Start of picture text -->
igi Publicagées identificadas através da<br>Pg: pesquisa nas bases de dados<br>isi n=905<br>zi<br>Pai<br>isi<br>fol Publicagdes apos remocao de<br>as duplicatas:<br>iB: n=723<br>Bevsed Publicagdes excluidas<br>posses segundo critérios<br>exclus3o: 657<br>pot de<br>ig: Publicacdes selecionadas para<br>isiiz: leitura completa:<br>Pe n= 66<br>isi A<br>pay Publicagdes excluidas<br>Po segundo critérios<br>bcesed exclusdo: 50 de<br>Pd Artigos completos incluidos na<br>Poe andlise qualitativa<br>Si 16<br>Be<br>Pau<br>Pei Artigos completos incluidos na<br>H t analise quantitativa (meta-analise):<br>Lt 10<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
**Uso de natalizumabe para EMRR em alta atividade como primeira linha de tratamento**  
Após busca sistemática na literatura, foram incluídos 12 estudos na análise qualitativa. Uma revisão sistemática avaliou a eficácia do natalizumabe _versus_ fingolimode no tratamento da EMRR de alta atividade, por meio de uma meta-análise em rede de ensaios clínicos randomizados. Além desse estudo, 11 coortes avaliaram a efetividade do natalizumabe em pacientes com EMRR de alta atividade, quando comparado ao fingolimode.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Huisman e colaboradores (2016)<sup>92</sup> realizaram uma revisão sistemática da literatura, seguida de uma metanálise em rede, a fim de avaliar e comparar a eficácia do fingolimode com relação às demais terapias modificadoras da doença, no tratamento das formas _highly-active_ (alta atividade - HA) e _rapidly evolving severe_ (evolução rápida grave - RES) da EMRR.  
60  
No estudo, HA EMRR é definida como taxa de surtos inalterada ou aumentada, ou surtos graves contínuos no último ano, apesar do tratamento com pelo menos um medicamento modificador da doença. Já a RES é definida como dois ou mais surtos no último ano e uma ou mais lesões identificadas na ressonância com gadolínio, ou aumento na carga da lesão em T2, comparada com a ressonância anterior.  
A busca da literatura foi conduzida em 2010, seguindo os critérios do protocolo PRISMA, e atualizada em 2014, nas bases de dados MEDLINE, EMBASE e Cochrane Library. Foram selecionados ensaios clínicos randomizados, que avaliaram desfechos funcionais e resultados de MRI em pacientes adultos com HA EMRR ou RES EMRR tratados com fingolimode, IFN, AG, natalizumabe, teriflunomida, DMF ou alentuzumabe. Os estudos foram selecionados após leitura de título e resumo por dois revisores independentes, e as divergências resolvidas por um terceiro revisor. O mesmo processo foi seguido para leitura e seleção de texto completo. O estudo considerou apenas medicamentos recomendados para reembolso pelo Serviço Nacional de Saúde da Inglaterra (NHS, do inglês _National Health Service_ ), não considerando natalizumabe como comparador para os pacientes com HA EMRR, já que não há tal indicação do NHS.  
A extração dos dados dos estudos foi realizada em formulário próprio, por um revisor e certificado por um segundo revisor, e a qualidade metodológica dos estudos incluídos foi avaliada seguindo o _checklist_ do _National Institute for Health and Care Excellence_ (NICE) adaptada do checklist para ECR do _Centres for Reviews and Dissemination_ (CRD). Para reduzir viés devido à inconsistência entre estudos incluídos na meta-análise em rede, foram considerados apenas estudos com desenho, população e definições de subgrupo semelhantes.  
Os desfechos de eficácia avaliados foram: taxa de surto anualizada (ARR) aos 12 e 24 meses, ARR a qualquer momento relatado, diferença na mudança da pontuação inicial da Escala Expandida do Estado de Incapacidade de Kurtzke (EDSS) em 12 ou 24 meses, diferença na pontuação inicial da EDSS a qualquer momento, e _hazard ratio_ (HR) de progressão da incapacidade confirmada em 3 e 6 meses.  
Foi utilizada uma abordagem bayesiana com intervalos de credibilidade (ICr) para a meta-análise. Para cada desfecho avaliado, foram considerados ambos modelos de efeitos fixos e randômicos, entretanto, os modelos de efeitos fixos foram escolhidos, dado o pequeno número de estudos incluídos. Foram calculadas as probabilidades de cada tratamento específico ser superior a outro − ranqueadas pela mediana com 95% ICr − a probabilidade P-best e a medida SUCRA.  
Foram retornados 4.715 artigos pela estratégia de busca, excluídas as duplicatas. Destes, 8 artigos que reportaram resultados por grupo de pacientes com HA (n=5) e/ou RES (n=4) foram identificados, sendo todos análises post hoc de subgrupos de ensaios clínicos randomizados, multicêntricos, duplo-cegos, de fase três. Dados para análise de eficácia do natalizumabe, fingolimode e DMF foram extraídos dos ECR AFFIRM, FREEDOMS/FREEDOMS II e DEFINE/CONFIRM, respectivamente. Para avaliação dos pacientes com HA, o fingolimode pôde ser comparado ao dimetil-fumarato utilizando o placebo como comparador comum, enquanto para o grupo RES, o fingolimode pôde ser comparado ao natalizumabe, utilizando também dados de placebo como comparador comum. O risco de viés para as análises de subgrupo foi incerto.  
O resultado da metanálise em rede mostrou que, para o subgrupo de pacientes com a forma RES da doença, não houve diferença estatisticamente significante na taxa anualizada de surto aos 24 meses entre fingolimode (0,5 mg, MID) e natalizumabe (300 mg BID) (HR 1,72; 95% ICr 0,84 - 3,53). O valor SUCRA (%) para o desfecho de TAS aos 24 meses foi de 96,5 (posição no rank; 95% ICr 1 - 2) e 53,4 (posição no rank; 95% ICr 1 - 2) para natalizumabe e fingolimode, respectivamente, e de 89,0 (posição no rank 1; 95% ICr 1 - 2) para natalizumabe e 46,1 (posição no rank 2; 95% ICr 1 - 3) para fingolimode, no desfecho de 3 meses de progressão da incapacidade aos 24 meses.  
61

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A avaliação da qualidade metodológica da revisão sistemática foi realizada com a ferramenta AMSTAR 2. O instrumento é composto por sete domínios que abrangem 16 itens que devem ser respondidos como “sim”, que corresponde a um resultado positivo, “sim parcialmente”, “não” e “não se aplica”. Destes, sete domínios são considerados críticos na avaliação, sendo estes: o registro de protocolo (item 2), a adequação da busca na literatura (item 4), a justificativa para a exclusão de estudos individuais (item 7), a avaliação do risco de viés (item 9), a adequação da meta-análise (item 11), a consideração do risco de viés na interpretação dos resultados (item 13) e a avaliação da presença e do impacto do risco de viés (item 15). A confiança nos resultados da revisão avaliada pode ser categorizada em alta quando nenhuma ou apenas uma fraqueza não crítica está presente, moderada quando há mais de uma fraqueza não crítica, baixa quando o estudo apresenta uma falha crítica, e criticamente baixa quando mais de uma falha crítica pode ser identificada<sup>93</sup> . A avaliação da RS seguida de meta-análise de Huisman e colaboradores (2016), segundo o AMSTAR-2, está sintetizada no **Quadro E** , e a confiança no resultado do estudo foi classificada como criticamente baixa, já que os itens 2, 7 e 15 (considerados críticos) apresentaram falhas.  
**Quadro E -** Parâmetros para avaliação da qualidade da revisão sistemática incluída, segundo AMSTAR 2  
|**Item**|**Atendido?**|
|---|---|
|1. A pergunta de pesquisa e os critérios de inclusão abrange os componentes do PICO?|Sim|
|2. O relato da revisão contém uma declaração explícita de que os métodos foram estabelecidos antes da<br>sua realização e uma justificativa para qualquer desvio do protocolo?|Não|
|3. Os autores explicaram a seleção dos desenhos do estudo para inclusão na revisão?|Sim|
|4. Os autores utilizaram uma estratégia de busca abrangente?|Sim|
|5. Os autores realizaram a seleção dos estudos de forma duplicada?|Sim|
|6. Os autores realizaram a extração de dados de forma duplicada?|Sim|
|7. Os autores forneceram uma lista de estudos excluídos e justificaram as exclusões?|Não|
|8. Os autores descreveram os estudos incluídos com detalhamento adequado?|Sim|
|9. Os autores utilizaram uma técnica satisfatória para avaliar o risco de viés nos estudos individuais que<br>foram incluídos na revisão?|Sim,<br>parcialmente|
|10. Os autores relataram as fontes de financiamento para os estudos incluídos na revisão?|Não|
|11. Se a meta-análise foi justificada, os autores da revisão utilizaram métodos apropriados para a<br>combinação estatística de resultados?|Sim|
|12. Se a meta-análise foi realizada, os autores avaliaram o impacto potencial do risco de viés nos estudos<br>individuais sobre os resultados da meta-análise ou outra síntese de evidências?|Não|  
62  
|**Item**|**Atendido?**|
|---|---|
|13. Os autores levaram em consideração o risco de viés dos estudos individuais ao interpretar/ discutir os<br>resultados da revisão?|Sim|
|14. Os autores forneceram uma explicação e uma discussão satisfatória para qualquer heterogeneidade<br>observada nos resultados da revisão?|Não|
|15. Se realizaram síntese quantitativa, os autores fizeram uma investigação adequada do viés de publicação<br>(pequeno viés de estudo) e discutiram seu provável impacto nos resultados da revisão?|Não|
|16. Os autores relataram quaisquer fontes potenciais de conflito de interesses, incluindo qualquer<br>financiamento recebido para a realização da revisão?|Sim|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Foram incluídos na RS e meta-análise 11 estudos de vida real, comparando natalizumabe e fingolimode para tratamento de pacientes com EMRR de alta atividade. As características gerais dos estudos incluídos estão sumarizadas no **Quadro F** . A partir dos resultados extraídos desses estudos, foram realizadas meta-análises para os desfechos de efetividade e segurança com dados quantitativos disponíveis (seção 2.3.1.2.1).  
63  
**Quadro F -** Quadro de sumarização das características dos estudos observacionais incluídos  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|**Barbin et al., 2016**<sup>94</sup>|Estudo observacional retrospectivo|**Desfecho primário de efetividade**:|BAIXA|
||conduzido<br>em<br>27<br>hospitais|- Proporção de pacientes com||
|Participantes:|universitários na França, a partir da|pelo menos uma recidiva no||
|Total: 629|base de dados_European Database_|primeiro ano de tratamento.||
|Natalizumabe: 326|_for Multiple Sclerosis Software_.|**Desfechos secundários:**||
|Fingolimode: 303|Critérios de elegibilidade definidos:|- Proporção de pacientes com<br>pelo menos uma recaída aos 2|<br>|
|**Características dos pacientes na**|<br>- Idade entre 18 e 65 anos;|anos de tratamento;||
|**linha de base:**|- Pontuação na escala (EDSS)|- Proporção de pacientes com||
|EDSS médio (DP): 2,6 (1,3)|variando entre 0 e 5,5,|progressão<br>da<br>incapacidade||
|Surtos no ano anterior – n (%):<br>- ≥ 1: 526 (83,6%)<br>- ≥ 2: 311 (49,4%)|- Início de uso do natalizumabe<br>ou fingolimode entre 1 de<br>janeiro de 2011 e 1 de janeiro de<br>2013<br>- Ter ressonância magnética e<br>avaliação do EDSS no ano<br>anterior ao início do tratamento<br>disponível;<br>Pacientes com histórico de uso<br>prévio<br>de<br>medicamentos<br>modificadores do curso da doença<br>não foram incluídos.|definida por qualquer aumento<br>na pontuação do EDSS aos 12 e<br>24 meses (mais ou menos 3<br>meses) em comparação com a<br>linha de base;<br>- Proporção de pacientes com<br>pelo<br>menos<br>uma<br>lesão<br>aumentada do gadolínio em<br>comparação com a ressonância<br>magnética na linha de base;<br>- Proporção de pacientes com<br>pelo menos uma nova lesão T2<br>em<br>ressonância<br>magnética<br>realizada aos 12 e 24 meses<br>(mais ou menos 3 meses) em<br>comparação com a ressonância<br>magnética na linha de base.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|
|**Baroncini et al., 2016**<sup>95</sup>|Estudo observacional prospectivo<br>conduzido em dois centros italianos|**Desfechos primários**<br>●<br>Tempo da primeira recaída; e|BOA|
|266 participantes inicialmente -|<br>de esclerose múltipla.|●<br>Taxa de recaída anualizada||
|Coorte não ajustada|102 pacientes em cada braço depois|(ARR) após 12 e 24 meses.||
|Natalizumabe: 126|de um ajustamento por escores de|**Desfechos Secundários**||
|Fingolimode: 140|propensão.|-<br>Pontuação no EDSS aos 12 e<br>24 meses;||
|204 participantes - Coorte ajustada|Pacientes<br>com<br>EMRR<br>que|-<br>Tempo para agravamento da||
|Natalizumabe: 102|iniciaram<br>fingolimode<br>ou|incapacidade - definido como||
|Fingolimode: 102|natalizumabe devido à falha no uso<br>de agentes injetáveis de primeira|aumento da pontuação no<br>EDSS de ≥ 1 ponto (≥ 1,5|<br>|  
64  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
||linha<br>(IFNs<br>ou<br>AG)<br>com<br>seguimento de 24 meses.<br>-<br>Os critérios de exclusão foram|pontos se o EDSS da linha de<br>base = 0 e ≥ 0,5 pontos se o<br>EDSS linha base = 5,5)<br>confirmada após 6 meses;|<br> <br>|
||idade < 18 anos,|-<br>Tempo para melhoria da||
||-<br>Tratamento<br>com|incapacidade - definido como||
||imunossupressores no ano|uma diminuição do escore||
||anterior,|EDSS de ≥ 1 ponto nos||
||-<br>EM<br>primariamente|pacientes com EDSS basal ≥||
||progressiva|1.5, confirmada após 6 meses;||
||-<br>Tratamento<br>prévio<br>com|-<br>Percentual de pacientes com||
||fingolimode ou natalizumabe.|atividade<br>cerebral||
|||comprovada<br>por<br>RM<br>(ressonância magnética)         -<br>definida como a presença de ≥<br>1 nova/crescente Lesão T2 em<br>relação à RM cerebral anterior<br>e/ou a presença de ≥ 1 lesão<br>marcada<br>por<br>gadolínio<br>(gadolínio +) - aos 12 e 24<br>meses;<br>-<br>Tempo<br>para<br>a<br>primeira<br>evidência de atividade da|<br> <br> <br> <br> <br> <br> <br> <br> <br>|
|||doença<br>de<br>acordo<br>com<br>nenhuma<br>evidência<br>de|<br>|
|||atividade da doença (NEDA-||
|||3:<br>sem<br>recidivas,<br>sem||
|||atividade<br>de<br>ressonância||
|||magnética cerebral e nenhuma||
|||piora<br>da<br>deficiência<br>previamente definida)||  
65  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|**Curti et al., 2019**<sup>96</sup>|Estudo<br>observacional,|**Desfechos primários**|BOA|
||retrospectivo,<br>multicêntrico,|●<br>Taxa de recaída anualizada||
|281 pacientes (157 natalizumabe;|envolvendo três centros de EM no|(ARR) após 12 e 24 meses.||
|124<br>fingolimode).<br>Após<br>a|norte da Itália (Parma - PA, Modena|●<br>Tempo da primeira recaída.||
|correspondência<br>do<br>escore<br>de|- MO e Ferrara - FE), aprovados|||
|propensão, os grupos da coorte|pelos comitês de ética locais.|**Desfechos secundários**||
|ajustada apresentam 102 pacientes||●<br>Proporção de pacientes com||
|para natalizumabe e 102 para|Incluídos<br>pacientes<br>com<br>EM|≥1 recaída após 12 e 24||
|fingolimode.|remitente-recorrente<br>(RR)<br>de|meses.||
||acordo com o critério de McDonald|●<br>Proporção de pacientes com||
|**Características dos indivíduos na**|(2005-2010) que foram tratados|progressão da doença após||
|**linha de base:**|com pelo menos uma dose de|12 e 24 meses, confirmados||
|Natalizumabe: 102 participantes|natalizumabe ou fingolimode, de|após 6 meses (definido como||
|Tempo de tratamento - média (DP):|acordo<br>com<br>os<br>critérios<br>de|EDSS aumentado ≥1 ponto||
|36,3 (8,59)|elegibilidade de doença altamente|se o escore EDSS basal for||
|Sexo (%F): 70,6|ativa fornecidos pela Agência|<5,5 ou ≥0,5 ponto se o||
|Centro<br>de<br>Tratamento|Europeia de Medicamentos (EMA).|EDSS basal pontuação ≥5,5,||
|(PA/MO/FE/%): (32,3/27,5/40,2)|Foram excluídos pacientes com|sem recidivas).||
|Lesões de gadolínio de baseline|dados incompletos.|●<br>Proporção de pacientes com||
|(%): 22,5||regressão da doença após 12||
|Critério de alta atividade (%): 81,4||e 24 meses, confirmados||
|Números de surtos no ano anterior -||após 6 meses (definido como||
|média (DP): 1,35 (0,93)||diminuição de ≥1 EDSS||
|EDSS de base - média (DP): 3,1||ponto se o escore EDSS||
|(1,35)||basal for <5,5 ou ≥0,5 ponto||
|Duração da doença - média (DP):||se o EDSS basal for ≥5,5,||
|91,5 (90,1)||sem recidivas).<br>●<br>Número médio de lesões T2||
|Fingolimode: 102 participantes||/ gadolínio novas / ampliadas||
|Tempo de tratamento - média (DP):||no seguimento da RM após||
|38,2 (9,06)||12 e 24 meses.||
|Sexo (%F): 70,6||●<br>Proporção de pacientes com||
|Centro<br>de<br>Tratamento||≥1 lesão T2 e gadolínio||
|(PA/MO/FE/%): (34,3/28,4/37,3)||nova/aumentada na RM após||
|Lesões de gadolínio de baseline||12 e 24 meses (Atividade||
|(%): 22,5||Única Combinada, CUA).||
|Critério de alta atividade (%): 90,2||●<br>Proporção de pacientes com||
|Números de surtos no ano anterior -||“Nenhuma<br>evidência<br>de||
|média (DP): 1,23 (0,91)||atividade<br>da<br>doença”||  
66  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|EDSS de base - média (DP): 3,2<br>(1,58)<br>Duração da doença - média (DP):<br>115,9 (81,33)||(NEDA-3), definida como<br>ausência<br>de<br>recidivas<br>clínicas, CUA e doenças<br>confirmadas progressão da<br>capacidade (CDP) após 12 e<br>24 meses de terapia.|<br> <br> <br> <br>|
|**Gajofatto et al., 2014**<sup>97</sup><br>57<br>indivíduos<br>que<br>receberam<br>natalizumabe e 30 que receberam<br>fingolimode por um período médio<br>de 23 (1 a 63) e 22 (2 a 35) meses,<br>respectivamente foram incluídos.<br>**Características dos indivíduos na**<br>**linha de base:**<br>Natalizumabe: 57 participantes<br>Idade, anos - média (DP): 38,0 (9,3)<br>Duração da doença - mediana: 8,4<br>(0,5-35,1)<br>Sexo (%F): 75,4<br>Surtos no ano anterior - mediana: 2<br>(0-4)<br>EDSS de base - mediana: 3 (2-8)<br>Lesões de gadolínio (%): Presente<br>40,4<br>Ausente 59,6<br>Tratamento<br>prévio<br>(%):<br>0<br>medicamento 8,8 / 1 medicamento|<br>Estudo observacional retrospectivo,<br>com base em dados clínicos e de<br>ressonância magnética coletados<br>prospectivamente.<br>Pacientes com EMRR tratados com<br>natalizumabe ou fingolimode no<br>Hospital Verona, Itália.|**Desfechos de efetividade**:<br>●<br>Tempo para recidiva;<br>●<br>Taxa de recidiva;<br>●<br>Mudança no escore da escala<br>EDSS;<br>●<br>Novas lesões que aumentam<br>T2/gadolínio na RM.|<br> <br>BAIXA|  
67  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|52,6 / igual ou mais de 2<br>medicamentos 38,6<br>Tratamento no ano prévio (%): Sim<br>91,2 / Não 8,8||||
|Fingolimode: 30 participantes<br>Idade, anos - média (DP): 39,0 (7,8)||||
|Duração da doença - mediana: 11,1<br>(1,1-30,2)<br>Sexo (%F): 70,0<br>Surtos no ano anterior - mediana: 1||||
|(0-2)||||
|EDSS de base - mediana: 2.5 (0-||||
|5,5)||||
|Lesões de gadolínio (%): Presente<br>26,7<br>Ausente 73,3||||
|Tratamento<br>prévio<br>(%):<br>0||||
|medicamento 3,3 / 1 medicamento<br>66,6 / igual ou mais de 2<br>medicamentos 30,1<br>Tratamento no ano prévio (%): Sim<br>96,7 / Não 3,3||||
|**Koch-Henriksen et al., 2017**<sup>98</sup>|Estudo observacional prospectivo,<br>conduzido a nível nacional na|**Desfechos de efetividade**:<br>- Taxa<br>anualizada<br>de<br>surtos|<br>BOA|
|Tempo médio de acompanhamento:|Dinamarca.|(ARR);||
|1,8 anos|**Critério de elegibilidade:**|- Incidência de surtos (sintomas<br>neurológicos<br>novos<br>ou|<br>|
|Participantes (após pareamento):|- Pacientes<br>que<br>iniciaram<br>o|agravantes, que ocorrem em dias||
|Natalizumabe: 464|tratamento com natalizumabe ou|ou semanas, com duração de||
|Fingolimode: 464|fingolimode entre 1 de julho de<br>2011 e 31 de março de 2015.|pelo menos 24 horas na ausência<br>de febre);||
|**Características dos indivíduos na**||- Taxas de surtos tratados com||
|**linha de base:**|Os pacientes dos dois grupos de|esteroides;||
|Taxa de surto antes do tratamento|tratamento foram pareados por|- Proporção de pacientes livres de||
|(média ± DP):|_Propensity_<br>_Score_<br>_Matching_,|surtos;||
|Natalizumabe: 1,06 ± 0,95|comparando as variáveis da linha de|- Tempo até o primeiro surto;||
|Fingolimode: 1,05 ± 1,10|base que provaram ser preditores<br>das taxas de surto e da escolha do|||  
68  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Escore do EDSS (média ± DP):<br>Natalizumabe: 3,15 ± 1,60<br>Fingolimode: 3,08 ± 1,50|medicamento de segunda linha com<br>um valor-p < 0,10.|- Proporção de pacientes com<br>piora ou melhora do EDSS e<br>relação à linha de base.|<br>|
|**Preziosa et al., 2019** <sup>99</sup>|Estudo prospectivo, longitudinal,<br>aberto<br>e<br>não<br>randomizado,|**Desfechos de efetividade**:<br>- Alterações no EDSS e MFSC;|BOA|
|Tempo de seguimento: 24 meses<br>Participantes-n (%):|conduzido em um único centro.<br>Critérios de inclusão:|- Incidência de surto;<br>- Taxa Anualizada de Surto;||
|Natalizumabe: 30 (54,5)|- pacientes com EMRR, falhados|- NEDA-3<br>(No<br>Evidence<br>of||
|Fingolimode: 25 (45,5)|ao tratamento de primeira linha,<br>iniciando<br>tratamento<br>com|Disease Activity);<br>- Desempenho cognitivo;||
|**Características dos indivíduos na**<br>**linha de base:**|natalizumabe ou fingolimode<br>- idade entre 18 e 65 anos;|- Fadiga;<br>- Depressão;||
|AAR no ano anterior (média ± DP):<br>Natalizumabe: 1,20 ± 0,81|- EDSS < 6,0.<br>Critérios de exclusão:|- Alterações radiológicas.||
|Fingolimode: 1,00 ± 0,82<br>AAR nos 2 anos anteriores (média<br>± DP):|- tratamento sintomático estável<br>por menos de 3 meses;<br>- contraindicação à realização de<br>ressonância magnética;|||
|Natalizumabe: 0,82 ± 0,55<br>Fingolimode: 0,88 ± 0,60<br>EDSS (média ± DP):<br>Natalizumabe: 2,36 ± 1,26<br>Fingolimode: 2,63 ± 1,46|- presença<br>de<br>outras<br>comorbidades;<br>- histórico de abuso de drogas ou<br>álcool;<br>- gravidez ou lactação.|||
|Lesões hiperintensas em T2 (média<br>± DP):<br>Natalizumabe: 9,40 ± 11,40<br>Fingolimode: 9,20 ± 8,90||||
|Pacientes com lesões pelo gadolínio<br>(n | %):<br>Natalizumabe: 8 | 27%<br>Fingolimode: 4 | 16%||||
|**Prosperini et al., 2017**<sup>100</sup>|Estudo observacional, retrospectivo<br>e multicêntrico, da fase pós-|**Desfechos de efetividade**:<br>- NEDA-3<br>(do<br>inglês,<br>_No_|<br>BOA|
|n = 783 participantes|comercialização dos medicamentos|_Evidence of Disease Activity_,||
|Tempo de seguimento: 24 meses|fingolimode e natalizumabe.|definida como ausência de||  
69  
|**ESTUDO**|**DELINEAMENTO**<br>|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
||Os participantes incluídos foram|surtos, piora da incapacidade e||
|**Características dos indivíduos na**|divididos em dois grupos:|atividade radiológica);||
|**linha de base:**|**1. GRUPO**<br>**A**<br>(não|- Tempo até o surto (surto||
|**GRUPO A**|respondedores): pacientes com|definido como qualquer novo||
|Natalizumabe: 215 (37,9%)|EMRR que apresentaram ≥ 2|sintoma<br>neurológico,<br>não||
|Fingolimode: 202 (35,6%)|recaídas, ou 1 recaída associada|associado a outras causas, com||
|GA ou IFN-B: 150 (26,5%)|a um escore residual de EDSS>|duração de pelo menos 24 horas||
|Após pareamento, todos os grupos|2,0 no ano anterior ao estudo,|e acompanhado por novos sinais||
|ficaram com 110 participantes|enquanto em uso de GA ou|neurológicos);||
|Escore EDSS (média ± DP):|IFNB e, portanto, iniciaram|- Piora da incapacidade (definida||
|Natalizumabe<br>não-pareados|tratamento com NTZ ou FNG.|como aumento de ≥ 1,5 pontos||
|(pareados): 2,6 ± 1,2 (2,7 ± 1,1)|Pacientes com exposição prévia|se EDSS basal = 0, aumento de||
|Fingolimode<br>não-pareados|a<br>DMDs<br>não<br>foram|≥ 1,0 pontos se EDSS basal <||
|(pareados): 2,7 ± 1,3 (2,6 ± 1,1)|considerados para este estudo.|5,5) ou aumento de ≥ 0,5 pontos||
|GA<br>ou<br>IFNB<br>não-pareados|**2. GRUPO B** (pacientes com alta|se o EDSS basal era ≥ 5,5||
|(pareados): 2,5 ± 1,2 (2,7 ± 1,3)|atividade<br>e<br>virgens<br>de|confirmado com 6 meses de||
|Número de surtos no ano anterior|tratamento):<br>pacientes<br>com|intervalo);||
|(média ± DP):|EMRR que nunca haviam sido|- Melhora<br>da<br>incapacidade||
|Natalizumabe<br>não-pareados|tratados com outro DMD e|(definida como uma diminuição||
|(pareados): 1,7 ± 0,7 (1,4 ± 0,5)|tiveram ≥ 2 surtos no ano|sustentada de ≥ 1 ponto no||
|Fingolimode<br>não-pareados|anterior e ≥ 1 lesão que|EDSS,  confirmada no final do||
|(pareados): 1,4 ± 0,8 (1,4 ± 0,6)|aumentada pelo gadolínio na|seguimento de 24 meses);||
|GA<br>ou<br>IFNB<br>não-pareados|ressonância magnética. Esses|- Atividade radiológica (definida||
|(pareados): 1,3 ± 0,5 (1,4 ± 0,5)|pacientes foram submetidos ao|como a ocorrência de ≥ 1 lesão||
|Lesão pelo gadolíneo (n|%):|início do natalizumabe ou FNG|aumentada pelo gadolínio, ou ≥||
|Natalizumabe<br>não-pareados|como<br>primeiro<br>tratamento.|1 nova lesão hiperintensa em||
|(pareados): 142 | 66% (67 | 60,9%)|Também incluímos um grupo de|T2).||
|Fingolimode<br>não-pareados|pacientes que atenderam ao|||
|(pareados): 105 | 52% (66 | 60%)|mesmo critério, mas iniciaram|||
|GA<br>ou<br>IFNB<br>não-pareados|IFNB-1b ou GA (INJ) em altas|||
|(pareados): 93 | 62% (69 | 62,7%)|doses devido à preferência do|||
|**GRUPO B**|paciente ou à indisponibilidade|||
|Natalizumabe: 60 (27,8%)|de uma DMD alternativa.|||
|Fingolimode: 63 (29,2%)||||
|GA ou IFN-B: 93 (43,0%)||||
|Após pareamento, todos os grupos||||
|ficaram com 40 participantes||||
|Escore EDSS (média ± DP):||||  
70  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Natalizumabe<br>não-pareados<br>(pareados): 2,8 ± 1,4 (2,1 ± 0,8)<br>Fingolimode<br>não-pareados||||
|(pareados): 2,5 ± 1,1 (2,1 ± 0,9)<br>GA<br>ou<br>IFNB<br>não-pareados<br>(pareados): 1,8 ± 0,8 (2,1 ± 0,9)<br>Número de surtos no ano anterior<br>(média ± DP):<br>Natalizumabe<br>não-pareados<br>(pareados): 2,1 ± 0,8 (2,1 ± 0,7)||||
|Fingolimode<br>não-pareados||||
|(pareados): 2,0 ± 0,7 (2,1 ± 0,6)||||
|GA<br>ou<br>IFNB<br>não-pareados<br>(pareados): 2,1 ± 0,5 (2,2 ± 0,6)||||
|**Totaro et al., 2015**<sup>101</sup>|Estudo longitudinal, prospectivo e<br>observacional,<br>conduzido<br>em|- % de pacientes livres<br>de<br>atividade da doença;|<br>BAIXA|
|391 participantes|quatro centros.<br>Critérios de elegibilidade:|- % de pacientes livres<br>de<br>evolução em pelo menos 1.0 no|<br>|
|**Características dos indivíduos na**||EDSS;||
|**linha de base:**|1.GRUPO A(Natalizumabe)|- % de pacientes livres de novas||
|Natalizumabe: 197|- Pacientes que já faziam uso de|lesões T2 ou aumentadas pelo||
|Fingolimode: 194|imunomoduladores<br>há<br>pelo<br>menos 12 meses e: tiveram dois|gadolínio;<br>- Variações na ARR.||
|EDSS no ano precedente ao|surtos no último ano ou um|||
|tratamento:|surto<br>com<br>recuperação|||
|Natalizumabe: 2,3`土`0,95|incompleta e disfunção residual|||
|Fingolimode: 2,5`土`1,14|(EDSS ≥ 2.0); com no mínimo 9<br>lesões T2 (RM), ou aumento na|||
|ARR<br>no<br>ano<br>precedente<br>ao|carga de uma lesão, ou pelo|||
|tratamento:|menos uma lesão aumentada|||
|Natalizumabe: 1,9`土`0,72|pelo<br>gadolínio.|||
|Fingolimode: 1,1`土`0,74|Ou<br>- Pacientes com EM grave em|||
|Pacientes com atividade à imagem|rápida evolução, mesmo que<br>|||
|de RM:|não tratados previamente com<br>imunomoduladores e: com ≥ 2|||
|Natalizumabe: 96,4%|<br> <br> <br>|||
|Fingolimode: 707%|surtos<br>com<br>aumento<br>de|||
|,|disfunção no último ano (EDSS<br>≥ 2.0); e com novas lesões T2 ou|||  
71  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
||aumentadas pelo gadolínio nos<br>últimos 12 meses.<br>2.GRUPO B(Fingolimode):<br>- Pacientes que já faziam uso de<br>imunomoduladores<br>há<br>pelo<br>menos 12 meses e: tiveram pelo<br>menos um surto no último ano;<br>e com no mínimo 9 lesões T2<br>(RM), ou aumento na carga de<br>uma lesão, ou pelo menos uma<br>lesão aumentada pelo gadolínio.<br>Ou<br>- Pacientes com EM grave em<br>rápida evolução, mesmo que<br>não tratados previamente com<br>imunomoduladores e: com ≥ 2<br>surtos<br>com<br>aumento<br>de<br>disfunção no último ano; e com<br>novas lesões T2 ou aumentadas<br>pelo gadolínio nos últimos 12<br>meses.|||
|**Frisell et al., 2015** <sup>102</sup>|Estudo observacional, longitudinal<br>prospectivo, com apresentação dos|- Descontinuação do tratamento;<br>- Motivo da descontinuação do|<br>BOA|
|1516 participantes|resultados para os primeiros 12|tratamento.||
|Natalizumabe: 640<br>Fingolimode: 876|meses de tratamento.<br>Foram<br>incluídos<br>todos<br>os|||
|**Características dos indivíduos na**|<br>participantes de um outro estudo|||
|**linha de base:**<br>Média do EDSS:|(MS Epidemiology Study) que<br>iniciaram<br>tratamento<br>com|||
|Natalizumabe (SD): 2,4 (1,7)|natalizumabe ou fingolimode entre|||
|Fingolimode (SD):2,5 (1,7)|1 de agosto de 2011 até 31 de<br>outubro de 2013.<br>Os dados dos pacientes foram<br>coletados<br>no<br>baseline<br>e<br>em<br>intervalos de seis meses.|||  
72  
|**ESTUDO**|**DELINEAMENTO**<br>|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|**Braune et al., 2013** <sup>103</sup>|Estudo longitudinal observacional e|- Taxa de surto no primeiro ano|<br>BOA|
||prospectivo, com 24 meses de|de tratamento;||
|427 participantes|acompanhamento. Foram incluídos|- Piora na escala EDSS (1 ponto||
|Natalizumabe: 237|pacientes alemães que faziam parte|se linha de base menor que 5,5;||
|Fingolimode: 190|da rede NeuroTransConcept.|ou 0,5 ponto se linha de base<br>igual ou superior a 5,5).||
|**Características dos indivíduos na**|Os dados foram coletados nas|||
|**linha de base:**|consultas clínicas, que aconteciam|||
|Média do EDSS:|com frequência trimestral.|||
|Natalizumabe: 3,3`土`1,8||||
|Fingolimode: 2,3`土`1,6||||
|Média anual de surtos:||||
|Natalizumabe: 0,42`土`0,84||||
|Fingolimode: 0,34`土`0,69||||
|**Kalincik et al., 2015**<sup>104</sup>|Estudo observacional longitudinal<br>prospectivo. Foi multicêntrico (ao|- Taxa anual de surto;<br>- Proporção de indivíduos livres|<br>BOA|
|792 participantes, dos quais 578|todo, 66 centros especializados em|de surtos;||
|foram pareados.|EM).|- Proporção de pacientes livres de<br>progressão da doença;||
|Natalizumabe<br>não-pareados|Critérios de inclusão:|- Descontinuação do tratamento.||
|(pareados): 560 (407)|Foram selecionados indivíduos com|||
|Fingolimode<br>não-pareados|EM<br>remitente-recorrente<br>que|||
|(pareados): 232 (171)|abandonaram o tratamento com<br>interferon-beta ou AG (devido à|||
|Média anual de surtos no baseline:|presença de surtos ou progressão da|||
|Natalizumabe<br>não-pareados|doença nos últimos seis meses) e|||
|(pareados): 1.68`土`1.09 (1.53`土`|migraram para fingolimode ou|||
|1.04)|natalizumabe, desde que o intervalo|||
|Fingolimode<br>não-pareados|entre os medicamentos tenha sido|||
|(pareados): 1.20`土`0.85 (1.29`土`|inferior a 3 meses.|||
|0.86)|Critérios de exclusão:<br>Indivíduos que participaram de<br>ensaios clínicos envolvendo o uso<br>de<br>teriflunomida,<br>DMF,|||
||fingolimode,<br>cladribina,<br>mitoxantrona ou natalizumabe.|||  
73

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho taxa anualizada de surtos, foi realizada uma meta-análise comparando a efetividade do natalizumabe _versus_ fingolimode após um período de tratamento de 12 meses. Nessa meta-análise foram incluídos quatro estudos<sup>96–99</sup> , totalizando 1267 participantes. A ARR representa a incidência média de surtos ajustada por ano. Dessa forma, a intervenção favorecida é aquela que apresenta a menor taxa, ou seja, menor incidência de surto. Na comparação entre natalizumabe e fingolimode, não foi observada diferença estatisticamente significante entre os dois grupos após 12 meses de tratamento, com uma diferença média (DM) de surtos de -0,13 [(IC95%: - 0,26 – 0,00) I²= 65%; p = 0,05]. A alta heterogeneidade identificada ocorre em função do estudo Koch-Henriksen et al. (2017)<sup>98</sup> , que apresenta diferente sentido do efeito, com alto peso na metaanálise, em função do estreito intervalo de confiança. Retirando esse estudo, a heterogeneidade é anulada [DM = -0,20 (IC95%: -0,32 – -0,09) I²= 0%; p = 0,0006] e o resultado torna-se significativo estatisticamente, favorecendo o natalizumabe (Figura C).  
**Figura C -** _Forest-plot_ da meta-análise direta do desfecho de taxa anualizada de surto em 12 meses  
<!-- Start of picture text -->
‘Study or Subgroup MeanNatalizumabeSD Total MeanFingotimodeSD Total Weight IV,MeanRandom, Difference95% Cl IV,MeanRandom, Difference95% Cl<br>01 02185 52 03 05158 28 208% -020¢0.40,-0.00]<br>CURTIETALGAJOFATTOKOCH-HENRIKSENETAL ET 2019  AL 2014 028 08 102 047 096 102 189% -0.19¢-0.41, 0.03}<br>PREZIOSAETAL 2018 2017 0.296003 0.39460.18 46430 03070.24 04058O44 48825 378%224% -0.2110.39,-0.03}0.01 [-006,0.04) —_——<br>Total (95% Cl) 648 619 100.0%  -0.13)-0.26, 0.00]<br>Heterogeneity: Tau*= 0.01; Chi"= 8.74, df= 3 (P= 0.03),P= 66%<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
A taxa anualizada de surtos após 24 meses de tratamento também foi meta-analisada. Contudo, só foram incluídos dois estudos<sup>96,99</sup> que avaliaram este desfecho, chegando a uma população total de 259 indivíduos. Igualmente ao que havia sido demonstrado no primeiro ano de tratamento, não foi observada diferença estatisticamente significante entre os grupos de pacientes tratados com natalizumabe ou fingolimode [DM = -0,02 (IC95%: -0,20 – 0,17), p = 0,86]. Nesta meta-análise, entretanto, os estudos apontaram efeitos em direções opostas, o que conferiu maior heterogeneidade ao resultado encontrado (I² = 75%) (Figura D).  
**Figura D -** _Forest-plot_ da meta-análise direta do desfecho de taxa anualizada de surto em 24 meses  
<!-- Start of picture text -->
Natalizumabe —_Fingolimode Mean Difference Mean Difference<br>‘Study<br>or Subgroup _Mean__SD Total Mean SD _Total_Weight_IV, Random,95% CI 1, Random,<br>028 071 102 019 O44 102 436%  0.09(-0.07,0.25)<br>CURTIET AL 2019 95% Cl<br>PREZIOSAETAL<br>2019 0.02 0.09 30 012 0.22 25 56.4% -0.100.19,-0.01]<br>Total (95% Cl) 132 127 100.0%  -0.02{-0.20, 0.17]<br>Heterogeneity: Tau= 0.01; Ch?= 3.99, df= 1 (P = 0.08); P= 75% 5 ots + ng 7<br>Test or overall effect 2= 0.18 (P = 0.86) Favours [natalizumabe] Favours ffngolimode}<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O desfecho ausência de surto após seis meses de tratamento foi analisado, sendo incluídos dois estudos<sup>99,104</sup> que contaram com 633 participantes. A meta-análise apontou que os pacientes que foram tratados com natalizumabe apresentaram menor chance de ocorrência de surtos do que aqueles que receberam fingolimode [Odds Ratio (OR) = 2,85 (IC95%: 1,19 – 6,81) I² = 13%, p = 0,02]. Apesar do amplo intervalo de confiança encontrado em Preziosa et al., houve significância estatística no resultado final desta meta-análise (Figura E).  
74  
**Figura E -** _Forest-plot_ da meta-análise direta do desfecho de ausência de surto em seis meses  
<!-- Start of picture text -->
KALINCIKStudyorSubgroup ET AL 2016 Natalizumabe__Events_Total_Events330 «407— Fingolimode«108171Total Weight-92.0% MH,Odds Random,2,601.68, Ratio95%3.72)CL MH,OddsRandom, Ratio95% CL<br>PREZIOSAETAL 2019 30 «30 25 80% «12.77 (0.65, 249.71]<br>Total (95% Cl) 437 196 100.0% 2.85 (1.19, 6.81] <a<br>TotalTestforHeterogeneity:eventsoverall effect:Tau?= 0.17;= 2.35 Chit=360(F =1.18,0.02) df=1 (P129 = 0.28); F= 13% ot Favoursa1ffingolimode] 1 Favours [natalizumbe]10 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
Da mesma maneira, a ausência de surto após 12 meses de tratamento também foi meta-analisada (9 estudos<sup>94–97,99–</sup> 101,103,104, 2.796 participantes), demonstrando novamente com significância estatística que os indivíduos tratados com natalizumabe têm menores chances de ocorrência de surtos, quando comparados àqueles em uso do fingolimode [OR = 1,69 (IC95%: 1,15 – 2,47) I² = 74%, p = 0,007]. Contudo, este desfecho apresentou alta heterogeneidade, o que pode ser explicado pela dispersão nos resultados individuais de cada estudo (Figura F).  
**Figura F -** _Forest-plot_ da meta-análise direta do desfecho de ausência de surto em 12 meses  
<!-- Start of picture text -->
‘StudyBARBINor ETALSubgroup 2016 NatalizumabeEvents267 Total326.— FingolimodeEvents«221«-303:*14.8%Total Weight +MH,Odds Rand—-*1.38 Rati (0.96, o 95%m,2.00)CI MH, OddsRandom, Ratio 95% Cl<br>BARONCINIET AL 2016 93 10275 «(102 «96% «= 3,721.65, 8.39) —_—<br>BRAUNE ETAL 2013 170 237144190 14.0% © 0.81 (0.52, 1.25]<br>CURTIETAL 2019 79 10273102 11.6% «© 1,36 (0.72287)<br>GAJOFATTO ET AL 2014 45 67 «= 2030 8.0% © 1.88 (0.70, 6.08)<br>KALINCIK ET AL 2015 313 4078S 71:«*14.6% © 3.07 (2.10, 4.48) —_<br>PREZIOSAET AL 2019 29-30 1925 26% © 9.16 11.02, 82.21]<br>PROSPERINI ETAL 2017 8 110 «78 «110 11.8% 1.64 (0.88, 3.06]<br>TOTARO ETAL 2016 163 197 «188 «194 13.0% 1.09 (0.65, 1.83]<br>Total (95% Cl) 1568 1227 100.0% 1.69 [1.15, 2.47] al<br>TestforTotalHeterogeneity.eventsoverall effectTaut= 0.22;Z= 2.67ChiF=(P1237 = 30.93,0.007) uf= 8 (P =877 0.0002);F= 74% broFavours ffingolimode]| Favours+ (natalizumabe]t—<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
Também foi realizada uma meta-análise para a ausência de surto após 24 meses de tratamento. Neste desfecho foram incluídos 4 estudos<sup>94–96,99</sup> que totalizaram 1092 indivíduos. A exemplo dos resultados anteriores, os pacientes tratados com natalizumabe apresentaram menores chances de ocorrência de surto do que aqueles tratados com fingolimode [OR = 2,28 (IC95%: 1,25 – 4,13), I² = 67%, p = 0,007]. Este resultado foi estatisticamente significante (Figura G).  
**Figura G -** _Forest-plot_ da meta-análise direta do desfecho de ausência de surto em 24 meses  
<!-- Start of picture text -->
Events Total Events Total Weight_M-H, Random,<br>StudyBARBIN or  ETAL Subgroup  2016 Natalizumabe225 326— Fingolimode«188 —«303«37.4% = Odds—*1,.36 Ratio (0.98,95%1.90)Cl MH, Random,Odds Ratio95% Cl<br>BARONCINI ETAL 2016 90 102 «67 «102 -25.9% © -3.92/1.89, 8.11] ——<br>CURTIET AL 2019 70 102 «53-102 -30.4% = -2.02/1.14, 3.58) =<br>PREZIOSAET AL 2019 29°30 1928 «63% «= 9.46 (1.02, 82.21]<br>Total (95% Cl) 560 532 100.0% 2.28 [1.25, 4.13] =><br>TotalHeterogeneity:TestoreventsowallefeetZ=Tau?= 0.22; 2700000)Chi?=4149.37, df=3 (P =3070.02); F= 68% por re ' ie 100<br>Favours ffingolimode] Favours (natalizumabe]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
- **c) Número de lesões aumentadas no gadolínio**  
Não foi possível meta-analisar o número de lesões aumentadas no gadolínio após 12 e 24 meses, uma vez que só dois estudos<sup>96,99</sup> retrataram este desfecho e, em um deles, não foi possível realizar estimativa de efeito, conforme demonstrado nas Figuras H e I.  
75  
**Figura H -** _Forest-plot_ da meta-análise direta do desfecho de número de lesões aumentadas no gadolínio em 12 meses  
<!-- Start of picture text -->
Natalizumabe —_-Fingolimode Mean Difference Mean Difference<br>‘Study or Subgroup __Mean__SD Total Mean SD Total Weight IV, Random, 95% C1 IV, Randlom, 95% Cl<br>CURTIET AL 2019 009 048 102 0.03 025 102 100.0%  006/0.05,0.17]<br>PREZIOSAET AL 2019 0 0 30 004 02 25 Not estimable<br>Total (95% Cl) 132 127 100.0% 0.06 -0.05, 0.17]<br>Heterogeneity: Not applicable 4 ots $ os 7<br>Test for overall effect: Z= 1.12 (P= 0.26) Favours {natalizumabe] Favours fingolimode)<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
**Figura I -** _Forest-plot_ da meta-análise direta do desfecho de número de lesões aumentadas no gadolínio em 24 meses  
<!-- Start of picture text -->
Natalizumabe —_-Fingolimode Mean Difference Mean Difference<br>‘Study or Subgroup __Mean__SD Total Mean SD Total Weight IV, Random, 95% C1 IV, Randlom, 95% Cl<br>CURTIET AL 2019 009 048 102 0.03 025 102 100.0%  006/0.05,0.17]<br>PREZIOSAET AL 2019 0 0 30 004 02 25 Not estimable<br>Total (95% Cl) 132 127 100.0% 0.06 -0.05, 0.17]<br>Heterogeneity: Not applicable 4 ots $ os 7<br>Test for overall effect: Z= 1.12 (P= 0.26) Favours {natalizumabe] Favours fingolimode)<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho número de pacientes com lesão aumentada no gadolínio, foram realizadas duas meta-análises comparando o uso de natalizumabe com o de fingolimode - uma após 12 meses de tratamento e outra após 24 meses. Nos primeiros 12 meses, foram analisados três estudos<sup>94,97,99</sup> que contemplaram 473 indivíduos. Observou-se menores chances de detecção de lesões realçadas/aumentadas pelo gadolínio no grupo tratado com natalizumabe [OR = 0,17 (IC95%: 0,07 – 0,41) I² = 6%, p < 0,0001) (Figura J). Apesar do amplo intervalo de confiança de dois estudos incluídos, o resultado final foi estatisticamente significante. Na análise do desfecho após 24 meses de tratamento foram incluídos dois estudos<sup>94,99</sup> com 346 indivíduos onde, de maneira similar aos 12 meses, foram demonstradas menores chances de detecção de lesões realçadas/aumentadas pelo gadolínio no grupo tratado com natalizumabe [OR = 0,40 (IC95%: 0,20 – 0,78) I²= 6%, p < 0,0001] (Figura K).  
**Figura J -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com lesões aumentadas no gadolínio em 12 meses  
<!-- Start of picture text -->
Study or Subgroup NatalizumabeEvents Total_Events— FingolimodeTotal Weight_M-H,OddsRandom, Ratio95% Cl MH, OddsRandom, Ratio95% Cl<br>BARBIN ETALGAJOFATTO ETAL20162014 72 20846 301 1432 79.3%126% 0.910.13(0.08,10.06,10.62] 0.31]<br>PREZIOSAETAL 2019 0 (30 2 25 81% 0.15(0.01, 3.37]<br>Total (95% Cl) 284 189 100.0% 1710704<br>Total events a 33<br>Heterogeneity: Tau?<br>Test for overall effect:= Z= 0.07; 3.91Chit=(P < 2.13, 0.0001)df= 2 (P= 0.36); P= 6% os Favoursre}[natalizumabe] + Favours (fingolimode}$ 7}<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
**Figura K -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com lesões aumentadas no gadolínio em 24 meses.  
<!-- Start of picture text -->
Study or Subgroup EventsNatalizumabeTotal— EventsFingolimodeTotal Weight _M-H,OddsRandom, Ratio95% Cl MH, ‘OddsRandom, Ratio95% Cl<br>BARBIN ETAL 2016 16 177 =~ -22—« 114 95.2% 0.42 (0.21, 083),<br>PREZIOSAET AL 2019 0 30 2 25 4.8% 0.15(0.01, 3.37)<br>Total (95% Cl) 207 139 100.0% 0.40 [0.20, 0.78] =_><br>Total events 16 24<br>= = Favours (natalizumabe] Favours [fingolimode}<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
76

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de número de lesões novas ou aumentadas em T2, foi realizada uma meta-análise para 12 meses e outra para 24 meses de tratamento, ambas abrangendo dois estudos<sup>96,99</sup> e 259 participantes. Aos 12 meses, não foi identificada diferença estatisticamente significante entre natalizumabe e fingolimode para a incidência de lesões em T2 [OR= -0,13 (IC95%: -0,39 – 0,13) I²= 0%; p=0,32] (Figura L). Já aos 24 meses, a meta-análise favoreceu o natalizumabe, com uma diferença média estatisticamente significante no número de lesões novas ou aumentadas em T2 [OR= -0,51, (IC95%: -0,86 – -0,17) I²= 4%; p=0,003] comparado ao fingolimode (Figura M).  
**Figura L -** _Forest-plot_ da meta-análise direta do desfecho de número de lesões novas ou aumentadas em T2 em 12 meses  
<!-- Start of picture text -->
Natalizumabe —_Fingolimode Mean Difference Mean Difference<br>Study<br>CURTIETor SubgroupAL 2019 _Mean__SD_Total037 095 102 MeanO47 1.06SD Total102 Weight892% IV,-0.10/0.37,0.17|Random,95% Cl I, Random,95% Cl<br>PREZIOSAETAL<br>2019 0.77 159 30 1.16 14 25 108% -0.39-1.18,0.40)<br>Total (95% Cl) 132 127 100.0% — -0.13|-0.39, 0.13]<br>‘TestHeterogeneity: Tau*= 0.00; Chi*= 0.46, df=1 (P = 0.50); F= 0% 4 ots ae 7<br>for overall effect: Z= 0.99 (P= 0.32) Favours [natalizumabe] Favours ffingolimode]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
**Figura M -** _Forest-plot_ da meta-análise direta do desfecho de número de lesões novas ou aumentadas em T2 em 24 meses  
<!-- Start of picture text -->
Natalizumabe _Fingolimode Mean Difference Mean Difference<br>‘Study<br>CURTIETALor Subgroup2019 __Mean__SDO17 062 Total102 Mean063 146SD Total102 Weight91.6% IV,-046(0.77,-0.15] Random,95% Cl 1, Random,95% Cl<br>PREZIOSAETAL2019 0.83 1.72 30 1,92 263 28 84% -1.09(-2.26,0.08)<br>Total (95% Cl) 132 127 100.0% -0.51[-0.86, -0.17] lean ane<br>Heterogeneity: Tau? = 0.01; Chi#= 1.06, df= 1 (P = 0.31); P= 4% 4 te + ae 7<br>Testfor overall effect: Z= 2.93 (P = 0.003) Favours [natalizumabe] Favours fingolimode]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Foram realizadas duas meta-análises para o desfecho de número de pacientes com lesões hiperintensas novas ou aumentadas em T2, uma aos 12 meses (4 estudos<sup>94,95,97,99</sup> , 672 participantes) e outra aos 24 meses (3 estudos, 259 participantes) de tratamento. Em 12 meses, o natalizumabe apresentou efeito protetor, reduzindo a chance de surgimento de lesões em T2 com significância estatística [OR=0,33 (IC95%: 0,16 – 0,68) I²= 54%; p=0,002] (Figura N). A heterogeneidade identificada se deu em função do estudo Baroncini et al., que ao ser retirado resulta em um I² de 0%, sem alterar a significância estatística. Os mesmos resultados foram encontrados na meta-análise aos 24 meses de tratamento<sup>94,95,99</sup> , favorecendo o natalizumabe em comparação ao fingolimode com significância estatística [OR=0,23 (IC95%: 0,07 – 0,79) I²= 82%; p=0,02] (Figura O). Da mesma forma que aos 12 meses, o estudo de Baroncini et al. foi o responsável pela alta heterogeneidade. Uma vez removido esse estudo, o I² se igualou a 0.  
**Figura N -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com lesões novas ou aumentadas em T2 em 12 meses.  
<!-- Start of picture text -->
‘Study or Subgro NatalizumabeEvents _Total_Events— FingolimodeTotal_Weight_M-H, Random,Odds Ratio Odds Ratio<br>BARBINET AL 2016 17-208 «25143 33.9% 0.42 (0.22,95%0.81]Cl MH,—— Random,95% Cl<br>BARONCINIET AL 2016 6 102 32 102 26.4% 0.44 (0.05, 0.34) —_—_<br>GAJOFATTO ET AL 2014 8 42 4 20 17.8% 0.94 (0.25, 3.59]<br>PREZIOSAET AL 2019 9 30 15 25 21.9% 0.29 10.09, 0.87] —_—_<br>Total (95% Cl) 382 290 100.0% 0.33 (0.16, 0.68] =_><br>Total events 40 76<br>Heterogeneity: Tau= 0.28; ChiF= 6.47, df= 3 (P= 0.09); F= 54% bor ot i 10 100<br>Testor overall eect Z= 3.04 (P= 0.002) Favours [natalizumabe] Favours ffingolimode]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
77  
**Figura O -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com lesões novas ou aumentadas em T2 em 12 meses  
<!-- Start of picture text -->
Natalizumabe —_Fingolimode Odds Ratio Odds Ratio<br>Study or Subgroup Events Total Events Total Weight _M-H, Random, 95% Cl MLH, Random, 95% Cl<br>BARBIN ET AL 2016 2 177 29 114 37.7% 0.53 (0.29, 0.95) —<br>BARONCINI ET AL 2016 4 102 38 102 31.4% 0.07 (0.02, 0.20) ——<br>PREZIOSA ET AL 2019 10 30 16 25 30.9% 0.28 (0.09, 0.86) — —<br>Total (95% Cl) 309 241 100.0% 0.23 [0.07, 0.79] —=>__<br>Total events 4 83<br>sleetest ieeefor overall effecthearZ= 2.33 (P=  oe0.02) df= 2 (P = 0.004); F= 82% 001 Favours01 [natalizumabe] 1 Favours ffingolimode]40 4100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de ausência de atividade radiológica em 12 meses, foram incluídos na meta-análise dois estudos<sup>100,101</sup> e 611 participantes. O resultado favoreceu o natalizumabe, com significância estatística [OR=2,73 (IC95%: 1,86 – 4,02) I²= 0%; p<0,00001], com maior chance de os pacientes não apresentarem atividade radiológica em comparação ao fingolimode (Figura P).  
**Figura P -** _Forest-plot_ da meta-análise direta do desfecho de ausência de atividade radiológica em 12 meses  
<!-- Start of picture text -->
‘Study or Subgroup NatalizumabeEvents Total— EventsFingolimodeTotal Weight _M-H,OddsRandom, Ratio95% CI MH, OddsRandom, Ratio95% Cl<br>PROSPERINI ETAL 2017 84 110 62 110 44.6% 2.50 [1.40, 4.46) —<br>TOTARO ETAL 2015 172 197 136 194 55.4% 2.93 1.74, 4.94) +<br>Total (95% Cl) 307 304 100.0% 2.73 1.86, 4.02] ><br>Total events 256 198<br>TestHeterogeneity: for overall Tau*effect:= Z=0.00;5.09Chi*=(P < 0.00001)0.16, df= 1 (P = 0.69),F= 0% 0.01 FavoursO41 ffingolimode] 1 Favours [natalizumabe]10 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise do número de pacientes que atingiram o desfecho de ausência de evidência de atividade da doença (NEDA3, do inglês _No Evidence of Disease Activity_ ) foi realizada para a comparação entre natalizumabe e fingolimode aos 12 (cinco estudos<sup>95,96,99–101</sup> e 1.074 participantes) e 24 meses de tratamento (três estudos<sup>95,96,99</sup> e 463 participantes). O NEDA-3 é um desfecho composto, que considera três parâmetros: ausência de atividade radiológica, ausência de progressão da incapacidade e ausência de surtos. Aos 12 meses, o tratamento com natalizumabe foi estatisticamente favorecido [OR=2,12 (IC95%: 1,59 – 2,84) I²= 20%; p<0,00001], aumentando a chance de atingir NEDA-3 em mais de duas vezes em comparação ao fingolimode (Figura Q). A meta-análise de NEDA-3 aos 12 meses também favoreceu o natalizumabe, com significância estatística [OR=3,07 (IC95%: 2,05 – 4,59) I²= 0%; p<0,00001], em comparação ao fingolimode (Figura R).  
**Figura Q -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes que atingiram NEDA-3 em 12 meses.  
<!-- Start of picture text -->
Natalizumabe —_Fingolimode Odds Ratio Odds Ratio<br>‘Study or Subgro Events Total Events Total Weight _MLH, Random, 95% CI MH, Random, 95% Cl<br>BARONCINIETAL 2016 83 102 69 102 174% 318 (1.69,6.01] +<br>CURTIET AL 2019 60 102 50 «102 21.8% 1.49 (0.85, 2.58)<br>PREZIOSAPROSPERINIETAL 2019 15 30 8 25 6.5% 2.13(0.70, 6.41)<br>TOTARO ET ALETAL20152017 14274 1 9710 11546 1 9410 32 2. 03 % 1.772.86 [1(1 . 1665 ,  42 . 96)71] —_——_—_—,<br>Total (95% Cl) 541 533 100.0% 2.12 [1.59, 2.84] al<br>Total events 374 278<br>TestorHeterogeneity:overall Tau*effect:= Z=0,02;5.06Chi?(P =<4.98,0.00001)df= 4 (P = 0.29), F= 20% tn 02Favours [fingolimode]ny 7 Favours$[natalizumabe]7 70<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
78  
**Figura R -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes que atingiram NEDA-3 em 24 meses  
<!-- Start of picture text -->
‘Study Natalizumabe — Fingolimode Odds Ratio Odds Ratio<br>BARONCINIETor SubgrouyAL 2016 Events73 Total102 Events46102Total Weight_M-H,44.4% Random,4.18 95% Cl MH, Random,95% Cl<br>CURTIETALPREZIOSAET 2019AL 2019 4015 13 0 2-227 10225 41 2. 98 % 2 .57:35 (2.28, ( 10 83 . 27 ,  7.67] 47 9 . 3 5] ————<br>Total (95% Cl) 234 229 100.0% 3.07 [2.05, 4.59] =_<br>Total events 134 15<br>TestHeterogeneity: Tau= 0.00; Ch=1.82, df= 2 (P= 0.40); P= 0% or 02 ost 2 3 10<br>for overall effect Z= 6.44 (P < 0.00001) Favours ffingolimode] Favours [natalizumabe]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise do número de pacientes com melhora do EDSS em 12 meses incluiu dois estudos<sup>94,98</sup> e 1.458 participantes. Não foi identificada diferença entre os tratamentos com natalizumabe e fingolimode para esse desfecho [OR=1,00 (IC95%: 0,81 – 1,25) I²= 0%; p = 0,98]. Foi identificada, ainda, imprecisão na estimativa de efeito, evidenciada pelos amplos intervalos de confiança dos estudos (Figura S).  
**Figura S -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com melhora do EDSS em 12 meses  
<!-- Start of picture text -->
‘Study of Subgrou NatalizumabeEvents Total— EventsFingolimodeTotal Weight_MLH, Random,Odds Ratio ‘Odds Ratio<br>BARBIN ETAL 2016 68 272 65 288 30.9% 0.99 (0.67,95%1.47]Cl MH,Random,95% Cl<br>KOCHHENRIKSENETAL2017 186.484.185.484 B9.1% 4.01 (0.78, 1.31]<br>Total (95% Cl) 736 722 100.0% 1,000.81, 1.25]<br>Total events 254 260<br>TestorHeterogeneity:overall Tau*=effect Z=0.00;0.03Chi*=(P=0.01,0.98)df=1 (P= 0.94); P= 0% bs FavoursoF {fngolimod) t Favours [natalizumabe]75 3<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise do número de pacientes com estabilização do EDSS em 24 meses incluiu dois<sup>98,101</sup> estudos e 1.319 participantes. Não foi identificada diferença entre os tratamentos com natalizumabe e fingolimode para esse desfecho [OR=1,10 (IC95%: 0,66 – 1,85) I²= 51%; p = 0,71]. Muito embora apenas dois estudos tenham sido incluídos nessa meta-análise, uma alta heterogeneidade foi identificada. Provavelmente isso ocorreu em função de os estudos incluídos apresentarem diferentes magnitudes e direções do efeito, além de diferentes amplitudes no intervalo de confiança; impactando tanto na precisão quanto na consistência da estimativa de efeito (Figura T).  
**Figura T -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com estabilização do EDSS em 24 meses  
<!-- Start of picture text -->
Events Total_Events Total Weight_MLH, Random,<br>‘StudyKOCHHENRIKSENETAL2017‘144—«464.—«152 or Subgroup Natalizumabe  Fingolimode Odds Ratio95% Cl MH, Random,Odds Ratio95% Cl<br>TOTARO ET AL 2015 184 197174 484«194 -68.5%31.5% ©—— 0.92(0.70,1.22)1,630.79, 3.37]<br>Total (95% Ch 661 658 100.0% 1.10 0.66, 1.85]<br>TestforTotalHeterogeneity:eventsoverall effectTau?= 0.08;Z= 0.38 Chi#=P=2.03,0.71) df=328 1 (P= 0.18); P=328 61% Fy Favours ngffingolimode] t Favours [natalizumabe]+ Z<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
O desfecho de progressão da incapacidade foi avaliado aos 12 e 24 meses de tratamento. Para a meta-análise de progressão em 12 meses, foram incluídos seis estudos<sup>95,96,99,100,103,104</sup> e 1688 participantes. Não foi identificada diferença estatisticamente significante entre os tratamentos para esse desfecho [OR=1,05 (IC95%: 0,36 – 1,31) I²= 35%; p = 0,83] (Figura U). Aos 24  
79  
meses<sup>95,96,99</sup> também não foi identificada diferença estatisticamente significante na progressão da incapacidade entre natalizumabe e fingolimode [OR=0,96 (IC95%: 0,50 – 1,86) I²= 0%; p = 0,90] (Figura V).  
**Figura U -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com progressão da incapacidade em 12 meses  
<!-- Start of picture text -->
‘Study or Subgroup NatalizumabeEvents Total— FingolimodeEvents Total Weight _MLH,OddsRandom, Ratio95% Cl MH, OddsRandom, Ratio95% Cl<br>BARONCINIET AL 2016 7 102 3 102 139% 0.76 (027,213)<br>BRAUNE ETAL 2013 49° 237-37 190 329% 1,08 (0.67, 1.74]<br>CURTIET AL 2019 1 102 3 102 36% 0.33 (0.03, 3.19)<br>KALINCIK ET AL 2015 45° 407 10171: 22.6% 2.00 (0.98, 4.07)<br>PREZIOSAET AL 2019 3 30 0 25 21% — 6.4910.32, 131.92]<br>PROSPERINIET AL 2017 20 1100-27110 24.9% 0.68 (0.36, 1.31]<br>Total (95% CI) 988 700 100.0% 1.05 10.67, 1.64]<br>Total events 125 86<br>Heterogeneity: Tau*= 0.10; Chi*= 7.68, df= 5 (P= 0.18); P= 35% hor ri} 7 10 100<br>Test for overall effect: 2= 0.21 (P= 0.83) Favours [natalizumabe] Favours [fingolimode]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
**Figura V -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes com progressão da incapacidade em 24 meses  
<!-- Start of picture text -->
‘Study or Subgroup EventsNatalizumabeTotal— FingolimodeEvents Total Weight_M-H,OddsRandom, Ratio95% Cl MH, OddsRandom, Ratio95% CL<br>BARONCINI ETAL 2016 9 102 13 102 541% 0.66 (0.27, 1.63)<br>CURTIET AL 2019 9 102 7 102 41.3% 1.31 (0.47, 3.67]<br>PREZIOSAET AL 2019 2 30 0 25 4.6% 4.47 0.20, 97.63]<br>Total (95% Cl) 234 229 100.0% 0.96 [0.50, 1.86]<br>TotalHeterogeneity:events Tau? = 0.00; Chi*=20 1.98, df= 2 (P= 0.37);20 P= 0% bor ah ; +b 0!<br>Test for overall effect. 2= 0.12 (P= 0.90) Favours [natalizumabe] Favours ffingolimode]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise de descontinuação do tratamento em 12 meses incluiu três estudos<sup>97,102,104</sup> e 2.181 participantes. Não foi identificada diferença estatisticamente significante entre o tratamento com natalizumabe e fingolimode para esse desfecho [OR=0,86 (IC95%: 0,68 a 1,53), I² = 82%, p = 0,68] (Figura X). Cabe ressaltar a alta heterogeneidade identificada, decorrente dos estudos com diferentes magnitudes e direções de efeito, além de ser observada também grande imprecisão na estimativa de efeito.  
**Figura X -** _Forest-plot_ da meta-análise direta do desfecho de número de pacientes que descontinuaram o tratamento em 12 meses  
<!-- Start of picture text -->
Natalizumabe —Fingolimode ‘Odds Ratio Odds Ratio<br>‘Study or Subgroup Events Total_Events Total_Weight_M-H, Random, 95% Cl MH, Random, 95% Cl<br>FRISELL ETAL 2015 83 640 «(175°—«876 A74% 0.60 (0.45, 0.79) ——<br>GAJOFATTO ET AL 2014 30 8718 30 23.7% 0.97 (0.40, 2.36}<br>KALINCIK ET AL 2015 33° «40710171 28.8% 1.42 (0.68, 2.95}<br>Total (95% Cl) 1104 1077 100.0% 0.86 [0.48, 1.53]<br>Total events 146 201<br>Heterogeneity:<br>Test for overall effect:Tau*= Z= 0.16; 0.51 Chit=(P= 6.32, 0.61)df= 2 (P = 0.07); = 62% bp Favours { n atalizumabe}g Favours (fingolimode]+ Z<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para avaliar a qualidade metodológica dos estudos observacionais incluídos, foi utilizada a escala de Newcastle-Ottawa<sup>105</sup> .  
A maioria dos estudos foi classificada como de qualidade alta segundo os parâmetros avaliados pela ferramenta (Quadro G).  
80  
**Quadro G -** Parâmetros para avaliação da qualidade dos estudos observacionais do tipo coorte incluídos, segundo Newcastle-Ottawa  
|**Parâmetros***|**Seleção**|**Comparabilidade**|**Desfecho**|**Qualidade****|
|---|---|---|---|---|
|**Barbin et al., 2016**|☆☆☆☆|-|☆☆|BAIXA|
|**Baroncini et al., 2016**|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Curti et al., 2019**|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Gajofatto et al., 2014**|☆☆☆|-|☆☆|BAIXA|
|**Koch-Henriksen et al., 2017**|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Preziosa et al., 2019**|☆☆☆|☆|☆☆|BOA|
|**Prosperini et al., 2017**|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Totaro et al., 2015**|☆☆☆|-|☆☆|BAIXA|
|**Frisell et al., 2015**|☆☆☆☆|☆|☆☆|BOA|
|**Braune et al., 2013**|☆☆☆☆|☆|☆☆|BOA|
|**Kalincik et al., 2015**|☆☆☆☆|☆☆|☆☆☆|BOA|  
*Um estudo pode receber no máximo uma estrela para uma das subcategorias de “seleção” e “desfecho” (1 ao 4 e 6 ao 7), e no máximo duas estrelas para a subcategoria de “comparabilidade” (item 5).  
****** Boa qualidade: 3 ou 4 estrelas em seleção E 1 ou 2 estrelas em comparabilidade E 2 ou 3 estrelas em desfecho; Moderada: 2 estrelas em seleção E 1 ou 2 estrelas em comparabilidade E 2 ou 3 estrelas em desfecho.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A qualidade da evidência para os desfechos meta-analisados foi avaliada através do método GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ )<sup>106</sup> . Todos os desfechos avaliados estão descritos abaixo, com as justificativas para rebaixar a qualidade, quando aplicável (Tabela A).  
81  
**Tabela A.** Sumarização dos resultados dos estudos incluídos ( _Summary Of Findings_ [SOF] do _software_ GRADEpro)  
|**Avaliação da**|**certeza**||||||**№ de paciente**|**s**|**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineame**<br>**nto**<br>**do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistên**<br>**cia**|**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|**Natalizumabe**|**outros**<br>**DMDs**<br>**no SUS**<br> <br>**(**|**Relativo**<br>**95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|4<br>**ARR em 2**|estudo<br>observacion<br>al<br>**4 meses**|grave<sup>a</sup>|grave<sup>b,c,d</sup>|não grave|muito<br>grave<sup>e,f</sup>|nenhum|648|619|-<br>MD<br>**0.13**<br>**menor**<br>(0.26 menor<br>para 0)|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|
|2|estudo<br>observacion<br>al|não<br>grave|muito grave<br>b,g,h|não grave|muito<br>grave<sup>g,i</sup>|nenhum|132|127|-<br>MD<br>**0.02**<br>**menor**<br>(0.2 menor<br>para<br>0.17<br>mais alto)|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|  
**Ausência de surto em 12 meses**  
|9|estudo<br>observacion|muito<br>grave<sup>j</sup>|muito grave<br>b,g,h|não grave|grave<sup>e</sup>|nenhum|1237/1568<br>(78.9%)|877/1227<br>(71.5%)|**OR 1.69**<br>(1.15<br>para|**94 mais por**<br>**1.000**|⨁◯◯◯<br>MUITO|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||al||||||||2.47)|(de 28 mais<br>para<br>146<br>mais)|BAIXA||  
**Ausência de surto em 24 meses**  
82  
|**Avaliação da**|**certeza**||||||**№ de paciente**|**s**||**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineame**<br>**nto**<br>**do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistên**<br>**cia**|**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|**Natalizumabe**|**outros**<br><br>**no SUS**|**DMD**|**s**<br>**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|4|estudo<br>observacion<br>al|grave<sup>a</sup>|grave<sup>b,h</sup>|não grave|grave<sup>e</sup>|nenhum|414/560<br>(73.9%)|327/532<br>(61.5%)||**OR 2.28**<br>(1.25<br>para<br>4.13)|<br>**170**<br>**mais**<br>**por 1.000**<br>(de 51 mais<br>para<br>254<br>mais)|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|2|estudo|não|não grave|não grave|grave<sup>e</sup>|nenhum|360/437|129/196|**OR 2.85**|**188**<br>**mais**|⨁◯◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||observacion|grave|||||(82.4%)|(65.8%)|(1.19<br>para|**por 1.000**|MUITO||
||al||||||||6.81)|(de 38 mais<br>para<br>271<br>mais)|BAIXA||

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|6|estudo|não|muito grave|não grave|muito|nenhum|125/988|86/700|**OR 1.05**|**5 mais por**<br>⨁◯◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|
||observacion|grave|g,k||grave<sup>e</sup>||(12.7%)|(12.3%)|(0.67<br>para|**1.000**<br>MUITO||
||al||||||||1.64)|(de<br>37<br>menos para<br>64 mais)<br>BAIXA||  
**Progressão da incapacidade em 24 meses**  
83  
<!-- Start of picture text -->
Avaliação da certeza  № de pacientes  Efeito<br>Delineame<br>№  dos  Risco  Inconsistên Evidência  Outras  outros  DMDsRelativo  Absoluto  Certeza  Importância<br>nto  do  Imprecisão  Natalizumabe<br>estudos  de viés  cia  indireta  considerações  no SUS  (95% CI)  (95% CI)<br>estudo<br>3  estudo  não  muito grave  não grave grave  e  nenhum  20/234 (8.5%) 20/229 (8.7%)  OR 0.96  3  menos  ⨁◯◯◯ IMPORTANTE<br>observacion grave  g  (0.50  para  por 1.000  MUITO<br>al  1.86)  (de  42  BAIXA<br>menos para<br>64 mais)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|2|estudo<br>observacion<br>al|não<br>grave|não grave|não grave|muito<br>grave<sup>e,f</sup>|nenhum|132|127<br>-<br>MD<br>**0.13**<br>**menor**<br>(0.39 menor<br>para<br>0.13<br>mais alto)<br>⨁◯◯◯<br>MUITO<br>BAIXA|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|2|estudo<br>observacion<br>al|não<br>grave|não grave|não grave|grave<sup>e</sup>|nenhum|132|127<br>-<br>MD<br>**0.51**<br>**menor**<br>(0.86 menor<br>para<br>0.17<br>menor)<br>⨁◯◯◯<br>MUITO<br>BAIXA|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|  
**Nº de pacientes com novas lesões em T2 em 12 meses**  
84  
<!-- Start of picture text -->
Avaliação da certeza  № de pacientes  Efeito<br>Delineame<br>№  dos  Risco  Inconsistên Evidência  Outras  outros  DMDsRelativo  Absoluto  Certeza  Importância<br>nto  do  Imprecisão  Natalizumabe<br>estudos  de viés  cia  indireta  considerações  no SUS  (95% CI)  (95% CI)<br>estudo<br>4  estudo  grave  a  grave  b,h  não grave grave  e  nenhum  40/382  76/290  OR 0.33  157 menos  ⨁◯◯◯ NÃO<br>observacion (10.5%)  (26.2%)  (0.16  para  por 1.000  MUITO  IMPORTANTE<br>al  0.68)  (de  208  BAIXA<br>menos para<br>68 menos)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|3|estudo<br>observacion|muito<br>grave<sup>j</sup>|muito grave<br>b,h|não grave|grave<sup>l</sup>|nenhum|41/309<br>(13.3%)|83/241<br>(34.4%)|**OR 0.23**<br>(0.07<br>para|**237 menos**<br>**por 1.000**|⨁◯◯◯<br>MUITO|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||al||||||||0.79)|(de<br>309<br>menos para<br>51 menos)|BAIXA||

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|3|estudo|muito|grave<sup>h</sup>|não grave|muito|nenhum|9/284 (3.2%)|33/189|**OR 0.17**|**140 menos**|⨁◯◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||observacion|grave<sup>j</sup>|||grave<sup>e</sup>|||(17.5%)|(0.07<br>para|**por 1.000**|MUITO||
||al||||||||0.41)|(de<br>160<br>menos para<br>95 menos)|BAIXA||  
**Nº de pacientes com lesões aumentadas no gadolínio em 24 meses**  
85  
|**Avaliação da**|**certeza**||||||**№ de paciente**|**s**||**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineame**<br>**nto**<br>**do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistên**<br>**cia**|**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|**Natalizumabe**|**outros**<br><br>**no SUS**|**DMD**|**s**<br>**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|2|estudo<br>observacion<br>al|muito<br>grave<sup>j</sup>|não grave|não grave|grave<sup>l</sup>|nenhum|16/207 (7.7%)|24/139<br>(17.3%)||**OR 0.40**<br>(0.20<br>para<br>0.78)|<br>**96**<br>**menos**<br>**por 1.000**<br>(de<br>133<br>menos para<br>33 menos)|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|2|estudo<br>observacion<br>al|muito<br>grave<sup>j</sup>|não grave|não grave|não grave|nenhum|256/307<br>(83.4%)|198/304<br>(65.1%)|**OR 2.73**<br>(1.86<br>para<br>4.02)|**185**<br>**por 1.**<br>(de<br>mais<br>231 m|**mais**<br>**000**<br>125<br>para<br>ais)|⨁◯◯◯<br>MUITO<br>BAIXA|NÃO<br>IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|5|estudo|grave<sup>a</sup>|não grave|não grave|grave<sup>e</sup>|nenhum|374/541|278/533|**OR 2.12**|**176**<br>**mais**<br>⨁◯◯◯|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|
||observacion||||||(69.1%)|(52.2%)|(1.59<br>para|**por 1.000**<br>MUITO||
||al||||||||2.84)|(de<br>113<br>mais<br>para<br>234 mais)<br>BAIXA||  
**Número de pacientes com NEDA-3 em 24 meses**  
86  
<!-- Start of picture text -->
Avaliação da certeza  № de pacientes  Efeito<br>Delineame<br>№  dos  Risco  Inconsistên Evidência  Outras  outros  DMDsRelativo  Absoluto  Certeza  Importância<br>nto  do  Imprecisão  Natalizumabe<br>estudos  de viés  cia  indireta  considerações  no SUS  (95% CI)  (95% CI)<br>estudo<br>3  estudo  não  não grave  não grave grave  e  nenhum  134/234  75/229  OR 3.07  272  mais  ⨁◯◯◯ IMPORTANTE<br>observacion grave  (57.3%)  (32.8%)  (2.05  para  por 1.000  MUITO<br>al  4.59)  (de  172  BAIXA<br>mais  para<br>363 mais)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|3|estudo<br>observacion|muito<br>grave<sup>j</sup>|muito grave<br>b,g,h|não grave|muito<br>grave<sup>m</sup>|nenhum|146/1104<br>(13.2%)|201/1077<br>(18.7%)|**OR 0.86**<br>(0.48<br>para|**22**<br>**menos**<br>**por 1.000**<br>⨁◯◯◯<br>MUITO|IMPORTANTE|
|---|---|---|---|---|---|---|---|---|---|---|---|
||al||||||||1.53)|(de<br>87<br>menos para<br>73 mais)<br>BAIXA||

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
|2|estudo<br>observacion<br>al|muito<br>grave<sup>j</sup>|não grave|não grave|grave<sup>m</sup>|nenhum|254/736<br>(34.5%)|250/722<br>(34.6%)|**OR 1.00**<br>(0.81<br>para<br>1.25)|**0**<br>**menos**<br>**por 1.000**<br>(de<br>46<br>menos para<br>52 mais)|⨁◯◯◯<br>MUITO<br>BAIXA|CRÍTICO|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
**Número de pacientes com estabilização do EDSS em 24 meses**  
87  
|**Avaliação da**|**certeza**||||||**№ de paciente**|**s**||**Efeito**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№**<br>**dos**<br>**estudos**|<br>**Delineame**<br>**nto**<br>**do**<br>**estudo**|**Risco**<br>**de viés**|**Inconsistên**<br>**cia**|**Evidência**<br>**indireta**|**Imprecisão**|<br>**Outras**<br>**considerações**|**Natalizumabe**|**outros**<br>**no SUS**|**DMD**|**s**<br>**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|2|estudo<br>observacion<br>al|muito<br>grave<sup>j</sup>|muito grave<br>b,g,h|não grave|muito<br>grave<sup>m</sup>|nenhum|328/661<br>(49.6%)|326/658<br>(49.5%)||**OR 1.10**<br>(0.66<br>para<br>1.85)|**24 mais por**<br>**1.000**<br>(de<br>102<br>menos para<br>150 mais)|⨁◯◯◯<br>MUITO<br>BAIXA|IMPORTANTE|  
88  
**USO DE MEDICAMENTOS MODIFICADORES DA DOENÇA EM GESTANTES**

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Após busca sistemática na literatura, foram incluídos 16 estudos observacionais na análise qualitativa. Destes, seis tratavam-se de estudos sem comparador e, portanto, não foram incluídos nas meta-análises. Foram extraídos os dados dos dez estudos restantes, com realização de meta-análise dos desfechos possíveis. As meta-análises foram feitas em subgrupos, por medicamento. A população exposta foi considerada como aquela que utilizou MMCD durante o primeiro trimestre da gestação. Abaixo estão sumarizadas as características dos estudos incluídos (Quadro H).  
**Quadro H** - Sumarização das características dos estudos observacionais incluídos.  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|**Geiss et al., 2018**<sup>107</sup>|Estudo observacional prospectivo<br>realizado a partir da coleta de dados|**Desfecho primário de segurança:**<br>Prevalência<br>de<br>malformações|<br>BOA|
|**Participantes:**|até fevereiro de 2017 proveniente de|congênitas importantes, definidas||
||base<br>da<br>Novartis,<br>que|como defeitos estruturais com||
|Total: 1246 gestações e 1255|apresenta diferentes fontes:|importância cirúrgica, médica e||
|lactentes registradas na base de||cosmética, segundo os protocolos da||
|dados|**1)****_Gilenya® Pregnancy Exposure_**|European<br>Surveillance<br>of||
|Desfecho<br>conhecido:<br>717|**_Registry_ **- lançado em maio de 2011|Congenital<br>Anomalies||
|gestações e 725 lactentes|para coletar dados prospectivos de|(EUROCAT).||
|Nascidos vivos: 488 gestações e|segurança materna, fetal e do|Prevalência<br>de<br>malformações||
|494 lactentes|lactente associados ao uso do|congênitas menores, que são as que||
|Desfecho<br>desconhecido/|fingolimode durante a gestação ou 8|não<br>apresentam<br>consequência||
|pendente: 91 gestações|semanas antes da data da última|médica ou cosmética para a criança.||
|Perda<br>de<br>acompanhamento:|menstruação (DUM);|||
|301||**Desfechos**<br>**secundários**<br>**de**||
||**2)****_Pregnancy outcomes Intensive_**|**segurança:**||
|**Características dos pacientes**|**_Monitoring_**|Medidas de outros desfechos como||
|**na linha de base:**|**(PRIM)**- instituído em 1o de março|abortos espontâneos e eletivos,||
||de<br>2014<br>para<br>coletar|natimortos,<br>mortes<br>neonatais||
|Em ambos estudos, mais de|prospectivamente informação de|(contadas com nascidos vivos), e||
|75%<br>dos<br>pacientes<br>foram|pacientes gestantes relatadas para a|nascimentos a termo e pré-termo||
|expostos ao fingolimode dentro|Novartis que não estavam inscritas|com<br>ou<br>sem<br>malformações||
|de 8 semanas antes ou durante<br>da DUM ou durante o primeiro<br>trimestre.|no programa 1.<br>**3)** **Outros casos relatados além**|congênitas.||
|●<br>**Gilenya® Registry**n<br>= 113|**desses**<br>**programas**,<br>por<br>uma<br>variedade de fontes, incluindo|||
|Idade na DUM (anos), média ±|ensaios<br>clínicos,<br>estudos|||
|DP: 31,7 ± 4,6|observacionais,<br>programas<br>de|||
|●<br>**PRIM**n = 674|vigilância e relatos espontâneos.|||  
89  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Idade na DUM (anos), média ±<br>DP: 31,6 ± 5,6||||
|**Coyle et al., 2014**<sup>108</sup>|Estudo prospectivo observacional<br>realizado de 2006 a 2011, a partir do|<br> <br>**Desfecho primário de segurança:**<br>Taxa de malformações congênitas|<br>BOA|
|Participantes:|registro de mulheres expostas antes|<br>significativas em lactentes expostos||
|Total: 99 gestantes|da concepção ou durante a gestação|<br>ao IFN-1b durante a gestação,||
|Três<br>tiveram<br>perda<br>de<br>acompanhamento.|<br>(mas antes ou sem anomalias pré-<br>natais no rastreamento neonatal).<br>O seguimento foi realizado do|<br>definida a qualquer momento após a<br>DUM.||
|99 nascimentos (3 gêmeos),<br>incluindo 86 (86.9%) nascidos|<br> <br>cadastro até o nascimento para a<br>gestante e para os lactentes, do|<br> <br>**Desfechos**<br>**secundários**<br>**de**<br>**segurança:**||
|vivos.|cadastro até a visita pediátrica do 4o<br>mês de vida do lactente.|<br>Prevalência de aborto espontâneo ou<br>desfecho negativo gestacional em|<br>|
|**Características dos pacientes**<br>**na linha de base:**|<br>Critérios de elegibilidade definidos:|<br>mulheres expostas. Prevalência de<br>aborto eletivo, natimorto, gestação|<br>|
|Idade (média, DP): 30,9 (5,29)<br>Idade (mediana, variação): 31,0<br>(19–44)<br>95 gestantes foram expostas ao<br>IFN-1b ainda durante o 1o<br>trimestre e uma gestante durante<br>o terceiro trimestre.|<br> <br> <br> <br>●<br>Mulheres<br>gestantes<br>expostas ao uso IFN-1b a qualquer<br>momento após a DUM ou durante a<br>gestação, mas antes de qualquer<br>rastreamento pré-natal (ultrassom e<br>amniocentese);<br>●<br>Mulheres com exposição<br>similar submetidas a teste pré-natal<br>e sem achados sugestivos de<br>anormalidade fetal;<br>●<br>Foram excluídas gestantes<br>que<br>já<br>apresentavam<br>achados<br>sugestivos de anormalidades fetais<br>ou que registraram após o parto.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>ectópica, morte neonatal e morte<br>materna.||
|**Herbstritt et al., 2015**<sup>109</sup>|Estudo observacional prospectivo<br>de gestantes expostas ao AG e de|<br> <br>**Desfecho primário de segurança:**<br>Nascidos vivos com uma ou mais|<br>BOA|
|Participantes:|gestantes não expostas a MMCD.|anomalias congênitas. Anomalias||
|Total: 246 gestantes com EM<br>Expostas ao AG: 151<br>Não expostas a MMCD: 95|As mulheres foram cadastradas no<br>registro alemão de EM e gestação<br>(_German Multiple Sclerosis and_<br>_Pregnancy registry_) de 2008 a 2013.|<br> <br> <br> <br>congênitas<br>importantes<br>foram<br>consideram como alterações na<br>organogênese, defeitos estruturais<br>do corpo e/ou de órgão que|<br> <br> <br>|
|**Características dos pacientes**|<br>Um questionário padronizado foi|<br>comprometem<br>a<br>viabilidade<br>e||
|**na linha de base:**|aplicado<br>durante<br>o<br>período<br>gestacional e a pós-parto.|<br>requerem intervenção. Anomalias<br>menores foram definidas como|<br>|  
90  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Idade na concepção em anos<br>(média, DP): 31,91 (3,71) dos<br>expostos ao AG e 32,20 (4,08)<br>dos não expostos. Valor de p =|Cadastro foi feito em qualquer<br>momento da gestação.<br>Gestantes<br>foram<br>recrutadas<br>ativamente<br>por<br>clínicos<br>ou|<br> <br> <br>alterações estruturais pequenas que<br>não comprometam a viabilidade e<br>não necessitem ser tratadas. As<br>anomalias<br>congênitas<br>foram|<br> <br> <br>|
|0,579.|enfermeiras<br>ou<br>procuraram<br>os<br>pesquisadores devido a anúncios.<br>O cadastro foi financiado pela<br>indústria, mas os patrocinadores não<br>tiveram<br>envolvimento<br>no<br>delineamento do castro, na coleta de<br>dados, na análise e na disseminação<br>dos resultados.<br>O registro foi aprovado pelo comitê<br>institucional<br>da<br>universidade<br>Bochum de Ruhr.<br>Todas<br>as<br>mulheres<br>assinaram<br>consentimento informado.|<br> <br> <br> <br> <br> <br> <br> <br> <br>classificadas e pontuadas de acordo<br>com os protocolos do EUROCAT<br>(_European_<br>_surveillance_<br>_of_<br>_Congenital_<br>_Anomalies,_<br>ou<br>Vigilância Européia das Anomalias<br>Congênitas) pelos teratologistas.<br>**Desfechos**<br>**secundários**<br>**de**<br>**segurança:**<br>Aborto; morte fetal; morte neonatal<br>precoce; parto pré-termo. Aborto<br>eletivo e gestação ectópica também<br>foram<br>documentados.<br>Peso<br>e<br>comprimento<br>ao<br>nascer<br>dos<br>neonatos foram analisados nos<br>relatórios dos registros dos cuidados<br>gestacional e neonatal.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|
|**Salminem et al., 2010**<sup>110</sup><br>Participantes:<br>14 gestantes expostas ao AG.<br>13 nascidos vivos, incluindo um<br>casal de gêmeos e dois abortos|Estudo observacional de série de<br>casos prospectivos  para relatar a<br>experiência preliminar do uso AG<br>durante a concepção, gestação e<br>período pós-parto.|<br> <br> <br> <br>**Desfecho primário de segurança:**<br>O principal resultado de interesse<br>foi a taxa de anomalias congênitas e<br>aborto espontâneo.<br>**Desfechos**<br>**secundários**<br>**de**|<br> <br> <br>MODERADA|
|espontâneos.<br>Quatro gestantes interromperam<br>o uso do AG até a 20a semana<br>de gestação.<br>Uma usou antes e durante a<br>gestação<br>Nove continuaram o uso desde<br>antes da gestação até o período<br>pós-parto.|Critérios de elegibilidade definidos:<br>Pacientes acompanhadas em serviço<br>de saúde pública inglês desde 2004<br>em uso de AG e que engravidaram<br>em seguida foram acompanhadas<br>sistematicamente até o pós-parto.|<br> <br> <br> <br>**segurança:**<br>Complicações da EM, definida pelo<br>número de surtos. Peso ao nascer,<br>idade gestacional no momento do<br>parto.<br>História da EM foi coletada de<br>prontuários clínicos e o resultado foi<br>coletado pela entrevista por telefone<br>realizada<br>por<br>um<br>único|<br> <br> <br> <br> <br> <br>|
|**Características dos pacientes:**<br>Pacientes do sexo feminino com<br>surgimento agressivo de EM<br>(acometimento<br>físico||entrevistador.||  
91  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|tipicamente frequente, relapsos,<br>recuperação incompleta, alto<br>nível de lesão cerebral na RM),<br>em<br>uso<br>de<br>AG<br>e<br>que<br>continuaram durante a gestação.<br>Idade materna média no parto<br>(variação): 31,6 anos (25-41<br>anos).|<br> <br> <br> <br> <br> <br>|||
|**Nguyen et al., 2019**<sup>111</sup>|Estudo de coorte observacional<br>internacional a partir do registro da|<br> <br>**Desfechos de segurança:**<br>Número de nascidos vivos, parto a|<br>BOA|
|Participantes:<br>Total: 18767 mulheres foram|<br>Base de Dados da EM (com coleta<br>de dados prospectivos por longo|<br> <br>termo, parto pré-termo (com menos<br>de<br>37<br>semanas),<br>abortos|<br>|
|triadas no registro da base de|<br>tempo em 33 países), criada em|<br>espontâneos,<br>aborto<br>induzido,||
|dados da EM inicialmente.|2004.|desfechos<br>desconhecidos<br>(não||
|9098 (48%) apresentaram os||relatados,<br>seguimento<br>perdido,||
|critérios<br>de<br>elegibilidade,<br>contabilizando um seguimento|<br> <br>Dois períodos foram escolhidos: 1o<br>de janeiro de 2005 a 31 de dezembro|<br> <br>mulheres<br>que<br>continuavam<br>gestantes no momento da extração|<br>|
|total de 36043 pacientes-anos.<br>1178 (13%) mulheres tiveram<br>1521<br>gestações<br>registradas,<br>contabilizando<br>um<br>total|<br> <br> <br>de 2010 e 1o de janeiro de 2011 a 31<br>de dezembro de 2016, um período<br>de quase seis anos cada.|<br> <br>dos dados).||
|observado<br>de<br>7445<br>de|<br>Critérios de elegibilidade definidos:|||
|pacientes-ano,<br>incluindo<br>o<br>período pré e pós-gestacional.|<br>Os<br>critérios<br>de<br>inclusão<br>compreenderam<br>mulheres<br>com|<br>||
|Das 1521 gestações, 588 não|<br>idade<br>de<br>15–45<br>anos,|||
|foram expostas a MMCD no<br>ano<br>anterior.<br>298|<br> <br>prospectivamente inscritas na Base<br>da EM entre 1o de janeiro de 2005 a|<br>||
|descontinuaram MMCD no ano<br>anterior.|<br>5 de outubro de 2016, com o<br>diagnóstico<br>de<br>EM<br>remitente-|||
|635 estavam em uso de MMCD|<br>recorrente (2005 ou 2010 revisado|||
|no momento da gestação:|por<br>critério<br>de<br>McDonald).|||
|● 125 IFN-1a IM|Mulheres que converteram para EM|||
|● 61 IFN-1b|secundária progressiva continuaram|||
|● 164 IFN-1a S.C|na análise. Pacientes com síndrome|||
|● 137 GA|isolada clínica foram excluídas.|||
|● 104 Natalizumabe|Gestações antes de 2005 ou antes do|||
|● 17 DMF|diagnóstico<br>de<br>EM<br>remitente-|||
|● 21 Fingolimode|recorrente<br>também<br>foram|||
|● 4 Azatioprina|excluídas.|||  
92  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|● 2 Rituximabe||||
|**Características dos pacientes**<br>**na linha de base:**<br>●<br>2005-2010:<br>410 mulheres/478 gestações;<br>mediana da idade em anos<br>(variação): 31,3 (18,6-42,5).<br>Fenótipo da EM na gestação:<br>96,4% EM remitente-recorrente<br>e<br>3,6%<br>EM<br>secundária<br>progressiva;<br>mediana<br>da<br>duração da doença (variação):<br>4,0 (0,1-24,7); EDSS mediana<br>(variação): 1,5 (0-6,5)||||
|●<br>2011-2016:<br>867 mulheres/ 1043 gestações;<br>mediana da idade em anos<br>(variação): 31,9 (15,4-43,8).<br>Fenótipo da EM na gestação:<br>99,5% EM remitente-recorrente||||
|e<br>0,5%<br>EM<br>secundária<br>progressiva;<br>mediana<br>da<br>duração da doença (variação):<br>5,6 (0,2-22,7); EDSS mediana<br>(variação): 1,5 (0-7,5).||||
|**Fragoso et al., 2013**<sup>112</sup>|Estudo do tipo “coorte histórica”,<br>utilizando<br>registro<br>médico<br>de|<br>**Desfechos de segurança:**<br>Complicações<br>obstétricas<br>e|<br>BOA|
|Participantes:|pacientes de quatro países Brasil,|neonatais; peso ao nascer; altura ao||
|Total: 152 gestações em 132<br>mulheres com EM.|Reino Unido, México e Argentina.|nascer; Apgar; taxas de relapso;<br>progressão da EM pelo EDSS.||
|89 gestantes não expostas aos<br>MMCD durante a gestação.|Critérios de elegibilidade definidos:<br>Pacientes<br>foram<br>incluídos<br>se|||
|61 gestações ocorreram com ao<br>menos 8 semanas de exposição:<br>AG (n = 41)|tivessem ao menos uma gestação<br>com dados completos após a EM ter<br>sido diagnosticada de acordo com o|<br>||
|IFN-1b (n = 17)|critério de McDonald revisado em|||
|Pulsoterapia de imunoglobulina|2010 e se pertencessem a um dos|||
|(n=2)|seguintes grupos: (1) grupo controle|||  
93  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Corticóide oral em alta dose<br>(n=1)<br>**Características dos pacientes**<br>**na linha de base:**|- nenhuma exposição a MMCD por<br>no mínimo três meses antes da<br>gestação; (2) grupo exposto a droga<br>- um mínimo de oito semanas de<br>exposição contínua a qualquer|||
|●<br>Idade na gestação:<br>Controle: 28,6 ± 4,6 anos<br>Expostos a droga: 30,3 ± 5,6<br>anos.<br>●<br>Apresentação<br>clínica<br>da EM<br>Controle:<br>84<br>remitente-<br>recorrente,<br>2<br>secundária<br>progressiva,<br>1<br>primária<br>progressiva<br>Expostos a droga: 52 remitente-<br>recorrente,<br>4<br>secundária<br>progressiva.|MMCD no início da gestação<br>(incluindo o período de maior<br>susceptibilidade<br>aos<br>eventos<br>adversos, da concepção às oito<br>semanas subsequentes).|||
|**Hellwig et al., 2012**<sup>113</sup>|Estudo prospectivo de gestantes<br>com EM que faziam parte de base de<br>|**Desfechos de segurança:**<br>●<br>Anormalidades dos neonatos/|<br>BOA|
|Participantes:|dados nacional da Alemanha.|alterações congênitas.||
|Total: 335 gestantes<br>Não expostas a MMCD: 216<br>gestantes|Foram analisados dados do banco de<br>dados nacional de mulheres com<br>EMRR com gestação ou parto<br>|●<br>Características<br>do<br>neonato<br>(peso,<br>comprimento<br>e<br>idade<br>gestacional no parto).|<br>|
|Em uso de IFN-1b: 78 gestantes<br>Em uso de AG:  41 gestantes.|durante os últimos 10 anos. Foram<br>avaliados cada trimestre de gestação<br>e até três meses após o parto através<br>|●<br>Taxa<br>de<br>relapso<br>anual<br>(_Annualized Relapse Rate_- ARR):<br>`o`<br>durante os três trimestres|<br>|
|**Características dos pacientes**<br>**na linha de base:**|de entrevistas telefônicas ou de<br>consultas clínicas no ambulatório|<br>da gestação e nos primeiros 3<br>meses após o parto;||
|Idade média: não expostos<br>31,01 (± 4,57) anos; IFN-1b<br>31,03 (± 4,05) anos; AG 31.29<br>(± 3.42) anos.|universitário. Todas as informações<br>foram<br>obtidas<br>por<br>entrevistas<br>padronizadas estruturadas.|`o`<br>comparando-se os grupos<br>que<br>amamentaram<br>exclusivamente, os que não<br>amamentaram exclusivamente e<br>os que não amamentaram.|<br> <br> <br>|
|**Weber et al., 2009**<sup>114</sup>|Estudo observacional de coorte<br>prospectiva realizado com pacientes|Nos casos de múltiplas gestações,<br>cada nascido vivo foi incluído|<br> <br>BOA|
|Participantes:<br>1- Grupo comparativo saudável:<br>n=1556;|inscritos<br>em<br>um<br>Serviço<br>de<br>Informação de Teratologia para|individualmente na análise.<br>**Desfecho primário de segurança:**||  
94  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|2- Grupo com EM não exposto<br>ao IFN-1b ou ao AG: n=64;<br>3- Expostos ao IFN-1b: n=69;<br>4- Expostos ao AG: n=31.<br>**Características dos pacientes**<br>**na linha de base:**<br>Grupo saudável (1): mediana de<br>idade - 31 anos|<br> <br> <br>avaliação de risco de droga, em<br>Berlim, de 1996 a 2007<br>A informação do acompanhamento<br>foi<br>obtida<br>em<br>questionários<br>estruturados: detalhes de exposição<br>à droga (tempo de gestação, dose e<br>duração),<br>dados<br>demográficos,<br>médicos<br>e<br>história<br>obstétrica<br>materna.|<br> <br> <br> <br> <br> <br> <br>Taxa de anormalidades congênitas<br>importantes,<br>definidas<br>como<br>anormalidades<br>estruturais<br>de<br>relevância médica, cirúrgica ou<br>cosmética. Todas as anormalidades<br>congênitas foram classificadas de<br>acordo<br>com<br>Merks<br>et<br>al.<br>e<br>Rasmussen, et al.|<br> <br> <br> <br> <br> <br>|
|Grupo com EM sem droga (2):<br>mediana de idade - 32 anos<br>Em uso de IFN (3): mediana de<br>idade - 30 anos<br>Em uso de AG (4): mediana de<br>idade - 31 anos|<br> <br>|**Desfechos**<br>**secundários**<br>**de**<br>**segurança:**<br>Taxas de abortos, natimortos, parto<br>prematuro (<37 semanas), idade<br>gestacional no parto, e peso ao<br>nascer.|<br> <br> <br>|
|**Lu et al., 2012**<sup>115</sup>|Estudo de análise retrospectiva de<br>duas bases de dados populacionais|<br> <br>**Desfechos de segurança:**<br>Desfechos da gestação incluíram|<br>BOA|
|Participantes:<br>4855 mulheres nas bases de<br>dados.<br>553<br>nascimentos<br>de<br>406<br>gestantes.<br>Incluídas: 311 gestantes com<br>EMRR/418 neonatos.<br>1. 80 neonatos de mães que<br>usaram<br>MMCD,<br>mas<br>interromperam o uso até um<br>mês antes da concepção.<br>2. 317 neonatos de mulheres<br>que nunca usaram MMCD.<br>3. 21<br>neonatos<br>expostos<br>MMCD no período gestacional<br>(um mês antes da concepção ou<br>durante a gestação).<br>3.1) 15 neonatos expostos ao<br>Interferon beta.<br>3.2) 6 neonatos expostos ao AG.<br>**Características dos pacientes**<br>**na linha de base:**|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>da mesma província do Canadá. Os<br>dados coletados corresponderam ao<br>período entre abril de 1998 e março<br>de 2009.<br>Os grupos foram divididos entre<br>gestantes com EMRR expostos e<br>não<br>expostos<br>a<br>MMCD.<br>A<br>exposição<br>a<br>dois<br>medicamentos durante a gestação<br>foi analisada: IFN-1b e AG.<br>**Critérios de elegibilidade:**<br>Nascimentos individuais na BC<br>entre 1o de abril de 1988 (quando os<br>bancos de dados registraram pela<br>primeira<br>vez<br>nascimentos<br>de<br>pacientes com EM) e 31 de março de<br>2009 foram incluídos se a mãe<br>estivesse registrada em uma das<br>quatro clínicas de EM, e tivessem<br>diagnóstico antes do parto de<br>EMRR definida clinicamente com<br>evidência laboratorial (critérios de|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>duração do segundo estágio do<br>trabalho de parto, parto vaginal que<br>necessitou assistência (extração à<br>vácuo e/ou fórceps), e cesariana<br>(emergencial ou eletiva). Cesariana<br>foi analisada apenas entre os partos<br>de primíparas, pois um parto prévio<br>por cesariana aumenta a chance de<br>um próximo parto por cesariana.<br>Desfechos neonatais incluíram peso<br>ao nascer, idade gestacional, escore<br>de Apgar aos 5 minutos para<br>nascidos vivos apenas. Anomalias<br>congênitas (principais e menores)<br>foram relatadas para nascidos vivos<br>e natimortos.|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|  
95  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Comparáveis<br>entre<br>os<br>três<br>grupos (expostos a MMCD,<br>tratados previamente e sem<br>tratamento),<br>exceto<br>pela<br>duração da EM e da disfunção<br>(medido pelo escore EDSS), o<br>qual foi mais baixo no grupo<br>nunca tratado por MMCD<br>(grupo 2) (p < 0,05).|<br> <br> <br> <br> <br> <br> <br> <br>Poser<br>ou<br>McDonald).<br>Foram<br>excluídos<br>nascimentos<br>não<br>individuais (por exemplo, gêmeos,<br>trigêmeos) devido à tendência de<br>serem pré-termo e/ou baixo peso.<br>Nascimentos de mulheres com EM<br>primária progressiva ou um curso da<br>doença<br>desconhecido/<br>indeterminado<br>foram<br>excluídos;<br>nenhum<br>MMCD<br>tinha<br>sido<br>aprovado para ser utilizado na EM<br>primária progressiva.|<br> <br> <br> <br> <br> <br> <br> <br> <br>||
|**Ebrahimi et al., 2015**<sup>116</sup>|Estudo<br>prospectivo<br>que<br>visou<br>comparar os desfechos gestacionais|<br> <br>**Desfechos de segurança:**<br>Desfechos da gestação coletados|<br>BOA|
|Participantes:<br>1. Gestantes com EM remitente-<br>recorrente<br>expostas<br>ao<br>natalizumabe<br>durante<br>o<br>primeiro trimestre de gestação:<br>n = 101. Neonatos: n = 77.<br>2. Gestantes do grupo com EM<br>equivalente quanto à doença ao<br>grupo 1, exposto a outra<br>MMCD ou não exposto: n= 78.<br>Neonatos: n = 69.<br>3. Gestantes com grupo controle<br>saudável: n=97. Neonatos: n =<br>92.<br>**Características dos pacientes**<br>**na linha de base:**|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>em mulheres com EMRR expostas<br>ao natalizumabe durante o início da<br>gestação, com grupos de gestantes<br>com<br>doença<br>equivalente<br>não<br>expostas<br>ao<br>natalizumabe<br>e<br>controles saudáveis.<br>Foram<br>selecionadas<br>gestantes<br>registradas na base de dados de EM<br>em<br>Bochum,<br>na<br>Alemanha,<br>diagnosticadas com EM remitente-<br>recorrente, recrutadas entre 2006 e<br>2013.<br>Para o acompanhamento, gestantes<br>realizaram entrevistas a cada três<br>meses em consultas ambulatoriais<br>universitárias em Bochum ou por<br>telefone.<br>As<br>mulheres<br>foram|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>incluíram malformações congênitas,<br>abortos<br>espontâneos,<br>abortos<br>terapêuticos, idade gestacional da<br>perda gestacional, idade gestacional<br>ao nascimento, peso ao nascer,<br>circunferência<br>cefálica,<br>comprimento ao nascer, gênero, e<br>forma de parto. Detalhes da saúde<br>neonatal e das anomalias congênitas<br>foram confirmados pelo médico da<br>criança por carta de comunicação.|<br> <br> <br> <br> <br> <br> <br> <br> <br>|
|O<br>grupo<br>2 (com<br>EM<br>equivalente)<br>foi<br>significativamente mais velho<br>comparado ao grupo controle e<br>aos expostos ao natalizumabe (p<br>< 0.001). A taxa de exposição<br>ao álcool foi significativamente<br>maior nos controles do que nos<br>grupos com EM e nos expostos|<br> <br> <br> <br> <br> <br> <br> <br> <br>acompanhadas até seis meses após o<br>parto. Todos os dados relatados<br>pelas gestantes foram coletados a<br>partir<br>de<br>questionários<br>padronizados.<br>A exposição foi definida como<br>tratamento com natalizumabe a<br>partir de oito semanas antes da data<br>da última menstruação em diante.|<br> <br> <br> <br> <br> <br>||  
96  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|(p<br>=<br>0.003).<br>Não<br>houve<br>diferenças entre os grupos<br>quanto à idade gestacional do<br>recrutamento, IMC antes da<br>gestação, tabagismo, ou história<br>obstétrica.||||
|**Karlsson et al., 2014**<sup>117</sup>|Estudo prospectivo que objetivou<br>relatar os resultados de nove|**Desfechos de segurança:**|BOA|
|Participantes:<br>Total: 89 gestações de mulheres<br>com relapso de EM foram|ensaios clínicos fase II, III e IV<br>realizados em pacientes com surto<br>da EM durante o desenvolvimento|Nascidos vivos (com ou sem<br>alterações<br>congênitas,<br>como<br>acrania e curvatura póstero-medial||
|relatadas pelo programa clínico<br>de fingolimode em gestante.<br>Grupo<br>do<br>tratamento<br>com<br>fingolimode: 74 gestantes.<br>Todas as gestações prévias das<br>mulheres deste grupo não foram<br>expostas ao fingolimode.<br>8 não receberam fingolimode<br>durante o período uterino e<br>66 receberam fingolimode no<br>período uterino.|do programa de fingolimode na<br>EM. Todos os estudos tiveram<br>extensões opcionais em que as<br>pacientes receberam fingolimode.<br>Foi desenvolvido um programa<br>para avaliar os desfechos das<br>gestações que ocorreram durante a<br>realização desses ensaios clínicos,<br>com exposição ao fingolimode<br>durante período uterino até 31 de<br>outubro de 2011.|unilateral<br>da<br>tíbia),<br>abortos<br>espontâneos e abortos eletivos<br>(devido à tetralogia de Fallot,<br>morte<br>intrauterina,<br>gestação<br>ectópica/tubária,<br>gestação<br>não<br>desenvolvendo de acordo com o<br>padronizado).||
|Grupo placebo: 11 gestantes.|A<br>exposição<br>ao<br>fingolimode durante<br>o<br>período|||
|**Características dos pacientes**<br>**na linha de base:**|uterino<br>foi<br>definida<br>como<br>tratamento com fingolimode no|||
|O<br>total<br>de<br>exposição<br>ao<br>fingolimode para mulheres até<br>50<br>anos<br>de<br>idade<br>foi|momento da concepção ou em até<br>seis semanas antes da concepção.|||
|aproximadamente<br>7702|Critérios de elegibilidade:|||
|pacientes-ano,<br>com<br>25%<br>(n=1116/4444) das pacientes<br>tratadas por três anos ou mais.<br>Em contraste, a exposição ao<br>placebo e interferon beta-1a foi<br>de<br>aproximadamente<br>733<br>(n=437)<br>e<br>210<br>(n=211)|Critérios de inclusão para entrada<br>em<br>todos<br>os<br>estudos<br>de<br>fingolimode na EM consistiram<br>em mulheres com teste de gravidez<br>negativo antes da entrada no<br>estudo, que tiveram que usar duas<br>formas de contracepção efetiva|||
|pacientes-ano,<br>respectivamente.|durante o tratamento por 3 meses|||  
97  
|**ESTUDO**|**DELINEAMENTO**<br>após<br>a<br>descontinuação<br>do<br>medicamento do estudo.<br>No entanto, os investigadores<br>foram solicitados para informarem<br>eventuais<br>gestações<br>que<br>ocorressem durante os estudos,<br>apesar<br>dos<br>requerimentos<br>do<br>protocolo dos ensaios clínicos.<br>A data da concepção foi estimada<br>como duas semanas após a data da<br>última menstruação.|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|**Fragoso et al., 2013**<sup>118</sup>|Estudo<br>observacional<br>retrospectivo cujos dados foram|**Desfechos analisados:**|BOA|
|Participantes:152 gestações<br>(132 mulheres)<br>Grupo exposto aos MMCD: 61<br>gestações<br>Grupo controle: 89 gestações|coletados de registros médicos, de<br>quatro países (Brasil, México,<br>Argentina e Reino Unido).<br>Os dados foram coletados por<br>meio de um questionário enviado<br>aos médicos dispostos a participar<br>do estudo.<br>Critérios<br>de<br>elegibilidade<br>definidos:<br>1. pacientes com pelo menos uma<br>gravidez e com dados completos<br>após o diagnóstico de EM, de<br>acordo com o Critérios McDonald<br>2010;<br>2. para integrar o grupo controle a<br>paciente não deveria ser exposta a<br>nenhum MMCD por no mínimo<br>três meses antes da gravidez;<br>3. para integrar o grupo de<br>exposição a paciente deveria ter<br>no mínimo oito semanas de<br>exposição contínua a qualquer<br>MMCD no início da gravidez.|Os<br>desfechos<br>analisados<br>incluíram: idade em que os<br>sintomas de EM começaram, idade<br>gestacional, número de gravidezes<br>antes do diagnóstico da EM,<br>número de gestações após o<br>diagnóstico de EM, complicações<br>obstétricas,<br>complicações<br>neonatais,<br>taxas<br>de<br>recidiva<br>anterior, durante e após a gravidez,<br>e pontuação média do EDSS.||
|**Boskovic et al, 2005**<sup>119</sup><br>Participantes:|Trata-se de uma coorte cujas<br>participantes do estudo foram|**Desfechos analisados:**|MODERADA|  
98  
|**ESTUDO**|**DELINEAMENTO**|**DESFECHOS**|**QUALIDADE**|
|---|---|---|---|
|Total: 46 participantes|selecionadas dentre as mulheres do|Os<br>desfechos<br>analisados||
|1.<br>Mulheres expostas a IFN|Programa Motherisk, um serviço|incluíram: número de abortos||
|na gravidez: 16 participantes|de informações e aconselhamento|espontâneos, número de mortes||
|2.<br>Mulheres<br>que|sobre teratógenos no Hospital for|fetais, número de malformações||
|interromperam a IFN ou o|Sick Children, em Toronto.|graves, número de nascimentos||
|Copaxone<br>antes<br>da|Critérios<br>de<br>elegibilidade|prematuros, número de fumantes,||
|concepção: 12 participantes|definidos:|número de mães que relataram||
|3.<br>Pessoas<br>que|● mulheres que usaram a IFN-1b|ingestão de álcool, idade no||
|telefonavam para a linha de|na gravidez;|momento da gestação, peso antes||
|apoio: 18 participantes|● mulheres que interromperam a<br>IFN ou o Copaxone antes da<br>concepção;<br>● controles saudáveis.|da gravidez, ganho de peso na<br>gravidez, idade gestacional no<br>momento da ligação telefônica,<br>peso da criança ao nascer e idade<br>gestacional.|<br> <br> <br>|

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de morte fetal, apesar de três estudos reportarem resultado, não foi possível estimar o efeito nos grupos exposto vs. não exposto ( **Figura W** ). Avaliando os resultados reportados nos estudos individuais, identifica-se que nos estudos de Fragoso et al.<sup>112,118</sup> não houve incidência de morte fetal em nenhum dos grupos avaliados. Já o estudo de Boskovic et al<sup>119</sup> reporta maior risco de incidência do desfecho no grupo exposto, sem significância estatística [OR = 2,87 (IC95%: 0,11 – 74,28) p = 0,53].  
**Figura W -** _Forest-plot_ da meta-análise direta do desfecho de morte fetal para a comparação IFN-1b vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total _Events Total_Weight_M-H, Random, 95% Cl MH, Random, 95% Cl<br>Boskovic et al 2005 1 2 0 21 100.0% 2.87 (0.11, 74.28)<br>Fragoso et al 2013a 0 10 0 95 Not estimable<br>Fragoso et al 2013b o 1 0 87 Not estimable<br>Total (95% Cl) 50 203 100.0% 2.87 (0.11, 74.28]<br>Total events 1 0<br>Heterogeneity: Not applicable 0.01 a4 1 10 100<br>Testfor overall effect 2= 0.63 (P = 0.53) Favours (IFN-1b] Favours {ndo-expostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de incidência de aborto espontâneo, foram incluídos cinco estudos<sup>112,114,117–119</sup> (349 participantes). A meta-análise favoreceu o grupo não exposto à IFN-1b [OR = 2,58 (IC95%: 1,07 – 6,24) I² = 0%, p = 0,03], com menor risco de aborto espontâneo em comparação às gestantes expostas ao medicamento ( **Figura Y** ).  
99  
**Figura Y -** _Forest-plot_ da meta-análise direta do desfecho de aborto espontâneo para a comparação IFN-1b vs. não expostos  
<!-- Start of picture text -->
‘Study or Subgroup E xperimentalvents Total EventsControlTotal Weight _M-H,Odds Random, Ratio 95% Cl MH, OddsRandom, Ratio 95% Cl<br>Boskovic et al 2006 9 2 4 M 41.2% — 273(0.69,10.79)<br>Fragoso etal 2013a o 10 0 95 Notestimable<br>FragosoKarlsson etetalal 2013b 2014 oi) 174 21 89°WV 8.2%68% 1,000.78 (0.05,(0.03, 21.75]22.98)<br>Weberet al 2015 5 18 6 61 43.8% 3.53 (0.93, 13.36]<br>Total (95% Cl) 72 277 100.0% 2.58 [1.07, 6.24] <—-<br>Total events: 14 13<br>TestHeterogeneity:for overall Tau?effect= Z=0.00;2.11 Chi?(P== 1.07,0.03) df= 3 (P = 0.78), F=0% 0.01 Favourso4 (FN-1b] 1 Favours {ndo-expostos]10 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise do desfecho de número de abortos induzidos incluiu dois estudos<sup>114,117</sup> (306 participantes). Muito embora quatro estudos<sup>112,114,117,118</sup> tenham reportado esse desfecho, apenas dois contribuíram para a estimativa de efeito, uma vez que não foi possível estimar o OR para os estudos de Fragoso et al.<sup>112,118</sup> . O resultado obtido na meta-análise não favoreceu nenhum dos dois grupos [OR = 1,00 (IC95%: 0,07 – 13,49) I² = 67%, p = 1,00], uma vez que os estudos incluídos apresentaram sentidos de efeito divergentes, justificando também a alta heterogeneidade identificada ( **Figura Z** ).  
**Figura Z -** _Forest-plot_ da meta-análise direta do desfecho de aborto induzido para a comparação IFN-1b vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>‘Study or Subgroup Events Total Events Total Weight _M-H, Random, 95% Cl MH, Random, 95% Cl<br>FragosoFragoso et et al2013a 0 10 0 96 Notestimable<br>Karlsson etalal 20142013b 02 VF4 09 8711 43.9% 0.22Notestimable(0.02, 2.67]<br>Weber<br>et al 2015 30 4 3 61 56.1% 3.22 (0.60, 17.38)<br>Total (95% Cl) 52 254 100.0% 1.00 [0.07, 13.49]<br>Total events 5 12<br>Heterogeneity: Tau?= 2.41; Chit= 3.05, df= 1 (P = 0.08); P= 67% a1 01 1 10 100<br>Test for overall effect:Z= 0.00 (P= 1.00) Favours (IFN-1b] Favours [ndo-expostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de anomalias congênitas (dois estudos<sup>114,119</sup> , 236 participantes), a meta-análise não demonstrou diferença entre expostos e não expostos ao IFN-1b na incidência de malformações [OR = 1,18 (IC95%: 0,22 – 6,19) I² = 0%, p = 0,84] ( **Figura A1** ). Nesse caso também, embora quatro estudos tenham reportado o desfecho, apenas dois contribuíram para a estimativa de efeito, uma vez que nos estudos de Fragoso et al.<sup>118</sup> e Karlsson et al.<sup>117</sup> não foi relatado evento em nenhum dos grupos comparados.  
**Figura A1 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de anomalias congênitas ou malformações para a comparação IFN-1b vs. não  
expostos.  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total Events Total Weight _M-H, Random, 95% Cl MH, Random, 95% Cl<br>Boskovie et al 2005 2 23 1 2 448% 1.90 (0.16, 22.68)<br>Fragoso et al 2013b 0 1 0 a9 Not estimable<br>Karlsson et al 2014 0 (4 oo Not estimable<br>Weber<br>et al 2015 1 44 5 87 56.2% 0,80 (0.09, 7.45]<br>Total (95% Cl) 58 178 100.0% 1.18 [0.22, 6.19]<br>Total events 3 6<br>Heterogeneity: Taut= 0.00; ChF*= 0.26, df= 1 (P= 0.61); P= 0% oot 01 1 10 100<br>Test for overall effect:Z= 0.20 (P= 0.84) Favours (IFN-1b] Favours [ndo-expostos}<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
100

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de nascimentos prematuros (quatro estudos<sup>112,114,118,119</sup> , 323 participantes), não houve diferença estatisticamente significante na meta-análise entre expostos e não expostos à IFN-1b durante a gestação [OR = 1,39 (IC95%: 0,33 – 5,75) I² = 39%, p = 0,65] ( **Figura A2** ). Além de heterogeneidade moderada, a meta-análise apresentou imprecisão e inconsistência na estimativa de efeito para a incidência de prematuridade.  
**Figura A2 -** _Forest-plot_ da meta-análise direta do desfecho de nascimentos prematuros para a comparação IFN-1b vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total_Events Total_Weight_M-H, Random, 95% Cl MH, Random, 95% Cl<br>Boskovic etal 2005 2 23 3 21 30.0% 0.57 (0.09, 3.81)<br>Fragoso et al 2013a 2 10 3 95 295% 7.67 [1.11, 62.80) |<br>Fragoso et al 2013b oO 17 1 89 14.8% 1.69 (0.07, 43.10)<br>Weberet al 2015 1 13 8 65 25.7% 0.49 (0.06, 4.30)<br>Total (95% Cl) 63 260 100.0% 1.39 0.33,5.75]<br>Total events 5 16<br>TestHeterogeneity: for overall Tau?effect.= Z=0.82;0.45 Chi?(P==4.94,0.68) df= 3 (P= 0.18); F= 39% 0.01 Favourso4 (IFN-1b] 1 Favours Indo-expostos]10 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Não foi possível meta-analisar o desfecho de número de nascidos vivos. Apesar de dois estudos<sup>112,114</sup> reportarem esse dado, apenas em um foi estimado o efeito do uso de IFN-1b para esse desfecho ( **Figura A3** ), já que em Fragoso et al.<sup>112</sup> o número de eventos foi igual ao total de indivíduos de cada grupo. Dessa forma, embora nesse estudo não tenha sido identificada diferença entre expostos e não expostos, o estudo de Weber et al.<sup>114</sup> evidencia maior incidência de nascidos vivos entre os não-expostos, comparado às mulheres que usaram IFN-1b durante a gestação [OR = 0,25 (IC95%: 0,07 – 0,82) p = 0,02], com significância estatística.  
**Figura A3 -** _Forest-plot_ da meta-análise direta do desfecho de nascidos vivos para a comparação IFN-1b vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup: Events Total Events Total Weight M-H, Random, 95% Cl MH, Random, 95% Cl<br>Fragoso et al 2013a 10 10 95 95 Notestimable<br>Weber<br>et al 2015 14 57-4 100.0% 0.25 (0.07, 0.82] —i<br>Total (95% Cl) 31 159 100.0% 0.25 {0.07, 0.82] —=>_<br>Total events: 24 152<br>Heterogeneity: Not applicable bot o1 1 10 700<br>Test for overall effect Z= 2.29 (P= 0.02) Favours [ndo-expostos] Favours [IFN-1b]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de morte fetal, não foi possível realizar a meta-análise da comparação entre expostos e não expostos ao AG. Dos dois estudos<sup>112,118</sup> que reportavam esse desfecho, apenas em Fragoso et al.<sup>118</sup> o OR pôde ser estimado, uma vez que no outro estudo não foram relatados eventos nem entre expostos, nem entre não-expostos. Mesmo quando avaliado individualmente, Fragoso et al<sup>118</sup> não identificou diferença entre os grupos na incidência de morte fetal [OR = 6,63 (IC95%: 0,26 – 166,27) p = 0,25] ( **Figura A4** ).  
101  
**Figura A4 -** _Forest-plot_ da meta-análise direta do desfecho de morte fetal para a comparação AG vs. não expostos  
<!-- Start of picture text -->
‘Study or Subgroup E xperimentalvents Total EventsControlTotal Weight M-H,OddsRandom, Ratio95% Cl MH, OddsRandom, Ratio95% Cl<br>Fragoso et al 2013a 0 39 0 95 Notestimable<br>Fragosoet al 2013b 1 4 Oo 89 100.0% 6.63 (0.26, 166.27]<br>Total (95% Cl) 80 184 100.0% 6.63 [0.26, 166.27]<br>Total events 1 o<br>Heterogeneity: Not applicable<br>Test " . ot a4 i 10 100<br>for overall effect: 2= 1.15 (P= 0.25) Favours (glatiramer] Favours (ndo-expostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de incidência de aborto espontâneo, foram incluídos três estudos<sup>109,114,118</sup> (493 participantes). A metaanálise não demonstrou diferença entre os expostos e não expostos ao AG para esse desfecho [OR = 1,25 (IC95%: 0,54 – 2,85) I² = 0%, p = 0,60] ( **Figura A5** ). Não foi possível estimar o efeito relatado para esse desfecho em um dos estudos de Fragoso et al.<sup>112</sup> e, portanto, esse trabalho não contribuiu para a estimativa final da meta-análise.  
**Figura A5 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de aborto espontâneo para a comparação AG vs. não expostos  
<!-- Start of picture text -->
Study or Subgroup: E ventsxperimentalTotal EventsControlTotal Weight M-H,OddsRandom, Ratio95% Cl MH, OddsRandom, Ratio95% Cl<br>Fragoso et al 2013a o 39 o 96 Notestimable<br>Fragoso et al 20130 2 4 2 89 17.2% — 2.23 0.30, 16.42]<br>Herbstrittet al 2016 13 151 6 95 68.2% 1.40 (0.51, 3.81)<br>Weberet al 2016 1 26 6 61 14.6% 0.37 (0.04, 3.21]<br>Total (95% Cl) 257 340 100.0% 1.25 [0.54, 2.85]<br>Total events 16 14<br>TestHeterogeneity:for overall effect:Tau*= Z=0.00;0.52 ChiF=(P = 0.60)1.62, df= 2 (P = 0.45); = 0% bar Favoursry) (glatiramer] | Favours [néo-expostos)ib 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise do desfecho de casos de aborto induzido abrangeu dois estudos<sup>114,118</sup> e 195 participantes. O estudo de Fragoso et al 2013.<sup>112</sup> não contribui para a estimativa de efeito, uma vez que não foram relatados eventos em nenhum dos grupos. O resultado da meta-análise favoreceu os não-expostos ao AG, com significância estatística [OR = 5,19 (IC95%: 1,36 – 19,88) I²= 0%, p = 0,02], demonstrando menor incidência de abortos induzidos entre não-expostos quando comparados aos que utilizaram o medicamento ( **Figura A6** ).  
**Figura A6 -** _Forest-plot_ da meta-análise direta do desfecho de casos de aborto induzido para a comparação AG vs. não expostos.  
<!-- Start of picture text -->
‘Study or Subgroup E ventsxperimentalTotal EventsControlTotal Weight M-H,OddsRandom, Ratio95% Cl M.-H, Random,Odds Ratio95% Cl<br>Fragoso et al 2013a a 39 0 95 Notestimable<br>Fragoso etal 2013b 3004 0 87 202% 16.91 (0.80, 315.52}<br>Weber et al 2015 5 3 3 64 79.8% 3.91 (0.87, 17.58)<br>Total (95% Cl) 1 246 100.0% 5.19 [1.36, 19.88] —=__<br>Total events 8 3<br>TestHeterogeneity:for overall Tau*=effect Z2=0.00;° 2.40Chi#(P ==:0.70,0.02)df= 1 (P= 0.40), F= 0% 0.01 Favours01 (glatiramer] 1 Favours [ndo-expostos]10 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de incidência de anomalias congênitas foram incluídos cinco estudos<sup>109,113–115,118</sup> (1.039 participantes). A meta-análise não demonstrou diferença entre expostos e não expostos para esse desfecho [OR = 0,84 (IC95%: 0,35 – 2,01) I²= 6%, p = 0,70], não favorecendo, portanto, nenhum grupo ( **Figura A7** ). Ressalta-se, entretanto, que embora a heterogeneidade  
102  
estatística tenha se mostrado baixa, existem divergências na magnitude e sentido do efeito. Além disse, podemos identificar alta imprecisão na estimativa de efeito, evidenciada pelos amplos intervalos de confiança dos estudos incluídos, que reduzem a certeza da estimativa.  
**Figura A7 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de anomalias congênitas para a comparação AG vs. não expostos  
<!-- Start of picture text -->
‘Study or Subgroup E xperimentalvents Total EventsControlTotal Weight M-H,OddsRandom, Ratio95% Cl M.-H, Random,Odds Ratio95% Cl<br>HellwigFragoso etetal al 20122013b 21 41a 7o 2689 267%71% —6.631.83(0.31, (0.26, 166.27]7.65)<br>HerbstrittLuetal 2012et al2016 30 1616 1?6 oH?95 33.8%8.6% 1.32 0.30(0.07, (0.07,24.41]1.23]<br>Weber et al 2015 2 26 5 5? 23.8% 0.87 (0.16, 4.79)<br>Total (95% Cl) 265 774 100.0% 0.84 [0.35, 2.01]<br>Total events 8 35<br>TestHeterogeneity:for overall effect:Tau* = 0.06;Z = 0.38 Chi?(P==4.25,0.70)df= 4 (P = 0.37),F= 6% 0.01 Favours01 {glatiramer] Favours [ndo-expostos]710 700<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Foram incluídos quatro estudos<sup>109,112,114,118</sup> e 590 participantes na meta-análise da incidência de nascimentos prematuros entre expostos e não-expostos ao AG. Não houve diferença estatisticamente significante entre os grupos [OR = 0,57 (IC95%: 0,27 – 1,17) I²= 0%, p = 0,13]. Muito embora o estudo de Herbstritt et al.<sup>109</sup> apresente o maior peso para a estimativa de efeito, com maior representatividade amostral, magnitude de efeito e menor intervalo de confiança, a imprecisão dos demais estudos impactou fortemente no resultado da meta-análise ( **Figura A8** ).  
**Figura A8 -** _Forest-plot_ da meta-análise direta do desfecho de nascimentos prematuros para a comparação AG vs. não expostos  
<!-- Start of picture text -->
‘Study or Subgroup E xperimentalvents Total EventsControlTotal Weight _M-H,Odds Random, Ratio95% Cl M.-H, Random,Odds Ratio95% Cl<br>Fragoso et al 2013a 1 39 3 95 10.1% 0.81 (0.08, 8.01]<br>Fragoso<br>et al 20130 1 4 1 89 68% 2.20 0.13, 36.07)<br>Herbstrittet al2016 a 151 12 95 71.5% 0.54 (0.23, 1.29]<br>Weberet al 2015 1 26 8 55 11.6% 0.24 (0.03, 2.07]<br>Total (95% Cl) 256 334 100.0% 0.57 (0.27, 1.17]<br>Total events 14 24<br>Heterogeneity:<br>Test for overall effect:Tau = 0.00;Z= 1.53Chit=(P=1.61,0.13)df= 3 (P = 0.66); F= 0% aT Favoursa4 [glatiramer] Favours [ndo-expostos]7h ad<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Para o desfecho de nascidos vivos, foram incluídos dois estudos<sup>109,114</sup> (326 participantes) para a comparação entre expostos e não-expostos ao AG, uma vez que não foi possível estimar o efeito nos estudos de Fragoso et al.<sup>112</sup> e Hellwig et al.<sup>113</sup> . Não foi identificada diferença estatisticamente significante no número de nascidos vivos entre expostos e não-expostos ao AG  
[OR = 0,63 (IC95%: 0,30 – 1,32) I²= 0%, p = 0,22] ( **Figura A9** ).  
**Figura A9 -** _Forest-plot_ da meta-análise direta do desfecho de nascidos vivos para a comparação AG vs. não expostos  
<!-- Start of picture text -->
‘Study or Subgroup E ventsxperimentalTotal EventsControlTotal Weight M-H,OddsRandom, Ratio95% Cl M.-H, Random,Odds Ratio95% Cl<br>Fragoso et al 2013a 39 39 96 95 Notestimable<br>Hellwig etal 2012 4 4 216 216 Notestimable<br>WeberHerbstrittet al2016 136 161 88 95 61.7% 0.72 (0.28, 1.84]<br>et al 2015 2% 38 87 64 38.3% ©—081 (0.16, 1.68)<br>Total (95% Cl) 262 470 100.0% 0.63 [0.30, 1.32]<br>Total events 241 456<br>TestHeterogeneity:for overall effectTau*= Z=0.00;1.22 Chi*(P == 0.20,0.22) df=1 (P = 0.66), F= 0% 0.01 Favoursa1[ndo-expostos] H Favours [glatiramer]10 700<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
103

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise da incidência de aborto espontâneo entre mulheres expostas ao natalizumabe _versus_ expostas a outros MMCD incluiu 2 estudos<sup>111,116</sup> e 709 participantes. Não foi identificada diferença na chance de ocorrência de aborto espontâneo entre as duas exposições (natalizumabe e outros MMCD) [OR = 1,09 (IC95%: 0,54 – 2,21) I²= 40%, p = 0,80] ( **Figura A10** ). A heterogeneidade estatística foi moderada, principalmente em função dos estudos incluídos apresentarem diferentes sentidos da estimativa de efeito, diminuindo a certeza no resultado.  
**Figura A10 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de aborto espontâneo para a comparação natalizumabe vs. outros MMCD  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total_Events Total Weight MH, Random, 95% Cl MH, Random, 95% Cl<br>Ebrahimi et al 2015 8 78 29 438 460% 1.61 (0.71, 3.67]<br>Nguyen et al 2019 17-98 2095 54.0% 0.79 (0.38, 1.61]<br>Total (95% Ci) 176 533 100.0% 1.09 [0.54, 2.21]<br>Total events 6 49<br>TestHeterogeneity: for overall Tau?effect= 2=0.10;0.25 Chi?= (P= 1.66, 0.80) df= 1 (P= 0.20), P= 40% 0.01 Favoursa1{natalizumabe] 1 Favours [outros10 MTs} 100<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
Assim como para o desfecho de aborto espontâneo, a meta-análise de casos de aborto induzido<sup>111,116</sup> não demonstrou diferença estatisticamente significante entre expostos ao natalizumabe e expostos a outros MMCD [OR = 1,61 (IC95%: 0,30 – 8,59) I²= 82%, p = 0,58] ( **Figura A11** ). Foi identificada elevada heterogeneidade na meta-análise, uma vez que os estudos incluídos apresentavam diferentes sentidos na estimativa de efeito; além de haver também importante imprecisão no resultado, evidenciada pelo amplo intervalo de confiança da estimativa de efeito e pela pouca sobreposição entre os intervalos de confiança dos estudos individuais.  
**Figura A11 -** _Forest-plot_ da meta-análise direta do desfecho de abortos induzidos para a comparação natalizumabe vs. outros MMCD  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup _Events Total _Events Total Weight_M.H, Random, 95% Cl MH, Random, 95% Cl<br>Ebrahimi et al 2015 13 78 24 438 56.1% 3.46 [1.67, 7.12] ——<br>Nguyen et al 2019 4 98 6 95 44.9% 0.63 (0.17, 2.31]<br>Total (95% Cl) 176 533 100.0% 1.61 10.30, 8.59]<br>Total events 17 30<br>TestHeterogeneity: for overall Tau?=effect: Z=1.19; 0.56Chit= (P = 0.58)5.14, df=1 (P= 0.02); F= 81% bo Favoursoh [natalizumabe] Favours [outros+b DMTS] Tod!<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **8.1     Rastreio da tuberculose latente** -->
A meta-análise da incidência de nascimentos prematuros incluiu dois estudos<sup>111,116</sup> e 659 participantes. Não foi identificada diferença na chance de ocorrência de prematuridade entre os filhos de mães expostas ao natalizumabe _versus_ expostas a outros MMCD [OR = 0,82 (IC95%: 0,41 – 1,63) I²= 32%, p = 0,57] ( **Figura A12** ). A heterogeneidade estatística para essa meta-análise foi moderada, em função de os estudos apresentarem diferentes sentidos e magnitudes na estimativa de efeito.  
104  
**Figura A12 -** _Forest-plot_ da meta-análise direta do desfecho de nascimentos prematuros para a comparação natalizumabe vs. outros MMCD  
<!-- Start of picture text -->
Experimental Control Odds Ratio Oudds Ratio<br>Study or Subgroup Events _Total_Events _Total_Weight_M.H, Random, 95% Cl MH, Random, 95% Cl<br>Ebrahim et al 2015 16 «78 «87 438 «67.9% 1.04 (0.57, 1.89)<br>Nguyen etal 2018 6 76 10 67 321% 0.49 (0.17, 1.43]<br>Total (95% Cl) 154 505 100.0% 0.82 (0.41, 1.63]<br>Total events 2 97<br>Heterogeneity T= 008, One= 148, = 1 (P= 0.23), P= 32% bor oh + 7b Tod!<br>est for overall effect Z= 0.57 (P= 0.57) Favours [natalizumabe] Favours [outros DMTs}<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **a) Morte fetal** -->
Dos três estudos selecionados que reportavam o desfecho de morte fetal entre mães expostas a algum MMCD _versus_ nãoexpostas, apenas dois<sup>118,119</sup> (187 participantes) foram incluídos na meta-análise. O estudo de Fragoso et al.<sup>112</sup> não contribui para a estimativa de efeito, pois não foram relatados eventos em nenhum dos grupos avaliados. Não foi identificada diferença estatisticamente significante na incidência de morte fetal entre expostos e não-expostos aos MMCDs [OR = 3,80 (IC95%: 0,39 – 37,52) I²= 0%, p = 0,25] ( **Figura A13** ). Cabe ressaltar, entretanto, que há importante imprecisão na estimativa de efeito, que pode reduzir a certeza no resultado encontrado.  
**Figura A13 -** _Forest-plot_ da meta-análise direta do desfecho de morte fetal para a comparação uso de MMCD vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events _Total_Events Total Weight _M-H, Random, 95% Cl MH, Random, 95% Cl<br>Boskovic et al 2005 rs) O21 49.4% 2.87 (0.11, 74.28]<br>FragosoFragoso etet alal 201362013a 01 4354 0O 9589 50.6% 5.02 (0.20,Notestimable125.42]<br>Total (95% Cl) 126 205 100.0% 3.80 {0.39, 37.52]<br>Total events 2 0<br>Heterogeneity. Tau*= 0.00; . Chi*= 0.06, df= 1 (P= 0.81); P= 0%<br>Testfor overall effect Z= 1.14 (P= 0.25): ’ 01 Favours4  [expostos] 1 Favours [ndo-expostos]10 100)<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **b) Aborto espontâneo** -->
Para o desfecho de incidência de aborto espontâneo, foram incluídos 6 estudos<sup>109,114,116–119</sup> (820 participantes). O estudo de Fragoso et al.<sup>112</sup> , apesar de reportar o desfecho, não contribui para a estimativa de efeito por não relatar evento em nenhum dos grupos. Não foi identificada diferença estatisticamente significante entre mães expostas e não-expostas aos MMCDs na chance de ocorrência de aborto espontâneo [OR = 1,17 (IC95%: 0,74 – 1,87) I²= 0%, p = 0,50] ( **Figura A14** ).  
**Figura A14 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de aborto espontâneo para a comparação uso de MMCD vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup __Events _Total_Events Total Weight_M-H, Random, 95% Cl MH, Random, 95% Cl<br>Boskovic et<br>Ebrahimi al2005 9 23 4 21 115% 2.731069, 10.79)<br>Fragoso et et al 2015 17 98 = 20 95 41.9% 0.79 (0.38, 1.61]<br>Fragoso et alal2013a20136 02 4354 02 9589 55% — 1.67Not (0.23, estimable12.24]<br>Herbstritt<br>Karlsson etet alal 20142016 13°9 15170 61 9511 21.5%4.6% = 1.481.40 10.17,(0.51,12.94)3.81]<br>Weber<br>et al 2015 6 62 6 Bt 15.1% 41.20 (0.36, 3.96]<br>Total (95% Cl) 497 467 100.0% 1.47 (0.74, 1.87]<br>Total events 56 39<br>Heterogeneity. Tau*= 0.00; q Chi*= 2.92, df= 5 (P= 0.71); P= 0%<br>Favours [expostos] Favours [ndo-expostos]<br>Test for overall effect. Z= 0.67 (P= 0.50) : ’ 001 4 1 10 100)<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
105

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **c) Aborto induzido** -->
A meta-análise do desfecho de casos de aborto induzido entre mães expostas e não-expostas aos MMCDs abrangeu quatro estudos<sup>114,116–118</sup> e 528 participantes. Assim como no desfecho de aborto espontâneo, o estudo de Fragoso et al.<sup>112</sup> , apesar de reportar o desfecho, não contribui para a estimativa de efeito por não relatar evento em nenhum dos grupos. Não foi identificada diferença estatisticamente significante na incidência de abortos induzidos entre os grupos [OR = 1,10 (IC95%: 0,20 – 6,03) I²= 76%, p = 0,91] ( **Figura A15** ). A alta heterogeneidade estatística identificada pode ser atribuída à divergência no sentido das estimativas de efeito dos estudos individuais. Além de heterogeneidade, ressalta-se também imprecisão nos resultados, evidenciada tanto pelos amplos intervalos de confiança nas estimativas individuais, quanto pela pouca sobreposição entre os ICs dos estudos.  
**Figura A15 -** _Forest-plot_ da meta-análise direta do desfecho de casos de aborto induzido para a comparação uso de MMCD vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup __Events Total Events Total Weight _M-H, Random, 95% Cl MH, Random, 95% Cl<br>Ebrahimi et al 2015 4 98 6 95 288% 0.63 (0.17, 2.31]<br>Fragoso et al 20134 o 49 0 95 Not estimable<br>Fragoso et al 20136 3 54 0 87 16.7% 11.89 (0.60, 234.88]<br>Karlsson et al 2014 26070 9 11 26.4% 0.13<br>Weberet al 2015, 8 42 3 61 281% 3.62 (0.88,(0.03,14.02] 0.66] ——_——<br>Total (95% CI) 323 349 100.0% 1.10 [0.20, 6.03]<br>Total events a 18<br>Heterogeneity: Tau*= 2.17; Chi?= 12.40, df= 3 (P = 0.006);<br>Test for overall effect Z= 0.11 (P = 0.31) F= 76% bor Favoursoh [expostos] t Favours {ndo-expostos]tb Too!<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **d) Anomalias congênitas ou malformações** -->
Para o desfecho de incidência de anomalias congênitas nos filhos de mães expostas aos MMCDs foram incluídos oito estudos<sup>109,113–119</sup> e 1.364 participantes na meta-análise. Não foi identificada diferença estatisticamente significante na chance de ocorrência de malformações entre expostos e não-expostos aos MMCDs [OR = 0,82 (IC95%: 0,42 – 1,60) I²= 0%, p = 0,57] ( **Figura A16** ). É importante, entretanto, destacar que existe imprecisão na estimativa de efeito, com amplos intervalos de confiança e estudos com diferentes magnitudes e sentidos do efeito.  
**Figura A16 -** _Forest-plot_ da meta-análise direta do desfecho de incidência de anomalias congênitas para a comparação uso de MMCD vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study<br>or Subgroup __Events Total Events Total Weight M-H, Random, 95% Cl MLH, Random, 95% Cl<br>Boskovic et<br>Ebrahimi al2008 2° 23 1 21 7.2% 1.90 (0.16, 22.68]<br>Fragoso etetalal 2013b 2015 41 7784 3O 6989 18.9%4.3% — §.021.21(0.20,(0.26, 5.59]125.42]<br>Hellwig<br>et al 2012 20 41 7 216 171% 1.53 (0.31, 7.65]<br>Herbstritt<br>Karlsson et al2016 3 181 6 95 22.3% 0.30 (0.07, 1.23}<br>Luetal 2012et al 2014 2o «707 17O 31711 46%5.5% 0.840.40(0.04,(0.02,18.63]6.87]<br>Weberet al 2015, 3 42 5 57 201% 0.64 (0.14, 2.81]<br>Total (95% Cl) 489 875 100.0% 0.82 [0.42, 1.60]<br>Total events 17 39<br>Heterogeneity: Tau*= 0.00; Chi¥= 4.79, df= 7 (P = 0.69); F= 0% bor 04 t 1b 700<br>Test for overall effect: Z= 0.57 (P = 0.57) Favours [expostos] Favours {ndo-expostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.  
106

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: e) **Nascimento prematuro** -->
A meta-análise do desfecho de nascimentos prematuros em mães expostas aos MMCDs incluiu 6<sup>109,112,114,116,118,119</sup> estudos e 825 participantes. O resultado encontrado não favorece nenhum dos dois grupos avaliados, com um intervalo de confiança limítrofe para a significância estatística [OR = 0,58 (IC95%: 0,34 – 1,00) I²= 0%, p = 0,05] ( **Figura A17** ).  
**Figura A17 -** _Forest-plot_ da meta-análise direta do desfecho de nascimentos prematuros para a comparação AG vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total_Events Total Weight M-H, Random, 95% Cl M-H, Random, 95% Cl<br>Boskovic et<br>Ebrahimi et alal20062015 62. 7623 103 671 257%82% 0.570.49 (0.09,(0.17,3.81]1.43]<br>Fragoso et al 2013a 3 49 3 95 11.0% 2,000.39, 10.30)<br>Fragoso et al 20136 1 84 1 87 38% 1,620.10, 26.49]<br>Herbstritt et al 2016 1181 12,98 39.7% 0.54 (0.23, 1.29]<br>Weber et al 2015 2 82 8 55 115% 0.23 (0.05, 1.16]<br>Total (95% Cl) 405 420 100.0% 0.58 [0.34, 1.00] =><br>Total events 25 37<br>Heterogeneity: Tau*= 0.00; Chi*= 4.07, df= 5 (P = 0.54); P= 0% ta 4 + ri] Tad<br>Test for overall effect: Z= 1.97 (P = 0.05) Favours [expostos] Favours [ndo-expostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **f) Nascidos vivos** -->
A meta-análise do desfecho de nascidos vivos entre mães expostas aos MMCDs incluiu três estudos<sup>109,114,116</sup> e 555 participantes. Os estudos de Fragoso et al.<sup>112</sup> e Hellwig et al.<sup>113</sup> não contribuíram para a estimativa de efeito, pois não relataram evento nem no grupo exposto, nem no não-exposto aos MMCDs. Não foi identificada diferença estatisticamente significante no número de nascidos vivos entre expostos e não-expostos aos MMCDs [OR = 0,77 (IC95%: 0,36 – 1,67) I²= 59%, p = 0,51] ( **Figura A18** ). A alta heterogeneidade estatística pode ser justificada pelas diferenças entre os estudos incluídos, tanto no sentido quanto na magnitude de efeito. Há, também, pouca sobreposição entre os intervalos de confiança dos estudos individuais.  
**Figura A18 -** _Forest-plot_ da meta-análise direta do desfecho de nascidos vivos para a comparação AG vs. não expostos  
<!-- Start of picture text -->
Experimental Control Odds Ratio Odds Ratio<br>Study or Subgroup Events Total _Events Total Weight _MLH, Random, 95% Cl MH, Random, 95% Cl<br>Ebrahimi et al 2015 77 986395 AOI 1.38 (0.71, 2.67]<br>Fragoso et al 2013a 49 499595 Not estimable<br>HellwigHerbstritet etalal2012 2016 136a 1514 «= 216«8B 216«95 30.9% 0.72Not (0.28, estimable1.84]<br>Weber<br>et al 2015 39 «82 STA 28.9% 0.37 (0.13, 1.01]<br>Total (95% Cl) 391 565 100.0% 0.77 (0.36, 1.67]<br>Total events 342 525<br>Heterogeneity: Tau<br>Test = 0.27; ChiF= 4.85, df= 2 (P = 0.09); = 69% bo a4 + tb 70<br>for overall effect Z= 0.66 (P = 0.51) Favours [ndo-expostos] Favours fexpostos]<br><!-- End of picture text -->  
Fonte: Centro Colaborador do SUS (CCATES/UFMG), em 2020.

---

<!-- METADADOS: doenca: Esclerose Múltipla | secao: **f) Nascidos vivos** -->
A avaliação da qualidade dos estudos encontra-se resumida no Quadro I.  
**Quadro I -** Avaliação da qualidade metodológica dos estudos incluídos  
|**Parâmetros***|**Seleção**|**Comparabilidade**|**Desfecho**|**Qualidade****|
|---|---|---|---|---|
|**Geiss et al, 2018**<sup>107</sup>|☆☆☆|☆☆|☆☆|BOA|  
107  
|**Parâmetros***|**Seleção**|**Comparabilidade**|**Desfecho**|**Qualidade****|
|---|---|---|---|---|
|**Coyle et al, 2014**<sup>108</sup>|☆☆|☆☆|☆☆☆|BOA|
|**Herbstrittet al, 2015**<sup>109</sup>|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Salminem et al, 2010**<sup>110</sup>|☆☆|☆|☆☆|MODERADA|
|**Nguyen et al, 2019**<sup>111</sup>|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Fragoso et al, 2013a**<sup>112</sup>|☆☆☆|☆☆|☆☆|BOA|
|**Hellwig et al, 2012**<sup>113</sup>|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Weber et al, 2009**<sup>114</sup>|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Lu et al, 2012**<sup>115</sup>|☆☆☆☆|☆☆|☆☆☆|BOA|
|**Ebrahimi et al, 2015**<sup>116</sup>|☆☆☆|☆☆|☆☆☆|BOA|
|**Karlsson et al, 2014**<sup>117</sup>|☆☆☆|☆☆|☆☆|BOA|
|**Fragoso et al, 2013**<sup>118</sup>|☆☆☆|☆☆|☆☆|BOA|
|**Boskovic et al, 2005**<sup>119</sup>|☆☆|☆☆|☆☆|MODERADA|  
*Um estudo pode receber no máximo uma estrela para uma das subcategorias de “seleção” e “desfecho” (1 ao a e 6 ao 7), e no máximo duas estrelas para a subcategoria de “comparabilidade” (item 5).  
****** Boa qualidade: 3 ou 4 estrelas em seleção E 1 ou 2 estrelas em comparabilidade E 2 ou 3 estrelas em desfecho; Moderada: 2 estrelas em seleção E 1 ou 2 estrelas em comparabilidade E 2 ou 3 estrelas em desfecho.  
108  
**4. REFERÊNCIAS**  
1. HAUSER, S. L.; GOODIN, D. _Esclerose Múltilpla e Outras Doenças Desmielinizantes. In: BRAUNWALD, E.et al. Medicina Interna de Harisson. 18. ed. Porto Alegre: Artmed Editora_ . (2013).  
2. COMINI-FROTA et al. Guideline for multiple sclerosis treatment in Brazil: Consensus from the neuroimmunology scientific department of the Brazilian academy of Neurology. _Arq. Neuropsiquiatr._ **75** , 57–65 (2017).  
3. GAJOFATTO, A; BENEDETTI, M. Treatment strategies for multiple sclerosis: When to start, when to change, when to stop? _World J. Clin. Cases_ **3** , 545 (2015).  
4. ANNIBALI et al. IFN-β and multiple sclerosis: From etiology to therapy and back. _Cytokine Growth Factor Rev._ **26** , 221–228 (2015).  
5. Multiple Sclerosis International Federation (MSIF). _Atlas da Esclerose Múltipla_ . (2013).  
6. OLIVEIRA, E. & SOUZA, N. Esclerose Múltipla. _Rev. Neurociências_ **6** , 114–118 (1998).  
7. PEREIRA et al. Prevalence of multiple sclerosis in Brazil: A systematic review. _Mult. Scler. Relat. Disord._ **4** , 572–579 (2015).  
8. NETTER, F. H; ROYDEN, J. (Ed. ). Esclerose Múltipla e Outros Transtornos Autoimunes do sistema Nervoso Central. in _In: NETTER, H. et al. Coleção Netter de Ilustrações Médicas: Sistema Nervoso -Cérebro -Parte I. 2. ed.Rio de Janeiro: Elsevier._ 247–272 (2014).  
9. MACHADO et al. _Recomendações Esclerose Multipla_ . _São Paulo: Omnifarma_ (2012).  
10. BRASIL. Secretaria de Atenção à Saúde. _Portaria n_<sup>_o_</sup> _391, de 5 de maio de 2015. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Esclerose Múltipla. Brasília: Diário Oficial da União._ (2015).  
11. BRASIL. Ministério da Saúde. _Diretriz Metodológica de Elaboração de Diretrizes Clínicas. Brasília._ (2016).  
12. Brasil. Ministério da Saúde. Secretaria da Ciência Tecnologia E Insumos Estratégicos. Departamento De Ciência E Tecnologia. _Diretrizes Metodológicas: elaboração de revisão sistemática e metanálise de ensaios clínicos randomizado_ . vol. 80 (2012).  
13. NICE. National Institute for Health and Care Excellence. Multiple sclerosis in adults: management. _NICE Clin. Guidel._ 28 (2014).  
14. SCHÜNEMANN et al. GRADE handbook for grading quality of evidence and strength of recommendations. Updated October 2013. The GRADE Working Group, 2013. Available fromguidelinedevelopment.org/handbook. (2019).  
15. GRADEpro GDT: GRADEpro Guideline Development Tool [Software]. McMaster University, 2015 (developed by Evidence Prime, Inc.). Available from gradepro.org. (2019).  
16. MCDONALD et al. Recommended diagnostic criteria for multiple sclerosis: Guidelines from the International Panel on the Diagnosis of Multiple Sclerosis. _Ann. Neurol._ **50** , 121–127 (2001).  
17. POLMAN et al. Diagnostic criteria for multiple sclerosis: 2010 Revisions to the McDonald criteria. _Ann. Neurol._ **69** , 292–302 (2011).  
18. POLMAN et al. Diagnostic Criteria for Multiple Sclerosis: 2005 Revisions to the “McDonald Criteria”. _Am. Neurol. Assoc._ **58** , 7 (2005).  
19. Thompson, A. J. _et al._ Diagnosis of multiple sclerosis: 2017 revisions of the McDonald criteria. _Lancet Neurol._ **17** , 162– 173 (2018).  
20. KURTZKE, J. Rating neurologic impairment in multiple sclerosis: an expanded disability status scale (EDSS). _Neurology._ **Nov;33** , 1444–52. (1983).  
21. LUBLIN, FD; REINGOLD, S. Defining the clinical course of multiple sclerosis: Results of an international survey. _Neurology_ **84** , 963 (1996).  
109  
22. LUBLIN et al. Defining the clinical course of multiple sclerosis: The 2013 revisions. _Neurol. Am. Acad. Neurol._ **83** , (2014).  
23. COSTELLO et al. _THE USE OF DISEASE-MODIFYING THERAPIES IN MULTIPLE SCLEROSIS: Principles and Current Evidence. A Consensus Paper by the Multiple Sclerosis Coalition_ . (2019).  
24. MARQUES et al. Brazilian consensus for the treatment of multiple sclerosis: Brazilian academy of neurology and brazilian committee on treatment and research in multiple sclerosis. _Arq. Neuropsiquiatr._ **76** , 539–554 (2018).  
25. TABANSKY et al. Advancing drug delivery systems for the treatment of multiple sclerosis. _Immunol. Res._ **63** , 58–69 (2015).  
26. KALINCIK, T. Multiple Sclerosis Relapses: Epidemiology, Outcomes and Management. A Systematic Review. _Neuroepidemiology_ **44** , 199–214 (2015).  
27. CORTESE et al. Evidence-based guideline update: Plasmapheresis in neurologic disorders: Report of the Therapeutics and Technology Assessment Subcommittee of the American Academy of Neurology. _Neurology_ **76** , 294–300 (2011).  
28. KNUTH et al. Interferons Transcriptionally Up-Regulate MLKL Expression in Cancer Cells. _Neoplasia (United States)_ **21** , 74–81 (2019).  
29. REDER, A; FENG, X. How type I interferons work in multiple sclerosis and other diseases: Some unexpected mechanisms. _J. Interf. Cytokine Res._ **34** , 589–599 (2014).  
30. ZADEH et al. Mechanism and adverse effects of multiple sclerosis drugs: a review article. Part 2. _Int J Physiol Pathophysiol Pharmacol_ **11** , 105–114 (2019).  
31. CCATES (Centro Colaborador do SUS). Boletim Esclerose Múltipla. Volume 6. (2016).  
32. TEVA Pharmaceuticals LTDA. COPAXONE (acetato de glatirâmer)®. (2014).  
33. BRASIL. Ministério da Saúde. _Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Relatório de recomendação: Acetato de Glatirâmer 40 mg no tratamento da Esclerose Múltipla Remitente Recorrente_ . http://conitec.gov.br/images/Relatorios/2018/Relatorio_Glatiramer_EMRR.pdf (2018).  
34. PROD’HOMME, T; SAMVIL, S. The evolving mechanisms of action of glatiramer acetate. _Cold Spring Harb. Perspect. Med._ **9** , (2019).  
35. HONG et al. Induction of CD4+CD25+ regulatory T cells by copolymer-I through activation of transcription factor Foxp3. _Proc. Natl. Acad. Sci. U. S. A._ **102** , 6449–6454 (2005).  
36. JEE et al. CD4+CD25+ regulatory T cells contribute to the therapeutic effects of glatiramer acetate in experimental autoimmune encephalomyelitis. _Clin. Immunol._ **125** , 34–42 (2007).  
37. TRAUB et al. Dimethyl fumarate impairs differentiated B cells and fosters central nervous system integrity in treatment of multiple sclerosis. _Brain Pathol._ **29** , 640–657 (2019).  
38. HAAS et al. Glatiramer acetate improves regulatory T-cell function by expansion of naive CD4+CD25+FOXP3+CD31+ T-cells in patients with multiple sclerosis. _J. Neuroimmunol._ **216** , 113–117 (2009).  
39. WEBER et al. Type II monocytes modulate T cell-mediated central nervous system autoimmune disease. _Nat. Med._ **13** , 935–943 (2007).  
40. AHARONI et al. Glatiramer acetate reduces Th-17 inflammation and induces regulatory T-cells in the CNS of mice with relapsing-remitting or chronic EAE. _J. Neuroimmunol._ **225** , 100–111 (2010).  
41. SCOTT, L. Teriflunomide: A Review in Relapsing–Remitting Multiple Sclerosis. _Drugs_ **79** , 875–886 (2019).  
42. KLOTZ et al. Teriflunomide treatment for multiple sclerosis modulates T cell mitochondrial respiration with affinitydependent effects. _Sci. Transl. Med._ **11** , (2019).  
43. GENZYME A Sanofi Company. _AUBAGIO® teriflunomida_ . (2016).  
44. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de  
110  
Recomendação: Teriflunomida para primeira linha de tratamento da Esclerose Múltipla Remitente Recorrente. Brasília -. (2017).  
45. SPENCER et al. Reduction of CD8 + T lymphocytes in multiple sclerosis patients treated with dimethyl fumarate. _Neurol. Neuroimmunol. NeuroInflammation_ **2** , e76 (2015).  
46. MICHELL-ROBINSON et al. Effects of fumarates on circulating and CNS myeloid cells in multiple sclerosis. _Ann. Clin. Transl. Neurol._ **3** , 27–41 (2016).  
47. SCHULZE-TOPPHOFF et al. Dimethyl fumarate treatment induces adaptive and innate immune modulation independent of Nrf2. _Proc. Natl. Acad. Sci. U. S. A._ **113** , 4777–4782 (2016).  
48. KORNBERG et al. Dimethyl fumarate targets GAPDH and aerobic glycolysis to modulate immunity. _Nature_ **453** , 449– 453 (2018).  
49. LINKER et al. Fumaric acid esters exert neuroprotective effects in neuroinflammation via activation of the Nrf2 antioxidant pathway. _Brain_ **134** , 678–692 (2011).  
50. BIOGEN Brasil Produtos Farmacêuticos Ltda. TECFIDERATM fumarato de dimetila. (2015).  
51. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Fumarato de dimetila no tratamento da Esclerose Múltipla Remitente Recorrente após falha com betainterferona ou glatirâmer. 1–99 (2017).  
52. VOLPI et al. Preclinical discovery and development of fingolimod for the treatment of multiple sclerosis. _Expert Opin. Drug Discov._ **14** , 1199–1212 (2019).  
53. NOVARTIS Biociências LTDA. GILENYA® cloridrato de fingolimode. (2015).  
54. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de Recomendação: Fingolimode no tratamento da esclerose múltipla remitente recorrente após falha terapêutica com betainterferona ou glatirâmer. (2017).  
55. ENGELHARDT, B; KAPPOS, L. Natalizumab: Targeting α4-integrins in multiple sclerosis. _Neurodegener. Dis._ **5** , 16– 22 (2007).  
56. BIOGEN Brasil Produtos Farmacêuticos Ltda. TYSABRI® natalizumabe. (2018).  
57. IANNETA et al. Dynamic changes of MMP-9 plasma levels correlate with JCV reactivation and immune activation in natalizumab-treated multiple sclerosis patients. _Sci. Rep._ **9** , 1–9 (2019).  
58. BIOGEN Brasil Produtos Farmacêuticos Ltda. AVONEX® betainterferona 1a (publicada em 29/09/2022).  
59. MERCK S.A. Rebif® betainterferona-1a recombinante. 1–12 (29/04/2021).  
60. BAYER S.A. Betaferon® betainterferona 1b. (2016).  
61. ASPEN Pharma Indústria Farmacêutica Ltda. IMURAN® azatioprina. 1–8 (2014).  
62. WYETH. SOLU-MEDROL® succinato sódico de metilprednisolona. 1–6 (2018).  
63. JACOBS et al. Intramuscular Interferon beta-1a therapy initiated during a first demyelinating event in Multiple Sclerosis. _N. Engl. J. Med._ **343** , 898–904 (2000).  
64. COMI et al. Effect of early interferon treatment on conversion to definite multiple sclerosis: A randomised study. _Lancet_ **357** , 1576–1582 (2001).  
65. COMI et al. Effect of glatiramer acetate on conversion to clinically definite multiple sclerosis in patients with clinically isolated syndrome (PreCISe study): a randomised, double-blind, placebo-controlled trial. _Lancet_ **374** , 1503–1511 (2009).  
66. COMI et al. Comparison of two dosing frequencies of subcutaneous interferon beta-1a in patients with a first clinical demyelinating event suggestive of multiple sclerosis (REFLEX): A phase 3 randomised controlled trial. _Lancet Neurol._ **11** , 33–41 (2012).  
67. KAPPOS et al. Treatment with interferon beta-1b delays conversion to clinically definite and McDonald MS in patients  
111  
with clinically isolated syndromes. _Neurology_ **67** , 1242–1249 (2006).  
68. MILLER et al. Oral teriflunomide for patients with a fi rst clinical episode suggestive of multiple sclerosis (TOPIC): a randomised, double-blind, placebo-controlled, phase 3 trial. _Lancet Neurol 2014; 13 977–86 Publ._ doi:10.1016/S14744422(14)70191-7.  
69. ZIEMSSEN et al. Optimizing therapy early in multiple sclerosis: An evidence-based view. _Mult. Scler. Relat. Disord._ **4** , 460–469 (2015).  
70. BANWELL et al. Safety and tolerability of interferon beta-1b in pediatric multiple sclerosis. _Neurology_ **66** , 472–476 (2006).  
71. TENEMBAUM, SN; SEGURA, M. Interferon beta-1a treatment in childhood and juvenile-onset multiple sclerosis. 511– 514 (2006).  
72. GHEZZI et al. Long-term results of immunomodulatory treatment in children and adolescents with multiple sclerosis: The Italian experience. _Neurol. Sci._ **30** , 193–199 (2009).  
73. ALROUGHANI et al. Relapse occurrence in women with multiple sclerosis during pregnancy in the new treatment era. _Neurology_ **90** , e840–e846 (2018).  
74. CONFAVREUX et al. Rate of pregnancy-related relapse in multiple sclerosis. _N. Engl. J. Med._ **339** , 285–291 (1998).  
75. LORENZI, AR; FORD, H. Multiple sclerosis and pregnancy. _Neurol. Pregnancy Clin. Manag._ 214–221 (2012) doi:10.1201/b14988.  
76. FINKELSZTEIN et al. What can we really tell women with multiple sclerosis regarding pregnancy? A systematic review and meta-analysis of the literature. _BJOG An Int. J. Obstet. Gynaecol._ **118** , 790–797 (2011).  
77. Bio-Manguinhos. Betainterferona 1a Bio-Manguinhos Solução Injetável 22 mcg ou 44 mcg. 1–19 (2020).  
78. CAI et al. Pretreatment data is highly predictive of liver chemistry signals in clinical trials. _Drug Des. Devel. Ther._ **6** , 359–369 (2012).  
79. ANDRADE et al. EASL Clinical Practice Guidelines: Drug-induced liver injury. _J. Hepatol._ **70** , 1222–1261 (2019).  
80. ANNUNZIATA et al. Early synthesis and correlation of serum anti-thyroid antibodies with clinical parameters in multiple sclerosis. _J. Neurol. Sci._ **168** , 32–36 (1999).  
81. COLES et al. Pulsed monoclonal antibody treatment and autoimmune thyroid disease in multiple sclerosis. **354** , 1691– 1695 (1999).  
82. DURELLI et al. Thyroid function and autoimmunity during interferon β-1b treatment: A multicenter prospective study. _J. Clin. Endocrinol. Metab._ **86** , 3525–3532 (2001).  
83. KARNI, A; ABRAMSKY, O. Association of MS with thyroid disorders. _Neurology_ **53** , 883–885 (1999).  
84. SEYFERT et al. Multiple sclerosis and other immunologic diseases. _Acta Neurol. Scand._ **81** , 37–42 (1990).  
85. WALTHER, EU; HOHFELD, R. Multiple sclerosis: Side effects of interferon beta therapy and their management. _Neurology_ **53** , 1622–1627 (1999).  
86. BAYAS, A; RIECKMANN, P. Managing the adverse effects of interferon-β therapy in multiple sclerosis. _Drug Saf._ **22** , 149–159 (2000).  
87. MOSES, H; BRANDES, D. Managing adverse effects of disease-modifying agents used for treatment of multiple sclerosis. _Curr. Med. Res. Opin._ **24** , 2679–2690 (2008).  
88. LINKER, R; HAGHIKIA, A. Dimethyl fumarate in multiple sclerosis: latest developments, evidence and place in therapy. _Ther. Adv. Chronic Dis._ **7** , 198–207 (2016).  
89. COHEN et al. Oral fingolimod or intramuscular interferon for relapsing multiple sclerosis. _N. Engl. J. Med._ **362** , 402– 415 (2010).  
90. BRASIL. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos Esplanada. Relatório de  
112  
Recomendação: Natalizumabe 300mg (Tysabri®) para Esclerose Múltipla Remitente Recorrente em segunda linha de tratamento. (2013).  
91. Sormani, M. P. _et al._ Scoring treatment response in patients with relapsing multiple sclerosis. _Mult. Scler. J._ **19** , 605– 612 (2013).  
92. Huisman, E. _et al._ Systematic literature review and network meta-analysis in highly active relapsing-remitting multiple sclerosis and rapidly evolving severe multiple sclerosis. _BMJ Open_ **7** , 1–10 (2017).  
93. Shea, B. J. _et al._ AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non- randomised studies of healthcare interventions, or both. _BMJ_ (2017).  
94. Barbin et al. Comparative efficacy of fingolimod vs natalizumab: A French multicenter observational study. _Neurology_ **87** , 1066 (2016).  
95. Baroncini, D. _et al._ Natalizumab versus fingolimod in patients with relapsing-remitting multiple sclerosis nonresponding to first-line injectable therapies. _Mult. Scler._ **22** , 1315–1326 (2016).  
96. Curti, E. _et al._ The real-world effectiveness of natalizumab and fingolimod in relapsing-remitting multiple sclerosis. An Italian multicentre study. _Mult. Scler. Relat. Disord._ **33** , 146–152 (2019).  
97. Gajofatto, A., Bianchi, M. R., Deotto, L. & Benedetti, M. D. Are natalizumab and fingolimod analogous second-line options for the treatment of relapsing-remitting multiple sclerosis? A clinical practice observational study. _Eur. Neurol._ **72** , 173–180 (2014).  
98. Koch-Henriksen, N., Magyari, M., Sellebjerg, F. & Soelberg Sørensen, P. A comparison of multiple sclerosis clinical disease activity between patients treated with natalizumab and fingolimod. _Mult. Scler._ **23** , 234–241 (2017).  
99. Preziosa, P. _et al._ Effects of Natalizumab and Fingolimod on Clinical, Cognitive, and Magnetic Resonance Imaging Measures in Multiple Sclerosis. _Neurotherapeutics_ (2019) doi:10.1007/s13311-019-00781-w.  
100. Prosperini, L. _et al._ Real-world effectiveness of natalizumab and fingolimod compared with self-injectable drugs in nonresponders and in treatment-naïve patients with multiple sclerosis. _J. Neurol._ **264** , 284–294 (2017).  
101. Totaro et al. Efficacy of Natalizumab and Fingolimod in Relapsing Remitting Multiple Sclerosis in Real World Clinical Setting. _J. Neurol. Neurophysiol._ **06** , (2015).  
102. Frisell, T. _et al._ Comparative analysis of first-year fingolimod and natalizumab drug discontinuation among Swedish patients with multiple sclerosis. _Mult. Scler._ **22** , 85–93 (2016).  
103. Braune, S., Lang, M. & Bergmann, A. Second line use of Fingolimod is as effective as Natalizumab in a German outpatient RRMS-cohort. _J. Neurol._ **260** , 2981–2985 (2013).  
104. Kalincik, T. _et al._ Switch to natalizumab versus fingolimod in active relapsing-remitting multiple sclerosis. _Ann. Neurol._ **77** , 425–435 (2015).  
105. Wells, G. _et al._ The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analysis [manuals and scales]. (2008).  
106. Guyatt, G. H. _et al._ GRADE : an emerging consensus on rating quality of evidence and strength of recommendations. _BMJ_ **336** , (2008).  
107. Geissbühler et al. Evaluation of pregnancy outcomes in patients with multiple sclerosis after fingolimod exposure. _Ther Adv Neurol Disord_ **11** , 1–9 (2018).  
108. Coyle, P. K. _et al._ Final results from the Betaseron (interferon β-1b) Pregnancy Registry: A prospective observational study of birth defects and pregnancy-related adverse events. _BMJ Open_ **4** , 1–8 (2014).  
109. Herbstritt, S. _et al._ Glatiramer acetate during early pregnancy: A prospective cohort study. _Mult. Scler._ **22** , 810–816 (2015).  
110. Salminen, H. J., Leggett, H. & Boggild, M. Glatiramer acetate exposure in pregnancy: Preliminary safety and birth  
113  
outcomes. _J. Neurol._ **257** , 2020–2023 (2010).  
111. Nguyen, A. L. _et al._ Incidence of pregnancy and disease-modifying therapy exposure trends in women with multiple sclerosis: A contemporary cohort study. _Mult. Scler. Relat. Disord._ **28** , 235–243 (2019).  
112. Fragoso, Y. D. _et al._ Long-term effects of exposure to disease-modifying drugs in the offspring of mothers with multiple sclerosis: A retrospective chart review. _CNS Drugs_ **27** , 955–961 (2013).  
113. Hellwig, K., Haghikia, A., Rockhoff, M. & Gold, R. Multiple sclerosis and pregnancy: Experience from a nationwide database in Germany. _Ther. Adv. Neurol. Disord._ **5** , 247–253 (2012).  
114. Weber-Schoendorfer, C. & Schaefer, C. Multiple sclerosis, immunomodulators, and pregnancy outcome: A prospective observational study. _Mult. Scler._ **15** , 1037–1042 (2009).  
115. Lu et al. Perinatal outcomes in women with multiple sclerosis exposed to disease-modifying drugs. _Mult. Scler. J._ **18** , 460–467 (2012).  
116. Ebrahimi, N. _et al._ Pregnancy and fetal outcomes following natalizumab exposure in pregnancy. A prospective, controlled observational study. _Mult. Scler. J._ **21** , 198–205 (2015).  
117. Karlsson, G. _et al._ Pregnancy outcomes in the clinical development program of fingolimod in multiple sclerosis. _Neurology_ **82** , 674–680 (2014).  
118. Fragoso, Y. D. _et al._ The effects of long-term exposure to disease-modifying drugs during pregnancy in multiple sclerosis. _Clin. Neurol. Neurosurg._ **115** , 154–159 (2013).  
119. Boskovic, R., Wide, R., Wolpin, J., Bauer, D. J. & Koren, G. The reproductive effects of beta interferon therapy in pregnancy: A longitudinal cohort. _Neurology_ **65** , 807–811 (2005).  
114  
**APÊNDICE 3 - HISTÓRICO DE ALTERAÇÕES DO PCDT**  
|**Portaria**<br>**ou**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Número**<br>**do**<br>**Relatório**|**Principais alterações**|**Incorporadas ou alterado o uso**<br>**(ampliação e restrição) no SUS**|**Não incorporadas ao SUS**|
|Relatório<br>de<br>Recomendação nº<br>908/2024|Incorporação no SUS do<br>medicamento<br>cladribina<br>oral para alta atividade da<br>doença|Cladribina oral para tratamento de<br>pacientes com esclerose múltipla<br>remitente-recorrente altamente ativa<br>[Relatório Técnico nº 855/2023 e<br>Portaria SECTICS/MS nº 62/2023]|<br>Não possui|
|Relatório<br>de<br>Recomendação nº<br>839/2023|Alteração na bula das<br>betainterferonas<br>e<br>inclusão do rastreio de<br>tuberculose latente|Não possui|Ofatumumabe em primeira linha de<br>terapia modificadora do curso da doença<br>para o tratamento da esclerose múltipla<br>recorrente<br>[Relatório Técnico nº 747/2022 e<br>Portaria SCTIE/MS nº 58/2022]<br>Cladribina oral no tratamento de<br>pacientes<br>com<br>esclerose<br>múltipla<br>remitente-recorrente altamente ativa<br>[Relatório Técnico nº 748/2022 e<br>Portaria SCTIE/MS nº 66/2022]|
|Relatório<br>de<br>Recomendação<br>Nº<br>680/2022<br>[Portaria<br>Conjunta<br>SCTIE/SAES/MS<br>nº 1/2022]|Incorporação no SUS do<br>medicamento<br>alentuzumabe para alta<br>atividade da doença|Alentuzumabe para tratamento de<br>pacientes com esclerose múltipla<br>remitente<br>recorrente<br>com<br>características<br>comparáveis<br>aos<br>critérios<br>de<br>tratamento<br>com<br>natalizumabe<br>conforme<br>o<br>estabelecido<br>no<br>PCDT<br>[Relatório Técnico nº 609/2021 e<br>Portaria SCTIE/MS nº 15/2021]|<br>Não possui|
|Relatório<br>de<br>Recomendação<br>Nº<br>582/2021<br>[Portaria<br>Conjunta|Atualização de todo o<br>conteúdo do PCDT, com<br>destaque<br>para<br>a<br>incorporação no SUS do<br>medicamento fumarato de<br>dimetila<br>e<br>para<br>a<br>|Fumarato<br>de<br>dimetila<br>para<br>tratamento de primeira linha da<br>esclerose<br>múltipla<br>remitente<br>recorrente<br>[Relatório Técnico nº 505/2019 e<br>Portaria SCTIE/MS nº 65/2019]|Ocrelizumabe<br>para<br>tratamento<br>de<br>pacientes<br>adultos<br>com<br>esclerose<br>múltipla remitente-recorrente (EMRR)<br>como alternativa ou contraindicação ao<br>natalizumabe<br>[Relatório Técnico nº 561/2020 e<br>Portaria SCTIE/MS nº 41/2020]|
|SCTIE/SAES/MS<br>nº 03/2021]|ampliação de uso do<br>medicamento<br>natalizumabe para alta<br>atividade da doença|Natalizumabe no tratamento de<br>pacientes com esclerose múltipla<br>remitente-recorrente<br>com<br>alta<br>atividade<br>de<br>doença||  
115  
|**Portaria**<br>**ou**||**Tecnologias avaliadas pela Conitec**||
|---|---|---|---|
|**Número**<br>**do**<br>**Relatório**|**Principais alterações**|**Incorporadas ou alterado o uso**<br>**(ampliação e restrição) no SUS**|**Não incorporadas ao SUS**|
|||[Relatório Técnico nº 569/2020 e<br>Portaria SCTIE/MS nº 49/2020]||
||||Ocrelizumabe<br>para<br>tratamento<br>da<br>esclerose<br>múltipla<br>primariamente<br>[Relatório Técnico nº 446/2019 e<br>Portaria SCTIE nº 21/2019]|
|Relatório<br>de<br>Recomendação<br>Nº<br>455/2019<br>[Portaria<br>Conjunta|Atualização de todo o<br>conteúdo do PCDT, com<br>destaque<br>para<br>a<br>incorporação no SUS do<br>di  d|Acetato de Glatirâmer 40mg no<br>tratamento da esclerose múltipla<br>remitente<br>recorrente<br>[Relatório Técnico nº 418/2018 e|Ocrelizumabe para o tratamento de<br>formas<br>recorrentes<br>de<br>Esclerose<br>Múltipla<br>[Relatório Técnico nº 447/2019 e<br>Portaria SCTIE nº 22/2019]|
|SCTIE/SAES nº<br>7/2019]|mecamento acetato e<br>glatirâmer|Portaria SCTIE/MS nº 90/2018]|Alentuzumabe<br>no<br>tratamento<br>da<br>esclerose múltipla remitente recorrente<br>após falha terapêutica a duas ou mais<br>terapias<br>[Relatório Técnico nº 417/2018 e<br>Portaria SCTIE/MS nº 87/2018]|
||Atualização de todo o<br>conteúdo do PCDT, com<br>destaque<br>para<br>a<br>Incorporação no SUS dos<br>medicamentos<br>fingolimode<br>para<br>o|Fingolimode<br>no<br>tratamento<br>da<br>esclerose<br>múltipla<br>remitente<br>recorrente após falha terapêutica<br>com betainterferona ou glatirâmer<br>[Relatório Técnico nº 257/2017 e<br>Portaria SCTIE/MS nº 14/2017]|Fumarato de dimetila no tratamento da<br>esclerose múltipla remitente-recorrente<br>após<br>a<br>1ª<br>falha<br>terapêutica|
|Relatório<br>de<br>Recomendação<br>Nº<br>357/2018<br>[Portaria<br>Conjunta|<br> <br> <br> <br>tratamento de esclerose<br>múltipla<br>remitente<br>recorrente<br>após<br>falha<br>terapêutica<br>com<br>betainterferona<br>ou|Teriflunomida para primeira linha<br>de tratamento da esclerose múltipla<br>remitente<br>recorrente<br>[Relatório Técnico nº 259/2017 e<br>Portaria SCTIE/MS nº 19/2017]|[Relatório Técnico<br>nº<br>226/2016<br>e<br>Portaria SCTIE/MS nº 33/2016]|
|<br>SCTIE/SAS/MS<br>nº 10/2018]|<br> <br>glatirâmer,<br>além<br>da<br>incorporação no SUS dos<br>medicamentos<br>teriflunomida e fumarato<br>de<br>dimetila<br>para<br>o<br>tratamento de pacientes<br>adultos<br>com<br>esclerose<br>múltipla|Fumarato de dimetila no tratamento<br>da esclerose múltipla remitente<br>recorrente<br>após<br>falha<br>com<br>betainterferona<br>ou<br>glatirâmer<br>[Relatório Técnico nº 286/2017 e<br>Portaria SCTIE/MS nº 39/2017]<br>Restringir uso de Betainterferonas<br>no tratamento da esclerose múltipla<br>remitente-recorrente<br>(EMRR)|Alentuzumabe<br>no<br>tratamento<br>da<br>esclerose múltipla remitente recorrente<br>após<br>falha<br>terapêutica<br>com<br>betainterferona<br>ou<br>glatirâmer<br>[Relatório Técnico nº 307/2017 e<br>Portaria SCTIE/MS nº 43/2017]|  
116  
|**Portaria**<br>**ou**||**Tecnologias avaliadas pela Conitec**||||
|---|---|---|---|---|---|
|**Número**<br>**do**<br>**Relatório**|**Principais alterações**|**Incorporadas ou alterado o uso**<br>**(ampliação e restrição) no SUS**|**Não incorporadas ao**|**SUS**||
|||[Relatório Técnico nº 216/2016 e<br>Portaria SCTIE/MS nº 44/2017]||||
|Portaria SAS/MS<br>nº 391/2015|Atualização de todo o<br>conteúdo do PCDT|Não possui|Não possui|||
|Portaria SAS/MS<br>nº 1.505/ 2014|Atualização de todo o<br>conteúdo do PCDT|Fingolimode para o tratamento da<br>esclerose<br>múltipla<br>[Relatório Técnico nº 113/2014 e<br>Portaria Nº 24/2014]|Natalizumabe 300mg<br>múltipla<br>[Relatório Técnico nº 7<br>Nº 42/2013]|para<br>2/2013|esclerose<br>e Portaria|
|Portaria SAS/MS<br>nº 1.323/ 2013|Atualização de todo o<br>conteúdo do PCDT|Não possui|Fingolimode<br>para<br>esclerose<br>[Relatório Técnico nº 0<br>Nº 25/2012]|tratam<br>4/2012|ento<br>da<br>múltipla<br>e Portaria|
||Criação<br>do<br>Protocolo|||||
|Portaria SAS/MS<br>nº 493/ 2010|Clínico<br>e<br>Diretrizes<br>Terapêuticas - Esclerose<br>Múltipla|Não possui|Não possui|||  
117

---

