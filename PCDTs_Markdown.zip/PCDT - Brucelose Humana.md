<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Geral -->
<!-- Start of picture text -->
x<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **PORTARIA SECTICS/MS Nº 22, DE 12 DE MAIO DE 2025** -->
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Brucelose Humana.  
A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.798, de 28 de novembro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Fica aprovado, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas da Brucelose Humana.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico:https://www.gov.br/conitec/pt-br.  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **INTRODUÇÃO** -->
A brucelose humana é uma doença emergente e reemergente de distribuição global, causada por cocobacilos gram-negativos intracelulares facultativos do gênero _Brucella_ sp.<sup>1,2</sup> . Dentre as principais espécies de _Brucella_ patogênicas para o homem se encontram a _Brucella abortus_ ( _B. abortus_ ) _,_ que infecta principalmente bovinos _, a Brucella melitensis_ ( _B. melitensis_ ) _,_ cujos principais hospedeiros são pequenos ruminantes, como cabras e ovelhas e a _Brucella suis_ ( _B. suis_ ) _,_ que tem como hospedeiro preferencial os suínos. Também associada à doença humana está a _Brucella canis_ ( _B. canis_ ), preferencialmente relacionada à doença em cães domésticos<sup>3,4</sup> .  
Trata-se de uma das zoonoses mais prevalentes no mundo, endêmica principalmente em países da Ásia, especialmente no Oriente Médio, além da África, América Central e do Sul, Bacia do Mediterrâneo e Caribe<sup>2,5</sup> . A estimativa da carga desta doença, que compartilha vários dos qualificadores de doenças negligenciadas, é limitada pelo grande contingente de casos assintomáticos, pela dificuldade de confirmação diagnóstica e subnotificação dos casos existentes<sup>1,4</sup> .  
Estimativas projetadas com base em dados reportados entre 2014 e 2018 pela Organização Mundial de Saúde Animal (OMSA) e Banco Mundial, indicam incidência global anual entre 1,6 e 2,1 milhões de novos casos por ano<sup>6</sup> . No Brasil, a incidência da brucelose humana é pouco conhecida e, possivelmente, subestimada<sup>7</sup> . Alguns estados do país, como Santa Catarina<sup>8</sup> , Paraná<sup>9</sup> , Tocantins<sup>10</sup> , Rondônia<sup>11</sup> , Minas Gerais<sup>12</sup> , Mato Grosso<sup>7</sup> e Mato Grosso do Sul<sup>7</sup> já instituíram a notificação compulsória para todos os casos suspeitos. De acordo com o estudo que avaliou casos notificados ao Sistema de Informação de Agravos de Notificação (SINAN) nas 27 unidades federativas do Brasil entre 2014 e 2018, foram registrados 3.612 casos suspeitos de brucelose humana, dos quais 25% foram confirmados<sup>7</sup> . Os casos foram notificados principalmente na região Sul (22%), com predomínio de homens (75%) e em associação à exposição ocupacional (53%). Pacientes entre 30 e 39 anos de idade foram os mais envolvidos. Ainda, metade dos pacientes eram moradores da zona rural e 68% dos casos eram autóctones do município de residência, sendo esse o provável local de infeção. Os casos que evoluíram para cura somaram 63% do total. Observouse um crescimento de notificações de 29% entre 2014 e 2015, 47% entre 2015 e 2016, e 24% entre 2017 e 2018, estimando-se um coeficiente de incidência anual em 0,11 caso a cada 100,000 habitantes<sup>7</sup> .  
Em outro estudo avaliando casos notificados em Santa Catarina e submetidos à estratégia de investigação estadual, o mesmo perfil epidemiológico para a doença foi confirmado<sup>13</sup> . Já no Estado do Paraná, a incidência estimada no período de 2014 a 2017 variou entre 0,20 e 0,59 casos por 100.000 habitantes<sup>14</sup> . Estes dados confirmam o Brasil como um país endêmico para brucelose humana.  
A transmissão da brucelose para humanos ocorre predominantemente por meio do contato direto ou indireto com animais infectados e seus produtos contaminados<sup>15</sup> . O contato direto com animais, como cabras, ovelhas, gado, porcos e cães, pode resultar em transmissão, já que podem excretar _Brucella_ sp. em secreções reprodutivas, urina e leite. O consumo de produtos contaminados, como leite cru, manteiga, sorvetes, cremes e queijo não pasteurizado, incluindo queijo fresco, é uma das principais vias de aquisição da brucelose já que as bactérias _Brucella_ sp. podem sobreviver nestes produtos não tratados por meses<sup>3,16</sup> . O consumo de carne é menos frequentemente associado à infecção, mas apresentam risco potencial quando ingeridos crus ou  
2  
mal-cozidos<sup>3</sup> . A transmissão de humano para humano, embora descrita como relatos de casos isolados, pode ocorrer através de várias vias, incluindo a barreira placentária, lactação, relações sexuais e contato com tecidos como sangue e medula óssea<sup>17</sup> .  
As espécies de _Brucella_ podem sobreviver por longos períodos na lama, produtos do parto (como fetos abortados e placentas), carcaças de animais, esterco, poeira, água, solo, entre outras. Desta forma, a inalação de aerossóis contaminados com bactérias de _Brucella_ sp.  em suspensão em ambientes de criação intensiva de animais é tida como importante via de contaminação. A infecção por contato da pele lesionada, mucosas ou conjuntiva com fômites contaminados também pode acontecer, especialmente durante procedimentos veterinários ou em situações de manipulação de tecidos animais infectados, como animais abortados, placentas, órgãos e fluidos corporais como sangue. Trabalhadores de estabelecimentos agropecuários, veterinários, trabalhadores de matadouros e da indústria de processamento de carne estão sujeitos a essa exposição ocupacional<sup>3</sup> .  
Os trabalhadores envolvidos com o cuidado e vacinação de rebanhos, os laboratoristas que manipulam amostras humanas contaminadas e aqueles que manuseiam amostras de animais contaminados são os mais sujeitos à exposição acidental no ambiente de trabalho<sup>18,19</sup> . O risco de uma exposição clinicamente significativa aumenta exponencialmente durante e após incubação do material em meios sólidos e líquidos<sup>20</sup> . Procedimentos bacteriológicos de rotina, como homogeneização de tecidos, centrifugação e vórtex de suspensões bacterianas também podem resultar em dispersão e contaminação do ambiente e de profissionais de laboratório<sup>20</sup> . Apesar de ser menos comum, há registros de transmissões vertical, neonatal<sup>21–23</sup> , via aleitamento materno, sexual<sup>23,24</sup> e pela doação de órgãos e transfusão de sangue<sup>25</sup> . A infecção intrauterina por _Brucella sp_ . pode resultar em complicações graves, como aborto espontâneo, parto prematuro<sup>26–28</sup> , transmissão congênita da doença para o recém-nascido<sup>29</sup> , além de múltiplas complicações sistêmicas e orgânicas para mãe e filho<sup>30</sup> .  
A prevenção da brucelose em humanos inclui medidas eficazes e articuladas de controle em animais, e práticas de higiene rigorosas na produção e manipulação de alimentos de origem animal. A estratégia de prevenção mais eficaz é a eliminação da infecção nos animais, sendo a vacinação de bovinos, caprinos e ovinos recomendada especialmente em áreas com alta prevalência. Adicionalmente, é importante a disseminação de conhecimento sobre as vias de transmissão da infecção e prevenção entre as populações sob risco, com ênfase nas medidas de segurança alimentar como pasteurização adequada do leite e derivados. Também é fundamental disseminar o uso de medidas de segurança ocupacional, seja no manuseio de animais e seus derivados, através do uso de técnicas seguras para o processamento da carne, correto manejo e descarte de animais e seus tecidos, e na manipulação de amostras clínicas em laboratório, com o uso de barreiras físicas e equipamentos de proteção individual (EPI), inclusive durante a vacinação<sup>29</sup> .  
Clinicamente, a brucelose se manifesta como uma doença de curso as vezes agudo, mas muitas vezes insidioso tendendo a evolução crônica, com padrão variável de febre, e sintomas inespecíficos como mal-estar, sudorese, mialgia, entre outros<sup>31</sup> . Sintomas adicionais incluem perda de peso, artralgia, cefaleia, dor lombar, fadiga, anorexia, tosse e alterações emocionais com padrão depressivo<sup>32,33</sup> . O período de incubação (desde a aquisição até as manifestações clínicas) costuma ser de duas a quatro semanas; ocasionalmente, pode durar vários meses. Caso não tratada, a doença pode cursar com quadros prolongados (forma localizada/crônica) com duração de meses e até anos para os quais os achados físicos são variáveis e inespecíficos como o acometimento osteoarticular, geniturinário, neurológico e cardiovascular<sup>34–36</sup> .  
Devido à natureza ampla dos sinais e sintomas, ainda que associado ao vínculo epidemiológico, a confirmação laboratorial torna-se crucial. A detecção de _Brucella_ sp. em meio de cultivo a partir de diferentes espécimes clínicos é o padrão-ouro, porém, trata-se de uma técnica  
3  
laboriosa que requer tempo prolongado e infraestrutura laboratorial com nível de biossegurança 3 para sua realização<sup>37,38</sup> . Portanto, métodos imunológicos e moleculares, como aglutinação em placa e em tubo, ensaio imunoenzimático (ELISA) e reação em cadeia da DNA polimerase (PCR), vêm sendo amplamente empregados visando auxiliar na confirmação da doença<sup>39</sup> . Para o tratamento, geralmente são utilizados esquemas combinados de antimicrobianos<sup>40</sup> de diversas classes, dentre elas as tetraciclinas (doxiciclina e minociclina), aminoglicosídeos (amicacina, gentamicina e estreptomicina), quinolonas (ciprofloxacino), além de rifampicina, sulfametoxazol + trimetoprima a e ceftriaxona<sup>41</sup> .  
A identificação da doença em seu estágio inicial e o reconhecimento de casos de exposição acidental à _Brucella_ sp. devem ter encaminhamento ágil e adequado para o atendimento na Atenção Primária a Saúde, visando a um melhor resultado terapêutico e prognóstico dos casos. Ainda, a vigilância ativa dos casos é outra estratégia fundamental para contenção da brucelose humana no Brasil. Este Protocolo reúne as evidências disponíveis para orientar profissionais de saúde, pacientes, familiares e grupos de risco quanto ao diagnóstico, tratamento, monitoramento e profilaxia pós-exposição da brucelose humana.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **METODOLOGIA** -->
O processo de desenvolvimento desse PCDT seguiu recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>42</sup> que preconiza o uso do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ). O GRADE classifica a qualidade da evidência ou o grau de certeza dos resultados disponíveis na literatura em quatro categorias (muito baixo, baixo, moderado e alto)<sup>43</sup> . Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **CLASSIFICAÇÃO INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- A23 - Brucelose  
- A23.0 - Brucelose por _Brucella melitensis_  
- A23.1 - Brucelose por _Brucella abortus_  
- A23.2 - Brucelose por _Brucella suis_  
- A23.3 - Brucelose por _Brucella canis_  
- A23.8 - Outras bruceloses  
- A23.9 - Brucelose não especificada

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **DEFINIÇÕES** -->
Este Protocolo considera as seguintes definições:  
**Caso suspeito sintomático:** paciente com quadro clínico compatível com brucelose caracterizada por febre acompanhada por sinais e sintomas constitucionais tais como calafrios,  
4  
mialgia, sudorese, artralgia, astenia, fraqueza e hepatoesplenomegalia ou comprometimento localizado de sistemas-órgãos (artrite, orquite, endocardite, meningite, entre outros), associada a vínculo epidemiológico representado por consumo de alimentos contaminados (principalmente leite e derivados não pasteurizados como queijo, manteiga, nata e iogurte), exposição a animais infectados ou exposição acidental a material orgânico ou enriquecido com _Brucella_ sp.  
**Caso suspeito assintomático** : pessoa que não apresenta sinais e sintomas e que tenha sido exposta, seja pela ingestão de produtos (leite e derivados não pasteurizados) ou contato de risco com animais ou materiais biológicos contaminados com _Brucella_ sp.  
**Diagnóstico provável de brucelose:** caso suspeito sintomático acompanhado por positividade nos testes sorológicos realizados em duas plataformas distintas (Rosa Bengala e ELISA total ou IgG) ou detecção de DNA de _Brucella_ sp. em ensaio PCR.  
**Diagnóstico definitivo de brucelose:** caso suspeito sintomático confirmado por crescimento de _Brucella_ sp. em cultura ou por elevação de 4 vezes no título de teste sorológico (Rosa Bengala ou ELISA total ou IgG), em duas amostras diferentes, com intervalo igual ou superior a 2 semanas entre os exames.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Caso descartado:** -->
**I) Casos investigados com mais de 3 meses de sinais e sintomas:** testes sorológicos (Rosa Bengala e ELISA total ou IgG) discordantes ou negativos, associados a PCR não detectável, quando este for realizado;  
**II) Casos investigados com menos de 3 meses de sinais e sintomas:** testes sorológicos (Rosa Bengala e ELISA total ou IgG) discordantes ou negativos em duas testagens (com intervalo mínimo de 2 semanas entre elas).  
**Caso indefinido:** caso que não preencha os critérios de qualquer das situações anteriormente descritas.  
**Cura inicial:** desaparecimento de sinais e sintomas atribuídos à doença após tratamento específico.  
**Falha terapêutica/ausência de resposta:** persistência de sinais e/ou sintomas atribuíveis à doença após 6 semanas de início do tratamento.  
**<mark>Recidiva:</mark>** <mark>reaparecimento de sinais e/ou sintomas atribuíveis à brucelose, após período</mark> assintomático, até 12 meses após o fim do tratamento.  
5  
**Soroconversão recente:** condição apresentada por paciente suspeito assintomático, exposto à fonte contaminada por _Brucella_ sp. e que apresente critério sorológico de infecção recente (viragem sorológica ou elevação de título) tal como descrito a seguir:  
**I) Viragem sorológica:** positividade dos testes Rosa Bengala e Elisa (total ou IgG), no caso de ambos os testes serem negativos ou um positivo e outro negativo na avaliação basal (se a condição basal for positividade nos dois testes, esse critério não é aplicável).  
**II) Elevação de título:** elevação de quatro vezes ou mais no título de qualquer um dos testes sorológicos em uma das avaliações de seguimento após a exposição.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo pacientes com suspeita ou diagnóstico da brucelose humana e pessoas expostas acidentalmente à _Brucella_ sp.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo casos complicados de brucelose, tais como formas localizadas em sistema nervoso central, sistema cardiovascular, ocular, osteomielite, ou pacientes imunossuprimidos tais como aqueles vivendo com o vírus da imunodeficiência humana (HIV), transplantados ou usuários de imunossupressores. Essas situações devem ser abordadas de forma individualizada, em serviços de saúde e por profissionais especializados.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **CASOS ESPECIAIS** -->
Os casos especiais em geral requerem avaliação em serviço especializado, uma vez que podem requerer condutas definidas caso a caso, em função da complexidade.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **7.1. Gestantes e crianças** -->
A infecção por _Brucella_ sp. pode levar a complicações obstétricas como abortamento, parto prematuro, infecção intrauterina ou morte fetal<sup>44</sup> . A inespecificidade dos sinais e sintomas da brucelose aumenta a possibilidade de diagnóstico incorreto ou tardio, com risco de progressão para complicações. Assim, o reconhecimento e início precoce da terapia antimicrobiana são essenciais para redução do risco de desfechos obstétricos desfavoráveis, infecção neonatal e contaminação de profissionais da saúde envolvidos no parto incluindo aqueles responsáveis pela limpeza e desinfecção das salas de parto e centros obstétricos.  
Embora a brucelose seja menos comum entre crianças<sup>45</sup> , a população pediátrica é considerada especialmente suscetível devido à maior vulnerabilidade do sistema imunológico e à exposição a alimentos de risco<sup>46–48</sup> . Além disso, as crianças podem estar particularmente em risco, pois podem adotar animais recém-nascidos ou doentes como animais de estimação. Assim, a doença tende a ter um impacto mais significativo nesse grupo, sendo recomendado que as crianças  
6  
sejam protegidas do contato com animais recém-nascidos ou que tenham abortado ou parido recentemente<sup>3</sup> .  
Os principais sintomas clínicos da brucelose em crianças incluem febre, que frequentemente aparece isoladamente<sup>49</sup> , além de dor abdominal e mialgia<sup>50</sup> . O envolvimento ósseo e articular, incluindo artrite, espondilite e osteomielite, são as principais complicações da brucelose em crianças, com frequências que variam entre 6,4% e 73,5%<sup>51</sup> . Esplenomegalia e hepatomegalia podem estar presentes, mas ocorrem com menor frequência<sup>50</sup> . Em gestantes, a febre permanece como o sintoma mais frequente da brucelose. No que diz respeito às manifestações clínicas nos sistemas corporais afetados, o sistema osteoarticular é o mais comumente comprometido, apresentando sintomas como dor, edema e artralgia nas articulações, além de fadiga, astenia, fraqueza e dor lombar<sup>44</sup> .  
Apesar da relevância do tratamento da brucelose em gestantes e crianças ser indiscutível, existem desafios em relação ao arsenal terapêutico apropriado para estas populações. Tetraciclinas são contraindicadas para gestantes e crianças em fase de crecimento<sup>52</sup> . Além disso, o uso de aminoglicosídeos<sup>53</sup> e quinolonas<sup>54</sup> também não é recomendado durante a gestação.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **7.2. Casos crônicos/ formas localizadas da brucelose humana** -->
As recomendações de manejo deste protocolo se aplicam essencialmente às formas subagudas e agudas não localizadas da doença, que representam a maior parte dos casos reunidos na busca por evidências na literatura médica. Casos com manifestações focais, gravidade clínica ou acometimento do sistema nervoso central, e aqueles envolvendo hospedeiros específicos, tais como crianças muito jovens e pacientes imunossuprimidos, devem ser avaliados em centros de referência, por especialistas nas respectivas áreas envolvidas, e devem receber abordagem diferenciada, que pode incluir esquema terapêutico individualizado considerando o balanço entre os riscos e benefícios do tratamento para o paciente.  
Casos com complicações em sistemas orgânicos, tais como endocardite, infecção em sistema nervoso central, osteomielite ou abscesso profundo, o esquema terapêutico deve ser individualizado com base nas especificidades do paciente, penetração tecidual esperada dos antimicrobianos nos diferentes órgãos e gravidade clínica, não havendo condutas estudadas em ensaios clínicos. Como princípios gerais, sugere-se avaliar o prolongamento do tempo de tratamento para 4 a 6 meses no caso de osteomielite e considerar drenagem cirúrgica adjuvante no caso de coleção/abscesso<sup>55</sup> .  
7  
<mark>ABORDAGEM DE PACIENTES COM SUSPEITA OU DIAGNÓSTICO DA BRUCELOSE HUMANA</mark>

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **DIAGNÓSTICO** -->
A brucelose humana é uma doença de amplo espectro clínico, cujo diagnóstico definitivo requer a identificação do agente etiológico em amostra de sangue ou de outros tecidos e fluidos corporais. Entretanto, a dificuldade de isolamento em cultivo e o risco de infecção envolvido nessa manipulação exigem o uso de estratégias alternativas para a confirmação diagnóstica. São considerados casos prováveis de brucelose humana aqueles que apresentam vínculo epidemiológico, associados a manifestações clínicas compatíveis e resultados positivos combinados de testes laboratoriais imunológicos<sup>56</sup> , incluindo o teste Rosa Bengala (RBT) e ensaio imunoenzimático (ELISA), ou molecular, tal como a reação em cadeia da DNA polimerase (PCR).

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **8.1. Diagnóstico clínico** -->
A brucelose se manifesta inicialmente como uma doença febril semelhante a um quadro gripal, com sinais e sintomas constitucionais (mal-estar, astenia, inapetência)<sup>31</sup> inespecíficos e achados físicos variáveis, incluindo hepatomegalia, esplenomegalia e/ou linfadenopatia. Manifestações osteomusculares incluindo artralgia, mialgia e dores nas costas são frequentes, sendo descritas em cerca de metade dos pacientes (65%, 47% e 45%, respetivamente)<sup>31</sup> . Febre é um dos sinais mais comuns (78%)<sup>31</sup> , podendo se apresentar com padrão variável, sendo algumas vezes acompanhada por sudorese noturna, que pode se associar a odor peculiar de mofo<sup>57–59</sup> . Sintomas adicionais incluem perda de peso, cefaleia, dor lombar, fadiga, tosse e alterações emocionais com padrão depressivo)<sup>31,60</sup> .  
Conforme uma revisão sistemática de estudos realizados na China, os principais sintomas clínicos foram febre, fadiga, artralgia e dores musculares, com prevalências de 87%, 63%, 62% e 56%, respectivamente. Observou-se diferenças significativas relacionadas à faixa etária: erupções cutâneas, complicações respiratórias e cardíacas, além de orquite/epididimite, foram mais frequentes em crianças. Entre as complicações comuns da brucelose, destacaram-se hepatite, osteoartrite, doenças respiratórias, cardiovasculares, disfunção do sistema nervoso central, síndrome hemofagocítica e orquite/epididimite em homens<sup>60</sup> .  
Há relatos de período de incubação (desde a infecção até as manifestações clínicas) variando entre 1 semana e 2 meses<sup>61</sup> , mais comumente entre duas e quatro semanas. Quando não tratada, a doença pode persistir prolongadamente, com duração de meses e até anos. A doença pode se desenvolver de forma sistêmica não localizada ou afetar diversos sistemas do organismo, em especial o osteoarticular, o geniturinário, o sistema nervoso central (SNC), o gastrointestinal, o cardiovascular e o sistema respiratório. O envolvimento focal de órgãos é reconhecido como uma complicação da infecção, o que ocorre mais em adultos do que em crianças<sup>32,62</sup> .  
Uma classificação clínica universalmente aceita para a brucelose humana não está disponível. De modo geral, encontram-se arbitrariamente descritas na literatura as formas: aguda (menor que 2 meses), subaguda (3 a 12 meses) e crônica (maior que 1 ano)<sup>63–65</sup> . Quanto à forma de apresentação, o acometimento de sistemas específicos define a doença como localizada<sup>66,67</sup> , o que pode ocorrer tanto nas formas aguda, subaguda ou crônica.  
A brucelose humana crônica se assemelha à síndrome da fadiga persistente, sendo menos frequente em crianças, e mais prevalente em idosos. Geralmente, pacientes com brucelose crônica  
8  
apresentam psiconeurose, sudorese e perda de peso. Já a presença de febre é pouco frequente. Embora as diferentes formas localizadas possam ocorrer, as manifestações oculares, como episclerite e uveíte, são as mais frequentes<sup>68</sup> .  
As principais manifestações da brucelose humana incluem<sup>68</sup> :  
**- Sistema osteoarticular** : A doença osteoarticular é a forma mais comum de brucelose localizada, ocorrendo em até 70% dos pacientes e as manifestações incluem artrite periférica. As articulações mais comumente afetadas são as grandes articulações, como joelhos, quadris, ombros e tornozelos, sacro-ileíte e espondilite, sendo esta última mais comum no contexto da doença crônica<sup>33,46</sup> .  
**- Sistema genitourinário:** O envolvimento geniturinário é a segunda forma mais comum de brucelose localizada, ocorre em até 10% dos casos. No sexo masculino, a orquite e/ou epididimite são as manifestações mais comuns; prostatite e abscesso testicular ocorrem menos comumente. Em mulheres, foi descrito abscesso tubo-ovariano. Manifestações adicionais incluem cistite, nefrite intersticial, glomerulonefrite e abscesso renal<sup>69</sup> . Em mulheres grávidas tem sido associada ao risco de aborto espontâneo, morte fetal intrauterina, parto prematuro e infecção intrauterina com possível morte fetal<sup>34,70</sup> .  
**- Sistema nervoso central** : acometimento neurológico ocorre em até 10% dos casos<sup>35</sup> com quadros de meningite (aguda ou crônica), encefalite, abscesso cerebral, mielite, radiculite e/ou neurite (com envolvimento de nervos cranianos ou periféricos) e manifestações que incluem cefaleia, meningismo, confusão mental, letargia, convulsões, hemiparesia, sinais meníngeos e alterações emocionais.  
**- Sistema gastrointestinal:** dor abdominal, náuseas, vômitos, diarreia, constipação, hepatomegalia e esplenomegalia podem ocorrer durante o curso da brucelose. Complicações como hepatite granulomatosa e abscessos hepáticos também foram relatadas.  
**- Sistema cardiovascular** : envolvimento cardiovascular é considerado raro, descrito em até 3% dos casos<sup>35</sup> e pode incluir endocardite, que é a principal causa de morte na brucelose, mas também miocardite, pericardite, endarterite, tromboflebite e/ou aneurisma micótico da aorta ou ventrículos.  
**- Sistema respiratório** : tosse, dispneia, dor torácica e pneumonia, mais raramente abscessos pulmonares, empiema e derrame pleural<sup>71</sup> .  
**- Manifestações cutâneas** : erupções maculopapulares, eritema nodoso, púrpura, lesões papulares e nódulos subcutâneos podem ocorrer em pacientes com brucelose. Estas manifestações são geralmente secundárias à bacteremia ou reações de hipersensibilidade.  
É importante que os profissionais reconheçam os principais sinais e sintomas das diferentes manifestações da brucelose, a fim de excluir outros diagnósticos diferenciais dessa doença (ver seção sobre o diagnóstico laboratorial).

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **8.2. Vínculo epidemiológico** -->
Considerando o mecanismo de transmissão da infecção, o vínculo epidemiológico pode ser estabelecido diante das seguintes situações:  
9  
**Exposição a animais infectados** : indivíduos, como trabalhadores rurais, veterinários, trabalhadores de matadouros, que têm contato direto com animais infectados ou produtos contaminados derivados deles, como carne, vísceras, leite e derivados não pasteurizados.  
**Consumo de alimentos contaminados** : histórico de ingestão de produtos lácteos não pasteurizados ou outros produtos de origem animal de procedência desconhecida ou proveniente de áreas onde a doença animal é endêmica. Água e vegetais contaminados também podem ser fontes de exposição à _Brucella_ sp.  
**<mark>Contato com casos humanos</mark>** <mark>: embora incomum, a transmissão de pessoa para pessoa por via sexual, transfusão de sangue, vertical e transplante de órgãos está descrita.</mark>  
**<mark>Exposição acidental a</mark>** **_<mark>Brucella</mark>_** **<mark>sp.:</mark>** <mark>autoinoculação durante procedimento de vacinação animal, contato do spray da vacina com a mucosa ocular, ou exposição à material de cultivo para</mark> _<mark>Brucella</mark>_ <mark>sp</mark> _<mark>.</mark>_ <mark>em ambiente laboratorial.</mark>

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **8.3. Diagnóstico laboratorial** -->
A realização da cultura e a identificação de _Brucella_ sp. a partir de amostras clínicas é evidência irrefutável da infecção, estabelecendo o diagnóstico definitivo de brucelose humanda<sup>55</sup> . No entanto, essa doença caracteriza-se por carga bacteriêmica baixa e intermitente, com redução progressiva ao longo do curso da doença. Essa cinética da bacteremia torna a realização de hemocultura uma estratégia de investigação pouco sensível nas fases crônicas, mas especialmente indicada em casos agudos (menos de três meses de infecção)<sup>39,72</sup> . A baixa sensibilidade da cultura<sup>73–</sup> 75 exige o emprego de métodos sorológicos e moleculares de investigação, frequentemente usados em combinação, para aumento da acurácia diagnóstica. Por outro lado, as formas complicadas com sinais de comprometimento localizado em órgãos específicos (articulação, SNC, valva cardíaca etc.) e, principalmente, no caso de abscessos ou coleções, sempre que possível, devem ser investigadas com realização de cultivo a partir do respectivo espécime clínico coletado do foco identificado.  
Para sustentar as recomendações de investigação laboratorial para brucelose humana, foi realizada revisão sistemática da literatura<sup>76</sup> e levado em consideração as características intrínsecas dos testes, além de recomendações de organismos internacionais<sup>55</sup> , disponibilidade no contexto brasileiro, parâmetros como simplicidade de execução e custo unitário dos testes<sup>32</sup> . Detalhes metodológicos das estratégias utilizadas para as recomendações encontram-se disponíveis no Apêndice 1. Na **Figura 1** é apresentado o algoritmo para a investigação laboratorial da brucelose em indivíduos sintomáticos, baseado na combinação dos testes Rosa Bengala, ELISA (total ou IgG) e PCR.  
Para permitir a realização dos testes, recomenda-se a coleta de sangue para análise de sangue total e soro/plasma. Se outro espécime clínico coletado em condições estéreis estiver disponível (no caso de forma localizada), o material deve ser encaminhado para cultura e PCR. A sequência de realização dos testes segue o racional de otimização da utilização dos recursos e melhor aproveitamento das propriedades intrínsecas dos testes, em termos de desempenho, realizado em fluxo contínuo pelo Sistema Nacional de Laboratórios de Saúde Pública (SISLAB), a partir de cada entrada do registro de espécime clínico, via Sistema Gerenciador de Ambiente Laboratorial (GAL) e usufruindo de todos os recursos da rede de laboratórios (por meio de transferência interna de amostra), independentemente de qual seja o laboratório de entrada da amostra.  
Importante ressaltar que a investigação laboratorial de brucelose deve ser realizada para pacientes sintomáticos com suspeita da doença. Na primeira etapa de investigação, sugere-se a  
10  
realização simultânea de sorologia por duas técnicas diferentes: aglutinação por Rosa Bengala (titulável ou não) e ELISA total ou IgG. Cabe destacar que a detecção isolada de IgM pelo ELISA não deve ser considerada um critério de confirmação da doença ou um marcador da fase aguda da infecção, devido ao alto percentual de reações inespecíficas (falso-positivas) que podem persistir por longos períodos<sup>77</sup> .  
Em casos com resultados positivos para os testes de Rosa Bengala (titulável ou não) e ELISA total ou IgG, é possível o estabelecimento de um diagnóstico provável de brucelose em casos sintomáticos. Nos casos suspeitos com testes negativos ou discordantes, a amostra de sangue total (também coletada junto com a amostra de soro/plasma) seguirá para teste pela técnica de PCR. A detecção de DNA de _Brucella_ sp. na técnica de PCR em pacientes com manifestação clínica e vínculo epidemiológico é considerada evidência presuntiva do diagnóstico<sup>39</sup> . No entanto, um resultado negativo da PCR não é suficiente para descartar a suspeita de infecção, devido à possibilidade de falsos-negativos em pacientes com formas clínicas não bacteriêmicas ou com baixa/intermitente carga bacteriana.  
Após a realização da primeira etapa da investigação ( **Figura 1** ), não havendo confirmação do diagnóstico definitivo ou provável de brucelose ou se o teste por PCR não estiver disponível e persistindo a suspeita clínica, nova coleta de sangue com intervalo de 2 a 4 semanas da primeira coleta de sangue pode ser realizada para repetição do Rosa Bengala e ELISA (total ou IgG). A exigência de intervalo mínimo entre as duas coletas tem o propósito de minimizar o risco de falsonegativo relacionado ao período pré-soroconversão. Para qualquer um dos métodos sorológicos quantitativos, a elevação do título da reação acima de 4 vezes em um intervalo mínimo de 2 semanas confirma o diagnóstico definitivo de brucelose<sup>55</sup> .  
Em caso de exposição acidental, consultar a seção “ABORDAGEM DE PESSOAS EXPOSTAS ACIDENTALMENTE À BRUCELLA SP” deste Protocolo. Destaca-se que, em caso de aparecimento de sinais e sintomas compatíveis com brucelose humana até 24 semanas após a exposição, independente da classificação de risco da fonte, a investigação diagnóstica deve seguir a proposta detalhada na **Figura 1** .  
11  
<!-- Start of picture text -->
( individuo com quadro clinico'Casocompativel suspeito com sintomatico*brucelose + vinculo epidemiolégico”) }<br>= Coleta da 1° amostra de sangue total<br>parkerot tnlepeeatengiatca)het (See eece eee<br>_ sor para sorologia esangue total para PCR)<br>Realizar cultura Realizar Rosa Bengala e ELISA?<br>Positivo Negieo PeeigiseeticlDivergentes ou ‘Ambos reagentes<br>|<br>Diagnéstico [Avatar<br>| definitivo* dos demaisos resultados testes Realizar PCR Diagnésticoprovavel<br>NaoPCRdetectével indisponivelou el |<br>N&o__/ sim Diagnéstico<br>Caso permanece aurieal<br>Caso suspeito? |<br>descartado \_indefinido[Caso<br>nao _/Acoletada primer® sim | Coletasangue total<br>Caso da 2*amostra de<br>—indatinnan)* _ O" MaEOn g meses (apés pelo menos 2 semanas<br>sintomas?Miesdied ‘da data da 1° coleta)<br>Realizar Rosa Bengala e ELISA?<br>Pelocom menoselevacaoum dosde 4testes vezes reagente0 titulo elevagio‘Ambos reagentesde 4 vezes titulosem | |__—Divergentesambos negativesou<br>Diagnéstico Diagnéstico cea teats<br>definitive provavel<br> suspeita de exposicao 4 vacina RBS1 ou B. canis com quadro clinico compativel com brucelose: realizar somente a<br>cuttura<br>* Quadro clinico compativel com brucelose: febre acompanhada por sinais e sintomas constitucionais tals como calatfrios,<br>miaigia, sudorese, artralgia, astenia, fraqueza e hepatoesplenomegalia ou comprometimento localizado de sistemas-6rgos<br>(attire, orquite, endocardite, meningite, entre outros).<br>2 Vinculo epidemiolégico: consumo de alimentos contaminado (principaimente leite e derivados no pasteurizados, como|<br>queijo, manteiga, natas e iogurte), ou exposico a animais infectados ou exposicSo acidental a Brucella sp.<br>°Critérios de positividade: ELISA total ou Ig.<br>Cultura positiva: sempre que possivel encaminhar amostra das culturas positivas para confimac3o da espécie no<br>laboratério de referéncia.<br><!-- End of picture text -->  
Figura 1 - Fluxograma para o diagnóstico da brucelose humana.  
Fonte: elaboração própria.  
**Nota** : Casos suspeitos sintomáticos por infecção ou exposição acidental à vacina RB51 ou _B. canis devem seguir a investigação diagnóstica por exame de cultura, visto que não há produção de_ anticorpos tituláveis para os agentes investigados pelos métodos sorológicos disponíveis.  
12

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **8.4. Diagnóstico diferencial** -->
Devido à inespecificidade e amplo espectro clínico da brucelose, torna-se essencial o diagnóstico diferencial com outras doenças, infecciosas ou não, entre as quais destacam-se: febre tifoide, malária, endocardite bacteriana, tuberculose, pneumonia, mas também doenças reumatológicas, sarcoidose, neoplasias, infecções fúngicas e transtornos psiquiátricos ( **Figura 2** ). Dessa forma, exames específicos indicados para afastar outros diagnósticos diferenciais devem ser realizados concomitantemente à investigação para brucelose, de acordo com julgamento clínico e à luz das especificidades de cada caso.  
<!-- Start of picture text -->
Forma aguda Formas Localizadas<br>ra a Osteoarticular*® Respiratoria’24 Cardiovascular’:®<br>+ Tuberculose’ 434 fi~ Ciateaote | |((*6 sarcoidoseTuberculose ) (»3 EndocarditeMiocardites virais<br>« Febre tifoide? i Siestasty | *+ Pneumoniascriptococose «Neoplasia+ Derrame pericércicovalvar<br>+ Febre paratifoide'> 1 See | « Histoplasmose * Insuficiéncia cardiaca<br>* Atte de joeto<br>+ Endocardite infecciosa xi + Ait reumatoideou quasi | \e¢ NeoplasiasEmpiema pieural crénico —SSEag<br>* Mononucleose”* y beelehes Genitourinana*? Neurolégica’<br>> aea years+ Espondiiogscite (~PeOrquites viraisll € + Depressio=<br>* Criptococose’ A x ce— = etnaarenEpididimo-orquite «SagetDisturbios mentais<br>+ 3 Yes + Neoplasia testicular + Doenca de Lyme<br>Histoplasmose’ + Sinowie * Tuberculose<br>+ 133 Ag Tendinite y «= Pielonefrite de vias urinrias | * Encefalomieiteagua disseminada<br>Malaria oS (i Kentowaniomaasa__) + Etttose min<br>* Doenga colégeno-vascular> | ,,Gastrointestinay”<br>+ Febre reumaticaatica’ += DoencasDoeneana de Crohn Hepatoiliar’*Pi FunesCuténea®ranea’<br>+ Salmonelose‘‘ + inflamatoriasNeopiasias intestinaisintestinais (airepanes‘s Amebiase += MicosesPlinase profiundas:résea<br>X / | « Tuberculose intestinal |= Coecstte + Neoplasias<br>"|. Doenca de Whipple ae 2 Sarcoidose<br><!-- End of picture text -->  
Figura 2 - Condições de saúde mais frequentes a serem excluídas diante de quadros agudos sistêmicos.  
Legenda: 1. Mantur et al., 2004<sup>47</sup> ; 2. Takahashi et al., 1996<sup>78</sup> 3. Araj et al., 2010<sup>36</sup> ; 4. Ulu Kilic et al., 2013<sup>79</sup> ; 5. Guler et al., 2014<sup>80</sup> ; 6. Esmaeilnejad-Ganji et al., 2019<sup>81</sup> . Fonte: elaboração própria.  
13

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **ABORDAGEM TERAPÊUTICA** -->
O tratamento da brucelose humana é tido como um desafio, o que está diretamente ligado à capacidade das bactérias do gênero _Brucella_ sp. de formar nichos intracelulares nos tecidos hospedeiros. Isso pode explicar as recidivas observadas após terapia antimicrobiana aparentemente eficaz. Seu objetivo é reverter as manifestações clínicas e prevenir a ocorrência de complicações crônicas.  
São definidas três situações clínicas relacionadas ao tratamento, nomeadamente: cura, no caso de desaparecimento de sinais e sintomas atribuídos à doença após tratamento específico; falha terapêutica/ausência de resposta no caso de persistência de sinais e/ou sintomas atribuíveis à doença após 6 semanas de início do tratamento; e recidiva, caracterizada pelo reaparecimento de sinais e/ou sintomas atribuíveis à brucelose, após período assintomático, com ocorrência em até 12 meses após o fim do tratamento. Tanto a falha quanto a recidiva são consideradas insucessos terapêuticos<sup>82</sup> . Diferentes classes de antimicrobianos foram estudados para o tratamento da brucelose (tetraciclinas, aminoglicosídeos, sulfonamidas, quinolonas, cefalosporinas e a rifampicina)<sup>40,41,82–84</sup> . Apesar da limitação na qualidade da evidência disponível, os dados sugerem a superioridade de esquemas combinados em relação à monoterapia<sup>41,82,84</sup> . A combinação de doxiciclina e aminoglicosídeos (sulfato de estreptomicina ou sulfato de gentamicina) foi identificada como o esquema com as menores taxas de insucesso entre adultos<sup>84</sup> . Há evidências incipientes que sugerem benefício com a adição de hidroxicloroquina ao esquema doxiciclina e estreptomicina, porém esses achados necessitam de confirmação<sup>85,86</sup> . Para o tratamento de populações específicas, como crianças menores de 10 anos e gestantes, as evidências se mostraram ainda mais fracas e limitadas<sup>52</sup> .  
A escolha terapêutica deve considerar as especificidades de cada paciente, como faixa etária, gravidez ou potencial de engravidar, gravidade clínica, presença de disfunções sistêmicas ou de outras comorbidades, viabilidade de uso de medicamentos por via oral, preferências individuais e aspectos logísticos<sup>87</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.1. Tratamento medicamentoso em adultos** -->
O esquema de primeira escolha é a combinação de doxiciclina com um medicamento da classe dos aminoglicosídeos (sulfato de estreptomicina ou o sulfato de gentamicina), por ser a associação com menor taxa de insucesso comparada a outras combinações de antimicrobianos<sup>41,84</sup> .  
A escolha entre sulfato de estreptomicina e sulfato de gentamicina deve considerar a comodidade terapêutica (considerando a via, o período de administração e as características do paciente) e a disponibilidade do medicamento uma vez que a evidência existente até o momento não aponta diferença de eficácia ou toxicidade entre os dois aminoglicosídeos<sup>41,84</sup> . Já o tratamento de segunda escolha é combinação de doxiciclina e rifampicina (ambas de uso oral), por apresentar maiores taxas de insucesso terapêutico comparado à combinação de doxiciclina e aminoglicosídeo. A associação doxiciclina e rifampicina pode ser indicada quando houver restrição clínica ou impossibilidade operacional de uso de aminoglicosídeo (como em situações que inviabilizem a ida do paciente à unidade de saúde para a administração intravenosa ou intramuscular de aminoglicosídeos)<sup>88,89</sup> .  
14

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.2. Tratamento medicamentoso em crianças** -->
Nas crianças acima de 10 anos, o esquema terapêutico recomendado é o mesmo indicado para adultos.  
Já crianças com idade inferior a 10 anos têm restrição relativa ao uso de tetraciclinas em função do potencial dano ao crescimento e pigmentação dentária. O esquema mais frequentemente utilizado, de acordo com a literatura reunida abordando a forma não localizada da brucelose em crianças com idade até 10 anos, foi o sulfametoxazol associado à trimetoprima e a rifampicina. A taxa sumarizada de insucesso terapêutico (falha e/ou recidiva) reunindo todos os casos tratados foi estimada em 13% (IC95%: 6- 29%)<sup>52</sup> .  
O esquema terapêutico baseado na combinação de aminoglicosídeos (sulfato de estreptomicina ou gentamicina) com sulfametoxazol e trimetoprima foi estudada em menor número de casos, com grande variação na taxa de insucesso (falha e/ou recidiva), estimada em 2%, IC95%: 0,0-49,0%<sup>52</sup> . O uso desta e de outras combinações não está sustentado por ensaios clínicos e deve ser avaliado caso a caso, considerando restrições específicas em função da toxicidade que podem variar com a idade da criança.  
Ressalta-se que não foi identificado estudo randomizado avaliando eficácia e segurança do tratamento da brucelose em crianças com menos de 10 anos, de modo que a evidência reunida é constituída por estudos observacionais retrospectivos. Assim, a recomendação terapêutica baseiase na extrapolação dos dados de eficácia descritos em adultos e no perfil de segurança já descritos para os antimicrobianos. Embora na literatura científica e em guias terapêuticos de outros países o limite de idade para a recomendação do tratamento com os mesmos esquemas combinados usados em adultos seja 8 anos, na revisão da literatura realizada para a elaboração desse PCDT, observouse pouca representatividade de crianças entre 8 e 10 anos nos estudos incluídos. Por esta razão, optou-se pela abordagem mais conservadora e o limite mínimo de 10 anos para a recomendação de tratamento tal como indicado para adultos. Casos especiais de crianças entre 8 e 10 anos, a depender da gravidade clínica e fatores individuais, podem ser abordados, a critério do pediatra, com base nas recomendações propostas para adultos.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.3. Tratamento medicamentoso em gestantes** -->
Além de risco potencial de teratogenicidade, a mesma toxicidade descrita para crianças com menos de 10 anos se aplica ao feto, motivo pelo qual as tetraciclinas são contraindicadas em gestantes (categoria D)<sup>90</sup> . Não foi identificado estudo randomizado que avaliasse a eficácia e segurança do tratamento da brucelose em gestantes. A evidência reunida é constituída por estudos observacionais retrospectivos e, em todos os trabalhos, o desfecho de interesse apresentado foram as complicações obstétricas da brucelose, não tendo sido possível estimar a taxa de insucesso das intervenções nesse subgrupo. Por sua vez, a ocorrência de complicações obstétricas, tais como perda gestacional e parto prematuro, entre mulheres com brucelose foi em torno de 16% (IC95%: 8 - 30%)<sup>91–93</sup> .  
O esquema mais descrito na literatura para tratamento de gestantes com brucelose consiste na associação de sulfametoxazol + trimetoprima com rifampicina. Trata-se de uma escolha baseada na extrapolação de resultados disponíveis para adultos e em princípios gerais de segurança terapêutica para o uso de antimicrobianos em mulheres com potencial de engravidar e grávidas. É importante destacar a necessidade de gestantes com suspeita ou confirmação de brucelose serem acompanhadas em serviços de atenção especializada, de preferência sob cuidados de equipe obstétrica.  
15  
O uso de quinolonas durante a gestação permanece controverso, pelo risco potencial de toxicidade embrionária, especialmente durante o primeiro trimestre de gestação<sup>54,90</sup> . Por sua vez, a administração de aminoglicosídeos, especialmente o sulfato de estreptomicina, durante a gravidez aumenta o risco de ototoxicidade<sup>53,94</sup> e nefrotoxicidade no lactente<sup>53</sup> . Embora nenhum caso de toxicidade tenha sido identificado no feto após o uso do sulfato de gentamicina em gestantes, a existência de poucos estudos controlados, limitados a esquemas de tratamento de curta duração, impedem a extrapolação dessas observações<sup>94</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4. Medicamentos** -->
- cloridrato de doxiciclina: comprimido de 100 mg;  
- rifampicina: cápsula de 300 mg e suspensão oral 20 mg/mL  
- sulfametoxazol + trimetoprima: comprimido de 400 mg + 80 mg; suspensão oral de 40 mg/mL + 8 mg/mL e solução injetável 80 mg/mL + 16 mg/mL;  
- sulfato de estreptomicina: pó para solução injetável de 1 g;  
- sulfato de gentamicina: solução injetável de 40mg /mL.  
As principais informações dos medicamentos recomendados neste PCDT são descritas abaixo. A fonte das informações apresentadas a seguir é o Formulário Terapêutico Nacional<sup>95</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4.1. Cloridrato de doxiciclina** -->
A doxiciclina é um antibiótico que pertencente à classe das tetraciclinas, administrado por via oral. Seu mecanismo de ação envolve a inibição da síntese de proteínas nas bactérias, interferindo com a ligação do RNA mensageiro ao ribossomo bacteriano. Isso impede a produção de proteínas essenciais para o crescimento e replicação bacteriana, levando à morte das bactérias ou à inibição do seu crescimento. A dose usual em adultos no tratamento da brucelose é de 200 mg (100 mg, a cada 12 horas).  
O comprimido solúvel pode ser deglutido diretamente ou pode ser dissolvido em 50mL de água antes da administração. Recomenda-se a ingestão de aproximadamente 200mL de água durante a administração de comprimidos de medicamentos da classe das tetraciclinas para reduzir o risco de irritação esofágica e ulceração.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4.2. Rifampicina** -->
A rifampicina é um antibiótico da classe das rifamicinas cujo mecanismo de ação envolve a inibição da síntese de ácidos nucleicos nas bactérias, interferindo na atividade da RNA polimerase, uma enzima essencial para a transcrição do DNA em RNA. Esse mecanismo resulta na interrupção da produção de proteínas e ácidos nucleicos, levando à inibição do crescimento bacteriano.  
No adulto, a dose diária sugerida é de 600 mg. As cápsulas podem ser ingeridas com líquido, por via oral. A administração deve ser feita preferencialmente em jejum, pelo menos 30 minutos antes ou 2 horas após as refeições.  Para garantir absorção rápida e completa, recomendase administrar a rifampicina com o estômago vazio, longe das refeições. Este medicamento pode causar coloração avermelhada da urina, escarro e lágrimas.  
16

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4.3. Sulfametoxazol associado à trimetoprima** -->
A combinação de sulfametoxazol e trimetoprima, um antibiótico da classe das sulfonamidas e um inibidor da folato redutase, apresenta grande atividade sinérgica. O mecanismo de ação do sulfametoxazol consiste em inibir a síntese do ácido fólico bacteriano, enquanto a trimetoprima interfere na mesma via metabólica. Este mecanismo habitualmente resulta em atividade bactericida _in vitro_ em concentrações nas quais as substâncias individualmente são apenas bacteriostáticas. Ou seja, essa combinação de ações impede a produção de componentes essenciais para o crescimento bacteriano, levando à morte das bactérias.  
As doses administradas em comprimidos e suspensão de uso oral devem ser pela manhã e à noite, de preferência após uma refeição e com suficiente quantidade de líquido. O frasco de suspensão oral deve ser agitado antes da administração.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4.4. Sulfato de estreptomicina** -->
Este antibiótico pertencente à classe dos aminoglicosídeos, utilizado no tratamento de diversas infecções bacterianas, incluindo a brucelose. Seu mecanismo de ação envolve a interferência com a síntese de proteínas nas bactérias. A estreptomicina se liga irreversivelmente à subunidade 30S do ribossomo bacteriano, prejudicando a leitura do código genético e inibindo a síntese de proteínas essenciais para o crescimento bacteriano. Esse efeito leva à morte das bactérias ou à inibição do seu crescimento.  
A dose recomendada para os adultos é de 1.000 mg ao dia. O conteúdo em pó do frasco deve ser diluído com 5,0mL de água para injeção, obtendo-se uma solução límpida, incolor a levemente amarelada. O volume final do produto após reconstituição é cerca de 5,8mL. A solução pronta contém 216 mg de sulfato de estreptomicina por mL, equivalente a 172 mg de estreptomicina. Após reconstituição, deve-se administrar o medicamento imediatamente por via intramuscular profunda.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.4.5. Sulfato de gentamicina** -->
O sulfato de gentamicina também é um antibiótico da classe dos aminoglicosídeos, cujo mecanismo de ação envolve a interferência com a síntese de proteínas nas bactérias. A gentamicina se liga irreversivelmente à subunidade 30S do ribossomo bacteriano, prejudicando a leitura do código genético e inibindo a síntese de proteínas essenciais para o crescimento bacteriano. Esse efeito resulta na morte das bactérias ou na inibição do seu crescimento. A gentamicina é eficaz contra uma ampla gama de bactérias Gram-negativas, incluindo algumas cepas resistentes a outros antibióticos e é altamente eliminada na urina e no tecido renal.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.5. Esquemas de administração** -->
Os esquemas de administração dos medicamentos preconizado neste Protocolo estão descritos no Quadro 1, conforme populações específicas.  
17  
<u>Quadro 1 - Esquemas recomendados para tratamento da brucelose nos diferentes subgrupos.</u>  
|**Indicação**|**Esquema**|**Posologia diária**|**Duração**|
|---|---|---|---|
||**Preferenciais:**<br>cloridrato de doxiciclina<br>+|doxiciclina: 100 mg, 12/12<br>horas, VO<br>+<br>estreptomicina: 1000 mg/dia,<br>via IM|42 dias<br>14 dias|
|Adultos e<br>crianças<br>maiores de<br>10 anos|<br>aminoglicosídeos (sulfato<br>de estreptomicina ou<br>sulfato de gentamicina)|doxiciclina: 100 mg, 12/12<br>horas, VO<br>+<br>sulfato de gentamicina: 5<br>mg/kg/dia*,IM ou IV|42 dias<br>5 a 7 dias|
||**Alternativo:**<br>cloridrato de doxiciclina<br>+<br>rifampicina|Doxiciclina: 100 mg, 12/12<br>horas, VO<br>+<br>rifampicina: 600 mg (2 cápsulas<br>de 300mg),1 vez ao dia,VO|42 dias|
|Crianças<br>até 10 anos|SMX+TMP<br>+<br>rifampicina|SMX+TMP<br>8 a 12 mg/kg/dia, VO<sup>β</sup><br>+<br>rifampicina<br>15 a 20 mg/kg<sup>#</sup>, 1 vez ao dia,<br>VO|42 dias|
|Gestantes|SMX+TMP<br>+<br>rifampicina|SMX+TMP<br>400 mg +80mg/kg, 12/12 horas,<br>VO<br>+<br>rifampicina: 600 mg (2 cápsulas<br>de 300mg),1 vez ao dia,VO|42 dias|  
Legenda: IV: intravenosa; IM: intramuscular; SMX+TMP: Sulfametoxazol +  
trimetoprima; VO: via oral.  
**Nota 1:** Foram considerados os esquemas de administração utilizados nos estudos*<sup>96,97;</sup> #98,99; β:98,100,101. e relatórios do CDC 55 e Conitec102.  
**Nota 2:** A utilização de SMX+TMP em apresentação de solução injetável 80 mg/mL + 16 mg/mL (ampola de 5mL) pode ser necessária quando a administração oral é impossível ou contraindicada. Nesse caso, a dose a ser administrada para crianças de até 12 anos é de 30mg de SMX + 6mg de TMP por kg de peso corpóreo diariamente, sendo dividida em duas administrações. Para adultos e crianças acima de 12 anos, a dose recomendada corresponde a 2 ampolas de 5mL duas vezes ao dia. A dose padrão deve ser usada por não mais do que 5 dias consecutivos e as altas doses não mais do que 3 dias consecutivos<sup>103</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **9.6. Contraindicações** -->
As contraindicações aos medicamentos preconizados neste Protocolo são<sup>95</sup> :  
**Cloridrato de doxiciclina:** crianças menores de 7 anos (prejudicial ao desenvolvimento dos dentes), hipersensibilidade às tetraciclinas e na gestação devido ao risco de efeitos teratogênicos. Usar com precaução em pacientes com miastenia grave (fraqueza muscular pode ser aumentada), lúpus eritematoso sistêmico (pode ser exacerbado). Mulheres em idade fértil com sobrepeso ou histórico de hipertensão intracranial e pacientes vulneráveis à porfiria. Evitar a exposição à luz durante o uso (risco de fotossensibilidade). O risco na gravidez é classificado como categoria D - atravessa a placenta. A administração no segundo e terceiro trimestres podem causar descoloração dos dentes da criança e hepatotoxicidade materna tem sido relatada com doses altas,  
18  
por via parenteral. Devido ao risco de efeitos teratogênicos, esse medicamento não deve ser usado em mulheres grávidas.  
**Rifampicina:** casos de hipersensibilidade ao medicamento ou outro componente da formulação e na porfiria aguda. Usar com precaução nos casos de alcoolismo crônico, contracepção oral (risco de falha), diabete melito. Avaliar função hepática antes e durante o tratamento e descontinuar em caso de hepatotoxicidade. Fazer a dosagem do medicamento em pacientes em hemodiálise e com depuração de creatinina menor que 50 mL/minuto (50 a 100% da dose recomendada). Contraindicada para indivíduos que desenvolveram brucelose após exposição à cepa RB51. O risco na gravidez é classificado como categoria C - atravessa a placenta. A administração de rifampicina durante as últimas semanas de gravidez pode causar hemorragias pós-natais na mãe e no neonato (tratar com vitamina K).  
**Sulfametoxazol associado à trimetoprima (SMX+TMP):** pacientes com insuficiência hepática grave e uso com cautela na doença leve a moderada. Necessário ajuste de dose em idosos com a diminuição da função renal. Seu uso deve ser criterioso durante a amamentação, com monitoramento de sinais de icterícia. Usar com precaução nos casos de deficiência de glicose-6fosfato desidrogenase, asma, predisposição à hiperpotassemia ou deficiência de folato, sensibilidade a sulfitos e crianças abaixo de 6 semanas de idade. O risco na gravidez é classificado como categoria C – tanto sulfametoxazol quanto trimetoprima atravessam a placenta. Podem, portanto, interferir com o metabolismo do ácido fólico, devendo ser utilizado durante a gravidez se os possíveis riscos para o feto justificarem os benefícios terapêuticos esperados. Recomenda-se que toda mulher grávida, que está sendo tratada com sulfametoxazol + trimetoprima receba, concomitantemente, 5 a 10 mg de ácido fólico diariamente.  
**Sulfato de estreptomicina:** pacientes com hipersensibilidade. Pode causar neurotoxicidade, ototoxicidade e nefrotoxicidade, uso com cautela em idosos e pacientes com comprometimento renal. Lactantes em uso do medicamento devem evitar a amamentação devido aos riscos e efeitos adversos para o lactente. O risco na gravidez é classificado como categoria D – atravessa a placenta. Uso não recomendado durante a gestação devido à possibilidade de dano fetal como ototoxicidade, incluindo surdez. Se não houver alternativas terapêuticas ao uso dos aminoglicosídeos, recomenda-se monitorar cuidadosamente os níveis séricos maternos para que o feto não esteja exposto a quantidades excessivas e os níveis de fármaco materno não se tornem subterapêuticos.  
**Sulfato de gentamicina:** pacientes com hipersensibilidade ou reações tóxicas graves em tratamentos anteriores com gentamicina ou outros aminoglicosídeos. A dose deve ser ajustada para pacientes com insuficiência renal. Requer-se o monitoramento da função renal e neurotoxicidade em pacientes idosos, pediátricos, em uso de altas doses e durante períodos prolongados. Ototoxicidade vestibular e auditiva pode ocorrer primeiramente em pacientes com dano renal preexistente e em pacientes com a função renal normal, tratados com altas doses e/ou por períodos maiores do que os recomendados. Recomenda-se vigilância das funções renal e do oitavo par craniano durante o tratamento, principalmente em pacientes com insuficiência renal suspeita ou conhecida. Considerar a interrupção do aleitamento ou do tratamento, tendo em vista a importância do fármaco para o benefício da mãe. O risco na gravidez é classificado como categoria D – atravessa a placenta. Pode ocasionar dano fetal se administrado a mulheres grávidas. Há relatos de surdez total bilateral congênita irreversível em crianças cujas mães receberam aminoglicosídeos, incluindo gentamicina, durante a gravidez.  
Os principais eventos adversos e interações medicamentosas estão descritos no **Quadro 2** .  
19  
Quadro 2 - Principais eventos adversos e interações medicamentosas<sup>95</sup> .  
|**Medicamento**|**Principais eventos adversos**|**Interações moderadas**<br>**agraves**|
|---|---|---|
|cloridrato<br>de<br>doxiciclina|Hipersensibilidade (incluindo choque anafilático,<br>reação anafilática, reação anafilactóide, angioedema,<br>exacerbação<br>do<br>lúpus<br>eritematoso<br>sistêmico,<br>pericardite, doença do soro, púrpura de Henoch-<br>Schonlein, hipotensão, dispneia, taquicardia, edema<br>periférico, e urticária), cefaleia, náusea, vômito,<br>reação de fotossensibilidade, rash incluindo erupções<br>cutâneas maculopapulares e eritematosas, anemia<br>hemolítica, neutropenia, trombocitopenia, eosinofilia,<br>reação a medicamentos com eosinofilia e sintomas<br>sistêmicos (DRESS), reação de Jarisch-Herxheimer,<br>descoloração microscópica castanho-preta da glândula<br>tireoide,<br>diminuição<br>do<br>apetite,<br>hipertensão<br>intracraniana<br>benigna<br>(pseudotumor<br>cerebral),<br>abaulamento<br>de<br>fontanela,<br>zumbido,<br>rubor,<br>pancreatite, colite pseudomembranosa, colite por<br>_Clostridioides difficile_, úlcera esofágica, esofagite,<br>enterocolite,<br>lesões<br>inflamatórias<br>(com<br>supercrescimento de Candida na região anogenital),<br>disfagia,<br>dor<br>abdominal,<br>diarreia,<br>glossite,<br>descoloração do dente, hepatotoxicidade, hepatite,<br>função hepática anormal, necrólise epidérmica tóxica,<br>síndrome de Stevens-Johnson, eritema multiforme,<br>dermatite esfoliativa, erupção fixa, hiperpigmentação<br>da pele, foto-onicólise, artralgia, mialgia, aumento da<br>concentração de ureia no sangue.|Aumento do efeito do<br>metotrexato. Reduz o<br>efeito da penicilina.<br>A<br>absorção<br>das<br>tetraciclinas<br>é<br>prejudicada<br>por<br>antiácidos<br>que<br>contenham<br>alumínio,<br>cálcio,<br>magnésio<br>ou<br>outros<br>medicamentos<br>que contenham estes<br>cátions, preparações que<br>contenham ferro ou sais<br>de bismuto.<br>O álcool, barbitúricos,<br>carbamazepina<br>e<br>fenitoína diminuem a<br>meia-vida<br>da<br>doxiciclina.<br>O uso concomitante de<br>tetraciclinas<br>e<br>metoxiflurano<br>pode<br>causar toxicidade renal<br>fatal.|
|sulfato<br>de<br>estreptomicina|Dermatite esfoliativa, exantema, urticária, desordens<br>da coagulação, eosinofilia, anemia hemolítica,<br>leucopenia, pancitopenia, trombocitopenia, anafilaxia,<br>reação de hipersensibilidade, parestesia facial,<br>bloqueio<br>neuromuscular,<br>paralisia<br>do<br>trato<br>respiratório,<br>fraqueza<br>muscular,<br>ototoxicidade,<br>nefrotoxicidade, febre, neuropatia periférica, perda<br>auditiva, hipoacusia, vertigem, nistagmo, distúrbios<br>eletrolíticos (hipopotassemia e hipomagnesemia).|Bloqueadores<br>neuromusculares:<br>aumento do risco de<br>bloqueio<br>neuromuscular.<br>Bumetanida:<br>risco<br>aumentado<br>de<br>ototoxicidade.|
|sulfato<br>de<br>gentamicina|Nefrotoxicidade e neurotoxicidade (efeitos ocorrem<br>mais frequentemente em pacientes com alteração da<br>função renal e nos tratados durante longos períodos ou<br>com doses mais altas que as recomendadas). Outros<br>eventos adversos possivelmente relacionadas à<br>gentamicina incluem: depressão respiratória, letargia,<br>confusão, depressão, distúrbios visuais, diminuição do<br>apetite, perda de peso, hipotensão e hipertensão;<br>erupções<br>cutâneas,<br>prurido,<br>urticária,<br>ardor<br>generalizado, edema laríngeo, reações anafilactoides,<br>febre, cefaleia; náusea, vômito, aumento da salivação,<br>estomatite; púrpura, pseudotumor cerebral, síndrome<br>orgânica cerebral aguda, fibrose pulmonar, alopecia,|O uso concomitante de<br>gentamicina<br>com<br>potentes<br>diuréticos,<br>como ácido etacrínico<br>ou<br>furosemida.<br>Uso<br>concomitante<br>e/ou<br>sequencial, tópico ou<br>sistêmico<br>de<br>outros<br>antibióticos<br>potencialmente<br>nefrotóxicos<br>e/ou<br>neurotóxicos deve ser<br>evitado.|  
20  
|**Medicamento**|**Principais eventos adversos**|**Interações moderadas**<br>**agraves**|
|---|---|---|
||dores<br>articulares,<br>hepatomegalia<br>transitória<br>e<br>esplenomegalia.||
|rifampicina|Redução na pressão arterial, edema, choque, necrólise<br>epidérmica tóxica, pênfigo, alopecia, eritroderma,<br>dermatite esfoliativa, rubor, inchaço, exantema,<br>porfiria aguda intermitente, insuficiência adrenal<br>aguda, hiperglicemia, hipotireoidismo, pancreatite,<br>colelitíase,<br>hemorragia<br>gastrintestinal,<br>colite<br>pseudomembranosa, cólicas, câimbras intestinais,<br>diarreia, náuseas, vômitos, desconforto gástrico, azia,<br>perda de apetite, agranulocitose, distúrbios de<br>coagulação,<br>hemólise<br>intravascular,<br>coagulação<br>intravascular<br>disseminada,<br>anemia<br>hemolítica,<br>leucopenia,<br>trombocitopenia,<br>hepatite,<br>hepatotoxicidade,<br>icterícia,<br>hiperbilirrubinemia,<br>elevação<br>das<br>enzimas<br>hepáticas,<br>reações<br>de<br>hipersensibilidade,<br>anafilaxia,<br>síndrome<br>lúpica,<br>miopatia, artralgia, mialgia, fraqueza muscular, ataxia,<br>confusão mental, tontura, cefaleia, sonolência,<br>hipestesia, xantocromia, dificuldade de concentração,<br>distúrbios visuais, irritação ocular, transtornos<br>psicóticos, alteração de comportamento, falência<br>renal, nefrotoxicidade, nefrite intersticial aguda,<br>câncer primário de pulmão, dispneia, chiado, fadiga,<br>febre, sintomas de gripe, dor nas extremidades, suor,<br>urina<br>avermelhada,<br>prurido,<br>trombocitopenia,<br>leucopenia, eosinofilia, agranulocitose, vasculite.|Ausentes.|
|sulfametoxazol<br>associado<br>à<br>trimetoprima|Náuseas,<br>vômito,<br>colite<br>pseudomembranosa,<br>pancreatite, estomatite, glossite, dor abdominal,<br>anorexia,<br>diarreia,<br>exantema,<br>urticária,<br>fotossensibilidade,  prurido, síndrome de Stevens-<br>Johnson,<br>necrólise<br>epidérmica<br>tóxica,<br>porfiria<br>intermitente aguda, hipoglicemia, agranulocitose,<br>anemia aplástica, anemia hemolítica, desordem no<br>sistema<br>hematopoiético,<br>neutropenia,<br>trombocitopenia,<br>leucopenia,<br>necrose<br>hepática<br>fulminante, reação de hipersensibilidade, cefaleia,<br>tontura, letargia, neurite periférica, ataxia, vertigem,<br>convulsões, alucinações, apatia, psicose, miopatia,<br>ototoxicidade, nefrotoxicidade, urolitíase.|Antiarrítmicos da classe<br>1A,<br>antidepressivos<br>tricíclicos;<br>varfarina,<br>didanosina e fenitoína.<br>gemifloxacino: aumento<br>do<br>risco<br>de<br>cardiotoxicidade.<br>leucovirina: aumento da<br>taxa<br>de<br>falha<br>no<br>tratamento.<br>metotrexato:<br>aumento<br>do risco de toxicidade<br>pirimetamina: aumento<br>do risco de anemia<br>megaloblástica<br>e<br>pancitopenia.<br>digoxina: aumento da<br>concentração plasmática<br>destas substâncias.|  
Fonte: Formulário Terapêutico Nacional<sup>_95_</sup> _._  
21  
<mark>ABORDAGEM DE PESSOAS EXPOSTAS ACIDENTALMENTE À BRUCELLA SP.</mark>

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **EXPOSIÇÃO ACIDENTAL** -->
A exposição acidental é considerada um evento prevalente, sobretudo em acidentes no contexto laboral<sup>104,105</sup> . Existem diferentes cenários de exposição acidental à brucelose humana, com destaque para laboratórios de análises clínicas, centros cirúrgicos e contextos de atuação do veterinário e outros profissionais auxiliares)<sup>104,105</sup> . A situação mais estudada é a exposição acidental em laboratórios, seja de análises clínicas, seja de manipulação/produção de vacinas para brucelose animal. Uma avaliação envolvendo 254 laboratórios dos Estados Unidos da América (EUA) que manipulavam a vacina RB51 identificou condições potencialmente de risco para exposição acidental à _Brucella_ sp. em grande parte deles. Ao todo, 916 trabalhadores estavam expostos, sendo 679 (74%) classificados com exposição de alto risco e 237 (26%) com exposição de baixo risco<sup>106</sup> , segundo os critérios de classificação de risco do _Centers for Disease Control and Prevention_ dos Estados Unidos da América (CDC)<sup>107</sup> .  
No Brasil, o contexto mais frequente de exposição a brucelose humana envolve a aplicação de vacina atenuada para brucelose em rebanhos, o que confere à doença um caráter ocupacional. Um estudo realizado em Minas Gerais apontou que 32,83% (108/329; IC95%: 27,78-38,19%) dos veterinários envolvidos na vacinação contra brucelose bovina em 2018 relataram ter sido acidentalmente expostos às cepas vacinais B19 ou RB51<sup>108</sup> .  
Destaca-se a exposição à _Brucella_ sp. em locais de manipulação de animais, tais como matadouros e frigoríficos. No Maranhão, um estudo de soro prevalência entre funcionários de matadouro revelou que 10,7%<sup>109</sup> dos trabalhadores tinham anticorpos contra _Brucella_ sp. Em Tocantins, em uma amostra de 645 trabalhadores de frigoríficos, trabalhadores rurais, médicos veterinários e estudantes de medicina veterinária, 26 (4,0%) apresentaram sorologia positiva para _B. abortus_<sup>110</sup> . Em laboratórios de análises clínicas, entre janeiro de 2019 e abril de 2020, três acidentes com _B. abortus_ foram notificados em Curitiba e envolveram 58 trabalhadores<sup>111</sup> . Casos semelhantes de brucelose humana adquirida em laboratórios clínicos já tinham sido previamente relatados no Brasil<sup>112</sup> .  
Quadro 3 - Tipos de acidentes que geram exposição à Brucella sp.  
|**Contexto**|**Tipo de**<br>**exposição**|**Descrição**|
|---|---|---|
|Ocupacional|Laboratorial|Contato direto ou indireto durante manuseio de amostras<br>clínicas, meios de cultura enriquecidos ou contaminados,<br>aerossóis e vacina (ambiente de produção) durante<br>manipulações dentro do laboratório.|
||Clínica|Exposição após manuseio de tecidos com concentrações<br>elevadas de cepas de_Brucella_sp. (por exemplo, tecidos<br>placentários), contato direto com sangue e fluidos corporais<br>infectados através de rupturas na pele ou exposição durante a<br>prestação de serviços de saúde de natureza clínica através do<br>contato<br>com<br>pacientes<br>infectados<br>e<br>realização<br>de<br>procedimentogerador de aerossol(médico,dentista e outros).|
||Cirúrgica|Exposição em salas de cirurgia após contato direto com<br>pacientes infectados durante procedimentos cirúrgicos ou<br>contato indireto após ocorrência de eventos geradores de<br>aerossóis, como: uso de serras ou outros dispositivos elétricos;<br>ressuscitação cardiopulmonar; projeção de gotículas da<br>secreção de um abcesso e irrigação de altapressão.|
||Veterinária|Vacina|  
22  
|**Contexto**|**Tipo de**<br>**exposição**|**Descrição**|
|---|---|---|
|||Exposição por meio de lesões provocadas por agulha/seringa<br>contendo cepas vacinais vivas e atenuadas de_Brucella_sp. e<br>após contato do_spray_da vacina com a conjuntiva/pele não<br>íntegra.|
|||Clínica|
|||Exposição após contato com secreções e partes de animais<br>infectados (placenta e líquidos) durante a rotina, coleta de<br>amostra em exames clínicos (sangue e urina), procedimentos<br>cirúrgicos, inalação de cepas de_Brucella_sp. em aerossóis e<br>desinfecção/limpeza de ambientes contaminados. O risco de<br>exposição é maior quando os profissionais trabalham com<br>animais abortados ou emprocesso departo.|
|Outras fontes|Recreacional|Exposição após atividade de caça de suínos selvagens. A<br>contaminação pode ocorrer por duas vias, contato direto com<br>o animal infectado ou através da ingestão de carne<br>contaminada.|
||Pessoa para<br>pessoa|-Transmissão neonatal.<br>-Transmissão sexual.<br>-Doação de órgãos e transfusão de sangue.|  
Fonte: adaptado de CDC<sup>55</sup> . Classificação do risco em caso de exposição à fonte contaminada com _Brucella_ sp _._  
Dentre as formas de exposição acidental, a única que conta com estratificação do risco de infecção e recomendação de abordagem preconizada pelo CDC<sup>107</sup> é a exposição em ambiente de laboratório.  
**<u>Exposição acidental em laboratório:</u>** O risco de infecção é categorizado em três níveis (risco mínimo, risco baixo e risco alto), com base no tipo de exposição (maior no caso de produção de aerossóis), local de manipulação (dentro ou fora de cabines de segurança) e proximidade da fonte de exposição. Os diferentes contextos que caracterizam os três níveis de exposição em laboratório foram apresentados pelo CDC<sup>113</sup> e sumarizados na **Figura 3.**  
23  
<!-- Start of picture text -->
cranes ia<br>Classe Il certificada, com EPI adequado.<br>‘Amostra clinica de<br>rotina®<br>Presenca em laboratério enquanto alguém manipula amostra clinica<br>de rotina® em CSB Classe Il certificada ou em bancada com<br>manipulagao que nao envolva aeross6is.<br>_Risco minimot<br>" Manipular material enriquecido® ou amostra clinica reprodutiva® em.<br>uma CSB Classe ll certificada com EPI adequado.<br>Material enriquecido®™<br>‘ou amostra clinica<br>reprodutiva® Presenga em laboratério enquanto alguém manipula material<br>° enriquecido® ou amostra clinica reprodutiva® em CSB Classe Il<br>8 certificada,<br>Z<br>3<br>3<br>S Material enriquecido® Presenca em laboratério a uma distancia >1,5 m de alguém que<br>reprodutiva uma bancada aberta sem eventos geradores de aerossdis.<br>2 Riscobaixo ———>| ou amostra clinica. —*|_ manipule material enriquecido® ou amostra clinica reprodutiva® em<br>o<br>4<br>3<br>is)<br>‘Amostra clinica de Manipular amostra clinica de rotina® resultando em contato com pele<br>peor ‘ou mucosas rompidas,certificada,independentecom ou sem deEPI trabalharadequado. em CSB Classe II<br>‘enriquecido® ou amestracnia reprodutva® fora deuma CSB<br>Classe Il certificada.<br>Reco Manipular (ou distancia < 1,5m de alguém que manipule) material<br>Material enriquecido® Manipular material enriquecido® ou amostra clinica reprodutiva®<br>= reprodutivaa dentro de uma CSB Classe Il certificada, sem EP! adequado.<br>‘Todos os presentes durante a ocorréncia de eventos geradores de<br>aerossdis” com manipulagao de material enriquecido® ou amostra<br>clinica reprodutiva® em uma bancada aberta.<br>“Risco minimo, mas nao zero.<br>Exemplo de amostra clinica de rotina: sangue; liquido cefalorraquidiano.<br>®Exemplo de material enriquecido: isolado de Brucella; frasco de sangue positivo.<br>CExemplo de amostra clinica reprodutiva: liquido amniético; produtos placentarios.<br>Eventos geradores de aerossdis: centrifugagao sem transportadores selados; vortex; sonificagao e acidentes que envolvam derramamento/respingos.<br><!-- End of picture text -->  
Figura 3 - Classificação de risco de exposição à _Brucella_ sp. em ambientes de laboratórios. Siglas: EPI: Equipamentos de Proteção Individual; CSB: Cabine de Segurança Biológica. Fonte: Adaptado de CDC<sup>55</sup> .  
**<u>Exposição acidental em outros ambientes:</u>** <u>Para todas as outras situações de exposição à</u> _Brucella_ sp., não se identifica estratificação de risco estabelecida na literatura. Em analogia à exposição no laboratório, recomenda-se os mesmos princípios fundamentais da avaliação de risco nos acidentes biológicos (fonte/espécime biológico, mecanismo de exposição e a presença ou não de condições atenuantes, como uso de equipamentos de proteção individual ou coletiva - EPI/EPC).  
Com base nesse racional, devem ser considerados indicativos de exposição de alto risco: a fonte confirmadamente contaminada por _Brucella_ sp. (qualquer espécime clínico) ou material reprodutivo com alta suspeita de contaminação, ou seja, para esse último caso, mesmo que sem confirmação definitiva da presença de _Brucella_ sp., desde que associado a um dos mecanismos de exposições abaixo ( **Figura 4** ):  
- Inoculação percutânea (intramuscular ou dérmica);  
- Contato direto do material contaminado ou vacina com mucosa ou pele não íntegra;  
24  
- Realização de procedimento gerador de aerossol (aspiração por sucção, nebulização). No  
- caso de procedimento gerador de aerossol, deve-se considerar exposto quem estiver muito próximo ao evento (uma distância menor de 1,5 metros).  
<!-- Start of picture text -->
Amostra, material enriquecido, manipulagao de érgao de animais e procedimentos com pessoas contaminadas<br>Exposicao direta Exposicao indireta<br>Uso adequado 7" Local fechado e<br>4 orb ce micine 7 buenode noaerossol gerador Bece bee<br>Contato com material Pessoa no local<br>confirmadamente © —— Pele integra ——  Risco baixo da manipulacao<br>contaminado N,<br>\ penton Cena goacor — Raa<br>ou mucosa<br>ele nao integra | Rscoato.| de aerossol<br>Goticulasintegraem pele Risco baixo<br>Contat P local Sem aerossol e<br>‘ontato com e808 no local pulverizacaio ou<br>avacina ~~ Inoculacéo, acidente da manipulacao contato com<br>com perfurocortante. —— a vacina<br>ou inalacéo<br><!-- End of picture text -->  
Figura 4 - Classificação de risco de exposição à Brucella sp. em diferentes contextos. Fonte: elaboração própria.  
25

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **PROFILAXIA PÓS-EXPOSIÇÃO EM ACIDENTES COM** **_BRUCELLA_ SP.** -->
O termo Profilaxia Pós-Exposição (PEP), originalmente do inglês _Post Exposure Prophylaxis,_ se aplica à intervenção para prevenir ou reduzir o risco de adquirir doenças infectocontagiosas após exposição a agentes patogênicos como vírus e bactérias. A partir da identificação de situação com risco potencial de infecção por um patógeno, a profilaxia com antimicrobianos pode ser avaliada, o que deve ser acompanhado por monitoramento clínico de sinais e sintomas e a vigilância de marcadores biológicos, quando disponíveis<sup>100</sup> .  
Após uma exposição à _Brucella_ sp., a decisão sobre antibioticoprofilaxia se baseia na ponderação do risco de adoecimento em relação à toxicidade estimada com os medicamentos. A caracterização da fonte e o contexto da exposição são os principais elementos da avaliação do risco de infecção. A exposição acidental em laboratório durante manipulação de material confirmadamente contaminado por _Brucella_ sp. é a situação com mais relatos de profilaxia<sup>114–121</sup> . Para outros contextos de exposição, incluindo o acidente durante a aplicação de vacinas<sup>122</sup> , há menos dados reunidos e menor consenso entre autoridades em saúde<sup>55</sup> .  
A busca na literatura para a eficácia das estratégias de profilaxia para a prevenção de adoecimento em pessoas expostas acidentalmente à _Brucella_ sp. não identificou estudos randomizados. Apenas oito estudos observacionais envolvendo 97 indivíduos foram incluídos, todos eles expostos acidentalmente em ambientes laboratoriais<sup>114–121</sup> . Em todos os estudos, a estratificação de risco adotada foi a preconizada pelo CDC, sendo a profilaxia com doxiciclina associada à rifampicina indicada para os casos avaliados como de alto risco de adquirir a infecção. Nessa revisão, a taxa estimada de adoecimento por brucelose humana após profilaxia foi de 0,01% (IC95% 0,00 a 0,07%,)<sup>123</sup> . Eventos adversos, principalmente gastrointestinais, ocorreram em 26% dos casos. A qualidade da evidência foi classificada como “muito baixa” já que a maioria dos estudos descrevia pequenas séries de casos, sem informações sobre as características da exposição, da população e principalmente das intervenções usadas<sup>114–121</sup> .  
Com exceção do ambiente laboratorial, para todos os outros contextos de exposição acidental à _Brucella_ sp., não são conhecidas evidências consistentes capazes de apontar as taxas de adoecimento após o acidente (sem profilaxia) ou a proteção conferida pela instituição de antibiótico, assim, as evidências disponíveis não suportam recomendação universal de PEP<sup>123</sup> . Baseado em séries de casos de adoecimento após exposição acidental em laboratório, morbidade estimada para a doença e dificuldade de confirmação diagnóstica, a recomendação do CDC<sup>55</sup> de uso de PEP para casos de alto risco de infecção foi aplicada ao contexto brasileiro e extrapolada para todos os acidentes de alto risco, em laboratório e outros contextos, conforme a **Figura 5** .  
26  
<!-- Start of picture text -->
E) | monn rover ae<br>PEP nao PEP nao PEP<br>sugerida sugerida sugerida<br>Monitoramento de<br>fonitoramento ‘sinais € sintomas +<br>Atencdo: Caso se verifique 0 aparecimento de sinais e sintomas compativeis com brucelose:<br>‘humana associado a sorologia positiva, considerar como caso suspeito e seguir fluxo diagnéstico::<br>Figura 1). :<br>“sExposicgo de baixo risco em gestantes e imunocomprometidos pode ter a PEP!<br>sfecomendada conforme avaliagéo médica sobre a relacao de riscos e beneficios. t<br><!-- End of picture text -->  
Figura 5 - Algoritmo de decisão para indicação de PEP. Fonte: elaboração própria.  
O esquema antimicrobiano para prevenção de brucelose após exposição mais descrito na literatura é baseado na combinação de doxiciclina e rifampicina por 21 dias. A antibioticoprofilaxia pode ser iniciada até 24 semanas após a exposição de risco alto. A recomendação de tratamento por 42 dias é reservada aos casos sintomáticos.  
Para pacientes com contraindicação à doxiciclina, a associação de sulfametoxazol + trimetoprima à rifampicina pode ser usada. Para exposições acidentais tendo como fonte a vacina baseada em cepa RB51, a rifampicina não deve ser incluída no esquema profilático, visto que esta cepa é resistente ao medicamento. Assim, o uso de doxiciclina em monoterapia é uma estratégia a ser considerada (  
**Quadro** 4).  
Quadro 4 - Esquemas de PEP para exposição acidental à Brucella sp.  
|**Esquema Padrão**|**Esquema alternativo**|**Esquema alternativo**<br>**(exposição à vacina com a**<br>**cepa RB51)**|
|---|---|---|  
27  
|cloridrato de doxiciclina|SMX+TMP 400 mg/80 mg +|cloridrato de doxiciclina 100|
|---|---|---|
|100 mg + rifampicina 300<br>mg12/12 horaspor 21 dias|rifampicina 300 mg 12/12<br>horaspor 21 dias|mg 12/12 horas por 21 dias|
|Legenda: SMX+TMP: sulfam|etoxazol associado à trimetoprima.||  
Pessoas expostas à _Brucella_ sp _.,_ independentemente da estratificação do risco de infecção, devem ser orientadas a manter o automonitoramento regular de sinais e sintomas compatíveis com brucelose humana, sendo especialmente alertadas em relação ao surgimento de febre e de mialgia, artralgia, sudorese e artrite. Pacientes que evoluírem com sinais e sintomas sugestivos de brucelose humana devem ser abordados conforme a seção 8.3 Diagnóstico laboratorial.  
Considerando a falta de evidência para a recomendação de antibioticoprofilaxia em contextos diferentes de laboratório de análises clínicas, uma abordagem alternativa seria o monitoramento sorológico para a detecção da condição “soroconversão recente” (ver seção de definições), especialmente quando o risco estimado for baixo. A soroconversão recente pode ser considerada como uma situação de alto risco de adoecimento, para qual há oportunidade de instituir intervenção profilática por 21 dias. Para permitir a interpretação dos resultados de sorologia durante o monitoramento após exposição acidental, recomenda-se a coleta de sangue para realização de testagem sorológica imediatamente ou até 14 dias após a exposição (sorologia basal). Esta primeira coleta é importante para que se reconheça a condição do indivíduo prévia à exposição. Ou seja, a positividade sorológica nessa avaliação basal deve ser interpretada como evidência de infecção ocorrida antes da exposição em avaliação.  
São indicativos de soroconversão recente<sup>55</sup> :  
- A elevação de quatro vezes ou mais do título de qualquer um dos testes sorológicos quantitativos e/ou,  
- A positividade dos dois métodos sorológicos (Rosa Bengala e Elisa total ou IgG), no caso de ambos os testes serem negativos ou discordantes (um positivo e outro negativo), na avaliação basal.  
O monitoramento sorológico (repetição periódica dos testes) após a exposição tem o objetivo de identificar a ocorrência de soroconversão. Após a coleta basal, a literatura indica a realização de monitoramento com repetição da sorologia periodicamente nos primeiros 6 meses após a exposição acidental, com intervalos de 6 semanas<sup>71</sup> . Considerando a oportunidade de rastreio de infecção recente e as particularidades dos sistemas de atenção à saúde no território brasileiro, a repetição de sorologia pode ocorrer com intervalos diferentes (2 a 6 semanas) dependendo do risco estimado e das condições de execução dos testes.  O monitoramento sorológico realizado em intervalos menores nos primeiros dois meses após a exposição acidental pode beneficiar a identificação de infecção recente<sup>124</sup> .  
Não há monitoramento sorológico disponível atualmente para exposições à RB51 e _B. canis_<sup>125,126</sup> , já que não se espera aparecimento de anticorpos tituláveis para os agentes envolvidos com os métodos sorológicos disponíveis. Nesses casos, o monitoramento recomendado para casos de alto risco que não receberam PEP permanece sendo apenas a vigilância clínica e, em caso de surgimento de sinais e sintomas compatíveis com brucelose humana, deve-se seguir o fluxo diagnóstico descrito na seção Diagnóstico laboratorial, realizando a investigação diagnóstica por exame de cultura.  
28

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: O -->
**Quadro** _5_ resume as orientações consensuadas para PEP baseadas em princípios de boa prática clínica, tendo em vista o contexto atual de inexistência de evidência.  
Quadro 5 - Síntese das orientações consensuadas para PEP baseadas em princípios de boa prática clínica.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Todos os expostos de risco baixo e risco alto:** -->
- Monitoramento de sinais e sintomas nos 6 meses seguintes à exposição: febre, calafrios, mialgia, sudorese, artralgia, artrite, astenia, fraqueza.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Expostos em uso de PEP:** -->
- Estimular e monitorar adesão à antibioticoprofilaxia.  
- Monitoramento clínico e laboratorial da toxicidade da PEP.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Expostos em monitoramento sorológico:** -->
- Testagem sorológica para avaliação da situação basal (imediatamente após o acidente, aceitável até duas semanas do acidente.  
Repetição da sorologia periodicamente nos primeiros 6 meses após a exposição, com intervalos de 2 a 6 semanas a ser individualizado dependendo do risco estimado e condições de execução dos testes.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Gestantes e imunocomprometidos:** -->
- Recomenda-se avaliação individualizada pelo obstetra (quando aplicável) ou médico responsável pelo acompanhamento da imunossupressão.  
Fonte: adaptado de CDC<sup>107</sup> .  
29

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **RESISTÊNCIA ANTIMICROBIANA** -->
De acordo com o Plano de Ação Nacional de Prevenção e Controle da Resistência aos Antimicrobianos no Âmbito da Saúde Única 2018-2022 (PAN-BR)<sup>127</sup> ,  é crucial monitorar a suscetibilidade de microrganismos aos antimicrobianos na saúde humana para avaliar tendências epidemiológicas.  
Diversos fatores podem contribuir para o desenvolvimento de resistência antimicrobiana, como o diagnóstico equivocado de doenças infecciosas, utilização de antimicrobianos de amplo espectro em prejuízo dos antimicrobianos de menor espectro que tratam doenças específicas, ausência de programas educativos sobre o tema e a utilização inadequada dos antimicrobianos. Essas ações potencializam as chances de um microrganismo se adaptar e reproduzir mesmo na presença de antimicrobianos, ao invés de terem seu crescimento inibido<sup>128</sup> .  
A atividade antimicrobiana de um agente pode ser avaliada pela determinação da menor concentração necessária para inibir o crescimento de um microrganismo, sendo essa medida denominada Concentração Inibitória Mínima (CIM). Uma ampla variação nos valores de CIM pode favorecer a observação de cepas resistentes, pois evidencia a heterogeneidade da população estudada. A primeira evidência de resistência à rifampicina associada a doxiciclina foi durante o tratamento de um paciente infectado com _B. melitensis_ em 1986<sup>129</sup> . Inicialmente, o paciente respondeu bem à terapia, mas após três meses da última dose dos medicamentos, relatou dores nas articulações e voltou a apresentar resultado positivo para _B. melitensis_ , com um aumento expressivo da CIM da rifampicina de 1,0 μg/mL para 64 μg/mL. Esta mesma cepa também apresentou resistência à ciprofloxacino, com um aumento da CIM de 0,08 μg/mL em isolados iniciais para 5,0 μg/mL em apenas três semanas após início do tratamento<sup>130</sup> .  
Na Arábia Saudita, uma análise retrospectiva de 160 casos de pacientes positivos para _Brucella_ sp., predominantemente infectados com a cepa _B. melitensis_ (93%), revelou resistência antimicrobiana de 29% para o sulfametoxazol + trimetoprima; 3,5% para a rifampicina; 0,6% para estreptomicina; e 0,6% para tetraciclina<sup>131</sup> . Este mesmo estudo mostrou que nenhum dos isolados de _B. abortus_ demonstrou resistência aos antimicrobianos testados. Posteriormente, novos estudos<sup>132,133</sup> realizados na Arábia Saudita corroboraram os achados sobre a resistência de cepas de _Brucella_ sp _._ ao sulfametoxazol + trimetoprima. Na Turquia<sup>134</sup> , Kuwait<sup>135</sup> e China<sup>136</sup> , também há registros de isolados de _B. melitensis_ resistentes à rifampicina, porém na China os resultados foram menos expressivos.  
O perfil de resistência mais frequentemente descrito na literatura é para a espécie _B. melitensis_ . Contudo, no Brasil, a infecção com _B. melitensis_ é mais rara e a maioria dos casos de brucelose humana estão relacionados à infecção por _B. abortus_ . Um estudo realizado pela Universidade Federal de Minas Gerais, com isolados de _Brucella_ sp. de seis estados brasileiros, revelou uma tendência de isolados de _B. abortus_ serem resistentes à rifampicina (alta frequência de amostras com susceptibilidade intermediária), ciprofloxacino, estreptomicina, gentamicina e sulfametoxazol + trimetoprima. Em contrapartida, todos os isolados testados foram sensíveis à doxiciclina e ofloxacina<sup>128</sup> .  
Embora a prevalência de resistência de _B. melitensis_ e _B. abortus_ aos aminoglicosídeos estreptomicina e gentamicina ainda seja baixa (2,7% IC95% 1,5 a 4,9; 2,3% IC95% 1,7 a 3,2, respectivamente), a resistência à gentamicina tem aumentado consideravelmente nos últimos anos, tornando-se um fator preocupante no contexto da saúde pública<sup>137</sup> . A estreptomicina é utilizada no tratamento de infecções como leptospirose, diarreia, mastite e pneumonia<sup>138</sup> . Já a gentamicina é amplamente utilizada para tratar mastite e, quando associada com clindamicina, é considerada padrão ouro no tratamento de endometrite pós-parto<sup>138</sup> . O acesso fácil a esses  
30  
medicamentos e a vasta indicação clínica favorecem o uso indiscriminado em bovinos e o desenvolvimento de resistência.  
Devido à resistência antimicrobiana relatada em estudos experimentais e a incapacidade de reduzir o nível de infecção, o uso da estreptomicina está contraindicado para infecções causadas pela cepa vacinal Rev 1 (cepa viva atenuada de _B. melitensis_ )<sup>139</sup> . No mesmo sentido, o uso da rifampicina não é recomendado para infecções causadas pela cepa vacinal RB51, uma vez que se trata de cepa intrinsecamente resistente ao medicamento<sup>140</sup> . Em 2015, Pauletti e colaboradores identificaram cepas de _B. abortus_ multirresistentes e uma proporção significativa de cepas com susceptibilidade reduzida à rifampicina no Brasil – 36,73% (54/147)<sup>141</sup> . Dessa forma, embora a rifampicina seja amplamente utilizada no tratamento de brucelose humana, a resistência é um fenômeno a ser monitorado.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **MONITORAMENTO** -->
O monitoramento da resposta ao tratamento da brucelose é baseado em critérios clínicos, além do desaparecimento da febre. Adicionalmente, provas inespecíficas inflamatórias (velocidade de hemossedimentação e dosagem de proteína C reativa) são úteis no controle da atividade da doença. O seguimento clínico após o término do tratamento deve ser de no mínimo um ano. Nos casos de reaparecimento de sinais e sintomas durante ou após o tratamento, deve-se seguir o fluxo de investigação apresentado na **Figura 1** .  
No caso de diagnóstico firmado com resultado de teste sorológico quantitativo positivo, recomenda-se a realização de sorologia por volta da 6<sup>a</sup> semana de tratamento ou até duas semanas após seu término. Não existe recomendação para estender ou repetir tratamento em função de qualquer título na reação sorológica se o paciente estiver assintomático ou em melhora clínica. Caso o paciente apresente recrudescência de sinais e sintomas da doença, pode haver aumento no título de anticorpos anti- _Brucella_ em comparação com seu valor ao fim do tratamento. Por outro lado, a ausência de elevação do título da reação sorológica não afasta o diagnóstico de recidiva, que pode se basear em critérios clínicos.  
A vigilância da toxicidade do tratamento e da PEP deve ser realizada por meio de monitoramento laboratorial e clínico, com periodicidade individualizada de acordo com as manifestações da doença, tratamento prescrito, especificidades do paciente e esquema antimicrobiano escolhido ( **Quadro 6** ).  
Quadro 6 - Monitoramento de pacientes em tratamento da brucelose ou expostos acidentalmente em uso de PEP.  
|**Condição**|**Etapa (Período)**|**Monitoramento**|
|---|---|---|
|Caso<br>confirmado de<br>brucelose|Durante<br>o<br>tratamento<br>(Semanas 1 a 6)|-<br>Testagem sorológica (basal)<br>-<br>Tratamento: Avaliação clínica + exames<br>complementares de acordo com esquema em uso<br>(avaliação individualizada).|
||Após o tratamento<br>(12 meses)|-<br>Automonitoramento de sintomas.|
|Indivíduo com<br>exposição|Em uso de PEP|-<br>Testagem sorológica (basal).|  
31  
|**Condição**|**Etapa (Período)**|**Monitoramento**|
|---|---|---|
|acidental<br>à||-<br>Avaliação clínica + exames complementares|
|_Brucella_sp.||durante o uso de PEP de acordo com esquema em<br>uso (avaliação individualizada).|
|||-<br>Automonitoramento de sintomas por 6<br>meses.|  
Fonte: adaptado de CDC<sup>126</sup> .  
O  
**Quadro 7** elenca aspectos para monitoramento de pacientes em tratamento da brucelose humana em uso de aminoglicosídeos.  
Quadro 7 - Aspectos para monitoramento de pacientes em tratamento da brucelose humana.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Pacientes em uso de aminoglicosídeos podem requerer monitoramento especial, considerando o estado clínico e a evolução do tratamento**<sup>142</sup> **:**<sup>116</sup> : -->
- Administração diária de aminoglicosídeo deve contemplar o monitoramento da função  
- renal e concentração sérica do aminoglicosídeo em pacientes com insuficiência renal.  
- Avaliação de sinais de ototoxicidade durante o uso de aminoglicosídeos: tontura,  
- vertigens, ataxia, zumbidos, ruídos no ouvido e diminuição da audição.  
- Avaliação do oitavo par craniano durante o tratamento, principalmente em pacientes  
- com insuficiência renal suspeita ou conhecida.  
32

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Os casos de brucelose confirmados, mas sem gravidade clínica, e indivíduos expostos acidentalmente à _Brucella_ sp. devem ser avaliados no âmbito da Atenção Primária à Saúde (APS). Em áreas com alta incidência documentada ou alto risco estimado, deve-se promover educação continuada com envolvimento das especialidades afins, clínica médica, pediatria, infectologia e obstetrícia, além da saúde do trabalhador. Além da disseminação dos métodos de transmissão e prevenção da infecção, e da diversidade de apresentação clínica da doença, deve-se garantir a divulgação dos fluxos estabelecidos para a realização dos exames complementares e acesso aos medicamentos para tratamento e profilaxia.  
A atenção em serviço especializado ou hospitalar deve ser especialmente recomendada para casos graves, pessoas com comorbidades, imunossuprimidos, crianças, gestantes e aqueles com as formas complicadas da doença (como a neurobrucelose, endocardite e demais formas de acometimento articular),  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo. Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas atuais.  
**Este Protocolo padroniza o diagnóstico, tratamento e uso da profilaxia pósexposição para a brucelose humana para gestores e profissionais de saúde no âmbito do SUS. Assim, as condutas terapêuticas preconizadas pelo PCDT substituem as orientações anteriores do Ministério da Saúde publicadas por meio de diretrizes, manuais, cadernos, guias e outros documentos relacionados, os quais devem ser considerados desatualizados.**  
33

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **REFERÊNCIAS** -->
1.         Dean, A. S., Crump, L., Greter, H., Schelling, E. & Zinsstag, J. Global Burden of Human Brucellosis: A Systematic Review of Disease Frequency. _PLoS Negl Trop Dis_ **6** , e1865– e1865 (2012).  
2. Pappas, G., Papadimitriou, P., Akritidis, N., Christou, L. & Tsianos, E. V. The new global map of human brucellosis. _Lancet Infect Dis_ **6** , 91–99 (2006).  
3. Corbel, M. J. _Brucellosis in Humans and Animals_ . (World Health Organization, 2006).  
4. Laine, C. G., Scott, H. M. & Arenas-Gamboa, A. M. Human brucellosis: Widespread information deficiency hinders an understanding of global disease frequency. _PLoS Negl Trop Dis_ **16** , e0010404–e0010404 (2022).  
5. Bosilkovski, M., Edwards, M. S. & Calderwood, S. B. Brucellosis: epidemiology, microbiology, clinical manifestations, and diagnosis. _Uptodate, United States_ (2019).  
6. Laine, C. G., Johnson, V. E., Scott, H. M. & Arenas-Gamboa, A. M. Global estimate of human brucellosis incidence. _Emerg Infect Dis_ **29** , 1789 (2023).  
7. Bourdette, M. D. S. & Sano, E. Características Epidemiológicas da Brucelose Humana no Brasil no período 2014-2018. _Revista Cereus_ **15** , 27–40 (2023).  
8. Santa Catarina. Secretaria de Estado de Santa Catarina. Superintendência de Vigilância em Saúde. Diretoria de Vigilância Epidemiológica. Gerência de Vigilância de Zoonoses, A. por A. P. e D. T. por V. Protocolo Estadual de Brucelose Humana - Manejo Clínico e Vigilância em Saúde. _https://dive.sc.gov.br/phocadownload/doencas-_  
- _agravos/Brucelose/Publica%C3%A7%C3%B5es/1%20-_  
- _%20Protocolo%20estadual%20de%20brucelose%20humana%20-_  
- _%20Manejo%20Cl%C3%ADnico%20e%20Vigil%C3%A2ncia%20em%20Sa%C3%BAde.pdf_ 1–38 Preprint at (2019).  
9. Paraná. Secretaria de Estado da Saúde do Paraná. Superintendência de Vigilância em Saúde. Protocolo de manejo clínico e vigilância em saúde para brucelose humana no Estado do Paraná. – Curitiba: SESA/SVS/CEVA. _https://www.saude.pr.gov.br/sites/default/arquivos_restritos/files/documento/202004/protocolobrucelose2018.pdf_ 1–96 Preprint at (2018).  
10. Tocantins. Portaria/SESAU n<sup>o</sup> 1.482, de 18 de dezembro de 2015. Define a relação de doenças e agravos de notificação compulsória de interesse para o Estado do Tocantins. Diário Oficial do Estado do Tocantins. 10 de Março de 2016.p.17.  
11. Roraima. Comissão Intergestores Bipartite/RO. RESOLUÇÃO N<sup>o</sup> 301/13 – CIB / RO. (2013).  
12. Minas Gerais. Secretaria de Estado de Saúde de Minas Gerais. Coordenação de Zoonoses Vigilância de Fatores de Riscos Biológicos. Atualização nas orientações das ações da vigilância da brucelose humana. _http://vigilancia.saude.mg.gov.br/index.php/saude-do-trabalhador/_ (2021).  
13. Bernardi, F. _et al._ Epidemiological characterization of notified human brucellosis cases in Southern Brazil. _Rev Inst Med Trop Sao Paulo_ **64** , e38 (2022).  
14. Lemos, T. S. _et al._ Outbreak of human brucellosis in Southern Brazil and historical review of data from 2009 to 2018. _PLoS Negl Trop Dis_ **12** , e0006770 (2018).  
34  
15. Corbel, M. J. Brucellosis: an overview. _Emerg Infect Dis_ **3** , 213 (1997).  
16. Lilia Guzman-Hernandez, R., Contreras-Rodriguez, A., Daniel Avila-Calderon, E. & Rosario Morales-Garcia, M. Brucellosis: a zoonosis of importance in Mexico. _Revista Chilena de Infectologia_ **33** , 656–662 (2016).  
17. Tuon, F. F., Gondolfo, R. B. & Cerchiari, N. Human‐to‐human transmission of Brucella–a systematic review. _Tropical Medicine & International Health_ **22** , 539–546 (2017).  
18. Dias, E. C. & Almeida, I. M. Doenças relacionadas ao trabalho: manual de procedimentos para os serviços de saúde. Brasília: Ministério da Saúde do Brasil (2001).  
19. Pereira, C. R. _et al._ Occupational exposure to Brucella spp.: A systematic review and metaanalysis. _PLoS Negl Trop Dis_ **14** , 1–19 (2020).  
20. Yagupsky, P. Preventing laboratory-acquired brucellosis in the era of MALDI-TOF technology and molecular tests: A narrative review. _Zoonotic Diseases_ **2** , 172–182 (2022).  
21. Yagupsky, P. Neonatal brucellosis: rare and preventable. _Ann Trop Paediatr_ **30** , 177–179 (2010).  
22. Giannacopoulos, I., Eliopoulou, M. I., Ziambaras, T. & Papanastasiou, D. A. Transplacentally transmitted congenital brucellosis due to Brucella abortus. _J Infect_ **45** , 209–210 (2002).  
23. Kato, Y. _et al._ Brucellosis in a Returned Traveler and His Wife: Probable Person‐To‐Person Transmission of Brucella melitensis. _J Travel Med_ **14** , 343–345 (2007).  
24. Mantur, B. G., Mangalgi, S. & Mulimani, M. Brucella melitensis—a sexually transmissible agent? _The lancet_ **347** , 1763 (1996).  
25. Wood, E. E. Brucellosis as a hazard of blood transfusion. _Br Med J_ **1** , 27 (1955).  
26. Tikare, N. V, Mantur, B. G. & Bidari, L. H. Brucellar meningitis in an infant—evidence for human breast milk transmission. _J Trop Pediatr_ **54** , 272–274 (2008).  
27. Palanduz, A., Palanduz, S., Guler, K. & Guler, N. Brucellosis in a mother and her young infant: probable transmission by breast milk. _International journal of infectious diseases_ **4** , 55 (2000).  
28. Lubani, M., Sharda, D. & Helin, I. Probable transmission of brucellosis from breast milk to a newborn. _Trop Geogr Med_ **40** , 151–152 (1988).  
29. Arenas-Gamboa, A. M. _et al._ Human brucellosis and adverse pregnancy outcomes. Curr Trop Med Rep 3: 164–172. Preprint at (2016).  
30. Ali, S. _et al._ Brucellosis in pregnant women from Pakistan: an observational study. _BMC Infect Dis_ **16** , 1–6 (2016).  
31. Dean, A. S. _et al._ Clinical manifestations of human brucellosis: a systematic review and metaanalysis. _PLoS Negl Trop Dis_ **6** , e1929 (2012).  
32. Mantur, B. G., Amarnath, S. K. & Shinde, R. S. Review of clinical and laboratory features of human brucellosis. _Indian J Med Microbiol_ **25** , 188–202 (2007).  
33. Young, E. J. Brucellosis: current epidemiology, diagnosis, and management. _Curr Clin Top Infect Dis_ **15** , 115–128 (1995).  
34. Bosilkovski, M. _et al._ Osteoarticular involvement in childhood brucellosis: experience with 133 cases in an endemic region. _Pediatr Infect Dis J_ **32** , 815–819 (2013).  
35  
35. Bosilkovski, M., Krteva, L., Caparoska, S. & Dimzova, M. Osteoarticular involvement in brucellosis: study of 196 cases in the Republic of Macedonia. _Croat Med J_ (2004).  
36. Araj, G. F. Update on laboratory diagnosis of human brucellosis. _Int J Antimicrob Agents_ **36** , S12–S17 (2010).  
37. Meechan, P. J. & Potts, J. Biosafety in microbiological and biomedical laboratories. (2020).  
38. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento do Complexo Industrial e Inovação em Saúde. Classificação de Risco Dos Agentes Biológicos, (Brasília, 2022).  
39. Yagupsky, P., Morata, P. & Colmenero, J. D. Laboratory diagnosis of human brucellosis. _Clin Microbiol Rev_ **33** , 10–1128 (2019).  
40. Skalsky, K. _et al._ Treatment of human brucellosis: systematic review and meta-analysis of randomised controlled trials. _Bmj_ **336** , 701–704 (2008).  
41. Yousefi‐Nooraie, R., Mortaz‐Hejri, S., Mehrani, M. & Sadeghipour, P. Antibiotics for treating human brucellosis. _Cochrane Database of Systematic Reviews_ (2012) doi:10.1002/14651858.CD007179.pub2.  
42. BRASIL. Ministério da Saúde. _Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas_ . (Brasília, 2016).  
43. Guyatt, G. H. _et al._ GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. _BMJ_ **336** , 924–926 (2008).  
44. Liu, Z. _et al._ Different Clinical Manifestations of Human Brucellosis in Pregnant Women: A Systematic Scoping Review of 521 Cases from 10 Countries. _Infect Drug Resist_ **13** , 1067–1079 (2020).  
45. Khazaei, S. _et al._ Epidemiology of human brucellosis in Nahavand county, Hamadan Province, western Iran: an 8-year (2010–2017) registry-based analysis. _Asian Biomedicine_ **14** , 151–158 (2020).  
46. Al Shaalan, M. _et al._ Brucellosis in children: clinical observations in 115 cases. _International journal of infectious diseases_ **6** , 182–186 (2002).  
47. Mantur, B. G. _et al._ Childhood brucellosis—a microbiological, epidemiological and clinical study. _J Trop Pediatr_ **50** , 153–157 (2004).  
48. Tanir, G., Tufekci, S. B. & Tuygun, N. Presentation, complications, and treatment outcome of brucellosis in Turkish children. _Pediatrics International_ **51** , 114–119 (2009).  
49. Al Hashan, G. M. _et al._ Pattern of childhood brucellosis in Najran, south Saudi Arabia in 2013– 2017. _Electron Physician_ **9** , 5902 (2017).  
50. Parlak, M. _et al._ Clinical manifestations and laboratory findings of 496 children with brucellosis in V an, T urkey. _Pediatrics International_ **57** , 586–589 (2015).  
51. Dashti, A. S. & Karimi, A. Skeletal involvement of Brucella melitensis in children: a systematic review. _Iran J Med Sci_ **38** , 286 (2013).  
52. Galvão, E. L. _et al._ Treatment of Childhood Brucellosis: A Systematic Review. _Pediatr Infect Dis J_ 10–1097.  
36  
53. Niebyl, J. R. Antibiotics and other anti-infective agents in pregnancy and lactation. _Am J Perinatol_ **20** , 405–414 (2003).  
54. Yefet, E. _et al._ The safety of quinolones and fluoroquinolones in pregnancy: a meta‐analysis. _BJOG_ **125** , 1069–1076 (2018).  
55. Centers for Disease Control and Prevention. Brucellosis Reference Guide: Exposures, Testing, And Prevention. 1–40 Preprint at (2017).  
56. Jiang, H., Feng, L. & Lu, J. Updated Guidelines for the Diagnosis of Human Brucellosis — China, 2019. _China CDC Wkly_ **2** , 487–489 (2020).  
57. Mousa, A. R. M., Elbag, K. M., Kbogali, M. & Marafie, A. A. The nature of human brucellosis in Kuwait: study of 379 cases. _Rev Infect Dis_ **10** , 211–217 (1988).  
58. Kitt, E. _et al._ A case report of pediatric brucellosis in an Algerian immigrant. in _Open forum infectious diseases_ vol. 4 ofw263 (Oxford University Press US, 2017).  
59. Al Shamahy, H. A. & Wright, S. G. A study of 235 cases of human brucellosis in Sana’a, Republic of Yemen. _EMHJ-Eastern Mediterranean Health Journal, 7 (1-2), 238-246, 2001_ (2001).  
60. Zheng, R. _et al._ A systematic review and meta‐analysis of epidemiology and clinical manifestations of human brucellosis in China. _Biomed Res Int_ **2018** , 5712920 (2018).  
61. World Health Organization. Brucellosis. _https://www.who.int/news-room/factsheets/detail/brucellosis_ (2020).  
62. Pappas, G., Akritidis, N., Bosilkovski, M. & Tsianos, E. Brucellosis. _New England Journal of Medicine_ **352** , 2325–2336 (2005).  
63. Roushan, M. R. H., Mohrez, M., Gangi, S. M. S., Amiri, M. J. S. & Hajiahmadi, M. Epidemiological features and clinical manifestations in 469 adult patients with brucellosis in Babol, Northern Iran. _Epidemiol Infect_ **132** , 1109–1114 (2004).  
64. Castano, M. J. & Solera, J. Chronic brucellosis and persistence of Brucella melitensis DNA. _J Clin Microbiol_ **47** , 2084–2089 (2009).  
65. Galinska, E. M. & Zagórski, J. Brucellosis in humans-etiology, diagnostics, clinical forms. _Annals of agricultural and environmental medicine_ **20** , (2013).  
66. Trujillo, I. Z., Zavala, A. N., Caceres, J. G. & Miranda, C. Q. Brucellosis Infect Dis Clin North Am, 8 (1994). _View PDF View article View in Scopus_ 225–241.  
67. Gray, B. M., Evans, A. & Brachman, P. Bacterial infections of humans: epidemiology and control. Preprint at (1991).  
68. Doganay, M. & Aygen, B. Human brucellosis: an overview. _International Journal of Infectious Diseases_ **7** , 173–182 (2003).  
69. Bukhari, E. E. Pediatric brucellosis: an update review for the new millennium. _Saudi Med J_ **39** , 336 (2018).  
70. Bosilkovski, M., Krteva, L., Dimzova, M. & Kondova, I. Brucellosis in 418 patients from the Balkan Peninsula: exposure-related differences in clinical manifestations, laboratory test results, and therapy outcome. _International journal of infectious diseases_ **11** , 342–347 (2007).  
71. Pappas, G. _et al._ Brucellosis and the respiratory system. _Clinical Infectious Diseases_ **37** , e95–e99 (2003).  
37  
72. Espinosa, B. J. _et al._ Comparison of culture techniques at different stages of brucellosis. _Am J Trop Med Hyg_ **80** , 625–627 (2009).  
73. Mangalgi, S. & Sajjan, A. Comparison of three blood culture techniques in the diagnosis of human brucellosis. _J Lab Physicians_ **6** , 14–17 (2014).  
74. Alsayed, Y. & Monem, F. Brucellosis laboratory tests in Syria: what are their diagnostic efficacies in different clinical manifestations? _The Journal of Infection in Developing Countries_ **6** , 495–500 (2012).  
75. Hajia, M. _et al._ Comparison of methods for diagnosing brucellosis. _Lab Med_ **44** , 29–33 (2013).  
76. Freire, M. L., Machado de Assis, T. S., Silva, S. N. & Cota, G. Diagnosis of human brucellosis: Systematic review and meta-analysis. _PLoS Negl Trop Dis_ **18** , e0012030 (2024).  
77. Landry, M. L. Immunoglobulin M for acute infection: true or false? _Clinical and Vaccine Immunology_ **23** , 540–545 (2016).  
78. Takahashi, H. _et al._ An unusual case of brucellosis in Japan: difficulties in the differential diagnosis from pulmonary tuberculosis. _Internal medicine_ **35** , 310–314 (1996).  
79. Ulu Kilic, A., Metan, G. & Alp, E. Clinical presentations and diagnosis of brucellosis. _Recent Pat Antiinfect Drug Discov_ **8** , 34–41 (2013).  
80. Guler, S. _et al._ Human brucellosis in Turkey: different clinical presentations. _The Journal of Infection in Developing Countries_ **8** , 581–588 (2014).  
81. Esmaeilnejad-Ganji, S. M. & Esmaeilnejad-Ganji, S. M. R. Osteoarticular manifestations of human brucellosis: a review. _World J Orthop_ **10** , 54 (2019).  
82. Solís García del Pozo, J. & Solera, J. Systematic review and meta-analysis of randomized clinical trials in the treatment of human brucellosis. _PLoS One_ **7** , e32090 (2012).  
83. Huang, S. _et al._ Better efficacy of triple antibiotics therapy for human brucellosis: A systematic review and meta-analysis. _PLoS Negl Trop Dis_ **17** , e0011590 (2023).  
84. Silva, S. N. _et al._ Efficacy and safety of therapeutic strategies for human brucellosis: A systematic review and network meta-analysis. _PLoS Negl Trop Dis_ **18** , e0012010 (2024).  
85. Majzoobi, M. M., Hashmi, S. H., Emami, K. & Soltanian, A. R. Combination of doxycycline, streptomycin and hydroxychloroquine for short-course treatment of brucellosis: a single-blind randomized clinical trial. _Infection_ **50** , 1267–1271 (2022).  
86. Majzoobi, M. M. _et al._ Effect of hydroxychloroquine on treatment and recurrence of acute brucellosis: a single-blind, randomized clinical trial. _Int J Antimicrob Agents_ **51** , 365–369 (2018).  
87. de Jesus Lawinsky, M. L., Ohara, P. M., da Rosa Elkhoury, M., do Carmo Faria, N. & Cavalcante, K. R. L. J. Estado da arte da brucelose em humanos. _Rev Panamazonica Saude_ **1** , 10 (2010).  
88. Pappas, G., Siozopoulou, V., Akritidis, N. & Falagas, M. E. Doxycycline–rifampicin: Physicians’ inferior choice in brucellosis or how convenience reigns over science. _Journal of Infection_ **54** , 459–462 (2007).  
89. Pappas, G. _et al._ Health literacy in the field of infectious diseases: the paradigm of brucellosis. _Journal of Infection_ **54** , 40–45 (2007).  
90. Sánchez, A. R., Rogers III, R. S. & Sheridan, P. J. Tetracycline and other tetracycline‐derivative staining of the teeth and oral cavity. _Int J Dermatol_ **43** , 709–715 (2004).  
38  
91. Inan, A. _et al._ Brucellosis in pregnancy: results of multicenter ID-IRI study. _Eur J Clin Microbiol Infect Dis_ **38** , 1261–1268 (2019).  
92. Roushan, M. R. H., Baiani, M., Asnafi, N. & Saedi, F. Outcomes of 19 pregnant women with brucellosis in Babol, northern Iran. _Trans R Soc Trop Med Hyg_ **105** , 540–542 (2011).  
93. Khan, M. Y., Mah, M. W. & Memish, Z. A. Brucellosis in pregnant women. _Clin Infect Dis_ **32** , 1172–1177 (2001).  
94. Yu, P. A. _et al._ Safety of antimicrobials during pregnancy: a systematic review of antimicrobials considered for treatment and postexposure prophylaxis of plague. _Clinical Infectious Diseases_ **70** , S37–S50 (2020).  
95. Brasil. Ministério da Saúde. MedSUS. _https://www.gov.br/pt-br/apps/medsus_ .  
96. Roushan, M. R. H. _et al._ Efficacy of gentamicin plus doxycycline versus streptomycin plus doxycycline in the treatment of brucellosis in humans. _Clinical infectious diseases_ **42** , 1075–1080 (2006).  
97. Roushan, M. R. H. _et al._ Comparison of the efficacy of gentamicin for 5 days plus doxycycline for 8 weeks  versus streptomycin for 2 weeks plus doxycycline for 45 days in the treatment of human brucellosis: a randomized clinical trial. _J Antimicrob Chemother_ **65** , 1028–1035 (2010).  
98. Bosilkovski, M., Krteva, L., Caparoska, S., Labacevski, N. & Petrovski, M. Childhood brucellosis: Review of 317 cases. _Asian Pac J Trop Med_ **8** , 1027–1032 (2015).  
99. El-Amin, E. O. _et al._ Brucellosis in children of Dhofar Region, Oman. _Saudi Med J_ **22** , 610–615 (2001).  
100. Zamani, A. _et al._ Epidemiological and clinical features of Brucella arthritis in 24 children. _Ann Saudi Med_ **31** , 270–273 (2011).  
101. Sánchez-Tamayo, T. _et al._ Failure of short-term antimicrobial therapy in childhood brucellosis. _Pediatr Infect Dis J_ **16** , 323–324 (1997).  
102. Brasil. Ministério da Saúde. Ampliação de uso dos medicamentos doxiciclina, estreptomicina e rifampicina para o tratamento da brucelose humana. _Disponível em: https://www.gov.br/conitec/pt-_  
- _br/midias/relatorios/2017/relatorio_doxiciclinaestreptomicinarifampicina_brucelose_final.pdf_ (2017).  
103. Bac-Sulfitrin solução injetável. Anápolis: Brainfarma Indústria Química e Farmacêutica S.A; 2.  bula de medicamento. Disponível em: https://www.gov.br/anvisa/pt-br/sistemas/bularioeletronico. (2021).  
104. Memish, Z. A. & Mah, M. W. Brucellosis in laboratory workers at a Saudi Arabian hospital. _Am J Infect Control_ **29** , 48–52 (2001).  
105. Sophie, R., Michael, L., Marcel, B. & Earl, R. Prevention of laboratory-acquired brucellosis. _Clinical Infectious Diseases_ **38** , e119–e122 (2004).  
106. Centers for Disease Control and Prevention (CDC). Update: potential exposures to attenuated vaccine strain Brucella abortus RB51 during a laboratory proficiency test--United States and Canada, 2007. _MMWR Morb Mortal Wkly Rep_ **57** , 36–39 (2008).  
107. Centers for Disease Control and Prevention (CDC). Assessing Laboratory Risk Level & PEP. _https://www.cdc.gov/brucellosis/laboratories/risk-level.html_ (2018).  
39  
108. Pereira, C. R. _et al._ Accidental exposure to Brucella abortus vaccines and occupational brucellosis among veterinarians in Minas Gerais state, Brazil. _Transbound Emerg Dis_ **68** , 1363–1376 (2021).  
109. Pereira Santos, H. _et al._ Brucelose bovina e humana diagnosticada em matadouro municipal de São Luís-MA, Brasil. _Ciência Veterinária nos Trópicos_ **10** , 86–94 (2007).  
110. Ramos, T. R. R. _et al._ Epidemiological aspects of an infection by Brucella abortus in risk occupational groups in the microregion of Araguaina, Tocantins. _Brazilian Journal of Infectious Diseases_ **12** , 133–138 (2008).  
111. Tuon, F. F., Cequinel, J. C., da Silva Nogueira, K. & Becker, G. N. Brucella Laboratory Exposures in Brazil: Rare or Unnoticed? _Am J Trop Med Hyg_ **103** , 2528 (2020).  
112. Rodrigues, A. L. C., Silva, S. K. L. da, Pinto, B. L. A., Silva, J. B. da & Tupinambás, U. Outbreak of laboratory-acquired Brucella abortus in Brazil: a case report. _Rev Soc Bras Med Trop_ **46** , 791– 794 (2013).  
113. Centers for Disease Control and Prevention (CDC). Laboratory-acquired brucellosis--Indiana and Minnesota, 2006. _MMWR Morb Mortal Wkly Rep_ **57** , 39–42 (2008).  
114. Castrodale, L. J. _et al._ A case-study of implementation of improved strategies for prevention of laboratory-acquired brucellosis. _Saf Health Work_ **6** , 353–356 (2015).  
115. Miendje Deyi, V. Y. _et al._ Staggered enforcement of infection control and prevention measures following four consecutive potential laboratory exposures to imported Brucella melitensis. _Infection Prevention in Practice_ **3** , (2021).  
116. Maley, M. W., Kociuba, K. & Chan, R. C. Prevention of laboratory-acquired brucellosis: Significant side effects of prophylaxis [3]. _Clinical Infectious Diseases_ **42** , 433–434 (2006).  
117. Reddy, S. _et al._ Brucellosis in the UK: A risk to laboratory workers? Recommendations for prevention and management of laboratory exposure. _J Clin Pathol_ **63** , 90–92 (2010).  
118. Sam, I.-C. _et al._ A large exposure to Brucella melitensis in a diagnostic laboratory. _J Hosp Infect_ **80** , 321–325 (2012).  
119. Traxler, R. M. _et al._ Review of brucellosis cases from laboratory exposures in the United States in 2008 to 2011 and improved strategies for disease prevention. _J Clin Microbiol_ **51** , 3132–3136 (2013).  
120. Wong, C., Ng, S. Y. & Tan, S. H. An accidental laboratory exposure to Brucella melitensis: The prospective post-exposure management and a detailed investigation into the nature of the exposure. _J Med Microbiol_ **67** , 1012–1016 (2018).  
121. Nichols, M. _et al._ Brucella abortus Exposure during an Orthopedic Surgical Procedure in New Mexico, 2010. _Infect Control Hosp Epidemiol_ **35** , 1072–1073 (2014).  
122. Ashford, D. A. _et al._ Adverse events in humans associated with accidental exposure to the livestock brucellosis vaccine RB51. _Vaccine_ **22** , 3435–3439 (2004).  
123. Nascimento Silva, S. _et al._ Efficacy of antibiotic prophylaxis to preventing brucellosis in accidental exposure: A systematic review. _Tropical Medicine & International Health_ **29** , 454– 465 (2024).  
124. Al Dahouk, S. & Nöckler, K. Implications of laboratory diagnosis on brucellosis therapy. _Expert Rev Anti Infect Ther_ **9** , 833–845 (2011).  
40  
125. Cossaboom, C. M. _et al._ Notes from the field: Brucella abortus vaccine strain RB51 infection and exposures associated with raw milk consumption—Wise County, Texas, 2017. _Morbidity and Mortality Weekly Report_ **67** , 286 (2018).  
126. National Center for Emerging and Zoonotic Infectious Diseases (U.S.). Brucellosis reference guide : exposures, testing and prevention. Preprint at https://stacks.cdc.gov/view/cdc/46133 (2017).  
127. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Plano de ação nacional de prevenção e controle da resistência aos antimicrobianos no âmbito da saúde única 2018-2022 (PAN-BR). _https://bvsms.saude.gov.br/bvs/publicacoes/plano_prevencao_resistencia_antimicrobianos.pdf_ Preprint at (2019).  
128. Pauletti, R. B. susceptibilidade de isolados brasileiros de brucella abortus a agentes antimicrobianos utilizados no tratamento da brucelose humana. [Dissertação]. Belo Horizonte: Escola de veterinária, Universidade Federal de Minas Gerais; 2010. 51 s. Mestrado em Ciência Animal.  
129. De Rautlin de la Roy, Y. M. et al., Grignon, B., Grollier, G., Coindreau, M. F. & Becq-Giraudon, B. Rifampicin resistance in a strain of Brucella melitensis after treatment with doxycycline and rifampicin. Journal of Antimicrobial Chemotherapy 18, 648–649 (1986).  
130. Al-Sibai, M. B. & Qadri, S. M. H. Development of ciprofloxacin resistance in Brucella melitensis. _Journal of Antimicrobial Chemotherapy_ **25** , 302–303 (1990).  
131. Memish, Z., Mah, M. W., Al Mahmoud, S., Al Shaalan, M. & Khan, M. Y. Brucella bacteraemia: clinical and laboratory observations in 160 patients. _Journal of infection_ **40** , 59–63 (2000).  
132. Almuneef, M. _et al._ Brucella melitensis Bacteremia in Children: Review of 62 Cases. _Journal of Chemotherapy_ **15** , 76–80 (2003).  
133. Bannatyne, R. M., Rich, M. & Memish, Z. A. Co-trimoxazole resistant Brucella. _J Trop Pediatr_ **47** , 60 (2001).  
134. Baykam, N. _et al._ In vitro antimicrobial susceptibility of Brucella species. _Int J Antimicrob Agents_ **23** , 405–407 (2004).  
135. Dimitrov, T. S. _et al._ Incidence of bloodstream infections in a speciality hospital in Kuwait: 8- year experience. _Medical Principles and Practice_ **14** , 417–421 (2005).  
136. Liu, Z. _et al._ In vitro antimicrobial susceptibility testing of human Brucella melitensis isolates from Ulanqab of Inner Mongolia, China. _BMC Infect Dis_ **18** , 1–6 (2018).  
137. Moradkasani, S., Goodarzi, F., Beig, M., Tadi, D. A. & Sholeh, M. Prevalence of Brucella melitensis and Brucella abortus aminoglycoside-resistant isolates: a systematic review and metaanalysis. _Brazilian Journal of Microbiology_ 1–11 (2024).  
138. Abutarbush, S. M. Veterinary medicine—a textbook of the diseases of cattle, horses, sheep, pigs and goats. _The Canadian veterinary journal_ **51** , 541 (2010).  
139. Grilló, M. J. _et al._ Efficacy of several antibiotic combinations against Brucella melitensis Rev 1 experimental infection in BALB/c mice. _Journal of Antimicrobial Chemotherapy_ **58** , 622–626 (2006).  
41  
140. Schurig, G. G. _et al._ Biological properties of RB51; a stable rough strain of Brucella abortus. _Vet Microbiol_ **28** , 171–188 (1991).  
141. Barbosa Pauletti, R. _et al._ Reduced susceptibility to Rifampicin and resistance to multiple antimicrobial agents among Brucella abortus isolates from cattle in Brazil. _PLoS One_ **10** , e0132532 (2015).  
142. Le, T. A. _et al._ Aminoglycoside-Related Nephrotoxicity and Ototoxicity in Clinical Practice: A Review of Pathophysiological Mechanism and Treatment Options. _Adv Ther_ **40** , 1357–1365 (2023).  
42

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Escopo e finalidade do Protocolo** -->
O presente Apêndice consiste no documento de trabalho do grupo elaborador da elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Brucelose Humana contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DGITIS/SECTICS/MS. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade. O painel de especialistas incluiu médicos infectologistas e biólogo e farmacêutico envolvidos com o diagnóstico da doença.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
O processo de elaboração do PCDT para Brucelose Humana iniciou-se com uma reunião de escopo realizada virtualmente com o uso de videoconferência, no dia 25 de novembro de 2022 às 14:00 horas. A reunião teve como objetivo estabelecer o Escopo do PCDT da Brucelose Humana e foi organizada pelo Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS). Estiveram presentes representantes de áreas técnicas do Ministério da Saúde, do grupo de assessoria do Hospital Moinhos de Vento; do grupo elaborador e especialistas externos convidados.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do Protocolo, conforme o processo geral de desenvolvimento de diretrizes clínicas para o Sistema Único de Saúde (SUS).  
O objetivo desse PCDT foi elaborar um documento de abrangência nacional com recomendações para o diagnóstico, tratamento e abordagem da exposição acidental à brucelose humana, tema com muitas lacunas de evidência que não apresenta padrões consolidado para o SUS e promove muita variabilidade da prática clínica. Assim, este documento é direcionado aos profissionais de saúde que atuam na atenção primária ou especializada à saúde, alinhada aos preceitos fundamentais do SUS e com foco na promoção do cuidado oportuno e qualificado à população com Brucelose Humana, baseado na melhor evidência científica disponível.  
Foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT conforme a Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>42</sup> . Durante a reunião de escopo deste PCDT, as lacunas sobre brucelose humana foram mapeadas em três grandes grupos: diagnóstico, tratamento e profilaxia. A partir disso, foram debatidas na proposta de escopo ações específicas para cada grupo. Para o diagnóstico, a proposta de escopo incluiu uma revisão sistemática abrangente da literatura (sem limitação por comparador ou por tecnologia) e avaliação da possibilidade de realizar análise estratificada por espécie de _Brucella_ e forma clínica (aguda e crônica). Para o tratamento terapêutico, foi proposta a realização de uma revisão sistemática com ênfase nos esquemas identificados como de interesse (comparador a ser seguido pelo grupo técnico do Ministério da Saúde) e a possibilidade de uma análise estratificada por subgrupos clínicos (agudo e crônico). E, por último, a proposta de escopo para Profilaxia Pós-  
43  
Exposição que incluiu revisão sistemática abrangente da literatura sem restrição por desenho de estudo e a avaliação de pertinência de uma análise estratificada por tipo de exposição e espécies de _Brucella_ .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Etapas do processo de elaboração** -->
A proposta inicial de elaboração do PCDT da Brucelose Humana foi inicialmente discutida durante a reunião de pré-escopo, ocorrida em 23/09/2022. A reunião teve a presença de metodologistas e especialista do Grupo Elaborador, representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS) e Secretaria de Vigilância em Saúde e Ambiente (SVSA).  
Posteriormente, o escopo do documento foi discutido na reunião de escopo, ocorrida em 25/11/2022. A reunião teve a presença de metodologistas e especialista do Grupo Elaborador, metodologistas do HMV, representantes da SECTICS e SVSA, de sociedades médicas, especialistas convidados e contou com a apresentação de relatos de representantes de pacientes (contatos realizados previamente).  
Foram elaboradas perguntas PICO para as dúvidas clínicas e tecnologias que necessitariam de avaliação pela Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Após levantamento inicial das evidências pelo Grupo Elaborador, elas foram apresentadas em reunião ocorrida em 12/12/2022, com a presença de metodologistas do Grupo Elaborador e do HMV e representantes da SECTICS. A partir das evidências encontradas, as perguntas de pesquisa a serem respondidas foram priorizadas e validadas.  
Foram conduzidas ainda, reuniões de recomendações sobre o fluxo diagnóstico (em 01/09/2023 e 11/09/2023) e sobre o tratamento (em 11/10/2023) da Brucelose Humana, que também contaram com a participação das áreas do Ministério da Saúde, grupo elaborador, HMV e especialistas externos convidados.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Colaboração externa -->
O Protocolo foi atualizado pelo NATS-IRR (Instituto René Rachou – Fiocruz Minas), sob tutoria do NATS do Hospital Moinhos de Vento.  
Os participantes das reuniões de elaboração do referido PCDT estão descritos no **Quadro**  
**A** .  
Quadro A. Participantes das reuniões virtuais.  
|**Participante**|
|---|
|Alexander Vargas|
|Andreza Carine Gonçalves Pedro|
|Ávila Teixeira Vidal|  
44  
|**Participante**|
|---|
|Cinara Stein**|
|Cintia Laura Pereira de Araujo**|
|Denizard Andre de Abreu Delfino|
|Gideane Mendes de Oliveira|
|Edvar Yuri Pacheco Schubach|
|Endi Lanza Galvão**|
|Felipe Francisco Bondan Tuon*|
|Francisco Edilson Ferreira de Lima Júnior|
|Gilson Pires Dorneles**|
|Giselli Coelho Duarte|
|Glaucia Fernandes Cota**|
|Guilherme Geraldo Lovato Sório*|
|Guilherme Nardi Becker*|
|Illian de Freitas e Felix de Sousa|
|Janaína de Pina Carvalho**|
|Kathiaja Miranda Souza**|
|Lorenza Nogueira Campos Dezanet**|
|Marcelo Daniel Segalerba Bourdette|
|Marcelo Yoshito Wada|
|Marcos Vinicius da Silva*|
|Maria Juliana Rocha Reis|
|Mariana Lourenço Freire**|
|Marina Gonçalves de Freitas**|
|Marta da Cunha Lobo Souto Maior|
|Mell Ferreira Saliba**|
|Nathalia Siqueira Sardinha da Costa|
|Natiela Beatriz de Oliveira|
|Patrícia de Abreu Teixeira|
|Rejane Maria de Souza Alves|
|Rodrigo Menna Barreto Rodrigues|
|Sarah Nascimento Silva**|
|Stéfani Sousa Borges|
|SuelySanae Kashino*|
|Suena Medeiros Parahiba**|
|Tália Santana Machado de Assis**|
|Thais Conceição Borges|
|Thais Piazza de Melo|
|Verônica Colpani**|  
*Membros votantes na reunião de escopo e/ou recomendação; **Metodologistas.  
45

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Declaração e Manejo de Conflitos de Interesse -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro B** ).  
Quadro B. Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar fi|nanceiramente|
|---|---|
|algum dos benefícios abaixo?||
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>( ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>( ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>( ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>( ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>( ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>( ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma<br>forma ser beneficiada ouprejudicada com as recomendações da diretriz?|(   ) Sim<br>( ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de<br>marca,royalties)de alguma tecnologia ligada ao tema da diretriz?|(   ) Sim<br>( ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cu<br>possam ser afetadospela sua atividade na elaboração ou revisão da diretriz?|jos interesses|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>( ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>( ) Não|
|d) Partido político|(   ) Sim<br>( ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>( ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>( ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>( ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos<br>interessespossam ser afetados?|(   ) Sim<br>( ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer<br>oquevocê irá escrever eque deveria ser do conhecimentopúblico?|(   ) Sim<br>( ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja<br>relacionado acima, quepossa afetar sua objetividade ou imparcialidade?|(   ) Sim<br>( )Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos<br>conflitos listados acima?|(   ) Sim<br>( )Não|  
46  
O resumo dos conflitos de interesse dos membros do Grupo Elaborador está na **Quadro C** .  
Quadro C. Declaração de conflitos de interesse dos membros do Grupo Elaborador do PCDT e tutoria.  
|**Ptiit**|**Conflit**|**os de interesses declarados**|**Decisão**|
|---|---|---|---|
|**arcpane**|**Questão**|**Descrição geral**|**tomada**|
|Beatriz Prado Noronha|<br>-|<br>Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Cinara Stein|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Cintia Laura Pereira de Araujo|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Endi Lanza Galvão|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Felipe Francisco Bondan Tuon*|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Gilson Pires Dorneles|5e|Membro da Sociedade<br>Brasileira de Imunologia<br>(SBI)|Declarar e<br>participar|
|Glaucia Fernandes Cota|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Guilherme Geraldo Lovato Sório|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Guilherme Nardi Becker|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Janaína de Pina Carvalho|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Kathiaja Miranda Souza|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Lorenza Nogueira Campos Dezanet|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Marcos Vinicius da Silva|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Mariana Lourenço Freire|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Marina Gonçalves de Freitas|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Marina Petrasi Guahnon|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Mell Ferreira Saliba|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Sarah Nascimento Silva|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Suely Sanae Kashin|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Suena Medeiros Parahiba|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|
|Tália Santana Machado de Assis|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|  
47  
|**Particiante**|**Conflit**|**os de interesses declarados**|**Decisão**|
|---|---|---|---|
|**p**|**Questão**|**Descrição geral **|**tomada**|
|Verônica Colpani|-|Declarou não possuir conflito<br>de interesse|Declarar e<br>participar|

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A versão preliminar do texto do PCDT da Brucelose Humana foi pautada na 119ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas. Participaram desta reunião representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). Não foram considerações sobre a necessidade de alterações no documento, e o texto foi aprovado para apreciação pelo Comitê de PCDT da Conitec.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Consulta Pública** -->
A Consulta Pública nº 79/2024, do Protocolo Clínico e Diretrizes Terapêuticas da Brucelose Humana, foi realizada entre os dias 22/11/2024 e 12/12/2024. Foram recebidas 2 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/CP_CONITEC_079_2024_Protocolo_Clnico_e.pdf.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Busca da evidência e recomendações** -->
A busca da evidência foi desenvolvida conforme metodologia preconizada pela Diretrizes Metodológicas de Elaboração de Revisão Sistemática e Meta-análise do Ministério da Saúde, que preconiza o uso do sistema GRADE. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO (população; intervenção; comparador; _outcomes_ [desfechos]) ou PIRO (população; teste índice, teste de referência, _outcomes_ [desfechos]), de acordo com o tipo de revisão, se de intervenção ou de acurácia.  
A partir do escopo cinco questões de pesquisa foram levantadas, conforme **Quadro D** .  
Quadro D. Perguntas de pesquisa elencadas para elaboração do PCDT de brucelose humana  
|**Pergunta de pesquisa**|
|---|
|1) Qual é a melhor estratégia diagnóstica para brucelose humana a ser oferecida pelo sistema<br>nacional de laboratóriospúblicos no Brasil?|
|2) A combinação de doxiciclina + sulfato de gentamicina é tão eficaz e segura quanto<br>a doxiciclina + sulfato de estreptomicina no tratamento da brucelose humana?|
|3) Qual é a eficácia e a segurança da terapia com antimicrobiano para o tratamento da<br>brucelose humana em crianças com até 10anos de idade?*|  
48  
4) Qual é a eficácia e a segurança de esquemas de antimicrobianos para o tratamento da Brucelose Humana em gestantes?  
<u>5) Qual a eficácia do uso de antimicrobianos após exposição acidental à</u> _Brucella_ _<u>sp.</u>_ ?  
*Pergunta atualizada após a elaboração do escopo devido aos encaminhamentos do painel de especialista.  
O Grupo Elaborador ficou responsável pela busca e avaliação das evidências realizando uma busca sistematizada da literatura nas bases dados _MEDLINE_ (via _PubMed_ ), _Embase_ (via Periódicos Capes), LILACs (via Biblioteca Virtual de Saúde) e _Cochrane Library_ . Além disso, foram realizadas buscas manuais nas listas de referências das revisões sistemáticas já publicadas para as perguntas clínicas de interesse e pesquisa em bases de registros de estudos clínicos (www.clinicaltrials.gov e REBEC- www.ensaiosclinicos.gov.br), quando necessário.  
Os registros obtidos nas diferentes bases de dados foram importados para o gerenciador de referências _Mendeley_<sup>143</sup> , para exclusão das duplicatas e, posteriormente, para o programa _Rayyan_<sup>144</sup> , para triagem, categorização e seleção dos títulos e resumos das publicações, processo realizado por dois revisores de forma independente.  
O risco de viés dos artigos de avaliação de acurácia dos testes diagnósticos para brucelose humana incluídos na revisão sistemática foi avaliado pela ferramenta Quadas-2<sup>145</sup> . Para ensaios clínicos randomizados, o risco de viés para cada desfecho foi avaliado a partir da ferramenta _Revised Tool for Assessing Risk of Bias in Randomized Trials_ (RoB 2.0), por duas pesquisadoras de forma independente e pareada<sup>146</sup> . Ademais, a avaliação do risco de viés nesta revisão utilizou as ferramentas da JBI para a verificação de séries de casos e estudos de coorte<sup>147</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Recomendações** -->
Conforme recomendações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>42</sup> , utilizou-se o sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ) para a realizar a avaliação da qualidade da evidência e força de recomendação<sup>148</sup> . De forma sintética, a evidência foi graduada como alta, moderada, baixa e muito baixa, com observância dos critérios de rebaixamento ( _downgrade)_ da qualidade (limitações metodológicas, evidência indireta, inconsistência, imprecisão de estimativa de efeito e risco de viés de publicação) ou de elevação da qualidade (forte associação, gradiente doseresposta, fatores de confusão com ação inversa à direção do efeito<sup>148</sup> . Posteriormente, ainda de acordo com a Metodologia GRADE, foi construída a tabela _Evidence to Decision_ (EtD), que sumariza os principais achados do processo de avaliação da tecnologia segundo aspectos que devem ser levados em consideração no momento de tomada de decisão sobre a incorporação do produto (magnitude do problema, benefícios, danos, balanço entre danos e benefícios, certeza na evidência, aceitabilidade, viabilidade de implementação, uso de recursos, custo-efetividade, equidade, valores e preferências dos pacientes)<sup>149,150</sup> .  
Foram realizados três painéis de especialistas respectivamente em outubro, novembro e dezembro de 2023, a fim de estabelecer as recomendações por meio da análise da tabela EtD e julgamento dos painelistas, sendo todos os dados registrados nos formulários disponibilizados na plataforma GRADE-pro.  
A relatoria das seções do PCDT foi realizada pelo grupo elaborador apoiada pelos especialistas. Foram inseridas as recomendações realizadas pelo painel, literatura já consolidada sobre o assunto e formulados pontos de boas práticas para recomendações que ainda permaneceram com lacunas de evidências.  
49

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **QUESTÃO 1: Qual é a melhor estratégia diagnóstica para brucelose humana a ser oferecida pelo sistema nacional de laboratórios públicos no Brasil?** -->
**Recomendação:** Recomenda-se que a brucelose humana seja diagnosticada através dos testes de Rosa Bengala, ELISA IgG/IgM e PCR (certeza da evidência muito baixa, recomendação condicional).  
A estrutura PIRO para esta pergunta foi:  
**População:** pacientes com suspeita de brucelose humana.  
**Teste índice:** qualquer teste diagnóstico para brucelose humana (teste padrão de aglutinação em tubo, rosa bengala, ensaio imunoenzimático, imunocromatografia de fluxo lateral, teste de _Coombs_ e reação em cadeia da polimerase).  
**Teste de referência:** cultura (preferencialmente) ou outro teste laboratorial desde que claramente especificado.  
**Desfechos:** sensibilidade e especificidade.  
**Desenho de estudo:** estudos originais de acurácia diagnóstica.  
A pergunta de pesquisa foi assim formulada: Qual é a acurácia de testes para o diagnóstico de casos suspeitos de brucelose humana?  
A resposta para essa pergunta foi obtida por meio de revisão sistemática da literatura, em que foram analisadas as evidências científicas disponíveis de desempenho dos testes diagnósticos para brucelose humana.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Métodos e Resultados da Busca** -->
Foi realizada busca sistematizada da literatura nas bases de dados _Medline_ , _Embase_ , _Cochrane Library_ e BVS até 06 de janeiro de 2023. As estratégias de busca para cada base estão descritas no **Quadro E.**  
Quadro E. Estratégias de busca, de acordo com a base de dados, para identificação de estudos de acurácia dos testes diagnósticos para brucelose humana  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE|**População:**|1.492|
|(via|**#1**<br>(Brucellosis[MeSH<br>Terms])<br>OR<br>(Brucellosis)<br>OR||
|Pubmed)|(Brucelloses) OR (Malta Fever) OR (Fever, Malta) OR<br>(Gibraltar Fever) OR (Fever, Gibraltar) OR (Rock Fever) OR||
||(Fever, Rock) OR (Cyprus Fever) OR (Fever, Cyprus) OR<br>(Brucella Infection) OR (Brucella Infections) OR (Infection,||  
50  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Brucella) OR (Undulant Fever) OR (Fever, Undulant) OR<br>(Brucella abortus) OR (Brucella canis) OR (Brucella melitensis)<br>OR (Brucella ovis) OR (Brucella suis)||
||**Teste índice:**<br>**#2**(Serologic Tests[MeSH Terms]) OR (Serologic Tests) OR<br>(Serological Tests) OR (Serological Test) OR (Test, Serological)<br>OR (Tests, Serological) OR (Tests, Serologic) OR (Serologic<br>Test)<br>OR<br>(Test,<br>Serologic)<br>OR<br>(Serodiagnosis)<br>OR<br>(Serodiagnoses) OR (Fluorescent Antibody Technique[MeSH<br>Terms])<br>OR<br>(Fluorescent<br>Antibody<br>Technique)<br>OR<br>(Immunofluorescence) OR (Technics, Fluorescent Antibody)<br>OR (Technic, Fluorescent Antibody) OR (Fluorescent Antibody<br>Technics) OR (Antibody Technics, Fluorescent) OR (Antibody<br>Technic, Fluorescent) OR (Fluorescent Antibody Technic) OR<br>(Techniques, Immunofluorescence) OR (Immunofluorescence<br>Techniques)<br>OR<br>(Immunofluorescence<br>Technique)<br>OR<br>(Immunofluorescence Technics) OR (Immunofluorescence<br>Technic) OR (Antibody Technique, Fluorescent) OR (Antibody<br>Techniques, Fluorescent) OR (Enzyme-Linked Immunosorbent<br>Assay[MeSH Terms]) OR (Enzyme-Linked Immunosorbent<br>Assay) OR (Assay, Enzyme-Linked Immunosorbent) OR<br>(Assays, Enzyme-Linked Immunosorbent) OR (Enzyme Linked<br>Immunosorbent Assay) OR (Enzyme-Linked Immunosorbent<br>Assays) OR (Immunosorbent Assay, Enzyme-Linked) OR<br>(Immunosorbent Assays, Enzyme-Linked) OR (ELISA) OR<br>(Agglutination Tests[MeSH Terms]) OR (Agglutination Tests)<br>OR (Agglutination Test) OR (Test, Agglutination) OR (Tests,<br>Agglutination) OR (Rose Bengal[MeSH Terms]) OR (Rose<br>Bengal) OR (Bengal, Rose) OR (Rapid Diagnostic Tests[MeSH<br>Terms]) OR (Rapid Diagnostic Tests) OR (Diagnostic Test,<br>Rapid) OR (Diagnostic Tests, Rapid) OR (Rapid Diagnostic<br>Test) OR (Rapid Diagnostics) OR (Diagnostic, Rapid) OR<br>(Diagnostics, Rapid) OR (Rapid Diagnostic) OR (Molecular<br>Diagnostic<br>Techniques[MeSH<br>Terms])<br>OR<br>(Molecular<br>Diagnostic Techniques) OR (Diagnostic Technique, Molecular)<br>OR (Diagnostic Techniques, Molecular) OR (Molecular<br>Diagnostic Technique) OR (Technique, Molecular Diagnostic)<br>OR (Techniques, Molecular Diagnostic) OR (Molecular<br>Diagnostic Technics) OR (Diagnostic Technic, Molecular) OR<br>(Molecular Testing) OR (Testing, Molecular) OR (Polymerase<br>Chain Reaction[MeSH Terms]) OR (Polymerase Chain<br>Reaction) OR (Polymerase Chain Reactions) OR (Reaction,<br>Polymerase Chain) OR (Reactions, Polymerase Chain) OR<br>(PCR)||
||**Desfecho:**<br>**#3**<br>((sensitiv*[Title/Abstract]<br>OR<br>sensitivity<br>and<br>specificity[MeSH Terms] OR diagnose[Title/Abstract] OR<br>diagnosed[Title/Abstract] OR diagnoses[Title/Abstract] OR||  
51  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||diagnosing[Title/Abstract] OR diagnosis[Title/Abstract] OR<br>diagnostic[Title/Abstract] OR diagnosis[MeSH:noexp] OR<br>(diagnostic<br>equipment[MeSH:noexp]<br>OR<br>diagnostic<br>errors[MeSH:noexp] OR diagnostic imaging[MeSH:noexp] OR<br>diagnostic<br>services[MeSH:noexp])<br>OR<br>diagnosis,<br>differential[MeSH:noexp] OR diagnosis[Subheading:noexp]))<br>OR ((specificity[Title/Abstract]))<br>**#4**#1 AND #2 AND #3 AND humans[Filter]||
|EMBASE|**População:**<br>**#1**('brucellosis'/exp OR 'brucella infection' OR 'brucella<br>melitensis infection' OR 'malta fever' OR 'mediterranean fever<br>(brucellosis)' OR 'brucellosis' OR 'infection by brucella' OR<br>'infection by brucella melitensis' OR 'infection due to brucella'<br>OR 'infection due to brucella melitensis' OR 'melitococcosis' OR<br>'undulant fever' OR 'brucella'/exp OR 'brucella' OR 'brucella<br>contamination' OR 'brucella abortus'/exp OR 'brucella abortus'<br>OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR<br>'brucella abortus sensitivity' OR 'brucella canis'/exp OR 'brucella<br>melitensis'/exp OR 'brucella melitensis' OR 'micrococcus<br>melitensis' OR 'brucella ovis'/exp OR 'brucella ovis' OR 'brucella<br>suis'/exp OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis')|2.604|
||**Teste índice:**<br>**#2**('serology'/exp OR 'serologic reaction' OR 'serologic<br>specificity' OR 'serologic survey' OR 'serologic technique' OR<br>'serologic test' OR 'serologic tests' OR 'serological characteristic'<br>OR 'serological specificity' OR 'serological test' OR 'serology'<br>OR<br>'immunofluorescence'/exp<br>OR<br>'i.f.'<br>OR<br>'immune<br>fluorescence' OR 'immune fluorescence technique' OR<br>'immunofluorescence' OR 'immunofluorescence technique' OR<br>'immunofluorescent<br>technique'<br>OR<br>'indirect<br>immunofluorescence' OR 'enzyme linked immunosorbent<br>assay'/exp OR 'elisa' OR 'enzyme labeled immunosorbent assay'<br>OR 'enzyme linked immunoassay' OR 'enzyme linked<br>immunosorbent assay' OR 'enzyme linked immunospecific<br>assay' OR 'enzyme-linked immune assay' OR 'enzyme-linked<br>immuno-assay' OR 'enzyme-linked immunosorbent assay' OR<br>'agglutination test'/exp OR<br>'agglutination reaction' OR<br>'agglutination test' OR 'agglutination tests' OR 'agglutinin test'<br>OR 'test, agglutination' OR 'rose bengal'/exp OR 'bengal rose'<br>OR 'bengal rose stain' OR 'bengal rose staining' OR 'rose bengal'<br>OR 'rose bengal b' OR 'rose bengal disodium' OR 'rose bengal<br>sodium' OR 'rose bengale' OR 'rapid diagnostic test'/exp OR<br>'molecular diagnosis'/exp OR 'molecular diagnosis' OR<br>'molecular diagnostic' OR 'molecular diagnostic techniques' OR<br>'polymerase chain reaction'/exp OR 'pcr (polymerase chain<br>reaction)' OR 'polymerase chain reaction')||  
52  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||**Desfecho:**<br>**#3**('sensitivity and specificity'/exp OR 'sensitivity and<br>specificity' OR 'specificity and sensitivity' OR 'sensitivity'/exp<br>OR 'specificity'/exp OR 'diagnosis'/exp OR 'bacteriologic<br>diagnosis' OR 'diagnosis' OR 'diagnostic screening' OR<br>'diagnostic screening programs' OR 'diagnostic sign' OR<br>'diagnostic tool' OR 'diagnostics' OR 'disease diagnosis' OR<br>'medical diagnosis' OR 'physical diagnosis' OR 'true positive<br>result'/exp OR 'true negative result'/exp OR 'predictive<br>value'/exp OR 'negative predictive value' OR 'positive predictive<br>value' OR 'predictive value' OR 'predictive value of tests')<br>**#4**#1 AND #2 AND #3 AND [humans]/lim AND [embase]/lim||
|Cochrane<br>Library|**População:**<br>**#1**MeSH descriptor: [Brucellosis] explode all trees<br>**#2**'brucellosis' OR 'brucella infection' OR 'brucella melitensis<br>infection' OR 'malta fever' OR 'mediterranean fever (brucellosis)'<br>OR 'brucellosis' OR 'infection by brucella' OR 'infection by<br>brucella melitensis' OR 'infection due to brucella' OR 'infection<br>due to brucella melitensis' OR 'melitococcosis' OR 'undulant<br>fever' OR 'brucella' OR 'brucella abortus' OR 'brucella abortus'<br>OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR<br>'brucella abortus sensitivity' OR 'brucella melitensis' OR<br>'brucella canis' OR 'brucella canis' OR 'brucella canidis' OR<br>'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella<br>melitensis biovar suis' OR 'brucella melitensisbv. suis' OR<br>'brucella suis'|27|
||**Teste índice:**<br>**#3**MeSH descriptor: [Serologic Tests] explode all trees<br>**#4**MeSH descriptor: [Fluorescent Antibody Technique] explode<br>all trees<br>**#5**MeSH descriptor: [Enzyme-Linked Immunosorbent Assay]<br>explode all trees<br>**#6**MeSH descriptor: [Agglutination Tests] explode all trees<br>**#7**MeSH descriptor: [Rose Bengal] explode all trees<br>**#8**MeSH descriptor: [Molecular Diagnostic Techniques]<br>explode all trees<br>**#9**MeSH descriptor: [Polymerase Chain Reaction] explode all<br>trees<br>**#10**’serology' OR 'serologic reaction' OR 'serologic specificity'<br>OR 'serologic survey' OR 'serologic technique' OR 'serologic<br>test' OR 'serologic tests' OR 'serological characteristic' OR<br>'serological specificity' OR 'serological test' OR 'serology' OR<br>'fluorescent antibody technique' OR 'antibody fluorescent<br>technique' OR 'antibody, fluorescent' OR 'fluorescence antibody<br>technique' OR 'fluorescence antibody test' OR 'fluorescence<br>antiglobulin test' OR 'fluorescent antibody' OR 'fluorescent<br>antibody<br>darkfield<br>method'<br>OR<br>'fluorescent<br>antibody||  
53  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||identification' OR 'fluorescent antibody method' OR 'fluorescent<br>antibody technique' OR 'fluorescent antibody test' OR<br>'fluorescent<br>inhibition<br>technique'<br>OR<br>'enzyme<br>linked<br>immunosorbent assay' OR 'rose bengal' OR 'agglutination test'<br>OR 'agglutination reaction' OR 'agglutination test' OR<br>'agglutination tests' OR 'agglutinin test' OR 'test, agglutination'<br>OR 'molecular diagnostics' OR 'gene expression assay kit' OR<br>'gene expression test kit' OR 'genetic assay kit' OR 'genetic test<br>kit' OR 'molecular diagnostic test kit' OR 'molecular diagnostics'<br>OR 'polymerase chain reaction' OR 'pcr (polymerase chain<br>reaction)' OR 'polymerase chain reaction'<br>**#4**(#1 OR #2) AND #3||
||**Desfecho:**<br>**#11**MeSH descriptor: [Sensitivity and Specificity] explode all<br>trees<br>**#12**MeSH descriptor: [Diagnosis] explode all trees<br>**#13**('sensitivity and specificity' OR 'sensitivity and specificity'<br>OR 'specificity and sensitivity' OR 'sensitivity' OR 'specificity'<br>OR 'diagnosis' OR 'bacteriologic diagnosis' OR 'diagnosis' OR<br>'diagnostic screening' OR 'diagnostic screening programs' OR<br>'diagnostic sign' OR 'diagnostic tool' OR 'diagnostics' OR<br>'disease diagnosis' OR 'medical diagnosis' OR 'physical<br>diagnosis' OR 'true positive result' OR 'true negative result' OR<br>'predictive value' OR 'negative predictive value' OR 'positive<br>predictive value' OR 'predictive value' OR 'predictive value of<br>tests')<br>**#14**(#1 OR #2) AND (#3 OR #4 OR #5 OR #6 OR #7 OR #8<br>OR #9 OR #10) AND (#11 OR #12 OR #13)||
|BVS|**População:**<br>**#1**(mh:(Brucelose)) OR (Brucelose) OR (mh:(Brucellosis)) OR<br>(Brucellosis) OR (mh:(Brucelosis)) OR (Brucelosis) OR (Febre<br>Ondulante) OR (Febre de Malta) OR (Infecçãopor Brucella) OR<br>(mh:(Brucella)) OR (Brucella) OR (mh:(Brucella abortus)) OR<br>(Brucella abortus) OR (Bacterium abortus) OR (mh:(Brucella<br>canis )) OR (Brucella canis ) OR (mh:(Brucella melitensis )) OR<br>(Brucella melitensis ) OR (Micrococcus melitensis) OR<br>(mh:(Brucella ovis)) OR (Brucella ovis) OR (mh:(Brucella suis))<br>OR (Brucella suis)<br>**Teste índice:**<br>**#2**(Sorologia) OR (Serology) OR (Serología) OR (Serologia)<br>OR<br>(Imunofluorescência)<br>OR<br>(Fluorescent<br>Antibody<br>Technique) OR (Técnica del AnticuerpoFluorescente) OR<br>(Rastreamento de ProteínaFluorescente) OR (Testes de<br>AnticorposFluorescentesAntinucleares)<br>OR<br>(Técnica<br>de<br>Imunofluorescência) OR (Ensaio de ImunoadsorçãoEnzimática)|256|  
54  
|**Bases de**<br>**dados**|**Estratégias de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||OR (Enzyme-Linked Immunosorbent Assay) OR (Ensayo de<br>InmunoadsorciónEnzimática)<br>OR<br>(ELISA)<br>OR<br>(EnsaioImunoadsorventeEnzima-Associado)<br>OR<br>(EnsaioImunoadsorventeLigado à Enzima) OR (Ensaio de<br>ImunoadsorçãoLigado à Enzima) OR (Aglutinação) OR<br>(Agglutination) OR (Aglutinación) OR (Testes de Aglutinação)<br>OR (Rosa Bengala) OR (Rose Bengal) OR (Técnicas de<br>Diagnóstico Molecular) OR (Molecular Diagnostic Techniques)<br>OR (Técnicas de Diagnóstico Molecular) OR (ReaçãoemCadeia<br>da Polimerase) OR (Polymerase Chain Reaction) OR (Reacción<br>en Cadena de la Polimerasa) OR (PCR) OR (Reação da<br>PolimeraseemCadeia) OR (Reação de PolimeraseemCadeia) OR<br>(ReaçãoemCadeia de Polimerase)<br>**Desfecho:**<br>**#3**(Sensibilidade e Especificidade) OR (Sensitivity and<br>Specificity)<br>OR<br>(Sensibilidad<br>y<br>Especificidad)<br>OR<br>(Sensibilidade)<br>OR<br>(Especificidade)<br>OR<br>(VerdadeirosNegativos) OR (VerdadeirosPositivos) OR (Valor<br>Preditivo dos Testes) OR (Predictive Value of Tests) OR (Valor<br>Predictivo de las Pruebas) OR (Valor Preditivo) OR (Valor<br>PreditivoNegativo) OR (Valor PreditivoPositivo) OR (Valor<br>Preditivo do Teste) OR (Valores Preditivos de Testes) OR<br>(Reações Falso-Negativas) OR (Reações Falso-Positivas) OR<br>(Diagnóstico) OR (Diagnosis) OR (Detecção) OR (Diagnose)<br>Bases disponíveis após retirar MEDLINE no filtro da BVS:<br>**#4**db:("LILACS" OR "IBECS" OR "VETINDEX" OR<br>"BINACIS" OR "LIPECS" OR "CUMED" OR "PAHO" OR<br>"PAHOIRIS" OR "SES-SP" OR "ARGMSAL" OR "BDNPAR"<br>OR "MedCarib" OR "campusvirtualsp_centroamerica")<br>**#5**#1 AND #2 AND #3 AND #4||
|**Total**||**4.379**|  
Após reunidos os estudos identificados nas bases pesquisadas, as duplicatas foram excluídas por meio do programa _Mendeley_<sup>143</sup> . Em seguida, utilizando o aplicativo _Rayyan_<sup>144</sup> , foi realizada triagem de títulos e resumos, de acordo com o escopo da revisão. Os artigos selecionados foram lidos na íntegra e analisados de acordo com os critérios de elegibilidade.  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de inclusão** -->
(a) Tipos de participantes: Pacientes sintomáticos com suspeita de brucelose humana.  
(b) Teste índice: Qualquer teste diagnóstico (teste índice) com a informação deste teste disponível.  
55  
- (c) Tipo de referência: Cultura e/ou outro teste diagnóstico especificado.  
- (d) Tipos de estudos: Estudos originais de acurácia diagnóstica completos (resumos de  
- congressos não foram incluídos), com pelo menos 10 pacientes.  
- (e) Desfechos: Sensibilidade e especificidade.  
- (f) Idioma: Estudos publicados em inglês, espanhol e português.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de exclusão** -->
- (a) Tipos de participantes:  
Estudos com menos de 10 pacientes (casos com diagnóstico confirmado de brucelose humana).  
Pacientes com manifestações compatíveis com a forma localizada/complicada da brucelose humana.  
- (b) Tipo de intervenção:  
Ausência de informação sobre o teste index.  
Ausência de informação sobre o padrão de referência utilizado.  
- (c) Tipos de estudos:  
Publicações no formato de resumo de congresso com resultados apresentados em publicação científica.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resultados da Busca** -->
A busca identificou 4.379 artigos nas bases de dados. Após triagem e seleção com base nos critérios de elegibilidade, 90 estudos apresentaram potencial de inclusão. Considerou-se a cultura como teste de referência para o diagnóstico de brucelose humana, por se tratar de teste consagrado na literatura médica por sua alta especificidade a partir de espécimes biológicos estéreis. Apesar de específica, a cultura é considerada um teste de referência imperfeito por sua estimada baixa sensibilidade, o que é esperado para uma doença com bacteremia variável ao longo do curso da doença, que pode ser prolongado e relacionado à resposta inflamatória do hospedeiro e não somente ao dano direto causado pelo agente infeccioso. Por essa razão, além dos estudos utilizando como teste de referência a “cultura”, foram também reunidos os estudos cujo teste de referência para o diagnóstico de brucelose humana era positividade na cultura ou no teste sorológico padrão de aglutinação em tubo (SAT). Desta forma, ao final da leitura na íntegra, foram incluídos 38 manuscritos. O processo de seleção dos estudos e os motivos da exclusão estão resumidos no fluxograma PRISMA ( **Figura A** ).  
56  
<!-- Start of picture text -->
Identificação de estudos por meio de bases de dados e registros<br>Registros identificados:<br>MEDLINE (n=1.492)<br>EMBASE (n=2.604)  Duplicatas removidas (n=699)<br>COCHRANE (n=27)<br>BVS (n= 256)<br>Total = 4.379<br>Registros em triagem (n =3.680)  Registros excluídos (n =3.481)<br>Publicações pesquisadas para se<br>Registros não recuperados<br>manterem (n = 199)<br>(n = 20)<br>Registros excluídos:<br>Publicações  avaliadas  para   População (n= 13)<br>elegibilidade (n =179)   Desfecho (n= 24)<br> Desenho do estudo e/ou<br>população inadequada (n= 9)<br> Outro idioma (n=43)<br>Registros excluídos:<br>Registros potencialmente incluídos   Outros  comparadores<br>com diferentes comparadores   diferentes de cultura e/ou SAT<br>(n = 90)  (n=52)<br>Estudos incluídos (n = 38)<br>Identificação<br>Triagem<br>Incluído<br><!-- End of picture text -->  
Figura A. Fluxograma de seleção dos estudos incluídos na revisão sistemática avaliando acurácia para o diagnóstico da brucelose humana. Adaptado de Page et al<sup>151</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise e Apresentação dos Resultados** -->
As principais características dos estudos incluídos estão sumarizadas no **Quadro F** . Observa-se predomínio de estudos conduzidos em países da Ásia (24/30) e escassez de estudos na Europa e América, com apenas cinco e dois estudos, respectivamente. Em oito estudos, a origem dos pacientes não foi relatada<sup>152,158,162,165,167,170,181,183</sup> .  
Entre os estudos incluídos, o ELISA foi o teste índice mais avaliado (55%; 21/38), seguido do SAT (34,2%; 13/38), PCR (31,6%; 12/38) e Rosa Bengala (28,9%; 11/38). O teste  
57  
rápido foi avaliado em apenas quatro estudos e o teste de _Coombs_ em cinco estudos. De forma geral, os estudos incluídos são predominantemente retrospectivos (60,5%; 23/38) e frequentemente não são informados o tempo de início de sintomas (63,2%; 24/38), idade (52,6%; 20/38) e sexo dos pacientes (52,6%; 20/38).  
58

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro F. Principais características dos estudos incluídos para o diagnóstico da brucelose humana -->
|**Referência**|**Origem dos**<br>**pacientes**|**Testes índices**<br>**avaliados**|**Tamanho**<br>**amostral**<br>**(caso/não**<br>**caso)**|**Desenho do**<br>**estudo**|**Teste (s)**<br>**de**<br>**referência**|**Tempo de**<br>**início de**<br>**sintomas em**<br>**meses (média**<br>**/ mediana)**|**Idade**<br>**(média ou**<br>**mediana)**|**Masculino/**<br>**Feminino**|**Espécie de**<br>**_Brucella_**<br>**identificada (n)**|
|---|---|---|---|---|---|---|---|---|---|
|**Abdoel et al.,**<br>**2007**<sup>152</sup>|NR|1) SAT; 2) Teste<br>rápido;3) _Coombs_|45|Retrospectivo|Cultura|NR|NR|NR|_B. melitensis_(45)|
|**Akhvlediani et**<br>**al., 2017**<sup>153</sup>|Geórgia|1) SAT; 2) ELISA|33/48|Prospetivo|Cultura|NR|39,9<br>(DP 15,1)|60/21|_B. melitensis_(32) /<br>_B. abortus_(1)|
|**Al-Ajlan et al.,**<br>**2011**<sup>154</sup>|Arábia<br>Saudita|1) PCR convencional;<br>2)PCR em tempo real|89/40|Retrospectivo|Cultura|NR|NR|NR|_Brucella sp._|
|**Al-Attas et al.,**<br>**2000**<sup>155</sup>|Arábia<br>Saudita|PCR convencional|14/32|Prospectivo|Cultura<br>e/ou SAT|4 (1-13)|6 a 65|8/7|NR|
|**Almashhadany**<br>**et al., 2022**<sup>156</sup>|Iraque|Rosa Bengala|31/297|Transversal|Cultura|NR|44 (18–82)|172/153|_B. melitensis_(18) /<br>_B. abortus_(13)|
|**Al-Nakkas et**<br>**al., 2005**<sup>157</sup>|Kuwait|PCR convencional|89/244|Prospectivo|Cultura|NR|NR|NR|_B. melitensis_(85) /<br>_B. abortus_(4)|
|**Al-Shamahy et**<br>**al., 1998**<sup>158</sup>|NR|ELISA|146/20|Retrospectivo|Cultura ou<br>SAT|NR|NR|NR|_B. melitensis_|
|**Araj et al.,**<br>**1988**<sup>159</sup>|Kuwait|1) Rosa Bengala; 2)<br>SAT;3)ELISA|83/72|Retrospectivo|Cultura|< 2|NR|NR|_B. melitensis_(83)|
|**Araj et al.,**<br>**1990**<sup>160</sup>|Kuwait|ELISA|21/15|Retrospectivo|Cultura|< 2|31 (17–59)|NR|_B. melitensis_|
|**Aranís et al.,**<br>**2008**<sup>161</sup>|Chile|1)_Coombs_; 2) ELISA|10/18|Prospectivo|Cultura ou<br>SAT|0,6 (0,2-1)|M:53; F:46|6/4|NR|
|**Ayala et al.,**<br>**2014**<sup>162</sup>|NR|ELISA|49/77|Retrospectivo|Cultura|NR|NR|NR|_Brucella sp._|
|**Clavijo et al.,**<br>**2003**<sup>163</sup>|Espanha|1) Rosa Bengala; 2)<br>ELISA; 3) Teste<br>rápido|133|Retrospectivo|Cultura e/<br>ou SAT|< 3 (n=87) /<br>> 3 (n=46)|42 (16-75)|88/22|NR|
|**Dal et al., 2018**<br>164|Turquia|PCR em tempo real|36/117|Retrospectivo|Cultura|< 2 (n=210) /<br>> 3(n=5)|30 (2-80)|92/123|_B. melitensis_|
|**Debeaumont et**<br>**al., 2005**<sup>165</sup>|NR|PCR em tempo real|17/60|Retrospectivo|Cultura|NR|45 (11-69)|10/7|NR|  
59  
|**Referência**|**Origem dos**<br>**pacientes**|**Testes índices**<br>**avaliados**|**Tamanho**<br>**amostral**<br>**(caso/não**<br>**caso)**|**Desenho do**<br>**estudo**|**Teste (s)**<br>**de**<br>**referência**|**Tempo de**<br>**início de**<br>**sintomas em**<br>**meses (média**<br>**/ mediana)**|**Idade**<br>**(média ou**<br>**mediana)**|**Masculino/**<br>**Feminino**|**Espécie de**<br>**_Brucella_**<br>**identificada (n)**|
|---|---|---|---|---|---|---|---|---|---|
|**Díaz et al., 2011**<br>166|Espanha|1) SAT; 2) Rosa<br>Bengala|208/20|Retrospectivo|Cultura|NR|NR|NR|_B. melitensis_|
|**Ertek et ak.,**<br>**2006**<sup>167</sup>|NR|1) SAT 2) ELISA|32/20|Retrospectivo|Cultura|NR|NR|NR|NR|
|**Fadeel et al.,**<br>**2006**<sup>168</sup>|Egito|ELISA|202/103|Retrospectivo|Cultura|0,33 (0,1 – 3)|28 (3-60)|144/58|NR|
|**Fadeel et al.,**<br>**2011**<sup>169</sup>|Egito e EUA|ELISA|186/183|Retrospectivo|Cultura<br>e/ou SAT|NR|NR|NR|NR|
|**Gómez e tal.,**<br>**2008**<sup>170</sup>|NR|1) Rosa Bengala; 3)<br>ELISA;4) _Coombs_|25/90|Retrospectivo|Cultura ou<br>SAT|NR|41 (12-80)|22:3|NR|
|**Hasibi et al.,**<br>**2008**<sup>171</sup>|Irã|1) ELISA; 2) PCR|37/78|Prospectivo|Cultura<br>e/ou SAT|NR|44,8±14,7|Caso: 57/43;<br>Controle:<br>91/9|NR|
|**Hasibi et al.,**<br>**2013**<sup>172</sup>|Irã|ELISA|56/126|Retrospectivo|Cultura ou<br>SAT|NR|NR|NR|_B. melitensis_(19)|
|**Kiel et al., 1987**<br>173|Arábia<br>Saudita|SAT|60|Retrospectivo|Cultura|NR|32|35/25|_B. melitensis;_<br>_B. abortus_|
|**Mantur et al.,**<br>**2010**<sup>174</sup>|Índia|ELISA|31/72|Prospectivo|Cultura|NR|27,46 ±<br>18,74|03/01|_B. melitensis_|
|**Marei et al.,**<br>**2011**<sup>175</sup>|Egito|1) Rosa Bengala; 2)<br>PCR;3)Teste rápido|20/30|Prospectivo|Cultura ou<br>SAT|0,23 a 1,4|32,9 (21–<br>63)|13/7|NR|
|**Memish et al.,**<br>**2002**<sup>176</sup>|Arábia<br>Saudita|1) SAT; 2) ELISA|68/70|Prospectivo|Cultura|NR|NR|NR||
|**Mert et al.,**<br>**2003**<sup>177</sup>|Turquia|1) SAT; 2) Rosa<br>Bengala|30/280|Retrospectivo|Cultura|NR|NR|NR|NR|
|**Mizanbayeva et**<br>**al., 2009**<sup>178</sup>|Cazaquistão|1) SAT; 2) Rosa<br>Bengala; 3) Teste<br>rápido|63|Retrospectivo|Cultura|< 6 (n=50)<br>6 – 12 (n=2)<br>> 12(n=11)|33 (21-83)|46/17|NR|
|**Nicoletti et al.,**<br>**1971**<sup>179</sup>|Irã|1) SAT; 2) Rosa<br>Bengala|16/196|Prospectivo|Cultura|NR|NR|NR|_B. melitensis_(1)|  
60  
|**Referência**|**Origem dos**<br>**pacientes**|**Testes índices**<br>**avaliados**|**Tamanho**<br>**amostral**<br>**(caso/não**<br>**caso)**|**Desenho do**<br>**estudo**|**Teste (s)**<br>**de**<br>**referência**|**Tempo de**<br>**início de**<br>**sintomas em**<br>**meses (média**<br>**/ mediana)**|**Idade**<br>**(média ou**<br>**mediana)**|**Masculino/**<br>**Feminino**|**Espécie de**<br>**_Brucella_**<br>**identificada (n)**|
|---|---|---|---|---|---|---|---|---|---|
|**Nimri et al.,**<br>**2003**<sup>180</sup>|Jordânia|PCR convencional|20/25;<br>140/25|Prospectivo|Cultura;<br>Cultura<br>e/ou SAT|1,16 (0,33-2)|46 (6-86)|58/107|NR|
|**Osoba et al.,**<br>**2001**<sup>181</sup>|NR|ELISA|30/44|Retrospectivo|Cultura|< 2 meses|NR|NR|_B. melitensis_(30)|
|**Patra et al.,**<br>**2019**<sup>182</sup>|Índia|PCR em tempo real|53/54|Prospectivo|Cultura|1,23 (IQ: 0,77-<br>2)|NR|NR|_B. melitensis_(53)|
|**Peeridogaheh**<br>**et al., 2013**<sup>183</sup>|NR|1) ELISA; 2)_Coombs_|11/32|Retrospectivo|Cultura|NR|NR|NR|NR|
|**Purwar et al.,**<br>**2016**<sup>184</sup>|Índia|1) SAT; 2) Rosa<br>Bengala|20/360|Transversal|Cultura|NR|NR|NR|NR|
|**Queipo-Ortuño**<br>**et al., 1997**<sup>185</sup>|Espanha|PCR convencional|35/60|Prospectivo|Cultura|0,85 (0-4)|NR|37/10|_B. melitensis_(35)|
|**Saz et al., 1987**<br>186|Espanha|1) SAT; 2) Rosa<br>Bengala; 3) ELISA;<br>4) _Coombs_|208/107|Retrospectivo|Cultura|NR|NR|NR|_B. melitensis_|
|**Vrioni et al.,**<br>**2004**<sup>187</sup>|Grécia|PCR-ELISA|179|Retrospectivo|Cultura|1,08 (0,23–2)|46,1 (18-<br>91)|163/80|_B. melitensis_(179)|
|**Xu et al., 2020**<br>188|China|1) SAT; 2) ELISA|51/248|Prospectivo|Cultura|NR|48,39 ±<br>19,96|28/23|NR|
|**Zhao et al.,**<br>**2020**<sup>189</sup>|China|PCR em tempo real|46/62|Retrospectivo|Cultura|NR|NR|NR|_B. melitensis_|  
Legenda: SAT - teste padrão de aglutinação em tubo; ELISA - ensaio imunoenzimático; PCR - reação em cadeia da polimerase; DP - desvio padrão; NR - não relatado; IQ - Intervalo interquartil.  
61  
Os estudos foram estratificados de acordo com os testes índices avaliados, a saber: teste Rosa Bengala, padrão de aglutinação em tubo (SAT), ELISA, teste rápido, _Coombs_ e PCR. Para cada teste diagnóstico identificado, estimou-se a medida sumarizada de desempenho (sensibilidade e especificidade) por meio do _software_ CMA versão 3.0, agrupando todos os casos investigados com a mesma metodologia em diferentes estudos, utilizando o modelo de combinação por efeitos aleatórios, que incorpora a heterogeneidade entre os estudos e, portando, produz intervalos de confiança maiores e medidas menos precisas da estimativa central do desempenho.  
Várias terminologias foram encontradas para designar o teste Rosa Bengala, sendo identificados nesta revisão 11 estudos avaliando teste de aglutinação não titulável utilizando antígeno Rosa Bengala ( **Quadro G** ). A cultura foi considerada o teste de referência em oito estudos e, cultura e/ou SAT, em apenas três estudos. O estudo de Araj et al. (1988)<sup>190</sup> avaliou o desempenho de dois testes usando o corante Rosa Bengala, com desempenho similar. Desta forma, os casos avaliados e seus resultados foram contabilizados uma única vez na estimativa do desempenho sumarizado global do teste. Observou-se alta heterogeneidade tanto em termos de sensibilidade (I<sup>2</sup> =70,79), quanto em termos de especificidade (I<sup>2</sup> = 90,25) entre os resultados de desempenho de estudos utilizando cultura como teste de referência ( **Figura B** ). Já as medidas sumarizadas de sensibilidade e especificidade do Rosa Bengala, considerando cultura e/ou SAT como teste de referência foram de 96,6% [IC95%: 92,6–98,5] e 97,9% [IC95%: 93,1–99,4], respectivamente, ambas com baixa heterogeneidade (I<sup>2</sup> =0).  
O teste padrão de aglutinação em tubo (SAT) - considerado neste relatório como todo teste de aglutinação titulável utilizando antígeno de Rosa Bengala foi avaliado em 13 estudos tendo cultura como teste de referência ( **Quadro G** ). No caso do estudo realizado por Mizanbayeva et al. (2009)<sup>191</sup> , que avaliou o desempenho do SAT em diferentes títulos, somente os resultados referentes ao desempenho com título superior a 1:100 foi considerado no cálculo da medida sumarizada de desempenho, por ser o título mais próximo do utilizado por outros autores. Medidas sumarizadas de sensibilidade e especificidade de 89,2% [IC95%: 81,4–94,0; i<sup>2</sup> =85,2] e 95,6% [IC95%: 89,7–98,1; i<sup>2</sup> =89,2], respectivamente, foram estimadas para o SAT ( **Figura C** ).  
62  
Quadro H. Estudos de avaliação de desempenho do teste Rosa Bengala para o diagnóstico da brucelose humana  
|**Referência**|**Teste índice***|**Fabricante**|**Espécies do**<br>|**Definição**<br>|**Definição de não**|**N°**|**N° não**|**N°**<br>|**VP**|**FN**|**VN**|**FP**|**Sens**<br>|**Esp**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||**antígeno**|**de caso**|**caso**|**caso**|**caso**|**total**|||||**(%)**|**(%)**|
|**Almashhadany et**<br>**al., 2022**<sup>156</sup>|Rosa Bengala|_Torax Biosciences, United_<br>_Kingdom_||Cultura|Cultura|31|40|71|31|0|31|9|100|96,9|
|<sup>159</sup>|_Brucellosis card_<br>_test_|_Brewers' Diagnostic_<br>_Kits, UnitedStates_|_B. abortus_|Cultura|Outras doenças|83|72|155|83|0|72|0|100|100|
|**Araj et al., 1988**|_Brucelloslide test_|BioMérieux,France|_B. abortus_|Cultura|Outras doenças|83|72|155|83|0|72|0|100|100|
|**Díaz et al., 2011**<sup>166</sup>|Rosa Bengala|Antígeno fabricado por<br>_Veterinary Laboratory,_<br>_United Kingdom_(>1:4)||Cultura|Contato com<br>animal ou<br>acidente de<br>trabalho|208|20|228|180|28|20|0|87,4|100|
|**Mert et al.,**<br>**2003**<sup>177</sup>|Rosa Bengala|NR|NR|Cultura|NR|30|NR|30|30|0|NR|NR|100|NR|
|**Mizanbayeva et**<br>**al., 2009**<sup>178</sup>|Rosa Bengala|NR|NR|Cultura|NR|63|NR|63|45|18|NR|NR|71,4|NR|
|**Nicolleti et al.,**<br>**1971**<sup>179</sup>|Teste de<br>aglutinação em<br>cartão|_Becton dickinson, USA_|NR|Cultura|Cultura|16|196|212|15|1|154|42|93,8|78,6|
|**Purwar et al.,**<br>**2016**<sup>184</sup>|Teste de<br>aglutinação em<br>lâmina|Antígeno fabricado por<br>_Indian Veterinary_<br>_Research Institute, India_|_B. abortus_|Cultura|Cultura|20|380|400|20|0|365|15|100|96,1|
|**Saz et al., 1987**<sup>186</sup>|Rosa Bengala|NR|NR|Cultura|Cultura e testes<br>convencionais|208|107|315|182|26|107|0|87,5|100|
|**Clavijo et al.,**<br>**2003**<sup>163</sup>|_Brucelloslide_or<br>Rosa Bengala|_BioMérieux, France_|NR|Cultura e/ou<br>SAT|NR|133|NR|133|128|5|NR|NR|96,2|NR|
|**Gomes et al.,**<br>**2008**<sup>170</sup>|Rosa Bengala|_Bio Systems_, Barcelona,<br>Espanha|_B. abortus_|Cultura e/ou<br>SAT|Saudáveis|25|90|115|25|0|88|2|100|97,7|
|**Marei et al.,**<br>**2011**<sup>175</sup>|Rosa Bengala|Antígeno fabricado por<br>_Spinreact, Girona, Spain_|NR|Cultura e/ou<br>SAT|NR|20|30|50|20|0|30|0|100|100|  
Legenda: *Teste índice como descrito no artigo original; NR - Não relatado; Sens - Sensibilidade; Esp - Especificidade; VP - Verdadeiro positivo; FN - Falso negativo; VN - Verdadeiro negativo; FP - Falso positivo.  
63  
<!-- Start of picture text -->
Sensibilidade: Rosa Bengala x Cultura Especificidade: Rosa Bengala x Cultura<br>stay nome vette on 9581 Woot andom samt ame votre 084 955.1 wt andom<br>ent Lower Upper oie Reine Sth Sh th ent Lower Upper flatve folate Sd Sd Std<br>rate ‘ht! Art Tota Wwooht ‘wight Residue Resduel Reva ae mnt kt Tota ‘woot ‘weight Resiual Residual Resdvl<br>mastmacanystal 20220984 0794 0980 34/21 —a 10 120 Amastnacinystal<br>AaaetatDiaz eta 201198 088sosse o 8r2st 0905100 1 0 200 8 3 / 83 . Ee2598 se198 cs e atra 198ont 2022 0775Gere0993 arts062t0500 087909 910 0 0 20 203414072 / 72 m0nzfon cs137125<br>Meret, 2002 ogee 0789 0999 20/20 —8 ts 12 ot eta 1974 070s 0723 0900 154/198 zs0 438<br>Mantaywa<br>ate tal 20090784 0501 O82 45/63 ne 207 Purar ta 2018 oast ose 0975 265/390 m o2n cao<br>PurarPelesarea ta1887 20151971 oa7soarsose oem07086s 091309990901 182/20020/2018/18, BHmoteas6 020ous101 roeconeae teal geetonvermaneesSer oarSS eeeee Ee ~e"ia bows 3<br>Pradton intel oas7 o sa2gz0 og a tu > a  D<br>ao 0s ose tm<br>Heterogeneity: I-square=70.79, tau-squared=0.40, p=0.001 Heterogeneity: I-square=90.26, tau-squared=1.46, p=0.00<br>Sensibilidade: Rosa Bengala x Cultura e/ou SAT Especificidade: Rosa Bengala x Cultura e/ou SAT<br>sud name Event rate and 95% Cl Weight Random) stugy name Event rate and 95%C1 Weight (Random<br>Event Lower Upper Relaive Relative Sud Std Sid Event Lower Upper Relate Relative Std Std Std<br>rate limit timit_— Total weight weight Residual Residual Residual rate limit limit Total weight weight Residual Residual Residual<br>Cia tal, 2003 0952 0913 0886 128/133 B80 082 omezetal, 2008 0.978 0.918 0994 88/90 7990 on<br>GémezMaret etal. 2008 0981 0755 0889 25/25 mow ous Mareietal, 2011 0.984 0,789 0999 30/20 20,10 020<br>Pools al,2011 0876 0719 0889 20/20 oe) o2t pees bare ost ose<br>Prediction inten 0966 0925 0905 Py Prediction interval<br>coast 0000250078 .00<br>Heterogeneity: I-square=00.00, tau-squared=0.00, p=0.87 Heterogeneity: I-square=00.00, tau-squared=0.00, p=0.84<br><!-- End of picture text -->  
Figura B. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) do Rosa Bengala  
64  
Quadro G. Estudos de avaliação de desempenho do teste padrão de aglutinação em tubo (SAT) para o diagnóstico da brucelose humana  
|**Referência**|**Teste índice***|**Fabricante**|**Tipo de**<br>**antígeno**|**Título**|**Definição**<br>**de caso**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N° não**<br>**caso**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Abdoel et al.,**<br>**2007**<sup>152</sup>|Teste de<br>soroaglutinação|NR|NR|>1:320|Cultura|NR|45|NR|37|8|NR|NR|82,22|NR|
||_Wright test_(teste||||||||||||||
|**Akhvlediani et**<br>**al., 2017**<sup>153</sup>|padrão de<br>aglutinação em<br>tubo)|NR|_B. abortus_|>1:200|Cultura|Cultura|33|48|27|6|35|13|81,82|72,92|
|**Araj et al.,**<br>**1988**<sup>159</sup>|Teste de<br>microaglutinação<br>(MAT)|_National_<br>_Veterinary_<br>_Services_<br>_Laboratories,_<br>_Iowa _|_B._<br>_melitensis_|>1:80|Cultura|Outras doenças|83|72|83|0|72|0|100|100|
|||||||Contato com|||||||||
|**Díaz et al.,**<br>**2011**<sup>166</sup>|Teste de<br>Soroaglutinação|NR|NR|>1:160|Cultura|animal ou<br>acidente de<br>trabalho|208|20|160|48|20|0|76,9|100|
|**Ertek et al.,**<br>**2006**<sup>167</sup>|Teste de<br>aglutinação padrão|_Pendik_<br>_Veterinary_<br>_Institute,_<br>_Istanbul, Turkey_|_B. abortus_|>1:160|Cultura|Saudáveis de<br>área endêmica|32|20|30|2|20|0|93,75|100|
|**Kiel et al., 1987**<br>173|Teste sorológico<br>hemaglutinação|NR|_B_._abortus_/<br>_B_.<br>_melitensis_|>1:160|Cultura|NR|60|NR|60|0|NR|NR|100|NR|
|**Memish et al.,**<br>**2002**<sup>176</sup>|Teste padrão de<br>aglutinação (SAT)|_Antígeno_<br>_Wellcome_<br>_Diagnostics,_<br>_England_|_B_._abortus_/<br>_B_.<br>_melitensis_|>1:320|Cultura|Saudáveis de<br>área endêmica|68|70|65|3|70|0|95,59|100|
|**Mert et al.,**<br>**2003**<sup>177</sup>|_Wright test_(teste de<br>aglutinação em<br>tubo padrão)|_Pendik_<br>_Veterinary_<br>_Institute,_<br>_Istanbul, Turkey_|_B_._abortus_|>1:160|Cultura|NR|30|280|30|0|280|0|100|100|
|**Mizanbayeva**|Teste de<br>soroaglutinação de<br>_Wright_|NR||>1:25|Cultura|NR|63|NR|63|0|NR|NR|100|NR|
|**et al., 2009**<sup>178</sup>|Teste de||||||||||||||
||soroaglutinação de<br>_Wright_|NR||>1:50|Cultura|NR|63|NR|57|6|NR|NR|90,48|NR|  
65  
|**Referência**|**Teste índice***|**Fabricante**|**Tipo de**<br>**antígeno**|**Título**|**Definição**<br>**de caso**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N° não**<br>**caso**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||Teste de<br>soroaglutinação de<br>_Wright_|NR||>1:100|Cultura|NR|63|NR|46|17|NR|NR|73,02|NR|
||Teste de||||||||||||||
||soroaglutinação de<br>_Wright_|NR||>1:200|Cultura|NR|63|NR|32|31|NR|NR|50,79|NR|
|**Nicoletti et al.,**<br>**1971**<sup>179</sup>|Teste de<br>aglutinação em<br>tubo|Razi Institute,<br>Hessark, Iran||>1:80|Cultura|Cultura -|16|196|16|0|158|38|100|80,61|
|**Purwar et al.,**<br>**2016**<sup>184</sup>|Teste padrão de<br>aglutinação em<br>tubo|Antígeno<br>fabricador por<br>_Indian_<br>_Veterinary_<br>_Research_<br>_Institute, India_|_B_._abortus_|>80IU/mL|Cultura|Cultura|20|380|20|0|366|14|100|96,32|
|**Saz et al.,**<br>**1987**<sup>186</sup>|Teste padrão de<br>aglutinação|NR|_B_._abortus_|>1:80|Cultura|Cultura e testes<br>convencionais -|208|107|129|79|107|0|62,02|100|
|**Xu et al.,**<br>**2020**<sup>188</sup>|Teste de<br>aglutinação em<br>tubo padrão|Antígeno<br>comercial<br>(_Center for_<br>_Disease Control_<br>_and Prevention_,<br>China)||>1:100|Cultura|Outras doenças<br>ou saudáveis|51|338|41|10|316|22|80,39|93,49|  
Legenda: *Teste índice como descrito no artigo original; NR - Não relatado; Sens - Sensibilidade; Esp - Especificidade; VP - Verdadeiro positivo; FN  
- Falso negativo; VN - Verdadeiro negativo; FP - Falso positivo.  
66  
<!-- Start of picture text -->
Sensibilidade: SAT x Cultura<br>‘Say name Event rate and 95% C1 _ weight Random)<br>Event Lower Upper Relame Relwive Sis Sts Std<br>peadostpamdecanietal.2017 eta eta, 20071908 ‘oteon220818088009s ‘km068s0912 emt0909O911000 37/4527/29e389Tota ‘weit1028908206 ‘weight Residual081982181 Resi Residual<br>lac eta2011 0909 0630 0925 1851200 we] ons 903<br>Mariannexteat,et atot at,198720082002 099099209s a708820872 090409990906 201328018065/68 —a|ee)is208 082092161<br>MentcomIsandayeraetat.2009 tat,2003eta. 1971 ose07300971 07890808ogee 099908250998 3013048/6916198 a7aee380 42092120<br>PuraSazettat,2098 0978 0713 0999 20/20 nee 096<br>vet atat,20201997 0 620908 0 882673 o 8esnt 1291200a1/st -_ 1199087 494078<br>Pooled oss2 084 0.940 os<br>Preciton tena o9e2 0487 0908 00 025 050 ors 100<br>Heterogeneity: I-square=85. 17, tau-squared=0.86, p=0.00<br>Especificidade: SAT X Cultura<br>Study name Event rate and 95% Cl Wight (Random)<br>Event Lower Upper Relative Relative Sw Std Sud<br>rate limit timit Total ‘weight weight Residual Residual Residual<br>‘Aditediani<br>‘AajEnek otaal1988 2006etal 2017 0.729 0 .993976 0888 0 713,800 08360.9991,000 35/487220 / 7220 — 1626 6 st58 o371.99110<br>MemishMeateta 2002 0.983 0897 1,000 70/70 658 1.09<br>ot a, 2003 0.958 0872 1,000 280/280 6.60 1.89<br>Nicoletta 1971 0.806 0745 0856 158/196 _ m2 a6<br>Purwaret at 2016 0.963 0899 0978 366/380 ) i666 019<br>Saz eta. 1967 0.995 0890 1.000 107/107 659 13<br>Yu et at 2020 0535 0903 0957 316/338 | 00 40<br>Pooled 0.956 0897 0981 ><br>Prediction tera 0366 0567 0997 0.00 025 050 075 1.00<br>Heterogeneity: |-square=89. 18, tau-squared=1.19, p=0.00<br><!-- End of picture text -->  
Figura C. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para o SAT, considerando cultura como comparador  
67  
O ELISA foi avaliado em 11 estudos em comparação com cultura e outros sete estudos, tendo como teste de referência cultura e/ou SAT ( **Quadro H** Quadro). Em geral, os estudos incluídos avaliavam a presença das subclasses de anticorpos IgM, IgG e IgA. Apenas Al-Shamahy et al. (1998)<sup>192</sup> não especificaram a subclasse de anticorpo detectada, sendo excluído das análises sumarizadas. Fadeel et al. (2011)<sup>193</sup> avaliaram diferentes testes ELISA comerciais em amostras de pacientes do Egito e EUA. Para não incluir o mesmo paciente/caso mais de uma vez na medida sumarizada de desempenho global, foram considerados na estimativa apenas os resultados obtidos com o teste de melhor desempenho (ELISA _Immuno-Biological Laboratories_ ).  
Entre os estudos que avaliaram ELISA IgG e ELISA IgM considerando cultura como teste de referência, foi observada alta heterogeneidade com I<sup>2</sup> variando de 56,35 a 92,7. As medidas sumarizadas de sensibilidade e especificidade para ELISA IgG, tendo como teste de referência cultura e/ou SAT, foram de 85,8% [IC95%: 75,5–92,2; i<sup>2</sup> =00.0] e 99,0% [IC95%: 95,3–99,8; i<sup>2</sup> =00.0], respectivamente ( **Figura D** ). Já para ELISA IgM, foram de 55,3% [IC95%: 47,8–62,7; i<sup>2</sup> =00.0]; e 96,8% [IC95%: 59,5–99,8; i<sup>2</sup> =73.54], respectivamente ( **Figura E** ).  
_A detecção de IgA foi avaliada em apenas três estudos, sendo a medida sumarizada de sensibilidade estimada em 94,4% [IC95%: 68,1–99,2; i_<sup>_2_</sup> _=77,6] e especificidade em 98,5% [IC95%: 90,3–99,8; i_<sup>_2_</sup> _=00.0] (_ Figura F. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) do ELISA IgA

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Figura F** ). -->
O teste ELISA IgG/IgM apresentou os maiores valores de sensibilidade e especificidade, considerando cultura e/ou SAT como teste de referência: 96,8% [IC95%: 60,8–99,8; i<sup>2</sup> =88.90] e 98,6% [IC95%: 96,1–99,5; i<sup>2</sup> =00.0], respectivamente ( **Figura G** ).  
68  
Quadro H. Estudos de avaliação de desempenho para o ensaio imunoenzimático (ELISA) no diagnóstico da brucelose humana  
|**Referência**|**Teste**<br>**índice**|**Fabricante**|**Tipo deantígeno**|**Padrão**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**total**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||ELISA<br>IgG/IgM|_In-house test_|NR|Cultura|Cultura|33|48|81|32|1|15|33|96,97|31,25|
|**Akhvlediani et**<br>**al. 2017**<sup>153</sup>|ELISA<br>IgG|_IBL International,_<br>_Hamburg, Germany_|NR|Cultura|Cultura|33|48|81|31|2|27|21|93,94|56,25|
||ELISA<br>IgM|IBL International,<br>Hamburg,Germany|NR|Cultura|Cultura|33|48|81|11|22|41|7|33,33|85,42|
||ELISA<br>IgG|_In-house_|_B_._melitensis_|Cultura|Outra doença|83|72|155|83|0|72|0|100|100|
|**Araj et al.,**<br>**1988**<sup>159</sup>|ELISA<br>IgM|_In-house_|_B_._melitensis_|Cultura|Outra doença|83|72|155|83|0|72|0|100|100|
||ELISA<br>IgA|_In-house_|_B_._melitensis_|Cultura|Outra doença|83|72|155|83|0|72|0|100|100|
||ELISA-<br>IgG|_(National Veterinary_<br>_Services Laboratories,_<br>_Ames, Iowa USA). _|NR|Cultura|Saudável|21|15|36|21|0|15|0|100|100|
|**Araj et al.,**<br>**1990**<sup>160</sup>|ELISA-<br>IgM|_(National Veterinary_<br>_Services Laboratories,_<br>_Ames, Iowa USA). _|NR|Cultura|Saudável|21|15|36|21|0|14|1|100|93|
||ELISA-<br>IgA|_(National Veterinary_<br>_Services Laboratories,_<br>_Ames, Iowa USA). _|NR|Cultura|Saudável|21|15|36|20|1|15|0|95|100|
|**Ayala et al.,**|IELISA®<br>IgA/IgG|_Harbin Peace River_<br>_Biotechnology_<br>_Company Limited,_<br>_China_|NR|Cultura|Saudáveis e<br>sorologia -|49|77|126|48|1|77|0|98,0|100|
|<br>**2014**<sup>162</sup>|ELISA®<br>IgA/IgG<br>rapid|_Harbin Peace River_<br>_Biotechnology_<br>_Company Limited,_<br>_China_|NR|Cultura|Saudáveis e<br>sorologia -|49|77|126|47|2|77|0|95,9|100|
||ELISA<br>IgG/IgM|_Novum, Germany_|NR|Cultura|Saudáveis de<br>área endêmica|32|18|50|24|8|17|1|75|94,4|
|**Ertek et al.**<br>**2006**<sup>167</sup>|ELISA<br>IgG|_Novum, Germany_|NR|Cultura|Saudáveis de<br>área endêmica|32|20|52|26|6|19|1|81,25|95|
||ELISA<br>IgM|_Novum, Germany_|NR|Cultura|Saudáveis de<br>área endêmica|32|20|52|32|0|17|3|100|85|  
69  
|**Referência**|**Teste**<br>**índice**|**Fabricante**|**Tipo deantígeno**|**Padrão**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**total**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Fadeel et al.,**<br>**2006**<sup>167</sup>|ELISA<br>IgG/IgM|_Antígeno comercial da_<br>_Beckton Dickinson_|_B_._abortus_|Cultura|Cultura – e<br>confirmação de<br>outra doença|202|103|305|196|6|99|4|97,03|96,12|
|**Mantur et al.,**<br>**2010**<sup>174</sup>|ELISA<br>IgG/IgM|NovaTec<br>Immundiagnostica<br>GmbH, Dietzenbach,<br>Germany|NR|Cultura|Cultura|31|72|164|31|0|51|21|100|71,31|
||ELISA<br>IgG/IgM|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis de<br>área endêmica|66|70|136|62|4|68|2|93,9|97,1|
|**Memish et al.,**<br>**2002**<sup>176</sup>|ELISA<br>IgG|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis de<br>área endêmica|68|70|138|31|37|68|2|45,6|97,1|
||ELISA<br>IgM|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis de<br>área endêmica|67|70|137|53|14|70|0|79,1|100|
||ELISA<br>IgG/IgM|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis|30|44|74|27|3|44|0|90|100|
|**Osoba et al.,**<br>**2001**<sup>181</sup>|ELISA<br>IgG|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis|30|44|74|6|24|44|0|20|100|
||ELISA<br>IgM|_Genzyme Virotech_<br>_GmbH, Lowenplatz,_<br>_Russelsheim_|NR|Cultura|Saudáveis|30|44|74|24|6|44|0|80|100|
||ELISA<br>IgG/IgM|_Vircell, Spain_|LPS de_B_._abortus_|Cultura|Saudáveis|11|32|43|11|0|32|0|100,00|100|
|**Peeridogaheh**<br>**et al. 2013**<sup>183</sup>|ELISA<br>IgG|_Vircell, Spain_|LPS de_B_._abortus_|Cultura|Saudáveis|11|32|43|9|2|32|0|81,82|100|
||ELISA<br>IgM|_Vircell, Spain_|LPS de_B_._abortus_|Cultura|Saudáveis|11|32|43|8|3|32|0|72,73|100|
|<sup>186</sup>|ELISA<br>IgG|Ag Virion Institute,<br>Switzerland|_B_._abortus_S99|Cultura|Cultura - e<br>Testes<br>convencionais -|208|NR|208|186|22|NR|NR|89,42|NR|
|**Saz et al., 1987**|ELISA<br>IgM|_Ag Virion Institute,_<br>_Switzerland_|_B_._abortus_S99|Cultura|Cultura - e<br>Testes<br>convencionais -|208|0|208|181|27|NR|NR|87,02|NR|  
70  
|**Referência**|**Teste**<br>**índice**|**Fabricante**|**Tipo deantígeno**|**Padrão**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**total**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||ELISA<br>IgA|_Ag Virion Institute,_<br>_Switzerland_|_B_._abortus_S99|Cultura|Cultura - e<br>Testes<br>convencionais -|208|NR|208|167|41|NR|NR|80,29|NR|
|**Xu et al., 2020**<sup>188</sup>|ELISA<br>IgG/IgM|_IBL International,_<br>_Hamburg, Germany_|NR|Cultura|Saudáveis ou<br>outra doença|51|338|389|50|1|333|5|98,04|98,52|
||||||Saudáveis +||||||||||
|**Al-Shamahy et**<br>**al., 1998**<sup>158</sup>|ELISA|NR|B._abortus_|Cultura<br>e/ou SAT|outras doenças<br>+ indivíduos<br>expostos|146|1891|2037|64|82|1846|45|43,84|97,62|
|**Aranís et al.,**<br>**2008**<sup>161</sup>|ELISA<br>IgG|_Vircell, Spain_|LPS de_B_._abortus_|Cultura<br>e/ou SAT|Confirmação de<br>outra doença +<br>Cultura e SAT-|10|18|28|8|2|18|0|80|100|
|**Aranís et al.,**<br>**2008**<sup>161</sup>|ELISA<br>IgM|_Vircell, Spain_|LPS de_B_._abortus_|Cultura<br>e/ou SAT|Confirmação de<br>outra doença +<br>Cultura e SAT-|10|18|28|5|5|16|2|50|88,9|
|**Clavijo et al.,**<br>**2003**<sup>163</sup>|ELISA<br>IgM|_Laboratorios Vircell,_<br>_Granada, Spain)_|NR|Cultura<br>e/ou SAT|NR|133|NR|133|73|60|NR|NR|54,89|NR|
||ELISA<br>IgG/IgM|_Bio-Quant Brucella_<br>(Egito)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|67|145|212|67|0|50|95|100|34,5|
||ELISA<br>IgG/IgM|_Immuno-Biological_<br>_Laboratories (IBL)_<br>(Egito)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|67|145|212|67|0|143|2|100|98,6|
|**Fadeel et al.,**|ELISA<br>IgG/IgM|_Vircell_<br> (Egito)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|67|145|212|64|3|143|2|95,5|98,6|
|**2011**<sup>169</sup>|ELISA<br>IgG/IgM|_Euroimmun_<br>(Egito)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|67|145|212|67|0|130|15|100|89,7|
||ELISA<br>IgG/IgM|_Bio-Quant Brucella_<br>(Estados Unidos)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|119|38|157|119|0|4|34|100|10,5|
||ELISA<br>IgG/IgM|_Immuno-Biological_<br>_Laboratories (IBL)_<br>(Estados Unidos)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|119|38|157|118|1|37|1|99,2|97,4|  
71  
|**Referência**|**Teste**<br>**índice**|**Fabricante**|**Tipo deantígeno**|**Padrão**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**total**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||ELISA<br>IgG/IgM|_Vircell_<br>(Estados Unidos)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|119|38|157|86|33|37|1|72,3|97,4|
||ELISA<br>IgG/IgM|_Euroimmun_<br> (Estados Unidos)|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>confirmação de<br>outra doença|119|38|157|118|1|31|7|99,2|81,6|
||ELISA<br>IgG|_Serion/ Virion,_<br>_Wurzburg, Germany_|NR|Cultura<br>e/ou SAT|Saudáveis|25|90|115|21|4|90|0|84|100|
|**Gómez e tal.,**<br>**2008**<sup>170</sup>|ELISA<br>IgA|_Serion/ Virion,_<br>_Wurzburg, Germany_|NR|Cultura<br>e/ou SAT|Saudáveis|25|90|115|24|1|88|2|96|98|
||ELISA<br>IgM|_Serion/ Virion,_<br>_Wurzburg, Germany_|NR|Cultura<br>e/ou SAT|Saudáveis|25|90|115|15|10|90|0|60|100|
|**Hasibi et al.,**<br>**2013**<sup>172</sup>|ELISA<br>IgG/IgM|_Immuno Biological_<br>_Laboratories Company,_<br>_Germany_|NR|Cultura<br>e/ou SAT|Saudáveis ou<br>outra doença|56|126|182|42|14|126|0|75|100|
|**Hasibi et al.,**<br>**2008**<sup>171</sup>|ELISA<br>IgG|_Immuno Biological_<br>_Laboratories Company,_<br>_Germany_|NR|Cultura<br>e/ou SAT|Saudáveis|37|78|115|33|4|78|0|89,2|100|  
Legenda: NR: Não relatado; Sens: Sensibilidade; Esp: Especificidade; VP: Verdadeiro positivo; FN: Falso negativo; VN: Verdadeiro negativo; FP: Falso positivo.  
72  
<!-- Start of picture text -->
Sensibilidade: ELISA IgG x Cultura Especificidade: ELISA IgG x Cultura<br>oyna tana wp any ty same atte nd ch gh ano<br>Mintaro 017 ose ores ages 31/39 Se ad on ‘Abinledianet al 2017 os63 0421 0695 27/48 mst ast<br>reomaaaas ait as tame nit te oe eat 018589 OM m8 rat ar oe<br>on‘Sazetal, 1967 ceoono+ usesons ear0829 196/200 1505 ox PraPeesdogahehetal 2013 0.985sa 0.798ome 0.999ts 32/32 a baad<br>Heterogeneity: -square=02 67; tau-squared=2.43, p=0.00 Heterogeneity: I-square=86 10, tau-squared=4.67, p=0.00<br>Sensibilidade: ELISA IgG x Cultura e/ou SAT Especificidade: ELISA IgG x Cultura e/ou SAT.<br>‘Study name Event rate and 96%Cl ‘Weight (Random) ‘Study name ‘Event rate and 96% Cl ‘Weight (Random)<br>Event Lower Upper Relaive Relive Sed Std Sus Evs e n Lowertwa  Upse Reiveee RelaiveRo Sid Std ual Sdne<br>‘ands etal,20080,900tate 0489time 0.950ft 8/10Tota . eight1878 weight Residual058 Residual Reigual rankce s  etalar Sooooase2080974 vara.0,090te 0908eosooo 18/18sara S s oariam Wei ResidualoerteResa Resin<br>GomezHas etal,e tal,200820080,8400.802 0,6430.745 0,9390.959 21/2598/37 ma39,40 0.33078 HasibiPooled etal, 2008 0,994800 0,9070959 0908,1,000 78/78 SE« 355 037<br>Pooled 0858 0755 0.922 —_> Prediction teva 1<br>Predicton terval ' os om un om<br>a a aT<br>Heterogeneity: !-square=0.00, tau-squared=0.00, p=0.71 Heterogeneity: I-square=0.00, tau-squared=0.00, p=0.69<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Figura D. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para o ELISA IgG -->
73  
<!-- Start of picture text -->
Sensibilidade: ELISA IgM x Cultura Especificidade: ELISA IgM x Cultura<br>oofae toet Onint Tota ewewolget Relateweight Resiuat ResidualSa ResttvelSe Eventrate Lowerlimit Upperlimit Total Relative‘weight Relativeweight ResidualStd Residual‘std Residualstd<br>icons] 08 ass On Sik ua 2 ininsosts 17 Lame om e118 a +3<br>‘AeajetErtekCrvawa,zoo1 etal,at 20081990 09770965oh 07230.709SantO90T09080999 21/21419032/32 ne690693 21812 AbaAesManchaaa. 1220198202 899883809_ 88ST.oe om1080S000 70/772/728s botonoe 1ie=<br>rewarpoonal<br>Seater ants nroana? ct a rrte eons99m simarm neBa o sa PeeteOnin 201989 a8 at ak oo on<br>roseseaammunal ons cee 99 poses 209 asOh O78ons Amos e B/D _ om on<br>ons nate oa Preto tet Oss) 0st6 Oss7<br>Po rr a) om as om rst<br>Heterogeneity: |-square=86.5, tau-squared=1.27, p=0.00 Heterogeneity: !-square=56.35, tau-squared=1.02, p=0.03<br>Sensibilidade: ELISA IgM x Cultura e/ou SAT Especificidade: ELISA IgM x Cultura e/ou SAT<br>stuay name vant‘se Lower‘ie Upper“ft Tot vente and 85 Reatveignright RandomReitve"Weigh ResiuatResiuatRestuaStd ste sts snuty name Eventmeet LowerLaver Uppereee co ventaand 98% ReliveWeightrae RandomReliveVeta atStd nceStd netasts<br>MevieChipeta,hal, 20082003 0,6000549 02250464 07760601 79/1096/10 nahad 02602s AranasConeseet al, 200820080906 0,889 0,648Gore 0,9721000 99/9016/18 ns57.44 4,00too<br>PeeleGtmezetal2008Predeton era 0900sss 0402.o4Te 077006a 15/25 ' 108 ost omeeo tenet tece Geos ooae j<br>0,00 0.25 0,50, 076 1,00 baad ons “ bead had<br>Heterogeneity: I-square=0.00, tau-squared=0.00, p=0.84 Heterogeneity: -squore=73.54, tau-squared=3.57, p=0.05<br><!-- End of picture text -->  
Figura E. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) do ELISA IgM  
<!-- Start of picture text -->
Sensibilidade: ELISA IgA x Cultura Especificidade: ELISA IgA x Cultura<br>stuay name Event‘etmeLover Upperft Totat vent rte and 9%1 Reiatveweight‘weight randomRelateweight Residual| ste Resuatsta Residuala suay name Eventest LowerLew UpperUoeeT al Eventrte and 95% C1 Relaiveeight Random)ee RelaiveFle StStd RecdualSud Recs!Std<br>Arjetat, 188 0904 0912 1,000 82/09 <0 128 Aajetal, 1988 0953 0.900 1000 72/72 sos 076<br>ee ee tne beet terrane ae A Aaajetal, 1990 0.969 0,650 0,998 15/15 4938 076<br>Penk 08K 0581 Oe . “ Pe ean ate 8088<br>Prediction interval 0,944 0,000 1,000 Preciction neva '<br>a a oo 02s ag rs 800<br>Heterogeneity: I-square=77.62, tau-squared=2.47, p=0.01 Heterogeneity: I-square=0.00, tau-squared=0.00, p=0.45<br><!-- End of picture text -->  
Figura F. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) do ELISA IgA  
74  
<!-- Start of picture text -->
Sensibilidade: ELISA IgG/gM x Cultura Especificidade: ELISA laG/aM x Cultura<br>sus name ventrt and 9% 1 gm ancien sueynene venta and 9% 1 gn Rando<br>feet Lower Upper favre Ree Std std td feat Lower Upper a ee)<br>‘ae teat Tot ‘count "ght Remus! Renal Renu ‘et nt Tot ‘woont “weight Residual Renal Resa!<br>pentesanetal2017 0870814 0908 22/39 on os indesoiets<br>Fawane 2008 aro 0505 0987 105/202 woe a7 Fee ta, 20082017 0313.961 09880901 048615148o9#s. 98/109 —— =a] 141910 onsei<br>Atri eta.ea,201 20 2 0 geeaa 0 79669 09 9977 31/31e268 <a] 3035 208ost eraame t t,20120 2 0 grayo 0 8049% oan09m 5169 /7 20 a 1420ew 20 0<br>Precton mer ose 0880 099s Preto ea 005 005 1000<br>ny) as 0250s m0<br>Heterogeneity: Iquere=68.55, tau-squared=0.91, p=0.002 Heterogeneity: Isquare=94.34, tau-squared=4.17, p=0.00<br>Sensibilidade: ELISA IgG/lgM x Cultura e/ou SAT Especificidade: ELISA IgG/IgM x Cultura e/ou SAT<br>suoysame feat Lower Use svateteand 9.1 weaanso susyname Event tower Upper svatcateand 99401 ehfelae arden)Remtve Sid sit ste<br>mo tm “Hem To “ream ‘oust Restal Resa! Resi ow ‘et “Et Tot “teat ‘wouht Rebital Res! Reon<br>Haslett 2013 O7s0 0621 0846 42158 20s 120 Hast etal 2083 0998 a4 1000 128/126 tae oar<br>Fe a atetate eta, 2011 ( 600)E608 Union) oom0982 099 8 .9 O5881000 118 119o7 / 67 i 308mass os s F agetetataw 20 19 1 (€SasesUnos)6) 0 998574 0 se7995 0586ose tarts37/98 | | | 4 zzsr2r a7001<br>rr eT) Cn a eT)<br>Heterogeneity: Isquare=88.90, tau-squared=5.66, 9=0.00 Heterogeneity: I-square=0.00, tau-squared=0.00, p=0.54<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Figura G. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) do ELISA IgG/IgM -->
75  
Foram identificados quatro estudos<sup>191,194–196</sup> avaliando o desempenho de testes rápidos para brucelose humana, detectando classes de anticorpos IgG, IgM e IgG/IgM ( **Quadro I** ). Entre eles, apenas Marei et al. (2011)<sup>196</sup> apresenta dados de especificidade. Os estudos Abdoel et al. 2007<sup>194</sup> e Mizanbayeva et al. 2009<sup>191</sup> , consideraram cultura como teste de referência, sendo a medida sumarizada para sensibilidade para detecção de IgM, IgG e IgG/IgM de 74,3% [IC95%: 35,2–93,9; I<sup>2</sup> =91,9], 78,7 [IC95%: 70,0–85,4; I<sup>2</sup> =0,00] e 96,2 [IC95%: 70,4–99,6; I<sup>2</sup> =63,9], respectivamente. Para os estudos que consideram cultura e/ou SAT como teste de referência, foi possível estimar medidas sumarizadas de sensibilidade apenas para IgM, estimada em 70,6% [IC95%: 62,9–77,3; I<sup>2</sup> =0,00]  ( **Figura H** ).  
76

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro I. Estudos de avaliação de desempenho de testes rápidos para o diagnóstico da brucelose humana -->
|**Referência**|**Fabricante**|**Anticorpo detectado**|**Padrão**|**Definição de**<br>**não caso**|**N°**<br>**caso**|**N° não**<br>**caso**|**N°**<br>**total**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Abdl t l 2007**|_Omega Teknika_|IgM|Cultura|NR|45|NR|45|25|20|NR|NR|55,6|NR|
|**oe e a.**<br>152|_Omega Teknika_|IgG|Cultura|NR|45|NR|45|35|10|NR|NR|77,8|NR|
||_Omega Teknika_|IgM/IgG|Cultura|NR|45|NR|45|41|4|NR|NR|91,1|NR|
||_Organon Teknika_<br>_Ltd, Ireland_|IgM/IgG|Cultura|NR|63|NR|63|63|0|NR|NR|100,0|NR|
||_Organon Teknika_||Cultura|NR|63|NR|63|55|8|NR|NR|87,3|NR|
|**Mizanbayeva et**<br>**al. 2009**<sup>178</sup>|_Ltd, Dublin,_<br>_Ireland_|IgM||||||||||||
||_Organon Teknika_<br>_Ltd, Dublin,_<br>_Ireland_|IgG|Cultura|NR|63|NR|63|50|13|NR|NR|79,4|NR|
|**Clavijo et al., 2003**<br>163|_In house LPS-_<br>_impregnated_<br>_nitrocellulose strip_|IgM|Cultura<br>e/ou SAT|NR|133|NR|133|94|39|NR|NR|70,68|NR|
||_Royal Tropical_<br>_Institute,_<br>_Amsterdam,_<br>_Netherlands_|IgG|Cultura<br>e/ou SAT|Cultura e SAT|20|30|50|13|7|29|1|65|96,7|
|**Marei et al., 2011**<br>175|_Royal Tropical_<br>_Institute,_<br>_Amsterdam,_<br>_Netherlands_|IgM|Cultura<br>e/ou SAT|Cultura e SAT|20|30|50|14|6|29|1|70|96,7|
||_Royal Tropical_<br>_Institute,_<br>_Amsterdam,_<br>_Netherlands_|IgM/IgG|Cultura<br>e/ou SAT|Cultura e SAT|20|30|50|19|1|29|1|95|96,7|  
Legenda: NR - Não relatado; Sens - Sensibilidade; Esp - Especificidade; VP - Verdadeiro positivo; FN - Falso negativo; VN - Verdadeiro negativo; FP - Falso positivo.  
77  
<!-- Start of picture text -->
Sensibilidade: Teste rapido IgM x Cultura Sensibilidade: Teste rapido IgM x Cultura e/ou SAT<br>Heterogeneity: -square=91.98, tau-squared=1.34, p=0.00 Heterogeneity: square=0.00, tau-squared=0.00, 9=0.95<br>Sensibilidade: Teste rapido laG x Cultura Sensibilidade: Teste rapido IgM/IgG x Cultura<br>Seudy name Srest ete ond 975-01 Weight Random) ‘Study name Event rate and 95% Cl Weight (Random)<br>Sao ‘ame ‘Sin teu “rege ‘weiges ‘ciéunl fesiéual Residas! Event Lower Upper Relative Relative Std std std<br>Meminyeatt 208078 O67E NTE 50/62 —- ma 020 Aboe! et. 2007 ost 0785 a886 41/45 | an 4.00<br>enrognety art, vequrndo.0,po04 Hovrogenly:-quare=63.05,tausqurede202,peoosh® 02st<br><!-- End of picture text -->  
Figura H. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para o teste rápido  
O teste de _Coombs_ , dentre eles o teste comercial _Brucellacapt_<sup>®</sup> (Vircell, Espanha), foi avaliado em cinco estudos, sendo que em três<sup>194,197,198</sup> a cultura foi considerada como teste de referência e, em dois outros<sup>199,200</sup> , o teste de referência foi cultura e/ou SAT ( **Quadro J** ). Medidas sumarizadas de sensibilidade e especificidade de 93,1% [IC95%: 60,2–99,2; i<sup>2</sup> =71,5] e 98,4% [IC95%: 91,0–99,7; i<sup>2</sup> =18,9], respectivamente, foram estimadas considerando cultura como teste de referência e sensibilidade de 89,4% [IC95%: 30,0–99,4; i<sup>2</sup> =73,6] e especificidade de 98,8% [IC95%: 92,0–99,8; i<sup>2</sup> =0,00], considerando cultura e/ou SAT como teste de referência. De forma geral, alta heterogeneidade foi observada entre os estudos ( **Figura I** ).  
78

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro J. Estudos de avaliação de desempenho do teste de Coombs para o diagnóstico da brucelose humana. -->
|**Referência**|**Teste índex**|**Fabricante**|**Titulação**|**Padrão**|**Definição de não**<br>**caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**TOTAL**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Abdoel et al. 2007**<sup>152</sup>|_Coombs_|NR|>1:2560|Cultura|Outras doenças|45|NR|45|45|NR|NR|NR|100|NR|
|**Peeridogaheh et al. 2013**<sup>183</sup>|_Brucellacapt_<sup>_®_</sup>|(_Vircell SL,_<br>_Granada, Spain_)|NR|Cultura|Saudáveis|11|32|43|11|0|31|1|100|96,9|
|**Saz et al. 1987**<sup>186</sup>|_Coombs_|NR|>1:160|Cultura|Cultura e testes<br>convencionais<br>negativos|208|107|315|160|48|107|0|76,9|100|
|**Aranís et al., 2008**<sup>161</sup>|_Brucellacapt_<sup>_®_</sup>|(_Vircell SL,_<br>_Granada, Spain_)|NR|Cultura<br>e/ou<br>SAT|Outra doença e testes<br>convencionais<br>negativos|10|18|28|7|3|18|0|70|100|
|**Gómez e tal., 2008**<sup>170</sup>|_Brucellacapt_<sup>_®_</sup>|(_Vircell SL,_<br>_Granada, Spain_)|NR|Cultura<br>e/ou<br>SAT|Saudáveis|25|90|115|25|0|90|0|100|100|  
Legenda: NR - Não relatado; Sens - Sensibilidade; Esp - Especificidade; VP-: Verdadeiro positivo; FN - Falso negativo; VN - Verdadeiro negativo; FP - Falso positivo.  
79  
<!-- Start of picture text -->
Sensibilidade: Coombs X Cultura Especificidade: Coombs X Cultura<br>stusysame ent rate and 951 eh Random sug ame vettean 95% eon Random<br>vent Lower Uper Feaive Rose Skt ss vent Lower Upper fae fete<br>soa et.2007 etmeaes oss “mt0989 a5/4sTota ‘wen2078 “wonht Residual108 Resdul Restua Peencopannetal etme2013098 0902 0995 31/32Tt —BL ‘coont20 wet<br>sareal 1907 0769 0707 0821. 150/208 83s ast Peales ages 090 ose7<br>Pealee os os02 0992 Prudent 1<br>°<br>a eT)<br>Heterogeneity hsquare=71.5, tavssquared=2 63, p=0.03 oo 02s sas 0 Heterogenelty: Lsquare=18.91, taussquared=0.355 p=0.27<br>Sensibilidade: Coombs X Cultura efou SAT Especificidade: Coombs X Cultura e/ou SAT<br>study name Event rate and 96% ot Weight (Random) stugy name Event rate and 95% C1 Weight (Random)<br>Event Lower Upper Relative Relative std std std Event Lower Upper Relative Relative<br>rate tim ime Total, ‘weight weight Residual Residual Resigual rate limit mt Total weight weight<br>‘ransGomezetal,2008 0,700 0.376 0,900. 7/10 5621 4,00 Aranis eat, 2008 0.974 0690 0,908 18/18 447 F<br>PootedPredictiontal,tera 2008 0.8940981 03000,755 0.9040,809 25/25 [41,79 4,00 PooledPredictionGémez etal, eral2008 0.9680995 09180.920 0,9981,000 90/90 EE< 5053<br>Heterogeneity: hsquare=7356, teu-squared=3.49, p=0.05.ee) Heterogenety: |square=0.00,tau-squared=0.00, p=0.43a eT)<br><!-- End of picture text -->  
Figura I. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para o teste de Coombs.  
80  
O desempenho da PCR foi avaliado em nove estudos que utilizaram cultura como teste de referência e em quatro outros estudos utilizando cultura e/ou SAT como referência ( **Quadro K** ). Observou-se ampla diversidade metodológica nos estudos, especialmente em relação ao tipo de PCR realizada (PCR convencional, PCR tempo real, PCR-ELISA), tipo de primer e alvo utilizado (B4 e B5 [BCSP31]; JPF e JPR [OMP-2]; [IS711]; [virB4]; [16S RNA]) e tipo de amostra (sangue, soro e cultura de sangue). Foi possível estimar o desempenho sumarizado de acordo com a técnica utilizada (PCR convencional ou PCR tempo real) e em relação ao alvo utilizado (B4 ou B5 [BCSP31]), apenas para PCR convencional. No caso do estudo realizado por Al-Ajlan et al. 2011<sup>201</sup> , que avaliou a PCR convencional e a PCR tempo real em diferentes materiais biológicos, na estimativa de desempenho sumarizado foram considerados apenas os resultados em sangue, por ser o material biológico mais utilizado nos outros estudos incluídos.  
A PCR convencional em amostra de sangue foi avaliada em quatro estudos que consideravam a cultura como teste de referência. Nestes estudos, diferentes alvos foram utilizados, e a medida sumarizada de desempenho foi de 96,4% [IC95%: 69,6–99,7; i<sup>2</sup> =82,2] para sensibilidade e 98,1% [IC95%: 93,6 – 99,5; i<sup>2</sup> =30,7] para especificidade. Considerando apenas os dois estudos que avaliam PCR convencional utilizando _primers_ B4 e B5, sensibilidade de 90,9% [IC95%: 28,9–99,6; i<sup>2</sup> =81,1] e especificidade de 96,5% [IC95%: 89,8–98,9; i<sup>2</sup> =0,00], foram sumarizadas. Outros quatro estudos foram incluídos considerando a cultura e/ou SAT como teste de referência, a medida sumarizada de desempenho foi de 79,6% [IC95%: 47,6–94,4; i<sup>2</sup> =90,4] para sensibilidade e 96,0% [IC95%: 85,8–99,0; i<sup>2</sup> =47,8] para especificidade. Entre estes estudos, chama a atenção a baixa sensibilidade (45,5%) apresentada no estudo realizado por Hasibi et al. (2008)<sup>202</sup> , o que possivelmente se relaciona com o alto limite de detecção encontrado (1000fg). De acordo com Queipo-Ortuño et al. 1997<sup>203</sup> , o limite de detecção ideal da PCR para o diagnóstico de brucelose, seria próximo a 10fg, que seria equivalente a 2 bactérias, número de microrganismo possivelmente presente em amostra de 1 mL de sangue periférico de pacientes com doença clínica. Desta forma, excluído Hasibi et al. (2008)<sup>202</sup> das análises sumarizadas, observa-se redução da heterogeneidade, com sensibilidade de 93,3% [IC95%: 81,4–97,8; I<sup>2</sup> =24,9] e especificidade de 86,1% [IC95%: 80,0–90,5; I<sup>2</sup> =0,00] ( **Figura J** ).  
Foram incluídos apenas cinco estudos que avaliam o desempenho da PCR em tempo real, sendo em todos eles considerado cultura como teste de referência. A medida sumarizada de desempenho foi de 81,9% [IC95%: 66,9–91,0; i<sup>2</sup> =74,1] para sensibilidade e 91,5% [IC95%: 71,4– 97,9; I<sup>2</sup> =89,3] para especificidade. Estes estudos utilizam diferentes materiais biológicos e diversos alvos, não sendo possível estratificar os resultados de acordo com tais variáveis. Alto limite de detecção (1000 fg) foi também relatado por Patra et al. (2019)<sup>204</sup> . Em paralelo, Debeaumont et al. (2005)<sup>205</sup> relataram má preservação das amostras de soro antes da extração. No entanto, a exclusão de ambos os estudos no cálculo das medidas sumarizadas de desempenho não geraram alteração na medida de desempenho e em relação a heterogeneidade da análise, sendo relatado 93,6% [IC95%: 67,4–99,0; i<sup>2</sup> =80,7] de sensibilidade e 78,1% [IC95%: 47,5–93,3; I<sup>2</sup> =89,7] de especificidade ( **Figura K** ).  
81

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro K. Estudos de avaliação de desempenho da Reação em Cadeia da Polimerase (PCR) para o diagnóstico da brucelose humana -->
|**Referência**|**Teste índice**|**Primer (alvo) / Tipo**<br>**de amostra**|**Limite de**<br>**detecção**|**Definição**<br>**de caso**|**Definição de não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**TOTAL**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||PCR convencional|B4 e B5<br>(BCSP31)/Sangue|100 UFC/ml|Cultura|Saudáveis|89|40|129|64|25|38|2|71,9|95|
||PCR convencional|B4 e B5 (BCSP31)/<br>Cultura do sangue|NR|Cultura|Saudáveis|89|40|129|89|0|40|0|100|100|
||PCR convencional|B4 e B5<br>(BCSP31)/Soro|NR|Cultura|Saudáveis|89|40|129|48|41|40|0|53,9|100|
|**Al-Ajlan et al.**<br>**2011**<sup>154</sup>|PCR em tempo real|B4 e B5<br>(BCSP31)/Sangue|50<br>UFC/ ml|Cultura|Saudáveis|89|40|129|69|0|40|0|77,5|100|
||PCR em tempo real|B4 e B5<br>(BCSP31)/Cultura do<br>sangue|NR|Cultura|Saudáveis|89|40|129|89|20|40|0|100|100|
||PCR em tempo real|B4 e B5<br>(BCSP31)/Soro|NR|Cultura|Saudáveis|89|40|129|54|35|40|0|60,7|100|
|**Al-Nakkas et al.**<br>**2005**<sup>157</sup>|PCR convencional<br>(_Nested_)|(IS711)/Sangue|NR|Cultura|Outras doenças|89|244|333|89|0|244|0|100|100|
|**Ninri et al.**<br>**2003**<sup>180</sup>|PCR convencional|(16S RNA)/Sangue|NR|Cultura|Cultura e/ou SAT|20|25|45|20|0|25|0|100|100|
|**Queipo-Ortuno**<br>**et al. 1997**<sup>185</sup>|PCR convencional|B4 e B5<br>(BCSP31)/Sangue|10 fg|Cultura|Outra doença ou expostos<br>ou saudáveis|35|60|95|35|0|59|1|100|98,3|
|**Dal et al., 2018**<br>164|PCR em tempo real|(BCSP31)/Soro|80 UFC/mL|Cultura|Cultura|36|117|153|35|1|61|56|97,22|52,14|
|**Debeaumont et**<br>**al., 2005**<sup>165</sup>|PCR em tempo real|BCSP31 fw e rv<br>(BCSP31)/Soro|18 fg|Cultura|Saudáveis ou com outras<br>doenças|17|60|77|11|6|60|0|64,7|100|  
82  
|**Referência**|**Teste índice**|**Primer (alvo) / Tipo**<br>**de amostra**|**Limite de**<br>**detecção**|**Definição**<br>**de caso**|**Definição de não caso**|**N°**<br>**caso**|**N°**<br>**não**<br>**caso**|**N°**<br>**TOTAL**|**VP**|**FN**|**VN**|**FP**|**Sens**<br>**(%)**|**Esp**<br>**(%)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Patra et al.,**<br>**2019**<sup>182</sup>|PCR em tempo real|(virB4)/Sangue e<br>outros|1000 fg|Cultura|Outras doenças<br>infecciosas|61|54|107|42|19|54|0|68.9|100|
|**Zhao et al.,**<br>**2020**<sup>189</sup>|PCR em tempo real|JPF e JPR (OMP-<br>2)/Sangue|1000 fg|Cultura|Cultura|46|62|108|45|1|49|13|97,83|79,03|
||PCR-ELISA|B4 e B5<br>(BCSP31)/Sangue ou<br>soro|NR|Cultura|NR|179|NR|179|177|2|NR|NR|98,9|NR|
|**Vrioni et al.,**<br>**2004**<sup>187</sup>|PCR-ELISA|B4 e B5 (BCSP31)/<br>Sangue|NR|Cultura|NR|179|NR|179|167|12|NR|NR|93,3|NR|
||PCR-ELISA|B4 e B5 (BCSP31)/<br>Soro|NR|Cultura|NR|179|NR|179|159|20|NR|NR|88,8|NR|
|**Al-Attas et al.,**<br>**2000**<sup>155</sup>|PCR convencional|B4 e B5 (BCSP31)/<br>Sangue|30 fg|Cultura<br>e/ou SAT|Cultura e SAT [outras<br>doenças (18); expostos<br>(9); saudáveis (5)]|14|33|46|14|0|29|4|100|87,5|
|**Hasibi et al.,**<br>**2008**<sup>171</sup>|PCR convencional|B4 e B5 (BCSP31)/<br>Sangue|NR|Cultura<br>e/ou SAT|Controles saudáveis|37|78|115|15|22|78|0|45,5|100|
|**Marei et al.,**<br>**2011**<sup>175</sup>|PCR convencional|B4 e B5 (BCSP31)/<br>Soro|NR|Cultura ou<br>SAT|Cultura e SAT|20|30|50|17|3|29|1|85|96,7|
|**Ninri et al.**<br>**2003**<sup>180</sup>|PCR convencional|(16S RNA)/ Sangue|NR|Cultura<br>e/ou SAT|Cultura e/ou SAT|140|25|165|120|20|25|0|85,7|100|  
Legenda: NR - Não relatado; Sens - Sensibilidade; Esp - Especificidade; VP - Verdadeiro positivo; FN-Falso negativo; VN Verdadeiro negativo; FP - Falso positivo; UFC: unidades formadoras de colônia.  
83  
<!-- Start of picture text -->
Sensibilidade:ae PCR convencional x Cultura eotomantom eri teens aEspecificidade:PCR convencional x Cultura tment copa<br>imaamn<br>Smite oemt iea tamim oeme inan wz eeheeeee)I =ec =<br>Somecwramr) SSte ueins ostoe ea e = =a S acoeow ih eeoe as ane“am |—2aoss Pr<br>= i= et = oo Se oe =<br>otorogonenySensibitidade:| square=82PCR convencional17, tau squered=4 com primer93, B4p=0.00& BS (gone:BCSPS1) em sangue x Cutura Especificidade:Hoterogenety: square-30PCR convencional 89,tu-squared-0com primer82, B49-023€ BS (gene-BCSP31) em sangue x Cultura<br>— meme Eon oe soot antrm foe<br>sien ow aa eam am pa v= suman ta tat am ee aes py<br>= = im = te oe <<br>Heterogeneity:Sensibilidade:—— Lsquare=81.13,PCR convencionaltaussquared=4.x Cultura 48,  e/oup=0.02Sonoma SAT epee Especificidade:ey‘reteroger| squrPCR e =0 convencionalny 00, eu sauarede0x Cultura00. 2°0eone/ou 38 SATneerer enon<br>Slaten tee Soe ten oe = Se = Se aoe ouvkae eee: = 2<br>= eae ee i as Seraainn Sant are Gow 128 a ce<br>ceed Saul oe Say Renae Ser tin tae =,<br>‘Sensibilidade:teleroorety: EeveePCR convencional tii torevemet1.08x Cultura e/ou#8? SAT (com exciusto) _Especificidade:Heterogeneity Lsquaren47PCR convencional81, taw-sqvored0x Cultura93, px0.19/ou SAT (com exclusto)<br>a ‘etmemene eel —— Soetommt ee<br>rie SST aE nla maton i ed<br>ee oe rm soneme Sy ue gm ra ™ =<br>cam= GanSm onetine aneaoe mit —— i] = Secmo)~ Srimetne tomioe ona == 3<br>Hetorogenety, Lsquares24 90, tmsquared0.20, p=0.26 ‘Heterogeneity:squares0.00, ta-squared0.00, 0.55<br><!-- End of picture text -->  
Figura J. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para PCR convencional.  
84  
<!-- Start of picture text -->
Sensibilidade: PCR tempo real x Cultura Especificidade: PCR tempo real x Cultura<br>seudy ame Senta and 9981 ight fandom) study nome Event at nd 95 Wah fondo<br>Evert Lower Upper faitive Relate SS ent Lower Upper elie Relate Sd Std Sb<br>‘ce ‘iw “Ren Text rece "ag totaal Rectan! Rasa ‘oe on En Tota wig weight Residual Reual Resided<br>Annet<br>2011 077508770850 6889 ne 28 Aaja211 Os88 a aH 49/40 12 10<br>PareDaDebesument etaletal 202t2019ta. 2005 asare617 086dont040K 0782ser0832 4514611/1742/61 ‘08anass te1415 DaoPrDrtnnmonal,20209a, 2005 ogstorm0882 oars0608820509omoon 60/60suet9/8 204634139 am121m<br>Pron tral ca 02 ose Pree nal 0815 0069 0909<br>| om 2s 0st<br>Heterogeneity: L-square=74.12, tau-squared=0.52, p=0.00 Heterogeneity: | square=89.26, tau-squared=1.89, p=0.00<br>Sensibilidade: PCR tempo real x Cultura (com exclusdo) Especificidade: PCR tempo real x Cultura (com excluséo)<br>stugy name vent rate ana 9681 Weight (Random sw sane vot te ad 9581 igh anda<br>Event‘ate Lowertnt Upperme Tot Reiseeight Reliveweight Residualsts Resiualstg Resgualsts Event‘ate Lowertt Uppernk Tot Faniveeight Relive“WeibelStd Residualsiliesd!<br>AManetal 2011 075 0677 0,860 69/89 4416 121 AAjanetal 2011 0.988 0833 0868 40/40 1566 19<br>BraveDaletal,2018ps l,2020 0972face0978 0827oer0861 0906ooo0907 45/4625/26 20992045 os?073 DataPacedDuoetsl. ame20 osttamOTM Gastom7sAST2 a6omOTA 61/117481 a aeox oor18<br>Predctonieral 0996 0000 1,000 Prdcionetral 0781 6.01000<br>cco ans agosto eT)<br>Heterogeneity: I-square=80.72, tau-squared=2.34, p=0.00 Heterogeneity: I-square=89.72, tau-squared=1.09, p=0.00<br><!-- End of picture text -->  
Figura K. Estimativas de sensibilidade e especificidade (intervalo de confiança de 95%) para PCR em tempo real.  
85  
O risco de viés dos artigos de avaliação de acurácia dos testes diagnósticos para brucelose humana incluídos na revisão sistemática foi avaliado pela ferramenta Quadas-2<sup>206</sup> e encontra-se sumarizado no **Quadro** e na **Figura L** . No geral, observou-se que o risco de viés nos domínios referentes à seleção de pacientes, padrão de referência e fluxo e tempo, foi alto na maioria dos estudos e que a aplicabilidade foi baixa nos domínios referentes ao teste índice e padrão de referência.  
Quadro L. Avaliação do risco de viés pela ferramenta Quadas-2 para estudos de acurácia diagnóstica para brucelose humana  
|||**Risco**|**de viés**||**Preocupaçõ**|**es sobre a**|**plicabilidade**|
|---|---|---|---|---|---|---|---|
|**Estudo**|**Seleção dos**<br>**pacientes**|**Teste**<br>**índice**|**Padrão de**<br>**Referência**|**Fluxo e**<br>**tempo**|**Seleção dos**<br>**pacientes**|**Teste**<br>**índice**|**Padrão de**<br>**Referência**|
|Abdoel et al.,<br>2007||||||||
|Akhvlediani<br>et<br>al., 2017|?|?||||||
|<br>Al-Ajlan et al.,<br>2011||?||?||||
|Al-Attas et al.,<br>||?||||||
|2000||||||||
|Almashhadany<br>||?||||||
|et al. 2022||||||||
|,<br>Al-Nakkas et al.,<br>||?||||||
|2005||||||||
|<br>Al-Shamahy<br>et<br>al. 1998||?||||||
|,<br>Araj et al., 1988||||||||
|Araj et al., 1990||?||||||
|Aranãs<br>et<br>al.,<br>2008||?||||||
|Ayala et al., 2014||||||||
|Clavijo et al.,<br>2003||?||||||
|<br>Dal et al., 2018||?||||||
|Debeaumont<br>et<br>||?||||||
|al., 2005||||||||
|<br>Díaz et al., 2011|||||||?|
|Ertek et ak., 2006||?||||||
|Fadeel<br>et<br>al.,<br>||?||||||
|2006||||||||
|<br>Fadeel<br>et<br>al.,<br>2011||?||||||
|<br>Gómez e tal.,<br>2008||||||||
|<br>Hasibi<br>et<br>al.,<br>2008||||||||
|<br>Hasibi<br>et<br>al.,<br>2013||||||||
|<br>Kiel et al., 1987<br>Mantur et al.,<br>|?|?||?||||
|2010||||||||
|Marei et al., 2011||?||||||  
86  
|||**Risco**|**de viés**||**Preocupaçõ**|**es sobre ap**|**licabilidade**|
|---|---|---|---|---|---|---|---|
|**Estudo**|**Seleção dos**<br>**pacientes**|**Teste**<br>**índice**|**Padrão de**<br>**Referência**|**Fluxo e**<br>**tempo**|**Seleção dos**<br>**pacientes**|**Teste**<br>**índice**|**Padrão de**<br>**Referência**|
|Memish et al.,||?||||||
|2002||||||||
|Mert et al., 2003|Ls]|?<br>a|Ls]|o|5|5|Ls]|
|Mizanbayeva et||?<br><br>||?<br><br><br><br>|||~~|~~<br>~~5~~<br>~~5~~<br>~~a~~|
|al., 2009||||||||
|Nicoletti et al.,||?<br>|a|?<br><br>||5|5|a|
|1971||||||||
|Nimri et al., 2003||?<br>|||||a<br>5<br>5<br>a|
|Osoba<br>et<br>al.,<br>||?<br>|a|?<br><br>||5|L}|a|
|2001||||||||
|Patra et al., 2019|a|a|a|?<br>||L}|L}|a|
|Peeridogaheh et||?<br><br><br>|||||a<br>5<br>5<br>a|
|al., 2013<br>Purwar et al.,<br>2016||?<br><br>a|a|?<br><br>a|5|5|a|
|Queipo-Ortuño<br>||?<br><br>|||||a<br>5<br>5<br>a|
|et al. 1997||||||||
|,<br>Saz et al., 1987||?<br><br>i|a|?<br><br>i|5|5|?<br><br>a|
|Vrioni<br>et<br>al.,||?<br><br>|||||a<br>5<br>5<br>a|
|2004||||||||
|Xu et al., 2020||?<br><br>a|a|a|5|5|a|
|Zhao et al., 2020|o|?<br>a|o|o|o|5|is)|  
<!-- Start of picture text -->
Fluxo e Tempo mien<br>a<br>E Padrio de Referéncia<br>8<br>3 Teste index<br>3<br>Selegdo dos pacientes<br>0% = «20% += 40% = 60% + 80% + 100% 0% «20% += «40% += 60% = 80% 100%<br>Proporgio de estudos com baixo, alto ou no claro Proporcéo de estudos com baixo, alto ou no claro<br>RISCO DE VIES PREOCUPACOES SOBRE APLICABILIDADE<br><!-- End of picture text -->  
Figura L. Gráfico da avaliação do risco de viés pela ferramenta Quadas-2 para estudos de acurácia diagnóstica.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resumo das Evidências** -->
As medidas sumarizadas para a sensibilidade e especificidade dos testes diagnósticos avaliados para brucelose humana, assim como a heterogeneidade expressa através do I<sup>2</sup> estão apresentadas na **Tabela A** .  
87  
Tabela A. Medidas sumarizadas de desempenho dos testes diagnósticos avaliados para brucelose humana.  
|||**Cul**|**tura**||**Cultur**|**a e/ou**|**SAT**<br>**Esecificida**||
|---|---|---|---|---|---|---|---|---|
|**Teste Diagnóstico**|**Sensibilidade**<br>**(%) [IC95%]**|**I²**|**Especificidade**<br>**(%) [IC95%]**|**I²**|**Sensibilidade**<br>**(%) [IC95%]**|**I²**|**p**<br>**de (%)**<br>|**I²**|
|**Diagnóstico imunoló**|<br> **gico**<br>||<br>||<br>||**[IC95%]**<br>||
|Rosa Bengala|89,7<br>[82,0–94,4]|70,8|94,1<br>[83,1–98,1]|90,3|96,6<br>[92,6–98,5]|0,00|97,9<br>[93,1–99,4]|<sup>0,00</sup>|
|SAT|89,2<br>[81,4–94,0]|85,2|95,6<br>[89,7–98,1]|89,2|-|-|-|-|
|ELISA IgG|82,9<br>[59,5–94,1]|92,7|96,2<br>[80,6–99,4]|86,1|85,8<br>[75,5–92,2]|0,00|99,0<br>[95,3–99,8]|<sup>0,00</sup>|
|ELISA IgM|84,5<br>[68,0–93,3]|86,5|95,3<br>[87,5–98,4]|56,3|55,3<br>[47,8–62,7]|0,00|96,8<br>[59,5–99,8]|<sup>73,5</sup>|
|ELISA IgA|94,4<br>[68,1–99,2]|77,6|98,5<br>[90,3–99,8]|0,00|-|-|-|-|
|ELISA IgG/IgM|94,3<br>[87,5–97,5]|68,6|93,5<br>[75,8–98,5]|94,3|96,8<br>[60,8–99,8]|88,9|98,6<br>[96,1–99,5]|<sup>0,00</sup>|
|Teste Rápido IgG|78,7<br>[70,0-85,4]|0,00|-|-|-|-|-|-|
|Teste Rápido IgM|74,3<br>[35,2–93,9]|91,9|-|-|70,6<br>[62,9–77,3]|0,00|-|-|
|Teste Rápido<br>IgG/IgM|96,2<br>[70,4–99,6]|63,9|-|-|-|-|-|-|
|_Coombs_|93,1<br>[60,2–99,2]|71,5|98,4<br>[91,0-99,7]|18,9|89,4<br>[30,0–99,4]|73,6|98,8<br>[92,0–99,8]|<sup>0,00</sup>|
|**Diagnóstico molecul**|**ar**||||||||
||964||981||796||960||
|PCR convencional|,<br>[69,6–,99,7]|82,2|,<br>[93,6–99,5]|30,7|,<br>[47,6–94,4]|90,4|,<br>[85,8 – 99,0]|<sup>47,8</sup>|
|PCR convencional<br>(com exclusão)|-|-|-|-|93,3<br>[81,4–97,8]|24,9|86,1<br>[80,0–90,5]|0,00|
|PCR convencional<br>[_Primer_B4B5]|90,9<br>[28,9–99,6]|81,1|96,5<br>[89,8–98,9]|0,0|-|-|-|-|
|PCR em tempo real|81,9<br>[66,9–91,0]|74,1|91,5<br>[71,4–97,9]|89,3|-|-|-|-|
|PCR em tempo real<br>(com exclusão)|93,6<br>[67,4–99,0]|80,7|78,1<br>[47,5–93,3]|89,7|-|-|-|-|  
Considerando as imperfeições de ambos os padrões de referência avaliados nesta revisão sistemática, o padrão composto por Cultura e/ou SAT parece se aproximar mais do diagnóstico real, apresentando ainda, de forma geral, menor heterogeneidade entre os estudos avaliados. Em relação aos testes índices, para o teste rápido, observa-se <mark>ausência de dados de especificidade e para o teste de</mark> _<mark>Coombs</mark>_ <mark>pelo número limitado de estudos.</mark>  
88

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Perfil de evidências:** -->
A certeza da evidência foi avaliada <mark>pelo sistema GRADE, para os seguintes testes: Rosa bengala, E</mark> LISA IgG/IgM e <mark>PCR convencional (</mark> **<mark>Quadro M</mark>** <mark>,</mark> **<mark>Quadro N</mark>** <mark>e</mark> **<mark>Quadro O</mark>** <mark>, respectivamente), considerando cultura e/ou SAT como comparador.</mark>  
Em todas as comparações, a certeza da evidência foi classificada como muito baixa, limitando a utilização destes resultados de forma isolada para tomada de decisão.  
89

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro M. Avaliação da certeza da evidência pelo sistema GRADE para Rosa Bengala. -->
**Pergunta** : Deve-se usar Rosa Bengala para diagnosticar Brucelose em pacientes suspeitos?  
|**Desfecho**|**№ dos estudos**<br>**(№ de**<br>**pacientes)**|**delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Fatores que**<br>**Evidência**<br>**indireta**|**podem diminuir a**<br>**inconsistência**|**certeza da evid**<br>**Imprecisão**|**ência**<br>**Viés de publicação**|**Efeito por 100.000**<br>**pacientes testados**<br>**probabilidade pré-**<br>**teste de 1.92%**|**Força da**<br>**recomendação**|
|---|---|---|---|---|---|---|---|---|---|
|**Verdadeiros-positivos**<br>**Falsos-negativos**|3 estudos<br>178 pacientes|estudos de<br>coorte e caso-<br>controle|muito<br>grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|viés de publicação<br>altamente suspeito<sup>c</sup>|1855 (1778 para<br>1891)<br>65 (29 para 142)|⨁◯◯◯<br>muito baixa|
|**Verdadeiros-negativos**<br>**Falsos-positivos**|2 estudos<br>120 pacientes|estudos de<br>coorte e caso-<br>controle|muito<br>grave<sup>d</sup>|grave<sup>e</sup>|não grave|grave<sup>b</sup>|viés de publicação<br>altamente suspeito<sup>c</sup>|96020 (91312 para<br>97492)<br>2060 (588 para<br>6768)|⨁◯◯◯<br>muito baixa|  
Explicações  
a. Três estudos apresentam risco de viés em relação a seleção dos pacientes, padrão de referência e fluxo e tempo. Além disso, em um estudo há também risco de viés referente ao teste índice.  
b. Observa-se pequeno número de pacientes avaliados (<300 pacientes).  
c. Observa-se predomínio de estudos pequenos com desempenho muito alto. A ausência de estudos grandes sugere ocorrência de viés.  
d. Ambos os estudos apresentam risco de viés em relação a seleção dos pacientes, padrão de referência e fluxo e tempo. Além disso, em um estudo há também risco de viés referente ao teste índice.  
e. A especificidade foi avaliada em relação a pacientes saudáveis e não em pacientes suspeitos.  
Quadro N. Avaliação da certeza da evidência pelo sistema GRADE para ELISA IgG/IgM.  
90

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Pergunta** : Deve-se usar ELISA IgG/IgM para diagnosticar Brucelose em pacientes suspeitos? -->
|**Desfecho**|**№ dos**<br>**estudos**<br>**(№ de**<br>**pacientes)**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Fatores que pod**<br>**Evidência**<br>**indireta**|**em diminuir a cer**<br>**Inconsistência**|**teza da evidên**<br>**Imprecisão**|**cia**<br>**Viés de**<br>**publicação**|**Efeito por 100.000**<br>**pacientes testados**<br>**Probabilidade pré-teste**<br>**de1.92%**|**Força da**<br>**recomendação**|
|---|---|---|---|---|---|---|---|---|---|
|**Verdadeiros-**<br>**positivos**<br>**Falsos-negativos**|2 estudos<br>242 pacientes|estudo de acurácia<br>do tipo caso-<br>controle|muito<br>grave<sup>a</sup>|não grave|grave<sup>b</sup>|não grave|nenhum|1859 (1167 para 1916)<br>61 (4 para 753)|⨁◯◯◯<br>Muito baixa|
|**Verdadeiros-**<br>**negativos**|2 estudos<br>309 pacientes|estudo de acurácia<br>do tipo caso-<br>controle|muito<br>grave<sup>a</sup>|grave<sup>c</sup>|não grave|não grave|nenhum|96707 (94255 para<br>97590)|⨁◯◯◯<br>Muito baixa|
|**Falsos-positivos**||||||||1373 (490 para 3825)||  
Quadro O. Avaliação da certeza da evidência pelo sistema GRADE para PCR convencional.  
91

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Pergunta** : Deve-se usar PCR convencional para diagnosticar Brucelose em pacientes suspeitos? -->
|**Desfecho**|**№ dos**<br>**estudos**<br>**(№ de**<br>**pacientes)**|**Delineamento do**<br>**estudo**|**Fator**<br>**Risco de viés**|**es que podem diminui**<br>**Evidência indireta**|**r a certeza da evi**<br>**Inconsistência**|**dência**<br>**Imprecisão**|**Viés de publicação**|**Efeito por 100.000**<br>**pacientes testados**<br>**Probabilidade pré-**<br>**teste de1.92%**|**Força da**<br>**recomendação**|
|---|---|---|---|---|---|---|---|---|---|
|**Verdadeiros-**<br>**positivos**<br>**Falsos-**<br>**negativos**|4 estudos<br>211<br>pacientes|estudos de coorte<br>e caso-controle|muito grave<sup>a</sup>|grave<sup>b</sup>|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|1528 (914 para 1812)<br>392 (108 para 1006)|⨁◯◯◯<br>Muito baixa|
|**Verdadeiros-**<br>**negativos**<br>**Falsos-positivos**|4estudos<br>166<br>pacientes|estudos de coorte<br>e caso-controle|muito grave<sup>a</sup>|grave<sup>b,e</sup>|grave<sup>c</sup>|grave<sup>d</sup>|nenhum|94157 (84153 para<br>97099)<br>3923 (981 para<br>13927)|⨁◯◯◯<br>Muito baixa|  
Explicações:  
a. Três estudos apresentam risco de viés em relação a seleção de pacientes, padrão de referência e fluxo e tempo.  
b. Diferentes alvos são avaliados nos estudos incluídos.  
c. Observa-se variabilidade nas estimativas de efeito e intervalos de confiança que não se sobrepõem.  
d. Pequeno número de pacientes avaliados.  
e. A especificidade foi avaliada em relação a pacientes saudáveis e não em pacientes com suspeita da doença em ao menos um estudo.  
92  
**Formulação de recomendações pelo método GRADE (** **_Evidence to decision table_ - EtD):**  
O processo de formulação de recomendações por meio de um painel de especialistas, conduzido em setembro de 2023, é descrito a seguir. Nesse painel foram formuladas recomendações sobre o uso das tecnologias Rosa Bengala, ELISA IgG/IgM e PCR para o diagnóstico da brucelose humana, baseando-se nas contribuições do painel de especialistas apoiado pela síntese de evidências realizada pelo grupo elaborador.  
A **Tabela B** apresenta o processo de tomada de decisão sobre o uso do teste de Rosa Bengala para o diagnóstico de brucelose humana, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
Tabela B. Processo de tomada de decisão referente ao uso do teste de Rosa Bengala para o diagnóstico de brucelose humana  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Benefícios:|Preciso|Acurácia: 97,9%; Certeza da evidência muito baixa<br>(limitações metodológicas); Dados da literatura<br>advém de pacientes com forma sistêmica não sendo<br>possível estratificação por tempo da doença ou<br>espécie de_Brucella._|
|Efeitos desejáveis|Grande|Sensibilidade: 96,6% (IC95%: 92,6–98,5). Em<br>**1920**pacientes,**1855**(1778 a 1891) foram<br>diagnosticados corretamente.|
|Efeitos<br>indesejáveis|Moderado|Em 98.080 pacientes,**2.060**(588 a 6768)<br>diagnosticados erroneamente.<br>Foi discutida a ansiedade e o estigma relacionado a<br>ter a doença; os gastos desnecessários com<br>tratamento, eventos adversos e possibilidade de<br>resistência antimicrobiana e que deixar de tratar o<br>correto agente causador epossívelpiora clínica.|
|Certeza da<br>evidência:|Muito baixa|A certeza geral da evidência foi considerada muito<br>baixa. Os domínios rebaixados foram: risco de<br>viés; evidência indireta; imprecisão; viés de<br>publicação.<br>Foi discutido que isso se baseia na evidência<br>disponível até o momento|
|Custos:|Grande economia|Custo unitário:**R$0,15 a R$0,50**(Cotação Lacen<br>MG e PR), considerando apenas os reagentes.<br>Foi discutido que, além do custo por teste, há a<br>manutenção do equipamento, pessoal, além da<br>variabilidadepor kits utilizados|
|Equidade:|Aumenta|Simples realização (manual)<br>Laboratórios com simples infraestrutura (uso de<br>centrífuga)<br>Profissional treinado<br>Universalidade do teste|  
93  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Aceitabilidade:|Provavelmente sim|Resultado em menos de trinta minutos<br>Utilização de amostras de soro<br>Preferência dos profissionais para realização do<br>testepor sua simplicidade|
|Viabilidade de<br>implementação:|Sim|Necessita de treinamento do técnico para avaliação<br>do resultado<br>Kits comerciais disponíveis e registrados na<br>ANVISA Estrutura implantada nopaís|  
Fonte: Autoria própria.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Recomendação:** -->
Recomendação a favor e condicional para a intervenção, devido à baixa certeza da evidência.  
Considerações para subgrupos: A evidência disponível não aponta recomendações para subgrupos.  
Considerações para implementação: variabilidade dos kits.  
Monitoramento e avaliação: Avaliação do acesso aos testes e manutenção (disponibilidade dos testes); Estudos de validação dos kits diagnósticos.  
Prioridades em pesquisa: Necessidade de estudos com população brasileira.  
A **Tabela C** apresenta o processo de tomada de decisão sobre o uso do teste de ELISA IgG/IgM para o diagnóstico de brucelose humana, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
Tabela C. Processo de tomada de decisão referente ao uso do teste de ELISA IgG/IgM para o diagnóstico de brucelose humana  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Benefícios:|Preciso|Acurácia: 98,6%<br>Certeza da evidência muito baixa (limitações<br>metodológicas)<br>Dados da literatura advém de pacientes com forma<br>sistêmica não sendo possível estratificação por<br>tempo da doença ou espécie de_Brucella_|
|Efeitos desejáveis|Grande|Sensibilidade: 96,8% (IC95%: 60,8–99,8)<br>Em 1920 pacientes, 1859 (1167 a 1916) foram<br>diagnosticados corretamente<br>Grande intervalo de confiança|
|Efeitos<br>indesejáveis|Pequeno|Em 98.080 pacientes, 1.373 (490 a 3825) foram<br>diagnosticados erroneamente|  
94  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|||Foi discutida a ansiedade e o estigma relacionado a<br>ter a doença; os gastos desnecessários com<br>tratamento, eventos adversos e possibilidade de<br>resistência antimicrobiana e que deixar de tratar o<br>correto agente causador epossívelpiora clínica.|
|Certeza da<br>evidência:|Muito baixa|A certeza geral da evidência foi considerada muito<br>baixa<br>Os domínios rebaixados foram: risco de viés;<br>evidência indireta; imprecisão; viés de publicação<br>Foi discutido que isso se baseia na evidência<br>disponível até o momento|
|Custos:|Grande economia|Custo unitário:**R$12,71 a R$99,60**(Cotação<br>Lacen MG e PR), considerando apenas os<br>reagentes.<br>Foi discutido que, além do custo por teste, há a<br>manutenção do equipamento, pessoal, além da<br>variabilidadepor kits utilizados|
|Equidade:|Provavelmente<br>reduz|Relativamente simples realização (automação)<br>Equipamentos específicos (centrífuga e leitor de<br>ELISA)<br>Profissional treinadopara operá-los|
|Aceitabilidade:|Provavelmente sim|Resultado em média de 4 horas<br>Utilização de amostras de soro|
|Viabilidade de<br>implementação:|Provavelmente sim|Possibilita automação do processo (maior escala)<br>Kits comerciais disponíveis e registrados na<br>ANVISA<br>Testes comerciais e equipamento automatizado|  
Fonte: Autoria própria.  
Recomendação a favor e condicional para a intervenção, devido à baixa certeza da evidência.  
Considerações para subgrupos: A evidência disponível não aponta recomendações para subgrupos.  
Considerações para implementação: variabilidade dos kits.  
Monitoramento e avaliação: Avaliação do acesso aos testes e manutenção (disponibilidade dos testes); Estudos de validação dos kits diagnósticos.  
Prioridades em pesquisa: Necessidade de estudos com população brasileira.  
A **Tabela D** apresenta o processo de tomada de decisão sobre o uso do teste de PCR para o diagnóstico de brucelose humana, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
95  
Tabela D. Processo de tomada de decisão referente ao uso do teste de PCR para o diagnóstico de brucelose humana  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Benefícios:|Preciso|Acurácia: 95,9%<br>Certeza da evidência muito baixa (limitações<br>metodológicas)<br>Dados da literatura advém de pacientes com forma<br>sistêmica não sendo possível estratificação por<br>tempo da doença ou espécie de_Brucella_.|
|Efeitos desejáveis|Moderado|Sensibilidade: 93,3% (IC95%: 81,4–97,8)<br>Em 1920 pacientes, 1791 (914 a 1812) foram<br>diagnosticados corretamente.<br>Sensibilidade menor comparado ao Elisa e Rosa<br>bengala|
|Efeitos<br>indesejáveis|Grande|Em 98.080 pacientes, 3.923 (981 a 13927)<br>diagnosticados erroneamente<br>Foi discutida a ansiedade e o estigma relacionado a<br>ter a doença; os gastos desnecessários com<br>tratamento, eventos adversos e possibilidade de<br>resistência antimicrobiana e que deixar de tratar o<br>correto agente causador epossívelpiora clínica.|
|Certeza da<br>evidência:|Muito baixa|A certeza geral da evidência foi considerada muito<br>baixa<br>Os domínios rebaixados foram: risco de viés;<br>evidência indireta; imprecisão; viés de publicação<br>Foi discutido que isso se baseia na evidência<br>disponível até o momento|
|Custos:|Custo grande|Custo unitário: R$50,00 (valor de mercado)<br>Custo de manutenção da plataforma<br>Foi discutido que, além do custo por teste, há a<br>manutenção da plataforma, pessoal, além da<br>variabilidade por kits utilizados e de estrutura<br>diferenciada|
|Equidade:|Reduz|Técnica laboriosa<br>Demanda maior infraestrutura e equipamentos<br>mais complexos (máquina de PCR)<br>Profissionais especializados|
|Aceitabilidade:|Provavelmente não|Resultado em torno de 8 horas<br>Utilização de amostras de sangue(risco biológico)|
|Viabilidade de<br>implementação:|Provavelmente não|Complexidade no processo e difícil padronização<br>Diagnóstico<br>“in<br>house”,<br>ausência<br>de<br>kits<br>comerciais Requerer disponibilidade simultânea de<br>diferentes reagentes (kit de extração, enzima,<br>primer, equipamento, etc)<br>Grande estrutura, diferentes primers, requer<br>processos de validação em cada laboratório.<br>Restrito ao PR eSP atualmente.|  
Fonte: Autoria própria.  
96  
Recomendação a favor e condicional para a intervenção, devido à baixa certeza da evidência. Há ressalvas na recomendação do PCR devido à necessidade de padronização do teste.  
Considerações para subgrupos: A evidência disponível não aponta recomendações para subgrupos.  
Considerações para implementação: complexidade e custo.  
Monitoramento e avaliação: Necessidade de rígida padronização.  
Prioridades em pesquisa: Necessita de mais estudos, oportunidade de pesquisa. Lacuna de estudos com a população brasileira.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **QUESTÃO 2: A combinação de doxiciclina + sulfato de gentamicina é tão eficaz e segura quanto a doxiciclina + sulfato de estreptomicina no tratamento da brucelose humana?** -->
**Recomendação:** Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS da doxiciclina associada ao sulfato de gentamicina, conforme Relatório de Recomendação nº 901/2024, disponível em: https://www.gov.br/conitec/pt-br/midias/relatorios/2024/sulfato-de- <u>gentamicina-combinado-a-doxiciclina-para-o-tratamento-brucelose-humana</u>  
A resposta dessa pergunta foi obtida a partir de uma estratégia ampla que incluiu uma revisão sistemática com meta-análise em rede, sobre o tratamento da brucelose humana e a seguinte pergunta de pesquisa: Qual é a eficácia e segurança das estratégias terapêuticas para o tratamento da brucelose humana?  
Posteriormente, a pergunta específica comparando as tecnologias doxiciclina associado a sulfato de gentamicina e doxiciclina associado a sulfato de estreptomicina foram objeto de elaboração de um Relatório de Recomendação avaliado pela Conitec, a fim propor a incorporação do esquema doxiciclina associado a sulfato de gentamicina, tecnologia ainda não disponibilizado no SUS.  
A estrutura PICOS para esta pergunta foi:  
**População:** Casos confirmados de brucelose humana  
**Intervenção:** Monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana.  
**Comparador:** Monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana.  
**Desfechos:** Insucesso do tratamento (desfecho combinado considerando falha terapêutica/resposta ao tratamento + recidiva + perdas de acompanhamento), tempo de defervescência e incidência de eventos adversos.  
97  
**Desenho de estudo:** Ensaios clínicos randomizados.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Métodos e Resultados da Busca** -->
Foi realizada a busca sistematizada da literatura nas bases de dados _Medline_ (via _Pubmed_ ), _Embase_ , _Cochrane Library_ e BVS até a data de 06 de janeiro de 2023. As estratégias de busca para cada base estão descritas no **Quadro P** .  
98  
Quadro P. Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o tratamento da brucelose humana  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>(via<br>Pubmed)|<br>**População:**<br>**#1**(Brucellosis[MeSH Terms]) OR (Brucellosis) OR (Brucelloses) OR (Malta Fever) OR (Fever, Malta) OR (Gibraltar Fever) OR<br>(Fever, Gibraltar) OR (Rock Fever) OR (Fever, Rock) OR (Cyprus Fever) OR (Fever, Cyprus) OR (Brucella Infection) OR (Brucella<br>Infections) OR (Infection, Brucella) OR (Undulant Fever) OR (Fever, Undulant) OR (Brucella abortus) OR (Brucella canis) OR<br>(Brucella melitensis)OR(Brucella ovis)OR(Brucella suis)|<br> <br> <br>1472|
||**Intervenção:**<br>**#2**(tetracycline[MeSH Terms]) OR (doxycycline[MeSH Terms]) OR (gentamicin[MeSH Terms]) OR (ciprofloxacin[MeSH<br>Terms]) OR (levofloxacin[MeSH Terms]) OR (ofloxacin[MeSH Terms]) OR (therapeutics[MeSH Terms]) OR(Tetracycline) OR<br>(Tetrabid) OR (4-Epitetracycline) OR (4 Epitetracycline) OR (Topicycline) OR (Achromycin V) OR (Hostacyclin) OR (Tetracycline<br>Hydrochloride) OR (Tetracycline Monohydrochloride) OR (Sustamycin) OR (Achromycin) OR (doxycycline) OR (Doxycycline<br>Monohydrate) OR (Vibramycin) OR (Atridox) OR (Doxycycline Phosphate (1:1)) OR (BMY-28689) OR (BMY 28689) OR<br>(BMY28689) OR (BU-3839T) OR (BU 3839T) OR (BU3839T) OR (Doryx) OR (Doxycycline Calcium Salt (1:2)) OR (Doxycycline<br>Hyclate)<br>OR<br>(Doxycycline<br>Hemiethanolate)<br>OR<br>(Doxycycline<br>Monohydrochloride,<br>6-epimer)<br>OR<br>(Doxycycline<br>Monohydrochloride, 6 epimer) OR (Doxycycline Monohydrochloride, Dihydrate) OR (Doxycycline Calcium) OR (2-<br>Naphthacenecarboxamide, 4-(dimethylamino)-1,4,4a,5,5a,6,11,12a-octahydro-3,5,10,12,12a-pentahydroxy-6-methyl-1,11-dioxo-,<br>(4S-(4alpha,4aalpha,5alpha,5aalpha,6alpha,12aalpha))-) OR (Alpha-6-Deoxyoxytetracycline) OR (Alpha 6 Deoxyoxytetracycline)<br>OR (Doxycycline-Chinoin) OR (Doxycycline Chinoin) OR (Hydramycin) OR (Oracea) OR (Periostat) OR (Vibra-Tabs) OR (Vibra<br>Tabs) OR (Vibramycin Novum) OR (Vibravenos) OR (minocycline) OR (Minox 50) OR (Aknemin) OR (Aknin-Mino) OR (Aknin<br>Mino) OR (Aknosan) OR (Mynocine) OR (Apo-Minocycline) OR (Apo Minocycline) OR (Arestin) OR (Blemix) OR (Cyclomin)<br>OR (Cyclops) OR (Dentomycin) OR (Dynacin) OR (Icht-Oral) OR (Icht Oral) OR (Klinomycin) OR (Lederderm) OR (Mestacine)<br>OR (Minakne) OR (Mino-Wolff) OR (Mino Wolff) OR (Minocin) OR (Minocin MR) OR (Minoclir) OR (Minocycline<br>Hydrochloride) OR (Hydrochloride, Minocycline) OR (Minocycline Monohydrochloride) OR (Monohydrochloride, Minocycline)<br>OR (Minocycline, (4R-(4 alpha,4a beta,5a beta,12a beta))-Isomer) OR (Minolis) OR (Minomycin) OR (Minoplus) OR (Minotab)<br>OR (Akamin) OR (Akne-Puren) OR (Akne Puren) OR (gentamicins) OR (Gentamycins) OR (Garamycin) OR (Gentacycol) OR<br>(Gentamicin Sulfate) OR (Sulfate (Gentamicin) OR (Gentamicin Sulfate (USP)) OR (Gentavet) OR (Genticin) OR (G-Myticin) OR<br>(G Myticin) OR (GMyticin) OR (Gentamicin) OR (Gentamycin) OR (streptomycin) OR (Streptomycine Panpharma) OR<br>(Streptomycin Grünenthal)OR(Estreptomicina CEPA)OR(Strepto-Hefa)OR(Strepto Hefa)OR(Estreptomicina Clariana)OR|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|  
99  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||(Estreptomicina Normon) OR (Strepto-Fatol) OR (Strepto Fatol) OR (Streptomycin Sulfate) OR (Streptomycin Sulfate (2:3) Salt)<br>OR (Streptomycin Sulphate) OR (rifampicin) OR (Benemycin) OR (Rifampicin) OR (Rimactan) OR (Tubocin) OR (Rifadin) OR<br>(Rimactane) OR (ciprofloxacin) OR (Ciprofloxacin Hydrochloride Anhydrous) OR (Anhydrous, Ciprofloxacin Hydrochloride) OR<br>(Hydrochloride Anhydrous, Ciprofloxacin) OR (Cipro) OR (Ciprofloxacin Hydrochloride) OR (Hydrochloride, Ciprofloxacin) OR<br>(Ciprofloxacin Monohydrochloride Monohydrate) OR (Monohydrate, Ciprofloxacin Monohydrochloride) OR (Monohydrochloride<br>Monohydrate, Ciprofloxacin) OR (Bay-09867) OR (Bay 09867) OR (Bay09867) OR (Ciprinol) OR (levofloxacin) OR (Ofloxacin,<br>(S)-Isomer) OR (Levofloxacin Anhydrous) OR (Anhydrous, Levofloxacin) OR (Quixin) OR (Levaquin) OR (ofloxacin) OR<br>(Ofloxacine) OR (Tarivid) OR (ORF-28489) OR (ORF 28489) OR (ORF28489) OR (DR-3355) OR (DR 3355) OR (DR3355) OR<br>(Hoe-280) OR (Hoe 280) OR (Hoe280) OR (Ofloxacin Hydrochloride) OR (Ru-43280) OR (Ru 43280) OR (Ru43280) OR (DL-<br>8280) OR (DL 8280) OR (DL8280) OR (aminoglycosides) OR (macrolides) OR (macrolide) OR (Therapeutics) OR (Therapeutic)<br>OR (Therapy) OR (Therapies) OR (Treatment) OR (Treatments) OR (Anti-Bacterial Agents) OR (Agents, Anti-Bacterial) OR (Anti<br>Bacterial Agents) OR (Antibacterial Agents) OR (Agents, Antibacterial) OR (Antibacterial Agent) OR (Agent, Antibacterial) OR<br>(Anti-Bacterial Compounds) OR (Anti Bacterial Compounds) OR (Compounds, Anti-Bacterial) OR (Anti-Bacterial Agent) OR<br>(Agent, Anti-Bacterial) OR (Anti Bacterial Agent) OR (Anti-Bacterial Compound) OR (Anti Bacterial Compound) OR (Compound,<br>Anti-Bacterial) OR (Bacteriocidal Agents) OR (Agents, Bacteriocidal) OR (Bacteriocidal Agent) OR (Agent, Bacteriocidal) OR<br>(Bacteriocide)OR(Bacteriocides)OR(Antibiotics)OR(Antibiotic)|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>|
||**Desenho do estudo:**<br>**#3**((("clinical"[Title/Abstract] AND "trial"[Title/Abstract]) OR "clinical trials as topic"[MeSH Terms] OR "clinical<br>trial"[Publication Type] OR "random*"[Title/Abstract] OR "random allocation"[MeSH Terms] OR "therapeutic use"[MeSH<br>Subheading]) AND "humans"[MeSH Terms]) NOT "animals"[MeSH Terms:noexp]<br>**#4**#1 AND #2 AND #3||
|EMBASE|<br>**População:**<br>**#1**'brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR 'mediterranean fever (brucellosis)' OR<br>'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR 'brucella abortus' OR 'bacterium<br>abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella<br>canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis'|100<br> <br> <br> <br> <br> <br>1727|  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||**Intervenção:**<br>**#2**‘Therapy’/syn OR 'doxycycline'/syn OR 'doxycycline' OR 'gentamicin'/syn OR 'gentamicin' OR 'rifampicin'/syn OR 'rifampicin'<br>OR 'streptomycin'/syn OR 'streptomycin' OR 'ciprofloxacin'/syn OR 'ciprofloxacin' OR 'macrolide'/syn OR 'macrolide' OR<br>'aminoglycoside'/syn OR 'aminoglycoside' OR 'quinolone'/syn OR 'quinolone'|<br>|
||**Desenho do estudo:**<br>**#3**(‘randomized controlled trial’/exp OR ‘clinical trial’/exp OR ‘comparative study’/exp OR ‘controlled study’/de OR ‘evaluation<br>study’/de OR ‘human experiment’/exp OR random*:ab,ti OR control*:ab,ti OR ‘intervention study’:ab,ti OR ‘experimental<br>study’:ab,ti OR trial:ab,ti OR trials:ab,ti OR compar*:ab,ti OR repeat*:ab,ti OR crossover:ab,ti OR ‘double blind’:ab,ti OR<br>evaluat*:ab,ti OR ‘before and after’:ab,ti OR ‘interrupted time series’:ab,ti) NOT (‘animal’/exp NOT ‘human’/exp)<br>**#4**#1 AND #2 AND #3 AND[humans]/lim AND[embase]/lim|<br> <br>|
|Cochrane<br>Library|**População:**<br>**#1**MeSH descriptor: [Brucellosis] explode all trees<br>**População:**<br>**#2**'brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR 'mediterranean fever (brucellosis)' OR<br>'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR 'brucella abortus' OR 'bacterium<br>abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella<br>canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis''brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR<br>'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR 'infection due<br>to brucella' OR 'infection due to brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR<br>'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella melitensis'<br>OR 'brucella canis' OR 'brucella canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella<br>melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella suis'):ti,ab,kw|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>84|
||**Intervenção:**<br>**#3**(Doxycycline OR Minocycline OR Rifampin OR Streptomycin OR Gentamicins OR Trimethoprim OR Sulfamethoxazole OR<br>Quinolones OR Erythromycin OR Azithromycin OR Clarithromycin OR Macrolides OR Levofloxacin OR Ofloxacin OR|101<br> <br>|  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||Ciprofloxacin OR Chloramphenicol OR Tigecycline):ti,ab,kw||
||**#4** (#1 OR #2)AND #3||
|BVS|**População:**<br>**#1**((mh:(brucelose)) OR (brucelose) OR (mh:(brucellosis)) OR (brucellosis) OR (mh:(brucelosis)) OR (brucelosis) OR (febre<br>ondulante) OR (febre de malta) OR (infecçãopor brucella) OR (mh:(brucella)) OR (brucella) OR (mh:(brucella abortus)) OR<br>(brucella abortus) OR (bacterium abortus) OR (mh:(brucella canis )) OR (brucella canis ) OR (mh:(brucella melitensis )) OR (brucella<br>melitensis ) OR (micrococcus melitensis) OR (mh:(brucella ovis)) OR (brucella ovis) OR (mh:(brucella suis)) OR (brucella suis))<br> **Intervenção:**<br>**#2**((therapeutics OR therapeutic OR therapy OR therapies OR treatment OR treatments OR (anti-bacterial agents) OR (agents, anti-<br>bacterial) OR (anti bacterial agents) OR (antibacterial agents) OR (agents, antibacterial) OR (antibacterial agent) OR (agent,<br>antibacterial) OR (anti-bacterial compounds) OR (anti bacterial compounds) OR (compounds, anti-bacterial) OR (anti-bacterial<br>agent) OR (agent, anti-bacterial) OR (anti bacterial agent) OR (anti-bacterial compound) OR (anti bacterial compound) OR<br>(compound, anti-bacterial) OR (bacteriocidal agents) OR (agents, bacteriocidal) OR (bacteriocidal agent) OR (agent, bacteriocidal)<br>OR (bacteriocide) OR (bacteriocides) OR (anti-mycobacterial agents) OR (agents, anti-mycobacterial) OR (anti mycobacterial<br>agents) OR (anti-mycobacterial agent) OR (agent, anti-mycobacterial) OR (anti mycobacterial agent) OR (antimycobacterial agent)<br>OR (agent, antimycobacterial) OR (antimycobacterial agents) OR (agents, antimycobacterial) OR (antibiotics) OR (antibiotic)) )<br> **Desenho do estudo:**<br>**#3**(((mh:("Randomized Controlled Trials as Topic" OR "Controlled Clinical Trials as Topic" OR "Random Allocation" OR "Double-<br>Blind Method" OR "Single-Blind Method" OR "Placebos" OR "Multicenter Studies as Topic" OR "Cross-Over Studies" OR<br>"Pragmatic Clinical Trials as Topic") OR pt:("Randomized Controlled Trial" OR "Controlled Clinical Trial" OR "Multicenter<br>Studies" OR "Pragmatic Clinical Trial") OR ti:(random* OR aleatori* OR placebo*) OR (ti:("clinical trial" OR "ensayoclinico" OR<br>"ensaioclinico") AND tw:(control* OR random* OR aleatori* OR placebo*)) OR (ti:("cross-Over" OR multicenter OR<br>multicentric*) AND ti:(study OR studies OR estud*)) OR ab:(randomi* OR aleatori* OR placebo*) OR (ab:("clinical trial" OR<br>"ensayoclinico" OR "ensaioclinico") AND tw:(control* OR random* OR aleatori* OR placebo*)) OR (ab:("cross-Over" OR<br>multicenter OR multicentric*) AND ab:(study OR studies OR estud*)) OR (tw:(simple* OR singl* OR duplo* OR doble* OR doubl*<br>OR trebl* OR tripl*) AND tw:(cego OR ciego OR blind OR mask OR dumm*))) AND NOT ((mh:"animals" AND NOT<br>mh:"humans") OR mh:"Retrospective Studies")))|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>4|  
102  
|**Base de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||**Bases disponíveis após retirada da MEDLINE no filtro da BVS:**<br>**#4**(db:("LILACS" OR "ARGMSAL" OR "BINACIS"))||
||**#5**#1 AND #2 AND #3 AND #4||
|**Total**||**3.287**|  
103  
Todos os estudos identificados nas bases foram exportados para o programa _Mendeley_<sup>143</sup> , onde as duplicatas foram excluídas. Em seguida, as referências foram enviadas para o aplicativo _Rayyan_<sup>144</sup> para gerenciamento em relação à triagem de títulos e resumos no escopo da revisão. Os artigos selecionados foram lidos na íntegra e analisados de acordo com os critérios de elegibilidade.  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de inclusão:** -->
(a) Tipos de participantes: Pacientes com diagnóstico confirmado de brucelose humana.  
- (b) Tipo de intervenção: Qualquer intervenção terapêutica medicamentosa.  
- (c) Tipos de estudos: Ensaios clínicos randomizados.  
(d) Desfechos: Insucesso do tratamento (desfecho combinado considerando falha terapêutica/resposta ao tratamento + recidiva + perdas de acompanhamento), tempo de defervescência e incidência de eventos adversos.  
- (e) Idioma: Estudos publicados em inglês, espanhol e português.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de exclusão:** -->
(a) Tipos de participantes: Pacientes com manifestações secundárias da brucelose humana.  
(b) Tipos de estudos: Publicações no formato de abstract de congresso cujos resultados foram relatados em artigo científico; Estudos com menos de 10 pacientes em cada braço de tratamento.  
Adicionalmente, foram realizadas buscas na literatura cinzenta em duas plataformas: a base Google Acadêmico, com as principais palavras-chave definidas na estratégia de busca, e a base de dados _OpenGrey_ (atualmente arquivada como base de dados na _DANS EASY_ - _easy.dans.knaw.nl_ ), um sistema de Informação sobre Literatura Cinzenta da Europa. Além disso, foram realizadas buscas na plataforma ClinicalTrials.gov, fornecido pela Biblioteca Nacional de Medicina dos EUA, para identificação de estudos registrados e em andamento. As primeiras 10 páginas do Google Acadêmico foram verificadas; das demais bases, todos os títulos retornados por estas buscas foram lidos para avaliar se estavam dentro do escopo desta revisão. A triagem dos documentos resultantes destas buscas adicionais foi operacionalizada com o apoio de uma planilha Excel®️.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Desfechos de interesse** -->
O desfecho de interesse dessa análise foi a incidência de insucesso das intervenções, sendo comumente relatado pela ocorrência de falha e de recidiva da terapia. Os casos de recidiva são definidos como o reaparecimento de sinais, sintomas da doença ou resultados laboratoriais positivos após a conclusão da terapia e um período assintomático, situação identificada durante o acompanhamento do paciente. A falha terapêutica ou ausência de resposta é definida como a persistência de sinais e/ou sintomas após o final do tratamento. Considerando que o objetivo da terapia é a melhora das manifestações da doença a partir do início do tratamento, os dois desfechos foram considerados agrupáveis gerando um desfecho combinado de insucesso. Nesse estudo,  
104  
consideramos casos de insucesso aqueles sem resposta, aqueles com recidiva, além dos casos de perdas de _follow-up_ e interrupção do tratamento.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Risco de viés** -->
O risco de viés para cada desfecho foi avaliado a partir da ferramenta _Revised Tool for Assessing Risk of Bias in Randomized Trials_ (RoB 2.0)<sup>146</sup> por duas pesquisadoras de forma independente e pareada. Assim, cinco domínios foram avaliados: processo de randomização, desvios das intervenções pretendidas, dados ausentes, medidas do desfecho e seleção dos resultados relatados. Após a avaliação independente dos domínios, uma conclusão geral sobre o risco de viés era gerada para cada estudo.  
O estudo foi considerado com baixo risco de viés quando havia baixo risco para todos os domínios. O estudo foi julgado como “ _some concerns_ ” quando pelo menos um domínio apresentava algumas preocupações e nenhum julgamento de alto risco de viés era identificado. Por fim, o estudo foi julgado como alto risco de viés quando pelo menos um domínio foi considerado com alto risco.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Meta-análise** -->
Inicialmente, meta-análises para comparações binárias foram realizadas para comparações avaliadas em dois ou mais estudos, usando o risco relativo (RR) como medida de efeito para dados categóricos e _mean difference_ (MD) para medida de efeito para dados contínuos. Intervalos de confiança de 95% foram usados para apresentar os resultados em todos os casos. Em seguida, após confirmação dos pressupostos de similaridade, heterogeneidade e consistência, meta-análises em rede (NMA) foram realizadas para permitir a comparação de múltiplos tratamentos via um comparador em comum. Neste caso, o comparador escolhido foi a terapia com doxiciclina associado a estreptomicina para todos os desfechos. Para todas as análises, utilizouse a estatística frequentista, com o modelo de efeitos randômicos, e o R _statistical software_ (https://cran.r-project.org)<sup>207</sup> com ativação dos pacotes meta e netmeta.  
A similaridade foi avaliada qualitativamente, considerando a comparabilidade metodológica entre os estudos. A presença de heterogeneidade foi explorada pela análise de consistência entre os estudos: a pouca sobreposição dos intervalos de confiança para os resultados dos estudos individuais indicou heterogeneidade estatística. A estatística I<sup>2</sup> também foi utilizada para avaliar a heterogeneidade entre os estudos. Por fim, a inconsistência foi avaliada utilizando a função _netsplit._  
As probabilidades de classificação foram estimadas pelo valor P, análogo ao método da superfície sob a curva de classificação cumulativa (SUCRA) utilizado na estatística bayesiana, resultando em um ranking de probabilidade de cada tratamento ser o melhor em relação aos demais. Por fim, foi gerada uma tabela classificativa para cada resultado para obter uma comparação entre todas as intervenções.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Certeza da evidência** -->
A certeza da evidência foi avaliada para cada domínio usando o _Confidence in Network Meta-Analysis Software_ - CINeMA. Cada estimativa de efeito das principais terapias evidenciadas pelas redes, foi avaliada de acordo com os seguintes critérios:  
105  
1) Viés interno do estudo: O risco de viés geral para cada estudo foi atribuído de acordo com os critérios da ferramenta RoB 2.0. Em seguida, cada comparação pareada de terapia foi comparada com base no julgamento do viés médio e na contribuição da estimativa direta de estudos individuais para a matriz de contribuição.  
2) Evidência indireta: Este domínio considerou se os estudos incluídos nesta revisão responderam à questão de pesquisa direcionada em termos de população, tratamento e característica do desfecho. Esta revisão utilizou como desfecho primário, um desfecho combinado, embora nem todos os estudos primários tenham abordado desta maneira. Assim, os estudos que relataram apenas um dos desfechos (recidiva ou falha terapêutica) foram classificados como moderada evidência indireta e aqueles que relataram dados para compor o desfecho de forma completa foram classificados como baixa evidência indireta. Cada comparação pareada de terapia foi classificada na matriz de contribuição com base no julgamento do viés médio.  
3) Imprecisão: Os autores definiram efeitos clinicamente importantes como uma razão de risco menor que 0,8 e maior que seu recíproco 1,25. Viés de publicação: avaliado por meio da busca na literatura cinzenta e na base de dados internacional para registro de ensaios clínicos (Clinicaltrials.gov). Além disso, foram verificadas as fontes de financiamento das pesquisas para certificar de que não houve conflito de interesse da indústria farmacêutica contribuindo para a presença do viés de publicação.  
4) Incoerência: Os autores rebaixaram as comparações, resultando estatisticamente significativas no “teste de divisão de nó local”.  
5) Heterogeneidade: A heterogeneidade foi avaliada pela concordância das conclusões com base em intervalos de confiança e intervalo de predição em relação ao efeito nulo e o efeito clinicamente importante considerado como 0,8.  
Por fim, atribuiu-se a cada comparação um julgamento qualitativo global baseado em quatro níveis de certeza da evidência: alta, moderada, baixa, muito baixa. A qualidade geral da evidência foi rebaixada, começando do mais alto em um ou dois níveis para os domínios considerados classificados como “algumas preocupações” ou “principais preocupações”, respectivamente.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resultados da Busca** -->
A busca identificou 3.287 artigos nas bases de dados. Após triagem e processo de seleção com base nos critérios de elegibilidade, 31 manuscritos foram incluídos na análise qualitativa. Todo o processo de seleção do estudo e os motivos da exclusão estão resumidos em um fluxograma PRISMA ( **Figura M** ).  
106  
<!-- Start of picture text -->
Identificação de estudos por meio de bases de dados e registros<br>Registros identificados por meio de:<br>MEDLINE (n=1472)  Registros duplicados removidos<br>EMBASE (n=1727)  (n=292)<br>COCHRANE (n=84)<br>BVS (n=4)<br>Total = 3287 registros<br>Registros em triagem (n =2995)  Registros excluídos (n =2931)<br>=<br>Publicações pesquisadas para se  Registros não recuperados (n = 7)<br>manterem (n =64)<br>Publicações  avaliadas  para  Publicações excluídas:<br>elegibilidade (n =57)   Desfecho ausente (n=7)<br> Outro idioma (n=10)<br> Participantes  repetidos<br>(n=3)<br> Série pequena (menos<br>de 10 pacientes tratados) (n=2)<br> Desenho de estudo e/ou<br>população inadequada (n=4)<br>Estudos incluídos na revisão<br>(n= 31)<br>Relatos dos estudos incluídos<br>(n= 31)<br>= .<br>Figura M. Fluxograma de seleção dos estudos incluídos na revisão sistemática avaliando<br>opções terapêuticas para o tratamento das manifestações primárias da Brucelose Humana<br>Fonte: Adaptado de Page et al 151 .<br>Identificação<br>Triagem<br>Incluídos<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise e Apresentação dos Resultados** -->
As características dos estudos incluídos, descrevendo características metodológicas, dos participantes e das intervenções, estão sumarizadas **Quadro Q** e **Quadro R** .  
107

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro Q. Principais características metodológicas dos estudos que avaliaram eficácia do tratamento para brucelose humana -->
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|**Feiz, 1973**<sup>208</sup>|Irã (n = 95)|Grupo 1: DX<br>Grupo 2:<br>OXT+STP<br>Grupo 3: OXT|3|Sinais e sintomas<br>clínicos, teste de<br>triagem, teste de<br>soroaglutinação e<br>hemocultura.|Pacientes com brucelose<br>aguda.|NR|Ambos: 20/95|
|**Buzon,**<br>**1982**<sup>209</sup>|NR (n = 84)|Grupo 1: TE + RF<br>Grupo 2:<br>SMX/TMP|6|NR|NR|NR|NR|
|**Ariza, 1985**<sup>210</sup>|NR (n = 58)|Grupo 1: TE+STP<br>Grupo 2:<br>SMX/TMP|Grupo 1: 24<br>Grupo 2: 36|Culturas de sangue em<br>_Castañeda mediun_<br>foram incubadas por<br>pelo menos 6 semanas;<br>Testes de aglutinação de<br>_Wright_, Rosa bengala e<br>antiglobulina de<br>_Coombs_.|Pacientes consecutivos (jan<br>1978 e abr. 1980) com<br>brucelose e culturas de<br>sangue positivas para_B._<br>_melitensis_foram submetidos<br>a rigoroso e prolongado<br>acom panhamento clínico e<br>bacteriológico.|NR|Ambos: 2/58|
|**Rodriguez**<br>**Zapata,**<br>**1987**<sup>211</sup>|Espanha<br>(n = 72)|Grupo 1: DX+RF<br>(34)<br>Grupo 2: DX+STP<br>(36)|12|Presença de quadro<br>clínico compatível com<br>brucelose aguda, teste<br>de Rosa Bengala<br>positivo e/ou<br>hemocultura positiva<br>para_Brucella sp._|Pacientes com brucelose<br>aguda.|Idade < 13 e > 70 anos,<br>gestantes, doenças graves<br>concomitantes, pacientes<br>que necessitam de<br>tratamentos com<br>corticosteroides,<br>barbitúricos ou outros<br>antibióticos,<br>contraindicação para<br>qualquer um dos<br>antibióticos utilizados.|Grupo 1: 2/34<br>Grupo 2: 0/36|
|**Acocella,**<br>**1989**<sup>212</sup>|Multicêntrico –<br>França, Grécia,<br>Espanha (n =<br>146)|Grupo 1(A): RF +<br>DX (63)<br>Grupo 2 (B): DX +<br>STP(53)|12|Quadro clínico<br>compatível com<br>brucelose aguda e<br>padrão Teste de|Combinação de sintomas<br>clínicos e níveis de<br>anticorpos, ou de<br>hemoculturapositiva.|Idade < 10 anos e > 70<br>anos, mulheres grávidas,<br>doenças graves<br>concomitantes,alérgicas a|Ambos: 3/146|  
108  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||Grupo 3 (C): TE +<br>STP (27)||aglutinação em tubo<br>acima de 125 UI, ou<br>fixação de complemento<br>positiva em diluição de<br>1/8 ou mais, ou<br>hemocultura positiva<br>para_Brucella sp_.||qualquer um dos quatro<br>antibióticos a serem usados.||
|**Colmenero,**<br>**1989**<sup>213</sup>|Espanha<br>(n = 111)|Grupo 1: DX+STP<br>(59)<br>Grupo 2: DX+RF<br>(52)|6|(1) isolamento de<br>_Brucella sp._do sangue<br>ou de qualquer outro<br>fluido corporal e/ou (2)<br>quadro clínico<br>compatível com a<br>doença juntamente com<br>(i) soroaglutinação de<br>_Wright_em títulos iguais<br>ou superiores a 1/160;<br>ou<br>(ii) imunofluorescência<br>indireta com títulos<br>iguais ou superiores a<br>1/100 para os<br>conjugados IgS ou IgG<br>e igual ou superior a<br>1/50 para os conjugados<br>IgM ou IgA; ou<br>(iii) soroconversão de<br>quatro ou mais vezes os<br>títulos iniciais em duas<br>amostras de soro<br>separadas colhidas com<br>intervalo mínimo de 3<br>semanas entre elas.|Pacientes diagnosticados<br>como portadores de<br>brucelose em nosso serviço<br>durante 1985-1986.|Pacientes com<br>complicações<br>neuromeníngeas ou aqueles<br>tratados nas últimas 96h<br>com tetraciclina,<br>estreptomicina, Rifampicina<br>ou cotrimoxazol.|Grupo 1: 0/59<br>Grupo 2: 0/52|
|**1991,**<br>**Solera**<sup>214</sup>|Espanha (n =<br>84)|Grupo 1: DX+ RF<br>(42)<br>Grupo 2: DX+STP|12|O diagnóstico foi feito<br>em 48 pacientes por<br>meio do isolamento de|NR|Idade < 7 anos; mulheres<br>grávidas; os pacientes que<br>tinham tomado algum|109<br>Grupo 1: 8/42<br>Grupo 2: 8/42|  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||(42)||hemoculturas de<br>_Brucella sp._e nos 36<br>restantes, devido a<br>quadro clínico<br>compatível com<br>brucelose mais título de<br>aglutinação sérica de<br>_Wright_maior ou igual a<br>1/160. O teste da rosa<br>bengala foi utilizado<br>como método auxiliar<br>(inclusão de pacientes<br>com sinais clínicos<br>positivos pendentes de<br>hemoculturas ou<br>soroaglutinação).||tratamento antimicrobiano<br>eficaz nos 7 dias anteriores;<br>doença concomitante grave,<br>endocardite,<br>neurobrucelose; pacientes<br>com contraindicações para<br>tomar qualquer um dos<br>antibióticos testados.<br>Pacientes admitidos com<br>diagnóstico de espondilite.||
|**Ariza,**<br>**1992**<sup>215</sup>|Espanha<br>(n = 111)|Grupo 1: DX+RF<br>(53)<br>Grupo 2: DX+STP<br>(51)|12|Cultura positiva para<br>_Brucella melitensis_ou<br>achados linfínicos e<br>título de anticorpos para<br>_brucella_STAT<br>(>1/160).|Cultura positiva ou achados<br>clínicos e aglutinação em<br>tubo padrão|Endocardite ou<br>neurobrucelose.|Grupo 1: 9/53<br>Grupo 2: 7/58|
|**Akova,**<br>**1993**<sup>216</sup>|Turquia<br>(n = 61)|Grupo 1: DX+RF<br>(30)<br>Grupo 2: OFX+RF<br>(31)|12|Detecção sorológica de<br>anticorpos contra<br>espécies de_Brucella sp._<br>(STAT>1/160) e<br>achados clínicos<br>compatíveis e<br>isolamento de_Brucella_<br>_sp._|Pacientes com brucelose<br>(ver critério diagnóstico)|Mulheres grávidas,<br>endocardite,<br>neurobrucelose. indivíduos<br>que receberam terapia<br>antimicrobiana prévia ao<br>estudo, pacientes alérgicos<br>a qualquer um dos<br>medicamentos empregados<br>nos esquemas.|0|
|**Montejo,**<br>**1993**<sup>217</sup>|Espanha (n =<br>375)|Grupo 1: DX+RF (4<br>semanas)<br>Grupo 2:<br>SMX/TMP (6<br>meses)|12|Isolamento de germes<br>de espécimes clínicos<br>e/ou STAT de 1/160.|≥ 14 anos de idade, quadro<br>clínico compatível com<br>diagnóstico de brucelose,<br>isolamento de germes de<br>espécimes clínicos e/ou|Gestantes, antecedentes de<br>brucelose no último ano,<br>presença de doença grave<br>associada, relato de alergia<br>a um ou mais|Ambos: 45/375|  
110  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||Grupo 3: DX (6<br>semanas)<br>Grupo 4: STP (2 or<br>3 semanas) + DX (6<br>semanas)<br>Grupo 5: DX+RF (6<br>semanas)<br>Grupo 6: DX+STP<br>(6 semanas)|||STAT de 1/160.|antimicrobianos utilizados<br>neste estudo, diagnóstico de<br>endocardite, espondilite ou<br>acometimento do SNC por<br>_Brucella sp._||
|**Colmenero,**<br>**1994**<sup>218</sup>|Espanha<br>(n = 20)|Grupo1:  DX+STP<br>(9)<br>Grupo 2: DX+RF<br>(10)|6|Isolamento do<br>organismo ou exames<br>clínicos e sorológicos.<br>(soroaglutinação ≥1/160<br>e<br>teste<br>anti-_Brucella_<br>_Coombs_≥1/320)|(1) Hepático normal e<br>funções renais; (2) nenhum<br>deles recebeu qualquer<br>medicamento ou<br>tomou qualquer bebida<br>alcoólica durante o período<br>de tratamento.|NR|0/20|
|**Solera,**<br>**1995**<sup>219</sup>|Espanha<br>(n = 194)|Grupo 1: DX+RF<br>(100)<br>Grupo 2: DX+STP<br>(94)|12|Isolamento de espécies<br>ou título de anticorpos<br>contra_Brucella sp._<br>(STAT > 1/160) com<br>achados clínicos<br>compatíveis|Pacientes com brucelose<br>(critério diagnóstico:<br>sorologia + sintomas<br>compatíveis)|Gestantes, profissionais da<br>enfermagem;<br>hipersensibilidade<br>conhecida ou suspeita ou<br>outra contraindicação para<br>tetraciclinas, rifampicina ou<br>aminoglicosídeos; doença<br>concomitante grave; e<br>terapia antimicrobiana<br>eficaz dentro de 7 dias antes<br>da entrada no estudo.|Grupo 1: 13/100<br>Grupo 2: 14/94|
|**Kalo, 1996**<sup>220</sup>|Albânia (n =<br>24)|Grupo 1: DX+CIP<br>(12)<br>Grupo 2: DX+RF<br>(12)|6|Sorologia positiva e/ou<br>isolamento de_Brucella_<br>_sp._do sangue na<br>presença de achados<br>epidemiológicos e<br>clínicos compatíveis. Os<br>critérios sorológicos|NR|Idade < 15 anos, gestantes,<br>indivíduos que receberam<br>terapia antimicrobiana<br>prévia ao estudo, pacientes<br>alérgicos às drogas<br>empregadas, pacientes com<br>brucelose e complicações|Grupo 1: 0/12<br>Grupo 2: 0/12|
|||||foram: títulos de_Wright_<br>para soroaglutinação||graves dessa doença, como<br>acometimento do sistema||  
111  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||||iguais ou superiores a<br>1/160 e/ou títulos de<br>imunofluorescência<br>indireta maiores que<br>1/100.||nervoso central, endocardite<br>ou espondilite.||
|**Agalar,**<br>**1999**<sup>221</sup>|Turquia<br>(n = 40)|Grupo 1: DX+RF<br>(20)<br>Grupo 2: CIP+RF<br>(20)|12|Infecção por_Brucella_<br>_sp._com base nos<br>achados clínicos e<br>laboratoriais<br>(hemoculturas)|Pacientes com suspeita de<br>infecção com base nos<br>achados clínicos e<br>laboratoriais|Idade < 15 anos, história de<br>convulsões, uso recente de<br>antibióticos, alergia aos<br>antibióticos do estudo e<br>gravidez|Grupo 1: 0/20<br>Grupo 2: 0/20|
|**Saltoglu,**<br>**2002**<sup>222</sup>|Turquia<br>(n = 57)|Grupo 1: DX+RF<br>(30)<br>Grupo 2: OFX+RF<br>(27)|6|O isolamento de<br>_Brucella sp_. no sangue,<br>fluidos corporais e<br>quadro clínico<br>compatível apoiado pela<br>detecção de anticorpos<br>específicos em títulos<br>significativos e<br>demonstração de um<br>aumento de pelo menos<br>4 vezes, ou ambos nos<br>títulos de anticorpos em<br>amostras de soro foram<br>tomados após 2|Os pacientes com brucelose<br>foram acompanhados no<br>Departamento de<br>Microbiologia Clínica e<br>Doenças Infecciosas da<br>Universidade de Çukurova,<br>Hospital Balcalı, Adana,<br>Turquia, entre janeiro de<br>1997 e fevereiro de 2001.|NR|NR|
|||||semanas.||||
|**Solera,**<br>**2004**<sup>223</sup>|Espanha (167)|Grupo 1: DX + GT-<br>30 dias (84)<br>Grupo 2: DX+GT –<br>45 dias (83)|12|Isolamento do<br>organismo ou detecção<br>sorológica de anticorpos<br>contra_Brucella sp._<br>(STAT ≥1:160; ou<br>aumento de ≥4 vezes no<br>título de anticorpos<br>contra_Brucella sp_para<br>>1:80, revelado por<br>aglutinação em tubo<br>padrão,entre amostras|Idade ≥18 anos com<br>diagnóstico de brucelose e<br>pelo menos 2 dos seguintes<br>achados clínicos<br>compatíveis devem estar<br>presentes: febre, artralgias,<br>perda de peso,<br>hepatoesplenomegalia ou<br>sinais de doença focal.|Hipersensibilidade<br>conhecida ou suspeita (ou<br>outra contraindicação) a<br>tetraciclinas ou<br>aminoglicosídeos, doença<br>concomitante grave, peso<br>corporal de ≤50 kg ou<br>recebimento de terapia<br>antimicrobiana eficaz para<br>brucelose≤ 30 dias antes de<br>entrar no estudo.|Grupo 1: 7/80*<br>Grupo 2: 8/81*|  
112  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||||de soro obtidas ≥com<br>intervalo de 2 semanas e<br>estudadas no mesmo<br>laboratório)||||
|**Karabay,**<br>**2004**<sup>224</sup>|Turquia<br>(n = 34)|Grupo 1: DX+RF<br>(18)<br>Grupo 2: OFX+RF<br>(16)|3|Presença de sinais e<br>sintomas compatíveis<br>com brucelose,<br>incluindo aglutinação<br>positiva (título≥1/160)<br>|Pacientes com brucelose<br>(critério diagnóstico:<br>sorologia + sintomas<br>compatíveis)|Idade < 15 anos, história de<br>convulsão, mulheres<br>grávidas.|Grupo 1: 4/18<br>Grupo 2:1/16|
|||||e/ou culturapositiva||||
|**Roushan,**<br>**2004**<sup>225</sup>|Irã (n = 280)|Grupo<br>1:<br>SMX-<br>TMP+DX (140)<br>Grupo 2: SMX/TMP<br>+RF (140)|12|≥1/320 título padrão de<br>aglutinação em tubo<br>(STAT) de anticorpos<br>contra_Brucella sp._com<br>2 mercaptoetanol (2<br>ME) ≥1/160, em<br>associação com achados<br>clínicos compatíveis.<br>Testes confirmatórios<br>também foram<br>realizados usando Elisa<br>com títulos<br>significativos de<br>anticorpos IgM e IgG<br>específicos para<br>|Pacientes consecutivos com<br>brucelose atendidos de abril<br>de 1999 a janeiro de 2002<br>no Departamento de<br>Doenças Infecciosas do<br>Hospital Universitário<br>_Yahyanejad, Babol Medical_<br>_University_.|Idade < 10 anos, gestantes,<br>espondilite, endocardite,<br>meningoencefalite, história<br>prévia de brucelose e<br>terapia antimicrobiana por<br>mais de 7 dias antes da<br>inscrição.|Grupo 1: 10/140<br>Grupo 2: 23/140|
|||||_brucella sp._||||
|**Ersoy,**<br>**2005**<sup>226</sup>|Turquia<br>(n = 128)|Grupo 1: OFX+RF<br>(41)<br>Grupo 2: DX+RF<br>(45)<br>Grupo 3: DX+STP<br>(32)|6|(1) Isolamento de<br>_Brucella sp_. de sangue<br>ou outros fluidos.<br>(2) o achado de ≥1/160<br>ou aumento de quatro<br>vezes ao longo de 2–3<br>semanas no título de<br>anticorpos contra<br>_Brucella sp._por um<br>teste de aglutinação em|Pacientes ambulatoriais e<br>hospitalizados entre maio de<br>1997 e dezembro de 2002,<br>recém-diagnosticados como<br>brucelose não complicada.|Mulheres grávidas,<br>lactantes, hipersensibilidade<br>conhecida ou suspeita ou<br>qualquer contraindicação a<br>rifampicinas, tetraciclinas<br>ou aminoglicosídeos,<br>doença concomitante grave<br>e terapia antimicrobiana<br>eficaz dentro de 10 dias<br>antes do início do estudo.|Ambos: 10/128|  
113  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||||tubo padrão em<br>associação com achados<br>clínicos característicos e<br>história de consumo de<br>leite cru ou não<br>pasteurizado.||||
|**Roushan,**<br>**2006**<sup>227</sup>|Irã (n = 200)|Grupo 1: DX+STP<br>(100)<br>Grupo 2: DX+GT<br>(100)|12|STAT ≥1:320 e 2ME<br>≥1:80 que apresentaram<br>achados clínicos<br>compatíveis com este<br>diagnóstico.|Pacientes com brucelose<br>segundo critérios<br>diagnósticos|Idade <10 anos, espondilite,<br>neurobrucelose, gestantes e<br>recebimento de 11 semanas<br>de antibioticoterapia antes<br>da inclusão.|Grupo 1: 6/100<br>Grupo 2: 3/100|
|**Alavi, 2007**<sup>228</sup>|Irã (n = 105)|Grupo 1: DX+RF<br>(52)<br>Grupo 2: DX+ CFX<br>(53)|6|Achados clínicos<br>compatíveis e achado de<br>títulos significativos<br>(STAT ≥1/80 com<br>2-ME ≥1/40.|Pacientes com brucelose<br>segundo critérios<br>diagnósticos|Idade < 15 anos, gestantes,<br>espondilite, endocardite,<br>meningoencefalite, história<br>prévia de brucelose, terapia<br>antimicrobiana por mais de<br>sete dias antes da inscrição.|Grupo 1: 1/52<br>Grupo 2: 2/53|
|**Ranjbar**<br>**2007**<sup>229</sup>|Irã (n = 228)|Grupo 1: DX+RF<br>(114)<br>Grupo 2: DX+RF +<br>AM (114)|6|(1) Características<br>clínicas da brucelose<br>incluindo febre,<br>sudorese, artralgia,<br>hepatomegalia,<br>esplenomegalia e/ou<br>sinais de doença focal<br>com título padrão de<br>aglutinação em tubo de<br>≥1/160 de anticorpos<br>contra_Brucella_.<br>(2) amostra de tecido ou<br>hemocultura positiva<br>para_Brucella_;<br>(3) aumento de quatro<br>vezes no título de<br>_Wright_em um intervalo<br>de duas semanas com<br>achados clínicos|Pacientes consecutivos com<br>brucelose que frequentaram<br>o Hospital Hamedan Sina<br>entre 1999 e 2001, atendidos<br>ambulatorialmente ou<br>internados.|Idade < 8 anos, mulheres<br>grávidas,<br>endocardite e<br>neurobrucelose.|Grupo 1: 4/114<br>Grupo 2: 4/114|  
114  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||||compatíveis.||||
|**Keramat,**<br>**2009**<sup>230</sup>|Irã (n = 178)|Grupo 1: DX+RF<br>(61)<br>Grupo 2: CIP+RF<br>(62)<br>Grupo 3: CIP+DX<br>(55)|6|Sintomas compatíveis<br>com brucelose aguda<br>com título de anticorpos<br>para_Brucella sp._(STAT<br>≥1/160 e 2-ME ≥1/80,<br>e/ou hemocultura<br>positiva.|Pacientes com brucelose<br>segundo critérios<br>diagnósticos|Idade <17 anos, gestantes,<br>meningite, neurobrucelose,<br>endocardite, insuficiência<br>renal ou hepática|Grupo 1: 0/61<br>Grupo 2: 0/62<br>Grupo 3: 0/55|
|**Sarmadian**<br>**2009**<sup>231</sup>|Irã (n = 80)|Grupo 1: DX+RF<br>(40)<br>Grupo 2: DX+RF+<br>CIP (40)|6|NR|Pacientes com mais de 13<br>anos e frequentaram uma<br>das duas clínicas de doenças<br>infecciosas em Arak, Irã,<br>entre 2006 e 2008.|NR|NR|
|**Roushan,**<br>**2010**<sup>**28**</sup>|Irã (n = 164)|Grupo 1: DX+STP<br>(82)<br>Grupo 2: DX+GT<br>(82)|12|Título padrão de<br>aglutinação em tubo<br>(STA) ≥1:320 e título de<br>2-mercaptoetanol<br>(2ME) ≥1:160,<br>juntamente com achados<br>clínicos compatíveis<br>(febre, sudorese,<br>artralgias, artrite<br>periférica, sacroileíte e<br>epidídimo-orquite).|Casos ambulatoriais e<br>hospitalares com idade > a<br>10 anos.|Espondilite, endocardite,<br>neurobrucelose, gestante e<br>aqueles que receberam<br>antibióticos por > 2 dias.|Grupo 1: 5/82<br>Grupo 2: 2/82|
|**Hashemi,**<br>**2012**<sup>**29**</sup>|Irã (n = 219)|Grupo 1: OFX+RF<br>(73)<br>Grupo 2: DX+RF<br>(73)<br>Grupo 3: DX+STP<br>(73)|6|Apresentação clínica e<br>títulos significativos de<br>anticorpos específicos<br>(STAT ≥1/160,<br>Teste de_Coombs_<br>≥1/160, 2-ME ≥1-80 ou<br>_Brucella_IgG-ELISA<br>>12) e/ou hemocultura<br>positiva.|Pacientes com brucelose<br>segundo critérios<br>diagnósticos|Idade <17 anos,<br>endocardite,<br>neurobrucelose, espondilite,<br>insuficiência renal ou<br>hepática, ou tratamento para<br>brucelose nos últimos 6<br>meses.|Grupo 1: 9/73<br>Grupo 2: 11/73<br>Grupo 3: 8/73|
|**Sofian,**<br>**2014**<sup>**30**</sup>|Irã (n = 158)|Grupo<br>1:<br>DX+RF+STP<br>6<br>semanas(79)|24|Sinais e sintomas<br>compatíveis, teste<br>padrão de aglutinação|Pacientes com mais de 9<br>anos de idade com<br>diagnóstico de brucelose|Mulheres grávidas e<br>pacientes com outras<br>doenças subjacentes.|115<br>Grupo 1: 7/79<br>Grupo 2: 7/79|  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estud**<br>**(número de**<br>**pacientes)**|**o**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|---|
|||Grupo<br>DX+RF+STP<br>semanas (79)|2:<br>8||em tubo (STA) ≥ 1:160<br>e aglutinação de 2-<br>mercaptoetanol (2ME) ≥<br>1:80.|não complicada.|||
|**Hasanain**<br>**2016**<sup>**31**</sup>|Egito (120)|Grupo 1: DX+<br>(60)<br>Grupo<br>DX+RF+LEV (60|RF<br>2:<br>)|6|Contato com animais ou<br>produtos de origem<br>animal frescos e<br>manifestações clínicas<br>sugestivas de duração<br>inferior a um ano e<br>título de anticorpos<br>positivo(>1:160).|Pacientes com brucelose<br>aguda/subaguda que não<br>haviam recebido qualquer<br>terapia antimicrobiana desde<br>o início da doença.|Pacientes gestantes e<br>pediátricos|Grupo 1: 7/60<br>Grupo 2: 6/60|
|**Majzoobi,**<br>**2018**<sup>**32**</sup>|Irã (n = 177)|Grupo<br>DX+STP+HC (89<br>Grupo 2: DX+S<br>(88)|1:<br>)<br>TP|6|Característica clínica<br>compatível com<br>sorologia positiva para<br>_Brucella sp._<br>[_Wright_≥1/160, 2ME ≥<br>1/80] ou culturas de<br>sangue ou medula óssea<br>positivas para_Brucella_<br>_sp._|Pacientes com idade<br>mínima de 18 anos e<br>representaram os critérios de<br>brucelose aguda, incluindo<br>uma característica clínica<br>compatível com sorologia<br>positiva para_Brucella_<br>[_Wright_≥1/160, 2ME ≥<br>1/80] ou culturas de sangue<br>ou medula<br>óssea positivas para<br>_Brucella_ _sp._|Pacientes com deficiência<br>de glicose 6-fosfato<br>desidrogenase, mulheres<br>grávidas, doenças<br>preexistentes significativas<br>(porfiria, psoríase,<br>degeneração macular), ou<br>outras doenças<br>hematológicas,<br>gastrointestinais graves ou<br>doenças neurológicas.|Grupo 1: 0/89<br>Grupo 2: 0/88|
|**Karami,**<br>**2020**<sup>**33**</sup>|Irã (n = 339)|Grupo<br>DX+RF+GT<br>(8semanas)<br>(175)<br>Grupo<br>DX+RF+GT<br>(<br>semanas)<br>(164)|1:<br>2:<br>12|6|Clínica e sorológica<br>sintomas dos pacientes<br>selecionados<br>(_Wright_>1,80;<br>2ME>1,40).|(1) Idade >12 anos.<br>(2) Diagnóstico confirmado.<br>(3) Ausência de<br>complicações.<br>(4) Admissão em Hospital<br>Valiasr.|(1) Reações alérgicas a<br>medicamentos.<br>(2) História de doenças<br>renais.<br>(3) Distúrbios da audição e<br>do equilíbrio.|NR|
|**Majzoobi,**<br>**2022**<sup>**34**</sup>|Irã (n = 92)|Grupo<br>DX+STP+HC<br>(<br>dias) (46)<br>Grupo|1:<br>28<br>2:|6|Apresentações clínicas<br>compatíveis com<br>brucelose com sorologia<br>positiva,incluindo teste|Pacientes adultos internados<br>com brucelose|Idade < 18 anos, gestantes,<br>neurobrucelose,<br>endocardite, espondilite,<br>complicaçãograve da|Grupo 1: 0/46<br>Grupo 2: 0/46|  
116  
|**Autor, Ano**|**País**<br>**(casos)**|**Braços do estudo**<br>**(número de**<br>**pacientes)**|**Seguimento**<br>**(meses)**|**Critérios diagnósticos**|**Critérios de inclusão**|**Critérios de exclusão**|**Seguimento de**<br>**pacientes**<br>**perdidos/tratados**|
|---|---|---|---|---|---|---|---|
|||DX+STP+HC<br>(42||de aglutinação em tubo||brucelose, pacientes que||
|||dias) (46)||padrão (_Wright_) ≥ 1/160||não quiseram continuar o||
|||||e 2-mercaptoetanol||acompanhamento clínico e||
|||||(2ME) ≥ 1/80.||laboratorial.||  
<mark>Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; OXT: oxitetraciclina GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX-TMP: sulfametoxazol-trimetoprim; AM: amicacina; TE: tetraciclina, STAT: teste padrão de aglutinação em tubo; 2 ME: 2-mercaptoetanol, NR: não relatado. *Pacientes sem diagnóstico confirmado não foram contabilizados como perdas.</mark>  
117

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro R. Característica da população incluída nos estudos que avaliaram eficácia do tratamento para brucelose humana e características dos esquemas terapêuticos -->
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|**Feiz,**<br>**1973**<sup>208</sup>|Grupo 1: DX<br>/400mg/dia/14 dias e<br>200mg/dia/7 dias (31)|Grupo 2: OXT 25-30mg/kg +<br>STP 20mg/kg/ diariamente/14<br>dias (28).<br>Grupo 3: OXT 25-<br>30mg/kg/dia/21 dias(16)|Grupo 1: 21 dias<br>Grupo 2: 14 dias<br>Grupo 3: 14 dias|NR|NR|NR|Agudo|NR|NR|
|**Buzon,**<br>**1982**<sup>209</sup>|Grupo 1: TE/500mg + RF<br>1.200 mg/dia durante a<br>primeira semana e 600<br>mg/dia<br>durante<br>as<br>3<br>semanas seguintes/durante<br>um período de 4 semanas<br>(46 ciclos)|Grupo 2:<br>SMX/TMP (480/2400mg<br>(10dias), 320/1600mg (20dias)<br>e               160/400mg (até o<br>final do tratamento) durante 6<br>meses (46 ciclos)|Grupo 1:<br>4 semanas<br>Grupo 2:<br>6 meses|NR|NR|NR|Brucelose<br>ativa<br>(todos os<br>partici-<br>pantes)|NR|NR|
|**Ariza,**<br>**1985**<sup>210</sup>|TE/0.5g/21 dias<br>+<br>STP/1g/dia/14 dias (27)|SMX/TMP /240 mg a<br>1.200mg/duas vezes<br>ao dia/45 dias (28)|Grupo 1: 21 dias<br>Grupo 2: 45 dias|Grupo 1:<br>32.6 (13-72)<br>Grupo 2:<br>32,3(7 – 69)|Grupo 1:<br>20/71<br>Grupo 2:<br>25/3|NR|NR|_B. melitensis_|NR|
|**Rodriguez**<br>**Zapata,**<br>**1987**<sup>211</sup>|DX /200mg/dia/45 dias<br>+<br>RF /900mg/dia/45 dias<br>(34)<br>(ITT36)|DX /200mg/dia/21 dias<br>+<br>STP IM/1g/dia/21 dias (36)<br>(ITT36)|Grupo 1: 45 dias<br>Grupo 2: 21 dias|NR|Grupo 1:<br>28/6<br>Grupo 2:<br>28/8|Febre (70), Dor nas<br>articulações (59),<br>Sudorese (59),<br>Astenia (51),<br>Esplenomegalia (39),<br>Dor de cabeça (34),<br>Hepatomegalia (32),<br>Anorexia (26),<br>Mialgia (20),<br>Linfonodomegalia<br>(19), Sacroiliíte (9),<br>Radiculite (7),<br>Constipação (6),<br>Artrite periférica (5),<br>Orquite(4),|Agudo|NR|118<br>NR|  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|||||||Espondilite (2),<br>Insônia (2), Meningite<br>||||
|||||||(1)||||
|**Acocella,**<br>**1989**<sup>212</sup>|Grupo 1: RF 900 mg/dia<br>+ DX /200mg/dia/ 45 dias<br>(63)|Grupo 2: DX /200 mg/dia/45<br>dias + STP IM/ 1g/dia/21 dias<br>(53)<br>Grupo 3: TE /2g/dia/ (0-5 g 4x<br>ao dia)/21 dias + STP IM/<br>1g/daily/14 dias (27)|Grupo 1: 45 dias<br>Grupo 2: 45 dias<br>Grupo 3:21 dias|Grupo 1: 39<br>Grupo 2:40<br>Grupo 3:45|Grupo 1:<br>36/27<br>Grupo 2:<br>41/12<br>Grupo<br>3:17/20|Esplenomegalia<br>(31%),<br>linfonodomegalia<br>(24%), doença<br>localizada (14%)|Brucelose<br>aguda<br>(todos os<br>participant<br>es)|_B. melitensis_<br>_(68)_|NR|
|**Colmenero,**<br>**1989**<sup>213</sup>|Grupo 1: DX /100 mg<br>/12h/30 dias (59) +<br>STP IM/1g/21 dias (52)|Grupo 2: DX /100mg/12h + RF<br>/15mg/Kg/45 dias (uma dose<br>matinal)|Grupo 1: 21 dias<br>Grupo 2: 45 dias|Grupo 1:<br>33.46±5.26<br>Grupo 2:<br>32.74±2.15|Grupo 1:<br>45/14<br>Grupo 2:<br>32/20|Hepatomegalia (43),<br>Esplenomegalia (27)|Doença<br>Focal (40)|_B. melitensis_<br>_(57)_|NR|
|**1991,**<br>**Solera**<sup>214</sup>|DX/ 200mg/dia/45dias<br>+<br>RF 900 mg/dia/21dias<br>(42)|DX /200mg/dia/45dias<br>+<br>STP IM/ 1g/dia/14 dias (42)|Group 1: 45 dias<br>Group 2: 45 dias|Ambos:<br>32.1±16.6<br>Grupo 1:<br>34±17<br>Grupo 2:<br>29±15|Ambos:<br>65/17<br>Grupo 1:<br>32/10<br>Grupo 2:<br>33/9|Artrite (24), Febre<br>(72), Sudorese (72),<br>Astenia (64), Perda de<br>peso (35), Artralgias<br>(48), Mialgias (35),<br>Dor lombar (51),<br>Cefaleia (44),<br>Sintomas digestivos<br>(28), Adenopatia (12),<br>hepatomegalia (19),<br>esplenomegalia(28)|Doença<br>focal (29)|NR|Grupo 1:<br>28±38<br>Grupo 2:<br>17±15|
|**Ariza,**<br>**1992**<sup>215</sup>|Grupo 1:<br>DX /100mg/duas vezes/45<br>dias<br>+<br>RF/15mg/kg/45 dias (44)<br>(ITT 53)|Grupo 2:<br>DX /100mg/45 dias +<br>STP IM/1g/14 dias (94)|45 dias|39,1±16,5<br>Grupo 1<br>36,8±15,9<br>Grupo 2<br>41,9±116,6|Grupo 1<br>(DS): 31/13<br>Grupo 2<br>(DG): 37/14|NR|Doença<br>focal<br>Grupo 1<br>(DS): 8<br>Grupo 2<br>(GD):8|_B. Melitensis_<br>_(81)_|Grupo 1:<br>37,0 ±31,1<br>Grupo 2:<br>49,4 ± 59,1|  
119  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|**Akova,**<br>**1993**<sup>216</sup>|Grupo 1: DX/200mg/dia/6<br>semanas +<br>RF/600mg/dia/6 semanas<br>(30)|Grupo 2: OFX /400mg/dia/6<br>semanas<br>+ RF/600mg/dia/6 semanas<br>(31)|Grupo 1:45 dias<br>Grupo 2: 30 dias|Grupo 1:<br>34,4 ± 14,3<br>Grupo 2:<br>37,8 ± 15,1|Grupo<br>1:16/14<br>Grupo 2:<br>14/17|NR|NR|_B. melitensis_<br>(49)|Grupo 1:<br>31,4 ± 21,7<br>Grupo 2:<br>37,1 ±24,5|
|**Montejo,**<br>**1993**<sup>217</sup>|Grupo 1:<br>RF/1.200mg/dia/7 dias e<br>depois 600 mg/d por 21<br>dias +<br>DX/200mg/dia/28 dias<br>(65)|Grupo 2: TMP/160mg + SMX<br>/800mg/8h/10 dias; 12h até 4<br>semanas;<br>TMP/80mg + SMX<br>/400mg/12h/até 6 meses.<br>(64)<br>Grupo 3: DX /200mg/dia/6<br>semanas (71)<br>Grupo 4: STP IM/1g/dia/3<br>Semanas + DX /200mg/dia/6<br>semanas (44)<br>Grupo 5:<br>RF /900mg/dia + DX<br>/200mg/dia/<br>6 Semanas (46)<br>Grupo 6: STP IM/1g/dia/2<br>semanas + DX /200mg/dia/6<br>Semanas(40)|Grupo 1: 6 meses<br>Grupo 2: 6 meses<br>Grupo 3: 6<br>semanas<br>Grous 4: 6<br>semanas<br>Grupo 5: 6<br>semanas<br>Grupo 6: 6<br>semanas|Ambos: 46<br>(14 – 82)|Ambos:<br>242/88|Febre (313),<br>Transpiração (297),<br>Calafrios (269),<br>Artralgia (211),<br>Sintoma<br>constitucional (181),<br>Hepatomegalia (93),<br>Esplenomegalia (56),<br>Adenopatia (26),<br>Sacroiliíte (27),<br>Orquite (14), Lesões<br>cutâneas (70)|NR|_B. melitensis_<br>_(66)_<br>_B. abortus_<br>_(3)_|NR|
|**Colmenero,**<br>**1994**<sup>218</sup>|Grupo 1: DX /100mg/ 12<br>h/6 semanas + STP<br>IM/1g/dia/3 semanas (10)|Grupo 2: DX associada a RF:<br>600 mg/dia (peso entre 50 e 60<br>kg)|6 semanas|Ambos: 33,3<br>± 15,6 (17-<br>69)|Grupo 1:<br>7/3<br>Grupo 2:|NR|8/20<br>doença<br>focal|_Brucella_<br>_melitensis_<br>(12 de 18|60,2 ± 55,7<br>Grupo 1:<br>67,5±73,2|
|||900 mg/dia (pesando entre 61 e<br>80 kg)<br>1.200 mg/dia (pesa mais de 80<br>kg) (10)||Grupo 1:<br>35,3±18,8<br>Grupo 2:<br>32,1±12,1|6/4|||pacientes<br>que fizeram<br>cultura)|Grupo 2:<br>53,7±35,8|
|**Solera,**<br>**1995**<sup>219</sup>|Grupo 1: DX /5mg/kg de<br>peso corporal por dia se o<br>peso corporal foi de 40 kg|Grupo 2: DX + STP<br>IM/1g/dia/14 dias (94)|Grupo 1:45dias<br>Grupo 2: 45 dias|Grupo 1:<br>33 (7–77)<br>Grupo 2: 34|Grupo 1:<br>80/20<br>Grupo 2:|NR|Doença<br>focal<br>Grupo|Todos os<br>microrganis<br>mos isolados|Grupo 1: 27<br>± 34<br>Grupo 2: 25|
||ou menos/duas vezes/45|||(12–70)|79/15||1:36|foram_B._<br>_melitensis_|± 29|  
120  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
||dias + RF/900mg/dia/45<br>dias(100)||||||Grupo<br>2:42|||
|**Kalo,**<br>**1996**<sup>220</sup>|Grupo 1:<br>CIP/1000mg/dia/6<br>semanas +<br>DX/200mg/dia/6 semanas<br>(12)|Grupo 2: RF /900/mg/dia/6<br>semanas<br>+ DX/200/ mg/dia/6 semanas<br>(12)|Grupo 1: 6<br>semanas<br>Grupo 2: 6<br>semanas|Ambos:<br>31,76±13,5<br>(18-56)|Ambos:<br>14/10|NR|Agudo|_B. melitensis_<br>(11)|Ambos:<br>21.42±14.52|
|**Agalar,**<br>**1999**<sup>221</sup>|Grupo 1: DX/100mg/duas<br>vezes/<br>RF/600mg/dia/45 dias<br>(20)|Grupo 2: CIP/500mg/duas<br>vezes/45 dias +<br>RF/600mg/dia/30 dias (20)|Grupo 1:45 dias<br>Grupo 2: 30 dias|Grupo 1:<br>37.1±15.8<br>Grupo 2:<br>37,8±13,9|Grupo<br>1:13/7<br>Grupo<br>2:8/12|Febre (97,5%),<br>cefaleia (40%),<br>sudorese (87,5%),<br>artralgia (87,5%),<br>mialgia (77,5%),<br>artrite (15%),<br>sacroileíte (7,5%),<br>epididiorraquite<br>(2,5%)|NR|NR|Grupo 1:<br>36.45±28*<br>Grupo 2:<br>24.35±16.1*|
|**Saltoglu,**<br>**2002**<sup>222</sup>|Grupo 1: RF<br>600mg/dia/45 dias<br>+ DX 100mg/BID (30)|Grupo 2:<br>Ofloxacina/200mg/duas<br>vezes/45 dias<br>Rifampicina/ 600mg/dia (27)|Grupo 1: 2<br>semanas<br>Grupo 2: 2<br>semanas|Ambos: 36,8<br>±11,3 (15-<br>65)|Grupo 1:<br>8/22<br>Grupo 2:<br>6/21|Febre (49), Artralgia<br>(49), Hepatomegalia<br>(18), Esplenomegalia<br>(38), Artrite (12),<br>Sacroiliíte (15)|NR|NR|NR|
|**Solera,**<br>**2004**<sup>223</sup>|Grupo 1: DX /100mg/duas<br>vezes/30 dias + Placebo<br>GT/240mg/dia/7 dias (73)<br>(84 ITT)|Grupo 2: DX /100mg/duas<br>vezes/45 dias + GT<br>/240mg/dia/7 dias (73)<br>(83 ITT)|Grupo 1: 30dias<br>Grupo 2: 45dias|Grupo 1:<br>38,3± 13,7<br>Grupo 2:<br>39,5± 15,4|Grupo 1:<br>62/9<br>Grupo 2:<br>60/13|NR|Doença<br>focal|NR|Grupo 1:<br>30.2 ±28.3<br>Grupo 2:<br>33,5±33,4|
|**Karabay,**<br>**2004**<sup>224</sup>|Grupo 1: DX 100mg/duas<br>vezes/45 dias + RF<br>600mg/ dia/45 dias (14)<br>(18 ITT)|Grupo 2: OFX 400mg/dia/30<br>dias<br>+ RF 600mg/dia/30 dias (15)<br>(18 ITT)|Grupo 1: 45 dias<br>Grupo 2: 30 dias|Grupo 1: 29<br>(24–61)<br>Grupo 2: 35<br>(18–60)|Grupo 1:<br>11/3<br>Grupo 2:<br>13/2|Grupo 1: febre (13),<br>artralgia (10) Dor de<br>cabeça (10)<br>Grupo 2: febre (13),<br>artralgia (10) Dor de<br>cabeça(10)|NR|NR|NR|  
121  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|**Roushan,**<br>**2004**<sup>225</sup>|Grupo 1: CTX 8mg/kg/dia<br>do componente<br>trimetoprima dividido em<br>3 doses + DX 100mg/<br>duas vezes ao dia (140)|Grupo 2: CTX 8mg/kg/dia<br>do componente trimetoprima<br>dividido em 3 doses + RF<br>15mg/kg/dia<br>(140)|Grupo 1: 2 meses<br>Grupo 2: 2 meses|Grupo 1:<br>35.56±16.2<br>(12-81)<br>Grupo 2:<br>31.39±17.88<br>(10-79)|Grupo 1:<br>74/66<br>Grupo 2:<br>76/64|Artralgia (185),<br>Mialgia (94),<br>Esplenomegalia (19)|Aguda<br>(208)<br>Artrite<br>subaguda<br>e crônica<br>(72)|NR|NR|
|**Ersoy,**<br>**2005**<sup>226</sup>|Grupo 1: OFX<br>400mg/dia/6 semanas +<br>RF 600mg/dia/6 semanas<br>(41)|Grupo 2: DX 200mg/dia/6<br>semanas<br>+ RF 600mg/dia/6 semanas<br>(45)<br>Grupo 3: DX 100mg/dia/6<br>semanas<br>+ STP IM 1g/3 semanas (32)|Grupo 1: 6<br>semanas<br>Grupo 2: 6<br>semanas<br>Grupo 3: 6<br>semanas|Grupo 1:<br>(16-70)<br>Grupo 2: 18-<br>75<br>Grupo 3: 17-<br>62|Grupo 1:<br>23/18<br>Grupo 2:<br>24/21<br>Grupo 3:<br>15/17|NR|NR|NR|Grupo 1:<br>23,7± 2,2<br>Grupo 2:<br>25.3±1.7<br>Grupo 3:<br>28.4±2.5|
|**Roushan,**<br>**2006**<sup>227</sup>|Grupo 1: STP IM/1g/14<br>dias + DX 100mg/duas<br>vezes/45 dias (94) (100<br>ITT)|Grupo 2: GT 5 mg/kg/dia/7<br>dias +<br>DX 100mg/duas vezes/45 dias<br>(97) (100 ITT)|45 dias|Grupo 1:<br>36.2±14.14<br>Grupo 2:<br>33.74±16.6|Grupo 1:<br>52/42<br>Grupo 2:<br>57/40|Grupo 1: Febre 69<br>(73,4%); sudorese 80<br>(85,1%); Artralgia 67<br>(71,3%)<br>Grupo 2: Febre 75<br>(77,3%); sudorese 91<br>(93,8%); Artralgia 71<br>(73,2%)|Grupo 1:<br>81 agudos<br>(86,2%);<br>27<br>doenças<br>focais<br>(28,7%)<br>Grupo 2:<br>73 agudos<br>(75,3%);<br>24<br>doenças<br>focais<br>(24,7%)|NR|NR|
|**Alavi,**<br>**2007**<sup>228</sup>|Grupo 1: DX/100mg/ duas<br>vezes<br>RF/300mg/8 hora (51)<br>(52 ITT)|Grupo 2: DX /100mg/ duas<br>vezes +<br>CTX /2 comprimidos para<br>adultos ou 960mg/duas vezes<br>(51)|8 semanas|Grupo 1:<br>31.26<br>±11.23<br>Grupo 2:<br>29.89±9.81|NR|Grupo 1: Febre 29<br>(56,86); Sudorese<br>40(78,43); Artralgia<br>40(78,43); Dor<br>lombar 48(94,11)|NR|NR|NR|  
122  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|||(53 ITT)||||Grupo 2: Febre 28<br>(54,90); Sudorese<br>41(80,39); Artralgia<br>41(80,39); Dor<br>lombar 49(96,07)||||
|**Ranjbar**<br>**2007**<sup>229</sup>|Grupo 1: DX 100mg/duas<br>vezes ao dia +RF<br>10mg/kg/dia/8 semanas<br>(114)|Grupo 2:<br>DX 100mg/duas vezes ao dia +<br>RF<br>10mg/kg/dia/8 semanas + AM<br>IM/7.5mg/kg/duas vezes ao<br>dia/7 dias (114)|Grupo 1: 21 dias<br>Grupo 2: 45 dias|Grupo 1:<br>37±18.4<br>Grupo 2:<br>35.7±17|Ambos:<br>107/113<br>Grupo 1:<br>53/57<br>Grupo 2:<br>54/56|Febre (203)|NR|_B. melitensis_<br>(16)<br>Hemocultura<br>negativa (69)|NR|
|**Keramat,**<br>**2009**<sup>230</sup>|Grupo 1: DX 200 mg/dia<br>+ RF 15 mg/kg/dia (600–<br>900 mg) por via oral (61)|Grupo 2: CIP 15 mg/kg/dia<br>(500–750 mg duas vezes ao<br>dia) + RF 15 mg/kg/dia (62)<br>Grupo 3: CPI 15 mg/kg/dia<br>(500–750 mg duas vezes ao<br>dia) + DX 200 mg/dia (55)|8 semanas**|Grupo 1:<br>39,67<br>Grupo 2:<br>43.66±NR<br>Grupo 3:<br>38.41|Grupo 1:<br>43/18<br>Grupo 2:<br>34/28<br>Grupo 3:<br>38.41|Mal-estar (157),<br>artralgia (142), dor<br>generalizada (140),<br>sudorese (140) e<br>cefaleia (128).|Aguda<br>(duração<br><3 meses)|NR|NR|
|**Sarmadian**<br>**2009**<sup>231</sup>|Grupo 1: DX/100<br>mg/BID/8 semanas +<br>RF/10 mg/kg/dia/8<br>semanas<br>(40)|Grupo 2: DX / 100mg/BID/8<br>semanas + CIP /500mg/BID/8<br>semanas<br>(40)|Grupo 1: 8<br>semanas<br>Grupo 2: 8<br>semanas|NR|NR|NR|NR|NR|NR|
|**Roushan,**<br>**2010**<sup>232</sup>|Grupo 1: GT /5<br>mg/kg/dia/5 dias<br>+ DX/100mg/duas vezes<br>ao dia/8 semanas (82)|Grupo 2: GT IM/1g/2<br>semanas+ DX /1g/45 dias|Grupo 1: 8<br>semanas<br>Grupo 2: 45 dias|Grupo 1:<br>35.9±14.8<br>Grupo 2:<br>36,5±14,5|Ambos:<br>Grupo 1:<br>56/82<br>Grupo 2:<br>52/82|Febre, Sudorese,<br>Artralgia, Artrite<br>periférica, Sacroiliíte,<br>Epidídimo-orquite,<br>Espondilite|Agudo|NR|NR|
|**Hashemi,**<br>**2012**<sup>233</sup>|Grupo 1: OFX 800 mg por<br>dia + RF 15 mg/kg<br>diariamente durante   6|Grupo 2: DX 200 mg/ dia +<br>RF 15mg/kg/ diariamente/6<br>semanas (62) (ITT=73)|6 semanas|Grupo 1:<br>40,5± 14,2|Grupo:<br>1:36/28<br>Grupo:|Artralgia (74,3%),<br>cansaço (73,8%),<br>lombalgia (68,1%),|NR|_Brucella_<br>_melitensis_<br>(12)|Grupo 1:<br>60.1 ± 103<br>Grupo 2:|
||semanas (64) (ITT=73)|Grupo 3: DX 200mg por dia/6<br>semanas||Grupo 2:<br>38,6 ± 17,3|2:34/28|dor no corpo (57,6%),<br>sudorese(49,2%),|||68,6 ± 150,9|  
123  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|||+ STP 1000mg/ Diariamente/3<br>semanas (65) (ITT=73)||Grupo 3:<br>39,9± 15,4|Grupo:<br>3:26/29|cefaleia (46,6%) e<br>anorexia (45,0%)|||Grupo 3:<br>46,6 ± 34,3|
|**Sofian,**<br>**2014**<sup>234</sup>|Grupo 1: DX<br>100 mg/duas vezes por<br>dia/6 semanas + RF 600<br>mg/dia/ 6 semanas + STP<br>IM 750–1000 mg/ dia/7<br>dias (79)|Grupo 2: DX 100 mg/duas<br>vezes por dia/8 semanas + RF<br>600 mg/dia/ 8 semanas + STP<br>IM 750–1000 mg/ dia/7 dias<br>(79)|Grupo 1: 6<br>semanas<br>Grupo 2: 8<br>semanas|Ambos:<br>35.9±15<br>Grupo 1:<br>37.7±14.6<br>Grupo 2:<br>34.2±15.18|Ambos:<br>93/53<br>Grupo 1:<br>43/29<br>Grupo 2:<br>48/24|Febre (68,6%),<br>artralgia (62,6%),<br>anorexia (53,5%),<br>sudorese noturna<br>(52,9%), mal-estar<br>(49,3%), mialgia<br>(42%), cefaleia<br>(25%), tosse (10,4%),<br>diarreia(2,8%).|Brucelose<br>não<br>complicad<br>a|NR|9,5 dias (3 –<br>40)|
|**Hasanain**<br>**2016**<sup>235</sup>|Grupo 1: DX 200mg/dia +<br>RF 900 mg/dia/6 semanas<br>(53) (ITT=60)|Grupo 2: DX 200mg/dia + RF<br>900mg/dia + LEV 500mg/dia/6<br>semanas (54)<br>(ITT=60)|6 semanas|Grupo 1:<br>32,7<br>±<br>15<br>Grupo 2:<br>36.2<br>±<br>17.4|Grupo 1:<br>32/21<br>Grupo 2:<br>30/24|Febre 103 (96,3%),<br>Fadiga 89 (83,2%),<br>Mialgia 75 (7,1%),<br>Calafrios 71 (66,4%),<br>Sudorese 66 (61,7%),<br>Artralgia 52 (48,6%),<br>Bradicardia relativa<br>34 (31,8%),<br>Esplenomegalia 23<br>(21,5%),<br>Hepatomegalia 18<br>(16,8%),<br>Linfadenopatia 15<br>(14%)|Brucelose<br>aguda/sub<br>aguda|NR|NR|
|**Majzoobi,**<br>**2018**<sup>236</sup>|Grupo 1: HC 6,5 mg/kg +<br>DX 100 mg/duas vezes ao<br>dia/6 semanas + STP 1000<br>mg/dia (<60 anos) ou 750<br>mg/dia (idade mínima de<br>60 anos)3 semanas(89)|Grupo 2: DX 100 mg/duas<br>vezes ao dia/6 semanas + STP<br>1000 mg/dia (<60 anos) ou 750<br>mg/dia (idade mínima de 60<br>anos)/3 semanas<br>(88)|6 semanas|Grupo 1:<br>38.5±17.2<br>Grupo 2:<br>42,5±6,4|Grupo 1:<br>59/30<br>Grupo 2:<br>58/30|Dor generalizada,<br>Artralgia, Dor de<br>cabeça, Febre, Artrite,<br>Espondilite, Orquite|Agudo|NR|NR|  
124  
|**Autor, Ano**|**Intervenção**<br>**(mg/frequência/duração)**<br>**(n)**|**Comparação**<br>**(mg/frequência/duração) (n)**|**Duração do**<br>**tratamento**|**Idade**<br>**(média±DP,**<br>**anos) /**<br>**(intervalo)**|**Gênero**<br>**masculino/**<br>**feminino**|**Manifestações**<br>**clínicas**|**Forma**<br>**clínica**|**Espécies de**<br>**_Brucella_**<br>**Caracteriza**<br>**ção (n)**|**Duração dos**<br>**sintomas em**<br>**dias Média**<br>**± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|---|---|---|
|**Karami,**<br>**2020**<sup>237</sup>|Grupo 1: comprimidos de<br>DX (100 mg duas vezes<br>por dia durante 8<br>semanas) + RF (600<br>mg/dia por 8 semanas +<br>GT (5 mg/kg/dia por 7<br>dias) (175)|Grupo 2: comprimidos de DX<br>(100 mg duas vezes por dia<br>durante 12 semanas) +<br>RF (600 mg/d por<br>12 semanas + GT<br>(5 mg/kg/d por 7 dias) (164)|Grupo 1: Primeiro<br>grupo: 8 semanas<br>Grupo 2: Segundo<br>grupo:12 semanas|45.95 ±<br>18.65|193/146|Febre (81,1%),<br>sudorese (65,8%),<br>mialgia (69%),<br>artralgia (56,9%),<br>cefaleia (14,5%),<br>letargia (46%),<br>inapetência (44,5%),<br>tosse (8%), diarreia<br>(4,1%) e disúria<br>(13/6%)|NR|NR|Média de<br>30(21-56)<br>dias|
|**Majzoobi,**<br>**2022**<sup>238</sup>|DX 200 mg/dia/4 semanas<br>+ HC<br>400 mg/dia/4 semanas +<br>STP 1 g/dia/3 semanas<br>(46)|DX 200 mg/dia/6 semanas +<br>HC 400 mg/dia/6 semanas +<br>STP 1 g/dia/3 semanas.<br>(46)|Grupo 1: 28 dias<br>Grupo 2: 42 dias|Grupo 1:<br>37.4±5<br>Grupo 2:<br>40.11±5|Grupo 1:<br>35/11<br>Grupo 2:<br>29/17|Mialgia, cefaleia,<br>artralgia, febre||NR|NR|  
<mark>Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; OXT: oxitetraciclina GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX/TMP: sulfametoxazol-trimetoprima; AM: amicacina; TE: tetraciclina, STAT: teste padrão de aglutinação em tubo; 2 ME: 2-mercaptoetanol, NR: não relatado, y: Anos.</mark> ***** Duração da febre (em dias) antes da admissão ao hospital. ** Aqueles com espondilite ou que não responderam a uma terapia de oito semanas receberam tratamento adicional de quatro semanas.  
125

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Meta-análises** -->
Para a avaliação da eficácia e segurança das opções terapêuticas para brucelose humana, três desfechos foram incluídos nas NMA: insucesso do tratamento que compreende um desfecho combinado dos casos de recidiva e falha da doença, tempo de defervescência e eventos adversos. A **Figura N** ilustra as redes de evidências contendo as terapias avaliadas para cada um destes desfechos. Todas as redes atenderam aos princípios da homogeneidade, similaridade e consistência.  
Diante da inviabilidade de identificar uma única rede de evidência para cada desfecho, alguns estudos não puderam fazer parte das análises por testarem combinações de terapias que não foram comparadas com as demais incluídas nas redes. Enquanto Sofian<sup>239</sup> comparou doxiciclina associado a rifampicina (6 semanas) e a estreptomicina versus doxiciclina associado a rifampicina (8 semanas) e a estreptomicina, Karami<sup>240</sup> comparou doxiciclina associado a rifampicina e a gentamicina usados em 8 e 12 semanas de tratamento, não compondo nenhuma das análises. Roushan<sup>241</sup> por ser o único estudo que comparou as terapias sulfametoxazol + trimetoprima associado a doxiciclina e sulfametoxazol + trimetoprima associado a rifampicina e relatou resultados para eventos adversos, precisou ser excluído da rede desta evidência, apesar de ter contribuído com o desfecho combinado de insucesso do tratamento.  
A intervenção utilizada como comparador nas análises foi doxiciclina associado a estreptomicina. Esta é a intervenção mais utilizada do grupo doxiciclina-aminoglicosídeo, representando a atual indicação de tratamento para a doença.  
<!-- Start of picture text -->
mos<br><!-- End of picture text -->  
Figura N. Redes de Evidência para os desfechos (A) Insucesso do tratamento; (B) Tempo  
para Defervescência; (C) Eventos Adversos  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; OXT: oxitetraciclina GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX-TMP: sulfametoxazoltrimetoprima; AM: amicacina; TE: tetraciclina.  
126

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Insucesso do Tratamento** -->
Vinte e oito estudos, com 3.217 participantes e 20 categorias de intervenções apresentaram o desfecho recidiva, enquanto 18 estudos, com 2.256 participantes e 12 categorias de intervenções contribuíram com informações relacionadas à falha do tratamento. Assim, estes estudos contribuíram com a NMA para o desfecho combinado de insucesso do tratamento.  
Apenas a terapia tripla com doxiciclina associado a estreptomicina e a hidroxicloroquina usada por 42 dias (RR: 0,08; IC95% 0,01 a 0,76; certeza da evidência muito baixa certeza) apresentou efeito protetor contra insucesso do tratamento comparada ao esquema doxiciclina associada a estreptomicina. Não houve diferença estatisticamente significativa entre o esquema doxiciclina associado a estreptomicina quando comparado a doxiciclina associado a gentamicina (RR: 0,56; IC95% 0,22 a 1,45; certeza da evidência muito baixa certeza). O esquema, doxiciclina + rifampicina apresentou maior risco de insucesso quando comparado a doxiciclina associado a estreptomicina (RR: 1,96; IC95% 1,27 a 3,01; certeza da evidência muito baixa certeza). Todas as comparações realizadas contra esta última terapia podem ser visualizadas na **Figura O** Figura.  
<!-- Start of picture text -->
Comparacao: outro vs ‘DX + STP"<br>Tratamento (modelo de efeitos randémicos) RR = 95%-1C<br>CIP+RF 2.22 (0.66; 7.47)<br>DxDX+cIP —— 2464.38 (1.39:(0.82,1375}7.36)<br>DX+GT 0.56 (0.22, 1.45)<br>DX+GT(30 days) 0.74 (0.18; 3.07)<br>DX+RF = 1.96 [1.27; 3.01]<br>DX+RF+AM 151 (0.42; 5.41)<br>DX+RF+LEV 1.28 (0.41; 3.95)<br>DX+SMX-TMP 0.96 (0.25; 3.72)<br>DX+STP. 1.00<br>DX+STP+HC (28days) 0.11 (0.01; 1.43]<br>DX+STP+HC (42days) ——-——— 0.08 (0.01, 0.76)<br>OFX+RF 1.64 (0.82, 3.30}<br>OxT 265 (0.49, 14.41]<br>OXT+STP 1.21 (0.20; 7.17}<br>SMX-TMP. ae 359 [1.30, 997]<br>SMX-TMP+RF 1.61 (0.29; 8.86}<br>TE+STP ——— 4.03 (1.42; 11.45]<br>001 01 1 10 100 *<br>Risco relativo<br><!-- End of picture text -->  
Figura O. Gráfico de floresta da meta-análise em rede para o desfecho falha do tratamento Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; OXT: oxitetraciclina GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX-TMP: sulfametoxazoltrimetoprima; AM: amicacina; TE: tetraciclina.  
FiguraA **Figura P** ilustra a classificação das intervenções para o tratamento da brucelose humana e sua probabilidade de serem as melhores ou piores em relação ao risco de insucesso. As terapias com doxiciclina associado a estreptomicina e a hidroxicloroquina usadas por 42 e 28 dias tiveram as maiores probabilidades de evitar insucesso considerando a comparação direta e indireta juntas (P- _score_ = 0,967 e 0,921, respectivamente). A terceira melhor terapia no ranking foi doxiciclina associado a gentamicina (P- _score_ = 0,805) enquanto as piores terapias foram  
127  
SMX/TMP em monoterapia (P- _score_ = 0,144) e doxiciclina associado a ciprofloxacino (P _-score_ = 0,126).  
Não foi detectada presença de inconsistência na NMA para o desfecho insucesso do tratamento (Q = 3,70; P = 0,977) ou presença de heterogeneidade estatística (I<sup>2</sup> = 0%; tau = 0).  
128  
<!-- Start of picture text -->
1 2 20 4 5 6 7 89 10 11 12 «13 «140 «6150 160 7 a8,<br><!-- End of picture text -->  
|**Númeraçã**|**o**<br>**Esquema**<br>**terapêutico**|**Probabilidade**|
|---|---|---|
|1|DX+STP+HC<br>(42dias)|0,967|
|2|DX+STP+HC<br>(28 dias)|0,921|
|3|DX +GT|0,805|
|4|DX +GT (30<br>dias)|0,702|
|5|DX+STP|0,665|
|6|DX+SMX-TMP|0,650|
|7|OXT+STP|0,563|
|8|DX+RF+LEV|0,553|
|9|DX+RF+ AM|0,489|
|10|OFX+RF|0,459|
|11|SMX-TMP +RF|0,452|
|12|DX+RF|0,379|
|13|CIP+RF|0,349|
|14|DX|0,302|
|15|OXT|0,289|
|16|SMX-TMP|0,175|
|17|TE+STP|0,144|
|18|DX+CIP|0,126|  
<!-- Start of picture text -->
wie<br>075<br>050<br>025<br>0.00<br><!-- End of picture text -->  
Figura P. Classificação das intervenções e probabilidades de risco de insucesso no tratamento da brucelose humana  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; OXT: oxitetraciclina GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX-TMP: sulfametoxazoltrimetoprima; AM: amicacina; TE: tetraciclina.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Tempo de defervescência** -->
Apenas 5 estudos, com 379 participantes e 4 categorias de intervenções, contribuíram para a NMA que avaliou o tempo para defervescência. Não houve diferença neste tempo entre as terapias com doxiciclina associado a estreptomicina versus doxiciclina associado a rifampicina, e  
129  
ciprofloxacino associado a rifampicina (DM: -26,62; IC95% -56,57 a 3,33), embora o tratamento com ofloxacina associado a rifampicina (DM: -32,94; IC95% -60.55 a -5,34) tenha reduzido significativamente o tempo de febre ( **Figura Q** ).  
<!-- Start of picture text -->
‘Comparacao: outro vs "DX + STP"<br>Tratamento (modelo de efeitos randémicos) MD 95%1C<br>CIP+RF -26.62 [-56.57; 3.33]<br>OX+RF -0.94 [-14.23; 12.34]<br>DX+STP 0.00<br>OFX+RF- ———— -32.94 [-60.55; -5.34]<br>60 -40 -20 0 20 40 60<br>Diferenca Média<br><!-- End of picture text -->  
Figura Q. Gráfico de floresta da meta-análise em rede para o desfecho defervescência no tratamento da brucelose humana  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; GT: sulfato de gentamicina; CIP: ciprofloxacino.  
Na comparação envolvendo todos os tratamentos, doxiciclina associado a rifampicina e doxiciclina associado a estreptomicina apresentou tempo de defervescência significativamente maior comparado a ofloxacino associado a rifampicina (MD: 32,00; IC95% 11,60 a 52,40 horas; MD: 33,51; IC95% 10,44 a 56,58 horas, respectivamente).  
No ranqueamento das probabilidades de melhor desempenho, doxiciclina associado a estreptomicina apresentou-se na pior posição (P- _score_ = 0,138) ( **Figura R** ). A inconsistência não pôde ser detectada, uma vez que não houve _loops_ fechados para este desfecho.  
<!-- Start of picture text -->
OFK+RE CIPsRE DX+RF Dx+STP<br><!-- End of picture text -->  
<!-- Start of picture text -->
ar)<br>075<br>050<br>0 2500<br><!-- End of picture text -->  
<!-- Start of picture text -->
Esquema<br>Probabilidade<br>terapêutico<br>OFX+RF 0,884<br>CIP+RF  0,770<br>DX+RF  0,208<br>DX+STP  0,138<br><!-- End of picture text -->  
Figura R. Classificação das intervenções e probabilidades de risco para o desfecho de defervescência no tratamento da brucelose humana.  
Legenda: CIP: ciprofloxacino; DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacina; HC: hidroxicloroquina.  
130

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Eventos adversos** -->
Ao todo, 12 estudos envolvendo 1.819 participantes e 11 tipos de intervenções foram avaliadas em NMA para o desfecho taxa de eventos adversos.  
Não houve diferença significativa no risco de eventos adversos entre as diferentes terapias em comparação com a combinação doxiciclina associado a estreptomicina ( **Figura S** ). Quando todos os tratamentos foram comparados com os demais, a estratégia doxiciclina associado a gentamicina não apresentou diferença na incidência de eventos adversos (muito baixa certeza da evidência). Todas as comparações encontram-se no **Quadro R** .  
<!-- Start of picture text -->
Comparacao: outro vs ‘DX + STP"<br>Tratamento (modelo de efeitos randémicos) RR = 95%-IC<br>CIP+RE 1.71 (0.27; 10.96}<br>DX+cIP 4.49 (0.86: 23.34}<br>DX+GT 128 (062, 262}<br>DX+GT(30 days) 132 (051; 3.43}<br>DX+RF — 1.16 (078. 1.71]<br>DX+RF+AM 1.74 (0.44; 6.91]<br>DX+RF+LEV 2.08 (0.69, 6.30)<br>DX+STP 1,00<br>DX+STP+HC (42days) 064 (0.27, 149)<br>OFX+RF a 0.85 (0.47; 1.55}<br>TE+STP ——— 0.37 (0.05; 2.85}<br>01 0512 10<br>Risco Relativo<br><!-- End of picture text -->  
Figura S. Gráfico de floresta da meta-análise em rede para o desfecho reações adversas no tratamento da brucelose humana  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacino; GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; TE: tetraciclina.  
A **Figura T** Figura ilustra a classificação das intervenções para o tratamento da brucelose humana e sua probabilidade de causar eventos adversos. Os esquemas de tratamento com tetraciclina associado a estreptomicina e doxiciclina associado a estreptomicina e a hidroxicloroquina usada por 42 dias relacionaram à menor probabilidade de causar eventos adversos ( _P-score_ = 0.855 e 0.816, respectivamente). As terapias mais associadas com eventos adversos foram doxiciclina associado a rifampicina e ao levofloxacino ( _P-score_ = 0.255) e doxiciclina associado a ciprofloxacino ( _P-score_ = 0.084).  
Não foi detectada presença de inconsistência na NMA para o desfecho eventos adversos (Q = 6.23; P = 0.182) ou presença de heterogeneidade estatística (I<sup>2</sup> = 0%; tau = 0).  
131  
<!-- Start of picture text -->
certo<br>ors<br>050<br>oas<br>00<br>&x ee 6& fa FM& & Mmo SF& ra— séSs<br>s ra o ca<br>¥<br><!-- End of picture text -->  
Figura T. Classificação das intervenções e probabilidades de reações adversas no tratamento da brucelose humana  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacino; GT: sulfato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; TE: tetraciclina.  
As **Tabela E** e **Tabela F** são as league-table para os desfechos.  
132

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Tabela E. League-table para o desfecho insucesso do tratamento -->
|**CIP+RF**||0,38<br>(0,16; 0,92)|||1,48<br>(0,55; 3,97)||||||||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|1,14<br>(0,36; 3,63)|<br>**DX**||||<br>0,74<br>(0,37; 1,49)|<br>|||2,96<br>(0,97; 9,03)|||(|0,93<br>0,37; 2,31)|2,03<br>(0,70; 5,87)<br>|1,50<br>(0,58; 3,90)||
|0,44<br>(0,19; 1,00)|<br>0,38<br>(0,13; 1,13)|**DX+CIP**|||2,46<br>(1,00; 6,06)||||||||||||
|3,87<br>(1,18; 12,70)|<br>3,39 (1,27;<br>9,04)|8,82<br>(2,90; 26,81)|**DX+GT**|0,76<br>(0,44; 1,33)|||||0,58<br>(0,29; 1,14)||||||||
|2,95<br>(0,80; 10,95)|<br>2,59<br>(0,84; 7,97)|6,73<br>(1,94; 23,30)|0,76<br>(0,44; 1,33)|**DX+GT (30**<br>**dias)**|||||||||||||
|1,15|1,01|2,62|**0,30**|0,39||1,30|1,53|2,04|1,91|||1,37|||2,02|0,12|
|(0,45; 2,94)|<br>(0,51; 1,97)|(1,13; 6,07)|**(0,14; 0,62)**|(0,16; 0,97)|**DX+RF**|(0,59; 2,84)|(0,93; 2,51)|(0,83; 5,02)|<br>(1,47; 2,47)|||(0,91; 2,05)|||(0,86; 4,74)|(0,04; 0,39)|
|1,49<br>(0,44; 5,07)|<br>1,31<br>(0,47; 3,67)|3,40<br>(1,08; 10,74)|0,39<br>(0,13; 1,12)|0,51<br>(0,15; 1,69)|1,30<br>(0,59; 2,84)|<br>**DX+RF+AM**|||||||||||
|1,76<br>(0,61; 5,08)|<br>1,54<br>(0,67; 3,55)|4,01<br>(1,51; 10,63)|0,45<br>(0,19; 1,10)|0,60<br>(0,21; 1,68)|1,53<br>(0,93; 2,51)|<br>1,18<br>(0,47; 2,97)|<sup>**DX+RF+LEV**</sup>||||||||||
|2,34|2,05|5,34|0,61|0,79|2,04|1,57 (0,48;|1,33|**DX+SMX-**||||||||0,59|
|(0,64; 8,62)|<br>(0,67; 6,32)|(1,56; 18,32)|(0,19; 1,93)|(0,22; 2,87)|(0,83; 5,02)|<br>5,18)|(0,48; 3,73)|**TMP**||||||||(0,37; 0,95)|
|2,23|1,95|5,08|0,58 (0,29;|0,76|1,94|1,49 (0,66;|1,27 (0,73;|0,95|||12,14 (1,61;|0,79 (0,46;|||0,51 (0,15;|0,09|
|(0,84; 5,91)|<br>(0,96; 3,96)|(2,11; 12,24)|1,14)|(0,31; 1,82)|(1,50; 2,51)|<br>3,40)|2,22)|(0,37; 2,43)|<br>**DX+STP**||91,36)|1,37)|||1,73)|(0,02; 0,39)|
|19,69 (1,81;|<br>17,24 (1,75;|<br>44,86 (4,29;|5,09 (0,52;|6,67|17,13 (1,91;|<br>13,18 (1,29;|11,20 (1,18;|8,40 (0,79;|8,83|**DX+STP+HC**|<br>1,38 (0,61;||||||
|213,67)|169,89)|469,19)|49,77)|(0,64; 69,66)|<br>153,31)|135,04)|105,95)|89,90)|(1,00; 77,81)|**(28dias)**|3,10)||||||
|27,07 (2,88;|<br>23,70 (2,79;|<br>61,69 (6,82;|7,00|9,17|23,55 (3,08;|<br>18,12 (2,05;|15,40 (1,90;|11,55 (1,25;|<br>12,14|1,37|**DX+STP+HC**||||||
|254,60)|201,14)|557,71)|(0,83; 58,89)|(1,01; 82,80)|<br>180,22)|160,31)|125,06)|107,02)|(1,61; 91,36)|(0,61; 3,10)|**(42dias)**||||||
|1,59 (0,58;<br>4,41)|1,39<br>(0,64; 3,03)|3,63<br>(1,43; 9,18)|**0,41**<br>**(0,18; 0,92)**|0,54<br>(0,20; 1,44)|1,39 (0,93;<br>2,05)|1,07<br>(0,44; 2,56)|0,91<br>(0,48; 1,71)|0,68<br>(0,25; 1,82)|<br>0,71<br>(0,46; 1,10)|0,08<br>(0,01; 0,74)|0,06<br>(0,01; 0,46)|**OFX+RF**|||||
|1,06<br>(0,24; 4,62)|<br>0,93<br>(0,37; 2,31)|2,42<br>(0,59; 9,91)|0,27<br>(0,07; 1,05)|0,36<br>(0,08; 1,53)|0,92<br>(0,30; 2,87)|<br>0,71 (0,18;<br>2,81)|0,60<br>(0,18; 2,08)|0,45<br>(0,11; 1,93)|<br>0,48 (0,15;<br>1,51)|0,05<br>(0,00; 0,63)|0,04<br>(0,00; 0,40)|0,67<br>(0,20; 2,21)|**OXT**|2,19 (0,68;<br>7,00)|||
|2,32 (0,48;<br>11,14)|2,03<br>(0,70; 5,87)|5,29<br>(1,17; 23,98)|0,60<br>(0,14; 2,54)|0,79 (0,17;<br>3,69)|2,02<br>(0,57; 7,09)|<br>1,55<br>(0,35; 6,82)|1,32<br>(0,34; 5,10)|0,99 (0,21;<br>4,65)|1,04<br>(0,29; 3,72)|0,12<br>(0,01; 1,47)|0,09<br>(0,01; 0,93)|1,46<br>(0,39; 5,43)<br>(|2,19<br>0,68; 7,00)|**OXT+STP**|||
|<br>0,69<br>(0,21; 2,22)|<br> <br>0,60<br>(0,25; 1,44)|<br>1,56 (0,52;<br>4,68)|<br>**0,18**<br>**(0,07; 0,48)**|<br>0,23<br>(0,07; 0,73)|<br>0,60 (0,30;<br>1,21)|<br> <br>0,46<br>(0,16; 1,32)|<br>0,39 (0,17;<br>0,92)|<br>0,29<br>(0,09; 0,92)|<br> <br>0,31 (0,15;<br>0,64)|<br>0,03<br>(0,00; 0,35)|<br>0,03<br>(0,00; 0,22)|<br> <br>0,43<br>(0,19; 0,96)<br>|<br>0,65 (0,18;<br>2,29)|0,30<br>(0,07; 1,17)|<sup>**SMX-TMP**</sup>|2,89 (1,29;<br>6,49)|
|1,39|1,22|3,17 (0,85;|0,36|0,47 (0,12;|1,21 (0,44;|0,93|0,79 (0,26;|0,59|0,62|0,07 (0,01;|0,05 (0,01;|0,87|1,31|0,60 (0,12;|2,03|**SMX-**|
|(0,35; 5,57)|<br>(0,36; 4,13)|11,89)|(0,10; 1,26)|1,85)|3,36)|(0,26; 3,37)|2,46)|(0,37; 0,95)|<br>(0,22; 1,79)|0,79)|0,50)|(0,29; 2,61)<br>(|0,29; 6,02)|3,02)<br>|(0,59; 6,99)|**TMP+RF**|
|0,70<br>(0,21;2,34)|0,62<br>(0,24;1,60)|1,61<br>(0,52;4,95)|**0,18**<br>**(0,07; 0,51)**|0,24<br>(0,07;0,77)|0,61<br>(0,29;1,30)|0,47<br>(0,16;1,39)|0,40 (0,16;<br>0,99)|0,30 (0,09;<br>0,97)|0,32<br>(0,15;0,68)|0,04<br>(0,00;0,36)|0,03 (0,00;<br>0,23)|0,44<br>(0,19;1,03)<br>(|0,66<br>0,18;2,48)|0,30<br>(0,07;1,26)<br>|1,03<br>(0,52;2,04)<br>|0,51<br>(0,14;1,79) <sup>**TE+STP**</sup>|  
Legenda: DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; OFX: ofloxacino; GT: sufato de gentamicina; LEV: levofloxacino; HC: hidroxicloroquina; CIP: ciprofloxacino; CFX: ceftriaxona; SMX-TMP: sulfametoxazol-trimetoprima; AM: amicacina; TE: tetraciclina; OXT: oxitetraciclina.  
133

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Tabela F. League-table para o desfecho eventos adversos -->
|**CIP+RF**|0,38 (0,10; 1,40)|||1,48 (0,26; 8,53)|||||||
|---|---|---|---|---|---|---|---|---|---|---|
|0,38 (0,10; 1,40)|**DX+CIP**|||3,88 (0,84; 17,90)|||||||
|1,41 (0,22; 9,05)|3,71 (0,71; 19,28)|**DX+GT**|0,97 (0,64; 1,45)||||1,28 (0,75; 2,18)||||
|1,36 (0,20; 9,13)|3,58 (0,66; 19,55)|0,97 (0,64; 1,45)|**DX+GT (30 dias)**||||||||
|1,48 (0,26; 8,53)|3,88 (0,84; 17,90)|1,05 (0,56; 1,94)|1,08 (0,52; 2,27)|**DX+RF**|0,67 (0,19; 2,30)|0,56 (0,22; 1,39)|1,18 (0,86; 1,61)||1,42 (0,84; 2,42)|2,14 (0,26; 17,48)|
|0,98 (0,12; 8,42)|2,59 (0,36; 18,49)|0,70 (0,18; 2,78)|0,72 (0,17; 3,06)|0,67 (0,19; 2,30)|**DX+RF+AM**||||||
|0,82 (0,11; 5,94)|2,16 (0,36; 12,84)|0,58 (0,19; 1,76)|0,60 (0,19; 1,96)|0,56 (0,22; 1,39)|0,83 (0,18; 3,89)|**DX+RF+LEV**|||||
|1,80 (0,30; 10,69)|4,74 (1,00; 22,53)|1,28 (0,75; 2,18)|1,32 (0,68; 2,59)|1,22 (0,90; 1,66)|1,83 (0,51; 6,55)|2,20 (0,83; 5,79)|**DX+STP**|1,56 (0,78; 3,14)|1,10 (0,63; 1,91)|3,57 (0,46; 27,52)|
|2,81 (0,42; 19,07)|7,40 (1,34; 40,89)|2,00 (0,83; 4,82)|2,07 (0,78; 5,45)|1,91 (0,89; 4,09)|2,86 (0,67; 12,25)|3,43 (1,04; 11,34)|1,56 (0,78; 3,14)|**DX+STP+HC (42dias)**|||
|2,11 (0,34; 13,01)|5,54 (1,11; 27,57)|1,49 (0,72; 3,11)|1,55 (0,67; 3,58)|1,43 (0,88; 2,32)|2,14 (0,57; 8,09)|2,57 (0,91; 7,27)|1,17 (0,71; 1,93)|0,75 (0,32; 1,77)|**OFX+RF**||
|4,83 (0,34; 69,27)|12,70 (1,02; 157,98)|3,43 (0,43; 27,16)|3,55 (0,43; 29,26)|3,27 (0,44; 24,28)|4,91 (0,47; 51,75)|5,89 (0,65; 53,42)|2,68 (0,36; 19,81)|1,72 (0,21; 14,27)|2,29 (0,29; 17,83)|**TE+STP**|
|Legen<br>hidroxicloroq|da: DX: doxici<br>uina; CIP: cipro|clina; RF: rifa<br>floxacino; CF|mpicina; STP<br>X: ceftriaxona|: sulfato de es<br>; SMX-TMP:|treptomicina;<br>sulfametoxaz|OFX: ofloxac<br>ol-trimetoprim|ino; GT: sulf<br>a; AM: amica|ato de gentamicin<br>cina; TE: tetracic|a; LEV: levo<br>lina.|floxacino; HC:|  
134

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise de Subgrupos** -->
A maior parte dos estudos incluídos nesta revisão apresentam os resultados agrupados, impossibilitando a separação por grupos de interesse relacionados às características clínicas dos participantes, comorbidades e faixa etária. Destaca-se que embora uma estratificação por faixa etária não tenha sido possível, uma questão de interesse está centrada na faixa etária para indicação de algumas classes de medicamentos usadas no tratamento da brucelose humana. Medicamentos da classe das tetraciclinas não são recomendados para crianças menores de 8 anos conforme bula do medicamento, critério adotado e relatado nos protocolos dos estudos dessa revisão. Para os demais princípios ativos, observou-se em 10 estudos o uso do mesmo tratamento do adulto nas crianças a partir de 7 a 8 anos ( **Tabela G** ).  
Tabela G. Estudos e respectivas faixas etárias mínima e máxima  
|**Estudo (ano)**|**Faixa etária (anos)**|
|---|---|
|**Ariza (1985)**|7-69|
|**Solera (1991)**|7-63|
|**Montejo (1993)**|14-82|
|**Solera (1995)**|7-77|
|**Saltoglu (2002)**|15-65|
|**Roushan (2004)**|>17|
|**Ersoy (2005)**|16-75|
|**Roushan (2006)**|>17|
|**Hasanain, 2016**|>17|
|**Acocella, 1989**|10-70|  
Dessa forma, os resultados dessa revisão são aplicáveis à população de adultos e crianças com 10 anos ou mais, em uso dos mesmos princípios ativos. A avaliação das evidências relacionadas especificamente ao tratamento de crianças menores de 10 anos com brucelose humana foi desenvolvida separadamente e está disposta na Pergunta de Pesquisa 3.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Avaliação do Risco de Viés e Certeza da Evidência:** -->
As avaliações do risco de viés para cada desfecho de interesse desta revisão estão apresentadas nos **Quadro S** , **Quadro T** e **Quadro U** .  
Quadro S. Avaliação do risco de viés para o desfecho insucesso do tratamento, pela Ferramenta ROB.2 para ensaios clínicos randomizados  
|**Ano, autor**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés**|
|---|---|---|---|---|---|---|
|Ariza, 1985<sup>6</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Rodriguez Zapata,<br>1987<sup>7</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Acocella 1989<sup>8</sup>|Baixo|Baixo|Baixo|Alto|Alto|Alto|
|Colmenero,<br>1989<sup>9</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Solera, 1991<sup>10</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Ariza, 1992<sup>11</sup>|Baixo|Baixo|Baixo|Alto|Alto|Alto|
|Akova 1993<sup>12</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Montejo, 1993<sup>13</sup>|Baixo|Baixo|Baixo|Alto|Alto|Alto|  
135  
|**Ano, autor**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés**|
|---|---|---|---|---|---|---|
|1994, Colmenero<sup>14</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Solera, 1995<sup>15</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|Kalo, 1996<sup>16</sup>|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|Agalar, 1999<sup>17</sup>|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|Saltoglu, 2002<sup>18</sup>|Alto|Baixo|Alto|Alto|Alto|Alto|
|Solera, 2004<sup>19</sup>|Baixo|Baixo|Alto|Alto|Alto|Alto|
|Karabay, 2004<sup>20</sup>|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|Roushan, 2004<sup>21</sup>|Algumas<br>preocupações|Algumas<br>preocupações|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|Algumas<br>preocupações|
|2005, Ersoy<sup>22</sup><br> <br>|Algumas<br>preocupações|Alto|Alto|Alto|Alto|Alto|
|2006, Roushan<sup>23</sup>|Baixo|Alto|Alto|Algumas<br>preocupações|Alto|Alto|
|2007, Alavi<sup>24</sup>|Algumas<br>preocupações|Alto|Alto|Baixo|Algumas<br>preocupações|Alto|
|2007, Ranjbar<sup>25</sup>|Algumas<br>preocupações|Alto|Alto|Alto|Alto|Alto|
|2009, Keramat<sup>26</sup>|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|2009, Sarmadian<sup>27</sup>|Algumas<br>preocupações|Alto|Alto|Alto|Alto|Alto|
|2010, Roushan<sup>28</sup>|Alto|Baixo|Baixo|Alto|Alto|Alto|
|2012, Hashemi<sup>29</sup>|Algumas<br>preocupações|Baixo|Alto|Alto|Alto|Alto|
|2014, Sofian<sup>30</sup>|Alto|Baixo|Baixo|Alto|Algumas<br>preocupações|Alto|
|2016, Hasanain<sup>31</sup>|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|2018, Majzoobi<sup>32</sup>|Baixo|Baixo|Baixo|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|
|2020, Karami<sup>33</sup>|Baixo|Baixo|Baixo|Alto|Baixo|Alto|
|2022, Majzoobi<sup>34</sup>|Baixo|Baixo|Baixo|Alto|Baixo|Alto|  
Estudos que avaliaram apenas um dos desfechos usados no desfecho combinado (recidiva + falha) foram avaliados com alto risco de viés no domínio. Além disso, o método para a mensuração dos desfechos considerou as definições estabelecidas pelo autor; aquelas que consideraram apenas sinais e sintomas sem um parâmetro laboratorial obrigatório foram considerados inapropriados.  
Quadro T. Avaliação do risco de viés para o desfecho eventos adversos, pela Ferramenta ROB.2 para ensaios clínicos randomizados  
136  
|**Ano, autor**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de**<br>**viés**|
|---|---|---|---|---|---|---|
|1987, Rodriguez<br>Zapata|Alto|Baixo|Baixo|Alto|Alto|Alto|
|1989, Acocella|Baixo|Baixo|Baixo|Alto|Alto|Alto|
|1989, Colmenero|Alto|Baixo|Baixo|Alto|Alto|Alto|
|1992, Lang|Alto|Algumas<br>preocupações|Alto|Alto|Alto|Alto|
|1995, Solera|Alto|Baixo|Baixo|Alto|Alto|Alto|
|1999, Agalar|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|2004, Solera|Baixo|Baixo|Alto|Alto|Alto|Alto|
|2005, Ersoy|Algumas<br>preocupações|Algumas<br>preocupações|Alto|Alto|Alto|Alto|
|2007, Ranjbar|Algumas<br>preocupações|Alto|Alto|Baixo|Algumas<br>preocupações|Alto|
|2009, Keramat|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|2010, Roushan|Alto|Baixo|Baixo|Alto|Alto|Alto|
|2012, Hashemi|Algumas<br>preocupações|Baixo|Alto|Alto|Alto|Alto|
|2016, Hasanain|Algumas<br>preocupações|Baixo|Baixo|Alto|Alto|Alto|
|2018, Majzoobi|Baixo|Baixo|Baixo|Alto|Alto|Alto|  
Quadro U. Avaliação do risco de viés para o desfecho tempo de defervescência, pela Ferramenta ROB.2 para ensaios clínicos randomizados  
|**Ano/Autor**|**Domínio 1**|**Domínio 2**|**Domínio 3**|**Domínio 4**|**Domínio 5**|**Risco de viés**|
|---|---|---|---|---|---|---|
|1985, Ariza|Alto|Baixo|Baixo|Alto|Algumas<br>preocupações|Alto|
|1987, Rodriguez<br>Zapata|Alto|Baixo|Baixo|Alto|Algumas<br>preocupações|Alto|
|1995, Solera|Alto|Baixo|Baixo|Baixo|Algumas<br>preocupações|Alto|
|1999, Agalar|Algumas<br>preocupações|Baixo|Baixo|Alto|Algumas<br>preocupações|Alto|
|2004, Karabay|Algumas<br>preocupações|Baixo|Baixo|Baixo|Algumas<br>preocupações|Algumas<br>preocupações|  
Os **Quadro V** Quadro e **Quadro W** apresentam um sumário da qualidade da certeza da evidência para os desfechos insucesso do tratamento e eventos adversos, em relação às terapias que apresentaram os melhores desempenhos nas demais análises realizadas nesta revisão. A certeza de evidência foi avaliada como muito baixa em ambos os desfechos.  
137  
Quadro V. Certeza da evidência em relação às terapias que foram avaliadas quanto ao desfecho insucesso do tratamento  
|**Comparação**|**Quantidade de**<br>**estudos**|**Viés interno do**<br>**estudo**|**Viés relatado**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Certeza da**<br>**Evidência**|
|---|---|---|---|---|---|---|---|---|
|DX+GT:DX+GT (30 dias)|1|Preocupações<br>maiores|Baixo risco|Algumas<br>preocupações|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+GT:DX+STP|2|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|||Preocupações|Baixo risco|Nenhuma||Preocupações|Nenhuma||
|DX+RF: DX+STP|10|maiores||preocupação|Nenhuma preocupação|maiores|preocupação|Muito Baixa|
|DX+STP: DX+STP+HC (42||Algumas|Baixo risco|Nenhuma||Algumas|Preocupações||
|dias)|1|<br>preocupações||preocupação|Nenhuma preocupação|<br>preocupações|<br>maiores|Muito Baixa|
|<br>DX+STP+HC (28||<br>Preocupações|Baixo risco|<br>Algumas||<br>Nenhuma|Preocupações||
|dias):DX+STP+HC (42 dias)|1|maiores||preocupações|Preocupações maiores|preocupação|maiores|Muito Baixa|
|DX+GT:DX+RF|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Nenhuma preocupação|Preocupações<br>maiores|Preocupações<br>maiores|Muito Baixa|
|DX+GT:DX+STP+HC (28 dias)|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+GT:DX+STP+HC (42 dias)|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+GT (30 dias):DX+RF|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+GT (30 dias):DX+STP|0|Preocupações<br>maiores|Baixo risco|Algumas<br>preocupações|Preocupações maiores|Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+GT (30 dias):DX+STP+HC||Preocupações|Baixo risco|Algumas||Nenhuma|Preocupações||
|(28 dias)|0|maiores||preocupações|Preocupações maiores|preocupação|maiores|Muito Baixa|
|DX+GT (30 dias):DX+STP+HC||Preocupações|Baixo risco|Nenhuma||Nenhuma|Preocupações||
|(42 dias)|0|maiores||preocupação|Preocupações maiores|preocupação|maiores|Muito Baixa|
|DX+RF:DX+STP+HC (28 dias)|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Nenhuma preocupação|Algumas<br>preocupações|Preocupações<br>maiores|Muito Baixa|
|DX+RF:DX+STP+HC (42 dias)|0|Preocupações<br>maiores|Baixo risco|<br>Nenhuma<br>preocupação|<br>Nenhuma preocupação|<br>Nenhuma<br>preocupação|Preocupações<br>maiores|Muito Baixa|
|DX+STP: DX+STP+HC (28||Preocupações|Baixo risco|Algumas||Nenhuma|Preocupações||
|dias)|0|maiores||preocupações|Preocupações maiores|preocupação|maiores|Muito Baixa|  
<mark>DX: doxiciclina; RF: rifampicina; STP: sulfato de estreptomicina; GT: sulfato de gentamicina; HC: hidroxicloroquina.</mark>  
138  
Quadro W. Certeza da evidência em relação às terapias que foram avaliadas quanto ao desfecho eventos adversos  
|**Comparação**|**Quantidade de**<br>**estudos**|**Viés interno do**<br>**estudo**|**Viés**<br>**relatado**|**Evidência**<br>**indireta**|**Imprecisão**|**Heterogeneidade**|**Incoerência**|**Certeza da**<br>**Evidência**|
|---|---|---|---|---|---|---|---|---|
|DX+GT:DX+GT (30 dias)<br>DX+GT:DX+STP|1<br>1|Preocupações<br>maiores<br>Preocupações<br>maiores|Baixo risco<br>Baixo risco|Nenhuma<br>preocupação<br>Nenhuma<br>preocupação|Preocupações<br>maiores<br>Preocupações<br>maiores|Nenhuma<br>preocupação<br>Nenhuma<br>preocupação|Nenhuma<br>preocupação<br>Nenhuma<br>preocupação|Muito Baixa<br>Muito Baixa|
|DX+RF:DX+STP|6|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Algumas<br>preocupações|Algumas<br>preocupações|Nenhuma<br>preocupação|Baixa|
|DX+STP: DX+STP+HC<br>(42dias)|1|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|
|DX+GT:DX+RF|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|
|DX+GT:DX+STP+HC<br>(42dias)|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|
|DX+GT (30 dias):DX+RF|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|
|DX+GT (30 dias):DX+STP|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|
|DX+GT (30|0|Preocupações|Baixo risco|Nenhuma|Preocupações|Nenhuma|Nenhuma|Muito Baixa|
|dias):DX+STP+HC (42dias)||maiores||preocupação|maiores|preocupação|preocupação||
|DX+RF:DX+STP+HC<br>(42dias)|0|Preocupações<br>maiores|Baixo risco|Nenhuma<br>preocupação|Preocupações<br>maiores|Nenhuma<br>preocupação|Nenhuma<br>preocupação|Muito Baixa|  
<mark>DX: doxiciclina; RF: rifampicina; STP: estreptomicina; GT: gentamicina; HC: hidroxicloroquina.</mark>  
139

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **QUESTÃO 3: Qual é a eficácia e a segurança da terapia com antimicrobiano para o tratamento da brucelose humana em crianças até 10 anos de idade?** -->
**Recomendação:** Condicional a favor do uso do sulfametoxazol + trimetoprima associado à rifampicina para o tratamento de crianças com até 10 anos de idade diagnosticadas com brucelose humana (certeza da evidência muito baixa).  
A estrutura PICOS para esta pergunta foi:  
**População:** Casos confirmados de brucelose humana em crianças até 10 anos de idade.  
**Intervenção:** Monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana.  
**Comparador:** Nenhum tratamento, placebo, monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana.  
**Desfechos:** Insucesso do tratamento, tempo até a defervescência e eventos adversos.  
**Desenho de estudo:** Ensaios clínicos e estudos observacionais, com ou sem grupo comparador.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Métodos e Resultados da Busca** -->
Com base na pergunta PICOS estabelecida para esta revisão, foi realizada a busca sistematizada da literatura nas bases de dados _Medline_ (via _Pubmed_ ), _Embase_ (via Periódicos Capes), _Cochrane Library_ e LILACS (via BVS). A busca foi realizada até o dia 06 de março de 2023, usando termos MeSH, DECS e EMTREE, além de palavras-chave e outros termos livres relacionados a “brucelose humana”, “criança” e “tratamento”, conectados por operadores booleanos ( _OR_ , _AND_ ). Estudos adicionais foram pesquisados nas listas de referências dos artigos incluídos e na literatura cinzenta.  
As estratégias de busca para cada base estão descritas no **Quadro X** .  
140  
Quadro X. Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o tratamento da brucelose humana em crianças  
|**Bases de**<br>**dados**|**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE|<br>**População:**|825|
|(via|#1 (Brucellosis[MeSH Terms]) OR (Brucellosis) OR (Brucelloses) OR (Malta Fever) OR (Fever, Malta) OR (Gibraltar Fever) OR||
|Pubmed)|(Fever, Gibraltar) OR (Rock Fever) OR (Fever, Rock) OR (Cyprus Fever) OR (Fever, Cyprus) OR (Brucella Infection) OR (Brucella<br>Infections) OR (Infection, Brucella) OR (Undulant Fever) OR (Fever, Undulant) OR (Brucella abortus) OR (Brucella canis) OR<br>(Brucella melitensis) OR (Brucella ovis) OR (Brucella suis)|<br>|

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **População:** -->
#2 (child* or pediatr* or paediatr* or infant*) [All fields]

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Intervenção:** -->
#3 (therapeutics[MeSH Terms] OR antibacterial agents[MeSH Terms]) OR (antibiotics[MeSH Terms])OR  (Therapeutics) OR (Therapeutic) OR (Therapy) OR (Therapies) OR (Treatment) OR (Treatments) OR (Anti-Bacterial Agents) OR (Agents, AntiBacterial) OR (Anti Bacterial Agents) OR (Antibacterial Agents) OR (Agents, Antibacterial) OR (Antibacterial Agent) OR (Agent, Antibacterial) OR (Anti-Bacterial Compounds) OR (Anti Bacterial Compounds) OR (Compounds, Anti-Bacterial) OR (Anti-Bacterial Agent) OR (Agent, Anti-Bacterial) OR (Anti Bacterial Agent) OR (Anti-Bacterial Compound) OR (Anti Bacterial Compound) OR (Compound, Anti-Bacterial) OR (Bacteriocidal Agents) OR (Agents, Bacteriocidal) OR (Bacteriocidal Agent) OR (Agent, Bacteriocidal) OR (Bacteriocide) OR (Bacteriocides) OR (Anti-Mycobacterial Agents) OR (Agents, Anti-Mycobacterial) OR (Anti Mycobacterial Agents) OR (Anti-Mycobacterial Agent) OR (Agent, Anti-Mycobacterial) OR (Anti Mycobacterial Agent) OR (Antimycobacterial Agent) OR (Agent, Antimycobacterial) OR (Antimycobacterial Agents) OR (Agents, Antimycobacterial) OR (Antibiotics) OR (Antibiotic)  
#4 #1 AND #2 AND #3  
141  
|**Bases de**<br>**dados**|<br>**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|EMBASE|**População:**<br>#1   ('brucellosis'/exp OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR 'mediterranean fever<br>(brucellosis)' OR 'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR<br>'infection due to brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella'/exp OR 'brucella' OR 'brucella<br>contamination' OR 'brucella abortus'/exp OR 'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR<br>'brucella abortus sensitivity' OR 'brucella canis'/exp OR 'brucella melitensis'/exp OR 'brucella melitensis' OR 'micrococcus<br>melitensis' OR 'brucella ovis'/exp OR 'brucella ovis' OR 'brucella suis'/exp OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis')<br>**População:**<br>#2   child* OR pediatr* OR paediatr* OR infant*<br>**Intervenção:**<br>#3   'therapy' OR 'combination therapy' OR 'disease therapy' OR 'disease treatment' OR 'diseases treatment' OR 'disorder<br>treatment' OR 'disorders treatment' OR 'efficacy, therapeutic' OR 'illness treatment' OR 'medical therapy' OR 'medical<br>treatment' OR 'multiple therapy' OR 'polytherapy' OR 'somatotherapy' OR 'therapeutic action' OR 'therapeutic efficacy' OR 'therapeutic<br>trial' OR 'therapeutic trials' OR 'therapeutics' OR 'therapy, medical' OR 'treatment effectiveness' OR 'treatment efficacy' OR 'treatment,<br>medical'<br>#4 #1 AND #2 AND #3 AND[embase]/lim|<br> <br>882|
|Cochrane<br>Library|**População:**<br>#1 MeSH descriptor: [Brucellosis] explode all trees<br>#2 ('brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR 'mediterranean fever (brucellosis)' OR<br>'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR 'brucella abortus' OR 'bacterium<br>abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella<br>canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis''brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever' OR<br>'mediterranean fever(brucellosis)' OR 'brucellosis' OR 'infection bybrucella' OR 'infection bybrucella melitensis' OR 'infection due|<br>35|  
142  
**Número de Bases de Estratégia de Busca resultados dados** **<u>encontrados</u>** to brucella' OR 'infection due to brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR 'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella suis') #3 ((child* or pediatr* or paediatr* or infant*)) **Intervenção:** #4 (('therapy' OR 'combination therapy' OR 'disease therapy' OR 'disease treatment' OR 'diseases treatment' OR 'disorder treatment' OR 'disorders treatment' OR 'efficacy, therapeutic' OR 'illness treatment' OR 'medical therapy' OR 'medical treatment' OR 'multiple therapy' OR 'polytherapy' OR 'somatotherapy' OR 'therapeutic action' OR 'therapeutic efficacy' OR 'therapeutic trial' OR 'therapeutic trials' OR 'therapeutics' OR 'therapy, medical' OR 'treatment effectiveness' OR 'treatment efficacy' OR 'treatment, medical')) #5 (#1 OR #2) AND #3 AND #4 BVS **População:** 47 #1 (((mh:(brucelose)) OR (brucelose) OR (mh:(brucellosis)) OR (brucellosis) OR (mh:(brucelosis)) OR (brucelosis) OR (febre ondulante) OR (febre de malta) OR (infecçãopor brucella) OR (mh:(brucella)) OR (brucella) OR (mh:(brucella abortus)) OR (brucella abortus) OR (bacterium abortus) OR (mh:(brucella canis )) OR (brucella canis ) OR (mh:(brucella melitensis )) OR (brucella melitensis ) OR (micrococcus melitensis) OR (mh:(brucella ovis)) OR (brucella ovis) OR (mh:(brucella suis)) OR (brucella suis))) **População:** #2 (((child* OR pediatr* OR paediatr* OR infant*))) **Intervenção:** #3 (((therapeutics OR therapeutic OR therapy OR therapies OR treatment OR treatments OR (anti-bacterial agents) OR (agents, antibacterial) OR (anti bacterial agents) OR (antibacterial agents) OR (agents, antibacterial) OR (antibacterial agent) OR (agent, antibacterial) OR (anti-bacterial compounds) OR (anti bacterial compounds) OR (compounds, anti-bacterial) OR (anti-bacterial agent) OR (agent, anti-bacterial) OR (anti bacterial agent) OR (anti-bacterial compound) OR (anti bacterial compound) OR <u>(compound, anti-bacterial) OR (bacteriocidal agents) OR (agents, bacteriocidal) OR (bacteriocidal agent) OR (agent, bacteriocidal)</u>  
143  
|**Bases de**<br>**dados**<br>**Estratégia de Busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|
|OR (bacteriocide) OR (bacteriocides) OR (anti-mycobacterial agents) OR (agents, anti-mycobacterial) OR (anti mycobacterial<br>agents) OR (anti-mycobacterial agent) OR (agent, anti-mycobacterial) OR (anti mycobacterial agent) OR (antimycobacterial agent)<br>OR (agent, antimycobacterial) OR (antimycobacterial agents) OR (agents, antimycobacterial) OR (antibiotics) OR (antibiotic))) )<br>Bases disponíveis após retirar MEDLINE no filtro da BVS:<br>#4 (db:("LILACS" OR "IBECS" OR "BINACIS" OR "CUMED" OR "LIPECS" OR "MedCarib" OR "SES-SP" OR<br>"HANSENIASE" OR "LIS" OR "SMS-SP"))<br>#5 #1 AND #2 AND #3 AND #4||
|Total em todas as bases|1789|
|Busca realizada em 06/03/2023||  
144  
Inicialmente, os registros obtidos nas bases de dados foram importados para o _Mendeley Reference Management Software_<sup>143</sup> para detecção e eliminação das duplicatas, e em seguida, importados para o aplicativo _Rayyan_<sup>144</sup> para gerenciamento das referências e seleção dos estudos. De acordo com os critérios pré-definidos de elegibilidade, os registros foram selecionados por duas duplas de revisores, de forma independente, tanto na triagem de títulos e resumos, quanto na elegibilidade final pela leitura dos textos completos. Os conflitos foram discutidos até que se chegasse a um consenso e, quando necessário, foram resolvidos por outros revisores.  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de inclusão:** -->
(a) Tipos de participantes: Crianças até 10 anos de idade com diagnóstico confirmado de brucelose humana.  
(b) Tipo de intervenção: Qualquer intervenção terapêutica medicamentosa.  
(c) Tipos de estudos: Ensaios clínicos e estudos observacionais, com ou sem grupo comparador.  
(d) Desfechos: Insucesso do tratamento (desfecho combinado considerando falha terapêutica/resposta ao tratamento + recidiva + perdas de acompanhamento), tempo de defervescência e incidência de eventos adversos.  
(e) Idioma: Estudos publicados em inglês, espanhol e português.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de exclusão:** -->
(a) Tipos de participantes: Pacientes com manifestações secundárias da brucelose humana.  
(b) Tipos de estudos: Publicações no formato de _abstract_ de congresso cujos resultados foram relatados em artigo científico; Estudos com menos de 5 pacientes, que não reportaram a descrição dos tratamentos utilizados ou cujos resultados para a faixa etária de interesse não puderam ser extraídos.  
A extração dos dados foi realizada de forma independente por dois avaliadores, utilizando-se um formulário padronizado para a coleta. Os conflitos foram discutidos até que se chegasse a um consenso entre os dois revisores.  
Os seguintes dados foram extraídos: ano, autor, país, desenho do estudo, número de participantes, período do estudo, tempo de seguimento dos pacientes, critérios diagnósticos, critérios de inclusão, critérios de exclusão, idade, gênero, manifestações clínicas, forma clínica da doença (aguda, subaguda ou crônica), caracterização das espécies de _Brucella_ , duração dos sintomas, descrição da intervenção terapêutica, duração do tratamento, perdas de seguimento, casos de recidiva e falha ao tratamento, eventos adversos e tempo para a defervescência.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Desfechos de interesse** -->
O desfecho primário de interesse foi o insucesso das intervenções, sendo comumente relatado pela ocorrência de falha e/ou de recidiva da terapia. A recidiva foi definida como  
145  
reaparecimento de sintomas ou detecção de cultura sanguínea positiva após o término do tratamento. Falhas no tratamento foram definidas como persistência de sintomas e de culturas sanguíneas positivas na vigência do tratamento. Considerando que o objetivo da terapia é a melhora das manifestações da doença a partir do início do tratamento, os dois desfechos foram considerados agrupáveis gerando um desfecho combinado de insucesso. Nesse estudo, foram considerados casos de insucesso aqueles sem resposta ao tratamento e/ou aqueles com recidiva.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Risco de viés** -->
A avaliação do risco de viés dos estudos incluídos foi realizada utilizando-se as ferramentas de avaliação crítica da JBI ( _Instituto Joanna Briggs_ ) conforme o desenho metodológico dos estudos incluídos na revisão. A avaliação abrangeu os seguintes itens: (1) critérios de inclusão claros, (2) medição padronizada e confiável da condição, (3) métodos válidos para identificar a condição, (4) inclusão consecutiva e (5) completa dos participantes, (6) relato de dados demográficos dos participantes e (7) informações clínicas, (8) relato claro dos resultados e do seguimento dos pacientes, (9) relato de informações demográficas do local/ambulatório e (10) análise estatística apropriada.  
A avaliação da qualidade da evidência foi realizada por meio do sistema GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ), classificada em quatro níveis: alta, moderada, baixa ou muito baixa.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análises dos dados** -->
Inicialmente os dados foram analisados de forma qualitativa, seguida de uma sumarização dos achados em relação ao insucesso da terapia. A análise dos dados foi realizada no programa R versão 3.6.2 com ativação do pacote meta. Todas as análises foram conduzidas a partir do modelo de efeitos randômicos, dada a alta heterogeneidade entre os estudos, estimada pela estatística de I<sup>2</sup> . A estimativa sumarizada da taxa de insucesso da terapia (falha terapêutica e/ou recidiva) foi realizada somente entre aqueles estudos que relataram o desfecho separadamente para cada tipo de tratamento realizado e que apresentaram mais de cinco participantes por intervenção. Os estudos incluídos nesta revisão não forneceram dados que permitissem agrupar os demais desfechos de interesse para este relatório.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resultados da Busca** -->
A partir da estratégia de busca utilizada nas bases de dados, foram recuperados 1.773 registros, com 1.402 artigos restantes após a identificação e eliminação de duplicatas. Todos os registros passaram por um processo de revisão por pares, e o texto completo de 77 artigos potencialmente elegíveis foi cuidadosamente avaliado. Entre eles, 66 estudos não atenderam aos critérios de inclusão desta revisão. Os motivos de exclusão foram a ausência de desfecho de interesse (19 estudos), estudos que não avaliaram e/ou não relataram desfecho por terapia na população específica de crianças até 10 anos de idade (22 estudos), intervenções não relatadas ou mal descritas nos estudos impossibilitando a identificação dos tratamentos (12 estudos), tamanho amostral pequeno (4 estudos) e redação em idioma diferente do inglês, português ou espanhol (9 estudos). Ao final, 11 estudos atenderam aos critérios de elegibilidade e foram incluídos nesta revisão **Figura U** .  
146  
<!-- Start of picture text -->
Identificação de estudos por meio de bases de dados e registros<br>Registros identificados por:<br>MEDLINE (n=820)<br>Registros duplicados removidos<br>EMBASE (n=871)<br>(n=371)<br>COCHRANE (n=35)<br>BVS (n=47)<br>Total = 1773 registros<br>I {|<br>Registros em triagem (n =1402)  Registros excluídos (n =1315)<br>a<br>Publicações  pesquisadas   Registros não recuperados<br>(n =87)  (n = 10)<br>Publicações  avaliadas  para  Publicações excluídas (n=66)<br>elegibilidade (n =77)<br> População (n = 22)<br> Desfecho (n =19)<br> Intervenção não<br>especificada ou mal<br>descrita (n =12)<br> Outro idioma (n= 9)<br>Estudos incluídos na revisão<br> Série pequena (menos<br>(n = 11)<br>de 5 pacientes tratados)<br>Relatos dos estudos incluídos<br>(n=4)<br>(n = 11)<br>S ee |<br>hz<br>Figura U. Fluxograma de seleção dos estudos incluídos na revisão sistemática avaliando<br>opções terapêuticas para o tratamento das manifestações primárias da Brucelose Humana em<br>crianças até 10 anos de idade<br>Identificação<br>Triagem<br>Incluídos<br><!-- End of picture text -->  
Fonte: Adaptado de Page et al<sup>151</sup> .

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise e Apresentação dos Resultados** -->
As características dos estudos incluídos, tais como características metodológicas, dos participantes e das intervenções, estão apresentadas nos **Quadro Y** , **Quadro Z** e **Quadro AA** , respectivamente.  
Os onze estudos incluídos foram conduzidos em oito países diferentes. Especificamente, houve dois estudos da Grécia, um da Jordânia, dois do Irã, um da Macedônia, um de Omã, um da Espanha, um da Turquia e dois dos Estados Unidos.  
Todos os estudos incluídos apresentaram delineamento observacional. Dentre eles, 10 foram classificados como séries retrospectivas de casos, com dados obtidos de prontuários médicos, enquanto um estudo foi prospectivo.  
No contexto dos critérios de diagnóstico para a inclusão de pacientes nos estudos, a maioria deles utilizou uma combinação de um ou mais critérios para confirmar o diagnóstico. Os  
147  
critérios mais frequentemente utilizados foram o Teste de Aglutinação Padrão (STAT) com título igual ou superior a 1:160, cultura de sangue e avaliação de sinais e sintomas clínicos.  
Em relação ao ano de publicação dos estudos, três estudos foram conduzidos antes dos anos 2000, entre os anos de 1996 a 1999. Outro conjunto de estudos foi realizado entre 2000 e 2010 (3 estudos), e os estudos restantes (5 estudos) foram conduzidos a partir de 2011, sendo o estudo mais recente publicado em 2016. O período de acompanhamento do estudo variou dependendo da disponibilidade de prontuários dos pacientes e dos critérios de monitoramento. Os períodos de acompanhamento variaram desde acompanhamentos de curto prazo de um mês, até estudos de longo prazo com acompanhamento estendendo-se até 7 anos.  
Nesta revisão, os 11 estudos apresentaram um total de 1.156 crianças. Entre as crianças incluídas, 647 (56%) eram do sexo masculino e 509 (44%) eram do sexo feminino, demonstrando o mesmo padrão de proporção em cada estudo individual.  
Entre os estudos que realizaram a identificação das espécies, os resultados revelaram que a espécie mais identificada foi a _Brucella melitensis (B. melitensis)_ , seguida de _Brucella abortus (B. abortus),_ identificada em uma proporção menor. As principais manifestações clínicas observadas nos pacientes incluídos foram: febre (variando de 75% a 100% dos casos), sudorese (variando de 3,9% a 64% dos casos), artralgia (variando de 24% a 100% dos casos) e artrite (variando de 19,0% a 62,5% dos casos). Outras manifestações identificadas incluíram dor abdominal, dor de cabeça, dor nas costas, calafrios, fadiga, hepatomegalia, esplenomegalia e outras. A maioria dos estudos não relatou a forma clínica da doença. A duração dos sintomas variou de 0 a 360 dias.  
148  
Quadro Y. Principais características metodológicas dos estudos que avaliaram o tratamento da brucelose humana em crianças  
|**Estudo**|**País (n)**|**Desenho do estudo**|**Período do**<br>**estudo**|**Tempo de**<br>**seguimento**|**Critérios diagnósticos**|**Critérios de inclusão**|
|---|---|---|---|---|---|---|
|**Galanakis et al., 1996**<br>242|Grécia (52)|Série de casos<br>retrospectiva|1979 a 1993|<br>O seguimento foi<br>realizado de acordo<br>com a resposta<br>individual|STAT≥1:160 e/ou cultura de<br>sangue|Crianças hospitalizadas<br>com brucelose no<br>Departamento Pediátrico<br>Universitário|
|**Sánchez-Tamayo et**<br>**al., 1997**<sup>243</sup>|Espanha (34)|Série de casos<br>prospectiva|Março 1993 a<br>fevereiro 1995|6 meses após o final<br>do tratamento.<br>9,2 meses<br>intervalo (6-20<br>meses)|Sinais e sintomas clínicos, STAT<br>≥ 1:160 ou ≥ 1:320 para o teste<br>de_Coombs_anti-_Brucella_, ou<br>soroconversão de um dos testes<br>sorológicos com aumento de 4<br>vezes ou mais no título inicial<br>em duas amostras de soro e/ou<br>cultura de sangue|Crianças ≤ 14 anos de<br>idade diagnosticadas na<br>Unidade de Doenças<br>Infecciosas Pediátricas do<br>Hospital Regional de<br>Málaga, Espanha, ou nos<br>Departamentos Pediátricos<br>de dois hospitais distritais<br>dependentes|
|**Issa et al., 1999**<sup>244</sup>|Jordânia (68)|Série de casos<br>retrospectiva|NR|Pelo menos 6 meses|Qualquer um dos seguintes:<br>sinais e sintomas clínicos com<br>cultura de sangue positiva ou<br>STAT ≥ 1:160 e/ou aumento do<br>título|NR|
|**El-Amin et al., 2001**<br>245|Omã (375)|Série de casos<br>retrospectiva|Setembro 1995 a<br>setembro 1998|6 meses|O diagnóstico foi baseado em<br>critérios clínicos e confirmado<br>de acordo com os critérios de<br>definição de caso da<br>Organização Mundial da Saúde<br>(OMS): cultura de sangue<br>positiva ou STAT≥1:160|Todos os pacientes ≤ 13<br>anos de idade<br>diagnosticados com<br>brucelose|
|**Makis et al., 2005**<sup>246</sup>|Grécia (20)|Série de casos<br>retrospectiva|NR|Pelo menos 8 meses|Sinais e sintomas clínicos com<br>cultura de sangue positiva ou<br>STAT ≥ 1:160|Crianças hospitalizadas por<br>brucelose no Departamento<br>Pediátrico do Hospital<br>Universitário de Ioannina|
|**Shen et al., 2008**<sup>247</sup>|EUA (20)|Série de casos<br>retrospectiva|Janeiro 1993 a<br>janeiro 2005|1-9 meses|Sinais e sintomas clínicos com<br>cultura positiva de fluido<br>corporal estéril ou STAT ≥<br>1:160|A inclusão na revisão foi<br>baseada em um diagnóstico<br>clínico e laboratorial de<br>brucelose, seguido pelo<br>tratamento antimicrobiano<br>adequado|  
149  
|**Estudo**|**País (n)**|**Desenho do estudo**|**Período do**<br>**estudo**|**Tempo de**<br>**seguimento**|**Critérios diagnósticos**|**Critérios de inclusão**|
|---|---|---|---|---|---|---|
|**Logan et al., 2011**<sup>248</sup>|EUA (21)|Série de casos<br>retrospectiva<br>multicêntricas|Janeiro 1986 a<br>dezembro 2008|<br>2 anos|Sinais e sintomas clínicos com<br>cultura positiva de fluido<br>corporal estéril ou teste de<br>aglutinação ≥ 1:160.<br>O diagnóstico confirmado foi<br>baseado no isolamento de<br>espécies de_Brucella_em culturas<br>de sangue, medula óssea, líquido<br>cefalorraquidiano, outros locais<br>estéreis ou em amostras de<br>tecido|Casos de_Brucella_<br>ocorrendo em crianças <18<br>anos de idade|
|**Zamani et al., 2011**<sup>249</sup>|Irã (24)|Série de casos<br>retrospectiva|1997 a 2005|1 ano|STAT>1/160 e 2ME ≥1/40.<br>Culturas bacterianas foram<br>realizadas em todos os pacientes|Foram revisados os<br>prontuários hospitalares de<br>crianças com diagnóstico<br>confirmado de brucelose<br>que foram internadas na<br>enfermaria de doenças<br>infecciosas e no<br>departamento de pediatria<br>entre 1997 e 2005|
|**Bosilkovski et al.,**<br>**2015**<sup>250</sup>|Macedônia (317)|Série de casos<br>retrospectiva|Janeiro 1989 a<br>dezembro 2011|A mediana foi de 6<br>meses, variando de 0 a<br>84 meses|Sinais e sintomas na presença de<br>STAT (1/160), de teste de<br>_Coombs_para_Brucella_(1/320)<br>ou do ensaio Brucellacapt<br>(>1/320), de acordo com o<br>período do estudo|Pacientes com brucelose ≤<br>15 anos de idade|
|**Çıraklı et al., 2015**<br>251|Turquia (52)|Série de casos<br>retrospectiva|Janeiro 2008 a<br>dezembro 2013|NR|STAT ≥1/160, isolamento de<br>_Brucella_sp. em cultura de fluido<br>corporal estéril com sintomas e<br>sinais clínicos|Casos pediátricos<br>diagnosticados com<br>brucelose e internados no<br>Hospital Pediátrico da<br>Faculdade de Medicina da<br>Universidade Ondokuz<br>Mayis|
|**Roushan et al.,**<br>**2016**<sup>252</sup>|Irã (173)|Série de casos<br>retrospectiva|Abril 2005 a<br>dezembro 2015|NR|STAT ≥1/160 e 2ME ≥1/80 com<br>sintomas e sinais clínicos|Pacientes com brucelose ≤<br>15 anos de idade|  
Legenda: NR: não relatado, STAT: teste de aglutinação padrão; 2ME: 2-mercaptoetanol.  
150

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro ZI. Características da população pediátrica incluída nos estudos que avaliaram o tratamento da brucelose humana em crianças -->
|**Estudo**|**Idade (anos)**<br>**média±DP,**<br>**(intervalo)**|**Gênero masculino/feminino**|**Manifestações clínicas (%)**|**Forma clínica**|**Caracterização das**<br>**espécies de****_Brucella_**|**Duração dos**<br>**sintomas (dias)**<br>**Média ± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|
|**Galanakis et al.,**<br>**1996**<sup>242</sup>|NR (1.3-14)|31/21|Febre (88%), Artralgia (62%),<br>Mal-estar (29%), Mialgia/dor<br>de cabeça (21%), Sudorese<br>(19%),<br>Sintomas<br>gastrointestinais<br>(19%),<br>Erupção cutânea (12%), Tosse<br>(12%),<br>Manifestações<br>do<br>sistema nervoso central (2%),<br>Manifestações cardíacas (2%),<br>Esplenomegalia<br>(52%),<br>Hepatomegalia(33%).|NR|_B. melitensis_(21,2%)<br>_B. abortus_(2%)|16±NR (1 a 90)|
|**Sánchez-Tamayo**<br>**et al., 1997**<sup>243</sup>|8,3 (2,3-13,9)|24/10|NR|Localizada: 5/34<br>(osteoarticular)<br>Forma aguda: NR|NR|20,5 (5 a 75)|
|**Issa et al., 1999**<sup>244</sup>|NR (3-14)|40/28|Artralgia (78%); febre (75%);<br>sudorese (60%); artrite (56%);<br>esplenomegalia<br>(34%)<br>e<br>hepatomegalia(25%).|NR|NR|NR|
|**El-Amin et al.,**<br>**2001**<sup>245</sup>|5,6 ± 3,34<br>(7m - 12)|201/174|Febre (91%), Sudorese (57%),<br>Dor nos membros (55%),<br>Artrite<br>em<br>uma<br>única<br>articulação<br>(40%),<br>Esplenomegalia (23%), Dor<br>nas<br>costas<br>(20%),<br>Hepatomegalia<br>(18%),<br>Adenopatia (11%), Artrite em<br>múltiplas articulações(10,5%).|NR|_B. melitensis_(74%)<br>_B. abortus_(26%)|18 ± 9,61|
|**Makis et al.,**<br>**2005**<sup>246</sup>|Mediana 9,5 (3m -<br>11)|11/09|Todas<br>as<br>crianças<br>apresentaram febre e artralgia<br>ou mialgia.|NR|_B. melitensis_|NR|
|**Shen et al., 2008**<sup>247</sup>|7,85 (2-18)|10/10|Febre (80%), Artrite (25%),<br>Calafrios<br>(25%),<br>Artralgia<br>(75%),Perda depeso(5%),|NR|_B. melitensis_(90%)|(7 a 120)|  
151  
|**Estudo**|**Idade (anos)**<br>**média±DP,**<br>**(intervalo)**|**Gênero masculino/feminino**|**Manifestações clínicas (%)**|**Forma clínica**|**Caracterização das**<br>**espécies de****_Brucella_**|**Duração dos**<br>**sintomas (dias)**<br>**Média ± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|
||||Fadiga (5%), Dor generalizada<br>(5%), Falta de energia (5%),<br>Dor abdominal (25%), Dor de<br>cabeça(15%).||||
|**Logan et al.,**<br>**2011**<sup>248</sup>|mediana 6,5<br>(2-14)|13/08|Febre<br>(95%),<br>Sintomas<br>constitucionais<br>(76%),<br>Anorexia<br>(48%),<br>Fadiga<br>(33%), Calafrios (24%), Perda<br>de<br>peso<br>(24%),<br>Mialgias/Artralgias<br>(24%),<br>Dor abdominal (24%). %),<br>Vômitos e/ou diarreia (24%),<br>Dor<br>de<br>garganta<br>(19%),<br>Distúrbios neuropsiquiátricos<br>(10%),<br>Outros<br>(29%),<br>Esplenomegalia<br>(60%),<br>Hepatomegalia (55%), Artrite<br>(35%),<br>Sacroileíte<br>(15%),<br>Joelho (10%), Quadril (10%),<br>SNC<br>(15%),<br>Osteomielite<br>(10%),<br>Cardíaca<br>(10%),<br>Adenite mesentérica(5%).|NR|NR|15 ± NR (0 a 9<br>meses)|
|**Zamani et al.,**<br>**2011**<sup>249</sup>|7,4±3,71<br>(2-12)|14/10|Febre (87,5%), fadiga (75%),<br>dor<br>de<br>cabeça<br>(58,3%),<br>calafrios<br>(45,8%),<br>suores<br>noturnos (41,7%) e perda de<br>peso (20,8%). esplenomegalia<br>clinicamente evidente (25%) e<br>hepatomegalia<br>(16,7%).<br>Monoartrite<br>(62,5%)<br>e<br>poliartrite(37,5%).|NR|_B. melitensis_(17%)|NR|
|**Bosilkovski et al.,**<br>**2015**<sup>250</sup>|mediana 9 (7 m -<br>14 a)|201/116|Febre (78%), Mal-estar (60%),<br>Sudorese<br>(64%),<br>Artralgia<br>(72%), Perda de peso (10%),<br>Dor<br>de<br>cabeça<br>(33%),<br>Hepatomegalia<br>(68%),|NR|NR|21 (3 a 360)|  
152  
|**Estudo**|**Idade (anos)**<br>**média±DP,**<br>**(intervalo)**|**Gênero masculino/feminino**|**Manifestações clínicas (%)**|**Forma clínica**|**Caracterização das**<br>**espécies de****_Brucella_**|**Duração dos**<br>**sintomas (dias)**<br>**Média ± DP**<br>**(intervalo)**|
|---|---|---|---|---|---|---|
||||Esplenomegalia (53%).||||
|**Çıraklı et al.,**<br>**2015**<sup>251</sup>|11 (2-17)|42/10|Febre 39 (75%), artralgia 28<br>(53,8%), dor nas pernas 16<br>(30,8%), fadiga 10 (19,2%),<br>perda de peso 4 (7,7%),<br>epistaxe 3 (5,7%), sudorese<br>noturna<br>2<br>(3,9%),<br>esplenomegalia 23 (44,2%),<br>hepatomegalia 22 (42,3%),<br>artrite 10 (19,2%); Petéquias 3<br>(5,7%);<br>epididimorquite<br>1<br>(1,9%).|Aguda<br>(57,7%)<br>Subaguda (42,3%)|_B. melitensis_(65,2%)|NR|
|**Roushan et al.,**<br>**2016**<sup>252</sup>|NR|65/108|Febre (107 - 61,8%), sudorese<br>(77 - 44,5%), artralgia (90 -<br>52%), artrite (46 - 26,6%),<br>sacroileíte (13 - 7,5%) e<br>espondilite(46 - 26,6%).|NR|NR|NR|  
Legenda: DP: desvio padrão, NR: não relatado, a: anos, d: dias, m: meses, SNC: Sistema Nervoso Central.  
153

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro AA. Características das intervenções para tratamento da brucelose humana em crianças -->
|**Estudo**|**Tratamento descrito**<br>**para faixa etária**|**Intervenção (n tratado)**|**Dose**|**Duração do**<br>**tratamento**|**I**<br>**Recidiva**<br>**n (%)**|**nsucesso**<br>**Falha Terapêutica**<br>**n (%)**|
|---|---|---|---|---|---|---|
|**Galanakis et al.,**|<8 anos||SMX-TMP: 6-8||1 (2%)||
|**1996**<sup>242</sup>||SMX-TMP + STP* (24)|mg/kg/d<br>STP: 20-30mg/kg/d*|21 dias (3s)||NR|
|**Sánchez-Tamayo et**<br>**al., 1997**<sup>243</sup>|<8 anos|TMP-SXM + GT*** (13)|TMP-SXM: 8-10mg<br>TMP/kg/d<br>GT: 5mg/kg/d***|21 dias (3s)|4 (30%)|NR|
|**Issa et al., 1999**<sup>244</sup>|<8 anos|TMP-SXM + RF (10)|NR|42d (6s)|2 (20%)|NR|
|||TMP-SXM + STP* (7)|NR|42d (6s)|0 (0%)|NR|
|||RF + STP* (5)|NR|42d (6s)|1 (20%)|NR|
|||TMP-SXM + GT*** (9)|NR|42d (6s)|5 (55,6%)|NR|
|||RF + GT*** (3)|NR|42d (6s)|3 (100%)|NR|
|||TMP-SXM + RF (10)|NR|42d (6s)|2 (20%)|NR|
|**El-Amin et al.,**<br>**2001**<sup>245</sup>|<7 anos|TMP-SXM + RF ( 345)|TMP-SXM: 10/50<br>mg/kg/d<br>RF: 15 mg/kg/d|42d (6s)|0 (0%)|NR|
|**Makis et al., 2005**<br>246|< 10 anos|TMP-SXM + RF (16)|NR|42d (6s)|3 (31,8%)|NR|
|**Shen et al., 2008**<sup>247</sup>|<8 anos|TMP-SXM + RF e/ou GT (9)|NR|21d a 42d (3 a 6s)|3 (33,3%)|1 (11,1%)|
|**Logan et al., 2011**<br>|< 10 anos|TMP-SMX (5)|NR|≤ 21 dias (3s)|2 (40%)|0 (0%)|
|248||TE (1)|NR|42 d (6 s)|1 (100%)|0 (0%)|
|||TMP-SXM + GT (2)|NR|≥ 42 d (6 s)|1 (50%)|2 (100%)|
|||TMP-SXM + RF (3)|NR|≥ 42 d (6 s)|0 (%)|0 (%)|
|||TMP-SXM + RF + GT (1)|NR|≥ 42 d (6s)|0 (%)|0 (%)|
|||TE ou DX + G (2)|NR|21 dias (3s)|0 (%)|0 (%)|
|||TE ou DX + RF (1)|NR|≥ 42 d (6s)|0 (%)|0 (%)|  
154  
|**Estudo**|**Tratamento descrito**<br>**para faixa etária**|**Intervenção (n tratado)**|**Dose**|**Duração do**<br>**tratamento**|**I**<br>**Recidiva**<br>**n(%)**|**nsucesso**<br>**Falha Terapêutica**<br>**n(%)**|
|---|---|---|---|---|---|---|
|||DX + RF + GT (1)|NR|≥ 42 d (6s)|0 (%)|0 (%)|
|**Zamani et al.,**<br>**2011**<sup>249</sup>|<8 anos|TMP-SXM + GT (13)|TMP-SXM: 10<br>mg/kg/d<br>GT: 5-7 mg/kg/d|42 d (6s)|0 (%)|0 (%)|
|**Bosilkovski et al.,**<br>**2015**<sup>250</sup>|<8 anos|TMP-SXM + RF + GT (43)|TMP-SXM: 10-12<br>/k/d|45 d|4 (9,3%)|NR|
|||TMP-SXM + RF (74)|mgg<br>FR: 15–20 mg/kg/d|45 d|4 (5,4%)|NR|
|||TMP-SXM + GT (13)|GT: 5 mg/kg/d|45 d|0 (%)|NR|
|**Çıraklı et al.,**<br>**2015**<sup>251</sup>|<8 anos|TMP-SXM + RF (52)|NR|42 d (6s)|11 (21,2%)|NR|
|**Roushan et al.,**<br>**2016**<sup>252</sup>|<10 anos|TMP-SXM + RF (41)|NR|45 dias|2 (0,04%)|NR|  
Legenda: a) A falha do tratamento foi considerada como falha terapêutica ou falha terapêutica + recidiva; DX: doxiciclina; FR: rifampicina; STP: estreptomicina; GT: gentamicina; SMX-TMP: trimetoprima-sulfametoxazol; TE: tetraciclina; NR: não relatado, d: dias; s: semanas; *STP por via intramuscular por 2 semanas; **STP por via intramuscular por 3 semanas; **GT intramuscular por 5 a 7 dias.  
155

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resumo das evidências:** -->
A revisão sistemática conduzida com foco no tratamento da brucelose humana em crianças com idade até 10 anos revelou uma lacuna significativa no que se refere a ensaios clínicos randomizados. Não foram identificados estudos com este delineamento que avaliassem especificamente o tratamento da brucelose humana na população pediátrica. Em consequência, há uma carência de estudos comparativos que abordem a eficácia e a segurança dos tratamentos existentes para essa faixa etária.  
A partir dos estudos observacionais incluídos nesta revisão, foi possível identificar e extrair dados de cinco abordagens terapêuticas distintas para a faixa etária estudada: 1) Sulfametoxazol associado a Trimetoprima (SMX + TMP), 2) SMX + TMP associado a rifampicina, 3) SMX + TMP associado a aminoglicosídeos, 4) Rifampicina associado a aminoglicosídeos, 5) SMX + TMP associado a rifampicina e a aminoglicosídeos.  
A duração do tratamento com os antimicrobianos avaliados variou entre os estudos, sendo classificada como de curta duração (21 dias)<sup>101,253,254</sup> e de longa duração (42 dias ou mais)<sup>98,99,255–</sup> 260.  
Os esquemas de dupla terapia com sulfametoxazol + trimetoprima associado a rifampicina e com sulfametoxazol associado a trimetoprima e a aminoglicosídeos foram os mais relatados, por 7 e 5 estudos, respectivamente<sup>98,101,254,257,259</sup> .  
A taxa sumarizada de insucesso variou entre 2% e 40% entre os esquemas terapêuticos avaliados. No entanto, para alguns esquemas terapêuticos, apenas um estudo foi identificado: SMX + TMP em monoterapia<sup>253</sup> , rifampicina + aminoglicosídeos<sup>257</sup> , e a tripla terapia com SMX + TMP associado a rifampicina e a aminoglicosídeo<sup>98</sup> . Para os esquemas mais utilizados no tratamento da brucelose humana em crianças, as taxas de insucesso sumarizadas foram 2% (IC95%: 0,0-0,49) e 13% (IC95%: 0,06-0,29) para SMX + TMP associado a aminoglicosídeos e SMX + TMP associado a rifampicina, respectivamente ( **Tabela H** ). Nenhum dos estudos incluídos avaliou os desfechos de taxa de eventos adversos e tempo para a defervescência.  
Tabela H. Taxa de insucesso (IC95%) por esquema de tratamento  
|**Intervenção**||**Estudos**|**Eventos**|**Total de**<br>**participantes**|**Taxa de insucesso**<br>**sumária (IC95%)**|
|---|---|---|---|---|---|
|**Sulfametoxazol-**<br>**trimetoprima**||1|1|5|0,40<br>(0,10-0,80)|
|**Sulfametoxazol-**<br>**trimetoprima**<br>**rifampicina**|**+**|7|46|581|0,13<br>(0,06-0,29)|
|**Sulfametoxazol-**<br>**trimetoprima**<br>**aminoglicosídeos**|**+**|5|9|85|0,02<br>(0,00-0,49)|
|**Rifampicina**<br>**aminoglicosídeos**|**+**|1|1|5|0,20<br>(0,03-0,69)|
|**Sulfametoxazol-**<br>**trimetoprima**<br>**rifampicina**<br>**aminoglicosídeos**|**+**<br>**+**|1|4|43|0,09<br>(0,04-0,22)|

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Avaliação do Risco de Viés e Certeza da Evidência:** -->
Todos os estudos incluídos nesta revisão sistemática apresentam desenho correspondente a séries de casos, que compreendem um conjunto de pacientes com características comuns usado  
156  
para descrever algum aspecto clínico, fisiopatológico ou operacional de uma doença. Nestes estudos não foram observados grupos de comparação, sendo apresentados casos prevalentes em uma amostra por conveniência<sup>147</sup> . Assim, as pontuações obtidas na Lista de Verificação de Avaliação Crítica de Estudos de Série de Casos do JBI (em um total de 10 pontos) variaram de 4 a 9 pontos ( **Quadro BB** ). Os domínios que receberam mais penalidades foram a inclusão completa de participantes e relato claro das características demográficas dos participantes.  
157  
Quadro BB. Descrição geral da qualidade dos estudos incluídos na revisão sistemática avaliando intervenções terapêuticas para a brucelose na população pediátrica  
|**Estudo/ano**|**Havia**<br>**critérios**<br>**claros**<br>**para**<br>**inclusão**<br>**na série**<br>**de casos?**|**A condição foi**<br>**medida de forma**<br>**padronizada e**<br>**confiável para**<br>**todos os**<br>**participantes**<br>**incluídos na série**<br>**de casos?**|**Foram utilizados**<br>**métodos válidos**<br>**para a**<br>**identificação da**<br>**condição em todos**<br>**os participantes**<br>**incluídos na série**<br>**de casos?**|**A série de casos**<br>**teve inclusão**<br>**consecutiva dos**<br>**participantes?**|**A série de casos**<br>**teve inclusão**<br>**completa de todos**<br>**os participantes?**|**Houve relato claro**<br>**das características**<br>**demográficas dos**<br>**participantes no**<br>**estudo?**|**Houve relato**<br>**claro das**<br>**informações**<br>**clínicas dos**<br>**participantes?**|**Os resultados ou**<br>**acompanhamentos**<br>**dos casos foram**<br>**relatados de forma**<br>**clara?**|**Houve relato claro das**<br>**informações**<br>**demográficas do(s)**<br>**local(is) de**<br>**apresentação/clínica?**|**A análise**<br>**estatística foi**<br>**adequada?**|
|---|---|---|---|---|---|---|---|---|---|---|
|Galanakis et al.,<br>1995|SIM|SIM|SIM|INCERTO|SIM|SIM|SIM|SIM|SIM|SIM|
|Sánchez-Tamayo<br>et al., 1997|SIM|SIM|SIM|INCERTO|NÃO|NÃO|SIM|SIM|SIM|INCERTO|
|Issa et al., 1999|SIM|SIM|SIM|INCERTO|INCERTO|SIM|SIM|SIM|SIM|INCERTO|
|El-Amin et al.,<br>2001|SIM|SIM|SIM|SIM|NÃO|NÃO|SIM|SIM|SIM|SIM|
|Makis et al., 2005|SIM|SIM|SIM|INCERTO|INCERTO|NÃO|NÃO|SIM|NÃO|INCERTO|
|Shen et al., 2008|SIM|SIM|SIM|SIM|SIM|SIM|SIM|SIM|SIM|INCERTO|
|Logan et al., 2011|SIM|SIM|SIM|INCERTO|SIM|SIM|SIM|SIM|SIM|SIM|
|Zamani et al.,<br>2011|SIM|SIM|SIM|INCERTO|SIM|SIM|SIM|SIM|SIM|SIM|
|Bosilkovski et al.,<br>2015|SIM|SIM|SIM|INCERTO|SIM|SIM|SIM|SIM|SIM|SIM|
|Çıraklı et al., 2015|SIM|SIM|SIM|INCERTO|INCERTO|SIM|SIM|SIM|NÃO|SIM|
|Roushan et al.,<br>2016|SIM|SIM|SIM|SIM|INCERTO|NÃO|SIM|SIM|NÃO|INCERTO|  
Legenda: NA: não se aplica  
158  
A **Tabela I** apresenta os resultados das meta-análises e da avaliação da certeza da evidência (GRADE) para o desfecho da taxa de insucesso. A certeza da evidência para todos os esquemas terapêuticos avaliados foi classificada como "muito baixa". Esta classificação sugere que há uma confiança limitada nos efeitos estimados para taxa de recidiva.  
A decisão de rebaixar a certeza da evidência foi fundamentada em várias razões específicas relacionadas ao desenho dos estudos e à natureza dos dados disponíveis.  
Primeiramente, a fonte de informação que embasou a análise provém de séries de casos. Esse tipo de estudo, por sua natureza observacional impede de estabelecer relações causais. Além disso, a ausência de grupos comparadores nos estudos avaliados limita a capacidade de discernir a eficácia de uma intervenção em relação a outra.  
Durante essa revisão, foram encontrados cinco principais esquemas terapêuticos utilizados para tratar brucelose humana na população pediátrica até 10 anos de idade. Portanto, fica evidente a heterogeneidade da conduta terapêutica para essa população, o que torna desafiador fazer uma recomendação única.  
Faz-se necessária a realização de ensaios clínicos randomizados que abordem essas lacunas para uma compreensão mais aprofundada e confiável dos desfechos avaliados.  
159  
Tabela I. Avaliação da certeza da evidência pelo GRADE dos estudos que avaliaram taxa de recidiva após tratamento de brucelose humana na população pediátrica com até 10 anos de idade  
|||**A**|**valiação da certeza**|**da evidência**|||**№ depacien**|**tes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>**ulfameto**|**Delineamento do**<br>**estudo**<br>**xazol-trimetoprima (**|**Risco de**<br>**viés**<br>**monoterapia**|**Inconsistência**<br>**)**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Antimicrobianos**|**qualquer**<br>**comparador**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|1|Série de casos|não<br><sup>a</sup>|não grave<sup>b</sup>|grave<sup>c</sup>|muito grave<sup>d</sup>|Nenhum|1/5 (0,40, 95% IC 0,10-<br>|-|-|-|⨁◯◯◯<br>|CRÍTICO|
|**ulfameto**|**xazol-trimetoprima +**|grave<br>**rifampicina**|||||0,80)||||Muito baixa||
|7|Série de casos|muito|muito grave<sup>f</sup>|grave<sup>c</sup>|muito grave<sup>d</sup>|Nenhum|46/581 (0,13, 95% IC|-|-|-|⨁◯◯◯|CRÍTICO|
|**ulfameto**|**xazol-trimetoprima +**|grave<sup>e</sup><br>**aminoglicos**|**ídeos**||||0,06-0,29)||||Muito baixa||
|5<br>**ifampici**|Série de casos<br>**na + aminoglicosídeo**<br>|muito<br>grave<sup>e</sup><br>**s**<br>|muito grave<sup>f</sup><br>|muito grave<sup>g</sup>|muito grave<sup>d</sup><br>|Nenhum<br>|9/85 (0,02, 95% IC<br>0,00-0,49)<br>|-|-|-|⨁◯◯◯<br>Muito baixa<br>|CRÍTICO<br>|
|1|Série de casos|grave<sup>h</sup>|não grave<sup>b</sup>|grave<sup>c</sup>|muito grave<sup>d</sup>|Nenhum|1/5 (0,20, 95% IC 0,03-<br>|-|-|-|⨁◯◯◯|CRÍTICO|
||||||||069||||Mi bi||
|**ulfameto**|**xazol-trimetoprima +**|**rifampicina**|**+ aminoglicosídeos**<br>|**(Terapia tripla)**|||,)||||uto axa||
|1|Série de casos|não<br>grave<sup>a</sup>|não grave<sup>b</sup>|grave<sup>c</sup>|muito grave<sup>d</sup>|Nenhum|4/43 (0,09, 95% IC<br>0,04-0,22)|-|-|-|⨁◯◯◯<br>Muito baixa|CRÍTICO|

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Avaliação do Risco de Viés e Certeza da Evidência:** -->
**Sulfametoxazol-trimetoprima + rifampicina + aminoglicosídeos (Terapia tripla)**  
Explicações:  
a. O risco de viés foi julgado como não grave, considerando aplicação da ferramenta JBI.  
b. Uma vez que a medida sumária provém de um estudo, a heterogeneidade foi considerada não grave.  
c. Considerou-se grave pela ausência de comparador, gerando evidência indireta nas análises em crianças.  
d. Considerou-se muito grave devido ao amplo intervalo de confiança encontrado na sumarização das taxas de recidiva.  
160  
- e. O risco de viés foi julgado como muito grave, considerando aplicação da ferramenta JBI. Além disso, um estudo ou mais apresentou risco de viés  
- muito alto.  
- f. Elevada heterogeneidade identificada na sumarização dos estudos.  
- g. Considerou-se muito grave pela ausência de comparador, gerando evidência indireta nas análises em crianças. Além disso, foi sumarizado todos os  
- medicamentos pertencentes à classe de aminoglicosídeos, não se fazendo distinção entre eles.  
- h. O risco de viés foi julgado como grave, considerando aplicação da ferramenta JBI.  
161

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Formulação de recomendações pelo método GRADE (** **_Evidence to decision table - EtD_ )** -->
Apresenta-se o processo de formulação de recomendações por meio de um painel de especialistas conduzido em outubro de 2023. Nesse painel foram formuladas recomendações sobre o uso dos esquemas terapêuticos para o tratamento da brucelose humana em crianças, baseando-se nas contribuições do painel de especialistas e apoiado pela síntese de evidências realizada pelo grupo elaborador.  
A **Tabela J** apresenta o processo de tomada de decisão sobre o uso do sulfametoxazol + trimetropima + rifampicina para o tratamento da brucelose humana em crianças menores de 10 anos, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
Tabela J. Processo de tomada de decisão referente ao uso do sulfametoxazol + trimetropima + rifampicina para o tratamento da brucelose humana em crianças menores de 10 anos  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Efeitos<br>desejáveis|Moderado|A taxa de recidiva da doença é relativamente baixa para<br>todas as combinações avaliadas.<br>Esses resultados referem-se à forma clínica dominante<br>aguda encontrada na maioria dos estudos.<br>Sulfametoxazol-trimetoprima + rifampicina: taxa de cura<br>92,3% (Roushan et al., 2006, ensaio clínico)<br>Não foi possível extrair dos estudos o nível de gravidade<br>da doença. Porém alguns estudos (Çıraklı et al., 2015, Shen<br>et al., 2008, 2015, Bosilkovski et al., Tsolia et al., 2002;<br>Zamani<br>et<br>al.,<br>2011)<br>relataram<br>a<br>adição<br>de<br>aminoglicosídeos à terapia dupla em pacientes com<br>envolvimento osteoarticular e/ougraves.|
|Efeitos<br>indesejáveis|Moderado|Sulfametoxazo + trimetoprima: 1,9% desenvolveram<br>erupção cutânea alérgica (1 paciente- Çıraklı et al., 2015)<br>Galanakis et al., 1995, relataram que o tratamento foi bem<br>tolerado e que os pacientes não desenvolveram efeitos<br>adversos, porém a duração de tratamento foi de apenas 3<br>semanas.<br>rifampicina pode causar náuseas e vômitos, o que pode<br>inviabilizar o tratamento pela via oral (El-Amin et al.,<br>2001)<br>sulfametoxazol-trimetoprima<br>+<br>rifampicina:<br>1,75%<br>desenvolveram hepatite induzida por tratamento (Nabi et<br>al., 1992)<br>Aminoglicosideos:<br>Nefrotoxicidade, neurotoxicidade e ototoxicidade, além da<br>suavia de administração injetável.|
|Certeza da<br>evidência:|Muito baixa|GRADE: certeza da evidência muito baixa para todas as<br>comparações<br>Não houve argumentopara alterar a certeza da evidência.|
|Balanço de<br>efeitos|Favorece a<br>intervenção|162<br>A taxa de recidiva é baixa e eventos adversos em geral são<br>leves e em baixa frequência.|  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|||Não é possível distinguir a eficácia comparativa em<br>relação aos tratamentos, sendo que todos mostraram uma<br>resposta adequada da taxa de recidiva (RS com meta-<br>análise).<br>Considerando a sintomatologia da doença, os benefícios de<br>tratar com o esquema proposto são maiores que os riscos<br>identificados na literatura.<br>Votação: Houve divergência no voto do painel (favorece =<br>3,não há diferença =2)|
|Recursos<br>necessários:|Custos e<br>economias<br>insignificantes|Sulfametoxazol-trimetoprima +rifampicina por 42 dias<br>R$61,96 a R$80,47 - custo, assumindo peso médio das<br>crianças igual a 20 quilos e 42 dias de tratamento (9 frascos<br>sulfametoxazol+trimetropima)<br>Painel considerou o custo como custo irrisório<br>Votação5de5|
|Equidade:|Provavelmente<br>aumentou|Padronização de um esquema de tratamento oral com<br>posologia facilitada em qualquer localidade.<br>Rifampicina não é amplamente disponibilizada, compra<br>centralizada pelo Ministério da Saúde, podendo ser esse<br>contexto uma barreira ao acesso.<br>Avaliar o uso de mais de uma alternativa, melhora a<br>equidade no sentido de permitir tratamento oral em<br>pacientes cuja internação seria dificultada, ou em permitir<br>o tratamento injetável em pacientes com baixa adesão ou<br>intolerantes ao tratamento oral.<br>Votação: 4 de 5|
|Aceitabilidade:|Sim|PACIENTE SMZ+TMP antimicrobiano usado com<br>frequência na população pediátrica (suspensão oral 2x ao<br>dia)<br>GESTOR E PROFISSIONAL<br>Não é uma tecnologia complexa de ser adotada e não<br>requer grandes mudanças em termos organizacionais ou<br>estruturais dos serviços de saúde<br>O uso de aminoglicosídeos (injetável)<br>(aceitabilidade de pacientes e profissionais)<br>Acondicionamento do medicamento (paciente e serviço de<br>saúde)<br>Experiência do especialista relatada sobre perfil de evento<br>adverso mais grave para aminoglicosídeos.<br>Experiência de outro especialista relatada sobre a<br>preferência para uso dos aminoglicosídeos de 7-14 dias,<br>sem problemas com eventos adversos.<br>Votação 4/5(sim)|
|Viabilidade de<br>implementação:|Sim|Já está disponível na RENAME (SMZ-TMX- CBAF e<br>rifampicina no CESAF) e são fornecidos pelo SUS.<br>Votação5/5 (sim)|  
Fonte: Autoria própria.  
**Recomendação:**  
163  
Recomendação a favor condicional ao uso de sulfametoxazol-trimetropim +rifampicina no tratamento de crianças menores de 10 anos diagnosticadas com brucelose devido à baixa certeza da evidência.  
Considerações para subgrupos: Não houve definições de grupo.  
Considerações para implementação: discutir medidas para melhorar o acesso à rifampicina.  
Monitoramento e avaliação: Monitorar resistência antimicrobiana e toxicidade  
Prioridades em pesquisa: Dados demográficos acurados, desfechos em estudos bem delineados.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **QUESTÃO 4: Qual é a eficácia e a segurança de esquemas de antimicrobianos para o tratamento da brucelose humana em gestantes?** -->
**Recomendação:** Condicional a favor para o uso sulfametoxazol-trimetoprima + rifampicina para o tratamento da brucelose humana em gestantes (certeza da evidência muito baixa).  
A resposta dessa pergunta foi obtida a partir de uma estratégia ampla que incluiu a elaboração de uma revisão sistemática da literatura sobre o tratamento da brucelose humana em gestantes e a seguinte pergunta de pesquisa: Qual é a eficácia e segurança das estratégias terapêuticas com antimicrobianos para o tratamento da brucelose humana em gestantes?  
A estrutura PICO para esta pergunta foi:  
**População:** Casos confirmados de brucelose humana em gestantes.  
**Intervenção:** Monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana.  
**Comparador:** Monoterapia ou terapia combinada de antimicrobianos indicados para o tratamento da brucelose humana, placebo ou nenhum tratamento.  
**Desfechos:** Insucesso da terapia (falha terapêutica e/ou recidiva), tempo para a defervescência, eventos adversos gerais e eventos adversos obstétricos.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Métodos e Resultados da Busca** -->
Foi realizada a busca sistematizada da literatura nas bases de dados _Medline_ (via _Pubmed_ ), _Embase_ , _Cochrane Library_ e LILACS (via BVS) até a data 11 de maio de 2023 (atualizada até 12 de dezembro de 2023). As estratégias de busca para cada base estão descritas no **Quadro CC** .  
Quadro CC. Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre o tratamento da brucelose humana em gestantes  
164  
|**Bases**<br>**de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>(via<br>Pubmed)|**População:**<br>**#1**(Brucellosis[MeSH Terms]) OR (Brucellosis) OR (Brucelloses) OR (Malta Fever)<br>OR (Fever, Malta) OR (Gibraltar Fever) OR (Fever, Gibraltar) OR (Rock Fever) OR<br>(Fever, Rock) OR (Cyprus Fever) OR (Fever, Cyprus) OR (Brucella Infection) OR<br>(Brucella Infections) OR (Infection, Brucella) OR (Undulant Fever) OR (Fever,<br>Undulant) OR (Brucella abortus) OR (Brucella canis) OR (Brucella melitensis) OR<br>(Brucella ovis) OR (Brucella suis)<br>**População:**<br>**#2**"pregnan*"[All Fields]|471|
||**Intervenção:**<br>**#3**(therapeutics[MeSH Terms] OR antibacterial agents[MeSH Terms]) OR<br>(antibiotics[MeSH Terms]) OR (Therapeutics) OR (Therapeutic) OR (Therapy) OR<br>(Therapies) OR (Treatment) OR (Treatments) OR (Anti-Bacterial Agents) OR<br>(Agents, Anti-Bacterial) OR (Anti Bacterial Agents) OR (Antibacterial Agents) OR<br>(Agents, Antibacterial) OR (Antibacterial Agent) OR (Agent, Antibacterial) OR<br>(Anti-Bacterial Compounds) OR (Anti Bacterial Compounds) OR (Compounds,<br>Anti-Bacterial) OR (Anti-Bacterial Agent) OR (Agent, Anti-Bacterial) OR (Anti<br>Bacterial Agent) OR (Anti-Bacterial Compound) OR (Anti Bacterial Compound) OR<br>(Compound, Anti-Bacterial) OR (Bacteriocidal Agents) OR (Agents, Bacteriocidal)<br>OR (Bacteriocidal Agent) OR (Agent, Bacteriocidal) OR (Bacteriocide) OR<br>(Bacteriocides) OR (Anti-Mycobacterial Agents) OR (Agents, Anti-Mycobacterial)<br>OR (Anti Mycobacterial Agents) OR (Anti-Mycobacterial Agent) OR (Agent, Anti-<br>Mycobacterial) OR (Anti Mycobacterial Agent) OR (Antimycobacterial Agent) OR<br>(Agent, Antimycobacterial) OR (Antimycobacterial Agents) OR (Agents,<br>Antimycobacterial)OR(Antibiotics)OR(Antibiotic)<br>**#4**#1 AND #2 AND #3||
|EMBASE|**População:**<br>**#1**('brucellosis'/exp OR 'brucella infection' OR 'brucella melitensis infection' OR<br>'malta fever' OR 'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by<br>brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR<br>'infection due to brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR<br>'brucella'/exp OR 'brucella' OR 'brucella contamination' OR 'brucella abortus'/exp OR<br>'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR<br>'brucella abortus sensitivity' OR 'brucella canis'/exp OR 'brucella melitensis'/exp OR<br>'brucella melitensis' OR 'micrococcus melitensis' OR 'brucella ovis'/exp OR 'brucella<br>ovis' OR 'brucella suis'/exp OR 'brucella melitensis biovar suis' OR 'brucella<br>melitensisbv. suis' OR 'brucella suis')<br>**População:**<br>**#2**pregnan*<br>**Intervenção:**<br>**#3**<br>'therapy' OR 'combination<br>therapy' OR 'disease<br>therapy' OR 'disease<br>treatment' OR 'diseases<br>treatment' OR 'disorder<br>treatment' OR 'disorders<br>treatment' OR 'efficacy,<br>therapeutic' OR 'illness<br>treatment' OR 'medical<br>therapy' OR 'medical<br>treatment' OR 'multiple<br>therapy' OR 'polytherapy' OR 'somatotherapy' OR 'therapeutic<br>action' OR 'therapeutic<br>efficacy' OR 'therapeutic<br>trial' OR 'therapeutic<br>trials' OR 'therapeutics' OR 'therapy,<br>medical' OR 'treatment<br>effectiveness' OR 'treatment efficacy' OR 'treatment,medical'<br>**#4**#1 AND #2 AND #3 AND [embase]/lim|175|
|Cochrane<br>Library|**População:**<br>**#1**MeSH descriptor: [Brucellosis] explode all trees<br>**População:**<br>**#2**‘brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta<br>fever' OR 'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by<br>brucella' OR 'infection by brucella melitensis' OR 'infection due to brucella' OR<br>'infection due to brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR<br>'brucella' OR 'brucella abortus' OR 'brucella abortus' OR 'bacterium abortus' OR<br>'brucella abortus bang bacteria' OR 'brucella abortus sensitivity' OR 'brucella<br>melitensis' OR 'brucella canis' OR 'brucella canis' OR 'brucella canidis' OR 'brucella<br>ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella melitensis biovar suis' OR<br>'brucella melitensisbv. suis' OR 'brucella suis''brucellosis' OR 'brucella infection' OR|27|  
165  
|**Bases**<br>**de**<br>**dados**|**Estratégia de busca**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||'brucella melitensis infection' OR 'malta fever' OR 'mediterranean fever (brucellosis)'<br>OR 'brucellosis' OR 'infection by brucella' OR 'infection by brucella melitensis' OR<br>'infection due to brucella' OR 'infection due to brucella melitensis' OR<br>'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella abortus' OR 'brucella<br>abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria' OR 'brucella<br>abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella canis' OR<br>'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR 'brucella<br>melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella suis'):ti,ab,kw<br>**População:**<br>**#3**(pregnan*):ti,ab,kw<br>**Intervenção:**<br>**#4**((('therapy' OR 'combination therapy' OR 'disease therapy' OR 'disease treatment'<br>OR 'diseases treatment' OR 'disorder treatment' OR 'disorders treatment' OR 'efficacy,<br>therapeutic' OR 'illness treatment' OR 'medical therapy' OR 'medical treatment' OR<br>'multiple therapy' OR 'polytherapy' OR 'somatotherapy' OR 'therapeutic action' OR<br>'therapeutic efficacy' OR 'therapeutic trial' OR 'therapeutic trials' OR 'therapeutics'<br>OR 'therapy, medical' OR 'treatment effectiveness' OR 'treatment efficacy' OR<br>'treatment, medical'))||
||**#5** (#1 OR #2)AND #3 AND #4||
|Lilacs (via<br>BVS)<br>**Total**|**População**<br>**#1**((((mh:(brucelose)) OR (brucelose) OR (mh:(brucellosis)) OR (brucellosis) OR<br>(mh:(brucelosis)) OR (brucelosis) OR (febre ondulante) OR (febre de malta) OR<br>(infecçãopor brucella) OR (mh:(brucella)) OR (brucella) OR (mh:(brucella abortus))<br>OR (brucella abortus) OR (bacterium abortus) OR (mh:(brucella canis )) OR (brucella<br>canis ) OR (mh:(brucella melitensis )) OR (brucella melitensis ) OR (micrococcus<br>melitensis) OR (mh:(brucella ovis)) OR (brucella ovis) OR (mh:(brucella suis)) OR<br>(brucella suis)) ))<br>**População**<br>**#2**(pregnan*)<br>**Intervenção:**<br>**#3**((((therapeutics OR therapeutic OR therapy OR therapies OR treatment OR<br>treatments OR (anti-bacterial agents) OR (agents, anti-bacterial) OR (anti bacterial<br>agents) OR (antibacterial agents) OR (agents, antibacterial) OR (antibacterial agent)<br>OR (agent, antibacterial) OR (anti-bacterial compounds) OR (anti bacterial<br>compounds) OR (compounds, anti-bacterial) OR (anti-bacterial agent) OR (agent,<br>anti-bacterial) OR (anti bacterial agent) OR (anti-bacterial compound) OR (anti<br>bacterial compound) OR (compound, anti-bacterial) OR (bacteriocidal agents) OR<br>(agents, bacteriocidal) OR (bacteriocidal agent) OR (agent, bacteriocidal) OR<br>(bacteriocide) OR (bacteriocides) OR (anti-mycobacterial agents) OR (agents, anti-<br>mycobacterial) OR (anti mycobacterial agents) OR (anti-mycobacterial agent) OR<br>(agent, anti-mycobacterial) OR (anti mycobacterial agent) OR (antimycobacterial<br>agent) OR (agent, antimycobacterial) OR (antimycobacterial agents) OR (agents,<br>antimycobacterial) OR (antibiotics) OR (antibiotic))) ))<br>**Bases disponíveis após a retirada do MEDLINE do filtro da BVS:**<br>**#4**(db:("LILACS" OR "BINACIS" OR "IBECS"))<br>**#5**#1 AND #2 AND #3 AND #4|11<br>**684**|  
Busca realizada em 11/05/23 (atualizada até 12 de dezembro de 2023).  
Todos os estudos identificados nas bases foram exportados para o programa _Mendeley_<sup>261</sup> , onde as duplicatas foram excluídas. Em seguida, as referências foram enviadas para o aplicativo _Rayyan_<sup>262</sup> para gerenciamento em relação à triagem de títulos e resumos no escopo da revisão. Os artigos selecionados foram lidos na íntegra e analisados de acordo com os critérios de elegibilidade.  
166  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de inclusão:** -->
(a) Tipos de participantes: Mulheres gestantes com diagnóstico confirmado de brucelose humana.  
(b) Tipo de intervenção: Qualquer intervenção terapêutica medicamentosa, placebo ou nenhuma intervenção.  
(c) Delineamento dos estudos: Ensaios clínicos randomizados, estudos observacionais ou série de casos.  
(d) Desfechos: Insucesso da terapia (falha terapêutica e/ou recidiva), tempo para a defervescência, eventos adversos gerais e eventos adversos obstétricos.  
(e) Idioma: Estudos publicados em inglês, espanhol e português.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de exclusão** -->
(a) Tipos de participantes: Pacientes com manifestações secundárias da brucelose humana.  
(b) Tipos de estudos: Publicações com informações duplicadas, mantendo-se apenas a primeira publicação original; Estudos com menos de 5 participantes.  
Adicionalmente, foram realizadas buscas na literatura cinzenta em duas plataformas: a base Google Acadêmico, com as principais palavras-chave definidas na estratégia de busca, e a base de dados _Opengrey.eu_ , um sistema de Informação sobre Literatura Cinzenta da Europa. Além disso, foram realizadas buscas na plataforma _ClinicalTrials.gov_ , fornecido pela Biblioteca Nacional de Medicina dos EUA, para identificação de estudos registrados e em andamento. A triagem dos documentos resultantes destas buscas adicionais foi operacionalizada com o apoio de uma planilha Excel®️.  
A busca identificou 684 artigos nas bases de dados. Após triagem e processo de seleção com base nos critérios de elegibilidade, 6 manuscritos foram incluídos nesta análise descritiva<sup>91–</sup> 93,263–265. Todo o processo de seleção e os motivos das exclusões estão resumidos em um fluxograma PRISMA ( **Figura V** ).  
167  
<!-- Start of picture text -->
Identificação de estudos por meio de bases de dados e registros<br>Registros identificados por meio de:<br>MEDLINE (n=471)<br>EMBASE (n=175)<br>COCHRANE (n=27)  Registros duplicados removidos<br>BVS (n=11)  (n=97)<br>Literatura cinzenta (n=0)<br>Lista de referência (n=0)<br>Total: (n = 684)<br>Registros excluídos<br>Registros em triagem<br>(n =566)<br>(n =587)<br>Registros não recuperados<br>Publicações pesquisadas (n =21)<br>(n = 2)<br>Publicações avaliadas para  Registros excluídos (n = 13):<br>elegibilidade   -  Falta  de  resultado  por<br>(n = 19)  intervenção (n = 2)<br>-  Participantes repetidos (n=1)<br>-  Outro idioma (n= 5)<br>-  Pequenas séries (menos de<br>5 pacientes tratados) (n= 3)<br>-  Desenho do estudo (revisão<br>de literatura) (n = 2)<br>Estudos incluídos na revisão<br>(n = 6)<br>Relatos dos estudos incluídos<br>(n = 6)<br>Identificação<br>Seleção<br>Incluso<br><!-- End of picture text -->  
Figura V. Fluxograma de seleção dos estudos incluídos no tratamento da Brucelose Humana em gestantes  
Fonte: Adaptado de Page et al<sup>151</sup>

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise e Apresentação dos Resultados** -->
As características dos estudos incluídos, compreendendo características metodológicas, dos participantes e das intervenções, estão sumarizadas nos **Quadro DD** e **Quadro EE.**  
168

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro DD. Principais características metodológicas dos estudos sobre o tratamento da brucelose humana em gestantes -->
|**Autor, ano**|**País (n)**|**Delineamento**|**Período de**<br>**estudo**|**Tempo de**<br>**seguimento**|**Critério de diagnóstico**|**Critérios de inclusão**|
|---|---|---|---|---|---|---|
|**Bosilkovski et al.,**<br>**2020**|República da<br>Macedônia (5)|Série de casos|1995 a 2009|6-36 meses|Sinais e sintomas clínicos, análises laboratoriais<br>(Hb 120 g/L, RBC 4100x1012/L, leucócitos<br>4,6x109/L, Ne 62%, Pl 200x1012/L, ALT/AST<br>22/18 U/L, creatinina 64 μ mol /L, VHS 60<br>mm/h, PCR 64 mg/L, cultura de urina negativa,<br>teste Rosa Bengala positivo, STA 1/1280, teste de<br>_Brucella Coombs_1/1280).|Nenhuma das pacientes<br>apresentadas tinha história<br>prévia de brucelose, doenças<br>venéreas crônicas, gravidez<br>patológica ou aborto<br>espontâneo.|
|**Inan et al., 2019**|Turquia (242)|Observacional<br>retrospectivo<br>multicêntrico|2002 a 2015|Gravidez + período<br>neonatal e após<br>conclusão da terapia|Confirmação clínica e laboratorial, STA (≥<br>1:160) ou RBC e/ou isolamento de_Brucella_no<br>sangue humano e /ou placenta e feto abortado.|Gestantes com brucelose com<br>ou sem parto<br>recente/aborto/MFI.|
|**Gulsun et al., 2011**|Turquia (39)|Observacional<br>prospectivo|2003 a 2010|Gravidez + período<br>neonatal e durante<br>pelo menos seis meses<br>após o término da<br>terapia|STA teste, teste de_Coombs anti-Brucella_e/ou<br>hemocultura em mulheres grávidas cujos achados<br>clínicos sugeriam brucelose.|Gestantes saudáveis como<br>grupo controle e gestantes que<br>tiveram brucelose.|
|**Roushan**<br>**et**<br>**al.,**<br>**2011**|Irã (19)|Série de casos|2000 a 2010|24 meses|Título de STA ≥1/160 e título de 2-<br>mercaptoetanol (2ME) ≥1/80 com achados<br>clínicos compatíveis.|NR|
|**Khan et al., 2001**|Arábia<br>Saudita (92)|Observacional<br>retrospectivo|1983 a 1995|NR|Características clínicas compatíveis e título de<br>aglutinina sérica ≥1:320 ou resultado de<br>hemoculturapositivo.|NR|
|**Seoud et al., 1991**|Líbano (6)|Série de casos|1985 a 1987|8 meses pós-parto|Sinais e sintomas clínicos, teste sorológico<br>utilizando teste em tubo de aglutinação direta e<br>indireta (título direto >1:80 e título indireto<br>>1:160). Todas as culturas eram realizadas em<br>mídia especial.|Mulheres grávidas com<br>brucelose.|  
Legenda: NR: não relatado, STA: _Standard Tube Agglutination_ teste. Hb: hemoglobina. RBC: contagem de eritrócitos. PL: plaquetas. Ne: neutrófilos. AST: aspartato aminotransferase. ALT: alanina aminotransferase. VHS: velocidade de hemossedimentação. PCR: Reação em Cadeia da Polimerase. U: unidade. L: litros. mg: miligrama. mm/h: milímetros por hora, MFI: morte fetal intrauterina.  
Quadro EEJ. Características da população gestante incluída nos estudos sobre o tratamento da brucelose humana  
169  
|**Autor, ano**|**Idade**<br>**média±DP**<br>**(intervalo) anos**|**Manifestação clínica (%)**|**Forma clínica**|**Espécie de****_Brucella_**|**Duração dos sintomas**|
|---|---|---|---|---|---|
|**Bosilkovski et al.,**<br>**2020**|25,8 ± 3,2 (20 –<br>29)|Caso 1 (lombalgia, mal-estar, sudorese, dor de cabeça e<br>temperatura de 38,4ºC).<br>Caso 2 (temperatura de 39ºC, febre, mal-estar, artralgias,<br>sudorese).<br>Caso 3 (mal-estar, dor no quadril direito, temperatura de<br>39ºC, sudorese noturna, diminuição do apetite e dor de<br>cabeça).<br>Caso 4 (sudorese, mal-estar, cefaleia, diminuição do apetite,<br>artralgias, náuseas e vómitos há 3 semanas).<br>Caso 5 (temperatura de 38,2ºC, sudorese, mal-estar, cefaleia,<br>artralgia e artrite doquadril esquerdo).|NR|NR|Caso 1: duas semanas até o<br>diagnóstico de brucelose.<br>Caso 2: Seis semanas antes da<br>admissão hospitalar<br>Caso 3: Dois meses antes da<br>internação hospitalar<br>Caso 4: 3 semanas<br>Caso 5: Três meses antes de<br>sua internação no hospital|
|**Inan et al.,**<br>**2019**|28,8±6,28 (17–50)|Fraqueza (95,4%), suores noturnos (89,6%), artralgia<br>(88,8%), febre (83,7%), sangramento vaginal (9,1%), dor na<br>virilha (23,5%).|Aguda: 230<br>(95,0%)<br>Subaguda: 7<br>(2,9%)<br>Crônica: 5 (2,1%)|_Brucella sp_. (41,8%)<br>_B. melitensis_(64,2%)|Média de 15 (variação de 10 a<br>21) dias|
|**Gulsun et al., 2011**|28.07 (20 - 40)|Artralgia (92,3%), febre (76,9%), mialgia (71,7%),<br>hepatomegalia (28,2%) e esplenomegalia (25,6%).|Aguda: 30<br>Subaguda: 2<br>Recorrência: 4|_B. melitensis (NR)_|NR|
|**Roushan**<br>**et**<br>**al.,**<br>**2011**|25,0±4,62|Sudorese (57,8%), Febre (42,1%), Dor nas costas ou<br>generalizada(36,8%),Artralgia ou Mialgia(36,8%)|NR|_B. melitensis (4)_|NR|
|**Khan et al., 2001**|26,9 (16 – 47)|Febre (41,3%)|Aguda: 92 (100%)|_B. melitensis (16)_<br>_B. abortus (1)_<br>_Não identificado (5)_|NR|
|**Seoud et al., 1991**|24,5 (18 – 33)|Febre (100%); mal-estar generalizado (83,3%); fadiga<br>(83,3%); calafrios (66,6%); sudorese (66,6%); dor lombar<br>(66,6%); artralgia (50%); mialgia (50%); cefaleia (33,3%);<br>hepatoesplenomegalia (33,3%)|NR|_B. melitensis (3)_|Febre – Média 3,5 (±3,0)<br>(variação de 2 a 12 semanas)|  
Legenda: NR: não relatado.  
170  
Esta revisão incluiu 6 estudos, quatro foram relatos retrospectivos do tratamento da brucelose humana em gestantes<sup>91,93,263,264</sup> , dois estudos prospectivos<sup>92,265</sup> , publicados entre 1991 e 2020. Os estudos foram desenvolvidos na República da Macedônia<sup>263</sup> , na Turquia<sup>91, 265</sup> , no Líbano<sup>264</sup> , na Arábia Saudita<sup>93</sup> e no Irã<sup>92</sup> . Ao todo, foram incluídas 403 gestantes, com uma variação amostral variando de 5 a 242 participantes nos estudos.  
Os estudos descrevem a utilização de diferentes esquemas terapêuticos, variando entre a mono, dupla e a tripla terapia. O esquema mais utilizado foi a combinação de SMX + TMP associado a rifampicina prescrita para 114 gestantes<sup>263</sup> , seguida de ceftriaxona + rifampicina prescrita para 92 gestantes; neste caso, a terapia foi utilizada em apenas um estudo<sup>91</sup> . Bosilkovski et al.<sup>263</sup> incluíram doxiciclina ao esquema contendo SMX + TMP associado a rifampicina após aborto ou nascimento do bebê, enquanto nenhum dos demais estudos mencionou esta recomendação. O esquema triplo contendo SMX + TMP associado a ceftriaxona e a rifampicina foi prescrito para 47 gestantes<sup>91</sup> . A recidiva da doença foi um desfecho relatado em quatro estudos, tendo ocorrido em 10 participantes (3%) após o tratamento e desaparecimento dos sinais e sintomas da doença. Nem todos os estudos associaram este desfecho à terapia utilizada no tratamento das gestantes.  
O tempo para a defervescência foi um desfecho encontrado em apenas um estudo<sup>263</sup> , variando de dois a quatro dias após tratamento com SMX + TMP associado a rifampicina. Nenhum dos estudos relatou o perfil de segurança geral dos esquemas terapêuticos nas gestantes avaliadas. Inan et al. (2019)<sup>91</sup> destacou ausência de diferença significativa entre as taxas de eventos adversos obstétricos entre gestantes tratadas com SMX + TMP associado a rifampicina vs. ceftriaxona associado a rifampicina (13,9% vs. 13,0%, p = 0.849). Não foi possível realizar comparações entre o desempenho de diferentes esquemas terapêuticos em um mesmo estudo, visto que os resultados foram descritos de forma agregada<sup>91</sup> ou descritos para apenas alguns grupos de participantes<sup>265</sup> ou ainda, incluíram um único participante por esquema terapêutico 263,264.  
Desfechos relacionados à gestação foram relatados em todos os estudos. O desfecho aborto foi observado em todos os estudos, com 94 gestantes afetadas (23,3%). Ao todo, estudos relataram 20 nascimentos relacionados a partos pré-termo<sup>91,265</sup> com 10 recém-nascidos apresentando baixo peso ao nascer<sup>265</sup> . Os partos a termo foram relatados em 65 recémnascidos<sup>92,93,265</sup> .  
No estudo conduzido por Khan et al. (2011)<sup>93</sup> , foram incluídas 92 gestantes, sendo que apenas 41 delas receberam tratamento com antimicrobianos para a brucelose humana. Este tratamento pré-parto apresentou efeito protetor significativo contra a ocorrência de aborto quando comparado ao tratamento inadequado ou a nenhum tratamento (RR: 0,14; IC95%, 0,06-0,37; p > 0,001). No entanto, a incidência de aborto entre 23 pacientes que receberam tratamento com SMX + TMP em monoterapia não foi significativamente diferente daquela de 17 pacientes que receberam tratamento com uma combinação de SMX + TMP associado a rifampicina (P = 0,6). O **Quadro FF** relata os principais resultados dos estudos incluídos nesta revisão.  
Embora os diferentes desfechos, definições adotadas e desenhos dos estudos propostos inviabilizem agrupamentos e comparações para a maioria dos desfechos de interesse, foi possível avaliar a taxa de eventos adversos obstétricos especialmente para a combinação SMX + TMP associado a rifampicina que foi de 16% (IC95% 0,08 a 0,30)<sup>266–268</sup> . Para os demais esquemas, o resultado representa a perspectiva de apenas um estudo.  
171

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro FF. Resultados do tratamento da brucelose humana em gestantes a partir de estudos incluídos na revisão. -->
|**Autor, ano**|**Intervenções (n)**|**Duração do**<br>**tratamento**<br>**(dias)**|**Tempo de**<br>**seguimento**<br>**(meses)**|**Evolução clínica (n/n**<br>**tratado)**|**Definição de**<br>**recidiva**|**Desfechos obstétricos (n/n tratado)**|
|---|---|---|---|---|---|---|
|**Bosilkovski et**<br>**al., 2020**|SMX-TMP + RF + DX (1) **|28|36|Recorrência (1/1)|NR|Sangramento vaginal e aborto espontâneo na 13ª<br>semana de gestação (durante tratamento com SMX-<br>TMP + RF) (1/1)|
||SMX-TMP + RF (1)|45|12|Defervescência no<br>segundo dia de<br>tratamento(1/1)|NR|Ausência de movimentos fetais na 28ª semana de<br>gestação (3 meses após o término do tratamento<br>antibrucelar) (1/1)|
||SMX-TMP + RF + DX (1) **|28|19|Defervescência no<br>terceiro dia de<br>tratamento,cura(1/1)|NR|Nascimento prematuro na 32ª semana de gestação sem<br>sintomas/sinais e_Brucellacapt_negativo (1/1)|
||SMX-TMP + RF (1)|45|12|Curar sem recorrência<br>(1/1)|NR|Nascimento prematuro na 32ª semana gestacional, 6<br>semanas após término do tratamento antibrucelar. Rosa<br>Bengala inicial positivo em bebês e negativo após 9<br>meses de nascimento (1/1)|
||SMX-TMP + RF (1)|45|6|Defervescência no<br>quarto dia de<br>tratamento, cura sem<br>recidiva (1/1)|NR|Parto vaginal espontâneo na 39ª semana de gestação, 3<br>semanas após o término do tratamento antibrucelar. O<br>bebê apresentou resultados positivos nos testes<br>sorológicos nos primeiros 6 meses, após os quais<br>foram negativos (1/1)|
|**Inan et al., 2019**|CFX +RF (92)<br>SMX-TMP + RF (79)<br>SMX-TMP + CFX + RF (47)<br>SMX-TMP + GT/STP (6)<br>CFX + SMX-TMP (3)<br>RF + DX (3)<br>RF + SMX-TMP + GT (3)<br>RF + GT (1)<br>RF+DX+GT (1)<br>CFX (5)<br>CFM (2)|42 – 56 (ou<br>até resolução)|NR|Recorrência<br>DX + RF (1/3)*|Reaparecimento<br>de sinais<br>clínicos e de<br>brucelose após<br>terapia bem-<br>sucedida e<br>cultura positiva<br>ou aumento no<br>título de<br>anticorpos na<br>ausência de<br>sintomas de<br>exposição a<br>_Brucella._|Complicações obstétricas<sup>b</sup><br>(CFX + RF 12/92; SMX-TMP + RF 11/79; SMX-TMP<br>+ CFX + RF 4/47)<br>Mortalidade materna e neonatal ou sequelas pertinentes<br>nos recém-nascidos (0/242)|  
172  
|**Autor, ano**|**Intervenções (n)**|**Duração do**<br>**tratamento**<br>**(dias)**|**Tempo de**<br>**seguimento**<br>**(meses)**|**Evolução clínica (n/n**<br>**tratado)**|**Definição de**<br>**recidiva**|**Desfechos obstétricos (n/n tratado)**|
|---|---|---|---|---|---|---|
|**Gulsun et al.,**<br>**2011**|SMX-TMP (NR)<br>SMX-TMP + RF (NR)<br>CFX + RF (NR)<br>RF (NR)|42|6|Recorrência<br>SMX-TMP (7/NR)|Anteriormente<br>diagnosticado<br>com brucelose e<br>curado<br>adequadamente,<br>mas os<br>resultados<br>clínicos e<br>laboratoriais<br>tornaram-se<br>novamente<br>positivos.|Nascimentos a termo (16), baixo peso ao nascer (9),<br>partos prematuros (6), aborto no primeiro trimestre<br>(1)*|
|**Roushan et al.,**<br>**2011**|SMX-TMP + RF (13)<br>GT + DX (4)<br>SMX-TMP + DX (1)<br>DX + RF (1)|45 a 60|24|NR|NR|Entregas a prazo (SMX-TMP + RF 8/13)<br>Aborto espontâneo (SMX-TMP + RF 5/13; GT + DX<br>4/4; SMX-TMP + DX 1/1; DX + RF 1/1)|
|**Khan et al., 2001**|SMX-TMP (23)<br>SMX-TMP + RF (17)<br>RF (1)|Pelo menos 4<br>semanas|NR|NR|NR|Aborto espontâneo ou morte fetal (SMX-TMP 3/23;<br>SMX-TMP + RF 1/17; RF 0/1)<br>Entregas normais (SMX-TMP 19/23; SMX-TMP + RF<br>16/17; RF 1/1)|
|**Seoud et al., 1991**|SMX-TMP + CFT(1)|42|NR|Recorrência(1/1)|NR|Um aborto terapêutico na 10ª semana degravidez(1/1)|
||SMX-TMP + RF(2)|35 a 42|NR|Recorrência(0/2)|NR|Parto vaginal normal(1/1)|
||NR|NR|NR|Recorrência (0/1)|NR|Ruptura prematura de membranas, corioamnionite,<br>cesariana(1/1)|
||SMX-TMP + TE(2)|21 a 28|NR|Recorrência(0/2)|NR|Aborto terapêutico na 12ª semana degestação(1/1)|  
a Falha terapêutica foi considerada como falha terapêutica isolada ou falha terapêutica + recidiva.  
bConsiderou-se complicação obstétrica a presença de pelo menos um dos seguintes eventos: ameaça de aborto, aborto espontâneo, PROM, IFD, parto prematuro, quaisquer complicações ou anomalias no recém-nascido e no bebê, ou morte materna após o parto de uma gestante com brucelose.  
- *Resultados globais sem distinção por intervenção.  
**Adicionada doxiciclina ao tratamento após aborto espontâneo ou nascimento do bebê.  
- ***O estudo não apresenta os resultados por intervenção.  
Legenda: DX: doxiciclina; RF: rifampicina; STP: estreptomicina; GT: gentamicina; CFX: ceftriaxona; SMX-TMP: sulfametoxazol-trimetoprima; TE: Tetraciclina, CFM: cefotaxima, CFT: cefoxitina, NR: não relatado.  
173  
A avaliação do risco de viés nesta revisão utilizou as ferramentas da JBI para avaliação de séries de casos e estudos de coorte. Ressalta-se que embora o estudo de Inan et, al.<sup>266</sup> tenha sido classificado como uma coorte transversal retrospectiva multicêntrica pelos autores, o objetivo principal do estudo foi descrever o perfil epidemiológico das gestantes de alguns serviços sem a inclusão de um grupo de comparação, baseado na prevalência de casos em alguns serviços, similar a descrição de uma série de casos coletada retrospectivamente, motivo pelo qual foi utilizada na avaliação do risco de viés o _checklist_ para estudos de série de casos. Os resultados da avaliação do risco de viés dos estudos incluídos nesta revisão estão apresentados nos **Quadro GG** e **Quadro HH** Quadro, de acordo com a ferramenta utilizada.  
174

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro GG. Avaliação do risco de viés pela Ferramenta JBI _Critical Appraisal Checklist for Case Series._ -->
||**Bosilkovski et al.,**<br>**2020**|**Inan et al.,**<br>**2019**|**Roushan et al.,**<br>**2011**|**Khan et al.,**<br>**2001**|**Seoud et al.,**<br>**1991**|
|---|---|---|---|---|---|
|Havia critérios claros para inclusão na casuística?|**S**|**S**|**N**|**N**|**S**|
|A condição foi medida de forma padronizada e confiável para todos<br>os participantes incluídos na série de casos?|**U**|**U**|**S**|**S**|**S**|
|Foram utilizados métodos válidos para identificação da condição<br>para todos os participantes incluídos na casuística?|**S**|**S**|**S**|**S**|**S**|
|A casuística teve inclusão consecutiva de participantes?|**U**|**S**|**S**|**S**|**U**|
|A casuística teve inclusão completa dos participantes?|**S**|**S**|**S**|**S**|**S**|
|Houve relato claro dos dados demográficos dos participantes do<br>estudo?|**S**|**S**|**S**<br>|**S**|**S**|
|Houve relato claro das informações clínicas dos participantes?|**S**|**S**|**S**|**S**|**S**|
|Os desfechos ou resultados de seguimento dos casos foram<br>claramente relatados?|**S**|**S**|**S**|**S**|**N**|
|Houve<br>relato<br>claro<br>das<br>informações<br>demográficas<br>do(s)<br>sítio(s)/clínica(s) apresentado(s)?|**U**|**S**|**S**|**N**|**S**|
|A análise estatística foi adequada?|**NA**|**S**|**NA**|**S**|**S**|  
Legenda: S: Sim, N: Não, U: Obscuro, NA: Não aplicável.  
175  
Quadro HH. Risco de viés do estudo observacional prospectivo, avaliado pela ferramenta JBI _checklist for Cohort Studies._  
|**Estudo**<br>**1**<br>**2**|**3**|**4**<br>**5**<br>**6**|**7**|**8**<br>**9**<br>**10**|**11**|**Total**<br>**(nº de****)**|
|---|---|---|---|---|---|---|
|Gulson et al., 2011<br><br>||<br>X<br>||<br><br>NA|ü|9/10|
|Respostas aos critérios:: Sim; X= Não; ?: Não<br>1. Os dois grupos eram semelhantes e foram recr<br>2. As exposições foram medidas de forma semelh<br>3. A exposição foi medida de forma válida e conf<br>4. Foram identificados fatores de confusão?<br>5. Foram declaradas estratégias para lidar com fat<br>6. Os grupos/participantes estavam livres do desf<br>7. Os resultados foram medidos de forma válida e<br>8. O tempo de acompanhamento foi relatado e su<br>9. O acompanhamento foi completo e, caso contr<br>10. Foram utilizadas estratégias para abordar o ac<br>11. Foi utilizada análise estatística adequada?<br>Fonte: Elaboração própria.|claro; NA<br>utados na<br>ante para<br>iável?<br>ores de c<br>echo no i<br>confiáve<br>ficiente p<br>ário, os m<br>ompanha|: Não aplicável<br>mesma população?<br>atribuir as pessoas a gru<br>onfusão?<br>nício do estudo (ou no m<br>l?<br>ara que os resultados oco<br>otivos da perda do acom<br>mento incompleto?|pos expost<br>omento da<br>rressem?<br>panhament|os e não expostos?<br>exposição)?<br>o foram descritos e expl|orados?||

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Resumo das evidências:** -->
Dentre os estudos inseridos na revisão, destaca-se que os desfechos de interesse relacionados ao insucesso da terapia e o relato de eventos adversos não foram frequentemente descritos por esquema terapêutico nos estudos. Considerando o interesse em avaliar a certeza da evidência para o esquema SMX + TMP associado a rifampicina, os estudos de Inan et al., 2019<sup>266</sup> e Khan et al., 2001<sup>268</sup> e Roushan et al., 2011<sup>92</sup> são os únicos que apresentaram dados para o desfecho de complicações obstétricas separado por esquema terapêutico ( **Tabela K** ).  
176  
Tabela K. Avaliação da qualidade da evidência pelo GRADE dos estudos que avaliaram a terapia com SMX-TMP + RF para a brucelose humana durante a gestação  
<!-- Start of picture text -->
№ de pacientes Efeito<br>Avaliação da certeza da evidência<br>Certeza Importância<br>Outras  qualquer  Relativo Absoluto<br>antimicrobianos<br>№ dos  Delineamento do  Risco  Evidência  considerações comparador (95% CI) (95% CI)<br>Inconsistência Imprecisão<br>estudos estudo de viés indireta<br><!-- End of picture text -->  
**Eventos adversos relacionados à gestação (Complicações obstétricas)**  
|3|estudo<br>observacional<br>(109)|não<br>grave|não grave|não grave|muito<br>grave<sup>a</sup>|-<br>19/96 (17,4%)|-<br>-<br>-<br>⨁◯◯◯<br>Muito<br>Baixa|CRÍTICO|
|---|---|---|---|---|---|---|---|---|  
a Evidência gerada a partir estudos observacionais, sem grupo comparador.  
177

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
Apresenta-se o processo de formulação de recomendações por meio de um painel de especialistas conduzido em outubro de 2023. Nesse painel foram formuladas recomendações sobre o uso dos esquemas terapêuticos para o tratamento da brucelose humana em gestantes, baseando-se nas contribuições do painel de especialistas e apoiado pela síntese de evidências realizada pelo grupo elaborador.  
A **Tabela L** apresenta o processo de tomada de decisão sobre o uso do sulfametoxazol associado a trimetropima e a rifampicina para o tratamento da brucelose humana em gestantes, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
Tabela L. Processo de tomada de decisão referente ao uso do sulfametoxazol + trimetropima + rifampicina para o tratamento da brucelose humana em gestantes  
|**Item da EtD**|**Julgamento**<br>**dos painelistas**|**Justificativa**|
|---|---|---|
|Efeitos desejáveis|<br>Moderado|Ausência de dados sumarizados em comparação direta na<br>população de interesse<br>Extrapolar dados da análise da população geral: ausência de<br>diferença entre esquema com SMX-TMP + RF vs. DX + STP<br>(RR: 1,61; IC95%: 0,29 a 8,86).<br>Ausência de taxa de cura/recidiva para o esquema com CFX<br>Benefício para gestantes vs. feto<br>Votação: unanimidade|
|Efeitos indesejáveis|Moderado|Resultados Inan, 2019 (desfavorável)<br>CFX + RF -12 de 79<br>SMX-TMP + RF - 11 de 79<br>SMX-TMP + CFX + RF - 4 de 43<br>Uma revisão apontou prevalência de anomalias congênitas em<br>3,5% (IC95% 1,8–5,1%) das mulheres que usaram SMX-TMP<br>na gravidez (certeza da evidência muito baixa) (Ford et al., 2014)<br>- Estudo não direcionado à brucelose<br>Categorias de risco na gravidez:<br>gentamicina D<br>estreptomicina D<br>SMX-TMP C<br>rifampicina C<br>ceftriaxona B<br>Votação: unanimidade(5/5)|
|Certeza da<br>evidência:|Muito baixo|GRADE: certeza da evidência muito baixa<br>(Evidência gerada a partir de estudo observacional, sem grupo<br>comparador).<br>Votação: unanimidade(5/5)|
|Balanço de efeitos|Favorece a<br>intervenção|Os benefícios superam os riscos?<br>Desfechos obstétricos: gestante com brucelose humana<br>apresenta risco e morbidade para o feto.<br>Votação: unanimidade(5/5)|
|Recursos<br>necessários:|Custos e<br>economias<br>insignificantes|sulfametoxazol + trimetoprima + rifampicina (80 mg/400 mg)<br>12/12 horas/ 42 dias de tratamento)<br>R$ 35,15 (MS) a R$53,15 (BPS)<br>Votação: unanimidade(5/5)|  
178  
|**Item da EtD**|**Julgamento**<br>**dos painelistas**|**Justificativa**|
|---|---|---|
|Equidade:|Aumento|Esquema terapêutico acessível (pacientes moradores de zona<br>rural e grandes centros)<br>Administração via oral (não requer estrutura hospitalar)<br>Rifampicina não é amplamente disponibilizada, compra<br>centralizada pelo Ministério da Saúde, podendo ser esse contexto<br>uma barreira ao acesso.<br>Votação: unanimidade(5/5)|
|Aceitabilidade:|Sim|PACIENTE<br>Barreiras: resistência das gestantes ao tratamento (tratamento<br>longo com antimicrobianos)<br>Facilitadores: terapia oral preferida pelos pacientes (Papas et al.,<br>2007)<br>GESTOR E PROFISSIONAL DE SAÚDE<br>Boa experiência do programa de tuberculose com uso de<br>rifampicina (relato do especialista)<br>OBS: acesso à rifampicina (ver barreiras)<br>Votação: 4/5(sim)|
|Viabilidade de<br>implementação:|Sim|Terapia já disponível na Rename (SMZ-TMP - CBAF e<br>rifampicina - CESAF) e padronizada em alguns estados.<br>Votação: unanimidade 5/5|  
Fonte: Autoria própria.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Recomendação:** -->
Recomendação a favor e condicional para a intervenção, devido à baixa certeza da evidência. Há ressalvas na recomendação do PCR devido à necessidade de padronização do teste.  
Considerações para subgrupos: Observar o trimestre de gestação para a indicação de boas práticas do PCDT.  
Considerações para implementação: delinear o fluxo de acesso aos medicamentos e serviços de referência em gestação de alto risco (OBS: transmissão no parto).  
Acompanhamento e avaliação: Período de avaliação mais curto para monitoramento do tratamento em gestantes.  
Prioridades em pesquisa: Estudos com melhores delineamentos para gestantes.  
179

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **QUESTÃO 5: Qual a eficácia do uso de antimicrobianos após exposição acidental à** **_Brucella sp._ ?** -->
**Recomendação:** condicional a favor da Profilaxia Pós-Exposição (PEP) acidental à cepa _Brucella sp._  
A resposta dessa pergunta foi obtida a partir de uma estratégia ampla que incluiu a elaboração de uma revisão sistemática da literatura sobre a eficácia da PEP em pessoas que tiveram contato com _Brucella sp._ e a seguinte pergunta de pesquisa: Qual a eficácia do uso de antimicrobianos após exposição acidental à _Brucella sp._ ?  
A estrutura PICO para esta pergunta foi:  
**População:** Indivíduos expostos acidentalmente à _Brucella sp._  
**Intervenção:** Monoterapia ou terapia combinada de antimicrobianos indicados para a profilaxia da brucelose humana.  
**Comparador:** Nenhuma intervenção, placebo ou qualquer antimicrobiano.  
**Desfechos:** Ocorrência de brucelose, Intensidade/gravidade de sintomas, taxa de soroconversão, eventos adversos e adesão ao tratamento.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Métodos e Resultados da Busca** -->
Com base na pergunta PICO estabelecida para esta revisão sistemática, foi realizada a busca sistematizada da literatura nas bases de dados _Medline_ (via _Pubmed_ ), _Embase_ (via Periódicos Capes), _Cochrane Library_ e LILACS (via BVS). A busca foi realizada até o dia 20 de março de 2023 e atualizada em 20 de novembro do mesmo ano, usando termos MeSH, DECS e EMTREE, além de palavras-chave e outros termos livres relacionados a “brucelose humana” e “profilaxia” conectados por operadores booleanos ( _OR_ , _AND_ ). Estudos adicionais foram pesquisados nas listas de referências dos artigos incluídos e na literatura cinzenta. As estratégias de busca para cada base estão descritas no **Quadro II** .  
180  
Quadro II. Estratégias de busca, de acordo com a base de dados, para identificação de estudos clínicos sobre a profilaxia em indivíduos expostos acidentalmente à _Brucella_ sp.  
|**Bases de**<br>**dados**|**Estratégias**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
|MEDLINE<br>(via<br>Pubmed)|<br>**População:**<br>**#1**(Brucellosis[MeSH Terms]) OR (Brucellosis) OR (Brucelloses) OR (Malta Fever) OR<br>(Fever, Malta) OR (Gibraltar Fever) OR (Fever, Gibraltar) OR (Rock Fever) OR (Fever,<br>Rock) OR (Cyprus Fever) OR (Fever, Cyprus) OR (Brucella Infection) OR (Brucella<br>Infections) OR (Infection, Brucella) OR (Undulant Fever) OR (Fever, Undulant) OR<br>(Brucella abortus) OR (Brucella canis) OR (Brucella melitensis) OR (Brucella ovis) OR<br>(Brucella suis)<br>**Intervenção:**<br>**#2**Post-Exposure Prophylaxis [MeSH Terms] OR "Disease Prevention" OR<br>chemoprevention OR "Post-Exposure Prophylaxis" OR "Profilaxis Posexposición" OR<br>"Antibiotic Prophylaxis" OR antibioprophylaxie OR chemoprophylaxis OR prophylaxis<br>OR prevention OR "Occupational Exposure" OR "Exposition professionnelle" OR<br>"Laboratory Infection" OR "Accidental Exposure" OR ("Brucella Vaccine"[Mesh] OR<br>Vaccine, Brucella)|<br> <br> <br> <br> <br>1.730|
||**#3**#1 AND #2 AND humans[Filter]||
|EMBASE|<br>**População:**<br>**#1**('brucellosis'/exp OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta<br>fever' OR 'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by brucella'<br>OR 'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella'/exp OR<br>'brucella' OR 'brucella contamination' OR 'brucella abortus'/exp OR 'brucella abortus' OR<br>'bacterium abortus' OR 'brucella abortus bang bacteria' OR 'brucella abortus sensitivity'<br>OR 'brucella canis'/exp OR 'brucella melitensis'/exp OR 'brucella melitensis' OR<br>'micrococcus melitensis' OR 'brucella ovis'/exp OR 'brucella ovis' OR 'brucella suis'/exp<br>OR 'brucella melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella suis')<br>**Intervenção:**<br>**#2**('prophylaxis'/exp OR prophylaxis OR 'chemoprophylaxis'/exp OR chemoprophylaxis<br>OR 'post exposure prophylaxis'/exp OR 'post exposure prophylaxis' OR 'antibiotic<br>prophylaxis'/exp OR 'antibiotic prophylaxis' OR 'occupational exposure'/exp OR<br>'occupational exposure' OR 'laboratory infection'/exp OR 'laboratory infection' OR<br>'accidental exposure' OR ‘brucella vaccine’)|843<br> <br> <br> <br>|
||**#3**#1 AND #2 AND [humans]/lim AND [embase]/lim||
|Cochrane<br>Library|**População:**<br>**#1**MeSH descriptor: [Brucellosis] explode all trees<br>**População:**<br>**#2**('brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever'<br>OR 'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by brucella' OR<br>'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella<br>abortus' OR 'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria'<br>OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella<br>canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR<br>'brucella melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella<br>suis''brucellosis' OR 'brucella infection' OR 'brucella melitensis infection' OR 'malta fever'<br>OR 'mediterranean fever (brucellosis)' OR 'brucellosis' OR 'infection by brucella' OR<br>'infection by brucella melitensis' OR 'infection due to brucella' OR 'infection due to<br>brucella melitensis' OR 'melitococcosis' OR 'undulant fever' OR 'brucella' OR 'brucella<br>abortus' OR 'brucella abortus' OR 'bacterium abortus' OR 'brucella abortus bang bacteria'<br>OR 'brucella abortus sensitivity' OR 'brucella melitensis' OR 'brucella canis' OR 'brucella<br>canis' OR 'brucella canidis' OR 'brucella ovis' OR 'brucella ovis' OR 'brucella suis' OR<br>'brucella melitensis biovar suis' OR 'brucella melitensisbv. suis' OR 'brucella<br>suis'):ti,ab,kw<br>**Intervenção:**<br>**#3**("Disease Prevention" OR chemoprevention OR "Post-Exposure Prophylaxis" OR<br>"Profilaxis Posexposición" OR "Antibiotic Prophylaxis" OR antibioprophylaxie OR<br>chemoprophylaxis OR prophylaxis OR prevention OR "Occupational Exposure" OR<br>"Exposition professionnelle" OR "Laboratory Infection" OR "Accidental<br>Exposure"):ti,ab,kw|<br> <br>19|  
181  
|**Bases de**<br>**dados**|**Estratégias**|**Número de**<br>**resultados**<br>**encontrados**|
|---|---|---|
||**#4**MeSH descriptor: [Brucella Vaccine] explode all trees<br>**#5** (#1 OR #2)AND(#3 OR #4)||
|BVS|**População:**<br>**#1**(((mh:(brucelose)) OR (brucelose) OR (mh:(brucellosis)) OR (brucellosis) OR<br>(mh:(brucelosis)) OR (brucelosis) OR (febre ondulante) OR (febre de malta) OR<br>(infecçãopor brucella) OR (mh:(brucella)) OR (brucella) OR (mh:(brucella abortus)) OR<br>(brucella abortus) OR (bacterium abortus) OR (mh:(brucella canis )) OR (brucella canis )<br>OR (mh:(brucella melitensis)) OR (brucella melitensis) OR (micrococcus melitensis) OR<br>(mh:(brucella ovis)) OR (brucella ovis) OR (mh:(brucella suis)) OR (brucella suis)))<br>**Intervenção:**<br>**#2**("Disease Prevention" OR chemoprevention OR "Post-Exposure Prophylaxis" OR<br>"Profilaxis Posexposición" OR "Antibiotic Prophylaxis" OR antibioprophylaxie OR<br>chemoprophylaxis OR prophylaxis OR prevention OR "Occupational Exposure" OR<br>"Exposition professionnelle" OR "Laboratory Infection" OR "Accidental Exposure" OR<br>“Vaccine, Brucella”)<br>**Bases disponíveis após retirar MEDLINE no filtro da BVS:**<br>**#3**( db:("LILACS" OR "PAHO" OR "BINACIS" OR "IBECS" OR "CUMED" OR<br>"LIPECS" OR "VETINDEX" OR "LIS" OR "MedCarib" OR "SMS-SP" OR<br>"ARGMSAL" OR "MINSAPERU" OR "WHOLIS" OR "DECS" OR "HANSENIASE"<br>OR "MULTIMEDIA" OR "PAHOIRIS" OR "SES-SP" OR "colecionaSUS"))<br>**#4**#1 AND #2 AND #3|<br>447|
|**Total em to**|**das as bases**|3039|  
Busca realizada em 20/03/2023 e atualizada até 20/11/2023.  
182  
Foram considerados como critérios de elegibilidade:

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de inclusão** -->
(a) Tipos de participantes: Participantes em uso de profilaxia com antimicrobianos após exposição acidental à _Brucella sp._  
(b) Tipo de intervenção: Qualquer intervenção terapêutica medicamentosa, placebo ou nenhuma intervenção.  
(c) Delineamento dos estudos: Ensaios clínicos randomizados, estudos observacionais, inclusive relatos de casos.  
(d) Desfechos: Medidas relativas ao sucesso da terapia profilática, como a taxa de ocorrência de brucelose humana. Outros desfechos considerados foram eventos adversos, intensidade/gravidade de sintomas, taxa de soroconversão e adesão ao tratamento.  
(e) Idioma: Estudos publicados em inglês, espanhol e português.

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Critérios de exclusão** -->
(a) Tipos de estudos: Publicações no formato de _abstract_ de congresso, cujos resultados também foram relatados em artigo científico; Estudos com menos de 5 participantes.  
(b) Tipo de intervenção: Estudos que não relataram adequadamente o esquema profilático utilizado.  
Inicialmente, os registros obtidos nas bases de dados foram importados para o _Mendeley Reference Management Software_<sup>143</sup> para identificação e eliminação das duplicatas, e em seguida, importados para o aplicativo _Rayyan_<sup>144</sup> para gerenciamento das referências e seleção dos estudos. De acordo com os critérios pré-definidos de elegibilidade, a triagem de títulos e resumos foi realizada de forma independente por duas duplas de revisores. As etapas de leitura de texto completo, inclusão dos estudos e extração de dados foram realizadas por uma dupla de revisores. Os conflitos foram discutidos até que se chegasse a um consenso.  
Os dados extraídos incluíram: autor, ano, país, desenho do estudo, número de pacientes, período do estudo, duração do acompanhamento dos pacientes, tipo de vigilância, classificação do risco de exposição, população que recebeu a PEP, antimicrobianos utilizados na PEP, duração do tratamento e desfecho de ocorrência da brucelose.  
A partir da estratégia de busca realizada, foram recuperados 3.102 registros, com 2.608 citações restantes após a identificação e eliminação de duplicatas. Após triagem e processo de seleção com base nos critérios de elegibilidade, todos os registros selecionados passaram por um processo de revisão por pares com a leitura do texto na íntegra (44 artigos). Dentre esses, 33 estudos não atenderam aos critérios de inclusão desta revisão. Os motivos de exclusão incluíram estudos que não reportaram adequadamente a descrição do esquema profilático utilizado (5 estudos), relatos de caso com menos de 5 participantes (6 estudos), 18 estudos cuja população não foi a de interesse e 4 estudos publicado em idioma diverso do inglês, espanhol e português. Ao final, 11 estudos atenderam aos critérios de elegibilidade e foram incluídos nesta revisão. A **Figura W** ilustra o fluxograma de seleção dos estudos.  
183  
<!-- Start of picture text -->
Identificação de estudos por meio de bases de dados e registros<br>Registros identificados por meio de:<br>MEDLINE (n=1730)<br>EMBASE (n=843)<br>Registros duplicados removidos<br>COCHRANE (n=19)<br>(n=494)<br>BVS (n=447)<br>Busca manual (n=63)<br>Total = 3102 registros<br>Registros em triagem<br>Registros excluídos<br>(n =2608)<br>(n =2563)<br>= =<br>Publicações pesquisadas<br>(n =45)  Registros não recuperados<br>(n = 1)<br>Publicações avaliadas para  Publicações excluídas (n=33)<br>elegibilidade    População inadequada (n = 18)<br>(n =44)   Intervenção não especificada<br>ou mal descrita (n = 5)<br> Outro idioma (n= 4)<br> Tamanho amostra (menos de 5<br>participantes) (n=6)<br>=<br>—<br>Estudos incluídos na revisão<br>(n = 11)<br>Relatos dos estudos incluídos<br>(n = 11)<br>_<br>Figura W. Fluxograma de seleção dos estudos incluídos na revisão sistemática avaliando<br>opções terapêuticas para a profilaxia pós-exposição à  Brucella  sp.<br>Identificação<br>Triagem<br>Incluídos<br><!-- End of picture text -->  
Fonte: Adaptado de Page et al<sup>151</sup>

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Análise e apresentação dos resultados** -->
A revisão sistemática abrangeu onze estudos que foram realizados em seis países diferentes, sendo cinco estudos dos EUA<sup>114,119,121,122,269</sup> e um estudo de cada um dos seguintes países: Belgica<sup>115</sup> , Austrália<sup>270</sup> , Reino Unido<sup>117</sup> , Malásia<sup>118</sup> , Singapura<sup>120</sup> e Turquia<sup>271</sup> . Todos os estudos incluídos na análise são estudos observacionais descritivos (série de casos).  
Quanto à natureza da exposição na população estudada, observou-se que todos os estudos relataram exposição ocupacional, especialmente de profissionais de saúde de laboratórios. Os profissionais foram principalmente expostos à _B. melitensis_<sup>115–118,120,269)</sup> . Além disso, dois estudos investigaram a exposição à _Brucella suis_<sup>114,119</sup> e dois estudos à _B. abortus_<sup>121,122</sup> _._ Dois estudos avaliaram a exposição ocupacional em veterinários, estudantes e técnicos veterinários<sup>122,271</sup> . O estudo de Nichols et al, 2014<sup>121</sup> investiga além da exposição laboratorial, a exposição dos  
184  
profissionais de saúde e de limpeza numa sala de procedimento cirúrgico. Todas as demais exposições derivaram da análise de amostras de pacientes em laboratórios clínicos.  
O período do estudo foi relatado em seis publicações e variou de 2008 a 2020. Quatro estudos não forneceram essa informação<sup>116, 117,121,272</sup> . O tempo de seguimento dos pacientes foi relatado em 9 estudos, variou entre 6 meses<sup>114,115,117,120–122,269</sup> a 8 meses<sup>118,270</sup> .  
Os métodos de vigilância empregados nos estudos abrangeram abordagens sorológicas, PCR e clínicas. Especificamente, cinco estudos<sup>114,116,119–121</sup> realizaram vigilância sorológica e clínica combinada, três estudos<sup>117,118,269</sup> focaram exclusivamente na vigilância sorológica, enquanto um estudo abrangeu vigilância sorológica, PCR e clínica<sup>115</sup> e outro focado em sinais clínicos<sup>122</sup> . As características dos estudos incluídos podem ser encontradas em detalhe no **Quadro JJ** .  
185

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro JJ. Principais características metodológicas dos estudos avaliando Profilaxia Pós-Exposição para brucelose humana -->
|**Estudo**|**País (n)**|**Desenho do estudo**|**Local do estudo**|**Período do**<br>**estudo**|**Tempo de**<br>**seguimento**|**População avaliada**|**Tipo de vigilância**|
|---|---|---|---|---|---|---|---|
|**Ashford**<br>**et**<br>**al**<br>**2004**<sup>122</sup>|EUA (26)|Série de casos|NR. Vacinação animal.|1998 a 1999|6 meses|Exposição ocupacional<br>de veterinários,<br>estudantes e técnicos<br>veterinários à vacina<br>RB51|Sinais clínicos|
|**Carra et al, 2010**<sup>269</sup>|EUA (34)|Série de casos|Laboratório clínico de<br>um hospital de cuidados<br>intensivos|2009|6 meses|Casos de exposição por<br>inalação a_Brucella_<br>_melitensis_|Sorológico|
|**Castrodale et al,**<br>**2015**<sup>114</sup>|EUA (31)|Série de casos|Dois laboratórios<br>diferentes no Alasca,<br>EUA|2012|6 meses|Casos de exposição<br>laboratorial à_Brucella_<br>_suis_|Sorológico e clínico|
|**Deyi et al, 2021**<sup>115</sup>|Bélgica (28)|Série de casos|Laboratório clínico<br>atendendo cinco<br>Hospitais Universitários|2015 a 2020|6 meses|Casos de exposição<br>laboratorial a_Brucella_<br>_melitensis_em<br>laboratórios<br>universitários de<br>Bruxelas|Sorológico, PCR e<br>clínico|
|**Kutlu, et al, 2014**<sup>271</sup>|Turquia (17)*|Estudo transversal|Direções provinciais de<br>alimentação, agricultura<br>e pecuária, institutos de<br>controle e investigação<br>veterinária, faculdades<br>veterinárias e setor<br>privado|2011|NR|Exposição ocupacional<br>de veterinários e técnicos<br>veterinários à vacina<br>_Brucella_(cepa S19 e<br>Rev.1)|Definição de<br>diagnóstico de<br>brucelose sorológico<br>e clínico e auto-<br>relato|
|**Maley et al, 2006**<sup>116</sup>|Austrália (44)|Série de casos|Laboratório hospitalar|NR|8 meses|Casos de exposição<br>laboratorial à_Brucella_<br>_melitensis_|Sorológico e clínico|  
186  
|**Estudo**|**País (n)**|**Desenho do estudo**|**Local do estudo**|**Período do**<br>**estudo**|**Tempo de**<br>**seguimento**|**População avaliada**|**Tipo de vigilância**|
|---|---|---|---|---|---|---|---|
|**Nichols**<br>**et**<br>**al,**<br>**2014**<sup>121</sup>|EUA (18)|Série de casos|Sala de cirurgia e<br>laboratório hospitalar|NR|6 meses|Casos de exposição<br>durante procedimento<br>cirúrgico e laboratorial à<br>_Brucella_abortus|Sorológico e clínico|
|**Reddy et al., 2010**<br>117|Reino Unido (50)|Série de casos|Cinco laboratórios<br>diferentes em Londres,<br>Inglaterra|NR|6 meses|Casos de exposição<br>laboratorial a_Brucella_<br>_melitensis_em<br>laboratórios de Londres|Sorológico|
|**Sam et al.; 2012**<sup>118</sup>|Malásia (51)|Série de casos|Um laboratório do<br>Centro Médico da<br>Universidade da<br>Malásia|2009|8 meses|Casos de exposição<br>laboratorial a_Brucella_<br>_melitensis_em um<br>laboratório da Malásia|Sorológico|
|**Traxler et al., 2013**<br>119|EUA (35)|Série de casos|Diferentes laboratórios<br>nos EUA|2008 a 2011|NR|Casos de exposição<br>laboratorial a_Brucella_<br>_suis_em laboratórios de<br>Londres|Sorológico e clínico|
|**Wong et al., 2018**<sup>272</sup>|Singapura (22)|Série de casos|Laboratório de<br>microbiologia em<br>Singapura|NR|6 meses|Acidentes de laboratório<br>com_Brucella melitensis_<br>ocorridos em Singapura|Sorológico e clínico|  
Legenda: CDC: _Centers for Disease Control and Prevention_ ; EUA: Estados Unidos da América; PCR: Reação em Cadeia da Polimerase; NR: não relatado.  
187  
Os onze estudos incluídos abrangeram um total de 356 trabalhadores de laboratórios clínicos ou veterinários. Quanto à classificação da exposição, 154 participantes foram categorizados como alto risco, 12 como de médio risco, 147 participantes como baixo risco de exposição e 43 não relataram esta classificação noQuadro **Quadro KK** .  
A maioria dos artigos utilizou a definição de classificação de risco adotada pelo _Centers for Disease Control and Prevention_ (CDC). De acordo com essa instituição dos Estados Unidos da América (EUA), a classificação de risco durante uma exposição à _Brucella sp._ em um laboratório de análises clínicas dependerá de alguns fatores, tais como o tipo de amostra manuseada (rotina, enriquecida ou reprodutiva), as atividades desempenhadas pelos profissionais presentes no laboratório no momento da exposição, a distância dos profissionais em relação a amostra e a utilização de procedimentos de segurança. A classificação de risco é classificada em mínimo, baixo e alto risco.  
Riscos mínimos são oriundos de situações nas quais uma pessoa manipula amostras em uma Cabine de Biossegurança Classe II certificada, com o uso adequado de equipamento de proteção individual (EPI). As demais pessoas presentes no laboratório também são classificadas como risco mínimo quando o manipulador da amostra se encontra nas condições mencionadas ou em uma bancada aberta sem a ocorrência de eventos geradores de aerossóis. Nestas situações, a PEP não deve ser oferecida.  
O cenário de baixo risco caracteriza-se pela presença de uma pessoa no laboratório a uma distância superior a 5 pés (aproximadamente 1,5 metros) de alguém que esteja manipulando material enriquecido ou amostra clínica reprodutiva em uma bancada aberta, sem ocorrência de eventos geradores de aerossóis. Nesses casos, a PEP pode ser considerada em grávidas ou imunocomprometidos.  
Exposições de alto risco podem ocorrer em diferentes contextos, tais como: (1) contato de uma amostra clínica de rotina com a pele ferida ou mucosas, independentemente do uso de uma Cabine de Biossegurança Classe II certificada e do EPI; (2) manipulação direta ou distância igual ou inferior a 5 pés do manipulador de material enriquecido ou amostra clínica reprodutiva fora de uma cabine de biossegurança classe II certificada; (3) pessoa que manipula material enriquecido ou amostra clínica reprodutiva dentro de uma cabine de biossegurança classe II certificada, sem o uso adequado de EPI; (4) todos os presentes durante a ocorrência de eventos geradores de aerossóis com manipulação de material enriquecido ou amostra clínica reprodutiva em uma bancada aberta. PEP deve ser oferecida nesses casos, sendo o esquema terapêutico padrão o uso de doxiciclina 100 mg duas vezes ao dia e rifampicina 600 mg uma vez ao dia, por três semanas.  
Um dos estudos incluídos<sup>116</sup> classificou os participantes como de baixo, médio e alto risco de exposição. O estudo classifica alto risco como o de funcionários que manipularam com culturas em bancadas abertas ou potencialmente inalaram material das culturas líquidas ou em placa fora da Cabine de Biossegurança Classe II certificada. Os funcionários de médio risco se encontravam mais próximos do manipulador e os de baixo risco trabalhavam em outras áreas do laboratório. O estudo de Nichols e colaboradores<sup>121</sup> avaliou profissionais expostos tanto na sala de cirurgia quanto no laboratório de análises clínicas. Na sala de cirurgia, a classificação de risco foi definida como a presença na sala de operações durante procedimentos geradores de aerossóis, incluindo irrigação articular e limpeza após o procedimento.  
Outros dois estudos<sup>122,271</sup> não procederam a classificação de risco, uma vez que foram estudos avaliando acidentes vacinais em veterinários, estudantes e técnicos veterinários.  
188  
As informações sociodemográficas dos participantes, abrangendo fatores como raça, sexo e idade, não foram apresentadas no âmbito dos estudos incluídos nesta revisão. Em todos os estudos que avaliavam exposição em profissionais de laboratórios, a PEP foi oferecida exclusivamente aos indivíduos classificados como de alto risco. Dentre os participantes classificados como de alto risco, nem todos os trabalhadores aceitaram a abordagem terapêutica, resultando num subconjunto de 125 participantes dos 154 classificados originalmente como de alto risco. No conjunto de participantes cuja classificação de risco não se aplicava, dos 43 indivíduos, 42 receberam PEP.  
A maioria dos estudos detalhou uniformemente o protocolo de tratamento profilático empregado, que consistiu na administração de doxiciclina 100 mg duas vezes ao dia, combinada com rifampicina 600 mg, ambas administrados durante 21 dias. Dois estudos<sup>122,271</sup> empregaram esquemas profiláticos distintos, como doxiciclina em monoterapia. O intervalo de tempo desde o momento da exposição até o início da PEP apresentou muita variabilidade, compreendendo um intervalo de 0 até 31 dias.  
Nos nove estudos sobre exposição acidental à _Brucella sp._ em laboratórios, seis relataram eventos adversos em pacientes que usaram PEP. Entre os 69 participantes incluídos na análise, 19 indivíduos (27,5%) relataram ter sofrido eventos adversos. Os principais eventos adversos foram náusea, febre, perda de peso, fadiga, vômito, anorexia, hepatite leve, inchaço facial leve, depressão leve, ansiedade, desconforto gastrointestinal e resultados anormais de testes de função hepática. No estudo que relatou exposição acidental devido à inoculação da vacina, os eventos adversos foram classificados como locais, sistêmicos e locais persistentes<sup>122</sup> . Das 25 pessoas que receberam PEP, 14 relataram eventos adversos locais (56%), 19 (73%) relataram sintomas sistêmicos e sete pessoas (27%) eventos adversos persistentes, definidos como vermelhidão e inchaço que persistiram por mais tempo do que a duração média dos eventos adversos locais relatados pela coorte do estudo. Vale ressaltar que os eventos adversos relatados neste estudo estão relacionados à injeção da vacina e à tentativa de identificar sinais da cepa no organismo, dada a dificuldade de isolamento da cepa RB51. Os autores não conseguiram determinar se o resultado do evento adverso relatado resultou de “infecção” por RB51.  
A adesão aos medicamentos foi relatada em sete estudos. Dentre os 84 participantes aos quais foi prescrita PEP nestes estudos, um total de 72 (85,7%) aderiram com sucesso ao regime profilático prescrito.  
Cada estudo incluído nesta revisão sistemática documentou a manifestação da brucelose humana, confirmada pela sintomatologia clínica ou pelo diagnóstico laboratorial. Ashford e colaboradores<sup>122</sup> relataram como desfecho a ocorrência de eventos adversos relacionados ao acidental vacinal. Dos 150 participantes submetidos à PEP, a manifestação da brucelose humana surgiu em apenas dois indivíduos (1,3%), conforme relatado em dois estudos. Em um desses estudos<sup>119</sup> uma mulher de 32 anos iniciou a PEP 13 dias após a exposição e relatou completar 21 dias de PEP. Quatro meses após a exposição, ela apresentou sintomas e, após confirmação diagnóstica, foi tratada com regime de doxiciclina e rifampicina por 6 semanas.  
189

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro KK. Resultados dos estudos que avaliaram Profilaxia Pós-Exposição para brucelose humana -->
|**Estudo**|**Classificação**<br>**da exposição**<br>**de risco (n)**|**População**<br>**que**<br>**recebeu**<br>**PEP**|**PEP**<br>**antimicrobiana;**<br>**duração do**<br>**tratamento**|**Tempo da**<br>**exposição a**<br>**administração**<br>**de PEP**|**Monitoramento**<br>**Sorológico/**<br>**Sintomático**|**Número de pessoas**<br>**com adesão**<br>**medicamentosa/total**<br>**de pessoas**|**Eventos**<br>**adversos**<br>**(n)**|**Eventos**<br>**adversos**<br>**relatados**|**Número de**<br>**casos de**<br>**brucelose/total**<br>**de pessoas**|
|---|---|---|---|---|---|---|---|---|---|
|**Ashford et**<br>**al 2004**<sup>122</sup>|NR<br>(Ferimentos<br>com agulhas<br>n=21; sprays<br>conjuntivais<br>n=4;<br>exposição por<br>spray de uma<br>ferida aberta<br>n=1.|25|-doxiciclina 200<br>mg (n=21).<br>-amoxicilina,<br>doxiciclina (NR)<br>- doxiciclina,<br>gentamicina<br>(NR)<br>-tetraciclina,<br>doxiciclina (NR)|Mesmo dia<br>(n=18)|Entrevista no contato<br>inicial e após 6<br>meses para avaliar<br>sintomas ou doenças<br>de longo prazo|NR|Local<br>14(25)<br>Sistêmico<br>19(25)<br>Persistente<br>7 (25)|Eritema,<br>endurecimento,<br>febre, calafrios,<br>suores, fadiga,<br>mialgia e<br>artralgia|(0/25)<br>(cultura isolada<br>em uma pessoa<br>após<br>procedimento<br>cirúrgico)|
|**Carra et**<br>**al, 2010**<sup>269</sup>|Alto risco<br>(23)<br>Baixo risco<br>(11)|Alto risco<br>(23)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|24 dias|Monitoramento<br>sorológico<br>sequencial - os<br>títulos foram<br>determinados e<br>repetidos em 2, 4, 6<br>e 24 semanas|22/23|6/23|Náuseas|1/23|
|**Castrodale**<br>**et al,**<br>**2015**<sup>114</sup>|Alto risco (6)<br>Baixo risco<br>(25)|Alto risco<br>(6)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|3-31 dias|Monitoramento<br>sorológico<br>sequencial - os<br>títulos foram<br>determinados e<br>repetidos em 6, 12,<br>18 e 24 semanas.<br>Vigilância da febre|3/6|1/6|Febre|0/6|
|**Deyi et al,**<br>**2021**<sup>115</sup>|Alto risco<br>(11)<br>Baixo risco<br>(17)|Alto risco<br>(11)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|2 dias|Monitoramento<br>sorológico<br>sequencial - os<br>títulos foram<br>determinados e<br>repetidos em 3, 6,<br>12, 18 e 24 semanas.<br>PCR|11/11|1/11|Febre, perda de<br>peso e fadiga|0/11|
|**Kutlu et al **|NR.|17|Doxiciclina|NR|NR|NR|NR|NR|0/17|  
190  
|**Estudo**|**Classificação**<br>**da exposição**<br>**de risco (n)**|**População**<br>**que**<br>**recebeu**<br>**PEP**|**PEP**<br>**antimicrobiana;**<br>**duração do**<br>**tratamento**|**Tempo da**<br>**exposição a**<br>**administração**<br>**de PEP**|**Monitoramento**<br>**Sorológico/**<br>**Sintomático**|**Número de pessoas**<br>**com adesão**<br>**medicamentosa/total**<br>**de pessoas**|**Eventos**<br>**adversos**<br>**(n)**|**Eventos**<br>**adversos**<br>**relatados**|**Número de**<br>**casos de**<br>**brucelose/total**<br>**de pessoas**|
|---|---|---|---|---|---|---|---|---|---|
|**2014**|||(n=8)<br>Doxiciclina +<br>Rifampicina<br>(n=6);<br>10 a 28 dias|||||||
|**Maley et**<br>**al, 2006**<sup>116</sup>|Alto risco (7)<br>Risco médio<br>(12)<br>Baixo risco<br>(25)|Alto risco<br>(7)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|7 dias (1<br>começou em 4<br>semanas)|Teste sorológico por<br>12 semanas|4/7|6/7|Náuseas (6),<br>vômitos (6),<br>anorexia (6),<br>febre (1),<br>hepatite leve (1),<br>pequeno inchaço<br>facial (1),<br>depressão leve<br>(1), ansiedade<br>durante o uso de<br>antibióticos(1).|0/7|
|**Nichols et**<br>**al, 2014**<sup>121</sup>|Alto risco<br>(17)<br>Baixo risco<br>(1)|Alto risco<br>(15)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|NR|Monitoramento<br>sorológico<br>sequencial,<br>automonitoramento e<br>acompanhamento<br>por equipe<br>profissional|15/15|NR|NR|0/15|
|**Reddy et**<br>**al., 2010**<sup>117</sup>|Alto risco<br>(29)<br>Baixo risco<br>(21)|Alto risco<br>(20)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg (ou 450mg);<br>21 dias|NR|A sorologia de<br>acompanhamento foi<br>feita em 6 semanas e<br>6 meses|NR|NR|NR|0/20|
|**Sam et al.;**<br>**2012**<sup>118</sup>|Alto risco<br>(27)<br>Baixo risco<br>(24)|Alto risco<br>(12)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>(ou 450) mg; 21<br>dias|NR|O teste sorológico<br>foi realizado usando<br>o STAT. O teste foi<br>realizado no início<br>do estudo e, em<br>seguida, 2, 4, 6<br>semanas e 8 meses<br>após a exposição|8/12|4/12|Efeitos<br>colaterais<br>gastrointestinais<br>(3) e testes de<br>função hepática<br>anormais (1)|0/12|  
191  
|**Estudo**|**Classificação**<br>**da exposição**<br>**de risco (n)**|**População**<br>**que**<br>**recebeu**<br>**PEP**|**PEP**<br>**antimicrobiana;**<br>**duração do**<br>**tratamento**|**Tempo da**<br>**exposição a**<br>**administração**<br>**de PEP**|**Monitoramento**<br>**Sorológico/**<br>**Sintomático**|**Número de pessoas**<br>**com adesão**<br>**medicamentosa/total**<br>**de pessoas**|**Eventos**<br>**adversos**<br>**(n)**|**Eventos**<br>**adversos**<br>**relatados**|**Número de**<br>**casos de**<br>**brucelose/total**<br>**de pessoas**|
|---|---|---|---|---|---|---|---|---|---|
||||||potencial|||||
|**Traxler et**<br>**al., 2013**<sup>119</sup>|Alto risco<br>(21)<br>Baixo risco<br>(14)|Alto risco<br>(21)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|NR|Diferentes<br>procedimentos de<br>monitoramento<br>foram estabelecidos<br>entre os casos|A adesão ao tratamento<br>não foi estabelecida<br>para todos os casos<br>notificados.|NR|NR|1/21|
|**Wong et**<br>**al., 2018**<sup>272</sup>|Alto risco<br>(13)<br>Baixo risco<br>(9)|Alto risco<br>(10)|Doxiciclina<br>100mg 2x d +<br>Rifampicina 600<br>mg; 21 dias|2 dias|Automonitoramento<br>diário de sintomas e<br>relato de qualquer<br>doença febril por um<br>período de 6 meses.<br>Três amostras de<br>sorologia para<br>_Brucella_foram<br>oferecidas a todos os<br>funcionários<br>expostos; no início<br>do estudo, entre as<br>semanas 10 a 13 e na<br>semana 24.|9/10|1/10|Desconforto<br>gastrointestinal<br>leve durante a<br>terapia<br>combinada.<br>Um indivíduo<br>era intolerante à<br>rifampicina<br>devido a efeitos<br>colaterais<br>gastrointestinais<br>após 1 dia de<br>tratamento e<br>optou por<br>continuar com 3<br>semanas de<br>monoterapia<br>com doxiciclina|0/10|  
Legenda: NR: Não relatado; CDC: _Centers for Disease Control_ : mg: miligramas; 2xd: duas vezes por dia; STAT: _Standard Tube Agglutination_ _<mark>Test</mark>_ <mark>.</mark> Nota: # Um indivíduo era intolerante à rifampicina devido a efeitos colaterais gastrointestinais após 1 dia de tratamento e optou por continuar com 3 semanas de monoterapia com doxiciclina.  
192  
A fim de sumarizar os dados sobre a eficácia da PEP, foi proposto um recorte para agrupar os estudos com a descrição sucinta da intervenção em indivíduos expostos nos laboratórios, sendo incluídos oito estudos<sup>114–121</sup> . A ocorrência de brucelose entre indivíduos expostos tratados com PEP foi observada em apenas um de um total de 97 indivíduos tratados (0,01; IC95% 0,00 a 0,07. Seis estudos relataram adesão à PEP; entre os 61 pacientes tratados, 50 relataram ter utilizado a PEP conforme prescrito, taxa de 86% (IC95% 0,58 a 0,96), sem detalhamento sobre o percentual de uso de medicamentos que foi considerado adesão satisfatória à PEP. Neste recorte, cinco estudos relataram eventos adversos ocorridos durante a PEP. Dos 46 pacientes que receberam PEP, 13 relataram algum evento adverso, incidência de 26% (IC95% 0,08 a 0,58). Nenhum estudo detalhou eventos adversos quanto à duração, intensidade, gravidade ou causalidade.  
A avaliação do risco de viés dos estudos incluídos foi conduzida de acordo com a Lista de Verificação de Avaliação Crítica de Estudos de Série de Casos e com a Lista de Verificação de Avaliação Crítica de Estudos Transversais do JBI (Instituto Joanna Briggs). Os resultados são apresentados nos **Quadro LL** e **Quadro MM** . Nos dez estudos avaliados pela ferramenta de série de casos, identificou-se que as pontuações obtidas variaram entre 5 e 7 pontos. Todos os estudos foram penalizados no domínio de apresentação dos dados demográficos dos participantes (domínio 6) e nove estudos foram penalizados no domínio de apresentação de informações clínicas (domínio 7). Estes estudos frequentemente careciam de detalhes abrangentes sobre os participantes, tais como idade, gênero e outras informações demográficas relevantes. Adicionalmente, observou-se a ausência de detalhes clínicos adequados, incluindo histórico médico dos participantes, sintomas clínicos e outros dados clínicos pertinentes.  
Em sete estudos, o domínio de inclusão consecutiva (domínio 4) foi considerado não aplicável. Tal categorização decorreu da interpretação das revisões ao considerar que o desenho do estudo contemplava a exposição de todos os trabalhadores em uma amostra de casos de brucelose humana. Assim, todos os trabalhadores expostos foram incluídos no estudo, o que está em consonância com o domínio 5 (inclusão completa dos participantes). Ademais, identificaramse limitações na apresentação das informações demográficas do local/clínica (domínio 9), com seis estudos sendo penalizados nesse domínio. Notou-se também que a maioria dos estudos não conduziu análises quantitativas ou comparações estatísticas, tornando seus resultados majoritariamente descritivos. Em consequência, o domínio de análise estatística foi considerado não aplicável para a maioria dos estudos.  
193

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro LL. Descrição geral da qualidade dos estudos (série de casos) -->
|**Estudo/ano**|**Havia**<br>**critérios**<br>**claros para**<br>**inclusão na**<br>**série de**<br>**casos?**|**A condição foi**<br>**medida de forma**<br>**padronizada e**<br>**confiável para**<br>**todos os**<br>**participantes**<br>**incluídos na série**<br>**de casos?**|**Foram utilizados**<br>**métodos válidos**<br>**para a**<br>**identificação da**<br>**condição em**<br>**todos os**<br>**participantes**<br>**incluídos na série**<br>**de casos?**|**A série de casos**<br>**teve inclusão**<br>**consecutiva dos**<br>**participantes?**|**A série de casos**<br>**teve inclusão**<br>**completa de todos**<br>**os participantes?**|**Houve relato claro**<br>**das características**<br>**demográficas dos**<br>**participantes no**<br>**estudo?**|**Houve relato claro**<br>**das informações**<br>**clínicas dos**<br>**participantes?**|**Os resultados ou**<br>**acompanhamentos dos**<br>**casos foram relatados de**<br>**forma clara?**|**Houve relato claro das**<br>**informações demográficas**<br>**do(s) local(is) de**<br>**apresentação/clínica?**|**A análise**<br>**estatística**<br>**foi**<br>**adequada?**|
|---|---|---|---|---|---|---|---|---|---|---|
|Ashford et al.<br>2004<sup>122</sup>|SIM|SIM|SIM|NÃO|NÃO|NÃO|SIM|SIM|NÃO|NA|
|Carra et al,<br>2010<sup>78</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|NÃO|NA|
|Castrodale et al,<br>2015<sup>79</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|NÃO|NA|
|Deyi et al,<br>2021<sup>81</sup>|SIM|SIM|SIM|SIM|SIM|NÃO|NÃO|SIM|SIM|NA|
|Maley et al,<br>2006<sup>82</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|SIM|NA|
|Nichols et al,<br>2010<sup>121</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|NÃO|NA|
|Reddy et al.,<br>2010<sup>83</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|NÃO|NA|
|Sam et al.; 2012<br>84|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|SIM|NA|
|Traxler et al.,<br>2013<sup>85</sup>|SIM|SIM|SIM|SIM|SIM|NÃO|NÃO|SIM|NÃO|NA|
|Wong et al.,<br>2018<sup>86</sup>|SIM|SIM|SIM|NA|SIM|NÃO|NÃO|SIM|SIM|NA|

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Quadro MM. Descrição geral da qualidade do estudo transversal -->
|**Estudo/ano**|**Os critérios para**<br>**inclusão na amostra**<br>**foram claramente**<br>**definidos?**|**Os sujeitos do estudo**<br>**e o ambiente foram**<br>**descritos em**<br>**detalhes?**|**A exposição foi**<br>**medida de uma**<br>**maneira válida e**<br>**confiável?**|**Foram usados**<br>**critérios padrões e**<br>**objetivos para a**<br>**medição da**<br>**condição?**|**Fatores de confusão**<br>**foram identificados?**|**Foram declaradas**<br>**estratégias para**<br>**lidar com os fatores**<br>**de confusão?**|**Os resultados foram**<br>**medidos de uma**<br>**maneira válida e**<br>**confiável?**|**Foi usada uma**<br>**análise estatística**<br>**apropriada?**|
|---|---|---|---|---|---|---|---|---|
|Kutlu et al.,2014|SIM|SIM|SIM|SIM|NÃO|NÃO|SIM|SIM|  
194

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Perfil das evidências:** -->
A avaliação da certeza da evidência foi conduzida utilizando a ferramenta GRADE, considerando diversos fatores como risco de viés, inconsistência, imprecisão e evidência indireta ( **Tabela M** ).  
Os desfechos avaliados nesta revisão foram: casos de brucelose humana, eventos adversos e adesão ao tratamento. Após uma análise criteriosa, a certeza da evidência para todos os desfechos foi classificada como "muito baixa". Esta classificação sugere que há uma confiança limitada nos efeitos estimados para os desfechos.  
A decisão de rebaixar a certeza da evidência foi fundamentada em várias razões específicas relacionadas ao desenho dos estudos e à natureza dos dados disponíveis. Primeiramente, a principal fonte de informação que embasou a análise provém de séries de casos. Esse tipo de estudo, por sua natureza observacional impede de estabelecer relações causais. Além disso, a ausência de grupos comparadores nos estudos avaliados limita a capacidade de discernir a eficácia de uma intervenção em relação a outra.  
Outro ponto crucial é a falta sistemática de dados nos estudos que possam auxiliar na decisão sobre a adoção ou não da profilaxia após exposição acidental à _Brucella sp_ . Sem esses dados, torna-se desafiador fazer afirmações conclusivas sobre sua eficácia e a adesão dos profissionais a essa medida. Faz-se necessária a realização de pesquisas futuras que abordem essas lacunas para uma compreensão mais aprofundada e confiável dos desfechos avaliados.  
195

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Tabela M. Avaliação da qualidade da evidência pelo GRADE dos estudos que avaliaram a profilaxia na população exposta à _Brucella_ sp -->
|||**Avaliação da**|**certeza da evi**|**dência**|||**№ de paci**|**entes**|**Ef**|**eito**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Ris-co de**<br>**viés**|**Inconsis-**<br>**tência**|**Evidência**<br>**indireta**|**Impre-**<br>**cisão**|**Outras**<br>**conside-**<br>**rações**|**Antimicro-**<br>**bianos**|**Qual-quer**<br>**compa-**<br>**rador**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Certeza**|**Importância**|
|**Casos de Br**|**ucelose**||||||||||||
|11|10 séries de casos<br>1 transversal|Grave<sup>a</sup>|não grave|Muito grave<sup>c</sup>|grave<sup>d</sup>||2/150 (1,3%)|-|-|-|⨁◯◯◯<br>Muito baixa|Crítico|
|**Eventos adv**|**ersos**||||||||||||
|6|Série de casos|grave<sup>a</sup>|grave<sup>b</sup>|Muito grave<sup>c</sup>|grave<sup>d</sup>||19/69 (27,5%)|-|-|-|⨁◯◯◯<br>Muito baixa|Crítico|
|**Adesão ao tr**|**atamento**||||||||||||
|7|Série de casos|grave<sup>a</sup>|grave<sup>b</sup>|muito gra-ve<sup>c</sup>|grave<sup>d</sup>||72/84 (85,7%)|-|-|-|⨁◯◯◯<br>Muito baixa|Importante|  
Explicações:  
a. O risco de viés foi julgado como grave, considerando aplicação da ferramenta JBI. Todos os estudos foram penalizados pela ausência de características demográficas e clínicas dos participantes.  
b. No desfecho de eventos adversos e adesão ao tratamento os estudos apresentam resultados divergentes.  
c. Considerou-se muito grave, pela ausência de comparador uma vez que não é possível estimar se fazer profilaxia com antimicrobianos é melhor do que não fazer.  
d. Evidência gerada a partir de poucos estudos, com tamanho amostral reduzido.  
196

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Tabela para tomada de decisão (** **_Evidence to Decision table_ - EtD):** -->
Apresenta-se o processo de formulação de recomendações por meio de um painel de especialistas conduzido em dezembro de 2023. Nesse painel foram formuladas recomendações sobre o uso dos esquemas terapêuticos para o tratamento da brucelose humana em gestantes, baseando-se nas contribuições do painel de especialistas e apoiado pela síntese de evidências realizada pelo grupo elaborador.  
A **Tabela N** apresenta o processo de tomada de decisão sobre profilaxia pós exposição para a exposição acidental à brucelose, baseando-se nas contribuições do painel de especialistas, na síntese de evidências realizada pelo grupo elaborador e nas informações das diretrizes e dos documentos (bula, por exemplo) sobre essa tecnologia.  
Tabela N. Processo de tomada de decisão referente à recomendação da profilaxia pós exposição para a exposição acidental à brucelose  
|**Item da EtD**|**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|---|
|Efeitos desejáveis|Moderado|Revisão da literatura desenvolvida pelo NATS:<br>Taxa de ocorrência de brucelose humana pós<br>exposição com uso de profilaxia: 2/142 (1,4%)<br>(acidentes em laboratório de diagnóstico e acidente<br>vacinal)<br>Votação painel: moderado (5) / grande (1)<br>Os<br>estudos<br>não<br>conseguem<br>correlacionar<br>informações importantes e em detalhes sobre via de<br>exposição, carga bacteriana, características clínicas<br>dosparticipantes,exposições anteriores.|
|Efeitos<br>indesejáveis|Moderado|Efeito indesejável do tratamento<br>Votação painel: Abstenção (1) / pequeno (2) /<br>moderado (3)<br>Exposição ocupacional repetida de profissionais<br>(contato com animais, acidentes no laboratório)<br>Dados da revisão: Taxa de eventos adversos: 37/94<br>(39.4%) (n=7)|
|Certeza da<br>evidência:|Muito baixa|GRADE: certeza da evidência muito baixa<br>(desfechos casos de brucelose; taxa de eventos<br>adversos e taxa de adesão).<br>Votaçãopainel:unanimidade|
|Balanço de efeitos|Provavelmente<br>favorece a<br>intervenção|Considerando<br>a<br>sintomatologia<br>inespecífica,<br>morbidade e dificuldade diagnóstica da doença a<br>PEP pode ser benéfica a despeito das reações<br>adversas que foram consideradas de fácil manejo.<br>Ademais, a taxa de adesão ao tratamento foi de<br>83,6%, indicando boa tolerabilidade.<br>Dentre os estudos avaliados na RS, nenhum<br>paciente de alto risco exposto à_Brucella_sp. que<br>não realizou profilaxia desenvolveu a doença.<br>**Comentários do painel:**|  
197  
|**Item da EtD**<br>**Julgamento dos**<br>**painelistas**|**Justificativa**|
|---|---|
||Há diferentes considerações a depender do tipo de<br>exposição (conforme comorbidades, características<br>dos participantes)<br>Não há literatura quer aponte que a exposição leva<br>ao desenvolvimento da doença diferenças podem<br>ser pontuadas para cada tipo de exposição.<br>Votação painel: a favor (2) provavelmente a favor<br>(4) Área técnica relatou número crescente de<br>acidentes vacinais.<br>Uso da vacina RB51 (vacina modificada, de cultura<br>viva), que não induz anticorpos detectados por<br>sorologia e cepa resistente à rifampicina.|
|Recursos<br>necessários:<br>Grandes economias|Doxiciclina (200 mg/dia/21 dias) + rifampicina<br>(600 mg/dia/21 dias)<br>R$28,94 (compra MS) - R$ 132,95 (BPS)<br>**Comentários**<br>**do**<br>**painel**:<br>custos<br>indiretos<br>relacionados ao absenteísmo.<br>|
||Votação dopainel: grande economia(6)|
|Equidade:<br>Aumento|Acesso a profilaxia pós exposição:<br>Disponibilizar uma profilaxia representa resposta a<br>uma demanda ocupacional.<br>Rifampicina não é amplamente disponibilizada,<br>compra centralizada pelo Ministério da Saúde,<br>podendo ser esse contexto uma barreira ao acesso.<br>Votação do painel: provavelmente aumenta (2)<br>aumenta(4)|
|Aceitabilidade:<br>Provavelmente sim|PACIENTE Percentual de indivíduos de alto risco<br>que não aceitaram fazer a profilaxia: 27/141<br>(19,15%) (9 estudos incluídos)<br>Taxa de adesão ao tratamento: 72/84 (85,7%) (n=7)<br>GESTOR E PROFISSIONAL<br>Não requer grandes mudanças em termos<br>organizacionais ou estruturais dos serviços de<br>saúde.<br>Requer capacitação dos profissionais quanto à<br>identificação e classificação do risco de exposição<br>e monitoramento do tratamento (toxicidade).<br>Requer estabelecimento de redes de referência para<br>garantir acesso ao tratamento em tempo oportuno.<br>Considerações do painel: Há diferenças a depender<br>do esquema terapêutico proposto. Votação do<br>painel: sim (1) provavelmente sim (5).<br>OBS: Intervenções para melhorar a aceitabilidade<br>da PEP e monitoramento|
|Viabilidade de<br>implementação:<br>Sim|O esquema já está disponível na RENAME e faz<br>parte do CESAF.<br>Votação dopainel: sim(6)|
|Fonte: Autoria própria.||  
198

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: **Recomendação:** -->
Recomendação a favor e condicional a favor da PEP na exposição acidental, devido à baixa certeza da evidência. Os riscos inerentes a não fazer PEP, como adoecimento, geram custos diretos e indiretos. Ainda, o perfil de tolerância da PEP é aceitável.  
Considerações para subgrupos: Foram discutidas a exposição em laboratório e a exposição vacinal RB51. Outras exposições não foram discutidas no painel. Considerar o contexto para definição da PEP:  
- Cenário de exposição (ambientes e locais de exposição, cepa para qual ocorreu a exposição)  
- Escolha do esquema  
Considerações para implementação: Orientações diferenciadas conforme o tipo de exposição - definir cada uma das vias para melhor orientar os profissionais na classificação da exposição; Disponibilidade da intervenção de forma descentralizada (operacionalização), ações de monitoramento necessárias para a implementação da PEP.  
Acompanhamento e avaliação: Acompanhamento clínico e laboratorial dos usuários (verificar sugestão do protocolo do PR); Monitoramento da intervenção em termos epidemiológicos (notificação, vigilância) com possibilidade de criar indicadores.  
Prioridades em pesquisa: Estudos longitudinais para identificar a taxa de desenvolvimento da _Brucella_ sp. após o uso do PEP e perfil de eventos adversos.  
199

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: Referências -->
1.         Dean, A. S., Crump, L., Greter, H., Schelling, E. & Zinsstag, J. Global Burden of Human Brucellosis: A Systematic Review of Disease Frequency. _PLoS Negl Trop Dis_ **6** , e1865–e1865 (2012).  
2. Pappas, G., Papadimitriou, P., Akritidis, N., Christou, L. & Tsianos, E. V. The new global map of human brucellosis. _Lancet Infect Dis_ **6** , 91–99 (2006).  
3. Corbel, M. J. _Brucellosis in Humans and Animals_ . (World Health Organization, 2006).  
4. Laine, C. G., Scott, H. M. & Arenas-Gamboa, A. M. Human brucellosis: Widespread information deficiency hinders an understanding of global disease frequency. _PLoS Negl Trop Dis_ **16** , e0010404–e0010404 (2022).  
5. Bosilkovski, M., Edwards, M. S. & Calderwood, S. B. Brucellosis: epidemiology, microbiology, clinical manifestations, and diagnosis. _Uptodate, United States_ (2019).  
6. Laine, C. G., Johnson, V. E., Scott, H. M. & Arenas-Gamboa, A. M. Global estimate of human brucellosis incidence. _Emerg Infect Dis_ **29** , 1789 (2023).  
7. Bourdette, M. D. S. & Sano, E. Características Epidemiológicas da Brucelose Humana no Brasil no período 2014-2018. _Revista Cereus_ **15** , 27–40 (2023).  
8. Santa Catarina. Secretaria de Estado de Santa Catarina. Superintendência de Vigilância em Saúde. Diretoria de Vigilância Epidemiológica. Gerência de Vigilância de Zoonoses, A. por A. P. e D. T. por V. Protocolo Estadual de Brucelose Humana - Manejo Clínico e Vigilância em Saúde . _https://dive.sc.gov.br/phocadownload/doencas-_  
- _agravos/Brucelose/Publica%C3%A7%C3%B5es/1%20-_  
_%20Protocolo%20estadual%20de%20brucelose%20humana%20-_  
- _%20Manejo%20Cl%C3%ADnico%20e%20Vigil%C3%A2ncia%20em%20Sa%C3%BAde.pdf_ 1–38 Preprint at (2019).  
9. Paraná. Secretaria de Estado da Saúde do Paraná. Superintendência de Vigilância em Saúde. Protocolo de manejo clínico e vigilância em saúde para brucelose humana no Estado do Paraná. – Curitiba: SESA/SVS/CEVA. _https://www.saude.pr.gov.br/sites/default/arquivos_restritos/files/documento/202004/protocolobrucelose2018.pdf_ 1–96 Preprint at (2018).  
10. Tocantins. Portaria/SESAU n<sup>o</sup> 1.482, de 18 de dezembro de 2015. Define a relação de doenças e agravos de notificação compulsória de interesse para o Estado do Tocantins. Diário Oficial do Estado do Tocantins. 10 de Março de 2016.p.17.  
11. Roraima. Comissão Intergestores Bipartite/RO. RESOLUÇÃO N<sup>o</sup> 301/13 – CIB / RO. (2013).  
12. Minas Gerais. Secretaria de Estado de Saúde de Minas Gerais. Coordenação de Zoonoses Vigilância de Fatores de Riscos Biológicos. Atualização nas orientações das ações da vigilância da brucelose humana. _http://vigilancia.saude.mg.gov.br/index.php/saude-do-trabalhador/_ (2021).  
13. Bernardi, F. _et al._ Epidemiological characterization of notified human brucellosis cases in Southern Brazil. _Rev Inst Med Trop Sao Paulo_ **64** , e38 (2022).  
14. Lemos, T. S. _et al._ Outbreak of human brucellosis in Southern Brazil and historical review of data from 2009 to 2018. _PLoS Negl Trop Dis_ **12** , e0006770 (2018).  
200  
15. Corbel, M. J. Brucellosis: an overview. _Emerg Infect Dis_ **3** , 213 (1997).  
16. Lilia Guzman-Hernandez, R., Contreras-Rodriguez, A., Daniel Avila-Calderon, E. & Rosario Morales-Garcia, M. Brucellosis: a zoonosis of importance in Mexico. _Revista Chilena de Infectologia_ **33** , 656–662 (2016).  
17. Tuon, F. F., Gondolfo, R. B. & Cerchiari, N. Human‐to‐human transmission of Brucella–a systematic review. _Tropical Medicine & International Health_ **22** , 539–546 (2017).  
18. Dias, E. C. & Almeida, I. M. Doenças relacionadas ao trabalho: manual de procedimentos para os serviços de saúde. Brasília: Ministério da Saúde do Brasil (2001).  
19. Pereira, C. R. _et al._ Occupational exposure to Brucella spp.: A systematic review and metaanalysis. _PLoS Negl Trop Dis_ **14** , 1–19 (2020).  
20. Yagupsky, P. Preventing laboratory-acquired brucellosis in the era of MALDI-TOF technology and molecular tests: A narrative review. _Zoonotic Diseases_ **2** , 172–182 (2022).  
21. Yagupsky, P. Neonatal brucellosis: rare and preventable. _Ann Trop Paediatr_ **30** , 177–179 (2010).  
22. Giannacopoulos, I., Eliopoulou, M. I., Ziambaras, T. & Papanastasiou, D. A. Transplacentally transmitted congenital brucellosis due to Brucella abortus. _J Infect_ **45** , 209–210 (2002).  
23. Kato, Y. _et al._ Brucellosis in a Returned Traveler and His Wife: Probable Person‐To‐Person Transmission of Brucella melitensis. _J Travel Med_ **14** , 343–345 (2007).  
24. Mantur, B. G., Mangalgi, S. & Mulimani, M. Brucella melitensis—a sexually transmissible agent? _The lancet_ **347** , 1763 (1996).  
25. Wood, E. E. Brucellosis as a hazard of blood transfusion. _Br Med J_ **1** , 27 (1955).  
26. Tikare, N. V, Mantur, B. G. & Bidari, L. H. Brucellar meningitis in an infant—evidence for human breast milk transmission. _J Trop Pediatr_ **54** , 272–274 (2008).  
27. Palanduz, A., Palanduz, S., Guler, K. & Guler, N. Brucellosis in a mother and her young infant: probable transmission by breast milk. _International journal of infectious diseases_ **4** , 55 (2000).  
28. Lubani, M., Sharda, D. & Helin, I. Probable transmission of brucellosis from breast milk to a newborn. _Trop Geogr Med_ **40** , 151–152 (1988).  
29. Arenas-Gamboa, A. M. _et al._ Human brucellosis and adverse pregnancy outcomes. Curr Trop Med Rep 3: 164–172. Preprint at (2016).  
30. Ali, S. _et al._ Brucellosis in pregnant women from Pakistan: an observational study. _BMC Infect Dis_ **16** , 1–6 (2016).  
31. Dean, A. S. _et al._ Clinical manifestations of human brucellosis: a systematic review and metaanalysis. _PLoS Negl Trop Dis_ **6** , e1929 (2012).  
32. Mantur, B. G., Amarnath, S. K. & Shinde, R. S. Review of clinical and laboratory features of human brucellosis. _Indian J Med Microbiol_ **25** , 188–202 (2007).  
33. Young, E. J. Brucellosis: current epidemiology, diagnosis, and management. _Curr Clin Top Infect Dis_ **15** , 115–128 (1995).  
34. Bosilkovski, M. _et al._ Osteoarticular involvement in childhood brucellosis: experience with 133 cases in an endemic region. _Pediatr Infect Dis J_ **32** , 815–819 (2013).  
201  
35. Bosilkovski, M., Krteva, L., Caparoska, S. & Dimzova, M. Osteoarticular involvement in brucellosis: study of 196 cases in the Republic of Macedonia. _Croat Med J_ (2004).  
36. Araj, G. F. Update on laboratory diagnosis of human brucellosis. _Int J Antimicrob Agents_ **36** , S12–S17 (2010).  
37. Meechan, P. J. & Potts, J. Biosafety in microbiological and biomedical laboratories. (2020).  
38. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. Departamento do Complexo Industrial e Inovação em Saúde. Classificação de Risco Dos Agentes Biológicos, (Brasília, 2022).  
39. Yagupsky, P., Morata, P. & Colmenero, J. D. Laboratory diagnosis of human brucellosis. _Clin Microbiol Rev_ **33** , 10–1128 (2019).  
40. Skalsky, K. _et al._ Treatment of human brucellosis: systematic review and meta-analysis of randomised controlled trials. _Bmj_ **336** , 701–704 (2008).  
41. Yousefi‐Nooraie, R., Mortaz‐Hejri, S., Mehrani, M. & Sadeghipour, P. Antibiotics for treating human brucellosis. _Cochrane Database of Systematic Reviews_ (2012) doi:10.1002/14651858.CD007179.pub2.  
42. BRASIL. Ministério da Saúde. _Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas_ . (Brasília, 2016).  
43. Guyatt, G. H. _et al._ GRADE: an emerging consensus on rating quality of evidence and strength of recommendations. _BMJ_ **336** , 924–926 (2008).  
44. Liu, Z. _et al._ Different Clinical Manifestations of Human Brucellosis in Pregnant Women: A Systematic Scoping Review of 521 Cases from 10 Countries. _Infect Drug Resist_ **13** , 1067–1079 (2020).  
45. Khazaei, S. _et al._ Epidemiology of human brucellosis in Nahavand county, Hamadan Province, western Iran: an 8-year (2010–2017) registry-based analysis. _Asian Biomedicine_ **14** , 151–158 (2020).  
46. Al Shaalan, M. _et al._ Brucellosis in children: clinical observations in 115 cases. _International journal of infectious diseases_ **6** , 182–186 (2002).  
47. Mantur, B. G. _et al._ Childhood brucellosis—a microbiological, epidemiological and clinical study. _J Trop Pediatr_ **50** , 153–157 (2004).  
48. Tanir, G., Tufekci, S. B. & Tuygun, N. Presentation, complications, and treatment outcome of brucellosis in Turkish children. _Pediatrics International_ **51** , 114–119 (2009).  
49. Al Hashan, G. M. _et al._ Pattern of childhood brucellosis in Najran, south Saudi Arabia in 2013– 2017. _Electron Physician_ **9** , 5902 (2017).  
50. Parlak, M. _et al._ Clinical manifestations and laboratory findings of 496 children with brucellosis in V an, T urkey. _Pediatrics International_ **57** , 586–589 (2015).  
51. Dashti, A. S. & Karimi, A. Skeletal involvement of Brucella melitensis in children: a systematic review. _Iran J Med Sci_ **38** , 286 (2013).  
52. Galvão, E. L. _et al._ Treatment of Childhood Brucellosis: A Systematic Review. _Pediatr Infect Dis J_ 10–1097.  
202  
53. Niebyl, J. R. Antibiotics and other anti-infective agents in pregnancy and lactation. _Am J Perinatol_ **20** , 405–414 (2003).  
54. Yefet, E. _et al._ The safety of quinolones and fluoroquinolones in pregnancy: a meta‐analysis. _BJOG_ **125** , 1069–1076 (2018).  
55. Centers for Disease Control and Prevention. Brucellosis Reference Guide: Exposures, Testing, And Prevention. 1–40 Preprint at (2017).  
56. Jiang, H., Feng, L. & Lu, J. Updated Guidelines for the Diagnosis of Human Brucellosis — China, 2019. _China CDC Wkly_ **2** , 487–489 (2020).  
57. Mousa, A. R. M., Elbag, K. M., Kbogali, M. & Marafie, A. A. The nature of human brucellosis in Kuwait: study of 379 cases. _Rev Infect Dis_ **10** , 211–217 (1988).  
58. Kitt, E. _et al._ A case report of pediatric brucellosis in an Algerian immigrant. in _Open forum infectious diseases_ vol. 4 ofw263 (Oxford University Press US, 2017).  
59. Al Shamahy, H. A. & Wright, S. G. A study of 235 cases of human brucellosis in Sana’a, Republic of Yemen. _EMHJ-Eastern Mediterranean Health Journal, 7 (1-2), 238-246, 2001_ (2001).  
60. Zheng, R. _et al._ A systematic review and meta‐analysis of epidemiology and clinical manifestations of human brucellosis in China. _Biomed Res Int_ **2018** , 5712920 (2018).  
61. World Health Organization. Brucellosis. _https://www.who.int/news-room/factsheets/detail/brucellosis_ (2020).  
62. Pappas, G., Akritidis, N., Bosilkovski, M. & Tsianos, E. Brucellosis. _New England Journal of Medicine_ **352** , 2325–2336 (2005).  
63. Roushan, M. R. H., Mohrez, M., Gangi, S. M. S., Amiri, M. J. S. & Hajiahmadi, M. Epidemiological features and clinical manifestations in 469 adult patients with brucellosis in Babol, Northern Iran. _Epidemiol Infect_ **132** , 1109–1114 (2004).  
64. Castano, M. J. & Solera, J. Chronic brucellosis and persistence of Brucella melitensis DNA. _J Clin Microbiol_ **47** , 2084–2089 (2009).  
65. Galinska, E. M. & Zagórski, J. Brucellosis in humans-etiology, diagnostics, clinical forms. _Annals of agricultural and environmental medicine_ **20** , (2013).  
66. Trujillo, I. Z., Zavala, A. N., Caceres, J. G. & Miranda, C. Q. Brucellosis Infect Dis Clin North Am, 8 (1994). _View PDF View article View in Scopus_ 225–241.  
67. Gray, B. M., Evans, A. & Brachman, P. Bacterial infections of humans: epidemiology and control. Preprint at (1991).  
68. Doganay, M. & Aygen, B. Human brucellosis: an overview. _International Journal of Infectious Diseases_ **7** , 173–182 (2003).  
69. Bukhari, E. E. Pediatric brucellosis: an update review for the new millennium. _Saudi Med J_ **39** , 336 (2018).  
70. Bosilkovski, M., Krteva, L., Dimzova, M. & Kondova, I. Brucellosis in 418 patients from the Balkan Peninsula: exposure-related differences in clinical manifestations, laboratory test results, and therapy outcome. _International journal of infectious diseases_ **11** , 342–347 (2007).  
71. Pappas, G. _et al._ Brucellosis and the respiratory system. _Clinical Infectious Diseases_ **37** , e95–e99 (2003).  
203  
72. Espinosa, B. J. _et al._ Comparison of culture techniques at different stages of brucellosis. _Am J Trop Med Hyg_ **80** , 625–627 (2009).  
73. Mangalgi, S. & Sajjan, A. Comparison of three blood culture techniques in the diagnosis of human brucellosis. _J Lab Physicians_ **6** , 14–17 (2014).  
74. Alsayed, Y. & Monem, F. Brucellosis laboratory tests in Syria: what are their diagnostic efficacies in different clinical manifestations? _The Journal of Infection in Developing Countries_ **6** , 495–500 (2012).  
75. Hajia, M. _et al._ Comparison of methods for diagnosing brucellosis. _Lab Med_ **44** , 29–33 (2013).  
76. Freire, M. L., Machado de Assis, T. S., Silva, S. N. & Cota, G. Diagnosis of human brucellosis: Systematic review and meta-analysis. _PLoS Negl Trop Dis_ **18** , e0012030 (2024).  
77. Landry, M. L. Immunoglobulin M for acute infection: true or false? _Clinical and Vaccine Immunology_ **23** , 540–545 (2016).  
78. Takahashi, H. _et al._ An unusual case of brucellosis in Japan: difficulties in the differential diagnosis from pulmonary tuberculosis. _Internal medicine_ **35** , 310–314 (1996).  
79. Ulu Kilic, A., Metan, G. & Alp, E. Clinical presentations and diagnosis of brucellosis. _Recent Pat Antiinfect Drug Discov_ **8** , 34–41 (2013).  
80. Guler, S. _et al._ Human brucellosis in Turkey: different clinical presentations. _The Journal of Infection in Developing Countries_ **8** , 581–588 (2014).  
81. Esmaeilnejad-Ganji, S. M. & Esmaeilnejad-Ganji, S. M. R. Osteoarticular manifestations of human brucellosis: a review. _World J Orthop_ **10** , 54 (2019).  
82. Solís García del Pozo, J. & Solera, J. Systematic review and meta-analysis of randomized clinical trials in the treatment of human brucellosis. _PLoS One_ **7** , e32090 (2012).  
83. Huang, S. _et al._ Better efficacy of triple antibiotics therapy for human brucellosis: A systematic review and meta-analysis. _PLoS Negl Trop Dis_ **17** , e0011590 (2023).  
84. Silva, S. N. _et al._ Efficacy and safety of therapeutic strategies for human brucellosis: A systematic review and network meta-analysis. _PLoS Negl Trop Dis_ **18** , e0012010 (2024).  
85. Majzoobi, M. M., Hashmi, S. H., Emami, K. & Soltanian, A. R. Combination of doxycycline, streptomycin and hydroxychloroquine for short-course treatment of brucellosis: a single-blind randomized clinical trial. _Infection_ **50** , 1267–1271 (2022).  
86. Majzoobi, M. M. _et al._ Effect of hydroxychloroquine on treatment and recurrence of acute brucellosis: a single-blind, randomized clinical trial. _Int J Antimicrob Agents_ **51** , 365–369 (2018).  
87. de Jesus Lawinsky, M. L., Ohara, P. M., da Rosa Elkhoury, M., do Carmo Faria, N. & Cavalcante, K. R. L. J. Estado da arte da brucelose em humanos. _Rev Panamazonica Saude_ **1** , 10 (2010).  
88. Pappas, G., Siozopoulou, V., Akritidis, N. & Falagas, M. E. Doxycycline–rifampicin: Physicians’ inferior choice in brucellosis or how convenience reigns over science. _Journal of Infection_ **54** , 459–462 (2007).  
89. Pappas, G. _et al._ Health literacy in the field of infectious diseases: the paradigm of brucellosis. _Journal of Infection_ **54** , 40–45 (2007).  
90. Sánchez, A. R., Rogers III, R. S. & Sheridan, P. J. Tetracycline and other tetracycline‐derivative staining of the teeth and oral cavity. _Int J Dermatol_ **43** , 709–715 (2004).  
204  
91. Inan, A. _et al._ Brucellosis in pregnancy: results of multicenter ID-IRI study. _Eur J Clin Microbiol Infect Dis_ **38** , 1261–1268 (2019).  
92. Roushan, M. R. H., Baiani, M., Asnafi, N. & Saedi, F. Outcomes of 19 pregnant women with brucellosis in Babol, northern Iran. _Trans R Soc Trop Med Hyg_ **105** , 540–542 (2011).  
93. Khan, M. Y., Mah, M. W. & Memish, Z. A. Brucellosis in pregnant women. _Clin Infect Dis_ **32** , 1172–1177 (2001).  
94. Yu, P. A. _et al._ Safety of antimicrobials during pregnancy: a systematic review of antimicrobials considered for treatment and postexposure prophylaxis of plague. _Clinical Infectious Diseases_ **70** , S37–S50 (2020).  
95. Brasil. Ministério da Saúde. MedSUS. _https://www.gov.br/pt-br/apps/medsus_ .  
96. Roushan, M. R. H. _et al._ Efficacy of gentamicin plus doxycycline versus streptomycin plus doxycycline in the treatment of brucellosis in humans. _Clinical infectious diseases_ **42** , 1075–1080 (2006).  
97. Roushan, M. R. H. _et al._ Comparison of the efficacy of gentamicin for 5 days plus doxycycline for 8 weeks  versus streptomycin for 2 weeks plus doxycycline for 45 days in the treatment of human brucellosis: a randomized clinical trial. _J Antimicrob Chemother_ **65** , 1028–1035 (2010).  
98. Bosilkovski, M., Krteva, L., Caparoska, S., Labacevski, N. & Petrovski, M. Childhood brucellosis: Review of 317 cases. _Asian Pac J Trop Med_ **8** , 1027–1032 (2015).  
99. El-Amin, E. O. _et al._ Brucellosis in children of Dhofar Region, Oman. _Saudi Med J_ **22** , 610–615 (2001).  
100. Zamani, A. _et al._ Epidemiological and clinical features of Brucella arthritis in 24 children. _Ann Saudi Med_ **31** , 270–273 (2011).  
101. Sánchez-Tamayo, T. _et al._ Failure of short-term antimicrobial therapy in childhood brucellosis. _Pediatr Infect Dis J_ **16** , 323–324 (1997).  
102. Brasil. Ministério da Saúde. Ampliação de uso dos medicamentos doxiciclina, estreptomicina e rifampicina para o tratamento da brucelose humana. _Disponível em: https://www.gov.br/conitec/pt-_  
- _br/midias/relatorios/2017/relatorio_doxiciclinaestreptomicinarifampicina_brucelose_final.pdf_ (2017).  
103. Bac-Sulfitrin solução injetável. Anápolis: Brainfarma Indústria Química e Farmacêutica S.A; 2.  bula de medicamento. Disponível em: https://www.gov.br/anvisa/pt-br/sistemas/bularioeletronico. (2021).  
104. Memish, Z. A. & Mah, M. W. Brucellosis in laboratory workers at a Saudi Arabian hospital. _Am J Infect Control_ **29** , 48–52 (2001).  
105. Sophie, R., Michael, L., Marcel, B. & Earl, R. Prevention of laboratory-acquired brucellosis. _Clinical Infectious Diseases_ **38** , e119–e122 (2004).  
106. Centers for Disease Control and Prevention (CDC). Update: potential exposures to attenuated vaccine strain Brucella abortus RB51 during a laboratory proficiency test--United States and Canada, 2007. _MMWR Morb Mortal Wkly Rep_ **57** , 36–39 (2008).  
107. Centers for Disease Control and Prevention (CDC). Assessing Laboratory Risk Level & PEP. _https://www.cdc.gov/brucellosis/laboratories/risk-level.html_ (2018).  
205  
108. Pereira, C. R. _et al._ Accidental exposure to Brucella abortus vaccines and occupational brucellosis among veterinarians in Minas Gerais state, Brazil. _Transbound Emerg Dis_ **68** , 1363–1376 (2021).  
109. Pereira Santos, H. _et al._ Brucelose bovina e humana diagnosticada em matadouro municipal de São Luís-MA, Brasil. _Ciência Veterinária nos Trópicos_ **10** , 86–94 (2007).  
110. Ramos, T. R. R. _et al._ Epidemiological aspects of an infection by Brucella abortus in risk occupational groups in the microregion of Araguaina, Tocantins. _Brazilian Journal of Infectious Diseases_ **12** , 133–138 (2008).  
111. Tuon, F. F., Cequinel, J. C., da Silva Nogueira, K. & Becker, G. N. Brucella Laboratory Exposures in Brazil: Rare or Unnoticed? _Am J Trop Med Hyg_ **103** , 2528 (2020).  
112. Rodrigues, A. L. C., Silva, S. K. L. da, Pinto, B. L. A., Silva, J. B. da & Tupinambás, U. Outbreak of laboratory-acquired Brucella abortus in Brazil: a case report. _Rev Soc Bras Med Trop_ **46** , 791– 794 (2013).  
113. Centers for Disease Control and Prevention (CDC). Laboratory-acquired brucellosis--Indiana and Minnesota, 2006. _MMWR Morb Mortal Wkly Rep_ **57** , 39–42 (2008).  
114. Castrodale, L. J. _et al._ A case-study of implementation of improved strategies for prevention of laboratory-acquired brucellosis. _Saf Health Work_ **6** , 353–356 (2015).  
115. Miendje Deyi, V. Y. _et al._ Staggered enforcement of infection control and prevention measures following four consecutive potential laboratory exposures to imported Brucella melitensis. _Infection Prevention in Practice_ **3** , (2021).  
116. Maley, M. W., Kociuba, K. & Chan, R. C. Prevention of laboratory-acquired brucellosis: Significant side effects of prophylaxis [3]. _Clinical Infectious Diseases_ **42** , 433–434 (2006).  
117. Reddy, S. _et al._ Brucellosis in the UK: A risk to laboratory workers? Recommendations for prevention and management of laboratory exposure. _J Clin Pathol_ **63** , 90–92 (2010).  
118. Sam, I.-C. _et al._ A large exposure to Brucella melitensis in a diagnostic laboratory. _J Hosp Infect_ **80** , 321–325 (2012).  
119. Traxler, R. M. _et al._ Review of brucellosis cases from laboratory exposures in the United States in 2008 to 2011 and improved strategies for disease prevention. _J Clin Microbiol_ **51** , 3132–3136 (2013).  
120. Wong, C., Ng, S. Y. & Tan, S. H. An accidental laboratory exposure to Brucella melitensis: The prospective post-exposure management and a detailed investigation into the nature of the exposure. _J Med Microbiol_ **67** , 1012–1016 (2018).  
121. Nichols, M. _et al._ Brucella abortus Exposure during an Orthopedic Surgical Procedure in New Mexico, 2010. _Infect Control Hosp Epidemiol_ **35** , 1072–1073 (2014).  
122. Ashford, D. A. _et al._ Adverse events in humans associated with accidental exposure to the livestock brucellosis vaccine RB51. _Vaccine_ **22** , 3435–3439 (2004).  
123. Nascimento Silva, S. _et al._ Efficacy of antibiotic prophylaxis to preventing brucellosis in accidental exposure: A systematic review. _Tropical Medicine & International Health_ **29** , 454– 465 (2024).  
124. Al Dahouk, S. & Nöckler, K. Implications of laboratory diagnosis on brucellosis therapy. _Expert Rev Anti Infect Ther_ **9** , 833–845 (2011).  
206  
125. Cossaboom, C. M. _et al._ Notes from the field: Brucella abortus vaccine strain RB51 infection and exposures associated with raw milk consumption—Wise County, Texas, 2017. _Morbidity and Mortality Weekly Report_ **67** , 286 (2018).  
126. National Center for Emerging and Zoonotic Infectious Diseases (U.S.). Brucellosis reference guide : exposures, testing and prevention. Preprint at https://stacks.cdc.gov/view/cdc/46133 (2017).  
127. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Plano de ação nacional de prevenção e controle da resistência aos antimicrobianos no âmbito da saúde única 2018-2022 (PAN-BR). _https://bvsms.saude.gov.br/bvs/publicacoes/plano_prevencao_resistencia_antimicrobianos.pdf_ Preprint at (2019).  
128. Pauletti, R. B. susceptibilidade de isolados brasileiros de brucella abortus a agentes antimicrobianos utilizados no tratamento da brucelose humana. [Dissertação]. Belo Horizonte: Escola de veterinária, Universidade Federal de Minas Gerais; 2010. 51 s. Mestrado em Ciência Animal.  
129. De Rautlin de la Roy, Y. M. et al., Grignon, B., Grollier, G., Coindreau, M. F. & Becq-Giraudon, B. Rifampicin resistance in a strain of Brucella melitensis after treatment with doxycycline and rifampicin. Journal of Antimicrobial Chemotherapy 18, 648–649 (1986).  
130. Al-Sibai, M. B. & Qadri, S. M. H. Development of ciprofloxacin resistance in Brucella melitensis. _Journal of Antimicrobial Chemotherapy_ **25** , 302–303 (1990).  
131. Memish, Z., Mah, M. W., Al Mahmoud, S., Al Shaalan, M. & Khan, M. Y. Brucella bacteraemia: clinical and laboratory observations in 160 patients. _Journal of infection_ **40** , 59–63 (2000).  
132. Almuneef, M. _et al._ Brucella melitensis Bacteremia in Children: Review of 62 Cases. _Journal of Chemotherapy_ **15** , 76–80 (2003).  
133. Bannatyne, R. M., Rich, M. & Memish, Z. A. Co-trimoxazole resistant Brucella. _J Trop Pediatr_ **47** , 60 (2001).  
134. Baykam, N. _et al._ In vitro antimicrobial susceptibility of Brucella species. _Int J Antimicrob Agents_ **23** , 405–407 (2004).  
135. Dimitrov, T. S. _et al._ Incidence of bloodstream infections in a speciality hospital in Kuwait: 8- year experience. _Medical Principles and Practice_ **14** , 417–421 (2005).  
136. Liu, Z. _et al._ In vitro antimicrobial susceptibility testing of human Brucella melitensis isolates from Ulanqab of Inner Mongolia, China. _BMC Infect Dis_ **18** , 1–6 (2018).  
137. Moradkasani, S., Goodarzi, F., Beig, M., Tadi, D. A. & Sholeh, M. Prevalence of Brucella melitensis and Brucella abortus aminoglycoside-resistant isolates: a systematic review and metaanalysis. _Brazilian Journal of Microbiology_ 1–11 (2024).  
138. Abutarbush, S. M. Veterinary medicine—a textbook of the diseases of cattle, horses, sheep, pigs and goats. _The Canadian veterinary journal_ **51** , 541 (2010).  
139. Grilló, M. J. _et al._ Efficacy of several antibiotic combinations against Brucella melitensis Rev 1 experimental infection in BALB/c mice. _Journal of Antimicrobial Chemotherapy_ **58** , 622–626 (2006).  
207  
140. Schurig, G. G. _et al._ Biological properties of RB51; a stable rough strain of Brucella abortus. _Vet Microbiol_ **28** , 171–188 (1991).  
141. Barbosa Pauletti, R. _et al._ Reduced susceptibility to Rifampicin and resistance to multiple antimicrobial agents among Brucella abortus isolates from cattle in Brazil. _PLoS One_ **10** , e0132532 (2015).  
142. Le, T. A. _et al._ Aminoglycoside-Related Nephrotoxicity and Ototoxicity in Clinical Practice: A Review of Pathophysiological Mechanism and Treatment Options. _Adv Ther_ **40** , 1357–1365 (2023).  
143. Mendeley. Mendeley Reference Manager. Preprint at https://www.mendeley.com/referencemanager/library/all-references (2023).  
144. Ouzzani, M., Hammady, H., Fedorowicz, Z. & Elmagarmid, A. Rayyan—a web and mobile app for systematic reviews. _Syst Rev_ **5** , 210 (2016).  
145. Whiting, P. F. _et al._ QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. _Ann Intern Med_ **155** , 529–536 (2011).  
146. Sterne, J. A. C. _et al._ RoB 2: a revised tool for assessing risk of bias in randomised trials. _bmj_ **366** , (2019).  
147. Munn, Z. _et al._ Methodological quality of case series studies: an introduction to the JBI critical appraisal tool. _JBI Evid Synth_ **18** , 2127–2133 (2020).  
148. Atkins, D. _et al._ Systems for grading the quality of evidence and the strength of recommendations I: Critical appraisal of existing approaches The GRADE Working Group. _BMC Health Serv Res_ **4** , 38 (2004).  
149. Moberg, J. _et al._ The GRADE Evidence to Decision (EtD) framework for health system and public health decisions. _Health Res Policy Syst_ **16** , 45 (2018).  
150. Schünemann, H. J. _et al._ GRADE Evidence to Decision (EtD) frameworks for adoption, adaptation, and de novo development of trustworthy recommendations: GRADEADOLOPMENT. _J Clin Epidemiol_ (2017) doi:10.1016/j.jclinepi.2016.09.009.  
151. Page, M. J. _et al._ The PRISMA 2020 statement: an updated guideline for reporting systematic reviews. _International journal of surgery_ **88** , 105906 (2021).  
152. Abdoel, T. H. & Smits, H. L. Rapid latex agglutination test for the serodiagnosis of human brucellosis. _Diagn Microbiol Infect Dis_ **57** , 123–128 (2007).  
153. Akhvlediani, T. _et al._ Epidemiological and clinical features of brucellosis in the country of Georgia. _PLoS One_ **12** , 1–12 (2017).  
154. Al-Ajlan, H. H., Ibrahim, A. S. & Al-Salamah, A. A. Comparison of different PCR methods for detection of Brucella spp. in human blood samples. _Pol J Microbiol_ **60** , 27–33 (2011).  
155. Al-Attas, R. A., Al-Khalifa, M., Al-Qurashi, A. R., Badawy, M. & Al-Gualy, N. Evaluation of PCR, culture and serology for the diagnosis of acute human brucellosis. _Ann Saudi Med_ **20** , 224– 228 (2000).  
156. Almashhadany, D. A., Zefenkey, Z. F. & Odhah, M. N. A. Epidemiological study of human brucellosis among febrile patients in Erbil-Kurdistan region, Iraq. _J Infect Dev Ctries_ **16** , 1185– 1190 (2022).  
208  
157. Al-Nakkas, A., Mustafa, A. S. & Wright, S. G. Large-scale evaluation of a single-tube nested PCR for the laboratory diagnosis of human brucellosis in Kuwait. _J Med Microbiol_ **54** , 727–730 (2005).  
158. Al-Shamahy, H. A. & Wright, S. G. Enzyme-linked immunosorbent assay for brucella antigen detection in human sera. _J Med Microbiol_ **47** , 169–172 (1998).  
159. Araj, G. F., Brown, G. M., Haj, M. M. & Madhvan, N. V. Assessment of Brucellosis Card test in screening patients for brucellosis. _Epidemiol Infect_ **100** , 389–398 (1988).  
160. Araj, G. F., Dhar, R., Lastimoza, J. L. & Haj, M. Indirect fluorescent antibody test versus enzymelinked immunosorbent assay and agglutination tests in the serodiagnosis of patients with brucellosis. _Serodiagnosis and Immunotherapy in Infectious Disease_ **4** , 1–8 (1990).  
161. Aranís J., C. _et al._ Utilidad de la determinación de anticuerpos IgG e IgM por ELISA e inmunocaptura en una serie clínica de brucelosis humana. _Revista Chilena de Infectologia_ **25** , 116–121 (2008).  
162. Ayala, S. M. _et al._ Validation of a simple universal IELISA for the diagnosis of human brucellosis. _European Journal of Clinical Microbiology and Infectious Diseases_ **33** , 1239–1246 (2014).  
163. Clavijo, E. _et al._ Comparison of a dipstick assay for detection of Brucella-specific immunoglobulin M antibodies with other tests for serodiagnosis of human brucellosis. _Clin Diagn Lab Immunol_ **10** , 612–615 (2003).  
164. Dal, T. _et al._ Comparison of multiplex real-time polymerase chain reaction with serological tests and culture for diagnosing human brucellosis. _J Infect Public Health_ **12** , 337–342 (2019).  
165. Debeaumont, C., Falconnet, P. A. & Maurin, M. Real-time PCR for detection of Brucella spp. DNA in human serum samples. _European Journal of Clinical Microbiology and Infectious Diseases_ **24** , 842–845 (2005).  
166. Díaz, R., Casanova, A., Ariza, J. & Moriyón, I. The rose Bengal test in human brucellosis: A neglected test for the diagnosis of a neglected disease. _PLoS Negl Trop Dis_ **5** , 1–8 (2011).  
167. Ertek, M., Yazgi, H., Özkurt, Z., Ayyildiz, A. & Parlak, M. Comparison of the diagnostic value of the standard tube agglutination test and the ELISA IgG and IgM in patients with brucellosis. _Turk J Med Sci_ **36** , 159–163 (2006).  
168. Fadeel, M. A. _et al._ Rapid enzyme-linked immunosorbent assay for the diagnosis of human brucellosis in surveillance and clinical settings in Egypt. _Saudi Med J_ **27** , 975–981 (2006).  
169. Fadeel, M. A., Hoffmaster, A. R., Shi, J., Pimentel, G. & Stoddard, R. A. Comparison of four commercial IgM and IgG ELISA kits for diagnosing brucellosis. _J Med Microbiol_ **60** , 1767–1773 (2011).  
170. Concepción Gómez, M. _et al._ Evaluation of seven tests for diagnosis of human brucellosis in an area where the disease is endemic. _Clinical and Vaccine Immunology_ **15** , 1031–1033 (2008).  
171. Hasibi, M. _et al._ Enzyme linked immunosorbent assay versus polymerase chain reaction for diagnosis of brucellosis. _Journal of Medical Sciences_ **8** , 595–598 (2008).  
172. Hasibi, M., Jafari, S., Mortazavi, H., Asadollahi, M. & Djavid, G. E. Determination of the accuracy and optimal cut-off point for ELISA test in diagnosis of human brucellosis in Iran. _Acta Med Iran_ **51** , 687–692 (2013).  
209  
173. Kiel, F. W. & Yousuf Khan, M. Analysis of 506 consecutive positive serologic tests for brucellosis in Saudi Arabia. _J Clin Microbiol_ **25** , 1384–1387 (1987).  
174. Mantur, B. _et al._ ELISA versus conventional methods of diagnosing endemic brucellosis. _American Journal of Tropical Medicine and Hygiene_ **83** , 314–318 (2010).  
175. Marei, A. _et al._ Laboratory diagnosis of human brucellosis in Egypt and persistence of the pathogen following treatment. _J Infect Dev Ctries_ **5** , 786–791 (2011).  
176. Memish, Z. A., Almuneef, M., Mah, M. W., Qassem, L. A. & Osoba, A. O. Comparison of the Brucella Standard Agglutination Test with the ELISA IgG and IgM in patients with Brucella bacteremia. _Diagn Microbiol Infect Dis_ **44** , 129–132 (2002).  
177. Mert, A. _et al._ The sensitivity and specificity of Brucella agglutination tests. _Diagn Microbiol Infect Dis_ **46** , 241–243 (2003).  
178. Mizanbayeva, S. _et al._ The evaluation of a user-friendly lateral flow assay for the serodiagnosis of human brucellosis in Kazakhstan. _Diagn Microbiol Infect Dis_ **65** , 14–20 (2009).  
179. Nicoletti, P. & Fadai-Ghotbi, M. M. A comparison of the tube agglutination and card tests for the diagnosis of Brucella melitensis infection in humans. _Canadian Journal of Public Health/Revue Canadienne de Sante’e Publique_ 442–445 (1971).  
180. Nimri, L. F. Diagnosis of recent and relapsed cases of human brucellosis by PCR assay. _BMC Infect Dis_ **3** , 1–7 (2003).  
181. Osoba, A. O. _et al._ Diagnostic value of Brucella ELISA IgG and IgM in bacteremic and nonbacteremic patients with brucellosis. _Journal of Chemotherapy_ **13** , 54–59 (2001).  
182. Patra, S., Tellapragada, C., Vandana, K. E. & Mukhopadhyay, C. Diagnostic utility of in-house loop-mediated isothermal amplification and real-time PCR targeting virB gene for direct detection of Brucella melitensis from clinical specimens. _J Appl Microbiol_ **127** , 230–236 (2019).  
183. Peeridogaheh, H., Golmohammadi, M. G. & Pourfarzi, F. Evaluation of ELISA and Brucellacapt tests for diagnosis of human Brucellosis. _Iran J Microbiol_ **5** , 14–18 (2013).  
184. Purwar, S., Metgud, S. C., Mutnal, M. B., Nagamoti, M. B. & Patil, C. S. Utility of serological tests in the era of molecular testing for diagnosis of human brucellosis in endemic area with limited resources. _Journal of Clinical and Diagnostic Research_ **10** , DC26–DC29 (2016).  
185. Queipo-ortuño, M. I., Morata, P., Ocón, P., Manchado, P. & De Dios Colmenero, J. Rapid diagnosis of human brucellosis by peripheral-blood PCR assay. _J Clin Microbiol_ **35** , 2927–2930 (1997).  
186. Saz, J. V. _et al._ Enzyme-linked immunosorbent assay for diagnosis of brucellosis. _Eur J Clin Microbiol_ **6** , 71–74 (1987).  
187. Vrioni, G. _et al._ Application of a polymerase chain reaction enzyme immunoassay in peripheral whole blood and serum specimens for diagnosis of acute human brucellosis. _European Journal of Clinical Microbiology and Infectious Diseases_ **23** , 194–199 (2004).  
188. Xu, N., Wang, W., Chen, F., Li, W. & Wang, G. ELISA is superior to bacterial culture and agglutination test in the diagnosis of brucellosis in an endemic area in China. _BMC Infect Dis_ **20** , 1–7 (2020).  
189. Zhao, C., Xu, W. & Gao, W. A real-time quantitative PCR based on molecular beacon for detecting Brucella infection. _Arq Bras Med Vet Zootec_ **72** , 1039–1046 (2020).  
210  
190. Araj, G. F., Brown, G. M., Haj, M. M. & Madhvan, N. V. Assessment of brucellosis card test in screening patients for brucellosis. _Epidemiol Infect_ **100** , 389–398 (1988).  
191. Mizanbayeva, S. _et al._ The evaluation of a user-friendly lateral flow assay for the serodiagnosis of human brucellosis in Kazakhstan. _Diagn Microbiol Infect Dis_ **65** , 14–20 (2009).  
192. Al-Shamahy, H. A. & Wright, S. G. Enzyme-linked immunosorbent assay for brucella antigen detection in human sera. _J Med Microbiol_ **47** , 169–172 (1998).  
193. Fadeel, M. A., Hoffmaster, A. R., Shi, J., Pimentel, G. & Stoddard, R. A. Comparison of four commercial IgM and IgG ELISA kits for diagnosing brucellosis. _J Med Microbiol_ **60** , 1767–1773 (2011).  
194. Abdoel, T. H. & Smits, H. L. Rapid latex agglutination test for the serodiagnosis of human brucellosis. _Diagn Microbiol Infect Dis_ **57** , 123–128 (2007).  
195. Clavijo, E. _et al._ Comparison of a dipstick assay for detection of Brucella-specific immunoglobulin M antibodies with other tests for serodiagnosis of human brucellosis. _Clinical and Vaccine Immunology_ **10** , 612–615 (2003).  
196. Marei, A. _et al._ Laboratory diagnosis of human brucellosis in Egypt and persistence of the pathogen following treatment. _The Journal of Infection in Developing Countries_ **5** , 786–791 (2011).  
197. Peeridogaheh, H., Golmohammadi, M. G. & Pourfarzi, F. Evaluation of ELISA and Brucellacapt tests for diagnosis of human Brucellosis. _Iran J Microbiol_ **5** , 14 (2013).  
198. Saz, J. V _et al._ Enzyme-linked immunosorbent assay for diagnosis of brucellosis. _Eur J Clin Microbiol_ **6** , 71–74 (1987).  
199. Aranís, C. _et al._ Utilidad de la determinación de anticuerpos IgG e IgM por ELISA e inmunocaptura en una serie clínica de brucelosis humana. _Revista chilena de infectología_ **25** , 116–121 (2008).  
200. Gómez, M. C. _et al._ Evaluation of seven tests for diagnosis of human brucellosis in an area where the disease is endemic. _Clinical and Vaccine Immunology_ **15** , 1031–1033 (2008).  
201. Al-Ajlan, H. H., Ibrahim, A. S. & Al-Salamah, A. A. Comparison of different PCR methods for detection of Brucella spp. in human blood samples. _Pol J Microbiol_ **60** , 27–33 (2011).  
202. Hasibi, M. _et al._ Enzyme linked immunosorbent assay versus polymerase chain reaction for diagnosis of brucellosis. _Journal of Medical Sciences_ **8** , 595–598 (2008).  
203. Queipo-Ortuño, M. I., Morata, P., Ocón, P., Manchado, P. & Colmenero, J. de D. Rapid diagnosis of human brucellosis by peripheral-blood PCR assay. _J Clin Microbiol_ **35** , 2927–2930 (1997).  
204. Patra, S., Tellapragada, C., Vandana, K. E. & Mukhopadhyay, C. Diagnostic utility of in‐house loop‐mediated isothermal amplification and real‐time PCR targeting virB gene for direct detection of Brucella melitensis from clinical specimens. _J Appl Microbiol_ **127** , 230–236 (2019).  
205. Debeaumont, C., Falconnet, P. A. & Maurin, M. Real-time PCR for detection of Brucella spp. DNA in human serum samples. _European Journal of Clinical Microbiology and Infectious Diseases_ **24** , 842–845 (2005).  
206. Whiting, P. F. _et al._ QUADAS-2: a revised tool for the quality assessment of diagnostic accuracy studies. _Ann Intern Med_ **155** , 529–536 (2011).  
211  
207. R: The R Project for Statistical Computing. Preprint at https://www.r-project.org/ (2023).  
208. Feiz, J. M., Sabbaghian, H. & Sohrabi, F. A comparative study of therapeutic agents used for treatment of acute  brucellosis. _Br J Clin Pract_ **27** , 410–413 (1973).  
209. Buzon, L., Bouza, E. & Rodriguez, M. Treatment of brucellosis with rifampicin+tetracycline vs TMP/SMZ. A prospective and randomized study. _Chemioterapia_ **1** , No. 221-No. 221 (1982).  
210. Ariza, J., Gudiol, F., Pallarés, R., Rufí, G. & Fernández-Viladrich, P. Comparative trial of cotrimoxazole versus tetracycline-streptomycin in treating human brucellosis. _Journal of infectious diseases_ **152** , 1358–1359 (1985).  
211. Rodriguez Zapata, M., Gamo Herranz, A. & De La Morena Fernández, J. Comparative study of two regimens in the treatment of brucellosis. _Chemioterapia_ **6** , 360–362 (1987).  
212. Acocella, G. _et al._ Comparison of three different regimens in the treatment of acute brucellosis: a  multicenter multinational study. _J Antimicrob Chemother_ **23** , 433–439 (1989).  
213. Colmenero Castillo, J. D. _et al._ Comparative trial of doxycycline plus streptomycin versus doxycycline plus rifampin for the therapy of human brucellosis. _Chemotherapy_ **35** , 146–152 (1989).  
214. Solera, J., Medrano, F., Rodriguez, M., Geijo, P. & Paulino, J. Multicentric study comparing rifampin and doxycycline with streptomycin and doxycycline in human brucellosis. _Med Clin (Barc)_ **96** , 649–653 (1991).  
215. Ariza, J. _et al._ Treatment of human brucellosis with doxycycline plus rifampin or doxycycline plus  streptomycin. A randomized, double-blind study. _Ann Intern Med_ **117** , 25–30 (1992).  
216. Akova, M. _et al._ Quinolones in treatment of human brucellosis: comparative trial of ofloxacinrifampin versus doxycycline-rifampin. _Antimicrob Agents Chemother_ **37** , 1831–1834 (1993).  
217. Montejo, J. M. _et al._ Open, randomized therapeutic trial of six antimicrobial regimens in the treatment of human brucellosis. _Clinical infectious diseases_ **16** , 671–676 (1993).  
218. Colmenero, J. D. _et al._ Possible implications of doxycycline-rifampin interaction for treatment of brucellosis. _Antimicrob Agents Chemother_ **38** , 2798–2802 (1994).  
219. Solera, J. _et al._ Doxycycline-rifampin versus doxycycline-streptomycin in treatment of human brucellosis due to Brucella melitensis. _Antimicrob Agents Chemother_ **39** , 2061–2067 (1995).  
220. Kalo, T., Novi, S., Nushi, A. & Dedja, S. Ciprofloxacin plus doxycycline versus rifampicin plus doxycycline in the treatment of acute brucellosis. _Med Mal Infect_ **26** , 587–589 (1996).  
221. Agalar, C., Usubutun, S. & Turkyilmaz, R. Ciprofloxacin and rifampicin versus doxycycline and rifampicin in the treatment of brucellosis. _European journal of clinical microbiology & infectious diseases_ **18** , 535–538 (1999).  
222. Saltoglu, N., Tasova, Y., Inal, A. S., Seki, T. & Aksu, H. S. Efficacy of rifampicin plus doxycycline versus rifampicin plus quinolone in the  treatment of brucellosis. _Saudi Med J_ **23** , 921–924 (2002).  
223. Solera, J. _et al._ A randomized, double-blind study to assess the optimal duration of doxycycline treatment for human brucellosis. _Clinical infectious diseases_ **39** , 1776–1782 (2004).  
212  
224. Karabay, O., Sencan, I., Kayas, D. & Sahin, I. Ofloxacin plus rifampicin versus doxycycline plus rifampicin in the treatment of  brucellosis: a randomized clinical trial [ISRCTN11871179]. _BMC Infect Dis_ **4** , 18–18 (2004).  
225. Roushan, M. R. H., Gangi, S. M. E. & Ahmadi, S. A. A. Comparison of the efficacy of two months of treatment with co-trimoxazole plus  doxycycline vs. co-trimoxazole plus rifampin in brucellosis. _Swiss Med Wkly_ **134** , 564–568 (2004).  
226. Ersoy, Y., Sonmez, E., Tevfik, M. R. & But, A. D. Comparison of three different combination therapies in the treatment of human  brucellosis. _Trop Doct_ **35** , 210–212 (2005).  
227. Roushan, M. R. H. _et al._ Efficacy of gentamicin plus doxycycline versus streptomycin plus doxycycline in the treatment of brucellosis in humans. _Clinical infectious diseases_ **42** , 1075–1080 (2006).  
228. Alavi, S. M. & Rajabzadeh, A. R. Comparison of two chemotherapy regimen: doxycyclinerifampicin and doxycycline cotrimoxazol in the brucellosis patients Ahvaz, Iran, 2004-2006. _Pak J Med Sci_ **23** , 889–892 (2007).  
229. Ranjbar, M. _et al._ Comparison between doxycycline-rifampin-amikacin and doxycyclinerifampin regimens in the treatment of brucellosis. _International Journal of Infectious Diseases_ **11** , 152–156 (2007).  
230. Keramat, F., Ranjbar, M., Mamani, M., Hashemi, S. H. & Zeraati, F. A comparative trial of three therapeutic regimens: ciprofloxacin-rifampin, ciprofloxacin-doxycycline and doxycyclinerifampin in the treatment of brucellosis. _Trop Doct_ **39** , 207–210 (2009).  
231. Sarmadian, H., Didgar, F., Sufian, M., Zarinfar, N. & Salehi, F. Comparison Between Efficacy of Cipofoxacin Doxycycline and Rifampin - Doxycycline Regimens in Treatment and Relapse of Brucellosis. _Tropical medicine & international health_ **14** , 209–209 (2009).  
232. Roushan, M. R. H. _et al._ Comparison of the efficacy of gentamicin for 5 days plus doxycycline for 8 weeks  versus streptomycin for 2 weeks plus doxycycline for 45 days in the treatment of human brucellosis: a randomized clinical trial. _J Antimicrob Chemother_ **65** , 1028–1035 (2010).  
233. Hashemi, S. H. _et al._ Comparison of doxycycline-streptomycin, doxycycline-rifampin, and ofloxacin-rifampin in the treatment of brucellosis: a randomized clinical trial. _International journal of infectious diseases_ **16** , e247-51 (2012).  
234. Sofian, M. _et al._ Comparison of two durations of triple-drug therapy in patients with uncomplicated  brucellosis: A randomized controlled trial. _Scand J Infect Dis_ **46** , 573–577 (2014).  
235. Hasanain, A., Mahdy, R., Mohamed, A. & Ali, M. A randomized, comparative study of dual therapy (doxycycline-rifampin) versus triple therapy (doxycycline-rifampin-levofloxacin) for treating acute/subacute brucellosis. _Brazilian Journal of Infectious Diseases_ **20** , 250–254 (2016).  
236. Majzoobi, M. M. _et al._ Effect of hydroxychloroquine on treatment and recurrence of acute brucellosis: a single-blind, randomized clinical trial. _Int J Antimicrob Agents_ **51** , 365–369 (2018).  
237. Karami, A., Mobaien, A., Jozpanahi, M., Moghtader-Mojdehi, A. & Javaheri, M. Effect of 8- week and 12-week triple therapy (doxycycline, rifampicin, and gentamicin) on brucellosis: A comparative study. _Journal of Acute Disease_ **9** , 161–165 (2020).  
238. Majzoobi, M. M., Hashmi, S. H., Emami, K. & Soltanian, A. R. Combination of doxycycline, streptomycin and hydroxychloroquine for short-course treatment of brucellosis: a single-blind randomized clinical trial. _Infection_ **50** , 1267–1271 (2022).  
213  
239. Sofian, M. _et al._ Comparison of two durations of triple-drug therapy in patients with uncomplicated brucellosis: A randomized controlled trial. _Scand J Infect Dis_ **46** , 573–577 (2014).  
240. Karami, A., Mobaien, A., Jozpanahi, M., Moghtader-Mojdehi, A. & Javaheri, M. Effect of 8- week and 12-week triple therapy (doxycycline, rifampicin, and gentamicin) on brucellosis: A comparative study. _Journal of Acute Disease_ **9** , 161–165 (2020).  
241. Roushan, M. R. H. _et al._ Comparison of the efficacy of gentamicin for 5 days plus doxycycline for 8 weeks versus streptomycin for 2 weeks plus doxycycline for 45 days in the treatment of human brucellosis: a randomized clinical trial. _Journal of antimicrobial chemotherapy_ **65** , 1028– 1035 (2010).  
242. Galanakis, E., Bourantas, K. L., Leveidiotou, S. & Lapatsanis, P. D. Childhood brucellosis in north-western Greece: a retrospective analysis. _Eur J Pediatr_ **155** , 1–6 (1996).  
243. Sánchez-Tamayo, T. _et al._ Failure of short-term antimicrobial therapy in childhood brucellosis. _Pediatr Infect Dis J_ **16** , 323–324 (1997).  
244. Issa, H. & Jamal, M. Brucellosis in children in south Jordan. _East Mediterr Health J_ **5** , 895–902 (1999).  
245. El-Amin, E. O. _et al._ Brucellosis in children of Dhofar Region, Oman. _Saudi Med J_ **22** , 610–615 (2001).  
246. Makis, A. C. _et al._ Serum levels of soluble interleukin-2 receptor alpha (sIL-2Ralpha) as a predictor  of outcome in brucellosis. _J Infect_ **51** , 206–210 (2005).  
247. Shen, M. W. Diagnostic and therapeutic challenges of childhood brucellosis in a nonendemic country. _Pediatrics_ **121** , e1178–e1183 (2008).  
248. Logan, L. K., Jacobs, N. M., McAuley, J. B., Weinstein, R. A. & Anderson, E. J. A multicenter retrospective study of childhood brucellosis in Chicago, Illinois  from 1986 to 2008. _Int J Infect Dis_ **15** , e812-7 (2011).  
249. Zamani, A. _et al._ Epidemiological and clinical features of Brucella arthritis in 24 children. _Ann Saudi Med_ **31** , 270–273 (2011).  
250. Bosilkovski, M., Krteva, L., Caparoska, S., Labacevski, N. & Petrovski, M. Childhood brucellosis: Review of 317 cases. _Asian Pac J Trop Med_ **8** , 1027–1032 (2015).  
251. Çıraklı, S. _et al._ Evaluation of childhood brucellosis in the central Black Sea region. _Turk J Pediatr_ **57** , 123–128 (2015).  
252. Hasanjani Roushan, M. R., Zahedpasha, Y. & Soleimani Amiri, M. J. Clinical manifestations and laboratory test results on 173 children with brucellosis. _Eur J Pediatr_ **175** , 1450–1450 (2016).  
253. Logan, L. K., Jacobs, N. M., McAuley, J. B., Weinstein, R. A. & Anderson, E. J. A multicenter retrospective study of childhood brucellosis in Chicago, Illinois  from 1986 to 2008. _Int J Infect Dis_ **15** , e812-7 (2011).  
254. Galanakis, E., Bourantas, K. L., Leveidiotou, S. & Lapatsanis, P. D. Childhood brucellosis in north-western Greece: a retrospective analysis. _Eur J Pediatr_ **155** , 1–6 (1996).  
255. Hasanjani Roushan, M. R., Zahedpasha, Y. & Soleimani Amiri, M. J. Clinical manifestations and laboratory test results on 173 children with brucellosis. _Eur J Pediatr_ **175** , 1450 (2016).  
214  
256. Makis, A. C. _et al._ Serum levels of soluble interleukin-2 receptor alpha (sIL-2Ralpha) as a predictor  of outcome in brucellosis. _J Infect_ **51** , 206–210 (2005).  
257. Issa, H. & Jamal, M. Brucellosis in children in south Jordan. _East Mediterr Health J_ **5** , 895–902 (1999).  
258. Çıraklı, S. _et al._ Evaluation of childhood brucellosis in the central Black Sea region. _Turk J Pediatr_ **57** , 123–128 (2015).  
259. Zamani, A. _et al._ Epidemiological and clinical features of Brucella arthritis in 24 children. _Ann Saudi Med_ **31** , 270–273 (2011).  
260. Shen, M. W. Diagnostic and therapeutic challenges of childhood brucellosis in a nonendemic country. _Pediatrics_ **121** , e1178–e1183 (2008).  
261. Mendeley. Mendeley Reference Manager. https://www.mendeley.com/referencemanager/library/all-references (2023).  
262. Mourad Ouzzani, H. H., Zbys Fedorowicz, Ahmed Elmagarmid & Hossam Hammady. Rayyan — a web and mobile app for systematic reviews. _Systematic Reviews_ 5–210 https://rayyan.ai/ (2016) doi:DOI: 10.1186/s13643-016-0384-4.  
263. Bosilkovski, M. _et al._ Brucellosis in pregnancy: case reports with different outcomes in an endemic  region. _Acta Clin Croat_ **59** , 338–343 (2020).  
264. Seoud, M., Saade, G., Awar, G. & Uwaydah, M. Brucellosis in pregnancy. _J Reprod Med_ **36** , 441–445 (1991).  
265. Gulsun, S., Aslan, S., Satici, O. & Gul, T. Brucellosis in pregnancy. _Trop Doct_ **41** , 82–84 (2011).  
266. Inan, A. _et al._ Brucellosis in pregnancy: results of multicenter ID-IRI study. _European Journal of Clinical Microbiology & Infectious Diseases_ **38** , 1261–1268 (2019).  
267. Roushan, M. R. H., Baiani, M., Asnafi, N. & Saedi, F. Outcomes of 19 pregnant women with brucellosis in Babol, northern Iran. _Trans R Soc Trop Med Hyg_ **105** , 540–542 (2011).  
268. Khan, M. Y., Mah, M. W. & Memish, Z. A. Brucellosis in pregnant women. _Clinical infectious diseases_ **32** , 1172–1177 (2001).  
269. Carra, M. A. _et al._ Brucella melitensis exposure of healthcare workers (HCWS) in the clinical laboratory of a large acute care hospital. _Am J Infect Control_ **38** , E46–E48 (2010).  
270. Maley, M. W., Kociuba, K. & Chan, R. C. Prevention of Laboratory-Acquired Brucellosis: Significant Side Effects of Prophylaxis. _Clinical Infectious Diseases_ **42** , 433–434 (2006).  
271. Kutlu, M. _et al._ Risk factors for occupational brucellosis among veterinary personnel in Turkey. _Prev Vet Med_ **117** , 52–58 (2014).  
272. Wong, C., Ng, S. Y. & Tan, S. H. An accidental laboratory exposure to Brucella melitensis: The prospective post-exposure management and a detailed investigation into the nature of the exposure. _J Med Microbiol_ **67** , 1012–1016 (2018).  
215

---

<!-- METADADOS: doenca: PCDT - Brucelose Humana | secao: APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO -->
|**Número do**<br>**Relatório da**<br>**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais**<br>**alterações**|**Tecnologias avalia**<br>**Incorporação ou**<br>**alteração do uso no SUS**|**daspela Conitec**<br>**Não incorporação ou não**<br>**alteração no SUS**|
|---|---|---|---|
|Portaria<br>SECTICS/MS n°||Ampliação<br>de<br>uso<br>dos<br>medicamentos doxici-clina,<br>estreptomicina<br>e<br>rifampicina<br>para<br>o<br>tratamento da brucelo-se<br>humana<br>[Relatório<br>de<br>Recomendação<br>nº<br>254/2017;<br>Portaria||
|22, de 12 de maio<br>de 2025 [Relatório<br>de Recomendação<br>nº 985/2025]|Primeira versão<br>do documento|SCTIE/MS nº 13/2017]<br>Sulfato<br>de<br>gentamicina<br>combinado à doxiciclina<br>para<br>o<br>tratamento<br>da<br>brucelose<br>humana<br>[Relatório<br>de<br>Recomendação<br>nº<br>901/2024;<br>Portaria<br>SCTIE/MSnº 28/2024]|-|  
216

---

