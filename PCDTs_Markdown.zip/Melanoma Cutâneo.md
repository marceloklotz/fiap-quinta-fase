<!-- METADADOS: doenca: Melanoma Cutâneo | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 19, DE 25 DE OUTUBRO DE 2022  
Aprova as Diretrizes Diagnósticas e Terapêuticas do Melanoma Cutâneo.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTAe a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE - SUBSTITUTA, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Melanoma Cutâneo e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 754/2022 e o Relatório de Recomendação nº 757 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas - Melanoma Cutâneo.  
Parágrafo único. As Diretrizes objeto deste artigo, que contêm o conceito geral do Melanona Cutâneo, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio https://www.gov.br/saude/ptbr/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Melanoma Cutâneo.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 357, de 08 de abril de 2013, publicada no Diário Oficial da União nº67, de 9 de abril de 2013, seção 1, página 41 a 45.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: MARIA INEZ PORDEUS GADELHA -->
ANA PAULA TELES FERREIRA BARRETO

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **1. INTRODUÇÃO** -->
O Melanoma Cutâneo é uma neoplasia que se forma a partir da transformação dos melanócitos, os quais são células produtoras de melanina originárias embriologicamente da crista neural. Além da pele, os melanócitos também estão presentes nos olhos (mucosas uveal e conjuntival), ouvidos, trato gastrointestinal (esôfago superior e mucosa ano-retal), meninges e nas mucosas oral, nasofaríngea, anorretal e genital<sup>1,2</sup> . O melanoma cutâneo é proveniente da pele, podendo ser maligno extensivo superficial, nodular, lentigo maligno e lentiginoso acral.  
Cerca de dois terços desses tumores se desenvolvem na pele normal e os demais têm origem de nevos melanocíticos préexistentes<sup>3</sup> .  
O Melanoma Cutâneo tem seu desenvolvimento resultante de múltiplas e progressivas alterações no DNA celular, que podem ser causadas por ativação de proto-oncogenes, por mutações ou deleções de genes supressores tumorais ou por alteração estrutural dos cromossomos<sup>4</sup> . Trata-se da forma mais agressiva e letal dos cânceres de pele<sup>5,6</sup> e  pode ser a causa de metástases  
de tumor primário desconhecido, quando há regressão espontânea<sup>2</sup> . Na fase inicial, o tumor apresenta crescimento radial, principalmente intraepidérmico, seguida por uma fase de crescimento vertical (nodular), com invasão da derme e dos vasos, podendo evoluir para a fase de disseminação metastática<sup>7</sup> . Há discussões sobre a existência de duas vias principais da patogênese do melanoma cutâneo: pela exposição cumulativa ao sol no local do futuro câncer em pessoas sensíveis ao sol e pela exposição precoce ou intermitente ao sol e propensão do nevo, promovido por fatores genéticos<sup>6,8,9</sup> . Cerca de 30% dos melanomas cutâneos derivam de nevos benignos (melanocíticos), sendo que essa estimativa pode chegar a 50% em pacientes com numerosos nevos<sup>6,8,9</sup> .  
O Melanoma Cutâneo é o 12º tipo de câncer mais frequente no mundo, sendo sua taxa de incidência ajustada por idade de 3,0 por 100.000 pessoas<sup>10</sup> . Observou-se um expressivo crescimento na incidência de melanoma cutâneo nas populações de pele clara em todo o mundo<sup>11–13</sup> , provavelmente em função da interação de fatores ambientais, comportamentais e fenotípicos<sup>14–</sup> 17. No Brasil, segundo o Instituto Nacional de Câncer (INCA) do Ministério da Saúde, foram estimados cerca de 4.200 casos entre os homens e 4.250 casos entre as mulheres para cada ano do triênio 2020-2022<sup>18</sup> . Dado o crescimento expressivo da população e o aumento da expectativa de vida, estima-se que o número total de pacientes diagnosticados com melanoma cutâneo continuará a crescer nas próximas décadas<sup>6,19</sup> .  
Um dos fatores de risco para o desenvolvimento de melanoma cutâneo é a presença dos fototipos I e II de Fitzpatrick, ou seja, pessoas de pele clara, que se queimam facilmente ao invés de se bronzear quando expostas ao sol<sup>20,21</sup> . Entretanto, em contraste com o melanoma disseminado superficialmente na pele, o melanoma dos tipos nodular e mucoso parece ser independente da exposição a UV<sup>6</sup> . Dentre os diversos fatores de risco para o desenvolvimento de melanoma cutâneo, destacamse: nevos displásicos, nevos melanocíticos congênitos, grande número de nevos comuns (mais de 50), lentigo maligno, histórico pessoal de melanoma ou história familiar de melanoma; exposição solar intermitente, queimaduras solares (especialmente durante a infância) e uso de camas de bronzeamento<sup>6,11,12,20–24</sup> . Adicionalmente, o estado imunológico do paciente pode afetar o desenvolvimento do melanoma cutâneo, uma vez que esta neoplasia parece ser mais comum em pacientes imunodeprimidos devido a história de transplante de órgão, infecção por vírus da imunodeficiência humana (HIV) ou neoplasia hematológica, ou que estejam em uso de medicamento imunossupressor<sup>6,25</sup> .  
A média de idade dos pacientes com melanoma cutâneo varia entre 57 a 64 anos em todo o mundo, e a localização anatômica da lesão neoplásica pode variar conforme a idade<sup>6,26</sup> , sendo a idade abaixo de 45 anos considerada um fator de risco para mulheres<sup>6,27</sup> . Há diferenças na apresentação do melanoma entre homens e mulheres. Nos homens, os melanomas cutâneos  
são mais frequentemente localizados na cabeça, pescoço e tronco, com ulceração e maior espessura do índice de Breslow, além de maior incidência e taxa de mortalidade duas vezes maior quando comparado com mulheres<sup>6,26,28</sup> . A menor mortalidade em mulheres pode ser reflexo tanto da prevenção primária (comportamento no sol, proteção UV), quanto secundária (adesão aos serviços de saúde)<sup>6,29</sup> . Apesar da melhor sobrevida das mulheres ser atribuída ao diagnóstico precoce (tratamento em estádio I e II), essa sobrevida diminui se houver metástase<sup>6,26</sup> .  
Desse modo, os esforços para reduzir a incidência de melanoma cutâneo têm focado na identificação de indivíduos de alto risco para desenvolver essa neoplasia e em modificações comportamentais quanto à exposição solar. Para o melanoma cutâneo, a prevenção constitui-se basicamente na proteção solar, evitando-se a exposição entre 10 e 16 horas, com o uso de barreiras físicas como chapéu, guarda-sol e camiseta, bem como a não utilização de bronzeamento artificial, já proibido no Brasil<sup>30–32</sup> . O INCA orienta a realização do autoexame da pele de forma periódica em busca de lesões suspeitas, uma vez que o diagnóstico precoce representa alta chance de cura e desempenha um importante papel no aumento da sobrevida. Portanto, sinais de alerta devem estimular o indivíduo a procurar orientação médica e campanhas longas de prevenção contra o melanoma cutâneo podem reduzir a incidência e a mortalidade pela doença<sup>6,11,16,18,33,34</sup> .  
Entre as neoplasias de pele, o melanoma apresenta o pior prognóstico. A estimativa mundial de sobrevida em cinco anos é de 69%, sendo de 73% nos países desenvolvidos e de 56% nos países em desenvolvimento<sup>13,18</sup> . O principal fator prognóstico do melanoma cutâneo é o estadiamento histopatológico, que depende da profundidade de invasão da lesão primária (espessura de Breslow) e da presença de ulceração<sup>35</sup> . As lesões primárias localizadas nas extremidades do corpo são associadas com um melhor prognóstico em comparação àquelas centrais, em áreas como cabeça, pescoço ou tronco<sup>23,36</sup> . Fatores prognósticos desfavoráveis são idade avançada, sexo masculino e padrão de crescimento nodular<sup>23,36–39</sup> . Em pacientes com melanoma estádio IV, ter desidrogenase láctica sérica (DHL, também chamada lactatodesidrogenase LDH) elevada, doença visceral (com exceção do pulmão), maior idade no momento do diagnóstico, acometimento de mais de um órgão e mais de uma metástase foram fatores prognósticos associados com menor sobrevida<sup>40</sup> . Em uma coorte que incluiu 589 pacientes com melanoma em estágio IV, o número de metástases foi o fator preditor de sobrevida mais relevante e a mediana de sobrevida foi de nove meses, sendo que a sobrevida em cinco anos foi de 9%<sup>40</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos do melanoma cutâneo, com o objetivo de orientar o que é válido e não válido técnico-cientificamente, com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 2** .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **C43 Melanoma maligno** -->
- C43.0 Melanoma maligno do lábio - C43.1 Melanoma maligno da pálpebra, incluindo as comissuras palpebrais  
- C43.2 Melanoma maligno da orelha e do conduto auditivo externo  
- C43.3 Melanoma maligno de outras partes e partes não especificadas da face  
- C43.4 Melanoma maligno do couro cabeludo e do pescoço  
- C43.5 Melanoma maligno do tronco  
- C43.6 Melanoma maligno do membro superior, incluindo ombro  
- C43.7 Melanoma maligno do membro inferior, incluindo quadril  
- C43.8 Melanoma maligno invasivo da pele - C43.9 Melanoma maligno de pele, não especificado  
**D03 Melanoma** **_in situ_**  
- D03.0 Melanoma _in situ_ do lábio - D03.1Melanoma _in situ_ da pálpebra, incluindo o canto - D03.2 Melanoma _in situ_ da orelha e do conduto auditivo externo - D03.3 Melanoma _in situ_ de outras partes e partes não especificadas da face - D03.4 Melanoma _in situ_ do couro cabeludo e do pescoço  
- D03.5 Melanoma _in situ_ do tronco  
- D03.6 Melanoma _in situ_ dos membros superiores, incluindo ombro  
- D03.7 Melanoma _in situ_ dos membros inferiores, incluindo quadril  
- D03.8 Melanoma _in situ_ de outras localizações  
- D03.9 Melanoma _in situ_ , não especificado

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **3.1. Diagnóstico clínico** -->
O ponto de partida do diagnóstico é uma lesão de pele suspeita. Geralmente, o paciente se queixa do surgimento de uma nova lesão pigmentada ou de modificações de tamanho, forma ou cor de um nevo melanocítico pré-existente. Lesões pigmentadas suspeitas devem ser examinadas com boa luz (com ou sem magnificação) e devem ser avaliadas segundo os critérios clínicos ABCDE<sup>41</sup> **(Quadro 1)** ou a _checklist_ de sete pontos<sup>42</sup> ( **Quadro 2** ). Estes critérios indicam suspeita de melanoma cutâneo quando estão presentes em lesões melanocíticas e podem ser detectados nas fases iniciais de desenvolvimento do tumor<sup>22</sup> . A presença de qualquer característica mais relevante da _checklist_ de sete pontos ou quaisquer das características dos critérios clínicos ABCDE é indicação para encaminhamento do paciente a um médico especialista, que pode ser dermatologista ou oncologista clínico ou cirúrgico<sup>43</sup> . Os médicos devem estar familiarizados com os sete pontos e os critérios clínicos ABCDE para avaliar lesões melanóticas<sup>43</sup> . A presença de características menos relevantes deve gerar suspeita<sup>43</sup> .  
**Quadro 1** - Critérios clínicos ABCDE  
|**A**|**A**ssimetria geométrica em dois eixos|
|---|---|
|**B**|**B**orda irregular|
|**C**|Pelo menos duas**C**ores diferentes na lesão|
|**D**|**D**iâmetro máximo > 6mm|
|**E**|**E**volução/mudança no aspecto da lesão|  
Adaptado das Diretrizes para tratamento de melanoma cutâneo na Escócia<sup>43</sup>  
**Quadro 2** - Identificação de melanoma com sete pontos  
|**Características mais relevantes**|**Características menos relevantes**|
|---|---|
|Mudança em tamanho de lesão|Inflamação|
|Pigmentação irregular|Sensação alterada ou de coceira|
|Borda irregular|Lesão maior do que as outras|
||Exsudação/ crostas da lesão|  
Adaptado das Diretrizes para tratamento de melanoma cutâneo na Escócia<sup>43</sup> .  
Para a avaliação clínica do paciente, estudos demonstram maior especificidade da dermatoscopia em relação ao exame da lesão a olho nu. A dermatoscopia permite visualizar a distribuição da melanina e analisar mais detalhadamente lesões pigmentares, permitindo diferenciar outras doenças clinicamente confundidas com melanoma, como carcinomas basocelulares pigmentados e ceratoses seborreicas. Esse método é de extrema utilidade quando empregado por profissional experiente<sup>34</sup> . São critérios dermatoscópicos sugestivos do diagnóstico de melanoma cutâneo: pigmentação assimétrica, pseudópodes (estrias irregulares na periferia da lesão), véu cinza azulado (áreas de regressão tumoral) e arquitetura vascular atípica<sup>35,44</sup> As lesões de pele pigmentadas que forem referidas para avaliação ou identificadas durante consulta podem ser avaliadas usando dermatoscópio desde que existam profissionais da saúde treinados nessa técnica e conforme disponibilidade deste equipamento<sup>43</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **3.2. Diagnóstico histopatológico** -->
Em pacientes com lesões suspeitas de melanoma cutâneo deve-se realizar biópsia excisional da lesão com margens de 1 a 2 mm de pele normal e com bainha de gordura. Devido ao tamanho ou localização da lesão, a biópsia incisional só pode ser realizada caso a excisional não seja viável. Então, o local da biópsia deve ser a porção mais enegrecida ou mais elevada da lesão. Raspagens (s _havings_ ) e curetagens são contraindicadas como métodos para biópsia porque impossibilitam a avaliação de toda a espessura tumoral e a realização do estadiamento por exame histopatológico<sup>22,43</sup> .  
O laudo do exame histopatológico deve conter as seguintes especificações: espessura de Breslow; presença ou ausência de ulceração; taxa mitótica dermal; avaliação do _status_ da margem profunda e periférica; presença ou ausência de microssatelitose; existência de desmoplasia pura; e existência de invasão linfovascular ou angiolinfática<sup>45</sup> .  
Os quatro tipos mais comuns de melanoma cutâneo são:  
- a. Melanoma maligno extensivo superficial: trata-se de lesão pigmentada assimétrica com pigmentação variável e contorno irregular. Neste tipo de melanoma, pode haver crescimento da lesão, mudança em sua sensação ou cor, formação de crostas, sangramento ou inflamação<sup>43</sup> .  
- b. Melanoma nodular: tem apresentação mais breve e maior tendência a sangrar ou ulcerar<sup>43</sup> .  
- c. Melanoma lentigo maligno: ocorre com maior frequência em pele queimada pelo sol na cabeça e no pescoço de pacientes mais velhos. Esse tipo de melanoma tem lesão pré-invasiva ( _in situ_ ) e por longo período, chamada de lentigo maligno. Esta lesão pode progredir para um melanoma lentigo maligno invasivo<sup>43</sup> .  
- d. Melanoma lentiginoso acral: ocorre nas palmas das mãos (palmar), solas dos pés (plantar) e debaixo das unhas (subungueal)<sup>2,43</sup> .  
Também existem outros dois tipos de melanoma cutâneo mais raros: o melanoma desmoplástico e o melanoma hipermelanocítico de baixo grau<sup>43</sup> .  
Quando não diagnosticado e não tratado precocemente, o tumor pode aumentar de tamanho, em extensão e profundidade, com progressiva alteração da cor e formas originais. Outras características podem levar ao diagnóstico, tais como ulceração, sangramento ou sintomas (prurido, dor e inflamação)<sup>3,46</sup> .  
O risco de metástase pode ser previsto por meio da espessura do tumor, uma vez que quanto maior este for, maior é o risco para espalhamento e recorrência do melanoma cutâneo. De forma semelhante, a ulceração e alta taxa de divisão celular são associadas com pior prognóstico<sup>23,36</sup> . Entretanto, há sinais de atividade melanocítica para mais (aumento) ou para menos (redução ou mesmo sumiço da lesão melanótica).  
A profundidade da invasão neoplásica, medida da camada granulosa da pele até a base da lesão, é conhecida por índice ou espessura de Breslow: menor que 1 mm, de 1,1 a 2 mm, de 2,1 a 4 mm e maior que 4 mm. Já os níveis de Clark definem a profundidade com base na camada da pele invadida pelo melanoma: limitada à epiderme ou à junção epidermodérmica (melanoma _in situ_ – nível I); invasão até a derme superficial - papilar (nível II); invasão de toda a derme profunda - papilar (nível III); invasão de toda a derme reticular (nível IV); e invasão do tecido subcutâneo – hipoderme (nível V)<sup>2</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **3.3. Avaliação molecular** -->
O conhecimento dos fatores genéticos e moleculares relacionados ao melanoma cutâneo vem tendo papel relevante no seu diagnóstico, tratamento e prognóstico. A identificação de indivíduos geneticamente predispostos e dos genes envolvidos, bem como a intervenção em vias de sinalização específicas, isto é, agir nas vias intracelulares que possibilitam o desenvolvimento do tumor na doença metastática, têm possibilitado novos métodos de diagnóstico, tratamento e acompanhamento, impactando na terapêutica do paciente.  
Mutações nos genes _CDKN2A_ e _CDK4_ foram detectadas em algumas famílias com melanoma hereditário, conferindo um risco aumentado para esta neoplasia<sup>35</sup> . Até o momento, a existência de uma mutação universal para todos os melanomas cutâneos é desconhecida. Em amostras, as mutações identificadas estavam presentes nas vias de sinalização da MAP quinase (proteína quinase ativada por mitógeno)<sup>6,47,48</sup> , da PI3K (fosfoinositol 3-quinase) e da Wnt<sup>6,49,50</sup> . As duas mutações mais comuns, nos genes _BRAF_ e _NRAS_ , ativam a via da MAP quinase enquanto o _NF1_ é um gene supressor tumoral que contribui para a regulação da ativação de _RAS_<sup>6,51</sup> . Para classificação genômica, sugerem-se quatro subgrupos: mutações em _BRAF_ , _RAS_ , _NF1_ e tipo selvagem triplo (quando os três tipos citados anteriormente não estão mutados)<sup>6,52</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **3.4. Estadiamento** -->
A difusão do tumor na pele e tecidos adjacentes definirá o tratamento clínico e o prognóstico dos pacientes. O estadiamento é feito considerando aspectos clínicos e patológicos. Determina-se o estádio do melanoma cutâneo por meio da análise do tumor (T), do número de nodos metastáticos (N), e de metástases distantes (M)<sup>23,53</sup> .  
O estadiamento clínico inclui o estadiamento microscópico do tumor primário (espessura de Breslow) e a avaliação clínica, por imagem e por biópsia, se indicada, para a detecção de metástases<sup>43,45</sup> . A partir do estadiamento clínico, é possível definir os seguintes critérios, adotando-se as categorias e subcategorias discriminadas nos **quadros 3 e 4** :  
a) presença ou ausência de ulceração;  
b) tamanho do tumor em relação à profundidade na derme (T, definido patologicamente – pT1 a pT4);  
c) acometimento linfático, que pode ser no próprio linfonodo (clinicamente detectado ao exame físico ou por imagem, ou pelo linfonodo sentinela) e no sistema linfático (metástases em trânsito, satélites ou microssatélites), cuja categorização varia de N0 a N3; e  
d) metástases à distância (M0 ou M1).  
Os níveis séricos de DHL/LDH são descritos como sufixo à categoria M, isto é, normal (0) ou elevado (1)<sup>35</sup> .  
A despeito do número de lesões, metástases em trânsito, satélites e microssatélites representam um critério de categorização de invasão linfática (N). Metástases em trânsito são lesões macroscópicas localizadas além de 2 cm do tumor primário ou da drenagem linfática ou em direção a ela. Satélites são lesões macroscópicas localizadas além de 2 cm do tumor primário. Microssatélites são células malignas isoladas e assim consideradas independentemente da sua distância do tumor primário e do tamanho do agrupamento celular. São metástases linfáticas microscópicas, cuja presença indica risco aumentado de recorrência neoplásica<sup>48</sup> . O mais utilizado sistema de estadiamento do câncer é o da União Internacional Contra o Câncer (UICC), a Classificação de Tumores Malignos, que utiliza as categorias T (tumor), N (acometimento linfonodal) e M (metástase a distância), chamada simplificadamente de TNM. De acordo com a classificação TNM proposta pela UICC 8ª edição<sup>54.</sup> , os casos com metástases em trânsito, satélites ou microssatélites categorizam-se como N1c, N2c ou N3c com base no número de linfonodos regionais acometidos por melanoma (respectivamente, nenhum, um e dois ou mais linfonodos)<sup>54</sup> .  
Em complementação, o estadiamento patológico inclui não só o estadiamento microscópico do tumor primário, como também dados patológicos sobre os linfonodos regionais após a biópsia do linfonodo sentinela ou o esvaziamento linfático à procura de acometimento de linfonodo regional<sup>43,45</sup> .  
Pacientes classificados nos estádios 0 e IA (respectivamente, Tis – melanoma _in situ_ - e T1) sem metástases regionais ou distantes clinicamente detectáveis não precisam de avaliação patológica de linfonodo para completar o estadiamento patológico. Nesses casos, basta usar a notação cN0 para designar a categorização linfática clínica no estadiamento patológico<sup>43,45</sup> . Nos casos de melanoma em estádios clínicos I e II, não é necessário que o paciente realize rotineiramente exames de imagem, devendo estes serem solicitados conforme sua indicação clínica. Pacientes que, após biópsia, forem diagnosticados como tendo lesões com espessura menor que 0,8 mm tipicamente têm tumores com pouco acesso a vasos linfáticos e sanguíneos. Dessa forma, a probabilidade de metástases locorregionais ou distais ter ocorrido é baixa<sup>23</sup> .  
Exames séricos não são rotineiramente indicados para o estadiamento de pacientes assintomáticos. No entanto, a dosagem de DHL/LDH deve ser feita em pacientes com melanoma cutâneo em estádio IV, uma vez que é parte da classificação de rotina<sup>43</sup> . Nos estádios III e IV, deve-se considerar a realização de tomografia computadorizada (TC) de tórax, abdômen e pelve. Pacientes com lesões em pescoço, face ou couro cabeludo têm indicação de TC de região cervical. A realização de ressonância magnética (RM) de encéfalo deve ser considerada nos pacientes em estádio IIIB a IV, e para recorrência de doença metastática à distância, mesmo em pacientes assintomáticos<sup>45</sup> . As imagens devem ser realizadas com contraste intravenoso, a menos que contraindicado. Nas TC de tórax para metástases pulmonares, o contraste é desnecessário<sup>45</sup> . Atualmente, a evidência sobre o uso de tomografia computadorizada por emissão de pósitrons (PET-CT) no estadiamento de pacientes de risco mais alto é crescente, especialmente para candidatos a ressecção de metástases<sup>23</sup> . Contudo, a indicação de PET-CT em caso de melanoma não teve sua indicação recomendada pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC).  
O estádio III caracteriza que houve invasão dos linfonodos regionais, pele próxima ou vasos linfáticos. Já o estádio IV indica câncer metastático<sup>23</sup> , inclusive por invadir linfonodos não regionais. Os pulmões e a pleura são geralmente os primeiros locais com metástases viscerais do melanoma cutâneo. Outros locais onde pode haver invasão metastática são o cérebro, fígado, ossos, trato gastrointestinal e linfonodos não regionais<sup>23,55</sup> .  
**Quadro 3** - Definições de T, N e M.  
||**Categorização do tumor primár**|**io**|
|---|---|---|
|**Categoria T**|**Espessura**|**Status de Ulceração**|
|TX: Espessura do tumor primário<br>não pode ser avaliada (p.ex.,<br>diagnóstico em material obtido por<br>curetagem).|Não aplicável|Não aplicável|
|T0: Sem evidência de tumor<br>primário (p.ex., melanoma<br>primário desconhecido ou<br>completamente regredido).|Não aplicável|Não aplicável|
|Tis: melanoma_in situ_|Não aplicável|Não aplicável|
|T1|≤1 mm|Desconhecido ou não especificado|
|T1a|<0,8 mm|Sem ulceração|
|T1b|<0,8 mm<br>0,8 – 1,0 mm|Com ulceração<br>Com ou sem ulceração|
|T2|>1,0 - 2,0 mm|Desconhecido ou não especificado|
|T2a|>1,0 – 2,0 mm|Sem ulceração|
|T2b|>1,0 – 2,0 mm|Com ulceração|  
|T3<br>>2,0 - 4,0 mm|Desconhecido ou não especificado|
|---|---|
|T3a<br>>2,0 – 4,0 mm|Sem ulceração|
|T3b<br>>2,0 – 4,0 mm|Com ulceração|
|T4<br>>4,0 mm|Desconhecido ou não especificado|
|T4a<br>>4,0 mm|Sem ulceração|
|T4b<br>>4,0 mm|Com ulceração|
|**Extensão para linfonodos regionais ou metástases**|**linfáticas**|
|**Categoria N**<br>**Número de linfonodos regionais**<br>**acometidos por melanoma**|**Presença de metástases em trânsito,**<br>**satélites ou microssatélites.**|
|NX<br>Linfonodos regionais não podem ser<br>avaliados (p. ex., biópsia de linfonodo<br>sentinela não realizada ou linfonodos<br>regionais previamente removidos por outra<br>razão).|Não|
|N0<br>Sem metástase em linfonodos regionais.|Não|
|N1<br>Metástase em um linfonodo regional ou metás<br>nodais|tase regional intralifática em metástases|
|N1a<br>Apenas metástases microscópicas<br>(clinicamente ocultas)|Não|
|N1b<br>Metástases macroscópicas (clinicamente<br>aparente).|Não|
|N1c<br>Metástases satélites ou em trânisto sem<br>metástase em linfonodo regional.|Sim|
|N2<br>Metástase em dois ou três linfonodos regionai<br>metástases linfonodais|s ou metástase regional intralifática com|
|N2a<br>Apenas metástases nodais microscópicas|Não|
|N2b<br>Metástase nodal macroscópica|Não|
|N2c<br>Metástases satélites ou em trânisto com<br>apenas uma metástase em linfonodo<br>regional.|Sim|
|N3<br>Metástase em quatro ou mais linfonodos regio<br>linfonodos regionais ou metástases em trânsit<br>mais linfonodos regionais|nais ou infiltração metastática em<br>o, satélites com metástase em dois ou|
|N3a<br>Apenas metástases nodais microscópicas).|Não|
|N3b<br>Metástase nodal macroscópica|Não|
|N3c<br>Metástases satélites ou em trânisto com duas|Sim|
|ou mais metástases em linfonodo regional.||
|**Metástases à distância**||
|**Categoria M**<br>**Local Anatômico**|**Nível sérico de Desidrogenase**<br>**Láctica (DHL)**|
|M0<br>Sem evidência de metástase à distância.|Não aplicável|  
|M1||Evidência de metástase à distância.|Conforme a seguir|
|---|---|---|---|
|M1a||Metástase para pele, tecido subcutâneo ou|Não informado ou não especificado|
||M1a(0)|linfonodos além dos linfonodos regional.|Não elevado|
||M1a(1)||Elevado|
|M1b||Metástases em pulmão|Não informado ou não especificado|
||M1b(0)||Não elevado|
||M1b(1)||Elevado|
|M1c||Metástases em outros locais fora do SNC|Não informado ou não especificado|
||M1c(0)||Não elevado|
||M1c(1)||Elevado|
|M1d||Metástases em SNC|Não informado ou não especificado|
||M1d(0)||Não elevado|
||M1d(1)||Elevado|  
Adaptado de UICC<sup>54</sup> .  
Em melanoma categorizado como pT1cM0, anotar cN0 em vez de pNX, na ausência de linfonodos regionais acometidos. [p = patológico; c = clínico]. DHL=desidrogenase láctica; M=metástase; N=nodo (linfonodo); SNC=sistema nervoso central; Sufixos para a categoria M: (0) DHL não elevada e (1) DHL elevada; T=tumor.  
**Quadro 4** - Estadiamento clínico e patológico do melanoma cutâneo  
||Estadia<br>|mento clínico<br>||
|---|---|---|---|
|ESTÁDIO|T|N|M|
|0|Tis|N0|M0|
|IA|T1a|N0|M0|
|IB|T1b ou T2a|N0|M0|
|IIA|T2b ou T3a|N0|M0|
|IIB|T3b ou T4a|N0|M0|
|IIC|T4b|N0|M0|
|III|Qualquer T, Tis|≥N1|M0|
|IV|Qualquer T|Qualquer N|M1|
||<br>Estadiame<br>|<br>nto patológico<br>||
|ESTÁDIO|T|N|M|
|0|Tis|N0|M0|
|IA|T1a ou T1b|N0|M0|
|IB|T2a|N0|M0|
|IIA|T2b ou T3a|N0|M0|
|IIB|T3b ou T4a|N0|M0|
|IIC|T4b|N0|M0|
|III|Qualquer T|≥N1|M0|
|IIIA|T1a, T1b ou T2a|N1a ou N2a|M0|
|IIIB|T1a, T1b ou T2a<br>T2b - T3a|N1b/c ou N2b<br>N1a/b/c, N2a/b|M0<br>M0|  
||T1a/b, T2a/b, T3a|N2c ou N3a/b/c|M0|
|---|---|---|---|
|IIIC|T3b, T4a|≥ N1|M0|
||T4b|N1a/b/c, N2a/b/c|M0|
|IIID|T4b|N3a/b/c|M0|
|IV|Qualquer T, Tis|Qualquer N|M1|  
Adaptado de UICC<sup>54</sup> .  
M=metástase; N=nodo (linfonodo); Sufixos para a categoria M: (0) DHL não elevada, (1) DHL elevada; T=tumor; Tis= melanoma _in situ_ .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Incluem-se nestas DDT os pacientes que apresentarem, pelo menos, um dos critérios a seguir:  
- Lesões pigmentadas na pele ou lesões suspeitas de melanoma cutâneo<sup>56</sup> ;  
- qualquer tipo de melanoma cutâneo invasivo ou variantes melanocíticas intradérmicas atípicas<sup>56</sup> .  
Adicionalmente, pacientes que necessitarem de tratamento adjuvante, terapia sistêmica, tratamento cirúrgico e  
radioterapia devem apresentar critérios de inclusão específicos, conforme a seguir:  
- Para tratamento adjuvante: pacientes com melanoma cutâneo em estádio III.  
- Para terapia sistêmica ou tratamento cirúrgico (ressecção de metástases à distância): pacientes com melanoma cutâneo  
- em estádio IV limitado ou disseminado.  
- Para radioterapia: pacientes com melanoma cutâneo em estádio IV disseminado (irressecável) e pacientes sob cuidados  
- paliativos.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Excluem-se destas DDT os pacientes com diagnóstico de outros tipos de câncer de pele, como o carcinoma basocelular e carcinoma de células escamosas (epidermoide)<sup>56</sup> ou de melanomas não cutâneos, como melanoma primário de mucosa ou melanoma ocular<sup>45</sup> .  
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso do respectivo procedimento ou medicamento recomendados nestas Diretrizes.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **6. CASOS ESPECIAIS** -->
A gravidez pode vir acompanhada de uma atividade maior de melanócitos, o que pode causar mudanças na pigmentação da pele. A possibilidade de haver desfechos piores para caso de melanoma associado à gravidez é controversa. Em meta-análise, observou-se 17% de probabilidade aumentada de mortalidade nos casos de melanoma associado à gravidez, variando entre 3% e 33%, no desfecho de sobrevida global. Já para sobrevida livre de doença, estimou-se um aumento de 50% da probabilidade de recorrência da doença em casos de melanoma associado à gravidez, variando de 19% a 90%<sup>57</sup> . Por isso, mulheres que desejam engravidar após a excisão de melanoma em estádio I ou II devem ser aconselhadas a postergar a gravidez por dois anos após o procedimento cirúrgico, por causa do risco aumentado de recorrência<sup>43</sup> . É importante conscientizar os médicos da importância de diagnosticar o melanoma mesmo em pacientes grávidas, uma vez que um nevo modificado durante a gravidez pode ser confundido com um achado normal. Assim, deve-se realizar biópsia de qualquer lesão pigmentada que sofra alteração durante a gravidez, sendo recomendado o mesmo tratamento para mulheres grávidas e não grávidas<sup>43,58</sup> . A biópsia excisional com margens largas pode ser feita com segurança, sob anestesia local, em qualquer momento da gravidez. Esse procedimento permite a análise histopatológica, o prognóstico e é potencialmente curativo, por isso não deve ser adiado para o período pós-parto<sup>58–60</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7. TRATAMENTO** -->
O tratamento é definido após a confirmação histopatológica e o estadiamento do caso<sup>13,33,55</sup> . As modalidades terapêuticas do melanoma cutâneo incluem tratamento cirúrgico (excisão com margens ampliadas, investigação de linfonodo sentinela, esvaziamento linfático e ressecção de metástases à distância), tratamento adjuvante, terapia sistêmica e radioterapia<sup>23</sup> .  
Sabe-se que o melanoma tem característica imunogênica e que pode haver regressão tumoral, possivelmente por resposta imunológica do hospedeiro<sup>61</sup> . A regressão histológica é definida como a área dentro do tumor em que as células neoplásicas desapareceram ou diminuíram em número na derme (e epiderme), sendo substituídas por fibrose, novos vasos e infiltrado inflamatório<sup>61–63</sup> . Em casos de melanoma, é possível observar regressão com frequência entre 10% e 35%<sup>61,64</sup> . Em revisão sistemática com meta-análise, foi encontrado que pacientes com regressão tumoral de melanoma tiveram menor probabilidade de terem lifonodo sentinela positivo [ _odds ratio_ (OR) de 0,56; com intervalo de confiança de 95% (IC95%) de 0,41 a 0,77] em comparação com pacientes sem regressão<sup>61</sup> . Em outras palavras, o risco de metástase de melanoma para o linfonodo sentinela foi significantemente menor em pacientes com regressão histológica em comparação com aqueles sem regressão<sup>61</sup> . Ademais, pacientes com regressão histológica de melanoma primário tiveram menor probabilidade de morrer [risco relativo (RR) de 0,77; com IC95% de 0,61 a 0,97) do que aqueles sem regressão histológica<sup>65</sup> . No momento, não é possível formular recomendações no que se refere a esse achado.  
Também é possível que um melanoma secundário (em linfonodos ou visceral) apareça mesmo sem local primário evidente, o que é conhecido como melanoma de sítio primário desconhecido e suspeita-se que essa manifestação ocorra devido à regressão histológica<sup>66</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.1.1. Excisão com margens ampliadas** -->
No momento do diagnóstico, a maioria dos pacientes com melanoma cutâneo apresenta-se com a neoplasia nos estádios iniciais IA (T1a, N0, M0) e IIA (T2a ou T3a, N0, M0), tanto no Brasil quanto em países desenvolvidos<sup>13,22,35</sup> . Nesses pacientes, o tratamento cirúrgico é curativo em 70% a 90% dos casos.  
Após a biópsia de excisão do melanoma, de acordo com o diagnóstico e o estadiamento, é realizada a excisão radical da cicatriz remanescente com ampliação de margens<sup>7,16,22</sup> . No caso de tumor metastático, são necessários exames adicionais para determinar a melhor conduta. A ampliação de margens é necessária, uma vez que a excisão com margens estreitas pode ser acompanhada de recidiva local, pela frequência de possíveis lesões satélites<sup>16,22</sup> .  
As margens clínicas recomendadas em tratamento cirúrgico para excisão com margens ampliadas de melanoma primário variam conforme a espessura do tumor ( **Quadro 5** ).  
**Quadro 5** – Margens para excisão com margens ampliadas de melanoma cutâneo.  
|**Espessura do tumor**|**Margens cirúrgicas recomendadas**|
|---|---|
|_In situ_|0,5 – 1,0 cm|
|Menor ou igual a 1,0 mm|1,0 cm|
|Entre 1,0 e 2,0 mm|1,0 – 2,0 cm|
|Entre 2,1 e 4,0 mm|2,0 cm|
|Maior que 4,0 mm|2,0 cm|  
Adaptado de NCCN<sup>45</sup> .  
Uma revisão sistemática com meta-análise publicada em 2021 avaliou a excisão de melanoma cutâneo com margens consideradas estreitas (1 a 2 cm) e largas (3 a 5 cm) e apontou que não houve diferença estatisticamente significativa entre os  
grupos para os desfechos: recorrência loco regional (RR 1,09; IC95% 0,98 a 1,22; P=0,12), recorrência local (RR 1,20; IC95% 0,66 a 2,21; P=0,55), metástases em trânsito (RR 1,30; IC95% 0,86 a 1,97; P=0,21), risco de desenvolver metástase linfonodal regional (RR 1,04; IC95% 0,91 a 1,18; P=0,56), risco de desenvolver metástase a distância (RR 0,55; IC95% 0,72 a 1,24; P=0,68), morte (RR 1,00; IC95% 0,93 a 1,07; P=0,97), nem morte por causa de melanoma (RR 1,11; IC95% 0,96 a 1,28; P=0,16). Houve diferença entre os grupos tratados com margens estreitas _versus_ largas para o risco de precisar de enxerto de pele, que foi significativamente menor para o grupo que passou por excisão estreita (RR 0,30; IC95% 0,19 – 0,49; P<0,05)<sup>67</sup> .  
Esses achados estão consonantes com os descritos em diretrizes internacionais<sup>23,45,68</sup> , e recomenda-se que sejam utilizados os parâmetros de extensão de margens especificados no **Quadro 5** para a excisão com ampliação de margens. A **Figura 1** traz o fluxograma para tratamento de pacientes com melanoma cutâneo nos estádios 0 e IA.  
**Figura 1** - Fluxograma de tratamento de pacientes com melanoma cutâneo em estádios 0 e IA. Adaptado de NCCN<sup>45</sup>  
<!-- Start of picture text -->
. Paciente com melanoma<br>Paciente com melanoma = 7m<br>. a cutaneo em estadio IA (T1a)<br>cutaneo em estadio0 in situ (espessura <0,8 mm, sem<br>ulceragao)<br>Anamnese completa e exame fisico;<br>Exames de imageme testes de laboratério<br>de rotina nao so recomendados;<br>Exames de imagem somente para avaliar<br>sinais e sintomas especificos<br>Tratamento primario<br>Excisdo com margens<br>ampliadas<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.1.2. Investigação de linfonodo sentinela** -->
Os locais mais prováveis para os quais células de melanoma cutâneo podem se disseminar, sem contar a pele próxima à lesão primária, são os linfonodos regionais. Como os linfonodos sentinela (linfonodos de drenagem imediata) são os primeiros a receber a linfa drenada do local onde o melanoma cutâneo se encontra, eles apresentam o maior risco de invasão regional<sup>23,43,69</sup> . Portanto, a presença ou ausência dessas células no linfonodo sentinela é preditora de recorrência neoplásica e de sobrevida de pacientes com melanoma cutâneo<sup>23</sup> .  
A linfocintilografia pré-operatória deve ser realizada com tecnécio associado a corante azul patente e _gama-probe_ intraoperatório para determinar o primeiro linfonodo de drenagem da cadeia linfonodal acometida pelo tumor. Em seguida,  
devem ser realizados a biópsia do linfonodo sentinela (determinado pela linfocintilografia) e o exame histopatológico do material biopsiado. Ressalta-se que o uso de amostras congeladas para biópsia pode reduzir a sensibilidade do exame, além de ser necessário sacrificar parte do linfonodo para obtenção de material confiável. Esses fatores prejudicam a deteccção de células de melanoma ou células metastáticas isoladas<sup>7,70</sup> .  
Como a biópsia do linfonodo sentinela permite a avaliação do acometimento linfático regional, caso esta não identifique metástase a possibilidade de não ocorrer doença metastática na respectiva cadeia linfática é superior a 95%. A retirada de amostra do linfonodo sentinela preserva os pacientes da morbidade associada a dissecções linfáticas extensas e desnecessárias<sup>71</sup> , sendo indicada para os pacientes com diagnóstico de melanoma cutâneo com espessura tumoral maior que  1,0 mm<sup>43</sup> . Para pacientes com a doença em estádio IB, T1b (espessura de Breslow menor que 0,8 mm, com ulceração ou de 0,8 a 1 mm com ou sem ulceração) ou ocasionalmente com lesão classificada como T1a em que o tumor tem espessura menor que 0,8mm, se existirem fatores de mau prognóstico, como invasão linfovascular e ulceração, os riscos e benefícios do procedimento devem ser discutidos com o paciente.  
A **Figura 2** traz o fluxograma para tratamento de casos de melanoma cutâneo em estádio IB (T1b). Por sua vez, o fluxograma de tratamento dos pacientes em estádios IB (T2a) ou II (T2b ou mais alto) encontra-se na **Figura 3** .  
**Figura 2** - Fluxograma de tratamento de pacientes com melanoma cutâneo em estádio IB (T1b). Adaptado de NCCN<sup>45</sup>  
<!-- Start of picture text -->
Paciente com melanoma<br>cutneo em estédio 18 (T1b)<br>{espessura <0,8 mm com<br>uleeracdo ou espessura de 0.8<br>‘mm a 1mm com ou sem<br>uleeragdo}<br>‘Anamnese completa e exame fisico:<br>Exames de imagem ettestes de laboratério<br>de rotina nio so recomendados;<br>Exames de imagem somente para avaliar<br>sinals e sintomas especificos<br>Discutir e considerar biépsia,<br>de linfonodo sentinela<br>Tratamento primsrio Tratamento primério<br>Excisdoampliadas com margens ampliadasExcisocomlinfonodo e bidpsiasentinelamargens de<br>Linfonodopositivesentinela Linfonodonegativesentinela<br>Paciente com melanoma<br>cuténeo estédio Ill<br><!-- End of picture text -->  
**Figura 3** - Fluxograma de tratamento de pacientes com melanoma cutâneo estádios IB (T2a) ou II (T2b ou mais alto). Adaptada de NCCN<sup>45</sup> .  
<!-- Start of picture text -->
Paciente com melanoma<br>cutneo em estédio IB (T2a)<br>ou Il (T2b ou mais alto)<br>Anamnese completa e exame fisico;<br>Exames de imagem e testes de laboratério<br>de rotina no so recomendados;<br>Exames de imagem somente para avaliar<br>sinais e sintomas especificos<br>Discutir e oferecer bidpsia de<br>linfonodo sentinela<br>Tratamento primario Tratamento primario<br>Excisdo com margens Excisdo com margens<br>ampliadas ampliadaslinfonodo e biépsiasentinela de<br>Linfonodo sentinela Linfonodo sentinela<br>positivo negativo<br>Paciente com melanoma Paciente em<br>cutneo estédio Ill observac3o<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.1.3. Esvaziamento linfático e ressecção** -->
Historicamente, a presença de linfonodo sentinela positivo era considerada indicação de linfadenectomia regional. Contudo, dois recentes ensaios clínicos randomizados, que compararam a dissecção linfonodal completa com observação clínica (acompanhada de palpação e ultrassonografia do linfonodo) em caso de recorrência, não demonstraram qualquer melhora na sobrevida relacionada ao melanoma ou sobrevida livre de metástases. Os pacientes indicados para observação apresentaram menores índices de linfedema (24,1% _vs_ 6,3%)<sup>72,73</sup> . Por outro lado, o esvaziamento linfonodal diminuiu a recorrência local e auxiliou na identificação dos pacientes que podem ser beneficiados pela terapia adjuvante<sup>56,74</sup> . Assim, os resultados desses estudos reforçam a observação e o acompanhamento com ultrassonografia da região afetada, de modo que a dissecção linfonodal completa seja reservada aos casos de recidiva, mediante o acompanhamento ecográfico, ou quando o exame patológico dos linfonodos for determinante para a decisão de realização de adjuvância<sup>55,74</sup> .  
Pacientes com recidiva em linfonodos regionais devem ser submetidos à dissecção de todos os linfonodos da respectiva cadeia de drenagem, embora não se tenha na literatura registro de um benefício evidente de sobrevida global. A presença de invasão linfática pode significar doença sistêmica e confere ao paciente um prognóstico pior, estando associada a uma sobrevida em torno de 40% em 5 anos<sup>22,55</sup> .  
As diretrizes terapêuticas escocesas recomendam a linfadenectomia completa em pacientes com biópsia positiva no linfonodo sentinela<sup>43</sup> . Tal procedimento cirúrgico envonlve a remoção completa de todos os linfonodos da cadeia de drenagem  
para análise patológica completa<sup>43</sup> . Assim, a remoção cirúrgica de toda a região ao redor do linfonodo é indicada para metástases de linfonodos regionais (estádio III)<sup>23</sup> . Após esse procedimento, existe o risco de linfedema, por isso, os pacientes devem ter acesso aos serviços de um especialista na área<sup>43</sup> .  
O tratamento de pacientes com melanoma cutâneo estádio III está esquematizado na **Figura 4** .  
**Figura 4** - Fluxograma de tratamento de pacientes com melanoma cutâneo em estádio III. Adaptado de NCCN<sup>45</sup> .  
<!-- Start of picture text -->
Paciente com melanoma Paciente com melanoma<br>cutaneo em estédio IIIA cutneo em estddio IIIB/C/D<br>(linfonodo sentinela (linfonodo sentinela<br>positivo) positivo)<br>Considere realizar exames de imagem i<br>para estadiamento‘ *einicial; Examesi  devehimagem para i<br>° sh<br>Exames de, imagem para avaliarin sinais estadiamento‘ale wel iniciale para‘fh avaliar<br>e sintomas especificos; sinais: e sintomas especificos;Prentifh<br>; tes<br>Considere mutac3otestar para BRAF identificara Considereimutagotestar paraBRAFidentificara<br>Tratamento primério<br>Acompanhamento por<br>meio de ultrassom da bacia<br>linfatica (preferivel)<br>ou<br>Dissecgo linfonodal<br>completa<br>Quimioterapia adjuvants<br>Alfainterferona, de acordo<br>com 0 protocolo de CACON/<br>UNACON<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.1.4.  Ressecção de metástases à distância** -->
Se, após os exames de estadiamento, houver suspeita de doença metastática, pode ser realizada punção aspirativa com agulha fina guiada por exame de imagem ou biópsia aberta da área suspeita para confirmação histopatológica. Quando um desses exames for positivo para malignidade, deve-se considerar as opções terapêuticas a seguir, de acordo com os achados:  
- Metástase solitária ou limitada: ressecção ou terapia sistêmica, principalmente quando há progressão da metástase;  
- metástases disseminadas não acometendo o sistema nervoso central (SNC): terapia sistêmica;  
- metástases disseminadas acometendo o SNC: tratamento cirúrgico, radioterapia e, caso indicada, terapia sistêmica.  
A ressecção de metástases à distância pode ser indicada para alguns casos selecionados<sup>75</sup> . A metastasectomia pode ser uma opção para pacientes cujas metástases estejam em pele distante, linfonodo ou víscera (melanoma cutâneo em estádio IV)<sup>43</sup> . A conduta deve ser individualizada, sendo que o procedimento cirúrgico pode ter caráter paliativo (tratando sintomas e melhorando a qualidade de vida) ou curativo<sup>75</sup> .  
O tratamento de pacientes com melanoma cutâneo em estádio IV limitado, isto é, operável e ressecável, está resumido na **Figura 5.**  
**Figura 5** - Fluxograma de tratamento de pacientes com melanoma em cutâneo estádio IV limitado (operável e ressecável). Adaptado de NCCN<sup>45</sup> .  
<!-- Start of picture text -->
Paciente com melanams<br>cutneo em estidia IV<br>(metastética)<br>Bispsia para confirmag3o;<br>Mensuragia de LOM;<br>Exames de imagem para estadiamenta e<br>para avaliar sinais e sintomas especificos<br>Tratamento‘Soence  da Tratamentodoenga  da<br>netactitica metastitica<br>Ressecro Tratamentosistémica<br>Sem. O imagemExames depara<br>doenga ou progressio<br>Tratar camo<br>disseminadavia parecutrePositive pareNegativeautre<br>etistace metistase<br>‘Tratamento adjuvante<br>Opgdes de terapia sistémica:<br>Nivalumabe,<br>pembralizumabe;<br>Observaso<br>Doenca<br>residual<br>sem<br>evidéncia de<br>doenga<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.2. Tratamento adjuvante** -->
Pacientes com tumores em estádio IB [T1b (menor que 0,8 mm, com ulceração); (0,8 a 1,0 mm, com ou sem ulceração) ou T2a (maior que 1,0 a 2,0 mm, sem ulceração)], em estádio IIC (T4b - maior que 4,0 mm, com ulceração) ou em estádio III (qualquer T, Tis e igual ou maior a N1, isto é, com acometimento linfático regional) têm um risco de recorrência que varia de 30% a 80%. Estes grupos de alto risco constituem o foco principal dos estudos que avaliaram a eficácia da terapia adjuvante<sup>13,16</sup> . Em casos de melanoma cutâneo de alto risco (estádios IIB e IIC; espessura tumoral maior que 2,0 mm), terapias adjuvantes ainda não são estabelecidas como de rotina para este grupo<sup>23</sup> .  
Em 2012, a CONITEC recomendou a incorporação no SUS da alfainterferona para a quimioterapia adjuvante do melanoma cutâneo em estádio III<sup>76</sup> . No que tange o uso de alfainterferona na terapia adjuvante, os _guidelines_ da NCCN comentam que o benefício do seu uso é pequeno, apesar de ser estatisticamente significante e que as terapias-alvo e as imunoterapias são  
mais efetivas e mais bem toleradas do que a  alfainterferona e, portanto, não recomenda mais o seu uso<sup>45</sup> . Já as diretrizes de tratamento escocesas recomendam que a alfainterferona apenas seja empregada em contexto de pesquisa clínica como terapia adjuvante de pacientes com melanoma estádio II e III<sup>43</sup> . As diretrizes da Sociedade Americana de Oncologia Clínica (ASCO) não recomenda o uso de ipilumimabe nem de alfainterferona em altas doses de forma rotineira<sup>77</sup> .  
Existem revisões sistemáticas e meta-análises recentes que abordam o uso da alfainterferona como tratamento adjuvante do melanoma cutâneo, sendo que a comparação mais comum nos estudos incluídos era da alfainterferona _versus_ observação clínica (p.ex., sem tratamento)<sup>78</sup> . Uma meta-análise apoia a eficácia da alfainterferona adjuvante para o tratamento de pessoas com melanoma cutâneo de alto risco (TNM estádio II-III) em termos de sobrevida livre de doença (17%; IC95% 13% a 22%) e, em menor grau, sobrevida global (9%; IC95% 3% a 15%)<sup>78</sup> . Observaram-se eventos adversos graus 3 e 4 em uma minoria de participantes. Tais eventos prejudicaram a qualidade de vida, mas desapareceram após a suspensão do tratamento<sup>78</sup> . Os pacientes tratados com alfainterferona tiveram melhor sobrevida ajustada à qualidade de vida em comparação com aqueles que foram somente observados<sup>78</sup> . Outro estudo mostrou que a alfainterferona diminui o risco de recorrência em 14% e resulta em benefício na medida de sobrevida global<sup>79</sup> , isto é, foi encontrada redução proporcional de 10% no risco de morte com o seu uso<sup>79</sup> . Apesar de clinicamente significativo, a diferença absoluta de mortalidade em 10 anos foi cerca de 3%<sup>79</sup> . Não houve evidência de relação dose-resposta com doses crescentes de alfainterferona nem evidência de diferença em termos da duração de tratamento<sup>79</sup> .  
Decisões de tratamento para pacientes com alto risco devem ser individualizadas, com base em uma estimativa do risco de recidiva de acordo com os critérios de estadiamento TNM e presença de comorbidades. Ensaios clínicos randomizados (ECR) que explorem outras terapias para essa população ainda são necessários, devendo o uso de alfainterferona adjuvante ser discutido com os pacientes no que diz respeito ao seu risco-benefício. O tratamento com alfainterferona tem impacto negativo na qualidade de vida dos pacientes e os seus eventos adversos limitam seu uso prolongado, principalmente quando usada em doses mais altas<sup>79</sup> .  
As recomendações da Sociedade Americana de Oncologia Clínica (ASCO) especificam alternativas de tratamento para pacientes com base na presença de mutação em _BRAF_ , e sugerem que esse teste deve ser feito no momento do diagnóstico<sup>77</sup> . Também ressalta que somente o teste para mutação em _BRAF_ seria necessário antes de iniciar terapia adjuvante com inibidores de _BRAF/MEK_<sup>77</sup> . E recomenda o nivolumabe ou o pembrolizumabe por 52 semanas para pacientes com doença estádios IIIA/B/C/D ressecável que são _BRAF_ tipo selvagem<sup>77</sup> .  
A ASCO ressalta que não se podem fazer recomendações sobre dabrafenibe + trametinibe em pacientes com melanoma estádios III/IV ressecável com mutações _BRAF_ a não ser que seja a mutação V600E/K<sup>77</sup> . Para estes, isto é, pacientes com doença _BRAF_ mutante (V600E/ K*) estádios IIIA/B/C/D ressecável, recomenda o uso de: nivolumabe ou pembrolizumabe ou dabrafenibe + trametinibe, por 52 semanas<sup>77</sup> . Pacientes com melanoma estádio IV ressecável poderiam receber, de acordo com essas diretrizes americanas, nivolumabe adjuvante, pembrolizumabe ou dabrafenibe + trametinibe (se apresentarem a mutação em _BRAF_ ) e cita que alterações entre essas associações de inibidor de _BRAF/MEK_ podem ser consideradas, caso os pacientes apresentem toxicidade<sup>77</sup> . Entretanto, no caso de falha no uso desses medicamentos, inexistem dados sobre a mudança para outra associação<sup>77</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.3. Tratamento da doença metastática** -->
A ASCO orienta, para pacientes com melanoma cutâneo metastático/irressecável com _BRAF_ tipo selvagem, as seguintes opções: ipilimumabe + nivolumabe, seguido de nivolumabe ou nivolumabe em monoterapia ou pembrolizumabe<sup>77</sup> . Ao passo que, para pacientes com melanoma cutâneo metastático/irressecável mutante em _BRAF_ (V600), recomenda como opções: ipilimimabe + nivolumabe seguido de nivolumabe ou nivolumabe ou pembrolizumabe ou dabrafenibe + trametinibe ou encorafenibe + binimetinibe ou vemurafenibe + cobimetinibe<sup>77</sup> .  
Já as diretrizes de tratamento escocesas recomendam que o vemurafenibe e o dabrafenibe podem ser usados como monoterapia para pacientes com melanoma metastático ou irressecável, com mutação em _BRAF_ (V600), como primeira linha<sup>43</sup> .  
Também recomenda trametinibe + dabrafenibe para pacientes com melanoma metastático ou irressecável, com mutação _BRAF_ (V600), estádios IIIC ou IV<sup>43</sup> .  
A Conitec avaliou a evidência de eficácia e segurança do ipilimumabe no tratamento do melanoma metastático ou não cirúrgico. Apesar da alta eficácia do ipilimumabe em comparação com a dacarbazina, identificou-se que existiam registros nacionais de outras imunoterapias mais eficazes do que o ipilimumabe<sup>80</sup> . Essas razões, entre outras citadas no Relatório de Recomendação n° 391 de outubro de 2018, levaram a Conitec a recomendar a não incorporação do ipilimumabe para tratar pacientes com melanoma cutâneo metastático<sup>80</sup> .  
Posteriormente, foram avaliadas as principais evidências científicas disponíveis na literatura sobre a eficácia e segurança das chamadas terapias-alvo (vemurafenibe, dabrafenibe, cobimetinibe e trametinibe) e das chamadas imunoterapias (pembrolizumabe, nivolumabe e ipilimumabe) em comparação à quimioterapia com dacarbazina para o tratamento de primeira linha do melanoma avançado não cirúrgico e metastático. Conforme o Relatório de Recomendação n° 541 de julho de 2020, a recomendação final da Conitec foi favorável à incorporação da classe anti-PD1 (nivolumabe ou pembrolizumabe) para tratamento de primeira linha do melanoma avançado não cirúrgico e metastático, conforme a assistência oncológica no SUS<sup>81</sup> .  
De acordo com o referido Relatório de Recomendação n° 541, avaliaram-se as comparações possíveis entre vemurafenibe, dabrafenibe, cobimetinibe e trametinibe, e entre pembrolizumabe, nivolumabe e ipilimimabe, em monoterapia e em terapia combinada, comparativamente com a dacarbazina, nos desfechos de eficácia e segurança para tratamento de primeira linha de melanoma avançado não cirúrgico (irressecável) e metastático<sup>81</sup> . Foram incluídas três revisões sistemáticas com metaanálise em rede e os resultados mostraram que todas as terapias foram superiores à dacarbazina nos desfechos de sobrevida livre de progressão e de sobrevida global, exceto o dabrafenibe, e que o uso combinado apresentou melhor efeito terapêutico do que isolado<sup>81–84</sup> . No que se refere à sobrevida livre de progressão, não houve diferença entre diferentes medicamentos da mesma classe nem entre as ditas terapias-alvo e imunoterapia combinadas dentro da mesma classe<sup>81</sup> . Quanto à sobrevida global, a redução do risco de morte para as imunoterapias isoladas anti-PD-1 foi de 54%, segundo melhor resultado após a combinação de nivolumabe com ipilimumabe<sup>81</sup> . A taxa de sobrevida global em cinco anos para imunoterapia isolada (nivolumabe ou pembrolizumabe) foi de 70%, em contraste com cerca de 40% daqueles tratados com dacarbazina<sup>81</sup> . A sobrevida mediana de pacientes em uso de imunoterapia isolada (nivolumabe ou pembrolizumabe) foi de 36 meses em comparação ao uso de dacarbazina, que era de 11 meses<sup>81</sup> . Quanto aos desfechos de segurança, observou-se menor risco de eventos adversos de graus 3 e 4 com imunoterapia isolada (nivolumabe ou pembrolizumabe), porém sem significância estatítica<sup>81,82</sup> .  
O tratamento de pacientes com melanoma cutâneo estádio IV irressecável ou disseminado, isto é, com metástases à distância, está esquematizado na **Figura 6** .  
**Figura 6** - Fluxograma de tratamento de pacientes com melanoma cutâneo em estádio IV disseminado (irressecável). Adaptado de NCCN<sup>45</sup> .  
<!-- Start of picture text -->
Paciente com melanoma<br>cutneo em estédio IV<br>(metastatico)<br>Bidpsia para confirmac3o;<br>Mensura¢o de LDH;<br>Exames de imagem para estadiamento e<br>para avaliar sinais e sintomas especificos<br>Tratamento da Tratamento da<br>doenga doenga<br>metastitica metastitica<br>Com metéstases Sem metéstases<br>cerebrais cerebrais<br>Consulta &<br>equipe<br>multidisciplinar<br>Opsées incluem<br>Terapia sistémica (preferivel);<br>Considerar ressecco paliativa<br>e/ou radioterapia para<br>doenga sintomatica<br>extracraniana;<br>Cuidado paliativo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **7.4. Radioterapia** -->
O melanoma é considerado um tumor resistente à radioterapia quando comparado a outros tipos de câncer<sup>85–87</sup> . Embora o tratamento curativo seja o cirúrgico, com a ressecção completa da lesão primária, com ou sem o esvaziamento linfático regional, a radioterapia mantém-se útil para casos selecionados de tumores irressecáveis, quando o resultado estético do tratamento cirúrgico for desfavorável, principalmente na região da face, da cabeça e do pescoço<sup>85–87</sup> . Ademais, a radioterapia também pode ser usada em pacientes com metástases no cérebro; em caso de tumores muito extensos, previamente à intervenção cirúrgica; para alívio de sintomas; em caso de linfonodomegalias maciças (maior que 3 cm), com quatro ou mais linfonodos acometidos; ou extensão extra-nodal<sup>23</sup> .  
A radioterapia definitiva pode ser uma opção terapêutica de pacientes com melanoma _in situ_ , com melanoma do tipo lentigo maligno inoperável ou com alto risco cirúrgico da ressecção completa<sup>45</sup> .  
O uso de radioterapia adjuvante após ressecção linfática diminui a recidiva local do melanoma, mas não aumenta a sobrevida global dos pacientes<sup>23,45,85–87</sup> . Ademais, a radioterapia adjuvante pode ser indicada em casos de melanoma desmoplástico, a depender de fatores de risco para recorrência local<sup>45</sup> ; de doença em linfonodo regional ressecada de alto risco<sup>45</sup> ; e para melanoma cutâneo em estádios IIIB ou IIIC, considerando-se o potencial de recorrência local e benefícios e riscos, inclusive os eventos adversos da radioterapia<sup>43</sup> .  
A radioterapia também permanece como uma modalidade de tratamento paliativo, principalmente no sistema nervoso central (SNC), na coluna vertebral e nos ossos<sup>85–87</sup> . A radioterapia paliativa pode ser empregada em casos de metástases regionais, no que se refere à doença linfonodal irressecável e metástases satélites ou em trânsito; e à doença residual local, satélite ou em trânsito após tratamento prévio<sup>45</sup> .  
Embora a radioterapia possa ser considerada em casos com alto risco de recidiva local após a linfadenectomia radical, ela não está isenta de toxicidade adicional e o seu risco-benefício deve ser amplamente discutido com os pacientes antes de sua utilização, e novas modalidades terapêuticas e técnicas de radioterapia ainda estão sendo consolidadas para avaliação da melhor eficácia terapêutica<sup>85–87</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **8. MONITORAMENTO** -->
Pacientes sob tratamento devem ser monitorizados para avaliar a resposta terapêutica nos locais de doença prévia, com exames de imagem (TC, preferencialmente) regularmente. Em caso da chamada imunoterapia, deve-se atentar para os efeitos adversos específicos e os respectivos critérios de acompanhamento laboratorial e por imagem, assim como os parâmetros de avaliação da resposta tumoral.  
Pacientes que apresentaram qualquer tipo de evento adverso, inclusive intolerância grave, de graus 3 e 4 aos medicamentos, de acordo com a _Common Terminology Criteria for Adverse Events_ (CTCAE) versão 5<sup>88</sup> ( **Quadro 6** ), devem ter a dose do respectivo medicamento reduzida após avaliação médica. Nesses casos, o paciente deve retornar ao tratamento apenas quando a toxicidade estiver nos graus 1 ou 2. Pacientes que também não tolerarem doses reduzidas devem ter o seu tratamento suspenso. Essa conduta deve considerar o medicamento utilizado, o evento adverso em questão e o benefício atingido. A classificação da gravidade dos eventos adversos está no **Apêndice 1** .  
**Quadro 6** - Eventos adversos e interações dos tratamentos medicamentosos recomendados nestas Diretrizes.  
|**Alfainterferona**|Eventos adversos<br>mais comuns|Alopecia, prurido, pele seca,_rash_cutâneo, hipersudorese;<br>anorexia;<br>depressão, insônia, ansiedade, instabilidade emocional, agitação,<br>nervosismo;<br>diminuição do peso corporal;<br>dispneia, tosse;<br>faringite, infecção viral;<br>febre, fadiga, cefaleia e mialgia;<br>inflamação ou reação no local de injeção, fadiga, arrepios, febre, sintomas<br>semelhantes à gripe, astenia, irritabilidade, dor torácica, mal-estar;<br>leucopenia;<br>mialgia, artralgia, dor músculo-esquelética;<br>náusea, vômitos, dor abdominal, diarreia, estomatite, dispepsia;<br>tonturas, cefaléias, diminuição da capacidade de concentração, xerostomia;<br>visão turva<sup>89</sup>.|
|---|---|---|
||Interações<br>medicamentosas|Medicamentos narcóticos, hipnóticos ou sedativos; agentes potencialmente<br>mielossupressores; teofilina ou aminofilina; aldesleucina; agentes<br>quimioterápicos como citarabina, ciclofosfamida, doxorubicina e<br>teniposídeo<sup>89</sup>.|
|**Nivolumabe**|Eventos adversos|Diarreia, náusea;|  
||mais comuns|diminuição do apetite (anorexia);<br>dor músculo-esquelética, artralgia;<br>erupção cutânea, prurido;<br>hipertensão arterial;<br>hipotireoidismo, hipertireoidismo;<br>infecção no trato respiratório superior;<br>neuropatia periférica, dor de cabeça, tontura;<br>neutropenia;<br>pneumonite, dispneia, tosse;<br>reação infusional, hipersensibilidade<sup>90</sup>.|
|---|---|---|
||Interações<br>medicamentosas|Uso anterior de corticosteroide sistêmico e outros imunossupressores<sup>90</sup>.|
|**Pembrolizumabe**|Eventos adversos<br>mais comuns|Anemia;<br>arritmia cardíaca (incluindo fibrilação atrial);<br>cefaleia;<br>diarreia, dor abdominal, náusea, vômitos, constipação intestinal;<br>dispneia, tosse;<br>dor músculo-esquelética, artralgia;<br>erupção cutânea, prurido;<br>fadiga, astenia, edema, pirexia;<br>hipotereoidismo;<br>pneumonia;<br>reação relacionada infusional;<br>redução do apetite<sup>91</sup>.|
||Interações<br>medicamentosas|Uso anterior de corticosteroides sistêmicos e outros imunossupressores<sup>91</sup>|  
Adaptado de bulas dos medicamentos registrados na ANVISA<sup>89–91</sup> .  
O acompanhamento dos pacientes é feito de acordo com o seu estadiamento clínico, conforme o **Quadro 7** . De maneira geral, após cinco anos, todos os pacientes devem ser seguidos anualmente − a menos que tenham também nevos displásicos, casos em que se recomendam consultas a cada seis meses. O risco de um segundo tumor primário aumenta significativamente nos pacientes com esses nevos e história familiar de melanoma. O exame anual deve continuar por, pelo menos, dez anos, e preferencialmente por toda a vida, porque as recidivas tardias surgem em aproximadamente 3% dos pacientes. O seguimento contínuo é recomendado também para pacientes com nevos displásicos<sup>35</sup> .  
**Quadro 7** - Periodicidade de acompanhamento de pacientes com melanoma cutâneo conforme o estádio  
|**Estádio**|**Acompanhamento**|
|---|---|
|**0**|Não necessita seguimento após tratamento inicial, avaliação dos resultados e orientações<sup>43</sup>.|
|**IA-IIA**|Exame físico a cada 6 a 12 meses nos primeiros 5 anos; após, anualmente.|
||Exames de imagem não são recomendados como rotina, devendo ser realizados apenas caso o paciente<br>apresente sintoma sugestivo de possível metástase.|
|**IIB-IIC**|Exame físico a cada 3 a 6 meses por 2 anos após o diagnóstico. Em seguida, a cada 6 a 12 meses por 3 anos.|  
Após estes períodos, o exame físico deve ser realizado anualmente. Exames de imagem podem ser solicitados a cada 3 a 12 meses conforme a condição clínica do paciente nos primeiros 3 anos. Após este período, devem ser solicitados conforme indicação médica. **III e além** Acompanhamento a cada 3 meses por 5 anos<sup>43</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **9. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes nestas Diretrizes, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Doentes de melanoma cutâneo devem ser atendidos em serviços especializados em oncologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento. Além da familiaridade que esses hospitais guardam com o estadiamento, tratamento e controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do atendimento dos pacientes, facilitando ações de controle e avaliação. Incluem-se, entre essas ações, a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada _versus_ autorizada, valores apresentados _versus_ autorizados _versus_ ressarcidos); e a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente − primeira maior do que segunda maior do que terceira − sinaliza a efetividade terapêutica). Ações de auditoria devem verificar _in loco_ , por exemplo, a existência e observância da conduta ou do protocolo adotado no hospital; a regulação do acesso assistencial; a qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional do paciente (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e integralidade assistenciais; e o grau de satisfação dos pacientes.  
Do **Quadro 8** constam alguns dos profissionais que podem ser acionados para avaliação e acompanhamento de pacientes com melanoma, a depender da disponibilidade local na atenção especializada à saúde (níveis secundário e terciário do SUS).  
**Quadro 8** - Divisão de atribuições entre especialistas conforme a disponibilidade de profissionais  
|**Especialistas**|**Atribuições**|
|---|---|
|**Dermatologista**|• Para vigilância de indivíduos com maior risco de melanoma com base no fenótipo do nevo,<br>histórico familiar, sensibilidade ao sol e outros fatores.<br>• Para detecção precoce de lesões pigmentadas suspeitas, particularmente em indivíduos<br>com risco aumentado de ter melanoma.<br>• Para a vigilância da pele e o monitoramento de longo prazo de pacientes com melanoma<br>cutâneo, para detectar possíveis novos melanomas primários.<br>• Para a avaliação clínica e biópsia de lesões de pele suspeitas de melanoma.<br>• Para discutir a conduta terapêutica em equipe de especialistas.<br>• Para o tratamento cirúrgico de melanoma cutâneo inicial.|
|**Cirurgião Oncológico**|• Para detecção precoce de lesões pigmentadas suspeitas, particularmente em indivíduos|
|**e outros Cirurgiões**|com risco aumentado de ter melanoma.|
|**Especialistas**|• Para a avaliação clínica e biópsia de lesões de pele suspeitas de melanoma.|  
||• Para discutir a conduta terapêutica em equipe de especialistas.<br>• Para o tratamento cirúrgico de melanoma cutâneo em qualquer estágio tumoral ou<br>recidivado, inclusive biópsia de linfonodo sentinela, com ou sem linfadenectomia.<br>• Para tratamento cirúrgico paliativo de metástases viscerais e no SNC.<br>• Para acompanhar os pacientes tratados cirurgicamente.|
|---|---|
|**Oncologista**<br>**Clínico**<br>**e**|• Para a avaliação clínica e encaminhamento de casos de lesões de pele suspeitas de<br>melanoma.<br>• Para discutir a conduta terapêutica em equipe de especialistas.|
|**Oncologista Pediátrico**|• Para avaliar, indicar e encaminhar casos para radioterapia.<br>• Para avaliar, indicar, prescrever e monitorar tratamento sistêmico adjuvante.<br>• Para avaliar indicar, prescrever e monitorar tratamento sistêmico paliativo.<br>• Para acompanhar os pacientes tratados.|
|**Médico Nuclear**|• Para linfocintilografia pré-operatória se for realizado biópsia de linfonodo sentinela.<br>• Para interpretação dos respectivos exames cintilográficos.|
|**Médico Patologista**|• Para diagnosticar e estabelecer o estadiamento patológico (a partir de material de biópsia,<br>biópsia de congelação e peça cirúrgica, do tumor primário e de locais de metástases<br>regionais e à distância).|
|**Radioterapeuta**<br>**(Radioncologista)**|• Para discutir a conduta terapêutica em equipe de especialistas.<br>• Para avaliar, indicar, prescrever e monitorar a radioterapia.<br>• Para acompanhar os pacientes tratados.|  
Adaptado de Swetter et al<sup>1</sup> .  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a poliquimioterapia do linfoma folicular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama, que são adquiridos pelo Ministério da Saúde e fornecidos aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde. Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais as terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados pelo SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento de medicamento antineoplásico é do hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos (Grupo 03, Subgrupo 01) e cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Relativamente ao sítio primário ou secundário, os procedimentos cirúrgicos da tabela do SUS aplicáveis a pacientes  
com diagnóstico melanoma cutâneo encontram-se no Grupo 04 e podem ser acessados por código ou nome do procedimento e por código da CID-10.  
Os procedimentos radioterápicos da tabela do SUS aplicáveis a pacientes com diagnóstico de melanoma cutâneo são os seguintes:  
03.04.01.011-1 - Internação p/ radioterapia externa (cobaltoterapia/acelerador linear)  
03.04.01.040-5 - Radioterapia de pele  
03.04.01.052-9 - Radioterapia de metástase em sistema nervoso central  
03.04.01.053-7 - Radioterapia de plasmocitoma / mieloma / metástases em outras localizações  
Os procedimentos da Tabela do SUS para a quimioterapia de melanoma cutâneo são os seguintes:  
_Quimioterapia paliativa – adulto_  
03.04.02.023-0 - Quimioterapia do melanoma maligno avançado  
_Quimioterapia adjuvante (profilática) – adulto_  
03.04.05.032-6 - Quimioterapia de melanoma maligno

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **10. REFERÊNCIAS** -->
1. Swetter S, Wells M, Albertini J, Elston D. Cutaneous Melanoma [Internet]. Medscape. 2019. Available from:  
https://emedicine.medscape.com/article/1100753-overview  
2.  Ribas A, Read P, Slingluff Jr C. Cutaneous Melanoma. In: DeVita Jr V, Lawrence T, Rosenberng S, editors. DeVita,  
Hellman, and Rosenberg’s cancer: principles & practice of oncology. EUA: Wolters Kluwer Health; 2015. p. 1510–60.  
3.  Kang S, Amagai M, Bruckner A, Enk A, Margolis D, McMichael J, et al. Fitzpatrick’s Dermatology. 9th Editio.  
McGraw-Hill Education, editor. 2019.  
4.  Polsky D, Cordon-Cardo C. Oncogenes in melanoma. Oncogene. 2003 May;22(20):3087–91.  
5.  American Cancer Society. Cancer facts and figures 2018. Atlanta: American Cancer Society; 2018.  
6.  Dimitriou F, Krattinger R, Ramelyte E, Barysch MJ, Micaletto S, Dummer R, et al. The World of Melanoma:  
Epidemiologic, Genetic, and Anatomic Differences of Melanoma  Across the Globe. Curr Oncol Rep. 2018 Sep;20(11):87.  
7.  Nasierowska-Guttmejer A, Biernat W, Wiśniewski P, Kordek R, Wysocki W, Jeziorski A, et al. Sentinel lymph node biopsies in patients with malignant melanoma — qualifying principles and histopathological assessment (2017). Nowotwory J Oncol [Internet]. 2017;67(1):41–7. Available from: https://doi.org/10.5603/NJO.2017.0006  
8.  Bevona C, Goggins W, Quinn T, Fullerton J, Tsao H. Cutaneous melanomas associated with nevi. Arch Dermatol.  
2003 Dec;139(12):1620–4; discussion 1624.  
9.  Haenssle HA, Mograby N, Ngassa A, Buhl T, Emmert S, Schön MP, et al. Association of Patient Risk Factors and  
Frequency of Nevus-Associated Cutaneous  Melanomas. JAMA dermatology. 2016 Mar;152(3):291–8.  
10.  Ferlay J, Soerjomataram I, Dikshit R, Eser S, Mathers C, Rebelo M, et al. Cancer incidence and mortality worldwide:  
sources, methods and major patterns in  GLOBOCAN 2012. Int J cancer. 2015 Mar;136(5):E359-86.  
11.  Bakos L, Wagner M, Bakos RM, Leite CSM, Sperhacke CL, Dzekaniak KS, et al. Sunburn, sunscreens, and  
phenotypes: some risk factors for cutaneous melanoma in  southern Brazil. Int J Dermatol. 2002 Sep;41(9):557–62.  
12.  Gandini S, Sera F, Cattaruzza MS, Pasquini P, Zanetti R, Masini C, et al. Meta-analysis of risk factors for cutaneous  
melanoma: III. Family history, actinic  damage and phenotypic factors. Eur J Cancer. 2005 Sep;41(14):2040–59.  
13.  Boyle P, Maisonneuve P, Doré JF. Epidemiology of malignant melanoma. Br Med Bull. 1995 Jul;51(3):523–47.  
14.  Mendes GLQ, Koifman RJ, Koifman S. Mortality frequency and trends attributed to melanoma in Brazil from 1980-  
2005. J Toxicol Environ Health A. 2010;73(13–14):850–7.  
15.  Simard EP, Ward EM, Siegel R, Jemal A. Cancers with increasing incidence trends in the United States: 1999  
through 2008. CA Cancer J Clin. 2012;62(2):118–28.  
16.  Tsao H, Atkins MB, Sober AJ. Management of cutaneous melanoma. N Engl J Med. 2004 Sep;351(10):998–1012.  
17.  Little EG, Eide MJ. Update on the current state of melanoma incidence. Dermatol Clin. 2012 Jul;30(3):355–61.  
18.  Instituto Nacional do Câncer (INCA)., Brasil. Ministério da Saúde. Instituto Nacional do Câncer José Alencar  
Gomes da Silva (INCA). Estatísticas de câncer [Internet]. 2021. Available from: https://www.inca.gov.br/numeros-de-cancer  
19.  Whiteman DC, Green AC, Olsen CM. The Growing Burden of Invasive Melanoma: Projections of Incidence Rates  
and Numbers  of New Cases in Six Susceptible Populations through 2031. J Invest Dermatol. 2016 Jun;136(6):1161–71.  
20.  Gandini S, Sera F, Cattaruzza MS, Pasquini P, Picconi O, Boyle P, et al. Meta-analysis of risk factors for cutaneous  
melanoma: II. Sun exposure. Eur J Cancer. 2005 Jan;41(1):45–60.  
21.  Thompson JF, Scolyer RA, Kefford RF. Cutaneous melanoma. Lancet (London, England). 2005  
Feb;365(9460):687–701.  
22.  Doherty G, Way L. Cirurgia - diagnóstico e tratamento. 11th Editi. Rio de Janeiro: Guanabara-Koogan; 2004.  
23.  Burns D, George J, Aucoin D, Bower J, Burrell S, Gilbert R, et al. The Pathogenesis and Clinical Management of  
Cutaneous Melanoma: An Evidence-Based  Review. J Med imaging Radiat Sci. 2019 Sep;50(3):460-469.e1.  
24.  Rastrelli M, Tropea S, Rossi CR, Alaibac M. Melanoma: epidemiology, risk factors, pathogenesis, diagnosis and  
classification. In Vivo. 2014;28(6):1005–11.  
25.  Kubica AW, Brewer JD. Melanoma in immunosuppressed patients. Mayo Clin Proc. 2012 Oct;87(10):991–1003.  
26.  Joosse A, Collette S, Suciu S, Nijsten T, Patel PM, Keilholz U, et al. Sex is an independent prognostic indicator for  
survival and relapse/progression-free  survival in metastasized stage III to IV melanoma: a pooled analysis of five European organisation for research and treatment of cancer randomized controlled trials. J Clin Oncol  Off J Am Soc Clin  Oncol. 2013 Jun;31(18):2337–46.  
27.  Liu F, Bessonova L, Taylor TH, Ziogas A, Meyskens FLJ, Anton-Culver H. A unique gender difference in early  
onset melanoma implies that in addition to  ultraviolet light exposure other causative factors are important. Pigment Cell Melanoma Res. 2013 Jan;26(1):128–35.  
28.  Siegel RL, Miller KD, Jemal A. Cancer Statistics, 2017. CA Cancer J Clin. 2017 Jan;67(1):7–30.  
29.  Courtenay WH. Constructions of masculinity and their influence on men’s well-being: a theory of  gender and health.  
Soc Sci Med. 2000 May;50(10):1385–401.  
30.  Ghiasvand R, Weiderpass E, Green AC, Lund E, Veierød MB. Sunscreen Use and Subsequent Melanoma Risk: A  
Population-Based Cohort Study. J Clin Oncol  Off J Am Soc Clin  Oncol. 2016 Nov;34(33):3976–83.  
31.  Watts CG, Drummond M, Goumas C, Schmid H, Armstrong BK, Aitken JF, et al. Sunscreen Use and Melanoma  
Risk Among Young Australian Adults. JAMA dermatology. 2018 Sep;154(9):1001–9.  
32.  Green AC, Williams GM, Logan V, Strutton GM. Reduced melanoma after regular sunscreen use: randomized trial  
follow-up. J Clin Oncol  Off J Am Soc Clin  Oncol. 2011 Jan;29(3):257–63.  
33.  Kittler H, Pehamberger H, Wolff K, Binder M. Diagnostic accuracy of dermoscopy. Lancet Oncol. 2002  
Mar;3(3):159–65.  
34.  Cestari TF, Miozzo A, Brodt C, Pacheco F, Bakos L. Evaluation of ultraviolet-B susceptibility in the population of  
Rio Grande do Sul, Brazil. J Eur Acad Dermatology Venereol. 1997;9(1001):S140.  
35.  Freedber I, Eisen A, Wolff K, Austen K, Goldsmith L, Katz S. Fitzpatrick’s Dermatology in General Medicine. 6th  
Editio. McGraw-Hill Professional; 2003.  
36.  Canadian Cancer Society. Melanome. 2019.  
37.  Callender GG, Egger ME, Burton AL, Scoggins CR, Ross MI, Stromberg AJ, et al. Prognostic implications of  
anatomic location of primary cutaneous melanoma of 1 mm  or thicker. Am J Surg. 2011 Dec;202(6):655–9.  
38.  Balch CM, Soong S, Gershenwald JE, Thompson JF, Coit DG, Atkins MB, et al. Age as a prognostic factor in patients with localized melanoma and regional  metastases. Ann Surg Oncol. 2013 Nov;20(12):3961–8.  
39.  Thompson JF, Soong S-J, Balch CM, Gershenwald JE, Ding S, Coit DG, et al. Prognostic significance of mitotic rate in localized primary cutaneous melanoma: an  analysis of patients in the multi-institutional American Joint Committee on Cancer melanoma staging database. J Clin Oncol  Off J Am Soc Clin  Oncol. 2011 Jun;29(16):2199–205.  
40.  Neuman HB, Patel A, Ishill N, Hanlon C, Brady MS, Halpern AC, et al. A single-institution validation of the AJCC  
staging system for stage IV melanoma. Ann Surg Oncol. 2008 Jul;15(7):2034–41.  
41.  Abbasi NR, Shaw HM, Rigel DS, Friedman RJ, McCarthy WH, Osman I, et al. Early diagnosis of cutaneous  
melanoma: revisiting the ABCD criteria. JAMA. 2004 Dec;292(22):2771–6.  
42.  Healsmith MF, Bourke JF, Osborne JE, Graham-Brown RA. An evaluation of the revised seven-point checklist for  
the early diagnosis of  cutaneous malignant melanoma. Br J Dermatol. 1994 Jan;130(1):48–50.  
43.  Scottish Intercollegiate Guidelines Network (SIGN). Cutaneous melanoma. (SIGN publication no. 146) [Internet].  
SIGN, editor. Edinburgh; 2017. 68 p. Available from: http://www.sign.ac.uk  
44.  Vestergaard ME, Macaskill P, Holt PE, Menzies SW. Dermoscopy compared with naked eye examination for the diagnosis of primary  melanoma: a meta-analysis of studies performed in a clinical setting. Br J Dermatol. 2008 Sep;159(3):669– 76.  
45.  Swetter SM, Thompson JA, Albertini MR, Barker CA, Baumgartner J, Boland G, et al. NCCN Guidelines® Insights: Melanoma: Cutaneous, Version 2.2021: Featured Updates to the NCCN Guidelines. J Natl Compr Cancer Netw J Natl Compr Canc Netw [Internet]. 2021;19(4):364–76. Available from: https://jnccn.org/view/journals/jnccn/19/4/article-p364.xml  
46.  Atkins MB, Hsu J, Lee S, Cohen GI, Flaherty LE, Sosman JA, et al. Phase III trial comparing concurrent biochemotherapy with cisplatin, vinblastine,  dacarbazine, interleukin-2, and interferon alfa-2b with cisplatin, vinblastine, and dacarbazine alone in patients with metastatic malignant melanoma (E3695): a trial coordi. J Clin Oncol  Off J Am Soc Clin Oncol. 2008 Dec;26(35):5748–54.  
47.  Sullivan RJ, Flaherty K. MAP kinase signaling and inhibition in melanoma. Oncogene. 2013 May;32(19):2373–9.  
48.  Nissan MH, Pratilas CA, Jones AM, Ramirez R, Won H, Liu C, et al. Loss of NF1 in cutaneous melanoma is  
associated with RAS activation and MEK  dependence. Cancer Res. 2014 Apr;74(8):2340–50.  
49.  Hayward NK, Wilmott JS, Waddell NN, Johansson PA, Field MA, Nones K, et al. Whole-genome landscapes of  
major melanoma subtypes. Nature. 2017 May;545(7653):175–80.  
50.  Kulikova K, Kibardin A, Gnuchev N, Georgiev G, Larin S. Wnt signaling pathway and its significance for melanoma  
development. CTM Mod Technol Med. 2012;107–11.  
51.  Sullivan RJ. The role of mitogen-activated protein targeting in melanoma beyond BRAFV600. Curr Opin Oncol.  
2016 Mar;28(2):185–91.  
52.  Genomic Classification of Cutaneous Melanoma. Cell. 2015 Jun;161(7):1681–96.  
53.  Bastian BC. The molecular pathology of melanoma: an integrated taxonomy of melanocytic  neoplasia. Annu Rev  
Pathol. 2014;9:239–71.  
54.  Union for International Cancer Control (UICC). TNM Classification of Malignant Tumours [Internet]. Eighth Edi. Brierley JD, Gospodarowicz MK, Wittekind C, editors. John Wiley & Sons, Ltd; 2017. 241 p. Available from: https://www.legeforeningen.no/contentassets/201604933ce448e888a101ab969a4205/tnm-classification-of-malignant-tumours8th-edition.pdf  
55.  Garbe C, Peris K, Hauschild A, Saiag P, Middleton M, Spatz A, et al. Diagnosis and treatment of melanoma. European consensus-based interdisciplinary  guideline--Update 2012. Eur J Cancer. 2012 Oct;48(15):2375–90.  
56.  Dinnes J, Deeks JJ, Chuchu N, Ferrante di Ruffano L, Matin RN, Thomson DR, et al. Dermoscopy, with and without visual inspection, for diagnosing melanoma in adults. Cochrane Database Syst Rev [Internet]. 2018 Dec 4 [cited 2021 Jun 24];(12). Available from: http://doi.wiley.com/10.1002/14651858.CD011902.pub2  
57.  Kyrgidis A, Lallas A, Moscarella E, Longo C, Alfano R, Argenziano G. Does pregnancy influence melanoma  
prognosis? A meta-analysis. Melanoma Res. 2017 Aug;27(4):289–99.  
58.  Still R, Brennecke S. Melanoma in pregnancy. Obstet Med [Internet]. 2017 Mar 20;10(3):107–12. Available from:  
https://doi.org/10.1177/1753495X17695001  
59.  Australian Cancer Network Melanoma Guidelines Revision Working Party. Australian Cancer Network Melanoma  
Guidelines Revision Working Party. Wellington; 2008.  
60.  Broer N, Buonocore S, Goldberg C, Truini C, Faries MB, Narayan D, et al. A proposal for the timing of management  
of patients with melanoma presenting during  pregnancy. J Surg Oncol. 2012 Jul;106(1):36–40.  
61.  Ribero S, Gualano MR, Osella-Abate S, Scaioli G, Bert F, Sanlorenzo M, et al. Association of Histologic Regression  
in Primary Melanoma With Sentinel Lymph Node Status: A Systematic Review and Meta-analysis. JAMA Dermatology. 2015 Dec;151(12):1301–7.  
62.  Requena C, Botella-Estrada R, Traves V, Nagore E, Almenar S, Guillén C. [Problems in defining melanoma  
regression and prognostic implication]. Actas Dermosifiliogr. 2009 Nov;100(9):759–66.  
63.  Kang S, Barnhill RL, Mihm MCJ, Sober AJ. Histologic regression in malignant melanoma: an interobserver  
concordance study. J Cutan Pathol. 1993 Apr;20(2):126–9.  
64.  Ribero S, Moscarella E, Ferrara G, Piana S, Argenziano G, Longo C. Regression in cutaneous melanoma: a  
comprehensive review from diagnosis to  prognosis. J Eur Acad Dermatol Venereol. 2016 Dec;30(12):2030–7.  
65.  Gualano MR, Osella-Abate S, Scaioli G, Marra E, Bert F, Faure E, et al. Prognostic role of histological regression  
in primary cutaneous melanoma: a  systematic review and meta-analysis. Br J Dermatol. 2018 Feb;178(2):357–62.  
66.  Kamposioras K, Pentheroudakis G, Pectasides D, Pavlidis N. Malignant melanoma of unknown primary site. To  
make the long story short. A  systematic review of the literature. Crit Rev Oncol Hematol. 2011 May;78(2):112–26.  
67.  Hanna S, Lo SN, Saw RPM. Surgical excision margins in primary cutaneous melanoma: A systematic review and  
meta-analysis. Eur J Surg Oncol. 2021 Jul;47(7):1558–74.  
68.  Dummer R, Hauschild A, Lindenblatt N, Pentheroudakis G, Keilholz U. Cutaneous melanoma: ESMO Clinical  
Practice Guidelines for diagnosis, treatment and  follow-up. Ann Oncol  Off J Eur Soc Med Oncol. 2015 Sep;26 Suppl 5:v12632.  
69.  Damsky WE, Rosenbaum LE, Bosenberg M. Decoding melanoma metastasis. Cancers (Basel) [Internet]. 2010 Dec  
30;3(1):126–63. Available from: https://pubmed.ncbi.nlm.nih.gov/24212610  
70.  Jonjić N, Rajković Molek K, Seili-Bekafigo I, Grbac Ivanković S, Girotto N, Jurišić D, et al. Predictive Value of  
Intraoperative Sentinel Lymph Node Imprint Cytology Analysis for  Metastasis in Patients with Melanoma. Acta Dermatovenerol Croat. 2017 Jul;25(2):99–106.  
71.  Wright F, Spithoff K, Easson A, Murray C, Toye J, McCready D, et al. Primary excision margins and sentinel lymph  
node biopsy in clinically node-negative  melanoma of the trunk or extremities. Clin Oncol (R Coll Radiol). 2011 Nov;23(9):572– 8.  
72.  Faries MB, Thompson JF, Cochran AJ, Andtbacka RH, Mozzillo N, Zager JS, et al. Completion Dissection or  
Observation for Sentinel-Node Metastasis in Melanoma. N Engl J Med [Internet]. 2017 Jun 7;376(23):2211–22. Available from: https://doi.org/10.1056/NEJMoa1613210  
73.  Leiter U, Stadler R, Mauch C, Hohenberger W, Brockmeyer N, Berking C, et al. Complete lymph node dissection  
versus no dissection in patients with sentinel lymph  node biopsy positive melanoma (DeCOG-SLT): a multicentre, randomised,  
phase 3 trial. Lancet Oncol. 2016 Jun;17(6):757–67.  
74.  Ranieri JM, Wagner JD, Wenck S, Johnson CS, Coleman JJ 3rd. The prognostic importance of sentinel lymph node  
biopsy in thin melanoma. Ann Surg Oncol. 2006 Jul;13(7):927–32.  
75.  Wong SL, Coit DG. Role of surgery in patients with stage IV melanoma. Curr Opin Oncol. 2004 Mar;16(2):155–  
60.  
76.  BRASIL. Ministério da Saúde. Secretaria de Ciência T e IED de G e I de T em S. Quimioterapia adjuvante com  
alfainterferona no tratamento do melanoma cutâneo [Internet]. 2013. Available from: http://conitec.gov.br/images/Incorporados/Alfainterferona-Melanoma-final.pdf  
77.  Seth R, Messersmith H, Kaur V, Kirkwood JM, Kudchadkar R, McQuade JL, et al. Systemic Therapy for Melanoma:  
ASCO Guideline. J Clin Oncol  Off J Am Soc  Clin Oncol. 2020 Nov;38(33):3947–70.  
78.  Mocellin S, Lens MB, Pasquali S, Pilati P, Chiarion Sileni V. Interferon alpha for the adjuvant treatment of cutaneous  
melanoma. Cochrane database Syst Rev. 2013 Jun;(6):CD008955.  
79.  Ives NJ, Suciu S, Eggermont AMM, Kirkwood J, Lorigan P, Markovic SN, et al. Adjuvant interferon-α for the  
treatment of high-risk melanoma: An individual patient  data meta-analysis. Eur J Cancer. 2017 Sep;82:171–83.  
80.  Brasil. Ministério da Saúde. Secretaria de Ciência T e IE. Relatório de recomendação n<sup>o</sup> 391 de outubro de 2018 -  
Ipilimumabe para tratamento de pacientes com melanoma metastático [Internet]. 2018. Available from: http://conitec.gov.br/images/Relatorios/2018/Relatorio_Ipilimumabe_MelanomaMetastatico_FINAL.pdf  
81.  Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE. Relatório de recomendação n<sup>o</sup> 541 de 2020 -  
Terapia-alvo (vemurafenibe, dabrafenibe, cobimetinibe, trametinibe) e imunoterapia (ipilimumabe, nivolumabe, pembrolizumabe) para o tratamento de primeira linha do melanoma avançado não-cirúrgico e metastático [Internet]. 2020. Available from: http://conitec.gov.br/images/Relatorios/2020/Relatorio_541_TerapiaAlvo_Melanoma_Final_2020.pdf  
82.  Pike E, Hamidi V, Saeterdal I, Odgaard-Jensen J, Klemp M. Multiple treatment comparison of seven new drugs for  
patients with advanced  malignant melanoma: a systematic review and health economic decision model in a Norwegian setting. BMJ Open. 2017 Aug;7(8):e014880.  
83.  Pasquali S, Hadjinicolaou A V, Chiarion Sileni V, Rossi CR, Mocellin S. Systemic treatments for metastatic  
cutaneous melanoma. Cochrane database Syst Rev. 2018 Feb;2(2):CD011123.  
84.  Zoratti MJ, Devji T, Levine O, Thabane L, Xie F. Network meta-analysis of therapies for previously untreated  
advanced BRAF-mutated  melanoma. Cancer Treat Rev. 2019 Mar;74:43–8.  
85.  Khan MK, Khan N, Almasan A, Macklis R. Future of radiation therapy for malignant melanoma in an era of newer,  
more  effective biological agents. Onco Targets Ther. 2011;4:137–48.  
86.  Khan N, Khan MK, Almasan A, Singh AD, Macklis R. The evolving role of radiation therapy in the management  
of malignant melanoma. Int J Radiat Oncol Biol Phys. 2011 Jul;80(3):645–54.  
87.  Burmeister BH, Henderson MA, Ainslie J, Fisher R, Di Iulio J, Smithers BM, et al. Adjuvant radiotherapy versus  
observation alone for patients at risk of lymph-node  field relapse after therapeutic lymphadenectomy for melanoma: a randomised trial. Lancet Oncol. 2012 Jun;13(6):589–97.  
88.  National Cancer Institute. Common terminology criteria for adverse events v4.0 [Internet]. 2010. Available from:  
https://ctep.cancer.gov/protocoldevelopment/electronic_applications/ctc.htm#ctc_60  
89.  Aché Laboratórios Farmacêuticos S.A. Bula profissional alfainterferona 2b recombinante [Internet]. 2021. Available  
from: https://consultas.anvisa.gov.br/#/medicamentos/25351689303201846/?substancia=23091&situacaoRegistro=V  
90.  Bristol-Myers Squibb Farmacêutica LTDA. Bula OPDIVO (nivolumabe) Solução injetável 10mg/ml [Internet].  
2021. Available from:  
https://consultas.anvisa.gov.br/#/medicamentos/25351308360201510/?substancia=25853&situacaoRegistro=V  
91.  MSD. Bula KEYTRUDA pembrolizumabe solução injetável 100mg/4mL [Internet]. 2021. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351643945201574/?substancia=25930&situacaoRegistro=V

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: _ADVERSE EVENTS._ -->
|Grau 1|Leve: assintomático ou com sintomas leves; somente observação clínica ou diagnóstica; intervenção não é<br>indicada.|
|---|---|
|Grau 2|Moderado: indica-se intervenção não invasiva, local ou mínima; as atividades diárias básicas instrumentais (p.<br>ex., preparar refeições, fazer compras, usar o telefone, etc.) apropriadas à idade estão limitadas.|
|Grau 3|Grave: medicamente significante, mas não ameaça a vida imediatamente; indica-se ou prolonga-se a|
||hospitalização; incapacitante; atividades diárias básicas de autocuidado limitadas (p. ex., tomar banho, trocar<br>de roupa, alimentar-se, usar o banheiro, tomar medicamentos; e não estar confinado à cama).|
|Grau 4|Consequências ameaçam a vida: indica-se intervenção urgente.|
|Grau 5|Morte relacionada a eventos adversos.|  
Traduzido livremente e _adaptada de_ CTCAE Versão 5<sup>88</sup> .

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **1. ESCOPO E FINALIDADE DAS DIRETRIZES** -->
A revisão das Diretrizes Diagnósticas e Terapêuticas (DDT) do Melanoma Cutâneo teve como base as DDT publicadas por meio da Portaria SAS/MS nº 357, de 08 de abril de 2013 e a estrutura de PCDT definida pela Portaria SAS/MS n° 375, de 10 de novembro de 2009.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas, por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
Os consultores especialistas apontaram para a necessidade de atualização do texto das DDT com os novos estudos dos medicamentos biológicos indicados para o tratamento do melanoma cutâneo, bem como a revisão dos dados de incidência da doença.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **2.1. Colaboração externa** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), outros técnicos participaram do desenvolvimento deste Protocolo, sendo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema. Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **2.2. Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização destas Diretrizes do Melanoma Cutâneo foi apresentada à 94ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em outubro de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE), Secretaria de Atenção Especializada à Saúde (SAES) e Secretaria Especial de Saúde Indígena (SESAI). Os membros presentes recomendaram que estas DDT fossem encaminhadas para o Grupo Elaborador, para que procedessem às adequações necessárias conforme sugerido e que retornassem para posterior apreciação nesta Subcomissão; e, caso aprovadas, fossem submetidas à apreciação da Conitec.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **2.3. Consulta pública** -->
A Consulta Pública nº 33/2022, para a atualização das Diretrizes Diagnósticas e Terapêuticas do Melanoma Cutâneo, foi realizada entre os dias 20/05/2021 e 08/06/2021. Foram recebidas 89 contribuições, que podem ser verificadas em: <http://conitec.gov.br/images/Consultas/Contribuicoes/2022/20220609_CP_CONITEC_033_2022_DDT_do_Melanoma.pdf>.

---

<!-- METADADOS: doenca: Melanoma Cutâneo | secao: **3. BUSCA DA EVIDÊNCIA E RECOMENDAÇÕES** -->
A primeira atualização do texto das DDT foi realizada em 2017 e foi definida a necessidade de avaliação da incorporação  
dos medicamentos (terapias-alvo e imunoterapia) para o tratamento de melanoma avançado (irressecável ou mestastático).  
Após a recomendação final da Conitec favorável à incorporação dos medicamentos nivolumabe ou pembrolizumabe para a doença metastática, foi realizada nova busca sistematizada na base de dados PubMed e no Google scholar, no mês de junho de 2021, para avaliar as evidências de revisões sistemáticas e diretrizes clínicas de outros países. A literatura foi recuperada, triada,  
selecionada e lida em sua integridade por somente um revisor. A qualidade dos estudos e o nível de evidência não foram  
avaliados, uma vez que não foi formulada nenhuma pergunta PICO para essa etapa do processo.  
De acordo com os resultados encontrados, a minuta das DDT foi atualizada, a fim de incluir dados epidemiológicos e novos estudos, principalmente relacionados ao tratamento adjuvante.

---

