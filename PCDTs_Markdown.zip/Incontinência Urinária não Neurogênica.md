<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: Geral -->
<!-- Start of picture text -->
2<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 1, DE 09 DE JANEIRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Incontinência Urinária não Neurogênica.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a incontinência urinária não neurogênica no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta condição;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 486/2019 e o Relatório de Recomendação n<sup><u>o</u></sup> 495 – Novembro de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Insuficiência Urinária não Neurogência.  
1  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da insuficiência urinária não neurogência, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da insuficiência urinária não neurogência.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa condição em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º .  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: DENIZAR VIANNA -->
2  
ANEXO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS INCONTINÊNCIA URINÁRIA NÃO NEUROGÊNICA

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **1. INTRODUÇÃO** -->
O termo incontinência urinária (IU) refere-se à queixa de qualquer perda de urina, que pode ser involuntária, provocada pelo indivíduo ou descrita por um cuidador (1-3). Essa perda involuntária pode estar associada com a urgência e também com esforço ou esforço físico, incluindo atividades esportivas, ou em espirros ou tosse. A IU é uma condição que afeta a qualidade de vida, comprometendo o bem-estar físico, emocional, psicológico e social das pessoas. A IU pode acometer indivíduos de todas as idades, de ambos os sexos e de todos os níveis sociais e econômicos. Um estudo na população dos EUA estimou que 12 milhões de pessoas sofrem de IU. Estima-se que 200 milhões de pessoas vivam com incontinência ao redor do mundo e que entre 15% e 30% das pessoas acima de 60 anos que vivem em ambiente domiciliar apresentam algum grau de incontinência (4, 5). Entretanto, o número exato de pessoas acometidas pode ser muito maior do que as estimativas atuais, visto que muitas delas não procuram ajuda por vergonha, acreditando que o problema seria uma consequência normal do envelhecimento ou, ainda, que não existe tratamento. Estudo brasileiro conduzido em população idosa relatou uma prevalência de IU de 11,8% entre os homens e de 26,2% entre as mulheres (6).  
As mulheres têm maior predisposição de apresentar essa condição (7). As mulheres apresentam uma menor capacidade de oclusão uretral e isso se deve ao fato de a uretra funcional feminina ser mais curta e a continência depender não somente do funcionamento esfincteriano adequado, mas também de elementos de sustentação uretral (músculos e ligamentos) e transmissão da pressão abdominal para o colo vesical (8) .  
Inúmeras situações podem levar a IU. A identificação da sua causa é essencial para o tratamento adequado. De maneira geral, a presença de IU pode ser dividida de acordo com a etiologia em neurogênica (p.ex., por lesão medular traumática, esclerose múltipla, acidente vascular cerebral) e não neurogênica (p. ex. hiperatividade detrusora,  
3  
insuficiência intrínseca do esfíncter uretral, cirurgias da próstata). Este Protocolo trata de causas não neurogênicas, especificamente a IU aos esforços e a IU por urgência no adulto  
A IU pode ser classificada de acordo com o tipo de incontinência em IU aos esforços, IU de urgência e IU mista. A Incontinência Urinária aos Esforços (IUE) ocorre devido a uma deficiência no suporte vesical e uretral que é feito pelos músculos do assoalho pélvico ou por uma fraqueza ou lesão do esfíncter uretral. Essa condição leva a perda de urina em situações de aumento da pressão intra-abdominal, tais como, tossir, espirrar, correr, rir, pegar peso, levantar da posição sentada ou até mesmo andar. Em geral, não ocorrem perdas em repouso e durante o sono. Essa situação é bastante frequente em mulheres. Em homens sem alterações neurológicas relevantes, esse tipo de incontinência ocorre após prostatectomia, em que o mecanismo esfincteriano proximal é removido. Nesses casos, a continência fica dependente do esfíncter uretral estriado e uma lesão parcial ou total deste componente esfincteriano pode levar a IU.  
A Incontinência Urinária de Urgência (IUU) ocorre como consequência da hiperatividade detrusora (HD), que ocorre quando o músculo detrusor apresenta contração involuntária. Para a preservação da continência urinária, é fundamental que a bexiga apresente função normal e a pressão intravesical deve permanecer relativamente baixa e constante durante todo o seu enchimento. Em pessoas com a sensibilidade vesical preservada, a HD leva a um desejo súbito e imperioso de urinar. Quando a contração vesical supera a capacidade de oclusão uretral gerada pelo esfíncter, ocorre a IUU. Várias situações podem levar a hiperatividade detrusora, desde uma infecção urinária que irrita a mucosa vesical até uma alteração, identificável ou não, da inervação vesical. Os sintomas mais comuns associados a IUU são urgência miccional, polaciúria e noctúria (necessidade de acordar a noite devido a desejo miccional). A incontinência Urinária Mista (IUM) é a combinação da IUE e IUU, ou seja, uma insuficiência de oclusão uretral associada à hiperatividade detrusora.  
A identificação de fatores de risco e da condição em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos não cirúrgicos das causas não neurogênicas de insuficiência urinária (IU), especificamente da  
4  
IU aos esforços e da IU por urgência no adulto, considerando as diferentes condutas terapêuticas para homens e mulheres. A descrição da metodologia científica, elaboração das estratégias de busca, descrição do fluxo de seleção das evidências e as tabulações dos dados das características dos participantes, características dos estudos e desfechos de eficácia e segurança estão detalhados no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- R32 - Incontinência urinária não especificada  
- N39.3 Incontinência de tensão (“stress”)  
N39.4 Outras incontinências urinárias especificadas

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **3. CRITÉRIOS DE INCLUSÃO** -->
- Adultos (> 18 anos), de ambos os sexos; e  
- Diagnóstico de Incontinência Urinária de Esforço (IUE), de Incontinência Urinária de Urgência (IUU) ou de Incontinência Urinária mista (IUM).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **4. CRITÉRIOS DE EXCLUSÃO** -->
- População pediátrica (< 18 anos) ou  
- Incontinência urinária de causa neurogênica.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5. DIAGNÓSTICO** -->
Uma história completa deve fornecer elementos que permitam indicar qual o tipo mais provável de IU e a conduta diagnóstica e terapêutica mais apropriada.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.1. História Clínica** -->
Os elementos a serem observados no diagnóstico de IUE na mulher incluem:  
- Frequência de episódios de perda e hábitos miccionais;  
- grau de incômodo;  
- condição de perda (esforço ou urgência);  
- necessidade de utilizar proteção (absorventes, fraldas);  
5  
- horário em que ocorrem as perdas;  
- associação com medicamentos;  
- ingestão hídrica;  
- cirurgias pélvicas;  
- número e tipo de partos; e  
- complicações ginecológicas.  
Nas mulheres, a constipação intestinal distende a parte distal do sigmoide e do reto podendo prejudicar a transmissão parassimpática sacral, resultando em atividade detrusora inadequada, principalmente em idosos (5). Além disso, a presença de uma ou mais infecções do trato urinário é fator preditor independente para o desenvolvimento de hiperatividade detrusora (9).  
Em homens sem doença neurológica, a IU está, na maioria das vezes, associada com história de cirurgia prostática. Esta intercorrência pode ser causada por incompetência esfincteriana, disfunção vesical ou transbordamento urinário devido a retenção. Aproximadamente 1% dos pacientes submetidos à ressecção transuretral da próstata evoluem com quadro significativo de IU no pós-operatório (10), enquanto que nos pacientes submetidos à prostatectomia radical, esta complicação pode ocorrer entre 2% a 80% dos casos (11, 12), dependendo da definição de incontinência utilizada. Como é esperado que em pacientes com hiperplasia benigna da próstata o tratamento cirúrgico alivie os sintomas urinários, qualquer grau de IU pós-operatória é pouco tolerado. Nos pacientes submetidos à cirurgia radical, a IU pós-operatória é comum, porém os sintomas são transitórios e persistem apenas por algumas semanas, na maioria dos casos. A IU pode requerer tratamento cirúrgico quando se mantém por tempo mais prolongado.  
Alguns pacientes submetidos à prostatectomia podem apresentar, nas primeiras semanas após a retirada da sonda vesical, urgência, IUU e polaciúria. Nesta fase, é importante excluir duas condições que podem causar essas manifestações, que são infecção urinária e retenção de urina por obstrução.  
A quantificação e o tipo de perda urinária devem ser determinados durante a anamnese, como descrito na avaliação das mulheres. O levantamento da história deve focar no trato urinário, história prévia de cirurgia ou de radioterapia, comorbidades e sintomas de doenças que podem causar disfunção vesical e história familiar de doenças da próstata (hiperplasia prostática benigna e câncer) (4)  
6  
Nos pacientes que foram submetidos à prostatectomia radical, deve-se obter informação a respeito do tipo de cirurgia (retropúbica, perineal, laparoscópica ou robótica), além do _status_ do câncer. Nos casos de radioterapia, deve-se investigar o tipo ao qual o paciente foi submetido – externa ou interna (braquiterapia) (1).  
Informações valiosas podem ser obtidas a partir de uma história cuidadosa em relação à incontinência, especialmente quando relacionada à disfunção do esfíncter. Sintoma de incontinência urinária aos esforços associado à história de cirurgia prostática é altamente preditivo da presença de disfunção esfincteriana. Ficazzola e Nitti (13) demonstraram que sintomas de IUE apresentam 95% de valor preditivo positivo e 100% de valor preditivo negativo. No entanto, a IUU como preditor de disfunção vesical não parece ser tão valiosa, e sua presença não pode ser determinada com precisão sem o estudo urodinâmico (13).  
O diabete melito mal controlado e o diabete insípido podem levar a um aumento do débito urinário, superando os mecanismos normais de continência (14).  
Uma avaliação crítica dos medicamentos de uso contínuo é recomendada para excluir os efeitos de qualquer agente farmacológico na função do trato urinário inferior. Por exemplo, os inibidores da enzima conversora de angiotensina causam tosse crônica, enquanto os bloqueadores alfa-adrenérgicos causam diminuição da resistência à uretra, ambos podendo exacerbar a IUE. Os agonistas alfa-adrenérgicos causam aumento da resistência uretral, resultando em exacerbação da retenção urinária. Os anticolinérgicos causam relaxamento do detrusor, o que pode causar retenção urinária e IU por transbordamento. Os diuréticos não têm efeito direto sobre a função do detrusor, mas podem causar um aumento do volume urinário, levando a frequência e urgência. Os bloqueadores dos canais de cálcio e psicotrópicos relaxam os músculos lisos, prejudicando a fase de esvaziamento, podendo contribuir para a retenção urinária. Sedativos não têm repercussão direta na bexiga, mas podem contribuir para sedação e delírio (1).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.2. Exame Físico** -->
O exame físico nas mulheres deve ser direcionado para os sistemas que poderiam estar relacionados com a IU, incluindo o exame geral da mobilidade, estado cognitivo, edema periférico, exame abdominal para detecção de massas pélvicas e avaliação neurológica para doenças como esclerose múltipla, doença de Parkinson, compressão de  
7  
raiz nervosa (hérnia de disco), parestesias e distrofismo muscular. Deve-se determinar o índice de massa corporal (IMC) da paciente. Atenção deve ser dada para a presença de prolapso de órgãos pélvicos e atrofia vaginal. A força e tônus da musculatura pélvica (elevador dos ânus) e a sensibilidade perineal também devem ser avaliados. A paciente deve ser instruída a realizar manobras de esforço em posição supina e ortostática para observação da perda e sua intensidade.  
Nos homens o exame físico, pode-se descobrir a presença de distensão vesical, que está associada à incontinência por transbordamento. Deve-se verificar o tônus do esfíncter anal, assim como o reflexo bulbocavernoso, com a finalidade de se diagnosticar uma provável causa neurológica da incontinência.  
Como teste diagnóstico simples, pede-se para que o paciente fique na posição ereta e com a bexiga cheia; se observada perda urinária, a maior probabilidade é que o paciente apresente incompetência esfincteriana. Caso ocorra perda aparente, o paciente é solicitado a tossir, e, se a perda urinária ocorrer somente durante o período de aumento na pressão intra-abdominal, é bastante provável tratar-se de incompetência esfincteriana.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.3. Diário miccional** -->
A utilização de um diário miccional, que avalia a rotina urinária e de perdas, é um método bastante simples e muito útil na avaliação inicial (15). O diário miccional permite avaliar o número de micções, número de episódios de IU e o volume de líquido ingerido e eliminado em 24 horas. A medida do volume urinado por micção pode ser usada para ajudar no diagnóstico, como por exemplo de bexiga hiperativa ou poliúria. O diário também pode ser usado para monitorar a resposta e eficácia do tratamento, além de ser amplamente utilizado em estudos clínicos e exercer um papel terapêutico, pois fornece ao paciente uma visão do comportamento da bexiga. Atenção especial deve ser dada em pacientes com IU grave, pois os dados obtidos em relação ao volume total em 24 horas podem ser inferiores do que a capacidade vesical. O período de aplicação do diário miccional é incerto na literatura, podendo variar de 2-3 dias até 3-7 dias.  
Embora represente uma ferramenta útil no arsenal diagnóstico para determinados pacientes, existem algumas limitações. Não há evidências de que os resultados obtidos pelo diário miccional se correlacionem com o tipo de IU. Outro fator limitante é a dificuldade de alguns pacientes em entender e completar o diário de forma confiável,  
8  
especialmente quando o tempo (dias) é prolongado. Além disso, o diário pode não ser útil para obter informações sobre sintomas que ocorrem de maneira menos frequente (1).  
Um aspecto relevante na avaliação da incidência de IU masculina é o tipo e a gravidade dos sintomas, assim como os eventos precipitantes. A gravidade pode ser determinada pelo número de episódios de perdas ao dia, a necessidade de proteção (por exemplo, uso de fraldas ou absorventes, _clamp_ peniano ou coletores externos) e o impacto da incontinência nas atividades da vida diária. Nesse sentido, o diário miccional pode ser útil especialmente naqueles casos em que existe dúvida sobre a gravidade do quadro e possibilidade de perda urinária por urgência associada (IU mista).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.4. Exames complementares** -->
Infecção urinária pode levar ao surgimento de IU. Um exame de análise de caracteres físicos, elementos e sedimentos na urina deve ser solicitado para descartar a possibilidade de infecção, bem como de outras alterações observáveis nesse exame.  
A ultrassonografia do trato urinário e da pélvis nas mulheres permite avaliar a presença de massa(s) na cavidade pélvica, além de fornecer informações sobre resíduo pós-miccional (RPM) e lesões do trato urinário. A presença de resíduo pós-miccional < 50 ml é considerada normal.  
Outros exames, como cistoscopia e uretrocistografia miccional, podem ser úteis, dependendo da apresentação inicial do quadro clínico. Após a avaliação, o médico deve ser capaz de determinar se a paciente apresenta IUE, IUU ou associação de ambas (IUM). O tratamento deve ser realizado considerando o tipo da IU, com o risco de insucesso ou a piora do quadro em casos de diagnóstico equivocado.  
Nos homens o câncer de bexiga, carcinoma _in situ_ de bexiga, infecções do trato urinário, estenose de uretra e cálculo vesical podem causar sintomas semelhantes à bexiga hiperativa e devem ser excluídos antes de se definir o tratamento de pacientes com suposta IUE. Por este motivo, a maioria das diretrizes sobre pacientes com sintomas do trato urinário inferior e IU orientam o uso do exame de urina como ferramenta útil na Atenção Primária (1).  
9  
Além disso, a análise e cultura da urina são necessárias antes do tratamento cirúrgico da incontinência urinária masculina. A infecção do trato urinário deve ser devidamente diagnosticada e adequadamente tratada.  
A avaliação da função renal ser feita com a dosagem da creatinina sérica. A dosagem do antígeno prostático específico (PSA) também é necessária no estabelecimento do _status_ do câncer.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.5. Urodinâmica** -->
A avaliação urodinâmica completa ou estudo urodinâmico (EUD) é um exame realizado para avaliar o funcionamento do trato urinário inferior. Em geral, o EUD é realizado quando há falha no tratamento clínico ou quando se planeja alguma forma de tratamento cirúrgico. Esse exame é essencial para definir e predizer a resposta ao tratamento, podendo ser decisivo quanto à indicação ou não de um tratamento cirúrgico. O exame geralmente não gera dor, apenas um pequeno desconforto pela passagem do cateter uretral.  
O estudo urodinâmico é amplamente utilizado como complemento ao diagnóstico clínico nas mulheres, pois pode ajudar a fornecer ou confirmar o diagnóstico, prever o resultado do tratamento e facilitar a orientação ao paciente e para direcionar o tratamento. Por todas estas razões, é um exame frequentemente utilizado, especialmente antes de tratamentos invasivos (16). A realização do estudo urodinâmico rotineiramente antes do tratamento cirúrgico ainda é debatido, pois há inconsistência nos dados de literatura (17).  
O estudo urodinâmico nos homens pode ser útil na avaliação dos casos de IU pósprostatectomia, por definir exatamente a causa da perda urinária, além de ajudar na quantificação objetiva da incontinência. A medida do fluxo urinário livre e do resíduo urinário pós-miccional é realizada no início do exame. O fluxo diminuído, associado ou não à presença de resíduo urinário, pode ser secundário à obstrução ou à diminuição da força de contração do detrusor. A análise da capacidade, da sensibilidade, da complacência e da presença de hiperatividade detrusora é feita por meio da cistometria. O estudo pressão-fluxo é realizado no final da cistometria e pode ajudar a diferenciar obstrução de anormalidades na contração vesical. Testes de esforço são realizados durante o enchimento vesical para avaliar a competência esfincteriana. Quando não for detectada  
10  
a perda urinária aos esforços, estes devem ser repetidos após a remoção do cateter (1). A redução do fluxo urinário na presença da pressão vesical elevada confirma o diagnóstico de obstrução, enquanto que, na presença de baixa pressão, indica atividade ineficaz do detrusor.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.1.6. Exames por Imagem (uretrocistografia retrógrada e miccional)** -->
Nos homens, a detecção de estenose da anastomose vesicouretral ou estenose de uretra deve ser investigada quando se planeja um tratamento cirúrgico da IU em pacientes com baixo fluxo urinário ou sinais de obstrução no estudo urodinâmico (18). Quando não reconhecida, pode complicar significativamente as condutas cirúrgicas da IU pósprostatectomia radical. Essa investigação pode ser feita por meio de uretrocistoscopia ou uretrocistografia retrógrada e miccional.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2. Diagnóstico da Incontinência Urinária de Urgência (IUU)** -->
O diagnóstico da bexiga hiperativa (BH) baseia-se na queixa clínica, exame físico (incluindo exame ginecológico) e exames laboratoriais de rotina. Tal avaliação em portadores de BH visa a excluir outras condições locais que cursam com os mesmos sintomas.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.1 História** -->
Tipicamente, pacientes portadores de BH apresentam as seguintes queixas:  
- Urgência (imperiosidade para urinar ou sensação iminente de perda de urina);  
- frequência (número de micções diárias superior a oito);  
- noctúria (necessidade de acordar a noite devido a desejo miccional) com ou sem incontinência de urgência associada (paciente sente vontade de urinar e não consegue chegar à toalete sem apresentar perda urinária).  
11  
Estes sintomas podem aparecer associados ou de forma isolada. Por definição, a presença de condições fisiopatológicas locais, que levem aos mesmos sintomas, exclui o diagnóstico de BH. Entre estas condições destacam-se:  
- Neoplasia vesical, especialmente carcinoma _in situ_ de bexiga;  
- infecção do trato urinário inferior;  
- medicamentos com efeitos colaterais sobre o trato urinário inferior, como alguns tipos de antidepressivos;  
- litíase vesical;  
- obstrução infravesical (geralmente decorrente de tratamento cirúrgico de IUE); e  
- fatores emocionais.  
Todas estas condições podem ser excluídas por meio de medidas simples, como uma boa anamnese, exame físico detalhado e exames laboratoriais de fácil realização.  
Desta forma, na anamnese, além dos sintomas de BH a presença de sintomas associados, a presença de disúria e dor no baixo ventre durante a micção, acompanhada ou não febre, apontam para uma provável infecção do trato urinário.  
A presença de hematúria macroscópica torna obrigatória a exclusão de neoplasia vesical. Antecedentes de cirurgia para correção de IUE, especialmente em pacientes sem sintomas de BH no pré-operatório, tornam necessária a exclusão de obstrução infravesical. Alterações de marcha, da fala ou de sensibilidade sugerem a coexistência de doença neurológica como causadora dos sintomas de BH. Além disto, é necessário caracterizar e quantificar a presença de noctúria pelo número de vezes que o paciente necessita acordar para ir ao banheiro durante à noite (19). É importante, principalmente em mulheres, que se diferencie a urge-incontinência da incontinência de esforço. Também deve fazer parte da história a quantificação do grau de comprometimento da qualidade de vida do paciente decorrente de seus sintomas miccionais e não apenas em pacientes que apresentem incontinência urinária (20).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.2. Exame físico** -->
12  
Apesar dos indivíduos com bexiga hiperativa não apresentarem, necessariamente, alterações oa exame físico, a sua realização é fundamental no sentido de afastar outras doenças que podem levar a sintomas semelhantes aos de bexiga hiperativa (21, 22).  
Deve-se atentar ao exame da região pélvica nas mulheres. A presença de globo vesical palpável aponta para uma possível incontinência paradoxal (por transbordamento). A detecção de massa(s) palpável(eis) em região pélvica sugere a presença de neoplasia que pode comprometer os nervos responsáveis pelo funcionamento da bexiga (23).  
A realização de um exame neurológico sumário, no qual se avalia alteração de marcha, da sensibilidade perineal e do tônus do esfíncter anal também é fundamental. A normalidade destes parâmetros reflete uma integridade do centro medular sacral responsável pelo arco reflexo da micção e torna pouco provável a presença de doença neurológica com repercussão sobre o trato urinário inferior (24-26).  
Adicionalmente, nas mulheres, a realização de exame ginecológico é mandatória, devendo-se verificar a presença de atrofia urogenital, prolapso genital e vulvo-vaginite atrófica. Durante o exame físico, a realização de teste de esforço, com a paciente em pé, permite, em muitos casos, o diagnóstico de perdas urinárias aos esforços que pode estar associada aos sintomas de BH (27, 28).  
Em homens acima de 50 anos, a presença de aumento prostático, avaliado durante o toque retal, pode sugerir a presença de obstrução infravesical e, portanto, uma hiperatividade secundária. O exame de toque retal também permite avaliar as condições do assoalho pélvico (29, 30).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.3. Diário miccional** -->
Deve ser solicitado ao paciente seu preenchimento, pois permite diferenciar diversas condições que podem simular bexiga hiperativa. Indivíduos com bexiga hiperativa geralmente urinam pequenos volumes em intervalos de tempo reduzidos durante o dia e à noite. Pacientes idosos, em especial, podem apresentar sintomas do trato urinário inferior, inclusive incontinência urinária, decorrentes de sobrecarga do trato urinário inferior causada por excesso de ingesta hídrica ou mesmo da presença de doença metabólica mal controlada, como a diabete (31).  
13

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.4. Exames Laboratoriais** -->
A análise do sedimento urinário e cultura e antibiograma de urina devem ser solicitados em todos os pacientes com quadro clínico de BH. A presença de infecção bacteriana pode desencadear sintomas semelhantes aos observados em indivíduos com BH, e o tratamento buscará a resolução do quadro infeccioso (32).  
Da mesma forma, a presença de hematúria na ausência de infecção sugere a possibilidade de doença neoplásica ou litíase renal que deverão ser adequadamente investigadas. Dosagens séricas de creatinina e glicose são sempre recomendadas. Pacientes em fases iniciais de insuficiência renal podem ter sintomas de BH. Pacientes diabéticos com glicemia elevada apresentam diurese osmótica, resultando em volumes urinários elevados com consequente sobrecarga do trato urinário inferior e sintomas de BH (32).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.5. Urodinâmica** -->
A urodinâmica é o exame para avaliação funcional do trato urinário inferior. Deve ser solicitado quando o paciente apresentar sintomas e sinais que não possam ser explicados apenas por hiperatividade primária (p. ex., infecções do trato urinário) (33, 34).  
De forma geral, recomenda-se a realização desse exame nas seguintes condições  
(23):  
- Falha do tratamento inicial;  
- presença de resíduo pós-miccional significativo;  
- cirurgia prévia do trato urinário inferior;  
- suspeita de que os sintomas de BH decorram de doenças associadas mais graves, como doença neurológica com acometimento das estruturas neurais responsáveis pela inervação do trato urinário inferior; ou  
- quando os sintomas parecem decorrer de quadro doloroso sugerindo afecção irritativa (cistite intersticial)  
14  
Basicamente, a cistometria de indivíduos com BH pode ser normal nos casos de urgência sensorial ou apresentar contrações detrusoras durante o enchimento (urgência motora). A presença de dor progressiva durante o enchimento vesical sugere o diagnóstico de cistite intersticial(35).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5.2.6. Exame de Imagem** -->
A ultrassonografia pélvica permite identificar a presença de lesão(ões) tumoral(ais), cálculos urinários e sintomas indiretos de obstrução do trato urinário, tais como dilatações pielo-ureterais, etc. A ultrassonografia também permite avaliar o volume prostático bem como o resíduo pós-miccional. Deve ser solicitada quando permanecer qualquer dúvida quanto ao diagnóstico do paciente (36-38).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.1.1. Tratamento Conservador da IUE e Medidas Gerais** -->
No tratamento da IUE, sempre é recomendada a conduta conservadora antes do tratamento invasivo. Nas mulheres o tratamento conservador incluem mudanças no estilo de vida e a adoção de técnicas de reabilitação.O tratamento conservador por meio de orientação, exercícios pélvicos e _biofeedback_ deve ser a primeira escolha nos primeiros 12 meses, por antecipar  a recuperação espontânea da continência (39).  
Os fatores de estilo de vida que podem estar associados à IUE incluem obesidade, dieta, nível de atividade física e ingestão de líquidos. A adequação desses fatores pode melhorar a IUE. A escolha da terapia inicial deve levar em consideração a preferência da paciente e o contexto clínico geral avaliado de acordo com o item 5. Diagnóstico.  
Nas mulheres, o excesso de peso foi identificado como um fator de risco para a IU em muitos estudos epidemiológicos (40, 41). Há evidências de que a prevalência de IUE aumenta proporcionalmente ao aumento do índice de massa corpórea (IMC) (42). Nos casos de obesidade e sobrepeso, a perda de 5% do peso corporal inicial tem impacto na redução dos sintomas da IU. Revisão sistemática concluiu que a perda de peso foi benéfica na melhoria da IU (40, 43, 44).  
15  
Nas mulheres, a atividade física regular pode fortalecer a musculatura do assoalho pélvico e possivelmente diminuir o risco de desenvolvimento de IU, especialmente IUE. No entanto, é possível que o exercício físico pesado possa agravar o quadro. Estudos em diferentes populações concluíram que o exercício físico extenuante aumenta o risco de IUE durante os períodos de atividade física (45-47). Por outro lado, a presença de IU pode impedir que as mulheres façam exercícios (48). Existem evidências de qualidade baixa de que a prática de exercício de intensidade moderada diminui a IUE em mulheres de meia-idade e que isso pode estar relacionado ao controle de peso (1). Dessa maneira, a recomendação de exercício físico para indivíduos com IUE é condicionada à gravidade do quadro, à presença de comorbidades e à supervisão por profissional da saúde.  
A modificação da ingestão de líquidos, em particular a restrição, é uma conduta comumente usada por pessoas com IU para aliviar os seus sintomas. O aconselhamento pelos profissionais da saúde sobre a ingestão de líquidos deve basear-se numa ingestão de líquidos em 24 horas que seja suficiente para evitar a desidratação(49).  
Nos homens, o tratamento conservador por meio de orientação, exercícios pélvicos e _biofeedback_ deve ser a primeira escolha nos primeiros 12 meses, por antecipar  a recuperação espontânea da continência (39). Os fatores de estilo de vida que podem estar associados à IUE incluem dieta, micção de horário e adequação da ingestão de líquidos. A adequação desses fatores pode melhorar a IUE.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.1.2. Reabilitação -** **_Treinamento dos Músculos do Assoalho Pélvico (TMAP)_** -->
O treinamento dos músculos do assoalho pélvico (TMAP) se constitui de um programa no qual as pacientes são orientadas a contrair os músculos do assoalho pélvico (MAP) por um tempo progressivo, repetidas vezes ao longo do dia. O TMAP é recomendado como primeira linha de tratamento, considerando a preferência da paciente, para melhorar a função do assoalho pélvico e a estabilidade da uretra. Em situações de não adesão, recusa da paciente ou falha do TMAP, outras formas de tratamento serão indicadas, conforme descrito neste Protocolo. O TMAP pode ser associado ao _biofeedback_ (por meio de estímulos visuais, táteis ou auditivos), estimulação elétrica de superfície ou cones vaginais (49-52).  
16  
O TMAP não apresenta contraindicações no tratamento das mulheres e não está associado a efeitos colaterais. Fundamenta-se no incremento da força de contração dos músculos do assoalho pélvico e de suporte dos órgãos pélvicos. Contudo, a manutenção dos resultados depende da continuidade dos exercícios (49). O tratamento da IU com TMAP no período do pós-parto precoce aumenta as chances de continência por até 12 meses (53, 54).  
A IUE masculina após a prostatectomia apresenta característica de resolução espontânea na maioria dos casos, no prazo de 6 a 12 meses (55). A realização de técnicas de reabilitação, nos primeiros meses do pós-operatório, pode acelerar o tempo de recuperação da continência. Nesse período, o TMAP pode ser recomendado considerando a preferência do paciente. O TMAP não oferece benefício para tratamento da IU aos 12 meses após a prostatectomia,(56). Há evidências contraditórias sobre se o treinamento vesical, estimulação elétrica ou _biofeedback_ aumentam a eficácia da TMAP isolado nos homens (49).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **_6.1.3 Biofeedback_** -->
O Biofeedback é considerado um tratamento adjunto para o TMAP, pois permite que os pacientes observem a contração dos MAP enquanto realizam os exercícios. Atua como adjuvante ao TMAP, motiva os pacientes a conseguir uma contração muscular mais forte e, assim, estimula a adesão ao treinamento intensivo. As medidas da atividade dos MAP podem ser avaliadas por perineômetro ou eletromiografia (57, 58).  
Os esquemas de tratamento supervisionados de maior intensidade e a adição de _biofeedback_ conferem maior benefício. Apoia-se o princípio geral de que uma maior eficácia é alcançada por meio da associação de diferentes tipos de tratamento e aumento progressivo da intensidade. A adição do Biofeedback ao TMAP pode promover melhor coordenação e controle dos MAP quando comparado ao TMAP sem o Biofeedback (49, 51, 59).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.2.1 Tratamento Conservador da IUU e Medidas Gerais** -->
17  
A mudança de estilo de vida é a opção de primeira linha para todos os pacientes com IUU.  Consiste em mudanças de hábitos para aliviar os sintomas vesicais e reeducação vesical para treinar habilidades para controlar a IUU. São medidas de fácil aplicação, baixo custo, porém dependem da compreensão, motivação e adesão do paciente, bem como de incentivo pelo profissional da saúde (60-63).  
As orientações compreendem o diário miccional, orientações para dieta e ingesta hídrica, estratégias para o controle do desejo miccional, treinamento dos músculos do assoalho pélvico (com ou sem _biofeedback_ ) e estimulação elétrica.  
O Treinamento vesical é a terapia de primeira linha para adultos com IUU. Consiste em um programa de educação do paciente com um esquema de micção programada com ajuste gradual dos intervalos. Os objetivos específicos são corrigir os hábitos defeituosos de micção frequente, melhorar o controle sobre a urgência, prolongar os intervalos de micção, aumentar a capacidade da bexiga, reduzir episódios de incontinência e restaurar confiança do paciente (49).  
Mudanças de hábitos incluem a redução da ingestão de fluídos, cafeína, alimentos ácidos e álcool, além da orientação como perda de peso, cessação do tabagismo e tratamento da constipação (64).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.2.2 Reabilitação- Treinamento dos músculos do assoalho pélvico (TMAP), Biofeeback ou estimulação do nervo tibial.** -->
O TMAP pode ser usado para o controle da IUU, uma vez que a contração do detrusor pode ser inibida por uma contração voluntária dos músculos do assoalho pélvico (MAP). O paciente é instruído a não se apressar para ir ao banheiro e fazer a contração dos  MAP repetidamente até o controle da sensação de urgência e evitar a IU (65, 66).  
Observa-se redução nos episódios de incontinência em mulheres com IUU que realizaram TMAP com _biofeedback_ em comparação com TMAP com palpação digital, sem _biofeedback_ . A qualidade de vida foi significativamente maior após TMAP com _biofeedback_ (67).  
A estimulação percutânea do nervo tibial é uma forma de neuromodulação que proporciona a estimulação retrógrada ao plexo do nervo sacral por meio de um eletrodo  
18  
inserido no tornozelo, cefálico ao maléolo medial, uma área anatômica reconhecida como o centro da bexiga. A estimulação transcutânea do nervo tibial é menos invasiva do que estimulação percutânea e pode ser posicionada na região do tornozelo com o uso de eletrodos de superfície (68).  
A Eletroestimulação, sempre que disponível, deve ser considerada complementar à terapia comportamental em pacientes com IUU. Em teoria, a neuroestimulação deve ser minimamente invasiva, facilmente aplicável e não causar constragimento desnecessário. Além disso, a sustentabilidade e a relação custo-eficácia são relevantes considerando tratamentos farmacológicos (49, 69, 70).  
São descritos diferentes protocolos de tratamento (3, 6, 8, 12 semanas) com os dados mais objetivos a favor do esquema de 12 semanas (71). Sendo assim, o estímulo deve ser feito uma vez por semana até, no máximo, 12 semanas. A extensão do tratamento deve levar em conta a gravidade do quadro e resposta ao tratamento.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.2.3 Outros tratamentos** -->
A avaliação de medicamentos da classe de antimuscarínicos, atualmente registrados no Brasil para o tratamento da bexiga hiperativa, como a oxibutinina, tolterodina, solifenacina e darifenacina e também o agonista beta-3 mirabegrona, foi procedida pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), e esses medicamentos não tiveram o uso recomendado.  Estas tecnologias apresentam dados de eficácia semelhante, sendo as principais diferenças observadas nos esquemas de administração e nos efeitos adversos. As evidências indicam que, mesmo que o uso dos antimuscarínicos e a mirabegrona, comparativamente ao placebo, resulte em redução de episódios de IU/dia e do número de micções/dia, essa redução é inconsistente e não representa relevância clínica expressiva, já que corresponde em geral a menos de 01 episódio/dia. A maioria dos estudos avaliados apresentou risco de viés elevado, tempo de seguimento curto e resultados heterogêneos. Os estudos também apontam que existe dúvida quanto à manutenção do efeito de redução de 100% dos episódios de IU (taxa de cura), haja vista que os testes são realizados apenas após três dias de diário miccional. A razão de custo-efetividade incremental para a redução de 01 episódio de IU/dia apresentou altos valores. Assim, após a análise desse conjunto de evidências a recomendação de não incorporar estas tecnologias foi publicada pelas portarias SCTIE/MS nº 33/2019 e n<sup>o</sup> 34/2019 (72, 73).  
19

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **7. MONITORAMENTO** -->
Boas práticas clínicas pressupõem ao menos uma avaliação em intervalo de tempo recente após a conclusão de etapa básica de medidas conservadoras fisioterápicas (tempo mínimo de 3 meses) e avaliações periódicas de seguimento. A definição da periodicidade nas avaliações de seguimento após outras modalidades de tratamento fica a cargo do médico assistente.  
Em tais atendimentos, a obtenção de informações clínicas por anamnese e exame físico são quesitos intuitivos, não sendo necessária a realização de propedêutica complementar. O exame físico deve conter:  
- Avaliação clínica geral;  
- pesquisa dos reflexos cutâneo anal e bulboesponjoso;  
- em homens, toque retal e avaliação da força de contração esfincteriana anal;  
- em mulheres, inspeção pélvica geral, avaliação vulvar e vaginal, inclusive toque para avaliação de força de contração muscular perineal, pesquisa de mobilidade uretral, da existência de prolapsos genitais e de incontinência urinária mediante manobras de esforço.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **8. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica dos sinais e sintomas relativos à evolução e à gravidade da condição urinária.  
No âmbito da Atenção Primária, os pacientes podem ser atendidos por profissionais capacitados para orientação de técnicas de reabilitação e acompanhamento do tratamento. Os procedimentos de reabilitação devem ser prescritos e realizados por profissionais da saúde devidamente qualificados e compreendem o treinamento dos músculos do assoalho pélvico, associado ou não ao _biofeedback_ e à eletroestimulação do nervo tibial.  No SUS, o procedimento que registra essas técnicas é o 03.02.01.002-5 - Atendimento fisioterapêutico em pacientes c/ disfunções uroginecológicas.  
20  
Nos casos de indicação cirúrgica (por exemplo, cirurgia de Burch em mulheres), deve-se dar o encaminhamento aos hospitais que realizem este procedimento.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **REFERÊNCIAS** -->
1. Abrams P CL, Khoury S, Wein A. Incontinence 5th International consultation on incontinence. Health Publication Ltd. 2013:361-88.  
2. D'Ancona C, Haylen B, Oelke M, Abranches-Monteiro L, Arnold E, Goldman H, et al. The International Continence Society (ICS) report on the terminology for adult male lower urinary tract and pelvic floor symptoms and dysfunction. Neurourol Urodyn. 2019;38(2):433-77.  
3. Dziekaniak ACM, Rodrigo Dalke; Cesar, Juraci Almeida. Incontinência urinária entre idosos residentes em área rural de município do sul do Brasil / Urinary incontinence among older adults living in the rural area of a municipality in southern Brazil. Geriatr, Gerontol Aging (Impr). 2019;13(1):4-10.  
4. Wilson L BJ, Shin GP, Luc KO, Subak LL. Annual direct cost of urinary incontinence. Obstetrics & Gynecology. 2001;98(3):398-406.  
5. Norton P, Brubaker L. Urinary incontinence in women. Lancet. 2006;367(9504):57-67.  
6. Tamanini JT, Lebrao ML, Duarte YA, Santos JL, Laurenti R. Analysis of the prevalence of and factors associated with urinary incontinence among elderly people in the Municipality of Sao Paulo, Brazil: SABE Study (Health, Wellbeing and Aging). Cadernos de saude publica. 2009;25(8):1756-62.  
7. Hunskaar S BK, Clark A, Lapitan MC, Nelson R, Sillen U, Thom D. Epidemiology of urinary (UI) and faecal (FI) incontinence and pelvic organ prolapse (POP). Incontinence. 2005;1:255-312.  
8. Fleischmann N FA, Blaivas JG, Panagopoulos G. Sphincteric urinary incontinence: relationship of vesical leak point pressure, urethral mobility and severity of incontinence. The Journal of urology. 2003;169(3):999-1002.  
9. BROWN JS, GRADY D, OUSLANDER JG, HERZOG AR, VARNER RE, POSNER SF. Prevalence of Urinary Incontinence and Associated Risk Factors in Postmenopausal Women. Obstetrics & Gynecology. 1999;94(1):66-70.  
10. Habib NA, Luck RJ. Results of transurethral resection of the benign prostate. British Journal of Surgery. 1983;70(4):218-9.  
11. Mettlin CJ MG, Sylvester J, McKee RF, Morrow M, Winchester DP. Results of hospital cancer registry surveys by the American College of Surgeons. Cancer. 1997;80(9):1875-81.  
12. Rudy DC, Woodside JR, Crawford ED. Urodynamic evaluation of incontinence in patients undergoing modified Campbell radical retropubic prostatectomy: a prospective study. The Journal of urology. 1984;132(4):708-12.  
21  
13. Ficazzola MA NV. The etiology of post-radical prostatectomy incontinence and correlation of symptoms with urodynamic findings. The Journal of urology. 1998;160(4):1317-20.  
14. Resnick NM, Yalla SV. Management of urinary incontinence in the elderly. New England Journal of Medicine. 1985;313(13):800-5.  
15. Abrams P, Klevmark B. Frequency volume charts: an indispensable part of lower urinary tract assessment. . Scandinavian journal of urology and nephrology Supplementum. 1996;179:47-53.  
16. Nambiar AK, Lemack GE, Chapple CR, Burkhard FC, European Association of U. The Role of Urodynamics in the Evaluation of Urinary Incontinence: The European Association of Urology Recommendations in 2016. Eur Urol. 2017;71(4):501-3.  
17. Zimmern P LH, Nager C, Sirls L, Kraus SR, Kenton K, Wilson T, Sutkin G, Siddiqui N, Vasavada S, Norton P. Pre‐operative urodynamics in women with stress urinary incontinence increases physician confidence, but does not improve outcomes. Neurourology and urodynamics. 2014;33(3):302-6.  
18. JG B. Pathophysiology and differential diagnosis of benign prostatic hypertrophy. Urology. 1988;32(Suppl 6):5-11.  
19. Abrams P, Cardozo L, Fall M, Griffiths D, Rosier P, Ulmsten U, et al. The standardisation of terminology of lower urinary tract function: report from the Standardisation Sub-committee of the International Continence Society. Neurourol Urodyn. 2002;21(2):167-78.  
20. Coyne KS, Payne C, Bhattacharyya SK, Revicki DA, Thompson C, Corey R, et al. The impact of urinary urgency and frequency on health-related quality of life in overactive bladder: results from a national community survey. Value in health : the journal of the International Society for Pharmacoeconomics and Outcomes Research. 2004;7(4):455-63.  
21. Nitti V, Taneja S. Overactive bladder: achieving a differential diagnosis from other lower urinary tract conditions. Int J Clin Pract. 2005;59(7):825-30.  
22. Wyndaele JJ. Overactive bladder, differential diagnosis, and clinical utility of fesoterodine. Int J Gen Med. 2012;5:943-51.  
23. Truzzi JC, Gomes CM, Bezerra CA, Plata IM, Campos J, Garrido GL, et al. Overactive bladder - 18 years - Part I. Int Braz J Urol. 2016;42(2):188-98.  
24. B H, KE A. Common theme for drugs effective in overactive bladder treatment: inhibition of afferent signaling from the bladder. International Journal of Urology. 2013;20(1):21-7.  
25. Kennelly MJ, Devoe WB. Overactive bladder: pharmacologic treatments in the neurogenic population. Reviews in urology. 2008;10(3):182-91.  
26. Leron E, Weintraub AY, Mastrolia SA, Schwarzman P. Overactive Bladder Syndrome: Evaluation and Management. Curr Urol. 2018;11(3):117-25.  
22  
27. Lukacz ES, Santiago-Lastra Y, Albo ME, Brubaker L. Urinary Incontinence in Women: A Review. JAMA. 2017;318(16):1592-604.  
28. NICE. Urinary incontinence and pelvic organ prolapse in women overview NICE2019 [Available from: https://pathways.nice.org.uk/pathways/urinaryincontinence-and-pelvic-organ-prolapse-in-women.  
29. Gratzke C, Bachmann A, Descazeaud A, Drake MJ, Madersbacher S, Mamoulakis C, et al. EAU Guidelines on the Assessment of Non-neurogenic Male Lower Urinary Tract Symptoms including Benign Prostatic Obstruction. Eur Urol. 2015;67(6):1099-109.  
30. NICE. Lower urinary tract symptoms in men: management - Clinical guideline [CG97] 2010 [Available from: https://www.nice.org.uk/guidance/cg97.  
31. Bright E, Drake MJ, Abrams P. Urinary diaries: evidence for the development and validation of diary content, format, and duration. Neurourol Urodyn. 2011;30(3):348-52.  
32. Nitti V. Clinical testing for overactive bladder. Can Urol Assoc J. 2011;5(5 Suppl 2):S137-S8.  
33. Rovner E, Kennelly M, Schulte-Baukloh H, Zhou J, Haag-Molkenteller C, Dasgupta P. Urodynamic results and clinical outcomes with intradetrusor injections of onabotulinumtoxinA in a randomized, placebo-controlled dose-finding study in idiopathic overactive bladder. Neurourol Urodyn. 2011;30(4):556-62.  
34. Rovner ES, Goudelocke CM. Urodynamics in the evaluation of overactive bladder. Curr Urol Rep. 2010;11(5):343-7.  
35. Al-Hayek S, Abrams, P. Cystometry and overactive bladder: The need for provocative testing. Current Bladder Dysfunction Reports. 2009;4(4).  
36. Panayi DC, Tekkis P, Fernando R, Hendricken C, Khullar V. Ultrasound measurement of bladder wall thickness is associated with the overactive bladder syndrome. Neurourol Urodyn. 2010;29(7):1295-8.  
37. Rachaneni S MS, Middleton LJ, et al.; on behalf of the Bladder Ultrasound Study (BUS) Collaborative Group. Bladder ultrasonography for diagnosing detrusor overactivity: test accuracy study and economic evaluation. (Health Technology Assessment, No 207). 2016.  
38. Yilmaz Z, Voyvoda B, Sirinocak PB. Overactive bladder syndrome and bladder wall thickness in patients with obstructive sleep apnea syndrome. Int Braz J Urol. 2018;44(2):330-7.  
39. Bono AA BM, Sanz VJ, Esclarín DM, Abad RJ, Salvador OJ. Urinary continence after radial prostatectomy. Prognostic factors and recovery time. Actas urologicas espanolas. 2001;25(8):544-8.  
40. Hunskaar S. A systematic review of overweight and obesity as risk factors and targets for clinical intervention for urinary incontinence in women. Neurourol Urodyn. 2008;27(8):749-57.  
23  
41. Subak LL, Wing R, West DS, Franklin F, Vittinghoff E, Creasman JM, et al. Weight loss to treat urinary incontinence in overweight and obese women. N Engl J Med. 2009;360(5):481-90.  
42. Nygaard I, Barber MD, Burgio KL, Kenton K, Meikle S, Schaffer J, et al. Prevalence of symptomatic pelvic floor disorders in US women. JAMA. 2008;300(11):1311-6. 43. Burkhard F, .,, et al. EAU-Guidelines on urinary incontinence in adults 2016 [Available from: https://uroweb.org/wp-content/uploads/EAU-Guidelines-UrinaryIncontinence-2016.pdf.  
44. Gozukara YM, Akalan G, Tok EC, Aytan H, Ertunc D. The improvement in pelvic floor symptoms with weight loss in obese women does not correlate with the changes in pelvic anatomy. Int Urogynecol J. 2014;25(9):1219-25.  
45. Hannestad YS, Rortveit G, Daltveit AK, Hunskaar S. Are smoking and other lifestyle factors associated with female urinary incontinence? The Norwegian EPINCONT Study. BJOG : an international journal of obstetrics and gynaecology. 2003;110(3):247-54.  
46. Jorgensen S, Hein HO, Gyntelberg F. Heavy lifting at work and risk of genital prolapse and herniated lumbar disc in assistant nurses. Occupational medicine (Oxford, England). 1994;44(1):47-9.  
47. Nygaard IE, Thompson FL, Svengalis SL, Albright JP. Urinary incontinence in elite nulliparous athletes. Obstetrics and gynecology. 1994;84(2):183-7.  
48. Brown WJ, Miller YD. Too wet to exercise? Leaking urine as a barrier to physical activity in women. Journal of science and medicine in sport. 2001;4(4):373-8.  
49. Burkhard F, et al.,. EAU-Guidelines on urinary incontinence in adults 2016 [Available from: https://uroweb.org/wp-content/uploads/EAU-Guidelines-UrinaryIncontinence-2016.pdf.  
50. Imamura M, Abrams P, Bain C, Buckley B, Cardozo L, Cody J, et al. Systematic review and economic modelling of the effectiveness and cost-effectiveness of nonsurgical treatments for women with stress urinary incontinence. Health Technol Assess. 2010;14(40):1-188, iii-iv.  
51. Shamliyan T, Wyman J, Kane RL. AHRQ Comparative Effectiveness Reviews. Nonsurgical Treatments for Urinary Incontinence in Adult Women: Diagnosis and Comparative Effectiveness. Rockville (MD): Agency for Healthcare Research and Quality (US); 2012.  
52. Hay-Smith EJ, Herderschee R, Dumoulin C, Herbison GP. Comparisons of approaches to pelvic floor muscle training for urinary incontinence in women. Cochrane Database Syst Rev. 2011(12):CD009508.  
53. Boyle R, Hay-Smith EJ, Cody JD, Morkved S. Pelvic floor muscle training for prevention and treatment of urinary and faecal incontinence in antenatal and postnatal women. Cochrane Database Syst Rev. 2012;10:CD007471.  
24  
54. Haddow G, Watts R, Robertson J. Effectiveness of a pelvic floor muscle exercise program on urinary incontinence following childbirth. Int J Evid Based Healthc. 2005;3(5):103-46.  
55. Van Kampen M, De Weerdt W, Van Poppel H, Feys H, Castell CA, Stragier J, et al. Prediction of urinary continence following radical prostatectomy. Urologia internationalis. 1998;60(2):80-4.  
56. Campbell SE, Glazener CM, Hunter KF, Cody JD, Moore KN. Conservative management for postprostatectomy urinary incontinence. Cochrane Database Syst Rev. 2012;1:CD001843.  
57. Fitz FF, Resende AP, Stupp L, Sartori MG, Girao MJ, Castro RA. Biofeedback for the treatment of female pelvic floor muscle dysfunction: a systematic review and meta-analysis. Int Urogynecol J. 2012;23(11):1495-516.  
58. Bo K. Pelvic floor muscle training in treatment of female stress urinary incontinence, pelvic organ prolapse and sexual dysfunction. World J Urol. 2012;30(4):437-43.  
59. Burns PA, Pranikoff K, Nochajski TH, Hadley EC, Levy KJ, Ory MG. A comparison of effectiveness of biofeedback and pelvic muscle exercise treatment of stress incontinence in older community-dwelling women. Journal of gerontology. 1993;48(4):M167-74.  
60. Robinson D, Giarenis I, L. C. The medical management of refractory overactive bladder. Maturitas. 2013;74(4):386-90.  
61. Giarenis I, Cardozo L. Management of refractory overactive bladder. Minerva ginecologica. 2013;65(1):41-52.  
62. Gormley EA, Lightner DJ, Burgio KL, Chai TC, Clemens JQ, Culkin DJ, et al. Diagnosis and treatment of overactive bladder (non-neurogenic) in adults: AUA/SUFU guideline. J Urol. 2012;188(6 Suppl):2455-63.  
63. Syan R, Brucker BM. Guideline of guidelines: urinary incontinence. BJU Int. 2016;117(1):20-33.  
64. Ouslander JG. Management of overactive bladder. N Engl J Med. 2004;350(8):786-99.  
65. Burgio KL, Whitehead WE, Engel BT. Urinary incontinence in the elderly. Bladder-sphincter biofeedback and toileting skills training. Annals of internal medicine. 1985;103(4):507-15.  
66. de Groat WC. A neurologic basis for the overactive bladder. Urology. 1997;50(6A Suppl):36-52; discussion 3-6.  
67. Burgio KL, Goode PS, Richter HE, Markland AD, Johnson TM, 2nd, Redden DT. Combined behavioral and individualized drug therapy versus individualized drug therapy alone for urge urinary incontinence in women. J Urol. 2010;184(2):598-603.  
25  
68. Booth J, Hagen S, McClurg D, Norton C, MacInnes C, Collins B, et al. A feasibility study of transcutaneous posterior tibial nerve stimulation for bladder and bowel dysfunction in elderly adults in residential care. J Am Med Dir Assoc. 2013;14(4):270-4.  
69. de Wall LL, Heesakkers JP. Effectiveness of percutaneous tibial nerve stimulation in the treatment of overactive bladder syndrome. Res Rep Urol. 2017;9:145-57.  
70. Schreiner L, dos Santos TG, Knorst MR, da Silva Filho IG. Randomized trial of transcutaneous tibial nerve stimulation to treat urge urinary incontinence in older women. Int Urogynecol J. 2010;21(9):1065-70.  
71. Yoong W, Shah P, Dadswell R, Green L. Sustained effectiveness of percutaneous tibial nerve stimulation for overactive bladder syndrome: 2-year follow-up of positive responders. Int Urogynecol J. 2013;24(5):795-9.  
72. BRASIL. Ministério da Saúde. Relatório nº 467 - Antimuscarínicos (oxibutinina, tolterodina, solifenacina e darifenacina) para o tratamento da Incontinência Urinária de Urgência. Portaria SCTIE/MS nº 33/2019 - Publicada em 28/06/2019. In: DGITIS, editor. Brasília, DF: Ministério da Saúde; 2019.  
73. BRASIL. Ministério da Saúde. Relatório nº 466 - Mirabegrona para o tratamento de incontinência urinária de urgência (IUU). Portaria SCTIE/MS nº 34/2019 - Publicada em 28/06/2019. In: DGITIS, editor. Brasília, DF: Ministério da Saúde; 2019.  
26  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **A) Metodologia** -->
Com a presença de oito membros do Grupo Elaborador, sendo cinco especialistas e três metodologistas, e um representante do Comitê Gestor, uma reunião presencial para definição do escopo deste Protocolo Clínico e Diretrizes Terapêuticas (PCDT) foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.  
Inicialmente, a macroestrutura do PCDT foi estabelecida com base na Portaria SAS/MS N° 375, de 10 de novembro de 2009 (74), que define o roteiro para elaboração dos PCDT, especificando-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias para levantamento das evidências. Considerando as tecnologias já disponíveis no SUS, as novas tecnologias foram identificadas.  
Os participantes elencaram questões de pesquisa, estruturadas de acordo com o acrônimo PICO, para cada tecnologia que necessitasse de avaliação das evidências para análise pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), considerando também casos de incertezas atuais sobre seu uso.  
27  
<!-- Start of picture text -->
•População ou condição clínica<br>P<br>•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos<br>observacionais<br>I<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>•Controle, de acordo com tratamento/níveis de<br>C exposição do fator/exames disponíveis no SUS<br>•Desfechos: sempre que possível, definidos a<br>O priori, de acordo com sua importância<br><!-- End of picture text -->  
**Figura 1– Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO.**  
Ao final dessa dinâmica, sete questões de pesquisa foram definidas para o presente PCDT ( **Quadro 1** ).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Quadro 1 – Questões de pesquisa elencadas pelo Grupo Elaborador do Protocolo Clínico e Diretrizes Terapêuticas.** -->
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**1**|O uso de tela de polipropileno (sintética) é mais<br>eficaz que conduta cirúrgica sem tela?|Tratamento|
|**2**|Quais são as indicações, eficácia e potenciais<br>complicações da cirurgia de sling masculino?|Tratamento|
|**3**|Quais são as indicações, eficácia e potenciais<br>complicações da cirurgia de esfíncter urinário<br>artificial?|Tratamento|
|**4**|Qual a eficácia e segurança dos medicamentos<br>antimuscarínicos<br>(oxibutinina,<br>tolterodina,<br>solifenacina e darifenacina) para o tratamento da<br>incontinência urinária de urgência?|Tratamento|  
28  
|**Número**|**Descrição**|**Seção**|
|---|---|---|
|**5**|Qual a eficácia e segurança da Mirabegrona para<br>o tratamento da incontinência urinária de<br>urgência?|Tratamento|
|**6**|Quais são as indicações, eficácia e segurança da<br>toxina botulínica A (onabotulinumtoxinA) no<br>tratamento da incontinência urinária de urgência?|Tratamento|
|**7**|Quais são as indicações, eficácia e segurança da<br>neuromodulação<br>sacral<br>no<br>tratamento<br>da<br>incontinência urinária de urgência?|Tratamento|  
Após a avaliação das perguntas pelo Comitê gestor do PCDT de incontinência urinária, foi identificado que a temática poderia ser dividida em dois grandes grupos, tratamento cirúrgico e não cirúrgico. Assim, considerando priorizações e tempo dedicado para a elaboração do documento, foram focadas as duas perguntas estruturadas, relativas à avaliação da eficácia e da segurança dos antimuscarínicos e da mirabegrona para o controle da IUU. De acordo com o Comitê gestor do PCDT, as demais tecnologias, cirúrgicas, poderão serão abordadas em uma nova versão do PCDT ou em outro documento.  
As seções foram distribuídas entre os integrantes do grupo elaborador para análise das evidências e redação do texto do PCDT. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida no PCDT. As bases de dados Epistemonikos e Google  
29  
acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com metaanálise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clinico-demográficas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiuse um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, essas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia. Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares, que atuassem como provedores de evidência indireta para a questão de pesquisa, também foram mantidos, para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. O detalhamento desse processo de seleção é descrito por questão de pesquisa correspondente, ao longo deste Apêndice.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. Esta extração foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel. As características dos participantes nos estudos  
30  
foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Caso o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Caso o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2) (75), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane (76), os estudos observacionais pela ferramenta Newcastle-Ottawa (77) e os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2) (78). Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas a priori como alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa ao longo deste Apêndice.  
**A análise completa do conjunto de evidência descrito pode ser consultada nos relatórios de recomendação da CONITEC (72,73), disponíves em** **<u>www.conitec.gov.br, de 2019.</u>**

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **B) Questões de Pesquisa** -->
**Questão de Pesquisa 4:** Qual a eficácia e segurança dos medicamentos antimuscarínicos (oxibutinina, tolterodina, darifenacina e solifenacina) para o tratamento da incontinência urinária de urgência?

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **MEDLINE via Pubmed** -->
31  
(((((((("Urinary Bladder, Overactive"[Mesh]) OR Urinary Bladder, Overactive) OR Overactive Bladder) OR Overactive Urinary Bladder) OR Bladder, Overactive)) OR (((((((("Urinary Incontinence, Urge"[Mesh]) OR Urinary Reflex Incontinence) OR Incontinence, Urinary Reflex) OR Urinary Urge Incontinence) OR Urge Incontinence) OR Incontinence, Urge)) OR Urinary Incontinence, Urge))) AND ((((("Muscarinic Antagonists"[Mesh] OR Muscarinic Antagonists OR Antagonists, Muscarinic OR Antimuscarinics OR Antimuscarinic Agents OR Agents, Antimuscarinic OR Cholinergic Muscarinic Antagonists OR Antagonists, Cholinergic Muscarinic OR Muscarinic Antagonists, Cholinergic)) OR ("oxybutynin" [Supplementary Concept] OR oxybutynin OR 4-(diethylamino)-2-butynyl-alpha-cyclohexyl-alpha-hydroxybenzeneacetate OR 4- (diethylamino)-2-butynyl-alpha-phenylcyclohexaneglycolate OR Zatur OR Contimin OR Cystonorm OR Ditropan OR Dridase OR Cystrin OR Dresplan OR Driptane OR gelnique OR Gen-Oxybutynin OR Novo-Oxybutynin OR Nu-Oxybutyn OR Oxyb AbZ OR Oxybutin Holsten OR Oxybuton OR Oxybutynin AL OR Oxybutynin AZU OR Oxybutynin Heumann OR Oxybutynin Hexal OR oxybutynin hydrochloride OR oxybutynin chloride OR Oxybutynin Stada OR oxybutynin von ct OR Oxybutynin-Puren OR Oxybutynin-ratiopharm OR Oxymedin OR Oxytrol OR PMS-Oxybutynin OR Pollakisu OR Renamel OR Ryol OR Spasmex Oxybutynin OR Spasyt OR Tavor OR Oxybugamma OR Apo-Oxybutynin)) OR ("Tolterodine Tartrate"[Mesh] OR Tolterodine Tartrate OR Tartrate, Tolterodine OR Tolterodine OR Detrol OR Detrol LA OR Urotrol OR PHA-686464B OR PHA 686464B OR PHA686464B OR Detrusitol OR Unidet)) OR ("Solifenacin Succinate"[Mesh] OR Solifenacin Succinate OR Succinate, Solifenacin OR Quinuclidin-3'-yl-1-phenyl-1,2,3,4-tetrahydroisoquinoline-2-carboxylate monosuccinate OR YM905 OR YM 905 OR 905, YM OR Vesicare OR Solifenacin)) OR ("darifenacin" [Supplementary Concept] OR darifenacin OR darifenacine OR darifenicin OR darifenacin hydrochloride OR Enablex OR UK-88525 OR darifenacin hydrobromide OR Emselex)AND (randomized controlled trial[pt] OR controlled clinical trial[pt] OR randomized[tiab] OR placebo[tiab] OR drug therapy[sh] OR randomly[tiab] OR trial[tiab] OR groups[tiab] NOT (animals [mh] NOT humans [mh]))  
Total: 1.621 referências  
<mark>Data do acesso: 04/10/2017.</mark>  
32

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **EMBASE** -->
(urinary AND incontinence, AND urge OR (urinary AND ('reflex'/exp OR reflex) AND ('incontinence'/exp OR incontinence)) OR 'urge incontinence'/exp OR 'urge incontinence' OR (incontinence, AND urinary AND ('reflex'/exp OR reflex)) OR 'overactive bladder'/exp OR 'overactive bladder' OR (urinary AND bladder, AND overactive) OR (overactive AND urinary AND ('bladder'/exp OR bladder))) AND (('muscarinic receptor blocking agent'/exp OR 'muscarinic receptor blocking agent') OR ('oxybutynin'/exp OR 'oxybutynin') OR ('tolterodine'/exp OR 'tolterodine') OR ('solifenacin'/exp OR 'solifenacin') OR ('darifenacin'/exp OR 'darifenacin'))AND ('crossover procedure':de OR 'double-blind procedure':de OR 'randomized controlled trial':de OR 'single-blind procedure':de OR random*:de,ab,ti OR factorial*:de,ab,ti OR crossover*:de,ab,ti OR ((cross NEXT/1 over*):de,ab,ti) OR placebo*:de,ab,ti OR ((doubl* NEAR/1 blind*):de,ab,ti) OR ((singl* NEAR/1 blind*):de,ab,ti) OR assign*:de,ab,ti OR allocat*:de,ab,ti OR volunteer*:de,ab,ti)  
Total: 1.867 referências  
<mark>Data do acesso: 04/10/2017.</mark>

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **2) Seleção das Evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 3.488 referências (1.621 MEDLINE e 1867 no EMBASE). Destas, 902 foram excluídas por estarem duplicadas. Duas mil quinhentos e oitenta e seis referências foram triadas por meio da leitura de título e resumos, <mark>das quais 82 tiveram seus textos completos avaliados para confirmação da elegibilidade</mark>  
<mark>Os critérios de inclusão priorizaram estudos com maior rigor metodológico (revisões sistemáticas recentes, com meta-análise direta ouindireta de resultados de ensaios clínicos randomizados, e estudos primários do tipo ensaios clínicos randomizados comparativos) que compararam a eficácia e segurança dosantimuscarínicosdisponíveis no Brasil (oxibutinina, darifenacina, solifenacina e tolterodina) com outro tratamento ouplacebo, em pacientes diagnosticados com incontinência urinária de urgência.Somente resumos de congressos de revisões sistemáticas com meta-análise que fornecessem as referências dos estudos incluídos foram considerados.</mark>  
33  
<mark>Desta forma, 70 referências foram excluídas com as seguintes razões: 62 estudos originais já incluídos nas revisões sistemáticas com meta-análise incluídas neste documento; e oito avaliaram preditores de resposta ao tratamento (e não o efeito do tratamento em si).</mark>  
<mark>Ao todo, dez referências foram incluídas (79-88): oito revisões sistemáticas com meta-análises diretas ou indiretas (79-86); e dois ensaios clínicos randomizados que não foram incluídos pelas revisão sistemáticas (87, 88).</mark>

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **3) Descrição dos Estudos e seus Resultados** -->
A descrição sumária dos estudos encontra-se nas tabelas a seguir. As características dos estudos incluídos são apresentadas na **Tabela 1** . As características dos participantes de cada estudo encontram-se na **Tabela 2** . Os desfechos primários encontram-se na **Tabela 3** (número de episódios de incontinência urinária em 24 horas, número de episódios de incontinência urinária de urgência em 24 horas, número de episódios de urgência em 24 horas e número de micções em 24 horas) e os desfechos secundários na **Tabela 4** (noctúria, volume urinado por micção e taxa de cura). Os eventos adversos relatados nos estudos são apresentados nas **tabelas 5-8** .  
34

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 1 – Características dos estudos** -->
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**Obloza et al.**<br>**2017**<br>**(79)**|Revisão<br>sistemática com<br>meta-análise<br>indireta|Comparar o<br>tratamento de BH<br>com antimuscarínicos<br>versus mirabegron e<br>versus toxina<br>botulínica A|25 ECRs incluídos|Grupo MIRA 50 mg:<br>Mirabegron 50 mg<br>Grupo AntiM:<br>Antimuscarínicos:<br>propiverina,<br>fesoterodina,<br>solifenacina,<br>oxibutinina, trospium<br>Grupo ToxBot:<br>Toxina botulínica A 100<br>UI injeção intra-detrusor|Grupo PLAC:<br>Placebo|Alto<br>Não reporta<br>extração por pares,<br>não reporta as<br>razões de exclusão<br>de estudos, não<br>descreve os<br>estudos incluídos<br>com detalhes<br>suficientes, não<br>reporta fonte de<br>financiamento dos<br>estudos incluídos,<br>não avaliou viés de<br>publicação|
|**Sebastianelli**<br>**et al. 2017**<br>**(80)**|Revisão<br>sistemática com<br>meta-análise<br>(resumo de<br>congresso)|Avaliar a eficácia e<br>segurança do MIRA<br>comparado à TOLT<br>para o tratamento de<br>BH e de sintomas do<br>trato urinário baixo|8 ECRs incluídos,<br>n=10.239<br>participantes|Grupo MIRA 50 mg:<br>Mirabegron 50 mg<br>Grupo MIRA 100 mg:<br>Mirabegron 100 mg|Grupo TOLT:<br>Tolterodina 4 mg|Alto<br>Resumo de<br>congresso não<br>apresenta<br>informações<br>suficientes para<br>avaliação|
|**Fonseca et al.**<br>**2016**|Revisão<br>sistemática com|Avaliar a evidência<br>existente de ECRs em|<sup>15 ECRs incluídos</sup>|Grupo OXIB:<br>Oxibutinina 5 e 10 mg|Grupo PLAC:<br>Placebo|Incerto|  
35  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**(81)**|meta-análise.<br>Última<br>atualização em<br>setembro de<br>2015|relação aos desfechos<br>dos tratamentos<br>farmacológicos<br>disponíveis no Brasil,<br>para BH||Grupo TOLT:<br>Tolterodina 1, 2 e 4 mg<br>Grupo SOLI:<br>Solifenacina 5 e 10 mg||Não avaliou risco<br>de viés de<br>publicação, não<br>citou a<br>presença/ausência<br>de conflitos de<br>interesse|
|**Owen et al.**<br>**2016**<br>**(82)**|Revisão<br>sistemática com<br>meta-análise<br>(resumo de<br>congresso).<br>Última<br>atualização em<br>janeiro de 2016|Comparar a eficácia e<br>segurança de<br>intervenções<br>conservativas para<br>hiperatividade do<br>detrusor idiopática e<br>BH, utilizando a<br>meta-análise em rede|Total de 174<br>ECRs incluídos,<br>n=75.355<br>participantes, 140<br>intervenções.<br>Não relata quantos<br>ECRs avaliaram<br>antimuscarínicos|Grupo OXIB:<br>Oxibutinina 5 mg LI<br>3x/dia<br>Grupo TOLT+neuro:<br>Tolterodina 4 mg LP<br>1x/dia +<br>neuroestimulação<br>Grupo TOLT+ToxBot:<br>Tolterodina 2 mg LI<br>2x/dia + toxina<br>botulínica<br>Grupo DARI:<br>Darifenacina 30 mg LP<br>1x/dia<br>Grupo SOLI:<br>Solifenacina 20 mg LP<br>1x/dia|Grupo PLAC:<br>Placebo|Alto<br>Resumo de<br>congresso não<br>apresenta<br>informações<br>suficientes para<br>avaliação|
|**Reynolds et**<br>**al. 2015**|Revisão<br>sistemática com|Avaliar e evidência<br>disponível nos ECRs|50 ECRs<br>incluídos, >27.000|Grupo OXIB:<br>Oxibutinina (n=2.762)|Grupo PLAC:|Alto|  
36  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
|**(83)**|meta-análise.<br>Última<br>atualização em<br>março de 2014|sobre desfechos do<br>tratamento<br>farmacológico em<br>mulheres com BH|mulheres.<br>13 ECRs com<br>OXIB, 25 com<br>TOLT, 8 com<br>SOLI e 4 com<br>DARI|Grupo TOLT:<br>Tolterodina (n=8.857)<br>Grupo SOLI:<br>Solifenacina (n=2.340)<br>Grupo DARI:<br>Darifenacina (n=834)|Placebo<br>(n=5.073)|Não descreveu os<br>estudos incluídos,<br>não avaliou as<br>fontes de<br>heterogeneidade,<br>não conduziu<br>análises de<br>sensibilidade para<br>avaliar o impacto<br>da heterogeneidade<br>nas estimativas,<br>não avaliou viés de<br>publicação|  
|**Luo et al.**<br>**2012**<br>**(84)**|Revisão<br>sistemática com<br>meta-análise.<br>Última<br>atualização em<br>janeiro de 2011|Avaliar a eficácia e<br>segurança da SOLI<br>para o tratamento de<br>adultos com BH|13 ECRs<br>incluídos, sendo 9<br>ECRs com SOLI<br>vs placebo, 6 com<br>SOLI vs TOLT e 4<br>com SOLI 5 mg vs<br>10 mg|Grupo SOLI:<br>Solifenacina 2,5 - 10 mg|Grupo PLAC:<br>Placebo<br>Grupo TOLT:<br>Tolterodina 2 - 4<br>mg<br>Grupo SOLI 10<br>mg:<br>Solifenacina 10|Incerto<br>Não menciona<br>protocolo pré-<br>definido, não<br>avaliou risco de<br>viés de publicação|
|---|---|---|---|---|---|---|
||||||mg||
|**Madden et**<br>**al. 2012**<br>**(85)**|Revisão<br>sistemática com<br>meta-análise<br>(resumo de|Avaliar a taxa de cura<br>com o uso de<br>antimuscarínicos para<br>o tratamento da IUU|16 ECRs<br>incluídos, 10<br>avaliaram|Grupo AntiM:<br>Antimuscarínicos|Placebo|Alto<br>Resumo de<br>congresso não<br>apresenta|  
37  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||congresso).<br>Última<br>atualização em<br>dezembro de<br>2010||antimuscarínicos<br>vs placebo|||informações<br>suficientes para<br>avaliação|
|**Odeyemi et**<br>**al. 2012**<br>**(86)**|Revisão<br>sistemática com<br>meta-análise<br>(resumo de<br>congresso).<br>Última<br>atualização em<br>outubro de 2011|Obter evidências<br>sobre a SOLI e TROS<br>para dar suporte às<br>decisões de<br>prescrição e<br>formulários|8 ECRs incluídos,<br>5 compararam<br>SOLI vs placebo e<br>3 compararam<br>TROS vs placebo|Grupo SOLI:<br>Solifenacina 5 mg ou 10<br>mg|Grupo PLAC:<br>Placebo<br>Grupo TROS:<br>Trospium 20 mg<br>LI 2x/dia ou<br>Trospium 60 mg<br>LP 1x/dia|Alto<br>Resumo de<br>congresso não<br>apresenta<br>informações<br>suficientes para<br>avaliação|
|**Herschorn et**<br>**al. 2017**<br>**(87)**|SYNERGY:<br>ECR<br>multinacional,<br>duplo-cego,<br>controlado por<br>placebo e<br>substância ativa|Comparar a eficácia<br>da terapia combinada<br>de SOLI e MIRA<br>versus placebo e<br>monoterapia|Idade >18 anos,<br>com sintomas<br>predominantes de<br>IUU > 3 meses,<br>com média >8<br>micções/24h, >1<br>urgência/24h, >3<br>incontinências no<br>diário de 7 dias|Grupo SOLI+MIRA:<br>Solifenacina 5 mg +<br>mirabegron 25 mg ou 50<br>mg<br>Grupo MIRA:<br>Mirabegron 25 mg ou 50<br>mg<br>Grupo SOLI:<br>Solifenacina 5 mg|Grupo PLAC:<br>Placebo|Alto<br>Não reporta como<br>foi realizada a<br>geração da<br>sequência<br>aleatória, não<br>reporta ocultação<br>da alocação|
|**Kuo et al.**<br>**2015**<br>**(88)**|ECR,<br>multicêntrico,<br>duplo-cego,|Analisar a eficácia e<br>segurança MIRA|Adultos com<br>sintomas de BH<br>por > 3 meses|Grupo MIRA:<br>Mirabegron 50 mg<br>Grupo TOLT:|Grupo PLAC:<br>Placebo|Incerto<br>A análise não foi<br>por intenção de|  
38  
|**Autor, ano**|**Desenho do**<br>**estudo**|**Objetivo do estudo**|**População**|**Detalhes da**<br>**intervenção**|**Detalhes do**<br>**Comparador**|**Risco de viés**|
|---|---|---|---|---|---|---|
||placebo-<br>controlado,<br>ativo-controlado,|comparado com<br>placebo||Tolterodina LP 4mg||tratar (i.e., não<br>foram analisados<br>todos os|
||grupo-paralelo<br>Study 178-CL-|||||participantes que<br>foram|
||045|||||randomizados).|  
Legenda: BH: bexiga hiperativa; IUU: incontinência urinária de urgência; ECR: ensaio clínico randomizado; LI: liberação imediata; LP: liberação prolongada; DARI: darifenacina; MIRA: mirabegron; OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; TROS: trospium; PLAC: placebo.  
**Tabela 2 – Características dos participantes**  
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ± DP**|**Sexo, % feminino**|**Duração do estudo**|
|---|---|---|---|---|---|
|**Obloza et al. 2017 (79)**|NR|NR|NR|NR|NR|
|**Sebastianelli et al.**<br>**2017 (80)**|Total|10.239|NR|NR|NR|
|**Fonseca et al. 2016**<br>**(81)**|NR|NR|NR|NR|NR|
|**Owen et al. 2016 (82)**|Total|75.355|NR|NR|NR|
|**Reynolds et al. 2015**|Total|>27.000|NR|100%|Mediana: 12 semanas|
|**(83)**|OXIB|2.762|NR|100%|(2 - 52 semanas)|  
39  
|**Autor, ano**|**Grupo**|**Tamanho amostral,**<br>**n**|**Idade, média ± DP**|**Sexo, % feminino**|**Duração do estudo**|
|---|---|---|---|---|---|
||TOLT|8.857|NR|100%||
||SOLI|2.340|NR|100%||
||DARI|834|NR|100%||
||SOLI vs PLAC|3.311|NR|NR||
|**Luo et al. 2012 (84)**|SOLI vs TOLT|2.008|NR|NR|Variação: 8 - 16<br>semanas|
||SOLI 5 mg vs SOLI<br>10 mg|695|NR|NR||
||Total|7.284|NR|NR||
|**Madden et al. 2012**<br>**(85)**|AntiM|5.127|NR|NR|NR|
||PLAC|2.157|NR|NR||
|**Odeyemi et al. 2012**<br>**(86)**|NR|NR|NR|NR|NR|
||Total|3.398|57,4 ± 13,4|77,0%||
||PLAC|429|57,9 ± 13,0|76,2%||
|**Herschorn et al. 2017**<br>**(87)**|MIRA 25 mg|423|56,9 ± 13,6|77,3%|18 semanas|
||MIRA 50 mg|422|56,7 ± 13,3|76,5%||
||SOLI 5 mg|423|58,2 ± 12,8|78,3%||  
40  
|**Autor, ano**|**Grupo**<br>**Ta**|**manho amostral,**<br>**n**|**Idade, média ± DP**|**Sexo, % feminino**|**Duração do estudo**|
|---|---|---|---|---|---|
||SOLI + MIRA 25 mg|853|57,1 ± 13,9|76,9%||
||SOLI + MIRA 50 mg|848|57,6 ± 13,4|76,8%||
||Total|248|NR|NR||
|**Kuo et al. 2015 (88)**|MIRA|76|59,0 ± 15,1|61,8%|14 semanas|
||TOLT|74|56,4 ± 15,8|59,5%||
||PLAC|68|58,4 ± 13,0|61,2%||  
AntiM: antimuscarínicos; DARI: darifenacina; MIRA: mirabegron; OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; TROS: trospium; PLAC: placebo; NR: não reportado;DP: desvio padrão.  
41

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 3 –  Desfechos primários de eficácia** -->
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
||MIRA vs SOLI 5 mg|∆ (MIRA) - (SOLI):<br>0,24 (IC95% -0,26;<br>0,75)|NR|∆ (MIRA) - (SOLI):<br>0,69 (IC95% -0,44;<br>0,94), p=0,02|∆ (MIRA) - (SOLI):<br>0,43 (IC95% -0,21;<br>0,65), p<0,001|
||MIRA vs SOLI 10<br>mg|∆ (MIRA) - (SOLI):<br>0,48 (IC95% 0,26; 0,70)|NR|∆ (MIRA) - (SOLI):<br>0,99 (IC95% 0,74;<br>1,24), p<0,001|∆ (MIRA) - (SOLI):<br>0,80 (IC95% 0,58;<br>1,02), p<0,001|
|**Obloza et al.**<br>**2017 (79)**|MIRA vs TOLT|∆ (MIRA) - (TOLT): -<br>0,05 (IC95% -0,35;<br>0,24)|NR|∆ (MIRA) - (TOLT): -<br>0,21 (IC95% -0,58;<br>0,16), p=NS|∆ (MIRA) - (TOLT):<br>0,10 (IC95% -0,37;<br>0,57), p=NS|
||MIRA vs FESO 4<br>mg|∆ (MIRA) - (FESO):<br>0,16 (IC95% -0,33;<br>0,66)|NR|∆ (MIRA) - (FESO):<br>0,33 (IC95% -0,27;<br>0,94), p=NS|∆ (MIRA) - (FESO):<br>0,01 (IC95% -0,51;<br>0,54), p=NS|
||MIRA vs FESO 8<br>mg|∆ (MIRA) - (FESO):<br>0,44 (IC95% -0,26;<br>1,15)|NR|∆ (MIRA) - (FESO):<br>0,64 (IC95% 0,04;<br>1,23), p=NS|∆ (MIRA) - (FESO):<br>0,34 (IC95% -0,22;<br>0,92), p=NS|
|||∆ (MIRA 50 mg) -|||∆ (MIRA 50 mg) -|
|**Sebastianelli et**<br>**al. 2017 (80)**|MIRA 50 mg vs<br>TOLT|(TOLT): -0,09 (IC95% -<br>0,35; 0,17), p=0,49, 5<br>ECRs, I<sup>2</sup>: 70%, p=0,009|NR|NR|(TOLT): -0,11 (IC95% -<br>0,26; 0,03), p=0,12, 5<br>ECRs, I<sup>2</sup>: 44%, p=0,13|  
42  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
||MIRA 100 mg vs<br>TOLT|∆ (MIRA 100 mg) -<br>(TOLT): -0,07 (IC95% -<br>0,26; 0,12), p=NS, 3<br>ECRs, I2: 36%, p=NS|NR|NR|∆ (MIRA 100 mg) -<br>(TOLT): -0,08 (IC95% -<br>0,27; 0,11), p=0,39, 3<br>ECRs, I2: 0%, p=0,74|
|||∆ (OXIB) - (TOLT):|∆ (OXIB) - (TOLT): -||∆ (OXIB) - (TOLT):|
||OXIB vs TOLT|0,15 (IC95% -0,64;<br>0,94), p=NS, 3 ECRs,<br>I2: 73%, p=0,03|0,49 (IC95% -1,00;<br>0,03), p=NS, 2 ECRs,<br>I2: 0%, p=NS|NR|0,00 (IC95% -0,01;<br>0,01), p=NS, 4 ECRs,<br>I2: 18%, p=NS|
||TOLT 1 mg vs<br>PLAC|∆ (TOLT 1 mg) -<br>(PLAC): -0,26 (IC95% -<br>1,05; 0,53), p=NS, 2|NR|NR|∆ (TOLT 1 mg) -<br>(PLAC): -0,55 (IC95% -<br>1,08; -0,02), p=0,04, 3|
|||ECRs, I2: 0%, p=NS|||ECRs, I2: 0%, p=NS|
|**Fonseca et al.**<br>**2016 (81)**|TOLT 2 mg vs<br>PLAC|∆ (TOLT 2 mg) -<br>(PLAC): -0,45 (IC95% -<br>0,76; -0,14), p=0,005, 6<br>ECRs, I2: 0%, p=NS|NR|NR|∆ (TOLT 2 mg) -<br>(PLAC): -0,57 (IC95% -<br>0,82; -0,32), p<0,0001,<br>7 ECRs, I2: 0%, p=NS|
|||∆ (TOLT 4 mg) -|||∆ (TOLT 4 mg) -|
||TOLT 4 mg vs<br>PLAC|(PLAC): -0,46 (IC95% -<br>0,83; -0,08), p=0,02, 6|NR|NR|(PLAC): -0,66 (IC95% -<br>0,85; -0,47), p<0,0001,|
|||<br>ECRs, I2: 0%, p=NS|||<br>6 ECRs, I2: 0%, p=NS|
||TOLT 2 mg vs|∆ (TOLT 2 mg) -|NR|NR|∆ (TOLT 2 mg) -|
||TOLT 1 mg|(TOLT 1 mg): -0,08|||(TOLT 1 mg): 0,04|  
43  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
|||(IC95% -0,75; 0,59),<br>p=NS, 2 ECRs, I2: 0%,<br>p=NS|||(IC95% -0,46; 0,54),<br>p=NS, 3 ECRs, I2: 0%,<br>p=NS|
||TOLT 4 mg vs<br>TOLT 2 mg|∆ (TOLT 4 mg) -<br>(TOLT 2 mg): -0,11<br>(IC95% -0,67; 0,45),<br>p=NS, 3 ECRs, I2: 0%,<br>p=NS|NR|NR|∆ (TOLT 4 mg) -<br>(TOLT 2 mg): -0,73<br>(IC95% -1,64; 0,18),<br>p=NS, 3 ECRs, I2: 86%,<br>p=0,0008|
|||∆ (SOLI) - (PLAC): -|||∆ (SOLI) - (PLAC): -|
||SOLI vs PLAC|0,77 (IC95% -1,09; -<br>0,45), p<0,0001, 2<br>ECRs, I2: 0%, p=NS|NR|NR|0,77 (IC95% -1,09; -<br>0,45), p<0,0001, 2<br>ECRs, I2: 0%, p=NS|
|**Owen et al.**|OXIB|∆ (final) - (basal): -0,56<br>(IC95% -0,95; -0,24),<br>p<0,05|NR|NR|∆ (final) - (basal): -0,72<br>(IC95% -1,06; -0,36),<br>p<0,05|
|**2016 (82)**|TOLT+neuro|NR|NR|NR|∆ (final) - (basal): -1,93<br>(IC95% -2,72; -1,15),<br>p<0,05|
|**Reynolds et al.**<br>**2015 (83)**|OXIB LI|NR|∆ (basal) - (final): 1,61<br>(IC95% 0,8; 2,42),<br>p<0,05|NR|∆ (basal) - (final): 2,4<br>(IC95% 1,46; 3,33),<br>p<0,05|  
44  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
||OXIB LP|NR|∆ (basal) - (final): 0,53<br>(IC95% 20,34; 1,41),<br>p<0,05|NR|∆ (basal) - (final): 1,72<br>(IC95% 0,68; 2,75),<br>p<0,05|
||TOLT LO|NR|∆ (basal) - (final): 1,59<br>(IC95% 1,12; 2,06),<br>p<0,05|NR|∆ (basal) - (final): 1,99<br>(IC95% 1,29; 2,68),<br>p<0,05|
||TOLT LP|NR|∆ (basal) - (final): 1,67<br>(IC95% 1,27; 2,08),<br>p<0,05|NR|∆ (basal) - (final): 2,14<br>(IC95% 1,63; 2,64),<br>p<0,05|
||DARI|NR|∆ (basal) - (final): 1,65<br>(IC95% 0,6; 2,7),<br>p<0,05|NR|∆ (basal) - (final): 2,18<br>(IC95% 0,31; 4,05),<br>p<0,05|
||SOLI|NR|∆ (basal) - (final): 1,47<br>(IC95% 0,93; 2,02),<br>p<0,05|NR|∆ (basal) - (final): 2,14<br>(IC95% 1,41; 2,88),<br>p<0,05|
|**Luo et al. 2012**<br>**(84)**|SOLI vs PLAC|∆ (SOLI) - (PLAC): -<br>0,51 (IC95% -0,76; -<br>0,26), p<0,0001, 7<br>ECRs, I<sup>2</sup>: 52%, p=NS|∆ (SOLI) - (PLAC): -<br>0,54 (IC95% -0,88; -<br>0,20), p<0,002|∆ (SOLI) - (PLAC): -<br>1,08 (IC95% -1,31; -<br>0,85), p<0,0001, 7<br>ECRs, I<sup>2</sup>: 0%, p=NS|∆ (SOLI) - (PLAC): -<br>1,07 (IC95% -1,39; -<br>0,76), p<0,0001, 7<br>ECRs, I<sup>2</sup>: 57%, p=0,04|  
45  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
||SOLI vs TOLT|∆ (SOLI) - (PLAC): -<br>0,51 (IC95% -0,76; -<br>0,26), p<0,0001, 7<br>ECRs, L6:Q7: 52%,<br>p=NS|∆ (SOLI) - (TOLT): -<br>0,58 (IC95% -0,64; -<br>0,51), p<0,0001|∆ (SOLI) - (TOLT): -<br>0,37 (IC95% -0,51; -<br>0,23), p<0,0001, 5<br>ECRs, I2: 0%, p=NS|∆ (SOLI) - (TOLT): -<br>0,06 (IC95% -0,12; -<br>0,01), p<0,02, 5 ECRs,<br>I2: 20%, p=NS|
||SOLI 5 mg vs SOLI<br>10 mg|∆ (SOLI 5 mg) - (SOLI<br>10 mg): 0,17 (IC95% -<br>0,07; 0,41), p=NS, 3<br>ECRs, I2: 17%, p=NS|∆ (SOLI 5 mg) - (SOLI<br>10 mg): 0,38 (IC95% -<br>0,04; -0,80), p=NS|∆ (SOLI 5 mg) - (SOLI<br>10 mg): -0,09 (IC95% -<br>0,20; 0,11), p=NS, 4<br>ECRs, I2: 0%, p=NS|∆ (SOLI 5 mg) - (SOLI<br>10 mg): 0,29 (IC95%<br>0,25; 0,34), p<0,0001, 4<br>ECRs, I2: 0%, p=NS|
||SOLI 5 mg vs TROS<br>LP|NR|∆ (SOLI 5 mg) -<br>(TROS): -0,78 (IC95% -<br>1,43; -0,42), p<0,05|NR|∆ (SOLI 5 mg) -<br>(TROS): -0,89 (IC95% -<br>1,14; -0,70), p<0,05|
|**Odeyemi et al.**|SOLI 5 mg vs TROS<br>LI|NR|∆ (SOLI 5 mg) -<br>(TROS): -1,55 (IC95% -<br>2,17; -1,11), p<0,05|NR|∆ (SOLI 5 mg) -<br>(TROS): -0,93 (IC95% -<br>1,39; -0,62), p<0,05|
|**2012 (86)**|SOLI 10 mg vs<br>TROS LP|NR|∆ (SOLI 10 mg) -<br>(TROS): -0,75 (IC95% -<br>1,46; -0,38), p<0,05|NR|∆ (SOLI 10 mg) -<br>(TROS): -1,25 (IC95% -<br>1,66; -0,95), p<0,05|
||SOLI 10 mg vs<br>TROS LI|NR|∆ (SOLI 10 mg) -<br>(TROS): -1,50 (IC95% -<br>2,30; -0,98), p<0,05|NR|∆ (SOLI 10 mg) -<br>(TROS): -1,31 (IC95% -<br>2,00; -0,85), p<0,05|  
46  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
||SOLI 5 mg|∆ (final) - (basal): -0,45|NR|NR|∆ (final) - (basal): -0,56|
||MIRA 25 mg|∆ (final) - (basal): -0,37|NR|NR|∆ (final) - (basal): -0,36|
||MIRA 50 mg|NR|NR|NR|∆ (final) - (basal): -0,39|
||SOLI+MIRA 25 mg|∆ (final) - (basal): -0,70|NR|NR|∆ (final) - (basal): -0,85|
|**Hh**|SOLI+MIRA 50 mg|∆ (final) - (basal): -0,65|NR|NR|∆ (final) - (basal): -0,95|
|**erscorn et**<br>**al. 2017 (87)**|SOLI+MIRA 25 mg<br>vs MIRA 25 mg|∆ (SOLI+MIRA 25 mg)<br>- (MIRA 25 mg): -0,34<br>(IC95% -0,58; -0,10),<br>p=0,001|NR|NR|∆ (SOLI+MIRA 25 mg)<br>- (MIRA 25 mg): -0,48<br>(IC95% -0,76; -0,21),<br>p=0,001|
||SOLI+MIRA 50 mg<br>vs MIRA 50 mg|∆ (SOLI+MIRA 50 mg)<br>- (MIRA 50 mg): -0,23<br>(IC95% -0,47; 0,01),<br>p=NS|NR|NR|∆ (SOLI+MIRA 50 mg)<br>- (MIRA 50 mg): -0,56<br>(IC95% -0,84; -0,28),<br>p<0,001|
|||Basal, média ± DP: 2.54<br>± 3.00|Basal, média ± DP: 2.16<br>± 2.42|Basal, média ± DP: 5.53<br>± 3.98|Basal, média ± DP: 11.6<br>± 3.09|
|**Kuo et al. 2015**<br>**(88)**|MIRA 50 mg|Fim do estudo: 1.16 ±<br>2.51<br>DM ± DP: -1.16 ± 2.51|Fim do estudo: 0.43 ±<br>1.09<br>DM ± DP: -1.73 ± 2.71|Fim do estudo: 3.56 ±<br>3.78<br>DM ± DP: -1.97 ± 3.49|Fim do estudo: 9.46 ±<br>2.79<br>DM ± DP: -2.12 ± 2.91|
||TOLT 4 mg|Basal, média ± DP: 1.58<br>± 1.95|Basal, média ± DP: 1.61<br>± 2.10|Basal, média ± DP: 5.93<br>± 4.87|Basal, média ± DP: 12.3<br>± 3.27|  
47  
|**Autor, ano**|**Grupos comparados**|**Número de episódios**<br>**de incontinência**<br>**urinária em 24 horas**|**Número de episódios**<br>**de incontinência**<br>**urinária de urgência**<br>**em 24 horas**|**Número de episódios**<br>**de urgência em 24**<br>**horas**|**Número de micções em**<br>**24 horas**|
|---|---|---|---|---|---|
|||Fim do estudo: 0.78 ±<br>1.25<br>DM ± DP: -0.79 ± 2.02|Fim do estudo: 0.63 ±<br>1.07<br>DM ± DP: -0.63 ± 1.07|Fim do estudo: 3.97 ±<br>4.53<br>DM ± DP: -1.96 ± 4.33|Fim do estudo: 11.4 ±<br>3.79<br>DM ± DP: -0.98 ± 3.18|
|||Basal, média ± DP: 2.61<br>± 2.18|Basal, média ± DP: 2.67<br>± 2.36|Basal, média ± DP: 5.49<br>± 4.30|Basal, média ± DP: 13.2<br>± 5.29|
||PLAC|Fim do estudo: 2.03 ±|Fim do estudo: 1.65 ±|Fim do estudo: 4.00 ±|Fim do estudo: 11.9 ±|
|||3.24|2.86|4.37|4.70|
|||DM ± DP: -0.58 ± 2.51|DM ± DP: -1.02 ± 2.68|DM ± DP: -1.49 ± 4.84|DM ± DP: -1.28 ± 3.49|
||MIRA 50 mg vs<br>PLAC|∆ (MIRA) - (PLAC): -<br>0.84, p=NS|∆ (MIRA) - (PLAC): -<br>1.15, p=NS|∆ (MIRA) - (PLAC): -<br>0.46, p=NS|∆ (MIRA) - (PLAC): -<br>1.42, p=0,004|
||TOLT 4 mg vs|∆ (TOLT) - (PLAC): -|∆ (TOLT) - (PLAC): -|∆ (TOLT) - (PLAC): -|∆ (TOLT) - (PLAC): -|
||PLAC|0.95, p=NS|0.86, p=NS|0.25, p=NS|0.01, p=NS|  
DARI: darifenacina; MIRA: mirabegron; OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; TROS: trospium; PLAC: placebo; LI: liberação imediata; LP: liberação prolongada; ECR: ensaio clínico randomizado; DM: diferença média; I2: heterogeneidade (I _squared_ ); Δ: diferença entre grupos; IC95%: intervalo de confiança de 95%; NS: não significativo; NR: não reportado.

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 4 – Desfechos secundários de eficácia** -->
48  
|**Autor, ano**|**Grupos comparados**|**Noctúria em 24 horas**|**Volume urinado por micção,**<br>**mL**|**Taxa de cura**|
|---|---|---|---|---|
||MIRA vs SOLI 5 mg|NR|∆ (MIRA) - (SOLI): -11,21<br>(IC95% -17,57; -4,85),<br>p<0,001|NR|
||MIRA vs SOLI 10 mg|NR|∆ (MIRA) - (SOLI): -18,94<br>(IC95% -25,41; -12,48),<br>p<0,001|NR|
|**Obloza et al. 2017 (79)**|MIRA vs TOLT|NR|∆ (MIRA) - (TOLT): -2,34<br>(IC95% -6,39; 1,69), p=NS|NR|
||MIRA vs FESO 4 mg|NR|∆ (MIRA) - (FESO): 4,25<br>(IC95% -5,71; 14,22), p=NS|NR|
||MIRA vs FESO 8 mg|NR|∆ (MIRA) - (FESO): -11,94<br>(IC95% -21,93; -1,95), p=0,02|NR|
|**Owen et al. 2016 (82)**|TOLT+ToxBot|∆ (final) - (basal): -0,43<br>(IC95% -0,87; 0,03), p=NS|NR|NR|
||SOLI vs PLAC|∆ (SOLI) - (PLAC): -0,14<br>(IC95% -0,25; -0,04), p=0,007|∆ (SOLI) - (PLAC): 28,78<br>(IC95% 23,70; 33,86),<br>p<0,0001|NR|
|**Luo et al. 2012 (84)**|SOLI vs TOLT|∆ (SOLI) - (TOLT): -0,07<br>(IC95% -0,10; -0,05),<br>p<0,0001|∆ (SOLI) - (TOLT): 10,86<br>(IC95% 7,38; 14,34),<br>p<0,0001|NR|  
49  
|**Autor, ano**|**Grupos comparados**|**Noctúria em 24 horas**|**Volume urinado por micção,**<br>**mL**|**Taxa de cura**|
|---|---|---|---|---|
||SOLI 5 mg vs SOLI 10<br>mg|∆ (SOLI 5 mg) - (SOLI 10<br>mg): 0,02 (IC95% -0,17; -<br>0,22), p=NS|∆ (SOLI 5 mg) - (SOLI 10<br>mg): -10,41 (IC95% -14,19; -<br>6,62), p<0,0001|NR|
||AntiM vs PLAC|NR|NR|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,82<br>(IC95% 1,62; 2,03),<br>p<0,0001, 10 ECRs, I2: 51%,<br>p=0,03|
|**Madden et al. 2012**<br>**(85)**|OXIB LP vs OXIB LI|NR|NR|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 0,92<br>(IC95% 0,54; 1,56), p=NS, 2<br>ECRs|
||Novos AntiM (SOLI,<br>FESO, TROS) vs<br>antigos AntiM (TOLT,<br>OXIB)|NR|NR|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,28<br>(IC95% 1,12; 1,47), p<0,05, 4<br>ECRs|
|**Herschorn et al. 2017**<br>**(87)**|SOLI+MIRA 25 mg vs<br>MIRA 25 mg|NR|∆ (SOLI+MIRA 25 mg) -<br>(MIRA 25 mg): 21,52 (IC95%<br>15,35; 27,68), p<0,001|NR|  
50  
|**Autor, ano**|**Grupos comparados**|**Noctúria em 24 horas**|**Volume urinado por micção,**<br>**mL**|**Taxa de cura**|
|---|---|---|---|---|
||SOLI+MIRA 50 mg vs<br>MIRA 50 mg|NR|∆ (SOLI+MIRA 50 mg) -<br>(MIRA 50 mg): 17,74 (IC95%<br>11,58; 23,90), p<0,001|NR|
||SOLI 5 mg vs PLAC|NR|p<0,05|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,34<br>(IC95% 0,99; 1,79), p=NS<br>Normalização da frequência<br>de micção: OR: 1,87 (IC95%<br>1,38; 2,54), p<0,001|
||MIRA 25 mg vs PLAC|NR|∆ (MIRA 25 mg) - (PLAC):<br>4,88, p=NS|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,17<br>(IC95% 0,87; 1,57), p=NS<br>Normalização da frequência<br>de micção: OR: 1,66 (IC95%<br>1,22; 2,25), p=0,001|
||MIRA 50 mg vs PLAC|NR|p<0,05|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,40<br>(IC95% 1,04; 1,87), p=0,027<br>Normalização da frequência<br>de micção: OR: 1,67 (IC95%<br>1,23; 2,27), p=0,001|  
51  
|**Autor, ano**|**Grupos comparados**|**Noctúria em 24 horas**|**Volume urinado por micção,**<br>**mL**|**Taxa de cura**|
|---|---|---|---|---|
||SOLI+MIRA 25 mg vs<br>PLAC|NR|p<0,05|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,75<br>(IC95% 1,36; 2,26), p<0,001<br>Normalização da frequência<br>de micção: OR: 2,43 (IC95%<br>1,86; 3,18), p<0,001|
||SOLI+MIRA 50 mg vs<br>PLAC|NR|∆ (SOLI+MIRA 50 mg) -<br>(PLAC): 31,29, p<0,001|Sem episódios de<br>incontinência por 3 dias<br>seguidos no diário: OR: 1,87<br>(IC95% 1,45; 2,42), p<0,001<br>Normalização da frequência<br>de micção: OR: 2,67 (IC95%<br>2,04; 3,49), p<0,001|
||MIRA 50 mg|Basal, média ± DP: 2.32 ±<br>1.38<br>Fim do estudo: 1.82 ± 1.12<br>DM ± DP: -0.50 ± 1.14|Basal, média ± DP: 152 ±<br>54.3<br>Fim do estudo:173 ± 69.7<br>DM ± DP: 22.17 ± 47.8|NR|
|**Kuo et al. 2015 (88)**|TOLT 4 mg|Basal, média ± DP: 2.35 ±<br>1.51<br>Fim do estudo:1.90 ± 1.30<br>DM ± DP: -0.45 ± 1.25|Basal, média ± DP: 148 ±<br>60.7<br>Fim do estudo:161 ± 67.0<br>DM ± DP: 13.30 ± 36.9|NR|
||PLAC|Basal, média ± DP: 2.66 ±<br>1.73|Basal, média ± DP: 150 ±<br>63.4|NR|  
52  
|**Autor, ano**|**Grupos comparados**|**Noctúria em 24 horas**|**Volume urinado por micção,**<br>**mL**|**Taxa de cura**|
|---|---|---|---|---|
|||Fim do estudo: 2.12 ± 1.47<br>DM ± DP: -0.55 ± 1.54|Fim do estudo:156 ± 67.5<br>DM ± DP: 5.54 ± 32.3||
||MIRA 50 mg vs PLAC|∆ (MIRA) - (PLAC): - 0.13<br>(0.18), p=NS|∆ (MIRA) - (PLAC): 16.70<br>(6.69), p=0,013|NR|
||TOLT 4 mg vs PLAC|∆ (TOLT) - (PLAC): - 0.06<br>(0.18), p=NS|∆ (TOLT) - (PLAC): 7.59<br>(6.69), p=NS|NR|  
Legenda: AntiM: antimuscarínicos; CIR: tratamento cirúrgico; DARI: darifenacina; FESO: fesoterodina; MIRA: mirabegron; OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; TROS: trospium; ToxBot: toxina botulínica; PLAC: placebo; LI: liberação imediata; LP: liberação prolongada; OR: razão de chances ( _odds ratio_ ); ECR: ensaio clínico randomizado; I2: heterogeneidade (I _squared_ ); Δ: diferença entre grupos; IC95%: intervalo de confiança de 95%; NS: não significativo; NR: não reportado.  
53

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 5 – Eventos adversos do estudo de Fonseca** **_et al._ 2016 (81)** -->
||||**Fo**|**nseca et al. 2016(**|**81)**|||
|---|---|---|---|---|---|---|---|
|**Evento adverso,**<br>**n (%)**|**OXIB vs.**<br>**TOLT**|**TOLT 1 mg**<br>**vs. PLAC**|**TOLT 2 mg vs.**<br>**PLAC**|**TOLT 4 mg vs.**<br>**PLAC**|**TOLT 2 mg vs.**<br>**TOLT 1 mg**|**TOLT 4 mg**<br>**vs. TOLT 2**<br>**mg**|**SOLI vs.**<br>**PLAC**|
||RR: 0,88<br>(IC95% 0,52;||RR: 1,61<br>(IC95% 1,11;|RR: 1,52<br>(IC95% 1,11;|||RR: 3,06<br>(IC95% 0,62;|
|Constipação|1,49), p=NS, 2<br>ECRs, I2: 0%,<br>p=NS|NR|2,32), p=0,01, 4<br>ECRs, I2: 0%,<br>p=NS|2,09), p=0,009,<br>5 ECRs, I2: 0%,<br>p=NS|NR|NR|15,17), p=NS, 2<br>ECRs, I2: 80%,<br>p=0,03|
|Boca seca|RR: 1,49<br>(IC95% 1,06;<br>2,10), p=0,02,<br>4 ECRs, I2:<br>84%, p=0,0003|RR: 2,33<br>(IC95% 1,26;<br>4,29),<br>p=0,007, 2<br>ECRs, I2: 0%,<br>p=NS|RR: 3,72<br>(IC95% 3,05;<br>4,54), p<0,0001,<br>7 ECRs, I2: 0%,<br>p=NS|RR: 2,88<br>(IC95% 2,40;<br>3,45), p<0,0001,<br>6 ECRs, I2: 0%,<br>p=NS|RR: 1,69<br>(IC95% 1,26;<br>2,28), p=0,0005,<br>3 ECRs, I2: 0%,<br>p=NS|RR: 0,79<br>(IC95% 0,68;<br>0,92),<br>p=0,002, 3<br>ECRs, I2: 0%,<br>p=NS|<br>RR: 3,73<br>(IC95% 1,80;<br>7,72), p=0,0004,<br>2 ECRs, I2:<br>64%, p=NS|
|Descontinuação do||||||||
|tratamento devido a<br>eventos adversos|p=NS|p=NS|p=NS|p=NS|p=NS|p=NS|p=NS|  
Legenda: OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; PLAC: placebo; ECR: ensaio clínico randomizado; I2: heterogeneidade (I _squared_ ); RR: risco relativo; IC95%: intervalo de confiança de 95%; NS: não significativo; NR: não reportado.  
**Tabela 6 – Eventos adversos do estudo de Reynolds** **_et al._ 2015 (83)**  
|**Evento adverso,**<br>**n (%)**|**PLAC**|**OXIB LI**|**OXIB LP**|**Reynolds**<br>**OXIB**<br>**transdérmico**|**et al. 2015(8**<br> <br>**OXIB**<br>**gel**|**3)**<br>**TOLT LI**|**TOLT LP**|**DARI**|**SOLI**|
|---|---|---|---|---|---|---|---|---|---|
|Eventos<br>cardiovasculares|0 - 0,9%<br>(n=3)|0,2 - 1,2%<br>(n=3)|NR|0,8% (n=1)|NR|0% (n=1)|0 - 5% (n=2)|0,5%<br>(n=1)|0,3%<br>(n=1)|  
54  
|**Evento adverso,**<br>||||**Reynolds et**<br>**OXIB**|**al. 2015(8**<br>**OXIB**|**3)**||||
|---|---|---|---|---|---|---|---|---|---|
|**n (%)**|**PLAC**|**OXIB LI**|**OXIB LP**|<br>**transdérmico**|<br>**gel**|**TOLT LI**|**TOLT LP**|**DARI**|**SOLI**|
|Constipação|0 - 7,6%<br>(n=30)|0 - 52%<br>(n=14)|6,4 - 8,6%<br>(n=5)|3,3 - 5,4% (n=2)|<sup>1,3%</sup><br>(n=1)|2,5 - 30%<br>(n=14)|1 - 10,2%<br>(n=14)|18,5 -<br>44%<br>(n=6)|4,3 -<br>45%<br>(n=16)|
|Diarreia|1,2 - 5,4%<br>(n=8)|1 - 5%<br>(n=3)|7,9 - 14%<br>(n=3)|NR|NR|3 - 3,4%<br>(n=2)|1,8 - 6,8%<br>(n=6)|NR|2,1%<br>(n=1)|
|Tontura ou vertigem|0 - 3,8%<br>(n=10)|0 - 38%<br>(n=10)|3,8 - 11%<br>(n=5)|4% (n=1)|1,5%<br>(n=1)|1,7 - 16,7%<br>(n=5)|1,4 - 2,6%<br>(n=7)|0 - 24%<br>(n=2)|1 - 26%<br>(n=6)|
|Boca seca|0 - 21%<br>(n=36)|5,9 - 100%<br>(n=20)|14 - 68% (n=9)|2,6 - 9,6% (n=3)|<sup>6,9%</sup><br>(n=1)|10 - 56,7%<br>(n=17)|7,3 - 39%<br>(n=19)|20,4 -<br>77%<br>(n=6)|6,9 -<br>99%<br>(n=18)|
|Dispepsia|0 - 5% (n=6)|<sup>1,1 - 27%</sup><br>(n=6)|5,3 - 11%<br>(n=3)|NR|NR|1,7 - 9%<br>(n=8)|2,7 - 7% (n=3)|5,2 -<br>8,7%<br>(n=2)|1,3 -<br>4,7%<br>(n=4)|
|Fadiga|0,5 - 2%<br>(n=8)|9 - 15%<br>(n=2)|1,6 - 18%<br>(n=2)|NR|NR|1 - 3,6%<br>(n=2)|2 - 3,8% (n=4)|NR|<1 -<br>1,3%<br>(n=2)|
|Cefaleia|0 - 8%<br>(n=22)|0 - 37%<br>(n=10)|5,6 - 12%<br>(n=6)|NR|1,5%<br>(n=1)|3 - 16,7%<br>(n=11)|1 - 8% (n=14)|3,8 -<br>38%<br>(n=5)|0,8 -<br>28%<br>(n=9)|
|Alteração da micção|0 - 0,9%<br>(n=3)|14 - 29%<br>(n=2)|3,2 - 4% (n=2)|NR|NR|0 - 9%<br>(n=7)|1% (n=1)|NR|2,1 -<br>5,1%<br>(n=3)|
|Insônia|<1 - 2,2%<br>(n=3)|2 - 50%<br>(n=2)|0,5 - 1,8%<br>(n=3)|NR|NR|0,5 - 3,3%<br>(n=5)|0,8 - 1,7%<br>(n=3)|36%<br>(n=1)|0,8 -<br>28%<br>(n=2)|
|Náusea ou vômitos|0 - 11%<br>(n=9)|1,1 - 17%<br>(n=10)|3,2 - 5% (n=3)|4,6% (n=1)|NR|1,6 - 7%<br>(n=6)|0 - 2,7% (n=5)|NR|1 - 5,6%<br>(n=5)|  
55  
|**Evento adverso,**<br>||||**Reynolds et**<br>**OXIB**|**al. 2015(8**<br>**OXIB**|**3)**<br>||||
|---|---|---|---|---|---|---|---|---|---|
|**n (%)**|**PLAC**|**OXIB LI**|**OXIB LP**|<br>**transdérmico**|<br>**gel**|**TOLT LI**|**TOLT LP**|**DARI**|**SOLI**|
|Eventos respiratórios|0 - 14%<br>(n=6)|3 - 13%<br>(n=2)|6% (n=1)|NR|NR|10 - 16%<br>(n=2)|4% (n=1)|0,3 -<br>5,6%<br>(n=2)|1,8 -<br>4,6%<br>(n=4)|
|Sonolência|0 - 2% (n=6)|<sup>3 - 40%</sup><br>(n=4)|1 - 4,3% (n=4)|1,6% (n=1)|NR|1,6 - 16,7%<br>(n=5)|0 - 3% (n=4)|NR|0%<br>(n=1)|
|Infecção do trato<br>urinário|0 - 11%<br>(n=12)|<1 - 18%<br>(n=3)|5,1 - 12%<br>(n=2)|2,4% (n=1)|NR|3 - 19%<br>(n=4)|1 - 4,1% (n=8)|1,1 -<br>4,8%<br>(n=3)|3,4 -<br>15%<br>(n=5)|
|Alterações da visão|0 - 7,7%<br>(n=16)|1,2 - 44%<br>(n=10)|2,2 - 3,3%<br>(n=4)|2,3% (n=1)|NR|0,6 - 13,3%<br>(n=8)|<1 - 6% (n=6)|<sup>0 - 33%</sup><br>(n=3)|0 - 33%<br>(n=16)|
|Qualquer evento<br>adverso|9,3 - 68,3%<br>(n=17)|29,6 - 92%<br>(n=3)|51% (n=1)|NR|56,8%<br>(n=1)|53% (n=1)|9,7 - 74%<br>(n=9)|47,9 -<br>63,6%<br>(n=2)|20,7 -<br>72%<br>(n=8)|
|Descontinuação do<br>tratamento devido a<br>eventos adversos|0 - 6%<br>(n=26)|11,1 - 17%<br>(n=3)|6,2 - 13%<br>(n=4)|10,7% (n=1)|4,9%<br>(n=1)|1,9 - 15%<br>(n=6)|0 - 6,3%<br>(n=10)|3,2 -<br>10,8%<br>(n=2)|3 -<br>10,9%<br>(n=10)|  
Legenda: DARI: darifenacina; OXIB: oxibutinina; SOLI: solifenacina; TOLT: tolterodina; PLAC: placebo; LI: liberação imediata; LP: liberação prolongada; NR: não reportado.  
56  
**Tabela 7 – Eventos adversos dos estudos de Luo** **_et al._ 2012 (84) e Herschorn** **_et al._ 2017 (87)**  
|**Evento adverso,**||**Luo et al. 2012(84)**|**SOLI 5**||**SOLI 5**|**Herschor **<br>**MIRA**|**net al. 2**<br>**MIRA**|**017(87)**<br>**SOLIMIR**|**SOLIMI**|
|---|---|---|---|---|---|---|---|---|---|
||||**m vs.**|||||**+**|**+**|
|**n (%)**|**SOLI vs. PLAC**|**SOLI vs. TOLT**|<br>|**PLAC**||||||
||||**SOLI 10 mg**||**mg**|**25 mg**|**50 mg**|**A 25 mg**|**RA 50 mg**|
|Constipação|OR: 2,87 (IC95%<br>2,10; 3,92),<br>p=0,001|OR: 2,91 (IC95%<br>1,86; 4,56),<br>p<0,0001|OR: 0,64<br>(IC95% 0,34;<br>1,20), p=NS|6<br>(1,4%)|6<br>(1,4%)|11<br>(2,6%)|6<br>(1,4%)|38 (4,5%)|31 (3,7%)|
|Boca seca|OR: 5,57 (IC95%<br>4,24; 7,32),<br>p<0,0001|OR: 1,09 (IC95%<br>0,89; 1,34), p=NS|OR: 0,45<br>(IC95% 0,26;<br>0,76), p=0,003|8<br>(1,9%)|17<br>(4,0%)|14<br>(3,3%)|25<br>(5,9%)|74 (8,7%)|61 (7,2%)|
|Alterações da visão|OR: 2,15 (IC95%<br>1,36; 3,41),<br>p=0,001|OR: 3,19 (IC95%<br>1,14; 8,95),<br>p=0,03)|OR: 0,65<br>(IC95% 0,43;<br>1,00), p=NS)|3<br>(0,7%)|1<br>(0,2%)|0|2<br>(0,5%)|5 (0,6%)|6 (0,7%)|
|Infecção Trato<br>urinario|NR|NR|NR|21<br>(4,9%)|18<br>(4,3%)|16<br>(3,8%)|21<br>(5,0%)|60 (7,0%)|44 (5,2%)|
|Retenção urinaria|NR|NR|NR|0|0|0|3<br>(0,7%)<br>|8 (0,9%)|10 (1,2%)|
|Retenção urinaria|NR|NR|NR|0|0|0|1<br>(0,2%)|4 (0,5%)|5 (0,6%)|
|Retenção urinaria<br>aguda|NR|NR|NR|0|0|0|0|0|1 (0,1%)|
|Volume urinario<br>residual aumentado|NR|NR|NR|0|0|0|0|3 (0,4%)|3 (0,4%)|
|urina residual|NR|NR|NR|0|0|0|0|1(0,1%)|0|
|Esvaziamento<br>incompleto da bexiga|NR|NR|NR|0|0|0|1<br>(0,2%)|1 (0,1%)|0|
|Hipersensibilidade|NR|NR|NR|4<br>(0,9%)|4<br>(0,9%)|4<br>(0,9%)|3<br>(0,7%)|9 (1,1%)|4 (0,5%)|  
57  
|**Evento adverso,**||**Luo et al. 2012(84)**||||**Herschor **<br>|**net al. 2**<br>|**017(87)**<br>||
|---|---|---|---|---|---|---|---|---|---|
||||**SOLI 5 m vs**||**SOLI 5**|**MIRA**|**MIRA**|**SOLI+MIR**|**SOLI+MI**|
|**n (%)**|**SOLI vs PLAC**|**SOLI vs TOLT**|**g .**<br>|**PLAC**||<br>|<br>|||
||**.**|**.**|**SOLI 10 mg**||**mg**<br>|**25 mg**|**50 mg**|**A 25 mg**|**RA 50 mg**|
|Glaucoma|NR|NR|NR|0|1<br>(0,2%)|0|0|1 (0,1%)|1 (0,1%)|
|Sonolência|NR|NR|NR|11<br>(2,6%)|11<br>(2,6%)|15<br>(3,6%)|12<br>(2,8%)|29 (3,4%)|13 (1,5%)|
|Dispepsia|NR|NR|NR|3<br>(0,7%)|1<br>(0,2%)|1<br>(0,2%)|1<br>(0,2%)|10 (1,2%)|16 (1,9%)|
|Qualquer evento<br>adverso|NR|SOLI: 10,14%<br>TOLT: 7,74%<br>OR: 1,46 (IC95%<br>0,81; 2,61), p=NS|SOLI 5 mg:<br>6,65%<br>SOLI 10 mg:<br>6,27%<br>OR: 1,07<br>(IC95% 0,53;<br>2,15), p=NS|145<br>(33,8%)|135<br>(31,9%)|147<br>(34,8%)|149<br>(35,2%)|<sup>345 (40,4%)</sup>|<sup>314 (37,0%)</sup>|
|Evento adverso<br>relacionado ao<br>medicamento|NR|NR|NR|45<br>(10,5%)|37<br>(8,7%)|52<br>(12,3%)|63<br>(14,9%)|<sup>157 (18,4%)</sup>|<sup>150 (17,7%)</sup>|
|Evento adverso grave|NR|NR|NR|8<br>(1,9%)|6<br>(1,4%)|5<br>(1,2%)|3<br>(0,7%)|12 (1,4%)|19 (2,2%)|
|Evento adverso grave<br>relacionado ao<br>medicamento|NR|NR|NR|0|1<br>(0,2%)|1<br>(0,2%)|0|2 (0,2%)|3 (0,4%)|
|Descontinuação do<br>tratamento devido a<br>eventos adversos|NR|NR|NR|9<br>(2,1%)|7<br>(1,7%)|10<br>(2,4%)|7<br>(1,7%)|20 (2,3%)|22 (2,6%)|
|Descontinuação do<br>tratamento devido a<br>eventos adversos|NR|NR|NR|7<br>(1,6%)|4<br>(0,9%)|6<br>(1,4%)|5<br>(1,2%)|17 (2,0%)|19 (2,2%)|  
58  
|**Evento adverso,**<br>**n (%)**|**SOLI vs. PLAC**|**Luo et al. 2012(84)**<br>**SOLI vs. TOLT**|**SOLI 5 mg vs.**<br>**SOLI 10 mg**|**PLAC**<br>**SOLI 5**<br>**mg**|**Herschor **<br>**MIRA**<br>**25 mg**|**net al. 2**<br>**MIRA**<br>**50 mg**|**017(87)**<br>**SOLI+MIR**<br>**A 25 mg**|**SOLI+MI**<br>**RA 50 mg**|
|---|---|---|---|---|---|---|---|---|
|relacionados ao<br>medicamento|||||||||  
Legenda: SOLI: solifenacina; TOLT: tolterodina; PLAC: placebo; OR: razão de chances ( _odds ratio_ ); IC95%: intervalo de confiança de 95%; NS: não significativo; NR: não reportado.  
**Tabela 8 – Eventos adversos do estudo de Kuo** **_et al._ 2015 (88)**  
|**Eventos adversos,**||**Kuo et al. 2015(88)**||
|---|---|---|---|
|**n (%)**|MIRA 50mg|TOLT 4mg|PLAC|
|EAET|36(42,4%)|40(49,4%)|33(42,9%)|
|EAET Sérios|1(1,3%)|0|0|
|EAET relacionados aos medicamentos|20(23,5%)|24(29,6%)|19(24,7%)|
|EAET sérios relacionados aos medicamentos|0|0|0|
|Hipertensão|2(2,4%)|1(1,2%)|0|
|EAET- Cardiovasculares|6|9|10|
|Retenção urinária|0|0|0|
|Boca seca|3(3,9%)|6(7,1%)|7(8,6%)|
|Descontinuação devido a EAET|2(2,4%)|1(1,2%)|1(1,3%)|
|Descontinuação devido a EAET relacionados aos medicamentos|1(1,2%)|0|1(1,3%)|
|Morte devido ao EA|1(1,3%)|0|0|  
59  
Legenda: MIRA: mirabegron; TOLT: tolterodina; PLAC: placebo; EAET: eventos adversos emergentes do tratamento.  
60  
**<mark>Questão de Pesquisa 5:</mark>** <mark>Qual a eficácia e segurança da Mirabegrona para o tratamento da incontinência urinária de urgência?</mark>

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **MEDLINE via Pubmed:** -->
<mark>(((((((("Urinary Bladder, Overactive"[Mesh]) OR Urinary Bladder, Overactive) OR Overactive Bladder) OR Overactive Urinary Bladder) OR Bladder, Overactive)) OR (((((((("Urinary Incontinence, Urge"[Mesh]) OR Urinary Reflex Incontinence) OR Incontinence, Urinary Reflex) OR Urinary Urge Incontinence) OR Urge Incontinence) OR Incontinence, Urge)) OR Urinary Incontinence, Urge))) AND (((((((("mirabegron"[Supplementary Concept]) OR Betmiga) OR 2- AND (2aminothiazol-4-yl) AND -4'- AND (2- AND ((2-hydroxy-2-phenylethyl) AND amino) AND ethyl) AND acetanilide) OR Betanis) OR YM 178) OR YM-178)) OR mirabegron) AND Humans[Mesh]</mark>  
Data: 26/09/2017  
Total: 169

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **EMBASE:** -->
"(mirabegron OR 'mirabegron'/exp OR betmiga OR (ym AND 178) OR 'ym 178' OR betanis) AND ('urge incontinence'/exp OR (urinary AND incontinence, AND urge) OR (urinary AND reflex AND incontinence) OR 'urge incontinence' OR (incontinence, AND urinary AND reflex) OR 'overactive bladder'/exp OR 'overactive bladder' OR (urinary AND bladder, AND overactive) OR (overactive AND urinary AND bladder)) AND [embase]/lim AND [humans]/lim"  
Data: 26/09/2017  
Total: 675

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **5) Seleção das evidências** -->
A busca das evidências resultou em 844 referências (169 no MEDLINE e 675 no EMBASE). Destas, 166 foram excluídas por estarem duplicadas. Seiscentos e sessenta e oito referências foram triadas por meio da leitura de título e resumos, das quais noventa  
61  
e duas referências tiveram seus textos completos avaliados para confirmação da elegibilidade.  
Como critério de inclusão, foram priorizadas revisões sistemáticas com meta- análise de ensaios clínicos randomizados e estudos primários do tipo ensaios clínicos randomizados comparativos. Foram incluídos ensaios clínicos randomizados que não estavam presentes nas revisões sistemáticas. Os estudos incluídos em revisões sistemáticas, que realizaram estratificação por população com incontinência foram incluídos, pois as revisões sistemáticas não contemplaram essa população. Somente resumos de congressos de revisões sistemáticas com meta-análise que fornecessem as referências dos estudos incluídosforam considerados.  
No total, 70 estudos foram excluídos. Quinze revisões foram excluídas: 1) seis eram revisões narrativas; 2) três não apresentaram meta-análise; 3) uma revisão sistemática de qualquer tipo de estudo; 4) um resumo não contemplava a população de interesse; 5) quatro resumos não apresentaram as referências dos estudos analisados. Em relação aos ensaios clínicoscompletos ou em formato de resumo, 40 foram excluídos: 1) sete haviam sido incluídos nas revisões sistemáticas; 2) cinco análises combinadas “ _pooled_ ” cujos artigos analisados estavam presentes nas revisões sistemáticas incluídas; 3) três ensaios clínicos eram análises exploratórias de estudos incluídos; 4) um estudo era não comparativo; 5) dois artigos apresentaram dados que não foram passíveis de serem coletados; 6) dois estudos não compreendiam população de interesse; 7) dois estudos analisavam medicamentos que não são registrados no Brasil; 8) um estudo não analisou o objetivo de interesse; 9) 11 resumos pois havia o estudo original disponível; 10) três resumos apresentaram informações insuficientes ou não relevantes; 12) em dois resumos a população não era de interesse; 11) um estudo era experimental série de casos. Quinze estudos observacionais foram excluídos.  
No total 22 referências (79, 80, 87-106) foram incluídas: 1) Duas revisões sistemáticas com meta-análises de comparações diretas completas (89, 90); 2) Uma revisão sistemáticade comparações diretas apresentada por 2 resumos de congresso (80, 91); 3) Quatrorevisões sistemáticas com meta-análise em rede (79, 95-97). 5) Três análises combinadas de ensaios clínicos randomizados, dois ECR originais (92, 93) e o outro ECR em forma de resumo de congresso (94); 6) Oito ensaios clínicos randomizados de 11  
62  
referências (87, 88, 98-106). Entre esses, um foi apresentado apenas em formato de resumo de congresso (87).

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6)** **<mark>Descrição dos estudos e seus resultados</mark>** -->
<mark>Os estudos incluídos serão apresentados de acordo com o grupo de comparações. Primeiramente serão descritas as características dos estudos, seguidas das características dos participantes, dos desfechos de eficácia e, por fim, dos desfechos de segurança. A descrição sumária dos estudos que abordaram as comparações Mirabegrona</mark> _<mark>versus</mark>_ <mark>placebo ou onabotulinumtoxina ou antimuscarínicos encontram-se nas</mark> **<mark>tabelas 9-15</mark>** <mark>. Os estudos que analisaram essas comparações estratificadas por sexo encontram-se nas</mark> **<mark>tabelas 16-19</mark>** <mark>. As comparações do Mirabegrona e Solifenacina em monoterapia ou em combinação</mark> _<mark>versus</mark>_ <mark>Placebo, Mirabegrona ou Solifenacina estão apresentados nas</mark> **<mark>tabelas 20-25</mark>** <mark>.</mark>  
63

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.1 Mirabegrona** **_versus_ Placebo ou Onabotulinumtoxina ou Antimuscarínicos** -->
**Tabela 9 – Características dos estudos que compararam Mirabegrona** **_versus_ Placebo ou ou onabotulinumtoxina ou antimuscarínicos.**  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Wu et al.**<br>**2014(89)**|Revisão<br>sistemática com<br>meta-análise de<br>ECR<br>(última atualização<br>julho de 2013)|Avaliar a<br>eficácia e<br>segurança do<br>MIRA para BH|Diagnóstico de<br>BH; FMM≥8<br>vezes em 24h;<br>EPU≥3 com ou<br>sem IU.|6 ECR<br>MIRA vs.<br>Placebo: 5 ECR<br>MIRA vs. TOL:<br>4 ECR|MIRA|Placebo ou TOL|Alto Risco de Viés<br>Não foi realizada<br>busca na literatura<br>cinzenta. A lista de<br>excluídos não foi<br>fornecida. Não foi<br>analisado o<br>impacto dos<br>estudos primários<br>de acordo com a<br>qualidade da<br>evidência na meta-<br>análise. Viés de<br>publicação não foi<br>analisado.<br>Qualidade dos<br>estudos primários:<br>moderada a alta|  
64  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Cui et al.**<br>**2013(90)**|Revisão<br>sistemática com<br>meta-análise de<br>ECR de fase III<br>(última atualização<br>outubro de 2013)|Avaliar a<br>eficácia e<br>segurança do<br>MIRA para BH|Pacientes com<br>BH|4 ECR de fase<br>III; 3524<br>participantes|MIRA 50 mg oral|Placebo|Alto Risco de Viés<br>Não foi reportado<br>se a seleção dos<br>artigos e a<br>extração dos dados<br>foi feita por uma<br>dupla de revisores.<br>A lista de<br>excluídos não foi<br>fornecida; não foi<br>realizada busca na<br>literatura cinzenta<br>(estudos não<br>publicados).|
|**Drake et al.**<br>**2017(95)**|Revisão<br>sistemática com<br>meta-análise em<br>rede de ECR<br>(última atualização<br>julho de 2013)|Comparar a<br>eficácia do<br>Botox, MIRA e<br>anticolinérgicos<br>em adultos com<br>BH idiopática|Adultos com<br>BH idiopática<br>com ou sem<br>IU;<br>hiperatividade<br>do detrusor<br>refratário; IU<br>idiopática ou<br>não<br>neurogênica e<br>IU|56 ECR<br>10 analisaram<br>Botox<br>10<br>analisaramMIRA<br>Obs: foram<br>utilizados dados<br>somente que<br>analisaram o<br>MIRA|MIRA 25 e 50mg<br>MIRA 25 e 50mg|Placebo<br>Botox|Risco de viés<br>incerto<br>Comparações<br>indiretas;<br>estratégia de busca<br>não foi totalmente<br>adequada pois<br>utilizou estratégias<br>de busca<br>previamente<br>publicadas.<br>Limitação de|  
65  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||predominante<br>de urgência||||idioma. De acordo<br>com ROB, 22<br>estudos<br>apresentaram alto<br>risco de viés; 26<br>apresentaram<br>algum risco e 8<br>estudos o risco de|
||||||||viés não está claro.|
||||Adultos||||Alto risco de viés<br>Comparações<br>indiretas;os<br>detalhes dos|
|**Obloza et al.**<br>**2017(79)**|Revisão<br>sistemática com<br>meta-análise em<br>rede de ECR<br>(última atualização<br>NR)|Comparar a<br>efetividade de<br>terapias para BH<br>usando modelo<br>de comparação<br>indireta de<br>Bucher|diagnosticados<br>com sintomas<br>de BH<br>idiopática<br>(sintomas por ><br>3 meses;FMM<br>≥8 vezes em<br>24h; EPU ≥3.|25 ECR|Anticolinérgicos<br>orais/transdérmicos<br>BOTOX|MIRA|artigos incluídos e<br>a lista de artigos<br>excluídos não<br>foram fornecidos.<br>A heterogeneidade<br>entre os estudos<br>não foi avaliada.<br>Risco de viés dos<br>artigos incluídos<br>foi considerado<br>baixo.|  
66  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Freemantle**<br>**et al.**<br>**2016(97)**|Revisão<br>sistemática com<br>meta-análise em<br>rede de ECR<br>(última atualização<br>agosto de 2013)|Avaliar a<br>eficácia clínica<br>de doses de<br>BOTOX de<br>100U<br>comparado com<br>MIRA 25 ou<br>100mg em<br>adultos com BH<br>via comparação<br>indireta|Adultos com<br>BH idiopática<br>com ou sem<br>IU;<br>hiperatividade<br>do detrusor<br>refratário; IU<br>urgência<br>idiopática ou<br>não<br>neurogênica|19 ECR<br>11 analisaram<br>BOTOX<br>8 analisaram<br>MIRA|BOTOX|MIRA 25 ou 50<br>mg|Alto risco de viés<br>Comparações<br>indiretas;<br>estratégia de busca<br>não foi totalmente<br>adequada pois<br>utilizou estratégias<br>de busca<br>previamente<br>publicadas.<br>Limitação de<br>idioma. Não<br>utilizou uma<br>ferramenta<br>adequada para<br>avaliação do risco<br>de viés. Pode ter<br>viés depublicação|
|**Maman et**<br>**al. 2014(96)**|Revisão<br>sistemática com<br>meta-análise em<br>rede de ECR<br>(última atualização<br>agosto de 2013)|Analisar a<br>eficácia e<br>tolerabilidade do<br>MIRA 50 mg<br>versus<br>antimuscarínicos|Adultos com<br>diagnóstico de<br>BH.<br>Hiperatividade<br>do detrusor.<br>Urgência<br>urinária|44 ECR, 27309<br>participantes|MIRA 50 mg<br>ou<br>antimuscarínicos|Antimuscarínicos<br>placebo|<br>Alto risco de viés<br>Comparações<br>indiretas; não foi<br>reportado a análise<br>da<br>heterogeneidade<br>entre os estudos; A<br>maioria dos artigos|  
67  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||||||incluídos<br>apresentaram alto<br>risco de viés|
|**Salvi et al.**<br>**2017;**<br>**Sebastianelli**<br>**et al. 2017**<br>**(80, 91)**|2 resumos de<br>congresso: revisão<br>sistemática com<br>meta-análise de<br>ECR|Analisar a<br>eficácia,<br>segurança e<br>tolerabilidade do<br>MIRA 50 mg,<br>MIRA 100mg e<br>TOL|BH e sintomas<br>do trato<br>urinário<br>inferior<br>armazenamento|8 ECR, 10239<br>participantes|MIRA 50 mg<br>MIRA 100mg<br>TOL 4mg|Placebo<br>TOL 4mg<br>MIRA 100mg|Alto risco de viés<br>Resumo de<br>congresso não<br>contém todas as<br>informações<br>relevantes para<br>julgamento|
|**Chapple et**<br>**al. 2015(92)**<br>**(análise**<br>**exploratória)**|Observacional:<br>análise<br>exploratória de 3<br>ECR|Conduzir uma<br>análise post hoc<br>para determinar<br>o efeito do<br>MIRA 50 mg<br>versus placebo<br>nos desfechos<br>miccionais em<br>subgrupos de<br>população<br>incontinente na<br>linha de base|Pacientes com<br>BH que<br>receberam ≥ 1<br>doses; ≥1 EIU<br>Estratificados<br>por:<br>1. PIU (≥ 1<br>EIU na linha de<br>base)<br>2. PIU≥ 2: ≥ 2<br>EIU na linha de<br>base<br> 3.PIU≥4:4≥|MIRA: 862<br>Placebo: 878|MIRA|Placebo|Alto risco de viés<br>Combinação de<br>ECR, perda do<br>efeito da<br>randomização; não<br>há análises da<br>heterogeneidade;<br>não forneceu as<br>características<br>basais<br>estratificados pelos<br>subgrupos<br>analisados|  
68  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||EIU na linha de<br>base|||||  
|**Yamaguchi**<br>**et al.**<br>**2015(98)**|ECR,multicêntrico,<br>duplo-cego,<br>placebo-<br>controlado, grupo-<br>paralelo,<br>NCT00527033|Analisar a<br>eficácia e<br>segurança<br>MIRA<br>comparado com<br>placebo e avaliar<br>a dose-reposta<br>do MIRA|Adultos com<br>sintomas de<br>BH por ≥24<br>semanas;<br>FMM≥8 vezes<br>em 24h;<br>EPU≥1 ou<br>episódios de<br>IUU≥1/24H|Total: 842<br>randomizados<br>PR<br>MIRA 25 mg:<br>211<br>MIRA 50 mg:<br>208<br>MIRA 100 mg:<br>209<br>Placebo:214|MIRA 25 mg<br>MIRA 50 mg<br>MIRA 100 mg|Placebo|Alto risco de viés<br>Não foi descrito o<br>método de<br>randomização e<br>sigilo de alocação.<br>Não houve<br>cegamento dos<br>avaliadores dos<br>desfechos.|
|---|---|---|---|---|---|---|---|
|**Kuo et al.**<br>**2015(88)**|ECR,multicêntrico,<br>duplo-cego,<br>placebo-<br>controlado, ativo-<br>controlado, grupo-<br>paralelo<br>Study 178-CL-045|Analisar a<br>eficácia e<br>segurança<br>MIRA<br>comparado com<br>placebo|Adultos com<br>sintomas de<br>BH por > 3<br>meses|Total: 248<br>randomizados e<br>218 analisado<br>PR/PTA<br>MIRA 50 mg:<br>85/76<br>TOL 4 mg: 82/74<br>Placebo: 81/68|MIRA 50 mg<br>TOL LP 4mg|Placebo|Risco de viés<br>incerto<br>A análise não foi<br>por intenção de<br>tratar (i.e., não<br>foram analisados<br>todos os pacientes<br>que foram<br>randomizados).|  
69  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Khullar et**<br>**al. 2015;**<br>**Khullar et**<br>**al. 2013(99,**<br>**100)**|ECR,<br>multinacional,<br>multicêntrico,<br>duplo-cego,<br>placebo-<br>controlado, ativo-<br>controlado, grupo-<br>paralelo fase III<br>SCORPIO|Analisar a<br>eficácia,<br>segurança,<br>tolerabilidade e<br>desfechos<br>relatados<br>pelospacientes<br>com BH|Adultos com<br>sintomas de<br>BH por ≥3<br>meses; FMM≥8<br>vezes em 24h;<br>EPU≥3<br>episódios com<br>ou sem IU|Total: 1987<br>randomizados e<br>1906 analisados<br>PR/ PTA/ PIU<br>MIRA 100 mg:<br>498/ 478/281<br>MIRA 50 mg:<br>497/473/293<br>TOL 4 mg:<br>495/475/300<br>Placebo:<br>497/480/291|MIRA 100 mg<br>MIRA 50 mg<br>TOL LP 4 mg|Placebo|Risco de viés<br>incerto<br>A análise não foi<br>por intenção de<br>tratar (i.e., não<br>foram analisados<br>todos os pacientes<br>que foram<br>randomizados).|
|**Herschorn et**<br>**al. 2013(101)**|ECR,<br>multinacional,<br>multicêntrico,<br>duplo-cego,<br>placebo-<br>controlado, grupo-<br>paralelo fase III|Analisar a<br>eficácia e<br>tolerabilidade do<br>MIRA 25 e 50<br>mg uma vez ao<br>dia versus<br>placebo|Adultos com<br>sintomas de<br>BH por ≥3<br>meses; FMM≥8<br>vezes em 24h;<br>EPU≥3<br>episódios com<br>ou sem IU|Total: 1315<br>foram<br>randomizados<br>PR/ PTA /PIU<br>MIRA 50 mg:<br>440/426/ 257<br>MIRA 25 mg:<br>432/410/ 254<br>Placebo:433/<br>NR/ NR|MIRA 50 mg<br>MIRA 25 mg|Placebo|Alto risco de viés<br>Não foi descrito o<br>método de<br>randomização e<br>sigilo de alocação.<br>Não houve<br>cegamento dos<br>avaliadores dos<br>desfechos. A<br>análise não foi por<br>intenção de tratar<br>(ie., não foi<br>analisado todos os|  
70  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
||||||||pacientes que<br>foram<br>randomizados).<br>Desfechos<br>incompletos<br>(perdas<br>significativas).<br>Não forneceu os<br>resultados do<br>placebo.|  
MIRA: mirabegrona; TOL: tolterodina; LP: liberação prolongada; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; FMM: frequência média de micção; EPU: episódio de urgência; IU: incontinência urinária; IUU: incontinência urinária de urgência; PR: população que foi inicialmente randomizada; PTA: população total analisada; PIU: população com incontinência urinária.  
71  
**Tabela 10 – Características dos participantes dos estudos que compararam Mirabegrona versus Placebo ou ou onabotulinumtoxina ou antimuscarínicos.**  
|**Autor, ano**<br>**Wu et al.**|**Intervenção,**<br>**PTA (n)**<br>|**Controle,**<br>**PTA (n)**<br>|<br>**Idade**<br>**Intervenção**<br>**Média (DP):**<br>**Revisões Siste**<br>|<br>**Idade**<br>**Controle**<br>**Média**<br>**(DP):**<br>**máticas co**<br>|**n (%)sexo**<br>**masculino**<br>**Intervenção**<br>**m Meta-análi**<br>|<br>**n (%) sexo**<br>**masculino**<br>**Controle**<br>**ses de compa**<br>|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**<br>**rações diretas**<br>|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**<br>|**Período de**<br>**estudo**<br>|
|---|---|---|---|---|---|---|---|---|---|
|<br>**2014(89)**|NA|NA|NR|NR|NR|NR|NR|NR|12 semanas|
|**Cui et al.**<br>**2013(90)**|NA|NA|NR|NR|NR|NR|NR|NR|12 semanas|
||||**Revisões Sistem**|**áticas com**|**Meta-anális**|**es de compar**|**ações indiretas**|||
|**Drake et al.**<br>**2017(95)**|NA|NA|NR|NR|NR|NR|Número médio de<br>Número médio de<br>urgência<br>Número médio de<br>de micçõe|3.2 EIU por dia<br>7.6 episódios de<br>por dia<br>11.7 episódios<br>spor dia|12 semanas|
|**Obloza et al.**<br>**2017(79)**|<br>NA|NA|NR|NR|NR|NR|NR|NR|NR|
||||||||Número médio d|e 3.48 EIU por||
|**Freemantle**<br>**et al.**<br>**2016(97)**|NA|NA|NR|NR|Min-<br>max.:55.4-<br>100%|Min-<br>max.:68.7-<br>89.3%|di<br>Número médio de<br>de urgênci|a<br>6.32 episódios<br>a por dia|12 semanas (min-<br>max.: 2-24<br>semanas)|
|**Maman et**<br>**al. 2014(96)**|NA|NA|NR|NR|NR|NR|NR|NR|12 semanas (min-<br>max.: 4-16<br>semanas)|  
72  
|**Autor, ano**|**Intervenção,**<br>**PTA (n)**|**Controle,**<br>**PTA (n)**|<br>**Idade**<br>**Intervenção**<br>**Média (DP):**|<br>**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
|||||**Ensaios**|**Clínicos Rand**|**omizados**||||
|**Salvi et al.**<br>**2017;**||||||||||
|**Sebastianelli**<br>**et al. 2017**<br>**(80, 91)**|<br>NA|NA|NR|NR|NR|NR|NR|NR|NR|
|**Chapple et**<br>**al. 2015(92)**|MIRA<br>(PIU: 862;<br>PIU≥ 2: 449;<br>PIU≥ 4: 198)|Placebo<br>(PIU:<br>878;<br>PIU≥ 2:<br>457;<br>PIU≥ 4:|NR|NR|NR|NR|NR|NR|12 semanas|
|||194)||||||||
||MIRA 25<br>mg (211)||54,9 (13,59)||41 (19,6)||População BH<br>IUU, n (%)<br>125 (59,8)||14 semanas: 2<br>|
|**Yamaguchi**<br>**et al.**<br>**2015(98)**|MIRA 50mg<br>(208)<br>MIRA 100<br>mg (209)|Placebo<br>(214)|56,2 (13,59)<br>56,9 (13,29)|55,7<br>(12,89)|31 (14,9)<br>35 (16,9)|42 (19,9)|População BH<br>IUU, n (%)<br>115 (55,3)<br>População BH<br>IUU, n (%)<br>127(61,4)|População BH<br>IUU, n (%)<br>126 (59,7)|semanas de<br>período de<br>eliminação e 12<br>semanas de<br>tratamento|
|**Kuo et al,**<br>**2015(88)**|MIRA 50mg<br>(76)|Placebo<br>(68)|59,0 (15,1)|58,4<br>(13,0)|29 (38,2)|26 (38,2)|População BH<br>IUU, n (%)<br>40 (52,6)|População BH<br>IUU, n (%)<br>38 (55,9)|14 semanas: 2<br>semanas de<br>período de|  
73  
|**Autor, ano**|**Intervenção,**<br>**PTA (n)**|**Controle,**<br>**PTA (n)**|**Idade**<br>**Intervenção**<br>**Média (DP):**|**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%) sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
||TOL 4mg<br>(74)||56,4 (15,8)||30 (40,5)||População BH<br>IUU, n (%)<br>42(56,8)||eliminação e 12<br>semanas de<br>tratamento|
|**Khullar et**|MIRA 100<br>mg (496)||59,1 (12,36)||141 (28,4)||População BH<br>IUU, n (%)<br>PTA: 179 (37,4)|||
|**al, 2015;**|||||||PIUU: 140 (49,8)|População BH|14 semanas: 2|
|**Khullar et**|||||||População BH|IUU, n (%)|semanas de|
|**al, 2013 (99,**<br>**100)**|MIRA 50<br>mg (493)|Placebo<br>(494)|59,1 (12,36)|59,2<br>(12,30)|136 (27,6)|138 (27,9)|IUU, n (%)<br>PTA: 192 (40,6)<br>PIUU: 143 (48,8)<br>População BH|PTA: 201<br>(41,9)<br>PIUU: 156<br>(53,6)|período de<br>eliminação e 12<br>semanas de<br>tratamento|
|**SCORPIO**|TOL 4 mg<br>(495)||59,1 (12,89)||134 (27,1)||IUU, n (%)<br>PTA: 184 (38,7)<br>PIUU:142(47,3)|||
|**Herschorn**<br>**et al,**<br>**2013(101)**|MIRA 50<br>mg (440)<br>MIRA 25<br>mg (432)|Placebo<br>(433)|60,3 (12,22)<br>58,5 (12,85)|58,2<br>(13,73)|137 (31,1)<br>139 (32,2)|132 (30,5)|Disponível na<br>desfechos d|planilha dos<br>e eficácia|14 semanas: 2<br>semanas de<br>período de<br>eliminação e 12<br>semanas de<br>tratamento|  
MIRA: mirabegrona; SOLI: solifenacina; TOL: tolterodina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; IU: incontinência urinária; IUU: incontinência urinária de urgência; PTA: população total analisada; PIU: população com incontinência urinária,PIUU: população com incontinência urinária de urgência,  
74  
**Tabela 11 – Desfechos de eficácia dos estudos que compararam Mirabegrona** **_versus_ Placebo ou onabotulinumtoxina ou antimuscarínicos.**  
|**Autor, ano**<br>|**Grupos**<br>MIRA total<br>vs, Placebo|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**<br>**Revisõe**<br>DM: –0,54 (IC<br>95%: –0,63, –<br>0,45); I2: 0%<br>(p:0,44); 5 ECR; n<br>MIRA: 2215; n<br>placebo: 2713|**Valor p**<br>**s Sistemát**<br><<br>0,00001|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**<br>**icas com Meta-anál**<br>DM: –0,55 (IC<br>95%: –0,63, –<br>0,47); I2: 19%<br>(p:0,27); 5 ECR; n<br>MIRA: 3229; n<br>placebo:3294|**Valor p**<br>**ises de co**<br><<br>0,00001|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**<br>**mparações diretas**<br>NR|**Valor p**<br>NR|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**<br>NR|**Valor p**<br>NR|
|---|---|---|---|---|---|---|---|---|---|
|**Wu et al,**<br>**2014(89)**<br>**RS com**<br>**meta-análise**<br>**de ECR**|MIRA<br>25mg vs,<br>Placebo|DM: –0,66 (IC<br>95%: –0,91, –<br>0,40); I2: 61%<br>(p:0,11); 2 ECR; n<br>MIRA: 353; n<br>placebo: 539|<<br>0,00001|DM: –0,44 (IC<br>95%: –0,58, –<br>0,31); I2: 0%<br>(p:0,88); 2 ECR; n<br>MIRA: 577; n<br>placebo:599|<<br>0,00001|NR|NR|NR|NR|
||MIRA 50<br>mg vs,<br>Placebo|DM: –0,53 (IC<br>95%: –0,66, –<br>0,40); I2: 0%<br>(p:0,40); 4 ECR; n|<<br>0,00001|DM: –0,59 (IC<br>95%: –0,73, –<br>0,45); I2: 0%<br>(p:0,75); 4 ECR; n|<<br>0,00001|NR|NR|NR|NR|  
75  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||MIRA: 1100; n<br>placebo: 1283||MIRA: 1508; n<br>placebo:1532||||||
||MIRA 100<br>mg vs,<br>Placebo|DM: –0,51 (IC<br>95%: –0,67, –<br>0,36); I2: 0%<br>(p:0,47); 4 ECR; n<br>MIRA: 762; n<br>placebo: 891|<<br>0,00001|DM: –0,65 (IC<br>95%: –0,81, –<br>0,49); I2: 49%<br>(p:0,12); 4 ECR; n<br>MIRA: 1144; n<br>placebo:1163|<<br>0,00001|NR|NR|NR|NR|
||MIRA total<br>vs, TOL<br>4mg|DM: –0,25 (IC<br>95%: –0,43, –<br>0,06); I2: 97% (p<<br>0,00001); 4 ECR;<br>n MIRA: 2321; n<br>TOL: 2329|0,009|DM: –0,17 (IC<br>95%: –0,35, 0,01);<br>I2: 85%<br>(p<0,00001); 4<br>ECR; n MIRA:<br>2942;n TOL:2765|0,07|NR|NR|NR|NR|
||MIRA 50<br>mg vs, TOL<br>4 mg|DM: –0,23 (IC<br>95%: –0,50, 0,03);<br>I2: 99% (p<<br>0,00001); 3 ECR;<br>n MIRA: 1190; n<br>TOL: 1144|0,09|DM: –0,07 (IC<br>95%: –0,37, 0,23);<br>I2: 80% (p: 0,006);<br>3 ECR; n MIRA:<br>1429; n TOL:1351|0,63|NR|NR|NR|NR|
||MIRA 100<br>mg vs, TOL<br>4 mg|DM: –0,23 (IC<br>95%: –0,34, –<br>0,12); I2: 0%<br>(p:0,87);4 ECR;n|<<br>0,00001|DM: –0,23 (IC<br>95%: –0,40, –<br>0,06); I2: 41% (p:<br>0,16);4 ECR;n|0,008|NR|NR|NR|NR|  
76  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||MIRA: 1131; n<br>TOL: 1185||MIRA: 1513; n<br>TOL:1414||||||
|**Cui et al,**<br>**2013 (90)**|MIRA 50<br>mg vs,<br>Placebo|DM: –0,44 (IC<br>95%: –0,59, –<br>0,29); I2: 0%<br>(p:0,90); 4 ECR; n<br>MIRA: 1242; n<br>placebo: 1259|<<br>0,00001|DM: –0,62 (IC<br>95%: –0,80, –<br>0,45); I2: 0%<br>(p:0,56); 4 ECR; n<br>MIRA: 1704; n<br>placebo: 1709|<<br>0,00001|DM: –0,60 (IC<br>95%: –0,85, –0,36);<br>I2: 0% (p:0,68); 3<br>ECR; n MIRA:<br>1274; n placebo:<br>1293|<<br>0,00001|NR|NR|
|||<br>**Revisões**|**Sistemáti**|<br>**cas com Meta-análi**|**ses de com**|<br> **parações indiretas**||||
||MIRA 50<br>mg vs,<br>Placebo♦|DM: -0,58 (IC<br>95%: -0,73, -0,42),<br>favorece MIRA|<0,05|DM: -0,65 (IC<br>95%: -0,78, -0,52),<br>favorece MIRA|<0,05|DM: -0,75 (IC<br>95%: -1,00, -0,51),<br>favorece MIRA|<0,05|NR|NR|
|**Drake et al,**|MIRA 25<br>mg vs,<br>Placebo♦|DM: -0,53 (IC<br>95%: -0,69, -0,32),<br>favorece MIRA|<0,05|DM: -0,57 (IC<br>95%: -0,73, -0,37),<br>favorece MIRA|<0,05|DM: -0,58 (IC<br>95%: -0,86, -0,28),<br>favorece MIRA|<0,05|NR|NR|
|**2017(95)**|MIRA 50<br>mg vs,<br>BOTOX|DM: 0,97 (IC<br>95%: 0,47, 1,49),<br>Favorece BOTOX|<0,05|DM: 0,72 (IC 95%:<br>0,36, 1,08),<br>Favorece BOTOX|<0,05|DM: 1,26 (IC 95%:<br>0,67, 1,84),<br>Favorece BOTOX|<0,05|NR|NR|
||MIRA 25<br>mg vs,<br>BOTOX|DM: 1,03 (IC<br>95%: 0,51, 1,56),<br>favorece BOTOX|<0,05|DM: 0,81 (IC 95%:<br>0,43, 1,18),<br>Favorece BOTOX|<0,05|DM: 1,44 (IC 95%:<br>0,83, 2,04),<br>Favorece BOTOX|<0,05|NR|NR|  
77  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg vs,<br>FESO 4 mg<br>*|DM: 0,168 (IC<br>95%: -0,33, 0,69)|0,7|DM: 0,017 (IC<br>95%: -0,51, 0,54)|0,96|DM: 0,33 (IC 95%:<br>-0,27, 0,94)|0,52|NR|NR|
||MIRA 50<br>mg vs,<br>FESO 8 mg<br>*|DM: 0,443 (IC<br>95%: -0,26, 1,15)|0,34|DM: 0,347 (IC<br>95%: -0,22, 0,92)|0,45|DM: 0,64 (IC 95%:<br>0,04, 1,23)|0,1|NR|NR|
|**Obloza et al,**<br>|MIRA 50<br>mg vs,<br>Propiverina<br>*|DM: 0,098 (IC<br>95%: -0,25, 0,45)|0,73|DM: -0,029 (IC<br>95%: -0,5, 0,43)|0,91|DM: 0,24 (IC 95%:<br>-0,34, 0,83)|0,51|NR|NR|
|**2017(79)**|MIRA 50<br>mg vs, TOL<br>4 mg*|DM: -0,051 (IC<br>95%: -0,35, 0,24)|0,85|DM: 0,102 (IC<br>95%: -0,37, 0,57)|0,9|DM: -0,21 (IC<br>95%: -0,58, 0,16)|0,45|NR|NR|
||MIRA50<br>mg vs,<br>SOLI 5 mg<br>*|DM: 0,246 (IC<br>95%: -0,26, 0,75)|0,13|DM: 0,435 (IC<br>95%: 0,21, 0,65),<br>favorece a SOLI|0,0001|DM: 0,69 (IC 95%:<br>0,94, 0,44),<br>favorece a<br>solifenacina|0,02|NR|NR|
||MIRA50<br>mg vs,<br>SOLI 10 mg<br>*|DM: 0,48 (IC<br>95%: 0,26, 0,7),<br>favorece a SOLI|0,04|DM: 0,802 (IC<br>95%: 0,58, 1,02),<br>favorece a SOLI|0,00003|DM: 0,99 (IC 95%:<br>0,74, 1,24),<br>favorece a SOLI|0,00007|NR|NR|  
78  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|<br>**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA50<br>mg vs,<br>Trospium*|DM: 0,263 (IC<br>95%: -0,06, 0,58)|0,18|DM: 0,138 (IC<br>95%: -0,07, 0,34)|0,9|DM: -0,46 (IC<br>95%: -0,7, -0,21),<br>favorece MIRA|0,003|NR|NR|
||MIRA50<br>mg vs,<br>Oxibutinina<br>*|DM: 0,109 (IC<br>95%: -0,01, 0,38)|0,7|DM: 0,099 (IC<br>95%: -0,28, 0,42)|0,7|NR|NR|NR|NR|
||MIRA50<br>mg vs,<br>BOTOX*|**Pacientes**<br>**previamentes**<br>**tratados**<br>DM: 0,95 (IC<br>95%: 0,39,1,52)|NS|**Pacientes**<br>**previamentes**<br>**tratados**<br>DM: 0,73 (IC 95%:<br>0,37,1,09)|NS|NR|NR|NR|NR|
|||DM não ajustado:<br>–1,85 (IC 95%: –||||DM não ajustado: –<br>2,06 (IC 95%: –||||
|**Freemantle**<br>**et al,**<br>**2016(97)**|BOTOX vs,<br>Placebo|2,25, –1,45); I2:<br>0%; 2 ECR; n<br>MIRA: 557; n<br>placebo: 548<br>DM ajustado▲: –<br>1,35 (IC 95%: –<br>1,79,–0,90|<0,05<br><0,05|DM não ajustado:<br>–1,47 (IC 95%: –<br>1,86, –1,10); I2:<br>47,7%; 2 ECR; n<br>MIRA: 557; n<br>placebo: 548|<0,05|2,59, –1,55); I2:<br>4,6%; 3 ECR; n<br>MIRA: 579; n<br>placebo: 577<br>DM ajustado▲:–<br>1,93 (IC 95%: –<br>2,48,–1,38)|<0,05<br><0,05|NR|NR|  
79  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||DM não ajustado:<br>–0,44 (IC 95%: –||||DM não ajustado: –<br>0,58 (IC 95%: –||||
||MIRA 50<br>mg vs,<br>Placebo|0,59, –0,28); I2:<br>0%; 6 ECR; n<br>MIRA: 1495; n<br>placebo: 1504<br>DM ajustado▲: –<br>0,65 (IC 95%: –<br>0,89,–0,41)|<0,05<br><0,05|DM não ajustado:<br>–0,66 (IC 95%: –<br>0,82, –0,48); I2:<br>0%; 6 ECR; n<br>MIRA: 2080; n<br>placebo: 2085|<0,05|0,80, –0,36); I2:<br>0%; 3 ECR; n<br>MIRA: 785; n<br>placebo:<br>DM ajustado▲: –<br>0,61 (IC 95%: –<br>0,92,–0,29)|<0,05<br><0,05|NR|NR|
|||DM não ajustado:<br>–0,53 (IC 95%: –||||DM não ajustado: –<br>0,43(IC 95%: –<br>0,74, –0,11); I2:||||
||MIRA 25<br>mg vs,<br>Placebo|0,78, –0,29); I2:<br>0%; 3 ECR; n<br>MIRA: 487; n<br>placebo: 508<br>DM ajustado▲: –<br>0,73 (IC 95%: –<br>1,07, –0,41)|<0,05<br><0,05|DM não ajustado:<br>–0,58 (IC 95%: –<br>0,82, –0,33); I2:<br>0%; 3 ECR; n<br>MIRA: 786; n<br>placebo: 792|<0,05|0%; 6 ECR; n<br>MIRA: 2075; n<br>placebo: 2084<br>791<br>DM ajustado▲: –<br>0,44 (IC 95%: –<br>0,81, –0,10)|<0,05<br><0,05|NR|NR|  
80  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|<br>**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||BOTOX vs,<br>MIRA 50<br>mg|DM não ajustado: -<br>1,41 (IC 95%: -<br>1,84, -0,98); I2:<br>NA; 8 ECR; n<br>total: 4591<br>DM ajustado▲: -<br>0,70 (IC 95%: -<br>1,23, -0,16); 6<br>ECR; n total: 3517,<br>favorece Botox|<0,05<br><0,05|DM não ajustado: -<br>0,81 (IC 95%: -<br>1,24, -0,40); I2:<br>NA; 8 ECR; n<br>total: 6056,<br>favorece Botox|<0,05|DM não ajustado: –<br>1,48 (IC 95%: –<br>2,06, –0,92); I2:<br>NA; 9 ECR; n<br>total:6100<br>DM ajustado▲: –<br>1,32 (IC 95%: –<br>2,00, –0,67); I2:<br>NA; 7 ECR; n<br>total:4390, favorece<br>Botox|<0,05<br><0,05|NR|NR|
||BOTOX vs,<br>MIRA 25<br>mg|DM não ajustado -<br>1,32 (IC 95%: -<br>1,79, -0,84); I2:<br>NA; 8 ECR; n<br>total: 4591<br>DM ajustado▲: -<br>0,62 (IC 95%: -<br>1,20, -0,02); 6<br>ECR; n total: 3517,<br>favorece Botox|<0,05<br><0,05|DM não ajustado: -<br>0,89 (IC 95%: -<br>1,35, -0,45); I2:<br>NA; 8 ECR; n<br>total: 6056,<br>favorece Botox|<0,05|DM não ajustado: –<br>1,63 (IC 95%: –<br>2,23, –1,03); I2:<br>NA; 9 ECR; n<br>total:6100<br>DM ajustado▲: –<br>1,49 (IC 95%: –<br>2,16, –0,80); I2:<br>NA; 7 ECR; n<br>total:4390, favorece<br>Botox|<0,05<br><0,05|NR|NR|  
81  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|<br>**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA 25<br>mg vs,<br>MIRA<br>50mg|DM não ajustado -<br>0,09 (IC 95%: -<br>0,33, 0,15); I2:<br>NA; NR ECR; n<br>total: NR<br>DM ajustado▲: -<br>0,08 (IC 95%: -<br>0,40,0,23)|NS<br>NS|DM não ajustado:<br>0,08 (IC 95%: -<br>0,17, 0,33); I2:<br>NA; NR ECR; n<br>total: NR|NS|DM não ajustado<br>0,15 (IC 95%: -<br>0,17, 0,47); I2: NA;<br>NR ECR; n total:<br>NR<br>DM ajustado▲:<br>0,16(IC 95%: -0,19,<br>0,51)|NS<br>NS|NR|NR|
|**Maman et**<br>**214**|TOL 4 mg<br>vs, MIRA<br>50 mg|DM: 0,088 (IC<br>95%: -0,057,0,234)|>0,05|DM: 0,157 (IC<br>95%: -0,001,<br>0,315)<br>**PUI§**<br>DM: 0,216 (IC<br>95%: -0,025,<br>0,456)|>0,05|NR|NR|NR|NR|
|**al, 0(96)**|DARI 15<br>mg vs,<br>MIRA 50<br>mg|DM: 0,132 (IC<br>95%: -0,270,0,536)|>0,05|DM: 0,067(IC<br>95%: -0,260,0,393)<br>**PUI§**<br>DM: 0,149 (IC<br>95%: -0,215,<br>0,518)|>0,05|NR|NR|NR|NR|  
82  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||DARI 7,5<br>mg vs,<br>MIRA 50<br>mg|DM: 0,294 (IC<br>95%: -0,200,0,786)|>0,05|DM: 0,068 (IC<br>95%: -0,411,<br>0,546)<br>**PUI§**<br>DM: 0,151 (IC<br>95%: -0,358,<br>0,661)|>0,05|NR|NR|NR|NR|
||Fesoteredina<br>4 mg vs,<br>MIRA 50<br>mg|DM: 0,104 (IC<br>95%: -0,384,0,590)|>0,05|DM: 0,137 (IC<br>95%: -0,163,0,437)<br>**PUI§**<br>DM: 0,356 (IC<br>95%: -0,135,<br>0,847)|>0,05|NR|NR|NR|NR|
||Fesoteredina<br>8 mg vs,<br>MIRA 50<br>mg|DM: 0,223 (IC<br>95%: -0,277,0,726)|>0,05|DM: -0,049 (IC<br>95%: -0,250,<br>0,152)<br>**PUI§**<br>DM: 0,061 (IC<br>95%: -0,212,<br>0,334)|>0,05|NR|NR|NR|NR|  
83  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||Oxibutinina<br>10 mg vs,<br>MIRA 50<br>mg|DM: 0,143 (IC<br>95%: -0,396,0,684)|>0,05|DM: 0,138 (IC<br>95%: -0,528,<br>0,807)<br>**PUI§**<br>DM: -0,569 (IC<br>95%: -1,509,<br>0,369)|>0,05|NR|NR|NR|NR|
||Placebo vs,|DM: 0,493 (IC||DM: 0,696 (IC<br>95%: 0,553, 0,838)||||||
||MIRA 50<br>mg|95%: -0,368, -<br>0,619)|<0,05|**PUI§**<br>DM: 0,778 (IC<br>95%: 0,555,1,001)|>0,05|NR|NR|NR|NR|
|||||DM: -0,584 (IC<br>95%: -0,837, -<br>0,332)||||||
||SOLI 10 mg<br>vs, MIRA<br>50 mg|DM: -0,237 (IC<br>95%: -0,486,0,011)|>0,05|**PUI§**<br>DM: -0,722 (IC<br>95%: -1,322, -<br>0,125)<br>Favorece a SOLI|<0,05|NR|NR|NR|NR|  
84  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||SOLI 5 mg|DM: -0,234 (IC||DM: -0,240 (IC<br>95%: -0,495,0,014)||||||
||vs, MIRA<br>50 mg|95%: -0,479,0,011)|>0,05|**PUI§**<br>NR|>0,05|NR|NR|NR|NR|
||Trospium<br>|||DM: -0,126 (IC<br>95%: -0,579,0,328)||||||
||60 mg vs,<br>MIRA 50<br>mg|DM: NR|NR|**PUI§**<br>DM: -0,042 (IC<br>95%: -0,527,<br>0,443)|>0,05|NR|NR|NR|NR|
|**Salvi et al,**<br>**2017;**<br>**Sebastianelli**|MIRA<br>50mg vs,<br>TOL 4 mg|DM: –0,09 (IC<br>95%: –0,35, 0,17);<br>I2: 70% (p:0,009);<br>5 ECR; n MIRA:<br>2213; n placebo:<br>2137|0,49|DM: –0,11 (IC<br>95%: –0,26, 0,03);<br>I2: 44% (p:0,13); 5<br>ECR; n MIRA:<br>2213; n placebo:<br>2137|0,12|NR|NR|NR|NR|
|**et al, 2017**<br>**(80, 91)**<br>**(resumo)**|MIRA 100<br>mg vs, TOL<br>4 mg|DM: –0,07 (IC<br>95%: –0,26, 0,12);<br>I2: 46% (p:0,12); 3<br>ECR; n MIRA:<br>1484; n placebo:<br>1392|0,48|DM: –0,08 (IC<br>95%: –0,27, 0,11);<br>I2: 0% (p:0,74); 3<br>ECR; n MIRA:<br>1484; n placebo:<br>1392|0,39|NR|NR|NR|NR|  
85  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA<br>50mg vs,<br>MIRA 100<br>mg|DM: 0,15 (IC<br>95%: –0,02, 0,31);<br>I2: 36% (p:0,21); 5<br>ECR; n MIRA:<br>1984; n placebo:<br>1992|0,08|DM: 0,03 (IC 95%:<br>–0,13, 0,19); I2:<br>0% (p:0,60); 5<br>ECR; n MIRA:<br>1984; n placebo:<br>1992|0,70|NR|NR|NR|NR|
|||||**Ensaios Clínicos Ra**|**ndomizad**|**os**||||
|||PIU§||PIU§||PIU§||||
|||Basal, média (EP):<br>MIRA: 2,71 (0,09)<br>Placebo: 2,73<br>(0,09)<br>∆ (MIRA) -|<0,001|Basal, média (EP):<br>MIRA: 11,66<br>(0,11)<br>Placebo: 11,59<br>(0,11)|<0,001|Basal, média (EP):<br>MIRA: 6,38 (0,13)<br>Placebo: 6,33<br>(0,12)<br>∆ (MIRA) -|<br><0,001|||
|**Chapple et**||(Placebo):||∆ (MIRA) -||(Placebo):||||
|**al, 2015(92)**|MIRA|−0,40 (IC 95%:||(Placebo):||−0,85 (IC 95%:||||
|**(Análise**|50mg vs,|−0,58, -0,21)||−0,68 (IC 95%:||−1,16, -0,55)||NR|NR|
|**exploratória**<br>**de 3 ECR)**|Placebo|PIU≥ 2<br>Basal, média (EP):<br>MIRA: 4,36 (0,13)<br>Placebo: 4,37<br>(0,13)<br>∆ (MIRA) -|<0,001|−0,92, -0,45)<br>PIU≥ 2<br>Basal, média (EP):<br>MIRA: 12,03<br>(0,16)<br>Placebo:11,94|<0,001|PIU≥ 2<br>Basal, média (EP):<br>MIRA: 7,64 (0,18)<br>Placebo: 7,44<br>(0,17)<br>∆ (MIRA) -|<br><0,001|||
|||(Placebo):||(0,16)||(Placebo):||||  
86  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||−0,58 (IC 95%:||∆ (MIRA) -||−1,18 (IC 95%:||||
|||−0,91, -0,24)|<0,001|(Placebo):<br>−0,76 (IC 95%:|<0,001|−1,63, -0,72)|<0,001|||
|||PIU≥ 4<br>Basal, média (EP):||−1,10, -0,42)||PIU≥ 4<br>Basal, média (EP):||||
|||MIRA: 6,54 (0,20)||PIU≥ 4||MIRA: 8,83 (0,30)||||
|||Placebo: 6,78||Basal, média (EP):||Placebo: 8,96||||
|||(0,20)||MIRA: 12,66||(0,28)||||
|||∆ (MIRA) -||(0,26)||∆ (MIRA) -||||
|||(Placebo):||Placebo: 12,64||(Placebo):||||
|||−0,85 (IC 95%:||(0,28)||−1,53 (IC 95%:||||
|||−1,52, -0,18)||∆ (MIRA) -<br>(Placebo):<br>−0,74 (IC 95%:<br>−1,30,-0,18)||−2,29, -0,77)||||  
|**Yamaguchi**<br>**et al,**|MIRA 25<br>mg|Basal, média (DP):<br>2,20 (2,499)<br>DM (DP): -1,29<br>(1,938)|<0,001<br>vs,<br>placebo|Basal, média (DP):<br>11,17 (2,526)<br>DM (DP): -1,94<br>(2,158)|<0,001<br>vs,<br>placebo|Basal, média (DP):<br>4,68 (3,209)<br>DM (DP): -2,15<br>(2,731)|NS|Basal, média<br>(DP): 1,97<br>(2,378)<br>DM (DP): -1,14<br>(1,809)|0,006 vs,<br>Placebo|
|---|---|---|---|---|---|---|---|---|---|
|**2015(98)**||Basal, média (DP):|<0001|Basal, média (DP):|<0001|Basal, média (DP):||Episódios de||
||MIRA|2,00 (2,228)|,<br>|11,47 (2,835)|,<br>|4,84 (3,255)|NS|IUU|0,008 vs,|
||50mg|DM (DP): -1,20|vs,<br>Plb|DM (DP): -2,12|vs,<br>Plb|DM (DP): -2,24||Basal, média|Placebo|
|||(1,455)|aceo|(2,383)|aceo|(3,120)||(DP): 1,82||  
87  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||||||||(2,098)<br>DM (DP): -1,09<br>(1,345)||
||MIRA 100<br>mg|Basal, média (DP):<br>1,86 (1,666)<br>DM (DP): -1,28<br>(1,355)|<0,001<br>vs,<br>placebo|Basal, média (DP):<br>11,77 (2,606)<br>DM (DP): -1,97<br>(1,970)|<0,001<br>vs,<br>placebo|Basal, média (DP):<br>4,53 (3,093)<br>DM (DP): -2,48<br>(2,605)|0,011<br>vs,<br>Placebo|Basal, média<br>(DP): 1,77<br>(1,640)<br>DM (DP): -1,24<br>(1,278)|<0,001 vs,<br>Placebo|
||Placebo|Basal, média (DP):<br>1,68 (1,471)<br>DM (DP): -0,64<br>(1,360)|NA|Basal, média (DP):<br>11,20 (2,761)<br>DM (DP): -1,18<br>(2,155)|NA|Basal, média (DP):<br>4,57 (3,160)<br>DM (DP): -1,83<br>(2,965)|NA|Basal, média<br>(DP): 1,55<br>(1,376)<br>DM (DP): -0,68<br>(1,358)|NA|
|||Basal, média (DP):<br>2,54 (3,00)||Basal, média (DP):<br>11,6 (3,09)||Basal, média (DP):<br>5,53 (3,98)||Basal, média<br>(DP): 2,16<br>(2,42)||
|**Kuo et al,**<br>**2015(88)**|MIRA<br>50mg|Fim do estudo:<br>1,16 (2,51)<br>DM (DP): - 1,16<br>(2,51)|NR|Fim do estudo:<br>9,46 (2,79)<br>DM (DP): - 2,12<br>(2,91)|NR|Fim do estudo: 3,56<br>(3,78)<br>DM (DP): - 1,97<br>(3,49)|NR|Fim do<br>estudo:0,43<br>(1,09)<br>DM (DP): -1,73<br>(2,71)|NR|
||TOL 4mg|Basal, média (DP):<br>1,58 (1,95)|NR|Basal, média (DP):<br>12,3 (3,27)|NR|Basal, média (DP):<br>5,93 (4,87)|NR|Basal, média<br>(DP): 1,61|NR|
|||Fim do estudo:||Fim do estudo:||Fim do estudo: 3,97||(2,10)||  
88  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||0,78 (1,25)<br>DM (DP):   -0,79<br>(2,02)||11,4 (3,79)<br>DM (DP):   -0,98<br>(3,18)||(4,53)<br>DM (DP):  -1,96<br>(4,33)||Fim do estudo:<br>0,63 (1,07)<br>DM (DP): -0,63<br>(1,07)||
||Placebo|Basal, média (DP):<br>2,61 (2,18)<br>Fim do estudo:<br>2,03 (3,24)<br>DM (DP): - 0,58<br>(2,51)|NR|Basal, média (DP):<br>13,2 (5,29)<br>Fim do estudo:<br>11,9 (4,70)<br>DM (DP):  -1,28<br>(3,49)|NR|Basal, média (DP):<br>5,49 (4,30)<br>Fim do estudo: 4,00<br>(4,37)<br>DM (DP):  -1,49<br>(4,84)|NR|Basal, média<br>(DP): 2,67<br>(2,36)<br>Fim do estudo:<br>1,65 (2,86)<br>DM (DP): -<br>1,02(2,68)|NR|
||MIRA<br>50mg vs,<br>Placebo|∆ (MIRA) -<br>(Placebo):<br>-0,84|0,112|∆ (MIRA) -<br>(Placebo):<br>-1,42|0,004|∆ (MIRA) -<br>(Placebo):<br>- 0,46|0,446|∆ (MIRA) -<br>(Placebo):<br>-1,15|0,083|
||TOL 4 mg<br>vs, Placebo|∆ (TOL) -<br>(Placebo):<br>-0,95|0,756|∆ (TOL) -<br>(Placebo):<br>- 0,01|0,985|∆ (TOL) -<br>(Placebo):<br>- 0,25|0,683|∆ (TOL) -<br>(Placebo):<br>-0,86|0,592|
|**Khullar et**<br>**al, 2015;**<br>**Khullar et**<br>**al, 2013 (99,**<br>**100)**|MIRA 100<br>mg|PIU§<br>Basal, média (EP):<br>2,89 (0,147)<br>Fim do estudo:<br>1,37 (0,134)<br>DM linha de base e<br>12 semanas(IC|<0,05|NA£|NA£|NA£|NA£|NA£|NA£|  
89  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|**SCORPIO £**||95%): -1,46 (-1,68,<br>-1,23)<br>DM linha de base e<br>4 semanas (IC<br>95%): -1,03 (-1,27,<br>-0,79)|<0,05|||||||
||MIRA 50<br>mg|PIU§<br>Basal, média (EP):<br>2,83 (0,165)<br>Fim do estudo:<br>1,22 (0,133)<br>DM linha de base e<br>12 semanas (IC<br>95%): - 1,57 ( -<br>1,79, -1,35)<br>DM linha de base e<br>4 semanas (IC<br>95%):   -1,04 ( -<br>1,27,-0,81)|<0,05<br><0,05|NA£|NA£|NA£|NA£|NA£|NA£|
||TOL 4 mg|PIU§<br>Basal, média (EP):<br>2,63 (0,148)<br>Fim do estudo:<br>1,42(0,145)|<0,05|NA£|NA£|NA£|NA£|NA£|NA£|  
90  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|<br>**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||DM linha de base e<br>12 semanas (IC<br>95%):  -1,27(-1,49,<br>-1,05)<br>DM linha de base e<br>4 semanas (IC<br>95%): -1,00 ( -<br>1,23,-0,77)|<0,05|||||||
||Placebo|PIU§<br>Basal, média (EP):<br>2,67 (0,140)<br>Fim do estudo:<br>1,54 (0,145)<br>DM linha de base e<br>12 semanas (IC<br>95%): -1,17 ( -<br>1,39, -0,95)<br>DM linha de base e<br>4 semanas (IC<br>95%): -0,65 ( -<br>0,88,-0,42)|<0,05<br><0,05|NA£|NA£|NA£|NA£|NA£|NA£|
||MIRA 100<br>mg vs,<br>Placebo|PIU§<br>∆ (MIRA 100) -<br>(Placebo)linha de|0,010|NA£|NA£|NA£|NA£|NA£|NA£|  
91  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||base e 12 semanas:<br>-0,29 (IC 95%: -<br>0,61, -0,03)<br>∆ (MIRA 100) -<br>(Placebo) linha de<br>base e 4 semanas:<br>-0,38 (IC 95%: -<br>0,71,-0,05)|0,002|||||||
||MIRA 50<br>mg vs,<br>Placebo|PIU§<br>∆ (MIRA 50) -<br>(Placebo) linha de<br>base e 12 semanas:<br>- 0,41 (IC 95%: -<br>0,72, -0,09)<br>∆ (MIRA 50) -<br>(Placebo) linha de<br>base e 4 semanas:<br>-0,39 (IC 95%: -<br>0,71,-0,06)|0,003<br>0,002|NA£|NA£|NA£|NA£|NA£|NA£|
||TOL 4 mg<br>vs, Placebo|PIU§<br>∆ (TOL) -<br>(Placebo)linha de|0,11|NA£|NA£|NA£|NA£|NA£|NA£|  
92  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||base e 12 semanas:<br>- 0,10 (IC 95%: -<br>0,42, 0,21)<br>∆ (TOL) -<br>(Placebo) linha de<br>base e 4 semanas:<br>-0,35 (IC 95%: -<br>0,68,-0,03)|0,019|||||||
|**Herschorn**<br>**et al,**<br>**2013(101)**|MIRA 50<br>mg|PIU§<br>Basal, média<br>(EP):2,51 (0,15)<br>DM linha de base e<br>12 semanas (EP):<br>-1,38 (0,12)<br>DM linha de base e<br>4 semanas (EP):<br>-1,13(0,12)|NR|NA£|NA£|NA£|NA£|PIU§<br>Basal, média<br>(EP): 2,33<br>(0,14)<br>DM linha de<br>base e 4<br>semanas (EP): -<br>1,33 (0,11)|NR|
||MIRA 25<br>mg|PIU§<br>Basal, média (EP):<br>2,65 (0,16)<br>DM linha de base e<br>12 semanas (EP): -<br>1,36(0,12)|NR|NA£|NA£|NA£|NA£|PIU§<br>Basal, média<br>(EP): 2,45<br>(0,14)<br>DM linha de<br>base e 4|NR|  
93  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
|||DM linha de base e<br>4 semanas (EP):<br>- 0,96 (0,12)||||||semanas (EP):<br>-1,31 (0,11)||
||Placebo|PIU§<br>Basal, média (EP):<br>NR<br>DM(EP):  NR|NR|NA£|NA£|NA£|NA£|PIU§<br>Basal, média<br>(EP): NR<br>DM(EP): NR|NR|
|||PIU§<br>∆ (MIRA 50) -<br>(Placebo) linha de<br>base e 12 semanas:||||||PIU§||
|||- 0,42 (IC 95%: -||||||∆ (MIRA 50) -||
||MIRA 50|0,76, -0,08)|0,001|||||(Placebo) linha||
||mg vs,<br>Placebo|∆ (MIRA 50) -<br>(Placebo) linha de<br>base e 4 semanas:<br>-  0,51 (IC 95%: -<br>0,85, -0,17)|<0,001|NA£|NA£|NA£|NA£|de base e 4<br>semanas: -0,39<br>(IC 95%: -0,69,<br>-0,08)|0,002|  
94  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**urgência em 24h**<br>**(DM entre a linha**<br>**de base e 12**<br>**semanas)**|**Valor p**|**Episódios de**<br>**IUU em 24h**<br>**(DM entre a**<br>**linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA 25<br>mg vs,<br>Placebo|PIU§<br>∆ (MIRA 25) -<br>(Placebo) linha de<br>base e 12 semanas:<br>-  0,40 (IC 95%: -<br>0,74, -0,06)<br>∆ (MIRA 25) -<br>(Placebo) linha de<br>base e 4 semanas:<br>- 0,34 (IC 95%: -<br>0,68,-0,01)|0,005<br>0,039|NA£|NA£|NA£|NA£|PIU§<br>∆ (MIRA 25) -<br>(Placebo) linha<br>de base e 4<br>semanas:  -0,36<br>(IC 95%: -0,67,<br>-0,05)|0,004|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; IU: incontinência urinária; IUU: incontinência urinária de urgência; PTA: população total analisada; PIU: população com incontinência urinária, PIUU: população com incontinência urinária de urgência;EIU: episódios de incontinência urinária; * o tempo de seguimento não foi reportado;▲ajustado pela gravidade de EIU na linha de base; NA£ somente foram coletados desfechos que não foram inclusos nas revisões sistemáticas; PIU§ população com incontinência: participantes que apresentaram mais de 1 EIU na linha de base;EPPCB: Escores da Percepção do paciente da condição da bexiga; KHQ: King’s Health Questionnaire, mede qualidade de vida; NA: não se aplica; NR: não reportado; DM: diferença de médias; ∆: diferença; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos,  
95

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 12 – Desfechos de eficácia secundários ou relatados pelos pacientes dos estudos que compararam Mirabegrona versus Placebo ou Tolterodina.** -->
|**Autor,**<br>**ano**|**Grupos**<br>MIRA<br>total vs,<br>Placebo|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**<br>**Revisões**<br>NR|**Valor**<br>**p**<br>**Sistemáti**<br>NR|**Desfechos secundários**<br>**miccionais**<br>**cas com Meta-análises de c**<br>NR|**Valor**<br>**p**<br>**ompara**<br>NR|**Desfechos reportados pelos**<br>**pacientes**<br>**ções diretas**<br>**OAB-q**<br>DM: –4,49 (IC 95%: –6,27, –2,71);<br>I2: 84% (p< 0,00001); 4 ECR; n<br>MIRA: 3140;nplacebo:3208|**Valor p**<br>< 0,00001|
|---|---|---|---|---|---|---|---|
||MIRA<br>25mg vs,<br>Placebo|NR|NR|NR|NR|**OAB-q**<br>DM: –1,10 (IC 95%: –2,29, 0,08); I2:<br>0% (p:0,63); 2 ECR; n MIRA: 573; n<br>placebo: 595|0,07|
|**Wu et al,**<br>**2014(89)**|MIRA 50<br>mg vs,<br>Placebo|NR|NR|NR|NR|**OAB-q**<br>DM: –4,64 (IC 95%: –6,05, –3,22);<br>I2: 34% (p:0,21); 4 ECR; n MIRA:<br>1498;nplacebo:1523|< 0,00001|
||MIRA<br>100 mg<br>vs,<br>Placebo|NR|NR|NR|NR|**OAB-q**<br>DM: –6,43 (IC 95%: –9,70, –3,15);<br>I2: 83% (p:0,003); 2 ECR; n MIRA:<br>1069;nplacebo:1090|0,0001|
||MIRA<br>total vs,<br>TOL 4mg|NR|NR|NR|NR|**OAB-q**<br>DM: –1,09 (IC 95%: –2,51, 0,33); I2:<br>75% (p:0,001); 3 ECR; n MIRA:<br>2857;n TOL:2688|0,13|  
96  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50|||||**OAB-q**||
||mg vs,<br>TOL 4<br>mg|NR|NR|NR|NR|DM: –0,82 (IC 95%: –3,47, 1,83); I2:<br>84% (p: 0,002); 3 ECR; n MIRA:<br>1419;n TOL:1344|0,54|
||MIRA|||||**OAB-q**||
||100 mg<br>vs, TOL 4<br>mg|NR|NR|NR|NR|DM: –1,34 (IC 95%: –2,82, 0,13); I2:<br>43% (p: 0,17); 3 ECR; n MIRA:<br>1438;n TOL:1344|0,07|
|**Cui et al,**<br>**2013(90)**|MIRA 50<br>mg vs,<br>Placebo *|NR|NR|**Volume médio de**<br>**esvaziamento por micção**<br>DM:12,99 (IC 95%: 9,85,<br>16,12); I2: 0% (p:0,64); 3<br>ECR; n MIRA: 1276; n<br>placebo: 1294<br>**Episódios de noctúria em**<br>**24h**<br>DM: -0,12 (IC 95%: -0,23,<br>-0,01); I2: 0% (p:0,35); 2<br>ECR; n MIRA: 804; n<br>placebo: 814|<<br>0,0000<br>1<br>0,03|**OAB-q**<br>DM: –5,34 (IC 95%: –7,11, –3,57);<br>I2: 0% (p:0,41); 2 ECR; n MIRA:<br>889; n placebo:908<br>**TS-VAS**<br>DM:0,74 (IC 95%: 0,45, 1,05); I2:<br>0% (p:0,54); 2 ECR; n MIRA: 838; n<br>placebo: 861<br>**Percepção dp paciente da condição**<br>**da bexiga**<br>DM: -0,20 (IC 95%: -0,33, -0,07); I2:<br>0% (p:1); 2 ECR; n MIRA: 840; n<br>placebo: 866|< 0,00001<br>< 0,00001<br>0,003|
|||**Revisões S**|**istemátic**|**as com Meta-análises de co**|**mparaçõ **|**es indiretas**||  
97  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg vs,<br>Placebo*|**Redução de 100% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 1,43 (IC 95%: 1,21,<br>1,71)<br>**Redução de ≥ 50% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**|<0,05<br><0,05|NR|NR|NR|NR|
|**Drake et**<br>**l**||OR: 1,64 (IC 95%: 1,27,<br>2,13)||||||
|**a,**<br>**2017(95)**||**Redução de 100% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 1,32 (IC 95%: 1,03,||||||
||MIRA 25|1,61)|<0,05|||||
||mg vs,<br>Placebo*|**Redução de ≥ 50% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 1,54 (IC 95%: 1,13,<br>2,01)|<0,05|NR|NR|NR|NR|  
98  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg vs,<br>BOTOX<br>*|**Redução de 100% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 0,33 (IC 95%: 0,22,<br>0,49)<br>**Redução de ≥ 50% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 0,48 (IC 95%: 0,32,<br>0,72)|<0,05<br><0,05|NR|NR|NR|NR|
||MIRA 25<br>mg vs,<br>BOTOX<br>*|**Redução de 100% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 0,30 (IC 95%: 0,20,<br>0,46)<br>**Redução de ≥ 50% de**<br>**EIU/dia entre a linha de**<br>**base e 12 semanas**<br>OR: 0,45 (IC 95%: 0,29,<br>0,67)|<0,05<br><0,05|NR|NR|NR|NR|
|**Obloza et**<br>**al,**<br>**2017(79)**|MIRA 50<br>mg vs,<br>FESO 4<br>mg|NR|NR|**Volume por micção**<br>DM: 4,25 (IC 95%: -5,71,<br>14,22)|0,9|NR|NR|  
99  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg vs,<br>FESO 8<br>mg|NR|NR|**Volume por micção**<br>DM: -11,94 (IC 95%: -<br>21,93, -1,95), favorece<br>MIRA|0,02|NR|NR|
||MIRA 50<br>mg vs,<br>Propiveri<br>na|NR|NR|**Volume por micção**<br>DM: -8,4 (IC 95%: -18,75,<br>1,95),|0,3|NR|NR|
||MIRA 50<br>mg vs,<br>TOL 4<br>mg|NR|NR|**Volume por micção**<br>DM: -2,34 (IC 95%: -6,39,<br>1,69)|0,25|NR|NR|
||MIRA vs,<br>SOLI 5<br>mg|NR|NR|**Volume por micção**<br>DM: -11,21 (IC 95%: -<br>17,57, -4,85), favorece<br>MIRA|0,0005|NR|NR|
||MIRA vs,<br>SOLI 10<br>mg|NR|NR|**Volume por micção**<br>DM: -18,94 (IC 95%: -<br>25,41, -12,48), favorece<br>MIRA|0,0005|NR|NR|
||MIRA vs,<br>Trospium|NR|NR|**Volume por micção**<br>DM: 0,73 (IC 95%: -3,59,<br>4,92)|0,98|NR|NR|
||MIRA vs,<br>Oxibutina|NR|NR|NR|NR|NR|NR|  
100  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||BOTOX<br>vs,<br>Placebo|**Redução de A) 100% e**<br>**B) 50% de EIU/dia**<br>A)OR: 4,45 (IC 95%:<br>2,79, 7,46); I2: 0%; 3<br>ECR; n MIRA: 577; n<br>placebo: 576<br>B) OR: 3,43 (IC 95%:<br>1,94, 6,24); I2: 0%; 2<br>ECR; n MIRA: 557; n<br>placebo: 548|<0,05<br><0,05|**Episódios de noctúria**<br>DM não ajustado: –0,25<br>(IC 95%: -0,43, –0,07); I2:<br>0%; 3 ECR; n MIRA: 557;|<0,05|NR|NR|
|**Freeman**<br>**tle et al,**<br>**2016(97)**||**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 6,62 (IC 95%: 2,39,<br>20,45); I2: 0%; 2 ECR; n<br>MIRA: 527; n placebo:<br>518|<0,05|n placebo: 548||||
||MIRA 50<br>mg vs,<br>Placebo|**Redução de A) 100% e**<br>**B) 50% de EIU/dia**<br>**A)**OR: 1,27 (IC 95%:<br>0,91, 1,80); I2: 0%; 3<br>ECR; n MIRA: 658; n<br>placebo: 659<br>B) OR: 1,66 (IC 95%:<br>1,00,2,74);I2: NA;2|>0,05<br>>0,05<br>>0,05|**Episódios de noctúria**<br>DM não ajustado: –0,15<br>(IC 95%: -0,27, –0,03); I2:<br>0%; 4 ECR; n MIRA:<br>1123; n placebo: 1126|<0,05|NR|NR|  
101  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||ECR; n MIRA: 550; n<br>placebo: 553||||||
|||**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 0,95 (IC 95%: 0,33,<br>2,72); I2: NR; 1 ECR; n<br>MIRA: 166; n placebo:<br>165||||||
||MIRA 25<br>mg vs,<br>Placebo|**Redução de 100% de**<br>**EIU/dia**<br>**A)**OR: 1,26 (IC 95%:<br>0,84, 1,86); I2: 0%; 3<br>ECR; n MIRA: 353; n<br>placebo: 368<br>B) OR: 1,87 (IC 95%:<br>1,03, 3,47); I2: NA; 1<br>ECR; n MIRA: 254; n<br>placebo: 262<br>**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 1,08 (IC 95%: 0,38,<br>3,03);I2: NR;1 ECR;n|>0,05<br><0,05<br>>0,05|**Episódios de noctúria**<br>DM não ajustado: –0,19<br>(IC 95%: -0,36, –0,02); I2:<br>0%; 2 ECR; n MIRA: 324;<br>n placebo: 312|<0,05|NR|NR|  
102  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||MIRA: 167; n placebo:<br>165||||||
||BOTOX<br>vs, MIRA<br>50 mg|**Redução de A) 100% e**<br>**B) 50% de EIU/dia entre**<br>**a linha de base e 12**<br>**semanas**<br>A)OR: 3,49 (IC 95%:<br>1,97, 6,55); I2: NA; 3<br>ECR; n total: 2783<br>B) OR: 2,07 (IC 95%:<br>0,98, 4,49); I2: NA; 4<br>ECR; n total: 2462<br>Favorece Botox<br>**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 7,01 (IC 95%: 1,62,<br>32,60); I2: NR; 3 ECR; n<br>total: 1961<br>**Episódios de noctúria**<br>DM não ajustado: –0,10<br>(IC 95%: -0,32, 0,12); I2:<br>0%;6 ECR;n total:3678|<0,05<br>>0,05<br><0,05<br>>0,05|**Episódios de noctúria**<br>DM não ajustado: -0,10<br>(IC95% -0,32; 0,12)|NS|NR|NR|  
103  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Redução de A) 100% e**<br>**B) 50% de EIU/dia entre**<br>**a linha de base e 12**<br>**semanas**<br>A)OR: 3,54 (IC 95%:<br>1,93, 6,81); I2: NA; 3||||||
|||ECR; n total: 2783|<0,05|||||
||BOTOX|B) OR: 1,83 (IC 95%:||**Episódios de noctúria**||||
||vs, MIRA<br>25 mg|0,80, 4,25); I2: NA; 4<br>ECR; n total: 2462<br>Favorece Botox<br>**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 6,16 (IC 95%: 1,43,<br>28,58); I2: NR; 3 ECR; n<br>total:1961|>0,05<br><0,05|DM não ajustado: -0,06<br>(IC95% -0,31; 0,19)|NS|NR|NR|
||MIRA 25<br>mg vs,<br>MIRA<br>50mg|**Redução de A) 100% e**<br>**B) 50% de EIU/dia**<br>A) OR: 0,99 (IC 95%:<br>0,67, 1,46); I2: NA; NR<br>ECR; n total: NR<br>B) OR: 1,13 (IC 95%:<br>0,62, 2,10); I2: NA; NR<br>ECR; n total: NR|NS<br>NS<br>>0,05|DM não ajustado: -0,04<br>(IC95% -0,21; 0,13)|NS|NR|NR|  
104  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**Redução de 100% de**<br>**episódios de**<br>**urgência/dia**<br>OR: 1,14 (IC 95%: 0,40,<br>3,23); I2: NA; NR ECR; n<br>total: NR||||||
|**Maman**<br>**et al,**<br>**2014(96)**|TOL 4<br>mg vs,<br>MIRA 50<br>mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 11,7%; b) 0,0%; c)<br>0,0%<br>2) a) 2,6%; b) 0,0%; c)<br>0,0%<br>**3)**a)18,2%; b) 0,0%; c)<br>0,0%|NR|NR|NR|NR|NR|
||DARI 15<br>mg vs,<br>MIRA 50<br>mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**|NR|NR|NR|NR|NR|  
105  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 34,4%; b)0,0%; c)<br>0,0%<br>3) a) 44,7%; b) 2,3%; c)<br>0,0%||||||
||DARI 7,5<br>mg vs,<br>MIRA 50<br>mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 39,2%; b) 1,0%; c)<br>0,0%<br>3)a) 44,7%; b) 2,3%; c)<br>0,0%|NR|NR|NR|NR|NR|  
106  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||Fesotered<br>ina 4 mg<br>vs, MIRA<br>50 mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 18,5%; b) 0,0%; c)<br>0,0%<br>3)a) 57,2%; b) 0,6%; c)<br>0,0%|NR|NR|NR|NR|NR|
||Fesotered<br>ina 8 mg<br>vs, MIRA<br>50 mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%|NR|NR|NR|NR|NR|  
107  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||2) a) 68,2%; b) 0,0%; c)<br>0,0%<br>3)a) 94,6%; b) 3,7%; c)<br>0,0%||||||
||Oxibutini<br>na 10 mg<br>vs, MIRA<br>50 mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 79,6% b) 25,6%; c)<br>1,8%<br>3) a) 79,6%; b) 25,6%; c)<br>1,8%|NR|NR|NR|NR|NR|
||Placebo<br>vs, MIRA<br>50 mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**|NR|NR|NR|NR|NR|  
108  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 34,2%; b) 3,0%; c)<br>0,0%<br>3**)**a) 0,0%; b) 0,0%; c)<br>0,0%||||||
||SOLI 10<br>mg vs,<br>MIRA 50<br>mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 100,0%; b) 74,2%;<br>c) 0,1%<br>3)a) 98,8%; b) 32,7%; c)<br>0,1%|NR|NR|NR|NR|NR|
||SOLI 5<br>mg vs,|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**|NR|NR|NR|NR|NR|  
109  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg|**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) a) 25,9%; b) 0,1%; c)<br>0,0%<br>2) a) 96,8%; b) 2,3%; c)<br>0,0%<br>3**)**a) 94,9%; b) 12,0%; c)<br>0,0%||||||
||Trospium<br>60 mg vs,<br>MIRA 50<br>mg|**Probabilidade do**<br>**tratamento ser melhor**<br>**do que o MIRA na**<br>**população em geral 1)**<br>**EIU; 2) Frequência de**<br>**micções; 3) Episódio de**<br>**IUU nas margens de**<br>**superioridade (a) 0 b)**<br>**0,5 c) 1 episódio por dia)**<br>1) NR<br>2) a) 70,7%; b) 5,3%; c)<br>0,0%<br>3)a) 65,0%; b) 9,8%; c)<br>0,3%|NR|NR|NR|NR|NR|  
110  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**<br>**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|
||||**Ensaios Clínicos Randomiza**|**dos**|||
|**Salvi et**<br>**al, 2017;**|||||||
|**Sebastian**<br>**elli et al,**<br>**2017 (80,**<br>**91)**|NR|NR|NR<br>NR|NR|NR|NR|
||||**Volume urinado/micção**<br>**(ml)**<br>PIU§<br>Basal, média (EP):<br>MIRA: 158,4 (1,9)<br>Placebo: 159,1 (1,9)<br>∆ (MIRA) - (Placebo):<br>13,3 (IC 95%:9,0, 17,7)|<0,001|||
|**Chapple**<br>**et al,**<br>**2015(92)**|MIRA<br>50mg vs,<br>Placebo|NR|NR<br>PIU≥ 2<br>Basal, média (EP):<br>MIRA: 153,2 (2,7)<br>Placebo: 155,3 (2,7)<br>∆ (MIRA) - (Placebo):<br>13,6 (IC 95%: 7,6, 19,7)|<0,001|NR|NR|
||||PIU≥ 4<br>Basal, média (EP):<br>MIRA:147,4(4,1)||||  
111  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||Placebo: 151,8 (4,2)<br>∆ (MIRA) - (Placebo):<br>12,1(IC 95%: 3,0,21,3)|<0,001|||
|||||**Volume urinado/micção**||**KHQ- QV; (DM)**|**vs, placebo**|
|||||**(ml)**|<0,001|Percepção Geral da Saúde: -3,3|NT|
|||||Basal, média (DP): 147,746|vs,|Impacto da Incontinência: -16,3|<0,025|
|||||(50,4554)|Placeb|Limitações de funções: -12,5|NT|
||MIRA 25<br>mg|NR|NR|DM (DP): 23,783 (41,6669|o|Limitações de físicas: -12,6<br>Limitações sociais: -7,8|<0,025<br>NT|
|||||**Episódios de noctúria**||Relações pessoais: -3,5|NT|
|||||Basal, média (DP): 147,746||Emoções: -13,9|NT|
|||||(50,4554)|NS|Dormir/Emergia: -11,4|NT|
|**Yamaguc**||||DM(DP):–0,39 (0,849)||Medidas de gravidade:-7,9|<0,025|
|**hi et al,**<br>**2015(98)**|MIRA<br>50mg|NR|NR|**Volume urinado/micção**<br>**(ml)**<br>Basal, média (DP): 151,570<br>(49,4637)<br>DM (DP): 27,249<br>(39,5137)|<0,001<br>vs,<br>Placeb<br>o|**KHQ- QV (DM)**<br>Percepção Geral da Saúde: 0,3<br>Impacto da Incontinência: -13,2<br>Limitações de funções: -11,3<br>Limitações de físicas: -10,8<br>Limitações sociais: -4,7|**vs, placebo**<br>NT<br><0,025<br>NR<br><0,025<br>NR|
|||||**Episódios de noctúria**<br>Basal, média (DP): 147,746<br>(50,4554)<br>DM(DP):–0,38 (0,814)|NS|Relações pessoais: -2,6<br>Emoções: -10<br>Dormir/Emergia: -8,4<br>Medidas de gravidade: -8,5|NT<br>NR<br>NT<br><0,025|  
112  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||**Volume urinado/micção**<br>**(ml)**<br>Basal, média (DP): 152,697<br>(46,5259))|<0,001<br>vs,<br>Placeb|**KHQ- QV; (DM)**<br>Percepção Geral da Saúde: -4,4<br>Impacto da Incontinência: -15,2<br>Limitações de funções: -12,6|**vs, placebo**<br>NR<br><0,025<br><0,025|
||MIRA<br>100 mg|NR|NR|DM (DP): 31,231<br>(39,4515)|o|Limitações de físicas: -10,6<br>Limitações sociais: -7,3|<0,025<br><0,025|
|||||**Episódios de noctúria**||Relações pessoais: -3,2|NR|
|||||Basal, média (DP): 147,746<br>(50,4554)|NS|Emoções: -13,7<br>Dormir/Emergia: -9,5|<0,025<br>NR|
|||||DM(DP):–0,49 (0,907)||Medidas degravidade:-10,3|<0,025|
||Placebo|NR|NR|**Volume urinado/micção**<br>**(ml)**<br>Basal, média (DP): 148,953<br>(42,9617)<br>DM (DP): 11,184<br>(36,9308)|NA|**KHQ- QV; (DM)**<br>Percepção Geral da Saúde: -2,2<br>Impacto da Incontinência: -7,3<br>Limitações de funções: -6,7<br>Limitações de físicas: -5,7<br>Limitações sociais: -3,2|NR|
|||||**Episódios de noctúria**<br>Basal, média (DP): 147,746<br>(50,4554)<br>DM(DP):–0,24(0,977)||Relações pessoais: -0,8<br>Emoções: -7,4<br>Dormir/Emergia: -6,4<br>Medidas de gravidade:  -4,7||  
113  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||**Volume por micção**<br>Basal, média (DP): 152<br>(54,3)<br>Fim do estudo:173 (69,7)||**KHQ- QV; DM (DP)**<br>Percepção Geral da Saúde: - 6,85<br>(24,0)<br>Impacto da Incontinência: - 7,31<br>(28,5)||
||MIRA<br>50mg|NR|NR|DM (DP): 22,17 (47,8)<br>**Episódios de noctúria**|NR|Limitações de funções: - 13,2 (35,5)<br>Limitações de físicas: - 11,2 (32,3)<br>Limitações sociais: -8,75 (29,6)|NR|
|||||Basal, média (DP): 2,32<br>(1,38)<br>Fim do estudo: 1,82 (1,12)<br>DM (DP): -0,50 (1,14)||Relações pessoais: -3,59 (28,7)<br>Emoções: - 14,8 (31,6)<br>Dormir/Emergia: - 14,2 (29,4)<br>Medidas de gravidade: - 6,67 (16,3)||
|**Kuo et al,**||||||Problemas na bexiga:-6,89 (16,0)||
|**2015(88)**||||**Volume por micção**<br>Basal, média (DP): 148||**KHQ- QV; DM (DP)**<br>Percepção Geral da Saúde: - 4,93<br>(25,2)||
|||||(60,7)<br>Fim do estudo:161 (67,0)<br>DM (DP): 13,30 (36,9)||Impacto da Incontinência: - 15,5<br>(29,2)<br>Limitações de funções: -8,22 (25,6)||
||TOL 4mg|NR|NR|**Episódios de noctúria**|NR|Limitações de físicas: -7,98 (26,7)<br>Limitações sociais: -4,54 (24,3)|NR|
|||||Basal, média (DP): 2,35<br>(1,51)<br>Fim do estudo:1,90 (1,30)<br>DM (DP):  -0,45 (1,25)||Relações pessoais: -5,56 (24,9)<br>Emoções: -8,45 (23,9)<br>Dormir/Emergia: -10,1 (25,6)<br>Medidas de gravidade:  -4,69 (16,1)<br>Problemas na bexiga:-9,15 (14,8)||  
114  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||**Volume por micção**<br>Basal, média (DP): 150<br>(63,4)<br>Fim do estudo:156 (67,5)<br>DM (DP): 5,54 (32,3)||**KHQ- QV; DM (DP)**<br>Percepção Geral da Saúde: 1,17<br>(22,5)<br>Impacto da Incontinência:  -13,5<br>(30,1)<br>Limitações de funções: -11,2 (32,9)||
||Placebo|NR|NR|**Episódios de noctúria**|NR|Limitações de físicas: - 5,47 (29,4)<br>Limitações sociais: - 2,86 (27,3)|NR|
|||||Basal, média (DP): 2,66<br>(1,73)<br>Fim do estudo: 2,12 (1,47)<br>DM (DP): -0,55 (1,54)||Relações pessoais: 0,85 (25,9)<br>Emoções:  -6,08 (24,6)<br>Dormir/Emergia: - 7,29 (25,5)<br>Medidas de gravidade: -0,42 (16,2)<br>Problemas na bexiga:-4,95 (15,8)||
||MIRA<br>50mg vs,<br>Placebo|NR|NR|**Volume por micção**<br>∆ (MIRA) - (Placebo):<br>16,70 (6,69)<br>**Episódios de noctúria**<br>∆ (MIRA) - (Placebo):<br>- 0,13 (0,18)|0,013<br>0,484|**KHQ- QV; DM (DP)**<br>Percepção Geral da Saúde: - 6,18<br>(3,35)<br>Impacto da Incontinência: 7,73 (4,60)<br>Limitações de funções: - 0,20 (4,73)<br>Limitações de físicas: -  2,60 (4,49)<br>Limitações sociais: -4,70 (3,83)<br>Relações pessoais: -3,49 (4,80)<br>Emoções: - 6,04 (4,22)<br>Dormir/Emergia: - 3,39 (3,83)<br>Medidas de gravidade: - 4,66 (2,59)<br>Problemas na bexiga:-0,48 (2,42)|0,066<br>0,094<br>0,967<br>0,563<br>0,222<br>0,468<br>0,154<br>0,377<br>0,073<br>0,844|  
115  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||TOL 4<br>mg vs,<br>Placebo|NR|NR|**Volume por micção**<br>∆ (TOL) - (Placebo):<br>7,59 (6,69)<br>**Episódios de noctúria**<br>∆ (TOL) - (Placebo):<br>- 0,06 (0,18)|0,258<br>0,734|**KHQ- QV; DM (DP)**<br>Percepção Geral da Saúde: - 2,34<br>(3,38)<br>Impacto da Incontinência: 1,81 (4,66)<br>Limitações de funções: 4,83 (4,81)<br>Limitações de físicas: 1,26 (4,53)<br>Limitações sociais: 0,63 (3,86)<br>Relações pessoais: -3,00 (4,82)<br>Emoções: 1,25 (4,26)<br>Dormir/Emergia: 0,94 (3,86)<br>Medidas de gravidade: - 2,09 (2,62)<br>Problemas na bexiga:-  2,36 (2,44)|0,490<br>0,698<br>0,316<br>0,781<br>0,871<br>0,534<br>0,769<br>0,807<br>0,425<br>0,336|
|**Khullar**<br>**et al,**<br>**2015;**<br>**Khullar**<br>**et al,**<br>**2013 (99,**<br>**100)**<br>**SCORPI**<br>**O £**|MIRA<br>100 mg<br>vs,<br>Placebo|PIU§<br>**Pacientes com redução**<br>**de 50% no número de**<br>**episódios de IU 24h**<br>OR: 1,45 (IC 95%: 1,02–<br>2,05)<br>**Pacientes com redução**<br>**de 100% no número de**<br>**episódios de IU 24h**<br>OR: 1,29 (IC 95%: 0,90–<br>1,84)|0,037<br>0,17|NA£|NA£|NA£|NA£|  
116  
|**Autor,**<br>**ano**|**Grupos**|**Probabilidades de**<br>**redução dos desfechos**<br>**miccionais entre a linha**<br>**de base e 12 semanas**|**Valor**<br>**p**|**Desfechos secundários**<br>**miccionais**|**Valor**<br>**p**|**Desfechos reportados pelos**<br>**pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg vs,<br>Placebo|PIU§<br>**Pacientes com redução**<br>**de 50% no número de**<br>**episódios de IU 24h**<br>OR: 1,75 (IC 95%: 1,23–<br>2,49)<br>**Pacientes com redução**<br>**de 100% no número de**<br>**episódios de IU 24h**<br>OR: 1,23 (IC 95%: 0,86–<br>1,76)|0,002<br>0,26|NA£||NA£|NA£|
||TOL 4<br>mg vs,<br>Placebo|PIU§<br>**Pacientes com redução**<br>**de 50% no número de**<br>**episódios de IU 24h**<br>OR: 1,44 (IC 95%: 1,02–<br>2,03)<br>**Pacientes com redução**<br>**de 100% no número de**<br>**episódios de IU 24h**<br>OR: 1,35 (IC 95%: 0,95–<br>1,92)|0,037<br>0,097|NA£||NA£|NA£|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa;IU: incontinência urinária; IUU: incontinência urinária de urgência;OAB-q: questionário de bexiga hiperativa, do inglês overactive bladder questionnaire; KHQ King’s Health  
117  
Questionnaire; QV: qualidade de vida; TS-VAS:escala visual analógica da satisfação do tratamento, do inglês treatment satisfaction-visual analog scale score; £NA foram coletados desfechos que não foram inclusos em revisões sistemáticas; PIU§: população com incontinência: participantes que apresentaram mais de 1 EIU na linha de base;NA: não se aplica; OR: Odds ratio ou razão de chances; DM: diferença de médias; ∆: diferença; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos; NR: não reportado;NS: não significativo; NT: não testado,  
118  
**Tabela 13 – Desfechos de segurança das revisões sistemáticas com meta-análises de comparação direta do Mirabegrona** **_versus_ Placebo ou**  
**Tolterodina.**  
||**W**|**u et a**|**l, 2014(89)**||**Cui et a**|**l, 2013(9**|**0)**|**Salvi et**|**al, 20**|**17; Sebastianelli**|**et al, 2017 (**|**80, 91)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|**MIR**<br>**A**<br>**Placeb**<br>**o**|**Val**<br>**or p**|<br>**MIRA**<br>**TOL  4**<br>**mg**|**Val**<br>**or p**|**MIRA**<br>**50 mg**|**Placeb**<br>**o**|**Val**<br>**or p**|<br>**MIR**<br>**A 50**<br>**mg**<br>**Placeb**<br>**o**|**Val**<br>**or p**|**MIRA**<br>**100**<br>**mg**<br>**Placeb**<br>**o**|**Val**<br>**or p**<br>**TOL**<br>**4 mg**|**Placeb**<br>**o**|**Val**<br>**or p**|
||**MIRA Total**<br>**vs, Placebo**:<br>OR: 1,04 (IC<br>95%: 0,93,<br>1,15); I2: 0%<br>(p: 0,48); 5<br>ECR; n|0,51|**MIRA Total vs,**<br>**TOL:**<br>OR: 0,90 (IC<br>95%: 0,80, 1,00);<br>I2: 21% (p:<br>0,27); 4 ECR; n<br>MIRA: 3023; n|0,04||||||||||
|EAET|MIRA: 3308;<br>n placebo:<br>3331<br>**MIRA 25mg**<br>**vs, Placebo**<br>OR: 1,12 (IC<br>95%: 0,88,|0,37|placebo: 2848<br>**MIRA 50mg vs,**<br>**TOL**:<br>OR: 0,90 (IC<br>95%: 0,78, 1,05);<br>I2: 30% (p:<br>0,24); 3 ECR; n|0,19|OR: 1,1<br>95%: 0,93<br>I2: 0% (p<br>4 ECR; n<br>1753; n p<br>175|0 (IC<br>, 1,31);<br>: 0,66);<br>MIRA:<br>lacebo:<br>8|0,25|<br>OR: 0,94 (IC<br>95%: 0,83,<br>1,06); I2: 52%<br>(p: 0,05); 7<br>ECR; n<br>MIRA: 2353;<br>n placebo:<br>2347|0,32|OR: 0,97 (IC<br>95%: 0,81,<br>1,16); I2: 43%<br>(p: 0,16); 4<br>ECR; n MIRA:<br>1162; n<br>placebo: 1178|0,75<br>OR: 1<br>95%<br>1,62);<br>(p: 0<br>ECR;<br>13<br>placeb|,38 (IC<br>: 1,17,<br>I2: 43%<br>,14); 4<br>n TOL:<br>25; n<br>o: 1396|<0,<br>000<br>1|
||1,42); I2: 0%<br>(p: 0,40); 2<br>ECR; n<br>MIRA: 602; n<br>placebo: 601<br>**MIRA 50mg**|0,64|MIRA: 1474; n<br>placebo: 1392<br>**MIRA 100 mg**<br>**vs, TOL:**<br>OR: 0,89 (IC<br>95%: 0,76,1,03);|0,12||||||||||  
119  
||**W**|**u et a**|**l, 2014(89)**||**Cui et**|**al, 2013(**|**90)**||**Salvi et**|**al, 20**|**17; Seba**|**stianelli**|**et al, 2017 (**|**80, 91)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**<br>**adversos**|**MIR**<br>**A**<br>**Placeb**<br>**o**|**Val**<br>**or p**|**MIRA**<br>**TOL  4**<br>**mg**|**Val**<br>**or p**|**MIRA**<br>**50 mg**|**Placeb**<br>**o**|**Val**<br>**or p**|**MIR**<br>**A 50**<br>**mg**|**Placeb**<br>**o**|**Val**<br>**or p**|**MIRA**<br>**100**<br>**mg**|**Placeb**<br>**o**|**Val**<br>**or p**<br>**TOL**<br>**4 mg**|<br> <br>**Placeb**<br>**o**|**Val**<br>**or p**|
||**vs, Placebo**<br>OR: 1,04 (IC<br>95%: 0,89,<br>1,21); I2: 6%<br>(p: 0,36); 4<br>ECR; n<br>MIRA: 1544;<br>n placebo:<br>1548|0,92|I2: 36% (p:<br>0,20); 4 ECR; n<br>MIRA: 1549; n<br>placebo: 1456|||||||||||||
||**MIRA 100**<br>**mg vs,**<br>**Placebo**<br>OR: 0,99 (IC<br>95%: 0,83,|||||||||||||||
||1,19); I2: 26%<br>(p: 0,25); 4<br>ECR; n<br>MIRA: 1162;<br>n placebo:<br>1182|||||||||||||||
|Hiperten<br>são|NR|NR|NR|NR|OR: 0,<br>95%: 0,6<br>I2: 0% (<br>3ECR;n|91 (IC<br>8, 1,21);<br>p: 0,59);<br>MIRA:|0,52|<sup>OR: 1</sup><br>95%|<sup>,02 (IC</sup><br>: NR)|0,90|OR: 1,<br>95%:|41 (IC<br>NR)|0,08<br>|NR|NR|  
120  
||**W**|**u et a**|**l, 2014(89)**||**Cui et**|**al, 2013(**|**90)**|**Salvi et**|**al, 20**|**17; Seba**|**stianelli**|**et al,**|**2017 (80,**|**91)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**||||<br>||||**MIR**<br>||**MIRA**|||<br>|||
|**adversos**|**MIR**<br>**A**<br>**Placeb**<br>**o**|**Val**<br>**or p**|**MIRA**<br>**TOL  4**<br>**mg**|<br>**Val**<br>**or p**|**MIRA**<br>**50 mg**|**Placeb**<br>**o**|**Val**<br>**or p**|**A 50**<br>**mg**<br>**Placeb**<br>**o**|**Val**<br>**or p**|<br>**100**<br>**mg**|**Placeb**<br>**o**|**Val**<br>**or p**|<br>**TOL**<br>**4 mg**<br>**P**|**laceb**<br>**o**|**Val**<br>**or p**|
||||||1380; n<br>13|placebo:<br>85||||||||||
|EAET-<br>Cardiova<br>sculares|NR|NR|NR|NR|**Arrit**<br>**card**<br>OR: 1,<br>95%: 0,9<br>I2: 0% (<br>3 ECR;<br>1379; n<br>13|**mias**<br>**íacas**<br>67 (IC<br>5, 2,92);<br>p: 0,51);<br>n MIRA:<br>placebo:<br>84|0,07|OR: 1,0 (IC<br>95%: NR)|1|OR: 2,<br>95%:|18 (IC<br>NR)|0,06|<br>NR||NR|
||||||OR: 0,<br>95%: 0,0|25 (IC<br>5, 1,18);||||||||||
|Retenção<br>urinária|NR|NR|NR|NR|I2: 0% (<br>3 ECR;<br>1379; n<br>13|p: 0,90);<br>n MIRA:<br>placebo:<br>84|0,08|NR|NR|N|R|NR|NR||NR|
|Boca<br>seca|NR|NR|NR|NR|NR|NR|NR|OR: 2,49 (IC<br>95%: NR)|<0,<br>000<br>01|OR: 2,<br>95%:|43 (IC<br>NR)|<0,<br>000<br>1|OR: 2,9<br>95%: N|7 (IC<br>R)|<0,<br>000<br>1|
|Constipa<br>ção|NR|NR|NR|NR|NR|NR|NR|NR|NR|N|R|NR|NR||NR|
|Visão<br>turva|NR|NR|NR|NR|NR|NR|NR|NR|NR|N|R|NR|NR||NR|  
121  
||**W**|**u et al, 2014(8**|**9)**||**Cui et a**|**l, 2013(**|**90)**||**Salvi et**|**al, 20**|**17; Seba**|**stianelli**|**et al,**|**2017 (**|**80, 91)**||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**||||||||**MIR**|||**MIRA**||||||
|**adversos**|<br>**MIR**<br> <br>**Placeb**|**Val**<br>**MIRA**|**TOL  4**|**Val**|**MIRA**<br>|**Placeb**|**Val**|**A 50**|**Placeb**|**Val**|<br>**100**|**Placeb**|**Val**|**TOL**<br>|**Placeb**|**Val**|
||**A**<br>**o**|**or p**|**mg**|**or p**|**50 mg**|**o**|**or p**|**mg**|**o**|**or p**|**mg**|**o**|**or p**|<br>**4 mg**|**o**|**or p**|
|Desconti|||||OR: 1,2<br>95%: 0,84|2 (IC<br>, 1,76);|||||||||||
|nuação<br>devido a|NR|NR<br>|NR|NR|I2: 28<br>0,24); 4|% (p:<br>ECR; n|0,29|<sup>OR: 0</sup><br>95%|<sup>,97 (IC</sup><br>: NR)|0,80|OR: 0,<br>95%:|89 (IC<br>NR)|0,63|<sup>OR: 1</sup><br>95%|<sup>,42 (IC</sup><br>: NR)|0,12|
|EA|||||MIRA: 1<br>placebo|759; n<br>:1765|||||||||||  
MIRA: mirabegrona; TOL: tolterodina; ECR: ensaio clínico randomizado;EAET: eventos adversos emergentes do tratamento; EATE relacionada com a medicamento: cuja relação com o medicamento de estudo não poderia ser descartada; OR: Odds ratio ou razão de chances; NR: não reportado; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos,  
122  
**Tabela 14 – Desfechos de segurança da revisão sistemática com meta-análise em rede que compararam Mirabegrona** **_versus_ OnabotulinumtoxinA ou Antimuscarínicos.**  
|**Eventos**|||||||**Maman et al, 2**|**014(9**|**6)**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**<br>Boca seca|**TO**<br>**L**<br>**MI**<br>**RA**<br>**TOL 4**<br>**mg LP**<br>OR: 4,257<br>(IC 95%:<br>2,738,6,3<br>88)<br>**TOL 4**<br>**mg LI**<br>OR:7,290<br>(IC 95%:<br>4,365,11,<br>640)|**Val**<br>**or p**<br><0,<br>05<br><0,<br>05|**DA**<br>**RI**<br>**MI**<br>**RA**<br>**DARI 15**<br>**mg**OR:<br>8,378 (IC<br>95%:<br>4,296,14,<br>940)<br>**DARI 7,5**<br>**mg**<br>OR:<br>5,201 (IC<br>95%:<br>2,452,9,8<br>35)|**Val**<br>**or p**<br><0,<br>05<br><0,<br>05|**FES**<br>**O**<br>**MIR**<br>**A**<br>**FESO 4mg**<br>OR: 4,572<br>(IC 95%:<br>2,698,7,350)<br>**FESO 8mg**<br>OR: 9,976<br>(IC 95%:<br>6,132,15,440<br>)|**Val**<br>**or p**<br><0,<br>05<br><0,<br>05|**OXI**<br>**MIRA**<br>**OXI LP a) 10**<br>**mg; b) 15 mg c)**<br>**5 mg**<br>a) OR: 7,049 (IC<br>95%:<br>3,888,11,960)<br>b) OR: 8,159 (IC<br>95%:<br>2,828,18,710)<br>c) OR: 4,223 (IC<br>95%:<br>1,520,9,511)<br>**OXI LI a) 10**<br>**mg; b) 15 mg c)**<br>**9 mg**<br>a) OR: 14,628<br>(IC 95%:<br>6,497,28,050)<br>b) OR: 40,702<br>(IC 95%:<br>15,210,91,590)<br>c) OR:11,169|**Val**<br>**or p**<br><0,<br>05<br><0,<br>05<br><0,<br>05<br><0,<br>05<br><0,<br>05<br><0,<br>05|**Placeb**<br>**o**<br>**MIR**<br>**A**<br>OR: 1,344 (IC<br>95%: 0,863,<br>2,004)|**Val**<br>**or p**<br>>0,<br>05|**SO**<br>**LI**<br>**MIR**<br>**A**<br>**SOLI 10**<br>**mg**<br>OR: 10,297<br>(IC 95%:<br>6,008,16,6<br>40)<br>**SOLI 5 mg**<br>OR: 4,213<br>(IC 95%:<br>2,431,6,89<br>7)|**Val**<br>**or p**<br><0,<br>05<br><0,<br>05|**TR**<br>**O**<br>**MI**<br>**RA**<br>**TRO 60**<br>**mg**<br>OR:<br>10,297<br>(IC 95%:<br>2,997,10,<br>790)<br>**TRO 30**<br>**mg**<br>OR: 4,848<br>(IC 95%:<br>1,655,11,<br>590)|**Valo**<br>**rp**<br><0,0<br>5<br><0,0<br>5|  
123  
|**Eventos**|||||||**Maman et al, 2**|**014(9**|**6)**|||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**|**TO**<br>**L**<br>**MI**<br>**RA**|**Val**<br>**or p**|**DA**<br>**RI**<br>**MI**<br>**RA**|**Val**<br>**or p**|**FES**<br>**O**<br>**MIR**<br>**A**|**Val**<br>**or p**|**OXI**<br>**MIRA**<br>(IC 95%:<br>5,620,20,210)|**Val**<br>**or p**|**Placeb**<br>**o**|**MIR**<br>**A**|**Val**<br>**or p**|**SO**<br>**LI**<br>**MIR**<br>**A**|**Val**<br>**or p**|**TR**<br>**O**<br>**MI**<br>**RA**|**Valo**<br>**rp**|
|Constipaç<br>ão|**TOL 4**<br>**mg LP**<br>OR: 1,105<br>(IC 95%:<br>2,738,6,3<br>88)<br>**TOL 4**<br>**mg LI**<br>OR:1,020<br>(IC 95%:<br>0,587,1,6<br>52)|<0,<br>05<br>>0,<br>05|**DARI 15**<br>**mg**OR:<br>3,151 (IC<br>95%:<br>1,671,5,4<br>80)<br>**DARI 7,5**<br>**mg**<br>OR:<br>1,720 (IC<br>95%:<br>0,801,3,2<br>33)|<0,<br>05<br>>0,<br>05|**FESO 4mg**<br>OR: 1,064<br>(IC 95%:<br>0,575,1,802)<br>**FESO 8mg**<br>OR: 1,914<br>(IC 95%:<br>1,135,3,032)|>0,<br>05<br><0,<br>05|**OXI LP a) 10**<br>**mg; b) 15 mg c)**<br>**5 mg**<br>a) OR: 1,014 (IC<br>95%:<br>0,522,1,782)<br>b) OR: 2,160 (IC<br>95%:<br>0,268,8,279)<br>c) OR: 2,452 (IC<br>95%:<br>0,417,8,649)<br>**OXI LI a) 10**<br>**mg; b) 15 mg c)**<br>**9 mg**<br>a) OR: 2,452 (IC<br>95%:<br>0,417,8,649)<br>b) OR: 1,549 (IC<br>95%:<br>0,403,4,145)<br>c) OR: 0,986 (IC|>0,<br>05<br>>0,<br>05<br>>0,<br>05<br>>0,<br>05<br>>0,<br>05<br>>0,<br>05|OR: 0,7<br>95%<br>0,484,1|32 (IC<br>:<br>,066)|>0,<br>05|**SOLI 10**<br>**mg**<br>**OR: 4,237**<br>**(IC 95%:**<br>**2,471,6,86**<br>**0)**<br>**SOLI 5 mg**<br>**OR: 2,379**<br>**(IC 95%:**<br>**1,353,**<br>**3,911)**|<0,<br>05<br><0,<br>05|**TRO 60**<br>**mg**<br>OR: 1,694<br>(IC 95%:<br>0,881,2,9<br>76)<br>**TRO 30**<br>**mg**<br>OR: 7,603<br>(IC 95%:<br>2,076,<br>22,660)|>0,0<br>5<br><0,0<br>5|  
124  
|**Eventos**|||||||**Maman et al, 2**|**014(9**|**6)**||||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**|**TO**<br>**L**<br>**MI**<br>**RA**|**Val**<br>**or p**|**DA**<br>**RI**<br>**MI**<br>**RA**|**Val**<br>**or p**|**FES**<br>**O**<br>**MIR**<br>**A**|**Val**<br>**or p**|**OXI**<br>**MIRA**<br>95%:<br>0,407,1,992)|**Val**<br>**or p**|**Placeb**<br>**o**|**MIR**<br>**A**|**Val**<br>**or p**|**SO**<br>**LI**<br>**MIR**<br>**A**|**Val**<br>**or p**<br>**TR**<br>**O**<br>**MI**<br>**RA**|**Valo**<br>**rp**|
|Visão<br>turva|**TOL 4**<br>**mg LP**<br>OR: 1,439<br>(IC 95%:<br>0,556,3,1<br>03)<br>**TOL 4**<br>**mg LI**<br>OR:1,145<br>(IC 95%:<br>0,383,2,6<br>96)|>0,<br>05<br>>0,<br>05|**DARI 7,5**<br>**mg**OR:<br>1,323 (IC<br>95%:<br>0,227,4,3<br>56)|>0,<br>05|**FESO 4mg**<br>OR: 0,797<br>(IC 95%:<br>0,041,3,719)<br>**FESO 8mg**<br>OR: 0,729<br>(IC 95%:<br>0,037,3,399)|>0,<br>05<br>>0,<br>05|**OXI LP a) 10**<br>**mg; b) 15 mg c)**<br>**5 mg**<br>a) OR: 2,603 (IC<br>95%:<br>0,204,11,970)<br>b) OR: 7,162 (IC<br>95%:<br>0,020,41,810)<br>c) OR: 4,965 (IC<br>95%:<br>0,048,28,120)<br>**OXI LI a) 10**<br>**mg; b) 15 mg c)**<br>**9 mg**<br>a) NR<br>b) OR: 2,466 (IC<br>95%:<br>0,072,14,020)<br>c) OR: 0,415 (IC<br>95%: 0,0002,<br>2,614)|>0,<br>05<br>>0,<br>05<br>>0,<br>05<br>NR<br>>0,<br>05<br>>0,<br>05|OR: 5,2<br>95%<br>0,912,1|69 (IC<br>:<br>8,360)|>0,<br>05|**SOLI 10**<br>**mg**<br>**OR: 0,791**<br>**(IC 95%:**<br>**0,303,1,71**<br>**2)**<br>**SOLI 5 mg**<br>**OR:1,935**<br>**(IC 95%:**<br>**0,667,4,47**<br>**8)**|<br>>0,<br>05<br>>0,<br>05<br>**TRO 60**<br>**mg**<br>OR: 0,750<br>(IC 95%:<br>0,235,1,8<br>18)<br>**TRO 30**<br>**mg**<br>OR: 2,418<br>(IC 95%:<br>0,145,11,<br>790)|>0,0<br>5<br>>0,0<br>5|  
125  
MIRA: mirabegrona 50 mg, DARI: Darifenacina; FESO: fesoterodina,; TRO: Trospium; OXI: Oxibutinina; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; OR: Odds ratio ou razão de chances; DM: diferença de médias; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos; NA: não se aplica; NR: não reportado; NS: não significativo,  
**Tabela 15 – Desfechos de segurança dos ensaios clínicos randomizados que compararam Mirabegrona** **_versus_ Placebo ou Tolterodina.**  
|**Eventos adversos**||**Ya**|**maguchi et al, 2**|**015(98)**|||**Kuo et al, 20**|**15(88)**||
|---|---|---|---|---|---|---|---|---|---|
|**n (%)**|**MIRA 25**<br>**mg**|**MIRA 50**<br>**mg**|**MIRA 100**<br>**mg**|**Placebo**|**Valor p**|**MIRA 50mg**|**TOL 4mg**|**Placebo**|**Valor**<br>**p**|
||||||Dose-resposta:|||||
|EAET|169 (80,5)|171 (82,2)|175 (84,1)|157 (74,1)|0,009;<br>MIRA 50 vs,<br>Placebo: 0,046;<br>MIRA 100 vs,<br>Placebo:0,012|36 (42,4)|40 (49,4)|33 (42,9)|NS|
|EAET Sérios|3 (1,4)|1 (0,5)|1 (0,5)|4 (1,9)|NR|0|5 (6,2)|1 (1,3)||  
126  
|**Eventos adversos**||**Yam**|**aguchi et al, 2**|**015(98)**|||**Kuo et al, 20**|**15(88)**||
|---|---|---|---|---|---|---|---|---|---|
|**n (%)**|**MIRA 25**<br>**mg**|**MIRA 50**<br>**mg**|**MIRA 100**<br>**mg**|**Placebo**|**Valor p**|**MIRA 50mg**|**TOL 4mg**|**Placebo**|**Valor**<br>**p**|
|EAET<br>relacionados aos<br>medicamentos|49 (23,3)|51 (24,5)|54 (26,0)|40 (18,9)|Dose-resposta:<br>0,084; NS vs,<br>Placebo|20 (23,5)|24 (29,6)|19 (24,7)|NR|
|EAET sérios||||||||||
|relacionados aos<br>medicamentos|1|0|1|1|NR|0|0|0|NR|
|Hipertensão|2 (1)|1 (0,5)|1 (0,5)|0|NR|2 (2,4)|1 (1,2)|0|NR|
|EAET-|Taquicardia:<br>0|Taquicardia:<br>1 (0,5)|Taquicardia:0|<br>Taquicardia:<br>0||||||
|Cardiovasculares|Palpitações:<br>1(0,5)|Palpitações:<br>4(1,9)|Palpitações:<br>1 (0,5)|Palpitações:<br>1(0,5)|NR|n:6|n:9|n:10|NR|
|Infecção do trato<br>urinário|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Retenção urinária|NR|NR|NR|NR|NR|0|0|0|NR|
|Desordens<br>gastrointestinais|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Boca seca|2 (1,0)|3 (1,4)|2 (1,0)|1 (0,5)|NR|6 (7,1%)|7 (8,6%)|3 (3,9)|NR|
|Constipação|1 (0,5)|5 (2,4)|6 (2,9)|3 (1,4)|NR|NR|NR|NR|NR|
|Visão turva|0|0|0|0|NR|NR|NR|NR|NR|  
127  
|**Eventos adversos**||**Yam**|**aguchi et al, 2**|**015(98)**|||**Kuo et al, 20**|**15(88)**||
|---|---|---|---|---|---|---|---|---|---|
|**n (%)**|**MIRA 25**<br>**mg**|**MIRA 50**<br>**mg**|**MIRA 100**<br>**mg**|**Placebo**|**Valor p**|**MIRA 50mg**|**TOL 4mg**|**Placebo**|**Valor**<br>**p**|
|Dor de cabeça|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Reações de<br>Hipersensibilidade|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Descontinuação<br>devido a EAET|5 (2,4)|7 (3,4)|8 (3,8)|4 (1,9)|NR|2 (2,4%)|1 (1,2%)|1 (1,3%)|NR|
|Descontinuação<br>devido a EAET<br>relacionados aos<br>medicamentos|1 (0,5)|5 (2,4)|6 (2,9)|2 (0,9)|NR|1 (1,2%)|0|1 (1,3%)|NR|
|Morte devido ao<br>EA|0|0|0|0|NA|0|0|1 (1,3)|NA|  
MIRA: mirabegrona; TOL: tolterodina; ECR: ensaio clínico randomizado;EAET: eventos adversos emergentes do tratamento; EATE relacionada com o medicamento: cuja relação com o medicamento de estudo não poderia ser descartada; EA: eventos adversos; NA: não se aplica; NR: não reportado,

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.1.2 Mirabegrona versus Placebo ou Tolterodina: análises exploratórias estratificadas por sexo** -->
128

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **Tabela 16 – Características dos estudos que realizaram análises exploratórias do Mirabegrona** **_versus_ Placebo ou Tolterodinaestratificadas por sexo.** -->
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Tubaro**<br>**et al,**<br>**2017(93)**|Observacional<br>(análise<br>combinada de 5<br>ECR)|Analisar dados<br>somente da<br>população<br>masculina de 5<br>ECR que<br>incluíam a<br>população geral<br>com BH|Homens com<br>sintomas de BH<br>por ≥3 meses e<br>os estudos<br>também<br>poderiam incluir<br>homens com<br>histórico de<br>sintomas do trato<br>urinário inferior<br>associado com<br>alargamento<br>prostático<br>benigno ou<br>câncer de<br>próstata|5 ECR<br>ECR SCORPIO/<br>ARIES/<br>CAPRICORN:<br>MIRA 50 mg (382)<br>vs, Placebo (362)<br>ECR TAURUS:<br>MIRA 50 mg (204)<br>vs, TOL 4 mg (206)<br>ECR BEYOND:<br>MIRA 50 mg (222)<br>vs, SOLI (221)|MIRA 50 mg<br>MIRA 50 mg<br>MIRA 50 mg,|Placebo<br>TOL 4 mg<br>SOLI 5 mg|Alto risco de viés<br>Combinação de ECR,<br>perda do efeito da<br>randomização; não há<br>análises da<br>heterogeneidade; inclui<br>estudo de superioridade e<br>não-inferioridade|
|**Sand et**<br>**al,**<br>**2013(94)**|Observacional<br>(análise<br>combinada de 3<br>ECR) / resumo<br>de congresso|Analisar a<br>eficácia e<br>tolerabilidade<br>do MIRA 50 e<br>100 mg em<br>mulheres com<br>BH|Mulheres com<br>sintomas de BH<br>por ≥3 meses;<br>FMM≥8 vezes<br>em 24h; EPU≥3<br>episódios com ou<br>sem IU|3 ECR<br>PTA/ PIU:<br>ECR SCORPIO/<br>ARIES/<br>CAPRICORN:<br>MIRA 50 mg (942/<br>694) vs,Placebo|MIRA 50 mg<br>MIRA 100 mg|Placebo|Alto risco de viés<br>Resumo de congresso não<br>contém todas as<br>informações relevantes<br>para julgamento;<br>combinação de ECR,<br>perda do efeito da|  
129  
|**Autor**|**Desenho do**<br>**estudo**|**Objetivo**|**População**|**Número de estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|||||(724)|||randomização; não há<br>análises da|
|||||ECR SCORPIO/|||heterogeneidade; inclui|
|||||ARIES: MIRA 100|||estudo de superioridade e|
|||||mg (649/ 483) vs,<br>Placebo(724/ 966)|||não-inferioridade|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; FMM: frequência média de micção; IU: incontinência urinária; EPU: episódios de urgência; PTA: população total analisada; PIU: população com incontinência urinária,  
**Tabela 17 – Características dos participantes dos estudos que realizaram análises exploratórias do Mirabegrona** **_versus_ Placebo ou Tolterodina estratificadas por sexo.**  
|**Autor, ano**|**Intervenção**<br>**, PTA (n)**|**Controle,**<br>**PTA (n)**|**Idade**<br>**Intervenção**<br>**Média (DP):**|**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenç**<br>**ão**|**n (%)**<br>**sexo**<br>**masculin**<br>**o**<br>**Controle**|**Variáveis clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**e bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
|**Tubaro et**|MIRA 50|Plb|||n/N (%):|n/N (%):|**População BH**|**População BH**|12 semanas|
|**al, 2017(93)**|<br>mg (382)|aceo<br>(362)|62,8 (11,3)|62,1 (12,8)|382/1324<br>(28,9)|362/1328<br>(27,3)|**IUU, n (%)**<br>141(36,9)|**IUU, n (%)**<br>130(35,9)|de<br>tratamento|  
130  
|**Autor, ano**|**Intervenção**<br>**, PTA (n)**|**Controle,**<br>**PTA (n)**|**Idade**<br>**Intervenção**<br>**Média (DP):**|<br>**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenç**<br>**ão**|**n (%)**<br>**sexo**<br>**masculin**<br>**o**<br>**Controle**|**Variáveis clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis clínicas**<br>**e bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
|**(Homens:**<br>**análise**<br>**combinada**|MIRA 50<br>mg (204)|TOL 4<br>mg (206)|61,6 (11,5)|61,7 (12,0)|n/N (%):<br>204/789<br>(25,9)|n/N (%):<br>206/791<br>(26,0)|**População BH**<br>**IUU, n (%)**<br>76 (37,3)|**População BH**<br>**IUU, n (%)**<br>67(32,5)|(SCORPIO/<br>ARIES/<br>CAPRICOR|
|**de ECR)**|MIRA 50<br>mg (222)|SOLI 5<br>mg (221)|58,1 (15,1)|59,5 (14,6)|n/N (%):<br>222/921<br>(24,1)|n/N (%):<br>221/912<br>(24,2)|**População BH**<br>**IUU, n (%)**<br>74 (33,3)|**População BH**<br>**IUU, n (%)**<br>78 (35,3)|N/BEYOND<br>)<br>52 semanas<br>(TAURUS)|
|**Sand et al,**<br>**2013(94)**|MIRA 50<br>mg||58,5||NR||NR||14 semanas:<br>2 semanas|
||||||||||de período|
|**(Mulheres:**<br>**análise**<br>**combinada**<br>**de ECR/**<br>**resumo)**|MIRA 100<br>mg|Placebo|58,7|58,1|NR|NR|NR|NR|de<br>eliminação e<br>12 semanas<br>de<br>tratamento|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado;BH: bexiga hiperativa;IUU: incontinência urinária de urgência,  
131  
**Tabela 18 –  Desfechos de eficácia dos estudos que realizaram análises exploratórias do Mirabegrona** **_versus_ Placebo ou Tolterodina estratificadas por sexo.**  
|||**EIU em 24 h (DM entre a**<br>||**Número médio de**<br>**micções em 24 h (DM**||**Episódios de urgência em**<br>**24h**||
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Grupos**|**linha de base e 12**<br>**semanas)**|**Valor p**|<br>**entre a linha de base e 12**<br>**semanas)**|**Valor p**|<br>**(DM entre a linha de base e**<br>**12 semanas)**|**Valor p**|
|||**PIU§**<br>Basal, média (DP)<br>MIRA 50 mg basal: 2,2<br>(2,45)||Basal, média (DP)<br>MIRA 50 mg: 12,0 (3,4)<br>Placebo: 11,7 (3,4)||Basal, média (DP)<br>MIRA 50 mg basal: 5,45<br>(3,9)||
|||Placebo basal: 2,1 (2,77)||DM (IC 95%) basal e 12||Placebo basal: 5,02 (3,2)||
|**Tubaro et**<br>**al,**<br>**2017(93)**<br>**(Homens:**<br>**análise**<br>**combinada**<br>**de ECR)**|<br>MIRA 50 mg<br>vs, Placebo<br>(3 ECR)|DM basal e 12 semanas<br>MIRA: -1,48 (−1,78,<br>−1,18)<br>Placebo: -1,41 (−1,72,<br>−1,10)<br>∆ (MIRA) - (Placebo):<br>-0,07(IC 95%:-0,50, 0,36)|<0,05<br><0,05<br>NS|semanas<br>MIRA: -1,29 (−1,55,<br>−1,04)<br>Placebo: -0,92 (−1,18,<br>−0,66)<br>∆ (MIRA) - (Placebo):<br>-0,37 (IC 95%: -0,74, -<br>0,01)|<0,05<br><0,05<br><0,05|DM (IC 95%) basal e 12<br>semanas<br>MIRA: -1,60 (−1,93, −1,27)<br>Placebo: -1,88 (−2,23, −1,54)<br>∆ (MIRA) - (Placebo):<br>0,28 (IC 95%: -0,19, 0,76)|<0,05<br><0,05<br>NS|
||MIRA 50 mg<br>vs, TOL 4<br>mg|**PIU§**<br>MIRA 50 mg basal: 1,9<br>(2,41)<br>TOL 4 mgbasal:1,9 (2,55)||MIRA 50 mg basal: 11,4<br>(2,8)<br>TOL 4 mg basal: 11,4 (3,0)||MIRA 50 mg basal: 5,2 (3,5)<br>TOL 4 mg basal: 4,8 (3,6)||  
132  
|||**EIU em 24 h (DM entre a**<br>||**Número médio de**<br>**micções em 24 h (DM**||**Episódios de urgência em**<br>**24h**||
|---|---|---|---|---|---|---|---|
|**Autor, ano**|**Grupos**|**linha de base e 12**<br>**semanas)**|**Valor p**|<br>**entre a linha de base e 12**<br>**semanas)**|**Valor p**|**(DM entre a linha de base e**<br>**12 semanas)**|**Valor p**|
|||**PIU§**<br>Basal, média (DP)<br>MIRA 50 mg basal: 2,13<br>(1,85)<br>SOLI 5 mg basal: 2,31<br>(2,16)||Basal, média (DP):<br>MIRA 50 mg basal: 11,8<br>(3,1)<br>SOLI 5 mg basal: 11,6<br>(2,4)||Basal, média (DP):<br>MIRA 50 mg basal: 7,6 (4,9)<br>SOLI 5 mg basal: 7,3 (4,4)||
||SOLI 5 mg<br>vs, MIRA 50<br>mg|DM (IC 95%) basal e 12<br>semanas<br>MIRA: −2,02 (−2,27,<br>−1,77)<br>SOLI: −1,74 (−1,99,<br>−1,49)<br>∆ (SOLI) - (MIRA):<br>+0,28 (–0,08, 0,64)|<0,05<br><0,05<br>NS|DM (IC 95%) basal e 12<br>semanas<br>MIRA: -2,97 (−3,32,<br>−2,63)<br>SOLI: -3,10 (−3,45, −2,76)<br>∆ (SOLI) - (MIRA):<br>-0,13 (IC 95%: -0,62, 0,36)|<0,05<br><0,05<br>NS|DM basal e 12 semanas<br>MIRA: -4,43 (−4,88, −3,98)<br>SOLI: -4,67 (−5,12, −4,22)<br>∆ (SOLI) - (MIRA):<br>-0,24 (IC 95%: -0,88, 0,40)|<0,05<br><0,05<br>NS|
|**Sand et al,**<br>**2013(94)**<br>**(Mulheres:**|MIRA 50 mg|**PIU§**<br>Basal (EP): 2,83 (0,10)<br>DM (IC 95%): −1,50<br>(−1,65,−1,35)|<0,05|Basal (EP): 11,60 (0,12)<br>DM (IC 95%): −1,93<br>(−2,09, −1,77)|<0,05|**PIU§**<br>Basal (EP): 2,46 (0,09)<br>DM (IC 95%): −1,35 (−1,49,<br>−1,22)|<0,05|
|**análise**<br>**combinada**<br>**de ECR/**<br>**resumo)**|MIRA 100<br>mg|**PIU§**<br>Basal (EP): 2,94 (0,12)<br>DM (IC 95%): −1,50<br>(−1,68,−1,32)|<0,05|Basal (EP): 11,56 (0,10)<br>DM (IC 95%): −1,79<br>(−1,99, −1,59)|<0,05|**PIU§**<br>Basal (EP): 2,64 (0,11)<br>DM (IC 95%): −1,34 (−1,50,<br>−1,18)|<0,05|  
133  
|**Autor, ano**|**Grupos**|**EIU em 24 h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valor p**|**Número médio de**<br>**micções em 24 h (DM**<br>**entre a linha de base e 12**<br>**semanas)**|**Valor p**|**Episódios de urgência em**<br>**24h**<br>**(DM entre a linha de base e**<br>**12 semanas)**|**Valor p**|
|---|---|---|---|---|---|---|---|
||Placebo|**PIU§**<br>Basal (EP): 2,86 (0,10)<br>DM (IC 95%): −1,03<br>(−1,17,−0,89)|<0,05|Basal (EP): 11,54 (0,10)<br>DM (IC 95%): −1,31<br>(−1,47, −1,15)|<0,05|**PIU§**<br>Basal (EP): 2,49 (0,09)<br>DM (IC 95%): −0,89 (−1,02,<br>−0,76)|<0,05|
||MIRA 50 mg<br>vs, Placebo|**PIU§**∆<br>(MIRA 50) - (Placebo):<br>−0,47 (IC 95%: −0,67,<br>−0,26)|<0,05|(MIRA 50) - (Placebo):<br>−0,62 (IC 95%: −0,85,<br>−0,39)|<0,05|**PIU§**∆<br>(MIRA 50) - (Placebo):<br>−0,46 (IC 95%: −0,65,<br>−0,28)|<0,05|
||MIRA 100<br>mg vs,<br>Placebo|**PIU§**<br>∆ (MIRA 100) - (Placebo):<br>−0,47 (IC 95%: −0,70,<br>−0,23)|<0,05|∆ (MIRA 100) - (Placebo):<br>−0,48 (IC 95%: −0,74,<br>−0,22)|<0,05|**PIU§**<br>∆ (MIRA 100) - (Placebo):<br>−0,45 (IC 95%: −0,67,<br>−0,24)|<0,05|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; IU: incontinência urinária; IUU: incontinência urinária de urgência; EIU: episódios de incontinência urinária; PIU§: população com incontinência: participantes que apresentaram mais de 1 EIU na linha de base;NA: não se aplica; NR: não reportado; DM: diferença de médias; ∆: diferença; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos; NS: não significativo; NT: não testado.  
134  
**Tabela 19–  Desfechos de segurança dos estudos que realizaram análises exploratórias do Mirabegrona** **_versus_ Placebo ou Tolterodina estratificadas por sexo.**  
|**Eventos adversos**<br>**n (%)**|<br>|**(Home**|**Tubaro et**<br>**ns: análise**<br>|**al, 2017(93**<br>**combinada**<br>|**)**<br>**de ECR)**<br>|||<br>**(Mulheres**<br>|**Sand et al, 2**<br>**: análise com**<br>**resumo**<br>|**013(94)**<br>**binada de**<br>**)**|**ECR/**<br>|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**MIRA 50**<br>**mg***|**Placebo**|**MIRA**<br>**50mg**|**TOL 4**<br>**mg**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**Valor**<br>**p**|**MIRA 100**<br>**mg**|**MIRA 50**<br>**mg**|**Placebo**|**Valor**<br>**p**|
|EAET|n/N (%):<br>181/393<br>(46,1)|n/N (%):<br>171/378<br>(45,2)|n/N (%):<br>126/210<br>(60,0)|n/N (%):<br>132/212<br>(62,3)|n/N (%):<br>55/224<br>(24,5)|n/N (%):<br>59/225<br>(26,2)|NR|303 (44,9)|466 (47,5)|487 (48,6)|<br>NR|
|EAET Sérios|NR|NR|NR|NR|NR|NR|NR|19 (2,8)|17 (1,7)|19 (1,9)|NR|
|Hipertensão|43 (10,9)|35 (9,3)|26 (12,4)|25 (11,8)|4 (0,4)|4 (0,4)|NR|34 (5,0)|60 (6,1)|70 (7,0)|NR|
|EAET-<br>Cardiovasculares|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Infecção do trato<br>urinário|NR|NR|4 (1,9)|5 (2,4)|NR|NR|NR|18 (2,7)|37 (3,8)|22 (2,2)|NR|
|Retenção urinária|1 (0,3)|1 (0,3)|0|3 (1,4)|1 (0,1)|0|NR|NR|NR|NR|NR|
|Desordens<br>gastrointestinais|Dispepsia:<br>2 (0,5)|Dispepsia:<br>4 (1,1)|Dispepsia:<br>1 (0,5)|Dispepsia:<br>4 (1,9)|Dispepsia: 1<br>(0,1)|<br>Dispepsia:<br>1 (0,1)|<br>NR|NR|NR|NR|NR|
|Boca seca|6 (1,5)|9 (2,4)|7 (3,3)|17 (8,0)|8 (3,5)|15 (6,7)|NR|NR|NR|NR|NR|
|Constipação|8 (2,0)|6 (1,6)|6 (2,9)|4 (1,9)|4 (1,8)|6 (2,7)|NR|NR|NR|NR|NR|
|Visão turva|1 (0,3)|0|3 (1,4)|1 (0,5)|2 (0,2)|0|NR|NR|NR|NR|NR|  
135  
|**Eventos adversos**<br>**n (%)**||**(Home**|**Tubaro et**<br>**ns: análise**|**al, 2017(93**<br>**combinada**|**)**<br>**de ECR)**|||<br>**(Mulheres**|**Sand et al, 2**<br>**: análise com**<br>**resumo**|**013(94)**<br>**binada de**<br>**)**|**ECR/**|
|---|---|---|---|---|---|---|---|---|---|---|---|
||**MIRA 50**<br>**mg***|**Placebo**|**MIRA**<br>**50mg**|**TOL 4**<br>**mg**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**Valor**<br>**p**|**MIRA 100**<br>**mg**|**MIRA 50**<br>**mg**|**Placebo**|**Valor**<br>**p**|
|Dor de cabeça|10 (2,5)|5 (1,3)|5 (2,4)|7 (3,3)|7 (3,1)|3 (1,3)|NR|17 (2,5)|34 (3,5)|37 (3,7)|NR|
|Reações de<br>Hipersensibilidade|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Descontinuação<br>devido a EAET|NR|NR|NR|NR|NR|NR|NR|25 (3,7)|36 (3,7)|31 (3,1)|NR|  
*Valores referentes à estudos diferentes incluídos na análise combinada; MIRA: Mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; n/N (%): número de eventos/ número da população total analisada (porcentagem);EAET: eventos adversos emergentes do tratamento; NR: não reportado,

---

<!-- METADADOS: doenca: Incontinência Urinária não Neurogênica | secao: **6.2 Mirabegrona e Solifenacina monoterapia ou em combinação** **_versus_ Placebo, Mirabegrona ou Solifenacina.** -->
136  
**Tabela 20 – Características dos estudos que realizaram compararam Mirabegrona e Solifenacina monoterapia ou em combinação** **_versus_ Placebo, Mirabegrona ou Solifenacina.**  
|**Autor**|**Desenho do estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes**<br>**do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Herschorn**<br>**et al, 2017;**<br>**Robinson et**<br>**al, 2017**<br>**(102, 103)**|ECR,multinacional,<br>multicêntrico,<br>duplo-cego, grupo-<br>paralelo, Placebo-<br>controlado e ativo-<br>controlado, fase III<br>(NCT01972841)<br>SYNERGY Study|Avaliar a eficácia<br>e segurança do<br>SOLI combinado<br>com MIRA<br>comparado com<br>monoterapia na<br>população com<br>BH geral com IU|Diagnóstico de<br>BH molhada<br>(sintomas de<br>urgência,<br>frequência<br>urinária e IU);<br>FMM≥8 vezes<br>em 24h; EPU≥1;<br>episódios de<br>IU≥3 em 7 dias;|Total: 3527 foram<br>randomizados e<br>3308 foram<br>analisados<br>PR/ PTA<br>SOLI 5 mg +<br>MIRA 50mg:<br>883/848<br>SOLI 5 mg<br>+MIRA 25mg:<br>885/853<br>MIRA 50mg:<br>437/422<br>MIRA 25 mg:<br>441/423<br>SOL 5 mg:<br>434/423<br>Placebo: 447/429|SOLI 5 mg<br>+ MIRA<br>50mg<br>SOLI 5 mg<br>+MIRA<br>25mg|MIRA<br>50mg<br>MIRA<br>25mg<br>SOLI 5 mg<br>Placebo|Alto risco de viés<br>Não foi descrito o método<br>de randomização e sigilo<br>de alocação; não houve<br>cegamento dos<br>avaliadores dos desfechos;<br>desequilíbrio na<br>quantidade de pacientes<br>ou razões para perdas<br>entre os grupos de<br>intervenção, A análise não<br>foi por intenção de tratar<br>(ie, Não foi analisado<br>todos os pacientes que<br>foram randomizados), Não<br>demonstrou todos os<br>dados de todos os<br>desfechos,|  
137  
|**Autor**|**Desenho do estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes**<br>**do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Gratzke et**<br>**al, 2017**<br>**(resumo)(87)**|Resumo de<br>congresso/ ECR,<br>duplo cego, grupo-<br>paralelo|Analisar a<br>eficácia e<br>segurança a longo<br>prazo da<br>combinação<br>MIRA + SOLI<br>versus<br>monoterapia de<br>MIRA eSOLI|Adultos com<br>sintomas de BH<br>por ≥3 meses e<br>≥ 3 EIU|MIRA + SOLI:<br>1210<br>MIRA: 306<br>SOLI: 303|MIRA 50<br>mg + SOLI<br>5 mg|MIRA 50<br>mg<br>SOLI 5 mg|Alto risco de viés<br>Resumo de congresso não<br>contém todas as<br>informações relevantes<br>para julgamento;<br>características basais não<br>foram fornecidas|
|**Drake et al,**<br>**2016;**<br>**MacDiarmid**<br>**et al, 2016**<br>**(104, 105)**|ECR,multicêntrico,<br>duplo-cego, grupo-<br>paralelo, fase IIIb,<br>NCT01908829<br>BESIDE|Avaliar a eficácia,<br>segurança e<br>tolerabilidade da<br>combinação SOLI<br>5 mg e MIRA 50<br>mg versus SOLI 5<br>e 10 mg em<br>pacientes com BH<br>que<br>permaneceram<br>incontinentes<br>após 4 semanas<br>de uso de SOLI 5<br>mg|Pacientes com<br>BH (sintomas<br>≥3 meses com<br>≥2 EIU) que<br>permaneceram<br>incontinentes<br>(≥1 episódio)<br>após 4 semanas<br>de uso de SOLI<br>5 mg|SOLI + MIRA:<br>727 randomizados<br>e 707 analisados<br>PR/PTA<br>SOLI 5 mg:<br>728/705<br>SOLI 10mg:<br>719/648|SOLI 5 mg<br>+ MIRA<br>(25mg após<br>4 semanas<br>aumentou<br>para 50 mg)<br>(SOLI +<br>MIRA)|SOLI 5 mg<br>SOLI 10<br>mg|Risco de viés incerto, Não<br>houve cegamento dos<br>avaliadores dos desfechos,<br>A análise não foi por<br>intenção de tratar (ie, Não<br>foi analisado todos os<br>pacientes que foram<br>randomizados),|  
138  
|**Autor**|**Desenho do estudo**|**Objetivo**|**População**|**Número de**<br>**estudos**<br>**ouparticipantes**<br>**incluídos**|**Detalhes da**<br>**Intervenção**|**Detalhes**<br>**do**<br>**Controle**|**Risco de Viés**|
|---|---|---|---|---|---|---|---|
|**Batista et al**<br>**2015(106)**|ECR, estudo<br>aberto, duplo-cego,<br>fase IIIb, estudo de<br>não inferioridade<br>BEYOND|Comparar a<br>eficácia e<br>segurança do<br>MIRA 50 mg e<br>SOLI 5 mg em<br>pacientes não<br>satisfeitos com<br>tratamento com<br>antimuscarínicos<br>devido à falta de<br>eficácia|Adultos com<br>sintomas de BH<br>por ≥3 meses<br>que<br>demonstraram<br>insatisfação com<br>a eficácia do<br>último<br>antimuscarínicos<br>utilizados<br>(exceto SOLI)<br>por meio do<br>questionário de<br>Satisfação de<br>tratamento de<br>Likert|Total: 1887<br>randomizados<br>PR/ PTA/ PIU:<br>MIRA: 943/ 865/<br>405<br>SOLI: 944/ 854/<br>413|MIRA 50<br>mg|SOLI 5 mg|Risco de viés incerto<br>A análise não foi por<br>intenção de tratar (ie,, não<br>foi analisado todos os<br>pacientes que foram<br>randomizados),|  
MIRA: mirabegrona; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa; FMM: frequência média de micção; EPU: episódio de urgência; IU: incontinência urinária; IUU: incontinência urinária de urgência; PR: população que foi inicialmente randomizada; PTA: população total analisada; PIU: população com incontinência urinária,  
139  
**Tabela 21 – Características dos participantes dos estudos que realizaram compararam Mirabegrona e Solifenacina monoterapia ou em combinação** **_versus_ Placebo, Mirabegrona ou Solifenacina.**  
|**Autor, ano**|**Intervenção,**<br>**PTA (n)**|**Controle,**<br>**PTA (n)**|**Idade**<br>**Intervenção**<br>**Média (DP):**|**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
|**Herschorn**<br>**et al, 2017;**<br>**Robinson et**<br>**al, 2017(102,**<br>**103)**|SOLI 5 mg +<br>MIRA 50mg<br>(883)|MIRA<br>50mg<br>(437)<br>MIRA<br>25mg<br>(441)|57,1 (13,9)|56,7<br>(13,3)<br>56,9<br>(13,6)|656 (76,9)|323 (76,5)<br>327 (77,3)|**População BH**<br>**IUU, n (%)**<br>561 (65,8)<br>**EIU/24h,**<br>**média (DP)**<br>3,16 (3,08)<br>**Micções/24h,**<br>**média (DP)**<br>10,74 (2,36)|**População**<br>**BH IUU, n**<br>**(%)**<br>268 (63,5)<br>**EIU/24h,**<br>**média (DP)**<br>3,18 (3,47)<br>**Micções/24h,**<br>**média (DP)**<br>11,19 (3,27)<br>**População**<br>**BH IUU, n**<br>**(%)**<br>267 (63,1)<br>**EIU/24h,**<br>**média (DP)**<br>3,41 (3,37)<br>**Micções/24h,**<br>**média (DP)**<br>10,81(2,63)|18 semanas:<br>período inicial<br>de 4 semanas de<br>placebo uni-<br>cego, 12<br>semanas de<br>tratamento duplo<br>cego e uma fase<br>final de 2<br>semanas de<br>placebo uni-cego|  
140  
|**Autor, ano**|**Intervenção,**<br>**PTA (n)**|**Controle,**<br>**PTA (n)**|**Idade**<br>**Intervenção**<br>**Média (DP):**|**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
||SOLI 5 mg<br>+MIRA<br>25mg (885)|SOLI 5<br>mg (434)<br>Placebo<br>(447)|57,6 (13,4)|58,2<br>(12,8)<br>57,9<br>(13,0)|651 (76,8)|331 (78,3)<br>327 (76,2)|**População BH**<br>**IUU, n (%)**<br>567 (66,9)<br>**EIU/24h,**<br>**média (DP)**<br>3,22 (3,17)<br>**Micções/24h,**<br>**média (DP)**<br>10,73 (2,88)|**População**<br>**BH IUU, n**<br>**(%)**<br>275 (65,0)<br>**EIU/24h,**<br>**média (DP)**<br>3,58 (3,51)<br>**Micções/24h,**<br>**média (DP)**<br>10,76 (2,47)<br>**População**<br>**BH IUU, n**<br>**(%)**<br>285 (66,4)<br>**EIU/24h,**<br>**média (DP)**<br>3,41 (3,37)<br>**Micções/24h,**<br>**média (DP)**<br>10,97(2,86)||
|**Gratzke et**<br>**al, 2017**<br>**(resumo)(87)**|MIRA +<br>SOLI (1210)|MIRA<br>(306)<br>SOLI<br>(303)|NR|NR<br>NR|NR|NR<br>NR|NR|NR<br>NR|14 semanas: 2<br>semanas de<br>período de<br>eliminação e 12|  
141  
|**Autor, ano**|**Intervenção,**<br>**PTA (n)**|**Controle,**<br>**PTA (n)**|<br>**Idade**<br>**Intervenção**<br>**Média (DP):**|<br>**Idade**<br>**Controle**<br>**Média**<br>**(DP):**|**n (%)sexo**<br>**masculino**<br>**Intervenção**|<br>**n (%)**<br>**sexo**<br>**masculino**<br>**Controle**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Intervenção**|**Variáveis**<br>**clínicas e**<br>**bioquímicas**<br>**relevantes**<br>**Controle**|**Período de**<br>**estudo**|
|---|---|---|---|---|---|---|---|---|---|
||||||||||meses de<br>tratamento|
|||SOLI 5||56,9||121 (172)|||18 semanas: 2|
|**Drake et al,**<br>**2016;**<br>**MacDiarmid**<br>**et al,**<br>**2016(104,**<br>**105)**<br>**BESIDE**|<br>SOLI +<br>MIRA (707)|mg (705)<br>SOLI 5<br>mg (698)|58,0 (13,2)|(13,4)<br>57,3<br>(13,2)|119 (16,8)|,<br>113 (16,2)|Disponível na<br>desfechos d|planilha dos<br>e eficácia|semanas de<br>período de<br>eliminação, 4<br>semanas de<br>SOLI cego, 12<br>semanas de<br>tratamento duplo<br>cego e 2<br>semanas de<br>placebo cego|
|**Batista et al**<br>**2015(106)**<br>**BEYOND**|MIRA 50mg<br>(936)|SOLI 5<br>mg (934)|56,7 (14,3)|57,4<br>(13,6)|224 (23,9)|225 (24,1)|**População BH**<br>**IUU, n (%)**<br>383 (40,9)|**População**<br>**BH IUU, n**<br>**(%)**<br>387 (41,4)|14 semanas: 2<br>semanas de<br>período de<br>eliminação e 12<br>semanas de<br>tratamento|  
MIRA: mirabegrona; SOLI: solifenacina; BH: bexiga hiperativa; PTA: população total analisada; EIU: episódio de incontinência urinária; IUU: incontinência urinária de urgência; NR: não reportado; DP: desvio padrão,  
142  
**Tabela 22 – Desfecho de eficácia dos estudos que compararam Mirabegrona e Solifenacina monoterapia ou em combinação** **_versus_ Placebo, Mirabegrona ou Solifenacina.**  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg|DM basal e 18<br>semanas:–1,76|NR|DM basal e 18<br>semanas:–2,03|NR|NR|NR|NR|NR|
|**Herscho**<br>**t l**|MIRA<br>25mg|DM basal e 18<br>semanas: –1,70|NR|DM basal e 18<br>semanas: –2,00|NR|NR|NR|NR|NR|
|**rn e a,**<br>**2017;**<br>**Robinso**|SOLI 5<br>mg|DM basal e 18<br>semanas:–1,79|NR|DM basal e 18<br>semanas:–2,20|NR|NR|NR|NR|NR|
|**n et al,**<br>**2017**|Placebo|DM basal e 18<br>semanas:–1,34|NR|DM basal e 18<br>semanas:–1,64|NR|NR|NR|NR|NR|
|<br>**(102,**<br>**103)**<br>**SYNER**<br>**GY**|SOLI 5<br>mg +<br>MIRA<br>25mg|DM basal e 18<br>semanas: –2,04|NR|DM basal e 18<br>semanas: –2,49|NR|NR|NR|NR|NR|
|<br>**Study**|SOLI 5<br>mg +<br>MIRA<br>50mg|DM basal e 18<br>semanas: –1,98|NR|DM basal e 18<br>semanas: –2,59|NR|NR|NR|NR|NR|  
143  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
||SOLI 5|∆ (SOLI 5 mg +<br>MIRA 25mg) -<br>(MIRA 25 mg):<br>–0,34 (IC 95%:  –<br>0,58, –0,10)|0,00<br>1|∆ (SOLI 5 mg +<br>MIRA 25mg) -<br>(MIRA 25 mg):<br>–0,48 (IC 95%: –0,76,<br>–0,21)|0,001|||||
||mg +<br>MIRA<br>25mg vs,<br>MIRA 25<br>mg|**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆ –0,33 (IC<br>95%: –0,68, 0,02)<br>Não: ∆ –0,35 (IC|>0,0<br>5<br><0,0<br>5|**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆ –0,75 (IC<br>95%: –1,15, –0,34)<br>Não: ∆ –0,25 (IC|<br><0,05<br>>0,05|NR|NR|NR|NR|
|||95%:–0,68,–0,02)||95%:–0,63, 0,13)||||||
|||∆ (SOLI 5 mg +<br>MIRA 25mg) -||∆ (SOLI 5 mg +<br>MIRA 25mg) - (SOLI||||||
||SOLI 5<br>mg +|(SOLI 5 mg):<br>–0,25 (IC 95%: –|0,07<br>|5 mg):<br>–0,29 (IC 95%: –0,57,|0,040|||||
||MIRA<br>25mg vs,|0,49, –0,01)|2|–0,01)||NR|NR|NR|NR|
||<br>SOLI 5<br>mg|**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**|<0,0|**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**|NS<br>NS|||||  
144  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
|||**BH**<br>Sim: ∆ –0,54 (IC<br>95%: –0,89, –0,19)<br>Não: ∆ 0,01 (IC 95%<br>–0,32, 0,34)|5<br>NS|**BH**<br>Sim: –0,40 (IC 95%:<br>–0,81, 0,00)<br>Não: ∆ –0,19 (IC<br>95%: –0,57, 0,19)||||||
||SOLI 5<br>mg +<br>MIRA<br>50mg vs,<br>MIRA 50<br>mg|∆ (SOLI 5 mg +<br>MIRA 50mg) -<br>(MIRA 50mg)<br>–0,23 (IC 95%: –<br>0,47, 0,01)<br>**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆–0,37 (IC<br>95%: –0,72, –0,01)<br>Não: ∆ –0,11 (IC|0,05<br>2<br><0,0<br>5<br>>0,0<br>5|∆ (SOLI 5 mg +<br>MIRA 50mg) -<br>(MIRA 50mg)<br>–0,56 (IC 95%: –0,84,<br>–0,28)<br>**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆–0,83 (IC 95%:<br>–1,24, –0,42)<br>Não: ∆ –0,32 (IC|<0,001<br><0,05<br>>0,05|NR|NR|NR|NR|
|||95%:–0,44, 0,22)||95%:–0,70, 0,06)||||||  
145  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
|||∆ (SOLI 5 mg +<br>MIRA 50mg) -<br>(SOLI 5 mg)<br>–0,20 (IC 95%: –||∆ (SOLI 5 mg +<br>MIRA 50mg) - (SOLI<br>5 mg)<br>–0,39 (IC 95%: –0,67,||||||
||SOLI 5<br>mg +<br>MIRA<br>50mg vs,<br>SOLI 5<br>mg|0,44, 0,04)<br>**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆–0,39 (IC<br>95%: –0,74, –0,04)|0,03<br>3<br><0,0<br>5<br>>0,0<br>5|–0,11)<br>**Pacientes haviam**<br>**utilizado**<br>**previamente**<br>**medicamentos para**<br>**BH**<br>Sim: ∆–0,57 (IC 95%:<br>–0,97, –0,17)|0,006<br><0,05<br>>0,05|NR|NR|NR|NR|
|||Não: ∆ –0,01 (IC||Não: ∆ –0,24 (IC||||||
|||95%:–0,34, 0,32)||95%:–0,62, 0,14)||||||
||SOLI 5|||||||||
||mg|∆ (SOLI 5 mg +||∆ (SOLI 5 mg +||||||
||+MIRA<br>25 MG|MIRA 25 mg) -<br>(Placebo):|<0,0|MIRA 25 mg) -<br>(Placebo):||NR|NR|NR|NR|
||vs,<br>Placebo|–0,70|5|–  0,85|<0,05|||||
||SOLI 5|∆ (SOLI 5 mg +||∆ (SOLI 5 mg +||||||
||mg<br>+MIRA|MIRA 50 mg) -<br>(Placebo):|<0,0|MIRA 50 mg) -<br>(Placebo):|<005|NR|NR|NR|NR|
||50MG|–0,65|5|–0,95|,|||||  
146  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
||vs,<br>Placebo|||||||||
||MIRA 25|||∆ (MIRA 25 mg) -||||||
||mg vs,<br>Placebo|NR|<0,0<br>5|(Placebo):<br>–0,36|<0,05|NR|NR|NR|NR|
||MIRA|||∆ (MIRA 50 mg) -||||||
||50mg vs,<br>Placebo|NR|NR|(Placebo):<br>–0,39|<0,05|NR|NR|NR|NR|
||SOLI 5|∆ (SOLI 5 mg) -||∆ (SOLI 5 mg) -||||||
||mg vs,<br>Placebo|(Placebo):<br>–0,45|<0,0<br>5|(Placebo):<br>–0,56|<0,05|NR|NR|NR|NR|
||MIRA 50<br>mg|DM (IC 95%) basal<br>e 12 meses:<br>-1,58 (-1,79,-1,37)|<0,0<br>5|DM (IC 95%) basal e<br>12 meses:<br>-2,10 (-2,36,-1,85)|<0,05|NR|NR|NR|NR|
||SOLI 5|DM (IC 95%) basal||DM (IC 95%) basal e||||||
|**Gratzke**<br>**et al**|<br>mg|e 12 meses:<br>-1,90 (-2,12,-1,69)|<0,0<br>5|12 meses:<br>-2,16 (-2,42,-1,91)|<0,05|NR|NR|NR|NR|
|**,**<br>**2017**|MIRA 50<br>+|DM (IC 95%) basal||DM (IC 95%) basal e||||||
|**(resumo**<br>**)(87)**|mg<br>SOLI 5<br>mg|e 12 meses:<br>-2,03 (-2,14, -1,93)|<0,0<br>5|12 meses:<br>-2,58 (-2,71, -2,46)|<0,05|NR|NR|NR|NR|
||MIRA 50|∆ (MIRA +SOLI) -||∆ (MIRA +SOLI) -||||||
||mg +<br>SOLI 5<br>mgvs,|<br>(MIRA):<br>– 0,45 (IC 95%: -<br>0,69,-0,21)|<0,0<br>01|<br>(MIRA):<br>– 0,48 (IC 95%: -0,77,<br>-0,20)|<0,001|NR|NR|NR|NR|  
147  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
||MIRA 50<br>mg<br>MIRA 50<br>mg +<br>SOLI 5<br>mg vs,<br>SOLI 5<br>mg|∆ (MIRA +SOLI) -<br>(SOLI):<br>– 0,13 (IC 95%: -<br>0,37, 0,11)|0,00<br>2|∆ (MIRA +SOLI) -<br>(SOLI):<br>– 0,42 (IC 95%: -0,71,<br>-0,13)|0,004|NR|NR|NR|NR|
||SOLI<br>+MIRA|Basal, média (EP):<br>3,24 (0,11)<br>DM:-1,80|NR|Basal, média (EP):<br>9,13 (0,10)<br>DM:-1,59|NR|DM (EP): –2,95 (0,10)|NR|DM (EP): –1,82<br>(0,07)|NR|
|**Drake**<br>**et al,**<br>|SOLI 5<br>mg|Basal, média (EP):<br>3,15 (0,10)<br>DM:-1,53|NR|Basal, média (EP):<br>8,90 (0,10)<br>DM:-1,14|NR|DM (EP): –2,41 (0,10)|NR|DM (EP):  –1,54<br>(0,07)|NR|
|**2016;**<br>**MacDia**<br>**rmid et**<br>|SOLI 10<br>mg|Basal, média (EP):<br>3,31 (0,12)<br>DM:-1,67|NR|Basal, média (EP):<br>8,97 (0,10)<br>DM:-1,12|NR|DM (EP): –2,54 (0,11)|NR|DM (EP): –1,63<br>(0,07)|NR|
|**al, 2016**<br>**(104,**<br>**105)**<br>**BESID**<br>|SOLI<br>+MIRA<br>vs, SOLI<br>5mg|∆ (SOLI +MIRA) -<br>(SOLI 5 mg:<br>-0,26 (IC 95%: -<br>0,47,-0,05)|0,00<br>1|∆ (SOLI +MIRA) -<br>(SOLI 5 mg:<br>-0,45 (IC 95%: -0,67,<br>-0,22)|<0,001|∆ (SOLI +MIRA) -<br>(SOLI 5 mg): –0,54<br>(0,15) (IC 95%: –0,83,<br>–0,25)|<<br>0,001|<br>∆ (SOLI +MIRA) -<br>(SOLI 5 mg): –0,27<br>(0,10) (IC 95%: –<br>0,47,–0,07)|0,003|
|**E**|SOLI<br>+MIRA<br>vs, SOLI<br>10mg|∆ (SOLI +MIRA) -<br>(SOLI 10 mg:<br>-0,13 (IC 95%: -<br>0,34, 0,08)|0,00<br>8|∆ (SOLI +MIRA) -<br>(SOLI 10 mg:<br>-0,47 (IC 95%: -0,70,<br>-0,25)|<0,001|∆ (SOLI +MIRA) -<br>(SOLI 5 mg): –0,40<br>(0,15) (IC 95%: –0,69,<br>–0,11)|0,007|<br>∆ (SOLI +MIRA) -<br>(SOLI 10 mg): –0,19<br>(0,10) (IC 95%: –<br>0,39, 0,01)|0,014|  
148  
|**Autor,**<br>**ano**|**Grupos**|**EIU em 24 h (DM**<br>**entre a linha de**<br>**base e 12 semanas)**|**Val**<br>**or p**|**Número médio de**<br>**micções em 24 h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valor**<br>**p**|**Episódios de urgência**<br>**em 24h**<br>**(DM entre a linha de**<br>**base e 12 semanas)**|**Valo**<br>**r p**|**Episódios de IUU**<br>**em 24h (DM entre a**<br>**linha de base e 12**<br>**semanas)**|**Valo**<br>**r p**|
|---|---|---|---|---|---|---|---|---|---|
|**Batista**|MIRA<br>50mg|PIU§<br>Basal, média (DP):<br>2,1 (2,3)<br>DM:-1,40|NR|Basal, média (DP):<br>11,6 (3,3)<br>DM (EP): -2,95 (0,09)|NR|PIU§<br>Basal, média (DP): 7,7<br>(4,8)<br>DM:-4,61|NR|PIU§<br>Basal, média (DP):<br>1,9 (2,0)<br>DM:-1,47|NR|
|**et al,**<br>**2015(10**<br>**6)**|SOLI 5<br>mg|PIU§<br>Basal, média (DP):<br>2,1 (2,1)<br>DM:-1,60|NR|Basal, média (DP):<br>11,4 (2,9)<br>DM (EP): -3,13 (0,09)|NR|PIU§<br>Basal, média (DP): 7,8<br>(4,5)<br>DM:-4,84|NR|PIU§<br>Basal, média (DP):<br>2,0 (1,9)<br>DM:-1,53|NR|
|**BEYON**<br>**D**|MIRA<br>50mg vs,<br>SOLI 5<br>mg|NR||∆ (MIRA) - (SOLI):<br>−0,18 (IC 95%:<br>−0,42, 0,06)|*Não<br>inferio<br>r não<br>demon<br>strada|NR||NR||  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina;*A não-inferioridade do MIRA não foi demonstrada uma vez que o limite inferior não foi > −0,20; ECR: ensaio clínico randomizado; BH: bexiga hiperativa;IU: incontinência urinária; IUU: incontinência urinária de urgência;PIU§: população com incontinência: participantes que apresentaram mais de 1 EIU na linha de base;OR: Odds ratio ou razão de chances; DM: diferença de médias; ∆: diferença; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos;NR: não reportado,  
149  
**Tabela 23 – Desfechos de eficácia secundários ou relatados pelos pacientes dos estudos que compararam Mirabegrona e Solifenacina monoterapia ou em combinação** **_versus_ Placebo, Mirabegrona ou Solifenacina.**  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA<br>50 mg|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 21,99||**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-26,1<br>**QVRS total**<br>DM linha de base e 18semanas:21|<0,001 vs,<br>Placebo<br><0,001 vs,<br>Placebo|
|**Herschorn**<br>**et al, 2017;**<br>**Robinson et**<br>**al, 2017**|MIRA<br>25mg|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas:13,32||**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-23,9<br>**QVRS total**<br>DM linha de base e 18semanas**: **18,9|0,001 vs,<br>Placebo<br>=0,004 vs,<br>placebo|
|**(102, 103)**<br>**SYNERGY**<br>**Study**|SOLI 5<br>mg|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 30,99||**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-26,4<br>**QVRS total**<br>DM linha de base e 18semanas:20,2|<0,001 vs,<br>Placebo<br><0,001 vs,<br>placebo|
||Placebo|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 8,44||**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-19,5|NR|  
150  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**<br>**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|
||||||**QVRS total**<br>DM linha de base e 18 semanas: 15,4||
||SOLI 5<br>mg +<br>MIRA<br>25mg|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 34,84|**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-31,1<br>**QVRS total**<br>DM linha de base e 18 semanas: 24|<0,001 vs,<br>Placebo;<0,001<br>vs,<br>Monoterapias<br><0,001 vs,<br>Placebo;<0,001<br>vs,<br>Monoterapias|
||SOLI 5<br>mg +<br>MIRA<br>50mg|NA|NA|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 39,73|**OAB-q Symptom Bother**<br>DM linha de base e 18 semanas:<br>-32,2<br>**QVRS total**<br>DM linha de base e 18 semanas: 24,3|<0,001 vs,<br>Placebo;<br><0,001 vs,<br>Monoterapias<br><0,001 vs,<br>Placebo;<br><0,001 vs,<br>Monoterapias<br>(exceto vs,<br>MIRA 50mg o<br>p:0,002)|  
151  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||SOLI 5<br>mg +<br>MIRA<br>25mg<br>vs,<br>MIRA<br>25 mg|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a)OR:1,50 (IC95%: 1,16,<br>1,93)<br>b) OR:1,47 (IC95%: 1,13,<br>1,90)|0,002<br>0,004|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 21,52<br>(IC 95%: 15,35,<br>27,68)|< 0,001|NR|NR|
||SOLI 5<br>mg +<br>MIRA<br>25mg<br>vs,<br>SOLI 5<br>mg|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a) OR:1,31 (IC95%: 1,02,<br>1,69)<br>b) OR:1,30 (IC95%: 1,01,<br>1,67)|0,035<br>0,044|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 3,85 (IC<br>95%: –2,29,10,0)|0,219|NR|NR|
||SOLI 5<br>mg +<br>MIRA<br>50mg<br>vs,<br>MIRA|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a) OR:1,34 (IC95%: 1,04,|0,023<br><0,001|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 17,74<br>(IC 95%:11,58,|< 0,001|NR|NR|
||50mg|1,73)||23,90)||||  
152  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||b) OR:1,60 (IC95%: 1,23,<br>2,08)||||||
||SOLI 5<br>mg +<br>MIRA<br>50mg<br>vs,<br>SOLI 5<br>mg|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a) OR:1,40 (IC95%: 1,09,<br>1,81)<br>b) OR:1,43 (IC95%: 1,11,<br>1,84)|0,009<br>0,006|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM basal e 18<br>semanas: 8,75 (IC<br>95%: 2,61,14,89)|0,005|NR|NR|
||SOLI 5<br>mg<br>+MIRA<br>25 MG<br>vs,<br>Placebo|**Pacientes com zero**<br>**episódios de IU no fim**<br>**do estudo**<br>OR: 1,75 (IC95%: 1,36,<br>2,26)|<0,001|NR|<0,05|NR|NR|
||SOLI 5<br>mg<br>+MIRA<br>50 MG<br>vs,<br>Placebo|**Pacientes com zero**<br>**episódios de IU no fim**<br>**do estudo**<br>OR: 1,87 (IC95%: (1,45,<br>2,42)|<0,001|∆ (SOLI 5 mg +<br>MIRA 50 mg) -<br>(Placebo):<br>31,29 ml|<0,001|NR|NR|  
153  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA<br>25 mg<br>vs,<br>Placebo|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a) OR: 1,17 (IC95%:<br>0,87, 1,57)<br>b) OR: 1,66 (IC95%:<br>1,22,2,25)|0,300<br>0,001|∆ (MIRA 25 mg) -<br>(Placebo):<br>4,88 ml|0,178|NR|NR|
||MIRA<br>50mg<br>vs,<br>Placebo|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a)OR: 1,40 (IC95%: 1,04,<br>1,87)<br>b) OR: 1,67 (IC95%:<br>1,23,2,27)|0,027<br>0,001|NR|<0,05|NR|NR|
||SOLI 5<br>mg vs,<br>Placebo|**Pacientes com a) zero**<br>**episódios de IU e b)**<br>**normalização da**<br>**frequência miccional no**<br>**fim do estudo**<br>a)OR: 1,34 (IC95%: 0,99,<br>1,79)|0,055<br><0,001|NR|<0,05|NR|NR|  
154  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||b) OR: 1,87 (IC95%:<br>1,38, 2,54)||||||
||MIRA<br>50 mg|NR|NR|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM (IC 95%)<br>basal e 12 meses:<br>21,83 (15,70,<br>27,96)|<0,05|**OAB-q Symptom Bother**<br>DM (IC 95%) basal e 12 meses:<br>-21,96 (-24,20, -19,72)<br>**TS-VAS**<br>DM (IC 95%) basal e 12 meses:<br>2,19 (1,95,2,43)|<0,05<br><0,05|
|**Gratzke et**<br>**al, 2017**|SOLI 5<br>|NR|NR|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM (IC 95%)||**OAB-q Symptom Bother**<br>DM (IC 95%) basal e 12 meses:<br>-24,91 (-27,12, -22,69)|<0,05|
|**(87)(resumo)**|mg|||basal e 12 meses:<br>24,90 (18,82,<br>30,97)|<0,05|**TS-VAS**<br>DM (IC 95%) basal e 12 meses<br>2,15 (1,91,2,38)|<0,05|
||MIRA<br>50 mg +<br>SOLI 5<br>mg|NR|NR|**Volume**<br>**urinado/micção**<br>**(ml)**<br>DM (IC 95%)<br>basal e 12 meses:<br>37,67 (34,62,<br>40,72)|<0,05|**OAB-q Symptom Bother**<br>DM (IC 95%) basal e 12 meses:<br>-29,51 (-30,62, -28,40)<br>**TS-VAS**<br>DM (IC 95%) basal e 12 meses<br>2,73 (2,62,2,85)|<0,05<br><0,05|  
155  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||MIRA<br>50 mg +<br>SOLI 5<br>mg vs,<br>MIRA<br>50 mg|NR|NR|**Volume**<br>**urinado/micção**<br>**(ml)**<br>∆ (MIRA +SOLI)<br>- (MIRA):<br>15,84 (IC 95%:<br>8,99,22,69)|<0,001|**OAB-q Symptom Bother**<br>∆ (MIRA +SOLI) - (MIRA):<br>-7,55 (IC 95%: -10,05, -5,05)<br>**TS-VAS**<br>∆ (MIRA +SOLI) - (MIRA):<br>0,55 (IC 95%: 0,28, 0,82)|<0,001<br><0,001|
||MIRA<br>50 mg +<br>SOLI 5<br>mg vs,<br>SOLI 5<br>mg|NR|NR|**Volume**<br>**urinado/micção**<br>**(ml)**<br>∆ (MIRA +SOLI)<br>- (MIRA):<br>12,77 (IC 95%:<br>5,98,19,57)|<0,001|**OAB-q Symptom Bother**<br>∆ (MIRA +SOLI) - (MIRA):<br>-4,60 (IC 95%: -7,09, -2,12)<br>**TS-VAS**<br>∆ (MIRA +SOLI) - (MIRA):<br>0,59 (IC 95%:0,32, 0,86)|<0,001<br><0,001|
|**Drake et al,**<br>**2016;**<br>**MacDiarmid**<br>**et al, 2016**<br>**(104, 105)**<br>**BESIDE**|SOLI<br>+MIRA|**Respondentes para zero**<br>**incontinência**<br>No fim do estudo, n/N<br>(%):  325/706 (46,0%)||**DM (EP):**<br>**Volume**<br>**urinado/micção**<br>**(ml):**28,05 (1,97)<br>**Episódios de**<br>**noctúria:**<br>–0,43 (0,03)||**DM (EP):**<br>**EPPCB**<br>DM (DP): –1,5 (0,0)<br>**QVRS total**<br>Basal: 58,83 (0,85)<br>DM (DP): 20,78<br>**OAB-q Symptom Bother**<br>Basal:53,51 (0,76)<br>DM(DP):-26,89|NR|  
156  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||SOLI 5<br>mg|**Respondentes para zero**<br>**IU**<br>No fim do estudo, n/N<br>(%):  267/704 (37,9%)|NR|**DM (EP):**<br>**Volume**<br>**urinado/micção**<br>**(ml)**<br>16,52 (1,97)<br>**Episódios de**<br>**noctúria/24H**<br>–0,37 (0,03)|NR|**DM (EP):**<br>**EPPCB**<br>–1,2 (0,0)<br>**QVRS total**<br>Basal: 59,32 (0,89)<br>DM (DP): 17,63<br>**OAB-q Symptom Bother**<br>Basal: 51,85 (0,78)<br>DM(DP):-21,93|NR|
||SOLI<br>10 mg|**Respondentes para zero**<br>**IU**<br>No fim do estudo, n/N<br>(%):  280/697 (40,2%)|NR|**DM (EP):**<br>**Volume**<br>**urinado/micção**<br>**(ml)**<br>20,30 (1,97)<br>**Episódios de**|NR|**DM (EP):**<br>**EPPCB**<br>–1,3 (0,0)<br>**QVRS total**<br>Basal: 60,14 (0,87)<br>DM (DP): 17,40|NR|
|||||<br>**noctúria/24H**<br>–0,41 (0,03)||**OAB-q Symptom Bother**<br>Basal: 52,63 (0,78)<br>DM(DP):-23,59||
||SOLI|**Respondentes para zero**||**Média (DP) (IC**||**Média (DP) (IC 95%):**||
||+MIRA|**IU**|0,001|**95%):**||||  
157  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
||vs,<br>SOLI 5<br>mg|OR: 1,47 (IC 95%: 1,17–<br>1,84)<br>**50% redução EIU e**<br>**melhora ≥10 pontos no**|<0,001|**Volume**<br>**urinado/micção**<br>**(ml)**<br>∆ (SOLI +MIRA)|< 0,001<br>0,174|**EPPCB**<br>∆ (SOLI +MIRA) - (SOLI 5 mg): –0,3<br>(0,1) (IC 95%: –0,4, –0,1<br>**QVRS total**|< 0,001|
|||**OAB- q Symptom**<br>**Bother**<br>OR: 1,66 (IC 95%:1,33,|<0,001|- (SOLI 5 mg):<br>11,52 (2,79) (IC<br>95%: 6,06–16,99)||∆ (SOLI +MIRA) - (SOLI 5 mg): 3,15<br>(IC 95%: 1,35, 4,95)|0,001|
|||2,07)||**Episódios de**||**OAB-q Symptom Bother**<br>∆ (SOLI +MIRA) - (SOLI 5 mg): -|< 0,001|
|||**50% redução EIU e**<br>**melhora ≥10 pontos na**<br>**QVRS total**<br>OR: 1,59 (IC 95%:1,27,<br>2,00)||**noctúria/24H**<br>∆ (SOLI +MIRA)<br>- (SOLI 5 mg ): –<br>0,06 (0,05) (IC<br>95%:–0,16, 0,03)||4,96(IC 95%: -6,88, -3,04)||
|||**Respondentes para zero**<br>**incontinência**|0,033|**Média (EP) (IC**<br>**95%):**||**Média (EP) (IC 95%):**||
|||OR: 1,28 (IC 95%: 1,02–||||**EPPCB**||
||SOLI<br>+MIRA<br>vs,|1,61)||**Volume**<br>**urinado/micção**<br>**(ml)**|0,005|∆ (SOLI +MIRA) - (SOLI 10 mg): –0,2<br>(0,1) (IC 95%: –0,3, –0,1)|0,004|
||SOLI|**50% redução EIU e**|0,050|∆ (SOLI +MIRA)||**QVRS total**||
||10 mg|**melhora ≥10 pontos no**<br>**OAB-Q Symptom**<br>**Bother**||- (SOLI 10 mg):<br>7,75 (2,79) (IC<br>95%: 2,29, –|0,634|∆ (SOLI +MIRA) - (SOLI 10 mg): 3,38<br>(IC 95%: 1,58, 5,19)|<0,001|
|||OR:1,25 (IC 95%:1,00,|0,003|13,21)||**OAB-q Symptom Bother**||  
158  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||1,56)<br>**50% redução EIU e**<br>**melhora ≥10 pontos na**<br>**QVRS total**<br>OR: 1,41 (IC 95%:1,13,<br>1,77)||**Episódios de**<br>**noctúria/24H**<br>∆ (SOLI +MIRA)<br>- (SOLI 10 mg): –<br>0,02 (0,05) (IC<br>95%: –0,11, 0,07)||∆ (SOLI +MIRA) - (SOLI 10 mg): -3,30<br>(IC 95%: -5,23, -1,37)|0,001|
|||||**OABSS- EIUU**<br>**(escores de 0-5),**<br>**média (DP**)<br>Basal: 3,65 (0,70)<br>Fim do estudo:<br>2,68 (0,93)|0,0004<br>vs,<br>Basal|||
|||||**OABSS- A)**||||
||MIRA<br>50mg|NR|NR|**frequência diária**<br>**(escores de 0-2) e**<br>**B) frequência**<br>**noturna (escores**<br>**de 0-3), média**<br>**(DP)**<br>Basal: A) 1,94<br>(0,67); B)<br>0,65±0,54)|A)<br>0,0003<br>vs,<br>Basal;<br>B)<br><0,0001<br>vs,<br>Basal|NR|NR|
|||||Fim do estudo:A)||||  
159  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||||0,61 (0,49);<br>B)1,03 (0,81)||||
||MIRA<br>50mg|**Normalização da micção**<br>(⩾8 micções/24 h na linha<br>de base e<8<br>micções/24 h pos linha de<br>base):<br>43,6%|NR|**PIU§**<br>**Episódios de**<br>**noctúria**<br>Basal, média (DP):<br>2,3 (1,4)<br>|NR|**EPPCB A) melhora ≥ 1 pontos; B)**<br>**melhora ≥ 2 pontos**<br>Respondentes, n (%):  A) 651 (71,9);<br>B)419 (46,2)<br>**QVRS total (Melhora ≥ 10 pontos)**<br>Respondentes, n (%): 612 (67,5)|NR|
|**Batista et al,**<br>**2015(106)**<br>||**Redução de A) 50% e B)**<br>**100% de EIU/dia**<br>A) 85,1%; B) 67,3%||DM: -1,40<br>DM: -0,95||**OAB-q Symptom Bother (Melhora ≥**<br>**10 pontos)**<br>Respondentes,n(%):690 (76,2)||
|**BEYOND**|SOLI 5<br>mg|**Normalização da micção**<br>(⩾8 micções/24 h na linha<br>de base e <8<br>micções/24 h pos linha de<br>base):<br>47,2%<br>**Redução de A) 50% e B)**|NR|**PIU§**<br>**Episódios de**<br>**noctúria**<br>Basal, média (DP):<br>2,3 (1,4)<br>DM: -0,94|NR|**EPPCB A) melhora ≥ 1 pontos; B)**<br>**melhora ≥ 2 pontos**<br>Respondentes, n (%): A) 672 (74,9); B)<br>458 (51,1)<br>**QVRS total (Melhora ≥ 10 pontos)**<br>Respondentes, n (%): 637 (71,0)|NR|  
160  
|**Autor, ano**|**Grupos**|**Probabilidades de**<br>**redução de desfechos**<br>**miccionais**|**Valor**<br>**p**|**Desfechos**<br>**secundários**<br>**miccionais**|**Valor p**|**Desfechos reportados pelos pacientes**|**Valor p**|
|---|---|---|---|---|---|---|---|
|||**100% de EIU/dia**<br>A) 88,1%; B) 68,5%||||**OAB-q Symptom Bother (Melhora ≥**<br>**10 pontos)**<br>Respondentes, n (%):728 (81,2)||
||MIRA<br>50mg<br>vs,<br>SOLI 5<br>mg|**Normalização da micção**<br>(⩾8 micções/24 h na linha<br>de base e <8<br>micções/24 h pos linha de<br>base):<br>OR: 1,14 (IC 95%: 0,93,<br>1,39)<br>**Redução de A) 50% e B)**<br>**100% de EIU/dia**<br>A) OR: 1,25 (IC<br>95%:0,82, 1,90)<br>B) OR: 1,02 (IC 95%:<br>0,73,1,42),|NS<br>NS<br>NS|**PIU§**<br>**Episódios de**<br>**noctúria**<br>NR|NR|**EPPCB A) melhora ≥ 1 pontos; B)**<br>**melhora ≥ 2 pontos**<br>A) OR:  1,18 (IC 95%:0,94, 1,49);<br>B) OR: 1,21 (IC 95%:0,99, 1,50)<br>**QVRS total (Melhora ≥ 10 pontos)**<br>OR: 1,26 (IC 95%: 1,01, 1,57)<br>**OAB-q Symptom Bother (Melhora ≥**<br>**10 pontos)**<br>OR: 1,37 (IC 95%: 1,07, 1,75)|A) 0,15<br>B) 0,069<br>0,045<br>0,011|  
MIRA: mirabegrona; TOL: tolterodina; SOLI: solifenacina; ECR: ensaio clínico randomizado; BH: bexiga hiperativa;IU: incontinência urinária; EIU: episódios de incontinência urinária; EIUU: episódios de incontinência urinária de urgência; EPPCB: escores da Percepção do paciente da condição da bexiga; OAB-q: questionário de bexiga hiperativa, do inglês overactive bladder questionnaire; OAB-Symptom Bother: escala de satisfação do tratamento de BH, sendo considerado respondente se atingido ≥90 de 100;OABSS: escores de sintomas de bexiga hiperativa, do inglês overactive bladder symptoms score; KHQ King’s Health Questionnaire; QVRS: qualidade de vida relacionada a saúde; TS-VAS:escala visual analógica da satisfação do tratamento,  
161  
do inglês treatment satisfaction-visual analog scale score; £NA foram coletados desfechos que não foram inclusos em revisões sistemáticas; PIU§: população com incontinência: participantes que apresentaram mais de 1 EIU na linha de base;NA: não se aplica; OR: Odds ratio ou razão de chances; DM: diferença de médias; ∆: diferença; DP: desvio padrão; EP: erro padrão; IC 95%: intervalo de confiança de 95%; I2: métrica para medir a heterogeneidade estatística dos estudos; NR: não reportado;NS: não significativo; NT: não testado,  
**Tabela 24 – Desfechos de segurança dos estudos que envolveram a comparação com a combinação de Mirabegrona e Solifenacina.**  
|**Eventos**||**Herschor**|**n et al, 2**<br>**(**|**017; Ro**<br>**SYNER**|**binson et al,**<br>**GY Study)**|**2017(102, 1**|**03)**|**G**|**ratzke e**<br>**(Re**|**t al, 2017(87)**<br>**sumo)**||**D**<br>**M**<br>**2016(**|**rake et**<br>**acDiar**<br>**104, 1**|**al, 201**<br>**mid et**<br>**05)(BES**|**6;**<br>**al,**<br>**IDE)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**<br>**n (%)**|**Placeb**<br>**o**|**MIRA**<br>**25 mg**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**SOLI 5mg**<br>**+ MIRA**<br>**25 mg**|**SOLI**<br>**5mg +**<br>**MIRA**<br>**50mg**|**Valor p**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**MIRA 50**<br>**mg +**<br>**SOLI 5 mg**|**Valo**<br>**r p**|**SOL**<br>**I +**<br>**MIR**<br>**A**|**SOL**<br>**I**<br>**5mg**|**SOL**<br>**I10**<br>**mg**|**Valo**<br>**r p**|
|EAET|145<br>(33,8)|135<br>(31,9)|147<br>(34,8)|149<br>(35,2)|345 (40,4)|314<br>(37,0)|NR|126<br>(41,3)|134<br>(44,2)|596 (49,4)|NR|260<br>(35,9<br>)|241<br>(33,1<br>)|283<br>(39,4<br>)|NR|
|EAET<br>Sérios|8 (1,9)|6 (1,4)|5 (1,2)|3 (0,7)|3 (0,7)|19 (2,2)|NR|8 (2,6)|8 (2,6)|51 (4,2)|NR|13<br>(1,8)|10<br>(1,4)|15<br>(2,1)|NR|  
162  
|||**Herschor**|**n et al, 2**|**017; Ro**|**binson et al,**|**2017(102, 1**|**03)**|**G**|**ratzke e**|**t al, 2017(87)**||**D**<br>**M**|**rake et**<br>**acDiar**|**al, 201**<br>**mid et**|**6;**<br>**al,**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Eventos**|||**(**|**SYNER**|**GY Study)**||||**(Re**|**sumo)**||**2016(**|**104, 1**|**05)(BES**|**IDE)**|
|**adversos**<br>**%**|||||**SOLI 5m**|**SOLI**||||**MIRA 50**||**SOL**<br>|**SOL**|**SOL**||
|**n ()**|**Placeb**<br>**o**|**MIRA**<br>**25 mg**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**g**<br>**+ MIRA**<br>**25 mg**|**5mg +**<br>**MIRA**<br>**50mg**|**Valor p**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|<br>**mg +**<br>**SOLI 5 mg**|**Valo**<br>**r p**|**I +**<br>**MIR**<br>**A**|**I**<br>**5mg**|**I10**<br>**mg**|**Valo**<br>**r p**|
|EAET<br>relacionado<br>s aos<br>medicamen<br>tos|45<br>(10,5)|37<br>(8,7)|52<br>(12,3)|63<br>(14,9)|157 (18,4)|150<br>(17,7)|NR|35<br>(11,5)|42<br>(13,9)|200 (16,6)|NR|141<br>(19,4<br>)|125<br>(17,2<br>)|161<br>(22,4<br>)|NR|
|EAET<br>sérios||||||||||||||||
|relacionado<br>s aos<br>medicamen<br>tos|0|1 (0,2)|1 (0,2)|0|2 (0,2)|3 (0,4)|NR|1 (0,3)|0|0|NR|NR|NR|NR|NR|
|Hipertensã<br>o|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|12<br>(1,7)|6<br>(0,8)|13<br>(1,8)|NR|
|EAET-<br>Cardiovasc<br>ulares|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|n<br>(%)*:<br>7<br>(1,0)|n<br>(%)*:<br>5<br>(0,7)|<br>n<br>(%)*:<br>4<br>(0,6)|NR|
|Infecção do|<br>21|18|16|21|60 (7,0)|44 (5,2)|Todos|11|12|||7|7|12||
|trato|(4,9)|(4,3)|(3,8)|(5,0)|IC 95%:|IC 95%:|<0,05,|<br>(36)|<br>(40)|41 (31,4)|NR|(1,0)|(1,0)|(1,7)|NR|
|urinário|IC|IC|IC|IC|(5,3, 8,8)|(3,7, 6,7)|linha de|,|,|||||||  
163  
|**Eventos**<br>**adversos**<br>**n (%)**|<br>|**Herschor**<br>|**n et al, 2**<br>**(**<br>|**017; Ro**<br>**SYNER**<br>|**binson et al,**<br>**GY Study)**<br>**SOLI 5mg**|**2017(102, 1**<br>**SOLI**<br>|**03)**|**G**<br>|**ratzke e**<br>**(Re**<br>|**t al, 2017(87)**<br>**sumo)**<br>**MIRA 50**|<br>|**D**<br>**M**<br>**2016(**<br>**SOL**<br>**I +**|**rake et**<br>**acDiar**<br>**104, 10**<br>**SOL**|**al, 201**<br>**mid et**<br>**5)(BES**<br>**SOL**|**6;**<br>**al,**<br>**IDE)**<br>**Valo**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||**Placeb**|**MIRA**|**MIRA**|**SOLI**|<br>|**5mg +**||**MIRA**|**SOLI**||**Valo**|<br>|**I**|**I10**||
||**o**|**25 mg**|**50mg**|**5mg**|**+ MIRA**<br>**25 mg**|<br>**MIRA**<br>**50mg**|**Valor p**|**50mg**|**5mg**|**mg +**<br>**SOLI 5 mg**|**r p**|**MIR**<br>**A**|**5mg**|**mg**|**r p**|
||95%:<br>(2,9,<br>6,9)|95%:<br>(2,9,<br>6,9)|95%:<br>(2,0,<br>5,6)|95%:<br>(2,9,<br>7,0)|||base e 18<br>semanas|||||||||
|Retenção<br>urinária|0|0<br>:|0|3 (0,7)<br>IC<br>95%:<br>(0,0,<br>1,5)|8 (0,9)<br>IC 95%:<br>(0,3, 1,6)|10 (1,2)<br>IC 95%:<br>(0,5, 1,9)|Combinaç<br>ões<br><0,05,<br>linha de<br>base e 18<br>semanas|NR|NR|NR|NR|2<br>(0,3)|1<br>(0,1)|5<br>(0,7)|NR|
|Desordens<br>gastrointest<br>inais|Dispep<br>sia: 3<br>(0,7)|Dispep<br>sia:1<br>(0,2)|Dispep<br>sia: 1<br>(0,2)|Dispep<br>sia: 1<br>(0,2)|Dispepsia:<br>10 (1,2)|Dispepsia<br>: 16 (1,9)|NR|NR|NR|NR|NR|9<br>(1,2)|13<br>(1,8)|12<br>(1,7)||
|Boca seca|8 (1,9)|17<br>(4,0)|14<br>(3,3)|25<br>(5,9)|74 (8,7)|61 (7,2)|NR|12<br>(3,9)|18<br>(5,9)|76 (6,1)|NR|43<br>(5,9)|41<br>(5,6)|68<br>(9,5)|NR|
|Constipaçã<br>o|6 (1,4)|6 (1,4)|11<br>(2,6)|6 (1,4)|38 (4,5)|31 (3,7)|NR|3 (1,0)|7 (2,3)|40 (3,3)|NR|33<br>(4,6)|22<br>(3,0)|34<br>(4,7)|NR|
|Visão turva|3 (0,7)|1 (0,2)|0|2 (0,5)|5 (0,6)|6 (0,7)|NR|NR|NR|NR|NR|NR|NR|NR|NR|
|Dor de<br>cabeça|NR|NR|NR|NR|NR|NR|NR|5 (1,6)|5 (1,7)|35 (2,9)|NR|NR|NR|NR|NR|  
164  
|**Eventos**||**Herschor**|**n et al, 2**<br>**(**|**017; Ro**<br>**SYNER**|**binson et al,**<br>**GY Study)**|**2017(102, 1**|**03)**|**G**|**ratzke e**<br>**(Re**|**t al, 2017(87)**<br>**sumo)**||**D**<br>**M**<br>**2016(**|**rake et**<br>**acDiar**<br>**104, 1**|**al, 201**<br>**mid et**<br>**05)(BES**|**6;**<br>**al,**<br>**IDE)**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**adversos**<br>**n (%)**|**Placeb**<br>**o**|**MIRA**<br>**25 mg**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**SOLI 5mg**<br>**+ MIRA**<br>**25 mg**|**SOLI**<br>**5mg +**<br>**MIRA**<br>**50mg**|**Valor p**|**MIRA**<br>**50mg**|**SOLI**<br>**5mg**|**MIRA 50**<br>**mg +**<br>**SOLI 5 mg**|**Valo**<br>**r p**|**SOL**<br>**I +**<br>**MIR**<br>**A**|**SOL**<br>**I**<br>**5mg**|**SOL**<br>**I10**<br>**mg**|**Valo**<br>**r p**|
|Reações de<br>hipersensib<br>ilidade|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|NR|11<br>(1,5)|6<br>(0,8)|6<br>(0,8)|NR|
|Descontinu<br>ação<br>devido a<br>EAET|9 (2,1)|7 (1,7)|10<br>(2,4)|7 (1,7)|20 (2,3)|22 (2,6)|NR|7 (2,3)|5 (1,7)|25 (2,1)|NR|11<br>(1,5)|11<br>(1,5)|11<br>(1,5)|NR|
|Descontinu<br>ação<br>devido a<br>EAET<br>relacionado<br>s aos<br>medicamen<br>tos|7 (1,6)|4 (0,9)|6 (1,4)|5 (1,2)|17 (2,0)|19 (2,2)|NR|4 (1,3)|4 (1,3)|17 (1,4)|NR|NR|NR|11<br>(1,5)|NR|
|Morte<br>devido ao<br>EA|0|0|0|0|0|0|NA|1 (0,3)|0|1 (0,1)|NR|0|0|0|NA|  
MIRA: mirabegrona; SOLI: solifenacina; EA: eventos adversos; EAET: eventos adversos emergentes do tratamento; EATE relacionada com o medicamento: cuja relação com o medicamento de estudo não poderia ser descartada; IC 95%: intervalo de confiança de 95%; NR: não reportado,  
165  
**Tabela 25 – Desfechos de segurança dos estudos que envolveram a comparação de Mirabegrona e Solifenacina monoterapia ou** **_versus_ placebo.**  
|**Eventos**<br>|**Bastista et a**|**l, 2015(BEYOND)(**|**106)**||**Kuo et al, **|**2015(88)**||
|---|---|---|---|---|---|---|---|
|**adversos**<br>**n (%)**|**MIRA 50mg**|**SOLI 5mg**|**Valor p**|**MIRA 50mg**|**TOL 4mg**|**Placebo**|**Valor p**|
|EAET|274 (29,3)|282 (30,2)|NR|36 (42,4)|40 (49,4)|33 (42,9)|NS|
|EAET Sérios|14(1,5)|13(1,4)|NR|1(1,3)|0|0||
|EAET||||||||
|relacionados<br>aos|104 (11,1)|135 (14,5|NR|20 (23,5)|24 (29,6)|19 (24,7)|NR|
|medicamentos||||||||
|EAET sérios||||||||
|relacionados<br>aos|4 (0,4)|4 (0,4)|NR|0|0|0|NR|
|medicamentos||||||||
|Hipertensão|10(1,1)|14(1,5)|NR|2(2,4)|1(1,2)|0|NR|
|EAET-|Taquicardia: 1 (0,1)|Taquicardia: 2<br>(0,2)||||||
|Cardiovascular<br>es|<br>Palpitações: 1 (0,5)|Palpitações: 1<br>(0,5)|NR|n:6|n:9|n:10|NR|  
166  
|**Eventos**<br>|**Bastista et**|**al, 2015(BEYOND)(1**|**06)**||**Kuo et al, **|**2015(88)**||
|---|---|---|---|---|---|---|---|
|**adversos**||||||||
|**n (%)**|**MIRA 50mg**|**SOLI 5mg**|**Valor p**|**MIRA 50mg**|**TOL 4mg**|**Placebo**|**Valor p**|
|Infecção do<br>trato urinário|22 (2,4)|24 (2,6)|NR|NR|NR|NR|NR|
|Retenção<br>urinária|1 (0,1)|1 (0,1)|NR|0|0|0|NR|
|Desordens<br>gastrointestinai<br>s|Dispepsia: 5 (0,5)|Dispepsia: 5 (0,5)|NR|NR|NR|NR|NR|
|Boca seca|29 (3,1)|54(5,8)|NR|3 (3,9%)|6 (7,1%)|7(8,6%)|NR|
|Constipação|21(2,2)|23(2,5)|NR|NR|NR|NR|NR|
|Visão turva|6 (0,6)|4(0,4)|NR|NR|NR|NR|NR|
|Dor de cabeça|28 (3,0)|22(2,4)|NR|NR|NR|NR|NR|
|Reações de||||||||
|hipersensibilid<br>ade|32 (3,4)|35 (3,7)|NR|NR|NR|NR|NR|
|Descontinuaçã<br>o devido a<br>EAET|13 (1,4)|17 (1,8)|NR|2 (2,4%)|1 (1,2%)|1 (1,3%)|NR|
|Descontinuaçã<br>o devido a<br>EAET<br>relacionados<br>aos<br>medicamentos|9 (1,0)|14 (1,5)|NR|1 (1,2%)|0|1 (1,3%)|NR|
|Morte devido<br>ao EA|0|0|NA|1 (1,3)|0|0|NA|  
MIRA: Mirabegrona; SOLI: solifenacina; EA: eventos adversos; EAET: eventos adversos emergentes do tratamento; EATE relacionada com o medicamento: cuja relação com o medicamento de estudo não poderia ser descartada NR: não reportad  
167  
168

---

