<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE  
PORTARIA CONJUNTA SAES/SECTICS Nº 12, DE 24 DE JULHO DE 2025  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas das Amiloidoses Associadas à Transtirretina  
**O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE E A SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INOVAÇÃO E DO COMPLEXO ECONÔMICO-INDUSTRIAL DA SAÚDE** , no uso das atribuições que lhes conferem o Decreto nº 11.798, de 28 de novembro de 2023, alterado pelo Decreto nº 12.489, de 04 de junho de 2025,  
Considerando a necessidade de se atualizarem os parâmetros sobre as Amiloidoses associadas à transtirretina no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 1004/2025 e o Relatório de Recomendação nº 1007/2025 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Amiloidoses associadas à transtirretina.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral de Amiloidoses associadas à transtirretina, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento de Amiloidoses associadas à transtirretina.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria Conjunta SAS-SCTIE/MS nº 22, de 02 de outubro de 2018, publicada no Diário Oficial da União (DOU) nº 196, de 10 de outubro de 2018, seção 1, página 63.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: MOZART JULIO TABOSA SALES -->
FERNANDA DE NEGRI

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **INTRODUÇÃO** -->
As amiloidoses sistêmicas são um grupo de doenças que se caracterizam pelo depósito de substância amiloide nos tecidos<sup>1</sup> . As amiloidoses têm como mecanismo fisiopatológico comum a proteotoxicidade de moléculas precursoras aberrantes, devido à mutação ou outro mecanismo que se desagregam em formas intermediárias e, finalmente, se depositam como fibrilas de amiloide no interstício tecidual. Este depósito causa disfunção de diversos órgãos<sup>2,3</sup> .  
Existem diferentes tipos de amiloidoses sistêmicas, entre elas as amiloidoses ligadas a proteínas precursoras que sofreram mutação, tais como a transtirretina (TTR)<sup>1,2,4</sup> . A TTR é uma proteína predominantemente sintetizada no fígado (98%) e que tem a função de ser carreadora da tiroxina e do retinol<sup>4,5</sup> . Quando a TTR sofre desestabilização de sua estrutura tetramérica, por mutação nas formas hereditárias (familiares) ou por outro mecanismo, na forma selvagem (essa ligada ao depósito tecidual de TTR nativa), há a consequente dissociação em monômeros e deposição tecidual sob a forma de agregados de filamentos amiloides. Essas são as amiloidoses associadas à TTR<sup>5,6</sup> .  
A amiloidose transtirretina (ATTR) do tipo selvagem foi descrita pela primeira vez em 1876 e sua prevalência permanece desconhecida. No entanto, estudos sugerem que é subdiagnosticada e que pode ser a forma mais frequente de amiloidose cardíaca. A ATTR selvagem é uma condição não hereditária, encontrada principalmente em homens e, em geral, começa após os 70 anos (por isso foi anteriormente conhecida como amiloidose senil), ainda que existam casos diagnosticados em indivíduos mais jovens<sup>7</sup> .  
Na forma hereditária (familiar), variantes gênicas ligadas à amiloidose do gene da TTR têm herança autossômica dominante<sup>4</sup> . Conforme a variante apresentada, o paciente pode desenvolver manifestações clínicas distintas, que surgem em idades diferentes, o que permite uma boa correlação genótipo-fenótipo para a maioria das mutações já descritas. A variante mais prevalente é a p.Val30Met, caracterizada por manifestações que se iniciam, geralmente, aos 30 anos de idade, com polineuropatia marcante. Já a segunda variante mais prevalente é a p.Ser77Tyr<sup>8-14</sup> .  
Dentro do espectro de possibilidades de combinações de lesões sistêmicas, a variante p.Val122Ile caracteriza um início de manifestações mais tardio, em torno de 50 anos, com cardiopatia predominante<sup>13-15</sup> . Entre estes dois extremos, diversas variantes gênicas e diferentes fenótipos combinados são encontrados<sup>14</sup> . Reconhecer a ancestralidade do paciente é relevante, pois pode fornecer uma pista para a variante patogênica específica. A p.Val30Met é mais frequentemente originária de Portugal ou da Suécia, enquanto a p.Val122Ile é originária da África Ocidental<sup>14,16,17</sup> .  
As amiloidoses por TTR manifestam-se por meio de dois quadros clínicos principais: a polineuropatia amiloide associada à transtirretina (ATTR-PN) e a cardiomiopatia amiloide associada à transtirretina (ATTR-CM). A presença de um desses quadros ou a combinação dos mesmos associada à disautonomia, levanta a suspeita clínica de uma amiloidose por TTR, em especial em indivíduos com história familiar autossômica dominante<sup>18</sup> .  
A ATTR-CM pode ser classificada de acordo com o genótipo: ATTRh, causada por uma das mutações hereditárias conhecidas (autossômicas dominantes) no gene _TTR_ , ou selvagem (também conhecida como ATTR-CM sistêmica senil ou senil), quando o paciente não apresenta mutações envolvidas com o desenvolvimento da doença<sup>4,7,17</sup> .  
Um estudo epidemiológico realizado no norte de Portugal encontrou prevalência de 1/1.000 e uma frequência de portador da variante de 1/538 habitantes. Esta área de Portugal é considerada endêmica da ATTR-PN, onde a idade de início média é de  
33 anos<sup>19</sup> . Por outro lado, idade avançada de início, depois dos 55 anos de idade, foi observada em outros países, como a Suécia<sup>20</sup> . Além de Portugal, Japão e Suécia também possuem áreas endêmicas de ATTR-PN<sup>4,18</sup> .  
No Brasil, observou-se um aumento no número de casos de amiloidoses hereditárias associadas à TTR (ATTR) registrados desde a criação do Centro de Estudos em Paramiloidose Antônio Rodrigues de Mello (CEPARM) no Hospital Universitário Clementino Fraga Filho (HUCFF), em 1984, na Universidade Federal do Rio de Janeiro. De acordo com esses dados, 102 pacientes com ATTR-PN, entre 1991 e 2011, foram avaliados no CEPARM, dos quais 77% eram provenientes do Rio de Janeiro<sup>10</sup> .  
Adicionalmente, dados referentes à população brasileira inscrita no _Transthyretin Amyloidosis Outcomes Survey_ (THAOS) indicaram que, dos 160 pacientes incluídos na análise, 91,9% apresentavam a variante patogênica p.Val30Met e a mediana da idade do início dos sintomas foi de 32,5 anos<sup>14</sup> . Dados similares foram observados na casuística da Universidade de São Paulo (USP)<sup>21</sup> que caracterizou 44 pacientes brasileiros com ATTR-PN, sendo 26 não-relacionados com variante patogênica p. Val30Met e 24, submetidos ao transplante hepático<sup>22</sup> . A mediana de idade destes pacientes, no início dos sintomas, foi de 32 anos, sendo significativamente maior no sexo feminino (33 _versus_ 27 anos)<sup>21</sup> .  
Um estudo brasileiro de 2018<sup>23</sup> , que avaliou amostras da população com variantes patogênicas em _TTR_ , observou que a variante p.Val30Met foi identificada em 90,6% das amostras avaliadas, enquanto sete pacientes (4,7%) apresentavam variantes patogênicas não- _TTR_ (p.Aps38Tyr, p.Ile107Val, p.Val71Ala e p.Val122Ile) e, outros sete (4,7%) eram portadores de variantes não patogênicas (p.Gly6Ser e p.Thr119Thr). No estudo REACT<sup>24</sup> , registro de amiloidose cardíaca do estado de São Paulo, publicado em 2024, dos 644 pacientes incluídos, 505 apresentavam a forma hereditária (ATTRh) e 139, a selvagem. Entre os ATTRh, 47,5% tinham a mutação Val30Met e 39,2%, Val122Ile. Ainda, 53,9% dos pacientes apresentavam o fenótipo cardíaco, 51,1% o fenótipo neurológico, e 25,6% dos pacientes apresentaram o fenótipo misto (ATTR-PN e ATTR-CM). Estes dados corroboram a heterogeneidade da população do país com ATTRh.  
Os tecidos e órgãos mais acometidos com o depósito de substância amiloide são os nervos periféricos, coração, trato gastrointestinal, rins, sistema nervoso central e os olhos<sup>4</sup> . A lesão é do tipo perda de axônios nos nervos periféricos, principalmente naqueles não mielinizados ou com pouca mielina e, portanto, de pequeno calibre. Isso explicaria o quadro clínico, que progride de uma polineuropatia de fibras finas, acometimento precoce da percepção térmica e da percepção da dor, além de disautonomia, até uma polineuropatia sensitivo-motora completa, com fraqueza, atrofia e perda da capacidade deambulatória, com evolução para óbito em 10 anos, em média<sup>4,11,16,25</sup> . A doença inicia, geralmente, com dor e parestesias nos pés, associadas à dor distal em membros inferiores e perda sensório-térmica, seguida de perda tátil leve e hipo/arreflexia de tornozelo. Geralmente, os pacientes começam com sintomas motores após uma história de hipoestesia por 2 anos. Após 4 a 5 anos de evolução, os sintomas sensoriais começam nas mãos<sup>6,16,26</sup> .  
A cardiopatia também é marcante, havendo alterações precoces na condução cardíaca, causando bloqueios de condução e arritmias, necessidade de implantação de marca-passo e, mais tardiamente, cardiopatia e disfunção por infiltração miocárdica de amiloide<sup>17,25,26</sup> . Dentre as alterações do ritmo cardíaco, a fibrilação atrial é mais prevalente em pacientes com ATTR-CM, assim como os bloqueios atrioventriculares<sup>17</sup> . Nos casos de fenótipo neurológico, a progressão da neuropatia leva à incapacidade sensitivo-motora, embora a mortalidade seja mais relacionada ao comprometimento cardíaco<sup>17,27</sup> .  
A função renal é afetada tardiamente e a principal manifestação é a síndrome nefrótica com microalbuminúria precoce<sup>4,25</sup> . O envolvimento renal com falência renal progressiva pode ser observado em até um terço dos pacientes descendentes de portugueses que tiveram início precoce da sua doença<sup>28</sup> . Entretanto, disfunção renal grave raramente ocorre em indivíduos com a forma tardia da ATTR<sup>4</sup> .  
Os sintomas digestivos constituem um dos aspectos mais relevantes e precoces da clínica da ATTR, por sua frequência, intensidade e influência negativa no bem-estar dos pacientes. Alterações importantes na motilidade gastrointestinal são a  
principal justificativa para essas manifestações, sendo expressão da disautonomia neurovegetativa. Podem ocorrer diarreia, constipação, náuseas, vômitos e sensação de plenitude com esvaziamento gástrico tardio<sup>4,14,25,26,29</sup> . O emagrecimento é uma característica importante, habitualmente precoce e constante. Pode estar ligado às manifestações gastrointestinais, má-absorção ou perdas proteicas renais e digestivas, constituindo uma das manifestações de pior prognóstico da doença<sup>4,30</sup> .  
Com relação às manifestações oculares, observam-se quadros de anisocoria, resposta lenta à luz ou ausência de resposta pupilar<sup>31</sup> e a queixa de olho seco por infiltração amiloide das glândulas lacrimais, levando à ceratoconjuntivite é frequente<sup>25,31</sup> . Podem ocorrer depósitos de amiloide, com opacidades do cristalino e do vítreo, geralmente precoces, além de glaucoma e angiopatia ocular amiloide<sup>4,31</sup> .  
Destacam-se também as perturbações sexuais e esfincterianas, com incontinência dos esfíncteres urinário e fecal e disfunção erétil<sup>32</sup> .  
Um estudo retrospectivo de 2014<sup>33</sup> indicou um comprometimento clínico do sistema nervoso central (SNC) em pacientes com ATTR, apesar da realização do transplante hepático, sob a forma de angiopatia amiloide cerebral, que surge com o passar do tempo, em média 15 anos após o início da doença. Sinais e sintomas focais do tipo _stroke like_ , enxaqueca _like_ , crises epiléticas focais, hemorragias cerebrais e declínio cognitivo foram citados<sup>4,16,33</sup> . Pacientes com ATTR com variantes não-Val30Met também podem apresentar um fenótipo raro de amiloidose oculoleptomeníngea e, no início do curso da doença, sintomas proeminentes oculares e do SNC. Quatorze variantes foram descritas com esse fenótipo<sup>34</sup> . Recentemente, um paciente com a variante p.Tyr69His no gene _TTR_ foi relatado no Brasil<sup>16,35</sup> .  
Não há tratamento curativo para as ATTR e a conduta envolve acompanhamento por equipe multidisciplinar e inclui intervenções como fisioterapia, cirurgias, como o transplante hepático e terapia medicamentosa<sup>4,36</sup> .  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária à Saúde (APS) um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este PCDT visa a definir critérios de diagnóstico, acompanhamento e tratamento de pacientes com ATTR.  
**CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- E85.0 Amiloidose heredofamiliar não-neuropática  
- E85.1 Amiloidose heredofamiliar neuropática.  
- E85.8 Outras amiloidoses

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.1.1. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
A ocorrência de polineuropatia sensitivo-motora progressiva periférica e pelo menos um dos sintomas a seguir é sugestiva de ATTR-PN<sup>16</sup> :  
- histórico familiar de neuropatia;  
- disfunção autonômica precoce: disfunção erétil ou hipotensão postural, por exemplo;  
- envolvimento cardíaco: cardiomiopatia, hipertrofia, bloqueio atrioventricular e arritmia;  
- alterações gastrointestinais: diarreia, constipação com episódios de alternância e perda de peso inexplicada;  
- síndrome do túnel do carpo bilateral, especialmente se outros membros da família também a apresentarem;  
- anormalidades renais (albuminúria ou azotemia leve, por exemplo); ou  
- opacidade do vítreo.  
Rápida progressão da doença e falha à resposta ao tratamento com imunomoduladores são sinais adicionais<sup>16</sup> . Recomenda-se, também, a avaliação dos escores neurológicos funcionais por meio do _polyneuropathy disability score_ (PND) e avaliação sensitivo-motora pelo _neuropathy impairmet score_ (NIS)<sup>37</sup> .  
A confirmação do diagnóstico da forma selvagem inclui os sinais e sintomas, além de exames complementares e a confirmação da forma hereditária (familiar) é a presença de variante patogênica no gene _TTR_ acompanhada de sintomatologia compatível<sup>16,37-39</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.1.2. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
A ocorrência de manifestações de insuficiência cardíaca, combinada com os sintomas a seguir, é sugestiva de ATTR-  
CM<sup>17</sup> :  
- Insuficiência cardíaca de fração de ejeção preservada (ICFEp), particularmente em homens idosos (acima de 65 anos);  
- Bloqueio atrioventricular (AV) inexplicado com implante prévio de marca-passo;  
- Miocardiopatia hipertrófica iniciada tardiamente (após 60 anos) com padrão assimétrico;  
- Estenose aórtica e pacientes idosos (acima de 65 anos) com baixo fluxo/baixo gradiente;  
- Síndrome do túnel do carpo bilateral, estenose do canal vertebral, ruptura do tendão do bíceps;  
- Polineuropatia sensorial-motora não explicada, como parestesia, dor neuropática, fraqueza;  
- Disfunção autonômica, com hipotensão postural, diarreia pós-prandial alternando com constipação, disfunção erétil;  
- Opacidade vítrea e alterações pupilares;  
- História familiar de polineuropatia ou miocardiopatia.  
A confirmação do diagnóstico da forma selvagem inclui os sinais e sintomas, além de exames complementares e a confirmação da forma hereditária (familiar) é a presença de variante patogênica no gene _TTR_ acompanhada de sintomatologia compatível<sup>16,37-39</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.2.1. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
Para constatação do depósito amiloide, recomenda-se a realização da biópsia do órgão afetado, especialmente de glândula salivar ou tecido adiposo (pele e partes moles), por serem menos invasivas ou biópsia de nervo ou reto (ânus e canal anal), quando necessário. Todos os tecidos obtidos devem ser corados com vermelho-congo e examinados ao microscópio de polarização. É importante ressaltar que resultados negativos não descartam a amiloidose e que a biópsia é recomendável para determinar o início da doença<sup>16</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.2.2. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
O diagnóstico laboratorial da cardiomiopatia amiloidótica pode também incluir marcadores de insuficiência cardíaca como o peptídeo natriurético cerebral (BNP, do inglês _brain natriuretic peptide_ ) ou o NT-próBNP (porção N-terminal do precursor de BNP) e os níveis de troponina<sup>17</sup> .  
Além disso, pode-se incluir o monitoramento da proteinúria e função renal (ureia, creatinina, ácido úrico, taxa de filtração glomerular, proteína em urina de 24 horas)<sup>16,38</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.3. Diagnóstico genético** -->
O diagnóstico da variante patogênica que confirma a ATTR-PN ou ATTR-CM na forma hereditária (familiar) é feito por meio de testes de DNA, como o sequenciamento completo do gene _TTR_ com identificação de mutação por sequenciamento por amplicon até 500 pares de bases, que devem ser utilizados no diagnóstico de pacientes pré-sintomáticos e sintomáticos<sup>4,16</sup> .  
O diagnóstico genético tem um papel de destaque na ATTR hereditária, devendo ser usado para detecção de portadores assintomáticos, com adequado aconselhamento genético e para confirmação de casos suspeitos, com ou sem história familiar<sup>16</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.4.1. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
Devem ser realizados exames complementares, como a eletromiografia com estudos de condução nervosa<sup>16,38</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.4.2. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
A avaliação cardíaca deve incluir eletrocardiograma, ecocardiografia transtorácica, dosagem de troponina e, em alguns casos, ressonância magnética de coração, cintilografia cardíaca com pirofosfato (ou outro marcador específico para a TTR) e monitoramento pelo sistema Holter<sup>37</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.5.1. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
O diagnóstico diferencial é feito com outras polineuropatias que afetem, predominantemente, fibras de pequeno calibre em nervos periféricos, tais como, hanseníase e diabetes, que são as mais importantes. De fato, qualquer neuropatia de caráter axonal crônico pode ser confundida com a ATTR-PN, principalmente quando não há história familiar evidente ou quando o início é tardio<sup>4,6,26,27</sup> .  
Uma das fontes de diagnóstico incorreto mais comum para a ATTR-PN são as polineuropatias desmielinizantes inflamatórias crônicas (PDIC)<sup>4,16</sup> . Apesar das PDIC serem, geralmente, caracterizadas por uma neuropatia sensitivo-motora primariamente desmielinizante, uma vez que um extenso dano axonal comprimento-dependente está presente, características eletrofisiológicas de ATTR-PN podem se assemelhar às observadas para PDIC, devido ao dano axonal na condução mais rápida ou à desmielinização secundária. Além disso, níveis da proteína TTR no líquido cefalorraquidiano podem estar elevadas em pacientes com ATTR-PN, embora de forma menos acentuada na PDIC. Em muitos casos, uma biópsia negativa contribui para o diagnóstico errado. Uma forma importante de considerar ATTR-PN como diagnóstico em um paciente inicialmente classificado como PDIC é a falta de resposta aos tratamentos imunomoduladores e/ou imunossupressores<sup>16</sup> .  
Por fim, torna-se fundamental diferenciar a forma hereditária daquela ligada ao depósito de imunoglobulina de cadeia leve e doença hematológica (denominada amiloidose subtipo AL), cujo tratamento é muito diferente<sup>2,4,16</sup> . O diagnóstico equivocado pode acontecer devido à ocorrência de gamopatia monoclonal em pacientes idosos ou imunomarcação falsa de depósitos amiloides<sup>16</sup> . A investigação das cadeias leves monoclonais de imunoglobulinas inicia-se pela realização de eletroforese com imunofixação no sangue e na urina e a dosagem da relação das cadeias leves livres (kappa/lambda). Em caso positivo, é necessária a biópsia tecidual para confirmar o depósito de proteína amiloide (cadeia leve) e a elaboração da estratégia terapêutica específica<sup>17</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.5.2. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
Da mesma forma que para ATTR-PN, na ATTR-CM é fundamental diferenciar a forma hereditária (familiar) daquela ligada ao depósito de imunoglobulina de cadeia leve e doença hematológica (denominada amiloidose subtipo AL)<sup>17</sup> .  
Para a ATTR-CM, outros diagnósticos diferenciais importantes devem ser realizados com cardiomiopatias hipertróficas sarcoméricas como Doença de Fabry e Doença de Pompe, ambas com tratamento específico disponível<sup>38</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.6.1. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
Após o diagnóstico, o estágio da neuropatia e a extensão sistêmica da doença devem ser determinados, de forma a guiar o curso de tratamento<sup>16</sup> . Os estágios de gravidade da ATTR-PN são determinados pela incapacidade de deambulação do paciente e o grau de assistência necessário. São utilizadas duas classificações: uma clássica em três estágios, proposta por Coutinho et al.<sup>40</sup> e o escore de incapacidade da neuropatia periférica modificado (mPND da sigla em inglês _modified peripheral neuropathy disability score_ )<sup>26</sup> **(Quadro 1)** .  
**Quadro 1 -** Estágio da ATTR-PN de acordo com a gravidade dos sintomas.  
|**Estágios de Coutinho**|**Estágios mPND**|
|---|---|
|Estágio I (estágio inicial): neuropatia sensorial e motora limitada aos|Estágio<br>I:<br>distúrbios<br>sensoriais,<br>mas|
|membros inferiores. Comprometimento motor leve. Deambulação sem<br>auxílio.|capacidade de locomoção preservada (sem<br>comprometimento motor).|
||Estágio II: dificuldade para andar, mas não há<br>necessidade de auxílio para marcha.|
|Estágio II (estágio intermediário): é necessário auxílio para marcha. A<br>neuropatia progride para membros superiores e tronco. Amiotrofia em|Estágio IIIa: é necessária uma bengala ou<br>muleta para caminhar.|
|membros superiores e inferiores. Comprometimento motor moderado.|Estágio IIIb: são necessárias duas bengalas,<br>duas muletas ou um andador para caminhar.|
|Estágio III (estágio avançado): estágio terminal, acamado ou em cadeira de<br>rodas. Neuropatia sensorial, motora e autonômica grave em todos os<br>membros.|Estágio IV: paciente confinado a uma cadeira<br>de rodas ou cama.|

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **3.6.2. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
Os pacientes com insuficiência cardíaca são acompanhados de acordo com a classificação da _New York Heart Association_ (NYHA). Essa classificação auxilia na definição terapêutica e na avaliação da resposta ao tratamento, contribuindo para otimizar o atendimento clínico<sup>41</sup> **(Quadro 2)** .  
**Quadro 2 –** Classificação funcional da _New York Heart Association_ (NYHA).  
|**Classe NYHA**|**Descrição**|
|---|---|
|I|Sem limitações para realização de atividade física. Atividades habituais não causam dispneia, cansaço,|
||palpitações.|
|II|Discreta limitação para realização de atividade física. Atividades habituais causam dispneia, cansaço,<br>palpitações.|  
|**Classe NYHA**|**Descrição**|
|---|---|
|III|Importante limitação para realização de atividade física. Atividades de intensidades inferiores causam<br>dispneia, cansaço, palpitações.|
|IV|Limitações para realização de qualquer atividade física. Sintomas de insuficiência cardíaca podem<br>ocorrer em repouso.|

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nesse PCDT pacientes de ambos os sexos, maiores de 18 anos de idade, com diagnóstico confirmado de amiloidose associada à TTR, independentemente das suas manifestações clínicas e do estágio da doença.  
Adicionalmente, para uso de tafamidis meglumina 20 mg, os pacientes devem apresentar polineuropatia amiloidótica hereditária (familiar) sintomática (CID-10 E85.1) em estágio inicial (estágio I de Coutinho) e não terem sido submetidos à transplante hepático.  
Adicionalmente, para uso de tafamidis 61 mg, os pacientes devem apresentar cardiomiopatia associada à TTR (selvagem ou hereditária), classe NYHA II ou III e idade acima de 60 anos.  
Serão elegíveis para o transplante os pacientes com doador identificado; em condições clínicas para o transplante; e em idade compatível com o transplante hepático, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes<sup>42</sup> e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **CRITÉRIOS DE EXCLUSÃO** -->
Pacientes que apresentem intolerância, hipersensibilidade ou contraindicação a medicamento neste Protocolo deverão ser  
excluídos ao uso do respectivo medicamento preconizado.  
Em relação ao uso de tafamidis, adicionalmente, serão excluídas gestantes e lactantes.  
O uso concomitante de tafamidis 20 mg e tafamidis 61 mg não é preconizado por este Protocolo. Assim, pacientes em uso de tafamidis meglumina 20 mg estão excluídos do uso de tafamidis 61 mg. Do mesmo modo, pacientes em uso de tafamidis 61 mg estão excluídos do uso de tafamidis meglumina 20 mg.  
Entretanto, pacientes com amilodoise familiar (hereditária) associada à transtirretina com comprometimento misto (neurológico e cardíaco) que já estejam em uso de tafamidis meglumina 20 mg podem migrar para o uso de tafamidis 61 mg, caso seja a escolha terapêutica da equipe médica assistente e respeitando os demais critérios de inclusão.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **TRATAMENTO** -->
O tratamento das ATTR é complexo e requer medidas específicas para o controle da progressão da amiloidogênese sistêmica, além de terapia direcionada aos sintomas e órgãos afetados pela amiloidose<sup>4,16,17</sup> . O atendimento dos pacientes com ATTR envolve equipe multidisciplinar<sup>16,17</sup> e o tratamento com o medicamento tafamidis meglumina 20 mg para ATTR-PN hereditária (familiar)<sup>36</sup> e tafamidis 61 mg para ATTR-CM (selvagem ou hereditária)<sup>43</sup> , conforme critérios de inclusão definidos neste PCDT, além de transplante hepático conforme o Regulamento Técnico do Sistema Nacional de Transplantes vigente<sup>42</sup> .  
É crucial que a equipe multiprofissional acompanhe continuamente o paciente, monitorando a evolução da doença, fornecendo orientação à família, realizando os encaminhamentos aos especialistas, conforme necessário e coordenando o atendimento integral ao paciente.  
Além disso, é importante que pacientes e familiares sejam orientados acerca da doença e suas possíveis complicações e riscos, também com auxílio de um relatório escrito. Os pacientes também devem ser informados de que, em caso de emergência, o médico assistente deve ser comunicado e receber cópia do relatório médico com informações sobre a condição crônica do paciente.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.1. Tratamento não medicamentoso** -->
Como se trata de uma doença crônica, multissistêmica e progressiva, os pacientes com ATTR e suas famílias requerem, geralmente, apoio psicológico e social a partir do diagnóstico da doença<sup>16,17</sup> .  
No caso da ATTR forma hereditária (familiar), o aconselhamento genético deve ser oferecido a todas as famílias e aos pacientes, visando a fornecer informações sobre _status_ genético, diagnóstico pré-natal e chance de recorrência. A ATTR hereditária é de padrão autossômico dominante, sendo assim, a chance de um indivíduo heterozigoto afetado por ATTR hereditária ter um filho, independente do sexo, com a condição é de 50%<sup>4</sup> . Um teste preditivo, ou seja, aquele realizado em familiar assintomático de um portador da condição genética, pode ser feito em indivíduos adultos, mediante adequado processo de aconselhamento genético<sup>4</sup> . É importante que uma equipe multidisciplinar acompanhe o paciente, sugerindo-se a inclusão, além da equipe médica de multiespecialidades, nutricionistas, psicólogos, fisioterapeutas e enfermeiros<sup>16</sup> .  
O transplante hepático tem como objetivo prevenir a formação de depósitos amiloides adicionais, pela remoção do principal sítio de produção de qualquer TTR, mutada ou não. Com a substituição do fígado, espera-se que não haja progressão da doença<sup>6,22</sup> .  
O transplante hepático deve ser realizado no estágio inicial (estágio I de Coutinho) da doença, antes do aparecimento de lesões extensas que não poderão ser revertidas com este procedimento<sup>15,44,45</sup> .  
Como em alguns casos o depósito de TTR pode seguir após o transplante hepático, com progressão das manifestações cardíacas<sup>46</sup> , outra possibilidade pode ser o transplante combinado fígado-coração, com aparente melhor prognóstico do que o transplante isolado de apenas um desses órgãos<sup>47</sup> . No entanto, considerando a pouca disponibilidade de órgãos e os riscos associados ao procedimento, o uso de medicamentos que bloqueiem a síntese hepática de TTR é a estratégia mais utilizada<sup>17</sup> .  
A indicação, realização e acompanhamento pós-transplante hepático devem seguir o Regulamento Técnico do Sistema Nacional de Transplantes vigente<sup>42</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.2. Tratamento medicamentoso** -->
Ressalta-se a importância do acompanhamento dos usuários em relação ao uso dos medicamentos preconizados neste PCDT para que alcancem os resultados positivos em relação à efetividade do tratamento e para monitorar o surgimento de problemas relacionados à segurança. Nesse aspecto, a prática do Cuidado Farmacêutico, por meio de orientação, educação em saúde e acompanhamento contínuo, contribui diretamente para o alcance dos melhores resultados em saúde, ao incentivar o uso apropriado dos medicamentos que sejam indicados, seguros e efetivos, ao estimular a adesão ao tratamento, ao fornecer apoio e informações que promovam a autonomia e o autocuidado dos pacientes.  
Como a adesão ao tratamento é essencial para que o usuário alcance os resultados esperados, é fundamental que sejam fornecidas, no momento da dispensação dos medicamentos, informações acerca do processo de uso do medicamento, interações medicamentosas e possíveis eventos adversos. A integração do Cuidado Farmacêutico aos Protocolos Clínicos e Diretrizes  
Terapêuticas é, portanto, fundamental para proporcionar uma assistência à saúde mais segura, efetiva e centrada na pessoa, abordando de forma abrangente as necessidades de cada indivíduo.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.2.3. Polineuropatia amiloide associada à transtirretina (ATTR-PN)** -->
O uso de tafamidis meglumina 20 mg é recomendado para o tratamento da ATTR-PN hereditária (familiar) em pacientes adultos, sintomáticos, em estágio inicial (estágio I da escala de Coutinho) e não submetidos a transplante hepático<sup>36</sup> , uma vez que apresentou perfil satisfatório de segurança, eficácia na estabilização da TTR e na redução da progressão da doença<sup>48-50</sup> . Para essa população, seu uso também está associado à manutenção e até melhora do estado nutricional<sup>51</sup> .  
Em pacientes com ATTR-PN, com variantes patogênicas que não a p.Val30Met ou p.Val122Ile, o medicamento foi bem tolerado e eficaz na estabilização da TTR, com melhora do índice de massa corporal (IMC) modificado e da qualidade de vida dos pacientes<sup>52</sup> . Os pacientes em uso do medicamento devem ser acompanhados em centros de referência sempre que possível e, caso se mostrem não respondedores, deverão ser encaminhados ao transplante hepático, se aplicável.  
A Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec) avaliou a incorporação dos medicamentos inotersena e patisirina, conforme Relatórios de Recomendação nº 799 (Portaria SECTICS/MS nº24/2023)<sup>53</sup> e nº 800 (Portaria SECTICS/MS nº58/2023)<sup>54</sup> , com recomendação final de não incorporação. A Conitec também avaliou a incorporação da vutrisirana para o tratamento de pacientes adultos com amiloidose hereditária mediada por transtirretina com polineuropatia em estágio II, conforme Relatório de Recomendação nº 964/2025 e obteve recomendação final de não incorporação (Portaria SECTICS/MS nº 11/2025). Portanto, o uso destes medicamentos não é preconizado neste PCDT.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.2.4. Cardiomiopatia amiloide associada à transtirretina (ATTR-CM)** -->
O tafamidis 61 mg é recomendado para o tratamento de pacientes com ATTR-CM (selvagem ou hereditária), classe NYHA II ou III e idade acima de 60 anos, pois atua como estabilizador da TTR e retarda o depósito cardíaco. Seu uso resultou em redução na mortalidade e na taxa de hospitalizações relacionadas às questões cardiovasculares<sup>43</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.2.5. Medicamento** -->
- Tafamidis meglumina: cápsulas de 20 mg;  
- Tafamidis: cápsulas de 61 mg.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.3. Esquema de administração** -->
**Tafamidis meglumina:**  
Para tratamento de pacientes com ATTR-PN hereditária (familiar), tafamidis meglumina 20 mg por via oral (VO), uma vez ao dia, ingerida com ou sem alimentos. Não são necessários ajustes de dose para pacientes idosos (acima de 65 anos), nem para pacientes com comprometimento renal ou comprometimento hepático leve ou moderado<sup>55</sup> . O medicamento não deve ser prescrito para a população pediátrica, uma vez que a ATTR-PN não é uma doença presente nesta população<sup>55</sup> , nem para gestantes e lactantes<sup>56</sup> ;

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Tafamidis:** -->
Para tratamento de pacientes com ATTR-CM, tafamidis 61 mg por VO, uma vez ao dia.  
Nota: Por serem medicamentos diferentes, é importante ressaltar que tafamidis e tafamidis meglumina não são intercambiáveis por mg.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.3.1. Eventos adversos** -->
Os eventos adversos em geral são leves e bem tolerados. Os mais comuns são diarreia, dor abdominal, infecção urinária e infecção vaginal<sup>55,56</sup> . Tafamidis contém sorbitol, portanto, pacientes com problemas hereditários de intolerância à frutose não devem tomar este medicamento<sup>55</sup> .

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.3.2. Critérios de interrupção** -->
O tempo de tratamento com tafamidis deve ser monitorado para avaliação da necessidade de outra terapia, incluindo a realização de transplante hepático<sup>55</sup> . Gestantes devem descontinuar o tratamento, podendo retomar após a gestação e período de lactação<sup>56</sup> . Como o medicamento não foi avaliado em pacientes com insuficiência hepática grave, é recomendada precaução no seu uso por essa população<sup>55</sup> .  
Os critérios de interrupção do tratamento devem ser apresentados de forma clara ao paciente quando o medicamento estiver sendo considerado e antes de iniciar seu uso. Durante o acompanhamento clínico do paciente em tratamento medicamentoso, os parâmetros de resposta terapêutica (incluindo as avaliações clínicas e laboratoriais conforme **Quadro 3** ) deverão ser avaliados periodicamente e discutidos com o paciente. No caso de interrupção por falha de adesão, recomenda-se que o paciente seja incentivado à adesão e, caso haja comprometimento explícito de seguimento das recomendações médicas, o paciente poderá retornar ao tratamento.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **6.3.3. Tratamento em populações específicas** -->
Os dados disponíveis em humanos são ainda limitados para avaliar o uso em mulheres grávidas. Na dose de 20 mg/dia ou 80mg/dia, não foram identificados quaisquer riscos associados ao medicamento para defeitos congênitos graves, aborto espontâneo ou resultados maternos ou fetais adversos. Entretanto, com base em estudos em animais, este medicamento pode causar danos fetais (com doses nove vezes maior do que a dose máxima recomendada em humanos). Não há estudos controlados conduzidos em gestações humanas<sup>56</sup> .  
Não há dados específicos sobre o uso em humanos durante a lactação. O medicamento é excretado no leite em estudos com animais. A segurança e a eficácia não foram estabelecidas em pacientes pediátricos<sup>56</sup> .  
Não houve efeitos de tafamidis na fertilidade, no desempenho reprodutivo ou no comportamento de acasalamento em ratos em qualquer dose<sup>55</sup> . Sendo assim, o uso de tafamidis não é recomendado durante a gestação e a lactação<sup>55</sup> .  
Os pacientes que já se encontrarem em tratamento com tafamidis 61 mg quando da publicação deste PCDT deverão ser reavaliados quanto aos critérios de inclusão e exclusão neste Protocolo.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **MONITORAMENTO** -->
Após o início do tratamento, recomenda-se avaliação clínica e laboratorial em até três meses. O paciente deve ser acompanhado por equipe multiprofissional, preferencialmente incluindo nutrólogo e fisioterapeuta, neurologista, cardiologista, nefrologista, além de coleta de dados de IMC e anamnese completa semestrais. Ainda, o paciente deve ser avaliado anualmente por oftalmologista para acompanhamento, com especial atenção à medida de pressão ocular e avaliação do vítreo.  
O cuidado do paciente deve ocorrer em Centro de Referência (CR), sempre que possível, por ser um serviço com equipe multidisciplinar integrada de especialistas<sup>57</sup> , assegurando o adequado diagnóstico e acompanhamento.  
Exames laboratoriais para medir a função renal, cardíaca, hepática, eletrólitos, glicemia, eletroforese de proteínas, lipidograma, exame de urina (EAS -Elementos Anormais do Sedimento, creatinina e proteína), eletroneuromiografia, eletrocardiograma, holter, ecocardiograma, aferição da pressão arterial e marcadores bioquímicos (troponina) devem ser  
realizados a cada 6 meses. Deve-se assumir uma frequência maior para pacientes que apresentem progressão da doença ou qualquer outra preocupação.  
Após 12 meses de tratamento, pacientes com doença estável devem continuar o uso de tafamidis. Já os pacientes que apresentarem progressão dos sinais ou sintomas devem ser avaliados para opções alternativas de tratamento, como o transplante hepático.  
O médico assistente deve solicitar, periodicamente, informações sobre outros membros afetados da família ou avaliá-los. Também deve avaliar se o paciente e sua família têm uma boa compreensão da doença e dos riscos reprodutivos, fornecendo ou encaminhando para orientação e aconselhamento genético adicionais, sempre que aplicável.  
O **Quadro 3** apresenta as avaliações para o acompanhamento de pacientes com ATTR, definindo períodos mínimos para aquelas avaliações que têm por objetivo detectar a eficácia e segurança da terapia medicamentosa. A periodicidade das demais avaliações deve ocorrer conforme critério do médico assistente. O seguimento de pacientes submetidos a transplante hepático deve seguir a conduta adotada pelo centro transplantador.  
**Quadro 3** - Avaliações para seguimento clínico dos pacientes com ATTR  
|**Avaliações***|**Avaliação**<br>**inicial**|**A cada 6**<br>**meses**|**A cada 12**<br>**meses**|
|---|---|---|---|
|Análise genética específica<br>(gene_TTR_– presença de variante patogênica será detectada nos casos de<br>ATTR-PN ou ATTR-CM hereditárias)|X|||
|História médica|X|X||
|Aconselhamento genético|X|||
|Determinação da adesão ao acompanhamento/tratamento||X||
|Avaliação nutricional (peso/altura/IMC)|X|X||
|Avaliação de Sinais Vitais|X|X||
|Aplicação de questionário de qualidade de vida validado|X||X|
|AVALIAÇÃO LABORATORIAL<br>[função renal, hepática, íons, glicemia, eletroforese de proteínas,<br>lipidograma, exame de urina (EAS, creatinina e proteína)]|X|X||
|AVALIAÇÃO NEUROLÓGICA||||
|- Exame neurológico clínico<br>[incluir escalas como_polyneuropathy disability score_(PND) e avaliação<br>sensitivo-motora pelo_neuropathy impairmet score_(NIS)]|X|X||
|- Eletroneuromiografia|X|X||
|AVALIAÇÃO CARDIOLÓGICA**||||
|- Eletrocardiograma|X|||
|- Ecocardiograma|X|||
|- Holter|X|||
|- Laboratório (BNP ou NT-próBNP e troponina)|X|||
|AVALIAÇÃO OFTALMOLÓGICA (pressão ocular e avaliação do vítreo)|X||X|  
* Para pacientes em tratamento específico. As demais avaliações devem ser realizadas em períodos determinados pelo médico assistente.  
**A periodicidade da avaliação depende da forma da ATTR-CM e da evolução clínica.  
Legenda: IMC= Índice de Massa Corpórea; EAS (Elementos Anormais do Sedimento); BNP = peptídeo natriurético cerebral, do inglês brain natriuretic peptide; NT-próBNP = porção N-terminal do precursor de BNP.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento das ATTR deve ser feito por equipe em serviços especializados ou de referência em doenças raras, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias e realização de testes pré-sintomáticos para familiares. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja treinado nessa atividade.  
Os serviços especializados ou de referência têm de estar capacitados com equipe multiprofissional que abranja neurologista com expertise em doenças neuromusculares e eletrofisiologia, cardiologista, ecocardiografistas, nefrologistas, oftalmologistas, gastroenterelogistas, neuropatologistas, hematologistas, geneticistas, fisiatras, especialistas em cintilografia e outros métodos de imagem como a ressonância magnética, nutricionistas, psicólogos e psiquiatras.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com ATTR deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio, conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde, via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
A indicação de transplante deve observar o Regulamento Técnico do Sistema Nacional de Transplantes vigente e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
Os receptores submetidos a transplante originários dos próprios hospitais transplantadores, neles devem continuar sendo assistidos e acompanhados. Os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras (PNAIPDR) e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do SUS, por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014. A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e, como objetivo, reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias, além de melhorar a qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno, redução de incapacidade e cuidados paliativos.  
A linha de cuidado da atenção aos usuários com demanda para a realização das ações na PNAIPDR é estruturada pela APS e Atenção Especializada à Saúde (AES), em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A APS é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário  
na RAS. Já a AES é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da APS.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o locus da atenção à saúde dos pacientes com doenças raras.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da AES, assim classificados:  
- Serviço de Atenção Especializada em Doenças Raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de Referência em Doenças Raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os serviços de AES em doenças raras.  
Assim, o atendimento de pacientes com doenças raras é feito, prioritariamente, na APS, principal porta de entrada para o SUS e, se houver necessidade, o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade.  
Considerando que cerca de 80% das doenças raras são de origem genética, o Aconselhamento Genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O AG é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Recomenda-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **REFERÊNCIAS** -->
1. Westermark P, Benson MD, Buxbaum JN, Cohen AS, Frangione B, Ikeda S-I, et al. A primer of amyloid nomenclature. Amyloid. 2007;14(3):179–83.  
2. Cohen AD, Comenzo RL. Systemic light-chain amyloidosis: advances in diagnosis, prognosis, and therapy. Hematology. 2010;2010(1):287–94.  
3. Merlini G, Bellotti V. Molecular mechanisms of amyloidosis. N Engl J Med. 2003;349:583–96.  
4. Sekijima Y. Hereditary Transthyretin Amyloidosis. 2001 Nov 5 [Updated 2021 Jun 17]. In: Adam MP, Mirzaa GM, Pagon RA, et al., editors. GeneReviews® [Internet]. Seattle (WA): University of Washington, Seattle; 1993-2023.  
5. Hamilton JA, Benson MD. Transthyretin: a review from a structural perspective. Cell Mol Life Sci. 2001;58(10):1491–521.  
6. Planté-Bordeneuve V. Update in the diagnosis and management of transthyretin familial amyloid polyneuropathy. J Neurol. 2014;261:1227–33.  
7. González-López E, López-Sainz Á, Garcia-Pavia P. Diagnosis and Treatment of Transthyretin Cardiac Amyloidosis. Progress and Hope. Rev Esp Cardiol (Engl Ed). 2017 Nov;70(11):991-1004. English, Spanish. doi: 10.1016/j.rec.2017.05.036. Epub 2017 Sep 1.  
8. Adams D, Koike H, Slama M, Coelho T. Hereditary transthyretin amyloidosis: a model of medical progress for a fatal disease. Nat Rev Neurol 2019;15(07):387–404.  
9. Conceicão I, Carvalho M. Clinical variability in type I familial amyloid polyneuropathy (Val30Met): Comparison between late- and early-onset cases in Portugal. Muscle Nerve. 2007;35(1):116–8.  
10. Cruz MW. Regional differences and similarities of familial amyloidotic polyneuropathy (FAP) presentation in Brazil. Amyloid. 2012;19(Suppl.1):65–7.  
11. Parman Y, Adams D, Obici L, et al; European Network for TTR-FAP (ATTReuNET) Sixty years of transthyretin familial amyloid polyneuropathy (TTR-FAP) in Europe: where are we now? A European network approach to defining the epidemiology and management patterns for TTR-FAP. Curr Opin Neurol 2016;29(Suppl 1, Suppl 1)S3–S13.  
12. Schmidt HWC. M.; Botteman, M.F.; Carter, J.A.; Chopra, A.S.; Stewart, M.; Hopps, M.; Fallet, S.; Amass, L. Global prevalence estimates of transthyretin familial amyloid polyneuropathy (ATTR-FAP): a systematic review and projections. The 19th annual European Congress of International Society for Pharmacoeconomics and Outcomes Research. Vienna, Austria2016.  
13. Benson MD, Dasgupta NR, Rao R. Diagnosis and Screening of Patients with Hereditary Transthyretin Amyloidosis (hATTR): Current Strategies and Guidelines. Ther Clin Risk Manag 2020; 16:749–758.  
14. Cruz MW, Pinto MV, Pinto LF, et al. Baseline disease characteristics in Brazilian patients enrolled in Transthyretin Amyloidosis Outcome Survey (THAOS). Arq Neuropsiquiatr 2019;77(02): 96–100.  
15. Jacobson DR, Pastore R, Pool S, Malendowicz S, Kane I, Shivji A, et al. Revised transthyretin Ile 122 allele frequency in African-Americans. Hum Genet. 1996;98:236–8.  
16. Pinto MV, França MC Jr, Gonçalves MVM, Machado-Costa MC, Freitas MRG, Gondim FAA, Marrone CD, Martinez ARM, Moreira CL, Nascimento OJM, Covaleski APP, Oliveira ASB, Pupe CCB, Rodrigues MMJ, Rotta FT, Scola RH, Marques W Jr, Waddington-Cruz M. Brazilian consensus for diagnosis, management and treatment of hereditary transthyretin amyloidosis with peripheral neuropathy: second edition. Arq Neuropsiquiatr. 2023 Mar;81(3):308-321.  
17. Simões MV, et al. Posicionamento sobre Diagnóstico e Tratamento da Amiloidose Cardíaca – 2021. Arq Bras Cardiol. 2021; 117(3):561-598.  
18. Sekijima, Y., Ueda, M., Koike, H. et al. Correction to: Diagnosis and management of transthyretin familial amyloid polyneuropathy in Japan: red-flag symptom clusters and treatment algorithm. Orphanet J Rare Dis 14, 111 (2019).  
19. Sousa A, Coelho T, Barros J, Sequeiros J. Genetic epidemiology of familial amyloidotic polyneuropathy (FAP)-type I in Povoa do Varzim and Vila do Conde (North of Portugal). Am J Med Genet - Neuropsychiatr Genet. 1995;60:512–21.  
20. Holmgren G, Costa PM, Andersson C, Asplund K, Steen L, Beckman L, et al. Geographical distribution of TTR met30 carriers in northern Sweden: discrepancy between carrier frequency and prevalence rate. J Med Genet. 1994;31:351–4.  
21. Bittencourt P, Couto C, Clemente C, Farias A, Palácios S, Mies S, et al. Phenotypic expression of familial amyloid polyneuropathy in Brazil. Eur J Neurol. 2005;12(4):289–93.  
22. Bittencourt P, Couto C, Farias A, Marchiori P, Massarollo P, Mies S. Results of liver transplantation for familial amyloid polyneuropathy type I in Brazil. Liver Transpl. 2002;8(1):34–9.  
23. Lavigne-Moreira C, Marques VD, Gonçalves MVM, de Oliveira MF, Tomaselli PJ, Nunez JC, do Nascimento OJM, Barreira AA, Marques W Jr. The genetic heterogeneity of hereditary transthyretin amyloidosis in a sample of the Brazilian population. J Peripher Nerv Syst. 2018 Jun;23(2):134-137.  
24. Fábio Fernandes, Georgina del Cisne Jadán Luzuriaga, Guilherme Wesley Peixoto da Fonseca, Edileide Barros Correia, Alzira Alves Siqueira Carvalho AVSM et al. Clinical and genetic profiles of patients with hereditary and wild-type transthyretin amyloidosis: the Transthyretin Cardiac Amyloidosis Registry in the state of São Paulo, Brazil (REACT-SP). Orphanet J Rare Dis. 2024;19(1):273.  
25. Conceição I. Clínica e história natural da polineuropatia amiloidotica familiar. Sinapse. 2006;6(Suppl.1):86–90.  
26. Ando Y, Coelho T, Berk JL, Cruz MW, Ericzon B-G, Ikeda S, et al. Guideline of transthyretin related hereditary amyloidosis for clinicians. Orphanet J Rare Dis. 2013;8:31.  
27. Gertz MA, Dispenzieri A. Systemic Amyloidosis Recognition, Prognosis, and Therapy: A Systematic Review. JAMA. 2020;324(1):79-89.  
28. Lobato L, Beirão I, Silva M, Fonseca I, Queiros J, Rocha G, Sarmento AM, Sousa A, Sequeiros J. End-stage renal disease and dialysis in hereditary amyloidosis TTR V30M: presentation, survival and prognostic factors. Amyloid. 2004;11:27–37.  
29. Wixner J, Mundayat R, Karayal ON, Anan I, Karling P, Suhr OB. THAOS: Gastrointestinal manifestations of transthyretin amyloidosis - common complications of a rare disease. Orphanet J Rare Dis. 2014;9:1–9.  
30. Fonseca I. Emagrecimento e desnutrição na Polineuropatia Amiloidótica Familiar de tipo português. Sinapse. 2006;6(Suppl.1):121–4.  
31. Ando E, Ando Y, Okamura R, Uchino M, Ando M, Negi A. Ocular manifestations of familial amyloidotic polyneuropathy type I: long term follow up. Br J Ophthamology. 1997;81:295–8.  
32. Andrade M. Introdução às alterações vésico-esfincterianas na polineuropatia amiloidótica familiar. Sinapse. 2006;6(Suppl.1):103–9.  
33. Maia LF, Magalhaes R, Freitas J, Taipa R, Pires MM, Osorio H, et al. CNS involvement in V30M transthyretin amyloidosis: clinical, neuropathological and biochemical findings. J Neurol Neurosurg Psychiatry. 2014;86(2):159–67.  
34. Sousa L, Coelho T, Taipa R. CNS Involvement in Hereditary Transthyretin Amyloidosis. Neurology 2021;97(24):1111–1119.  
35. Quintanilha GS, Cruz MW, Silva MTT, Chimelli L. Oculoleptomeningeal Amyloidosis Due to Transthyretin p.Y89H (Y69H) Variant. J Neuropathol Exp Neurol 2020;79(10):1134–1136.  
36. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Relatório de recomendação: Tafamidis meglumina no tratamento da polineuropatia amiloidótica familiar relacionada à proteína transtirretina. Brasília: Ministério da Saúde; 2018. 43 p.  
37. Ando Y, Adams D, Benson MD, Berk JL, Planté-Bordeneuve V, Coelho T, Conceição I, Ericzon BG, Obici L, Rapezzi C, Sekijima Y, Ueda M, Palladini G, Merlini G. Guidelines and new directions in the therapy and monitoring of ATTRv amyloidosis. Amyloid. 2022 Sep;29(3):143-155.  
38. Writing Committee; Kittleson MM, Ruberg FL, Ambardekar AV, Brannagan TH, Cheng RK, Clarke JO, Dember LM, Frantz JG, Hershberger RE, Maurer MS, Nativi-Nicolau J, Sanchorawala V, Sheikh FH. 2023 ACC Expert Consensus Decision Pathway on Comprehensive Multidisciplinary Care for the Patient With Cardiac Amyloidosis: A Report of the American College of Cardiology Solution Set Oversight Committee. J Am Coll Cardiol. 2023 Mar 21;81(11):1076-1126.  
39. Carretero M, Sáez MS, Posadas-Martínez ML, Aguirre MA, Sorroche P, Negro A, Calandra CR, Salutto V, Lautre A, Conti E, León-Cejas L, Reisin R, Nucifora EM, Rugiero M. Guía de práctica clínica de tratamiento de la polineuropatía amiloidótica familiar [Practice guideline for the treatment of familial amyloid polyneuropathy]. Medicina (B Aires). 2022;82(2):262-274.  
40. Coutinho P DA, Lima J L, Barbosa A R. Amsterdam: Excerpta Medica; 1980. Forty years of experience with type I amyloid neuropathy: review of 483 cases; pp. 88–98.  
41. Ministério da Saúde. Ministério da Saúde. 2024. p. 39 Portaria SAES/SECTICS no 10, de 13 de setembro de 2024. Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Insuficiência Cardíaca com Fração de Ejeção Reduzida. Available from: https://www.gov.br/conitec/pt-br/midias/protocolos/pcdt-de-insuficiencia-cardiaca  
42. Brasil. Ministério da Saúde. Gabinete do Ministro. Portaria no 2.600, de 21 de outubro de 2009: Aprova o Regulamento Técnico do Sistema Nacional de Transplantes [Internet]. 2009. Available from: http://bvsms.saude.gov.br/bvs/saudelegis/gm/2009/prt2600_21_10_2009.html  
43. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Relatório de recomendação: Tafamidis no tratamento de pacientes com cardiomiopatia amiloide associada à transtirretina (selvagem ou hereditária), classes NYHA II e III acima de 60 anos de idade. Brasília: Ministério da Saúde; 2022. 58 p.  
44. Suhr O. Impact of liver transplantation on familial amyloidotic polyneuropathy (FAP) patients’ symptoms and complications. Amyloid. 2003;10(Suppl. 1):77–83.  
45. Drent G, Graveland CW, Hazenberg BPC, Haagsma EB. Quality of life in patients with familial amyloidotic polyneuropathy long-term after liver transplantation. Amyloid. 2009;16(3):133–41.  
46. Okamoto S, Zhao Y, Lindqvist P, Backman C, Ericzon BG, Wijayatunga P, Henein MY, Suhr OB. Development of cardiomyopathy after liver transplantation in Swedish hereditary transthyretin amyloidosis (ATTR) patients. Amyloid. 2011; Dec;18(4):200-5.  
47. Sack FU, Kristen A, Goldschmidt H, Schnabel PA, Dengler T, Koch A, Karck M. Treatment options for severe cardiac amyloidosis: heart transplantation combined with chemotherapy and stem cell transplantation for patients with ALamyloidosis and heart and liver transplantation for patients with ATTR-amyloidosis. Eur J Cardiothorac Surg. 2008 Feb;33(2):257-62.  
48. Cruz MW, Amass L, Keohane D, Schwartz J, Li H, Gundapaneni B. Early intervention with tafamidis provides long-term (5.5-year) delay of neurologic progression in transthyretin hereditary amyloid polyneuropathy. Amyloid. 2016;23(3):178–83.  
49. Coelho T, Maia LF, Martins A, Waddington M. Tafamidis for transthyretin familial amyloid polyneuropathy: a randomized, controlled trial. Neurology. 2012;79:785–92.  
50. Coelho T, Maia LF, da Silva AM, Cruz MW, Planté-Bordeneuve V, Suhr OB, et al. Long-term effects of tafamidis for the treatment of transthyretin familial amyloid polyneuropathy. J Neurol. 2013;260(11):2802–14.  
51. Suhr OB, Conceição IM, Karayal ON, Mandel FS, Huertas PE, Ericzon B. Post hoc analysis of nutritional status in patients with transthyretin familial amyloid polyneuropathy: impact of tafamidis. Neurol Ther. 2014;3(2):101–12.  
52. Merlini G, Planté-Bordeneuve V, Judge DP, Schmidt H, Obici L, Perlini S, et al. Effects of tafamidis on transthyretin stabilization and clinical outcomes in patients with non-Val30Met transthyretin amyloidosis. J Cardiovasc Transl Res. 2013;6(6):1011–20.  
53. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Relatório de recomendação nº 799: Inotersena para o tratamento da polineuropatia amiloidótica familiar relacionada à transtirretina em pacientes adultos em estágio 2 ou pacientes não respondedores a tafamidis meglumina. Portaria SECTICS/MS nº 24/2023 - Publicada em 11/05/2023. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2023/20230511_relatorio_799_inotersena_pafttr.pdf  
54. Ministério da Saúde (Brasil). Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC). Relatório de recomendação nº 800: Patisirana no tratamento de pacientes diagnosticados com amiloidose hereditária relacionada à transtirretina (ATTRh) com polineuropatia em estágio 2 ou que apresentem resposta inadequada ao tafamidis. Portaria SECTICS/MS nº 58/2023 – Publicada em 20/10/2023. Disponível em: https://www.gov.br/conitec/ptbr/midias/relatorios/2023/copy_of_Relatorioderecomendacao800Patisirana_para_ATTRh_polineuropatia.pdf  
55. Pfizer U.S. Pharmaceuticals Group. Product Information. Vyndaqel (tafamidis). 2019.  
56. Verma B, Patel P. Tafamidis. [Updated 2023 May 29]. In: StatPearls [Internet]. Treasure Island (FL): StatPearls Publishing;  
- 2023 Jan-. Available from: https://www.ncbi.nlm.nih.gov/books/NBK574508/  
57. BRASIL. Ministério da Saúde. Gabinete do Ministro. Portaria nº 199, de 30 de janeiro de 2014. Brasília, 2014.  
**TERMO DE ESCLARECIMENTO E RESPONSABILIDADE TAFAMIDIS, TAFAMIDIS MEGLUMINA**  
Eu, ______________________________________________________________________________________ (nome  
do (a) paciente), declaro ter sido informado (a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de **tafamidis meglumina ou tafamidis** , indicada para o tratamento da **polineuropatia amiloide por Transtirretina (ATTR-PN) hereditária** ou **cardiomiopatia amiloide por Transtirretina (ATTR-CM) hereditária ou selvagem** , respectivamente.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a) __________________  
______________________________________________________________________ (nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Posterga a progressão da neuropatia periférica;  
- Melhora a condição nutricional.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais eventos adversos, riscos e precauções:  
- Medicamento classificado na gestação como fator de risco C (os estudos em animais revelaram toxicidade reprodutiva, portanto, não é recomendado seu uso durante a gravidez ou em mulheres com potencial para engravidar que não utilizam métodos contraceptivos);  
- Contraindicado em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da fórmula;  
- Pacientes com problemas hereditários de intolerância à frutose não devem tomar este medicamento;  
- Mulheres com potencial para engravidar deverão utilizar um método contraceptivo eficaz durante o tratamento com  
- tafamidis ou tafamidis meglumina e durante um mês após o tratamento, devido à meia-vida prolongada;  
- O tafamidis e o tafamidis meglumina não devem ser utilizados durante a amamentação, pois os dados farmacodinâmicos e toxicológicos disponíveis em animais mostraram excreção de tafamidis e tafamidis meglumina no leite; assim não pode ser excluído qualquer risco para os recém-nascidos e lactentes;  
- Os eventos adversos em geral são leves e bem tolerados, sendo que os mais comuns são diarreia, dor abdominal e  
- infecção urinária.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim  (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) Tafamidis meglumina 20 mg  (    ) Tafamidis 61mg  
|Local:|Data:|||
|---|---|---|---|
|Nome do paciente:||||
|Cartão Nacional de Saúde:||||
|Nome do responsável legal:||||
|Documento de identificação do re|sponsável legal:|||
||_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:||CRM:|UF:|
||___________________________<br>Assinatura e carimbo do médico<br>Data:____________________|||  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) das Amiloidoses associadas à Transtirretina (ATTR), contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Inovação e do Complexo EconômicoIndustrial da Saúde do Ministério da Saúde (DGITS/SECTICS/MS).  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
Esta proposta de atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) tem como finalidade atualizar as recomendações do Ministério da Saúde (MS) para diagnóstico, tratamento, monitoramento e acompanhamento de pessoas com Amiloidose relacionada à Transtirretina (ATTR) atendidos no Sistema Único de Saúde (SUS), e não somente àquelas portadoras do fenótipo de polineuropatia amiloide por transtirretina (ATTR-PN) hereditária. A atualização contemplou mudanças nos cuidados e monitoramento dos pacientes nos últimos anos.  
O processo de atualização deste PCDT foi conduzido de acordo com a Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde (2020) e incluiu buscas e avaliação da literatura científica disponível sobre pessoas com Amiloidose relacionada à transtirretina (ATTR). Os achados foram traduzidos em recomendações voltadas à assistência no SUS, formuladas por um painel de especialistas no tema e representantes de pacientes. Neste contexto, o PCDT constitui um instrumento que confere segurança e efetividade clínica de modo organizado e acessível, com base nas melhores evidências científicas disponíveis.  
A partir da versão do PCDT publicada pela Portaria Conjunta SAES-SCTIE/MS nº 22, de 02 de outubro de 2018, foram incluídos estudos, diretrizes e as avaliações da Conitec realizadas após essa data para a atualização das evidências e das recomendações sobre o tema, bem como a atualização de dados epidemiológicos.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Equipe de elaboração e partes interessadas** -->
A proposta inicial de atualização do PCDT das Amiloidoses associadas à Transtirretina (ATTR) foi inicialmente discutida durante a reunião de pré-escopo, ocorrida em 06 de dezembro de 2022. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo EconômicoIndustrial da Saúde (SECTICS) e Secretaria de Atenção Especializada em Saúde (SAES).  
Posteriormente, o escopo do documento foi discutido na reunião de escopo, ocorrida em 08 de maio de 2023. A reunião teve a presença de metodologistas e especialistas do Grupo Elaborador, representantes da SECTICS e SAES, representantes de pacientes, de sociedades médicas e especialistas convidados.  
O Protocolo foi atualizado pelo Núcleo de Avaliação de Tecnologias do Hospital de Clínicas de Porto Alegre (HCPA).  
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A** - Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos ben|efícios abaixo?|
|---|---|
|Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou|(   ) Sim|
|prejudicada com as recomendações da diretriz?|(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afetados<br>atividade na elaboração ou revisão da diretriz?|pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim|  
||(   ) Não|
|---|---|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e que|(   ) Sim|
|deveria ser do conhecimento público?|(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar sua|(   ) Sim|
|objetividade ou imparcialidade?|(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT das Amiloidoses hereditárias associadas à transtirretina foi apresentada na 119ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 17 de setembro de 2024. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS); Secretaria de Atenção Especializada em Saúde (SAES). O PCDT foi aprovado para avaliação da Conitec e a proposta foi aprovada para ser apresentada aos membros do Comitê de PCDT da Conitec em sua 134ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.  
Considerando os ajustes em decorrência da Consulta Pública nº 71/2024, a proposta de atualização do PCDT das Amiloidoses associadas à transtirretina foi apresentada à Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, à sua 124ª Reunião Ordinária, realizada em 15 de abril de 2025. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia e Inovação e do Complexo Econômico-Industrial da Saúde (SECTICS), Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Vigilância em Saúde e Ambiente (SVSA) e Secretaria de Saúde Indígena (SESAI). O PCDT foi aprovado para avaliação da Conitec.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Consulta Pública** -->
A Consulta Pública nº 71/2024, para a atualização do Protocolo Clínico e Diretrizes Terapêuticas das Amiloidoses Hereditárias associadas à Transtirretina (TTR), foi realizada entre os dias 16 de outubro de 2024 a 04 de novembro de 2024. Foram recebidas cento e vinte e três contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2024/contribuicoes-da-consulta-publica-71-2024-de-amiloidoses-hereditarias-associadas-atranstirretina.</u>

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **Busca da evidência e recomendações** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Conitec para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento das ATTR. Não foram encontradas tecnologias disponíveis já incorporadas para o tratamento das ATTR, além do tafamidis e transplante hepático.  
Foi também realizada, em 08 de setembro de 2023, uma busca por diretrizes clínicas nacionais e internacionais e recomendações de especialistas a respeito da doença. Foram utilizados os termos “ _Familial Amyloid Neuropathy_ ” OR “Familial Transthyretin Cardiac Amyloidosis” OR “Hereditary Amyloidosis, Transthyretin Related” AND “tafamidis meglumine” OR  
“treatment” e restringindo-se para estudos em humanos, nos idiomas português, espanhol e inglês, sem limite de data. As  
seguintes bases de dados e websites institucionais que abrigam protocolos e diretrizes foram consultados:  
- Diretrizes da Associação Médica Brasileira (AMB);  
- Protocolos Clínicos e Diretrizes terapêuticas do Ministério da Saúde; e  
- PubMed/MEDLINE.  
O **Quadro B** descreve as estratégias utilizadas de acordo com a base de dados.  
**Quadro B** - Estratégias de busca, de acordo com a base de dados:  
|**Bases de dados**|**Estratégia de busca**|**Número de resultados**<br>**encontrados**|
|---|---|---|
|**Medline (via Pubmed)**|(("Familial Amyloid Neuropathy"[MeSH Terms]) OR<br>("Familial Transthyretin Cardiac Amyloidosis") OR<br>("Hereditary Amyloidosis, Transthyretin Related")) Filters:<br>Clinical Trial, Guideline, Meta-Analysis, Randomized<br>Controlled Trial, Systematic Review|67 artigos|
|**Embase**|'hereditary transthyretin amyloidosis' AND ([cochrane<br>review]/lim OR [systematic review]/lim OR [meta<br>analysis]/lim OR [controlled clinical trial]/lim OR [randomized<br>controlled trial]/lim OR [clinical trial]/lim)|88 artigos|
|**Cochrane library**|Familial Amyloid Neuropathy in Title Abstract Keyword<br>Familial Transthyretin Cardiac Amyloidosis in Title Abstract<br>Keyword|1 Cochrane Reviews<br>0 Cochrane Reviews|
||Hereditary Amyloidosis, Transthyretin Related in Title<br>Abstract Keyword|0 Cochrane Reviews|  
Foram localizados 156 artigos nas três bases de dados. Excluindo as 16 duplicatas, 10 artigos foram selecionados para leitura na íntegra e apenas quatro<sup>13,15,40,41</sup> foram incluídas neste relatório. Outros artigos de conhecimento dos autores foram utilizados. A  
**Figura A** apresenta a estratégia e os resultados das buscas realizadas.  
**Figura A** - Fluxograma de seleção dos estudos.  
Para as recomendações sobre o tratamento, diagnóstico e monitoramento, foram adotadas as recomendações do PCDT da Polineuropatia Amiloidótica Familiar publicado pela Portaria Conjunta SAS/SCTIE/MS n° 16 de 24 de maio de 2018. Também foram utilizadas as evidências identificadas pelas buscas, para atualização dos textos, assim como as bulas dos medicamentos incorporados ao SUS para o tratamento das ATTR. Diretrizes internacionais, recomendações e consensos de especialistas e avaliações de outras agências de Avaliação de Tecnologias em Saúde também foram utilizados.  
**QUESTÃO 1: Qual a eficácia e a segurança do tafamidis no tratamento da cardiomiopatia amiloide associada à transtirretina, selvagem ou hereditária, classes funcionais NYHA II e III, em pessoas acima de 60 anos de idade, quando comparado ao placebo, melhor cuidado de suporte ou transplante?**  
**Recomendação** : Adotou-se a deliberação da Conitec, em recomendar a incorporação no SUS do tafamidis 61 mg no tratamento de pacientes com cardiopatia amiloide associada à transtirretina (selvagem ou hereditária), classe NYHA II e III acima de 60 anos de idade, conforme Relatório de Recomendação nº 899/2024, disponível em: https://www.gov.br/conitec/pt- <u>br/midias/relatorios/2024/tafamidis-61-mg-no-tratamento-de-pacientes-com-cardiopatia-amiloide-associada-a-transtirretinaselvagem-ou-hereditaria-classe-nyha-ii-e-ii-acima-de-60-anos-de-idade</u>  
A estrutura PICO para esta pergunta foi:  
P- População: Pacientes acima de 60 anos de idade com cardiomiopatia amiloide associada à transtirretina (hereditária ou selvagem), classe NYHA II e III  
I – Intervenção: Tafamidis  
C – Comparação: Placebo, melhor cuidado de suporte ou transplante  
O - Desfechos Primários:  
- Hospitalização por causas cardiovasculares  
- Mortalidade por todas as causas  
- Qualidade de vida  
Secundários:  
- Teste de caminhada de seis minutos  
- Eventos adversos não graves ou totais  
- Eventos adversos graves  
Desenho de Estudo: Ensaio clínico randomizado  
Métodos e resultados da busca:  
Para responder essa pergunta, foi utilizada a síntese de evidências apresentada no Relatório de Recomendação n° 899/2024 da Conitec. Não foi realizada uma busca adicional na literatura, uma vez que a busca presente no referido Relatório foi considerada recente.

---

<!-- METADADOS: doenca: Amiloidoses Associadas a Transtirretina | secao: **HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>**Relatório da diretriz**<br>**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Tecnologias av**<br>**Incorporação ou alteração**<br>**do uso no SUS**|**aliadas pela Conitec**<br>**Não incorporação ou não**<br>**alteração no SUS**|
|---|---|---|---|
|Relatório de<br>Recomendação nº<br>1007 de maio de 2025|Atualização do conteúdo do<br>PCDT.<br>Ampliação do escopo para<br>cardiomiopatia amiloide por<br>transtirretina (ATTR-CM).<br>Alteração do título.<br>Inclusão das manifestações<br>neurológicas e cardíacas da<br>ATTR, de todos os estágios da<br>doença, na população-alvo.<br>Incorporação de tecnologias no<br>SUS.|Tafamidis 61 mg no<br>tratamento de pacientes com<br>cardiopatia amiloide<br>associada à transtirretina<br>(selvagem ou hereditária),<br>classe NYHA II e II acima<br>de 60 anos de idade<br>[Relatório de Recomendação<br>nº 899/2024; Portaria<br>SECTICS/MS nº 26/2024].|Vutrisirana no tratamento de<br>pacientes adultos com amiloidose<br>hereditária mediada por<br>transtirretina com polineuropatia<br>em estágio II. [Relatório de<br>Recomendação nº 964/2025;<br>Portaria SECTICS/MS nº<br>11/2025].<br>Inotersena para o tratamento da<br>polineuropatia amiloidótica<br>familiar relacionada à<br>transtirretina em pacientes adultos<br>no Estágio 2 no SUS [Relatório de<br>Recomendação nº 922/2024;<br>Portaria SECTICS/MS nº<br>47/2024].<br>Patisirana no tratamento de<br>pacientes diagnosticados com<br>amiloidose hereditária relacionada<br>à transtirretina (ATTRh) com<br>polineuropatia em estágio 2 ou<br>que apresentem resposta<br>inadequada ao tafamidis.<br>[Relatório de Recomendação nº<br>800/2023; Portaria SECTICS/MS<br>nº 58/ 2023].<br>Inotersena para o tratamento da<br>polineuropatia amiloidótica<br>familiar relacionada à|  
|**Número do**<br>**Relatório da diretriz**||**Tecnologias av**|**aliadas pela Conitec**|
|---|---|---|---|
|**clínica (Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração**<br>**do uso no SUS**|**Não incorporação ou não**<br>**alteração no SUS**|
||||transtirretina em pacientes adultos<br>não atendidos pela terapia com<br>estabilizadores da proteína TTR<br>no SUS. [Relatório de<br>Recomendação n° 799/2023;<br>Portaria SECTICS/MS nº<br>24/2023]<br>Tafamidis meglumina no<br>tratamento de pacientes com<br>cardiomiopatia amiloide associada<br>à transtirretina (selvagem ou<br>hereditária), classes NYHA II e III<br>acima de 60 anos de idade<br>[Relatório de Recomendação nº<br>795/2022; Portaria SCTIE/MS nº<br>177/2022].<br>Tafamidis meglumina no<br>tratamento de pacientes com<br>cardiomiopatia amiloide associada<br>à transtirretina (selvagem ou<br>hereditária) acima de 60 anos de<br>idade [Relatório de<br>Recomendação nº 10/2021;<br>Portaria  SCTIE/MS nº 10/2021].|
|Portaria Conjunta<br>SAS-SCTIE/MS nº<br>22, de 2 de outubro<br>de 2018<br>[Relatório de<br>Recomendação nº<br>371/2018]|Primeira versão do PCDT da<br>Polineuropatia Amiloidótica<br>Familiar|Tafamidis meglumina no<br>tratamento da polineuropatia<br>amiloidótica familiar<br>relacionada à proteína<br>transtirretina [Relatório de<br>Recomendação nº 339/2018;<br>Portaria  SCTIE/MS nº<br>2/2018].|-|

---

