<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA Nº 365, DE 15 DE FEVEREIRO DE 2017.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas Anemia na Doença Renal Crônica.  
O Secretário de Atenção à Saúde, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem parâmetrossobre a anemia na doença renal crônica no Brasil e de diretrizesnacionaisparadiagnóstico, tratamento e acompanhamento dos indivíduoscom esta doença;  
Considerando que os ProtocolosClínicos e DiretrizesTerapêuticas (PCDT) sãoresultado de consenso técnico-científico e são formulados dentro de rigorososparâmetros de qualidade, precisão de indicação e posologia;  
Considerando os registros de deliberação nº 211/2016 e nº 212/2016 e os relatórios de recomendação nº 230 - Agosto/2016 e nº 231 - Agosto/2016, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC); e  
Considerando a avaliação técnica do Departamento de Gestão da Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS), do Departamento de Regulação, Avaliação e Controle de Sistemas (DRAC/SAS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolve:  
Art. 1º  Ficam aprovados, na forma dos anexos a esta Portaria, disponíveis no sítio: www.saude.gov.br/sas, o PROTOCOLOCLÍNICO E DIRETRIZESTERAPÊUTICAS - ANEMIA NA DOENÇA RENAL CRÔNICA – REPOSIÇÃO DE FERRO (Anexo I) e o PROTOCOLOCLÍNICO E DIRETRIZESTERAPÊUTICAS - ANEMIA NA DOENÇA RENAL CRÔNICA – ALFAEPOETINA (Anexo II).  
§ 1º - Os protocolos, objeto deste Artigo, que contêm o conceito geral da anemia na doença renal crônica com vistas à reposição de ferro e uso de alfaepoteina, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, são de caráter nacional e devem ser utilizados pelas Secretarias de Saúde dos Estados, Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes. § 2º - É obrigatória a observância destes protocolos para fins de dispensação de medicamentos neles previstos.  
§ 3º - É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de medicamento preconizado para o tratamento da anemia na doença renal crônica, o que deverá ser formalizado por meio da assinatura do respectivo Termo de Esclarecimento e Responsabilidade, conforme os modelos integrantes dos Protocolos.  
§ 4º - Os gestores Estaduais e Municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com a doença em todas as etapas descritas nos anexos a esta Portaria.  
Art. 2º Esta Portaria entra em vigor na data de sua publicação.  
Art. 3º Fica revogada a Portaria nº 226/SAS/MS, de 10 de maio de 2010, publicada no Diário Oficial da União (DOU) nº 88, de 11 de maio de 2010, seção 1, página 37.  
FRANCISCO DE ASSIS FIGUEIREDO

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 1. METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Utilizou-se como estratégia de busca no PubMed os termos "ferric oxide"[Mesh], "iron"[Mesh], "iron compounds"[Mesh], ("kidney failure, chronic"[Mesh], "hemodialysis"[Mesh]) e "anemia"[Mesh], restringindo-se a busca para ensaios clínicos randomizados e meta-análises publicados nos últimos 10 anos. A busca resultou em 28 artigos.  
No Embase, foram utilizados como estratégia de busca os termos 'hemodialysis'/exp, 'chronic kidney failure'/exp, 'dialysis'/exp, 'anemia'/exp e 'iron'/exp, limitando-se a pesquisa a ensaios clínicos randomizados, meta-análises e revisões da Cochrane publicados nos últimos 10 anos. A busca resultou em 54 artigos.  
Quando avaliadas em conjunto, as buscas em ambas as bases de dados identificaram nove ensaios clínicos e duas meta-análises com intervenções e desfechos relevantes para o tema de interesse nesteProtocolo. As buscas foram realizadas no dia 15 de dezembro de 2009.  
Foram consultados ainda o UpToDate, versão 19.3, e as diretrizes da _National Kidney Foundation - Kidney Disease Outcomes Quality Initiative_ (1). A consulta à bibliografia dessas fontes levou à identificação de outros 11 estudos observacionais, utilizados principalmente na introdução deste Protocolo.  
Em 11 de janeiro 2016, foi realizada atualização da busca. Na base MEDLINE/PubMed, utilizando-se a estratégia "kidney failure, chronic"[MeSH Terms] AND "anemia, iron-deficiency"[MeSH Terms] AND ((systematic[sb] OR Randomized Controlled Trial[ptyp] OR Meta-Analysis[ptyp] OR Guideline[ptyp]) Filters: From 2009/12/16, foram localizadas oito referências. Destas, uma foi selecionada para leitura. Utilizou-se a ferramenta “related articles” com vistas a localizar outros estudos relevantes. Essa busca resultou na inclusão de um estudo.  
Na base Embase, foram utilizados os termos 'chronic kidney failure'/exp AND 'anemia'/exp AND ([cochrane review]/lim OR [systematic review]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND [embase]/lim AND [1-12-2009]/sd, sendo identificados 32 estudos, dos quais nenhum foi selecionado para leitura.  
Na biblioteca Cochrane, utilizando-se os termos de busca "kidney failure, chronic" and "anemia" and "iron", foram localizadas cinco revisões sistemáticas da Cochrane, sendo que quatro foram excluídas e uma já havia sido incluída via PubMed.  
Foi ainda consultada a base de dados UpToDate versão 19.3 e foram incluídos artigos de conhecimento dos autores, resultando na inclusão de 20 novas referências.  
Para responder às demandas da consulta pública, foram incluídas 3 novas referências de conhecimento dos elaboradores.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 2. INTRODUÇÃO -->
A anemia é uma complicação frequente e importante da doença renal crônica (DRC), associando-se com aumento de morbidade e mortalidade (2-6). Utilizando-se a definição clássica de anemia pela Organização Mundial da Saúde (OMS), como nível sérico de hemoglobina inferior a 13 g/dL em homens e mulheres na pós-menopausa e inferior a 12 g/dL em mulheres pré-menopáusicas, essa condição estará presente em cerca de 90% dos pacientes com DRC que apresentam taxa de filtração glomerular estimada inferior a 25-30 mL/min/1,73 m<sup>2</sup> [equações _Modification of Diet in Renal Disease Study_ (MDRD) ou Crockoft-Gault (CKD-EPI) (1,7)]. Entretanto, anemia pode estar presente em pacientes com taxa de filtração glomerular estimada entre 30 e 60 mL/min/1,73 m<sup>2</sup> (2,8,9).  
Na maioria dos casos, a anemia decorre primariamente da produção renal reduzida de eritropoetina. A manutenção de estoques corporais adequados de ferro é fundamental para uma adequada  
resposta ao tratamento com alfaepoetina, sendo a deficiência de ferro ou a sua reduzida disponibilidade as principais causas de falha do tratamento. A deficiência de ferro é comum em pacientes com DRC em estágios avançados e resulta de uma combinação de fatores como redução da ingesta dietética, diminuição da absorção intestinal de ferro e aumento das perdas sanguíneas. Em pacientes em hemodiálise, a perda de ferro é mais expressiva. Estima-se que pacientes em hemodiálise percam em média 2 g de ferro por ano pelo método dialítico em si, além de outras perdas (gastrointestinais, coletas de sangue frequentes, etc.), justificando a necessidade de avaliação sistemática e reposição apropriada (10).  
No Brasil, estima-se, a partir dos dados do Sistema de Informações Ambulatoriais do SUS, que, em 2015, 91.963 pacientes submeteram-se a diálise, dos quais em torno de 90% a hemodiálise. O uso de alfaepoetina fez parte do tratamento de mais de 80% desses pacientes. (11)  
Apesar de a reposição de ferro ter benefícios definidos em pacientes com DRC, incluindo a melhora da anemia (e não a correção) e redução de dose de alfaepoetina, a melhor forma de administração e parâmetros para sua indicação e acompanhamento ainda são motivos de controvérsia, razão pela qual a sua regulamentação pelo SUS se faz necessária.  
A identificação dos fatores de risco da doença renal crônica, seu diagnóstico em estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para a prevenção e controle desta doença, a redução de suas incidência e mortalidade e um melhor resultado terapêutico e prognóstico dos casos que não puderam ser evitados.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- N 18.0 Doença renal em estádio final  
- N18.8 Outra insuficiência renal crônica

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 4. DIAGNÓSTICO -->
Antes do início do tratamento, todos os pacientes devem ser avaliados e outras causas de anemia, afastadas. Os pacientes devem ser submetidos a uma anamnese e exame físico detalhados, bem como à realização de hemograma completo e determinação das reservas de ferro. A avaliação dos parâmetros hematimétricos do hemograma, como volume corpuscular médio (VCM), concentração de hemoglobina corpuscular média (CHCM) e índice de anisocitose eritrocitária ( _red blood cell distribution width_ , RDW), pode auxiliar no diagnóstico diferencial de outras causas de anemia. A saturação de transferrina avalia o ferro funcionalmente disponível para a eritropoese e é calculada pela equação: concentração de ferro sérico (mg/dL) x 100/capacidade total de ligação de ferro.  
A ferritina sérica é o marcador mais utilizado para avaliar as reservas orgânicas de ferro, estando diminuída em caso de deficiência desse mineral, embora seja sujeita a considerável variabilidade biológica e variação entre diferentes técnicas de dosagem (12). A ferritina sérica encontra-se elevada em estados de sobrecarga de ferro, mas também é influenciada por outras condições não relacionadas ao metabolismo do ferro, como inflamação, desnutrição, infecção, doença hepática e malignidades, sendo considerada um reagente de fase aguda da inflamação. A presença de tais condições deve ser criteriosamente considerada durante a avaliação clínica. Às vezes, na prática clínica, o método definitivo de demonstrar a deficiência de ferro na DRC tem sido avaliar a resposta hematopoética à sua administração (13). É muito importante destacar a relação entre as condições inflamatórias e a regulação dos estoques de ferro corporais (14). A hepticidina, uma proteína produzida no fígado, é a principal reguladora da homeostase do ferro. Altos níveis de hepticidina levam à retenção do ferro no sistema reticulo-endotelial e limitam sua disponibilidade para a eritropoese. Níveis elevados de hepticidina têm sido achados em pacientes com DRC e com doenças inflamatórias, pois esse peptídeo é excretado na urina e induzido por vários agentes pró-inflamatórios (15). Nessas condições, o escalonamento da dose de ferro administrada pode levar ao aumento dos depósitos teciduais de ferro, com potencias efeitos deletérios desse metal sobre a função imune (16) e a mediação de estresse oxidativo (17,18).  
Devido à condição inflamatória dos pacientes com DRC, os valores de referência de ferritina sérica para diagnóstico de deficiência de ferro são mais elevados do que para a população sem doença renal. Os critérios para diagnóstico de deficiência absoluta de ferro em pacientes com DRC em tratamento conservador ou em diálise peritoneal são:  
- ferritina inferior a 100 ng/mL e  
- saturação de transferrina inferior a 20%.  
Em pacientes em hemodiálise, o diagnóstico de deficiência de ferro é dado por:  
- ferritina inferior a 200 ng/mL e  
- saturação de transferrina inferior a 20%.  
Os pacientes com DRC também podem apresentar deficiência funcional de ferro, condição na qual os estoques corporais estão aumentados, mas o ferro não pode ser mobilizado adequadamente para a eritropoese devido ao sequestro no sistema retículo-endotelial.  
Os critérios para deficiência relativa (19) são:  
Para pacientes sob hemodiálise: ferritina sérica entre 200 e 500 ng/mL e saturação de transferrina inferior a 20%.  
Para os pacientes com DRC em tratamento conservador ou diálise peritoneal: ferritina sérica entre 100 e 500 ng/mL e  saturação de transferrina inferior a 20%.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 5. CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo os pacientes adultos, de ambos os sexos, que apresentarem o diagnóstico de DRC nos estágios 3 a 5 (filtração glomerular estimada inferior a 60 mL/min/1,73 m<sup>2</sup> ), conforme definido por normas e diretrizes reconhecidas),(20,21), na presença dos seguintes critérios:  
- anemia, com hemoglobina sérica inferior a 10 g/dL em ambos os sexos e  
- deficiência absoluta ou relativa de ferro (conforme o item 4 DIAGNÓSTICO).  
A suplementação de ferro em crianças está indicada sempre que a saturação da transferrina for inferior a 20% e a ferritina, inferior a 200 ng/mL. (22)

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 6. CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo os pacientes que apresentarem:  
- hemocromatose;  
- hemossiderose;  
- anemia hemolítica;  
- ferritina sérica acima de 500 ng/mL e saturação de transferrina superior a 30%; ou  
- hipersensibilidade ou intolerância ao produto ou a um de seus componentes.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 7. CASOS ESPECIAIS -->
Pacientes em tratamento conservador ou em diálise peritoneal podem se beneficiar do uso do ferro por via oral como suplementação. Caso apresentem intolerância gastrointestinal, inadequada adesão ou resposta insuficiente ao tratamento oral, poderá ser considerada a reposição parenteral de ferro. Nesses casos, o diagnóstico de deficiência de ferro é dado por nível de ferritina inferior a 100 ng/mL e saturação de transferrina inferior a 20%.  
Na gravidez, é recomendada uma dose de 25 mg por semana de sacarato de hidróxido férrico intravenoso. Não se recomenda o uso no primeiro trimestre.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8. TRATAMENTO -->
Até recentemente, os ensaios clínicos (23-31) e meta-análises (32,33) disponíveis acerca da efetividade do ferro parenteral no tratamento de anemia em pacientes com DRC tiveram como desfechos principais o nível de hemoglobina e a presença de eventos adversos. Desfechos de maior impacto, como ganho em sobrevida e qualidade de vida não foram adequadamente avaliados.  
Em pacientes com DRC em tratamento conservador, o uso rotineiro do ferro parenteral proporcionou um pequeno ganho nos níveis de hemoglobina (0,31 g/dL), que não parece representar vantagem significativa em relação à reposição oral de ferro, segundo meta-análise publicada (32).  
Em 2014, foi publicado o estudo FIND-CKD (34), que avaliou 626 pacientes com DRC em estágios 3 a 5 e deficiência de ferro que não recebiam ESA (siga em Inglês de “agente estimulador da eritropoese”), randomizados para três grupos de tratamento: ferro endovenoso (EV) (carboximaltose férrica) para alcançar-seo alvo de ferritina sérica elevada (400-600 ng/mL) ou baixa (100-200 ng/mL) ou ferro oral (sulfato ferroso 200 mg/dia). O desfecho primário era o tempo até início de outro tratamento para anemia (ESA, transfusão sanguínea ou outra terapia com ferro) ou hemoglobina menor que 10 g/dL nas semanas 8 a 52. O tempo de seguimento foi de 12 meses. A dose média cumulativa de ferro foi 2.685 mg no grupo alvo de ferritina elevada e de 1.040 mg no grupo alvo de ferritina baixa. O evento primário ocorreu em 23,5%, 32,2% e 31,8% nos grupos ferritina alta, ferritina baixa e ferro oral, respectivamente. Segundo os autores, não houve evidência de toxicidade renal e nenhuma diferença na incidência de eventos cardiovasculares ou infecciosos entre os três grupos de tratamento.  
Já no estudo REVOKE (35), 136 pacientes com DRC em estágios 3 a 4 e deficiência de ferro foram randomizados para receber ferro oral (975 mg/dia por 8 semanas) ou sacarato de ferro (200 mg EV a cada 2 semanas, total 1 g) para avaliar o efeito sobre progressão da doença renal ao longo de 2 anos. O estudo foi encerrado precocemente por recomendação de comitê independente de monitorização de segurança, com base na pequena probabilidade de se encontrar diferença entre os gruposquanto à redução da filtração glomerular e um grande risco de eventos adversos no grupo de ferro EV. Houve aumento da frequência de eventos adversos graves, incluindo eventos cardiovasculares (p<0,001) e hospitalizações para tratamento de infecções. Os níveis de hemoglobina melhoraram ao longo do tempo em ambos os grupos, com nenhuma diferença nos níveis atingidos pelos grupos durante os 2 anos de seguimento do estudo. Tais dados sugerem que, embora possa haver benefícios da suplementação de ferro nesses pacientes, os riscos do tratamento precisam ser adequadamente avaliados. Diante disso, nesse grupo de pacientes, o uso de ferro parenteral só deve ser considerado em casos de intolerância ou falha ao tratamento por via oral.  
Em pacientes em hemodiálise, a meta-análise citada anteriormente (32) demonstrou ainda que o uso sistemático do ferro parenteral foi superior à reposição oral de ferro em relação ao incremento de hemoglobina [0,83 g/dL, intervalo de confiança de 95% (IC95%) 0,09-1,57). Tal resposta foi independente do uso de alfaepoetina. Além disso, a dose necessária de alfaepoetina foi significativamente menor no grupo que recebeu ferro por via parenteral (32).  
Em meta-análise de estudos observacionais na população de crianças em hemodiálise, observou-se benefício com uso de ferro parenteral quanto a aumento da hemoglobina e redução das doses de alfaepoetina (33). Meta-análise da Cochrane publicada em 2012, incluindo 28 estudos (2.098 participantes), concluiu que o uso de ferro parenteral em adultos e crianças com DRC se associou a aumento dos níveis de ferritina e de saturação de transferrina, aumento de hemoglobina e leve redução do uso de alfaepoetina em relação à reposição oral. Efeitos adversos gastrointestinais foram mais comuns com a reposição oral, entretanto hipotensão e reações alérgicas foram mais frequentes com a administração parenteral. Não se observou efeito na mortalidade (36). Outra meta-análise, publicada em 2013, com 72 estudos e 10.605 pacientes, concluiu que a administração de ferro EV era efetiva em aumentar a hemoglobina e reduzir o risco de transfusões sanguíneas alogênicas, mas era associada com risco aumentado de infecções (risco relativo = 1,33, 95% IC 1,10-1,64) quando comparada com suplementação de ferro oral ou nenhuma reposição de ferro (37).  
Dois ensaios clínicos visando, respectivamente, a manter a ferritina acima de 200 ng/mL (26) e saturação de transferrina entre 30%-50% (25) com a reposição parenteral de ferro em pacientes em hemodiálise verificaram redução das doses necessárias de alfaepoetina para manter a hemoglobina dentro da faixa alvo, quando comparados com o grupo controle, em que se visava a manter ferritina entre 100-200 ng/mL (26) e saturação da transferrina entre 20%-30% (23).  
O estudo DRIVE (31), publicado por Coyne _et al_ ., avaliou a resposta hematopoética à administração de ferro EV em pacientes em hemodiálise com hemoglobina inferior a 11 g/dL e necessitando  
doses de alfaepoetina superiores a 225 UI/kg/semana ou 22.500 UI/semana e com níveis basais de ferritina sérica elevada (500 a 1.200 ng/mL) e saturação de transferrina menor que 25% em comparação com a não suplementação de ferro. Após 6 semanas, o aumento da hemoglobina foi significativamente maior no grupo que recebeu ferro EV (diferença de cerca de 0,5 g/dL). A resposta ao ferro parenteral não diferiu entre os pacientes com ferritina sérica maior ou menor que 800 ng/mL antes do início do tratamento. No estudo DRIVE II (38), o período de acompanhamento foi estendido por mais 6 semanas para avaliar a resposta à administração de 1 g de ferro EV sobre as doses de alfapoetina e índices de ferro. Houve redução significativa nas doses de alfapoetina nos pacientes tratados com ferro parenteral. Não houve diferença entre os grupos quanto à taxa de eventos adversos; no entanto o estudo foi de curta duração.  
Cabe ressaltar que resultados de estudos retrospectivos e observacionais recentemente publicados levantam a possibilidade de riscos associados com a administração de ferro EV para pacientes em hemodiálise (39-41). No entanto, os dados a esse respeito ainda são conflitantes (42), e ensaios com desfechos clínicos significativos como de morbimortalidade são aguardados (43) para responder a essa questão de modo definitivo (44).

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.1. Fármacos -->
- Sulfato ferroso: comprimidos de 40 mg, solução oral de 25 mg/mL e xarope de 5 mg/mL;  
- Sacarato de hidróxido férrico: solução injetável de 100 mg, frasco de 5 mL.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.2 ESQUEMAS DE ADMINISTRAÇÃO Adultos -->
- Sulfato ferroso: dose de 40 mg, via oral, três vezes ao dia, nos intervalos das refeições.  
- Sacarato de hidróxido férrico: uso intravenoso, conforme esquema a seguir:  
Dose teste: Os estudos clínicos que avaliaram a segurança do sacarato de hidróxido férrico demonstraram que o medicamento é seguro e que a utilização de dose teste, apesar de recomendada pelo fabricante, pode ser dispensada (45). Quando utilizada, a dose teste deve ser realizada na primeira administração e consiste em diluir 25 mg de ferro elementar em 100 mL de solução salina e administrar por via intravenosa em no mínimo 15 minutos. Deve-se aguardar 15 minutos antes de administrar o restante da primeira dose ou repor as doses necessárias nos dias subsequentes, caso não ocorram reações adversas como cefaleia, náusea, vômitos, parestesias, distúrbios gastrointestinais, dores musculares, febre, hipotensão, urticária, rubor ou reação anafilática.  
Dose de ataque: indicada quando o nível de ferritina sérica for inferior a 200 ng/mL ou a saturação de transferrina for inferior a 20%. Pode-se administrar 1.000 mg de ferro, divididos em 10 sessões de hemodiálise ou em 10 dias diferentes (duas ou três vezes por semana) nos pacientes em diálise peritoneal ou em tratamento conservador (19).  
Dose de manutenção: indicada para manter os estoques adequados de ferro em pacientes com níveis de ferritina superiores a 200 ng/mL e saturação da transferrina superior a 20%. Administrar 100 mg de ferro por via intravenosa em dose única a cada 15 dias (19).A dose deve ser diluída em no mínimo 100 mL de solução fisiológica e infundida em 5 a 15 minutos. Estudo demonstra segurança do seu uso em tempos de administração menores, de até 5 minutos, sem aumento de reações adversas (45).

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Crianças -->
Nos estágios iniciais da DRC, ferro por via oral pode ser utilizado. A dose recomendada é de 6 mg/kg/dia com no máximo 150 a 300 mg de ferro elementar, dividido em duas a três tomadas, duas horas antes ou uma hora após alimentação para maximizar a absorção gastrointestinal.  
Reposição de ferro para crianças em diálise peritoneal: Administrar dose mensal de 5 mg/Kg (sem exceder 200 mg de ferro por infusão) diluídos em 200 mL de soro fisiológico e commaior tempo da infusão (60 minutos). O aumento da dose, nestes casos, tem como objetivo evitar as punções venosas repetidas.  
Reposição de ferro IV é recomendada para a totalidade das crianças em hemodiálise, e a administração é feita durante ou após a sessão, na frequência de uma a duas vezes por semana. Doses entre 1,5 a 5 mg/Kg de peso mostraram resultados favoráveis sem a observação de efeitos colaterais indesejáveis. Deve ser diluída em soro fisiológico e infundida durante 30 a 60 minutos.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8. 3. TEMPO DE TRATAMENTO - CRITÉRIOS DE INTERRUPÇÃO -->
O tratamento com ferro parenteral deve ser interrompido temporariamente quando a saturação de transferrina for superior a 30% ou a ferritina sérica for superior a 500 ng/mL.  
Após o retorno dos valores de ferritina sérica para níveis abaixo de 500 ng/mL, reiniciar a reposição com dose menor de ferro.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.4. OBJETIVOS DO TRATAMENTO -->
- Manter níveis de hemoglobina entre 10 e 12 g/dL;  
- Manter o nível sérico de ferritina entre 200 e 500 ng/mL;e  
- Manter a saturação da transferrina entre 20% e 30%.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.5. BENEFÍCIOS ESPERADOS -->
Melhora da anemia e, consequentemente, melhora da capacidade funcional, qualidade de vida e redução da morbimortalidade pela DRC.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 9. MONITORIZAÇÃO -->
Antes do início do tratamento, todos os pacientes devem dispor de hemograma completo, dosagens de ferritina e saturação da transferrina com vistas ao diagnóstico diferencial de anemia e estabelecimento da deficiência de ferro. Dosagens de hemoglobina, ferritina e saturação da transferrina devem sem repetidas mensalmente enquanto estiverem fora das medidasdo alvo terapêutico. Após, mantêm-se dosagens mensais de hemoglobina e trimestrais de ferritina e de saturação da transferrina. O uso de ferro parenteral deve ser suspenso 7-10 dias antes da realização dos exames.  
Deve-se ter atenção especial para casos de anafilaxia com sacarato de hidróxido de férrico ou produtos semelhantes, bem como suspeita de infecção ativa ou insuficiência hepática.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Os pacientes com anemia na doença renal crônica devem ser acompanhados em serviços especializados de nefrologia com terapia renal substitutiva (hemodiálise e diálise peritoneal). Há de se observar os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses do medicamento prescritas e dispensadas e da adequação de uso.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 11. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE- TER -->
Sugere-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizadoneste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 12. REFERÊNCIAS BIBLIOGRÁFICAS -->
1. National Kidney Foundation. NKF-DOQI clinical practice guidelines for the treatment of anemia of chronic renal failure. National Kidney Foundation-Dialysis Outcomes Quality Initiative. Am J Kidney Dis. 1997;30(4 Suppl 3):S192-240.  
2. Kazmi WH, Kausz AT, Khan S, Abichandani R, Ruthazer R, Obrador GT, et al. Anemia: an early complication of chronic renal insufficiency. Am J Kidney Dis. 2001;38(4):803-12.  
3. Abramson JL, Jurkovitz CT, Vaccarino V, Weintraub WS, McClellan W. Chronic kidney disease, anemia, and incident stroke in a middle-aged, community-based population: the ARIC Study. Kidney Int. 2003;64(2):610-5.  
4. Jurkovitz CT, Abramson JL, Vaccarino LV, Weintraub WS, McClellan WM. Association of high serum creatinine and anemia increases the risk of coronary events: results from the prospective communitybased atherosclerosis risk in communities (ARIC) study. J Am Soc Nephrol. 2003;14(11):2919-25.  
5. McClellan WM, Flanders WD, Langston RD, Jurkovitz C, Presley R. Anemia and renal insufficiency are independent risk factors for death among patients with congestive heart failure admitted to community hospitals: a population-based study. J Am Soc Nephrol. 2002;13(7):1928-36.  
6. Sarnak MJ, Tighiouart H, Manjunath G, MacLeod B, Griffith J, Salem D, et al. Anemia as a risk factor for cardiovascular disease in The Atherosclerosis Risk in Communities (ARIC) study. J Am Coll Cardiol. 2002;40(1):27-33.  
7. National Kidney Foundation. Glomerular filtration rate (GFR) [Internet].National Kidney Foundation [acesso em 17 set 2014]. Disponível em: http://www.kidney.org/professionals/KDOQI/gfr.  
8. Singh AK, Szczech L, Tang KL, Barnhart H, Sapp S, Wolfson M, et al. Correction of anemia with epoetin alfa in chronic kidney disease. N Engl J Med. 2006;355(20):2085-98.  
9. Drüeke TB, Locatelli F, Clyne N, Eckardt KU, Macdougall IC, Tsakiris D, et al. Normalization of hemoglobin level in patients with chronic kidney disease and anemia. N Engl J Med. 2006;355(20):207184.  
10. Eschbach JW, Cook JD, Scribner BH, Finch CA. Iron balance in hemodialysis patients. Ann Intern Med. 1977;87(6):710-3.  
11. Ministério da Saúde. Sistema de Informações Ambulatoriais/Sistema Único de Saúde. Extraído em: 03 jan. 2017. Disponível em http://tabnet.datasus.gov.br/tabnet/tabnet.htm .  
12. Tarng DC. The conundrum of serum ferritin measurement in patients with chronic kidney disease. Nat Clin Pract Nephrol. 2009;5(2):66-7.  
13. Stancu S, Bârsan L, Stanciu A, Mircescu G. Can the response to iron therapy be predicted in anemic nondialysis patients with chronic kidney disease? Clin J Am Soc Nephrol. 2010;5(3):409-16.  
14. Weiss G. Kronenberg F. Intravenous iron administration: new observations and time for next steps. Kidney Int. 2015;87(1):10-2.  
15. Ganz T, Nemeth E. Hepcidin and iron homeostasis. Biochim Biophys Acta. 2012;1823(9):1434-43. 16. Sengoelge G, Kletzmayr J, Ferrara I, Perschl A, Hörl WH, Sunder-Plassmann G. Impairment of transendolthelial leukocyte migration by iron complexes. J Am Soc Nephrol. 2003;14(10):2639-44.  
17. Pai AB, Boyd AV, McQuade CR, Harford A, Norenberg JP, Zager PG. Comparison of oxidative stress markers after intravenous administration of iron dextran, sodium ferric gluconate, and iron sucrose in patients undergoing hemodialysis. Pharmacotherapy. 2007;27(3): 343-50.  
18. Kuo KL, Hung SC, Wei YH, Tarng DC. Intravenous iron exacerbates oxidative DNA damage in peripheral blood lymphocytes in chronic hemodialysis patients. J Am Soc Nephrol. 2008;19(9):1817-26. 19. Berns J. Use of iron preparations in hemodialysis patients [Internet]. UpToDate; 2014. [acesso em 17 set 2014]. Disponível em: <u>http://www.uptodate.com/contents/use-of-iron-preparations-in-hemodialysispatients.</u>  
20. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. Diretrizes Clínicas para o Cuidado ao paciente com Doença Renal Crônica – DRC no Sistema Único de Saúde/ Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. – Brasília: Ministério da Saúde, 2014. p.:37 p.: il.  
21. Kidney Disease: Improving Global Outcomes (KDIGO) CKD Work Group. KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease. Kidney Int (Suppl) 2013;3:1-150.  
22. Hörl WH. Iron therapy for renal anemia: how much needed, how much harmful? Pediatr Neprol 2007;22:480-9.  
23. Anirban G, Kohli HS, Jha V, Gupta KL, Sakhuja V. The comparative safety of various intravenous iron preparations in chronic kidney disease patients. Ren Fail. 2008;30(6):629-38.  
24. Li H, Wang SX. Intravenous iron sucrose in peritoneal dialysis patients with renal anemia. Perit Dial Int. 2008;28(2):149-54.  
25. Besarab A, Amin N, Ahsan M, Vogel SE, Zazuwa G, Frinak S, et al. Optimization of epoetin therapy with intravenous iron therapy in hemodialysis patients. J Am Soc Nephrol. 2000;11(3):530-8. 26. DeVita MV, Frumkin D, Mittal S, Kamran A, Fishbane S, Michelis MF. Targeting higher ferritin concentrations with intravenous iron dextran lowers erythropoietin requirement in hemodialysis patients. Clin Nephrol. 2003;60(5):335-40.  
27. Li H, Wang SX. Intravenous iron sucrose in Chinese hemodialysis patients with renal anemia. Blood Purif. 2008;26(2):151-6.  
28. Sav T, Tokgoz B, Sipahioglu MH, Deveci M, Sari I, Oymak O, et al. Is there a difference between the allergic potencies of the iron sucrose and low molecular weight iron dextran? Ren Fail. 2007;29(4):4236.  
29. Sheashaa H, El-Husseini A, Sabry A, Hassan N, Salem A, Khalil A, et al. Parenteral iron therapy in treatment of anemia in end-stage renal disease patients: a comparative study between iron saccharate and gluconate. Nephron Clin Pract. 2005;99(4):c97-101.  
30. Ruiz-Jaramillo Mde L, Guizar-Mendoza JM, Gutierrez-Navarro Mde J, Dubey-Ortega LA, Amador-Licona N. Intermittent versus maintenance iron therapy in children on hemodialysis: a randomized study. Pediatr Nephrol. 2004;19(1):77-81.  
31. Coyne D, Kapoian T, Suki W, Singh A, Moran J, Dahl NV. Ferric gluconate is highly efficacious in anemic hemodialysis patients with high serum ferritin and low transferrin saturation: results of the Dialysis Patients' Response to IV Iron with Elevated Ferritin (DRIVE) Study. J Am Soc Nephrol. 2007;18(3):975-84.  
32. Rozen-Zvi B, Gafter-Gvili A, Paul M, Leibovici L, Shpilberg O, Gafter U. Intravenous versus oral iron supplementation for the treatment of anemia in CKD: systematic review and meta-analysis. Am J Kidney Dis. 2008;52(5):897-906.  
33. Gillespie RS, Wolf FM. Intravenous iron therapy in pediatric hemodialysis patients: a metaanalysis. Pediatr Nephrol. 2004;19(6):662-6.  
34. Macdougall IC, Bock AH, Carrera F, Eckardt KU, Gaillard C, Van Wyck D. FIND-CKD: a randomized trial of intravenous ferric carboxymaltose versus oral iron in patients with chronic kidney disease and iron deficiency anaemia. Nephrol Dial Transplant. 2014;29(11):2075-84.  
35. Agarwal R, Kusek JW, Pappas MK.A randomized trial of intravenous and oral iron in chronic kidney disease. Kidney Int. 2015;88(4):905-14.  
36. Albaramki J, Hodson EM, Craig JC, Webster AC. Parenteral versus oral iron therapy for adults and children with chronic kidney disease. Cochrane Database Syst Rev. 2012;1:CD007857.  
37. Litton E, Xiao J, Ho KM. Safety and efficacy of intravenous iron therapy in reducing requirement for allogeneic blood transfusion: systematic review and meta-analysis of randomised clinical trials. BMJ. 2013;347:f4822.  
38. Kapoian T, O'Mara NB, Singh AK, Moran J, Rizkala AR, Geronemus R, et al. Ferric gluconate reduces epoetin requirements in hemodialysis patients with elevated ferritin. J Am Soc Nephrol. 2008;19(2):372-9.  
39. Bailie GR, Larkina M, Goodkin DA, Li Y, Pisoni RL, Bieber B, et al. Data from the Dialysis Outcomes an Practice Patterns Study validate an association between high intravenous iron doses and mortality. Kidney Int. 2015;87(1):162-8.  
40. Brookhart MA, Freburger JK, Ellis AR, Wang L, Winkelmayer WC, Kshirsagar AV. Infection risk with bolus versus maintenance iron supplementation in hemodialysis patients. J Am Soc Nephrol. 2013;24(1):1151-8.  
41. Rostoker G, Cohen Y. Magnetic resonance imaging repercussions of intravenous iron products used for iron-deficiency anemia and dialysis-associated anemia. J Comput Assist Tomogr. 2014;38(6):843-4. 42. Tangri N, Miskulin DC, Zhou J, Bandeen-Roche K, Michels WM, Ephraim PL, et al. Effect of intravenous iron use on hospitalizations in patients undergoing hemodialysis: a comparative effectiveness analysis from the DEcIDE-ESRD study. Nephrol Dial Transplant. 2015;30(4):667-75.  
43. King's College Hospital NHS Foundation Trust.UK Multicentre open-label randomised controlled trial of IV iron therapy in incident haemodialysis patients [Internet]. Clinical trials for Pivotal MacDougall; 2013[acesso em 12 fev 2016]. Disponivel em:  
<u>https://www.clinicaltrialsregister.eu/ctr-search/search?query=Pivotal+MacDougall.</u> (pesquisa pelos termos: PIVOTAL,MacDougall).  
44. Charytan DM, Pai AB, Chan CT, Coyne DW, Hung AM, Kovesdy CP, et al. Considerations and challenges in defining optimal iron utilization in hemodialysis. J Am Soc Nephrol. 2015;26(6):1238-47. 45. Charytan C, Levin N, Al-Saloum M, Hafeez T, Gagnon S, Van Wyck DB. Efficacy and safety of iron sucrose for iron deficiency in patients with dialysis-associated anemia: North American clinical trial. Am J Kidney Dis. 2001;37(2):300-7.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE SACARATO DE HIDRÓXIDO FÉRRICO -->
Eu, ____________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento sacarato de hidróxido férrico, indicado para o tratamento da anemia na doença renal crônica.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora da anemia e, consequentemente, melhora da capacidade funcional, qualidade de vida e redução da morbimortalidade pela insuficiência renal crônica;  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- não há relato de efeitos adversos fetais com o uso de sacarato de hidróxido férrico em doses usuais durante a gravidez. Entretanto, caso engravide, o médico deverá ser avisado;  
- os efeitos adversos já relatados são os seguintes: dor no local de administração, alteração da coloração da pele, dor no quadrante inferior do abdômen, dor de cabeça, dores no corpo, taquicardia, calorões, náusea, vômitos, falta de ar, tonturas;  
- possibilidade de reações tardias (em relação à administração do medicamento) tais como tontura, desmaio, febre, calafrios, vermelhidão, coceiras, dores pelo corpo, confusão mental;  
- possibilidade de reação anafilática grave com morte (1 para cada 4 milhões de doses administradas);  
- o medicamento está contraindicado em casos de hipersensibilidade (alergia), em hemocromatose, talassemia, anemia falciforme, anemia hemolítica e anemia associada a leucemias; e  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendome a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.(    ) Sim       (   ) Não  
<!-- Start of picture text -->
Local:                                                                Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico Responsável: CRM: UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 1. METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Foi realizada busca de artigos nas bases de dados do MEDLINE/PubMed, Embase e Cochrane, limitada aos últimos 10 anos, até a data de 31 de janeiro de 2010. Foram selecionados ensaios clínicos randomizados, meta-análises e revisões sistemáticas envolvendo o tratamento medicamentoso da anemia na doença renal crônica e cujos desfechos fossem clinicamente relevantes. Foram excluídos os estudos cujos desfechos não tivessem relevância clínica ou cujo fármaco não tivesse registro na Agência Nacional de Vigilância Sanitária (ANVISA).  
No MEDLINE/PubMed, foi utilizada a estratégia: "Kidney Failure, Chronic"[Mesh] AND "Anemia"[Mesh] AND ("humans"[MeSH Terms] AND (Meta-Analysis[ptyp] OR Randomized Controlled Trial[ptyp]). A busca resultou em 107 estudos, dos quais 24 foram julgados relevantes para esteProtocolo. Nova busca com a mesma estratégia, porém sem limite de data, identificou outros quatro estudos que foram incluídos tendo em vista a sua importância histórica.  
No Embase, foi utilizada a estratégia ‘chronic kidney failure’/exp AND 'drug therapy'/exp AND ([cochrane review]/lim OR [controlled clinical trial]/lim OR [meta analysis]/lim OR [randomized controlled trial]/lim OR [systematic review]/lim) AND [humans]/lim AND [embase]/lim. A busca identificou 86 estudos que foram analisados individualmente. Foram incluídos três estudos adicionais em relação àqueles já identificados na busca do PubMed.  
Na biblioteca Cochrane, utilizando-se a expressão “chronic kidney failure anemia”, foram localizadas três revisões sistemáticas, incluídas na elaboração desteProtocolo.  
Foi consultado ainda o UpToDate®, versão 17.3, no site http://www.uptodateonline.com e livros-texto de Nefrologia.  
Em 11/01/2016, foi realizada atualização da busca, utilizando-se os critérios de inclusão e exclusão da busca inicial. Na base MEDLINE/PubMed, foi utilizada a estratégia “"kidney failure, chronic"[MeSH Terms] AND "anemia"[MeSH Terms] AND ((Meta-Analysis[ptyp] OR Randomized Controlled Trial[ptyp] OR systematic[sb]) AND ("2010/02/01"[PDAT]: "3000/12/31"[PDAT]) AND "humans"[MeSH Terms] AND (English[lang] OR Portuguese[lang] OR Spanish[lang]))”, localizando-se 55 estudos. Foram selecionados nove estudos para leitura na íntegra, sendo que nenhum foi incluído.  
Na base Embase, utilizaram-se os termos de busca “'chronic kidney disease'/de AND 'therapy'/exp AND ('anemia'/exp OR 'anemia'/de) AND ([systematic review]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [1-1-2010]/sd AND [1-2-2010]/sd”, tendo sido localizados 132 estudos; destes, foram selecionados 11 para leitura, sendo que somente um estudo foi incluído.  
Na biblioteca Cochrane, utilizando-se os termos “kidney failure, chronic” AND “anemia”, foram localizadas quatro revisões sistemáticas sobre o tema publicadas a partir de 2010; destas, uma foi selecionada para leitura. Essa busca não resultou na inclusão de novos estudos.  
A publicação eletrônica UpToDate® versão 19.3, a página da agência _americana Food and Drug Administration_ (FDA) e artigos de conhecimento dos autores também foram consultados a respeito do tema, resultando na inclusão de cinco referências.  
Para responder às demandas da consulta pública foram incluídas 7 novas referências de conhecimento dos autores.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 2. INTRODUÇÃO -->
A anemia é definida como um estado de deficiência de massa eritrocitária e de hemoglobina, resultando em aporte insuficiente de oxigênio para órgãos e tecidos. Os valores normais de hematócrito e hemoglobina variam em relação a idade, gênero, tipo racial e outros fatores. Utilizando-se a definição clássica de anemia pela Organização Mundial da Saúde (hemoglobina inferior a 13 g/dL em homens e mulheres na pós-menopausa e inferior a 12 g/dL em mulheres na pré-menopausa), essa condição estará presente em até 90% dos pacientes com doença renal crônica (DRC), com taxa de filtração glomerular inferior a 25-30 mL/min (1-3).  
A anemia na DRC pode se desenvolver em decorrência de qualquer uma das condições hematológicas que afetam a população em geral; entretanto, sua causa mais comum é a deficiência de eritropoetina, sobretudo naqueles com doença mais avançada. Essa glicoproteína, produzida pelos rins atua na medula óssea, estimulando as células progenitoras da série eritroide. Os maiores estímulos para a sua produção são a presença de anemia e hipóxia tecidual. Em pacientes com DRC, ocorre deficiência relativa de sua produção, ou seja, os níveis produzidos estão aquém do esperado para o grau de anemia apresentado. Isso decorre da perda progressiva de néfrons ao longo da história natural da DRC (4,5).  
Além da menor produção de eritrócitos, em decorrência dos níveis insuficientes de eritropoetina, pacientes com DRC apresentam também uma menor meia-vida eritrocitária, decorrente de um pequeno grau de hemólise. Tal alteração pode ser parcialmente corrigida com a suplementação de eritropoetina exógena (alfaepoetina) (5).  
A manutenção de estoques corporais adequados de ferro é fundamental para adequada resposta ao tratamento com alfaepoetina, sendo a deficiência de ferro ou a sua reduzida disponibilidade as principais causas de falha ao tratamento. Estima-se que pacientes em hemodiálise percam em média 2 g de ferro por ano pelo método dialítico em si, além de outras perdas (gastrointestinais, coletas de sangue frequentes, etc.), justificando a necessidade de avaliação sistemática e de reposição apropriada (6).  
A presença de anemia acarreta uma série de consequências ao paciente com DRC. A qualidade de vida é afetada, uma vez que, sintomas como fadiga, dispneia e prejuízo na capacidade cognitiva, entre outros, decorremda anemia. Há ainda uma maior predisposição a eventos cardiovasculares (7-9), com aumento da mortalidade cardiovascular (10) e, possivelmente, aumento da mortalidade geral (11,12). O maior número de eventos acaba por levar a um maior número de hospitalizações, com aumento de custos para o sistema de saúde (4,5).  
O tratamento da anemia com o uso de alfaepoetina praticamente suprimiu a necessidade de transfusões sanguíneas e os riscos a elas associados e, além disso, promoveu benefícios, como a melhora na qualidade de vida e no desempenho físico e cognitivo e a redução do número de hospitalizações (13). Entretanto, estudos recentes têm demonstrado que a manutenção de um alvo terapêutico de hemoglobina acima de 13 g/dL está associado a um aumento da morbimortalidade (14). Diante disso, a faixa terapêutica atualmente recomendada para hemoglobina situa-se entre 10 e 12 g/dL.  
No Brasil, estima-se, a partir dos dados do Sistema de Informações Ambulatoriais do SUS (disponíveis em <u>http://tabnet.datasus.gov.br/tabnet/tabnet.htm</u> e captados em 03/01/2017), que 91.963 pacientes submeteram-se a diálise em 2015, dos quais em torno de 90% a hemodiálise. O uso de alfaepoetina fez parte do tratamento de mais de 80% desses pacientes.  
A identificação dos fatores de risco da doença renal crônica, seu diagnóstico em estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para a prevenção e controle desta doença, a redução de suas incidência e mortalidade e um melhor resultado terapêutico e prognóstico dos casos que não puderam ser evitados.  
3. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- N18.0 Doença renal em estádio final  
- N18.8 Outra insuficiência renal crônica  
4. DIAGNÓSTICO  
A presença de anemia deve ser sistematicamente avaliada em pacientes com DRC, sobretudo naqueles pacientes com sinais e sintomas sugestivos, como fadiga, dispneia, descoramento de mucosas e taquicardia, entre outros. Uma avaliação clínica completa deve ser realizada a fim de excluir outras causas de anemia.  
O diagnóstico de anemia se dá pela presença de hemoglobina inferior a 13 g/dL em homens e mulheres na pós-menopausa e inferior a 12 g/dL em mulheres na pré-menopausa. A avaliação laboratorial deve incluir hemograma completo, dosagem de ferritina e saturação da transferrina. A necessidade de exames adicionais, para diagnóstico diferencial de outras doenças que cursam com anemia, dependerá da avaliação clínica individualizada.  
Em pacientes com anemia decorrente da DRC, o hemograma costuma revelar anemia do tipo anemia da doença crônica, ou seja, normocítica e normocrômica. As reservas de ferro devem ser avaliadas e corrigidas conforme o Protocolo Clínico e Diretrizes Terapêuticas da Anemia na Doença Renal Crônica – Reposição de Ferro.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 5. CRITÉRIOS DE INCLUSÃO -->
Serão incluídos neste Protocolo os pacientes adultos, de ambos os sexos, que apresentarem diagnóstico de DRC e todas as condições a seguir:  
- Estágios 3 a 5 (filtração glomerular inferior a 60 mL/min/1,73m<sup>2</sup> conforme definido por normas e diretrizes reconhecidas)(3,15,16);  
- anemia, com hemoglobina sérica menor ou igual a 10 g/dL tanto para homens quanto para mulheres; e  
- reservas adequadas de ferro, definidas por ferritina sérica maior que 100 ng/mL e saturação da transferrina maior que 20% em pacientes em tratamento conservador ou diálise peritoneal e ferritina sérica maior que 200 ng/mL e saturação da transferrina maior que 20% em pacientes em tratamento com hemodiálise.  
Também serão incluídos deste Protocolo os pacientes pediátricos com DRC e com hemoglobina abaixo de 11 g/dL, quando outras causas de anemia forem excluídas e os estoques de ferro estiverem adequados.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 6. CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo os pacientes que apresentarem:  
- hipersensibilidade/intolerância ao medicamento proposto ou a um de seus componentes;  
- hipertensão arterial sistêmica não controlada (níveis acima de 140/90 mmHg) mesmo com uso de três anti-hipertensivos; ou  
- anemia de outras etiologias.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 7. CASOS ESPECIAIS -->
Os riscos e benefícios do uso de alfaepoetina em gestantes com DRC devem ser criteriosamente avaliados antes de sua utilização. Há evidências de que o medicamento causa anormalidades em animais, mas o risco em humanos ainda não está definido. O benefício do medicamento, porém, pode justificar o risco na gravidez. Não se sabe se o medicamento é excretado no leite materno.  
O uso de alfaepoetina para tratamento da anemia em pacientes com câncer está associado com aumento nas taxas de recidiva de tumores sólidos e potencial aumento da mortalidade relacionada à doença. Diante disso, o uso desse medicamento em pacientes com anemia por DRC e diagnóstico de câncer exige muita cautela (17,18).

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8. TRATAMENTO -->
A suplementação de alfaepoetina em pacientes com DRC tem o potencial de reduzir de forma significante a necessidade de transfusões e os riscos a ela associados, além de contribuir para evitar a sobrecarga de ferro, reduzir a massa ventricular esquerda e melhorar a qualidade de vida dos pacientes (13).  
Os benefícios do tratamento foram avaliados em meta-análise publicada por Jones et al. (19). Além do aumento dos níveis de hemoglobina e consequente melhoria da qualidade de vida e redução da necessidade de transfusões, os pacientes tratados ainda tiveram uma substancial redução na taxa de hospitalizações.  
Existem diferentes agentes estimuladores da eritropoese (ESA, em Inglês), como alfaepoetina, betaepoetina, darbepoetina e ativadores contínuos do receptor da eritropoetina, sendo a posologia a principal diferença entre eles. A alfaepoetina, por ser o representante mais bem estudado, com maior experiência de uso clínico e perfil de segurança em longo prazo conhecido, permanece como agente de escolha no tratamento da anemia na DRC. Quando comparada à alfaepoetina, a darbepoetina não mostrou vantagens em termos de eficácia (20,21).  
Pacientes em tratamento conservador e em diálise peritoneal  
Pacientes com DRC em tratamento conservador ou em diálise peritoneal beneficiam-se do uso de alfaepoetina para correção da anemia. Estudo publicado por Revicki et al. (22) comparou seu uso contra apenas observação em 83 pacientes com DRC em tratamento conservador. A anemia foi corrigida em 79% dos pacientes que receberam alfaepoetina e em 0% dos controles. Houve ainda melhora significativa no desempenho físico e cognitivo, além de outros itens relacionados à qualidade de vida.  
O impacto da correção da anemia na qualidade de vida de pacientes com DRC em tratamento conservador foi avaliado em estudo publicado por Alexander et al. (23). Os autores demonstraram que a correção da anemia se correlacionou com melhoras estatística e clinicamente significativas em escores de qualidade de vida. Uma revisão sistemática da Cochrane (24) buscou avaliar a eficácia da alfaepoetina no tratamento da anemia em pacientes com DRC em tratamento conservador. Os autores concluíram que o uso da alfaepoetina corrige a anemia, evita transfusões, melhora a qualidade de vida e a capacidade física.  
Apesar de a anemia ser um conhecido fator de risco para a progressão da DRC, persiste motivo de debate se a sua correção poderia retardar a necessidade de hemodiálise. Em estudo publicado por Gouva et al. (25) incluindo 88 pacientes com DRC em tratamento conservador, o uso precoce de alfaepoetina (definido como início de alfaepoetina com nível sérico de hemoglobina entre 9-11 g/dL) associou-se com um retardo na progressão da doença e na necessidade de diálise em relação ao grupo no qual se iniciou alfaepoetina tardiamente (início quando hemoglobina menor que 9 g/dL). Por outro lado, no estudo CREATE (26), que randomizou 603 pacientes com DRC estágios 3 e 4 em grupos com alvos de hemoglobina entre 11-12,5 g/dL (grupo intervenção) ou 10,5-11,5 g/dL (grupo controle), não houve diferença em relação à progressão da doença e mais pacientes no grupo intervenção necessitaram de diálise. A massa ventricular esquerda também não parece diferir quando a alfaepoetina é iniciada mais precocemente (27,28).  
No estudo TREAT, que incluiu 4.038 pacientes com DRC em tratamento conservador e com diabete mélito tipo 2, o uso de darbepoetina alfa (dosagem alvo de hemoglobina de 13 mg/dL ou placebo, com uso de darbepoetina alfa de resgate se hemoglobina menor que 9 mg/dL) não mostrou diferenças entre os grupos quanto à ocorrência de DRC terminal ou de eventos cardiovasculares e mortalidade.  Houve, entretanto, um aumento estatístico de incidência de acidente vascular cerebral no grupo tratado, em comparação ao grupo placebo ( _hazard ratio_ = 1,92, intervalo de confiança de 95% 1,38-2,68; p < 0,001). Adicionalmente, os autores relataram que, entre pacientes com história de câncer no início do estudo, ocorreram 60 mortes em 188 pacientes randomizados para darbepoetina e 37 mortes em 160 pacientes do grupo placebo (p=0,13) (18).  
A frequência de administração de alfaepoetina em pacientes com DRC em tratamento conservador foi motivo do estudo PROMPT (29). Os pacientes foram randomizados para um dos quatro braços de tratamento com alfaepoetina subcutânea: 10.000 unidades internacionais (UI) uma vez por semana; 20.000 UI a cada 2 semanas; 30.000 UI a cada 3 semanas e 40.000 UI a cada 4 semanas. O desfecho  
primário foi o nível de hemoglobina ao final das 16 semanas de tratamento. Não houve diferença estatisticamente significativa em relação aos níveis de hemoglobina e às medidas de qualidade de vida ao final do tratamento. Cerca de 90% dos pacientes dos grupos que receberam alfaepoetina a cada 1 ou 2 semanas e 75% daqueles dos grupos que receberam a cada 3 ou 4 semanas mantiveram hemoglobina superior a 11 g/dL ao final do estudo. Os autores concluíram que uma menor frequência de administração de alfaepoetina pode ser efetiva e flexibilizaria o tratamento da anemia nesse grupo de pacientes.  
Em outro estudo, publicado por Pergola et al. (30), a administração de alfaepoetina semanalmente ou a cada 2 semanas mostrou-se igualmente eficaz em pacientes com DRC em estágios 3 ou 4.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Pacientes em hemodiálise -->
Os benefícios do uso de alfaepoetina no tratamento da anemia em pacientes com DRC em hemodiálise foram claramente demonstrados no clássico estudo publicado por Eschbach et at. (13). Os 333 pacientes incluídos, com hematócrito inferior a 30% e reservas adequadas de ferro, virtualmente eliminaram a necessidade de transfusões sanguíneas após 2 meses de tratamento com alfaepoetina, uma vez que tiveram sua anemia corrigida. A dose média de alfaepoetina, administrada por via intravenosa no estudo, foi de 75 UI/kg, três vezes por semana. Os pacientes tiveram ainda melhora significativa na qualidade de vida A frequência de administração de alfaepoetina em pacientes em hemodiálise foi estudada por Lee et al. (31), em que84 pacientes foram randomizados em dois grupos: o grupo intervenção, que recebia alfaepoetina uma vez por semana por via subcutânea, e o grupo controle, que recebia alfaepoetina duas ou três vezes por semana (conforme uso prévio), por via subcutânea. Não houve diferença estatisticamente significativa em relação aos níveis de hemoglobina e doses de alfaepoetina após 12 semanas, desfechos principais do estudo. Tais resultados sugerem que o uso de dose única semanal de alfaepoetina pode ser uma opção no tratamento de manutenção desse grupo de pacientes.  
Uma revisão sistemática da Cochrane, publicada anteriormente ao estudo de Lee et al., avaliou o impacto de diferentes frequências de administração subcutânea de alfaepoetina na correção da anemia em pacientes em diálise (32). Os níveis de hemoglobina foram semelhantes, independentemente da frequência do uso da alfaepoetina (uma, duas ou três vezes por semana). A dose única semanal associou-se com necessidade adicional de 12 UI/kg de alfaepoetina. Não houve diferença em relação à ocorrência de efeitos adversos.  
Uma revisão dos dados do estudo _Normal Hematocrit Cardiac Trial_ publicada por Coyne, em 2010, entretanto, mostrou que a administração de eritropoietina em pacientes em hemodiálise está associada a riscos. No estudo de Besarab et al., de 1998, foram avaliados 1.233 pacientes em hemodiálise com cardiopatia clinicamente evidente, tratados com eritropoetina alfa por 14 meses, tendo como alvo terapêutico níveis de hemoglobina de 10 a 11 g/dL ou a normalização da hemoglobina (13 a 15 g/dL) (33). O estudo foi terminado precocemente devido a um aumento do número de mortes, embora não estatisticamente significativo. A revisão de Coyne, entretanto, mostrou que havia muitas inconsistências no relato anterior do estudo e que havia, sim, um aumento significativo do risco de morte (risco relativo 1,27, intervalo de confiança de 95% 1,04-1,54) nos pacientes tratados com eritropoietina alfa com o objetivo de normalizar os níveis de hemoglobina, sem que houvesse benefício consistente na qualidade de vida dos pacientes (34). Esses dados foram posteriormente incorporados aos dados de outros estudos e nas recomendações de segurança da _Food and Drug Administration_ (FDA) sobre uso de epoetina a pacientes com doença renal crônica.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Reservas de ferro -->
A manutenção de reservas adequadas de ferro associa-se à necessidade de menores doses de alfaepoetina para correção da anemia. Em vista disso, todos os pacientes devem ser avaliados e conduzidos de acordo com o Protocolo Clínico e Diretrizes Terapêuticasda Anemia na Doença Renal Crônica – Reposição de Ferro.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Via de administração -->
A melhor via de administração de alfaepoetina permanece motivo de debate, sobretudo nos pacientes em hemodiálise. Pacientes em tratamento conservador e em diálise peritoneal são tratados preferencialmente pela via subcutânea. Kaufman et al. (35), em estudo que comparou as vias de administração subcutânea e intravenosa de alfaepoetina, observou que o uso subcutâneo foi capaz de manter os níveis de hemoglobina utilizando uma dose de alfaepoetina 30% menor do que aquela utilizada por via intravenosa, o que gerou significativa redução de custos ao tratamento. A taxa relatada de desconforto no local da aplicação foi muito baixa, com 86% dos pacientes que receberam alfaepoetina por via subcutânea graduando o desconforto relacionado como leve ou ausente.  
Estudo publicado por Messa et al. (36) avaliou a eficácia da administração intravenosa em relação à subcutânea no tratamento da anemia em pacientes em hemodiálise e concluiu que a administração intravenosa semanal foi inferior à subcutânea semanal e à intravenosa dividida em três doses semanais.  
Na pediatria, a via preferencial de administração de ESA é a subcutânea, sendo que a via intravenosa favorece por conveniência os pacientes em hemodiálise. A via intraperitoneal não é recomendada. (37).

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Níveis Alvo de Hemoglobina -->
Por muito tempo, os estudos sobre o uso de ESA para o tratamento da anemia em pacientes com DRC avaliaram os níveis de hemoglobina e a necessidade de transfusões como os desfechos primários de interesse. Nos últimos anos, desfechos clinicamente mais relevantes, como mortalidade, eventos cardiovasculares, trombose de acessos vasculares e qualidade de vida, passaram a ser considerados em qualquer intervenção relativa ao tratamento da anemia em pacientes com DRC (38).  
A meta-análise publicada por Phrommintikul et al. (14) incluindo mais de 5.000 pacientes provenientes de nove ensaios clínicos, entre eles os recentes estudos CREATE (26) e CHOIR (39), buscou avaliar a relação entre o nível sérico alvo de hemoglobina e eventos cardiovasculares e mortalidade geral e atualizou os resultados de revisão sistemática prévia da Cochrane (40). Os autores verificaram que a manutenção de níveis mais elevados de hemoglobina (entre 12 e 16 g/dL) associou-se com aumento da mortalidade geral, bem como com aumento do risco para hipertensão de difícil controle e trombose de fístula arteriovenosa. Não houve diferença em relação à ocorrência de infartos do miocárdio ou hipertrofia ventricular esquerda.  
Em 2010, Palmer et al. publicaram nova meta-análise, incluindo o resultado de 27 estudos (10.452 pacientes), inclusive o estudo TREAT (41). Os autores concluíram que um nível mais alto de hemoglobina (13 g/dL) estava associado a um aumento no risco de acidente vascular cerebral, hipertensão e trombose do acesso vascular, quando comparado com alvos terapêuticos mais baixos (média do grupo 10,1 g/dL de hemoglobina), achados consistentes tanto em pacientes em diálise como em pacientes prédialíticos.  
Em outra meta-análise, publicada por Clement et al. (42), não foram observadas vantagens clinicamente relevantes em relação à qualidade de vida na manutenção da hemoglobina em níveis séricos superiores a 12 g/dL. Visando a avaliar especificamente o impacto do nível de hemoglobina na hipertrofia ventricular esquerda, Parfrey et al. publicaram meta-análise demonstrando ausência de benefício em manter níveis acima de 12 g/dL quando comparado a níveis convencionais (43).  
Diante desses resultados, pode-se concluir que buscar a correção completa da anemia não traz benefícios adicionais em relação ao controle sintomático e à qualidade de vida e pode levar a aumento da morbimortalidade. Com base nesses dados, recomenda-se que seja utilizada menor dose individualizada eficaz e capaz de obter controle sintomático, evitando a necessidade de transfusões de sangue; adicionalmente, recomenda-se que a hemoglobina não ultrapasse o valor de 12 g/dL (44-46).  
O nível sérico alvo de hemoglobina para crianças e adolescentes em tratamento com ESA deve ser entre 11 e 12 g/dL em qualquer estágio da DRC. Os níveis de hemoglobina não devem ultrapassar 13 g/d.(37)

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.1 FÁRMACO -->
- Alfaepoetina: frasco-ampola com 1.000 UI, 2.000 UI, 3.000 UI, 4.000 UI e 10.000 UI.  
- 8.2 ESQUEMAS DE ADMINISTRAÇÃO Adultos  
Pacientes adultos em tratamento conservador ou em diálise peritoneal podem ser tratados inicialmente com uma das seguintes opções, ajustadas posteriormente de acordo com a resposta terapêutica:  
- 50-100 UI/kg, via SC, divididas em uma a três aplicações por semana;  
- 10.000 UI, via SC, uma vez por semana; ou  
- 20.000 UI, via SC, uma vez a cada 2 semanas;  
Pacientes em hemodiálise podem ser tratados inicialmente com uma das seguintes opções, ajustadas posteriormente de acordo com a resposta terapêutica:  
- 50-100 UI/kg, via SC, divididas em uma a três aplicações por semana ou  
- 50-100 UI/kg, via SC, divididas em três aplicações por semana.  
Diversos nomogramas para ajuste de dose de alfaepoetina foram descritos em pacientes com DRC (47-49). A maioria, contudo, não foi validada de forma prospectiva. Inexistem comparações diretas entre diferentes estratégias de ajuste de dose. Sugere-se que os pacientes tenham a sua hemoglobina monitorizada a cada 2 semanas após cada ajuste de dose até a estabilização e, a partir de então, a cada 4 semanas. As doses devem ser corrigidas conforme o nível de hemoglobina e desde que as reservas de ferro estejam adequadas:  
- Se, após 4 semanas de tratamento, a elevação de hemoglobina for inferior a 0,3 g/dL por semana: aumentar a dose em 25%, respeitando-se o limite da dose máxima, que é de 300 UI/kg/semana por via subcutânea e 450 UI/kg/semana por via intravenosa.  
- Se, após 4 semanas de tratamento, a elevação de hemoglobina estiver no intervalo de 0,3-0,5  
g/dL por semana: manter a dose em uso.  
- Se após 4 semanas, a elevação de hemoglobina for maior que 0,5 g/dL por semana ou o nível de hemoglobina estiver entre 12 e 13 g/dL: reduzir a dose em 25% a 50%, respeitando o limite da dose mínima recomendada, que é de 50 UI/kg/semana via SC.  
- Suspender temporariamente o tratamento se o nível de hemoglobina estiver superior a 13 g/dL. Quanto ao reinício, não há recomendação específica; entretanto, deve-se aguardar a queda da hemoglobina, quando hemoglobina estiver entre 10 e 12 g/dL, para reiniciar a eritropoetina com dose menor.  
Antes de cada ajuste de dose de alfaepoetina, os níveis séricos de ferritina e saturação da transferrina devem ser avaliados e mantidos de acordo com o Protocolo Clínico e Diretrizes Terapêuticas da Anemia na Doença Renal Crônica – Reposição de Ferro.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: Crianças -->
- 100 a 200 UI/Kg/dose.  Pacientes em hemodiálise pela via intravenosa (IV) 2 a 3 vezes por semana e em diálise peritoneal uso SC 1 a 2 vezes na semana.  
A escolha da dose inicial deve levar em consideração o quadro clínico, o grau de anemia e a idade da criança. Doses de 200 UI/kg/semana podem elevar a hemoglobina em 0,75-1 g/dL no primeiro mês, na presença de reservas de ferro adequadas, determinando um aumento gradativo até atingir o nível sérico alvo de hemoglobina (entre 11 e 12 g/dL). Caso não se verifique melhora do nível sérico da hemoglobina, a dose de ESA pode ser aumentada em 25%.  
A maioria responde a doses entre 100 e 200 UI/kg/semana, embora crianças menores de 5 anos utilizem doses superiores a 300UI/Kg/semana.(50,51)

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.3. TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO -->
O tratamento deve ser mantido de forma contínua com vistas à manutenção da hemoglobina sérica em níveis estáveis e compatíveis com os objetivos do tratamento.  
Em adultos, recomenda-se redução de dose se o nível da hemoglobina sérica for igual ou superior a 12 g/dL, conforme esquemas de administração; e suspensão temporária, quando superior a 13 g/dL, reiniciando-se quando estiver entre 10 e 12 g/dL. Deve ser considerada a suspensão do tratamento na ocorrência de evento adverso grave, conforme item 9MONITORIZAÇÃO.  
A resposta inadequada é um problema comum em crianças e adultos. O aumento das doses para atingir o nível sérico de hemoglobina alvo tem sido associado a efeitos adversos em adultos, porém não há estudos que demonstrem esta associação em crianças.  
Em crianças, aumentos de níveis séricos de hemoglobina de 0,5 a 1 g/dL são esperados após o primeiro mês de tratamento, considerando que o perfil de ferro esteja adequado (ferritina ≥ 200 ng/dL e saturação da transferrina > 20%). Quando este aumento não ocorrer, a dose de alfaepoetina pode ser aumentada em 25%. Caso o perfil de ferro esteja abaixo do indicado, é necessáriaa suplementação de ferro. Incrementos nos níveis séricos da hemoglobina superiores a 2 g/dL no mês deverão ser evitados. Ao atingir o nível alvo (entre 11 e 12 g/dL de hemoglobina), as doses e frequência devem ser ajustadas, evitando-se a suspensão do medicamento.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 8.4. BENEFÍCIOS ESPERADOS -->
O tratamento com alfaepoetina tem como benefícios a correção da anemia, com consequente redução da necessidade de transfusões, redução no número de hospitalizações e melhora sintomática, da qualidade de vida, da capacidade cognitiva e do desempenho físico.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 9. MONITORIZAÇÃO -->
A resposta ao tratamento deve ser acompanhada por meio de dosagens séricas de hemoglobina a cada 2 semanas, até a estabilização dos seus níveis, e após cada ajuste de dose. Quando houver nível de hemoglobina estável após duas medidas consecutivas, a frequência de aferição pode ser mensal. Deve-se atentar para a necessidade de monitorização concomitante das reservas de ferro, conforme o Protocolo Clínico e Diretrizes Terapêuticas da Anemia na Doença Renal Crônica – Reposição de Ferro.  
Tendo em vista que o uso de alfaepoetina está associado com o desenvolvimento de hipertensão arterial de difícil controle, os pacientes devem ter sua pressão arterial aferida pelo menos quinzenalmente, independentemente da história prévia de hipertensão arterial sistêmica. Deve ser considerada a suspensão da alfaepoetina na presença de hipertensão arterial em estágio 2 (pressão sistólica maior ou igual a 160 mmHg ou pressão diastólica maior ou igual a 100 mmHg) refratária ao tratamento com três diferentes fármacos em dose adequada, uma vez que essa situação pode estar relacionada com aumento da mortalidade (14).  
A aplasia pura da série eritroide é um evento raro que pode decorrer do uso de ESA. A condição clínica caracteriza-se por anemia grave, baixa contagem de reticulócitose ausência de precursores eritroides na medula óssea, na presença de normalidade das outras séries (leucócitos e plaquetas), e decorre da produção de anticorpos neutralizantes da eritropoetina, seja endógena ou exógena. Sua ocorrência é estimada em 1,6 por 10.000 pacientes/ano com o uso de alfaepoetina por via subcutânea, havendo raros relatos de caso com o uso intravenoso. Recomenda-se que sejam avaliados para essa condição os pacientes em uso de alfaepoetina há pelo menos 4 semanas que desenvolvam:  
- queda da hemoglobina maior do que 0,5-1 g/dL por semana na ausência de transfusões ou a necessidade de transfusão de pelo menos uma unidade de hemácias por semana para manter os níveis de hemoglobina;  
- contagens normais de leucócitos e plaquetas; e  
- contagem absoluta de reticulócitos inferior a 10.000/microlitro.  
Na ocorrência de aplasia pura da série eritroide, o uso de alfaepoetina deve ser suspenso e tratamento específico instituído, conforme Protocolo Clínico e Diretrizes Terapêuticas da Aplasia Pura Adquirida da Série Vermelha.  
A resposta inadequada é um problema comum em crianças e adultos. O aumento das doses para atingir o nível séricode hemoglobina alvo tem sido associado a efeitos adversos em adultos, porém não há  
estudos que demonstrem esta associação em crianças. Considera-se resposta inadequada ao tratamento a persistência de anemia (nível sérico de hemoglobina inferior a 10 g/dL) ou a necessidade de doses muito altas de alfaepoetina (300 UI/kg/semana por via subcutânea e 450 UI/kg/semana por via intravenosa). Tais pacientes devem ser inicialmente avaliados em relação à sua adequada reserva de ferro, de acordo com o Protocolo Clínico e Diretrizes Terapêuticas da Anemia na Doença Renal Crônica – Reposição de Ferro, pois essa é a causa mais comum.  
Nos pacientes com reservas de ferro adequadas, outras causas devem ser afastadas, como outras anemias carenciais (deficiência de vitamina B12 ou de ácido fólico), hiperparatireoidismo secundário não controlado, terapia dialítica inadequada, doenças inflamatórias ou infecciosas crônicas, neoplasias (sólidas e de origem hematopoética), mielofibrose, síndrome mielodisplásica, hemoglobinopatias, intoxicação por alumínio e aplasia pura da série eritroide. Nesses casos, tratamento específico deve ser instituído (4,52).  
As crianças com oxalose e cistinose apresentam anemia resistente aos ESA e podem receber doses superiores a 12.000 UI/semana com o objetivo de reduzir a necessidade transfusional. (53)  
A deficiência de vitaminas ocorre em crianças renais crônicas pelas dietas inadequadas, absorção prejudicada por outros medicamentos e pelas perdas na diálise. Essas podem ser repostas por via oral, porém não há comprovação que favoreçam a resposta aos ESA. A vitamina B6 está envolvida na biossíntese do heme e pode estar deficiente no eritrócito, mesmo com níveis plasmáticos normais. Nesses casos, a suplementação, por via oral, de 100-150 mg/semana é necessária. A deficiência de folato deve ser corrigida quando necessário.  
Recentemente, a deficiência de vitamina D3 foi citada como fator de resistência aos ESA. Um estudo prospectivo avaliou dois grupos de crianças ambos com insuficiência de vitamina D3 e doses semelhantes de ESA. Um grupo recebeu ergocalciferol e, ao final do estudo, a dose de ESA no grupo tratado diminuiu significativamente, quando comparada ao grupo controle. A deficiência de vitamina D3 deve ser rotineiramente avaliada e tratada quando necessário.(54)

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Os pacientes com anemia na doença renal crônica devem ser acompanhados em serviços especializados de nefrologia com terapia renal substitutiva (hemodiálise e diálise peritoneal). Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica das doses do medicamento prescritas e dispensadas e da adequação de uso.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 11. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER -->
Sugere-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: 12. REFERÊNCIAS BIBLIOGRÁFICAS -->
1. Hsu CY, Bates DW, Kuperman GJ, Curhan GC. Relationship between hematocrit and renal function in men and women. Kidney Int. 2001;59(2):725-31.  
2. Kazmi WH, Kausz AT, Khan S, Abichandani R, Ruthazer R, Obrador GT, et al. Anemia: an early complication of chronic renal insufficiency. Am J Kidney Dis. 2001;38(4):803-12.  
3.  Levey AS, Stevens LA, Schmid CH, Zhang YL, Castro AF 3rd, Feldman HI, et al. A new equation to estimate glomerular filtration rate. Ann Intern Med. 2009;150(9):604-12.  
4. Berns JS. Erythropoietin for the anemia of chronic kidney disease in hemodialysis patients [Internet]. UpToDate; 2009. [acesso em 31 Jan 2010]. Disponível em: <u>http://www.uptodate.com/contents/erythropoietin-for-the-anemia-of-chronic-kidney-disease-inhemodialysis-patients.</u>  
5. Fishbane S. Hematologic aspects of kidney disease. In: Brenner BM. Brenner and Rector's The Kidney. 8th ed. Philadelphia: Saunders; 2007. p. 1728-38.  
6. Eschbach JW, Cook JD, Scribner BH, Finch CA. Iron balance in hemodialysis patients. Ann Intern Med. 1977;87(6):710-3.  
7. Abramson JL, Jurkovitz CT, Vaccarino V, Weintraub WS, McClellan W. Chronic kidney disease, anemia, and incident stroke in a middle-aged, community-based population: the ARIC Study. Kidney Int. 2003;64(2):610-5.  
8. Jurkovitz CT, Abramson JL, Vaccarino LV, Weintraub WS, McClellan WM. Association of high serum creatinine and anemia increases the risk of coronary events: results from the prospective community-based atherosclerosis risk in communities (ARIC) study. J Am Soc Nephrol. 2003;14(11):2919-25.  
9. Sarnak MJ, Tighiouart H, Manjunath G, MacLeod B, Griffith J, Salem D, et al. Anemia as a risk factor for cardiovascular disease in The Atherosclerosis Risk in Communities (ARIC) study. J Am Coll Cardiol. 2002;40(1):27-33.  
10. McClellan WM, Flanders WD, Langston RD, Jurkovitz C, Presley R. Anemia and renal insufficiency are independent risk factors for death among patients with congestive heart failure admitted to community hospitals: a population-based study. J Am Soc Nephrol. 2002;13(7):1928-36.  
11. Locatelli F, Pisoni RL, Combe C, Bommer J, Andreucci VE, Piera L, et al. Anaemia in haemodialysis patients of five European countries: association with morbidity and mortality in the Dialysis Outcomes and Practice Patterns Study (DOPPS). Nephrol Dial Transplant. 2004;19(1):121-32. 12. Levin A. The relationship of haemoglobin level and survival: direct or indirect effects? Nephrol Dial Transplant. 2002;17 Suppl 5:8-13.  
13. Eschbach JW, Abdulhadi MH, Browne JK, Delano BG, Downing MR, Egrie JC, et al. Recombinant human erythropoietin in anemic patients with end-stage renal disease. Results of a phase III multicenter clinical trial. Ann Intern Med. 1989;111(12):992-1000.  
14. Phrommintikul A, Haas SJ, Elsik M, Krum H. Mortality and target haemoglobin concentrations in anaemic patients with chronic kidney disease treated with erythropoietin: a meta-analysis. Lancet. 2007;369(9559):381-8.  
15. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. Diretrizes Clínicas para o Cuidado ao paciente com Doença Renal Crônica – DRC no Sistema Único de Saúde/ Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Especializada e Temática. – Brasília: Ministério da Saúde, 2014. p.:37 p.: il.;  
16. Kidney Disease: Improving Global Outcomes (KDIGO) CKD Work Group. KDIGO 2012 Clinical Practice Guideline for the Evaluation and Management of Chronic Kidney Disease. Kidney Int (Suppl) 2013;3:1-150.  
17. Tonia T, Mettler A, Robert N, Schwarzer G, Seidenfeld J, Weingart O, et al. Erythropoietin or darbepoetin for patients with cancer. Cochrane Database Syst Rev. 2012;12:CD003407.  
18. Pfeffer MA, Burdmann EA, Chen CY, Cooper ME, de Zeeuw D, Eckardt KU, et al.  A trial of darbepoetin alfa in type 2 diabetes and chronic kidney disease.  N Engl J Med. 2009;361(21):2019-32.  
19. Jones M, Ibels L, Schenkel B, Zagari M. Impact of epoetin alfa on clinical end points in patients with chronic renal failure: a meta-analysis. Kidney Int. 2004;65(3):757-67.  
20. Vanrenterghem Y, Bárány P, Mann JF, Kerr PG, Wilson J, Baker NF, et al. Randomized trial of darbepoetin alfa for treatment of renal anemia at a reduced dose frequency compared with rHuEPO in dialysis patients. Kidney Int. 2002;62(6):2167-75.  
21. Palmer SC, Saglimbene V, Mavridis D, Salanti G, Craig JC, Tonelli M,et al. Erythropoiesis-stimulating agentes for anemia in adults with chronic kidney disease: a network meta-analysis. Cochrane Database Syst Rev. 2014;12:CD010590.  
22. Revicki DA, Brown RE, Feeny DH, Henry D, Teehan BP, Rudnick MR, et al. Health-related quality of life associated with recombinant human erythropoietin therapy for predialysis chronic renal disease patients. Am J Kidney Dis. 1995;25(4):548-54.  
23. Alexander M, Kewalramani R, Agodoa I, Globe D. Association of anemia correction with health related quality of life in patients not on dialysis. Curr Med Res Opin. 2007;23(12):2997-3008.  
24. Cody J, Daly C, Campbell M, Donaldson C, Khan I, Rabindranath K, et al. Recombinant human erythropoietin for chronic renal failure anaemia in pre-dialysis patients. Cochrane Database Syst Rev. 2005(3):CD003266.  
25. Gouva C, Nikolopoulos P, Ioannidis JP, Siamopoulos KC. Treating anemia early in renal failure patients slows the decline of renal function: a randomized controlled trial. Kidney Int. 2004;66(2):753-60. 26. Drüeke TB, Locatelli F, Clyne N, Eckardt KU, Macdougall IC, Tsakiris D, et al. Normalization of hemoglobin level in patients with chronic kidney disease and anemia. N Engl J Med. 2006;355(20):207184.  
27. Macdougall IC, Temple RM, Kwan JT. Is early treatment of anaemia with epoetin-alpha beneficial to pre-dialysis chronic kidney disease patients? Results of a multicentre, open-label, prospective, randomized, comparative group trial. Nephrol Dial Transplant. 2007;22(3):784-93.  
28. Roger SD, McMahon LP, Clarkson A, Disney A, Harris D, Hawley C, et al. Effects of early and late intervention with epoetin alpha on left ventricular mass among patients with chronic kidney disease (stage 3 or 4): results of a randomized clinical trial. J Am Soc Nephrol. 2004;15(1):148-56.  
29. Provenzano R, Bhaduri S, Singh AK. Extended epoetin alfa dosing as maintenance treatment for the anemia of chronic kidney disease: the PROMPT study. Clin Nephrol. 2005;64(2):113-23.  
30. Pergola PE, Gartenberg G, Fu M, Wolfson M, Rao S, Bowers P. A randomized controlled study of weekly and biweekly dosing of epoetin alfa in CKD Patients with anemia. Clin J Am Soc Nephrol. 2009;4(11):1731-40.  
31. Lee YK, Kim SG, Seo JW, Oh JE, Yoon JW, Koo JR, et al. A comparison between once-weekly and twice- or thrice-weekly subcutaneous injection of epoetin alfa: results from a randomized controlled multicentre study. Nephrol Dial Transplant. 2008;23(10):3240-6.  
32. Cody J, Daly C, Campbell M, Donaldson C, Khan I, Vale L, et al. Frequency of administration of recombinant human erythropoietin for anaemia of end-stage renal disease in dialysis patients. Cochrane Database Syst Rev. 2002;(4):CD003895.  
33. Besarab A, Bolton WK, Browne JK, Egrie JC, Nissenson AR, Okamoto DM, et al.  The effects of normal as compared with low hematocrit values in patients with cardiac disease who are receiving hemodialysis and epoetin.  N Engl J Med. 1998;339(9):584-90.  
34. Coyne DW. The health-related quality of life was not improved by targeting higher hemoglobin in the Normal Hematocrit Trial. Kidney Int. 2012;82(2):235-41.  
35. Kaufman JS, Reda DJ, Fye CL, Goldfarb DS, Henderson WG, Kleinman JG. Subcutaneous compared with intravenous epoetin in patients receiving hemodialysis. Department of Veterans Affairs Cooperative Study Group on Erythropoietin in Hemodialysis Patients. N Engl J Med. 1998;339(9):578-83.  
36. Messa P, Nicolini MA, Cesana B, Brezzi B, Zattera T, Magnasco A, et al. Efficacy prospective study of different frequencies of Epo administration by i.v. and s.c. routes in renal replacement therapy patients. Nephrol Dial Transplant. 2006;21(2):431-6.  
37. Bandeira MFS, Garcia CD. Recomendações para o tratamento da anemia no paciente pediátrico. J Bras Nefrol 2014;36(1 Supl. 1):36-45.  
38. Manns BY, Tonelli M. The new FDA labeling for ESA--implications for patients and providers. Clin J Am Soc Nephrol. 2012;7(2)348-53.  
39. Singh AK, Szczech L, Tang KL, Barnhart H, Sapp S, Wolfson M, et al. Correction of anemia with epoetin alfa in chronic kidney disease. N Engl J Med. 2006;355(20):2085-98.  
40. Strippoli GF, Navaneethan SD, Craig JC. Haemoglobin and haematocrit targets for the anaemia of chronic kidney disease. Cochrane Database Syst Rev. 2006(4):CD003967.  
41. Palmer SC, Navaneethan SD, Craig JC, Johnson DW, Tonelli M, Garg AX, et al. Meta-analysis: erythropoiesis-stimulating agents in patients with chronic kidney disease. Ann Intern Med. 2010;153(1):2333.  
42. Clement FM, Klarenbach S, Tonelli M, Johnson JA, Manns BJ. The impact of selecting a high hemoglobin target level on health-related quality of life for patients with chronic kidney disease: a systematic review and meta-analysis. Arch Intern Med. 2009;169(12):1104-12.  
43. Parfrey PS, Lauve M, Latremouille-Viau D, Lefebvre P. Erythropoietin therapy and left ventricular mass index in CKD and ESRD patients: a meta-analysis. Clin J Am Soc Nephrol. 2009;4(4):755-62.  
44. Berns JS. Anemia of chronic kidney disease: Target hemoglobin/hematocrit for patients treated with erythropoietic agents [Internet]. UpToDate; 2014. [acesso em 14 Set 2014]. Disponível em: <u>http://www.uptodate.com/contents/anemia-of-chronic-kidney-disease-target-hemoglobin-hematocrit-forpatients-treated-with-erythropoietic-agents.</u>  
45. FDA. U.S. Food and Drug Administration [Internet].  [acesso em 14 Set 2014]. Disponível em:http://www.fda.gov/Drugs/DrugSafety/PostmarketDrugSafetyInformationforPatientsandProviders/uc <u>m109375.htm.</u>  
46. Information for Healthcare Professionals: Erythropoiesis Stimulating Agents (ESA) [Aranesp (darbepoetin), Epogen (epoetin alfa), and Procrit (epoetin alfa)] Acessado em :<  
http://www.fda.gov/Drugs/DrugSafety/PostmarketDrugSafetyInformationforPatientsandProviders/ucm12 6481.htm FDA:  08/14/2013 ]. [PARA DOSE INDIVIDUALIZADA]  
47. Tolman C, Richardson D, Bartlett C, Will E. Structured conversion from thrice weekly to weekly erythropoietic regimens using a computerized decision-support system: a randomized clinical study. J Am Soc Nephrol. 2005;16(5):1463-70.  
48. Brimble KS, Rabbat CG, McKenna P, Lambert K, Carlisle EJ. Protocolized anemia management with erythropoietin in hemodialysis patients: a randomized controlled trial. J Am Soc Nephrol. 2003;14(10):2654-61.  
49. Patterson P, Allon M. Prospective evaluation of an anemia treatment algorithm in hemodialysis patients. Am J Kidney Dis. 1998;32(4):635-41.  
50. Atkinson MA, Furth SL. Anemia in children with chronic kidney disease. Nat Rev Nephrol 2011; 7:63541.  
51. Jander A, Wierciński R, Bałasz-Chmielewska I, Miklaszewska M, Zachwieja K, Borzecka H, et al. Anaemia treatment in chronically dialysed children: a multicentre nationwide observational study. Scand J Urol Nephro. 2012;46:375-80.  
52. Rossert J, Gassmann-Mayer C, Frei D, McClellan W. Prevalence and predictors of epoetin hyporesponsiveness in chronic kidney disease patients. Nephrol Dial Transplant. 2007;22(3):794-800. 53. Gahl WA, Reed, GF, Thoene JG, Schulman JD, Rizzo WB, Jonas AJ, et al. Cysteamine therapy for children with nephropathic cistinosis. N Engl J Med 1987; 316: 971-7.  
54. Rianthavorn P, Boonyapapong P Ergocalciferol decreases erythropoietin resistance in children with chronic kidney disease stage 5. Pediatr Nephrol 2013; 28: 1261-6.

---

<!-- METADADOS: doenca: Portaria SAS 365 - DRC | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE ALFAEPOETINA -->
Eu,_____________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento alfaepoetina, indicado para o tratamento da anemia na doença renal crônica.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico ______________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- correção da anemia e consequente redução da necessidade de transfusões;  
- melhora sintomática e da qualidade de vida;  
- redução no número de hospitalizações; e  
- melhora da capacidade cognitiva e do desempenho físico.  
- Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais  
efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso da alfaepoetina na gravidez; portanto, caso engravide,  
- devo avisar imediatamente ao meu médico;  
- os efeitos adversos mais comumente relatados são os seguintes: tonturas, sonolência, febre,  
- dores de cabeça, dores nas juntas e nos músculos, fraqueza e aumento da pressão arterial. Também podem ocorrer problemas graves no coração, como infarto do miocárdio, acidentes vasculares cerebrais (derrame), além da formação de trombos. Ausência da produção de células vermelhas do sangue foi relatada raramente após meses a anos de tratamento com alfaepoetina;  
- reações no local da injeção, como queimação e dor, podem ocorrer, mas mais frequentemente  
- em pacientes que receberam o medicamento por via subcutânea que por via intravenosa; - o medicamento está contraindicado em casos de hipersensibilidade (alergia) a ele ou aos  
- componentes da fórmula e em casos de pressão alta não controlada; e  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem. Estou ciente de que esse medicamento somente pode ser utilizado por mim, comprometendo-  
- me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.(  ) Sim (  ) Não  
|Local:Data:|||
|---|---|---|
|Nome dopaciente:|||
|CartãoNacional deSaúde:|||
|Nome do responsável legal:|||
|Documento deidentificação doresponsável legal:|||
|______________________<br>Assinatura dopaciente ou d|_______________<br>o responsável legal||
|Médico responsável:|CRM:|UF:|
|_________________<br>Assinatura e carimb|__________<br>o do médico||
|Data:___________|_________||

---

