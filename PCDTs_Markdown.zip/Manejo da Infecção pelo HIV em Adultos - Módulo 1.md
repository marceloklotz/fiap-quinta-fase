<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA SECTICS/MS Nº 56, DE 18 DE OUTUBRO DE 2023  
Torna pública a decisão de aprovar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 1 - Tratamento.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE DO MINISTÉRIO DA SAÚDE, no uso das atribuições que lhe conferem a alínea "c" do inciso I do art. 32 do Decreto nº 11.358, de 1º de janeiro de 2023, e tendo em vista o disposto nos arts. 20, 22 e 23 do Decreto nº 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º. Fica aprovado, no âmbito do Sistema Único de Saúde- SUS, o Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 1 - Tratamento.  
Art. 2º. Ficam atualizados, no âmbito do SUS, os capítulos 6 a 14 do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos, conforme consta do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos: Módulo 1 - Tratamento.  
Art. 3º. O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde - Conitec estará disponível no endereço eletrônico: https://www.gov.br/conitec/pt-br.  
Art. 4º. Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: ANEXO -->
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA MANEJO DA INFECÇÃO PELO HIV EM ADULTOS MÓDULO 1: TRATAMENTO

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **INTRODUÇÃO** -->
A experiência nacional de enfrentamento à epidemia de aids no âmbito do Sistema Único de Saúde (SUS) ao longo do tempo, foi estabelecida e alicerçada na participação social, no respeito aos direitos humanos, no combate ao estigma, ao preconceito e à discriminação.  
O Programa Conjunto das Nações Unidas sobre o HIV/aids (Unaids) propõe que a aids pode ser eliminada como problema de saúde pública até 2030, desde que se alcancem as metas 95/95/95 que consistem em: diagnosticar 95% das pessoas que vivem com HIV ou aids (PVHA), 95% delas estejam em tratamento com antirretrovirais, e 95% das em tratamento em supressão viral.  
O acesso à terapia antirretroviral (TARV) reduz morbidade e mortalidade relacionadas à aids, tem impacto na qualidade de vida das PVHA e estabelece seu status de condição crônica.  
Entretanto, o acesso à prevenção, ao diagnóstico e ao tratamento ainda são muito desiguais no Brasil, o que se reflete no diagnóstico tardio, na cobertura de tratamento, na retenção ao cuidado, na perda de seguimento, na supressão viral e na sobrevida. De modo geral, esses indicadores são desfavoráveis entre PVHA com menor tempo de estudo formal, negras ou indígenas, com mais de 50 anos, que vivem em municípios menores e em algumas regiões do Brasil.  
É frequente que o diagnóstico do HIV, ou mesmo a reinserção de pessoas diagnosticadas no passado, ocorram já na presença de tuberculose ou de condições definidoras de aids. A coinfecção TB-HIV reduz de forma significativa a sobrevida de PVHA, particularmente quando ocorre na presença de imunossupressão grave, com contagem de linfócitos T-CD4 (LT-CD4) menor que 200 células/mm<sup>3</sup> e, especialmente, quando inferior a 100 células/mm<sup>3</sup> . Testagem rápida para HIV e início rápido da TARV - em 7 ou até 14 dias após o início do tratamento da TB ou de doenças oportunistas - ainda não estão totalmente implementados no Brasil.  
Como estratégia para reduzir a mortalidade por aids no Brasil, o Departamento de HIV/Aids, Tuberculose, Hepatites Virais e Infecções Sexualmente Transmissíveis (DATHI) está introduzindo o rastreio com testes “ _point of care_ ”, na mesma hora e no local do atendimento, para TB e criptococose com objetivo de intensificar a política de tratamento da aids na presença de imunossupressão grave, remoção de barreiras e garantia de  acesso rápido ao tratamento, atuando nas lacunas do cuidado que podem ter impacto na mortalidade devido a aids no país.  
Entretanto, não é apenas o diagnóstico tardio, a retenção no cuidado e o acesso à TARV que tem impacto na vida das PVHA. Entre aqueles que têm acesso ao diagnóstico e ao início oportuno da TARV, a toxicidade e o desenvolvimento de comorbidades adquiriram particular importância, nos últimos anos. No Brasil, cerca de 180 mil pessoas estão em TARV e têm idade superior a 50 anos, estabelecendo como essenciais a abordagem ao estilo de vida e a prevenção e manejo de condições crônicas não transmissíveis na agenda de cuidado.  
Neste contexto, o DATHI se propôs a atualizar o PCDT em 2023, expressando as principais estratégias de cuidado e tratamento introduzidas após 2017.  
A atualização do PCDT será dividida em três (3) etapas:  
- i. Tratamento;  
- ii. Coinfecções;  
- iii. Comorbidades.  
A presente atualização refere-se à primeira etapa – Tratamento.  
Materiais complementares a esta publicação estão disponíveis no site: <u>https://www.gov.br/aids/pt-br/centrais-de-conteudo. Incluindo Manual do Cuidado Contínuo e</u> Manual técnico para diagnóstico da infecção pelo HIV em adultos.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **METODOLOGIA** -->
O processo de desenvolvimento desse PCDT envolveu a realização de avaliações de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências, que foram adotadas e/ou adaptadas às recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para o tratamento do HIV. Uma descrição mais detalhada da metodologia está disponível no Apêndice 1. Além disso, o histórico de alterações deste Protocolo encontra-se descrito no Apêndice 2.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **ABORDAGEM INICIAL DO ADULTO VIVENDO COM HIV** -->
Os principais objetivos da abordagem inicial são: identificar o estágio clínico da infecção pelo HIV, avaliar a presença de coinfecções ou comorbidades, conhecer as vulnerabilidades socioculturais do usuário e estabelecer uma relação de confiança e respeito com a equipe multiprofissional do serviço de saúde, objetivando a pronta vinculação ao serviço de saúde.  
A avaliação inicial de uma pessoa com diagnóstico de infecção pelo HIV deve incluir história médica atual e pregressa, exame físico completo, exames complementares e conhecimento de seus contextos de vida. O uso de uma linguagem acessível é fundamental para a compreensão dos aspectos essenciais da infecção, da avaliação clínico-laboratorial, da adesão, do tratamento e sua retenção. Este diálogo propõe-se a esclarecer eventuais dúvidas e abrir caminho para a superação das dificuldades.  
O acolhimento à PVHA é atribuição de todos os profissionais da equipe e deve iniciar assim que a pessoa chegar ao serviço de saúde, garantindo uma escuta respeitosa e profissional, independentemente do motivo que a levou a buscar ajuda.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.1. **Vulnerabilidades relacionadas ao HIV** -->
O uso da terapia antirretroviral e outros avanços tecnológicos permitiram o aumento da expectativa e qualidade de vida das Pessoas Vivendo com HIV/ Aids (PVHA). No entanto, ainda  
persistem condições socioculturais que criam vulnerabilidades para a infecção e para morbimortalidade pelo HIV/Aids. Entre os fatores de vulnerabilidade que criam barreiras significativas tanto para o controle da epidemia, como para o sucesso do tratamento e do cuidado, destacam-se vivências de discriminação e estigma relacionados ao racismo, à homofobia, transfobia, sexismo, machismo, sorofobia entre tantas outras condições que aprofundam as inequidades em saúde.  
Tanto na saúde pública, como na clínica, a relação entre vulnerabilidades e Aids tem mão dupla. A exclusão social tem um papel na construção da vulnerabilidade à infecção pelo HIV. Por outro lado, diferentes aspectos ligados ao viver com HIV/Aids reforçam e produzem novas vulnerabilidades decorrentes do estigma da doença, que persiste impactando a saúde das pessoas, sua adesão e retenção ao tratamento.  
**Portanto, na abordagem inicial e no seguimento, os aspectos que causam as vulnerabilidades para o HIV devem ser levados em consideração no encontro entre profissionais de saúde e usuário.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.2. **Anamnese** -->
Conhecer e compreender as condições psicossociais, riscos e vulnerabilidades que envolvem o contexto de vida da PVHA representa uma ferramenta importante para o cuidado integral e o consequente sucesso terapêutico.  
A investigação não deve se esgotar na primeira consulta, mas precisa ser complementada e atualizada nos atendimentos subsequentes. Esses aspectos podem ser abordados tanto pelo médico como por outro membro da equipe de saúde, conforme as particularidades de cada serviço.  
Os itens listados no Quadro 1 para estruturar um roteiro inicial, que pode ser adaptado conforme a necessidade de cada pessoa.  
**Quadro 1** : Roteiro para abordagem inicial  
||•<br> <br>contage<br>antirretr|Explicar a doença: transmissão, história natural, significado da<br>m de LT-CD4+ e do exame de carga viral, impacto da terapia<br>oviral (TARV) na morbimortalidade|
|---|---|---|
|Informações|•<br>|Revisar e documentar o primeiro exame anti-HIV|
|específicas sobre a<br>infecção pelo HIV|•<br> <br>anterior<br>•<br> <br>prévios<br>pré-exp|Verificar se há contagens de LT-CD4+ e exames de CV-HIV<br>es<br>Discutir o uso de ARV e a ocorrência de eventos adversos<br>(ex.: com uso de profilaxia pós-exposição - PEP – e profilaxia<br>osição-PrEP)|
||Avaliar:<br>•<br>|<br>Presença de sinais e/ou sintomas|
|História médica<br>atual e passada|•<br> <br>medica<br>•<br> <br>(_interfer_<br>•<br>|História de alergias, hipersensibilidade ou intolerância a<br>mentos<br>História de tuberculose, prova tuberculínica ou IGRA<br>_on gamma release assay_), profilaxia e/ou tratamento prévio<br>História de doença mental familiar e/ou pessoal|  
||•<br>profil<br>•<br>inclui<br>•<br>•<br>altern|<br>ax<br> <br>nd<br> <br> <br>ati|Infecção oportunista (IO) prévia ou atual e necessidade de<br>ia para IO<br>Outras infecções ou comorbidades atuais e/ou pregressas,<br>o histórico de internações hospitalares<br>Histórico de imunizações<br>Uso<br>de<br>medicamentos,<br>práticas<br>complementares<br>e/ou<br>vas|
|---|---|---|---|
||Avali<br>•|ar:<br>|<br>Parcerias e práticas sexuais|
|Riscos e|•|<br>|Utilização de preservativos e outros métodos de prevenção<br> <br> <br> <br> <br> <br>|
|<br>|•||História<br>de<br>sífilis<br>e<br>outras<br>Infecções<br>Sexualmente|
|vulnerabilidades|Trans<br>•<br>•|mi<br> <br>|<br>ssíveis (IST)<br>Uso de tabaco, álcool e outras drogas<br>Interesse em reduzir os danos à saúde|
||Avali|ar:<br>|<br>|
||•|<br>|Reação emocional ao diagnóstico<br>|
|História psicossocial|•<br>gover<br>•<br>•|<br>na<br> <br>|Rede de apoio social (família, amigos, organizações não<br>mentais, acesso a Rede de Atenção Psicossocial)<br>Nível educacional<br>Condições de trabalho, domicílio e alimentação|
||Discu<br>|tir<br>|/avaliar:<br>D d t filh|
|Saúde reprodutiva|•<br>•|<br>|esejo e er os<br>Métodos contraceptivos|
||•||Estado sorológico da(s) parceria(s) e filho(s)|
||Revis|ar|histórico de:|
||•||Doenças cardiovasculares e hipertensão|
|História familiar|•||Dislipidemias|
||•||Diabetes|
||•||Neoplasias|  
Fonte: DATHI/SVSA/MS. Legenda :IO: infecções oportunistas; ARV: antirretroviral  
Pessoas com diagnóstico recente de infecção pelo HIV podem apresentar expectativas e dúvidas que podem dificultar a plena compreensão de todas as informações disponibilizadas. Compreender tal situação, esclarecer os questionamentos e fornecer informações atualizadas fortalece o vínculo do paciente com o profissional de saúde e o serviço de saúde, favorece a retenção e consequentemente o sucesso terapêutico. Desse modo, a primeira consulta deverá ter duração superior às demais consultas de rotina. Sugere-se duração de, ao menos, 45 minutos para a primeira avaliação e consultas subsequentes com duração variável, a depender da demanda da PVHA e da abordagem profissional.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.3. **Exame físico** -->
A infecção pelo HIV tem um acometimento sistêmico. É necessário, portanto, atentar para sinais clínicos comumente associados à doença Figura 1. O exame físico deve ser completo e incluir a aferição da pressão arterial, peso, altura, cálculo do índice de massa corpórea e medida da circunferência abdominal.  
O exame físico completo deve ser realizado regularmente porque leva a achados importantes. O exame da pele, a oroscopia, exame da genitália externa e região perianal são também relevantes, uma vez que diversos sinais e sintomas presentes podem estar associados às infecções sexualmente transmissíveis (IST) e a infecção pelo HIV. Quanto mais baixa a contagem de LTCD4+, mais frequentemente os pacientes devem ser examinados.  
<!-- Start of picture text -->
_ goin SS<br><!-- End of picture text -->  
Figura 1: Sinais clínicos que podem estar relacionados à infecção pelo HIV e que devem ser investigados no exame físico inicial Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.4. **Exames complementares adicionais** -->
A abordagem laboratorial no início do acompanhamento clínico auxilia a avaliação da condição geral de saúde, a pesquisa de comorbidades, a presença de coinfecções e a urgência no início da TARV. Também fornece informações laboratoriais basais pré-tratamento, bem como orienta sobre a necessidade de imunizações e profilaxias.  
O Quadro 2 indica os exames que devem ser solicitados na primeira consulta.  
**Quadro 2:** Exames complementares para abordagem inicial  
|**Exames relacionados ao HIV:**|
|---|
|Contagem de LT-CD4+ e exame de carga viral do HIV (CV-HIV)<br>Genotipagempré-tratamento<sup>(a)</sup>|
|**Exames laboratoriais:**|
|Hemograma completo|  
Glicemia de jejum Dosagem de lipídios (colesterol total, HDL, LDL, VLDL, triglicerídeos) <u>Avaliação hepática e renal (AST, ALT, FA, BT e frações, Cr, exame básico de urina)</u> **<mark>Avaliação</mark>** **<u><mark>de coinfecções, infecções sexualmente transmissíveis (IST) e comorbidades:</mark></u>** Teste imunológico para sífilis<sup>(b)</sup> LF – LAM - Teste de fluxo lateral para detecção de lipoarabinomanano<sup>(c)</sup> LF-CrAg - Teste de fluxo lateral antígeno criptocócico ( _Cryptococcal Antigen Lateral Flow Assay_ )<sup>(d)</sup>  
Testes para hepatites virais (anti-HAV, anti-HCV, HBsAg, anti-HBc total e anti-HBs para verificação de imunização) IgG para toxoplasmose Sorologia para HTLV I e II, Leishmaniose e Chagas<sup>(e)</sup> Prova tuberculínica (PT) ou IGRA<sup>(f)</sup> <u>Radiografia de tórax</u>  
Fonte: DATHI/SVSA/MS.  
Legenda: HDL: lipoproteína de alta densidade ( _high density lipoprotein_ ); LDL: lipoproteína de baixa densidade ( _low density lipoprotein_ ); VLDL: lipoproteína de muito baixa densidade ( _very low density lipoprotein_ ); AST ou TGO: aspartato transaminase ou transaminase glutâmico oxalacética; ALT ou TGP: alanina transaminase ou transaminase glutâmica pirúvica sérica; FA: fosfatase alcalina; BT: bilirrubina total; Cr: creatinina  
(a) Indicada APENAS para gestantes, casos novos com coinfecção TB/HIV, pessoas que tenham se infectado com parceria em uso de TARV, crianças e adolescentes e soroconversão durante o uso de PrEP  
- (b) Consultar o “Manual Técnico para Diagnóstico da Sífilis”  
- (c) PVHA com manifestações clínicas sugestivas de tuberculose pulmonar ou extrapulmonar conforme item 7.3.1  
(d) PVHA estágio clínico da 3 ou 4 da Organização Mundial da Saúde ou LT-CD4 < 200 células/mm<sup>3</sup> e sem histórico de doença criptocócica, conforme ítem 7.3.2  
- (e) Triagem para indivíduos oriundos de áreas endêmicas.  
- (f) Indicados para pessoas com contagem de linfócitos T-CD4+ > 350 células/mm³.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.6. **Infecção latente pelo Mycobacterium tuberculosis** -->
A infecção pelo HIV determina elevado risco de desenvolver tuberculose ativa e é cerca de 20 vezes superior em relação à população geral<sup>1,2</sup> . O tratamento da infecção latente pelo _Mycobacterium tuberculosis_ (ILTB) reduz a mortalidade<sup>3–5</sup> e o risco de desenvolvimento de tuberculose ativa nos anos subsequentes<sup>3,6</sup> .  
**A redução do risco de desenvolver tuberculose ativa é potencializada pelo tratamento da ILTB e especialmente pelo início precoce da terapia antirretroviral (TARV).**  
A PT é realizada mediante a inoculação do derivado proteico purificado (PPD) e é considerada positiva quando o resultado da leitura for maior ou igual a 5 mm.  
Outro método para detecção de ILTB é a realização do teste de liberação interferon-gama (IGRA), que detecta interferon-gama liberado pelas células T após exposição aos antígenos do _M. tuberculosis._  
Tanto a PT quanto o IGRA são indicados para pessoas vivendo com HIV (PVHA) com contagem de linfócitos T-CD4+ maior que 350 células/mm³.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.7. **Investigação da tuberculose ativa** -->
A tuberculose é a principal causa conhecida de óbito por doenças infecciosas nas PVHA. Por isso, a tuberculose deve ser investigada em todas as consultas, utilizando o escore clínico validado pela Organização Mundial da Saúde (OMS)<sup>7</sup> , calculado pelo questionamento sobre a presença dos sintomas descritos na Figura 2:  
<!-- Start of picture text -->
C} Tosse<br>C} Febre<br>C} Emagrecimento<br>@ Sudorese noturna<br><!-- End of picture text -->  
Figura 2: Sinais e sintomas para rastreio da tuberculose  
Em 2021, incorporou-se ao SUS um teste rápido para rastreio e diagnóstico da tuberculose pulmonar e extrapulmonar nas PVHA<sup>8</sup> . O fluxo lateral para detecção do lipoarabinomanano ( **LFLAM) é um teste** **_"point-of-care"_** _,_ que detecta a presença do antígeno lipoarabinomanano em amostra de urina. Trata-se de um teste de baixa complexidade para execução, com resultado rápido, dispensando a necessidade de ambiente laboratorial. Possui elevado valor preditivo positivo em pacientes com dano imunológico grave, como na presença de contagem de LT-CD4 <u><</u> 100 células/mm<sup>3. 9–12</sup> .  
Pode ser utilizado como rastreio nos serviços de saúde, sejam ambulatoriais ou hospitalares, obedecendo os seguintes critérios:  
- **a. Indicações para uso do LF-LAM em PVHA no atendimento ambulatorial:**  
- PVHA assintomáticas com LT-CD4 < 100 células/mm<sup>3</sup> ;  
- PVHA com sinais e/ou sintomas de TB pulmonar ou extrapulmonar, independentemente da contagem de LT-CD4;  
- PVHA gravemente doentes, independentemente da contagem de LT-CD4.  
- **b. Indicações para uso do LF-LAM em PVHA no atendimento hospitalar/internação:**  
- PVHA assintomáticos LT-CD4 < 200 células/mm<sup>3</sup> ;  
- PVHA com sinais e/ou sintomas de TB pulmonar ou extrapulmonar, independentemente da contagem de LT-CD4;  
- PVHA gravemente doentes, independentemente da contagem de LT-CD4.  
São consideradas PVHA gravemente doentes, aqueles que apresentarem: frequência respiratória ≥30 respirações/minuto; frequência cardíaca ≥ 120 batimentos/minuto; incapacidade para deambular sem auxílio; temperatura corporal ≥ 39°C, considerando a epidemiologia local e julgamento clínico, independentemente da contagem de LT-CD4+.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.8. **Investigação da doença criptocócica** -->
Diante da sua “invisibilidade epidemiológica”, diagnóstico tardio, dificuldade de acesso ao diagnóstico laboratorial e indisponibilidade de medicamentos efetivos, a mortalidade por doença criptocócica permanece elevada. O diagnóstico e o tratamento oportunos da doença criptocócica são os principais fatores relacionados à redução de mortalidade<sup>13–16</sup> .  
O LF-CrAg é um teste imunocromatográfico, de fluxo lateral, que permite realizar o diagnóstico de criptococose em aproximadamente 10 minutos, sem necessidade de infraestrutura laboratorial. O teste pode ser realizado em amostra de soro, sangue periférico (através de punção digital) e líquor<sup>17–20</sup> .  
A detecção de CrAg no sangue pode preceder, em semanas a meses, as manifestações neurológicas<sup>17,21</sup> .  
Recomenda-se assim, o rastreio com LF-CrAg para PVHA com contagem de LT-CD4 abaixo de 200 células/mm<sup>3</sup> , **sem histórico prévio de meningite criptocócica** .<sup>1</sup>  
PVHA com histórico prévio de meningite criptococose devem ser avaliadas quanto aos sinais e sintomas neurológicos e, se necessário, encaminhadas para realização de punção lombar com avaliação liquórica (exame micológico direto e cultura) e hemocultura para verificar a fungemia. A Figura 3 descreve o rastreio de doença criptocócica.  
1 Para rastreio da doença criptócica em PVHA assintomáticas, quando disponível e oportuno, optar por amostra de soro.  
<!-- Start of picture text -->
Pessoa vivendo com HIV<br>Nao [ \ sim<br>/ Contagem de \<br>{ cp4<200<br>célulasimL?<br>‘Sem indicac&o de rastreio Realizar LF-CrAg<br>para criptococose usando 0 (puncao digital)<br>LF-CrAg J<br>Negativo | { Postivo |<br>PVHA sintomatica: investigar<br>eueres rweocces oporein inte Realizar hemocultura e<br>PVHA assintomatica: iniciar Pungao4  lombar’ 4<br>TARV<br><!-- End of picture text -->  
Figura 3: Fluxo para rastreio de doença criptocócica  
PVHA: Pessoa vivendo com HIV; LF-CrAg - teste rápido para detecção do antígeno criptocócico; IO - Infecções oportunistas; TARV - Terapia antirretroviral. 1 – Hemocultura para verificar fungemia e encaminhar líquor para o laboratório para realização de LF-CrAg, exame micológico direto e cultura.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 3.9. **Pontos chave da avaliação inicial** -->
Após a avaliação inicial, alguns pontos devem estar claros tanto para a PVHA, quanto para o profissional da saúde:  
|O que deverá|•|Em termos gerais, como o vírus causa a doença;|
|---|---|---|
|estar claro para<br>|•|A diferença entre viver com HIV e viver com aids;|
|a PVHA após<br>a(s) primeira(s)<br>|•<br>CV;|A importância e significado da contagem de LT-CD4+ e o exame de|
|consulta(s):|•<br>•<br>utilida|Formas de transmissão e estratégias de prevenção;<br>Como a terapia antirretroviral (TARV) funciona e qual a sua<br>de;|
||•<br>•<br>transm<br>transm<br>o paci<br>•<br>físicas<br>•|Prognóstico, com mensagens que é possível viver bem com HIV<br>Adoção de práticas de prevenção de infecções sexualmente<br>issíveis (IST) e hepatites virais, esclarecendo sobre seus riscos na<br>issão e evolução da infecção pelo HIV, propiciando abertura para que<br>ente fale abertamente sobre suas práticas sexuais e sintomas de IST;<br>Abordagem ao estilo de vida, com dieta equilibrada, atividades<br>regulares, evitar tabagismo para reduzir risco cardiovascular;<br>Onde encontrar mais informações médicas e sociais;|  
||•<br>Grupos de apoio (ONG, organizações comunitárias) disponíveis na<br>área para o apoio de PVHA;<br>•<br>Testes laboratoriais planejados e sua utilidade para tratamento futuro.|
|---|---|
|O que o<br>profissional da<br>saúde deverá<br>saber após a(s)<br>|Infecção e risco<br>•<br>Quando, onde e por quais razões foi realizado o teste para HIV?<br>Houve um teste negativo antes disso? Quais os riscos que o paciente teve no<br>intervalo entre os testes?|
|consulta(s):|•<br>Práticas sexuais do usuário, para abordagem a IST;<br>•<br>História familiar de diabetes, doenças cardiovasculares e<br>hipertensão, dislipidemias, câncer, tuberculose ou outras doenças<br>infecciosas;<br>•<br>Histórico de viagens recentes? Onde nasceu ou onde passou a maior<br>parte da vida?<br>•<br>Que drogas recreativas consome regularmente e como (via<br>endovenosa, inalada etc.)?|
||•<br>Tabagismo? Quantidade acumulada (carteiras de cigarros/ano);<br>•<br>Era doador de sangue de repetição? Se sim, o médico deverá informar<br>o serviço de hemoterapia;<br>•<br>Contato prévio com pessoa vivendo com tuberculose?|
||Comprometimento imunológico<br><br>|
||•<br>Presença de sinais ou sintomas|
||•<br>Presença de coinfecções ou IO|
||•<br>Indicação de profilaxia ou tratamento preemptivo<br>Comorbidades<br><br>|
||•<br>Doenças anteriores, doenças concomitantes|
||•<br>Infecções prévias, tuberculose, IST, incluindo sífilis e hepatites A, B<br>e C<br>•<br>Medicamentos que utiliza|
||•<br>Existe história de reações alérgicas?|
||•<br>Vacinação? Possui registro?<br>Aspectos sociais|
||•<br>Parceria sexual e testagem para HIV e IST? Tem filhos ou planos<br>para a gravidez?<br>•<br>Contexto social do paciente, qual profissão/ocupação? Horário de<br>trabalho e outras atividades. Possui alguma crença/religião? Existem<br>restrições quanto à utilização de TARV?|
||•<br>Orientação sexual? Identidade de gênero? Nome social?<br>•<br>Quem conhece a condição sorológica do paciente? Rede de apoio<br>caso adoeça ou necessite de ajuda? Sabe se tem amigos infectados pelo HIV?<br>Tem interesse em entrar em contato com assistentes sociais ou grupos de<br>apoio (ONG)?<br>•<br>Avaliar necessidade para apoio à revelação diagnóstica e a urgência<br>da<br>necessidade<br>de<br>apoio<br>psicoterapêutico?<br>O<br>acompanhamento<br>psicoterapêutico, assimcomo oTARV, deve ser iniciadorapidamente.|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **QUANDO INICIAR A TERAPIA ANTIRRETROVIRAL** -->
A recomendação da TARV para todas as PVHA, independentemente da contagem de LTCD4, está associada com diversos benefícios tanto para o paciente, quanto para o sistema de saúde, quando atingidos os objetivos do tratamento<sup>5,22–24</sup> .  
Para que ocorram os benefícios relacionados ao início imediato da TARV o acesso oportuno a testagem é fundamental. A despeito de estratégias de testagem, o diagnóstico em estágios mais avançados da doença ainda é observado com frequência<sup>25</sup> .  
Os principais objetivos do tratamento são<sup>26–30</sup> :  
- Redução da morbimortalidade  
- Aumento na expectativa de vida  
- Redução da progressão da doença, evitando eventos definidores de aids  
- Redução de comorbidades (cardiovasculares, renais)  
- Redução na incidência de tuberculose  
- Recuperação da função imune  
- Supressão virológica duradoura  
- Melhora na qualidade de vida  
- Prevenção da transmissão  
**A TARV deve ser iniciada no mesmo dia ou em até 7 dias após o diagnóstico**  
As vantagens da TARV devem estar claras para a PVHA, e que após seu início, não deve ser interrompida. O acolhimento e o cuidado compartilhado pela equipe multidisciplinar é essencial e a abordagem individualizada deve ser estabelecida até que a pessoa esteja adaptada e familiarizada com seu tratamento.  
Os profissionais devem estar preparados para identificar barreiras estruturais e sociais que possam impactar na adesão ao tratamento e no cuidado contínuo, entre elas: estigma social, preconceito, racismo, insegurança alimentar, entre outras. Devem também ter tranquilidade em iniciar a TARV mesmo antes dos resultados de CD4 e CV.  
O acolhimento, o cuidado compartilhado e o início rápido da TARV favorecem a vinculação e a retenção do usuário ao serviço de saúde<sup>31,32</sup> , pilares centrais do cuidado contínuo às PVHA. Ademais, contribui para a obtenção da carga viral indetectável mais rapidamente, impactando na resposta imunológica, na morbidade, na mortalidade e na cadeia de transmissão do vírus, na resposta imunológica e na morbidade e mortalidade. Além disso, tem impacto no processo inflamatório crônico, reduzindo o risco de eventos clínicos e desfechos desfavoráveis<sup>33–43</sup> .  
Após a avaliação inicial, que inclui história clínica e exame físico criterioso, a TARV deve ser prescrita. Entre as PVHA com sinais e sintomas comprometendo o sistema nervoso central e na  
suspeita de IO como meningite tuberculosa e meningite criptocócica, o início da TARV deve ser postergado. As exceções são abordadas nos itens **4.9 e 4.10.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **INDETECTÁVEL = INTRANSMISSÍVEL (I = I)** -->
O uso de antirretrovirais (ARV) representa uma potente intervenção para a prevenção da transmissão do HIV<sup>44–55</sup> .  
A supressão da replicação viral reduz risco de novas transmissões. Os primeiros estudos que acompanharam casais sorodiferentes não identificaram transmissão do HIV por pessoas em tratamento com carga viral plasmática inferior a 200 cópias/mL por pelo menos 6 meses,<sup>23,62</sup> . Tais estudos fundaram o conceito de **“Indetectável = Intransmissível” (I=I) para transmissão sexual do HIV**<sup>54,56–61</sup> .  
Mais recentemente, uma revisão sistemática envolvendo 7.700 casais sorodiferentes de 25 países confirmou que o risco de transmissão sexual quando a carga viral é inferior a 200 cópias/mL é zero.<sup>54,56–61</sup> . Adicionalmente, a revisão evidenciou que o risco de transmissão do vírus é muito baixo quando a carga viral plasmática é inferior a 1.000 cópias/ml: apenas duas das 323 transmissões identificadas ocorreram no contexto de carga viral entre 200 e 1.000 cópias/mL.<sup>63</sup> Com base nessas evidências, a OMS enfatiza que PVHA que têm carga viral indetectável têm risco zero de transmitir HIV a seus parceiros sexuais<sup>64</sup> .  
Recentemente, foram publicados uma revisão sistemática e um guia da Organização Mundial da Saúde<sup>63,64</sup> que reiteram o conceito I=I. Nos estudos revisados não houve registro de transmissão sexual do HIV entre pessoas com carga viral inferior a 600 cópias/mL e duas possíveis transmissões, não confirmadas, com carga viral entre 600 e 1.000 cópias. Sendo assim, o risco de transmissão sexual a partir de PVHA com carga viral inferior a 1.000 cópias/ml é “quase” zero.  
**PVHA com carga viral indetectável têm risco zero de transmitir o HIV por via sexual.**  
O esclarecimento e a divulgação do conceito “Indetectável = Intransmissível” (I = I) é parte essencial do cuidado às PVHA. O conceito combate estigma e preconceito, afirma os direitos sexuais e reprodutivos e melhora a qualidade de vida das PVHA.  
Ao entrar em contato com o conceito I=I, é essencial que a PVHA compreenda a importância da adesão ao tratamento para obtenção da supressão viral máxima, isto é, a carga viral indetectável. A adesão subótima pode levar à supressão incompleta da replicação viral, emergência de mutações virais de resistência e transmissão do HIV, inclusive de vírus resistentes a antirretrovirais.  
**O manejo de condições que podem afetar a adesão ao tratamento, como depressão e uso de álcool ou substâncias psicoativas, é essencial para o sucesso do tratamento e a**  
**redução da transmissão.**  
Cada encontro com o paciente deve ser uma oportunidade de reforçar os benefícios da TARV para sua saúde e para prevenção da transmissão, assim como de gerenciar o risco de outras IST<sup>42,43</sup> . O profissional de saúde deve ativamente abordar as práticas seguras de sexo, recomendar o uso de preservativos e buscar detectar e tratar outras IST. Deve-se investigar e manejar o uso de álcool e outras substâncias psicoativas, reforçando, entretanto, que a TARV não deve ser interrompida, mesmo no contexto de uso ativo dessas substâncias.  
O impacto da boa adesão no sucesso do tratamento deve ser reforçado a cada encontro. A pessoa que por algum motivo não atingir a supressão viral deve ser informada sobre a efetividade do preservativo e de outros métodos de prevenção combinada disponíveis para sua parceria, tal como o uso da profilaxia pré-exposição (PrEP).  
O profissional de saúde deve auxiliar a PVHA no processo de revelação de sua condição sorológica à parceria sexual. Deve ficar claro à PVHA que períodos de má adesão e falha de tratamento representam riscos à parceria sorodiscordante e que idealmente tais informações devem ser compartilhadas com a parceria.  
O desejo reprodutivo deve ser abordado pelo profissional de saúde e, caso exista, acesso ao planejamento reprodutivo deve ser oferecido ao casal.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 4.2. **Início da TARV na coinfecção TB/HIV** -->
O início da TARV durante o tratamento da TB reduz a mortalidade, particularmente quando iniciada precocemente<sup>65–70</sup> .  
Revisão sistemática recente<sup>71</sup> mostrou que a introdução rápida da TARV em pessoas com coinfecção TB-HIV reduz a mortalidade em PVHA com CD4 ≤ 50 células/mm<sup>3</sup> , ainda que a síndrome inflamatória da reconstituição imune (SIRI) tenha sido mais frequente. A Organização Mundial de Saúde recomenda que a TARV seja iniciada em até 7 dias<sup>42,43</sup> .  
Existem poucos dados sobre o momento ideal para início da TARV na tuberculose meningoencefálica. Um ensaio clínico randomizado mostrou que o início precoce da TARV não alterou o prognóstico da doença, mas esteve relacionado à maior ocorrência de eventos adversos<sup>72</sup> . Contudo, este estudo apresenta várias limitações que questionam sua extrapolação para outros cenários<sup>73</sup> .  
Recomenda-se que, para PVHA e meningite tuberculosa, o início da TARV ocorra, preferencialmente, **entre a 4ª semana e a 6ª semana** do início do tratamento da tuberculose<sup>42</sup> . Nas situações em que seja possível acompanhamento frequente por especialistas para avaliação e controle da meningite tuberculosa, dos eventos adversos e desenvolvimento de SIRI, a introdução da TARV poderá ser mais precoce e ocorrer após duas semanas do início do tratamento da tuberculose - particularmente quando a contagem LT- CD4 estiver abaixo de 50 células/mm<sup>3</sup> . Por outro lado, nos locais em que há dificuldade para acessar serviços e profissionais especializados, o tempo pode ser estendido para até 8 semanas. **Em todos os casos de tuberculose em sistema nervoso central, está indicado o uso de corticoide, o que pode minimizar os efeitos da SIRI.**  
**O impacto na mortalidade alcançado pelo início precoce e oportuno da TARV supera o risco da SIRI, um fenômeno com variável de morte e passível de manejo na maioria dos casos**<sup>74,75</sup> **. O receio do desenvolvimento de SIRI não deve retardar o início da TARV, seu manejo é descrito mais adiante** .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 4.3. **Início da TARV na meningite criptocócica** -->
O início precoce da TARV na presença de meningite criptocócica pode aumentar a mortalidade<sup>76</sup> . Recomenda-se o **início da TARV entre 4 e 6 semanas após o início do tratamento antifúngico** , desde que tenha ocorrido melhora neurológica inequívoca, resolução da hipertensão intracraniana e cultura negativa para fungos no líquor, reduzindo assim o risco de desenvolver SIRI 77,78. Considerar que pacientes com criptococomas ou pseudocistos mucinosos devem receber, pelo menos, 6 semanas de tratamento de indução. Por outro lado, se o paciente não apresentar criptococomas ou pseudocistos mucinosos e apresentar controle da doença, mediante critérios clínicos, liquóricos e acompanhamento de especialistas, é possível o início da TARV antes das 4 – 6 semanas de tratamento da meningite criptocócica<sup>76–79</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 4.4. **Início da TARV em “controladores de elite”** -->
Um pequeno grupo de PVHA mantém CV-HIV não detectada (níveis plasmáticos abaixo do nível de quantificação) mesmo sem uso de TARV. Esses indivíduos são frequentemente chamados de “controladores de elite”<sup>80,81</sup> . Persistem incertezas quanto ao cuidados destes indivíduos<sup>82</sup> , mas o benefício do início da TARV está associado à redução da ativação inflamatória, reduzindo o risco de ocorrer progressão da doença. Caso opte-se por não iniciar TARV, deve ocorrer monitoramento clínico e laboratorial frequente.  
Recomenda-se o início da TARV, mesmo em controladores de elite e independentemente da contagem de LT-CD4+ **devido a** evidências de marcada ativação imune que aumenta o risco de desenvolver doenças não relacionadas à aids<sup>82–85</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **GENOTIPAGEM PRÉ-TRATAMENTO** -->
A indicação da genotipagem pré-tratamento baseia-se na custo-efetividade do teste, de acordo com a prevalência da resistência primária ou transmitida do HIV-1 na população<sup>86–88</sup> .  
A prevalência nacional de mutações de resistência primária aos inibidores da protease e à transcriptase reversa (análogos e não análogos de nucleosídeos/nucleotídeos) descrita foi de 9,5%. Ao considerar isoladamente os inibidores da transcriptase reversa não análogo de nucleosídeo (ITRNN), a prevalência nacional de mutações que conferem resistência a essa classe de antirretrovirais foi de 5,8%, variando de 4,5%, no Norte e Nordeste, a 7%, no Sul<sup>89</sup> , podendo ter uma variação ainda maior quando avaliados estudos isoladamente<sup>90–92</sup> .  
Outro aspecto importante a ser considerado é que a realização do exame de genotipagem requer um serviço especializado, associado à avaliação pós-teste por um médico referência em genotipagem (MRG). Esse profissional, então, indicará a recomendação terapêutica para cada paciente.  
Assim, recomenda-se a realização de **genotipagem pré-tratamento (em PVHA virgens de tratamento com TARV)** para:  
- **Pessoas que tenham se infectado com parceria em uso atual ou prévio de TARV** , uma vez que a possibilidade de detecção de mutações de resistência transmitida é mais provável nessa situação;  
- **Gestantes HIV** , para orientar o esquema terapêutico inicial se houver necessidade de mudança deste e obter dados epidemiológicos a respeito de resistência transmitida;  
- **Indivíduos vivendo com TB/HIV** , para orientar o esquema terapêutico inicial se houver necessidade de sua mudança (avaliação de resistência transmitida aos ARV do esquema inicial).  
- **Crianças e adolescentes,** no momento do diagnóstico para orientar o esquema terapêutirco inicial.  
- **Pessoas com soroconversão do HIV durante o uso de PrEP** , pela possibilidade de resistência transmitida ou adquirida a TDF/3TC.  
As indicações de genotipagem pré-tratamento estão resumidas no Quadro 3.  
**Quadro 3:** Indicações de genotipagem pré-tratamento  
|A genotipagem pré-tratamento está indicada nas seguintes situações:<br>•<br>Pessoas que tenham se infectado com parceria (atual ou pregresso) em uso de<br>TARV|
|---|
|•<br>Gestantes|
|•<br>Crianças e adolescente|
|•<br>Pessoas com história de uso de PrEP durante ou após o período de provável<br>infecção|
|CoinfecçãoTB/HIV|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **COMO INICIAR** -->
Todos os medicamentos disponíveis para terapia antirretroviral no SUS, seus esquemas de administração e observações sobre seu uso estão descritos no Apêndice A. Deve-se observar o uso apropriado de cada medicamento no algoritmo de tratamento dos pacientes.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 6.1. **Terapia antirretroviral inicial** -->
O esquema inicial para tratamento da infecção pelo HIV deve incluir três medicamentos antirretrovirais, sendo dois inibidores da transcriptase reversa análogos de nucleosídeo (ITRN) e um terceiro de outra classe: um inibidor da integrase (INI), um inibidor da protease potencializado com ritonavir (IP + RTV) ou um ITRNN. O esquema deve ser administrado em dose única diária.  
A associação de tenofovir e lamivudina (TDF/3TC) é a preferencial da classe dos ITRN, enquanto dolutegravir (DTG), darunavir 800 mg/dia potencializado por ritonavir 100 mg (DRV + RTV) e efavirenz (EFV) são, respectivamente, a escolha dentre os INI, IP + RTV e ITRNN (  
**Quadro 4** ).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **O esquema preferencial para início de tratamento é a associação de tenofovir com lamivudina e dolutegravir (TDF/3TC + DTG)** -->
**Quadro 4** : Esquema de terapia antirretroviral inicial para adultos  
|**Situação**|**Esquema antirretroviral**|
|---|---|
|Esquema preferencial|Tenofovir<sup>a</sup>/lamivudina +dolutegravir|
|Intolerância ou contraindicação a dolutegravir|Substituir dolutegravir por darunavir +<br>ritonavir<sup>b</sup> ou efavirenz<sup>c</sup>|
|Intolerância ou contraindicação a tenofovir<sup>d</sup>|Substituir tenofovir por abacavir<sup>e</sup>, se teste<br>HLA-B*5701 negativo, ou por zidovudina|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: Fonte:DATHI/SVSA/MS -->
TDF: tenofovir; 3TC: lamivudina; DTG: dolutegravir; DRV: darunavir; RTV: ritonavir; EFV: efavirenz; ABC: abacavir; AZT: zidovudina (a) Tenofovir é contraindicado em pacientes com doença renal pré-existente, disfunção renal aguda ou TFGe inferior a 60 mL/minuto. Deve ser usado com precaução em pacientes com osteoporose ou osteopenia, hipertensão arterial sistêmica e diabete melito não controladas. Nesses casos, monitorar e considerar alternativas após a estabilização do tratamento. (b) DRV+RTV: dose única diária de 800 mg de darunavir associado a 100 mg de ritonavir. (c) Como o risco de resistência transmitida a efavirenz é relevante no Brasil, esta opção deve ser considerada preferencialmente quando a carga viral ainda está detectável e há possibilidade de teste de genotipagem comprovando susceptibilidade ao medicamento. Entretanto, o início da TARV não deve ser postergado até a chegada do resultado. (d) No contexto de infecção ativa pelo HBV e contraindicação ao tenofovir, deve-se substituir tenofovir por outro fármaco ativo contra o vírus da hepatite B (tenofovir alafenamida). Consultar o PCDT de Hepatite B e coinfecções vigente.  
(e) Abacavir deve ser usado com precaução em pessoas com alto risco cardiovascular. A associação abacavir + lamivudina + efavirenz é contraindicada se a contagem viral estiver acima de 100.000 cópias/mL.  
Informações sobre o exame de tipificação do alelo HLA-B*5701 podem ser obtidas através do e-mail clab@aids.gov.br  
Para PVHA com contraindicação ou intolerância aos ITRN (tenofovir, abacavir e zidovudina), orienta-se consultar a câmara técnica estadual assessora no manejo de antirretrovirais.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 6.2. **TARV inicial para pessoas com TB/HIV** -->
Embora os princípios gerais da TARV sejam válidos para o contexto da coinfecção HIV e tuberculose (TB/HIV), existem particularidades importantes, sobretudo relacionadas a interações medicamentosas. Além disso, na coinfecção TB/HIV, há risco mais alto de má adesão ao tratamento, toxicidade medicamentosa e síndrome da reconstituição imune.  
Neste tópico são discutidos os esquemas antirretrovirais recomendados para o início de TARV em pessoas virgens de tratamento e com tuberculose causada por _M. tuberculosis_ multissensível. Os vários aspectos do manejo da tuberculose em PVHA em diferentes contextos são discutidos em detalhes no módulo 2 do PCDT para manejo das coinfecções e infecções oportunistas nas PVHA.  
As rifamicinas (rifampicina, rifabutina, rifapentina) são medicamentos-chave do tratamento para TB<sup>93</sup> . No entanto, apresentam interações significativas com vários medicamentos, incluindo alguns ARV. Este fato limita as opções terapêuticas de ARV para as PVHA com tuberculose. As interações farmacológicas mais significativas se referem à indução do metabolismo dos IP e de dolutegravir, que levam a redução das concentrações séricas desses ARV e risco de falha da TARV e resistência aos ARV.  
Devido ao intenso impacto do uso concomitante de rifampicina nos níveis séricos dos IP, todos medicamentos dessa classe são contraindicados para PVHA em uso de rifampicina<sup>93</sup> .  
Quanto ao dolutegravir, estudos farmacocinéticos demonstraram que o aumento da dose para 50 mg de 12/12h promove níveis séricos semelhantes aos obtidos com o uso de dolutegravir sem rifampicina, devendo a dose dobrada permanecer por mais duas semanas após o término do tratamento com a rifampicina<sup>94,95</sup> .  
Quanto ao efavirenz, a redução da dose causada pela rifampicina não tem impacto clínico. Estudos clínicos demonstram a segurança e eficácia no seu uso sem ajuste da dose para PVHA em uso concomitante de rifamicinas. Além disso, a disponibilidade de dose fixa combinada com tenofovir e lamivudina (no Brasil, a pílula “3 em 1”) é uma vantagem que favorece melhor adesão 96–100. Por outro lado, taxas elevadas de resistência a efavirenz pré-tratamento foram documentadas em vários países do mundo. Dados nacionais estimam alta prevalência de K103N (mutação para os ITRNN), variando de 3,4 a 5,5%<sup>89</sup> , podendo ser superior a 10%<sup>87,90–92</sup> . A OMS recomenda que países com estimativas de resistência antirretroviral pré-tratamento ao efavirenz de 10% ou mais evitem o uso de esquema contendo esse medicamento<sup>101</sup> .  
Considerando-se que o risco de resistência transmitida ao EFV é relevante no Brasil, a combinação tenofovir/lamivudina/efavirenz deixou de ser preferencial, mesmo no contexto da coinfecção TB/HIV. Entretanto, como no Brasil a genotipagem pré-tratamento está indicada no contexto de coinfecção TB/HIV, o esquema com EFV é uma alternativa em situações em que o teste de resistência é realizado. O início da TARV, entretanto, não deve ser postergado na espera do resultado. Em caso de resistência a qualquer ARV, o esquema deve ser modificado.  
As recomendações para início de TARV para pessoas em tratamento de tuberculose com rifampicina estão no Quadro 5.  
**Quadro 5:** Esquema de terapia antirretroviral inicial para adultos com tuberculose  
|**SITUAÇÃO**|**ESQUEMA ANTIRRETROVIRAL**|**OBSERVAÇÃO**|
|---|---|---|
|Coinfecção TB/HIV<br>•<br>Preferencial|Tenofovir 300 mg<sup>(a)</sup>/ Lamivudina 300<br>mg  “2 x 1” 1x/dia<br>+<br>Dolutegravir50mg12/12h|Após o término do tratamento<br>para TB, a dose dobrada de<br>dolutegravir, deve ser mantida<br>por 15 dias.|
|Coinfecção TB/HIV<sup>(a)</sup><br>•<br>Alternativo|Tenofovir 300 mg<sup>(a)</sup>/ Lamivudina 300<br>mg/ Efavirenz 600 mg<sup>(b)</sup><br>1x/dia|Após o término do tratamento<br>para TB, reavaliar a troca de<br>efavirenz por dolutegravir.|  
Fonte: DATHI/SVSA/MS.  
**Pela possibilidade de interações medicamentosas e de eventos adversos, pessoas coinfectadas TB-HIVrequerem consultas mais frequentes e regulares durante o tratamento da TB.**  
<u>Para mais informações sobre o tratamento da coinfecção TB/HIV, consultar o Módulo 2</u>  
- 6.3. **TARV em Mulheres Vivendo com HIV (MVHIV) que expressam desejo de engravidar**  
A recomendação da TARV para mulheres não se diferencia da recomendação geral, independente do desejo ou possibilidade de engravidar. A associação de tenofovir/lamivudina + dolutegravir é a preferencial.  
A escolha da TARV deve ser centrada na autonomia das mulheres, considerando-as como participantes ativas, oferecendo informações e opções para que elas possam tomar decisões fundamentadas. As escolhas terapêuticas devem ser feitas de forma compartilhada com a equipe de saúde, proporcionando a essas mulheres opções individualizadas e informadas a respeito do seu esquema ARV.  
As últimas evidências científicas não confirmam a associação do uso do DTG a defeitos do tubo neural<sup>102–107</sup> . O profissional de saúde deve fornecer as informações de segurança para uso dos ARV durante a gestação.  
Todas as mulheres que estejam planejando engravidar devem usar ácido fólico pelo menos 2 meses antes da gravidez e nos dois primeiros meses da gestação, como medida para evitar a ocorrência de defeito de tubo neural<sup>108,109</sup> .  
Para informações atualizadas e mais detalhes sobre TARV em gestantes, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV,  
Sífilis e Hepatites Virais”, disponível em: <u>https://www.gov.br/aids/pt-br/centrais-deconteudo/pcdts</u> ou https://www.gov.br/conitec/ptbr/midias/protocolos/20201113_pcdt_para_ptv_hiv_final.pdf.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 6.4. **Antirretrovirais disponíveis no Brasil para início de tratamento** -->
Além de eficácia, os principais critérios para seleção dos medicamentos do esquema ARV inicial são: boa tolerância, baixa toxicidade, possibilidade de dose única diária e de comprimidos coformulados. Idealmente o esquema deve estar ancorado em um medicamento que ofereça alta barreira à resistência viral (alta barreira genética), como o DTG ou a associação DRV + RTV, para os quais, na eventualidade de replicação viral e falha virológica, a emergência de mutações de resistência no genoma viral é incomum<sup>110,111</sup> .  
Todos os esquemas atualmente recomendados para início de tratamento no Brasil podem ser administrados em dose única diária. O **Quadro A** traz os antirretrovirais disponíveis, apresentação e posologia recomendada.  
As principais particularidades dos medicamentos recomendados para início de tratamento no Brasil são descritas a seguir:

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>ASSOCIAÇÃO TENOFOVIR / LAMIVUDINA (TDF/3TC):</u>** -->
- Classe: ITRN  
- Disponível em coformulação, na dose de 1 comprimido diário (300/300 mg)  
- Ativa contra o vírus da hepatite B<sup>112</sup> .  
• Comparada a zidovudina/lamivudina, apresenta um perfil favorável em termos de toxicidade, supressão virológica e resposta de LT-CD4+<sup>113,114</sup> . Em relação a associação abacavir e lamivudina, apresenta um perfil favorável quanto a eficácia virológica, em especial quando a CV é maior que100.000 cópias/mL<sup>115,116</sup> .  
- As principais toxicidades são renal e óssea<sup>117</sup> .  
- A toxicidade renal se dá por dano tubular proximal e ocorre sobretudo com o uso  
- concomitante de medicamentos nefrotóxicos, em pessoas de baixo peso, especialmente mulheres, no contexto de doença renal prévia ou doença pelo HIV avançada e em pessoas com alto risco renal, como diabéticos, hipertensos, negros e idosos<sup>117–120</sup> . Em pessoas sem esses fatores de risco, disfunção renal grave é muito rara.  
- Diminuição da massa óssea foi associada ao uso de tenofovir em diversos estudos.  
- Tal efeito pode contribuir para risco aumentado de osteopenia, osteoporose e fraturas<sup>117–</sup> 121.  
**Tenofovir/lamivudina é a associação de ITRN preferencial em geral e a única recomendada para coinfecção HIV-HBV**  
O tenofovir é um análogo de nucleotídeo (ITRNt) e sua maior desvantagem é a nefrotoxicidade, particularmente em diabéticos, hipertensos, negros, idosos, pessoas com baixo peso corporal (especialmente mulheres), doença pelo HIV avançada ou insuficiência renal préexistente e no uso concomitante de outros medicamentos nefrotóxicos<sup>117,118,122–124</sup> .  Novo aparecimento ou agravamento da insuficiência renal tem sido associado ao uso de tenofovir<sup>125,126</sup> . Porém, disfunções graves são muito raras<sup>119,127</sup> . Pacientes com doença renal preexistente devem usar preferencialmente outra associação de ITRN.  
A diminuição da densidade óssea tem sido relacionada ao uso de tenofovir<sup>120,128</sup> .  
Dados sobre o uso do tenofovir durante o primeiro trimestre de gestação não demonstraram aumento em defeitos congênitos quando em comparação com a população geral. Além disso, esse ARV é bem tolerado durante a gestação<sup>129,130</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>ASSOCIAÇÃO ABACAVIR + LAMIVUDINA (ABC +3TC):</u>** -->
- Classe: ITRN  
- Por não estar disponível em coformulação no Brasil, a associação resulta em 4  
- comprimidos diários a serem associados a um terceiro medicamento. O comprimido de abacavir tem 300 mg e o de lamivudina 150 mg.  
- Por ser contraindicada a portadores do alelo HLA B*5701, seu uso pressupõe a  
- realização de teste de detecção desse alelo.  
- Em combinação com efavirenz ou atazanavir/ritonavir, foi inferior em eficácia a  
- zidovudina/lamivudina para PVHA com carga viral acima de 100.000 cópias/mL<sup>131,132</sup> .  
- Reações de hipersensibilidade, inclusive formas graves, foram relacionadas ao  
- início do tratamento com abavacir, especialmente no contexto de reexposição ao medicamento, podendo ocorrer em até 50% dos pacientes positivos para o HLA-B*5701 133–135.  
- A exposição recente a abacavir (durante os primeiros seis meses de uso) foi  
- associada a aumento do risco de eventos cardiovasculares e, portanto,  deve ser evitado em pessoas com risco cardiovascular elevado<sup>135–138</sup> .  
<u><mark>O abacavir não deve ser administrado a pacientes com resultado positivo para HLA-B*5701.</mark></u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>ASSOCIAÇÃO DE ZIDOVUDINA/LAMIVUDINA (AZT/3TC):</u>** -->
- Classe: ITRN  
- Disponível em coformulação, na dose de 1 comprimido (300/150 mg) a cada 12  
- horas.  
- Causa mais frequentemente intolerância gastrintestinal que as combinações com  
- tenofovir ou abacavir.  
- Zidovudina é o ITRN com maior toxicidade mitocondrial, que pode se manifestar  
- como mielotoxicidade (mais comumente anemia), acidose metabólica ou lipoatrofia (perda de gordura subcutânea, especialmente em glúteos e membros inferiores)<sup>139</sup> .  
• Zidovudina deve ser evitado se a dosagem de hemoglobina for inferior a 10 g/dL ou de neutrófilos, inferior 1.000 células/mm<sup>3</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>DOLUTEGRAVIR (DTG):</u>** -->
- Classe: INI  
- Registrado de forma isolada e em coformulação com outros antirretrovirais no  
- Brasil; a dose é de 1 comprimido de 50 mg uma vez ao dia.  
- Tem alta potência e promove queda mais rápida da carga viral que os ARV de  
- outras classes. Compõe esquemas ARV de alta eficácia.  
- Oferece alta barreira genética à resistência viral, isto é, na eventualidade de falha  
- virológica, a emergência de mutações virais de resistência a dolutegravir é incomum<sup>140–144</sup> .  
- Bem tolerado, a frequência de eventos adversos é baixa. Cefaleia e insônia podem  
- ocorrer, mas não são comuns. A necessidade de descontinuação por eventos adversos graves é muito rara<sup>140–144</sup> .  
• Devido à inibição do transportador de cátions orgânicos tipo 2 (OCT2) nos túbulos renais proximais, dolutegravir diminui a secreção tubular de creatinina e pode, nas primeiras quatro semanas de uso, levar a aumento da creatinina sérica e consequente redução de 10 a 15% na taxa de filtração glomerular estimada. Esse aumento não representa nefrotoxicidade e não tem relevância clínica, já que não há alteração concomitante da função renal medida diretamente com métodos precisos, como o teste de inulina, padrãoouro para avaliar filtração glomerular. Dolutegravir não é contraindicado na insuficiência renal<sup>144</sup> .  
- Comparado a efavirenz, dolutegravir promoveu maior ganho de peso após o início  
- da TARV, especialmente se combinado com tenofovir alafenamida e em mulheres negras 145. Embora a relação entre ganho de peso e diferentes ARV precise ser mais bem caracterizada<sup>146</sup> , recomenda-se particular atenção ao ganho de peso após o início de DTG.  
- O aumento de risco de eventos cardiovasculares observado nos primeiros dois anos  
- de uso de INI na coorte RESPOND<sup>147</sup> , não foi confirmado na coorte suíça. Nesse estudo mais recente foram incluídos apenas pessoas em início de TARV e, após controle para fatores de risco cardiovasculares tradicionais e relacionados ao HIV, a incidência cumulativa de eventos cardiovasculares não foi diferente entre os usuários de dolutegravir e os de outros ARV<sup>148</sup> .  
- As seguintes interações medicamentosas são relevantes<sup>149</sup> :  
- Dolutegravir é contraindicado com oxcarbamazepina, dofetilida e pilsicainida.  
`o` Para PVHA em uso de carbamazepina, fenitoína ou fenobarbital, e que não possam substituí-los ou interrompê-los, o dolutegravir poderá ser associado na posologia 50 mg 2x/dia (50 mg de 12/12h).  
`o` Recomenda-se que o dolutegravir seja administrado duas horas antes ou seis horas depois que medicamentos contendo cátions polivalentes, como antiácidos com alumínio ou magnésio, e polivitamínicos, Suplementos de cálcio ou ferro, quando acompanhado de alimentos podem ser administrados concomitantemente a dolutegravir.  
`o` Dolutegravir aumenta a concentração plasmática da metformina, portanto a administração concomitante requer monitorização dos efeitos adversos da última, sobretudo em pessoas com disfunção renal. Ao se iniciar o uso de dolutegravir, sugerese reduzir a dose máxima diária de metformina para 1.000 mg. Ao se descontinuar dolutegravir, pode ser necessário um aumento da dose de metformina.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>DARUNAVIR 800 MG + RITONAVIR 100 MG (DRV 800 MG + RTV 100 MG)</u>** -->
- Classe: IP  
- Darunavir deve ser usado sempre em combinação com 100 mg de ritonavir, que  
- age como potencializador farmacológico.  
• A apresentação de 800 mg é a indicada para esquemas iniciais, pois se pressupõe ausência de mutações de resistência a darunavir. Dose única diária de 800 mg de darunavir e 100 mg de ritonavir<sup>150</sup> .  
- Não disponível em coformulação.  
- Tem alta potência e compõe esquemas ARV de alta eficácia<sup>150,151</sup> .  
- Oferece alta barreira genética à resistência viral, isto é, na eventualidade de falha  
- virológica, a emergência de mutações virais de resistência a darunavir é incomum<sup>150,151</sup> .  
• Intolerância gastrointestinal, incluindo diarreia, e dislipidemia são efeitos adversos comuns. A exposição cumulativa de darunavir foi associada a um aumento de risco de eventos cardiovasculares em estudos observacionais<sup>150–153</sup> .  
• Darunavir e ritonavir são substratos, indutores e inibidores de enzimas microssomais, o que implica em inúmeras interações medicamentosas de relevância clínica 149.  
`o` Entre outros, são contraindicados para uso concomitante com darunavir: rifampicina, alfuzosina, cisaprida, lurasidona, sinvastatina, astemizol, terfenadina e alfuzosina.  
`o` Ajuste de dose de medicamentos concomitantes podem ser necessários. Portanto, antes da introdução de qualquer comedicação, é imperioso consultar a possibilidade de interações medicamentosas.  
• A apresentação de darunavir 800 mg não é recomendada para gestantes devido a redução do nível sérico de darunavir a partir do segundo trimestre. A dose é de 600 mg em associação com 100 mg de ritonavir de 12em 12 horas deve ser usada durante a gestação<sup>153</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **<u>EFAVIRENZ (EFV):</u>** -->
- Classe: ITRNN  
- Disponível em coformulação com tenofovir/lamivudina, tem a posologia  
- confortável de um comprimido ao dia para o esquema completo.  
- Associado a dois ITRN plenamente ativos, compõe esquemas antirretrovirais com  
- alta eficácia para terapia inicial<sup>114,115</sup> .  
• Efavirenz, comparado a lopinavir/ritonavir em esquema inicial, apresentou maior efetividade e durabilidade da supressão viral, atribuídas à comodidade posológica, boa tolerância e às maiores taxas de adesão ao tratamento em longo prazo. Por outro lado, efavirenz foi inferior a dolutegravir após 48 semanas e a raltegravir após 4 e 5 anos de tratamento. A diferença nesses dois estudos foi atribuída a maior descontinuidade por eventos adversos nos grupos com efavirenz<sup>114,115</sup> .  
• Tem baixa barreira genética à resistência viral, isto é, emergência rápida de resistência ocorre em períodos de má adesão e replicação viral<sup>92</sup> . Resistência completa a todos ITRNN de primeira geração pode ocorrer com apenas uma única mutação para a classe<sup>154</sup> . Além disso, alta prevalência de resistência em pacientes virgens de tratamento (resistência primária) foi demonstrada em várias regiões do mundo, inclusive no Brasil. 87,89–91,100,101,155  
• Efeitos adversos neuropsiquiátricos são comuns, atingindo até 50% das pessoas no início do tratamento. Tonturas, alterações do sono, sonhos bizarros e alucinações costumam ser de leve a moderada intensidade e tendem a arrefecer após as primeiras duas a quatro semanas de uso. Distimia e sintomas depressivos podem permanecer de forma sutil durante todo o tratamento. Aumento do risco de suicídio, sobretudo em pessoas com histórico de afecções psiquiátricas, foi identificado em alguns estudos. Efavirenz deve ser evitado em pessoas com depressão ou que necessitam permanecer em vigília durante a noite. Para minimizar a percepção dos efeitos adversos, recomenda-se a tomada do esquema com efavirenz à noite, antes de dormir e, preferencialmente, com o estômago vazio, duas horas após o jantar<sup>156</sup> .  
• Efavirenz é substrato e indutor de algumas isoenzimas microssomais, o que implica em potenciais interações medicamentosas. À prescrição de efavirenz e comedicações, devese consultar a possibilidade de interações farmacológicas e a necessidade de ajuste de doses 149.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 7.1. **Periodicidade das consultas para as PVHA** -->
A periodicidade das consultas médicas deve ser individualizada e adequar-se às condições clínicas da PVHA. No geral, os intervalos recomendados são descritos no Quadro 6.  
**Quadro 6** : Recomendação de periodicidade de consultas médicas  
|**SITUAÇÃO**|**INTERVALO**<br>**DE**<br>**RETORNO**<sup>**(a)**</sup>|**OBJETIVOS PRINCIPAIS**|
|---|---|---|
|Após introdução ou<br>alteração da TARV|Entre 7 e 15<br>dias|Observar e manejar eventos adversos imediatos e<br>dificuldades relacionadas à adesão.<br>Fortalecer vínculo com equipe e serviço de saúde.<br>Essa consulta pode ser realizada por profissionais da<br>enfermagem, farmacêuticos clínicos ou outras abordagens<br>ofertadas pelo serviço.|
|Até<br>adaptação<br>à<br>TARV|Mensal/<br>bimestral|Observar e manejar eventos adversos tardios e<br>dificuldades relacionadas à adesão em longo prazo.<br>Fortalecer vínculo com equipe e serviço de saúde.|
|PVHA em TARV<br>com supressão viral<br>e assintomática|Até 6 meses|Observar e manejar eventos adversos tardios e<br>dificuldades relacionadas à adesão em longo prazo.<br>Avaliar manutenção da supressão viral e eventual falha<br>virológica.<br>Manejar comorbidades.|
|PVHA em TARV<br>sem supressão viral,<br>sintomática ou com<br>comorbidades não<br>controladas|Individualizar|Avaliar falhas na adesão e seus motivos.<br>Verificar possibilidade de resistência(s) viral(is) à TARV<br>e necessidade de troca.<br>Avaliar e investigar sintomas.<br>Manejarcomorbidadesnão controladas.|  
Fonte: DATHI/SVSA/MS.  
(a) Nos intervalos entre as consultas médicas, a adesão deverá ser trabalhada por outros profissionais da equipe multiprofissional.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 7.2. **Monitoramento laboratorial da infecção pelo HIV** -->
O histórico de exames de LT-CD4+ e CV-HIV, bem como o histórico de dispensação de TARV e resultados de genotipagens realizadas, podem ser acessados na plataforma <u>https://laudo.aids.gov.br/ pelos profissionais cadastrados.</u>  
A contagem de LT-CD4+ tem importância na avaliação inicial, enquanto a CV-HIV é considerada o padrão-ouro para monitorar a eficácia da TARV e detectar precocemente problemas de adesão em PVHA.  
**7.2.1. Contagem de linfócitos T – CD4 + (LT-CD4)**  
A contagem de LT-CD4+ é um dos biomarcadores mais importantes para avaliar o grau de comprometimento do sistema imune, a indicação das imunizações e das profilaxias para IO. Por isso, é necessária sua realização periódica, conforme Quadro 7.  
**Quadro 7** : Recomendação de periodicidade para monitoramento laboratorial de exame de LT-CD4+  
|**SITUAÇÃO CLÍNICA**|**CONTAGEM DE LT-CD4+**|**FREQUÊNCIA**<br>**SOLICITAÇÃO**|**DE**|
|---|---|---|---|
||Abaixo de 350 células/mm³|A cada 6 meses||
|Em uso de TARV; e<br>Assintomática; e<br>Com cara viral indetectável|Entre<br>350<br>células/mm³<br>e<br>500<br>células/mm³|Anualmente||
|g|Acima de 500 células/mm³ em dois<br>exames consecutivos, com pelo<br>menos 6 meses de intervalo|Não solicitar||
|Sem uso de TARV; ou<br>Evento clínico<sup>(a)</sup>; ou<br>Em falha virológica|Qualquer valor|A cada 6 meses||
|Profilaxia ou presença de IO|Qualquer valor|A cada 3 meses||  
Fonte: DATHI/SVSA/MS.  
(a): Toxicidade e possíveis causas de linfopenias (neoplasias, uso de interferon etc.).  
Alguns fatores podem influenciar na contagem absoluta de LT-CD4+. Pessoas esplenectomizadas ou uma parcela dos coinfectadas com vírus T-linfotrópico humano (HTLV) podem apresentar um valor absoluto superestimado. Nesses casos, a porcentagem permanece estável e deve ser o parâmetro avaliado. Flutuações laboratoriais e fisiológicas de LT-CD4+ não têm relevância clínica.  
Para pessoas em TARV, com CV-HIV indetectável e contagem de LT-CD4+ acima de 350 células/mm<sup>3</sup> , a realização do exame de LT-CD4+ para monitoramento não é mais necessária<sup>157,158</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 7.3. **Carga viral do HIV (CV-HIV)** -->
Para PVHA em uso de TARV, o foco do monitoramento laboratorial deve ser a CV-HIV para avaliar a eficácia do tratamento e detectar precocemente a falha virológica, caracterizada por dois exames sequenciais de CV-HIV detectáveis. A periodicidade de realização do exame é descrita no Quadro 8.  
**Quadro 8** : Recomendação de periodicidade para monitoramento laboratorial de exame de CV-HIV  
|**SITUAÇÃO CLÍNICA**|**FREQUÊNCIA**<br>**SOLICITAÇÃO**|**DE**|**PRINCIPAIS OBJETIVOS**|
|---|---|---|---|
|PVHA em supressão viral e<br>estabilidade<br>clínica<br>e<br>imunológica|A cada 6 meses||Confirmar continuidade da supressão<br>viral e adesão do paciente|
|Início<br>de<br>TARV<br>ou<br>modificação de TARV por|Após 8 semanas<br>início de TARV ou|do<br>de|Confirmar<br>resposta<br>virológica<br>adequada à TARV ou ao novo esquema|
|<br>falha virológica|novo esquemaTAR|V|<br>deTARV e adesão do paciente|
|Confirmação<br>de<br>falha<br>virológica|Após 4 semanas<br>primeira<br>CV-<br>detectável|da<br>HIV|Confirmar<br>falha<br>virológica<br>e<br>necessidade de solicitação de exame de<br>genotipagem|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 7.4. **Exames e avaliações complementares no seguimento clínico** -->
A realização de exames complementares para seguimento do paciente é necessária e sua frequência dependerá da condição clínica e uso de TARV. A periodicidade de realização dos exames complementares é descrita no  
**Quadro 9** .  
**Quadro 9:** Recomendação de periodicidade de exames e avaliações complementares no seguimento clínico  
|**EXAME**|**PRÉ-**<br>**TARV**|**SEGUIMENTO**|**OBSERVAÇÃO**<sup>**(a)**</sup>|
|---|---|---|---|
|**Hemograma**<br>**completo**|Sim|6-12 meses|Repetir em 2 a 8 semanas se início<br>ou troca de TARV com zidovudina<br>Intervalo de 3 a 6 meses se em uso<br>de<br>zidovudina<br>ou<br>outros<br>medicamentosmielotóxicos|
|**Creatinina sérica e**<br>**Taxa**<br>**de**<br>**Filtração**<br>**Glomerular estimada**<br>**(TFGe)**<sup>**(b)**</sup>|Sim|Anual|Intervalo de 3 a 6 meses se em uso<br>de<br>tenofovir<br>ou<br>outros<br>medicamentos nefrotóxicos, TFGe<br>abaixo de 60 mL/minuto ou risco<br>aumentado para doença renal (ex.:<br>diabetes,hipertensão)|
|**Exame**<br>**básico**<br>**de**<br>**urina**|Sim|Anual|Intervalo de 3 a 6 meses se em uso<br>de<br>tenofovir<br>ou<br>outros<br>medicamentos nefrotóxicos, TFGe<br>abaixo<br>de<br>60<br>mL/minuto,<br>proteinúria ou risco aumentado para<br>doença<br>renal<br>(ex.:<br>diabetes,<br>hipertensão)|  
|**EXAME**|**PRÉ-**<br>**TARV**|**SEGUIMENTO**|**OBSERVAÇÃO**<sup>**(a)**</sup>|
|---|---|---|---|
|**AST, ALT, FA, BT e**<br>**Frações**|Sim|3-12 meses|Intervalos mais frequentes em caso<br>de<br>uso<br>de<br>medicamentos<br>hepatotóxicos, doença hepática ou<br>coinfecções com HCV ouHBV|
|**CT,**<br>**LDL,**<br>**HDL,**<br>**VLDLe TGL**|Sim|Anual|Intervalo de 6 meses em caso de<br>alteraçãonaúltima análise|
|**Glicemia de jejum**<sup>**(c)**</sup>|Sim|Anual|Considerar teste de tolerância à<br>glicose caso o resultado da glicemia<br>de jejum esteja entre 100 e<br>125mg/dL|
|**PT** **ou IGRA**|Sim|Anual, se exame inicial <<br>5 mm ou negativo|Iniciar tratamento para infecção<br>latente quando PT ≥ 5 mm ou IGRA<br>positivo e excluídaTBativa|
|**Teste**<br>**imunológico**<br>**para sífilis**<sup>**(d)**</sup>|Sim|Semestral/conforme<br>indicação|Considerar maior frequência de<br>triagem em caso de risco ou<br>exposição|
|**Anti-HCV**|Sim|Anual/conforme<br>indicação|Considerar maior frequência de<br>triagem em caso de risco ou<br>exposição<br>Solicitar carga viral de HCV se anti-<br>HCV positivo ou em caso de<br>suspeita deinfecção aguda|
|**Triagem**<br>**HBV**<br>**(HBsAg e anti-HBc**<br>**total)**|Sim|Avaliação inicial|Considerar maior frequência de<br>triagem em caso de risco ou<br>exposição<br>Vacinar pessoas não imunizadas<br>Pessoas<br>imunizadas<br>(anti-HBs<br>reagentes) não necessitam nova|
||||<br>triagemparaHBV|
|**Escores de risco**||||
|**Escore**<br>**de**<br>**risco**|||Recomenda-se que seja reavaliado a|
|**cardiovascular para**<br>**avaliação**<br>**do**<br>**risco**|Sim|Anual|<br>cada mudança de TARV e de forma<br>mais frequente de acordo com o|
|<br>**cardiovascular**|||<br>riscoinicial.|
|**FRAX para avaliação**<br>**do risco de fraturas**|Homens<br>PVHA c|com mais de 40 anos e<br>om alto risco de fratura de fr|mulheres com mais de 40 anos;<br>agilidade.|
|Fonte: DATHI/SVSA/M|S.|||
|(a)<br>Alterações<br>(b) Consultarhttp://arqui<br>quando<br>(c) A dosagem de hem|l<br>vos.sbn.o<br>oglobina|aboratoriais<br>devem<br>rg.br/equacoes/link/RFG.htm<br>necessário:<br>glicada (Hb1Ac) não deve|<br>ser<br>investigadas.<br> . Avaliar a coleta de outros exames<br>fósforo<br>ser utilizada como parâmetro para|
|diagnóstico|de|diabetes|em<br>PVHA|
|(d)<br>Consultar<br>o<br>“M<br>hhttps://www.gov.br/aid|anual<br>T<br>s/pt-br/ce|écnico<br>para<br>Diagnóstic<br>ntrais-de-conteudo.|o<br>da<br>Sífilis”,<br>disponível<br>em|  
7.5. **Rastreamento e detecção precoce das neoplasias**  
O Quadro 10 resume as principais recomendações para rastreio e detecção precoce frequentemente encontradas.  
**Quadro 10:** Rastreamento das neoplasias  
|**LOCAL**|**PACIENTES**|**PROCEDIMENTO**|**FREQUÊNCIA**|
|---|---|---|---|
|**Mama**|Mulheres entre 50 e 69<br>anos|Mamografia|Bianual|
||||Realizar o primeiro exame<br>logo após início da atividade<br>sexual;<br>Periodicidade anual após|
|**Colo**<br>**uterino**|Mulheres|Preventivo do câncer do<br>colo do útero|dois<br>exames<br>normais<br>consecutivos realizados com<br>intervalo semestral.<br>Realizar<br>colposcopia<br>na<br>presença<br>de<br>alterações<br>patológicas|
|**Ânus**|Relação receptiva anal,<br>antecedente<br>de<br>HPV,<br>histologia<br>vulvar<br>ou<br>cervical anormal|Toque retal|Anual; realizar anuscopia na<br>presença<br>de<br>alterações<br>patológicas|
|**Fígado**|Pacientes<br>cirróticos<br>e<br>portadores de HBsAg<br>positivos|Dosagem<br>de<br>alfa-<br>fetoproteína e realização<br>de ultrassom|Semestral|  
Fonte: DATHI/SVSA/MS.  
Como ainda não foi publicada uma diretriz nacional para rastreamento de neoplasia de pulmão, os serviços devem trabalhar na perspectiva de redução do risco, com a diminuição do tabagismo<sup>159</sup> .  
Para detecção precoce dos cânceres de cólon e reto, orienta-se seguir as recomendações do INCA, conforme livro _Detecção Precoce do Câncer_ .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **IMUNIZAÇÕES** -->
Adultos e adolescentes vivendo com HIV podem receber todas as vacinas do calendário nacional, desde que não apresentem deficiência imunológica importante. À medida que aumenta a imunodepressão, eleva-se também o risco relacionado à administração de vacinas de agentes vivos, bem como se reduz a possibilidade de resposta imunológica consistente<sup>160–162</sup> .  
Sempre que possível, deve-se adiar a administração de vacinas em pacientes sintomáticos ou com imunodeficiência grave (contagem de LT-CD4+ abaixo de 200 células/mm<sup>3</sup> ), até que um grau satisfatório de reconstituição imune seja obtido com o uso de TARV, o que proporciona melhora na resposta vacinal e redução do risco de complicações pós-vacinais.  
A administração de vacinas com vírus vivos atenuados (varicela, rubéola, febre amarela, sarampo e caxumba) em pessoas com imunodeficiência está condicionada à análise individual de risco-benefício e não deve ser realizada em casos de imunodepressão grave. Em PVHA com  
contagem de LT-CD4+ acima de 200 células/mm<sup>3</sup> há pelo menos seis meses, pode ser considerado o uso de vacinas vivas, de acordo com a recomendação do Quadro 11  
**Quadro 11:** Categorias imunológicas em pessoas vivendo com HIV  
|**CONTAGEM**<br>**DE**<br>**LT-CD4+**|**RECOMENDAÇÃO PARA USO DE VACINAS**|
|---|---|
|**(PERCENTUAL) ***|**COM AGENTES VIVOS ATENUADOS**|
|Maiorouiguala 350 células/mm<sup>3</sup>|Indicaro uso|
|200 a 350 células/mm<sup>3</sup>(15%-19%)|Avaliar parâmetros clínicos e risco epidemiológico<br>para a tomada de decisão|
|Abaixo de200 células/mm<sup>3</sup> (<15%)|Não vacinar|  
Fonte: DATHI/SVSA/MS.  
*A ser avaliada nas vacinas com microorganismos vivos.  
O Quadro 12 aborda o esquema vacinal básico para adultos e adolescentes vivendo com HIV.  
**Quadro 12** : Esquema vacinal para adultos vivendo com HIV  
|**VACINA**|**Composição**<br>**(agente)**|**RECOMENDAÇÃO**|
|---|---|---|
|**Tríplice**<br>**viral**<br>**(SRC)**<sup>**(a)**</sup>|Vivo atenuado|Duas doses para qualquer idade observando a<br>categoria imunológica(quadro 8).|
|**Varicela (VZ)**<sup>**(a) (b)**</sup>|Vivo atenuado|Duas doses com intervalo de três meses em<br>suscetíveis<sup>(a)</sup>, com LT-CD4+ acima de 200<br>células/mm<sup>3</sup>hápelo menos 6 meses.|
|**Febre amarela (FA)**|Vivo atenuado|Individualizar o risco/benefício conforme a<br>condição imunológica do paciente e a situação<br>epidemiológica da região. Vacinar quando LT-<br>CD4+ acima de 200 células/mm<sup>3</sup>há pelo menos 6<br>meses.<br>Contraindicada em gestantes – avaliar risco<br>benefício<br>de<br>acordo<br>com<br>a<br>situação<br>epidemiológica.|
|**Dupla do tipo adulto**<br>**(dT)**|Toxoide|Três doses (0, 2, 4 meses) e reforço a cada 10 anos.<br>Gestantes: Uma ou duas doses a qualquer momento<br>da gestação se vacinação incompleta do tétano e<br>difteria.|
|**dTpa**|Toxoide|Gestantes: aplicar uma dose de dTpa a cada<br>gestação a partir da 20a semana, independente de<br>vacinação anterior|
|**_Haemophilus_**<br>**_influenzae_**<br>**tipo**<br>**b**<br>**(Hib)**|Conjugada|Duas doses com intervalo de 8 a 12 semanas,<br>independentemente da idade|  
|**VACINA**|**Composição**<br>**(agente)**|**RECOMENDAÇÃO**|
|---|---|---|
|**Hepatite A**|Inativado|Duas doses, com intervalo de 6 a 12 meses, em<br>indivíduos suscetíveis à hepatite A (anti-HAV não<br>reagente).|
|**Hepatite B**|Subunidade|Dose dobrada recomendada pelo fabricante,<br>administrada em quatro doses (0, 1, 2 e 6 a 12<br>meses) em todos os indivíduos suscetíveis à<br>hepatite B (HBsAg não reagente, anti-HBc total<br>não reagente,anti-HBs não reagente).|
|**Pneumo 13 (VPC13)**|Polissacarídeo<br>Conjugado|Uma dose. Após intervalo de 2 meses, aplicar<br>pneumo 23. No caso de vacinação anterior com<br>pneumo 23, aplicar uma dose de pneumo 13 com<br>intervalo de 12 meses entre as vacinas.|
|**_Streptococcus_**<br>**_pneumoniae_**<br>**(23-**<br>**valente)**|Polissacarídeo|Duas doses com intervalo de cinco anos,<br>independentemente da idade. Observar um ano de<br>intervalo entre apneumo 23 e apneumo 13.|
|**Vacina**<br>**influenza**<br>**inativada(INF3): **|Inativado|Uma dose anual da vacina inativada contra o vírus<br>influenza.|
|**Vacina**<br>**papilomavírus**<br>**humano 6, 11, 16 e**<br>**18 (recombinante) –**<br>**HPV**<br>**quadrivalente**<sup>**(a)**</sup>|VPL:<br>Partículas<br>“vírus-like”|Três doses (0, 2 e 6 meses)<br>- Mulheres e homens de 9 a 45 anos.|
|**Vacina**<br>**meningocócica C**|Oligossacarídeo<br>Conjugada|2 doses com intervalo de 8 a 12 semanas; revacinar<br>após 5 anos.|
|**MenACWY**||Duas doses com intervalo de 8 a 12 semanas e<br>revacinar a cada 5 anos.|  
Fonte: SVSA/MS.  
A imunogenicidade e a eficácia da vacina contra hepatite B são inferiores em pacientes imunodeprimidos em relação aos imunocompetentes. Por esse motivo, **quatro doses de vacina contra hepatite B, com o dobro da dose habitual** , são necessárias à indução de anticorpos em níveis protetores<sup>112</sup> .  
A sorologia (anti-HBs) após esquema completo da vacina HBV está recomendada para PVHA um a dois meses após a última dose do esquema vacinal. Resposta satisfatória à vacina é observada quando os títulos de anti-HBs são maiores que 10 mUI/L.  
Para mais informações complementares referentes à vacinação consultar o Manual de Centros Imunobiológicos Especiais vigente.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **FALHA AO TRATAMENTO ANTIRRETROVIRAL** -->
Na última década, diversos avanços em terapia antirretroviral (TARV) resultaram em um aumento progressivo das taxas de resposta no tratamento da infecção pelo HIV. Com os esquemas antirretrovirais modernos, mais de 80% dos pacientes apresentam carga viral inferior a 50 cópias/mL após um ano de tratamento e a maior parte mantém a supressão viral nos anos seguintes<sup>163</sup> . Para a fração de pacientes que apresenta falha ao tratamento inicial, novas estratégias para terapia de resgate têm sido testadas com resultados de eficácia e durabilidade igualmente animadores. Esquemas de resgates mais simples e bem tolerados possibilitam atualmente taxas de supressão viral elevadas, mesmo na presença de resistência viral<sup>164–171</sup> .  
O sucesso da terapia de resgate depende da escolha cuidadosa dos medicamentos e da estratégia para compor o novo esquema. O reconhecimento precoce da falha virológica e a introdução oportuna do novo esquema antirretroviral são fundamentais para evitar a progressão da doença e o acúmulo de mutações de resistência viral, com consequente perda de opções terapêuticas.  
**O manejo precoce da falha virológica reduz o risco de progressão da imunodeficiência e preserva opções terapêuticas.**

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.1. **Caracterização da falha de tratamento** -->
Caracteriza-se como falha do tratamento antirretroviral a ausência de supressão viral após seis meses de TARV ou rebote da replicação viral após um período de supressão<sup>172</sup> .  
Os testes moleculares padrão mais comumente utilizados para quantificação de RNA viral no plasma têm limites de detecção entre 20 e 50 cópias/mL. Na vigência de supressão viral, os resultados são expressos como “inferior ao limite mínimo”, quando um número muito pequeno, não quantificável de cópias virais é detectado, ou como “não detectado”, quando nenhum RNA viral é detectado. Para fins clínicos, qualquer dos dois resultados indica supressão viral satisfatória e sucesso do esquema ARV vigente<sup>172</sup> .  
Define-se como falha virológica o resultado confirmado de carga viral (CV-HIV) superior a 200 cópias/mL<sup>172</sup> .  
A detecção esporádica de viremia baixa (inferior a 200 cópias/mL) representa, na maior parte dos casos, replicação de vírus selvagens a partir de células latentes infectadas (reservatórios virais). Replicação transitória, com uma medida isolada de CV-HIV detectável em níveis baixos entre medidas com CV-HIV não detectada é definida usualmente como “blip” e não representa falha virológica. “Blips”, em geral, não estão associados a falha subsequente<sup>173</sup> . Por outro lado, viremia baixa persistente pode refletir emergência de resistência e prenunciar falha da TARV<sup>174,175</sup> . Supressão viral parcial, isto é replicação viral na vigência de TARV, leva a acúmulo progressivo  
|**Definição de falha virológica**|
|---|
|Carga viral detectável (>200 cópias/mL) confirmada:|
|•<br>após seis meses do início da TARV_ou_|
|•<br>após um período de supressão viral.|  
de mutações no genoma viral que terminam por conferir resistência não só aos medicamentos em uso, como também aos outros da mesma classe, o que resulta em perda de opções terapêuticas<sup>176</sup> .  
Mesmo com supressão viral máxima, 15% a 30% das pessoas que iniciam TARV se comportam como não respondedores imunológicos, isto é, apresentam deficiência na recuperação da contagem de LT-CD4+. A ausência de resposta imunológica ocorre mais frequentemente quando o início da TARV é tardio, a contagem inicial de LT-CD4+ é muito baixa e em PVHA com idade avançada. Por outro lado, a supressão viral máxima e sustentada é um fator protetor contra infecções oportunistas, mesmo quando a resposta imunológica é parcial<sup>177</sup> .  
A ocorrência de infecções oportunistas na ausência de falha virológica não indica falha da TARV, mas reflete recuperação imunológica insuficiente, falha de profilaxias ou síndrome da reconstituição imune. Assim, na presença de supressão viral máxima, tanto a falha imunológica como a falha clínica não são expressões de falha do tratamento e raramente indicam necessidade de mudança do esquema antirretroviral.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.2. **Causas da falha virológica** -->
A principal causa de falha do tratamento antirretroviral é a má adesão do paciente ao tratamento. Fatores psicossociais, como depressão, uso de substâncias psicoativas, dificuldade de acesso e comorbidades ou doenças oportunistas ativas, além de fatores diretamente relacionados aos medicamentos, como efeitos adversos e posologia complexa, contribuem para a má adesão<sup>172,178</sup> .  
Durante os períodos de adesão irregular, níveis séricos baixos dos medicamentos, insuficientes para suprimir completamente a replicação viral, exercem pressão seletiva sobre a população viral e promovem a emergência de subpopulações resistentes aos medicamentos. A então _resistência viral adquirida_ , consequência imediata da má adesão, passa a ser causa da falha virológica, mesmo que o paciente volte a usar a medicação adequadamente. Nos casos de falha virológica a esquemas baseados em ITRNN, mutações de resistência a ARV são detectadas em até 90%<sup>179</sup> .  
A transmissão de vírus resistentes ( _resistência transmitida_ ), identificável em teste de genotipagem pré-tratamento, é causa menos comum de falha virológica. Na última década, um aumento progressivo da taxa de resistência transmitida aos ITRNN tem sido documentado<sup>87,155</sup> , mas a migração de EFV para DTG como base do esquema inicial contorna o problema da resistência transmitida, já que a transmissão de vírus com mutações de resistência no gene da integrase continua a ser rara<sup>180</sup> .  
Esquemas inadequados, seja devido a potência insuficiente, baixa barreira genética à resistência viral (terapia dupla inadequada, tripla com três ITRN, IP sem potencialização por ritonavir e monoterapia com IP) ou por interações medicamentosas são associados a maior risco de falha da TARV. Comorbidades resultando em vômitos ou diarreia podem impedir a absorção  
adequada dos medicamentos, resultar em concentrações séricas baixas de medicamentos e contribuir para a falha do tratamento.  
As principais causas de falha do tratamento antirretroviral e medidas para mitigá-las encontram-se no Quadro 13.  
Quadro 13: Identificação e manejo das causas de falha de tratamento  
|**Causas de falha da**<br>**TARV**|**Manejo**|
|---|---|
|Má adesão|Identificar fatores ligados ao paciente (psicológicos, sociais, cognitivos,<br>econômicos) e aos medicamentos (intolerância, complexidade).<br>Reavaliar em toda visita. Abordar a causa da má adesão, encontrar<br>apoiadores e buscar soluções individualizadas em conjunto com o<br>paciente e a rede de apoio. Ex.: envolver familiares ou amigos, assistente<br>social, equipemultidisciplinare/ou unidade básica de saúde.|
|Esquemas<br>inadequados|Avaliar a potência e a barreira à resistência do esquema.  Checar se o<br>esquema iniciado está de acordo com as diretrizes vigentes.|
|Fatores|Pesquisar a possibilidade de administração incorreta, interações|
|farmacológicos|medicamentosas oumá absorção.|
|Resistência viral|Em caso de falha confirmada, solicitar teste de genotipagem.|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.3. **Teste genotípico de resistência viral (genotipagem)** -->
Uma vez detectada e confirmada a falha virológica, recomenda-se a pesquisa de resistência viral aos medicamentos antirretrovirais, cujo resultado auxilia na elaboração de um esquema de resgate com maior chance de supressão viral<sup>181</sup> .  
**O teste de genotipagem precoce reduz a chance de acúmulo de mutações e resistência ampla e otimiza a escolha do esquema de resgate**  
O teste genotípico de resistência do HIV (“genotipagem”) consiste em amplificar material genético viral do plasma do paciente, sequenciar o genoma viral e compará-lo ao vírus selvagem de referência, identificando mutações associadas à redução da susceptibilidade aos medicamentos. O teste padrão identifica mutações nas regiões da transcriptase reversa e da protease do gene _pol_ ; a região da integrase é incluída apenas para pacientes que já usaram medicamentos da classe dos INI. A genotipagem do gene _env_ para detectar genotropismo e resistência a enfuvirtida é restrita a casos selecionados<sup>182</sup> .  
Os testes comerciais padrão detectam mutações que estão presentes em ao menos 20% da população viral. Nas situações de CV-HIV muito baixa, os testes de genotipagem são menos eficazes, pois pode não haver a amplificação das sequências. Além disso, subpopulações minoritárias com mutações de resistência podem não ser detectadas<sup>182</sup> . Por conta dessa menor  
sensibilidade para detecção de resistência no contexto de CV-HIV baixa, estabeleceu-se, no Brasil, o limite de viremia de 500 cópias/mL, a partir do qual o teste pode ser solicitado para realização.  
- **Critérios para realização do teste de genotipagem:** • PVHA em uso de TARV; • Falha virológica confirmada: 2 exames consecutivos com CV-HIV detectável, sendo o último exame com CV-HIV >500 cópias/mL.  
Recomenda-se que os testes de genotipagem sejam realizados o mais precocemente possível em relação ao diagnóstico da falha virológica. A viremia persistente, mesmo baixa, pode levar a acúmulo de mutações e resistência cruzada nas classes antirretrovirais em uso. Cerca de 60% dos pacientes mantidos com supressão viral parcial desenvolvem novas mutações de resistência após 18 meses. Após um ano sob viremia persistente, há perda de uma opção de medicamento em cerca de um terço dos casos<sup>172,183</sup> . O Quadro 14 traz aspectos relevantes a serem considerados na solicitação e interpretação do teste de genotipagem.  
**Quadro 14:** Considerações para otimizar o uso da genotipagem do HIV  
|**Antes de solicitar**||
|---|---|
|O exame deve ser coletado na<br>vigência de TARV|Algumas mutações ficam arquivadas rapidamente após a<br>interrupção da TARV, devido à ausência da pressão<br>seletiva exercida pelo medicamento e acabam não<br>aparecendo no exame realizado.|
|A CV-HIV deve estar detectável|Com viremia baixa, a amplificação do genoma viral é mais<br>difícil<br>No contexto de viremia muito baixa, mutações existentes<br>podem não ser detectadas.|
|**Solicitação**||
|Genotipagem convencional<br>_(ITRN, ITRNN e IP)_|Solicitar para toda falha virológica|
|Integrase<br>_(RAL, DTG)_|Solicitar em caso de falha atual ou prévia a INI|
|Genotropismo (alça V3 GP120)<br>_(MVQ)_|Solicitar na suspeita de resistência a 3 classes (ITRN,<br>ITRNN e IP).<br>Realizada<br>automaticamente<br>se<br>a<br>genotipagem<br>convencional detectar resistência às 3 classes|
|GP41<br>_(ENF/T20)_|Solicitar em falha sob uso de enfuvirtida (ENF/T20).<br>Na ausência da pressão seletiva (falha prévia a ENF) não é<br>recomendado, pois as mutações ficam arquivadas.|
|**Interpretação e elaboração do e**|**squema de resgate**|
|Mutações detectadas|Provável redução da susceptibilidade, entretanto a classe de<br>ITRN retém atividade residual mesmo na presença de<br>mutações.|  
|Mutações não detectadas|Não significa necessariamente medicamento ativo. Na<br>ausência de pressão seletiva (suspensão do medicamento)<br>ou em situações de CV-HIV baixa, pode não ser possível<br>detectar as subpopulações virais minoritárias com<br>mutações de resistência.|
|---|---|
|Considerar<br>o<br>histórico<br>de<br>esquemas ARV, falhas e de<br>testes de genotipagem|Mutações selecionadas no passado podem não ser<br>detectáveis na ausência do medicamento, contudo,<br>reemergem rapidamente após sua reintrodução. A<br>resistência é cumulativa: as mutações detectadas em<br>diferentes testes de um mesmo paciente devem ser<br>somadas.|
|Considerar os resultados como<br>“atuais” no máximo até 6 meses<br>após a coleta de amostra|Considerando-se o ritmo médio de acúmulo de novas<br>mutações na vigência de falha, após um período de 6 meses<br>podem surgir novas mutações e ocorrer perda adicional de<br>opções de tratamento.|
|Estruturar o esquema de resgate<br>a partir da orientação de MRG,<br>capacitados<br>e<br>atualizados<br>periodicamente pelo MS|A interpretação do teste e a escolha do melhor esquema de<br>resgate são complexas e demandam experiência e<br>atualização contínua no manejo da falha virológica.|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.4. **Falha virológica com CV-HIV menor que 500 cópias/mL** -->
Os casos de falha virológica com carga viral abaixo de 500 cópias/mL representam um desafio no manejo do tratamento das PVHA.  
Diferentemente dos casos com viremia muito baixa (abaixo de 200 cópias/mL), naqueles em que a CV-HIV se mantém entre 200 e 500 cópias/mL, definidos como falha virológica, o risco de resistência a ARV é grande<sup>175</sup> . Entretanto, devido às limitações do teste de genotipagem para esta faixa de viremia, há atualmente restrições para realização do exame neste contexto.  
Embora não haja consenso quanto ao manejo da falha com viremia baixa, sugere-se a seguinte abordagem<sup>172,175</sup> :  
- Reavaliar adesão, interações farmacológicas, comorbidades ativas, histórico de TARV e resposta ao tratamento.  
- Reavaliar o esquema ARV. Esquemas baseados em medicamentos de baixa potência ou barreira à resistência, como EFV, RAL ou IP não potencializado com RTV, devem ser modificados para incluir, ao menos, um medicamento de alta barreira, como DTG ou DRV/r.  
- Idealmente um especialista em resistência, como um médico de referência em genotipagem (MRG) ou a câmara técnica de referência devem ser consultados para auxiliar na troca empírica do esquema.  
- Monitorar CV-HIV a cada 3 meses.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.5. **Princípios gerais da terapia de resgate** -->
A disponibilidade de cinco classes de ARV e o surgimento, dentro dessas classes, de medicamentos potentes, ativos contra vírus resistentes e ao mesmo tempo bem tolerados, possibilitam hoje esquemas terapêuticos de resgate altamente eficazes. Após falha do tratamento inicial, taxas de resposta superiores a 80% têm sido obtidas com esquemas de segunda linha em estudos clínicos e na vida real. Além disso, a combinação criteriosa de medicamentos com alta barreira genética à resistência e de classes distintas possibilita a supressão viral máxima e duradoura mesmo no contexto desafiador da multirresistência.  
A composição e a complexidade do esquema de resgate necessárias à obtenção de supressão viral máxima dependem do tipo de falha (falha inicial _vs._ falhas múltiplas; resistência restrita _vs._ resistência ampla) e dos níveis de CV-HIV e da contagem de LT-CD4+ no momento da falha. Falha prolongada, falhas múltiplas, resistência genotípica ampla incluindo mutações no gene da protease, CV-HIV acima de 100.000 cópias/mL e contagens de LT-CD4+ baixas são fatores associados a menores taxas de resposta e podem demandar esquemas ARV mais complexos.  
O Quadro 15 resume os princípios gerais para elaboração de um esquema ARV de resgate.  
**Quadro 15:** Princípios gerais para elaboração de um esquema de resgate  
|**1.**|**Identificar precocemente a falha**|
|---|---|
|•<br>•<br>•|Queda menor que 2 logs após 8 semanas do início do esquema ARV<br>Manutenção de CV-HIV > 200 cópias 6 meses após o início do esquema ARV<br>Rebote de CV-HIV>200 cópias após obtenção de supressão viral|
|**2.**|**Solicitar teste de genotipagem **|
|•|Critérios:|
|`o`<br>`o`<br>`o`|Confirmar a falha virológica<br>CV-HIV >500 cópias/mL<br>PVHA em uso de TARV|
|•<br>•|Falha atual ou prévia com INI: solicitar genotipagem da integrase<br>Expectativa de resistência em ≥3 classes: solicitar genotropismo para considerar MVQ|
|**3.**|**Rever o esquema ARV em uso**|
|•<br>adeq|Adesão, uso/administração, tolerância, interações, potência, barreira genética,<br>uação às diretrizes vigentes|
|**4.**|**Rever o histórico de TARV e de resposta**|
|•<br>não<br>•<br>ativi<br>•<br>•|Falha prévia a EFV ou NVP: presumir resistência a ambos os medicamentos, ainda que<br>detectada no teste de genotipagem, devido à baixa barreira genética<br>Falha prévia a 3TC: presumir a presença da mutação M184V, que compromete a<br>dade de 3TC e ABC, ainda que não detectada no teste, devido à baixa barreira genética<br>Nenhuma falha prévia a IP sem RTV: pressupor atividade plena de IP/r<br>Falha prolongada: pressupor acúmulo de mutações|
||Fonte: DATHI/SVSA/MS.|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.6. **Resgate após falha inicial** -->
Na última década, diversos estudos clínicos randomizados investigaram alternativas para resgate de falha de esquemas de primeira linha baseados em inibidores da transcriptase reversa não análogos de nucleosídeos (ITRNN - efavirenz ou nevirapina). Tais estudos compararam o esquema de resgate padrão (2 inibidores da transcriptase reversa análogos de núcleos(t)ídeos associados a um inibidor da protease com reforço de ritonavir) com um esquema experimental. Foram comparados ao esquema padrão: esquemas duplos sem ITRN (Lopinavir/ritonavirr + raltegravir ou darunavir+ritonavir+ dolutegravir) e esquemas triplos de 2 ITRN (zidovudina+lamivudina ou tenofovir + lamivudina) associados a dolutegravir<sup>164–171</sup> .  
Altas taxas de eficácia foram atingidas com todos os esquemas testados nesses estudos, com 80 a 90% dos participantes atingindo supressão viral após 48 semanas. Outro achado notável, comum a todos esses estudos, foi a documentação de que mutações de ITRN presentes no início do tratamento de segunda linha não prejudicaram a eficácia dos esquemas contendo ITRN sem atividade ou com atividade reduzida segundo o teste de genotipagem.  
As recomendações para resgate de primeira linha foram reformuladas com bases nos estudos acima mencionados<sup>111,184,185</sup> , mantendo-se na maioria das diretrizes a recomendação de teste de genotipagem para auxiliar as decisões sobre a composição do esquema<sup>111,181,184,185</sup> . A realização do teste é particularmente importante por conta da substituição do efavirenz na primeira linha pelo dolutegravir. O perfil de resistência na falha com o esquema inicial baseado em dolutegravir é menos conhecido e os estudos acima mencionados trataram exclusivamente da falha de esquemas baseados em efavirenz ou nevirapina.  
Os esquemas de resgate devem conter preferencialmente ao menos 2 medicamentos ativos, sendo pelo menos um com alta barreira à resistência, isto é, dolutegravir ou darunavir+ritonavir. Contudo, é importante considerar que os ITRN mantêm atividade mesmo na presença de mutações. As mutações de resistência a ITRN não interferem com a resposta a darunavir+ritonavir ou dolutegravir nos esquemas de resgate de primeira linha, desde que darunavir e dolutegravir estejam 100% ativos<sup>164–171</sup> . Sendo assim, a dupla de ITRN preferencial para compor o esquema de segunda linha passa a ser sempre tenofovir + lamivudina. Devido à toxicidade e pior adesão com zidovudina, não há vantagem em usar zidovudina, mesmo no contexto de resistência genotípica a tenofovir 164,186,187,  
Em casos de comprometimento extenso dos ITRN, particularmente em situações de maior risco de falha (adesão irregular, doença avançada, carga viral alta, CD4 baixo), a combinação de tenofovir/lamivudina com darunavir/ritonavir pode ser mais segura que a com dolutegravir, para evitar a emergência de mutações de resistência em caso de nova falha. Embora dolutegravir ofereça alta barreira à resistência viral, no contexto de esquemas subótimos ou de adesão prolongadamente ruim. a emergência de mutações no gene da integrase foi documentada em estudos clínicos e observacionais<sup>164–171</sup> .  
Como na falha de esquema inicial baseado em IP +ritonavir, a regra é a ausência de mutações para IP, a posologia de darunavir + ritonavir de uma vez ao dia (800 + 100 mg) é preferencial nos esquemas de resgates de primeira linha que incluem darunavir. Em caso de contraindicação ao darunavir, atazanavir + ritonavir pode ser utilizado, entretanto atazanavir + ritonavir tem barreira genética mais baixa, potencial nefrotóxico e habitualmente é mais mal tolerado que darunavir+ritonavir.  
Nos casos excepcionais de ocorrência de mutações na protease, atazanavir /ritonavir não deve ser usado e, caso haja alguma mutação de resistência ao darunavir (V11I, V32I, L33F, I47V, I50V, I54L, I54M, T74P, L76V, I84V, L89V), a posologia deve ser: darunavir +ritonavir 600 mg + 100 mg 12/12h.  A presença de mutações na protease sugere experiência e falha prévia com IP sem potencialização de ritonavir. Tais casos devem ser manejados como resgate de terceira linha, pois esquemas mais complexos podem ser necessários.  
Em resumo, os esquemas hoje recomendados após falha de TARV inicial são três, todos em dose única diária:  
- Tenofovir/lamivudina (300/300 mg) + dolutegravir (50 mg) uma vez ao dia  
- Tenofovir/lamivudina (300/300 mg) + darunavir+ ritonavir (800 mg + 100 mg) uma vez ao dia  
- Dolutegravir (50 mg) + darunavir+ ritonavir (800 mg + 100 mg) uma vez ao dia. Esta opção é reservada a PVHA com contraindicação ou toxicidade a Tenofovir/lamivudina.  
Os esquemas recomendados e as ponderações para eleição da alternativa mais adequada em cada cenário estão discutidos no Quadro 16.  
**Quadro 16** : Esquemas de resgate após falha do esquema inicial  
|**Esquema inicial**<br>**em falha**|**Opções de esquemas de**<br>**resgate****_(todos de 1 dose_**<br>**_diária)_**|**Comentários**|
|---|---|---|
|**2 ITRN + ITRNN**|Tenofovir/lamivudina+<br>dolutegravir|Mais bem tolerado, o que favorece a<br>adesão.|
||Tenofovir/lamivudina+<br>darunavir+ritonavir|Em casos de comprometimento extenso<br>dos ITRN e alto risco de má adesão,<br>DRV+RTV pode ser mais seguro que<br>DTG para evitar a emergência de<br>mutações de resistência.|
||Dolutegravir + darunavir +<br>ritonavir|Em<br>geral<br>reservado<br>para<br>contraindicação ou toxicidade aTDF.|
|**2 ITRN +**<br>**IP+RTV**|Tenofovir/lamivudina+<br>darunavir + ritonavir|Na falha de esquema inicial com IP/r, a<br>regra é ausência de mutações no gene<br>da protease.  Pode-se manter o<br>esquema, caso já inclua DRV/r.|
||Tenofovir/lamivudina +<br>dolutegravir|Esquema preferido se a causa da falha<br>for intolerância a IP/r, para melhorar a<br>tolerância e a adesão.<br>Em casos de comprometimento extenso<br>dos ITRN e alto risco de manutenção da<br>má adesão, DRV/r pode ser mais seguro<br>que DTG para evitar a emergência de<br>mutações deresistência.|  
|**Esquema inicial**<br>**em falha**|**Opções de esquemas de**<br>**resgate****_(todos de 1 dose_**<br>**_diária)_**|**Comentários**|
|---|---|---|
||Dolutegravir + darunavir +<br>ritonavir|Em<br>geral<br>reservado<br>para<br>contraindicação ou toxicidade a TDF.|
|**2 ITRN + INI**|Tenofovir/lamivudina+<br>darunavir + ritonavir|Opção mais segura se o esquema inicial<br>era baseado em RAL ou se não há<br>possibilidade de genotipagem.|
||Tenofovir/lamivudina+<br>dolutegravir|Na falha de esquema inicial com DTG<br>não é comum que ocorram mutações<br>para INI, por isso a possibilidade de<br>manutenção do esquema. Caso a<br>genotipagem mostre mutações para<br>INI, esta opção fica excluída.|
||Dolutegravir + darunavir+<br>ritonavir|Em<br>geral<br>reservado<br>para<br>contraindicação<br>ou<br>toxicidade<br>a<br>tenofovir.|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 9.7. **Resgate após múltiplas falhas** -->
A exposição prévia e falha a múltiplos esquemas ARV está associada a multirresistência viral, isto é, resistência cruzada ampla dentro de cada classe e resistência em várias classes de ARV. Nessas circunstâncias, a elaboração de um esquema de resgate eficaz é mais complexa e deve contar com o auxílio de um médico de referência em genotipagem ou da câmara técnica local.  
Os princípios gerais para o resgate após múltiplas falhas são os mesmos apresentados no Quadro 15, porém valem algumas considerações particulares.  
Todo esforço deve ser empenhado em recuperar o histórico completo de exposição a ARV e de resposta virológica, assim como os testes de genotipagem previamente realizados. Um novo teste de genotipagem é essencial. As mutações de diferentes testes devem ser somadas às do teste atual antes da interpretação.  
Se há segurança, com base na história e nos testes de resistência, há segurança de plena susceptibilidade a darunavir + ritonavir e dolutegravir, a base racional para compor o esquema após múltiplas falhas é semelhante à apresentada acima para resgate inicial.  
Nos casos de resistência ampla, particularmente quando há alguma mutação para darunavir + ritonavir, esquemas mais complexos são necessários<sup>167</sup> , incluindo ao menos dois, mas idealmente três medicamentos ativos e, se necessário, deve-se lançar mão da atividade residual dos ITRN.  
No Quadro 17 estão listados os medicamentos usados para compor os esquemas de resgate na situação de multirresistência.  
**Quadro 17:** Medicamentos e doses para resgate após múltiplas falhas

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Inibidor da protease (IP)** -->
|**Darunavir + ritona**<br>**DRV+RTV**<br>**Inibidor da integr**<br>|**vir**<br>**ase (**|800 mg* + 100 mg uma vez ao dia, na ausência de mutações para<br>darunavir*,<br>600 mg+100 mg de 12/12h, se houver alguma mutação de resistência.<br>Darunaviré contraindicado com rifampicina.<br>**INI)**<br>|
|---|---|---|
|**Dolutegravir**<br>**DTG**<br>**Inibidor da transc**<br>|**ripta**|50 mg de 12/12h, se houver mutações de resistência a INI<br>50 mg/dia, na ausência de mutações a INI<br>50 mg de 12/12h, se coadministrado com efavirenz ou rifampicina.<br>Em vírus com mutações a INI, coadministração com efavirenz é<br>contraindicada e não há dados com rifampicina.<br>**se reversa não-nucleosídeo (ITRNN)**<br>|
|**Etravirina**<br>**ETR**<br>**Inibidor de entrad**<br>|**a, an**|200 mg de 12/12h<br>O teste de genotipagem pode subestimar a resistência em casos de falha<br>prévia a efavirenz e, principalmente, a nevirapina.<br>Contraindicado com rifampicina.<br>**tagonista de CCR5**<br>|
|**Maraviroque**<br>**MVQ**<br>**Inibidor de entrad**|**a, in**|Apresentação 150 mg. A dose será definida a depender dos<br>medicamentos concomitantes. Consultar**Quadro B.**Exige teste de<br>genotropismo recente (6 meses) evidenciando exclusivamente vírus de<br>tropismo R5<br>**ibidor da fusão**|
|**Enfuvirtida**<br>**ENF (T20)**||90 mg 12/12, via subcutânea<br>Medicamentoinjetável,reaçãolocal intensa é comum.|  
Fonte: DATHI/SVSA/MS.  
* Mutações de resistência a DRV: V11I, V32I, L33F, I47V, I50V, I54L, I54M, T74P, L76V, I84V, L89V

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: ABORDAGEM DA INTERRUPÇÃO DO TRATAMENTO E ESTRATÉGIAS PARA **MELHORAR A ADESÃO** -->
A interrupção do tratamento se refere à descontinuação ou interrupção do uso de antirretrovirais. Pode ocorrer de forma concomitante ou não à perda de consultas, exames e outras ações de cuidado<sup>188,189</sup> .  
A boa adesão à TARV é fundamental para o sucesso no tratamento da infecção pelo HIV. Pessoas com adesão irregular apresentam maior risco de falha virológica, emergência de resistência aos ARV e transmissão de vírus resistentes. PVHA que aderem mal ao tratamento têm maior risco de progressão da infecção, evolução para aids e óbito.<sup>178,190–193</sup> .  
O Sistema de Monitoramento Clínico (SIMC) e o Sistema de Controle Logístico de Medicamentos (SICLOM) permitem listar em tempo real as PVHA de cada serviço que estão em atraso ou perda de seguimento.  
No Brasil, do ponto de vista administrativo, são consideradas pessoas em interrupção de tratamento aquelas que não retornaram para retirar seus medicamentos antirretrovirais depois de 100 dias contados a partir da data prevista no Siclom para a próxima dispensação.  
Em 2022, 76% das pessoas apresentaram adesão suficiente, enquanto 15% tinham adesão insuficiente e 9% foram consideradas como perda de seguimento (interrupção de tratamento e óbito)<sup>194</sup> .  
Diferente do paciente em início de tratamento, sem experiência prévia com antirretrovirais, o usuário que retoma a TARV após um período de descontinuidade tem experiências prévias que devem ser investigadas e abordadas para evitar novas interrupções do tratamento.  
O primeiro passo da abordagem da má adesão e interrupção do tratamento é a identificação das PVHA com atraso de retirada de medicação. De acordo com as especificidades de cada unidade, uma rotina deve ser criada para identificar periodicamente as PVHA que interromperam o tratamento. Estratégias para restabelecer o vínculo entre a PVHA e o serviço de saúde variam de serviço a serviço, mas idealmente devem incluir a localização dos indivíduos, contato telefônico, convocação e remoção de obstáculos ao acesso, como viabilização de transporte e realização de consulta sem agendamento. Uma vez restabelecido o contato do paciente com a equipe de saúde, deve-se **avaliar o perfil de vulnerabilidade do usuário, as razões que motivaram a interrupção de tratamento e adotar uma abordagem qualificada e multidisciplinar de acordo com o caso.**  
Determinantes psicossociais, comportamentais, biológicos e estruturais podem interferir diretamente na adesão e devem ser abordados na estratégia de reintrodução da TARV. Para isso, deve-se considerar:  
- <u>fatores relacionados ao paciente e seu contexto social:</u> rotinas diárias ocupadas/não estruturadas; insegurança financeira; uso de substâncias; problemas de saúde mental; eventos de vida estressantes ou disruptivos; pessoas em situação de rua; falta de apoio familiar e/ou social; estigma e receio de divulgação; fadiga com o tratamento; experiência com efeitos adversos; baixa escolaridade; comorbidades; histórico de interrupção de tratamento prévio; entre outros.  
- <u>fatores relacionados aos medicamentos: eventos adversos; toxicidade; posologias</u> complexas em casos de comorbidades; entre outros.  
- <u>fatores relacionados à organização dos serviços de saúde: facilidade no acesso;</u> disponibilidade de insumos e profissionais qualificados; vinculação com a unidade de saúde e com a equipe; entre outros.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 10.1. **Reintrodução da TARV após interrupção do tratamento** -->
A reintrodução da TARV é uma das prioridades quando a PVHA retorna ao serviço de  
saúde.  
Na suspeita de infecção pelo HIV avançada deve-se lançar mão de ferramentas auxiliares para diagnóstico rápido e efetivo de infecções oportunistas. Exemplos importantes são o teste molecular para detecção de _M. tuberculosis_ e o LF-LAM para o diagnóstico rápido de tuberculose, e o LF-CrAg para criptococose.  
A escolha dos ARV que farão parte do esquema de reintrodução deve levar em consideração os motivos da interrupção de tratamento, as classes dos medicamentos em uso antes da descontinuação, e o histórico terapêutico e de testes de resistência.  
Efavirenz e nevirapina têm barreira genética baixa para resistência, pois mutações que conferem resistência viral a esses medicamentos emergem rapidamente no gene da transcriptase reversa no contexto de má adesão e falha.<sup>195,196</sup> . Outro fator que favorece a seleção de variantes resistentes após a descontinuação de esquemas compostos por ITRN e ITRNN é a meia-vida plasmática longa dos ITRNN. A descontinuação simultânea dos ITRN e ITRNN resulta em monoterapia temporária com ITRNN, que pode culminar com seleção de mutantes resistentes<sup>197</sup> . Sendo assim, indivíduos em interrupção de tratamento de tratamento após uso de ITRNN não devem reiniciar o tratamento com medicamentos desta classe<sup>198</sup> .  
Por outro lado, a interrupção de esquemas baseados em antirretrovirais com alta barreira genética, como darunavir potencializado por ritonavir e dolutegravir, não está associada a emergência de resistência a esses medicamentos. Além disso, a presença de darunavir ou dolutegravir no esquema antirretroviral “protege” parcialmente os outros componentes do esquema contra resistência. Assim, pacientes que interromperam esquemas baseados em dolutegravir ou darunavir + ritonavir podem retomar o mesmo esquema.  
O Quadro 18 orienta a escolha dos esquemas para retomada da TARV após a interrupção.  
Após 4 a 6 semanas da reintrodução da TARV, novo exame de carga viral deve ser realizado. Espera-se ao menos queda de 2 log na CV-HIV. Nos casos de CV-HIV maior que 500 cópias/mL confirmada, deve-se seguir orientações de manejo da falha virológica, conforme seção 7: Falha ao tratamento antirretroviral.  
**Quadro 18:** Esquemas de retomada após interrupção da terapia antirretroviral  
|**Esquema**<br>**interrompido**|**Opções de esquemas para**<br>**retomada**|**Comentários**|
|---|---|---|
|**Interrupção de esq**|**uema inicial**||
|**2 ITRN + ITRNN**|Tenofovir/lamivudina +<br>dolutegravir|Esquema preferencial. Mais bem<br>tolerado, o que favorece a adesão.|
||Tenofovir/lamivudina +<br>darunavir + ritonavir|Esquema alternativo, em caso de<br>contraindicação ou intolerância a<br>DTG.|
||Dolutegravir+ darunavir +<br>ritonavir|Reservado para contraindicação ou<br>toxicidade a TDF.|
|**2 ITRN + INI**|Tenofovir/lamivudina +<br>dolutegravir|Na interrupção de esquema inicial com<br>dolutegravir não é comum que<br>ocorram mutações para INI.|
||Tenofovir/lamivudina +<br>darunavir + ritonavir|Opção mais segura se há histórico de<br>má adesão recorrente e períodos<br>prévios de replicação em vigência de<br>tratamento.|
||Dolutegravir + darunavir +<br>ritonavir|Reservado para contraindicação ou<br>toxicidade a tenofovir.|  
|**Esquema**<br>**interrompido**|**Opções de esquemas para**<br>**retomada**|**Comentários**|
|---|---|---|
|**2**<br>**ITRN**<br>**+**<br>**IP+RTV**|Tenofovir/lamivudina +<br>darunavir + ritonavir|Na interrupção ou falha de esquema<br>inicial com IP/r, a regra é ausência de<br>mutações no gene da protease.  Pode-<br>se manter o esquema, caso já inclua<br>darunavir+ritonavir.|
||Tenofovir/lamivudina +<br>dolutegravir|Esquema preferido se a causa da<br>interrupção for intolerância a IP/r, para<br>melhorar a tolerância e a adesão.|
||Dolutegravir + darunavir +<br>ritonavir|Reservado para contraindicação ou<br>toxicidade a tenofovir.|
|**Outros cenários**|||
|**Histórico incerto**<br>**ou desconhecido**|Tenofovir/lamivudina +<br>darunavir + ritonavir|Atualmente resistência a darunavir +<br>ritonavir é rara e, em caso de falha do<br>esquema de retomada, a emergência de<br>mutações para darunaviréimprovável.|
|**Interrupção**<br>**de**<br>**esquema**<br>**de**<br>**resgate**|Retomar o esquema<br>interrompido.|Repetir carga viral em 4-8 semanas. Se<br>estiver acima de 500 cópias/mL,<br>solicitargenotipagem.|  
Fonte: DATHI/SVSA/MS

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **EVENTOS ADVERSOS AOS ANTIRRETROVIRAIS** -->
Os benefícios globais da supressão viral e a melhora na função imunológica como resultado da TARV superam largamente os riscos associados aos efeitos adversos de alguns ARV.  
Os novos esquemas de ARV estão associados a menos eventos adversos graves e maior tolerância que os esquemas utilizados no passado, assim, as descontinuidades do tratamento têm sido menos frequentes.  
Uma vez que a TARV é agora recomendada para todas as PVHA, independentemente da contagem de LT-CD4+, e a terapia não deve ser interrompida, o tratamento da PVHA deve ser individualizado, evitando efeitos adversos em longo prazo, tais como toxicidade óssea ou renal, dislipidemia, resistência à insulina ou doença cardiovascular.  
<mark>Para conseguir uma supressão viral sustentada ao longo da vida, tanto as toxicidades de</mark> longo prazo quanto as de curto prazo devem ser antecipadas e superadas.  
Deve-se considerar os possíveis efeitos adversos ao selecionar a TARV, bem como as comorbidades, o uso de medicamentos concomitantes e a história prévia de intolerância ou hipersensibilidade aos medicamentos.  
Vários fatores podem predispor os indivíduos a efeitos adversos de medicamentos ARV, tais como:  
- Comorbidades que aumentam o risco de efeitos adversos ou os exacerbam (ex.: etilismo ou coinfecção com hepatites virais podem aumentar o risco de hepatotoxicidade; distúrbios psiquiátricos podem ser exacerbados por efavirenz; disfunção renal aumenta o risco de nefrotoxicidade por tenofovir).  
- Interações medicamentosas que podem aumentar a toxicidade dos ARV ou de outros medicamentos em uso concomitante. Para checar as interações, consultar: <u>https://interacoeshiv.huesped.org.ar/.</u>  
- Fatores genéticos (ex.: reação de hipersensibilidade a abacavir, toxicidade neuropsiquiátrica por efavirenz, hiperbilirrubinemia associada a atazanavir)<sup>199–201</sup> .  
Em geral, no caso de efeito adverso grave ou potencialmente fatal, ou, ainda, hipersensibilidade, a TARV deve ser descontinuada até que os sintomas se resolvam e um esquema de substituição possa ser iniciado com segurança.  
Os efeitos adversos associados a cada ARV estão resumidos no Quadro 19. O  
**Quadro 20** traz os eventos adversos mais comuns e/ou graves conhecidos e associados aos ARV, por classe de medicamento.  
**Para substituições de ARV, consultar também o item Substituição de esquemas (** **_switch_ ) de TARV no contexto de supressão viral.**  
**Quadro 19:** Eventos adversos associados aos antirretrovirais  
|**ARV**|**EFEITOS ADVERSOS DE**<br>**RELEVÂNCIA CLÍNICA**|**FATORES DE RISCO**|**RECOMENDAÇÕES DE MANEJO**<sup>**(d)**</sup>|
|---|---|---|---|
|Abacavir|Reação de hipersensibilidade|Presença do alelo HLA-B*5701<br>|Não usar se teste para HLA-B * 5701 positivo<br>Avaliar substituição por tenofovir. Se tenofovir for<br>contraindicado, avaliaruso dezidovudina|
||Anormalidades<br>eletrocardiográficas<br>(prolongamento<br>do<br>intervalo<br>QRS e PR)|Pessoas com doença pré-existente do<br>sistema de condução<br>Uso<br>concomitante<br>de<br>outros<br>medicamentos que podem prolongar<br>os intervalos PR ou QRS<br>Síndrome do QT longo congênito|Usar com precaução em pessoas com doença pré-<br>existente de condução ou que também estejam tomando<br>medicamentos que possam prolongar os intervalos PR<br>ou QRS|
|Atazanavir<br>+<br>Ritonavir|Hiperbilirrubinemia<br>indireta<br>(icterícia clínica)|Presença de alelo difosfato de uridina<br>(UDP)<br>-<br>glucuronosiltransferase<br>1A1*28 (UGT1A1*28)|Fenômeno clinicamente benigno, mas potencialmente<br>estigmatizante.<br>A ocorrência de icterícia pode afetar a imagem e a<br>autoestima<br>da<br>PVHA,<br>devendo,<br>portanto,<br>ser<br>cuidadosamente<br>avaliada,<br>considerando-se<br>a<br>substituição<br>do<br>medicamento<br>quando<br>houver<br>desconforto para a PVHA.|
||Nefrolitíase<br>Colelitíase|História de nefrolitíase|Avaliar substituição por darunavir/ritonavir. Se os IP +<br>ritonavir estiverem contraindicados, considerar a<br>substituição por INI.|
||Anemia e neutropenia grave|LT-CD4+ menor ou igual a 200<br>células/mm³|Substituir se hemoglobina estiver menor que 10,0 g/dL|
|Zidovudina|Acidose lática ou hepatomegalia<br>grave com esteatose<br>Lipodistrofia<br>Miopatia|IMC >maior que 25 (ou peso corporal<br>maior que 75 kg)<br>Exposição prolongada a ITRN|e/ou contagem de neutrófilos estiver abaixo de 1.000<br>células/mm<sup>3</sup><br>Avaliar substituição por tenofovir ou abacavir<sup>(a)</sup>|
|Dlti|Insônia (<3%), cefaleia (<2%),<br>náuseas e vômitos (<1%)||Se dolutegravir tiver sido usado como esquema inicial<br>preferencial<br>(“primeira<br>linha”)<br>e<br>se<br>houver|
|ouegravr|Reação de hipersensibilidade<br>Hepatotoxicidade|Coinfecção hepatite B ou C<br>Doença hepática|intolerância/toxicidade, avaliar substituição por IP +<br>ritonavir|  
|**ARV**|**EFEITOS ADVERSOS DE**<br>**RELEVÂNCIA CLÍNICA**|**FATORES DE RISCO**|**RECOMENDAÇÕES DE MANEJO**<sup>**(d)**</sup>|
|---|---|---|---|
||||Quando utilizado como TARV de uso restrito (“terceira<br>linha”), opções disponíveis limitadas – avaliar<br>genotipagem|
|Darunavir<br>+<br>Ritonavir|<br>Hepatotoxicidade|- Doença hepática prévia<br>- Coinfecção HBV e/ou HCV<br>- Uso concomitante de medicamentos<br>hepatotóxicos|Avaliar genotipagem antes da troca|
||Reações de hipersensibilidade e<br>cutâneas graves|Alergia às sulfonamidas|Para reações de hipersensibilidade, substituir por outra<br>classe terapêutica|
||Toxicidade persistente no SNC<br>(tonturas, sonolência, insônias,<br>sonhos vívidos, “sensação de<br>embriaguez”,<br>“sensação<br>de<br>ressaca”) ou sintomas mentais<br>(ansiedade, depressão, confusão<br>mental)|Depressão ou outro transtorno mental<br>(anterior ou no início)|Orientar sobre tais eventos e informar que normalmente<br>desaparecem ao final das primeiras semanas de<br>tratamento<br>Orientar uso do medicamento ao dormir, de preferência,<br>com estômago vazio, para minorar os eventos adversos.<br>Avaliar substituição por dolutegravir ou IP + ritonavir<br>se persistirem os sintomas.|
||Convulsões|Histórico de convulsões|Os<br>efeitos<br>adversos<br>neurológicos<br>podem<br>ser<br>|
|Efavirenz|Hepatotoxicidade|Doença hepática prévia<br>Coinfecção HBV e/ou HCV<br>Uso concomitante de medicamentos<br>hepatotóxicos|exacerbados com o uso concomitante de álcool. É<br>necessário que abordar o uso recreativo de álcool e<br>outras drogas, aconselhando o paciente para que o uso<br>do medicamento não seja interrompido|
||Reações de hipersensibilidade e<br>cutâneas graves|Fator(es) de risco desconhecido(s)|Se<br>hepatotoxicidade<br>grave,<br>reações<br>de<br>hipersensibilidade ou intolerância/toxicidade, avaliar<br>substituição<br>por<br>IP + ritonavir|
||Ginecomastia|Fator(es) de risco desconhecido(s)|Avaliar substituição por IP+ritonavir|
|Etravirina|Reações de hipersensibilidade e<br>cutâneas graves|Fator(es) de risco desconhecido(s)|Opções disponíveis limitadas – avaliar genotipagem|
|Raltegravir|Rabdomiólise, miopatia, mialgia|Uso<br>concomitante<br>de<br>outros<br>medicamentos que aumentam o risco|<sup>Avaliar histórico de uso e genotipagem antes da troca.</sup>|  
|**ARV**|**EFEITOS ADVERSOS DE**<br>**RELEVÂNCIA CLÍNICA**|**FATORES DE RISCO**|**RECOMENDAÇÕES DE MANEJO**<sup>**(d)**</sup>|
|---|---|---|---|
|||de miopatia e rabdomiólise, incluindo<br>estatinas||
||Hepatotoxicidade<br>Erupção cutânea (_rash_) grave e<br>reação de hipersensibilidade|Fator(es) de risco desconhecido(s)||
|Tenofovir<sup>(b)</sup>|Toxicidade renal<br>Lesão renal aguda e síndrome de<br>Fanconi|Doença renal prévia<br>Mais de 50 anos<br>IMC abaixo de 18,5 ou baixo peso<br>corporal<br>(abaixo<br>de<br>50<br>kg),<br>especialmente em mulheres<br>Diabetes não tratada<br>Hipertensão não tratada<br>Uso<br>concomitante<br>de<br>fármacos<br>nefrotóxicos ou de IP+ritonavir|Avaliar substituição por abacavir<sup>(a)</sup>ou zidovudina<br>Não iniciar tenofovir se doença renal prévia, TFGe<br>abaixo de 60 mL/minuto ou insuficiência renal. Usar|
||Diminuição<br>da<br>densidade<br>mineral óssea|História de osteomalácia ou fratura<br>patológica<br>Fatores de risco para osteoporose ou<br>perda de densidade mineral óssea<br>Deficiência de vitamina D|com precaução quando hipertensão não controlada,<br>diabetes não tratada, idoso ou baixo peso corporal|
||Acidose<br>láctica<br>ou<br>hepatomegalia<br>grave<br>com<br>esteatose|Exposição prolongada a ITRN<br>Obesidade<br>Doençahepática||  
Fonte: Adaptado de DHHS, 2022 e WHO, 2021<sup>110,111,202</sup>  
- (a) Abacavir deve ser utilizado apenas em PVHA sabidamente negativas para HLA-B*5701.  
- (b) Em PVHA com infecção crônica ativa pelo HBV, deve-se substituir o tenofovir por outro fármaco ativo contra o HBV.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Quadro 20:** Eventos adversos mais comuns e/ou graves por classe de antirretroviral -->
|**EVENTO**<br>**ADVERSO**|**ITRN**|**ITRNN**|**IP**|**INI**|**IE**|
|---|---|---|---|---|---|
||Relatada<br>com<br>ITRN,<br>especialmente com zidovudina.<br>Início insidioso com pródromo<br>gastrointestinal, perda de peso e|||||
||fadiga.<br>Pode<br>progredir<br>rapidamente<br>com<br>taquicardia,<br>|||||
|Acidose lática|taquipneia, icterícia, fraqueza,<br>alterações no estado mental,<br>pancreatite e falência de órgãos.<br>Mortalidade alta se nível de<br>lactato sérico estiver maior que 10<br>mmol/L.<br>Mulheres e pacientes obesos têm<br>risco aumentado|S/D|S/D|S/D|S/D|
|Alteração<br>da<br>densidade<br>mineral<br>óssea (DMO)|Tenofovir: associado a maior<br>perda de DMO que outros ITRN.<br>Osteomalácia<br>pode<br>estar<br>associada a tubulopatia renal e<br>perda de fosfato urinário|Diminuição da DMO é obser|vada após o início de qualquer esq|uema de TARV|S/D|
|Aumento de peso|Observadonoinício do tratamento|e subsequente supressão viral.|Maior na classe dosINI.||S/D|
|Colelitíase|S/D|S/D|Atazanavir: colelitíase e<br>cálculosrenais|S/D|S/D|
|Diabetes/resistência<br>insulínica|Zidovudina|S/D|Lopinavir/ritonavir|S/D|S/D|  
|**EVENTO**<br>**ADVERSO**|**ITRN**|**ITRNN**|**IP**|**INI**|**IE**|
|---|---|---|---|---|---|
|Dislipidemia|Zidovudina > Abacavir: aumento<br>de triglicerídeos e LDL|Efavirenz:<br>aumento<br>de<br>triglicerídeos, LDL e HDL|Todos os IP + ritonavir:<br>aumentam<br>triglicerídeos,<br>LDL e HDL<br>Lopinavir/ritonavir<br>><br>Darunavir + Ritonavir e<br>Atazanavir+<br>ritonavir:<br>aumento de triglicerídeos|S/D|S/D|
|Doença<br>cardiovascular|Abacavir:<br>associado<br>a<br>um<br>aumento do risco de IAM em<br>alguns estudos de coorte.<br>Risco<br>absoluto<br>maior<br>em<br>pacientes com fatores de risco<br>tradicionais de DCV|S/D|Darunavir/ritonavir:<br>Associado com IAM e<br>AVC em algumas coortes.<br>Atazanavir + Ritonavir:<br>prolongamento<br>PR<br>(os<br>riscos<br>incluem<br>doença<br>cardíaca<br>pré-existente,<br>outros medicamentos).|S/D|S/D|
|Eventos<br>gastrointestinais|Atazanavir<br>><br>outros<br>ITRN:<br>náusea e vômitos|S/D|<br>Intolerância<br>gastrointestinal<br>(ex.:<br>diarreia, náusea, vômitos)<br>Comum e mais frequente<br>com<br>Lopinavir/ritonavir<br>que<br>com<br>Darunavir+<br>Ritonavir e Atazanavir+<br>Ritonavir: diarreia|S/D|S/D|  
|**EVENTO**<br>**ADVERSO**|**ITRN**|**ITRNN**|**IP**|**INI**|**IE**|
|---|---|---|---|---|---|
|Eventos hepáticos|Relatos com a maioria dos ITRN<br>Zidovudina:<br>mais<br>comum<br>esteatose<br>Quando tenofovir e lamivudina<br>são retirados ou quando HBV<br>desenvolve resistência: pacientes<br>coinfectados HIV/HBV podem<br>desenvolver exacerbação grave da<br>hepatite (_flares_) com potencial<br>fulminante.|Efavirenz: aumento das<br>transaminases|Todos<br>os<br>IP:<br>hepatite<br>induzida por medicamentos<br>e<br>descompensação<br>hepática.<br>Atazanavir:<br>icterícia<br>devido<br>a<br>hiperbilirrubinemia<br>indireta benigna|S/D|Maraviroque:<br>hepatotoxicida<br>de com ou sem<br>_rash_e reação<br>de<br>hipersensibilid<br>ade|
|Eventos<br>renais/<br>urolitíase|Tenofovir:<br>aumento<br>de<br>Creatinina,<br>proteinúria,<br>hipofosfatemia, perda de fosfato<br>urinário, glicosúria, hipocalemia,<br>acidose metabólica|S/D|Atazanavir<br>e<br>Lopinavir/ritonavir:<br>aumento do risco de doença<br>renal crônica em um grande<br>estudo de coorte<br>Atazanavir: litíase renal.<br>Hidratação adequada pode<br>reduzir o risco|Dolutegravir:<br>inibe a secreção<br>de creatinina sem<br>reduzir a função<br>renal glomerular<br>(não<br>ocorre<br>nefrotoxicidade)|S/D|
|Lipodistrofia|Lipoatrofia: Zidovudina. Pode ser<br>mais provável quando os ITRN<br>são combinados com efavirenz<br>que com um IP+RTV|Lipo-hipertrofia: aumento de<br>efavirenz, IP e raltegravir; en|gordura em tronco observado<br>tretanto, a relação causal não|em esquemas com<br>foi estabelecida.|S/D|
|Miopatia/elevação de<br>creatina fosfoquinase<br>(CPK)|<br>Zidovudina: miopatia|S/D|S/D|RAL<br>e<br>DTG:<br>↑CPK, fraqueza e<br>rabdomiólise|S/D|
|Farmacodermia|Entricitabina: hiperpigmentação|Todos os ITRNN|Atazanavir<br>Darunavir|Raltegravir|Maraviroque|
|Reação<br>de<br>hipersensibilidade<br>(RHS), exceto_rash_|Abacavir:<br>contraindicado<br>se<br>HLA-B*5701<br>positivo.<br>Início<br>médio de 9 dias após início do|-|S/D|Ralegravir: RHS<br>relatada<br>quando<br>administrado em<br>combinação com|Maraviroque:<br>relatada como<br>parte de uma<br>síndrome|  
|**EVENTO**<br>**ADVERSO**|**ITRN**|**ITRNN**|**IP**|**INI**|**IE**|
|---|---|---|---|---|---|
|isolado e Síndrome de<br>Stevens-Johnson|tratamento; 90% das reações<br>ocorrem nas primeiras 6 semanas.<br>Sintomas de RHS (por ordem de<br>frequência decrescente): febre,<br>erupção cutânea (_rash_), mal-estar,<br>náuseas,<br>cefaleias,<br>mialgia,<br>calafrios, diarreia, vómitos, dor<br>abdominal, dispneia, artralgia e<br>sintomas respiratórios<br>Os sintomas pioram com a<br>manutenção do uso de abacavir.<br>Os pacientes, independentemente<br>do_status_do HLAB*5701, não<br>devem reiniciar com ABC se<br>houver suspeita de RHS|||outros<br>fármacos<br>conhecidos<br>por<br>causar<br>RHS.<br>Todos os ARV<br>devem<br>ser<br>interrompidos se<br>RHS ocorrer.<br>Dolutegravir:<br>relatado em <1%<br>dos pacientes|relacionada à<br>hepatotoxicida<br>de|
|Sangramentos|S/D|S/D|Hemorragia espontânea e<br>hematúria na hemofilia|S/D|S/D|
|Síndrome de Stevens-<br>Johnson/necrólise<br>epidérmica tóxica|Zidovudina: relato de casos|Nevirapina><br>Efavirenz,<br>Etravirina|Darunavir,<br>Lopinavir/ritonavir,<br>Atazanavir: relato de casos|Raltegravir|S/D|
|||Efavirenz:<br>sonolência,<br>insônia, sonhos anormais,<br>tontura,<br>diminuição<br>da<br>concentração,<br>depressão,||Todos<br>os<br>INI:<br>Insônia, depressão<br>e suicídio foram<br>relatados||
|Sistema<br>nervoso/eventos<br>psiquiátricos|S/D|psicose e ideação suicida.<br>Os sintomas geralmente<br>desaparecem ou diminuem<br>após 2 a 4 semanas. O uso<br>do medicamento ao dormir<br>pode reduzir os sintomas.<br>Os riscos incluem doença|S/D|raramente<br>com<br>INI,<br>principalmente<br>em pacientes com<br>condições<br>psiquiátricas<br>preexistentes|S/D|  
|**EVENTO**<br>**ADVERSO**<br>**ITRN**|**ITRNN**|**IP**|**INI**|**IE**|
|---|---|---|---|---|
||psiquiátrica<br>prévia<br>não<br>controlada,<br>uso<br>concomitante de agentes<br>com<br>efeitos<br>neuropsiquiátricos<br>e<br>concentrações aumentadas<br>de<br>efavirenz<br>por<br>predisposição genética ou<br>ingestão com alimentos.<br>Foi encontrada associação<br>entre efavirenz e ideação<br>suicida, suicídio e tentativa<br>de suicídio (especialmente<br>entre pacientes mais jovens<br>e com história de doença<br>mental<br>ou<br>abuso<br>de<br>substâncias).||||
|Supressão de medula<br>óssea<br>Zidovudina: anemia, neutropenia|S/D|S/D|S/D|S/D|  
Fonte: Adaptado de DHHS, 2021 e WHO, 2021<sup>110,111,202</sup>  
S/D = indica que não há relatos de casos para o efeito adverso ou que não há dados disponíveis para a classe de ARV. ITRN: inibidor da transcriptase reversa análogo núcleos(t)ídeo; ITRNN: inibidor da transcriptase reversa não análogo nucleosídeo; IP: inibidor de protease; INI: inibidor de integrase; IE: inibidores de entrada.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **SUBSTITUIÇÃO DE ESQUEMAS (SWITCH) DE TARV NO CONTEXTO DE SUPRESSÃO VIRAL** -->
O uso racional de ARV, considerando sua eficácia, efetividade, toxicidade e comodidade posológica, é uma das diretrizes das indicações para TARV.  
Sendo assim, é possível considerar a mudança de um esquema eficaz para um esquema alternativo em algumas situações.  
A TARV é substituída principalmente por:  
- Efeitos adversos agudos/subagudos;  
- Prevenção de toxicidade em longo prazo;  
- Comorbidades associadas;  
- Prevenção de interações medicamentosas graves;  
O princípio fundamental da mudança da TARV é manter a supressão viral sem comprometer futuras <u>opções de tratamento.</u>  
<mark>A revisão do histórico completo de ARV do paciente – incluindo resposta virológica, toxicidades</mark> associadas e resultados de genotipagens anteriores (se disponíveis) – é fundamental antes de <u>qualquer troca de tratamento.</u>  
O histórico de dispensação de TARV e os resultados de genotipagens realizadas, bem como o histórico de exames de LT-CD4+ e CV-HIV, podem ser acessados na plataforma <u>https://laudo.aids.gov.br/, pelos profissionais cadastrados.</u>  
Há a possibilidade de que mutações de resistência à(s) TARV anteriormente utilizada(s) tenha(m) sido “arquivada(s)”, mesmo se não detectada(s) no teste de genotipagem mais recente. Se houver incerteza quanto à resistência prévia, não é aconselhável mudar o esquema de TARV nas pessoas em com supressão virológica, a menos que o novo esquema seja provavelmente tão ativo contra o vírus potencialmente resistente. A consulta às Câmaras Técnicas e aos MRG é recomendada quando se contempla uma mudança de esquema para um paciente com histórico de resistência a uma ou mais classes de ARV.  
Algumas estratégias de substituição apresentam boa segurança para a troca. Substituições dentro da mesma classe de ARV, seja por eventos adversos ou por ARV que oferecem um perfil de segurança e posologia melhores, são capazes de manter a supressão viral desde que haja boa adesão e ausência de resistência ao novo ARV<sup>203–209</sup> .  
**Após a troca da TARV recomenda-se monitoramento mais intensivo, com o objetivo de avaliar a tolerabilidade, a resposta virológica e a adesão do paciente. Um retorno deve ser agendado entre sete e 15 dias e uma CV-HIV deverá ser solicitada após a troca** .  
Ressalta-se que pacientes em falha virológica devem ter a substituição da TARV guiada por exame de genotipagem (ver seção FALHA AO TRATAMENTO ANTIRRETROVIRAL).

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 12.1. **Substituição de esquemas (troca) em virtude de eventos adversos dos antirretrovirais** -->
<mark>Nem todos os efeitos adversos requerem uma modificação imediata da TARV.</mark>  
Náusea leve ou diarreia no início do tratamento não são eventos incomuns, podendo ser manejados clinicamente. Os efeitos adversos gastrointestinais que ocorrem durante as primeiras semanas muitas vezes melhoram espontaneamente ou podem ser tratados sintomaticamente. O mesmo se aplica a algumas reações alérgicas e a sintomas neuropsiquiátricos.  
<mark>Comunicar-se com o paciente, aconselhando-o sobre como tolerar ou diminuir certos sintomas e</mark> informando que estes não continuarão indefinidamente, geralmente ajuda.  
No entanto, alguns eventos adversos à TARV quase sempre requerem descontinuação e consequente substituição da terapia **(ver seção 14 –** EVENTOS ADVERSOS AOS ANTIRRETROVIRAIS **)** .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 12.2. **Terapia dupla** -->
A “terapia dupla” é composta por lamivudina associada com medicamentos de alta barreira genética – dolutegravir ou darunavir e reforço de ritonavir – e demonstra segurança e eficácia na manutenção da supressão virológica<sup>210–215</sup> .  
Esses esquemas apresentam vantagens relacionadas à facilidade posológica, redução na toxicidade e interações medicamentosas.  
Pessoas que mantêm controle virológico, que apresentam múltiplas comorbidades ou que podem evoluir com alteração da função renal, osteopenia/osteoporose, além daqueles que apresentam intolerância ou evento adverso relacionado a outros ARV, podem se beneficiar da “terapia dupla”.  
A TARV preferencial é:  
1ª opção: Lamivudina 300 mg + dolutegravir 50 mg ou lamivudina/dolutegravir (300/50 mg) em dose fixa combinada.  
2ª opção: Lamivudina + darunavir 800 mg + ritonavir 100 mg  
Para a recomendação da “terapia dupla”, as seguintes condições devem estar necessariamente presentes:  
- Ausência de qualquer falha virológica prévia;  
- Adesão regular à TARV;  
- Carga viral indetectável nos últimos 12 meses, sendo a última CV realizada há  
- pelo menos seis meses;  
- Exclusão de coinfecção com hepatite B ou tuberculose;  
- Idade maior o igual a 18 anos.  
- Não estar gestante;  
- Taxa de filtração glomerular estimada que não implique em redução de dose da  
- lamivudina (TFGe maior que 30 mL/min).  
- Para PVHA com indicação de dolutegravir: não estar em uso de medicamentos que requeiram a dose dobrada de dolutegravir ou que reduzam o nível sérico do medicamento.  
**Neste protocolo, a “terapia dupla” não é recomendada para início de tratamento. A prescrição deve ser realizada de maneira criteriosa, pois a utilização indevida coloca em risco a resposta ao tratamento.**  
Antes da prescrição, deve-se avaliar a presença de interações medicamentosas que possam impactar na escolha. A ferramenta atualmente disponível em português pode ser encontrada no site: https://interacoeshiv.huesped.org.ar/.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **SÍNDROME INFLAMATÓRIA DA RECONSTITUIÇÃO IMUNE: DIAGNÓSTICO E TRATAMENTO** -->
Os seis primeiros meses do início da TARV são especialmente importantes. A melhora clínica e imunológica, assim como a supressão viral são esperados nos indivíduos com adesão à TARV. Entretanto, podem ocorrer IO e/ou a SIRI, bem como desenvolvimento precoce de reação aos medicamentos, como hipersensibilidade, especialmente nos primeiros três meses de tratamento.  
O uso da TARV reduz a mortalidade geral de PVHA. Entretanto, em situações específicas, há um risco aumentado nos primeiros meses do tratamento, como em pessoas que iniciam o tratamento com doença avançada e imunodeficiência grave **(contagem de LT-CD4+ abaixo de 100 células/mm³)** , na presença de coinfecções e/ou comorbidades, anemia, baixo IMC ou desnutrição.  
A reconstituição imune é uma das metas da TARV. Em algumas situações, observa-se um quadro clínico de caráter inflamatório exacerbado, chamado de **SIRI** , associada ao início da TARV. Essa síndrome se manifesta como piora “paradoxal” de doenças preexistentes, geralmente autolimitadas, mas que podem assumir formas graves. São descritas reações inflamatórias relacionadas a infecções fúngicas, virais e bacterianas, além de neoplasias e fenômenos autoimunes.  
É importante diferenciar as infecções subclínicas que aparecem pela primeira vez em pacientes em TARV (“SIRI desmascarada”) e infecções clinicamente evidentes já existentes no início da terapia, que muitas vezes, paradoxalmente, pioram durante a terapia (“SIRI paradoxal”).  
O início da TARV não deve ser postergado por receio de ocorrência da SIRI, uma vez que os benefícios da TARV superam enormemente seus riscos.  
O início da TARV em pacientes com baixas contagens de LT-CD4+ é um fator preditor para ocorrência de SIRI, especialmente havendo história pregressa ou atual de coinfecções ou de IO.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 13.1. **Diagnóstico da SIRI** -->
O diagnóstico da SIRI é clínico e deve ser considerado quando sinais ou sintomas inflamatórios ocorrem entre quatro a oito semanas após o início da TARV, na reintrodução de um esquema interrompido ou na modificação para um esquema mais eficaz após a falha virológica. Observa-se, em geral, aumento na contagem de LT-CD4+ e redução na CV-HIV, o que demonstra a efetividade do tratamento.  
No diagnóstico diferencial, deve ser excluída falha da TARV por má adesão ou resistência viral, falha ao tratamento da coinfecção ou IO, interações medicamentosas e eventos adversos associados à TARV.  
Sinais ou sintomas inflamatórios que ocorrem entre quatro e oito semanas após o início ou modificação da TARV podem ser indicativos de SIRI.  
No diagnóstico diferencial, deve ser excluída falha da TARV por má adesão ou resistência viral, falha ao tratamento da coinfecção ou IO, interações medicamentosas e eventos adversos associados à TARV.  
Uma vez que não existem critérios bem estabelecidos para o diagnóstico da SIRI, normalmente é necessária uma combinação de achados para orientar a suspeita clínica (Quadro 21).  
**Quadro 21:** Critérios para suspeita clínica de SIRI  
- <mark>Piora de doença reconhecida ou surgimento de nova manifestação após início da TARV.</mark>  
- - Contagem de LT-CD4+ abaixo de 100 células/mm³ antes do início ou modificação do esquema.  
- Relação temporal entre o início da TARV e o aparecimento das manifestações inflamatórias (geralmente dentro de quatro a oito semanas do início da TARV).  
- Presença de resposta imune, virológica ou ambas após início da TARV.  
- Exclusão de falha ao tratamento, reação adversa ou superinfecção.  
- Fonte: DATHI/SVSA/MS.  
O Quadro 22 resume as principais apresentações de SIRI conforme as IO.  
**Quadro 22:** Apresentação da SIRI conforme as infecções oportunistas  
|Tuberculose|Agravamento dos sintomas pulmonares ou das imagens radiológicas,<br>além de aumento e/ou fistulização de linfonodos ou piora dos sintomas<br>neurológicos.<br>Surgimento de novas lesões em órgãos inicialmente não acometidos<br>(SNC, linfonodos, pleura, etc).<br>Alterações hepáticas, difíceis de diferenciar da hepatoxicidade<br>induzida pelos medicamentos.|
|---|---|
|Complexo||
|_Mycobacterium_<br>_avium_<br>(MAC)|Linfadenite localizada, doença pulmonar ou doença disseminada|
|_Cryptococcus sp_|Agravamento dos sintomas de meningite e da hipertensão<br>intracraniana|
|Citomegalovírus (CMV)|Surgimento ou agravamento de retinite, vitreíte ou uveíte<br>A retinite ocorre na maioria das vezes no local das inflamações<br>anteriores e pode levar a rápida e permanente perda de visão<br>O tempo médio para vitreíte por SIRI é de 20 semanas após o início da<br>TARV|
|Hepatite B ou C|Elevações transitórias das transaminases, difíceis de distinguir da<br>hepatotoxicidadeinduzida por medicamentos|
|Leucoencefalopatia<br>multifocal<br>progressiva<br>(LEMP)|Lesões de LEMP podem aparecer com agravamento ou novos déficits<br>neurológicos focais|
|Sarcoma deKaposi|Agravamento da doença|
|Doenças autoimunes|Exacerbação de doenças autoimunes preexistentes, como sarcoidose|
|Vírus herpes simples e<br>vírus varicela-zoster|Pode haver reativação de HSV e VZV após o início da TARV|
|Complicações<br>dermatológicas<br>inespecíficas|Aparecimento ou piora das manifestações dermatológicas, tais como<br>foliculites, verrugas orais e genitais|  
Fonte: DATHI/SVSA/MS.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: 13.2. **Tratamento da SIRI** -->
A prevenção das complicações associadas à SIRI envolve identificação e manejo precoce.  
Na suspeita de SIRI, deve-se priorizar o diagnóstico e tratamento da IO. Na maior parte dos casos, sua resolução é espontânea, envolvendo tratamento sintomático. Ressalta-se que a TARV não deverá ser interrompida, exceto em casos graves, em particular, nas neuroinfecções por tuberculose e criptococo.  
Nos casos mais intensos, terapia anti-inflamatória pode ser necessária, incluindo corticosteroides, nos casos graves. Nessas situações, prednisona 0,5 a 1,5 mg/kg/dia, ou equivalente, durante uma a duas semanas, com posterior e gradual retirada. Metiprednisolona (1g/dia) ou dexametasona (0,3mg/kg/dia) intravenosas, em casos mais críticos ou pacientes sem tolerância a medicação oral, são opções. Nos casos de Sarcoma de Kaposi (HHV-8) o corticoide não deve ser utilizado<sup>216–218</sup> .

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **REFERÊNCIAS** -->
1.  PREFEITURA MUNICIPAL DE SÃO PAULO. Secretaria Municipal de Assistência e Desenvolvimento Social - SMADS. Pesquisa censitária da população em situação de rua, caracterização socioeconômica da população adulta em situação de rua e relatório temático de identificação das necessidades. 2021.  
2.  BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde e Ambiente. Boletim Epidemiológico Tuberculose, Número Especial, Mar.2023. 2022.  
3.  BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis. Protocolo de vigilância da infecção latente pelo Mycobacterium tuberculosis no Brasil – 2. ed. – Brasília: Ministério da Saúde, 2022. [Internet]. Available from: www.saude.gov.br/tuberculose  
4.  WHO consolidated guidelines on tuberculosis. Module 1: prevention – tuberculosis preventive treatment. Geneva: World Health Organization; 2020  
5.  The TEMPRANO ANRS 12136 Study Group. A Trial of Early Antiretrovirals and Isoniazid Preventive Therapy in Africa. New England Journal of Medicine. 2015;373(9).  
6.  Badje A, Moh R, Gabillard D, Guéhi C, Kabran M, Ntakpé JB, et al. Effect of isoniazid preventive therapy on risk of death in west African, HIV-infected adults with high CD4 cell counts: longterm follow-up of the Temprano ANRS 12136 trial. Lancet Glob Health. 2017;5(11).  
7.  World Health Organization. WHO consolidated guidelines on tuberculosis Module 2: Screening Systematic screening for tuberculosis disease Web Annex B. GRADE Summary of Findings Tables. WHO Press. 2020;  
8.  BRASIL. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Relatório de Recomendação nº 591/2021 - Teste lipoarabinomanano de fluxo lateral na urina (LFLAM) para rastreamento e diagnóstico de tuberculose ativa em pessoas suspeitas vivendo com HIV/AIDS.  
9.  Songkhla MN, Tantipong H, Tongsai S, Angkasekwinai N. Lateral flow urine lipoarabinomannan assay for diagnosis of active tuberculosis in adults with human immunodeficiency virus infection: A prospective cohort study. Open Forum Infect Dis. 2019;6(4).  
10.  Huerga H, Ferlazzo G, Bevilacqua P, Kirubi B, Ardizzoni E, Wanjala S, et al. Incremental yield of including determine-TB LAM assay in diagnostic algorithms for hospitalized and ambulatory HIV-positive patients in Kenya. PLoS One. 2017;12(1).  
11.  Huerga H, Mathabire Rucker SC, Cossa L, Bastard M, Amoros I, Manhiça I, et al. Diagnostic value of the urine lipoarabinomannan assay in HIV-positive, ambulatory patients with CD4 below 200 cells/μl in 2 low-resource settings: A prospective observational study. Vol. 16, PLoS Medicine. 2019.  
12.  Benjamin A, Cavalcante SC, Jamal LF, Arakaki-Sanchez D, De Lima JN, Pilotto JH, et al. Accuracy of Determine TB-LAM Ag to detect TB in HIV infected patients associated with diagnostic methods used in Brazilian public health units. PLoS One. 2019;14(9).  
13.  Correction to Lancet Infect Dis 2022; published online Aug 29. https://doi.org/10.1016/S14733099(22)00499-6 (The Lancet Infectious Diseases (2022) 22(12) (1748–1755), (S1473309922004996), (10.1016/S1473-3099(22)00499-6)). Vol. 23, The Lancet Infectious Diseases. 2023.  
14.  Rajasingham R, Govender NP, Jordan A, Loyse A, Shroufi A, Denning DW, et al. The global burden of HIV-associated cryptococcal infection in adults in 2020: a modelling analysis. Lancet Infect Dis. 2022;22(12).  
15.  Firacative C, Lizarazo J, Illnait-Zaragozí MT, Castañeda E, Arechavala A, Córdoba S, et al. The status of cryptococcosis in latin America. Vol. 113, Memorias do Instituto Oswaldo Cruz. 2018.  
16.  Jarvis JN, Bicanic T, Loyse A, Namarika D, Jackson A, Nussbaum JC, et al. Determinants of mortality in a combined cohort of 501 patients with HIV-associated cryptococcal meningitis: Implications for improving outcomes. Clinical Infectious Diseases. 2014;58(5).  
17.  Williams DA, Kiiza T, Kwizera R, Kiggundu R, Velamakanni S, Meya DB, et al. Evaluation of Fingerstick Cryptococcal Antigen Lateral Flow Assay in HIV-Infected Persons: A Diagnostic Accuracy Study. Clinical Infectious Diseases. 2015;61(3).  
18.  Rajasingham R, Meya DB, Boulware DR. Integrating cryptococcal antigen screening and preemptive treatment into routine HIV care. J Acquir Immune Defic Syndr (1988). 2012;59(5).  
19.  Boulware DR, Rolfes MA, Rajasingham R, von Hohenberg M, Qin Z, Taseera K, et al. Multisite validation of cryptococcal antigen lateral flow assay and quantification by laser thermal contrast. Emerg Infect Dis. 2014;20(1).  
20.  BRASIL. Ministério da Saúde. Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec). Relatório de Recomendação n<sup>o</sup> 615//2021 - Teste diagnóstico, point of care, de Cryptococcal Antigen Lateral Flow Assay (Crag-LFA) para detecção de infecção por Cryptococcus e diagnóstico de meningite criptocócica em pessoas com HIV/AIDS. [Internet]. Available from: http://conitec.gov.br/  
21.  Vidal JE, Toniolo C, Paulino A, Colombo A, dos Anjos Martins M, da Silva Meira C, et al. Asymptomatic cryptococcal antigen prevalence detected by lateral flow assay in hospitalised HIV-infected patients in São Paulo, Brazil. Tropical Medicine and International Health. 2016;21(12).  
22.  Cohen MS, Chen YQ, McCauley M, Gamble T, Hosseinipour MC, Kumarasamy N, et al. Antiretroviral Therapy for the Prevention of HIV-1 Transmission. New England Journal of Medicine. 2016;375(9).  
23.  Rodger AJ, Cambiano V, Phillips AN, Bruun T, Raben D, Lundgren J, et al. Risk of HIV transmission through condomless sex in serodifferent gay couples with the HIV-positive partner taking suppressive antiretroviral therapy (PARTNER): final results of a multicentre, prospective, observational study. The Lancet. 2019;393(10189).  
24.  The INSIGHT START Study Group. Initiation of Antiretroviral Therapy in Early Asymptomatic HIV Infection. New England Journal of Medicine. 2015;373(9).  
25.  O’Connell S, Enkelmann J, Sadlier C, Bergin C. Late HIV presentation – missed opportunities and factors associated with a changing pattern over time. Int J STD AIDS. 2017;28(8).  
26.  Samji H, Cescon A, Hogg RS, Modur SP, Althoff KN, Buchacz K, et al. Closing the gap: Increases in life expectancy among treated HIV-positive individuals in the United States and Canada. PLoS One. 2013;8(12).  
27.  Palella FJ, Armon C, Chmiel JS, Brooks JT, Hart R, Lichtenstein K, et al. CD4 cell count at initiation of ART, long-term likelihood of achieving CD4 >750 cells/mm3 and mortality risk. Journal of Antimicrobial Chemotherapy. 2016;71(9).  
28.  Moore RD, Keruly JC. CD4+ cell count 6 years after commencement of highly active antiretroviral therapy in persons with sustained virologic suppression. Clinical Infectious Diseases. 2007;44(3).  
29.  Mellors JW, Muñoz A, Giorgi J V., Margolick JB, Tassoni CJ, Gupta P, et al. Plasma viral load and CD4+ lymphocytes as prognostic markers of HIV-1 infection. Ann Intern Med. 1997;126(12).  
30.  Egger M, May M, Chêne G, Phillips AN, Ledergerber B, Dabis F, et al. Prognosis of HIV-1infected patients starting highly active antiretroviral therapy: A collaborative analysis of prospective studies. Lancet. 2002;360(9327).  
31.  Mateo-Urdiales A, Johnson S, Smith R, Nachega JB, Eshun-Wilson I. Rapid initiation of antiretroviral therapy for people living with HIV. Cochrane Database of Systematic Reviews. 2019;  
32.  Michienzi SM, Barrios M, Badowski ME. Evidence Regarding Rapid Initiation of Antiretroviral Therapy in Patients Living with HIV. Vol. 23, Current Infectious Disease Reports. 2021.  
33.  Pilcher CD, Ospina-Norvell C, Dasgupta A, Jones D, Hartogensis W, Torres S, et al. The Effect of Same-Day Observed Initiation of Antiretroviral Therapy on HIV Viral Load and Treatment Outcomes in a US Public Health Setting. J Acquir Immune Defic Syndr (1988). 2017;74(1).  
34.  Labhardt ND, Ringera I, Lejone TI, Klimkait T, Muhairwe J, Amstutz A, et al. Effect of offering same-day ART vs usual health facility referral during home-based HIV testing on linkage to care and viral suppression among adults with HIV in Lesotho: The CASCADE randomized clinical trial. In: JAMA - Journal of the American Medical Association. 2018.  
35.  Coffey S, Bacchetti P, Sachdev D, Bacon O, Jones D, Ospina-Norvell C, et al. RAPID antiretroviral therapy: High virologic suppression rates with immediate antiretroviral therapy initiation in a vulnerable urban clinic population. AIDS. 2019;33(5).  
36.  Black S, Zulliger R, Myer L, Marcus R, Jeneker S, Taliep R, et al. Safety, feasibility and efficacy of a rapid ART initiation in pregnancy pilot programme in Cape Town, South Africa. South African Medical Journal. 2013;103(8).  
37.  Colasanti J, Sumitani J, Christina Mehta C, Zhang Y, Nguyen ML, Del Rio C, et al. Implementation of a rapid entry program decreases time to viral suppression among vulnerable persons living with HIV in the southern United States. Open Forum Infect Dis. 2018;5(6).  
38.  Rosen S, Maskew M, Fox MP, Nyoni C, Mongwenyana C, Malete G, et al. Initiating Antiretroviral Therapy for HIV at a Patient’s First Clinic Visit: The RapIT Randomized Controlled Trial. PLoS Med. 2016;13(5).  
39.  Ford N, Darder M, Spelman T, Maclean E, Mills E, Boulle A. Early adherence to antiretroviral medication as a predictor of long-term HIV virological suppression: Five-year follow up of an observational cohort. PLoS One. 2010;5(5).  
40.  Protopopescu C, Carrieri MP, Raffi F, Picard O, Hardel L, Piroth L, et al. Prolonged viral suppression over a 12-year follow-up of HIV-infected patients: The persistent impact of adherence at 4 months after initiation of combined antiretroviral therapy in the anrs co8 aprococopilote cohort. J Acquir Immune Defic Syndr (1988). 2017;74(3).  
41.  Brennan AT, Larson B, Tsikhutsu I, Bii M, Fox MP, Venter WD, et al. Same-day art initiation in the slate trial in Kenya: Preliminary results. Top Antivir Med. 2019;27(SUPPL 1).  
42.  Organization WH. Consolidated guidelines on HIV testing services for a changing epidemic. Policy Briefs. 2019;(November).  
43.  World Health Organization. Guidelines for Managing Advanced HIV Disease and Rapid Initiation of Antiretroviral Therapy. Behaviour and Information Technology. 2017;2(2).  
44.  Neely MN, Benning L, Xu J, Strickler HD, Greenblatt RM, Minkoff H, et al. Cervical shedding of HIV-1 RNA among women with low levels of viremia while receiving highly active antiretroviral therapy. J Acquir Immune Defic Syndr (1988). 2007;44(1).  
45.  Fiore JR, Suligoi B, Saracino A, Di Stefano M, Bugarini R, Lepera A, et al. Correlates of HIV-1 shedding in cervicovaginal secretions and effects of antiretroviral therapies. AIDS. 2003;17(15).  
46.  Lambert-Niclot S, Tubiana R, Beaudoux C, Lefebvre G, Caby F, Bonmarchand M, et al. Detection of HIV-1 RNA in seminal plasma samples from treated patients with undetectable HIV-1 RNA in blood plasma on a 2002-2011 survey. Vol. 26, AIDS. 2012.  
47.  Piazza M. A combination of nucleoside analogues and a protease inhibitor reduces HIV-1 RNA levels in semen: Implications for sexual transmission of HIV infection. Antivir Ther. 1999;4(2).  
48.  Coombs RW, Reichelderfer PS, Landay AL. Recent observations on HIV type-1 infection in the genital tract of men and women. Vol. 17, AIDS. 2003.  
49.  Vernazza PL, Troiani L, Flepp MJ, Cone RW, Schock J, Roth F, et al. Potent antiretroviral treatment of HIV-infection results in suppression of the seminal shedding of HIV. AIDS. 2000;14(2).  
50.  Tovanabutra S, Robison V, Wongtrakul J, Sennum S, Suriyanon V, Kingkeow D, et al. Male viral load and heterosexual transmission of HIV-1 subtype E in Northern Thailand. J Acquir Immune Defic Syndr (1988). 2002;29(3).  
51.  Quinn TC, Wawer MJ, Sewankambo N, Serwadda D, Li C, Wabwire-Mangen F, et al. Viral Load and Heterosexual Transmission of Human Immunodeficiency Virus Type 1. New England Journal of Medicine. 2000;342(13).  
52.  Porco TC, Martin JN, Page-Shafer KA, Cheng A, Chadebois E, Grant RM, et al. Decline in HIV infectivity following the introduction of highly active antiretroviral therapy. AIDS. 2004;18(1).  
53.  Barreiro P, Del Romero J, Leal M, Hernando V, Asencio R, De Mendoza C, et al. Natural pregnancies in HIV-serodiscordant couples receiving successful antiretroviral therapy. Vol. 43, Journal of Acquired Immune Deficiency Syndromes. 2006.  
54.  LeMessurier J, Traversy G, Varsaneux O, Weekes M, Avey MT, Niragira O, et al. Risk of sexual transmission of human immunodeficiency virus with antiretroviral therapy, suppressed viral load and condom use: A systematic review. CMAJ. 2018;190(46).  
55.  Attia S, Egger M, Müller M, Zwahlen M, Low N. Sexual transmission of HIV according to viral load and antiretroviral therapy: Systematic review and meta-analysis. AIDS. 2009;23(11).  
56.  Eisinger RW, Dieffenbach CW, Fauci AS. HIV Viral Load and Transmissibility of HIV Infection. JAMA. 2019;321(5).  
57.  Rodger AJ, Cambiano V, Bruun T, Vernazza P, Collins S, Van Lunzen J, et al. Sexual activity without condoms and risk of HIV transmission in serodifferent couples when the HIV-positive partner is using suppressive antiretroviral therapy. JAMA - Journal of the American Medical Association. 2016;316(2).  
58.  Bavinton BR, Pinto AN, Phanuphak N, Grinsztejn B, Prestage GP, Zablotska-Manos IB, et al. Viral suppression and HIV transmission in serodiscordant male couples: an international, prospective, observational, cohort study. Lancet HIV. 2018;5(8).  
59.  Cook R, Davidson P, Martin R. Antiretroviral treatment can reduce the risk of HIV transmission between male partners to “zero.” The BMJ. 2019;366.  
60.  Bavinton B, Grinsztejn B, Phanuphak N, JIN F, Zablotska I, Prestage G, et al. HIV treatment prevents HIV transmission in male serodiscordant couples in Australia, Thailand, and Brazil. In: 9th International AIDS Society Conference on HIV Science. 2017.  
61.  Cohen MS, Chen YQ, McCauley M, Gamble T, Hosseinipour MC, Kumarasamy N, et al. Prevention of HIV-1 Infection with Early Antiretroviral Therapy. New England Journal of Medicine. 2011;365(6).  
62.  Rodger AJ, Cambiano V, Bruun T, Vernazza P, Collins S, Van Lunzen J, et al. Sexual activity without condoms and risk of HIV transmission in serodifferent couples when the HIV-positive partner is using suppressive antiretroviral therapy. JAMA - Journal of the American Medical Association. 2016;316(2).  
63.  Broyles LN, Luo R, Boeras D, Vojnov L. The risk of sexual transmission of HIV in individuals with low-level HIV viraemia: a systematic review. Lancet [Internet]. 2023 Jul 21; Available from: http://www.ncbi.nlm.nih.gov/pubmed/37490935  
64.  WHO policy brief. The role of hiv viral suppression in improving individual health and reducing transmission policy. July, 2023.  
65.  Havlir D V., Kendall MA, Ive P, Kumwenda J, Swindells S, Qasba SS, et al. Timing of Antiretroviral Therapy for HIV-1 Infection and Tuberculosis. New England Journal of Medicine. 2011;365(16).  
66.  Sinha S, Shekhar RC, Singh G, Shah N, Ahmad H, Kumar N, et al. Early versus delayed initiation of antiretroviral therapy for Indian HIV-Infected individuals with tuberculosis on antituberculosis treatment. BMC Infect Dis. 2012;12.  
67.  Blanc FX, Sok T, Laureillard D, Borand L, Rekacewicz C, Nerrienet E, et al. Earlier versus Later Start of Antiretroviral Therapy in HIV-Infected Adults with Tuberculosis. New England Journal of Medicine. 2011;365(16).  
68.  Amogne W, Aderaye G, Habtewold A, Yimer G, Makonnen E, Worku A, et al. Efficacy and safety of antiretroviral therapy initiated one week after tuberculosis therapy in patients with CD4 counts < 200 cells/μL: TB-HAART study, a randomized clinical trial. PLoS One. 2015;10(5).  
69.  Manosuthi W, Mankatitham W, Lueangniyomkul A, Thongyen S, Likanonsakul S, Suwanvattana P, et al. Time to initiate antiretroviral therapy between 4 weeks and 12 weeks of tuberculosis treatment in HIV-infected patients: Results From the TIME study. J Acquir Immune Defic Syndr (1988). 2012;60(4).  
70.  Abdool Karim SS, Naidoo K, Grobler A, Padayatchi N, Baxter C, Gray A, et al. Timing of Initiation of Antiretroviral Drugs during Tuberculosis Therapy. New England Journal of Medicine. 2010;362(8).  
71.  Burke RM, Rickman HM, Singh V, Corbett EL, Ayles H, Jahn A, et al. What is the optimum time to start antiretroviral therapy in people with HIV and tuberculosis coinfection? A systematic review and meta-analysis. Vol. 24, Journal of the International AIDS Society. 2021.  
72.  Török ME, Yen NTB, Chau TTH, Mai NTH, Phu NH, Mai PP, et al. Timing of initiation of antiretroviral therapy in human immunodeficiency virus (HIV)-associated tuberculous meningitis. Clinical Infectious Diseases. 2011;52(11).  
73.  Lawn SD, Wood R. Poor prognosis of HIV-associated tuberculous meningitis regardless of the timing of antiretroviral therapy. Vol. 52, Clinical Infectious Diseases. 2011.  
74.  Burman W, Weis S, Vernon A, Khan A, Benator D, Jones B, et al. Frequency, severity and duration of immune reconstitution events in HIV-related tuberculosis. International Journal of Tuberculosis and Lung Disease. 2007;11(12).  
75.  Müller M, Wandel S, Colebunders R, Attia S, Furrer H, Egger M. Immune reconstitution inflammatory syndrome in patients starting antiretroviral therapy for HIV infection: a systematic review and meta-analysis. Vol. 10, The Lancet Infectious Diseases. 2010.  
76.  Scriven JE, Rhein J, Hullsiek KH, Von Hohenberg M, Linder G, Rolfes MA, et al. Early ART after cryptococcal meningitis is associated with cerebrospinal fluid pleocytosis and macrophage activation in a multisite randomized trial. Journal of Infectious Diseases. 2015;212(5).  
77.  Eshun-Wilson I, Okwen MP, Richardson M, Bicanic T. Early versus delayed antiretroviral treatment in HIV-positive people with cryptococcal meningitis. Vol. 2018, Cochrane Database of Systematic Reviews. 2018.  
78.  Guidelines for diagnosing, preventing and managing cryptococcal disease among adults, adolescents and children living with HIV. Geneva: World Health Organization; 2022.  
79.  Ingle SM, Miro JM, May MT, Cain LE, Schwimmer C, Zangerle R, et al. Early Antiretroviral Therapy Not Associated With Higher Cryptococcal Meningitis Mortality in People With Human Immunodeficiency Virus in High-Income Countries: An International Collaborative Cohort Study. Clinical Infectious Diseases [Internet]. 2023 Mar 8; Available from: https://academic.oup.com/cid/advance-article/doi/10.1093/cid/ciad122/7072297  
80.  Choudhary SK, Vrisekoop N, Jansen CA, Otto SA, Schuitemaker H, Miedema F, et al. Low Immune Activation despite High Levels of Pathogenic Human Immunodeficiency Virus Type 1 Results in Long-Term Asymptomatic Disease. J Virol. 2007;81(16).  
81.  Morin SF, Koester KA, Steward WT, Maiorana A, McLaughlin M, Myers JJ, et al. Missed opportunities: Prevention with HIV-infected patients in clinical care settings. J Acquir Immune Defic Syndr (1988). 2004;36(4).  
82.  Hunt PW, Brenchley J, Sinclair E, McCune JM, Roland M, Page-Shafer K, et al. Relationship between T cell activation and CD4+ T cell count in HIV-seropositive individuals with undetectable plasma HIV RNA levels in the absence of therapy. Journal of Infectious Diseases. 2008;197(1).  
83.  Pereyra F, Lo J, Triant VA, Wei J, Buzon MJ, Fitch K V., et al. Increased coronary atherosclerosis and immune activation in HIV-1 elite controllers. AIDS. 2012;26(18).  
84.  Hsue PY, Hunt PW, Schnell A, Kalapus SC, Hoh R, Ganz P, et al. Role of viral replication, antiretroviral therapy, and immunodeficiency in HIV-associated atherosclerosis. AIDS. 2009;23(9).  
85.  Krishnan S, Wilson EMP, Sheikh V, Rupert A, Mendoza D, Yang J, et al. Evidence for innate immune system activation in HIV type 1-infected elite controllers. Journal of Infectious Diseases. 2014;209(6).  
86.  World Health Organization. Surveillance of HIV Drug Resistance in Adults Initiating Antiretroviral Therapy (Pre-Treatment HIV Drug Resistance). WwwWhoInt/Hiv/Pub/Grudresistance/En/. 2014;350(10).  
87.  Coelho LPO, Matsuda EM, Nogueira RS, de Moraes MJ, Jamal LF, Madruga JVR, et al. Prevalence of HIV-1 transmitted drug resistance and viral suppression among recently diagnosed adults in São Paulo, Brazil. Arch Virol. 2019;164(3).  
88.  Bertagnolio S, Hermans L, Jordan MR, Avila-Rios S, Iwuji C, Derache A, et al. Clinical impact of pretreatment human immunodeficiency virus drug resistance in people initiating nonnucleoside reverse transcriptase inhibitor-containing antiretroviral therapy: A systematic review and metaanalysis. Vol. 224, Journal of Infectious Diseases. 2021.  
89.  Arruda MB, Boullosa LT, Cardoso CC, da Costa CM, Brites C, de Lima STS, et al. Brazilian network for HIV drug resistance surveillance (HIV-BresNet): A survey of treatment-naive individuals. J Int AIDS Soc. 2018;21(3).  
90.  Tanaka TSO, Cesar GA, Rezende GR de, Puga MAM, Weis-Torres SM dos S, Bandeira LM, et al. Molecular Epidemiology of HIV-1 among Prisoners in Central Brazil and Evidence of Transmission Clusters. Viruses. 2022 Aug 1;14(8).  
91.  Bahls LD, Canezin PH, Reiche EMV, Fernandez JCC, Dias JRC, Meneguetti VAF, et al. Moderate prevalence of HIV-1 transmitted drug resistance mutations in southern Brazil. AIDS Res Ther. 2019 Feb 5;16(1).  
92.  Ferreira ACG, Coelho LE, Grinsztejn E, Jesus CS de, Guimarães ML, Veloso VG, et al. Transmitted drug resistance in patients with acute/recent HIV infection in Brazil. Brazilian Journal of Infectious Diseases. 2017 Jul 1;21(4):396–401.  
93.  Saúde M DA. Brasil. Ministério da Saúde. Secretaria de Vigilância em Saúde. Departamento de Vigilância das Doenças Transmissíveis. Manual de Recomendações para o Controle da Tuberculose no Brasil / Ministério da Saúde, Secretaria de Vigilância em Saúde, Departamento de Vigilância das Doenças Transmissíveis. – Brasília: Ministério da Saúde, 2019. [Internet]. Available from: www.saude.gov.br/  
94.  Dooley KE, Kaplan R, Mwelase N, Grinsztejn B, Ticona E, Lacerda M, et al. Dolutegravir-based Antiretroviral Therapy for Patients Coinfected with Tuberculosis and Human Immunodeficiency Virus: A Multicenter, Noncomparative, Open-label, Randomized Trial. Clinical Infectious Diseases. 2020;70(4).  
95.  Dooley KE, Sayre P, Borland J, Purdy E, Chen S, Song I, et al. Safety, tolerability, and pharmacokinetics of the HIV integrase inhibitor dolutegravir given twice daily with rifampin or once daily with rifabutin: Results of a phase 1 study among healthy subjects. J Acquir Immune Defic Syndr (1988). 2013;62(1).  
96.  Jiang HY, Zhang MN, Chen HJ, Yang Y, Deng M, Ruan B. Nevirapine versus efavirenz for patients co-infected with HIV and tuberculosis: A systematic review and meta-analysis. Vol. 25, International Journal of Infectious Diseases. 2014.  
97.  Atwine D, Bonnet M, Taburet AM. Pharmacokinetics of efavirenz in patients on antituberculosis treatment in high human immunodeficiency virus and tuberculosis burden countries: A systematic review. Vol. 84, British Journal of Clinical Pharmacology. 2018.  
98.  Luetkemeyer AF, Rosenkranz SL, Lu D, Marzan F, Ive P, Hogg E, et al. Relationship between weight, efavirenz exposure, and virologic suppression in HIV-infected patients on rifampin-based  
tuberculosis treatment in the AIDS clinical trials group A5221 STRIDE study. Clinical Infectious Diseases. 2013;57(4).  
99.  Cohen K, Grant A, Dandara C, McIlleron H, Pemba L, Fielding K, et al. Effect of rifampicinbased antitubercular therapy and the cytochrome P450 2B6 516G>T polymorphism on efavirenz concentrations in adults in South Africa. Antivir Ther. 2009;14(5).  
100. Boulle A, Van Cutsem G, Cohen K, Hilderbrand K, Mathee S, Abrahams M, et al. Outcomes of nevirapine- and efavirenz-based antiretroviral therapy when coadministered with rifampicin-based antitubercular therapy. JAMA. 2008;300(5).  
101. GLOBAL ACTION PLAN ON HIV DRUG RESISTANCE [Internet]. 2017. Available from: http://apps.who.int/bookorders.  
102. Semengue ENJ, Fokam J, Etame NK, Molimbou E, Chenwi CA, Takou D, et al. Dolutegravir-Based Regimen Ensures High Virological Success despite Prior Exposure to Efavirenz-Based First-LINE ART in Cameroon: An Evidence of a Successful Transition Model. Viruses. 2023;15(1).  
103. Pereira GFM, Kim A, Jalil EM, Fernandes Fonseca F, Shepherd BE, Veloso VG, et al. Dolutegravir and pregnancy outcomes in women on antiretroviral therapy in Brazil: a retrospective national cohort study. Lancet HIV. 2021;8(1).  
104. Rebecca Zash et al. Update on neural tube defects with antiretoviral exposure in the Tsepamo study, Botswana. In: Abstract PEBLB14; IAS 2021 abstract book., editor. 2021.  
105. Jessica Albano et al. Integrase Inhibitor Exposure and CNS and Neural Tube Defects: Data from the Antiretroviral Pregnancy Registry (APR). . In: Conference on Retroviruses and Opportunistic Infections, editor. 2018.  
106. Money D, Lee T, O’Brien C, Brophy J, Bitnun A, Kakkar F, et al. Congenital anomalies following antenatal exposure to dolutegravir: a Canadian surveillance study. BJOG. 2019;126(11).  
107. Patel K, Huo Y, Jao J, Powis KM, Williams PL, Kacanek D, et al. Dolutegravir in Pregnancy as Compared with Current HIV Regimens in the United States. New England Journal of Medicine. 2022;387(9).  
108. Saúde M DA. saúde das mulheres [Internet]. 2016. Available from: www.dab.saude.gov.br  
109. Brazil. Departamento de Atenção Básica. Atenção ao pré-natal de baixo risco. 316 p.  
110. WHO. Consolidated guidelines on HIV prevention, testing, treatment, service delivery and monitoring: recommendations for a public health approach. Geneva: World Health Organization. 2021.  
111. Dube MP. , Stein JH. AJA. Panel on Antiretroviral Guidelines for Adults and Adolescents. Guidelines for the Use of Antiretroviral Agents in Adults and Adolescents with HIV. Department of Health and Human Services. 2021;40(Build 29393).  
112. BRASIL. Portaria n.º 25, de 18 de maio de 2023. decisão de atualizar, no âmbito do Sistema Único de Saúde - SUS, o Protocolo Clínico e Diretrizes Terapêuticas de Hepatite B e Coinfecções.  
113. Arribas JR, Pozniak AL, Gallant JE, DeJesus E, Gazzard B, Campo RE, et al. Tenofovir disoproxil fumarate, emtricitabine, and efavirenz compared with zidovudine/lamivudine and  
efavirenz in treatment-naive patients: 144-Week analysis. J Acquir Immune Defic Syndr (1988). 2008;47(1).  
114. Gallant JE, DeJesus E, Arribas JR, Pozniak AL, Gazzard B, Campo RE, et al. Tenofovir DF, Emtricitabine, and Efavirenz vs. Zidovudine, Lamivudine, and Efavirenz for HIV. New England Journal of Medicine. 2006;354(3).  
115. Sax PE, Tierney C, Collier AC, Fischl MA, Mollan K, Peeples L, et al. Abacavir– Lamivudine versus Tenofovir–Emtricitabine for Initial HIV-1 Therapy. New England Journal of Medicine. 2009;361(23).  
116. Casado JL. Renal and bone toxicity with the use of tenofovir: Understanding at the end. AIDS Rev. 2016;18(2).  
117. Gervasoni C, Meraviglia P, Landonio S, Baldelli S, Fucile S, Castagnoli L, et al. Low body weight in females is a risk factor for increased tenofovir exposure and drug-related adverse events. PLoS One. 2013;8(12).  
118. Goicoechea M, Liu S, Best B, Sun S, Jain S, Kemper C, et al. Greater tenofovir-associated renal function decline with protease inhibitor-based versus nonnucleoside reverse-transcriptase inhibitor-based therapy. Journal of Infectious Diseases. 2008;197(1).  
119. Gallant JE, Winston JA, DeJesus E, Pozniak AL, Chen SS, Cheng AK, et al. The 3-year renal safety of a tenofovir disoproxil fumarate vs. a thymidine analogue-containing regimen in antiretroviral-naive patients. AIDS. 2008;22(16).  
120. McComsey GA, Kitch D, Daar ES, Tierney C, Jahed NC, Tebas P, et al. Bone mineral density and fractures in antiretroviral-naive persons randomized to receive abacavir-lamivudine or tenofovir disoproxil fumarate-emtricitabine along with efavirenz or atazanavir-ritonavir: AIDS Clinical Trials Group A5224s, a substudy of ACTG A5202. Journal of Infectious Diseases. 2011;203(12).  
121. Hetherington S, McGuirk S, Powell G, Cutrell A, Naderer O, Spreen B, et al. Hypersensitivity reactions during therapy with the nucleoside reverse transcriptase inhibitor abacavir. Clin Ther. 2001;23(10).  
122. Kearney BP, Mathias A, Mittan A, Sayre J, Ebrahimi R, Cheng AK. Pharmacokinetics and safety of tenofovir disoproxil fumarate on coadministration with lopinavir/ritonavir. J Acquir Immune Defic Syndr (1988). 2006;43(3).  
123. Gallant JE, Moore RD. Renal function with use of a tenofovir-containing initial antiretroviral regimen. AIDS. 2009;23(15).  
124. Hall AM, Hendry BM, Nitsch D, Connolly JO. Tenofovir-associated kidney toxicity in HIV-infected patients: A review of the evidence. Vol. 57, American Journal of Kidney Diseases. 2011.  
125. Zimmermann AE, Pizzoferrato T, Bedford J, Morris A, Hoffman R, Braden G. Tenofovirassociated acute and chronic kidney disease: A case of multiple drug interactions. Vol. 42, Clinical Infectious Diseases. 2006.  
126. Karras A, Lafaurie M, Furco A, Bourgarit A, Droz D, Sereni D, et al. Tenofovir-related nephrotoxicity in human immunodeficiency virus-infected patients: Three cases of renal failure, fanconi syndrome, and nephrogenic diabetes insipidus. Clinical Infectious Diseases. 2003;36(8).  
127. Scherzer R, Estrella M, Li Y, Choi AI, Deeks SG, Grunfeld C, et al. Association of tenofovir exposure with kidney disease risk in HIV infection. AIDS. 2012;26(7).  
128. Stellbrink HJ, Orkin C, Arribas JR, Compston J, Gerstoft J, Van Wijngaerden E, et al. Comparison of changes in bone density and turnover with abacavir-lamivudine versus tenofoviremtricitabine in HIV-infected adults: 48-week results from the ASSERT study. Clinical Infectious Diseases. 2010;51(8).  
129. Gibb DM, Kizito H, Russell EC, Chidziva E, Zalwango E, Nalumenya R, et al. Pregnancy and infant outcomes among HIV-infected women taking long-term art with and without tenofovir in the DART trial. PLoS Med. 2012;9(5).  
130. Nurutdinova D, Onen NF, Hayes E, Mondy K, Overton ET. Adverse effects of tenofovir use in HIV-infected pregnant women and their infants. Annals of Pharmacotherapy. 2008;42(11).  
131. Daar ES, Tierney C, Fischl MA, Sax PE, Mollan K, Budhathoki C, et al. Atazanavir plus ritonavir or efavirenz as part of a 3-drug regimen for initial treatment of HIV-1: A randomized trial. Ann Intern Med. 2011;154(7).  
132. Bansi L, Sabin C, Gilson R, Gazzard B, Leen C, Anderson J, et al. Virological response to initial antiretroviral regimens containing abacavir or tenofovir. Journal of Infectious Diseases. 2009;200(5).  
133. Mallal S, Phillips E, Carosi G, Molina JM, Workman C, Tomažič J, et al. HLA-B*5701 Screening for Hypersensitivity to Abacavir. New England Journal of Medicine. 2008;358(6).  
134. Saag MS, Balu R, Phillips E, Brachman P, Martorell C, Burman W, et al. High sensitivity of human leukocyte antigen-B*5701 as a marker for immunologically confirmed abacavir hypersensitivity in white and black patients. Clinical Infectious Diseases. 2008;46(7).  
135. Sabin CA, Worm SW, Weber R, Reiss P, El-Sadr W, Dabis F, et al. Use of nucleoside reverse transcriptase inhibitors and risk of myocardial infarction in HIV-infected patients enrolled in the D:A:D study: A multi-cohort collaboration. The Lancet. 2008;371(9622).  
136. Dorjee K, Choden T, Baxi SM, Steinmaus C, Reingold AL. Risk of cardiovascular disease associated with exposure to abacavir among individuals with HIV: A systematic review and metaanalyses of results from 17 epidemiologic studies. Vol. 52, International Journal of Antimicrobial Agents. 2018.  
137. Eyawo O, Brockman G, Goldsmith CH, Hull MW, Lear SA, Bennett M, et al. Risk of myocardial infarction among people living with HIV: An updated systematic review and metaanalysis. Vol. 9, BMJ Open. 2019.  
138. Khawaja AA, Taylor KA, Lovell AO, Nelson M, Gazzard B, Boffito M, et al. HIV Antivirals Affect Endothelial Activation and Endothelial-Platelet Crosstalk. Circ Res. 2020;127(11).  
139. Lewis W, Dalakas MC. Mitochondrial toxicity of antiviral drugs. Vol. 1, Nature Medicine. 1995.  
140. Cahn P, Pozniak AL, Mingrone H, Shuldyakov A, Brites C, Andrade-Villanueva JF, et al. Dolutegravir versus raltegravir in antiretroviral-experienced, integrase-inhibitor-naive adults with HIV: Week 48 results from the randomised, double-blind, non-inferiority SAILING study. The Lancet. 2013;382(9893).  
141. Raffi F, Jaeger H, Quiros-Roldan E, Albrecht H, Belonosova E, Gatell JM, et al. Oncedaily dolutegravir versus twice-daily raltegravir in antiretroviral-naive adults with HIV-1 infection (SPRING-2 study): 96 week results from a randomised, double-blind, non-inferiority trial. Lancet Infect Dis. 2013;13(11).  
142. Molina JM, Clotet B, van Lunzen J, Lazzarin A, Cavassini M, Henry K, et al. Once-daily dolutegravir is superior to once-daily darunavir/ritonavir in treatment-naïve HIV-1-positive individuals: 96 week results from FLAMINGO. J Int AIDS Soc. 2014;17.  
143. Walmsley S, Baumgarten A, Berenguer J, Felizarta F, Florence E, Khuong-Josses MA, et al. Dolutegravir plus abacavir/lamivudine for the treatment of HIV-1 infection in antiretroviral therapy-naive patients: Week 96 and week 144 results from the SINGLE randomized clinical trial. J Acquir Immune Defic Syndr (1988). 2015;70(5).  
144. Gutiérrez F, Fulladosa X, Barril G, Domingo P. Renal tubular transporter-mediated interactions of HIV drugs: Implications for patient management. Vol. 16, AIDS Reviews. 2014.  
145. Lake JE, Trevillyan J. Impact of Integrase inhibitors and tenofovir alafenamide on weight gain in people with HIV. Vol. 16, Current opinion in HIV and AIDS. 2021.  
146. Guaraldi G, Bonfanti P, Di Biagio A, Gori A, Milić J, Saltini P, et al. Evidence gaps on weight gain in people living with HIV: a scoping review to define a research agenda. BMC Infect Dis. 2023 Dec 1;23(1):230.  
147. Neesgaard B, Greenberg L, Miró JM, Grabmeier-Pfistershammer K, Wandeler G, Smith C, et al. Associations between integrase strand-transfer inhibitors and cardiovascular disease in people living with HIV: a multicentre prospective study from the RESPOND cohort consortium. Lancet HIV. 2022;9(7).  
148. Surial B, Chammartin F, Damas J, Calmy A, Haerry D, Stöckle M, et al. Impact of integrase inhibitors on cardiovascular disease events in people with HIV starting antiretroviral therapy. Clinical Infectious Diseases [Internet]. 2023 May 9; Available from: https://academic.oup.com/cid/advance-article/doi/10.1093/cid/ciad286/7157183  
149. University of Liverpool. Interaction Checker. https://interacoeshiv.huesped.org.ar/.  
150. Cahn P, Fourie J, Grinsztejn B, Hodder S, Molina JM, Ruxrungtham K, et al. Week 48 analysis of once-daily vs. twice-daily darunavir/ritonavir in treatment-experienced HIV-1infected patients. AIDS. 2011;25(7).  
151. Orkin C, Dejesus E, Khanlou H, Stoehr A, Supparatpinyo K, Lathouwers E, et al. Final 192-week efficacy and safety of once-daily darunavir/ritonavir compared with lopinavir/ritonavir in HIV-1-infected treatment-naïve patients in the ARTEMIS trial. HIV Med. 2013;14(1).  
152. Ryom L, Lundgren JD, El-Sadr W, Reiss P, Kirk O, Law M, et al. Cardiovascular disease and use of contemporary protease inhibitors: the D:A:D international prospective multicohort study. Lancet HIV. 2018;5(6).  
153. Khoo S, Peytavin G, Burger D, Hill A, Brown K, Moecklinghoff C, et al. Pharmacokinetics and safety of Darunavir/Ritonavir in HIV-infected pregnant women. Vol. 19, AIDS Reviews. 2017.  
154. Pires AF, et al. Brazilian network for HIV Drug Resistance Surveillance (HIV-BresNet) of naive-treatment individuals: a cross sectional study. In: 9th IAS Conference on HIV Science, editor. 2017.  
155. HIV DRUG RESISTANCE HIV DRUG RESISTANCE REPORT 2021. 2021.  
156. Law JKC, Butler LT, Hamill MM. Predictors of Discontinuation of Efavirenz as Treatment for HIV, Due to Neuropsychiatric Side Effects, in a Multi-Ethnic Sample in the United Kingdom. AIDS Res Hum Retroviruses. 2020;36(6).  
157. WHO. What’s new in treatment monitoring: viral load and CD4 testing. HIV treatment and care. 2017;(July).  
158. Ford N, Stinson K, Gale H, Mills EJ, Stevens W, González MP, et al. CD4 changes among virologically suppressed patients on antiretroviral therapy: A systematic review and metaanalysis. Vol. 18, Journal of the International AIDS Society. 2015.  
159. Detecção Precoce do Câncer MINISTÉRIO DA SAÚDE Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA) MINISTÉRIO DA SAÚDE Instituto Nacional de Câncer José Alencar Gomes da Silva (INCA) [Internet]. Available from: http://controlecancer.bvs.br/  
160. Lopez A, Mariette X, Bachelez H, Belot A, Bonnotte B, Hachulla E, et al. Vaccination recommendations for the adult immunosuppressed patient: A systematic review and comprehensive field synopsis. Vol. 80, Journal of Autoimmunity. 2017.  
161. El Chaer F, El Sahly HM. Vaccination in the Adult Patient Infected with HIV: A Review of Vaccine Efficacy and Immunogenicity. Vol. 132, American Journal of Medicine. 2019.  
162. Sutcliffe CG, Moss WJ. Vaccination of Human Immunodeficiency Virus–Infected Persons. In: Plotkin’s Vaccines. 2017.  
163. Nickel K, Halfpenny NJA, Snedecor SJ, Punekar YS. Comparative efficacy, safety and durability of dolutegravir relative to common core agents in treatment-naïve patients infected with HIV-1: an update on a systematic review and network meta-analysis. BMC Infect Dis. 2021;21(1).  
164. Paton NI, Musaazi J, Kityo C, Walimbwa S, Hoppe A, Balyegisawa A, et al. Efficacy and safety of dolutegravir or darunavir in combination with lamivudine plus either zidovudine or tenofovir for second-line treatment of HIV infection (NADIA): week 96 results from a prospective, multicentre, open-label, factorial, randomised, non-inferiority trial. Lancet HIV. 2022;9(6).  
165. Paton NI, Kityo C, Thompson J, Nankya I, Bagenda L, Hoppe A, et al. Nucleoside reverse-transcriptase inhibitor cross-resistance and outcomes from second-line antiretroviral therapy in the public health approach: an observational analysis within the randomised, openlabel, EARNEST trial. Lancet HIV. 2017;4(8).  
166. Keene CM, Griesel R, Zhao Y, Gcwabe Z, Sayed K, Hill A, et al. Virologic efficacy of tenofovir, lamivudine and dolutegravir as second-line in adults failing a tenofovir-based first-line regimen: a prospective cohort study. AIDS. 2021;35(9).  
167. Gandhi RT, Tashima KT, Smeaton LM, Vu V, Ritz J, Andrade A, et al. Long-term Outcomes in a Large Randomized Trial of HIV-1 Salvage Therapy: 96-Week Results of AIDS Clinical Trials Group A5241 (OPTIONS). J Infect Dis [Internet]. 2020 May 5 [cited 2023 Jun 14];221(9):1407. Available from: /pmc/articles/PMC7137888/  
168. Boyd M. Ritonavir-boosted lopinavir plus nucleoside or nucleotide reverse transcriptase inhibitors versus ritonavir-boosted lopinavir plus raltegravir for treatment of HIV-1 infection in adults with virological failure of a standard first-line ART regimen (SECOND-LINE): A randomised, open-label, non-inferiority study. The Lancet. 2013;381(9883).  
169. La Rosa AM, Harrison LJ, Taiwo B, Wallis CL, Zheng L, Kim P, et al. Raltegravir in second-line antiretroviral therapy in resource-limited settings (SELECT): a randomised, phase 3, non-inferiority study. Lancet HIV. 2016;3(6).  
170. Boyd MA, Moore CL, Molina JM, Wood R, Madero JS, Wolff M, et al. Baseline HIV-1 resistance, virological outcomes, and emergent resistance in the SECOND-LINE trial: An exploratory analysis. Lancet HIV. 2015;2(2).  
171. Aboud M, Kaplan R, Lombaard J, Zhang F, Hidalgo JA, Mamedova E, et al. Dolutegravir versus ritonavir-boosted lopinavir both with dual nucleoside reverse transcriptase inhibitor therapy in adults with HIV-1 infection in whom first-line therapy has failed (DAWNING): an open-label, non-inferiority, phase 3b trial. Lancet Infect Dis. 2019;19(3).  
172. McCluskey SM, Siedner MJ, Marconi VC. Management of Virologic Failure and HIV Drug Resistance. Vol. 33, Infectious Disease Clinics of North America. 2019.  
173. Lee KJ, Shingadia D, Pillay D, Walker AS, Riordan A, Menson E, et al. Transient viral load increases in HIV-infected children in the UK and Ireland: What do they mean? Antivir Ther. 2007;12(6).  
174. Grennan JT, Loutfy MR, Su D, Harrigan PR, Cooper C, Klein M, et al. Magnitude of virologic blips is associated with a higher risk for virologic rebound in HIV-infected individuals: A recurrent events analysis. Journal of Infectious Diseases. 2012;205(8).  
175. Bai R, Lv S, Wu H, Dai L. Low-level Viremia in Treated HIV-1 Infected Patients: Advances and Challenges. Curr HIV Res. 2022;20(2).  
176. Karlsson AC, Younger SR, Martin JN, Grossman Z, Sinclair E, Hunt PW, et al. Immunologic and virologic evolution during periods of intermittent and persistent low-level viremia. AIDS. 2004;18(7).  
177. Gaardbo JC, Hartling HJ, Gerstoft J, Nielsen SD. Incomplete immune recovery in HIV infection: Mechanisms, relevance for clinical care, and possible solutions. Vol. 2012, Clinical and Developmental Immunology. 2012.  
178. Benson C, Wang X, Dunn KJ, Li N, Mesana L, Lai J, et al. Antiretroviral Adherence, Drug Resistance, and the Impact of Social Determinants of Health in HIV-1 Patients in the US. AIDS Behav. 2020;24(12).  
179. Sigaloff KCE, Calis JCJ, Geelen SP, van Vugt M, de Wit TFR. HIV-1-resistanceassociated mutations after failure of first-line antiretroviral treatment among children in resourcepoor regions: A systematic review. Vol. 11, The Lancet Infectious Diseases. 2011.  
180. Bailey AJ, Rhee SY, Shafer RW. Integrase Strand Transfer Inhibitor Resistance in Integrase Strand Transfer Inhibitor-Naive Persons. AIDS Res Hum Retroviruses. 2021;37(10).  
181. Kantor R, Gupta RK. We should not stop considering HIV drug resistance testing at failure of first-line antiretroviral therapy. Vol. 10, The lancet. HIV. 2023.  
182. Metzner KJ. Technologies for HIV-1 drug resistance testing: inventory and needs. Curr Opin HIV AIDS [Internet]. 2022 Jul 1 [cited 2023 Jun 14];17(4):222–8. Available from: https://pubmed.ncbi.nlm.nih.gov/35762377/  
183. Hosseinipour MC, Gupta RK, Van Zyl G, Eron JJ, Nachega JB. Emergence of HIV Drug Resistance During First- and Second-Line Antiretroviral Therapy in Resource-Limited Settings. J Infect Dis [Internet]. 2013 Jun 6 [cited 2023 Jun 14];207(Suppl 2):S49. Available from: /pmc/articles/PMC3708738/  
184. Update of recommendations on first- and second-line antiretroviral regimens. Geneva, Switzerland: World Health Organization; 2019 (WHO/CDS/HIV/19.15).  
|185.|<br>HIV Drug Resistance Report 2019. Geneva, Switzerland: World Health Organization;<br>2019 (WHO/CDS/HIV/19.21).|
|---|---|
|186.|<br>Zhao Y, Maartens G, Meintjes G. Dolutegravir for second-line treatment: Programmatic<br>implications of new evidence. Vol. 23, Southern African Journal of HIV Medicine. 2022.|
|187.|<br>DOLUTEGRAVIR WITH RECYCLED nRTIs IS NONINFERIOR TO PI-BASED<br>ART: VISEND TRIAL - CROI Conference [Internet]. [cited 2023 Jun 14]. Available from:<br>https://www.croiconference.org/abstract/dolutegravir-with-recycled-nrtis-is-noninferior-to-pi-<br>based-art-visend-trial/|
|188.|<br>BRASIL. Ministério da Saúde. Secretaria de Vigilância em Saúde. Programa Nacional de<br>DST e Aids. Manual de adesão ao tratamento para pessoas vivendo com HIV e Aids / Ministério<br>da Saúde, Secretaria de Vigilância em Saúde, Programa Nacional de DST e Aids. – Brasília:<br>Ministério da Saúde, 2008.|
|189.|<br>BRASIL. Ministério da Saúde. MANUAL DO CUIDADO CONTÍNUO DAS PESSOAS<br>VIVENDO COM HIV/AIDS [Internet], 2023.|
|190.|<br>Barth RE, van der Loeff MFS, Schuurman R, Hoepelman AI, Wensing AM. Virological<br>follow-up of adult patients in antiretroviral treatment programmes in sub-Saharan Africa: a<br>systematic review. Vol. 10, The Lancet Infectious Diseases. 2010.|
|191.|<br>Yonga PO, Kalya SK, Lynen L, Decroo T. Treatment interruptions and reengagement on<br>HIV care in a rural county serving pastoralist communities in Kenya: A retrospective cohort study.<br>Trans R Soc Trop Med Hyg. 2019;113.|
|192.|<br>Mirzazadeh A, Eshun-Wilson I, Thompson RR, Bonyani A, Kahn JG, Baral SD, et al.<br>Interventions to reengage people living with HIV who are lost to follow-up from HIV treatment<br>programs: A systematic review and meta-analysis. Vol. 19, PLoS Medicine. 2022.|
|193.|<br>Glass TR, De Geest S, Weber R, Vernazza PL, Rickenbach M, Furrer H, et al. Correlates<br>of self-reported nonadherence to antiretroviral therapy in HIV-infected patients: The Swiss HIV<br>Cohort Study. J Acquir Immune Defic Syndr (1988). 2006;41(3).|
|194.|<br>Espinosa A, Miranda B, Fernando G, Pereira M, Roberta A, Pascom P, et al. Relatório de<br>Monitoramento Clínico do HIV 2022.|
|195.|<br>Schweighardt B, Ortiz GM, Grant RM, Wellons M, Miralles GD, Kostrikis LG, et al.<br>Emergence of drug-resistant HIV-1 variants in patients undergoing structured treatment<br>interruptions. AIDS. 2002;16(17).|
|196.|<br>Ford N, Orrell C, Shubber Z, Apollo T, Vojnov L. HIV viral resuppression following an<br>elevated viral load: a systematic review and meta-analysis. Vol. 22, Journal of the International<br>AIDS Society. 2019.|
|197.|<br>Darwich L, Esteve A, Ruiz L, Bellido R, Clotet B, Martinez-Picado J. Variability in the<br>plasma concentration of efavirenz and nevirapine is associated with genotypic resistance after<br>treatment interruption. Antivir Ther. 2008;13(7).|
|198.|<br>Amstutz A, Nsakala BL, Vanobberghen F, Muhairwe J, Glass TR, Namane T, et al.<br>Switch to second-line versus continued first-line antiretroviral therapy for patients with low-level<br>HIV-1 viremia: An open-label randomized controlled trial in Lesotho. PLoS Med. 2020;17(9).|
|199.|<br>Rodríguez-Nóvoa S, Martín-Carbonero L, Barreiro P, González-Pardo G, Jiménez-<br>Nácher I, González-Lahoz J, et al. Genetic factors influencing atazanavir plasma concentrations<br>and the risk of severe hyperbilirubinemia. AIDS. 2007;21(1).|  
200. Gounden V, van Niekerk C, Snyman T, George JA. Presence of the CYP2B6 516G> T polymorphism, increased plasma Efavirenz concentrations and early neuropsychiatric side effects in South African HIV-infected patients. AIDS Res Ther. 2010;7.  
201. Stainsby CM, Perger TM, Vannappagari V, Mounzer KC, Hsu RK, Henegar CE, et al. Abacavir Hypersensitivity Reaction Reporting Rates During a Decade of HLA-B*5701 Screening as a Risk-Mitigation Measure. Pharmacotherapy. 2019;39(1).  
202. WHO. Key facts HIV/ AIDS. World Health Organization. 2021.  
203. Pozniak A, Markowitz M, Mills A, Stellbrink HJ, Antela A, Domingo P, et al. Switching to coformulated elvitegravir, cobicistat, emtricitabine, and tenofovir versus continuation of nonnucleoside reverse transcriptase inhibitor with emtricitabine and tenofovir in virologically suppressed adults with HIV (STRATEGY-NNRTI): 48 week results of a randomised, open-label, phase 3b non-inferiority trial. Lancet Infect Dis. 2014;14(7).  
204. Palella FJ, Fisher M, Tebas P, Gazzard B, Ruane P, Van Lunzen J, et al. Simplification to rilpivirine/emtricitabine/tenofovir disoproxil fumarate from ritonavir-boosted protease inhibitor antiretroviral therapy in a randomized trial of HIV-1 RNA-suppressed participants. AIDS. 2014;28(3).  
205. Arribas JR, Pialoux G, Gathe J, Di Perri G, Reynes J, Tebas P, et al. Simplification to coformulated elvitegravir, cobicistat, emtricitabine, and tenofovir versus continuation of ritonavir-boosted protease inhibitor with emtricitabine and tenofovir in adults with virologically suppressed HIV (STRATEGY-PI): 48 week results of a randomised, open-label, phase 3b, noninferiority trial. Lancet Infect Dis. 2014;14(7).  
206. Mills A, Cohen C, Dejesus E, Brinson C, Williams S, Yale K, et al. Efficacy and safety 48 weeks after switching from efavirenz to rilpivirine using emtricitabine/tenofovir disoproxil fumarate-based single-tablet regimens. HIV Clin Trials. 2013;14(5).  
207. Gallant JE, Daar ES, Raffi F, Brinson C, Ruane P, DeJesus E, et al. Efficacy and safety of tenofovir alafenamide versus tenofovir disoproxil fumarate given as fixed-dose combinations containing emtricitabine as backbones for treatment of HIV-1 infection in virologically suppressed adults: a randomised, double-blind, active-controlled phase 3 trial. Lancet HIV. 2016;3(4).  
208. Mills A, Crofoot G, Ortiz R, Rashbaum B, Towner W, Ward D, et al. Switching from twice-daily raltegravir plus tenofovir disoproxil Fumarate/Emtricitabine to once-daily Elvitegravir/Cobicistat/Emtricitabine/ Tenofovir disoproxil fumarate in virologically suppressed, HIV-1-infected subjects: 48 weeks data. HIV Clin Trials. 2014;15(2).  
209. Wohl DA, Bhatti L, Small CB, Edelstein H, Zhao HH, Margolis DA, et al. The ASSURE study: HIV-1 suppression is maintained with bone and renal biomarker improvement 48 weeks after ritonavir discontinuation and randomized switch to abacavir/lamivudine+atazanavir. HIV Med. 2016;17(2).  
210. Pulido F, Ribera E, Lagarde M, Pérez-Valero I, Palacios R, Iribarren JA, et al. Dual Therapy with Darunavir and Ritonavir Plus Lamivudine vs Triple Therapy with Darunavir and Ritonavir Plus Tenofovir Disoproxil Fumarate and Emtricitabine or Abacavir and Lamivudine for Maintenance of Human Immunodeficiency Virus Type 1 Viral Suppression: Randomized, OpenLabel, Noninferiority DUAL-GESIDA 8014-RIS-EST45 Trial. Clinical Infectious Diseases. 2017;65(12).  
211. Llibre JM, Brites C, Cheng CY, Osiyemi O, Galera C, Hocqueloux L, et al. Efficacy and Safety of Switching to the 2-Drug Regimen Dolutegravir/Lamivudine Versus Continuing a 3- or 4-Drug Regimen for Maintaining Virologic Suppression in Adults Living With Human Immunodeficiency Virus 1 (HIV-1): Week 48 Results From the Phase 3, Noninferiority SALSA Randomized Trial. Clin Infect Dis. 2023;76(4).  
212. Cahn P, Madero JS, Arribas J, Antinori A, Ortiz R, Clarke A, et al. Durable Efficacy of Dolutegravir (DTG) Plus Lamivudine (3TC) in Antiretroviral Treatment-Naive Adults With HIV1 Infection: 96-Week Results From the GEMINI Studies. J Infect Public Health. 2020;13(2).  
213. Erratum: Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral TreatmentNaive Adults With HIV-1 Infection: 96-Week Results From the GEMINI-1 and GEMINI-2 Randomized Clinical Trials: Erratum (Journal of acquired immune deficiency syndromes (1999) (2020) 83 3 (310-318)). Vol. 84, Journal of acquired immune deficiency syndromes (1999). 2020.  
214. Cahn P, Madero JS, Arribas JR, Antinori A, Ortiz R, Clarke AE, et al. Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral Treatment–Naive Adults With HIV-1 Infection. JAIDS Journal of Acquired Immune Deficiency Syndromes. 2020;83(3).  
215. Cahn P, Madero JS, Arribas JR, Antinori A, Ortiz R, Clarke AE, et al. Durable Efficacy of Dolutegravir Plus Lamivudine in Antiretroviral Treatment-Naive Adults With HIV-1 Infection: 96-Week Results From the GEMINI-1 and GEMINI-2 Randomized Clinical Trials. In: Journal of Acquired Immune Deficiency Syndromes. 2020.  
216. Trattner A, Hodak E, David M, Sandbank M. The appearance of kaposi sarcoma during corticosteroid therapy. Cancer. 1993;72(5).  
217. Volkow PF, Cornejo P, Zinser JW, Ormsby CE, Reyes-Terán G. Life-threatening exacerbation of Kaposi’s sarcoma after prednisone treatment for immune reconstitution inflammatory syndrome. Vol. 22, AIDS. 2008.  
218. Poizot-Martin I, Brégigeon S, Palich R, Marcelin AG, Valantin MA, Solas C, et al. Immune Reconstitution Inflammatory Syndrome Associated Kaposi Sarcoma. Vol. 14, Cancers. 2022.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: Apêndice A -->
**<u>Quadro A</u>** - Lista <u>de antirretrovirais de uso adulto disponíveis no SUS</u>  
|**Princípio ativo**|**Apresentação**<br>**disponível **|**Esquema de administração padrão**<br>**recomendado**|**Observações**|
|---|---|---|---|
||**_Inibidores da transcr_**|**_iptase reversa análogo de núcleos(t)ídeo (ITRN)_**||
|Abacavir (ABC)|300 mg comprimido<br>revestido|300 mg (1 comprimido) duas vezes ao dia ou<br>600 mg (2 comprimidos) uma vez ao dia.|Pode ser administrado em dose única (2<br>comprimidos)|
|Lamivudina (3TC)|150 mg comprimido<br>revestido|150 mg (1 comprimido) duas vezes ao dia ou<br>300 mg (2 comprimidos) uma vez ao dia.|Pode ser administrado em dose única (2<br>comprimidos)|
|Tenofovir (TDF)|300 mg comprimido<br>revestido|300 mg (1 comprimido) uma vez ao dia.||
|Zidovudina (AZT)|100 mg cápsula<br>gelatinosa dura|300 mg (3 cápsulas) duas vezes ao dia.||
||**_Inibidores da transcript_**|**_ase reversa não-análogos de nucleosídeo (ITRNN)_**||
|Efi EFZ|600 mg comprimido<br>revestido|600 mg (1 comprimido) uma vez ao dia.||
|avrenz ()|200 mg comprimido<br>revestido|600 mg (3 comprimidos) uma vez ao dia.||
|Etravirina (ETR)|200 mg comprimido<br>revestido|200 mg (1 comprimido), 2 vezes ao dia.|O<br>teste<br>de<br>genotipagem<br>pode<br>subestimar a resistência em casos de<br>falha<br>prévia<br>a<br>efavirenz<br>e,<br>principalmente, a nevirapina.<br>Contraindicado com rifampicina.|
|Nevirapina (NVP)|200 mg comprimido<br>revestido|200 mg (1 comprimido), 2 vezes ao dia.||
|||**_Inibidores da protease (IP)_**||
|Atazanavir (ATV)|300 mg cápsula dura|<br>ATV 300 mg (1 cápsula) + RTV 100 mg (1<br>comprimido) uma vez ao dia||
|Darunavir (DRV)|800 mg comprimido<br>revestido|<br>DRV<br>800<br>mg<br>(1<br>comprimido)<br>+<br>RTV 100 mg (1 comprimido) uma vez ao dia,<br>na ausência demutações paraDRV.|Contraindicado com rifampicina.<br>Contraindicação<br>com<br>tenofovir<br>alafenamida25mg.|  
|**Princípio ativo**|**Apresentação**<br>**disponível**|**Esquema de administração padrão**<br>**recomendado**|**Observações**|
|---|---|---|---|
||||Gestantes: Só deve ser utilizado<br>durante a gravidez se o benefício<br>potencial justificar o risco potencial.|
||600 mg comprimido<br>revestido|DRV<br>600<br>mg<br>(1<br>comprimido)<br>+<br>RTV 100 mg (1 comprimido) duas vezes ao dia,<br>se houver alguma *mutação de resistência a<br>darunavir.|Contraindicado com rifampicina.<br>Contraindicação<br>com<br>tenofovir<br>alafenamida (TAF) 25mg.<br>Gestantes: Só deve ser utilizado<br>durante a gravidez se o benefício<br>potencial justificar o risco potencial.|
|Ritonavir (RTV)|100 mg comprimido<br>revestido|Utilizado em associação a outros ARVs,<br>conforme recomendado no PCDT de manejo do<br>HIV emadultos.|Embora o ritonavir seja um IP,<br>geralmente<br>é<br>usado<br>como<br>um<br>potencializador farmacocinético.|
||**_I_**|**_nibidores da integrase(INI)_**||
|Dolutegravir (DTG)|50 mg comprimido<br>revestido|50 mg (1 comprimido), uma vez ao dia, na<br>ausência de mutações a INI;<br>50 mg (1 comprimido), duas vezes ao dia, se<br>houver mutações de resistência a INI;<br>50 mg (1 comprimido), 2 vezes ao dia, se<br>coadministrado com EFV ourifampicina.|Em vírus com mutações a INI,<br>coadministração<br>com<br>EFV<br>é<br>contraindicada e não há dados com<br>rifampicina.|
|Raltegravir (RAL)|400 mg comprimido<br>revestido|400 mg (1 comprimido), duas vezes ao dia.||
||**_Inibidor_**|**_de entrada(antagonista de CCR5)_**||  
|**Princípio ativo**|**Apresentação**<br>**disponível**|**Esquema de administração padrão**<br>**recomendado**|**Observações**|
|---|---|---|---|
|Maraviroque<br>(MVQ)|150 mg comprimido<br>revestido|A dose varia de 150 mg a 600 mg a depender<br>dos<br>medicamentos<br>administrados<br>concomitantemente (Quadro 24).<br>**_Inibidor dafusão_**|Exige teste de genotropismo recente (6<br>meses) evidenciando exclusivamente<br>vírus de tropismo R5.|
|Enfuvirtida (T-20)|90 mg/ml, pó liófilo para<br>soluçãoinjetável.|90 mg/ml (1 frasco-ampola), duas vezes ao<br>diaviasubcutânea.|Medicamento injetável, reação local<br>intensaécomum.|
|Tenofovir/Lamivudina (TDF/3TC)|<br>**_Medicamento_**<br>300 mg/300 mg<br>comprimido revestido|,  <br>**_s em Dose Fixa Combinada(DFC)_**<br>300 mg/300 mg (1 comprimido) uma vez ao dia||
|Tenofovir/Lamivudina/Efavirenz<br>(TDF/3TC/EFV)|300 mg/300 mg/600 mg<br>comprimido revestido|300 mg/300 mg/600 mg (1 comprimido) uma<br>vez ao dia.||
|Zidovudina/Lamivudina<br>(AZT/3TC)|300 mg/150 mg<br>comprimido revestido|300 mg/150 mg (1 comprimido) duas vezes ao<br>dia.||
|Dolutegravir/Lamivudina<br>(DTG/3TC)|50 mg/300 mg<br>comprimido revestido|50 mg/300 mg (1 comprimido) uma vez ao dia.||  
Fonte: DATHI/SVSA/MS.  
Legenda: * Mutações de resistência a DRV: V11I, V32I, L33F, I47V, I50V, I54L, I54M, T74P, L76V, I84V, L89V  
**<u>Quadro B:</u>** <u>Posologia do maraviroque 150 mg</u>  
|**Medicamentos concomitantes**|**Dose recomendada**|
|---|---|
|Inibidores potentes da CYP3A (com ou sem indutor da CYP3A) incluindo:<br>inibidores de protease (exceto tipranavir)<br>delavirdina<br>cetoconazol, itraconazol, claritromicina,<br>Outros inibidores potentes da CYP3A (nefazodona, telitromicina)|150 mg a cada 12 horas|
|Indutores potentes da CYP3A (sem inibidor da CUP3A) incluindo:<br>efavirenz<br>rifampicina|600 mg a cada 12 horas|
|etravirina<br> carbamazepina,fenobarbitalefenitoína||
|Outros medicamentos concomitantes, incluindo tipranavir/ritonavir, nevirapina, raltegravir, todos ITRN e<br>enfuvirtida|300 mg a cada 12 horas|

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo elaborador da atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Adultos - Módulo 1: Tratamento contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Equipe de elaboração e partes interessadas** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), o Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI/SVS/MS) constituiu um grupo de trabalho interno para revisão e atualização deste PCDT. Este grupo foi composto por técnicos do DATHI e um comitê assessor. Além disso, outros profissionais de diversas áreas da saúde participaram enquanto colaboradores, conforme elencado a seguir:  
|Álisson Bigolin|Marcus Vinicius Guimaraes de Lacerda|
|---|---|
|Amílcar Tanuri|Maria Adelaide Millington|
|Ana Cristina Garcia Ferreira|Maria Clara Gianna Garcia Ribeiro|
|Ana Roberta Pati Pascom|Mayara Maia Lima|
|André Bon Fernandes da Costa|Mayra Gonçalves Aragón|
|Beatriz Brittes Kamiensky|Monica Jacques de Moraes|
|Beatriz Gilda Jegerhorn Grinsztejn|Nicole Menezes de Souza|
|Camila Fernanda dos Santos Santana|Orlando Marcos Farias de Sousa|
|Celso Ferreira Ramos Filho|Pâmela Cristina Gaspar|
|Denize Lotufo Estevam|Paula Pezzuto|
|Draurio Barreira Cravo Neto|Paulo Abrão Ferreira|
|Érico Antônio Gomes de Arruda|Ricardo Sobhie Diaz|
|Estevão Portela Nunes|Rodrigo Ramos de Sena|
|Fernanda Dockhorn Costa|Romina do Socorro Marques de Oliveira|
|Francisco Álisson Paula de França|Ronaldo Campos Hallal|
|Guilherme Alves de Lima Henn|Ronaldo Zonta|
|Gustavo Luís Meffe Andreoli|Rosalynd Moreira|
|José Ernesto Vidal Bermudez|Rosana Del Bianco|
|José Luiz de Andrade Neto|Simone de Barros Tenore|
|José Valdez Ramalho Madruga|Swamy Lima Palmeira|
|Kathiely Martins dos Santos|Tatianna Meireles Dantas de Alencar|
|Leonor Henriette de Lannoy|Tayrine Huana de Sousa Nascimento|
|Lilian Nobre de Moura|Thiago Cherem Morelli|
|Liliana Romero Veja|Valdilea Veloso|
|Lisandra Serra Damasceno|Valéria Cavalcanti Rolla|
|Marcelo Yoshito Wada|Veruska Maia da Costa|
|Marcia Leite de Sousa Gomes||

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos - Módulo 1: Tratamento foi apresentada na 107ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 20 de julho de 2023. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Complexo da Saúde (SECTICS); Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS), Secretaria de Saúde Indígena (SESAI) e Secretaria de Vigilância em Saúde e Ambiente (SVSA). Foram sugeridos alguns ajustes no Apêndice Metodológico e textuais do documento. O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Comitê de PCDT da Conitec em sua 121ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Consulta Pública** -->
A Consulta Pública nº 32/2023, para atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos - Módulo 1: Tratamento, foi realizada entre os dias 10/08/2023 e 29/08/2023. Foram recebidas 13 contribuições, que podem ser verificadas em: <u>https://www.gov.br/conitec/ptbr/midias/consultas/contribuicoes/2023/CP_CONITEC_032_2023_PCDT_para_Manejo.pdf</u>

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **Busca da evidência e recomendações** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos - Módulo 1: Tratamento contou com a participação do comitê de _experts_ no tratamento da doença. O grupo de especialistas foi composto por representantes da comunidade científica, representante da Sociedade Brasileira de Infectologia, representantes da sociedade civil e especialistas com longa experiência no cuidado e tratamento de pessoas que vivem com HIV e Aids, oriundos de instituições envolvidas com o cuidado às pessoas vivendo com HIV.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao MS para análise prévia às reuniões de escopo e formulação de recomendações.  
Para a atualização das recomendações do novo documento, elaborou-se uma proposta inicial do escopo de atualização do PCDT, que motivou a primeira reunião _on-line_ com o grupo técnico assessor realizada em novembro de 2022. Nesta reunião, foram estabelecidos os pontos que demandavam atualização, considerando as novas tecnologias em saúde previamente incorporadas, o cenário epidemiológico e as principais estratégias de enfrentamento à epidemia de Aids. Os principais temas definidos que nortearam a revisão e discussão na reunião foram:  
a) Quais populações apresentam maior benefício com rastreamento e diagnóstico da tuberculose com emprego do IGRA para Infecção Latente (ILTB) e LF-LAM para Tuberculose Ativa?  
b) Quais populações apresentam maior benefício com o rastreamento e diagnóstico do CRAG para criptococose?  
c) Quais são as atualizações de quando deve ser iniciado o tratamento antirretroviral?  
d) Quais são as atualizações de como deve ser iniciado o tratamento antirretroviral?  
e) Quais estratégias de substituição de antirretrovirais devem ser adotadas para reduzir a toxicidade?  
f) Para quais populações e situações é necessário desintensificar o tratamento, utilizando a terapia dupla?  
g) Quais são as atualizações de como deve ser estruturado o esquema antirretroviral de resgate em pacientes com falha virológica e resistência?  
h) Quais são as atualizações de como deve ser estruturado o esquema antirretroviral na sua reintrodução após a interrupção do tratamento?  
i) Como deve ser estruturado o esquema antirretroviral na coinfecção com tuberculose?  
Diante do exposto, foram realizadas buscas na literatura científica por revisões sistemáticas, ensaios clínicos randomizados, além de protocolos e diretrizes clínicas internacionais sobre os temas específicos de cada uma das seções. Também foram utilizados os Relatórios técnicos das novas tecnologias em saúde recentemente incorporadas, como o LF-LAM, CrAG e darunavir 800 mg.  
Após a análise das evidências científicas, buscou-se identificar as necessidades de atualização do PCDT publicado em 2017, como subsídio para a nova reunião com o grupo de especialistas, que ocorreu em junho de 2023. O levantamento de evidências resultante das buscas na literatura científica, foi utilizado para elaboração da proposta preliminar.  
Previamente, os especialistas receberam a proposta elaborada pela Coordenação-Geral de Vigilância do HIV/Aids e das Hepatites Virais (CGAHV/DATHI/SVSA/MS) e que elencava os pontos chave para atualização do PCDT. Durante o encontro, foi aplicada uma adaptação do método Delphi para obter o consenso dos especialistas para a tomada de decisão sobre as novas recomendações e também em relação àquelas que apresentavam diferenças de parâmetros na literatura.  
Após a reunião, as decisões foram incorporadas ao texto do documento final, o qual foi compartilhado com o grupo de especialistas para a definição da versão final, sendo que as sugestões adicionais foram consolidadas pela equipe da CGAHV/DATHI/SVSA/MS.  
Na sequência, a minuta de texto atualizado foi apresentada à Coordenação-Geral de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CGPCDT/DGITS/SECTICS/MS) e, após revisão, foi avaliada pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas.

---

<!-- METADADOS: doenca: Manejo da Infecção pelo HIV em Adultos - Módulo 1 | secao: **APÊNDICE 2 - HISTÓRICO DE ALTERAÇÕES DO PROTOCOLO** -->
|**Número do**<br>**Relatório da**||**Tecnologias avaliadaspela**|**Conitec**|
|---|---|---|---|
|**diretriz clínica**<br>**(Conitec) ou**<br>**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação**<br>**ou não alteração no**<br>**SUS**|
|Relatório<br>de<br>Recomendação nº<br>853/2023|Desmembramento do<br>texto em módulos;<br>Atualização do texto<br>do<br>documento<br>e<br>inclusão<br>de<br>orientações referentes<br>às<br>tecnologias<br>incorporadas|Incorporação do darunavir 800 mg para o<br>tratamento de pessoas vivendo com HIV<br>em falha virológica ao esquema de<br>primeira linha e sem mutações que<br>conferem resistência ao darunavir (V11I,<br>V32I, L33F, I47V, I50V, I54L, I54M,<br>T74P, L76V, I84V ou L89V)<br>[Portaria<br>SECTICS/MS<br>nº<br>34/2023;<br>Relatório de Recomendação nº 829]<br>Incorporação do teste de Liberação de<br>Interferon-gama (IGRA) para detecção de<br>infecção latente pelo_Mycobacterium_<br>_tuberculosis_em pacientes com doenças<br>inflamatórias<br>imunomediadas<br>ou<br>receptores de transplante de órgãos<br>sólidos<br>[Portaria<br>SCTIE/MS<br>nº<br>50/2020;<br>Relatório de Recomendação nº 573]<br>Incorporação do teste diagnóstico, point<br>of care, de_Cryptococcal Antigen Lateral_<br>_Flow Assay_(CRAG-LFA) para detecção<br>de<br>infecção<br>por<br>_Cryptococcus_<br>e<br>diagnóstico de meningite criptocócica em<br>pessoas<br>vivendo<br>com<br>o<br>vírus<br>da<br>imunodeficiência humana (PVHIV)<br>[Portaria<br>SCTIE/MS<br>nº<br>28/2021;<br>Relatório de Recomendação nº 615]<br>Incorporação do teste de fluxo lateral para<br>detecção de lipoarabinomanano em urina<br>(LF-LAM)<br>para<br>rastreamento<br>e<br>diagnóstico de tuberculose ativa em<br>pessoas suspeitas vivendo com HIV/AIDS<br>[Portaria<br>SCTIE/MS<br>nº<br>02/2021;<br>Relatório de Recomendação nº591]|-|
|Portaria<br>SCTIE/MS nº 52,<br>de<br>23/11/2017<br>[Relatório<br>de<br>Recomendação nº<br>299]|Primeira versão do<br>documento|-|-|

---

