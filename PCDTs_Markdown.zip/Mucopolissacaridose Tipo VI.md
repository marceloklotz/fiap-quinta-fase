<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 20, DE 05 DEZEMBRO DE 2019.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Mucopolissacaridose Tipo VI.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre a mucopolissacaridose tipo VI no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando os registros de deliberação ~~n~~<sup><u>o</u></sup> 400/018 e ~~n~~<sup><u>o</u></sup> 465/2019 e os relatórios de recomendação n<sup><u>o</u></sup> 412 – Dezembro de 2018 e n<sup><u>o</u></sup> 476 – Outubro de 2019 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Mucopolissacaridose  
Tipo VI.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da mucopolissacaridose do tipo VI, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>http://portalms.saude.gov.br/protocolose-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito</u> Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da mucopolissacaridose tipo VI.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas na Portaria, disponível no sítio citado no parágrafo único do art. 1º  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: FRANCISCO DE ASSIS FIGUEIREDO -->
DENIZAR VIANNA  
ANEXO

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **1. INTRODUÇÃO** -->
A Mucopolissacaridose Tipo VI (MPS VI), ou Síndrome Maroteaux-Lamy, é uma doença genética rara, de herança autossômica recessiva, causada pela atividade deficiente da enzima N-acetilgalactosamina4-sulfatase ou arilsulfatase B ( _ASB_ ) _,_ responsável pela degradação do glicosaminoglicano (GAGs) dermatan sulfato (DS), resultando no acúmulo desse componente nos lisossomos de múltiplos tecidos do corpo (1).  
A MPS VI é uma doença heterogênea e progressiva (2). Pacientes com a forma rapidamente progressiva frequentemente desenvolvem baixa estatura, alterações faciais grosseiras, anormalidades esqueléticas e nas articulações, compressão da medula espinhal, comprometimento da função pulmonar e cardiovascular, alterações oculares, infecções respiratórias, otites de repetição e mortalidade precoce no início da fase adulta, geralmente por insuficiência cardiopulmonar. Nas formas com progressão lenta, as morbidades também podem ser significativas com mortalidade em torno da terceira a quinta década de vida (3).  
A incidência é variável, descrita como 1 a cada 43.261 a 1 a cada 1 milhão de nascidos vivos (4-10), dados possivelmente subestimados por não haver rotina de rastreio populacional (11). Apesar de a incidência de nascimentos não estar disponível para o Brasil, investigação diagnóstica realizada em laboratório de referência de Porto Alegre, Rio Grande do Sul, com amostras de alto risco de diversas regiões brasileiras, mostrou que 19% dos pacientes identificados apresentavam MPS VI (12), enquanto que outro estudo do mesmo grupo referiu diagnóstico de 238 casos de MPS VI entre 1982 e 2015 (13). Apesar de não haver grupo étnico no qual a MPS VI seja mais prevalente, a ocorrência de endogamia parece explicar a alta prevalência da doença no norte de Portugal e algumas áreas do Brasil (14). Ainda, segundo pesquisa realizada pelo demandante da tecnologia com base em unidades comercializadas, estima-se que no Brasil há 183 pacientes. (15)  
Inexiste tratamento curativo para a MPS VI. Este PCDT visa definir critérios de diagnóstico, acompanhamento e tratamento de pacientes com MPS VI, incluindo terapia de reposição enzimática (TRE) intravenosa (IV) com galsulfase e transplante de células-tronco hematopoiéticas (TCTH).  
<mark>A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.</mark>  
Este PCDT visa a definir critérios de diagnóstico, acompanhamento e tratamento, incluindo terapia de reposição enzimática intravenosa (TRE IV) com galsulfase e o TCTH, de pacientes com MPS VI. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À**

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **1. INTRODUÇÃO** -->
- E76.2 Outras Mucopolissacaridoses

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3. DIAGNÓSTICO** -->
A confirmação do diagnóstico de MPS VI envolve exames bioquímicos ou genéticos que deverão ser realizados sempre que houver suspeita clínica dessa doença.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3.1 SUSPEITA DIAGNÓSTICA** -->
O diagnóstico de MPS VI deve ser suspeitado em indivíduos que apresentarem pelo menos um dos  
seguintes sinais e sintomas abaixo relacionados, especialmente naqueles que tiverem a combinação de pelo  
menos dois deles (4):  
- Características faciais sugestivas de doença lisossômica (face de “depósito”);  
- Infecções respiratórias superiores precoces e de repetição, incluindo otite média, excluídas outras  
causas mais frequentes;  
- Perda auditiva;  
- Diminuição da velocidade de crescimento;  
- Hepatoesplenomegalia, excluídas outras causas mais frequentes;  
- Hérnias;  
- Alterações esqueléticas ou articulares típicas [disostose múltipla, giba, limitação da amplitude de  
movimento (AM) das articulações];  
- Mãos em garra;  
- Achados oculares característicos (opacificação bilateral da córnea);  
- Irmão de qualquer sexo com MPS VI.  
Como os achados clínicos variam de acordo com a gravidade da doença, os sinais e sintomas por si  
só, não são diagnósticos.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3.2 DIAGNÓSTICO LABORATORIAL** -->
A confirmação do diagnóstico de MPS VI pode envolver métodos bioquímicos ou genéticos.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3.2.1 Atividade da ASB** -->
A redução ou ausência de atividade da ASB em fibroblastos, leucócitos ou sangue impregnado em papel-filtro sugere fortemente o diagnóstico de MPS VI, mas não é suficiente para confirmá-lo como único teste, devido à possibilidade de ocorrência de deficiência múltipla de sulfatase, outro erro inato do metabolismo (4, 16). Por isto, a atividade de pelo menos outra sulfatase (arilsulfatase A, arilsulfatase B, heparan N-sulfatase ou iduronato-sulfatase) deve estar normal.  
A medida da atividade enzimática em gotas de sangue impregnadas em papel-filtro tem a vantagem da facilidade de transporte e manipulação, mas deve ser considerada como método de triagem, devido aos casos de falso-positivos associados.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3.2.2 Teste genético** -->
A presença de duas mutações patogênicas bialélicas no gene _ASB_ também confirma o diagnóstico. A análise do gene _ASB_ permite a detecção das mutações que provocam a doença e, consequentemente, o diagnóstico genético e a detecção de heterozigotos, facilitando o aconselhamento genético individual e familiar (4). Já foram descritas 207 mutações no gene _ASB_ (17).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3.2.3 Associação genótipo-fenótipo clínico** -->
A maior importância dos estudos de genótipo-fenótipo é a identificação, em idade precoce, daqueles indivíduos que apresentarão a forma grave da doença. Apesar de não estar estabelecida para todas as mutações já descritas, para algumas mutações há uma clara associação entre genótipo-fenótipo (14). A mutação p.Y210C, por exemplo, parece associar-se a um fenótipo mais brando (4), enquanto que a homozigose para mutações do tipo “sem sentido” leva a fenótipos mais graves.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT todos os pacientes que apresentarem pelo menos um dos sinais ou sintomas descritos no item 3.1 (Suspeita Clínica) deste Protocolo e tiverem o diagnóstico de MPS VI confirmado de acordo com um dos critérios abaixo relacionados (4). Estes também são os critérios para início do tratamento com galsulfase, ou seja:  
- Atividade da enzima ASB < 10% do limite inferior dos valores de referência em fibroblastos ou leucócitos **<u>E</u>** atividade de pelo menos outra sulfatase (arilsulfatase A, arilsulfatase B, heparan N- sulfatase ou iduronato-sulfatase) avaliada na mesma amostra e pelo mesmo método, apresentando valores normais **<u>E</u>** presença de níveis aumentados de GAGs totais na urina ou de excreção aumentada de DS; **OU**  
- Atividade da enzima ASB < 10% do limite inferior dos valores de referência em fibroblastos, leucócitos ou em papel-filtro **<u>E</u>** atividade de pelo menos outra sulfatase (arilsulfatase A, arilsulfatase B, heparan N-sulfatase ou iduronato-sulfatase) avaliada na mesma amostra e pelo mesmo método, apresentando valores normais, **<u>E</u>** presença de mutações patogênicas em homozigoze ou heterozigoze composta no gene _ASB_ .  
Os pacientes que já estiverem em uso de galsulfase quando da publicação deste PCDT deverão ser reavaliados para verificação dos critérios de inclusão. Caso não preencham os critérios, a reposição da enzima deve ser imediatamente suspensa.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: 4.1 **CRITÉRIOS DE INCLUSÃO PARA TERAPIA DE REPOSIÇÃO ENZIMÁTICA (TER)** -->
Poderão fazer uso de galsulfase todos os indivíduos com diagnóstico de MPS VI realizado de acordo  
com o item 3 deste PCDT (4) **<u>E:</u>**  
- a) que tenham idade entre 0 a 6 anos de idade; **<u>OU</u>**  
- b) que tenham idade igual ou superior a 7 anos **<u>E</u>**  
- **b.1)** sejam ambulantes e capazes de percorrer, sem ajuda, pelo menos 5 metros nos 6 primeiros minutos do Teste da Caminhada de 6 minutos (TC6M); **<u>OU</u>**  
- **<u>b.2)</u>** sejam capazes de realizar espirometria.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **(TCTH)** -->
Serão elegíveis para o transplante de células-tronco hematopoéticas (TCTH) alogênico (TCTH-AL) aparentado (TCTH-AL-AP) ou não aparentado (TCTH-AL-NAP):  
- Os pacientes com diagnóstico de MPS VI e com fatores de risco para pior evolução da doença;  
- com doador de células-tronco hematopoéticas (CTH) identificado;  
- em condições clínicas para o transplante; e  
- em idade compatível com o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas as respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
O tipo (aparentado ou não aparentado) e subtipo (mieloablativo ou não mieloablativo) do TCTH  
dependerão da idade e das condições clínicas do paciente, cabendo à equipe transplantadora defini-los.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **5.1 CRITÉRIOS DE EXCLUSÃO PARA TRE** -->
Serão excluídos do tratamento com galsulfase os pacientes que se enquadrarem nas seguintes  
situações:  
- Condição médica irreversível e que implique em sobrevida provavelmente < 6 meses como resultado da MPS VI ou de outra doença associada, em acordo entre mais de um especialista;  
- Pacientes com idade > 18 anos que, após serem informados sobre os potenciais riscos e benefícios associados ao tratamento com galsulfase, recusarem-se a serem tratados;  
- Pacientes com histórico de falha de adesão, desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que, mesmo após o programa, não comparecerem a pelo menos 50% do número de consultas ou de avaliações previstas em um ano.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **(TCTH)** -->
- Pacientes com diagnóstico de MPS VI sem condições clínicas para o TCTH-AL;  
- Pacientes em idade incompatível para o TCTH-AL, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas as respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS; ou  
- Pacientes sem doador de células-tronco hematopéticas (CTH) identificado.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6. TRATAMENTO** -->
O tratamento clínico dos pacientes com MPS VI envolve equipe multidisciplinar (1, 4, 18, 19) e inclui intervenções não específicas, realizadas no nível do fenótipo clínico (como cirurgias para correção  
das alterações esqueléticas), e específicas, realizadas no nível da proteína mutante (como a TRE IV) (4, 20). Outras condutas, como uso de inibidores de síntese de substrato, terapia oral, terapia com nanopartículas e terapia gênica, estão ainda em fase de desenvolvimento (21).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.1 TRATAMENTO GERAL** -->
O paciente com MPS VI tem uma doença crônica, progressiva e multissistêmica e rotineiramente requer cuidados urgentes por equipe multiprofissional que inclua fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, equipe de enfermagem e diferentes especialidades médicas (4). É crucial que um médico cuide continuamente do paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando o paciente para especialistas conforme necessário e coordenando o atendimento ao paciente como um todo, idealmente em um centro de referência.  
Além disso, é importante que os pacientes e as famílias sejam orientados sobre sua doença e possíveis complicações e riscos, também por meio de um relatório escrito. Os pacientes também devem ser informados de que, em caso de emergência, o médico assistente deve ser informado da doença e receber uma cópia do relatório médico. (4) Os pacientes com MPS VI podem desenvolver sintomas neurológicos secundários a compressão medular (4). Dessa forma, um neurocirurgião poderá fazer parte da equipe multidisciplinar de acompanhamento desses pacientes. (4)  
As principais manifestações clínicas da MPS VI e suas opções de tratamento de suporte e sintomáticos podem ser encontradas no **Apêndice 1** . É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e mais graves nos pacientes com a forma grave da doença. Da mesma forma, nem todos os pacientes necessitarão ser submetidos a todas as formas de tratamento.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.1.1. Tratamento ortopédico** -->
Pacientes com MPS VI têm comprometimento ósseo significativo (1, 4, 22) e requerem fisioterapia motora dinâmica, cujo objetivo principal é a prevenção ou estabilização de deformidades osteoarticulares, mantendo a amplitude de movimento. A fisioterapia, associada ou não a medicação analgésica, deve se concentrar em massoterapia para ajudar o relaxamento de todos os músculos, enfatizando o antebraço e o punho, por causa da síndrome do túnel do carpo, além de manobras e manipulações de todas as articulações com movimentos lentos para não causar dor, de acordo com os critérios da técnica de mobilização miofascial (4).  
Além disso, equipamentos de auxílio da marcha ou cadeira de rodas podem aumentar a mobilidade e aliviar a dor; contudo, esforços na medida de postergar ao máximo a utilização dos mesmos devem ser feitos para manter esses pacientes móveis por maior tempo possível, uma vez que a sua qualidade de vida reduz drasticamente ao se tornarem dependentes de cadeira de rodas (4).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.1.2. Tratamento das manifestações respiratórias** -->
As manifestações respiratórias são as principais causas de morbimortalidade e podem ocorrer por causas obstrutivas ou restritivas (4). Entre os objetivos do tratamento clínico está o melhor controle das infecções recorrentes de via aérea. Normalmente, solução salina é usada para eliminar crostas e secreções.  
Antibióticos são utilizados para o tratamento de exacerbações respiratórias agudas de origem bacteriana, como otite média aguda ou tonsilite, conforme indicação clínica e a critério médico. Corticosteroides sistêmicos por breves períodos podem ajudar a reduzir o edema e facilitar a drenagem de secreções, conforme indicação clínica e a critério médico. Os medicamentos para asma devem ser administrados conforme PCDT específico para essa condição clínica (23). Pacientes podem, ainda, se beneficiar de terapias de suporte, como imunizações regulares para influenza e pneumococo (4), seguindo o calendário obrigatório de vacinação.  
Fisioterapia respiratória visa melhorar função pulmonar, ventilação e biomecânica respiratória, prejudicadas na MPS VI. Estão indicadas as manobras de higiene brônquica descritas na literatura, como vibrocompressão, drenagem postural, tosse controlada por manobra de aceleração do fluxo expiratório, nebulização e aspiração nasotraqueal com material estéril e descartável. Orientação para cuidadores e membros da família é de vital importância, porque a fisioterapia respiratória deve ser realizada diariamente. (4)

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.1.3. Tratamento oftalmológico** -->
A opacificação na córnea e as alterações de refração (astigmatismo, miopia e hipermetropia) são comuns na MPS VI, podendo levar à diminuição da acuidade visual e fotossensibilidade (4, 24). Lentes corretivas devem ser prescritas para corrigir erros de refração (4). O transplante de córnea pode melhorar notavelmente a visão (4), embora possa ocorrer opacificação na córnea transplantada como já relatado para MPS IV-A (25).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.1.4. Tratamento cirúrgico** -->
A MPS VI pode evoluir com complicações neurológicas, como hidrocefalia comunicante e compressão medular, além de síndrome do túnel do carpo e hidrocefalia (4, 26, 27); porém, os sinais clássicos de hipertensão intracraniana geralmente estão ausentes, evoluindo de forma insidiosa, e os sintomas são difíceis de distinguir de danos primários ao cérebro (4). A maioria dos casos de compressão medular apresenta tetraparesia espástica, mas paraparesia espástica ou hemiparesia também podem ocorrer. (28)  
Cirurgia de coluna tóraco-lombar para correção da cifose pode ser uma alternativa quando a deformidade progride (29-32). Há relatos que sugerem que os pacientes com MPS VI que realizam cirurgia da coluna vertebral aumentam risco de grandes complicações, incluindo infarto da medula espinhal e instabilidade da coluna vertebral (29). Assim, cirurgias de coluna devem ter avaliações periódicas de monitorização com neurofisiologia. Seguimento com ressonância cerebral ao diagnóstico e durante o seguimento a cada 2 a 3 anos é recomendado e imagens da coluna devem ser obtidas na presença de novos sintomas (26). Eventualmente esses pacientes necessitam de cirurgias corretivas devido a deformidades ósseas diversas, incluindo a região do quadril e joelhos (4, 22).  
Com relação ao tratamento cirúrgico das manifestações clínicas nas vias aéreas, os procedimentos cirúrgicos mais frequentes incluem adenotonsilectomia, cirurgia de cornetos nasais e traqueostomia (4). Como o bloqueio das vias aéreas em MPS é multifatorial, os resultados da adenotonsilectomia variam, mas a melhora a médio prazo na qualidade respiratória é percebida na maioria dos casos. Com relação ao  
tratamento da perda auditiva, quando decorrente de causas condutivas e por infecções respiratórias frequentes requer inserção de tubos de ventilação de longa duração, porém nem sempre é resolutivo.  
A cirurgia das vias aéreas pode ser complicada pela macroglossia, abertura limitada da boca, margem cirúrgica restrita e instabilidade da coluna cervical, dificultando a visualização do campo cirúrgico. Hiperextensão no pescoço nesses pacientes pode causar compressão medular aguda. Uma alternativa de realização de adenoidectomia quando o acesso pela abertura oral está comprometido é a cirurgia endoscópica por via nasal (33). A traqueostomia definitiva ou temporária pode ser realizada antes de outras cirurgias para facilitar o controle das vias aéreas, se o suporte ventilatório for inefetivo ou em pacientes com obstrução de via aérea também quando acordados. A traqueostomia deve ser evitada sempre que possível, devido a dificuldades na técnica cirúrgica, endurecimento da traqueia, alterações anatômicas significativas como pescoço curto, e possibilidade de complicações pós-operatórias, como traqueíte, pneumonia recorrente e bloqueio da traqueostomia por secreções espessas. Assim, como as complicações são frequentes neste procedimento, sugere-se a realização apenas em centros com experiência nesses pacientes (4). Os desafios da gestão de uma traqueostomia nesses pacientes, associados à dificuldade de aceitação pelo paciente e pela família, também devem ser levados em consideração.  
O tratamento cirúrgico das manifestações oftalmológicas consiste, quando necessário, em correção do estrabismo, do aumento da pressão intraocular, além do transplante de córnea já mencionado. Além disso, quando há aumento da pressão intracraniana, a drenagem ventrículo-peritoneal pode evitar atrofia do nervo ótico e perda de visão, além da descompressão cirúrgica deste nervo, quando indicada. (4)  
Muitos pacientes com MPS apresentam risco anestésico elevado devido à obstrução das vias aéreas superiores. Avaliação pré-operatória para avaliação dos riscos sempre está indicada (4), uma vez que a dificuldade na intubação pode ser fatal (34). Idealmente as cirurgias devem ser realizadas em centros de referência com experiência em MPS, sendo fundamental a presença de anestesista experiente em intubação difícil para a realização desses procedimentos, pois a necessidade de acompanhar a intubação com fibroscopia é frequente. As máscaras laríngeas podem ser usadas para o tratamento das vias aéreas por períodos curtos ou para facilitar a intubação de fibra óptica (34-36). Os tubos endotraqueais podem precisar ser menores do que o previsto para a idade e o tamanho de um paciente com MPS VI. Pacientes geralmente apresentam obstrução pós-operatória das vias aéreas, e as observações hospitalares durante a noite não são incomuns. A consciência da possibilidade de traqueostomia pós-operatória é importante para todas as partes envolvidas. Quando possível, os procedimentos que exigem anestesia geral devem ser evitados, para minimizar o risco.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.2.1 TRANSPLANTE DE CÉLULAS TRONCO-HEMATOPOIÉTICAS (TCTH)** -->
As evidências atualmente disponíveis sugerem que existem benefícios da realização de TCTH em indivíduos com MPS VI, especialmente naqueles em idade precoce. (37-39) Desta forma, indivíduos com MPS VI que tenham até 6 anos de idade, deverão ser encaminhados a centros transplantadores de referência, a fim de ser verificada a possibilidade de realização de TCTH.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.2.2 TERAPIA DE REPOSIÇÃO ENZIMÁTICA (TRE)** -->
A galsulfase, _ASB_ recombinante, é uma enzima produzida em células de ovário de hamster chinês ( _Chinese hamster ovary cells_ - CHO) e trata-se do fármaco disponível para o tratamento específico da MPS VI (20). A galsulfase foi considerada segura nos estudos incluídos, com eventos adversos leves na maioria dos casos e facilmente tratáveis (40, 41) e eficaz para melhora na distância percorrida no teste da caminhada dos 6 minutos (TC6M), melhora na função pulmonar e redução de GAGs. (42)

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.3 CASOS ESPECIAIS** -->
A galsulfase é considerada classe B para uso na gestação e aleitamento. A evidência científica apontada na literatura para tratamento de gestantes com MPS VI é limitada a série de casos: há relato na literatura de manutenção de uso da galsulfase durante a gestação com desfechos positivos para mãe e recémnascido (43). De forma geral, recomenda-se que o tratamento com TRE não seja iniciado durante a gestação, especialmente durante o primeiro trimestre, e que, se já iniciado, seja mantido durante a gravidez.  
Da mesma forma, caso estejam em uso de glicocorticoides e anti-histamínicos, considerar a interrupção da TRE, especialmente no primeiro trimestre.  
Casos associados à não redução de GAGs urinários devem ser avaliados de forma individualizada. Quando houver reação à infusão mediada por IgE, deve ser discutida a possibilidade a tolerização.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.4. FÁRMACO** -->
- Galsulfase: 1 mg/ml solução injetável.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.5 ESQUEMA DE ADMINISTRAÇÃO** -->
A dose recomendada para a galsulfase é de 1 mg/kg de peso corporal, administrada uma vez por semana por infusão IV. O uso de antipiréticos ou anti-histamínicos é recomendado 30 a 60 minutos antes do início da infusão (4). A infusão deve ser feita em ambiente hospitalar ou ambulatorial.  
O volume total da infusão é determinado pelo peso corporal do paciente e deve ser infundido ao longo de 4 horas. Pacientes com 20 kg ou menos devem receber um volume total de 100 ml. Pacientes com mais de 20 kg devem receber um volume total de 250 ml. A taxa de infusão inicial deve ser de 6 ml por hora durante a primeira hora. Se a infusão for bem tolerada, a velocidade de infusão pode ser aumentada para 80 ml por hora durante as restantes 3 horas. O tempo de infusão pode ser prolongado até 20 horas se ocorrerem reações à infusão. (43)

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **6.6 RISCOS E BENEFÍCIOS ESPERADOS** -->
A galsulfase é considerada um medicamento seguro. Os seus principais benefícios são a melhora no teste de caminhada de 6 e de 12 minutos e redução nos níveis de GAGs urinários.  
O desfecho primário do ECR existente foi a distância no TC12M, desfechos secundários incluíram TC6M, teste de subida de escada em 3 minutos (3MSC), capacidade vital forçada (CVF) e nível de GAGs urinário. Não foram avaliadas redução de mortalidade ou qualidade de vida. (41)  
Após 24 semanas, os pacientes que receberam galsulfase caminharam em média 92 metros a mais no TC12M (IC 95% 11 a 172 metros; p = 0,025), 53 metros no TC6M (IC95% 14 a 90 metros; p = 0,007)  
e subiram 5,7 degraus de escadas por minuto a mais no 3MSC (IC 95% -0,1 a 11,5 degraus de escadas por minuto; p = 0,053) do que os pacientes que receberam placebo. A melhora contínua foi observada durante o estudo de extensão de 24 semanas. O declínio dos níveis de GAGs urinários na semana 24 no grupo galsulfase foi -227 ± 18 μg/mg (p <0,001) a mais que no grupo placebo. (41)  
Estudo observacional do registro de MPS VI mostrou ainda benefício da TRE após 10 anos de tratamento na função pulmonar medida por espirometria, sendo que a melhora geral na CVF foi de 30% (p<0,0001), a melhora nos menores de 13 anos foi de 67% (p=0,0002) e nos maiores de 13 anos de 13% (p=0,011). (44) Em outro estudo observacional do registro de MPS VI, houve um aumento médio de 45 metros na distância percorrida em 6 minutos e uma média da redução de GAGs de 64% (85% no grupo com valores maiores ao baseline; 44% no grupo com valores menores ao baseline) (42).  
Em relação aos eventos adversos, um paciente no grupo intervenção apresentou evento adverso grave: um episódio de apneia com necessidade de traqueostomia de emergência. Entre os 19 pacientes do grupo de galsulfase, os eventos adversos mais frequentes ou mais relevantes clinicamente foram os seguintes: 17 casos de mialgia, sete casos de pirexia, seis de dispneia, quatro de dor torácica, três casos de edema localizado, um caso de dor no local da infusão, um caso de conjuntivite. (41)

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **7. TEMPO DE TRATAMENTO – CRITÉRIOS DE INTERRUPÇÃO** -->
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, ao paciente ou aos pais ou responsáveis quando a TRE estiver sendo considerada e antes de iniciá-la. Durante o acompanhamento do paciente com TRE, os parâmetros de resposta terapêutica deverão ser avaliados periodicamente e discutidos com os pais, paciente ou responsáveis. No caso de interrupção por falha de adesão, o paciente e parentes deverão ser inseridos em programa de incentivo à adesão, e o paciente poderá retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas. O tempo de tratamento não pode ser pré-determinado, devendo ser mantido enquanto indicado e dele o doente se beneficie.  
O tempo de tratamento não pode ser pré-determinado, devendo ser mantido enquanto indicado e dele o doente se beneficie.  
Para fins deste PCDT, a TRE deve ser interrompida nas seguintes situações (45, 46):  
a) Pacientes que não apresentarem melhora após 6 meses de tratamento em pelo menos uma das seguintes manifestações clínicas que comprovadamente respondem ao tratamento com TRE: TC6M (melhora definida como o aumento da distância percorrida, em relação ao período basal, de pelo menos 45m); **<u>OU</u>** níveis basais de GAGs urinários (melhora definida como a redução dos níveis urinários de GAGs em pelo menos 60% em relação aos níveis basais); **<u>OU</u>** função pulmonar medida por espirometria (melhora definida como aumento da CVF ou do VEF1, na ausência de uso concomitante de broncodilatador, em pelo menos 10% em relação aos níveis basais).  
b) Pacientes que desenvolverem condição irreversível que implique em morte iminente, cujo prognóstico não se alterará devido ao uso da TRE, como resultado da MPS VI ou de outra doença associada, em acordo entre mais de um especialista.  
c) Pacientes que não apresentarem pelo menos 50% de adesão ao número de infusões previstas em um ano, ou ao número de consultas previstas em um ano, ou ao número de avaliações previstas em um ano  
com o médico responsável pelo seguimento do paciente, desde que previamente inseridos, sem sucesso, em programa específico para melhora de adesão, ou seja, pacientes que, mesmo após o programa, não comparecerem a pelo menos 50% do número de infusões, consultas ou avaliações previstas em um ano.  
d) Pacientes que apresentarem hipersensibilidade ou reação adversa grave (choque anafilático, risco de óbito) ao uso da galsulfase, que não podem ser controladas com segurança utilizando medidas terapêuticas e preventivas apropriadas.  
e) Pacientes com idade > 18 anos que, após serem devidamente informados sobre os riscos e benefícios de sua decisão, optarem por não mais se submeterem ao tratamento com TRE IV com galsulfase.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **8. MONITORIZAÇÃO** -->
Os pacientes devem ter a resposta terapêutica e os eventos adversos monitorados. O médico deve realizar anamnese completa em cada visita e coletar dados de altura (em pé ou em decúbito dorsal, e, no caso de restrições nos membros inferiores, por segmento), peso e perímetro cefálico, de preferência usando o mesmo instrumento, devidamente calibrado. O exame físico deve ser completo e incluir sinais vitais (temperatura, frequência cardíaca, frequência respiratória e pressão arterial), bem como medidas para quantificação do tamanho do fígado (por hepatimetria). A avaliação do desenvolvimento sexual deve ser realizada em adolescentes, de acordo com os critérios de Tanner (47, 48). Nas visitas, dados sobre todas as avaliações realizadas desde o último agendamento devem ser obtidos e os testes necessários devem ser solicitados, incluindo avaliação por especialistas em neurologia, otorrinolaringologia, ortopedia, oftalmologia, cardiologia e pneumologia, conforme indicação clínica e a critério do médico assistente.  
As avaliações de rotina devem ser realizadas semestralmente pelo médico assistente com vacinas, orientação dietética, exames e conselhos preventivos. (4) Os pacientes e seus familiares devem ter acesso ao aconselhamento genético.  
O **Apêndice 2** apresenta as avaliações consideradas mínimas para o acompanhamento de pacientes com MPS VI. São definidos períodos mínimos apenas para aquelas avaliações que têm por objetivo detectar a eficácia e segurança da TRE; para as demais, a periodicidade de avaliações fica a critério do médico assistente. Alguns componentes das avaliações específicas serão discutidos a seguir.  
Sugere-se que todos os pacientes sejam encaminhados para ortopedista com experiência em MPS ao diagnóstico. Para fins de diagnóstico e acompanhamento (conforme indicação clínica), devem ser realizadas radiografias do crânio (perfil), coluna vertebral (anteroposterior, lateral neutra e em flexão/extensão, incluindo região cervical), tórax (anteroposterior e lateral), coxofemoral (posteroanterior) e ambas as mãos. (49) Sobre-exposição à radiação deve ser evitada. Avaliação radiológica do quadril e membros inferiores devem focar na presença de displasia de quadril progressiva. (50)  
A avaliação da coluna deve focar na presença de estenose, instabilidade ou compressão medular. Com o objetivo de detectar precocemente essas alterações, é recomendada avaliação neurológica, que pode revelar hiperreflexia, hipertonia, sintomas piramidais ou déficits proprioceptivos (51).  
A análise de GAGs urinários pode ser quantitativa, por uso do método espectrofotométrico descrito por De Jong _et al_ . (52), ou permitir a identificação do tipo de GAG que está sendo excretado em quantidade aumentada na urina (por cromatografia ou eletroforese ou espectrometria de massa em tandem de GAGs).  
(4, 52, 53) A quantificação de GAGs urinários é utilizada para diagnóstico e, também, monitorização do tratamento específico da MPS VI, uma vez que, na vigência de tratamento, ocorre diminuição da excreção dessas moléculas (4, 54).  
Como parte da avaliação do tratamento, os seguintes itens devem ser respeitados:  
- Monitorar os resultados dos transplantes por meio de estudo observacional original.  
− Monitorar o uso, a adesão, a indicação e os resultados da TRE com galsulfase. Por meio desse monitoramento, será possível estabelecer grupos de pacientes que são de fato beneficiados e reavaliar a incorporação do medicamento a médio prazo.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
O tratamento da MPS VI deve ser feito por equipe em serviços especializados, para fins de diagnóstico e de acompanhamento dos pacientes e de suas famílias. Como o controle da doença exige experiência e familiaridade com manifestações clínicas associadas, convém que o médico responsável tenha experiência e seja treinado nessa atividade.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.  
Para a administração de medicamentos biológicos intravenosos, é essencial o atendimento centralizado, para maior racionalidade do uso e avaliação da efetividade dos medicamentos. A infusão deve ser feita em ambiente hospitalar.  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos (REREME/INCA/MS), e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os resultados de todos os casos MPS VI submetidos a TCTH mieloablativo halogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos 1 (um) ano da realização do transplante.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE - TER** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste PCDT, bem como critérios para interrupção do tratamento, levando-se em consideração as informações contidas no TER.  
Para o esclarecimento sobre os riscos e benefícios do transplante de células-tronco hematopoéticas  
alogênico, adotam-se as normas preconizadas no âmbito do Sistema Nacional de Transplantes.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **11. REFERÊNCIAS** -->
1. MJ NE. The Mucopolysaccharidoses.  The Online Metabolic and Molecular Bases of Inherited Disease.  
2. Spranger JW, Koch F, McKusick VA, Natzschka J, Wiedemann HR, Zellweger H. Mucopolysaccharidosis VI (Maroteaux-Lamy's disease). Helv Paediatr Acta. 1970;25(4):337-62.  
3. Giugliani R, Herber S, Lapagesse L, de Pinto C, Baldo G. Therapy for mucopolysaccharidosis VI: (Maroteaux-Lamy syndrome) present status and prospects. Pediatr Endocrinol Rev. 2014;12 Suppl 1:1528.  
4. Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18.  
5. Lowry RB, Applegarth DA, Toone JR, MacDonald E, Thunem NY. An update on the frequency of mucopolysaccharide syndromes in British Columbia. Hum Genet. 1990;85(3):389-90.  
6. Meikle PJ, Hopwood JJ, Clague AE, Carey WF. Prevalence of lysosomal storage disorders. JAMA. 1999;281(3):249-54.  
7. Nelson J. Incidence of the mucopolysaccharidoses in Northern Ireland. Hum Genet. 1997;101(3):355-8.  
8. Baehner F, Schmiedeskamp C, Krummenauer F, Miebach E, Bajbouj M, Whybra C, et al. Cumulative incidence rates of the mucopolysaccharidoses in Germany. J Inherit Metab Dis. 2005;28(6):1011-7.  
9. Pinto R, Caseiro C, Lemos M, Lopes L, Fontes A, Ribeiro H, et al. Prevalence of lysosomal storage diseases in Portugal. Eur J Hum Genet. 2004;12(2):87-92.  
10. Poorthuis BJ, Wevers RA, Kleijer WJ, Groener JE, de Jong JG, van Weely S, et al. The frequency of lysosomal storage diseases in The Netherlands. Hum Genet. 1999;105(1-2):151-6.  
11. Valayannopoulos V, Nicely H, Harmatz P, Turbeville S. Mucopolysaccharidosis VI. Orphanet J Rare Dis. 2010;5:5.  
12. Coelho JC, Wajner M, Burin MG, Vargas CR, Giugliani R. Selective screening of 10,000 highrisk Brazilian patients for the detection of inborn errors of metabolism. Eur J Pediatr. 1997;156(8):650-4.  
13. Giugliani R, Federhen A, Michelin-Tirelli K, Riegel M, Burin M. Relative frequency and estimated minimal frequency of Lysosomal Storage Diseases in Brazil: Report from a Reference Laboratory. Genet Mol Biol. 2017;40(1):31-9.  
14. Karageorgos L, Brooks DA, Pollard A, Melville EL, Hein LK, Clements PR, et al. Mutational analysis of 105 mucopolysaccharidosis type VI patients. Hum Mutat. 2007;28(9):897-903.  
15. Brasil C-M-. Galsulfase para o tratamento da mucopolissacaridose tipo VI2018.  
16. Dierks T, Dickmanns A, Preusser-Kunze A, Schmidt B, Mariappan M, von Figura K, et al. Molecular basis for multiple sulfatase deficiency and mechanism for formylglycine generation of the human formylglycine-generating enzyme. Cell. 2005;121(4):541-52.  
17. Human Gene Mutation Database: http://www.hgmd.cf.ac.uk/ac/index.php;  [  
18. Pastores GM. Musculoskeletal complications encountered in the lysosomal storage disorders. Best Pract Res Clin Rheumatol. 2008;22(5):937-47.  
19. Turra GS, Schwartz IV. Evaluation of orofacial motricity in patients with mucopolysaccharidosis: a cross-sectional study. J Pediatr (Rio J). 2009;85(3):254-60.  
20. Schwartz IV, Souza CF, Giugliani R. Treatment of inborn errors of metabolism. J Pediatr (Rio J). 2008;84(4 Suppl):S8-19.  
21. Giugliani R, Federhen A, Vairo F, Vanzella C, Pasqualim G, da Silva LM, et al. Emerging drugs for the treatment of mucopolysaccharidoses. Expert Opin Emerg Drugs. 2016;21(1):9-26.  
22. White KK. Orthopaedic aspects of mucopolysaccharidoses. Rheumatology (Oxford). 2011;50 Suppl 5:v26-33. 23. Saúde Md. Asma. In: Conitec, editor. <u>http://portalarquivos2.saude.gov.br/images/pdf/2014/julho/22/PT-SAS-N---1317-alterado-pela-603-de21-de-julho-de-2014.pdf2013.</u> 24. Ashworth JL, Biswas S, Wraith E, Lloyd IC. The ocular features of the mucopolysaccharidoses. Eye (Lond). 2006;20(5):553-63. 25. Käsmann-Kellner B, Weindler J, Pfau B, Ruprecht KW. Ocular changes in mucopolysaccharidosis IV A (Morquio A syndrome) and long-term results of perforating keratoplasty. Ophthalmologica. 1999;213(3):200-5. 26. Reichert R, Campos LG, Vairo F, de Souza CF, Pérez JA, Duarte J, et al. Neuroimaging Findings in Patients with Mucopolysaccharidosis: What You Really Need to Know. Radiographics. 2016;36(5):1448-62.  
27. Azevedo AC, Schwartz IV, Kalakun L, Brustolin S, Burin MG, Beheregaray AP, et al. Clinical and biochemical study of 28 patients with mucopolysaccharidosis type VI. Clin Genet. 2004;66(3):208-13. 28. Kachur E, Del Maestro R. Mucopolysaccharidoses and spinal cord compression: case report and review of the literature with implications of bone marrow transplantation. Neurosurgery. 2000;47(1):2238; discussion 8-9. 29. Williams N, Cundy P, Eastwood D. Surgical Management of Thoracolumbar Kyphosis in Patients with Mucopolysaccharidosis: A Systematic Review. Spine (Phila Pa 1976). 2017. 30. Roberts SB, Dryden R, Tsirikos AI. Thoracolumbar kyphosis in patients with mucopolysaccharidoses: clinical outcomes and predictive radiographic factors for progression of deformity. Bone Joint J. 2016;98-B(2):229-37. 31. Dalvie SS, Noordeen MH, Vellodi A. Anterior instrumented fusion for thoracolumbar kyphosis in mucopolysaccharidosis. Spine (Phila Pa 1976). 2001;26(23):E539-41. 32. Bekmez S, Demirkiran HG, Dede O, Ismayilov V, Yazici M. Surgical Management of Progressive Thoracolumbar Kyphosis in Mucopolysaccharidosis: Is a Posterior-only Approach Safe and Effective? J Pediatr Orthop. 2018;38(7):354-9. 33. Nayak DR, Balakrishnan R, Murthy KD. An endoscopic approach to the deviated nasal septum-a preliminary study. J Laryngol Otol. 1998;112(10):934-9. 34. Shinhar SY, Zablocki H, Madgy DN. Airway management in mucopolysaccharide storage disorders. Arch Otolaryngol Head Neck Surg. 2004;130(2):233-7. 35. Brain AI. The laryngeal mask--a new concept in airway management. Br J Anaesth. 1983;55(8):801-5. 36. Walker RW, Allen DL, Rothera MR. A fibreoptic intubation technique for children with mucopolysaccharidoses using the laryngeal mask airway. Paediatr Anaesth. 1997;7(5):421-6. 37. Hoogerbrugge PM, Brouwer OF, Bordigoni P, Ringden O, Kapaun P, Ortega JJ, et al. Allogeneic bone marrow transplantation for lysosomal storage diseases. The European Group for Bone Marrow Transplantation. Lancet. 1995;345(8962):1398-402. 38. Krivit W. Allogeneic stem cell transplantation for the treatment of lysosomal and peroxisomal metabolic diseases. Springer Semin Immunopathol. 2004;26(1-2):119-32. 39. Herskhovitz E, Young E, Rainer J, Hall CM, Lidchi V, Chong K, et al. Bone marrow transplantation for Maroteaux-Lamy syndrome (MPS VI): long-term follow-up. J Inherit Metab Dis. 1999;22(1):50-62. 40. Gomes DF, Gallo LG, Leite BF, Silva RB, da Silva EN. Clinical effectiveness of enzyme replacement therapy with galsulfase in mucopolysaccharidosis type VI treatment: Systematic review. J Inherit Metab Dis. 2019;42(1):66-76. 41. Harmatz P, Giugliani R, Schwartz I, Guffon N, Teles EL, Miranda MC, et al. Enzyme replacement therapy for mucopolysaccharidosis VI: a phase 3, randomized, double-blind, placebo-controlled, multinational study of recombinant human N-acetylgalactosamine 4-sulfatase (recombinant human arylsulfatase B or rhASB) and follow-on, open-label extension study. J Pediatr. 2006;148(4):533-9. 42. Harmatz PR, Lampe C, Parini R, Sharma R, Teles EL, Johnson J, et al. Enzyme replacement therapy outcomes across the disease spectrum: Findings from the mucopolysaccharidosis VI Clinical Surveillance Program. J Inherit Metab Dis. 2019;42(3):519-26. 43. Inc. BP. Prescribing Information Naglazyme https://www.naglazyme.com/2019 [ 44. Giugliani R, Lampe C, Guffon N, Ketteridge D, Leão-Teles E, Wraith JE, et al. Natural history and galsulfase treatment in mucopolysaccharidosis VI (MPS VI, Maroteaux-Lamy syndrome)--10-year follow-up of patients who previously participated in an MPS VI Survey Study. Am J Med Genet A. 2014;164A(8):1953-64.  
45. Giugliani R, Federhen A, Muñoz Rojas MV, Vieira TA, Artigalás O, Pinto LL, et al. [Enzyme replacement therapy for mucopolysaccharidoses I, II and VI: recommendations from a group of Brazilian F experts]. Rev Assoc Med Bras (1992). 2010;56(3):271-7.  
46. Brunelli MJ, Atallah Á, da Silva EM. Enzyme replacement therapy with galsulfase for mucopolysaccharidosis type VI. Cochrane Database Syst Rev. 2016;3:CD009806.  
47. Marshall WA, Tanner JM. Variations in pattern of pubertal changes in girls. Arch Dis Child. 1969;44(235):291-303.  
48. Marshall WA, Tanner JM. Variations in the pattern of pubertal changes in boys. Arch Dis Child. 1970;45(239):13-23.  
49. Garcia P, Sousa SB, Ling TP, Conceição M, Seabra J, White KK, et al. Skeletal complications in mucopolysaccharidosis VI patients: Case reports. J Pediatr Rehabil Med. 2010;3(1):63-9.  
50. Oussoren E, Bessems JHJM, Pollet V, van der Meijden JC, van der Giessen LJ, Plug I, et al. A long term follow-up study of the development of hip disease in Mucopolysaccharidosis type VI. Mol Genet Metab. 2017;121(3):241-51.  
51. Horovitz DD, Magalhães TeS, Pena e Costa A, Carelli LE, Souza e Silva D, de Linhares e Riello AP, et al. Spinal cord compression in young children with type VI mucopolysaccharidosis. Mol Genet Metab. 2011;104(3):295-300.  
52. de Jong JG, Hasselman JJ, van Landeghem AA, Vader HL, Wevers RA. The spot test is not a reliable screening procedure for mucopolysaccharidoses. Clin Chem. 1991;37(4):572-5.  
53. Auray-Blais C, Lavoie P, Tomatsu S, Valayannopoulos V, Mitchell JJ, Raiman J, et al. UPLCMS/MS detection of disaccharides derived from glycosaminoglycans as biomarkers of mucopolysaccharidoses. Anal Chim Acta. 2016;936:139-48.  
54. Swiedler SJ, Beck M, Bajbouj M, Giugliani R, Schwartz I, Harmatz P, et al. Threshold effect of urinary glycosaminoglycans and the walk test as indicators of disease progression in a survey of subjects with Mucopolysaccharidosis VI (Maroteaux-Lamy syndrome). Am J Med Genet A. 2005;134A(2):144-50.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Eu,____________________________________________________ (nome do(a) paciente),  
declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **galsulfase,** indicada para o tratamento da **mucopolissacaridose tipo VI** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico  
_______________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber podem trazer os seguintes benefícios:  
- melhora dos sintomas da doença, como melhora no teste de caminhada em 12 minutos, melhora  
- da função pulmonar e redução dos glicosaminoglicanos (GAGs) urinários.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- medicamento classificado na gestação como fator de risco B (estudos em animais não mostraram  
- anormalidades, embora estudos em mulheres não tenham sido feitos; o medicamento deve ser prescrito com cautela);  
- efeitos adversos da galsulfase: aqueles relatados em dois ou mais estudos foram problemas na  
pele, coceiras na pele e febre.  
- contraindicação em casos de hipersensibilidade (alergia) ao fármaco ou aos componentes da  
- fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas  
ao meu tratamento, desde que assegurado o anonimato.   (    ) Sim (    ) Não  
|Local:                                                                                          Data:|
|---|
|Nome do paciente:|
|Cartão Nacional do SUS:|
|Nome do responsável legal:|
|Documento de identificação do responsável legal:|
|Assinatura do paciente ou do responsável legal|
|Médico:                                                                           CRM:                                 RS:<br>______________________________|  
Assinatura e carimbo do médico  
Data:  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: SUPORTE E SINTOMÁTICOS -->
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
|**Sistema nervoso**<br>**periférico**|Compressão medular|Cirurgia, fisioterapia|
|**Olhos**|Acuidade visual diminuída<br>Opacificação de córnea|Avaliação oftalmológica<br>Transplante de córnea (em casos específicos)|
|**Vias aéreas**|Síndrome da apneia obstrutiva do sono<br>Infecções de repetição, hipersecreção<br>Doença pulmonar restritiva|Amigdalectomia, adenoidectomia,<br>oxigenioterapia<br>Avaliação funcional pulmonar<br>Farmacoterapia<br>Fisioterapia|
|**Tecido conjuntivo**|Hérnias|Cirurgia|
|**Articulações**|Dor, contraturas|Fisioterapia, terapia ocupacional<br>Farmacoterapia|
|**Ossos**|Geno valgo, luxação de quadril|Correção cirúrgica|
|**Orelhas**|Hipoacusia|Próteses (em casos específicos)|
||Otites de repetição|Farmacoterapia, cirurgia|
|**Gastrointestinal**|Diarreia<br>Ganho inadequado ou excessivo de peso|Orientação nutricional<br>Orientação nutricional|
||Distúrbio deglutição|Farmacoterapia, fonoaudiologia<br>Cirurgia (gastrostomia)|
|**Bucomaxilofacial**|Mal oclusão, dentição anômala|Cirurgia<br>Aparelho ortodôntico|
|**Cardiovascular**|Valvulopatias, cardiomiopatia, insuficiência<br>cardíaca|Farmacoterapia, cirurgia|  
Fonte: Elaborado a partir de Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18. _al_ (4).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: PROGRAMA MÍNIMO DE AVALIAÇÕES PARA SEGUIMENTO CLÍNICO -->
DOS PACIENTES COM MPS VI  SOB TERAPIA DE REPOSIÇÃO ENZIMÁTICA OU NÃO (4)  
|**Avaliações**|**Avaliação**<br>**inicial**|**A cada 6**<br>**meses**|**A cada 12**<br>**meses**|
|---|---|---|---|
|**Atividade enzimática**|X|X*||
|**GAGs urinários**|X|X**||
|**História médica**|X|X||
|**Aconselhamento Genético**|X|||
|**Revisão do número de infusões realizadas no período*****||X||
|**Determinação da adesão ao acompanhamento/tratamento****|X|X||
|**Peso/altura**|X|X||
|**Pressão arterial**|X|X||
|**Hepatimetria (exame físico)**|X|X||
|**Questionário de qualidade de vida validado**|X||X**|
|**AVALIAÇÃO NEUROLÓGICA**||||
|**- Exame neurológico**|X|||
|**- RNM do crânio**|X|||
|**- RNM da coluna**|X|||
|**- Velocidade de condução do nervo mediano**|X|||
|**- Avaliação do neurodesenvolvimento**|X|||
|**AVALIAÇÃO OFTALMOLÓGICA (acuidade visual, retina,**|X|||
|**córnea)**||||
|**AUDIOMETRIA**|X|||
|**AVALIAÇÃO FUNCIONAL**||||
|**- Ecocardiograma**|X|||  
|**- Eletrocardiograma**|X|||
|---|---|---|---|
|**- TC12M****|X|X||
|**- CVF/VEF1 (espirometria)****|X|X|X|
|**- Polissonografia**|X|||
|**AVALIAÇÃO DA MOBILIDADE ARTICULAR**|X|||
|**RAIO-X ÓSSEO**|X|||  
*Para pacientes que fizeram transplante de células-tronco hematopoiéticas. **Para pacientes que fizeram transplante de células-tronco hematoipoiéticas ou estão em terapia de reposição enzimática, quando capazes de realizar a avaliação. ***Para pacientes em terapia de reposição enzimática. As demais avaliações, incluindo as avaliações indicadas somente no período basal (iniciais) devem ser realizadas em períodos determinados pelo médico assistente. GAGs = glicosaminoglicanos; RNM = ressonância magnética; TC12M = teste de caminhada em 12 minutos; CVF = capacidade vital forçada; VEF1 = volume expiratório forçado no primeiro segundo.  
Fonte: Elaborado a partir de Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18. _al_ (4).  
**APÊNDICE 3**  
METODOLOGIA DE BUSCA E AVALIAÇÃO DE LITERATURA

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **1. POLÍTICA NACIONAL DE ATENÇÃO INTEGRAL ÀS PESSOAS COM DOENÇAS RARAS** -->
A Política Nacional de Atenção Integral às Pessoas com Doenças Raras foi publicada em 12 de fevereiro de 2014 por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014<sup>1</sup> , que, além de instituir a referida política, também aprovou as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde - SUS e instituiu incentivos financeiros de custeio.  
Essa Política tem como objetivo reduzir a mortalidade e a incapacidade causadas por essas doenças, bem como contribuir para a melhoria da qualidade de vida das pessoas com doenças raras. Está organizada no conceito das Redes de Atenção à Saúde (RAS), considerando-se todos os pontos de atenção, bem como os sistemas logísticos e de apoio necessários para garantir a oferta de ações de promoção, detecção precoce, diagnóstico, tratamento e cuidados paliativos, de forma oportuna, para as pessoas com doenças raras.  
A Política utiliza como definição de doença rara a estabelecida pela Organização Mundial da Saúde, isto é, “aquela doença que afeta até 65 pessoas em cada 100.000 indivíduos, ou seja, 1,3 pessoas para cada 2.000 indivíduos”, conforme estabelecido nas diretrizes citadas acima.  
Como não seria possível organizar as diretrizes abordando as doenças raras de forma individual, devido ao grande número de doenças, as diretrizes políticas foram organizadas na forma de eixos estruturantes, que permitem classificar as doenças raras de acordo com suas características comuns, com a finalidade de maximizar os benefícios aos usuários.  
Dessa forma, as doenças raras foram classificadas em dois eixos: a) Doenças raras de origem genética, com três grupos: 1 - Anomalias congênitas ou de manifestação tardia, 2 - Deficiência intelectual, 3 - Erros inatos do metabolismo; b) Doenças Raras de origem não genética, com os seguintes grupos de causas: 1 - Infecciosas, 2 - Inflamatórias, 3 - Autoimunes, 4 - Outras doenças raras não genéticas.  
Para a implantação e implementação dessa política foram incorporados, inicialmente, quinze exames na Tabela de Procedimentos, Medicamentos, Órteses, Próteses de Materiais Especiais do SUS, abrangendo biologia molecular, citogenética e imunoensaios, além do aconselhamento genético.  
Os princípios e diretrizes daquela Portaria, expressos no artigo 6º, inciso VI, visam a garantir a incorporação e o uso de tecnologias voltadas para a promoção, prevenção e cuidado integral na RAS, incluindo tratamento medicamentoso e fórmulas nutricionais, quando indicados no âmbito do SUS, que devem ser resultado das recomendações formuladas por órgãos governamentais a partir do processo de avaliação e aprovação pela Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) e elaboração dos Protocolos Clínicos e Diretrizes Terapêuticas (PCDT).  
Para viabilizar as definições e implementação da Política, a Coordenação de Média e Alta Complexidade (CGMAC), juntamente com a CONITEC, organizou um encontro com especialistas que atuam na área de doenças raras em todo o País, abarcando os dois eixos da Política e seus respectivos grupos supracitados. O “Painel de Especialistas”, realizado nos dias 19 e 20 de maio de 2014, objetivou estabelecer critérios e prioridades para a elaboração de PCDTs para a implementação da Política Nacional de Atenção  
1 Republicada para consolidar as alterações introduzidas pela Portaria nº 981/GM/MS, de 20 de maio de 2014, publicada no Diário Oficial da União nº 95, de 21 de maio de 2014, Seção 1, página 44.  
Integral às Pessoas com Doenças Raras no SUS. Entre as doenças elencadas para elaboração de PCDT priorizados, está a mucopolissacaridose tipo VI (MPS VI).

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **2. REUNIÃO DE ESCOPO** -->
A fim de dar continuidade ao processo de elaboração do PCDT, foi realizada uma reunião de escopo com o comitê gestor e elaborador deste PCDT, realizada dia 25 de fevereiro de 2019, no Hospital Alemão Oswaldo Cruz (HAOC), quando foram estabelecidas as seguintes perguntas de pesquisa para elaboração deste PCDT:  
- A galsulfase é eficaz para os seguintes desfechos: sobrevida, qualidade de vida, número de  
infecções de vias respiratórias, cardiopatia, eventos adversos, doença óssea, doença ocular?  
- A galsulfase é segura em gestantes e pacientes em aleitamento materno?  
- Quais são os critérios para interrupção de tratamento com galsulfase?  
- Até qual idade o TCTH é efetivo?

---

<!-- METADADOS: doenca: Mucopolissacaridose Tipo VI | secao: **3. BUSCAS NA LITERATURA** -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio da CONITEC para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da MPS 1. Foi também realizada busca por diretrizes nacionais e internacionais a respeito da doença.  
Não foram encontradas tecnologias disponíveis, já incorporadas ou em avaliação.  
As seguintes bases de protocolos e diretrizes foram consultadas:  
- NICE _guidelines_ (http://www.nice.org.uk/guidance/published?type=CG);  
- _National Library of Australia_ – http://webarchive.nla.gov.au/gov/;  
- Diretrizes da Associação Médica Brasileira (AMB).  
- PCDT MS  
- PubMed/MEDLINE  
As diretrizes localizadas foram as seguintes:  
- Terapia de reposição enzimática para as mucopolissacaridoses I, II e VI: recomendações de um grupo de especialistas brasileiros. Giugliani R, _et al._ Rev Assoc Med Bras. 2010; 56(3): 257-77.  
- _Mucopolysaccharidosis I, II, and VI: Brief review and guidelines for treatment._ Giugliani R, _et al._ Genet Mol Biol. 2010; 33(4): 589-604.  
- Giugliani R, Harmatz P, Wraith JE. Management guidelines for mucopolysaccharidosis VI. Pediatrics. 2007;120(2):405-18.  
Após a reunião de escopo, ficou estabelecido que o PCDT se destina a crianças e adultos com MPS VI, de ambos os sexos, e tem por objetivo revisar práticas diagnósticas e terapêuticas e incorporar as recomendações referentes ao tratamento medicamentoso com a terapia de reposição enzimática com galsulfase e ao tratamento com TCTH.  
Para a elaboração dos critérios diagnósticos e para a avaliação das situações especiais de gestação e aleitamento foram utilizadas diretrizes internacionais elaboradas por diferentes grupos de especialistas, que são utilizadas como consenso nos diversos centros de referência.  
Para avaliação de interrupção de tratamento, foi utilizada a seguinte estratégia de busca: “(mucopolysaccharidosis type vi OR Maroteaux-Lamy syndrome) AND interruption”, sendo apenas um resultado encontrado, a revisão sistemática da Cochrane listada abaixo. A base de dados buscada foi MEDLINE/PubMed e a referência encontradas não respondia à pergunta definida na reunião de escopo, sendo utilizadas as diretrizes internacionais acima citadas para responder à questão.  
- Brunelli MJ, Atallah ÁN, da Silva EMK. Enzyme replacement therapy with galsulfase for mucopolysaccharidosis type VI. Cochrane Database of Systematic Reviews 2016, Issue 3.  
Para a elaboração dos demais itens do PCDT, foram utilizadas as buscas, resultados recomendações e referências constantes no relatório de recomendação da galsulfase como terapia de reposição enzimática no tratamento da MPS VI, disponível em <u>http://conitec.gov.br/images/Relatorios/2018/Recomendacao/Relatorio_Galsulfase_MPS_VI.pdf</u>

---

