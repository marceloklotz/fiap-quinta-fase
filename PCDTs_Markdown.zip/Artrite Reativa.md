<!-- METADADOS: doenca: Artrite Reativa | secao: Geral -->
<!-- Start of picture text -->
Bi"0<br>ee<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Artrite Reativa | secao: PORTARIA CONJUNTA Nº 06, DE 22 DE ABRIL DE 2021. -->
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reativa.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a artrite reativa no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnicocientífico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 582/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 587 – Fevereiro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Artrite Reativa.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da artrite reativa, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticaspcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos</u> Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da artrite reativa.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.150/SAS/MS, de 11 de novembro de 2015, publicada no Diário Oficial da União nº 216, de 12 de novembro de 2015, seção 1, página65.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: HÉLIO ANGOTTI NETO -->
**ANEXO**

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **1.  INTRODUÇÃO** -->
A artrite reativa (ARe) pertence ao grupo das espondiloartrites (EpA), as quais são doenças reumáticas crônicas que afetam articulações periféricas e axiais, com características clínicas, radiológicas e genéticas semelhantes.  
As EpA integram um grupo constituído das seguintes doenças: Espondilite Anquilosante (EA), Artrite Psoríaca (AP), Espondiloartrite Enteropática (AE), Artrite Relacionada à Entesite (ARE - forma juvenil) e a Espondiloartrite Indiferenciada<sup>1</sup> .  
A ARe é definida como uma sinovite estéril imunomediada que se desenvolve em até 4 semanas após infecções gastrointestinais ou genitourinárias<sup>2</sup> , causadas por um entre os seguintes patógenos: _Chlamydia trachomatis_ , _Yersinia_ (principalmente _Y. enterocolítica_ e _Y. pseudotuberculosis_ ), _Salmonella_ sp., _Shigella_ (particularmente _S flexneri_ ), _Campylobacter jejuni_ , _Escherichia coli_ e _Clostridioides difficile_<sup>3,4</sup> . Classicamente se manifesta por quadro de mono- ou oligoartrite (até 4 articulações acometidas) assimétrica estéril, em particular de membros inferiores, e que na maioria das vezes é transitória.  
As artrites que ocorrem após infecções estreptocócicas, virais ou por borrélias não fazem parte do grupo das ARe e devem ser denominadas de artrites reacionais ou relacionadas a infecções<sup>5</sup> . São também exemplos de artrite reacional os quadros articulares pós-infecção pelo chikungunya e a artrite que pode acometer pacientes submetidos à terapia intravesical com extrato do BCG (bacilo de Calmette-Guerin)<sup>6,7</sup> . Artrite tem sido também mencionada após Covid-19 (https://www.translationalres.com/article/S1931-5244(21)00047-5/fulltext).  
A comprovação do quadro infeccioso em caso de ARe pode ser difícil, porque em muitos pacientes o quadro infeccioso é assintomático, sobretudo quando o foco é genitourinário, particularmente nas mulheres. Além disso, as manifestações musculoesqueléticas podem acontecer depois que o evento infeccioso gastrointestinal já estiver resolvido. Pode haver, ainda, sintomas gerais inespecíficos (mal-estar geral, febre e fadiga). O acometimento poliarticular ocorre em 20%-30% dos casos, e podem haver manifestações mucocutâneas, que se associam à presença do antígeno leucocitário humano B27 (HLA-B27)<sup>2</sup> .  
O subtipo de ARe que se apresenta como de artrite, conjuntivite e uretrite era denominado Doença de Reiter, termo que não é mais utilizado<sup>8</sup> , embora ainda constante da CID-10.  
A ARe é uma doença infrequente, e os poucos estudos epidemiológicos sobre ela são heterogêneos. A sua incidência é provavelmente subestimada, uma vez que casos leves são subdiagnosticados<sup>9</sup> .  No Brasil,  em 2010 , de um total de 1.472 pacientes do Registro Brasileiro de Espondiloartrites (RBE), apenas 49 (3,3%) foram classificados como ARe<sup>10</sup> . A ARe atinge predominantemente adultos jovens entre 20 e 40 anos e acomete mais  
homens do que mulheres, com uma taxa de 3:1 quando a infecção inicial é genitourinária. Após infecções entéricas, a ARe parece acometer ambos os sexos em proporção semelhante<sup>3</sup> .  
A evolução clínica da ARe pode seguir diversos padrões: curso autolimitado, recorrente ou contínuo (crônico). Estabeleceu-se por consenso que os quadros com duração acima de seis meses são considerados crônicos. O prognóstico da maior parte dos casos é bom, com a maioria dos pacientes recuperando-se gradualmente em poucos meses<sup>2,10,11</sup> . Contudo, observou-se um curso prolongado e crônico da artrite em cerca de 2%-19% dos pacientes, dependendo do agente desencadeador, da presença do HLA-B27 e do tempo de seguimento. Observou-se cronificação em 4% dos casos pós-infecção por _Yersinia_ , em 19% daqueles pós-infecção por _Salmonella_ e _Shigella_ e em 17% daqueles pós-infecção por _Chlamydia_ . Entre os pacientes que evoluem com acometimento articular crônico, de 14% a 49% apresentam predomínio axial (sacroiliíte em 14%-49% dos casos ou semelhante à EA entre 12% e 26%). O quadro periférico (forma oligoarticular) pode se assemelhar à AP<sup>5,12,13</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da artrite reativa. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **2.  CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID10)** -->
- M03.2: outras artropatias pós-infecciosas em doenças classificadas em outra parte.  
- M03.6: artropatia reacional em outras doenças classificadas em outra parte.  
- M02.1: artropatia pós-desintérica.  
- M02.3: doença de Reiter.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **3.  DIAGNÓSTICO** -->
O diagnóstico de artrite reativa é feito pela anamnese, exame físico e raciocínio clínico, com o auxílio dos exames complementares, já que não existem marcadores laboratoriais ou de imagem que lhe sejam específicos<sup>15-19</sup> .  
A manifestação clínica mais comum (95%) da ARe é a presença de oligoartrite aguda e assimétrica de membros inferiores, principalmente em joelhos, tornozelos e articulações metatarsofalângicas.  Muitos pacientes não apresentam sintomas relacionados à infecção precedente, mas podem ocorrer sintomas gerais inespecíficos, como mal-estar geral, febre e fadiga. Dentro do grupo das EpA, a ARe é a que pode cursar com febre. O acometimento poliarticular não é frequente, embora possa ocorrer em 20%-30% dos casos. As manifestações mucocutâneas incluem úlceras orais indolores e autolimitadas, ceratodermia blenorrágica, pústulas palmoplantares e balanite circinada. A balanite pode surgir em qualquer fase da doença e  
independentemente da atividade articular. Pode haver, ainda, prostatite crônica, bem como cervicite ou salpingite crônicas, com consequente esterilidade feminina<sup>2</sup> .  
<mark>O</mark> _<mark>American College of Rheumatology</mark>_ <mark>(ACR) estabeleceu em 1999 os critérios diagnósticos para a ARe, sendo considerado um diagnóstico definitivo quando tanto os critérios maiores quanto os menores estão presentes, e provável quando há apenas os maiores ou um critério maior acompanhado de pelo menos um critério menor.</mark>  
<mark>São critérios maiores:</mark>  
1. <mark>Artrite com pelo menos 2 de 3 características (assimétrica, mono ou oligoarticular, acometimento de membros inferiores); e</mark>  
2. <mark>infecção sintomática precedendo o quadro articular com pelo menos uma das características (enterite – diarreia por ao menos um dia entre 3 dias a 6 semanas do início da artrite; uretrite – disúria ou descarga uretral por ao menos um dia entre 3 dias a 6 semanas do início da artrite).</mark>  
<mark>Já os critérios menores são:</mark>  
1. <mark>Evidência de infecção da uretra ou do colo uterino por</mark> _<mark>Chlamydia trachomatis</mark>_ <mark>; e</mark>  
2. <mark>cultura de fezes positiva para patógenos entéricos acima mencionados e reação em cadeia de polimerase (PCR, sigla em Inglês) positiva para</mark> _<mark>Chlamydia</mark>_ <mark>no líquido sinovial</mark><sup>14</sup> <mark>.</mark>  
<mark>A necessidade de comprovação da infecção precedente por meio de cultura, presença de ácido desoxirribonucleico (DNA, sigla em Inglês) do agente causal ou anticorpos contra o mesmo não é prática, uma vez que a infecção, particularmente a genitourinária, pode ser assintomática e a sensibilidade dos testes pode não ser suficiente</mark><sup>14</sup> <mark>. Assim, o diagnóstico precisa contemplar a presença da infecção, embora não seja necessária a comprovação do agente etiológico.</mark>  
Há também a possibilidade de utilização dos critérios classificatórios propostos pelo ASAS ( _Assessment on SpondyloArthritis International Society)_ como auxiliar no raciocínio clínico para o diagnóstico, pois são mais abrangentes e contemplam tanto as queixas predominantemente axiais (EpA-ax) quanto aquelas predominantemente periféricas (EpA-p) ( **Quadro 1** )<sup>15-18</sup> .  
**Quadro 1 -** Critérios de classificação ASAS para espondiloartrite  
(queixas predominantemente axiais ou predominantemente periféricas)  
|**AXIAL**|**PERIFÉRICO**|
|---|---|
|Para pacientes com dor nas costas ou na coluna<br>vertebral (axial) com mais de 3 meses de duração<br>e idade de início menor que 45 anos:|Para pacientes com manifestações exclusivamente<br>periféricas<sup>2</sup>:|
|Imagem de<br>sacroiliíte<sup>1</sup><br>+<br>OU<br>HLA-B27 positivo*<br>+|Artrite OU Entesite OU Dactilite*<br>+|  
||1 achado<br>2 achados|Pelo menos 1 dos seguintes achados:|
|---|---|---|
|re|lacionado às<br>relacionados às EpAs||
||EpAs||
|Ach|ados de EpA|<br>Uveíte anterior|
||Dor lombar inflamatória<sup>3</sup>|<br>Psoríase|
||Artrite|<br>DII (atual)|
|<br><br>|Entesite (inserção tendão de Aquiles ou fáscia<br>plantar)<br>Uveíte anterior<br>Dactilite|<br>Infecção recente (urogenital ou intestinal)<sup>8</sup><br><br>HLA-B27 positivo<br><br>Imagem de sacroiliíte<sup>1</sup><br>OU|
|<br><br>|Psoríase<sup>4</sup><br>Doença inflamatória intestinal (DII)<sup>5</sup><br>Boa resposta ao anti-inflamatório não<br>esteroidal (AINE)<sup>6</sup>|Pelo menos 2 dos seguintes achados:<br><br>Artrite<br><br>Entesite|
||História familiar de EpA<sup>7</sup>|<br>Dactilite|
||HLA-B27 positivo|<br>Passado de DII|
||PCR elevada|<br>História familiar de EpA|  
1) Inflamação ativa (aguda) na RNM altamente sugestiva de sacroiliíte associada com espondiloartrite (EpA) ou sacroiliíte definida radiograficamente de acordo com os critérios de Nova Iorque modificados (bilateral grau maior ou igual a II ou unilateral grau maior ou igual a III).  
2) Geralmente assimétrica, mono ou oligoarticular ou com predomínio em membros inferiores.  
3) Definida por pelo menos 4 dos 5 critérios a seguir: 1. idade de <40 anos; 2. início insidioso; 3. melhora com exercício; 4. não melhora com repouso; 5. dor noturna (com melhora ao levantar).  
4) Diagnóstico médico (passado ou atual).  
5)  Diagnóstico médico de DII (atual ou pregresso): doença de Crohn ou retocolite ulcerativa (comprovação por endoscopia, imagem ou biópsia).  
6) Melhora acima de 80% após 24-48h de uso de AINE em dose plena e piora após 24-48h de sua interrupção.  
7) Presença de parentes de primeiro grau (mãe, pai, irmãos, filhos) ou de segundo grau (avós, tios, sobrinhos) com espondilite anquilosante, psoríase, uveíte anterior, artrite reativa ou DII.  
8)  Infecção genital (uretrite ou cervicite não gonocócica) ou intestinal (diarreia) **nas últimas 4 semanas** que antecederam o surgimento da artrite, entesite, dactilite.  
* Se usado como critério de entrada, não deve ser usado novamente como achado no box seguinte.  
AINE, anti-inflamatório não esteroidal; DII, doença inflamatória intestinal; EpA, espondiloartrite; PCR, proteína  
C reativa; RNM, ressonância nuclear magnética, HLA-B27, Antígeno Leucocitário Humano subtipo B27.  
Os critérios ASAS podem ser usados e recomendados na prática assistencial, apesar de não serem utilizados isoladamente para diagnóstico de ARe, uma vez que aglutinam características clínicas articulares e extra-articulares, bem como achados de exames laboratoriais e de imagem. Além disso, eles têm sido validados  
em diversas compilações de estudos clínicos nos últimos 10 anos, atestando bom desempenho (especificidade acima de 80%)<sup>19</sup> .  
As definições do intervalo da infecção precedente para o início do quadro articular variam de 4 a 6 semanas, sendo o intervalo de até 6 semanas estabelecido pelo ACR, e de até 4 semanas por outros grupos reconhecidos, como o _European Spondyloarthropathy Study Group_ (ESSG), Amor e ASAS. Foi consenso entre os especialistas que, para o presente PCDT, fosse adotado o período de até 4 semanas<sup>16,18,20,21</sup> .  
Na ARe, importa estabelecer-se o diagnóstico correto ao considerar a queixa articular (predominância periférica ou axial) e a infecção genitourinária ou gastrointestinal prévia. Embora os exames complementares (laboratoriais e de imagem) não sejam mandatórios para o estabelecimento do diagnóstico, podem auxiliar na investigação etiológica da infecção desencadeante, adequado diagnóstico diferencial e acompanhamento evolutivo do dano estrutural no subgrupo de pacientes cujo quadro articular venha a se tornar crônico<sup>15-19, 27-</sup> 31,37-39.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **3.1.  Exames Laboratoriais** -->
Em pacientes com história precedente de infecção genitourinária, a pesquisa da clamídia pode ser feita por meio de anticorpos específicos (sorologia) para _Chlamydia trachomatis_ IgM ou IgG (infecção tardia). A presença de anti-IgM pode auxiliar o raciocínio clínico, pois indica infecção recente. No entanto, a presença da anti-IgG não tem valor clínico, pois a prevalência na população geral é elevada (10%-40%) e reflete contato passado, muitas vezes assintomático, especialmente em mulheres<sup>22-26</sup> .  
A investigação etiológica direta da infecção urogenital pode ser feita pela pesquisa de DNA da _Chlamydia trachomatis_ pela técnica de PCR em amostra de secreção uretral ou da cérvice uterina (raspado endocervical), em pacientes sintomáticos, para tratamento específico e diagnóstico diferencial em relação a outras uretrites. Outro meio é a pesquisa por PCR em amostra isolada do primeiro jato de urina. No entanto, só está indicada para pacientes sintomáticos para tratamento específico e diagnóstico diferencial com outras uretrites<sup>27-31</sup> .  
Embora a identificação do agente relacionado à infecção gastrointestinal seja um dos fatores de risco para a cronificação da ARe e tenha valor epidemiológico em saúde pública, não tem sido feita na prática assistecial, especialmente pela baixa positividade da coprocultura, ausência de correlação estreita entre as alterações da microbiota intestinal e aquelas encontradas em controles saudáveis, mas também pela perda da oportunidade (janela) de coleta do material entre o gatilho intestinal e a queixa musculoesquelética<sup>11,12,18,20,21,32</sup> .  
O quadro intestinal, em geral, tem evolução autolimitada e tende a se resolver em 7 a 10 dias. Sendo assim, na grande maioria das vezes, o paciente não faz a associação da queixa intestinal com a articular, e a oportunidade de comprovar o agente etiológico é perdida. Queixas intestinais baixas prolongadas podem suscitar o diagnóstico diferencial com colite crônica e artrite enteropática<sup>32</sup> .  
A presença do HLA-B27 é um marcador de risco para a artrite e também para o acometimento do esqueleto axial (sacroiliíte), além de estar relacionado a maior risco de cronificação da doença<sup>33, 34</sup> . Assim como  
nas demais doenças do grupo das EpA, a presença do HLA-B27 é um importante fator de risco genético<sup>34</sup> . A pesquisa desse marcador pode ser realizada nos pacientes com a suspeita clínica de ARe, uma vez que tem valor diagnóstico e prognóstico (maior chance de cronificação, acometimento axial e maior possibilidade de apresentar manifestações extra-articulares). Pode ser feita pela técnica de reação em cadeia de polimerasetempo real (PCR-RT) e solicitada somente uma vez<sup>18,19</sup> .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **3.2.  Exames de Imagem** -->
Os exames de imagem, incluindo a radiografia simples, ultrassonografia e ressonância magnética, são complementares para a confirmação diagnóstica, diagnóstico diferencial e avaliação da progressão do dano estrutural ao longo do tempo<sup>18,19,35</sup> .  
Para os quadros periféricos, as radiografias simples das regiões acometidas são preconizadas. Inicialmente, os achados podem ser inespecíficos ou normais. Mais recentemente, a avaliação do sítio insercional das enteses nas EpA-p pode ser mais bem avaliada pela ultrassonografia com _Power doppler_ , sobretudo em caso de dúvida<sup>36</sup> .  
Para os quadros axiais, recomenda-se a radiografia simples da bacia em incidência anteroposterior (AP) ou da articulações sacroilíacas em incidência de Ferguson, a fim de se avaliar o grau de sacroiliíte, conforme os critérios modificados de Nova Iorque. Em casos normais ou de dúvida, a ressonância magnética das sacroilíacas, sem contraste, com as sequências ponderadas em T1 e STIR ( _Short Tau Inversion R_ ecovery) ou T2 com supressão de gordura (T2 FATSAT), deve ser solicitada. Os achados de imagem na RM de articulação sacroilíaca incluem alterações agudas (edema da medula óssea, derrame articular, capsulite e entesite) e estruturais [esclerose óssea subcondral (ES), metaplasia gordurosa (MetG), erosões (ER) e sindesmófitos/anquilose]<sup>17,35</sup> .  
A cintilografia óssea não é recomendada nem para avaliação da atividade axial nem periférica, uma vez que não há validação científica para este exame nos de casos de EpA<sup>17</sup> .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **4.  CASOS ESPECIAIS** -->
Em pacientes com mono- ou oligoartrite nas fases iniciais e ausência de história clara de infecção precedente, a análise do líquido sinovial é recomendada para diagnóstico diferencial com artrite séptica, artrite por cristais e artrite traumática. Na ARe, o líquido sinovial apresenta-se com predomínio de neutrófilos, na fase aguda, e de linfócitos, na fase crônica<sup>37</sup> .  
Entre as EpA, a ARe é a que mais pode se assemelhar aos quadros sépticos, uma vez que os pacientes podem apresentar febre nas fases de atividade da doença, bem como aspecto séptico do líquido sinovial e celularidade aumentada. Nesses casos, o julgamento clínico é fundamental, bem como cultura com antibiograma do líquido sinovial<sup>38,39</sup> .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **5.  CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem quadro clínico articular periférico ou axial com história comprovada ou sugestiva de infecção genitourinária ou gastrointestinal dentro do intervalo de até 4 semanas antes do aparecimento dos sinais articulares.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes que não tenham o diagnóstico de Artrite Reativa (ARe).  
Intolerância, hipersensibilidade ou contraindicação serão critérios de exclusão ao uso do respectivo medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.1. Tratamento não medicamentoso** -->
Embora não haja estudos com doentes de ARe, exercícios físicos e técnicas de fisioterapia são recomendados no tratamento sintomático destes pacientes, especialmente naqueles em que ocorre a cronificação dos sintomas musculoesqueléticos<sup>40-42</sup> .  
Nos casos de ARe induzida por infecção genitourinária, é importante que o paciente seja orientado sobre a prevenção de Infecções Sexualmente Transmissíveis (IST), para evitar a recorrência do quadro, conforme o PCDT específico do Ministério da Saúde<sup>43</sup> . Outras recomendações incluem para de fumar, perder peso, educar o paciente e estimular a sua participação em grupos de ajuda<sup>44-46</sup> .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.2. Tratamento medicamentoso** -->
**7.2.1. Tratamento de infecções precedentes**  
Para as infecções genitourinárias agudas e sintomáticas por _Chlamydia trachomatis_ , o tratamento antimicrobiano adequado, com macrolídeo ou uma tetraciclina, deve ser prontamente indicado para o paciente e para o seu parceiro sexual<sup>43</sup> . Teoricamente, isso diminuiria o desenvolvimento da ARe; entretanto, estudos controlados por placebo nunca foram realizados e não existem comprovações científicas consistentes que comprovem que os antibióticos possam mitigar a cronificação<sup>47,48,54</sup> .  
O uso de antibióticos por curto ou longo período no tratamento da ARe foi foco de estudos; entretanto, depois que a artrite se manifesta, os antibióticos não parecem modificar o curso da doença<sup>47-50</sup> . Os resultados de ensaios clínicos que avaliaram a antibioticoterapia em casos de ARe associada à infecção genitourinária crônica (prostatite, cervicite ou salpingo-ooforite) por _Chlamydia trachomatis_ são conflitantes<sup>51-53</sup> . Assim, o uso rotineiro de antibióticos não é preconizado, mas pode ser indicado se houver morbidade relacionada à infecção genitourinária crônica e a partir de avaliação por especialista da área (ginecologista ou urologista).  
O uso de antibióticos para as infecções gastrointestinais ativas segue os padrões da prática das doenças infecciosas. Em geral, não são indicados para as infecções entéricas não complicadas<sup>48</sup> .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.2.2. Tratamento das manifestações musculoesqueléticas** -->
Os AINE são a primeira linha de tratamento para a fase aguda de dor e inflamação da artrite. São usados nas suas doses máximas e de forma contínua por pelo menos duas semanas, sendo geralmente bastante eficazes no controle dos sintomas<sup>48,49,55</sup> , apesar de não alterarem o curso da doença<sup>54,55</sup> ou modificarem de forma significativa as medidas de mobilidade da coluna e os reagentes de fase aguda (Velocidade de Hemossedimentação - VHS e Proteína C Reativa - PCR)<sup>55</sup> .  
O uso de glicocorticoide intra- ou periarticular pode ajudar de forma segura e eficaz o tratamento de uma única articulação periférica acometida e com sintomas incapacitantes, nos casos em que o AINE não controlou os sintomas satisfatoriamente, bem como no controle dos sintomas nas entesites. Raramente o glicocorticoide sistêmico é indicado, sendo empregado apenas nos raros casos de doença grave, prolongada ou sistêmica em que ocorre resistência aos AINE<sup>48,49,54,56</sup> , para controle sintomático e independente da eventual necessidade de utilização dos Medicamentos Modificadores do Curso da Doença (MMCD).  
Os MMCD estão indicados quando não há controle satisfatório dos sintomas com AINE e glicocorticoide intra ou periarticular, ou se a doença se torna crônica, recorrente ou erosiva e agressiva<sup>48,54,56</sup> . Entre os MMCD, a sulfassalazina é a mais estudada, sendo bem tolerada, segura e eficaz para a doença articular periférica em doses de até 3.000 mg/dia<sup>47,48,57</sup> . Além da ação antibacteriana, a sulfassalazina diminui os níveis de imunoglobulina (Ig) sérica, principalmente a IgA, e reduz a VHS<sup>55-59</sup> . Pela possibilidade de hipersensibilidade cruzada a salicilatos e sulfonamidas, o uso de sulfassalazina está contraindicado em pacientes com hipersensibilidade a esses medicamentos.  
Os pacientes com evidências de cronificação da doença e comprovada evolução para Espondilite Anquilosante (quadro axial)<sup>46</sup> ou Artrite Psoríaca (quadro periférico) devem ser tratados conforme os critérios de elegibilidade especificados nos respectivos PCDT.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.3. Fármacos** -->
- Ibuprofeno: comprimidos de 200, 300 e 600 mg; suspensão oral de 50 mg/mL.  
- Naproxeno: comprimidos de 250 e 500 mg.  
- Prednisona: comprimidos de 5mg e 20 mg.  
- Acetato de betametasona + fosfatodissódico de betametasona: suspensão injetável 3 mg/mL + 3  
mg/mL.  
- Acetato de metilprednisolona: solução injetável 40mg/mL.  
- Sulfassalazina: comprimidos de 500 mg.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.4. Esquemas de administração** -->
- Ibuprofeno: 600 a 2.700 mg/dia, divididas em três administrações (8h/8h).  
- Naproxeno: 500 a 1000 mg/dia, divididas em duas administrações (12/12h) (usar a menor dose pelo  
menor tempo possível).  
- Prednisona: 5 a 20mg, 1 a 2x/dia, pelo menor tempo necessário para controle das manifestações articulares e extra-articulares agudas.  
- Acetato de betametasona + fosfatodissódico de betametasona: 1 ampola intramuscular a cada 4  
semanas, pelo menor tempo necessário para controle das manifestações articulares e extra-articulares agudas; ou 1 ampola periarticular em dose única.  
- Acetato de metilprednisolona: 1 a 2 mL intra-articular em dose única.  
- Sulfassalazina: 500 a 3000mg/dia, 1 a 3x/dia, por 3 a 6 meses ou até a remissão da doença articular inflamatória.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **7.5. Benefícios esperados** -->
- Melhora da dor;  
- melhora dos sinais e sintomas de inflamação articular;  
- melhora da qualidade de vida; e  
- redução da morbidade e incapacidade nos pacientes.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **8. MONITORAMENTO** -->
O tratamento deve ser mantido ou interrompido (em casos de remissão, caracterizada pela ausência de sinais e sintomas) com base na avaliação do médico sobre os sintomas e sinais do paciente.  
No seguimento dos pacientes com Are, é importante avaliar a atividade da doença por meio da avaliação clínica, que inclui observação dos sinais de dor e edema articular, número de articulações acometidas, presença de entesite e dactilite, registro da presença de dor axial inflamatória e noturna, além de rigidez matinal. Adicionalmente, é importante a avaliação periódica da mobilidade da coluna e o registro da presença de limitação funcional. Deve-se também registrar a presença de manifestações extra-articulares como psoríase, uveíte, diarreia e uretrite<sup>45,46</sup> .  
O ideal é que, nos casos de ARe em fase inicial e aguda, as consultas tenham um intervalo inferior a 30 dias, podendo ser espaçadas à medida que ocorre o controle do quadro clínico. Quando há cronificação e o paciente evolui com doença inflamatória articular periférica ou axial persistente, as consultas passam a ter intervalo de 3 a 6 meses. Inexistem instrumentos de avaliação de atividade de doença e comprometimento funcional que sejam específicos para a ARe. Por isso, quando há cronificação do quadro, podem ser utilizados os instrumentos da EA ou AP, conforme estabelecidos nos PCDT específicos. De modo geral, a avaliação da velocidade de hemossedimentação (VHS) e a dosagem da proteína C reativa (PCR) são úteis na avaliação da atividade inflamatória inicial e auxiliam o monitoramento da atividade de doença, devendo ser solicitadas conforme a necessidade, a depender da evolução clínica<sup>45,46</sup> .  
Quando indicada a infiltração intra-articular ou em bainha tendinosa com glicocorticoide, os pacientes devem ser monitorados devido ao risco de complicações, como artrite séptica e ruptura tendínea. É  
recomendável que a infiltração em bainha tendinosa do tendão de Aquiles seja guiada por ultrassom e realizada por médico treinado nesse procedimento, a fim de minimizar o risco de rotura local<sup>45,46</sup> . O monitoramento de eventos adversos dos medicamentos deve ser realizado conforme especificado no **Quadro 2** .  
**Quadro 2 -** Monitoramento de acordo com os medicamentos  
|**Medicamento**|**Avaliação**|**Conduta frente a alterações**|
|---|---|---|
|Prednisona, acetato de<br>betametasona<br>+<br>fosfatodissódico<br>de<br>betametasona,<br>acetato<br>de metilprednisolona.|Glicemia: após 4 semanas e<br>se<br>necessário<br>uso<br>mais<br>prolongado, a cada 3 meses.<br>Monitorar a pressão arterial<br>epeso corporal.|Avaliar a redução da dose ou interromper o tratamento<br>frente a taxas alteradas.|
|Ibuprofeno e naproxeno.|Hemograma,<br>creatinina,<br>AST/ TGO e ALT/TGP, análise<br>de urina: a cada 3 meses.<br>Monitorar a pressão arterial<br>e sintomas dispépticos.|- Anemia, leucopenia ou trombocitopenia novas ou<br>acentuadas: reduzir a dose em 25% a 50%; interromper<br>o uso do medicamento se persistirem as alterações.<br>- Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>Limite Superior da Normalidade (LSN): reduzir a dose<br>em 25% a 50%.<br>- Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>- Elevação de TGO/TGP acima de 5 vezes LSN:<br>interromper o uso do medicamento.<br>- Creatinina: interromper o uso em caso de elevação de<br>creatinina > 0,3mg/dL.<br>- Alteração em exame de urina: suspender o<br>medicamento em caso de hematúria ou aparecimento<br>de cilindros associado à elevação da creatinina.|
|Sulfassalazina|Hemograma, creatinina,<br>AST/TGO e ALT/ TGP,<br>análise de urina: a cada 3<br>meses.|- Anemia, leucopenia ou trombocitopenia novas ou<br>acentuadas: reduzir a dose em 25% a 50%; interromper<br>o uso do medicamento se persistirem as alterações.<br>- Elevação de AST/TGO e ALT/TGP entre 1 e 3 vezes o<br>LSN: reduzir a dose em 25% a 50%.<br>- Elevação de AST/TGO e ALT/TGP entre 3 e 5 vezes o<br>LSN: suspender o uso do medicamento até AST/TGO e<br>ALT/TGP entre 1 e 3 vezes o LSN e reiniciar com 50% da<br>dose.<br>- Elevação de TGO/TGP acima de 5 vezes o LSN:<br>interromper o uso do medicamento.<br>- Creatinina: interromper o uso em caso de elevação de<br>creatinina > 0,3mg/dL.<br>- Alteração em exame de urina: suspender o<br>medicamento em caso de hematúria ou aparecimento<br>de cilindros associado à elevação da creatinina.|  
ALT/TGP: alanino-aminotransferase/transaminase glutâmico-pirúvica; AST/TGO: aspartatoaminotransferase/transaminase glutâmico-oxalacética; LSN: limite superior da normalidade.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a  
monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas  
e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Todos os pacientes com dificuldades diagnósticas, refratários ao tratamento ou com toxicidade  
medicamentosa (inclusive intolerância) devem ser atendidos em serviços especializados, preferencialmente por reumatologista.  
Pacientes que apresentarem evolução para Espondilite Anquilosante ou Artrite Psoríaca devem ser  
tratados conforme os respectivos PCDT do Ministério da Saúde, mediante a comprovação dos critérios de elegibilidade.  
Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da  
Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **11. REFERÊNCIAS** -->
1. McAllister K, Goodson N, Warburton L, Rogers G. Spondyloarthritis: diagnosis and management: summary of NICE guidance. BMJ. 2017;356:j839.  
2. Schmitt SK. Reactive Arthritis. Infect Dis Clin North Am. 2017;31(2):265-77.  
3. Misra R, Gupta L. Epidemiology: Time to revisit the concept of reactive arthritis. Nat Rev Rheumatol. 2017;13(6):327-8.  
4. Carter JD. Reactive arthritis: defined etiologies, emerging pathophysiology, and unresolved treatment. Infect Dis Clin North Am. 2006;20(4):827-47.  
5. Hannu T, Inman R, Granfors K, Leirisalo-Repo M. Reactive arthritis or post-infectious arthritis? Best Pract Res Clin Rheumatol. 2006;20(3):419-33.  
6. Zaid A, Gerardin P, Taylor A, Mostafavi H, Malvy D, Mahalingam S. Chikungunya Arthritis: Implications of Acute and Chronic Inflammation Mechanisms on Disease Management. Arthritis Rheumatol. 2018;70(4):48495.  
7. Bernini L, Manzini CU, Giuggioli D, Sebastiani M, Ferri C. Reactive arthritis induced by intravesical BCG therapy for bladder cancer: our clinical experience and systematic review of the literature. Autoimmun Rev. 2013;12(12):1150-9.  
8. Scheinberg MA. Passado nazista e mudança do nome de uma doença: o caso da doença de Wegener. Revista Brasileira de Reumatologia. 2012;52:300-1.  
9. Leirisalo-Repo M, Suoranta H. Ten-year follow-up study of patients with Yersinia arthritis. Arthritis Rheum. 1988;31(4):533-7.  
10. Gallinaro AL, Ventura C, Barros PDS, Gonçalves CR. Espondiloartrites: análise de uma série Brasileira comparada a uma grande casuística Ibero-Americana (estudo RESPONDIA). Revista Brasileira de Reumatologia. 2010;50:581-9.  
11. Braun J, Kingsley G, van der Heijde D, Sieper J. On the difficulties of establishing a consensus on the definition of and diagnostic investigations for reactive arthritis. Results and discussion of a questionnaire prepared for the 4th International Workshop on Reactive Arthritis, Berlin, Germany, July 3-6, 1999. J Rheumatol. 2000;27(9):2185-92.  
12. Kanakoudi-Tsakalidou F, Pardalos G, Pratsidou-Gertsi P, Kansouzidou-Kanakoudi A, TsangaropoulouStinga H. Persistent or severe course of reactive arthritis following Salmonella enteritidis infection. A prospective study of 9 cases. Scand J Rheumatol. 1998;27(6):431-4.  
13. Leirisalo M, Skylv G, Kousa M, Voipio-Pulkki LM, Suoranta H, Nissila M, et al. Followup study on patients with Reiter's disease and reactive arthritis, with special reference to HLA-B27. Arthritis Rheum. 1982;25(3):24959.  
14. Selmi C, Gershwin ME. Diagnosis and classification of reactive arthritis. Autoimmun Rev. 2014;13(45):546-9.  
15. Rudwaleit M, Landewe R, van der Heijde D, Listing J, Brandt J, Braun J, et al. The development of Assessment of SpondyloArthritis international Society classification criteria for axial spondyloarthritis (part I): classification of paper patients by expert opinion including uncertainty appraisal. Ann Rheum Dis. 2009;68(6):770-6.  
16. Rudwaleit M, van der Heijde D, Landewe R, Listing J, Akkoc N, Brandt J, et al. The development of Assessment of SpondyloArthritis international Society classification criteria for axial spondyloarthritis (part II): validation and final selection. Ann Rheum Dis. 2009;68(6):777-83.  
17. Sieper J, Rudwaleit M, Baraliakos X, Brandt J, Braun J, Burgos-Vargas R, et al. The Assessment of SpondyloArthritis international Society (ASAS) handbook: a guide to assess spondyloarthritis. Ann Rheum Dis. 2009;68 Suppl 2:ii1-44.  
18. Rudwaleit M, van der Heijde D, Landewe R, Akkoc N, Brandt J, Chou CT, et al. The Assessment of SpondyloArthritis International Society classification criteria for peripheral spondyloarthritis and for spondyloarthritis in general. Ann Rheum Dis. 2011;70(1):25-31.  
19. Sepriano A, Rubio R, Ramiro S, Landewe R, van der Heijde D. Performance of the ASAS classification criteria for axial and peripheral spondyloarthritis: a systematic literature review and meta-analysis. Ann Rheum Dis. 2017;76(5):886-90.  
20. Dougados M, van der Linden S, Juhlin R, Huitfeldt B, Amor B, Calin A, et al. The European Spondylarthropathy Study Group preliminary criteria for the classification of spondylarthropathy. Arthritis Rheum. 1991;34(10):1218-27. 21. Amor B, Dougados M, Listrat V, Menkes CJ, Dubost JJ, Roux H, et al. [Evaluation of the Amor criteria for spondylarthropathies and European Spondylarthropathy Study Group (ESSG). A cross-sectional analysis of 2,228 patients]. Ann Med Interne (Paris). 1991;142(2):85-9. 22. Hoenderboom BM, van Willige ME, Land JA, Pleijster J, Götz HM, van Bergen JEAM, et al. Antibody Testing in Estimating Past Exposure to Chlamydia trachomatis in the Netherlands Chlamydia Cohort Study. Microorganisms. 2019;7(10):442.  
23. Chemaitelly H, Weiss HA, Smolak A, Majed E, Abu-Raddad LJ. Epidemiology of Treponema pallidum, Chlamydia trachomatis, Neisseria gonorrhoeae, Trichomonas vaginalis, and herpes simplex virus type 2 among female sex workers in the Middle East and North Africa: systematic review and meta-analytics. Journal of global health. 2019;9(2):020408-.  
24. Land JA, Van Bergen JE, Morre SA, Postma MJ. Epidemiology of Chlamydia trachomatis infection in women and the cost-effectiveness of screening. Hum Reprod Update. 2010;16(2):189-204. 25. Rietmeijer CA, Hopkins E, Geisler WM, Orr DP, Kent CK. Chlamydia trachomatis positivity rates among men tested in selected venues in the United States: a review of the recent literature. Sex Transm Dis. 2008;35(11 Suppl):S8-s18. 26. Kucinskiene V, Sutaite I, Valiukeviciene S, Milasauskiene Z, Domeika M. Prevalence and risk factors of genital Chlamydia trachomatis infection. Medicina (Kaunas). 2006;42(11):885-94.  
27. Hallsworth PG, Hefford C, Waddell RG, Gordon DL. Comparison of antigen detection, polymerase chain reaction and culture for detection of Chlamydia trachomatis in genital infection. Pathology. 1995;27(2):168-71. 28. SG. H. Chlamydia trachomatis: update on laboratory diagnosis. Check sample. Am Soc Clin Pathol1997. p. 49-61.  
29. Hillis SD, Wasserheit JN. Screening for chlamydia--a key to the prevention of pelvic inflammatory disease. N Engl J Med. 1996;334(21):1399-401.  
30. Hitchcock PJ. Future directions of chlamydial research. In: Chlamydia intracellular biology pathogenesis, and immunity. . 1999. p. 297-311.  
31. Seadi CF, Oravec R, Poser Bv, Cantarelli VV, Rossetti ML. Diagnóstico laboratorial da infecção pela Chlamydia trachomatis: vantagens e desvantagens das técnicas. Jornal Brasileiro de Patologia e Medicina Laboratorial. 2002;38:125-33.  
32. Manasson J, Shen N, Garcia Ferrer HR, Ubeda C, Iraheta I, Heguy A, et al. Gut Microbiota Perturbations in Reactive Arthritis and Postinfectious Spondyloarthritis. Arthritis Rheumatol. 2018;70(2):242-54.  
33. Nanagara R, Li F, Beutler A, Hudson A, Schumacher Jr HR. Alteration of chlamydia trachomatis biologic behavior in synovial membranes suppression of surface antigen production in reactive arthritis and reiter's syndrome. Arthritis & Rheumatism. 1995;38(10):1410-7.  
34. Taurog JD. The role of HLA-B27 in spondyloarthritis. J Rheumatol. 2010;37(12):2606-16.  
35. Maksymowych WP, Lambert RG, Ostergaard M, Pedersen SJ, Machado PM, Weber U, et al. MRI lesions in the sacroiliac joints of patients with spondyloarthritis: an update of definitions and validation by the ASAS MRI working group. Ann Rheum Dis. 2019;78(11):1550-8.  
36. Zabotti A, Mandl P, Zampogna G, Dejaco C, Iagnocco A. One year in review 2018: ultrasonography in rheumatoid arthritis and psoriatic arthritis. Clin Exp Rheumatol. 2018;36(4):519-25.  
37. Courtney P, Doherty M. Joint aspiration and injection and synovial fluid analysis. Best Pract Res Clin Rheumatol. 2013;27(2):137-69.  
38. Fowler ML, Zhu C, Byrne K, Lieber SB, Moore A, Shmerling RH, et al. Pathogen or contaminant? Distinguishing true infection from synovial fluid culture contamination in patients with suspected septic arthritis. Infection. 2017;45(6):825-30.  
39. Horowitz DL, Katzap E, Horowitz S, Barilla-LaBarca ML. Approach to septic arthritis. Am Fam Physician. 2011;84(6):653-60.  
40. Regel A, Sepriano A, Baraliakos X, van der Heijde D, Braun J, Landewé R, et al. Efficacy and safety of nonpharmacological and non-biological pharmacological treatment: a systematic literature review informing the 2016 update of the ASAS/EULAR recommendations for the management of axial spondyloarthritis. RMD Open. 2017;3(1):e000397.  
41. Millner JR, Barron JS, Beinke KM, Butterworth RH, Chasle BE, Dutton LJ, et al. Exercise for ankylosing spondylitis: An evidence-based consensus statement. Semin Arthritis Rheum. 2016;45(4):411-27.  
42. Rausch Osthoff AK, Niedermann K, Braun J, Adams J, Brodin N, Dagfinrud H, et al. 2018 EULAR recommendations for physical activity in people with inflammatory arthritis and osteoarthritis. Ann Rheum Dis. 2018;77(9):1251-60.  
43. Brasil. Ministério da Saúde.   Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST). Portaria Conjunta SAS/SCTIE nº 42 - 05/10/2018. 2018.  
44. Villaverde-García V, Cobo-Ibáñez T, Candelas-Rodríguez G, Seoane-Mato D, Campo-Fontecha PDD, Guerra M, et al. The effect of smoking on clinical and structural damage in patients with axial spondyloarthritis: A systematic literature review. Semin Arthritis Rheum. 2017;46(5):569-83.  
45. Ward MM, Deodhar A, Gensler LS, Dubreuil M, Yu D, Khan MA, et al. 2019 Update of the American College of Rheumatology/Spondylitis Association of America/Spondyloarthritis Research and Treatment Network Recommendations for the Treatment of Ankylosing Spondylitis and Nonradiographic Axial Spondyloarthritis. Arthritis Rheumatol. 2019;71(10):1599-613.  
46. Resende GG, Meirelles ES, Marques CDL, Chiereghin A, Lyrio AM, Ximenes AC, et al. The Brazilian Society of Rheumatology guidelines for axial spondyloarthritis - 2019. Adv Rheumatol. 2020;60(1):19.  
47. Anandarajah A, Ritchlin CT. Treatment update on spondyloarthropathy. Curr Opin Rheumatol. 2005;17(3):247-56.  
48. Hamdulay SS, Glynne SJ, Keat A. When is arthritis reactive? Postgrad Med J. 2006;82(969):446-53.  
49. Leirisalo-Repo M. Reactive arthritis. Scand J Rheumatol. 2005;34(4):251-9.  
50. Putschky N, Pott HG, Kuipers JG, Zeidler H, Hammer M, Wollenhaupt J. Comparing 10-day and 4-month doxycycline courses for treatment of <em>Chlamydia trachomatis</em>-reactive arthritis: a prospective, double-blind trial. Annals of the Rheumatic Diseases. 2006;65(11):1521.  
51. Barber CE, Kim J, Inman RD, Esdaile JM, James MT. Antibiotics for treatment of reactive arthritis: a systematic review and metaanalysis. J Rheumatol. 2013;40(6):916-28.  
52. Kuuliala A, Julkunen H, Paimela L, Peltomaa R, Kautiainen H, Repo H, et al. Double-blind, randomized, placebo-controlled study of three-month treatment with the combination of ofloxacin and roxithromycin in recent-onset reactive arthritis. Rheumatol Int. 2013;33(11):2723-9.  
53. Carter JD, Espinoza LR, Inman RD, Sneed KB, Ricca LR, Vasey FB, et al. Combination antibiotics as a treatment for chronic Chlamydia-induced reactive arthritis: a double-blind, placebo-controlled, prospective trial. Arthritis Rheum. 2010;62(5):1298-307.  
54. David T Yu, MDAstrid van Tubergen M, PhD. Reactive arthritis. In: Joachim Sieper M, editor.: <u>http://www.uptodate.com/contents/reactive-arthritis; 2019.</u>  
55. Maksymowych WP, Breban M, Braun J. Ankylosing spondylitis and current disease-controlling agents: do they work? Best Pract Res Clin Rheumatol. 2002;16(4):619-30.  
56. Mease PJ. Disease-modifying antirheumatic drug therapy for spondyloarthropathies: advances in treatment. Curr Opin Rheumatol. 2003;15(3):205-12.  
57. Clegg DO, Reda DJ, Abdellatif M. Comparison of sulfasalazine and placebo for the treatment of axial and peripheral articular manifestations of the seronegative spondylarthropathies: a Department of Veterans Affairs cooperative study. Arthritis Rheum. 1999;42(11):2325-9.  
58. Clegg DO, Reda DJ, Weisman MH, Cush JJ, Vasey FB, Schumacher HR, Jr., et al. Comparison of sulfasalazine and placebo in the treatment of reactive arthritis (Reiter's syndrome). A Department of Veterans Affairs Cooperative Study. Arthritis Rheum. 1996;39(12):2021-7.  
59. Olivieri I, Palazzi C, Peruz G, Padula A. Management issues with elderly-onset rheumatoid arthritis: an update. Drugs Aging. 2005;22(10):809-22.  
60. Kroon FP, van der Burg LR, Ramiro S, Landewé RB, Buchbinder R, Falzon L, et al. Non-steroidal antiinflammatory drugs (NSAIDs) for axial spondyloarthritis (ankylosing spondylitis and non-radiographic axial spondyloarthritis). Cochrane Database Syst Rev. 2015(7):Cd010952.  
61. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. Bmj. 2017;358:j4008.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ACETATO DE BETAMETASONA + FOSFATO DISSÓDICO DE BETAMETASONA, ACETATO DE METILPREDNISOLONA, IBUPROFENO, NAPROXENO, PREDNISONA E SULFASSALAZINA.  
Eu,_________________________________________________________ (nome do [a] paciente), declaro ter sido informado (a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de **acetato de betametasona + fosfato dissódico de betametasona,  acetato de metilprednisolona, ibuprofeno, naproxeno, prednisona e sulfassalazina,** indicados para o tratamento da **Artrite Reativa** .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo médico___________________________________________________ (nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora da dor;  
- melhora dos sinais e sintomas de inflamação articular;  
- melhora da qualidade de vida; e  
- redução da morbidade e incapacidade nos pacientes.  
Fui também informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos: - Sulfassalazina, prednisona, naproxeno e ibuprofeno não devem ser usados durante a gravidez e lactação, exceto sob orientação do seu médico.  
- O uso de corticoides intra-articulares (metilprednisolona e betametasona) durante a gestação, quando recomendado pelo seu médico, deve ocorrer com as menores doses possíveis, especialmente no primeiro trimestre.  
- Efeitos adversos do **ibuprofeno:** tontura, urticária na pele, reações de alergia, dor de estômago, náusea, má digestão, prisão de ventre, perda de apetite, vômitos, diarreia, gases, dor de cabeça, irritabilidade, zumbido, inchaço e retenção de líquidos.  
- Efeitos adversos do **naproxeno** : dor abdominal, sede, constipação, diarreia, dispneia, náusea, estomatite, azia, sonolência, vertigens, enxaqueca, tontura, erupções cutâneas, prurido, sudorese, ocorrência de distúrbios auditivos e visuais, palpitações, edemas, dispepsia e púrpura  
- Efeitos adversos da **sulfassalazina** : dor de cabeça, sensibilidade aumentada aos raios solares, alergias de pele graves, dores abdominais, náusea, vômitos, perda de apetite, diarreia, hepatite, dificuldade para engolir, diminuição do número dos glóbulos brancos no sangue, parada na produção de sangue pela medula óssea (anemia aplásica), anemia por destruição aumentada dos glóbulos vermelhos do sangue (anemia hemolítica), diminuição do número de plaquetas no sangue, falta de ar associada à tosse e febre (pneumonite intersticial), dores articulares, cansaço e reações alérgicas.  
- Efeitos adversos da **prednisona** : retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose, problemas de estômago [úlceras estomacais]), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação e manifestação de diabete melito.  
- Efeitos adversos da **metiprednisolona:** retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, manifestação ou complicações do diabete melito, e urticária crônica.  
- Efeitos adversos da **betametasona** : retenção de líquidos, aumento da pressão arterial, problemas no coração, fraqueza nos músculos, problema nos ossos (osteoporose), problemas de estômago (úlceras), inflamação do pâncreas (pancreatite), dificuldade de cicatrização de feridas, pele fina e frágil, irregularidades na menstruação, manifestação de diabetes melito, e reações no local da injeção.  
- Medicamentos contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.   (   ) Sim   (   ) Não  
O meu tratamento constará do(s) seguinte(s) medicamento(s):  
- (   ) acetato de betametasona + fosfato dissódico de betametasona  
- (   ) acetato de metilprednisolona  
- (   ) ibuprofeno  
- (   ) naproxeno  
- (   ) prednisona  
- (   ) sulfassalazina  
|Local:|Data:||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|Assinatura do paciente ou|do responsável legal||
|Médico Responsável:|CRM:|UF:|
|Data:|||
|Assinatura e carimb|o do médico||  
**Nota 1** : Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**Nota 2** : A administração de metilprednisolona ou betametasona é compatível com o procedimento 03.03.09.003-0: infiltração de substâncias em cavidade sinovial (articulação, bainha tendinosa), da _Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais do SUS_ .

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **1. Escopo e finalidade do Protocolo** -->
A revisão do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Artrite Reativa iniciou-se com a reunião presencial para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização do referido PCDT, que contou com a presença de sete membros do Grupo Elaborador, sendo três especialistas e quatro metodologistas, além de cinco representantes do Comitê Gestor (Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde - DGITIS/SCTIE/MS).  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria nº 1.150/SAS/MS, de 11 de novembro de 2015), na estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10 de novembro de 2009, e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde. Cada seção foi detalhada e discutida entre os membros do Grupo Elaborador, com o objetivo de elaborar as condutas clínicas e identificar as tecnologias que seriam consideradas nas recomendações. Com a verificação das tecnologias já disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO, para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou de acompanhamento que utilizassem tecnologias já disponíveis no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou possibilidade de desinvestimento.  
Além dos representantes do DGITIS/SCTIE/MS, participaram do desenvolvimento deste PCDT metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
O documento elaborado foi apresentado à 82ª Reunião da Subcomissão de PCDT da Conitec, realizada no dia 08/09/2020 com a participação de áreas técnicas do Ministério da Saúde, que decidiram, por unanimidade, apresentar o documento para a avaliação e deliberação dessa Cmissão, o que ocorreu à sua 92ª Reunião Ordinária, em 05/11/2020.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Consulta Pública</u>** -->
A Consulta Pública nº 61/2020, do Protocolo Clínico e Diretrizes Terapêuticas da Artrite Reativa, foi realizada entre os dias 20/11/2020 a 09/12/2020. Foram recebidas seis (06) contribuições no total e salienta-se que todas foram analisadas. O conteúdo integral das contribuições encontra-se disponível na página da Conitec em: http://conitec.gov.br/images/Consultas/Contribuicoes/2020/CP_CONITEC_61_2020_PCDT_Artrite.pdf

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Recomendação Final da Conitec</u>** -->
A recomendação final da Conitec ocorreu em sua 94ª Reunião da Conitec, em 03/02/2021, a partir da qual foi publicado o Relatório de Recomendação N<sup>o</sup> 587 - Fevereiro de 2021.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Busca da evidência e recomendações</u>** -->
Na reunião de escopo havia sido solicitada a ampliação de uso do medicamento naproxeno, pois ele se encontra incorporado para outras doenças reumáticas, como osteoartrite de joelho e quadril, espondilite anquilosante, artrite psoríaca e artrite reumatoide.  
Logo, foi desenvolvida a pergunta estruturada para elaboração do relatório (PICO), para consubstanciar uma Nota Técnica sobre a ampliação do uso do naproxeno, a ser apresentada para avaliação e deliberação da Conitec:

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **Pergunta de Pesquisa: O naproxeno é uma opção segura e eficaz para o tratamento da ARe?** -->
|**População**|Pacientes com artrite reativa|
|---|---|
|**Intervenção (tecnologia)**|Naproxeno|
|**Comparação**|Placebo ou ibuprofeno|
|**Desfechos**|Eficácia (melhora da dor), escore_Bath Ankylosing Spondylitis Activity_<br>_Index_(BASDAI), escore_Bath Ankylosing Spondylitis Functional Index_|
|**(****_Outcomes_) **|(BASFI), avaliação global, escore_Ankylosing Spondylitis Disease Activity_<br>_Score_(ASDAS) e segurança|

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Estratégias de buscas</u>** -->
Foram realizadas buscas nas bases de dados Medline (via PubMed) e Embase, com acesso em 27 de setembro de 2019. As estratégias de busca estão descritas no **Quadro A** .  
**Quadro A** - Estratégia de buscas por evidências nas bases de dados  
|**Base**|**Estratégia**|**Localizados**|**Duplicados**|**Incluídos**|
|---|---|---|---|---|
|Medline<br>(via<br>PubMed)|((("Spondylarthritis"[Mesh] OR<br>Spondylarthritis) OR "Arthritis,<br>Reactive"[Mesh]) OR "Arthritis, Reactive")<br>AND (("Naproxen"[Mesh]) OR Naproxen)|81|||
|Embase|('reactive arthritis'/exp OR 'arthritis,<br>reactive' OR 'idiopathic reactive arthritis'<br>OR 'reactive arthritis') AND<br>'naproxen'/exp AND ('placebo'/exp OR<br>'ibuprofen'/exp)|32|1|1|

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Seleção das evidências</u>** -->
Os critérios de inclusão dos estudos foram Ensaios Clínicos Randomizados (ECR) e revisões sistemáticas com meta-análise, que comparassem o naproxeno com o ibuprofeno ou placebo no tratamento de pacientes com diagnóstico de ARe, nos quais os desfechos de interesses definidos _a priori_ tivessem sido avaliados. Na condição de existência de revisão sistemática com qualidade adequada e que contemplasse os ECR elegíveis, essa seria priorizada. Foram considerados desfechos: melhora da dor, escores BASDAI, BASFI e ASDAS, avaliação global do paciente e segurança do medicamento, conforme determinado em reunião de especialistas para a Nota Técnica a ser apresentada à Conitec. Foi selecionada uma revisão sistemática com meta-análise.

---

<!-- METADADOS: doenca: Artrite Reativa | secao: **<u>Descrição do estudo e seus resultados</u>** -->
A revisão sistemática e meta-análise de Kroon et al. (2015)(60) avaliou a eficácia e segurança de antiinflamatório não esteroidal (AINE) em pacientes com espondiloartrite axial em comparação a placebo ou a outros comparadores, tendo como principais desfechos dor, índice BASDAI, índice BASFI, índice BASMI, progressão radiográfica, suspensão de tratamento por Eventos Adversos (EA) e EA graves. Foram incluídos 39 estudos (35 ECRs, dois _quasi_ -ECR e dois estudos de coorte), sendo que, destes, 29 ECR e dois _quasi_ -ECR foram incluídos nas análises quantitativas (N=4.356). Cinco estudos avaliaram o naproxeno como intervenção: três em comparação a outros AINE (aceclofenaco, butacote, piroxicam) e dois em comparação a outros medicamentos (celecoxibe, etoricoxibe) e a placebo.  As análises comparativas entre naproxeno e placebo dos dois ECR serão descritas individualmente, de acordo com os desfechos. Os ECR individuais foram consultados para complementação dos dados descritos na RS.  
A revisão sistemática de Kroon et al. (2015)(60) apresentou qualidade metodológica moderada pela ferramenta AMSTAR-2 (61) por apresentar fragilidade em mais de um domínio não crítico, ainda que não tenha apresentado falhas nos domínios críticos, de acordo com a referida ferramenta.  
Os resultados por desfecho encontram-se nas **tabelas 1 a 8** .  
**Tabela 1** - Dor de acordo com escala visual analógica (escala 0-100; maior é pior)  
|**Estudo**|**Tipo**<br>**Estudo**|**Pacientes (n**|**)**|**Intervenções**|**Resultados**|**Limitações do estudo**|
|---|---|---|---|---|---|---|
|Kroon<br>FP e cols<br>(2015)|Revisão<br>sistemática<br>(39 estudos; 2<br>ECR incluídos<br>nesta análise)|Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van H<br>2005):  n=387.<br>Estudo 2 (Barkh<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>eijde,<br>uizen,|Estudo 1: etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/<br>dia(n=99)<br>x<br>placebo<br>(n=93).<br>Tempo de tratamento: 6 semanas<br>(parte I, de interesse).<br>Estudo 2: celecoxibe 200 mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia(157) x placebo (156). Tempo<br>de tratamento: 12 semanas.|Estudo 1:naproxeno vs. placebo<br>Escala da dor (média ± dp): 43,29±24,62 vs<br>64,37 ± 23,72;<br>diferença média [IC95%]: -21.08 [ -27,95, -<br>14,21]; p<0,05 (valor não informado).<br>Estudo 2:naproxeno vs. placebo<br>Mudança média na intensidade da dor em<br>comparação ao_baseline_: 36,4 mm_vs_10,3<br>mm|Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente, não sendo<br>possível utilizar dados da<br>meta-análise.<br>Estudos avaliados incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante axial (critério<br>modificado de Nova Iorque).<br>*Estudo<br>2:<br>não<br>efetuada<br>comparação estatística entre<br>osgrupos.|  
Legenda: dp: desvio padrão; ECR: ensaio clínico randomizado; IC: intervalo de confiança  
**Tabela 2** - Escore BASDAI (escala 0-100; maior é pior)  
|**Estudo**|**Tipo**<br>**Estudo**<br>**Pacientes (**|**n)**<br>**Intervenções**<br>**Resultados**|**Limitações do estudo**|
|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática (39<br>estudos; 2 ECR<br>incluídos nesta<br>análise)<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica)<br>Estudo 1 (van<br>2005):  n=387.<br>Estudo 2 (Bark<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>Heijde,<br>huizen,<br>Estudo 1:etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/ dia<br>(n=99) x placebo (n=93). Tempo de<br>tratamento: 6 semanas (parte I, de<br>interesse).<br>Estudo<br>2:<br>celecoxibe200<br>mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia(157) x placebo (156). Tempo de<br>tratamento: 12 semanas.<br>Estudo 1: naproxeno vs. placebo<br>Escore médio (± dp): 37,25 (20,26) vs 54,<br>(19,46);<br>diferença média (IC95%): -17,45 (-23,10,<br>11,80); p<0,05 (valor não informado).<br>Estudo 2: naproxeno x placebo<br>Mudança média no escore após 12 semanas:<br>22,9 vs. -1,74 (não descrita medida d<br>variância).|7<br>-<br>-<br>e<br>Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente,<br>não<br>sendo<br>possível utilizar dados da meta-<br>análise.<br>Estudos<br>avaliados<br>incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante<br>axial<br>(critério<br>modificado de Nova Iorque).<br>Estudo 2 não descreveu medida<br>de variância, impossibilitando<br>comparação estatística entre os<br>grupos.|  
Legenda: dp: desvio padrão; ECR: ensaio clínico randomizado; IC: intervalo de confiança  
**Tabela 3** - Escore BASFI (escala 0-100; maior é pior)  
|**Estudo**|**Tipo**<br>**Estudo**<br>**Pacientes (n**|**)**<br>**Intervenções**<br>**Resultados**|**Limitações do estudo**|
|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática (39<br>estudos; 2 ECR<br>incluídos nesta<br>análise)<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van<br>2005):  n=387.<br>Estudo 2 (Bark<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>Heijde,<br>huizen,<br>Estudo 1:etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/ dia<br>(n=99) x placebo (n=93). Tempo de<br>tratamento: 6 semanas (parte I, de<br>interesse).<br>Estudo 2: celecoxibe 200 mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia (157) x placebo (156). Tempo de<br>tratamento: 12 semanas.<br>Estudo 1:naproxeno vs. placebo<br>Escore médio (± dp): 39,44 (20,37) vs. 50,0<br>(17,6);<br>diferença média (IC95%): -10.58 (-15,99,<br>5,17); p<0,05 (valor não informado).<br>Estudo 2:naproxeno vs. placebo:<br>Melhora no escore em comparação a<br>_baseline_: 15,5 mm_vs_3,1 mm|2<br>-<br>o<br>Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente,<br>não<br>sendo<br>possível utilizar os dados da<br>meta-análise.<br>Estudos<br>avaliados<br>incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante<br>axial<br>(critério<br>modificado de Nova Iorque).<br>*Estudo<br>2:<br>não<br>efetuada<br>comparação estatística entre os<br>grupos.|  
**Tabela 4** - Avaliação global do paciente (escala 0-100; maior é pior)  
|**Estudo**|**Tipo**<br>**Estudo**<br>**Pacientes (n**|**)**<br>**Intervenções**<br>**Resultados**|**Limitações do estudo**|
|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática (39<br>estudos; 2 ECR<br>incluídos nesta<br>análise)<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van<br>2005):  n=387.<br>Estudo 2 (Bark<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>Heijde,<br>huizen,<br>Estudo 1:etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/ dia<br>(n=99) x placebo (n=93). Tempo de<br>tratamento: 6 semanas (parte I, de<br>interesse).<br>Estudo 2: celecoxibe 200 mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia (157) x placebo (156). Tempo de<br>tratamento: 12 semanas.<br>Estudo 1:naproxeno vs. placebo<br>Escore médio (± dp): 43 (24,76) vs 60,3<br>(24,62); diferença média (IC95%): -17,37 (<br>24,39, -10,35); p<0,05 (valor não informado).<br>Estudo 2:naproxeno vs. placebo<br>Melhora no escore em comparação a<br>_baseline_: 27,8 mm vs  4,4 mm|7<br>-<br> <br>o<br>Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente,<br>não<br>sendo<br>possível utilizar os dados da<br>meta-análise.<br>Estudos<br>avaliados<br>incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante<br>axial<br>(critério<br>modificado de Nova Iorque).<br>*Estudo<br>2:<br>não<br>efetuada<br>comparação estatística entre os<br>grupos.|  
Legenda: dp: desvio padrão; ECR: ensaio clínico randomizado; IC: intervalo de confiança.  
**Tabela 5** - Número de qualquer evento adverso  
|**Estudo**|**Tipo**<br>**Estudo**<br>**Pacientes (n**|**)**<br>**Intervenções**<br>**Resultados**|**Limitações do estudo**|
|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática (39<br>estudos; 2 ECR<br>incluídos nesta<br>análise)<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van<br>2005):  n=387.<br>Estudo 2 (Bark<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>Heijde,<br>huizen,<br>Estudo 1:etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/ dia<br>(n=99) x placebo (n=93). Tempo de<br>tratamento: 6 semanas (parte I, de<br>interesse).<br>Estudo 2: celecoxibe 200 mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia (157) x placebo (156). Tempo de<br>tratamento: 12 semanas.<br>Estudo 1:naproxeno vs. placebo<br>41/99 vs. 37/93; RR (IC95%) 1,04 (0,74, 1<br>p>0,05 (valor não informado)<br>Estudo 2:naproxeno vs. placebo<br>78/157 vs. 82/156; RR (IC95%) 0,95 (<br>1,17); p>0,05 (valor não informado)|,47);<br>0,76,<br>Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente,<br>não<br>sendo<br>possível utilizar os dados da<br>meta-análise.<br>Estudos<br>avaliados<br>incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante<br>axial<br>(critério<br>modificado de Nova Iorque).|  
Legenda: ECR: ensaio clínico randomizado; IC: intervalo de confiança; RR: risco relativo.  
**Tabela 6** - Número de eventos adversos graves  
|**Estudo**|**Tipo**<br>**Estudo**|**Pacientes (n**|**)**<br>**Intervenções**<br>**Resultados**|**Limitações do estudo**|
|---|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática<br>estudos; 2 E<br>incluídos ne<br>análise)|(39<br>CR<br>sta<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van<br>2005):  n=387.<br>Estudo 2 (Bark<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>Heijde,<br>huizen,<br>Estudo 1:etoricoxibe 90 mg<br>(n=103) x etoricoxibe 120 mg<br>(n=92) x naproxeno 500 mg 2 x/<br>dia(n=99) x placebo (n=93). Tempo<br>de tratamento: 6 semanas (parte I,<br>de interesse).<br>Estudo 2: celecoxibe 200 mg<br>(n=137) x celexocibe 400 mg<br>(n=161) x naproxeno 500 mg 2 x/<br>dia(157) x placebo (156). Tempo de<br>tratamento: 12 semanas.<br>Estudo 1:naproxeno vs. placebo<br>0/99 vs. 0/93; RR não estimado<br>Estudo 2:naproxeno vs. placebo<br>3/157 vs. 2/156; RR (IC95%) 1,49 (0,25,<br>p>0,05 (valor não informado)|8,80);<br>Somente<br>dois<br>estudos<br>avaliaram<br>naproxeno<br>com<br>comparador<br>previsto<br>na<br>pergunta PICO e, portanto,<br>foram<br>descritos<br>individualmente,<br>não<br>sendo<br>possível utilizar os dados da<br>meta-análise.<br>Estudos<br>avaliados<br>incluíram<br>pacientes<br>com<br>espondilite<br>anquilosante<br>axial<br>(critério<br>modificado de Nova Iorque).|  
Legenda: ; ECR: ensaio clínico randomizado; IC: intervalo de confiança; RR: risco relativo.  
**Tabela 7** - Número de eventos adversos por sistemas  
|**Estudo**|**Tipo**<br>**Estudo**|**Pacientes (n)**|<br>**Intervenções**<br>**Resultados**|**Limit**|**ações do e**|**studo**|
|---|---|---|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática (<br>estudos; 2 E<br>incluídos nes<br>análise)|39<br>CR<br>ta<br>Pacientes<br>espondiloartrite<br>(espondilite<br>anquilosante<br>espondiloartrite<br>não-radiográfica).<br>Estudo 1 (van H<br>2005): n=387.<br>Estudo 2 (Barkh<br>2006):  n=611.|com<br>axial<br>e<br>axial<br> <br>eijde,<br>uizen,<br>Estudo 1:Etoricoxibe 90 mg<br>(n=103) x Etoricoxibe 120 mg<br>(n=92) x Naproxeno 500 mg 2 x/<br>dia (n=99) x placebo (n=93).<br>Tempo<br>de<br>tratamento:<br>6<br>semanas (parte I, de interesse).<br>Estudo 2:Celecoxibe 200 mg<br>(n=137) x Celexocibe 400 mg<br>(n=161) x Naproxeno 500 mg 2<br>x/<br>dia(157)<br>x<br>Placebo<br>(156).Tempo de tratamento: 12<br>semanas.<br>Estudo 1:naproxeno vs. placebo<br>- EA gastrointestinal: 5/99 vs 5/93; RR 0,94<br>(0,28, 3,14); p>0,05 (valor não informado).<br>- EA respiratório: 2/99 vs 3/93; RR 0,63 (0,11,<br>3,66); p>0,05 (valor não informado).<br>- EA neurológico: 2/99 vs 3/93; RR 0,63 (0,11,<br>3,66); p>0,05 (valor não informado).<br>Estudo 2:naproxeno vs. placebo<br>- EA gastrointestinal: 29/157 vs. 13/156; RR<br>2,22<br>(1,20,<br>4,10);<br>p<0,05<br>(valor<br>não<br>informado).3 pacientes do grupo naproxeno<br>apresentaram EA gastrointestinais (GI) graves<br>(1 úlcera gástrica grave, 1 hemorragia GI<br>moderada e 1 hemorragia GI grave).<br>- EA respiratório: 16/157 vs. 20/156; RR 0,80<br>(0,43, 1,49); p>0,05 (valor não informado).<br>- EA neurológico: 3/157 vs. 11/156; RR 0,27<br>(0,08, 0,95); p<0,05 (valor não informado).<br>- EA dermatológico: 0/157 vs. 3/156; RR 0,14<br>(0,01, 2,73); p>0,05 (valor não informado).|Somente<br>avaliaram<br>comparad<br>pergunta<br>foram<br>individual<br>possível u<br>meta-análi<br>Estudos<br> <br>pacientes<br>anquilosan<br>modificado|dois<br>naprox<br>or<br>pre<br>PICO e,<br>mente,<br>n<br>tilizar os<br>se.<br>avaliados<br>com<br>te<br>axial<br>de Nova|estudos<br>eno<br>com<br>visto<br>na<br>portanto,<br>descritos<br>ão<br>sendo<br>dados da<br>incluíram<br>espondilite<br> <br>(critério<br>Iorque).|  
Legenda: EA: evento adverso; ECR: ensaio clínico randomizado; IC: intervalo de confiança; RR: risco relativo.  
**Tabela 8** - Saída do estudo por evento adverso  
|**Estudo**|**Tipo**<br>**Estudo**|<br>**Pacientes (n)**|**Intervenções**<br>**Resultados**|**Limi**|**tações do est**|**udo**|
|---|---|---|---|---|---|---|
|Kroon FP<br>e<br>cols<br>(2015)|<br> <br>Revisão<br>sistemática<br>estudos; 2<br>incluídos n<br>análise).|(39<br>ECR<br>esta<br>Pacientes<br>com<br>espondiloartrite axial<br>(espondilite<br>anquilosante<br>e<br>espondiloartrite axial<br>não-radiográfica).<br>Estudo 1 (van de<br>Heijde,<br>2005):<br>n=387.<br>Estudo<br>2<br>(Barkhuizen,<br>2006):<br>n=611.<br>Estudo 1<br>(n=103)<br>(n=92) x n<br>(n=99) x p<br>tratament<br>interesse)<br>Estudo 2<br>(n=137)<br>(n=161) x<br>dia(157) x<br>tratament|:etoricoxibe 90 mg<br>x etoricoxibe 120 mg<br>aproxeno 500 mg 2 x/ dia<br>lacebo (n=93). Tempo de<br>o: 6 semanas (parte I, de<br>.<br>:celecoxibe 200 mg<br>x celexocibe 400 mg<br>naproxeno 500 mg 2 x/<br>placebo (156). Tempo de<br>o: 12 semanas.<br>Estudo 1:naproxeno vs. placebo<br>1/99 vs. 1/93; RR 2,82 (IC95% 0,12 –<br>68,37); p>0,05 (valor não informado).<br>Estudo 2:naproxeno vs. placebo<br>9/157 vs. 11/156; RR 0,81 (IC95% 0,35-<br>1,91); p>0,05 (valor não informado).|<br> <br>Somente d<br>naproxeno<br>previsto n<br>portanto,<br>individualm<br>possível uti<br>análise.<br>Estudos<br>pacientes<br>anquilosan<br>modificado|ois estudos<br> <br>com<br>c<br>a pergunta<br>foram<br>ente,<br>nã<br>lizar os dado<br>avaliados<br>com<br>te<br>axial<br>de Nova Iorq|avaliaram<br>omparador<br>PICO e,<br>descritos<br>o<br>sendo<br>s da meta-<br>incluíram<br>espondilite<br>(critério<br>ue).|  
Legenda: ECR: ensaio clínico randomizado; IC: intervalo de confiança; RR: risco relativo.

---

