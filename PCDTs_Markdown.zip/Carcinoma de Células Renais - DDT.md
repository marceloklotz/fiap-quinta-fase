<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 20, de 27 de OUTUBRO de 2022.  
Aprova as Diretrizes Diagnósticas e Terapêuticas do Carcinoma de Células Renais.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTA e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE - SUBSTITUTA , no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Carcinoma de Células Renais e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 752/2022 e o Relatório de Recomendação nº 755 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas - do Carcinoma de Células Renais.  
Parágrafo único. As Diretrizes objeto deste artigo, que contêm o conceito geral do Carcinoma de Células Renais, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponíveis no sítio <u>https://www.gov.br/saude/pt-br/assuntos/pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos</u> Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do carcinoma de células renais.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS n<sup>o</sup> 1.440, de 16 de dezembro de 2014, publicada no Diário Oficial da União nº 244, de 17 de dezembro de 2014, seção 1, página 78.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.  
MARIA INEZ PORDEUS GADELHA  
ANA PAULA TELES FERREIRA BARRETO

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **1. INTRODUÇÃO** -->
O Carcinoma de Células Renais (CCR), também chamado de câncer de células renais ou de adenocarcinoma de células renais, é o tipo mais comum de câncer de rim<sup>1</sup> . O CCR é responsável, respectivamente, por 5% e 3% de todas as doenças malignas em homens e mulheres, sendo assim, o sétimo câncer mais comum entre homens e o décimo câncer mais comum entre mulheres<sup>2</sup> . Dos tipos de CCR, 70% a 80% são tumores de células claras (CRCC), 10% a 15% são carcinomas papilares (ou papilíferos), 3% a 5% são CCR do subtipo cromófobo e 1% é carcinoma de origem dos ductos coletores (tumor de Bellini). Os demais tipos celulares são considerados muitos raros, com prevalência abaixo de 1%<sup>3,4</sup> .  
Em 2018, estimou-se que o câncer renal tenha sido responsável por 2,2% dos novos casos de neoplasias malignas no adulto no mundo<sup>5</sup> . No Brasil, nesse mesmo ano, a incidência estimada foi de 10.688 novos casos com taxa geral padronizada por idade de 4,3 casos por 100.000 habitantes e uma taxa bruta geral de 5,1%. Já a taxa bruta de mortalidade foi de 1,9%, caracterizando um dos cânceres urológicos com maior letalidade<sup>6</sup> . Devido ao alto grau de incerteza que acompanha a projeção de pequenos números, não se recomenda estimar o número de casos de câncer de baixa incidência, como o câncer renal. Assim, por demanda específica, em 2018, o Instituto Nacional de Câncer, do Ministério da Saúde, estimou, em todo Brasil, 6.270 casos de câncer de rim, sendo 3.760 entre homens e 2.510 entre mulheres<sup>7</sup> .  
O CCR é muito raro em indivíduos com menos de 40 anos e tem seu pico de incidência entre os 60 e 70 anos<sup>8</sup> . A razão de casos entre homens e mulheres é 1,5:1. Homens são mais acometidos devido a fatores de risco bem estabelecidos, como tabagismo, hipertensão arterial sistêmica, obesidade e síndromes genéticas (como a síndrome de von HippelLindau)<sup>8</sup> . Por outro lado, o controle do peso, a atividade física, o consumo regular de frutas e verduras (em particular, as crucíferas) e evitar ou suspender o tabagismo são fatores potencialmente protetores<sup>8,9</sup> .  
Os sintomas do CCR incluem dor lombar, hematúria, massa abdominal palpável, síndromes paraneoplásicas e manifestações de doença metastática, como dor óssea, tosse persistente ou linfadenomegalia periférica. O exame físico tem um papel limitado no diagnóstico do CCR. As lesões renais expansivas, sejam sólidas ou císticas, permanecem, na sua maioria, assintomáticas e impalpáveis até os estágios mais avançados da doença<sup>10</sup> . O rastreamento populacional de câncer renal em população assintomática não tem bases técnico-científicas<sup>10–13</sup> . Entretanto, o rastreamento com ecografias periódicas pode ser considerado para pacientes com alto risco de desenvolvimento do câncer de células renais, como aqueles com síndrome de von Hippel-Lindau<sup>14</sup> .  
O indicador mais significativo de prognóstico para o carcinoma de células renais é o estadiamento patológico<sup>15</sup> . Pacientes com câncer em estágio I ou II no momento do diagnóstico têm taxa de sobrevida em cinco anos de 80% a 90%. Os indicadores de mau prognóstico incluem: escores de baixo estado funcional usando a escala de desempenho de Karnofsky<sup>16,17</sup> ou a escala de _performance status_ do _Eastern Cooperative Oncology Group_ (ECOG)<sup>18</sup> , altos níveis séricos de desidrogenase láctica (DHL) – também conhecida como lactatodesidrogenase (LDH), hemoglobinemia baixa, altos níveis séricos de cálcio corrigido e diabete melito<sup>15,19</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos do carcinoma de células renais, com o  
objetivo de orientar o que é válido e não válido técnico-cientificamente, com base em evidências que garantam a segurança, a efetividade e a reprodutibilidade, para orientar condutas e protocolos assistenciais. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- C64 Neoplasia maligna do rim, exceto pelve renal.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3. DIAGNÓSTICO** -->
As lesões renais expansivas na sua maioria, sejam sólidas ou císticas, permanecem assintomáticas e impalpáveis até os estágios mais avançados da doença, tornando o papel do exame físico limitado<sup>20</sup> . Hoje em dia, a maioria dos casos é diagnosticada incidentalmente, pelo uso frequente de exames de imagens indicados para uma variedade de sintomas ou doenças não relacionadas ao câncer<sup>21</sup> . Os tumores renais diagnosticados de forma fortuita perfazem em torno de 75% dos casos e se associam a melhor prognóstico. A tríade clássica de dor em flanco, hematúria e massa abdominal palpável é rara (6% a 10% dos casos) e está correlacionada a tipo histopatológico neoplásico agressivo e a doença avançada<sup>22</sup> .  
Alguns pacientes com CCR apresentam manifestações de doença metastática<sup>20</sup> . Os pulmões são o sítio mais comum de metástases em pacientes com CCR, as quais ocorrem em estágios mais tardios e indicam pior prognóstico<sup>23,24</sup> . Cerca de 35% a 40% dos pacientes com CCR metastático apresentam metástases ósseas. A metástase óssea (lesões osteoblásticas e mistas) pode causar dor, fratura patológica, compressão da medula espinhal, hipercalcemia e outros eventos relacionados ao esqueleto, que podem afetar significativamente a qualidade de vida dos pacientes<sup>25</sup> . Metástases hepáticas também são comuns em casos de CCR e têm piores resultados de sobrevida em comparação com pacientes com metástases em outros órgãos<sup>26</sup> .  
Síndromes paraneoplásicas ocorrem em 30% dos pacientes com CCR sintomático<sup>27</sup> . Muitas vezes, as síndromes paraneoplásicas podem ser o primeiro sintoma que o paciente apresenta e atuam como indicador da presença de uma malignidade oculta. Alguns sinais e sintomas de síndromes paraneoplásicas relativamente comuns são: anemia (observada em 52% dos pacientes elegíveis para nefrectomia)<sup>20</sup> ; hipercalcemia (afetando entre 13% e 20% dos pacientes)<sup>28</sup> ; disfunção hepática, também chamada de síndrome de Sauffer quando não há metástase hepáticas (em uma série com 365 pacientes, 21% estavam com a fosfatase alcalina estava elevada<sup>29</sup> ); febre (que ocorre em até 20% dos pacientes)<sup>30</sup> e é usualmente intermitente e associada a sudorese noturna; anorexia; perda ponderal; e fadiga. Outros sinais e sintomas de síndromes paraneoplásicas são caquexia, eritrocitose, amiloidose secundária, trombocitose e poliartralgia reumática.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.1. Diagnóstico por imagem** -->
Os nódulos ou massas renais são um grupo de tumores biologicamente heterogêneos que podem ser benignos, malignos (indolentes ou agressivos) ou indeterminados. São identificados incidentalmente em 10% a 27% dos exames de imagem abdominal (ecografia, tomografia computadorizada [TC] ou ressonância magnética [RM]). A maioria das massas renais pode ser determinada como benigna ou maligna por meio dos exames de imagem supracitados, mas as lesões indeterminadas necessitarão de avaliação complementar<sup>31</sup> . Lesões incidentais com tamanho menor que 1 cm são dificilmente caracterizadas com exames complementares ou biópsia. Além disso, são benignas na maioria dos casos e, mesmo quando malignas, costumam ter comportamento indolente<sup>32</sup> .  
A ecografia abdominal é usualmente o primeiro exame a identificar as massas renais e consegue diferenciar massas sólidas e císticas. Massas renais sólidas podem ser essencialmente divididas entre lesões suspeitas de carcinoma de células renais e de angiomiolipoma (tumor benigno)<sup>33</sup> . Para as lesões sólidas, mesmo quando a suspeita é de angiomiolipoma (lesão caracteristicamente hiperecogênica), indica-se a realização de, pelo menos, uma TC ou RM de abdome, com contraste, para se estabelecer o diagnóstico com maior confiabilidade, já que até um terço dos carcinomas de células renais são hiperecogênicos<sup>34</sup> .  
As massas renais císticas identificadas à ecografia são essencialmente divididas em cistos simples e complexos, os quais podem estar em situação cortical, medular ou parapélvica. Os cistos renais simples (de formato arredondado, paredes lisas e anecoicos) assintomáticos identificados à ecografia não precisam de qualquer avaliação complementar, independentemente do seu tamanho, nem de seguimento<sup>35</sup> . Entretanto, pacientes com cistos renais complexos (de contornos irregulares, paredes espessas, septos ou calcificações) ou múltiplos cistos agrupados (que dificultam a caracterização dos cistos) têm indicação de TC ou RM de abdome, com contraste, para classificar os cistos conforme a classificação Bosniak<sup>36–38</sup> ( **Tabela 1** ).  
**Tabela 1** - <mark>Classificação de Bosniak para cistos renais</mark> .  
|**Categorias**|**Definição e conduta**|
|---|---|
|Categoria I|<br>Cisto simples: conteúdo líquido homogêneo, paredes finas, contornos regulares, sem<br>calcificações, septos, espessamento parietal ou realce pós-contraste.<br><br>Sem necessidade de investigação adicional nem de acompanhamento.|
|Categoria II|<br>Cisto minimamente complicado: presença de septos finos (até dois, espessura abaixo de dois<br>milímetros), mínima calcificação parietal, conteúdo denso, menor que três centímetros, sem<br>realce pós-contraste.<br><br>Sem necessidade de investigação adicional nem de acompanhamento.|
|Categoria IIF|<br>Cisto minimamente complicado: podem apresentar múltiplos septos finos ou levemente<br>espessados, paredes minimamente espessadas e contorno regular. Não há realce mensurável<br>pós-contraste, mas podem apresentar realce percebido (subjetivo) das paredes ou septos do<br>cisto. Podem apresentar calcificações espessas ou nodulares e contornos irregulares.<br>Também estão incluídos nessa categoria os cistos hiperdensos completamente intrarrenais,<br>maiores do que três centímetros, com paredes regulares.<br><br>Requer acompanhamento: risco de câncer menor que 5%, pelo que há necessidade de<br>reavaliação por TC ou RM em seis e doze meses e, depois, anualmente durante cinco anos.|
|Categoria III|<br>Cisto moderadamente complicado: espessamento parietal, presença de septos irregulares e<br>espessos com realce pós-contraste, com ou sem calcificações. Pode se apresentar como<br>cistos multiloculares.<br><br>Risco de câncer de 40% a 60%, motivo pelo qual se indica intervenção cirúrgica na maioria<br>desses casos.|
|Categoria IV|<br>Neoplasia cística: espessamento parietal ou septal grosseiro, nodular ou irregular, com<br>componente sólido junto à parede do cisto ou septos, com realce pós-contraste.<br><br>Risco de câncer de 95% a 100%, sendo indicada intervenção cirúrgica.|  
Fonte: Defortescu et al 2017<sup>39</sup> .  
Para massas renais sólidas, o critério mais importante para caracterizar lesões malignas é a presença de realce póscontraste<sup>40</sup> . Exames de imagem com cortes transversais pré e pós-contraste, como TC ou RM, são os melhores exames para avaliar malignidade das lesões renais sólidas. No entanto, mesmo massas renais sólidas e com realce pós-contraste, cujo exame de imagem pode ser sugestivo de câncer de células renais, podem ser benignas, como o são os oncocitoma e angiomiolipoma pobre em gordura. Dentre as massas renais sólidas ressecadas cirurgicamente, 8% a 27% podem ser benignas. Já o percentual de lesões benignas diminui conforme o tamanho das lesões aumenta: 46% em massas com menos de um centímetro, 30% em massas com menos de dois centímetros e 25% em massas com menos de três centímetros<sup>41–43</sup> .  
A TC abdominal fornece informações sobre a função e morfologia do rim contralateral, a extensão do tumor primário, o envolvimento venoso, a possibilidade de metástases linfonodais locorregionais e a condição das glândulas adrenais e outros órgãos sólidos abdominais. A angiotomografia, quando disponível, é útil em casos selecionados quando é necessário o detalhamento da vascularização renal, como no caso de tumores hilares<sup>44</sup> . A RM pode fornecer informações adicionais sobre a massa renal, extensão local e presença de trombo na veia cava. A RM também é indicada para pacientes com alergia ao contraste iodado ou para gestantes<sup>45–47</sup> . Além disso, a RM parece ter maior acurácia para o diagnóstico de lesões císticas complexas categorizadas como Bosniak IIF a III<sup>39</sup> .  
A ultrassonografia com contraste é uma alternativa para auxiliar na caracterização das lesões renais quando a TC não for conclusiva<sup>48</sup> . A arteriografia renal e a venocavografia inferior têm papel limitado para a avaliação de casos muito selecionados<sup>49</sup> . A cintilografia renal deve ser considerada em caso de pacientes com perda de função renal, para auxiliar na definição do tratamento<sup>50</sup> . Não está recomendada a realização de tomografia por emissão de pósitrons (PET-CT) no diagnóstico e estadiamento do câncer renal<sup>48</sup> .  
A radiografia simples de tórax possui boa acurácia para a avaliação de metástase pulmonar. Tomografia de tórax deve ser realizada seletivamente para pacientes com sintomas respiratórios, achados suspeitos na radiografia simples ou doença locorregional extensa<sup>51–54</sup> . Indica-se TC ou RM encefálicas apenas na presença de sintomas neurológicos, como cefaleia persistente<sup>41</sup> . Por sua vez, a cintilografia óssea está indicada em pacientes com dor óssea ou níveis séricos de fosfatase alcalina elevados. Entretanto, a elevação dos níveis de fosfatase alcalina isoladamente tem baixo valor prognóstico<sup>55</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.2.1. Histopatologia** -->
O CRCC é o tipo histopatológico mais comum, sendo responsável por, aproximadamente, 90% dos tumores renais. Existem outros tipos histológicos, sendo divididos de acordo com a classificação da OMS de 2016<sup>56</sup> ( **Tabela 2** ).  
**Tabela 2** - Classificação histopatológica e características do CCR.  
|**Tipo histopatológico**|**Características**|
|---|---|
|CCRcc - Células claras (75% a 85%)|●<br>Apresentam pior prognóstico do que os tipos papilar e<br>cromófobo.|
|CCRp - Papilar (10% a 15%)|●<br>Dividem-se microscopicamente em papilar tipo 1 (melhor<br>prognóstico) e papilar tipo 2. São multifocais e bilaterais em|
||10% dos pacientes.|
|CCRr - Cromófobo (5% a 10%)|●<br>Tem prognóstico melhor do que o carcinoma de células claras.|
|CCDC - Ductos coletores (ductos de Bellini;|●<br>De comportamento muito agressivo.|  
|**Tipo histopatológico**|**Características**|
|---|---|
|muito raro)||
|De translocação (raro)|●<br>Carcinoma de células renais de translocação associada ao|
||fator de transcrição da microftalmia (MIT)*.|
||●<br>Deve ser suspeitado em caso de crianças e adultos jovens.|
|Outros subtipos mais raros|●<br>Medular (CCRm)|
||●<br>Neoplasia cística multilocular com baixo potencial de|
||malignidade.|
||●<br>CCR associado à Leiomiomatose Hereditária|
||●<br>CCR mucinoso e espinocelular.|
||●<br>CCR deficiente de succinato desidrogenase(SDH).|
||●<br>CCR tubulocístico.|
||●<br>CCR associado à doença renal cística adquirida.|
||●<br>CCR não classificado.|  
Fonte: OMS<sup>56</sup> . * Fusão gênica de dois membros dos fatores de transcrição, originando as translocações Xp11 e t(6;11).Estes tipos histológicos apresentam características morfológicas, genéticas e moleculares distintas, resultando em doenças de prognóstico variável<sup>4</sup> . A presença de áreas de diferenciação sarcomatoide confere um pior prognóstico em qualquer dos tipos histopatológicos.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.2.2. Biópsia de massas renais** -->
Apesar de atualmente ser considerada segura e efetiva, a biópsia de tumores renais tem indicações restritas e deve ser indicada apenas quando o resultado puder alterar a conduta terapêutica do caso. Os principais riscos associados à biópsia são a formação de hematoma e sangramento. A taxa de complicação geral é de 5%. O risco de implante tumoral no trajeto da agulha é considerado desprezível (0,01%)<sup>57</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.2.2.1. Indicações** -->
A indicação mais precisa de biópsia de massa renal localizada é quando houver suspeita de linfoma, abscesso ou metástase. Em casos de neoplasia metastática sem indicação de nefrectomia citorredutora, a biópsia deve ser realizada para confirmação histopatológica e para a definição do tratamento sistêmico. Também deve ser considerada em pacientes com doença localizada e candidatos à vigilância ativa, ou que serão submetidos aos tratamentos por ablação térmica (por radiofrequência ou crioterapia). Em todas as situações, a equipe responsável e o paciente devem estar cientes dos riscos envolvidos (risco pequeno de sangramento e possibilidade de dificultar um possível tratamento cirúrgico posterior). Em pacientes com bom _performance status_ , com expectativa de vida longa e para os quais os riscos cirúrgicos são mínimos, a nefrectomia parcial ou radical, sem confirmação histopatológica, continua a ser o tratamento padrão.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.2.2.2. Técnica** -->
A biópsia pode ser realizada sob orientação de ultrassonografia ou de TC, ambas com desempenho semelhante. Deve-se utilizar técnica coaxial, com uma cânula que evite o contato da amostra do tecido obtido com as estruturas anatômicas ao longo do trajeto. A biópsia por agulha grossa – BAG ( _core biopsy; CB_ ) tem taxas de diagnóstico superiores em comparação com a punção aspirativa por agulha fina – PAAF, devendo-se retirar, no mínimo, dois fragmentos com uma  
agulha de calibre mínimo 16- _gauge_<sup>58</sup> . As duas técnicas podem ser usadas de forma complementar, elevando ainda mais as suas acurácias isoladas.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.3. Avaliação da extensão da doença (estadiamento)** -->
O estadiamento do carcinoma de células renais deve observar os critérios da 8ª edição do manual da União  
Internacional para Controle do Câncer (UICC)<sup>59</sup> , conforme simplificado no **Quadro 1** .  
**Quadro 1** - Definições de T, N e M de acordo com a União Internacional para Controle do Câncer (UICC)<sup>59</sup> .  
|**Categoria**|**Critérios**|
|---|---|
||TX: tumor primário não pode ser avaliado.|
||T0: sem evidência do tumor primário.|
||T1: tumor menor ou igual a sete centímetros no maior diâmetro, restrito ao rim.<br>T1a: tumor menor ou igual a quatro centímetros no maior diâmetro, restrito ao rim.<br>T1b: tumor maior que quatro centímetros, mas menor ou igual a sete centímetros no<br>maior diâmetro, restrito ao rim.|
|**Tumor primário (T)**|T2: tumor maior que sete centímetros no maior diâmetro, restrito ao rim.<br>T2a: tumor maior que sete centímetros, mas menor ou igual dez centímetros no maior<br>diâmetro, restrito ao rim.<br>T2b: tumor maior que dez centímetros no maior diâmetro, restrito ao rim.|
||T3: tumor com extensão para as veias principais ou tecidos periféricos, mas não<br>envolve a glândula adrenal ipsilateral e não ultrapassa a fáscia de Gerota.<br>T3a: tumor com extensão à veia renal ou seus segmentos, ou invade a gordura do seio<br>renal ou perirenal sem ultrapassar a fáscia de Gerota.<br>T3b: tumor com extensão à veia cava infradiafragmática.<br>T3c: tumor com extensão à veia cava supradiafragmática ou invade a parede do vaso.|
||T4: tumor ultrapassa a fáscia de Gerota (incluindo extensão por contiguidade à<br>glândula suprarrenal ipsilateral).|
||NX: linfonodos regionais não avaliados.|
|**Linfonodos (N)**|N0: ausência de acometimento linfonodal regional.|
||N1: metástase em linfonodos regionais.|
|**Metástase a distância (M)**|MX: metástase(s) não avaliadas.|
||M0: ausência de metástase(s).|
||M1: metástase(s) presentes.|
||Estádio I - T1, N0 e M0.|
|**Agrupamento por**|Estádio II - T2, N0 e M0.|
|**estádios**|Estádio III - N1, T1 ou T2 e M0; ou T3, N0 ou N1 e M0.<br>Estádio IV - T4 ou M1.|  
Ressalta-se que a classificação baseia-se no momento de avaliação e tratamento da doença. A classificação TNM pode ser<sup>59</sup> :  
- Clínica (cTNM): o estadiamento baseia-se na anamnese, no exame físico e nos exames de imagem realizados antes de iniciar o tratamento. Os exames de imagem, entretanto, não são obrigatórios para determinar o estágio clínico da doença, que deve ser determinado a partir das informações disponíveis.  
- Patológica (pTNM): o estadiamento baseia-se em informações adicionais obtidas a partir de achados operatórios e análise patológica de amostras; é aplicável quando o procedimento cirúrgico ocorre antes do início da radioterapia adjuvante ou terapia sistêmica.  
Em alguns casos, descritores adicionais podem ser utilizados:  
- m: o sufixo (m) é usado para indicar a presença de múltiplos tumores primários em um único local;  
- y: o prefixo y é usado quando a classificação é realizada durante ou após terapia multimodal (ycTNM ou ypTNM). Esta classificação corresponde à extensão do tumor no momento em que a avaliação está sendo feita (em vigência da terapia multimodal);  
- r: o prefixo r identifica tumores recorrentes classificados após um intervalo livre de doença;  
- a: o prefixo a é utilizado para identificar que a classificação foi feita pela primeira vez na autópsia.  
Outros fatores além dos presentes na classificação TNM são importantes para definição do prognóstico<sup>60</sup> :  
- Tipo histopatológico: o CCRcc detém pior prognóstico entre os tipos histológicos mais comuns tipos patológicos enquanto os tumores de ducto de Bellini e medular são os mais agressivos;  
- grau nucleolar OMS/ISUP<sup>61</sup> ;  
- presença de componentes sarcomatoide e rabdoide;  
- presença de necrose tumoral; e  
- invasão angiolinfática microscópica.  
<u>Nota: O sistema OMS/ISUP de classificação da Organização Mundial da Saúde e Sociedade Internacional de</u> Patologia Urológica (ISUP — _International Society of Urological Pathology_ ) para o carcinoma de células renais é validado como um parâmetro de prognóstico para o carcinoma de células renais papilar e de células claras, mas pode ser utilizado, para fins descritivos, para outros tipos de carcinoma de células renais, exceto o carcinoma de células renais cromófobo. O grau deve ser atribuído com base no campo de alta potência único que mostra o maior grau de pleomorfismo nuclear.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.4. Exames laboratoriais** -->
A avaliação clínica pela anamnese, exame físico, exames de imagem e complementares auxiliam o planejamento terapêutico. Estes exames são requisitos para o estadiamento e pontuação de escores prognósticos (principalmente em casos metastáticos) e permitem a detecção e avaliação das condições clínicas e comorbidades do paciente. Os exames complementares incluem<sup>62,63</sup> :  
- Hemograma completo;  
- velocidade de hemossedimentação;  
- dosagem sérica de ureia, creatinina, proteína C reativa (PCR), cálcio, albumina, desidrogenase láctica (DHL) e fosfatase alcalina;  
- provas de função hepática.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3.5. Fatores prognósticos** -->
Alguns fatores influenciam o prognóstico dos doentes com câncer renal e devem ser registrados por ocasião do diagnóstico. Dentre os fatores clínicos, estão a capacidade funcional – _performance status_ /PS, níveis sanguíneos de hemoglobina e níveis séricos de cálcio e desidrogenase láctica. Os fatores anatômicos são a classificação TNM e o estadiamento. Já os fatores histopatológicos incluem a classificação histopatológica nuclear de Fuhrman (baseada em parâmetros como tamanho nuclear e o formato e as proeminências dos nucléolos)<sup>64</sup> , tipo histopatológico, presença de componente sarcomatoide, invasão microvascular, invasão capsular, necrose tumoral e invasão do sistema coletor<sup>15,62,63</sup> .  
Em pacientes com doença localizada, o estadiamento patológico (TNM) é o fator isolado mais importante para o prognóstico. A invasão direta da parede da veia renal é um fator prognóstico mais importante do que a extensão cranial do trombo<sup>15,62,63</sup> . A maior redução de sobrevida se observa em pacientes com tumores T4, N1 ou M1. Vários nomogramas já foram validados para estratificar sobrevida em pacientes com tumores localizados ou metastáticos. Para estratificação de risco de pacientes com doença localizada ou metastática, pode-se utilizar o sistema de estadiamento integrado da Universidade da Califórnia de Los Angeles (UCLA), por ser a mais utilizada para a inclusão de pacientes em estudos clínicos ( **Tabela 3** )<sup>15,62,63</sup> .  
**Tabela 3** - Grupos de risco pelo sistema de estadiamento integrado da Universidade da Califórnia.  
|**Risco**|**Doença localizada (N0, M0) ao diagnóstico**|**Doença avançada (N1-2, M1) ao diagnóstico**|
|---|---|---|
|||●<br>N1M0, qualquer grau e qualquer PS.|
|Baixo|●<br>T1, grau 1-2 e PS = 0.|●<br>N2M0, grau 1-2 e PS = 0.|
|||●<br>M1, grau 1-2 e PS = 0.|
||●<br>T1, grau 1-2 e PS igual ou maior|●<br>N2M0, grau 1-2 e PS igual ou maior que 1.|
||que 1.|●<br>N2M0, grau 3 e qualquer PS.|
|Itdiái|●<br>T1, grau 3-4 e qualquer PS. T2,|●<br>N2M0, grau 4 e PS = 0.|
|nermero|qualquer grau e qualquer PS.|●<br>M1, grau 1-2 e PS igual ou maior que 1.|
||●<br>T3, grau 1 e qualquer PS. T3, grau|●<br>M1, grau 3 e qualquer PS.|
||2-4 e PS = 0.|●<br>M1, grau 4 e PS = 0.|
|Alto|●<br>T3, grau 2-4 e PS igual ou maior|●<br>N2M0, grau 4 e PS igual ou maior que 1.|
||que 1. T4, qualquer grau e qualquer PS.|●<br>M1, grau 4 e PS igual ou maior que 1.|  
Legenda: PS = _performance status_ ; Grau de Fuhrman<sup>64</sup> ou ISUP/OMS<sup>61</sup> .  
Para avaliação de pacientes com CCR metastático, já foram validados sistemas de classificação como o da _Cleveland Clinic_ , do _Memorial Sloan Kettering Cancer Center_ (MSKCC) e o _International Metastatic Renal Cell Carcinoma Database Consortium_ (IMDC). Os fatores mais importantes nestes casos são: intervalo livre de metástase desde o diagnóstico, _performance status_ , número e locais de metástases, anemia, hipercalcemia, níveis elevados de fosfatase alcalina ou de desidrogenase lática, trombocitose e histologia sarcomatoide<sup>62,63</sup> . Metástases ósseas, cerebrais ou hepáticas e vários locais metastáticos implicam em maior comprometimento prognóstico. O escore da IMDC ( **Quadro 2** ) demonstrou melhor capacidade de definição de prognóstico e tem sido o mais utilizado em estudos clínicos<sup>65</sup> . Esta classificação é um dos principais critérios utilizados para a indicação de nefrectomia citorredutora.  
**Quadro 2** - Fatores prognósticos do _International Metastatic Renal Cell Carcinoma Database Consortium_ (IMDC)  
|**Fatores prognósticos**|
|---|
|Escore de Karnofskydeperformance status menorque 80|
|Tempo do diagnóstico até início da terapia alvo menorque 1 ano|
|Hemoglobina abaixo do limite inferior da normalidade|
|Cálcio sérico acima do limite superior da normalidade|
|Contagem de neutrófilos acima do limite superior da normalidade|
|Plaquetas acima do limite superior da normalidade|
|**Classificação**|
|Risco baixo: nenhum dos fatores de risco|
|Risco intermediário: 1 ou 2 dos fatores de risco|
|Risco alto:  maior ou igual a 3 fatores de risco ou mais|
|Adaptado de Heng et al 2013<sup>66</sup>.|  
Ressalta-se que não se conhece o desempenho prognóstico destas escalas estabelecidas para casos tratados com medicamentos recentemente desenvolvidos, como os chamados imunoterápicos, vez que elas foram desenvolvidas e validadas em bases de dados que não incluíam doentes tratados com medicamentos dessa classe terapêutica<sup>62,63</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nestas DDT os pacientes com idade de 19 ou mais anos e que tenham diagnóstico de Carcinoma de Células Renais.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicação absoluta ao uso do respectivo procedimento ou medicamento ou recomendados nestas DDT.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.1. Doença Localizada** -->
O tratamento das neoplasias renais malignas localizadas é preferencialmente o cirúrgico. A escolha pela nefrectomia parcial ou radical varia de acordo com o tamanho da lesão, localização, grau de acometimento do órgão, via de acesso e experiência do cirurgião. O procedimento cirúrgico pode ser realizado por via aberta, laparoscópica ou assistido por robótica (de iguais resultados terapêuticos), de acordo com a disponibilidade nos serviços de saúde. Alternativamente, para pacientes com lesões pequenas ou que não são candidatos ao tratamento cirúrgico devido à idade avançada ou comorbidades presentes, a vigilância ativa ou as terapias ablativas, como a crioterapia e a ablação por radiofrequência, são opções terapêuticas<sup>67–70</sup> .  
Os tratamentos ablativos podem ser considerados nos casos de paciente que apresente tumores corticais de pequena dimensão, inferiores ou iguais a 3 cm e idade inferior a 70 anos, alto risco cirúrgico, apenas um rim, função renal comprometida, CCR hereditário ou múltiplos tumores bilaterais. Para confirmar o potencial de malignidade do tumor e o seu subtipo, é recomendada biópsia renal<sup>71–73</sup> .  
Na _radioablação_ , é produzido um calor local em torno de 80°C, suficiente para induzir a necrose das células neoplásicas. Na _crioablação_ , é gerada uma bola de gelo a baixíssimas temperaturas (em torno de -140°C) que, por meio de  
ciclos sucessivos de congelamento e descongelamento, promove a destruição das células tumorais<sup>74,75</sup> . Esses procedimentos podem ser realizados durante um ato operatório, acrescentando recursos adicionais ao procedimento cirúrgico.  
Minimamente invasiva, a ablação percutânea é um procedimento seguro, com baixas taxas de complicações (2% a 3%)<sup>74,75</sup> . Na maioria dos casos, não requer internações prolongadas nem anestesia profunda, e é bem tolerada pelos pacientes, que podem retornar às suas atividades rotineiras em pouco tempo - em alguns casos, até no dia seguinte. Cerca de 40% dos pacientes apresentam reações passageiras, como febre baixa, dor e desconforto locais, fadiga e prostração, que costumam durar de dois a três dias após o procedimento e são facilmente controladas com medicamentos<sup>74–76</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.1.1. Tratamento cirúrgico** -->
Apesar da escassez de ensaios clínicos e da heterogeneidade dos estudos retrospectivos, a nefrectomia parcial coloca-se como tratamento preferencial no tratamento da doença localizada. Ressalvadas as limitações da evidência disponível, há aparente benefício desta técnica em termos de sobrevida global (SG), sobrevida específica (sem morte pelo CCR) e preservação da função renal<sup>67–70</sup> . Esta vantagem independe do tamanho da lesão e mesmo em tumores maiores que sete centímetros, restritos ao rim, a nefrectomia parcial pode ser proposta, desde que tecnicamente possível e que haja uma adequada seleção do caso, visto que em casos de tumor pT2 há maior chance de complicações peri-operatórias<sup>60,77</sup> . Em caso de pacientes com rim único, múltiplos tumores ou função renal limítrofe, a nefrectomia parcial deve ser preferida.  
A nefrectomia radical deve ser reservada para os casos em que a localização tumoral e as condições locais impeçam a realização de procedimento cirúrgico poupador de néfrons com segurança, bem como quando há acometimento da veia cava ou da adrenal ou possibilidade de linfonodomegalia retroperitoneal.  
Da mesma maneira que a comparação entre as nefrectomias parcial e radical, a qualidade da evidência relativa ao tipo de técnica empregada é limitada. Não há diferença em desfechos oncológicos na abordagem por via aberta, laparoscópica ou robótica, sendo que as abordagens minimamente invasivas, laparoscópica e robótica, são cada vez mais difundidas e popularizadas e apresentam melhores desfechos peri-operatórios<sup>78,79</sup> . Mais recentemente, Choi et al. publicaram meta-análise de estudos observacionais, em que a nefrectomia parcial robótica apresentou melhores desfechos perioperatórios em relação à nefrectomia parcial laparoscópica<sup>80</sup> .  
Como já mencionado, terapias ablativas podem ser oferecidas para pacientes idosos ou com comorbidade relevante, como alternativa ao tratamento cirúrgico em caso de lesões tumorais menores que três centímetros. O tratamento pode ser realizado por crioterapia ou ablação por radiofrequência, por via percutânea ou laparoscópica. Estas técnicas apresentam maior taxa de recidiva e podem resultar em múltiplas intervenções para atingir resultados equivalentes aos da nefrectomia parcial em tumores T1; portanto, a sua indicação deve ser judiciosa e o paciente deve ser bem-informado dos riscos e benefícios do procedimento proposto<sup>81–83</sup> .  
O benefício prognóstico e terapêutico da linfadenectomia em caso de neoplasia renal ainda é incerto<sup>84</sup> . A linfadenectomia deve ser realizada em caso de maior risco de acometimento extra-renal ou quando são identificados linfonodos peri-hilares ou retroperitoneais aumentados, em exames de imagem pré-operatórios ou durante a intervenção cirúrgica. Inexiste benefício estabelecido em se proceder à linfadenectomia peri-hilar, quando os linfonodos desta região são de aspecto normal<sup>84–86</sup> .  
Sempre que possível, a adrenalectomia ipsilateral deve ser evitada quando da realização de nefrectomia radical, exceto em casos de tumor de grande volume localizado no polo superior ou quando há acometimento da adrenal na avaliação de imagem pré-operatória<sup>87</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.1.2. Vigilância ativa** -->
Em caso de doença localizada, por vigilância ativa entende-se postergar o tratamento definitivo do tumor, optandose pela monitorização da lesão renal por meio de exames de imagem seriados. Esta estratégia é apropriada para casos de tumor T1a, em especial lesões menores de dois centímetros ou em pacientes idosos, com múltiplas comorbidades e baixa expectativa de vida, em que o risco de progressão da doença é pequeno e não justifica o benefício da intervenção. Os protocolos são variados e sugerem seguimento periódico (semestral) com exame de imagem (TC ou RM) com intervenção caso se observe o crescimento da lesão tumoral, seja pela velocidade de crescimento linear ou pelo aumento do diâmetro total<sup>72,73,75</sup> . No **Quadro 3** estão descritos os fatores que devem ser considerados na observação com vigilância ativa em caso de câncer renal localizado.  
**Quadro 3** - <mark>Fatores que devem ser considerados na observação com vigilância ativa em caso de câncer renal localizado.</mark>  
|**Fatores do paciente**|**Fatores tumorais**|
|---|---|
|Paciente idoso|Tumor  menor que3 cm|
|Expectativa de vida menor que 5 anos|Crescimento tumoral menor que 5mm ao ano.|
|Comorbidades graves|Tumor não infiltrativo, localizado.|
|Risco perioperatório alto|Baixa|
|Status funcional ruim|Histologia favorável|
|Função renal marginal||
|Paciente não aceita os riscos inerentes ao procediemento<br>cirúrgico||  
Fonte: Galvão et al, 2018<sup>71</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.2.1. Tratamento cirúrgico - Nefrectomia citorredutora** -->
A nefrectomia citorredutora é uma importante opção de tratamento para casos de CCR, embora estudos recentes tenham sugerido que a seleção de pacientes é crítica, pois aqueles com doença de baixo risco são menos propensos a se beneficiar do tratamento cirúrgico<sup>88–90</sup> . Vários pequenos estudos contemporâneos têm examinado os desfechos oncológicos da nefrectomia citorredutora em casos de CCR metastático, mas com resultados conflitantes<sup>88–90</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.2.2. Radioterapia externa** -->
A radioterapia externa pode ser empregada para controle de sintomas locais, como dor e sangramento tumoral, e na paliação de metástases óssea ou cerebral<sup>63,91</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.2.3. Vigilância ativa** -->
Em caso de doença avançada, a vigilância ativa implica o monitoramento do crescimento tumoral por meio de exames de imagem. Os critérios de progressão utilizados para uma intervenção cirúrgica são: duplicação do volume tumoral em menos de 12 meses; crescimento maior que 0,5 cm/ano; aparecimento de manifestações clínicas relacionadas ao tumor; diâmetro tumoral que alcança valores iguais ou maiores que 4 cm<sup>72,73,75</sup> . O seguimento desses tumores deve ser individualizado, sendo usual o controle por TC ou RM a cada 4 a 6 meses nos primeiros 3 anos e, a seguir, anualmente. Pacientes julgados aptos para a vigilância ativa devem ser informados que, apesar de baixo, existe um risco real de  
progressão tumoral e perda da oportunidade terapêutica cirúrgica, bem como da ineficácia dos tratamentos sistêmicos. Admite-se que 20% a 25% das pequenas massas renais apresentam características agressivas, com uma taxa de 15% a 25% de grau de Furhman III e IV, taxa de progressão para estádio pT3 em 10% a 40% e taxa de metástase próxima a 10%<sup>72,73,75</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **6.2.4. Quimioterapia** -->
Como na maioria das vezes a doença metastática é considerada incurável, benefícios potenciais da quimioterapia sistêmica com diversos medicamentos devem ser pesados em relação à toxicidade de citocinas e citotóxicos<sup>43,92</sup> e aos custos. Uma parcela de pacientes pode apresentar doença metastática de baixo volume e de crescimento lento, sendo potencialmente candidatos à vigilância ativa até a efetiva progressão da doença antes de se iniciar qualquer tratamento. No entanto, os pacientes que têm doença mais agressiva necessitam de tratamento sistêmico com início imediato. Não há indicação clínica de tratamento sistêmico com finalidade adjuvante, quando houver a remoção completa das lesões clínicas (ressecção cirúrgica R0)<sup>93</sup> .  
O uso de interferona (IFN) e interleucina 2 (IL-2) constituiu o tratamento padrão, de primeira linha de pacientes com câncer renal metastático até o desenvolvimento dos ditos alvoterápicos<sup>94</sup> . A IFN e a IL-2 são citocinas inespecíficas, com uma ação presumida de estimulação de resposta imunitária antitumoral. Seus benefícios foram demonstrados em vários estudos clínicos, sendo modestos em relação à taxa de resposta (5% a 20%), sobrevida livre de progressão (SLP) e SG (mediana de aproximadamente 12 meses)<sup>95–99</sup> . Como a eficácia é modesta e a toxicidade alta, a busca por novos tratamentos ou combinações foi necessária.  
O sunitinibe, pazopanibe e sorafenibe foram os primeiros agentes antiangiogênicos aprovados no Brasil para o tratamento de pacientes com CCR metastático, os quais podem receber tratamento sistêmico de primeira linha com diferentes opções terapêuticas<sup>43,100</sup> , sendo os medicamentos sunitinibe e pazopanibe os atualmente mais utilizados<sup>91,101</sup> . A recomendação da incorporação do cloridrato de pazopanibe e do malato de sunitinibe para carcinoma renal de células claras metastático ocorreu à 72ª Reunião Ordinária do Plenário da Conitec, conforme modelo da Assistência Oncológica adotado no SUS<sup>101</sup> .  
O perfil de toxicidade e segurança da quimioterapia com citocinas e citotóxicos, em uso isolado ou em associações, é bastante conhecido pelo longo tempo em uso na medicina<sup>102</sup> . Durante o uso da interferona, quase todos os pacientes experimentam, pelo menos, um evento adverso, na maioria das vezes de intensidade leve a moderada e que diminui de intensidade com o uso contínuo, mas a suspensão do tratamento devido aos efeitos colaterais pode ser necessária em até 24% dos casos<sup>102,103</sup> . Sintomas gripais são os efeitos colaterais mais comuns (febre, calafrios, fadiga, dor de cabeça, artralgia e mialgia), e outros sintomas podem incluir fadiga persistente durante todo o tratamento, tontura, depressão, hipotensão arterial e alterações oculares (retinopatia, hemorragia da retina, obstrução arterial ou obstrução venosa retiniana)<sup>104,105</sup> . O uso de interleucina-2 está associado à ocorrência de síndrome do extravasamento capilar, que tipicamente começa logo após o início do tratamento, e é caracterizada por perda de tônus vascular e extravasamento de proteínas do plasma e fluido para dentro do espaço extravascular, resultando em hipotensão e má perfusão dos órgãos internos, condições que podem resultar em eventos adversos potencialmente fatais: arritmias cardíacas (supraventriculares e ventriculares), angina, infarto do miocárdio, insuficiência respiratória que exige ventilação mecânica, hemorragia ou infarto gastrointestinal, insuficiência renal, anasarca e alterações do estado mental<sup>106,107</sup> .  
Os medicamentos antiangiogênicos estão relacionados a risco aumentado de eventos adversos gastrintestinais (mucosite, diarreia, vômito)<sup>108,109</sup> , cardiovasculares (hipertensão arterial, trombose arterial, isquemia cardíaca, insuficiência cardíaca) e insuficiência renal<sup>110</sup> , citopênicos (anemia, neutropenia e trombocitopenia)<sup>111,112</sup> , sangramento<sup>113</sup> , síndrome pé-  
mão<sup>114</sup> , hepáticos<sup>115</sup> e morte<sup>116</sup> . Por sua vez, os inibidores da via de sinalização da proteína _mammalian target of rapamycin_ (mTOR) associam-se a maior risco de infecções, toxicidade pulmonar e morte<sup>117–119</sup> .  
Embora inexista evidência conclusiva de que o tratamento resulte na diminuição de sintomas, pacientes com carcinoma de células claras metastático refratário ao tratamento inicial, que mantenham boa capacidade funcional (escore de Karnofsky acima de 80%) e funções renal e hepática normais podem ser candidatos à quimioterapia com medicamento da mesma classe, em se tratando de antiangiogênicos, ou de outra classe terapêutica, até nova progressão da doença<sup>120</sup> .  
O medicamento pembrolizumabe associado a axitinibe e ipilimumabe associado a nivolumabe e cabozantinibe em monoterapia têm sido utilizados como tratamentos de primeira linha de carcinoma de células renais<sup>121</sup> . Conforme o Relatório de Recomendação nº 660, de agosto de 2021, referente à avaliação dessas tecnologias, os resultados mostraram que, em pacientes de baixo risco, as associações não apresentaram benefício adicional quando comparados com sunitinibe para nenhum dos desfechos avaliados (SG, SLP e taxa de resposta objetiva)<sup>122</sup> . Já para os pacientes classificados com risco intermediário ou alto, as associações são superiores ao sunitinibe em todos os desfechos. Dados de análises indiretas mostram que o pembrolizumabe/axitinibe tem maior probabilidade/SUCRA ( _surface under the cumulative ranking curve_ ) de ser a melhor opção de tratamento para o desfecho de SG e SLP. Entretanto, esses dados devem ser interpretados com cautela, pois as meta-análises em rede apontam estudos com qualidade da evidência muito baixa e moderada, com importantes incertezas, especialmente por incluírem uma população heterogênea, diferentes números de participantes e esquemas de tratamentos entre as tecnologias avaliada. Além disso, a análise econômica realizada pela Conitec demonstrou razão de custo-efetividade incremental (RCEI) e impacto orçamentário elevados<sup>123</sup> . Desta forma, estes medicamentos tiveram decisão desfavorável a incorporação no SUS.  
Já para tratamento de segunda linha, atualmente, diferentes medicamentos são indicados na literatura para pacientes com CCRm, incluindo o cabozantinibe e o nivolumabe. O Relatório de Recomendação nº 661 da Conitec<sup>123</sup> mostrou que o cabozantinibe proporciona a melhor efetividade, considerando-se os desfechos de anos de vida e anos de vida ajustados por qualidade (QALY), quando comparado ao everolimo, resultando 2,29 anos de vida e 1,48 QALY ganhos. Em relação ao nivolumabe, os resultados mostraram que há uma melhor efetividade, considerando-se os desfechos de anos de vida e QALYs, quando comparado ao everolimo, resultando 2,20 anos de vida e 1,39 QALY ganhos. Quanto à ocorrência de eventos adversos, eventos adversos graves e suspensão do tratamento devido a eventos adversos, não foram verificadas diferenças significativas entre esses tratamentos e os demais medicamentos e o placebo. Contudo, estes resultados são fundamentados em uma meta-análise em rede com estudos com qualidade de evidência classificada como muito baixa e moderada. Igualmente, os custos de tratamento do cabozantinibe e do nivolumabe são superiores, aos tratamentos já disponibilizados, resultando em RCEI e impacto orçamentário elevados para o SUS<sup>123</sup> . Com base nesses achados, a Conitec recomendou a não incorporação desses medicamentos para o tratamento de primeira e segunda linha do CCRm<sup>121,123</sup>  
Pacientes com prognóstico favorável ou intermediário, sem metástase cerebral, sem episódio cardiovascular recente e com capacidade funcional adequada (de 0 a 2 na escala do ECOG) são candidatos à quimioterapia com citocinas (interferona-alfa, interleucina-2), citotóxico (5-fluoruracila, capecitabina, doxorrubicina, gencitabina, vimblastina), antiangiogênicos (sunitinibe, sorafenibe, pazopanibe, bevacizumabe) ou inibidores da via de sinalização da proteína _mammalian target of rapamycin_ (mTOR) – everolimo, tensirolimo<sup>103–107,124</sup> .  
O CCR metastático irressecável é incurável e um dos tumores sólidos mais resistentes à quimioterapia<sup>125</sup> . Inexistem estudos comparativos diretos que permitam asseverar em definitivo a eficácia de cada um dos medicamentos disponíveis, havendo apenas a indicação de maior resultado terapêutico para os antiangiogênicos ou inibidores mTOR frente ao uso de  
placebo ou interferona<sup>126–130</sup> - a um custo elevado para os sistemas de saúde<sup>131,132</sup> - e para a quimioterapia citotóxica no câncer renal com diferenciação sarcomatoide<sup>133</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **7. MONITORAMENTO** -->
O monitoramento após o tratamento cirúrgico do carcinoma de células renais permite identificar complicações pósoperatórias, acompanhar a função renal e identificar recorrências locais e no rim contralateral e a ocorrência de metástases. Após a ressecção cirúrgica, 20% a 30% dos pacientes com tumores localizados apresentam recidiva. O pulmão é o sítio mais comum de recidiva à distância, ocorrendo em 50% a 60% dos casos que evoluem para doença metastática. O tempo mediano para recidiva após o procedimento cirúrgico é um a dois anos, com a maioria das recidivas ocorrendo nos primeiros três anos<sup>134</sup> . Apesar disso, observam-se recidivas esporádicas após cinco anos do tratamento cirúrgico<sup>135,136</sup> .  
Inexiste consenso sobre o monitoramento após o tratamento do câncer de células renais. Vigilância radiológica intensiva não é necessária para todos os casos<sup>137</sup> . É necessário, portanto, estratificar o risco do caso para adequar o acompanhamento. Um protocolo de vigilância estruturada, que permite identificar recorrência e o desenvolvimento de metástase de maneira mais oportuna, quando o volume tumoral é pequeno e o caso em algumas situações possivelmente ainda curável, está associado à maior sobrevida global<sup>138</sup> . O tempo de seguimento geralmente recomendado é 3 a 5 anos, sendo que o monitoramento posterior a 5 anos deve ser criteriosamente estabelecido<sup>139–141</sup> .  
Para pacientes submetidos a tratamentos ablativos, o monitoramento deve ser inicialmente mais frequente, pois o risco de recorrência local é cinco a vinte vezes maior do que quando é realizada nefrectomia parcial<sup>142,143</sup> . Uma conduta que pode ser adotada é a avaliação com exames de imagem (TC ou RM de abdome, com ou sem contraste), mais frequentemente no primeiro ano (a cada três a seis meses) e, após, anualmente por cinco anos.  
A maneira mais adequada para se definir o perfil de risco dos pacientes e, assim, adequar o cronograma de monitoramento é a utilização de nomogramas ou sistemas de estratificação de risco, como o UCLA _Integrated Staging System_ (UISS) e o escore SSIGN<sup>144–145</sup> .  
Para o monitoramento de pacientes submetidos à radioterapia e à quimioterapia, adotam-se os respectivos cuidados e condutas institucionais estabelecidas.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **8. REGULAÇÃO, CONTROLE E AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes nestas DDT, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Casos de CCR devem ser atendidos em hospitais habilitados em oncologia e com porte tecnológico suficiente para diagnosticar, estadiar, tratar e acompanhar os pacientes. Além da familiaridade que tais hospitais guardam com o estadiamento, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e a garantia do atendimento das pacientes, e muito facilita as ações de controle e avaliação. Entre tais ações incluem-se a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES), a autorização prévia dos procedimentos, o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos) e a verificação dos percentuais da frequência dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda e segunda maior do  
que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou do protocolo adotados no hospital, a regulação do acesso assistencial, a qualidade da autorização, a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses), a compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod), a compatibilidade da cobrança com os serviços executados, a abrangência e a integralidade assistenciais e o grau de satisfação dos doentes.  
O Ministério da Saúde e as Secretarias de Saúde não padronizam nem fornecem medicamentos antineoplásicos diretamente aos hospitais ou aos usuários do SUS. A exceção é feita ao mesilato de imatinibe para a quimioterapia do tumor do estroma gastrointestinal (GIST), da leucemia mieloide crônica e da leucemia linfoblástica aguda cromossoma Philadelphia positivo; do nilotinibe e do dasatinibe para a quimioterapia da leucemia mieloide crônica; do rituximabe para a poliquimioterapia do linfoma folifcular e do linfoma difuso de grandes células B; e dos trastuzumabe e pertuzumabe para a quimioterapia do carcinoma de mama, que são adquiridos pelo Ministério da Saúde e fornecidos aos hospitais habilitados em oncologia no SUS, por meio das secretarias estaduais de saúde.Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais as terapias antineoplásicas medicamentosas são indicadas. Ou seja, os hospitais credenciados pelo SUS e habilitados em oncologia são os responsáveis pelo fornecimento de medicamentos oncológicos que eles, livremente, padronizam, adquirem e fornecem, cabendo-lhes codificar e registrar conforme o respectivo procedimento. Assim, a partir do momento em que um hospital é habilitado para prestar assistência oncológica pelo SUS, a responsabilidade pelo fornecimento de medicamento antineoplásico é do hospital, seja ele público ou privado, com ou sem fins lucrativos.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Relativamente ao sítio primário ou secundário, os procedimentos cirúrgicos da tabela do SUS aplicáveis a pacientes com diagnóstico de carcinoma de células renais encontram-se no Grupo 04 e podem ser acessados por código ou nome do procedimento e por código da CID-10.  
Os procedimentos radioterápicos da tabela do SUS aplicáveis a pacientes com diagnóstico de carcinoma de células renais são os seguintes:  
03.04.01.011-1 - Internação p/ radioterapia externa (cobaltoterapia/acelerador linear) 03.04.01.047-2 - Radioterapia do aparelho urinário 03.04.01.052-9 - Radioterapia de metástase em sistema nervoso central 03.04.01.053-7 - Radioterapia de plasmocitoma / mieloma / metástases em outras localizações O procedimento da tabela do SUS para a quimioterapia de carcinoma de células renais é o seguinte: _Quimioterapia paliativa – adulto_  
03.04.02.016-8 - Quimioterapia do carcinoma de rim avançado  
**9. REFERÊNCIAS**  
1. American Cancer Society (ACS). Kidney Cancer (Adult) - Renal Cell Carcinoma. [Internet]. Available from: https://www.cancer.org/cancer/kidney-cancer.html  
2. Escudier B, Porta C, Schmidinger M, Algaba F, Patard JJ, Khoo V, et al. Renal cell carcinoma: ESMO clinical practice guidelines for diagnosis, treatment and follow-up. Ann Oncol. 2014;  
3. Muglia VF, Prando A. Carcinoma de células renais: Classificação histológica e correlação com métodos de imagem. Radiol Bras. 2015;  
4. Warren AY, Harrison D. WHO/ISUP classification, grading and pathological staging of renal cell carcinoma: standards and controversies. World J Urol. 2018;  
5. Bray F, Ferlay J, Soerjomataram I, Siegel RL, Torre LA, Jemal A. Global cancer statistics 2018: GLOBOCAN estimates of incidence and mortality worldwide for 36 cancers in 185 countries. CA Cancer J Clin. 2018;  
6. WHO. Estimated number of new cases in 2018, worldwide, both sexes, all ages. Int Agency Res Cancer. 2018;  
7. Brasil. Instituto Nacional de Câncer. IN: CARCINOMA DE CÉLULAS RENAIS EM NÚMEROS. [Internet]. BristolMyers Squibb. [cited 2021 Sep 8]. Available from: https://www.bms.com/assets/bms/brazil/documents/Infográfico Câncer Renal.pdf.  
8. Capitanio U, Bensalah K, Bex A, Boorjian SA, Bray F, Coleman J, et al. Epidemiology of Renal Cell Carcinoma [Figure presented]. European Urology. 2019.  
9. Kushi LH, Doyle C, McCullough M, Rock CL, Demark-Wahnefried W, Bandera E V., et al. American Cancer Society guidelines on nutrition and physical activity for cancer prevention: Reducing the Risk of Cancer with Healthy Food Choices and Physical Activity. CA Cancer J Clin. 2012;  
10. Usher-Smith J, Simmons RK, Rossi SH, Stewart GD. Current evidence on screening for renal cancer. Nat Rev Urol. 2020;17(11):637–42.  
11. Krogsbøll LT, Jørgensen KJ, Gøtzsche PC. Screening with urinary dipsticks for reducing morbidity and mortality. Cochrane Database of Systematic Reviews. 2015.  
12. Morrissey JJ, London AN, Luo J, Kharasch ED. Urinary biomarkers for the early diagnosis of kidney cancer. Mayo Clin Proc. 2010;  
13. Diana P, Klatte T, Amparore D, Bertolo R, Carbonara U, Erdem S, et al. Screening programs for renal cell carcinoma: a systematic review by the EAU young academic urologists renal cancer working group. World J Urol [Internet]. 2022;(0123456789). Available from: https://doi.org/10.1007/s00345-022-03993-6  
14. Vogelzang NJ, Stadler WM. Kidney cancer. Lancet. 1998.  
15. Gray RE, Harris GT. Renal cell carcinoma: Diagnosis and management. Am Fam Physician. 2019;  
16. Perez Valdivieso JR, Bes-Rastrollo M, Monedero P, De Irala J, Javier Lavilla F. Karnofsky performance score in acute renal failure as a predictor of short-term survival. Nephrology. 2007;  
17. Schag CC, Heinrich RL, Ganz PA. Karnofsky performance status revisited: reliability, validity, and guidelines. J Clin Oncol. 1984 Mar;2(3):187–93.  
18. Azam F, Latif MF, Farooq A, Tirmazy SH, Alshahrani S, Bashir S, et al. Performance Status Assessment by Using ECOG (Eastern Cooperative Oncology Group) Score for Cancer Patients by Oncology Healthcare Professionals. Case Rep Oncol. 2019;  
19. Chen L, Li H, Gu L, Ma X, Li X, Gao Y, et al. The impact of diabetes mellitus on renal cell carcinoma prognosis: A meta-analysis of cohort studies. Med (United States). 2015;  
20. Kim HL, Belldegrun AS, Freitas DG, Bui MHT, Han KR, Dorey FJ, et al. Paraneoplastic signs and symptoms of renal cell carcinoma: Implications for prognosis. J Urol. 2003;  
21. Jayson M, Sanders H. Increased incidence of serendipitously discovered renal cell carcinoma. Urology. 1998;  
22. Patard JJ, Leray E, Rodriguez A, Rioux-Leclercq N, Guillé F, Lobel B. Correlation between symptom graduation, tumor characteristics and survival in renal cell carcinoma. Eur Urol. 2003;  
23. Lin S, Zheng Y, Qin Z, Hu X, Qi F, Yin R, et al. Surgical intervention in renal cell carcinoma patients with lung and bronchus metastasis is associated with longer survival time: a population-based analysis. Ann Transl Med. 2019;  
24. Ljungberg B, Alamdari FI, Rasmuson T, Roos G. Follow-up guidelines for nonmetastatic renal cell carcinoma based on the occurrence of metastases after radical nephrectomy. BJU Int. 1999;84(4):405–11.  
25. Grünwald V, Eberhardt B, Bex A, Flörcken A, Gauler T, Derlin T, et al. An interdisciplinary consensus on the management of bone metastases from renal cell carcinoma. Nature Reviews Urology. 2018.  
26. Abdel-Rahman O. Clinical correlates and prognostic value of different metastatic sites in metastatic renal cell carcinoma. Futur Oncol. 2017;  
27. Sacco E, Pinto F, Sasso F, Racioppi M, Gulino G, Volpe A, et al. Paraneoplastic syndromes in patients with urological malignancies. Urologia Internationalis. 2009.  
28. Ikuerowo S, Ojewuyi O, Omisanjo O, Abolarinwa A, Bioku M, Doherty A. Paraneoplastic syndromes and oncological outcomes in renal cancer. Niger J Clin Pract. 2019;  
29. Chuang YC, Lin ATL, Chen KK, Chang YH, Chen MT, Chang LS. Paraneoplastic elevation of serum alkaline phosphatase in renal cell carcinoma: Incidence and implication on prognosis. J Urol. 1997;158(5):1684–7.  
30. Gold PJ, Fefer A TJSUO 1996 N-22. P 8946620. Paraneoplastic manifestations of renal cell carcinoma. Urol Oncol. 1996;14(4).  
31. Gill IS, Aron M, Gervais DA, Jewett MAS. Clinical practice. Small renal mass. N Engl J Med. 2010;  
32. Silverman SG, Israel GM, Trinh QD. Incompletely characterized incidental renal masses: Emerging data support conservative management. Radiology. 2015.  
33. Hélénon O, Delavaud C, Dbjay J, Gregory J, Rasouli N, Correas JM. A Practical Approach to Indeterminate and Cystic Renal Masses. Semin Ultrasound, CT MRI. 2017;  
34. Flum AS, Hamoui N, Said MA, Yang XJ, Casalino DD, McGuire BB, et al. Update on the Diagnosis and Management of Renal Angiomyolipoma. Journal of Urology. 2016.  
35. Curry NS. Small renal masses (lesions smaller than 3 cm): Imaging evaluation and management. American Journal of Roentgenology. 1995.  
36. Israel GM, Bosniak MA. An update of the Bosniak renal cyst classification system. Urology. 2005;  
37. Miranda CMNR de, Maranhão CP de M, Santos CJJ dos, Padilha IG, Farias L de PG de, Rocha MS da. Bosniak classification of renal cystic lesions according to multidetector computed tomography findings. Radiol Bras. 2014;  
38. Silverman SG, Pedrosa I, Ellis JH, Hindman NM, Schieda N, Smith AD, et al. Bosniak classification of cystic renal masses, version 2019: An update proposal and needs assessment. Radiology. 2019;  
39. Defortescu G, Cornu JN, Béjar S, Giwerc A, Gobet F, Werquin C, et al. Diagnostic performance of contrast-enhanced ultrasonography and magnetic resonance imaging for the assessment of complex renal cysts: A prospective study. Int J Urol. 2017;  
40. Israel GM, Bosniak MA. How I do it: Evaluating renal masses. Radiology. 2005.  
41. Kutikov A, Fossett LK, Ramchandani P, Tomaszewski JE, Siegelman ES, Banner MP, et al. Incidence of benign  
pathologic findings at partial nephrectomy for solitary renal mass presumed to be renal cell carcinoma on preoperative imaging. Urology. 2006;  
42. Li G, Cuilleron M, Gentil-Perret A, Tostain J. Characteristics of image-detected solid renal masses: Implication, for optimal treatment. International Journal of Urology. 2004.  
43. McKiernan J, Yossepowitch O, Kattan MW, Simmons R, Motzer RJ, Reuter VE, et al. Partial nephrectomy for renal cortical tumors: Pathologic findings and impact on outcome. Urology. 2002;  
44. Ferda J, Hora M, Hes O, Ferdová E, Kreuzberg B. Assessment of the kidney tumor vascular supply by two-phase MDCT-angiography. Eur J Radiol. 2007;  
45. Mueller-Lisse UG, Mueller-Lisse UL. Imaging of advanced renal cell carcinoma. World J Urol. 2010;  
46. Johns Putra LG, Minor TX, Bolton DM, Appu S, Dowling CR, Neerhut GJ. Improved Assessment of Renal Lesions in Pregnancy With Magnetic Resonance Imaging. Urology. 2009;  
47. Giannarini G, Petralia G, Thoeny HC. Potential and limitations of diffusion-weighted magnetic resonance imaging in kidney, prostate, and bladder cancer including pelvic lymph node staging: A critical analysis of the literature. European Urology. 2012.  
48. Vogel C, Ziegelmüller B, Ljungberg B, Bensalah K, Bex A, Canfield S, et al. Imaging in Suspected Renal-Cell Carcinoma: Systematic Review. Clin Genitourin Cancer. 2019;  
49. Uzzo RG, Novick AC. Nephron sparing surgery for renal tumors: Indications, techniques and outcomes. Journal of Urology. 2001.  
50. Huang WC, Levey AS, Serio AM, Snyder M, Vickers AJ, Raj G V., et al. Chronic kidney disease after nephrectomy in patients with renal cortical tumours: a retrospective cohort study. Lancet Oncol. 2006;  
51. Lim DJ, Carter MF. Computerized tomography in the preoperative staging for pulmonary metastases in patients with renal cell carcinoma. J Urol. 1993;  
52. Heidenreich A, Ravery V. Preoperative imaging in renal cell cancer. World J Urol. 2004;  
53. Sheth S, Scatarige JC, Horton KM, Corl FM, Fishman EK. Current concepts in the diagnosis and management of renal cell carcinoma: Role of multidetector CT and three-dimensional CT. Radiographics. 2001;  
54. Mano R, Vertosick E, Sankin AI, Chevinsky MS, Larish Y, Jakubowski CD, et al. Subcentimeter pulmonary nodules are not associated with disease progression in patients with renal cell carcinoma. J Urol. 2015;  
55. Seaman E, Goluboff ET, Ross S, Sawczuk IS. Association of radionuclide bone scan and serum alkaline phosphatase in patients with metastatic renal cell carcinoma. Urology. 1996;  
56. WHO. World Health Organization. on Cancer IAFR, Others. WHO classification of tumours of the urinary system and male genital organs (IARC WHO classification of tumours). 4th ed. IARC Press, Lyon; 2016.  
57. Volpe A, Jewett MAS. Current role, techniques and outcomes of percutaneous biopsy of renal tumors. Expert Review of Anticancer Therapy. 2009.  
58. Sanchez A, Feldman AS, Ari Hakimi A. Current management of small renal masses, including patient selection, renal tumor biopsy, active surveillance, and thermal ablation. Journal of Clinical Oncology. 2018.  
59. Brierley JD, Gospodarowicz, Mary K. Wittekind C. TNM Classification of Malignant Tumours, 8th Edition. 2017.  
60. Mir MC, Derweesh I, Porpiglia F, Zargar H, Mottrie A, Autorino R. Partial Nephrectomy Versus Radical Nephrectomy for Clinical T1b and T2 Renal Tumors: A Systematic Review and Meta-analysis of Comparative Studies. European Urology. 2017.  
61. Delahunt B, Cheville JC, Martignoni G, Humphrey PA, Magi-Galluzzi C, McKenney J, et al. The International Society  
of Urological Pathology (ISUP) grading system for renal cell carcinoma and other prognostic parameters. Am J Surg Pathol. 2013;  
62. Brasil. Ministério da Saúde. Secretaria da Atenção à Saúde. Portaria n<sup>o</sup> 1.440, de 16 de dezembro de 2014. Diretrizes Diagnósticas e Terapêuticas do Carcinoma de Células Renais. Brasília: Ministério da Saúde, 2014.  
63. Sociedade Brasileira de Oncologia Clínica (SBOC). Diretrizes de tratamentos oncológicos recomendados pela Sociedade Brasileira de Oncologia Clínica: Bexiga. 2020;19.  
64. Impacto da revisão do grau histológico em carcinoma de células renais tipo células claras numa coorte - LARCG (Latin American Renal Cancer Group). [Internet]. [cited 2021 Sep 14]. Available from: http://www.iccrcancer.org/getattachment/Datasets-Em-Portugues/Urinary-Male-Genital/Invasive-Carcinoma-of-Renal-TubularOrigin/ICCR-Kidney-nephrectomy-1st-edn-v1-1-bookmark-PT.pdf  
65. Ko JJ, Xie W, Kroeger N, Lee J lyun, Rini BI, Knox JJ, et al. The international metastatic renal cell carcinoma database consortium model as a prognostic tool in patients with metastatic renal cell carcinoma previously treated with first-line targeted therapy: A population-based study. Lancet Oncol. 2015;  
66. Heng DYC, Xie W, Regan MM, Harshman LC, Bjarnason GA, Vaishampayan UN, et al. External validation and comparison with other models of the International Metastatic Renal-Cell Carcinoma Database Consortium prognostic model: A population-based study. Lancet Oncol. 2013;14(2):141–8.  
67. Kunath F, Schmidt S, Krabbe LM, Miernik A, Dahm P, Cleves A, et al. Partial nephrectomy versus radical nephrectomy for clinical localised renal masses. Cochrane Database of Systematic Reviews. 2017.  
68. Van Poppel H, Da Pozzo L, Albrecht W, Matveev V, Bono A, Borkowski A, et al. A prospective, randomised EORTC intergroup phase 3 study comparing the oncologic outcome of elective nephron-sparing surgery and radical nephrectomy for low-stage renal cell carcinoma. Eur Urol. 2011;  
69. Pierorazio PM, Johnson MH, Ball MW, Gorin MA, Trock BJ, Chang P, et al. Five-year Analysis of a Multiinstitutional Prospective Clinical Trial of Delayed Intervention and Surveillance for Small Renal Masses: The DISSRM Registry. Eur Urol. 2015;  
70. MacLennan S, Imamura M, Lapitan MC, Omar MI, Lam TBL, Hilvano-Cabungcal AM, et al. Systematic review of perioperative and quality-of-life outcomes following surgical management of localised renal cancer. European Urology. 2012.  
71. Galvão A, Castro E. TRATAMENTO DO CÂNCER RENAL LOCALIZADO – PROTOCOLO INSTITUCIONAL DO HOSPITAL DAS CLÍNICAS DA UFMG. Urominas- Soc Bras Urol. 2018;  
72. Rais-Bahrami S, Guzzo TJ, Jarrett TW, Kavoussi LR, Allaf ME. Incidentally discovered renal masses: Oncological and perioperative outcomes in patients with delayed surgical intervention. BJU Int. 2009;  
73. McIntosh A, Lee T, Greenberg R, Chen DY, Viterbo R, Smaldone M, et al. PD51-04 ACTIVE SURVEILLANCE FOR LOCALIZED RENAL MASSES: GROWTH RATES AND OUTCOMES IN PATIENTS WITH MASSES ≥4 CM. J Urol. 2018;  
74. American Cancer Society (ACS). Kidney cancer treatment. [Internet]. Available from: https://www.cancer.org/cancer/kidney-cancer/treating/ablation.html  
75. Pierorazio PM, Johnson MH, Patel HD, Sozio SM, Sharma R, Iyoha E, et al. Management of Renal Masses and Localized Renal Cancer: Systematic Review and Meta-Analysis. Journal of Urology. 2016.  
76. Filippiadis D, Mauri G, Marra P, Charalampopoulos G, Gennaro N, De Cobelli F. Percutaneous ablation techniques for renal cell carcinoma: current status and future  trends. Int J Hyperth  Off J Eur Soc  Hyperthermic Oncol North Am  
Hyperth Gr. 2019 Oct;36(2):21–30.  
77. Li J, Zhang Y, Teng Z, Han Z. Partial nephrectomy versus radical nephrectomy for cT2 or greater renal tumors: A systematic review and meta-analysis. Minerva Urologica e Nefrologica. 2019.  
78. Lane BR, Gill IS. 7-Year Oncological Outcomes After Laparoscopic and Open Partial Nephrectomy. J Urol. 2010;  
79. Wu Z, Li M, Liu B, Cai C, Ye H, Lv C, et al. Robotic versus open partial nephrectomy: A systematic review and metaanalysis. PLoS ONE. 2014.  
80. Choi JE, You JH, Kim DK, Rha KH, Lee SH. Comparison of perioperative outcomes between robotic and laparoscopic partial nephrectomy: A systematic review and meta-analysis. European Urology. 2015.  
81. Hu X, Shao YX, Wang Y, Yang ZQ, Yang WX, Li X. Partial nephrectomy versus ablative therapies for cT1a renal masses: A Systematic Review and meta-analysis. European Journal of Surgical Oncology. 2019.  
82. Rivero JR, De La Cerda J, Wang H, Liss MA, Farrell AM, Rodriguez R, et al. Partial Nephrectomy versus Thermal Ablation for Clinical Stage T1 Renal Masses: Systematic Review and Meta-Analysis of More than 3,900 Patients. Journal of Vascular and Interventional Radiology. 2018.  
83. Abu-Ghanem Y, Fernández-Pello S, Bex A, Ljungberg B, Albiges L, Dabestani S, et al. Limitations of Available Studies Prevent Reliable Comparison Between Tumour Ablation and Partial Nephrectomy for Patients with Localised Renal Masses: A Systematic Review from the European Association of Urology Renal Cell Cancer Guideline Panel. Eur Urol Oncol. 2020;  
84. Bhindi B, Wallis CJD, Boorjian SA, Thompson RH, Farrell A, Kim SP, et al. The role of lymph node dissection in the management of renal cell carcinoma: a systematic review and meta-analysis. BJU International. 2018.  
85. Capitanio U, Becker F, Blute ML, Mulders P, Patard JJ, Russo P, et al. Lymph node dissection in renal cell carcinoma. European Urology. 2011.  
86. Blom JHM, van Poppel H, Maréchal JM, Jacqmin D, Schröder FH, de Prijck L, et al. Radical Nephrectomy with and without Lymph-Node Dissection: Final Results of European Organization for Research and Treatment of Cancer (EORTC) Randomized Phase 3 Trial 30881. Eur Urol. 2009;  
87. O’Malley RL, Godoy G, Kanofsky JA, Taneja SS. The Necessity of Adrenalectomy at the Time of Radical Nephrectomy: A Systematic Review. Journal of Urology. 2009.  
88. Lenis AT, Burton CS, Golla V, Pooli A, Faiena I, Johnson DC, et al. Cytoreductive nephrectomy in patients with metastatic renal cell carcinoma and venous thrombus—Trends and effect on overall survival. Urol Oncol Semin Orig Investig. 2019;  
89. Shinder BM, Rhee K, Farrell D, Farber NJ, Stein MN, Jang TL, et al. Surgical management of advanced and metastatic renal cell carcinoma: A multidisciplinary approach. Frontiers in Oncology. 2017.  
90. Janisch F, Hillemacher T, Fuehner C, D’Andrea D, Meyer CP, Klotzbücher T, et al. The impact of cytoreductive nephrectomy on survival outcomes in patients treated with tyrosine kinase inhibitors for metastatic renal cell carcinoma in a real-world cohort. Urol Oncol Semin Orig Investig. 2020;  
91. Sociedade Brasileira de Oncologia Clínica SBOC. Recomendações para o Tratamento do Câncer Renal. 2017;  
92. Wang R, Wolf JS, Wood DP, Higgins EJ, Hafez KS. Accuracy of Percutaneous Core Biopsy in Management of Small Renal Masses. Urology [Internet]. 2009 Mar [cited 2021 May 31];73(3):586–90. Available from: https://pubmed.ncbi.nlm.nih.gov/19118884/  
93. Scherr AJO, Lima JPSN, Sasse EC, Lima CSP, Sasse AD. Adjuvant therapy for locally advanced renal cell cancer: A systematic review with meta-analysis. BMC Cancer [Internet]. 2011 Mar 31 [cited 2021 May 31];11. Available from:  
https://pubmed.ncbi.nlm.nih.gov/21453469/  
94. Zhang X, Shen Z, Zhong S, Zhu Z, Wang X, Xu T. Comparison of peri-operative outcomes of robot-assisted vs laparoscopic partial nephrectomy: A meta-analysis. BJU Int. 2013;112(8).  
95. Zheng JH, Zhang XL, Geng J, Guo CC, Zhang XP, Che JP, et al. Long-term oncologic outcomes of laparoscopic versus open partial nephrectomy. Chin Med J (Engl). 2013;126(15):2938–42.  
96. Van Poppel H, Joniau S, Goethuys H. Open partial nephrectomy for complex tumours and > 4 cm: Is it still the gold standard technique in the minimally invasive era? Arch Esp Urol. 2013 Jan;66(1):129–38.  
97. Fan X, Xu K, Lin T, Liu H, Yin Z, Dong W, et al. Comparison of transperitoneal and retroperitoneal laparoscopic nephrectomy for renal cell carcinoma: A systematic review and meta-analysis. BJU Int. 2013 Apr;111(4):611–21.  
98. Tait C, Tandon S, Baker L, Goodman C, Townell N, Nabi G. Long-term oncologic outcomes of laparoscopic radical nephrectomy for kidney cancer resection: Dundee cohort and metaanalysis of observational studies. Vol. 25, Surgical Endoscopy. Springer New York LLC; 2011. p. 3154–61.  
99. Asimakopoulos AD, Miano R, Annino F, Micali S, Spera E, Iorio B, et al. Robotic radical nephrectomy for renal cell carcinoma: A systematic review. BMC Urol. 2014 Sep 18;14(1).  
100. Kim SP, Thompson RH, Boorjian SA, Weight CJ, Han LC, Murad MH, et al. Comparative effectiveness for survival and renal function of partial and radical nephrectomy for localized renal tumors: a systematic review and metaanalysis. J Urol [Internet]. 2012 Jul [cited 2021 May 31];188(1):51–7. Available from: http://www.ncbi.nlm.nih.gov/pubmed/22591957  
101. Brasil.Ministério da Saúde. Relatório Conitec n<sup>o</sup> 406: Sunitinibe ou pazopanibe para o tratamento de pacientes portadores de carcinoma renal de células claras metastático. 2018;http://conitec.gov.br/images/Relatorios/2018/Relat.  
102. Ko YJ, Atkins MB. Chemotherapies and immunotherapies for metastatic kidney cancer. Current urology reports. 2005. 103. Motzer RJ, Bacik J, Murphy BA, Russo P, Mazumdar M. Interferon-alfa as a comparative treatment for clinical trials of new therapies against advanced renal cell carcinoma. J Clin Oncol. 2002;  
104. Hernberg M, Pyrhönen S, Muhonen T. Regimens with or without interferon-α as treatment for metastatic melanoma and renal cell carcinoma: An overview of randomized trials. J Immunother. 1999;  
105. Coppin C, Porzsolt F, Autenrieth M, Kumpf J, Coldman A, Wilt TJ. Immunotherapy for advanced renal cell cancer. Cochrane Database of Systematic Reviews. 2015.  
106. Baaten G, Voogd AC, Wagstaff J. A systematic review of the relation between interleukin-2 schedule and outcome in patients with metastatic renal cell cancer. Eur J Cancer. 2004;  
107. Malaguarnera M, Ferlito L, Gulizia G, Di Fazio I, Pistone G. Use of interleukin-2 in advanced renal carcinoma: Metaanalysis and review of the literature. European Journal of Clinical Pharmacology. 2001.  
108. Santoni M, Conti A, De Giorgi U, Iacovelli R, Pantano F, Burattini L, et al. Risk of gastrointestinal events with sorafenib, sunitinib and pazopanib in patients with solid tumors: A systematic review and meta-analysis of clinical trials [Internet]. Vol. 135, International Journal of Cancer. Wiley-Liss Inc.; 2014 [cited 2021 May 31]. p. 763–73. Available from: https://pubmed.ncbi.nlm.nih.gov/24127298/  
109. Ibrahim EM, Kazkaz GA, Abouelkhair KM, Bayer AM, Elmasri OA. Sunitinib adverse events in metastatic renal cell carcinoma: A meta-analysis. Int J Clin Oncol [Internet]. 2013 Dec [cited 2021 May 31];18(6):1060–9. Available from: https://pubmed.ncbi.nlm.nih.gov/23179639/  
110. Zhu X, Stergiopoulos K, Wu S. Risk of hypertension and renal dysfunction with an angiogenesis inhibitor sunitinib: Systematic review and meta-analysis. Acta Oncologica. 2009.  
111. Schutz FAB, Jardim DLF, Je Y, Choueiri TK. Haematologic toxicities associated with the addition of bevacizumab in cancer patients. Eur J Cancer. 2011;  
112. Schutz FAB, Je Y, Choueiri TK. Hematologic toxicities in cancer patients treated with the multi-tyrosine kinase sorafenib: A meta-analysis of clinical trials. Crit Rev Oncol Hematol. 2011;  
113. Hang XF, Xu WS, Wang JX, Wang L, Xin HG, Zhang RQ, et al. Risk of high-grade bleeding in patients with cancer treated with bevacizumab: A meta-analysis of randomized controlled trials. Eur J Clin Pharmacol. 2011;  
114. Chu D, Lacouture ME, Weiner E, Wu S. Risk of hand-foot skin reaction with the multitargeted kinase inhibitor sunitinib in patients with renal cell and non-renal cell carcinoma: A meta-analysis. Clinical Genitourinary Cancer. 2009.  
115. Kapadia S, Hapani S, Choueiri TK, Wu S. Risk of liver toxicity with the angiogenesis inhibitor pazopanib in cancer patients. Acta Oncol (Madr). 2013;  
116. Sivendran S, Liu Z, Portas LJ, Yu M, Hahn N, Sonpavde G, et al. Treatment-related mortality with vascular endothelial growth factor receptor tyrosine kinase inhibitor therapy in patients with advanced solid tumors: A metaanalysis. Cancer Treatment Reviews. 2012.  
117. Choueiri TK, Je Y, Sonpavde G, Richards CJ, Galsky MD, Nguyen PL, et al. Incidence and risk of treatment-related mortality in cancer patients treated with the mammalian target of rapamycin inhibitors. Ann Oncol. 2013;  
118. Iacovelli R, Palazzo A, Mezi S, Morano F, Naso G, Cortesi E. Incidence and risk of pulmonary toxicity in patients treated with mTOR inhibitors for malignancy. A meta-analysis of published trials. Acta Oncol (Madr). 2012;  
119. Kaymakcalan MD, Je Y, Sonpavde G, Galsky M, Nguyen PL, Heng DYC, et al. Risk of infections in renal cell carcinoma (RCC) and non-RCC patients treated with mammalian target of rapamycin inhibitors. Br J Cancer. 2013;  
120. Beaumont JL, Butt Z, Baladi J, Motzer RJ, Haas T, Hollaender N, et al. Patient‐Reported Outcomes in a Phase III Study of Everolimus Versus Placebo in Patients with Metastatic Carcinoma of the Kidney That Has Progressed on Vascular Endothelial Growth Factor Receptor Tyrosine Kinase Inhibitor Therapy. Oncologist [Internet]. 2011 May [cited 2021 May 31];16(5):632–40. Available from: https://pubmed.ncbi.nlm.nih.gov/21459902/;  
121. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Conitec. Relatório de Recomendação 570. Outubro de 2020. Cabozantinibe para tratamento de primeira linha de câncer renal avançado. Disponível em <u>https://www.gov.br/conitec/ptbr/midias/consultas/relatorios/2020/20201113_relatorio_de_recomendacao_570_cabozantinibe.pdf;</u>  
122. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Conitec. Relatório de Recomendação 660. Agosto de 2021. Pembrolizumabe, axitinibe, ipilimumabe e nivolumabe para tratamento de primeira linha de câncer de células renais. Disponível em https://www.gov.br/conitec/ptbr/midias/relatorios/2021/20210830_relatorio_660_pembrolizumabe_axitinibe_ipilimumabe_nivolumabe_ccr_1_linha _final.pdf;  
123. Brasil. Ministério da Saúde. Secretaria de Ciência Tecnologia e Insumos Estratégicos. Conitec. Relatório de Recomendação 661. Junho de 2021. Cabozantinibe ou nivolumabe para o tratamento de segunda linha para pacientes  
- com carcinoma de células renais metastático. Disponível em https://docs.bvsalud.org/biblioref/2021/09/1292081/20210903_relatorio_cabozantinibe_nivolumabe_ccr_segunda_linh a.pdf  
124. Passalacqua R, Buzio C, Buti S, Porta C, Labianca R, Pezzuolo D, et al. Phase III, randomised, multicentre trial of maintenance immunotherapy with low-dose interleukin-2 and interferon-α for metastatic renal cell cancer. Cancer  
Immunol Immunother. 2010;  
125. Ministério da Saúde. Portaria n<sup>o</sup> 1.440/SAS/MS. Diretrizes Diagnósticas e Terapêuticas do Carcinoma de Células Renais. Brasília: Ministério da Saúde; 2014. Brasília Ministério da Saúde. 2014;  
126. Escudier B, Eisen T, Stadler WM, Szczylik C, Oudard S, Staehler M, et al. Sorafenib for treatment of renal cell carcinoma: Final efficacy and safety results of the phase III treatment approaches in renal cancer global evaluation trial. J Clin Oncol [Internet]. 2009 Jul 10 [cited 2021 May 31];27(20):3312–8. Available from: https://pubmed.ncbi.nlm.nih.gov/19451442/  
127. Mills EJ, Rachlis B, O’Regan C, Thabane L, Perri D. Metastatic renal cell cancer treatments: An indirect comparison meta-analysis. BMC Cancer [Internet]. 2009 Jan 27 [cited 2021 May 31];9. Available from: https://pubmed.ncbi.nlm.nih.gov/19173737/  
128. Di Lorenzo G, Casciano R, Malangone E, Buonerba C, Sherman S, Willet J, et al. An adjusted indirect comparison of everolimus and sorafenib therapy in sunitinib-refractory metastatic renal cell carcinoma patients using repeated matched samples. Expert Opin Pharmacother [Internet]. 2011 Jul [cited 2021 May 31];12(10):1491–7. Available from: https://pubmed.ncbi.nlm.nih.gov/21599551/  
129. Zbrozek AS, Hudes G, Levy D, Strahs A, Berkenblit A, DeMarinis R, et al. Q-TWiST analysis of patients receiving temsirolimus or interferon alpha for treatment of advanced renal cell carcinoma. Pharmacoeconomics [Internet]. 2010 [cited 2021 May 31];28(7):577–84. Available from: https://pubmed.ncbi.nlm.nih.gov/20550223/  
130. Thompson Coon J, Hoyle M, Green C, Liu Z, Welch K, Moxham T, et al. Bevacizumab, sorafenib tosylate, sunitinib and temsirolimus for renal cell carcinoma: A systematic review and economic evaluation [Internet]. Vol. 14, Health Technology Assessment. Health Technol Assess; 2010 [cited 2021 May 31]. p. 1–184. Available from: https://pubmed.ncbi.nlm.nih.gov/20028613/  
131. Hoyle M, Green C, Thompson-Coon J, Liu Z, Welch K, Moxham T, et al. Cost-effectiveness of sorafenib for secondline treatment of advanced renal cell carcinoma. Value Heal [Internet]. 2010 [cited 2021 May 31];13(1):55–60. Available from: https://pubmed.ncbi.nlm.nih.gov/19804431/  
132. Buti S, Bersanelli M, Sikokis A, Maines F, Facchinetti F, Bria E, et al. Chemotherapy in metastatic renal cell carcinoma today? A systematic review [Internet]. Vol. 24, Anti-Cancer Drugs. Anticancer Drugs; 2013 [cited 2021 May 31]. p. 535–54. Available from: https://pubmed.ncbi.nlm.nih.gov/23552469/  
133. Eggener SE, Yossepowitch O, Pettus JA, Snyder ME, Motzer RJ, Russo P. Renal cell carcinoma recurrence after nephrectomy for localized disease: Predicting survival from time of recurrence. J Clin Oncol. 2006;  
134. Stewart SB, Thompson RH, Psutka SP, Cheville JC, Lohse CM, Boorjian SA, et al. Evaluation of the National Comprehensive Cancer Network and American Urological Association renal cell carcinoma surveillance guidelines. J Clin Oncol. 2014;  
135. Dabestani S, Beisland C, Stewart GD, Bensalah K, Gudmundsson E, Lam TB, et al. Long-term Outcomes of Followup for Initially Localised Clear Cell Renal Cell Carcinoma: RECUR Database Analysis. Eur Urol Focus. 2019;  
136. Patard JJ, Shvarts O, Lam JS, Pantuck AJ, Kim HL, Ficarra V, et al. Safety and efficacy of partial nephrectomy for all T1 tumors based on an international multicenter experience. J Urol. 2004;  
137. Beisland C, Guðbrandsdottir G, Reisæter LAR, Bostad L, Hjelle KM. A prospective risk-stratified follow-up programme for radically treated renal cell carcinoma patients: evaluation after eight years of clinical use. World J Urol. 2016;  
138. NCCN. NCCN Guidelines for Kidney Cancer. 2021;  
139. European Association of Urology. EAU Guidelines on Renal Cell Carcinoma. 2020.  
140. American Urological Association. AUA Guidelines Follow-up for Clinically Localized Renal Neoplasms. 2013.  
141. Kunkle DA, Egleston BL, Uzzo RG. Excise, Ablate or Observe: The Small Renal Mass Dilemma-A Meta-Analysis and Review. Journal of Urology. 2008.  
142. Klatte T, Grubmüller B, Waldert M, Weibl P, Remzi M. Laparoscopic cryoablation versus partial nephrectomy for the treatment of small renal masses: Systematic review and cumulative analysis of observational studies. European Urology. 2011.  
143. Zisman A, Pantuck AJ, Wieder J, Chao DH, Dorey F, Said JW, et al. Risk group assessment and clinical outcome algorithm to predict the natural history of patients with surgically resected renal cell carcinoma. J Clin Oncol. 2002;  
144. Frank I, Blute ML, Cheville JC, Lohse CM, Weaver AL, Zincke H. An outcome prediction model for patients with clear cell renal cell carcinoma treated with radical nephrectomy based on tumor stage, size, grade and necrosis: The SSIGN score. J Urol. 2002;  
145. Cindolo L, Patard JJ, Chiodini P, Schips L, Ficarra V, Tostain J, et al. Comparison of predictive accuracy of four prognostic models for nonmetastatic renal cell carcinoma after nephrectomy: A multicenter European study. Cancer. 2005.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **1. Escopo e finalidade das Diretrizes** -->
A atualização das Diretrizes Diagnósticas e Terapêuticas (DDT) do Carcinoma de Células Renais (CCR) foi iniciada com a reunião presencial para delimitação do seu escopo. Nesta reunião, estavam presentes dois membros do Departamento de Gestão, Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS); um membro da Coordenação-Geral de Atenção Especializada (CGAE/DAET/SAES/MS) e nove membros do grupo elaborador. Os representantes do Ministério da Saúde participaram por meio de videoconferência.  
Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento das DDT, sendo definida a macroestrutura das Diretrizes, embasado no disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009<sup>1</sup> e nas Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>2</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no Sistema Único de Saúde, novas tecnologias puderam ser identificadas. Deste modo, o grupo de especialistas foi orientado a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (ANVISA) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo elaborador destas DDT foi composto por um painel de especialistas e metodologistas sob coordenação do DGITS. Entre os nove membros do grupo elaborador, três eram especialistas e quatro metodologistas. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e de confidencialidade.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Declaração e Manejo de Conflitos de Interesse** -->
Todos os membros do Grupo Elaborador declararam seus conflitos de interesse, utilizando a Declaração de Potencial Conflitos de Interesses ( **Quadro A** ).  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a)<br>Reembolso por comparecimento a eventos na área de interesse da diretriz|( ) Sim|
|---|---|
||( ) Não|
|b)<br>Honorários por apresentação, consultoria, palestra ou atividades de ensino|( ) Sim|
||( ) Não|
|c)<br>Financiamento para redação de artigos ou editorias|( ) Sim|  
||( ) Não|
|---|---|
|d)<br>Suporte para realização ou desenvolvimento de pesquisa na área|( ) Sim<br>( ) Não|
|e)<br>Recursos ou apoio financeiro para membro da equipe|( ) Sim<br>( ) Não|
|f)<br>Algum outro benefício financeiro|( ) Sim<br>( ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|( ) Sim<br>( ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|( ) Sim<br>( ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|( ) Sim<br>( ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser afet<br>atividade na elaboração ou revisão da diretriz?|ados pela sua|
|a) Instituição privada com ou sem fins lucrativos|( ) Sim<br>( ) Não|
|b) Organização governamental ou não-governamental|( ) Sim<br>( ) Não|
|c) Produtor, distribuidor ou detentor de registro|( ) Sim<br>( ) Não|
|d) Partido político|( ) Sim<br>( ) Não|
|e) Comitê, sociedade ou grupo de trabalho|( ) Sim<br>( ) Não|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **3. Busca da evidência** -->
Estas DDT foram desenvolvidas conforme as Diretrizes Metodológicas de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO. Durante a reunião de escopo destas DDT, duas questões de pesquisa foram levantadas ( **Quadro B** ):  
**Quadro B** - Questões PICO elencadas para elaboração das DDT.  
|**PICO**|**Pergunta**|**Material**|
|---|---|---|
|||**Suplementar**|
|1|As associações ipilimumabe/nivolumabe ou pembrolizumabe/axitinibe são eficazes|A|
||e seguras para o tratamento do carcinoma de células renais avançado ou metastático,<br>comparada à imunoterapia com interferon ou terapia com inibidores de tirosina||
||quinase (sunitinibe ou pazopanibe)?||
|2|Qual a eficácia, segurança e a custo-efetividade, em segunda linha de tratamento, do|B|  
levomalato de cabozantinibe ou nivolumabe em comparação ao everolimo, pazopanibe, sunitibe, ipilimumabe, axitinibe e pembrolizumabe para pacientes adultos com CCR metastático?  
A equipe de metodologistas envolvida no processo ficou responsável pela busca e avaliação de evidências, segundo metodologia GRADE. Deste modo, a busca na literatura foi realizada nas bases PubMed e Embase e validadas no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizado e não padronizado para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e checada por outro, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo.  
Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança.  
Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel<sup>®</sup> . As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>3</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>4</sup> , os estudos observacionais pela ferramenta NewcastleOttawa<sup>5</sup> . Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas as estratégias de busca, síntese e avaliação das evidências para cada uma das duas questões PICO realizadas para as presente DDT.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **4. Recomendações** -->
A relatoria das seções das DDT foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referir a recomendação com base nos estudos pivotais que apoiam a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas, interpretavam as evidências e redigiam uma primeira versão da recomendação, para ser discutida entre o painel de especialistas na ocasião do consenso.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **5. Referências** -->
1. BRASIL. Portaria N<sup>o</sup> 375/SAS/MS, de 10 de novembro de 2009. Diário Oficial da União. 2009.  
2. BRASIL. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério da Saúde. 2016.  
3. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: A critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;  
4. Higgins JPT, Altman DG, Gøtzsche PC, Jüni P, Moher D, Oxman AD, et al. The Cochrane Collaboration’s tool for assessing risk of bias in randomised trials. BMJ. 2011 Oct;343:d5928.  
5. Wells GA, Shea B, O’Connell D, Peterson J, Welch V, Losos M  et al. The Newcastle-Ottawa Scale (NOS) for assessing the quality if nonrandomized studies in meta-analyses. 2012.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **MATERIAL SUPLEMENTAR A - PERGUNTA PICO 1** -->
**Questão de pesquisa:** “As associações ipilimumabe/nivolumabe ou pembrolizumabe/axitinibe são eficazes e  
seguras para o tratamento do carcinoma de células renais avançado ou metastático, comparada à imunoterapia com interferon ou terapia com inibidores de tirosina quinase (sunitinibe ou pazopanibe)?”.  
Nesta pergunta, o acrônimo PICO era:  
Pacientes (P): pacientes com carcinoma de células renais avançado (1ª linha) - subgrupo de risco intermediário/alto ou baixo  
Intervenção (I): combinação de nivolumabe/ipilimumabe ou pembrolizumabe/axitinibe  
Comparadores (C):sunitinibe ou pazopanibe  
_Outcomes_ /desfechos (O):sobrevida livre de progressão, sobrevida global e segurança

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **A. Estratégia de busca** -->
A estratégia de busca referente a esta pergunta está descrita no **Quadro C** :  
**Quadro C -** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Base de**<br>**dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**Medline**<br>**via**<br>**PubMed**|("pembrolizumab" [Supplementary Concept] OR "Ipilimumab"[Mesh] OR<br>"Nivolumab"[Mesh] OR "Axitinib"[Mesh]) AND ("Carcinoma, Renal Cell"[Mesh]<br>OR renal cell carcinoma)<br>**Data do acesso: 19/09/2020**|638|
|**EMBASE**|('renal cell carcinoma'/mj OR 'carcinoma, renal cell' OR 'kidney cell carcinoma' OR<br>'renal cell carcinoma' OR 'renal cell adenocarcinoma' OR 'renal cell cancer'/mj OR<br>'kidney carcinoma'/mj OR 'grawitz tumor' OR 'adenocarcinoma, kidney' OR<br>'carcinoma, kidney' OR 'hypernephroid carcinoma' OR 'hypernephroma' OR 'kidney<br>adenocarcinoma' OR 'kidney carcinoma' OR 'renal adenocarcinoma' OR 'renal<br>carcinoma') AND ('pembrolizumab'/mj OR 'keytruda' OR 'pembrolizumab' OR<br>'axitinib'/mj OR 'nivolumab'/mj OR 'nivolumab' OR 'opdivo' OR 'ipilimumab'/mj<br>OR 'ipilimumab') AND ([cochrane review]/lim OR [systematic review]/lim OR<br>[meta-analysis]/lim OR [controlled clinical trial]/lim OR [randomized controlled<br>trial]/lim)<br>**Data do acesso: 19/09/2020**|775|
|**The**<br>**Cochrane**<br>**Library**|#1 MeSH descriptor: [Carcinoma, Renal Cell] explode all trees<br>#2 "renal cell carcinomas"<br>#3 "renal cell adenocarcinoma"<br>#4 "Adenocarcinoma of Kidney"<br>#5 "Renal Cell Cancer"<br>#6 "Renal Adenocarcinoma"|5 revisões<br>cochrane|  
||#7 "Renal Cell Carcinoma"<br>#8 "Kidney Neoplasm"<br>#9 "Renal Neoplasms"<br>#10 "Kidney Cancers"<br>#11 "Renal Cancers"<br>#12 "Cancer of the Kidney"<br>#13 #1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 OR #9 OR #10 OR #11<br>OR #12<br>#14 pembrolizumab<br>#15 Keytruda<br>#16 Nivolumab<br>#17 Opdivo<br>#18 Ipilimumab<br>#19 Yervoy<br>#20 #14 OR #15 OR<br>**Data do acesso: 19/09/2020**||
|---|---|---|
|**LILACS**|(tw:(Carcinoma de Células Renais )) OR (tw:(Carcinoma, Renal Cell )) OR<br>(tw:(Carcinoma de Células Renales)) OR (tw:(Adenocarcinoma de Células Renais))<br>OR (tw:(Carcinoma Hipernefroide)) OR (tw:(Hipernefroma)) OR<br>(mh:(C04.557.470.200.025.390)) OR (mh:(C04.588.945.947.535.160)) OR<br>(mh:(C12.758.820.750.160)) OR (mh:(C12.777.419.473.160)) OR<br>(mh:(C13.351.937.820.535.160)) OR (mh:(C13.351.968.419.473.160)) AND<br>(tw:("nivolumabe")) OR (tw:("nivolumab")) OR (tw:(Opdivo)) OR<br>(mh:(D12.776.124.486.485.114.224.060.829)) OR<br>(mh:(D12.776.124.790.651.114.224.060.829)) OR<br>(tw:(D12.776.377.715.548.114.224.200.829)) OR (tw:(ipilimumabe)) OR<br>(tw:(pembrolizumab)) OR (tw:(pembrolizumabe)) OR (tw:(axitinibe)) OR<br>(tw:(axitinib)) OR (tw:(Inlyta)) OR (mh:(D02.065.277.051 )) OR<br>(mh:(D02.241.223.100.100.115)) OR (mh:(D02.455.426.559.389.127.085.093))<br>OR (mh:(D03.383.129.539.487.065)) OR (mh:(D03.633.100.449.065))|296|
||**Data do acesso: 19/09/2020**||
|**Total**||**1714**|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **B. Seleção das evidências** -->
Na busca foram recuperadas 1.714 publicações. Após a exclusão de 200 duplicatas, permaneceram 1.514 para análise de título e resumo. Posteriormente, após a aplicação dos critérios de elegibilidade, permaneceram 20 publicações para leitura completa. Por fim, apenas as revisões sistemáticas mais recentes e de qualidade, com meta-análises, foram selecionadas. Ensaios clínicos randomizados foram selecionados apenas se não incluídos em nenhuma das revisões sistemáticas ( **Figura 1** ).  
**Figura 1 -** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
° Publicagées identificadas por meio<br>1m da pesquisa7 nas bases de dados:<br>§ MEDLINE (n= 638)<br>Fa EMBASE (n= 775)<br>3 Cochrane library (n= 5)<br>om LILACS (n= 296)<br>°<br>3 Registros- rastreados Registros excluidos<br>= (n=1514) (n =1493 )<br>a<br>ie3 Publicagéesi"  selecionadas- Publicacélblleagpe>critérios elitesdelui exclus&o: Segunda<br>Pe para leitura (n= 20) (n =15)<br>3<br>‘BD<br>aby<br>Estudos incluidos (n= 5)<br>3 3 revisées sistematicas com<br>3 metanalise<br>£ 1 revisdo sistematica direta<br>1 ensaio clinico de seguimento<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **C.          Descrição dos estudos e resultados** -->
Os desfechos de eficácia e segurança dos estudos incluídos encontram-se na **Tabela A** .  
**Tabela A -** Desfechos de eficácia e segurança dos estudos incluídos.  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**Tecnologia avaliada versus**<br>**Comparador**|**Desfechos**|**Tamanho do efeito**<br>**(IC 95%)**|**Direção do efeito**|
|---|---|---|---|---|---|
|Massari et<br>al. 2020<sup>1</sup>|Revisão<br>sistemática<br>com|<br>Tratamentos combinados<br>(Nivolumabe/ipilimumabe,|<br>Diminuição do<br>apetite|<br>Maior risco de prurido:<br>(RR 3,06; IC95% 2,51-3,72)|Favorece tecnologia<br>avaliada: terapia|
||meta-análise direta|pembrolizumabe/axitinibe<br>avelumabe/axitinibe)|<br>Diarreia<br><br>Fadiga|<br>Erupção cutânea<br>(RR 1,43; IC95% 1,21-1,68),|combinada|
|||<br>Sunitinibe|<br>Hipertensão<br><br>Hipotireoidismo<br><br>Náusea<br><br>Reação cutânea/<br>eritrodistesia palmoplantar<br><br>Prurido<br><br>Erupção cutânea<br><br>Estomatite|<br>Menor risco de fadiga<br>(RR 0,49; IC95% 0,33-0,67),<br><br>Náusea<br>(RR 0,60; IC95% 0,58-0,71)<br><br>Estomatite<br>(RR 0,68; IC95% 0,47-0,98)||
|Cao et al.|<br>Revisão|<br>Sorafenibe|<br>**Primários**|**Primários:**|<br>**SLP e SG:**|
|2020<sup>2</sup>|sistemática<br>com<br>meta-análise<br>indireta|<br>Sunitinibe<br><br>Pazopanibe<br><br>Cabozantinibe<br>Nivolumabe/ipilimumabe,<br><br>Axitinibe<br><br>Tivozanibe<br><br>Everolimo<br><br>IFN-α<br><br>Bevacizumabe/IFN-α<br><br>Temsirolimo/bevacizumab|SLP, SG.<br><br>**Secundários**<br>eventos adversos|**SLP**<br>**Risco baixo:**<br>NI: HR 2,18 (IC95% 1,47-3,25)<br>PA: HR 0,72 (IC95% 0, 32-1,30).<br>**Intermediário:**<br>NI: HR 0,66 (IC95% 0,53 -0,81)<br>PA: HR 0,58 (IC95% 0,44- 0,80)<br>**Alto:**<br>NI: HR 0,57 (IC95% 0,43 a 0,76)<br>PA: HR 0,48 (IC95% 0,30 a 0,82)|Favorece tecnologia<br>avaliada NI e PA para<br>risco intermediário e<br>alto.<br><br>**SLP e SG:**<br>Favorece tecnologia<br>comparadora<br>(sunitinibe) para risco<br>baixo.|  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**Tecnologia avaliada versus**<br>**Comparador**|**Desfechos**|**Tamanho do efeito**<br>**(IC 95%)**|**Direção do efeito**|
|---|---|---|---|---|---|
|||e Avelumabe/axitinibe<br><br>Pembrolizumabe/axitinibe||**SG**<br>**Risco baixo:**<br>PA: HR 0,64 (IC95% 0,24 a 1,70)<br>**Intermediário:**<br>PA e NI (HR 0,53, IC95% 0,34 a 0,81;<br>HR 0,66, IC95% 0,50 a 0,87,<br>respectivamente)<br>**Alto:**<br>PA e NI (HR 0,43, IC95% 0,23 a 0,80;<br>HR 0,57, IC95% 0,39 a 0,83,<br>respectivamente).|<br>**EAs:**<br>tecnologias avaliadas e<br>comparadora são<br>semelhantes.|
|||||**Secundários:**<br>A comparação de todas as terapias não<br>encontrou diferenças significativas nas<br>taxas de EAs de grau alto ou gerais.||
|Elaidi et al.<br>2020<sup>3</sup>|<br>Revisão<br>sistemática<br>com<br>meta-análise<br>indireta|<br>Nivolumabe/ipilimumabe<br><br>Pembrolizumabe/axitinibe<br><br>Avelumabe/axitinibe|**Primários:**<br>SLP, SG.<br>**Secundários:**<br>Taxa de resposta|**Primários:**<br>**SLP**<br>**Risco baixo:**<br>Avelumabe/axitinibe foi superior ao<br>PA (HR: 0,67 (0,26-1,70), e NI (HR:<br>0,44 (0,19–1,00)<br>**Intermediário/alto:**<br>PA e avelumabe/axitinibe foram as||  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**Tecnologia avaliada versus**<br>**Comparador**|**Desfechos**|**Tamanho do efeito**<br>**(IC 95%)**|**Direção do efeito**|
|---|---|---|---|---|---|
|||||duas melhores opções comparados a<br>NI (PA HR: 0,87 (0,58-1,30), OR: 1,1<br>(0,76-1,70), avelumabe/axitinibe HR:<br>0,91 (0,58-1,40), OR: 1,7 (1,10-2,70)).<br>**SG**<br>População geral: PA foi mais eficaz<br>que avelumabe/axitinibe (HR: 0,68;<br>0,35-1,30) e NI (HR: 0,75; 0,44-1,30).<br>**Secundários:**<br>**Taxa de resposta objetiva**<br>**Baixo risco:**<br>Avelumabe/axitinibe foi superior a PA<br>(HR 1,8; 0,69-4,60)) e ao NI (HR 5,6;<br>2,40–13,00)).<br>**Intermediário/alto:**<br>PA (HR 1,1; 0,76-1,70) e<br>avelumabe/axitinibe (HR 1,7; 1,10-<br>2,70) foram as melhores opções de<br>tratamento comparadas a NI.||
|Motzer<br>et<br>al.  2020<sup>4</sup>|Ensaio<br>clínico<br>randomizado<br>de<br>seguimento|<br>Nivolumabe/ipilimumabe<br><br>Sunitinibe|**Primários:**<br>SLP, SG.<br>**Secundários:**<br>Taxa de resposta|**Primários:**<br>**SLP**<br>**Risco baixo:**HR, 1,65; IC95%, 1,16–<br>2,35 (a favor do sunitinibe).||  
|**Autor, ano**|**Delineamento do**<br>**estudo**|**Tecnologia avaliada versus**<br>**Comparador**|**Desfechos**|**Tamanho do efeito**<br>**(IC 95%)**|**Direção do efeito**|
|---|---|---|---|---|---|
|||||**Intermediário/alto:**HR, 0,75;<br>IC95%, 0,62–0,90.<br>**SG**<br>**Risco baixo:**SG mediana não foi<br>alcançada em nenhum dos braços.<br>Intermediário/alto: HR, 0,66; IC95%,<br>0,55–0,80.<br>**Secundários:**<br>**Taxa de resposta objetiva**<br>**Risco baixo:**<br>28,8% (IC95%21,1–37,6) com NI x<br>54,0% (44,9–63,0) com SUN<br>**Intermediário/alto:**<br>NI x SUN (42,4% vs 29,4%)||  
**Legenda:** NI: nivolumabe/ipilimumabe; PA: pembrolizumabe/axitinibe; ECR: Ensaio Clínico Randomizado; IC95%: Intervalo de confiança 95%; SLP: sobrevida livre de progressão; SG: sobrevida global; EA: eventos adversos; CCRm: câncer de células renais metastático/avançado; G-3-4: grau 3 e 4

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **D. Qualidade geral das evidências** -->
A avaliação do risco de viés dos ensaios clínicos randomizados que avaliaram a eficácia das associações em tela foi realizada utilizando a versão 2 da ferramenta de risco de viés Cochrane para ensaios randomizados<sup>5</sup> e está descrita na **Figura 2** .  
**Figura 2 -** Análise de risco de viés de ensaios clínicos randomizados (RoB2).  
<!-- Start of picture text -->
Risk of bias domains<br>Be<br>z, ® e@2 @@ @ ®<br>= @®® @e8e8e@2 @86 06@ @®<br>Domains: Judgement<br>D1: Bias arising from the randomization process.<br>D2: Bias due to deviations from intended intervention. @ High<br>D3:D4: BiasBias duein measurementto missing outcomeof the outcome.data. @ Some concems<br>D5: Bias in selection of the reported result. @ iow<br><!-- End of picture text -->  
Para análise da qualidade metodológica das RS com meta-análise em rede ou não, foi utilizada a ferramenta AMSTAR-2. Esta ferramenta é amplamente utilizada para avaliar a qualidade científica de revisões sistemáticas tradicionais ou meta-análises, mas ainda não é formalmente utilizada para ser aplicada em meta-análises em rede<sup>6</sup> . No entanto, Ge et al., 2016, com base na análise de 102 meta-análises em rede com tema central câncer constatou que revisões e extensões do AMSTAR podem ser consideráveis para serem aplicadas em meta-análises em rede<sup>6</sup> . A avaliação da qualidade das revisões sistemáticas encontradas para responder esta pergunta está descrita na **Tabela B** .  
**Tabela B -** AMSTAR 2 Avaliação da Qualidade de Revisões Sistemáticas.  
|||**E**|**STUDOS**||
|---|---|---|---|---|
|**CRITÉRIOS**|**Cao et al.**<br>**2020**<sup>**2**</sup>|**Massari et al.**<br>**2020**<sup>1</sup>|**Elaidi et al.**<br>**2020**<sup>3</sup>|**Motzer et al.**<br>**2020**<sup>4</sup>|
|(1) Pergunta e Inclusão|Sim|sim|sim|sim|
|(2) Protocolo|Não|não|não|sim|
|(3) Desenho do estudo|Não|sim|não|não|
|(4) Pesquisa abrangente|Sim|sim|sim|sim|
|(5) Seleção dos estudos|Sim|sim|sim|não|
|(6) Extração de dados|Sim|sim|sim|não|
|(7) Justificativa dos estudos excluídos|Não|não|não|não|
|(8) Detalhes dos estudos incluídos|sim|Parcialmente|não|sim|
|(9) Risco de viés|Sim|sim|sim|não|
|(10) Fontes de financiamento|Sim|sim|sim|sim|
|(11) Métodos estatísticos|Sim|sim|sim|sim|
|(12) Risco de viés na meta-análises|Não|sim|não|não|
|(13) Risco de viés em estudos individuais|Sim|sim|não|não|  
37  
|||**E**|**STUDOS**||
|---|---|---|---|---|
|**CRITÉRIOS**|**Cao et al.**|**Massari et al.**|**Elaidi et al.**|**Motzer et al.**|
||**2020**<sup>**2**</sup>|**2020**<sup>1</sup>|**2020**<sup>3</sup>|**2020**<sup>4</sup>|
|(14) Explicação da heterogeneidade|Sim|sim|sim|não|
|(15) Viés de publicação|Sim|não|não|não|
|(16) Conflito de interesse|Sim|sim|sim|sim|
|**_Qualidade_**|**_Moderada_**|**_Baixa_**|**_Baixa_**|**_Criticamente Baixa_**|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida global** -->
Elaidi et al., 2020<sup>3</sup> avaliou comparativamente, por meta-análise indireta, a SG entre os tratamentos nivolumabe/ipilimumabe, pembrolizumabe/axitinibe e avelumabe/axitinibe. Na população geral, os dados mostraram que o pembrolizumabe/axitinibe (SUCRA = 96%) foi mais eficaz que avelumabe/axitinibe (HR 0,68; 0,35-1,30) e nivolumabe/ipilimumabe (HR 0,75; 0,44-1,30) ( **Figura 3** ).  
**Figura 3 -** Forest plot da comparação indireta entre cada combinação para o desfecho de sobrevida global.  
<!-- Start of picture text -->
Overall survival<br>Pembro+ Axi vs Nivo + Ipi 0.75 [0.44 - 1.3]<br>Ave + Axi vs Nivo+Ipi 1.1 [0.65 - 1.9]<br>Pembro+Axi vs Ave+Axi 0.68 [0.35 - 1.3]<br>0.3 1 5<br>Favours Treat 1 Favours Treat 2<br><!-- End of picture text -->  
Fonte: Elaidi et al., 2020<sup>3</sup>

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Pacientes com Baixo risco** -->
Com base nos dados da meta-análise em rede de Cao et al., 2020, para tratamento de pacientes com CCRm de baixo risco, não houve diferença significativa na SG entre sunitinibe e pazopanibe (HR 0,88, IC de 95% 0,64 a 1,21) ou pembrolizumabe/axitinibe (HR 0,64; IC95% 0,24 a 1,70)<sup>2</sup> ( **Figura 4** ).  
38  
**Figura 4** - Análise da sobrevida global para pacientes com classificação de baixo risco.  
<!-- Start of picture text -->
A PEM_AXI<br>+ PAZ<br>‘<br>SUN<br>B os<br>07<br>06<br>2 0S<br>z o4 —*-SUN<br>2 03 - PAZ<br>= 02 PEM_AXI<br>o4<br>0<br>1 2 3<br>Rankings<br><!-- End of picture text -->  
Legenda: (A) diagrama de rede: o tamanho de cada nó de tratamento corresponde ao número de pacientes. A largura das linhas é proporcional ao número de tentativas (B) Classificação dos tratamentos para o desfecho de sobrevida global. SUN = sunitinibe. PAZ = pazopanibe. PEM_AXI = pembrolizumabe/axitinibe. Fonte: Cao et al  2020<sup>2</sup>  
De forma geral, não houve diferenças significativas entre as terapias sistêmicas para CCRm de baixo risco.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Pacientes com Risco intermediário/alto** -->
Em pacientes de risco intermediário, tanto o nivolumabe/ipilimumabe (HR 0,66, IC 95% 0,50-0,87) quanto o pembrolizumabe/axitinibe (HR 0,53, IC 95% 0,34-0,81) foram associados a um ganho de SG maior que sunitinibe. Em pacientes de alto risco, as associações também foram mais eficazes (pembrolizumabe/axitinibe: HR 0,43, IC 95% 0,23-0,80 e nivolumabe/ipilimumabe: HR 0,57, IC 95% 0,39-0,83). No ranqueamento das tecnologias avaliadas havia 81% de probabilidade de pembrolizumabe/axitinibe ser a melhor escolha para pacientes de risco intermediário e 78% para os classificados como alto risco, respectivamente (SUCRA = 93,1% e SUCRA = 91,4%, respectivamente) quando comparado indiretamente ao nivolumabe/ipilimumabe, pazopanibe e sunitinibe ( **Figuras 5 e 6** )<sup>2</sup> .  
39  
**Figura 5** - Análise da sobrevida global para pacientes com classificação de risco intermediário.Legenda: (A) diagrama de rede: o tamanho de cada nó de tratamento corresponde ao número de pacientes. A largura das linhas é proporcional ao número de tentativas (B) Classificação dos tratamentos para o desfecho de sobrevida global. SUN = sunitinibe. PAZ = pazopanibe. PEM_AXI = pembrolizumabe/axitinibe, NIVI_IPI = nivolumabe/ipilimumabe. Fonte: Cao et al  2020<sup>2</sup>  
<!-- Start of picture text -->
A , PAZ<br>PEM_AXI<br>. * NIVIPI<br>se<br>sun<br>B 09<br>os<br>o7 —\<br>06 \<br>Bos —+stn<br>3 oa “PAZ<br>z 03 —*-PEM_AXI<br>02 —NIV_IPI<br>on<br>°<br>1 2 3 4<br>Rankings<br><!-- End of picture text -->  
**Figura 6** - Classificação dos tratamentos para o desfecho de sobrevida global para pacientes de alto risco.Legenda: SUN = sunitinibe. PAZ = pazopanibe. PEM_AXI = pembrolizumabe/axitinibe, NIVI_IPI = nivolumabe/ipilimumabe.  
Fonte: Cao et al  2020<sup>2</sup>  
<!-- Start of picture text -->
09<br>08<br>0.7<br>06<br>2<br>= os —*-SUN<br>Z 04 PAZ<br>E 03 —*-PEM_AXI<br>0.2 ——NIV_IPI<br>0.1<br>0<br>1 2 3 4<br>Rankings<br><!-- End of picture text -->  
Para o desfecho de sobrevida global, nenhuma das meta-análises apresentou dados de HR para as comparações entre si, apenas dados da classificação relativa dos diferentes tratamentos usando SUCRA estavam disponíveis. No estudo de extensão do CheckMate 214, com dados de 42 (média) meses de acompanhamento, o nivolumabe/ipilimumabe foi superior ao sunitinibe (HR, 0,66; IC95%, 0,55–0,80) na análise de SG. A probabilidade de SG foi de 52% com a associação e 39% com sunitinibe para o período avaliado<sup>4</sup> .  
40

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida livre de progressão** -->
De acordo com dados de meta-análise indireta de Elaidi e colaboradores<sup>3</sup> , o pembrolizumabe/axitinibe e o avelumabe/axitinibe mostraram eficácia semelhante na SLP para a população geral (HR: 1,00; 0,68-1,50). A combinação nivolumabe/ipilimumabe teve eficácia inferior em comparação com avelumabe/axitinibe (HR: 0,81; 0,57-1,20) e pembrolizumabe/axitinibe (HR: 0,82; 0,58-1,20). A classificação mostrou o avelumabe/axitinibe como a melhor opção de tratamento (SUCRA = 83%), seguido do pembrolizumabe/axitinibe (SUCRA = 80%), mas a diferença não foi clinicamente relevante.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Pacientes com Baixo risco** -->
Na população de baixo risco, a comparação entre nivolumabe/ipilimumabe, pembrolizumabe/axitinibe e avelumabe/axitinibe, mostrou que o avelumabe/axitinibe foi superior a pembrolizumabe/axitinibe (HR 0,67; 0,26-1,70) e nivolumabe/ipilimumabe (HR 0,44; 0,19–1,00)<sup>3</sup> .  
Cao et al., 2020 compararam a eficácia de 12 tratamentos para primeira linha de CCRm: avelumabe/axitinibe, axitinibe, bevacizumabe/interferon (IFN-α), everolimo, IFN-α, nivolumabe/ipilimumabe, pazopanibe, pembrolizumabe/axitinibe, sorafenibe, sunitinibe, temsirolimus/bevacizumabe, tivozanibe ( **Figura 7** ). Em pacientes com baixo risco, o IFN-α e nivolumabe/ipilimumabe apresentaram a pior eficácia na SLP, sendo estatisticamente inferiores ao sunitinibe (HR 2,69; IC95% 1,54=4,67 HR 2,18, IC95% 1,47-1,30, respectivamente). O pembrolizumabe/axitinibe não mostrou diferença na SLP quando comparado ao sunitinibe (HR 0,72 IC95% 0,32-3,25) ( **Figura 8** )<sup>2</sup> .  
**Figura 7** - Diagrama de rede: o tamanho de cada nó de tratamento corresponde ao número de pacientes.Nota: A largura das linhas é proporcional ao número de tentativas.Legenda: AXI: axitinibe; BEV_IFN: bevacizumabe/interferon; EVE: everolimo; IFN: IFN-α; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe; PLA: placebo; SOR: sorafenibe; SUN: sunitinibe; TEM_BEV: temsirolimo mais bevacizumabe; TIV: tivozanibe.  
<!-- Start of picture text -->
IFN EVE<br>NIV_IPI av aN<br>AXI<br>PAZ<br>AVE_AXI<br>PEM_AXI<br>Tv<br>PLA<br>TEM_BEV<br>SOR<br>SUN<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup> .  
41  
**Figura 8** - Forest plot da meta-análise tendo o sunitinibe como comparador.Legenda: AXI: axitinibe; BEV_IFN: bevacizumabe/interferon; EVE: everolimo; IFN: IFN-α; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe; PLA: placebo; SOR: sorafenibe; SUN: sunitinibe; TEM_BEV: temsirolimo mais bevacizumabe; TIV: tivozanibe.  
<!-- Start of picture text -->
Compared with SUN UR 08% CD<br>PLA 255 1137,4.70)<br>IFN H en 2.69 (1.54,4.67)<br>sor - 147(061,349)<br>PAZ i 1.02 (0.74, 1.39)<br>ax + 093,034,254)<br>EVE - 1.20(0.80, 1.80)<br>BEV_IFN - 1.65 (0.90, 2.99)<br>TEM_BEV . 1.98 (0.98, 3.96)<br>mW - 0.89 0.34,2.38)<br>Net :—— 2.18(147,325)<br>PEM_AXI : 0.72 (0.32, 1.30)<br>AVE_AXI el ' 0.57 (0.34,0.96)<br>a3 g— 1 _ “7<br>Favours other drug Favours SUN<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup> .  
Na classificação entre as terapias avaliadas, a associação avelumabe/axitinibe teve maior probabilidade de classificação de fornecer o maior benefício de SLP para pacientes com baixo risco (SUCRA = 92,3%), seguido do pembrolizumabe/axitinibe (SUCRA não apresentado pelos autores) ( **Figura 9** ).  
**Figura 9 -** Classificação dos tratamentos para sobrevida livre de progressão em pacientes de baixo risco.Legenda: AXI: axitinibe; BEV_IFN: bevacizumabe/interferon; EVE: everolimo; IFN: IFN-α; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe; PLA: placebo; SOR: sorafenibe; SUN: sunitinibe; TEM_BEV: temsirolimo mais bevacizumabe; TIV: tivozanibe.  
<!-- Start of picture text -->
os<br>aaa —+-sUN<br>—#-PAZ<br>{os -#-SOR<br>£02 \ a te ——— 27 ——AXI<br>oa Vaens ‘ EVE<br>a= aN TV<br>o te Ne SN mu<br>faa @e€eC tr shana sen<br>Rankings<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup>

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Pacientes com Risco intermediário/alto** -->
Nos grupos de risco intermediário/alto, pembrolizumabe/axitinibe (HR 0,87; 0,58-1,30) e avelumabe/axitinibe (HR 0,92; 0,58-1,40) foram melhores opções terapêuticas quando comparados ao nivolumabe/ipilimumabe ( **Figura 10** ).  
42  
**Figura 10** - Forest plot da comparação indireta entre cada combinação para o desfecho de sobrevida livre de progressão.  
<!-- Start of picture text -->
Treat 1 Treat 2 Hazard ratio/Odds ratio (95% Cl)<br>Progression-free survival<br>Pembro+ Axi vs Nivo+Ipi 0.87 (058 -13])<br>Ave + Axi vs Nivo+ Ipi 0.92 [0.58- 1.4]<br>Ave + Axi vs Pembro+ Axi 1.1 [062-18]<br>0.5 1 3<br>Favours Treat 1 Favours Treat 2<br><!-- End of picture text -->  
Fonte: Elaidi et al., 2020<sup>3</sup>  
Uma meta-análise em rede avaliando 12 tratamentos em primeira linha demonstrou que cabozantinibe (HR 0,63; IC95% 0,44-0,97) e as associações nivolumabe/ipilimumabe (HR 0,66; IC95% 0,53-0,81), pembrolizumabe/axitinibe (HR 0,58; IC95% 0,44-0,80) e avelumabe/axitinibe (HR 0,62; IC95% 0,47-0,83) proporcionaram maior ganho de SLP quando comparado ao sunitinibe em pacientes com risco intermediário ( **Figura 11** ). No ranqueamento, a associação pembrolizumabe/axitinibe teve maior probabilidade (49%) de ser o melhor tratamento, com um SUCRA de 90,7% ( **Figura 12** ).  
**Figura 11 -** Diagrama de rede: o tamanho de cada nó de tratamento corresponde ao número de pacientes.Nota: A largura das linhas é proporcional ao número de tentativas.Legenda: AXI: axitinibe; BEV_IFN: bevacizumabe/interferon; EVE: everolimo; IFN: IFN-α; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe; PLA: placebo; SOR: sorafenibe; SUN: sunitinibe; TEM_BEV: temsirolimo mais bevacizumabe; TIV: tivozanibe  
<!-- Start of picture text -->
IFN BEV_IFN<br>NIV_IPI as<br>PAZ<br>AVE_AXI<br>TIV<br>PEM_AXI<br>PLA TEM_BEV<br>SOR SUN<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup> .  
43  
**Figura 12** - Classificação dos tratamentos para sobrevida livre de progressão em pacientes de risco intermediário.Legenda: AVE_AXI: avelumabe/axitinibe; AXI: axitinibe; CAB: Cabozantinibe; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe;; SUN: sunitinibe; TIV: tivozanibe.  
<!-- Start of picture text -->
0.6<br>bea IE —+sUN<br>04 PAZ<br>zg AXI<br>i 03 ear<br>= —CAB<br>02 tv<br>O41 -eNIV_IPI<br>—PEM_AXI<br>0<br>12 3 4 5 6 7 8 9 10 1 12 13 14 —-AVE_AXI<br>Rankings<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup>  
Esta melhora também foi evidenciada em pacientes de alto risco (nivolumabe/ipilimumabe: HR 0,57, IC95% 0,430,76 e pembrolizumabe/axitinibe: HR 0,48, IC95% 0,30-0,82 comparados ao sunitinibe). O pembrolizumabe/axitinibe foi o tratamento com maior probabilidade de classificação na SLP em pacientes de alto risco (SUCRA = 91,3%) dentre os 12 tratamentos avaliados (7). Em outra meta-análise em rede, na qual foram analisados os tratamentos tezolizumabe/ebevacizumabe, IMA901/sunitinibe, pazopanibe, pembrolizumabe/axitinibe, nivolumabe/ipilimumabe e avelumabe/axitinibe, o avelumabe/axitinibe teve a maior probabilidade de fornecer a SLP (pontuação P: 0,7582) seguido do pembrolizumabe/axitinibe (pontuação P: 0,7293) em pacientes com risco intermediário/alto<sup>7</sup> . Dados da análise estendida do ensaio clínico CheckMate 214 mostraram que o nivolumabe/ipilimumabe foi superior ao sunitinibe (HR, 0,75; IC de 95%, 0,62–0,90), com probabilidades de SLP em 42 meses de 33% _versus_ 16%, respectivamente<sup>4</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta** -->
Na análise de grupos de riscos para o desfecho taxa de resposta, o avelumabe/axitinibe foi superior a pembrolizumabe/axitinibe (HR 1,8; 0,69-4,60) e ao nivolumabe/ipilimumabe (HR 5,6; 2,40–13,00)) nos pacientes classificados como de baixo risco ( **Figura 13** )<sup>3</sup> .  
**Figura 13** - Forest plot da comparação indireta entre cada combinação para o desfecho de taxa de resposta em pacientes de baixo risco.  
<!-- Start of picture text -->
Treat 1 Treat 2<br>Hazard ratio/Odds ratio (95% Crl)<br>Objective response rate<br>NivoNivo ++ IpiIpi vsvs Ave+Pembro+AxiAxi Ste—o— 3.256 [ 2415 - 130]66]<br>Pembro+ Axi vs Ave+ Axi 18 [0.69 - 4.6]<br>0.1 1 20<br>Favours Treat 1 Favours Treat 2<br><!-- End of picture text -->  
Fonte: Elaidi et al., 2020<sup>3</sup>  
44  
No grupo de risco intermediário/alto, pembrolizumabe/axitinibe (HR 1,1; 0,76-1,70) e avelumabe/axitinibe (HR 1,7;  
- 1,10-2,70) foram as melhores opções de tratamento comparadas a nivolumabe/ipilimumabe ( **Figura 14** )<sup>3</sup> .  
**Figura 14** - Forest plot da comparação indireta entre cada combinação para o desfecho de taxa de resposta em pacientes de baixo risco.  
<!-- Start of picture text -->
Treat 1 Treat 2 Hazard ratio/Odds ratio (95% Crl)<br>Objective response rate<br>NivoNivo ++ IpiIpi vsvs Pembro+Ave+Axi Axi 1 .17 [ 0.76-1.7]11-27]<br>Pembro+Axi vs Ave+Axi 15 [0.91 -2.6]<br>0.5 1 3<br>Favours Treat 1 Favours Treat 2<br><!-- End of picture text -->  
Fonte: Elaidi et al., 2020<sup>3</sup>  
Dados de longo prazo mostraram que mais pacientes obtiveram resposta completa (10,1% –12,8% _versus_ 1,4% –  
5,6%) com nivolumabe/ipilimumabe que com o sunitinibe, independentemente do grupo de risco<sup>4</sup> .

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos** -->
Evidência indireta com nove ensaios clínicos não encontrou diferenças significativas nas taxas de EAs graves ou gerais entre as tecnologias avaliadas ( **Figura 15** ).  
**Figura 15** - Eventos adversos graves. O tratamento da coluna é comparado com o tratamento da linha.Nota: _Odds Ratio_ menores que 1 favorecem o tratamento definidor de coluna.Legenda: AVE_AXI: avelumabe /axitinibe; CAB: cabozantinibe; NIV_IPI: nivolumabe/ipilimumabe; PAZ: pazopanibe; PEM_AXI: pembrolizumabe/axitinibe; PLA: placebo; SOR: sorafenibe; SOR_IL-2: sorafenibe/interleucina-2; SUN: sunitinibe; TIV: tivozanibe.  
<!-- Start of picture text -->
0.40 283 107 198 09 $29 049 130 1.00<br>(0.02, 8.55) (0.06, 150.75) (0.12, 9.19) (0.02, 201.54) (0.09, 8.13) (0.06, 499.51) (0.05, 4.26) (0.15, 12.14) (0.11, 8.77)<br>716 267 495 230 1298 124 333 248<br>(0.63, 94.46) (0.31, 24.54) (0.20, 156.27) (0.05, 99.17) (0.45, 392.76) (0.03, 52.88) (0.08, 135.00) (0.06, 109.18)<br>038 0.69 032 1.82 O17 0.46 0.36<br>(0.01, 9.58) (0.08, 6.50) (0.00, 30.01) (0.18, 16.55) (0.00. 13.75) (0.00, 39.97) (0.00, 30.63)<br>1st 087 437 0.46 12 092<br>(0.04, 110.86) (0.03, 19.18) (0.09, 278.21) (0.02, 10.04) (0.06, 25.58) (0.04, 19.41)<br>0.46 263 0.25 0.66 O51<br>(0.00, 6733) (0.11, 53.00) (0.00, 3335) (0.00, 9127) (0.00, 6733)<br>$80 033 1a 1.08<br>(0.03, 947.65) (0.02, 13.17) (0.06, 33.89) (0.05, 25.63)<br>0.09 025 0.19<br>(0.00, 1357) (0.00, 40.53) (0.00, 2800)<br>265 204<br>(0.13, $875) (0.09, 44.95)<br>076<br>(0.03, 16.68)<br><!-- End of picture text -->  
Fonte: Cao et al., 2020<sup>2</sup>  
Massari e colaboradores avaliaram seguintes os EAs em pacientes tratados com combinações imunológicas, incluindo nivolumabe/ipilimumabe e pembrolizumabe/axitinibe: diminuição do apetite, diarreia, fadiga, hipertensão, hipotireoidismo, náusea, eritrodisestesia palmo plantar, prurido, erupção cutânea e estomatite<sup>1</sup> ..  
45  
Para EA de todos os graus de gravidade, os pacientes tratados com combinações imunobiológicas apresentaram maior risco de prurido (RR 3,11; IC952,55-3,78) e erupção cutânea (RR 1,44; IC 95% 1,23-1,69), quando comparados com pacientes tratados com sunitinibe. Entretanto, foi observado que indivíduos tratados com as associações tiveram menor risco de fadiga de grau 3 ou 4 (RR 0,49; IC95% 0,36-0,67), náusea (RR 0,60; IC95% 0,39-0,91), eritrodisestesia palmo plantar (RR 0,22; IC 95% 0,06-0,73) e estomatite (RR 0,68; IC95% 0,47-0,98)<sup>1</sup> .  
Para desfechos mais graves (grau 3 ou 4), não foram encontradas diferenças significativas entre as combinações e sunitinibe: hipotireoidismo (RR 1,24; IC95% 0,33-4,61), náusea (RR 1,05; IC 95% 0,55-1,99), eritrodisestesia palmo plantar (RR 0,20; IC95% 0,03-1,58), prurido (RR 4,92; IC 95% 0,57- 42,06), erupção cutânea (RR 1,56; IC 95% = 0,435,70), estomatite (RR = 0,34; IC95% 0,07-1,56) hipertensão (RR 0,61; IC 95% 0,29-1,29), diarreia (RR 1,07; IC95% 0,482,38), diminuição do apetite (RR1,37; IC 95% 0,46-4,09). Nenhuma diferença significativa foi detectada entre os dois grupos analisados, no desfecho de hipertensão de todos os graus (RR 0,54; IC95% 0,27 -1,07)<sup>1</sup> .  
Dados de longo prazo não mostraram diferenças significativas de incidência de EAs de qualquer grau entre nivolumabe/ipilimumabe e sunitinibe<sup>4</sup> .  
No estudo KEYNOTE-426, 2,6% dos pacientes no grupo pembrolizumabe/axitinibe morreram de eventos adversos, sendo que quatro (0,9%) relacionados ao tratamento (miastenia gravis, miocardite, fascite necrotizante e pneumonite, em 1 paciente cada). Entre os 15 pacientes no grupo de sunitinibe que morreram de eventos adversos, sete pacientes morreram por EAs relacionados ao tratamento (infarto agudo do miocárdio, parada cardíaca, hepatite fulminante, hemorragia gastrointestinal, hemorragia intracraniana e pneumonia)<sup>8</sup> . No estudo CheckMate 214, oito mortes no grupo nivolumabe mais ipilimumabe e quatro mortes no grupo sunitinibe foram relatadas como relacionadas ao tratamento<sup>8</sup> . Nos dados de longo prazo, nenhuma morte adicional relacionada ao tratamento foi relatada desde a análise primária<sup>4</sup> .  
As informações sobre a certeza da evidência por desfecho estão descritas nas **Tabelas C e D** .  
46  
**Tabela C** - Certeza da evidência para pembrolizumabe mais axitinibe comparado a sunitinibe para carcinoma de células renais avançado.  
||**Cert**|**eza da evidência**||||**Efeito**||
|---|---|---|---|---|---|---|---|
|**№ dos estudos**<br>**Delineamento do**<br>**estudo Risco de viés**<br>**Sobrevida global risco favorável**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo (IC95%)**|**Certeza**|
|1<br>ECR<br>**Sobrevida global risco intermediário**|Não grave|Não grave|Não grave|Muito grave<sup>a</sup>|Nenhum|HR 0,64<br>(0,24 para 1,62)|⨁⨁◯◯<br>BAIXA|
|1<br>ECR<br>**Sobrevida global risco alto**|Não grave|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|HR 0,53<br>(0,35 para 0,82)|⨁⨁◯◯<br>BAIXA|
|||||||HR 0,43|⨁⨁◯◯|
|1<br>ECR<br>**Sobrevida livre de progressão risco favo**|Grave<sup>c</sup><br>**rável**|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|<br>(0,23 para 0,81)|BAIXA|
|1<br>ECR|Grave<sup>d</sup>|Não grave|Não grave|Muito grave<sup>a</sup>|Nenhum|HR 0,81<br>(0,53 para 1,24)|⨁◯◯◯<br>MUITO<br>BAIXA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida livre de progressão risco intermediário** -->
47  
|||**Certe**|**za da evidência**||||**Efeito**||
|---|---|---|---|---|---|---|---|---|
|**№ dos estudos**|**Delineamento do**<br>**estudo Risco de viés**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo (IC95%)**|**Certeza**|
|1|ECR|Grave<sup>d</sup>|Não grave|Não grave|Não grave|Nenhum|HR 0,70<br>(0,54 para 0,91)|⨁⨁⨁◯<br>MODERADA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida livre de progressão risco alto** -->
|1<br>**e resposta obje**|ECR<br>**tiva**|Grave<sup>d</sup>|Não grave|Não grave|Grave<sup>b</sup>|Nenhum|HR 0,58<br>(0,35 para 0,94)|⨁⨁◯◯<br>BAIXA|
|---|---|---|---|---|---|---|---|---|
|1<br>**s adversos**|ECR|Grave<sup>d</sup>|Não grave|Não grave|Não grave|Nenhum|OR 2,28<br>(1,74 para 3,00)|⨁⨁⨁◯<br>MODERADA|
|1|ECR|Grave<sup>d</sup>|Não grave|Não grave|Muito grave<sup>a</sup>|Nenhum|OR 1,22<br>(0,92 para 1,62)|⨁◯◯◯<br>MUITO<br>BAIXA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos** -->
**ECR** : ensaio clínico randomizado; **IC95:** intervalo de confiança de 95%; **HR:** _Hazard Ratio_ ; **OR:** _Odds ratio_

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos** -->
a. Intervalo de confiança amplo favorecendo as duas tecnologias  
b. Intervalo de confiança amplo  
c. Pequena amostra da população  
d. Estudo aberto - pacientes, centros participantes e médicos administrando terapia e avaliando a tecnologia não foram mascarados para atribuição de tratamento.  
48  
**Tabela D** - Certeza da evidência para nivolumabe com ipilimumabe comparado a sunitinibe para carcinoma de células renais.  
|||**Ce**|**rteza da evidência**||||**Efeito**||
|---|---|---|---|---|---|---|---|---|
|**№ dos estudos**|**Delineamento do**<br>**estudo Risco de viés**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo (IC95%)**|**Certeza**|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida global risco intermediário** -->
|1<br>**ida global ri**|ECR<br>**sco alto**|Não grave|Não grave|Não grave|Grave<sup>a</sup>|Nenhum|HR 0,66<br>(0,50 para 0,87)|⨁⨁⨁◯<br>MODERADA|
|---|---|---|---|---|---|---|---|---|
|1|ECR|Grave<sup>b</sup>|Não grave|Não grave|Grave<sup>a</sup>|Nenhum|HR 0,57<br>(0,39 para 0,83)|⨁⨁◯◯<br>BAIXA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida livre de progressão risco intermediário** -->
|**1**<br>**ida livre de p**|ECR<br>**rogressão risco alto**|Grave<sup>c</sup><br>|Não grave|Não grave|Não grave|Nenhum|HR 0,66<br>(0,53 para 0,81)|⨁⨁⨁◯<br>MODERADA|
|---|---|---|---|---|---|---|---|---|
|1|ECR|Muito<br>grave<sup>b,c</sup>|Não grave|Não grave|Não grave|Nenhum|HR 0,57<br>(0,43 para 0,76)|⨁⨁◯◯<br>BAIXA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta objetiva** -->
49  
|||**Cer**|**teza da evidência**||||**Efeito**||
|---|---|---|---|---|---|---|---|---|
|**№ dos estudos**|**Delineamento do**<br>**estudo Risco de viés**|**Risco de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Relativo (IC95%)**|**Certeza**|
|1|ECR|Grave<sup>c</sup>|Não grave|Não grave|Grave<sup>a</sup>|Nenhum|OR 1,36<br>(1,06 para 1,74)|⨁⨁◯◯<br>BAIXA|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos** -->
|1<br>ECR|Grave<sup>c</sup>|Não grave|Não grave|Não grave|Nenhum|OR 0,50<br>(0,39 para 0,64)|⨁⨁⨁◯<br>MODERADA|
|---|---|---|---|---|---|---|---|  
**ECR** : ensaio clínico randomizado; **IC95:** intervalo de confiança de 95%; **HR:** _Hazard Ratio_ ; **OR:** _Odds ratio_

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos** -->
a. Intervalo de confiança amplo  
b. Número da amostra pequeno  
c. Estudo aberto - pacientes, centros participantes e médicos administrando terapia e avaliando a tecnologia não foram mascarados para atribuição de tratamento  
50

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **E. Referências** -->
1. Massari F, Mollica V, Rizzo A, Cosmai L, Rizzo M, Porta C. Safety evaluation of immune-based combinations in patients with advanced renal cell carcinoma: a systematic review and meta-analysis. Expert Opin Drug Saf [Internet]. 2020;19(10):1329–38. Available from: https://doi.org/10.1080/14740338.2020.1811226  
2. Cao G, Wu X, Wang Z, Tian X, Zhang C, Wu X, et al. What is the optimum systemic treatment for advanced/metastatic renal cell carcinoma of favourable, intermediate and poor risk, respectively? A systematic review and network meta-analysis. BMJ Open. 2020;10(8).  
3. Elaidi R, Phan L. Comparative E ffi cacy of First-Line Immune-Based Combination Therapies in Metastatic Renal Cell Carcinoma : A Systematic Review and.  
4. Motzer RJ, Escudier B, McDermott DF, Arén Frontera O, Melichar B, Powles T, et al. Survival outcomes and independent response assessment with nivolumab plus ipilimumab versus sunitinib in patients with advanced renal cell carcinoma: 42-month follow-up of a randomized phase 3 clinical trial. J Immunother Cancer. 2020;8(2).  
5. Sterne JAC, Savović J, Page MJ, Elbers RG, Blencowe NS, Boutron I, et al. RoB 2: A revised tool for assessing risk of bias in randomised trials. BMJ. 2019;366.  
6. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: A critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;  
7. Mori K, Mostafaei H, Miura N, Karakiewicz PI, Luzzago S, Schmidinger M, et al. Systemic therapy for metastatic renal cell carcinoma in the first-line setting: a systematic review and network meta-analysis. Cancer Immunol Immunother [Internet]. 2021;70(2):265–73. Available from: https://doi.org/10.1007/s00262-020-02684-8  
8. Motzer RJ, Escudier B, George S, Hammers HJ, Srinivas S, Tykodi SS, et al. Nivolumab versus everolimus in patients with advanced renal cell carcinoma: Updated results with long-term follow-up of the randomized, open-label, phase 3 CheckMate 025 trial. Cancer. 2020;126(18):4156–67.  
51

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **MATERIAL SUPLEMENTAR B - PERGUNTA PICO 2** -->
**Questão de pesquisa:** “Qual a eficácia, segurança e a custo-efetividade, em segunda linha de tratamento, do levomalato de cabozantinibe ou nivolumabe em comparação ao everolimo, pazopanibe, sunitibe, ipilimumabe, axitinibe e pembrolizumabe para pacientes adultos com CCR metastático?”.  
Nesta pergunta, o acrônimo PICO era:  
Pacientes (P): CCR metastático pós-terapia antiangiogênica  
Intervenção (I): nivolumabe e cabozantinibe  
Comparadores (C): everolimo, pazopanibe, sunitinibe, ipilimumabe, axitinibe e pembrolizumabe  
_Outcomes_ /desfechos (O):sobrevida global, sobrevida livre de progressão, taxa de resposta.

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **A. Estratégia de busca** -->
A estratégia de busca referente a esta pergunta está descrita no **Quadro D** .  
**Quadro D -** Estratégias de busca nas bases de dado PubMed e Embase.  
|**Base de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**Medline via**<br>**PubMed**|((kidney neoplasms[MeSH Terms]) OR (kidney"[All Fields] AND<br>neoplasms[All Fields]) OR (“kidney neoplasms"[All Fields]) OR (renal[All<br>Fields] AND cancer[All Fields]) OR (Carcinoma, Renal cell/) OR (renal cell<br>carcinoma[Title/Abstract]) OR ("metastatic renal cell carcinoma"[All Fields]))<br>AND (("sunitinib"[MeSH Terms] OR "sunitinib"[All Fields] OR "sunitinib<br>s"[All Fields]) OR ("pazopanib"[All Fields] OR ("axitinib"[All Fields]) OR<br>("pembrolizumab"[All Fields]) OR ("ipilimumab"[All Fields]) OR<br>("nivolumab"[All Fields]) OR ("everolimus"[All Fields]) OR<br>("cabozantinib"[All Fields])) AND ((randomized controlled trial[Publication<br>Type]) OR (Controlled clinical trial[Publication Type]) OR<br>(randomized[Title/Abstract]) OR (randomly[Title/Abstract]) OR<br>(trial[Title/Abstract]))<br>Data de acesso: 03/08/2020.|1078|
|**EMBASE**|(('kidney neoplasms':kw) OR (('kidney'/exp OR kidney) AND ('neoplasm'/exp<br>OR neoplasm)) OR (('kidney'/exp OR kidney) AND ('cancer'/exp OR cancer))<br>OR (('renal'/exp OR renal) AND ('cancer'/exp OR cancer)) OR ('renal cell<br>carcinoma'/exp OR 'renal cell carcinoma') OR ('renal cell carcinoma':ab,ti) OR<br>('metastatic renal cell carcinoma'/exp OR 'metastatic renal cell carcinoma' OR<br>(metastatic AND ('renal'/exp OR renal) AND ('cell'/exp OR cell) AND<br>('carcinoma'/exp OR carcinoma))) OR ('kidney metastasis'/exp OR 'kidney|4764|  
52  
|**Base de dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
||metastasis')) AND (('sunitinib'/exp OR sunitinib) OR ('pazopanib'/exp OR<br>pazopanib) OR ('axitinib'/exp OR axitinib) OR ('pembrolizumab'/exp OR<br>pembrolizumab) OR ('ipilimumab'/exp OR ipilimumab) OR ('nivolumab'/exp<br>OR nivolumab) OR ('everolimus'/exp OR everolimus) OR ('cabozantinib'/exp<br>OR cabozantinib)) AND (('randomized controlled trial'/exp OR 'randomized<br>controlled trial' OR (randomized AND controlled AND ('trial'/exp OR trial)))<br>OR ('controlled clinical trial'/exp OR 'controlled clinical trial') OR||
||(randomized:ti,ab,kw) OR (randomly:ti,ab,kw) OR (trial:ti,ab,kw))<br>Data de acesso: 03/08/2020.||
|**Total:**||5842|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **B. Seleção das evidências** -->
A busca das evidências resultou em 5.842 referências (1.078 no MEDLINE e 4.764 no EMBASE). A revisão sistemática por estudos clínicos identificou 4.898 registros depois de remoção de duplicidades, dos quais 4.624 foram considerados irrelevantes durante a triagem e 263 foram excluídos após leitura dos textos na íntegra. Desta forma, foram incluídos 13 estudos na análise final. Doze estudos foram identificados por busca manual, mediante o acesso às referências dos artigos incluídos neste estudo e revisões publicadas anteriormente, as quais não foram identificadas na busca inicial. Entretanto, após leitura do texto completo, esses estudos não foram incluídos na análise final. Ao todo, 11 ensaios clínicos foram incluídos na presente revisão, conforme **Figura 16** .  
53  
**Figura 16 -** Fluxograma de seleção dos estudos.  
<!-- Start of picture text -->
2 | | Publicacdes identificadas por<br>=© | | meio da pesquisa nas basesde Busca Manual<br>§ PUBMEDdados:(n= 1078) (n=12)<br>3 EMBASE (n= 4764)<br>$ Registros rastreados agave anette<br>F (0=4898) (n=4624 )<br>Publicagées selecionadas PublicagBes excluidas segundo<br>g para leitura (n= 274) critérios de excluséo:<br>3 (0=263)<br>3<br>gz Estudos(n=13) incluidos<br>3 || _ tnctuidos na sintese qualitativa (n= 14)<br>| |  inctuidos na sintese quantitativa (n= 10)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **C. Descrição dos estudos e resultados** -->
Os estudos incluídos para responder esta pergunta estão descritos na **Tabela E** .  
**Tabela E** - Estudos incluídos.  
|**Referência**|**Registo no Clinical Trials**|**Nome do Estudo**|**Comparadores**|
|---|---|---|---|
|Eichelberg et al., 2015<sup>8</sup>|NCT00732914|SWITCH|Sorafenibe_vs_Sunitinibe|
|Escudier et al., 2007<sup>7</sup>|NCT00073307|TARGET|Sorafenibe_vs_Placebo|
|Hutson et al., 2014<sup>6</sup>|NCT00474786|INTORSECT|Tensirolimo_vs_Sorafenibe|
|Motzer et al., 2010<sup>10</sup>|NCT00410124|RECORD-1|Everolimo_vs_Placebo|
|Motzer et al., 2013<sup>11</sup>|NCT00678392|AXIS|Axitinibe_vs_Sorafenibe|
|Motzer et al., 2014<sup>5</sup>|NCT00903175|RECORD-3|Everolimo_vs_Sunitinibe|
||||Lenvatinibe associado ao|
|Motzer et al., 2015<sup>3</sup>|NCT01136733|HOPE-205|everolimo_vs_Lenvatinibe_vs_<br>Everolimo|
|Motzer et al., 2020<sup>1</sup>|NCT01668784|CheckMate|Everolimo_vs_Nivolumabe|
|Powles et al., 2018<sup>9</sup>|NCT01865747|METEOR|Cabozantinibe_vs_Everolimo|
|Retz et al., 2019<sup>2</sup>|NCT01613846|SWITCH-2|Sorafenibe_vs_Pazopanibe|
|Voss et al., 2019<sup>12</sup>|NCT01727336|DART|Axitinibe_vs_Dalantercepte<br>associado ao axitinibe|  
**D. Risco de viés, avalição da qualidade do relato e qualidade da evidência**  
54  
O **Quadro G** descreve a avaliação do risco de viés dos ensaios clínicos selecionados para responder essa pergunta.  
**Quadro G -** Avaliação do risco de viés nos ensaios clínicos (ROB v2.0).  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdidos**|**Mensuração do**<br>**desfecho**|**Seleção**<br>**do**<br>**resultado**<br>**reportado**|**Viés**<br>**global**|
|---|---|---|---|---|---|---|
|Eichelberg et al.,<br>2015<sup>8</sup>|baixo risco|baixo risco|baixo<br>risco|algumas<br>preocupações.|alto risco|alto risco|
|Escudier et al.,<br>2007<sup>7</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Hutson et al.,<br>2014<sup>6</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Motzer et al.,<br>2010<sup>10</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Motzer et al,<br>2013<sup>11</sup>|baixo risco|baixo risco|baixo<br>risco|algumas<br>preocupações.|baixo<br>risco|algumas<br>preocupações.|
|Motzer et al.,<br>2014<sup>5</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Motzer et al.,<br>2015<sup>3</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Motzer et al.,<br>2020<sup>1</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Powles et al.,<br>2018<sup>9</sup>|baixo risco|baixo risco|baixo<br>risco|baixo risco|baixo<br>risco|baixo risco|
|Retz et al., 2019<sup>2</sup>|baixo risco|baixo risco|baixo<br>risco|algumas<br>preocupações.|alto risco|alto risco|
|Voss et al., 2019<sup>12</sup>|baixo risco|baixo risco|baixo<br>risco|algumas<br>preocupações.|baixo<br>risco|algumas<br>preocupações.|

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **E. Análise da evidência** -->
**Meta-análises dos dados**  
**Sobrevida livre de progressão**  
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes<sup>1–9</sup> . A **Figura 17** demonstra a rede, na qual o tamanho dos nós representa o número de estudos; a cor dos nós representa o _indirectness;_ a espessura das linhas representa o tamanho da amostra; e a cor das linhas representa o risco de viés. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções.  
55  
Para este desfecho, existem 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 estimativas de efeito relativo ( **Quadro E** ). Estes resultados foram apresentados por meio de uma matriz chamada tabela de classificação, a qual contém todos informações sobre a eficácia relativa e sua incerteza para todos os pares de intervenções possíveis.  
**Figura 17** - _Network Plot_ da NMA para sobrevida livre de progressão.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
56  
**Quadro E -** _League table_ da NMA para sobrevida livre de progressão.  
<!-- Start of picture text -->
Axitinibe “2.919 0.681 -8.419 1.219 0.981 1.800 4.483 2.600 0.821 2.200<br>~10.233; 4.394 | -5.420;6.782 | -18.370;1532 | -8.921;6.482 | -6.295;8.256 | -3.864;7.464 | -0.953,9.920 | -1.457;6.657 | -4.620;6263 | -3.427; 7.827<br>~4.394;2.919 10.233 Cabozantinibe 0.432;3.600 7.632 -4.493;7.8931.700 | -1.754;9.5543.300 | -2536;11.9754718  | 2.038;7.40 12.767 | -0.565;5519 11.604 | -2.595;3741 10.07 | -2.108;5.419 12.346<br>-0.681 -3.600 Everolimo -9.100 1.900 0.300 1419 3.803 1919 0.141 1519<br>~6.782;5.420 | -7.632; 0.432 -16.961;-1.239 | -6.601;2.801 | -3.663;4.263 | -4.913;7.152 | 0.265;7.340 | -2.637;6.476 | -4.747;5.028 | -4.478;7.517<br>8.419<br>Lenvatini_ 7.200 9.400 10.219 12.903 11.019 9.241 10.619<br>-1.532; 18.370 -0.784; 15.184 | 0.596; 18.204 | 0.311; 20.128 | 4.282; 21.523 | 1.933; 20.106 | -0.016; 18.497 | 0.732; 20.507<br>1.219 1.700 1.900 -7.200 Lenvatinibe 2.200 3.019 5.703 3.819 2.041 3.419<br>6.482;8.921 | -7.893;4.493 | -2.801;6.601 | -15.184;0.784 | [>| -3.948;8.348 | -4.628; 10.667 | -0.181; 11586 | -2.727; 10.366 | -4.740;8.822 | -4.201; 11.040<br>-0.981 -3.900 -0.300 -3.400 -2.200 Nivolumabe 0.819 3.503 1.619 -0.159 1.219<br>-8.256;6.295 | -9.554;1.754 | -4.263; 3.663 | -18.204;-0.596 | -8.348; 3.948 -6.398; 8.037 | -1.810;8.815 | -4.419;7.658 | -6.451;6.133 | -5.969; 8.408<br>-1.800 4.719 1.119 -10.219 -3.019 -0.819 2.683 0.800 -0.979 0.400<br>-7.464;3.864 | -11.975;2.536 | -7.152;4.913 | -20.128;-0.311 | -10.667; 4.628 | -8.037;6.398 Pazopanibe -2.676; 8.042 | -3.153,4.753 | -6.343;4.386 | -5.152;5.952<br>~4.483 -7.403 -3.803 -12.903 -5.703 -3.503 -2.683 Placebo -1.883 -3.662 -2.283<br>-9.920;0.953 | -12.767;-2.038 | -7.340; -0.265 | -21.523;-4.282 | -11.586;0.181 | -8.815;1810 | -8.042;2.676 5.502; 1.736 | -8.255;0.931 | -7.603; 3.037<br>-6.657;1.457-2.600 | -11.604;0.565“5.519 | -6.476;-1919 2.637 | -20.106;-1.933-11.019 | -10.366;2.727-3.819 | -7.658;4.419“1619 | -4.753;3.153-0.800 | -1.736;5.5021.883 Sorafenibe -5.405;1.779 1.848 | -4.300;3.500-0.400<br>-6.263;4.620-0.821 | -10.077;2.595“3.741 | -5.028;4.7470.141 | -18.497;0.016-9.241 | -8.822;4.740-2.041 | -6.133;6.4510.159 | -4386;63430.979 | -0.931;8.2553.662 | -1.848;5.4051779 Sunitinibe -3.947;1379 6.708<br>-2.200 “5.119 1519 -10.619 -3.419 “1219 -0.400 2.283 0.400 “1379 Tensirolimo<br>-7.827;3.427 | -12.346;2.108 | -7.517;4.478 | -20.507;-0.732 | -11.040; 4.201 | -8.408;5.969 | -5.952;5.152 | -3.037;7.603 | -3.500;4.300 | -6.704; 3.947<br><!-- End of picture text -->  
Nota: Médias com valores inferiores a 0 favorecem o medicamento listado na coluna; médias com valores superiores a 0 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística **.**  
57

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida global** -->
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes<sup>1–9</sup> . A **Figura 18** demonstra a análise em rede, a qual considerou o tamanho e a cor dos nós conforme número de estudos e _indirectness,_ respectivamente; a espessura e a cor das linhas conforme tamanho da amostra risco de viés, respectivamente.  
A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Para este desfecho, foram consideradas 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 estimativas de efeito relativo ( **Quadro F** ).  
**Figura 18** - _Network Plot_ da NMA para sobrevida global.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
58  
**Quadro F -** _League table_ da NMA para sobrevida global.  
<!-- Start of picture text -->
Axitinibe “1518 3.382 “6.718 -0.318 “2.718 6.200 3.628 0.900 “2.702 5.200<br>-9.024;5.988 | -3.626;10.390 | -16.901;3.465 | -10.284;9.647 | -10.885;5.448 | -2.366;14.766 | -1.474;8.730 | -3.012;4.812 | -12.267;6.863 | 0.087;10.313<br>1.518 Cabozantinibe 4,900 5.200 1.200 ~1.200 7.718 5.146 2.418 “1.184 6.718<br>-5.988;9.024 2.210;7.590 | -13.062;2.662 | -6.379;8.779 | -6.181;3.781 | -2.237;17.674 | -0.527;10.819 | -3.988;8.824 | -9.535;7.168 | -0.484;13.921<br>-3.382 -4,900 Everolimo -10.100 “3.700 -6.100 2.818 0.246 “2.482 ~6.084 1.818<br>-10.390;3.626 | -7.590; -2.210 -17.488; -2.712 | -10.785;3.385 | -10,293; -1.907 | -6.767;12.403 | -4.749;5.241 | -8.296;3.332 | -13.990;1.822 | -4.863;8.500<br>6.718 5.200 10.100 Lenvatinibe 6.400 4.000 12.918 10.346 7.618 4.016 11.918<br>-3.465;16.901 | -2.662;13.062 | 2.712;17.488 -2,395;15.195 | -4.495;12.495 | 0.816;25.020 | 1.428;19.264 | -1.783;17.019 | -6.805;14.837 | 1.957;21.879<br>0.318 -1.200 3.700 -6.400 Lenvatinibe -2.400 6.518 3.946 1.218 “2.384 5.518<br>-9.647;10.284 | -8.779;6.379 | -3.385;10.785 | -15.195;2.395 | Tvl) -10.633;5.833 | -5.401;18.438 | -4.723;12.615 | -7.947;10.384 | -13.001;8.233 | -4.221;15.257<br>2.718 1.200 6.100 -4,000 2.400 8.918 6.346 3.618 0.016 7.918<br>Nivolumabe<br>-5.448;10.885 | -3.781;6.181 | 1.907;10.293 | -12.495;4.495 | -5.833;10.633 -1.544;19.380 | -0.175;12.868 | -3.550;10.786 | -8.933;8.965 | 0.030;15.806<br>-6.200 7.718 -2.818 -12.918 6.518 -8.918 -2.572 -5.300 -8.902 -1.000<br>-14.76;62.366 | -17.674;2.237 | -12.403;6.767 | -25.020; -0.816 | -18.438;5.401 | -19.380;1.544 Pazopanibe -10.867;5.723 | -12.921;2.321 | -20.489;2.685 | -9.301;7.301<br>-8.730;1.474“3.628 | -10.819;0.527“5.146 | -5.241;4.749-0.246 | -19.264;~10.346 -1.428 | -12.615;4.723“3.946 | -12.868,0.175-6.346 | -5.723;10.8672.572 Placebo -6.003;0.548“2.728 | -14.884;2.223~6.330  | -3.072;6.2161572<br>-0.900 2.418 2.482 7.618 “1.218 3.618 5.300 2.728 Sorafenibe -3.602 4,300<br>-4.812;3.012 -8.824;3.988 -3.332;8.296 -17.019;1.783 | -10.384;7.947 | -10.786;3.550 | -2.321;12.921 | -0.548;6.003 -12.331;5.126 | 1.008;7.592<br>2.702 1.184 6.084 ~4.016 2.384 -0.016 8.902 6.330 3.602 Sunitinibe 7.902<br>~6.863;12.267 -7.168;9.535 | -1.822;13.990 | -14.837;6.805 | -8.233;13.001 -8.965;8.933 -2.685;20.489 | -2.223;14.884 | -5.126;12.331 -1.427;17.231<br>-5.200 6.718 “1818 “11.918 5.518 -7.918 1.000 “1572 -4,300 -7.902 Tensirolimo<br>~10.313; -0.087 | -13.921;0.484 | -8.500;4.863 | -21.879; -1.957 | -15.257;4.221 | -15.806;-0.030 | -7.301;9.301 | -6.216;3.072 | -7.592;-1.008 | -17.231;1.427<br><!-- End of picture text -->  
Nota: Médias com valores inferiores a 0 favorecem o medicamento listado na coluna; médias com valores superiores a 0 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística  
59

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta clínica** -->
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes<sup>1–9</sup> . A rede construída apara o desfecho taxa de resposta clínica pode ser vista na **Figura 19** . Para este desfecho, a NMA incluiu um total de 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), sendo feitas 55 estimativas de efeito relativo entre as possíveis comparações ( **Quadro G** ).  
**Figura 19 -** _Network Plot_ da NMA para taxa de resposta clínica.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
60  
**Quadro G -** _League table_ da NMA para taxa de resposta clínica.  
<!-- Start of picture text -->
0,433 2,976 0,516 0,250 0,432 0,951 14,092 2321 0,755 2,391<br>Axitinibe 0,103;1,817 | 0,914;9,688 | 0,088;3,025 | 0,044;1,441 | 0,118;1,579 | 0,359;2,521 | 5,944;33,415 | 1,496;3,600 | 0,257;2,217 | 1,095;5,219<br>2,309 6,870 1,190 0,578 0,997 2,196 32,534 5,358 1,742 5,519<br>0,550; 9,687 Cabozantinibe 3,043; 15,515 | 0,253; 5,606 | 0,126;2,663 | 0,376;2,644 | 0,43511,084 | 7,235 46,321 | 1,368; 20,983 | 0,655;4,638 | 1,219; 24,988<br>0,103;0,336 1,094 | 0,064;0,146 0,329 Everolimo 0,046;0,173 0,647 | 0,023;0,3060,084 | 0,085;0,2480,145 | 0,079;1,2950,320 | 1,33816,7574,736 | 0,261;2,3320,780 | 0,147;0,4370,254 | 0,225;0,803 2,865<br>0,331;1,939 11,380 | 0,178;3,9560,840 | 1,545;5,77221,568 Lenvatinibe 0,213;0,4861,109 | 0,202;0,837 3,476 | 0,270;1,84512,611 | 4,40269,72827,333 | 0,811;4,9884,501 | 0,352;1,464 6,091 | 0,743;4,637 28,951<br>3,994 1,730 11,885 2,059 Lenvatinibe 1,724 3,799 36,278 9,267 3,014 9,548<br>0,694; 22,982 | 0,376; 7,968 | 3,265; 43,263 | 0,901;4,704 | eum | 0,425;6,986 | 0,566 25,508 | 9,23642,955 | 1,703;0,431 | 0,742; 12,242 | 1,558; 58,504<br>0,633;2317 8,474 | 0,378;2,6631,003 | 4,028;11,7996,894 | 0,288;1,194 4,959 | 0,143;0,580 2,351 Nivolumabe 0,4929,8632,204 | 8,270128,88232,649 | 1,587;18,2145,376 | 0,814;1,749 3,754 | 1,392;5,538 22,025<br>0,397;1,051 2,786 | 0,090;0,455 2,298 | 0,772;3,129 12,676 | 0,079;0,542 3,706 | 0,039;1,7680,263 | 0,101;0,454 2,031 Pazopanibe 4,718;14,816 46,525 | 1,022;2,440 5,823 | 0,213;2,9510,794 | 0,851;2,513 7,426<br>0,071 0,031 0,211 0,037 0,018 0,031 0,067<br>Placet_ 0,165 0,054 0,170<br>0,030; 0,168 | 0,007;0,138 | 0,060;0,747 | 0,006;0,227 | 0,003;0,108 | 0,008;0,121 | 0,021; 0,212 0,078; 0,346 | 0,016;0,175 | 0,063; 0,454<br>0,431 0,187 1,282 0,222 0,108 0,186 0,410 6,073 0,325 1,030<br>0,278; 0,668 | 0,048;0,731 | 0,429;3,836 | 0,040; 1,233 | 0,020;0,587 | 0,055;0,630 | 0,172;0,978 | 2,888; 12,771 Sorafenibe 0,122; 0,870 | 0,540; 1,965<br>0,451;1325 3,892 | 0,216;1,5280,574 | 2,291;6,7883,943 | 0,164;0,683 2,843 | 0,082;1,3470,332 | 0,266;1,2280,572 | 0,339;4,6881,260 | 5,721;60,94118,672 | 1,149;3,075 8,227 Sunitinibe7 0,976;3,167 10,277<br>0,418 0,181 1,245 0,216 0,105 0,181 0,398 5,895 0971 0,316<br>0,192; 0,913 | 0,040;0,820 | 0,349; 4,440 | 0,035; 1,347 | 0,017;0,642 | 0,045;0,718 | 0,135; 1,176 | 2,202;15,778 | 0,509;1,851 | 0,097; 1,024 Tensirolimo<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
61

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta completa** -->
A rede para este desfecho foi composta por dez estudos, os quais totalizaram 5.028 participantes ( **Figura 20** )<sup>1–9</sup> . A rede incluiu um total de 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 possibilidades de comparação dois a dois ( **Quadro H** ).  
**Figura 20** - _Network Plot_ da NMA para taxa de resposta completa.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
62  
**Quadro H -** _League table_ da NMA para taxa de resposta completa.  
<!-- Start of picture text -->
Axitinibe 4.642 4.614 1.569 4.706 2.230 1.224 2.719 1.003 1.477 3.104<br>0.009;2465.130 | 0.034;618.007 | 0.004;551.973 | 0.009;2524.252 | 0.013;408.953 | 0.010;150.491 | 0.023;326.229 | 0.020;50.673 | 0.014;154.038 | 0.020;491.961<br>0.215 0.994 0.338 1.014 0.493 0.264 0.586 0.216 0.318 0.669<br>0.000;14.388 Cabozantinibe 0.020;50.239 | 0.002;54.201 | 0.004;263.170 | 0.007;35.517 | 0.001;73.840 | 0.004;83.873 | 0.002;28.936 | 0.004;27.413 | 0.002;232.921<br>0.217 1.006 Everolimo 0.340 1.020 0.496 0.265 0.589 0.217 0.320 0.673<br>0.002;29.026 | 0.020;50.856 0.014;8.543 | 0.020;52.389 | 0.090;2.725 | 0.005;15.152 | 0.028;12.347 | 0.012;4.078 | 0.039;2.650 | 0.009;51.811<br>0.638 2.960 2.942 Lenvatinibe 3.000 1.460 0.781 1.733 0.639 0.942 1.979<br>0,002;24.348 | 0.018;474.756 | 0.117;73.929 0.119;75.369 | 0.038;55.964 | 0.004;137.662 | 0.021;145.897 | 0.008;49.924 | 0.020;44.483 | 0.009;442.438<br>0.213 0.987 0.981 0.333 Lenvatinibe 0.487 0.260 0.578 0.213 0.314 0.660<br>0.000;114.000 | 0.004;256.134 | 0.019;50.375 | 0.013;8.375 Everolimo. 0.007;35.563 | 0.001;73.670 | 0.004;83.814 | 0.002;28.919 | 0.004;27.432 | 0.002;232.293<br>0.437 2.027 2.015 0.685 2.055 0.535 1.187 0.438 0.645 1.355<br>Nivolumabe<br>0.002;77.968 | 0.028;145.941 | 0.367;11.061 | 0.018;26.251 | 0.028;150.145 0.007;43.056 | 0.036;38.788 | 0.015;12.998 | 0.043;9.735 | 0.013;144.027<br>0.817 3.792 3.769 1.281 3.844 1.871 2.220 0.819 1.207 2.535<br>Pazopanibe<br>0.007;100.404 | 0.014;1061.672 | 0.066;215.228 | 0.007;225.969 | 0.014;1088.330 | 0.023;150.656 0.044;110.930 | 0.050;13.287 | 0.029;50.689 | 0.036;177.221<br>0.368 1.708 1.697 0.577 1.731 0.842 0.450 0.369 0.543 1.142<br>0.003;44.141 | 0.0122;44.594 | 0.081;35.570 | 0.007;48.570 | 0.012;251.112 | 0.026;27.528 | 0.009;22.497 Placebo_ 0.024;5.739 | 0.024;12.058 | 0.017;77.665<br>0.997 4.630 4.602 1.564 4.693 2.284 1.221 2711 Sorafenibe~~ 1.473 3.095<br>0.020;50.395 | 0.0356;20.174 | 0.245;86.358 | 0.020;122.156 | 0.035;636.892 | 0.077;67.803 | 0.075;19.806 | 0.174;42.182 0.122;17.795 | 0.126;76.340<br>0.677 3.142 3.123 1.062 3.185 1.550 0.829 1.840 0.679 Sunitinibe 2.101<br>0.006;70.570 | 0.0362;70.670 | 0.377;25.847 | 0.022;50.139 | 0.036;278.300 | 0.103;23.392 | 0.020;34.810 | 0.083;40.829 | 0.056;8.197 0.036;121.754<br>0.322 1.496 1.487 0.505 1516 0.738 0.394 0.876 0.323 0.476 Tensirolimo<br>0.002;51.060 | 0.0045;21.026 | 0.019;114.503 | 0.002;112.979 | 0.004;533.895 | 0.007;78.406 | 0.006;27.572 | 0.013;59.573 | 0.013;7.968 | 0.008;27.586<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
63

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta parcial** -->
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes<sup>1–9</sup> .  A rede construída para este desfecho pode ser vista na **Figura 21** . A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções. Foram incluídas um total de 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 estimativas de efeito relativo ( **Quadro I** ).  
**Figura 21 -** _Network Plot_ da NMA para taxa de resposta parcial.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
64  
**Quadro I -** _League table_ da NMA para taxa de resposta parcial.  
<!-- Start of picture text -->
Axitinibe 0.370 2.543 0.240 0.429 0.343 0.873 13.621 2.321 0.647 2.261<br>0.084;1.640 0.731;8.844 0.040;1.443 0.070;2.634 0.087;1.346 0.317;2.405, 5.737;32.343 1.496;3.600 0.205;2.043 1.029;4.968<br>2.701 6.870 0.647 1.159 0.925 2.359 36.796 6.269 1.748 6.109<br>0.610;11.972 Cabozantinibe 3,043;15.515 | 0.141;2.981 | 0.246;5.463 | 0.343;2.495 | 0.435;12.788 | 7.813;173.313 | 1.511;26.003 | 0.652;4.686 | 1.277;29.230<br>0.113;1.3670.393 | 0,064;0.3290.146 Everolimo 0.026;0.3430.094 | 0.045;0.6310.169 | 0.076;0.2370.135 | 0.078;1.5100.343 | 1.433;20.0155.356 | 0.284;2.9290.912 | 0.146;0.4430.254 | 0.234;3.3850.889<br>4.173 1.545 10.613 1.790 1.429 3.643 56.838 9.683 2.701 9.437<br>Lenvatinibe<br>0.693;25.118 0.335;7.114 2.916;38.629 0.782;4.096 0.349;5.857, 0.510;26.008 8.975;359.999 1.699;55.197 0.662;11.020 1.470;60.558<br>2.331 0.863 5.928 0.559 Lenvatinibe 0.798 2.035, 31.747 5.409 1.508 8.271<br>0.380;14.311 | 0.183;4.067 | 1.585;22.174 | 0.244;1.278 | 7 | 0.190;3.355 | 0.280;14.791 | 4.917;204.977 | 0.930;31.466 | 0.361;6.312 | 0.806;34.477<br>0.743;11.4752.919 | 0.401;2.9141.081 | 4.215;13.0797.425 | 0.171;2.8670.700 | 0.298;5.2641.253 Nivolumabe 0.522;12.4462.549 | 9.472;166.96839.766 | 1.853;24.7726.775 | 0.855;4.1761.889 | 1.546;28.1946.602<br>1.145 0.424 2.913 0.274 0.491 0.392 15.600 2.658 0.741 2.590<br>0.416;3.154 | 0.078;2.299 | 0.662;12.811 | 0.038;1.959 | 0.068;3.572 | 0.080;1.916 Pazopanibe 4,801;50.689 | 1.067;6.623 | 0.183;3.009 | 0.843;7.959<br>0.073 0.027 0.187 0.018 0.031 0.025 0.064 0.170 0.048 0.166<br>Placebo<br>0.031;0.174 0.006;0.128 0.050;0.698 0.003;0.111 0.005;0.203 0.006;0.106 0.020;0.208 0.081;0.359 0.014;0.164 0.062;0.447<br>0.431 0.160 1.096 0.103 0.185, 0.148 0.376 5.870 0.279 0.974<br>0.278;0.668 0.038;0.662 0.341;3.518 0.018;0.589 0.032;1.076 0.040;0.540 0.151;0.938 2.787;12.364 Sorafenibe 0.096;0.807 0.507;1.873<br>0.489;4.8781545 | 0.213;1.5330.572 | 2.255;6.8473,929 | 0.091;1.5110.370 | 0.158;2.7740.663 | 0.239;1.1700.529 | 0.332;5.4761.349 | 6.080;72.85021.046 | 1.239;10.3753.586 Sunitinibe 1.004;12.1623.494<br>0.442 0.164 1.125 0.106 0.190 0.151 0.386 6.024 1.026 0.286 Tensirolimo<br>0.201;0.972 | 0.034;0.783 | 0.295;4.281 | 0.017;0.680 | 0.029;1.241 | 0.035;0.647 | 0.126;1.186 | 2.236;16.226 | 0.534;1.972 | 0.082;0.996<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
65

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta – doença estável** -->
A rede foi composta por dez estudos, os quais totalizaram 5.028 participantes ( **Figura 22** )<sup>1–9</sup> . A rede construída para este desfecho pode ser vista na Figura 22. A NMA permitiu comparar o efeito relativo entre qualquer par de intervenções, nesta análise composta por 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 estimativas de efeito relativo ( **Quadro J** ).  
**Figura 22 -** _Network Plot_ da NMA para taxa de resposta para doença estável **.**  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
66  
**Quadro J -** _League table_ da NMA para taxa de resposta para doença estável.  
<!-- Start of picture text -->
Axitinibe 0.400 0.482 1.160 0.698 1112 0.753 2.073 0.833 0.653 0.902<br>2.501 0.219;0.730 | 0.287;0.808 | 0.449;2.996 | 0.271;1.800 | 0.617;2.005 | 0.389;1.458 | 1.396;3.079 | 0.622;1.115 | 0.379;1.125 | 0.545;1491<br>1.3704.567 Cabozantinibe 1.204 2.901 1.747 2.782 1.884 5.186 2.083 1.633 2.255<br>2.077 0.830 0.885;1.638Everolimo) | 1.236;6.8072.408, | 0.746;4.0881.450 | 1.833;4.2222.310 | 0.852;4.1621.564 | 3.173;8.4744.306 | 1.230;3.5261.730 | 1.037;2.5731.356 | 1.158;4.3931.873<br>1.2383.484 | 0.610;1.130 1.087;5.337 | 0.656;3.204 | 1.743;3.062 | 0.753;3.247 | 2.936;6.314 | 1.128;2.651 | 0.971;1.894 | 1.037;3.383<br>0.862 0.345 0.415 Lenvatinibe 0.602 0.959 0.649 1.788 0.718 0.563 0.777<br>0.3342.227 | 0.147;0.809 | 0.187;0.920 0.276;1.314 | 0.412;2.231 | 0.220;1.912 | 0.739;4.322 | 0.291;1.772 | 0.238;1.335 | 0.289;2.095<br>1.432 0.573 0.689 1.661 Lenvatinibe 1.593 1.078 2.969 1.193 0.935 1.291<br>0.5563.690 | 0.245;1.340 | 0.312;1.523 | 0.761;3.624 Everolimo 0.687;3.695 | 0.367;3.169 | 1.231;7.160 | 0.485;2.935 | 0.396;2.210 | 0.480;3.472<br>0.899 0.359 0.433 1.043 0.628 Nivolumabe 0.677 1.864 0.749 0.587 0811<br>0.491.620 | 0.237;0.546 | 0.327;0.574 | 0.448;2.425 | 0.271;1.456 0,309;1.481 | 1.159;2.998 | 0.449;1.249 | 0.379;0.909 | 0.421;1.561<br>0.6862.5711.328 | 0.240;1.1730.531 | 0.308;1.3280.639 | 0.523;4.5351.540 | 0.316;2.7250.927 | 0.675;3.2321.477 Pazopani5 1.437;5.2722.753 | 0.611;2.0011.106 | 0.410;1.8340.867 | 0.583;2.4601.197<br>0.482 0.193 0.232 0.559 0.337 0.536 0.363 Placebo 0.402 0.315 0.435,<br>0.3250.716 | 0.118;0.315 | 0.158;0.341 | 0.231;1.352 | 0.140;0.812 | 0.334;0.863 | 0.190;0.696 0.308;0.524 | 0.202;0.492 | 0.267;0.709<br>0.8961.6081.201 | 0.284;0.8130.480 | 0.377;0.8860.578 | 0.564;3.4351.392 | 0.341;2.0630.838 | 0.801;2.2281.335 | 0.500;1.6360.904 | 1.907;3.2492.489 Sorafeni~~ 0.496;1.2400.784 | 0.719;1.6301.083<br>1531 0.612 0.737 1.776 1.070 1.704 1.153 3.175 1.276 Sunitinibe 1381<br>0.8892.638 | 0.389;0.965 | 0.528;1.030 | 0.749;4.210 | 0.452;2.528 | 1.100;2.638 | 0.545;2.440 | 2.033;4.960 | 0.806;2.018 0.747;2.553<br>1.109 0.443 0.534 1.286 0.74 1.234 0.835, 2.299 0.924 0.724 Tensirolimo<br>0.671.833 | 0.228;0.864 | 0.296;0.965 | 0.477;3.466 | 0.288;2.082 | 0.641;2.375 | 0.406;1.716 | 1.411;3.746 | 0.614;1.391 | 0.392;1.339<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
67

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta para doença progressiva** -->
A rede foi composta por dez estudos, os quais totalizaram 5.028 participantes ( **Figura 23** )<sup>1–9</sup> . A NMA incluiu de 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 estimativas de efeito relativo ( **Quadro K** ).  
**Figura 23 -** _Network Plot_ da NMA para taxa de resposta para doença progressiva.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
68  
**Quadro K -** _League table_ da NMA para taxa de resposta para doença progressiva.  
<!-- Start of picture text -->
Axitinibe 2.291 0.983 7.760 4.966 0.645 1.946 0.241 1.037 1.491 1.041<br>1.089;4.819 | 0.551;1.755 | 1.476;40.801 | 1.159;21.283 | 0.336;1.238 | 0.972;3.895 | 0.149;0.388 | 0.726;1.481 | 0.819;2.714 | 0.630;1.722<br>0.436 0.429 3.387 2.168 0.281 0.849 0.105 0.453 0.651 0.455<br>0.208;0.918 Cabozantinibe 0,269;0.684 | 0.668;17.177 | 0.527;8.913 | 0.162;0.490 | 0.351;2.055 | 0.057;0.193 | 0.236;0.870 | 0.347;1219 | 0.216;0.956<br>1.017 2.331 7.895 5.053, 0.656 1.980 0.245 1.055 1.517 1.060<br>Everolimo<br>0.570;1.816 1.462;3.715 1.667;37.390 1.330;19.196 0.486;0.886 0.935;4.194 0.165;0.363 0.668;1.667 0.997;2.309 0.594;1.890<br>0.129 0.295 0.127 0.640 0.083 0.251 0.031 0.134 0.192 0.134<br>Lenvatinibe<br>0.025;0.678 0.058;1.497 0.027;0.600 0.102;4.000 0.017;0.405 0.045;1.410 0.006;0.154 0.026;0.676 0.038;0.962 0.026;0.705<br>0.201 0.461 0.198 1.563 Lenvatinibe 0.130 0.392 0.048 0.209 0.300 0.210<br>0.047;0.863 0.112;1.897 0.052;0.752 0.250;9.765, Everolimo 0.033;0.510 0.085;1.812 0.012;0.195 0.051;0.856 0.074;1.217 0.049;0.898<br>1.551 3.553 1.525 12.036 7.703 Nivolumabe 3.018 0.373 1.609 2.313 1.615<br>0.808;2.979 | 2.041;6.187 | 1.129;2.059 | 2.469;58.668 | 1.961;30.259 1.345;6.775 | 0.227;0.612 | 0.931;2.780 | 1.380;3.876 | 0.841;3.101<br>0.514 1.177 0.505 3.988 2.552 0,331 0.124 0.533 0.766 0.535<br>0.257;1.028 | 0.487;2.849 | 0.238;1.070 | 0.709;22.423 | 0.552;11.802 | 0.148;0.744 Pazopanibe 0,063;0.243 | 0.294;0.967 | 0.356;1.648 | 0.268;1.070<br>2.580;6.7014.158 | 5.173;17.5409.526 | 2.755;6.0624,087 | 6.486;160.51732.266 | 5.134;83.05520.650 | 1.633;4.4002.681 | 4,120;15.8908,091 Placebo 3.139;5.9254.312 | 3.818;10.0676.199 | 2.689;6.9734.330<br>0.675;1.3770.964 | 1.150;4.2432.209 | 0.600;1.4970.948 | 1.479;37.8457.482 | 1.168;19.6314.788 | 0.360;1.0740.622 | 1.034;3.4031.876 | 0.169;0,3190.232 Sorafenil™ 0.888;2.3271.437 | 0.704;1.4321.004<br>0.369;1.2210.671 | 0.820;2.8781537 | 0.433;1.0040.659 | 1.039;26.0635.204 | 0.822;13.4993.331 | 0.258;0.7250.432 | 0.607;2.8071.305 | 0.099;0.2620.161 | 0.430;1.1260.696 Sunitinibe 0.384;1.2700.698<br>0.960 2.200 0.944 7.451 4.769 0.619 1.869 0.231 0.996 1.432 Tensirolimo<br>0.581;1.588 1.046;4.626 0.529;1.684 1.418;39.170 1.113;20.430 0.323;1.188 0.934;3.738 0.143;0.372 0.698;1.420 0.787;2.604<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
69

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos gerais** -->
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes ( **Figura 24** )<sup>1–9</sup> . Esta rede incluiu um total de 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), com 55 possíveis comparações e estimativas de efeito relativo ( **Quadro L** ).  
**Figura 24 -** Network Plot – Eventos adversos gerais.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
70  
**Quadro L -** _League table_ da NMA para evento adverso.  
<!-- Start of picture text -->
_ 0.238 8.382 8.063 8.219 4.951 1.102 0.644 0.783 2.143 0.762<br>0.001;22256.73 Cabozantinibe 0.223;5562.484 | 0.011;105831.13 | 0.011;107893.51 | 0.018;23701.65 | 0.01;25691.10 | 0.04;2006.80 | 0.03;3769.50 | 0.012;6585.99 | 0.00;25850.88<br>0.119 0.028 0.962 0.981 0.591 0.131 0.077 0.093 0.256 0.091<br>Lenvatinibe|<br>0.000;1396.32 0.000;92.15, 0.002;541.206 0.002;530.64 0.000;1722.962 | 0.000;1605.51 | 0.000;153.56 | 0.000;273.85 0.000;504.87 0.00;1569.63<br>0.122 0.029 1.020 0.981 Lenvatinibe 0.602 0.134 0.078 0.095, 0.261 0.093<br>0.202 0.048 1.693 1.629 1.660 0.223 0.130 0.158 0.433 0.154<br>0.908 0.216 7.608 7.318 7.460 4494 0.585 0.711 1.945 0.692<br>1.553 0.369 13.014 12.517 12.760 7.686 1.710 1.216 3.327 1.183<br>1.276 0.304 10.700 10.291 10.492 6.319 1.406 0.822 2.736 0.973<br>0.467 0.111 3.911 3.762 3.835 2.310 0.514 0.301 0.366 0.356<br>1.312 0.312 10.998 10.578 10.784 6.495 1.445 0.845 1.028 2.812<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância  
estatística.  
71

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Evento adverso grave** -->
A NMA foi composta por dez estudos, os quais totalizaram 5.028 participantes ( **Figura 25** )<sup>1–9</sup> . Nesta NMA foram incluídas 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo), que geraram um total de 55 comparações possíveis, para as quais foram obtidas as estimativas de efeito ( **Quadro M** ).  
**Figura 25 -** _Network Plot_ da NMA para evento adverso grave.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
72  
**Quadro M -** _League table_ da NMA para evento adverso grave.  
<!-- Start of picture text -->
Axitinibe 2,062 1,846 0,820 0,450 1,494 0,720 2,273 1,148 0,987 0,902<br>0,081;52,300 | 0,130;26,143 | 0,030;22,653 | 0,016;12,680 | 0,059;37,766 | 0,050;10,483 | 0,193;26,803 | 0,177;7,464 | 0,081;11,984 | 0,064;12,632<br>0,485 0,895 0,398 0,218 0,724 0,349 1,102 0,557 0,479 0,438<br>0,01912,300 Cabozantinibe 0,141;5,701 | 0,026;6,055 | 0,014;3,403 | 0,053;9,895 | 0,013;9,085 | 0,094;12,919 | 0,040;7,774 | 0,041;5,603 | 0,017;11,023<br>0,0387,6740,542 | 0,175;7,1161,117 Everolimo 0,060;3,2720,444 | 0,032;1,8550,244 | 0,128;5,1260,809 | 0,027;5,6990,390 | 0,243;6,2341,231 | 0,095;4,0640,622 | 0,106;2,7020,535 | 0,035;6,8670,489<br>0,04433,6661,219 | 0,165;38,2642,514 | 0,306;16,5632,250 Lenvatinibe 0,071;4,2140,549 | 0,120;27,6131,821 | 0,031;24,8510,878 | 0,212;36,2782,771 | 0,090;21,6761,400 | 0,092;15,7351,203 | 0,040;30,1751,100<br>2,221 4,580 4,100 1,822 Lenvatinibe 3,318 1,600 5,049 2,551 2,192 2,004<br>0,07962,565 | 0,294;71,414 | 0,539;31,184 | 0,237;13,994 | ayaa | 0,214;51,537 | 0,055;46,178 | 0,376;67,803 | 0,161;40,451 | 0,163;29,409 | 0,072;56,081<br>0,02616,9250,669 | 0,101;18,8551,380 | 0,195;7,8261,236 | 0,036;8,3270,549 | 0,019;4,6810,301 Nivolumabe 0,019;12,5020,482 | 0,130;17,7591,522 | 0,055;10,6890,769 | 0,057;7,7020,661 | 0,024;15,1680,604<br>1,388 2,862 2,562 1,139 0,625 2,073 3,155 1,594 1,370 1,252<br>Pazopanibe<br>0,09520,200 | 0,110;74,433 | 0,175;37,412 | 0,040;32,220 | 0,022;18,031 | 0,080;53,748 0,259;38,440 | 0,235;10,814 | 0,109;17,181 | 0,087;18,076<br>0,0375,1880,440 | 0,077;10,6320,907 | 0,160;4,1110,812 | 0,028;4,7250,361 | 0,015;2,6600,198 | 0,056;7,6700,657 | 0,026;3,8610,317 Placebo 0,101;2,5210,505 | 0,066;2,8370,434 | 0,034;4,6390,397<br>0,871 1,796 1,608 0,714 0,392 1,301 0,627 1,980 Sorafenibe 0,860 0,786<br>0,1345,662 | 0,129;25,076 | 0,246;10,501 | 0,046;11,065 | 0,025;6,218 | 0,094;18,093 | 0,092;4,258 | 0,397;9,880 0,165;4,485 | 0,122;5,049<br>1,013 2,089 1,870 0,831 0,456 1,513 0,730 2,303 1,163 0,914<br>0,08312,302 | 0,178;24,457 | 0,370;9,450 | 0,064;10,870 | 0,034;6,118 | 0,130;17,642 | 0,058;9,153 | 0,352;15,049 | 0,223;6,070 Sunitinibe 0,076;11,003<br>1,108 2,286 2,046 0,909 0,499) 1,656 0,798 2,519 1,273 1,094 Tensirolimo<br>0,07915,516 | 0,091;57,576 | 0,146;28,737 | 0,033;24,943 | 0,018;13,960 | 0,066;41,575 | 0,055;11,525 | 0,216;29,444 | 0,198;8,176 | 0,091;13,166<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística  
73

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Suspensão devido a evento adverso** -->
Esta NMA incluiu dez estudos, os quais totalizaram 5.028 participantes<sup>1–9</sup> . A **Figura 26** demonstra a rede para este desfecho. A NMA incluiu 11 intervenções (axitinibe, cabozantinibe, everolimo, lenvatinibe, lenvatinibe associado ao everolimo, nivolumabe, pazopanibe, placebo, sorafenibe, sunitinibe e tensirolimo) e permitiu comparar o efeito relativo entre qualquer par de intervenções, totalizando 55 estimativas de efeito relativo ( **Quadro N** ).  
**Figura 26.** _Network plot_ da NMA para suspensão devido a evento adverso.  
<!-- Start of picture text -->
fenibe<br>pazopanibe,<br>lumitinibe<br>cabozaptinibe a<br>nivoli<br>ian tensirolimo:<br>levantinibe<br>limo<br>levantinibe everolimo axitinibe<br><!-- End of picture text -->  
74  
**Quadro N -** _League table_ da NMA para suspensão devido a adverso.  
<!-- Start of picture text -->
Axitinibe 0,024 0,024 0,013 0,010 0,032 0,067 0,129 0,076 0,051 0,057<br>0,000;2,042 | 0,000;1,360 | 0,000;1,260 | 0,000;0,951 | 0,000;2,745 | 0,001;3,557 | 0,003;5,986 | 0,002;2,324 | 0,001;2,491 | 0,001;2,901<br>42,258 1,029 0,546 0,416 1,356 2,815 5,436 3,206 2,140 2,424<br>0,490;3646,051 Cabozantinibe 0,151;7,014 | 0,030;10,027 | 0,023;7,539 | 0,091;20,190 | 0,085;93,522 | 0,352;83,965 | 0,184;55,790 | 0,160;28,620 | 0,078;75,717<br>0,735;2295,25741,075 | 0,143;6,6270,972 Everolimo 0,060;4,7310,531 | 0,046;3,5420,404 | 0,197;8,8121318 | 0,146,51,2752,736 | 0,751;37,1965,284 | 0,376;25,8473,116 | 0,364;11,8972,080 | 0,135;41,0012,357<br>0,794;7540,17077,370 | 0,100;33,6161,831 | 0,211;16,7871,884 Lenvatinibe 0,094;6,1650,761 | 0,137;44,9932,482 | 0,133;199,6775,154 | 0,531;186,6629,953 | 0,280;123,0885,870 | 0,239;64,2643,917 | 0,122;162,0984,439<br>101,657 2,406 2,475 1,314 Lenvatinibe 3,261 6771 13,078 7711 5,147 5,832<br>1,051;9831,040 | 0,133;43,632 | 0,282;21,700 | 0,162;10,643 | Siri | 0,182;58,399 | 0,176;259,823 | 0,706;242,306 | 0,372;159,844 | 0,318;83,371 | 0,161;210,882<br>31,174 0,738 0,759 0,403 0,307 2,077 4,010 2,365 1,578 1,789<br>Nivolumabe<br>0,364;2667,775 | 0,050;10,988 | 0,113;5,076 | 0,022;7,305 | 0,017;5,491 0,063;68,272 | 0,263;61,111 | 0,138;40,630 | 0,120;20,818 | 0,058;55,268<br>15,013 0,355 0,365 0,194 0,148 0,482 1,931 1,139 0,760 0,861<br>Pazopanibe<br>0,281;801,672 | 0,011;11,805 | 0,020;6,850 | 0,005;7,518 | 0,004;5,667 | 0,015;15,835 0,133;27,991 | 0,150;8,654 | 0,048;11,929 | 0,053;14,052<br>0,167;361,6957,773 | 0,012;2,8410,184 | 0,027;1,3320,189 | 0,005;1,8840,100 | 0,004;1,4170,076 | 0,016;3,8000,249 | 0,036;7,5040,518 Placel_ 0,103;3,3680,590 | 0,047;3,2640,394 | 0,033;5,9570,446<br>13,183 0,312 0,321 0,170 0,130 0,423 0,878 1,696 0,667 0,756<br>Sorafenibe<br>0,430;403,792 | 0,018;5,429 | 0,039;2,662 | 0,008;3,573 | 0,006;2,688 | 0,025;7,265 | 0,116;6,673 | 0,297;9,685 0,104;4,297 | 0,111;5,154<br>19,751 0,467 0,481 0,255 0,194 0,634 1,316 2,541 1,498 Sunitinibe 1,133<br>0,401;971,751 | 0,035;6,253 | 0,084;2,751 | 0,016;4,188 | 0,012;3,147 | 0,048;8,355 | 0,084;20,648 | 0,306;21,075 | 0,233;9,646 0,078;16,430<br>17,430 0,412 0,424 0,225 0,471 0,559 1,161 2,242 1,322 0,882<br>0,345;881,478 | 0,013;12,883 | 0,024;7,383 | 0,006;8,226 | 0,005;6,199 | 0,018;17,276 | 0,071;18,940 | 0,168;29,952 | 0,194;9,011 | 0,061;12,796 Tensirolimo<br><!-- End of picture text -->  
Nota: Razões de chance com valores inferiores a 1 favorecem o medicamento listado na coluna; Razões de chance com valores superiores a 1 favorecem o medicamento listado na linha; valores em negrito indicam significância estatística.  
75  
**Avaliação da qualidade da evidência - CINeMA (** **_Confidence in Network Meta-Analysis_ )**

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida livre de progressão** -->
O **Quadro O** apresenta a avaliação geral da evidência para o desfecho sobrevida livre de progressão.  
**Quadro O -** Avaliação geral da evidência – sobrevida livre de progressão.  
<!-- Start of picture text -->
Comparagdes Viés do estudo Viés de Indirectness Heterogeneidade ‘Avaliagéo<br>publicagao Final<br>sem Grande<br>Axitinibe - Sorafenibe 1 Sem preocupacées _| Nao detectado preocupacées Sem preocupasées preocupacao Grande preocupac3o<br>Cabozantinibe - Everolimo 1 Sem preocupagées _| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupacao Algumaspreocupacées Baixo<br>Sem Grande<br>; -<br>Everolimo - Lenvatinibe 1 Sem preocupagées _| Nao detectado preocupacées Sem preocupagées preocupacao Grande preocupacao<br>Everolimo - Lenvatinibe Everolimo | 1 Sem preocupagées _| Nao detectado sempreocupacées Sem preocupagées Grandepreocupacao Grande preocupac3o<br>Everolimo - Nivolumabe 1 Sem preocupacées _| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupacao Grande preocupaco<br>Sem Grande<br>;<br>Everolimo - Placebo 1 Sem preocupagées _| Nao detectado preocupacées Sem preocupagées preocupacao Grande preocupacio<br>Everolimo - Sunitinibe 1 Sem preocupagées _| Nao detectado sempreocupacées Sem preocupagées Grandepreocupacao Grande preocupac3o<br>Lenvatinibe - Lenvatinibe Everolimo | 1 Sem preocupagées _| Nao detectado Sempreocupacées —_| preocupacdoGrande Sem preocupagées ‘Algumaspreocupacées Baixo<br>Sem Grande<br>Grande preocupacdo_| Nao detectado Sem preocupacées Grande preocupaco<br>Pazopanibe - Sorafenibe 1 preocupacées preocupacao<br>Placebo - Sorafenibe 1 Sem preocupagées _| Nao detectado sempreocupacées Sem preocupagées Grandepreocupacao Grande preocupacao<br><!-- End of picture text -->  
76  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de<br>publicagdo<br>Sorafenibe - Sunitinibe 1 Grande preocupacao_ | Nao detectado sempreocupagées Sem preocupacées Grandepreocupacao Grande preocupacao<br>Sorafenibe - Tensirolimo 1 Sem preocupacées _| Nao detectado Sempreocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Cabozantinibe Sem preocupacées _| Nao detectado Sempreocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Everolimo Sem preocupacées _| Nao detectado Sempreocupagdes —_| preocupacdoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Lenvatinibe Sem preocupacées _| Nao detectado sempreocupagdes —_| preocupacdoGrande Sem preocupacées | Grande preocupacéo<br>Axitinibe - Lenvatinibe Everolimo Sem preocupagées _| Nao detectado sempreocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Nivolumabe Sem preocupacées _| Nao detectado Sem’preocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Pazopanibe Algumaspreocupacées Nao detectado Sempreocupagées —_| preocupacoGrande Sem preocupacées | Grande preocupacdo<br>Axitinibe - Placebo Sem preocupacées _| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupacao ‘Algumaspreocupagées Baixo<br>Algumas. Sem Grande<br>Axitinibe - Sunitinibe preocupacées Nao detectado preocupagdes —_| preocupacdo Sem preocupacées | Grande preocupacdo<br>Axitinibe - Tensirolimo Sem preocupaces _| Nao detectado sempreocupacées Sem preocupasées Grandepreocupacao Grande preocupacao<br><!-- End of picture text -->  
77  
<!-- Start of picture text -->
Comparacées Viés do estudo Viés de Impreciséo Heterogeneidade “ Avaliacdo<br>publicagdo Final<br>Cabozantinibe - Lenvatinibe Sem preocupagées _| Nao detectado Sempreocupagées —_| preocupacdoGrande Sem preocupacées | Grande preocupacéo<br>CabozantinibeEverolimo - Lenvatinibe Sem preocupagées _| Nao detectado Sem Grande Sem preocupacées | Grande preocupac3o<br>preocupagées —_| preocupaco<br>Cabozantinibe - Nivolumabe Sem preocupacées _| Nao detectado Sempreocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacao<br>Algumas Sem Grande<br>Cabozantinibe - Pazopanibe preocupacées Nao detectado preocupagées —_| preocupacdo Sem preocupagées | Grande preocupacao<br>sem Grande<br>;<br>Cabozantinibe - Placebo Sem preocupacées _| Nao detectado preocupagées Sem preocupacées preocupacao Sem preocupacées<br>Cabozantinibe - Sorafenibe Sem preocupagées _| Nao detectado Sempreocupagées Sem preocupacées Grandepreocupacao Algumaspreocupagées Baixo<br>Cabozantinibe - Sunitinibe Sem preocupagées _| Nao detectado sempreocupacées —_| preocupacaoGrande Sem preocupacées | Grande preocupac3o<br>Cabozantinibe - Tensirolimo Sem preocupagées _| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupacao Grande preocupacéo<br>Algumas sem Grande<br>Everolimo - Pazopanibe preocupacdes Nao detectado preocupagées —_| preocupacao Sem preocupacées | Grande preocupac3o<br>Everolimo - Sorafenibe Sem preocupagées | Nao detectado Sempreocupagées —_| preocupacaoGrande Sem preocupacées | Grande preocupacao<br>Everolimo - Tensirolimo Sem preocupagées _| Nao detectado Sempreocupagées —_| preocupacdoGrande Sem preocupacées | Grande preocupacdo<br><!-- End of picture text -->  
78  
<!-- Start of picture text -->
Viés de .<br>Viés do estudo Heterogeneidade<br>Comparacées Avaliacéo.<br>publicagéo Final<br>sem Grande<br>;<br>Lenvatinibe - Nivolumabe Sem preocupacées —_/ Nao detectado preocupagées _| preocupacao Sem preocupagées_| Sem preocupasées<br>‘Algumas Sem Grande<br>Lenvatinibe - Pazopanibe preocupacées Nao detectado preocupasées _| preocupacio Sem preocupagées_| Sem preocupacées<br>Lenvatinibe - Placebo Sem preocupacées —_| Nao detectado Sempreocupagées Sem preocupacées Grandepreocupagao ‘Sem preocupacées<br>Sem Grande<br>Lenvatinibe - Sorafenibe Sem preocupacées —_ | Nao detectado preocupacées Sem preocupacées preocupacao Sem preocupagées<br>Lenvatinibe - Sunitinibe Sem preocupacées —_ Nao detectado Sempreocupasées _| preocupacioGrande Sem preocupagées ‘Algumaspreocupacées<br>Lenvatinibe - Tensirolimo Sem preocupacées —_| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupagao ‘Sem preocupacées<br>Lenvatinibe Everolimo - Nivolumabe Sem preocupacées —_/ Nao detectado Sempreocupagées _| preocupacaoGrande Sem preocupagées | Grande preocupacao<br>‘Algumas Sem Grande<br>Nao detectado Sem preocupagées_| Grande preocupacao<br>Lenvatinibe Everolimo - Pazopanibe preocupacées preocupacgdes preocupacao<br>Lenvatinibe Everolimo - Placebo Sem preocupacées | Nao detectado Sempreocupacées Sem preocupacées Grandepreocupaco ‘Algumaspreocupagées<br>Lenvatinibe Everolimo - Sorafenibe Sem preocupacées —_| Nao detectado Sempreocupagées __| preocupacaoGrande Sem preocupagées | Grande preocupacao<br>Lenvatinibe Everolimo - Sunitinibe Sem preocupacées —_| Nao detectado Sempreocupagdes —_| preocupacdoGrande Sem preocupagées_| Grande preocupacao<br><!-- End of picture text -->  
79  
<!-- Start of picture text -->
Comparagées Viés do estudo Viés de Indirectness Heterogeneidade  Avaliacao.<br>publicagdo Final<br>Lenvatinibe Everolimo - Tensirolimo Sem preocupacées _| Nao detectado sempreocupacées —_| preocupacaoGrande Sem preocupacées | Grande preocupagao<br>Algumas Sem Grande<br>Nivolumabe - Pazopanibe preocupacées Nao detectado preocupacées _| preocupacao Sem preocupacées | Grande preocupacao<br>Nivolumabe - Placebo Sem preocupacées _| Nao detectado Sempreocupacées Sem preocupagées Grandepreocupacao Grande preocupao<br>Nivolumabe - Sorafenibe Sem preocupacées _| Nao detectado Sempreocupacées Sem preocupagées Grandepreocupacao Grande preocupaco<br>Nivolumabe - Sunitinibe Sem preocupacées _| Nao detectado Sempreocupacées _| preocupacioGrande Sem preocupacées | Grande preocupagao<br>Sem Grande<br>- Tensirolimo. preocupacées preocupacao<br>Nivolumabe Sem preocupasées _| Nao detectado Sem preocupacées Grande preocupacao<br>‘Algumas ‘Sem Grande<br>Nao detectado Sem preocupacées Grande preocupacao<br>Pazopanibe - Placebo preocupacées preocupacées preocupacao<br>Pazopanibe - Sunitinibe Grande preocupacao_| Nao detectado sempreocupacdes —_| preocupacaoGrande Sem preocupacées | Grande preocupagao<br>‘Algumas ‘Sem Grande<br>Pazopanibe - Tensirolimo preocupacées Nao detectado preocupacdes —_| preocupacao Sem preocupacées | Grande preocupagao<br>Algumas Sem Grande Algumas<br>Nao detectado Sem preocupacées<br>Placebo - Sunitinibe preocupacées preocupacées preocupacao preocupagées Baixo<br>Placebo - Tensirolimo Sem preocupacées _| Nao detectado Sempreocupacées Sem preocupacées Grandepreocupacao Grande preocupacao<br><!-- End of picture text -->  
<!-- Start of picture text -->
Viés de "<br>Viés do estudo Heterogeneidade<br>Comparagées Avaliagéo<br>publicagdo Final<br>‘Algumas Sem Grande<br>Sunitinibe - Tensirolimo preocupacées Nao detectado preocupacées —_| preocupacdo Sem preocupacées | Grande preocupacéo<br><!-- End of picture text -->  
80

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Sobrevida global** -->
O **Quadro P** apresenta a avaliação geral da evidência para o desfecho sobrevida global.  
**Quadro P** - Avaliação geral da evidência – sobrevida global.  
<!-- Start of picture text -->
Comparacées Avaliagao<br>Viés do estudo Viés de publicagéo Heterogeneidade Incoeréncia Final '<br>Axitinibe - Sorafenibe [*| ‘Sem preocupacées Nao detectado ‘Sem preocupacoes |Grande preocupacdo [Sem preocupacées |Sem preocupacées<br>Cabozantinibe - Nao detectado ‘Sem preocupagées _| Grande preocupacao<br>Everolimo Sem preocupagées Sem preocupagdes Sem preocupagées<br>Everolimo - Lenvatinibe Nao detectado ‘Sem preocupagées _| Grande preocupacao<br>Everolimo ‘Sem preocupagdes Sem preocupagées Sem preocupagées<br>Everolimo - Lenvatinibe [*| ‘Sem preocupacées Nao detectado ‘Sem preocupacoes |Sempreocupacées |Grande preocupacdo | Sem preocupacoes<br>Everolimo - Nivolumabe [*| ‘Sem preocupacées Nao detectado ‘Sem preocupacoes |Sem preocupacées |Grande preocupacao | Sem preocupacées<br>Everolimo - Placebo [*| ‘Sem preocupacées Nao detectado ‘Sem preocupacées Grande preocupacao |Sem preocupacées<br>Everolimo - Sunitinibe [3] ‘Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacao ‘Sem preocupacées<br>Lenvatinibe - Nao detectado Grande preocupacao |Sem preocupacées<br>Lenvatinibe Everolimo Sem preocupages Sem preocupagdes Sem preocupagées<br>Pazopanibe - Nao detectado ‘Sem preocupagées _| Grande preocupacao<br>Sorafenibe 1| Grande preocupacao Sem preocupagées ‘Sem preocupagées<br>Placebo - Sorafenibe [*| ‘Sem preocupacées Nao detectado ‘Sem preocupacées |Sempreocupacées | Grande preocupaco |Sem preocupacées<br>Sorafenibe - Sunitinibe [*| Algumas preocupacées | Nao detectado ‘Sem preocupacoes | Grande preocupacdo [Sem preocupacées |Sem preocupacées<br><!-- End of picture text -->  
81  
<!-- Start of picture text -->
fw — — al hol— eee<br>TensirolimoSorafenibe - 1 Sem preocupacées Nao detectado | Sem preocupagées | Grande preocupac3o | Sem preocupacées_| Sem preocupagdes<br>Axitinibe - Nao detectado Sem preocupacées Grande preocupacao<br>Cabozantinibe Sem preocupacées Sem preocupagées Sem preocupacées<br>Axitinibe - Everolimo [°| ‘Sem preocupacoes. Nao detectado ‘Sem preocupagoes | Grande preocupacdo |Sem preocupagées | Sem preocupacoes<br>Axitinibe - Lenvatinibe Nao detectado Sem preocupagées | Grande preocupagao<br>Everolimo Sem preocupasées Sem preocupacées Sem preocupacées<br>Axitinibe - Lenvatinibe I?! ‘Sem preocupacées Nao detectado Sem preocupacées |Sem preocupacées |Grande preocupacao | Sem preocupagdes<br>Axitinibe - Nivolumabe [°| ‘Sem preocupacoes. Nao detectado ‘Sem preocupagoes | Grande preocupacdo |Sem preocupagées | Sem preocupacoes<br>Axitinibe - Pazopanibe I?) Algumas preocupacées | N3o detectado Sem preocupacées | Grande preocupacdo |Sem preocupasées |Sem preocupacdes<br>Axitinibe - Placebo [°)Sem preocupagées Nao detectado ‘Sem preocupagoes |Sem preocupagdes | Grande preocupacao |Sem preocupacoes<br>Axitinibe - Sunitinibe [°|‘Sem preocupacées. No detectado ‘Sem preocupagées | Grande preocupacdo |Sem preocupasées | Sem preocupacoes<br>Axitinibe - Tensirolimo [°|Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacao |Sem preocupacées | Sem preocupagdes<br>Cabozantinibe - Nao detectado Grande preocupa¢ao |Sem preocupagées<br>Lenvatinibe Everolimo Sem preocupacées Sem preocupasées Sem preocupacées<br><!-- End of picture text -->  
82  
<!-- Start of picture text -->
frome me— mmm free [ert rence le<br>Cabozantinibe - Nao detectado Grande preocupacao |Sem preocupacées<br>Lenvatinibe Sem preocupacées ‘sem preocupacées Sem preocupacées<br>Cabozantinibe - Nao detectado Sem preocupasées _| Grande preocupacao<br>Nivolumabe Sem preocupacées Sem preocupacées Sem preocupacées<br>Cabozantinibe - Nao detectado Grande preocupacio |Sem preocupacées<br>Pazopanibe Algumas preocupagdes Sem preocupacées Sem preocupacées<br>Cabozantinibe - Placebo °|Sem preocupacées Nao detectado Sem preocupagdes Sem preocupacées<br>Cabozantinibe - N&o detectado Sem preocupagées Grande preocupa¢ao<br>Sorafenibe Sem preocupagées Sem preocupacées Sem preocupacées<br>Cabozantinibe - Nao detectado Grande preocupacao |Sem preocupacées<br>Sunitinibe Sem preocupacées ‘sem preocupacées Sem preocupacées<br>Cabozantinibe - Nao detectado Sem preocupasées _| Grande preocupacao<br>Tensirolimo Sem preocupacées ‘Sem preocupacées Sem preocupacées<br>Everolimo - Pazopanibe °| Algumas preocupacées_| No detectado ‘Sem preocupagées | Grande preocupacao |Sem preocupagées |Sem preocupagées<br>Everolimo - Sorafenibe [°| ‘Sem preocupacées Nao detectado Sem preocupacées Sem preocupacées<br>Everolimo - Tensirolimo °| ‘Sem preocupacées Nao detectado ‘Sem preocupagées | Grande preocupacao Sem preocupacées<br><!-- End of picture text -->  
83  
<!-- Start of picture text -->
fv eee— perme— ne ee<br>Lenvatinibe Everolimo - Nao detectado Sem preocupacdes _ | Grande preocupaco<br>Nivolumabe Sem preocupacées Sem preocupacées Sem preocupacées<br>Lenvatinibe Everolimo - Nao detectado Grande preocupacao | Sem preocupagées<br>Pazopanibe Algumas preocupacées Sem preocupagées Sem preocupacées | Baixo<br>Lenvatinibe Everolimo - Nao detectado ‘Sem preocupacdes _ | Grande preocupaco<br>Placebo Sem preocupacées Sem preocupacées Sem preocupacées<br>Lenvatinibe Everolimo - Nao detectado Sem preocupacées —_| Grande preocupacao<br>Sorafenibe Sem preocupagées Sem preocupagées Sem preocupacées<br>Lenvatinibe Everolimo - Nao detectado Grande preocupacao | Sem preocupacdes<br>Sunitinibe Sem preocupacées Sem preocupacées Sem preocupacées<br>Lenvatinibe Everolimo - Nao detectado Sem preocupacées —_| Grande preocupacao<br>Tensirolimo Sem preocupagées Sem preocupagées Sem preocupacées<br>Lenvatinibe - Nao detectado| ‘Sem preocupac®es _ | Grande preocupaco<br>Nivolumabe Sem preocupacées Sem preocupacées Sem preocupacées<br>Lenvatinibe - Nao detectado Grande preocupa¢ao |Sem preocupacées<br>Pazopanibe Algumas preocupacées Sem preocupagées Sem preocupacées | Baixo<br>Lenvatinibe - Placebo °| ‘Sem preocupagdes Nao detectado Sem preocupacées |Sem preocupagdes | Grande preocupacao | Sem preocupacées<br><!-- End of picture text -->  
84  
<!-- Start of picture text -->
Lenvatinibe - N3o detectado ‘Sem preocupacées Grande preocupac3o<br>Sorafenibe Sem preocupacdes Sem preocupacées Sem preocupacées<br>Lenvatinibe - Nao detectado ‘Sem preocupacées Grande preocupacao<br>Tensirolimo Sem preocupacées Sem preocupacées Sem preocupacées<br>Nivolumabe - Nao detectado Sem preocupacées Grande preocupacao<br>Pazopanibe Algumas preocupagées Sem preocupacées Sem preocupacées<br>Nivolumabe - Placebo °|Sem preocupacées Nao detectado ‘Sem preocupacées ‘Sem preocupacées<br>Nivolumabe - Nao detectado Grande preocupacao |Sem preocupacées<br>Sorafenibe Sem preocupacées Sem preocupacées Sem preocupacées<br>Nivolumabe - Sunitinibe | ‘Sem preocupagées Nao detectado Sem preocupacées Sem preocupagées<br>Nivolumabe - Nao detectado Grande preocupa¢ao | Sem preocupacées<br>Tensirolimo Sem preocupacées Sem preocupagées Sem preocupacées<br>Pazopanibe - Placebo °|Algumas preocupagées | Nao detectado ‘Sem preocupacées ‘Sem preocupacées<br>Pazopanibe - Sunitinibe °| Algumas preocupagées | Nao detectado Sem preocupacées Sem preocupacées<br><!-- End of picture text -->  
85  
<!-- Start of picture text -->
= SF EEF<br>Pazopanibe - Nao detectado Grande preocupacdo | Sem preocupacées Ee<br>= J<br>Pact Sannie [P fererecniss  Mecsetaie _[rresnste [everosnss [fenstresarsas [en rennin<br>[etecrencine _[P[fmeesceie [eeteetiee [Presents [Frowcoste [fortress [enaercnte<br>aS<br>Sa a ae AN<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta clínica** -->
O **Quadro Q** apresenta a avaliação geral da evidência para o desfecho taxa de resposta clínica.  
86  
**Quadro Q** - Avaliação geral da evidência – taxa de resposta clínica.  
<!-- Start of picture text -->
Comparacées Viés do estudo Heterogeneidade<br>publicacdo<br>Lee fee lee eee<br>al lll ll ial ella<br>li lid ll cil le lad<br>aa Wal ll liad<br>aia nc ld iid el cima =<br>ci Wlll il all<br><!-- End of picture text -->  
87  
<!-- Start of picture text -->
|acmanComparacées |i [womViés do estudo | taeViés de [mac | monte —-| mamaHeterogeneidade | marin— | AvaliagéoOT<br>[Mere[Meee Nres e ntsen |[ferent t[eneersesesll [ Mesieeneceeens [ nr r ronntearsos [c o nsentrrosne meccossnll [ Fenreonesterasarsos [ Feo re mcrneeccessal<br>aa lil ll i ial<br>[ree ene [emer ronises [Noses [Perrone [Const neccoste [nrrounsie: [Hnowcrxte<br>Cabozantinibe - Lenvatinibe<br>ac al lll i<br>== j-— bP<br>an ll l l cd<br>ila ll<br>a illll i ae id=<br>isl ei al<br>li<br>aa lil ll ila e l i i ald=<br>lll<br>li al<br>lil<br>ll i a =)<br><!-- End of picture text -->  
88  
<!-- Start of picture text -->
Comparacées Viés do estudo Heterogeneidade<br>on ee eee oe eee<br>a ac Vl a publicagéod al laa il =<br>a<br>iiialii lliill ld[eaelllll iileeeilmaneilai isarenaileoniadiadaa==<br>Lillial sd lms a lau a md ==<br>iia i l lil illal<br>a cle lil ial liad<br>ll el lla<br>la<br>a i ca ad =<br>a a i d i l l cll i l l  id<br>lllll le a ==<br>ciaa i lllil lalal id<br>a clll lila iel ==<br><!-- End of picture text -->  
89  
ic aa  
Legenda: N: quantidade de estudo com avaliação direta

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta completa** -->
O **Quadro R** apresenta a avaliação geral da evidência para o desfecho taxa de resposta completa.  
90  
**Quadro R** - Avaliação geral da evidência – taxa de resposta completa.  
a cl  
91  
<!-- Start of picture text -->
— a a an Eas een<br>Seaam llllll ion saell lali ad<br>cl<br>Sa sa i<br>aa ll ll lil ell lal ad<br>i lllca a<br>a liliena i ad<br>a llsil cillai<br>a a sna cl a l<br>lllll lil ell lal<br>si a<br>cal<br>a lilill sa cn ad<br>sil cilali<br>cl<br>iia ll lia ealil lc l ad<br>a<br>lal<br>ll<br>ii lili cilena c il aila<br><!-- End of picture text -->  
92  
<!-- Start of picture text -->
A lc a il<br>iin lc<br>liallila Wc cil WcWaite llaac lai elelial alaallll lalal<br>iiaaaa Wil cil il la iel llll lal lal<br>ia Wil ila ll lal<br>iaii Willa Wc ila eidll ll ll lalaaa)<br>eaeaa cll Wil il ila lall lllellal lal<br>i a Wc i li elsil lilll lalia<br>ia Will cil la elll lillal<br>Sac<br>iia cil sllae l lil ll<br>aa Wc i elil l ill ialal<br><!-- End of picture text -->  
93  
<!-- Start of picture text -->
=<br>a<br>accel<br>ll la<br>am<br>a a ellcl ll  ia ll  lad=<br>am cl allll laad<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta parcial** -->
O **Quadro S** apresenta a avaliação geral da evidência para o desfecho taxa de resposta parcial.  
94  
**Quadro S -** Avaliação geral da evidência – taxa de resposta parcial.  
<!-- Start of picture text -->
Comparacées Viés do estudo Indirectness Heterogeneidade<br>publicagao Final<br>on et [ee ee oe ee<br>=Everolimo - Lenvatinibe 1 |ES Sem preocupacées Nao detectado | Sempreocupacdes | Sempreocupacées | Grande preocupacao | Sem preocupacées<br>Lenvatinibe - Lenvatinibe 1 | Sem preocupacées Nao detectado | Sempreocupacdes | Grande preocupacao | Sem preocupacdes | Sem preocupacées<br>= SE Ee rer<br>a ac ial aa la laa<br>l<br>lla bl =<br><!-- End of picture text -->  
95  
<!-- Start of picture text -->
Comparacées Viés do estudo Heterogeneidade<br>publicagéo Final<br>on ter Le ee eee bo ee<br>aAxitinibe - Lenvatinibe Semcipreocupagées N&o detectado | Semal preocupacées | Grande preocupacdola| Sem preocupacdes GlasSem preocupagées<br>=~ SE Er i<br>Slinalealia lal all<br>el sl il cl cia =<br>ae l l l iad bala<br>lll il claa =<br>[SamaraclCabozantinibe - Lenvatinibe o[‘Semsarepreocupagées [ReaiaeN&o detectado | Semeolll preocupacées |[saeGrande preocupacdo | i[arm Sem preocupacdes a  bala[SNASem preocupacées<br>Se i P|<br>Silinlaiead al allis il aum l balaci =<br>Sail<br>iii[Saas olaisarsass [Reenail allall[saal[seameaditl ala bala[Sar =<br>ic<br>il ll ial<br><!-- End of picture text -->  
96  
<!-- Start of picture text -->
Comparagdes Viés do estudo Viés de Heterogeneidade Incoeréncia Avaliagéo<br>publicaggo Final<br>Everolimo - Pazopanibe [°| ‘Algumas preocupacées | Naodetectado | Sempreocupagées | Grande preocupacao | Sem preocupagdes _| Sem preocupacdes<br>Everolimo - Sorafenibe I°| Algumas preocupacées | N3odetectado | Sem preocupacdes | Grande preocupacao | Sem preocupagées ‘Sem preocupagées<br>Everolimo - Tensirolimo [°| Algumas preocupacées | Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupagées ‘Sem preocupacées emo<br>Lenvatinibe - Nivolumabe [| Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées _| Sem preocupacdes<br>Lenvatinibe - Pazopanibe °| Algumas preocupacées | Naodetectado | Sem preocupacées | Grande preocupacao | Sem preocupacdes —_| Sem preocupacdes [fee |<br>Lenvatinibe - Placebo °| ‘Sem preocupagées Nao detectado | Sem preocupacées | Sem preocupacdes | Grande preocupacao | Sem preocupacdes<br>Lenvatinibe - Sorafenibe [°| ‘Sem preocupacées. Nao detectado | Sempreocupacées | Sempreocupacées | Grande preocupacao | Sem preocupacdes<br>Lenvatinibe - Sunitinibe [°| ‘Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées ‘Sem preocupacées<br>Lenvatinibe - Tensirolimo [°| ‘Sem preocupacdes Nao detectado | Sempreocupacées | Sem preocupacdes | Grande preocupacio | Sem preocupacdes<br>Lenvatinibe Everolimo - ‘Sem preocupagdes Nao detectado | Sem preocupacdes | Grande preocupagao | Sem preocupacdes __| Sem preocupacGes<br>Nivolumabe<br>Lenvatinibe Everolimo - ‘Algumas preocupagées | Nao detectado | Sem preocupacdes | Grande preocupacao | Sem preocupacées _ | Sem preocupacées<br>Pazopanibe<br>Lenvatinibe Everolimo - Sem preocupagdes Nao detectado | Sem preocupacées | Sem preocupagdes | Grande preocupacdo | Sem preocupages<br>Placebo<br>Lenvatinibe Everolimo - ‘Sem preocupagées Nao detectado | Sem preocupacdes | Grande preocupagao | Sem preocupacdes | Sem preocupacées<br>Sorafenibe<br><!-- End of picture text -->  
97  
<!-- Start of picture text -->
Comparagées Viés do estudo Heterogeneidade<br>publicagéo Final<br>anLenvatinibe Everolimo - teeSem preocupacées N&oele detectado | Sem preocupacées | Grandebepreocupacao | Semeepreocupacées ‘Semeepreocupacées<br>SS<br>Lenvatinibe Everolimo - Sem preocupacées N&oS detectado | S e m preocupagées | Gr a nde preocupacdo | Sem preocupacées Sem preocupagées<br>SS SEE<br>Sara [o[ Soe [Rar [Son [San [Seem<br>Psmacrae — [o[arisem ar [Seems [sores [ota [Som<br>aS [oleae [ar [See [Seren [Sean [Sr<br>Rama cae _[o[ arene [ear [Sen [aarmane Sern<br>ialea bllesabailball<br>mars [olson [iar [Srey [Serene [satan re<br>[semaesa [o[somree [ WleSeeaeoso  ll[ear[eama r  lS[ren [ srrSon [aarmane[Sreeran [ sammestraneSaaaal[Sombalsa ==a<br>Sl<br>ll llbl bl<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Taxa de resposta – doença estável** -->
O **Quadro T** apresenta a avaliação geral da evidência para o desfecho taxa de resposta em doença estável.  
98  
**Quadro T -** Avaliação geral da evidência – taxa de resposta para doença estável.  
<!-- Start of picture text -->
=<br>a a ea<br>SeEverolimo-Lenvatinibe | 1 | Sem preocupacdes Nao detectado ‘Sem preocupacéesnn| Grande preocupacao | Sem preocupacées _ | Sem preocupacées<br>in lll all alka cial<br>aLenvatinibe -Lenvatinibe | 1 | Sem preocupacéesllNao detectado Semlilpreocupacées | Grandeell preocupacao |ballSem preocupacées Semciapreocupacées<br>SSP<br>esas lll Eeld Eeesl bla cia<br>ciaial WlllUlll iald alkil ll alaiad=<br>linala Wll l l ldald alci blachil ciia d<br>n l<br>ll lhl cid<br><!-- End of picture text -->  
99  
<!-- Start of picture text -->
ce Meedoenne ee depunleste [irareemess[imerssto | Neterogenetaas [rere [Aeaasto Fat<br>Axitinibe - Lenvatinibe [°| ‘sem preocupacées Nao detectado Sem preocupagées | Grande preocupacao | Sem preocupacées _| Sem preocupacées<br>Axitinibe - Lenvatinibe Sem preocupagées Nao detectado Sem preocupagdes | Grande preocupacao | Sem preocupagdes | Sem preocupacées<br>Everolimo<br>Axitinibe - Nivolumabe [°| Sem preocupacées No detectado ‘Sem preocupagées | Grande preocupacdo | Sem preocupacées | Sem preocupacées<br>Axitinibe - Pazopanibe [°| ‘Algumas preocupacées | Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupacdes | Sem preocupacdes<br>Axitinibe - Placebo [°| ‘Sem preocupacées Nao detectado Sem preocupacées | Sem preocupacées | Grande preocupacao | Sem preocupacées<br>Axitinibe - Sunitinibe [°| Sem preocupacdes Nao detectado ‘Sem preocupagées | Grande preocupacao | Sem preocupagdes | Sem preocupacées<br>Axitinibe - Tensirolimo [°| Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupacdes | Sem preocupacdes<br>Cabozantinibe - Sem preocupacées Nao detectado Sem preocupagées | Sem preocupacées | Grande preocupacao | Sem preocupacées<br>Lenvatinibe<br>Cabozantinibe - Sem preocupagées Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupacées | Sem preocupacées<br>Lenvatinibe Everolimo<br>Cabozantinibe - Sem preocupagées Nao detectado ‘Sem preocupacées | Sem preocupagées | Grande preocupacao | Sem preocupagdes<br>Nivolumabe<br>Cabozantinibe - Algumas preocupacées | Nao detectado ‘Sem preocupacées | Grande preocupago | Sem preocupacées | Sem preocupagées | Baixo<br>Pazopanibe<br>Cabozantinibe - Placebo [°| Sem preocupacées Nao detectado ‘Sem preocupacées | Sem preocupacées | Grande preocupacao | Sem preocupacées<br><!-- End of picture text -->  
100  
<!-- Start of picture text -->
[emrmene[r[Wmcoete[earcetintCabozantinibe - Sem preocupacées N&o detectado [acresSem preocupacéesewes| Sem preocupagées: [RewemnaeGrande preocupa¢ao |[oeoSem p r eot c upacées[bee]<br>= Pe ees ee<br>a A a a a<br>=Cabozantinibe - Sem preocupacées N&o detectado Sem preocupacées | Sem preocupacées. Grande preocupacao | Sem preocupacées<br>[Frame Pacnae [| Remaoascniie [Rsaeazaie | Sm e icniiee| a e neoaas [S e nco | Senae aT<br>[Eeamermataie [Oo [semaroamoe [atin [Emoone [Emomone [Sani RenEe | SAT<br>[EeamorTentatno[SRSA [@[Senaroua[Rraracaie[Smomaneie[Smoicnsie [Sudeneani |Sats<br>[Rae [9[SemeoTS | RaRaTaao Rac TERRORS [Sem ESRS | eS<br>[vate PatoFronaie [ 0 [SenarRem o umatamecie [Rea[Mrara r aie[Smoeaniempm  [a| nie pROGRATSvsouats [ SereoSom a natn || S enetAO |ARN<br>[Reareraaeabe [9 [semacoamne | Raracaie[Smoeicie | ae RRaGRAS [Sone | eA<br>[ema inabe [9 [Semacoamaa [RaaRcase | Smac | Rie ROSAS [Sem | STS<br>[enatabe Tenia [9 [Sewaroumia [narrate Soeicnie [eae osouaias [Sereaannt | Sets<br>=eLenvatinibe Everolimo - Sem preocupacées N&o detectado Sem preocupacées | Grande preocupacdo | Sem preocupacées Sem preocupacées<br>Lenvatinibe Everolimo eS Sas<br>a - ffAlgumas preocupacGes | N3o detectado Sem preocupacées | Grande preocupacdo | Sem preocupacées Sem preocupacées | Baixo<br><!-- End of picture text -->  
101  
<!-- Start of picture text -->
SS<br>Lenvatinibe Everolimo - Sem preocupacées Nao= detectado ‘Sem preocupacées=| Sem preocupacées Grande=preocupacao | Sem preocupagées<br>eeLenvatinibe Everolimo - eeSem preocupacées Nao detectado Sem preocupagées | Grande preocupacao | Sem preocupacées Sem preocupacées<br>SSLenvatinibe Everolimo- ‘Sem preocupacées PSNao detectado See‘Sem preocupacées | Grande preocupacao | Sem preocupacées | Sem preocupacdes<br>SR ee<br>Lenvatinibe Everolimo - Sem preocupagées N&o detectado Sem preocupagées | Grande preocupacdo | Sem preocupacées Sem preocupagées<br>Se P|<br>Lsfameisd[e[meaneillill[aes lal[amen ballad [sarmensbal aliarm [aalald=<br>caical l a llallacl Ml ala<br>Sai alia ala<br>Peas sae iileerrene soooil[ sero |alllors [sores ll=<br>Pee |e sereene ieee _[Sreene [seers sere oe<br>i a lca Nal al<br>ae aa Se pepe S|<br><!-- End of picture text -->  
<!-- Start of picture text -->
=<br>Sa a [Sa=See saene eee [eea<br><!-- End of picture text -->  
102

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **O Quadro U apresenta a avaliação geral da evidência para o desfecho taxa de resposta para doença progressiva.** -->
**Quadro U -** Avaliação geral da evidência – taxa de resposta para doença progressiva.  
<!-- Start of picture text -->
Viés de Avaliacéo<br>Viés do estudo publicacéo Imprecisdo Final<br>Axitinibe - Sorafenibe ‘Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées ‘Sem preocupagdes<br>Cabozantinibe - Sem preocupacdes Nao detectado | Sem preocupacées | Sem preocupacdes —_| Grande preocupaco_| Sem preocupacées<br>Everolimo<br>Everolimo - 1 | Sem preocupagées Nao detectado | Sem preocupacdes | Sem preocupades | Grande preocupagao_| Sem preocupagdes<br>Lenvatinibe Everolimo<br>Everolimo - 1 | Sem preocupacées Nao detectado | Sem preocupacdes | Sem preocupacdes | Grande preocupacao_| Sem preocupagoes<br>Lenvatinibe<br>Everolimo - 1 | Sem preocupacdes Nao detectado | Sem preocupacdes | Sem preocupacdes | Grande preocupaco_ | Sem preocupacdes<br>Nivolumabe<br>Everolimo - Placebo ‘Sem preocupacées Nao detectado | Sem preocupacdes | Sem preocupacdes Grande preocupac3o | Sem preocupacdes<br>Everolimo - Sunitinibe Sem preocupacées Nao detectado | Sem preocupacdes | Grande preocupacao | Sem preocupacées __| Sem preocupagoes<br>Lenvatinibe - 1 | Sem preocupacées Nao detectado | Sem preocupacdes | Grande preocupacao | Sem preocupacées _| Sem preocupagdes<br>Lenvatinibe Everolimo<br>Pazopanibe - 1 | Grande preocupacso | Naodetectado | Sem preocupacdes | Sem preocupacées | Grande preocupacao | Sem preocupacdes<br>Sorafenibe<br>Placebo - Sorafenibe + Sem preocupagées Nao detectado | Sem preocupaces | Sempreocupacdes | Grande preocupacao_| Sem preocupacdes<br>Sorafenibe - Sunitinibe ‘Algumas preocupagées | Naodetectado | Sem preocupacées | Grande preocupacao | Sem preocupacdes ‘Sem preocupagées<br><!-- End of picture text -->  
103  
<!-- Start of picture text -->
Comparacées Viés do estudo Viés de Heterogeneidade Incoeréncia Avaliagao<br>publicagéo Final<br>Sorafenibe - 1 | Sem preocupacées Nao detectado | Sem preocupacdes | Grande preocupaco | Sem preocupagdes _| Sem preocupacdes<br>Tensirolimo<br>Axitinibe - Sem preocupasées Nao detectado | Sem preocupacdes | Sem preocupagées | Grande preocupacao | Sem preocupacées<br>Cabozantinibe<br>Axitinibe - Everolimo | Sem preocupacées Nao detectado | Sem preocupagdes | Grande preocupacdo | Sem preocupacées ‘Sem preocupacdes<br>Axitinibe - Lenvatinibe Sem preocupacées Nao detectado | Sem preocupacdes | Sem preocupagées | Grande preocupacao | Sem preocupacées<br>Everolimo<br>Axitinibe - Lenvatinibe | Sem preocupagdes Nao detectado | Sem preocupaces | Sem preocupacées —_| Grande preocupacdo | Sem preocupacées<br>Axitinibe - Nivolumabe | Sem preocupagdes Nao detectado | Sem preocupacdes | Grande preocupac3o | Sem preocupacées | Sem preocupacées<br>‘Axitinibe - Pazopanibe | ‘Algumas preocupagées | Naodetectado | Sem preocupagdes | Grande preocupacdo | Sem preocupacdes ‘Sem preocupacées<br>Axitinibe - Placebo | Sem preocupagdes Nao detectado | Sem preocupacées | Sem preocupacées —_| Grande preocupacdo | Sem preocupacées<br>Axitinibe - Sunitinibe 1° Algumas preocupacdes | N3odetectado | Sem preocupacées | Grande preocupacio | Sem preocupacdes ‘Sem preocupagées<br>Axitinibe - Tensirolimo | Sem preocupacées Nao detectado | Sem preocupagdes | Grande preocupacdo | Sem preocupacées ‘Sem preocupacées<br>Cabozantinibe - Sem preocupasées Nao detectado | Sem preocupacdes | Grande preocupaco | Sem preocupagdes _| Sem preocupacdes<br>Lenvatinibe Everolimo<br>Cabozantinibe - Sem preocupasées Nao detectado | Sem preocupacdes | Grande preocupacao | Sem preocupagdes _| Sem preocupacdes<br>Lenvatinibe<br><!-- End of picture text -->  
104  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de Avaliagao<br>publicagéo Final<br>Cabozantinibe - ‘Sem preocupacées Nao detectado | Sem preocupagées | Sempreocupagdes | Grande preocupacao | Sem preocupagdes<br>Nivolumabe<br>Cabozantinibe - ‘Algumas preocupagées | Ndodetectado | Sem preocupacdes | Grande preocupacdo | Sempreocupagdes | Sem preocupacdes | Baixo<br>Pazopanibe<br>Cabozantinibe - ‘Sem preocupagées Nao detectado | Sem preocupacées | Sem preocupagdes Grande preocupacao | Sem preocupagées<br>Placebo<br>Cabozantinibe - ‘Sem preocupagées Nao detectado | Sem preocupacées | Sem preocupagées Grande preocupacao | Sem preocupagées<br>Sorafenibe<br>Cabozantinibe - ‘Sem preocupagdes Nao detectado | Sempreocupacées | Grande preocupagao | Sem preocupacdes ‘Sem preocupagdes<br>Sunitinibe<br>Cabozantinibe - ‘Sem preocupagées Nao detectado | Sem preocupacées | Sempreocupagdes | Grande preocupacao | Sem preocupagdes<br>Tensirolimo:<br>Everolimo - ‘Algumas preocupagées | Ndodetectado | Sem preocupacdes | Grande preocupacdo | Sem preocupagdes | Sem preocupacdes | Baixo<br>Pazopanibe<br>Everolimo - Sorafenibe | ‘Sem preocupacées Nao detectado | Sem preocupagées | Grande preocupac3o | Sempreocupacées | Sem preocupacdes<br>Everolimo - ‘Sem preocupacées Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Sem preocupagdes<br>Tensirolimo<br><!-- End of picture text -->  
105  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de<br>publicagéo<br>Lenvatinibe Everolimo Sem preocupagdes Nao detectado | Sem preocupagdes | Sem preocupacées | Grande preocupacao | Sem preocupacées<br>- Nivolumabe<br>Lenvatinibe Everolimo Algumas preocupacdes | Naodetectado | Sem preocupacées | Grande preocupacao | Sem preocupacées | Sem preocupacdes | Baixo<br>- Pazopanibe<br>Lenvatinibe Everolimo Sem preocupagdes Nao detectado | Sem preocupagdes | Sem preocupagdes | Grande preocupacado | Sem preocupagées<br>- Placebo<br>Lenvatinibe Everolimo Sem preocupagdes Nao detectado | Sem preocupagdes | Sem preocupacdes | Grande preocupacao | Sem preocupagées<br>-Sorafenibe<br>Lenvatinibe Everolimo Sem preocupagdes Nao detectado | Sem preocupagdes | Grande preocupacao | Sem preocupagdes | Sem preocupagées,<br>- Sunitinibe<br>Lenvatinibe Everolimo Sem preocupagdes Nao detectado | Sem preocupagdes | Sempreocupacdes | Grande preocupacdo | Sem preocupagdes<br>-Tensirolimo<br>Lenvatinibe - Sem preocupagdes Nao detectado | Sem preocupagdes | Sem preocupacées | Grande preocupacao_| Sem preocupacées<br>Nivolumabe<br>Lenvatinibe - Algumas preocupagdes | Naodetectado | Sem preocupagdes | Grande preocupacdo | Sempreocupacdes | Sem preocupagdes | Baixo<br>Pazopanibe<br>Lenvatinibe - Placebo | Sem preocupagdes No detectado | Sem preocupacdes | Sem preocupacdes Grande preocupacao | Sem preocupacdes<br><!-- End of picture text -->  
106  
<!-- Start of picture text -->
Viés de<br>Viés do estudo Heterogeneidade<br>publicacéo<br>Lenvatinibe - Sem preocupagées Nao detectado | Sem preocupacées | Sem preocupagées Grande preocupacao | Sem preocupacées<br>Sorafenibe<br>Lenvatinibe - Sem preocupagées Nao detectado | Sem preocupacées | Sem preocupagées Grande preocupa¢do | Sem preocupacées<br>Sunitinibe<br>Lenvatinibe - ‘Sem preocupagdes Nao detectado | Sempreocupagdes | Sempreocupacdes | Grande preocupacdo | Sem preocupacées<br>Tensirolimo<br>Nivolumabe - ‘Algumas preocupagées | Naodetectado | Sempreocupacdes | Sem preocupacées | Grande preocupacao | Sem preocupagdes<br>Pazopanibe<br>Nivolumabe - Placebo | °| ‘Sem preocupagdes Nao detectado | Sempreocupacées | Sem preocupacdes Grande preocupacao | Sem preocupacées<br>Nivolumabe - Sem preocupagées Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupacées Sem preocupacées<br>Sorafenibe<br>Nivolumabe - Sem preocupages Nao detectado | Sem preocupagées | Sem preocupacées Grande preocupacdo | Sem preocupagées<br>Sunitinibe<br>Nivolumabe - Sem preocupagées Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupagées Sem preocupagées<br>Tensirolimo<br>Pazopanibe - Placebo | Algumas preocupagées | Naodetectado | Sem preocupagées | Sempreocupagées | Grande preocupacdo | Sem preocupacdes<br>Pazopanibe - ‘Algumas preocupagées | Naodetectado | Sempreocupacdes | Grande preocupagdo | Sem preocupagdes | Sem preocupagdes<br>Sunitinibe<br><!-- End of picture text -->  
107  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparagées Viés de<br>publicacdo<br>Pazopanibe - ‘Algumas preocupagées | Naodetectado | Sem preocupacées | Grande preocupacao | Sem preocupacées | Sem preocupacées<br>Tensirolimo<br>Placebo - Sunitinibe | °| ‘Sem preocupacées Nao detectado | Sem preocupagées | Sem preocupacées Grande preocupagdo | Sem preocupacées<br>Placebo - Tensirolimo | °| ‘Sem preocupagées Nao detectado | Sem preocupagdes | Sem preocupagées _| Grande preocupacao | Sem preocupacdes<br>Sunitinibe - Algumas preocupagées | Naodetectado | Sem preocupaces | Grande preocupacdo | Sem preocupacées | Sem preocupacées<br>Tensirolimo<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Eventos adversos gerais** -->
O **Quadro V** apresenta a avaliação geral da evidência para o desfecho eventos adversos gerais.  
108  
**Quadro V -** Avaliação geral da evidência – evento adverso geral.  
<!-- Start of picture text -->
Comparacées Viés do estudo Viés de Indirectness Heterogeneidade ‘Avaliagao<br>publicacéo Final<br>Axitinibe - Sorafenibe Sem preocupacdes ‘Sem preocupacdes | Grande preocupacao | Sem preocupacdes | Grande preocupacao<br>Cabozantinibe - 1 | Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Everolimo<br>Everolimo - Lenvatinibe Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Everolimo -Lenvatinibe | 1 | Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacéo | Sem preocupagées | Grande preocupacdo<br>Everolimo<br>Everolimo - Nivolumabe Sem preocupacées Sem preocupacées | Grande preocupacio | Sempreocupacées | Grande preocupacao<br>Everolimo - Placebo Sem preocupacées Sem preocupacées | Grande preocupacdo | Sempreocupacées | Sem preocupacdes<br>Everolimo - Sunitinibe Sem preocupacées ‘Sem preocupacées | Grande preocupacio | Sempreocupacées | Sem preocupacées<br>Lenvatinibe - Lenvatinibe [1 | Sem preocupacdes Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br>Everolimo<br>Pazopanibe - Sorafenibe Grande preocupacso | Naodetectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupac3o<br>Placebo - Sorafenibe Sem preocupagdes Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupaces | Sem preocupagdes<br>Sorafenibe - Sunitinibe Algumas preocupacées | Naodetectado | Sem preocupacdes | Grande preocupacdo | Sem preocupagdes | Sem preocupagdes<br>Sorafenibe - Tensirolimo Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br>Axitinibe - Cabozantinibe °| Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br><!-- End of picture text -->  
109  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de Avaliacéo<br>publicacéo Final<br>Axitinibe - Everolimo °| Sem preocupacdes Sem preocupacées | Grande preocupac3o | Sem preocupacées | Grande preocupacao<br>Axitinibe - Lenvatinibe | Sem preocupagdes Nao detectado | Sem preocupacées | Grande preocupac3o | Sem preocupagées | Grande preocupaco<br>Axitinibe - Lenvatinibe Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées | Grande preocupacao<br>Everolimo<br>Axitinibe - Nivolumabe °| Sem preocupacées No detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées | Grande preocupacao<br>Axitinibe - Pazopanibe °| ‘Algumas preocupacées | N3odetectado | Sempreocupagdes | Grande preocupag3o | Sem preocupacées | Grande preocupacao<br>Axitinibe - Placebo °| Sem preocupacoes Nao detectado | Sem preocupacées | Grande preocupac3o | Sem preocupacdes | Grande preocupacao<br>Axitinibe - Sunitinibe °| Algumas preocupacées | N3odetectado | Sem preocupacées | Grande preocupac3o | Sem preocupagées | Grande preocupacao<br>Axitinibe - Tensirolimo. "| Sem preocupacées Nao detectado | Sempreocupagées | Grande preocupacdo | Sempreocupacées | Grande preocupacao.<br>Cabozantinibe - Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacao | Sem preocupagées | Grande preocupacao<br>Lenvatinibe<br>Cabozantinibe - Sem preocupacées Nao detectado | Sem preocupaces | Grande preocupacao | Sem preocupagées | Grande preocupacao<br>Lenvatinibe Everolimo<br>Cabozantinibe - Sem preocupacées Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br>Nivolumabe<br>Cabozantinibe - ‘Algumas preocupagdes | Naodetectado | Sem preocupacées | Grande preocupacao | Sem preocupagées | Grande preocupacao<br>Pazopanibe<br><!-- End of picture text -->  
110  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de Avaliagao<br>publicagéo Final<br>Cabozantinibe - Placebo °| Sem preocupacées Nao detectado | Sempreocupacées | Grande preocupacio | Sempreocupacées | Grande preocupacao<br>Cabozantinibe - ‘Sem preocupagdes Nao detectado | Sempreocupacgées | Grande preocupacdo | Sempreocupacées | Grande preocupacao<br>Sorafenibe<br>Cabozantinibe - Sem preocupagées Nao detectado | Sempreocupagées | Grande preocupacio | Sem preocupacées | Grande preocupacao<br>Sunitinibe<br>Cabozantinibe - Sem preocupagdes Nao detectado | Sem preocupacées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Tensirolimo:<br>Everolimo - Pazopanibe °| Algumas preocupacdes | Nao detectado | Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacao<br>Everolimo - Sorafenibe °| Sem preocupagdes Nao detectado | Sempreocupacées | Grande preocupacao | Sem preocupacées | Grande preocupacao<br>Everolimo - Tensirolimo P| Sem preocupagdes Sem preocupacées | Grande preocupacdo | Sem preocupacdes | Grande preocupacao<br>Lenvatinibe - Sem preocupagées Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Nivolumabe<br>Lenvatinibe - Pazopanibe °| Algumas preocupagdes | Nao detectado | Sem preocupagées | Grande preocupacso | Sem preocupagées | Grande preocupacao<br>Lenvatinibe - Placebo °| Sem preocupacdes Nao detectado | Sempreocupacées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Lenvatinibe - Sorafenibe | ‘Sem preocupagdes Nao detectado | Sempreocupacées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Lenvatinibe - Sunitinibe °| Sem preocupacées Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br><!-- End of picture text -->  
111  
<!-- Start of picture text -->
Viés do estudo Heterogeneidade<br>Comparacées Viés de Avaliacao<br>publicacdo Final<br>Lenvatinibe - Sem preocupagées Nao detectado | Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacdo<br>Tensirolimo<br>Lenvatinibe Everolimo- Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacdes | Grande preocupacao<br>Nivolumabe<br>Lenvatinibe Everolimo - ‘Algumas preocupacées | Ndodetectado | Sem preocupacdes | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Pazopanibe<br>Lenvatinibe Everolimo - Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupagao<br>Placebo<br>Lenvatinibe Everolimo - Sem preocupagdes Nao detectado | Sem preocupagdes | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Sorafenibe<br>Lenvatinibe Everolimo - Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacdes | Grande preocupagao<br>Sunitinibe<br>Lenvatinibe Everolimo - Sem preocupacdes Nao detectado | Sem preocupagdes | Grande preocupacdo | Sem preocupacdes | Grande preocupacao<br>Tensirolimo<br>Nivolumabe - ‘Algumas preocupagdes | Ndodetectado | Sem preocupacées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Pazopanibe<br>Nivolumabe - Placebo [°| Sem preocupacdes ‘Sem preocupacées | Grande preocupac3o | Sempreocupacées | Grande preocupacao<br>Nivolumabe - Sorafenibe [| Sem preocupagdes Nao detectado | Sempreocupacées | Grande preocupacdo | Sem preocupacdes | Grande preocupacdo<br><!-- End of picture text -->  
112  
<!-- Start of picture text -->
Comparacdes Viés do estudo Viés de Heterogeneidade Avaliacéo<br>publicacao Final<br>Nivolumabe - Sunitinibe [° Sem preocupagdes Nao detectado | Sempreocupagdes | Grande preocupacao | Sem preocupagdes | Grande preocupacao<br>Nivolumabe - Sem preocupacdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Tensirolimo<br>Pazopanibe - Placebo ° | Algumas preocupacdes | Ndodetectado | Sempreocupacées | Grande preocupacao | Sempreocupacées | Grande preocupacao<br>Pazopanibe - Sunitinibe °| Grande preocupacao Nao detectado | Sempreocupacdes | Grande preocupacio | Sem preocupagdes | Grande preocupacao<br>Pazopanibe - Tensirolimo °| Algumas preocupacées | Naodetectado | Sem preocupacées | Grande preocupacao | Sempreocupacées | Grande preocupacao<br>Placebo - Sunitinibe [°| Sem preocupacées Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Placebo - Tensirolimo [°| Sem preocupagdes Nao detectado | Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Sunitinibe - Tensirolimo [°| Algumas preocupacdes | Naodetectado | Sem preocupacdes | Grande preocupacao | Sem preocupacées | Grande preocupacao<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Evento adverso grave** -->
O **Quadro W** apresenta a avaliação geral da evidência para o desfecho eventos adversos graves.  
113  
**Quadro W -** Avaliação geral da evidência – evento adverso grave.  
<!-- Start of picture text -->
Viés do estudo Viés de publicacao Heterogeneidade<br>Comparacées AvaliacéoFinal<br>‘Axitinibe - Sorafenibe Sem preocupagdes Nao detectado Sem preocupagées | Grande preocupagao | Sem preocupacées | Grande preocupacao<br>CabozantinibeEverolimo - 1 | Sem preocupacées Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>EverolimoLenvatinibe- 1 | Sem preocupacées Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupacées | Grande preocupacao<br>EverolimoLenvatinibe- Everolimo 1 | Sem preocupacées Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupacées | Grande preocupacao<br>Everolimo<br>Nivolumabe- 1 | Sem preocupacées Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupacées | Grande preocupacdo<br>Everolimo - Placebo ‘Sem preocupacdes Nao detectado Sem preocupagées | Grande preocupacao | Sempreocupacées | Sem preocupacées<br>Everolimo - Sunitinibe ‘Sem preocupagdes Nao detectado Sem preocupagées | Grande preocupacio | Sempreocupacées | Sem preocupacées<br>LenvatinibeLenvatinibe -Everolimo 1 | Sem preocupacées Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>PazopanibeSorafenibe - 1 | Grande preocupacio —_| Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupacées | Grande preocupacao<br>Placebo - Sorafenibe ‘Sem preocupacdes Nao detectado ‘Sem preocupagées | Grande preocupagao | Sem preocupagdes | Sem preocupacdes<br>Sorafenibe - Sunitinibe Algumas preocupacdes | Nao detectado Sem preocupagées | Grande preocupacao | Sem preocupagdes | Sem preocupacdes<br><!-- End of picture text -->  
114  
<!-- Start of picture text -->
Viés do estudo Viés de publicacéo Heterogeneidade<br>Comparacées AvaliacaoFinal f<br>TensirolimoSorafenibe - 1 | sem preocupasées No detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacéo<br>CabozantinibeAxitinibe - Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacao<br>‘Axitinibe - Everolimo. | ‘Sem preocupagdes Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br>Axitinibe - Lenvatinibe | Sem preocupacdes No detectado Sem preocupacdes | Grande preocupacdo | Sem preocupacées | Grande preocupacao<br>Axitinibe - Lenvatinibe<br>Everolimo\ Sem preocupacées No detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées_| Grande preocupacao<br>Axitinibe - Nivolumabe | Sem preocupagdes Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacao<br>‘Axitinibe - Pazopanibe | Algumas preocupacées | Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupagées | Grande preocupacao<br>Axitinibe - Placebo | Sem preocupagdes Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacao<br>Axitinibe - Sunitinibe | Algumas preocupacées | Nao detectado Sem preocupacées | Grande preocupacio | Sem preocupacées | Grande preocupacao<br>Axitinibe - Tensirolimo | Sem preocupagdes Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacdo<br>Cabozantinibe-Lenvatinibe Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacio | Sem preocupacées | Grande preocupaco<br>CabozantinibeLenvatinibe Everolimo- Sem preocupacdes Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées_| Grande preocupaco<br><!-- End of picture text -->  
115  
<!-- Start of picture text -->
Comparagées Viés do estudo Viés de publicagéo Indirectness Heterogeneidade AvaliagéoFinal '<br>Cabozantinibe<br>Nivolumabe - Sem preocupagées No detectado Sem preocupacées | Grande preocupagdo | Sem preocupagées _| Grande preocupacéo<br>CabozantinibePazopanibe - Algumas preocupagées | Nao detectado Sem preocupacées | Grande preocupacdo | Sem preocupagées | Grande preocupaco<br>Cabozantinibe-<br>P lac eb.ebo Sem preocupagées Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupagées | Grande preocupacio<br>Cabozantinibe<br>Sorafenibe - Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupagao<br>Cabozantinibe -<br>Sunitinibe7 Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupagao<br>Cabozantinibe-<br>_<br>Tensirolimo Sem preocupagées Nao detectado Sem preocupacées | Grande preocupacéo | Sem preocupacées | Grande preocupacao<br>Everolimo<br>- Algumas preocupagées | Nao detectado Sem preocupacées | Grande preocupagdo | Sem preocupagdes_| Grande preocupacdo<br>Pazopanibe<br>Everolimo - Sorafenibe ° | ‘Sem preocupacées Nao detectado Sem preocupagées | Grande preocupacao | Sem preocupacées | Grande preocupacao<br>Everolimo<br>Tensirolimo- Sem preocupagées Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupagées _| Grande preocupacio<br><!-- End of picture text -->  
116  
<!-- Start of picture text -->
Vigs do estudo Viés de publicacéo Impreciséo Heterogeneidade<br>Comparacées ‘AvaliagaoFinal<br>NivolumabeLenvatinibe - Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacdo | Sem preocupacées _| Grande preocupacdo<br>LenvatinibePazopanibe - Algumas preocupacées | Nao detectado Sem preocupacées | Grande preocupagdo | Sem preocupacées _| Grande preocupacao<br>Lenvatinibe - Placebo ° | ‘Sem preocupacdes Nao detectado Sem preocupagées | Grande preocupacao | Sempreocupacées | Grande preocupacao<br>Lenvatinibe -<br>Sorafenibe Sem preocupagées Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupagées | Grande preocupacao<br>SunitinibeLenvatinibe - Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacdo | Sem preocupacées _| Grande preocupacao<br>Lenvatinibe -<br>;<br>Tensirolimo Sem preocupacées Nao detectado Sem preocupacées | Grande preocupagdo | Sem preocupacées | Grande preocupacdo<br>-LenvatinibeNivolumabeEverolimo Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacdo | Sem preocupacées _| Grande preocupacao<br>Lenvatinibe Everolimo<br>- Pazopanibe Algumas preocupagdes_| Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupacées_| Grande preocupacao<br>-LenvatinibePlacebo Everolimo Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacao | Sem preocupacées | Grande preocupacio<br><!-- End of picture text -->  
117  
<!-- Start of picture text -->
‘Avaliagao<br>comparaées a vitsdoestudo | vies de pulcagio | indrectness | imprecséo | Heterogeneidade | Final<br>Lenvatinibe Everolimo<br>;<br>- Sorafenibe Sem preocupagées Nao detectado Sem preocupacées | Grande preocupac3o | Sem preocupagées_| Grande preocupac3o<br>-LenvatinibeSunitinibe Everolimo Sem preocupacées Nao detectado Sem preocupacées | Grande preocupac3o | Sem preocupagées | Grande preocupacao<br>Lenvatinibe Everolimo<br>;<br>-Tensirolimo Sem preocupacées Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupagées | Grande preocupacio<br>PazopanibeNivolumabe - Algumas preocupacées | Nao detectado Sem preocupacées | Grande preocupac3o | Sem preocupagées | Grande preocupacao<br>Nivolumabe - Placebo | ‘Sem preocupacées Sem preocupacées | Grande preocupacao | Sempreocupacées | Grande preocupacao<br>Nivolumabe<br>Sorafenibe - Sem preocupacées Nao detectado Sem preocupacées | Grande preocupacio | Sem preocupagées_| Grande preocupaco<br>Nivolumabe -<br>Sunitinibe Sem preocupagées Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupagées; | Grande preocupacdo<br>Nivolumabe -<br>Tensirolimo Sem preocupacées Nao detectado Sem preocupacées | Grande preocupac3o | Sem preocupagées | Grande preocupaco<br>Pazopanibe - Placebo | Algumas preocupagées | Nao detectado ‘Sem preocupacées | Grande preocupac3o | Sem preocupacées | Grande preocupacao<br>Pazopanibe-<br>Sunitinibe' Grande preocupacio_—_| Nao detectado Sem preocupagées | Grande preocupac3o | Sem preocupagées_| Grande preocupacio<br><!-- End of picture text -->  
118  
<!-- Start of picture text -->
Comparacées Viés do estudo Viés de publicacdo Indirectness Heterogeneidade AvaliacgaoFinal<br>Pazopanibe<br>Tensirolimo- Algumas preocupacées | Nao detectado Sem preocupagées | Grande preocupagdo | Sem preocupacées | Grande preocupacao<br>Placebo - Sunitinibe I? | ‘Sem preocupacées Nao detectado Sem preocupacdes | Grande preocupacdo | Sem preocupacdes | Grande preocupacao<br>Placebo - Tensirolimo I? | Sem preocupacées Nao detectado Sem preocupagdes | Grande preocupacdo | Sem preocupacdes | Grande preocupac3o<br>SunitinibeTensirolimo- Algumas preocupacées | Nao detectado Sem preocupagées | Grande preocupacdo | Sem preocupacées | Grande preocupaco<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Suspensão devido a Evento Adverso** -->
O **Quadro X** apresenta a avaliação geral da evidência para o desfecho suspensão devido a evento adverso.  
119  
**Quadro X-** Avaliação geral da evidência – suspensão devido a evento adverso.  
<!-- Start of picture text -->
Viés do estudo Vis de Imprecisio Heterogeneidade<br>publicagao<br>Axitinibe - Sorafenibe ‘Sem preocupaées ‘Sem preocupacées |Grande preocupago |Sem preocupacées _| Grande preocupagao<br>‘Cabozantinibe - Everolimo ‘Sem preocupagées Nao detectado | Sem preocupacées | Grande preocupagao |Sem preocupacées _ | Grande preocupacio<br>EverolimoEverolimo - Lenvatinibe 1| sem preocupagées N3o detectado |Sem preocupagdes | Grande preocupagao | Sem preocupagées _| Grande preocupacio<br>Everolimo - Lenvatinibe ‘Sem preocupacées N3o detectado | Sem preocupacées | Grande preocupacao | Sem preocupacées Grande preocupac’o<br>Everolimo - Nivolumabe | ‘Sem preocupagées N3o detectado | Sem preocupagdes | Grande preocupag3o |Sem preocupacées | Grande preocupago<br>Everolimo - Placebo ‘Sem preocupaées ‘Sem preocupacées |Grande preocupacao |Sem preocupacgées _ | Sem preocupacées<br>Everolimo - Sunitinibe ‘Sem preocupacées N3o detectado | Sem preocupacdes | Grande preocupac3o |Sem preocupacées _ | Sem preocupacdes<br>LenvatinibeEverolimo - Lenvatinibe Sem preocupagées Nao detectado |Sem preocupagées | Grande preocupagao | Sem preocupagées _| Grande preocupaco<br>Pazopanibe - Sorafenibe Grande preocupagdo |N3odetectado | Sem preocupagfes |Grande preocupac3o |Sem preocupagSes _| Grande preocupaco<br>Placebo - Sorafenibe ?| ‘Sem preocupagées Nao detectado | Sem preocupagées | Grande preocupago |Sem preocupacées | Sem preocupagoes<br>Sorafenibe - Sunitinibe ‘Algumas preocupacées ‘Sem preocupacées |Grande preocupago |Sem preocupacgées _ | Sem preocupacées<br>‘Sorafenibe - Tensirolimo ‘Sem preocupacées N3o detectado | Sem preocupagées | Grande preocupac3o |Sem preocupagées | Grande preocupaco<br><!-- End of picture text -->  
120  
<!-- Start of picture text -->
Comparagées Viés do estudo .<br>publicag30<br>i | er ee nel ee<br>[Seer<br>Sean Seas [are |<br>- Lenvatinibe<br>=Axitinibe Re Sa See a pe |<br>= fae ba baa ee<br>en fae ees aes eran fee Ser<br>aa lM il ell lac<br>an [pares Saas ee Sere ee S|<br>a a l l ilallla<br>c ei<br>la<br>- Lenvatinibe<br>=Cabozantinibe EH a ae eee ae |<br>== EEF Ee<br>Sa Eee Saas ee eres ee S|<br>Seeal[Paneallaes ee eeillee S|<br>| Saas Sear Seas Sree ae |<br>= SS Ss a Se<br><!-- End of picture text -->  
121  
<!-- Start of picture text -->
“<br>Vies de<br>Viés do estudo<br>publicac3o<br>‘Cabozantinibe - Sunitinibe ° ‘Sem preocupacoes Sem preocupacoes | Grande preocupagso |Sempreocupacoes | Grande preocupacso<br>Cabozantinibe - Tensirolimo ° ‘Sem preocupacdes Sem preocupacdes | Grande preocupag3o |Sempreocupacoes | Grande preocupac3o<br>Everolimo - Pazopanibe °| ‘Algumas preocupacées Sem preocupacées | Grande preocupac3o |Sempreocupacdes | Grande preocupac3o<br>Everolimo - Sorafenibe °| ‘Algumas preocupagdes Sem preocupacdes | Grande preocupac3o |Sempreocupasdes | Grande preocupac3o<br>Everolimo - Tensirolimo. °| ‘Sem preocupacoes Sem preocupacdes | Grande preocupac3o |Sem preocupasdes | Grande preocupac3o<br>Lenvatinibe Everolimo -<br>. . . . _ .<br>Nivolumabe Sem preocupacgdes N3odetectado |Sempreocupacées | Grande preocupag3o |Sempreocupagées | Grande preocupaci0<br>LenvatinibePazopanibe Everolimo - Algumas preocupagdes |N3odetectado |Sempreocupacdes | Grande preocupag3o |Sempreocupacdes _| Grande preocupac3o<br>Lenvatinibe Everolimo -<br>>‘lacebo Sem preocupagées N3odetectado |Sem preocupases | Grande preocupag3o |Sempreocupagées _| Grande preocupag3o<br>Lenvatinibe Everolimo -<br>. . . 7 ~ =,<br>Sorafenibe Sem preocupacdes N3odetectado |Sempreocupacées | Grande preocupag3o |Sempreocupagées | Grande preocupac30<br>LenvatinibeSunitinibe Everolimo - Sem preocupagées N3odetectado | Sem preocupagées | Grande preocupac3o |Sem preocupacées _| Grande preocupac3o<br>Lenvatinibe Everolimo -<br>.<br>Tensirolimo Sem preocupagées N3odetectado |Sem preocupagées | Grande preocupac3o |Sem preocupacées _| Grande preocupac3o<br>Lenvatinibe - Nivolumabe | ‘Sem preocupagdes Sem preocupacdes | Grande preocupac3o |Sempreocupacoes | Grande preocupac3o<br>4aa<br><!-- End of picture text -->  
122  
<!-- Start of picture text -->
. Viés de ~ gnci:<br>SSSea Viés doestudoed 3 GedIndirectness elImprecisao  Ged eelIncoeréncia  Kc<br>= SeeSSas ae Saaepee poeae Seee ||<br>= Se ae ares eens area ae<br>=== Se faa e paseres pe a aess eeeeae ae|<br>S es<br>Ke Se ae peeeres eranares areaeee [eee|<br>SSS<br>a See Saae peeSee Eepares eeeee aear<br>See= Se ae ree eens ane [ane<br>ii eisai ree [eae [arene Rares [eee [Sere<br>a e pera [Seen [arenes [areseames nll[ere  la[Sere<br>lsa<br>hal nial anal laa la<br>Se<br>SS SS ae R a ae reea e pareneen ane e ae<br><!-- End of picture text -->  
123

---

<!-- METADADOS: doenca: Carcinoma de Células Renais - DDT | secao: **Referências** -->
1. Motzer R, Tykodi S, Escudier B. Final analysis of the CheckMate 025 trial comparing nivolumab (NIVO) versus everolimus (EVE) with >5 years of follow-up in patients with advanced renal cell carcinoma (aRCC). J Clin Oncol. 2020;38(6).  
2. Retz M, Bedke J, Bogemann M. SWITCH II: Phase III randomized, sequential, open-label study to evaluate the efficacy and safety of sorafenib-pazopanib versus pazopanib-sorafenib in the treatment of advanced or metastatic renal cell carcinoma (AUO AN 33/11). Eur J Cancer. 2019;  
3. Motzer RJ, Hutson TE, Glen H, Michaelson MD, Molina A, Eisen T, et al. Lenvatinib, everolimus, and the combination in patients with metastatic renal cell carcinoma: A randomised, phase 2, open-label, multicentre trial. Lancet Oncol. 2015;  
4. Beaumont JL, Butt Z, Baladi J, Motzer RJ, Haas T, Hollaender N, et al. Patient‐Reported Outcomes in a Phase III Study of Everolimus Versus Placebo in Patients with Metastatic Carcinoma of the Kidney That Has Progressed on Vascular Endothelial Growth Factor Receptor Tyrosine Kinase Inhibitor Therapy. Oncologist [Internet]. 2011 May [cited 2021 May 31];16(5):632–40. Available from: https://pubmed.ncbi.nlm.nih.gov/21459902/  
5. Motzer RJ, Barrios CH, Kim TM, Falcon S, Cosgriff T, Harker WG, et al. Phase II randomized trial comparing sequential first-line everolimus and second-line sunitinib versus first-line sunitinib and second-line everolimus in patients with metastatic renal cell carcinoma. J Clin Oncol. 2014;32(25):2765–72. 6. Hutson TE, Escudier B, Esteban E, Bjarnason GA, Lim HY, Pittman KB, et al. Randomized phase III trial of temsirolimus versus sorafenib as second-line therapy after sunitinib in patients with metastatic renal cell carcinoma. J Clin Oncol [Internet]. 2014 Mar 10 [cited 2021 May 31];32(8):760–7. Available from: https://pubmed.ncbi.nlm.nih.gov/24297950/  
7. Escudier B, Szczylik C, Oudard S, Siebels M, Hutson TE, Pharm D, et al. Sorafenib in Advanced Clear-Cell Renal-Cell Carcinoma. 2007;125–34.  
8. Eichelberg C, Vervenne WL, De Santis M, Fischer Von Weikersthal L, Goebell PJ, Lerchenmüller C, et al. SWITCH: A randomised, sequential, open-label study to evaluate the efficacy and safety of sorafenib-sunitinib versus sunitinib-sorafenib in the treatment of metastatic renal cell cancer. Eur Urol. 2015;68(5):837–47.  
9. Powles T, Motzer RJ, Escudier B, Pal S, Kollmannsberger C, Pikiel J, et al. Outcomes based on prior therapy in the phase 3 METEOR trial of cabozantinib versus everolimus in advanced renal cell carcinoma. Br J Cancer. 2018; 10. Motzer RJ, Escudier B, Oudard S, Hutson TE, Porta C, Bracarda S, et al. Phase 3 trial of everolimus for metastatic renal cell carcinoma: Final results and analysis of prognostic factors. Cancer. 2010;116(18):4256–65. 11. Motzer RJ, Escudier B, Tomczak P, Hutson TE, Michaelson MD, Negrier S, et al. Axitinib versus sorafenib as second-line treatment for advanced renal cell carcinoma: Overall survival analysis and updated results from a randomised phase 3 trial. Lancet Oncol [Internet]. 2013;14(6):552–62. Available from: http://dx.doi.org/10.1016/S14702045(13)70093-7  
12. Voss MH, Bhatt RS, Vogelzang NJ, Fishman M, Alter RS, Rini BI, et al. A phase 2, randomized trial evaluating the combination of dalantercept plus axitinib in patients with advanced clear cell renal cell carcinoma. Cancer. 2019;125(14):2400–8.  
124

---

