<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA CONJUNTA Nº 8, DE 26 DE JUNHO DE 2023.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Lipofuscinose Ceroide Neuronal tipo 2.  
O SECRETARIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETARIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE, no uso das atribuições,  
Considerando a necessidade de se estabelecerem os parâmetros sobre a Lipofuscinose Ceroide Neuronal tipo 2 no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença; Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 793/2022 e o Relatório de Recomendação n<sup><u>o</u></sup> 769 – Dezembro de 2022, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a realização de busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Lipofuscinose Ceroide Neuronal tipo 2. Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Lipofuscinose Ceroide Neuronal tipo 2, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-ediretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Lipofuscinose Ceroide Neuronal tipo 2.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme as suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
HELVÉCIO MIRANDA MAGALHÃES JÚNIOR  
CARLOS AUGUSTO GRABOIS GADELHA

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A Lipofuscinose Ceroide Neuronal tipo 2 (CLN2, do inglês _neuronal ceroid lipofuscinosis type 2_ ), conhecida também como deficiência de tripeptidil-peptidase 1 (TPP1), é uma doença genética rara, autossômica recessiva, de depósito lisossômico, causada pela presença de variantes patogênicas no gene _CLN2/TPP1_ , localizado no braço curto do cromossomo 11 (11p15.4)<sup>1,2</sup> . Mutações associadas à CLN2 incluem mutações de _splicing_ , _missense_ , _nonsense_ , pequenas deleções e inserções de nucleotídeo único, todas levando à deficiência da enzima TPP1<sup>3</sup> .  
A atividade deficiente da enzima TPP1 causa o acúmulo intracelular de lipopigmentos autofluorescentes com diversos padrões ultraestruturais em diferentes tecidos, o que leva à perda neuronal, produzindo sintomas que incluem especialmente perda neuronal, crises convulsivas e perda visual progressivas<sup>2</sup> . As crianças afetadas pela forma clássica (infantil tardia) desenvolvem-se normalmente até a idade de dois a quatro anos, com exceção do atraso da linguagem que pode ser frequente, seguido por um início súbito de convulsões e um rápido declínio na função psicomotora, podendo levar ao óbito no início da adolescência<sup>4</sup> .  
As formas atípicas da doença incluem um espectro de variação na idade de início dos sintomas, forma de evolução da doença e multiplicidade de fenótipo, especialmente incluindo outros sinais/sintomas neurológicos<sup>4</sup> . Uma das formas atípicas inclui manifestações parkinsonianas de início mais tardio, com progressão lenta e ausência de crises convulsivas e perda visual<sup>1,4</sup> . Outra forma atípica descrita inclui ataxia proeminente com ausência de crises convulsivas, regressão cognitiva ou perda visual, exibindo deficiência parcial da enzima TPP1, forma conhecida também com ataxia espinocerebelar autossômica recessiva tipo 7 (SCAR7)<sup>1,4</sup> .  
Dados epidemiológicos de prevalência e incidência para CLN2 são pouco descritos na literatura. As estimativas de incidência mundiais variam de 6 a 8 casos por 100.000 nascidos vivos<sup>5</sup> , com diferenças geográficas contabilizando de 0,15 a 9,0 por 100.000 nascidos vivos<sup>6</sup> .  
O acesso limitado aos serviços especializados e ferramentas diagnósticas em certas regiões pode levar a uma complexa jornada e consequente atraso no diagnóstico correto<sup>7,8</sup> . Não existem estudos epidemiológicos nacionais sobre CLN2. Contudo, o Serviço de Genética Médica do Hospital de Clínicas de Porto Alegre (SGM/HCPA), o qual realiza cerca de 90% a 95% dos diagnósticos de CLN2 no Brasil, identificou 25 casos no país, desde 2006. Nesse período, têm sido diagnosticados em média 5 novos casos por ano. Especialistas estimam que em 2022 haja um total de 80 pacientes no Brasil.  
A identificação da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos. Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da CLN2. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 3** .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
- E75.4 Lipofuscinose neuronal ceroide.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
O diagnóstico de CLN2 é realizado com base na suspeita clínica, e confirmado por marcadores bioquímicos e teste genético. A suspeita deve ocorrer em indivíduos que apresentem pelo menos um dos seguintes sinais e sintomas relacionados à doença, com início tipicamente entre os dois e quatro anos de idade<sup>1,9</sup> :  
- atraso na linguagem;  
- crises convulsivas (epilepsia);  
- ataxia de marcha;  
- declínio cognitivo progressivo;  
- perda de função motora;  
- perda visual progressiva;  
- alterações motoras, como mioclonia, espasticidade e distonia.  
A atrofia cerebelar grave é o principal achado presente na ressonância magnética de crânio<sup>10</sup> e a fotossensibilidade detectada pelo eletroencefalograma (EEG) é um marcador precoce de CLN2<sup>11</sup> .  
Fenótipos atípicos podem ter apresentação tardia, com descrição de formas juvenil e adulta com curso mais prolongado da doença<sup>9</sup> . Como os achados clínicos variam de acordo com a gravidade da doença, os sinais e sintomas, por si só, não são diagnósticos.  
A confirmação do diagnóstico de CLN2 envolve exames bioquímicos e genéticos que deverão ser realizados sempre que houver suspeita clínica dessa doença.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A confirmação do diagnóstico de CLN2 envolve métodos bioquímicos e genéticos.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A redução ou ausência de atividade da enzima TPP1 em fibroblastos, leucócitos ou sangue impregnado em papel-filtro sugere fortemente o diagnóstico de CLN2, mas não é suficiente para confirmá-lo, sendo necessária análise genética compatível.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A presença de duas variantes patogênicas, provavelmente patogênicas ou variantes de significado incerto (VUS) bialélicas no gene _TPP1/CLN2_ associada à atividade deficiente da enzima TPP1 confirma o diagnóstico. A análise do gene _TPP1/CLN2_ permite a detecção das variantes que provocam a doença e, consequentemente, o diagnóstico genético e a detecção de heterozigotos, facilitando o aconselhamento genético individual e familiar<sup>1,9</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A maior importância dos estudos de genótipo-fenótipo é a possibilidade de predição aproximada, em idade precoce, da forma da doença que os indivíduos apresentarão. Há dezenas de variantes patogênicas descritas no gene _TPP1/CLN2_ , a maioria sendo considerada privada ou presente em regiões geográficas bem delimitadas, não permitindo ainda uma adequada relação genótipo-fenótipo universal<sup>12</sup> .  
Mutações em _TPP1_ já foram identificadas em pacientes com ataxia, incluindo ataxia espinocerebelar 7 (SCAR7) que tem um início tardio e fenótipo mais restrito sem epilepsia, regressão cognitiva ou anormalidades oftalmológicas<sup>13</sup> . Esses  
fenótipos variam em gravidade, desde CLN2 infantil tardia grave, passando pela forma juvenil, até SCAR7 leve. No entanto, o mecanismo subjacente à variação do fenótipo é desconhecido, havendo evidências de que o nível residual de atividade da enzima TPP1 está associado à gravidade fenotípica<sup>14</sup> .  
Algumas variantes genéticas como c.509-1G>C e p.Arg208* são consideradas mais prevalentes e associadas com fenótipo clássico de CLN2<sup>15</sup> . Já a variante p.Arg447His tem sido identificada em casos com fenótipo mais leve e prolongado<sup>16,17</sup> . Ainda não está claro se a variação do fenótipo está correlacionada com os genótipos das mutações em _TPP1_<sup>18</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Serão incluídos neste PCDT todos os pacientes com diagnóstico de CLN2 confirmado, de acordo com os critérios abaixo, os quais devem ser comprovados por laudo/relatório médico e pela cópia dos exames realizados:  
a) Atividade deficiente da enzima TPP1 (no plasma/leucócitos); **<u>e</u>**  
b) Variantes patogênicas, provavelmente patogênicas ou variantes de significado incerto (VUS) bialélicas identificadas no gene _CLN2_ .  
Adicionalmente, para início da terapia de reposição enzimática (TRE) com alfacerliponase, em qualquer idade, os pacientes devem apresentar escore mínimo ≥ 1 no domínio motor e no domínio linguagem, e soma das pontuações dos domínios motor e linguagem na escala CLN2 ≥ 2 **(Quadro 1)**<sup>19</sup> . Os pacientes que já estiverem em uso de alfacerliponase quando da publicação deste Protocolo deverão ser reavaliados para sua manutenção em terapia mediante cumprimento dos critérios de inclusão do PCDT e avaliação médica.  
A escala CLN2 foi desenvolvida com base na escala de Hamburgo (que avalia adicionalmente os domínios epilepsia e visual) com o objetivo de ser utilizada em ensaios clínicos, podendo ser comparada com coortes históricas de pacientes sem tratamento. Esta escala é composta por dois domínios, que avaliam a função motora e a linguagem (ML). A pontuação em cada domínio varia de 0 a 3, sendo que, quando os domínios são combinados, a pontuação pode variar de 0 a 6. Pontuações mais altas significam uma melhor condição de saúde. De acordo com Schulz et al.<sup>19</sup> , os domínios motor e linguístico seriam os principais para se avaliar a eficácia terapêutica, uma vez que os episódios epilépticos dependem também do tratamento anticonvulsivante simultâneo e porque os efeitos visuais aparecem mais tardiamente na história natural da doença, com um declínio mais inconsistente em comparação com outras funções.  
**Quadro 1 -** Escala CLN2 motor-linguagem (ML).  
|**Escore**|**Domínio motor**|**Domínio linguagem**|
|---|---|---|
|**3**|Marcha amplamente normal.|Linguagem aparentemente normal.|
||Sem<br>ataxia<br>proeminente<br>e<br>nenhuma<br>queda<br>patológica.|Inteligível e amplamente apropriada à idade.<br>Sem declínio observado na linguagem.|
|**2**|Marcha independente, conforme definido pela<br>habilidade de andar sem suporte por 10 passos.<br>Tem instabilidade na caminhada e pode ter quedas<br>intermitentes.|Linguagem<br>torna-se<br>reconhecidamente<br>anormal:<br>algumas palavras inteligíveis, podem formar frases<br>curtas para transmitir conceitos, solicitações ou<br>necessidades.<br>Este resultado significa um declínio de um nível anterior<br>de capacidade (do individual máximo alcançado pela<br>criança anteriormente).|
|**1**|Necessita de ajuda externa para caminhar ou possui|Dificilmente compreensível.|  
|**Escore**|**Domínio motor**|**Domínio linguagem**|
|---|---|---|
||capacidade apenas para  engatinhar.|Poucas palavras inteligíveis.|
|**0**|Já não pode caminhar ou engatinhar.|Sem palavras inteligíveis ou vocalizações.|  
Fonte: Traduzido de Schulz _et al_ ., 2018<sup>19</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Serão excluídos do tratamento com alfacerliponase os pacientes que atenderem aos seguintes critérios:  
- Apresentarem condição médica irreversível adicional que comprometa o benefício em longo prazo da TRE, conforme  
- avaliação médica<sup>20</sup> ;  
- Apresentarem intolerância, hipersensibilidade, contraindicação ou eventos adversos graves relacionados ao  
- medicamento, impossibilitando o tratamento<sup>20</sup> ;  
- Pacientes com derivações ventrículo-peritoneais.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Não há dados disponíveis sobre segurança para a gestante e o feto/bebê quanto ao uso da alfacerliponase durante a gestação e lactação, embora não se espere que enzimas recombinantes cruzem a barreira placentária ou sejam excretadas em quantidade aumentada no leite materno. Preconiza-se que o tratamento com alfacerliponase não seja iniciado durante a gestação<sup>21</sup> . Não foram realizados estudos com alfacerliponase em animais ou seres humanos quanto aos efeitos na fertilidade<sup>21</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
O paciente com CLN2 tem uma doença crônica, progressiva e multissistêmica que, rotineiramente, requer cuidados por equipe multiprofissional, incluindo fonoaudiólogos, fisioterapeutas, terapeutas ocupacionais, equipe de enfermagem, equipe de assistência psicológica e social e diferentes especialidades na área da saúde<sup>8</sup> . O tratamento é estabelecido com base na melhor evidência disponível, uma vez que se trata de doença rara, e inclui intervenções não específicas, realizadas no nível do fenótipo clínico, e específicas, realizadas no nível da proteína mutante, como a TRE<sup>6,8</sup> .  
É crucial que um médico cuide continuamente do paciente, monitorando a evolução da doença, fornecendo orientação à família, encaminhando o paciente para especialistas, conforme necessário, e coordenando o atendimento ao paciente como um todo, idealmente em um centro de referência.  
Como é uma doença genética de padrão autossômico recessivo<sup>1</sup> , com risco de recorrência em 25% dos irmãos do paciente afetado, é fundamental a realização de aconselhamento genético por profissional habilitado. Além disso, é importante que os pacientes e as famílias sejam orientadas sobre sua doença e possíveis complicações e riscos, também por meio de um relatório escrito. Os pacientes podem desenvolver, particularmente, sinais e sintomas neurológicos e oftalmológicos na forma clássica da doença, de modo que neurologistas e oftalmologistas devem fazer parte das equipes de acompanhamento especializado<sup>6,8,22</sup> na maior parte das vezes.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
As principais manifestações clínicas da CLN2 e suas opções de tratamento de suporte e sintomático podem ser encontradas no **Apêndice 1** . É importante frisar que nem todos os pacientes apresentarão todas as manifestações citadas, as quais costumam ser mais frequentes e mais graves nos pacientes com a forma grave (infantil tardia) da doença. Da mesma  
maneira, nem todos os pacientes necessitarão ser submetidos a todos os tipos de tratamento.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
As crises convulsivas são as manifestações mais frequentes nos pacientes com CLN2. Costumam ocorrer a partir dos dois anos de idade e podem ser de difícil controle, por vezes, necessitando o uso de múltiplos medicamentos anticonvulsivantes<sup>6</sup> . Preconiza-se que a cada consulta clínica seja feita a revisão do padrão das crises convulsivas e dos medicamentos utilizados, com ajustes conforme necessário e, preferencialmente, com avaliação neurológica especializada, de acordo com o PCDT de Epilepsia publicado pelo Ministério da Saúde<sup>6,9</sup> .  
A realização de EEG é preconizada no diagnóstico da condição e, após, a cada 6 meses ou conforme o curso da doença individual<sup>9,23</sup> . A ressonância magnética de crânio deve ser realizada no diagnóstico e anualmente, exceto em casos muito avançados da doença<sup>9,10</sup> . Atrofia cerebelar grave é o principal sinal presente na ressonância magnética de crânio<sup>10,24</sup> .  
Desordens do movimento também podem estar presentes na clínica dos pacientes com CLN2. Ataxia é o sinal mais comum, presente nas formas clássica e tardia, embora distonia, coreia e parkinsonismo também sejam descritos<sup>2,25,26</sup> . A reavaliação clínica é preconizada a cada consulta<sup>9</sup> .  
Alterações no padrão do sono são muito frequentes na CLN2, primariamente pela condição ou como consequência do uso dos anticonvulsivantes<sup>27</sup> . Alterações de humor, fadiga, dificuldades de aprendizado e de memória são repercussões comuns associadas ao distúrbio do sono<sup>28</sup> . Avaliação clínica apropriada ou com polissonografia, quando aplicável, deve ser realizada e, se necessário, tratamento medicamentoso poderá ser instituído<sup>9,27</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Crianças com CLN2 apresentam atraso do neurodesenvolvimento ou regressão neurológica, especialmente associadas com as crises convulsivas<sup>2</sup> . Atraso ou regressão na fala pode ser uma das primeiras manifestações cognitivas reconhecidas<sup>4</sup> . Crianças com CLN2 que tenham alterações cognitivas ou comportamentais beneficiam-se de intervenções padrão, como terapia ocupacional e reabilitação cognitiva quando apropriadas<sup>9</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Pacientes com CLN2 frequentemente apresentam dor por diversas causas possíveis (contraturas musculares, origem gastrointestinal, origem urinária por retenção, entre outras)<sup>29</sup> . Aplicação de escalas de dor podem auxiliar na avaliação e na instituição de tratamento apropriado<sup>9,29</sup> . Intervenções medicamentosas podem ser utilizadas, de acordo com o tipo e intensidade da dor, além de medidas não medicamentosas, como calor e acompanhamento fisioterápico<sup>8,30</sup> , e o tratamento é preconizado conforme PCDT da Dor Crônica publicado pelo Ministério da Saúde<sup>31</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
As manifestações oftalmológicas da CLN2 costumam aparecer a partir dos quatro anos de idade, com declínio visual progressivo podendo levar à perda visual completa secundária à degeneração retiniana<sup>32</sup> . Avaliação com oftalmologista para análise de acuidade visual, câmara anterior e fundo de olho deve ser realizada, assim como exames oftálmicos específicos, conforme necessidade<sup>32,33</sup> . Lentes corretivas para corrigir erros de refração e demais tratamentos podem ser prescritos, conforme análise e indicação especializada<sup>9,32</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
As manifestações respiratórias na CLN2 podem surgir tardiamente, em estágios avançados da doença<sup>2,4</sup> . Medidas de suporte básicas, como mobilização do paciente e higiene pulmonar auxiliam no controle dos sintomas. Alguns medicamentos,  
assim como fisoterapia respiratória, poderão ser necessários, conforme avaliação clínica<sup>6,8</sup> . Imunizações regulares para doenças respiratórias preveníveis são preconizadas para o paciente e seus contatos domiciliares<sup>8,34</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Achados cardíacos são pouco frequentes na CLN2, mas pode haver depósito de lipopigmentos no tecido muscular cardíaco, o que explica determinadas manifestações presentes no eletrocardiograma e no ecocardiograma de alguns pacientes<sup>35,36</sup> . Esses exames são preconizados no diagnóstico e, posteriormente, a cada 2 anos, se não houver complicações detectadas. Avaliação e acompanhamento com cardiologista são preconizados se houver achados anormais nos exames específicos<sup>9</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Dificuldades de deglutição são comuns na CLN2 e os profissionais envolvidos nos cuidados desses pacientes devem estar atentos a elas. Assim, devem ser garantidas a consistência apropriada da alimentação e a orientação aos cuidadores sobre sinais de disfunção orofaríngea<sup>6,8</sup> .  
Intervenções medicamentosas e não medicamentosas podem ser recomendadas para o tratamento das secreções orais, se necessário<sup>6,7</sup> . Quando o risco de aspiração for alto, pneumonias de aspiração forem recorrentes ou aspiração silente já for detectada em videodeglutograma, a realização de gastrostomia deve ser considerada<sup>6</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A alfacerliponase é uma forma recombinante da enzima TPP1 produzida em células de ovário de hamster chinês e o único medicamento disponível no mundo para o tratamento específico da CLN2<sup>20</sup> .  
As principais evidências clínicas para seu uso são oriundas de três estudos (190-201, 190-202 e 190-901)<sup>20</sup> . O estudo 190-201 foi um estudo aberto de braço único, incluindo 23 crianças de 3 a 16 anos com CLN2 infantil tardia tratadas com alfacerliponase. Os pacientes deveriam ter escore entre 3 e 6 na escala CLN2-ML e escore de pelo menos 1 em cada um dos dois domínios desta escala no momento do _screening_ para participação no estudo. Os pacientes foram incluídos nos EUA, Alemanha, Itália e Reino Unido e o seguimento foi de 48 semanas. Após a sua conclusão, os pacientes foram incluídos em um estudo de extensão (190-202) para acompanhamento de longo prazo. Todos os pacientes que completaram o primeiro estudo fizeram a transição para o segundo, com coleta de dados por até 240 semanas. Houve diferença estatística entre o grupo que recebeu alfacerliponase e o grupo controle histórico em relação ao tempo até declínio irreversível de dois pontos na escala CLN2-ML quando os domínios motor e linguagem foram avaliados de forma combinada (HR 0,08; IC95% 0,02 a 0,23, p<0,001). Diferença estatística também foi observada quando os domínios foram avaliados separadamente (HR 0,04; IC95% 0,00 a 0,29, p=0,002 para o domínio motor e HR 0,15; IC95% 0,04 a 0,52, p=0,003 para o domínio linguagem). Já o estudo 190-901, de história natural da doença, avaliou, retrospectivamente, a progressão da doença em pacientes com CLN2 não tratada<sup>20,37</sup> . Neste estudo, o tratamento com alfacerliponase intracerebroventricular resultou em declínio mais lento das funções motoras e de linguagem, em comparação com controles de história natural da doença<sup>21</sup> .  
Por ser a população incluída nos ensaios clínicos que forneceram a evidência de eficácia e segurança do medicamento, este Protocolo preconiza que a TRE com alfacerliponase deve ser iniciada, em qualquer idade, por aqueles pacientes com escore mínimo ≥ 1 no domínio motor e no domínio linguagem, e soma das pontuações dos domínios motor e linguagem na escala CLN2 ≥ 2 **(Quadro 1)**<sup>19</sup> .  A Figura 1 apresenta o fluxograma de diagnóstico e tratamento medicamentoso da CLN2.  
**Figura 1** _–_ Fluxograma para o diagnóstico e tratamento da CLN2. TRE= terapia de reposição enzimática.  
<!-- Start of picture text -->
Suspeita diagnóstica a partir de sinais e sintomas de CLN2<br>Atividade deficiente da enzima tripeptidil peptidase 1 (TPP1)<br>(no plasma/leucócitos/fibroblastos)<br>Variantes patogênicas, provavelmente patogênicas ou de<br>significado incerto (VUS) bialélicas identificadas no gene<br>Sim  Algum critério  Não<br>de exclusão<br>para TRE?<br>Tratamento de Suporte  Iniciar TRE com alfacerliponase<br>Diagnóstico<br>Tratamento<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
- Alfacerliponase: solução para perfusão contendo 30 mg/mL.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A dose preconizada é de 300 mg de alfacerliponase administrada a cada duas semanas, por via intracerebroventricular. No entanto, crianças menores de 2 anos devem utilizar as doses descritas no **Quadro 2** .  
**Quadro 2** - Doses preconizadas em crianças até 2 anos de idade.  
|**Faixas etárias**|**Dose total administrada a cada 2**<br>**semanas (mg)**|**Volume da solução de Alfacerliponase**<br>**(mL)**|
|---|---|---|
|**Nascimento até < 6 meses**|100|3,3|
|**6 meses até < 1 ano**|150|5|
|**1 ano até < 2 anos**|200 (primeiras 4 doses)<br>300 (doses subsequentes)|6,7 (primeiras 4 doses)<br>10 (doses subsequentes)|
|**2 anos ou mais**|300|10|  
Fonte: BIOMARIM, 2022<sup>21</sup> .  
A velocidade da infusão e da solução de lavagem é de 2,5 mL/hora e a duração completa da infusão é de aproximadamente 2 a 4,5 horas, dependendo da dose e do volume administrados, devendo ser feita em ambiente hospitalar ou ambulatorial. É preconizado pré-tratamento dos pacientes com anti-histamínicos, com ou sem antipiréticos, 30 a 60 minutos antes da infusão. Os sinais vitais devem ser monitorados antes do início da infusão e, periodicamente, durante e após a infusão por pelo menos uma hora<sup>21</sup> .  
O medicamento alfacerliponase é administrado no líquido cefalorraquidiano (LCR) por perfusão por meio de um reservatório e um cateter implantados cirurgicamente (dispositivo de acesso intracerebroventricular). Esse dispositivo deve ser  
implantado antes da primeira perfusão e deve ser adequado para aceder aos ventrículos cerebrais, com vista à administração terapêutica<sup>21</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Além dos cuidados e precauções com relação à administração do medicamento, os seguintes eventos adversos da  
alfacerliponase<sup>21,37</sup> devem ser monitorados e prevenidos:  
- Infecções por meio do dispositivo intracerebroventricular: observar técnica asséptica de manipulação e administração  
da enzima;  
- Extravasamento e falha do dispositivo: inspeção do local e revisão do dispositivo a cada aplicação;  
- As amostras do líquido cefalorraquidiano (LCR) devem ser rotineiramente enviadas para análise para detectar  
- infecções subclínicas por meio do dispositivo;  
- Observação clínica para sinais de reações anafiláticas durante a infusão.  
Imunogenicidade: tal como acontece com todas as proteínas terapêuticas, existe potencial para imunogenicidade. No entanto, não foram detectados no LCR anticorpos neutralizantes (NAb) com especificidade para o medicamento capazes de inibir a captação celular de alfacerliponase mediada por receptores<sup>21</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Os critérios de interrupção do tratamento devem ser apresentados, de forma clara, ao paciente ou aos pais/responsáveis quando o tratamento com alfacerliponase estiver sendo considerado e antes de iniciá-lo. Durante o acompanhamento do paciente, os parâmetros de resposta terapêutica deverão ser avaliados periodicamente e discutidos com a família. No caso de interrupção por falta de adesão, o paciente e parentes deverão ser inseridos em programa de incentivo à adesão. O paciente poderá retornar ao tratamento, caso haja comprometimento explícito de seguimento das recomendações médicas. O tempo de tratamento não pode ser pré-determinado, devendo ser mantido pelo tempo indicado e enquanto o paciente se beneficie de seu uso.  
O tratamento deve ser interrompido nas seguintes situações<sup>20,38</sup> :  
- presença de condição médica irreversível adicional que comprometa o benefício a longo prazo da terapia;  
- pacientes não tolerantes à infusão ou que apresentem eventos adversos graves relacionados ao medicamento,  
- impossibilitando a retomada do tratamento;  
- reação anafilática com ameaça à vida causada pelo princípio ativo ou por qualquer um dos excipientes, se a nova  
- administração não for bem-sucedida;  
 presença de sinais de extravasamento agudo do dispositivo de acesso intracerebroventricular, falha do dispositivo ou infecção relacionada ao dispositivo;  
 redução de ≥ 2 pontos na soma dos escores dos domínios motor e linguagem da escala CLN2 ( **Quadro 1** ) persistente  
por duas avaliações consecutivas (realizadas a cada 24 semanas)<sup>38</sup> ;  
- soma dos escores dos domínios motor e linguagem da escala CLN2 atinge o valor de zero ( **Quadro 1** ) em duas  
- avaliações consecutivas (realizadas a cada 24 semanas)<sup>8</sup> .

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Os pacientes devem ter a resposta terapêutica e os eventos adversos monitorados. O médico deve realizar anamnese e exame físico completos em cada consulta. Nas consultas, dados sobre todas as avaliações realizadas desde o atendimento anterior devem ser obtidos e os testes necessários devem ser solicitados, incluindo avaliação por especialistas em neurologia,  
oftalmologia, cardiologia e pneumologia, conforme indicação clínica e a critério do médico assistente. As avaliações de rotina devem ser realizadas a cada 24 semanas pelo médico assistente com vacinas, orientação nutricional, exames e aconselhamento preventivo. Os pacientes e seus familiares devem ter acesso ao aconselhamento genético<sup>9,20,38</sup> .  
Como parte da avaliação do tratamento, deve-se monitorar o uso, a adesão, a indicação e os resultados do tratamento com alfacerliponase. Por meio desse monitoramento, será possível estabelecer grupos de pacientes que são de fato beneficiados e reavaliar a incorporação do medicamento a médio prazo.  
Não há interações conhecidas com alfacerliponase e outros medicamentos. O paciente deve informar a equipe de saúde se estiver fazendo uso, tiver usado recentemente, ou se puder vir a usar outros medicamentos.  
O **Apêndice 2** apresenta as avaliações consideradas mínimas para o acompanhamento de pacientes com CLN2, sendo necessárias para o acesso ao medicamento. São definidos períodos mínimos apenas para aquelas avaliações que têm por objetivo detectar a eficácia e segurança da TRE. Para as demais, a periodicidade de avaliações fica a critério do médico assistente.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Observando os cuidados de armazenamento do medicamento, conforme consta em bula, a alfacerliponase deve ser distribuída diretamente aos centros de referência definidos para administração do medicamento. Os frascos do medicamento e a solução de lavagem devem ser armazenados em posição vertical em um congelador na temperatura entre <mark>-25°C e -15°C.</mark>  
Pacientes com suspeita de CLN2 devem ser encaminhados, preferencialmente, a um serviço especializado ou de referência em doenças raras para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento. Pacientes com CLN2 devem ser avaliados periodicamente em relação à eficácia do tratamento e desenvolvimento de toxicidade aguda ou crônica. A existência de centro de referência facilita o tratamento em si, bem como o ajuste de doses conforme necessário e o controle de eventos adversos. A alfacerliponase é uma enzima indicada para uso intracerebroventricular e deve ser administrada por médico experiente (pediatra, neurologista ou geneticista), utilizando técnicas seguras e assépticas durante a sua preparação e administração.  
Cabe destacar que, sempre que possível, o atendimento da pessoa com CLN2 deve ocorrer por equipe multiprofissional, possibilitando o desenvolvimento de Projeto Terapêutico Singular (PTS) e a adoção de terapias de apoio conforme sua necessidade funcional e as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde (SUS).  
Deve-se verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo. Estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação dos medicamentos e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Em 2014, o Ministério da Saúde instituiu a Política Nacional de Atenção Integral às Pessoas com Doenças Raras e aprovou as Diretrizes para Atenção Integral às Pessoas com doenças raras no âmbito do Sistema Único de Saúde (SUS) por meio da Portaria GM/MS nº 199, de 30 de janeiro de 2014 (consolidada no Anexo XXXVIII da Portaria de Consolidação GM/MS nº 2/2017 e na Seção XIV do Capítulo II do Título III da Portaria de Consolidação GM/MS nº 6/2017), relativas à Política Nacional de Atenção Integral às Pessoas com Doenças Raras.  
A política tem abrangência transversal na Rede de Atenção à Saúde (RAS) e como objetivo reduzir a mortalidade, contribuir para a redução da morbimortalidade e das manifestações secundárias e a melhoria da qualidade de vida das pessoas, por meio de ações de promoção, prevenção, detecção precoce, tratamento oportuno redução de incapacidade e cuidados  
paliativos. A linha de cuidado da atenção aos usuários com demanda para a realização das ações na Política Nacional de Atenção Integral às Pessoas com Doenças Raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde (RAS) e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no SUS. A Atenção Primária é responsável pela coordenação do cuidado e por realizar a atenção contínua da população que está sob sua responsabilidade adstrita, além de ser a porta de entrada prioritária do usuário na RAS. Já a Atenção Especializada é responsável pelo conjunto de pontos de atenção com diferentes densidades tecnológicas para a realização de ações e serviços de urgência, ambulatorial especializado e hospitalar, apoiando e complementando os serviços da atenção básica.  
Os hospitais universitários, federais e estaduais, em torno de 50 em todo o Brasil, e as associações beneficentes e voluntárias são o _locus_ da atenção à saúde dos pacientes com doenças raras.  
Porém, para reforçar o atendimento clínico e laboratorial, o Ministério da Saúde incentiva a criação de serviços da Atenção Especializada, assim classificados:  
- Serviço de atenção especializada em doenças raras: presta serviço de saúde para uma ou mais doenças raras; e  
- Serviço de referência em doenças raras: presta serviço de saúde para pacientes com doenças raras pertencentes a, no  
- mínimo, dois eixos assistenciais (doenças raras de origem genética e de origem não genética).  
No que diz respeito ao financiamento desses serviços, para além do ressarcimento pelos diversos atendimentos diagnósticos e terapêuticos clínicos e cirúrgicos e a assistência farmacêutica, o Ministério da Saúde instituiu incentivo financeiro de custeio mensal para os serviços de atenção especializada em doenças raras.  
Assim, o atendimento de pacientes com doenças raras é feito prioritariamente na Atenção Primária, principal porta de entrada para o SUS, e se houver necessidade o paciente será encaminhado para atendimento especializado em unidade de média ou alta complexidade, e a linha de cuidados de pacientes com doenças raras é estruturada pela Atenção Primária e Atenção Especializada, em conformidade com a Rede de Atenção à Saúde e seguindo as Diretrizes para Atenção Integral às Pessoas com Doenças Raras no Sistema Único de Saúde.  
Considerando que cerca de 80% das doenças raras são de origem genética, o aconselhamento genético (AG) é fundamental na atenção às famílias e pacientes com essas doenças. O aconselhamento genético é um processo de comunicação que lida com os problemas humanos associados à ocorrência ou ao risco de ocorrência de uma doença genética em uma família. Este processo envolve a participação de pessoas adequadamente capacitadas, com o objetivo de ajudar o indivíduo e a família a compreender os aspectos envolvidos, incluindo o diagnóstico, o curso provável da doença e os cuidados disponíveis.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
**Quadro 3:** Códigos e procedimentos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.  
|**Código**|**Procedimento**|
|---|---|
|02.02.10.011-1|Identificação de mutação por sequenciamento por amplicon até 500 pares de bases|
|02.02.10.019-7|Ensaios enzimáticos em tecido cultivado para diagnóstico de erros inatos do metabolismo|
|03.01.01.021-8|Avaliação clínica de diagnóstico de doenças raras – eixo I: 3 – erros inato de metabolismo|
|04.03.08.003-7|Implante intraventricular de bomba de infusão de fármacos|  
**10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)**  
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
1. Online Mendelian Inheritance in Man, OMIM®. Johns Hopkins University, Baltimore, MD. MIM Number:  
{204500}: {05/30/2018}: World Wide Web URL: https://omim.org/entry/204500  
2. Mole, S. E., Williams, R. E., Goebel, H. H. Correlations between genotype, ultrastructural morphology and clinical  
phenotype in the neuronal ceroid lipofuscinoses. Neurogenetics 6: 107-126, 2005.  
3. Kohlschutter A, Schulz A. CLN2 disease (classic late infantile neuronal ceroid lipofuscinosis). Pediatr Endocrinol  
Rev. 2016;13(Suppl 1):682–8.  
4. Nickel M, Simonati A, Jacoby D, et al. Disease characteristics and progression in patients with late-infantile  
neuronal ceroid lipofuscinosis type 2 (CLN2) disease: an observational cohort study. Lancet Child Adolesc Health. 2018;2:582-590.  
5. Sleat DE, Gedvilaite E, Zhang Y, Lobel P, Xing J. Analysis of large-scale whole exome sequencing data to  
determine the prevalence of genetically-distinct forms of neuronal ceroid lipofuscinosis. Gene. 2016;593(2):284–91.  
6. Williams RE, Adams HR, Blohm M, et al. Management strategies for CLN2 disease. Pediatr Neurol.  
2017;69:102e112.  
7. Fietz M, AlSayed M, Burke D, Cohen-Pfefer J, Cooper JD, Dvorakova L, et al. Diagnosis of neuronal ceroid lipofuscinosis type 2 (CLN2 disease): expert recommendations for early detection and laboratory diagnosis. Mol Genet Metab. 2016;119(1–2):160–7.  
8. Mole SE, Schulz A, Badoe E, Berkovic SF, de Los Reyes EC, Dulz S, et al. Guidelines on the diagnosis, clinical  
assessments, treatment and management for CLN2 disease patients. Orphanet J Rare Dis. 2021 Apr 21;16(1):185.  
9. Guelbert N, Atanacio N, Denzler I, Embiruçu KE, Mancilla N, Naranjo R, et al. Position of Experts Regarding Follow-Up of Patients with Neuronal Ceroid Lipofuscinosis-2 Disease in Latin America.  Journal of Inborn Errors of Metabolism & Screening 2020, Volume 8: e20200012.  
10. Williams RE, Aberg L, Autti T, Goebel HH, Kohlschütter A, Lönnqvist T. Diagnosis of the neuronal ceroid  
lipofuscinoses: An update. Biochimica et Biophysica Acta, 2006; 1762(10), 865–872.  
11. Specchio N, Bellusci M, Pietrafusa N, Trivisano M, de Palma L, Vigevano F. Photosensitivity is an early marker of  
neuronal ceroid lipofuscinosis type 2 disease. Epilepsia, 2017; 58(8), 1380–1388.  
12. Gardner E, Bailey M, Schulz A, Aristorena M, Miller N, Mole SE. Mutation update: Review of TPP1 gene variants  
associated with neuronal ceroid lipofuscinosis CLN2 disease. Hum Mutat. 2019 Nov;40(11):1924-1938.  
13. Sun Y, Almomani R, Breedveld G.J, Santen GW, Aten E, Lefeber DJ, et al. Autosomal recessive spinocerebellar ataxia 7 (SCAR7) is caused by variants in TPP1, the gene involved in classic late-infantile neuronal ceroid lipofuscinosis 2 disease (CLN2 disease). Hum Mutat. 2013; 34: 706-713.  
14. Sleat DE, El-Banna M, Sohar I, Kim K, Dobrenis K, et al. Residual levels of tripeptidyl-peptidase I activity  
dramatically ameliorate disease in late-infantile neuronal ceroid lipofuscinosis. Mol Genet Metab. 2008; 94: 222-233.  
15. Hou J, van Leeuwen J, Andrews BJ, Boone C. Genetic network complexity shapes background-dependent  
phenotypic expression.Trends Genet. 2018; 34: 578-586.  
16. Di Giacopo R, Cianetti L, Caputo V, La Torraca I, et al. Protracted late infantile ceroid lipofuscinosis due to TPP1 mutations: Clinical, molecular and biochemical characterization in three sibs.J Neurol Sci. 2015; 356: 65-71.  
17. Kohan R, Carabelos MN, Xin W, Sims K, Guelbert N, Cismondi I.A. et al. Neuronal ceroid lipofuscinosis type CLN2: a new rationale for the construction of phenotypic subgroups based on a survey of 25 cases in South America.Gene. 2013; 516: 114-121.  
18. Chen ZR, Liu DT, Meng H, Liu L, Bian WJ, Liu XR, Zhu WW, He Y, Wang J, Tang B, Su T, Yi YH. Homozygous  
missense TPP1 mutation associated with mild late infantile neuronal ceroid lipofuscinosis and the genotype-phenotype correlation. Seizure. 2019 Jul;69:180-185.  
19. Schulz A, Ajayi T, Specchio N, Reyes E de L, Gissen P, Ballon D, et al. Study of Intraventricular Cerliponase Alfa  
for CLN2 Disease. N Engl J Med. 2018;378(20):1898–907.  
20. NICE. Cerliponase alfa for treating neuronal ceroid lipofuscinosis type 2. 2019.  
https://www.nice.org.uk/guidance/hst12.  
21. ANVISA. Bula do medicamento BRINEURA® alfacerliponase - solução para infusão 30 mg/mL. BioMarin Brasil  
Farmacêutica Ltda.  
22. Boustany RM. Neurology of the neuronal ceroid-lipofuscinoses: late infantile and juvenile types. Am J Med Genet.  
1992;42(4):533–5.  
23. Beltrán L, reyes valenzuela G, Loos M, Vargas R, Spinzanti P, Lizama R, Caraballo R. Late-onset childhood  
neuronal ceroid lipofuscinosis: Early clinical and electroencephalographic markers. Epilepsy Res. 2018;144:49-52.  
24. Dyke JP, Sondhi D, Voss HU, Yohay K, Hollmann C, Mancenido D, et al. Brain region-specific degeneration with  
disease progression in late infantile neuronal ceroid lipofuscinosis (CLN2 Disease). Am J Neuroradiol. 2016;37(6):1160–1169.  
25. Chang M, Cooper JD, Davidson BL, van Diggelen OP, Elleder M, Goebel HH, et al. CLN2. In: Mole S, Williams R,  
and Goebel H eds. 2nd ed. The Neuronal Ceroid Lipofuscinoses (Batten Disease). Oxford University Press; 2011: 80–109.  
26. Schulz A, Kohlschütter A, Mink J, Simonati A, Williams R. NCL diseases - clinical perspectives. Biochim Biophys  
Acta. 2013;1832(11):1801–1806.  
27. Lehwald LM, Pappa R, Steward S, De Los Reyes E. Neuronal Ceroid Lipofuscinosis and Associated Sleep  
Abnormalities. Pediatr Neurol. 2016;59:30–35.  
28. Owens J, Au R, Carskadon M, Millman R, Wolfson A, Braverman PK, et al. Insufficient sleep in adolescents and  
young adults: An update on causes and consequences. Pediatrics. 2014;134(3):e921–e932.  
29. Barney CC, Hoch J, Byiers B, Dimian A, Symons FJ. A case- controlled investigation of pain experience and  
sensory function in neuronal ceroid lipofuscinosis. Clin J Pain. 2015;31(11):998–1003.  
30. Breau LM, Burkitt C. Assessing pain in children with intellectual disabilities. Pain Res Manag. 2009 Mar-  
Apr;14(2):116-20.  
31. Ministério da Saúde. Portaria no 1083, de 02 de outubro de 2012. Protocolo Clínico e Diretrizes Terapêuticas da Dor  
Crônica. Diário Oficial da União 2012; 02 out.  
32. Orlin A, Sondhi D, Witmer MT, Wessel MM, Mezey JG, Kaminsky SM, et al. Spectrum of Ocular Manifestations  
in CLN2-Associated Batten (Jansky-Bielschowsky) Disease Correlate with Advancing Age and Deteriorating Neurological Function. PLoS One. 2013;8(8): e73128.  
33. Quagliato EMAB, Rocha DM, Sacai PY, Watanabe SS, Salomão SR, Berezovsky A. Retinal function in patients  
with the neuronal ceroid lipofuscinosis phenotype. Arq Bras Oftalmol. 2017;80(4):215–219.  
34. Mortensen A, Raebel EM, Wiseman S. Impact of the COVID-19 pandemic on access to the cerliponase alfa  
managed access agreement in England for CLN2 treatment. Orphanet J Rare Dis. 2022 Jan 19;17(1):19.  
35. Østergaard JR, Rasmussen TB, Mølgaard H. Cardiac involvement in juvenile neuronal ceroid lipofuscinosis (Batten  
disease). Neurology. 2011;76(14):1245–51.  
36. Hofman IL, van der Wal AC, Dingemans KP, Becker AE. Cardiac pathology in neuronal ceroid lipofuscinosesa  
clinicopathologic correlation in three patients. Eur J Paediatr Neurol. 2001;5(Suppl A):213–217.  
37. Lewis G, Morrill AM, Conway-Allen SL, Kim B. Review of Cerliponase Alfa: Recombinant Human Enzyme Replacement Therapy for Late-Infantile Neuronal Ceroid Lipofuscinosis Type 2. J Child Neurol. 2020 Apr;35(5):348-353.  
38. Canadian Drug Expert Committee Recommendation: Cerliponase Alfa (Brineura — Biomarin Pharmaceutical [Canada] Inc.): Indication: For the treatment of neuronal ceroid lipofuscinosis type 2 (CLN2) disease, also known as tripeptidyl peptidase 1 (TPP1) deficiency [Internet]. Ottawa (ON): Canadian Agency for Drugs and Technologies in Health; 2019 May. Available from: https://www.ncbi.nlm.nih.gov/books/NBK543392/  
ALFACERLIPONASE

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Eu,________________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de alfacerliponase, indicada para o tratamento da lipofuscinose ceroide neuronal tipo 2 (CLN2).  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo(a) médico(a)  
(nome do(a) médico(a) que prescreve).  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora dos sintomas da doença;  
- melhora na escala motor e de linguagem.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- medicamento alfacerliponase: medicamento classificado na gestação como categoria C. Não há dados sobre o seu uso  
- em gestantes, não sendo preconizado seu uso;  
 os eventos adversos mais comuns do medicamento alfacerliponase são: convulsões, dores de cabeça, hipersensibilidade, queda de pressão, hematoma, infecções respiratórias, irritabilidade, febre, vômito, aftas na língua e boca, diminuição dos batimentos cardíacos, conjuntivite, dor, dor abdominal, erupção cutânea, reação anafilática, sentir-se nervoso, síndrome da cabeça caída, urticária;  
 a administração desse medicamento necessita a implantação de um dispositivo intracerebroventricular permanente que pode causar infecções e extravasamento do medicamento; deve ser administrada por médico, experiente (pediatra, neurologista ou geneticista), utilizando técnicas seguras e assépticas durante a sua preparação e administração.  
- as amostras do líquido cefalorraquidiano (LCR) devem ser rotineiramente enviadas para análise para detectar  
- infecções do dispositivo;  
 consultas e exames durante o tratamento são necessários;  
 todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
(    ) Sim  (    ) Não  
Meu tratamento constará do seguinte medicamento:  
(    ) Alfacerliponase  
|Local:                                                             Data:|||
|---|---|---|
|Nome do paciente:|||
|Cartão Nacional de Saúde:|||
|Nome do responsável legal:|||
|Documento de identificação do responsável legal:|||
|_____________________________________<br>Assinatura do paciente ou do responsável legal|||
|Médico responsável:|CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico|||
|Data:____________________|||  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica no SUS se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
|**Órgão/sistema**|**Manifestação clínica**|**Avaliação/tratamento**|
|---|---|---|
||Crises convulsivas|Neurologista / anticonvulsivantes|
||Manifestações motoras (ataxia, distonia,<br>coreia, parkinsonismo)|Neurologista, fisioterapia|
|Sistema nervoso central|Distúrbios do sono|Neurologista, pneumologista|
||Déficit cognitivo|Neurologista, educador especializado|
||Dor|Anticonvulsivantes,<br>benzodiazepínicos,<br>fisioterapia, medidas não medicamentosas|
|Olhos|Acuidade visual diminuída<br>Perda visual completa|Avaliação oftalmológica|
||Infecções de repetição, hipersecreção|Avaliação funcional pulmonar|
|Vias aéreas||Tratamento medicamentoso<br>Fisioterapia<br>Imunizações|
|Cardiovascular|Depósito muscular cardíaco|Avaliação cardiológica|
|Gastrointestinal|Distúrbio da deglutição|Orientação nutricional|  
Fonte: Elaborado a partir de Mole et al., 2021<sup>1</sup> ; Guelbert et al., 2020<sup>2</sup>

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
1.Mole SE, Schulz A, Badoe E, Berkovic SF, de Los Reyes EC, Dulz S, et al. Guidelines on the diagnosis, clinical assessments, treatment and management for CLN2 disease patients. Orphanet J Rare Dis. 2021 Apr 21;16(1):185.  
2.Guelbert N, Atanacio N, Denzler I, Embiruçu KE, Mancilla N, Naranjo R, et al. Position of Experts Regarding Follow-Up of Patients with Neuronal Ceroid Lipofuscinosis-2 Disease in Latin America.  Journal of Inborn Errors of Metabolism & Screening 2020, Volume 8: e20200012.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
PROGRAMA MÍNIMO DE AVALIAÇÕES PARA SEGUIMENTO CLÍNICO DOS PACIENTES COM CLN2 TRATADOS OU NÃO COM TERAPIA DE REPOSIÇÃO ENZIMÁTICA  
|Avaliações|Avaliação|A cada 6|<br>A cada 12|<br>A cada|
|---|---|---|---|---|
||inicial|meses|meses|24 meses|
|Atividade enzimática|X||||
|Análise genética específica|X||||
|História médica|X|X|||
|Aconselhamento genético|X||||
|Revisão do número de infusões realizadas no período||X|||
|Determinação da adesão ao acompanhamento/tratamento||X|||
|Avaliação nutricional|X|X|||
|AVALIAÇÃO NEUROLÓGICA|||||
|- Exame neurológico|X||||
|- Eletroencefalograma|X|X|||
|- Ressonância magnética de crânio|X||X||
|AVALIAÇÃO OFTALMOLÓGICA|X|X|||
|AVALIAÇÃO CARDIOLÓGICA|X|X|||
|- Eletrocardiograma|X|||X|
|- Ecocardiograma|X|||X|  
Fonte: Elaborado a partir de Mole et al., 2021<sup>1</sup> ; Guelbert et al., 2020<sup>2</sup>

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
1.Mole SE, Schulz A, Badoe E, Berkovic SF, de Los Reyes EC, Dulz S, et al. Guidelines on the diagnosis, clinical assessments, treatment and management for CLN2 disease patients. Orphanet J Rare Dis. 2021 Apr 21;16(1):185.  
2.Guelbert N, Atanacio N, Denzler I, Embiruçu KE, Mancilla N, Naranjo R, et al. Position of Experts Regarding Follow-Up of Patients with Neuronal Ceroid Lipofuscinosis-2 Disease in Latin America.  Journal of Inborn Errors of Metabolism & Screening 2020, Volume 8: e20200012.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
O presente apêndice consiste no documento de trabalho do grupo elaborador do PCDT de CLN2 contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do Protocolo, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS). O painel de especialistas incluiu médicos da especialidade de genética, neurologia, medicina interna e pneumologia.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração deste Protocolo foi conduzida em caráter emergencial em virtude da incorporação da alfacerliponase para o tratamento dos pacientes com CLN2. Foi realizada uma reunião de escopo, em junho/2022, com representantes do Ministério da Saúde, associação de pacientes e com o Grupo Elaborador deste PCDT que incluiu, além de farmacêuticos, dois especialistas geneticistas.  
Esse Protocolo considera as melhores evidências advindas de diretrizes clínicas já publicadas por outros órgãos ou entidades nacionais e internacionais para o diagnóstico, tratamento e monitorização desses pacientes.  
**2. Equipe de elaboração e partes interessadas**

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
O Protocolo foi elaborado pelo NATS Nuclimed/HCPA.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesse, utilizando a  
Declaração de Potenciais Conflitos de Interesse ( **Quadro A** ).  
**Quadro A -** Questionário de conflitos de interesse diretrizes clínico-assistenciais.  
1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente algum dos benefícios abaixo?  
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|---|---|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim<br>(   ) Não|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|  
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|---|---|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de|(   ) Sim|
|alguma tecnologia ligada ao tema da diretriz?|(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser<br>atividade na elaboração ou revisão da diretriz?|afetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever<br>e que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A proposta de elaboração do PCDT de Lipofuscinose Ceroide Neuronal tipo 2, foi apresentada na 103ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 23 de setembro de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada à Saúde (SAES), Secretaria de Atenção Primária à Saúde (SAPS) e Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação da Conitec e a proposta foi apresentada aos membros do Plenário da Conitec em sua 113ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
A Consulta Pública nº 72/2022, referente à elaboração do Protocolo Clínico e Diretrizes Terapêuticas de Lipofuscinose Ceroide Neuronal tipo 2, foi realizada entre os dias 01/11/2022 e 21/11/2022. Foram recebidas 697 contribuições, que podem ser verificadas em:  
https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2022/20221122_cp_conitec_072_2022_pcdt-lipofuscinoseceroide-neuronal-tipo-2.pdf

---

<!-- METADADOS: doenca: Lipofuscinose Ceroide Neuronal tipo 2 | secao: MINISTÉRIO DA SAÚDE -->
Foram consultados a Relação Nacional de Medicamentos Essenciais (RENAME) e o sítio eletrônico da Conitec para a identificação das tecnologias disponíveis no Brasil e tecnologias demandadas ou recentemente incorporadas para o tratamento da CLN2. Não foram encontradas tecnologias disponíveis já incorporadas para o tratamento da CLN2, além da alfacerliponase.  
Foi também realizada, em 01 de junho de 2022, busca por diretrizes clínicas nacionais e internacionais e recomendações de especialistas a respeito da doença. Foram utilizados os termos “neuronal ceroid lipofuscinosis type 2” OR “NCL2” AND “alfacerliponase” OR “treatment” e restringindo-se para estudos em humanos, nos idiomas português, espanhol e inglês, sem limite de data. As seguintes bases de dados e websites institucionais que abrigam protocolos e diretrizes foram consultados:  
- NICE guidelines (http://www.nice.org.uk/guidance/published?type=CG);  
- Diretrizes da Associação Médica Brasileira (AMB);  
- Protocolos Clínicos e Diretrizes terapêuticas do Ministério da Saúde; e  
- PubMed/MEDLINE.  
Para as recomendações sobre o tratamento, diagnóstico e monitoramento, foram utilizadas as evidências do Relatório de Recomendação nº 706, de abril de 2022, aprovado pela Conitec, o qual motivou a incorporação do medicamento, conforme a Portaria SCTIE/MS n° 39 de 20 de abril de 2022. Adicionalmente, foram consultadas a bula do medicamento aprovada pela ANVISA, diretrizes internacionais, recomendações e consensos de especialistas e avaliações de outras agências de Avaliação de Tecnologias em Saúde, como agência Canadense (CADTH) e NICE.

---

