<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE  
PORTARIA CONJUNTA Nº 10, DE 18 DE JULHO DE 2023.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Hipertensão Pulmonar.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E COMPLEXO DA SAÚDE substituto no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a hipertensão pulmonar no Brasil e as diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 806/2023 e o Relatório de Recomendação n<sup><u>o</u></sup> 809 – Março de 2023 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e a avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SECTICS/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SECTICS/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hipertensão Pulmonar.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da hipertensão pulmonar, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da hipertensão pulmonar.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAES/MS n<sup>o</sup> 35, de 16 de janeiro de 2014, publicada no Diário Oficial da União (DOU) nº 12, de 17 de janeiro de 2014, seção 1, página 91, e republicada no (DOU) nº 107, de 6 de junho de 2014, seção 1, página 48, e no (DOU) nº 183, de 23 de setembro de 2014, seção 1, página 48.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
**ANEXO** PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS HIPERTENSÃO PULMONAR

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A hipertensão pulmonar (HP) é uma síndrome clínica e hemodinâmica que resulta no aumento da resistência vascular na pequena circulação, elevando os níveis pressóricos na circulação pulmonar<sup>1</sup> . Este aumento de resistência pode estar associado a várias condições médicas subjacentes ou a uma doença que afete exclusivamente a circulação pulmonar<sup>2</sup> .  
Apesar de ser considerada uma doença rara, a HP está se tornando um problema de saúde global cada vez mais comum e associada a um prognóstico ruim. Dados epidemiológicos estimam que a incidência mundial de HP seja entre 2 e 5 pacientes acometidos a cada milhão de adultos por ano, sendo que a incidência aumenta em indivíduos com idade acima de 65 anos<sup>3</sup> . Uma alta carga de mortalidade está associada à doença, principalmente quando há ausência de tratamento específico, casos nos quais é estimada uma sobrevida mediana de 2,8 anos<sup>4</sup> .  
A definição de HP já foi bastante discutida e ajustada ao longo dos anos<sup>5,6</sup> . A definição atual, elaborada por consenso por ocasião do 6º Simpósio Mundial de HP, estabelece que a HP pode ser definida por pressão arterial pulmonar média (PAPm) acima de 20 mmHg combinada a outras medidas hemodinâmicas, como, por exemplo, pressão de oclusão capilar pulmonar (POCP) e resistência vascular pulmonar (RVP)<sup>7</sup> . Conforme variação das medidas hemodinâmicas, a HP pode ser classificada em pré-capilar, em pós-capilar e na combinação de pré e pós-capilar, como apresentado no **Quadro 1** .  
A HP pré-capilar é definida pela presença concomitante de PAPm maior do que 20 mmHg, POCP menor ou igual a 15 mmHg e RVP igual ou maior a 3 unidades Wood. Nesta situação, o predomínio da doença vascular está no território arterial e há a necessidade de cateterismo cardíaco direito, como medida mandatória do débito cardíaco (DC) e da POCP<sup>8</sup> . A falha na confirmação do diagnóstico por cateterismo cardíaco direito é a principal causa de excesso de diagnóstico e tratamento da HP pré-capilar<sup>8</sup> .  
Por outro lado, quando a POCP for superior a 15 mmHg, o paciente apresenta HP pós-capilar, o que sugere a presença de alterações nas câmaras cardíacas esquerdas<sup>9</sup> . Há situações em que a HP pode ser classificada como combinada, isto é, quando a POCP está acima de 15 mmHg, mas não parece suficiente para justificar a magnitude de elevação da PAPm. Esses pacientes apresentam resistência vascular pulmonar maior ou igual a 3 unidades Wood e geralmente o gradiente diastólico pulmonar superior a 7 mmHg (GDP - diferença entre a pressão diastólica de artéria pulmonar e a pressão de capilar pulmonar)<sup>10</sup> .  
**Quadro 1 -** Definição hemodinâmica de hipertensão pulmonar.  
|**Definição**|**Características**<br>**PAPm**|**POCP**|**RVP**|**Grupos clínicos**<sup>**#**</sup>|
|---|---|---|---|---|
|**HP pré-capilar**|>20 mmHg|≤15 mmHg|>2 WU|1, 3, 4 e 5|
|**HP pós-capilar isolada**|>20 mmHg|>15 mmHg|≤2 WU|2 e 5|
|**HP pré e pós-capilar**<br>**combinada**|>20 mmHg|>15 mmHg|>2 WU|2 e 5|  
<mark>Fonte: Adaptado de Simonneau e colaboradores, 2019</mark><sup>7</sup> <mark>. Legenda: PAPm: pressão arterial pulmonar média; POCP: pressão de oclusão capilar pulmonar; RVP: resistência vascular pulmonar; WU: unidades Wood.</mark><sup>#</sup> <mark>Conforme estabelecidos no Quadro 2: Grupo 1: HAP; Grupo 2: HP por doença cardíaca esquerda; Grupo 3: HP devido à doença pulmonar ou hipóxia; Grupo 4: HP devido à obstrução arterial pulmonar; Grupo 5: HP por mecanismos não esclarecidos ou multifatorial.</mark>  
A classificação mais atual da HP em adultos e crianças divide-se em cinco subgrupos, de acordo com mecanismos fisiopatológicos similares, apresentação clínica, características hemodinâmicas e abordagem terapêutica:  
 Grupo 1: Hipertensão arterial pulmonar (HAP);  
- Grupo 2: HP devido à doença cardíaca esquerda;  
- Grupo 3: HP devido à doença pulmonar ou hipóxia;  
- Grupo 4: HP devido à obstrução de artérias pulmonares;  
- Grupo 5: HP com mecanismos multifatoriais ou não claros.  
Cada um dos grupos compreende um conjunto de condições, conforme descritas no **Quadro 2** .  
**Quadro 2** - Classificação clínica da hipertensão pulmonar.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
- 1.1 HAP idiopática  
- 1.2 HAP hereditária  
- 1.3 HAP induzida por drogas e toxinas  
- 1.4 HAP associada com:  
- 1.4.1 doença do tecido conjuntivo  
- 1.4.2 infecção pelo HIV  
- 1.4.3 hipertensão portal  
- 1.4.4 doença cardíaca congênita  
- 1.4.5 esquistossomose  
- 1.5 HAP dos respondedores a longo prazo dos bloqueadores dos canais de cálcio (ver **Quadro** 3)  
- 1.6 HAP com características evidentes de acometimento venoso/capilar (DVOC/HCP)  
- 1.7 Síndrome da HP persistente do recém-nascido **2. HP devido à doença cardíaca esquerda**  
- 2.1 HP devido à insuficiência cardíaca com FEVE preservada  
- 2.2 HP devido à insuficiência cardíaca com FEVE reduzida  
- 2.3 Doença cardíaca valvular  
- 2.4 Condições cardiovasculares congênitas/adquiridas que levam à HP pós-capilar  
**3. HP devido a doenças pulmonares ou hipóxia**  
- 3.1 Doença pulmonar obstrutiva  
- 3.2 Doença pulmonar restritiva  
- 3.3 Outras doenças pulmonares com padrão restritivo/obstrutivo misto  
- 3.4 Hipóxia sem doença pulmonar  
- 3.5 Distúrbios pulmonares do desenvolvimento  
**4. HP devido a obstruções da artéria pulmonar**  
- 4.1 HP tromboembólica crônica (HPTEC)  
- 4.2 Outras obstruções da artéria pulmonar  
- 4.2.1 Sarcoma (grau alto ou intermediário) ou angiossarcoma  
4.2.2 Outros tumores malignos (carcinoma renal, carcinoma uterino, tumores células germinativas do testículo e outros tumores)  
4.2.3 Tumores não malignos (leiomioma uterino)  
- 4.2.4 Arterite sem doença do tecido conjuntivo 4.2.5 Estenoses da artéria pulmonar congênita 4.2.6 Parasitas (hidatidose)

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
5.1 Distúrbios hematológicos Anemia hemolítica crônica, distúrbios mieloproliferativos.  
5.2 Distúrbios sistêmicos e metabólicos  
Histiocitose pulmonar por células de Langerhans, doença de Gaucher, doença de armazenamento de glicogênio, neurofibromatose, sarcoidose.  
5.3 Outros  
Insuficiência renal crônica com ou sem hemodiálise, mediastinite fibrosante  
5.4 Doença cardíaca congênita complexa  
Hipertensão pulmonar segmental (artéria pulmonar isolada de origem ductal, artéria pulmonar ausente, atresia pulmonar com defeito septo ventricular e artérias colaterais aorto-pulmonares principais, hemitruncus, outros), ventrículo único, síndrome da Cimitarra.  
Fonte: Adaptado de Simonneau e colaboradores, 2019<sup>7</sup> . Legenda: HAP: hipertensão arterial pulmonar; HP: hipertensão pulmonar; HIV: vírus da imunodeficiência adquirida; DVOP: doença veno-oclusiva pulmonar; HCP: hemangiomatose capilar pulmonar; FEVE: fração de ejeção ventricular esquerda.  
A hipertensão arterial pulmonar (HAP) (grupo 1) é caracterizada por perda e remodelação obstrutiva do leito vascular pulmonar. A elevação crônica da resistência vascular pulmonar pode resultar em disfunção progressiva do ventrículo direito (VD) e insuficiência do VD<sup>7</sup> . A HAP pode ocorrer por diversos fatores, desde forma idiopática ou hereditária, assim como decorrente do uso de toxinas ou de outras doenças, conforme o **Quadro 2Quadro 2** . A história natural da HAP de etiologia idiopática foi bem caracterizada pelo _National Institute of Health Registry on Primary Pulmonary Hypertension_ americano (NIH) _,_ sendo, o tempo médio de sobrevida dos pacientes naquele registro de 2,8 anos a partir do diagnóstico<sup>5</sup> .  
Já a hipertensão pulmonar por doença cardíaca do lado esquerdo (grupo 2) ocorre em resposta a um aumento da pressão do átrio esquerdo (AE) e, geralmente, é consequência de um distúrbio cardíaco subjacente, como insuficiência cardíaca (com ou sem fração de ejeção reduzida) ou doença cardíaca valvar<sup>11</sup> .  
No Grupo 3, a hipertensão pulmonar devido à doença pulmonar crônica ou hipóxia pode ocorrer em muitas doenças pulmonares, incluindo doença pulmonar obstrutiva crônica (DPOC), doença pulmonar intersticial e distúrbios respiratórios do sono. A elevação da pressão arterial pulmonar média na DPOC pode resultar da perda de vasculatura pulmonar, distensibilidade vascular e redução do recrutamento de vasos<sup>12</sup> .  
A HP tromboembólica crônica (HPTEC) (grupo 4) é caracterizada por obstrução da vasculatura pulmonar por material tromboembólico organizado e remodelação vascular, decorrente de embolia pulmonar prévia. A HP tromboembólica crônica provavelmente é subdiagnosticada e sua incidência e prevalência não foram estabelecidas recentemente<sup>13</sup> .  
Por fim, o grupo 5 reúne condições clínicas sem mecanismo predominante identificado que conduza ao desenvolvimento da HP e pode envolver vários fenômenos fisiopatológicos em seu processo. Desde o início, esse grupo representou formas de HP menos estudadas em comparação com outros grupos. No entanto, muitas das formas de HP atualmente alocadas no grupo 5 representam uma parte significativa da carga mundial ainda não reconhecida de HP<sup>14</sup> .  
Neste Protocolo, a abordagem da HP inclui medidas e cuidados não medicamentosos, tratamento específico e tratamento adjuvante.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da hipertensão pulmonar. A elaboração deste PCDT teve como base para sua estruturação o processo preconizado pela Diretriz Metodológica de Elaboração de Diretrizes  
Clínicas do Ministério da Saúde<sup>15,16</sup> . O processo de desenvolvimento desse PCDT envolveu a realização de revisões sistemáticas (RS) e o levantamento de ensaios clínicos randomizados (ECR) para as sínteses de evidências, e foram adotadas ou adaptadas as recomendações já publicadas para as tecnologias que se encontram disponíveis no SUS para as respectivas condições. A metodologia de busca e a avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
- I27.0 Hipertensão arterial pulmonar primária  
- I27.2 Outra hipertensão pulmonar secundária  
- I27.8 Outras doenças pulmonares do coração especificadas (HAP associada a cardiopatias congênitas/síndrome de  
- Eisenmenger)  
À exceção da HAP idiopática e familiar, todas as demais enfermidades devem ser acompanhadas de CID secundário, que especifique a situação associada à HP.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
O diagnóstico de HP é complexo e requer uma extensa avaliação clínica, laboratorial e radiológica. Uma avaliação cuidadosa da história médica, condição física, ecocardiograma e parâmetros hemodinâmicos é essencial para diagnosticar e caracterizar as diferentes formas de HP de forma eficaz. Em caso de suspeita de HAP ou HPTEC, há a necessidade de confirmação diagnóstica invasiva via cateterismo cardíaco direito<sup>17</sup> . Além da confirmação de HP, a utilização de um algoritmo diagnóstico visa a permitir a identificação da sua etiologia, que é fundamental para definir o tratamento do paciente.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Os sinais e sintomas de HP são bastante semelhantes aos de outras causas de insuficiência respiratória crônica, como dispneia progressiva, fadiga crônica, fraqueza, angina, estase jugular, cianose, pré-síncope e síncope<sup>17</sup> . Os achados físicos podem incluir elevação ou retração paraesternal esquerda, segunda bulha cardíaca aumentada, terceira bulha cardíaca do ventrículo direito, pressão venosa jugular elevada com forma de onda anormal, pulsos arteriais de baixo volume, hepatomegalia, ascite, edema periférico e sopro regurgitante tricúspide<sup>17</sup> .  
Como várias doenças apresentam acometimento vascular pulmonar frequente, o médico deve estar atento para a possibilidade de HP, em especial a esclerodermia (até 27% de prevalência de HP), esquistossomose (7,7% de HP na doença hepatoesplênica), hipertensão portal (7,2% de HP em candidatos à transplante hepático), infecção pelo HIV (0,5% de HP) e embolia pulmonar (5,1% de prevalência de HPTEC)<sup>2,17</sup> .  
Ainda, algumas substâncias foram associadas com o desenvolvimento de HAP e o seu uso deve ser pesquisado durante a avaliação inicial de HAP (Quadro 3).  
**Quadro 3** - Fármacos associados à HAP.  
|**Associação definitiva**|**Associação possível**|
|---|---|
|Aminorex|Cocaína|
|Fenfluramina|Fenilpropanolamina|
|Dexfenfluramina|L-triptofano|
|Benfluorex|Erva de São João|
|Metanfetaminas|Anfetaminas|
|Desatinibe|Interferon α e β|  
|**Associação definitiva**|**Associação possível**|
|---|---|
|Óleo de canola tóxico|Agentes alquilantes (mitomicina C, ciclofosfamida)<sup>5</sup>|
||Bosutinibe|
||Antivirais contra hepatite C|
||Leflunomida|  
Fonte: Modificado do 6º _World Symposium on Pulmonary Hypertension_<sup>18,19</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Na investigação inicial de insuficiência respiratória, alguns exames podem indicar a presença de HP, entre eles:  
 Radiografia de tórax – os sinais sugestivos de HP são o abaulamento do tronco de artéria pulmonar; a distância entre a borda do ventrículo direito e a coluna vertebral superior a 44 mm; a relação entre a distância entre os hilos pulmonares e a distância entre as extremidades torácicas superior a 0,44; o diâmetro da artéria descendente anterior direita superior a 16 mm e da esquerda superior a 18 mm; o preenchimento do espaço retroesternal pela área cardíaca<sup>20</sup> .  
 Eletrocardiograma – os sinais sugestivos de HP são a presença de sobrecarga de câmaras direitas e a presença de bloqueio de ramo direito. Taquicardia sinusal, taquiarritmias e alterações da repolarização ventricular também podem estar presentes<sup>21</sup> .  
 Prova de função pulmonar e oximetria - a maior parte dos pacientes com doença vascular pura apresenta um componente restritivo leve à espirometria - capacidade vital forçada (CVF) maior que 70% do predito. Distúrbios obstrutivos também podem estar presentes na HAP, desde que de pequena monta – volume expiratório forçado no primeiro segundo (VEF1) maior que 60% do predito. Reduções acentuadas na difusão de monóxido de carbono (menor que 60%) podem estar presentes e, em geral, são mais frequentes do que as alterações ventilatórias apresentadas anteriormente<sup>12</sup> . Hipóxia também pode estar presente nas doenças da circulação pulmonar.  
 Ecocardiograma - o ecocardiograma permite a avaliação da probabilidade da existência de HP ao avaliar a velocidade de regurgitação de fluxo na válvula tricúspide, tamanho do ventrículo direito, função do septo interventricular, flutuações do diâmetro da veia cava inferior com a respiração e diâmetros das artérias pulmonares (vide **Quadro 4** )<sup>22</sup> . O ecocardiograma também possibilita a avaliação das câmaras cardíacas esquerdas, permitindo a identificação dos casos de HP associados a doenças do coração esquerdo (HP grupo 2). Nesses casos, a HP deve-se a um processo passivo de aumento de pressões nas câmaras esquerdas e posterior acometimento arterial pulmonar. Este exame também permite a confirmação de _shunt_ cardíaco e de cardiopatia congênita. Assim, a investigação diagnóstica de HP pode ser interrompida e o foco do tratamento deve ser a disfunção cardíaca esquerda. Metade dos casos de HP na América do Sul possui esta etiologia<sup>23</sup> .  
**Quadro 4** - Probabilidade ecocardiográfica de HP.  
|**Pico de velocidade de regurgitação na**|**Presença de outros sinais**|**Probabilidade ecocardiográfica**|
|---|---|---|
|**tricúspide m.s**<sup>**-1**</sup>|**ecocardiográficos de HP**|**de HP**|
|<2,8 ou não mensurável|Não|Baixa|
|<2,8 ou não mensurável|Sim|Intermediária|
|2,9-3,4|Não|Intermediária|
|2,9-3,4|Sim|Alta|
|>3,4|Não exigido|Alta|  
Fonte: Modificado de Frost e colaboradores, 2019<sup>22</sup>  
 Tomografia de tórax - em conjunto com a prova de função pulmonar, permite excluir o diagnóstico de HP associada a  
doença pulmonar crônica ou hipoxemia (HP grupo 3). Grandes alterações parenquimatosas pulmonares com enfisema, fibrose ou outras pneumopatias intersticiais podem justificar 45% das causas de HP<sup>23</sup> . Estes pacientes também não necessitam prosseguir na investigação diagnóstica de HP.  
 Polissonografia: pode ser útil no algoritmo diagnóstico de HP, por permitir a exclusão de apneia obstrutiva do sono em paciente sintomático.  
 Cintilografia de inalação/perfusão - é fundamental para identificar embolia pulmonar crônica como causa de HP (grupo 4). A identificação deste grupo de pacientes é fundamental, pois a HPTEC é uma causa potencialmente curável de HP e os pacientes devem ser avaliados visando a possibilidade de endarterectomia pulmonar, realizada em centro de referência. Por apresentar menor sensibilidade para o diagnóstico de HPTEC, a angiotomografia convencional não substitui a cintilografia. Vale destacar que a cintilografia é necessária para excluir o diagnóstico de HPTEC crônico. Porém seu diagnóstico não é definitivo apenas com este exame, sendo necessária a complementação com angiografia pulmonar por tomografia computadorizada, convencional ou por ressonância magnética<sup>24</sup> . Novas tecnologias para identificação de HPTEC, como SPECT V/Q com emissão de fóton único ou tomografia de tórax de perfusão com dupla energia são promissoras, mas são necessários mais estudos para que seu uso possa ser recomendado<sup>22</sup> .  
 Cateterismo cardíaco direito - é fundamental para a confirmação diagnóstica do paciente com HP. Apesar de invasivo, o risco do procedimento em centros experientes é bastante pequeno, com uma morbidade de apenas 1,1%<sup>25</sup> . Os seguintes parâmetros devem ser aferidos: pressão de artéria pulmonar sistólica, diastólica e média, pressão de oclusão de artéria pulmonar diagnóstico e resistência vascular pulmonar. Além disso, também devem ser aferidos o débito/índice cardíaco, pressão de átrio direito e medida de saturação venosa central, todos com valor prognóstico. O débito cardíaco pode ser aferido por meio do método de termodiluição ou pelo método de Fick. Os pontos de corte de valores diagnósticos para os diferentes tipos de hipertensão pulmonar são descritos no **Quadro 1** .  
 O teste de vasorreatividade deve ser realizado em pacientes com HAP idiopática, hereditária ou induzida por medicamentos. Pode ser utilizado óxido nítrico, iloprosta inalatório ou epoprostenol endovenoso. Para ser considerado vassorreator, o paciente deve apresentar uma queda de pelo menos 10 mmHg na pressão média de artéria pulmonar, devendo atingir níveis inferiores à 40 mmHg, com manutenção ou elevação do débito cardíaco ( **Quadro 5** ).  
**Quadro 5** - Definição dos respondedores agudos e a longo prazo dos bloqueadores de canal de cálcio.  
|**Teste de vasorreatividade aguda para pacientes com**|**Resposta a longo prazo aos bloqueadores dos canais de**|
|---|---|
|**HAP idiopática, hereditária ou induzida por**<br>**medicamentos**|**cálcio (BCC)**|
|Redução de PAPm ≥ 10 mmHg para atingir um valor<br>absoluto de PAPm ≤ 40 mmHg<br>Débito cardíaco aumentado ou inalterado|Classe Funcional I/II da NYHA<br>Melhora hemodinâmica sustentada (igual ou melhor do que o<br>alcançado no teste agudo) após pelo menos 1 ano com uso apenas<br>de BCC.|  
Fonte: Adaptado de Simonneau G, e colaboradores, 2019<sup>7</sup> . Abreviaturas – HAP: hipertensão arterial pulmonar; PAPm: pressão arterial pulmonar média; NYHA:  
_New York Heart Association_ ; BCC: bloqueadores dos canais de cálcio.  
 Exames laboratoriais - uma vez confirmada a presença de HP via cateterismo cardíaco direito e feita a classificação da etiologia da HP como sendo grupo 1 (já descartadas HP associada à doença cardíaca esquerda - grupo 2, à doença pulmonar crônica - grupo 3, à embolia pulmonar crônica - grupo 4 e a doenças com mecanismos multifatoriais ou desconhecidos - grupo 5), as condições associadas ao grupo 1 devem ser pesquisadas. A maior parte destas condições é avaliada por testes laboratoriais, com realização de hemograma, exame parasitológico de fezes, pesquisa de anticorpo antinuclear,  
aminotransferases/transaminases (alaninoaminotransferase – ALT/TGP e aspartatoaminotransferase – AST/TGO), gasometria arterial, de anticorpos anti-DNA, de fator reumatoide, de anticorpo anti-HIV, de HbsAg, de anticorpo anti-HBC (IgG), de anticorpo anti-HCV. Cabe, também, nesse momento a realização de uma ultrassonografia de abdome, para descartar síndrome portopulmonar ou esquistossomose grave. O algoritmo diagnóstico completo está sumarizado nas **Figuras 1 e 2** .  
**Figura 1** - Algoritmo diagnóstico de hipertensão pulmonar.  
<!-- Start of picture text -->
( Paciente com sinais e sintomas compativeis com Hipertensdo Pulmonar }<br>Realizacéo de ecocardiograma<br>Probabilidade ecocardiogratica de Probabilidade ecocardiogratica de<br>HP intermediaria ou alta HP baixa<br>Buscar outra etiologia para os<br>sintomas<br>Fatores de risco do paciente: idade Paciente possui<br>e comorbidades cardiovasculares fatores de risco ou dados ‘Sim ‘Tratar as doengas do coragao<br>(HAS, DM, FA, obesidade) ‘ecocardiograticoscon doencompativeis ea Grupo I ‘esquerdo utilizando diurético<br>Dados ecocardiograficos (tamanho coragdo esquerdo como vasodiiatadores<br>do AE, VE e septo) causa de HP?<br>Nao<br>Tomografia de torax Paciente possui im<br>Prova de funcao exames compativeis Tratar as doengas pulmonares<br>Gasometria arterial ‘com doengas pulmonares Grupo tt utilizando oxigénio<br>Polissonografia (se apresentar cronicas como broncodilatadores<br>sintomas de apneia) causa de HP?<br>Nao<br>Cintilogratia examesPaciente compativeis possui Sim Gas Avaliaras possibilidades de<br>Inalagdo/Perfusio com embolia pulmonar como 3 tromboendartectomiat6rax, arteriografia, cateterismo(angio-TCde|<br>causa de HP? cardiaco direito)<br>Nao<br>‘Cateterismo cardiaco\. Nao<br>direito confirmou HP Buscar outras etiologias<br>(PAPm > 20)?<br>Sim<br>PAOP>15, PAOP <15<br>RVP>2<br>euzall Grupo |<br>Hipertensao Arterial Pulmonar<br>Tratar as doengas do coragao acai<br>esquerdo utilizando diurético e Coup<br>vasodlilatadores<br><!-- End of picture text -->  
Fonte: Adaptado do algoritmo da Sociedade Europeia de Cardiologia/Sociedade Respiratória Europeia para diagnóstico de HP<sup>26</sup> . HAS: hipertensão arterial pulmonar; DM: diabetes melitus; FA: fibrilação atrial; AE: átrio esquerdo; VE: ventrículo esquerdo; HP: hipertensão pulmonar; PAPm: pressão arterial pulmonar média; PAOP: pressão arterial pulmonar obstruída; RVP: resistência vascular pulmonar; HAP: hipertensão arterial pulmonar.  
**Figura 2** - Algoritmo diagnóstico etiológico de HAP.  
<!-- Start of picture text -->
_<br>Paciente com HAP confirmada por cateterismo cardiaco<br>direito (PAPm > 20 e PAOP < 15 e RVP > 2)<br>es<br>Definigdo da etiologia da doenga<br>Historiavetor: Todas as outras, Sorologias,  de Epidemiologia-jemioloa: ‘Achados TC<br>Testes eee etiologias Pe hepatite PPF Sorologia Ecocardiograma _cepecttcos<br>genéticos " descartadas oh USG abdome USG abdome aoe<br>—y a<br>HAP HAP induzida acne HAP associada| | Hipertensao Cardiopatia<br>vasorreatividadeTeste de Negativo Estratificagdo de risco<br>NO 10-20 ppm<br>Positivo (Queda da PAPM > Paciente teve resposta Nao Tamer<br>10 mmHg para atingir < 40 Tratar com bloqueador do sustentada (1a), CF I, le oD<br>mmHg com DC inalterado ou canal de calcio remodinamica igualimethor & ana<br>elevado) anterior ao tratamento? (RO)<br>Sim<br>Mantercanalcom debloqueadorcalcio do Re-estratificagdofon) de<br><!-- End of picture text -->  
Fonte: Adaptado do algoritmo da Sociedade Europeia de Cardiologia/Sociedade Respiratória Europeia para diagnóstico de HP<sup>26</sup> . PAPm: pressão arterial pulmonar média; PAOP: pressão arterial pulmonar obstruída; RVP: resistência vascular pulmonar; HAP: hipertensão arterial pulmonar, HIV: vírus da imunodeficiência humana; TC: tomografia; FAN: fator antinuclear; USG: ultrassonografia; PPF: fibrose periportal; NO: óxido nítrico; ppm: partes por milhão; DC: débito cardíaco; CF: classe funcional.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Uma vez confirmado o diagnóstico de HP, antes do início do tratamento específico o paciente deve ter sua gravidade avaliada. Para HAP, há algumas ferramentas baseadas na estratificação de risco de morte do paciente que podem ser utilizadas. Destacam-se entre elas a calculadora de risco do registro REVEAL<sup>27</sup> , a ferramenta dos registros de HP sueco<sup>28</sup> e COMPERA<sup>29</sup> e a ferramenta simplificada do registro francês<sup>30</sup> . A estratificação de risco é validada para avaliar mortalidade para pacientes do grupo 1 da classificação (i.e. HAP), sendo possível aplicar a estratificação de risco aos grupos 2, 3 e 4 da HP, reconhecendo que <mark>a correlação com mortalidade foi menos estudada nesses grupos, que não há indicação de tratamento com drogas-alvo de HAP nos grupos 2 e 3 e que a terapia e</mark> specífica vasodilatadora pode ser indicada apenas no grupos 1 e 4<sup>31</sup> .  
Preconiza-se que o paciente seja avaliado e seu risco estratificado a cada 3 a 6 meses, durante sua reavaliação clínica, conforme o **Quadro 6** . Em todas as consultas, deve ser avaliada a classe funcional do paciente, conforme classificação da NYHA/OMS ( **Quadro 7** ) e a distância percorrida no teste de caminhada de 6 minutos. Serão considerados de baixo risco todos os pacientes que preencherem os dois critérios (classe funcional I ou II e distância percorrida no teste de caminhada de 6 minutos maior que 440 metros). Se o paciente preencher pelo menos um critério não invasivo de alto risco, como classe funcional IV, ou distância percorrida no teste de caminhada de 6 minutos menor que 165 metros, a gravidade do quadro deve ser confirmada por medida hemodinâmica invasiva. O paciente será considerado de alto risco se, além de pelo menos um critério clínico, ele apresentar um critério hemodinâmico de maior gravidade, como pressão de átrio direito maior que 14 mmHg, índice cardíaco menor que 2,0 L/min/m<sup>2</sup> ou saturação venosa central menor que 60%. Se o paciente não preencher os critérios de baixo ou alto risco, ele será considerado de risco intermediário. Nesses casos, outros meios de estratificação de risco podem ser utilizados para definir a real condição clínica do paciente, como ergo-espirometria ou ecocardiografia. O objetivo do tratamento da HAP é buscar sempre o baixo risco para todos os pacientes. De um modo geral, os principais parâmetros de risco estão expressos no **Quadro 8** .  
**Quadro 6** - Estratificação simplificada de risco de morte dos pacientes com HAP.  
|**Variáveis**|**Risco baixo**<br>**(CF I, II)**|**Risco intermediário**<br>**(CF III)**|**Risco alto**<br>**(CF IV)**|
|---|---|---|---|
|Clínicas e funcionais*|TC6M > 440 m|TC6M 165-440 m|TC6M < 165 m|
||(Opcional)|(Opcional)|Mandatória|
|Hemodinâmicas|Pressão de AD < 8|Pressão de AD 8-14|Pressão de AD > 14|
||SVO2 > 65%|SVO2 60- 65%|SVO2 < 60%|  
*Avaliadas a cada 3-6 meses. Fonte: Adaptado de Boucly, A e colaboradores, 2017<sup>30</sup> .  Abreviaturas – CF: classe funcional; AD: átrio direito (em mmHg); TC6M: teste de caminhada de 6 minutos; SVO2: saturação venosa central.  
**Quadro 7** - Classificação funcional da HAP da Organização Mundial da Saúde (OMS).  
|**Classe**|**Características clínicas**|
|---|---|
|I|Pacientes com HAP sem limitação das atividades físicas. Atividades físicas habituais não causam dispneia ou<br>fadiga excessiva, dor torácica ou pré-síncope.|
|II|Pacientes com HAP com discreta limitação das atividades físicas. Pacientes confortáveis no<br>repouso, mas as atividades físicas habituais causam dispneia ou fadiga excessiva, dor torácica ou<br>pré-síncope.|
|III|Pacientes com HAP com relevante limitação das atividades físicas. Pacientes confortáveis no<br>repouso, mas esforços menores que as atividades físico habituais causam dispneia ou fadiga<br>excessiva, dor torácica ou pré́-síncope.|  
|**Classe**||**Características clínicas**|
|---|---|---|
|IV|Pacientes com HAP com incapacidade|para realizar qualquer atividade física sem sintomas. Pacientes|
||manifestam sinais de falência ventricular|direita. Dispneia ou fadiga podem estar presentes no repouso e o|
||desconforto aumenta com qualquer esforço|feito.|  
**Quadro 8** - Estratificação de risco de morte em um ano dos pacientes com HAP.  
|**Determinantes do**||**Mortalidade estimada em 1**|**ano**|
|---|---|---|---|
|**prognóstico**|**Risco baixo < 5%**|**Risco intermediário 5-10%**|**Risco alto > 10%**|
|Sinais clínicos de<br>insuficiência VD|Ausente|Ausente|Presente|
|Progressão sintomas|Não|Lenta|Rápida|
|Síncope|Não|Ocasionalmente*|Repetidamente**|
|Classe funcional (OMS)|I, II|III|IV|
|Distância caminhada em teste<br>dos 6 minutos|> 440 m|165-440 m|< 165 m|
|Teste do exercício<br>cardiopulmonar|Pico VO2 > 15<br>(> 65% pred.)<br>Inclinação<br>VE/VCO2 < 36|Pico VO2 11–15<br>(35-65% pred.)<br>Inclinação VE/VCO2 36–44.9|Pico VO2 < 11<br>(< 35% pred.)<br>Inclinação VE/VCO2 ≥ 45|
|Exames de imagem|Área AD < 18 cm<sup>2</sup>|Área AD 18–26 cm<sup>2</sup>|Área AD > 26 cm<sup>2</sup>|
|(Eco, RM tórax)|Ausência de DP|Ausência ou mínimo DP|DP presente|
||Pressão AD < 8|Pressão AD 8–14|Pressão AD >14|
|Parâmetros hemodinâmicos|IC ≥ 2,5|IC 2,0–2,4|IC < 2,0|
||SvO2 > 65%|SvO2 60–65%|SvO2 < 60%|  
Fonte: Adaptado de Gallie N e colaboradores, 2015<sup>17</sup> . Legenda – VD: ventrículo direito; pico VO2: <mark>consumo de oxigênio de</mark> _<mark>pico</mark>_ (mL/min/kg); Alça VE/VCO2: equivalente ventilatório para o CO2; AD: átrio direito (mmHg); DP: derrame pericárdico; IC: índice cardíaco (l/min/m<sup>2</sup> ); SvO2: saturação venosa central. *Síncope ocasional durante exercício brusco ou intenso, ou síncope ortostática ocasional num paciente previamente estável. **Episódios repetidos de síncope, mesmo em atividade física leve ou regular.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Serão incluídos neste Protocolo todos os pacientes com diagnóstico de Hipertensão Pulmonar:  
1. Hipertensão arterial pulmonar (HAP);  
2. HP devido à doença cardíaca esquerda;  
3. HP devido à doença pulmonar ou hipóxia;  
4. HP devido à obstrução de artérias pulmonares (HPTEC);  
5. HP com mecanismos multifatoriais ou não claros.  
Serão incluídos para tratamento medicamentoso específico os pacientes do grupo 1 (HAP), diagnosticados por meio de cateterismo cardíaco direito, que demonstrarem pressão média da arterial pulmonar acima de 25 mmHg **E** pressão de oclusão da artéria pulmonar menor ou igual a 15 mmHg **E** resistência vascular pulmonar maior que 2 WU.  
Serão elegíveis ao transplante de pulmão os pacientes com HP que não atingirem o baixo risco apesar de estarem em uso de terapia tripla com dose otimizada e que apresentarem condições clínicas para o transplante, conforme o vigente Regulamento  
Técnico do Sistema Nacional de Transplantes, e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Intolerância, hipersensibilidade ou contraindicação serão os critérios de exclusão ao uso dos respectivos medicamentos preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Pacientes pediátricos dos grupos 1 a 5 da HP devem seguir as mesmas orientações fornecidas por este PCDT para os adultos, atentando-se para as doses preconizadas para as crianças das alternativas terapêuticas aqui contempladas, conforme esquemas de administração preconizados neste Protocolo<sup>8</sup> .  
A HP pediátrica está associada a diversas doenças, com início em diferentes idades. Diferenças na etiologia, apresentação e desfechos requerem, por vezes, abordagem única em crianças. A distribuição de etiologias em HP pediátrica é bem diferente da dos adultos, sendo em crianças maior a predominância de HAP idiopática, HAP associada a doenças cardíacas congênitas (HAP-DCC) e HP associada a doenças pulmonares do desenvolvimento. Atualmente, sugere-se que o tratamento com vasodilatador específico seja baseado em metas de estratificação de risco, tal como em pacientes adultos<sup>8</sup> . Embora a falta de dados de ensaios clínicos para o uso da terapia direcionada à HP pediátrica persista, os dados emergentes estão melhorando a identificação de alvos apropriados para terapia em crianças.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Dados recentes indicam que o resultado das gestantes com HAP melhorou ao longo do tempo, especialmente, quando a HAP está bem controlada e naquelas pacientes com teste de vasorreatividade positivo, que permanecem em uso de BCC oral por longo tempo<sup>17</sup> . No entanto, a gravidez está associada a uma taxa de mortalidade substancial na HAP e, portanto, a recomendação geral é de que todas as pacientes com HAP evitem a gravidez<sup>17</sup> .  
Em relação aos métodos de controle de natalidade mais adequados, apesar dos métodos contraceptivos de barreira se mostrarem seguros para o paciente, eles possuem um efeito imprevisível<sup>17</sup> . Progestágenos, como acetato de medroxiprogesterona, são eficazes para a contracepção e evitam os problemas potenciais do uso de estrogênios. Visto que a bosentana pode reduzir a eficácia dos agentes contraceptivos orais, uma combinação de dois métodos (dupla barreira) é preconizada. A paciente que engravidar deve ser informada acerca do alto risco que corre e a interrupção precoce da gravidez deve ser discutida. As pacientes que optarem por continuar a gravidez devem manter o tratamento da doença, ter parto eletivo planejado e contar com colaboração efetiva entre obstetras e especialistas em HP para o controle, adequação e possível suspensão do uso de medicamentos teratogênicos que, porventura, esteja em uso<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A definição do tratamento dependerá da classificação etiológica da doença, conforme grupos 1 a 5, e da estratificação de risco ( **Quadro 8** ). O tratamento está dividido em três etapas principais: 1) medidas gerais ou tratamento de suporte, para todos os grupos; 2) tratamento medicamentoso específico por grupo, quando houver indicação; 3) tratamento cirúrgico, com transplante de pulmão, para os casos de resposta terapêutica inadequada<sup>17</sup> .  
A adesão ao tratamento deve ser verificada em cada reavaliação clínica pela complexidade da terapia, atentando para possíveis alterações induzidas espontaneamente por pacientes ou médicos não especialistas<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
As medidas gerais incluem assistência multiprofissional aos pacientes com HP, com orientações que otimizem suas atividades de vida diária frente à marcada limitação funcional decorrente da doença. O diagnóstico de HP geralmente confere um certo grau de isolamento social, com achados comuns de depressão e ansiedade, o que potencializa sintomas como a dispneia<sup>32,33</sup> .  
Pacientes classificados no grupo 1 (HAP) tiveram um aumento em complexidade e número de evidências de eficácia, na última década<sup>17</sup> , bem com o desenvolvimento de medicamentos específicos. O processo de tratamento deve considerar uma estratégia complexa, envolvendo a avaliação inicial da gravidade e o acompanhamento da resposta ao tratamento<sup>17</sup> .  
O objetivo primário da abordagem terapêutica para pacientes com HP por doença cardíaca esquerda (grupo 2) é melhorar o tratamento global da condição subjacente, antes de considerar medidas específicas para tratar a HP. Isso inclui reparo de doença cardíaca valvar, quando indicado, e terapia agressiva para insuficiência cardíaca com função sistólica reduzida<sup>11,34</sup> .  
Atualmente, não existe terapia específica para HP associada a doenças pulmonares (grupo 3)<sup>35</sup> . No geral, pacientes com doença pulmonar e HP hipoxêmicos devem receber terapia com O2 a longo prazo, adaptando as recomendações gerais para DPOC. O tratamento da doença pulmonar subjacente deve ser otimizado<sup>35</sup> .  
Para pacientes classificados com hipertensão pulmonar tromboembólica crônica (grupo 4), uma abordagem multimodal e individualizada é preconizada, uma vez que engloba diferentes terapêuticas que visam melhorar a qualidade de vida<sup>13</sup> .  
O tratamento da HP devido a mecanismos pouco claros ou multifatoriais (grupo 5) deve ser adaptado para o diagnóstico primário, que pode incluir vários distúrbios com múltiplas pato-etiologias, como por exemplo: vasoconstrição pulmonar, vasculopatia proliferativa, compressão extrínseca, oclusão intrínseca, insuficiência cardíaca de alto débito, obliteração vascular e insuficiência cardíaca esquerda. Portanto, o tratamento da HP é secundário.  
Sabe-se que procedimentos cirúrgicos eletivos oferecem risco aumentado em pacientes com HAP, sendo a anestesia epidural provavelmente mais bem tolerada do que a anestesia geral<sup>36</sup> . Os pacientes geralmente mantidos em terapia via oral podem exigir conversão temporária para tratamento intravenoso ou nebulização até que consigam engolir e absorver medicamentos novamente. Dados retrospectivos de pacientes com HAP ou HPTEC após procedimentos cirúrgicos eletivos de artroplastia ortopédica de membros inferiores mostram redução da qualidade de vida dos pacientes após procedimentos cirúrgicos eletivos, mas sem mortalidade associada. As complicações perioperatórias incluíram: 1) hipotensão com necessidade de vasopressores (n = 10); 2) transfusão de sangue (n = 7); 3) infecção não ortopédica (n = 4); e 4) insuficiência cardíaca direita descompensada (n = 1).  
Em relação a pacientes com HP que realizam viagens aéreas, não há estudos para determinar a necessidade de O2 suplementar durante viagens aéreas prolongadas. Os efeitos fisiológicos conhecidos da hipóxia em voos sugerem que a administração de O2 deve ser considerada para pacientes com classes funcionais III e IV e naqueles com pressão arterial de O2 inferior a 60 mmHg persistente<sup>35</sup> . Um fluxo de 2 L/min aumenta a pressão inspirada de O2 para valores próximos aos do nível do mar. Da mesma forma, esses pacientes devem evitar altitudes superiores a 1500–2000 metros caso não possuam O2 suplementar. Ainda, os pacientes devem ser aconselhados a viajar com informações escritas sobre sua doença e serem orientados sobre serviços médicos de HP próximos ao destino<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Os pacientes classificados no grupo 1 (HAP) ou no grupo 4 (HPTEC) devem ser aconselhados a permaneceram ativos, respeitando os limites dos seus sintomas e evitando qualquer excesso que agrave a dispneia e a fadiga<sup>37-39</sup> , uma vez que potencializam a inatividade e comprometem a qualidade de vida pela progressiva perda de condicionamento<sup>físico40</sup> . O uso de tecnologias que possam auxiliar na monitorização da atividade física deve ser encorajado, oferecendo informações importantes para o acompanhamento clínico da capacidade funcional e do sedentarismo desses pacientes<sup>41</sup> . O exercício supervisionado é  
aconselhado pela diretriz mais recente da Sociedade Europeia de Cardiologia (ESC) e da Sociedade Respiratória Europeia (ERS) para pacientes do grupo 1 (HAP) clinicamente estáveis sob tratamento medicamentoso sem mudança nos últimos 2 meses. O treinamento físico deve envolver exercícios aeróbicos de baixa a moderada intensidade (60% a 80% da frequência cardíaca máxima, não excedendo 120 bpm), com o uso da escala subjetiva de esforço [0-10] e com a manutenção de uma SpO2 maior que 85% a 90%. Uma SpO2 maior que 85% é segura, no entanto, é necessário O2 suplementar quando a SpO2 estiver abaixo de 88%. Durante o uso de O2 suplementar, a SpO2 precisa permanecer acima de 85% para que o paciente possa continuar a realizar a atividade física. Caso a SpO2 oscile ou diminua a saturação, o paciente deve interromper a realização de atividade física<sup>37,42,43</sup> .  
O treinamento muscular de resistência e força periférica, central e respiratória deve ser complementar ao aeróbico. Como essas intervenções fazem parte de programas de reabilitação cardiopulmonar multidisciplinar, devem ser realizados, preferencialmente, em internação ou centros sob supervisão de fisioterapeuta ou educador físico especializado<sup>37,44</sup> . A frequência dos programas de reabilitação e exercícios supervisionados varia de 3 a 5 vezes por semana, com duração de 2 a 3 meses<sup>38,45</sup> .  
A eficácia do treinamento físico sobre a capacidade funcional foi verificada em três revisões sistemáticas com metaanálise, com aumento da distância percorrida no teste de caminhada de seis minutos (53 a 72 metros), aumento do VO2 de pico (1,5 a 2,2 mL/min/kg) e aumento da carga tolerada (14,9 W)<sup>38,43,46</sup> . Os benefícios do exercício estão associados a melhorias na função muscular periférica e respiratória, na perfusão e trocas gasosas pulmonares e na função ventricular direita, além da inibição da ativação da inflamação e da proliferação de células musculares lisas<sup>44</sup> .  
O exercício físico é notadamente benéfico para redução de sintomas, melhora da capacidade funcional e qualidade de vida, no entanto, permanece desconhecido como impactaria sobre a fisiopatologia da HAP ou da HPTEC<sup>38,47</sup> . Recentes revisões sistemáticas com meta-análises demostraram que o exercício supervisionado é seguro para pacientes com HPTEC ou HAP moderada (classes funcionais II e III OMS), sendo necessários mais ensaios clínicos para os pacientes com classe funcional IV<sup>37,38,45,46</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Pacientes com HP são suscetíveis ao desenvolvimento de pneumonia, sendo esta a causa de morte em 7% dos casos. Assim, os pacientes devem ser vacinados contra influenza e pneumonia pneumocócica e o cartão de vacinação deve ser mantido atualizado<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A HP é uma doença com impacto significativo sobre os aspectos emocionais, sociais, financeiros e espirituais dos pacientes e de suas famílias<sup>48,49</sup> . A depressão e a ansiedade são achados comuns nos pacientes com HP e estão relacionadas com dispneia importante e comprometimento marcado na qualidade de vida relacionada à saúde<sup>32,49</sup> .  
As equipes que acompanham esses pacientes devem ser capazes de reconhecer a necessidade de encaminhamento a profissionais como: psiquiatra, psicólogo clínico e assistente social. Ademais, incentivar os pacientes e seus familiares a participar de grupos de apoio pode ter efeitos positivos no enfrentamento da doença e nas perspectivas de sucesso do tratamento. Além do apoio psicológico e social, deve haver um planejamento proativo de atendimento avançado, com encaminhamento a serviços especializados de cuidados paliativos, quando apropriado<sup>17,18</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A restrição de sódio na dieta (menos de 2,4 g/dia) é aconselhada, especialmente nos pacientes com disfunção ventricular direita<sup>50</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Existe alta prevalência de lesões trombóticas vasculares no exame _post-mortem_ de pacientes com Hipertensão Arterial Pulmonar idiopática (HAPI), bem como alterações nas vias de coagulação e fibrinolítica<sup>51</sup> . Fatores de risco para o tromboembolismo venoso, como a insuficiência cardíaca e a imobilidade, constituem justificativa para a anticoagulação oral na HAP, embora ela não seja recomendada nas formas associadas de HAP. O tratamento com anticoagulante oral pode ser considerado em pacientes com HAPI, Hipertensão Arterial Pulmonar Hereditária (HAPH) e HAP pelo uso de anorexígenos, com o objetivo de manter o tempo de protrombina (razão normalizada internacional - RNI) entre 1,5 e 2,5<sup>17,52,53</sup> . Portanto, no grupo 1 a decisão sobre anticoagulação deve ser individualizada após análise de risco benefício<sup>37</sup> .  
Em pacientes com HPTEC, preconiza-se tratamento contínuo com anticoagulantes a partir da suspeita diagnóstica. O objetivo é a prevenção do tromboembolismo venoso recorrente e da trombose da artéria pulmonar _in situ_ . A anticoagulação deve ser mantida no período pós-operatório se o paciente for submetido à <mark>tromboendarterectomia pulmonar (</mark> TEAP), independentemente do seu sucesso, ou durante tratamento clínico, se o tratamento do paciente não envolver procedimento cirúrgico. A escolha do anticoagulante ainda é controversa, mas os antagonistas da vitamina K, como a varfarina, são os mais utilizados nas principais séries da literatura, com alvo terapêutico da RNI entre 2,0 e 3,0<sup>13</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Os diuréticos são preconizados para pacientes com sinais de descompensação de insuficiência cardíaca direita e retenção hídrica. Na ausência de estudos clínicos randomizados sobre o uso de diuréticos em HP, a experiência clínica mostra seus benefícios nos pacientes sintomáticos com sobrecarga hídrica, sendo a escolha do medicamento a critério do médico assistente<sup>17,37</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Embora tenha sido demonstrado que a administração de O2 reduz a resistência vascular pulmonar (RVP) em pacientes com HAP, não existem estudos clínicos randomizados que indiquem que a oxigenioterapia ao longo prazo seja benéfica. Entre os pacientes com HAPI, foram identificados benefícios da oxigenoterapia apenas naqueles com hipoxemia em repouso ou durante exercício. O uso da oxigenoterapia contínua está indicada na presença de PaO2 consistentemente menor ou igual a 60 mmHg ou SaO2 menor ou igual a 90%, em repouso. Durante o exercício, a suplementação de O2 deve ser oferecida para manter saturação acima de 88%-90%, se necessária, a fim de melhorar a capacidade ao exercício<sup>17,52</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A administração aguda de digitálicos em pacientes com HP, principalmente HAPI e disfunção ventricular direita, mostrou aumento da contratilidade ventricular e do débito cardíaco, porém sua efetividade ao longo prazo é desconhecida<sup>52,54</sup> . Não há dados robustos disponíveis sobre a utilidade e segurança de inibidores da enzima conversora de angiotensina, antagonista do receptor da angiotensina II, betabloqueadores ou ivabradina em pacientes com HP<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
A deficiência de ferro é comum em pacientes com HAP e foi relatada em 43% dos pacientes com HAPI. Dados preliminares indicam que a capacidade reduzida de exercício e o aumento da mortalidade estejam associados a deficiência de ferro, independentemente da presença ou da gravidade da anemia. O monitoramento regular da concentração de ferro e a correção da deficiência devem ser considerados em pacientes com HAP<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
O tratamento deve ser iniciado de acordo com o resultado do teste de vasorreatividade e da estratificação de risco<sup>17</sup> . A **Figura 3** estabelece o algoritmo preconizado para o tratamento medicamentoso da HAP, com o objetivo de atingir parâmetros de baixo risco.  
São três as vias fisiopatológicas alvo dos medicamentos atualmente disponíveis, além dos BCC: a via do óxido nítrico, a via da endotelina-1 e a via da prostaciclina<sup>17</sup> . As classes terapêuticas e os medicamentos preconizados por esse Protocolo são: BCC – nifedipino e anlodipino; os inibidores da fosfodiesterase 5 (PDE5i) – sildenafila; os antagonistas de receptor da endotelina 1 (ERA) – ambrisentana e bosentana; e o prostanoide – iloprosta.  
<mark>Embora o limiar de PAPm para diagnóstico de HP tenha sido recentemente reduzido para 20 mmHg,</mark> a maioria dos estudos realizados com esses fármacos em pacientes do grupo 1 utilizou os critérios hemodinâmicos prévios: PAPm maior que 25 mmHg. Portanto, a recomendação atual é que o tratamento deve ser iniciado sempre que a PAPm estiver igual ou acima de 25 mmHg e que, pacientes com PAPm entre 21 e 24 mmHg, devem ser cautelosamente monitorizados<sup>18</sup> . Deve-se atentar para a presença de acometimento venoso e capilar pulmonar significativo, como na doença venoclusiva e na hemangiomatose pulmonar, associados a pior prognóstico, à resposta limitada à terapia de HAP e ao risco de edema pulmonar com esses medicamentos<sup>55</sup> . Deve-se suspeitar desses diagnósticos em pacientes com HAP que apresentem: diminuição da capacidade de difusão do pulmão para monóxido de carbono (frequentemente menor que 50%), hipoxemia grave e presença de linhas septais, opacidades/nódulos em vidro fosco centrolobulares e aumento do linfonodo mediastinal na tomografia de tórax.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Pacientes virgens de tratamento, portadores de HAP idiopática, hereditária ou induzida por drogas ou toxinas e que apresentem teste de vasorreatividade pulmonar positivo devem ser tratados inicialmente com a maior dose de BCC (nifedipino ou anlodipino) tolerável pelo paciente<sup>17</sup> , e sua resposta terapêutica deve ser avaliada após 3 a 6 meses de tratamento. Se o paciente apresentar uma resposta adequada, definida pela presença de critérios de baixo risco na estratificação simplificada, deve ser mantida a monoterapia prolongada com BCC ( **Quadro 6** ). Caso não seja observada uma resposta sustentada ao tratamento com altas doses de BCC, estes pacientes devem ser tratados de acordo com as recomendações para pacientes com teste de vasorreatividade negativo ou para aqueles com outras etiologias de grupo 1, com medicamentos aprovados para HAP, de acordo com a estratificação de risco.  
A monoterapia inicial está indicada para alguns grupos específicos de HAP nos quais a relação eficácia e segurança da terapia combinada inicial não está estabelecida ( **Quadro 9** )<sup>20</sup> . Nesta população, como não há evidência oriunda de comparação direta entre os fármacos, não fica estabelecida qualquer monoterapia de primeira linha. A escolha do medicamento dependerá de fatores como perfil de eventos adversos, interação medicamentosa, comorbidades, disponibilidade e custo. Dentre os fármacos disponíveis para uso em monoterapia estão ambrisentana, bosentana, iloprosta, sildenafila ou selexipague. Deve-se seguir o escalonamento adequado conforme cada caso e a indicação em bula dos medicamentos. Por exemplo, a ambrisentana e o selexipague possuem indicação terapêutica aprovada apenas para usuários em CF II e III, conforme as suas bulas.  
**Quadro 9** - Indicações para uso de tratamento em monoterapia na hipertensão arterial pulmonar.  
|Pacientes com HAP-I, HAP-H ou HAP-D com teste de vasorreatividade pulmonar positivo em classe funcional I-II e resposta<br>hemodinâmica sustentada após 1 ano de BCC.|
|---|
|Pacientes com HAP que permanecem estáveis e estratificados com baixo risco após tratamento prolongado (>5-10 anos) com|
|monoterapia.|
|Paciente com HAP-I > 75 anos e com múltiplos fatores de risco para insuficiência cardíaca com FE preservada (hipertensão<br>arterial sistêmica, diabetes melito, doença arterial coronariana, fibrilação atrial, obesidade).|  
Pacientes com suspeita ou alta probabilidade de doença pulmonar venoclusiva ou hemangiomatose pulmonar capilar.  
Terapia combinada não disponível ou contraindicada (ex. doença hepática grave). Pacientes com doença muito leve (ex. CF-OMS I, RVP 3-4 WU, PAPm <30 mmHg, VD normal no ecocardiograma).  
Fonte: Modificada de Galie N. e colaboradores, 2019<sup>37</sup> . Abreviaturas – HAP: hipertensão arterial pulmonar; HAP-I: HAP idiopática; HAP-H: HAP hereditária; HAP-D: HAP induzida por drogas e toxinas; BCC: bloqueadores dos canais de cálcio; HIV: vírus da imunodeficiência humana; CF-OMS: classe funcional da Organização Mundial da Saúde; RVP: resistência vascular pulmonar; PAPm: pressão de artéria pulmonar média; VD: ventrículo direito.  
Para pacientes com risco baixo, o início de tratamento com terapia dupla combinada está destinado àqueles que são virgens de tratamento e que não preenchem os critérios para iniciar o tratamento em monoterapia. Para pacientes com risco intermediário, a terapia combinada é a indicada. Em ambos os casos, a terapia dupla preferencial deverá incluir um PDE5i (sildenafila) e um ERA (preferencialmente bosentana, o qual poderá ser substituído por ambrisentana). Na impossibilidade de utilização de um destes fármacos, iloprosta ou selexipague poderá ser utilizado.  
Em pacientes que não atingirem baixo risco com terapia combinada dupla, é aconselhado o uso de terapia tripla, utilizando sildenafila associado a ERA (bosentana ou ambrisentana) e, preferencialmente, selexipague. Caso haja restrição ao uso do selexipague, este deverá ser substituído por iloprosta. Pacientes de alto risco devem ser avaliados por equipe de transplante pulmonar e a inclusão ou permanência em lista dependerá da sua estratificação de risco subsequente ( **Quadro 10** ).  
**Quadro 10** - Indicações para uso de tratamento com terapia combinada dupla e tripla sequencial.  
|**Classe**<br>**funcional**|**Terapia combinada dupla**|**Terapia tripla**|
|---|---|---|
|II|Sildenafila + ambrisentana*|Ambrisentana + sildenafila + selexipague|
||Sildenafila + bosentana*|Bosentana + sildenafila + selexipague|
|III|Sildenafila + ambrisentana*|Ambrisentana + sildenafila + iloprosta|
||Sildenafila + bosentana*|Bosentana + sildenafila + iloprosta|
|||Ambrisentana + sildenafila + selexipague<br>Bosentana + sildenafila + selexipague|
|IV|Sildenafila + bosentana*|Sildenafila + bosentana + iloprosta|  
Fonte: Adaptado do Grupo de Trabalho Permanente Para Produção de Informações Técnicas<sup>56</sup> , 2022. * Na impossibilidade de utilização de um destes fármacos, iloprosta ou selexipague poderão ser utilizados.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Após 3 a 6 meses do início do tratamento, os pacientes devem ser novamente estratificados, utilizando a ferramenta simplificada do registro francês ( **Quadro 6** ) ou outr <mark>a ferramenta de estratificação de risco da preferência do médico</mark><sup>30</sup> . Os pacientes que apresentarem resposta terapêutica adequada e baixo risco nas reavaliações deverão manter a terapia e permanecer em acompanhamento regular.  
Quando mesmo em tratamento medicamentoso o paciente se enquadrar na classificação de risco intermediário ou alto, o tratamento deve ser escalonado: se estiver em monoterapia inicial, deve ir para terapia combinada dupla; se estiver em terapia combinada dupla, deve ir para terapia combinada tripla. A combinação tripla disponível inclui um PDE5i (sildenafila), um ERA (ambrisentana ou bosentana) e selexipague ou iloprosta. A utilização e indicação para acrescentar um terceiro medicamento necessita ser comprovada por estratificação de risco intermediário/alto, conforme **Figura 3** . Os pacientes também devem ser encaminhados para acompanhamento com a equipe de transplante de pulmão.  
Para os pacientes que evoluam ou mantenham a sua classificação de risco alto, o tratamento deve ser escalonado para terapia máxima combinada tripla, com priorização do transplante de pulmão. A persistência ou piora da classificação para risco  
intermediário ou alto deverá ser controlada com incremento para terapia dupla, tripla ou combinação máxima, dependendo do tratamento previamente utilizado.  
**Figura 3.** Algoritmo de tratamento de HAP.  
<!-- Start of picture text -->
| Paciente com HAP confirmada |<br>Teste de vasorreatividade<br>(se HAP hereditaria, iHAP idiopatica Medidas gerais<br>‘ou HAP induzida por drogas)<br>LT<br>torn] Negativo<br>Tratar com zs *<br>bloqueador4  do aecdo de risco<br>ona. (terapia incial)<br>Sim /Paciente manteve\, N&o Risco baixo | Risco intermedinio. | | Risco atto<br>resposta adequada 1 t 1<br>‘apés 3 a 6 meses?/ a ‘Terapia tripla<br>Manter —— Monoterapia‘combinada *- ouERA+ dupla combinadaTerapia dupla (ERA PDESieemlowene.+ selexipague<br>tratamento com PDESI +PDESN) Avaliacdo para<br>bloqueador do transplante|<br>canal de calcio<br>Re-eatratiicacdo de risco a cada 3 a6 meses<br>(terapia de acompanhamento)<br>| Risco baixo | Risco intermediario | Risco alto |<br>CF | oul E TC6M > 440 m | ee CFeTCéMeSheets<br>Manter a terapia e Acrescentar uma classe<br>Considerar parémetros Acrescentar uma classe<br>prognésticos disponiveis de medicamento Encaminharde medicamentoou mantere<br>(RM, ECO, TCPe Cate D) em lista de transplante<br>‘a - Critérios para monoterapia podem ser consultados no Quadro 'IndicacSes para monoterapia na hipertensdo arterial pulmonar’.<br><!-- End of picture text -->  
Fonte: Modificada de Galie N. e colaboradores 2015<sup>17,57</sup> . Abreviaturas – HAP: hipertensão arterial pulmonar; HAP-I: HAP idiopática; HAP-H: HAP hereditária; HAP-D: HAP induzida por drogas ou toxinas; BCC: bloqueadores dos canais de cálcio; CF: classe funcional; TC6M: teste de caminhada de 6 minutos; RM: ressonância magnética cardíaca; ECO: ecocardiograma; ERA: antagonistas de receptor da endotelina 1; PDE5i: inibidores da fosfodiesterase 5; TCP: teste de exercício cardiopulmonar; Cate D: cateterismo cardíaco direito.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
- Ambrisentana: comprimidos de 5 e 10 mg.  
- Anlodipino: comprimidos de 5 e 10 mg.  
- Bosentana: comprimidos de 62,5 e 125 mg.  
- Citrato de sildenafila: comprimidos de 20 mg.  
- Iloprosta: solução para nebulização contendo 10 mcg/mL.  
- Nifedipino: cápsula ou comprimidos de 10 mg.  
 Selexipague: comprimidos de 200 mcg, 400 mcg, 600 mcg, 800 mcg, 1.000 mcg, 1.200 mcg, 1.400 mcg ou 1.600 mcg  
Deve ser observado o escalonamento adequado dos fármacos disponíveis conforme o caso e a indicação. Por exemplo, a ambrisentana e o selexipague possuem indicação terapêutica aprovada apenas para usuários em CF II e III.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
**-** Ambrisentana: a dose inicial preconizada é de 5 mg/dia e, se bem tolerada, pode ser aumentada para 10 mg/dia. Caso o paciente também esteja em uso de ciclosporina, a dose deve ser limitada a 5 mg uma vez ao dia. Não é necessário ajuste de dose para idosos. O mínimo metabolismo e a excreção renal do fármaco tornam improvável a necessidade de ajuste em paciente com insuficiência renal. Inexistem estudos adequados e bem controlados sobre o uso de ambrisentana em mulheres grávidas e crianças. Seu uso está contraindicado na gravidez, em mulheres em idade fértil que não estão utilizando método contraceptivo seguro, em lactantes, em indivíduos com menos de 18 anos, em pacientes com concentrações de aminotransferases (ALT ou AST) aumentadas em mais de 3 vezes o limite superior do normal e em pacientes com insuficiência hepática grave.  
**-** Bloqueadores dos canais de cálcio (anlodipino e nifedipino): o nifedipino pode ser iniciado com 30 mg/dia, devendo a dose ser aumentada progressivamente até a maior dose tolerada (de 30 a 240 mg/dia), em duas administrações diárias. A dose inicial de anlodipino é de 5 mg, podendo ser aumentada até 20 mg/dia, em uma administração diária. As doses devem ser ajustadas conforme a tolerância do paciente, monitorando-se melhora clínica, pressão arterial sistêmica, frequência cardíaca, saturação de oxigênio e eventos adversos<sup>17</sup> .  
- Bosentana: a dose inicial preconizada é de 62,5 mg, duas vezes/dia, durante 4 semanas, aumentando posteriormente para 125 mg, duas vezes/dia, como dose de manutenção. A posologia para pacientes com peso corpóreo abaixo de 40 kg deve seguir a orientação pediátrica. Não é necessário ajuste de dose para pacientes idosos ou com insuficiência renal, em hemodiálise ou com insuficiência hepática leve (Child-Pugh classe A). O uso de bosentana deve ser evitado em pacientes com insuficiência hepática moderada ou grave (Child-Pugh classe B ou C). Em pacientes entre 3 a 15 anos de idade, a dose deve ser calculada considerando seu peso: entre 10 e 20 kg, a dose inicial deve ser de 31,25 mg, uma vez/dia, e a de manutenção de 31,25 mg, duas vezes/dia; entre 21 e 40 kg, a dose inicial deve ser de 31,25 mg, duas vezes/dia, e a de manutenção de 62,5 mg, duas vezes/dia; acima de 40 kg, a dose inicial deve ser de 62,5 mg, duas vezes/dia, e a de manutenção de 125 mg, duas vezes/dia.  
- Iloprosta: a dose inicial preconizada é de 2,5 mcg por nebulização, podendo ser aumentada para 5 mcg, de acordo com a necessidade e a tolerabilidade individual. Em decorrência da curta meia-vida, deve ser administrado em nebulizações de 6 a 9 vezes/dia. A dose máxima é de 45 mcg/dia (9 ampolas/dia). Os nebulizadores utilizados nos estudos clínicos da iloprosta não são comercializados no Brasil. Assim, deve-se usar nebulizador ultrassônico e com aplicador bucal, visto que o medicamento não deve entrar em contato com a pele e os olhos. A eliminação de iloprosta é reduzida em pacientes com disfunção hepática e, nessa situação, deverão ser administradas doses de 2,5 mcg, com intervalos de pelo menos 3 a 4 horas (máximo de 6 nebulizações ao dia). A redução dos intervalos e o aumento da dose poderão ser realizados com precaução, com base na tolerabilidade individual. Não há necessidade de adaptar a dose para pacientes com depuração de creatinina acima de 30 mL/min. Para pacientes com depuração inferior a 30 mL/min, recomenda-se seguir a orientação para o tratamento da insuficiência hepática.  
- Selexipague: a dose inicial preconizada é de 200 mcg a cada 12 horas. A dose deve ser aumentada em 200 mcg, administrados duas vezes ao dia, até que o paciente apresente eventos adversos que não possam mais ser tolerados ou medicamente gerenciados ou até que a dose máxima de 1.600 mcg duas vezes ao dia seja atingida. O incremento da dose geralmente ocorre em intervalos semanais. Durante o ajuste de dose, recomenda-se não interromper o tratamento no caso de eventos adversos esperados uma vez que, geralmente, são transitórios ou gerenciáveis com tratamento sintomático. Se o paciente atingir uma dose que não pode mais ser tolerada, a dose deve ser reduzida para o nível anterior. O objetivo é atingir uma dose individualizada adequada para cada paciente (dose de manutenção individualizada). Quando o paciente também utiliza  
medicamentos que inibem moderadamente a CYP2C8 (como clopidogrel, deferasirox e teriflunomida), deve-se reduzir a dose para uma vez ao dia e retornar à frequência de dose de duas vezes ao dia quando o uso de medicamentos inibidores da CYP2C8 for interrompido.  
- Citrato de sildenafila: a dose inicial preconizada para adultos é de 60 mg/dia, em três administrações de 20 mg. Muitos estudos utilizaram doses maiores, sendo a máxima de 240 mg/dia em três administrações de 80 mg<sup>58</sup> . Em pacientes de 1 a 17 anos de idade, a dose preconizada depende do peso: até 20 kg, 10 mg, três vezes/dia; acima de 20 kg, 20 mg, três vezes/dia, sendo a dose máxima de 60 mg, três vezes/dia<sup>59,60</sup> . Não é necessário ajuste de dose para idosos ou para pacientes com insuficiência renal. Inexistem estudos adequados e bem controlados do uso de sildenafila em gestantes.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
O tempo de tratamento não pode ser pré-determinado, dependendo da tolerabilidade e da estratificação de risco do paciente, durante sua monitorização e acompanhamento.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Os benefícios esperados do tratamento medicamentoso da HAP são a melhora da capacidade de exercício, da classe funcional e dos parâmetros hemodinâmicos (redução da pressão da artéria pulmonar, aumento do índice cardíaco e diminuição da resistência vascular pulmonar)<sup>17</sup> .

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Os pacientes com HAP devem ser submetidos à avaliação clínica periódica com equipe de serviço especializado ou de centro de referência (pneumologistas, cardiologistas e reumatologistas, quando necessário) a cada 3 a 6 meses.  
A indicação do cateterismo cardíaco direito na re-estratificação deve ficar a critério do centro de referência e do médico assistente e deve ser utilizada quando as outras medidas de estratificação de risco não forem possíveis de avaliar. Como, por exemplo, casos em que o paciente piorou em um ou dois critérios, mas não está apto para fazer o teste de caminhada de seis minutos porque está com uma fratura no pé. A recomendação é a de que seja utilizada a ferramenta simplificada do registro francês ou outra ferramenta <mark>de estratificação de risco da preferência do médico</mark> para a re-estratificação de risco a cada avaliação ( **Quadro 6** ).  
A monitorização da resposta clínica dos pacientes deverá incluir, ainda, avaliação de eventos adversos relacionados ao uso dos medicamentos, especialmente quando em uso combinado.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
- Ambrisentana: os eventos adversos mais comuns são anemia, cefaleia, palpitações, rubor, congestão nasal, sinusite, nasofaringite, dor abdominal, constipação, retenção hídrica e edema periférico. Preconiza-se controle das enzimas hepáticas antes do início do tratamento, mensalmente no primeiro ano e, após, trimestralmente. O uso de ambrisentana não é preconizado se os níveis séricos de aminotransferases estiverem 3 vezes acima do limite superior da normalidade. Em caso de elevações significativas ou se as elevações forem acompanhadas por sinais ou sintomas de lesão hepática, a terapia deve ser suspensa. Preconiza-se a avaliação de anemia antes do início do tratamento, mensalmente durante os 4 primeiros meses e, após, a cada 3 meses.  
- Bloqueadores dos canais de cálcio (anlodipino e nifedipino): os eventos adversos mais comuns são edema, cefaleia, náusea, tontura, astenia, reações cutâneas, distúrbio gastrointestinal, bloqueio atrioventricular e bradicardia; as menos frequentes, _flush_ facial, hipotensão clinicamente significativa, arritmia, insuficiência cardíaca, parestesia, sonolência, tremor, poliúria, nictúria, anorexia, vômitos, aumento de peso, petéquias, prurido, fotossensibilidade e urticária. Não é necessária monitorização  
laboratorial, apenas controle da pressão arterial sistêmica e da frequência cardíaca.  
- Bosentana: os eventos adversos mais comuns são alteração da função hepática, nasofaringite, rubor, edema de membros inferiores, hipotensão, palpitação, dispepsia, fadiga e prurido; os menos frequentes são anemia, refluxo gastroesofágico e hemorragia retal. A metabolização pelas isoenzimas do citocromo P-450 faz com que a bosentana interfira na farmacodinâmica da varfarina e contraceptivos hormonais. Preoconiza-se a intensificação da monitorização do RNI, especialmente durante o início do tratamento e o período de aumento da dose, e adoção de método contraceptivo adicional de barreira para mulheres em idade fértil. Preconiza-se controle das enzimas hepáticas antes do início do tratamento, mensalmente no primeiro ano e, após, trimestralmente. O uso não é preconizado se os níveis séricos das aminotransferases estiverem 3 vezes acima do limite superior da normalidade. Frente a alterações persistentes ou progressivas dos níveis séricos das aminotransferases, pode-se inicialmente reduzir a dose diária de bosentana e, caso não haja melhora, o seu uso deve ser interrompido. Preconiza-se a avaliação de anemia antes do início do tratamento, mensalmente durante os 4 primeiros meses e, após, a cada 3 meses.  
- Iloprosta: os eventos adversos mais comuns são rubor por vasodilatação, cefaleia, dor mandibular, trismo, aumento da tosse e insônia. Eventos adversos sérios, relatados em menos de 3% dos pacientes, incluíram insuficiência cardíaca congestiva, dor torácica, taquicardia supraventricular, dispneia, edema periférico e insuficiência renal. Esse medicamento é bem tolerado e não obriga a realização de acompanhamento laboratorial. Os sinais vitais devem ser monitorizados quando se inicia o tratamento. Em pacientes com pressão arterial sistólica inferior a 85 mmHg, a administração do medicamento deve ser interrompida imediatamente se houver sinais de edema pulmonar.  
- Selexipague: os eventos adversos mais comuns são cefaleia, diarreia, náusea e vômito, dor na mandíbula, mialgia, dor nas extremidades, rubor e artralgia. Estas reações são mais frequentes durante a fase de ajuste de dose. A maioria destas reações é de intensidade leve a moderada. Os eventos adversos associados ao mecanismo de ação de selexipague foram observados com frequência, em particular durante a fase de titulação de dose individualizada, e incluem: cefaleia, diarreia, náusea, dor na mandíbula, mialgia, dor nas extremidades, vômito, rubor e artralgia. Estes eventos geralmente são transitórios ou minimizados com tratamento sintomático. Se, no decorrer do tempo, o tratamento com a dose de manutenção definida pelo médico assistente tornar-se menos tolerável, deve ser considerado tratamento sintomático ou redução da dose para o próximo nível mais baixo.  
- Citrato de sildenafila: os eventos adversos mais comuns são cefaleia, rubor, dispepsia, diarreia e dor nos membros. Já os menos frequentes são insônia, distúrbios visuais, visão turva, tosse, epistaxe e congestão nasal. Não é necessária monitorização laboratorial, apenas controle de alterações retinianas e de sinais de neuropatia periférica.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Devem ser observados os critérios de inclusão e exclusão de pacientes deste PCDT, a duração e a monitorização do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso de medicamentos.  
Casos de hipertensão pulmonar devem ser atendidos em hospitais habilitados em Pneumologia e com porte tecnológico suficiente para diagnosticar, estadiar, tratar e acompanhar os pacientes. Além da familiaridade que tais hospitais guardam com o estadiamento, tratamento e controle de eventos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A adesão aos medicamentos e sua correta utilização devem ser monitoradas pelos serviços de assistência farmacêutica, a fim de contribuir com a melhoria no tratamento, promovendo a qualidade do uso dos medicamentos, evitando-se o desperdício dos recursos terapêuticos e preconizando trocas e interrupções, quando adequado.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04) e de transplantes (Grupo 05 e seus seis subgrupos) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.  
**11. REFERÊNCIAS**  
1. Humbert M. Pulmonary arterial hypertension and chronic thromboembolic pulmonary hypertension: pathophysiology. Eur Respir Rev 2010;19:59-63.  
2. Alves JL, Jr., Oleas FG, Souza R. Pulmonary Hypertension: Definition, Classification, and Diagnosis. Semin Respir Crit Care Med 2017;38:561-70.  
3. Hoeper MM, Humbert M, Souza R, Idrees M, Kawut SM, Sliwa-Hahnle K, et al. A global view of pulmonary hypertension. Lancet Respir Med. 2016;4(4):306-22.  
4. D'Alonzo GE, Barst RJ, Ayres SM, et al. Survival in patients with primary pulmonary hypertension. Results from a national prospective registry. Ann Intern Med 1991;115:343-9.  
5. Rich S, Dantzker DR, Ayres SM, et al. Primary pulmonary hypertension. A national prospective study. Ann Intern Med 1987;107:216-23.  
6. ACCP. Consensus statement: primary pulmonary hypertension. Chest 1993;104.  
7. Simonneau G, Montani D, Celermajer DS, et al. Haemodynamic definitions and updated clinical classification of pulmonary hypertension. Eur Respir J 2019;53.  
8. Rosenzweig EB, Abman SH, Adatia I, et al. Paediatric pulmonary arterial hypertension: updates on definition, classification, diagnostics and management. Eur Respir J 2019;53.  
9. Gavilanes F, Alves JL, Jr., Fernandes C, et al. Left ventricular dysfunction in patients with suspected pulmonary arterial hypertension. J Bras Pneumol 2014;40:609-16.  
10. Naeije R, Vachiery JL, Yerly P, Vanderpool R. The transpulmonary pressure gradient for the diagnosis of pulmonary vascular disease. Eur Respir J 2013;41:217-23.  
11. Vachiery JL, Tedford RJ, Rosenkranz S, et al. Pulmonary hypertension due to left heart disease. Eur Respir J 2019;53.  
12. Nathan SD, Barbera JA, Gaine SP, et al. Pulmonary hypertension in chronic lung disease and hypoxia. Eur Respir J 2019;53.  
13. Kim NH, Delcroix M, Jais X, et al. Chronic thromboembolic pulmonary hypertension. Eur Respir J 2019;53.  
14. Channick RN, Simonneau G, Sitbon O, et al. Effects of the dual endothelin-receptor antagonist bosentan in patients with pulmonary hypertension: a randomised placebo-controlled study. Lancet 2001;358:1119-23.  
15. Barst RJ, Mubarak KK, Machado RF, et al. Exercise capacity and haemodynamics in patients with sickle cell disease with pulmonary hypertension treated with bosentan: results of the ASSET studies. Br J Haematol 2010;149:426-35.  
16. BRASIL. Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT). Departamento de Gestão e Incorporação de Tecnologias e Inovações em Saúde (DGITS). Manual de Atividades do Grupo Elaborador de PCDT. 2020:27 p.  
17. Galie N, Humbert M, Vachiery JL, et al. 2015 ESC/ERS Guidelines for the diagnosis and treatment of pulmonary hypertension: The Joint Task Force for the Diagnosis and Treatment of Pulmonary Hypertension of the European Society of Cardiology (ESC) and the European Respiratory Society (ERS): Endorsed by: Association for European Paediatric and Congenital Cardiology (AEPC), International Society for Heart and Lung Transplantation (ISHLT). Eur Respir J 2015;46:90375.  
18. Galie N, McLaughlin VV, Rubin LJ, Simonneau G. An overview of the 6th World Symposium on Pulmonary Hypertension. Eur Respir J 2019;53.  
19. Sahay S. Evaluation and classification of pulmonary arterial hypertension. J Thorac Dis 2019;11:S1789-S99.  
20. Altschul E, Remy-Jardin M, Machnicki S, et al. Imaging of Pulmonary Hypertension: Pictorial Essay. Chest 2019;156:211-27.  
21. Hoette S, Jardim C, Souza R. Diagnosis and treatment of pulmonary hypertension: an update. J Bras Pneumol 2010;36:795-811.  
22. Frost A, Badesch D, Gibbs JSR, et al. Diagnosis of pulmonary hypertension. Eur Respir J 2019;53.  
23. Hoeper MM, Humbert M, Souza R, et al. A global view of pulmonary hypertension. Lancet Respir Med 2016;4:306-22.  
24. Tunariu N, Gibbs SJ, Win Z, et al. Ventilation-perfusion scintigraphy is more sensitive than multidetector CTPA in detecting chronic thromboembolic pulmonary disease as a treatable cause of pulmonary hypertension. J Nucl Med 2007;48:6804.  
25. Hoeper MM, Lee SH, Voswinckel R, et al. Complications of right heart catheterization procedures in patients with pulmonary hypertension in experienced centers. J Am Coll Cardiol 2006;48:2546-52.  
26. Mandras SA, Mehta HS, Vaidya A. Pulmonary Hypertension: A Brief Guide for Clinicians. Mayo Clin Proc 2020;95:1978-88.  
27. Benza RL, Gomberg-Maitland M, Elliott CG, et al. Predicting Survival in Patients With Pulmonary Arterial Hypertension: The REVEAL Risk Score Calculator 2.0 and Comparison With ESC/ERS-Based Risk Assessment Strategies. Chest 2019;156:323-37.  
28. Kylhammar D, Kjellstrom B, Hjalmarsson C, et al. A comprehensive risk stratification at early follow-up determines prognosis in pulmonary arterial hypertension. Eur Heart J 2018;39:4175-81.  
29. Hoeper MM, Kramer T, Pan Z, et al. Mortality in pulmonary arterial hypertension: prediction by the 2015 European pulmonary hypertension guidelines risk stratification model. Eur Respir J 2017;50.  
30. Boucly A, Weatherald J, Savale L, et al. Risk assessment, prognosis and guideline implementation in pulmonary arterial hypertension. Eur Respir J 2017;50.  
31. Sandqvist A, Kylhammar D, Bartfay SE, et al. Risk stratification in chronic thromboembolic pulmonary hypertension predicts survival. Scand Cardiovasc J 2021;55:43-9.  
32. Pfeuffer E, Krannich H, Halank M, et al. Anxiety, Depression, and Health-Related QOL in Patients Diagnosed with PAH or CTEPH. Lung 2017;195:759-68.  
33. Takita Y, Takeda Y, Fujisawa D, Kataoka M, Kawakami T, Doorenbos AZ. Depression, anxiety and psychological distress in patients with pulmonary hypertension: a mixed-methods study. BMJ Open Respir Res 2021;8.  
34. McMurray JJ, Adamopoulos S, Anker SD, et al. ESC Guidelines for the diagnosis and treatment of acute and chronic heart failure 2012: The Task Force for the Diagnosis and Treatment of Acute and Chronic Heart Failure 2012 of the European Society of Cardiology. Developed in collaboration with the Heart Failure Association (HFA) of the ESC. Eur Heart J 2012;33:1787-847.  
35. Weitzenblum E, Sautegeau A, Ehrhart M, Mammosser M, Pelletier A. Long-term oxygen therapy can reverse the progression of pulmonary hypertension in patients with chronic obstructive pulmonary disease. Am Rev Respir Dis 1985;131:493-8.  
36. Meyer S, McLaughlin VV, Seyfarth HJ, et al. Outcomes of noncardiac, nonobstetric surgery in patients with PAH: an international prospective survey. Eur Respir J 2013;41:1302-7.  
37. Galie N, Channick RN, Frantz RP, et al. Risk stratification and medical therapy of pulmonary arterial hypertension. Eur Respir J 2019;53.  
38. Morris NR, Kermeen FD, Holland AE. Exercise-based rehabilitation programmes for pulmonary hypertension. Cochrane Database Syst Rev 2017;1:CD011285.  
39. Grunig E, MacKenzie A, Peacock AJ, et al. Standardized exercise training is feasible, safe, and effective in pulmonary arterial and chronic thromboembolic pulmonary hypertension: results from a large European multicentre randomized controlled trial. Eur Heart J 2021;42:2284-95.  
40. Mereles D, Ehlken N, Kreuscher S, et al. Exercise and respiratory training improve exercise capacity and quality of life in patients with severe chronic pulmonary hypertension. Circulation 2006;114:1482-9.  
41. Sehgal S, Chowdhury A, Rabih F, et al. Counting Steps: A New Way to Monitor Patients with Pulmonary Arterial Hypertension. Lung 2019;197:501-8.  
42. Babu AS, Holland AE, Morris NR. Exercise-Based Rehabilitation to Improve Exercise Capacity and Quality of Life in Pulmonary Arterial Hypertension. Phys Ther 2019;99:1126-31.  
43. Buys R, Avila A, Cornelissen VA. Exercise training improves physical fitness in patients with pulmonary arterial hypertension: a systematic review and meta-analysis of controlled trials. BMC Pulm Med 2015;15:40.  
44. Benjamin N, Marra AM, Eichstaedt C, Grunig E. Exercise Training and Rehabilitation in Pulmonary Hypertension. Heart Fail Clin 2018;14:425-30.  
45. Grunig E, Eichstaedt C, Barbera JA, et al. ERS statement on exercise training and rehabilitation in patients with severe chronic pulmonary hypertension. Eur Respir J 2019;53.  
46. Pandey A, Garg S, Khunger M, et al. Efficacy and Safety of Exercise Training in Chronic Pulmonary Hypertension: Systematic Review and Meta-Analysis. Circ Heart Fail 2015;8:1032-43.  
47. Santos-Lozano A, Fiuza-Luces C, Fernandez-Moreno D, et al. Exercise Benefits in Pulmonary Hypertension. J Am Coll Cardiol 2019;73:2906-7.  
48. Guillevin L, Armstrong I, Aldrighetti R, et al. Understanding the impact of pulmonary arterial hypertension on patients' and carers' lives. Eur Respir Rev 2013;22:535-42.  
49. Somaini G, Hasler ED, Saxer S, et al. Prevalence of Anxiety and Depression in Pulmonary Hypertension and Changes during Therapy. Respiration 2016;91:359-66.  
50. Stickel S, Gin-Sing W, Wagenaar M, Gibbs JSR. The practical management of fluid retention in adults with right heart failure due to pulmonary arterial hypertension. Eur Heart J Suppl 2019;21:K46-K53.  
51. Fuster V, Steele PM, Edwards WD, Gersh BJ, McGoon MD, Frye RL. Primary pulmonary hypertension: natural history and the importance of thrombosis. Circulation 1984;70:580-7.  
52. Thenappan T, Ormiston ML, Ryan JJ, Archer SL. Pulmonary arterial hypertension: pathogenesis and clinical management. BMJ 2018;360:j5492.  
53. Olsson KM, Delcroix M, Ghofrani HA, et al. Anticoagulation and survival in pulmonary arterial hypertension: results from the Comparative, Prospective Registry of Newly Initiated Therapies for Pulmonary Hypertension (COMPERA). Circulation 2014;129:57-65.  
54. Rich S, Seidlitz M, Dodin E, et al. The short-term effects of digoxin in patients with right ventricular dysfunction from pulmonary hypertension. Chest 1998;114:787-92.  
55. Montani D, Girerd B, Jais X, et al. Clinical phenotypes and outcomes of heritable and sporadic pulmonary veno-occlusive disease: a population-based study. Lancet Respir Med 2017;5:125-34.  
56. Secretaria de Estado da Saúde de Santa Catarina. Protocolo Estadual para Tratamento Farmacológico da Hipertensão Arterial Pulmonar no Âmbito do SUS em Santa Catarina complementar ao Protocolo Clínico e Diretrizes Terapêuticas do  
Ministério da Saúde. 2022. at <u>https://www.saude.sc.gov.br/index.php/informacoes-gerais-documentos/assistenciafarmaceutica/componente-especializado-da-assistencia-farmaceutica-ceaf/protocolos-clinicos-ter-resumos-eformularios/hipertensao-arterial-pulmonar/20398-protocolo-estadual-de-hipertensao-arterial-pulmonar-hap/file.)</u>  
57. Fernandes CJ, Calderaro D, Assad APL, et al. Update on the Treatment of Pulmonary Arterial Hypertension. Arq Bras Cardiol 2021;117:750-64  
58. Galiè N, Ghofrani HA, Torbicki A, et al. Sildenafil citrate therapy for pulmonary arterial hypertension. New England Journal of Medicine 2005;353:2148-57.  
59. Barst RJ, Ivy DD, Gaitan G, et al. A randomized, double-blind, placebo-controlled, dose-ranging study of oral sildenafil citrate in treatment-naive children with pulmonary arterial hypertension. Circulation 2012;125:324-34.  
60. Barst RJ, Beghetti M, Pulido T, et al. STARTS-2: long-term survival with oral sildenafil monotherapy in treatment-naive pediatric pulmonary arterial hypertension. Circulation 2014;129:1914-23.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: Geral -->
AMBRISENTANA, ANLODIPINO, BOSENTANA, ILOPROSTA, NIFEDIPINO, SILDENAFILA E SELEXIPAGUE  
Eu, ______________________________________________________________________________________ (nome  
do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso dos medicamentos ambrisentana, anlodipino, bosentana, iloprosta, nifedipino, sildenafila e selexipague indicados para o tratamento da hipertensão arterial pulmonar.  
Os termos médicos foram explicados e todas as dúvidas foram resolvidas pelo(a) médico(a) _______________________________________________________________________________________________ (nome  
do(a) médico(a) que prescreve).  
Assim, declaro que:  
Fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhora na capacidade de exercício;  
- diminuição da pressão da artéria do pulmão;  
- melhora da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
• não se sabe ao certo os riscos do uso de anlodipino, sildenafila, iloprosta, ambrisentana, bosentana e selexipague na gravidez, portanto, caso engravide, devo avisar imediatamente ao meu médico; o nifedipino é contraindicado antes da 20ª semana de gravidez e lactante.  
- eventos adversos mais comuns do anlodipino: dores de cabeça, tontura, sonolência, palpitações, rubor, dor abdominal,  
- náusea, edema e fadiga.  
- eventos adversos mais comuns do nifedipino: dor de cabeça, inchaço, dilatação dos vasos sanguíneos, prisão de ventre  
- e mal-estar geral.  
- eventos adversos mais comuns da sildenafila: vermelhidão, dores de cabeça, dificuldade de digestão, diarreia e dor em  
- braços e pernas, gripe, febre, tosse, visão turva e dificuldade para dormir;  
• eventos adversos mais comuns da iloprosta: vasodilatação, dores de cabeça, tosse e insônia; eventos adversos sérios: dor no peito (uma taxa de menos de 3%), aumento dos batimentos cardíacos, falta de ar, inchaço em braços e pernas e problemas nos rins;  
• eventos adversos mais comuns da ambrisentana: anemia (diminuição de hemoglobina ou do hematócrito), cefaleia, palpitações, rubor, congestão nasal, sinusite, nasofaringite (a incidência de congestão nasal foi relacionada à dose durante o tratamento), dor abdominal, constipação, retenção hídrica e edema periférico;  
- eventos adversos mais comuns da bosentana: alteração da função hepática, nasofaringite, rubor, edema de membros  
- inferiores, hipotensão, palpitação, dispepsia, fadiga e prurido;  
- riscos de eventos adversos potencialmente graves com o uso de combinação de medicamentos para o tratamento da  
- hipertensão arterial pulmonar ainda não foram adequadamente avaliados.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- ( ) Sim ( ) Não  
Meu tratamento constará do(s) seguinte(s) medicamento(s):  
<!-- Start of picture text -->
( ) ambrisentana  ( ) anlodipino<br>( ) bosentana  ( ) iloprosta<br>( ) nifedipino  ( ) sildenafila<br>( ) selexipague<br>Local:  Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>______________________________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>______________________________________________________<br>Assinatura e carimbo do médico<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
Depois da publicação da Portaria Conjunta SAES-SECTICS/MS nº 10/2023, a qual aprovou a atualização do Protocolo Clínico e Diretrizes Terapêuticas da Hipertensão Pulmonar, a Coordenação Geral do Componente Especializado da Assistência Farmacêutica verificou a necessidade de incluir esclarecimentos sobre a possibilidade de redução da dose de manutenção do medicamento selixipague. Assim, foi incluído o parágrafo “Se, no decorrer do tempo, o tratamento com a dose de manutenção definida pelo médico assistente tornar-se menos tolerável, deve ser considerado tratamento sintomático ou redução da dose para o próximo nível mais baixo” na seção Monitoramento de eventos adversos.  
O tema foi apresentado como informe à 119ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 17/09/2023 e aprovado pelos membros presentes.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Hipertensão Pulmonar teve início com reunião presencial para delimitação do escopo do PCDT. Esta reunião foi composta por membros do Grupo Elaborador, especialistas e metodologistas e representantes do Comitê Gestor. Inicialmente, foram detalhadas e explicadas questões referentes ao desenvolvimento do PCDT, sendo definida a macroestrutura do Protocolo, embasado no disposto em Portaria SAS/MS n° 375, de 10 de novembro de 2009, e na Diretriz de Elaboração de Diretrizes Clínicas do Ministério da Saúde<sup>1</sup> , sendo as seções do documento definidas.  
Posteriormente, cada seção foi detalhada e discutida entre os participantes, com o objetivo de identificar tecnologias que seriam consideradas nas recomendações. Após a identificação de tecnologias já disponibilizadas no SUS, novas tecnologias puderam ser identificadas. Deste modo, o grupo de especialistas foi orientado a elencar questões de pesquisa, que foram estruturadas segundo o acrônimo PICO, para qualquer tecnologia não incorporada ao SUS ou em casos de dúvida clínica. Para o caso dos medicamentos, foram considerados apenas aqueles que tivessem registro na Agência Nacional de Vigilância Sanitária (Anvisa) e indicação do uso em bula, além de constar na tabela da Câmara de Regulação do Mercado de Medicamentos (CMED). Não houve restrição ao número de perguntas de pesquisa durante a condução desta reunião. Estabeleceu-se que recomendações diagnósticas, de tratamento ou acompanhamento que envolvessem tecnologias já incorporadas ao SUS não teriam questões de pesquisa definidas, por se tratar de prática clínica já estabelecida, à exceção de casos de incertezas sobre o uso, casos de desuso ou possibilidade de desincorporação.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
O grupo elaborador deste PCDT foi composto por um painel de especialistas e metodologistas sob coordenação do DGITS. Todos os participantes externos ao Ministério da Saúde assinaram um formulário de Declaração de Conflitos de Interesse e confidencialidade.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
A versão preliminar do texto foi pautada na 104ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, que ocorreu em 22 de novembro de 2022. Participaram desta reunião representantes da Secretaria de Atenção Especializada à Saúde (SAES/MS), da Secretaria de Vigilância em Saúde (SVS/MS), da Secretaria de Atenção Primária à Saúde (SAPS/MS), da Secretaria Especial de Saúde Indígena (SESAI/MS), da Secretaria de Ciência e Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE): do Departamento de Gestão e Incorporação de Tecnologias  
em Saúde (DGITS/SCTIE/MS), do Departamento de Ciência e Tecnologia (DECIT/SCTIE/MS) e do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS). Os membros da Subcomissão presentes na reunião recomendaram pautar a apreciação do documento na Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (Conitec).

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
A Consulta Pública nº 95/2022, do Protocolo Clínico e Diretrizes Terapêuticas de Hipertensão Pulmonar, foi realizada entre os dias 14/12/2022 e 02/01/2023. Foram recebidas 346 contribuições, que podem ser verificadas em: https://www.gov.br/conitec/pt-br/midias/consultas/contribuicoes/2022/cp_conitec_095_2022_protocolo_clinico_e.pdf

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
Este PCDT foi desenvolvido seguindo as orientações da Diretriz Metodológica de Elaboração de Diretrizes Clínicas do Ministério da Saúde. As perguntas de pesquisa foram estruturadas segundo o acrônimo PICO ( **Figura 1** ). Durante a reunião de escopo deste PCDT, três questões de pesquisa foram elaboradas ( **Quadro A** ):  
**Figura 1 -** Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
<!-- Start of picture text -->
•População ou condição clínica<br>P<br>•Intervenção, no caso de estudos experimentais<br>•Fator de exposição, em caso de estudos<br>observacionais<br>I<br>•Teste índice, nos casos de estudos de acurácia<br>diagnóstica<br>C •Controle, de acordo com tratamento/níveis de exposição do fator/exames disponíveis no SUS<br>O •Desfechos: sempre que possível, definidos a priori, de acordo com sua importância<br><!-- End of picture text -->  
<!-- Start of picture text -->
.<br><!-- End of picture text -->  
**Quadro A** - Questões PICO elencadas durante a reunião de escopo para elaboração do PCDT.  
|**PICO**|**Pergunta**|
|---|---|
|1|População: pacientes com HAP com risco baixo ou intermediário.<br>Intervenção: sildenafila + bosentana ou ambrisentana.<br>Comparador: sildenafila 60 mg.<br>Desfechos: piora da classe funcional com piora do teste de caminhada de 6M, hospitalização, mortalidade, sobrevida<br>livre de transplante.|
||População: pacientes com HAP com risco intermediário sem resposta (estável em intermediário).<br>Intervenção: sildenafila + (bosentana ou ambrisentana) + (iloprosta ou selexipague).|
|2|Comparador: sildenafila + bosentana ou ambrisentana (em alta dose da sildenafila).<br>Desfechos: piora da classe funcional com piora do teste de caminhada de 6M, hospitalização, mortalidade, sobrevida<br>livre de transplante.|
|3|População: pacientes com HAP com alto risco.|  
|**PICO**|**Pergunta**|
|---|---|
||Intervenção: sildenafila + (bosentana ou ambrisentana) + (iloprosta).|
||Comparador: sildenafila + bosentana ou ambrisentana (em alta dose da sildenafila).|
||Desfechos: piora da classe funcional com piora do teste de caminhada de 6M, hospitalização, mortalidade, sobrevida<br>livre de transplante.|  
Durante a síntese de evidências, foi demandada ao Plenário da Conitec a avaliação de incorporação do medicamento selexipague, culminando na incorporação desse medicamento. Assim, o Relatório de Recomendação nº 645, de julho de 2021, teve como objetivo analisar as evidências científicas apresentadas pelo demandante Janssen-Cilag sobre eficácia, segurança, custo-efetividade e impacto orçamentário do selexipague, para pacientes adultos com hipertensão arterial pulmonar (HAP – grupo I) em classe funcional III que não alcançaram resposta satisfatória com ERA ou PDE5i, como alternativa a iloprosta, visando avaliar a sua incorporação no Sistema Único de Saúde (SUS). A Portaria SCTIE/MS nº 53, de 6 de agosto de 2021, incorporou, no âmbito do SUS, o selexipague para pacientes adultos com hipertensão arterial pulmonar (HAP - Grupo I) em classe funcional III que não alcançaram resposta satisfatória com ERA ou PDE5i, como alternativa a iloprosta, conforme protocolo estabelecido pelo Ministério da Saúde. O respectivo relatório pode ser acessado na íntegra por meio do link: <u>https://www.gov.br/conitec/pt-br/midias/relatorios/2021/20210809_relatorio_642_selexipague_p53.pdf</u>  
Devido à incorporação da terapia dupla ou tripla com selexipague ou iloprosta, foi necessário atualizar as perguntas PICO previamente definidas. A nova pergunta de pesquisa elencada para a atualização do PCDT envolveu a comparação de monoterapias e terapias duplas, as quais não haviam sido avaliadas anteriormente ( **Quadro B** ).  
O relatório técnico final contém os métodos e resultados do parecer técnico-científico, avaliação econômica e análise de impacto orçamentário englobando as três questões de pesquisa, os quais subsidiaram a recomendação final da Conitec.  
**Quadro B** - Nova questão PICO elencada para elaboração do PCDT.  
|**Pergunta**|**Relatório técnico final**|
|---|---|
|Qual a eficácia, efetividade e a segurança dos|Brasil / Ministério da Saúde. Ambrisentana, bosentana, iloprosta,|
|tratamentos em monoterapia ou terapia|selexipague e sildenafila para o tratamento de pacientes com hipertensão|
|combinada da sildenafila, bosentana,|arterial pulmonar. 2022. Nº 730. Disponível em:|
|ambrisentana, ilopostra, selexipague em|https://www.gov.br/conitec/pt-|
|comparação à sildenafila em monoterapia para|br/midias/relatorios/2022/20220603_relatorio_730_sildenafila_bosentan|
|pacientes com hipertensão arterial pulmonar?|a_ambrisentana_ilopostra_selexipague_riociguate_hap.pdf Acesso em:<br>17 jan 2023.|  
A equipe de metodologistas envolvida no processo foi responsável pela busca e avaliação de evidências, segundo a metodologia GRADE. A busca na literatura foi realizada nas bases de dados PubMed e Embase, bem como no Google Scholar e Epistemonikos. A estratégia de busca contemplou os vocabulários padronizados e não padronizados para cada base de dados para os elementos “P” e “I” da questão de pesquisa, combinados por meio de operadores booleanos apropriados.  
O fluxo de seleção dos artigos foi descritivo. A seleção das evidências foi realizada por um metodologista e conferida por outro, respeitando o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem dos estudos por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios de elegibilidade (de acordo com a pergunta de pesquisa) foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-  
análise era pequena, mais de uma revisão sistemática com meta-análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis demográfico-clínicas e desfechos de eficácia/segurança. Adicionalmente, para complementar o corpo das evidências, verificouse a existência de ensaios clínicos randomizados adicionais que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizou-se os estudos comparativos não randomizados. Os estudos excluídos na fase 3 tiveram suas razões de exclusão relatadas e referenciadas. O processo de seleção dos estudos foi representado em forma de fluxograma e pode ser visto ao longo do texto deste Apêndice.  
Com o corpo das evidências identificado, foram extraídos os dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha de Excel<sup>®</sup> . As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi relatada. Se o estudo apresentasse baixo risco de viés, significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Desta forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A MeaSurement Tool to Assess systematic Reviews 2_ (AMSTAR-2), os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane, os estudos observacionais pela ferramenta Newcastle-Ottawa. Séries de caso foram consideradas como estudos com alto risco de viés, dadas as limitações metodológicas inerentes ao desenho.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. A seguir, podem ser consultadas as estratégias de busca, síntese e avaliação das evidências para cada as duas questões PICO realizadas para o presente PCDT.  
A qualidade das evidências e a força da recomendação foram julgadas de acordo com os critérios _Confidence in Network Meta-analysis_ (CINeMA). O conjunto de evidências foi avaliado para cada desfecho considerado neste protocolo, sendo fornecida, ao final, a medida de certeza na evidência para cada um deles.  
A relatoria das seções do PCDT foi distribuída entre os especialistas, responsáveis pela redação da primeira versão do texto. Essas seções poderiam ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecidas e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas, interpretavam as evidências e redigiam uma primeira versão da recomendação.  
**Questão 1 - Qual a eficácia, efetividade e a segurança dos tratamentos em monoterapia ou terapia combinada da sildenafila, bosentana, ambrisentana, ilopostra, selexipague em comparação à sildenafila em monoterapia para pacientes com hipertensão arterial pulmonar?**<sup>**1**</sup>  
Nesta pergunta de pesquisa a estrutrada PICO foi composta por:  
> 1 O relatório completo encontra-se disponível no link: https://www.gov.br/conitec/ptbr/midias/relatorios/2022/20220603_relatorio_730_sildenafila_bosentana_ambrisentana_ilopostra_selexipague_riociguate_hap.pdf  
- População - Pacientes com hipertensão arterial pulmonar.  
- Intervenção - Bosentana ou ambrisentana ou iloprosta ou selexipague ou riociguate  
- Comparador - Sildenafila  
- Desfecho - Primários: Piora clínica, sobrevida livre de transplante, mortalidade; Secundários: pressão arterial  
pulmonar, classe funcional (OMS), teste de caminhada de 6 minutos; hospitalização; eventos adversos.  
Ressalta-se que o riociguate não possui indicação em bula aprovada para tratamento da HAP. No entanto, como há estudos que avaliam o seu uso nessa população, foi incluído na revisão sistemática visando a ampliação dos dados incluídos na metaanálise em rede e consequente melhora dos parâmetros do modelo. Adicionalmente, por ser realizada uma meta-análise em rede, os medicamentos listados como comparadores e intervenção podem ou não ser associados.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
**Quadro C** - Busca de dados no Medline via PubMed e Embase.  
|**Base**|**Estratégia**|**n**|
|---|---|---|
|Pubmed<br>via<br>Medline|(("pulmonary heart disease"[MeSH Terms] OR ("pulmonary"[All Fields] AND "heart"[All Fields]<br>AND "disease"[All Fields]) OR "pulmonary heart disease"[All Fields]) OR ("hypertension,<br>pulmonary"[MeSH Terms] OR ("hypertension"[All Fields] AND "pulmonary"[All Fields]) OR<br>"pulmonary hypertension"[All Fields] OR ("pulmonary"[All Fields] AND "hypertension"[All Fields]))<br>OR ("pulmonary arterial hypertension"[MeSH Terms] OR ("pulmonary"[All Fields] AND<br>"arterial"[All Fields] AND "hypertension"[All Fields]) OR "pulmonary arterial hypertension"[All<br>Fields])) AND (("sildenafil citrate"[MeSH Terms] OR ("sildenafil"[All Fields] AND "citrate"[All<br>Fields]) OR "sildenafil citrate"[All Fields] OR "sildenafil"[All Fields] OR "sildenafil's"[All Fields])<br>OR ((((bosentan)[All Fields] OR (bosentan[MeSH Terms])) OR (bosentan[Supplementary Concept]))<br>OR (bosentan[Title/Abstract])) OR ((((ambrisentan) OR (ambrisentan[MeSH Terms])) OR<br>(ambrisentan[Title/Abstract])) OR (ambrisentan[Supplementary Concept])) OR ((((iloprost) OR<br>(iloprost[MeSH Terms])) OR (iloprost[Title/Abstract])) OR (iloprost[Supplementary Concept])) OR<br>((((Selexipag)<br>OR<br>(Selexipag[Title/Abstract]))<br>OR<br>(Selexipag[MeSH<br>Terms]))<br>OR<br>(Selexipag[Supplementary Concept])) OR ("riociguat"[Supplementary Concept] OR "riociguat"[All<br>Fields] OR "riociguat"[Title/Abstract] OR "riociguat"[Supplementary Concept]))|3.805|
|Embase<br>Busca realizada|((('pulmonary heart disease':ti,ab,kw) OR ('pulmonary heart disease'/exp) OR ('pulmonary<br>hypertension':ti,ab,kw)<br>OR<br>('pulmonary<br>hypertension'/exp)<br>OR<br>('pulmonary<br>arterial<br>hypertension':ti,ab,kw) OR ('pulmonary arterial hypertension'/exp) OR (pulmonar* NEAR/2<br>hypertensi*)) AND ((Sildenafil OR 'sildenafil'/exp OR 'sildenafil'/de OR 'sildenafil':ti,ab,kw) OR<br>(Bosentan OR 'bosentan'/exp OR 'bosentan'/de OR 'bosentan':ti,ab,kw) OR (Ambrisetan OR<br>'ambrisetan'/exp OR 'ambrisetan'/de OR 'ambrisetan':ti,ab,kw) OR (Iloprost OR 'iloprost'/exp OR<br>'iloprost'/de OR 'iloprost':ti,ab,kw) OR (Selexipag OR 'selexipag'/exp OR 'selexipag':ti,ab,kw) OR<br>(Riociguat OR 'riociguat OR ''riociguat':ti,ab,kw))) NOT (ANIMAL)<br>em 16/04/2021.|10.940|

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
A revisão sistemática por estudos clínicos identificou 11.512 registros depois de remoção de duplicidades, dos quais 10.930 foram considerados irrelevantes durante a triagem e 515 foram excluídos após leitura dos textos na íntegra. Desta forma,  
foram incluídos 69 estudos na análise final. Um estudo foi identificado por busca manual, mediante o acesso às referências dos artigos incluídos neste estudo e revisões publicadas anteriormente, as quais não foram identificadas na busca inicial.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
<!-- Start of picture text -->
Bases de dados  Busca manual<br>MEDLINE/PubMed (n = 3.805)<br>(n = 1)<br>Embase (n = 10.940)<br>Registros após remoção dos duplicados<br>(n = 11.512)<br>Registros rastreados<br>(n = 11.512)<br>Registros excluídos<br>(n = 10.928)<br>Artigos em texto completo avaliados<br>para elegibilidade<br>Artigos em texto completo<br>(n = 584)<br>excluídos, com justificativa<br>(n = 515)<br>Desfecho = 11<br>Artigos incluídos na revisão sistemática<br>(n = 69)  População = 19<br>Tipo de estudo = 345<br>Identificação<br>Triagem<br>Elegibilidade<br>Inclusão<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
**Quadro D -** Descrição dos estudos incluídos.  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|NCT00323297|Vizza et al., 2017<sup>2</sup>|ECR<br>Duplo cego|Multicêntrico|103 participantes<br>Adultos<br>75,7% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|II<br>III<br>IV|Sildenafila 20 mg (3x/dia) +<br>bosentana 62,5 – 125 mg (2x/dia)<br>Bosentana 62,5 - 125 mg (2x/dia)|12<br>semanas|
|SUPER<br>NCT00644605|Galie et al., 2005<sup>3</sup><br>Badesch et al., 2007<sup>4</sup><br>Pepke-Zaba et al.,<br>2008<sup>5</sup>|ECR<br>Duplo cego|Multicêntrico|278 participantes<br>Adultos<br>75,1% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Reparo cirúrgico (≥5<br>anos antes do estudo)|I<br>II<br>III<br>IV|Sildenafila 20 mg (3x/dia)<br>Sildenafila 40 mg (3x/dia)<br>Sildenafila 80 mg (3x/dia)<br>Placebo|12<br>semanas|
|NCT00430716|Vizza et al., 2017<sup>6</sup>|ECR<br>Duplo cego|Multicêntrico|129 participantes<br>Adultos<br>67,4% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Reparo cirúrgico|I<br>II<br>III<br>IV|Sildenafila 1 mg (3x/dia)<br>Sildenafila 5 mg (3x/dia)<br>Sildenafila 20 mg (3x/dia)|12<br>semanas|
|STARTS-1<br>NCT00159913<br>NCT00159874|Barst et al., 2012<sup>7</sup><br>Russell et al., 2019<sup>8</sup><br>Beghetti et al., 2017<sup>9</sup><br>Beghetti et al.,<br>2013<sup>10</sup>|ECR<br>Duplo cego|Multicêntrico|234 participantes<br>Criança/adolescente<br>61,9% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|NA|Sildenafila – 10 mg (3x/dia)<br>Sildenafila – 40 mg (3x/dia)<br>Sildenafila – 80 mg (3x/dia)<br>Placebo|16<br>semanas|
|GRIPHON<br>NCT01106014|Beghetti et al.,<br>2019<sup>11</sup>Coghlan et<br>al., 2018<sup>12</sup>Preston et|ECR<br>Duplo cego|Multicêntrico|1.156 participantes<br>Adultos<br>79,8% sexo feminino|Idiopática<br>Hereditária|I<br>II<br>III|Selexipague 0,2 – 1,6 mg (2x/dia)<br>Placebo|26<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
||al., 2018<sup>13</sup>Sitbon et<br>al., 2015<sup>14</sup>Gaine et<br>al., 2021<sup>15</sup>Gaine et<br>al., 2017<sup>16</sup>Karelkina<br>et al., 2020<sup>17</sup>Sitbon<br>et al., 2020<sup>18</sup>||||Associada a doença do<br>tecido conjuntivo<br>Vírus da<br>imunodeficiência<br>humana<br>Reparo cirúrgico||||
|BREATHE-5<br>NCT00367770|Galie et al., 2006<sup>19</sup>|ECR<br>Duplo cego|Multicêntrico|54 participantes<br>Adultos|Síndrome de<br>Eisenmenger|NA|Bosentana 62,5 – 125 mg (2x/dia)<br>Placebo|16<br>semanas|
|BREATHE-1|Denton et al., 2006<sup>20</sup>|ECR<br>Aberto|Multicêntrico|66 participantes<br>Adultos<br>16,6% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Lúpus eritematoso<br>sistêmico|III<br>IV|Bosentana 62,5 - 125 mg (2x/dia)<br>Placebo|12<br>semanas|
|NCT00303004|Iversen et al., 2010<sup>21</sup>|ECR<br>Duplo cego|Dinamarca|20 participantes<br>Adultos<br>65% sexo feminino|Síndrome de<br>Eisenmenger|II<br>III<br>IV|Sildenafila 20 mg (3x/dia) +<br>bosentana 62,5 – 125 mg (2x/dia)<br>Bosentana 62,5 ou 125 mg<br>(2x/dia)|12<br>semanas|
|COMPASS 3<br>NCT00433329|Benza et al., 2018<sup>22</sup>|ECR<br>Aberto|Multicêntrico|100 participantes<br>Adultos<br>82% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|I<br>II<br>III<br>IV|Sildenafila 20 mg (3x/dia) +<br>bosentana 62,5 - 125 mg (2x/dia)<br>Sildenafila 20 mg (3x/dia)|28<br>semanas|
|COMPASS 2<br>NCT00303459|McLaughlin et al.,<br>2015<sup>23</sup>|ECR|Multicêntrico|334 participantes<br>Adultos|Idiopática<br>Hereditária|II<br>III|Sildenafila 20 mg (3x/dia) +<br>bosentana 62,5 - 125 mg (2x/dia)|16<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|||Duplo cego||75,7% sexo feminino|Associada a doença do<br>tecido conjuntivo|IV|Sildenafila 20 mg (3x/dia)||
|SIOVAC<br>NCT00862043|Bermejo et al.,<br>2018<sup>24</sup>|ECR<br>Duplo cego|Espanha|200 participantes<br>Adultos<br>79,5% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Reparo cirúrgico (≥1<br>ano antes do estudo)|I<br>II<br>III|Sildenafila 40 mg (3x/dia)<br>Placebo|24<br>semanas|
|BIPH<br>NCT01712997|Han et al., 2017<sup>25</sup>|ECR<br>Aberto|China|21 participantes<br>Adultos<br>62,5% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|III<br>IV|Iloprosta 0,1 mg (4-6x/dia) +<br>bosentana 62,5 - 125 mg (2x/dia)<br>Bosentana 62,5 - 125 mg (2x/dia)<br>Iloprosta 0,1 mg (4-6x/dia)|12<br>semanas|
|NCT00993408|Simonneau et al.,<br>2012<sup>26</sup>|ECR<br>Duplo cego|Multicêntrico|43 participantes<br>Adultos<br>81,4% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|II<br>III|Selexipague 0,4 – 0,8 mg (2x/dia)<br>Placebo|17<br>semanas|
|ARIES<br>NCT00091598|Galiè et al., 2008<sup>27</sup><br>Oudiz et al., 2009<sup>28</sup>|ECR<br>Duplo cego|Multicêntrico|373 participantes<br>Adultos<br>83,3% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Vírus da<br>imunodeficiência<br>humana|I<br>II<br>III<br>IV|Ambrisentana 2,5 mg (1x/dia)<br>Ambrisentana 5 mg (1x/dia)<br>Ambrisentana 10 mg (1x/dia)<br>Placebo|12<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|EARLY<br>NCT00091715|Galiè et al., 2008<sup>29</sup><br>Simonneau et al.,<br>2014<sup>30</sup>|ECR<br>Duplo cego|Multicêntrico|185 participantes<br>Adultos<br>69,7% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Vírus da<br>imunodeficiência<br>humana<br>Doenças autoimunes|II|Bosentana 62,5 - 125 mg (2x/dia)<br>Placebo|24<br>semanas|
|PATENT<br>NCT00863681<br>NCT00810693|Ghofrani et al.,<br>2013<sup>31</sup>Rosenkranz<br>et al., 2015<sup>32</sup><br>Rubin et al., 2015<sup>33</sup><br>Ghofrani et al.,<br>2016<sup>34</sup>Galie et al.,<br>2017<sup>35</sup>Humbert et<br>al., 2017<sup>36</sup>Ghofrani<br>et al., 2020<sup>37</sup><br>Simonneau et al.,<br>2020<sup>38</sup>|ECR<br>Aberto|Multicêntrico|443 participantes<br>Adultos<br>79% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Cirrose hepática<br>Devido a uso de<br>anorexígeno ou<br>anfetamina|I<br>II<br>III<br>IV|Riociguate 1,5 mg (3x/dia)<br>Riociguate 2,5 mg (3x/dia)<br>Placebo|12<br>semanas|
|NA|Badesch et al.,<br>2002<sup>39</sup>|ECR<br>Duplo cego|Multicêntrico|32 participantes<br>Adultos<br>87,5% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Esclerodermia|III<br>IV|Bosentana 62,5 – 125 mg (2x/dia)<br>Placebo|12<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|NA|Wilkins et al.,<br>2005<sup>40</sup>|ECR<br>Duplo cego|Inglaterra|26 participantes<br>Adultos<br>80,7% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|III|Sildenafila 50 mg (3x/dia)<br>Bosentana 62,5 ou 125 mg<br>(2x/dia)|16<br>semanas|
|PATENT<br>PLUS<br>NCT01179334|Galie et al., 2015<sup>41</sup>|ECR<br>Duplo cego|Multicêntrico|18 participantes<br>Adultos<br>66,6% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|I<br>II<br>III<br>IV|Sildenafila 20 mg (3x/dia) +<br>Riociguate 1,5 - 2,5 mg (3x/dia)<br>Sildenafila 20 mg (3x/dia)|12<br>semanas|
|NCT01726049|Hoendermis et al.,<br>2015<sup>42</sup>|ECR<br>Duplo cego|Multicêntrico|52 participantes<br>Adultos<br>71% sexo feminino|Idiopática|II<br>III<br>IV|Sildenafila 20 mg (3x/dia)<br>Placebo|12<br>semanas|
|NA|Kaluski et al., 2008<sup>43</sup>|ECR<br>Duplo cego|Israel|887 participantes<br>Adultos<br>28,7% sexo feminino|Idiopática|III<br>IV|Bosentana 8 – 125 mg (2x/dia)<br>Placebo|20<br>semanas|
|FUTURE 4<br>NCT01389856|Steinhorn et al.,<br>2016<sup>44</sup>|ECR<br>Duplo cego|Multicêntrico|23 participantes<br>Criança<br>65,2% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|NA|Bosentana 2 mg/kg (2x/dia)<br>Placebo|1 semana|
|NCT00309790|Lewis et al., 2007<sup>45</sup>|ECR|EUA|34 participantes|Idiopática|II<br>III|Sildenafila 25 - 75 mg (3x/dia)<br>Placebo|12<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|||Duplo cego||Adultos<br>85,2% sexo feminino|Associada a doença do<br>tecido conjuntivo|IV|||
|LEPHT<br>NCT01065454|Bonderman et al.,<br>2013<sup>46</sup>|ECR<br>Duplo cego|Multicêntrico|201 participantes<br>Adultos<br>38,4% sexo feminino|Idiopática|II<br>III<br>IV|Riociguate 0,5 mg (3x/dia)<br>Riociguate 1 mg (3x/dia)<br>Riociguate 2 mg (3x/dia)<br>Placebo|16<br>semanas|
|NA|Galie et al., 2005<sup>47</sup>|ECR<br>Duplo cego|Multicêntrico|64 participantes<br>Adultos<br>84,4% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Virus da<br>imunodeficiência<br>humana<br>Devido a uso de<br>anorexígeno ou<br>anfetamina|II<br>III|Ambrisentana 1 mg (1x/dia)<br>Ambrisentana 2,5 mg (1x/dia)<br>Ambrisentana 5 mg (1x/dia)<br>Ambrisentana 10 mg (1x/dia)|12<br>semanas|
|NA|Hoeper et al., 2005<sup>48</sup>|ECR|Alemanha|207 participantes<br>Adultos<br>77,5% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Doenças autoimunes|III|Iloprosta 5 µg (6x/dia) +<br>bosentana 125 mg (2x/dia)<br>Bosentana 125 mg (2x/dia)|12<br>semanas|
|NA|McLaughlin et al.,<br>2006<sup>49</sup>|ECR<br>Duplo cego|EUA|67 participantes<br>Adultos<br>79,1% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|II<br>III<br>IV|Iloprosta 5 µg (6x/dia) +<br>bosentana 125 mg (2x/dia)<br>Bosentana 125 mg (2x/dia)|12<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
||||||Virus da<br>imunodeficiência<br>humana<br>Devido a uso de<br>anorexígeno||||
|NA|Olschewski et al.,<br>2002<sup>50</sup>|ECR<br>Duplo cego|Multicêntrico|303 participantes<br>Adultos<br>69,8% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|III<br>IV|Iloprosta 5 µg (6x/dia)<br>Placebo|12<br>semanas|
|RISE-IIP<br>NCT02138825|Nathan et al., 2019<sup>51</sup>|ECR<br>Duplo cego|Multicêntrico|147 participantes<br>Adultos<br>35,3% sexo feminino|Idiopática<br>Pneumonias|II<br>III<br>IV|Riociguate 2,5 (3x/dia)<br>Placebo|26<br>semanas|
|NCT01332331|Ivy et al., 2020<sup>52</sup>|ECR<br>Cego|Multicêntrico|41 participantes<br>Adolescente<br>65,8% sexo feminino|Idiopática|II<br>III|Ambrisentana baixa dose<br>Peso 20 – 35 kg: 2,5 mg<br>Peso > 35 kg: 5 mg<br>Ambrisentana<br>Peso 20 – 35 kg: 5 mg<br>Peso 35 – 50 kg: 7,5 mg<br>Peso > 50 kg: 10 mg|24<br>semanas|
|ASSET<br>NCT00310830<br>NCT00313196<br>NCT00360087|Barst et al., 2010<sup>53</sup>|ECR<br>Duplo cego|Multicêntrico|26 participantes<br>Adultos<br>61,9% sexo feminino|Idiopática|NA|Bosentana 125 mg (2x/dia)<br>Placebo|16<br>semanas|
|NA|Mohamed et al.,<br>2012<sup>54</sup>|ECR|Arabia Saudita|47 participantes<br>Recem nascido|Idiopática<br>Aspiração de mecônio|NA|Bosentana 1 µg/kg (2x/dia)<br>Placebo||  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|||Duplo cego||44,6% sexo feminino|||||
|NCT00414687|Olschewski et al.,<br>2010<sup>55</sup>|ECR<br>Aberto|Alemanha|63 participantes<br>Adultos<br>44,5% sexo femino|Idiopática|II<br>III<br>IV|Iloprosta 5 µg (6x/dia)<br>Placebo|12<br>semanas|
|Dilate-1<br>NCT01172756|Bonderman et al.,<br>2014<sup>56</sup>|ECR<br>Duplo cego|Multicêntrico|39 participantes<br>Adultos<br>38,4% sexo feminino|Idiopática<br>Hereditária|NA|Riociguate 0,5 mg (3x/dia)<br>Riociguate 1 mg (3x/dia)<br>Riociguate 2,5 mg (3x/dia)<br>Placebo|4<br>semanas|
|NA|Channick et al.,<br>2001<sup>57</sup>Channick et<br>al., 2001<sup>58</sup>|ECR<br>Duplo cego|Multicêntrico|32 participantes<br>Adultos<br>87,5% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|III|Bosentana 62,5 mg - 125 mg<br>(2x/dia)<br>Placebo|12<br>semanas|
|NA|Ghofrani et al.,<br>2002<sup>59</sup>|ECR<br>Aberto|Alemanha|30 participantes<br>Adultos<br>76,6% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo<br>Doença de Raynaud|NA|Sildenafila 12,5 mg (3x/dia) +<br>iloprosta 5 µg (6x/dia)<br>Silfenafila 50 mg (3x/dia) +<br>Iloprosta 5 µg (6x/dia)<br>Sildenafila 12,5 mg (3x/dia)<br>Sildenafila 50 mg (3x/dia)|1 dia|
|NA|Rubin et al., 2002<sup>60</sup>|ECR<br>Duplo cego|Multicêntrico|213 participantes<br>Adultos<br>78,8% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|III<br>IV|Bosentana 125 mg (2x/dia)<br>Bosentana 250 mg (2x/dia)<br>Placebo|16<br>semanas|
|TRACE<br>NCT03078907|Howard et al.,<br>2020<sup>61</sup>Preston et al.,<br>2018<sup>62</sup>|ECR<br>Duplo cego|Multicêntrico|108 participantes<br>Adultos<br>71,2% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|NA|Selexipague 0,2 – 1,6 mg (2x/dia)<br>Placebo||  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
||||||Induzido por drogas<br>ou toxinas||||
|NA|Porhownik et al.,<br>2008<sup>63</sup>|Coorte<br>prospectiva||10 participantes<br>Adultos<br>80% sexo feminino|Idiopática<br>Associada a doença do<br>tecido conjuntivo|II<br>III|Sildenafila + bosentana<br>Bosentana|36<br>semanas|
|NA|Alkhayat et al.,<br>2016<sup>64</sup>|Coorte<br>prospectiva||139 participantes<br>Adultos<br>23,7% sexo feminino|Doença pulmonar<br>obstrutiva crônica|NA|Sildenafila 20 mg (3x/dia)<br>Placebo|12<br>semanas|
|NA|Gong et al., 2018<sup>65</sup>|Coorte<br>prospectiva||20 participantes<br>Adultos<br>80% sexo feminino|Idiopática|II<br>III<br>IV|Ambrisetana<br>Bosentana|96<br>semanas|
|COMBI<br>NCT00120380|Hoeper et al., 2006<sup>66</sup>|ECR<br>Aberto||40 participantes<br>Adultos<br>77,5% sexo feminino|Idiopática|III|Bosentana 125 mg (2x/dia)<br>Iloprosta 5 µg (6x/dia)||
|NA|Kahveci et al.,<br>2014<sup>67</sup>|Coorte<br>retrospectiva||47 participantes<br>Recém-Nascido<br>44,6% sexo feminino|Idiopática<br>Pneumonia<br>Aspiração de mecônio|NA|Sildenafila 0,5 mg/kg (3x/dia)<br>Iloprosta 1-2,5 µg (6x/dia)|1 semana|
|NA|William et al.,<br>2020<sup>68</sup>|Coorte<br>prospectiva||167 participantes<br>Criança/Adolescente<br>28,1% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo<br>Síndrome de<br>Eisenmenger|NA|Sildenafila<br>< 1 ano = 0,5 – 1 mg/kg (3x/dia)<br>> 1 ano e < 20 kg = 10 mg<br>(3x/dia)<br>> 1 ano e > 20 kg = 20 mg<br>(3x/dia)<br>Placebo|12<br>semanas|  
|**Estudo**|**Autor, ANO**|**Delineamento**|**Local**|**População**|**Origem da HAP**|**OMS**|**Comparadores**|**Período**<br>**de**<br>**avaliação**|
|---|---|---|---|---|---|---|---|---|
|NA|Benza et al., 2020<sup>69</sup>|Coorte<br>retrospectiva||4.824 participantes<br>Adultos<br>79,6% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|NA|Ambrisetana<br>Bosentana|52<br>semanas|
|NA|Douwes et al.,<br>2014<sup>70</sup>|Coorte<br>prospectiva||24 participantes<br>Adultos<br>75% sexo feminino|Idiopática<br>Hereditária<br>Associada a doença do<br>tecido conjuntivo|I<br>II<br>III<br>IV|Sildenafila + bosetana<br>Bosentana|1.152<br>semanas|

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
**Quadro F -** Descrição para risco de viés.  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdidos**|**Mensuração do**<br>**desfecho**|**Seleção do**<br>**resultado**<br>**relatado**|**Viés**<br>**global**|
|---|---|---|---|---|---|---|
|**NCT00323297**|||||||
|SUPER<br>NCT00644605|||||||
|**NCT00430716**|||||||
|STARTS-1<br>NCT00159913|||||||
|**GRIPHON**<br>**NCT01106014**|||||||
|BREATHE-5<br>NCT00367770|||||||
|**BREATHE-1**|||||||
|NCT00303004|||||||
|**COMPASS-3**<br>**NCT00433329**|||||||
|COMPASS 2<br>CT00303459|||||||
|**SIOVAC**<br>**NCT00862043**|||||||
|BIPH<br>NCT01712997|||||||
|**NCT00993408**|||||||
|ARIES<br>NCT00091598|||||||
|**EARLY**<br>**NCT00091715**|||||||
|PATENT<br>NCT00863681|||||||
|**Badesch et al,**<br>**2002**|||||||
|**Wilkins et al,**<br>**2005**|||||||
|**PATENT PLUS**<br>**NCT01179334**|||||||
|NCT01726049|||||||
|**Kaluski et al,**<br>**2008**|||||||  
|**Estudo**|**Randomização**|**Desvio das**<br>**intervenções**<br>**pretendidas**|**Dados**<br>**perdidos**|**Mensuração do**<br>**desfecho**|**Seleção do**<br>**resultado**<br>**relatado**|**Viés**<br>**global**|
|---|---|---|---|---|---|---|
|FUTURE 4<br>NCT01389856|||||||
|**NCT00309790**|||||||
|LEPHT<br>NCT01065454|||||||
|**Galie et al., 2005**|||||||
|**Hoeper et al.,**<br>**2005**|||||||
|**McLaughlin et**<br>**al., 2006**|||||||
|**Olschewski et al.,**<br>**2002**|||||||
|**RISE-IIP**<br>**NCT02138825**|||||||
|NCT01332331|||||||
|**ASSET**<br>**NCT00310830**|||||||
|**Mohamed et al.,**<br>**2012**|||||||
|**NCT00414687**|||||||
|Dilate-1<br>NCT01172756|||||||
|**Channick et al.,**<br>**2001**<br>**Channick et al.,**<br>**2001**|||||||
|**Ghofrani et al.,**<br>**2002**|||||||
|**Rubin et al.,**<br>**2002**|||||||
|TRACE<br>NCT03078907|||||||
|**COMBI**<br>**NCT00120380**|||||||

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
Iloprosta 5 mcg associado a bosentana 125 mg apresentou uma redução da **pressão arterial pulmonar** ao ser comparado com bosentana 125 mg, iloprosta 5 mcg, placebo, riociguate 1,5 mg, riociguate 1 mg, riociguate 2,5 mg, riociguate 2 mg, riociguate 5 mg, sildenafila 1 mg, sildenafila 20 mg, sildenafila 40 mg, sildenafila 5 mg, sildenafila 80 mg, assim como manteve a não diferença significativa ao ser comparado com selexipague 1,6 mg.  
Ao ser considerado o **teste de caminhada de 6 minutos,** verificou-se benefício de iloprosta 5 mcg associado a bosentana 125 mg ao ser comparado com ambrisentana 10, ambrisentana 1 mg, ambrisentana 2,5 mg, ambrisentana 5 mg, bosentana 125 mg, bosentana 250 mg, iloprosta 5 mcg, placebo, riociguate 1,5 mg, riociague 2,5 mg, selexipague 1,6 mcg, sildenafila 1 mg, sildenafila 20 mg, sildenafila 20 mg associado a bosentana 125 mg, sildenafila 20 mg associado ao riociguate 2,5 mg, sildenafila 40 mg, sildenafila 5 mg e sildenafila 80 mg. Sildenafila 20 mg associado a bosentana 125 mg apresentou aumento da distância percorrida ao ser comparado com placebo e inferior ao ser comparado com Iloprosta 5 mcg associado a bosentana 125 mg.  
Ao serem consideradas a **sobrevida livre de transplante** e **a mortalidade,** não houve diferença significativa entre os diferentes tipos de tratamento na análise de sensibilidade realizada.  
Ao ser considerada a **ocorrência de hospitalizações,** foi verificado que iloprosta 5 mcg associado a bosentana 125 mg apresentou uma redução de risco ao ser comparado com placebo.  
Ao ser considerada a ocorrência de **eventos adversos,** foi verificado que iloprosta 5 mcg associado a bosentana 125 mg apresentou um aumento do risco ao ser comparado com bosentana 125 mg.  
Ao ser considerada a ocorrência de **eventos adversos graves,** foi verificado que sildenafila 20 mg associado a bosentana 125 mg possui menor risco de ocorrência quando comparado a sildenafila.  
Ao ser considerada a ocorrência de **piora clínica,** foi verificado que iloprosta 5 mcg associado a bosentana125 mg apresentou redução do risco de ocorrência quando comparado ao placebo e bosentana 125 mg.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
A análise do CINeMA demonstrou que a evidência da meta-análise em rede foi predominantemente muito baixa, mas variou entre muito baixa e alta para as comparações realizadas. Esse resultado se deve ao viés dos estudos, viés de publicação, imprecisão, heterogeneidade e inconsistência dos resultados incluídos na NMA.  
2 Serão apenas informas as diferenças significativas conforme análises de sensibilidade realizadas após a Consulta Pública 06/2022.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
1. Brasil. Ministério da Saúde. Secretaria de Ciência T, Saúde IeIEe, Incorporação DdGe, Saúde dTeIe. DIRETRIZES  
METODOLÓGICAS - Elaboração de Pareceres Técnico-Científicos2021.  
2. Vizza CD, Jansa P, Teal S, Dombi T, Zhou D. Sildenafil dosed concomitantly with bosentan for adult pulmonary  
arterial hypertension in a randomized controlled trial. BMC Cardiovasc Disord. 2017;17(1):239.  
3. Galiè N, Ghofrani HA, Torbicki A, Barst RJ, Rubin LJ, Badesch D, et al. Sildenafil citrate therapy for pulmonary  
arterial hypertension. New England Journal of Medicine. 2005;353(20):2148-57.  
4. Badesch DB, Hill NS, Burgess G, Rubin LJ, Barst RJ, Galie N, et al. Sildenafil for pulmonary arterial hypertension  
associated with connective tissue disease. The Journal of rheumatology. 2007;34(12):2417-22.  
5. Pepke-Zaba J, Gilbert C, Collings L, Brown MC. Sildenafil improves health-related quality of life in patients with  
pulmonary arterial hypertension. Chest. 2008;133(1):183-9.  
6. Vizza CD, Sastry BK, Safdar Z, Harnisch L, Gao X, Zhang M, et al. Efficacy of 1, 5, and 20 mg oral sildenafil in the  
treatment of adults with pulmonary arterial hypertension: a randomized, double-blind study with open-label extension. BMC Pulm Med. 2017;17(1):44.  
7. Barst RJ, Ivy DD, Gaitan G, Szatmari A, Rudzinski A, Garcia AE, et al. A randomized, double-blind, placebo-  
controlled, dose-ranging study of oral sildenafil citrate in treatment-naive children with pulmonary arterial hypertension. Circulation. 2012;125(2):324-34.  
8. Russell S, Beghetti M, Oudiz R, Balagtas C, Zhang M, Ivy D. Effects of oral sildenafil on exercise capacity in children  
with pulmonary arterial hypertension: a randomised trial. Open Heart. 2019;6(2):e001149.  
9. Beghetti M, Rudzinski A, Zhang M. Efficacy and safety of oral sildenafil in children with Down syndrome and  
pulmonary hypertension. BMC Cardiovasc Disord. 2017;17(1):177.  
10. Beghetti M, Zhang M, Ivy DD, Barst RJ. Oral sildenafil in children with down syndrome and pulmonary arterial  
hypertension. Am J Respir Crit Care Med. 2013;187.  
11. Beghetti M, Channick RN, Chin KM, Di Scala L, Gaine S, Ghofrani HA, et al. Selexipag treatment for pulmonary  
arterial hypertension associated with congenital heart disease after defect correction: insights from the randomised controlled GRIPHON study. Eur J Heart Fail. 2019;21(3):352-9.  
12. Coghlan JG, Channick R, Chin K, Di Scala L, Galie N, Ghofrani HA, et al. Targeting the Prostacyclin Pathway with  
Selexipag in Patients with Pulmonary Arterial Hypertension Receiving Double Combination Therapy: Insights from the Randomized Controlled GRIPHON Study. Am J Cardiovasc Drugs. 2018;18(1):37-47.  
13. Preston IR, Channick RN, Chin K, Di Scala L, Farber HW, Gaine S, et al. Temporary treatment interruptions with  
oral selexipag in pulmonary arterial hypertension: Insights from the Prostacyclin (PGI2) Receptor Agonist in Pulmonary Arterial Hypertension (GRIPHON) study. J Heart Lung Transplant. 2018;37(3):401-8.  
14. Sitbon O, Channick R, Chin KM, Frey A, Gaine S, Galiè N, et al. Selexipag for the treatment of pulmonary arterial  
hypertension. New England Journal of Medicine. 2015;373(26):2522-33.  
15. Gaine S, Sitbon O, Channick RN, Chin KM, Sauter R, Galie N, et al. Relationship Between Time From Diagnosis  
and Morbidity or Mortality in Pulmonary Arterial Hypertension: Results From the Phase III GRIPHON Study. Chest. 2021.  
16. Gaine S, Chin K, Coghlan G, Channick R, Di Scala L, Galie N, et al. Selexipag for the treatment of connective tissue  
disease-associated pulmonary arterial hypertension. Eur Respir J. 2017;50(2).  
17. Karelkina EV, Goncharova NS, Simakova MA, Moiseeva OM. [Experience with Selexipag to Treat Pulmonary  
Arterial Hypertension]. Kardiologiia. 2020;60(4):36-42.  
18. Sitbon O, Chin KM, Channick RN, Benza RL, Di Scala L, Gaine S, et al. Risk assessment in pulmonary arterial  
hypertension: Insights from the GRIPHON study. J Heart Lung Transplant. 2020;39(4):300-9.  
19. Galie N, Beghetti M, Gatzoulis MA, Granton J, Berger RM, Lauer A, et al. Bosentan therapy in patients with Eisenmenger syndrome: a multicenter, double-blind, randomized, placebo-controlled study. Circulation. 2006;114(1):48-54.  
20. Denton CP, Humbert M, Rubin L, Black CM. Bosentan treatment for pulmonary arterial hypertension related to connective tissue disease: a subgroup analysis of the pivotal clinical trials and their open-label extensions. Ann Rheum Dis. 2006;65(10):1336-40.  
21. Iversen K, Jensen AS, Jensen TV, Vejlstrup NG, Søndergaard L. Combination therapy with bosentan and sildenafil in Eisenmenger syndrome: A randomized, placebo-controlled, double-blinded trial. European Heart Journal. 2010;31(9):112431.  
22. Benza RL, Raina A, Gupta H, Murali S, Burden A, Zastrow MS, et al. Bosentan-based, treat-to-target therapy in  
patients with pulmonary arterial hypertension: results from the COMPASS-3 study. Pulm Circ. 2018;8(1):2045893217741480.  
23. McLaughlin V, Channick RN, Ghofrani HA, Lemarie JC, Naeije R, Packer M, et al. Bosentan added to sildenafil  
therapy in patients with pulmonary arterial hypertension. Eur Respir J. 2015;46(2):405-13.  
24. Bermejo J, Yotti R, Garcia-Orta R, Sanchez-Fernandez PL, Castano M, Segovia-Cubero J, et al. Sildenafil for improving outcomes in patients with corrected valvular heart disease and persistent pulmonary hypertension: a multicenter, double-blind, randomized clinical trial. Eur Heart J. 2018;39(15):1255-64.  
25. Han X, Zhang Y, Dong L, Fang L, Chai Y, Niu M, et al. Treatment of Pulmonary Arterial Hypertension Using Initial  
Combination Therapy of Bosentan and Iloprost. Respir Care. 2017;62(4):489-96.  
26. Simonneau G, Torbicki A, Hoeper MM, Delcroix M, Karlocai K, Galie N, et al. Selexipag: an oral, selective prostacyclin receptor agonist for the treatment of pulmonary arterial hypertension. Eur Respir J. 2012;40(4):874-80.  
27. Galiè N, Olschewski H, Oudiz RJ, Torres F, Frost A, Ghofrani HA, et al. Ambrisentan for the treatment of pulmonary  
arterial hypertension: Results of the ambrisentan in pulmonary arterial hypertension, randomized, double-Blind, placebocontrolled, multicenter, efficacy (ARIES) study 1 and 2. Circulation. 2008;117(23):3010-9.  
28. Oudiz RJ, Galie N, Olschewski H, Torres F, Frost A, Ghofrani HA, et al. Long-term ambrisentan therapy for the  
treatment of pulmonary arterial hypertension. J Am Coll Cardiol. 2009;54(21):1971-81.  
29. Galie N, Rubin L, Hoeper M, Jansa P, Al-Hiti H, Meyer G, et al. Treatment of patients with mildly symptomatic pulmonary arterial hypertension with bosentan (EARLY study): a double-blind, randomised controlled trial. Lancet (London, England). 2008;371(9630):2093-100.  
30. Simonneau G, Galie N, Jansa P, Meyer GM, Al-Hiti H, Kusic-Pajic A, et al. Long-term results from the EARLY study  
of bosentan in WHO functional class II pulmonary arterial hypertension patients. International journal of cardiology. 2014;172(2):332-9.  
31. Ghofrani HA, Galie N, Grimminger F, Grunig E, Humbert M, Jing ZC, et al. Riociguat for the treatment of pulmonary  
arterial hypertension. The New England journal of medicine. 2013;369(4):330-40.  
32. Rosenkranz S, Ghofrani HA, Beghetti M, Ivy D, Frey R, Fritsch A, et al. Riociguat for pulmonary arterial hypertension  
associated with congenital heart disease. Heart. 2015;101(22):1792-9.  
33. Rubin LJ, Galie N, Grimminger F, Grunig E, Humbert M, Jing ZC, et al. Riociguat for the treatment of pulmonary  
arterial hypertension: a long-term extension study (PATENT-2). Eur Respir J. 2015;45(5):1303-13.  
34. Ghofrani HA, Grimminger F, Grunig E, Huang Y, Jansa P, Jing ZC, et al. Predictors of long-term outcomes in patients  
treated with riociguat for pulmonary arterial hypertension: data from the PATENT-2 open-label, randomised, long-term extension trial. Lancet Respir Med. 2016;4(5):361-71.  
35. Galie N, Grimminger F, Grunig E, Hoeper MM, Humbert M, Jing ZC, et al. Comparison of hemodynamic parameters in treatment-naive and pre-treated patients with pulmonary arterial hypertension in the randomized phase III PATENT-1 study. J Heart Lung Transplant. 2017;36(5):509-19.  
36. Humbert M, Coghlan JG, Ghofrani HA, Grimminger F, He JG, Riemekasten G, et al. Riociguat for the treatment of pulmonary arterial hypertension associated with connective tissue disease: results from PATENT-1 and PATENT-2. Ann Rheum Dis. 2017;76(2):422-6.  
37. Ghofrani HA, Grunig E, Jansa P, Langleben D, Rosenkranz S, Preston IR, et al. Efficacy and safety of riociguat in combination therapy for patients with pulmonary arterial hypertension (PATENT studies). Pulm Circ. 2020;10(3):2045894020942121.  
38. Simonneau G, Ghofrani HA, Corris PA, Rosenkranz S, Grunig E, White J, et al. Assessment of the REPLACE study composite endpoint in riociguat-treated patients in the PATENT study. Pulm Circ. 2020;10(4):2045894020973124.  
39. Badesch DB, Bodin F, Channick RN, Frost A, Rainisio M, Robbins IM, et al. Complete results of the first randomized, placebo-controlled study of bosentan, a dual endothelin receptor antagonist, in pulmonary arterial hypertension. Current Therapeutic Research. 2002;63(4):227-46.  
40. Wilkins MR, Paul GA, Strange JW, Tunariu N, Gin-Sing W, Banya WA, et al. Sildenafil versus Endothelin Receptor Antagonist for Pulmonary Hypertension (SERAPH) study. Am J Respir Crit Care Med. 2005;171(11):1292-7.  
41. Galie N, Muller K, Scalise AV, Grunig E. PATENT PLUS: a blinded, randomised and extension study of riociguat plus sildenafil in pulmonary arterial hypertension. Eur Respir J. 2015;45(5):1314-22.  
42. Hoendermis ES, Liu LC, Hummel YM, van der Meer P, de Boer RA, Berger RM, et al. Effects of sildenafil on invasive haemodynamics and exercise capacity in heart failure patients with preserved ejection fraction and pulmonary hypertension: a randomized controlled trial. Eur Heart J. 2015;36(38):2565-73.  
43. Kaluski E, Cotter G, Leitman M, Milo-Cotter O, Krakover R, Kobrin I, et al. Clinical and hemodynamic effects of bosentan dose optimization in symptomatic heart failure patients with severe systolic dysfunction, associated with secondary pulmonary hypertension--a multi-center randomized study. Cardiology. 2008;109(4):273-80.  
44. Steinhorn RH, Fineman J, Kusic-Pajic A, Cornelisse P, Gehin M, Nowbakht P, et al. Bosentan as Adjunctive Therapy for Persistent Pulmonary Hypertension of the Newborn: Results of the Randomized Multicenter Placebo-Controlled Exploratory Trial. J Pediatr. 2016;177:90-6 e3.  
45. Lewis GD, Shah R, Shahzad K, Camuso JM, Pappagianopoulos PP, Hung J, et al. Sildenafil improves exercise capacity and quality of life in patients with systolic heart failure and secondary pulmonary hypertension. Circulation. 2007;116(14):1555-62.  
46. Bonderman D, Ghio S, Felix SB, Ghofrani HA, Michelakis E, Mitrovic V, et al. Riociguat for patients with pulmonary hypertension caused by systolic left ventricular dysfunction: a phase IIb double-blind, randomized, placebo-controlled, doseranging hemodynamic study. Circulation. 2013;128(5):502-11.  
47. Galie N, Badesch D, Oudiz R, Simonneau G, McGoon MD, Keogh AM, et al. Ambrisentan therapy for pulmonary arterial hypertension. J Am Coll Cardiol. 2005;46(3):529-35.  
48. Hoeper MM, Leuchte H, Halank M, Wilkens H, Meyer FJ, Seyfarth HJ, et al. Combining inhaled iloprost with  
bosentan in patients with idiopathic pulmonary arterial hypertension. Eur Respir J. 2006;28(4):691-4.  
49. McLaughlin VV, Oudiz RJ, Frost A, Tapson VF, Murali S, Channick RN, et al. Randomized study of adding inhaled iloprost to existing bosentan in pulmonary arterial hypertension. Am J Respir Crit Care Med. 2006;174(11):1257-63.  
50. Olschewski H, Simonneau G, Galie N, Higenbottam T, Naeije R, Rubin LJ, et al. Inhaled iloprost for severe pulmonary hypertension. The New England journal of medicine. 2002;347(5):322-9.  
51. Nathan SD, Behr J, Collard HR, Cottin V, Hoeper MM, Martinez FJ, et al. Riociguat for idiopathic interstitial pneumonia-associated pulmonary hypertension (RISE-IIP): a randomised, placebo-controlled phase 2b study. Lancet Respir Med. 2019;7(9):780-90.https://www.ncbi.nlm.nih.gov/pubmed/31416769  
52. Ivy D, Beghetti M, Juaneda-Simian E, Miller D, Lukas MA, Ioannou C, et al. A Randomized Study of Safety and Efficacy of Two Doses of Ambrisentan to Treat Pulmonary Arterial Hypertension in Pediatric Patients Aged 8 Years up to 18 Years. The Journal of Pediatrics: X. 2020;5.  
53. Barst RJ, Mubarak KK, Machado RF, Ataga KI, Benza RL, Castro O, et al. Exercise capacity and haemodynamics in patients with sickle cell disease with pulmonary hypertension treated with bosentan: results of the ASSET studies. British journal of haematology. 2010;149(3):426-35.  
54. Mohamed WA, Ismail M. A randomized, double-blind, placebo-controlled, prospective study of bosentan for the  
treatment of persistent pulmonary hypertension of the newborn. J Perinatol. 2012;32(8):608-13.  
55. Olschewski H, Hoeper MM, Behr J, Ewert R, Meyer A, Borst MM, et al. Long-term therapy with inhaled iloprost in patients with pulmonary hypertension. Respiratory medicine. 2010;104(5):731-40.  
56. Bonderman D, Pretsch I, Steringer-Mascherbauer R, Jansa P, Rosenkranz S, Tufaro C, et al. Acute hemodynamic effects of riociguat in patients with pulmonary hypertension associated with diastolic heart failure (DILATE-1): a randomized, double-blind, placebo-controlled, single-dose study. Chest. 2014;146(5):1274-85.  
57. Channick RN, Simonneau G, Sitbon O, Robbins IM, Frost A, Tapson VF, et al. Effects of the dual endothelin-receptor antagonist bosentan in patients with pulmonary hypertension: a randomised placebo-controlled study. Lancet (London, England). 2001;358(9288):1119-23.  
58. Channick RN, Simonneau G, Sitbon O, Robbins IM, Frost A, Tapson VF, et al. Effects of the dual endothelin-receptor antagonist bosentan in patients with pulmonary hypertension: A randomized placebo-controlled study. Revista Portuguesa de Cardiologia. 2001;20(11):1151-2.  
59. Ghofrani HA, Wiedemann R, Rose F, Olschewski H, Schermuly RT, Weissmann N, et al. Combination therapy with  
oral sildenafil and inhaled iloprost for severe pulmonary hypertension. Ann Intern Med. 2002;136(7):515-22.  
60. Rubin LJ, Badesch DB, Barst RJ, Galie N, Black CM, Keogh A, et al. Bosentan therapy for pulmonary arterial  
hypertension. The New England journal of medicine. 2002;346(12):896-903.  
61. Howard L, Rosenkranz S, Frantz R, Hemnes A, Pfister T, Shiraga Y, et al. Assessing Daily Life Physical Activity by  
Actigraphy in Pulmonary Arterial Hypertension: Insights from the Randomized Controlled Study with Selexipag (Trace). Chest. 2020;158(4):A2449-A51.  
62. Preston I, Frantz R, Hemnes A, Rosenkranz S, Skaara H, Pfister T, et al. Rationale and design of trace: A doubleblind, placebo-controlled phase 4 study in pulmonary arterial hypertension to assess the effect of selexipag on physical activity, patient-reported symptoms and their impact, in daily life. Am J Respir Crit Care Med. 2018;197(MeetingAbstracts).  
63. Porhownik NR, Al-Sharif H, Bshouty Z. Addition of sildenafil in patients with pulmonary arterial hypertension with  
inadequate response to bosentan monotherapy. Can Respir J. 2008;15(8):427-30.  
64. Alkhayat K, Eid M. Sildenafil citrate therapy for secondary pulmonary arterial hypertension due to chronic obstructive  
lung disease. Egyptian Journal of Chest Diseases and Tuberculosis. 2016;65(4):805-9.  
65. Gong SG, Wang L, Pudasaini B, Yuan P, Jiang R, Zhao QH, et al. Transition from Ambrisentan to Bosentan in  
Pulmonary Arterial Hypertension: A Single-Center Prospective Study. Can Respir J. 2018;2018:9836820.  
66. Hoeper MM, Markevych I, Spiekerkoetter E, Welte T, Niedermeyer J. Goal-oriented treatment and combination  
therapy for pulmonary arterial hypertension. Eur Respir J. 2005;26(5):858-63.  
67. Kahveci H, Yilmaz O, Avsar UZ, Ciftel M, Kilic O, Laloglu F, et al. Oral sildenafil and inhaled iloprost in the  
treatment of pulmonary hypertension of the newborn. Pediatric pulmonology. 2014;49(12):1205-13.  
68. William MB, Ali MAS, Farghaly HS, Elfaham TH. Effectiveness and short-term survival associated with adding  
sildenafil to conventional therapy in the management of children with pulmonary hypertension. Progress in Pediatric Cardiology. 2020;56.  
69. Benza RL, Lickert CA, Xie L, Drake W, Ogbomo A, Yuce H, et al. Comparative effectiveness of endothelin receptor antagonists on mortality in patients with pulmonary arterial hypertension in a US Medicare population: a retrospective database analysis. Pulmonary Circulation. 2020;10(4).  
70. Douwes JM, Roofthooft MT, Van Loon RL, Ploegstra MJ, Bartelds B, Hillege HL, et al. Sildenafil add-on therapy in paediatric pulmonary arterial hypertension, experiences of a national referral centre. Heart. 2014;100(3):224-30.

---

<!-- METADADOS: doenca: Hipertensão Pulmonar | secao: **Alteração pós publicação** -->
|**Relatório ou**||**Tecnologias avaliadas p**|**ela Conitec**|
|---|---|---|---|
|**Portaria de**<br>**Publicação**|**Principais alterações**|**Incorporação ou alteração do uso no**<br>**SUS**|**Não incorporação ao SUS**|
||Pós-publicação:<br>inclusão de informações<br>na<br>seção<br>Monitoramentos<br>de<br>eventos adversos|-|-|
|||Incorporação<br>do<br>selexipague<br>para<br>||
|Portaria<br>Conjunta<br>SAES-SECTICS/MS<br>nº 10/2023 [Relatório<br>de Recomendação nº<br>809/2023]|Atualização devido à<br>incorporação<br>de<br>tecnologias no SUS.<br>Nesta<br>atualização,<br>houve a ampliação do<br>escopo<br>para<br>Hipertensão Pulmonar|pacientes adultos com hipertensão arterial<br>pulmonar (HAP - Grupo I) em classe<br>funcional III que não alcançaram resposta<br>satisfatória com ERA ou PDE5i, como<br>alternativa<br>a<br>iloprosta<br>–<br>Portaria<br>SCTIE/MS nº 53, de 6 de agosto de 2021<br>Incorporação<br>dos<br>medicamentos<br>sildenafila e bosentana em uso associado<br>para o tratamento de pacientes com<br>Hipertensão Arterial Pulmonar – Portaria<br>SCTIE/MSnº 49,de 03 dejunho de 2022.|Não<br>incorporação<br>do<br>riociguate para tratamento da<br>Hipertensão<br>Pulmonar<br>Tromboembólica<br>Crônica<br>(HPTEC)<br>inoperável,<br>persistente<br>ou<br>recorrente<br>após tratamento cirúrgico –<br>Portaria SCTIE/MS nº 24, de<br>11 de março de 2022.|
|Portaria SAS/MS nº<br>35, de 16 de janeiro<br>de 2014|Atualização<br>de<br>conteúdo|Incorporação<br>de<br>ambrisentana<br>e<br>bosentana<br>para<br>o<br>tratamento<br>da<br>Hipertensão Arterial Pulmonar (HAP) na<br>falha<br>primária,<br>secundária<br>ou<br>contraindicação da sildenafila – Portaria<br>SCTIE/MS nº 53, de 07 de novembro de<br>2013|Não<br>incorporação<br>de<br>tadalafila, indicada para o<br>tratamento da hipertensão<br>arterial pulmonar – Portaria<br>SCTIE/MS nº 5, de 05 de<br>março de 2013<br>Não<br>incorporação<br>de<br>ambrisentana<br>para<br>o<br>tratamento da hipertensão<br>arterial pulmonar – Portaria<br>SCTIE/MS nº 27, de 13 de<br>setembro de 2012|

---

