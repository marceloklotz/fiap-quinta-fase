<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 02, DE 11 DE JANEIRO DE 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Raquitismo e Osteomalácia.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o Raquitismo e Osteomalácia no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação ~~n~~<sup><u>o</u></sup> 688/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 692 – Dezembro de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Raquitismo e Osteomalácia.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do Raquitismo e Osteomalácia, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter nacional e deve ser</u> utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do Raquitismo e Osteomalácia.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Fica revogada a Portaria SAS/MS n<sup>o</sup> 451, de 29 de abril de 2016, publicada no Diário Oficial da União (DOU) nº 82, de 02 de maio de 2016, seção 1, páginas 53.  
Art. 5º  Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: SERGIO YOSHIMASA OKANE -->
HÉLIO ANGOTTI NETO  
ANEXO

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **1. INTRODUÇÃO** -->
O raquitismo e a osteomalácia são doenças caracterizadas pela deficiência da mineralização óssea com repercussões primariamente esqueléticas, mas que também podem afetar diversos outros tecidos e órgãos, comprometendo a saúde global do indivíduo. O raquitismo resulta da deficiência de mineralização da placa de crescimento de crianças e adolescentes. A osteomalácia, por sua vez, resulta da deficiência de mineralização da matriz osteoide e pode ocorrer tanto em crianças e adolescentes quanto em adultos<sup>1,2</sup> .  
A deficiência da mineralização óssea, que caracteriza a patogênese dessas duas doenças, pode ocorrer por várias razões, como carência nutricional dos substratos cálcio ou fósforo; deficiência nutricional e distúrbios na síntese ou na utilização da vitamina D; tubulopatias renais perdedoras de cálcio e fósforo; distúrbios acidobásicos (como acidoses metabólicas); doenças que comprometam a absorção intestinal de cálcio e fósforo (como a doença celíaca); medicamentos que desregulam o metabolismo osteomineral (como alguns anticonvulsivantes e imunossupressores)<sup>3</sup> .  
As concentrações séricas da principal forma de armazenamento de vitamina D no organismo, a 25-hidroxivitamina D, variam de acordo com a idade do indivíduo, a cor da sua pele, a região geográfica onde mora (depende da altitude e da distância da linha do Equador), e da estação do ano<sup>4</sup> . A redução da exposição aos raios ultravioleta B do sol e o excessivo uso de protetor solar podem aumentar o risco de deficiência de vitamina D<sup>5,6</sup> . Além disso, o uso de vestimentas que cobrem todo o corpo (por questões culturais), deslocamentos realizados predominantemente dentro de veículos automotivos e a fuga da exposição ao sol são alguns exemplos de situações que podem comprometer a síntese de vitamina D pelo organismo<sup>7,8</sup> .  
O raquitismo e a osteomalácia decorrentes da deficiência de cálcio e fósforo podem ter causas nutricionais ou ambientais (raquitismo carencial ou nutricional) ou causas genéticas (raquitismos genéticos). Esses últimos podem ser secundários a mutações nos genes que codificam proteínas envolvidas na síntese e atividade da vitamina D, na regulação do metabolismo do fosfato ou nas vias que controlam a mineralização óssea. O raquitismo também pode ser causado por doenças adquiridas e que interferem no metabolismo da vitamina D, como a doença hepática grave e a insuficiência renal crônica, assim como por medicamentos que desregulam o equilíbrio do cálcio e fósforo nos túbulos renais<sup>9</sup> . As tubulopatias perdedoras de fósforo ou de cálcio, de etiologia genética ou adquirida, também podem levar ao raquitismo e à osteomalácia<sup>10</sup> .  
O raquitismo pode ser classificado em dois tipos, calciopênico ou fosfopênico, os quais podem apresentar características clínicas e radiológicas bem semelhantes, sendo a diferenciação feita por exames bioquímicos laboratoriais. A causa mais comum do raquitismo calciopênico é a deficiência da vitamina D, e do fosfopênico são os distúrbios relacionados à perda renal de fosfato. Em ambos, há redução das concentrações de fósforo no organismo, que é a causa fisiopatogênica das alterações observadas na placa de crescimento do indivíduo com raquitismo nutricional<sup>11,12</sup> .  
Além das causas ambientais que levam à deficiência de vitamina D e, consequentemente, ao raquitismo calciopênico, a doença também pode decorrer de causas genéticas. O raquitismo dependente de vitamina D é secundário a mutações no gene que codifica a enzima 1-alfa-hidroxilase ( _CYP27B1_ ), responsável pela ativação final da vitamina D no seu metabólito ativo (calcitriol). O raquitismo resistente à vitamina D (ou dependente tipo II) é causado por mutações no gene que codifica o receptor de vitamina D ( _VDR_ ), tornando-o não responsivo ao calcitriol<sup>13</sup> .  
Outras causas mais raras de raquitismo são secundárias a tumores e doenças que cursam com má-absorção intestinal. O uso de alguns medicamentos também pode causar raquitismo, como diuréticos de alça, glicocorticoides, anticonvulsivantes e  
produtos à base de alumínio<sup>14</sup> . Nos casos hereditários, diversas doenças já foram descritas como causadoras do raquitismo hipofosfatêmico, podendo cursar com um aumento da atividade do fator de crescimento do fibroblasto 23 (raquitismo hipofosfatêmico ligado ao cromossoma X ou hipofosfatemia ligada ao cromossoma X - HLX, raquitismo hipofosfatêmico autossômico dominante e raquitismo hipofosfatêmico autossômico recessivo) ou com defeitos nos canais de reabsorção de fósforo dependente de sódio (raquitismo hipofosfatêmico com hipercalciúria hereditário)<sup>15,16</sup> .  
A principal causa do raquitismo fosfopênico consiste em um grupo de doenças genéticas que desregulam e inibem a reabsorção de fosfato nos túbulos proximais renais, mas também pode ser causado por uma síndrome paraneoplásica rara decorrente de tumores produtores de fator de crescimento do fibroblasto 23 (osteomalácia oncogênica) ou por condições que levam a distúrbios da absorção intestinal desse mineral<sup>17–19</sup> . Entre os raquitismos hipofosfatêmicos genéticos, o HLX é o mais frequente, uma doença progressivamente debilitante e deformante, que corresponde a cerca de 80% dos casos e tem transmissão de caráter dominante ligada ao cromossoma X. O HLX decorre de um distúrbio genético raro decorrente de mutações com perda de função do gene _PHEX_ ( _Phosphate Regulating Endopeptidase Homolog X-Linked,_ endopeptidase homóloga reguladora do fosfato ligada ao X _)_ que codifica a proteína PHEX, envolvida na síntese e na degradação do fator de crescimento do fibroblasto 23 (FGF23). É uma doença com penetrância completa, mas com ampla variabilidade clínica, levando a graus variados na gravidade do raquitismo e nas deformidades dos membros superiores e inferiores, associadas à dor crônica, fraqueza muscular, muitas vezes incapacitante, e tendência a abscessos dentários. Este quadro pode levar a comprometimento grave do crescimento, da deambulação, necessidade de procedimentos cirúrgicos ortopédicos para correção das deformidades e redução importante da qualidade de vida do indivíduo<sup>20</sup> . Adultos com HLX podem apresentar osteomalácia, dores ósseas e fraqueza muscular importante, que também pode ser incapacitante e comprometer a qualidade de vida do paciente<sup>21</sup> .  
De forma semelhante aos casos de raquitismo e osteomalácia em crianças e adolescentes, a osteomalácia nos adultos decorre da deficiência de vitamina D, sendo essa deficiência a causa mais frequente, embora a osteomalácia também possa ser induzida por doenças que afetam o fígado e os rins, por medicamentos que interferem no metabolismo osteomineral e, em casos raros, por tumor<sup>22–27</sup> .  
Conforme exposto, o raquitismo e a osteomalácia podem ser classificados de acordo com sua etiopatogenia em genéticos ou adquiridos (ambientais) e de acordo com a deficiência mineral subjacente em calciopênicos (deficiência de suprimento de cálcio e fósforo) ou fosfopênicos (deficiência de fósforo)<sup>3,28</sup> . As principais causas e exemplos desses tipos de raquitismo são apresentados no **Quadro 1Quadro 1** .  
**Quadro 1 -** Classificação dos raquitismos e osteomalácia<sup>3,28</sup> .  
||**Raquitismos**|**ou Osteomalácia**|
|---|---|---|
||**Genéticos**|**Adquiridos**|
|**CALC**|**IOPÊNICOS**|<br>**CALCIOPÊNICOS**|
|<br>**Tubulo**|**patias renais perdedoras de cálcio ou fósforo**|<br>**Carência Nutricional**|
||Acidose tubular renal|<br>Deficiência dietética de cálcio|
||Síndrome de Fanconi|<br>Deficiência de vitamina D (baixa exposição ao sol;|
||Doença de Dent|uso de vestimenta que cobre todo o corpo; uso<br>excessivo de protetor solar)|
|**Distúr**|**bios do metabolismo da vitamina D**||
||Deficiência da síntese de 25OHD|**Síndromes disabsortivas**|
||Deficiência da síntese de 1,25(OH)2D|<br>Doença celíaca|  
||Resistência à vitamina D|<br>Doenças inflamatórias intestinais|
|---|---|---|
|**FOSF**<br>|**OPÊNICOS**|**Medicamentos que interferem no metabolismo da**<br>**vitamina D, do cálcio e do fósforo**<br><br>Glicocorticoides sistêmicos|
|**Doença**|**s metabólicas hereditárias**|<br>Anticonvulsivantes (fenobarbital, fenitoína,|
||Raquitismos hipofosfatêmicos (RH)|carbamazepina)|
||Aumento da excreção renal de fósforo<br>- RH ligado ao cromossoma X|<br>Antiácidos (contendo cálcio, fosfato ou alumínio;<br>inibidores da bomba de próton)|
||- RH autossômico dominante<br>- RH autossômico recessivo|<br>Antirretrovirais: tenofovir, lopinavir<br>|
||- Síndrome de McCune Albright|**Doenças crônicas**|
||- Síndrome do nevus epidérmico|<br>Hepatopatias|
|||<br>Doença renal crônica<br><br>HIV/AIDS|
|||**FOSFOPÊNICOS**|
|||<br><br>Osteomalácia induzida por tumor produtor de<br>FGF23|  
25OHD: calcidiol; 1,25(OH)2D: calcitriol; FGF23: fator de crescimento do fibroblasto 23.  
Em relação à epidemiologia, principalmente por serem doenças subdiagnosticadas, há escassez de dados epidemiológicos no Brasil sobre o raquitismo e a osteomalácia. Estudos brasileiros mostraram heterogeneidade na prevalência de hipovitaminose D, que varia conforme a localização geográfica da população estudada, sexo e idade, entre outros fatores<sup>29,30</sup> . Um dos motivos dessa heterogeneidade é o ponto de corte utilizado para definir a suficiência em vitamina D. Enquanto alguns grupos caracterizam a suficiência em vitamina D para valores da 25-hidroxivitamina D acima de 20 ng/mL, outros usam o ponto de corte de 30 ng/mL. Atualmente, o consenso da Sociedade Brasileira de Endocrinologia e Metabologia e da Sociedade Brasileira de Patologia Clínica propõe que para indivíduos jovens e saudáveis, o ponto de corte para se definir suficiência em vitamina D seja de 20 ng/mL<sup>31</sup> .  
Um estudo realizado em 2004 mostrou que cerca de 78% dos pacientes internados no Hospital das Clínicas em Porto Alegre apresentaram deficiência de vitamina D moderada a grave<sup>32</sup> . Em 2008, outro estudo realizado na mesma cidade com moradores de lares para idosos apresentou prevalência de deficiência de vitamina D de 85%<sup>33</sup> . Em Belo Horizonte, a prevalência de hipovitaminose D encontrada foi de 42,4% em pacientes ambulatoriais<sup>34</sup> . Em adultos na cidade de São Paulo observou-se um pico nas concentrações séricas de vitamina D no outono e o nadir (valores mais baixos) na primavera, refletindo o padrão de insolação de raios ultravioletas (UV) sobre a população na estação anterior<sup>35,36</sup> . Um estudo investigando o status da vitamina D em diferentes cidades brasileiras, localizadas em latitudes distintas (Recife, Salvador, Rio de Janeiro, São Paulo, Curitiba e Porto Alegre), identificou que, nas cidades mais ao norte (Recife e Salvador), os níveis de vitamina D foram significativamente maiores do que no Rio de Janeiro, São Paulo, Curitiba e Porto Alegre. A prevalência de inadequação de vitamina D (abaixo de 20 ng/mL)  
aumentou progressivamente com as latitudes mais ao sul, atingindo um pico de prevalência de 24,5% em Porto Alegre. Esta prevalência foi muito superior a encontrada em Recife e Salvador<sup>37</sup> .  
A incidência global de HLX é estimada em 1 a cada 20.000-25.000 indivíduos<sup>38</sup> . A partir de dados demográficos brasileiros, considerando uma base populacional de 211,5 milhões de habitantes, e da prevalência referida de HLX em populações de outros países, a estimativa de indivíduos com HLX no Brasil variou de 211 até 1.900 indivíduos<sup>39,40</sup> . Um estudo recente realizado no Estado do Paraná estimou que a população com HLX neste estado era de 57 crianças e adultos em 2018, correspondendo a 5 casos por milhão de habitantes<sup>31</sup> . Entretanto, estas estimativas devem ser consideradas com cautela, visto que o estudo indica algumas limitações como cobertura de registro dos casos de HLX; ausência de um registro de doenças raras no Brasil; e dificuldades de acesso aos serviços de saúde por estes pacientes<sup>31</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos do raquitismo e osteomalácia, incluindo o HLX. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E55.0 Raquitismo ativo  
- E55.9 Deficiência não especificada de vitamina D  
- E64.3 Sequelas do raquitismo  
- E83.3 Distúrbios do metabolismo do fósforo  
- M83.0 Osteomalácia puerperal  
- M83.1 Osteomalácia senil  
- M83.2 Osteomalácia do adulto devido à má-absorção  
- M83.3 Osteomalácia do adulto devido à desnutrição  
- M83.8 Outra osteomalácia do adulto

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3. DIAGNÓSTICO** -->
O diagnóstico de raquitismo e da osteomalácia é feito com base nos fatores de risco, predisposição genética, histórico alimentar e apresentação clínica, e confirmado por marcadores bioquímicos e radiológicos e, se necessário, histomorfométrico e genético.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3.1. Diagnóstico clínico** -->
O indivíduo na faixa etária pediátrica que apresenta raquitismo, seja genético ou adquirido, costuma nascer com peso e comprimento adequados para a idade gestacional e a doença se manifesta nos primeiros meses de vida (no caso do genético) ou quando o insulto ambiental se impõe (no caso do adquirido). As manifestações iniciais incluem redução na velocidade de crescimento, a qual pode levar à baixa estatura, fraqueza muscular, dores musculoesqueléticas (difícil de se caracterizar em lactentes) e o aparecimento de deformidades esqueléticas que mais comumente atingem os membros superiores e inferiores, com comprometimento do desenvolvimento motor do indivíduo. Os sinais clínicos típicos de raquitismo em geral são encontrados em quadros mais avançados e incluem atraso no fechamento das fontanelas; craniotabes; rosário raquítico (edema das junções  
costocondrais); sulcos de Harrison (causados pela tração dos músculos diafragmáticos nas costelas); alargamento dos punhos, joelhos e tornozelos; curvatura progressivas do rádio, ulna, fêmur e da tíbia<sup>14</sup> . As alterações em membros inferiores costumam aparecer quando as crianças começam a deambular.  
Além disso, podem ser visualizadas alterações específicas de acordo com as causas do raquitismo. Nos pacientes com raquitismo calciopênico pode-se observar hipoplasia do esmalte dentário, diminuição do tônus muscular e maior risco de infecções<sup>14</sup> . Os abscessos dentários são mais comuns em pacientes com HLX e, por isso, as intervenções odontológicas cirúrgicas são intervenções recorrentes para estes pacientes<sup>42</sup> . Nos pacientes com raquitismo dependente de vitamina D tipo II, frequentemente se observa alopecia universal<sup>43</sup> .  
Na infância e adolescência, a osteomalácia ocorre concomitantemente ao raquitismo. No adulto, ela pode ser assintomática ou estar associada a sintomas inespecíficos como dores, fraturas ósseas ou fraqueza muscular. A dor óssea é geralmente mais pronunciada na coluna lombar, pelve e extremidades inferiores, e devido à intensa fragilidade óssea podem ocorrer fraturas com trauma mínimo. Um sinal clínico importante é dor à palpação desses locais. A fraqueza muscular caracteristicamente é proximal e associada com hipotonia muscular e desconforto à movimentação, podendo inclusive ser limitante e comprometer a deambulação<sup>44</sup> . As deformidades esqueléticas, nos casos graves, podem ser múltiplas e extensas. Na maioria dos casos, há dificuldade de diagnóstico precoce dos pacientes adultos com osteomalácia por serem oligo ou assintomáticos, fazendo com que os pacientes cheguem aos serviços de saúde com quadros graves de múltiplas fraturas.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3.2. Diagnóstico laboratorial** -->
O diagnóstico laboratorial do raquitismo e osteomalácia é feito a partir da avaliação dos marcadores bioquímicos do osteometabolismo e inclui a dosagem sérica de vitamina D (sendo o metabólito a 25-hidroxivitamina D utilizado na maior parte dos casos e reservando-se a dosagem da 1,25(OH)2-vitamina D para casos específicos), cálcio, fósforo, fosfatase alcalina, hormônio da paratireoide (PTH),  dosagem das enzimas do fígado alanina-aminotransferase (ALT/TGP) e aspartatoaminotransferase (AST/TGO), creatinina (para avaliação de nefropatias e cálculo da excreção urinária de cálcio e fósforo), ureia, potássio e gasometria venosa (para investigação das acidoses tubulares renais)<sup>45</sup> . Faz parte da investigação também a dosagem urinária de cálcio, fosfato, clearance de creatinina, medida do pH e da densidade urinária e avaliação da presença de glicosúria e proteinúria<sup>46,47</sup> . O **Quadro 2** apresenta as alterações características nos exames de acordo com o tipo de raquitismo e osteomalácia.  
**Quadro 2 -** Alterações laboratoriais nas diferentes causas de raquitismo e osteomalácia<sup>48</sup>  
|**Causa/ exame**|**Cálcio**<br>**sérico**|**Fósforo**<br>**sérico**|**PTH**|**25-**<br>**hidroxivitamina**<br>**D**|**Fosfatase**<br>**alcalina**|**Fosfatúria**|**Calciúria**|
|---|---|---|---|---|---|---|---|
|**Deficiência de**<br>**vitamina D**|N ou ↓|↓|↑|↓|↑|↓|↓|
|**Dependente de**<br>**Vitamina D (I)**|↓|↓|↑|N ou ↑|↑|↑|↓|
|**Dependente de**<br>**Vitamina D (II)**|↓|↓|↑|↑|↑|↑|↓|
|**Perda de fósforo**|N|↓|N|N|↑ou ↓|↑|N ou ↑|
|**Acidose metabólica**|N|↓|↑|N|N|↑|↑|
|**Hipofosfatasia**|N|N|N|N|↓|N|N|  
↓, baixo; ↑, elevado; N, normal, PTH: hormônio da paratireoide, Hipofosfatasia: deficiência da enzima fosfatase alcalina.  
O Consenso Global sobre Prevenção e Manejo do Raquitismo Nutricional<sup>49</sup> recomenda a classificação do status da vitamina D, com base nos níveis séricos de 25-hidroxivitamina D ( **Tabela 1** ). Esta classificação permite o diagnóstico correto, o reconhecimento da causa e a escolha da melhor intervenção a cada indivíduo.  
**Tabela 1 -** Consenso global para definição do status de vitamina D  
|**Status de vitamina D**|**Níveis séricos de 25-hidroxivitamina D**|
|---|---|
|Suficiência|acima de 20 ng/mL|
|Insuficiência|12 – 20 ng/mL|
|Deficiência|abaixo de 12 ng/mL|  
Fonte: Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. J Clin Endocrinol Metab [Internet]. 2016 Feb;101(2):394–415. Available from: https://academic.oup.com/jcem/articlelookup/doi/10.1210/jc.2015-2175.  
Para o diagnóstico das formas de raquitismo ou osteomalácia secundárias à perda renal de fósforo, é importante o cálculo da taxa de reabsorção tubular de fósforo (TRP) que é feito a partir da seguinte fórmula:  
TRP = (1 – fração de excreção de fósforo) x 100  
TRP = {1 – [(P _u_ x Cr _p_ )/(P _p_ x Cr _u_ )]} x 100, em que P _u_ é concentração de fósforo urinário (em mg/dL), Cr _p_ é concentração de creatinina plasmática (em mg/dL), P _p_ é a concentração de fósforo plasmático (em mg/dL) e Cr _u_ é a concentração de creatinina urinária (em mg/dL).  
A fosfatúria é considerada aumentada, isto é, hiperfosfatúria, quando a TRP está abaixo de 85% em pacientes com hipofosfatemia<sup>50</sup> . Entretanto, alguns pacientes pediátricos com raquitismo hipofosfatêmico podem apresentar TRP inapropriadamente normal. Isto acontece por um mecanismo de compensação metabólica, quando valores muito baixos de fosfatemia desencadeiam um aumento compensatório da reabsorção tubular renal desse eletrólito para tentar normalizá-lo. Nestes casos, utiliza-se uma forma de avaliação do equilíbrio renal do fosfato mais precisa, por meio do cálculo da taxa máxima de reabsorção de fosfato corrigida pela taxa de filtração glomerular (TmP/GFR). As fórmulas para o cálculo da TmP/GFR são descritas abaixo e os valores dos intervalos normais para máximo tubular para fosfato corrigido para GFR são apresentados na **Tabela 2**<sup>51</sup> .  
- Se TRP ≤ 0,86 (86%): TmP/GFR = TRP x fosfato sérico  
- Se TRP > 0,86 (86%): TmP/GFR = [(0,3 x TRP) / (1 - (0,8 x TRP))] x fosfato sérico  
**Tabela 2 -** Intervalos para da taxa máxima de reabsorção de fosfato corrigida pela taxa de filtração glomerular (TmP/GFR)  
|**Idade**|**TmP/GFR**|
|---|---|
||**Valores para ambos os sexos (mg/dL)**|
|Recém-nascido|5,7 – 8,1|
|1 mês - 2 anos|3,6 - 5,4|
|2-12 anos|3,8 – 5,0|
|12-16 anos|3,4 – 4,6|
|15-25 anos|3,3 - 5,9|
|25-45 anos|3,09 - 4,18|
|45-65 anos|2,78 - 4,18|  
65-75 anos  
2,47 - 4,18  
Fonte: Chong WH, Molinolo AA, Chen CC, Collins MT. Tumor-induced osteomalacia. Endocr Relat Cancer [Internet]. 2011 Jun;18(3):R53–77. Available from: https://erc.bioscientifica.com/view/journals/erc/18/3/R53.xml  
As concentrações séricas normais (próximas ao limite inferior) de fosfato em crianças com raquitismo nutricional podem ser observadas na fase intermediária da doença. Esse fato decorre da intensa desmineralização óssea provocada pelo hiperparatireoidismo secundário, que provê fosfato à circulação e pode elevar transitoriamente a fosfatemia. Em seguida, essas concentrações diminuem na fase avançada, devido à manutenção da hiperfosfatúria desencadeada pelo hiperparatireoidismo e da deficiência de absorção intestinal de fosfato secundária à hipovitaminose D<sup>52,53</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3.3. Diagnóstico radiológico** -->
A avaliação radiológica de ossos longos é parte essencial da investigação do paciente com suspeita de raquitismo ou osteomalácia. As alterações radiológicas do raquitismo são mais bem visualizadas nas placas de crescimento dos ossos com crescimento rápido, como na ulna distal e nas metáfises dos joelhos. Os sinais iniciais são o alargamento das metáfises ósseas (sinal da taça) e a perda da definição da zona entre a epífise e a metáfise. Com a progressão da doença, podem aparecer outros sinais como escavações, cistos e desorganização da placa de crescimento. Outras alterações são: diminuição do padrão de trabeculação óssea, rarefação óssea e corticais finas. Em quadros graves, podem ser encontradas fraturas patológicas e pseudofraturas de Looser, que são zonas com linhas radioluscentes, de 2 a 5 mm de largura, com bordas escleróticas, bilaterais e perpendiculares à margem cortical do osso e que representam fraturas de insuficiência em regiões de sobrecarga mecânica<sup>44</sup> . Um aspecto diferencial é que no paciente com HLX as radiografias de ossos longos podem mostrar espessamento do osso cortical, em contraste com o adelgaçamento observado no raquitismo nutricional.  
Outro sinal radiológico bastante característico, mas atualmente pouco visto, encontrado em casos mais graves e crônicos, é o rosário raquítico, observado à inspeção física e à radiografia posteroanterior do tórax. Esse sinal corresponde a lesões proeminentes em forma de contas de um rosário, sendo que cada conta representa o alargamento e edema da junção costocondral.  
A osteomalácia pode apresentar-se radiograficamente com importante rarefação óssea. Um achado comum, porém, não muito específico, é o adelgaçamento da cortical do osso. Achados radiológicos mais específicos são as alterações em corpos vertebrais e as pseudofraturas de Looser, que são o achado radiológico mais característico da osteomalácia e são mais frequentemente encontradas no colo femoral, embora também possam ser encontradas em outros ossos. Os corpos vertebrais apresentam-se com perda da trabeculação óssea e consequente aparência de uma radiografia de baixa qualidade. Com o avanço da doença, as vértebras mostram-se grandes e biconvexas<sup>48</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3.4. Diagnóstico histomorfométrico** -->
O exame padrão-ouro para o diagnóstico de raquitismo e osteomalácia é a análise histomorfométrica óssea, com marcação por tetraciclina. Esse antibiótico é administrado em dois momentos ao paciente para avaliar a taxa de crescimento ósseo. Ele é depositado como uma banda no local de mineralização e, como é fluorescente, pode ser visto ao microscópio. Pode-se então medir a distância entre duas bandas de tetraciclina e estimar a taxa de crescimento do osso naquele intervalo de tempo entre as duas administrações do antibiótico. O valor normal é de 1 micrometro/dia. Para o diagnóstico, deve-se caracterizar a diminuição da distância entre as bandas de tetraciclina e o aumento relevante do osteoide (matriz não mineralizada)<sup>48</sup> . Apesar de ser considerado padrão-ouro, a avaliação histomorfométrica é raramente empregada em função de ser um exame invasivo e pouco acessível, e de haver outras possibilidades diagnósticas com base em critérios clínicos, laboratoriais e radiológicos. Dessa forma, o exame de histomorfometria óssea é reservado para os casos de maior complexidade, nos quais não há correlação clínicolaboratorial, e com forte suspeita clínica não confirmada nos exames laboratoriais.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3.5. Diagnóstico genético** -->
Quando os achados clínicos, bioquímicos e radiográficos sugerem o diagnóstico de HLX ou outra forma genética do raquitismo ou osteomalácia, o teste genético é preconizado<sup>42,54</sup> . No HLX, mutações no gene _PHEX_ causam o aumento na síntese e diminuição na degradação do FGF-23. O excesso de FGF-23 inibe a proteína cotransportadora de sódio e fosfato nos túbulos renais proximais (NPT2a e NPT2c), causando aumento na excreção urinária de fosfato, e inibe a expressão do gene _CYP27B1_ , responsável por codificar a enzima 1-alfa-hidroxilase, consequentemente, inibindo a síntese de calcitriol e a absorção intestinal de fosfato<sup>55</sup> . O excesso de FGF-23 também inibe parcialmente a síntese de PTH, fazendo com que nesse tipo de raquitismo o PTH esteja próximo ou pouco acima do limite superior, diferente dos outros tipos, nos quais esse hormônio encontra-se bastante elevado.  
A análise genética do paciente com suspeita de HLX pode ser feita pelo sequenciamento do gene _PHEX_ ou pela realização de um painel genético para raquitismo, que engloba uma série de genes associados a diferentes causas de raquitismo, incluindo o gene _PHEX._ A técnica preferencial para análise do gene _PHEX_ é por sequenciamento de nova geração (NGS). Nos casos de NGS negativo, está indicado MLPA ( _Multiplex Ligation-dependent Probe Amplification_ ) do gene _PHEX_ para pesquisa de variação do número de cópias (CNV)<sup>56</sup> . Diferentes tipos de variantes já foram descritos no gene _PHEX_ . Os protocolos de sequenciamento ou análise de CNV devem seguir os padrões de boas práticas laboratoriais e as variantes identificadas devem ser de acordo com a proposta do _American College of Medical Genetics_ (ACMG).  
A identificação de variantes deve ser interpretada por laboratório experiente e por médico capacitado. O médico geneticista faz parte da equipe multiprofissional que avalia estes pacientes apresentando _expertise_ para correlação genótipofenótipo.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste PCDT pacientes com diagnóstico clínico, laboratorial, radiológico e, quando aplicável, genético, de raquitismo ou osteomalácia, conforme o item “3. Diagnóstico”.  
Para que o paciente seja elegível ao tratamento com calcitriol requer-se, adicionalmente, a presença de um dos seguintes critérios:  
a) Crianças e adolescentes sem resposta à reposição com vitamina D2 ou D3 e cálcio (ver o sub-item “7.3 Benefícios  
Esperados”), devido à raquitismo ou osteomalácia:  
- Dependente de vitamina D tipo I (déficit de síntese de 1,25-dihidroxivitamina D);  
- dependente de vitamina D tipo II (resistência à ação da 1,25-dihidroxivitamina D);  
- secundários à hipofosfatemia dependente de FGF-23 não hipercalciúrica;  
- secundários à doença hepática; ou  
- secundários a tumor produtor de FGF-23 (osteomalácia induzida por tumor);  
- b) Adultos com raquitismo ou osteomalácia e com dor óssea ou fraturas que não se consolidam ou com hipofosfatemia secundária a medicamentos.  
Para que o paciente seja elegível ao tratamento com burosumabe, deve preencher o seguinte critério:  
- Diagnóstico genético de HLX e ter entre um ano e 17 anos de idade.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Intolerância, hipersensibilidade ou contraindicação excluem os pacientes do uso do respectivo medicamento preconizado neste Protocolo.  
Para o tratamento com calcitriol, deverão ser excluídos pacientes com raquitismo hipofosfatêmico hipercalciúrico, uma vez que já podem apresentar concentrações séricas elevadas de calcitriol pelo mecanismo fisiopatogênico da doença, e o uso de calcitriol pode agravar a hipercalciúria.  
Com relação ao tratamento com burosumabe, estão excluídos os pacientes sem resposta terapêutica ou que manifestem algum evento adverso grave ao iniciar o tratamento com este medicamento. Também são excluídos pacientes com insuficiência renal grave ou doença renal em estágio terminal, porque essas condições estão associadas a um metabolismo mineral anormal<sup>57</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **6.1. Tratamento clínico** -->
Os objetivos gerais do tratamento dos diversos tipos de raquitismos e osteomalácia, incluindo o HLX, devem ser centrados no paciente e focar na otimização da sua qualidade de vida, melhora da mobilidade funcional, redução da dor, evitar ou minimizar o risco de procedimentos cirúrgicos ortopédicos e intervenções odontológicas, minimizar o absenteísmo escolar e profissional e contribuir com a integração do indivíduo nas atividades sociais.  
Indivíduos com raquitismo ou osteomalácia de qualquer etiologia devem ser avaliados por uma equipe multidisciplinar, composta por médicos (pediatra, clínico geral, endocrinologista, nefrologista, ortopedista e geneticista), fisioterapeutas, dentistas, nutricionistas e demais profissionais da saúde envolvidos no atendimento físico, psíquico e social desse grupo de pacientes. Os pacientes deverão receber orientações para melhorar hábitos de vida, incluindo possivelmente a reorganização dos hábitos alimentares, exposição correta e segura ao sol (desde que não haja contraindicação), cessação do tabagismo, redução de  
peso, incentivo à atividade física e redução de estresse. Uma dieta saudável com ingestão nutricional adequada de macronutrientes, cálcio, vitamina D e fósforo é preconizada. Exercícios e fisioterapia devem ter como objetivo otimizar ou prevenir a fraqueza muscular, dores nas costas e nas articulações, rigidez articular e mobilidade limitada, visando a melhora da força muscular, estabilidade central, amplitude articular e mobilidade funcional geral<sup>11,12,42,54</sup> .  
Adicionalmente, deve-se enfocar orientações nutricionais, aconselhamento genético em caso de suspeita ou diagnóstico confirmado de raquitismo genéticos, de acordo com a disponibilidade dos exames, e apresentar a Política Nacional de Saúde Bucal para prevenção, tratamento ou acompanhamento de pacientes com alterações orodentais decorrentes de raquitismos e osteomalácia, incluindo especialmente a HLX, na qual o risco de abscessos dentários recorrentes é maior.  
No caso de indivíduos com raquitismo ou osteomalácia secundários a síndromes disabsortivas intestinais, como a doença celíaca e as doenças inflamatórias intestinais (DII), o cuidado consiste na retirada do glúten da dieta (doença celíaca) e no tratamento específico da DII, cujos aspectos fogem ao contexto deste Protocolo.  
Nas situações em que há raquitismo ou osteomalácia induzidos por medicamentos que interferem no metabolismo da vitamina D, do cálcio ou do fósforo, o tratamento do indivíduo consiste na suspensão ou substituição do medicamento causador, de acordo com a doença de base e as condições clínicas do paciente.  
No raquitismo ou osteomalácia secundários às acidoses tubulares renais associadas a tubulopatias, o tratamento consiste na correção da acidose (preferencialmente controlado por nefrologista), podendo ser necessária a reposição de eletrólitos, de acordo com o tipo da tubulopatia. Com exceção da reposição de fosfato, as demais reposições eletrolíticas no paciente com acidose tubular renal não são abordadas neste Protocolo, por serem objeto de discussão específica.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **6.1.1 Tratamento medicamentoso específico** -->
O tratamento do paciente com raquitismo ou osteomalácia depende da causa subjacente. No caso de raquitismo nutricional (carencial), o tratamento em seu contexto maior deve focar no reconhecimento e no tratamento dos fatores ambientais e comportamentais que levaram à doença. O tratamento medicamentoso nessa situação baseia-se na administração de vitamina D2 (ergocalciferol) ou D3 (colecalciferol) e cálcio<sup>58</sup> . Deve-se reforçar que não há indicação de reposição de fosfato no tratamento de indivíduos com raquitismo nutricional, além do fato de essa conduta poder piorar o hiperparatireoidismo secundário desses pacientes.  
Aos indivíduos em situações de risco para hipovitaminose D está indicada a suplementação via oral das necessidades fisiológicas de vitamina D (na forma de D2 ou D3) a partir do primeiro mês de vida, na dose de 400 UI por dia no primeiro ano de vida e 600 UI por dia do segundo ano em diante<sup>59</sup> . Pacientes com deficiência de vitamina D, além da administração de vitamina D nas doses específicas de acordo com a idade, devem receber suplementação adequada de cálcio, correspondendo a pelo menos 500 mg/dia de cálcio elementar<sup>49</sup> . Em situações nas quais a ingestão de cálcio é insuficiente, a suplementação da dieta com esse elemento também se demonstrou eficaz na prevenção do raquitismo<sup>60</sup> .  
A suplementação de vitamina D e cálcio parece alcançar benefícios para evitar fraturas vertebrais e não vertebrais em adultos<sup>61</sup> . Esses efeitos protetores foram mais pronunciados em indivíduos com baixos níveis de 25-hidroxivitamina D (< 10-12 ng/mL) e em uma população de lares de idosos<sup>62</sup> . Pacientes idosos utilizando 700 a 800 UI/dia de vitamina D2 ou D3 oral, com ou sem suplementação de cálcio, apresentaram redução significativa de 26% no risco de sofrer uma fratura de quadril e redução significativa de 23% no risco de sofrer qualquer fratura não vertebral quando comparado ao uso de cálcio sozinho ou placebo<sup>63</sup> .  
O tratamento de indivíduos com raquitismo carencial por deficiência de vitamina D foi avaliado em um estudo controlado randomizado (ECR) levado a cabo na Turquia e na Índia que comparou o uso de cálcio, vitamina D ou a combinação dos dois medicamentos. Nesse estudo, a combinação de tratamentos alcançou níveis séricos de cálcio e fosfatase alcalina melhores que os dois tratamentos separados<sup>64,65</sup> . Entretanto, os grupos que receberam cálcio ou vitamina D isoladamente apresentaram melhora nos níveis de fosfatase alcalina e nas alterações radiológicas na avaliação pré e pós-tratamento<sup>66</sup> . Por outro lado, um ECR de crianças com raquitismo na Nigéria, comparando o tratamento com vitamina D, cálcio ou a combinação de ambos encontrou que as crianças que receberam cálcio e tratamento combinado apresentaram os melhores resultados. Isto é, houve elevação do nível sérico de cálcio e queda no nível sérico de fosfatase alcalina quando comparadas com o grupo que recebeu apenas vitamina D, demonstrando que a ingestão de cálcio é parte importante do tratamento<sup>67</sup> . A adição de vitamina D (50.000 UI por mês) à reposição de cálcio (aproximadamente 938 mg, dividida em duas vezes ao dia) demonstrou tendência de melhora dos resultados radiológicos e laboratoriais (67% no grupo randomizado para vitamina D vs. 44% no grupo placebo, P=0,06) em crianças com raquitismo<sup>68</sup> .  
O uso da forma ativa da vitamina D, o calcitriol, deve ser restrito àquelas situações nas quais sua síntese ou ação estão comprometidos. Nos pacientes com raquitismo resistente à vitamina D (dependente tipo 2), as doses necessárias de calcitriol e a resposta ao tratamento são menos previsíveis, uma vez que dependem do grau de resistência do receptor. Pacientes com raquitismos hipofosfatêmicos decorrentes do excesso de FGF-23 (raquitismo hipofosfatêmico autossômico recessivo, osteomalácia oncogênica) devem ser tratados com calcitriol, uma vez que há inibição da síntese de calcitriol pelo FGF-23, exceto nos casos de raquitismo hipofosfatêmico com hipercalciúria, para os quais está contraindicado<sup>69</sup> .  
Até 2018, os pacientes com HLX tinham como tratamento padrão a reposição de fosfato e calcitriol, denominado tratamento convencional. Atualmente, as evidências científicas mostram que o tratamento de eleição para pacientes pediátricos, com HLX a partir de 12 meses de idade, deve ser o burosumabe. Foram demonstrados benefícios na melhora dos sinais clínicos e radiológicos de raquitismo em crianças, das dores ósseas crônicas, da fraqueza muscular, da mobilidade e do crescimento com tratamento com burosumabe em relação ao tratamento convencional<sup>70–72</sup> .  O tratamento da HLX é continuado pelo menos até a conclusão do crescimento. Atualmente, não há consenso sobre a continuação do tratamento convencional até a idade adulta,  
embora muitas vezes a prática seja fazê-lo, pelo menos, em pacientes que são sintomáticos devido à osteomalácia subsequente que inevitavelmente ocorre após a interrupção do tratamento. No entanto, nem todos os adultos toleram a interrupção do tratamento com poucos sintomas e, pelo menos, por um tempo, muitos desenvolvem sintomas osteomalácicos ativos, dor óssea, fraqueza muscular e pseudofraturas, que demonstram vários graus de melhora durante o tratamento com vitamina D ativa e fosfato. Devido aos riscos conhecidos da terapia com calcitriol e fosfato, a recomendação dos consensos internacionais tem sido de interromper o tratamento no final do crescimento e reiniciá-lo se houver desenvolvimento de manifestações clínicas<sup>73–78</sup> . Portanto, preconiza-se que os pacientes com HLX adultos e sintomáticos recebam o tratamento convencional com reposição de fosfato e calcitriol até que se obtenha o controle dos sintomas.  
Em caso de adultos com osteomalácia, o objetivo principal é a correção da causa básica, quando possível. Concomitantemente, devem ser corrigidos os distúrbios metabólicos decorrentes, a hipocalcemia e a hipofosfatemia. O tratamento, tanto da causa quanto das alterações osteometabólicas, varia conforme o mecanismo responsável pela osteomalácia 79:  
- osteomalácia induzida por medicamentos: suspensão dos medicamentos e reavaliação do uso de substitutos para tratar a  
- doença de base;  
- osteomalácia por deficiência de vitamina D: suplementação com vitamina D2 ou D3;  
- osteomalácia induzida por tumor: localização e exérese do tumor; quando não se identifica o tumor ou o enquanto o tumor  
- não é ressecável, manter o tratamento com calcitriol e fósforo.  
Diversos estudos têm demonstrado que a reposição de vitamina D2 ou D3 em caso de pacientes com deficiência de vitamina D corrige as alterações do metabolismo ósseo, melhora os sintomas e a força muscular<sup>3</sup> e reduz o número de quedas, que é uma causa importante de fraturas.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **6.2. Tratamento cirúrgico** -->
As alterações provocadas pelos diversos tipos de raquitismo/osteomalácia, incluindo o HLX, podem levar à necessidade procedimentos cirúrgicos ortopédicos de correção ao longo da vida do paciente. Portanto, pode ser necessário que estes pacientes sejam acompanhados por ortopedista. Os procedimentos ortopédicos são geralmente indicados para correção de deformidades dos membros inferiores e para o tratamento de fraturas<sup>42</sup> .  
Inexistem evidências disponíveis sobre o uso de dispositivos de crescimento guiado para o tratamento de pacientes com deformidades decorrentes do raquitismo ou osteomalácia, comparado àqueles já disponíveis no SUS. Assim, o uso de dispositivos de crescimento guiado não é preconizado no presente Protocolo ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **7. FÁRMACOS** -->
- Carbonato de cálcio: comprimidos de 1.250 mg (corresponde a 500 mg de cálcio elementar);  
- carbonato de cálcio + colecalciferol: comprimidos de 500 mg de cálcio elementar + 200 UI de D3;  
- carbonato de cálcio + colecalciferol: comprimidos de 500 mg de cálcio elementar + 400 UI de D3;  
- carbonato de cálcio + colecalciferol: comprimidos de 600 mg de cálcio elementar + 400 UI de D3;  
- fosfato de cálcio tribásico + colecalciferol: comprimidos de 600 mg de cálcio + 400 UI;  
- calcitriol: cápsulas de 0,250 microgramas; e  
- burosumabe: solução injetável em frascos de 10 mg/mL, 20 mg/mL ou 30 mg/mL<sup>57</sup> .  
No Brasil não há preparações farmacêuticas industriais prontas de fosfato, sendo necessário que sejam manipuladas em farmácias magistrais. A formulação pode ser prescrita na forma de solução fosfatada ou em cápsulas, cujas fórmulas mais utilizadas são apresentadas nos **qudros 3 e 4** .  
**Quadro 3 -** Fórmula da solução fosfatada (15 mg de fósforo elementar por mL de solução)<sup>80</sup>  
|**Componente**|**Quantidade**|
|---|---|
|Fosfato de sódio monobásico|11,55 g|
|Fosfato de sódio dibásico (anidro)|55,6 g|
|Xarope simples|300 mL|
|Solução conservante|10 mL|
|Essência|1 mL|
|Água destilada|qsp 1.000 mL|  
qsp = quantidade suficiente para  
**Quadro 4 -** Fórmula de cápsula de fósforo (cada cápsula = 250 mg de fósforo elementar)  
|**Componente**|**Quantidade**|
|---|---|
|Fosfato de sódio monobásico|130 mg|
|Fosfato de sódio dibásico (anidro)|852 mg|
|Fosfato de potássio monobásico|155 mg|
|Excipiente|qsp 1 cápsula|  
qsp = quantidade suficiente para

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **7.1. Esquemas de administração** -->
- **Vitamina D:** De forma geral, o tratamento com vitamina D para pacientes com raquitismo e osteomalácia é realizado  
- com suas formas precursoras, vitamina D2 (ergocalciferol) ou D3 (colecalciferol), uma vez que as reações enzimáticas para conversão em calcidiol e calcitriol estão íntegras. Reserva-se o uso do calcitriol às situações em que há comprometimento da síntese ou da atividade da enzima 1-alfa-hidroxilase, responsável pela conversão do calcidiol em calcitriol.  
- **Vitamina D2 ou D3:** São utilizadas no tratamento de crianças, adolescentes e adultos com raquitismo nutricional por  
- deficiência de vitamina D. A recomendação atual da posologia em pediatria é sugerida segundo a faixa etária, conforme descrito

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: na **Tabela 3** . -->
**Tabela 3 -** Doses de Vitamina D2 ou D3 no tratamento do paciente com raquitismo nutricional  
|**Idade**|**Dose diária por 90 dias**|**Em dose única**|**Dose de manutenção**|
|---|---|---|---|
|< 3 meses|2.000 UI|---|400 UI|
|3–12 meses|2.000 UI|50.000 UI|400 UI|
|> 12 meses – 12 anos|3.000–6.000 UI|150.000 UI|600 UI|
|> 12 anos|6.000 UI|300.000 UI|600 UI|  
Fonte: Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. J Clin Endocrinol Metab [Internet]. 2016 Feb;101(2):394–415. Available from: https://academic.oup.com/jcem/articlelookup/doi/10.1210/jc.2015-2175.  
Para adultos com deficiência de vitamina D, vários esquemas posológicos são propostos. Podem ser administradas doses semanais de 50.000 UI por 6 a 12 semanas seguidas de dose de reposição de 2.000 UI por dia. Em pacientes com doenças que cursam com má-absorção, doses maiores podem ser necessárias, de acordo com a resposta clínica e laboratorial. Uma vez que estão disponíveis associações de vitamina D com cálcio, o tratamento deve ser feito com as doses preconizadas, sempre em relação à dose de vitamina D.  
**- Calcitriol:** É o metabólito ativo da vitamina D, produzido nos rins a partir de sua precursora, a 25-hidroxivitamina D. A dose inicial de calcitriol para os pacientes com raquitismo dependente de vitamina D (tipo I) é de 0,01 mcg/kg por dia para crianças com peso menor que 10 kg e 0,02 mcg/kg por dia para crianças acima deste peso e adultos. Essa dose é mantida até resolução das lesões ósseas, e após é prescrita dose de manutenção que varia de 0,25 mcg a 1 mcg/dia. As doses de início e de manutenção podem variar de acordo com a gravidade da doença e a resposta ao tratamento. Os pacientes com raquitismo resistente à vitamina D (dependente tipo II) devem ser tratados inicialmente com 2 mcg de calcitriol e 1.000 mg de cálcio elemento por dia. As doses devem ser individualizadas nesses pacientes conforme a resposta clínica e laboratorial e pode-se chegar a posologias bem elevadas de calcitriol, de acordo com o grau de resistência do receptor de vitamina D. Em pacientes com doença hepática grave, na qual a síntese de calcidiol está comprometida, pode-se iniciar o calcitriol com doses de 0,01 a 0,02 mcg/kg por dia, com ajustes baseados na resposta clínica e laboratorial.  
Nos casos de raquitismo hipofosfatêmico secundário ao excesso de FGF-23, a dose preconizada de calcitriol é de 0,03 a 0,07 mcg/kg/dia, em uma ou duas tomadas diárias<sup>82</sup> . Os pacientes com raquitismo hipofosfatêmico com hipercalciúria não devem receber calcitriol, pois já apresentam esses níveis elevados<sup>83</sup> .  
**- Cálcio:** A administração de 500 mg por dia de cálcio elementar, seja na forma de ingestão dietética ou de suplemento, deve ser prescrita junto à reposição de vitamina D no tratamento do raquitismo nutricional, independentemente da idade ou do peso do paciente pediátrico<sup>81</sup> .  
- **Carbonato de cálcio** : Comprimido revestido de 1.250 mg de carbonato de cálcio (equivalente a 500 mg de cálcio elementar) indicado para a complementação das necessidades de cálcio no organismo, em estados deficientes e para o tratamento de hipocalcemia. A dose recomendada em bula é de um comprido por dia para crianças e adultos, sendo que corresponde a 100% da Ingestão Diária Recomendada (IDR) para crianças de 1 a 3 anos; a 83% da IDR para crianças de 4 a 6 anos; a 71% da IDR para crianças de 7 a 10 anos e a 50% da IDR para adultos<sup>84</sup> . Os comprimidos de carbonato de cálcio podem estar associados à vitamina D3 em algumas formulações.  
**- Fósforo:** A dose de fósforo preconizada para o tratamento de formas de raquitismo decorrentes da perda urinária aumentada de fósforo é de 30 a 60 mg/kg/dia de fósforo elementar. Em adolescentes na fase final do crescimento e em adultos, a dose é mais baixa, em torno de 20 mg/kg por dia. Deve-se iniciar com doses mais baixas e promover um aumento gradativo de acordo com a resposta clínica e laboratorial (dosagem de PTH e da fosfatase alcalina). Importante lembrar que, no caso de raquitismo hipofosfatêmico associado a excesso de FGF-23, não se deve tentar normalizar a fosfatemia, pois a perda urinária excessiva de fosfato se mantém. O uso excessivo de fosfato pode desencadear hiperparatireoidismo secundário e até terciário (funcionamento autonômico das paratireoides). O fósforo deve ser administrado de quatro a seis vezes por dia para pacientes com a forma de raquitismo mencionada acima, com intervalo de cerca de 1 a 2 horas entre a administração do fosfato e a ingestão de leite<sup>85</sup> . Deve-se reforçar que não há indicação de reposição de fosfato em pacientes com raquitismo carencial.  
**- Burosumabe:** Pode ser iniciado para pacientes com HLX a partir de um ano de idade e adolescentes até 18 anos incompletos. Para pacientes em tratamento convencional com reposição de fosfato e calcitriol, este deve ser interrompido sete a dez dias antes do início do burosumabe, uma vez que são terapias excludentes. Para pacientes com peso inferior a 10 kg, a dose inicial do burosumabe é 1 mg/kg de peso corporal, administrado por via subcutânea a cada 14 dias. Para pacientes com peso superior a 10 kg, o esquema de dose inicial preconizada é de 0,8 mg/kg do peso corporal, a cada 14 dias, ajustando o valor para o múltiplo de 10 mais próximo. Deve-se respeitar a posologia máxima de 90 mg por dose para pacientes com mais de 56 kg de  
peso. No caso de não se atingir a normalização da fosfatemia, deve-se seguir o cronograma de ajuste da dose descrito nas **Tabela 4** e **Tabela 5** para manter o fósforo sérico dentro do intervalo de referência para a idade. Se o fósforo sérico estiver acima do intervalo normal, suspender a próxima dose e reavaliar o nível de fósforo sérico no período de 4 semanas. O paciente precisa ter fósforo sérico abaixo do intervalo normal para poder reiniciar o tratamento com burosumabe<sup>86</sup> . Não é necessário que o paciente tenha passado por algum tratamento prévio para iniciar o uso de burosumabe pois, para este grupo específico, seu uso é o tratamento de primeira linha.  
**Tabela 4 -** Orientação posológica para início da terapia e ajustes de dose com burosumabe para pacientes que pesam mais de 10 kg  
|**Peso corporal (kg)**|**Dose de início**|**Primeiro aumento de dose**|**Segundo aumento de dose (mg)**|
|---|---|---|---|
||**(mg)**|**(mg)**||
|**10-14**|10|15|20|
|**15-18**|10|20|30|
|**19-31**|20|30|40|
|**32-43**|30|40|60|
|**44-56**|40|60|80|
|**57-68**|50|70|90|
|**69-80**|60|90|90|
|**81-93**|70|90|90|
|**94-105**|80|90|90|
|**106 ou maior**|90|90|90|  
Fonte: Bula do medicamento burosumabe<sup>86</sup>  
**Tabela 5 -** Orientação posológica para reinício da terapia com burosumabe  
|**Dose anterior (mg)**|**Dose de reinício (mg)**|
|---|---|
|10|5|
|15|10|
|20|10|
|30|10|
|40|20|
|50|20|
|60|30|
|70|30|
|80|40|
|90|40|  
Fonte: Bula do medicamento burosumabe<sup>86</sup>

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **7.2. Tempo de tratamento (critérios de interrupção)** -->
Nos casos de pacientes com raquitismo e osteomalácia secundários à deficiência de vitamina D, o tratamento deve ser mantido até a normalização das alterações bioquímicas, radiológicas e a resolução dos sintomas. Após esse período, o paciente deve utilizar uma dose de manutenção, não sendo mais necessárias doses para reposição de deficiência.  
Nos casos de pacientes que têm indicação para o uso de calcitriol, o tratamento deve ser mantido até o término do crescimento dos adolescentes. Na fase adulta, esses pacientes devem ser tratados se apresentarem sintomas de dor óssea ou fraturas que não consolidam.  
Os pacientes com raquitismo, HLX e osteomalácia precisam ser avaliados individualmente quanto à necessidade de reposição de cálcio, fósforo e calcitriol ao longo da vida.  
Em caso de pacientes pediátricos nos quais o fechamento epifisário ainda não ocorreu, orienta-se uma avaliação cuidadosa para se definir quanto à suspensão ou manutenção do tratamento com burosumabe. Pacientes adolescentes em uso do medicamento e que tenham completado 18 anos podem continuar o tratamento com burosumabe, desde que apresentem benefício clínico. Também se orienta uma avaliação quanto à suspensão de burosumabe se vier a ocorrer alguma das seguintes situações: hiperparatireoidismo, nefrocalcinose, fratura ou pseudofratura. Pode ser necessária a interrupção ou redução da dose do burosumabe com base nos níveis séricos de fósforo ou em caso de falha ao tratamento. Nestes casos, os pacientes voltam a fazer o uso do tratamento convencional com reposição de fosfato e calcitriol. Se o fósforo sérico estiver acima do intervalo normal, deve-se suspender a próxima dose e reavaliar o nível de fósforo sérico no período de quatro semanas. O paciente precisa ter atingido o fósforo sérico abaixo do intervalo normal para poder reiniciar o tratamento com burosumabe<sup>57</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **7.3. Benefícios esperados** -->
Nos casos dos raquitismos e osteomalácia secundários à deficiência nutricional de cálcio e de vitamina D, com a resolução da causa, com a instituição do tratamento não medicamentoso e com a terapia de reposição de vitamina D e cálcio, espera-se resolução dos sintomas, das alterações bioquímicas associadas, da mineralização óssea e melhora das deformidades esqueléticas (de acordo com o grau das deformidades e com o tempo em que se instalaram). A normalização da hipofosfatemia é o primeiro sinal mensurável na avaliação bioquímica do paciente e deve ocorrer até 14 dias após instituída a suplementação de vitamina D. Ainda, a normalização da excreção urinária de cálcio é um indicador relevante da melhora dos níveis de vitamina D.  
O tratamento convencional das formas fosfopênicas de raquitismo promove redução dos níveis plasmáticos de fosfatase alcalina, que podem atingir a faixa de normalidade ou situar-se discretamente acima dos valores normais. Por outro lado, o tratamento não resulta em normalização dos níveis plasmáticos de fósforo ou da reabsorção tubular de fosfato. Apesar de poder melhorar parcialmente as manifestações clínicas e radiológicas do paciente, o tratamento convencional não restaura totalmente o ritmo de crescimento e metade dos pacientes chegam à vida adulta com baixa estatura. Em alguns pacientes, as deformidades ósseas secundárias podem ser prevenidas ou até mesmo corrigidas com o tratamento convencional, mas não é a regra<sup>82</sup> .  
As evidências científicas mais atuais e de melhor consistência mostram que o tratamento com burosumabe mostra-se eficaz e seguro em caso de paciente pediátrico com HLX e promove normalização da taxa de excreção urinária de fosfato, da fosfatemia, da síntese de calcitriol, na melhora da mineralização óssea do paciente, no controle das dores ósseas e da fraqueza muscular, além de redução da necessidade de intervenções ortopédicas e odontológicas<sup>70,87,88</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **8. MONITORAMENTO** -->
Em caso de pacientes com raquitismo e osteomalácia carencial em terapia com vitamina D, deve-se monitorar os níveis séricos de cálcio, fósforo, fosfatase alcalina e PTH, assim como as dosagens de níveis urinários de cálcio e fósforo duas e quatro semanas após o início do tratamento, objetivando-se avaliar a tendência da resposta terapêutica. O primeiro eletrólito a se normalizar é o fosfato (até o final da segunda semana). Após essas primeiras avaliações, esses exames devem ser repetidos em três meses juntamente com radiografias dos principais sítios atingidos (punhos e joelhos) para avaliação de resolução das lesões. A normalização da fosfatase alcalina é mais lenta, podendo levar até 6 a 12 meses.  
As crianças e adolescentes tratados com calcitriol devem ser monitorizadas mensalmente nos primeiros três meses após início do tratamento, com dosagem de níveis séricos de cálcio, fósforo, fosfatase alcalina, PTH e dosagem de níveis urinários de cálcio, devido ao risco de hipercalcemia e hipercalciúria, que podem levar à litíase renal e nefrocalcinose. Posteriormente, essas avaliações bioquímicas devem acontecer a cada três ou seis meses, de acordo com as condições clínicas do paciente. O cálculo da relação cálcio/creatinina urinária em amostra isolada é um método prático de avaliação do nível de calciúria do paciente. Os valores de referência são descritos na **Tabela 6** .  
**Tabela 6 -** Valores de referência da razão cálcio: creatinina urinária, ajustados para a idade, para avaliação do grau de calciúria do paciente.  
|**Idade**|**Valores para ambos os sexos**<br>**(em mg/mg de creatinina)**|
|---|---|
|1 a 12 meses|0,03 a 0,81|
|13 a 23 meses|0,03 a 0,56|
|24 a 35 meses|0,02 a 0,50|
|3 a 4 anos|0,02 a 0,41|
|5 a 6 anos|0,01 a 0,30|
|7 a 9 anos|0,01 a 0,25|
|10 a 14 anos|0,01 a 0,24|
|Maior que 14 anos|0,01 a 0,24|  
Fonte: Journal of Pediatrics, 131 (2): 252-7,1997.  
Pacientes em uso de calcitriol também devem realizar ultrassonografia de rins e vias urinárias a cada 12/24 meses, devido ao risco aumentado de litíase renal nefrocalcinose.  
Radiografias dos sítios esqueléticos com lesões do raquitismo/osteomalácia devem ser feitas no primeiro mês e três meses após o início do tratamento. Essas avaliações devem ser feitas em menos tempo naqueles pacientes em uso de doses elevadas de calcitriol. Na fase de manutenção do tratamento, as avaliações devem ser realizadas trimestralmente e a dose ajustada para alcance da resposta terapêutica.  
Os principais potenciais eventos adversos do tratamento com vitamina D ou seus análogos são a hipercalcemia e a hipercalciúria, que podem levar à litíase renal e nefrocalcinose. O calcitriol está associado a taxas mais elevadas dessas complicações e por isso o monitoramento bioquímico sérico e urinário dos pacientes deve ser mais rigoroso. Nos casos de intoxicação por vitamina D ou na presença de efeitos de superdosagem, o medicamento deve ser suspenso ou ter sua dose reduzida.  
A reposição de fósforo pode apresentar eventos adversos transitórios como dor abdominal e diarreia. Além disso, a palatabilidade das formas disponíveis de fósforo para reposição dificulta o seu uso. O tratamento desses tipos de raquitismo deve ser interrompido uma semana antes dos procedimentos cirúrgicos ortopédicos eletivos, com o intuito de se prevenir a hipercalcemia secundária à imobilização prolongada no pós-operatório. Outras complicações relacionadas a essas doenças e ao seu tratamento incluem o hiperparatireoidismo secundário e terciário e a nefrocalcinose, relacionadas ao uso de dose excessiva de fósforo com hipocalcemia secundária que estimula a secreção de PTH. Por essas razões, os pacientes devem ser avaliados trimestralmente por meio de exame clínico e dosagens séricas de cálcio, fósforo, creatinina e fosfatase alcalina. Dosagens urinárias de cálcio, fósforo e creatinina também são importantes. A dosagem de PTH e a ultrassonografia renal devem ser realizadas anualmente<sup>82</sup> . Se o paciente apresentar hiperparatireoidismo terciário ou nefrocalcinose, deve ser avaliado para o controle dessas complicações.  
Os principais eventos adversos do tratamento com burosumabe são: febre, reação no local da injeção, tosse, vômito, dor nas extremidades, dor de cabeça, dor nas costas, abscesso dentário, cáries dentárias, diarreia, diminuição da vitamina D, constipação, erupção cutânea, náusea, tonturas, síndrome das pernas inquietas, espasmos musculares e fósforo sérico aumentado (podendo ser associado com maior risco de nefrocalcinose)<sup>86</sup> . Sendo assim, para pacientes que já estão usando o burosumabe, pode ser necessária a interrupção ou redução da dose com base em seus níveis séricos de fósforo. O monitoramento clínico, bioquímico e radiológico em pacientes pediátricos em uso de burosumabe deve seguir as orientações do **Quadro 5** .  
**Quadro 5 -** Protocolo de acompanhamento clínico, bioquímico e radiológico do paciente em terapia com burosumabe  
|**Tempo de tratamento**|**Avaliação metabólica***|**Avaliação radiológica****|**Avaliação**<br>**antropométrica*****|
|---|---|---|---|
|Basal|X|X|X|
|15 dias|X|||
|1 mês|X||X|
|2 meses|||X|
|3 meses|X||X|
|6 meses|X|X|X|
|12 meses|X|X|X|
|18 meses|X||X|
|após|semestral|a cada ano|semestral|  
*Avaliação metabólica: sérica (Ca, P, Fosfatase alcalina, PTH, Cr; 1,25(OH)2Vitamina D); urinária (Ca, P, Cr); cálculo da TmP/GFR).  
**Avaliação radiológica: radiografia de punhos, joelhos; ultrassonografia de rins e vias urinárias.  
***Avaliação antropométrica: peso, comprimento/estatura, distância intercondilar, distância intermaleolar. Fonte: Elaboração própria.  
O intervalo entre as consultas e a solicitação de exames complementares necessários para avaliação da eficácia e segurança do tratamento ao longo do acompanhamento depende da etiologia do raquitismo ou osteomalácia e da resposta de cada paciente. Geralmente, os pacientes são reavaliados 6 meses após o início do tratamento e, depois, anualmente, a depender das condições clínicas e necessidades do paciente.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento.  
Os procedimentos diagnósticos (Grupo 02), terapêuticos clínicos (Grupo 03) e terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos colaterais relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **11. REFERÊNCIAS** -->
1. Uday S, Högler W. Nutritional rickets &amp; osteomalacia: A practical approach to management. Indian Journal of Medical Research. 2020;152(4):356.  
2. Chan JC, Roth KS. Hypophosphatemic Rickets [internet] [Internet]. Medscape. 2020. Available from: https://emedicine.medscape.com/article/922305-overview  
3. Holick MF. Vitamin D deficiency. N Engl J Med. 2007;357(3):266–81.  
4. Premaor MO, Furlanetto TW. Hipovitaminose D em Adultos: Entendendo Melhor a Apresentação de Uma Velha Doença. Arq Bras Endocrinol Metab. 2006;50:25–37.  
5. Kechichian E, Ezzedine K. Vitamin D and the Skin: An Update for Dermatologists. American Journal of Clinical Dermatology. 2018 Apr 9;19(2):223–35.  
6. Lichtenstein A, Ferreira-Júnior M, Sales MM, Aguiar FB de, Fonseca LAM, Sumita NM, et al. Vitamina D: ações extraósseas e uso racional. Revista da Associação Médica Brasileira. 2013 Sep;59(5):495–506.  
7. Edis Z, Haj Bloukh S. Vitamin D Deficiency: Main Factors Affecting The Serum 25-Hydroxyvitamin D ([25(Oh)D]) Status And Treatment Options. 2016 Jan;2348–6848.  
8. Naeem Z. Vitamin d deficiency- an ignored epidemic. International journal of health sciences. 2010 Jan;4(1):V–VI.  
9. Carpenter TO, Shaw NJ, Portale AA, Ward LM, Abrams SA, Pettifor JM. Rickets. Nature Reviews Disease Primers. 2017 Dec 21;3(1):17101.  
10. Filho H de M, Castro LCG de, Damiani D. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metabol. 2006;50(4):802–13.  
11. World Health Organization. Nutritional rickets: a review of disease burden, causes, diagnosis, prevention and treatment.  
2019.  
12. Carpenter TO, Shaw NJ, Portale AA, Ward LM, Abrams SA, Pettifor JM. Rickets. Nature Reviews Disease Primers. 2017 Dec 21;3(1):17101.  
13. JA L, E C, LG. R. Metabolic bone disease. In: Endocrinology. 2008. p. 1269–310.  
14. Nield LS, Mahajan P, Joshi A, Kamat D. Rickets: Not a Disease of the Past - American Family Physician. 2006 American Academy of Family Physicians. 2006;74:619-26(4):629–30.  
15. de Menezes Filho H, de Castro LC DD. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metab. 2006;50(4):802–13.  
16. Bastepe M, H. J. Inherited hypophosphatemic disorders in children and the evolving mechanisms of phosphate regulation. Rev Endocr Metab Disord. 2008;9(2):171–80.  
17. de la Cerda-Ojeda F, González-Rodríguez JD, Madariaga L, Martínez-Díaz-Guerra G, Matoses-Ruipérez ML. Hypophosphataemic Rickets: Similar Phenotype of Different Diseases. Advances in Therapy. 2020 May 31;37(S2):80–8.  
18. Florenzano P, Hartley IR, Jimenez M, Roszko K, Gafni RI, Collins MT. Tumor-Induced Osteomalacia. Calcified Tissue International. 2021 Jan 5;108(1):128–42.  
19. Eswarakumar AS, Ma NS, Ward LM, Backeljauw P, Wasserman H, Weber DR, et al. Long-Term Follow-up of Hypophosphatemic Bone Disease Associated With Elemental Formula Use: Sustained Correction of Bone Disease After Formula Change or Phosphate Supplementation. Clinical Pediatrics. 2020 Oct 15;59(12):1080–5.  
20. Skrinar A, Dvorak-Ewell M, Evins A, Macica C, Linglart A, Imel EA, et al. The Lifelong Impact of X-Linked Hypophosphatemia: Results From a Burden of Disease Survey. Journal of the Endocrine Society. 2019 Jul 1;3(7):1321–34.  
21. Seefried L, Smyth M, Keen R, Harvengt P. Burden of disease associated with X-linked hypophosphataemia in adults: a systematic literature review. Osteoporosis International. 2021 Jan 24;32(1):7–22.  
22. Tovey FI, Hall ML, Ell PJ, Hobsley M. A review of postgastrectomy bone disease. J Gastroenterol Hepatol. 1992;7(6):639–45.  
23. Cohen A, Drake MT. Epidemiology and etiology of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/epidemiology-and-etiology-of-  
osteomalacia?search=osteomalacia&topicRef=2040&source=see_link#H3169360  
24. Mechica JB. Raquitismo e osteomalacia. Arq Bras Endocrinol Metab. 1999;43(6).  
25. Yin Z, Du J, Yu F, Xia W. Osteoporosis and Sarcopenia. Osteoporosis and Sarcopenia. 2018;4(4):119–27.  
26. Florenzano P, Hartley IR, Jimenez M, Roszko K, Gafni RI, Collins MT. Tumor - Induced Osteomalacia. Calcified Tissue International. 2020;(0123456789).  
27. Scheinman SJ, Carpenter T. Hereditary hypophosphatemic rickets and tumor-induced osteomalacia [Internet]. UpToDate.  
2021. Available from: https://www.uptodate.com/contents/hereditary-hypophosphatemic-rickets-and-tumor-inducedosteomalacia?search=osteomalacia&source=search_result&selectedTitle=4~143&usage_type=default&display_rank=4#H22  
28. Mechica JB. Raquitismo e osteomalacia. Arquivos Brasileiros de Endocrinologia & Metabologia. 1999 Dec;43(6):457– 66.  
29. Linhares ER. Effect of nutrition on vitamin D status : studies on healthy and poorly nourished Brazilian children12. 2018;(May):625–30.  
30. SARAIVA GL, CENDOROGLO MS, RAMOS LR, ARAÚJO LMQ, VIEIRA JGH, MAEDA SS, et al. Prevalência da Deficiência, Insuficiência de Vitamina D e Hiperp aratiroidismo Secundário em Idosos Institucionalizados e Moradores na Comunidade da Cidade de São Paulo, Brasil. Arq Bras Endocrinol Metab. 2007;51(3):437–42.  
31. Moreira CA, Costa TMRL, Marques JVO, Sylvestre L, Almeida ACR, Maluf EMCP, et al. Prevalence and clinical characteristics of X-linked hypophosphatemia in Paraná, southern Brazil. Archives of Endocrinology and Metabolism. 2020 Oct 9;64(6):796–802.  
32. Premaor MO, Alves GV, Crossetti LB, Furlanetto TW. to Hypovitaminosis D in Hypoalbuminemic Is Less Intense than in Normoalbuminemic Patients. 2004;24(1):47–53.  
33. Scalco R, Premaor MO, Froehlich PE, Furlanetto TW. High prevalence of hypovitaminosis D and secondary hyperparathyroidism in elders living in nonprofit homes in South Brazil. Endocr. 2008;33:95–100.  
34. Silva BCC, Rgos BMC, Fujii JB, Dias EP, Soares MMS. Prevalência de Deficiência e Insuficiência de Vitamina D e sua Correlação com PTH, Marcadores de Remodelação Óssea e Densidade Mineral Óssea, em Pacientes Ambulatoriais. 2008;482– 8.  
35. Maeda SS, Saraiva GL, Hayashi LF, Cendoroglo MS, Ramos LR, Corrêa M de P, et al. Seasonal variation in the serum 25-hydroxyvitamin D levels of young and elderly active and inactive adults in São Paulo, Brazil. Dermato-Endocrinology. 2013 Jan 27;5(1):211–7.  
36. Saraiva GL, Cendoroglo MS, Ramos LR, Araujo LMQ, Vieira JGH, Kunii I, et al. Influence of ultraviolet radiation on the production of 25 hydroxyvitamin D in the elderly population ˜ o Paulo ( 23 o 34 ’ S), Brazil in the city of Sa. Osteoporos Int. 2005;16:1649–54.  
37. Arantes HP, Kulak CAM, Fernandes CE, Zerbini C, Bandeira F, Barbosa IC, et al. Correlation between 25hydroxyvitamin D levels and latitude in Brazilian postmenopausal women: from the Arzoxifene Generations Trial. Osteoporosis International. 2013 Oct 30;24(10):2707–12.  
38. Padidela R, Nilsson O, Makitie O, Beck-Nielsen S, Ariceta G, Schnabel D, et al. The international X-linked hypophosphataemia (XLH) registry (NCT03193476): rationale for and description of an international, observational study. Orphanet Journal of Rare Diseases. 2020 Dec 30;15(1):172.  
39. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE em Saúde, Saúde D de G e I de T e I em. Relatório de recomendação, n<sup>o</sup> 594. Burosumabe para o tratamento de hipofosfatemia ligada ao cromossoma X em adultos e crianças. 2021.  
40. OrphaNet. Hipofosfatemia ligada ao X [Internet]. 2019.  
41. Brasil. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério. Ministério da Saúde. Secretaria de Ciência T e IEstratégicosD de G e I de tecnologias em Saúde, editor. Brasília, DF; 2016. 96p.  
42. Haffner D, Emma F, Eastwood DM, Duplan MB, Bacchetta J, Schnabel D, et al. Clinical practice recommendations for  
the diagnosis and management of X-linked hypophosphataemia. Nature Reviews Nephrology. 2019 Jul 8;15(7):435–55.  
43. Macedo LC de, Soardi FC, Ananias N, Belangero VMS, Rigatto SZP, De-Mello MP, et al. Mutations in the vitamin D receptor gene in four patients with hereditary 1,25-dihydroxyvitamin D-resistant rickets. Arquivos Brasileiros de Endocrinologia & Metabologia. 2008 Nov;52(8):1244–51.  
44. Elder CJ, Bishop NJ. Rickets. The Lancet. 2014;383(9929):1665–76.  
45. Lorenzo JA, Canalis E RLG. Metabolic bone disease. In: Endocrinology. 2008. p. 1269–310.  
46. Chibuzor MT, Graham-Kalio D, Osaji JO, Meremikwu MM. Vitamin D, calcium or a combination of vitamin D and calcium for the treatment of nutritional rickets in children. Cochrane Database of Systematic Reviews. 2020 Apr 17;  
47. Uday S, Högler W. Nutritional rickets &amp; osteomalacia: A practical approach to management. Indian Journal of Medical Research. 2020;152(4):356.  
48. Cohen A, Drake MT. Clinical manifestations, diagnosis, and treatment of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/clinical-manifestations-diagnosis-and-treatment-ofosteomalacia?search=Osteomalacia&source=search_result&selectedTitle=1~143&usage_type=default&display_rank=1#H131  
8839684  
49. Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. The Journal of Clinical Endocrinology & Metabolism. 2016 Feb;101(2):394–415.  
50. Mughal Z. Rickets in childhood. Semin Musculoskelet Radiol. 2002;6(3):183–90.  
51. Chong WH, Molinolo AA, Chen CC, Collins MT. Tumor-induced osteomalacia. Endocrine-Related Cancer. 2011 Jun;18(3):R53–77.  
52. Atapattu N, Shaw N, Högler W. Relationship between serum 25-hydroxyvitamin D and parathyroid hormone in the search for a biochemical definition of vitamin D deficiency in children. Pediatric Research. 2013 Nov 2;74(5):552–6.  
53. Z B. The relationship of hypocalcemic convulsions related to nutritional rickets with age, gender, season, and serum phosphorus levels. Neurosciences (Riyadh). 2007;12(4):302–5.  
54. Laurent MR, De Schepper J, Trouet D, Godefroid N, Boros E, Heinrichs C, et al. Consensus Recommendations for the Diagnosis and Management of X-Linked Hypophosphatemia in Belgium. Frontiers in Endocrinology. 2021 Mar 19;12.  
55. Beck-Nielsen SS, Mughal Z, Haffner D, Nilsson O, Levtchenko E, Ariceta G, et al. FGF23 and its role in X-linked hypophosphatemia-related morbidity. Orphanet Journal of Rare Diseases. 2019 Dec 26;14(1):58.  
56. Ruppe MD. X-Linked Hypophosphatemia. In: Adam MP, Ardinger HH, Pagon RA, Wallace SE, Bean LJH, Mirzaa G, et al., editors. Seattle (WA); 1993.  
57. Ultragenyx Brasil Farmacêutica Ltda. Bula do medicamneto: Crysvita® (burosumabe). [Internet]. Anvisa. 2019. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351011667202031/?substancia=26479  
58. Chibuzor MT, Graham-Kalio D, Osaji JO, Meremikwu MM. Vitamin D, calcium or a combination of vitamin D and calcium for the treatment of nutritional rickets in children. Cochrane Database of Systematic Reviews. 2020 Apr 17;  
59. Wagner C, Greer FR. Prevention of rickets and vitamin D deficiency in infants, children, and adolescents. Pediatrics. 2008;122(5):1142–52.  
60. Thacher TD, Fischer PR, Isichei CO, Zoakah AI PJM. Prevention of nutritional rickets in Nigerian children with dietary calcium supplementation. Bone. 2012;50(5):1074–80.  
61. Moreira CA, Ferreira CEDS, Madeira M, Silva BCC, Maeda SS, Batista MC, et al. Reference values of 25hydroxyvitamin D revisited: a position statement from the Brazilian Society of Endocrinology and Metabolism (SBEM) and the Brazilian Society of Clinical Pathology/Laboratory Medicine (SBPC). Archives of Endocrinology and Metabolism. 2020 May 27;64(4):462–78.  
62. Tang BM, Eslick GD, Nowson C, Smith C, Bensoussan A. Use of calcium or calcium in combination with vitamin D supplementation to prevent fractures and bone loss in people aged 50 years and older: a meta-analysis. The Lancet. 2007 Aug;370(9588):657–66.  
63. Bischoff-Ferrari HA, Willett WC, Wong JB, Giovannucci E, Dietrich T, Dawson-Hughes B. Fracture Prevention With Vitamin D Supplementation. JAMA. 2005 May 11;293(18):2257.  
64. Kutluk G, Cetinkaya F BM. Comparisons of oral calcium, high dose vitamin D and a combination of these in the treatment of nutritional rickets in children. J Trop Pediatr. 2002;59(2):127–33.  
65. Aggarwal V, Seth A, Marwaha RK, Sharma B, Sonkar P, Singh S AS. Management of nutritional rickets in Indian children: a randomized controlled trial. J Trop Pediatr. 2013;59(2):127–33.  
66. Kutluk G, Cetinkaya F BM. Comparisons of oral calcium, high dose vitamin D and a combination of these in the treatment of nutritional rickets in children. J Trop Pediatr. 2002;59(2):127–33.  
67. Thacher TD, Fischer PR, Pettifor JM, Lawson JO, Isichei CO, Reading JC et al. A comparison of calcium, vitamin D, or both for nutritional rickets in Nigerian children. N Engl J Med. 1999;341(8):563–8.  
68. Thacher TD, Fischer PR PJM. Vitamin D treatment in calcium-deficiency rickets: a randomised controlled trial. Arch Dis Child. 2014;99(9):807–11.  
69. Tieder M, Arie R, Bab I, Maor J, Liberman UA. A New Kindred with Hereditary Hypophosphatemic Rickets with Hypercalciuria: Implications for Correct Diagnosis and Treatment. Nephron. 1992;62(2):176–81.  
70. Imel EA, Glorieux FH, Whyte MP, Munns CF, Ward LM, Nilsson O, et al. Burosumab versus conventional therapy in children with X-linked hypophosphataemia: a randomised, active-controlled, open-label, phase 3 trial. The Lancet. 2019 Jun;393(10189):2416–27.  
71. Carpenter TO, Whyte MP, Imel EA, Boot AM, Högler W, Linglart A, et al. Burosumab Therapy in Children with X- Linked Hypophosphatemia. New England Journal of Medicine. 2018 May 24;378(21):1987–98.  
72. Whyte MP, Carpenter TO, Gottesman GS, Mao M, Skrinar A, San Martin J, et al. Efficacy and safety of burosumab in children aged 1–4 years with X-linked hypophosphataemia: a multicentre, open-label, phase 2 trial. The Lancet Diabetes & Endocrinology. 2019 Mar;7(3):189–99.  
73. Marcucci G, Brandi ML. Congenital Conditions of Hypophosphatemia Expressed in Adults. Calcified Tissue International [Internet]. 2021 Jan 14;108(1):91–103. Available from: https://link.springer.com/10.1007/s00223-020-00695-2 74. Carpenter TO, Imel EA, Holm IA, Jan de Beur SM, Insogna KL. A clinician’s guide to X-linked hypophosphatemia. Journal of Bone and Mineral Research [Internet]. 2011 Jul;26(7):1381–8. Available from: https://onlinelibrary.wiley.com/doi/10.1002/jbmr.340  
75. Haffner D, Emma F, Eastwood DM, Duplan MB, Bacchetta J, Schnabel D, et al. Clinical practice recommendations for the diagnosis and management of X-linked hypophosphataemia. Nature Reviews Nephrology [Internet]. 2019 Jul 8;15(7):435– 55. Available from: http://www.nature.com/articles/s41581-019-0152-5  
76. Lecoq A-L, Brandi ML, Linglart A, Kamenický P. Management of X-linked hypophosphatemia in adults. Metabolism [Internet]. 2020 Feb;103:154049. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0026049519302641  
77. Laurent MR, de Schepper J, Trouet D, Godefroid N, Boros E, Heinrichs C, et al. Consensus Recommendations for the Diagnosis and Management of X-Linked Hypophosphatemia in Belgium. Frontiers in Endocrinology. 2021 Mar 19;12.  
78. Linglart A, Biosse-Duplan M, Briot K, Chaussain C, Esterle L, Guillaume-Czitrom S, et al. Therapeutic management of hypophosphatemic rickets from infancy to adulthood. Endocrine Connections. 2014 Mar;3(1):R13–30.  
79. Cohen A, Drake MT. Clinical manifestations, diagnosis, and treatment of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/clinical-manifestations-diagnosis-and-treatment-ofosteomalacia?search=Osteomalacia&source=search_result&selectedTitle=1~143&usage_type=default&display_rank=1#H131 8839684  
80. de Menezes Filho HC CPH. Raquitismo Hipofosfatêmico Ligado ao X. Projeto Diretrizes [Internet]. [Internet]. Associação Médica Brasileira e Conselho Federal de Medicina. 2004. Available from: http://www.projetodiretrizes.org.br/4_volume/29-RaquitisH.pdf.2004  
81. Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. The Journal of Clinical Endocrinology & Metabolism. 2016 Feb;101(2):394–415.  
82. de Menezes Filho HC CPH. Raquitismo Hipofosfatêmico Ligado ao X. Projeto Diretrizes [Internet]. [Internet]. Associação Médica Brasileira e Conselho Federal de Medicina. 2004. Available from: http://www.projetodiretrizes.org.br/4_volume/29-RaquitisH.pdf.2004  
83. Bastepe M, H. J. Inherited hypophosphatemic disorders in children and the evolving mechanisms of phosphate regulation. Rev Endocr Metab Disord. 2008;9(2):171–80.  
84. Sanofi Medley Farmacêutica Ltda. Bula do medicamento: OS-CAL® 500 (carbonato de cálcio). 2020.  
85. de Menezes Filho H, de Castro LC DD. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metab. 2006;50(4):802–13.  
86. Ultragenyx Brasil Farmacêutica Ltda. Bula do medicamneto: Crysvita® (burosumabe). [Internet]. Anvisa. 2019. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351011667202031/?substancia=26479  
87. Padidela R, Whyte MP, Glorieux FH, Munns CF, Ward LM, Nilsson O, et al. Patient-Reported Outcomes from a Randomized, Active-Controlled, Open-Label, Phase 3 Trial of Burosumab Versus Conventional Therapy in Children with X- Linked Hypophosphatemia. Calcified Tissue International. 2021 May 23;108(5):622–33.  
88. Schindeler A, Biggin A, Munns CF. Clinical Evidence for the Benefits of Burosumab Therapy for X-Linked Hypophosphatemia (XLH) and Other Conditions in Adults and Children. Frontiers in Endocrinology. 2020 May 28;11.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
CALCITRIOL, CARBONATO DE CÁLCIO E BUROSUMABE **.**  
Eu, ________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso do medicamento calcitriol e carbonato de cálcio, indicados para o tratamento do raquitismo e da osteomalácia, e do medicamento burosumabe, indicado para o tratamento da hipofosfatemia ligada ao cromossoma X.  
Os termos médicos me foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _______________________________________________ (nome do médico que prescreve)  
Assim, declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- melhor controle da doença;  
- melhora dos problemas ósseos e dos sintomas.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- não se sabe ao certo os riscos do uso do calcitriol e do burosumabe na gravidez; portanto, caso engravide, devo avisar imediatamente ao meu médico;  
- a segurança para o uso do calcitriol e do bursoumabe durante a amamentação deve ser avaliada pelo médico assistente, considerando riscos e benefícios, visto que o calcitriol é excretado pelo leite materno e que não há informações sobre a excreção de burosumabe por esta via;  
- os efeitos colaterais já relatados para o calcitriol são os seguintes: aumento dos níveis de cálcio no sangue, prisão de ventre, diarreia, secura da boca, dor de cabeça, sede intensa, aumento da frequência ou da quantidade de urina, perda do apetite, gosto metálico, dor nos músculos, náusea, vômitos, cansaço e fraqueza. Alguns efeitos crônicos podem incluir conjuntivite, diminuição do desejo sexual, irritabilidade, coceiras, infecções do trato urinário, febre alta, aumento da pressão arterial, batimentos cardíacos irregulares, aumento da sensibilidade dos olhos à luz ou irritação, aumento dos níveis de fósforo no sangue, aumento do colesterol, aumento das enzimas do fígado alanina-aminotransferase/transaminase glutâmico-pirúvica (ALT/TGP) e aspartato-aminotransferase/transaminase glutâmico-oxalacética (AST/TGO), perda de peso, inflamação no pâncreas e psicose, que é o sintoma mais raro;  
- o calcitriol é contraindicado em casos de hipersensibilidade (alergia) conhecida ao fármaco;  
- os efeitos colaterais já relatados para o carbonato de cálcio em casos raros são: distúrbios gastrintestinais e dor abdominal superior.  
- o carbonato de cálcio é contraindicado para pacientes com insuficiência renal grave.  
- os efeitos colaterais relatados em mais de 10% dos pacientes pediátricos tratados com burosumabe são os seguintes: febre, reação no local da injeção, tosse, vômito, dor nas extremidades, dor de cabeça, abscesso dentário, cáries dentárias, diarreia, diminuição da vitamina D, constipação, erupção cutânea, náusea e tonturas.  
- o burosumabe é contraindicado nas seguintes situações: em uso concomitante com fosfato oral ou análogos ativos da vitamina D (por exemplo, calcitriol, paricalcitol, doxercalciferol, calcifediol), devido ao risco de hiperfosfatemia; quando o  
fósforo sérico está dentro ou acima da faixa normal para a idade; em pacientes com insuficiência renal grave ou doença renal em estágio terminal, porque essas condições estão associadas a um metabolismo mineral anormal.  
- o risco da ocorrência de eventos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira  
ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  (   ) Sim     (   ) Não  
Meu tratamento constará de:  
- (   ) Burosumabe  
- (   ) Calcitriol  
- (   ) Carbonato de cálcio isolado  
- (   ) Carbonato de cálcio associado a colecalciferol  
- (   ) Fosfato de cálcio tribásico associado a colecalciferol  
<!-- Start of picture text -->
Local:                                                             Data:<br>Nome do paciente:<br>Cartão Nacional de Saúde:<br>Nome do responsável legal:<br>Documento de identificação do responsável legal:<br>_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>_________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) de Raquitismo e Osteomalácia iniciou-se com a demanda pelo Ministério da Saúde (MS), a partir da incorporação do burosumabe para o tratamento da hipofosfatemia ligada ao cromossoma X (HLX)<sup>89</sup> . Assim, a nova versão do PCDT deveria trazer informações mais detalhadas acerca da HLX. A definição do escopo ocorreu em dois momentos: as reuniões de pré-escopo e escopo foram realizadas virtualmente, dias 14/06/2021 e 05/04/2021. Os trabalhos foram conduzidos tendo como base o PCDT vigente (Portaria nº 451/SAS/MS, de 29 de abril de 2016) e a estrutura de PCDT definida pela Portaria n° 375/SAS/MS, de 10 de novembro de 2009. Ficou estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas, por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidade de desinvestimento.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **2. Equipe de elaboração e partes interessadas** -->
Além dos representantes do Ministério da Saúde do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os participantes do Grupo Elaborador preencheram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde, como parte dos resultados do trabalho.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **2.1. Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de atualização do PCDT do Raquitismo e Osteomalácia foi apresentada à 93ª Reunião Ordinária da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 23 de setembro de 2021. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE/MS), da Secretaria de Atenção Especializada em Saúde (SAES/MS) e da Secretaria Especial de Saúde Indígena (SESAI/MS) que decidiram, por unanimidade, pautar o tema na reunião da Conitec.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **3. Buscas da evidência e recomendações** -->
Em 16 e 23 de agosto de 2021, foram feitas reuniões para a definição das perguntas de pesquisa levantadas em reunião de escopo que subsidiariam a escrita do texto do PCDT.  
Como já mencionado, o processo de atualização deste documento utilizou como base a versão vigente do PCDT de Raquitismo e Osteomalácia, no âmbito do SUS (Portaria nº 451/SAS/MS, de 29 de abril de 2016), que manteve sua estrutura metodológica.  
A Portaria nº 1/SCTIE/MS, de 19 de fevereiro de 2021, tornou pública a decisão de incorporar o burosumabe para o tratamento da hipofosfatemia ligada ao cromossoma X em crianças conforme Protocolo Clínico e Diretrizes Terapêuticas (PCDT) e não incorporar o burosumabe para o tratamento da hipofosfatemia ligada ao cromossoma X em adultos, no âmbito do SUS. Deste modo, o medicamento foi incluído neste Protocolo, utilizando-se as buscas de evidência, resultados e referências do Relatório de Recomendação Nº 594, de fevereiro de 2021, disponível em: http://conitec.gov.br/images/Relatorios/2021/20210222_Relatorio_594_burosumabe_HLX_HMV.pdf.  
Para a atualização do presente Protocolo, foram elencadas duas perguntas estruturadas, referentes ao tratamento do HLX em adultos e tratamento cirúrgico de deformidades ósseas em indivíduos da faixa etária pediátrica decorrentes de raquitismo, osteomalacia ou HLX (descritas nos **quadros A e B** ). Também foram consideradas diretrizes nacionais e internacionais sobre a  
temática para a atualização das informações pertinentes.  
**Quadro A -** Pergunta PICO 1: O fósforo em monoterapia ou combinado com calcitriol é mais eficaz, efetivo e seguro, no tratamento dos pacientes adultos  
com HLX, do que a ausência de tratamento?  
|**P**|Adultos com raquitismo hipofosfatêmico ligado ao cromossoma X|
|---|---|
|**I**|Fósforo (monoterapia ou combinada com calcitriol; contínua ou intermitente)|
|**C**|Ausência de tratamento ou as intervenções comparadas entre si|
|**O**|Primários:|
||Melhora clínica – dor e fraqueza muscular<br>Normalização de níveis de vitamina D e de fosfatase alcalina<br>Secundários:|
||Eventos adversos (hiperparatireoidismo, alterações renais - nefrocalcinose)<br>Número de fraturas e pseudoartrose<br>Entesopatia|
|**S**|Revisões sistemáticas (com ou sem meta-análise), ensaios clínicos randomizados ou quasi-randomizados e estudos<br>de coorte (prospectivo e retrospectivo|  
**Quadro B -** Pergunta PICO 2: O uso de dispositivo de crescimento guiado, na parte interna ou externa no joelho em crianças e adolescentes, é mais eficaz, efetivo e seguro, para correção de deformidades decorrentes do raquitismo ou osteomalácia, do que o fixador externo de deformidades angulares?  
|**P**|Crianças e adolescentes com deformidades decorrentes do raquitismo ou osteomalácia|
|---|---|
|**I**|Dispositivo de crescimento guiado (_clamps_) na parte interna ou externa do joelho|
|**C**|Fixador externo de deformidades angulares|
|**O**|Primários:|
||Melhora de deformidades, melhora da mobilidade funcional,<br>melhora da qualidade de vida, melhora do quadro álgico,<br>Secundários:|
||Aumento da estatura|
|**S**|Revisões sistemáticas (com ou sem meta-análise), ensaios clínicos randomizados ou quasi-randomizados e estudos<br>de coorte (prospectivo e retrospectivo)|

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **A. Estratégia de busca** -->
Com base na pergunta PICO estruturada ( **Quadro A** ) foram realizadas buscas nas plataformas Medline (PUBMED), EMBASE e Cochrane. As estratégias de busca adotadas em cada uma das plataformas, assim como os resultados obtidos, são apresentadas no ( **Quadro C** ).  
**Quadro C -** Estratégias de busca nas bases de dado PubMed e Embase _,_ incluindo termos da doença e intervenção – 07/10/2021  
|**Base de**<br>**dados**|**Estratégias de busca**|**Resultado**|
|---|---|---|
|MEDLINE<br>(Pubmed)|((("Familial Hypophosphatemic Rickets"[Mesh]) OR ("Familial Hypophosphatemic<br>Rickets" OR "Hypophosphatemic Rickets, Familial" OR "D053098" OR "Rickets,<br>Familial Hypophosphatemic" OR "Hypocalcemic Vitamin D-Resistant Rickets" OR<br>"Hypocalcemic Vitamin D Resistant Rickets" OR "Rickets, Hereditary Vitamin D-<br>Resistant" OR "Rickets, Hereditary Vitamin D Resistant" OR "Hereditary<br>Hypophosphatemic Rickets" OR "Hypophosphatemic Rickets, Hereditary" OR "Rickets,<br>Hereditary Hypophosphatemic" OR "Vitamin D-Resistant Rickets, Hereditary" OR<br>"Vitamin D Resistant Rickets, Hereditary" OR "Hereditary Vitamin D-Resistant Rickets"<br>OR "Hereditary Vitamin D Resistant Rickets" OR "Generalized Resistance To 1,25-<br>Dihydroxyvitamin D" OR "Generalized Resistance To 1,25 Dihydroxyvitamin D" OR<br>"Vitamin D-Resistant Rickets With End-Organ Unresponsiveness To 1,25-<br>Dihydroxycholecalciferol" OR "Vitamin D Resistant Rickets With End Organ<br>Unresponsiveness To 1,25 Dihydroxycholecalciferol" OR "Vitamin D-Resistant Rickets,<br>X-Linked" OR "Vitamin D Resistant Rickets, X Linked" OR "Hypophosphatemic Rickets,<br>X-Linked Recessive" OR "Hypophosphatemic Rickets, X Linked Recessive" OR "Rickets,<br>X-Linked Hypophosphatemic" OR "Hypophosphatemic Rickets, X-Linked" OR "X-<br>Linked Hypophosphatemic Rickets" OR "Hypophosphatemia, X-Linked" OR<br>"Hypophosphatemia, X Linked" OR "X-Linked Hypophosphatemia" OR "X Linked<br>Hypophosphatemia" OR "Hypophosphatemic Rickets, X-Linked Dominant" OR<br>"Hypophosphatemic Rickets, X Linked Dominant")) AND ((("Phosphorus<br>Compounds"[Mesh] OR "Phosphorus Compounds" OR "Compounds, Phosphorus" OR<br>"D017553" OR phosphate OR "phosphate solution" OR "phosphorus capsule" OR<br>"Phosphates"[Mesh] OR "D010710" OR "Inorganic Phosphate" OR "Phosphate,<br>Inorganic" OR "Inorganic Phosphates" OR "Phosphate" OR "Phosphates, Inorganic" OR<br>"Orthophosphate")) OR (("Calcitriol"[Mesh]) OR ("D002117" OR "FXC9231JVH" OR<br>"Calcitriol" OR "1 alpha,25-Dihydroxyvitamin D3" OR "1 alpha,25 Dihydroxyvitamin<br>D3" OR "D3, 1 alpha,25-Dihydroxyvitamin" OR "1,25-Dihydroxyvitamin D3" OR "1,25<br>Dihydroxyvitamin D3" OR "D3, 1,25-Dihydroxyvitamin" OR "1 alpha,25-<br>Dihydroxycholecalciferol" OR "1,25-Dihydroxycholecalciferol" OR "1,25<br>Dihydroxycholecalciferol" OR "Bocatriol" OR "Calcijex" OR "Calcitriol KyraMed" OR<br>"KyraMed, Calcitriol" OR "Calcitriol-Nefro" OR "Calcitriol Nefro" OR "Decostriol" OR<br>"MC1288" OR "MC-1288" OR "MC 1288" OR "Osteotriol" OR "Renatriol" OR<br>"Rocaltrol" OR "Silkis" OR "Sitriol" OR "Soltriol" OR "Tirocal" OR "20-epi-1alpha,25-<br>dihydroxycholecaliferol" OR "1,25-dihydroxy-20-epi-Vitamin D3" OR "1,25 dihydroxy<br>20 epi Vitamin D3" OR "D3, 1,25-dihydroxy-20-epi-Vitamin" OR "1,25(OH)2-20epi-D3"<br>OR "1 alpha, 25-dihydroxy-20-epi-Vitamin D3"))) AND (medline[Filter])) NOT<br>((animals[MH:noexp] NOT (animals[MH:noexp] AND humans[MH]))) Filters:<br>MEDLINE|856|  
|**Base de**<br>**dados**|**Estratégias de busca**|**Resultado**|
|---|---|---|
|Embase|('familial hypophosphatemic rickets'/exp OR 'familial hypophosphatemic rickets' OR<br>'familial hypophosphataemia' OR 'familial hypophosphataemias' OR 'familial<br>hypophosphataemic osteomalacia' OR 'familial hypophosphataemic rickets' OR 'familial<br>hypophosphatemia' OR 'familial hypophosphatemias' OR 'familial hypophosphatemic<br>osteomalacia' OR 'hereditary hypophosphataemia' OR 'hereditary hypophosphataemias'<br>OR 'hereditary hypophosphataemic osteomalacia' OR 'hereditary hypophosphataemic<br>rickets' OR 'hereditary hypophosphatemia' OR 'hereditary hypophosphatemias' OR<br>'hereditary hypophosphatemic osteomalacia' OR 'hereditary hypophosphatemic rickets' OR<br>'hereditary vitamin d resistant rickets' OR 'hypophosphataemia, familial' OR<br>'hypophosphatemia, familial') AND ('calcitriol'/exp OR 'calcitriol' OR '1 alpha 25<br>dihydroxyvitamin d 3' OR '1, 25 dihydrocholecalciferol' OR '1, 25 dihydroxy<br>cholecalciferol' OR '1, 25 dihydroxy vitamin d 3' OR '1, 25 dihydroxycalciferol' OR '1, 25<br>dihydroxycholecalciferol' OR '1, 25 dihydroxycolecalciferol' OR '1, 25 dihydroxyvitamin<br>d' OR '1, 25 dihydroxyvitamin d 3' OR '1, 25 dihydroxyvitamin d3' OR '1-alfa, 25-<br>dihydroxycholecalciferol' OR '1alpha 25 dihydroxycolecalciferol' OR '1alpha, 25<br>dihydroxycholecalciferol' OR '1alpha, 25 dihydroxycolecalciferol' OR '1alpha, 25<br>dihydroxyvitamin d 3' OR '1alpha, 25 dihydroxyvitamin d3' OR '5 [2 [1 (5 hydroxy 1, 5<br>dimethylhexyl) 7a methyl 2, 3, 3a, 5, 6, 7 hexahydro 1h inden 4 ylidene] ethylidene] 4<br>methylenecyclohexane 1, 3 diol' OR '5 [2 [1 [6 hydroxy 6 methylheptan 2 yl] 7a methyl 2,<br>3, 3a, 5, 6, 7 hexahydro 1h inden 4 ylidene] ethylidene] 4 methylidenecyclohexane 1, 3<br>diol' OR '9, 10 secocholesta 5, 7, 10 (19) triene 1alpha, 3beta, 25 triol' OR 'bocatriol' OR<br>'bonky' OR 'cabone' OR 'calcijex' OR 'caraben sc' OR 'cholecalciferol, 1alpha, 25<br>dihydroxy' OR 'cicarol' OR 'citrihexal' OR 'colecalciferol 1, 25 diol' OR 'colecalciferol,<br>1alpha, 25 dihydroxy' OR 'decostriol' OR 'difix' OR 'dn 101' OR 'dn101' OR 'ecatrol' OR<br>'ecatrol f' OR 'hitrol' OR 'kolkatriol' OR 'kosteo' OR 'lemytriol' OR 'meditrol' OR<br>'osteotriol' OR 'poscal' OR 'renatriol' OR 'rexamat' OR 'ro 21 5535' OR 'ro 215535' OR<br>'ro215535' OR 'rocaltrol' OR 'roical' OR 'rolsical' OR 'silkis' OR 'sitriol' OR 'soltriol' OR<br>'tariol' OR 'tirocal' OR 'topitriol' OR 'triocalcit' OR 'vectical' OR 'vitamin d3, 1, 25<br>dihydroxy' OR 'phosphorus derivative'/exp OR 'phosphate'/exp OR 'phosphorous'/exp)<br>AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)|385|
|Cochrane|#1<br>MeSH descriptor: [Familial Hypophosphatemic Rickets] explode all trees<br>#2<br>Familial Hypophosphatemic Rickets (Word variations have been searched)<br>#3<br>#1 OR #2<br>#4<br>MeSH descriptor: [Phosphorus] explode all trees<br>#5<br>MeSH descriptor: [Phosphates] explode all trees<br>#6<br>phosphorus OR phosphate (Word variations have been searched)<br>#7<br>#4 OR #5 OR #6<br>#8<br>MeSH descriptor: [Calcitriol] explode all trees|**27**|  
|**Base de**<br>**dados**|||**Estratégias de busca**|**Resultado**|
|---|---|---|---|---|
||#9|calcitriol (Word var|iations have been searched)||
||#10|#8 OR #9|||
||#11|#7 OR #10|||
||#12|#3 AND #11|||
|Total||||**1.268**|

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **População** -->
Foram incluídos estudos que incluem pacientes adultos (com idade superior a 18 anos) acometidos com HLX.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Intervenção** -->
A intervenção de interesse foi o fósforo em monoterapia ou combinado com calcitriol (contínua ou intermitente).  
No Brasil não há preparações farmacêuticas industriais de fosfato prontas, sendo necessário que sejam manipuladas em farmácias magistrais, conforme as fórmulas descritas no documento do PCDT de Raquitismo e Osteomalácia, que contém 15 mg de fósforo elementar por mL de solução fosfatada e 250 mg de fósforo elementar por cápsula de fósforo<sup>90</sup> .  
O calcitriol é um metabólito ativo da vitamina D com 3 grupos hidroxila (OH) e é comumente referido como 1,25dihidroxicolecalciferol, ou 1alpha, 25-dihidroxivitamina D 3 ou 1,25-dihidroxivitamina D 3. O calcitriol desempenha um papel na regulação do cálcio plasmático em conjunto com o hormônio da paratireoide (PTH), aumentando a absorção de cálcio e fosfato da dieta do trato gastrointestinal, promovendo a reabsorção tubular renal de cálcio nos rins e estimulando a liberação de depósitos de cálcio do sistema esquelético<sup>91</sup> . Por exercer um efeito vitamínico D, os efeitos colaterais do calcitriol podem ocorrer em caso de superdosagem, de forma semelhantes aos da hipervitaminose D, ou seja, síndrome de hipercalcemia ou intoxicação por cálcio (dependendo da gravidade e duração da hipercalcemia). Sintomas agudos ocasionais incluem anorexia, cefaléia, vômito e constipação. Efeitos crônicos podem incluir distrofia, distúrbios sensoriais, por vezes febre com sede, poliúria, desidratação, apatia, interrupção do crescimento e infecções do trato urinário<sup>92</sup> . O calcitriol possui registro na Anvisa, para as apresentações de 1 mcg/ml solução injetável e de 0,25 mcg em cápsula gelatinosa mole<sup>93</sup> .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Comparador** -->
Nesta avaliação foi considerada a ausência de tratamento ou as intervenções comparadas entre si.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Desfechos** -->
Os desfechos primários considerados foram: a melhora clínica (dor e fraqueza muscular) e a normalização de níveis de vitamina D e de fosfatase alcalina. Os desfechos secundários considerados foram: eventos adversos (hiperparatireoidismo, alterações renais - nefrocalcinose), o número de fraturas e pseudoartrose, e entesopatia.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Tipos de estudos** -->
Foram considerados para inclusão revisões sistemáticas (com ou sem meta-análise), ensaios clínicos randomizados (ECR) ou quasi-randomizados e estudos observacionais com grupo comparador (prospectivo e retrospectivo). Os estudos incluídos nas revisões sistemáticas foram conferidos e, caso já estivessem contemplados, a revisão sistemática recuperada contribuiria para a escrita do relatório, mas seria excluída.  
**Critérios de inclusão:** foram consideradas elegíveis publicações dos tipos revisão sistemática, ECR, estudos observacionais com grupo comparador, sem restrição de data de publicação e linguagem, que avaliaram a utilização de fósforo em monoterapia ou combinado com calcitriol (contínua ou intermitente) para o tratamento de pacientes adultos com HLX.  
**Critérios de exclusão:** não foram considerados na seleção estudos pré-clínicos, revisões narrativas, estudos observacionais descritivos sem grupo comparador de tratamento, séries de casos, relato de caso, resumos de congressos, relatórios breves ( _brief report_ ), cartas ao editor, _pooled-analyses_ , consenso de especialistas, teses e dissertações. Também foram excluídas publicações que avaliaram outras tecnologias que não aquelas de interesse da pergunta de pesquisa.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **B. Seleção das evidências** -->
Foram encontrados 1.268 registros nas plataformas de busca (856 no MEDLINE, 385 no EMBASE e 27 na Cochrane). Após a remoção de duplicatas, 1.235 registros foram triados (leitura de título e resumo). Na fase seguinte, 51 textos completos foram avaliados quanto a elegibilidade. Ao final, três artigos foram incluídos na revisão. A **Figura 1** descreve o fluxograma da seleção dos estudos e suas etapas. Os estudos excluídos na fase 3 com suas respectivas justificativas são descritos no **Quadro D** .

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **C. Descrição dos estudos e resultados** -->
Foram incluídos três coortes que avaliaram pacientes adultos com HLX em uso de fosfato e calcitriol: Lyles et al., 1982<sup>142</sup> , Sullivan et al., 1992<sup>143</sup> , Imel et al., 2010<sup>144</sup> .  
Lyles et al., 1982<sup>142</sup> , avaliaram em uma coorte com 21 adultos com HLX se um defeito no metabolismo da vitamina D pode desempenhar um papel na patogênese da HLX e da osteomalácia, comparou três pacientes tratados com vitamina D e fosfato com 18 pacientes não tratados, por um período de 1,5 a 7 anos.  
Sullivan et al., 1992<sup>143</sup> , investigaram as respostas clínicas, bioquímicas e histológicas com o uso de fosfato e vitamina D em 16 pacientes adultos sintomáticos com HLX seguidos por uma média de 4,2 anos. Cada paciente serviu como seu próprio controle. Foram estudados 18 adultos com HLX (média de 37 anos de idade).  
Imel et al., 2010<sup>144</sup> , avaliaram se as terapias padrão atuais para o tratamento de HLX (calcitriol e fosfato) aumentam as concentrações circulantes de FGF23, em uma coorte oito participantes. A intervenção foi o uso de calcitriol oral e fosfato, comparados à ausência de tratamento. O seguimento foi de 14,4 ± 11,7 meses (coorte de tratamento) e 25 ± 32 meses (coorte sem tratamento).  
A descrição sumária dos estudos incluídos encontra-se na **Tabela** . As características basais dos participantes de cada estudo podem ser vistas na **Tabela** . Os resultados de efetividade encontram-se na **Tabela C** .  
**Figura 1 -** Fluxograma de seleção das evidências  
<!-- Start of picture text -->
Publicações identificadas por meio da pesquisa nas bases de<br>dados: 1.268<br>PUBMED = 856<br>EMBASE= 385<br>COCHRANE = 27<br>Publicações após remoção de duplicatas: 1.235<br>Publicações excluídas: 1.184<br>Publicações excluídas segundo critérios de<br>exclusão: 48<br>Publicações selecionadas para leitura completa: 51  Tipo de intervenção: 06<br>Tipo de estudo: 05<br>Tipo de desfecho: 06<br>Não recuperado: 01<br>Tipo de participante: 13<br>Tipo de comparação: 10<br>Tipo de publicação: 07<br>Estudos incluídos<br>Ensaio clínico randomizado: 0<br>Coortes: 3<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
**Quadro D -** Estudos excluídos e seus respectivos motivos  
|**Estudo**|**Justificativa**|
|---|---|
|**Berndt, 1996** <sup>94</sup>|Artigo não recuperado.|
|**Boros, 2014**<sup>95</sup>|Tipo de comparação e publicação: não faz a comparação entre os medicamentos e não é HLX.<br>Resumo de congresso.|
|**Boros, 2014**<sup>96</sup>|Tipo de publicação: resumo de congresso.|
|**Broseta, 2019**<sup>97</sup>|Tipo de publicação: resumo de congresso.|
|**Broseta, 2019**<sup>98</sup>|Tipo de publicação: resumo de congresso.|
|**Cagnoli, 2017**<sup>99</sup>|Tipo de participante: estudo com crianças e adolescentes.|
|**Carpenter, 1996**<sup>100</sup>|Tipo de desfecho: não apresenta os desfechos de interesse separados para pacientes adultos.|
|**Carpenter, 2014**<sup>101</sup>|Tipo de comparação: compara paricalcitol x placebo.|
|**Carpenter, 2014** <sup>102</sup>|Tipo de comparação: compara KRN23 é um anticorpo anti-FGF23 x placebo.|  
|**Che, 2016**<sup>103</sup>|Tipo de comparação: comparou a qualidade de vida de pacientes com HLX com a de pacientes<br>afetados com espondiloartrite axial.|
|---|---|
|**Chesney, 1980**<sup>104</sup>|Tipo de população: estudo com crianças.|
|**Cheung, 2013**<sup>105</sup>|Tipo de estudo: estudo transversal, nenhum dos adultos participantes do estudo estava recebendo<br>tratamento com fosfato e calcitriol.|
|**Chung, 2002** <sup>106</sup>|Tipo de estudo: relato de casos. Artigo não recuperado.|
|**Colares Neto, 2015**<sup>107</sup>|Tipo de publicação: resumo de congresso.|
|**Colares Neto, 2019**<sup>108</sup>|Tipo de comparação: as comparações realizadas foram entre pacientes adultos e pediátricos, e<br>entre pacientes com e semnefrocalcinose e / ou nefrolitíase.|
|**Connor, 2015** <sup>109</sup>|Tipo de intervenção: o objetivo do estudo foi investigar a relação entre tratamento e entesopatia<br>e doença dentária em pacientes adultos com XLH. Não houve intervenções.|
|**Connor, 2015**<sup>110</sup>|Tipo de publicação: resumo de congresso.|
|**Dahir, 2020**<sup>111</sup>|Tipo de intervenção: burosumabe comparado a qualquer intervenção medicamentosa. Resultados<br>não disponíveis|
|**Delvin, 1981** <sup>112</sup>|Tipo de população: estudo com crianças.|
|**Duplan, 2017**<sup>113</sup>|Tipo de desfecho: frequência e a gravidade da periodontite.|
|**Faiyaz-Ul-Haque, 2018**<br>114|Tipo de população: estudo com crianças.|
|**Gjørup, 2018** <sup>115</sup>|Tipo de desfecho relatado e comparação: características craniofaciais e o fenótipo dentário de<br>pacientes com raquitismo dependente de vitamina D tipo 1A (VDDR1A), comparados com<br>pacientes com HLX e controles saudáveis.|
|**Glorieux, 1980** <sup>116</sup>|Tipo de população: estudo com crianças.|
|**Hansen, 2018**<sup>117</sup>|Tipo de estudo e desfecho: estudo transversal avaliou níveis de esclerostina em pacientes com<br>HLX tratados e não tratados.|
|**Hansen, 2019**<sup>118</sup>|Tipo de intervenção: compara pacientes tratados alfacalcidol e fosfato com aqueles não tratados.|
|**Harrell, 1985** <sup>119</sup>|Tipo de participante: estudo com cinco participantes, destes apenas um adulto.|
|**Imel, 2010** <sup>120</sup>|Tipo de desfecho e publicação: concentrações séricas de klotho envolvidas na fisiopatologia da<br>HLX. Resumo de congresso.|
|**Imel, 2015** <sup>121</sup>|Tipo de intervenção: KRN23 foi injetado via subcutânea a cada 28 dias. Dois estudos sequenciais<br>de fase 1/2 de rótulo aberto sem comparador.|
|**Insogna, 2018** <sup>122</sup>|Tipo de comparação: burosumabe e placebo|
|**Javier, 2013**<sup>123</sup>|Tipo de estudo e publicação: estudo transversal, ausência de grupo comparador. Resumo de<br>congresso.|
|**Jehan, 2008**<sup>124</sup>|Tipo de pacientes: pacientes com raquitismo hipofosfatêmico, mas não é HLX. Pacientes com<br>raquitismo de início tardio (após 5 anos de idade) e pacientes com mutações de ganho de função<br>conhecidas do gene FGF23 foram excluídos do estudo.|
|**Jiménez, 2021**<sup>125</sup>|Tipo de intervenção: estudo transversal, com 20 adultos. Pacientes que estavam em tratamento<br>com fosfato e / ou calcitriol foram solicitados a interromper o uso por 7 dias antes da avaliação|  
||médica, a fim de obter resultados para comparar com os pacientes em tratamento depois. Mas<br>destes apenas 30 e 35% dos pacientes faziam o uso de calcitriol e fosfato, respectivamente.|
|---|---|
|**Lyles, 1982**<sup>126</sup>|Tipo de população: estudo comparou pacientes com HLX tratados com fosfato oral e vitamina<br>D2 com aqueles não tratados. No entanto o grupo de pacientes tratados incluia apenas crianças e<br>adolescentes.|
|**Martin-Grace, 2018**<sup>127</sup>|Tipo de publicação: resumo de congresso.|
|**McEnery, 1972**<sup>128</sup>|Tipo de estudo: relato de caso.|
|**Miyamoto, 2000** <sup>129</sup>|Tipo de comparação: compara D2 e vitamina D3.|
|**Nakajima, 1990**<sup>130</sup>|Tipo de participante: compara pacientes com HLX com pacientes saudáveis e avalia a<br>concentração de Receptores de Vitamina D (VDR). Inclui crianças e adultos, não apresenta o<br>resultado separado.|
|**Nakamura, 2017**<sup>131</sup>|Tipo de comparação: avaliou a apresentação fenotípica da HLX durante a idade adulta, incluindo<br>complicações além de doenças esqueléticas e dentárias, controle saudável.|
|**Ohata, 2019**<sup>132</sup>|Tipo de publicação: resumo de congresso.|
|**Patzer, 1999**<sup>133</sup>|Tipo de população: estudo com crianças e adolescentes.|
|**Rafaelsen, 2016**<sup>134</sup>|Tipo de população: estudo com crianças.|
|**Salcion Picaud, 2018**<sup>135</sup>|Tipo de desfecho e publicação: não apresenta os desfechos de interesse. Resumo de congresso.|
|**Shanbhogue, 2018**<sup>136</sup>|Tipo de intervenção: compara pacientes tratados alfacalcidol e fosfato com aqueles não tratados.|
|**Suzuki, 2009** <sup>137</sup>|Tipo de população: pacientes com raquitismo hipofosfatêmico e osteomalácia, não é diagnostico<br>de HLX.|
|**Taylor, 1995** <sup>138</sup>|Tipo de desfecho: o estudo incluiu crianças e adultos, mas não apresenta o resultado separado<br>para adultos.|
|**Theret, 2013**<sup>139</sup>|Tipo de comparação e publicação: comparou o metabolismo ósseo e mineral de pacientes com<br>fenótipo com FGF23 e a forma autossômica dominante rara de raquitismo hipofosfatêmico<br>devido a mutações de PHEX ou FGF23. Resumo de congresso.|
|**Tieder, 1993**<sup>140</sup>|Tipo de participantes e comparação: estudo compara 12 pacientes com a síndrome de raquitismo<br>hipofosfatêmico hereditário com hipercalciúria (HHRH) recebendo apenas fosfatos orais e em 5<br>pacientes HLX recebendo fosfatos orais e vitamina D.|
|**Tiosano, 2011**<sup>141</sup>|Tipo de comparação: compara os pacientes com raquitismo hereditário resistente à vitamina D<br>com pacientes saudáveis, e adultos com crianças.|  
**Tabela** **<mark>A –</mark>** <mark>D</mark> escrição sumária dos estudos incluídos que avaliaram a efetividade do fosfato ou calcitriol em indivíduos portadores de HLX  
|**Estudo**|**Desenho**<br>**do estudo**|**Características gerais da**<br>**população**|**País ou N/N**<br>**centros**|**Período do**<br>**estudo**|<br>**Tempo de**<br>**acompanhamento**|**Alternativas comparadas**|**Financiamento**|
|---|---|---|---|---|---|---|---|
|**Lyles, 1982**|Coorte|Pacientes com HLX<br>n = 21 adultos (11 homens e 10<br>mulheres) com idades entre 20 e<br>72 anos.|Estados<br>Unidos|NR|1,5 a 7 anos|Vitamina D2 (25.000-200.000<br>U / dia) ou 25-<br>hidroxivitamina D (100 / xg /<br>dia) e suplementos dietéticos<br>de fosfato (1,2-2,5 g de<br>fósforo elementar por dia): n=<br>3<br>Ausência de tratamento: n=18|Clinical Research Center Branch<br>Division of Research Facilities and<br>Resources, U.S. Public Health<br>Service (M 01 FR 30),<br>National Institute of Arthritis,<br>Metabolism and Digestive Disease<br>(AM 27032-01) a<br>Basil O'Connor Starter Research<br>(Grant No. 5-279)|
|**Sullivan,**<br>**1992**|Coorte|Pacientes adultos sintomáticos<br>com HLX.<br>Na maioria dos pacientes (15 de<br>18), o raquitismo hipofosfatêmico<br>foi diagnosticado na infância. Três<br>indivíduos foram diagnosticados<br>como adultos após o diagnóstico<br>ter sido feito em outros membros<br>da família.<br>Dois pacientes não se<br>interessaram na terapia quando<br>adulto.|n= 1 Yale-<br>New Haven<br>Hospital<br>(New Haven,<br>Connecticut,<br>Estados<br>Unidos)|Maio de<br>1978 a<br>julho de<br>1990.|Média de 4,2 anos (de<br>9 meses a 9 anos de<br>tratamento)|Vitamina D (1,25-(OH)2D3)<br>e Fosfato: n= 15<br>Vitamina D (1,25-(OH)2D3):<br>n= 1|General clinical research Center<br>Branch of the NIH; Shiners of North<br>America|  
|**Estudo**|**Desenho**<br>**do estudo**|**Carac**|**terísticas gerais da**<br>**população**|**País ou N/N**<br>**centros**|**Período do**<br>**estudo**|<br>**Tempo de**<br>**acompanhamento**|**Alternativas comparadas**|**Financiamento**|
|---|---|---|---|---|---|---|---|---|
|**Imel, 2010**|Coorte|Pacientes a<br>de HLX.|dultos com diagnóstico|n=2 Yale<br>University;<br>Indiana<br>University.|NR|média 14,4 ± 11,7<br>meses (2,5 a 35,3<br>meses na coorte de<br>tratamento) e 25 ± 32<br>meses (2,5 a 80 meses<br>na coorte sem|Fosfato (três a cinco vezes ao<br>dia em doses tituladas até 20-<br>35 mg de fósforo elementar /<br>kg / d) e calcitriol (titulado até<br>20-30 ng / kg / d em duas<br>doses divididas): n=3|National Institutes of Health Grants<br>K23AR057096, KL2RR025760,<br>T32AR07581, R01 AR042228, e<br>P50 AR054086|
|||||||tratamento)|Ausência de tratamento: n=5||  
**Tabela** **<mark>B -</mark>** Características basais dos participantes dos estudos  
|Estudo|**Alternativas**<br>**comparadas**|**N**<br>**participant**<br>**es**|**Idade**<br>**média**<br>**(intervalo)**|**Sexo**|**Fosfato**<br>**sérico**<br>**(média ±**|**Cálcio**<br>**sérico total**<br>**(média ±**|**Creatinina**<br>**sérica**<br>**(média ±**|**Fosfatase**<br>**alcalina**<br>**(média ±**|**PTH**<br>**imunorrea**<br>**tivo**<br>**(média ±**|**25OHD**<br>**(média ±**<br>**DP)**|**1,25**<br>**(OH)2D **<br>**(média ±**|**TmP/G**<br>**FR**|**FGF**<br>**23**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||**anos**||**DP)**|**DP)**|**DP)**|**DP)**|<br>**DP)**||**DP)**|||
||Vitamina D2 (25.000-<br>200.000 U / dia) ou<br>25-hidroxivitamina D|||||||||||||
|**Lyles, 1982**|(100 / xg / dia) e<br>suplementos dietéticos<br>de fosfato (1,2-2,5 g de<br>fósforo elementar por<br>dia)|3|20 a 72|Homens: 11<br>Mulheres:<br>10|2,51 a<br>2,72<sup>#</sup>|NR|NR|NR|NR|NR|NR|NR|NR|
||Ausência de<br>tratamento|18|||< 2,5|NR|NR|NR|NR|NR|NR|NR|NR|
||Pacientes em uso de|||||||||||||
|**Sullivan,**<br>**1992**|vitamina D (1,25-<br>(OH)2D3) e fosfato<br>Comparados com eles|18|37,0 (16 a<br>65)|Homens: 9<br>Mulheres: 9|10,98 ±<br>0,03<br>mmol/L|2,31 ±<br>0,03mmol/<br>L|67 ± 4<br>pmol/L|1,26 ± 0,16<br>µkat / L|30 ± 6<br>nLeq / mL|57 ± 6<br>mmol/L|83 ± 6<br>mmol/L|NR|NR|
||mesmos após 4,2 anos|||||||||||||
|**Imel, 2010**|Fosfato e calcitriol|3|29,2 ± 1,5<br>(27,7 a<br>30,8)|Homens: 2<br>Mulheres: 1|1,8 ± 0,1<br>mg/dLdL|9,0 ± 0,1<br>mg/dLdL|0,7 ± 0,2<br>mg/dLdL|177 ± 56<br>U/L|131 ± 49<br>pg/mL|NR|NR|1,5 ± 0,0<br>mg/dL|216 ±<br>67<br>pg/m<br>L|
||Ausência de<br>tratamento|5|30.7 ± 10.1<br>(18,6 a<br>41,4)|Homens: 0<br>Mulheres: 5|2,0 ± 0,5<br>mg/dLdL|9,1 ± 0,1<br>mg/dLdL|0,8 ± 0,2<br>mg/dLdL|72 ± 21<br>U/L|90 ± 35<br>pg/mL|NR|NR|1,8 ± 0,7<br>mg/dL|92 ±<br>12|  
|Estudo|**Alternativas**<br>**comparadas**|**N**<br>**participant**<br>**es**|**Idade**<br>**média**<br>**(intervalo)**<br>**anos**|**Sexo**|**Fosfato**<br>**sérico**<br>**(média ±**<br>**DP)**|**Cálcio**<br>**sérico total**<br>**(média ±**<br>**DP)**|**Creatinina**<br>**sérica**<br>**(média ±**<br>**DP)**|**Fosfatase**<br>**alcalina**<br>**(média ±**<br>**DP)**|**PTH**<br>**imunorrea**<br>**tivo**<br>**(média ±**<br>**DP)**|**25OHD**<br>**(média ±**<br>**DP)**|**1,25**<br>**(OH)2D **<br>**(média ±**<br>**DP)**|**TmP/G**<br>**FR**|**FGF**<br>**23**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||||||||||||pg/m<br>L|  
DP: desvio padrão; PTH: hormônio da paratireoide; 25OHD: 25-hidroxivitamina D; 1,-25 (OH)2D: 1,25-di-hidroxivitamina D [1,25(OH)2D;<sup>#</sup> : intervalo.  
**Tabela** **<mark>C -</mark>** Desfechos de efetividade de estudos que avaliaram a efetividade do fosfato ou calcitriol em indivíduos portadores de HLX  
|**Autor,**<br>**ano**|**Intervenção e**<br>**comparação**|**Fosfato sérico**<br>**(média ± DP)**|**Cálcio sérico**<br>**(média ± DP)**|**Cálcio**<br>**urinário**<br>**(média ±**<br>**DP)**|**Creatinina**<br>**sérica**<br>**(média ±**<br>**DP)**|**Fosfatase**<br>**alcalina**<br>**(média ± DP)**|**PTH**<br>**imunorreativo**<br>**(média ± DP)**|**25OHD**<br>**(média**<br>**±DP)**|**1,-25**<br>**(OH)2D**<br>**(média**<br>**± DP)**|**FGF23**|<br>**%**<br>**Diferença**<br>**FGF23**|<br>**Eventos adversos**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**Lyles, 1982**|Vitamina D<br>(1,25-<br>(OH)2D3) e<br>fosfato|2,6 ± 0,1 mg /<br>dLdL|9,2 ± 0,1 mg/dL|NR|NR|NR|NR|NR|12.6 ±<br>1.2*<br>pg/mL|NR|NR|NR|
||Ausência de<br>tratamento|2,2 ± 0,1 mg /<br>dLdL|9,3 ± 0,2 mg/dL|NR|NR|NR|NR|NR|300 ±<br>2.9*<br>pg/mL|NR|NR|NR|
||Pacientes em<br>uso de<br>vitamina D||||||||||||
|**Sullivan,**<br>**1992**|(1,25-<br>(OH)2D3) e<br>fosfato<br>Comparados<br>com eles<br>mesmos após<br>4,2 anos|0,77 ± 0,04*<br>mmol/L;<br>∆: +0,13|2,34 ± 0,03<br>mmol/L;<br>∆: +0,04|4,39 ±<br>0,44*<br>mmol/L;<br>∆: +2,47|69 ± 6<br>pmol/L;<br>∆: +3|1,14 ± 0,14<br>µkat/L;<br>∆: -0.12|38 ± 7** nLeq<br>/ mL|61 ±<br>7**<br>mmol/L|87 ±<br>6**<br>mmol/L|NR|NR|hiperparatireoidismo:<br>n=1<br>nefrolitíase: n=0<br>hipercalcemia: n=2|
|**Imel 2010**|Fosfato e<br>calcitriol|2.3 ± 0.3 mg / dL|9.0 ± 0.5 mg/dL|NR|0.8 ± 0.3<br>mg/dL|193 ± 13 U/L|NR|NR|NR|1096 ±<br>848<br>pg/mL|352.4 ±<br>271.1<br>pg/mL|hiperparatireoidismo<br>hipercalcêmico: n=0|
|**,**|Ausência de<br>tratamento|2.2 ± 0.3 mg /<br>dLdL|9.1 ± 0.2 mg/dL|NR|0.8 ± 0.2<br>mg/dL|91 ± 42 * U/L|NR|NR|NR|81 ±<br>26*<br>pg/mL|-12.9 ±<br>19.2<br>pg/mL|hiperparatireoidismo<br>hipercalcêmico: n=0|  
DP: desvio padrão; ∆: Diferenças entre os valores médios dos períodos de pré-tratamento e tratamento; * p<0,05; **p= Não significante

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Risco de viés dos estudos incluídos** -->
Os estudos foram avaliados quanto ao risco de viés de acordo a ferramenta _Risk of Bias in Non-randomised Studies of Interventions_ (ROBINS-I)<sup>145</sup> para os estudos observacionais. Dois estudos apresentaram risco de viés grave<sup>142,143</sup> e um estudo apresentou risco moderado<sup>144</sup> . Os domínios mais comprometidos foram viés de confundimento e viés de seleção dos participantes, por não apresentarem as características basais dos participantes; por não informarem detalhadamente como foi a seleção dos participantes, por diferenças nos históricos de tratamento prévio entre os participantes dos grupos de comparação. Detalhes sobre o risco de viés de cada estudo podem ser observados na **Figura 2** .  
**Figura 2 -** Avaliação da qualidade metodológica dos estudos incluídos (ROBINS-I)  
|||||||**Domínios do risco de v**|**iés**|||
|---|---|---|---|---|---|---|---|---|---|
|**Estudo**||**D1**|**D2**|**D3**|**D**|**4**<br>**D5**|**D6**|**D7**|**Geral**|
|Domínios:|||||||Julgamento:|||
|D1: Viés de confund|imento|||||||Crítico||
|D2: Viés de seleção|dos partici|pantes||||||Grave||
|D3: Viés de classific|ação da in|tervenção||||||Moderado||
|D4: Viés de desvios|das interv|enções pretendidas||||||Baixo||
|D5: Viés de perda de|dados|||||||Nenhuma informação||
|D6: Viés de mensura|ção do de|sfecho||||||||
|D7: Viés de seleção|do relato d|o resultado||||||||

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Avaliação da qualidade da evidência** -->
A qualidade geral do conjunto das evidências na comparação fosfato ou calcitriol vs. ausência de tratamento foi muito baixa para os desfechos avaliados: níveis séricos de 5- hidroxivitamina D; de 1,25-di-hidroxivitamina D; de cálcio sérico; creatinina sérica; PTH sérico; fosfatase alcalina; fosfato sérico em jejum; excreção urinária de cálcio e concentrações  
de FGF23. Os principais fatores ponderados para o rebaixamento da qualidade da evidência foram o risco de viés e a imprecisão entre os estudos, conforme apresentado na tabela **D** com as demais justificativas.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Certeza da evidência** -->
|**№ dos**<br>**estudos**<br>**Delineamento**<br>**do estudo**<br>**Resposta bioquímica**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|---|---|---|---|---|---|---|---|---|
|3<br>estudo<br>observacional|gravea<sup>,b,c</sup>|não grave|não grave|muito<br>graved|nenhum|**Lyles, 1982:**O nível sérico de vitamina D (1,25 (OH)<br>2D) em pacientes adultos com HLX tratados com<br>calcitriol ou fosfato foi significativamente menor do<br>que o dos pacientes não tratados (P <0,05), 12.6 ± 1,2<br>pg/mL e 300 ± 2,9* pg/mL, respectivamente. Não<br>houve diferença significante entre os grupos em relação<br>aos níveis séricos de cálcio e fósforo em jejum, os<br>valores foram 9,3 ± 0,2 e 2,2 ± 0,1 mg / dL em<br>pacientes HLX não tratados e 9,2 ± 0,1 e 2,6 ± 0,1 mg /<br>dL em pacientes tratados.<br>**Sullivan, 1992:**A média de fosfato sérico em jejum e<br>excreção urinária de cálcio aumentou (P <0,015) com a<br>terapia com vitamina D e fosfato comparada a ausência<br>de tratamento no início, diferença de +0,13 mmol/L e<br>+2,47 mmol/L, respectivamente. Não houve alteração<br>significativa nos níveis de cálcio sérico, creatinina<br>sérica, 250HD, 1,25-(OH)2D e PTH sérico<br>imunorreativo.<br>**Imel, 2010:**As concentrações de FGF23 foram<br>elevadas em todos os indivíduos adultos com HLX sem<br>tratamento, mas foram significativamente menores do<br>que nos adultos em tratamento com fosfato e calcitriol<br>(P = 0,03), uma diferença significante de -12.9 ± 19.2<br>pg/mL. Houve uma redução significativa nos níveis de|⨁◯◯◯<br>Muito baixa|IMPORTANTE|

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Resposta bioquímica** -->
|fosfatase alcalina entre os pacientes tratados e não|
|---|
|tratados, os valores foram de 193 ± 13 U/L e 91 ± 42|
|U/L, respectivamente (p< 0,05). Não houve alteração|
|significativa nos níveis de fosfato sérico, cálcio sérico,<br>creatinina sérica entre pacientes tratados e não tratados.|  
**Tabela D -** Sumarização dos resultados dos estudos incluídos (Summary of Findings (SoF) do _webapp_ Grade PRO)  
||||**Certeza da evid**|**ência**||||||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Certeza**|**Importância**|
|**Respost**|**a bioquímica**|||||||||
|3|estudo<br>observacional|grave<sup>a,b,c</sup>|não grave|não grave|muito<br>grave<sup>d</sup>|nenhum|**Lyles, 1982:**O nível sérico de vitamina D (1,25 (OH)<br>2D) em pacientes adultos com HLX tratados com<br>calcitriol ou fosfato foi significativamente menor do<br>que o dos pacientes não tratados (P <0,05), 12.6 ± 1,2<br>pg/mL e 300 ± 2,9* pg/mL, respectivamente. Não<br>houve diferença significante entre os grupos em relação<br>aos níveis séricos de cálcio e fósforo em jejum, os<br>valores foram 9,3 ± 0,2 e 2,2 ± 0,1 mg / dL em<br>pacientes HLX não tratados e 9,2 ± 0,1 e 2,6 ± 0,1 mg /<br>dL em pacientes tratados.<br>**Sullivan, 1992:**A média de fosfato sérico em jejum e<br>excreção urinária de cálcio aumentou (P <0,015) com a<br>terapia com vitamina D e fosfato comparada a ausência<br>de tratamento no início, diferença de +0,13 mmol/L e<br>+2,47 mmol/L, respectivamente. Não houve alteração<br>significativa nos níveis de cálcio sérico, creatinina<br>sérica, 250HD, 1,25-(OH)2D e PTH sérico<br>imunorreativo.<br>**Imel, 2010:**As concentrações de FGF23 foram<br>elevadas em todos os indivíduos adultos com HLX sem<br>tratamento, mas foram significativamente menores do<br>que nos adultos em tratamento com fosfato e calcitriol<br>(P = 0,03), uma diferença significante de -12.9 ± 19.2|⨁◯◯◯<br>Muito baixa|IMPORTANTE|  
<!-- Start of picture text -->
pg/mL. Houve uma redução significativa nos níveis de<br>fosfatase alcalina entre os pacientes tratados e não<br>tratados, os valores foram de 193 ± 13 U/L e 91 ± 42<br>U/L, respectivamente (p< 0,05). Não houve alteração<br>significativa nos níveis de fosfato sérico, cálcio sérico,<br>creatinina sérica entre pacientes tratados e não tratados.<br><!-- End of picture text -->  
**Justificativa** : a. Desvios das intervenções pretendidas e ausência de cegamento de avaliadores; b. Não está claro como foi a seleção dos participantes; c. Histórico de tratamento prévio difere entre os participantes, assim como a idade em que iniciou o tratamento; d. Tamanho amostral pequeno, não teve poder suficiente para avaliar uma diferença no desfecho avaliado.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Avaliação geral – GRADE (Evidence to Decision – EtD)** -->
A **Tabela E** contém a sumarização das evidências, organizadas de acordo com o layout da tabela Evidence to Decision  
(EtD), também da metodologia GRADE.  
**Tabela E -** Resumo dos principais domínios avaliados (Tabela _Evidence to Decision_ (EtD) do _webapp_ GRADE Pro)  
|**PERGUNTA**<br> <br>||
|---|---|
|**1)**<br>**O fósforo e**<br>**pacientes adultos c**<br>|**m monoterapia ou combinado com calcitriol é mais eficaz, efetivo e seguro, no tratamento dos**<br>**om HLX, do que a ausência de tratamento?**|
|**POPULAÇÃO**|Adultos com raquitismo hipofosfatêmico ligado ao cromossoma X|
|**INTERVENÇÃO**|Fósforo em monoterapia ou combinado com calcitriol (contínua ou intermitente)|
|**COMPARAÇÃO**|Ausência de tratamento ou as intervenções comparadas entre si|
|**DESFECHOS**<br>**PRINCIPAIS**<br>**AVALIAÇÃO**|Primários:<br>Melhora clínica – dor e fraqueza muscular<br>Normalização de níveis de vitamina D e de fosfatase alcalina<br>Secundários:<br>Eventos adversos (hiperparatireoidismo, alterações renais - nefrocalcinose)<br>Número de fraturas e pseudoartrose<br>Entesopatia|
|**Problema**<br>**O problema é uma**<br>|**prioridade?**<br> <br>|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA<br>CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente<br>não<br>● Provavelmente<br>sim<br>○ Sim<br>○ Varia<br>○ Incerto<br>**Efeitos Desejáveis**<br>**Quão substanciais**|A HLX é uma doença ultrarrara, cronicamente debilitante e deformante.<br>O tratamento convencional em adultos consiste na reposição oral de fosfato e vitamina D. No entanto,<br>esta terapia está associada a eventos adversos importantes. O perfil da relação entre riscos e benefícios a<br>longo prazo dessa terapia em adultos com HLX é incerta.<br>A incidência global de HLX é estima em 1 a cada 20.000-25.000 indivíduos<sup>38</sup>. A partir de dados<br>demográficos brasileiros, considerando uma base populacional de 211,5 milhões de habitantes, e da<br>prevalência referida de HLX em populações de outros países, a estimativa de indivíduos com HLX no<br>Brasil variou de 211 até 1.900 indivíduos<sup>39,40</sup>.<br>**são os efeitos desejáveis?**|  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|---|---|---|
|○ Trivial|Apesar da baixa qualidade metodo|lógica e variabilidade dos estudos, os estudos demonstraram redução|
|○Pequeno|significativa nos níveis de fosfatas|e alcalina. Os níveis de fósforo sérico foram divergentes nos estudos,|
|● Moderado<br>○ Grande<br>○ Varia|em estudo não houve diferença en<br>no outro estudo houve redução. O<br>foram divergentes, em um estudo|tre os grupos, em outro houve aumento nos níveis séricos de fósforo e<br>s resultados dos níveis séricos de vitamina D (1,25 (OH) 2D) também<br>não houve diferença entre os grupos e em outro os pacientes tratados|
|○ Incerto|apresentaram uma redução signific<br>níveis de cálcio sérico.<br>Apenas um estudo avaliou os nívei<br>concentrações de FGF23.<br>Desfechos de melhora clínica, com<br>estudos.|ativa. Nos três estudos não diferença entre os grupos com relação aos<br>s de FGF23, no qual o tratamento apresentou redução significativa nas<br>o redução da dor e da fraqueza muscular não foram avaliados nestes|
|**Efeitos Indesejáve**<br>**Quão substanciais**|**is**<br>**são os efeitos indesejáveis esperad**|**os?**|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Grande<br>● Moderado<br>○ Pequeno<br>○ Trivial<br>○ Varia<br>○ Incerto|Dois estudos avaliaram os eventos<br>casos de hipercalcemia e nenhum<br>houve nenhum caso de hiperparati<br>De acordo com guidelines intern<br>excessivo de fosfato e calcitriol<br>nefrocalcinose e insuficiência rena<br>e não modifica a dor relacionada<br>uso do tratamento convencional<br>gastrointestinais, como diarreia e c|adversos, em um deles houve um caso de hiperparatireoidismo, dois<br>caso de nefrolitíase ao longo do tratamento<sup>146</sup>. No outro estudo não<br>reoidismo hipercalcêmico ao longo do acompanhamento<sup>147</sup>.<br>acionais<sup>73–76</sup>o tratamento de longo prazo, com uso inadequado ou<br>pode causar hiperparatireoidismo e hipercalciúria com consequente<br>l. Além de não prevenir ou melhorar a perda auditiva ou entesopatias,<br>à osteoartrose. Alguns dos desafios frequentemente enfrentados pelo<br>são a adesão variável e a baixa tolerabilidade, incluindo sintomas<br>ólicas abdominais.|

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Certeza da Evidência** -->
**Qual é a certeza global na evidência?**  
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS||
|---|---|---|---|
|○ Muito baixa|A qualidade geral da evidência fo|i baixa para todos os desfechos.||
|● Baixa<br>○ Moderada<br>○ Alta<br>○ Sem estudos|**Desfech**|**o**<br>**Importância**|**Certainty of the**<br>**evidence**<br>**(GRADE)**|
|<br>incluídos|**Resposta bioquímica:**níveis séri<br>D; de 1,25-di-hidroxivitamina D [<br>creatinina sérica; PTH sérico imu<br>alcalina; fosfato sérico em jejum;<br>e concentrações de FGF23.|cos de 5-hidroxivitamina<br>1,25(OH)2D; cálcio sérico;<br>norreativo; fosfatase<br>excreção urinária de cálcio<br>IMPORTANTE|⨁◯◯◯<br>Muito baixa|
||Dois estudos apresentaram risco d<br>risco moderado (Imel, 2010).|e viés grave (Lyles, 1982 e Sullivan, 1992) e um e|studo apresentou|
|**Valores**<br>**Existe incerteza im**|**portante ou variabilidade dobre**|**o quanto as pessoas valoram os desfechos princ**|**ipais?**|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS||
|○ Incerteza ou<br>variabilidade<br>importante<br>○ Possivelmente<br>incerteza ou<br>variabilidade|Acredita-se que os pacientes adul<br>pelo tratamento com com fosfato|tos com HLX tenham preferência pela ausência d<br>e calcitriol, devido aos efeitos colaterais.|e tratamento do que|
|importante||||
|● Provavelmente<br>sem incerteza ou<br>variabilidade||||
|importante<br>○ Sem incerteza||||
|ou variabilidade<br>importante||||

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Balanço dos efeitos** -->
|**O balanço entre os**|**efeitos desejáveis e indesejáveis f**|**avorece a intervenção ou a comparação?**|
|---|---|---|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Favorece a<br>comparação|Apesar da baixa qualidade metodo<br>consistentes na redução dos níveis|lógica e variabilidade dos estudos, os resultados se mostraram<br>de fosfatase alcalina. Foram poucos os eventos adversos relatados|
|○ Provavelmente<br>favorece a|nos estudos, em um deles houve u<br>nenhum caso de nefrolitíase ao lo|m caso de hiperparatireoidismo, dois casos de hipercalcemia e<br>ngo do tratamento<sup>143</sup>. No entanto os estudos apresentam várias|
|comparação|limitações como um número amos|tral bem reduzido.|
|○ Não favorece<br>nem a interveção<br>nem a comparação<br>● Provavelmente<br>favorece a|De acordo com guidelines interna<br>melhorar parcialmente a dor óssea<br>por insuficiência espontânea. Por<br>entesopatias, e não modifica a dor|cionais<sup>73–76</sup>o tratamento padrão com fosfato e calcitriol pode<br>e a osteomalácia em pacientes adultos, e a cicatrização de fraturas<br>outro lado, este tratamento não previne ou melhora a perda auditiva ou<br>relacionada à osteoartrose.|
|intervenção|||
|○ Favorece a<br>intervenção|||
|○ Varia<br>○ Incerto|||
|**Aceitabilidade**<br>**A intervenção é ac**|**eitavel para os principais atores s**<br>|**ociais (stakeholders)?**<br>|
|JULGAMENTO|EVIDÊNCIAS DE PESQUISA|CONSIDERAÇÕES ADICIONAIS|
|○ Não<br>○ Provavelmente|Acredita-se que não teriam restriç|ões.|
|não<br>○ Provavelmente|||
|sim|||
|● Sim|||
|○ Varia<br>○ Incerto|||

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **RESUMO DOS JULGAMENTOS** -->
|**DOMÍNIO**||||**JULGAM**|**ENTO**||
|---|---|---|---|---|---|---|
|**PROBLEMA**|Não|Provavelme<br>nte não|**Provavel**<br>**mente**<br>**sim**|Sim|Varia|Incerto|  
|**EFEITOS**<br>**DESEJÁVEIS**|Trivial|Pequeno|**Moderad**<br>**o**|Grande||Varia|Incerto|
|---|---|---|---|---|---|---|---|
|**EFEITOS**<br>**INDESEJÁVEIS**|Grande|**Moderado**|Pequeno|Trivial||Varia|Incerto|
|**CERTEZA DA**<br>**EVIDÊNCIA**|Muito<br>baixa|**Baixa**|Moderada|Alta|||Sem estudos incluídos|
|**VALORES**|Incertez<br>a ou<br>variabili<br>dade<br>importa<br>nte|Possivelme<br>nte<br>incerteza ou<br>variabilidad<br>e<br>importante|**Provavel**<br>**mente**<br>**sem**<br>**incerteza**<br>**ou**<br>**variabilid**<br>**ade**<br>**importan**<br>**te**|Sem<br>incerteza<br>ou<br>variabilid<br>ade<br>important<br>e||||
|**BALANÇO DOS**<br>**EFEITOS**|Favorec<br>e a<br>compara<br>ção|Provavelme<br>nte favorece<br>a<br>comparação|Não<br>favorece<br>nem a<br>intervençã<br>o e nem a<br>comparaç<br>ão|**Provavel**<br>**mente**<br>**favorece**<br>**a**<br>**intervenç**<br>**ão**|Favore<br>ce a<br>interve<br>nção|Varia|Incerto|
|**ACEITABILIDA**<br>**DE**|Não|Provavelme<br>nte não|Provavel<br>mente sim|**Sim**||Varia|Incerto|
|<br>**TIPO DE RECOM**|**ENDAÇÃ**|<br>**O**||||||
|Recomendação forte<br>contra a intervenção|Recomend<br>condicio<br>contra<br>interven|ação<br>nal<br>a<br>ção<br>Não fav|orece uma ou|outra<br>**Reco**<br>**ç**<br>**condi**<br>**a fav**<br>**interv**|**menda**<br>**ão**<br>**cional**<br>**or da**<br>**enção**|Recomendação|forte a favor da intervenção|
|○|○||○||**●**||○|
|**RECOMENDAÇÕ**|**ES**|||||||  
Em pacientes adultos com HLX, quando continuar ou interromper o tratamento convencional e quando reiniciá-lo ainda não está claro, pois ainda existem poucos dados epidemiológicos sobre o curso natural da doença em adultos. No entanto, devido  
aos riscos conhecidos da terapia com calcitriol e fosfato, a recomendação dos _guidelines_ internacionais tem sido de interromper o tratamento no final do crescimento e reiniciar se houver desenvolvimento de problemas clínicos<sup>73–78</sup> .  
Portanto, recomenda-se, para os pacientes com HLX adultos e sintomáticos façam o uso do tratamento convencional com reposição de fosfato e calcitriol até controlar os sintomas.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **Pergunta PICO 2** -->
**Questão de pesquisa:** <mark>“</mark> _<mark>O uso de dispositivo de crescimento guiado, na parte interna ou externa no joelho em crianças e adolescentes, é mais eficaz, efetivo e seguro, para correção de deformidades decorrentes do raquitismo ou osteomalácia, do que o fixador externo de deformidades angulares?”</mark>_  
Nesta pergunta, pacientes (P) eram crianças e adolescentes, intervenção era (I) dispositivo de crescimento guiado (C) fixador externo de deformidades angulares; e desfechos (O) sobrevida global, sobrevida livre de progressão e eventos adversos.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **A. Estratégia de busca** -->
A estratégia de busca adotada para a questão 2 da pesquisa encontra-se no **Quadro E** .  
**Quadro E -** Estratégias de busca nas bases de dado PubMed, Cochrane e Embase.  
|**Base de**<br>**dados**|**Estratégia de busca**|**Resultados**|
|---|---|---|
|**Medline via**<br>**PubMed**|"Familial Hypophosphatemic Rickets"[MeSH Terms] OR "Rickets"[MeSH Terms] OR<br>"Osteomalacia"[MeSH Terms] OR "rickets, hypophosphatemic"[MeSH Terms] OR<br>"Hypophosphatemia"[MeSH<br>Terms]<br>OR<br>"XLH"[All<br>Fields]<br>OR<br>"heritable<br>hypophosphatemic rickets"[All Fields] AND (("Ilizarov Technique"[MeSH Terms] OR<br>"External Fixators"[MeSH Terms]) OR "Osteotomy"[MeSH Terms]) OR "growth<br>modulation" OR "Growth Plate" OR "circular fixator" OR "eight-Plate Guided Growth<br>System**"**OR**"**Hemiepiphysiodesis**"** <br>**Data: 05/10/2021**|294|
|**Embase**<br>**Total**|#17 #8 AND #16<br>#16 #9 OR #10 OR #11 OR #12 OR #13 OR #14 OR #15<br>#15 'internal fixator'/de AND [embase]/lim<br>#14 'bone plating system'/de AND [embase]/lim<br>#13 'orthopedic fixation device'/exp AND [embase]/lim<br>#12 'epiphysis plate'/exp AND [embase]/lim<br>#11 ('osteotomy'/exp OR 'osteotomy') AND [embase]/lim<br>#10 ('external fixator'/exp OR 'external fixator') AND [embase]/lim<br>#9 ('ilizarov technique'/exp OR 'ilizarov technique') AND [embase]/lim<br>#8 #1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7<br>#7 'oncogenic osteomalacia'/de AND [embase]/lim<br>#6 'x linked hypophosphatemic rickets'/de AND [embase]/lim<br>#5 ('hypophosphatemia'/exp OR 'hypophosphatemia') AND [embase]/lim 12760<br>#4 ('osteomalacia'/exp OR 'osteomalacia') AND [embase]/lim<br>#3 ('hypophosphatemic rickets'/exp OR 'hypophosphatemic rickets') AND [embase]/lim<br>#2 ('rickets'/exp OR 'rickets') AND [embase]/lim 10451<br>#1 ('familial hypophosphatemic rickets'/exp OR 'familial hypophosphatemic rickets')<br>AND[embase]/<br>**Data: 05/10/2021**|543<br>837|

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **B. Seleção das evidências** -->
A busca das evidências resultou em 837 referências. Destas, 53 foram excluídas por estarem duplicadas. Um total de 784 referências foi triado por meio da leitura de título e resumos, das quais 14 tiveram seus textos completos avaliados para confirmação da elegibilidade ( **Figura 3** ).  
**Figura 3 -** Fluxograma de seleção dos estudos  
<!-- Start of picture text -->
Publicações identificadas por meio da pesquisa<br>nas bases de dados (n=837)<br>PUBMED (n= 294)<br>EMBASE (n=543)<br>Duplicatas (n= 53)<br>Estudos avaliados pelo título e pelo resumo (n=784)<br>Publicações excluídas segundo critérios de<br>exclusão (n=770)<br>Publicações selecionadas para leitura completa<br>(n=14)<br>Publicações excluídas segundo critérios de<br>exclusão (n= 14)<br>Estudos incluídos (n=0)<br>Identificação<br>Seleção<br>Elegibilidade<br>Incluídos<br><!-- End of picture text -->  
Após um processo rigoroso e sistemático de busca e seleção de estudos, com critérios de inclusão claros e predefinidos, nenhum estudo foi elegível. Até o momento, não existe evidência comprovando que o uso de dispositivo de crescimento guiado, na parte interna ou externa no joelho em crianças e adolescentes, é mais eficaz, efetivo e seguro, para correção de deformidades decorrentes do raquitismo ou osteomalácia, do que o fixador externo de deformidades angulares. O **Quadro F -** reporta os estudos excluídos e o motivo da exclusão.  
**Quadro F -** Estudos excluídos e seus respectivos motivos de exclusão  
|**Autor, ano**|**Critério de exclusão**|**Motivo de exclusão detalhado**|
|---|---|---|
|Choi et al., 2002|Tipo de delineamento|Série de casos|
|Eralp et al., 2010||Série de casos|  
|Ferris et al., 1991|Série de casos|
|---|---|
|Funcentese et al., 2008|Série de casos|
|Horn et al., 2007|Série de casos|
|Kanel et al., 1995|Série de casos|
|Kocaoglu et al., 2009|Série de casos|
|Larson et al., 2010|Série de casos|
|Matsubara et al., 2007|Série de casos|
|Petje et al., 2008|Série de casos|
|Popkov et al., 2015|Série de casos|
|Song et al., 2006|Série de casos|
|Varred et al., 2018|Série de casos|
|Wirth et al., 2019|Série de casos|  
Após este processo de busca e seleção de evidências, o Grupo Elaborador discutiu os achados junto ao Comitê Gestor, em 29/10/2021. Estavam presentes metodologistas do grupo elaborador, representantes da Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS/SCTIE/MS) e da Coordenação-Geral de Avaliação de Tecnologias em Saúde. (CGATS/DGITIS/SCTIE/MS). Com base nos resultados identificados, os presentes concordaram que não havia evidências suficientes que justificassem a continuidade da demanda, considerando os pré-requisitos necessários para que a Conitec avaliasse a tecnologia para incorporação. Dessa forma, decidiu-se pelo encerramento da demanda.

---

<!-- METADADOS: doenca: Raquitismo e Osteomalácia | secao: **REFERÊNCIAS BIBLIOGRÁFICAS** -->
1. Uday S, Högler W. Nutritional rickets &amp; osteomalacia: A practical approach to management. Indian Journal of Medical Research. 2020;152(4):356.  
2. Chan JC, Roth KS. Hypophosphatemic Rickets [internet] [Internet]. Medscape. 2020. Available from: https://emedicine.medscape.com/article/922305-overview  
3. Holick MF. Vitamin D deficiency. N Engl J Med. 2007;357(3):266–81.  
4. Premaor MO, Furlanetto TW. Hipovitaminose D em Adultos: Entendendo Melhor a Apresentação de Uma Velha Doença. Arq Bras Endocrinol Metab. 2006;50:25–37.  
5. Kechichian E, Ezzedine K. Vitamin D and the Skin: An Update for Dermatologists. American Journal of Clinical Dermatology. 2018 Apr 9;19(2):223–35.  
6. Lichtenstein A, Ferreira-Júnior M, Sales MM, Aguiar FB de, Fonseca LAM, Sumita NM, et al. Vitamina D: ações extraósseas e uso racional. Revista da Associação Médica Brasileira. 2013 Sep;59(5):495–506.  
7. Edis Z, Haj Bloukh S. Vitamin D Deficiency: Main Factors Affecting The Serum 25-Hydroxyvitamin D ([25(Oh)D]) Status And Treatment Options. 2016 Jan;2348–6848.  
8. Naeem Z. Vitamin d deficiency- an ignored epidemic. International journal of health sciences. 2010 Jan;4(1):V–VI.  
9. Carpenter TO, Shaw NJ, Portale AA, Ward LM, Abrams SA, Pettifor JM. Rickets. Nature Reviews Disease Primers. 2017 Dec 21;3(1):17101.  
10.  Filho H de M, Castro LCG de, Damiani D. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metabol. 2006;50(4):802–13.  
11.  World Health Organization. Nutritional rickets: a review of disease burden, causes, diagnosis, prevention and treatment. 2019.  
12.  Carpenter TO, Shaw NJ, Portale AA, Ward LM, Abrams SA, Pettifor JM. Rickets. Nature Reviews Disease Primers. 2017 Dec 21;3(1):17101.  
13.  JA L, E C, LG. R. Metabolic bone disease. In: Endocrinology. 2008. p. 1269–310.  
14.  Nield LS, Mahajan P, Joshi A, Kamat D. Rickets: Not a Disease of the Past - American Family Physician. 2006 American Academy of Family Physicians. 2006;74:619-26(4):629–30.  
15.  de Menezes Filho H, de Castro LC DD. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metab. 2006;50(4):802–13.  
16.  Bastepe M, H. J. Inherited hypophosphatemic disorders in children and the evolving mechanisms of phosphate regulation. Rev Endocr Metab Disord. 2008;9(2):171–80.  
17.  de la Cerda-Ojeda F, González-Rodríguez JD, Madariaga L, Martínez-Díaz-Guerra G, Matoses-Ruipérez ML. Hypophosphataemic Rickets: Similar Phenotype of Different Diseases. Advances in Therapy. 2020 May 31;37(S2):80–8. 18.  Florenzano P, Hartley IR, Jimenez M, Roszko K, Gafni RI, Collins MT. Tumor-Induced Osteomalacia. Calcified Tissue International. 2021 Jan 5;108(1):128–42.  
19.  Eswarakumar AS, Ma NS, Ward LM, Backeljauw P, Wasserman H, Weber DR, et al. Long-Term Follow-up of Hypophosphatemic Bone Disease Associated With Elemental Formula Use: Sustained Correction of Bone Disease After Formula Change or Phosphate Supplementation. Clinical Pediatrics. 2020 Oct 15;59(12):1080–5.  
20.  Skrinar A, Dvorak-Ewell M, Evins A, Macica C, Linglart A, Imel EA, et al. The Lifelong Impact of X-Linked Hypophosphatemia: Results From a Burden of Disease Survey. Journal of the Endocrine Society. 2019 Jul 1;3(7):1321–34.  
21.  Seefried L, Smyth M, Keen R, Harvengt P. Burden of disease associated with X-linked hypophosphataemia in adults: a systematic literature review. Osteoporosis International. 2021 Jan 24;32(1):7–22.  
22.  Tovey FI, Hall ML, Ell PJ, Hobsley M. A review of postgastrectomy bone disease. J Gastroenterol Hepatol. 1992;7(6):639–45.  
23.  Cohen A, Drake MT. Epidemiology and etiology of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/epidemiology-and-etiology-of-  
osteomalacia?search=osteomalacia&topicRef=2040&source=see_link#H3169360  
24.  Mechica JB. Raquitismo e osteomalacia. Arq Bras Endocrinol Metab. 1999;43(6).  
25.  Yin Z, Du J, Yu F, Xia W. Osteoporosis and Sarcopenia. Osteoporosis and Sarcopenia. 2018;4(4):119–27.  
26.  Florenzano P, Hartley IR, Jimenez M, Roszko K, Gafni RI, Collins MT. Tumor - Induced Osteomalacia. Calcified Tissue International. 2020;(0123456789).  
27.  Scheinman SJ, Carpenter T. Hereditary hypophosphatemic rickets and tumor-induced osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/hereditary-hypophosphatemic-rickets-and-tumor-inducedosteomalacia?search=osteomalacia&source=search_result&selectedTitle=4~143&usage_type=default&display_rank=4#H22  
28.  Mechica JB. Raquitismo e osteomalacia. Arquivos Brasileiros de Endocrinologia & Metabologia. 1999 Dec;43(6):457– 66.  
29.  Linhares ER. Effect of nutrition on vitamin D status : studies on healthy and poorly nourished Brazilian children12. 2018;(May):625–30.  
30.  SARAIVA GL, CENDOROGLO MS, RAMOS LR, ARAÚJO LMQ, VIEIRA JGH, MAEDA SS, et al. Prevalência da Deficiência, Insuficiência de Vitamina D e Hiperp aratiroidismo Secundário em Idosos Institucionalizados e Moradores na Comunidade da Cidade de São Paulo, Brasil. Arq Bras Endocrinol Metab. 2007;51(3):437–42.  
31.  Moreira CA, Costa TMRL, Marques JVO, Sylvestre L, Almeida ACR, Maluf EMCP, et al. Prevalence and clinical characteristics of X-linked hypophosphatemia in Paraná, southern Brazil. Archives of Endocrinology and Metabolism. 2020 Oct 9;64(6):796–802.  
32.  Premaor MO, Alves GV, Crossetti LB, Furlanetto TW. to Hypovitaminosis D in Hypoalbuminemic Is Less Intense than in Normoalbuminemic Patients. 2004;24(1):47–53.  
33.  Scalco R, Premaor MO, Froehlich PE, Furlanetto TW. High prevalence of hypovitaminosis D and secondary hyperparathyroidism in elders living in nonprofit homes in South Brazil. Endocr. 2008;33:95–100.  
34.  Silva BCC, Rgos BMC, Fujii JB, Dias EP, Soares MMS. Prevalência de Deficiência e Insuficiência de Vitamina D e sua Correlação com PTH, Marcadores de Remodelação Óssea e Densidade Mineral Óssea, em Pacientes Ambulatoriais. 2008;482– 8.  
35.  Maeda SS, Saraiva GL, Hayashi LF, Cendoroglo MS, Ramos LR, Corrêa M de P, et al. Seasonal variation in the serum 25-hydroxyvitamin D levels of young and elderly active and inactive adults in São Paulo, Brazil. Dermato-Endocrinology. 2013 Jan 27;5(1):211–7.  
36.  Saraiva GL, Cendoroglo MS, Ramos LR, Araujo LMQ, Vieira JGH, Kunii I, et al. Influence of ultraviolet radiation on the production of 25 hydroxyvitamin D in the elderly population ˜ o Paulo ( 23 o 34 ’ S), Brazil in the city of Sa. Osteoporos Int. 2005;16:1649–54.  
37.  Arantes HP, Kulak CAM, Fernandes CE, Zerbini C, Bandeira F, Barbosa IC, et al. Correlation between 25hydroxyvitamin D levels and latitude in Brazilian postmenopausal women: from the Arzoxifene Generations Trial. Osteoporosis International. 2013 Oct 30;24(10):2707–12.  
38.  Padidela R, Nilsson O, Makitie O, Beck-Nielsen S, Ariceta G, Schnabel D, et al. The international X-linked hypophosphataemia (XLH) registry (NCT03193476): rationale for and description of an international, observational study. Orphanet Journal of Rare Diseases. 2020 Dec 30;15(1):172.  
39.  Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE em Saúde, Saúde D de G e I de T e I em. Relatório de recomendação, n<sup>o</sup> 594. Burosumabe para o tratamento de hipofosfatemia ligada ao cromossoma X em adultos e crianças. 2021.  
40.  OrphaNet. Hipofosfatemia ligada ao X [Internet]. 2019.  
41.  Brasil. Diretrizes Metodológicas: Elaboração de Diretrizes Clínicas. Ministério. Ministério da Saúde. Secretaria de Ciência T e IEstratégicosD de G e I de tecnologias em Saúde, editor. Brasília, DF; 2016. 96p.  
42.  Haffner D, Emma F, Eastwood DM, Duplan MB, Bacchetta J, Schnabel D, et al. Clinical practice recommendations for the diagnosis and management of X-linked hypophosphataemia. Nature Reviews Nephrology. 2019 Jul 8;15(7):435–55.  
43.  Macedo LC de, Soardi FC, Ananias N, Belangero VMS, Rigatto SZP, De-Mello MP, et al. Mutations in the vitamin D receptor gene in four patients with hereditary 1,25-dihydroxyvitamin D-resistant rickets. Arquivos Brasileiros de Endocrinologia & Metabologia. 2008 Nov;52(8):1244–51.  
44.  Elder CJ, Bishop NJ. Rickets. The Lancet. 2014;383(9929):1665–76.  
45.  Lorenzo JA, Canalis E RLG. Metabolic bone disease. In: Endocrinology. 2008. p. 1269–310.  
46.  Chibuzor MT, Graham-Kalio D, Osaji JO, Meremikwu MM. Vitamin D, calcium or a combination of vitamin D and calcium for the treatment of nutritional rickets in children. Cochrane Database of Systematic Reviews. 2020 Apr 17;  
47.  Uday S, Högler W. Nutritional rickets &amp; osteomalacia: A practical approach to management. Indian Journal of Medical Research. 2020;152(4):356.  
48.  Cohen A, Drake MT. Clinical manifestations, diagnosis, and treatment of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/clinical-manifestations-diagnosis-and-treatment-ofosteomalacia?search=Osteomalacia&source=search_result&selectedTitle=1~143&usage_type=default&display_rank=1#H13 18839684  
49.  Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. The Journal of Clinical Endocrinology & Metabolism. 2016 Feb;101(2):394–415.  
50.  Mughal Z. Rickets in childhood. Semin Musculoskelet Radiol. 2002;6(3):183–90.  
51.  Chong WH, Molinolo AA, Chen CC, Collins MT. Tumor-induced osteomalacia. Endocrine-Related Cancer. 2011 Jun;18(3):R53–77.  
52.  Atapattu N, Shaw N, Högler W. Relationship between serum 25-hydroxyvitamin D and parathyroid hormone in the search for a biochemical definition of vitamin D deficiency in children. Pediatric Research. 2013 Nov 2;74(5):552–6.  
53.  Z B. The relationship of hypocalcemic convulsions related to nutritional rickets with age, gender, season, and serum phosphorus levels. Neurosciences (Riyadh). 2007;12(4):302–5.  
54.  Laurent MR, De Schepper J, Trouet D, Godefroid N, Boros E, Heinrichs C, et al. Consensus Recommendations for the Diagnosis and Management of X-Linked Hypophosphatemia in Belgium. Frontiers in Endocrinology. 2021 Mar 19;12.  
55.  Beck-Nielsen SS, Mughal Z, Haffner D, Nilsson O, Levtchenko E, Ariceta G, et al. FGF23 and its role in X-linked hypophosphatemia-related morbidity. Orphanet Journal of Rare Diseases. 2019 Dec 26;14(1):58.  
56.  Ruppe MD. X-Linked Hypophosphatemia. In: Adam MP, Ardinger HH, Pagon RA, Wallace SE, Bean LJH, Mirzaa G, et al., editors. Seattle (WA); 1993.  
57.  Ultragenyx Brasil Farmacêutica Ltda. Bula do medicamneto: Crysvita® (burosumabe). [Internet]. Anvisa. 2019. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351011667202031/?substancia=26479  
58.  Chibuzor MT, Graham-Kalio D, Osaji JO, Meremikwu MM. Vitamin D, calcium or a combination of vitamin D and calcium for the treatment of nutritional rickets in children. Cochrane Database of Systematic Reviews. 2020 Apr 17;  
59.  Wagner C, Greer FR. Prevention of rickets and vitamin D deficiency in infants, children, and adolescents. Pediatrics. 2008;122(5):1142–52.  
60.  Thacher TD, Fischer PR, Isichei CO, Zoakah AI PJM. Prevention of nutritional rickets in Nigerian children with dietary calcium supplementation. Bone. 2012;50(5):1074–80.  
61.  Moreira CA, Ferreira CEDS, Madeira M, Silva BCC, Maeda SS, Batista MC, et al. Reference values of 25hydroxyvitamin D revisited: a position statement from the Brazilian Society of Endocrinology and Metabolism (SBEM) and the Brazilian Society of Clinical Pathology/Laboratory Medicine (SBPC). Archives of Endocrinology and Metabolism. 2020 May 27;64(4):462–78.  
62.  Tang BM, Eslick GD, Nowson C, Smith C, Bensoussan A. Use of calcium or calcium in combination with vitamin D supplementation to prevent fractures and bone loss in people aged 50 years and older: a meta-analysis. The Lancet. 2007 Aug;370(9588):657–66.  
63.  Bischoff-Ferrari HA, Willett WC, Wong JB, Giovannucci E, Dietrich T, Dawson-Hughes B. Fracture Prevention With Vitamin D Supplementation. JAMA. 2005 May 11;293(18):2257.  
64.  Kutluk G, Cetinkaya F BM. Comparisons of oral calcium, high dose vitamin D and a combination of these in the treatment of nutritional rickets in children. J Trop Pediatr. 2002;59(2):127–33.  
65.  Aggarwal V, Seth A, Marwaha RK, Sharma B, Sonkar P, Singh S AS. Management of nutritional rickets in Indian children: a randomized controlled trial. J Trop Pediatr. 2013;59(2):127–33.  
66.  Kutluk G, Cetinkaya F BM. Comparisons of oral calcium, high dose vitamin D and a combination of these in the treatment of nutritional rickets in children. J Trop Pediatr. 2002;59(2):127–33.  
67.  Thacher TD, Fischer PR, Pettifor JM, Lawson JO, Isichei CO, Reading JC et al. A comparison of calcium, vitamin D, or both for nutritional rickets in Nigerian children. N Engl J Med. 1999;341(8):563–8.  
68.  Thacher TD, Fischer PR PJM. Vitamin D treatment in calcium-deficiency rickets: a randomised controlled trial. Arch Dis Child. 2014;99(9):807–11.  
69.  Tieder M, Arie R, Bab I, Maor J, Liberman UA. A New Kindred with Hereditary Hypophosphatemic Rickets with Hypercalciuria: Implications for Correct Diagnosis and Treatment. Nephron. 1992;62(2):176–81.  
70.  Imel EA, Glorieux FH, Whyte MP, Munns CF, Ward LM, Nilsson O, et al. Burosumab versus conventional therapy in children with X-linked hypophosphataemia: a randomised, active-controlled, open-label, phase 3 trial. The Lancet. 2019 Jun;393(10189):2416–27.  
71.  Carpenter TO, Whyte MP, Imel EA, Boot AM, Högler W, Linglart A, et al. Burosumab Therapy in Children with X- Linked Hypophosphatemia. New England Journal of Medicine. 2018 May 24;378(21):1987–98.  
72.  Whyte MP, Carpenter TO, Gottesman GS, Mao M, Skrinar A, San Martin J, et al. Efficacy and safety of burosumab in children aged 1–4 years with X-linked hypophosphataemia: a multicentre, open-label, phase 2 trial. The Lancet Diabetes & Endocrinology. 2019 Mar;7(3):189–99.  
73.  Marcucci G, Brandi ML. Congenital Conditions of Hypophosphatemia Expressed in Adults. Calcified Tissue International [Internet]. 2021 Jan 14;108(1):91–103. Available from: https://link.springer.com/10.1007/s00223-020-00695-2  
74.  Carpenter TO, Imel EA, Holm IA, Jan de Beur SM, Insogna KL. A clinician’s guide to X-linked hypophosphatemia. Journal of Bone and Mineral Research [Internet]. 2011 Jul;26(7):1381–8. Available from: https://onlinelibrary.wiley.com/doi/10.1002/jbmr.340  
75.  Haffner D, Emma F, Eastwood DM, Duplan MB, Bacchetta J, Schnabel D, et al. Clinical practice recommendations for the diagnosis and management of X-linked hypophosphataemia. Nature Reviews Nephrology [Internet]. 2019 Jul 8;15(7):435– 55. Available from: http://www.nature.com/articles/s41581-019-0152-5  
76.  Lecoq A-L, Brandi ML, Linglart A, Kamenický P. Management of X-linked hypophosphatemia in adults. Metabolism [Internet]. 2020 Feb;103:154049. Available from: https://linkinghub.elsevier.com/retrieve/pii/S0026049519302641  
77.  Laurent MR, de Schepper J, Trouet D, Godefroid N, Boros E, Heinrichs C, et al. Consensus Recommendations for the Diagnosis and Management of X-Linked Hypophosphatemia in Belgium. Frontiers in Endocrinology. 2021 Mar 19;12.  
78.  Linglart A, Biosse-Duplan M, Briot K, Chaussain C, Esterle L, Guillaume-Czitrom S, et al. Therapeutic management of hypophosphatemic rickets from infancy to adulthood. Endocrine Connections. 2014 Mar;3(1):R13–30.  
79.  Cohen A, Drake MT. Clinical manifestations, diagnosis, and treatment of osteomalacia [Internet]. UpToDate. 2021. Available from: https://www.uptodate.com/contents/clinical-manifestations-diagnosis-and-treatment-ofosteomalacia?search=Osteomalacia&source=search_result&selectedTitle=1~143&usage_type=default&display_rank=1#H13 18839684  
80.  de Menezes Filho HC CPH. Raquitismo Hipofosfatêmico Ligado ao X. Projeto Diretrizes [Internet]. [Internet]. Associação Médica Brasileira e Conselho Federal de Medicina. 2004. Available from: http://www.projetodiretrizes.org.br/4_volume/29-RaquitisH.pdf.2004  
81.  Munns CF, Shaw N, Kiely M, Specker BL, Thacher TD, Ozono K, et al. Global Consensus Recommendations on Prevention and Management of Nutritional Rickets. The Journal of Clinical Endocrinology & Metabolism. 2016 Feb;101(2):394–415.  
82.  de Menezes Filho HC CPH. Raquitismo Hipofosfatêmico Ligado ao X. Projeto Diretrizes [Internet]. [Internet]. Associação Médica Brasileira e Conselho Federal de Medicina. 2004. Available from: http://www.projetodiretrizes.org.br/4_volume/29-RaquitisH.pdf.2004  
83.  Bastepe M, H. J. Inherited hypophosphatemic disorders in children and the evolving mechanisms of phosphate regulation. Rev Endocr Metab Disord. 2008;9(2):171–80.  
84.  Sanofi Medley Farmacêutica Ltda. Bula do medicamento: OS-CAL® 500 (carbonato de cálcio). 2020.  
85.  de Menezes Filho H, de Castro LC DD. Hypophosphatemic rickets and osteomalacia. Arq Bras Endocrinol Metab. 2006;50(4):802–13.  
86.  Ultragenyx Brasil Farmacêutica Ltda. Bula do medicamneto: Crysvita® (burosumabe). [Internet]. Anvisa. 2019. Available from: https://consultas.anvisa.gov.br/#/medicamentos/25351011667202031/?substancia=26479  
87.  Padidela R, Whyte MP, Glorieux FH, Munns CF, Ward LM, Nilsson O, et al. Patient-Reported Outcomes from a Randomized, Active-Controlled, Open-Label, Phase 3 Trial of Burosumab Versus Conventional Therapy in Children with X- Linked Hypophosphatemia. Calcified Tissue International. 2021 May 23;108(5):622–33.  
88.  Schindeler A, Biggin A, Munns CF. Clinical Evidence for the Benefits of Burosumab Therapy for X-Linked Hypophosphatemia (XLH) and Other Conditions in Adults and Children. Frontiers in Endocrinology. 2020 May 28;11.  
89.  Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE em Saúde, Saúde D de G e I de T e I em. PORTARIA SCTIE/MS N<sup>o</sup> 1, DE 19 DE FEVEREIRO DE 2021. Torna pública a decisão de incorporar o burosumabe para o tratamento da hipofosfatemia ligada ao cromossoma X em crianças conforme Protocolo Clínico e Diretrizes Terapêuticas (PCDT) e não incorporar o bu. 2021.  
90.  Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE em Saúde, Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde. PORTARIA N<sup>o</sup> 451, DE 29 DE ABRIL DE 2016: Protocolo Clínico e Diretrizes Terapêuticas do Raquitismo e Osteomalácia. Diario Oficial da União 2016.  
91.  Drugbank. Calcitriol [Internet]. 2021. Available from: https://go.drugbank.com/drugs/DB00136  
92.  Germed Farmacêutica LTDA. Bula de medicamento: Sigmariol® (calcitriol) Cápsula gelatinosa mole 0,25 mcg. 2014;  
93.  AGÊNCIA NACIONAL DE VIGILÂNCIA SANITÁRIA ANVISA. Consulta de medicamentos registrados [Internet]. 2021. Available from: https://consultas.anvisa.gov.br/#/medicamentos/q/?substancia=1602&situacaoRegistro=V  
94.  Berndt M, Ehrich JH, Lazovic D, Zimmermann J, Hillmann G, Kayser C, et al. Clinical course of hypophosphatemic rickets in 23 adults. Clinical nephrology. 1996 Jan;45(1):33–41.  
95.  Boros, E .; Rothenbuhler, A .; Haidar, H .; Prie, D .; Harvengt, P .; Vija, L .; Brailly-Tabard, S .; Chanson, P .; Linglart, A .; Kamenicky P. ; Prospective evaluation of bone mineralization, PTH regulation, and metabolic profile in adult patients with hereditary hypophosphatemic rickets. 53rd Annual Meeting of the European Society for Paediatric Endocrinology (ESPE). Hormone Research in Paediatrics. 2014;82(s1):1–507.  
96.  Boros, E .; Rothenbuhler, A .; Heinrichs, C .; BrachetBoros, E .; Rothenbuhler, A .; Heinrichs, C .; Brachet, C .; Esterle, L .; Kamenicky, P .; Harvengt, P .; Brailly-Tabard, S .; Haidar, H .; Gaucher, C .; Silve, C .; Gossiome, C .; Wicart, P .; Duplan, A. ; Outcomes of vitamin D analogues and phosphate supplements in patients with hereditary hypophosphatemic rickets , comparison with non-treated patients. 53rd Annual Meeting of the European Society for Paediatric Endocrinology (ESPE). Hormone Research in Paediatrics. 2014;82(s1):1–507.  
97.  Broseta, J.J.; López, L.C.; Guillén, E.; Gómez-Bori, A.; Mendizábal, S.; Hernández-Jaras J; Morbidity and clinical laboratory findings in adults with x-linked hypophosphatemia (xlh). World Congress on Osteoporosis, Osteoarthritis and Musculoskeletal Diseases (WCO-IOF-ESCEO 2019): Posters Abstracts. Osteoporosis International. 2019 Jul 9;30(S2):253– 773.  
98.  Broseta JJ, Lopez-Romero LC, Guillen E, Gómez-Bori A, Mendizabal S, Hernandez-Jaras J. X-linked hypophosphatemia (XLH) in adults: Clinical and laboratory findings. SP017X-LINKED HYPOPHOSPHATEMIA (XLH) IN ADULTS: CLINICAL AND LABORATORY FINDINGS. Nephrology Dialysis Transplantation. 2019 Jun 1;34(Supplement_1).  
99.  Cagnoli M, Richter R, Böhm P, Knye K, Empting S, Mohnike K. Spontaneous Growth and Effect of Early Therapy with Calcitriol and Phosphate in X-linked Hypophosphatemic Rickets. Pediatric endocrinology reviews : PER. 2017 Nov;15(Suppl 1):119–22.  
100.  Carpenter TO, Keller M, Schwartz D, Mitnick M, Smith C, Ellison A, et al. 24,25 Dihydroxyvitamin D supplementation corrects hyperparathyroidism and improves skeletal abnormalities in X-linked hypophosphatemic rickets--a clinical research center study. The Journal of Clinical Endocrinology & Metabolism. 1996 Jun;81(6):2381–8.  
101.  Carpenter TO, Olear EA, Zhang JH, Ellis BK, Simpson CA, Cheng D, et al. Effect of Paricalcitol on Circulating Parathyroid Hormone in X-Linked Hypophosphatemia: A Randomized, Double-Blind, Placebo-Controlled Study. The Journal of Clinical Endocrinology & Metabolism. 2014 Sep 1;99(9):3103–11.  
102.  Carpenter TO, Imel EA, Ruppe MD, Weber TJ, Klausner MA, Wooddell MM, et al. Randomized trial of the anti-FGF23 antibody KRN23 in X-linked hypophosphatemia. Journal of Clinical Investigation. 2014 Apr 1;124(4):1587–97.  
103.  Che H, Roux C, Etcheto A, Rothenbuhler A, Kamenicky P, Linglart A, et al. Impaired quality of life in adults with X- linked hypophosphatemia and skeletal symptoms. European Journal of Endocrinology. 2016 Mar;174(3):325–33.  
104.  Chesney RW. Supranormal 25-Hydroxyvitamin D and Subnormal 1,25-Dihydroxyvitamin D. American Journal of Diseases of Children. 1980 Feb 1;134(2):140.  
105.  Cheung M, Roschger P, Klaushofer K, Veilleux L-N, Roughley P, Glorieux FH, et al. Cortical and Trabecular Bone Density in X-Linked Hypophosphatemic Rickets. The Journal of Clinical Endocrinology & Metabolism. 2013 May 1;98(5):E954–61.  
106.  Chung W-T, Niu D-M, Lin C-Y. Clinical aspects of X-linked hypophosphatemic rickets. Acta paediatrica Taiwanica = Taiwan er ke yi xue hui za zhi. 43(1):26–34.  
107.  Colares Neto, G. De Paula; Yamauchi, F.I.; Baroni, R.H.; Fontenele, I.; Gomes, A.C.; Chammas, M.C.; Matsunaga R; Nephrocalcinosis and nephrolithiasis in 36 X-linked hypophosphataemic rickets patients: Diagnostic imaging and evaluation of risk factors in a single-centre study. 54th Annual Meeting of the European Society for Paediatric Endocrinology (ESPE). Hormone Research in Paediatrics. 2015 Sep 22;84(1):1–622.  
108.  Colares Neto G de P, Ide Yamauchi F, Hueb Baroni R, de Andrade Bianchi M, Cavalanti Gomes A, Chammas MC, et al. Nephrocalcinosis and Nephrolithiasis in X-Linked Hypophosphatemic Rickets: Diagnostic Imaging and Risk Factors. Journal of the Endocrine Society. 2019 May 1;3(5):1053–61.  
109.  Connor J, Olear EA, Insogna KL, Katz L, Baker S, Kaur R, et al. Conventional Therapy in Adults With X-Linked Hypophosphatemia: Effects on Enthesopathy and Dental Disease. The Journal of Clinical Endocrinology & Metabolism. 2015 Oct 1;100(10):3625–32.  
110.  Connor, J.; Olear, E.; Katz, L.; Baker, S.; Kaur, R.; Simpson, C.; Sterpka, J.; Zhang, J.; Dubrow, R.; Insogna K; Extended conventional therapy in adult patients with X-linked hypophosphatemia: Effects on enthesopathy and dentition. Annual Meeting of the American Society for Bone and Mineral Research Seattle, WA 2015. Journal of Bone and Mineral Research. 2015 Feb;30(S1):S1–S1.  
111.  Dahir K, Roberts MS, Krolczyk S, Simmons JH. X-Linked Hypophosphatemia: A New Era in Management. Journal of the Endocrine Society. 2020 Dec 1;4(12).  
112.  Delvin EE, Glorieux FH. Serum 1,25-dihydroxyvitamin D concentration in hypophosphatemic vitamin D-resistant rickets. Calcified Tissue International. 1981 Dec;33(1):173–5.  
113.  Biosse Duplan M, Coyac BR, Bardet C, Zadikian C, Rothenbuhler A, Kamenicky P, et al. Phosphate and Vitamin D Prevent Periodontitis in X-Linked Hypophosphatemia. Journal of Dental Research. 2017 Apr 13;96(4):388–95.  
114.  Faiyaz-Ul-Haque M, AlDhalaan W, AlAshwal A, Bin-Abbas BS, AlSagheir A, Alotaiby M, et al. Hereditary 1,25dihydroxyvitamin D-resistant rickets (HVDRR): clinical heterogeneity and long-term efficacious management of eight patients from four unrelated Arab families with a loss of function VDR mutation. Journal of Pediatric Endocrinology and Metabolism. 2018 Aug 28;31(8):861–8.  
115.  Gjørup H, Beck-Nielsen SS, Haubek D. Craniofacial and dental characteristics of patients with vitamin-D-dependent rickets type 1A compared to controls and patients with X-linked hypophosphatemia. Clinical Oral Investigations. 2018 Mar 12;22(2):745–55.  
116.  Glorieux FH, Marie PJ, Pettifor JM, Delvin EE. Bone Response to Phosphate Salts, Ergocalciferol, and Calcitriol in Hypophosphatemic Vitamin D-Resistant Rickets. New England Journal of Medicine. 1980 Oct 30;303(18):1023–31.  
117.  Hansen, S.; Shanbhogue, V.V.; Jorgensen, N.R.; Beck-Nielsen SS. Increased levels of bone formation and resorption markers in patients with hypophosphatemic rickets. 57th Annual Meeting of the European Society for Paediatric Endocrinology, ESPE 2018. Hormone Research in Paediatrics. 2018;90(1).  
118.  Hansen S, Shanbhogue V V., Jørgensen NR, Beck-Nielsen SS. Elevated Bone Remodeling Markers of CTX and P1NP in Addition to Sclerostin in Patients with X-linked Hypophosphatemia: A Cross-Sectional Controlled Study. Calcified Tissue International. 2019 Jun 1;104(6):591–8.  
119.  Harrell RM, Lyles KW, Harrelson JM, Friedman NE, Drezner MK. Healing of bone disease in X-linked hypophosphatemic rickets/osteomalacia. Induction and maintenance with phosphorus and calcitriol. Journal of Clinical Investigation. 1985 Jun 1;75(6):1858–68.  
120.  Imel, E .; Gray, A .; Hasegawa, H .; Yamazaki, Y .; Econs M. ; Measurement of serum klotho, a co-receptor for FGF23, in x-linked hypophosphatemic rickets. ASBMR 2010 Annual Meeting SU0001-SU0482. Journal of Bone and Mineral Research. 2010;25(S1):S225–362.  
121.  Imel EA, Zhang X, Ruppe MD, Weber TJ, Klausner MA, Ito T, et al. Prolonged Correction of Serum Phosphorus in Adults With X-Linked Hypophosphatemia Using Monthly Doses of KRN23. The Journal of Clinical Endocrinology & Metabolism. 2015 Jul;100(7):2565–73.  
122.  Insogna KL, Briot K, Imel EA, Kamenický P, Ruppe MD, Portale AA, et al. A Randomized, Double-Blind, PlaceboControlled, Phase 3 Trial Evaluating the Efficacy of Burosumab, an Anti-FGF23 Antibody, in Adults With X-Linked Hypophosphatemia: Week 24 Primary Analysis. Journal of Bone and Mineral Research. 2018 Aug;33(8):1383–93.  
123.  Javier, R.M.; Briot, K.; Cohen-Solal, M.; Cortet, B.; Eloy, C.; Laroche, M.; Lafforgue, P.; De Vernejoul M-C. X-linked hypophosphatemia in adults and rheumatological manifestations: Cross-sectional survey of the bone section of the french society of rheumatology sfr-os. J Bone Miner Res. 2013;28.  
124.  Jehan F, Gaucher C, Nguyen TM, Walrant-Debray O, Lahlou N, Sinding C, et al. Vitamin D Receptor Genotype in Hypophosphatemic Rickets as a Predictor of Growth and Response to Treatment. The Journal of Clinical Endocrinology & Metabolism. 2008 Dec 1;93(12):4672–82.  
125.  Jiménez M, Ivanovic-Zuvic D, Loureiro C, Carvajal CA, Cavada G, Schneider P, et al. Clinical and molecular characterization of Chilean patients with X-linked hypophosphatemia. Osteoporosis International. 2021 Sep 5;32(9):1825–36. 126.  Lyles KW, Harrelson JM, Drezner MK. The efficacy of vitamin D2 and oral phosphorus therapy in x-linked hypophosphatemic rickets and osteomalacia. Journal of Clinical Endocrinology and Metabolism. 1982;54(2):307–15.  
127.  Martin-Grace, J .; Crowley, RK; Kilbane, M .; Twomey, P .; McKenna M. Congenital hypophosphatemia in adults: Determinants of bone turnover markers and changes in renal phosphate handling following total parathyroidectomy. Irish Endocrine Society 42nd Annual Meeting. Irish Journal of Medical Science (1971 -). 2018 May 17;187(S5):173–226.  
128.  McEnery PT, Silverman FN, West CD. Acceleration of growth with combined vitamin D-phosphate therapy of hypophosphatemic resistant rickets. The Journal of Pediatrics. 1972 May;80(5):763–73.  
129.  MIYAMOTO J, KOTO S, HASEGAWA Y. Final Height of Japanese Patients with X-Linked Hypophosphatemic Rickets. Effect of Vitamin D and Phosphate Therapy. Endocrine Journal. 2000;47(2):163–7.  
130.  Nakajima S, Yamaoka K, Yamamoto T, Okada S, Tanaka H, Seino Y. Decreased concentration of 1,25-dihydroxyvitamin D3 receptors in peripheral mononuclear cells of patients with X-linked hypophosphatemic rickets: effect of phosphate supplementation. Bone and Mineral. 1990 Sep;10(3):201–9.  
131.  Nakamura Y, Takagi M, Takeda R, Miyai K, Hasegawa Y. Hypertension is a characteristic complication of X-linked hypophosphatemia. Endocrine Journal. 2017;64(3):283–9.  
132.  Ohata, Y.; Kubota, T.; Takeyari, S.; Kitaoka, T.; Nakano, Y.; Miyata, K.; Yamada, C.; Ozono, K.; Ishihara, Y.; Nakayama, H.; Yamamoto, K.; Fujiwara, M.; Yamamoto, K.; Michigami, T.; Mabe, H.; Yamaguchi, T.; Matsui, K.; Tamada, I.; Namba, N.; Yamamoto, A.; A; Mutational analysis of the PHEX gene and genotype-phenotype correlation in 37 Japanese patients with X-linked hypophosphatemic rickets. Annual Meeting of the American Society for Bone and Mineral Research. 2019. Journal of Bone and Mineral Research. 2019;34(1).  
133.  Patzer L, van’t Hoff W, Shah V, Hallson P, Kasidas GP, Samuell C, et al. Urinary supersaturation of calcium oxalate and phosphate in patients with X-linked hypophosphatemic rickets and in healthy schoolchildren. The Journal of Pediatrics. 1999 Nov;135(5):611–7.  
134.  Rafaelsen S, Johansson S, Ræder H, Bjerknes R. Hereditary hypophosphatemia in Norway: a retrospective populationbased study of genotypes, phenotypes, and treatment complications. European Journal of Endocrinology. 2016 Feb;174(2):125– 36.  
135.  Salcion Picaud A, Lassalle L, Merzoug V, Usardi A, Rothenbuhler A, Kamenicky P, et al. SAT0364 High prevalence of enthesopathies in patients with x-linked hypophosphatemia. In: Saturday, 16 JUNE 2018. BMJ Publishing Group Ltd and European League Against Rheumatism; 2018. p. 1046.3-1047.  
136.  Shanbhogue VV, Hansen S, Jørgensen NR, Beck-Nielsen SS. Impact of Conventional Medical Therapy on Bone Mineral Density and Bone Turnover in Adult Patients with X-Linked Hypophosphatemia: A 6-Year Prospective Cohort Study. Calcified Tissue International. 2018 Mar 15;102(3):321–8.  
137.  Suzuki E, Yamada M, Ariyasu D, Izawa M, Miyamoto J, Koto S, et al. Patients with Hypophosphatemic Osteomalacia Need Continuous Treatment during Adulthood. Clinical Pediatric Endocrinology. 2009;18(1):29–33.  
138.  Taylor A, Sherman NH, Norman ME. Nephrocalcinosis in X-linked hypophosphatemia: effect of treatment versus disease. Pediatric Nephrology. 1995 Apr;9(2):173–5.  
139.  Theret, C.; Esterle, L.; Souchon, P.-F.; Roussey, G.; Allain-Launay, E.; Rothenbuhler, A.; Deschenes, G.; Chaussain, C.; Prie, D.; Kamenicky, P.; Silve, C.; Linglart A; Patients with mutations in phex or FGF23 share FGF23 excess but present distinct BONE and mineral metabolism features. Vol. 34, Endocrine Reviews - 95th Annual Meeting and Expo of the Endocrine Society, ENDO. 2013.  
140.  Tieder M, Blonder J, Strauss S, Shaked U, Maor J, Gabizon D, et al. Hyperoxaluria Is Not a Cause of Nephrocalcinosis in Phosphate-Treated Patients with Hereditary Hypophosphatemic Rickets. Nephron. 1993;64(4):526–31.  
141.  Tiosano D, Hadad S, Chen Z, Nemirovsky A, Gepstein V, Militianu D, et al. Calcium Absorption, Kinetics, Bone Density, and Bone Structure in Patients with Hereditary Vitamin D-Resistant Rickets. The Journal of Clinical Endocrinology & Metabolism. 2011 Dec;96(12):3701–9.  
142.  Lyles KW, Clark AG, Drezner MK. Serum 1,25-dihydroxyvitamin D levels in subjects with X-linked hypophosphatemic rickets and osteomalacia. Calcified Tissue International [Internet]. 1982 Dec;34(1):125–30. Available from: http://link.springer.com/10.1007/BF02411222  
143.  Sullivan W, Carpenter T, Glorieux F, Travers R, Insogna K. A prospective trial of phosphate and 1,25-dihydroxyvitamin D3 therapy in symptomatic adults with X-linked hypophosphatemic rickets. The Journal of Clinical Endocrinology & Metabolism [Internet]. 1992 Sep;75(3):879–85. Available from: https://academic.oup.com/jcem/article-  
lookup/doi/10.1210/jcem.75.3.1517380  
144.  Imel EA, DiMeglio LA, Hui SL, Carpenter TO, Econs MJ. Treatment of X-Linked Hypophosphatemia with Calcitriol and Phosphate Increases Circulating Fibroblast Growth Factor 23 Concentrations. The Journal of Clinical Endocrinology & Metabolism [Internet]. 2010 Apr 1;95(4):1846–50. Available from: https://academic.oup.com/jcem/article/95/4/1846/2597239 145.  Sterne JA, Hernan MA, Reeves BC, Savovic J, Berkman ND, Viswanathan M, et al. ROBINS-I: a tool for assessing risk of bias in non-randomised studies of interventions. BMJ (Clinical research ed). 2016 Oct;355:i4919.  
146.  Sullivan W, Carpenter T, Glorieux F, Travers R, Insogna K. A prospective trial of phosphate and 1,25-dihydroxyvitamin D3 therapy in symptomatic adults with X-linked hypophosphatemic rickets. The Journal of Clinical Endocrinology & Metabolism. 1992 Sep;75(3):879–85.  
147.  Imel EA, DiMeglio LA, Hui SL, Carpenter TO, Econs MJ. Treatment of X-Linked Hypophosphatemia with Calcitriol and Phosphate Increases Circulating Fibroblast Growth Factor 23 Concentrations. The Journal of Clinical Endocrinology & Metabolism. 2010 Apr 1;95(4):1846–50.

---

