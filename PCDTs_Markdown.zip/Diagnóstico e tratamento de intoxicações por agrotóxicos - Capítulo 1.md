<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Geral -->
PORTARIA Nº 43, DE 16 DE OUTUBRO DE 2018 (*)  
Torna pública a decisão de aprovar as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - capítulo 1, no âmbito do Sistema Único de Saúde - SUS.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS DO MINISTÉRIO DA SAÚDE, no uso de suas atribuições legais e com base nos termos dos art. 20 e art. 23 do Decreto 7.646, de 21 de dezembro de 2011, resolve:  
Art. 1º Ficam aprovadas as Diretrizes Brasileiras para diagnóstico e tratamento das intoxicações por agrotóxicos - capítulo 1, no âmbito do Sistema Único de Saúde - SUS.  
Art. 2º O prazo máximo para efetivar a oferta ao SUS é de cento e oitenta dias.  
Art. 3º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico: http://conitec.gov.br/.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Geral -->
- (*)Republicada por ter saído no DOU nº 200, de 17 de outubro de 2018, Seção 1, página 44, com incorreção no original.  
1

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
As intoxicações exógenas por agrotóxicos são processos patológicos caracterizadas por um desequilíbrio fisiológico, com manifestações variadas de acordo com a classe das substâncias. A exposição aos agrotóxicos pode ser de natureza ocupacional, acidental, delitiva, suicida, entre outras. Considera-se como caso suspeito todo indivíduo que, tendo sido exposto a agrotóxicos, apresente sinais e sintomas clínicos de intoxicação ou alterações laboratoriais possivelmente compatíveis<sup>1</sup> .  
O aumento da comercialização de agrotóxicos em nosso país é acompanhado pelo aumento do número de registros de intoxicações exógenas relacionadas a esses produtos. No Brasil, segundo informações fornecidas pela Coordenação De Vigilância Ambiental Do Ministério Da Saúde, entre 2007 e 2017, foram registrados um total de 29.472 casos de intoxicações acidentais por agrotóxicos no Sistema Nacional de Agravos de Notificação (Sinan). Dessa forma, o Ministério da Saúde considera que a exposição humana a agrotóxicos é um importante problema de saúde pública. Inferese pelos dados disponibilizados no Sinan que trabalhadores rurais, bem como profissionais de empresas da agricultura, de fábricas formuladoras, desinsetizadores e aplicadores de agrotóxicos em campanhas de saúde pública representam um grupo vulnerável à intoxicação por esses produtos<sup>2</sup> .  
Contudo, não há como desconsiderar que outras formas de exposições ambientais, acidentais e intencionais também contribuam de forma significativa para o número de casos de intoxicações por agrotóxicos registrados em nosso país. Sendo assim, a existência de populações adjacentes a áreas de risco de formulação e uso de agrotóxicos, a contaminação de corpos hídricos e a presença de resíduos de agrotóxicos em diversas matrizes alimentares exigem uma intensificação das ações de vigilância de populações expostas ou potencialmente expostas a esses compostos por parte dos órgãos de saúde<sup>3</sup> .  
Diante desse contexto, desde 2002, o Ministério da Saúde, por meio da Vigilância em Saúde de Populações Expostas a Agrotóxicos (VSPEA), vem incentivando e auxiliando os estados na implementação de ações integradas, voltadas para a adoção de medidas de prevenção dos fatores de risco, promoção e assistência à saúde para os casos suspeitos de intoxicação exógena por agrotóxicos. Em 2012, a Portaria MS/GM nº 2938/2012 autorizou o repasse de recurso aos estados e ao Distrito Federal para o fortalecimento da VSPEA, contribuindo para a implantação desta vigilância nas 27 Unidades da Federação<sup>2</sup> .  
A publicação das _Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos “_ representa uma ação estruturante de VSPEA no âmbito do Sistema Único de Saúde  
2  
(SUS). Essas têm como objetivo propor recomendações que auxiliem aos profissionais de saúde da atenção básica, média e alta complexidade, na escolha de intervenções adequadas para o atendimento de pacientes intoxicados por agrotóxicos, considerando as melhores evidências científicas disponíveis.  
Esse documento apresenta um capítulo inicial dessas diretrizes e contempla uma abordagem geral voltada a pacientes com suspeita de exposição aguda a qualquer agrotóxico, o que inclui prevenção, diagnóstico e tratamento. Nos capítulos posteriores serão desenvolvidos aspectos relacionados ao diagnóstico e tratamento das intoxicações por inibidores de colinesterase, glifosato, piretroides, 2,4D, bipiridílios e um capítulo final sobre o monitoramento da população cronicamente exposta.  
**Classificação Estatística Internacional de Doenças e Problemas Relacionados à Saúde (CID-10)**  
Além do CID-10 da afecção principal (T60 - Efeitos tóxicos de pesticidas), esse deverá ser complementado pelas codificações: X48 (Envenenamento [intoxicação] acidental por e exposição a pesticidas); X68 (Autointoxicação intencional por e exposição intencional, a pesticidas); X87 (Agressão por pesticidas); Y18 (Envenenamento [intoxicação] por e exposição a pesticidas, intenção não determinada), as quais permitem conhecer a circunstância das intoxicações.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
**Indivíduos com suspeita de intoxicação ou intoxicados por agrotóxicos, considerando as exposições agudas ou crônicas agudizadas no âmbito acidental, nos processos relacionados ao trabalho e as de caráter intencional.**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
Indivíduos com manifestações derivadas da exposição crônica a agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
|**Diretriz**|**Abordagem inicial do paciente intoxicado por agrotóxicos**|
|---|---|
|CID 10|Causa: T60|
||Circunstância: X48, X68, X87, Y18|
|População alvo|Indivíduos com suspeita de intoxicação ou intoxicados por agrotóxicos,|
||em suas formas agudas.|
|Usuários|Médico Clínico Geral|  
3  
||Médico da Família<br>Médicos lotados em unidades de Urgência e Emergência<br>Médico toxicologista<br>Profissionais de saúde (não foram consideradas ações para atenção pré-<br>hospitalar)<br>Secretarias de Saúde (Municipal e Estadual)|
|---|---|
|Nível<br>de<br>atendimento|Baixa, média e alta complexidade|
|Grupo Elaborador|Profissionais com expertise em toxicologia e medicina do trabalho, sendo<br>eles representantes da Associação Brasileira de Centros de Informações<br>Toxicológicas (ABRACIT), dos Centros de Informação e Assistência<br>Toxicológica<br>(CIATOX),<br>médicos<br>toxicologistas<br>de<br>núcleos<br>universitários do país, médicos do trabalho das secretarias de saúde<br>estaduais, além de membros integrantes de diversos departamentos do<br>Ministério da Saúde.|
|Escopo|Esse documento apresentará um capítulo inicial de abordagem geral do<br>indivíduo intoxicado por agrotóxicos que inclui a prevenção, diagnóstico<br>e tratamento. Nos capítulos posteriores serão desenvolvidos aspectos<br>relacionados ao diagnóstico e tratamento das intoxicações relacionadas a<br>inibidores de colinesterase, glifosato, piretroides, 2,4-D e um capítulo<br>final sobre o monitoramento da população cronicamente exposta.|
|Objetivos|Propor recomendações que auxiliem aos profissionais de saúde da atenção<br>básica, média e alta complexidade, na escolha de intervenções adequadas<br>para o atendimento de pacientes intoxicados por agrotóxicos,<br>considerando as melhores evidências científicas disponíveis.|
|Metodologia|Busca de Guias de Práticas Clínicas (GPC) para adaptação;|
|(Metodologia<br>detalhada - Anexo<br>A)|Busca sistemática e manual;<br>Avaliação de qualidade de evidências e de recomendações por GRADE|
|Validação externa|Médico de emergência<br>Médico toxicologista|  
4  
||Médico pediatra|
|---|---|
|Conflito<br>de|Todos os participantes declararam não possuir conflitos de interesse|
|interesse||
|Financiamento|Ministério da Saúde/ Organização Pan-Americana de Saúde|
|Atualização|4 anos ou quando a evidência determinar|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
As **Recomendações (R)** apresentadas foram elaboradas, considerando as ferramentas metodológicas propostas pelo sistema GRADE - “ _Grading of Recommendations Assessment, Development and Evaluation_ ”. Elas são apresentadas em formato de quadros, conforme exemplo descrito na Quadro 1 abaixo, juntamente com seus respectivos níveis de recomendação (direção – contra ou a favor; força – forte ou condicional).  
Para cada recomendação são apresentadas as **Evidências (E)** encontradas e a avaliação dessas, de acordo com os critérios pré-definidos pela referida metodologia. Cabe destacar que o nível de evidência representa a qualidade da evidência científica disponível e define a confiança na informação utilizada (alta, moderada, baixa ou muito baixa) para cada desfecho. Junto com as evidências, também estão referenciados os anexos onde podem ser encontradas as tabelas de síntese de evidências e tabelas de avaliação de qualidade de evidências por GRADE.  
É importante ressaltar que uma recomendação forte não está necessariamente atrelada a uma qualidade de evidência alta ou moderada, assim como evidências de qualidade baixa não necessariamente formarão uma recomendação condicional. É possível que exista uma evidência muito baixa que gere uma recomendação forte, e o contrário também pode acontecer. Isso porque a força de recomendação está atrelada ao equilíbrio de diversos fatores relacionados como o balanço de efeitos desejáveis e não desejáveis, valores e preferencias dos pacientes, custos, entre outros.  
Quadros destacados no texto como **Pontos de Boa Prática (PBP)** indicam condutas que são fortemente estabelecidas e indicadas pelo grupo de especialistas, apesar de não terem sido encontradas evidências que as subsidiam.  
**Quadro 1 - Disposição de evidências e recomendações no texto.**  
|**Recomendação**|
|---|
|Texto e força da recomendação|
|**Evidências**|  
Evidências encontradas com suas respectivas referências e nível.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: Diretrizes Brasileiras para Diagnóstico e Tratamento de Intoxicações por Agrotóxicos – Capítulo 1 -->
Conduta estabelecida.  
5  
Capítulo 1 – Abordagem Geral do Paciente Intoxicado por Agrotóxicos

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Na assistência de uma pessoa intoxicada, o prognóstico se mostra mais favorável quando, no atendimento inicial, é possível: identificar o agente tóxico, estimar a quantidade absorvida, determinar a via de exposição e o tempo transcorrido desde a exposição até o atendimento. Estas informações favorecem um diagnóstico mais preciso, o qual, por sua vez, direciona as decisões terapêuticas e resulta em um melhor prognóstico<sup>4</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Realize uma triagem rápida, seguida de uma anamnese que permita uma adequada avaliação do risco da gravidade da intoxicação.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
**tempo possível**<sup>4</sup> **.**  
**São Informações essenciais**<sup>5</sup> **:**  
- **_Quem?_**  
Nome, idade, ocupação, sexo, gravidez, histórico (uso de medicamentos, doenças agudas e crônicas, uso de álcool, drogas ilícitas).  
- **_O que foi utilizado e quanto?_** Agente e quantidade utilizada. Verificar a disponibilidade da embalagem e bula do produto.  
- **Qual a via de exposição?** Via oral, dérmica, inalatória, intravenosa (intencional).  
- **_Onde?_**  
Obter dados sobre o local de exposição.  
- **_Como?_** Determinar a circunstância na qual ocorreu a exposição ao agrotóxico, se essa foi acidental, ocupacional, tentativa de suicídio, agressão, ambiental (vazamentos ou deriva de pulverização durante a aplicação). E a intenção de uso do produto.  
- **_Há quanto tempo_ ?**  
Estabelecer o lapso temporal entre a exposição e o atendimento.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Colete informações junto aos acompanhantes ou familiares das vítimas de intoxicações por agrotóxicos, especialmente quando são crianças ou pacientes inconscientes<sup>5</sup> .  
6  
Ligue para o Centro de Informação e Assistência Toxicológica (CIATox) de sua região para orientações sobre suspeita de intoxicações com manifestações clínicas atípicas,  quadros iniciais de difícil identificação ou caso haja qualquer dúvida em relação à intoxicação<sup>5,6</sup> .  
No site: http://portal.anvisa.gov.br/disqueintoxicacao estão disponíveis os números de contato dos diferentes centros de informação e assistência toxicológica da Rede Nacional de Centros de Informação e Assistência Toxicológica (Renaciat). O número gratuito do serviço Disqueintoxicação é **0800 722 6001.**  
No site <u>http://abracit.org.br/wp/centros/ estão disponíveis os contatos dos centros de intoxicação</u> da Associação Brasileira de Centros de Informação e Assistência Toxicológica (ABRACIT).  
Consulte na internet também a Ficha de Segurança Química (FISQP), o rótulo e a bula do agrotóxico para mais informações<sup>7</sup> .  
A Ficha de Segurança Química (FISPQ) é um documento normalizado pela Associação Brasileira de Normas Técnicas (ABNT) que apresenta informações sobre aspectos diversos relacionados a produtos químicos (substâncias ou misturas). Sendo assim, ela, além de outras informações, apresenta recomendações sobre medidas de proteção e ações em situação de emergência<sup>7</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Pacientes assintomáticos ou que apresentem sintomas leves, normalmente não requerem hospitalização.  
O paciente deve ser monitorado durante um período mínimo de 6 a 12 horas.  
Esse monitoramento deve incluir a avaliação dos seguintes parâmetros:  
- estado de alerta;  
- sinais neurológicos;  
- sinais vitais;  
- se possível, oximetria de pulso;  
Após a alta, assegurar que o paciente será mantido em observação médica.  Ele deve retornar ao serviço de saúde caso apresente algum sintoma.  
A ausência de sinais e sintomas, após 12 h, reduz a probabilidade de sua ocorrência. Contudo, é preciso atentar para os casos de intoxicações com inibidores de colinesterease ou com compostos organofosforados altamente lipofílicos, como é o caso do fethion. Esses compostos podem produzir os primeiros sinais de debilidade muscular e insuficiência respiratória mesmo depois de 48 h da exposição.  
7

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A maioria das intoxicações se manifesta por meio de sinais e sintomas relacionados à toxicodinâmica do agente tóxico. Dessa forma, as manifestações podem ser imediatas, mistas ou tardias. O reconhecimento das toxíndromes clássicas (ex.: síndrome colinérgica- agrotóxicos organofosforados e carbamatos e cáusticos- paraquate) pode auxiliar no estabelecimento de um diagnóstico mais preciso<sup>10</sup> .  
Os sinais e sintomas observados nas intoxicações por agrotóxicos dependem do agente, do tipo e da magnitude da exposição. De uma forma geral, irritações dérmicas e oculares, irritações do trato respiratório superior e inferior, respostas alérgicas, sintomas gastrintestinais e manifestações neurológicas podem ser observados em casos de intoxicações.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Realize um breve exame físico, no contexto do suporte vital, para identificar as medidas imediatas necessárias para estabilizar o paciente. O exame deve incluir a verificação dos sinais vitais, do nível de consciência, avaliação do diâmetro e reatividade das pupilas (diâmetro e reatividade à luz), temperatura e umidade da pele, instalação da oximetria de pulso e medida da glicemia capilar, se disponíveis<sup>11</sup> .  
Considere a possibilidade da intoxicação ser resultante da combinação de diversas substâncias, visto que as formulações de agrotóxicos podem ter diferentes combinações de princípios ativos e adjuvantes, os quais podem alterar as manifestações clínicas da intoxicação<sup>4</sup> . Além disso pode ocorrer exposição simultânea a agrotóxicos e outros agentes (medicamentos, álcool e outras drogas). Esses podem ter manifestações similares ou antagônicas<sup>11,12</sup> .  
O paciente intoxicado pode apresentar um amplo espectro de manifestações clínicas que poderiam ser explicadas por outras causas como traumatismos, alterações neurológicas ou metabólicas, o que confunde o estabelecimento do diagnóstico. Há também a possibilidade da existência de comorbidades, que não devem ser negligenciadas<sup>5</sup> .  
Considere também a possibilidade de manifestações ou toxíndromes mistas ou parciais, por não ter transcorrido tempo suficiente para que se observem as manifestações plenas<sup>10</sup> .  
**Em pacientes pediátricos é importante suspeitar de intoxicação em episódios de início súbito com comprometimento do estado geral.**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Dada a diversidade de substâncias registradas e utilizadas como agrotóxicos, não é possível padronizar os exames a serem realizados em caso de intoxicação aguda. Entretanto, alguns exames laboratoriais podem auxiliar no diagnóstico e seguimento de pacientes intoxicados por esses agentes.  
8

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Solicite **hemograma e bioquímica sanguínea** em todos os pacientes intoxicados sintomáticos ou com histórico de exposição potencialmente grave.  
Solicite outros exames complementares de acordo com os sistemas comprometidos para cada substância e com a evolução do paciente.  
Alguns agrotóxicos contam com testes específicos que auxiliam na identificação do agente envolvido, mas o diagnóstico é fundamentalmente clínico.  
Realize os testes padronizados, de acordo com os protocolos locais e orientações do CIATox para determinar o agente envolvido na intoxicação, sempre que disponíveis, sem atrasar o início do tratamento.  
A intoxicação por agrotóxicos pode ocasionar diferentes alterações laboratoriais de acordo com o princípio ativo, adjuvantes, e características da exposição. Algumas substâncias contam com descrições detalhadas das possíveis alterações laboratoriais, mas não existem provas patognomônicas. As alterações específicas serão descritas nos capítulos posteriores das presentes diretrizes.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A gravidade das intoxicações é variável de acordo com o agente envolvido, as características da exposição, os fatores e suscetibilidades individuais. Existem diversos instrumentos que permitem avaliar a e classificar a gravidade das intoxicações. Alguns consideram grupos químicos específicos, outros se valem dos agrotóxicos de uma forma geral. São também de grande valia os utilizados rotineiramente para avaliar a gravidade de usuários recebidos ou internados em unidades de saúde.  
Abaixo é apresentado um instrumento que permite orientar a gravidade da intoxicação, considerando os sinais e sintomas observados em diferentes sistemas (Quadro 12). Entretanto, cabe ao clínico responsável pelo atendimento a avaliação e a determinação da gravidade da intoxicação, considerando a sua experiência e percepção das manifestações, observadas em cada caso.  
**Quadro 2 – Apresentação de sintomas observados por sistema de acordo com a gravidade da intoxicação por agrotóxicos**  
|||**Sintomas**|**de acordo com a gravidade d**|**a intoxicação**|
|---|---|---|---|---|
|**Sistema**||**Alta**|**Moderada**|**Baixa**|
|**Nervoso**|Coma||Confusão|Hiperatividade|
||Paralisia||Alucinações|Dor de cabeça|  
9  
|||Visão turva<br>Ataxia<br>Discurso lento<br>Síncope<br>Perda auditiva<br>Neuropatia localizada/<br>Parestesias|Sudorese profusa<br>Tontura<br>Tremor<br>Zumbido<br>Sonolência|
|---|---|---|---|
|**Ocular**|Úlcera corneana<br>Perfuração corneana<br>Perda davisão|Abrasão corneana<br>Queimadura de olhos<br>Alteraçõesvisuais|Lacrimejamento<br>Midríase/Miose<br>Dor/conjuntivite|
||Bradicardia: FC <40<br>adultos, <60 crianças,<br><80 neonatos|Bradicardia: FC= 40-50<br>adultos; 60-80 crianças, 80-<br>||
|**Cardiovascular**|Taquicardia: FC >180<br>adultos;> 190<br>Crianças; > 200<br>neonatos<br>|90 neonatos<br>Taquicardia: FC= 140-180<br>adultos;160-190 crianças,<br>160-200 neonatos<br>Dor no peito|Extra-sístoles<br>isoladas<br>Hipertensão|
||Parada cardíaca<br>Infarto do miocárdio<br>Choque|<br>Distúrbio de condução<br>Hipertensão/Hipotensão||
|**Respiratório**|Cianose e depressão<br>respiratória<br>Edema pulmonar<br>Parada respiratória|Anormalidades<br>radiográficas difusas<br>Alterações respiratórias<br>Broncoespasmo<br>Dispneia|Tosse<br>Irritação das vias<br>aéreas|
|**Gastrintestinal**|Hemorragia<br>Ulceração de mucosa<br>Disfagia grave|Vômito<br>Diarreia<br>Melena<br>Icterícia|Perda de apetite<br>Náusea<br>Irritação de mucosa<br>Cólicas abdominais<br>Constipação|
|**Metabólico**|Desequilíbrio ácido /<br>base (pH <7,15 ou> 7,7)<br>Desequilíbrio<br>eletrolítico severo|Desvio aniônico<br>Acidose (pH 7,15-7,30)<br>Alcalose (pH 7,60-7,69)|Febre de curta<br>duração<br>Hiperglicemia leve|
|**Renal**|Anúria<br>Insuficiência renal|Hematúria<br>Oligúria<br>Proteinúria|Poliúria|
|**Dermatológico**|Queimaduras: 2º grau><br>50% da SC total<br>Queimaduras: 3º grau<br>de> 2%daSC|Queimaduras: 2º grau<br><50% da SC<br>Queimaduras: 3º grau de<br><2%daSC|Edema<br>Eritema<br>Urticária|
|**Muscular**|Rigidez muscular e<br>rabdomiólise<br>Síndrome<br>compartimental|Fasciculações<br>Rigidez<br>Fraqueza|Fraqueza muscular<br>Dor muscular|
|**Outros**|-|-|Fadiga<br>Mal-estar|  
FC – Frequência cardíaca; SC – Superfície corpórea. Fonte: Traduzido de THUNDIYIL _et al._ , 2008.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
10

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
O tratamento inicial da intoxicação aguda por agrotóxicos inclui o suporte vital, a descontaminação do paciente, a eliminação do agente tóxico, o controle das convulsões (quando ocorrerem) e a terapia com antídotos, quando indicada<sup>14</sup> . O Suporte Vital Básico, acompanhado de uma adequada reposição hidroeletrolítica e correção de eventual desequilíbrio ácido-base, pode ser suficiente para a estabilização do paciente<sup>15</sup> .  
A abordagem inicial para o atendimento nos casos de suspeita de intoxicação por agrotóxicos está apresentada no formato de fluxograma no anexo B.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
**Realize procedimentos de suporte vital no paciente intoxicado como em qualquer paciente traumatizado. Considere as intoxicações como traumas múltiplos de origem química**<sup>16</sup> **, iniciando a seguinte sequência de avaliações**<sup>17</sup> **:**  
A: Via aérea com proteção da coluna cervical;  
B: Ventilação e respiração;  
C: Circulação;  
D: Disfunção, estado neurológico;  
E: Exposição do paciente e cuidar da hipotermia **.**  
**Uma vez estabilizado o paciente, prossiga com a avaliação secundária considerando a seguinte sequência**<sup>5,18</sup> :  
A: Controle avançado da via aérea;  
B: Revisar e modificar dispositivos de oxigenação;  
C: Estabelecer um acesso venoso e iniciar reposição hidroeletrolítica;  
D: Descontaminação;  
E: Eliminação facilitada;  
F: Terapia específica com antídotos;  
G: Ligar e consultar o Centros de Informação e Assistência Toxicológica (CIATox).  
**Deve ser avaliada a capacidade da unidade de saúde para dar continuidade ao atendimento ou considerar encaminhamento para um serviço de maior complexidade.**  
11  
**Importante utilizar medidas de proteção individual durante o processo de descontaminação do paciente, de forma a não entrar em contato direto com o agente tóxico, frente ao risco de contaminação.**  
Apesar de não terem sido encontrados estudos clínicos randomizados controlados com evidências relacionadas à eficácia do suporte vital nas intoxicações, ele é uma prática reconhecida como efetiva entre os profissionais de saúde. Os guias de prática clínica e revisões encontradas relacionadas com reanimação e abordagem inicial do paciente intoxicado corroboram que o suporte vital é a conduta inicial a ser estabelecida em qualquer tipo de intoxicação<sup>8,15,19</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se que profissionais de saúde responsáveis pelo atendimento de pacientes intoxicados acionem os Centros de Informação e Assistência Toxicológica (CIATox) de sua região para esclarecimentos sobre os primeiros socorros e tratamento adequado para cada tipo de substância tóxica (Recomendação forte a favor da intervenção - Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
**Evidências**  
Pacientes que tiveram assistência remota do Centro de Informações Toxicológicas reduziram a média do tempo de internação em 3,43 dias (IC 95%: -6,10 a -0,77) do que aqueles que não receberam nenhuma assistência do referido centro. Não houve diferença estatística na gravidade entre os pacientes com ou sem assistência do Centro de Informações Toxicológicas (p>0,5)<sup>20</sup> (Evidência  baixa - Anexo I.5.1).  
Os Centros de Informação e Assistência Toxicológica (CIATox) são estabelecimentos de saúde integrantes da Linha de Cuidado ao Trauma, da Rede de Atenção às Urgências e Emergências no âmbito do Sistema Único de Saúde – SUS<sup>21</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A triagem de um paciente intoxicado pode variar daquela de um paciente comum. Mesmo que se encontre assintomático ou com sintomatologia leve, ele deve ser classificado como prioritário para o recebimento de cuidados imediatos<sup>16</sup> .  
Considere que os agrotóxicos envolvidos nos casos de intoxicação podem se apresentar em diferentes formulações, associados com outros ingredientes ativos e com diferentes solventes, que podem modificar a toxicocinética e a toxicodinâmica do produto. Por conseguinte, esses componentes podem alterar o quadro clínico e a efetividade do tratamento de escolha.  
12  
Considere as condições da exposição, características toxicocinéticas e toxicodinâmicas do agente tóxico e a suscetibilidade individual do paciente intoxicado para estabelecer a melhor estratégia terapêutica<sup>18</sup> .  
Caso a terapia com antídotos seja indicada, ela deve ser iniciada imediatamente.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Serviços pré-hospitalares, unidades de pronto atendimento e hospitais devem ter o controle da disponibilidade e quantidade de antídotos e suprimentos para descontaminação disponíveis na rede.  
A melhoria do gerenciamento clínico e o fornecimento de antídotos tende a reduzir significativamente a mortalidade em casos de intoxicação<sup>22</sup> . Algumas diretrizes sugerem quais antídotos devem estar disponíveis nos centros de atenção hospitalar e em quais quantidades. Assim é recomendável uma gestão adequada desses produtos nas unidades que atendem emergências em saúde<sup>23,24</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Nas intoxicações agudas, as medidas de descontaminação externas e internas possuem um papel fundamental para a prevenção da absorção dos tóxicos. A efetividade e indicação dessas técnicas dependem da via de exposição, da substância envolvida e do tempo transcorrido desde a exposição 22,25.  
As medidas de descontaminação existentes, quando indicadas, deverão ser realizadas o mais breve possível<sup>25</sup> . A conduta adequada dos profissionais de saúde na sua execução influenciará significativamente na absorção do agente tóxico, interferindo na gravidade e evolução, prevenindo complicações e mortalidade.  
Apesar da busca sistemática ter sido realizada para agrotóxicos em geral, a maior parte das evidências encontradas está relacionada com intoxicações por organofosforados. Provavelmente, por serem esses compostos os mais comumente envolvidos em intoxicações por agrotóxicos. Por isso, é importante avaliar as características de cada substância para definir a melhor abordagem de descontaminação para situações específicas.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A execução das manobras de descontaminação por parte do pessoal de saúde deve ser feita utilizando equipamentos de proteção individual.  
Realize as medidas de descontaminação, no menor tempo possível – considerando o lapso temporal entre a exposição e o atendimento, tendo em conta a via de exposição e as substâncias  
13  
envolvidas, a fase da toxicocinética do agente tóxico conforme o tempo de exposição, bem como os benefícios e efeitos adversos de cada técnica.  
A lavagem gástrica e o uso do carvão ativado somente devem ser realizados se houver indicação na bula para o caso e se o profissional for capacitado e treinado para a realização do procedimento. Sendo profissional não médico, é necessário dispor de autorização médica para a sua realização.  
**Descontaminação dérmica**<sup>6</sup>  
Realize a descontaminação dérmica, especialmente nos casos com suspeita de intoxicação por agrotóxicos de reconhecida absorção por essa via. Para isso:  
- Remova as roupas contaminadas;  
- Realize a lavagem da pele com água, em temperatura ambiente, e sabão neutro, sem esquecer cabelo, unhas, região axilar, umbigo e região genital;  
- Irrigue exaustivamente com água, sem atrasar a estabilização clínica do paciente;  
- Se o agente tóxico for pó ou sólido, antes de lavar o paciente, retire o excesso de produto com pano seco ou compressa;  
- Considere cobrir todos os ferimentos antes de iniciar a lavagem corporal;  
- Evite a hipotermia.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
- Lave os olhos mantendo um fluxo contínuo de água ou soro fisiológico, com as pálpebras abertas, a partir do canto interno do olho (próximo ao nariz), em direção à lateral da face, por, no mínimo, 20 minutos.  
- Nos casos de exposição de um único olho, evite contaminar o olho não afetado, lateralizando a cabeça.  
Embora soluções isotônicas com pH neutro sejam preferíveis para a realização de irrigação ocular, não se deve perder tempo procurando por uma solução de irrigação específica caso se tenha água disponível<sup>19</sup> .  
**O manejo e descarte de materiais e objetos contaminados devem ser realizados de forma segura, de acordo com as técnicas de gerenciamento de resíduos perigosos estabelecidas para serviços de saúde.**  
14  
Não foram encontrados artigos que demonstrem a efetividade da descontaminação dérmica e ocular. Contudo, vários guias de prática clínica orientam a sua realização. Sendo assim, parece razoável a adoção dessa prática considerando a potencial absorção cutânea de vários agrotóxicos nos casos de exposição dérmica<sup>15,26,27</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Não é recomendado o uso rotineiro de doses múltiplas de carvão ativado para intoxicação por agrotóxicos (Recomendação condicional contra a intervenção -Anexo I.6). Entretanto, considere a administração de uma única dose de carvão ativado aos pacientes atendidos em até 60 min da exposição, com histórico de ingestão de grandes quantidades de agrotóxicos altamente tóxicos e que sejam adsorvidos pela substância.  (Recomendação condicional a favor da intervenção- Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Em um ensaio clínico, 1.310 pacientes, maiores de 14 anos, intoxicados com inibidores de colinesterase foram randomizados em três grupos: um de dose única de carvão ativado (440), um de doses múltiplas (429) e um sem carvão ativado (441). A história de êmese antes do atendimento, êmese forçada ou lavagem gástrica foi semelhante entre os grupos.  
Não houve redução significativa da mortalidade nos grupos avaliados, tanto no de dose única (OR 0,94, IC 95% 0,63-1,41), como no de doses múltiplas (OR 0.78, 95% IC 95% 0,51-1,19) quando comparados com o grupo que não recebeu a intervenção. Tampouco se observaram diferenças significativas quando comparados os grupos intervencionais.  
Não foi evidenciada redução significativa na necessidade de intubação, convulsões, tempo até a morte ou agravamento clínico com o uso de carvão ativado em doses múltiplas ou única. A duração média da ventilação (excluindo as mortes) foi semelhante no grupo que recebeu doses múltiplas, quando comparado com o grupo sem intervenção. Contudo, essa foi mais longa nos pacientes tratados com dose única de carvão ativado<sup>28</sup> .  
Não houve diferenças significativas quando o carvão ativado foi administrado antes ou após duas horas da ingestão. Contudo, deve-se considerar que somente um número pequeno de pacientes chegaram ao local de atendimento antes de transcorridas duas horas da exposição. O IC estreito (IC 95% 0,61 a 2,38,) sugere pouco benefício<sup>28</sup> .  
15  
(Evidência alta - Anexo I.5.1)  
Não existem evidências suficientes de que o uso de carvão ativado reduz a mortalidade em pacientes vítimas de intoxicação aguda por organofosforados, se comparada à não utilização<sup>26</sup> .  Alguns guias, não específicos para agrotóxicos, que abordam a descontaminação gástrica, recomendam o uso de uma única dose de carvão ativado para agentes tóxicos diversos nos casos de ingestão de quantidades potencialmente tóxicas, até 60 minutos após a ingestão<sup>25</sup> .  
São **contraindicações** para o uso do carvão ativado: nível de capacitação ou treinamento inadequado do executor para a realização segura do procedimento, diminuição do peristaltismo, íleo paralítico, obstrução intestinal, comprometimento ou potencial comprometimento da via aérea, hemorragia ou perfuração gastrointestinal<sup>25,29</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A utilização de carvão ativado apresenta riscos.  
Nos casos excepcionais em que os benefícios da administração do carvão ativado superem os riscos, a administração poderá ser realizada por via oral ou sonda enteral.  
Caso o paciente se apresente com alteração do estado de consciência, hemodinamicamente instável ou convulsionando, é necessária a proteção da via aérea antes da administração de carvão ativado.  
As **complicações** associadas ao uso de carvão ativado, ou à técnica, são: pneumonia aspirativa<sup>30–39</sup> ; empiema<sup>40</sup> ; pneumotórax<sup>41</sup> ; bronquiolite obliterante<sup>42</sup> , insuficiência respiratória<sup>35,43,44</sup> ; cavernas pulmonares 44; mediastinite 45; Síndrome da Angústia Respiratória Aguda - SARA 46, <mark>linfangioleiomiomatose pulmonar</mark><sup>47</sup> <mark>, granuloma,</mark><sup>48</sup> <mark>, constipação</mark><sup>34</sup> <mark>, abrasão corneana</mark><sup>32,49</sup> <mark>êmese</mark><sup>34,50–</sup> 52 <mark>e a</mark> lterações hidroeletrolíticas 32.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
**Recomendações**  
Não é recomendável a realização **rotineira** de lavagem gástrica em pacientes intoxicados por agrotóxicos considerando as evidências disponíveis. (Recomendação forte contra a intervençãoAnexo I.7)  
Realize a lavagem gástrica em casos de ingestão de dose potencialmente letal de agrotóxicos, desde que eles que não tenham sido diluídos em solventes orgânicos e corrosivos e a exposição tenha ocorrido a menos de 60 minutos antes do procedimento.  
Deve-se avaliar se os benefícios superam os possíveis danos, devendo ser priorizado o tratamento por meio de cuidados de suporte vital.  
(Recomendação condicional a favor da intervenção- Anexo I.6)  
16

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
<mark>Foi encontrada uma revisão sistemática na qual incluíram 56 estudos, dos quais 23 eram ensaios clínicos controlados e randomizados, que avaliaram a eficácia e a segurança de utilização da lavagem gástrica para intoxicações com organofosforados diversos. Desses 23, foram selecionados 6 estudos nos quais todos os pacientes receberam como procedimento de base a lavagem gástrica na sua forma múltipla ou única. Nenhum dos estudos comparou a referida intervenção com a sua não realização. No geral, nenhum dos estudos indicou se houve ou não uma remoção significativa do agente tóxico no lavado gástrico. Os benefícios do procedimento foram incertos, com a perspectiva de que talvez lavagens múltiplas contribuíssem à redução da mortalidade e de insuficiência respiratória. Assim, apesar do uso generalizado de lavagens gástricas múltiplas para o tratamento de intoxicação por organofosforados em alguns países, não há, atualmente, nenhuma evidência de alta qualidade para apoiar sua eficácia clínica</mark><sup>53</sup> (Evidência muito baixa<sup>1</sup> - Anexos I.5.1).  
Não existe evidência suficiente para recomendar ou desencorajar definitivamente o uso da lavagem gástrica como procedimento de descontaminação para pacientes intoxicados por agrotóxicos. Não existe uma prática unificada em relação a esse procedimento<sup>54</sup> e as indicações para o seu uso podem variar nos diferentes grupos de agrotóxicos.  Mais uma vez, se reforça a necessidade de contato com o CIATox e o acesso ao rótulo e à bula do produto.  
Cinco estudos clínicos randomizados, mais antigos, foram encontrados a partir de uma revisão sistemática<sup>55</sup> com evidências sobre o uso da lavagem gástrica como medida de descontaminação para outros agentes tóxicos, que não agrotóxicos. Esses estudos utilizaram diferentes tratamentos comparativos e mostraram que a recuperação de resíduos é variável. De um modo geral, eles indicaram que há uma ineficácia dos métodos de esvaziamento gástrico em diferentes desfechos, tais como a recuperação de resíduos intragástricos, na mudança significativa de tempo de permanência no departamento de emergência, no tempo médio de intubação, ou no tempo médio de permanência em uma Unidade de Terapia Intensiva<sup>52,56–58</sup> .  
Dessa forma, evidências suportando situações nas quais a lavagem gástrica se mostra benéfica para os pacientes são baseadas em extrapolações teóricas ou alguns relatos de caso, sem comparações com ausência da intervenção. Por outro lado, também faltam evidências que excluam totalmente os seus benefícios em algumas situações. Tal controvérsia é ocasionada pelo fato dos estudos disponíveis apresentarem falhas metodológicas e, com isso, terminarem por fragilizar a demonstração da efetividade do procedimento, mesmo quando iniciado em até uma hora a partir da ingestão do agente tóxico<sup>55</sup> .  
Algumas **complicações** são associadas ao procedimento: hipoxemia; pneumonia aspirativa; arritmias cardíacas; perfuração de esôfago ou de estômago; hemorragia de vias aéreas superiores; hemorragia conjuntival; falha respiratória; desequilíbrio hidroeletrolítico; laringoespasmo e pneumonia<sup>55</sup> **.**  
As seguintes **contraindicações** para a realização da lavagem gástrica são descritas na literatura<sup>55</sup> :  
- Falta de treinamento para a realização do procedimento;  
> 1 A inacessibilidade aos artigos, pelo fato de que todos eram disponibilizados somente em chinês, fez com que se optasse pela avaliação por GRADE dos resultados dos artigos primários descritos na revisão sistemática.  
17  
- Perda do reflexo de proteção da via aérea por comprometimento neurológico ou presença de crises convulsivas (contraindicação relativa; pode-se realizar a lavagem gástrica, desde que haja prévia intubação);  
- A intoxicação por agentes tóxicos que aumentam o risco e gravidade de aspiração brônquica (hidrocarbonetos, por exemplo) ou a gravidade da intoxicação;  
- Pacientes com risco elevado de perfuração gastrintestinal ou hemorragia devido a patologias, cirurgia recente ou outra condição clínica;  
- Pacientes com anormalidades craniofaciais, traumatismo craniano concomitante ou uma série de outras lesões corporais consideradas limitantes para a realização do procedimento;  
- Casos em que o paciente se recuse a cooperar ou resistir devem ser considerados como uma contraindicação relativa, uma vez que se aumenta a chance de complicações;  
- Nos casos de ingestão de produtos cáusticos, como o paraquate, pelo risco de perfuração esofágica e gástrica.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Não foram encontradas evidências diretas sobre a indução do vômito como medida de descontaminação para casos de intoxicação, nem evidências que permitam exclui-la em situações excepcionais. Assim, foi utilizada a indução do vômito com xarope de ipeca como uma evidência indireta da efetividade do vômito como medida de descontaminação.  
O xarope de ipeca ( _Psychotria ipecacuanha_ ) é um medicamento que se utilizava para evitar a absorção de tóxicos ingeridos. Por conter alcaloides eméticos, ele induz o vômito na maioria das pessoas que o consomem, exercendo tanto efeitos gastrintestinais locais, como no centro do vômito 59. Visto que o medicamento caiu em desuso, tanto no âmbito geral como nos serviços de saúde, ele não foi considerado como uma intervenção de descontaminação.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
O vômito não deve ser induzido como medida de descontaminação. Entretanto, também não é indicada a sua inibição, caso ele ocorra de forma espontânea em pacientes intoxicados. (Recomendação forte contra a intervenção - Anexo I.6)

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Estudo realizado com 592 pacientes intoxicados com diversos fármacos comparou a efetividade do esvaziamento gástrico (xarope de ipeca ou lavagem gástrica) prévio à administração de carvão ativado e a administração apenas de carvão ativado. Os resultados indicaram que ambos têm benefícios questionáveis, considerando que desfechos clínicos satisfatórios podem ser obtidos sem que nenhum procedimento de esvaziamento gástrico seja realizado de forma rotineira em pacientes intoxicados por medicamentos<sup>60</sup> (Evidência baixa - Anexo I.5.1).  
Não foram encontradas evidências, a partir de estudos clínicos, indicando que a indução do vômito melhore os desfechos nos pacientes intoxicados por agrotóxicos. Seis estudos clínicos, randomizados, encontrados em uma revisão sistemática, sugerem que a administração de xarope de ipeca é um método de esvaziamento gástrico ineficaz para recuperação dos resíduos gastrintestinais ou para alterar significativamente os desfechos clínicos dos pacientes atendidos na emergência<sup>59</sup> .  
18

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A **irrigação intestinal total** é uma medida de descontaminação que consiste na administração, por meio de sonda nasoenteral, de grandes quantidades de uma solução osmoticamente equilibrada (polietilenoglicol). O objetivo é limpar fisicamente o tóxico até a sua completa eliminação por via retal, impedindo assim a sua absorção pelo trato gastrintestinal<sup>61</sup> .  
A técnica tem sido considerada de grande valia para os casos onde há ingestão de quantidades potencialmente tóxicas de drogas de liberação prolongada ou formuladas com camada entérica. Também se mostra efetiva para substâncias não adsorvíveis por carvão ativado (como ferro, lítio ou potássio), dada a alta mortalidade dessas substâncias e a carência de outras opções para a descontaminação gastrintestinal nesses casos<sup>25,61</sup> .  
**Recomendação**  
A irrigação intestinal total não deve ser realizada no paciente intoxicado por agrotóxicos. (Recomendação forte contra a intervenção- Anexo I.6)  
**Evidências**  
Não foram encontrados estudos clínicos onde tratamento com irrigação intestinal total foi utilizado como medida de descontaminação em casos de intoxicação por agrotóxicos. Foram encontrados somente quatro estudos clínicos randomizados controlados sobre irrigação intestinal total como medida de descontaminação a partir de uma revisão sistemática<sup>61</sup> .  
São estudos _crossover_ , em voluntários, realizados com medicamentos em cápsulas de liberação sustentada ou retardada. No entanto, esses estudos apresentam evidências inconsistentes: dois estudos mostraram a efetividade do procedimento, um mostrou que o tratamento não foi efetivo, e o outro que não houve aumento da efetividade quando o tratamento foi administrado junto com carvão ativado, podendo inclusive reduzir a eficácia do carvão ativado para alguns medicamentos. Até o momento, faltam evidências de qualidade mostrando a melhora dos desfechos clínicos com a técnica de irrigação intestinal total<sup>62–65</sup> (Evidência muito baixa – Anexo I.5.1).  
Dentre as **complicações da técnica destacam-se** : náuseas; vômito; dor abdominal; distensão abdominal; angioedema; anafilaxia; laceração de Mallory-Weiss e broncoaspiração<sup>61</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Um dos desafios para o clínico responsável pelo atendimento inicial de pacientes intoxicados por agrotóxicos é determinar, de maneira precoce, se o paciente apresentará ou não complicações graves e se ele pode ser beneficiado por alguma abordagem ou técnica que facilite a eliminação do tóxico.  
As técnicas de **eliminação corpórea** avaliadas nesse capítulo foram:  
- Catárticos;  
- Diurese forçada;  
- Alcalinização urinária.  
19  
Apesar de doses múltiplas de carvão ativado ser considerada uma técnica de eliminação para algumas intoxicações, a ausência de evidência da sua efetividade na busca efetuada para as medidas de descontaminação não será considerada dentro das técnicas de eliminação.  
As técnicas de **eliminação extracorpórea consideradas** foram:  
- Diálise peritoneal;  
- Hemodiálise;  
- Hemofiltração;  
- Hemoperfusão;  
- Plasmaferese;  
- Exsanguineotransfusão.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Catárticos  
A intenção do uso de catárticos é diminuir a absorção de agentes tóxicos, acelerando a sua expulsão do trato gastrintestinal. Por isso, o uso de catárticos provavelmente beneficiaria os pacientes que ingeriram substâncias de absorção lenta<sup>66</sup> .  
Os dois tipos gerais de catárticos osmóticos utilizados em pacientes intoxicados são os sacarídeos (sorbitol) e os salinos (citrato de magnésio, sulfato de magnésio, sulfato de sódio). O primeiro muitas vezes combinado com carvão ativado para melhorar a palatabilidade deste<sup>66</sup> .  
**Recomendação**  
**Não se recomenda o uso** de catárticos como medida de eliminação para o tratamento do paciente intoxicado por agrotóxicos (Recomendação forte contra a intervenção -Anexo I.6) **.**  
**Evidências**  
Não foram encontrados ensaios clínicos randomizados controlados sobre a utilização de catárticos para o tratamento de pacientes com intoxicação aguda por agrotóxicos. Por outro lado, a partir de revisão sistemática<sup>66</sup> , três estudos clínicos randomizados com evidências sobre o uso de **catártico sozinho** como medida de eliminação corpórea de medicamentos emergiram na busca. Todos antigos, com um número muito limitado de voluntários, e que mostraram que o catártico sozinho não reduz a absorção do agente<sup>67–69</sup> (Evidência muito baixa - Anexo I.5.1).  
Não foram encontrados estudos clínicos metodologicamente aceitáveis para investigar a capacidade dos catárticos, com ou sem carvão ativado, de reduzir a biodisponibilidade de fármacos ou melhorar alguns desfechos clínicos de pacientes intoxicados.  
Na revisão sistemática supracitada<sup>66</sup> , o uso **combinado de catárticos com carvão ativado** como medida de eliminação corpórea de alguns agentes tóxicos, não agrotóxicos, apresentou resultados conflitantes, sendo todos os estudos de baixa qualidade metodológica. Cinco deles apontaram não haver diferença significativa de eficácia entre o tratamento com carvão ativado sozinho e o tratamento com carvão ativado em combinação com catárticos<sup>67,69–72</sup> , sendo que um deles mostrou não só ausência de diferença com o uso da intervenção, mas também o aumento dos efeitos colaterais quando  
20  
a combinação foi comparada com carvão ativado sozinho<sup>72</sup> . Somente dois estudos mostraram que o sorbitol 70%, melhorou a efetividade do tratamento quando em combinação com carvão ativado em relação ao carvão ativado sozinho<sup>73,74</sup> . Entretanto, um estudo observacional em pacientes intoxicados com organofosforados indicou não haver diferença na mortalidade e no desenvolvimento de insuficiência respiratória com o uso da combinação sorbitol/carvão ativado, quando comparado com a ausência da intervenção<sup>75</sup> .  
Para agrotóxicos específicos, como é o caso dos inibidores de colinesterase, a intoxicação em si causa diarreia, o que pode levar ao desequilíbrio hidroeletrolítico. Este pode ser exacerbado pela administração de catárticos, sugerindo que os riscos não compensam os benefícios potenciais dessa intervenção<sup>26</sup>  
As complicações do uso de catártico são<sup>66</sup> :  
- Dose única: cólicas abdominais, náuseas, vômitos, diaforese, hipotensão.  
- Doses múltiplas ou excessivas: desidratação; hipernatremia em pacientes que recebem catártico contendo sódio ou doses excessivas de sorbitol; hipermagnesemia em pacientes que recebem catártico contendo magnésio.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A **diurese forçada** (administração de soluções cristaloides acompanhadas de diuréticos de alça), como uma medida de eliminação corpórea, em algum momento foi recomendada para eliminar produtos de excreção renal, como é o caso do lítio, da ciclofosfamida, do etilenoglicol, de salicilatos, dentre outros. No entanto, por não ter sido comprovada a sua eficácia, sendo a ela também associados frequentemente efeitos adversos secundários (sobrecarga hídrica, edema pulmonar, hipernatremia, hipopotassemia), a diurese forçada caiu em desuso<sup>76</sup> . Ressalta-se que não foram encontrados estudos clínicos recentes sobre a utilização dessa técnica para o tratamento de pacientes com intoxicação aguda por agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A finalidade da **alcalinização urinária** é favorecer a eliminação dos agentes tóxicos de natureza ácida. Sabe-se que agentes classificados como ácidos fracos, após filtração glomerular, são mais facilmente eliminados em pH alcalino no lúmen tubular. Nesse tipo de ambiente aumenta a proporção da forma ionizada do agente, o que altera a sua lipossolubilidade, dificultando a reabsorção tubular, favorecendo a excreção. Assim a manipulação do pH urinário (valor ≥7,5) mediante a administração de bicarbonato de sódio endovenoso, em vez da diurese forçada, é o principal objetivo do tratamento. A eficácia da alcalinização urinária depende da contribuição relativa da depuração renal para a depuração corporal total da substância ativa<sup>77</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Não se recomenda o uso rotineiro de alcalinização urinária com bicarbonato como medida de eliminação no tratamento de intoxicações por agrotóxicos. Contudo, há indícios de considerá-la como uma alternativa razoável para os casos de intoxicação por agrotóxicos de natureza acídica, como é o caso dos derivados do ácido clorofenoxiacético, a partir de estudos com nível de evidência muito baixa (Recomendação condicional contra a intervenção -Anexo I.6) **Evidências**  
21  
Quatro estudos de caso<sup>78–81</sup> e uma série de casos<sup>82</sup> avaliaram a efetividade da técnica, considerando a depuração renal e a redução da concentração plasmática de herbicidas do ácido clorofenoxiacético por meio da alcalinização urinária. Em um dos estudos de caso foi reportado um declínio do tempo de meia-vida razoável (Evidência muito baixa - Anexo I.5.1).  
Alguns estudos clínicos e observacionais sugerem benefícios da utilização da alcalinização urinária para o tratamento de pacientes intoxicados com herbicidas clorofenoxiacético (como o 2,4-D). Embora seja uma medida relativamente barata e facilmente acessível, não há como estabelecer tal prática rotineiramente dada a insuficiência de evidências de melhor qualidade.  
As **complicações** mais comuns da alcalinização urinária são<sup>77,83</sup> :  
- Alcalemia;  
- Tetania alcalítica (ocasionalmente);  
- Hipocalemia;  
- Hipocalcemia (mais raramente).  
São **contraindicações** da alcalinização urinária: insuficiência renal, insuficiência cardíaca préexistente.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Não foram encontrados ensaios controlados randomizados ou diretrizes para o uso de técnicas de eliminação extracorpórea em casos de intoxicações por agrotóxicos, por serem a essas relacionadas a fatores multivariados. No entanto em algumas situações específicas é preciso considerá-las no âmbito da prática clínica. A capacidade de depuração de cada uma delas dependerá da cinética e das características físico-químicas do produto tóxico<sup>76,84</sup> .  
As principais **técnicas de eliminação extracorpórea** avaliadas foram<sup>76</sup> :  
- Hemodiálise;  
- Diálise peritoneal;  
- Hemofiltração;  
- Hemoperfusão;  
- Exsanguineotransfusão;  
- Plasmaferese.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Utilizar técnicas de eliminação extracorpórea, se disponíveis, considerando as propriedades toxicocinéticas e toxicodinâmicas próprias da substância envolvida, assim como a gravidade clínica do paciente, além das seguintes condições<sup>84</sup> :  
- Ingestão e provável absorção de uma dose altamente tóxica (potencialmente letal);  
- Concentrações plasmáticas muito altas, conforme avaliado pela experiência prévia de risco de morte e sequelas clínicas graves;  
- Deterioração clínica progressiva, apesar da terapia de suporte intensivo e manejo clínico adequado;  
22  
- <mark>Intoxicação grave com sinais vitais anormais, incluindo depressão da função do</mark> SNC, resultando em hipoventilação ou apneia, grave hipotermia e hipotensão;  
- Intoxicação com uma substância extraível que pode ser removida a uma taxa superior à eliminação endógena pelo fígado ou rim;  
- Intoxicação por agentes com efeito metabólico ou tardio, tais como metanol, etilenoglicol e paraquate;  
- Coma prolongado (graus III e IV) e ventilação assistida prolongada, por mais de 48h;  
- Insuficiência renal aguda causada por um agente (potencialmente) nefrotóxico;  
- Comprometimento do metabolismo e excreção da substância tóxica na presença de insuficiência hepática, cardíaca ou renal.  
A utilização de técnicas de eliminação extracorpórea em vítimas de intoxicação por agrotóxicos deve ser feita em combinação com as outras práticas, tais como o suporte vital, métodos de descontaminação, outros métodos de eliminação e antídotos.  
Caso alguma medida de eliminação extracorpórea seja considerada como parte do tratamento do paciente intoxicado, sugere-se contatar o CIATox para discutir as medidas de eliminação para cada intoxicação em particular.  
São esperadas complicações de acordo com a técnica utilizada<sup>76,84</sup> . Visto que existem diferentes técnicas de eliminação extracorpórea e que cada uma delas apresenta suas especificidades e sua indicação depende da efetividade teórica ou experimental para cada substância, os estudos encontrados por meio da busca sistemática ou adicionados após seleção manual não foram avaliados por GRADE. As evidências específicas para cada classe de agrotóxicos serão, portanto, tratadas em capítulos independentes.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
As estratégias de prevenção das intoxicações por agrotóxicos são distintas, considerando as diferentes circunstâncias de exposição. Sendo assim, este guia foi estruturado em três partes, considerando as diferentes exposições a esses agentes, sendo elas: as de caráter acidental, as relacionadas a tentativas de suicídio e as relacionadas ao trabalho.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
**A prevenção das intoxicações por agrotóxicos é a melhor forma de garantir a segurança e a saúde da população**<sup>85</sup> **.**  
A Organização Mundial de Saúde (OMS) sugere as seguintes intervenções preventivas para reduzir a morbimortalidade associadas à intoxicação por agrotóxicos<sup>86</sup> :  
- Rever e recomendar melhorias nas políticas regulatórias relacionadas aos agrotóxicos;  
- Implementar vigilância epidemiológica permanente e monitoramento das intoxicações por agrotóxicos em contextos clínicos, comunitários e laborais;  
23  
- Desenvolver ou fortalecer ações em conjunto com o controle social que minimizem os riscos de intoxicação intencional e não intencional por agrotóxicos;  
- Identificar na população pessoas-chave (líderes ou especialistas) e garantir que elas tenham acesso a informações atualizadas sobre o uso e prevenção da intoxicação por agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
No Brasil, entre 2007 e 2017, foram registrados um total de 29.472 casos de intoxicações acidentais por agrotóxicos no Sistema Nacional de Agravos de Notificação (Sinan). Isso foi equivalente a 27,7% do total de intoxicações notificadas no sistema. Desses, 50,3% foram em menores de 19 anos. Nessa faixa etária, a via oral foi predominante dentre as vias de exposição, correspondendo a 78,8% das notificações.  
Após busca sistemática, não foram encontradas evidências de alta qualidade metodológica que indicassem formas de prevenção apropriadas para se evitar intoxicações acidentais por agrotóxicos. Porém, algumas intervenções definidas a partir da identificação de fatores de risco para intoxicação por outras substâncias indicaram ser efetivas, podendo, assim, serem extrapoladas para a prevenção das intoxicações por agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se as seguintes medidas aos pais ou responsáveis, para a prevenção de acidentes por agrotóxicos em crianças (Recomendação forte a favor- Anexo I.6):  
- Reduzir e eliminar possíveis fontes domésticas de exposição ou contato;  
- Evitar estocar substâncias tóxicas em casa ou ao alcance das crianças;  
- Aumentar a atenção e cuidado às crianças;  
- Não armazenar agrotóxicos de maneira inapropriada, como em garrafas de refrigerante ou utensílios que chamem a atenção de crianças;  
- Não reutilizar embalagens de agrotóxicos;  
- Descartar de acordo com a indicação no rótulo do produto.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Um estudo de caso-controle mostrou que manter medicamentos ao alcance de crianças ou não os armazenar de forma segura, bem como não os guardar imediatamente após o uso, aumenta as chances das crianças entre 0 e 4 anos serem atendidas nos serviços de atenção secundária em decorrência de intoxicações. Se tais associações forem causais, a implementação de práticas de prevenção poderiam reduzir de 11 a 20% dos casos de intoxicações<sup>87</sup> . Espera-se que o armazenamento adequado de agrotóxicos também contribua para a redução do número de intoxicações. Verificou-se também que as intoxicações eram mais frequentes em domicílios com famílias monoparentais<sup>87</sup> .  
Um estudo prospectivo, multicêntrico, internacional, que analisou mais de 360 mil emergências pediátricas, concluiu que mais de 30% das intoxicações pediátricas na região da América do Sul e do Mediterrâneo Oriental envolveram cuidadores que admitiram manter a substância tóxica em um recipiente não-original. Além disso, em 44,5% (IC 95%, 38,9% - 50,0%) das intoxicações  
24  
não intencionais associadas a produtos domésticos, os cuidadores admitiram não manter esses produtos fora do alcance das crianças<sup>88</sup> .  
Ao se avaliar os casos de intoxicações pediátricas acidentais, observou-se que em 70% das intoxicações com querosene, este havia sido armazenado em garrafas de refrigerante<sup>89</sup> (Evidência moderada – Anexo I.5.2).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Aos fabricantes de agrotóxicos de uso doméstico recomenda-se considerar o uso de embalagens especiais de proteção à criança (Recomendação forte a favor da intervenção- Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
O uso de embalagens especiais de proteção a crianças em medicamentos com venda sob prescrição médica foi associado a uma redução anual da taxa de mortalidade de 1,4 mortes por milhão de crianças abaixo dos 5 anos de idade (IC95% 0,85-1,95)<sup>90</sup> . (Evidência muito baixa - Anexo I.5.2).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
No Brasil, entre 2007 e 2017, foram registrados no Sinan um total de 56.630 casos de intoxicações relacionadas a tentativas de suicídio por agrotóxicos. Essas ocorrências equivalem a 53,2% do total de intoxicações notificadas no sistema.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Dentre as intervenções preventivas sugeridas pela OMS para reduzir a morbimortalidade nos casos de intoxicação intencional por agrotóxicos<sup>86</sup> , destacam-se:  
- Atuar na melhoria do acesso aos serviços de saúde e de apoio para grupos de risco de suicídio;  
- Melhorar a gestão clínica e os cuidados de saúde mental de pessoas intoxicadas por agrotóxicos em estabelecimentos de saúde em diferentes níveis.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Reforçar o controle regulatório e a revisão de registros pela autoridade sanitária, estabelecendo um processo de avaliação periódica da toxicidade dos agrotóxicos registrados ou comercializados no Brasil, considerando evidências de segurança.  
(Recomendação forte a favor da intervenção - Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Um estudo realizado na Coreia do Sul mostrou que a taxa global de suicídio associada a agrotóxicos diminuiu entre 2003-2013, independentemente do tipo de produto, após a  
25  
implementação de diversas medidas regulatórias direcionadas ao controle desses produtos no país. Essa redução foi mais pronunciada após a proibição do paraquate<sup>91</sup> . Outro estudo, realizado no Sri Lanka, evidenciou uma diminuição em 50% na taxa de suicídios após a proibição de agrotóxicos da Classe I e restrições nos de classe II. Contudo, o número de hospitalizações relacionadas às intoxicações intencionais por agrotóxicos aumentou<sup>92–94</sup> . A proibição dos agrotóxicos mais tóxicos pode ter contribuído na redução de mortes por suicídio<sup>92–95</sup> .  
Em Bangladesh, a mortalidade por intoxicação por agrotóxicos reduziu no período após a proibição dos produtos mais tóxicos, com uma redução relativa de 37,1%, (IC 95% 35,4 a 38,8%).  A taxa de suicídio por intoxicação por agrotóxicos caiu de 6,3/100.000, antes da proibição, para 2,2/100.000. Isso corresponde a um declínio de 65,1% (IC95% de 52,0 a 76,7%)<sup>96</sup> .  
Já um estudo realizado em Taiwan demostrou que medidas de restrição de disponibilidade de agrotóxicos reduzem a taxa de suicídio, sem haver o aumento compensatório desta por outros métodos<sup>97</sup> .  
Além disso, foi visto que a proibição seletiva dos agrotóxicos de maior toxicidade, os quais eram associados ao maior número de mortes por intoxicação intencional, não causou prejuízo aos agricultores, no que tange a produtividade, no Sri Lanka<sup>98</sup> .  
(Evidência muito baixa - Anexo I.5.2).  
O Decreto 4.074/2002<sup>99</sup> , que regulamenta a lei de agrotóxicos - Lei 7.802/89<sup>100</sup> , prevê que os órgãos responsáveis pela concessão de registro devem “promover a reavaliação do registro de agrotóxicos, seus componentes e afins quando surgirem indícios da ocorrência de riscos que desaconselhem o uso de produtos registrados ou quando o País for alertado nesse sentido, por organizações internacionais responsáveis pela saúde, alimentação ou meio ambiente, das quais o Brasil seja membro integrante ou signatário de acordos”. Além disso, a referida norma, em seu art. 13, indica que os “agrotóxicos, seus componentes e afins que apresentarem indícios de redução de sua eficiência agronômica, alteração dos riscos à saúde humana ou ao meio ambiente poderão ser reavaliados a qualquer tempo e ter seus registros mantidos, alterados, suspensos ou cancelados”  
**Recomendação** Desenhar estratégias intersetoriais de prevenção para comunidades rurais, que sejam apropriadas ao contexto local e que contribuam para a redução do acesso aos agrotóxicos, tal como a proposição de centrais de armazenamento. (Recomendação condicional a favor da intervenção - Anexo I.6). **Evidência**  
Desenhar estratégias intersetoriais de prevenção para comunidades rurais, que sejam apropriadas ao contexto local e que contribuam para a redução do acesso aos agrotóxicos, tal como a proposição de centrais de armazenamento.  
26  
Estudos realizados em comunidades rurais na Índia indicaram que a construção de instalações comunitárias centralizadas de armazenagem de agrotóxicos, supervisionadas e trancadas, pode contribuir para a redução do número de casos de suicídio por essas substâncias, por dificultar o acesso<sup>101,102</sup> .  
(Evidência muito baixa - Anexo I.5.2).  
O armazenamento em centrais comunitárias podem ter desvantagens de implementação e manutenção, como: a dificuldade de acesso pelos agricultores para o uso rotineiro dos produtos pela sua localização; a necessidade da presença constante de supervisores; uso indevido dos agrotóxicos armazenados na ausência de controles e supervisão adequados; além da manutenção física do espaço, entre outros<sup>101,103</sup> .  
Quanto à armazenagem doméstica de agrotóxicos, não houve evidência de que essa estratégia repercutiria na diminuição da incidência de intoxicações de por tentativa de suicidio por esses produtos<sup>103</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
O período logo após uma tentativa de suicídio é considerado crítico, considerando o risco de uma nova investida<sup>104</sup> . Se identificada a circunstância de intoxicação por tentativa de suicídio, o paciente deve ser encaminhado à Rede de Atenção Psicossocial (RAPS).  
Para conhecer mais sobre a RAPS acesse o endereço eletrônico do Portal da Saúde: <u>http://portalms.saude.gov.br/saude-para-voce/saude-mental/prevencao-do-suicidio</u>  
Considere que existem múltiplos determinantes que influenciam no estabelecimento de estratégias efetivas de prevenção de intoxicações por agrotóxicos relacionadas ao trabalho. O princípio básico é a prevenção da exposição dos trabalhadores aos agrotóxicos, de preferência eliminando-a ou, se não for possível, mantendo-a abaixo de limites considerados aceitáveis. Dessa forma, estas não devem ser prioritariamente exercidas sobre os sujeitos expostos a esses riscos, ou seja, com enfoque no equipamento de proteção individual (EPI), mas sim sobre o ambiente e as condições de trabalho, incluindo, quando necessário, a intervenção sobre o próprio processo de produção<sup>105</sup> .  
A legislação brasileira considera como trabalhadores expostos a agrotóxicos aqueles que executam atividades econômicas<sup>2</sup> que os utilizam, direta ou indiretamente. Considera também  indivíduos que,  
*As principais atividades econômicas que utilizam agrotóxicos em seu processo de trabalho são: agricultura, pecuária, silvicultura, pesca, aquicultura, produção florestal, manejo de ecossistemas hídricos, manejo das vias  
27  
apesar de não manipularem diretamente esses agentes, circulam e desempenham suas atividades em áreas vizinhas aos locais onde se manipulam esses produtos<sup>106</sup> .  
As normas nacionais e internacionais incorporadas no arcabouço jurídico brasileiro, no que se refere à saúde e segurança no trabalho, devem ser observadas durante o manuseio e utilização de agrotóxicos. Dentre elas, destaca-se a Convenção nº 170 da Organização Internacional do Trabalho, a qual foi publicada por meio do Decreto n° 2.657/98. Ela regulamenta a segurança na utilização de produtos químicos no trabalho, que abrange toda atividade que poderia expor o trabalhador a produto químico, incluindo a produção, manipulação, armazenamento, transporte, eliminação, tratamento dos dejetos, emissão resultante do trabalho, manutenção, reparo e a limpeza de equipamento e recipientes utilizados<sup>107</sup> .  
Ressalta-se que as particularidades previstas em outras normativas, como é o caso das Normas Regulamentadoras (NR) do Ministério do Trabalho e Emprego, aprovadas pela Portaria MTE n° 3.214/1978<sup>108</sup> e 86/2005<sup>106</sup> contemplam aspectos relacionados aos cuidados com a saúde do trabalhador e a segurança da utilização de agrotóxicos em atividades laborais. Essas normas preveem particularidades relacionadas ao uso de Equipamento de Proteção Individual (NR 6), exames periódicos e parâmetros para controle biológico da exposição ocupacional aos agrotóxicos do tipo ésteres organofosforados e carbamatos (NR 7), descrição do Programa de Prevenção de Riscos Ambientais, o qual visa, por meio da antecipação dos riscos, buscar meios de evitar, dentre outros agravos, as intoxicações por agrotóxicos (NR 9), normas de saúde e segurança da utilização de agrotóxicos no trabalho rural (NR 31), dentre outras .  
A Organização das Nações Unidas para Agricultura e Alimentação<sup>109</sup> sugere ações específicas para se eliminar os riscos ocupacionais associados à exposição aos agrotóxicos, onde todos os aspectos relacionados ao “ciclo de vida” desses produtos, desde a produção até sua utilização ou eliminação, são considerados. Complementarmente, a OMS recomenda<sup>110,111</sup> :  
- Envolver os atores de toda a cadeia produtiva (fabricantes, trabalhadores das indústrias produtoras de agrotóxicos, distribuidores, armazenadores, vendedores e usuários) em ações relacionadas à prevenção da intoxicação por agrotóxicos;  
- Eliminar ou substituir os agrotóxicos de alta periculosidade;  
- Prover e assegurar o uso de Equipamentos de Proteção Individual (EPI) adequados e acessíveis;  
- Assegurar que roupas de proteção utilizadas no manuseio de agrotóxicos sejam lavadas com segurança e de uma forma regular;  
- Treinar aplicadores em relação ao uso de agrotóxicos, principalmente os de maior periculosidade;  
- Assegurar o armazenamento adequado de agrotóxicos no intuito de impedir o acesso desses ao público, no geral, e principalmente crianças;  
- Desenvolver planos de manejo de vetores que adotem medidas sanitárias de controle, de modo a eliminar ou minimizar o uso de produtos químicos.  
férreas, madeireira e as atividades desinsetizadoras privadas e de saúde pública. As atividades relacionadas à produção, transporte, armazenamento e comercialização de agrotóxicos, a reciclagem de embalagem de agrotóxicos, as atividades extensionistas rurais, a jardinagem, entre outros (107).  
28  
Uma alternativa para a redução dos riscos da exposição aos agrotóxicos e seus impactos à saúde é desenvolver sistemas agroalimentares sustentáveis, como a agroecologia e produção orgânica e demais estratégias que fazem parte do Plano Nacional de Agroecologia e Produção Orgânica (PLANAPO)<sup>112</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se o uso de Equipamentos de Proteção Individual (EPI), de acordo com as normas vigentes, para a redução da incidência de intoxicação ocupacional por agrotóxicos (Recomendação condicional a favor da intervenção - Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Estudo realizado em Santa Catarina indicou que agricultores que afirmaram utilizar EPI durante o manuseio e uso de agrotóxicos apresentaram 70% menos sintomas de intoxicação, quando comparados aos que não o utilizavam (RP=0,29; IC95%= 0,05 – 1,70; p=0,049)<sup>113</sup> .  
Dados relacionados à intoxicação por agrotóxicos coletados em 152 manipuladores foram avaliados por meio de um estudo realizado em Teresópolis (RJ). Foi observado que indivíduos que não usaram nenhum tipo de EPI tiveram 19 vezes mais chance de se intoxicar em relação aos indivíduos que usam ao menos um tipo de proteção. Quando o motivo para o não uso do EPI foi o calor, essa chance aumentou em 53 vezes. O estudo também indicou que a utilização de óculos de proteção, de macacão, de máscara e do uso de roupa de aplicação somente um dia, reduz as chances de intoxicação em, respectivamente, 56%, 14%, 83% e 78%<sup>114</sup> .  
Um estudo descritivo envolvendo 282 agricultores da fruticultura em um município do Rio Grande do Sul, indicou que a ocorrência de casos possiveis de intoxicações agudas, segundo a ferramenta de classificação proposta pela OMS, foi maior entre trabalhadores que não usavam máscaras (p=0,02) e proteção na cabeça (p=0,07). A incidência de intoxicação no ultimo ano, referida pelos trabalhadores, foi menor entre aqueles que informaram usar “sempre” máscaras, proteção de cabeça e roupas de proteção (p<0,01)<sup>115</sup> .  
(Evidência muito baixa - Anexo I.5.2).  
Informações para o uso do EPI encontram-se descritas nos rótulos e bulas de todos os produtos comercializados no Brasil.  
Outras estratégias adicionais, além o uso de EPI, também podem auxiliar na proteção do agricultor. Por exemplo, o uso de trator em cabine fechada, como forma de proteção coletiva, pode auxiliar na redução da exposição do trabalhador<sup>116,117</sup> .  
29

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Por ter uma efetividade limitada em diversas situações cotidianas **, o uso de EPI não deve ser o foco único das estratégias de redução dos riscos de exposição** . A sua adaptação ao contexto do trabalho real, social, econômico, geográfico e cultural da agricultura brasileira deve também ser ponderada.  
Além disso, para reduzir os riscos ocupacionais relacionados aos agrotóxicos, deve ser ajustada a organização do ambiente e do processo de trabalho, considerando que os trabalhadores são expostos a esses produtos em diversas etapas, desde a sua fabricação ao descarte.  
O EPI tem demonstrado uma efetividade limitada, devido a fatores descritos em alguns estudos. A adesão ao uso é um desses fatores, que está diretamente relacionado ao desconforto. Na percepção dos trabalhadores rurais brasileiros, ele aumenta a sensação de calor, além de dificultar a locomoção 118,119.  
Também são observados problemas de adesão ao uso de EPI que podem estar relacionados à falta de treinamento e ao desconhecimento do risco à saúde. A maioria dos trabalhadores rurais apresenta um baixo nível de conhecimento em relação aos riscos associados ao uso de agrotóxicos<sup>120,121</sup> . Além disso, a não percepção da necessidade do uso e a indisponibilidade dos equipamentos de proteção que sejam mais apropriados, além de outros fatores, contribuem para que os trabalhadores não os utilizem<sup>122</sup> .  
Um estudo realizado no Brasil, com vestimentas certificadas e utilizadas por agentes de controle de endemia, demonstrou não haver retenção de malationa, pela vestimenta, durante a aplicação do produto, mesmo essa sendo nova<sup>123</sup> . Outro estudo, realizado com 38 trabalhadores rurais na França, encontrou que a metade deles excedeu a ingestão diária aceitável, considerando a absorção dérmica como uma extrapolação da ingestão, apesar do uso de luvas. Isso foi mais frequente quando realizavam o preparo da calda<sup>117</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se disponibilizar no ambiente de trabalho um local onde o trabalhador possa realizar  
a higiene pessoal após o contato ou utilização de agrotóxicos para a redução na incidência de intoxicação ocupacional.  
(Recomendação forte a favor da intervenção - Anexo I.6).  
**Evidências**  
Aspectos higiênicos são importantes preditores da intoxicação, pois trabalhadores rurais que não trocam ou lavam a roupa, após a última aplicação de agrotóxico, têm riscos de intoxicação aumentados em 126 vezes quando comparados aos que adotam essas práticas<sup>114</sup> .  
(Evidência muito baixa - Anexo I.5.2).  
Associações significativas entre práticas de higiene e uso de EPI foram observadas entre trabalhadores rurais que realizam práticas de segurança em relação aos agrotóxicos e condições de  
30  
trabalho. A existência de um lugar para tomar banho ou se lavar após o trabalho e a disponibilidade de sabão para lavagem das mãos favorece a adoção de práticas de higiene, bem como o uso de EPI 110.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Compete ao empregador fornecer aos empregados, gratuitamente, EPI adequado ao risco, em perfeito estado de conservação e funcionamento nas seguintes circunstâncias: sempre que as medidas de ordem geral não ofereçam completa proteção contra os riscos de acidentes do trabalho ou de doenças profissionais e do trabalho; enquanto as medidas de proteção coletiva estiverem sendo implantadas; para atender a situações de emergência (NR6)<sup>108</sup> .  
Adicionalmente, o empregador rural ou equiparado deve adotar, no mínimo, as seguintes medidas (NR 31)<sup>106</sup> :  
- Fornecer EPI e vestimentas adequadas aos riscos e que não propiciem desconforto térmico prejudicial ao trabalhador, bem como vestimentas de trabalho em perfeitas condições de uso, devidamente higienizados, responsabilizando-se pela descontaminação dos mesmos ao final de cada jornada de trabalho, e substituindo-os sempre que necessário;  
- Orientar quanto ao uso correto dos dispositivos de proteção;  
- Disponibilizar um local adequado para a guarda da roupa de uso pessoal;  
- Fornecer água, sabão e toalhas para higiene pessoal;  
- Garantir que nenhum dispositivo de proteção ou vestimenta contaminada seja levado para fora do ambiente de trabalho;  
- Garantir que nenhum dispositivo ou vestimenta de proteção seja reutilizado antes da devida descontaminação;  
- Vedar o uso de roupas pessoais quando da aplicação de agrotóxicos;  
- Vedar a manipulação de quaisquer agrotóxicos, adjuvantes e produtos afins por menores de dezoito anos, maiores de sessenta anos e por gestantes;  
- Afastar a gestante das atividades com exposição direta ou indireta a agrotóxicos imediatamente após ser informado da gestação;  
- Vedar o trabalho em áreas recém-tratadas, antes do término do intervalo de reentrada estabelecido nos rótulos dos produtos, salvo com o uso de equipamento de proteção recomendado;  
- Vedar a entrada e permanência de qualquer pessoa na área a ser tratada durante a pulverização aérea;  
- Fornecer instruções suficientes aos que manipulam agrotóxicos, adjuvantes e afins, e aos que desenvolvam qualquer atividade em áreas onde possa haver exposição direta ou indireta a esses produtos, garantindo os requisitos de segurança previstos.  
Também é recomendável sempre adotar medidas de proteção contra contaminação dos trabalhadores que manipulam essas vestimentas e equipamentos.  
O trabalhador que apresentar sintomas de intoxicação deve ser imediatamente afastado das atividades e transportado para atendimento médico, juntamente com as informações contidas nos rótulos e bulas dos agrotóxicos aos quais tenha sido exposto (NR 31)<sup>106</sup> .  
31

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se a lavagem dos EPI no local de trabalho com máquinas de lavar roupas exclusivas para essa finalidade, evitando a exposição decorrente da lavagem manual.  
(Recomendação forte a favor da intervenção - Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
A lavagem de EPI em tanque de uso doméstico aumenta a chance de intoxicação em 56 vezes em relação aos indivíduos que adotam outras práticas mecânicas de lavagem<sup>114</sup> . (Evidência muito baixa - Anexo I.5.2).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se aos profissionais de saúde e empregadores a realização de programas de educação continuada por meio de capacitações, treinamento e assistência técnica que (Recomendação forte a favor da intervenção -Anexo I.6):  
- Considerem e valorizem a construção coletiva, práticas e saberes do trabalhador;  
- Auxiliem a compreensão do real potencial da toxicidade do produto;  
- Promovam o cuidado e minimizem os perigos da exposição ocupacional;  
- Orientem pessoas a compreender e interpretar os símbolos utilizados em rótulos e embalagens de agrotóxicos;  
- Considerem as questões de gênero e faixas etárias.  
- Evidências  
Intervenções educacionais em relação à leitura do rótulo, efeitos adversos à saúde, estocagem em local seguro e uso de EPI para o manuseio de agrotóxico entre agricultores resultaram numa melhor pontuação geral no questionário de conhecimento, atitude e prática (CAP). Entretanto, houve deficiência na retenção do conhecimento e não foi verificada uma melhoria significativa em relação às práticas adotadas em relação aos agrotóxicos<sup>124</sup> .  
A intervenção educacional, por meio de uma sessão única de treinamento, apesar de contribuir para a adesão do uso de equipamentos de aplicação e uma redução do número de agrotóxicos utilizados, não foi considerada efetiva para aumentar a adesão ao uso de EPI e nem tampouco para uma redução da exposição dérmica<sup>125</sup> .  
A percepção sobre a adoção de medidas de segurança em relação ao uso de agrotóxicos é maior em agricultores com um maior nível de educação formal, bem como entre os que tiveram experiências prévias de intoxicação com esses produtos. A preferência de temas para treinamentos se mostrou variável de acordo com o grupo etário<sup>126</sup> .  
32  
Outro estudo com trabalhadoras agrícolas revelou que o conhecimento que essas apresentavam em relação à segurança do manuseio de agrotóxicos era resultante de treinamentos e outras formas de aprendizado. Contudo, esse grupo de trabalhadoras indicou a necessidade de mais capacitação, pois não se consideravam seguras ao manusear esse tipo de produto, principalmente se estivessem grávidas. Elas indicaram que os treinamentos poderiam ser oferecidos pelo empregador, pelos seus supervisores e por profissionais da área de saúde<sup>127</sup> . (Evidência muito baixa - Anexo I.5.2).  
**Estratégias para redução do risco de exposição a agrotóxicos por consumo de alimentos**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Segundo a Lei Orgânica de Segurança Alimentar e Nutricional - LOSAN, a Segurança Alimentar e Nutricional (SAN) compreende o direito de todos ao acesso regular e permanente a alimentos de qualidade, em quantidade suficiente, sem comprometer o acesso a outras necessidades essenciais. Tem-se como pressuposto a adoção de práticas alimentares promotoras de saúde, que respeitem a diversidade cultural e que sejam ambiental, cultural, econômica e socialmente sustentáveis<sup>128</sup> .  
Nesse sentido, para ter uma alimentação adequada e saudável não basta atentar somente para as características nutricionais dos alimentos.  É preciso considerar sua procedência, a forma de produção, sendo recomendável o consumo de alimentos orgânicos e de base agroecológica. O estímulo ao cultivo doméstico de alimentos orgânicos também é uma prática a ser estimulada. Uma horta, mesmo que pequena, plantada nos quintais das casas ou em vasos pendurados em muros ou apoiados em lajes ou sacadas, oferece, a baixo custo, quantidade razoável de alimentos _in natura_ e sem agrotóxicos<sup>129</sup> .  
Uma das vantagens da produção de alimentos orgânicos é o uso restrito de agrotóxicos sintéticos. Isso contribui para que a quantidade de seus resíduos nos alimentos seja reduzida, e, portanto, uma menor exposição de consumidores a esses produtos. Além disso, a produção de alimentos orgânicos reduz a exposição ocupacional de trabalhadores agrícolas aos agrotóxicos e a exposição à deriva das populações rurais<sup>130</sup> .  
De acordo com relatório divulgado pelo Serviço de Pesquisa do Parlamento Europeu, a agricultura orgânica prevê um baixo uso de agrotóxicos, sendo os riscos potenciais para a saúde humana relacionados a tais produtos amplamente evitados. Em geral, o consumo de alimentos orgânicos diminui substancialmente a exposição ao agrotóxico alimentar dos consumidores, bem como os riscos agudos e crônicos dessa exposição<sup>131</sup> .  
Caso o agricultor opte pelo uso de agrotóxicos na produção de alimentos, recomenda-se, de acordo com a Lei 7.802/89<sup>100</sup> :  
33  
- Utilizar apenas produtos recomendados para aquela cultura, de acordo com o receituário agronômico;  
- Aplicar os produtos apenas nas doses recomendadas;  
- Somente realizar a colheita após cumprido o intervalo de segurança (tempo de carência entre a aplicação e a colheita) de acordo com o rótulo e bula do produto.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Recomenda-se a lavagem dos alimentos para auxiliar na redução de resíduos de agrotóxicos de contato em alimentos.  
(Recomendação condicional a favor da intervenção - Anexo I.6).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Foram encontrados diversos estudos que indicaram a redução de resíduos de agrotóxicos em alimentos quando lavados com água corrente, ácido acético (vinagre), limoneno, detergente e suas combinações. Essa redução encontrada nesses estudos foi entre 14 e 97% e varia de acordo com o agrotóxico<sup>132–141</sup> .  
(Evidência muito baixa - Anexo I.5.2).  
Destaca-se que a lavagem dos alimentos provavelmente reduz apenas os resíduos de agrotóxicos de contato (que ficam na parte externa dos alimentos) e não dos agrotóxicos sistêmicos (que penetram nos alimentos).  
Os estudos encontrados demostraram que cozinhar ou assar os alimentos reduz a concentração de resíduos de agrotóxicos, podendo ser mais eficaz que apenas lavá-los<sup>132,135,140–145</sup> . Porém, há escassez de estudos que avaliem a toxicidade dos subprodutos dos agrotóxicos após a cocção, sendo esse um aspecto importante a ser investigado.  
Foram encontrados outros processos ou métodos que vêm sendo utilizados para a remoção de resíduos de agrotóxicos em alimentos, como a ozonização<sup>135,146</sup> , uso de ultrassom<sup>147</sup> , radiação gama 148, processamento microbiológico lácteo 149, pulsos elétricos 150 e plasma não térmico in-package (NTP)<sup>151</sup> . Contudo, dadas as características específicas de cada método, é difícil a popularização do seu uso.  
É também necessária especial atenção aos subprodutos formados pela aplicação dessas técnicas, uma vez que eles podem ser até mais tóxicos do que o próprio agrotóxico original<sup>147</sup> .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
Notifique todos os casos suspeitos de intoxicação exógena no Sistema de Informação de Agravos de Notificação (Sinan). Ela é **obrigatória** a todos os profissionais de saúde (anexo C e D), e é um fator determinante para medidas de vigilância.  
34  
Existe também a possibilidade da comunicação pelos cidadãos ou estabelecimentos educacionais por meio do Disque Notifica: 0800-644-6645 ou notifica@saude.gov.br.  
A Portaria GM/MS de Consolidação nº 4 de 2017, anexo V, capítulo I (Origem: PRT MS/GM 204/2016)<sup>152</sup> , inclui a intoxicação exógena por agrotóxicos como um agravo de notificação compulsória semanal, e determina em seu artigo 3º como “ **obrigatória para os médicos, outros profissionais de saúde ou responsáveis pelos serviços públicos e privados de saúde, que prestam assistência ao paciente** ”. O instrumento utilizado para que se proceda a referida notificação no Sistema de Informação de Agravos de Notificação (Sinan) é a Ficha de Investigação de Intoxicação Exógena (Anexo D). Nela, todos os campos devem ser criteriosamente preenchidos, inclusive quando a informação for negativa ou incompleta.  
Para esclarecimento sobre o preenchimento dos campos da ficha consultar o Manual do usuário Sinan - Instruções para preenchimento da ficha de intoxicação exógena, disponível em: <u>http://pisast.inf.br/assuntos-relacionados/temas/agrotoxicos/material-de-apoio</u>  
Em caso de ser uma intoxicação exógena por agrotóxicos **relacionada ao trabalho** , de acordo com a Lei 8.213/1991; Portaria GM/MS de Consolidação nº 2 de 2017, anexo XV (origem: PRT MS 1.823/2012); Portaria GM/MS de Consolidação nº 5 de 2017, art. 422 e Anexo LXXIX (origem: PRT MS 3.120/1998)<sup>153</sup> ; Lei 6.015/1973; Portaria GM/MS de Consolidação nº 4 de 2017, anexo V (Origem: PRT MS/GM 204/2016)<sup>152</sup> ; o médico ou profissional de saúde deve:  
- Emitir a Comunicação de Acidente de Trabalho (CAT) para os trabalhadores que contribuem com o INSS e os segurados especiais (a exemplo de agricultores e pescadores);  
- • Referenciar o trabalhador, para a atenção básica, caso o primeiro atendimento seja realizado em serviços de média ou alta complexidade com o objetivo de dar continuidade ao cuidado;  
- • Acionar o Centros de Referência em Saúde do Trabalhador (Cerest) ou equipe de vigilância em saúde para realizar vigilância de ambiente e processo de trabalho referente ao caso, com o objetivo de intervir, minimizando ou eliminando a exposição de trabalhadores aos agrotóxicos;  
- Notificar o caso na ficha de investigação de **Intoxicação Exógena do Sinan** e sempre preencher os campos: 32-Ocupação, 36-Atividade Econômica (CNAE), 34-Local de ocorrência da exposição como “ambiente de trabalho”, 56-A exposição/contaminação foi decorrente do trabalho/ ocupação? Como “Sim”;  
- Em caso de **óbito** , incluindo suicídio, por intoxicação por agrotóxicos relacionada ao trabalho, preencher um dos campos de causa do óbito da Declaração de Óbito (DO) com o CID-10, Y96-Circunstâncias relativas às condições de trabalho. E ainda assinalar o campo acidente de trabalho como “sim” na parte de causas externas da DO.  
Nos casos de intoxicações **relacionadas a circunstâncias de violência ou tentativa de suicídio** deve-se realizar também a notificação no Sinan, na ficha de Violência Interpessoal e Autoprovocada, de forma **complementar a ficha de Intoxicações Exógenas** . A tentativa de suicídio deve ser notificada compulsoriamente em até 24 horas pelo profissional de saúde ou responsável pelo serviço assistencial que prestar o primeiro atendimento à pessoa. É preciso articular a notificação do caso à vigilância epidemiológica do município imediatamente após o  
35  
seu conhecimento, seja por meio da ficha de notificação, e-mail ou telefone (com posterior envio da ficha), e encaminhar o indivíduo para a Rede de Atenção Psicossocial - RAPS (Portaria GM/MS de Consolidação nº 4 de 2017, anexo V, capítulo I (Origem: PRT MS/GM 204/2016)) 152.  
Caso necessário, consulte o Instrutivo VIVA – Notificação de Violência Interpessoal e Autoprovocada, disponível em: <u>http://bvsms.saude.gov.br/bvs/publicacoes/viva_instrutivo_violencia_interpessoal_autoprovoca da_2ed.pdf</u>  
Para um maior conhecimento da Vigilância de Populações Expostas a Agrotóxicos no Brasil, recomenda-se a leitura do documento “Diretrizes Nacionais para a Vigilância em Saúde de Populações Expostas a Agrotóxicos”<sup>154</sup> , do Ministério da Saúde, disponível em: <u>http://portalsaude.saude.gov.br//images/pdf/2016/fevereiro/24/Diretrizes-VSPEA.pdf</u>

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Diagnóstico nas Intoxicações Agudas por Agrotóxicos** -->
1. Brasil. Ministério da Saúde. Guia de Vigilância em Saúde [Internet]. 2 ed. Cavalcante AL, editor. Vol. Único. Brasília: Secretaria de Vigilância em Saúde. Coordenação-Geral de Desenvolvimento da Epidemiologia em Serviços; 2017. 72 p. Available from: http://portalarquivos.saude.gov.br/images/pdf/2017/outubro/06/Volume-Unico-2017.pdf  
2. Brasil. Ministério da Saúde. Relatório Nacional de Vigilância em Saúde de Populações Expostas a Agrotóxicos-volume 1 t. 1 [Internet]. Brasilia; 2016. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/agrotoxicos_otica_sistema_unico_saude_v1_t.1.p df  
3. Brasil. Agência Nacional de Vigilância Sanitária. Programa de Análise de Resíduos de Agrotóxicos em Alimentos (PARA) Relatório das Análises de Amostras Monitoradas no Período de 2013 a 2015 [Internet]. Brasília; 2016. Available from: http://portal.anvisa.gov.br/documents/219201/2782895/Relatório+PARA/a6975824-74d64b8e-acc3-bf6fdf03cad0?version=1.0  
4. Roberts JR, Reigart JR. Recognition and Management of Nonrelaxing [Internet]. United States Environmental Protection Agency. 2013. Available from: http://dx.doi.org/10.1016/j.mayocp.2011.09.004  
5. Erickson TB, Thompson TM, Lu JJ. The Approach to the Patient with an Unknown Overdose. Emerg Med Clin North Am. 2007;25(2):249–81.  
6. Brasil. Ministério da Saúde. Protocolos de Suporte Avançado de Vida. 2<sup>a</sup> . Urgência. P de I para o S 192-S de AM de, editor. Brasilia: Secretaria de Atenção à Saúde; 2016.  
7. Brasil. (Associação Brasileira de Normas Técnicas/NBR). Produtos químicos — Informações sobre segurança, saúde e meio ambiente Parte 4: Ficha de informações de segurança de produtos químicos (FISPQ). Rio de Janeiro; 2009.  
8. Mexico. CENETEC. Prevención primaria, diagnóstico precoz y tratamiento oportuno de la  
36  
intoxicación aguda por agroquímicos en el primer nivel de atención. Salud CN de ET en, editor. DF: CENETEC; 2008. 1-50 p.  
9. Roberts DM, Aaron CK. Management of acute organophosphorus pesticide poisoning. Bmj. 2007;334(7594):629–34.  
10. Van Hoving DJ, Veale DJH, Muller GF. Clinical Review: Emergency management of acute poisoning. African J Emerg Med. 2011;1(2):69–78.  
11. Brasil. Ministério da Saúde. Protocolos de Suporte Básico de Vida [Internet]. Brasília; 2016. Available from: CDD 616.0252  
12. dos Santos MAT, Reyes FGR, Areas MA. Piretroides- Uma Visão geral. Alim Nutr. 2007;18(3):339–49.  
13. Thundiyil JG, Stober J, Besbelli N, Pronczuk J. Acute pesticide poisoning: A proposed classification tool. Bull World Health Organ. 2008;86(3):205–9.  
14. Lindell AR of C, Bernier GM( U of TMB. National Pesticide Practice Skills Guidelines for Medical & Nursing. The National Environmental Educatiion & Training Fundation, editor. Washington, DC; 2003.  
15. Truhlář A, Deakin CD, Soar J, Khalifa GEA, Alfonzo A, Bierens JJLM, et al. European Resuscitation Council Guidelines for Resuscitation 2015. Section 4. Cardiac arrest in special circumstances. Resuscitation. 2015;95:148–201.  
16. Mexico. CENETEC. Prevención, diagnóstico y tratamiento de intoxicaciones agudas em pediatría en el primer, segundo y tercer nivel de atención. Salud CN de ET en, editor. DF: CENETEC; 2014. 60 p.  
17. Colégio Americano de Cirurgiões - Comitê de trauma. Suporte Avançado de Vida no Trauma - Manual do Curso de Alunos. 9<sup>a</sup> . 2012. 365 p.  
18. Mexico. CENETEC. Tratamiento general de las intoxicaciones y envenenamientos en niños y adultos. Salud CN de ET en, editor. DF: CENETEC; 2014. 51 p.  
19. Thompson TM, Theobald J, Lu J, Erickson TB. The general approach to the poisoned patient. Disease-a-Month. 2014;60(11):509–24.  
20. Galvão TF, Silva MT, Silva CD, Barotto AM, Gavioli IL, Bucaretchi F, et al. Impact of a poison control center on the length of hospital stay of poisoned patients: retrospective cohort. Sao Paulo Med J. 2011;129(1):23–9.  
21. Brasil. Ministério da Saúde. Portaria n° 1.678/2015. Brasilia: DOU 06/10/2015; 2015.  
22. Eddleston M, Buckley NA, Eyer P, Dawson AH. Management of acute organophosphorus pesticide poisoning. Lancet. 2008;371(9612):597–607.  
23. Aguilar-Salmerón R, Martínez-Sánchez L, Broto-Sumalla A, Fernández de Gamarra-Martínez E, García-Pelaéz M, Nogué-Xarau S. Recomendaciones de disponibilidad y utilización de antídotos en los hospitales según su nivel de complejidad asistencial. Emergencias. 2016;28(1):45–54.  
24. Fernandes LCR, Galvão TF, Ricardi AST, De Capitani EM, Hyslop S, Bucaretchi F. Antidote availability in the municipality of Campinas, São Paulo, Brazil. Sao Paulo Med J. 2017;135(1):15–22.  
25. Bouchard. Guidelines Update. Adv Skin Wound Care. 2010;18(4):221–3.  
26. Blain PG. Organophosphorus poisoning ( acute ) Search date April 2010 Organophosphorus poisoning ( acute ). 2011;(April 2010):1–17.  
27. Thompson TM, Theobald J, Lu J, Erickson TB. The general approach to the poisoned patient. Disease-a-Month. 2014;60(11):509–24.  
37  
28. Eddleston M, Juszczak E, Buckley NA, Senarathna L, Mohamed F, Dissanayake W, et al. Multiple-dose activated charcoal in acute self-poisoning: a randomised controlled trial. Lancet (London, England). 2008 Feb;371(9612):579–87.  
29. Chyka PA, Seger D, Krenzelok EP, Vale JA, American Academy of Clinical Toxicology, European Association of Poisons Centres and Clinical Toxicologists. Position paper: Singledose activated charcoal. Clin Toxicol (Phila). 2005;43(2):61–87.  
30. Amigó M, Nogué S, Mir Ò̀. Carb??n activado en 575 casos de intoxicaciones agudas. Seguridad y factores asociados a las reacciones adversas. Med Clin (Barc). 2010;135(6):243– 9.  
31. Bosse GM, Barefoot JA, Pfeifer MP, Rodgers GC. Comparison of three methods of gut decontamination in tricyclic antidepressant overdose. J Emerg Med. 1995;13(2):203–9.  
32. Dorrington CL, Johnson DW, Brant R, Berlin R, Daya M, Purssell R, et al. The frequency of complications associated with the use of multiple-dose activated charcoal. Ann Emerg Med. 2003;41(3):370–7.  
33. Bairral B. Activated charcoal bronchial aspiration. J Bras Pneumol. 2012;43(6):236–8. 34. Osterhoudt KC, Alpern ER, Durbin D, Nadel F, Henretig FM. Activated charcoal administration in a pediatric emergency department. Pediatr Emerg Care. 2004;20(8):493–8.  
35. Golej J, Boigner H, Burda G, Hermon M, Trittenwein G. Severe respiratory failure following charcoal application in a toddler. Resuscitation. 2001;49(3):315–8.  
36. Menzies D. Fatal pulmonary aspiration of oral activated charcoal. 1988;297:459–60. 37. Harris CR, Filandrinos D. Accidental administration of activated charcoal into the lung: aspiration by proxy. Ann Emerg Med. 1993 Sep;22(9):1470–3.  
38. Pollack MM, Dunbar BS, Holbrook PR, Fields AI. Aspiration of activated charcoal and gastric contents. Ann Emerg Med. 1981 Oct;10(10):528–9.  
39. Silberman H, Davis SM, Lee A. Activated charcoal aspiration. N C Med J. 1990 Feb;51(2):79–80.  
40. Justiniani FR, Hippalgaonkar R, Martinez LO. Charcoal-containing empyema complicating treatment for overdose. Chest. 1985 Mar;87(3):404–5.  
41. Thomas B, Cummin D, Falcone RE. Accidental Pneumothorax from a Nasogastric Tube. N Engl J Med. 1996 Oct;335(17):1325–6.  
42. Elliott CG, Colby T V, Kelly TM, Hicks HG. Charcoal lung. Bronchiolitis obliterans after aspiration of activated charcoal. Chest. 1989 Sep;96(3):672–4.  
43. Gutiérrez GC, Bossert T, Espinosa JQ. Guía Metodológica para la elaboración de Guías de Atención Integral en el Sistema General de Seguridad Social en Salud Colombiano. 2010. 2013.  
44. Francis RCE, Schefold JC, Bercker S, Temmesfeld-Wollbrück B, Weichert W, Spies CD, et al. Acute respiratory failure after aspiration of activated charcoal with recurrent deposition and release from an intrapulmonary cavern. Intensive Care Med. 2009 Feb;35(2):360–3.  
45. Caravati EM, Knight HH, Linscott MS, Stringham JC. Esophageal laceration and charcoal mediastinum complicating gastric lavage. J Emerg Med. 2001;20(3):273–6.  
46. De Weerdt A, Snoeckx A, Germonpré P, Jorens PG. Rapid-onset adult respiratory distress syndrome after activated charcoal aspiration. A pitch-black tale of a potential to kill. Am J Respir Crit Care Med. 2015 Feb;191(3):344–5.  
47. Huber M, Pohl W, Reinisch G, Attems J, Pescosta S, Lintner F. Lung disease 35 years after aspiration of activated charcoal in combination with pulmonary lymphangioleiomyomatosis: A histological and clinicopathological study with scanning electron microscopic evaluation  
38  
- and element analysis. Virchows Arch. 2006;449(2):225–9.  
- 48. Seder DB, Christman RA, Quinn MO, Knauft ME. Case Reports A 45-Year-Old Man With a Lung Mass and History of Charcoal Aspiration. 2006;1251–4.  
49. McKinney PE, Phillips S, Gomez HF, Brent J. Corneal abrasions secondary to activated charcoal. Am J Emerg Med. 1993 Sep;11(5):562.  
50. Boyd R, Hanson J. Prospective single blinded randomised controlled trial of two orally administered activated charcoal preparations. J Accid Emerg Med. 1999;16(1):24–5.  
51. Crockett R, Krishel SJ, Manoguerra A, Williams SR, Clark RF. Prehospital use of activated charcoal: A pilot study. J Emerg Med. 1996;14(3):335–8.  
52. Merigian. Prospective evaluation of gastric emptying in the self-poisoned patients. 1990. 53. Li Y, Tse ML, Gawarammana I, Buckley N, Eddleston M. Systematic review of controlled clinical trials of gastric lavage in acute organophosphorus pesticide poisoning. Clin Toxicol Philadelphia Pa. 2009;47(3):179–92.  
54. Benson BE, Hoppu K, Troutman WG, Bedry R, Erdman A, Höjer J, et al. Position paper update: gastric lavage for gastrointestinal decontamination. Clin Toxicol. 2013 Mar;51(3):140–6.  
55. Benson BE, Hoppu K, Troutman WG, Bedry R, Erdman A, Jer JHÖ, et al. Position paper update: gastric lavage for gastrointestinal decontamination. 2013;  
56. Saetta JP, Quinton DN. Residual gastric content after gastric lavage and ipecacuanha-induced emesis in self-poisoned patients: an endoscopic study. J R Soc Med. 1991;84(1):35–8.  
57. Saetta JP, March S, Gaunt ME, Quinton DN. Gastric emptying procedures in the self-poisoned patient: are we forcing gastric content beyond the pylorus? J R Soc Med. 1991;84(5):274–6.  
58. Underhill TJ, Greene MK, Dove AF. A comparison of the efficacy of gastric lavage, ipecacuanha and activated charcoal in the emergency management of paracetamol overdose. Arch Emerg Med. 1990;7(3):148–54.  
59. Höjer J, Troutman WG, Hoppu K, Erdman A, Benson BE, Mégarbane B, et al. Position paper update: ipecac syrup for gastrointestinal decontamination. Clin Toxicol. 2013;51(3):134–9.  
60. Kulig K, Bar-or D, Cantrill S V, Rosen P, Rumack BH, Hospital DG, et al. Management of acutely poisoned patients without gastric emptying. 1985;(June):562–7.  
61. Thanacoody R, Caravati EM, Troutman B, Höjer J, Benson B, Hoppu K, et al. Position paper update: Whole bowel irrigation for gastrointestinal decontamination of overdose patients. Clin Toxicol. 2015;53(1):5–12.  
62. Smith SW, Ling LJ, Halstenson CE. Whole-bowel irrigation as a treatment for acute lithium overdose. Ann Emerg Med. 1991;20(5):536–9.  
63. Ly BT, Schneir AB, Clark RF. Effect of whole bowel irrigation on the pharmacokinetics of an acetaminophen formulation and progression of radiopaque markers through the gastrointestinal tract. Ann Emerg Med. 2004;43(2):189–95.  
64. Lapatto‐Reiniluoto O, Kivistö KT, Neuvonen PJ. Activated charcoal alone and followed by whole‐bowel irrigation in preventing the absorption of sustained‐release drugs. Clin Pharmacol Ther. 2001;70(3):255–60.  
65. Kirshenbaum LA, Mathews SC, Sitar DS, Tenenbein M. Whole‐bowel irrigation versus activated charcoal in sorbitol for the ingestion of modified‐release pharmaceuticals. Clin Pharmacol Ther. 1989;46(3):264–71.  
66. Barceloux. Position Paper: Cathartics. J Toxicol Clin Toxicol. 2004;42(3):243–53.  
67. Al-Shareef AH, Buss DC, Allen EM, Routledge PA. The effects of charcoal and sorbitol  
39  
(alone and in combination) on plasma theophylline concentrations after a sustained-release formulation. Hum Exp Toxicol. 1990;9(3):179–82.  
68. Sørensen PN. The effect of magnesium sulfate on the absorption of acetylsalicylic acid and lithium carbonate from the human intestine. Arch Toxicol. 1975;34(2):121–7.  
69. Minton NA, Hentry JA. Prevention of drug absorption in simulated theophylline overdose. J Toxicol Clin Toxicol. 1995;33(1):43–9.  
70. Galinsky RE, Levy G. Evaluation of activated charcoal-sodium sulfate combination for inhibition of acetaminophen absorption and repletion of inorganic sulfate. J Toxicol Clin Toxicol. 1984;22(1):21–30.  
71. Mayersohn M, Perrier D, Picchioni AL. Evaluation of a charcoal-sorbitol mixture as an antidote for oral aspirin overdose. Clin Toxicol. 1977;11(5):561–7.  
72. McNamara RM, Aaron CK, Gemborys M, Davidheiser S. Sorbitol catharsis does not enhance efficacy of charcoal in a simulated acetaminophen overdose. Ann Emerg Med. 1988;17(3):243–6.  
73. Goldberg MJ, Spector R, Park GD, Johnson GF, Roberts P. The effect of sorbitol and activated charcoal on serum theophylline concentrations after slow‐release theophylline. Clin Pharmacol Ther. 1987;41(1):108–11.  
74. Keller RE, Schwab RA, Krenzelok EP. Contribution of sorbitol combined with activated charcoal in prevention of salicylate absorption. Ann Emerg Med. 1990;19(6):654–6.  
75. Moon J, Chun B, Song K. An exploratory study; the therapeutic effects of premixed activated charcoal–sorbitol administration in patients poisoned with organophosphate pesticide. Clin Toxicol. 2015;53(2):119–26.  
76. Ghannoum M, Gosselin S. Enhanced poison elimination in critical care. Adv Chronic Kidney Dis. 2013;20(1):94–101.  
77. Proudfoot AT, Krenzelok EP, Vale JA. Position paper on urine alkalinization. J Toxicol Clin Toxicol. 2004;42(1):1–26.  
78. Jearth V, Chauhan V, Sharma K, Negi R. A rare survival after 2,4-D (ethyl ester) poisoning: Role of forced alkaline diuresis. Indian J Crit Care Med [Internet]. 2015;19(1):57. Available from: http://www.ijccm.org/text.asp?2015/19/1/57/148658  
79. Prescott LF, Park J, Darrien I. Mecoprop intoxication. Br J Clin Plharmac. 1979;7:111–6.  
80. Friesen EG, Jones GR, Vaughan D. Clinical presentation and management of acute 2, 4-D oral ingestion. Drug Saf. 1990;5(2):155–9.  
81. Schmoldt A, Iwersen S, Schlüter W. Massive ingestion of the herbicide 2-methyl-4chlorophenoxyacetic acid (MCPA). J Toxicol Clin Toxicol. 1997;35(4):405–8.  
82. Flanagan RJ, Meredith TJ, Ruprah M, Onyon LJ, Liddle A. Alkaline diuresis for acute poisoning with chlorophenoxy herbicides and ioxynil. Lancet. 1990;335(8687):454–8.  
83. Fox GN. Hypocalcemia complicating bicarbonate therapy for salicylate poisoning. West J Med. 1984;141(1):108.  
84. Mendonca S, Gupta S, Gupta A. Extracorporeal management of poisonings. Saudi J Kidney Dis Transplant. 2012;23(1):1.  
85. US-EPA. Recognition and Management of Pesticide Poisonings. 2013;(US Environmental Protection Agency-USEPA):277.  
86. WHO. Safer Access to Pesticides: Community Intervention. 1st ed. Geneva: WHO Press; 2006.  
87. Kendrick D, Majsak-Newman G, Benford P, Coupland C, Timblin C, Hayes M, et al. Poison  
40  
prevention practices and medically attended poisoning in young children: multicentre casecontrol study. Inj Prev. 2017;23(2):93–101.  
88. Mintegi S, Azkunaga B, Prego J, Qureshi N, Dalziel SR, Arana-Arri E, et al. International Epidemiological Differences in Acute Poisonings in Pediatric Emergency Departments. Pediatr Emerg Care [Internet]. 2017;00(00):1. Available from: http://insights.ovid.com/crossref?an=00006565-900000000-98804  
89. Azizi BH, Zulkifli HI, Kassim MS. Circumstances surrounding accidental poisoning in children. Med J Malaysia. 1994;  
90. Rodgers GB. The safety effects of child-resistant packaging for oral prescription drugs. Two decades of experience. JAMA. 1996 Jun;275(21):1661–5.  
91. Cha ES, Chang S-S, Gunnell D, Eddleston M, Khang Y-H, Lee WJ. Impact of paraquat regulation on suicide in South Korea. Int J Epidemiol. 2016 Apr;45(2):470–9.  
92. Roberts DM, Karunarathna A, Buckley NA, Manuweera G, Sheriff MHR, Eddleston M. Influence of pesticide regulation on acute poisoning deaths in Sri Lanka. Bull World Health Organ. 2003;81(11):789–98.  
93. Knipe DW, Metcalfe C, Fernando R, Pearson M, Konradsen F, Eddleston M, et al. Suicide in Sri Lanka 1975-2012: age, period and cohort analysis of police and hospital data. BMC Public Health [Internet]. 2014;14:839. Available from: http://www.biomedcentral.com/14712458/14/839  
94. Gunnell D, Fernando R, Hewagama M, Priyangika WDD, Konradsen F, Eddleston M. The impact of pesticide regulations on suicide in Sri Lanka. Int J Epidemiol. 2007;36(6):1235–42.  
95. Knipe DW, Padmanathan P, Muthuwatta L, Metcalfe C, Gunnell D. Regional variation in suicide rates in Sri Lanka between 1955 and 2011: a spatial and temporal analysis. BMC Public Health. 2017 Feb;17(1):193.  
96. Chowdhury FR, Dewan G, Verma VR, Knipe DW, Isha IT, Faiz MA, et al. Bans of WHO Class I Pesticides in Bangladesh-Suicide Prevention without Hampering Agricultural Output. Int J Epidemiol. 2017 Aug;  
97. Lin J-J, Lu T-H. Trends in solids/liquids poisoning suicide rates in Taiwan: a test of the substitution hypothesis. BMC Public Health [Internet]. 2011;11(1):712. Available from: http://www.biomedcentral.com/1471-2458/11/712  
98. Manuweera G, Eddleston M, Egodage S, Buckley NA. Do targeted bans of insecticides to prevent deaths from self-poisoning result in reduced agricultural output? Environ Health Perspect. 2008;116(4):492–5.  
99. Brasil. Presidência da República. Decreto n<sup>o</sup> 4.074/2002. Brasilia; 2002 p. 1.  
100.  Brasil. Presidência da República. Lei 7.802/1989. Brasília: Casa Civil-Subchefia de Assuntos Jurídicos; 1989 p. 6–9.  
101.  Vijayakumar L, Jeyaseelan L, Kumar S, Mohanraj R, Devika S, Manikandan S. A central storage facility to reduce pesticide suicides--a feasibility study from India. BMC Public Health [Internet]. 2013;13(1):850. Available from: http://www.pubmedcentral.nih.gov/articlerender.fcgi?artid=3847561&tool=pmcentrez&rend ertype=abstract  
102.  Mohanraj R, Kumar S, Manikandan S, Kannaiyan V, Vijayakumar L. A public health initiative for reducing access to pesticides as a means to committing suicide: Findings from a qualitative study. Int Rev Psychiatry [Internet]. 2014;26(4):445–52. Available from: http://www.tandfonline.com/doi/full/10.3109/09540261.2014.924094  
103.  Pearson M, Metcalfe C, Jayamanne S, Gunnell D, Weerasinghe M, Pieris R, et al. Effectiveness of household lockable pesticide storage to reduce pesticide self-poisoning in  
41  
rural Asia: a community-based, cluster-randomised controlled trial. Lancet (London, England). 2017 Oct;390(10105):1863–72.  
104.  Hunt IM, Kapur N, Webb R, Robinson J, Burns J, Shaw J, et al. Suicide in recently discharged psychiatric patients: A case-control study. Psychol Med. 2009;39(3):443–9.  
105.  Eduardo Garcia Garcia, José Prado Alves Filho. Aspectos de Prevenção e Controle de Acidentes no Trabalho com Agrotóxicos. Fundacentr. São Paulo; 2005. 53 p.  
106.  Brasil. Ministério do Trabalho e Emprego. PORTARIA N<sup>o</sup> 86/2005. Brasilia; 2005.  
107.  Brasil. Presidência da República. DECRETO N<sup>o</sup> 2.657/1998 [Internet]. Brasília: Casa; 1998 p. 5–8. Available from: Presidência da República- Subchefia para Assuntos Jurídicos  
108.  Brasil. NR 6 - Equipamento de Proteção Individual (EPI). Portaria GM. 1978;3214(6):1–7.  
109.  FAO. International code of conduct on the distribution and use of pesticides. Food Agric Organ United Nations. 2003;(November 2002):1–36.  
110.  Levesque DL, Arif AA, Shen J. Association between workplace and housing conditions and use of pesticide safety practices and personal protective equipment among North Carolina farmworkers in 2010. Int J Occup Environ Med. 2012 Apr;3(2):53–67.  
111.  WHO. Preventing Disease through Healthy Environments. Geneva, Switzerland: WHO Document Production Services; 2010. p. 6.  
112.  PLANAPO. Plano Nacional de Agroecologia e Produção Orgânica. Ministério do Desenvolvimento Agrário CI de A e PO (CIAPO), editor. Brasília, DF, Brasil; 2013. 96p p.  
113.  Savi EP, Sakae TM, Candemil R, Sakae DY, Valerim K. Sintomas associados à exposição aos agrotóxicos entre rizicultores em uma cidade no sul de Santa Catarina . Medicina (B Aires). 2010;39:17–23.  
114.  Soares W, Freitas E, Coutinho J. Trabalho rural e saúde: intoxicações por agrotóxicos no município de Teresópolis-RJ. Rev Econ e Sociol Rural. 2005;43(4):685–701.  
115.  Faria NMX, Rodrigues Da Rosa JA, Facchini LA. Intoxicações por agrotóxicos entre trabalhadores rurais de fruticultura, Bento Gonçalves, RS. Rev Saude Publica. 2009;43(2):335–44.  
116.  Barcellos M, Faletti MM, Madureira LA dos S, Bauer FC. Analytical evaluation of the protection offered by sealed tractor cabins during crop pulverization with fenitrothion. Environ Monit Assess. 2016;188(12).  
117.  Baldi I, Lebailly P, Jean S, Rougetet L, Dulaurent S, Marquet P. Pesticide contamination of workers in vineyards in France. J Expo Sci Environ Epidemiol [Internet]. 2006;16(2):115–24. Available from: http://www.ncbi.nlm.nih.gov/pubmed/16175199  
118.  Soares WL, de Freitas EAV, Coutinho JAG. Trabalho rural e saúde : intoxicações por agrotóxicos no município de Teresópolis - RJ. Rev Econ e Sociol Rural. 2005;43(4):685–701.  
119.  Silva JPL da, Araújo MZ, Melo LC de Q. Panorama da vulnerabilidadeda saúde do agricultor familiar de São José de Princesa/PB. Rev Bras Ciências da Saúde [Internet]. 2013;17(1):29– 38. Available from: http://periodicos.ufpb.br/ojs2/index.php/rbcs/article/view/13652  
120.  Norkaew S, Siriwong W, Siripattanakul S RM. Knowledge, Attitude, and Practice (KAP) of Using Personal Protective Equipment (PPE) for Chilli-Growing Farmers in Huarua SubDistrict, Mueang District, Ubonrachathani Province, Thailand. J Heath Res. 2010;24(2):83– 6.  
121.  Andrade-Rivas F, Rother H-A. Chemical exposure reduction: Factors impacting on South African herbicide sprayers’ personal protective equipment compliance and high risk work practices. Environ Res. 2015 Oct;142:34–45.  
122.  Gregolis T, Pinto W, Saúde FP-RB de, 2012  undefined. Percepção de riscos do uso de  
42  
- agrotóxicos por trabalhadores da agricultura familiar do município de Rio Branco, AC. Rev Bras Saúde Ocup. 2012;v. 37(125).  
123.  Leme TS, Papini S, Vieira E, Luchini LC. [Evaluation of personal protective equipment used by malathion sprayers in dengue control in São Paulo, Brazil]. Cad Saude Publica. 2014 Mar;30(3):567–76.  
124.  Sam KG, Andrade HH, Pradhan L, Pradhan A, Sones SJ, Rao PGM, et al. Effectiveness of an educational program to promote pesticide safety among pesticide handlers of South India. Int Arch Occup Environ Health. 2008;81(6):787–95.  
125.  Perry MJ, Layde PM. Farm pesticides: Outcomes of a randomized controlled intervention to reduce risks. Am J Prev Med. 2003;24(4):310–5.  
126.  Hashemi SM, Hosseini SM, Hashemi MK. Farmers’ perceptions of safe use of pesticides: Determinants and training needs. Int Arch Occup Environ Health. 2012;85(1):57–66.  
127.  Flocks J, Kelley M, Economos J, McCauley L. Female farmworkers’ perceptions of pesticide exposure and pregnancy health. J Immigr Minor Heal. 2012 Aug;14(4):626–32.  
128.  Brasil. Lei de Segurança Alimentar e Nutricional. Lei n<sup>o</sup> 11346, 15 setembro 2006. 2006;  
129.  Brasil. Ministério da Saúde. Guia Alimentar para a População Brasileira Guia Alimentar para a População Brasileira. 2<sup>a</sup> . Melo E lves de, editor. Brasília: Departamento de Atenção Básica; 2014. 199 p.  
130.  Mie A, Andersen HR, Gunnarsson S, Kahl J, Kesse-Guyot E, Rembiałkowska E, et al. Human health implications of organic food and organic agriculture: a comprehensive review. Environ Heal. 2017 Dec;16(1):111.  
131.  EPRS. Human health implications of organic food and organic agriculture. Eur Parliam Res Serv. 2016;(Science and Technology Options Assessment (STOA)):88.  
132.  Soliman KM. Changes in concentration of pesticide residues in potatoes during washing and home preparation. Food Chem Toxicol. 2001 Aug;39(8):887–91.  
133.  Hassanzadeh N, Bahramifar N, Esmaili-Sari A. Residue content of carbaryl applied on greenhouse cucumbers and its reduction by duration of a pre-harvest interval and post-harvest household processing. J Sci Food Agric. 2010 Oct;90(13):2249–53.  
134.  Hao J, Wuyundalai  , Liu H, Chen T, Zhou Y, Su Y-C, et al. Reduction of Pesticide Residues on Fresh Vegetables with Electrolyzed Water Treatment. J Food Sci. 2011 May;76(4):C520– 4.  
135.  Kusvuran E, Yildirim D, Mavruk F, Ceyhan M. Removal of chloropyrifos ethyl, tetradifon and chlorothalonil pesticide residues from citrus by using ozone. J Hazard Mater. 2012 Nov;241–242:287–300.  
136.  Kong Z, Shan W, Dong F, Liu X, Xu J, Li M, et al. Effect of home processing on the distribution and reduction of pesticide residues in apples. Food Addit Contam Part A. 2012 Aug;29(8):1280–7.  
137.  Al-Taher F, Chen Y, Wylie P, Cappozzo J. Reduction of pesticide residues in tomatoes and other produce. J Food Prot. 2013 Mar;76(3):510–5.  
138.  Lu H-Y, Shen Y, Sun X, Zhu H, Liu X-J. Washing effects of limonene on pesticide residues in green peppers. J Sci Food Agric. 2013 Sep;93(12):2917–21.  
139.  Saeedi Saravi SS, Shokrzadeh M. Effects of washing, peeling, storage, and fermentation on residue contents of carbaryl and mancozeb in cucumbers grown in greenhouses. Toxicol Ind Health. 2014;32(6):1135–42.  
140.  Rani M, Saini S, Kumari B. Persistence and effect of processing on chlorpyriphos residues in tomato (Lycopersicon esculantum Mill.). Ecotoxicol Environ Saf. 2013 Sep;95:247–52.  
43  
141.  Mekonen S, Ambelu A, Spanoghe P. Effect of Household Coffee Processing on Pesticide Residues as a Means of Ensuring Consumers’ Safety. J Agric Food Chem. 2015 Sep;63(38):8568–73.  
142.  Sengupta D, Aktar MW, Alam S, Chowdhury A. Impact assessment and decontamination of pesticides from meat under different culinary processes. Environ Monit Assess. 2010 Oct;169(1–4):37–43.  
143.  Certel M, Cengiz MF, Akçay M. Kinetic and thermodynamic investigation of mancozeb degradation in tomato homogenate during thermal processing. J Sci Food Agric. 2012 Feb;92(3):534–41.  
144.  Zhang Z, Jiang WW, Jian Q, Song W, Zheng Z, Wang D, et al. Changes of field incurred chlorpyrifos and its toxic metabolite residues in rice during food processing from-RAC-toconsumption. Spanoghe P, editor. PLoS One. 2015 Jan;10(1):e0116467.  
145.  Mujawar S, Utture SC, Fonseca E, Matarrita J, Banerjee K. Validation of a GC-MS method for the estimation of dithiocarbamate fungicide residues and safety evaluation of mancozeb in fruits and vegetables. Food Chem. 2014 May;150:175–81.  
146.  Savi GD, Piacentini KC, Bortolotto T, Scussel VM. Degradation of bifenthrin and pirimiphosmethyl residues in stored wheat grains (Triticum aestivum L.) by ozonation. Food Chem. 2016 Jul;203:246–51.  
147.  Zhang Y, Zhang W, Liao X, Zhang J, Hou Y, Xiao Z, et al. Degradation of diazinon in apple juice by ultrasonic treatment. Ultrason Sonochem. 2010 Apr;17(4):662–8.  
148.  Chowdhury MAZ, Jahan I, Karim N, Alam MK, Rahman MA, Moniruzzaman M, et al. Determination of Carbamate and Organophosphorus Pesticides in Vegetable Samples and the Efficiency of Gamma-Radiation in Their Removal. Biomed Res Int. 2014;2014:1–9.  
149.  Zhou X-W, Zhao X-H. Susceptibility of nine organophosphorus pesticides in skimmed milk towards inoculated lactic acid bacteria and yogurt starters. J Sci Food Agric. 2015 Jan;95(2):260–6.  
150.  Zhang Y, Hou Y, Zhang Y, Chen J, Chen F, Liao X, et al. Reduction of diazinon and dimethoate in apple juice by pulsed electric field treatment. J Sci Food Agric. 2012 Mar;92(4):743–50.  
151.  Misra NN, Pankaj SK, Walsh T, O’Regan F, Bourke P, Cullen PJ. In-package nonthermal plasma degradation of pesticides on fresh produce. J Hazard Mater. 2014 Apr;271:33–40.  
152.  Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 4/2017. Ministério da Saúde, Gabinete do Ministro, Brasília, DF, Brasil Brasília; 2017 p. 288p.  
153.  Brasil. Ministério da Saúde. Portaria de Consolidação n<sup>o</sup> 5/2017. 5 Brasília; 2017.  
154.  Brasil. Ministério da Saúde. Diretrizes Nacionais para a Vigilância em Saúde de Populações Expostas a Agrotóxicos. 1<sup>a</sup> . Brasília: Editora MS; 2016. 1-26 p.  
44

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
O presente trabalho foi realizado de acordo com as orientações descritas no documento intitulado Diretrizes Metodológicas para a Elaboração de Diretrizes Clínicas do Ministério da Saúde(1), seguindo o fluxo de trabalho definido para a elaboração de Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) preconizado pela Portaria MS/SCTIE nº 27, de 12 de junho de 2015(2).

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
A Coordenação Geral de Vigilância em Saúde Ambiental (CGVAM) coordenou a elaboração das DDTA como Comitê Gestor (CG) e constituiu o Grupo Elaborador (GE).  Este, por sua vez, foi constituído por profissionais com expertise em Saúde Pública, Toxicologia e Medicina do Trabalho. Assim, foram convidados representantes da Associação Brasileira de Centros de Informações Toxicológicas (ABRACIT), dos Centros de Centro de Informação e Assistência Toxicológica (CIATOX), médicos toxicologistas de núcleos universitários do país e médicos do trabalho das Secretarias de Estaduais Saúde. Além desses, foram convidados membros integrantes de diversos departamentos do Ministério da Saúde, tais como o Departamento de Vigilância em Saúde Ambiental e Saúde do Trabalhador (DSAST) da Secretaria de Vigilância em Saúde; o Departamento de Gestão e Incorporação de Tecnologias (DGITS) e o Departamento de Assistência Farmacêutica (DAF), ambos da Secretaria de Ciência, Tecnologia e Insumos Estratégicos (SCTIE). Também fizeram parte do grupo elaborador técnicos do Departamento de Atenção Básica (DAB), do Departamento de Atenção Especializada e Temática (DAET) e do Departamento de Atenção Hospitalar e de Urgência (DAHU), da Secretaria de Atenção à Saúde (SAS).  
O GE contribuiu na elaboração do escopo das DDTA, na revisão e aprimoramento dos documentos elaborados pelo CG: documento de alcance, perguntas de busca, resultados da busca, avaliação de sínteses de evidência. O GE também contribuiu para a redação e avaliação das recomendações, aportou alguns documentos que não foram captados na revisão e participou de todas as tarefas necessárias para a aprovação final do documento. Ressalta-se que os membros do grupo elaborador aprovaram o documento final antes da sua submissão para a avaliação externa.  
Para a elaboração do primeiro capítulo das DDTA (Abordagem Geral), foi realizada uma reunião presencial na qual se definiu o plano de trabalho, tendo sido explicada aos membros do GE as etapas do processo.  Após as buscas, análise das evidências e elaboração das recomendações, duas reuniões presenciais foram realizadas no intuito de redigir e avaliar as recomendações propostas.  Os demais ajustes mencionados anteriormente foram realizados com ajuda de meios virtuais (e-mail, compartilhamento de arquivos em nuvens e outros).  
45

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Os grupos de agrotóxicos selecionados para o desenvolvimento das DDTA foram definidos a partir de uma proposta elaborada pelo GG em conjunto com toxicologistas, considerando inicialmente a frequência de notificações no Sinan. Posteriormente, a partir de uma adaptação de um instrumento de priorização utilizado pelo Instituto de Cancerologia da Colômbia, foi confeccionado um formulário de priorização. Nele, alguns parâmetros foram propostos (carga do agravo, benefício potencial ao elaborar as diretrizes, disponibilidade de evidência científica, e possibilidades de ações de prevenção) para que o GE avaliasse e definisse as substâncias a serem contempladas na diretriz.  
Os temas foram compartilhados numa reunião presencial com o grupo elaborador, o qual após avaliação, selecionou os seguintes tópicos:  abordagem geral do indivíduo intoxicado por agrotóxicos; intoxicação por inibidores da acetilcolinesterase, glifosato, piretróides e piretrinas, ácido 2,4diclorofenoxiacético (2,4-D) e bipiridílios. O grupo também decidiu pela inclusão de um capítulo adicional sobre o monitoramento da população cronicamente exposta a agrotóxicos. Para definir a ordem em que seriam elaborados os capítulos, cada membro do grupo elaborador preencheu uma matriz de priorização que considerava a relevância de cada grupo químico e o impacto potencial da elaboração das diretrizes em cada caso.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
O escopo das DDTA foi elaborado em reunião presencial do GE, onde foram discutidos e descritos os pontos pretendidos para a construção das recomendações do Ministério da Saúde para a prevenção e atenção integral ao indivíduo intoxicado por agrotóxicos.  
O documento com o escopo foi publicado no site da Comissão Nacional de Inserção de Tecnologias do SUS (CONITEC), e passou por Enquete Pública no período de 09 de dezembro de 2015 a 09 de janeiro de 2016. Foram recebidas 38 contribuições, das quais: 16 “muito bom”, 18 “bom” e 4 “regular”.  
Contudo, considerando as atualizações regulatórias propostas pela Agência Nacional de Vigilância durante o processo de elaboração dessas diretrizes, os bipiridílios foram excluídos do escopo.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Num primeiro momento, foram elaboradas perguntas genéricas de pesquisa relacionadas aos temas prevenção, diagnóstico e tratamento da intoxicação por agrotóxicos de uma forma geral. Em seguida foi realizada uma busca exploratória para estruturar as perguntas usando a estratégia “PICO”.  A palavra representa um acrônimo para **P** aciente/ **P** opulação, **I** ntervenção, **C** omparação e “ **_O_** _utcomes_ ”  
46  
(desfecho), os quais são os elementos fundamentais da pergunta de pesquisa e fundamentam a sua construção para que se inicie uma busca bibliográfica de evidências. Assim, uma pergunta “PICO” contempla simultaneamente (BRASIL, 2016):  
- A população incluída nos estudos, suas características e situação clínica;  
- A intervenção a ser investigada;  
- A utilização de um comparador, alternativa ou controle definido para cada intervenção;  
- O desfecho (do inglês “ _outcome_ ”) investigado.  
Foram selecionados desfechos considerados críticos consensuais, sendo eles: incidência, morbidade  
e mortalidade por intoxicação por agrotóxicos. As tabelas com todas as perguntas “PICO” formuladas pelo grupo elaborador são apresentadas como anexo correspondente a cada capítulo.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Primeiramente, foi realizado o levantamento bibliográfico de Guias de Prática Clínica (GPC) que abordassem o tema de intoxicação por agrotóxicos, com o objetivo de verificar se esses guias possuíam as informações necessárias para responder às perguntas PICO e então adaptar as recomendações dos guias encontrados, por meio da metodologia _Adapte_ (3). A busca foi realizada de forma irrestrita e nos sites de instituições elaboradoras e compiladoras de guias, busca manual em instituições governamentais e sociedades científicas brasileiras, busca sistemática em PUBMED e BVS.  
A qualidade dos guias encontrados foi avaliada pela metodologia _Appraisal of Guidelines for Research and Evaluation_ (AGREE II), sendo verificado se esses respondiam às perguntas PICO   (4). As tabelas com as avaliações dos guias encontrados são apresentadas como anexo correspondente a cada capítulo.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
A busca sistemática foi realizada dada a impossibilidade de responder adequadamente todas as perguntas PICO com as informações disponibilizadas nos GPC. Seguiu-se com a revisão sistemática da literatura nas bases de dados _PubMed/Medline_ , Biblioteca Virtual em Saúde (BVS) e _Cochrane Library_ .

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Foram construídos descritores a partir de cada pergunta PICO nas diferentes bases nos idiomas inglês, português e espanhol, considerando “Descritores em Ciências da Saúde” (Decs) para BVS; e _Medical Subject Headings_ (Mesh) no _PubMed._ Para o Cochrane, foram considerados somente os termos livres  
47  
_poisoning_ e _pesticides_ . Posteriormente, as buscas foram ampliadas por meio da inclusão de sinônimos. O conjunto de termos MeSH/Decs e seus sinônimos foi adicionado à busca pelos operadores _booleanos_ AND (para adicionar termos) ou OR (para adicionar sinônimos). As estratégias de busca utilizadas estão disponíveis como anexo referente a cada capítulo.  
Os seguintes critérios de inclusão foram adotados, para a busca sistemática: publicações originais; artigos nos idiomas inglês, português e espanhol; publicados entre 01/01/2010 a 30/08/2017. Os trabalhos que não se encaixaram nos critérios de inclusão não foram utilizados.  
Para subsidiar as evidencias de tratamento, foram considerados inicialmente ensaios clínicos e revisões sistemáticas de ensaios clínicos. Ante a impossibilidade de serem encontrados esse tipo de publicações para alguns temas, foram incluídos outros tipos de estudo.  Para prevenção e diagnóstico, optou-se pela utilização de estudos clínicos e observacionais, considerando também dados publicados em estudos pré-clínicos para informação complementar.  
A seleção de artigos para a leitura completa foi realizada por pares. Os avaliadores utilizaram como critério o fato desses apresentarem em seus títulos ou resumos respostas potenciais às perguntas PICO.  Nesse ponto, somente foram excluídos artigos rejeitados por ambos avaliadores. As tabelas de seleção de artigos estão disponíveis nos anexos referentes ao capítulo.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Dada a baixa disponibilidade de artigos primários que considerassem alguns temas específicos, optou-se pela recuperação de estudos primários a partir de guias de pratica clínica bem como revisões sistemáticas, busca na literatura cinza e artigos fornecidos pelo próprio grupo elaborador.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
A qualidade dos estudos selecionados foi avaliada por meio das ferramentas propostas pelo sistema “ _Grading of Recommendations Assessment, Development and Evaluation_ ” (GRADE)(1,5,6). Nele, a qualidade das evidências utilizadas para apoiar uma recomendação para um determinado desfecho é avaliada por meio de uma análise conjunta de informações provenientes de estudos intervencionais e observacionais. Dessa forma, as recomendações são apoiadas na confiabilidade da informação utilizada, sendo ela representada por um nível de qualidade de evidência. A Tabela 2 apresenta os quatro níveis de evidência atribuídos pelo sistema, considerando a confiança dos resultados avaliados.  
**Tabela 2 - Significado dos quatro níveis de qualidade das evidências no sistema GRADE(5).**  
|**Qualidade**|**Definição**|
|---|---|  
48  
|**Alta**<br>**++++**|Há elevada confiança de que o verdadeiro resultado está muito perto da<br>estimativa relatada no conjunto de evidências|
|---|---|
|**Moderada**<br>**+++**|Há confiança moderada na estimativa de efeito. É provável que o<br>verdadeiro resultado aproxima-se da estimativa relatada no conjunto de<br>evidências, mas há possibilidade de que seja diferente|
|**Baixa**<br>**++**|A confiança na estimativa de efeito é limitada. O verdadeiro resultado<br>pode ser muito diferente da estimativa relatada no conjunto de evidências|
|**Muito Baixa**<br>**+**|Há pouca confiança na estimativa de efeito. É muito provável que o<br>resultado verdadeiro seja substancialmente diferente da estimativa<br>relatada no conjunto de evidências|  
Traduzido de GRADE, 2013.  
Deve-se aqui ressaltar que, pela metodologia GRADE, o primeiro passo para a avaliação da qualidade das evidências é identificar o tipo de estudo que fundamenta as estimativas do efeito observado. Dessa forma, é pré-definido que evidências obtidas por meio de ensaios clínicos randomizados, apresentam uma qualidade inicialmente classificada como alta. Por outro lado, evidências de estudos observacionais são, em princípio, classificadas como de baixa qualidade. Contudo, ao longo do processo de análise, alguns fatores podem elevar ou diminuir a qualidade da evidência (Tabela 3Tabela 4), o que resulta na sua categorização em um dos quatro níveis de qualidade descritos anteriormente.  
**Tabela 3 – Fatores que reduzem a qualidade da evidência(5).**  
|**Fator**|**Consequência**|
|---|---|
|**Limitações metodológicas (risco de viés)**|↓ 1 ou 2 níveis|
|**Inconsistência**|↓ 1 ou 2 níveis|
|**Evidência indireta**|↓ 1 ou 2 níveis|
|**Imprecisão**|↓ 1 ou 2 níveis|
|**Viés de publicação**|↓ 1 ou 2 níveis|  
**Traduzido de GRADE, 2013.**  
**Tabela 4 – Fatores que elevam a qualidade da evidência(5).**  
|**Fator**|**Consequência**|
|---|---|  
49  
|Elevada magnitude de efeito||↑ 1 ou 2 níveis|
|---|---|---|
|**Fatores**<br>**de**<br>**confusão**<br>**residuais**|**que**|↑ 1 nível|
|**aumentam a confiança na estimativa**|||
|**Gradiente dose-resposta**||↑ 1 nível|  
Traduzido de GRADE, 2013.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Considerando o sistema GRADE, a ênfase para que uma determinada intervenção seja adotada ou não é expressa pela força da sua recomendação. Para tal, além de considerar a qualidade das evidências analisadas, a metodologia propõe outros fatores determinantes da direção da recomendação. Assim, são considerados também o equilíbrio entre resultados desejáveis e indesejáveis (possíveis danos e benefícios) e a aplicação de valores e preferências do paciente (Tabela 5). Dessa forma, a força da recomendação pode ser forte ou condicional (fraca), ou seja, a favor ou contra a intervenção proposta(1).  
Na elaboração das presentes diretrizes, para a avaliação da força da recomendação, foram considerados os seguintes fatores:  
- Qualidade das evidências;  
- O balanço entre riscos e benefícios;  
- Custos associados à intervenção;  
- Aceitabilidade;  
- Viabilidade,  
- Importância do problema;  
- Valores e preferências.  
A avaliação dos critérios, que não a “Qualidade das evidências”, foi realizada por meio do consenso entre os participantes do grupo elaborador, após cada recomendação ter sido exaustivamente avaliada. O grupo realizou o julgamento sobre a direção e força das recomendações. As tabelas de avaliação de recomendações estão disponíveis no anexo IX.  
É importante ressaltar que uma recomendação forte não está necessariamente atrelada a uma qualidade de evidência alta ou moderada, assim como evidências de qualidade baixa não formarão necessariamente uma recomendação condicional. Por exemplo, não existem ensaios clínicos controlados sobre a eficácia dos paraquedas na prevenção de óbito por trauma em queda livre, mas é razoável recomendar fortemente seu uso mesmo que a evidência provenha de estudos observacionais(7). Nesse caso existe uma evidência muito baixa que gerou uma recomendação forte. **Tabela 5 – Implicação dos graus de recomendação de acordo com o sistema GRADE(6).**  
50  
|**Público Alvo**|**Forte**|**Condicional (fraca)**|
|---|---|---|
|**Gestores**|A recomendação deve ser adotada<br>como política de saúde na maioria<br>das situações|É necessário debate substancial e<br>envolvimento das partes interessadas.|
|**Pacientes**|A maioria dos indivíduos desejaria<br>que a intervenção fosse indicada e<br>apenas um pequeno número não<br>aceitaria essa recomendação|Grande parte dos indivíduos desejaria<br>que a intervenção fosse indicada;<br>contudo considerável número não<br>aceitaria essa recomendação|
|**Profissionais**|A maioria dos pacientes deve|O profissional deve reconhecer que|
|**de Saúde**|receber a intervenção recomendada|diferentes escolhas serão apropriadas<br>para cada paciente para definir uma|
|||decisão consistente com os seus<br>valores e preferências|  
Fonte: Brasil, 2014.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Uma versão preliminar desta diretriz foi submetida a revisão por médicos avaliadores externos, convidados pelo Comitê Gestor.  
Após a avaliação das colaborações encaminhada pelos avaliadores externos, o documento foi encaminhado à Subcomissão de Avaliação dos Protocolos Clínicos e Diretrizes Terapêuticas (PCDT) da CONITEC. Posteriormente, submetido à plenária da CONITEC para aprovação, de acordo com o fluxo previsto pela Portaria MS/SCTIE(2).  
Após aprovação na plenária foi realizada uma consulta pública para receber contribuições da sociedade, e identificar os valores e preferências das recomendações pelos pacientes. A página de consulta pública foi amplamente divulgada à comunidade, associações representantes de grupos de trabalhadores agrícolas e outros grupos de associações, funções e órgãos relacionados à saúde e as populações do campo, floresta e águas. As contribuições recebidas foram avaliadas pelo grupo elaborador e, se pertinentes e alinhadas à metodologia de base em evidências, foram incorporadas ao documento.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
Foi solicitado a todos os membros do grupo elaborador, grupo de validação e todos os que participaram em algum momento na elaboração do guia, o preenchimento do formulário de declaração de conflitos de interesse. No formulário, o qual consiste em uma tradução de formato  
51  
proposto no “ _Guía Metodológica para la elaboración de Guías de Atención Integral en el Sistema General de Seguridad Social en Salud colombiano”_ , constam interesses relacionados às atividades que possam gerar conflitos no que se refere ao julgamento profissional sobre um interesse primário, como a segurança dos pacientes ou a validade da pesquisa. Também constam os que podem influenciar a decisão por um interesse secundário como ganho financeiro, prestígio promoção pessoal ou profissional. Apenas um convidado apresentou conflito de interesse, sendo ele, então, excluído de qualquer forma de participação nos trabalhos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
A previsão de processo de atualização para esta diretriz é de 4 anos após a publicação, ou se surgirem novas evidências que determine novas recomendações.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
As despesas para a elaboração da presente diretriz foram previstas no orçamento do Ministério da Saúde/Organização Pan Americana de Saúde, para o Departamento de Vigilância em Saúde Ambiental e Saúde do Trabalhador, da Secretaria de Vigilância em Saúde do Ministério da Saúde.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo A – Metodologia** -->
1. Brasil. Diretrizes metodológicas : elaboração de diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Gestão e Incorporação de Tecnologias em Saúde. 2016. 100 p.  
2. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia e Insumos Estratégicos. PORTARIA N<sup>o</sup> 27, DE 12 DE JUNHO DE 2015 Brasil; 2015.  
3. Brasi. Diretrizes metodológicas : ferramentas para adaptação de diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Departamento de Ciência e Tecnologia. Brasília; 2014. 110 p.  
4. AGREE II. INSTRUMENTO DE AVALIAÇÃO DE NORMAS DE ORIENTAÇÃO CLÍNICA - AGREE II (APPRAISAL OF GUIDELINES FOR RESEARCH & EVALUATION II). Canadá; 2009.  
5. GRADE. GRADE Handbook -Handbook for grading the quality of evidence and the strength of recommendations using the GRADE approach. [Internet]. 2013. p. 1–57. Available from: http://gdt.guidelinedevelopment.org/app/handbook/handbook.html  
6. BRASIL M da S. Diretrizes metodológicas : Sistema GRADE – Manual de graduação da qualidade da evidência e força de recomendação para tomada de decisão em saúde / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Depar- tamento de Ciência e T. Brasília; 2014.  
7. Smith GC, Pell JP. Parachute use to prevent death and major trauma related to gravitational challenge: Systematic review of [randomized] controlled trials. J Int Assoc Physicians AIDS Care. 2004;3(4):108–9.  
52

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Intoxicação por Agrotóxicos** -->
<!-- Start of picture text -->
Sintomatologi Sim Exposição<br>a aguda aguda<br>Não Use equipamentos de<br>proteção individual<br>( EPI)<br>Avaliação clínica e exames  Avaliação<br>complementares e  clínica inicial Se necessário<br>atendimento ou  encaminhar para<br>encaminhamento de  unidade de maior<br>acordo com protocolos de  complexidade<br>cada unidade<br>Sim Não<br>Estável<br>Manter sob observação por 6<br>a 12 horas. Considerar medidas<br>Suporte vital básico e<br>de descontaminação*<br>avançado<br>Descontaminação mucocutânea e gástrica*, Eliminação ou Antídoto,<br>Não<br>Estável  de acordo com a clínica do paciente e características do agente e da<br>exposição.<br>Solicitação de exames complementares, se necessário.<br>Sim<br>Alta  e  acompanhamento  ambulatorial  para  Continuidade do atendimento de acordo com evolução:<br>prevenção de novas intoxicações, tratamento de  Se alta, acompanhamento ambulatorial para prevenção de<br>sequelas.  novas intoxicações, tratamento de sequelas.<br>Se tentativa de suicídio, encaminhar para RAPS. Se tentativa de suicídio, encaminhar para RAPS.<br><!-- End of picture text -->  
**Priorize o suporte vital básico e proteja via aérea em pacientes com alterações de consciência.**  
Ligue para o **CIATox 0800 722 6001** para esclarecer as indicações dos métodos de descontaminação e eliminação para cada substância.  
***Em pacientes atendidos em até 60 minutos após a exposição, avaliando se os benefícios teóricos superam os possíveis danos, garantindo a proteção da via aérea.**  
1. Considere lavagem gástrica quando houver ingestão de grande quantidade de agrotóxicos altamente tóxicos que não sejam diluídos em solventes orgânicos e corrosivos.  
2. Considere utilizar uma dose única de carvão ativado quando houver ingestão de grande quantidade de agrotóxicos altamente tóxicos que são adsorvidos pelo carvão ativado. Dose: 0,1-1 g/kg de carvão em pó diluído em agua ou soro. Máximo 50 g.  
**Notifique todos os casos, suspeitos ou confirmados** , na ficha de intoxicação exógena do Sinan; **Notifique na ficha de Violência** , se suspeita de maltrato, tentativa de suicídio ou homicídio; 53 **Preencha a Comunicação de Acidente de Trabalho** , se exposição ocupacional; Declaração de óbito quando aplicável.  
**Anexo C – Fluxograma para ações de Vigilância de Intoxicações por**  
<!-- Start of picture text -->
Agrotóxicos<br><!-- End of picture text -->  
<!-- Start of picture text -->
ACOES DE VIGILANCIA<br>INTOXICAGOES COM AGROTOXICOS<br>PREENCHER A FICHA DE INTOXICACOES<br>EXOGENAS (SINAN)<br>ACIDENTAL OCUPACIONAL VIOLENCIA/HOMIC{DIOeesea fe SURG<br>Preencher Ficha de Violéncia<br>Interpessoal Autoprovocada<br>seguintesAtentar campospara o napreenchimento Ficha de IntoxicacSodos Emitir Comunicagaoi pa ncintie de Trabalho<br>Exégena (Sinan): (CAT)<br>1. Campo 32 ("Ocupacao"); Entrar em contato com a e<br>2. Campo 34 (Local de ocorréncia4 da refer€ncia em Satide do Trabalhadorquipe de<br>‘exposig8o/contaminag80 como jaca uplic ietdeial neta da<br>3. Campo ‘ambiente36 (Atividadede trabalho";Econémica -CNAE) Vigilancia em Satide do Trabalhador<br>4. Campo 56 ("A exposicéo/conta-<br>minago foi decorrente do trabalho<br>ocupacao<br>RECOMENDAR AFASTAMENTO DA EXPOSICAO<br><!-- End of picture text -->  
54

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo D – Ficha de Intoxicação Sinan** -->
<!-- Start of picture text -->
Repablica Federativa do Brasil SINAN<br>Miniaterio da Sande SISTEMA DE INFORMAGAO DE AGRAVOS DE NOTIFICACAO Ne<br>FICHA DE INVESTIGAGAO — INTOXICACAO EXOGENA<br>‘Caso suspeito: todo squele individuo que, tendo sido exposto = substsnoas quimicas (agrotoxicos, medicamentos, produtos di<br>uso doméstico, cosméticos © higiene pessoal, produtos quimicos de uso industrial, drogas. plantas e alimentos e, bebidas),<br>presente sinais © sintomas clinicos de intoxica3o e/ou alteragdes laboratoriais provavelmente ou possivelmente compativeis.<br>[#] Tes . 2 Indviduat<br>[2] Agravoisoenca (Coaigo (C1D10)[ 3] Data da Notmeacso<br>: INTOXICAGAO EXOGENA T659 i<br>[2]uF | [5]municipioae Notmeago (Codigo (IBGE)<br>[5] Unisace ae Sauce (ou cura tert nttcasra) ‘Codigo eee |<br>[2] Nome do Pactente [2]! 22 Nascimento<br>Bomr (ou) igade __ 3° FFT] Sex0 m-stescutine ; |Raga’Cor<br>cena os Pres OFpay, eesnieanea sey ae:<br>SSTEma eSSiemade mmacomets [antgeSo tats gnaSamp ou gesgre)TEducerkoEnerowipeco!UndanavaemeonaaelaconseSEerage grassdome suoerie!Su  com® ge a la SEsWigrorede mio*O neonglNo n e toantgooe  coll cu? ges) Oo|<br>[5](aTLLLILITILItNumero [Fe]muntcpedo cartdoae susResiencia tttFners sane (Codigo (IBGE) Distrito |<br>25] Sarr [Btesescur(rua, avenida,_.) codigo<br>2)Nunero Feeanesemeno paces) [Esmee |<br>aecamp o t. [ai ce rf<br>(DDD) Telefone 2791 - uma 2-Rura [] | Bo]Pats (se resisente tora do Brasi<br>: 3-Penumana §-Ignorado J<br>Dados Complementares do Caso<br>Ellon mersssre [2)ocupagso<br>‘Stuapio no Mereado de Trabaino cm<br>‘1- Empregado registrado com carteira assinads 05 - Servidor pabiico celetista otasnaaat aves<br>02 - Empregado n3o registrado 06- Aposentado 11- Empregador<br>(03- Autonomoy conta propria G7- Desempregado 12- Outros.<br>(04- Servidor pubico estatuano 06 - Trapaino temporano 99 - Ignorado )<br>Fl Loos de ccorrenataSEscolaicreche1. a3Residencia exposigSo 2. Ambiente de trapamo 3.Trajetodo trabamo —4.Servigasde sande oO |<br>[B5] Nome do localestabelecmento de ocorrénciaE.Amblente extemo 7.0utro | eensS.gnorado |<br>PALF Pa)wunicipie<br>ao esapeiecimerto coago(BG=) [3s]Ditto |<br>eer [Fi]togracouro ( nua, aveniaa, etc. - enderego do estabelectmento)<br>a2] Numero (Bicemienente ar. casa ) [4 Ponto ae Reterencia do estapelectmento =hat |<br>Fa@](000) Tetetone FPP 3-PerturbanaESRI ne Liat se estaoetecmertotra oo Bras) |<br>IntoxicagSo Exogena Sinan$-IgnoradoNET SvS 03/06/2005 7<br><!-- End of picture text -->  
55

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.1 – PERGUNTAS PICO - ABORDAGEM GERAL** -->
**Quadro I.1.1 -** Perguntas PICO relativas à abordagem geral para o diagnóstico de pacientes com intoxicação aguda por agrotóxicos. **Quadro I.1.2 -** Perguntas PICO relativas à abordagem geral para o tratamento de pacientes com intoxicação aguda por agrotóxicos. **Quadro I.1.3 -** Perguntas de pesquisa no formato “PICO” para questões de prevenção às intoxicações por agrotóxicos.  
**Quadro I.1.1 -** Perguntas PICO relativas à abordagem geral para o diagnóstico de pacientes com intoxicação aguda por agrotóxicos.  
|**Perguntas**|**População**|**Intervenção**|**Comparação**|**Desfecho**|
|---|---|---|---|---|
|1. Quais aspectos devem ser<br>considerados na anamnese para<br>avaliar exposições potenciais a<br>agrotóxicos?|Indivíduos<br>potencialmente<br>expostos<br>a<br>agrotóxicos.|- História da exposição;<br>- História ocupacional;<br>- Antecedentes de interesse.||Diagnóstico de casos de<br>intoxicação.|
|2. Quais são as manifestações<br>clínicas<br>mais<br>frequentes<br>que<br>permitem<br>suspeitar<br>de<br>uma<br>intoxicação agudapor agrotóxicos?|Indivíduos expostos a<br>agrotóxicos.|- Manifestações clínicas da intoxicação aguda por<br>agrotóxicos (principais grupos) e toxindromes.||Diagnóstico de casos de<br>intoxicação.|
|3. Quais exames podem auxiliar no<br>diagnóstico ante a suspeita de<br>intoxicação aguda por agrotóxicos?|Indivíduos<br>com<br>suspeita<br>de<br>intoxicação<br>por<br>agrotóxicos.|- Exames laboratoriais para o diagnóstico de intoxicação<br>por<br>agrotóxicos;<br>- Exames complementares para o acompanhamento dos<br>casos de  intoxicaçãopor agrotóxicos.||- Diagnóstico;<br>- Mortalidade;<br>- Gravidade;<br>- Incapacidade.|
|4. Quais são os diagnósticos<br>diferenciais de intoxicação aguda<br>com agrotóxicos?|Indivíduos<br>com<br>suspeita<br>de<br>intoxicação<br>por<br>agrotóxicos.|-<br>Diagnósticos<br>diferenciais<br>da<br>intoxicação<br>por<br>agrotóxicos.|Pergunta de con|textualização.|
|5. Qual é a melhor escala para<br>avaliar a gravidade da intoxicação?|Homes e mulheres<br>com<br>suspeita<br>de<br>intoxicação<br>por<br>agrotóxicos.|- Acolhimento considerar classificação de risco em<br>unidades de pronto atendimento e emergência - Escalas de<br>avaliação de gravidade (considerar_Poisoning Severity_<br>_Score_._Grading of Acute Poisoning_).|-<br>Comparação<br>entre escalas;<br>-<br>Não<br>utilização de<br>escalas.|- Mortalidade;<br>- Severidade;<br>- Incapacidade.|  
56  
**Quadro I.1.2 -** Perguntas PICO relativas à abordagem geral para o tratamento de pacientes com intoxicação aguda por agrotóxicos.  
|**Perguntas**<br>**População**|**Intervenção**|**Comparaçã**<br>**o**|**Desfecho**|
|---|---|---|---|
|1. Quais são as medidas que a<br>população geral deve tomar ante o<br>paciente<br>intoxicado<br>com<br>agrotóxicos?<br>(_Sem_<br>_busca_<br>_sistemática_)<br>Indivíduos potencialmente<br>expostos a agrotóxicos.|Medidas por leigos.|Não realizar|<br>- Mortalidade<br>- Gravidade<br>- Complicações|
|2. Qual é o tratamento inicial<br>hospitalar (profissionais da saúde)<br>para o paciente intoxicado com<br>agrotóxicos?<br>Indivíduos potencialmente<br>expostos a agrotóxicos.|- Abordagem geral do paciente intoxicado.<br>- Tratamento Sindromático||- Gravidade<br>- Mortalidade<br>- Tempo de Internação<br>- Incapacidade|
|3.<br>Quais<br>são<br>as<br>medidas<br>hospitalares de descontaminação<br>em<br>crianças<br>e<br>adultos<br>com<br>intoxicação aguda por agrotóxicos?<br>Indivíduos com intoxicação<br>por agrotóxicos.<br>Subgrupos:<br>- Tipos de agrotóxicos<br>- Crianças, idosos, grávidas<br>e adultos|- Descontaminação da pele;<br>- Descontaminação ocular;<br>- Descontaminação gastrointestinal:<br>- Indução do vômito;<br>- Lavagem gástrica;<br>- Carvão ativado;<br>- Irrigação intestinal total.|Ausência da<br>intervenção|- Gravidade<br>- Mortalidade<br>- Tempo de Internação<br>- Complicações<br>- Incapacidade|
|4. Quais são os métodos de<br>eliminação disponíveis para os<br>casos de intoxicação aguda por<br>agrotóxicos?<br>Indivíduos com intoxicação<br>por<br>agrotóxicos<br>Subgrupos:<br>- Tipos de agrotóxicos;<br>- Crianças, idosos, grávidas<br>e adultos.|- Doses múltiplas de carvão ativado;<br>- Diurese forçada;<br>- Alcalinização;<br>- Acidificação da urina;<br>- Diálise;<br>- Hemofiltração;<br>- Hemoperfusão;<br>- Plasmaferese;<br>- Exsanguineotransfusão.|Ausência da<br>intervenção|- Gravidade;<br>- Mortalidade;<br>- Tempo de Internação;<br>- Complicações;<br>- Incapacidade.|
|5. Qual deve ser o monitoramento<br>do<br>paciente<br>intoxicado<br>por<br>agrotóxicos?<br>(_Sem_<br>_busca_<br>_sistemática_)<br>Indivíduos com intoxicação<br>por agrotóxicos|- Tipo de monitoramento (observação, enfermaria,<br>UTI)<br>- Tempo de monitoramento|Pergunta de c|ontextualização|
|6.<br>Qual<br>deve<br>ser<br>o<br>acompanhamento, seguimento e<br>reabilitação dopaciente intoxicado<br>Indivíduos com história de<br>intoxicação por agrotóxicos|- Características do monitoramento.|Pergunta de c|ontextualização|  
57  
por agrotóxicos? ( _Sem busca sistemática_ <u>)</u>  
**<u>Quadro I.1.3 -</u>** Perguntas de pesquisa no formato “PICO” para questões de prevenção às intoxicações por agrotóxicos.  
|**Pergunta **|**População **|**Intervenção (fator de estudo) **|**Comparação **|**Desfecho **||
|---|---|---|---|---|---|
|1. Quais intervenções são efetivas<br>para reduzir a incidência de<br>intoxicações por agrotóxicos de<br>caráter suicida?|Indivíduos Subgrupos:<br>- Adolescentes;<br>- Adultos;|Intervenções para redução de tentativas de<br>suicídio com agrotóxicos;<br>Redução do acesso aos agrotóxicos.|Ausência da<br>intervenção|Incidência||
|2. Quais intervenções são efetivas<br>para reduzir a incidência de<br>intoxicações por agrotóxicos de<br>caráter ocupacional?|Indivíduos<br>expostos<br>a<br>agrotóxicos no ambiente de<br>trabalho.|- Políticas públicas e controle do uso de<br>agrotóxicos<br>- Redução do acesso e uso de agrotóxicos<br>- Fomento à produção agroecológica<br>- Possibilidade de emprego de produtos e<br>substâncias de toxicidade mais baixa<br>- Estímulo e capacitação para o uso de<br>equipamentos<br>de<br>proteção<br>individual<br>(agricultores autônomos, empregados)<br>- Capacitação sobre os efeitos dos agrotóxicos na<br>saúde humana e ambiental e o seu manuseio<br>- Programa de saúde do trabalhador|Ausência do<br>fator|Incidência||
|3. Quais intervenções são efetivas<br>para reduzir a incidência de<br>intoxicações por agrotóxicos de<br>caráter acidental?|Indivíduos potencialmente<br>expostos a agrotóxicos.<br>Subgrupos:<br>- Crianças<br>- Adultos|- Restrição de agrotóxicos altamente tóxicos;<br>- Redução de acesso;<br>- Atividades educativas.|Ausência do<br>fator|Incidência||
|4. Quais são as estratégias para<br>redução do risco de exposição por<br>consumo<br>de<br>alimentos<br>com<br>resíduos de agrotóxicos?|Indivíduos<br>potencial<br>expostos<br>a<br>agrotó<br>**_População geral_**<br>Indivíduos potencialmente<br>expostos a agrotóxicos.|mente<br>xicos<br>- Ausência do fator<br>- Lavagem;<br>- Cozimento;<br>- Descascamento.|Ausência do<br>fator|Resíduos<br>Agrotóxicos|de|  
58

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.2 – Diretrizes Existentes** -->
- **Diretriz 1:** Prevención, diagnóstico y tratamiento de intoxicaciones agudas en pediatria en el primer, segundo y tercer nivel de atención. México: Secretaría de Salud, 2014.  
- **Diretriz 2:** Tratamiento general de las intoxicaciones y envenenamientos en niños y adultos. México: Secretaría de Salud, 2014.  
- **Diretriz 3:** Clinical practice guideline for the prevention and treatment of sucidal behavior. Espanha: Galician Agency for Health Technology Assessment (AVALIA-T), 2012.  
- **Diretriz 4:** Guia de atención integral de salud ocupacional basada en la evidencia para trabajadores expuestos a plaguicidas inhibidores de la colinesterasa (organofosforados y carbamatos). Colômbia: Ministerio de la Protección Social, 2008.  
- **Diretriz 5:** Prevención primaria, diagnóstico precoz y tratamiento oportuno de la intoxicación aguda por agroquímicos en el primer nivel de atención. México: Secretaría de Salud, 2008.  
**<u>Quadro 1.</u>** Diretrizes cujo conteúdo corresponde às perguntas PICO para intoxicações por agrotóxicos.  
||**Cont**|**eúdo n**|**a diretr**|**iz**||
|---|---|---|---|---|---|
|**Pergunta**|**D1**|**D2**|**D3**|**D4**|**D5**|
|1. Quais aspectos devem ser considerados na anamnese para avaliar<br>exposiçõespotenciais a agrotóxicos?||||||
|2. Quais são as manifestações clínicas mais frequentes que permitem<br>suspeitar de uma intoxicação aguda ou crônicapor agrotóxicos?||||||
|3. Quais instrumentos ou ferramentas clínicas podem auxiliar no<br>diagnóstico de intoxicações crônicas a agrotóxicos? Quais exames<br>podem auxiliar no diagnóstico ante a suspeita de intoxicação aguda<br>por agrotóxicos?||||||
|4. Quais são os diagnósticos diferenciais de intoxicação aguda com<br>agrotóxicos?|<br>|||||
|5. Qual é a melhor escala para avaliar a gravidade da intoxicação?||||||
|6. Quais são as medidas que a população geral deve tomar ante o<br>paciente intoxicado com agrotóxicos?||||||
|7. Qual é o tratamento inicial hospitalar e/ou pré-hospitalar<br>(profissional da saúde) para o paciente com suspeita de intoxicação<br>por agrotóxicos?||||||
|8. Quais são as medidas hospitalares de descontaminação em crianças<br>e adultos com intoxicação agudapor agrotóxicos?||||||
|9. Quais são os métodos de eliminação disponíveis em intoxicação<br>agudapor agrotóxicos?||||||
|10. Qual deve ser o monitoramento do paciente intoxicado por<br>agrotóxicos?||||||
|11. Qual deve ser o acompanhamento, seguimento e reabilitação do<br>pacienteintoxicado poragrotóxicos?||||||
|12. Quais intervenções são efetivas para reduzir a incidência de<br>intoxicações por agrotóxicos de caráter suicida?||||||
|13. Quais intervenções são efetivas para reduzir a incidência de<br>intoxicações por agrotóxicos de caráter ocupacional?||||||
|14. Quais intervenções são efetivas para reduzir a incidência de<br>intoxicações por agrotóxicos de caráter acidental?||||||  
59  
15. Quais são as estratégias para redução do risco de exposição      por consumo de alimentos com resíduos de agrotóxicos?  
60  
**Tabela 1 –** Avaliação da **“Diretriz 1”,** pelo sistema de avaliação _Apraisal of Guidelines for Research & Evaluation_ II (AGREE II).  
||**Domínio 1.**<br>**Âmbito e**<br>**finalidade**|**Domí**<br>**Envolvim**<br>**partes int**|**nio 2.**<br>**ento das**<br>**eressadas**|**Dom**|**ínio**|**3. Rigo**|**r de**|**de**|**se**|**nv**|**olvi**|**mento**|**Domínio 4.**<br>**apresen**|**Clareza da**<br>**tação**|**Domínio**<br>**Aplicabili**|**5.**<br>**dade**||**Domín**<br>**Independ**<br>**editor**|**io 6.**<br>**ência**<br>**ial**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Item|1<br>2<br>3<br>Total|4<br>5|6<br>Total|7<br>8|9|10|11||12||13|14<br>Total|15<br>16|17<br>Total|18<br>19<br>20<br>|21<br>|Total|22<br>2|3<br>Total|**Avaliação glo**<br>**7**|**bal - 1 a**|
|Avaliador 1|7<br>7<br>7<br>21|4<br>1|7<br>12|6<br>7|4|6||4|6||7|<br>7<br>47|6<br>7|7<br>20|6<br>6<br>6|1|19|6|7<br>13|<br>Avaliador 1|6|
|Avaliador 2|7<br>7<br>6<br>20|6<br>1|6<br>13|7<br>7|5|6||6|7||5|<br>7<br>50|6<br>7|6<br>19|5<br>7<br>5|2|19|5|6<br>11|Avaliador 2|6|
|Avaliador 3|7<br>6<br>7<br>20|5<br>1|7<br>13|7<br>6|5|5||7|6||6|<br>7<br>49|6<br>7|7<br>20|4<br>7<br>2|1|14|6|6<br>12|Avaliador 3|6|
|Avaliador 4|7<br>7<br>7<br>21|5<br>1|7<br>13|7<br>6|4|7||2|7||6|<br>7<br>46|6<br>4|7<br>17|1<br>2<br>1|2|6|6|7<br>13|Avaliador 4|5|
|Avaliador 5|7<br>7<br>7<br>21|6<br>1|7<br>14|7<br>7|5|6||6|7||7|<br>7<br>52|6<br>6|7<br>19|3<br>5<br>5|1|14|4|7<br>49|Avaliador 5|6|
|Soma Avaliadores|103||65|||||||||244||95|||58||98|**Média**|**5,8 **|
|Valor máximo do domínio|<br>15||15|||||||||40||15|||20||10|||
|Valor mínimo do domínio|<br>105||105|||||||||280||105|||140||70|||
|**Nota final**|**0,98**|**0, **|**56**||||**0,85**||||||**0,8 **|**9**|**0,32**|||**1,47**||||  
#### **Tabela 2 –** Avaliação da **“Diretriz 2”,** pelo sistema de avaliação _Apraisal of Guidelines for Research & Evaluation_ II (AGREE II).  
||**Domí**<br>**Âmb**<br>**finali**|**nio 1.**<br>**ito e**<br>**dade**|**Domínio**<br>**Envolvimen**<br>**partes intere**|**2.**<br>**to das**<br>**ssadas**|**Domín**|**io 3**|**. Rigor**|**d**|**e d**|**esen**|**volvimen**|**to**|||**Domínio 4. C**<br>**apresent**|**lareza da**<br>**ação**|**Domí**<br>**Aplicab**|**nio 5.**<br>**ilidade**|**Domínio 6.**<br>**Independência**<br>**editorial**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Item|1<br>2<br>3|<br>Total|4<br>5<br>6|Total|7<br>8<br>9||10|1|1|12|<br>13<br>1|4<br>T|ot|al|15<br>16<br>1|7<br>Total|18<br>19<br>20|<br>21<br>Total|22<br>23<br>Total|||
|Avaliador 1|6<br>5<br>|5<br>16|5<br>1<br>4|10|6<br>7<br>|4|6||5|<br>6|<br>7|3||44|6<br>5|7<br>18|4<br>6<br>4|<br>1<br>15|6<br>7<br>13|**Avaliação glob**|**al - 1 a 7**|
|Avaliador 2|7<br>7<br>|5<br>19|5<br>1<br>7|13|7<br>7<br>|5|6||7|<br>7|<br>5|5||49|6<br>6|7<br>19|5<br>7<br>3|<br>1<br>16|6<br>5<br>11|Avaliador 1|5|
|Avaliador 3|6<br>6<br>|6<br>18|5<br>1<br>7|13|6<br>7<br>|5|5||7|<br>6|<br>4|5||45|6<br>5|7<br>18|4<br>7<br>2|<br>1<br>14|7<br>6<br>13|Avaliador 2|5|
|Avaliador 4|7<br>7<br>|7<br>21|5<br>1<br>7|13|7<br>7<br>|4|6||2|<br>6|<br>5|7||44|5<br>6|7<br>18|3<br>6<br>2|<br>1<br>12|6<br>7<br>13|Avaliador 3|5|
|Avaliador 5|7<br>7<br>|7<br>21|5<br>1<br>7|13|7<br>7<br>|4|6||7|<br>7|<br>6|7||51|6<br>5|7<br>18|2<br>6<br>3|<br>1<br>12|4<br>7<br>11|Avaliador 4|5|
|Soma Avaliadores||95||62|||||||||2|33||91||69|<br>61|Avaliador 5|6|
|Valor máximo do domínio||15||15||||||||||40||15||20|<br>10|**Média**|**5,2 **|
|Valor mínimo do domínio||105||105|||||||||2|80||105||140|<br>70|||
|**Nota final**|**0, **|**89**|**0,52**|||||**0,8 **|**0**||||||**0,84**||**0,4 **|**1**|**0,85**|||  
78  
**Tabela 3 –** Avaliação da **“Diretriz 3”,** pelo sistema de avaliação _Apraisal of Guidelines for Research & Evaluation_ II (AGREE II).  
||**Domínio 1. Âmbito**<br>**e finalidade**|**Domínio**<br>**Envolvimen**<br>**partes intere**|**2.**<br>**to d**<br>**ssad**|**as**<br>**as**|**Domínio**|**3. Rigor de d**|**esenvolviment**|**o**|||**Domínio 4. Cl**<br>**apresenta**|**areza da**<br>**ção**|**Domínio 5.**<br>**Aplicabilidade**|**Domínio 6.**<br>**Independência**<br>**editorial**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Item|1<br>2<br>3<br>Total|4<br>5<br>6|Tot|al|7<br>8<br>9|10<br>11|12<br>13<br>1|4<br>T|ota|l|15<br>16<br>1|7<br>Total|18<br>19<br>20<br>21<br>Total|22<br>23<br>Total|||
|Avaliador 1|7<br>7<br>6<br>20|7 5<br>7||19|6<br>3<br>3|6<br>6|6<br>7<br>|3|4|0|6<br>5<br>|6<br>17|2<br>6<br>4<br>1<br>13|5<br>7<br>12|**Avaliaçãoglob**|**al - 1 a 7**|
|Avaliador 2|6<br>7<br>7<br>20|6 6<br>6||18|7<br>6<br>5|5<br>6|6<br>7<br>|4|4|6|6<br>6<br>|7<br>19|5<br>7<br>3<br>1<br>16|1<br>7<br>8|Avaliador 1|5|
|Avaliador 3|0|||0||||||0||0|0|0|Avaliador 2||
|Avaliador 4|7<br>7<br>6<br>20|6 3<br>6||15|7<br>6<br>5|4<br>4|6<br>7<br>|7|4|6|5<br>6<br>|7<br>18|3<br>7<br>1<br>2<br>13|7<br>7<br>14|Avaliador 3||
|Avaliador 5|7<br>7<br>7<br>21|6 7<br>7||20|6<br>6<br>4|6<br>6|7<br>7<br>|1|4|3|6<br>6<br>|7<br>19|3<br>7<br>5<br>1<br>16|1<br>7<br>8|Avaliador 4|5,5|
|Soma Avaliadores|81|||72|||||17|5||73|<br>58|<br>42|Avaliador 5|6|
|Valor máximo do domínio|<br>15|||15|||||4|0||15|<br>20|<br>10|**Média**|**5,5 **|
|Valor mínimo do domínio|<br>105||1|05|||||28|0||105|<br>140|<br>70|||
|**Nota final**|**0,73**|**0,63**||||**0,56**|||||**0,64**||**0,32**|**0,53**|||  
**Tabela 4 –** Avaliação da **“Diretriz 4”,** pelo sistema de avaliação _Apraisal of Guidelines for Research & Evaluation_ II (AGREE II).  
||**Domínio 1. Âmbito**<br>**e finalidade**|**Domí**<br>**Envolvim**<br>**partes int**|**nio 2**<br>**ento**<br>**eress**|**.**<br>**das**<br>**adas**|**Domín**|**io**|**3.**|**Rigor**|**d**|**e d**|**esen**|**volvim**|**ento**||**Domínio 4.**<br>**aprese**|**C**<br>**nt**|**lar**<br>**aç**|**eza**<br>**ão**|**da**|<br>**Do**<br>**Aplic**|**míni**<br>**abili**|**o 5.**<br>**dad**|**e**|**Domínio 6.**<br>**Independência**<br>**editorial**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Item|1<br>2<br>3<br>Total|4<br>5<br>6|<br>|Total|7<br>8<br>9||10|<br>|11||12|13|14<br>To|tal|<br>15<br>16|1|7|Tot|al|<br>18<br>19<br>|20<br>|21<br>|Total|22<br>23<br>Total|||
||||||||||||||||||||||||||**Avaliação glo**|**bal - 1 a**|
|Avaliador 1|6<br>6<br>7<br>19|6 4|6|16|6<br>6<br>|4||6||5|6|<br>6|<br>7|4|6<br>6<br>4||7||17|<br>5<br>5|4|6|20|6<br>7<br>13|<br>**7**||
|Avaliador 2|6<br>6<br>6<br>18|5 4|7|16|6<br>5<br>|5||6||3|6|<br>7|<br>6|4|4<br>4<br>6||7||17|<br>3<br>4|3|5|15|6<br>6<br>12|Avaliador 1|6|
|Avaliador 3|6<br>6<br>7<br>19|6 3|7|16|6<br>6<br>|5||6||5|7|<br>7|<br>6|4|8<br>5<br>4||7||16|<br>3<br>5|4|5|17|6<br>6<br>12|Avaliador 2|6|
|Avaliador 4|7<br>6<br>7<br>20|6 4|7|17|7<br>7<br>|5||7||6|7|<br>7|<br>6|5|2<br>4<br>4||7||15|<br>3<br>4|4|4|15|5<br>7<br>12|Avaliador 3|6|
|Avaliador 5|7<br>7<br>7<br>21|6 5|7|18|6<br>6<br>|6||6||6|6|<br>6|<br>6|4|8<br>6<br>7||7||20|<br>6<br>6|6|3|21|4<br>7<br>11|Avaliador 4|5|
|Soma Avaliadores|97|||83||||||||||23|8||||85||||88|<br>60|Avaliador 5|6|  
79  
|Valor máximo do domínio|15|15||40|15|20|10|**Média**<br>**5,8 **|
|---|---|---|---|---|---|---|---|---|
|Valor mínimo do domínio|105|105||280|105|140|70||
|**Nota final**|**0,91**|**0,76**|**0,83**||**0,78**|**0,57**|**0,83**||  
**Tabela 5 –** Avaliação da **“Diretriz 5”,** pelo sistema de avaliação _Apraisal of Guidelines for Research & Evaluation_ II (AGREE II).  
||**Domínio 1.**<br>**e finalid**|**Âmbito**<br>**ade**|**Domí**<br>**Envolvim**<br>**partes int**|**nio 2.**<br>**ento das**<br>**eressadas**|**Domínio**|**3. R**|**igor**|**de d**|**esen**|**volvimen**|**to**|**Domínio 4.**<br>**aprese**|**C**<br>**nt**|**lar**<br>**aç**|**eza**<br>**ão**|**da**||**Domíni**<br>**Aplicabil**|**o 5.**<br>**idade**|**Domín**<br>**Indepen**<br>**edito**|**io 6.**<br>**dência**<br>**rial **|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Item|1<br>2<br>3|<br>Total|4<br>5<br>|6<br>Total|7<br>8<br>9|10|<br>|11|12|13<br>1|4<br>Total|15<br>16|1|7|To|tal|<br>18|<br>19<br>20<br>|21<br>Total|22<br>23<br>|Total|||
|Avaliador 1|6<br>5<br>|5<br>16|5<br>1|7<br>13|6<br>3<br>4||6|2|6|<br>7|1<br>35|6<br>4||6||16|<br>2|<br>2<br>2|1<br>7|6<br>5|11|**Avaliação glo**<br>**7**|**bal - 1 a**|
|Avaliador 2|7<br>6<br>|5<br>18|6<br>1|7<br>14|5<br>4<br>4||6|4|5|<br>7|1<br>36|5<br>4||3||12|<br>2|<br>2<br>2|1<br>7|6<br>5|11|Avaliador 1|5|
|Avaliador 3|7<br>6<br>|5<br>18|6<br>1|7<br>14|6<br>4<br>3||6|6|7|<br>7|3<br>42|7<br>5||2||14|<br>3|<br>3<br>2|1<br>9|6<br>6|12|Avaliador 2|5|
|Avaliador 4|7<br>7<br>|7<br>21|5<br>1|7<br>13|5<br>4<br>3||5|4|6|<br>4|1<br>32|6<br>6||6||18|<br>4|<br>3<br>2|1<br>10|5<br>7|12|Avaliador 3|5|
|Avaliador 5|7<br>7<br>|7<br>21|6<br>1|7<br>14|7<br>7<br>1||6|6|7|<br>6|5<br>45|7<br>6||6||19|4|<br>3<br>3|1<br>11|5<br>7|46|Avaliador 4|5|
|Soma Avaliadores||94||68|||||||190|||||79|||44||92|Avaliador 5|6|
|Valor máximo do domínio||15||15|||||||40|||||15|||20||10|**Média**|**5,2 **|
|Valor mínimo do domínio||105||105|||||||280||||1|05|||140||70|||
|**Nota final**|**0,88**||**0,5 **|**9**||||**0,63**||||**0, **|**71**|||||**0,20**||**1,3 **|**7**|||  
80

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.3 - Estratégias de Busca** -->
**Após a busca exploratória sobre o diagnóstico geral das intoxicações por agrotóxicos, optou-se por não utilizar a revisão sistemática como metodologia para esse item porque as recomendações que são aplicáveis a todos os tipos de agrotóxicos são em grande maioria pontos de boa prática. Porém, a busca sistemática será realizada para diagnóstico nos capítulos posteriores desta diretriz, tendo em vista a especificidade do tema nos grupos priorizados.**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.3 - Estratégias de Busca** -->
**Quadro I.3.2.1 - Estratégia de busca e associação de termos MeSH, no site de buscas PubMed, para a abordagem geral no tratamento de intoxicações por agrotóxicos.**  
**Quadro I.3.2.2 - Termos de busca MeSH e termos livres, para cada bloco conceitual, utilizados no site Cochrane Library, no idioma inglês, para a abordagem geral no tratamento de intoxicações por agrotóxicos.**  
**Quadro I.3.2.3 - Termos de busca DeCS e termos livres, para cada bloco conceitual, utilizados no site Lilacs/BVS no idioma português para a abordagem geral no tratamento de intoxicações por agrotóxicos.**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.3 - Estratégias de Busca** -->
**Quadro I.3.3.1.** Estratégia de busca e associação de palavras-chave, no **PubMed** , para as perguntas PICO de Prevenção.  
**Quadro I.3.3.2.** Estratégia de busca e associação de palavras-chave, para o **Cochrane Library** , para as perguntas PICO de Prevenção.  
**Quadro I.3.3.3.** Estratégia de busca e associação de palavras-chave, para **Lilacs/BVS** , para as perguntas PICO de Prevenção.  
81  
**ANEXO I.3.2 – TRATAMENTO**  
**Quadro I.3.2.1 - Estratégia de busca e associação de termos MeSH, no site de buscas PubMed, com o respectivo número de publicações resultantes da busca.**  
|**Pergunta**|**Bloco conceitual**||**Termos**||**Estratégia**|**Pubmed**|
|---|---|---|---|---|---|---|
||||**Inglê**|**s**|||
|1. Qual é o tratamento inicial<br>para o paciente intoxicado|Tratamento<br>de<br>envenenamento|Therapeutics,<br>Treatment, Po|Therapy,<br>isoning, Agr|Emergency<br>ochemicals,|("Therapeutics"[Mesh]<br>OR<br>"therapy"[Subheading]<br>OR<br>"Emergency Treatment"[Mesh]) AND ("Poisoning"[Mesh]||
|com agrotóxicos?|por agrotóxicos|Pesticides|||OR<br>"poisoning"[Subheading])<br>AND<br>("Agrochemicals"[Mesh] OR "Pesticides"[Mesh]) AND<br>(systematic[sb] OR Clinical Study[ptyp] OR Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp] OR Randomized<br>Controlled Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"2016/05/31"[PDAT]) AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|30<br>(Busca 1a)|
|||Therapeutics,<br>Treatment,<br>Oximes, Diph|Therapy,<br>Poisoning,<br>enhydramine|Emergency<br>Atropine,|("Therapeutics"[Mesh]<br>OR<br>"therapy"[Subheading]<br>OR<br>"Emergency Treatment"[Mesh]) AND ("Poisoning"[Mesh]<br>OR "poisoning"[Subheading]) AND ("Atropine"[Mesh] OR<br>"Oximes"[Mesh] OR "Diphenhydramine"[Mesh]) AND<br>(systematic[sb] OR Clinical Study[ptyp] OR Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp] OR Randomized|15<br>(Busca 1b)|  
82  
|||||Controlled Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"2016/05/31"[PDAT]) AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|<br>|
|---|---|---|---|---|---|
|3.<br>Qual<br>deve<br>ser<br>a<br>abordagem<br>pré-hospitalar<br>ante<br>um<br>paciente<br>com<br>suspeita de intoxicação por<br>agrotóxicos?<br>(Profissional<br>de saúde)|Tratamento<br>emergencial/<br>ambulatorial em<br>casos<br>de<br>envenenamento<br>por agrotóxicos|Emergencies, Emergency<br>Emergency<br>Medical<br> <br>Critical Care, Ambulances,<br>care, Health personnel,<br>Agrochemicals, Pesticides|Treatment,<br>Technicians,<br>Ambulatory<br>Poisoning,|("Emergencies"[Mesh] OR "Emergency Treatment"[Mesh]<br>OR "Emergency Medical Technicians"[Mesh] OR "Critical<br>Care"[Mesh] OR "Ambulances"[Mesh] OR "Ambulatory<br>Care"[Mesh]<br>OR<br>"Health<br>Personnel"[Mesh])<br>AND<br>("Poisoning"[Mesh] OR "poisoning"[Subheading]) AND<br>("Agrochemicals"[Mesh] OR "Pesticides"[Mesh]) AND<br>(systematic[sb] OR Clinical Study[ptyp] OR Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp] OR Randomized<br>Controlled Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"2016/05/31"[PDAT]) AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br>4<br>(Busca 3a)|  
83  
|4. Quais são as me|didas|<br>Métodos<br>de|Therapeutics,|Therapy,|("Therapeutics"[Mesh] OR "therapy"[Subheading]) AND||
|---|---|---|---|---|---|---|
|hospitalares|de|<br>descontaminação|Decontamination,|Poisoning,|("Decontamination/methods"[Mesh]<br>OR||
|descontaminação<br>crianças<br>e<br>adultos<br>intoxicação<br>aguda<br>agrotóxicos?|em<br>com<br>por|<br> <br> <br>em<br>casos<br>de<br>intoxicação<br>aguda<br>por<br>agrotóxicos|Agrochemicals, Pesticides||"Decontamination/therapy"[Mesh])<br>AND<br>("Poisoning"[Mesh] OR "poisoning"[Subheading]) AND<br>("Agrochemicals"[Mesh] OR "Pesticides"[Mesh]) AND<br>(systematic[sb] OR Clinical Study[ptyp] OR Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp] OR Randomized<br>Controlled Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"2016/05/31"[PDAT]) AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|<br>0<br>(Busca 4a)|
||||Poisoning, Agrochemicals,<br>Charcoal,<br>Gastric<br>lavage<br>Cathartics, Fuller’s Earth|Pesticides,<br>,<br>Ipecac,|("Poisoning"[Mesh] OR "poisoning"[Subheading]) AND<br>("Agrochemicals"[Mesh] OR "Pesticides"[Mesh]) AND<br>("Charcoal"[Mesh]<br>OR<br>"Gastric<br>Lavage"[Mesh]<br>OR<br>"Ipecac"[Mesh]<br>OR<br>"Cathartics"[Mesh]<br>OR<br>"Fuller's<br>Earth"[Supplementary Concept]) AND (systematic[sb] OR<br>Clinical Study[ptyp] OR Clinical Trial[ptyp] OR Meta-<br>Analysis[ptyp] OR Randomized Controlled Trial[ptyp]) AND<br>("2010/01/01"[PDAT]<br>:<br>"2016/05/31"[PDAT])<br>AND<br>"humans"[MeSH<br>Terms]<br>AND<br>(English[lang]<br>OR<br>Portuguese[lang] OR Spanish[lang])|<br> <br>3<br>(Busca 4b)|  
84  
||||Poisoning, Charcoal, Gastric lavage,<br>Ipecac, Cathartics, Fuller’s Earth|("Poisoning"[Mesh] OR "poisoning"[Subheading]) AND<br>("Charcoal"[Mesh]<br>OR<br>"Gastric<br>Lavage"[Mesh]<br>OR<br>"Ipecac"[Mesh]<br>OR<br>"Cathartics"[Mesh]<br>OR<br>"Fuller's<br>Earth"[Supplementary Concept]) AND (systematic[sb] OR<br>Clinical Study[ptyp] OR Clinical Trial[ptyp] OR Meta-<br>Analysis[ptyp] OR Randomized Controlled Trial[ptyp]) AND<br>("2010/01/01"[PDAT]<br>:<br>"2016/05/31"[PDAT])<br>AND<br>"humans"[MeSH<br>Terms]<br>AND<br>(English[lang]<br>OR<br>Portuguese[lang] OR Spanish[lang])|<br> <br> <br> <br> <br> <br> <br>13<br>(Busca 4c)|
|---|---|---|---|---|---|
|5. Quais são os métodos de<br>eliminação disponíveis em<br>intoxicação<br>aguda<br>por<br>agrotóxicos?|Métodos<br>eliminação<br>casos<br>intoxicação<br>aguda<br>agrotóxicos|de<br>em<br>de<br>por|Therapeutics,<br>Therapy,<br>Renal<br>elimination,<br>Intestinal<br>elimination,<br>Hepatobiliary<br>elimination,<br>Pharmacokinetics,<br>Poisoning,<br>Agrochemicals, Pesticides|("Therapeutics"[Mesh] OR "therapy"[Subheading]) AND<br>("Renal<br>Elimination"[Mesh]<br>OR<br>"Intestinal<br>Elimination"[Mesh] OR "Hepatobiliary Elimination"[Mesh]<br>OR<br>"Pharmacokinetics"[Mesh]<br>OR<br>"pharmacokinetics"[Subheading]) AND ("Poisoning"[Mesh]<br>OR<br>"poisoning"[Subheading])<br>AND<br>("Agrochemicals"[Mesh] OR "Pesticides"[Mesh]) AND<br>(systematic[sb] OR Clinical Study[ptyp] OR Clinical<br>Trial[ptyp] OR Meta-Analysis[ptyp] OR Randomized<br>Controlled Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"2016/05/31"[PDAT]) AND "humans"[MeSH Terms] AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|<br> <br> <br> <br> <br> <br> <br> <br> <br> <br> <br>2<br>(Busca 5a)|  
85  
|Therapeutics,<br>|Therapy,<br>Poisoning,|("Therapeut|ics"[Mesh] OR "therapy"[Subheading]) AND||
|---|---|---|---|---|
|Agrochemicals,|Pesticides, Charcoal,|("Poisoning|"[Mesh] OR "poisoning"[Subheading]) AND||
|Diuresis, Urine,|Sodium bicarbonate,|("Agrochem|icals"[Mesh] OR "Pesticides"[Mesh]) AND||
|Dialysis, Renal d|ialysis (Hemodialysis,|("Charcoal"|[Mesh]<br>OR<br>"Diuresis"[Mesh]<br>OR||
|Peritoneal|dialysis,<br>and|"urine"[Sub|heading] OR "Sodium Bicarbonate"[Mesh] OR||
|Hemodiafiltration|),<br>Hemoperfusion,|"sodium|bicarbonate,<br>sodium<br>carbonate<br>drug||
|Hemofiltration,|Plasmapheresis,|combination|"[Supplementary Concept] OR "Dialysis"[Mesh]|6|
|Exchange Transf|usion Whole Blood|OR "Renal<br>"Hemofiltra|Dialysis"[Mesh] OR "Hemoperfusion"[Mesh] OR<br>tion"[Mesh] OR "Plasmapheresis"[Mesh] OR|(Busca 5b)|
|||"Exchange<br>(systematic[|Transfusion,<br>Whole<br>Blood"[Mesh])<br>AND<br>sb] OR Clinical Study[ptyp] OR Clinical||
|||Trial[ptyp]<br>Controlled<br>"2016/05/31<br>(English[lan|OR Meta-Analysis[ptyp] OR Randomized<br>Trial[ptyp]) AND ("2010/01/01"[PDAT] :<br>"[PDAT]) AND "humans"[MeSH Terms] AND<br>g] OR Portuguese[lang] OR Spanish[lang])||  
Filtros aplicados: período (01/01/2010 a 31/05/2016), idioma (inglês, português e espanhol), espécie ( _humans_ ) e tipos de estudos ( _systematic, clinical study, clinical trial, meta-analysis, randomized controlled trial_ ).  
Fonte: elaboração própria.  
**Quadro I.3.2.2 - Termos de busca MeSH e termos livres, para cada bloco conceitual, utilizados no site Cochrane Library, no idioma inglês, para a abordagem geral no tratamento de intoxicações por agrotóxicos.**  
86  
|**Pergunta**|**Bloco conceitual**|**Termos**|**Estratégia**<br>|**Cochrane**|
|---|---|---|---|---|
|||**Inglês**|||
|1. Qual é o tratamento inicial<br>para o paciente intoxicado<br>com agrotóxicos?|Tratamento<br>de<br>envenenamento<br>por agrotóxicos|Therapeutics,<br>Therapy,<br>Emergency<br>Treatment, Poisoning, Agrochemicals,<br>Pesticides|("Therapeutics" OR "Therapy" OR "Emergency Treatment")<br>AND ("Poisoning") AND ("Agrochemicals" OR "Pesticides")|3|
|||Agrochemicals, Pesticides, Atropine,<br>Oximes, Diphenhydramine|("Agrochemicals" OR "Pesticides") AND (“Atropine” OR<br>“Oximes” OR “Diphenhydramine”)|1|
|3.<br>Qual<br>deve<br>ser<br>a|Tratamento|Therapeutics, Therapy, Emergencies,|("Therapeutics" OR "Therapy") AND ("Emergencies" OR||
|abordagem<br>pré-hospitalar<br>ante<br>um<br>paciente<br>com<br>suspeita de intoxicação por<br>agrotóxicos?<br>(Profissional<br>de saúde)|emergencial/<br>ambulatorial em<br>casos<br>de<br>envenenamento<br>por agrotóxicos|Emergency<br>Treatment,<br>Emergency<br>Medical Technicians, Critical Care,<br>Ambulances, Ambulatory care, Health<br>personnel, Poisoning, Agrochemicals,<br>Pesticides|"Emergency<br>Treatment"<br>OR<br>"Emergency<br>Medical<br>Technicians" OR "Critical Care" OR "Ambulances" OR<br>"Ambulatory<br>Care"<br>OR<br>"Health<br>Personnel")<br>AND<br>("Poisoning") AND ("Agrochemicals" OR "Pesticides")|0|
|4. Quais são as medidas|Métodos<br>de|Decontamination,<br>Poisoning,|("Decontamination”)<br>AND<br>("Poisoning")<br>AND||
|hospitalares<br>de|descontaminação|Agrochemicals, Pesticides|("Agrochemicals" OR "Pesticides")|0|
|descontaminação<br>em|em<br>casos<br>de||||
|crianças<br>e<br>adultos<br>com|intoxicação||||
|intoxicação<br>aguda<br>por<br>agrotóxicos?|aguda<br>por<br>agrotóxicos|Poisoning, Agrochemicals, Pesticides,<br>Charcoal,<br>Gastric<br>lavage,<br>Ipecac,<br>Cathartics, Fuller’s Earth|("Poisoning") OR ("Agrochemicals" OR "Pesticides") AND<br>("Charcoal" OR "Gastric Lavage" OR "Ipecac" OR<br>"Cathartics" OR "Fuller's Earth")|16|  
87  
|5. Quais são os métodos de|Métodos<br>de|Therapeutics,|Therapy,<br>_Elimination_,|("Therapeutics" OR "Therapy") AND ("Elimination”) AND|<br>|
|---|---|---|---|---|---|
|eliminação disponíveis em|eliminação<br>em|Poisoning, Ag|rochemicals, Pesticides|("Poisoning") AND ("Agrochemicals" OR "Pesticides")|0|
|intoxicação<br>aguda<br>por<br>agrotóxicos?<br>Filtros aplicados: período<br>Fonte: elaboração própri<br>**Quadro I.3.2.3 - Termos de busc**<br>**intoxicações por agrotóxicos.**|casos<br>de<br>intoxicação<br>aguda<br>por<br>agrotóxicos<br>(01/01/2010 a 31/0<br>a.<br>**a DeCS e termos livre**|Charcoal, D<br>bicarbonate,<br>Hemofiltration<br>Plasmapheresi<br>Whole<br>Agrochemical<br>5/2016), idiom<br>**s, para cada blo**|iuresis, Urine, Sodium<br>Dialysis, Hemodialysis,<br>,<br>Hemoperfusion,<br>s, Exchange Transfusion<br>Blood,<br>Poisoning,<br>s, Pesticides<br>a (inglês, português e espa<br>**co conceitual, utilizados no sit**|("Charcoal" OR "Diuresis" OR "Urine" OR "Sodium<br>Bicarbonate" OR "Dialysis" OR “Hemodialysis” OR<br>"Hemoperfusion" OR "Hemofiltration" OR "Plasmapheresis"<br>OR<br>"Exchange<br>Transfusion,<br>Whole<br>Blood")<br>AND<br>("Poisoning" OR "Agrochemicals" OR "Pesticides")<br>nhol).<br>**e Lilacs/BVS no idioma português para a abordagem geral no tratam**|<br> <br> <br> <br>2<br>**ento de**|
|**Pergunta**|**Bloco conceitual**||**Termos**<sup>a</sup>|**Estratégia**<sup>b</sup>|**Lilacs/BVS**|
||||**Português**|||
|1. Qual é o tratamento inicial<br>para o paciente intoxicado<br>com agrotóxicos?|Tratamento<br>de<br>envenenamento<br>por agrotóxicos|Terapêutica,<br>Tratamento<br>Emergências,<br>_Intoxicação_,|_Tratamento_,<br>_Terapia_,<br>de<br>Emergência,<br>Envenenamento,<br>_Intoxicações_,|((tw:(terapêutica)) OR (tw:(tratamento)) OR (tw:(terapia))<br>OR (tw:(tratamento de emergência)) OR (tw:(emergências)))<br>AND ((tw:(envenenamento)) OR (tw:(intoxicação)) OR<br>(tw:(intoxicações)))<br>AND<br>((tw:(agroquímicos))<br>OR|<br> <br> <br> <br>1<br>(Busca 1a)|  
88  
|||Agroquímicos<br>_Agroquímicos,_|,_Agrotóxico, Produtos_<br>_Defensivo Agrícola_|(tw:(agrotóxico)) OR (tw:(produtos agroquímicos)) OR<br>(tw:(defensivo agrícola)))||
|---|---|---|---|---|---|
|||Envenenamen<br>_Intoxicações_,<br>Difenidramina|to,<br>_Intoxicação_,<br>Atropina¸Oximas,<br>|((tw:(envenenamento))<br>OR<br>(tw:(intoxicação))<br>OR<br>(tw:(intoxicações))) AND ((tw:(atropina)) OR (tw:(oximas))<br>OR (tw:(difenidramina)))|6<br>(Busca 1b)|
|3.<br>Qual<br>deve<br>ser<br>a<br>abordagem<br>pré-hospitalar|Tratamento<br>emergencial/|Tratamento<br>Emergências,|de<br>Emergência,<br>Serviços Médicos de|((tw:(Tratamento de emergência)) OR (tw:(Emergências))<br>OR (tw:(Serviços Médicos de Emergência)) OR (tw:(pronto-||
|ante<br>um<br>paciente<br>com<br>suspeita de intoxicação por<br>agrotóxicos?<br>(Profissional<br>de saúde)|ambulatorial em<br>casos<br>de<br>envenenamento<br>por agrotóxicos|Emergência,<br>_Atendimento p_<br>de Emergênci<br>de saúde, A<br>Ambulatorial,|_Pronto-socorro_,_SAMU_,<br>_ré-hospitalar_, Auxiliares<br>a,_Paramédicos_, Pessoal<br>mbulâncias, Assistência<br> <br>Cuidados<br>críticos,|socorro)) OR (tw:(SAMU)) OR (tw:(atendimento pré-<br>hospitalar)) OR (tw:(Auxiliares de emergência)) OR<br>(tw:(paramédicos)) OR (tw:(Pessoal de saúde)) OR<br>(tw:(ambulâncias)) OR (tw:(assistência ambulatorial)) OR<br>(tw:(cuidados críticos))) AND ((tw:(Envenenamento)) OR|0<br>(Busca 3a)|
|||Envenenamen<br>_Intoxicações_,<br>_Agrotóxico,_<br>_Defensivo Agr_|to,<br>_Intoxicação_,<br>Agroquímicos,<br>_Produtos Agroquímicos,_<br>_ícola_|(tw:(Intoxicação))<br>OR<br>(tw:(Intoxicações)))<br>AND<br>((tw:(Agroquímicos))<br>OR<br>(tw:(Agrotóxico))<br>OR<br>(tw:(Produtos agroquímicos)) OR (tw:(Defensivo agrícola)))||
|||Terapêutica,|_Tratamento_,<br>_Terapia_,|((tw:(terapêutica)) OR (tw:(tratamento)) OR (tw:(terapia)))||
|||Tratamento|de<br>Emergência,|AND<br>((tw:(Tratamento<br>de<br>emergência))<br>OR|99|
|||Emergências,<br>Emergência,|Serviços Médicos de<br>_Pronto-socorro_,_SAMU_,|(tw:(Emergências))<br>OR<br>(tw:(Serviços<br>Médicos<br>de<br>Emergência)) OR (tw:(pronto-socorro)) OR (tw:(SAMU))|(Busca 3b)|  
89  
|||_Atendimento pré-hospitalar_, Auxiliares<br>de Emergência,_Paramédicos_, Pessoal<br>de saúde, Ambulâncias, Assistência<br>Ambulatorial,<br>Cuidados<br>críticos,<br>Envenenamento,<br>_Intoxicação_,<br>_Intoxicações_,<br>Agroquímicos,<br>_Agrotóxico, Produtos Agroquímicos,_<br>_Defensivo Agrícola_|OR (tw:(atendimento pré-hospitalar)) OR (tw:(Auxiliares de<br>emergência)) OR (tw:(paramédicos)) OR (tw:(Pessoal de<br>saúde))<br>OR<br>(tw:(ambulâncias))<br>OR<br>(tw:(assistência<br>ambulatorial))<br>OR<br>(tw:(cuidados<br>críticos)))<br>AND<br>(((tw:(Envenenamento))<br>OR<br>(tw:(Intoxicação))<br>OR<br>(tw:(Intoxicações)))<br>OR<br>((tw:(Agroquímicos))<br>OR<br>(tw:(Agrotóxico)) OR (tw:(Produtos agroquímicos)) OR<br>(tw:(Defensivo agrícola))))||
|---|---|---|---|---|
|4. Quais são as medidas<br>hospitalares<br>de<br>descontaminação<br>em<br>crianças<br>e<br>adultos<br>com|Métodos<br>de<br>descontaminação<br>em<br>casos<br>de<br>intoxicação|Descontaminação,<br>Envenenamento,<br>_Intoxicação_,<br>_Intoxicações_,<br>Agroquímicos,_Agrotóxico, Produtos_<br>_Agroquímicos, Defensivo Agrícola_|((tw:(descontaminação))) AND ((tw:(envenenamento)) OR<br>(tw:(intoxicação))<br>OR<br>(tw:(intoxicações)))<br>AND<br>((tw:(agroquímicos)) OR (tw:(agrotóxico)) OR (tw:(produtos<br>agroquímicos)) OR (tw:(defensivo agrícola)))|0<br>(Busca 4a)|
|intoxicação<br>aguda<br>por<br>agrotóxicos?|aguda<br>por<br>agrotóxicos|Descontaminação,<br>Envenenamento,<br>_Intoxicação_,_Intoxicações_|((tw:(descontaminação))) AND ((tw:(envenenamento)) OR<br>(tw:(intoxicação)) OR (tw:(intoxicações)))|2<br>(Busca 4b)|
|||Envenenamento,<br>_Intoxicação_,<br>_Intoxicações_,<br>Agroquímicos,<br>_Agrotóxico, Produtos Agroquímicos,_<br>_Defensivo Agrícola,_Carvão Vegetal_,_<br>_Carvão, Carvão ativado,_Lavagem<br>gástrica,_Irrigação gástrica,_Ipeca,|(((tw:(envenenamento))<br>OR<br>(tw:(intoxicação))<br>OR<br>(tw:(intoxicações)))<br>OR<br>((tw:(agroquímicos))<br>OR<br>(tw:(agrotóxico)) OR (tw:(produtos agroquímicos)) OR<br>(tw:(defensivo agrícola)))) AND ((tw:(carvão vegetal)) OR<br>(tw:(carvão)) OR (tw:(carvão ativado)) OR (tw:(lavagem<br>gástrica)) OR (tw:(irrigação gástrica)) OR (tw:(ipeca)) OR|26<br>(Busca 4c)|  
90  
|||_Ipecacuanha,_<br>Catárticos,<br>_Purgante,_<br>_Terra de Fuller_|(tw:(ipecacuanha)) OR (tw:(catárticos)) OR (tw:(purgante))<br>OR (tw:(terra de fuller)))||
|---|---|---|---|---|
|5. Quais são os métodos de<br>eliminação disponíveis em<br>intoxicação<br>aguda<br>por<br>agrotóxicos?|Métodos<br>de<br>eliminação<br>em<br>casos<br>de<br>intoxicação<br>aguda<br>por<br>agrotóxicos|Eliminação<br>Renal,<br>Eliminação<br>intestinal,<br>Eliminação<br>hepatobiliar,<br>_Eliminação_,<br>Envenenamento,<br>_Intoxicação_,<br>_Intoxicações_,<br>Agroquímicos,_Agrotóxico, Produtos_<br>_Agroquímicos, Defensivo Agrícola_|((tw:(eliminação renal)) OR (tw:(eliminação intestinal)) OR<br>(tw:(eliminação hepatobiliar)) OR (tw:(eliminação))) AND<br>((tw:(envenenamento))<br>OR<br>(tw:(intoxicação))<br>OR<br>(tw:(intoxicações)))<br>AND<br>((tw:(agroquímicos))<br>OR<br>(tw:(agrotóxico)) OR (tw:(produtos agroquímicos)) OR<br>(tw:(defensivo agrícola)))|0<br>(Busca 5a)|
|||Envenenamento,<br>_Intoxicação_,<br>_Intoxicações_,<br>Agroquímicos,<br>_Agrotóxico, Produtos Agroquímicos,_<br>_Defensivo Agrícola,_Carvão Vegetal_,_<br>_Carvão,_<br>_Carvão_<br>_ativado,_<br>Diurese,<br>Urina, Bicarbonato de sódio, Diálise,<br>Diálise<br>renal,<br>_Hemodiálise_,<br>Hemoperfusão,<br>Hemofiltração,<br>Plasmaferese, Transfusão total|(((tw:(envenenamento))<br>OR<br>(tw:(intoxicação))<br>OR<br>(tw:(intoxicações)))<br>OR<br>((tw:(agroquímicos))<br>OR<br>(tw:(agrotóxico)) OR (tw:(produtos agroquímicos)) OR<br>(tw:(defensivo agrícola)))) AND ((tw:(carvão vegetal)) OR<br>(tw:(carvão)) OR (tw:(carvão ativado)) OR (tw:(diurese)) OR<br>(tw:(urina)) OR (tw:(bicarbonato de sódio)) OR (tw:(diálise))<br>OR<br>(tw:(diálise<br>renal))<br>OR<br>(tw:(hemodiálise))<br>OR<br>(tw:(hemoperfusão))<br>OR<br>(tw:(hemofiltração))<br>OR<br>(tw:(plasmaferese)) OR (tw:(transfusão total)))|51<br>(Busca 5b)|
|||**Espanhol**|||
|||Terapéutica,<br>_Tratamiento_,<br>_Terapia_,<br>Tratamiento de Urgencia, Urgencias<br>Médicas,<br>Envenenamiento,|((tw:(terapéutica)) OR (tw:(tratamiento)) OR (tw:(terapia))<br>OR (tw:(tratamiento de urgencia)) OR (tw:(urgencias<br>médicas)))<br>AND<br>((tw:(envenenamiento))<br>OR|4<br>(Busca 1c)|  
91  
|1. Qual é o tratamento inicial<br>para o paciente intoxicado<br>com agrotóxicos?|Tratamento<br>de<br>envenenamento<br>por agrotóxicos|_Intoxicación_<br>_Plaguicida_,<br>_Agrícolas, P_|,<br>Agroquímicos,<br> <br>_Pesticida,_<br>_Químicos_<br>_roductos Agroquímicos_|(tw:(intoxicación)))<br>AND<br>((tw:(agroquímicos))<br>OR<br>(tw:(plaguicida)) OR (tw:(pesticida)) OR (tw:(químicos<br>agrícolas)) OR (tw:(productos agroquímicos)))||
|---|---|---|---|---|---|
|||Envenenami<br>Atropina, O|ento,<br>_Intoxicación_,<br>ximas, Difenhidramina|((tw:(envenenamiento))<br>OR<br>(tw:(intoxicación)))<br>AND<br>((tw:(atropina)) OR (tw:(oximas)) OR (tw:(difenhidramina)))|9<br>(Busca 1d)|
|3.<br>Qual<br>deve<br>ser<br>a<br>abordagem<br>pré-hospitalar<br>ante<br>um<br>paciente<br>com<br>suspeita de intoxicação por<br>agrotóxicos?<br>(Profissional<br>de saúde)|Tratamento<br>emergencial/<br>ambulatorial em<br>casos<br>de<br>envenenamento<br>por agrotóxicos|Tratamiento<br>Médicas,<br>Urgencia,<br>Auxiliares<br>Personal<br> <br>Atención<br>críticos, En<br>Agroquímic<br>_Químicos_<br>_Agroquímic_|de Urgencia, Urgencias<br>Servicios<br>Médicos<br>de<br>_Atención Prehospitalaria_,<br>de Urgencia,_Paramédicos_,<br>de<br>Salud,<br>Ambulancias,<br>Ambulatoria,<br>Cuidados<br>venenamiento,_Intoxicación_,<br>os,_Plaguicida_,_Pesticida,_<br>_Agrícolas,_<br>_Productos_<br>_os _|((tw:(tratamiento de urgencia)) OR (tw:(urgencias médicas))<br>OR (tw:(servicios médicos de urgencia)) OR (tw:(atención<br>prehospitalaria)) OR (tw:(auxiliares de urgencia)) OR<br>(tw:(paramédicos)) OR (tw:(personal de salud)) OR<br>(tw:(ambulancias)) OR (tw:(atención ambulatoria)) OR<br>(tw:(cuidados críticos))) AND ((tw:(envenenamiento)) OR<br>(tw:(intoxicación)))<br>AND<br>((tw:(agroquímicos))<br>OR<br>(tw:(plaguicida)) OR (tw:(pesticida)) OR (tw:(químicos<br>agrícolas)) OR (tw:(productos agroquímicos)))|0<br>(Busca 3c)|
|||Terapéutica,<br>Tratamiento<br>Médicas,<br>Urgencia,<br>Auxiliares|<br>_Tratamiento_,<br>_Terapia_,<br>de Urgencia, Urgencias<br>Servicios<br>Médicos<br>de<br>_Atención Prehospitalaria_,<br>de Urgencia,_Paramédicos_,|((tw:(terapéutica)) OR (tw:(tratamiento)) OR (tw:(terapia)))<br>AND ((tw:(tratamiento de urgencia)) OR (tw:(urgencias<br>médicas)) OR (tw:(servicios médicos de urgencia)) OR<br>(tw:(atención<br>prehospitalaria))<br>OR<br>(tw:(auxiliares<br>de<br>urgencia)) OR (tw:(paramédicos)) OR (tw:(personal de|113<br>(Busca 3d)|
|||Personal<br>|de<br>Salud,<br>Ambulancias,|salud))<br>OR<br>(tw:(ambulancias))<br>OR<br>(tw:(atención||  
92  
|||Atención<br>Ambulatoria,<br>críticos, Envenenamiento,_In_<br>Agroquímicos,_Plaguicida_,<br>_Químicos_<br>_Agrícolas,_<br>_Agroquímicos _|Cuidados<br>_toxicación_,<br> _Pesticida,_<br>_Productos_|ambulatoria))<br>OR<br>(tw:(cui<br>(((tw:(envenenamiento))<br>OR<br>((tw:(agroquímicos))<br>OR<br>(tw:(pesticida))<br>OR<br>(tw:(q<br>(tw:(productos agroquímicos))))|dados<br>críticos)))<br>(tw:(intoxicación)))<br>(tw:(plaguicida))<br>uímicos<br>agrícolas))<br>|AND<br>OR<br>OR<br>OR||
|---|---|---|---|---|---|---|---|
|4. Quais são as medidas<br>hospitalares<br>de<br>descontaminação<br>em<br>crianças<br>e<br>adultos<br>com|Métodos<br>de<br>descontaminação<br>em<br>casos<br>de<br>intoxicação|Descontaminación,<br>Enven<br>_Intoxicación_,<br>Agr<br>_Plaguicida_,<br>_Pesticida,_<br>_Agrícolas, Productos Agroqu_|enamiento,<br>oquímicos,<br>_Químicos_<br>_ímicos_|((tw:(descontaminación))) AND<br>(tw:(intoxicación)))<br>AND<br>(tw:(plaguicida)) OR (tw:(pes<br>agrícolas)) OR (tw:(productos a|((tw:(envenenamiento)<br>((tw:(agroquímicos))<br>ticida)) OR (tw:(quí<br>groquímicos)))|) OR<br>OR<br>micos|0<br>(Busca 4d)|
|intoxicação<br>aguda<br>por<br>agrotóxicos?|aguda<br>por<br>agrotóxicos|Descontaminación,<br>Enven<br>_Intoxicación_|enamiento,|((tw:(descontaminación))) AND<br>(tw:(intoxicación)))|((tw:(envenenamiento)|) OR|8<br>(Busca 4e)|
|||Envenenamiento,<br>_In_|_toxicación_,|(((tw:(envenenamiento))<br>OR|(tw:(intoxicación)))|OR||
|||Agroquímicos,_Plaguicida_,<br>_Químicos_<br>_Agrícolas,_<br>_Agroquímicos,_<br>Carbón<br>_Carbón Vegetal, Carbón_<br>Lavado Gástrico,_Irrigación_<br>Ipeca,_Jarabe de Ipeca_,<br>_Purgante,_ _Tierra de Fuller_|_Pesticida,_<br>_Productos_<br>Orgánico,<br>_Activado_,<br>_Gástrica_,<br>Catárticos,|((tw:(agroquímicos))<br>OR<br>(tw:(pesticida))<br>OR<br>(tw:(q<br>(tw:(productos<br>agroquímicos<br>orgánico)) OR (tw:(carbón<br>activado)) OR (tw:(lavado gá<br>gástrica)) OR (tw:(ipeca)) OR<br>(tw:(catárticos)) OR (tw:(pur<br>fuller)))|(tw:(plaguicida))<br>uímicos<br>agrícolas))<br>))))<br>AND<br>((tw:(c<br>vegetal)) OR (tw:(c<br>strico)) OR (tw:(irrig<br>(tw:(jarabe de ipeca)<br>gante)) OR (tw:(tierr|OR<br>OR<br>arbón<br>arbón<br>ación<br>) OR<br>a de|36<br>(Busca 4f)|  
93  
|5. Quais são<br>eliminação d|os métodos de<br>isponíveis em|Métodos<br>eliminação|de<br>em<br>Eliminación<br>intestinal, Eli|renal,<br> <br>minación H|Eliminación<br>epatobiliar,|((tw:(eliminación<br>(tw:(eliminación|renal))<br>hepatob|OR (tw<br>iliar))|:(eliminac<br>OR (tw:(el|ión intestinal<br>iminación)))|)) OR<br>AND||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|intoxicação|aguda<br>por|casos|de<br>_Eliminación_,|Enven|enamiento,|((tw:(envenenam|iento))|OR|(tw:(into|xicación)))|AND|1|
|agrotóxicos?||intoxicação<br>aguda<br>agrotóxicos|por<br>_Intoxicación_,<br>_Plaguicida_,<br>_Agrícolas, Prod_|Ag<br>_Pesticida,_<br>_uctos Agroq_|roquímicos,<br>_Químicos_<br>_uímicos_|((tw:(agroquímic<br>(tw:(pesticida))<br>(tw:(productos ag|os))<br>OR<br>roquím|OR<br>(tw:(q<br>icos)))|(tw:(pl<br>uímicos|aguicida))<br>agrícolas))|OR<br>OR|(Busca 5c)|
||||Envenenamient|o,<br>_In_|_toxicación_,|(((tw:(envenenam|iento))|<br>OR|(tw:(int|oxicación)))|OR||
||||Agroquímicos,<br>_Químicos_<br> <br>_Agroquímicos,_<br>_Carbón Veget_<br>Diuresis, Orina<br>Diálisis, Diális<br>Hemoperfusión<br>Plasmaféresis,<br>Sangre|_Plaguicida_,<br>_Agrícolas,_<br>Carbón<br>_al, Carbón_<br>, Bicarbonat<br>is Renal,_H_<br>,<br>Hem<br>Recambio|_Pesticida,_<br>_Productos_<br>Orgánico,<br>_Activado_,<br>o de Sodio,<br>_emodiálisis,_<br>ofiltración,<br>Total<br>de|((tw:(agroquímic<br>(tw:(pesticida))<br>(tw:(productos<br>orgánico)) OR<br>activado))<br>OR<br>(tw:(bicarbonato<br>(tw:(diálisis<br>r<br>(tw:(hemoperfusi<br>(tw:(plasmaféresi|os))<br>OR<br>agroqu<br>(tw:(c<br>(tw:(d<br> <br>de<br> <br>enal))<br>ón))<br>s)) OR|OR<br>(tw:(q<br>ímicos<br>arbón<br>iuresis<br>sódio))<br>OR<br>OR<br>(tw:(rec|(tw:(pl<br>uímicos<br>))))<br>AN<br>vegetal))<br>))<br>OR<br> <br>OR<br>(<br>(tw:(he<br>(tw:(hem<br>ambio tot|aguicida))<br>agrícolas))<br>D<br>((tw:(c<br>OR (tw:(c<br>(tw:(orina))<br>tw:(diálisis))<br>modiálisis))<br>ofiltración))<br>al de sangre))|OR<br>OR<br>arbón<br>arbón<br>OR<br>OR<br>OR<br>OR<br>)|71<br>(Busca 5d)|  
a Os termos DeCS estão mostrados em negrito e os termos livres, em itálico.  
b tw = palavras-chave contidas no Título, resumo ou assunto.  
*Filtros aplicados: todas as bases de busca, exceto Medline; idiomas inglês, português e espanhol; período de 2010 a 2016; tipo de documento: somente Artigo.  
94

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.3 - Estratégias de Busca** -->
**Quadro I.3.3.1. Estratégia de busca e associação de palavras-chave, no PubMed, para as perguntas PICO de Prevenção.**  
||**Pergunta**|**Bloco conceitual**|**Termos**|**Estratégia**|**Pubmed**|
|---|---|---|---|---|---|
||||**Inglês**|||
|1.<br>Quais<br>efetivas<br>incidência<br>agrotóxicos|intervenções<br>são<br>para<br>reduzir<br>a<br>de intoxicações por<br>de caráter suicida?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter suicida|Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Suicide, Suicide,<br>Attempted,<br>Suicidal<br>ideation,<br>suicidal<br>behaviour,<br>Prevention<br>and<br>control,<br>Prevention, Primary Prevention.|("Poisoning"[Mesh]<br>OR<br>"poisoning"[Subheading]<br>OR<br>"Organophosphate Poisoning"[Mesh]) AND ("Pesticides"[Mesh]<br>OR "Agrochemicals"[Mesh]) AND ("Suicide"[Mesh] OR "Suicide,<br>Attempted" [Mesh] OR “Suicidal ideation” OR “suicidal<br>behaviour”) AND ("Primary Prevention"[Mesh] OR "prevention<br>and<br>control"<br>[Subheading])<br>AND<br>"2010/01/01"[PDAT]:<br>"2017/08/31"[PDAT] AND (English[lang] OR Portuguese[lang]<br>OR Spanish[lang])|19 (1a)|
|||||(("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh])<br>AND||
|2.<br>Quais<br>efetivas<br>incidência<br>agrotóxicos<br>ocupaciona|intervenções<br>são<br>para<br>reduzir<br>a<br>de intoxicações por<br> <br>de<br>caráter<br>l?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter ocupacional|Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Prevention and<br>control, Prevention, Primary Prevention,<br>Ocupational Exposure, Ocupational Injuries|"prevention and control"[Subheading]) AND ("Occupational<br>Injuries"[Mesh] OR "Occupational Exposure"[Mesh]) AND<br>("Poisoning"[Mesh]<br>OR<br>"poisoning"[Subheading]<br>OR<br>"Organophosphate<br>Poisoning"[Mesh])<br>AND<br>("2010/01/01"[PDAT]: "2017/08/31"[PDAT]) AND (English[lang]<br>OR Portuguese[lang] OR Spanish[lang]))|18 (2a)|  
95  
|||Equipamentos de Proteção Individual|(("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh])<br>AND<br>("prevention and control"[Subheading]) AND ("Occupational<br>Injuries"[Mesh] OR "Occupational Exposure"[Mesh]) AND<br>(("Protective<br>Clothing"[Mesh])<br>OR<br>("Personal<br>Protective<br>Equipment"[Mesh]))<br>AND<br>(("2010/01/01"[PDAT]:<br>"2017/08/31"[PDAT]) AND (English[lang] OR Portuguese[lang]<br>OR Spanish[lang]))|33 (2b)|
|---|---|---|---|---|
|||Agricultura orgânica|(("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh])<br>AND<br>("Occupational<br>Injuries"[Mesh]<br>OR<br>"Occupational<br>Exposure"[Mesh]) AND**("Organic Agriculture"[Mesh])**AND<br>(("2010/01/01"[PDAT]:<br>"2017/08/31"[PDAT])<br>AND<br>(English[lang] OR Portuguese[lang] OR Spanish[lang]))|1 (2c)|
|3.<br>Quais<br>intervenções<br>são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>acidental?|Prevenção<br>intoxicação<br>p<br>agrotóxicos,<br>caráter acidental|à<br>or<br>de<br> <br>Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Prevention and<br>control, Prevention, Primary Prevention,<br>Accidents, Accidental Exposure|("Poisoning"[Mesh]<br>OR<br>"poisoning"[Subheading]<br>OR<br>"Organophosphate Poisoning"[Mesh]) AND ("Pesticides"[Mesh]<br>OR "Agrochemicals"[Mesh]) AND ("accidental"[All Fields] OR<br>"accidents"[All Fields] OR “Accidents, Occupational”[Mesh])<br>AND ("Primary Prevention"[Mesh] OR "prevention  and  control"<br>[Subheading]) AND ("2010/01/01"[PDAT]: "2017/08/31"[PDAT])<br>AND (English[lang] OR Portuguese[lang] OR Spanish[lang])|4 (3a)|  
96  
|||Busca mais abrangente e com menos termos|("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh])<br>("accidental"[All Fields] OR "accidents"[All Fields<br>("prevention"[All<br>Fields)<br>AND<br>("2010/01/01"<br>"2017/08/31"[PDAT]) AND (English[lang] OR Portugu<br>OR Spanish[lang]))|AND<br>]) AND<br>[PDAT]:<br>ese[lang]|22 (3b)|
|---|---|---|---|---|---|
|**4.**Quais são as estratégias para|Redução do risco<br>de intoxicação por|Agrochemicals, Pesticides, Food. Organic|("Food"[Mesh] OR "Food, Organic"[Mesh]) AND ("<br>Residues"[Mesh]) AND ("Cholinesterase Inhibitors"[M<br>"Carbamates"[Mesh] OR "Organophosphate Poisoning"[M<br>"Organophosphorus<br>Compounds"[Mesh])<br>(("2010/01/01"[PDAT]<br>:<br>"2017/08/31"[PDAT])<br>(English[lang] OR Portuguese[lang] OR Spanish[lang])|Pesticide<br>esh] OR<br>esh] OR<br>AND<br>AND|151 (4a)|
|redução do risco de exposição<br>por consumo de alimentos com<br>resíduos<br>de<br>inibidores<br>de<br>colinesterase?|<br>resíduos<br>de<br>inibidores<br>de<br>colinesterase<br>em<br>alimentos|Food,<br>Cholinesterase<br>Inhibitors,<br>Organophosphorus<br>Compounds,<br>Carbamates, Risk factors, Pesticide residues,<br>Prevention and control|("prevention<br>and<br>control"<br>[Subheading]<br>OR<br> <br>Prevention"[Mesh]<br>)<br>AND<br>("Food"[Mesh]<br>OR<br>Organic"[Mesh])<br>AND ("Pesticide Residues"[Mesh]<br>("Pesticides"[Mesh]<br>OR<br>"Agrochemicals"[Mesh])<br>("Cholinesterase Inhibitors"[Mesh] OR "Carbamates"[M<br>"Organophosphate Poisoning"[Mesh] OR "Organoph<br>Compounds"[Mesh])<br>AND<br>(("2010/01/01"[PDA<br>"2017/08/31"[PDAT]) AND (English[lang] OR Portugu<br>OR Spanish[lang])|"Primary<br>"Food,<br>) AND<br>AND<br>esh] OR<br>osphorus<br>T]<br>:<br>ese[lang]|11 (4b)|  
97  
|("prevention<br>and<br>control"<br>[Subheading]<br>OR<br>"Primary||
|---|---|
|Prevention"[Mesh]) AND ("degradation" OR “reduction” OR<br>“removal” OR “decontamination”) AND ("Food Safety"[Mesh])<br>AND ("Pesticide Residues"[Mesh]) AND (("2010/01/01"[PDAT] :<br>"2017/08/31"[PDAT]) AND (English[lang] OR Portuguese[lang]<br>OR Spanish[lang])|17 (4c)|
|("Risk Management"[Mesh] OR "Risk Factors"[Mesh OR "Risk<br>Reduction Behavior"[Mesh]) AND ("Pesticide Residues"[Mesh])<br>AND ("Cholinesterase Inhibitors"[Mesh] OR "Carbamates"[Mesh]||
|OR "Organophosphate Poisoning"[Mesh] OR "Organophosphorus|0|
|Compounds"[Mesh])<br>AND<br>(("2010/01/01"[PDAT]<br>:<br>"2017/08/31"[PDAT]) AND (English[lang] OR Portuguese[lang]<br>OR Spanish[lang]))||  
*Filtros aplicados: período 01/01/2010 a 31/08/2017, idiomas inglês, português e espanhol. Busca realizada no dia 24/09/2017.  
98  
**Quadro I.3.3.2. Estratégia de busca e associação de palavras-chave, para o Cochrane Library, para as perguntas PICO de Prevenção.**  
|**Pergunta**|**Bloco conceit**|**ual**<br>**Termos**|**Estratégia**|**Cochrane**|
|---|---|---|---|---|
|||**Inglês**|||
|1. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>suicida?|Prevenção<br>intoxicação<br>agrotóxicos,<br>caráter suicida|à<br>por<br>de<br>Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Suicide, Suicide,<br>Attempted,<br>Suicidal<br>ideation,<br>suicidal<br>behaviour,<br>Prevention<br>and<br>control,<br>Prevention, Primary Prevention.|("Poisoning" OR poison* OR "Organophosphate Poisoning") AND<br>("Pesticides" OR "Agrochemicals") AND ("Suicide" OR Suicid*)<br>AND ("Prevention" OR prevent*)|2 (5a)|
|2. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>ocupacional?|Prevenção<br>intoxicação<br>agrotóxicos,<br>caráter ocupaci|à<br>por<br>de<br>onal<br>Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Prevention and<br>control, Prevention, Primary Prevention,<br>Ocupational Exposure, Ocupational Injuries|("Poisoning" OR poison* OR "Organophosphate Poisoning") AND<br>("Pesticides" OR "Agrochemicals") AND (Occupational*) AND<br>("Prevention" OR prevent*)|1 (5b)|
|3. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>acidental?|Prevenção<br>intoxicação<br>agrotóxicos,<br>caráter acidenta|à<br>por<br>de<br>l<br>Poisoning,<br>Organophosphate<br>Poisoning,<br>Agrochemicals, Pesticides, Prevention and<br>control, Prevention, Primary Prevention,<br>Accidents, Accidental Exposure|("Poisoning" OR poison* OR "Organophosphate Poisoning") AND<br>("Pesticides" OR "Agrochemicals") AND (Accident*) AND<br>("Prevention" OR prevent*)|1 (5c)|  
99  
|**4.**Quais são as estratégias<br>para redução do risco de<br>exposição por consumo de|Redução do r<br>de intoxicação<br>resíduos<br>inibidores|isco<br>por<br>de<br>de|Agrochemicals, Pesticides,<br>Food,<br>Cholinesterase<br>Organophosphorus|Food. Organic<br>Inhibitors,<br>Compounds,|("Pesticides"<br>Inhibitors"<br>|OR<br>OR<br>|"Agrochemicals")<br>AND<br>("Cholinesterase<br>“Organophosphorus<br>Compounds”<br>OR<br> <br>0|
|---|---|---|---|---|---|---|---|
|alimentos com resíduos de<br>inibidores de colinesterase?|colinesterase<br>alimentos|em|Carbamates, Risk factors, Pe<br>Prevention and control|sticide residues,|“Carbamates”|) AND|(pesticide residue* OR food)|  
*Filtros aplicados: idioma da revisão em português, inglês ou espanhol. Busca realizada no dia 24/09/2017.  
**Quadro I.3.3.3. Estratégia de busca e associação de palavras-chave, para Lilacs/BVS, para as perguntas PICO de Prevenção.**  
|**Pergunta**|**Bloco conceitual**|**Termos**|||**Estratégia**<br>**Lilacs/BVS**|
|---|---|---|---|---|---|
||||**Portu**|**guês**||
|||Prevenção<br>e<br>Mitigação,<br> <br>Agrotóxicos,|<br>controle,<br>P<br>Agroquímicos,<br>Defensivo|revenção<br>e<br>Agrotóxico,<br>Agrícola,|(Prevenção OR Mitigação OR controle) AND (Agroquímicos OR<br>Agrotóxico OR Agrotóxicos OR “Defensivo Agrícola” OR|
|1. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter suicida|Defensivos<br>Agroquímicos<br>Intoxicação,<br>Tentativa de S|Agrícolas,<br>,<br>En<br>Intoxicações,<br>uicídio|Produtos<br>venenamento,<br> <br>Suicídio,|“Defensivos Agrícolas” OR “Produtos Agroquímicos”) AND<br>(Envenenamento OR Intoxicação OR Intoxicações) AND (Suicídio<br>OR “Tentativa de Suicídio”)<br>0|
|suicida?||Busca mais ab|rangente||(tw:(agroquimico*)) OR (tw:(pesticida*)) OR (tw:(agrotóxico*))<br>OR (tw:(defensivo* agrícola*)) AND (tw:(intoxicaç*)) OR<br>(tw:(envenenamento*)) AND (tw:(suicídio*)) AND (tw:(preven*))<br>OR (tw:(controle)) OR (tw:(mitigação))<br>0|  
100  
|||Busca mais a|brangente||(tw:(agroquimico*)) OR (tw:(pesticida*)) OR (tw:(agrotóxico*))<br>OR (tw:(defensivo* agrícola*)) AND (tw:(intoxicaç*)) OR<br>(tw:(envenenamento*)) AND (tw:(suicid*))|0|
|---|---|---|---|---|---|---|
|2. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a|Prevenção<br>à<br>intoxicação<br>por|Prevenção<br>Mitigação,<br>Agrotóxicos,<br>Defensivos<br>Agroquímico<br>Intoxicação,<br>Ocupacional|e<br>controle,<br> <br>Agroquímicos,<br> <br>Defensivo<br>Agrícolas,<br>s,<br>En<br>Intoxicações,|Prevenção<br>e<br>Agrotóxico,<br>Agrícola,<br>Produtos<br>venenamento,<br> <br>Exposição|(Prevenção OR Mitigação OR controle) AND (Agroquímicos OR<br>Agrotóxico OR Agrotóxicos OR “Defensivo Agrícola” OR<br>“Defensivos Agrícolas” OR “Produtos Agroquímicos”) AND<br>(Envenenamento OR Intoxicação OR Intoxicações)<br>AND<br>(ocupacional OR “Exposição ocupacional”)|0|
|incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>ocupacional?|<br> <br>agrotóxicos,<br>de<br>caráter ocupacional|Busca mais a|brangente||(tw:(agrotóxico*)) OR (tw:(pesticida*)) OR (tw:(agroquímico*))<br>OR (tw:(defensivo* agrícola*)) AND (tw:(envenenamento)) OR<br>(tw:(intoxicação)) OR (tw:(intoxicações)) AND (tw:(ocupacional))<br>OR (tw:(trabalho))|0|
|||EPI|||((tw:(pesticida*)) OR (tw:(agrotóxico*))) AND ((tw:("equipamento<br>de proteção individual")) OR (tw:(EPI)))|10 (6b)|
|3. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>acidental?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter acidental|Prevenção<br>Mitigação,<br>Agrotóxicos,<br>Defensivos|e<br>controle,<br> <br>Agroquímicos,<br> <br>Defensivo<br>Agrícolas,|Prevenção<br>e<br>Agrotóxico,<br>Agrícola,<br>Produtos|(Prevenção OR Mitigação OR controle) AND (Agroquímicos OR<br>Agrotóxico OR Agrotóxicos OR “Defensivo Agrícola” OR<br>“Defensivos Agrícolas” OR “Produtos Agroquímicos”) AND<br>(Envenenamento OR Intoxicação OR Intoxicações) AND<br>(acidente* OR “acidental”)|0|  
101  
|||Agroquímico<br>Intoxicação, I|s,<br>E<br>ntoxicações, A|nvenenamento,<br>cidentes|||
|---|---|---|---|---|---|---|
|||Busca mais a|brangente||(tw:(agrotóxico*)) OR (tw:(pesticida*)) OR (tw:(agroquímico*))<br>OR (tw:(defensivo* agrícola*)) AND (tw:(envenenamento)) OR<br>(tw:(intoxicação)) OR (tw:(intoxicações)) AND (tw:(acidental)) OR<br>(tw:(acidente*))|0|
|**4.**Quais são as estratégias|Redução do r<br>de intoxicação|isco<br>por<br>Prevenção<br>Mitigação,<br>Agrotóxicos,|e<br>controle,<br>Agroquímicos<br> <br>Defensivo|Prevenção<br>e<br>,<br>Agrotóxico,<br> <br>Agrícola,|("Alimentos”)<br>AND<br>("Resíduos<br>de<br>Praguicidas”)<br>AND<br>(Agroquímicos OR Agrotóxico OR Agrotóxicos OR “Defensivo<br>Agrícola” OR “Defensivos Agrícolas”) AND (“Inibidores da<br>Colinesterase”<br>OR<br>“Compostos<br>Organofosforados”<br>OR<br>Carbamatos)|0|
|para redução do risco de<br>exposição por consumo de<br>alimentos com resíduos de<br>inibidores de colinesterase?|<br>resíduos<br>inibidores<br>colinesterase<br>alimentos|<br>de<br>de<br>em<br>Defensivos<br>Colinesterase<br>Organofosfor<br>Carbamatos,<br>Praguicidas|Agrícolas,<br> <br>,<br>ados<br>Alimentos,<br>**Esp**|Inibidores<br>da<br>Compostos<br>Resíduos<br>de<br>**anhol**|tw:(((tw:(agroquimico*))<br>OR<br>(tw:(pesticida*))<br>OR<br>(tw:(agrotóxico*))<br>OR<br>(tw:(defensivo*<br>agrícola*)))<br>AND<br>((tw:(inibidores da colinesterase)) OR (tw:(carbamatos)) OR<br>(tw:(compostos organofosforados))) AND ((tw:(alimentos)) OR<br>(tw:(resíduos de praguicidas)))) AND (instance:"regional") AND (<br>db:("LILACS") AND type:("article"))|1 (6d)|  
102  
|1. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>suicida?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter suicida|Prevención<br>Mitigación,<br>Envenenamie<br>Organofosfato<br>Suicidio.|y<br>Ag<br>nto,<br>s,|control,<br>P<br>roquímicos,<br> <br>Intoxic<br>Intento|revención<br>y<br> <br>Plaguicidas,<br>ación<br>por<br>de<br>Suicidio,|(tw:(agroquimico*))<br>OR<br>(tw:(envenamiento*)) OR (tw:(in<br>AND (tw:(prevencion*)) OR (tw|(tw:(plaguicida*))<br>AND<br>toxicacion*)) AND (tw:(suicid*))<br>:(prevent*))|18 (6a)|
|---|---|---|---|---|---|---|---|---|
|2. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>ocupacional?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter ocupacional|Prevención<br>Mitigación,<br>Envenenamie<br>Organofosfato<br>Exposición Pr|y<br>Ag<br>nto,<br>s,<br>ofe|control,<br>P<br>roquímicos,<br> <br>Intoxic<br>Riesgos<br>sional|revención<br>y<br> <br>Plaguicidas,<br>ación<br>por<br>Laborales,|(tw:(plaguicida*))<br>OR<br>(tw:(envenenamiento*))<br>OR<br>(tw:(prevencion*)) OR (tw:(pre<br>(tw:(profesional*))|(tw:(agroquimico*))<br>AND<br>(tw:(intoxicacion*))<br>AND<br>vent*)) AND (tw:(laboral*)) OR|0|
|3. Quais intervenções são<br>efetivas<br>para<br>reduzir<br>a<br>incidência de intoxicações por<br>agrotóxicos<br>de<br>caráter<br>acidental?|Prevenção<br>à<br>intoxicação<br>por<br>agrotóxicos,<br>de<br>caráter acidental|Prevención<br>Mitigación,<br>Envenenamie<br>Organofosfato<br>Accidentes.|y<br>Ag<br>nto,<br>s,|control,<br>P<br>roquímicos,<br> <br>Intoxic<br>Prevención|revención<br>y<br> <br>Plaguicidas,<br>ación<br>por<br>de Accidentes,|(tw:(agroquimico*))<br>OR<br>(tw:(envenenamiento*))<br>OR<br>(tw:(prevencion*)) OR (tw:(prev|(tw:(plaguicida*))<br>AND<br>(tw:(intoxicacion*))<br>AND<br>ent*)) AND (tw:(accident*))|6 (6c)|
|**4.**Quais são as estratégias<br>para redução do risco de<br>exposição por consumo de<br>alimentos com resíduos de<br>inibidores de colinesterase?|Redução do risco<br>de intoxicação por<br>resíduos<br>de<br>inibidores<br>de<br>colinesterase<br>em<br>alimentos|Prevención<br>Mitigación,<br>Inhibidores de<br>Organofosfor<br>Alimentos, Re|y<br>Ag<br>la<br>ado<br>sid|control,<br>P<br>roquímicos,<br>Colinesteras<br>s, Carbamato<br>uos de Plagu|revención<br>y<br> <br>Plaguicidas,<br>a, Compuestos<br>s<br>icidas|tw:(((tw:(agroquimico*)) OR<br>“inhibidores de la colinesterasa”)<br>(tw:(carbamatos))) AND ((tw:(a<br>plaguicidas)))) AND (instance:"r<br>AND type:("article"))|(tw:(plaguicida*))) AND ((tw:(<br>) OR (tw:( organofosforados)) OR<br>limento*)) OR (tw:(residuos de<br>egional") AND ( db:("LILACS")|**11 (6e)**|  
*Filtros aplicados: período 01/01/2010 a 2017, idiomas inglês, português e espanhol e que contivessem as palavras-chaves no título, resumo ou assunto (tw). Busca realizada no dia 24/09/2017.  
103

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.4 – Seleção de Artigos** -->
**Após a busca exploratória sobre o diagnóstico geral das intoxicações por agrotóxicos, optou-se por não utilizar a revisão sistemática como metodologia para esse item porque as recomendações que são aplicáveis a todos os tipos de agrotóxicos são em grande maioria pontos de boa prática. Porém, a busca sistemática será realizada para diagnóstico nos capítulos posteriores desta diretriz, tendo em vista a especificidade do tema nos grupos priorizados.**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.4 – Seleção de Artigos** -->
**Quadro I.4.2.1** . Artigos resultantes da busca sistemática no site Pubmed para as perguntas PICO referentes ao tratamento de intoxicações agudas por agrotóxicos.  
**Quadro I.4.2.2** - Artigos resultantes da busca sistemática no site Cochrane Library para as perguntas PICO referentes ao tratamento de pacientes intoxicados com agrotóxicos e análise de inclusão do artigo.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.4 – Seleção de Artigos** -->
**Quadro I.4.3.1.** Artigos resultantes da busca sistemática no site Pubmed para as perguntas PICO referentes à prevenção de intoxicações agudas por agrotóxicos.  
**Quadro I.4.3.2.** Concordância de inserção dos Artigos resultantes da busca sistemática no site Cochrane Library, para as perguntas PICO relacionadas à prevenção.  
**Quadro I.4.3.3.** Concordância de inserção dos Artigos resultantes da busca sistemática no site Lilacs- BVS, para as perguntas PICO relacionadas à prevenção.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.4 – Seleção de Artigos** -->
104  
**Quadro I.4.2.3.** Artigos resultantes da busca sistemática no site **Pubmed** para as perguntas PICO referentes ao tratamento de intoxicações agudas por agrotóxicos.  
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|Adjuvant treatment with crude rhubarb for patients with acute organophosphorus<br>pesticide poisoning: A meta-analysis of randomized controlled trials.|Wang L, Pan S.|2015|Sim|
|Applicability of citronella oil (Cymbopogon winteratus) for the prevention of<br>mosquito-borne diseases in the rural area of Tikapur, far-western Nepal.|Sajo ME, Song SB, Bajgai J, Kim YJ, Kim PS, Ahn<br>DW, Khanal N, Lee KJ.|2015|Não|
|Home-based community health worker intervention to reduce pesticide exposures<br>to farmworkers'children: A randomized-controlled trial.|Salvatore AL, Castorina R, Camacho J, Morga N,<br>López J, Nishioka M, Barr DB, Eskenazi B, Bradman<br>A.|2015|Não|
|Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in<br>the treatment of acute severe organophosphorus pesticide poisoning.|Liang MJ, Zhang Y.|2015|Sim|
|An exploratory study; the therapeutic effects of premixed activated charcoal-<br>sorbitol administration in patients poisoned with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|Não|
|Glucocorticoid with cyclophosphamide for paraquat-induced lung fibrosis.|Li LR, Sydenham E, Chaudhary B, Beecher D, You C.|2014|Sim|
|Is oxygen required before atropine administration in organophosphorus or<br>carbamate pesticide poisoning?-A cohort study.|Konickx LA, Bingham K, Eddleston M.|2014|Não|  
105  
|Organophosphate-pyrethroid combination pesticides may be associated with<br>increased toxicity in human poisoning compared to either pesticide alone.|Iyyadurai R, Peter JV, Immanuel S, Begum A,<br>Zachariah A, Jasmine S, Abhilash KP.|2014|Não|
|---|---|---|---|
|Long-lasting permethrin impregnated uniforms: A randomized-controlled trial for<br>tick bite prevention.|Vaughn MF, Funkhouser SW, Lin FC, Fine J, Juliano<br>JJ, Apperson CS, Meshnick SR.|2014|Não|
|Comparison between kidney and continuous plasma perfusion for paraquat<br>elimination.|Li GQ, Li YM, Wei LQ, Liu Y, Zhang YH.|2014|Sim|
|Reactivation of plasma butyrylcholinesterase by pralidoxime chloride in patients<br>poisoned by WHO class II toxicity organophosphorus insecticides.|Konickx LA, Worek F, Jayamanne S, Thiermann H,<br>Buckley NA, Eddleston M.|2013|Sim|
|A central storage facility to reduce pesticide suicides--a feasibility study from<br>India.|Vijayakumar L, Jeyaseelan L, Kumar S, Mohanraj R,<br>Devika S, Manikandan S.|2013|Não|
|Can topical insect repellents reduce malaria? A cluster-randomised controlled trial<br>of the insect repellent N,N-diethyl-m-toluamide (DEET) in Lao PDR.|Chen-Hussey V, Carneiro I, Keomanila H, Gray R,<br>Bannavong S, Phanalasy S, Lindsay SW.|2013|Não|
|Effect of intravenous lipid emulsion in patients with acute glyphosate intoxication.|Gil HW, Park JS, Park SH, Hong SY.|2013|Sim|
|[Field efficacy of repellent formulation containing para-menthane-3,8-diol and<br>lemongrass against Culicoides pachymerus (Diptera: Ceratopogonidae) in<br>Colombia].|Santamaría E, Cabrera OL, Zipa Y, Pardo RH.|2012|Não|
|A systematic review on the nerve-muscle electrophysiology in human<br>organophosphorus pesticide exposure.|Karami-Mohajeri S, Nikfar S, Abdollahi M.|2014|Não|  
106  
|I smell a rat: a case report and literature review of paradoxical thrombosis and<br>hemorrhage in a patient with brodifacoum toxicity.|Franco D, Everett G, Manoucheri M.|2013|Não|
|---|---|---|---|
|A systematic review of mosquito coils and passive emanators: defining<br>recommendations for spatial repellency testing methodologies.|Ogoma SB, Moore SJ, Maia MF.|2012|Não|
|A nationwide evidence-based study of factors associated with hospitalisations due<br>to unintentional poisoning and poisoning mortality in Taiwan.|Chien WC, Chung CH, Lin CH, Lai CH.|2013|Não|
|Clinical analysis of 12 patients caused by long-acting anticoagulant rodenticide<br>occult poisoning.|Cao X, Li L, Zheng Y.|2012|Não|
|Glucocorticoid with cyclophosphamide for paraquat-induced lung fibrosis.|Li LR, Sydenham E, Chaudhary B, You C.|2012|Sim - Repetido|
|Potential of the bush mint, Hyptis suaveolens essential oil for personal protection<br>against mosquito biting.|Abagli AZ, Alavo TB, Avlessi F, Moudachirou M.|2012|Não|
|A community-based cluster randomised trial of safe storage to reduce pesticide<br>self-poisoning in rural Sri Lanka: study protocol.|Pearson M, Konradsen F, Gunnell D, Dawson AH,<br>Pieris R, Weerasinghe M, Knipe DW, Jayamanne S,<br>Metcalfe C, Hawton K, Wickramasinghe AR, Atapattu<br>W, Bandara P, de Silva D, Ranasinghe A, Mohamed F,<br>Buckley NA, Gawarammana I, Eddleston M.|2011|Não|
|Medical management of paraquat ingestion.|Gawarammana IB, Buckley NA.|2011|Sim|
|Organophosphorus poisoning (acute).|Blain PG.|2011|Sim|  
107  
|Effectiveness of citronella preparations in preventing mosquito bites: systematic<br>review of controlled laboratory experimental studies.|Kongkaew C, Sakunrag I, Chaiyakunapruk N,<br>Tawatsin A.|2011|Não|
|---|---|---|---|
|Oximes for acute organophosphate pesticide poisoning.|Buckley NA, Eddleston M, Li Y, Bevan M, Robertson<br>J.|2011|Sim|
|An urgent need to restrict access to pesticides based on human lethality.|Miller M, Bhalla K.|2010|Não|
|Expert review of the evidence base for arthropod bite avoidance.|Goodyer LI, Croft AM, Frances SP, Hill N, Moore SJ,<br>Onyango SP, Debboun M.|2010|Não|
|Clinical and bioavailability studies of sublingually administered atropine sulfate.|Rajpal S, Ali R, Bhatnagar A, Bhandari SK, Mittal G.|2010|Não|
|Extrapyramidal effects of acute organophosphate poisoning.|Reji KK, Mathew V, Zachariah A, Patil AK, Hansdak<br>SG, Ralph R, Peter JV.|2016|Sim|
|An exploratory study; the therapeutic effects of premixed activated charcoal-<br>sorbitol administration in patients poisoned with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|Não|
|Is oxygen required before atropine administration in organophosphorus or<br>carbamate pesticide poisoning?-A cohort study.|Konickx LA, Bingham K, Eddleston M.|2014|Não|
|Efficacy of pralidoxime in organophosphorus poisoning: revisiting the controversy<br>in Indian setting.|Banerjee I, Tripathi SK, Roy AS.|2014|Sim|
|Reactivation of plasma butyrylcholinesterase by pralidoxime chloride in patients<br>poisoned by WHO class II toxicity organophosphorus insecticides.|Konickx LA, Worek F, Jayamanne S, Thiermann H,<br>Buckley NA, Eddleston M.|2013|Sim - Repetido|  
108  
|Effect of a brief outreach educational intervention on the translation of acute<br>poisoning treatment guidelines to practice in rural Sri Lankan hospitals: a cluster<br>randomized controlled trial.|Senarathna L, Buckley NA, Dibley MJ, Kelly PJ,<br>Jayamanna SF, Gawarammana IB, Dawson AH.|2013|Não|
|---|---|---|---|
|Phase II study of magnesium sulfate in acute organophosphate pesticide poisoning.|Basher A, Rahman SH, Ghose A, Arif SM, Faiz MA,<br>Dawson AH.|2013|Sim|
|Open-label randomized clinical trial of atropine bolus injection versus incremental<br>boluses plus infusion for organophosphate poisoning in Bangladesh.|Abedin MJ, Sayeed AA, Basher A, Maude RJ, Hoque<br>G, Faiz MA.|2012|Sim|
|Organophosphorus poisoning (acute).|Blain PG.|2011|Sim - Repetido|
|Oximes for acute organophosphate pesticide poisoning.|Buckley NA, Eddleston M, Li Y, Bevan M, Robertson<br>J.|2011|Sim - Repetido|
|Prochlorperazine in children with migraine: a look at its effectiveness and rate of<br>akathisia.|Trottier ED, Bailey B, Lucas N, Lortie A.|2012|Não|
|A trial of midazolam vs diphenhydramine in prophylaxis of metoclopramide-<br>induced akathisia.|Erdur B, Tura P, Aydin B, Ozen M, Ergin A, Parlak I,<br>Kabay B.|2012|Não|
|Bioscavenger therapy for organophosphate poisoning-an open-labeled pilot<br>randomized trial comparing fresh frozen plasma or albumin with saline in acute<br>organophosphate poisoning in humans.|Pichamuthu K, Jerobin J, Nair A, John G, Kamalesh J,<br>Thomas K, Jose A, Fleming JJ, Zachariah A, David SS,<br>Daniel D, Peter JV.|2010|Sim|
|Clinical and bioavailability studies of sublingually administered atropine sulfate.|Rajpal S, Ali R, Bhatnagar A, Bhandari SK, Mittal G.|2010|Não|  
109  
|A prospective, randomized trial of intravenous prochlorperazine versus<br>subcutaneous sumatriptan in acute migraine therapy in the emergency department.|Kostic MA, Gutierrez FJ, Rieg TS, Moore TS, Gendron<br>RT.|2010|Não|
|---|---|---|---|
|Home-based community health worker intervention to reduce pesticide exposures<br>to farmworkers'children: A randomized-controlled trial.|Salvatore AL, Castorina R, Camacho J, Morga N,<br>López J, Nishioka M, Barr DB, Eskenazi B, Bradman<br>A.|2015|Não|
|Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in<br>the treatment of acute severe organophosphorus pesticide poisoning.|Liang MJ, Zhang Y.|2015|Sim - Repetido|
|Is oxygen required before atropine administration in organophosphorus or<br>carbamate pesticide poisoning?-A cohort study.|Konickx LA, Bingham K, Eddleston M.|2014|Não|
|Organophosphate-pyrethroid combination pesticides may be associated with<br>increased toxicity in human poisoning compared to either pesticide alone.|Iyyadurai R, Peter JV, Immanuel S, Begum A,<br>Zachariah A, Jasmine S, Abhilash KP.|2014|Não|
|An exploratory study; the therapeutic effects of premixed activated charcoal-<br>sorbitol administration in patients poisoned with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|Não|
|Medical management of paraquat ingestion.|Gawarammana IB, Buckley NA.|2011|Sim - Repetido|
|Organophosphorus poisoning (acute).|Blain PG.|2011|Sim - Repetido|
|Retrospective review of unintentional pediatric ingestions of doxylamine.|Cantrell FL, Clark AK, McKinley M, Qozi M.|2015|Não|
|An exploratory study; the therapeutic effects of premixed activated charcoal-<br>sorbitol administration in patients poisoned with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|Não|  
110  
|Application of the perineal ostomy in severe organophosphate poisoned patients<br>after catharsis.|Zhang DM, Xiao Q.|2014|Sim|
|---|---|---|---|
|Suicide by gases in England and Wales 2001-2011: evidence of the emergence of<br>new methods of suicide.|Gunnell D, Coope C, Fearn V, Wells C, Chang SS,<br>Hawton K, Kapur N.|2015|Não|
|Castor bean seed ingestions: a state-wide poison control system's experience.|Thornton SL, Darracq M, Lo J, Cantrell FL.|2014|Não|
|Effect of a brief outreach educational intervention on the translation of acute<br>poisoning treatment guidelines to practice in rural Sri Lankan hospitals: a cluster<br>randomized controlled trial.|Senarathna L, Buckley NA, Dibley MJ, Kelly PJ,<br>Jayamanna SF, Gawarammana IB, Dawson AH.|2013|Não|
|Randomized controlled study on the use of multiple-dose activated charcoal in<br>patients with supratherapeutic phenytoin levels.|Skinner CG, Chang AS, Matthews AS, Reedy SJ,<br>Morgan BW.|2012|Não|
|Treating staggered paracetamol overdose.|Thomason C.|2012|Não|
|Medical management of paraquat ingestion.|Gawarammana IB, Buckley NA.|2011|Sim - Repetido|
|Organophosphorus poisoning (acute).|Blain PG.|2011|Sim - Repetido|
|Effect of activated charcoal in reducing paracetamol absorption at a supra-<br>therapeutic dose.|Wananukul W, Klaikleun S, Sriapha C, Tongpoo A.|2010|Não|
||Finkelstein Y, Aks SE, Hutson JR, Juurlink DN,|||
|Colchicine poisoning: the dark side of an ancient drug.|Nguyen P, Dubnov-Raz G, Pollak U, Koren G, Bentur<br>Y.|2010|Não|  
111  
|Dose-dependent adsorptive capacity of activated charcoal for gastrointestinal<br>decontamination of a simulated paracetamol overdose in human volunteers.|<br>Gude AB, Hoegberg LC, Angelo HR, Christensen HR.|2010|Não|
|---|---|---|---|
|Medical management of paraquat ingestion.|Gawarammana IB, Buckley NA.|2011|Sim - Repetido|
|Clinical and bioavailability studies of sublingually administered atropine sulfate.|Rajpal S, Ali R, Bhatnagar A, Bhandari SK, Mittal G.|2010|Não|
|Home-based community health worker intervention to reduce pesticide exposures<br>to farmworkers'children: A randomized-controlled trial.|Salvatore AL, Castorina R, Camacho J, Morga N,<br>López J, Nishioka M, Barr DB, Eskenazi B, Bradman<br>A.|2015|Não|
|Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in<br>the treatment of acute severe organophosphorus pesticide poisoning.|<br>Liang MJ, Zhang Y.|2015|Sim - Repetido|
|An exploratory study; the therapeutic effects of premixed activated charcoal-<br>sorbitol administration in patients poisoned with organophosphate pesticide.|Moon J, Chun B, Song K.|2015|Não|
|Comparison between kidney and continuous plasma perfusion for paraquat<br>elimination.|<br>Li GQ, Li YM, Wei LQ, Liu Y, Zhang YH.|2014|Sim - Repetido|
|Medical management of paraquat ingestion.|Gawarammana IB, Buckley NA.|2011|Sim - Repetido|
|Organophosphorus poisoning (acute).|Blain PG.|2011|Sim - Repetido|  
112  
**Quadro I.4.2.4 - Artigos resultantes da busca sistemática no site Cochrane Library para as perguntas PICO referentes ao tratamento de pacientes intoxicados com agrotóxicos e análise de inclusão do artigo.**  
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|Clinical analysis of penehyclidine hydrochloride combined with hemoperfusion in<br>the treatment of acute severe organophosphorus pesticide poisoning|<br>Liang MJ and Zhang Y|2015|Sim - Repetido|
|N-acetylcysteine a novel treatment for acute human organophosphate poisoning|Shadnia S, Ashrafivand S, Mostafalou S and Abdollahi<br>M|2011|Sim|
|Chronic kidney disease of unknown aetiology in Sri Lanka: is cadmium a likely<br>cause?|<br>Wanigasuriya KP, Peiris-John RJ and Wickremasinghe<br>R|2011|Não|
|Oximes for acute organophosphate pesticide poisoning|Nick A Buckley, Michael Eddleston, Yi Li , Marc<br>Bevan and Jane Robertson|2011|Sim - Repetido|
|Psychosocial interventions for self-harm in adults|Keith Hawton , Katrina G Witt , Tatiana L Taylor<br>Salisbury , Ella Arensman , David Gunnell , Philip<br>Hazell , Ellen Townsend and Kees van Heeringen|2016|Não|
|Interventions for necrotising pancreatitis|Kurinchi Selvan Gurusamy , Ajay P Belgaumkar ,<br>Adam Haswell , Stephen P Pereira and Brian R<br>Davidson|2016|Não|  
113  
|Interventions for self-harm in children and adolescents|Keith Hawton , Katrina G Witt , Tatiana L Taylor<br>Salisbury , Ella Arensman , David Gunnell , Ellen<br>Townsend , Kees van Heeringen and Philip Hazell|2015|Não|
|---|---|---|---|
|Noninvasive positive pressure ventilation for acute respiratory failure following<br>upper abdominal surgery|Debora AS Faria, Edina MK da Silva , Álvaro N<br>Atallah and Flávia MR Vital|2015|Não|
|Hemodialysis for lithium poisoning|Eric J Lavonas and Jennie Buchanan|2015|Não|
|Pharmacological interventions for self-harm in adults|Keith Hawton , Katrina G Witt , Tatiana L Taylor<br>Salisbury , Ella Arensman , David Gunnell , Philip<br>Hazell , Ellen Townsend and Kees van Heeringen|2015|Não|
|Laetrile treatment for cancer|Stefania Milazzo and Markus Horneber|2015|Não|
|Household interventions for preventing domestic lead exposure in children|Berlinda Yeoh , Susan Woolfenden , Bruce Lanphear ,<br>Greta F Ridley , Nuala Livingstone and Emile<br>Jorgensen|2014|Não|
|Prophylactic antibiotics for preventing pneumococcal infection in children with<br>sickle cell disease|Ceri Hirst and Shirley Owusu-Ofori|2014|Não|
|Glucocorticoid with cyclophosphamide for paraquat-induced lung fibrosis|Luying Ryan Li , Emma Sydenham , Bhuwan<br>Chaudhary , Deirdre Beecher and Chao You|2014|Sim - Repetido|
|D-Penicillamine for preventing retinopathy of prematurity in preterm infants|Mosarrat J Qureshi and Manoj Kumar|2013|Não|  
114  
|Xuebijing for paraquat poisoning|Jin Deng , Dongmei Huo , Qiaoyuan Wu, Lin Zhu and<br>Yunhua Liao|2013|Sim|
|---|---|---|---|
|Hyperbaric oxygen therapy for the adjunctive treatment of traumatic brain injury|Michael H Bennett , Barbara Trytko and Benjamin<br>Jonker|2012|Não|
|Home safety education and provision of safety equipment for injury prevention|Denise Kendrick , Ben Young , Amanda J Mason-Jones<br>, Nohaid Ilyas , Felix A Achana , Nicola J Cooper ,<br>Stephanie J Hubbard , Alex J Sutton , Sherie Smith ,<br>Persephone Wynn , Caroline A Mulvaney , Michael C<br>Watson and Carol Coupland|2012|Não|
|Hyperbaric oxygen for carbon monoxide poisoning|Nick A Buckley , David N Juurlink , Geoff Isbister ,<br>Michael H Bennett and Eric J Lavonas|2011|Não|
|Oximes for acute organophosphate pesticide poisoning|Nick A Buckley, Michael Eddleston, Yi Li , Marc<br>Bevan and Jane Robertson|2011|Sim - Repetido|
|Hemodialysis for lithium poisoning|Eric J Lavonas and Jennie Buchanan|2015|Não|
|Glucocorticoid with cyclophosphamide for paraquat-induced lung fibrosis|Luying Ryan Li , Emma Sydenham , Bhuwan<br>Chaudhary , Deirdre Beecher and Chao You|2014|Sim - Repetido|  
115  
**ANEXO I.4.3 – PREVENÇÃO**  
**Quadro I.4.3.5. Artigos resultantes da busca sistemática no site Pubmed para as perguntas PICO referentes à prevenção de intoxicações agudas por agrotóxicos.**  
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|Cost-effectiveness analyses of self-harm strategies aimed at reducing the mortality<br>of pesticide self-poisonings in Sri Lanka: a study protocol.|Madsen LB, Eddleston M, Hansen KS, Pearson M,<br>Agampodi S, Jayamanne S, Konradsen F.|2015|Sim|
|Clinico-epidemiological Study on Pesticide Poisoning in a Tertiary Care Hospital<br>in Eastern Nepal.|Agrawaal KK, Karki P.|2014|Não|
|A public health initiative for reducing access to pesticides as a means to<br>committing suicide: findings from a qualitative study|Mohanraj R, Kumar S, Manikandan S, Kannaiyan V,<br>Vijayakumar L.|2014|Sim|
|Policymaking 'under the radar': a case study of pesticide regulation to prevent<br>intentional poisoning in Sri Lanka.|Pearson M, Zwi AB, Buckley NA, Manuweera G,<br>Fernando R, Dawson AH, McDuie-Ra D.|2015|Não|
|A central storage facility to reduce pesticide suicides--a feasibility study from India|Vijayakumar L, Jeyaseelan L, Kumar S, Mohanraj R,<br>Devika S, Manikandan S.|2013|Sim|
|In rural Asia, locking up poisons to prevent suicides.|Hvistendahl M.|2013|Sim|
|The role of private pesticide vendors in preventing access to pesticides for self-<br>poisoning in rural Sri Lanka.|Weerasinghe M, Pearson M, Peiris R, Dawson AH,<br>Eddleston M, Jayamanne S, Agampodi S, Konradsen F.|2014|Sim|  
116  
|Prolonged coagulopathy related to coumarin rodenticide in a young patient:<br>superwarfarin poisoning|Altay S, Cakmak HA, Boz GC, Koca S, Velibey Y.|2012|Não|
|---|---|---|---|
|A community-based cluster randomised trial of safe storage to reduce pesticide<br>self-poisoning in rural Sri Lanka: study protocol.|Pearson M, Konradsen F, Gunnell D, Dawson AH,<br>Pieris R, et al.|2011|Sim|
|Trends in solids/liquids poisoning suicide rates in Taiwan: a test of the substitution<br>hypothesis|Lin JJ, Lu TH.|2011|Sim|
|Suicide by pesticide poisoning: findings from the island of Crete, Greece.|Kastanaki AE, Kraniotis CF, Kranioti EF, Nathena D,<br>Theodorakis PN, Michalodimitrakis M.|2010|Não|
|Major reductions in global suicide numbers can be made rapidly through pesticide<br>regulation without the need for psychosocial interventions.|Eddleston M, Bateman DN.|2010|Sim|
|An urgent need to restrict access to pesticides based on human lethality.|Miller M, Bhalla K.|2010|Sim|
|[Patients attended at a Venezuelan Toxicology Centre]|Tagliaferro ZA, Bracamonte G.|2010|Sim|
|Pattern of acute food, drug, and chemical poisoning in Sari City, Northern Iran|Ahmadi A, Pakravan N, Ghazizadeh Z.|2010|Sim|
|Rice tablet poisoning: a major concern in Iranian population.|Mehrpour O, Singh S.|2010|Não|
|Failed rescue therapy with rapamycin after paraquat intoxication|Lorenzen JM, Schonenberger E, Hafer C, Hoeper M,<br>Kielstein JT.|2010|Não|
|Regional variation in suicide rates in Sri Lanka between 1955 and 2011: a spatial<br>and temporal analysis.|Knipe DW, Padmanathan P, Muthuwatta L, Metcalfe<br>C, Gunnell D.|2017|Sim|  
117  
|High lethality and minimal variation after acute self-poisoning with carbamate|Lamb T, Selvarajah LR, Mohamed F, Jayamanne S,|||
|---|---|---|---|
|insecticides in Sri Lanka - implications for global suicide prevention.|Gawarammana I, Mostafa A, Buckley NA, Roberts<br>MS, Eddleston M.|2016|Sim|
|Farmers Knowledge, Attitudes, Practices and Health Problems Associated with<br>Pesticide Use in Rural Irrigation Villages, Southwest Ethiopia.|Gesesew HA, Woldemichael K, Massa D, Mwanri L.|2016|Sim|
|Pilot study assessing the effectiveness of factory-treated, long-lasting permethrin-<br>impregnated clothing for the prevention of tick bites during occupational tick<br>exposure in highly infested military training areas, Germany.|Faulde MK, Rutenfranz M, Keth A, Hepke J, Rogge M,<br>Görner A.|2015|Não|
|Pesticide knowledge, practice and attitude and how it affects the health of small-<br>scale farmers in Uganda: a cross-sectional study.|Oesterlund AH, Thomsen JF, Sekimpi DK, Maziina J,<br>Racheal A, Jørs E.|2014|Sim|
|Pesticide retailers' knowledge and handling practices in selected towns of Tanzania.|Lekei EE, Ngowi AV, London L.|2014|Sim|
|Integrating the wisdom and experience of indigenous farmworkers to improve<br>farmworker safety and health.|Farquhar S, de Jesus Gonzalez C, Hall J, Samples J,<br>Ventura S, Sanchez V, Shadbeh N.|2013|Não|
|Evaluating the effectiveness of a lay health promoter-led, community-based<br>participatory pesticide safety intervention with farmworker families.|Quandt SA, Grzywacz JG, Talton JW, Trejo G, Tapia<br>J, D'Agostino RB Jr, Mirabelli MC, Arcury TA.|2013|Sim|
|Engaging Latino farmworkers in the development of symbols to improve pesticide<br>safety and health education and risk communication.|LePrevost CE, Storm JF, Blanchard MR, Asuaje CR,<br>Cope WG.|2013|Sim|  
118  
|Acute ill-health in sheep farmers following use of pesticides.|Povey AC, Rees HG, Thompson JP, Watkins G, Stocks<br>SJ, Karalliedde L.|2012|Não|
|---|---|---|---|
|Labor and pollution prevention in Canada.|Bennett D.|2012|Não|
|Using epidemiology and neurotoxicology to reduce risks to young workers.|Rohlman DS, Nuwayhid I, Ismail A, Saddik B.|2012|Sim|
|The use of pesticides in French viticulture: a badly controlled technology transfer!|Alain G, Baldi I, Marçal J.|2012|Sim|
|Experimental strategy for translational studies of organophosphorus pesticide<br>neurotoxicity based on real-world occupational exposures to chlorpyrifos.|Lein PJ, Bonner MR, Farahat FM, Olson JR, Rohlman<br>DS, Fenske RA, Lattal KM, Lasarev MR, Galvin K,<br>Farahat TM, Anger WK.|2012|Sim|
|Occupational exposure to neurotoxic substances in Asian countries - challenges<br>and approaches.|Meyer-Baron M, Kim EA, Nuwayhid I, Ichihara G,<br>Kang SK.|2012|Sim|
|Female farmworkers' perceptions of pesticide exposure and pregnancy health.|Flocks J, Kelley M, Economos J, McCauley L.|2012|Sim|
|Farmers' perceptions of safe use of pesticides: determinants and training needs.|Hashemi SM, Hosseini SM, Hashemi MK.|2012|Sim|
|Pilot study assessing the effectiveness of long-lasting permethrin-impregnated<br>clothing for the prevention of tick bites.|Vaughn MF, Meshnick SR.|2011|Não|
|Pesticide use and opportunities of exposure among farmers and their families:<br>cross-sectional studies 1998-2006 from Hebron governorate, occupied Palestinian<br>territory.|Issa Y, Sham'a FA, Nijem K, Bjertness E, Kristensen<br>P.|2010|Sim|  
119  
|Acute illnesses associated with exposure to fipronil--surveillance data from 11|Lee SJ, Mulay P, Diebolt-Brown B, Lackovic MJ,|||
|---|---|---|---|
|states in the United States, 2001-2007.|Mehler LN, Beckman J, Waltz J, Prado JB, Mitchell<br>YA, Higgins SA, Schwartz A, Calvert GM.|2010|Sim|
|Pesticides: Perceived Threat and Protective Behaviors Among Latino<br>Farmworkers.|Walton AL, LePrevost C, Wong B, Linnan L, Sanchez-<br>Birkhead A, Mooney K.|2016|Sim|
|Farmers Knowledge, Attitudes, Practices and Health Problems Associated with<br>Pesticide Use in Rural Irrigation Villages, Southwest Ethiopia.|Gesesew HA, Woldemichael K, Massa D, Mwanri L.|2016|Sim - Repetido|
|Provision Increases Reported PPE Use for Mexican Immigrant Farmworkers: An<br>mHealth Pilot Study.|Snipes SA, Smyth JM, Murphy D, Miranda PY, Ishino<br>FA.|2015|Sim|
|Respirator Use Among US Farm Operators With Asthma: Results From the 2011<br>Farm and Ranch Safety Survey.|Casey ML, Mazurek JM.|2017|Sim|
|Association of health symptoms with low-level exposure to organophosphates,<br>DNA damage, AChE activity, and occupational knowledge and practice among<br>rice, corn, and double-crop farmers.|Hongsibsong S, Sittitoon N, Sapbamrer R.|2017|Não|  
120  
|Analytical evaluation of the protection offered by sealed tractor cabins during crop<br>pulverization with fenitrothion.|Barcellos M, Faletti MM, Madureira LA, Bauer FC.|2016|Sim|
|---|---|---|---|
|Hearing impairment and contributing factors among fertilizer factory workers.|Saffree Jeffree M, Ismail N, Awang Lukman K.|2016|Não|
|Observed and self-reported pesticide protective behaviors of Latino migrant and<br>seasonal farmworkers.|Walton AL, LePrevost C, Wong B, Linnan L, Sanchez-<br>Birkhead A, Mooney K.|2016|Sim|
|Protective clothing for pesticide operators: part II--data analysis of fabric<br>characteristics.|Shaw A, Schiffelbein P.|2016|Não|
|Protective clothing for pesticide operators: part I--selection of a reference test<br>chemical for penetration testing.|Shaw A, Schiffelbein P.|2016|Não|
|Dermal exposure and risk assessment of tebuconazole applicators in vineyards.|Mandic-Rajcevic S, Rubino FM, Vianello G, Fugnoli<br>L, Polledri E, Mercadante R, Moretto A, Fustinoni S,<br>Colosio C.|2015|Não|
|Chemical exposure reduction: Factors impacting on South African herbicide<br>sprayers' personal protective equipment compliance and high risk work practices.|Andrade-Rivas F, Rother HA.|2015|Sim|
|Occupational health and safety for agricultural workers in Thailand: gaps and<br>recommendations, with a focus on pesticide use.|Kaewboonchoo O, Kongtip P, Woskie S.|2015|Não|  
121  
|Taiwanese farm workers' pesticide knowledge, attitudes, behaviors and clothing<br>practices.|Weng CY, Black C.|2015|Não|
|---|---|---|---|
|Protective glove use and hygiene habits modify the associations of specific<br>pesticides with Parkinson's disease.|Furlong M, Tanner CM, Goldman SM, Bhudhikanok<br>GS, Blair A, Chade A, Comyns K, Hoppin JA, Kasten<br>M, Korell M, Langston JW, Marras C, Meng C,<br>Richards M, Ross GW, Umbach DM, Sandler DP,<br>Kamel F.|2015|Sim|
|A meta-analytic review of the effectiveness of single-layer clothing in preventing<br>exposure from pesticide handling.|Miguelino ES.|2014|Não|
|Respiratory fit testing for farmworkers in the Black Dirt region of Hudson Valley,<br>New York.|Earle-Richardson G, Fiske T, Wyckoff S, Shuford J,<br>May J.|2014|Não|
|Safety and health hazard observations in Hmong farming operations.|Neitzel RL, Krenz J, de Castro AB.|2014|Sim|
|[Evaluation of personal protective equipment used by malathion sprayers in dengue<br>control in São Paulo, Brazil].|Leme TS, Papini S, Vieira E, Luchini LC.|2014|Sim|
|Procedures to evaluate the efficiency of protective clothing worn by operators<br>applying pesticide.|Espanhol-Soares M, Nociti LA, Machado-Neto JG.|2013|Sim|
|Pesticide flow analysis to assess human exposure in greenhouse flower production<br>in Colombia.|Lesmes-Fabian C, Binder CR.|2013|Sim|
|Design of risk communication strategies based on risk perception among farmers<br>exposed to pesticides in Rio de Janeiro State, Brazil.|Peres F, Rodrigues KM, da Silva Peixoto Belo MS,<br>Moreira JC, Claudio L.|2013|Sim|  
122  
|Effectiveness of pesticide safety training and knowledge about pesticide exposure<br>among Hispanic farmworkers.|Levesque DL, Arif AA, Shen J.|2012|Não|
|---|---|---|---|
|Association between workplace and housing conditions and use of pesticide safety<br>practices and personal protective equipment among North Carolina farmworkers in||2012|Sim|
|2010.|Levesque DL, Arif AA, Shen J.|||
|Do workplace and home protective practices protect farm workers? Findings from<br>the "For Healthy Kids" study.|Coronado GD, Holte SE, Vigoren EM, Griffith WC,<br>Barr DB, Faustman EM, Thompson B.|2012|Sim|
|Risk-accepting personality and personal protective equipment use within the<br>Agricultural Health Study.|DellaValle CT, Hoppin JA, Hines CJ, Andreotti G,<br>Alavanja MC|2012|Sim|
|Dermal exposure assessment of pesticide use: the case of sprayers in potato farms<br>in the Colombian highlands.|Lesmes-Fabian C, García-Santos G, Leuenberger F,<br>Nuyttens D, Binder CR.|2012|Sim|
|Copper levels in buccal cells of vineyard workers engaged in various activities.|Thompson T, Freestone D, Michalczyk AA, Ackland<br>ML.|2012|Sim|
|Assessment of the risk of dermal exposure to pesticides during treatment with a<br>back-pack sprayer in the presence and absence of vegetation.|Kadri Z, Sylla S, Lebeau F, Schiffers B.|2012|Não|
|Occupational safety of farmers in the vegetable industry.|Lu JL.|2011|Sim|
|Pesticide use and opportunities of exposure among farmers and their families:<br>cross-sectional studies 1998-2006 from Hebron governorate, occupied Palestinian<br>territory.|Issa Y, Sham'a FA, Nijem K, Bjertness E, Kristensen<br>P.|2010|Sim|  
123  
|Ergonomics contribution to chemical risks prevention: An ergotoxicological<br>investigation of the effectiveness of coverall against plant pest risk in viticulture.|Garrigou A, Baldi I, Le Frious P, Anselm R, Vallier M.|2011|Sim|
|---|---|---|---|
|Pesticides and other chemicals: minimizing worker exposures.|Keifer M, Gasperini F, Robson M.|2010|Sim|
|Is organic farming safer to farmers' health? A comparison between organic and<br>traditional farming.|Costa C, García-Lestón J, Costa S, Coelho P, Silva<br>S, Pingarilho M, Valdiglesias V, Mattei F, Dall'Armi<br>V, Bonassi S, Laffon B, Snawder J, Teixeira JP.|2014|Sim|
|Tetramethylenedisulfotetramine: pest control gone awry.|Shakarjian MP, Laukova M, Velíšková J, Stanton PK,<br>Heck DE, Velíšek L.|2017|Não|
|Bending the curve: force health protection during the insertion phase of the Ebola<br>outbreak response.|Bailey MS, Beaton K, Bowley D, Eardley W, Hunt P,<br>Johnson S, Round J, Tarmey NT, Williams A.|2016|Não|
|Unintentional ingestion of cleaners and other substances in an immigrant Mexican<br>population: a qualitative study.|Crosslin K, Tsai R.|2016|Não|
|The changing trends of childhood poisoning at a tertiary children's hospital in<br>South Africa.|Balme KH, Roberts JC, Glasstone M, Curling L, Mann<br>MD.|2012|Não|
|Undereporting of acute pesticide poisoning in Tanzania: modelling results from<br>two cross-sectional studies.|Lekei EE, Ngowi AV, London L.|2016|Sim|  
124  
|Agricultural land management options after the Chernobyl and Fukushima<br>accidents: The articulation of science, technology, and society.|Vandenhove H, Turcanu C.|2016|Não|
|---|---|---|---|
|Tetramethylenedisulfotetramine: pest control gone awry.|Shakarjian MP, Laukova M, Velíšková J, Stanton PK,<br>Heck DE, Velíšek L.|2015|Sim|
|Efficacy of topical mosquito repellent (picaridin) plus long-lasting insecticidal nets<br>versus long-lasting insecticidal nets alone for control of malaria: a cluster<br>randomised controlled trial.|Sluydts V, Durnez L, Heng S, Gryseels C, Canier L,<br>Kim S, Van Roey K, Kerkhof K, Khim N, Mao S, Uk<br>S, Sovannaroth S, Grietens KP, Sochantha T, Menard<br>D, Coosemans M.|2016|Não|
|Pantoea agglomerans: a mysterious bacterium of evil and good. Part IV. Beneficial<br>effects.|Dutkiewicz J, Mackiewicz B, Lemieszek MK, Golec<br>M, Milanowski J.|2016|Não|
|Hired crop worker injuries on farms in the United States: A comparison of two<br>survey periods from the National Agricultural Workers Survey.|Tonozzi TR, Layne LA.|2016|Sim|
|Magnitude and characteristics of acute paraquat- and diquat-related illnesses in the<br>US: 1998-2013.|Fortenberry GZ, Beckman J, Schwartz A, Prado JB,<br>Graham LS, Higgins S, Lackovic M, Mulay P, Bojes<br>H, Waltz J, Mitchell Y, Leinenkugel K, Oriel MS,<br>Evans E, Calvert GM.|2016|Sim|
|[Accidental intoxication of the infant-juvenile population in households: profiles<br>of emergency care].|Brito JG, Martins CB.|2015|Não|  
125  
|Bending the curve: force health protection during the insertion phase of the Ebola<br>outbreak response.|Bailey MS, Beaton K, Bowley D, Eardley W, Hunt P,<br>Johnson S, Round J, Tarmey NT, Williams A.|2016|Não|
|---|---|---|---|
|Unintentional ingestion of cleaners and other substances in an immigrant Mexican<br>population: a qualitative study.|Crosslin K, Tsai R.|2016|Sim|
|EPA's proposed Worker Protection Standard and the burdens of the past.|Bohme SR.|2015|Sim|
|Exploded trust.|[No authors listed]|2013|Não|
|The changing trends of childhood poisoning at a tertiary children's hospital in South<br>Africa.|Balme KH, Roberts JC, Glasstone M, Curling L, Mann<br>MD.|2012|Não|
|Drivers of adoption of safety innovations on Australian cotton farms.|Fragar L, Temperley J.|2011|Sim|
|Occupational health and safety for agricultural workers in Thailand: gaps and<br>recommendations, with a focus on pesticide use.|Kaewboonchoo O, Kongtip P, Woskie S.|2015|Sim|
|Safety and health hazard observations in Hmong farming operations.|Neitzel RL, Krenz J, de Castro AB.|2014|Sim|
|Occupational hazards to the health of professional gardeners.|Knibbs LD.|2014|Sim|
|Pesticide poisoning trend analysis of 13 years: a retrospective study based on<br>telephone calls at the National Poisons Information Centre, All India Institute of<br>Medical Sciences, New Delhi|Peshin SS, Srivastava A, Halder N, Gupta YK.|2014|Sim|  
126  
|Control measures for slug and snail hosts of Angiostrongylus cantonensis, with<br>special reference to the semi-slug Parmarion martensi.|Hollingsworth RG, Howe K, Jarvi SI.|2013|Não|
|---|---|---|---|
|[Poisoning with household cleaning products in a city in Northeast Brazil]|Fook SM, Azevedo EF, Costa MM, Feitosa IL,<br>Bragagnoli G, Mariz SR.|2013|Sim|
|Differential antagonism of tetramethylenedisulfotetramine-induced seizures by<br>agents acting at NMDA and GABA(A) receptors.|Shakarjian MP, Velíšková J, Stanton PK, Velíšek L.|2012|Não|
|Esophageal complications following aluminium phosphide ingestion: an emerging<br>issue among survivors of poisoning|Jain RK, Gouda NB, Sharma VK, Dubey TN, Shende<br>A, Malik R, Tiwari G.|2010|Sim|
|Degradation of bifenthrin and pirimiphos-methyl residues in stored wheat grains<br>(Triticum aestivum L.) by ozonation.|Savi GD, Piacentini KC, Bortolotto T, Scussel VM.|2016|Sim - repetido|
|Multiresidue method for simultaneous analysis of aflatoxin M1, avermectins,<br>organophosphate pesticides and milbemycin in milk by ultra-performance liquid<br>chromatography coupled to tandem mass spectrometry.|Dos Anjos MR, Castro IM, Souza Mde L, de Lima VV,<br>de Aquino-Neto FR.|2016|Não|
|A single method for detecting 11 organophosphate pesticides in human plasma and<br>breastmilk using GC-FPD.|Naksen W, Prapamontol T, Mangklabruks A, Chantara<br>S, Thavornyutikarn P, Robson MG, Ryan PB, Barr DB,<br>Panuwet P.|2016|Não|
|Determination of dichlorvos residue levels in vegetables sold in Lusaka, Zambia.|Sinyangwe DM, Mbewe B, Sijumbila G.|2016|Não|
|Identification of multi-insecticide residues using GC-NPD and the degradation<br>kinetics of chlorpyrifos in sweet corn and soils.|Wang P, Rashid M, Liu J, Hu M, Zhong G.|2016|Não|  
127  
|Effects of washing, peeling, storage, and fermentation on residue contents of<br>carbaryl and mancozeb in cucumbers grown in greenhouses.|Saeedi Saravi SS, Shokrzadeh M.|2016|Sim|
|---|---|---|---|
|Residue level and dissipation of carbendazim in/on pomegranate fruits and soil.|Mohapatra S, S L.|2016|Sim|
|Food safety in Thailand. 3: Pesticide residues detected in mangosteen (Garcinia<br>mangostana L.), queen of fruits.|Phopin K, Wanwimolruk S, Prachayasittikul V.|2017|Não|
|Ecological risk analysis of pesticides used on irrigated rice crops in southern Brazil.|Vieira DC, Noldin JA, Deschamps FC, Resgalla C Jr.|2016|Não|
|Genetic analysis of molecular markers for propamocarb residue in Cucumis sativus<br>using quantitative trait locus mapping.|Xin M, Wang L, Ma BH, Qin ZW, Zhou XY.|2016|Não|
|A study on biomimetic immunoassay-capillary electrophoresis method based on<br>molecularly imprinted polymer for determination of trace trichlorfon residue in<br>vegetables.|Li J, Lu J, Qiao X, Xu Z.|2017|Não|
|Evaluation of pesticide residues in fruits and vegetables from Algeria.|Mebdoua S, Lazali M, Ounane SM, Tellah S, Nabi F,<br>Ounane G.|2017|Sim|
|Probabilistic acute risk assessment of cumulative exposure to organophosphorus<br>and carbamate pesticides from dietary vegetables and fruits in Shanghai<br>populations.|Li F, Yuan Y, Meng P, Wu M, Li S, Chen B.|2017|Sim|
|Using Standing Gold Nanorod Arrays as Surface-Enhanced Raman Spectroscopy<br>(SERS) Substrates for Detection of Carbaryl Residues in Fruit Juice and Milk.|Alsammarraie FK, Lin M.|2017|Não|  
128  
|Pesticide residues in leafy vegetables and human health risk assessment in North<br>Central agricultural areas of Chile.|Elgueta S, Moyano S, Sepúlveda P, Quiroz C, Correa<br>A.|2017|Sim|
|---|---|---|---|
|Evaluation of residue risk and toxicity of different treatments with diazinon<br>insecticide applied to mushroom crops.|Navarro MJ, Merino L, Gea FJ.|2017|Não|
|Behavior of Thiophanate Methyl and Propiconazole in Grape and Mango Fruits<br>Under the Egyptian Field Conditions.|Soliman AS, Helmy RM, Nasr IN, Abbas MS,<br>Mahmoud HA, Jiang W.|2017|Sim|
|Comprehensive strategy for pesticide residue analysis through the production cycle<br>of gilthead sea bream and Atlantic salmon.|Portolés T, Ibáñez M, Garlito B, Nácher-Mestre J,<br>Karalazos V, Silva J, Alm M, Serrano R, Pérez-<br>Sánchez J, Hernández F, Berntssen MHG.|2017|Não|
|Dissipation kinetics of organophosphorus pesticides in milled toasted maize and<br>wheat flour (gofio) during storage.|González-Curbelo MÁ, Socas-Rodríguez B, Herrero<br>M, Herrera-Herrera AV, Hernández-Borges J.|2017|Sim|
|Pesticide residues in nut-planted soils of China and their relationship between<br>nut/soil.|Han Y, Mo R, Yuan X, Zhong D, Tang F, Ye C, Liu Y.|2017|Sim|
|A double-label time-resolved fluorescent strip for rapidly quantitative detection of<br>carbofuran residues in agro-products.|Zhang Q, Qu Q, Chen S, Liu X, Li P.|2017|Não|
|Determination of fenobucarb residues in animal and aquatic food products using<br>liquid chromatography-tandem mass spectrometry coupled with a QuEChERS<br>extraction method.|Zheng W, Park JA, Zhang D, Abd El-Aty AM, Kim<br>SK, Cho SH, Choi JM, Shim JH, Chang BJ, Kim JS,<br>Shin HC.|2017|Não|
|Presence of pesticide residues on produce cultivated in Suriname.|Abdoel Wahid F, Wickliffe J, Wilson M, Van Sauers<br>A, Bond N, Hawkins W, Mans D, Lichtveld M.|2017|Não|  
129  
|Contributing effect of various washing procedures and additives on the decline|Kim SW, Abd El-Aty AM, Choi JH, Lee YJ, Lieu TT,|||
|---|---|---|---|
|pattern of diethofencarb in crown daisy, a model of leafy vegetables.|Chung HS, Rahman MM, Choi OJ, Shin HC, Rhee GS,<br>Chang MI, Kim HJ, Shim JH.|2016|Sim|
|Evaluation of ozonation technique for pesticide residue removal and its effect on<br>ascorbic acid, cyanidin-3-glucoside, and polyphenols in apple (Malus domesticus)<br>fruits.|Swami S, Muzammil R, Saha S, Shabeer A, Oulkar D,<br>Banerjee K, Singh SB.|2016|Sim|
|Dissipation kinetics and risk assessment of thiamethoxam and dimethoate in<br>mango.|Bhattacherjee AK, Dikshit A.|2016|Sim|
|Contributing effect of various washing procedures and additives on the decline<br>pattern of diethofencarb in crown daisy, a model of leafy vegetables.|Kim SW, Abd El-Aty AM, Choi JH, Lee YJ, Lieu TT,<br>Chung HS, Rahman MM, Choi OJ, Shin HC, Rhee GS,<br>Chang MI, Kim HJ, Shim JH.|2016|Sim|
|Binding and detoxification of chlorpyrifos by lactic acid bacteria on rice straw<br>silage fermentation.|Wang YS, Wu TH, Yang Y, Zhu CL, Ding CL, Dai CC.|2016|Não|
|Occurrence and spatial distribution of pesticide residues in butter and ghee<br>(clarified butter fat) in Punjab (India).|Bedi JS, Gill JP, Aulakh RS, Kaur P.|2016|Sim|
|Acetylcholinesterase biosensor for inhibitor measurements based on glassy carbon<br>electrode modified with carbon black and pillar[5]arene.|Shamagsumova RV, Shurpik DN, Padnya PL, Stoikov<br>II, Evtugyn GA.|2015|Sim|
|Pesticide residues in stone fruits from the south-eastern region of Poland in 2012-<br>2104.|Słowik-Borowiec M, Szpyrka E, Rupar J, Matyaszek<br>A, Podbielska M.|2015|Sim|
|Dissipation pattern and risk assessment studies of triazophos residues on capsicum<br>(Capsicum annuum L.) using GLC-FPD and GC-MS.|Singh Y, Mandal K, Singh B.|2015|Sim|
|Contribution to the food products' analysis: A research and evaluation on the<br>hemolytic effect of some pesticides used in Lebanon.|Al-Alam J, Millet M, Chbani A, Fajloun Z.|2015|Não|
|Degradation of chlorpyrifos residues in apple under temperate conditions of<br>Kashmir Valley.|Mukhtar M, Sherwani A, Wani AA, Ahmed SB, Sofi<br>JA, Bano P.|2015|Sim|  
130  
|Dissipation of deltamethrin, triazophos, and endosulfan in ready mix formulations<br>in tomato (Lycopersicon esculentum L.) and Egg plant (Solanum melongena L.).|Mukherjee I, Kumar A, Kumar A.|2015|Sim|
|---|---|---|---|
|Evaluation of chlorpyrifos transferred from contaminated feed to duck<br>commodities and dietary risks to Chinese consumers.|Li R, Ji X, He L, Liu Z, Wei W, Qiang M, Wang Q,<br>Yuan Y.|2015|Não|
|Estimation of human health risk associated with the consumption of pesticide-<br>contaminated vegetables from Kumasi, Ghana.|Akoto O, Gavor S, Appah MK, Apau J.|2015|Sim|
|Integrated pest management of "Golden Delicious" apples.|Simončič A, Stopar M, Velikonja Bolta Š, Bavčar D,<br>Leskovšek R, Baša Česnik H.|2015|Não|
|Analysis of veterinary drug and pesticide residues in animal feed by high-<br>resolution mass spectrometry: comparison between time-of-flight and Orbitrap.|Gómez-Pérez ML, Romero-González R, Martínez<br>Vidal JL, Garrido Frenich A.|2015|Não|
|Dissipation behavior and risk assessment of acephate in brinjal using GLC with<br>FPD.|Kaur R, Kaur S, Mandal K, Singh B.|2015|Sim|
|Changes of field incurred chlorpyrifos and its toxic metabolite residues in rice<br>during foodprocessing from-RAC-to-consumption.|Zhang Z, Jiang WW, Jian Q, Song W, Zheng Z, Wang<br>D, Liu X.|2015|Sim|
|Organochlorine and organophosphorus pesticide residues in raw buffalo milk from<br>agroindustrial areas in Assiut, Egypt.|Shaker EM, Elsharkawy EE.|2015|Sim|
|Vortex-assisted low density solvent liquid-liquid microextraction and salt-induced<br>demulsification coupled to high performance liquid chromatography for the<br>determination of five organophosphoruspesticide residues in fruits.|Seebunrueng K, Santaladchaiyakit Y, Srijaranai S.|2015|Não|
|Determination of pesticide residues in samples of green minor crops by gas<br>chromatography and ultra performance liquid chromatography coupled to tandem<br>quadrupole mass spectrometry.|Walorczyk S, Drożdżyński D, Kierzek R.|2015|Não|
|Development and verification for analysis of pesticides in eggs and egg products<br>using QuEChERS and LC-MS/MS.|Choi S, Kim S, Shin JY, Kim M, Kim JH.|2015|Sim|
|A case study on toxicological aspects of the pest and disease control in the<br>production of the high-quality raspberry (Rubus idaeus L.).|Sadło S, Szpyrka E, Piechowicz B, Grodzicki P.|2015|Não|  
131  
|Fate of 14C-ethion insecticide in the presence of deltamethrin and dimilin<br>pesticides in cotton seeds and oils, removal of ethion residues in oils, and<br>bioavailability of its bound residues to experimental animals.|Abdel-Gawad H, Mahdy F, Hashad A, Elgemeie GH.|2014|Não|
|---|---|---|---|
|Degradation pattern and risk assessment of carbendazim and mancozeb in mango<br>fruits.|Devi PA, Paramasivam M, Prakasam V.|2015|Não|
|Chlorpyrifos residual behaviors in field crops and transfers during duck pellet feed<br>processing.|Li R, Wei W, He L, Hao L, Ji X, Zhou Y, Wang Q.|2014|Não|
|Pesticide residue analysis of soil, water, and grain of IPM basmati rice.|Arora S, Mukherji I, Kumar A, Tanwar RK.|2014|Não|
|Multiresidue analysis of 16 pesticides in jujube using gas chromatography and<br>mass spectrometry with multiwalled carbon nanotubes as a sorbent.|Zhao L, Zhang L, Liu F, Xue X, Pan C.|2014|Não|
|Rapid simultaneous detection of multi-pesticide residues on apple using SERS<br>technique.|Zhang Y, Wang Z, Wu L, Pei Y, Chen P, Cui Y.|2014|Não|
|A novel paper rag as 'D-SERS' substrate for detection of pesticide residues at<br>various peels.|Zhu Y, Li M, Yu D, Yang L.|2014|Não|
|The use of dispersive pipet extraction (DPX) tips for the sample cleanup of apples,<br>pears, and oranges in the analysis of formetanate HCI.|Podhorniak LV.|2014|Não|
|Lab-on-a-drop: biocompatible fluorescent nanoprobes of gold nanoclusters for<br>label-free evaluation of phosphorylation-induced inhibition of acetylcholinesterase<br>activity towards the ultrasensitive detection of pesticide residues.|Zhang N, Si Y, Sun Z, Li S, Li S, Lin Y, Wang H.|2014|Não|
|Use of ammonium formate in QuEChERS for high-throughput analysis of<br>pesticides in food by fast, low-pressure gas chromatography and liquid<br>chromatography tandem mass spectrometry.|González-Curbelo MÁ, Lehotay SJ, Hernández-Borges<br>J, Rodríguez-Delgado MÁ.|2014|Não|
|Multiresidue analysis of pesticides in vegetables and fruits by supercritical fluid<br>extraction and liquid chromatography-tandem mass spectrometry.|Saito-Shida S, Nemoto S, Matsuda R.|2014|Não|
|Time-dependent movement and distribution of chlorpyrifos and its metabolism in<br>bamboo forest under soil surface mulching.|Liu Y, Shen D, Zhong D, Mo R, Ni Z, Tang F.|2014|Não|  
132  
|Persistence and dissipation of chlorpyrifos in Brassica chinensis, lettuce, celery,<br>asparagus lettuce, eggplant, and pepper in a greenhouse.|Lu MX, Jiang WW, Wang JL, Jian Q, Shen Y, Liu XJ,<br>Yu XY.|2014|Sim|
|---|---|---|---|
|Gas<br>chromatography<br>with<br>flame<br>photometric<br>detection<br>of<br>31<br>organophosphorus pesticide residuesin Alpinia oxyphylla dried fruits.|Zhao X, Kong W, Wei J, Yang M.|2014|Não|
|Monitoring of pesticide residues levels in fresh vegetable form Heibei Province,<br>North China.|Li W, Tai L, Liu J, Gai Z, Ding G.|2014|Não|
|An acetylcholinesterase biosensor based on graphene-gold nanocomposite and<br>calcined layered double hydroxide.|Zhai C, Guo Y, Sun X, Zheng Y, Wang X.|2014|Não|
|Determination of carbamate and organophosphorus pesticides in vegetable samples<br>and the efficiency of gamma-radiation in their removal.|Chowdhury MA, Jahan I, Karim N, Alam MK, Abdur<br>Rahman M, Moniruzzaman M, Gan SH, Fakhruddin<br>AN.|2014|Sim|
|Organophosphorus pesticide residues in vegetables from farms, markets, and a<br>supermarket around Kwan Phayao Lake of Northern Thailand.|Sapbamrer R, Hongsibsong S.|2014|Não|
|Dietary exposure of Hong Kong adults to pesticide residues: results of the first<br>Hong Kong Total Diet Study.|Wong WW, Yau AT, Chung SW, Lam CH, Ma S, Ho<br>YY, Xiao Y.|2014|Sim|
|Pesticide residues, heavy metals, and DNA damage in sentinel oysters Crassostrea<br>gigas from Sinaloa and Sonora, Mexico.|Vázquez-Boucard C, Anguiano-Vega G, Mercier L,<br>Rojas del Castillo E.|2014|Não|
|Simultaneous determination of ten organophosphate pesticide residues in fruits by<br>gas chromatography coupled with magnetic separation.|Tang Q, Wang X, Yu F, Qiao X, Xu Z.|2014|Não|
|Residues of organophosphate pesticides used in vegetable cultivation in ambient<br>air, surface water and soil in Bueng Niam Subdistrict, Khon Kaen, Thailand.|Harnpicharnchai K, Chaiear N, Charerntanyarak L.|2013|Não|
|Effect of hypochlorite oxidation on cholinesterase-inhibition assay of acetonitrile<br>extracts from fruits and vegetables for monitoring traces of organophosphate<br>pesticides.|Kitamura K, Maruyama K, Hamano S, Kishi T,<br>Kawakami T, Takahashi Y, Onodera S.|2014|Não|
|Behavior of pyrimethanil, pyraclostrobin, boscalid, cypermethrin and chlorpyrifos<br>residues on raspberry fruit and leaves of Laszka variety.|Sadło S, Szpyrka E, Stawarczyk M, Piechowicz B.|2014|Não|  
133  
|Validation of a GC-MS method for the estimation of dithiocarbamate fungicide<br>residues and safety evaluation of mancozeb in fruits and vegetables.|Mujawar S, Utture SC, Fonseca E, Matarrita J,<br>Banerjee K.|2014|Sim|
|---|---|---|---|
|Study on an electrochromatography method based on organic-inorganic hybrid<br>molecularly imprinted monolith for determination of trace trichlorfon in<br>vegetables.|Zhao T, Wang Q, Li J, Qiao X, Xu Z.|2014|Não|
|Application of graphene for the SPE clean-up of organophosphorus pesticides<br>residues from apple juices.|Han Q, Wang Z, Xia J, Zhang X, Wang H, Ding M.|2014|Não|
|Simple laccase-based biosensor for formetanate hydrochloride quantification in<br>fruits.|Ribeiro FW, Barroso MF, Morais S, Viswanathan S, de<br>Lima-Neto P, Correia AN, Oliveira MB, Delerue-<br>Matos C.|2014|Não|
|Dissipation kinetics of bifenazate in tea under tropical conditions.|Satheshkumar<br>A,<br>Senthurpandian<br>VK,<br>Shanmugaselvan VA.|2014|Não|
|Combined<br>determination<br>and<br>confirmation<br>of<br>ethylenethiourea<br>and<br>propylenethiourea residues in fruits at low levels of detection.|López-Fernández O, Rial-Otero R, Cid A, Simal-<br>Gándara J.|2014|Não|
|Study of a molecularly imprinted solid-phase extraction coupled with high-<br>performance liquid chromatography for simultaneous determination of trace<br>trichlorfon and monocrotophos residues in vegetables.|Wang X, Tang Q, Wang Q, Qiao X, Xu Z.|2014|Não|
|Construction of graphene oxide magnetic nanocomposites-based on-chip<br>enzymatic microreactor for ultrasensitive pesticide detection.|Liang RP, Wang XN, Liu CM, Meng XY, Qiu JD.|2013|Não|
|Selective determination of thiram residues in fruit and vegetables by hydrophilic<br>interaction LC-MS.|Ringli D, Schwack W.|2013|Não|
|Dynamics and residues of mixed formulation of fenamidone and mancozeb in<br>gherkin field ecosystem.|Paramasivam M, Chandrasekaran S.|2013|Não|
|Comparative assessment of pesticide residues in grain, soil, and water from IPM<br>and non-IPM trials of basmati rice.|Arora S, Mukherjee I, Kumar A, Garg DK.|2014|Não|  
134  
|Pesticide residues in human breast milk: risk assessment for infants from Punjab,<br>India.|Bedi JS, Gill JP, Aulakh RS, Kaur P, Sharma A, Pooni<br>PA.|2013|Sim|
|---|---|---|---|
|Determination of organophosphorus pesticides and metabolites in cereal-based<br>baby foods and wheat flour by means of ultrasound-assisted extraction and hollow-<br>fiber liquid-phase microextraction prior to gas chromatography with nitrogen<br>phosphorus detection.|González-Curbelo MÁ, Hernández-Borges J, Borges-<br>Miquel TM, Rodríguez-Delgado MÁ.|2013|Não|
|Pesticide residues in berries harvested from South-Eastern Poland (2009-2011).|Matyaszek A, Szpyrka E, Podbielska M, Słowik-<br>Borowiec M, Kurdziel A.|2013|Não|
|Residues of ¹⁴C-ethion along the extraction and refining process of maize oil, and<br>the bioavailability of bound residues in the cake for experimental animals.|Abdel-Gawad H, Abdel-Hameed RM, Witczak A.|2013|Não|
|Persistence and effect of processing on chlorpyriphos residues in tomato<br>(Lycopersicon esculantum Mill.).|Rani M, Saini S, Kumari B.|2013|Sim|
|Simultaneous determination of nine trace organophosphorous pesticide residues in<br>fruit samples using molecularly imprinted matrix solid-phase dispersion followed<br>by gas chromatography.|Wang X, Qiao X, Ma Y, Zhao T, Xu Z.|2013|Não|
|Quantifying fenobucarb residue levels in beef muscles using liquid<br>chromatography-tandem mass spectrometry and QuEChERS sample preparation.|Park KH, Choi JH, Abd El-Aty AM, Musfiqur Rahman<br>M, Jang J, Ko AY, Kwon KS, Park HR, Kim HS, Shim<br>JH.|2013|Sim|
|Washing effects of limonene on pesticide residues in green peppers.|Lu HY, Shen Y, Sun X, Zhu H, Liu XJ.|2013|Sim-Repetido|
|Determination of strobilurin fungicide residues in fruits and vegetables by micellar<br>electrokinetic capillary chromatography with sweeping.|Wang K, Chen GH, Wu X, Shi J, Guo DS.|2014|Não|
|Chlorpyrifos residues in food plant in the region of Setif-Algeria.|Benzidane C, Dahamna S.|2013|Não|
|Spinach or amaranth may represent highest residue of thiophanate-methyl with<br>open field application on six leaf vegetables.|Fan S, Zhao P, Zhang F, Yu C, Pan C.|2013|Não|  
135  
|Simultaneous separation and determination of eight organophosphorous pesticide<br>residues in vegetables through molecularly imprinted solid-phase extraction<br>coupled to gas chromatography.|Xin J, Qiao X, Ma Y, Xu Z.|2012|Não|
|---|---|---|---|
|Organophosphorus and carbamate pesticide residues detected in water samples<br>collected from paddy and vegetable fields of the Savar and Dhamrai Upazilas in<br>Bangladesh.|Chowdhury MA, Banik S, Uddin B, Moniruzzaman M,<br>Karim N, Gan SH.|2012|Não|
|CODEX-compliant eleven organophosphorus pesticides screening in multiple<br>commodities using headspace-solid phase microextraction-gas chromatography-<br>mass spectrometry.|Sang ZY, Wang YT, Tsoi YK, Leung KS.|2013|Não|
|Removal of chloropyrifos ethyl, tetradifon and chlorothalonil pesticide<br>residues from citrus by using ozone.|Kusvuran E, Yildirim D, Mavruk F, Ceyhan M.|2012|Sim-Repetido|
|A direct competitive enzyme-linked immunosorbent assay for rapid detection of<br>anilofos residues in agricultural products and environmental samples.|Zhang Y, Gao AH, Liu B, Sheng W, Tan C, Yuan M,<br>Wang S.|2013|Não|
|Measured versus simulated dietary pesticide intakes in children.|Riederer AM, Lu C.|2012|Não|
|Predictors of exposure to organophosphate pesticides in schoolchildren in the<br>Province of Talca, Chile.|Muñoz-Quezada MT, Iglesias V, Lucero B, Steenland<br>K, Barr DB, Levy K, Ryan PB, Alvarado S, Concha C.|2012|Não|
|Conventional (MG-BR46 Conquista) and transgenic (BRS Valiosa RR) soybeans<br>have no mutagenic effects and may protect against induced-DNA damage in vivo.|Venâncio VP, Silva JP, Almeida AA, Brigagão MR,<br>Azevedo L.|2012|Não|
|Monitoring of selected pesticides residue levels in water samples of paddy fields<br>and removal of cypermethrin and chlorpyrifos residues from water using rice bran.|Bhattacharjee S, Fakhruddin AN, Chowdhury MA,<br>Rahman MA, Alam MK.|2012|Não|
|Total diet study on pesticide residues in France: levels in food as consumed and<br>chronic dietary risk to consumers.|Nougadère A, Sirot V, Kadar A, Fastier A, Truchot E,<br>Vergnet C, Hommet F, Baylé J, Gros P, Leblanc JC.|2012|Sim|
|Direct estimation of carbaryl by gas liquid chromatography with nitrogen<br>phosphorus detection.|Battu RS, Mandal K, Urvashi, Pandher S, Takkar R,<br>Singh B.|2012|Não|
|Pathological effects of dichlorvos and fenitrothion in mice.|Somia el-M, Madiha F.|2012|Não|  
136  
|Reduction of pesticide residues on fresh vegetables with electrolyzed water<br>treatment.|Hao J, Wuyundalai, Liu H, Chen T, Zhou Y, Su YC, Li<br>L.|2011|Sim-Repetido|
|---|---|---|---|
|Novel sol-gel hybrid methyltrimethoxysilane-tetraethoxysilane as solid phase<br>extraction sorbent for organophosphorus pesticides.|Wan Ibrahim WA, Veloo KV, Sanagi MM.|2012|Não|
|An application of new microwave absorption tube in non-polar solvent microwave-<br>assisted extraction of organophosphorus pesticides from fresh vegetable samples.|Zhao X, Xu X, Su R, Zhang H, Wang Z|2012|Não|
|A pilot study of pesticides and PCBs in the breast milk of women residing in urban<br>and agricultural communities of California.|Weldon RH, Barr DB, Trujillo C, Bradman A, Holland<br>N, Eskenazi B.|2011|Não|
|Study of liquid chromatography/electrospray ionization mass spectrometry matrix<br>effect on the example of glyphosate analysis from cereals.|Kruve A, Auling R, Herodes K, Leito I.|2011|Não|
|Kinetic and thermodynamic investigation of mancozeb degradation in tomato<br>homogenate during thermal processing.|Certel M, Cengiz MF, Akçay M.|2012|Sim-Repetido|
|Bioavailability and toxicological potential of sunflower-bound residues of (14)C-<br>chlorpyrifos insecticide in rats.|Abdel-Gawad H, Taha H.|2011|Não|
|Assessment of pesticide residues in commonly used vegetables in Hyderabad,<br>Pakistan.|Latif Y, Sherazi ST, Bhanger MI.|2011|Não|
|Liquid extraction surface analysis (LESA) of food surfaces employing chip-based<br>nano-electrospray mass spectrometry.|Eikel D, Henion J.|2011|Não|
|Catanionic surfactant ambient cloud point extraction and high-performance liquid<br>chromatography for simultaneous analysis of organophosphorus pesticide<br>residues in water and fruit juice samples.|Seebunrueng K, Santaladchaiyakit Y, Soisungnoen P,<br>Srijaranai S.|2011|Não|
|Determination of carbendazim, thiophanate, thiophanate-methyl and benomyl<br>residues in agricultural products by liquid chromatography-tandem mass<br>spectrometry.|Nakamura M, Furumi Y, Watanabe F, Mizukoshi K,<br>Taniguchi M, Nemoto S.|2011|Não|  
137  
|A rapid and environmental friendly determination of the dithiocarbamate<br>metabolites ethylenethiourea and propylenethiourea in fruit and vegetables by ultra<br>high performance liquid chromatography tandem mass spectrometry.|Bonnechère A, Hanot V, Van Loco J.|2011|Não|
|---|---|---|---|
|Dissipation and distribution behavior of azoxystrobin, carbendazim, and<br>difenoconazole in pomegranate fruits.|Utture SC, Banerjee K, Dasgupta S, Patil SH, Jadhav<br>MR, Wagh SS, Kolekar SS, Anuse MA, Adsule PG.|2011|Não|
|Calculation of the dietary exposure of Chinese consumers to acephate residues<br>using deterministic and probabilistic approaches.|Liu P, Li CY, Wang CN, Sun JF, Min J, Hu D, Wu YN.|2011|Não|
|Sequential injection-bead injection-lab-on-valve coupled to high-performance<br>liquid chromatography for online renewable micro-solid-phase extraction of<br>carbamate residues in food and environmental samples.|Vichapong J, Burakham R, Srijaranai S, Grudpan K.|2011|Não|
|Using fast gas chromatography-mass spectrometry with auto-headspace solid-<br>phase microextraction to determine ultra trace residues of organophosphorus<br>pesticides in fruits.|Jiang Y, Ni Y, Zhu H, Zhu C.|2011|Não|
|A sensitive monoclonal antibody-based enzyme-linked immunosorbent assay for<br>chlorpyrifos residue determination in Chinese agricultural samples.|Liu YH, Chen J, Guo YR, Wang CM, Liang X, Zhu<br>GN.|2011|Não|
|Development of immunoaffinity columns for pyraclostrobin extraction from fruit<br>juices and analysis by liquid chromatography with UV detection.|Esteve-Turrillas FA, Mercader JV, Agulló C, Abad-<br>Somovilla A, Abad-Fuentes A.|2011|Não|
|Analysis of insecticides in honey by liquid chromatography-ion trap-mass<br>spectrometry: comparison of different extraction procedures.|Blasco C, Vazquez-Roig P, Onghena M, Masia A, Picó<br>Y.|2011|Não|
|Inoculations with arbuscular mycorrhizal fungi increase vegetable yields and<br>decrease phoxim concentrations in carrot and green onion and their soils.|Wang FY, Tong RJ, Shi ZY, Xu XF, He XH.|2011|Não|
|Dispersive liquid-liquid microextraction coupled with high-performance liquid<br>chromatography-diode array detection for the determination of N-methyl<br>carbamate pesticides in vegetables.|Lin X, Chen X, Huo X, Yu Z, Bi K, Li Q.|2011|Não|
|Development, validation, and uncertainty measurement of multi-residue analysis<br>of organochlorine and organophosphorus pesticides using pressurized liquid<br>extraction and dispersive-SPE techniques.|Sanyal D, Rani A, Alam S, Gujral S, Gupta R.|2011|Não|  
138  
|Determination of dithiocarbamates and milneb residues in foods by gas<br>chromatography-mass spectrometry.|Nakamura M, Noda S, Kosugi M, Ishiduka N,<br>Mizukoshi K, Taniguchi M, Nemoto S.|2010|Não|
|---|---|---|---|
|Capillary electrophoresis with immobilized quantum dot fluorescence detection for<br>rapid determination of organophosphorus pesticides in vegetables.|Chen Q, Fung Y.|2010|Não|
|Dynamics of phoxim residues in green onion and soil as influenced by arbuscular<br>mycorrhizal fungi.|Wang FY, Shi ZY, Tong RJ, Xu XF.|2011|Não|
|Coacervative microextraction ultrasound-assisted back-extraction technique for<br>determination of organophosphates pesticides in honey samples by gas<br>chromatography-mass spectrometry.|Fontana AR, Camargo AB, Altamirano JC.|2010|Não|
|Organophosphorus pesticide<br>residues in<br>raw<br>milk<br>and<br>infant<br>formulas<br>from Spanish northwest.|Melgar MJ, Santaeufemia M, Garcia MA.|2010|Não|
|Analytical methods for estimation of organophosphorus pesticide residues in fruits<br>and vegetables: a review.|Sharma D, Nagpal A, Pakade YB, Katnoria JK.|2010|Não|
|Residue content of carbaryl applied on greenhouse cucumbers and its reduction by<br>duration of a pre-harvest interval and post-harvest household processing.|Hassanzadeh N, Bahramifar N, Esmaili-Sari A.|2010|Sim - Repetido|
|Potential of atmospheric pressure chemical ionization source in GC-QTOF MS for<br>pesticide residue analysis.|Portolés T, Sancho JV, Hernández F, Newton A,<br>Hancock P.|2010|Não|
|Assessing children's dietary pesticide exposure: direct measurement of pesticide<br>residues in 24-hr duplicate food samples.|Lu C, Schenck FJ, Pearson MA, Wong JW.|2010|Sim|
|Simultaneous determination of phoxim and its photo-transformation metabolite<br>residues in eggs using liquid chromatography coupled with electrospray ionization<br>tandem mass spectrometry.|Lee JH, Park S, Jeong WY, Park HJ, Kim HG, Lee SJ,<br>Shim JH, Kim ST, Abd El-Aty AM, Im MH, Choi OJ,<br>Shin SC.|2010|Não|
|Monitoring of pesticide residues in market basket samples of vegetable from<br>Lucknow City, India: QuEChERS method.|Srivastava AK, Trivedi P, Srivastava MK, Lohani M,<br>Srivastava LP.|2011|Não|
|Multiresidue method for the determination of organophosphorus pesticides in<br>cereal matrixes.|Mariani MB, D'Aiuto V, Giannetti V.|2010|Não|  
139  
|Monoclonal antibody produced by heterologous indirect enzyme-linked<br>immunosorbent assay and its application for parathion residue determination in<br>agricultural and environmental samples.|Liu YH, Wang CM, Guo YR, Liang X, Gui W, Zhu<br>GN.|2010|Não|
|---|---|---|---|
|Development of enzyme linked immunoassay for the simultaneous detection of<br>carbaryl and metolcarb in different agricultural products.|Sun J, Dong T, Zhang Y, Wang S.|2010|Não|
|Simultaneous determination of residues of trichlorfon and dichlorvos in animal<br>tissues by LC-MS/MS.|Wang GM, Dai H, Li YG, Li XL, Zhang JZ, Zhang L,<br>Fu YY, Li ZG.|2010|Não|
|Effect of processing on 14C-chlorfenvinphos residues in maize oil and<br>bioavailability of its cake residues on rats.|Mahdy FM, El-Maghraby SI.|2010|Não|
|Dissipation study of thiophanate methyl residue in/on grapes (Vitis vinifera L.) in<br>India.|Mandal S, Das S, Bhattacharyya A.|2010|Sim|
|Determination of formetanate hydrochloride in fruit samples using liquid<br>chromatography-mass selective detection or -tandem mass spectrometry.|Podhorniak LV, Kamel A, Rains DM.|2010|Não|
|Fate of 14C-ethyl prothiofos insecticide in canola seeds and oils.|Abdel-Gawad H, Hegazi B.|2010|Não|
|Pesticide residues intake of French adults under increased consumption of fresh<br>fruits and vegetables--a theoretical study.|Barnat S, Boisset M, Casse F, Catteau M, Lecerf JM,<br>Veschambre D, Periquet A.|2010|Não|
|Multiresidue pesticide analysis in fresh produce by capillary gas chromatography-<br>mass spectrometry/selective ion monitoring (GC-MS/SIM) and -tandem mass<br>spectrometry (GC-MS/MS).|Wong JW, Zhang K, Tech K, Hayward DG, Makovi<br>CM, Krynitsky AJ, Schenck FJ, Banerjee K, Dasgupta<br>S, Brown D.|2010|Não|
|Development of chemiluminescence enzyme-linked immunosorbent assay for the<br>screening of metolcarb and carbaryl in orange juice, cabbage and cucumber.|Sun JW, Zhang Y, Wang S.|2010|Não|
|Degradation of diazinon in apple juice by ultrasonic treatment.|Zhang Y, Zhang W, Liao X, Zhang J, Hou Y, Xiao Z,<br>Chen F, Hu X.|2010|Sim|
|Determination of the residues of 18 carbamate pesticides in chestnut and pine nut<br>by GPC cleanup and UPLC-MS-MS.|Lin QB, Xue YY, Song H.|2010|Não|  
140  
|Bayesian modelling of long-term dietary intakes from multiple sources.|Kennedy MC.|2010|Não|
|---|---|---|---|
|Degradation of bifenthrin and pirimiphos-methyl residues in stored wheat grains<br>(Triticum aestivum L.) by ozonation.|Savi GD, Piacentini KC, Bortolotto T, Scussel VM.|2016|Sim-Repetido|
|Food safety in Thailand. 3: Pesticide residues detected in mangosteen (Garcinia<br>mangostana L.), queen of fruits.|Phopin K, Wanwimolruk S, Prachayasittikul V.|2017|não|
|Integrated pest management of "Golden Delicious" apples.|Simončič A, Stopar M, Velikonja Bolta Š, Bavčar D,<br>Leskovšek R, Baša Česnik H.|2015|Sim|
|Dissipation kinetics of bifenazate in tea under tropical conditions.|Satheshkumar<br>A,<br>Senthurpandian<br>VK,<br>Shanmugaselvan VA.|2014|Não|
|Washing effects of limonene on pesticide residues in green peppers.|Lu HY, Shen Y, Sun X, Zhu H, Liu XJ.|2013|Sim|
|Removal of chloropyrifos ethyl, tetradifon and chlorothalonil pesticide residues<br>from citrus by using ozone.|Kusvuran E, Yildirim D, Mavruk F, Ceyhan M.|2012|Sim|
|Measured versus simulated dietary pesticide intakes in children.|Riederer AM, Lu C.|2012|Não|
|Reduction of pesticide residues on fresh vegetables with electrolyzed water<br>treatment.|Hao J, Wuyundalai, Liu H, Chen T, Zhou Y, Su YC, Li<br>L.|2011|Sim|  
141  
|Kinetic and thermodynamic investigation of mancozeb degradation in tomato|Certel M, Cengiz MF, Akçay M.|||
|---|---|---|---|
|homogenate during thermal processing.||2012|Sim|
|Residue content of carbaryl applied on greenhouse cucumbers and its reduction by<br>duration of a pre-harvest interval and post-harvest household processing.|Hassanzadeh N, Bahramifar N, Esmaili-Sari A.|2010|Sim|
|Simultaneous determination of residues of trichlorfon and dichlorvos in animal<br>tissues by LC-MS/MS.|Wang GM, Dai H, Li YG, Li XL, Zhang JZ, Zhang L,<br>Fu YY, Li ZG.|2010|Não|
|Degradation of bifenthrin and pirimiphos-methyl residues in stored wheat grains<br>(Triticum aestivum L.) by ozonation.|Savi GD, Piacentini KC, Bortolotto T, Scussel VM.|2016|Sim|
|Enhanced Dissipation of Triazole and Multiclass Pesticide Residues on Grapes<br>after Foliar Application of Grapevine-Associated Bacillus Species.|Salunkhe VP, Sawant IS, Banerjee K, Wadkar PN,<br>Sawant SD.|2015|Sim|
|Effect of Household Coffee Processing on Pesticide Residues as a Means of<br>Ensuring Consumers' Safety.|Mekonen S, Ambelu A, Spanoghe P.|2015|Sim|
|First report of the concentrations and implications of DDT residues in chicken eggs<br>from a malaria-controlled area.|Bouwman H, Bornman R, van Dyk C, Barnhoorn I.|2015|Não|
|Production of apple-based baby food: changes in pesticide residues.|Kovacova J, Kocourek V, Kohoutkova J, Lansky M,<br>Hajslova J.|2014|Sim|  
142  
|In-package nonthermal plasma degradation of pesticides on fresh produce.|Misra NN, Pankaj SK, Walsh T, O'Regan F, Bourke P,<br>Cullen PJ.|2014|Sim|
|---|---|---|---|
|Effect of fruit and vegetable processing on reduction of synthetic pyrethroid<br>residues.|Chauhan R, Kumari B, Rana MK.|2014|Sim|
|Potential of ozone utilization for reduction of pesticide residue in food of plant<br>origin. A review.|Balawejder M, Antos P, Sadło S.|2013|Sim|
|Stability of the pyrethroid pesticide bifenthrin in milled wheat during thermal<br>processing, yeast and lactic acid fermentation, and storage.|Dorđević TM, Šiler-Marinković SS, Ðurović RD,<br>Dimitrijević-Branković SI, Gajić Umiljendić JS.|2013|Sim|
|Reduction of pesticide residues in tomatoes and other produce.|Al-Taher F, Chen Y, Wylie P, Cappozzo J.|2013|Sim|
|Removal of chloropyrifos ethyl, tetradifon and chlorothalonil pesticide residues<br>from citrus by using ozone.|Kusvuran E, Yildirim D, Mavruk F, Ceyhan M.|2012|Sim-Repetido|
|Effect of home processing on the distribution and reduction of pesticide residues in<br>apples.|Kong Z, Shan W, Dong F, Liu X, Xu J, Li M, Zheng Y.|2012|Sim|
|Reduction of pesticide residues on fresh vegetables with electrolyzed water<br>treatment.|Hao J, Wuyundalai, Liu H, Chen T, Zhou Y, Su YC, Li<br>L.|2011|Sim-Repetido|
|Kinetic and thermodynamic investigation of mancozeb degradation in tomato<br>homogenate during thermal processing.|Certel M, Cengiz MF, Akçay M.|2012|Sim-Repetido|
|Evaluation of chlorine dioxide gas residues on selected food produce.|Trinetta V, Vaidya N, Linton R, Morgan M.|2011|Sim|  
143  
|Fate of three insect growth regulators (IGR) insecticides (flufenoxuron, lufenuron<br>and tebufenozide) in grapes following field application and through the wine-|Likas DT, Tsiropoulos NG.|2011|Sim|
|---|---|---|---|
|making process.||||
|Residue content of carbaryl applied on greenhouse cucumbers and its reduction by<br>duration of a pre-harvest interval and post-harvest household processing.|Hassanzadeh N, Bahramifar N, Esmaili-Sari A.|2010|Sim-Repetido|  
**Quadro I.4.3.2.** Concordância de inserção dos Artigos resultantes da busca sistemática no site **Cochrane Library,** para as perguntas PICO relacionadas à prevenção.  
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|International Epidemiological Differences in Acute Poisonings in Pediatric|Mintegi S, Azkunaga B, Prego J, Qureshi N, Dalziel|||
|Emergency Departments|SR, Arana-Arri E, Acedo Y, Martinez-Indart L,<br>Urkaregi A, Salmon N , Benito J and Kuppermann N|2017|Sim|
|A central storage facility to reduce pesticide suicides --a feasibility study from<br>India.|Vijayakumar L, Jeyaseelan L, Kumar S, Mohanraj R,<br>Devika S and Manikandan S|2013|Sim - Repetido|
|Interventions for preventing injuries in the agricultural industry|Risto Rautiainen, Marika M Lehtola, Lesley Margaret<br>Day, Eva Schonstein , Juha Suutarinen , Simo Salminen<br>and Jos H Verbeek|2008|Não|  
144  
145  
**Quadro III.3.3. Concordância de inserção dos Artigos resultantes da busca sistemática no site Lilacs - BVS, para as perguntas PICO relacionadas à prevenção.**  
|**Título**|**Autor**|**Ano**|**Estudo**<br>**considerado**|
|---|---|---|---|
|Caracterización de las exposiciones a plaguicidas entre los años 2006 y 2013<br>reportadas al Centro de Información Toxicológica de la Pontificia Universidad<br>Católica de Chile / Characterization of pesticide exposures reported between 2006<br>and 2013 to a poison information center in Chile|Gutiérrez, Waldo; Cerda, Patricia; Plaza-Plaza, José<br>Cristian; Mieres, Juan José; Paris, Enrique; Ríos, Juan<br>Carlos.|2015|Não|
|Intoxicación letal con aldicarb: análisis de sangre post mortem mediante LC-ESI-<br>MS/MS / Fatal intoxication with aldicarb: Analysis in post mortem blood by LC-<br>ESI-MS/MS|Mariño-Gaviria, Diana Jazmín; Patiño-Reyes, Nancy.|2015|Não|
|Modo de adquisición de plaguicidas y medicamentos en pacientes intoxicados<br>atendidos en emergencias del Hospital Clínico Viedma / Acquisition mode<br>pesticides and drugs in intoxicated patients treated in emergency Hospital Clínico<br>Viedma|Molina Cabrera, Rilma; Guillen Vargas, Germán.|2014|Sim|
|Intoxicação aguda por agrotóxicos anticolinesterásicos na cidade do Recife,<br>Pernambuco, 2007-2010 / Acute anticholinesterase pesticide poisoning in Recife,<br>Pernambuco State, Brazil, 2007-2010 / Intoxicación aguda por agrotóxicos<br>anticolinesterásicos en la ciudad de Recife, Pernambuco, 2007-2010|Medeiros, Márcia Noelle Cavalcante; Medeiros,<br>Marília Cavalcante; Silva, Maria Beatriz Araújo.|2014|Sim|  
146  
|Intoxicações por agrotóxicos de uso agrícola em estados do Nordeste brasileiro,|Teixeira, Jules Ramon Brito; Ferraz, Carla Eloá de|||
|---|---|---|---|
|1999-2009 / Agricultural pesticide poisoning in northeast brazilian states, 1999-<br>2009 / Intoxicaciones por pesticidas de uso agrícola en estados del Nordeste<br>brasileño, 1999-2009|Oliveira; Couto Filho, José Carlos Ferreira; Nery,<br>Adriana Alves; Casotti, Cezar Augusto.|2014|Sim|
|Caracterización de la intoxicación exógena en niños y adolescentes en Sogamoso,<br>Boyacá durante el período de 2010 a 2013 / Characterization of exogenous<br>poisoning in children and teenagers at Sogamoso, Boyacá, during the period 2010<br>to 2013|Galvis Pérez, Aura Lucia; Ospina Díaz, Juan Manuel;<br>Manrique Abril, Fred Gustavo.|2014|Sim|
|Intoxicación letal por Clorfenapir, un plaguicida derivado pirrólico. Reporte de un<br>caso / Chlorfenapyr lethal poisoning, a pesticide derived pyrrole. Case Report|Valdivia-Infantas,<br>Melinda<br>M; Rodriguez-Benites,<br>Adrian.|2014|Não|
|Intoxicações por agrotóxicos na mesorregião norte central paranaense, Brasil -<br>2002 a 2011 / Intoxication due to pesticides in the central northern region of the<br>State of Paraná, Brazil - 2002 to 2011|Neves, Pedro Dias Mangolini; Bellini, Marcella.|2013|Sim|
|Mortalidade por intoxicacao ocupacional relacionada a agrotoxicos, 2000-2009,<br>Brasil / Occupational pesticide poisoning mortality, 2000-2009, Brazil / Mortalidad<br>por intoxicacion ocupacional relacionada con agrotoxicos, 2000-2009, Brasil|Santana, Vilma Sousa; Moura, Maria Claudia Peres;<br>Nogueira, Flavia Ferreira e.|2013|Sim|
|Intoxicações por agrotóxicos na Mesorregião Norte Central Paranaense 2007 a<br>2011 / Intoxication by pesticides in Parana North Central Mesoregion 2007 to 2011|Neves, Pedro Dias Mangolini; Bellini, Marcella.|2012|Sim|
|Comportamiento de la intoxicación por sustancias químicas, medicamentos y<br>sustancias psicoactivas en Colombia, 2010, reportados en Sivigila / Behavior of|Urrego Novoa, José Ricardo; Díaz Rojas, Jorge<br>Augusto.|2012|Sim|  
147  
|poisoning due to chemical compounds, drugs and psychoactive substances in||||
|---|---|---|---|
|Colombia during 2010 according to Sivigila||||
|Suicide attempts by exogenous intoxication among female adolescents treated at a<br>reference hospital in the city of Recife-PE, Brazil / Tentativas de suicídio por<br>intoxicação exógena em adolescentes do sexo feminino atendidas em um hospital<br>de referência de Recife-PE, Brasil / Tentativas de suicidio por intoxicación exógena<br>de adolescentes del sexo femenino atendidas en un hospital de referencia en la<br>ciudad de Recife-PE, Brasil|Veras, Juliana Lourenço de Araújo; Katz, Cintia<br>Regina Tornisiello.|2011|Sim|
|Intoxicações por agrotóxicos notificadas na 11ª regional desaúde do estado do<br>paraná / Poisoning pesticides registered in the 11th health regional of paranástate /<br>Intoxicación por herbicidas notificados a la 11ª regional de salud delestado de<br>paraná|Scardoelli, Márcia Glaciela da Cruz; Buriola, Aline<br>Aparecida; Oliveira, Magda Lúcia Félix de; Waidman,<br>Maria Angélica Pagliarini.|2011|Não|
|Intoxicação por agrotóxicos no Distrito Federal, Brasil, de 2004 a 2007 - análise da<br>notificação ao Centro de Informação e Assistência Toxicológica / Intoxication due<br>to pesticides in the Federal District of Brazil between 2004 and 2007 -analysis of<br>notification to the Toxicological Information and Assistance Center|Rebelo,<br>Fernanda<br>Maciel; Caldas,<br>Eloísa<br>Dutra; Heliodoro, Viviane de Oliveira; Rebelo, Rafaela<br>Maciel.|2011|Não|
|Intoxicação exógena por chumbinho como forma de autoextermínio no Estado de<br>Goiás, 2003 - 2007 / Exogenous intoxication by chumbinho (lead) as a form of self-<br>extermination in the State of Goiás (Brazil), 2003 - 2007 / Intoxicación exógena<br>por raticida (chumbinho) como forma de auto exterminio en el estado de Goiás,<br>2003 - 2007|Silva, Anna Carolina Sousa da; Vilela, Fábio<br>Paulo; Brandão,<br>Graciela<br>Mara<br>Ordones<br>do<br>Nascimento.|2011|Não|  
148  
|Espontánea reversibilidad de un síndrome de parkinson tardío y de alteraciones|Toledo L., Paola; Bustamante F., Gonzalo; Cartier R.,|||
|---|---|---|---|
|cognitivas frontales; después de una intoxicación aguda con órganofosforados /<br>Reversible parkinson syndrome and cognitive impairments due organophosphate<br>acute poisoning|Luis.|2010|Não|
|Edema pulmonar neurogénico posconvulsión secundario a intoxicación aguda<br>intencional por pesticida organoclorado en una suicida adolescente / Posictal<br>neurogenic pulmonary edema secondary to acute poisoning by organochlorine<br>pesticide in an adolescent suicide attempt|Marín, Gustavo Roberto; Baspineiro, Berta.|2010|Não|
|Pacientes atendidos en un Centro Toxicológico de Venezuela / Patients attended at<br>a Venezuelan Toxicology Centre|Tagliaferro, Zulay A; Bracamonte, Giannina.|2010|Sim|
|Autopercepção de dificuldade auditiva, hábitos e fatores de risco para perda<br>auditiva em agricultores / Self-perception of hearing disorders, habits, and hearing<br>loss risk factors in farmers|Stadler,<br>Suzelaine<br>Taize; Ribeiro,<br>Vanessa<br>Veis; França, Denise Maria Vaz Romano.|2016|Não|
|Perfil socioeconômico de trabalhadores rurais portadores de neoplasia / Perfil<br>socioeconómico de los trabajadores rurales portadores de neoplasia /<br>Socioeconomic profile of rural workers cancer sufferers|Silva,<br>Adrielle<br>Chermont<br>da; Camponogara,<br>Silviamar; Viero, Cibelle Mello; Menegat, Robriane<br>Prosdocimi; Dias,<br>Gisele<br>Loise; Miorin,<br>Jeanini<br>Dalcol.|2016|Não|
|Accidental intoxication of the infant-juvenile population in households: profiles of<br>emergency care / Intoxicación Accidental En La Población infanto-juvenil En<br>Ambiente Domiciliario: Perfil De Las Atenciones De Emergencia / Intoxicação|Brito,<br>Jackeline<br>Gonçalves; Martins,<br>Christine<br>Baccarat de Godoy.|2015|Não|  
149  
|acidental na população infanto-juvenil em ambiente domiciliar: perfil dos<br>atendimentos de emergência||||
|---|---|---|---|
|Trabalho rural e riscos à saúde: uma revisão sobre o "uso seguro" de agrotóxicos<br>no Brasil / Rural work and health risks: a review into de "safe use" of pesticides in<br>Brazil|Abreu, Pedro Henrique Barbosa de; Alonzo, Herling<br>Gregorio Aguilar.|2014|Sim|
|Uso de agrotóxicos e a relação com a saúde na etnia Xukuru do Ororubá,<br>Pernambuco, Brasil / The pesticide use and health in the Xukuru from Ororubá<br>ethnic group, Pernambuco, Brasil|Gonçalves, Glaciene Mary da Silva; Gurgel, Idê<br>Gomes Dantas; Costa, André Monteiro; Almeida,<br>Ludimila Raupp de;Lima, Tatiane Fernandes Portal<br>de; Silva, Edson.|2012|Sim|
|Perfil do uso populacional de inseticidas domésticos no combate a mosquitos /<br>Profile of the population use of household insecticides against mosquitoes|Oliveira, Luzilene Barbosa de; Nunes, Rafaela Maria<br>Pessoa; Santana, Claudiana Mangabeira; Costa,<br>Antônia Rosa da; Nunes, Narcia Mariana Fonseca;<br>Calou, Iana Bantim Felicio; Peron, Ana Paula;<br>Marques, Marcia Maria Mendes; Ferreira, Paulo<br>Michel Pinheiro.|2015|Sim|
|Caracterização do controle de Haematobia irritans e Rhipicephalus (Boophilus)<br>microplus no Triângulo Mineiro e Alto Paranaíba, Minas Gerais / Characterization<br>of Haematobia irritans and Rhipicephalus (Boophilus) microplus control in<br>Triângulo Mineiro and Alto Paranaíba, Minas Gerais|Domingues, Luísa N; Bello, Ana C. P. P; Cunha, Arildo<br>P; Leite, Patrícia V. B; Barros, Antonio T. M; Leite,<br>Romário C.|2012|Não|  
150  
|Vulnerabilidades de trabalhadores rurais frente ao uso de agrotóxicos na produção|Preza, Débora de Lucca Chaves; Augusto, Lia Giraldo|||
|---|---|---|---|
|de hortaliças em região do Nordeste do Brasil / Farm workers' vulnerability due to<br>the pesticide use on vegetable plantations in the Northeastern region of Brazil|da Silva.|2012|Sim|
|Análise da eficiência dos equipamentos de proteção individuais utilizados no<br>controle químico do mosquito vetor da dengue (Aedes aegypti) / Analysis of the<br>effectiveness of personal protective equipment used in the chemical control of the<br>mosquito vector of dengue (Aedes aegypti)|Melo, Carlos Frederico Campelo de Albuquerque e.|2012|Não|
|Sintomas associados à exposição aos agrotóxicos entre rizicultores em uma cidade<br>no sul de Santa Catarina.|Savi, Eduardo Pereira; Sakae, Thiago Mamôru ;<br>Candemil, Renan ; Sakae, Diana Yae ; Remor, Karina<br>Valerim Teixeira.|2010|Sim|
|Perfil audiológico de pilotos agrícolas / Agricultural pilot's audiological profile|Foltz, Lucas; Soares, Carla Debus; Reichembach,<br>Maria Adelaide Kuhl.|2010|Não|
|Análisis epidemiológico y clínico de intoxicaciones agudas atendidas en montería,|Guzmán<br>Terán,<br>Camilo; Villa<br>Dangond,|||
|Colombia / Analysis epidemiology and clinical of acute poisoning of served in<br>monteria, Colombia|Hiltony; Calderón Rangel, Alfonso.|2015|Sim|
|Accidental intoxication of the infant-juvenile population in households: profiles of<br>emergency care / Intoxicación Accidental En La Población infanto-juvenil En<br>Ambiente Domiciliario: Perfil De Las Atenciones De Emergencia / Intoxicação<br>acidental na população infanto-juvenil em ambiente domiciliar: perfil dos<br>atendimentos de emergência|Brito,<br>Jackeline<br>Gonçalves; Martins,<br>Christine<br>Baccarat de Godoy.|2015|Não|  
151  
|Intoxicações na infância:panorama geral do perfil das intoxicações em diferentes|Vilaça, Luciana; Cardoso, Poliana Renata.|||
|---|---|---|---|
|países / Poisoning among children: an overview of the profile of poisonings in<br>different countries||2014|Sim|
|Mortalidade por intoxicacao ocupacional relacionada a agrotoxicos, 2000-2009,<br>Brasil / Occupational pesticide poisoning mortality, 2000-2009, Brazil / Mortalidad<br>por intoxicacion ocupacional relacionada con agrotoxicos, 2000-2009, Brasil|Santana,<br>Vilma<br>Sousa; Moura,<br>Maria<br>Claudia<br>Peres; Nogueira, Flavia Ferreira e.|2013|Sim- Repetido|
|Avaliação das intoxicações por domissanitários em uma cidade do Nordeste do<br>Brasil / Poisoning with household cleaning products in a city in Northeast Brazil /<br>Evaluación de las intoxicaciones por productos domésticos en una ciudad del<br>Nordeste de Brasil|Fook, Sayonara Maria Lia; Azevedo, Esthefanye<br>Fernandes de; Costa, Monalisa Maciel; Feitosa,<br>Itavielly Layany França; Bragagnoli, Gerson; Mariz,<br>Saulo Rios.|2013|Sim|
|Caracterización del perfil epidemiológico de las llamadas al Centro de Información<br>Toxicológica de la Universidad Católica (CITUC), en el año 2010 /<br>Characterization of the epidemiological profile of calls received at the Poison<br>Information Center of the Catholic University (CITUC), in 2010|Bettini, M; Araya, A; Mieres, J; Cerda, P; Bravo, V;<br>Silva, L; Gallardo, A; Paris, E; Ríos, J.|2013|Sim|
|Organochlorine compound levels in fertile and infertile women from Rio de<br>Janeiro, Brazil / Níveis de substâncias organocloradas em mulheres férteis e<br>inférteis do Rio de Janeiro, Brasil|Bastos, Ana Marcia Xavier et al|2013|Sim|
|Residuos de plaguicidas organofosforados y carbamatos en aguas subterráneas de|Sánchez,<br>Victoria<br>Guadalupe; Gutiérrez,<br>César|||
|bebida en las zonas rurales de Plottier y Senillosa, Patagonia Norte, Argentina /<br>Organophosphate and carbamate pesticide residues in drinking groundwater in the<br>rural areas of Plottier and Senillosa, North Patagonia, Argentina|Argentino; Gomez,<br>Diego<br>Sebastian; Loewy,<br>Miriam; Guiñazú, Natalia.|2016|Não|  
152  
|Determinación de residuos de plaguicidas en trabajadores agrícolas del municipio|Gutiérrez,<br>Jorge; Parra,<br>Claudia; Blach,|||
|---|---|---|---|
|de Barcelona, Quindío, Colombia / Determination of pesticide levels in farmers<br>working in the Barcelona municipality, Quindio, Colombia|Diana; Zuluaga,<br>Diana; Zárate,<br>Mélida; Rojas,<br>Andrés; Nieto, Marco; Londoño, Alfonso.|2014|Sim|
|Inspección preliminar de algunas características de toxicidad en el agua potable<br>domiciliaria, Bogotá y Soacha, 2012 / Preliminary survey to detect toxic substances<br>in domestic potable water, Bogotá and Soacha, 2012|Silva, Elizabeth; Villarreal, María Elsa; Cárdenas,<br>Omayda; Cristancho, Carlos Armando; Murillo,<br>Carmenza; Salgado, Manuel Alberto; Nava, Gerardo.|2015|Não|
|Comparación de dos metodologías para la determinación de residuos de<br>plaguicidas en agua potable|Guerrero Dallos, Jairo Arturo; Velandia Rodriguez,<br>Nancy Yohanna.|2014|Não|
|Desarrollo y optimizacion de una metodologia multiresiduo por metodo Simplex<br>para el analisis de plaguicidas en miel de abejas / Development and optimization<br>of a multiresidue method for pesticide analysis in honey bee using Simplex method|Rodriguez, Danny; Diaz, Amanda C.; Ahumada, Diego<br>A.; Guerrero, Jairo A.|2014|Não|
|Comparación de dos aproximaciones para la estimación de la incertidumbre en<br>análisis de residuos de plaguicidas mediante cromatografía de gases / Comparison<br>of two approaches to estimate the uncertainty for pesticide residue analysis by gas<br>cromatography / Comparação de dois métodos para a estimativa da incerteza<br>análise de resíduos por cromatografia gasosa|Ahumada, Diego A; Aparicio, Llarys W; Fuentes, Jean<br>C; Guerrero, Jairo A; Checa, Brenda I.|2012|Não|
|Intoxicaciones agudas por plaguicidas consultadas al Centro Nacional de|Pérez<br>Rodríguez,<br>Sonia; Álvarez<br>Delgado,|||
|Toxicología durante el bienio 2007-2008 / Acute pesticide poisoning assited at the<br>National Toxicology Centre from 2007-2008|Maylén; Baldo, Marlene David; Capote Marrero,<br>Belina.|2012|Não|  
153  
|Resíduos de inseticidas organonofosforados: validação de método e ocorrência em|Amaral, Eliane Hooper; Soares, Alexandre Augusto;|||
|---|---|---|---|
|hortícolas / Residues of inseticides organophosphorus: method validation and<br>occurrence in vegetables|Sousa, Leandro Augusto Ferreira de; Souza, Scheilla<br>Vitorino Carvalho de; Junqueira, Roberto Gonçalves.|2012|Não|
|Impacto en la salud y el medio ambiente por exposición a plaguicidas e<br>implementación de buenas prácticas agrícolas en el cultivo de tomate, Colombia,<br>2011 / Impact on health and environment of exposure to pesticides and<br>implementation of best agricultural practices in tomato production, Colombia, 2011|Varona Uribe, Marcela; Castro, René A; Paéz, Martha<br>Isabel; Carvajal, Natalia; Barbosa, Edwin; León, Lina<br>María; Díaz, Sonia Mireya.|2012|Sim|
|Residuos de plaguicidas en aguas para consumo humano en una comunidad<br>agrícola del estado Mérida, Venezuela / Pesticide residues in drinking water of an<br>agricultural community in the state of Mérida, Venezuela|Flores-García, Mery Elisa; Molina-Morales, Yuri;<br>Balza-Quintero, Alirio; Benítez-Díaz, Pedro Rafael;<br>Miranda-Contreras, Leticia.|2011|Sim - Repetido|
|Estudio de caracterización de la calidad microbiológica yfisicoquímica del agua|Silva, Elizabeth; Ortiz, Jaime Eduardo; Murillo,|||
|utilizada en la industria de alimentos, Colombia, 2007 / Microbiological and<br>chemical quality of water used in Colombian food industries|Carmenza; Nava, Gerardo; Cárdenas, Omayda; Peralta,<br>Alejandro; Paredez, Marta; Piñeros, Karina; Otálora,<br>Andrés.|2010|Não|  
154

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.5 - Avaliação pelo método GRADE** -->
#### **ANEXO I.5.1 -TRATAMENTO**  
**Quadro I.5.1.1. Avaliação das evidências pelo método GRADE sobre o impacto da “Assistência remota” como tratamento inicial hospitalar ou pré-hospitalar para pacientes com intoxicação aguda por agrotóxicos considerando o tempo de internação.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo. O artigo utilizado para a avaliação de evidências sobre Assistência remota por GRADE foi obtido pela busca sistemática.  
|**№ dos**<br>**estudos**<br>Tempo d<br>|**Delineamento**<br>**do estudo**<br>e internação (ava<br>|**A**<br>**Risco de**<br>**viés**<br>liado com:<br>|**valiação da Qu**<br>**Inconsistência**<br>média de dias)<br>|**alidade**<br>**Evidência**<br>**indireta**<br>|**Imprecisão**<br>|**Outras**<br>**considerações**<br>|**Impacto**<br>|**Certainty**<br>|**Importância**<br>|
|---|---|---|---|---|---|---|---|---|---|
|1|estudos<br>observacionais|grave<sup>a,b</sup>|não grave|não grave|não grave|todos<br>os<br>potenciais<br>fatores<br>de<br>confusão<br>reduziriam<br>o<br>efeito<br>demonstrado|Pacientes que receberam auxílio do centro de controle de<br>intoxicações permaneceram internados por uma média de<br>5,50 ± 6,20 dias, enquanto os pacientes sem auxílio do<br>centro permaneceram internados por uma média de 8,46<br>± 12,50 dias. A diferença média entre os dois grupos foi<br>de -3,43 dias (intervalo de confiança de 95%, IC: -6,10 a<br>-0,77), revelando assim que os pacientes com assistência<br>remota<br>do<br>centro<br>de<br>controle<br>de<br>intoxicação<br>permaneceram hospitalizados por períodos mais curtos do<br>que os pacientes que não receberam tal auxílio|⨁⨁`◯◯`<br>BAIXA|IMPORTANTE|  
155  
#### **Explicações**  
a. Informação insuficiente sobre o processo de geração da sequência aleatória que permitiu a seleção dos pacientes. Segundo os autores, o critério de seleção utilizado foi constar no prontuário a intoxicação como motivo primário da internação  
b. Não ficou claro a distribuição da gravidade no grupo final selecionado e nem a distribuição dos pacientes nos dois grupos avaliados  
#### **_Referências:_**  
1. Galvão, T. F., Silva, M. T., Silva, C. D., Barotto, A. M., Gavioli, I. L., Bucaretchi, F., Atallah, A. N. Impact of a poison control center on the length of hospital stay of poisoned patients: retrospective cohort. São Paulo Med J; 2011.  
**Quadro I.5.1.2. Avaliação das evidências pelo método GRADE sobre “Lavagem Gástrica” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos. Foi utilizada a ferramenta GRADEpro GDT.** O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo. O artigo utilizado para a avaliação de evidências sobre Lavagem gástrica por GRADE foi obtido pela adição manual.  
|||**Avaliação da qu**|**alidade**||**№ de p**|**acientes**<br>**Efei**|**to**||
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**<br>**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**<br>**Outras**<br>**considerações**|**Lavagem**<br>**gástrica**<br>**múltipla**|**Lavagem**<br>**gástrica**<br>**simples**<br>**Relativo**<br>**(95% CI)**|**Qualidade**<br>**Absoluto**<br>**(95%**<br>**CI)**|**Importância**|  
Mortalidade (avaliado com: Proporção)  
156  
||||**Avaliação da qu**|**alidade**|||**№ de p**|**acientes**|**Efei**|**to**|||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Lavagem**<br>**gástrica**<br>**múltipla**|**Lavagem**<br>**gástrica**<br>**simples**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95%**<br>**CI)**|**Qualidade**|**Importância**|
|6<br>1,2,3,4,5,6<br>Insuficiê|ensaios<br>clínicos<br>randomizados<br>ncia respiratória (|muito<br>grave<sup>a</sup><br>avaliado co|muito grave<sup>b</sup><br>m: Proporção)|grave<sup>c</sup>|grave<sup>d</sup>|forte associação<br>todos<br>os<br>potenciais fatores<br>de<br>confusão<br>sugeririam<br>um<br>efeito espúrio e,<br>mesmo<br>assim,<br>nenhum efeito foi<br>observado.|22/302<br>(7.3%)|64/284<br>(22.5%)|não<br>estimável||⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|
|2<sup>1,5</sup>|ensaios<br>clínicos<br>randomizados|muito<br>grave<sup>1,5,a</sup>|muito grave<sup>b</sup>|grave<sup>e</sup>|grave<sup>d</sup>|forte associação<br>todos<br>os<br>potenciais fatores<br>de<br>confusão<br>sugeririam<br>um<br>efeito espúrio e,<br>mesmo<br>assim,<br>nenhum efeito foi<br>observado.|10/253<br>(4.0%)|25/241<br>(10.4%)|não<br>estimável||⨁`◯◯◯`<br>MUITO<br>BAIXA|CRÍTICO|  
**CI:** Intervalo de confiança  
157  
#### **Explicações**  
a. Estudos de uma mesma revisão sistemática com intervenções diversas com metodologias descritas inadequadamente e erros metodológicos segundo o autor da revisão. Não foram localizados os artigos primários.  
b. Diferenças importantes nas estimativas de efeito.  
c. Estudos realizados para avalição de lavagem gástrica múltipla.  
- d. Pequenos tamanhos de amostra.  
e. Estudos realizados para avaliação de lavagem gástrica múltipla.  
#### **Referências**  
1.  xX, Ji. The impact of different gastric lavage on the mortality of acute organophosphate poisoning. Med Theory Pract; 2000.  
2. You LH, Zeng Q. The experience of repeated gastric lavage in acute organophosphate poisoning. Sichuan Med; 2002.  
3. Luo QH, Liao LQ,He B,Liao J,Lu WH. The observation of multiple gastric lavages in acute organophosphates posioning. Sichuan Med J; 2002.  
4. Li YH, Zhang YX. Effect of repeated gastric lavage on the blood cholinesterase activity in organophosphorus pesticide poisoning. Nurs Mag; 2000.  
5. Zhang PY, Seng MQ,Dong XQ,Yao YC,Wang XZ. The analysis of different gastric lavages in treatment of acute organophosphate poisoning. J Pract Nur; 2002.  
6. Luo FQ, Xie LW,Teng XL. Research on multiple gastric lavages in severe organphosphate poiosoning. China J Mod Med; 2005.  
**Quadro I.5.1.2.1. Avaliação do risco de viés para o desfecho mortalidade relacionada a “lavagem gástrica” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
158  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de…<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.1.2.1. Avaliação do risco de viés para o desfecho insuficiência respiratória relacionada a “lavagem gástrica” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
159  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de…<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.1.3. Avaliação das evidências pelo método GRADE sobre o uso de “Carvão Ativado” como medida de descontaminação ou eliminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|||||**Uso de uma**|**única dose de**|**carvão ativado co**|**mparando co**|**m a não utiliz**|**ação**||||
|---|---|---|---|---|---|---|---|---|---|---|---|---|
||||**Avaliação da Ev**|**idência**|||**№ dep **|**acientes**|**Ef**|**eito**|||
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**uma única**<br>**dose de**<br>**carvão**<br>**ativado**|**nenhuma**<br>**dose de**<br>**carvão**<br>**ativado**|**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|**Importância**|
|Desfecho|: Mortalidade||||||||||||  
160  
<!-- Start of picture text -->
Uso de uma única dose de carvão ativado com p arando com a não utiliza ç ão<br>Avalia ç ão da Evidência  № de  p acientes  Efeito<br>uma única  nenhuma<br>№ dos  Delineamento  Risco de  Evidência  Outras  dose de  dose de  Relativo  Absoluto  Evidência  Importância<br>Inconsistência  Imprecisão<br>estudos  do estudo  viés  indireta  considerações  carvão  carvão  (95% CI)  (95% CI)<br>ativado  ativado<br>1   ensaios  grave  não grave   não grave  não grave   todos  os  109/1544  105/1554  OR 1.05 3 mais por  ⨁⨁⨁⨁ CRÍTICO<br>clínicos  a,b,c,d,e potenciais fatores  (7.1%)   (0.79 para  1.000 ALTA<br>randomizados   de  confusão  (6.8%)  1.40)   (de 13 menos<br>reduziriam  o  para 25<br>efeito  mais)<br>demonstrado<br><!-- End of picture text -->  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Usos**<br>**Inconsistência**|**de múltipla**<br>**Evidência**<br>**indireta**|**s doses de ca**<br>**Imprecisão**|**rvão ativado compa**<br>**Outras**<br>**considerações**|**rando com o**<br>**múltiplas**<br>**doses de**<br>**carvão**<br>**ativado**|**uso de uma ún**<br>**dose única**<br>**de carvão**<br>**ativado**|**ica dose**<br>**Relativo**<br>**(95% CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|<br>**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Desfech|o: Mortalidade||||||||||||
|1|ensaios<br>clínicos<br>randomizados|grave<br>1,a,b,c,d|não grave|não grave|não grave|todos<br>os<br>potenciais fatores<br>de<br>confusão<br>reduziriam<br>o<br>efeito<br>demonstrado|97/1531<br>(6.3%)|109/1544<br>(7.1%)|**OR 0.89**<br>(0.66 para<br>1.19)|**7 menos por**<br>**1.000**<br>(de 12 mais<br>para 23<br>menos)|⨁⨁⨁⨁<br>ALTA|CRÍTICO|  
161  
##### **Usos de múlti** **<mark>p</mark> las doses de carvão ativado com** **<mark>p</mark> arando com a não utiliza** **<mark>ç</mark> ão**  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras considerações**|**múltiplas**<br>**doses de**<br>**carvão**<br>**ativado**|**nenhuma**<br>**dose**|**Relativo**<br>**(95%**<br>**CI)**|**Absoluto**<br>**(95% CI)**|**Evidência**|<br>**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|
|Desfecho|: Mortalidade||||||||||||
|1|ensaios clínicos<br>randomizados|grave<br>a,b|não grave|não grave|não grave|todos<br>os<br>potenciais<br>fatores de confusão<br>reduziriam<br>o<br>efeito<br>demonstrado|97/1531<br>(6.3%)|105/1554<br>(6.8%)|**OR 0.93**<br>(0.69<br>para<br>1.25)|**4 menos**<br>**por 1.000**<br>(de 15 mais<br>para 20<br>menos)|⨁⨁⨁⨁<br>ALTA|CRÍTICO|  
#### **Explicações**  
- _a._ Não cegamento da avaliação do desfecho  
- _b._ Estudo aberto  
- c. Tempo de admissão dos pacientes na unidade era variável, o que poderia reduzir a efetividade da intervenção  
- d. Protocolo institucional prevê lavagem gástrica em pacientes intoxicados  
#### **Referências**  
1. Eddleston M, Juszczak E, Buckley NA, Senarathna L, Mohamed F, Dissanayake W, et al. Multiple-dose activated charcoal in acute self-poisoning: a randomised controlled trial. Lancet (London, England). England; 2008 Feb;371(9612):579–87.  
**Quadro I.5.1.4. Avaliação das evidências pelo método GRADE sobre o uso da “Irrigação Intestinal Total” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
162  
|||**A**|**valiação daq **|**ualidade**||||**Qualidade**|
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco de**<br>**viés**|**Inconsistê**<br>**ncia**|**Evidência**<br>**indireta**|**Imprecisã**<br>**o**|**Outras**<br>**considerações**|**Sumário de Resultados**||
|**Gravidade**|||||||||
|4<sup>1,2,3,4</sup>|ensaios clínicos<br>randomizados|grave<sup>a</sup>|grave<sup>b</sup>|Muito grave<sup>c</sup>|não grave|nenhum|Estudos crossover, em voluntários, realizados<br>com medicamentos em cápsulas de liberação<br>sustentada ou retardada. No entanto, esses<br>estudos<br>apresentam<br>evidências<br>inconsistentes: dois estudos mostraram a<br>efetividade do procedimento, um mostrou<br>que o tratamento não foi efetivo, e o outro que<br>não houve aumento da efetividade quando o<br>tratamento foi administrado junto com carvão<br>ativado, podendo inclusive reduzir a eficácia<br>do carvão ativado para alguns medicamentos.<br>Até o momento, faltam evidências de<br>qualidade<br>mostrando<br>a<br>melhora<br>dos<br>desfechos clínicos com a técnica de irrigação<br>intestinal total|⨁`◯◯◯`<br>MUITO BAIXA|  
#### **Explicações**  
a. São todos estudos com voluntários, e em alguns casos poucas informações são fornecidas sobre a randomização e aleatorização.  
b. Dois estudos mostraram a eficácia de WBI, dois mostraram que não foi eficaz, e 1 mostrou que não houve aumento da eficácia quando administrado junto com carvão ativado, podendo inclusive reduzir a eficácia do carvão ativado para carbamazepina.  
c. Os estudos são, em sua maioria, de avaliação farmacocinética e tinham como objetivo a recuperação do produto administrado por via oral. Considerando o desfecho estabelecido, associa-se que a maior eliminação de produto decorre da sua menor absorção e, consequentemente, redução de seus efeitos.  
#### **Referências**  
1. Kirshenbaum LA , Mathews SC , Sitar DS , Tenenbein M . Whole bowel irrigation versus activated charcoal in sorbitol for the ingestion of modified-release pharmaceuticals . Clin Pharmacol Ther 1989; 46 : 264 – 271  
2. Smith S W, L ing L J, H alstenson C E. W hole bowel irrigation as a treatment for acute lithium overdose . Ann Emerg Med 1991 ; 20 : 536 – 539.  
3. Ly B T, Schneir A B, C lark R F. E ffect of whole bowel irrigation on the pharmacokinetics of an acetaminophen formulation and progression of radiopaque markers through the gastrointestinal tract . Ann Emerg Med 2004 ; 43 : 189 – 195  
4. Lapatto-Reiniluoto O , K ivisto K T, N euvonen P J. A ctivated charcoal alone and followed by whole bowel irrigation in preventing the absorption of sustained-release drugs. Clin Pharmacol Ther 2001; 70: 255– 260.5.  
163  
**Quadro I.5.1.4.1. Avaliação do risco de viés para a biodisponibilidade de compostos após a utilização da “Irrigação Intestinal Total” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de seleção)<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
164  
**Quadro I.5.1.5. Avaliação das evidências pelo método GRADE sobre a indução do “Vômito por meio da administração de xarope de ipeca” como medida de descontaminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
**Contexto** : A irrigação intestinal total é uma medida de descontaminação que consiste na administração, por meio de sonda nasoenteral, de grandes quantidades de uma solução osmoticamente equilibrada (polietilenoglicol). O objetivo é limpar fisicamente o tóxico até a sua completa eliminação por via retal, impedindo assim a sua absorção pelo trato gastrintestinal 64. A técnica tem sido considerada de grande valia para os casos onde há ingestão de quantidades potencialmente tóxicas de drogas de liberação prolongada ou formuladas com camada entérica. Também se mostra efetiva para substâncias não adsorvíveis por carvão ativado (como ferro, lítio ou potássio), dada a alta mortalidade dessas substâncias e a carência de outras opções para a descontaminação gastrintestinal nesses casos  
#### **Bibliografia** :  
|**№ dos**<br>**estudos**<br>Complic|**Delineamento**<br>**do estudo**<br>ações Clínicas|**Risco**<br>**de viés**|**Certainty asses**<br>**Inconsistência**|**sment**<br> <br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de pac**<br>**o xarope**<br>**de ipeca**<br>**para a**<br>**indução**<br>**do vômito**|**ientes**<br>**não**<br>**utilizá-**<br>**lo**|**Ef**<br>**Relativo**<br>**(95%**<br>**CI)**|**eito**<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certainty**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|---|  
165  
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Certainty assess**<br>**Inconsistência**|**ment**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**№ de pacientes**<br>**o xarope**<br>**de ipeca**<br>**para a**<br>**indução**<br>**do vômito**<br>**não**<br>**utilizá-**<br>**lo**|**Ef**<br>**Relativo**<br>**(95%**<br>**CI)**|**eito**<br>**Absoluto**<br>**(95%**<br>**CI)**|**Certainty**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|---|---|
|1|ensaios<br>clínicos<br>randomizados|grave<br>1,a,b|não grave|muito<br>grave<sup>1,c</sup>|não grave|todos<br>os<br>potenciais<br>fatores<br>de<br>confusão<br>sugeririam um<br>efeito espúrio e,<br>mesmo assim,<br>nenhum efeito<br>foi observado.|Estudo realizado<br>intoxicados<br>com<br>comparou a efetivid<br>gástrico (xarope de<br>gástrica) prévio à ad<br>ativado e a administr<br>ativado. Os resulta<br>ambos<br>têm<br>benef<br>considerando<br>que<br>satisfatórios podem<br>nenhum procedimen<br>gástrico seja realizad<br>em<br>pacientes<br>medicamentos 62|com 592<br>diversos<br>ade do esv<br>ipeca ou<br>ministração<br>ação apena<br>dos indic<br>ícios<br>que<br>desfechos<br>ser obtido<br>to de esv<br>o de form<br>intoxicad|pacientes<br>fármacos<br>aziamento<br>lavagem<br>de carvão<br>s de carvão<br>aram que<br>stionáveis,<br> <br>clínicos<br>s sem que<br>aziamento<br>a rotineira<br>os<br>por|⨁⨁`◯◯`<br>BAIXA|IMPORTANTE|  
**CI:** Confidence interval  
166  
#### **Explicações**  
- a. Método de alocação e randomização não adequados  
- b. Pacientes com intoxicações diversas e com o tempo de atendimento variado  
- c. Agentes diversos, sendo esses principalmente medicamentos  
#### **Referências**  
1. Kulig K, Bar-or D,Cantrill S V,Rosen P,Rumack BH,Hospital DG,et al.. Management of acutely poisoned patients without gastric emptying. . Annals of Emergency Medicine; 1985.  
167  
**Quadro I.5.1.6. Avaliação das evidências pelo método GRADE sobre “Catárticos” como medida de eliminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|||**Av**|**aliação daquali**|**dade**||||**Qualidade**|
|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento do**<br>**estudo**|**Risco de**<br>**viés**|**Inconsistênci**<br>**a**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário de Resultados**||
|**Gravidade**|||||||||
|5<sup>1,2,3</sup>|ensaios<br>clínicos<br>randomizados|grave<sup>a</sup>|não grave|Muito grave<sup>b</sup>|grave<sup>c</sup>|nenhum|Não foram encontrados ensaios clínicos randomizados controlados<br>sobre a utilização de catárticos para o tratamento de pacientes com<br>intoxicação aguda por agrotóxicos. Por outro lado, a partir de revisão<br>sistemática, três estudos clínicos randomizados com evidências sobre o<br>uso de**catártico sozinho**como medida de eliminação corpórea de<br>medicamentos emergiram na busca. Todos antigos, com um número<br>muito limitado de voluntários, e que mostraram que o catártico sozinho<br>não reduz a absorção do agente|⨁`◯◯◯`<br>MUITO<br>BAIXA|  
#### **Explicações**  
a. São todos estudos com voluntários, e poucas informações são fornecidas sobre a randomização e aleatorização.  
b. Estudos com fármacos de liberação sustentada ou retardada, e não com agrotóxicos.  
c. Grupos pequenos.  
#### **Referências**  
1. Sorensen PN. The effect of magnesium sulfate on the absorption of acetylsalicylic acid and lithium carbonate from the human intestine. Arch Toxicol. Springer;1975;34(2):121-7.  
2. Al-Shareef AH, Buss DC, Allen EM, Routledge PA. The effects of charcoal and sorbitol (alone and in combination) on plasma theophylline concentrations after a sustainedrelease formulation. Hum Exp Toxicol. Sage Publications Sage CA: Thousand Oaks, CA; 1990;9(3):179–82.  
3. Minton NA, Hentry JA. Prevention of drug absorption in simulated theophylline overdose. J Toxicol Clin Toxicol. Taylor & Francis; 1995;33(1):43–9.  
**Quadro I.5.1.6.1. Avaliação do risco de viés sobre a efetividade na redução da absorção após o uso de Catárticos sozinhos como medida de eliminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés adaptada de Cochrane Community.  
168  
<!-- Start of picture text -->
Geração da sequência de alocação (viés de seleção)<br>Sigilo da sequência de alocação (viés de seleção)<br>Cegamento dos participantes (viés de condução)<br>Cegamento dos avaliadores (viés de detecção)<br>Desfechos incompletos (viés de atrito)<br>Relato seletivo (viés de relato)<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
169  
**Quadro I.5.1.7. Avaliação das evidências pelo método GRADE sobre “Alcalinização da Urina” como medida de eliminação para pacientes com intoxicação aguda por agrotóxicos.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Avaliação daquali**<br>**Inconsistência**|**dade**<br>**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Sumário de Resultados**|**Qualidad**<br>**e**|
|---|---|---|---|---|---|---|---|---|
|**Gravidade**|||||||||
|5<sup>1,2,3,4,5</sup>|estudos<br>observacionais<br>(relatos de caso)|muito<br>grave<sup>a</sup>|não grave|não grave|grave<sup>b</sup>|nenhum|23 pacientes (relatos de caso ou séries de caso) tiveram,<br>aparentemente, maior depuração renal com a alcalinização urinária; no<br>entanto, o método de alcalinização e sua relação com a depuração<br>forampouco descritos.|⨁`◯◯◯`<br>MUITO<br>BAIXA|  
#### **Explicações**  
a. Todos os estudos são relatos de caso ou séries de caso, que apresentam alto risco de viés (informações incompletas, poucos pacientes, ausência de controle e randomização).  
b. Grupos pequenos ou de apenas um indivíduo (relatos de caso).  
c. Método de randomização e alocação inadequado (dias pares e ímpares); ausência de cegamento dos avaliadores; houve perdas de seguimento por falta de coordenação da equipe; desfechos não são bem descritos.  
d. Pequeno tamanho amostral.  
#### **Referências**  
1. Prescott LF, Park J,Darrien I. Treatment of severe 2,4-D and mecoprop intoxication with alcaline diuresis. Br J Clin Pharmacol ; 1979.  
2. Flanagan RJ, Meredith TJ, Ruprah M, Onyon LJ, Liddle A. Alkaline diuresis for acute poisoning with chlorophenoxy herbicides and ioxynil. Lancet. Elsevier; 1990;335(8687):454–8  
3. Friesen EG, Jones GR, Vaughan D. Clinical presentation and management of acute 2, 4-D oral ingestion. Drug Saf. Springer; 1990;5(2):155–9  
4. Schmoldt A, Iwersen S, Schlüter W. Massive ingestion of the herbicide 2-methyl-4-chlorophenoxyacetic acid (MCPA). J Toxicol Clin Toxicol. Taylor & Francis; 1997;35(4):405–8.  
5. Jearth V, Chauhan V, Sharma K, Negi R. A rare survival after 2,4-D (ethyl ester) poisoning: Role of forced alkaline diuresis. Indian J Crit Care Med. 2015;19(1):57.  
#### **ANEXO I.5.2 - PREVENÇÃO**  
170  
**Quadro I.5.2.1. Avaliação das evidências pelo método GRADE sobre a questão: “intervenções efetivas para se reduzir a intoxicação por agrotóxicos por tentativa de suicídio para pacientes com intoxicação aguda por agrotóxicos”.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|||**A**<br>**Risco**|**valiação daQual**|**idade**|**Medid**|**as de controle re**|**gulatório**<br>**Imt**|**Qlidd**|**Imrtâni**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|<br>**de**<br>**ié**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**paco**|**uaae**|**poca**|
|Incidência d<br>|e intoxicaçõespor<br>|**vs**<br>agrotóxic|os relacionadas a|tentativas de|suicídio|||||
|8<sup>1,2,3,4,5,6,7,8</sup>|estudos<br>observacionais|não<br>grave|não grave|grave<sup>a</sup>|não grave|nenhum|Um estudo realizado na Coreia do Sul mostrou que a taxa global<br>de suicídio associada a agrotóxicos diminuiu entre 2003-2013,<br>independentemente do tipo de produto, após a implementação de<br>diversas medidas regulatórias direcionadas ao controle desses<br>produtos no país. Essa redução foi mais pronunciada após a<br>proibição do paraquate<sup>1</sup>. Outro estudo, realizado no Sri Lanka,<br>evidenciou uma diminuição em 50% na taxa de suicídios após a<br>proibição de agrotóxicos da Classe I e restrições nos de classe II.<br>Contudo, o número de hospitalizações relacionadas às<br>intoxicações intencionais por agrotóxicos aumentou<sup>2,3,4</sup>. A<br>proibição dos agrotóxicos mais tóxicos pode ter contribuído na<br>redução de mortes por suicídio<sup>2,3,4,5</sup>. Em Bangladesh, a<br>mortalidade por intoxicação por agrotóxicos reduziu no período<br>após a proibição dos produtos mais tóxicos, com uma redução<br>relativa de 37,1%, (IC 95% 35,4 a 38,8%).  A taxa de suicídio por<br>intoxicação por agrotóxicos caiu de 6,3/100.000, antes da<br>proibição, para 2,2/100.000. Isso corresponde a um declínio de<br>65,1% (IC95% de 52,0 a 76,7%)<sup>6</sup>. Já um estudo realizado em<br>Taiwan demostrou que medidas de restrição de disponibilidade de<br>agrotóxicos reduzem a taxa de suicídio, sem haver o aumento<br>compensatório desta por outros métodos<sup>7</sup>. Além disso, foi visto<br>que a proibição seletiva dos agrotóxicos de maior toxicidade, os<br>quais eram associados ao maior número de mortes por intoxicação<br>intencional, não causou prejuízo aos agricultores, no que tange a<br>produtividade, no Sri Lanka<sup>8</sup>.|⨁`◯◯◯`<br>MUITO<br>BAIXA||  
171  
||||||**Instalaçõ**|**es comunitárias d**|**e estocagem**|||
|---|---|---|---|---|---|---|---|---|---|
|||**A**|**valiação daQua**|**lidade**||||||
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**|<br>**Importância**|
|Incidênci|a de intoxicaçõespo|r agrotóxi|cos relacionadas|a tentativas de|suicídio|||||
|3<sup>9,10</sup>|estudos<br>observacionais|não<br>grave|grave<sup>b</sup>|não grave|não grave|nenhum|Estudos realizados em comunidades rurais na Índia indicaram<br>que a construção de instalações comunitárias centralizadas de<br>armazenagem de agrotóxicos, supervisionadas e trancadas, pode<br>contribuir para a redução do número de casos de suicídio por<br>essas substâncias, por dificultar o acesso<sup>9,10</sup>.|⨁`◯◯◯`<br>MUITO<br>BAIXA||  
#### **Explicações**  
a. A comparação é indireta nos estudos do Sri Lanka, uma vez que não está disponível a taxa de casos de suicídio por agrotóxicos, apenas a taxa geral. Além disso, as populações dos artigos são, em maioria, de países asiáticos.  
b. Estudo de Pearson et al 2017 não mostra diferenças entre intervenção (estocagem isolada de agrotóxicos) e grupo controle, diferindo do estudo de Vijayakumar et al., 2013, que mostra um potencial de uso dessa intervenção.  
#### **Referências** :  
1. Cha ES, Chang S-S, Gunnell D, Eddleston M, Khang Y-H, Lee WJ. Impact of paraquat regulation on suicide in South Korea. Int J Epidemiol. 2016 Apr; 45(2):470–9. 2. Roberts DM, Karunarathna A, Buckley NA, Manuweera G, Sheriff MHR, Eddleston M. Influence of pesticide regulation on acute poisoning deaths in Sri Lanka. Bull World Health Organ. 2003;81 (11):789–98.  
3. Gunnell D, Fernando R, Hewagama M, Priyangika WDD, Konradsen F, Eddleston M. The impact of pesticide regulations on suicide in Sri Lanka. Int J Epidemiol. 2007; 36(6):1235–42.  
4. Knipe DW, Metcalfe C, Fernando R, Pearson M, Konradsen F, Eddleston M, et al. Suicide in Sri Lanka 1975-2012: age, period and cohort analysis of police and hospital data. BMC Public Health. 2014 Aug;14 (1):839.  
5. Knipe DW, Padmanathan P, Muthuwatta L, Metcalfe C, Gunnell D. Regional variation in suicide rates in Sri Lanka between 1955 and 2011: a spatial and temporal analysis. BMC Public Health. 2017 Feb;17 (1):193.  
6. Chowdhury FR, Dewan G, Verma VR, Knipe DW, Isha IT, Faiz MA, et al. Bans of WHO Class I Pesticides in Bangladesh-Suicide Prevention without Hampering Agricultural Output. Int J Epidemiol. 2017 Aug;  
7. Lin J-J, Lu T-H. Trends in solids/liquids poisoning suicide rates in Taiwan: a test of the substitution hypothesis. BMC Public Health. 2011 Dec;11(1):712.  
8. Manuweera G, Eddleston M, Egodage S, Buckley NA. Do targeted bans of insecticides to prevent deaths from self-poisoning result in reduced agricultural output? Environ Health Perspect. 2008 Apr;116(4):492–5.  
172  
9. Vijayakumar L, Jeyaseelan L, Kumar S, Mohanraj R, Devika S, Manikandan S. A central storage facility to reduce pesticide suicides--a feasibility study from India. BMC Public Health. 2013 Sep;13(1):850.  
10. Mohanraj R, Kumar S, Manikandan S, Kannaiyan V, Vijayakumar L. A public health initiative for reducing access to pesticides as a means to committing suicide: findings from a qualitative study. Int Rev Psychiatry. 2014 Aug;26(4):445–52.  
**Quadro I.5.2.1.1. Avaliação do risco de viés sobre a “intervenções efetivas para se reduzir a intoxicação por agrotóxicos por tentativa de suicídio, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de Controle regulatório da toxicidade dos agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.1.2. Avaliação do risco de viés sobre a “intervenções efetivas para se reduzir a intoxicação por agrotóxicos por tentativa de suicídio, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de Estimular grupos de discussão na comunidade** . Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
173  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.2. Avaliação das evidências pelo método GRADE sobre a questão: intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças”, no desfecho reduzir a incidência de intoxicações por agrotóxicos acidentais em crianças com a retirada do alcance.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||||**De**|**ixar oproduto fora do alcance**|||
|---|---|---|---|---|---|---|---|---|
||||**Avaliação daQu **|**alidade**|||||
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Impacto**<br>**Outras**<br>**considerações**|**Qualidade**|**Importância**|  
Incidência de intoxica <mark>ç</mark> ões <mark>p</mark> or a <mark>g</mark> rotóxicos acidentais em crian <mark>ç</mark> as  
174  
||||**Avaliação daQu **|**alidade**|**De**|**ixar oproduto fo**|**ra do alcance**|||
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de**<br>**viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**Impacto**|**Qualidade**|**Importância**|
|2<sup>1,2</sup>|estudo<br>observacional|não<br>grave|não grave|não grave|não grave|forte<br>associação|Algumas intervenções de segurança doméstica foram<br>efetivas e podem ser extrapoladas para envenenamentos por<br>essas substâncias, tais como o armazenamento de<br>medicamentos (OR 1,53, IC 95% 1,27 a 1,84) fora do<br>alcance de crianças, trancados ou guardados imediatamente<br>após o uso, podem prevenir de 11-20% dos casos de<br>intoxicação com esses produtos<sup>1</sup>. Além disso, em 44,5% das<br>intoxicações não intencionais devido a produtos domésticos<br>(IC 95%, 38,9% - 50,0%), os cuidadores admitiram não<br>manter esses produtos fora do alcance das crianças<sup>2</sup>.|⨁⨁⨁`◯`<br>MODERADA|<br>CRÍTICO|  
**Referências** :  
1. Kendrick D, Majsak-Newman G, Benford P, Coupland C, Timblin C, Hayes M, et al. Poison prevention practices and medically attended poisoning in young children: multicentre case–control study. Inj Prev. 2017 Apr;23(2):93–101.  
2. Mintegi S, Azkunaga B, Prego J, Qureshi N, Dalziel SR, Arana-Arri E, et al. International Epidemiological Differences in Acute Poisonings in Pediatric Emergency Departments. Pediatr Emerg Care. 2017 Jan; 1.  
**Quadro I.5.2.2.1. Avaliação do risco de viés sobre “intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças”, no desfecho reduzir a incidência de intoxicações por agrotóxicos acidentais em crianças com a retirada do alcance.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
175  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.3. Avaliação das evidências pelo método GRADE sobre a questão: “intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças” no desfecho reduzir a incidência de intoxicações por agrotóxicos acidentais em crianças com a manutenção do produto em embalagens**  
176  
**originais.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
|||**Risco**|**Avaliação daQu **|**alidade**|**Manter op**|**roduto tóxico em**|**embalagens originais**<br>**Impacto**|**Qualidade**|**Importância**|
|---|---|---|---|---|---|---|---|---|---|
|**№ dos**<br>**estudos**<br>Incidênci|**Delineamento**<br>**do estudo**<br>a de intoxicaçõesp|<br>**de**<br>**viés**<br>or agro|**Inconsistência**<br>tóxicos de caráter|**Evidência**<br>**indireta**<br>acidental, em|**Imprecisão**<br>crianças|**Outras**<br>**considerações**||||
|3<sup>1,2,3</sup>|estudo<br>observacional|não<br>grave|não grave|não grave|não grave|forte<br>associação|A transferência de produtos perigosos para outras<br>embalagens também foi um fator associado ao aumento de<br>intoxicação em crianças (23% maior). Outro estudo<br>prospectivo multicêntrico internacional que analisou mais<br>de 360 mil emergências pediátricas reportadas na Europa,<br>América do Norte, Austrália e Ásia, concluiu que cerca de<br>21,3% (IC 95%, 21,3% - 23,6%) dos envenenamentos<br>pediátricos não intencionais envolveram cuidadores que<br>admitiram manter a substância tóxica em um recipiente não-<br>original (> 30% na região da América do Sul e do<br>Mediterrâneo Oriental). Observou-se ainda a existência de<br>um maior risco de intoxicação com querosene e<br>medicamentos<br>quando<br>esses<br>produtos<br>não<br>foram<br>armazenados de forma adequada. Associa-se 76% dos casos<br>de intoxicação com querosene ao fato do produto ter sido<br>armazenado em garrafas de refrigerantes.|⨁⨁⨁`◯`<br>MODERADA|<br>CRÍTICO|  
**Referências** :  
1. Kendrick D, Majsak-Newman G, Benford P, Coupland C, Timblin C, Hayes M, et al. Poison prevention practices and medically attended poisoning in young children: multicentre case–control study. Inj Prev. 2017 Apr;23(2):93–101.  
2. Mintegi S, Azkunaga B, Prego J, Qureshi N, Dalziel SR, Arana-Arri E, et al. International Epidemiological Differences in Acute Poisonings in Pediatric Emergency Departments. Pediatr Emerg Care. 2017 Jan; 1.  
3. Azizi BH, Zulkifli HI, Kassim MS. Circumstances surrounding accidental poisoning in children. Med J Malaysia. 1994 Jun; 49(2):132–7.  
177  
**Quadro I.5.2.3.1. Avaliação do risco de viés sobre “intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças” no desfecho reduzir a incidência de intoxicações por agrotóxicos acidentais em crianças com a manutenção do produto em embalagens originais.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.4. Avaliação das evidências pelo método GRADE sobre a questão: “intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças”.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
178  
<!-- Start of picture text -->
Embala g em es p ecial de  p rote ç ão<br>Avalia ç ão da  Q ualidade  № de  p acientes  Efeito<br>embalagem<br>Qualidad Importânci<br>especial de<br>№ dos  Delineamen Risco de  Inconsistên Evidência  Imprecisã Relativo  Absoluto  e  a<br>Outras considerações  proteção de  não utilizar<br>estudos  to do estudo  viés  cia  indireta  o  (95% CI)  (95% CI)<br>medicamento<br>s<br>Incidência das intoxica ç ões acidentais  p or a g rotóxicos em crian ç as<br>1  1 estudos  grave  a,b,c  não grave   grave  a não grave   todos os potenciais fatores  2/1000000  3.5/1000 1,4 -- 1 menos  ⨁ ◯◯◯ CRÍTICO<br>observacion de confusão sugeririam  (0.0%)   000  (0.85 para  por  MUITO<br>ais   um  efeito  espúrio  e,  1.95)   1.000.000 BAIXA<br>mesmo assim, nenhum  (0.0%)  (de 1<br>efeito foi observado.   menos<br>para 2<br>menos)<br><!-- End of picture text -->  
**Referências** :  
1. Rodgers GB. The safety effects of child-resistant packaging for oral prescription drugs. Two decades of experience. JAMA. 1996 Jun;275(21):1661–5.  
**Quadro I.5.2.4.1. Avaliação do risco de viés sobre a “intervenções efetivas para se reduzir a intoxicação por agrotóxicos de caráter acidental em crianças”, no desfecho de uso de embalagens especiais para crianças.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
179  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.5. Avaliação das evidências pelo método GRADE sobre a questão: “intervenções efetivas para se reduzir a intoxicação por agrotóxicos, de caráter ocupacional, para pacientes com intoxicação aguda por agrotóxicos”.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo.  
||||**O uso de Equipa**<br>**Avaliação da Qua**|**mentos de P**<br>**lidade**|**roteção Indivi**|**dual (EPI) para a**|**redução na incidência de intoxicação ocupacional por agrotóxicos**|||
|---|---|---|---|---|---|---|---|---|---|
||||||||**Imacto**|**Qualidade**|**Imortância**|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**p**||**p**|
|Incidência|de intoxicações oc|upacionai|s por agrotóxicos|||||||
|2<sup>1,2</sup>|estudos<br>observacionais|grave<sup>a</sup>|não grave|não grave|não grave|nenhum|Dos 59 agricultores entrevistados, aqueles que afirmavam utilizar EPI<br>apresentaram 70% menos sintomas de intoxicação quando comparados aos que<br>não o utilizavam (RP=0,29; IC95%= 0,05 – 1,70; p=0,049)<sup>1</sup>. No outro estudo, a<br>utilização de óculos de proteção, macacão, bem como usar somente um dia a<br>roupa de aplicação reduz as chances de intoxicação em, respectivamente, 56%,<br>14%, 83% e 78%<sup>2</sup>.|⨁`◯◯◯`<br>MUITO<br>BAIXA||
||||**Avaliação da Qua**|**Disponibi**<br>**lidade**|**lizar um local**|**para higiene pes**|**soal após o contato ou utilização de agrotóxicos.**|||
||||||||**Imt**|**Qlidd**|**Imrtâni**|
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Outras**<br>**considerações**|**paco**|**uaae**|**poca**|  
180  
<!-- Start of picture text -->
O uso de Equipamentos de Prote ç ão Individual (EPI) para a redu ç ão na incidência de intoxica ç ão ocupacional por a g rotóxicos<br>Avalia ç ão da Qualidade<br>Impacto   Qualidade  Importância<br>№ dos  Delineamento  Risco  Evidência  Outras<br>Inconsistência  Imprecisão<br>estudos  do estudo  de viés  indireta  considerações<br>Incidência de intoxicações ocupacionais por agrotóxicos<br>1 2 estudos  grave  não grave   grave  c não grave   nenhum   Os aspectos higiênicos são importantes preditores da intoxicação, pois  ⨁ ◯◯◯<br>observacionais   b indivíduos que não trocam ou lavam a roupa após a última aplicação têm riscos  MUITO<br>aumentados em 1.257% 2 .   BAIXA<br>Realizar a lava g em dos EPI em local de trabalho.<br>Avalia ç ão da Qualidade<br>Impacto   Qualidade  Importância<br>№ dos  Delineamento  Risco  Evidência  Outras<br>Inconsistência  Imprecisão<br>estudos  do estudo  de viés  indireta  considerações<br>Incidência de intoxica ç ões ocu p acionais  p or a g rotóxicos<br>1 2 estudos  não  não grave   grave  d não grave   nenhum   Um estudo realizado em Teresópolis-RJ, com trabalhadores rurais, verificou  ⨁ ◯◯◯<br>observacionais   grave   que a lavagem do EPI no tanque de uso doméstico aumenta a probabilidade de  MUITO<br>intoxicação em 564% em relação aos indivíduos que adotam outras práticas de  BAIXA<br>lavagem dos equipamentos mecânicos 2 .<br><!-- End of picture text -->  
|||||**Realização d**|**e programas**|**de educação continuada pelos profissionais de saúde e empregadores**|||
|---|---|---|---|---|---|---|---|---|
||||**Avaliação da Qua**|**lidade**|||||
|**№ dos**<br>**estudos**|**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**|**Imprecisão**|**Impacto**<br>**Outras**<br>**considerações**|**Qualidade**|**Importância**|
|Incidênci|a de intoxicações|ocupac|ionaispor agrot|óxicos|||||  
181  
|||||**Realização de programas de educação conti**|**nuada pelos profissionais de saúde e empregadores**|||
|---|---|---|---|---|---|---|---|
||||**Avaliação da Qu**|**alidade**||||
|||||<br>|**Impacto**|**Qualidade**|<br>**Importância**|
|**№ dos**<br>**estudos**|<br>**Delineamento**<br>**do estudo**|**Risco**<br>**de viés**|**Inconsistência**|**Evidência**<br>**indireta**<br>**Imprecisão**<br>**Outras**<br>**considerações**|||<br>|
|4<sup>3,4,5,6</sup>|estudos<br>observacionais|grave<br>e|não grave|grave<sup>f</sup><br>não grave<br>nenhum|Intervenções educacionais em relação à leitura do rótulo, efeitos adversos à<br>saúde, estocagem em local seguro e uso de EPI para o manuseio de agrotóxico<br>entre agricultores resultaram numa melhor pontuação geral no questionário de<br>conhecimento, atitude e prática (CAP). Entretanto, houve deficiência na retenção<br>do conhecimento e não foi verificada uma melhoria significativa em relação às<br>práticas adotadas em relação aos agrotóxicos<sup>3</sup>. A intervenção educacional, por<br>meio de uma sessão única de treinamento, apesar de contribuir para a adesão do<br>uso de equipamentos de aplicação e uma redução do número de agrotóxicos<br>utilizados, não foi considerada efetiva para aumentar a adesão ao uso de EPI e<br>nem tampouco para uma redução da exposição dérmica<sup>4</sup>. A percepção sobre a<br>adoção de medidas de segurança em relação ao uso de agrotóxicos é maior em<br>agricultores com um maior nível de educação formal, bem como entre os que<br>tiveram experiências prévias de intoxicação com esses produtos. A preferência<br>de temas para treinamentos se mostrou variável de acordo com o grupo etário<sup>5</sup>.<br>Outro estudo com trabalhadoras agrícolas revelou que o conhecimento que essas<br>apresentavam em relação à segurança do manuseio de agrotóxicos era resultante<br>de treinamentos e outras formas de aprendizado. Contudo, esse grupo de<br>trabalhadoras indicou a necessidade de mais capacitação, pois não se<br>consideravam seguras ao manusear esse tipo de produto, principalmente se<br>estivessem grávidas. Elas indicaram que os treinamentos poderiam ser oferecidos<br>pelo empregador, pelos seus supervisores e por profissionais da área de saúde<sup>6</sup>.|⨁`◯◯◯`<br>MUITO<br>BAIXA||  
**CI:** Intervalo de confiança  
#### **Explicações**  
a. O artigo de Savi et al (2010) relata que a amostra foi selecionada por conveniência, o que causou rebaixamento por risco de viés de seleção e avaliação.  
b. No artigo de Soares et al (2005) foi detectado alto risco de viés por se tratar de uma amostra envolvendo entrevistas com 153 estabelecimentos da região, representando cerca 5% dos estabelecimentos e isso não deixa claro se a amostra é representativa.  
c. No artigo de Soares et al (2005), foi verificado um desfecho substituto, ou seja, se condições de higienização poderiam melhorar a utilização de EPI e, dessa forma, reduzir as intoxicações dos trabalhadores.  
- d. A evidência é considerada indireta, por se tratar de desfecho substituto, ou seja, a lavagem dos EPIs, separadamente, como forma de diminuir a exposição aos agrotóxicos e, dessa forma, diminuir as intoxicações.  
e. A maioria dos estudos envolveu análise de percepção com base em questionários  
f. Hashemi et al, 2012 - população do Irã; Perry & Layde, 2003 e Flocks et al, 2012 - população norte americana  
182  
#### **Referências** :  
1. Savi EP, Sakae TM, Candemil R, Sakae DY, Valerim K, Remor T. Sintomas associados à exposição aos agrotóxicos entre rizicultores em uma cidade no sul de Santa Catarina. Arq Catarinenses Med. 2010; 39.  
2. Soares W, Freitas E, Coutinho J. Trabalho rural e saúde: intoxicações por agrotóxicos no município de Teresópolis-RJ. Rev Econ e Sociol Rural. 2005;43(4):685–701. 3. Sam KG, Andrade HH, Pradhan L, Pradhan A, Sones SJ, Rao PGM, et al. Effectiveness of an educational program to promote pesticide safety among pesticide handlers of South India. Int Arch Occup Environ Health. 2008; 81(6):787–95.  
4. Perry MJ, Layde PM. Farm pesticides: outcomes of a randomized controlled intervention to reduce risks. Am J Prev Med. 2003 May;24(4):310–5.  
5. Hashemi SM, Hosseini SM, Hashemi MK. Farmers’ perceptions of safe use of pesticides: determinants and training needs. Int Arch Occup Environ Health. 2012 Jan;85(1):57–66.  
6. Flocks J, Kelley M, Economos J, McCauley L. Female farmworkers’ perceptions of pesticide exposure and pregnancy health. J Immigr Minor Heal. 2012 Aug;14(4):626– 32.  
**Quadro I.6.2.5.1. Avaliação do risco de viés sobre as intervenções efetivas para se reduzir a intoxicação por agrotóxicos, de caráter ocupacional, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de uso de Equipamentos de Proteção Individual (EPI) para a redução na incidência de intoxicação ocupacional por agrotóxicos .** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
183  
**Quadro I.5.2.5.2. Avaliação do risco de viés sobre as intervenções efetivas para se reduzir a intoxicação por agrotóxicos, de caráter ocupacional, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de disponibilizar um local para higiene pessoal após o contato ou utilização de agrotóxicos.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.5.3. Avaliação do risco de viés sobre as intervenções efetivas para se reduzir a intoxicação por agrotóxicos, de caráter ocupacional, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de realizar a lavagem dos EPI em local de trabalho.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.5.4. Avaliação do risco de viés sobre as intervenções efetivas para se reduzir a intoxicação por agrotóxicos, de caráter ocupacional, para pacientes com intoxicação aguda por agrotóxicos”, no desfecho de realização de programas de educação continuada pelos profissionais de saúde e empregadores.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
184  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
**Quadro I.5.2.6. Avaliação das evidências pelo método GRADE sobre a questão: “estratégias para se reduzir o risco de exposição por consumo de alimentos com resíduos de agrotóxicos de contato”.** Foi utilizada a ferramenta GRADEpro GDT. O risco de viés foi avaliado conforme descrito na metodologia, considerando diversos fatores a depender do delineamento do estudo  
185  
<!-- Start of picture text -->
Avaliação da Qualidade<br>Impacto   Qualidade  Importância<br>№ dos  Delineamento  Risco  Evidência  Outras<br>Inconsistência  Imprecisão<br>estudos  do estudo  de viés  indireta  considerações<br>Resíduos de agrotóxicos de alimentos.<br>9 1,2,3,4,5,6,7,8,9 estudos  grave  a não grave   grave  b não grave   nenhum   A redução nas concentrações de resíduos de  ⨁ ◯◯◯<br>observacionais   agrotóxicos, por lavagem com água ou água e  MUITO<br>detergente, encontrada nesses estudos, foi de 14 a  BAIXA<br>97%  dependendo  do  princípio  ativo<br>estudado 1,2,3,4,5,6,7,8 .<br><!-- End of picture text -->  
#### **Explicações**  
a. Por se tratarem de estudos laboratoriais, a quantidade de grupos e o número de amostras de alimentos analisadas possuem parâmetros de difícil comparação e avaliação de adequação.  
b. Os desfechos que constam como evidência indireta “grave”, devem-se ao fato de não se referirem à mesma população de interesse (estudos em populações de outros países), ou as evidências são desfechos substitutos ou indiretos à recomendação. Nesse caso, os desfechos tratam a questão da intoxicação por ingestão de resíduos de alimentos de forma indireta, focalizando os resíduos nos alimentos e a forma de diminuí-los.  
#### **Referências** :  
1. Soliman KM. Changes in concentration of pesticide residues in potatoes during washing and home preparation. Food Chem Toxicol. 2001 Aug;39(8):887–91.  
2. Hassanzadeh N, Bahramifar N, Esmaili-Sari A. Residue content of carbaryl applied on greenhouse cucumbers and its reduction by duration of a pre-harvest interval and postharvest household processing. J Sci Food Agric. 2010 Oct;90(13):2249–53.  
3. Hao J, Wuyundalai, Liu H, Chen T, Zhou Y, Su Y-C, et al. Reduction of Pesticide Residues on Fresh Vegetables with Electrolyzed Water Treatment. J Food Sci. 2011 May;76(4):C520–4.  
4. Kusvuran E, Yildirim D, Mavruk F, Ceyhan M. Removal of chloropyrifos ethyl, tetradifon and chlorothalonil pesticide residues from citrus by using ozone. J Hazard Mater. 2012 Nov;241–242:287–300.  
5. Al-Taher F, Chen Y, Wylie P, Cappozzo J. Reduction of pesticide residues in tomatoes and other produce. J Food Prot. 2013 Mar;76(3):510–5.  
6. Lu H-Y, Shen Y, Sun X, Zhu H, Liu X-J. Washing effects of limonene on pesticide residues in green peppers. J Sci Food Agric. 2013 Sep;93(12):2917–21.  
7. Mekonen S, Ambelu A, Spanoghe P. Effect of Household Coffee Processing on Pesticide Residues as a Means of Ensuring Consumers’ Safety. J Agric Food Chem. 2015 Sep;63(38):8568–73.  
186  
8. Saeedi Saravi SS, Shokrzadeh M. Effects of washing, peeling, storage, and fermentation on residue contents of carbaryl and mancozeb in cucumbers grown in greenhouses. Toxicol Ind Health. 2014;32(6):1135–42.  
9. Rani M, Saini S, Kumari B. Persistence and effect of processing on chlorpyriphos residues in tomato (Lycopersicon esculantum Mill.). Ecotoxicol Environ Saf. 2013 Sep;95:247–52.  
**Quadro I.5.2.6.1. Avaliação do risco de viés sobre as intervenções efetivas para “estratégias para se reduzir o risco de exposição por consumo de alimentos com resíduos de agrotóxicos de contato”.** Foi utilizada a metodologia de avaliação de risco de viés de Cochrane Community, adaptada para estudos observacionais.  
<!-- Start of picture text -->
Variáveis de Confundimento<br>Avaliação dos resultados<br>Seleção dos Grupos<br>Outros vieses<br>0% 20% 40% 60% 80% 100%<br>Baixo Incerto Alto<br><!-- End of picture text -->  
187

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**QUADRO I.6.1** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para a abordagem geral para o tratamento de Intoxicações por agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**QUADRO I.6.2** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para a prevenção de Intoxicações por agrotóxicos.  
188

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**QUADRO I.6.1** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para a abordagem geral para o tratamento de Intoxicações por agrotóxicos.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**P** População intoxicada com agrotóxicos  
**I** Ligar ao centro de assistência toxicológica  
|**C**Ausência|da intervenção||
|---|---|---|
|**O**Redução|da mortalidade||
|**S**Clínicos|e observacionais||
||**Julgamento**|**Evidências**<br>**Considerações adicionais**|
||**Qual a qualidade da Evidência**|Pacientes que tiveram assistência remota|
|||(35,5%)<br>do<br>Centro<br>de<br>Informações|
|**os**|`☐`Sem estudos|Toxicológicas (CIT) ficaram em média 3,43<br>dias a menos (IC 95%: -6,10 a -0,77) internados|
|**risc**|`☐`Muito baixa|quando comparados a nenhum auxílio do CIT.|
|**Benefícios e**|`☒`Baixa<br>`☐`Moderada|Não houve diferença estatística na gravidade<br>entre os pacientes com ou sem assistência do<br>CIT (p>0,5) (Galvão et al. 2011).|
||`☐`Alta||  
189  
|||**Há balanço entre os riscos e benefícios**<br>`☒`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|---|---|---|---|
|**Valores  e**|**preferencias**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|Não foi realizada busca sistemática que<br>avaliasse a percepção dos pacientes em relação<br>aos principais desfechos, no entanto, considera-<br>se que o desfecho tempo de internação é crítico<br>para os pacientes.|  
190  
||**Os custos associados à intervenção são**|Não foi realizada busca sistemática|
|---|---|---|
||**pequenos?**||
||`☐`Não||
||`☐`Provavelmente não||
|**Custos**|`☐`Incerto||
||`☒`Provavelmente sim||
||`☐`Sim||
||`☐`Há variabilidade||  
191  
||**A opção é aceitável para as principais**<br>**partes interessadas?**<br>`☐`Não|Não foi realizada busca sistemática|
|---|---|---|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim||
||`☒`Sim||
||`☐`Há variabilidade||
||A opção é viável para implementar?<br>`☐`Não|CIT disponíveis no Brasil|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☒`Sim<br>`☐`Há variabilidade||  
192  
|||**Conclusão**<br>|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Recomenda-se que profiss<br>os Centros de Informação<br>primeiros socorros e tratam<br>No site: http://portal.anvisa<br>centros de informação tox<br>**722 6001.**<br>No sitehttp://abracit.org.<br>Associação Brasileira de C|ionais de saúde responsávei<br>e Assistência Toxicológica<br>ento adequado para cada ti<br>.gov.br/disqueintoxicacao  <br>icológica da Renaciat. O n<br>br/wp/centros/ estão dispo<br>entros de Informação e Ass|s pelo atendimento de pacie<br>(CIATox) de sua região para<br>po de substância tóxica.<br>estão disponíveis os número<br>úmero gratuito do serviço D<br>níveis os contatos dos ce<br>istência Toxicológica (ABR|ntes intoxicados acionem<br>esclarecimentos sobre os<br>s de contato dos diferentes<br>isque-intoxicação é**0800**<br>ntros de intoxicação da<br>ACIAT).|  
193  
|**Justificativa**||
|---|---|
|**Considerações subgrupo**||
|**Considerações implementação**|Processo de implementação no SUS.|
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||  
194

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**P** População intoxicada com agrotóxicos  
**I** Carvão ativado **C** Ausência da intervenção  
**O** Redução da mortalidade  
|**S**Clínicos|e observacionais||
|---|---|---|
||**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☐`Muito baixa<br>`☐`Baixa<br>`☒`Moderada<br>`☐`Alta|Em um ensaio clínico, 1.310 pacientes, maiores de 14<br>anos, intoxicados com inibidores de colinesterase foram<br>randomizados em três grupos: um de dose única de carvão<br>ativado (440), um de doses múltiplas (429) e um sem<br>carvão ativado (441). A história de êmese antes do<br>atendimento, êmese forçada ou lavagem gástrica foi<br>semelhante entre os grupos.<br>Não houve redução significativa da mortalidade nos<br>grupos avaliados, tanto no de dose única (OR 0,94, IC<br>95% 0,63-1,41), como no de doses múltiplas (OR 0.78,<br>95% IC 95% 0,51-1,19) quando comparados com o grupo<br>que não recebeu a intervenção. Tampouco se observaram|  
195  
||diferenças significativas quando comparados os grupos<br>intervencionais.|
|---|---|
||Não foi Evidênciada uma redução significativa na<br>necessidade de intubação, a apresentação de convulsões,<br>o tempo até a morte ou o agravamento clínico com o uso<br>de carvão ativado em doses múltiplas ou única.  A<br>duração média da ventilação (excluindo as mortes) foi<br>semelhante no grupo que recebeu doses múltiplas, quando<br>comparado com o grupo sem intervenção. Contudo, essa<br>foi mais longa nos pacientes tratados com dose única de<br>carvão ativado.|
||Não houve diferenças significativas quando o carvão<br>ativado foi administrado antes ou após duas horas da<br>ingestão. Contudo, deve-se considerar que somente um<br>número pequeno de pacientes chegaram ao local de<br>atendimento antes de transcorridas duas horas da<br>exposição. O IC estreito (IC 95% 0,61 a 2,38,) sugere<br>pouco benefício (Eddleston, Juszczak, et al. 2008).|
|**Há balanço entre os riscos e benefícios**|Os**efeitos adversos**associados ao uso carvão<br>ativado são: pneumonia aspirativa (Amigó, Nogué, and<br>Mir 2010; Bairral 2012; Bosse et al. 1995; Dorrington et|
|`☐`Benefícios sobrepõem os riscos|al. 2003; Golej et al. 2001; Harris and Filandrinos 1993;<br>Menzies 1988; Osterhoudt et al. 2004; Pollack et al. 1981;<br>Silberman, Davis, and Lee 1990); empiema (Justiniani,|  
196  
||`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|Hippalgaonkar, and Martinez 1985);  pneumotórax<br>(Thomas, Cummin, and Falcone 1996); bronquiolite<br>obliterante (Elliott et al. 1989), insuficiência respiratória<br>(Francis et al. 2009; Golej et al. 2001; Gutiérrez, Bossert,<br>and Espinosa 2013); cavernas pulmonares (Francis et al.<br>2009); mediastinite (Caravati et al. 2001); doença<br>pulmonar crônica (Graff 2002) SARA (De Weerdt et al.<br>2015), linfangioleiomiomatose pulmonar(Huber et al.<br>2006), granuloma, (Seder et al. 2006), constipação<br>(Osterhoudt et al. 2004) infeção respiratória (George<br>1991), abrasão corneana (Dorrington et al. 2003;<br>McKinney et al. 1993) êmese (Boyd and Hanson 1999;<br>Crockett et al. 1996; Merigian 1990; Osterhoudt et al.<br>2004), dificuldade de visualização dos procedimentos<br>(Lopes de Freitas, Ferreira, and Brito 1997; Moore and<br>Davies 1996) e alterações hidroeletrolíticas (Dorrington<br>et al. 2003).|
|---|---|---|
|**Valores  e**<br>**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito||  
197  
||Os custos associados à intervenção são|Dificuldade na logística|
|---|---|---|
||pequenos?||
||`☐`Não||
|**Custos**|`☐`Provavelmente não<br>`☐`Incerto||
||`☐`Provavelmente sim||
||`☒`Sim||
||`☐`Há variabilidade||  
198  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
199  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☒`|`☐`|`☐`|
|**Recomendação**|Não recomendamos o uso r|otineiro de carvão ativado|para intoxicação por agrotóx|icos.|
|**Justificativa**|Maior risco que benefício||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|Logística de distribuição||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|Em ambientes hospitalares|e com agrotóxicos em men|os de 1 h||
|**PERGUNTA: Carvão Ativado**|||||
|**P**População intoxicada com agrotó|xicos||||
|**I**Carvão ativado|||||  
200

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☐`Muito baixa<br>`☐`Baixa<br>`☒`Moderada<br>`☐`Alta|Em um ensaio clínico, 1.310 pacientes, maiores de 14<br>anos, intoxicados com inibidores de colinesterase foram<br>randomizados em três grupos: um de dose única de carvão<br>ativado (440), um de doses múltiplas (429) e um sem<br>carvão ativado (441). A história de êmese antes do<br>atendimento, êmese forçada ou lavagem gástrica foi<br>semelhante entre os grupos.<br>Não houve redução significativa da mortalidade nos<br>grupos avaliados, tanto no de dose única (OR 0,94, IC<br>95% 0,63-1,41), como no de doses múltiplas (OR 0.78,<br>95% IC 95% 0,51-1,19) quando comparados com o grupo<br>que não recebeu a intervenção. Tampouco se observaram<br>diferenças significativas quando comparados os grupos<br>intervencionais.<br>Não foi Evidênciada uma redução significativa na<br>necessidade de intubação, a apresentação de convulsões,<br>o tempo até a morte ou o agravamento clínico com o uso<br>de carvão ativado em doses múltiplas ou única.  A duração||  
201  
||média da ventilação (excluindo as mortes) foi semelhante<br>no grupo que recebeu doses múltiplas, quando comparado<br>com o grupo sem intervenção. Contudo, essa foi mais<br>longa nos pacientes tratados com dose única de carvão<br>ativado.<br>Não houve diferenças significativas quando o carvão<br>ativado foi administrado antes ou após duas horas da<br>ingestão. Contudo, deve-se considerar que somente um<br>número pequeno de pacientes chegaram ao local de<br>atendimento antes de transcorridas duas horas da<br>exposição. O IC estreito (IC 95% 0,61 a 2,38,) sugere<br>pouco benefício (Eddleston, Juszczak, et al. 2008).|
|---|---|
|**Há balanço entre os riscos e benefícios**|Os**efeitos adversos**associados ao uso carvão<br>ativado são: pneumonia aspirativa (Amigó, Nogué, and<br>Mir 2010; Bairral 2012; Bosse et al. 1995; Dorrington et|
|`☐`Benefícios sobrepõem os riscos|al. 2003; Golej et al. 2001; Harris and Filandrinos 1993;<br>Menzies 1988; Osterhoudt et al. 2004; Pollack et al. 1981;|
|`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|Silberman, Davis, and Lee 1990); empiema (Justiniani,<br>Hippalgaonkar, and Martinez 1985);  pneumotórax<br>(Thomas, Cummin, and Falcone 1996); bronquiolite<br>obliterante (Elliott et al. 1989), insuficiência respiratória<br>(Francis et al. 2009; Golej et al. 2001; Gutiérrez, Bossert,<br>and Espinosa 2013); cavernas pulmonares (Francis et al.<br>2009); mediastinite (Caravati et al. 2001); doença|  
202  
|||pulmonar crônica (Graff 2002) SARA (De Weerdt et al.<br>2015), linfangioleiomiomatose pulmonar(Huber et al.<br>2006), granuloma, (Seder et al. 2006), constipação<br>(Osterhoudt et al. 2004) infeção respiratória (George<br>1991), abrasão corneana (Dorrington et al. 2003;<br>McKinney et al. 1993) êmese (Boyd and Hanson 1999;<br>Crockett et al. 1996; Merigian 1990; Osterhoudt et al.<br>2004), dificuldade de visualização dos procedimentos<br>(Lopes de Freitas, Ferreira, and Brito 1997; Moore and<br>Davies 1996) e alterações hidroeletrolíticas (Dorrington et<br>al. 2003).|
|---|---|---|
|**Valores  e**<br>**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito||  
203  
||**Os custos associados à intervenção são**<br>**pequenos?**|Dificuldade na logística|
|---|---|---|
||`☐`Não||
||`☐`Provavelmente não||
|**Custos**|`☐`Incerto<br>`☐`Provavelmente sim||
||`☒`Sim||
||`☐`Há variabilidade||  
204  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
205  
||A opção é viável para implementar?|
|---|---|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
|**Tipo de recomendação**|**Recomendação forte**|**Recomendação**|**Recomendação**|**Recomendação forte a**|
|---|---|---|---|---|
||**contra a intervenção**|**condicional/fraca**<br>**contra a intervenção**|**condicional a favor da**<br>**intervenção**|**favor da intervenção**|
||`☐`|`☐`||`☐`|
||||`☒`||  
206  
|**Recomendação**|Sugere-se usar carvão ativado em pessoas que ingeriram uma grande qua<br>tóxicos, adsorvíveis por carvão ativado e que forem atendidas dentro de 60|ntidade de agrotóxicos altamente<br>min.|
|---|---|---|
|**Justificativa**|Maior risco que benefício||
|**Considerações subgrupo**|||
|**Considerações implementação**|Logística de distribuição||
|**Monitoramento e avaliação**|||
|**Prioridades de pesquisa**|Em ambientes hospitalares e com agrotóxicos em menos de 1 h||
|**PERGUNTA : Lavagem gástrica**|||
|**P**População intoxicada com agrotó|xicos||
|**I**Lavagem gástrica|||
|**C**Ausência da intervenção|||
|**O**Redução da mortalidade|||
|**S**Clínicos e observacionais|||
|**Julgamento**|**Evidencias**|**Considerações adicionais**|
|**Benefíci**<br>**os e**<br>**riscos**<br>**Qual a qualidade da**|**evidencia**<br>Foi encontrado um estudo de coorte avaliou 238 pacientes<br>com intoxicação por inseticida colinérgico que receberam<br>lavagem gástrica.||  
207  
|`☐`Sem estudos<br>|O número (única ou múltiplas lavagens) ou o período de<br>lavagens gástricas (período menor ou maior que 1 h após a|
|---|---|
|`☐`Muito baixa<br>`☒`Baixa|intoxicação) não teve nenhuma associação com a<br>mortalidade, falha respiratória inicial e duração da<br>ventilação assistida.|
|`☐`Moderada<br>`☐`Alta|No entanto, pacientes que receberam múltiplas lavagens em<br>comparação com aqueles que receberam lavagem única<br>desenvolveram em níveis significativamente menores  falha<br>respiratória tardia (9,0% vs. 20,5%, RR (95% CI): 0,45<br>(0,26-0,88), p = 0,01) e síndrome intermediária (9,9% vs.<br>23,6%, RR (95% CI): 0,43 (0,23-0,82), p = 0,005)<br>(Andrews 2014)|
|**Há balanço entre os riscos e benefícios**|Não foi realizada a busca sistemática. A lavagem<br>gástrica pode apresentar algumas**complicações** **potenciais**<br>como:<br>hipoxemia;<br>pneumonia<br>aspirativa;<br>arritmias|
|`☐`Benefícios sobrepõem os riscos|cardíacas; perfuração do esôfago; perfuração do estômago;<br>hemorragia nas vias aéreas superiores; hemorragia|
|`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|conjuntival;<br>falha<br>respiratória;<br>desequilíbrio<br>hidroeletrolítico; laringoespasmo e pneumonia (Benson,<br>Hoppu, Troutman, Bedry, Erdman, Jer, et al. 2013)|  
208  
|||`☐`Bem aceito|
|---|---|---|
|**Valores  e**|**preferencias**|`☐`Indiferente<br>`☒`Mal aceito|
|||**Os custos associados à intervenção são**|
|||**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto|
|||`☒`Provavelmente sim|
|||`☐`Sim|
|||`☐`Há variabilidade|  
209  
||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☒`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|  
210  
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
|---|---|---|---|---|
||`☒`|`☐`|`☐`|`☐`|
|**Recomendação**|Não é recomendável a realizaçã|o rotineira de lavagem gástrica em p|acientes intoxicados com agrotóxi|cos.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações**<br>**implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|**Importantissimo!!!**||||
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`||`☐`|  
211  
||`☒`|
|---|---|
|**Recomendação**|Sugere-se o uso da lavagem gástrica em casos de ingestão de dose potencialmente letal de agrotóxicos que não sejam diluídos em<br>solventes orgânicos e corrosivos e exposição inferior a 60 minutos. Os clínicos devem considerar se os benefícios teóricos superam os<br>possíveis danos, e devem priorizar o tratamento por meio de cuidados de suporte vital.|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações**||
|**implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**|Definir a proporção de agrotóxicos aceitável como remanescente no estômago no momento de admissão no hospital que permita<br>determinar a efetividade da técnica.|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**P** População intoxicada com agrotóxicos  
**I** vômito  
**C** Ausência da intervenção  
**O** Redução da mortalidade  
**S** Clínicos e observacionais  
212  
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
||**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada|Estudo realizado com 592 pacientes intoxicados<br>com fármacos diversos comparou efetividade do<br>esvaziamento gástrico (xarope de ipeca ou<br>lavagem gástrica) prévio à administração de<br>carvão ativado e a administração apenas de<br>carvão ativado.  Os resultados indicaram que<br>esse têm benefícios questionáveis, considerando||
|**Benefícios e riscos**|`☐`Alta|que desfechos clínicos satisfatórios podem ser<br>obtidos sem que nenhum procedimento de<br>esvaziamento gástrico seja realizado de forma<br>rotineira<br>em<br>pacientes<br>intoxicados<br>por<br>medicamentos (Kulig et al. 1985).<br>A ingestão de xarope de ipeca atrasou a<br>administração de carvão ativado em pacientes<br>pediátricos, intoxicados por diferentes fármacos,<br>que<br>receberam<br>ambas<br>intervenções<br>em<br>comparação com aqueles tratados apenas com<br>carvão ativado. O prolongamento no tempo de<br>permanência no serviço de emergência também||  
213  
|foi observado para o grupo que recebeu|
|---|
|tratamento<br>prévio<br>com<br>ipeca<br>antes<br>da|
|administração do carvão ativado (Kornberg and|
|Dolgin 1991) Achados semelhantes já haviam|
|sido observados (Merigian 1990).<br>A efetividade de procedimentos de esvaziamento<br>|
|gástrico para a redução da disponibilidade|
|entérica também foi avaliada indicando que<br>|
|esses não reduzem de forma significativa o<br>conteúdo gástrico residual e nem tampouco a|
|disponibilização entérica do agente (Saetta et al.<br>1991; Saetta and Quinton 1991).|
|Em um estudo comparativo de avaliação de|
|eficácia do uso do xarope de ipeca, da|
|administração de carvão ativado e da lavagem<br>gástrica como medida de descontaminação para<br>os casos de intoxicação oral por paracetamol, a|
|efetividade da primeira e da última foram|
|semelhantes, sendo o uso do carvão considerado|
|como mais eficaz para a redução dos níveis|  
214  
||plasmáticos do agente tóxico. (Underhill,<br>Greene, and Dove 1990).|
|---|---|
|**Qual a qualidade da Evidência**|A ingestão de xarope de ipeca atrasou a administração de<br>carvão ativado em pacientes que receberam ambos em<br>comparação com aqueles que foram tratados apenas com|
|`☐`Sem estudos|carvão ativado (Kornberg and Dolgin 1991; Kulig et al.<br>1985).  O mesmo achado foi observado em um estudo|
|`☐`Muito baixa<br>`☒`Baixa|pediátrico onde crianças intoxicadas por medicamentos<br>diversos e tratadas com xarope de ipeca receberam carvão<br>ativado somente depois de 100 min, sendo que essas foram|
|`☐`Moderada|mais propensas a vomitarem carvão ativado do que as<br>crianças tratadas apenas com carvão ativado (18/32 vs|
|`☐`Alta|6/38, p<0,001). (Kornberg and Dolgin 1991)|
|**Há balanço entre os riscos e benefícios**||
|`☐`Benefícios sobrepõem os riscos||
|`☐`Há equilíbrio entre riscos e benefícios||
|`☒`Riscos sobrepõem os benefícios||  
215  
|||`☐`Bem aceito|
|---|---|---|
|**Valores  e**|**preferencias**|`☐`Indiferente<br>`☒`Mal aceito|
|||**Os custos associados à intervenção são**|
|||**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto|
|||`☐`Provavelmente sim|
|||`☒`Sim|
|||`☐`Há variabilidade|  
216  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☒`Há variabilidade|  
217  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☒`|`☐`|`☐`|`☐`|
|**Recomendação**|O vômito não deve ser in<br>inibição, caso ele ocorra d|duzido como medida de desco<br>e forma espontânea em pacien|ntaminação. Entretanto, tam<br>tes intoxicados.|bém não é indicada a sua|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Irrigação intestin**|**al**||||
|**P**População intoxicada com agrot|óxicos||||
|**I**Irrigação intestinal|||||  
218

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Não foram encontrados estudos clínicos onde tratamento<br>com irrigação intestinal total foi utilizado como medidade<br>de descontaminação em casos de intoxicação por<br>agrotóxicos.  Foram encontrados somente quatro estudos<br>clínicos<br>randomizados<br>controlados<br>sobre<br>irrigação<br>intestinal total como medida de descontaminação a partir<br>de uma revisão sistemática (Thanacoody et al. 2015).<br>São estudos crossover, em voluntários, realizados com<br>medicamentos em cápsulas de liberação sustentada ou<br>retardada. No entanto, esses estudos apresentam evidências<br>inconsistentes: dois estudos mostraram a efetividade do<br>procedimento, um mostrou que o tratamento não foi<br>efetivo, e o outro que não houve aumento da efetividade<br>quando o tratamento foi administrado junto com carvão<br>ativado, podendo inclusive reduzir a eficácia do carvão<br>ativado para alguns medicamentos. Até o momento, faltam<br>evidências de qualidade mostrando a melhora dos<br>desfechos clínicos com a técnica de irrigação intestinal||  
219  
||||total (Kirshenbaum et al. 1989; Lapatto‐ Reiniluoto,<br>Kivistö, and Neuvonen 2001; Ly, Schneir, and Clark 2004;<br>Smith, Ling, and Halstenson 1991).|
|---|---|---|---|
|||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|Dentre as**complicações**estão: náusea;  vômito;<br>dor abdominal; distensão abdominal;  angioedema;<br>anafilaxia;  laceração de Mallory-Weiss e broncoaspiração<br>(Thanacoody et al. 2015).|
|**Valores  e**|**preferencias**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito||  
220  
||**Os custos associados à intervenção são**<br>**pequenos?**|
|---|---|
||`☐`Não|
||`☒`Provavelmente não|
|**Custos**|`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
221  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim<br>`☐`Há variabilidade|  
222  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☒`|`☐`|`☐`|`☐`|
|**Recomendação**|A irrigação intestinal total não|deve ser realizada no paciente intoxic|ado por agrotóxicos.||
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: catártico**|||||
|**P**População intoxicada com agrot|óxicos||||
|**I**catártico|||||  
223  
|**C**Ausência|da intervenção|
|---|---|  
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**nefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Não foram encontrados ensaios clínicos randomizados<br>controlados sobre a utilização de catárticos para o<br>tratamento de pacientes com intoxicação aguda por<br>agrotóxicos. Por outro lado, a partir de revisão sistemática<br>(Barceloux 2004), três estudos clínicos randomizados com<br>evidências sobre o uso de catártico sozinho como medida<br>de eliminação corpórea de medicamentos emergiram na<br>busca. Todos eles antigos, com um número muito limitado<br>de voluntários, e que mostraram que o catártico sozinho não<br>reduz a absorção do agente (Al-Shareef et al. 1990; Minton<br>and Hentry 1995; Sørensen 1975).||
|**Be**|**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☒`Riscos sobrepõem os benefícios|As complicações do uso de catártico são<br>(Barceloux 2004):<br><br>Dose única: cólicas abdominais, náuseas, vômitos,<br>diaforese, hipotensão.<br><br>Doses múltiplas ou excessivas: desidratação;<br>hipernatremia em pacientes que recebem catártico<br>contendo sódio ou doses excessivas de sorbitol;<br>hipermagnesemia em pacientes que recebem<br>catártico contendo magnésio.||  
224  
|||`☐`Bem aceito|
|---|---|---|
|**Valores  e**|**preferencias**|`☐`Indiferente<br>`☒`Mal aceito|
|||**Os custos associados à intervenção são**|
|||**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto|
|||`☐`Provavelmente sim|
|||`☒`Sim|
|||`☐`Há variabilidade|  
225  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☒`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim<br>`☐`Há variabilidade|  
226  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☒`|`☐`|`☐`|`☐`|
|**Recomendação**|Não se recomenda o uso de catá|rticos como medida de eliminação p|ara o tratamento do paciente intox|icado por agrotóxicos.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Alcalinização uri**|**nária**||||
|**P**População intoxicada com agro|tóxicos||||
|**I**Alcalinização urinária|||||
|**C**Ausência da intervenção|||||  
227  
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Quatro estudos de caso (Friesen, Jones, and Vaughan 1990;<br>Jearth et al. 2015; Prescott, Park, and Darrien 1979;<br>Schmoldt, Iwersen, and Schlüter 1997) e uma série de casos<br>(Flanagan et al. 1990) avaliaram a efetividade da técnica,<br>considerando a depuração renal e a redução da concentração<br>plasmática de herbicidas do ácido clorofenoxi por meio da<br>alcalinização urinária. Em um dos estudos de caso foi<br>reportado um declínio do tempo de meia-vida razoável.||
||**Há balanço entre os riscos e benefícios**<br>`☐`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios|As**complicações**mais comuns da alcalinização<br>urinária são: Proudfoot A.T., 2004; Lawson A.A.H. et al.,<br>1969; Berg K.J., 1977 Fox G.N., 1984<br><br>Alcalose metabólica;<br><br>Tetania alcalítica (ocasionalmente);<br><br>Hipocalemia;<br><br>Hipocalcemia (mais raramente).||  
228  
|||`☒`Riscos sobrepõem os benefícios|As**contraindicações** **absolutas**da alcalinização<br>urinária são: insuficiência renal aguda; doença renal<br>crônica.<br>A<br>falha<br>cardíaca<br>pré-existente<br>é<br>uma<br>**contraindicações relativa**da alcalinização urinária.|
|---|---|---|---|
|**Valores  e**|**preferencias**|`☐`Bem aceito<br>`☒`Indiferente<br>`☐`Mal aceito||
|||**Os custos associados à intervenção são**<br>**pequenos?**<br>`☐`Não||
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim<br>`☒`Sim<br>`☐`Há variabilidade||  
229  
||**A opção é aceitável para as principais partes**<br>**interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|  
230  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☒`|`☐`|`☐`|
|**Recomendação**|Não se recomenda o uso rotineir<br>por agrotóxicos. Contudo, há in<br>natureza acídica, como é o caso|o de alcalinização urinária com bicar<br>dícios de considerá-la como um alte<br>dos derivados do ácido clorofenoxia|bonato como medida de eliminaç<br>rnativa razoável para os casos de<br>cético, a partir de estudos com nív|ão no tratamento de intoxicações<br>intoxicação por agrotóxicos de<br>el de evidência muito baixa.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações**|||||
|**implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|**No texto**||||  
231

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**QUADRO I.6.2** – Tabela com o detalhamento da avaliação consensual do Grupo Elaborador das recomendações para a prevenção de Intoxicações por agrotóxicos.  
|**PERGUNTA:**|**Prevenção de acidentes em crianças**|||
|---|---|---|---|
|**P**Crianças||||
|**I**Fontes domé|sticas de exposição ou contato|||
|**C**Ausência da|intervenção|||
|**O**Incidência d|e intoxicação|||
|**S**Clínicos e ob|servacionais|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☐`Muito baixa<br>`☒`Baixa<br>`☐`Moderada|Um estudo de caso-controle mostrou que manter<br>medicamentos ao alcance de crianças ou não armazená-<br>los de forma segura, bem como não guardá-los<br>imediatamente após o uso, aumenta as chances de<br>assistência secundária à intoxicações em crianças com<br>idade entre 0 e 4 anos de idade. Se tais associações forem<br>causais, a implementação de práticas de prevenção<br>poderiam reduzir de 11 a 20% dos casos de intoxicações<br>(Kendrick_et al._, 2017). Espera-se que o armazenamento<br>adequado de agrotóxicos também contribua para a||  
232  
|`☐`Alta|redução do número de intoxicações. Verificou-se<br>também que as intoxicações eram mais frequentes em<br>domicílios com famílias monoparentais (Kendrick_et al._,<br>2017).|
|---|---|
||Um estudo prospectivo, multicêntrico, internacional, que<br>analisou mais de 360 mil emergências pediátricas<br>concluiu que mais de 30% das intoxicações pediátricas<br>na região da América do Sul e do Mediterrâneo Oriental,<br>envolveram cuidadores que admitiram manter a<br>substância tóxica em um recipiente não-original. Além<br>disso, em 44,5% (IC 95%, 38,9% - 50,0%) das<br>intoxicações não intencionais devido a produtos<br>domésticos, os cuidadores admitiram não manter esses<br>produtos fora do alcance das crianças (Mintegi_et al._,<br>2017).|
||Ao se avaliar os casos de intoxicações pediátricas<br>acidentais, observou-se que em 70% das intoxicações<br>com querosene, este havia sido armazenado em garrafas<br>de refrigerante (Azizi et al., 1994).|
|**Há balanço entre os riscos e benefícios**||
|`☒`Benefícios sobrepõem os riscos||  
233  
|||`☐`Há equilíbrio entre riscos e benefícios|
|---|---|---|
|||`☐`Riscos sobrepõem os benefícios|
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|
|||**Os custos associados à intervenção são**<br>**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
|||`☒`Sim 3<br>`☐`Há variabilidade|  
234  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim 4|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim 6|
||`☐`Há variabilidade|  
235  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**<br>**Cobertura**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Recomenda-se para a prevenção<br><br>Reduzir e eliminar possíveis<br><br>Evitar estocar substâncias tó<br><br>Aumentar a atenção e cuida<br><br>Não armazenar agrotóxicos<br>de crianças;<br><br>Não reutilizar embalagens d<br><br>Descartar de acordo com a i|de acidentes por agrotóxicos em<br>fontes domésticas de exposição<br>xicas em casa ou ao alcance das<br>do às crianças;<br>de maneira inapropriada, como e<br>e agrotóxicos;<br>ndicação no rótulo do produto.|crianças:<br>ou contato;<br>crianças;<br>m garrafas de refrigerante ou ute|nsílios que chamem a atenção|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||  
236

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
**P** Crianças  
**I** Embalagens especiais de proteção  
**C** Ausência da intervenção  
**O** Incidência de intoxicação  
|**S**Clínicos|e observacionais||
|---|---|---|
||**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☐`Muito baixa<br>`☐`Baixa<br>`☒`Moderada<br>`☐`Alta|O uso de embalagens especiais de proteção a crianças em<br>medicamentos prescritos foi associado a uma redução<br>anual da taxa de mortalidade de 1,4 mortes por milhão de<br>crianças abaixo dos 5 anos de idade (IC95% 0,85-1,95)<br>(Rodgers, 1996).|  
237  
|||**Há balanço entre os riscos e benefícios**|
|---|---|---|
|||`☒`Benefícios sobrepõem os riscos|
|||`☐`Há equilíbrio entre riscos e benefícios|
|||`☐`Riscos sobrepõem os benefícios|
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|  
238  
||**Os custos associados à intervenção são**|
|---|---|
||**pequenos?**|
||`☐`Não|
|**Custos**|`☐`Provavelmente não<br>`☐`Incerto|
||`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
239  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|  
240  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**|**Recomendação**|**Recomendação**|**Recomendação forte a**|
|**Cobertura**|**contra a intervenção**|**condicional/fraca**<br>**contra a intervenção**|**condicional a favor da**<br>**intervenção**|**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Aos fabricantes de agrotóxicos|de uso doméstico recomenda-se|considerar o uso de embalagens es|peciais de proteção à criança.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Prevenção de suicí**|**dio**||||
|**P**Homens e mulheres com intenção|suicida||||
|**I**controle regulatório|||||
|**C**Ausência da intervenção|||||  
241

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da Evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Um estudo realizado na Coreia do Sul mostrou que a taxa<br>global de suicídio associada a agrotóxicos diminuiu entre<br>2003-2013, independentemente do tipo de produto, após<br>a implementação de diversas medidas regulatórias<br>direcionadas ao controle desses produtos no país. Essa<br>redução foi mais pronunciada após a proibição do<br>paraquat (Cha_et al._, 2015).  Outro estudo, realizado no<br>Sri Lanka, evidenciou uma diminuição em 50% na taxa<br>de suicídios após a proibição de agrotóxicos da Classe I e<br>restrições nos de classe II. Contudo, o número de<br>hospitalizações relacionadas às intoxicações intencionais<br>por agrotóxicos aumentou (Roberts et al, 2003; Gunnell<br>et al, 2007; Knipe et al, 2014).   A proibição dos<br>agrotóxicos mais tóxicos pode ter contribuído na redução<br>de mortes por suicídio (Roberts 2003; Knipe 2014;<br>Gunnell et al 2007, Knipe 2017).<br>Em Bangladesh, a mortalidade por intoxicação por<br>agrotóxicos reduziu no período após a proibição dos<br>produtos mais tóxicos, com uma redução relativa de<br>37,1%, (IC 95% 35,4 a 38,8%).  A taxa de suicídio por||  
242  
||intoxicação por agrotóxicos caiu de 6,3/100.000, antes da<br>proibição, para 2,2/100.000. Isso corresponde a um<br>declínio de 65,1% (IC95% de 52,0 a 76,7%) (Chowdhury<br>_et al_, 2017).<br>Já um estudo realizado em Taiwan demostrou que<br>medidas de restrição de disponibilidade de agrotóxicos<br>reduzem a taxa de suicídio, sem haver o aumento<br>compensatório desta por outros métodos (Lin e Lu, 2011).<br>Além disso, foi visto que a proibição seletiva dos<br>agrotóxicos de maior toxicidade, os quais eram<br>associados ao maior número de mortes por intoxicação<br>intencional, não causou prejuízo aos agricultores, no que<br>tange a produtividade, no Sri Lanka (Manuweera_et al._,<br>2008).|
|---|---|
|**Há balanço entre os riscos e benefícios**||
|`☒`Benefícios sobrepõem os riscos||
|`☐`Há equilíbrio entre riscos e benefícios||
|`☐`Riscos sobrepõem os benefícios||  
243  
|||`☒`Bem aceito|
|---|---|---|
|**Valores  e**|**preferências**|`☐`Indiferente<br>`☐`Mal aceito|
|||**Os custos associados à intervenção são**<br>**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto|
|||`☒`Provavelmente sim|
|||`☐`Sim|
|||`☐`Há variabilidade|  
244  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☒`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
245  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**|**Recomendação**|**Recomendação**|**Recomendação forte a**|
|**Cobertura**|**contra a intervenção**|**condicional/fraca**<br>**contra a intervenção**|**condicional a favor da**<br>**intervenção**|**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Reforçar o controle regulatório e<br>da toxicidade dos agrotóxicos re|a revisão de registros pela autori<br>gistrados ou comercializados no|dade sanitária, estabelecendo um p<br>Brasil, considerando evidências d|rocesso de avaliação periódica<br>e segurança.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Prevenção de suicíd**|**io**||||
|**P**Homens e mulheres com intenção|suicida||||
|**I**redução de acesso aos agrotóxicos|||||  
246  
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Estudos realizados em comunidades rurais na Índia<br>indicaram que a construção de instalações comunitárias<br>centralizadas<br>de<br>armazenagem<br>de<br>agrotóxicos,<br>supervisionadas e trancadas, pode contribuir para a<br>redução do número de casos de suicídio por essas<br>substâncias, por dificultar o acesso (Vijayakumar_et al._,<br>2013; Mohanraj_et al._, 2014).||
||**Há balanço entre os riscos e benefícios**|||
||`☒`Benefícios sobrepõem os riscos|||  
247  
|||`☐`Há equilíbrio entre riscos e benefícios|
|---|---|---|
|||`☐`Riscos sobrepõem os benefícios|
|**Valores  e**|**preferências**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito|
|||**Os custos associados à intervenção são**<br>**pequenos?**|
|||`☐`Não|
|**Custos**||`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
|||`☐`Sim<br>`☐`Há variabilidade|  
248  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☒`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☒`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☒`Há variabilidade|  
249  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**<br>**Cobertura**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca**<br>**contra a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☒`|`☐`|
|**Recomendação**|Desenhar estratégias de prevenç<br>redução do acesso aos agrotóxic|ão intersetoriais apropriadas ao<br>os, tal como a proposição de cent|contexto local, para comunidades<br>rais de armazenamento.|rurais, que contribuam para a|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: EPI**|||||
|**P**População intoxicada com agrot|óxicos||||
|**I**EPI|||||  
250  
|**C**Ausênci|a da intervenção|||
|---|---|---|---|
|**O**Reduçã|o da mortalidade|||
|**S**Clínicos|e observacionais<br>|||
||**Julgamento**|**Evidências**|**Considerações adicionais**|
||**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa|Estudo realizado em Santa Catarina indicou que<br>agricultores que afirmavam utilizar EPI durante o<br>manuseio e uso de agrotóxicos apresentaram 70% menos<br>sintomas de intoxicação, quando comparados aos que não<br>o utilizavam (RP=0,29; IC95%= 0,05 – 1,70; p=0,049)<br>(Savi_et al._, 2010).||
|**Benefícios e riscos**|`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Dados relacionados à intoxicação por agrotóxicos de 152<br>manipuladores foram avaliados por meio de um estudo<br>realizado em Teresópolis (RJ). Foi observado que<br>indivíduos que não usam nenhum tipo de EPI têm 19 vezes<br>mais chance de se intoxicar em relação aos indivíduos que<br>usam ao menos um tipo de proteção. Quando o motivo<br>para o não uso é o calor, essa chance aumenta em 53 vezes.<br>O estudo também indicou que a utilização de óculos de<br>proteção, de macacão, de máscara e uso de roupa de<br>aplicação somente um dia, reduz as chances de intoxicação<br>em, respectivamente, 56%, 14%, 83% e 78% (Soares_et_<br>_al._, 2005).||  
251  
|||Um estudo descritivo envolvendo 282 agricultores da<br>fruticultura em um município do Rio Grande do Sul,<br>indicou que a ocorrência de casos possiveis de<br>intoxicações<br>agudas,<br>segundo<br>a<br>ferramenta<br>de<br>classificação proposta pela OMS, foi maior entre<br>trabalhadores que não usavam máscaras (p=0,02) e<br>proteção na cabeça (p=0,07) e a incidência de intoxicação<br>no ultimo ano, referrida pelos trabalhadores, foi menor<br>entre aqueles que informaram usar “sempre” máscaras,<br>proteção de cabeça e roupas de proteção (p<0,01) (Faria et<br>al. 2009).|
|---|---|---|
||**Há balanço entre os riscos e benefícios**|Não houve consenso entre o grupo em relação a<br>essa questão – sugestão de pesquisa e profundamento|
||`☐`Benefícios sobrepõem os riscos<br>`☒`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios||
|**Valores  e**<br>**preferências**|`☐`Bem aceito<br>`☐`Indiferente<br>`☒`Mal aceito||  
252  
||**Os custos associados à intervenção são**|
|---|---|
||**pequenos?**|
||`☒`Não|
|**Custos**|`☐`Provavelmente não<br>`☐`Incerto|
||`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
253  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☒`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☐`Sim<br>`☐`Há variabilidade|  
254  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☒`|`☐`|
|**Recomendação**|Recomenda-se o uso de Equipa<br>de intoxicação ocupacional por|mentos de Proteção Individual (EPI)<br>agrotóxicos.|, de acordo com as normas vigent|es, para a redução da incidência|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|Importante – riscos X ben|efícios EPI|||
|**PERGUNTA: Higiene no local d**|**e trabalho**||||  
255

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
|**O**Redução da mortalidade|
|---|  
|**S**Clínico|s e observacionais|||
|---|---|---|---|
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Aspectos higiênicos são importantes preditores da<br>intoxicação, pois trabalhadores rurais que não trocam ou<br>lavam a roupa, após a última aplicação de agrotóxico, têm<br>riscos de intoxicação aumentados em 126 vezes quando<br>comparados aos que adotam essas práticas (Soares_et al._,<br>2005).||
||**Há balanço entre os riscos e benefícios**|||  
256  
|||`☒`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios|
|---|---|---|
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|  
257  
||**Os custos associados à intervenção são**|
|---|---|
||**pequenos?**|
||`☐`Não|
|**Custos**|`☒`Provavelmente não<br>`☐`Incerto|
||`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
258  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|  
259  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Recomenda-se disponibilizar no<br>ou utilização de agrotóxicos par|ambiente de trabalho um local para<br>a a redução na incidência de intoxic|que o trabalhador possa realizar a<br>ação ocupacional.|higiene pessoal após o contato|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Lavagem do EPI**|**no local de trabalho**||||
|**P**População intoxicada com agrot|óxicos||||
|**I**Lavagem do EPI no local de tra|balho||||  
**C** Ausência da intervenção  
260

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
||**Qual a qualidade da evidência**<br>`☐`Sem estudos|A lavagem de EPI em tanque de uso doméstico aumenta a<br>chance de intoxicação em 56 vezes em relação aos<br>indivíduos que adotam outras práticas mecânicas de<br>lavagem desse tipo de equipamento (Soares_et al._, 2005).||
||`☒`Muito baixa|||
|**Benefícios e riscos**|`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|||
||**Há balanço entre os riscos e benefícios**|||
||`☒`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios|||  
261  
|||`☐`Riscos sobrepõem os benefícios|
|---|---|---|
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|  
262  
||**Os custos associados à intervenção são**<br>**pequenos?**|
|---|---|
||`☐`Não|
|**Custos**|`☒`Provavelmente não<br>`☐`Incerto|
||`☐`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
263  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
264  
||A opção é viável para implementar?|
|---|---|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
|**Tipo de recomendação**|**Recomendação forte**|**Recomendação**|**Recomendação**|**Recomendação forte a**|
|---|---|---|---|---|
||**contra a intervenção**|**condicional/fraca contra**<br>**a intervenção**|**condicional a favor da**<br>**intervenção**|**favor da intervenção**|
||`☐`|`☐`||`☒`|
||||`☐`||  
265  
|**Recomendação**<br>Recomenda-se a lavag<br>exposição decorrente d|em dos EPI no local de trabalho com máquinas de lavar roupas exclusivas para essa finalidade, evitando a<br>a lavagem manual.|
|---|---|
|**Justificativa**||
|**Considerações subgrupo**||
|**Considerações implementação**||
|**Monitoramento e avaliação**||
|**Prioridades de pesquisa**||
|**PERGUNTA: Educação**||
|**P**Homens e mulheres com intenção suicida||
|**I**Educação||
|**C**Ausência da intervenção||
|**O**Incidência de intoxicação||
|**S**Clínicos e observacionais||
|**Julgamento**|**Evidências**<br>**Considerações adicionais**|
|**Benefícios**<br>**e riscos**<br>**Qual a qualidade da evidência**|Intervenções educacionais em relação à leitura do rótulo,<br>efeitos adversos à saúde, estocagem em local seguro e uso<br>de EPI para o manuseio de agrotóxico entre agricultores<br>resultaram numa melhor pontuação geral no questionário|  
266  
|`☐`Sem estudos|de conhecimento, atitude e prática (CAP). Entretanto,|
|---|---|
||houve deficiência na retenção do conhecimento e não foi|
|`☒`Muito baixa<br>`☐`Baixa|verificada uma melhoria significativa em relação às<br>práticas adotadas em relação aos agrotóxicos (Sam_et al._,<br>2007a).|
|`☐`Moderada<br>`☐`Alta|A intervenção educacional, baseada em uma sessão única<br>de treinamento, apesar de contribuir para a adesão do uso<br>de equipamentos de aplicação e uma redução do número de<br>agrotóxicos utilizados, não foi considerada efetiva para<br>aumentar a adesão ao uso de EPI e nem tampouco para uma<br>redução da exposição dérmica (Perry e Layde, 2003).<br>A percepção sobre a adoção de medidas de segurança em<br>relação ao uso de agrotóxicos é maior em agricultores com<br>um maior nível de educação formal, bem como entre os que<br>tiveram experiências prévias de intoxicação com esses<br>produtos. A preferência de temas para treinamentos se<br>mostrou variável de acordo com o grupo etário (Hashemi_et_<br>_al._, 2012).|
||Outro estudo com trabalhadoras agrícolas revelou que o<br>conhecimento que essas apresentavam em relação à<br>segurança do manuseio de agrotóxicos era resultante de<br>treinamentos e outras formasde aprendizado. Contudo,<br>esse grupo de trabalhadoras indicou a necessidade de mais<br>capacitação, pois não se consideravam seguras ao manusear|  
267  
||||esse tipo de produto, principalmente se estivessem<br>grávidas. Elas indicaram que os treinamentos poderiam ser<br>oferecidos pelo empregador, pelos seus supervisores e por<br>profissionais da área de saúde (Flocks_et al._, 2012).|
|---|---|---|---|
|||**Há balanço entre os riscos e benefícios**||
|||`☒`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios||
|||`☐`Riscos sobrepõem os benefícios||
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito||  
268  
||**Os custos associados à intervenção são**|
|---|---|
||**pequenos?**|
||`☐`Não|
|**Custos**|`☐`Provavelmente não<br>`☐`Incerto|
||`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|  
269  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
||`☐`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim 3<br>`☐`Há variabilidade|  
270  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**|**Recomendação**|**Recomendação**|**Recomendação forte a**|
|**Cobertura**|**contra a intervenção**|**condicional/fraca contra**<br>**a intervenção**|**condicional a favor da**<br>**intervenção**|**favor da intervenção**|
||`☐`|`☐`|`☐`|`☒`|
|**Recomendação**|Recomenda-se aos profissionais<br>treinamento e assistência técnic<br><br>Considerem e valorizem a c<br><br>Auxiliem a compreensão do<br><br>Promovam o cuidado e min<br><br>Orientem pessoas a compre<br><br>Considerem as questões de|de saúde e empregadores a realizaçã<br>a que:<br>onstrução coletiva, práticas e sabere<br>real potencial da toxicidade do pro<br>imizem os perigos da exposição ocu<br>ender e interpretar os símbolos utiliz<br>gênero e faixas etárias.|o de programas de educação conti<br>s do trabalhador;<br>duto;<br>pacional;<br>ados em rótulos e embalagens de|nuada por meio de capacitações,<br>agrotóxicos;|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações implementação**|||||
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|||||
|**PERGUNTA: Lavagem do alim**|**ento**||||  
271  
**P** População intoxicada com agrotóxicos  
**I** Lavagem do alimento  
**C** Ausência da intervenção

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
||**Julgamento**|**Evidências**|**Considerações adicionais**|
|---|---|---|---|
|**Benefícios e riscos**|**Qual a qualidade da evidência**<br>`☐`Sem estudos<br>`☒`Muito baixa<br>`☐`Baixa<br>`☐`Moderada<br>`☐`Alta|Foram encontrados diversos estudos que indicam a redução<br>de resíduos de agrotóxicos em alimentos quando lavados<br>com água corrente, ácido acético, limoneno, detergente e<br>suas combinações. Essa redução encontrada nesses estudos<br>foi entre 14 e 97% e varia de acordo com o agrotóxico<br>(Soliman, 2001; Hassanzadeh_et al._, 2010; Hao_et al._, 2011;<br>Kusvuran_et al._, 2012; Kong_et al._, 2012; Al-Taher_et al._,<br>2013; Lu_et al._, 2013; Saeedi Saravi e Shokrzadeh, 2014;<br>Rani_et al._, 2013; Mujawar_et al._, 2014; Mekonen_et al._,<br>2015).||
||**Há balanço entre os riscos e benefícios**|||  
272  
|||`☒`Benefícios sobrepõem os riscos<br>`☐`Há equilíbrio entre riscos e benefícios<br>`☐`Riscos sobrepõem os benefícios|
|---|---|---|
|**Valores  e**|**preferências**|`☒`Bem aceito<br>`☐`Indiferente<br>`☐`Mal aceito|
|||**Os custos associados à intervenção são**<br>**pequenos?**|
|||`☐`Não|
|**Custos**||`☐`Provavelmente não<br>`☐`Incerto<br>`☒`Provavelmente sim|
|||`☐`Sim<br>`☐`Há variabilidade|  
273  
||**A opção é aceitável para as principais**<br>**partes interessadas?**|
|---|---|
||`☐`Não|
|**Aceitabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|
||A opção é viável para implementar?|
||`☐`Não|
|**Viabilidade**|`☐`Provavelmente não<br>`☐`Incerto<br>`☐`Provavelmente sim|
||`☒`Sim|
||`☐`Há variabilidade|  
274  
|||**Conclusão**|||
|---|---|---|---|---|
|**Tipo de recomendação**|**Recomendação forte**<br>**contra a intervenção**|**Recomendação**<br>**condicional/fraca contra**<br>**a intervenção**|**Recomendação**<br>**condicional a favor da**<br>**intervenção**|**Recomendação forte a**<br>**favor da intervenção**|
||`☐`|`☐`|`☒`|`☐`|
|**Recomendação**|Recomenda-se a lavagem dos al|imentos para auxiliar na redução de|resíduos de agrotóxicos de contato|em alimentos.|
|**Justificativa**|||||
|**Considerações subgrupo**|||||
|**Considerações**<br>**implementação**|Os agrotóxicos de contato|representam menos de 20% do|s agrotóxicos utilizados (Fo|nte não encontrada)|
|**Monitoramento e avaliação**|||||
|**Prioridades de pesquisa**|Pesquisar agrotóxicos sistê|micos e formas de diminuir os|resíduos||  
275  
**Anexo I.7 – Recomendações à população**

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
(http://abracit.org.br/wp/inseticidas/)  
Antes da manipulação dos agrotóxicos, consulte a bula do produto para obter informações de quais medidas devem ser tomadas para reduzir o risco de intoxicação, e como proceder caso ocorra uma intoxicação acidental.  
Agrotóxicos de uso agrícola nunca devem ser utilizados em casa, pois podem provocar intoxicações graves.  
Guarde o agrotóxico utilizado imediatamente após o uso. E mantenha o produto tampado quando não estiver em uso.  
Mantenha sempre o agrotóxico na sua embalagem original, fora do alcance de crianças, longe de alimentos e medicamentos.  
Nunca utilize embalagens de alimentos (como latas de leite em pó, garrafas de refrigerantes) para estocar produtos químicos.  
Não permita que a crianças apliquem agrotóxicos ou brinquem com as embalagens dos produtos.  
Mantenha longe do alcance de crianças, de preferência em local fechado e alto, substâncias que possam conter agrotóxicos (produtos para matar mosquitos, baratas ou ectoparasitas de animais de estimação) Remova crianças e brinquedos antes de aplicar agrotóxicos fora ou dentro de casa. Leia as instruções do rótulo para determinar quando crianças e podem voltar a entrar na área que foi tratada.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
- Caso tenha sido exposto a agrotóxicos mantenha a calma e ligue imediatamente para o Centro de Informação e Assistência Toxicológica (CIATox) da sua região para esclarecimentos sobre os primeiros socorros para cada tipo de substância tóxica.  
**Disque-intoxicação é 0800 722 6001**  
292  
- Ou ao Serviço de Atendimento Móvel de Urgência (SAMU), especialmente em casos mais graves.

---

<!-- METADADOS: doenca: Diagnóstico e tratamento de intoxicações por agrotóxicos - Capítulo 1 | secao: **Anexo I.6 – AVALIAÇÃO DE RECOMENDAÇÕES POR GRADE** -->
- Relate as condições da possível vítima e o ambiente em que ela se encontra. Se possível, informe o tipo de produto que originou a intoxicação (esta informação está disponível no rotulo ou bula do produto).  
- Caso você se depare com um incidente envolvendo agrotóxicos, assegure-se, primeiramente, de sua própria segurança para, então, poder proporcionar auxílio às demais pessoas a seu redor.  
- Quem proporciona os primeiros socorros deve se proteger da exposição. Deve-se ter cuidado especial com contato dérmico e inalatório (luvas, máscaras).  
- Após avaliação dos riscos da cena, se possível, retire imediatamente a pessoa afetada da área de exposição e transfira-lhe para um local arejado.  Não se esqueça de contatar o serviço de emergência.  
- Não provoque vômito na vítima. Não administre comidas, bebidas ou medicamentos, a não ser que seja indicado pelo pessoal especializado.  
- Retire a roupa contaminada. Não reutilizar a roupa removida.  
- Lave a pele contaminada com água corrente abundante e sabão neutro.  
- Em caso de contaminação ocular, vire a cabeça de lado e lave cada olho com água corrente durante pelo menos 15 min, mantendo a pálpebra aberta, sem deixar a água suja entrar no outro olho.  
- Caso a respiração diminua, retire qualquer objeto que esteja causando obstrução (prótese dental, lenços, etc).  
- Em caso de desmaio ou perda de consciência, coloque a pessoa afetada deitada com a cabeça para a esquerda.  
- Transporte de imediato o paciente ao centro de assistência mais próximo.  
- Se possível, leve o rótulo ou informações do produto a que foi exposto para conhecimento do médico.  
- Não confie em informações da Internet que não sejam de sites oficiais.  
Eddleston 2008 EPA 2017 https://archive.epa.gov/pesticides/news/web/html/prevent-poisonings.html  
293

---

