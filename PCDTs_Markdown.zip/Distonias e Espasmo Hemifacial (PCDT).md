<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Geral -->
<!-- Start of picture text -->
ne A ee<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO À SAÚDE  
PORTARIA CONJUNTA Nº 1, DE 29 DE MAIO DE 2017.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas de Distonias e Espasmo Hemifacial.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e o SECRETÁRIO DE CIÊNCIA E TECNOLOGIA E INSUMOS ESTRATÉGICOS, no uso das atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre as distonias e espasmo hemifacial no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com estes distúrbios;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 234/2017, o Relatório de Recomendação n<sup><u>o</u></sup> 252 – Fevereiro de 2017 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica da CONITEC, do Departamento de Gestão da Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Fica aprovado, na forma do Anexo, disponível no sítio: <u>www.saude.gov.br/sas, o</u> Protocolo Clínico e Diretrizes Terapêuticas - Distonias e Espasmo Hemifacial.  
Parágrafo único. O Protocolo de que trata este artigo, que contém o conceito geral de distonias e espasmo hemifacial, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento das distonias e espasmo hemifacial.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com esses distúrbios em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 376/SAS/MS, de 10 de novembro de 2009, publicada no Diário Oficial da União nº 215, de 11 de novembro de 2009, seção 1, páginas 61-64.  
FRANCISCO DE ASSIS FIGUEIREDO  
MARCO ANTÔNIO DE ARAÚJO FIREMAN

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 1 INTRODUÇÃO -->
A distonia é um distúrbio do movimento caracterizado por contrações musculares sustentadas ou intermitentes que produzem movimentos anormais, posturas anormais ou ambos. Os movimentos são tipicamente estereotipados, em torção, podendo ser tremulantes. A distonia é com frequência iniciada ou exacerbada por movimento ou postura e associada a transbordamento da ativação muscular (1).  
As distonias são classificadas, segundo a _Movement Disorders Society_ (1), em dois eixos, baseados nas características clínicas (Eixo 1) e na etiologia (Eixo 2). O principal objetivo dessa classificação é facilitar o reconhecimento clínico, o diagnóstico e, por consequência, uma escolha terapêutica adequada.  
O Eixo 1, que enfoca as manifestações clínicas das distonias, inclui quatro características baseadas nos seguintes fatores: idade de início, distribuição corporal, padrão temporal e qualquer manifestação clínica associada:

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 1. Idade de início -->
Do nascimento aos 2 anos; Crianças de 3-12 anos; Adolescentes de 13-20 anos; Adultos de 21-40 anos; Adultos acima de 40 anos.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 2. Distribuição corporal -->
Focal: afeta uma região isolada do corpo;  
Segmentar: envolve duas partes vizinhas: por exemplo, o pescoço e um braço; tronco e região cervical; um braço e ombro, ou ambos os braços; uma perna (ou ambas) e tronco;  
Multifocal: afeta duas ou mais partes não vizinhas do corpo; Generalizada: afeta o tronco e pelo menos dois outros sítios; Hemidistonia: braço e perna ipsilateral.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3. Padrão temporal -->
Curso: estático ou progressivo;  
Variabilidade: persistente, específica de uma ação (“ação-específica”), flutuação diurna ou paroxística.  
4. Coexistência de outros movimentos anormais Isolada;  
Combinada com outro distúrbio do movimento; Associada a outras manifestações neurológicas; Associada a manifestações sistêmicas.  
O Eixo 2, baseado na etiologia presumida, é classificado de acordo com evidência de doença do sistema nervoso (processo degenerativo, lesão estrutural ou ambos) e hereditariedade (hereditária ou adquirida). Quando a etiologia não é definida, é classificada como idiopática.  
A incidência das formas focais de distonia é estimada em dois novos casos por milhão de habitantes por ano, resultando em uma prevalência de 29,5 casos por 100.000 habitantes (1, 2). Esses números são maiores do que de outras doenças neurológicas bem conhecidas, como doença do neurônio motor, miastenia grave ou doença de Huntington.  
O tratamento das distonias é essencialmente sintomático e se baseia no alívio das contrações musculares, revertendo os movimentos e as posturas anormais e a dor associada e prevenindo contraturas e deformidades. A toxina botulínica tipo A (TBA) representa uma opção reconhecida para esse tratamento, sendo considerada o tratamento de escolha na maioria das distonias (2).  
O espasmo hemifacial é definido como uma condição na qual ocorrem contrações involuntárias clônicas irregulares ou movimentos tônicos dos músculos inervados pelo sétimo nervo craniano ipsilateral. Os espasmos geralmente começam como "espasmos" da pálpebra inferior, seguidos pelo acometimento periorbital e dos músculos faciais, periorais e platisma. Essa condição, muitas vezes, leva ao constrangimento social e interfere na visão por fechamento involuntário dos olhos. Embora o espasmo hemifacial seja, muitas vezes, atribuído a uma compressão vascular do nervo facial ipsilateral, outras etiologias devem ser consideradas no diagnóstico diferencial, visto que esse espasmo pode ser confundido com outros distúrbios do movimento, como blefaroespasmo, miocimia facial, tiques, distonia oromandibular e espasmo hemimastigatório (3).  
O tratamento sintomático não invasivo mais eficaz do espasmo hemifacial consiste em injeções de TBA em intervalos de 3 a 4 meses, conforme a resposta clínica. Em casos graves e refratários, a cirurgia de descompressão vascular está indicada (4).  
A identificação desses distúrbios em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
2 CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)  
- G24.3 Torcicolo espasmódico  
- G24.4 Distonia orofacial idiopática  
- G24.5 Blefaroespasmo  
- G24.8 Outras distonias  
- G51.3 Espasmo hemifacial clônico  
- G51.8 Outros transtornos do nervo facial

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3 DIAGNÓSTICO -->
O diagnóstico sindrômico das distonias é baseado nos achados clínicos. Em algumas situações específicas, o diagnóstico depende da realização de um exame confirmatório. Esse é o caso das distonias laríngeas, quando a realização da videolaringoscopia é necessária para diagnóstico e aplicação de toxina botulínica. A investigação de um diagnóstico etiológico deve ser sempre perseguida, com o intuito de proporcionar um tratamento mais adequado aos pacientes com distonia. No entanto, a maior parte das distonias focais será de etiologia idiopática.  
As características clínicas que constituem os critérios diagnósticos para as distonias focais passíveis de tratamento com toxina botulínica são descritas a seguir. Nas formas segmentares, ocorre o acometimento de duas partes vizinhas: por exemplo, o pescoço e um braço; tronco e região cervical; um  
braço e ombro, ou ambos os braços; uma perna (ou ambas) e tronco. Portanto, as distonias segmentares são, na realidade, uma combinação de distonias focais adjacentes, e o tratamento com toxina botulínica também pode ser utilizado com eficácia e segurança.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Blefaroespasmo -->
O blefaroespasmo é a contração espasmódica involuntária e bilateral do músculo orbicular dos olhos que causa fechamento ocular forçado, intermitente ou sustentado. Contrações da musculatura frontal e de músculos médios e inferiores da face podem ocorrer concomitantemente, na chamada síndrome de Meige (5). Os primeiros sintomas costumam ser sensação de irritação ocular ou hipersensibilidade à luz, ocasionando aumento da frequência do piscamento. A intensidade vai aumentando gradualmente até se tornar uma contratura espasmódica, dificultando a abertura ocular. Em alguns casos, pode haver grande dificuldade de visão (cegueira funcional) devido aos espasmos, sendo necessária ajuda para a realização das atividades habituais (6, 7).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Distonia oromandibular -->
A distonia oromandibular caracteriza-se por contrações espasmódicas da musculatura mastigatória (músculos temporal e masseter), facial inferior (músculos orbicular da boca, do complexo submentoniano, pterigoideos lateral e medial), lingual, labial e, esporadicamente, cervical (platisma). Os espasmos causam dificuldade de abrir ou fechar a boca devido ao desvio lateral da mandíbula, trismo ou bruxismo e desvio lateral ou superior ou protrusão da língua (2, 8). Dessa forma, dificultam a mastigação, deglutição e articulação das palavras e causam limitação funcional e embaraço social para muitos pacientes (9).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3.2 DISTONIA LARÍNGEA OU DISFONIA ESPASMÓDICA -->
A distonia laríngea é uma forma de distonia focal que compromete os músculos da prega vocal, da laringe e da faringe envolvidos no processo de vocalização. Pode estar associada à distonia de outros músculos faciais. Existem duas formas de distonia laríngea: distonia adutora e abdutora.  
Na distonia adutora, ocorre adução exagerada e irregular da prega vocal, que determina um padrão de voz cansado, com timbre metálico, áspero, tenso-estrangulado, do tipo sufocado, com início e término abruptos (voz entrecortada), devido a quebras curtas na fonação. A fala tem redução da maciez e se torna menos compreensível, embora o canto seja usualmente menos afetado do que a fala propriamente dita, exceto nos casos graves.  
Na distonia abdutora (forma menos frequente), ocorre contração sustentada dos músculos cricoaritenoideos posteriores, com abdução exagerada da prega vocal. A voz fica reduzida em volume, assoprada ou sussurrada, e é produzida com esforço, resultando em segmentos afônicos e dificultando a compreensão (10, 11).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3.3 DISTONIA CERVICAL -->
Distonia cervical, previamente chamada de torcicolo espasmódico, é o tipo mais comum de distonia focal. Caracteriza-se por contração involuntária de músculos da região cervical de forma assimétrica, ocasionando alterações da postura cefálica, como desvio lateral, para frente, para trás, rotação ou ainda uma combinação desses movimentos. Além disso, é comum a variação na intensidade dos espasmos, que costumam piorar durante períodos de estresse e de cansaço e melhorar com o repouso ou quando em decúbito. A dor é uma manifestação comum das distonias cervicais, presente em cerca de dois terços dos pacientes (2, 12, 13).  
A distonia cervical pode ser classificada quanto ao tipo de movimento cervical em:  
- Tipo I: cabeça rotada para um lado, com elevação do ombro ipsilateral;  
- Tipo II: cabeça rotada para um lado;  
- Tipo III: cabeça inclinada para um lado, com elevação do ombro ipsilateral;  
- Tipo IV: cabeça inclinada para trás.  
No entanto, frequentemente ocorre combinação de movimentos em vários planos (50% dos indivíduos apresentam movimentos involuntários em dois planos, 35% em um plano, e 11% em três planos). A forma com inclinação anterior da cabeça do tipo _anterocolis_ puro, por exemplo, é uma condição rara, mas cerca de 1%-24% dos casos de distonias cervicais complexas apresentam esse componente. Aplicando-se o conceito _colis-caput_ , as distonias cervicais podem ser subdivididas em _anterocolis_ , _anterocaput_ e mudança sagital da cabeça para frente. O mesmo é válido para as formas de inclinação lateral ( _laterocolis_ , _laterocaput_ e desvio lateral) e formas de desvio posterior ( _retrocollis_ e _retrocaput_ ). O reconhecimento dessas diferentes formas de distonia cervical e a caracterização se o componente predominante é _colis_ ou _caput_ são fundamentais para a seleção correta dos músculos a serem injetados com toxina botulínica. Em caso de insucesso do tratamento inicial, os músculos injetados devem ser reavaliados e reconsiderados. Em alguns casos complexos, para identificação correta dos músculos distônicos é necessária a utilização de eletromiografia (EMG) ou tomografia computadorizada (14).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3.4 DISTONIA DE MEMBRO -->
Nesse tipo de distonia focal, ocorre o acometimento de um dos membros. Uma forma comum de distonia de membro é a distonia específica de uma tarefa (“tarefa-específica”), também conhecida como cãibra do escrivão, ocupacional ou de tarefa. Nela, ocorre uma excessiva contração muscular simultânea de músculos antagonistas do antebraço apenas durante um ato específico, em geral o de escrever. Normalmente, costuma permanecer restrita ao membro que está sendo utilizado, afetando mais frequentemente o grupo de músculos flexores do antebraço (15), mas o compartimento extensor também pode estar acometido. Pode ocorrer evolução do quadro, com as contrações musculares sendo desencadeadas pela realização de outros movimentos ou surgindo mesmo durante o repouso. É possível que esse distúrbio seja consequência da atividade repetitiva do membro em indivíduos geneticamente predispostos (16).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 3.5 ESPASMO HEMIFACIAL -->
O espasmo hemifacial é um dos distúrbios mais comuns dos movimentos craniofaciais e consiste em movimentos involuntários irregulares tônicos ou clônicos dos músculos de um só lado da face (orbicular dos olhos, frontal, risório, zigomático maior), além do platisma. O espasmo hemifacial caracteriza-se por espasmos musculares frequentemente associados à compressão do nervo facial por estruturas vasculares, na saída do tronco cerebral (17). Quando ocorre contração do orbicular dos olhos e fechamento do olho, parte da musculatura frontal usualmente se contrai. Esse sinal, descrito por Babinski, é tipicamente presente no espasmo hemifacial, mas não no blefaroespasmo. Embora quase sempre unilaterais, casos raros de espasmo hemifacial bilateral têm sido descritos (3).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 4 CRITÉRIOS DE INCLUSÃO -->
Serão incluídos os pacientes que apresentarem uma das formas abaixo, de acordo com os critérios diagnósticos descritos no item 4 deste Protocolo:  
Distonias focais:  
- Blefaroespasmo;  
- distonia oromandibular;  
- distonia laríngea;  
- distonia cervical;  
- distonia de membro;  
- distonias segmentares; ou  
- espasmo hemifacial.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 5 CRITÉRIOS DE EXCLUSÃO -->
Serão excluídos deste Protocolo os pacientes que apresentarem pelo menos uma das condições abaixo:  
- Gravidez;  
- amamentação;  
- hipersensibilidade à TBA ou a um de seus componentes;  
- doença neuromuscular associada (por exemplo, doenças do neurônio motor, miastenia grave);  
- uso concomitante de potencializador do bloqueio neuromuscular, como aminoglicosídeo;  
- presença provável de anticorpos contra a TBA, definida por perda de resposta terapêutica após um determinado número de aplicações em paciente com melhora inicial; ou  
- perda definitiva de amplitude articular por anquilose ou retração tendínea.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 6 TRATAMENTO -->
O tratamento das distonias e do espasmo hemifacial é feito com a TBA, que é uma neurotoxina produzida pela bactéria _Clostridium botulinum_ . Seu principal mecanismo de ação é o bloqueio da liberação de acetilcolina, que é o principal neurotransmissor da placa motora. A TBA promove a interrupção da transmissão neuronal com consequente bloqueio neuromuscular e, por esse motivo, é usada em condições que se caracterizam por atividade muscular exagerada, como é o caso das distonias. Após a aplicação local, a TBA difunde-se pelos músculos e outros tecidos. Seu efeito concentra-se próximo ao ponto de aplicação e diminui com o aumento da distância em relação a esse ponto. A difusão para músculos vizinhos é possível, especialmente quando volumes elevados são utilizados, podendo ocasionar efeitos adversos (18).  
O uso clínico da TBA teve início na década de 1980 e, desde então, vários estudos, incluindo ensaios clínicos randomizados e controlados e meta-análises, têm demonstrado sua eficácia e segurança no tratamento das distonias focais. Este Protocolo inclui as apresentações atualmente disponíveis no Sistema Único de Saúde (SUS) e que, individualmente, tiveram sua eficácia clínica demonstrada no tratamento das distonias focais. As apresentações comerciais de TBA têm formas de armazenamento e diluição e doses de administração diferentes. São produtos biológicos que apresentam o mesmo mecanismo de ação, mas diferem em seu comportamento farmacocinético. O médico deverá conhecer suas similaridades e diferenças, pois não há uma razão fixa de equipotência entre elas. Inexistem unidades-padrão internacionais, e as unidades de uma preparação não são intercambiáveis com as de outra, ou seja, as unidades de uma formulação de TBA são exclusivas para aquele produto. As formulações existentes devem ser tratadas como produtos biológicos quanto à equivalência de doses, e estas devem ser definidas conforme as características individuais de cada produto.  
As doses e os pontos de aplicação são diferentes entre as formulações de TBA-1 e TBA-2 (19). Até o momento, apesar da dificuldade de se estabelecer um consenso sobre a proporção mais adequada, a literatura internacional aceita uma proporção de 1:3 ou 1:4 entre a TBA-1 e a TBA-2 (20-23).  
A forma farmacêutica e o número de unidades/frasco das apresentações de TBA são reproduzidas no Quadro 1.  
Quadro 1 - Forma farmacêutica e apresentação da TBA  
||TBA-1|TBA-2|
|---|---|---|
|Forma farmacêutica|Pó seco a vácuo|Pó liofilizado injetável|
|Número de unidades/frasco|100 U|500 U|  
TBA: toxina botulínica tipo A.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Blefaroespasmo -->
Existem vários estudos que avaliaram a eficácia da TBA no tratamento do blefaroespasmo. Uma revisão que incluiu 55 estudos, com mais de 2.500 pacientes no total, concluiu ser a TBA altamente efetiva no tratamento dessa condição, com uma taxa de sucesso de aproximadamente 90% e duração média de efeito entre 2 e 3,5 meses (24). Uma meta-análise concluiu por um grau de recomendação B (dois estudos de nível II) para o tratamento do blefaroespasmo com TBA(20, 25).  
Usualmente, administra-se a TBA em três a cinco pontos do músculo _orbicularis oculi_ , bilateralmente (26). Deve-se evitar a porção central da pálpebra superior, para que não ocorra a indesejada difusão para o músculo elevador da pálpebra superior, com risco de ptose palpebral. Injeções centrais na pálpebra inferior também devem ser evitadas, sendo que, quanto mais próximo da borda palpebral for injetada a toxina, maior o risco de efeitos adversos oculares (21). As doses recomendadas para aplicação no músculo _orbicularis oculi_ encontram-se reproduzidas no Quadro 2 (18).  
Quadro 2 - Doses recomendadas de TBA para blefaroespasmo por aplicação  
||TBA-1(U)|TBA-2(U)|
|---|---|---|
|Doseporponto|2,5-5|20|
|Dose totalpor olho|10-30|40-140|  
TBA: toxina botulínicatipo A.  
Se a resposta clínica inicial for inadequada, a dose total pode ser aumentada em cerca de duas a quatro vezes, evitando-se doses maiores que 30 U no total por olho. Doses maiores que 5 U de TBA-1 por ponto de aplicação não trazem benefício adicional e não devem ser utilizadas (27, 28). Em pacientes com contração concomitante da região da sobrancelha ou dos demais músculos faciais (síndrome de Meige), pontos adicionais de injeção podem ser aplicados nos músculos corrugador, frontal, zigomático, risório ou platisma (29, 30), em doses semelhantes.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Espasmo hemifacial -->
Poucos ensaios clínicos randomizados e controlados avaliaram o uso de TBA em casos de espasmo facial. No entanto, há evidências de que o tratamento com TBA melhora cerca de 88% nesses casos (24). Trata-se de uma das condições clínicas mais frequentes em ambulatórios para atendimento de casos de distúrbios do movimento, que ocasiona desconforto e perda funcional da visão decorrente da contração da musculatura orbicular dos olhos. De acordo com o Subcomitê de Avaliação da Academia Americana de Neurologia, há uma recomendação de grau C para o tratamento do espasmo hemifacial com TBA (um estudo classe II e um estudo classe III) (25).  
As injeções podem ser administradas tanto por via subcutânea quanto intramuscular. A literatura não é conclusiva com relação aos locais de aplicação e às doses padrão empregadas, mas, usualmente, doses similares às utilizadas no blefaroespasmo são aplicadas no músculo _orbicularis oculi_ (29), e doses adicionais de 2,5-5 U são administradas nos demais músculos faciais, em geral ao nível do malar e da musculatura zigomática (31). A resposta terapêutica começa a ser observada cerca de 2 a 4 dias após as injeções e atinge um pico ao fim da primeira semana (32), e o efeito persiste por aproximadamente 16 semanas (30, 32, 33). A dose total utilizada é 17,5-50 U de TBA-1 ou 50-200 U de TBA-2.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Distonia oromandibular -->
O tratamento dessa condição com TBA requer um detalhado conhecimento da anatomia local. Nos casos em que há abertura da boca, os principais músculos envolvidos são aqueles do complexo submentoniano e pterigoideo lateral. Quando o espasmo é de fechamento da boca, os principais músculos são o masseter, o pterigoideo medial (ou interno) e o temporal.  
O tratamento com TBA, em estudos não controlados, promoveu melhora em até dois terços dos pacientes (34). As doses recomendadas para esse tratamento estão reproduzidas no Quadro 3 (27, 34).  
Quadro 3 - Doses recomendadas de TBA para distonia oromandibular por aplicação  
|MÚSCULOS/DOSES|TBA-1 (U)|TBA-2 (U)|
|---|---|---|
|TOTAIS|||
|Complexo submentoniano|12,5-50|40-200|
|Masseter|25-75|75-300|  
TBA: toxina botulínica tipo A.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Distonia laríngea ou disfonia espasmódica -->
Antes que um paciente seja considerado candidato a injeções de TBA, o diagnóstico de distonia laríngea deve ser confirmado por avaliação neurológica e otorrinolaringológica. Os achados clínicos devem ser documentados por videolaringoscopia, e a administração da TBA deve ser executada por ou com acompanhamento de otorrinolaringologista.  
Na disfonia espasmódica adutora (forma mais comum), o músculo tireoaritnoideo deve ser localizado, e injeções percutâneas de TBA devem ser realizadas através da membrana cricotireoideia, com uma dose recomendada de TBA-1 entre 4-10 U por aplicação, de acordo com a gravidade da distonia (35).  
Os benefícios verificados do tratamento com TBA envolvem melhora significativa da gravidade dos sintomas sob vários aspectos, conforme demonstrado por diversos estudos, incluindo meta-análises (36, 37) e estudos de coorte (38). A melhora nos parâmetros fisiológicos, acústicos e de autopercepção foi estatisticamente significativa, com variação de cada medida entre 74%-91%, embora nenhuma diferença tenha sido encontrada entre injeções uni ou bilaterais. A melhora da voz observada começa após 24-72 horas da aplicação e dura cerca de 4 meses (39). O tratamento da distonia laríngea com TBA possui recomendação de grau B (um estudo classe I) (25).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Distonia cervical -->
O tratamento da distonia cervical com TBA possui recomendação de grau A (estudos de nível I) (25). Ocasiona melhora significativa da posição anormal da cabeça e da dor, quando comparado com placebo (40, 41). Cerca de 80% dos pacientes apresentam melhora do desvio postural e 76%-93% têm melhora da dor. A melhora clínica tende a ser observada em torno de 7 dias após a aplicação, mas, em alguns casos, pode levar até 4-8 semanas para aparecer (42). O pico de resposta ocorre em 4 a 6 semanas, e a duração do efeito é de cerca de 3 meses (43, 44). A correta seleção dos músculos acometidos, de acordo com o tipo de distonia cervical, é o fator mais importante para a adequada resposta ao tratamento. As doses e os músculos são sumarizados no Quadro 4 (18):  
Quadro 4 - Doses recomendadas de TBA para distonia cervical por aplicação  
|TIPOS|MÚSCULOS|PONTOS DE|TBA-1|TBA-2|
|---|---|---|---|---|
|||APLICAÇÃO|(U)|(U)|
|Tipo I: cabeça|Esternocleidomastoid|Mínimo 2|50-100|150-400|  
|girando<br>ara o lado e|Elevador da escápula|1-2|50|200|
|---|---|---|---|---|
|p<br>elevação|Escaleno mínimo|2|25-50|75-200|
|do ombro ipsilateral,|Esplênio|1-3|25-75|75-300|
||Trapézio|1-8|25-100|75-400|
|Tipo II: cabeça<br>rotada para um lado,|Esternocleidomastoid<br>eo|Mínimo 2,<br>se dose maior que<br>25 U|25-100|75-400|
|Tipo III: cabeça<br>ilid|Esternocleidomastoid<br>|Mínimo 2|25-100|75-400|
|ncnaa para um<br>lado com elevação|~~eo~~<br>Elevador da escápula|Mínimo 2|25-100|75-400|
|do ombro ipsilateral,|Escaleno|Mínimo 2|25-75|75-300|
||Trapézio|1-8|25-100|75-400|
|Tipo IV: cabeça<br>|Esplênio bilateral|2-8|50-200|150-800|
|inclinada para trás,|Trapézio|1-8|25-100|75-400|  
TBA: toxina botulínica tipo A.  
Como mencionado previamente, nas distonias cervicais, frequentemente se encontra uma combinação de movimentos em vários planos. Essas formas são, inclusive, mais comuns que formas isoladas de distonias. É importante também identificar se o componente predominante é _colis_ ou _caput_ , e se desvios do plano sagital da cabeça também não estão associados (14, 45-48).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: Distonia de membro -->
Três ensaios clínicos demonstraram uma melhora significativa da postura ou da dor associada à distonia de membro em pelo menos uma das aplicações (49-51), determinando uma recomendação de grau B para o uso da TBA no tratamento dessa condição (um estudo de nível I e três estudos de nível III) (25). A resposta clínica se inicia, aproximadamente, 1 semana após a injeção, com efeito máximo em 2 semanas e duração em torno de 3 meses. No entanto, apesar do benefício inicial, somente um terço dos pacientes permanece em tratamento por mais de 2 anos (52). Pacientes do sexo feminino e aqueles com punho em flexão têm melhor prognóstico, enquanto os com tremor distônico associado apresentam pobre resposta (15). Inexistem estudos comparativos entre TBA-1 e TBA-2 para essa distonia. As doses recomendadas para o tratamento da distonia de membros estão descritas no Quadro 5 (18).  
<u>Quadro 5 - Doses recomendadas de TBA para distonia de membros por aplicação</u>  
|MÚSCULOS|TBA-1 (U)|TBA-2 (U)|
|---|---|---|
|Flexor profundo dos dedos|20-40|60-120|
|Flexor ulnar do carpo|||
|Flexor superficial dos dedos|25-50|75-150|
|Flexor radial do carpo|||
|Flexor longo do polegar|10-20|30-50|  
|Extensor longo do polegar|||
|---|---|---|
|Pronador redondo|20-30|60-100|
|Lumbricais/extensor do dedo índice|5-10|15-30|
|Extensor comum dos dedos|15-25|50-75|  
TBA: toxina botulínica tipo A.  
Com relação às aplicações em músculos de membros superiores e inferiores, assim como ocorre com as distonias segmentares, diferentes grupos musculares devem ser injetados. A dose total por sessão de tratamento deve seguir as recomendações das bulas dos medicamentos, dividida entre os músculos selecionados. A determinação das doses baseia-se nos seguintes fatores: intensidade da distonia do segmento atingido, comprometimento funcional, peso corporal, tamanho e número de músculos a serem tratados.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 6.1 FÁRMACO -->
- Toxina botulínica tipo A: frasco-ampola com 100U (TBA-1) e frasco-ampola com 500U (TBA-2).

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 6.2 ESQUEMA DE ADMINISTRAÇÃO -->
Com relação às técnicas de aplicação da TBA, são feitas as seguintes recomendações:  
- A aplicação deve ser realizada por médico capacitado;  
- utilizar sempre solução salina sem conservantes (soro fisiológico a 0,9%) para reconstituição;  
- evitar o borbulhamento ou a agitação do conteúdo do frasco durante a reconstituição e a aspiração  
- do medicamento para a seringa de injeção;  
- indicar e modificar as injeções (doses e pontos de aplicação) de acordo com o resultado  
- terapêutico obtido após cada aplicação;  
- aplicar as injeções em múltiplos pontos em cada músculo (pelo menos dois pontos, podendo ser  
- mais nos músculos grandes);  
- em adultos, recomenda-se uma dose máxima por aplicação de TBA-1= 360 U e de TBA-2= 1.000

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: U; -->
- em crianças, recomenda-se uma dose máxima, por sessão de aplicação, de 6 U/kg ou 300 U de  
- TBA-1. A TBA-2 não foi registrada para tratamento das distonias em menores de 2 anos;  
- administrar a TBA em todos os músculos desejados na mesma sessão de aplicação;  
- respeitar um intervalo mínimo de 3 meses entre as aplicações de TBA (para diminuir o risco de  
- formação de anticorpos contra a toxina), mesmo que sejam em músculos diferentes;  
- considerar, em decisão colegiada, o uso de EMG ou eletroestimulação para as aplicações de TBA em casos especiais, quando determinados músculos não podem ser adequadamente palpados ou quando o paciente é refratário ao tratamento, para otimizar a administração da toxina [segundo a literatura (53), as taxas de melhora são semelhantes entre as aplicações guiadas ou não por EMG, concluindo que seu uso não é necessário na maioria dos pacientes].

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 6.3 TEMPO DE TRATAMENTO– CRITÉRIOS DE INTERRUPÇÃO -->
A duração do tratamento não é pré-determinada, e o tratamento deve ser indicado se não houver nenhum dos critérios de exclusão e deve ser mantido enquanto o paciente apresentar resposta terapêutica. As aplicações devem ocorrer em intervalos de pelo menos 3 meses. Será considerada falha terapêutica o fato de os pacientes não obterem os benefícios esperados com o tratamento ou apresentarem efeitos adversos graves ou que interfiram em suas atividades habituais.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 6.4 BENEFÍCIOS ESPERADOS -->
Inexiste um tratamento que resulte na cura definitiva das distonias, sendo possível apenas promover um alívio sintomático. Os principais benefícios esperados do tratamento com TBA são:  
- Diminuição da frequência e da gravidade dos espasmos;  
- diminuição da dor ou do desconforto ocasionados pelos espasmos;  
- melhora da atividade funcional e da qualidade de vida dos pacientes.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 7.1 EFEITOS ADVERSOS -->
As injeções de TBA são geralmente bem toleradas, e não há diferenças significativas entre as apresentações comerciais de TBA com relação a seus efeitos adversos. Os mais comuns estão relacionados aos locais de injeção ou à fraqueza excessiva dos músculos injetados, a qual, em geral, é transitória, mas que pode ter variados graus de intensidade (28, 33). O uso repetido da TBA pode causar fraqueza e atrofia dos músculos estriados (28, 54).  
Efeitos adversos sistêmicos são raros e consistem de um quadro semelhante ao viral, que é transitório, mas que pode persistir por algumas semanas. Injeções intravasculares acidentais podem ocasionar fraqueza muscular generalizada (44). Abaixo estão relacionados alguns dos principais efeitos adversos da TBA:  
- Relacionados aos locais da injeção: sensação dolorosa e equimoses ou hematomas locais;  
- Relacionados aos músculos periorbitais: os mais comuns são lacrimejamento, fotofobia e irritação ocular. Pode ocorrer fraqueza muscular excessiva, que impossibilita o fechamento ou a abertura dos olhos. Cerca de 10% dos pacientes desenvolvem ptose palpebral, que melhora espontaneamente em menos de 2 semanas (33). Outras complicações incluem visão turva, equimoses locais, exotropia ou endotropia (estrabismo) e diplopia. Alguns pacientes relatam redução acentuada do piscamento, levando a olho seco e queratite;  
- Relacionados aos músculos cervicais: disfagia é o efeito adverso mais comum (55, 56). Parece haver relação entre o surgimento de disfagia e a difusão de TBA, seja pela aplicação de altas doses, seja pelos músculos injetados. Boca seca, paralisia da prega vocal e fraqueza da musculatura cervical também podem ocorrer. Acometimento respiratório é um efeito adverso grave que pode ocorrer com injeções na região cervical, em torno da boca e nas cordas vocais. Pneumotórax é uma complicação rara, potencialmente grave, que pode ocorrer por penetração pleural ao serem aplicadas injeções cervicais baixas ou na região dorsal.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 7.2 CONTRAINDICAÇÕES -->
Entre as contraindicações à TBA, incluem-se a hipersensibilidade a ela ou a um de seus componentes, o diagnóstico de miastenia grave ou doenças do neurônio motor. Deve-se evitar a utilização em mulheres grávidas ou que estejam amamentando, assim como em pacientes em uso de aminoglicosídeo e outros potencializadores do bloqueio neuromuscular. Não se deve administrar TBA a pacientes com infecção local na área a ser injetada. Cuidados especiais devem ser tomados nos pacientes com coagulopatia ou em uso de anticoagulantes. Tais medidas incluem maior compressão do local da injeção e, sempre que possível, correção de distúrbios da coagulação previamente às injeções.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 7.3 DESENVOLVIMENTO DE ANTICORPOS CONTRA TBA -->
Embora a maioria dos pacientes continue a responder às injeções de TBA, alguns se tornam menos  
responsivos ao longo do tempo, ou até mesmo refratários ao tratamento. Ainda que problemas técnicos, como local de aplicação ou dose insuficiente, possam justificar a perda do benefício de resposta, é frequente, entre os médicos aplicadores, atribuir-se o fracasso terapêutico ao desenvolvimento de anticorpos neutralizantes para a TBA. Inexistem dados que comparem a probabilidade de desenvolver anticorpos anti-TBA entre as diferentes preparações de TBA disponíveis. Um produto comercial cuja formulação é livre de complexos proteicos acessórios não levou à produção de anticorpos neutralizadores em estudos clínicos, mas não demonstrou maior eficácia ou redução de efeitos adversos em relação aos demais (57-59). Dessa forma, a melhor estratégia para evitar a formação de anticorpos neutralizantes da TBA ainda é buscar sempre a menor dose e o maior intervalo interdoses possível, independentemente da apresentação comercial que estiver em uso.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 8  ACOMPANHAMENTO PÓS-TRATAMENTO -->
Como o tempo de tratamento não pode ser pré-determinado e o intervalo de aplicação depende do tipo de distonia e da resposta do paciente, o acompanhamento pós-tratamento deve ocorrer a cada aplicação, podendo o paciente ter ou não a aplicação subsequente, conforme o item Monitorização.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 9  REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR -->
Recomenda-se que a confirmação do diagnóstico, o tratamento e o acompanhamento dos pacientes com distonias e espasmo hemifacial sejam feitos em serviços especializados e com profissionais capacitados para a aplicação de TBA, contando com especialista(s) em  neurologia, neurocirurgia ou fisiatria.  
O objetivo desses serviços é viabilizar uma estrutura de apoio no SUS para o atendimento dos pacientes com a aplicação da TBA e o acompanhamento da resposta terapêutica, promovendo, assim, o uso racional do medicamento e dos recursos humanos e materiais.  
A experiência com a criação de um serviço especializado em distonias e espasmo hemifacial e com a implantação dos protocolos clínicos do Ministério da Saúde para o tratamento com TBA levou, ao longo dos anos, a uma redução significativa nos gastos públicos com esse tratamento, além de permitir uma comunicação ativa e informativa entre a classe médica, contribuindo para o uso racional de medicamentos (60).  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 10 TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER -->
Deve-se cientificar o paciente, ou o seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado neste Protocolo, levando-se em consideração as informações contidas no TER.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: 11 REFERÊNCIAS BIBLIOGRÁFICAS -->
1.  Albanese A, Bhatia K, Bressman SB, Delong MR, Fahn S, Fung VS, et al. Phenomenology and classification of dystonia:a consensus update. Mov Disord. 2013;28(7):863-73.  
2. Balint B, Bhatia KP. Dystonia: an update on phenomenology, classification, pathogenesis andtreatment. Curr Opin Neurol. 2014;27(4):468-76.  
3. Yaltho TC, Jankovic J. The many faces of hemifacial spasm: differential diagnosis of unilateral facial spasms. Mov Disord. 2011;26(9):1582-92.  
4. Chaudhry N, Srivastava A, Joshi L. Hemifacial spasm: The past, present and future. J Neurol Sci. 2015;356(1-2):27-31.  
5. Maurri S, Brogelli S, Alfieri G, Barontini F. Use of botulinum toxin in Meige's disease. Riv Neurol. 1988;58(6):245-8.  
6. Grandas F, Elston J, Quinn N, Marsden CD. Blepharospasm: a review of 264 patients. J Neurol Neurosurg Psychiatry. 1988;51(6):767-72.  
7. Jankovic J, Ford J. Blepharospasm and orofacial-cervical dystonia: clinical and pharmacological findings in 100 patients. Ann Neurol. 1983;13(4):402-11.  
8. Tolosa E, Martí M. Adult-onset idiopathic torsion dystonias. In: Watts RL, Koller WC, editors. Movement disorders: neurologic principles and practice. New York: McGraw-Hill; 1997. p. 429-41.  
9. Yébenes J, Pernaute R, Tabernero C. Symptomatic Dystonias. In: Watts RL, Koller WC, editors. Movement disorders: neurologic principles and practice. New York: McGraw-Hill; 1997. p. 455-75.  
10. Blitzer A, Brin MF, Fahn S, Lovelace RE. Clinical and laboratory characteristics of focal laryngeal dystonia: study of 110 cases. Laryngoscope. 1988;98(6 Pt 1):636-40.  
11. Rosenfield DB. Spasmodic dysphonia. Adv Neurol. 1988;49:317-27.  
12. Chan J, Brin MF, Fahn S. Idiopathic cervical dystonia: clinical characteristics. Mov Disord. 1991;6(2):119-26.  
13. Jankovic J, Leder S, Warner D, Schwartz K. Cervical dystonia: clinical findings and associated movement disorders. Neurology. 1991;41(7):1088-91.  
14. Finsterer J, Maeztu C, Revuelta GJ, Reichel G, Truong D. Collum-caput (COL-CAP) concept for conceptual anterocollis, anterocaput, and forward sagittal shift. J Neurol Sci. 2015;355(1-2):37-43  
15. Das CP, Dressler D, Hallett M. Botulinum toxin therapy of writer's cramp. Eur J Neurol. 2006;13 Suppl 1:55-9.  
16. Hallett M. The neurophysiology of dystonia. Arch Neurol. 1998;55(5):601-3.  
17. Wang A, Jankovic J. Hemifacial spasm: clinical findings and treatment. Muscle Nerve. 1998;21(12):1740-7.  
18. Moore P, Naumann M. Handbook of botulinum toxin treatment. 2nd ed. Oxford: Blackwell Publishing; 2003. p. 463.  
19. Marchetti A, Magar R, Findley L, Larsen JP, Pirtosek Z, Ruzicka E, et al. Retrospective evaluation of the dose of Dysport and BOTOX in the management of cervical dystonia and blepharospasm: the REAL DOSE study. Mov Disord. 2005;20(8):937-44.  
20. Nussgens Z, Roggenkämper P. Comparison of two botulinum-toxin preparations in the treatment of essential blepharospasm. Graefes Arch Clin Exp Ophthalmol. 1997;235(4):197-9.  
21. Sampaio C, Ferreira J, Simões F, Rosas M, Magalhães M, Correia Aea. DYSBOT: a single-blind, randomized parallel study to determine whether any differences can be detected in the efficacy and tolerability of two formulations of botulinum toxin type A--Dysport and Botox--assuming a ratio of 4:1. Mov Disord. 1997;12(6):1013-8.  
22. Odergren T, Hjaltason H, Kaakkola S, Solders G, Hanko J, Fehling C, et al. A double blind, randomised, parallel group study to investigate the dose equivalence of Dysport and Botox in the treatment of cervical dystonia. J Neurol Neurosurg Psychiatry. 1998;64(1):6-12.  
23. Ranoux D, Gury C, Fondarai J, Mas J, Zuber M. Respective potencies of Botox and Dysport: a double blind, randomised, crossover study in cervical dystonia. J Neurol Neurosurg Psychiatry. 2002;72(4):459-62.  
24. Jost WH, Kohl A. Botulinum toxin: evidence-based medicine criteria in blepharospasm and hemifacial spasm. J Neurol. 2001;248 Suppl 1:21-4.  
25. Simpson D, Blitzer A, Brashear A, Comella C, Dubinsky R, Hallett M, et al. Assessment: Botulinum neurotoxin for the treatment of movement disorders (an evidence-based review): report of the  
Therapeutics and Technology Assessment Subcommittee of the American Academy of Neurology. Neurology. 2008;70(19):1699-706.  
26. Bhidayasiri R, Cardoso F, Truong DD. Botulinum toxin in blepharospasm and oromandibular dystonia: comparing different botulinum toxin preparations. Eur J Neurol. 2006;13 Suppl 1:21-9. 27. Jankovic J. Blepharospasm and oromandibular-laryngeal-cervical dystonia: a controlled trial of botulinum A toxin therapy. Adv Neurol. 1988;50:583-91.  
28. Patrinely JR, Whiting AS, Anderson RL. Local side effects of botulinum toxin injections. Adv Neurol. 1988;49:493-500.  
29. Brin MF, Fahn S, Moskowitz C, Friedman A, Shale HM, Greene PE, et al. Localized injections of botulinum toxin for the treatment of focal dystonia and hemifacial spasm. Mov Disord. 1987;2(4):237-54. 30. Kraft SP, Lang AE. Botulinum toxin injections in the treatment of blepharospasm, hemifacial spasm, and eyelid fasciculations. Can J Neurol Sci. 1988;15(3):276-80.  
31. Tolosa E, Marti MJ, Kulisevsky J. Botulinum toxin injection therapy for hemifacial spasm. Adv Neurol. 1988;49:479-91.  
32. Mauriello JA Jr, Coniaris H, Haupt EJ. Use of botulinum toxin in the treatment of one hundred patients with facial dyskinesias. Ophthalmology. 1987;94(8):976-9.  
33. Dutton JJ, Buckley EG. Long-term results and complications of botulinum A toxin in the treatment of blepharospasm. Ophthalmology. 1988;95(11):1529-34.  
34. Tan EK, Jankovic J. Botulinum toxin A in patients with oromandibular dystonia: long-term followup. Neurology. 1999;53(9):2102-717.  
35. Teive HA, Scola RH, Werneck LC, Quadros Ad, Gasparetto EL, Sá DS, et al. [Use of botulinum toxin in the treatment of laryngeal dystonia (spasmodic dysphonia): preliminary study of twelve patients]. Arq Neuropsiquiatr. 2001;59(1):97-100.  
36. Boutsen F, Cannito MP, Taylor M, Bender B. Botox treatment in adductor spasmodic dysphonia: a meta-analysis. J Speech Lang Hear Res. 2002;45(3):469-81.  
37. Whurr R, Nye C, Lorch M. Meta-analysis of botulinum toxin treatment of spasmodic dysphonia: a review of 22 studies. Int J Lang Commun Disord. 1998;33 Suppl:327-9.  
32. Damrose JF, Goldman SN, Groessl EJ, Orloff LA. The impact of long-term botulinum toxin injections on symptom severity in patients with spasmodic dysphonia. J Voice. 2004;18(3):415-22.  
39. Blitzer A, Brin MF, Stewart CF. Botulinum toxin management of spasmodic dysphonia (laryngeal dystonia): a 12-year experience in more than 900 patients. Laryngoscope. 1998;108(10):1435-41. 40. Costa J, Espirito-Santo C, Borges A, Ferreira JJ, Coelho M, Moore P, et al. Botulinum toxin type A therapy for cervical dystonia. Cochrane Database Syst Rev. 2005(1):CD003633.  
41. Greene P, Kang U, Fahn S, Brin M, Moskowitz C, Flaster E. Double-blind, placebo-controlled trial of botulinum toxin injections for the treatment of spasmodic torticollis. Neurology. 1990;40(8):1213-8. 42. Jankovic J, Schwartz K, Donovan DT. Botulinum toxin treatment of cranial-cervical dystonia, spasmodic dysphonia, other focal dystonias and hemifacial spasm. J Neurol Neurosurg Psychiatry. 1990;53(8):633-9.  
43. Jankovic J, Schwartz K. Botulinum toxin injections for cervical dystonia. Neurology 1990; 40(2):277-80.  
44. Anderson TJ, Rivest J, Stell R, Steiger MJ, Cohen H, Thompson PD, et al. Botulinum toxin treatment of spasmodic torticollis. J R Soc Med. 1992;85(9):524-9.  
45. Ferreira JJ, Colosimo C, Bhidayasiri R, Marti MJ, Maisonobe P, Om S. Factors influencing secondary non-response to botulinum toxin type A injections in cervical dystonia.Parkinsonism Relat Disord. 2015;21(2):111-5.  
46. Finsterer J, Revuelta GJ. Anterocollis and anterocaput. Clin Neurol Neurosurg. 2014;127:44-53.  
47. Mordin M, Masaquel C, Abbott C, Copley-Merriman C. Factors affecting the health-related quality of life of patients with cervical dystonia and impact of treatment with abobotulinumtoxinA (Dysport): results from a randomised, double-blind, placebo-controlled study. BMJ Open. 2014 16;4(10):e005150.  
48. Rodrigues FB, Duarte G, Marques R, Castelão M, Ferreira JJ, Moore P,et al. Botulinum toxins type A and B for cervical dystonia, blepharospasm and hemifacial spasm-an update of cochrane movement disorders group systematic reviews. Mov Disord. 2015; 30 Suppl 1: S203-4.  
49. Tsui JK, Bhatt M, Calne S, Calne DB. Botulinum toxin in the treatment of writer's cramp: a doubleblind study. Neurology. 1993;43(1):183-5.  
50. Yoshimura DM, Aminoff MJ, Olney RK. Botulinum toxin therapy for limb dystonias. Neurology. 1992;42(3 Pt 1):627-30.  
51. Cole R, Hallett M, Cohen LG. Double-blind trial of botulinum toxin for treatment of focal hand dystonia. Mov Disord. 1995;10(4):466-71.  
52. Karp BI, Cole RA, Cohen LG, Grill S, Lou JS, Hallett M. Long-term botulinum toxin treatment of focal hand dystonia. Neurology. 1994;44(1):70-6.  
53. Comella CL, Buchman AS, Tanner CM, Brown-Toms NC, Goetz CG. Botulinum toxin injection for spasmodic torticollis: increased magnitude of benefit with electromyographic assistance. Neurology. 1992;42(4):878-82.  
54. Stell R, Thompson PD, Marsden CD. Botulinum toxin in spasmodic torticollis. J Neurol Neurosurg Psychiatry. 1988;51(7):920-3.  
55. Moore AP, Blumhardt LD. A double blind trial of botulinum toxin "A" in torticollis, with one year follow up. J Neurol Neurosurg Psychiatry. 1991;54(9):813-6.  
56. Evidente VG, Fernandez HH, LeDoux MS, Brashear A, Grafe S, Hanschmann A, et al. A randomized, double-blind study of repeated incobotulinumtoxinA (Xeomin(®)) in cervical dystonia. J Neural Transm (Vienna). 2013;120(12):1699-707.  
57. Truong DD, Gollomp SM, Jankovic J, LeWitt PA, Marx M, Hanschmann A, et al. Sustained efficacy and safety of repeated incobotulinumtoxinA (Xeomin(®)) injections in blepharospasm. J Neural Transm (Vienna). 2013;120(9):1345-53.  
58. Comella CL, Jankovic J, Truong DD, Hanschmann A, Grafe S; U.S. XEOMIN Cervical Dystonia Study Group. Efficacy and safety of incobotulinumtoxinA (NT 201, XEOMIN®, botulinum neurotoxin type A, without accessory proteins) in patients with cervical dystonia. J Neurol Sci. 2011;308(1-2):103-9. 59. Comella C. Treatment of dystonia [Internet]. UpToDate; 2014. [cited 2016 Jan 6]. Available from: http://www.uptodate.com/contents/treatment-of-dystonia.  
60. Picon P, Guarany F, Socal M, Leal M, Laporte E, Schestatsky P, et al. Implementation of Brazilian Guidelines for Botulinum Toxin: a three-year follow-up of a cost-reduction strategy in the public health system of Rio Grande do Sul. Oral presentation, 4th HTAI (Health Technology Assessment International) Annual Meeting; 2007 Jun 17-20; Barcelona, Spain.

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: TERMO DE ESCLARECIMENTO E RESPONSABILIDADE TOXINA BOTULÍNICA TIPO A -->
Eu, ________________________________________________ (nome do(a) paciente), declaro ter sido informado(a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso do medicamento toxina botulínica tipo A, indicado para o tratamento da distonia e espasmo hemifacial.  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo médico _____________________________________ (nome do médico que prescreve).  
Assim, declaro que:  
Fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes melhorias:  
- diminuição da frequência e intensidade dos espasmos (contração involuntária do músculo);  
- diminuição da dor ou do desconforto ocasionados pelas contrações;  
- melhora da atividade funcional e da qualidade de vida.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez; portanto, caso engravide, devo avisar imediatamente ao meu médico;  
- o principal efeito desagradável é dor no local de aplicação da injeção;  
- os efeitos adversos variam de acordo com o local de aplicação. Os mais relatados nas distonias são tontura, fraqueza geral, cansaço, sonolência, mal-estar geral, dificuldade para engolir, náusea, boca seca, dor de cabeça e irritabilidade; no blefaroespasmo (espasmo de pálpebra) e no espasmo hemifacial, são irritação nos olhos, lacrimejamento, relaxamento e inchaço da pálpebra, visão turva e tonturas.  
Conforme a marca comercial utilizada, a dose da toxina botulínica pode ser ajustada, e devo procurar orientação do médico ou farmacêutico em caso de dúvida.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido(a), inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (    ) Sim   (    ) Não  
|Local:                                                                Data:||
|---|---|
|Nome dopaciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||
|Documento de identificação do responsável legal:||
|_____________________________________<br>Assinatura dopaciente ou do responsável legal||
|Médico responsável:<br>CRM:|UF:|
|___________________________<br>Assinatura e carimbo do médico||
|Data:____________________||

---

<!-- METADADOS: doenca: Distonias e Espasmo Hemifacial (PCDT) | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
A revisão da literatura obedeceu a uma estratégia de busca realizada na PubMed/MEDLINE em 01/10/2009. As palavras-chave (em inglês) utilizadas na busca foram: “dystonia, torticollis, cervical dystonia, blepharospasm, hemifacial spasm, writer`s cramp, Meige syndrome, essential tremor, laryngeal dystonia, spasmodic dysphonia, e orofacial dystonia”. As buscas foram realizadas combinando cada uma das palavras-chave com o termo _botulinum toxin_ , restringindo-se a pesquisa a ensaios clínicos randomizados, revisões sistemáticas e meta-análises, sem limite de tempo.  
Dos 90 artigos identificados, foram excluídos os estudos metodologicamente inadequados ou com tamanho amostral muito reduzido, sendo selecionadas cinco revisões sistemáticas/meta-análises e 18 ensaios clínicos.  
Para a atualização deste PCDT em 06/01/2016, foi realizada nova busca da literatura.  
Na base MEDLINE/PubMed,foi utilizada a estratégia: “"Dystonia"[Mesh]) OR "Meige Syndrome"[Mesh]) OR "Torticollis"[Mesh]) OR "Cervical Dystonia, Primary" [Supplementary Concept]) OR "Blepharospasm"[Mesh]) OR "Hemifacial Spasm"[Mesh]) OR "Dystonic Disorders"[Mesh]) OR "Essential Tremor"[Mesh]) OR "laryngeal dystonia" OR "spasmodic dysphonia" OR "orofacial dystonia" AND "Therapeutics"[Mesh] Filters: Clinical Trial, Randomized Controlled Trial, Systematic Reviews, Guideline, Meta-Analysis, From 2009/10/02, Humans, English, Portuguese, Spanish”.Foram localizadas 206 referências; dessas, 16 foram selecionadas para leitura na íntegra.  
Na base EMBASE, foi utilizada a estratégia: “'dystonia'/exp OR 'torticollis'/exp OR 'cervical dystonia'/exp OR 'blepharospasm'/exp OR 'hemifacial spasm'/exp OR 'writer`s cramp'/exp OR 'meige syndrome'/exp OR 'essential tremor'/exp OR 'spasmodic dysphonia'/exp AND 'therapy'/exp AND ([cochrane review]/lim OR [systematic review]/lim OR [controlled clinical trial]/lim OR [randomized controlled trial]/lim OR [meta analysis]/lim) AND ([english]/lim OR [portuguese]/lim OR [spanish]/lim) AND [humans]/lim AND [embase]/lim AND [2-10-2009]/sd NOT [10-10-2014]/sd”.Foram localizados 388 estudos; desses, foram selecionados 13 para leitura na íntegra.  
Na biblioteca Cochrane, foi utilizada a estratégia: “dystonia OR torticollis OR cervical dystonia OR blepharospasm OR hemifacial spasm OR writer`s cramp OR Meige syndrome OR essential tremor OR laryngeal dystonia OR spasmodic dysphonia OR orofacial dystonia in Title, Abstract, Keywords, Publication Year from 2009 to 2016 in Cochrane Reviews'”.Foram localizadas 31 revisões sistemáticas da Cochrane; nenhuma foi selecionada.  
Foi ainda consultado o capítulo atualizado sobre o tema da publicação eletrônica UpToDate, versão 19.3.  
Foram excluídos estudos com desfechos não clínicos, bem como estudos avaliando condutas cirúrgicas ou intervenções indisponíveis ou não aprovadas no Brasil.  
A revisão da literatura resultou na exclusão de quatro artigos e inclusão de 13 referências bibliográficas relevantes para o presente Protocolo.

---

