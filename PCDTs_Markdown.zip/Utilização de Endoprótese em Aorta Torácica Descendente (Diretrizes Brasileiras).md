<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS  
PORTARIA CONJUNTA Nº 03, DE 7 DE JANEIRO DE 2019.  
Aprova as Diretrizes Brasileiras para Utilização de Endoprótese em Aorta Torácica Descendente.  
O SECRETÁRIO DE ATENÇÃO À SAÚDE e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS - Substituta, no uso de suas atribuições,  
Considerando a necessidade de se estabelecerem parâmetros sobre o tratamento de aneurisma da aorta torácica descendente e diretrizes nacionais para a sua indicação e acompanhamento dos indivíduos a ele submetidos;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 398/2018 e o Relatório de Recomendação n<sup><u>o</u></sup> 410 – Dezembro de 2018, da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a busca e avaliação da literatura; e  
Considerando a avaliação técnica do Instituto Nacional de Cardiologia (INC/SAS/MS), do Departamento de Gestão e Incorporação de Tecnologias no SUS (DGITS/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAS/MS), resolvem:  
Art. 1º  Ficam aprovadas, na forma do Anexo, as “Diretrizes Brasileiras para Utilização de Endoprótese em Aorta Torácica Descendente”.  
Parágrafo único. As diretrizes objeto deste artigo, que contêm as recomendações para o tratamento de aneurisma da aorta torácica descendente, disponíveis no sítio <u>http://portalms.saude.gov.br/protocolos-e-diretrizes, são de caráter nacional e devem</u> utilizadas pelas Secretarias de Saúde dos Estados, Distrito Federal e Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao  tratamento de aneurisma da aorta torácica descendente.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos doentes em todas as etapas descritas no Anexo desta Portaria.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
FRANCISCO DE ASSIS FIGUEIREDO VANIA CRISTINA CANUTO SANTOS  
ANEXO

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **RESUMO DAS RECOMENDAÇÕES** -->
Este documento apresenta as recomendações do Ministério da Saúde para a utilização das endopróteses aórticas no tratamento dos aneurismas da aorta torácica descendente (tipo B de Stanford e tipo III de DeBakey) e nas dissecções da aorta torácica.  
O público-alvo destas Diretrizes é composto pelos profissionais da saúde do SUS envolvidos no tratamento do aneurisma e da dissecção de aorta torácica (código I71.2 da CID-10) e profissionais do Ministério da Saúde envolvidos na incorporação, utilização e regulação de tecnologias em saúde.  
São excluídas as síndromes genéticas ou cardiopatias congênitas e aneurismas da aorta ascendente e do arco torácico.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Recomendações** -->
**1** - Em pacientes com aneurisma da aorta torácica descendente com indicação de cirurgia, dar preferência à realização de cirurgia endovascular, em função da sua maior eficácia e segurança quando comparada à cirurgia aberta.  
**2** - Em pacientes com dissecção de aorta do tipo B não complicada, dar preferência à realização do tratamento clínico em detrimento da cirurgia endovascular.  
**3** – Em pacientes com dissecção da aorta torácica descendente do tipo B complicada, dar preferência à realização de cirurgia endovascular, considerando o caráter invasivo da cirurgia aberta.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Fluxograma de tratamento** -->
Os algoritmos para as indicações terapêuticas do aneurisma da aorta torácica descendente e da dissecção de aorta tipo B encontram-se a seguir.  
<!-- Start of picture text -->
Aneurisma de aorta torácica descendente<br>Indicação cirúrgica?<br>(considerar sintoma, tamanho ou<br>crescimento)<br>Sim Não<br>Tratamento clínico e seguimento<br>Anatomicamente viável para<br>cirurgia endovascular?<br>Sim Não<br>Cirurgia endovascular Cirurgia aberta<br>z radiológico<br><!-- End of picture text -->  
<!-- Start of picture text -->
Dissecção  de aorta tipo B<br>Complicada?<br>Sim Não<br>Anatomicamente viável para cirurgia<br>Tratamento clínico e seguimento<br>endovascular?<br>Sim Não<br>Cirurgia<br>Cirurgia aberta<br>endovascular<br>= radiológico<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **INTRODUÇÃO** -->
Este documento apresenta as recomendações do Ministério da Saúde para a cirurgia endovascular no tratamento dos aneurismas da aorta torácica descendente (AATD) e das dissecções da aorta torácica. O público-alvo destas diretrizes é composto pelos profissionais da saúde do SUS envolvidos no tratamento do aneurisma e da dissecção da aorta torácica (código I71.2 da CID-10) e profissionais do Ministério da Saúde envolvidos na incorporação, utilização e regulação de tecnologias em saúde.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Aneurismas** -->
Aneurismas são dilatações segmentares da parede arterial que superam em mais de 50% o seu diâmetro máximo normal. Os aneurismas da aorta torácica (AAT) apresentam uma incidência em torno de 10/100 mil indivíduos/ano, a maioria (95%) assintomáticos e e de etiologia principalmente degenerativa<sup>(1)</sup> .  
A aorta é anatomicamente subdividida em torácica e abdominal. A aorta torácica é composta de três partes: porção ascendente, arco e porção descendente. A porção ascendente é limitada do ânulo aórtico ao tronco braquiocefálico. O arco aórtico representa a porção aórtica entre o tronco braquiocefálico e a subclávia esquerda.  A porção descendente inicia-se após a subclávia esquerda e termina ao nível do diafragma, onde passa a ser considerada aorta abdominal. A maioria dos aneurismas da aorta torácica (60%) está limitada à porção ascendente, 10% ao arco e 30% à porção descendente<sup>(1)</sup> .  
O conhecimento anatômico é relevante, pois as abordagens terapêuticas dos aneurismas variam de acordo com o segmento acometido. Aneurismas de aorta ascendente e arco são reparados em sua grande maioria por meio da cirurgia aberta e, portanto, fogem ao escopo destas Diretrizes. O aneurisma da aorta torácica descendente (AATD) pode ser reparado por cirurgia, procedimento endovascular ou uma combinação destes métodos (reparo híbrido).  
O tratamento tem como objetivo principal evitar a ruptura arterial, evento com alta letalidade. O tratamento inclui também, mudanças no estilo de vida e medicamentos, além da cirurgia aberta ou cirurgia endovascular. Em geral, o reparo do aneurisma é recomendado na presença de risco de ruptura ou complicações que excedam os riscos associados à própria reparação.  
Embora a maioria dos AATD não produzam sintomas, os pacientes que se tornam sintomáticos ou apresentam complicações relacionadas ao aneurisma (por exemplo, regurgitação aórtica aguda, dissecção e ruptura aórtica) devem ser submetidos à reparação. O estudo de Joyce et al. reforça esta necessidade, apontando sobrevida em 5 anos de 27% no grupo sintomático _versus_ 58% no grupo assintomático, com um terço das mortes por ruptura da aorta<sup>(2)</sup> .  
Em pacientes assintomáticos, a indicação de cirurgia depende do diâmetro, localização e taxa de expansão do aneurisma. O diâmetro é considerado o principal fator de risco para o desenvolvimento de dissecção ou ruptura da aorta. Notadamente, os riscos de complicações aumentam a partir de 6,0 cm, quando a taxa de ruptura supera 10% ao ano.  
Inexistem ensaios clínicos que tenham randomizado os pacientes de acordo com o tamanho do aneurisma ou taxa de expansão, limitando a utilização destes dados apenas como parâmetros para indicação de intervenção<sup>(3)</sup> . Entretanto, devido ao risco de ruptura observado em estudos do tipo séries de casos, há consenso em relação à indicação de cirurgia para aneurismas grandes (em torno de 6 cm de diâmetro). Por exemplo, um diâmetro do aneurisma superior a 2,75 cm/m² está associado a uma taxa anual de dissecção, ruptura e taxa da mortalidade de 8,0%. _[A área de superfície corporal pode ser calculada de acordo com a fórmula de DuBois & Dubois: (0,20247 x altura em metros_<sup>_0,725_</sup> _) x (peso em kilos_<sup>_0,425_</sup> _)]_<sup>_(4)_</sup> .  
Em relação à taxa de expansão do aneurisma, existe uma grande variabilidade entre os pacientes: alguns mantêm o diâmetro inicial, enquanto outros apresentam taxas de crescimento elevadas, superiores a 2,0 cm ao ano. Em média, os aneurismas torácicos apresentam uma taxa de expansão de 1,3±1,2 mm ao ano, podendo ser maior em aneurismas de maior tamanho.  
O acompanhamento de pacientes com AATD deve ser realizado com tomografia computadorizada a cada seis meses, para avaliar o tamanho do aneurisma e a taxa de expansão<sup>(5)</sup> . A maioria dos autores recomenda a intervenção para aneurismas maiores do que 5,0 ou 5,5 cm e com taxa de expansão maior ou igual a 0,5 a 1,0 centímetro ao ano<sup>(6,</sup> 7). Toda intervenção deve levar em consideração os riscos individuais de ruptura e aqueles inerentes ao próprio procedimento, assim como considerar as preferências individuais dos pacientes.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Cirurgia Endovascular** **_versus_ Cirurgia Aberta** -->
A técnica utilizada para correção do aneurisma na cirurgia aberta varia dependendo da localização e extensão do aneurisma. O reparo aberto do AATD é feito por meio de toracotomia e, muitas vezes, não requer circulação extracorpórea completa ou cardioplegia; no entanto, medidas devem ser adotadas para proteger a medula espinhal. Revascularização de órgãos-alvo (visceral, renal) pode requerer reimplante arterial nativo com ou sem endarterectomia ou enxertia<sup>(8)</sup> .  
O reparo endovascular do aneurisma da aorta torácica envolve o acesso através da punção das artérias ilíaca ou femoral e o implante de próteses na aorta excluindo o saco aneurismático da circulação e requer o cumprimento de critérios anatômicos específicos. Embora o reparo endovascular esteja associado a menor mortalidade perioperatória, foram relatadas complicações tardias, incluindo migração do enxerto e ruptura da aorta. Estas complicações estão associadas à necessidade de novos procedimentos (cirurgia ou novo implante de outra endoprótese) para controlar a expansão do aneurisma ou reverter as complicações vasculares decorrentes da obstrução de algum ramo arterial distal<sup>(9)</sup> .  
De acordo com o DATASUS, a cirurgia endovascular é cerca de duas vezes mais comum no Brasil, apresentando menor mortalidade intra-hospitalar e menor tempo de internação (Tabela 1).  
**TABELA 1 -** DADOS COMPARATIVOS ENTRE A CIRURGIA ENDOVASCULAR E A CIRURGIA ABERTA NOS ANOS DE 2015 E 2016, SEGUNDO DADOS DO DATASUS.  
|**Desfecho**||**Endovascular**|**Cirurgia**<br>**aberta**|
|---|---|---|---|
|Número|d|511 - 512|253 - 259|
|procedimen|tos ao ano|||
|Taxa<br>de|mortalidad|7,0% - 8,4%|25,7% -|
|operatória|||30,9%|
|Média de<br>em dias|permanênc|8,8 – 9,9|12,2 – 12,3|  
Fonte: DATASUS, acesso em 09/01/2018.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Dissecção** -->
A parede da aorta possui basicamente três camadas. A camada interna ou “íntima” está em contato com o sangue; a camada intermediária, chamada de “média”, contém células musculares e fibras elásticas, que permitem que a aorta se contraia e expanda durante o ciclo cardíaco; e a camada externa, chamada de “adventícia”, consiste de tecido conectivo que dá suporte estrutural adicional à aorta<sup>(10)</sup> .  
A dissecção de aorta é uma condição potencialmente fatal, que ocorre quando a camada interna ou íntima da parede arterial sofre dano, permitindo que o sangue penetre, separando-a (dissecando) da camada média. A doença é multifatorial, tendo como possíveis causas síndromes genéticas (destaque para as de Marfan e Ehlers-Danlos), hipertensão arterial sistêmica crônica ou causas iatrogênicas como a lesão vascular durante o cateterismo arterial. A partir do local de rotura da camada íntima, a dissecção pode ter progressão proximal ou distal. Desta forma, ramos arteriais como coronárias, carótidas, renais, mesentérica e ilíacas podem ser comprimidos ou ocluídos pela dissecção causando isquemia<sup>(10)</sup> .  
Os sistemas Stanford ( _Daily_ ) e DeBakey são usados para classificar a dissecção aórtica. O sistema de Stanford é o mais comum e classifica as dissecções na aorta ascendente e arco como tipo A, independentemente do local da lesão na íntima ( _flap_ ) e as outras dissecções são classificadas como tipo B. O sistema DeBakey baseia-se no local de origem da lesão: o tipo I se origina na aorta ascendente e se propaga ao menos no arco aórtico; o tipo II é originário e confinado à aorta ascendente; e o tipo III se inicia na aorta descendente e pode se estender distal ou proximalmente<sup>(10)</sup> .

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
I71.2 - Aneurisma da aorta torácica, sem menção de ruptura.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **OBJETIVO** -->
Definir as diretrizes nacionais para a utilização das endopróteses aórticas em posição torácica descendente, promovendo a saúde, evitando danos aos pacientes e otimizando os recursos materiais e humanos no âmbito do Sistema Único de Saúde (SUS).  
Recomendações referentes ao cuidado clínico (tratamento medicamentoso, atividade física ou controle do tabagismo) e avaliações econômicas não fazem parte do escopo.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **CRITRÉRIOS DE INCLUSÃO** -->
- Aneurisma na porção descendente da aorta torácica;  
- Dissecção da aorta torácica descendente (tipo B de Stanford e tipo III de DeBakey).

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **CRITRÉRIOS DE EXCLUSÃO** -->
- Síndromes genéticas ou cardiopatias congênitas;  
- Aneurismas da aorta ascendente e arco torácico.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **MÉTODO** -->
A elaboração deste documento teve como base para sua estruturação as “Diretrizes metodológicas para elaboração de diretrizes clínicas”, do Ministério da Saúde<sup>(11)</sup> .  
A qualidade metodológica das revisões sistemáticas selecionadas foi avaliada pela ferramenta AMSTAR II<sup>(12)</sup> . As recomendações destas Diretrizes seguiram o formato do sistema _Grading of Recommendations Assessment, Development and Evaluation_ (GRADE)<sup>(13)</sup> ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **RESULTADOS** -->
**Cirurgia endovascular** **_versus_ cirurgia aberta em pacientes com aneurisma da aorta torácica descendente e indicação de tratamento cirúrgico**  
A partir da busca de evidência científica, foram identificadas cinco revisões sistemáticas<sup>(14-18)</sup> com qualidade metodológica variando de muito baixa a moderada. Os resultados destas revisões sugerem, a favor da cirurgia endovascular, menor risco de eventos, como mortalidade intra-hospitalar, paraplegia, paresia e tempo de internação.  
Neste sentido, em pacientes com este perfil, deve-se dar preferência a realização de cirurgia endovascular ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Cirurgia endovascular** **_versus_ tratamento clínico em pacientes com dissecção de aorta do tipo B não complicada** -->
Para a dissecção aórtica do tipo B não complicada, identificaram-se duas revisões sistemáticas<sup>(19, 20)</sup> e um ensaio clínico randomizado<sup>(21)</sup> . A revisão de Ulug _et al._ teve como objetivo identificar ensaios clínicos randomizados, selecionando apenas um estudo, o ensaio chamado INSTEAD. De acordo com o AMSTAR 2, a revisão apresentou qualidade moderada.  
Neste estudo, foram considerados apenas os dados publicados após dois anos de seguimento, no qual a opção pela cirurgia endovascular associou-se a um aumento não estatisticamente significativo na mortalidade e complicações neurológicas ( **Apêndice 1** ).  
Assim, deve-se dar preferência à manutenção do tratamento clínico em pacientes com dissecção crônica tipo B não complicada.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Cirurgia endovascular** **_versus_ cirurgia aberta em pacientes com dissecção da aorta torácica descendente do tipo B** -->
Entre os pacientes com dissecção crônica do tipo B mantidos sob tratamento clínico, uma parcela significativa (em torno de 50%) necessitará de cirurgia. As principais causas de complicações das dissecções são concomitância de um aneurisma grande, crescimento rápido do saco aneurismático, extensão da dissecção ou perfusão inadequada<sup>(22)</sup> .  
Foram identificadas duas revisões sistemáticas: Kamman 2016<sup>(22)</sup> de moderada qualidade e Zhu 2016<sup>(23)</sup> , de muito baixa qualidade, além de coortes de pacientes com características basais como o risco cirúrgico heterogêneo. As evidências apontaram maior benefício com a cirurgia endovascular, considerando o caráter menos invasivo do procedimento e a falta de dados que confirmem a superioridade entre as opções cirúrgicas ( **Apêndice 1** ).

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **REFERÊNCIAS** -->
1. Shiraev TP, Qasabian R, Tardo D, Ninic G, Doyle Z. Open versus Endovascular Repair of Arch and Descending Thoracic Aneurysms: A Retrospective Comparison. Ann Vasc Surg. 2016;31:30-8.  
2. Joyce JW, Fairbairn JF, 2nd, Kincaid OW, Juergen JL. Aneurysms of the Thoracic Aorta. A Clinical Study with Special Reference to Prognosis. Circulation. 1964;29:176-81. 3. Davies RR, Goldstein LJ, Coady MA, Tittle SL, Rizzo JA, Kopf GS, et al. Yearly rupture or dissection rates for thoracic aortic aneurysms: simple prediction based on size. Ann Thorac Surg. 2002;73(1):17-27; discussion -8.  
4. Disponível em: https://www.valleyheartandvascular.com/Thoracic-Aneurysm- <u>Program/Risk-Stratification.aspx),acesso em 10 de janeiro de 2018.</u>  
5. Masuda Y, Takanashi K, Takasu J, Morooka N, Inagaki Y. Expansion rate of thoracic aortic aneurysms and influencing factors. Chest. 1992;102(2):461-6.  
6. Lobato AC, Puech-Leao P. Predictive factors for rupture of thoracoabdominal aortic aneurysm. J Vasc Surg. 1998;27(3):446-53.  
7. Hiratzka LF, Bakris GL, Beckman JA, Bersin RM, Carr VF, Casey DE, Jr., et al. 2010 ACCF/AHA/AATS/ACR/ASA/SCA/SCAI/SIR/STS/SVM guidelines for the diagnosis and management of patients with thoracic aortic disease: executive summary. A report of the American College of Cardiology Foundation/American Heart Association Task Force on Practice Guidelines, American Association for Thoracic Surgery, American College of Radiology, American Stroke Association, Society of Cardiovascular Anesthesiologists, Society for Cardiovascular Angiography and Interventions, Society of Interventional Radiology, Society of Thoracic Surgeons, and Society for Vascular Medicine. Catheter Cardiovasc Interv. 2010;76(2):E43-86.  
8. Disponível em https://www.uptodate.com/contents/management-of-thoracic- <u>aortic-aneurysm-in-</u>  
<u>adults?search=aortic%20aneurysm%20treatment&source=search_result&selectedTitle=1</u> ~150&usage_type=default&display_rank=1. Acesso em 23 de janeiro de 2018.  
9. Disponível em https://www.uptodate.com/contents/endovascular-repair-of-the- <u>thoracic-aorta?topicRef=8189&source=see_link. Acesso em 20 de janeiro de 2018.</u>  
10. Nienaber CA, Eagle KA. Aortic dissection: new frontiers in diagnosis and management: Part I: from etiology to diagnostic strategies. Circulation. 2003;108(5):62835.  
11. Diretrizes metodológicas: elaboração de diretrizes clínicas / Ministério da Saúde, Secretaria de Ciência, Tecnologia e Insumos Estratégicos, Gestão e Incorporação de Tecnologias em Saúde. 2016.  
12. Shea BJ, Reeves BC, Wells G, Thuku M, Hamel C, Moran J, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised or non-randomised studies of healthcare interventions, or both. BMJ. 2017;358:j4008.  
13. Disponivel em: http://www.gradeworkinggroup.org/.Acesso em 20 de janeiro de 2018.  
14. Walsh SR, Tang TY, Sadat U, Naik J, Gaunt ME, Boyle JR, et al. Endovascular stenting versus open surgery for thoracic aortic disease: systematic review and metaanalysis of perioperative results. J Vasc Surg. 2008;47(5):1094-8.  
15. Mustafa ST, Sadat U, Majeed MU, Wong CM, Michaels J, Thomas SM. Endovascular repair of nonruptured thoracic aortic aneurysms: systematic review. Vascular. 2010;18(1):28-33.  
16. Biancari F, Mariscalco G, Mariani S, Saari P, Satta J, Juvonen T. Endovascular Treatment of Degenerative Aneurysms Involving Only the Descending Thoracic Aorta: Systematic Review and Meta-analysis. J Endovasc Ther. 2016;23(2):387-92.  
17. Abraha I, Romagnoli C, Montedori A, Cirocchi R. Thoracic stent graft versus surgery for thoracic aneurysm. Cochrane Database Syst Rev. 2016(6):CD006796.  
18. Alsawas M, Zaiem F, Larrea-Mantilla L, Almasri J, Erwin PJ, Upchurch GR, Jr., et al. Effectiveness of surgical interventions for thoracic aortic aneurysms: A systematic review and meta-analysis. J Vasc Surg. 2017;66(4):1258-68 e8.  
19. Thrumurthy SG, Karthikesalingam A, Patterson BO, Holt PJ, Hinchliffe RJ, Loftus IM, et al. A systematic review of mid-term outcomes of thoracic endovascular repair (TEVAR) of chronic type B aortic dissection. Eur J Vasc Endovasc Surg. 2011;42(5):632-47.  
20. Ulug P, McCaslin JE, Stansby G, Powell JT. Endovascular versus conventional medical treatment for uncomplicated chronic type B aortic dissection. Cochrane Database Syst Rev. 2012;11:CD006512.  
21.    Nienaber CA, Rousseau H, Eggebrecht H, Kische S, Fattori R, Rehders TC, et al. Randomized comparison of strategies for type B aortic dissection: the INvestigation of STEnt Grafts in Aortic Dissection (INSTEAD) trial. Circulation. 2009;120(25):2519-28.  
22.        Kamman AV, Jonker FH, Nauta FJ, Trimarchi S, Moll FL, van Herwaarden JA. A review of follow-up outcomes after elective endovascular repair of degenerative thoracic aortic aneurysms. Vascular. 2016;24(2):208-16.  
23. Zhu Y, Wang B, Meng Q, Liu J, Zhai S, He J. Long-term efficacy of endovascular vs open surgical repair for complicated type-B aortic dissection: a single-center retrospective study and meta-analysis. Braz J Med Biol Res. 2016;49(6):e5194.  
24. Bavaria JE, Appoo JJ, Makaroun MS, Verter J, Yu ZF, Mitchell RS, et al. Endovascular stent grafting versus open surgical repair of descending thoracic aortic aneurysms in low-risk patients: a multicenter comparative trial. J Thorac Cardiovasc Surg. 2007;133(2):369-77.  
25. Nienaber CA, Kische S, Rousseau H, Eggebrecht H, Rehders TC, Kundt G, et al. Endovascular repair of type B aortic dissection: long-term results of the randomized investigation of stent grafts in aortic dissection trial. Circ Cardiovasc Interv. 2013;6(4):40716.  
APÊNDICE 1

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Equipe de desenvolvimento das Diretrizes** -->
Este documento foi elaborado por especialistas em desenvolvimento de diretrizes, médicos com especialização em Estatística, Saúde Pública, Epidemiologia e Medicina Baseada em Evidências, do Núcleo de Avaliação de Tecnologias em Saúde (NATS) do Instituto Nacional de Cardiologia (INC) e contou com a colaboração de representantes da Sociedade Brasileira de Radiologia Intervencionista e Cirurgia Endovascular, Departamento de Cirurgia Endovascular e Minimamente Invasiva, Sociedade Brasileira de Cirurgia Cardiovascular e Sociedade Brasileira de Hemodinâmica e Cardiologia Intervencionista, além de técnicos do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS).  
Os pacientes e seus representantes participaram da elaboração destas Diretrizes por meio da Consulta Pública N° 16 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), disponibilizada _online_ entre 27/09/2017 e 17/10/2017.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Escopo** -->
Com o foco na indicação de endopróteses para aneurisma na porção descendente da aorta torácica, foram elaboradas três perguntas de pesquisa:  
I. Em pacientes com aneurisma da aorta torácica descendente, com indicação de reparo, qual o procedimento (cirurgia aberta ou cirurgia endovascular) com maior eficácia e segurança?  
II. Em pacientes com dissecção de aorta do tipo B não complicada, qual o procedimento (tratamento clínico ou cirurgia endovascular) com maior eficácia e segurança?  
III. Em pacientes com dissecção de aorta do tipo B complicada, qual o procedimento (cirurgia aberta ou cirurgia endovascular) com maior eficácia e segurança?

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Classificação dos Desfechos** -->
De acordo com a metodologia GRADE, o Grupo Elaborador avaliou a importância relativa dos desfechos, conforme especificados no **Quadro 1** .  
**Quadro 1 -** Classificação da relevância clínica dos desfechos  
|**Desfecho**|**Classificação**|
|---|---|
|Mortalidadeperioperatória|Crítico|
|Mortalidadeglobal|Crítico|
|AVC<br>Acidente<br>Vascula|Crítico|
|Cerebral(AVC)||
|Complicação medular|Crítico|
|Complicação vascular|Importante|
|Reprocedimento|Importante|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Estratégia de Busca** -->
As bases de dados consultadas foram Medline via PubMed, Lilacs, Cochrane Library e os registros de ensaios clínicos e revisões sistemáticas da _National Institute for Health_ (USA) (www.clinicaltrials.gov).  
A estratégia de busca foi elaborada para identificar revisões sistemáticas, sem restrição de desenho de estudo incluído ou período, atualizadas com a busca por ensaios clínicos randomizados (ECR) recentes. A busca pelos ECR foi restrita ao período não contemplado pelas revisões sistemáticas e finalizada em 19 de setembro de 2017. As estratégias de busca estão apresentadas no **Quadro 2** .  
**Quadro 2 -** Estratégias de busca  
|**Base de**<br>**dados**|**Estratégia de busca para**<br>**aneurisma**|**Estratégia de busca para dissecção**|
|---|---|---|
|Medline|"Aortic Aneurysm, Thoracic"[A<br>Fields] AND (endovascular[Al<br>Fields] OR TEVAR[All Fields])<br>AND (systematic[sb] OR<br>Randomized Controlled<br>Trial[ptyp])|“aneurysm, dissecting OR “aneurysms<br>dissecting” OR “dissecting aneurysm” [All<br>Fields] AND (endovascular[All Fields] OR<br>TEVAR[All Fields]) AND (systematic[sb] OR<br>Randomized Controlled Trial[ptyp])|
|Cochrane|“Aortic Aneurysm, Thoracic”|“aneurysm, dissecting OR “aneurysms<br>dissecting” OR “dissectinganeurysm”|  
|Lilacs|ti:((tw:(aneurisma)) AND<br>(tw:(torácico)) OR<br>(tw:(aneurisma)) AND<br>(tw:(descendente)) OR<br>(tw:(dissecção)) not<br>(tw:(abdominal)) AND<br>(instance:"regional")) AND<br>(instance:"regional") AND<br>(db:("LILACS"))|ti:((tw:(aneurisma)) AND (tw:(torácico)) OR<br>(tw:(aneurisma)) AND (tw:(descendente))<br>OR (tw:(dissecção)) not (tw:(abdominal))<br>AND (instance:"regional")) AND<br>(instance:"regional") AND (db:("LILACS"))|
|---|---|---|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Seleção dos Artigos** -->
A seleção de artigos foi realizada por pares, de forma independente, e as divergências foram resolvidas por consenso. Todas as revisões sistemáticas e ensaios randomizados que respondessem a uma das três perguntas de pesquisa foram selecionadas, sem restrição de idioma ou qualidade.  
Foram selecionadas nove revisões sistemáticas (de estudos observacionais) e um único ensaio clínico randomizado. Cinco revisões sobre o tratamento do AATD<sup>(14-18)</sup> , três revisões sobre o tratamento da dissecção complicada<sup>(19,22-23)</sup> e uma revisão e um ensaio randomizado sobre o tratamento da dissecção aórtica tipo B não complicada<sup>(20-21)</sup> ( **Figura 1** ).  
**Figura 1 -** Seleção dos artigos  
<!-- Start of picture text -->
Medline 120<br>Cochrane 6<br>Lilacs 2<br>Excluídos:<br>Medline 111 (apêndice 1)<br>Cochrane 6  (4 população e<br>2 duplicatas)<br>Lilacs 2 (população)<br>Aneurisma de aorta torácica<br>Dissecção não<br>Dissecção complicada<br>(Walsh 2008, Mustafa 2010,  complicada<br>Biancari 2016, Abraha 2016 e  (Kamman 2016 e Zhu<br>(Ulug 2012, Thrumurthy<br>Alsawas 2017) 2016)<br>2011 e INSTEAD)<br><!-- End of picture text -->  
Após leitura dos títulos e resumos, foram excluídos estudos da base Medline, cujos motivos estão discriminados no **Quadro 3** .  
**Quadro 3 -** Estudos excluídos da base Medline de acordo com o motivo de exclusão  
|**Motivo da**<br>**Exclusão**|**Referência**|
|---|---|
|Desfecho<br>avaliado fora<br>do escopo|Famularo 2017; Khan 2016; Hynes 2016; Rolph 2015; Nauta 2015;<br>Monastiriotis 2015; De Ruiter 2015 Gawenda 2005; Ramdass 201<br>O’Callaghan 2014; Patterson 2014; Khaja 2014; Nordon 2013; Wilson 201<br>Murphy 2013; Lyons 2013; Rolph  2013; Lee 2013; Wong, 2012; Davies 201<br>Jonker 2010; Bakoyiannis 2010; van Keulen 2009; Falagas 2007; Kan 200<br>Jackson 2007;Murray2006.|
|População for<br>do escopo|Piffaretti 2017; Belczak 2017; Smith 2017; Melissano 2017; Von Allmen 201<br>Glorion 2016; Miao 2016; Hu 2016; Barr 2016; Takagi 2015; Faure 201<br>Patterson 2014; Hogendoorn 2014; Antonopoulos 2014; Canaud 2014; Paci<br>2013; Garg 2012; Shahverdyan 2013; Benedetto, 2013; Johnstone 2013; Ca<br>2012; Zhang 2012; Murashita 2012; Moulakakis 2011; Ramlawi 201<br>Hassoun 2011; Lyons 2011; Prasad 2011; Mastracci; Khoynezhad 2011; Whit<br>2011; Donas 2010; Rehman 2010; Karthikesalingam 2010; Mosquera 2010<br>Jonker 2010; Rheaume 2010; Knepper 2010; Zipfel 2009; Reily 2009; D’El<br>2009; Bakoyiannis 2009; Eagleton 2009; Schlösser 2009; Xenos 200<br>Manninen 2008;Tang2008;Donas 2007;Eggebrecht 2006;Ishimaru 2004.|
|Desenho do<br>estudo|Hertault 2015; Von Aspern 2015; Brunkwall 2003; Boodhwani 2014; Ricc<br>2013; Forbes 2013; Brunkwall 2013; Power 2013; Grabenwöger 2012; Ca<br>2011; Naoum 2011; Ricco 2011; De Rango 2011; Forbes 2011; Jenkis, 201<br>El-Sayed 2011;Krajcer 2010; Fillinger 2010; Forbes 2010; Subramanian 200<br>Corbillon 2008;Svensson 2008;Xiong2009;Hodgson,2006.|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **AVALIAÇÃO DE QUALIDADE** -->
A qualidade metodológica das revisões sistemáticas foi avaliada com a ferramenta AMSTAR II e a dos ensaios clínicos randomizados com a ferramenta de risco de viés da Cochrane<sup>(11)</sup> ( **Quadro 4** ).  
**Quadro 4 -** Análise da qualidade das revisões sistemáticas sobre o tratamento do aneurisma de aorta descendente segundo a ferramenta AMSTAR II.  
|**Estudo**<br>**Critério**|**Walsh**<br>**2008**|**Abraha**<br>**2016**|**Mustafa 201**|**Biancari**<br>**2016**|**Alsawas**<br>**2017**|
|---|---|---|---|---|---|
|**Qualidade**|**Muito baixa**|**Moderada**|**Muito baixa**|**Baixa**|**Moderada**|
|1. PICO|Crítica|Sim|Sim|Sim|Sim|
|2. Protocolo reportado<br>justificaram<br>qualque<br>desvio|Não crítica|Não crítica|Não crítica|Não crítica|Sim|
|3. Seleção do desenho|Não crítica|Não crítica|Não crítica|Não crítica|Não crítica|
|4. Busca adequada|Sim|Sim|Não crítica|Sim|Sim|
|5. Seleção dos estudo<br>em duplicata|Sim|Sim|Crítica|Sim|Sim|
|6. Extração de dados e<br>duplicata|Sim|Sim|Crítica|Não crítica|Sim|
|7.<br>Lista<br>de<br>estudo<br>excluídos|Não crítica|Sim|Não crítica|Não crítica|Não crítica|
|8. Descrição adequad<br>dos estudos|Crítica|Sim|Não crítica|Sim|Sim|
|9. Avaliação do risco d<br>viés|Sim|Sim|Crítica|Sim|Sim|
|10.<br>Informaçã|Não crítica|Sim|Não crítica|Não crítica|Não crítica|
|financiamento<br>do<br>estudos incluídos||||||
|11.<br>Combinaçã<br>estatística<br>adequad<br>para metanálise|Sim|Sim|Sim|Sim|Sim|
|12. Avaliaram impact<br>do risco de viés|Sim|Sim|Sim|Não crítica|Sim|
|13.<br>Consideração<br>d<br>risco de viés na discussã|Sim|Sim|Sim|Não crítica|Sim|
|14.<br>Discussão<br>d<br>heterogeneidade|Sim|Sim|Crítica|Não crítica|Sim|
|15. Impacto do viés d<br>publicação|Sim|Sim|Crítica|Crítica|Sim|
|16. Conflito de interesse|Sim|Sim|Sim|Sim|Sim|  
1 a 16: Tradução simplificada e não validada dos critérios do AMSTAR II.  
No **Quadro 5** , encontram-se os resultados da análise de qualidade específicas das revisões sistemáticas sobre o tratamento da dissecção da aorta torácica descendente tipo B.  
**Quadro 5 -** Análise da qualidade das revisões sistemáticas sobre o tratamento da dissecção da aorta torácica descendente tipo B segundo a ferramenta AMSTAR II  
|**Estudo**<br>**Critério**|**Thrumurthy**<br>**2011**|**Ulug**<br>**2012**|**Kamman**<br>**2016**|**Zhu**<br>**2016**|
|---|---|---|---|---|
|**Qualidade**|**Baixa**|**Moderada**|**Moderada **|**Muito baixa**|
|1. PICO|Sim|Sim|Sim|Sim|
|2.<br>Protocolo<br>reportado<br>justificaramqualquer desvio|Não crítica|Não crítica|Não crítica|Não crítica|
|3. Seleção do desenho|Sim|Não crítica|Não crítica|Não crítica|
|4. Busca adequada|Sim|Sim|Não crítica|Sim|
|5. Seleção dos estudos e<br>duplicata|Não crítica|Sim|Sim|Sim|
|6. Extração de dados e<br>duplicata|Sim|Sim|Não crítica|Sim|
|7. Lista de estudos excluídos|Não crítica|Sim|Não crítica|Não crítica|
|8. Descrição adequada do<br>estudos|Sim|Sim|Sim|Não crítica|
|9. Avaliação do risco de viés|Não crítica|Sim|Não crítica|Não crítica|
|10. Informação financiament<br>dos estudos incluídos|Não crítica|Não crítica|Não crítica|Não crítica|
|11.<br>Combinação<br>estatístic<br>adequadapara metanálise|Sim|Sim|Sim|Sim|
|12. Avaliaram impacto do risc<br>de viés|Sim|Sim|Sim|Não crítica|
|13. Consideração do risco d<br>viés na discussão|Sim|Sim|Não crítica|Não crítica|
|14.<br>Discussão<br>d<br>heterogeneidade|Sim|Sim|Não crítica|Crítica|
|15.<br>Impacto<br>do<br>viés<br>d<br>publicação|Sim|Sim|Sim|Crítica|
|16. Conflito de interesses|Sim|Sim|Sim|Crítica|  
Tradução simplificada e não validada dos critérios do AMSTAR II.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **GRADE E A FORMULAÇÃO DAS RECOMENDAÇÕES** -->
O GRADE ( _Grading of Recommendations Assessment, Development and Evaluation_ ) é um sistema desenvolvido por um grupo colaborativo de pesquisadores que visa à criação de um sistema universal, transparente e sensível para graduar a qualidade das evidências e a força das recomendações. Atualmente, mais de 80 instituições internacionais utilizam o GRADE, entre elas a Organização Mundial da Saúde (OMS), o _National Institute for Health and Clinical Excellence_ (NICE), a SIGN, os _Centers for Disease Control and Prevention_ (CDC) e a colaboração Cochrane.  
No sistema GRADE, a avaliação da qualidade do conjunto das evidências é realizada para cada desfecho analisado, e a qualidade da evidência é classificada em quatro níveis: alto, moderado, baixo e muito baixo. Esses níveis representam a confiança que se possui na estimativa dos efeitos apresentados.  
A classificação inicial da qualidade da evidência é definida a partir do delineamento dos estudos. O ensaio clínico randomizado é o delineamento de estudo mais adequado para questões relacionadas à intervenção e, quando são considerados esses ensaios clínicos, a qualidade da evidência pelo sistema GRADE inicia-se como alta. Quando apenas estudos observacionais são incluídos, a qualidade da evidência se inicia como baixa. A partir da classificação inicial, critérios são definidos, e o julgamento desses aspectos permitem reduzir ou elevar o nível de evidência. Os fatores responsáveis pela redução no nível de evidência são: 1) Limitações metodológicas (risco de viés); 2) Inconsistência; 3) Evidência indireta; 4) Imprecisão; e 5) Viés de publicação.  
A força da recomendação expressa a ênfase para que seja adotada ou rejeitada uma determinada conduta, considerando potenciais vantagens e desvantagens. São consideradas vantagens os efeitos benéficos na melhoria da qualidade de vida dos pacientes, o aumento da sobrevida e a redução dos custos. São consideradas desvantagens os riscos de efeitos adversos, a carga psicológica para o paciente e seus familiares e os custos para a sociedade. O balanço na relação entre vantagens e desvantagens determina a força da recomendação.  
A força da recomendação (forte ou fraca) pode ser a favor ou contra a conduta proposta, representando a confiança que se tem que as vantagens sobrepõem às desvantagens da intervenção proposta.  
Para o desenvolvimento destas Diretrizes, com a técnica de painel Delphi presencial e eletrônico, profissionais com experiência no desenvolvimento de diretrizes, em parceria com médicos representantes das Sociedades de especialistas na área de tratamento do aneurisma e dissecção da aorta torácica, utilizaram o método GRADE para formularem as recomendações.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Resultados** -->
**PERGUNTA 1: Em pacientes com aneurisma da aorta torácica descendente com indicação de cirurgia, qual o procedimento com maior eficácia e segurança, cirurgia endovascular ou cirurgia aberta?**  
Não foram encontrados ensaios clínicos randomizados. Foram selecionadas cinco revisões sistemáticas<sup>(14-18)</sup> com qualidade metodológica variando de muito baixa a moderada.  
Os resultados destas revisões ( **Tabela 1A** ) sugerem menor risco de eventos como mortalidade intra-hospitalar, paraplegia, paresia e tempo de internação a favor da cirurgia endovascular.  
**TABELA 1A -** RESUMO DOS ACHADOS DAS REVISÕES SISTEMÁTICAS  
|**Desfecho**|**Procedimento**|**Walsh**<br>**2008**|**Mustafa**<br>**2010**|**Biancari**<br>**2016**|**Alsawas**<br>**2017**|
|---|---|---|---|---|---|
|Morte em 30 dias|Endovascular|5,6%|5,1%|4,0%|6,4%|
||Aberta|16,5%|-|-|8,2%|
|Complicação neuroló|gi<br>Endovascular|5,4%|3,1%|4,6%|5,2%|
|grave|Aberta|14%|-|-|13,4%|
|Reintervenção|Endovascular|7%|14,9%|9,6%|-|
||Aberta|8,4%|-|-|-|  
A seguir, são apresentados os principais resultados destas revisões.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **WALSH SR, 2008**<sup>**(14)**</sup> **.** -->
O estudo identificou 17 séries de casos, totalizando 1.109 pacientes (538 implantes de endopróteses e 571 cirurgias abertas). Trata-se de uma revisão sistemática de muito baixa qualidade, cuja maior limitação foi a inclusão de aneurismas de diferentes etiologias; entre os 17 estudos analisados, sete apresentaram trauma como etiologia e nove incluíram ruptura de aorta como população. A cirurgia endovascular foi associada à redução significativa na mortalidade perioperatória e na taxa de complicação neurológica (paraplegia e AVC perioperatório). Não houve diferença na taxa de reintervenção ( **Tabela 2A** ).  
**TABELA 2A -** RESUMO DOS ACHADOS NA REVISÃO SISTEMÁTICA DE WALSH _ET AL_ . SOBRE A CIRURGIA ENDOVASCULAR _VERSUS_ CIRURGIA ABERTA NO TRATAMENTO DO ANEURISMA DA AORTA TORÁCICA DESCENDENTE  
|**Desfecho**|**Endovascular %**|**Cirurgia %**|**OR**|
|---|---|---|---|
|**(n/ n_endov./n_cir.)**|**(n° de eventos)**|**(n° de eventos)**|**IC 95%**|
|Morte perioperatória|5,6%|16,5%|0,36|
|(17/538/571)|(30)|(94)|0,23 – 0,58|
|Complicação neurológica grav|5,4%|14%|0,39|
|(16/481/476)|(26)|(67)|0,25 – 0,62|
|Reintervenção|7%|8,4%|0,82|
|(9/414/355)|(29)|(30)|0,48 – 1,40|  
N = número de estudos; n_endov = número de pacientes submetidos à cirurgia endovascular; n_cir = número de pacientes submetidos à cirurgia aberta.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **MUSTAFA 2010**<sup>**(15)**</sup> -->
Com o objetivo de avaliar a mortalidade em 30 dias após cirurgia endovascular no tratamento do AATD, foram selecionados 27 estudos (26 estudos do tipo série de casos e um observacional, detalhado abaixo) totalizando 1.038 casos de cirurgia endovascular. A qualidade da evidência da revisão foi julgada como muito baixa. Os resultados estão resumidos no **Quadro 6** .  
**QUADRO 6 -** RESULTADOS DOS ESTUDOS TIPO SÉRIE DE CASOS COM CIRURGIA ENDOVASCULAR PARA O  
ANEURISMA DA AORTA TORÁCICA DESCENDENTE DA REVISÃO DE MUSTAFA _ET AL_ .  
|**Desfecho**|**Incidência (%) n/N**|
|---|---|
|Morte em 30 dias|5,1% (53/1039)|
|Morte em 1 ano|23,3% (123/528)|
|Morte em 2 anos|17,6% (46/262)|
|Ruptura|3,8% (19/497)|
|Isquemia medular|3,1% (23/745)|
|Acidente vascular cerebral|4,7% (27/579)|
|Migração da prótese|2,4% (12/497)|
|Reintervenção|14,9% (74/498)|  
n = número absoluto de casos. N = número total de participantes nos estudos que reportaram os resultados referentes ao desfecho.  
O único estudo<sup>(24)</sup> incluído na revisão sistemática de Mustafa _et al._ 2010 que comparou os tratamentos avaliou os desfechos de 140 pacientes tratados com cirurgia endovascular em relação a uma coorte tratada com cirurgia aberta em 94 pacientes com aneurisma da aorta torácica descendente. Os resultados estão resumidos na **Tabela 3A** .  
**TABELA 3A -** RESUMO DOS RESULTADOS DO ESTUDO OBSERVACIONAL DE BAVARIA ET AL. COMPARAÇÃO ENTRE COORTES DE CIRURGIA ENDOVASCULAR E A CIRURGIA ABERTA NO ANEURISMA DA AORTA  
TORÁCICA DESCENDENTE  
|**Desfecho**|**Endovascular**|**Cirurgia**|**Valor de P**|
|---|---|---|---|
|Mortalidade em 30 dias|2,1%|11,7%|0,004|
|Insuficiência respiratória|4%|20%|< 0,001|
|Insuficiência renal|1%|13%|0,01|
|Paraplegia/paraparesia|3%|14%|0,003|
|Tempo de internação no CTI|2,6±14,6 dias|5,2±7,2 dias|< 0,001|
|Tempo de internação hospitalar|7,4±17,7 dias|14,4±12,8 dias|< 0,001|
|Complicações vasculares|14%|4%|0,015|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **BIANCARI 2016**<sup>**(16)**</sup> -->
Este estudo avaliou a cirurgia endovascular em aneurismas da aorta torácica descendente em 11 estudos do tipo série de casos, totalizando 673 pacientes. Os resultados estão resumidos na quadro 7.  
**QUADRO 7 -** RESUMO DOS RESULTADOS DA REVISÃO DE BIANCARI ET AL. RESULTADOS COM A CIRURGIA

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **BIANCARI 2016**<sup>**(16)**</sup> -->
|**Desfecho**|**Incidência (%)**|
|---|---|
|Morte em 30 dias|4,0% (2% a 6%)|
|Paraplegia|3,2% (1,9% a 4,5%)|
|Paresia permanente|1,4% (0,6% a 2,3%)|
|Reintervenção|9,6% (6,5% a 12,7%)|
|Ruptura|3,2% (1,2% a 5,2%)|
|Sobrevida em 1 ano|93,4% (89,3% a 97,5%)|
|Sobrevida em 2 anos|91,8% (87,6% a 96,1%)|
|Sobrevida em 3 anos|90,3% (85,3% a 95,4%)|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **ABRAHA 2016**<sup>**(17)**</sup> -->
Esta revisão do grupo Cochrane apresentou moderada qualidade pelo critério AMSTAR II. Buscou evidências restritas a ensaios clínicos randomizados, não identificando nenhum estudo.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **ALSAWAS 2017**<sup>**(18)**</sup> -->
A revisão teve como objetivo comparar a cirurgia endovascular com a cirurgia aberta no tratamento do aneurisma da aorta torácica descendente. Foram identificados 27 estudos observacionais. A avaliação da qualidade metodológica pelo AMSTAR II apontou qualidade moderada. O resumo dos achados está apresentado no **Quadro 8** .  
**Quadro 8 –** Resumo dos achados sobre a cirurgia endovascular e a cirurgia aberta para o  
tratamento do aneurisma da aorta torácica descendente no estudo de Alsawas _et al_ .  
|**Desfecho**<br>**(número de estudos/ total depacientes)**|**OR**<br>**(IC 95%)**|
|---|---|
|Morte em 30 dias|0,56|
|(18/22.702)|(0,4-0,74)|
|Morte em 30 dias exclusivamente em aneurismas sem ruptu|0,6|
|(9/19.985)|(0,36-0,99)|
|Paraplegia em 30 dias (6/77)|0,35<br>(0,2-0,6)|
|AVC em 30 dias (8/41.401)|0,89<br>(0,76-1,03)|  
<u>Recomendação do sistema GRADE: A recomendação é fraca, favorável à cirurgia</u> endovascular nos pacientes com aneurisma da aorta torácica descendente com indicação de cirurgia, devido a: 1) ausência de ensaios randomizados; 2) estudos observacionais com alto risco de viés; e 3) heterogeneidade entre os resultados e identificação do viés de publicação nas meta-análise.  
**PERGUNTA 2: Em pacientes com dissecção de aorta do tipo B não complicada, deve-se proceder à cirurgia endovascular?**  
Para a dissecção aórtica do tipo B não complicada, identificaram-se duas revisões sistemáticas<sup>(19, 20)</sup> e um ensaio clínico randomizado<sup>(21)</sup> . A revisão de Ulug _et al._ teve como objetivo identificar ensaios clínicos randomizados, selecionando apenas um estudo, o ensaio chamado INSTEAD. De acordo com o AMSTAR 2, a revisão apresentou qualidade moderada. A revisão de Thrumurthy 2011 foi considerada de baixa qualidade.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **THRUMURTHY 2011**<sup>**(19)**</sup> -->
Após o implante da endoprótese, a literatura é escassa em relação a resultados de longo prazo. Esta revisão teve como objetivo avaliar os resultados de médio prazo após o tratamento endovascular da dissecção crônica de aorta tipo B não complicada. Foram selecionados 17 estudos: um ensaio clínico randomizado, 14 coortes retrospectivas e 2 coortes prospectivas, incluindo 567 pacientes com mediana de 26,1 meses de seguimento. Os resultados de curto prazo (até 30 dias) e de médio prazo (entre 30 dias e 5 anos) estão resumidos respectivamente na **Tabela 4A** .  
**Tabela 4A -** Resultados de curto e médio prazo da cirurgia endovascular em dissecções de  
aorta tipo B, resultados da revisão de Thrumurthy _et al_ .  
|**Desfecho**|**Incidência curto prazo**|**Incidência médio prazo**|
|---|---|---|
||**(até 30 dias)**|**(30 dias a 5 anos)**|
|Morte|3,2% (18/567)|9,2% (46/499)|
|Vazamentos|11,7% (38/325)|8,1% (25/309)|
|AVC|0,8% (4/489)|1,5% (7/475)|
|Paraplegia/paraparesia|0,4%(2/462)|0,4%(2/447)|  
O estudo INSTEAD, que foi inicialmente desenhado para dois anos de seguimento, apresentou alta qualidade metodológica. Este ensaio não apontou diferença significativa na mortalidade entre os grupos de tratamento clínico e a cirurgia endovascular. Os resultados estão resumidos na **Tabela 5A** .  
**TABELA 5A -** RESULTADOS DE 2 ANOS DE SEGUIMENTO PARA O TRATAMENTO DA DISSECÇÃO DO TIPO B  
NÃO COMPLICADA, ESTUDO INSTEAD  
|**Desfecho**|**Tratamento clínico**|**Cirurgia endovascular**|**Valor de P**|
|---|---|---|---|
||**N(%)**|**N(%)**||
|Morte|3 (4,4)|8 (11,1)|0,2|
|Paraplegia/paraparesia|1 (1,4)|2 (2,8)|0,9|
|permanente||||  
2 (2,8) 0,53  
AVC com sequela  
0  
Embora em 2013 tenham sido publicados os resultados de cinco anos de seguimento<sup>(25)</sup> , foi detectada uma limitação relevante da qualidade da evidência e, portanto, este estudo foi excluído da análise.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **Considerações a respeito do ensaio Instead** -->
Na publicação dos resultados de 5 anos de seguimento<sup>(25)</sup> , observa-se uma incoerência entre o texto e o gráfico de sobrevida apresentado (Figura 2A). Enquanto no texto encontra-se referência a não haver perdas de seguimento e nenhuma morte no grupo do tratamento endovascular após o segundo ano, o gráfico de sobrevida apresenta um resultado diferente, com ambos os grupos finalizando o estudo com 32 pacientes (metade dos pacientes recrutados inicialmente). Para esclarecer estes dados, em 20 de fevereiro de 2018 tentou-se contato, por _e-mail_ , com os autores e com os editores da revista em que o artigo foi publicado, entretanto não se obteve resposta.  
<u>Recomendação do Sistema GRADE: Em pacientes com dissecção da aorta torácica do tipo</u> B, não complicada, a recomendação é fraca, favorável ao tratamento clínico. Os dados foram baseados em apenas um ensaio randomizado que apresentou resultados de 2 e 5 anos, sendo a extensão (5 anos de seguimento) excluída da análise devido a graves limitações metodológicas.  
**PERGUNTA 3: Em pacientes com dissecção da aorta torácica descendente do tipo B com indicação de intervenção, qual o procedimento com maior eficácia e segurança, cirurgia endovascular ou cirurgia aberta?**  
Entre os pacientes com dissecção crônica do tipo B mantidos sob tratamento clínico, uma parcela significativa (em torno de 50%) necessitará de cirurgia. As principais causas de complicações das dissecções são concomitância de um aneurisma grande, crescimento rápido do saco aneurismático, extensão da dissecção ou perfusão inadequada<sup>(22)</sup> .  
Foram identificadas duas revisões sistemáticas: Kamman 2016<sup>(22)</sup> de moderada qualidade e Zhu 2016<sup>(23)</sup> , de muito baixa qualidade.  
De forma geral, foram identificadas coortes de pacientes com características basais como o risco cirúrgico heterogêneo, limitando a avaliação dos dados e a comparação dos tratamentos. Os principais dados das revisões estão resumidos a seguir.

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **KAMMAN 2016**<sup>**(22)**</sup> -->
O objetivo desta revisão sistemática foi identificar qual a melhor intervenção, cirurgia aberta ou endovascular no tratamento para dissecção de aorta tipo B crônica que evolui para a necessidade de intervenção. Selecionadas 35 coortes envolvendo 1.081 pacientes no grupo da cirurgia aberta com um tempo de seguimento que variou de 34 a 102 meses e 1.393 pacientes no grupo de cirurgia endovascular, com 12 a 90 meses de seguimento. Os principais resultados estão resumidos na **Tabela rA** .  
**Tabela 6A -** Taxa de eventos em coortes de pacientes portadores de dissecção de aorta  
tipo B complicada, revisão de Kamman _et al._  
|**Desfecho**|**Cirurgia aberta**<br>**Evento %**<br>**(número de estudos)**|**Cirurgia endovascular**<br>**Evento %**<br>**(número de estudos)**|
|---|---|---|
|Morte perioperatória|5,6 - 21<br>(10)|0 - 13,7<br>(24)|
|Sobrevida em 1 ano|72 – 92<br>(6)|82,9 – 100<br>(9)|
|Sobrevida em 5 anos|53 – 86,7<br>(4)|64 – 88,9<br>(8)|
|Sobrevida em 10 anos|32 – 60<br>(3)|63<br>(1)|
|AVC|0 – 13,3<br>(10)|0 – 11,8<br>(16)|
|Isquemia medular|0 – 16,4<br>(10)|0 – 12,5<br>(15)|
|Insuficiência renal aguda|0 -33,3<br>(10)|0 – 34,4<br>(17)|
|Ruptura|0,4<br>1|0,5 – 7,1<br>(7)|
|Reintervenção|5,8 – 33,3<br>(8)|3,6 – 47,4<br>(17)|

---

<!-- METADADOS: doenca: Utilização de Endoprótese em Aorta Torácica Descendente (Diretrizes Brasileiras) | secao: **ZHU 2016**<sup>**(23)**</sup> -->
Revisão feita com o objetivo de comparar a cirurgia aberta com a endovascular no tratamento da dissecção da aorta torácica tipo B complicada. Incluídos nove estudos  
observacionais envolvendo coortes retrospectivas e prospectivas.  Não foi identificada diferença na sobrevida de longo prazo (HR 0,87, IC95% 0,52 – 1,98), embora os pacientes do grupo cirurgia aberta (n = 303) fossem significativamente mais jovens (49 versus 55; P = 0,006) do que o grupo da cirurgia endovascular (n = 436).  
<u>Recomendação do sistema GRADE: Em pacientes com dissecção da aorta torácica</u> descendente do tipo B complicada, a recomendação é fraca, favorável à cirurgia endovascular, considerando o caráter menos invasivo do procedimento e a falta de dados que confirmem a superioridade entre as opções cirúrgicas. A evidência foi avaliada como fraca devido a: 1) ausência de ensaios randomizados; 2) estudos observacionais com alto risco de viés; 3) heterogeneidade entre os resultados; e 4) perfil semelhante de eficácia e segurança entre os tratamentos.

---

