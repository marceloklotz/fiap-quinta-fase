<!-- METADADOS: doenca: Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais | secao: Geral -->
###### **MINISTÉRIO DA SAÚDE**  
###### **SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS**  
###### **PORTARIA SCTIE/MS Nº 55, DE 11 DE NOVEMBRO DE 2020**  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais.  
O SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições legais, resolve:  
Art. 1º Fica atualizado o Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais.  
Art. 2º O relatório de recomendação da Comissão Nacional de Incorporação de Tecnologias no Sistema Único de Saúde (CONITEC) sobre essa tecnologia estará disponível no endereço eletrônico <u>http://conitec.gov.br/.</u>  
Art. 3º Esta Portaria entra em vigor na data de sua publicação.  
Art. 4º Fica revogada a Portaria SCTIE/MS nº 50/2017 de 23 de novembro de 2017, publicada no Diário Oficial da União nº 226, de 27 de novembro de 2017, seção 1, página 120.  
HÉLIO ANGOTTI NETO  
**PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA PREVENÇÃO DA TRANSMISSÃO VERTICAL DO HIV, SÍFILIS E HEPATITES VIRAIS**  
**MINISTÉRIO DA SAÚDE**  
**Secretaria de Vigilância em Saúde Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis**  
###### **INTRODUÇÃO**  
O presente “Protocolo Clínico e Diretrizes Terapêuticas para Prevenção da Transmissão Vertical de HIV, Sífilis e Hepatites Virais” (PCDT-TV) tem por objetivo orientar o manejo das mulheres e suas parcerias sexuais quanto às Infecções Sexualmente Transmissíveis (IST) de potencial transmissão vertical, tratando especialmente da saúde sexual e reprodutiva para a população vivendo com HIV e do uso de antirretrovirais e demais agentes anti-infecciosos para prevenção e tratamento das IST, especialmente da sífilis, das hepatites virais (B e C) e da infecção pelo HIV, nas mulheres gestantes e crianças expostas.  
Este PCDT-TV está estruturado em cinco partes. A **Parte I** aborda a saúde sexual e reprodutiva no âmbito da prevenção combinada voltada para a mulher com vida sexual ativa. A **ParteI II** fala sobre recomendações de testagens recomendadas durante o pré-natal, IST na gestação, questões relacionadas ao Zika vírus e HTLV I/II.  
A **Parte III** trata da Prevenção da Transmissão Vertical do HIV mais especificamente, das pessoas vivendo com HIV, com enfoque também nas parcerias sexuais sorodiferentes e na Prevenção Combinada, incluindo a Profilaxia Pré-Exposição Sexual (PrEP).  Além disso, propõe novo esquema de tratamento antirretroviral para as gestantes que vivem com HIV, com incorporação do dolutegravir como escolha para compor o esquema preferencial inicial nas gestantes vivendo com HIV.  
A **Parte IV** trata da Prevenção da Transmissão Vertical da sífilis e foi atualizada em janeiro de 2020 para ficar alinhada com as definições do Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infeccções Sexualmente Transmissíveis (IST), a fim de contemplar com maior especificidade a gestante, mantendo o reforço à importância do diagnóstico e tratamento da parceria sexual, assim como todo o seguimento e manejo da criança exposta.  
Finalmente, a **Parte V** detalha a Prevenção da Transmissão Vertical das hepatites virais, com abordagem à gestante e à criança exposta para hepatites virais B e C.  
Este PCDT-TV está alinhado com os PCDT para Manejo da Infecção pelo HIV em Adultos, Profilaxia PósExposição de Risco à Infecção pelo HIV (PEP), Profilaxia Pré- Exposição de Risco à Infecção pelo HIV (PrEP) e Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis (IST), sendo os respectivos conteúdos referenciados entre os documentos. Os citados PCDT estão disponíveis em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
Nesse contexto, o presente PCDT-TV se propõe a ser uma ferramenta de linguagem objetiva, de modo a facilitar o acesso às principais informações e recomendações, possibilitando a sua utilização pela equipe multiprofissional de saúde no cuidado integral às gestantes, suas parcerias sexuais e crianças expostas.  
###### **Sumário**  
|**CONTEXTO ....................................................................................................**ERRO! INDICADOR NÃO DEFINIDO.|
|---|
|**PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS PARA PREVENÇÃO DA TRANSMISSÃO VERTICAL DO HIV,**|
|**SÍFILIS E HEPATITES VIRAIS ............................................................................................................................... 2**|
|**PARTE I - SAÚDE SEXUAL E REPRODUTIVA DA MULHER NO ÂMBITO DO HIV, IST E HEPATITES VIRAIS ............. 3**|
|**1.1 UMA ABORDAGEM CENTRADA NA MULHER..............................................................................................7**|
|**1.2 PREVENÇÃO COMBINADA PARA MULHERES..............................................................................................8**|
|**PARTE II - INFECÇÕES SEXUALMENTE TRANSMISSÍVEIS E TRANSMISSÃO VERTICAL ....................................... 14**|
|**2.1 TESTAGEM PARA PREVENÇÃO DA TRANSMISSÃO VERTICAL .................................................................... 14**|
|**2.2 MANEJO DAS IST NA GESTANTE E PARCERIA ............................................................................................... 15**|
|**2.3 MANEJO DO RN PARA PROFILAXIA DE GONORREIA ................................................................................. 16**|
|**2.4 HTLV ....................................................................................................................................................... 166**|
|**2.5 VÍRUS ZIKA ............................................................................................................................................... 17**|
|**PARTE III – PREVENÇÃO DA TRANSMISSÃO VERTICAL DO HIV ........................................................................ 19**|
|**3.1. PESSOAS VIVENDO COM HIV E DIREITOS REPRODUTIVOS ....................................................................... 20**|
|**3.2. PESSOAS VIVENDO COM HIV E PLANEJAMENTO SEXUAL E REPRODUTIVO .............................................. 21**|
|**3.3 ADOLESCÊNCIA EM PESSOAS VIVENDO COM HIV ..................................................................................... 21**|
|**3.4 ORIENTAÇÕES SOBRE SAÚDE SEXUAL DE PESSOAS VIVENDO COM HIV .................................................... 22**|
|**3.5 PLANEJAMENTO REPRODUTIVO PARA CONCEPÇÃO EM PESSOAS VIVENDO E CONVIVENDO COM HIV ... 24**|
|**3.5.1**<br>**PREVENÇÃO DA TRANSMISSÃO SEXUAL E VERTICAL DOHIV**............................................................................. 24|
|**3.5.2**<br>**CONTINUIDADE DAPREP PARA A MULHER GESTANTE E NO PUERPÉRIO**.............................................................. 25|
|**3.5.3**<br>**ORIENTAÇÕES GERAIS PARA O PLANEJAMENTO REPRODUTIVO**.......................................................................... 26|
|3.5.3.1<br>DETERMINAÇÃO DO PERÍODO FÉRTIL DA MULHER........................................................................................ 26|  
|**3.5.4**<br>**ESTRATÉGIAS DE CONCEPÇÃO PARA PARCERIAS SEXUAIS SORODIFERENTES PARAHIV**........................................... 26<br>|
|---|
|**SITUAÇÃO1: MULHER VIVENDO COM HIV E PARCERIA SEXUALHOMEM NEGATIVO PARA OHIV**............................ 27|
|**SITUAÇÃO2: HOMEM VIVENDO COM HIV E PARCERIA SEXUALMULHER NEGATIVA PARA OHIV**............................ 28|
|**3.5.5 ESTRATÉGIAS PARA PARCERIAS SEXUAIS SOROIGUAIS**.......................................................................................... 28|
|**3.6 PRÉ-NATAL DO PARCEIRO**...................................................................................................................................... 28|
|**3.7 PLANEJAMENTO REPRODUTIVO NA CONTRACEPÇÃO EMPESSOASVIVENDO COMHIV**..................................................... 29|
|**3.7.1**<br>**ORIENTAÇÕES QUANTO À CONTRACONCEPÇÃO**.............................................................................................. 30|
|**3.7.2 MULHERES COM ALTO RISCO DE INFECÇÃO PELOHIV (MULHER NEGATIVA PARA OHIV E PARCEIRO POSITIVO PARA OHIV).**|
|.......................................................................................................................................................................... 32|
|_3.7.3.1_<br>_Preservativos masculino e feminino ............................................................................................ 38_|
|_3.7.3.2_<br>_Dispositivo intrauterino............................................................................................................... 38_|
|_3.7.3.3_<br>_Métodos hormonais orais (combinados ou apenas de progestagênio) ...................................... 38_|
|_3.7.3.4_<br>_Métodos hormonais combinados não orais (injetáveis mensais) ............................................... 38_|
|_A OMS libera o uso destes métodos independente da TARV utilizada (45). ................................................. 38_|
|_3.7.3.5_<br>_Método hormonal de progestagênio não oral (injetável trimestral) .......................................... 39_|
|_A OMS libera o uso destes métodos independente da TARV utilizada (45). ................................................. 39_|
|_3.7.3.6_<br>_Métodos definitivos .................................................................................................................... 39_|
|_3.7.3.7_<br>_Contracepção de emergência ..................................................................................................... 39_|
|**_3.8 Abordagem diagnóstica da infecção pelo HIV na gestação, parto e puerpério_**_........................................... 40_|
|**_3.9 Abordagem inicial da gestante vivendo com HIV_**_......................................................................................... 42_<br>|
|**3.10 SEGUIMENTO CLÍNICO, LABORATORIAL E OBSTÉTRICO**............................................................................................... 43|
|**_3.10.1 Avaliação laboratorial inicial_**_........................................................................................................... 46_|
|**_Periodicidade de consultas e seguimento laboratorial_**_.............................................................................. 47_|
|**3.10.2 INVESTIGAÇÃO DE TUBERCULOSE EM GESTANTES VIVENDO COMHIV/AIDS**....................................................... 53|
|_Para mais informações sobre o tratamento da coinfecção TB-HIV, consultar o “Manual de Recomendações_<br>_para Controle da Tuberculose no Brasil”, disponível em http://www.saude.gov.br/tuberculose, e o_<br>_“Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”, disponível em_<br>_http://www.aids.gov.br/pcdt, a Nota Informativa Nº 11/2018/DCCI/SVS/MS e o Ofício Circular n°_<br>_05/2018/DAF/SCTIE/MS. .............................................................................................................................. 54_|
|**3.10.3 IMUNIZAÇÕES NA GESTANTE VIVENDO COMHIV/AIDS**................................................................................. 54|
|**3.11 - PREPARAÇÃO DA GESTANTE VIVENDO COMHIV/AIDS PARA O TRATAMENTO**............................................................. 58|
|**3.11.1 ATIVIDADE FÍSICA NA GESTAÇÃO**................................................................................................................... 58|
|**3.11.2 ABORDAGEM NUTRICIONAL DA GESTANTE VIVENDO COMHIV/AIDS**................................................................... 58|
|**3.11.3 ATIVIDADE SEXUAL NA GESTAÇÃO**................................................................................................................. 59|
|**3.11.4 ADESÃO NA GESTAÇÃO E PÓS-PARTO**............................................................................................................. 60|
|**3.12 - TRATAMENTO ANTIRRETROVIRAL NA GESTAÇÃO: PRINCÍPIOS, INDICAÇÕES, MONITORAMENTO,**|
|**MANEJO DE EVENTOS ADVERSOS E COMPLICAÇÕES (SIR) .............................................................................. 60**|
|**3.12.1 GENOTIPAGEM PRÉ-TRATAMENTO**................................................................................................................. 61|
|**A) ESQUEMA INICIAL PREFERENCIAL PARA INÍCIO NO1º TRIMESTRE(ATÉ12 SEMANAS DEIG)**............................................ 62|
|**3.12.3.2**<br>**MANEJO DA GESTANTE JÁ EM USO DETARV**........................................................................................ 66|
|**A) MANEJO DA GESTANTE EM USO DETARV COMCV-HIV INDETECTÁVEL**..................................................................... 66|
|**B) MANEJO DA GESTANTE JÁ EM USO DETARV COMCV-HIV DETECTÁVEL**..................................................................... 67|
|**3.12.3.3**<br>**MANEJO DA GESTANTE PARA REINÍCIO DETARV APÓS ABANDONO**.......................................................... 69|
|**SEGURANÇA DOSARV NA GESTAÇÃO**....................................................................................................................... 73|
|<br>**3.12.4 MANEJO DOS EFEITOS ADVERSOS DATARV**.................................................................................................... 74|
|**3.12.5 SÍNDROMEINFLAMATÓRIA DARECONSTITUIÇÃOIMUNE NA GESTANTE VIVENDO COMHIV/AIDS**............................. 78|
|**3.13 PROFILAXIA DE INFECÇÕES OPORTUNISTAS NA GESTANTE VIVENDO COMHIV/ AIDS**..................................................... 78|
|**_3.13.1 Profilaxia primária_**_............................................................................................................................ 79_|
|**_3.13.2 Profilaxia secundária_**_........................................................................................................................ 84_|
|**3.14 - COINFECÇÕES NA GESTANTE VIVENDO COM HIV/AIDS ........................................................................ 90**|
|**3.14.1.  COINFECÇÃOHIV E TUBERCULOSE**........................................................................................................... 90|  
|**_Critérios para início do tratamento antirretroviral na coinfecção HIV-TB na gestante_**_............................ 90_<br>|
|---|
|**_Manejo do tratamento da coinfecção HIV/TB na gestante_**_....................................................................... 90_|
|<br>**_Manejo de gestantes multiexperimentadas na coinfecção HIV-TB_**_........................................................... 92_|
|**3.14.2 COINFECÇÃOHIV E HEPATITES VIRAIS**............................................................................................................ 92|
|**_Rastreamento de hepatites virais na gestante vivendo com HIV/aids_**_...................................................... 92_|
|**_Coinfecção HIV-HBV em gestantes_**_.............................................................................................................. 93_<br>|
|**_Coinfecção HIV-HCV em gestantes_**_.............................................................................................................. 94_|
|**3.15 - MANEJO DAS INTERCORRÊNCIAS OBSTÉTRICAS NAS GESTANTES VIVENDO COM HIV/AIDS ................. 95**|
|**HEMORRAGIA PÓS-PARTO**...................................................................................................................................... 95|
|**HIPERÊMESE GRAVÍDICA**......................................................................................................................................... 96|
|**ROTURA PREMATURA DE MEMBRANAS**..................................................................................................................... 96|
|**_RPM em idade gestacional inferior a 34 semanas_**_..................................................................................... 97_|
|**_RPM em idade gestacional superior a 34 semanas_**_.................................................................................... 97_|
|**SANGRAMENTO VAGINAL NA GESTAÇÃO**.................................................................................................................... 98|
|**TRABALHO DE PARTO PRÉ-TERMO**............................................................................................................................ 98|
|**CONDUTA EM CASO DE NECESSIDADE DE REALIZAÇÃO DE PROCEDIMENTO INVASIVO**.......................................................... 99|
|**_3.16 - Manejo obstétrico e vias de parto na gestante vivendo com HIV_**_............................................................ 99_|
|**3.16.1.  INDICAÇÃO DA VIA DE PARTO EM GESTANTES VIVENDO COMHIV/AIDS**............................................................ 99|
|**3.16.2.  BIOSSEGURANÇA NO PARTO**..................................................................................................................... 103|
|**3.17 - USO DE TERAPIA ANTIRRETROVIRAL COMO PROFILAXIA DA TRANSMISSÃO VERTICAL DOHIV NO PARTO**........................ 103|
|**3.17.1.  INDICAÇÃO DEAZT NAPTV DOHIV NO PARTO**........................................................................................... 103|
|**3.18 - MANEJO DA MULHER VIVENDO COM HIV NO PUERPÉRIO ................................................................. 105**|
|**3.19 - MANEJO CLÍNICO DO RECÉM-NASCIDO EXPOSTO AOHIV**...................................................................................... 106|
|**3.19.1.  CUIDADOS NA SALA DE PARTO E PÓS-PARTO IMEDIATO**................................................................................. 106|
|**3.19.2  QUIMIOPROFILAXIA DORN EXPOSTO AOHIV**.............................................................................................. 109|
|**QUIMIOPROFILAXIA PARA OHIV**........................................................................................................................... 109|
|**3.19.3.  ROTINA DE ACOMPANHAMENTO CLÍNICO E LABORATORIAL DA CRIANÇA EXPOSTA AO HIV ...... 112**|
|**3.19.4 ESQUEMA VACINAL NA MATERNIDADE ........................................................................................ 112**|
|**IMUNIZAÇÃO DO RN QUE PERMANECE INTERNADO NA UNIDADE NEONATAL ............................................ 112**|
|**3.19.5 IMUNOBIOLÓGICOS NA UNIDADE NEONATAL ............................................................................... 113**|
|**IMUNOGLOBULINA ANTI-HEPATITE B (IGHAHB) E VACINA DE HEPATITE B ................................................... 113**|
|**IMUNOGLOBULINA ANTI-VARICELA-ZOSTER (IGHVZ) ................................................................................... 113**|
|**_Imunoglobulina antitetânica (IGHT)_**_......................................................................................................... 114_|
|**PARTE IV – PREVENÇÃO DA TRANSMISSÃO VERTICAL DA SÍFILIS ................................................................. 122**|
|**4.1.  DEFINIÇÃO E ETIOLOGIA DA SÍFILIS..................................................................................................... 129**|
|**4.2.  TRANSMISSÃO DA SÍFILIS ....................................................................................................................129**|
|**4.3.  CLASSIFICAÇÃO CLÍNICA DA SÍFILIS ..................................................................................................... 130**|
|**4.4.  MÉTODOS DIAGNÓSTICOS DE SÍFILIS .................................................................................................. 133**|
|**4.5. DIAGNÓSTICO DE SÍFILIS ..................................................................................................................... 139**|
|**4.6.  TRATAMENTO DE SÍFILIS ....................................................................................................................... 137**|
|**4.7.  MONITORAMENTO PÓS-TRATAMENTO DE SÍFILIS**................................................................................................... 142|
|**4.8.  RESPOSTA IMUNOLÓGICA AO TRATAMENTO DE SÍFILIS ....................................................................... 143**|
|**4.9.  SÍFILIS: PARCERIAS SEXUAIS .................................................................................................................. 145**|  
|**4.10.  ALGORITMO DE DECISÃO CLÍNICA PARA MANEJO DA SÍFILIS ADQUIRIDA E SÍFILIS EM GESTANTES .... 146**|
|---|
|**4.11.  SÍFILIS CONGÊNITA E CRIANÇA EXPOSTA À SÍFILIS .............................................................................. 154**|
|**4.12.  AVALIAÇÃO INICIAL DA CRIANÇA EXPOSTA OU COM SÍFILIS CONGÊNITA ........................................... 155**|
|**4.13.  CRIANÇA EXPOSTA À SÍFILIS ................................................................................................................ 157**|
|**4.13.1.  EXAME FÍSICO DA CRIANÇA EXPOSTA À SÍFILIS ............................................................................ 157**|
|**4.13.2.  TESTAGEM PARA SÍFILIS NA CRIANÇA EXPOSTA À SÍFILIS ............................................................ 158**|
|**4.13.3.  SEGUIMENTO CLÍNICO-LABORATORIAL DA CRIANÇA EXPOSTA À SÍFILIS ..................................... 160**|
|**4.14.  CRIANÇA COM SÍFILIS CONGÊNITA...................................................................................................... 162**|
|**4.14.1.  EXAME FÍSICO DA CRIANÇA COM SÍFILIS CONGÊNITA .................................................................. 163**|
|**4.14.2. TESTAGEM PARA SÍFILIS E EXAMES COMPLEMENTARES PARA A CRIANÇA COM SÍFILIS CONGÊNITA**<br>**..................................................................................................................................................................... 167**|
|**4.14.3.  NEUROSSÍFILIS NA CRIANÇA COM SÍFILIS CONGÊNITA ................................................................. 169**|
|**4.14.4.  SEGUIMENTO CLÍNICO DA CRIANÇA COM SÍFILIS CONGÊNITA ...................................................... 170**|
|**4.15.  TRATAMENTO DA CRIANÇA COM SÍFILIS CONGÊNITA ......................................................................... 172**|
|**4.15.1. TRATAMENTO COM BENZILPENICILINA BENZATINA EM DOSE ÚNICA ........................................... 173**|
|**4.15.2.  TRATAMENTO COM BENZILPENICILINA POR DEZ DIAS ................................................................. 173**|
|**4.15.3.  TRATAMENTO DE SÍFILIS CONGÊNITA NO PERÍODO PÓS-NATAL .................................................. 174**|
|**4.16.   MANEJO DA CRIANÇA EXPOSTA À SÍFILIS E DA CRIANÇA COM SÍFILIS CONGÊNITA............................ 185**|
|**4.17. ATRIBUIÇÕES ESSENCIAIS DOS PONTOS DE ATENÇÃO À CRIANÇA EXPOSTA/SÍFILIS CONGÊNITA ........ 176**|
|**PARTE V – PREVENÇÃO DA TRANSMISSÃO VERTICAL DAS HEPATITES VIRAIS .............................................. 181**|
|**5.1.  HISTÓRIA NATURAL DA HEPATITE B NA GESTAÇÃO .............................................................................. 181**|
|**5.1.1.  INFECÇÃO CRÔNICA PELO HBV ........................................................................................................ 181**|
|**5.1.2.  INFECÇÃO AGUDA PELO HBV .......................................................................................................... 182**|
|**5.2.  ABORDAGEM À MULHER EM IDADE REPRODUTIVA COM HEPATITE B .................................................. 183**|
|**5.3.  ABORDAGEM DE RASTREIO E VACINAÇÃO PARA HEPATITE B NA GESTANTE ........................................ 183**|
|**5.4.  ABORDAGEM À GESTANTE VIVENDO COM HEPATITE B ........................................................................ 185**|
|<br>**ESTRATÉGIAS DE CONCEPÇÃO PARA PARCERIAS SEXUAIS SORODIFERENTES PARAHBV**............................................ 190|
|**5.5.  PREVENÇÃO DA TRANSMISSÃO VERTICAL DA HEPATITE B.................................................................... 192**|
|**5.5.1.  TRANSMISSÃO VERTICAL DO HBV .................................................................................................. 192**|
|<br>**PARTO**...................................................................................................................................................... 193|
|<br>**AMAMENTAÇÃO**......................................................................................................................................... 193|
|**5.6.  CUIDADOS AO RN EXPOSTO À HEPATITE B (MÃE HBSAG REAGENTE) ................................................... 193**|
|<br>**SEGUIMENTO DA CRIANÇA EXPOSTA AO VÍRUS DA HEPATITEB**............................................................................ 193|
|**5.7.  HEPATITE VIRAL C ................................................................................................................................. 197**|
|<br>**ESTRATÉGIAS DE CONCEPÇÃO PARA PARCERIAS SEXUAIS SORODIFERENTES PARAHCV**............................................ 202|  
**Parte I - Saúde sexual e reprodutiva da mulher no âmbito do HIV, IST e**  
###### **Hepatites Virais**  
###### **1.1. Uma abordagem centrada na mulher**  
Os serviços de saúde que se propõem a atender mulheres de forma integral precisam ter uma abordagem centrada na pessoa, levando em conta as perspectivas dessas mulheres em seu cuidado em saúde, considerando-as como participantes ativas, ofertando informações e opções para que elas possam tomar decisões fundamentadas e com autonomia. A abordagem centrada na mulher se apoia em dois princípios orientadores: a promoção dos direitos humanos e a equidade de gênero. No contexto da prevenção da TV do HIV, IST e hepatites virais, o olhar deve ser também amplo e integral sobre a mulher. Deve-se pensar na linha de cuidado não somente na gestação, mas na oferta de oportunidades ímpares de intervenção em todo seu ciclo de vida. Este capítulo aborda formas de ofertar a prevenção combinada na mulher, trazendo os conceitos de saúde sexual e reprodutiva, além de habilidades de comunicação sobre saúde sexual (1).  
A saúde sexual implica a vivência livre, responsável e segura, da sexualidade e das decisões tomadas acerca da reprodução humana. É fundamental considerar a sexualidade como um dos componentes da saúde sexual, expressa de múltiplas formas e sentidos entre as pessoas.  Logo, a abordagem sobre saúde sexual requer atenção para aspectos físicos, biológicos e subjetivos (2).  
A saúde reprodutiva implica que a pessoa possa “ter uma vida sexual segura e satisfatória, tendo autonomia para se reproduzir e a liberdade de decidir sobre quando e quantas vezes deve fazê-lo”. O sistema de saúde deve ampliar o cuidado integral para que mulheres e suas famílias tenham acesso amplo ao conhecimento sobre seus direitos sexuais e reprodutivos. Já o planejamento reprodutivo, chamado também de planejamento familiar, traz um conjunto de ações de regulação da fecundidade, as quais podem auxiliar as pessoas a prever e controlar a geração e o nascimento de filhos, e englobam adultos, jovens e adolescentes, com vida sexual, de todas as orientações sexuais, com e sem parcerias estáveis, bem como quem se prepara para iniciar sua vida sexual. As ações do planejamento reprodutivo são voltadas para o fortalecimento dos direitos sexuais e reprodutivos dos indivíduos e se baseiam em ações clínicas, preventivas, educativas, oferta de informações e dos meios, métodos e técnicas para regulação da fecundidade. Devem incluir e valorizar a participação masculina, uma vez que a responsabilidade e os riscos das práticas anticoncepcionais são predominantemente assumidos pelas mulheres.  
Para maiores informações como abordar o tema das sexualidades, consultar o PCDT de Atenção Integral às pessoas com IST; disponível em <http://www.aids.gov.br/pcdt>.  
###### **1.2. Prevenção combinada para mulheres**  
Recomenda-se a estratégia da prevenção combinada para oferta de serviços à mulher sexualmente ativa. Trata-se de diferentes intervenções conciliadas em uma estratégia conjunta, por meio da combinação das três formas de intervenções possíveis na formulação de estratégias de prevenção: biomédicas, comportamentais e estruturais (marcos legais), oferecendo o mais alto grau de possibilidades para reduzir os riscos de transmissão e de prevenção ao HIV e às outras infecções sexualmente transmissíveis. Essa conjunção de ações deve ser centrada nas pessoas, em seus grupos sociais e na sociedade em que se inserem (3).  
Dentre as principais intervenções da Prevenção Combinada do HIV, estão as abordagens para motivar o uso de preservativos masculinos e femininos e de gel lubrificante, a oferta de tratamento antirretroviral para todas as pessoas vivendo com HIV, a Profilaxia Pós-Exposição (PEP) e a Profilaxia Pré-Exposição (PrEP), o incentivo à testagem e outras intervenções biomédicas; assim como processos de apoio comportamental para a vinculação e retenção nos serviços de saúde, de redução de danos para as pessoas que usam álcool e outras drogas, estratégias de comunicação e educação entre pares e outras intervenções legais, sociais, econômicas e culturais, na dimensão estrutural.  
O símbolo da mandala (Figura 1) é representativo das diferentes intervenções e medidas de prevenção disponíveis no SUS, sendo uma delas a prevenção da transmissão vertical. Para mais informações sobre Prevenção Combinada, consultar o “Prevenção Combinada do HIV: Bases conceituais para profissionais, trabalhadores (as) e gestores (as) de saúde”, disponível em <u>http://www.aids.gov.br/biblioteca.</u>  
Figura 1 - Mandala da Prevenção Combinada do HIV  
<!-- Start of picture text -->
So oreo<br><a" SS<br>ie fee Ny<br>if f; aN<br>ial = PREVENGAO '<br>aehit Fas COMBINADA a |<br>$33 7 i<br>By,<br>Stet, $<br>45m , poche aha<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
Assim, diversas medidas de prevenção são importantes e complementares para uma prática sexual segura. Trazemos abaixo um olhar específico sobre as ações da prevenção combinada voltadas para a mulher.  
›› Oferta de preservativo masculino e feminino: as mulheres possuem especificidades, de ordem biológica, cultural e social sofrem múltiplas barreiras para a adesão ao uso de preservativos, sejam vaginais ou penianos. Entre os principais limitadores para uso do preservativo em mulheres estão: redução na percepção de prazer, compromisso e confiança na parceria, normas familiares e culturais, pouco conhecimento na transmissão de HIV, IST e hepatites virais, desigualdades de gênero. Situações de violência interferem na negociação com a parceria e, assim, estão associadas ao não uso do preservativo. A percepção de exclusividade na relação sexual também influencia o uso do preservativo,  
na medida que algumas mulheres acreditam que uso do preservativo não é apropriado em uma relação monogâmica, implicando perda de confiança e de intimidade com sua parceria. Quando se compara a preferência da mulher em uso do preservativo com o relato do uso real, há discrepâncias significantes, indicando que as mulheres geralmente não possuem poder de decisão nesse aspecto do comportamento sexual. Profissionais de saúde devem encorajar o uso de preservativo em todas as consultas. Importante que seja ofertado o preservativo feminino (ou vaginal), uma vez que é um método de barreira que pode ser escolhido pela própria mulher, associado à sua autoestima e empoderamento, tanto na promoção de sua saúde sexual quanto no planejamento reprodutivo (4–6).  
›› Imunizar para HAV, HBV e HPV: a imunização para hepatite B deve ser reforçada como principal medida na prevenção da infecção pelo vírus do HBV e, consequentemente, da TV-HBV. Reforçar a importância de atualização do esquema vacinal desde o início das consultas ginecológicas como parte de tecnologias ofertadas do contexto da saúde sexual e reprodutiva. Para mulheres vivendo com HIV/aids suscetíveis à hepatite A, recomenda-se imunização para esse agravo. Em relação ao HPV, a vacina foi incorporada ao calendário nacional de vacinação em 2013 para meninas na mesma faixa etária, de 9 a 13 anos. Em relação às PVHIV, há recomendação de vacinação para o HPV na rotina de adolescentes e pessoas vivendo com HIV de 9 a 26 anos (7).  
›› Conhecer o status sorológico da (s) parceria (s) sexual (is) para o HIV: os (as) profissionais de saúde devem entender o contexto em que vive sua usuária e estimulá-la a conversar com sua (s) parceria (s) sobre práticas sexuais e sobre a necessidade do conhecimento do status sorológico para o HIV. É importante orientá-la sobre quais os métodos preventivos estão disponíveis e quais os mais indicados para a situação de parceria sorodiferente.  
›› Testar regularmente para HIV e outras IST: é necessário que sejam desmistificados mitos e crenças em relação à testagem para HIV, IST e HV. Devem ser trabalhadas as questões relacionadas aos valores culturais, ao medo de receber os resultados, à possível baixa percepção de risco, ao estigma e à discriminação, para que haja melhor adesão à testagem e ao seguimento pós-testagem, seja resultado reagente ou não. A testagem é um instrumento fundamental na estratégia  de prevenção combinada e a recomendação é que ela deve ser ofertada a todas as mulheres com vida sexual ativa, posto que permite o início de uma trajetória de cuidados integrais, promoção de saúde e de autocuidado (8).  
O rastreamento das IST propicia a identificação de uma rede de transmissão. Quando não há a testagem da (s) parceria (s), a rede se mantém ou se amplia na comunidade.  
No PCDT de Atenção Integral às pessoas com IST, está descrita a recomendação da rotina de rastreamento de IST para cada subgrupo populacional, disponível em http://www.aids.gov.br/pcdt.  
›› Tratar todas as pessoas vivendo com HIV (PVHIV) - Tratamento como Prevenção e “I=I”. Desde 2013, o Brasil recomendou o início oportuno de TARV para todas as PVHIV com diagnóstico confirmado, independentemente da situação imunológica. O “Tratamento para Todas as Pessoas”, estratégia incorporada no Protocolo Clínico e Diretrizes Terapêuticas (PCDT) para Manejo da Infecção pelo HIV em Adultos, aproximou ainda mais prevenção e assistência, conforme as diretrizes globais da Prevenção Combinada. Pessoas vivendo com HIV com carga viral indetectável sustentada há pelo menos 6 meses e em uso de TARV não transmitem o HIV por meio de relações sexuais, ou seja, **indetectável = intransmissível (I=I)** .  
Para maiores informações, acessar o PCDT para manejo da infecção pelo HIV em adultos, disponível em http://www.aids.gov.br/pcdt.  
›› Realizar exame preventivo de câncer de colo do útero (colpocitologia oncótica): o rastreamento deve ser realizado a partir de 25 anos em todas as mulheres que iniciaram atividade sexual, com intervalos de três anos, se os dois primeiros exames anuais forem normais. Os exames devem seguir até os 64 anos de idade. Para maiores informações sobre as indicações e condução clínica dos exames preventivos para câncer de colo do útero, consultar o Protocolo da atenção básica – Saúde das Mulheres, disponível em:  
<u>http://bvsms.saude.gov.br/bvs/publicacoes/protocolos_atencao_basica_saude_mulheres.pdf.</u>  
›› Realizar Profilaxia Pré-Exposição (PrEP), quando indicado. A PrEP oferece à mulher uma opção eficaz e controlada por ela mesma para prevenção do HIV (9). A avaliação de saúde sexual dessa mulher busca observar se ela faz parte de uma população-chave e, além disso, a caracterização das práticas sexuais, das parcerias sexuais e dos contextos específicos associados a um maior risco de infecção pelo HIV. Alguns grupos específicos, denominados populações-chave, estão sob maior risco de infecção pelo HIV e têm prioridade nessa estratégia, destacando-se pessoas trans, profissionais do sexo, parcerias sorodiferentes para o HIV e gays e homens que fazem sexo com outros homens.  
Portanto, devem também ser considerados indicativos, tais como:  
- Repetição de práticas sexuais anais e/ou vaginais com penetração sem o uso de preservativo.  
- Frequência das relações sexuais com parcerias eventuais sem uso de preservativos.  
- Quantidade e diversidade de parcerias sexuais.  
- Histórico de episódios de Infecções Sexualmente Transmissíveis (IST).  
- Busca repetida por Profilaxia Pós-Exposição (PEP).  
- Contextos de troca de sexo por dinheiro, objetos de valor, drogas, moradia etc.  
Caso algum desses critérios seja preenchido, a PrEP está indicada. Ressaltar que a adesão ao uso da PrEP é um fator crítico na proteção. Além disso, o medicamento é seguro durante a gestação e amamentação. Para maiores detalhamentos sobre a PrEP, consultar o PCDT de PrEP, disponível em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
- ›› Conhecer e ter acesso à anticoncepção e concepção: para maiores informações, consultar o Protocolo da atenção básica – Saúde das Mulheres, disponível em: <u>http://bvsms.saude.gov.br/bvs/publicacoes/protocolos_atencao_basica_saude_mulheres.pdf.</u>  
›› Realizar Profilaxia Pós-Exposição (PEP), quando indicado. A Profilaxia Pós-Exposição ao HIV (PEP) é uma das estratégias de prevenção do HIV. Uma vez identificada situação de potencial exposição ao HIV, dentro das últimas 72 horas, deve-se recomendar o início imediato da PEP, de acordo com o PCDT de PEP, disponível em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
**Referências Parte I - Saúde sexual e reprodutiva da mulher no âmbito do HIV, IST e Hepatites Virais**  
1. OMS. Guia consolidada sobre saúde sexual e reprodutiva e direitos das mulheres vivendo com HIV / AIDS Resumo executivo. 2017; Available from:  
- https://apps.who.int/iris/bitstream/handle/10665/254885/9789248549991-por.pdf?ua=1  
2. Brasil. Protocolos da Atenção Básica: Saúde das Mulheres. 2016.  
3. Brasil. Prevenção Combinada do HIV/Bases conceituais para profissionais, trabalhadores (as) e gestores (as) de saúde. 2017;123.  
4. Mokgetse M, Ramukumba MM. Female condom acceptability and use amongst young women in Botswana. Curationis. 2018;41(1):1–6.  
5. Bonacquisti A, Geller PA. Condom-use intentions and the influence of partner-related barriers among women at risk for HIV. J Clin Nurs. 2013;22(23–24):3328–36.  
6. Mileti FP, Mellini L, Sulstarova B, Villani M, Singy P. Exploring barriers to consistent condom use among sub-Saharan African young immigrants in Switzerland. AIDS Care - Psychol SocioMedical Asp AIDS/HIV [Internet]. 2019;31(1):113–6. Available from: https://doi.org/10.1080/09540121.2018.1526371  
7. Brasil M da S. Procolo Clínico e Diretrizes Terapeuticas para Atenção às Pessoas com Infecções Sexualmente Transmissíveis (IST). 2019;(0014125063):1–250.  
8. Cianelli R, Villegas N, Irarrazabal L, Castro J, Ojukwu EN, Adebayo OW, et al. HIV Testing  
Among Heterosexual Hispanic Women in South Florida. J Nurs Scholarsh. 2019;000:1–11.  
9. Hodges-Mameletzis I, Fonner VA, Dalal S, Mugo N, Msimanga-Radebe B, Baggaley R. PreExposure Prophylaxis for HIV Prevention in Women: Current Status and Future Directions. Drugs [Internet]. 2019;(0123456789). Available from:  
http://link.springer.com/10.1007/s40265-019-01143-8  
**Parte II - Infecções Sexualmente Transmissíveis e Transmissão Vertical**  
###### **2.1. Testagem para prevenção da transmissão vertical**  
Os testes que devem ser realizados pela gestante para prevenir a transmissão vertical de infecções e outros agravos estão detalhados a seguir:  
- **Sífilis** : na primeira consulta do pré-natal (idealmente, no primeiro trimestre da gestação), no início do terceiro trimestre (28ª semana) e no momento do parto ou aborto, independentemente de exames anteriores.  
- **Hepatite B** : na primeira consulta do pré-natal (idealmente, no primeiro trimestre). Se o resultado for não reagente e não houver história de vacinação prévia, recomenda-se a vacinação. Caso a gestante apresente-se no momento do parto sem ter realizado todas as doses da vacina, deve-se proceder à testagem dessa gestante para hepatite B na maternidade.  
- **HIV** : na primeira consulta do pré-natal (idealmente, no primeiro trimestre da gestação), no início do terceiro trimestre e no momento do parto, independentemente de exames anteriores.  
- **Hepatite C** : na primeira consulta do pré-natal (idealmente, no primeiro trimestre da gestação).  
- **Gonorreia e infecção por clamídia** : na primeira consulta do pré-natal em gestantes com idade menor ou igual a 30 anos, quando disponível.  
- **Vaginose bacteriana:** na primeira consulta do pré-natal em mulheres com alto risco de trabalho de parto pré-termo.  
- **Estreptococo do grupo B** : da 35ª à 37ª semana gestacional, realizar coleta de amostra por swab vaginal e endoanal, quando disponível.  
Além disso, a testagem para IST deve ser realizada em qualquer momento de exposição de risco e/ou violência sexual.  
###### **Quadro 1 – Oferta de testagem combinada de HIV, sífilis e hepatites B e C à gestante**  
###### Testagem para HIV  
###### Testagem para sífilis  
###### Testagem para Testagem para hepatite B hepatite C  
- **Teste rápido ou laboratorial de HIV (se resultado até 14 dias):**  
- •1ª consulta prénatal, idealmente no 1º trimestre da gestação  
- •3º trimestre da gestação  
- •Parto •História de exposição de risco/violência sexual  
- **Teste rápido ou treponêmico laboratorial de sífilis (se resultado até 14 dias):**  
- •1ª consulta prénatal, idealmente no 1º trimestre da gestação  
- •3º trimestre da gestação  
- •Parto/aborto  
- •História de exposição de risco/violência sexual  
- **Testes não treponêmicos quantitativos:** •Seguimento do tratamento de sífilis  
- **Teste rápido ou laboratorial de hepatite B (se resultado até 14 dias):**  
- •HBsAg na rotina da 1ª consulta prénatal, idealmente no 1º trimestre da gestação  
- •Histórico de vacinação  
•Parto (caso gestante não tenha recebido todas as doses da vacina contra hepatite B) •História de exposição de risco/violência sexual  
- **Teste rápido ou laboratorial de hepatite C (se resultado até 14 dias):**  
- •Anti-HCV na rotina da 1ª consulta prénatal, idealmente no 1º trimestre da gestação  
- •História de exposição de risco/violência sexual  
###### Fonte: DCCI/SVS/MS.  
Para mais informações sobre testagem, devem ser consultados o “Protocolo Clínico e Diretrizes Terapêuticas para atenção integral às pessoas com Infecções Sexualmente Transmissíveis”, o “Manual Técnico para Diagnóstico da Infecção pelo HIV”, o “Manual Técnico para Diagnóstico da Sífilis” e o  
“Manual Técnico para Diagnóstico das Hepatites Virais”, disponíveis em <u>http://www.aids.gov.br/biblioteca.</u>  
###### **2.2. Manejo das IST na gestante e parceria**  
A medida mais efetiva para a prevenção de IST no recém-nascido é o diagnóstico e tratamento da gestante e de sua parceria.  
Em destaque, vale ressaltar a infecção pelos Herpes Simplex Virus tipos 1 e 2, normalmente causadoras de úlceras genitais. As gestantes portadoras de herpes simples apresentam risco acrescido de complicações fetais e neonatais, sobretudo quando a infecção ocorre no final da gestação. O maior risco de transmissão do vírus acontece no momento da passagem do feto pelo canal de parto. Recomenda-se a realização de cesariana sempre que houver lesões herpéticas ativas no canal de parto (1,2).  
Em relação à reativação do Vírus Varicela Zoster (VVZ) causando quadros de herpes zoster, recomendase a suspensão da amamentação caso haja lesões que acometam a mama e possam ter contato direto com o lactente. Visto que a eliminação do VVZ pelo leite materno é muito baixa, não há indicação de suspender a amamentação (3,4).  
Para mais informações sobre o diagnóstico e manejo adequado das IST, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Atenção Integral às Pessoas com Infecções Sexualmente Transmissíveis”, disponível em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
###### **2.3. Manejo do RN para profilaxia de gonorreia**  
O antibiótico profilático ocular reduz o risco de conjuntivite gonocócica (5); no entanto, não é uma medida efetiva para prevenção de conjuntivite por _Chlamydia trachomatis_ .  
No RN, o gonococo pode acarretar, além da conjuntivite, artrite, sepse, abscesso em couro cabeludo, pneumonia, meningite, endocardite e estomatite.  
A profilaxia para o RN com colírio contendo antibiótico pode ser realizada até uma hora após o nascimento, permitindo à criança o contato com a família o mais rapidamente possível.  
###### **2.4. HTLV**  
Os vírus HTLV 1 e 2 pertencem à família _Retroviridae_ , sendo que a infecção não implica, necessariamente, o desenvolvimento de processos patogênicos. As vias de transmissão são a sexual, a parenteral e a vertical (gestação, parto ou aleitamento materno, principalmente) (6–8).  
O HTLV está associado a doenças neurológicas, oftalmológicas e dermatológicas, assim como à leucemia/linfoma (6). Das pessoas infectadas pelo HTLV, aproximadamente 90% permanecerão assintomáticas ao longo de suas vidas. Essas pessoas mantêm uma rede de transmissão silenciosa pela via sexual, sanguínea e vertical.  
O aleitamento materno é a principal via de transmissão vertical, ocorrendo em 20% a 30% dos lactentes amamentados por mães infectadas. O risco está associado a variáveis individuais, a exemplo do tempo de amamentação. A transmissão intrauterina ou no período periparto ocorre em menos de 5% dos casos (9,10).  
As recomendações para PTV do HTLV são:  
- uso de preservativo em todas as relações sexuais;  
- oferta de redução de danos para pessoas que usam drogas injetáveis; e  
- **contraindicação à amamentação em mães vivendo com HTLV 1/2** , sendo recomendado o uso de inibidores de lactação e de fórmulas lácteas infantis (6,9).  
###### **2.5. Vírus Zika**  
O vírus Zika é um Flavivírus capaz de causar infecção em humanos; o primeiro caso diagnosticado no Brasil ocorreu no ano de 2015, na Região Nordeste. A maioria das pessoas infectadas apresentará a **forma assintomática** . Em **pessoas sintomáticas,** os principais sinais e sintomas são _rash_ cutâneo, febre, conjuntivite, cefaleia, dores articulares e mialgia (11).  
As anomalias congênitas associadas à infecção pelo vírus Zika foram observadas logo após a entrada do vírus no território nacional. Em 2019, foi publicada uma atualização pela OMS reunindo maior quantidade de evidências a respeito da transmissão sexual do vírus Zika e, consequentemente, os riscos de anomalias congênitas. Nos Estados Unidos da América, 6% dos recém-nascidos (RN) de mulheres sintomáticas a assintomáticas para Zika apresentam anomalias congênitas, enquanto, no Brasil, 42% dos RN de mulheres que apresentaram exantema tiveram anomalias.  
A **microcefalia** foi o acometimento mais frequente do SNC e desencadeou situação de alerta no Brasil naquele momento, por ter sido considerado uma Situação de Emergência em Saúde Pública de Importância Nacional (12,13). O vírus pode ser transmitido por meio da picada do vetor _Aedes aegypti_  
(o mesmo que transmite dengue, Chikungunya e febre amarela) e é o principal modo de transmissão em regiões endêmicas para o vírus. Entretanto, as transmissões vertical e a sexual são descritas.  
A principal medida de combate à infecção é a prevenção, com medidas de controle do vetor e medidas protetivas individuais (uso de repelentes e de roupas <mark>com mangas longas e calças compridas)</mark> , de modo a diminuir chance de picada pelo mosquito. Ainda não há vacinas para prevenir a infecção pelo vírus Zika e nem tratamento específico. A **transmissão sexual do vírus Zika** foi comprovada por inúmeros relatos de casos, sendo a Zika considerada uma IST, cuja transmissão sexual pode ser evitada por meio do **uso de preservativo** (12).  
O uso do preservativo, ao prevenir a transmissão sexual de Zika evita infecção aguda e complicações neurológicas na parceria sexual, evita infecção de gestantes e, consequentemente, infecção congênita por Zika.  
Deve ser reforçada a importância do uso do preservativo, especialmente após viagens a áreas endêmicas ou suspeita e/ou confirmação do diagnóstico da infecção pela parceria sexual. Isso porque a persistência das partículas virais foi observada em fluidos corporais, como sêmen (12).  
**Para casais que desejam a concepção, recomenda-se** :  
- aguardar até **3 meses** após sinais/sintomas relacionados à infecção pelo vírus Zika quando o **homem** foi infectado;  
- aguardar até **2 meses** após sinais/sintomas relacionados à infecção pelo vírus Zika quando a **mulher** foi infectada.  
Em áreas endêmicas, casais que desejam a concepção, devem ser orientados quanto aos riscos da infecção pelo vírus Zika e a possibilidade de malformações fetais. **Para áreas endêmicas, a recomendação para uso contínuo do preservativo durante toda a gestação deve fazer parte do aconselhamento durante as consultas de pré-natal** . Até o presente momento, não há casos de transmissão por meio da reprodução assistida, mas recomenda-se que os prazos acima citados sejam considerados nos tratamentos de fertilidade (12).  
O diagnóstico precoce da infecção pelo vírus Zika na gestante, por meio de exames de detecção do RNA viral mediante PCR e/ou sorologias, auxilia no rastreamento das gestações de alto risco. Os exames sorológicos não são recomendados para diagnóstico da infecção aguda e não há  
recomendação de triagem rotineira no pré-natal. Esses exames também são utilizados no seguimento especializado para a criança que tenha nascido com alguma anomalia congênita.  
###### **REFERÊNCIAS Parte II - Infecções Sexualmente Transmissíveis e Transmissão Vertical**  
1. Brasil. Manual Técnico de Gestação de Alto Risco [Internet]. Gestação de Alto Risco Manual Técnico. 2010. 302 p. Available from:  
http://bvsms.saude.gov.br/bvs/publicacoes/gestacao_alto_risco.pdf  
2. Brasil M da S. Procolo Clínico e Diretrizes Terapeuticas para Atenção às Pessoas com Infecções Sexualmente Transmissíveis (IST). 2019;(0014125063):1–250.  
3. Garcia-Loygorri MC, Deluis D, Torreblanca B, March GA, Bachiller MR, Eiros JM. La leche materna como vehículo de transmisión de virus. Nutr Hosp. 2015;32(1):4–10.  
4. Lamounier JA, Moulin ZS, Xavier CC. Recommendations for breastfeeding during maternal infections. J Pediatr (Rio J). 2004;80(5 SUPPL. 5):181–8.  
5. Laga M. Epidemiology and control of gonococcal ophthalmia neonatorum. 1989;67(5):471–7.  
6. Gonçalves DU, Proietti FA, Ribas JGR, Araújo MG, Pinheiro SR, Guedes AC, et al. Epidemiology, treatment, and prevention of human T-cell leukemia virus type 1-associated diseases. Clin Microbiol Rev. 2010;23(3):577–89.  
7. Gessain A, Cassar O. Epidemiological aspects and world distribution of HTLV-1 infection. Front Microbiol. 2012;3(NOV):1–23.  
8. Carneiro-Proietti ABF, Catalan-Soares BC, Castro-Costa CM, Murphy EL, Sabino EC, Hisada M, et al. HTLV in the Americas: Challenges and perspectives. Rev Panam Salud Publica/Pan Am J Public Heal. 2006;19(1):44–53.  
9. Rosadas C, Taylor GP. Mother-to-child HTLV-1 transmission: Unmet research needs. Front Microbiol. 2019;10(MAY):1–18.  
10. Rosadas C, Malik B, Taylor GP, Puccioni-Sohler M. Estimation of HTLV-1 vertical transmission cases in Brazil per annum. PLoS Negl Trop Dis. 2018;12(11):1–14.  
11. Musso D, Ko AI, Baud D. Zika Virus Infection — After the Pandemic. N Engl J Med. 2019;381(15):1444–57.  
12. OMS. WHO | WHO guidelines for the prevention of sexual transmission of Zika virus. Who. 2019;1–6.  
13. Brasil. Plano Nacional de Enfrentamento à microcefalia - Protocolo de vigilância e resposta à  
ocorrência de microcefalia relacionada à infecção pelo vírus Zika. Ministério da Saúde [Internet]. 2015; Available from:  
http://portalsaude.saude.gov.br/images/pdf/2015/dezembro/09/Microcefalia---Protocolode-vigil--ncia-e-resposta---vers--o-1----09dez2015-8h.pdf  
**Parte III – Prevenção da Transmissão Vertical do HIV**  
###### **3.1. Pessoas vivendo com HIV e Direitos reprodutivos**  
O acesso universal ao tratamento e a maior prevalência do HIV na população jovem, sexualmente ativa e em idade reprodutiva, convergem para a necessidade de que as questões relacionadas à saúde sexual e planejamento reprodutivo sejam abordadas na linha de cuidado às PVHIV. O direito a decidir sobre ter ou não filhos está assegurado pelo Código de Ética Médica, no seu artigo 42, que diz: “é vedado ao médico desrespeitar o direito do paciente de decidir livremente sobre o método contraceptivo ou conceptivo, devendo o médico sempre explicar sobre a indicação, a segurança, a reversibilidade e o risco de cada método” (1,2).  
Deve-se considerar a abordagem da vivência sexual em sua plenitude na linha de cuidado integral às PVHIV e suas parcerias sexuais. Nesse contexto, faz-se necessário, por exemplo, identificar as práticas sexuais de risco, infertilidade e planejamento reprodutivo. O desejo de ter filhos deve ser discutido nos atendimentos, visando a proporcionar às pessoas informações sobre as formas mais seguras de concepção e sobre os cuidados necessários durante a gestação, o parto e o puerpério, além de reforçar que o planejamento reprodutivo é um direito, assegurando a livre decisão da pessoa sobre ter ou não ter filhos (3).  
Para isso, é importante, ainda, que os serviços de saúde ofereçam às parcerias sexuais suporte à testagem e à revelação mútua, tanto a pessoas com estado sorológico conhecido como desconhecido em relação ao HIV (3,4).  
Para que os direitos à saúde sexual e reprodutiva das PVHIV possam ser exercidos, é importante que se garantam condições livres de violência, coerção, discriminação ou qualquer outra restrição. É imprescindível assegurar a autonomia dos sujeitos com relação às suas práticas sexuais e decisão reprodutiva.  
###### **3.2. Pessoas vivendo com HIV e Planejamento sexual e reprodutivo**  
Para promover e proteger o direito à saúde sexual e planejamento reprodutivo das PVHIV, os serviços de saúde devem se adequar às necessidades e especificidades de seus usuários ao longo dos seus ciclos de vida.  
A escuta ativa e a promoção de um ambiente favorável ao diálogo sobre as práticas sexuais das pessoas e suas perspectivas reprodutivas devem estar presentes em todas as oportunidades de contato, em qualquer acesso aos serviços de saúde. Essa abordagem possibilita o vínculo e facilita a adesão às tecnologias disponíveis, que devem sempre ser oferecidas pelos profissionais.  
Isso implica uma nova abordagem do cuidado – não mais a oferta exclusiva do preservativo masculino, mas a ampliação da perspectiva para a prevenção combinada, concepção e contracepção, além de PrEP e PEP para o HIV, quando indicado.  
As atividades dos profissionais de saúde na assistência ao planejamento reprodutivo devem ser, preferencialmente, multidisciplinares e integradas, envolvendo atividades educativas, orientações, oferta de insumos e tecnologias de concepção e contracepção, além da articulação com outros serviços da rede de saúde. A equipe deve estar atenta ao despertar da sexualidade no trabalho com crianças e adolescentes que vivem com HIV, orientando-os sobre uma vida sexual saudável.  
Existem alguns princípios que devem nortear o modelo e a oferta dos serviços relacionados à fertilidade para pessoas em parcerias sorodiferentes. No que diz respeito às orientações, os profissionais de saúde devem dar suporte à tomada de decisões conscientes e voluntárias sobre as escolhas reprodutivas. Recomenda-se um enfoque às questões relacionadas ao estigma e discriminação que PVHIV e suas parcerias podem sofrer durante o período de concepção, gestação e no pós-parto, no que se remete ao risco de transmissão sexual e vertical do HIV, aos cuidados no puerpério, em especial da alimentação do recém-nascido e da inibição da lactação.  
###### **3.3. Adolescência em pessoas vivendo com HIV**  
A adolescência caracteriza-se por ser um período de notáveis transformações físicas, psíquicas, sexuais e sociais, constituindo a etapa de transição entre a infância e a vida adulta.  
A garantia dos direitos do adolescente nos serviços de saúde, independentemente da participação dos seus responsáveis, tem se revelado como elemento indispensável à melhora da qualidade da promoção, prevenção e assistência à sua saúde. O acesso a serviços, orientações e consultas de saúde deve ser garantido sem a necessidade de presença ou autorização de pais ou responsáveis, com direito à privacidade e sigilo de opiniões e condutas, salvo em situações de necessidade de internação ou de risco de vida (Estatuto da Criança e do Adolescente).  
Especialmente no trabalho com adolescentes vivendo com HIV, é comum observar uma tendência de pais/responsáveis e equipe de saúde a não abordar os aspectos determinantes da saúde sexual, como a negação do desejo sexual do jovem e o incentivo ao prolongamento da infância. No entanto, é essencial explicar que a prática sexual faz parte dessa fase da vida, e que ela pode ser desejada e vivenciada sem culpas, mas com informação, comunicação e exercício do livre arbítrio.  
Esse espaço de troca sobre saúde sexual e planejamento reprodutivo deve ser iniciado tão logo seja detectada a maturidade sexual, ou quando surjam perguntas sobre o assunto, devendo ser elaborado de forma gradual, ao longo dos diversos encontros no cuidado integral ao adolescente vivendo com HIV.  
De acordo com cada fase da vida e com a identificação dos riscos e práticas sexuais, podem ser oferecidas diferentes tecnologias associadas à prevenção combinada das IST/HIV/hepatites virais.  
Para maiores informações, acessar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes”, disponível em http://www.aids.gov.br/pcdt.  
###### **3.4. Orientações sobre saúde sexual de Pessoas vivendo com HIV**  
É fundamental que a abordagem considere as informações que a PVHIV e suas parcerias sexuais já possuam a respeito da concepção e anticoncepção, respeitando as particularidades e vulnerabilidades de cada contexto clínico e biopsicossocial (Quadro 2). Toda PVHIV deve ser orientada sobre os riscos de transmissão sexual e vertical do HIV.  
Cada processo de abordagem deve ser registrado em prontuário, com a descrição das orientações, pactuações e acordos entre as parcerias sexuais e a equipe de saúde.  
**Quadro 2 – Orientações quanto à saúde sexual de parcerias sexuais sorodiferentes**  
###### **Para as parcerias sexuais sem HIV:**  
- realizar orientação e avaliação da saúde sexual e reprodutiva continuamente;  
- investigar o desejo reprodutivo;  
testar parceria sorodiferente para o HIV;  
- realizar rastreio de sífilis e outras IST, mesmo assintomáticas;  
- orientar sobre a importância da re-testagem, sempre que houver situação de exposição de risco ou violência sexual;  
- atualizar situação vacinal;  
- atualizar exame colpocitológico; e  
- avaliar indicação de PrEP e PEP para o HIV.  
###### **Para as PVHIV:**  
- garantir que estejam em tratamento regular, com boa adesão à TARV, assintomáticas e sem IO;  
- atualizar situação vacinal;  
- assegurar que tenham pelo menos duas CV-HIV indetectáveis consecutivas, sendo a última com até seis meses de realização;  
- garantir que tenham exames negativos para sífilis e outras IST, mesmo assintomáticas; e  
- adequar medicações de potencial teratogênico, quando for o caso.  
###### **Para parcerias que optem pela contracepção:**  
- orientar sobre risco de transmissão de HIV e outras IST;  
- orientar sobre medidas de prevenção combinada (incluindo PrEP e PEP);  
- orientar sobre todas as possibilidades de métodos de contracepção disponíveis; e  
- oferecer testagem para HIV, sífilis e outras IST sempre que houver exposição de risco ou situação de violência sexual.  
###### **Para parcerias que optem pela concepção:**  
- orientar sobre os riscos de transmissão vertical e horizontal do HIV e as estratégias de redução do risco;  
- avaliar fertilidade das parcerias sexuais, idade e período fértil da mulher;  
- orientar sobre técnicas de identificação do período fértil da mulher;  
- se a mulher não engravidar após seis a doze meses de tentativas de concepção (a depender da idade e de outros fatores de subfertilidade), ampliar a investigação de fertilidade, de acordo com o serviço de referência; e  
- orientar sobre a técnica mais adequada de concepção, de acordo com o cenário das parcerias sexuais.  
Fonte: DCCI/SVS/MS.  
###### **3.5. Planejamento reprodutivo para concepção em Pessoas Vivendo e Convivendo com HIV**  
As orientações devem promover reflexões sobre as motivações do projeto parental, as expectativas da pessoa e/ou casal, o investimento emocional e financeiro e o histórico de saúde sexual e reprodutiva da PVHIV e sua (s) parceria(s) sexual (is).  
A equipe de saúde deve estar preparada para abordar os sucessos e insucessos dessa trajetória, devendo ser avaliadas as condições de enfrentamento às situações de risco de transmissão do HIV. A equipe também deve estar disponível para discutir sobre não ter filhos e a possibilidade de adoção.  
As tentativas de concepção sem orientação e acolhimento pela equipe de saúde, realizadas sem planejamento conjunto, expõem as parcerias sexuais negativas para o HIV a um maior risco de infecção pelo HIV, além de aumentarem o risco de transmissão vertical  (5).  
###### **3.5.1. Prevenção da transmissão sexual e vertical do HIV**  
Em gestações planejadas, com intervenções realizadas adequadamente durante o pré-natal, o parto e a amamentação, o risco de transmissão vertical do HIV é reduzido a menos de 2%. No entanto, sem o adequado planejamento e seguimento, está bem estabelecido que esse risco é de 15% a 45% (6,7).  
É fundamental que as parcerias sexuais possam tomar decisões conscientes sobre os benefícios e riscos relacionados às opções de concepção mais seguras, de acordo com suas características individuais (8).  
A boa adesão à TARV e a manutenção da CV-HIV indetectável reduzem o risco de transmissão sexual do HIV a níveis insignificantes, tornando o tratamento uma opção segura de prevenção da transmissão sexual para os casais sorodiferentes. Essa medida é especialmente efetiva entre as parcerias sexuais heterossexuais (Attia et al., 2009; Donnell et al., 2010; Mmeje, Cohen e Cohan, 2012; Cohen et al., 2017; Patel et al., 2015; Rodger et al., 2016; Saleem et al., 2017; Savasi et al., 2013).  
Evidências científicas recentes corroboram a afirmação de que PVHIV em TARV e com carga viral indetectável há pelo menos seis meses não transmitem o vírus HIV por via sexual.  
Ressalta-se também que o uso adequado de PrEP é uma medida eficaz para prevenção da transmissão de HIV entre casais sorodiferentes (8,17).  
Para a oferta ou não de PrEP como mais uma ferramenta para os casais sorodiferentes, deve-se considerar a supressão da CV-HIV e o perfil da PVHIV quanto à adesão à TARV e ausência de outras IST, além da realização de práticas sexuais de risco.  
- O principal é valorizar e reforçar a **autonomia da parceria soronegativa** quanto à sua prática sexual e o grau de exposição a que deseja se submeter, considerando que esta não é responsável pelas condutas da outra pessoa, por exemplo, no que se refere à tomada regular da TARV.  
Se indicada PrEP para a parceria que não vive com HIV antes do período fértil, o tempo para início da proteção com o uso de PrEP a partir da tomada da primeira dose depende da via sexual. Para a relação vaginal, são necessários pelo menos 20 dias. No entanto, o início da PrEP conjuntamente com o primeiro dia da menstruação garante proteção máxima, quando são levadas em consideração a farmacocinética e o comportamento humano durante o período fértil (8,17).  
###### **3.5.2. Continuidade da PrEP para a mulher gestante e no puerpério**  
Há segurança para manter a PrEP durante a gestação. Deve-se avaliar a continuidade da PrEP com a mulher já gestante e/ou orientar a retomada do uso do preservativo assim que a gravidez for confirmada, de acordo com as escolha da mulher e sua parceria sexual, uma vez que a gestação está associada a um risco aumentado de aquisição do HIV (Matthews, 2012; Mofenson, 2017).  
Do mesmo modo, o puerpério exige atenção especial, portanto, deve-se discutir continuidade de PrEP, reforçar o uso regular de preservativo masculino ou feminino e ofertar testagem para HIV e outras IST durante o aleitamento. Há alto risco TV-HIV por aleitamento nos casos de infecção aguda pelo HIV durante o período de amamentação (19,20).  
Para mais informações sobre PrEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pré-Exposição (PrEP) de Risco à Infecção pelo HIV”, disponível em <http://www.aids.gov.br/pcdt> e <conitec.gov.br>.  
###### **3.5.3. Orientações gerais para o planejamento reprodutivo**  
Como medidas gerais para o planejamento preconcepcional, reforçar as seguintes medidas:  
- Manter hábitos de vida e dieta saudáveis.  
- Cessar tabagismo, uso de álcool e outras drogas.  
- Testagem e tratamento para sífilis e outras IST.  
- Vincular o parceiro no pré-natal.  
- Mulheres com intenção de engravidar devem suplementar ácido fólico 3 meses antes da concepção e manter até 3 meses de gravidez.  
- Reavaliar todas as medicações em uso pela MVHIV, incluindo medicações fitoterápicas, para garantir que não haja nenhum medicamento com potencial teratogênico no período de concepção, incluindo o seu esquema de TARV.  
###### **3.5.3.1. Determinação do período fértil da mulher**  
Para determinar o período fértil, deve-se conhecer o conceito de ciclo regular, que consiste em uma diferença inferior a 10 dias entre ciclo menstrual mais longo e o ciclo menstrual mais curto (21). Por exemplo: o ciclo mais longo é de 32 dias e o mais curto é de 28 dias, portanto, a diferença seria de 4 dias, sendo considerados ciclos regulares. Outro exemplo seria no caso de uma mulher cujo ciclo mais longo ser de 38 dias e o mais curto ser de 27 dias, então, a diferença seria de 11 dias. Isso significa que esta mulher deve ser investigada para anovulação crônica (22).  
O período fértil é aquele que ocorre durante os cinco dias que antecedem a ovulação até o dia da ovulação (duração de 6 dias). O primeiro dia do ciclo é o dia que a menstruação ocorre. Para descobrir a provável data ovulação, deve-se subtrair 14 dias da duração do ciclo menstrual, já que a primeira fase do ciclo é variável e a segunda fase tem duração fixa de 14 dias. Por exemplo: em um ciclo de 30 dias, a ovulação tende a ocorrer no 16º dia do ciclo; já em um ciclo de 28 dias, a ovulação deve ocorrer no 14º dia do ciclo. Assim, em um ciclo de 28 dias, o período fértil seria do 9º dia ao 14<sup>o</sup> do ciclo menstrual. Já em ciclo de 30 dias, o período fértil seria do 11º dia ao 16<sup>o</sup> do ciclo menstrual.  
**3.5.3.2. Estratégias de concepção para parcerias sexuais sorodiferentes para HIV**  
Com base no que foi apresentado, a recomendação é que a PVHIV esteja em uso de TARV com boa adesão e apresente CV-HIV indetectável, por no mínimo 6 meses para, então, indicar relação sexual sem preservativo masculino ou feminino como primeira opção para concepção.  
###### **Situação 1: MULHER VIVENDO COM HIV e parceria sexual HOMEM NEGATIVO para o HIV**  
Caso a mulher vivendo com HIV esteja em uso de TARV com boa adesão e apresente CV-HIV indetectável, por no mínimo 6 meses, recomenda-se relação sexual sem preservativo masculino ou feminino como **primeira opção para concepção** . (8,14).  
A relação sexual pode ser a cada 1 a 2 dias ou só no período fértil. Caso não haja fatores que reduzam a fertilidade e a idade da mulher seja inferior a 35 anos, orienta-se a tentativa por até 12 meses. Caso a idade da mulher seja superior a 35 anos, o tempo de tentativa deve ser limitado a 6 meses. Após este período, referenciar o casal para a investigação de infertilidade (17,23).  
Outra opção seria a autoinseminação vaginal programada. Trata-se de procedimento simples, programado para o período fértil da mulher, de fácil realização, barato e sem necessidade de tecnologias de alto custo. Elimina a necessidade de relações sexuais sem o uso do preservativo masculino ou feminino, com redução de 100% do risco de transmissão do HIV (11,17).  
O método deve ser realizado da seguinte maneira:  
1. Em um dia fértil do ciclo menstrual, utilizar preservativo feminino ou masculino sem espermicida durante a relação sexual. O sêmen pode ser colhido diretamente do preservativo ou, se a pessoa preferir, coletado em um copo limpo após a ejaculação.  
2. Utilizar uma seringa de plástico sem agulha para coletar o sêmen.  
3. Introduzir na vagina, no ponto mais alto (profundo) possível, a seringa plástica (sem agulha) com o sêmen coletado, de preferência, imediatamente após a ejaculação.  
4. A mulher deve permanecer deitada por pelo menos 30 minutos após a injeção.  
5. Os passos 1 a 4 podem ser repetidos a cada dois dias durante o período fértil.  
**Situação 2: HOMEM VIVENDO COM HIV e parceria sexual MULHER NEGATIVA para o HIV**  
Caso o homem vivendo com HIV esteja em uso de TARV com boa adesão e apresente CV-HIV indetectável, por no mínimo 6 meses, recomenda-se relação sexual sem preservativo masculino ou feminino como **primeira opção para concepção** . (8,14).  
A relação sexual pode ser a cada 1 a 2 dias ou só no período fértil. Caso não haja fatores que reduzam a fertilidade e a idade da mulher seja inferior a 35 anos, orienta-se a tentativa por até 12 meses. Caso a idade da mulher seja superior a 35 anos, o tempo de tentativa deve ser limitado a 6 meses. Após este período, referenciar o casal para a investigação de infertilidade (17,23).  
###### **3.5.3.3. Estratégias para parcerias sexuais soroiguais**  
Os casais soroiguais em TARV com boa adesão, ambos com CV-HIV indetectável, assintomáticos, com pesquisa de IST negativa, podem realizar a concepção natural planejada (8,17).  
A relação sexual pode ser a cada 1 a 2 dias ou só no período fértil. Caso não haja fatores que reduzam a fertilidade e a idade da mulher seja inferior a 35 anos, orienta-se a tentativa por até 12 meses. Caso a idade da mulher seja superior a 35 anos, o tempo de tentativa deve ser limitado a 6 meses. Após este período, referenciar o casal para a investigação de infertilidade (17,23).  
###### **3.6. Pré-natal do parceiro**  
Historicamente, tanto o planejamento reprodutivo quanto as ações em saúde voltadas ao momento da gestação, parto e puerpério foram pensadas e direcionadas às mulheres e às gestantes, enfocando o binômio mãe-criança. Como estratégia para contextualizar a importância do envolvimento consciente e ativo de homens adolescentes, jovens adultos e idosos em todas as ações voltadas ao planejamento reprodutivo e, ao mesmo tempo, contribuir para a ampliação e a melhoria do acesso e acolhimento desta população aos serviços de saúde, com enfoque na Atenção Básica foi instituído o Guia do Pré-Natal do Parceiro para profissionais de saúde (24).  
O Pré-Natal do Parceiro propõe-se a ampliar o acesso e o acolhimento dos homens aos serviços e programas de saúde e qualificar as práticas de cuidado com sua saúde de maneira geral no âmbito do SUS.  
Recomenda-se ofertar na primeira consulta do homem testagem para HIV, sífilis, hepatite B e hepatite C e vacinar o pai/parceiro conforme a situação vacinal encontrada (24).  
Deve-se enfatizar o papel da parceria como importante fator de adesão ao tratamento e redução na transmissão vertical (25).  
Para maiores informações sobre o pré-natal do parceiro, consultar <u>https://portalarquivos2.saude.gov.br/images/pdf/2016/agosto/11/guia_PreNatal.pdf.</u>  
###### **3.7. Planejamento reprodutivo na contracepção em Pessoas Vivendo com HIV**  
Apesar dos avanços nos métodos contraceptivos, a gravidez não planejada ainda é uma questão de enfrentamento mundial, especialmente entre as populações com menos acesso à educação e aos serviços de saúde  (26,27). No Brasil, 55,4% das gestações não são planejadas (28). Já em determinadas situações, como em mulheres portadoras de doenças crônicas, MVHIV, ou situação de vulnerabilidade, observam-se taxas ainda mais elevadas de gestações não planejadas (29).  
As gestações não planejadas estão associadas ao aumento de desfechos negativos para saúde materna, neonatal e infantil, como baixo peso ao nascer, prematuridade, risco aumentado de sofrer violência física, início tardio de pré-natal, depressão pós-parto, mortalidade neonatal e infantil, entre outros (30–33).  
O acesso à informação e acolhimento no serviço permitem um ambiente para escolhas mais seguras e adequadas ao perfil de cada um, aumenta a adesão ao método escolhido e constitui uma das estratégias de prevenção de gestações não planejadas (4).  
A seleção adequada e o acesso aos métodos contraceptivos reduzem os riscos à saúde e contribuem para a prevenção de abortos clandestinos e diminuição de sobrecarga física, emocional e econômica (Singh, 2012; WHO, 2015).  
###### **3.7.1. Orientações quanto à contraconcepção**  
Nenhum método é isento de falhas e o uso correto minimiza o risco de falhas. Cada contraceptivo possui uma taxa de falha inerente ao método (uso perfeito do método) e uma associada à forma como é utilizado na vida real (uso típico do método) (Tabela 1). Quanto mais dependente da usuária for o método para manter sua eficácia, maior será a diferença das taxas de falha entre ambas as formas de utilização (34,35).  
Os métodos que independem da usuária para manter sua eficácia são representados pelos métodos cirúrgicos e pelos métodos contraceptivos reversíveis de longa ação (LARCs, sigla em inglês, de _longacting reversible contraceptives_ ), ou seja, aqueles que proporcionam efeito contraceptivo por três ou mais anos (dispositivo intrauterino de cobre, dispositivo intrauterino liberador de levonorgestrel e implante contraceptivo). Desse modo, é possível entender que tais alternativas podem ser mais adequadas para usuárias com baixa adesão a métodos que dependem de lembrança diária ou ação frequente, especialmente em populações de maior risco, como adolescentes e usuárias de drogas.  
Tabela 1 – Percentual de mulheres que apresentam falha do método contraceptivo no primeiro ano de uso (típico ou perfeito) e taxa de continuidade ao final do primeiro ano de uso.  
|||**Taxa de falha d**<br>**100 mulheres e**|**o método (%) em**<br>**m 1 ano de uso**||
|---|---|---|---|---|
|**Método**||**Uso típico**|**Uso perfeito**|**Taxa de continuidade do**<br>**método (%) após 1 ano**|
|**Nenhum**||85|85|n/a|
|**Espermicida**||28|18|42|
|**Coito interrompido**||22|4|46|
|**Métodos**||24|3-5|47|
|**Comportamentais**|||||
|**Diafragma**||12|6|57|
|**Preservativo**|||||
|Feminino||21|5|41|
|Masculino||18|2|43|
|**Pílulas**(combinada|ou||||
|apenas|de|9|0,3|67|
|progestagênio)|||||  
|**Adesivo/anel**|9|0,3|67|
|---|---|---|---|
|**Injetáveis**|6|0,2|56|
|**DIU**||||
|Cobre|0,8|0,6|78|
|Levonorgestrel|0,2|0,2|80|
|**Implante de ENG**|0,05|0,05|84|
|**Cirúrgicos**||||
|Vasectomia|0,15|0,1|100|
|LT|0,5|0,5|100|  
Adaptada de Trussell _et al._ , 2011. DIU: dispositivo intrauterino; ENG: etonogestrel; LT: laqueadura tubária.  
Além da efetividade, os benefícios e riscos de cada método contraceptivo devem ser levados em consideração na orientação contraceptiva (36). Assim, a avaliação das necessidades não contraceptivas das MVHIV deve ser considerada na eleição do contraceptivo.  
Outro ponto importante na prescrição de contraceptivos para MVHIV é a presença de outras morbidades, como tabagismo, hipertensão arterial, dislipidemia, entre outras. Para facilitar a prescrição de contraceptivos nestas situações, a Organização Mundial de Saúde (OMS) publicou uma orientação de contracepção em várias situações clínicas, entre elas a presença de HIV e o uso de terapia antirretroviral (TARV), que contempla os critérios médicos de elegibilidade para uso de contraceptivos. Nesta orientação, os contraceptivos são classificados de acordo com a melhor evidência disponível em categorias para uma dada situação (Quadro 3). Estas orientações são atualizadas periodicamente.  
Quadro 3 – Critérios Médicos de Elegibilidade para uso de métodos contraceptivos  
|**Categoria**|**Classificação**|**Julgamento clínico**|
|---|---|---|
|**1**|Condição em que não existem restrições<br>ao uso do método contraceptivo|Método pode ser utilizado em<br>quaisquer circunstâncias|
|**2**|Condição em que as vantagens do uso do<br>método geralmente superam os riscos,<br>teóricos ou comprovados|De modo geral, o método pode<br>ser utilizado|
|**3**|Condição em que os riscos, teóricos ou<br>comprovados, geralmente superam as<br>vantagens do uso do método|O método não é recomendado, a<br>menos que outros métodos mais<br>adequados não estejam|  
|||disponíveis, ou não sejam<br>aceitáveis. Avaliar risco-benefício|
|---|---|---|
|**4**|Condição em que há risco inaceitável à|Não utilizar o método|
||saúde com o uso do método||  
Fonte: Adaptado de “WHO – Medical eligibility criteria for contraceptive use, 5th edition”  
Os preservativos (masculino e feminino) permanecem como os únicos métodos que oferecem dupla proteção, reduzem a transmissão do HIV e de outras ISTs, além de evitarem a gestação. Entretanto, utilizar o preservativo como único método para planejamento reprodutivo requer engajamento do casal para uso correto do método, uma vez que as taxas de falha associadas ao seu uso típico variam de 18 a 21%. Assim, é recomendável associar outro método contraceptivo ao uso do preservativo, visando à dupla proteção (34).  
Neste capítulo será abordada a contracepção para mulheres com alto risco para infecção pelo HIV e para mulheres vivendo com HIV/AIDS.  
###### **3.7.2. Mulheres com alto risco de infecção pelo HIV (mulher negativa para o HIV e parceiro positivo para o HIV).**  
O uso de espermicidas e diafragma tem contraindicação absoluta nestas mulheres, pelo risco de microfissuras na parede vaginal e, consequentemente, risco aumentado de transmissão do HIV e exposição a outras IST (37). Os demais contraceptivos não alteram o risco de transmissão e aquisição do HIV.  
O uso de contraceptivo hormonal ou dispositivo intrauterino não interfere no risco de contrair ou transmitir HIV (38–41).  
Não há restrição para uso de método contraceptivo em mulheres com alto risco de infecção pelo HIV, com exceção do diafragma e espermicidas (3).  
Dessa forma, é importante que se mantenham as orientações de prevenção de IST para estas mulheres e que elas possam escolher o contraceptivo sem restrição.  
Baseada nas novas evidências de que nenhum contraceptivo hormonal ou dispositivo intrauterino altera o risco de contrair HIV, a OMS publicou novos critérios de elegibilidade para prescrição de contraceptivos para mulheres com alto risco de infecção pelo HIV (quadro 4). Quadro 4 - Critérios médicos de elegibilidade para prescrição de contraceptivos para mulheres com alto risco de infecção pelo HIV  
||Oral|Injetável|Pílula de|Implante|Injetável|DIU-cobre|
|---|---|---|---|---|---|---|
||combinado,<br>anel<br>e<br>adesivos|combinado|progestagênio|liberador<br>de<br>etonogestrel /<br>levonorgestrel|trimestral<br>(AMPD) IM<br>ou SC|/ DIU-LNG|
|Mulheres|1|1|1|1|1|1|
|com<br>alto|||||||
|risco para|||||||
|infecção<br>pelo HIV|||||||  
Adaptada de OMS, 2019.  
AMPD: Acetato de medroxiprogesterona subcutâneo; IM: Intramuscular; SC: Subcutâneo; DIU: Dispositivo intrauterino; DIU-LNG: Dispositivo intrauterino liberador de levonorgestrel.  
###### **3.7.3. Mulheres vivendo com HIV/AIDS**  
Para as MVHIV, nenhum método contraceptivo, seja hormonal ou dispositivo intrauterino, foi associado à piora da condição imunológica, à falha virológica ou à redução da efetividade da TARV (42– 44).  
Na presença de HIV, recomenda-se evitar o uso de espermicidas e diafragma nestas mulheres pelo risco de microfissuras na parede vaginal (37). Os demais métodos, não têm restrição. Em relação ao DIU-Cobre ou do DIU liberador de levonorgestrel (DIU-LNG), quando a usuária apresenta AIDS (linfócitos T CD4 < 200 células/mm<sup>3</sup> ou doença definidora de AIDS), sua inserção é categoria 3, por falta de estudos neste grupo de mulheres com a imunidade comprometida, e deve ser postergada para o momento em que a contagem de LT-CD4<sup>+</sup> for superior a este valor e/ou que a doença definidora de AIDS tenha sido resolvida. No caso de a mulher já estar utilizando previamente algum DIU (DIUCobre/DIU-LNG) e a contagem de LT-CD4<sup>+</sup> reduzir para abaixo de 200 células/mm<sup>3</sup> , ele não precisa ser retirado, a continuação do método é considerada categoria 2 (Quadro 5) (45).  
O quadro 6 resume os critérios de elegibilidade dos contraceptivos para MVHIV em uso de TARV (12,44–46).  
Quadro 5 - Critérios médicos de elegibilidade para prescrição de contraceptivos para mulheres que vivem com HIV/AIDS  
|Infecção|Oral|Injetável|Pílula de|Implante|Injet|ável|DIU-||
|---|---|---|---|---|---|---|---|---|
|pelo HIV|combinado,<br>anel<br>e|combinado|progestagênio|liberador<br>de<br>etonogestrel /|trime<br>(AM|stral<br>PD)|cobr<br>DIU-|e /|
||adesivos|||levonorgestrel|IM o|u SC|LNG||
||||||I|C|I|C|
|HIV<br>sem<br>critérios de|1|1|1|1|2|2|2|2|
|AIDS*|||||||||
|HIV<br>com<br>critérios de<br>AIDS*|1|1|1|1|3|2|3|2|  
Adaptada de OMS, 2015  
* AIDS: linfócitos T CD4 < 200 células/mm<sup>3</sup> ou doença definidora de AIDS  
Legenda: I = início; C = continuação  
Todos os esquemas de TARV podem ser utilizados de forma concomitante com os métodos contraceptivos. Recomenda-se o uso combinado com preservativo, especialmente entre os ARV com potencial de interação medicamentosa, como o efavirenz.  
Ressalta-se que o DTG pode ser coadministrado de forma segura com contraceptivos orais, visto que não apresenta interação medicamentosa com os contraceptivos hormonais (não é metabolizado pela enzima CYP3A4) (46–48).  
Quadro 6 – Critérios de elegibilidade para uso dos métodos contraceptivos em mulheres em uso de TARV  
|||||**Contraceptivo**||||||
|---|---|---|---|---|---|---|---|---|---|
|**ARV**|**Oral combinado/**|**Injetável**|**Pílula de**|**Acetato de**<br>**dit**|**Implante de**<br>**ltl/**|**DIU-C**|**obre**<sup>**(a)**</sup>|**SIU-L**|**NG**<sup>**(a)**</sup>|
||**adesivo combinado**|**combinado**|**progestagênio**|**meroxprogeserona**<br>**de depósito**|**evonorgesre**<br>**etanogestrel**|**I**|**C**|**I**|**C**|
|**ITRN**||||||||||
|ABC|1|1|1|1|1|2/3|2|2/3|2|
|TDF|1|1|1|1|1|2/3|2|2/3|2|
|AZT|1|1|1|1|1|2/3|2|2/3|2|
|3TC|1|1|1|1|1|2/3|2|2/3|2|
|FTC|1|1|1|1|1|2/3|2|2/3|2|
|**ITRNN**||||||||||
|EFV|2|2|2|1|2|2/3|2|2/3|2|
|ETR|1|1|1|1|1|2/3|2|2/3|2|
|NVP|2|2|2|1|2|2/3|2|2/3|2|
|**IP**||||||||||
|ATV/rD|2|2|2|1|2|2/3|2|2/3|2|
|RV/r|2|2|2|1|2|2/3|2|2/3|2|  
|||||**Contraceptivo**||||||
|---|---|---|---|---|---|---|---|---|---|
|**ARV**|**Oral combinado/**<br>**adesivo combinado**|**Injetável**<br>**combinado**|**Pílula de**<br>**progestagênio**|**Acetato de**<br>**medroxiprogesterona**<br>**de depósito**|**Implante de**<br>**levonorgestrel/**<br>**etanogestrel**|**DIU-Co**<br>**I**|**bre**<sup>**(a)**</sup><br>**C**|**SIU-L**<br>**I**|**NG**<sup>**(a)**</sup><br>**C**|
|**INI**||||||||||
|RAL|1|1|1|1|1|2/3|2|2/3|2|
|DTG<sup>(b)</sup>|1|1|1|1|1|2/3|2|2/3|2|  
Fonte: Adaptado de OMS, 2015.  
Legenda: I = início; C = continuação  
**(a):** Quando a mulher apresenta aids, com contagem de LT-CD4+ geralmente abaixo de 200 céls/mm<sup>3</sup> ou doença definidora de aids, **a inserção do DIU-Cobre ou do DIU-LNG é categoria 3. (b):** O DTG é metabolizado em via distinta do CYP 3A4 (enzima que metaboliza os contraceptivos hormonais).  
**Os métodos descritos no Quadro 6 não representam indicação terapêutica, mas se propõem a compor uma lista mais completa de alternativas, de modo que os profissionais possam individualizar a situação clínica de cada mulher vivendo com HIV diante dos diferentes métodos contraceptivos existentes.**  
Para prescrição dos métodos contraceptivos disponíveis no SUS, consultar os Protocolos da Atenção Básica: Saúde das Mulheres disponível em: <u>http://dab.saude.gov.br/portaldab/biblioteca.php?conteudo=publicacoes/protocolos_ab.</u>  
Quadro 7 – Métodos contraceptivos reversíveis disponibilizados no SUS  
|**Denominação genérica**|**Concentração/**<br>**composição**|**Forma farmacêutica/**<br>**descrição**|
|---|---|---|
|Preservativo feminino|-|160mm x 49mm|
|Preservativo masculino|-|160mm x 52mm|
|Dispositivo intrauterino plástico com<br>cobre|-|Modelo T 380mm<sup>2</sup>|
|Etinilestradiol + levonorgestrel|0,03mg + 0,15mg|Comprimido ou drágea|
|Noretisterona|0,35mg|Comprimido|
|Enantato de norestirona + valerato de<br>estradiol|50mg/mL + 5mg/mL|Solução injetável<br>mensal|
|Acetato de medroxiprogesterona|150 mg/mL|Suspensão injetável<br>trimestral|
|Diafragma|-|60mm de diâmetro<br>65mm de diâmetro<br>70mm de diâmetro<br>75mm de diâmetro<br>80mm de diâmetro<br>85mm de diâmetro|
|Levonorgestrel<br>(contracepção de emergência)|0,75mg<br>1,5mg|Comprimido|  
Fonte: Relatório Conitec nº 207, de abril de 2016.  
###### **3.7.3.1. Preservativos masculino e feminino**  
O uso de preservativos masculinos e femininos continua sendo o único método que confere dupla proteção, reduzindo o risco de transmissão das IST, inclusive do HIV, e ainda é contraceptivo. No entanto, como método contraceptivo, é muito dependente de adesão e do modo de uso a cada relação sexual. Requer engajamento das parcerias sexuais e é por isso que sua taxa de falha em uso típico varia entre 18% e 21%. Desse modo, **estimula-se a associação do preservativo com outro método contraceptivo** (34) **.**  
###### **3.7.3.2. Dispositivo intrauterino**  
A infecção pelo HIV não contraindica o uso do DIU, tanto de cobre quanto com liberação de levonorgestrel  (49).  
Para mais informações sobre indicações e o procedimento para inserção do dispositivo, consultar o “Manual técnico para profissionais de saúde – DIU com cobre T Cu 380 A” (50–53).  
Para mulheres que vivem com HIV e que estão com a contagem de LT-CD4+ menor que 200 céls/mm<sup>3</sup> , embora o DIU não precise ser retirado (categoria 2 de elegibilidade), **recomenda-se que sua inserção seja postergada até que ocorra reconstituição imune (aumento de LT-CD4+ e/ou resolução da doença definidora de aids)** .  
###### **3.7.3.3. Métodos hormonais orais (combinados ou apenas de progestagênio)**  
A OMS libera o uso destes métodos com todas as TARVs, lembrando que quando associado ao efavirenz, é importante alertar para a redução da eficácia e necessidade de associar preservativo (45,46).  
###### **3.7.3.4. Métodos hormonais combinados não orais (injetáveis mensais)**  
A OMS libera o uso destes métodos, independentemente da TARV utilizada (45).  
###### **3.7.4. Método hormonal de progestagênio não oral (injetável trimestral)**  
A OMS libera o uso destes métodos, independentemente da TARV utilizada (45).  
###### **3.7.4.1. Métodos definitivos**  
Os métodos contraceptivos definitivos são procedimentos cirúrgicos que resultam na esterilização do homem (vasectomia) ou da mulher (ligadura de trompas). Podem ser realizados por diferentes técnicas cirúrgicas e estão regulamentados por leis e portarias específicas. É ideal que, na condição de procedimento eletivo, a manipulação cirúrgica só deva ser realizada em PVHIV com imunidade reconstituída.  
###### **3.7.4.2. Contracepção de emergência**  
A contracepção de emergência tem como objetivo evitar a ocorrência de gravidez não planejada logo após a ocorrência de relação sexual desprotegida ou falha de um método contraceptivo. Esse método deve ser ofertado tanto nas relações consentidas quanto nas situações de violência sexual.  
Quanto maior o intervalo de tempo entre a relação sexual desprotegida e a tomada do medicamento, menor a sua eficácia. **Esse método contraceptivo pode ser ministrado até 120 horas após a relação sexual desprotegida** (36) **.**  
A chegada ao serviço de saúde com demanda por contracepção de emergência deve envolver avaliação da prática sexual, identificação dos riscos e oferta de testagem para HIV, sífilis e hepatites virais, além de PEP e PrEP, quando for o caso, especialmente se a PVHIV não estiver em uso de TARV.  
**A pílula de levonorgestrel** é mais eficaz que a pílula combinada em altas doses (conhecida como método Yuzpe) e causa menos efeitos adversos (36).  
De modo geral, os contraceptivos hormonais de emergência são seguros e eficazes. Os efeitos adversos mais comuns são náuseas e vômitos associados ao método Yuzpe, pela intolerância gástrica à alta dose hormonal de etinilestradiol e alteração do ciclo menstrual relacionado ao uso da pílula de levonorgestrel (54).  
Nas mulheres que vivem com HIV, a única ressalva quanto à utilização dos contraceptivos hormonais é a necessidade de avaliar a interação medicamentosa, especialmente com o efavirenz, pois a coadministração pode reduzir em 56% a quantidade do levonorgestrel oral (55). Há especialistas que recomendam fazer uso da dose única ao invés da dose fracionada, pela probabilidade de menor interferência na biodisponibilidade do hormônio.  
###### **3.8. Abordagem diagnóstica da infecção pelo HIV na gestação, parto e puerpério**  
Nas consultas das mulheres, o tema da saúde sexual e reprodutiva, bem como abordagem à prevenção combinada e opções quanto ao sexo seguro, concepção e contracepção devem ser abordados. Durante o pré-natal, ainda na primeira consulta, a equipe de saúde deve conversar com a gestante e suas parcerias sexuais (inclusive na estratégia do pré-natal do parceiro) sobre a importância da testagem para infecções sexualmente transmissíveis (IST) e os benefícios do diagnóstico precoce de uma IST, tanto para o controle da infecção materna quanto para a prevenção da transmissão vertical.  
No momento da testagem, é necessário um ambiente de confiança e respeito, que favoreça o vínculo e a avaliação de vulnerabilidades, permitindo a atenção resolutiva e a articulação com outros serviços de saúde para a continuidade da assistência.  
São recomendações quanto aos momentos de oferta de testagem para o HIV da gestante/puérpera (Figura 2):  
<!-- Start of picture text -->
Figura 2 – Momentos para oferecer testagem de HIV à gestante<br>1ª consulta do pré-<br>natal, idealmente no 1º<br>trimestre da gestação<br>Pré-natal<br>Início do 3º trimestre de<br>gestação (28ª semana)<br>Realizar Maternidade:<br>testagem para HIV  parto/ aborto<br>Sempre que houver<br>história de exposição de<br>risco/violência sexual<br>Oferta de testagem rápida para IST também para as parcerias sexuais das gestantes<br>=<br>Fonte: DCCI/SVS/MS.<br><!-- End of picture text -->  
Está recomendada a testagem rápida combinada para HIV, sífilis, hepatite B (se gestante sem esquema vacinal completo) e hepatite C sempre que oportuno. Os **testes rápidos** para HIV são métodos preferenciais para diagnóstico pois possibilitam início precoce da terapia antirretroviral e, consequentemente, resposta virológica mais rápida. A **testagem laboratorial** pode ser utilizada, desde que a entrega do resultado ocorra em tempo oportuno, tendo como objetivo não apenas o início do tratamento precoce da gestante para a sua própria saúde, mas visando a prevenção da transmissão vertical que depende de uma janela de tempo de oportunidade. ~~<u><mark>—</mark></u>~~ O teste rápido para HIV deve ser executado segundo as recomendações definidas no “Manual Técnico para Diagnóstico da Infecção pelo HIV”, disponível em <u>http://www.aids.gov.br/biblioteca.</u>  
De acordo com a literatura, apesar de raros, podem ocorrer resultados falso-reagentes nos testes para HIV em gestantes, em função da presença de aloanticorpos. São situações que exigem especial atenção: doenças autoimunes, múltiplos partos, transfusões sanguíneas, hemodiálise e vacinação recente. Dessa forma, a coleta da **carga viral do HIV (CV-HIV)** deve ser realizada em qualquer fluxo de diagnóstico, imediatamente, e antes do início da terapia antirretroviral (TARV).  
O **teste de genotipagem (genotipagem pré-tratamento)** está indicado para todas as gestantes que forem iniciar a TARV. Esse teste deverá ser solicitado e a amostra de sangue coletada antes de iniciar a TARV. No entanto, não é necessário aguardar o resultado da genotipagem para o início da TARV.  
###### **3.9. Abordagem inicial da gestante vivendo com HIV**  
Este capítulo aborda as recomendações para auxiliar os profissionais do pré-natal de baixo e de alto risco, além dos serviços especializados, no atendimento inicial às gestantes com diagnóstico de infecção pelo HIV, e que não apresentem manifestações de Infecções Oportunistas (IO).  
No caso de gestantes com imunossupressão mais grave (contagem de células T CD4+ menor ou igual a 350 células/ mm<sup>3</sup> ), sinais e sintomas de AIDS e/ou presença de IO, a abordagem será direcionada para o manejo dessas condições, mediante o auxílio do infectologista ou clínico com experiência no tratamento das pessoas vivendo com HIV (PVHIV). Importante que os serviços saibam seus fluxos locais de referência dessas gestantes, que devem ter seu agendamento e atendimento priorizados.  
As gestantes diagnosticadas com HIV, a partir de qualquer metodologia de testagem, devem ter seu cuidado compartilhado com o pré-natal de alto risco ou SAE, de acordo a situação clínica e fluxos de referência e contra referência locais, **devendo manter o vínculo com a Atenção Básica** em um modelo de **cuidado compartilhado** , como mostra a Figura 3.  
Figura 3 - Fluxograma de local de atendimento da gestante com HIV, de acordo com sua situação clínica  
<!-- Start of picture text -->
Atenção Básica<br>Pré-natal de alto risco<br>gestantesTodas as  Serviço especializado<br>Gestante<br>HIV+ Gestante HIV+ com imunossupressão grave<br>e/ou outras coinfecções<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
###### **3.10. Seguimento clínico, laboratorial e obstétrico**  
Um dos objetivos da avaliação inicial de uma pessoa recém-diagnosticada com a infecção pelo HIV é estabelecer uma boa relação profissional-usuário. A linguagem acessível e comunicação centrada na pessoa é fundamental para o bom entendimento dos aspectos essenciais da infecção pelo HIV, bem como sobre a importância do acompanhamento clínico-laboratorial e da TARV, contribuindo para a adesão ao tratamento e ao seguimento.  
Os itens listados a seguir servem como um roteiro para orientar a abordagem no acompanhamento inicial da gestante infectada pelo HIV:  
- avaliar o nível de conhecimento da gestante sobre a doença e explicar a infecção pelo HIV e sua evolução, assim como sobre o baixo risco de transmissão vertical dada a elevada eficácia das medidas preventivas;  
- enfatizar o impacto positivo do início do uso de TARV para a qualidade de vida dela e para a prevenção da transmissão vertical, destacando a importância da adesão nesse processo;  
- identificar alguma condição que exija intervenção imediata, como sinais e sintomas sugestivos de IO, bem como a necessidade de iniciar profilaxia para IO;  
- avaliar parceria sexual e filhos(as); e  
- abordar aspectos relacionados à saúde sexual e à prevenção combinada.  
O Quadro 8, a seguir, detalha questões a serem pesquisadas na história inicial. Esses aspectos devem ser abordados pela equipe multidisciplinar de saúde, de acordo com a organização local.  
Quadro 8 – Aspectos que devem ser abordados no atendimento à gestante vivendo com HIV  
|**Necessidades e**<br>**informações para o**<br>**manejo**|**Aspectos a serem abordados no atendimento inicial**|
|---|---|
|Diagnóstico|- Nível de conhecimento sobre HIV/aids, explicando as dúvidas de<br>forma objetiva<br>- Avaliação da rede de apoio familiar e social, assegurando<br>confidencialidade e sigilo|
|Informações específicas<br>sobre a infecção pelo<br>HIV|- Documentação do teste no prontuário e na Caderneta da<br>Gestante<br>- Presença ou história de IO relacionadas ao HIV<br>- Contagem de LT-CD4+ e CV-HIV, genotipagem e início de TARV<br>- História de uso anterior de ARV: tempo de uso e de interrupção,<br>adesão, eventos adversos prévios etc.<br>- Cartão de Vacinação<br>- Compreensão sobre a doença: explicação sobre TV e horizontal,<br>história natural, significado da contagem LT-CD4+, CV-HIV, TARV<br>e genotipagem<br>- Utilização de preservativo masculino e feminino e outras formas<br>de prevenção combinada<br>- História de sífilis, outras IST<br>-História de coinfecção com HBV ou HCV|
|Abordagem de sexo<br>seguro e práticas<br>sexuais de risco|- Investigação de práticas de risco, em um ambiente livre de<br>julgamento, para que a gestante e suas parcerias sexuais se<br>sintam à vontade para relatá-los<br>- Uso de tabaco, álcool e outras drogas lícitas e ilícitas<br>- Interesse em reduzir os danos à saúde<br>- Conhecimento sobre práticas sexuais seguras de acordo com o<br>relatado pela gestante|
|Hábitos de vida|- Rotinas diárias<br>- Hábitos nutricionais<br>- Atividade física<br>- Atividade laboral e possíveis exposições de risco|
|História clínica atual|- Alergias|  
|**Necessidades e**<br>**informações para o**<br>**manejo**|**Aspectos a serem abordados no atendimento inicial**|
|---|---|
|e passada|- História de doença mental<br>- História de tuberculose: PPD, doença e tratamento, inclusive de<br>tuberculose latente (ILTB) contato íntimo com pessoa com<br>diagnóstico atual de tuberculose<br>- Dislipidemias, diabetes, hipertensão arterial sistêmica, doenças<br>autoimunes, distúrbios da tireoide<br>- Câncer de mama e câncer de colo uterino (último preventivo)<br>- Hospitalizações prévias<br>- Uso de práticas integrativas|
|História reprodutiva|- História de infecções ginecológicas<br>- Fatores de risco para gestação<br>- Menarca e ciclos menstruais<br>- Uso de métodos contra conceptivos<br>- Gestações, partos e interrupções de gestações prévias|
|História social|- Rede de apoio social (família, amigos, ONG)<br>- Condições de domicílio<br>- Condições de alimentação<br>- Emprego/profissão<br>- Aspectos legais|
|História familiar|- Doenças cardiovasculares<br>- Dislipidemias<br>- Diabetes_mellitus_<br>- Doenças autoimunes|  
Fonte: DCCI/SVS/MS.  
Como a infecção pelo HIV é de caráter sistêmico, torna-se necessário, além do exame físico geral, observar atentamente os sinais clínicos sugestivos de manifestações da doença. O quadro seguinte lista os sistemas que frequentemente expressam alguma manifestação clínica associada à infecção pelo HIV.  
Quadro 9 – Órgãos e sistemas comumente associados a manifestações da infecção pelo HIV no exame inicial, em gestantes assintomáticas  
|**Órgãos e sistemas**|**Manifestações associadas/orientação**|
|---|---|
|Pele|- Pesquisar sinais de dermatite seborreica, foliculite, micose<br>cutânea, molusco contagioso, sarcoma de Kaposi|  
|Cabeça e pescoço|- Pesquisar candidíase oral e/ou leucoplasia pilosa na<br>orofaringe<br>- Realizar exame de fundo de olho, especialmente nas<br>gestantes com contagem de LT-CD4+ menor ou igual a 50<br>céls/mm<sup>3</sup>, bem como coinfecção com sífilis|
|---|---|
|Linfonodos|- Pesquisar linfadenomegalias|
|Abdome|- Pesquisar hepatomegalia ou esplenomegalia, massas<br>palpáveis|
|Sistema neurológico|- Pesquisar sinais neurológicos focais e avaliar estado cognitivo|
|Trato genital inferior|- Examinar a região vaginal, anal e perianal, pesquisando<br>corrimento, úlceras e lesões sugestivas de infecção pelo HPV<br>ou de neoplasias|  
Fonte: DCCI/SVS/MS.  
###### **3.10.1. Avaliação laboratorial inicial**  
A abordagem laboratorial no início do acompanhamento clínico-obstétrico de gestantes infectadas pelo HIV tem como objetivo avaliar a condição geral de saúde da mulher e identificar o status da infecção pelo HIV (situação imunológica e virológica inicial), a presença de comorbidades e de fatores que possam interferir na evolução da gravidez.  
O nível da **CV-HIV** é um dos fatores mais importantes associados ao risco de transmissão vertical do HIV e auxilia no seguimento e na definição da via de parto.  
A taxa de TV do HIV é inferior a 1% em gestantes em uso de TARV que mantêm níveis de CV-HIV abaixo de 1.000 cópias/mL (6,7,56), sendo, portanto, muito baixa quando a CV estiver indetectável. Além disso, a CV-HIV é utilizada para monitoramento da gestante infectada pelo HIV, auxiliando na avaliação da resposta à TARV.  
Durante o seguimento da gestante infectada pelo HIV, devem ser realizados pelo menos **três exames de CV-HIV durante a gestação** :  
- **na primeira consulta do pré-natal, para estabelecer a magnitude da viremia;**  
- **quatro semanas após a introdução ou mudança da TARV, para avaliar a resposta ao tratamento; e**  
- **na 34ª semana de gestação, para indicação da via de parto.**  
**A solicitação da CV-HIV, ainda, faz parte da avaliação da gestante, em qualquer momento, quando há dúvidas quanto à adesão à TARV.**  
A **contagem de LT-CD4+** deverá ser realizada **na primeira consulta de pré-natal** e pelo menos **a cada três meses durante a gestação** para gestantes em início de tratamento. Para gestantes em seguimento clínico em uso de TARV, com CV-HIV indetectável, solicitar contagem de LTCD4+ juntamente com CV-HIV na primeira consulta e na 34ª semana de gestação.  
###### **Periodicidade de consultas e seguimento laboratorial**  
Recomenda-se um número mínimo de 6 (seis) consultas de pré-natal, sendo a primeira consulta realizada idealmente no 1º trimestre da gestação.  
O Quadro 10 apresenta os exames sugeridos para estruturar a abordagem laboratorial inicial e sua frequência de realização durante as consultas de pré-natal.  
###### Quadro 10 – Periodicidade de realização de exames durante a gestação  
||||**Trimes**|**tre**||
|---|---|---|---|---|---|
|**Exame**|||||**Comentário**|
||**Inicial**|**1º**|**2º**|**3º**||
|Hemograma|**X**|**X**|**X**|**X**||
|Tipagem sanguínea|**X**|||||
|Coombs indireto|**X**||**X**||Se a gestante for Rh negativo<br>Se o resultado for**negativo**, administrar imunoglobulina anti-RhS na 28ª semana de<br>gestação|
|Glicemia em jejum|**X**|**X**|**X**|**X**||
|Teste de tolerância à glicose com<br>75g|||**X**||Entre a 24ª e a 28ª semana|
|CT, LDL, HDL e TGL|**X**|||||
|Exame sumário de urina e<br>urocultura|**X**|**X**|**X**|**X**||
|Provas de função hepática|**X**||||Em caso de gestantes em uso de**nevirapina**, deve-se realizar o controle de rotina<br>durante toda a gestação. Este medicamento não está mais recomendando para o<br>tratamento de pessoas adultas vivendo com HIV.<br>Em caso de uso de raltegravir, realizar controle na introdução do ARV e de rotina<br>durante toda a gestação, especialmente no 3º trimestre. Este medicamento não é mais<br>recomendando como esquemapreferencial degestantes vivendo com HIV,exceto|  
|||**Trimes**|**tre**||
|---|---|---|---|---|
|**Exame**||||**Comentário**|
||**Inicial**|**1º**<br>**2º**|**3º**||
|||||para aquelas que iniciam pré-natal e TARV tardiamente E que têm contraindicação ao<br>DTG por interação medicamentosa.|
|Prova de função renal (ureia e<br>creatinina)|**X**|**X**||Sempre calcular o_clearance_de creatina antes do uso de TDF, e rotineiramente após<br>introdução. Solicitar após o 1º mês e, pelo menos, trimestralmente, enquanto os níveis<br>estiverem dentro da normalidade|
|Contagem de LT-CD4+|**X**|**X**|**X**|Solicitar trimestralmente durante gestação para gestantes em início de tratamento.<br>Para gestantes em uso de TARV, com CV-HIV indetectável, solicitar no 1º trimestre e<br>na 34ª semana de gestação.|
|CV-HIV|**X**||**X**|A solicitação de CV-HIV deverá ser realizada na primeira consulta de pré-natal.<br>Para gestantes em início de tratamento ou modificação de TARV, uma segunda<br>amostra deverá ser solicitada 2 a 4 semanas após introdução/modificação da TARV.<br>Avaliar queda de pelo menos 1 Log de CV-HIV.<br>Nas gestantes em uso de TARV com CV-HIV**detectável**, avaliar adesão e a possibilidade<br>de realizar genotipagem (CV-HIV >500 cópias/mL).<br>Todas as gestantes deverão ter coleta de CV-HIV a partir da 34ª semana, para auxiliar<br>definição da via de parto e do uso de profilaxias|
|Genotipagem|**X**|||**Coletar antes do início da TARV para todas as gestantes em início de tratamento**<br>**(genotipagem pré-tratamento).**<br>**Iniciar TARV em gestantes que não estavam em tratamento o mais precocemente**<br>**possível, sem aguardar resultado de genotipagem.**|  
||||**Trimes**|**tre**|**ái**|
|---|---|---|---|---|---|
|**Exame**|||||**Comentro**|
||**Inicial**|**1º**|**2º**|**3º**||
||||||**Gestantes em TARV antes da gestação, que apresentem CV-HIV detectável: Avaliar**<br>**adesão e realizar ajuste, caso necessário, guiado por resultado de genotipagem.**|
|Teste treponêmico (ex.: TR) e/ou<br>teste não treponêmico (ex.:<br>VDRL)|**X**|||**X**|Realizar testagem para sífilis no diagnóstico da gestação (na primeira consulta de pré-<br>natal) e no 3º trimestre, além da admissão para o parto ou em caso de aborto.<br>Oferecer nova testagem em caso de história de exposição sexual de risco/violência<br>sexual.|
|Anti-HAV|**X**||||Solicitar na primeira consulta. Imunizar para hepatite A em caso de resultado não<br>reagente|
|HBsAg|**X**||||Na primeira consulta e no parto (caso o esquema vacinal não tenha sido completado).<br>Imunizar caso não haja histórico de vacinação completa (03 doses) e se HBsAg não<br>reagente.|
|Anti-HCV|X||||Na primeira consulta de pré-natal.|
|Sorologia para toxoplasmose<br>(IgM, IgG)|X|X|X|X|Sorologia trimestral para IgG, no caso de resultado inicial não reagente.<br>Realizar orientações quanto à prevenção da exposição a_Toxoplasma gondii._|
|Sorologia para doença de Chagas|X||||Na primeira consulta, solicitar dois métodos distintos para detecção de IgG conforme<br>grupos de risco: 1) pessoas residentes ou procedentes de áreas de transmissão ativa<br>(vetorial ou oral) atualmente ou no passado; 2) pessoas que habitam (ou tenham<br>habitado) em áreas com presença de triatomíneo; 3) pessoas que tenham recebido<br>transfusão de sangue (hemocomponentes) antes de 1992; 4) filhos(as) de mães com<br>doença de Chagas emquaisquer fases ou formas clínicas;5) pessoas com familiares|  
||||**Trimes**|**tre**||
|---|---|---|---|---|---|
|**Exame**|||||**Comentro**|
||**Inicial**|**1º**|**2º**|**3º**||
||||||(outros que não a “mãe biológica”) ou pessoas do convívio social que tenham<br>diagnóstico da doença de Chagas.|
|Citopatológico do colo do útero|X||||Semestral no primeiro ano de diagnóstico de infecção pelo HIV e, se normal, manter<br>seguimento anual.<br>Se contagem de LT-CD4+ <200 céls/mm³, priorizar correção dos níveis de LT-CD4+ e<br>realizar rastreamento citológico a cada 6 meses, até recuperação imunológica.<br>Realizar colposcopia na presença de alterações patológicas.|
|_Swab_vaginal e anal para pesquisa<br>de estreptococo do grupo B||||X|Entre a 35ª e a 37ª semana de gestação. Se a cultura for positiva, indicar profilaxia com<br>penicilina G cristalina endovenosa durante o trabalho de parto.|
|Exame especular com realização<br>de teste de pH e teste das aminas<br>(teste do cheiro ou de Whiff)|X||||Sempre que houver sinais e sintomas de vaginose bacteriana.|
|Rastreio de Infecção latente pelo<br>_M._<br>_tuberculosis_<br>com<br>Prova<br>Tuberculínica (PT)<sup>(a)</sup>ou IGRA<br>(_Interferon-gama release assay_)|X||||Realizar na primeira consulta em gestante assintomática e sem história prévia de TB.<br>Nas gestantes que apresentam contagem de LT-CD4+ menor ou igual a   350 céls/mm³<br>independente de PT, desde que excluída TB ativa.<br>PPD ≥5 mm: realizar a investigação de TB ativa. Caso a investigação seja negativa,<br>indicar a profilaxia com isoniazida associada à piridoxina. Na ausência de PT<sup>(a)</sup>, iniciar<br>isoniazida em casos específicos|  
Fonte: DCCI/SVS/MS.  
**Trimestre Exame Comentário Inicial 1º 2º 3º**  
(a) Para mais informações sobre a indisponibilidade de PPD, consultar a Nota Informativa nº 08/2014/CGPNCT/DEVEP/SVS/MS e o Ofício Circular nº <u>02/2015/CGPNCT/DEVIT/SVS/MS.</u>  
###### **3.10.2. Investigação de tuberculose em gestantes vivendo com HIV/aids**  
Uma vez que a tuberculose (TB) é a principal causa de óbito em PVHIV, recomenda-se a pesquisa em todas as consultas, inclusive durante o pré-natal. Deve-se questionar a gestante sobre sintomas respiratórios e provável contato íntimo com sintomático respiratório. São sinais e sintomas a presença de tosse, febre, emagrecimento e/ou sudorese noturna. A existência de qualquer um desses sintomas pode indicar TB ativa e deve ser investigada.  
Para **gestantes vivendo com HIV e sintomáticas respiratórias** (tosse há mais de 2 semanas), independentemente da contagem de LT-CD4+, **devem ser solicitadas 3 amostras de escarro para realização do teste rápido da TB (se disponível), pesquisa direta do bacilo de Koch (BAAR) e cultura de micobactéria.**  
Recomenda-se rastreio de Infecção latente pelo _M. tuberculosis_ (ILTB) em todas as PVHIV assintomáticas para TB e sem histórico prévio da doença, através de Prova Tuberculínica (PT) ou de IGRA ( _Interferon-gama release assay_ ).  
Se a **PT for menor que 5mm** , recomenda-se que seja **repetida anualmente** e também **após a reconstituição imunológica** com o uso da TARV.  
**Recomenda-se que TODAS as PVHIV com contagem de LT-CD4+ menor ou igual a 350 céls/mm³, inclusive gestantes, recebam tratamento para ILTB,** desde que excluída TB ativa, independentemente de PT.  
Para PVHIV com contagem de LT-CD4+ maior que 350 céls/mm³, os critérios para tratamento de ILTB são:  
1. Pacientes assintomáticos para TB (TB ativa excluída) com radiografia de tórax normal, e:  
- PT ≥5 mm ou IGRA positivo; ou  
- contatos intradomiciliares ou institucionais com pacientes com confirmação laboratorial, independentemente do resultado da PT ou do IGRA; ou  
- PT <5mm com registro documental de PT ≥5mm anterior, não tendo sido submetidos a tratamento ou tratamento da TB latente na ocasião.  
2. Pacientes assintomáticos para TB (TB ativa excluída) com radiografia de tórax evidenciando cicatriz radiológica de TB, sem tratamento prévio de ILTB.  
3. Na indisponibilidade da PT e TB ativa excluída, em caso de:  
- risco epidemiológico acrescido: locais com alta carga da doença, como presídios ou albergues;  
- pacientes sem TARV ou pacientes em TARV com falha virológica.  
Nas gestantes vivendo com HIV, **o tratamento da ILTB deve ser iniciado após o primeiro trimestre da gestação** (92).  
O esquema preferencial de tratamento para ILTB na gestante vivendo com HIV é a Isoniazida, na dose de 300 mg uma vez ao dia, por tempo de 6 a 9 meses, suplementada por piridoxina na dose de 50mg/dia durante a gestação, pela potencial toxicidade neurológica da isoniazida na mulher e no RN.  
A isoniazida 300 mg para o tratamento de ILTB em PVHIV está disponível para dispensação nas Unidades dispensadoras de medicamentos (UDM) pela opção Isoniazida-TB no SICLOM operacional.  
Recomenda-se a notificação de todos os casos que iniciarão o tratamento para Infecção Latente da Tuberculose. A notificação deve ser realizada no IL-TB (Sistema de Informação para notificação das pessoas em tratamento para ILTB – http://sitetb.saude.gov.br/iltb).  
Para mais informações sobre o tratamento da coinfecção TB-HIV, consultar o “Manual de Recomendações para Controle da Tuberculose no Brasil”, disponível em <u>http://www.saude.gov.br/tuberculose, e o “Protocolo Clínico e Diretrizes Terapêuticas para</u> Manejo da Infecção pelo HIV em Adultos”, disponível em http://www.aids.gov.br/pcdt, a Nota Informativa Nº 11/2018/DCCI/SVS/MS e o Ofício Circular n° 05/2018/DAF/SCTIE/MS.  
###### **3.10.3. Imunizações na gestante vivendo com HIV/aids**  
Além dos aspectos que dizem respeito à gestação, é preciso considerar as condições imunológicas da gestante vivendo com HIV/aids. Na infecção pelo HIV, à medida que aumenta a imunossupressão, reduz-se a possibilidade de resposta imunológica consistente.  
Sempre que possível, deve-se adiar a administração de vacinas em PVHIV sintomáticas ou com imunodeficiência grave, com presença de IO ou contagem de LT-CD4+ inferior a 200 céls/mm<sup>3</sup> , até que um grau satisfatório de reconstituição imune seja obtido com o uso de TARV, o que proporciona melhora na resposta vacinal e reduz o risco de complicações pós-vacinais.  
**As vacinas virais vivas que contêm os componentes do sarampo, da rubéola, da caxumba e da febre amarela não são recomendadas na gestação** .  
Contudo, quando for alto o risco de ocorrer a infecção natural pelos agentes dessas doenças (viagens a áreas endêmicas ou vigência de surtos ou epidemias), deve-se avaliar cada situação, sendo válido optar-se pela vacinação quando o benefício for considerado maior do que o possível risco. Se houver administração inadvertida durante a gestação, não se justifica o aborto por se tratar de risco teórico. A gestante deverá ser acompanhada pelo serviço de saúde (57).  
A vacina da febre amarela deve ser evitada; porém, em regiões de risco elevado ou em situações de surto, poderá ser administrada, avaliando-se relação de risco-benefício, devido à alta morbimortalidade da doença, a partir do terceiro trimestre da gestação. Nessas situações, será necessária a avaliação de um especialista e a correlação com a contagem de LT-CD4+ da gestante (Nota Informativa N° 01/2017/SVS/MS).  
As imunizações que podem ser indicadas na gestação de mulheres vivendo com HIV/aids estão especificadas no Quadro 11.  
###### Quadro 11 – Imunizações recomendadas em gestantes vivendo com HIV/aids  
|**Imunização**|**Recomendação – avaliar contagem de LT-CD4+ e condição clínica da gestante**|
|---|---|
|Vacina para pneumococo|Recomendada. Duas doses, com intervalo de 5 anos, independentemente da idade.|
|Vacina meningocócica conjugada (MncC)|Recomendada.|
|Vacina_Haemophilus influenzae_tipo b (Hib)|Nas mulheres menores de 19 anos, não previamente vacinadas.|
|Vacina para tétano e difteria (dT)|Recomendada. Indicado o reforço durante a gestação caso a última dose tenha sido administrada há mais<br>de 5 anos.|
|Vacina acelular contra difteria, tétano e<br>coqueluche (dTpa)|Se a gestante não for vacinada ou o estado vacinal for desconhecido, indicar 3 doses (esquema padrão) e<br>considerar uma dose de dTpa. Caso a gestante precise do reforço de difteria e tétano, poderá realizá-lo<br>contendo as 3 vacinas (dTpa) entre a 27ª semana e a 36ª semana (pelo menos 20 dias antes do parto),<br>conforme orientações sobre imunização contra a coqueluche em gestantes.|
|Vacina para hepatite B|Recomendada para as gestantes caso não haja histórico de vacinação completa e se HBsAg não reagente.<br>A dose deve ser o dobro daquela recomendada pelo fabricante e seguindo o esquema de 4 doses (0, 1, 2 e 6<br>ou 12 meses).|
|Imunoglobulina humana anti-hepatite B<br>(IGHAHB)|Recomendada para as gestantes suscetíveis, em situação de risco de exposição (ex.: usuárias de drogas que<br>compartilham seringas e agulhas, contato sexual desprotegido com pessoas HBsAg positivas ou em caso de<br>vítimas de violência sexual).|
||Dose única, iniciada ainda nos primeiros 14 dias de exposição.|  
|**Imunização**|**Recomendação – avaliar contagem de LT-CD4+ e condição clínica da gestante**|
|---|---|
|Vacina para hepatite A|Recomendada para as gestantes suscetíveis (anti-HAV IgG negativas).|
||Realizar duas doses com intervalo de 6 a 12 meses.|
|Influenza/H1N1<br>(INF)|Recomendada anualmente para PVHIV, antes do período da influenza. Vacina inativada trivalente, uma<br>dose anual.|
|Imunoglobulina para vírus da varicela-<br>zoster (VZV)|Recomendada para as gestantes suscetíveis (anti-VZV negativas), após exposição a pessoas com infecção<br>ativa por varicela.|
|Febre amarela|A vacinação está contraindicada em gestantes, independentemente do estado vacinal. Na impossibilidade<br>de adiar a vacinação, como em situações de emergência epidemiológica, vigência de surtos, epidemias ou<br>viagem para área endêmica, o médico deverá avaliar o benefício e o risco da vacinação.|  
Fonte: DCCI/SVS/MS.  
###### **A vacina contra o HPV não está indicada para as gestantes** .  
No entanto, em situação de vacinação inadvertida, não se recomenda a interrupção da gestação. A gestante deve ser acompanhada durante o pré-natal e o esquema completado após o parto.  
Para mais informações, consultar o calendário nacional de imunizações, disponível em <u>http://www.saude.gov.br/pni e em documentos específicos.</u>  
###### **3.11. Preparação da gestante vivendo com HIV/aids para o tratamento**  
###### **3.11.1. Atividade física na gestação**  
O exercício aeróbico regular durante a gravidez pode melhorar ou manter a capacidade física e a relação da gestante com o próprio corpo. No entanto, os dados de literatura ainda são insuficientes para explicar a extensão dos riscos e benefícios para a mãe e o feto.  
Desse modo, as gestantes que já realizam exercício físico regular podem ser orientadas a manter sua prática, desde que respeitem os limites de conforto e segurança do próprio corpo e que não se exponham a situações de risco. As atividades recreativas, na maioria dos casos, são seguras durante a gravidez.  
Para as gestantes que desejam iniciar atividade física, podem ser recomendados exercícios moderados por aproximadamente 30 minutos, diariamente. Avaliar de acordo com a disponibilidade a possibilidade da inclusão da mulher na política nacional de Práticas Integrativas e Complementares no SUS (Brasil, 2015b), disponível em: <u>http://189.28.128.100/dab/docs/portaldab/publicacoes/politica_nacional_praticas_integrativa s_complementares_2ed.pdf.</u>  
###### **3.11.2. Abordagem nutricional da gestante vivendo com HIV/AIDS**  
A alimentação das gestantes difere daquela dos adultos, basicamente, em razão da necessidade aumentada de nutrientes para possibilitar o adequado desenvolvimento do feto. As demandas nutricionais e energéticas podem variar segundo a avaliação do estado nutricional pré-  
gestacional, o estágio da infecção pelo HIV, as comorbidades (como diabetes, hipertensão ou obesidade), o estilo de vida e a atividade física habitual.  
Em gestantes vivendo com HIV/aids, deve-se avaliar se é um caso estável, assintomático ou se há alguma complicação ou sintoma de aids. Para gestantes assintomáticas, as recomendações não diferem dos cuidados com qualquer outra gestante de baixo risco. Deve-se seguir uma alimentação saudável, observando as necessidades nutricionais inerentes a essa condição fisiológica. Especial atenção deve ser dispensada à suplementação do ácido fólico na dose correta, 400 microgramas/dia (0,4 mg/dia), iniciando 1 mês antes da concepção e manter até a 12ª semana de gestação (58).  
A abordagem nutricional à gestante durante o pré-natal está bem estabelecida na série “Cadernos da Atenção Básica – Atenção ao pré-natal de baixo risco”, do item “Avaliação do estado nutricional e do ganho de peso gestacional”, disponível em <u>http://189.28.128.100/dab/docs/publicacoes/geral/caderno_atencao_pre_natal_baixo_risco.p df.</u>  
No “Manual Técnico para o Pré-Natal de Alto Risco”, disponível em <u>http://bvsms.saude.gov.br/bvs/publicacoes/gestacao_alto_risco.pdf, encontram-se também</u> orientações para gestantes que apresentam comorbidades, como anemias e diabetes, entre outras, que tornam o pré-natal de alto risco. Todas essas condições devem ser consideradas no cálculo das necessidades nutricionais.  
###### **3.11.3. Atividade sexual na gestação**  
As relações sexuais na gravidez não oferecem risco à gestação. A atividade sexual durante o terceiro trimestre da gravidez não está relacionada a aumento de prematuridade e mortalidade perinatal.  
É importante abordar durante a gestação e puerpério as práticas sexuais seguras e adequação das ofertas de prevenção combinada que mais se adeque à dinâmica da vida da mulher e suas parcerias sexuais. Deve ainda ser abordada a prevenção das IST que podem prejudicar a gestação e/ou serem transmitidas verticalmente, causando aumento da morbimortalidade, tanto para a gestante quanto para o concepto.  
Independentemente da CV-HIV, recomenda-se que as gestantes mantenham o **uso de preservativo masculino ou feminino** nas suas relações sexuais, protegendo-se de sífilis e outras IST. Outras tecnologias da Prevenção Combinada podem ser ofertadas de acordo com a dinâmica da vida sexual da mulher e suas parcerias sexuais.  
###### **3.11.4. Adesão na gestação e pós-parto**  
Apesar das evidências de que o desejo da mulher de proteger a saúde de seu filho e de se manter saudável leve à melhor adesão à TARV durante a gravidez, a cascata de cuidado contínuo das gestantes vivendo com HIV, no Brasil, em 2017, mostra que a proporção de GVHIV que apresentava CV-HIV suprimida no momento do parto foi de 46%. **A principal causa para a não supressão viral nesse grupo é a adesão insuficiente, que costuma se agravar após o parto.** Para o sucesso das políticas atuais de tratamento e acompanhamento de gestantes infectadas pelo HIV durante o pré-natal e após o parto, a equipe de saúde deve estar atenta aos aspectos individuais e dinâmicos que podem afetar a adesão (59).  
É imprescindível que essas mulheres recebam informações sobre os benefícios da TARV e que lhes seja garantido espaço para a discussão de eventuais temores sobre possíveis impactos negativos das medicações nos fetos e RN.  
**3.12.  Tratamento antirretroviral na gestação: princípios, indicações, monitoramento, manejo de eventos adversos e complicações (SIR)**  
O risco de transmissão vertical do HIV é determinado pela CV-HIV materna, pelo uso de TARV durante a gestação e pela relação entre o tempo de uso de TARV efetiva e o parto. A supressão da CV-HIV é um fator determinante na prevenção da transmissão vertical (PTV). O uso de TARV durante a gravidez reduz a taxa de transmissão vertical do HIV de aproximadamente 30% para menos de 1%, quando se alcança a supressão da CV-HIV materna (CV-HIV plasmática <50 cópias/mL) próxima ao parto (6,7,56).  
###### **3.12.1. Genotipagem pré-tratamento**  
Atualmente, há uma preocupação mundial com a transmissão de cepas resistentes do HIV a uma ou mais classes de ARV, o que está relacionado a maior chance de falha à TARV (60–62).  
Estudos mais recentes têm demonstrado que as mutações ocorrem de forma espontânea, sugerindo que esquemas de ARV com maior barreira genética para resistência, associados à maior adesão das pessoas em uso de TARV, podem limitar a expansão da resistência transmitida, por reduzir a geração de linhagens virais resistentes (63).  
A genotipagem pré-tratamento **está indicada para todas as gestantes vivendo com HIV em início de TARV** , de forma a orientar o esquema terapêutico.  
A realização de genotipagem para gestantes deve ser considerada uma prioridade na rede de assistência, uma vez que a escolha de um esquema antirretroviral eficaz tem impacto direto na TV do HIV. Contudo, **ressalta-se que o início do tratamento não deve ser retardado pela espera do resultado desse exame.**  
###### **3.12.2. Fatores a serem considerados na decisão sobre TARV para gestante vivendo com HIV**  
A escolha da TARV deve sempre ser compartilhada entre a equipe de saúde e a própria GVHIV e deve levar em consideração:  
- Se a MVHIV é virgem de TARV ou já fez uso prévio de TARV.  
- O momento do início da TARV em relação à concepção:  
- MVHIV em uso de TARV e que engravida;  
- TARV a ser iniciada na GVHIV.  
- Idade gestacional (IG);  
- condição clínica e imunológica da mulher;  
- sensibilidade aos antirretrovirais no exame de genotipagem pré-tratamento.  
- Em GVHIV com qualquer experiência prévia com antirretrovirais (ARV), considerar: histórico de TARV, falhas, exames prévios de genotipagem, toxicidade e tolerância.  
- Segurança do ARV no primeiro trimestre de gestação;  
- presença de hepatite B (incluir TDF no esquema de TARV em casos de coinfecção);  
- outros sinais e sintomas gravídicos que possam piorar em uso da TARV; e  
- a escolha da mulher.  
###### **3.12.3.  Das recomendações de TARV para GVHIV:**  
**3.12.3.1. GVHIV em início de TARV durante a gestação, sem histórico de exposição prévia à TARV**  
###### **a) Esquema inicial preferencial para início no 1º trimestre (até 12 semanas de IG)**  
Não há estudos suficientes para garantir total segurança à exposição fetal aos ARV, no primeiro trimestre. Os benefícios à saúde materna e à redução do risco de transmissão do HIV (TV-HIV) ao bebê<sup>4</sup> devem ser ponderados frente aos potenciais riscos de exposição de TARV ao feto.  
Sendo assim, recomenda-se abordar junto à GVHIV a relação de risco-benefício, a necessidade de boa adesão, e, de modo geral, **iniciar TARV o mais rápido possível** .  
**Para GVHIV que irão iniciar TARV no primeiro trimestre, recomenda-se** :  
Se genotipagem pré-tratamento comprovar ausência de mutações para ITRNN, o esquema preferencial é **TDF/3TC/EFZ** .  
Se genotipagem pré-tratamento não estiver disponível ou quando comprovar resistência transmitida a ITRNN, iniciar **TDF/3TC + ATV/r** .  
**b) Esquemas iniciais alternativos para gestantes no 1º trimestre de gestação**  
Na impossibilidade de composição da TARV com ITRNN e com o IP/r preferencial ATV/r, pode ser utilizado **darunavir potencializado por ritonavir (DRV/r), obrigatoriamente na dose recomendada de duas vezes ao dia** (DRV 600mg/ ritonavir 100mg de 12/12 h) **.**  
**O DTG não é recomendado para início de terapia no primeiro trimestre de gestação.** Contudo, após o primeiro trimestre, avaliar troca do terceiro ARV do esquema para DTG, considerando menor incidência de eventos adversos, maior tolerabilidade, se for o desejo da mulher.  
Pacientes estáveis, com boa tolerância ao esquema em uso e carga viral indetectável devem, preferencialmente, manter o esquema iniciado.  
**c) Esquema inicial preferencial para GVHIV a partir do 2º trimestre (a partir de 13 semanas de idade gestacional)**  
###### **TDF* + 3TC* + DTG**  
A terapia inicial deve incluir dois ITRN associados a um Inibidor de Integrase (INI).  
_* Preferencialmente na apresentação de dose fixa combinada_  
A TARV poderá ser iniciada na gestante antes mesmo de se terem os resultados dos exames de LT-CD4+, CV-HIV e genotipagem – principalmente nos casos de gestantes que iniciam tardiamente o acompanhamento pré-natal, com o objetivo de alcançar a supressão viral o mais rapidamente possível.  
São contraindicações ao DTG<sup>5</sup> :  
- uso concomitante dos seguintes anticonvulsivantes: oxicarbamazepina, dofetilida ou pilsicainida; e  
- reação de adversa ou intolerância ao medicamento.  
###### **d) Esquema inicial alternativo para GVHIV a partir do segundo trimestre de gestação**  
Caso a gestante apresente contraindicação ou eventos adversos que impossibilitem o uso do DTG, recomenda-se o manejo do esquema de ARV de acordo com a **tabela 1** abaixo.  
Quadro 12 - Esquemas iniciais alternativos de TARV para gestantes a partir do 2º trimestre de gestação  
|**Esquemas iniciais alternativos para gestante**<br>**12ª se**|**s a partir do 2° trimestre de gestação (após**<br>**mana)**|
|---|---|
|Contraindicação ao DTG|1ª opção: utilizar EFZ, caso genotipagem<br>mostre sensibilidade|
|Contraindicação ao EFZ|2ª opção: utilizar ATV/r|
|Contraindicação ao ATV/r|3ª opção: utilizar DRV/r|
|Contraindicação ao DTG e início tardio do<br>pré-natal (a partir do 3º trimestre de<br>gestação)|Avaliar a introdução de raltegravir (RAL)|  
Fonte: DCCI/SVS/MS  
O uso **de raltegravir (RAL)** no esquema de ARV pode ser considerado em gestantes que iniciam o pré-natal ou o uso da TARV tardiamente (final do segundo trimestre), e que tenham contraindicação ao DTG.  
A figura abaixo apresenta o fluxograma de decisão para escolha de antirretrovirais na GVHIV  
que irá iniciar o tratamento durante a gestação.  
Figura 4- Fluxograma de manejo de início de TARV na gestante vivendo com HIV  
<!-- Start of picture text -->
Gestante vivendo com<br>HIV que vai iniciar<br>TARV<br>Coletar CV-HIV,<br>contagem de LT-CD4 e<br>genotipagem<br>1º trimestre de<br>gestação* 2º ou 3º trimestre de<br>gestação<br>(até 12 semanas)<br>(a partir de 13 semanas)<br>Abordar benefícios e riscos do<br>início de TARV no primeiro<br>trimestre<br>Inicie (TDF+3TC) +<br>Reforçar aspectos de adesão<br>DTG<br>Autonomia da mulher<br>Esquemas alternativos<br>Sim Não<br>-<br>1 – EFZ – se genotipagem pré<br>tratmaneto sensível<br>2 - ATV/r<br>3 – DRV/r<br>Inicie (TDF+3TC) +<br>Inicie TARV** com:  DTG no início do  4 - RAL - se contraindicação ao DTG e<br>- segundo trimestre início tardio de TARV na gestação<br>(TDF+3TC) + EFZ – se geno pré<br>tratamento demonstrando<br>sensibilidade<br>(TDF+3TC) + ATV/r - se geno pré- *suplementação rotineira de ferro durante a<br>tratamento não disponivel ou  gestação (40mg/dia de ferro elementar e associar<br>genotipagem demonstrando mutação  ácido fólico na dose de 5 mg/dia até 12 semanas de<br>para ITRNN<br>IG<br>**avaliar trocar para DTG após 12 semanas de IG<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS  
###### **3.12.3.2. Manejo da gestante já em uso de TARV**  
###### **a) Manejo da gestante em uso de TARV com CV-HIV indetectável**  
Para GVHIV, **em uso de TARV prévia ao diagnóstico da gestação** e apresentando CV-HIV abaixo de 50 cópias/mL, **recomenda-se manter o mesmo esquema de ARV, desde que não contenha medicamento contraindicado na gestação.**  
**O ideal é não realizar a troca da TARV de uma gestante que esteja com boa adesão, assintomática e com CV-HIV indetectável.**  
Diante de uma MVHIV já em uso do DTG quando do diagnóstico da gestação, a decisão sobre a substituição do DTG deve ponderar que o defeito no fechamento do tubo neural pode acontecer de forma aleatória e é um evento raro (cerca de 0,06% na população geral no Brasil. Além disso, o risco adicional de defeito do tubo neural atribuível ao DTG é pequeno (0,2% em adição ao risco de cerca de 0,1% em MVHIV sem uso de DTG). Ademais, o fechamento se conclui até a 8ª semana gestacional, de forma que, se a GVHIV se apresenta após esse período, a alteração de seu esquema ARV pode representar mais riscos que benefícios (64,65).  
Dessa forma, recomenda-se avaliar para tomada de decisão compartilhada entre GVHIV e equipe de saúde:  
- **Uso de ácido fólico** , pois reduz a ocorrência de DTN na população geral e pode também ter um efeito protetor no caso de exposição ao DTG (66,67).  
- **Idade gestacional** : Não é recomendada troca do DTG para GVHIV com mais de 12 semanas de gestação. Para GVHIV com menos de 12 semanas de gestação é recomendada troca para esquemas contendo IP/r, preferencialmente ATV/r.  
- **Adesão e efeitos adversos** . Em nos casos de troca de ARV, avaliar a gestante semanalmente para monitorar efeitos adversos e adesão. Os principais efeitos adversos relacionados aos IP/r são justamente de trato gastrointestinal, o que pode piorar sintomas já frequentes durante a gestação.  
- **Possibilidade de escapes virais e perda do controle viral** : mudanças de TARV podem estar associados com escapes virais, especialmente em pessoas vivendo com HIV que já apresentaram falha virológica prévia. Escapes virais aumentam o risco de TV-HIV.  
Tabela 2 - Recomendações quanto à TARV de mulheres que engravidam em uso de DTG  
###### **TARV EM MULHERES QUE ENGRAVIDAM EM USO DE DTG**  
|Gestante com mais de 12|Manter DTG|
|---|---|
|semanas de gravidez||
|Gestante com 12 semanas ou<br>menos de gravidez|Trocar* DTG para IP/r (ATV/r)|
|Gestante em uso de esquema de|Avaliar o risco de perda do controle viral que a|
|resgate com IP/r e DTG em|modificação do esquema pode acarretar. O risco|
|qualquer fase da gestação|de rebote viral e transmissão vertical pode<br>superar o risco de DTN|  
*Se chegar à consulta com mais de **8 semanas** de IG, avaliar risco benefício da troca ou manter DTG, de forma individualizada, discutindo com a mulher.  
Fonte: DCCI/SVS/MS  
###### **b) Manejo da gestante já em uso de TARV com CV-HIV detectável**  
O reconhecimento precoce da falha virológica e a escolha adequada e oportuna do novo tratamento são fundamentais para evitar graves consequências, principalmente o insucesso da prevenção da TV-HIV, bem como uma maior progressão de doença e o adoecimento da gestante.  
A principal hipótese nos casos de falha virológica é má adesão. Os aspectos relacionados à adesão devem ser reforçados no cuidado das mulheres vivendo com HIV.  
Pelo fato de a gestação ter um período de duração relativamente curto, algumas orientações específicas devem ser seguidas quanto ao manejo da CV-HIV durante a gestação:  
- Todas as MVHIV que se tornam gestantes deverão realizar CV-HIV na primeira consulta de pré-natal.  
- Gestantes em TARV antes da gestação, que apresentem **CV-HIV detectável** , deverão ser avaliadas quanto à adesão e interação medicamentosa e **deverão ter exame de genotipagem solicitado para adequação da TARV** em uso, com celeridade. Ressalta-se que, para gestantes, apenas uma CV-HIV detectável (>500 cópias/mL) já é critério para solicitação de genotipagem.  
- GVHIV em **início de tratamento ou após modificação de TARV** deverão ter **nova amostra de CV-HIV coletada em duas a quatro semanas** .  
- Caso não tenha ocorrido **queda de pelo menos 1 log na CV-HIV** , avaliar adesão e interação medicamentosa, especialmente quanto à efetividade dos ARV prescritos.  
- Adequar a TARV de acordo com o resultado do **exame de genotipagem** , do menor prazo possível. Entrar em contato com a Câmara Técnica e/ou os Médicos Responsáveis pela Genotipagem (MRG), para que priorizem a avaliação das crianças e das gestantes.  
Figura 5 - Fluxograma de manejo de TARV na gestante vivendo com HIV em uso de TARV  
<!-- Start of picture text -->
Gestante vivendo<br>com HIV em uso de<br>TARV*<br>Coletar CV-HIV e<br>contagem de LT-CD4<br>na primeira consulta<br>de pré-natal<br>CV-HIV indetectável CV-HIV detectável<br>Reforçar adesão<br>1º trimestre* 2º ou 3º trimestre Avaliar interação<br>medicamentosa<br>Se CV-HIV>500 cópias/ml<br>– realizar genotipagem<br>Manter TARV<br>Em uso prévio DTG? Sem uso prévio DTG? Se tinha DTG -<br>orientar Ajustar esquema de<br>TARV conforme<br>genotipagem<br>Se <8 semanas: trocar<br>Manter esquema de<br>para ATV/r TARV<br>>8 semanas: avaliar<br>manutençaõ do DTG<br>* suplementação rotineira de ferro<br>Orientar<br>durante a gestação (40mg/dia de<br>ferro elementar e associar ácido<br>Fonte: DCCI/SVS/MS  fólico na dose de 5 mg/dia até 12<br>semanas de IG<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS  
Quadro 13 – Esquemas de TARV para início de tratamento em gestantes vivendo com HIV/aids  
|**Esquema preferencial para**|**Considerações**|
|---|---|
|**início de TARV na gestante**||
|**TDF + 3TC + DTG**|Iniciar DTG**após 12 semanas de gestação**. Contraindicado<br>no primeiro trimestre de gestação.|  
||Contraindicação ao TDF: AZT|
|---|---|
||Contraindicação ao TDF e AZT: ABC<sup>(a)</sup>|
|**Esquema alternativo para**<br>**início de TARV na gestante**||
||Pode ser iniciado no primeiro trimestre de gestação|
|TDF  3TC  EFV|Para uso do EFZ,**é mandatória a demonstração de**<br>**sensibilidade na genotipagem pré-tratamento**|
|+  +|Pode ser preferencial quando estejam presentes aspectos<br>de má adesão ou contraindicação ao uso do DTG|
||Contraindicação ao EFZ: ATV/r|
|TDF + 3TC + ATV/r|Pode ser preferencial na gestante com indicação de iniciar<br>TARV no 1º trimestre de gestação|
||Contraindicação ao ATV/r: DRV/r|
|TDF + 3TC + DRV/r|Esquema alternativo na gestante com indicação de iniciar<br>TARV no 1º trimestre de gestação|
|TDF  3TC  RAL<sup>(b)</sup>|Pode ser preferencial na gestante apresentadora tardia<br>(início da TARV no 3º trimestre de gestação)|
|+  +|Deve ser programada ainda no pré-natal a troca do RAL<br>para o DTG após o parto|  
Fonte: DCCI/SVS/MS.  
(a) Autorizada apenas se HLA-B*5701 negativo.  
(b) Realizar switch do RAL para DTG em até 90 dias após o parto.  
###### **3.12.3.3. Manejo da gestante para reinício de TARV após abandono**  
A MVHIV em situação de abandono de TARV e que engravida deve, assim que for readmitida no serviço, realizar avaliação de sintomas e exame físico, investigação de possíveis IO, coleta de CVHIV e de contagem de LT-CD4+ e introduzir um esquema de TARV de resgate conforme as orientações abaixo.  
O manejo da TARV pós-abandono deve respeitar os princípios de TARV de resgate.  
Para escolha do melhor esquema, deve-se considerar:  
- histórico de esquemas de TARV;  
- falhas virológicas e testes de genotipagem prévios;  
- contagem de LT-CD4 e exame de CV-HIV;  
- motivo da parada da TARV com objetivo de avaliar dificuldades na adaptação ou intolerância medicamentosa; e  
- idade gestacional – especial atenção às gestantes admitidas no terceiro trimestre em situação de abandono.  
Em relação ao esquema de TARV, as recomendações para **gestante em abandono de TARV são** :  
1 - Recomenda-se iniciar empiricamente a TARV com dois análogos de ITRN associados a um IP/r (preferencialmente ATV/r na dose de 300mg/100 mg uma vez ao dia).  
Se há falha prévia à classe de IP, considerar TARV com DRV/R (posologia de 600 mg/100 mg de 12/12 horas).  
2 - Após 4 a 6 semanas de uso efetivo de TARV, deve-se coletar nova CV-HIV e, se detectável, genotipagem para avaliação do tratamento e readequação do esquema de TARV.  
3 - Nos casos de gestante em abandono de TARV, com readmissão tardia no pré-natal (3º trimestre), considerar esquema contendo **ITRN + ATV/r + DTG** . A associação com INI nesse cenário visa garantir maior barreira genética e maior velocidade na indetecção de CV-HIV para o momento do parto.  
O Fluxograma 6 resume as principais recomendações para manejo de TARV na MVHIV em situação de abandono de tratamento e que engravida.  
Para mais informações a respeito da estruturação de esquemas de resgate, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos” e o “Manual Técnico para Avaliação de Exames de Genotipagem do HIV”, disponíveis em <u>http//www.aids.gov.br/pcdt.</u>  
Figura 6- Fluxograma de manejo de TARV na MVHIV em situação de abandono de TARV e que engravida  
<!-- Start of picture text -->
Gestante vivendo com HIV<br>Abandono de TARV*<br>Coletar CV-HIV, contagem de<br>LT-CD4<br>Abordar aspectos de adesão<br>Inicie TDF + 3TC + ATV/r**<br>*suplementação rotineira de<br>ferro durante a gestação<br>4-6 semanas após uso de  (40mg/dia de ferro<br>TARV: coletar CV-HIV e  elementar e associar ácido<br>genotipagem fólico na dose de 400<br>microgramas/dia até 12<br>semanas de IG<br>**em caso de readmissão<br>tardia (3º trimestre) para<br>reinício de TARV, considerar<br>Ajustar TARV de acordo com  associação com DTG no<br>a sensibilidade em  esquema de TARV<br>genotipagem, caso<br>necessário<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS  
Considerações sobre ARV na gestação:  
###### **Escolha dos ITRN**  
A associação tenofovir/lamivudina (TDF/3TC) é a preferencial nas gestantes infectadas pelo HIV, pois possui facilidade posológica (dose única diária), além de um perfil favorável em relação à lipoatrofia e à toxicidade hematológica, ambas associadas à zidovudina (AZT).  
###### **Esquemas alternativos:**  
Para os casos em que a dupla de ITRN (TDF/3TC) estiver contraindicada, deve-se proceder da seguinte maneira:  
||**Esquema alternativo**|
|---|---|
|Contraindicação ao TDF/3TC|1ª opção: utilizar AZT/3TC|
||2ª opção: utilizar ABC*/3TC|  
*Apenas nas gestantes com teste HLA-B*5701 negativo.  
**O ABC só deve ser utilizado em PVHIV que tenham teste para o HLA-B*5701 NEGATIVO,** pelo risco de hipersensibilidade. **O resultado deste exame deve ficar registrado no prontuário da mulher.**  
As gestantes que apresentarem contraindicação ao TDF, embora realizem a troca da medicação primeiramente pelo AZT, deverão já coletar HLA-B*5701 nesse momento. Isso evitará que, caso haja nova intolerância, a troca da medicação seja postergada pela ausência do exame que demonstra presença ou não de risco aumentado de hipersensibilidade ao ABC.  
###### **Escolha do INI**  
Evidencias científicas cada vez mais robustas vêm sustentando a importância dos inibidores de integrase na composição do esquema preferencial das pessoas vivendo com HIV, dada a sua superioridade quanto à maior barreira genética, tolerabilidade, supressão da carga viral e resposta imunológica (67–70).  
A **recomendação do uso de inibidor de integrase como droga de escolha para composição do esquema preferencial de gestantes** em início de tratamento uniformiza a escolha da TARV preferencial para início de tratamento no Brasil.  
A análise das evidências que corroboram para o uso do DTG a partir da 13ª semana de idade gestacional está presente no relatório de recomendações da Conitec que amplia  
o uso de DTG para GVHIV, disponível em <u>http://conitec.gov.br/images/Relatorios/2020/Relatorio_Dolutegravir_Gestante_HIV_515_202 0_FINAL.pdf.</u>  
###### **Considerações quanto aos ITRNN na gestação**  
O EFZ tem sua segurança comprovada na gestação por revisões sistemáticas e metanálises que excluíram a maior incidência de defeitos congênitos das crianças expostas no primeiro trimestre de gestação (Ford, 2014). Porém, uma questão a ser levada em consideração é o aumento mundial da incidência de resistência transmitida, que se dá quando um indivíduo se torna infectado com uma cepa de HIV-1 já resistente a uma ou mais drogas (59,62,71,72).  No relatório de monitoramento clínico das GVHIV, observou-se uma prevalência de 9% de resistência ao EFV nos exames de genotipagem pré-tratamento de gestantes (59).  
###### **Segurança dos ARV na gestação**  
A incidência de reações adversas em gestantes e crianças expostas a medicamentos ARV para profilaxia da transmissão vertical do HIV é baixa. Além de pouco frequentes, os efeitos adversos geralmente são transitórios e de intensidade leve à moderada, tanto nas gestantes quanto nas crianças. Tais efeitos raramente determinam a suspensão da utilização dos ARV, já que a eficácia desses medicamentos na PTV do HIV sobrepõe-se aos riscos das reações adversas. As alterações fisiológicas que ocorrem durante a gestação podem afetar a cinética da absorção, distribuição, biotransformação e eliminação dos medicamentos, alterando potencialmente a susceptibilidade da gestante à toxicidade aos diferentes fármacos.  
A associação entre o nascimento de crianças com malformações congênitas e a exposição aos ARV durante a vida intrauterina foi objeto de diversos estudos observacionais. Uma análise dos dados do registro americano e estudos realizados na Europa mostraram que a prevalência de malformações congênitas nessas crianças é semelhante à encontrada na população geral.  
Dados agregados sobre exposição aos ARV e malformações congênitas são disponibilizados pelo Registro de Antirretrovirais na Gestação (APR, do nome em inglês, disponível em <u>www.apregistry.com), com dados de toda Grã-Bretanha e Irlanda. Em relatos de casos</u> prospectivos, crianças expostas a AZT, 3TC, RTV, TDF, LPV, NVP e DRV demonstraram taxas de malformações congênitas dentro dos níveis esperados. O mesmo foi demonstrado mais  
recentemente para ABC, ATV e EFV. Para agentes mais recentes, como RAL, ETR, MVC e outros menos prescritos, como ENF/T20 e TPR, os dados são insuficientes quanto aos desfechos de exposição no primeiro trimestre para que possam ser excluídos riscos (73,74).  
###### **3.12.4. Manejo dos efeitos adversos da TARV**  
Os efeitos adversos mais comuns nas primeiras semanas de TARV em gestantes são semelhantes àqueles que ocorrem nos adultos em geral (Quadro 14).  
###### Quadro 14 - Manejo clínico dos efeitos adversos aos ARV  
|**ARV**|**Eventos adversos**<br>**Inibidores da transcriptase reversa análogos d**<br>|**Manejo**<br>**e nucleosídeo e nucleotídeo – ITRN(t)**<br>|
|---|---|---|
|ABC|Exantema e síndrome de Stevens Johnson, especialmente em<br>portadores de HLA-B*5701 positivo|Descontinuar o medicamento**(o uso do ABC só deve ser feito após**<br>**realização de teste para HLA-B*5701).**|
|AZT|Náuseas, anorexia, cefaleia, alterações no paladar, mal-estar e<br>insônia|Administrar sintomáticos e orientar manutenção da medicação, uma<br>vez que esses sintomas desaparecem ao longo da terapia, com<br>melhora considerável do apetite.|
||Anemia e neutropenia|O medicamento deve ser substituído caso Hb <10,0 g/dL e/ou<br>neutrófilos <1.000 céls/mm<sup>3</sup>.|
|3TC|Eventos adversos raros; pode ocorrer pancreatite ou neuropatia<br>periférica|Avaliação e acompanhamento.|
|TDF|Risco de toxicidade renal<br>Lesão renal aguda e síndrome de Fanconi<br>**Inibidores da transcriptase reversa não a**|Não iniciar TDF se doença renal prévia, TFGe <60 mL/min ou<br>insuficiência renal. Usar com precaução quando hipertensão não<br>controlada, diabetes não tratada, idoso ou baixo peso corporal.<br>**nálogos de nucleosídeo – ITRNN**|
|EFZ|Sintomas associados ao sistema nervoso central, tais como<br>tonturas, sensação de “embriaguez”, sonolência ou insônia,<br>dificuldade de concentração e sonhos vívidos (sensação forte de<br>realidade). Farmacodermias do tipo_rash_cutâneo|Orientar sobre tais eventos e informar que normalmente<br>desaparecem ao final das primeiras semanas de tratamento.<br>Os efeitos adversos neurológicos podem ser exacerbados com o uso<br>concomitante de álcool. É necessário abordar o uso recreativo de<br>álcool e outras drogas.<br>No caso de farmacodermia, avaliar medicação sintomática ou<br>necessidade de suspensão do medicamento.|  
|**ARV**|**Eventos adversos**|**Manejo**|
|---|---|---|
|NVP|Exantema (7%), geralmente maculopapular, de tipo eritema<br>multiforme; menos de 1% progride para Síndrome de Stevens-<br>Johnson ou para necrólise epidérmica tóxica<br>**Inibidores de pro**<br>|Suspender quando o exantema cutâneo for extenso, comprometer<br>mucosas, estiver associado a manifestações semelhantes a um<br>resfriado e/ou houver ocorrência de linfadenopatia. Das pessoas que<br>apresentam esse tipo de reação à NVP, 40% não demonstram reação<br>cruzada com o EFZ.<br>**tease – IP**|
|ATV/r|Náuseas, vômitos, diarreia, exantema, cefaleia, tontura<br>Aumento da bilirrubina total, às custas da fração indireta (35% a<br>47% dos casos), com icterícia em alguns casos. Elevação das<br>transaminases pode ocorrer em cerca de 2% a 7% dos casos|A ocorrência de icterícia pode afetar a imagem e a autoestima da<br>gestante, devendo, portanto, ser cuidadosamente avaliada e<br>considerada a suspensão do medicamento quando houver<br>desconforto para a pessoa.|
|DRV/r<br>RAL|Contém frações de sulfa. Pode ocorrer exantema (17% dos<br>tratados, mas taxa de 0,3% de descontinuação), náusea (18%) e<br>cefaleia (15%)<br>Disfunção hepática ocasional precoce no início do tratamento<br>**Inibidores de inte**<br>Relatos de casos de aumento de transaminases no terceiro<br>trimestre da gestação|Monitorar função hepática, especialmente nos primeiros meses e se<br>houver histórico de doença hepática pré-existente.<br>**grase – INI**<br>Reversíveis com a retirada da droga.|
|DTG|Bem tolerado; os efeitos adversos são incomuns: insônia (<3%),<br>cefaleia (<2%), náuseas e vômitos (<1%),_rash_(<1%). Atentar para<br>ganho de peso.|Raros relatos de reação de hipersensibilidade e aumento de<br>transaminases em pacientes coinfectados com hepatites virais.|  
Fonte: DCCI/SVS/MS.  
Para mais informações sobre o manejo dos efeitos adversos aos ARV, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”, disponível em <www.aids.gov.br/pcdt>.  
**3.12.5. Síndrome Inflamatória da Reconstituição Imune na gestante vivendo com HIV/aids**  
A reconstituição imune é uma das metas da TARV. Em algumas situações, observa-se um quadro clínico de caráter inflamatório exacerbado, chamado Síndrome Inflamatória da Reconstituição Imune (SIR), que está relacionada ao início da TARV e à recuperação do sistema imunológico da pessoa em queda de carga viral do HIV. Portanto, a SIR pode ser definida como uma piora da condição clínica do paciente após início da TARV, atribuída à recuperação da resposta imune a patógenos viáveis ou inviáveis (75).  
Para mais informações sobre o diagnóstico e o manejo da SIR, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”, disponível em <u>www.aids.gov.br/pcdt.</u>  
**3.13. Profilaxia de infecções oportunistas na gestante vivendo com HIV/ AIDS**  
Nenhum dado, até o momento, demonstra que o espectro das IO seja diferente entre as gestantes e mulheres não grávidas quando comparadas em relação à mesma contagem de LTCD4+. No entanto, fatores fisiológicos durante a gestação, como aumento do débito cárdico e do volume plasmático, alteração do volume respiratório corrente e transferência transplacentária de substâncias, podem dificultar o reconhecimento das IO e alterar a farmacocinética das substâncias envolvidas no tratamento.  
Os procedimentos necessários ao diagnóstico de IO suspeitas em gestantes devem ser realizados da mesma forma como indicados para mulheres não grávidas, respeitando as especificidades gerais inerentes ao método diagnóstico, de acordo com a idade gestacional, do modo como é feito para mulheres sem HIV.  
A profilaxia de IO proporciona uma importante redução da morbimortalidade em pessoas com disfunção imune secundária à infecção pelo HIV. Essa prevenção tem dois aspectos principais: a profilaxia primária e a secundária.  
Para informações detalhadas sobre o manejo clínico das IO, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Adultos”, disponível em <www.aids.gov.br/pcdt>.  
###### **3.13.1. Profilaxia primária**  
É uma estratégia que visa evitar o desenvolvimento de IO. O principal parâmetro para orientar a introdução ou suspensão de profilaxia é a contagem de LT-CD4+, uma vez que o risco de IO está diretamente associado ao nível dessas células de defesa.  
A síntese de critérios para início e suspensão das profilaxias, bem como de esquemas recomendados para gestantes não é diferente das recomendações para PVHIV de maneira geral (Quadro 15). Contudo, atenção especial deve ser dada nos casos que necessitem de uso de sulfametoxazol-trimetoprim (SMX-TMP), pelo potencial risco de teratogenicidade se administrado no primeiro trimestre ou pelo aumento do risco de do risco de hiperbilirrubinemia e _kernicterus_ se administrado próximo ao parto.  
Quadro 15 – Profilaxia primária das infecções oportunistas (evitar o primeiro episódio de doença)  
|Agente|Indicação|1ª escolha|Alternativas|Critérios de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|---|
|_Pneumocystis_<br>_jiroveci_|**LT-CD4+**<br>**<200**<br>**céls/mm**<sup>**3**</sup><br>(ou<br><14%)<br>ou<br>presença<br>de<br>candidíase oral<br>ou<br>febre<br>indeterminada<br>com<br>mais<br>de<br>duas semanas de<br>duração<br>ou<br>doença<br>definidora<br>de<br>aids|SMX-TMP<br>800mg/160mg<br>3x/semana|Dapsona<br>100mg/dia|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>200<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>3<br>meses.<br>**Reintroduzir**<br>**profilaxia se LT-**<br>**CD4+**<br>**<200**<br>**céls/mm**<sup>**3**</sup>.|SMX-TMP é a medicação de escolha tanto para<br>profilaxia quanto para tratamento.<br>Devido à preocupação com os riscos teóricos de<br>possível teratogenicidade associada à exposição<br>medicamentosa durante o 1º trimestre, deve ser<br>discutida com gestante e profissional de saúde a<br>manutenção da profilaxia durante esse período.<br>Usar dose habitual de suplementação com ácido<br>folínico recomendada para gestantes.<br>Também promove profilaxia contra toxoplasmose.<br>Neonatologistas devem ser avisados do uso de<br>sulfa ou dapsona próximos ao parto pelo aumento<br>teórico<br>do<br>risco<br>de<br>hiperbilirrubinemia<br>e<br>_kernicterus._|
|_Toxoplasma_<br>_gondii_|**LT-CD4+**<br>**<100**<br>**céls/mm**<sup>**3**</sup>e IgG<br>anti-_T._<br>_gondii_<br>reagente|SMX-TMP<br>800mg/160mg<br>1x/dia|Riscos associados<br>à<br>teratogenicidade<br>da pirimetamina<br>devem<br>ser|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>200<br>céls/mm<sup>3</sup><br>por|SMX-TMP pode ser administrado, levando em<br>consideração as mesmas observações quanto à<br>profilaxia para PCP.<br>Todas as gestantes devem seguir as mesmas<br>recomendações das mulheres sem HIV quanto à<br>prevenção do contato com_T.gondii_,testagem|  
|Agente|Indicação|1ª escolha|Alternativas|Critérios de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|---|
||||levados<br>em<br>consideração.|mais<br>de<br>3<br>meses.<br>**Reintroduzir**<br>**profilaxia se LT-**<br>**CD4+**<br>**<100**<br>**céls/mm**<sup>**3**</sup>**.**|sorológica para anticorpo IgG e IgM para<br>toxoplasma e a conduta realizada para cada perfil<br>sorológico (58).<br>Gestantes devem ser aconselhadas a não consumir<br>ou manipular carnes cruas ou mal passadas; isso<br>inclui cuidados com armazenamento das carnes e<br>limpeza dos utensílios na cozinha. Devem ainda ser<br>orientadas quanto à adequada higienização de<br>frutas e vegetais antes de consumi-los crus. Usar<br>luva e higienizar bem as mãos após manipulação do<br>solo. Se possuírem gatos, a caixa de areia deve ser<br>higienizada diariamente, preferencialmente por<br>outra pessoa que não a gestante. Os gatos devem<br>ser mantidos dentro de casa, e não é aconselhável<br>interagir com animais não domésticos durante o<br>período da gestação. É necessário, ainda, ter<br>cuidado com a alimentação dos gatos, dando<br>preferência às rações industrializadas ou alimentos<br>domésticos bem cozidos.<br>Profissional de saúde e gestante devem discutir<br>benefícios da profilaxia contra toxoplasmose e a<br>preocupação relacionada à teratogenicidade da<br>pirimetamina.<br>Em casos raros, gestantes com toxoplasmose<br>confirmada podem transmitir_T. gondii_para o feto<br>no útero. RN expostos devem ser avaliadosquanto|  
|Agente|Indicação|1ª escolha|Alternativas|Critérios de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|---|
||||||à possibilidade de ocorrência de toxoplasmose<br>congênita.|
|_Mycobacterium_<br>_tuberculosis_<br>(tuberculose<br>latente)|Contagem de LT<br>CD4+ menor ou<br>igual a 350 céls/<br>mm<sup>3</sup>;PT<br>>5mm<br>ou história de<br>contato<br>com<br>paciente<br>bacilífero<br>ou<br>radiografia<br>de<br>tórax<br>com<br>cicatriz de TB<br>sem tratamento<br>prévio.|Isoniazida<br>5mg/kg/dia<br>(máximo<br>300mg/dia)<br>A associação com<br>piridoxina<br>50mg/dia<br>pode<br>reduzir o risco de<br>neuropatia||**Duração de 6-9**<br>**meses**<br>**para**<br>**isoniazida**<br>**(preferencial-**<br>**mente**<br>**a**<br>**utilização**<br>**de**<br>**270 doses em**<br>**9-12 meses).**|É seguro e deve ser realizado durante a gravidez,<br>após o primeiro trimestre.|
|Complexo<br>_Mycobacterium_<br>_avium_|**LT-CD4+**<br>**<50**<br>**céls/mm**<sup>**3**</sup>|Azitromicina<br>1.200-<br>1.500mg/semana|Claritromicina<br>500mg 2x/dia|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>100<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>3<br>meses.<br>**Reintroduzir**<br>**profilaxia se LT-**||  
|Agente|Indicação|1ª escolha|Alternativas|Critérios de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|---|
|||||**CD4+**<br>**<50céls/mm**<sup>**3**</sup>**.**||
|_Cryptococcus sp._|Não se indica prof|ilaxia primária para|criptococose e hist|oplasmose.||
|_Histoplasma_<br>_capsulatum_|Evitar situações d<br>de pássaros e mor|e risco, tais como en<br>cegos.|trar em cavernas o|u se expor a fezes||
||Não se indica prof|ilaxia primária.||||
|Citomegalovírus|Recomenda-se dia<br>rotineira em PVHI|gnóstico precoce d<br>V com LT-CD4+ <50|e retinopatia por fu<br>céls/mm<sup>3</sup>.|ndoscopia||
|Herpes simplex|**Não se indica pro**|**filaxia primária.**||||  
Fonte: DCCI/SVS/MS.  
###### **3.13.2. Profilaxia secundária**  
Essa estratégia tem como objetivo evitar a recidiva de IO já ocorrida e que já tenha recebido tratamento completo. As recomendações de profilaxias secundárias estão resumidas no Quadro  
16, a seguir.  
Quadro 16 – Profilaxia secundária das IO e considerações quanto ao tratamento  
|Agente|1ª escolha|Alternativas|Critério de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|
|_Pneumocystis_<br>_jiroveci_|SMX-TMP 800mg/<br>160mg 3x/semana|Dapsona 100mg/dia|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>200<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>3<br>meses.|**SMX-TMP é a medicação de escolha tanto para profilaxia**<br>**quanto para tratamento.**|
|_Toxoplasma_<br>_gondii_|Peso<br><60kg:<br>sulfadiazina<br>500mg<br>4x/dia + pirimetamina<br>25mg 1x/dia + ácido<br>folínico 10mg 1x/dia<br>Peso >60kg:<br>sulfadiazina 1.000mg<br>4x/dia + pirimetamina<br>50mg 1x/dia + ácido<br>folínico 10mg 1x/dia|SMX-TMP<br>(800mg/160mg) 2x/ dia<br>ou<br>Clindamicina<br>600mg<br>3x/dia + pirimetamina<br>25-50mg 1x/dia + ácido<br>folínico 10mg 1x/dia<br>(Acrescentar cobertura<br>profilática para PCP)|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>200<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>6<br>meses.|**O tratamento deve ser o mesmo de adultos não gestantes.**<br>**Os pediatras devem ser alertados sobre o****_status_ sorológico**<br>**materno quanto ao****_T. gondii_ para proceder a investigação**<br>**quanto à ocorrência de toxoplasmose congênita.**|  
|Agente|1ª escolha|Alternativas|Critério de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|
|Complexo<br>_Mycobacterium_<br>_avium_|Claritromicina 500mg<br>2x/dia + etambutol<br>15mg/kg/dia (máximo<br>1.200mg/dia)|Azitromicina<br>500mg<br>1x/dia<br>+<br>etambutol<br>15mg/kg/dia<br>(máximo<br>1.200mg/dia)|Após um ano de<br>tratamento<br>para MAC, na<br>ausência<br>de<br>sintomas e LT-<br>CD4+<br>>100<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>6<br>meses.<br>**Reintroduzir se**<br>**LT-CD4+**<br>**<100**<br>**céls/mm**<sup>**3**</sup>||
|_Cryptococcus sp._|Fluconazol 200mg<br>1x/dia|Itraconazol<br>200mg<br>2x/dia ou anfotericina B<br>desoxicolato<br>1mg/kg<br>1x/semana|Término<br>do<br>tratamento de<br>indução<br>e<br>consolidação e<br>pelo menos 1<br>ano<br>de<br>manutenção,<br>assintomático e<br>LT-CD4+<br>>200céls/mm<sup>3</sup><br>por mais de 6<br>meses.||  
|Agente|1ª escolha|Alternativas|Critério de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|
|_Isospora belli_|SMX-TMP<br>(800mg/160mg)<br>três<br>vezes por semana|Pirimetamina<br>25mg<br>1x/dia + ácido folínico<br>10mg 3x/semana|**Não**<br>**há**<br>**recomendação**<br>**específica. No**<br>**entanto,**<br>**indica-se**<br>**a**<br>**suspensão**<br>**da**<br>**profilaxia com**<br>LT-CD4+<br>>200<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>3<br>meses.||
|Citomegalovírus|Ganciclovir<br>EV<br>5mg/kg/dia<br>5x/semana<br>**(apenas para retinite,**<br>**não**<br>**indicado**<br>**rotineiramente para**<br>**doença**<br>**gastrointestinal)**|Foscarnet 90-120mg/kg<br>1x/dia|**Boa resposta à**<br>**TARV**<br>**com**<br>manutenção de<br>LT-CD4+<br>>100<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>3-6<br>meses||  
|Agente|1ª escolha|Alternativas|Critério de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|
|Histoplasmose<br>**(doença**<br>**disseminada ou**<br>**infecção do**<br>**SNC)**|Itraconazol 200mg<br>1x/dia||**Manutenção**<br>**por**<br>**tempo**<br>**indeterminado,**<br>**pois**<br>**não**<br>**há**<br>**evidência**<br>**suficiente para**<br>**recomendação**<br>**de interrupção**<br>**do itraconazol.**<br>Considerar<br>suspensão após<br>período<br>mínimo de um<br>ano<br>de<br>tratamento de<br>manutenção,<br>ausência<br>de<br>sintomas e LT-<br>CD4+<br>>150<br>céls/mm<sup>3</sup><br>por<br>mais<br>de<br>6<br>meses||  
|Agente|1ª escolha|Alternativas|Critério de<br>suspensão|Especificidades para a gestante|
|---|---|---|---|---|
||||**Reintroduzir se**<br>**LT-CD4+**<br>**<150**<br>**céls/mm**<sup>**3**</sup>**.**||
|Herpes simplex<br>**(infecção**<br>**recorrente: >6**<br>**episódios/ano)**|Aciclovir 400mg<br>2x/dia||||
|Candidíase<br>esofágica|**Não se indica a profilax**|**ia secundária para cand**|**idíase esofágica.**||  
Fonte: DCCI/SVS/MS.  
###### **3.14. Coinfecções na gestante vivendo com HIV/AIDS**  
###### **3.14.1.  Coinfecção HIV e tuberculose**  
###### **Critérios para início do tratamento antirretroviral na coinfecção HIV-TB na gestante**  
A TB é a principal causa de óbito por doença infecciosa em mulheres no mundo e a mais importante causa de morbimortalidade em mulheres vivendo com HIV em regiões com recursos limitados. A maior taxa de coinfecção TB-HIV em mulheres ocorre na idade reprodutiva, entre 15 e 49 anos. As gestantes vivendo com HIV e que desenvolvem TB apresentam risco 2,5 vezes maior de transmissão do HIV para o RN que as gestantes infectadas pelo HIV e sem TB.  
Gestantes vivendo com HIV com diagnóstico de TB ativa devem iniciar TARV assim que possível, independentemente da apresentação clínica do agravo. O retardo do tratamento para o HIV está associado a uma maior letalidade e maior risco de TV do HIV.  
###### **Manejo do tratamento da coinfecção HIV/TB na gestante**  
A gestante com TB deve ser tratada com **Esquema Básico para Tratamento da TB em adultos e adolescentes** (disponível no “Manual de Recomendações para o Controle da Tuberculose no Brasil”, em <u>http://bvsms.saude.gov.br/bvs/publicacoes/manual_recomendacoes_controle_tuberculose_b rasil.pdf), constituído por uma primeira fase intensiva com duração de dois meses e esquema</u> composto por rifampicina, isonizaida, pirazinamida, etambutol, e uma segunda fase de manutenção de quatro meses e esquema que inclui rifampicina e isoniazida.  
O esquema deve ser administrado nas doses habituais ajustadas ao peso, quando for o caso, e está recomendado o uso de **piridoxina na dose de 50mg/dia durante a gestação** , pela potencial toxicidade neurológica da isoniazida na mulher e no RN.  
A genotipagem pré-tratamento também está indicada para todos os pacientes coinfectados com TB e HIV (PVHIV virgem de TARV), de forma a orientar o esquema terapêutico, se houver necessidade da mudança deste. Contudo, ressalta-se que o início da TARV não deve ser adiado pela não obtenção do resultado desse exame.  
Recomenda-se que gestantes coinfectadas com LT-CD4+ abaixo de 50 céls/mm³ ou com sinais de imunodeficiência avançada comecem a TARV dentro de duas semanas após o início do tratamento para TB. Nos demais casos, deve-se iniciar a TARV após 8 semanas de tratamento da tuberculose. Não se recomenda o início concomitante do tratamento para ambos os agravos.  
Os esquemas mais seguros para gestantes até a 12ª semana de idade gestacional em uso de rifampicina são a associação de ITRN + ITRNN:  
 **TDF + 3TC + EFZ***  
**_*o uso de EFZ está condicionado à realização de exame de genotipagem pré-tratamento_**  
Casos de gestantes com coinfecção TB-HIV, idade gestacional inferior a 12 semanas, com impossibilidade de uso de EFZ (genotipagem que evidencia resistência, história prévia de abandono, efeitos adversos) e que necessitem introduzir TARV imediatamente devem ser discutidos com a câmara técnica para decisão do melhor esquema terapêutico.  
Os esquemas mais seguros para gestantes após a 12ª semana de idade gestacional em uso de rifampicina são a associação de ITRN + INI:  **TDF + 3TC + DTG* ou** ITRN + ITRNN:  **TDF + 3TC + EFZ**  
###### **_*a dose do DTG deve ser de 50 mg, duas vezes ao dia durante o uso concomitante com rifampicina_**  
A rifampicina é um potente indutor do citocromo P450, reduzindo as concentrações plasmáticas de medicamentos que utilizam essa mesma via metabólica − no caso dos ARV, os IP e os ITRNN. Dessa maneira, a seleção de um esquema ARV com os medicamentos atualmente disponíveis implica poucas opções frente à oscilação dos níveis séricos de ITRNN e IP provocada pelo uso da rifampicina.  
Dados clínicos sobre eficácia e segurança do DTG coadministrado com rifampicina nos casos de coinfecção HIV-TB mostram que o DTG precisa de dose dobrada (50 mg duas vezes ao dia) por conta da interação medicamentosa com rifampicina. Essa combinação mostra-se bem tolerada, com equivalente eficácia em supressão viral e recuperação imunológica (Dooley et al., 2019; WHO, 2019b).  
Deve-se levar em consideração que os esquemas com dose fixa combinada uma vez ao dia têm impacto na adesão e isso deve ser discutido junto à gestante, especialmente nas situações de necessidade de tomadas diárias de outras medicações.  
###### **Manejo de gestantes multiexperimentadas na coinfecção HIV-TB**  
O manejo ARV de gestantes que apresentam falha terapêutica e utilizam esquemas de resgate deve ser estruturado por médicos experientes em TARV.  
O uso de IP na coinfecção deve ser reservado para situações em que não é possível estruturar um esquema ativo com associação de INI. No caso da administração de IP/r com rifampicina, esta deve ser substituída pela rifabutina.  
A rifabutina é um medicamento pertencente à categoria B da _Food and Drug Administration_ (FDA), órgão de referência americano. Isso quer dizer que estudos em animais não mostraram efeitos teratogênicos nos conceptos. Até o momento, não existem ensaios clínicos controlados em mulheres e o uso do medicamento em gestantes deve ser considerado somente se os benefícios justificarem possíveis riscos para os fetos.  
###### **3.14.2. Coinfecção HIV e hepatites virais**  
###### **Rastreamento de hepatites virais na gestante vivendo com HIV/aids**  
Todas as mulheres vivendo com HIV/aids devem ser testadas para HBV e HCV quando do início dos cuidados.  
As gestantes com resultado não reagente para hepatite B (HBsAg não-reagente) e sem histórico de vacinação devem receber vacina para HBV, de acordo com as recomendações do Programa Nacional de Imunizações Essas informações estão disponíveis em  
<u>http://portalsaude.saude.gov.br/index.php/o-ministerio/principal/leia-mais-o-ministerio/197secretaria-svs/13600-calendario-nacional-de-vacinacao.</u>  
Mulheres vivendo com HIV que apresentem resultados não reagentes para hepatite A (anti-HAV IgG negativo) devem receber esquema vacinal para hepatite A.  
###### **Coinfecção HIV-HBV em gestantes**  
A coinfecção HIV-HBV é associada à progressão acelerada para hepatite crônica e a uma maior mortalidade (78–80). Por essa razão, está **recomendado o tratamento de todas as pessoas coinfectadas HIV-HBV, independentemente dos resultados de HBeAg, CV-HBV e ALT.**  
Gestantes com coinfecção HBV-HIV devem receber combinação de ARV, incluindo esquema que contenha TDF.  
O tratamento baseado em TDF para as gestantes coinfectadas com HIV é parte do conjunto de medidas necessárias para promover a PTV do HBV (Wang et al., 2016).  
Nos casos de modificação de TARV por falha virológica ao HIV, o TDF deverá ser mantido como tratamento contra o HBV, em combinação com outros ARV, com atividade adequada à supressão viral do HIV.  
É importante que as gestantes coinfectadas HIV-HBV em uso de TARV sejam aconselhadas sobre sinais e sintomas de toxicidade hepática e que isso seja levado em consideração durante a escolha da terapêutica a ser instituída. As transaminases hepáticas devem ser monitoradas um mês após o início de TARV, e de forma contínua, com intervalos a serem definidos de acordo com os medicamentos em uso e o aparecimento de sinais e sintomas.  
Mais informações sobre o manejo da gestante com hepatite B e da criança exposta podem ser encontradas na seção específica deste PCDT-TV, na **Parte V – Transmissão Vertical de Hepatites Virais** .  
Para mais informações sobre diagnóstico, manejo e tratamento da hepatite B, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e Coinfecções”, disponível em <u>www.aids.gov.br/pcdt.</u>  
###### **Coinfecção HIV-HCV em gestantes**  
Está recomendada a pesquisa anual de HCV para toda PVHIV (WHO, 2016a; WHO, 2016b), inclusive gestantes. É importante considerar, ainda, que as situações de risco de exposição podem se repetir ao longo de toda a vida de qualquer indivíduo, inclusive mulheres gestantes, e devem ser investigadas de forma ativa.  
As mulheres vivendo com HIV coinfectadas com hepatite C deverão ser priorizadas para o tratamento da hepatite C.  
###### **Na população de mulheres coinfectadas HIV-HCV, o risco de transmissão vertical da hepatite**  
**C é duas vezes maior que na população geral** . Além disso, a coinfecção está associada a menor clareamento espontâneo do HCV, maior CV-HIV e progressão mais rápida da doença hepática (82,83).  
Embora ainda não existam imunoprofilaxias ou intervenções medicamentosas que possam prevenir a transmissão vertical da hepatite C, o diagnóstico precoce da mulher permite manejo menos invasivo durante o parto, seguimento em serviço de pré-natal de alto risco e indicação de tratamento após a gestação, assim como seguimento da criança exposta que também deverá ser tratada oportunamente, quando for o caso (84,85).  
O tratamento da hepatite C durante a gestação está contraindicado, em vista dos efeitos teratogênicos da ribavirina e da alfapeguinterferona e da ausência de estudos que garantam a segurança no uso dos novos medicamentos, os DAA. **A gravidez deverá ser evitada durante todo o tratamento contra hepatite C e durante os seis meses seguintes ao seu término** . Caso se opte pelo tratamento da hepatite C, após a resolução da gestação, a mulher deverá ser referenciada para consulta com especialista. Os indivíduos coinfectados são considerados prioritários para tratamento.  
É importante que as gestantes coinfectadas HIV-HCV em uso de TARV sejam aconselhadas sobre sinais e sintomas de toxicidade hepática.  
**Em gestantes coinfectadas HIV-HCV, as transaminases hepáticas devem ser monitoradas um mês após o início de TARV, e de forma contínua,** com intervalos a serem definidos de acordo com o medicamento em uso e o aparecimento de sinais de sintomas.  
Mais informações sobre o manejo da gestante com hepatite C e da criança exposta podem ser encontradas na seção específica deste PCDT-TV.  
**3.15. Manejo das intercorrências obstétricas nas gestantes vivendo com HIV/AIDS**  
As complicações clínicas associadas à gestação, como a hipertensão e o Diabete Melito (DM) gestacional, são manejadas da mesma forma em gestantes infectadas ou não infectadas pelo HIV, independentemente do _status_ imunológico. A pré-eclâmpsia, a síndrome HELLP, a colestase hepática e a insuficiência hepática aguda são **distúrbios associados à gestação e podem ser confundidos com os efeitos adversos dos ARV** . Portanto, é necessário realizar o diagnóstico diferencial de possíveis efeitos adversos associados ao uso de ARV. A utilização de IP também está relacionada ao desenvolvimento de hiperglicemia, DM e agravamento de distúrbios metabólicos da glicose e dos lipídios.  
A seguir, serão apresentadas as principais complicações obstétricas em gestantes vivendo com  
Dados de uma recente revisão sistemática mostraram que **mulheres vivendo com HIV/aids apresentaram risco três vezes maior de sepse puerperal** quando comparadas a mulheres não infectadas. Para outras complicações obstétricas, a evidência científica é fraca e inconsistente.  
HIV que merecem atenção do profissional de saúde (86).  
###### **Hemorragia pós-parto**  
Quando ocorrer hemorragia pós-parto por atonia uterina, **não se deve administrar derivado do ergot** se as parturientes fizerem uso de medicamentos **inibidores da enzima citocrômica P** , **CYP450 e CYP3A4 (inibidores de protease** , além de antibióticos macrolídeos). O uso concomitante de IP e derivados do ergot está associado a respostas vasoconstritoras exageradas e isquemias periféricas e centrais graves. O uso concomitante dessas substâncias está  
contraindicado; caso necessário, deve ser utilizado na menor dose efetiva, pelo menor tempo possível. Havendo condições clínicas, preferir ocitocina ou misoprostol.  
Em mulheres que estejam recebendo indutores da enzima CYP3A4, como NVP, EFV, ou ETR, agentes uterotônicos adicionais podem ser necessários em virtude da potencial diminuição dos níveis séricos e efeito terapêutico inadequado.  
###### **Hiperêmese gravídica**  
Para gestantes com hiperêmese gravídica, em que medidas gerais não controlam náuseas e vômitos, podem ser indicados antieméticos como a ondansetrona, além de vitamina B6 e antihistamínicos. Essas medicações não determinam interações farmacológicas expressivas com os ARV. A metoclopramida apresenta risco de liberação de sistema extrapiramidal e não deve ser indicada para manejo de hiperêmese gravídica.  
Mulheres com hiperêmese gravídica refratária ao manejo farmacológico inicial devem ser internadas em ambiente hospitalar, para melhor manejo clínico. Na ocorrência de êmese grave, considerar a retirada de todo o esquema ARV durante o período de impossibilidade de uso regular da medicação, que deve ser reiniciada após a melhora evidente dos sintomas, para evitar doses inadequadas e possibilidade de resistência viral. Nesses casos, estará indicada internação hospitalar, sendo uma opção o uso de antieméticos via endovenosa.  
Importante ainda reforçar que a hiperêmese pode afetar a biodisponibilidade dos antirretrovirais e levar à falha virológica. Essas mulheres devem ter CV-HIV monitorada para avaliar risco de transmissão vertical do HIV.  
Orientações específicas devem ser dadas às gestantes em uso de ARV, a fim de evitar transtornos gastrintestinais, que podem agravar os sintomas próprios da gestação.  
###### **Rotura Prematura de Membranas (RPM)**  
A RPM é uma complicação da gestação associada ao parto pré-termo. Tanto a RPM quanto a prematuridade estão associadas a um maior risco de TV do HIV.  
A conduta na RPM tem como parâmetro a idade gestacional de 34 semanas:  
###### **RPM em idade gestacional inferior a 34 semanas**  
Associada a um período de latência (sem trabalho de parto) longo, que pode durar até algumas semanas. Na ausência de corioamnionite e sofrimento fetal, recomenda-se medida semiconservadora, com observação e utilização de medicamentos que melhorem o prognóstico materno e perinatal.  
Sugere-se:  
- hiper-hidratação oral na presença de oligoâmnio;  
- utilização de corticoide (betametasona ou dexametasona), entre 23 e 34 semanas, para aceleração da maturidade pulmonar fetal; e  
- antibioticoterapia visando o estreptococo do grupo B.  
Na ocorrência de RPM pré-termo, está indicado o uso de **penicilina G cristalina** para prolongar o período de latência e para prevenção da morbimortalidade perinatal pelo estreptococo do grupo B, assim como para tratamento da infecção intraamniótica, se presente. Pode-se considerar ainda o uso de ampicilina e de clindamicina.  
###### **RPM em idade gestacional superior a 34 semanas**  
Para gestantes portadoras do HIV, com mais de 34 semanas e complicadas com ruptura prematura das membranas, a resolução da gravidez deve ser discutida, considerando fatores como trabalho de parto, valor da carga viral coletada com 34 semanas de IG e presença de infecção intrauterina.  
CV-HIV maior ou igual a 1000 cópias/ml coletada com 34 semanas de IG com indicará a via de parto e a presença de infecção intrauterina sustentará a indicação de antimicrobianos para tratar a corioamnionite. Caso não haja infecção e a gestante seja portadora do estreptococo do grupo B ou não conheça sua condição de portadora, estará indicada a profilaxia da septicemia de início precoce com penicilina cristalina.  
Na mulher em trabalho de parto e com bolsa rota, é preciso avaliar as condições de evolução do trabalho de parto e o risco de complicações. Frente à previsão de um parto demorado ou distócico, deve-se considerar a resolução por cesariana, fato que independe da corioamniorrexe.  
Sabendo-se que o tempo de trabalho de parto com cargas virais acima de 1000 cópias/ml está associado a maior ocorrência de TV do HIV, nas situações de colo desfavorável e ausência de atividade uterina, deve-se indicar a realização de parto por cesárea, com a intenção de evitar induções prolongadas.  
Caso as condições do colo do útero sejam favoráveis e a gestante estiver em uso de TARV, com CV-HIV menor que 1000 cópias/ml e apresentação cefálica, a via de parto pode ser vaginal. Essa decisão deve ser tomada junto com a gestante. Nesse cenário, pode-se utilizar ocitocina e misoprostol para induzir ou estimular o trabalho de parto.  
###### **Sangramento vaginal na gestação**  
O manejo do sangramento vaginal na primeira metade da gravidez independe da condição imunológica da gestante vivendo com HIV/aids. Não existem evidências de que a infecção pelo HIV, _per se_ , aumente o risco de abortamento e perdas fetais.  
###### **Trabalho de parto pré-termo**  
A presença de infecção pelo HIV não interfere no manejo do trabalho de parto pré-termo (TPP). É preciso avaliar: (i) os possíveis fatores desencadeantes do TPP, como anemia, infecção urinária e outras doenças maternas, principalmente as infecções cérvico-vaginais, e (ii) o bem-estar fetal.  
Como regra geral, se o TPP ocorrer antes de 34 semanas, a conduta expectante parece ser a mais adequada, em razão dos maiores riscos da prematuridade para o RN do que aqueles devidos à TV do HIV e à tentativa de inibição do parto. Assim, as condutas padronizadas incluem a introdução do **AZT intravenoso** materno concomitantemente à inibição medicamentosa do parto, a investigação de causas infecciosas e seus respectivos tratamentos e o uso de corticosteroides para maturação pulmonar quando indicado, sendo o esquema mais frequentemente utilizado o da betametasona intramuscular, aplicada em duas doses de 12mg, com intervalo de 24 horas. Ao se conseguir a inibição do parto, o AZT intravenoso deve ser descontinuado.  
No caso de TPP em que se decida pela conduta ativa, recomenda-se escolher a via de parto com base na CV-HIV materna e em indicações obstétricas, com infusão de AZT intravenoso, evitandose trabalho de parto prolongado em virtude do maior risco de TV do HIV. Até 32 semanas, estará indicado o uso de sulfato de magnésio endovenoso para proteção do encéfalo fetal.  
O uso de tocolíticos no contexto intra-hospitalar, como em qualquer situação de TPP, está indicado para postergar o parto por no mínimo 48 horas.  
A pesquisa de colonização pelo estreptococo do grupo B está indicada, com a coleta de conteúdo vaginal e retal com _swab_ e cultura em meio seletivo. Em caso de resultado positivo, o tratamento é realizado com penicilina G cristalina, com início durante o trabalho de parto até o nascimento, para reduzir a morbimortalidade perinatal associada à infecção neonatal. Caso não seja possível realizar a pesquisa do estreptococo do grupo B, deve-se considerar a administração de penicilina G cristalina, já que o parto pré-termo é um dos fatores que mais aumentam a morbimortalidade perinatal pelo estreptococo do grupo B, conforme a avaliação dos fatores de risco listados abaixo:  
- idade gestacional inferior a 37 semanas;  
- febre durante o período do parto (acima de 38°C);  
- rotura de membrana em período superior a 18 horas; e  
- ocorrência de infecção fetal por estreptococo do grupo B em gestações anteriores.  
###### **Conduta em caso de necessidade de realização de procedimento invasivo**  
Para gestantes com polidrâmnio e que tenham necessidade de **invasão âmnica** (para drenagem de líquido amniótico ou isoimunização Rh), a **utilização EV de AZT 2mg/kg peso materno, três horas antes da punção** , pode reduzir o risco de TV do HIV (Duarte et al., 2004).  
É importante realizar uma avaliação de risco e benefício do procedimento, levando em consideração a CV-HIV da gestante, especialmente em caso de mulheres que estejam com a CVHIV detectável.  
- **3.16. Manejo obstétrico e vias de parto na gestante vivendo com HIV**  
**3.16.1.  Indicação da via de parto em gestantes vivendo com HIV/AIDS**  
Em mulheres com **CV desconhecida ou maior que 1.000 cópias/mL** após 34 semanas de gestação, a **cesárea eletiva a partir da 38ª semana** de gestação diminui o risco de TV do HIV.  
Para gestantes **em uso de ARV e com supressão da CV-HIV sustentada** , caso não haja indicação de cesárea por outro motivo, a **via de parto vaginal** é indicada.  
Em mulheres com **CV-HIV <1.000 cópias/mL, mas DETECTÁVEL,** pode ser realizado parto vaginal, se não houver contraindicação obstétrica. **No entanto, o serviço deve estar ciente de que essa mulher tem indicação de receber AZT intravenoso.**  
Vale reforçar a recomendação que o parto vaginal é a via de escolha nas gestantes com CV-HIV, menor que 1000 cópias/ml a partir da 34ª semana. Abaixo dessa contagem, a cesariana não é fator estatisticamente relevante para prevenção de TV-HIV e se mostra como importante causa de morbidade nessa população ( Macdonald et al _._ , 2015). A incidência de complicações pósoperatórias e hospitalizações após cesariana é maior nas MVHIV do que nas mulheres negativas (89). **Portanto, se não houver indicação obstétrica que justifique, não se recomenda realizar cesariana eletiva em gestante com CV-HIV abaixo de 1000 cópias/ml para prevenir TV-HIV.**  
O **AZT injetável** é indicado para a PTV e deve ser administrado durante o início do trabalho de parto, ou pelo menos 3 (três) horas antes da cesariana eletiva, até o clampeamento do cordão umbilical **para as gestantes infectadas pelo HIV com CV-HIV desconhecida ou detectável a partir da 34ª semana de gestação ou com histórico de má adesão mesmo com CV-HIV indetectável** .  
A Figura 7 mostra as possíveis situações para administração de AZT intravenoso profilático para gestantes durante o parto.  
Figura 7 – Fluxograma quanto às situações para administração de AZT intravenoso profilático para gestante durante o parto  
<!-- Start of picture text -->
Gestante com CV<br>Parto cesário, eletivo,<br>desconhecida ou AZT injetável  IV no<br>empelicado, a partir da<br>detectável  na 34ª  parto<br>38ª semana<br>semana<br>Gestante com CV<br>Parto segundo<br>detectável, porém menor  AZT injetável  IV no<br>indicação obstétrica;<br>que 1.000  cópias/mL na  parto<br>34ª semana pode ser vaginal<br>Parto segundo<br>Gestante com CV<br>indicação obstétrica,  Manter  TARV habitual<br>indetectável na 34ª<br>preferencialmente  via oral<br>semana<br>vaginal<br><!-- End of picture text -->  
Fonte:  DCCI/SVS/MS.  
O quadro a seguir apresenta os cuidados específicos durante o parto vaginal e cesariana em gestantes vivendo com HIV/aids.  
Quadro 17 – Cuidados específicos durante o parto vaginal e cesariana em gestantes vivendo com HIV/aids  
###### **Cuidados específicos durante o parto vaginal**  
1. Assim como na gestação, **estão contraindicados todos os procedimentos invasivos durante o trabalho de parto** (amniocentese, cordocentese, amniotomia, precoce e monitorização fetal invasiva durante o trabalho de parto).  
2. O **parto instrumentalizado deve ser evitado** ; porém, quando indicado, o fórceps deve ser preferido ao vácuo-extrator. A aplicação do fórceps (ou vácuo-extrator) só será admitida se houver uma indicação obstétrica precisa e que supere os riscos maiores de infecção da criança pelo procedimento.  
3. Havendo condições favoráveis para o parto vaginal e estando este indicado, **iniciar o AZT intravenoso logo que a parturiente chegar ao serviço em trabalho de parto** , conforme o protocolo estabelecido, e **manter a infusão até a ligadura do cordão umbilical** .  
4. **Diante da integridade da bolsa amniótica, a progressão normal do trabalho de parto é preferível à sua indução** .  
5. O trabalho de parto deve ser monitorado cuidadosamente, **evitando toques desnecessários e repetidos (usar o partograma)** .  
6. Deve-se **evitar que as parturientes permaneçam com bolsa rota por tempo prolongado** , visto que a taxa de TV aumenta progressivamente após 4 (quatro) horas de bolsa rota.  
7. O uso de medicamentos que aumentam a atividade uterina não está contraindicado, devendo seguir os padrões de segurança já conhecidos.  
8. **A amniotomia artificial deve ser evitada,** a menos que extremamente necessária.  
9. A **ligadura do cordão umbilical deve ser imediata à expulsão do feto** , não devendo ser executada, sob nenhuma hipótese, a ordenha do cordão.  
10. A **episiotomia só será realizada após avaliação cautelosa de sua necessidade** . Sendo realizada, deverá ser protegida por compressas umedecidas com degermante (o mesmo utilizado para degermar a vagina e períneo durante o parto). Manter a episiotomia coberta pela compressa umedecida deve ser tarefa de um auxiliar, visto ser impossível para um único profissional dar assistência ao parto e evitar o contato direto do nascituro com a episiotomia.  
###### **Cuidados específicos da cesariana eletiva**  
1. **Confirmar a idade gestacional** , a fim de evitar a **prematuridade iatrogênica** . Utilizar parâmetros obstétricos, como data da última menstruação correta, altura uterina e ultrassonografia precoce (preferencialmente no 1º trimestre, ou antes da 20ª semana).  
2. A **cesárea eletiva deve ser realizada a partir da 38ª semana de gestação** , a fim de evitar a prematuridade, o trabalho de parto e a RPM.  
3. Caso a **gestante que tenha indicação para a cesárea eletiva** inicie o **trabalho de parto antes da data prevista** para a cirurgia e chegue à maternidade com **dilatação cervical mínima** (menor que 4cm), o obstetra deve iniciar a infusão **intravenosa do AZT** e realizar a **cesárea, se possível, após três horas de infusão** .  
4. Sempre que possível, **proceder ao parto empelicado** (retirada do neonato mantendo as membranas corioamnióticas íntegras).  
5. **Ligar o cordão umbilical imediatamente após a retirada do RN** e não realizar ordenha do cordão.  
6. Realizar a **completa hemostasia** de todos os vasos da parede abdominal e a troca das compressas ou campos secundários **antes de se realizar a histerotomia** , minimizando o contato posterior do RN com sangue materno.  
7. **Utilizar antibiótico profilático** tanto na cesárea eletiva quanto naquela de urgência: dose única EV de 2g de cefazolina.  
Fonte: DCCI/SVS/MS.  
###### **3.16.2.  Biossegurança no parto**  
**As precauções básicas e universais são medidas de prevenção que devem ser adotadas por todos os profissionais de saúde no cuidado com qualquer indivíduo** , independentemente do diagnóstico definido ou presumido de doenças infecciosas, quando da manipulação de sangue, secreções, excreções, mucosas ou pele não íntegra.  
As medidas de biossegurança incluem a utilização de Equipamento de Proteção Individual (EPI) – luvas, máscara, óculos de proteção, capotes e aventais –, com a finalidade de reduzir a exposição da pele e das mucosas do profissional de saúde ao sangue ou fluidos corpóreos de qualquer pessoa. Não há recomendação para uma paramentação específica no momento do parto de GVHIV.  
Em caso de exposição a materiais biológicos, o profissional exposto deve ser avaliado com rapidez para que possa, caso seja indicado, realizar a PEP devida, seguindo o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco à Infecção pelo HIV, IST e Hepatites Virais” (disponível em <u>www.aids.gov.br/pcdt). A profilaxia ao HIV não confere</u> segurança absoluta e, portanto, não substitui a boa prática de saúde no que concerne a minimizar riscos mediante o uso correto dos EPI e técnica de excelência.  
**3.17. Uso de terapia antirretroviral como profilaxia da transmissão vertical do HIV no parto**  
###### **3.17.1.  Indicação de AZT na PTV do HIV no parto**  
O **AZT injetável** é indicado para a prevenção da transmissão vertical e deve ser administrado **durante o início do trabalho de parto** , ou até 3 (três) horas antes da cesariana eletiva, até o clampeamento do cordão umbilical.  
Para as mulheres já em TARV, os **ARV devem ser mantidos nos horários habituais** , VO, com um pouco de água, mesmo durante o trabalho de parto ou no dia da cesárea programada.  
**Não é necessário uso de AZT profilático EV naquelas gestantes que apresentem CV-HIV indetectável após 34 semanas de gestação, e que estejam em TARV com boa adesão** (90,91). Entretanto, independentemente da CV-HIV, o médico pode eleger ou não o uso do AZT intraparto EV, a depender do seu julgamento clínico se houver risco de má adesão.  
###### **Esquema posológico de AZT injetável**  
- Apresentação comercial do AZT injetável (EV): frasco ampola de 10mg/mL. A dose de ataque na primeira hora é de 2mg/kg, seguida de manutenção com infusão contínua de 1mg/kg, diluído em 100mL de soro glicosado a 5%.  
- A parturiente deve receber AZT EV desde o início do trabalho de parto até o clampeamento do cordão umbilical.  
- A concentração não deve exceder 4 mg/mL.  
Quadro 18 – Esquema posológico do AZT na gestante vivendo com HIV  
||**Dose de ataque (2mg/kg) na**|**primeira hora**|
|---|---|---|
|Peso|Quantidade de zidovudina|Número gotas/min|
|40kg|8 mL|36|
|50kg|10 mL|37|
|60kg|12 mL|37|
|70kg|14 mL|38|
|80kg|16 mL|39|
|90kg|18 mL|39|
|<br>**Ma**<br>40kg|**nutenção (1mg/kg/hora) em**<br>4 mL|**infusão contínua**<br>35|
|50kg|5 mL|35|
|60kg|6 mL|35|
|70kg|7 mL|36|  
|80kg|8 mL|36|
|---|---|---|
|90kg|9 mL|36|  
Fonte: DCCI/SVS/MS.  
**Não é recomendável** substituição do AZT injetável no momento do parto pelo AZT via oral para gestante por conta da absorção errática do AZT VO, sem evidência que garanta nível sérico adequado no momento oportuno.  
###### **3.18. Manejo da mulher vivendo com HIV no puerpério**  
A TARV deve ser mantida após o parto, independentemente da contagem de LT-CD4+ e dos sinais e sintomas clínicos da mulher.  
A puérpera deverá ser orientada quanto à importância de seu acompanhamento clínico e ginecológico, assim como sobre o seguimento da criança até a definição de situação imunológica. **É muito comum, após o parto, haver diminuição da adesão da mulher ao tratamento** , principalmente o não comparecimento a consultas agendadas em serviço de referência para HIV, quando o diagnóstico é feito na maternidade. O comparecimento às consultas deve ser estimulado e monitorado, lançando-se mão de busca ativa, se necessário.  
A puérpera deve ter alta da maternidade com consulta agendada no serviço de saúde especializado, para seu acompanhamento e o da criança.  
**Recomenda-se que o serviço especializado que irá realizar o cuidado da criança exposta ao HIV também faça o seguimento da puérpera vivendo com HIV, durante os 12 meses que a criança exposta ficará vinculada a esse serviço. Portanto, a mulher que estiver em uso regular de TARV, sem intercorrências clínicas e mantendo CV-HIV indetectável, deverá ter sua rotina laboratorial solicitada e avaliada pelo serviço especializado que acompanha a criança.**  
Esse momento crítico na linha de cuidado materno-infantil deve avaliar, no âmbito de  uma puérpera vivendo com HIV e um RN exposto ao HIV, questões relacionadas à adesão ao esquema de TARV, uso adequado da profilaxia ARV do RN, efetividade das medidas para inibição de lactação e adaptação ao uso da fórmula láctea (58).  
O seguimento obstétrico da mulher com HIV no puerpério, salvo em situações especiais de complicações ocorridas durante o parto e o puerpério imediato, é igual ao de qualquer outra mulher, devendo-se prever o retorno entre o 5º e o 8º dia e no 42º dia pós-parto.  
A caderneta da gestante tem informações importantes para o acompanhamento da criança e para futuras gestações. Por esse motivo, deverá ser devolvida à puérpera com todas as anotações referentes ao período da internação para o parto.  
É necessário considerar que mulheres que não amamentam tendem a ter um período menor de amenorreia, podendo voltar a ovular a partir de quatro semanas após o parto. Assim, considerando os direitos sexuais e reprodutivos dessas mulheres, estas (bem como suas parcerias sexuais) devem ser acompanhadas nas ações de saúde sexual e planejamento reprodutivo, para que façam escolhas de forma consciente e segura.  
Para mais informações sobre seguimento da mulher no puerpério, acessar “Caderno de Atenção Básica – Atenção ao pré-natal de baixo risco” (disponível em <u>http://bvsms.saude.gov.br/bvs/publicacoes/cadernos_atencao_basica_32_prenatal.pdf).</u>  
###### **3.19. Manejo clínico do recém-nascido exposto ao HIV**  
A sequência de atividades recomendadas a seguir dependerá das condições de nascimento do RN. O intuito é evitar o contato do sangue materno com o do RN.  
###### **3.19.1.  Cuidados na sala de parto e pós-parto imediato**  
Todas as recomendações estão resumidas no Quadro 18, a seguir:  
Quadro 19 – Cuidados imediatos com o RN exposto ao HIV  
###### **Cuidados na sala de parto e pós-parto imediato**  
1. Sempre que possível, realizar o parto empelicado, com a retirada do neonato mantendo as membranas corioamnióticas íntegras.  
2. Clampear imediatamente o cordão após o nascimento, sem qualquer ordenha.  
3. Imediatamente após o nascimento (ainda na sala de parto), realizar o banho, preferencialmente com chuveirinho, torneira ou outra fonte de água corrente. Limpar com compressas macias todo sangue e secreções visíveis no RN.  
A compressa deve ser utilizada de forma delicada, com cuidado ao limpar as secreções, para não lesar a pele delicada da criança e evitar uma possível contaminação.  
4. Se necessário, aspirar delicadamente as vias aéreas do RN, evitando traumatismos em mucosas.  
5. Aspirar delicadamente o conteúdo gástrico de líquido amniótico (se necessário) com sonda oral, evitando traumatismos. Se houver presença de sangue, realizar lavagem gástrica com soro fisiológico.  
6. Colocar o RN junto à mãe o mais brevemente possível.  
7. Iniciar a primeira dose de AZT solução oral (preferencialmente ainda na sala de parto), logo após os cuidados imediatos ou nas primeiras 4 horas após o nascimento.  
8. Quando indicado, administrar a NVP o mais precocemente possível, antes das primeiras 48 horas de vida.  
9. Orientar a não amamentação e inibir a lactação com medicamento (cabergolina). Orientar a mãe a substituir o leite materno por fórmula láctea até 6 meses de idade. O aleitamento misto também é contraindicado.  
Pode-se usar leite humano pasteurizado proveniente de banco de leite credenciado pelo MS (p. ex., RN pré-termo ou de baixo peso).  
Se, em algum momento do seguimento, a prática de aleitamento for identificada, suspender o aleitamento e solicitar exame de CV para o RN.  
###### **Maternidade: cuidados antes da alta**  
10. É recomendado o alojamento conjunto em período integral, com o intuito de fortalecer o vínculo mãe-filho.  
11. Iniciar precocemente (ainda na maternidade ou na primeira consulta ambulatorial) o monitoramento laboratorial em todas as crianças expostas (independentemente de serem pré-termo ou não), considerando a possibilidade de eventos adversos aos ARV utilizados pela mãe.  
12. São terminantemente contraindicados o aleitamento cruzado (amamentação da criança <u>por outra nutriz) e o uso de leite humano com pasteurização domiciliar. Orientar a mãe</u>  
a substituir o leite materno por fórmula láctea até a criança completar 6 meses de idade.  
13. Anotar no resumo de alta do RN as informações do pré-natal, as condições do nascimento, o tempo de uso do AZT injetável na mãe, o momento do início do AZT xarope e da NVP no RN, dose utilizada, periodicidade e data de término, além das mensurações antropométricas, tipo de alimento fornecido à criança e outras informações importantes relativas ao parto.  
Essas informações deverão ser disponibilizadas ao SAE e à UBS que acompanharão a criança e a puérpera.  
14. A alta da maternidade é acompanhada de consulta agendada em serviço especializado para seguimento de crianças expostas ao HIV.  
- O comparecimento a essa consulta necessita ser monitorado. Em caso de não comparecimento, contatar a puérpera. A data da primeira consulta não deve ser superior a 15 dias a contar do nascimento, idealmente na primeira semana de vida.  
15. Preencher as fichas de notificação da “Criança exposta ao HIV” e enviá-las ao núcleo de vigilância epidemiológica competente.  
16. Atentar para as anotações feitas na carteira do RN referentes a dados que remetam à exposição ao HIV (comprometendo o sigilo), uma vez que se trata de um documento comumente manuseado pela família e algumas vezes requerido no trabalho dos progenitores para liberação do salário-família e para frequência à creche.  
Fonte: DCCI/SVS/MS.  
Crianças expostas ao HIV devem ser atendidas em SAE em HIV/aids, compartilhando o cuidado com a Atenção Básica.  
As crianças expostas ao HIV que tiverem diagnóstico confirmado permanecem no cuidado compartilhado entre serviço especializado e Atenção Primária, ao passo que as expostas ao HIV e não infectadas poderão ser acompanhadas apenas na Atenção Primária.  
As crianças expostas ao HIV e não infectadas tendem a apresentar mais infecções bacterianas e quadros mais graves, se comparadas a crianças não expostas ao HIV. A diminuição dos níveis de anticorpos maternos, transferida via placentária, e o não aleitamento por mães com HIV/aids mostram ser a diferença entre esses dois grupos.  
Para mais informações quanto ao acompanhamento, diagnóstico da infecção pelo HIV, monitoramento de efeitos adversos associados à exposição perinatal aos ARV e uso de alimentação por fórmula infantil, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para o Manejo da Infecção pelo HIV em Crianças e Adolescentes”, disponível em <http://www.aids.gov.br/pcdt>.  
###### **3.19.2. Quimioprofilaxia do RN exposto ao HIV**  
###### **Quimioprofilaxia para o HIV**  
Todas as crianças nascidas de mães vivendo com HIV deverão receber ARV como umas das medidas de profilaxia para TV (Quadro 20).  
O **RN** deve receber **AZT solução oral** , preferencialmente ainda **na sala de parto** , logo após os cuidados imediatos, ou nas primeiras quatro horas após o nascimento, devendo ser **mantido o tratamento durante as primeiras quatro semanas de vida** .  
Para **mães com CV-HIV maior que 1.000 cópias/mL** registrada no último trimestre **ou** com **CVHIV desconhecida** , a **NVP** deverá ser acrescentada ao AZT de acordo com os cenários descritos no Quadro 18, a seguir, e deve ser iniciada **até 48 horas após o nascimento** .  
A indicação da quimioprofilaxia após 48 horas do nascimento da criança deverá ser discutida caso a caso, preferencialmente com o médico especialista.  
A prescrição da quimioprofilaxia ARV deve ser realizada no Formulário de Solicitação de Medicamentos – Profilaxia, disponível na página do SICLOM operacional, em documentos (http://azt.aids.gov.br/documentos/siclom_operacional/Solicita%C3%A7%C3%A3o_Medicame <u>ntos_Profilaxia.pdf).</u>  
Quadro 20 – Indicação de ARV para a criança exposta ao HIV para profilaxia da transmissão vertical do HIV  
|**Cenários**|**Uso de ARV - Gestante no pré-natal**|**Indicação de**<br>**ARV - RN**|**Posologia de ARV para RN**|**Duração da**<br>**profilaxia com**<br>**ARV para RN**|
|---|---|---|---|---|
|**Uso de ARV**<br>**durante a**<br>**gestação**|- Uso de ARV no pré-natal e periparto,<br>com CV documentada <1.000 cópias/mL<br>no 3º trimestre|AZT (VO)|- RN com 35 semanas ou mais de idade gestacional:<br>4mg/kg/dose de 12/12h<br>- RN entre 30 e 35 semanas de idade gestacional:<br>2mg/kg/dose de 12/12h por 14 dias e 3mg/kg/dose de<br>12/12h a partir do 15º dia<br>- RN com menos de 30 semanas de idade gestacional:<br>2mg/kg/dose de 12/12h|<br> <br>4 semanas|
|**Sem uso de**<br>**ARV durante a**<br>**gestação**|- Sem utilização de ARV durante a<br>gestação, independentemente do uso<br>de AZT periparto;**ou**<br>- uso de ARV na gestação, mas CV<br>desconhecida ou acima de 1.000<br>cópias/mL no 3º trimestre;**ou**<br>- histórico de má adesão, mesmo com<br>com CV documentada <1.000 cópias/mL<br>no 3º trimestre;**ou**|AZT<br>(VO)<br>associado<br>a<br>NVP (VO)|Posologia do AZT (VO)<br>- RN nascido com 35 semanas ou mais de idade gestacional:<br>4mg/kg/dose de 12/12h<br>- RN entre 30 e 35 semanas de idade gestacional:<br>2mg/kg/dose de 12/12h por 14 dias e 3mg/kg/dose de<br>12/12h a partir do 15º dia<br>- RN com menos de 30 semanas de idade gestacional:<br>2mg/kg/dose de 12/12h|<br> <br>4 semanas|  
|- mãe com IST, especialmente sífilis;**ou**|Posologia da NVP (VO)|1ª dose: até 48h|
|---|---|---|
|- parturiente com resultado reagente no<br>momento do parto.|- Peso de nascimento >2 kg: 12mg/dose (1,2mL)<br>- Peso de nascimento 1,5 a 2 kg: 8mg/dose (0,8mL)|de vida<br>2ª dose: 48h<br>após 1ª dose|
||- Peso de nascimento <1,5kg: não usar NVP|3ª dose: 96h<br>após 2ª dose|  
###### Fonte: DCCI/SVS/MS.  
##### #%¥ Conitec  
Excepcionalmente, quando a criança não tiver condições de receber o medicamento por VO, pode ser  
utilizado o AZT injetável, nas seguintes doses:  
- RN com 35 semanas de idade gestacional ou mais: 3mg/kg/dose IV 12/12h, por quatro semanas;  
- RN entre 30 e 35 semanas de idade gestacional: 1,5 mg/kg/dose IV 12/12h nos primeiros 14 dias de vida e 2,3 mg/kg/dose IV 12/12h a partir do 15º dia, por quatro semanas;  
- RN com menos de 30 semanas de idade gestacional: 1,5 mg/kg/dose IV 12/12h, por quatro semanas.  
Nos casos de impossibilidade de deglutição e se houver indicação de NVP, poderá ser avaliada administração por sonda nasoenteral, pois esse medicamento não apresenta formulação injetável.  
**3.19.3.  Rotina de acompanhamento clínico e laboratorial da criança exposta ao HIV**  
O acompanhamento deve ser mensal nos primeiros seis meses e, no mínimo, bimestral a partir do 1º ano de vida. ~~<mark>PO</mark>~~ Para mais informações, consultar o “PCDT para o Manejo da Infecção pelo HIV em Crianças e Adolescentes", disponível em http://www.aids.gov.br/pcdt.  
###### **3.19.4. Esquema vacinal na maternidade**  
###### **Imunização do RN que permanece internado na unidade neonatal**  
Todas as vacinas do Programa Nacional de Imunizações (PNI) poderão ser administradas na unidade neonatal, se o RN atingir a idade cronológica apropriada para a vacinação, segundo o calendário nacional de imunizações pactuado. Esse calendário poderá ser modificado em situações de incorporação ou substituição de imunobiológicos pelo PNI.  
Vale ressaltar que deve ser levada em consideração a situação clínico-imunológica de cada criança e adolescente ao ser indicada a vacinação. Informações mais detalhadas podem ser encontradas no  
<!-- Start of picture text -->
#%¥ Conitec ST ot 5<br><!-- End of picture text -->  
“Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes”, disponível em http://www.aids.gov.br/pcdt.  
###### **3.19.5. Imunobiológicos na unidade neonatal**  
###### **Imunoglobulina anti-hepatite B (IGHAHB) e vacina de hepatite B**  
**A imunoglobulina humana anti-hepatite B (IGHAHB) está indicada logo após o nascimento, preferencialmente ainda nas primeiras 12 horas de vida,** para RN **de mãe HBsAg reagentes para hepatite B** . A dose da imunoglobulina é 0,5mL intramuscular, no músculo vasto lateral.  
Quando o perfil **HBsAg da mãe for desconhecido** , deve-se administrar imediatamente a vacina contra a hepatite B e, simultaneamente, solicitar a pesquisa de HBsAg materno, indicando-se a imunoglobulina até o 7º dia de vida, se o resultado for reagente.  
A primeira dose da vacina contra a hepatite B deverá ser administrada simultaneamente, na dose de 0,5mL, intramuscular, no músculo vasto lateral do outro membro. O esquema vacinal completo deve ser de 0 (ao nascimento, vacina monovalente), 2, 4, 6 e 15 meses (vacina pentavalente). Recomendase a realização de sorologia 30 a 60 dias após o término do esquema.  
Em caso de vacinação de crianças nascidas com menos de 2.000g ou 33 semanas de idade gestacional, são recomendadas pelo menos quatro doses de vacina de hepatite B recombinante, o que já está contemplado pelo esquema atual.  
###### **Imunoglobulina anti-varicela-zoster (IGHVZ)**  
Está indicada na dose de 150 UI, por via IM, nas seguintes situações:  
- RN cujas mães tenham apresentado quadro clínico de varicela de cinco dias antes a dois dias depois do parto;  
- pré-termos nascidos entre 28 semanas e 36 semanas de gestação, expostos à varicela, quando a mãe tiver história negativa para esse agravo;  
£% Conitec  
- pré-termos nascidos com menos de 28 semanas de gestação, expostos à varicela, independentemente da história materna desse agravo.  
###### **Imunoglobulina antitetânica (IGHT)**  
Está indicada na dose de 250 UI, por via IM, para RN que apresentem situação de risco para tétano e cujas mães não tenham história vacinal que garanta proteção contra o tétano neonatal (dT: vacina dupla tipo adulto – esquema de três doses há menos de um ano ou reforço há menos de cinco anos).  
###### **3.20. Amamentação nas mulheres vivendo com HIV**  
O risco de TV do HIV continua por meio da amamentação. Dessa forma, o fato de a mãe utilizar ARV não controla a eliminação do HIV pelo leite, e não garante proteção contra a TV.  
Recomenda-se que toda puérpera vivendo com HIV/aids seja orientada a **não amamentar** . Ao mesmo tempo, ela deve ser informada e orientada sobre o direito a receber fórmula láctea infantil.  
A **criança exposta, infectada ou não, terá direito a receber a fórmula láctea infantil, pelo menos, até**  
**completar seis meses de idade** . Esse prazo pode ser estendido conforme avaliação de casos específicos.  
A prática já demonstrou que uma das intervenções mais efetivas para evitar a amamentação natural é começar a orientação para o aleitamento artificial já durante o pré-natal. A decisão e a comunicação à puérpera sobre a necessidade de suprimir a lactação apenas após o parto é considerada tardia, com resultados insatisfatórios.  
O aleitamento cruzado (amamentação da criança por outra nutriz), a alimentação mista (leite humano e fórmula infantil) e o uso de leite humano com pasteurização domiciliar são contraindicados.  
Considerando-se que o aleitamento materno contribui substancialmente para a TV do HIV, é conveniente realizar a **orientação da puérpera/mãe soronegativa no momento do parto** . Devem-se avaliar suas vulnerabilidades e orientar a prevenção da infecção do HIV após o parto, principalmente com o uso de preservativos, reduzindo a possibilidade de infecção durante a amamentação.  
Se ocorrer infecção materna aguda durante a amamentação, o risco de infecção da criança é maior devido ao rápido aumento da CV-HIV e queda na contagem de LT-CD4+. A mãe deve ser orientada para a interrupção da amamentação assim que o diagnóstico for realizado.  
É importante a orientação sobre o uso do preservativo durante a lactação para as puérperas. Em caso de suspeita de infecção materna, cujo risco de transmissão para o lactente é alto, orienta-se a imediata interrupção da amamentação, a realização de testagem para HIV na mãe e no lactente para detecção precoce de infecção pelo HIV, avaliação para PEP e acompanhamento da criança exposta.  
Se a criança for **exposta à amamentação por mulher infectada pelo HIV** , deve-se orientar a mãe para **a interrupção imediata da amamentação** e avaliação quanto à necessidade de **realização de PEP** , simultaneamente à **investigação diagnóstica** .  
Para mais informações sobre como realizar a investigação diagnóstica da criança exposta ao HIV e indicações de PEP, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Manejo da Infecção pelo HIV em Crianças e Adolescentes” e o “Protocolo Clínico e Diretrizes Terapêuticas para Profilaxia Pós-Exposição de Risco à Infecção pelo HIV, IST e Hepatites Virais”, disponíveis em <u>http://www.aids.gov.br/pcdt.</u>  
###### **Uso de inibidores de lactação**  
A inibição farmacológica da lactação deve ser realizada **imediatamente após o parto** , utilizando-se **cabergolina 1mg VO, em dose única** (dois comprimidos de 0,5mg VO), **administrada antes da alta hospitalar** . ~~<mark>OO</mark>~~ Essa indicação ocorre pelas vantagens que a cabergolina apresenta em relação a outros medicamentos, tais como efetividade, comodidade posológica e raros efeitos colaterais (gástricos).  
A informação do código do procedimento deverá constar no preenchimento da Autorização de Internação Hospitalar (AIH) do parto.  
##### #%¥ Conitec  
Diante da ocorrência de lactação rebote, fenômeno pouco comum, pode-se realizar uma nova dose do inibidor.  
###### **Enfaixamento das mamas**  
Deve ser realizado apenas na ausência dos inibidores de lactação farmacológicos. Os serviços de saúde devem se organizar para oferecer a cabergolina em tempo oportuno.  
O procedimento consiste em realizar compressão das mamas com atadura, imediatamente após o parto, com o cuidado de não restringir os movimentos respiratórios ou causar desconforto materno. O enfaixamento é recomendado por um período de dez dias, evitando-se a manipulação e estimulação das mamas. A adesão é baixa, especialmente em países de clima quente, e sua efetividade é questionável.  
Referências da Parte III - Prevenção da transmissão vertical do HIV  
1. Conselho Federal de Medicina. Código de ética Médica. 2019; Available from: http://www.cremesp.org.br/library/modulos/publicacoes/pdf/CodigoEticaMedica2013.pdf  
2.  
- BRASIL. Boletim Epidemiológico HIV/Aids 2019. 2019;  
3. OMS. Contraceptive eligibility for women at high risk of HIV. 2019; Available from: http://www.who.int/reproductivehealth/publications/family_planning/HC-and-HIV-2017/en/  
4. OMS. Guia consolidada sobre saúde sexual e reprodutiva e direitos das mulheres vivendo com HIV / AIDS Resumo executivo. 2017; Available from: https://apps.who.int/iris/bitstream/handle/10665/254885/9789248549991-por.pdf?ua=1  
5. Mugo NR, Heffron R, Donnell D, Wald A, Were EO, Rees H, et al. Prospective Study among African HIV-1 Serodiscordant Couples. Aids. 2011;25(May 2010):1887–95.  
6. Tubiana R, Le Chenadec J, Rouzioux C, Mandelbrot L, Hamrene K, Dollfus C, et al. Factors Associated with Mother‐to‐Child Transmission of HIV‐1 Despite a Maternal Viral Load <500 Copies/mL at Delivery: A Case‐Control Study Nested in the French Perinatal Cohort (EPF‐ANRS CO1). Clin Infect Dis. 2010;50(4):585–96.  
7. Townsend CL, Byrne L, Cortina-Borja M, Thorne C, De Ruiter A, Lyall H, et al. Earlier initiation of ART and further decline in mother-to-child HIV transmission rates, 2000-2011. Aids. 2014;28(7):1049–57.  
8. Matthews LT, Beyeza-Kashesya J, Cooke I, Davies N, Heffron R, Kaida A, et al. Consensus statement: Supporting Safer Conception and Pregnancy For Men And Women Living with and Affected by HIV. AIDS Behav. 2018;22(6):1713–24.  
9. Attia S, Egger M, Müller M, Zwahlen M, Low N. Sexual transmission of HIV according to viral load and antiretroviral therapy: Systematic review and meta-analysis. Aids. 2009;23(11):1397– 404.  
<!-- Start of picture text -->
#%¥ Conitec Sy | te<br><!-- End of picture text -->  
10. Donnell D, Baeten JM, Kiarie J, Thomas K, Stevens W, Cohen CR, et al. Therapy : a Prospective Cohort Analysis. 2010;375(9731):2092–8.  
11. Mmeje O, Cohen CR, Cohan D. Evaluating safer conception options for HIV-serodiscordant couples (HIV-infected female/HIV-uninfected male): A closer look at vaginal insemination. Infect Dis Obstet Gynecol. 2012;2012.  
12. Patel RC, Onono M, Gandhi M, Blat C, Hagey J, Shade SB, et al. Pregnancy rates in HIV-positive women using contraceptives and efavirenz-based or nevirapine-based antiretroviral therapy in Kenya: A retrospective cohort study. Lancet HIV. 2015;2(11):e474–82.  
13. Myron S. Cohen, M.D., Ying Q. Chen, Ph.D., Marybeth McCauley, M.P.H., Theresa Gamble, Ph.D., Mina C. Hosseinipour, M.D., Nagalingeswaran Kumarasamy, M.B., B.S., James G. Hakim, M.D., Johnstone Kumwenda, F.R.C.P., Beatriz Grinsztejn, M.D., Jose H.S. Pilott P. Antiretroviral Therapy for the Prevention of HIV-1 Transmission. 2017;375(9):830–9.  
14. Rodger AJ, Cambiano V, Bruun T, Vernazza P, Collins S, Van Lunzen J, et al. Sexual activity without condoms and risk of HIV transmission in serodifferent couples when the HIV-positive partner is using suppressive antiretroviral therapy. JAMA - J Am Med Assoc. 2016;316(2):171– 81.  
15. Savasi V, Mandia L, Laoreti A, Cetin. I. Reproductive assistance in HIV serodiscordant couples. Hum Reprod Update. 2013;19(2):136–50.  
16. Saleem HT, Narasimhan M, Denison JA, Kennedy CE. Achieving pregnancy safely for HIVserodiscordant couples: A social ecological approach. J Int AIDS Soc [Internet]. 2017;20(1):18– 23. Available from: http://dx.doi.org/10.1080/17582652.2017.1278946  
17. Loutfy M, Kennedy VL, Poliquin V, Dzineku F, Dean NL, Margolese S, et al. No. 354-Canadian HIV Pregnancy Planning Guidelines. J Obstet Gynaecol Canada [Internet]. 2018;40(1):94–114. Available from: https://doi.org/10.1016/j.jogc.2017.06.033  
18. Mofenson LM, Baggaley RC, Mameletzis I. Tenofovir disoproxil fumarate safety for women and their infants during pregnancy and breastfeeding. Aids. 2017;31(2):213–32.  
19. Lockman S, Creek T. Acute Maternal HIV Infection during Pregnancy and Breast‐Feeding: Substantial Risk to Infants. J Infect Dis. 2009;200(5):667–9.  
20. Coutsoudis A. Breastfeeding and HIV. Best Pract Res Clin Obstet Gynaecol. 2005;19(2 SPEC. ISS.):185–96.  
21. Munro MG, Critchley HOD, Fraser IS, Haththotuwa R, Kriplani A, Bahamondes L, et al. The two FIGO systems for normal and abnormal uterine bleeding symptoms and classification of causes of abnormal uterine bleeding in the reproductive years: 2018 revisions. Int J Gynecol Obstet. 2018;143(3):393–408.  
22. Pfeifer S, Butts S, Fossum G, Gracia C, La Barbera A, Mersereau J, et al. Optimizing natural fertility: a committee opinion. Fertil Steril. 2017;107(1):52–8.  
23. American Society for Reproductive Medicine. Diagnostic evaluation of the infertile female: A committee opinion. Fertil Steril [Internet]. 2015;103(6):e44–50. Available from: http://dx.doi.org/10.1016/j.fertnstert.2015.03.019  
24. BRASIL. Guia do Pré-Natal do Parceiro para Profissionais de Saúde. Ministério da Saúde. 2016;123.  
25. Duarte G. Extensão da assistência pré-natal ao parceiro como estratégia de aumento da adesão  
##### #%¥  
ao pré-natal e redução da transmissão vertical de infecções. Rev Bras Ginecol e Obstet. 2007;29(4):171–4.  
26. Blumenthal PD, Voedisch A, Gemzell-Danielsson K. Strategies to prevent unintended pregnancy: Increasing use of longacting reversible contraception. Hum Reprod Update. 2011;17(1):121–37.  
27. Sutton MY, Zhou W, Frazier EL. Unplanned pregnancies and contraceptive use among HIVpositive women in care. PLoS One. 2018;13(5):1–14.  
28. Viellas EF et al. Prenatal care in Brazil. Cad Saude Publica. 2014;30:S1–15.  
29. Brandão K de SAG, Lima BG de C, Travassos AGÁ, de Brito F de OR, de Souza EXP, Haguihara T, et al. Adesão à dupla contracepção entre mulheres infectadas pelo HIV. Rev Bras Ginecol e Obstet. 2015;37(10):486–91.  
30. Singh A, Singh A, Mahapatra B. The consequences of unintended pregnancy for maternal and child health in rural India: Evidence from prospective data. Matern Child Health J. 2013;17(3):493–500.  
31. Lindberg L, Maddow-Zimet I, Kost K, Lincoln A. Pregnancy Intentions and Maternal and Child Health: An Analysis of Longitudinal Data in Oklahoma. Matern Child Health J. 2015;19(5):1087– 96.  
32. Faisal-Cury A, Menezes PR, Quayle J, Matijasevich A. Unplanned pregnancy and risk of maternal depression: secondary data analysis from a prospective pregnancy cohort. Psychol Heal Med. 2017;22(1):65–74.  
33. Yakubovich AR, Heron J, Feder G, Fraser A, Humphreys DK. Intimate partner violence victimisation in early adulthood: Psychometric properties of a new measure and gender differences in the Avon Longitudinal Study of Parents and Children. BMJ Open. 2019;9(3):7–9.  
34. Trussell J. Contraceptive failure in the United States James. NIH Public Access. 2011;83(5):397– 404.  
35. Winner B, Peipert JF, Zhao Q, Buckel C, Madden T, Allsworth JE, et al. Effectiveness of longacting reversible contraception. N Engl J Med. 2012;366(21):1998–2007.  
36. OMS. Family planning - a global handbook for providers. 2018.  
37. Wilkinson D, Tholandi M, Ramjee G, Rutherford GW. Nonoxynol-9 spermicide for prevention of vaginally acquired HIV and other sexually transmitted infections: Systematic review and metaanalysis of randomised controlled trials including more than 5000 women. Lancet Infect Dis. 2002;2(10):613–7.  
38. Ahmed K, Baeten JM, Beksinska M, Bekker L-G, Bukusi EA, Donnell D, et al. HIV incidence among women using intramuscular depot medroxyprogesterone acetate, a copper intrauterine device, or a levonorgestrel implant for contraception: a randomised, multicentre, open-label trial. Lancet. 2019;394(10195):303–13.  
39. Palanee-Phillips T, Brown ER, Szydlo D, Matovu Kiweewa F, Pather A, Harkoo I, et al. Risk of HIV1 acquisition among South African women using a variety of contraceptive methods in a prospective study. Aids. 2019;33(10):1619–22.  
40. Polis CB, Curtis KM, Hannaford PC, Phillips SJ, Chipato T, Kiarie JN, et al. An updated systematic review of epidemiological evidence on hormonal contraceptive methods and HIV acquisition in women. Aids. 2016;30(17):2665–83.  
<!-- Start of picture text -->
#%¥ Conitec Sy | te<br><!-- End of picture text -->  
41. Sabo MC, Richardson BA, Lavreys L, Martin HL, Jaoko W, Mandaliya K, et al. Does bacterial vaginosis modify the effect of hormonal contraception on HIV seroconversion. Aids. 2019;33(7):1225–30.  
42. Phillips SJ, Curtis KM, Polis CB. Effect of hormonal contraceptive methods on HIV disease progression: A systematic review. Aids. 2013;27(5):787–94.  
43. Heffron R, Mugo N, Ngure K, Celum C, Donnell D, Were E, et al. Hormonal contraceptive use and risk of HIV-1 disease progression. Aids. 2013;27(2):261–7.  
44. Pyra M, Heffron R, Mugo NR, Nanda K, Thomas KK, Baeten JM, et al. Effectiveness of Hormonal Contraception in HIV-Infected Women using Antiretroviral Therapy : A Prospective Study. 2016;29(17):2353–9.  
45. OMS. Medical eligibility criteria for contraceptive use - 5th edition. Med eligibility criteria Contracept use -- 5th ed [Internet]. 2015;(978 92 4 154915 8). Available from: http://apps.who.int/iris/bitstream/10665/181468/1/9789241549158_eng.pdf%0Ahttp://icme r.org/documentos/anticoncepcion_de_emergencia/WHO 2015 Medical eligibility criteria for contraceptive use.pdf  
46. Nanda K, Stuart GS, Robinson J, Gray AL, Tepper NK, Gaffield ME. Drug interactions between hormonal contraceptives and antiretrovirals. Vol. 31, Aids. 2017. 917–952 p.  
47. Song IH, Borland J, Chen S, Wajima T, Peppercorn AF, Piscitelli SC. Dolutegravir Has No Effect on the Pharmacokinetics of Oral Contraceptives With Norgestimate and Ethinyl Estradiol. Ann Pharmacother. 2015;49(7):784–9.  
48. Tittle V, Bull L, Boffito M, Nwokolo N. Pharmacokinetic and Pharmacodynamic Drug Interactions Between Antiretrovirals and Oral Contraceptives. Clin Pharmacokinet. 2015;54(1):23–34.  
49. Tepper NK, Curtis KM, Nanda K, Jamieson DJ. Safety of intrauterine devices among women with HIV: a systematic review. Contraception [Internet]. 2016;94(6):713–24. Available from: http://dx.doi.org/10.1016/j.contraception.2016.06.011  
50. Brasil. MANUAL TÉCNICO PARA PROFISSIONAIS DE SAÚDE – DIU COM COBRE T Cu 380 A. 2018;67.  
51. De Nadai MN, Poli-Neto OB, Franceschini SA, Yamaguti EMM, Monteiro IMU, Troncon JK, et al. Intracervical block for levonorgestrel-releasing intrauterine system placement among nulligravid women: a randomized double-blind controlled trial. Am J Obstet Gynecol [Internet]. 2020;222(3):245.e1-245.e10. Available from: https://doi.org/10.1016/j.ajog.2019.09.013  
52. Dina B, Peipert LJ, Zhao Q, Peipert JF. Anticipated pain as a predictor of discomfort with intrauterine device placement. Am J Obstet Gynecol [Internet]. 2018;218(2):236.e1-236.e9. Available from: https://doi.org/10.1016/j.ajog.2017.10.017  
53. Anthoulakis C, Iordanidou E, Vatopoulou A. Pain Perception during Levonorgestrel-releasing Intrauterine Device Insertion in Nulliparous Women: A Systematic Review. J Pediatr Adolesc Gynecol [Internet]. 2018;31(6):549-556.e4. Available from: https://doi.org/10.1016/j.jpag.2018.05.008  
54. Gemzell-Danielsson K. Mechanism of action of emergency contraception. Contraception [Internet]. 2010;82(5):404–9. Available from: http://dx.doi.org/10.1016/j.contraception.2010.05.004  
55. Carten ML, Kiser JJ, Kwara A, Mawhinney S, Cu-Uvin S. Pharmacokinetic interactions between the hormonal emergency contraception, levonorgestrel (Plan B), and efavirenz. Infect Dis  
<!-- Start of picture text -->
#%¥ Conitec Sy | te<br><!-- End of picture text -->  
Obstet Gynecol. 2012;2012.  
56. Chappell CA, Cohn SE. Prevention of Perinatal Transmission of Human Immunodeficiency Virus. Infect Dis Clin North Am [Internet]. 2014;28(4):529–47. Available from: http://dx.doi.org/10.1016/j.idc.2014.08.002  
57. Brasil. Atenção ao pré-natal de baixo risco. 2012.  
58. Brasil. Protocolos da Atenção Básica: Saúde das Mulheres. 2016.  
59. BRASIL. Relatório de Monitoramento Clínico das Gestantes Vivendo com HIV. 2019;  
60. Little SJ et al. Antiretroviral-drug resistance among patients Recently Infected With Hiv. N Engl J Med. 2002;347(6):385–94.  
61. Kuritzkes DR, Lalama CM, Ribaudo HJ, Marcial M, Meyer III WA, Shikuma C, et al. Preexisting Resistance to Nonnucleoside Reverse‐Transcriptase Inhibitors Predicts Virologic Failure of an Efavirenz‐Based Regimen in Treatment‐Naive HIV‐1–Infected Subjects. J Infect Dis. 2008;197(6):867–70.  
62. Moura MES, Da Guarda Reis MN, Lima YAR, Eulálio KD, Cardoso LPV, De Araujo Stefani MM. Low rate of transmitted drug resistance may indicate low access to antiretroviral treatment in Maranhão State, Northeast Brazil. AIDS Res Hum Retroviruses. 2015;31(2):250–4.  
63. Rhee SY, Blanco JL, Jordan MR, Taylor J, Lemey P, Varghese V, et al. Geographic and Temporal Trends in the Molecular Epidemiology and Genetic Mechanisms of Transmitted HIV-1 Drug Resistance: An Individual-Patient- and Sequence-Level Meta-Analysis. PLoS Med. 2015;12(4):1– 29.  
64. Santos LMP, Lecca RCR, Cortez-Escalante JJ, Sanchez MN, Rodrigues HG. Prevention of neural tube defects by the fortification of flour with folic acid: a population-based retrospective study in Brazil. Bull World Health Organ. 2016;94(1):22–9.  
65. Zash R, Holmes L, Diseko M, Jacobson DL, Brummel S, Mayondi G, et al. Neural-Tube Defects and Antiretroviral Treatment Regimens in Botswana. N Engl J Med [Internet]. 2019;NEJMoa1905230. Available from: http://www.nejm.org/doi/10.1056/NEJMoa1905230  
66. Atta CAM, Fiest KM, Frolkis AD, Jette N, Pringsheim T, St Germaine-Smith C, et al. Global birth prevalence of spina bifida by folic acid fortification status: A systematic review and metaanalysis. Am J Public Health. 2016;106(1):e24–34.  
67. OMS. Update of recommendations on first- and second-line antiretroviral regimens. http://apps.who.int/iris [Internet]. 2019;(July). Available from: https://www.who.int/hiv/pub/guidelines/en/  
68. Phillips AN, Venter F, Havlir D, Pozniak A, Kuritzkes D, Wensing A, et al. Risks and benefits of dolutegravir-based antiretroviral drug regimens in sub-Saharan Africa: a modelling study. Lancet HIV [Internet]. 2019;6(2):e116–27. Available from: http://dx.doi.org/10.1016/S23523018(18)30317-5  
69. Kelly SG, Masters MC, Taiwo BO. Initial Antiretroviral Therapy in an Integrase Inhibitor Era: Can We Do Better? Infect Dis Clin North Am. 2019;  
70. Yombi JC, Pozniak AL. Is it time for integrase inhibitors to be the preferred regimen for the firstline treatment of HIV-1-infected naive patients? AIDS Rev. 2016;18(2):89–100.  
71. Ferreira ACG, Coelho LE, Grinsztejn E, Jesus CS d., Guimarães ML, Veloso VG, et al. Transmitted drug resistance in patients with acute/recent HIV infection in Brazil. Brazilian J Infect Dis  
#%¥ Conitec  
[Internet]. 2017;21(4):396–401. Available from: http://dx.doi.org/10.1016/j.bjid.2017.03.013  
72. OMS. Hiv drug resistance report 2017. 2017.  
73. Williams PL, Crain MJ, Yildirim C, Hazra R, Van Dyke RB, Rich K, et al. Congenital anomalies and in utero antiretroviral exposure in human immunodeficiency virus-exposed uninfected infants. JAMA Pediatr. 2015;169(1):48–55.  
74. Ford N, Mofenson L, Shubber Z, Calmy A, Andrieux-Meyer I, Vitoria M, et al. Safety of efavirenz in the first trimester of pregnancy: An updated systematic review and meta-analysis. Aids. 2014;28(SUPPL. 2).  
75. Manzardo C, Guardo AC, Letang E, Plana M, Gatell JM, Miro JM. Opportunistic infections and immune reconstitution inflammatory syndrome in HIV-1-infected adults in the combined antiretroviral therapy era: A comprehensive review. Expert Rev Anti Infect Ther. 2015;13(6):751–67.  
76. OMS. UPDATED RECOMMENDATIONS ON FIRST-LINE AND SECOND-LINE ANTIRETROVIRAL REGIMENS AND POST-EXPOSURE PROPHYLAXIS AND RECOMMENDATIONS ON EARLY INFANT DIAGNOSIS OF HIV. Suppl to 2016 Consol Guidel use Antiretrovir drugs Treat Prev HIV Infect Geneva World Heal Organ 2019 Disponível em https//apps.who.int/iris/bitstream/handle/10665/277395/WHO-CDS-HIV-1851-. 2019;(December).  
77. Dooley, K. E., Kaplan, R., Mwelase, N., Grinsztejn, B., Ticona, E., Lacerda M. DOLUTEGRAVIRBASED ANTIRETROVIRAL THERAPY FOR PATIENTS CO-INFECTED WITH TUBERCULOSIS AND HIV: A MULTICENTER, NONCOMPARATIVE, OPEN-LABEL, RANDOMIZED TRIAL. Clin Infect Dis 2019 Mar 28 pii ciz256. 2019;  
78. Easterbrook P, Johnson C, Figueroa C, Baggaley R. HIV and hepatitis testing: Global progress, challenges, and future directions. AIDS Rev. 2016;18(1):3–14.  
79. Thio CL. Hepatitis B and human immunodeficiency virus coinfection. Hepatology. 2009;49(SUPPL. 5).  
80. Sulkowski MS. Viral hepatitis and HIV coinfection. J Hepatol. 2008;48(2):353–67.  
81. Liming Wang, Jeffrey Wiener, Marc Bulterys, Xiaoyu Wei, Lili Chen, Wei Liu, Shujia Liang, Colin Shepard, Linhong Wang, Ailing Wang FZAPK. Hepatitis B virus (HBV) load response to 2 antiviral regimens, tenofovir/lamivudine and lamivudine, in HIV/ HBV-coinfected pregnant women in Guangxi, China: The Tenofovir in Pregnancy (TiP) Study. J Infect Dis. 2016;(214):1695–9.  
82. Benova L, Mohamoud YA, Calvert C, Abu-Raddad LJ. Vertical transmission of hepatitis C virus: Systematic review and meta-analysis. Clin Infect Dis. 2014;59(6):765–73.  
83. Pott H, Theodoro M, Almeida J De, Figueiredo J, Castelo A. Mother-to-child transmission of hepatitis C virus. Eur J Obstet Gynecol [Internet]. 2018;224:125–30. Available from: https://doi.org/10.1016/j.ejogrb.2018.03.034  
84. Kushner T, Terrault NA. Hepatitis C in Pregnancy: A Unique Opportunity to Improve the Hepatitis C Cascade of Care. Hepatol Commun. 2019;3(1):20–8.  
85. Prasad MR, Honegger JR. Hepatitis C virus in pregnancy. Am J Perinatol. 2013;30(2):149–59.  
86. Calvert C, Ronsmans C. HIV and the Risk of Direct Obstetric Complications: A Systematic Review and Meta-Analysis. PLoS One. 2013;8(10).  
87. Macdonald EM, Ng R, Yudin MH, Bayoumi AM, Loutfy M, Raboud J, et al. Postpartum Maternal  
##### #%¥ Conitec  
and Neonatal Hospitalizations Among Women with HIV: A Population-Based Study. AIDS Res Hum Retroviruses [Internet]. 2015;31(10):967–72. Available from: http://www.liebertpub.com/doi/10.1089/aid.2015.0047  
88. Thorne C, Boer K, England K, Godfried MH, Newell ML, Mahdavi S, et al. Elective cesarean section for women living with HIV. Aids [Internet]. 2013;28(4):335.e1-335.e12. Available from: http://dx.doi.org/10.1016/j.ajog.2013.06.021  
89. Kennedy CE, Yeh PT, Pandey S, Betran AP, Narasimhan M. Elective cesarean section for women living with HIV. Aids. 2017;31(11):1579–91.  
90. Briand N, Warszawski J, Mandelbrot L, Dollfus C, Pannier E, Cravello L, et al. Is intrapartum intravenous zidovudine for prevention of mother-to-child hiv-1 transmission still useful in the combination antiretroviral therapy era? Clin Infect Dis. 2013;57(6):903–14.  
91. Cotter AM, Brookfield KF, Duthely LM, Gonzalez Quintero VH, Potter JE, O’Sullivan MJ. Duration of membrane rupture and risk of perinatal transmission of HIV-1 in the era of combination antiretroviral therapy. Am J Obstet Gynecol [Internet]. 2012;207(6):482.e1-482.e5. Available from: http://dx.doi.org/10.1016/j.ajog.2012.10.862  
92. Brasil. Manual de para o Controle da Tuberculose. 2018. 25–363 p.  
###### **Parte IV - Prevenção da Transmissão Vertical da sífilis**  
###### **4.1.  Definição e etiologia da sífilis**  
A sífilis é uma infecção bacteriana sistêmica, crônica, curável e exclusiva do ser humano. Quando não tratada, evolui para estágios de gravidade variada, podendo acometer diversos órgãos e sistemas do corpo. Trata-se de uma doença conhecida há séculos; seu agente etiológico, descoberto em 1905, é o _Treponema pallidum_ , subespécie _pallidum_ . Sua transmissão se dá principalmente por contato sexual; contudo, pode ser transmitida verticalmente para o feto durante a gestação de uma mulher com sífilis não tratada ou tratada de forma não adequada (1).  
A maioria das pessoas com sífilis são assintomáticas; quando apresentam sinais e sintomas, muitas vezes não os percebem ou valorizam, e podem, sem saber, transmitir a infecção às suas parcerias sexuais. Quando não tratada, a sífilis pode evoluir para formas mais graves, comprometendo especialmente os sistemas nervoso e cardiovascular (2–4).  
Na gestação, a sífilis pode apresentar consequências severas, como abortamento, prematuridade, natimortalidade, manifestações congênitas precoces ou tardias e/ou morte do recém-nascido (RN). O Capítulo 6 abrange importantes informações sobre sífilis congênita.  
#%¥ Conitec  
O Brasil, assim como muitos países, apresenta uma reemergência da doença. Diante disso, os profissionais de saúde devem estar aptos a reconhecer as manifestações clínicas, conhecer os testes diagnósticos disponíveis, e, principalmente, saber interpretar o resultado do exame para diagnóstico e controle de tratamento.  
###### **4.2.  Transmissão da sífilis**  
A transmissibilidade da sífilis é maior nos estágios iniciais (sífilis primária e secundária), diminuindo gradualmente com o passar do tempo (sífilis latente recente/ tardia). Vale a pena ressaltar que, no primeiro ano de latência, 25% dos pacientes apresentam recrudescimento do secundarismo e, portanto, pode haver a transmissão. Essa maior transmissibilidade explica-se pela riqueza de treponemas nas lesões, comuns na sífilis primária (cancro duro) e secundária (lesões mucocutâneas). As espiroquetas penetram diretamente nas membranas mucosas ou entram por abrasões na pele (4). Essas lesões se tornam raras ou inexistentes a partir do segundo ano da doença.  
Em gestantes, a taxa de transmissão vertical de sífilis para o feto é de até 80% intraútero. Essa forma de transmissão ainda pode ocorrer durante o parto vaginal, se a mãe apresentar alguma lesão sifilítica. A infecção fetal é influenciada pelo estágio da doença na mãe (maior nos estágios primário e secundário) e pelo tempo em que o feto foi exposto. Até 50% das gestações em mulheres com sífilis não tratada irão resultar em desfechos gestacionais adversos, dentre deles morte _in utero_ , parto prétermo, baixo peso ao nascer ou morte neonatal (5).  
###### **4.3.  Classificação clínica da sífilis**  
A sífilis é dividida em estágios que orientam o tratamento e monitoramento, conforme segue (3):  
- sífilis recente (primária, secundária e latente recente): até um ano de evolução; e  
- sífilis tardia (latente tardia e terciária): mais de um ano de evolução.  
**Sífilis primária:** o tempo de incubação é de dez a 90 dias (média de três semanas). A primeira manifestação é caracterizada por uma úlcera rica em treponemas, geralmente única e indolor, com borda bem definida e regular, base endurecida e fundo limpo, que ocorre no local de entrada da bactéria (pênis, vulva, vagina, colo uterino, ânus, boca, ou outros locais do tegumento), sendo denominada “cancro duro”. A lesão primária é acompanhada de linfadenopatia regional (acometendo  
#%¥ Conitec  
linfonodos localizados próximos ao cancro duro). Sua duração pode variar muito, em geral de três a oito semanas, e seu desaparecimento independe de tratamento. Pode não ser notada ou não ser valorizada pelo paciente. Embora menos frequente, em alguns casos a lesão primária pode ser múltipla.  
**Sífilis secundária:** ocorre em média entre seis semanas a seis meses após a cicatrização do cancro, ainda que manifestações iniciais, recorrentes ou subentrantes do secundarismo possam ocorrer em um período de até um ano. Excepcionalmente, as lesões podem ocorrer em concomitância com a manifestação primária. As manifestações são muito variáveis, mas tendem a seguir uma cronologia própria.  
Inicialmente, apresenta-se uma erupção macular eritematosa pouco visível (roséola), principalmente no tronco e raiz dos membros. Nessa fase, são comuns as placas mucosas, assim como lesões acinzentadas e pouco visíveis nas mucosas. As lesões cutâneas progridem para lesões mais evidentes, papulosas eritemato-acastanhadas, que podem atingir todo o tegumento, sendo frequentes nos genitais. Habitualmente, atingem a região plantar e palmar, com um colarinho de escamação característico, em geral não pruriginosa.  
Mais adiante, podem ser identificados condilomas planos nas dobras mucosas, especialmente na área anogenital. Estas são lesões úmidas e vegetantes que frequentemente são confundidas com as verrugas anogenitais causadas pelo HPV. Alopecia em clareiras e madarose são achados eventuais. O secundarismo é acompanhado de micropoliadenopatia, sendo característica a identificação dos gânglios epitrocleares. São comuns sintomas inespecíficos como febre baixa, mal-estar, cefaleia e adinamia.  
A sintomatologia desaparece em algumas semanas, independentemente de tratamento, trazendo a falsa impressão de cura. Atualmente, têm-se tornado mais frequentes os quadros oculares, especialmente uveítes. A neurossífilis meningovascular, com acometimento dos pares cranianos, quadros meníngeos e isquêmicos, pode acompanhar essa fase, contrariando a ideia de que a doença neurológica é exclusiva de sífilis tardia. Há que se considerar esse diagnóstico especialmente, mas não exclusivamente, em pacientes com imunodepressão.

---

<!-- METADADOS: doenca: Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais | secao: #%¥ Conitec <u>Sy</u> | <u>te</u> _Toda erupção cutânea sem causa determinada deve ser investigada com testes para sífilis._ ~~Po~~ -->
**Sífilis latente:** período em que não se observa nenhum sinal ou sintoma. O diagnóstico faz-se exclusivamente pela reatividade dos testes treponêmicos e não treponêmicos. A maioria dos diagnósticos ocorre nesse estágio. A sífilis latente é dividida em latente recente (até um ano de infecção) e latente tardia (mais de um ano de infecção). Aproximadamente 25% dos pacientes não tratados intercalam lesões de secundarismo com os períodos de latência.  
**Sífilis terciária:** ocorre aproximadamente em 15% a 25% das infecções não tratadas, após um período variável de latência, podendo surgir entre entre 1 e 40 anos depois do início da infecção. A inflamação causada pela sífilis nesse estágio provoca destruição tecidual. É comum o acometimento do sistema nervoso e do sistema cardiovascular. Além disso, verifica-se a formação de gomas sifilíticas (tumorações com tendência a liquefação) na pele, mucosas, ossos ou qualquer tecido. As lesões podem causar desfiguração, incapacidade e até morte.  
O Quadro 21 correlaciona as manifestações clínicas de sífilis adquirida com a evolução e estágios da doença.  
Quadro 21 – Manifestações clínicas de sífilis adquirida, de acordo com o tempo de infecção, evolução e estágios da doença  
|**ESTÁGIOS DE SÍFILIS**<br>**ADQUIRIDA**|**MANIFESTAÇÕES CLÍNICAS**|
|---|---|
|**Primária**|Cancro duro (úlcera genital)<br>Linfonodos regionais|
||Lesões cutâneo-mucosas (roséola, placas mucosas, sifílides papulosas,<br>sifílides palmoplantares, condiloma plano, alopecia em clareira,<br>madarose, rouquidão)|
|**Secundária**|Micropoliadenopatia<br>Linfadenopatia generalizada|
||Sinais constitucionais|
||Quadros neurológicos, oculares, hepáticos|  
#### £% Conitec  
|**Latente recente (até**<br>**um ano de duração)**|Assintomática|
|---|---|
|**Latente tardia (mais**||
|**de**<br>**um**<br>**ano**<br>**de**|Assintomática|
|**duração**||
||Cutâneas: lesões gomosas e nodulares, de caráter destrutivo.|
||Ósseas: periostite, osteíte gomosa ou esclerosante, artrites, sinovites e<br>nódulos justa-articulares.|
|**Terciária**|Cardiovasculares: estenose de coronárias, aortite e aneurisma da aorta,<br>especialmente da porção torácica.|
||Neurológicas: meningite, gomas do cérebro ou da medula, atrofia do<br>nervo óptico, lesão do sétimo par craniano, manifestações<br>psiquiátricas,_tabes dorsalis_e quadros demenciais como o da<br>paralisia geral.|  
Fonte: DCCI/SVS/MS.  
###### **4.4.  Métodos diagnósticos de sífilis**  
Os testes utilizados para o diagnóstico de sífilis são divididos em duas categorias: exames diretos e testes imunológicos.  
###### **Exames diretos de sífilis**  
Os exames diretos são aqueles em que se realiza a pesquisa ou detecção do _T. pallidum_ em amostras coletadas diretamente das lesões, e estão descritos no Quadro 22.

---

<!-- METADADOS: doenca: Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais | secao: #%¥ Conitec <u>Sy</u> | <u>te</u> _Toda erupção cutânea sem causa determinada deve ser investigada com testes para sífilis._ ~~Po~~ -->
Quadro 22 – Métodos diagnósticos de sífilis: exames diretos  
|**Método**|**Manifestações**<br>**clínicas de**<br>**sífilis**|**Material**|**Sensibilidade/**<br>**especifici**<br>**dade**|**Significado clínico**|**Observações**|
|---|---|---|---|---|---|
|**Exame**||Exsudato<br>seroso<br>das<br>lesões<br>ativas<br>para<br>observ|Alta<br>sensibilida<br>de<br>e<br>especificid<br>ade<br>Depende<br>da<br>experiênci|**Positivo:**<br>infecção<br>ativa.<br>Considerar<br>diagnóstico<br>diferencial com<br>treponemas<br>ã|Positividade em<br>pessoas<br>com cancro<br>primário|
|**em**<br>**campo**<br>**escuro**|Lesões primárias<br>e|ação<br>dos<br>trepon<br>emas<br>viáveis<br>em<br>amostr|a<br>do<br>técnico<br>Teste eficiente<br>e de baixo<br>custo para<br>diagnóstic<br>o<br>direto|no<br>patogênicos e<br>outros<br>organismos<br>espiralados<br>**Negativo:**<br>considerar que|pode<br>ser<br>anterior à<br>soroconver<br>são<br>(positivida<br>de<br>nos<br>testes|
||secundária<br>s|as<br>frescas|de sífilis|1) O número de_T._<br>_pallidum_<br>na|imunológic<br>os)|
|**Pesquisa**<br>**direta**<br>**com**<br>**material**<br>**corado**||Esfregaço<br>em<br>lâmina<br>ou<br>cortes<br>histoló<br>gicos<br>com<br>diferen<br>tes|Todas<br>as<br>técnicas<br>têm<br>sensibilida<br>de inferior<br>à<br>microscop<br>ia<br>de<br>campo|amostra<br>não<br>foi<br>suficiente<br>para<br>sua<br>detecção;<br>2)<br>A<br>lesão<br>está<br>próxima à cura<br>natural;<br>3) A pessoa recebeu<br>tratamento<br>sistêmico<br>ou|Não<br>é<br>recomenda<br>do<br>para<br>lesões<br>de<br>cavidade<br>oral|
|||corant<br>es|escuro|tópico||  
#### £% Conitec  
Fonte: DCCI/SVS/MS.  
###### **Testes imunológicos de sífilis**  
Os testes imunológicos são, certamente, os mais utilizados na prática clínica. Caracterizam-se pela realização de pesquisa de anticorpos em amostras de sangue total, soro ou plasma. Esses testes são subdivididos em duas classes, os treponêmicos e os não treponêmicos (Quadro 23).  
###### **Testes treponêmicos**  
São testes que detectam anticorpos específicos produzidos contra os antígenos de _T. pallidum._ São os primeiros a se tornarem reagentes, podendo ser utilizados como primeiro teste ou teste complementar. Em 85% dos casos, permanecem reagentes por toda vida, mesmo após o tratamento e, por isso, não são indicados para o monitoramento da resposta ao tratamento.  
Existem vários tipos de testes treponêmicos<sup>1</sup> :  
- Os Testes Rápidos (TR) utilizam principalmente a metodologia de imunocromatografia de fluxo lateral ou de plataforma de duplo percurso (DPP). São distribuídos pelo Ministério da Saúde para estados e Distrito Federal, sendo os mais indicados para início de diagnóstico,  
_Os TR são práticos e de fácil execução, com leitura do resultado em, no máximo, 30 minutos. Podem ser realizados com amostras de sangue total colhidas por punção digital ou venosa. Têm a vantagem de serem realizados no momento da consulta, possibilitando tratamento imediato._  
- Testes de hemaglutinação (TPHA, do inglês _T. Pallidum Haemagglutination Test_ ) e de aglutinação de partículas (TPPA, do inglês _T. Pallidum Particle Agglutination Assay_ ); ensaios de micro-hemaglutinação (MHA-TP, do inglês _Micro-Haemagglutination Assay_ ).  
- Teste de imunofluorescência indireta (FTA-Abs, do inglês _Fluorescent Treponemal AntibodyAbsorption_ ).  
> 1 Os testes de hemaglutinação (TPHA), aglutinação de partículas (TPPA) e de imunofluorescência indireta (FTA-abs) são produzidos com antígenos naturais de _Treponema pallidum_ . Esses antígenos são difíceis de obter e, por isso, tornam tais testes mais caros. As metodologias do tipo ELISA, CMIA e os testes rápidos são produzidas com antígenos sintéticos ou recombinantes, fator que favorece sua comercialização por preços menores.  
#%¥ Conitec  
- Ensaios imunoenzimáticos (como os testes ELISA, do inglês _Enzyme-Linked Immunossorbent Assay_ ) e suas variações, como os ensaios de quimiluminescência (CMIA). A vantagem desses ensaios é sua elevada sensibilidade e capacidade de automação.  
###### **Testes não treponêmicos**  
Esses testes detectam anticorpos anticardiolipina não específicos para os antígenos do _T. pallidum_ . Permitem a análise qualitativa e quantitativa. Sempre que um teste não treponêmico é realizado, é imprescindível analisar a amostra pura e diluída, em virtude do fenômeno prozona<sup>2</sup> . Uma vez observada reatividade no teste, a amostra deve ser diluída em um fator dois de diluição, até a última diluição em que não haja mais reatividade no teste. O resultado final dos testes reagentes, portanto, deve ser expresso em títulos (1:2, 1:4, 1:8, etc.). Os testes não treponêmicos são utilizados para o diagnóstico (como primeiro teste ou teste complementar) e também para o monitoramento da resposta ao tratamento e controle de cura.  
A queda adequada dos títulos é o indicativo de sucesso do tratamento. Os testes não treponêmicos mais comumente utilizados no Brasil são o VDRL (do inglês _Venereal Disease Research Laboratory_ ), o RPR (do inglês _Rapid Plasma Reagin_ ) e o USR (do inglês _Unheated-Serum Reagin_ ). Resultados falsoreagentes, ainda que raros, podem ocorrer. Anticorpos anticardiolipinas podem estar presentes em outras doenças. Por isso, é sempre importante realizar testes treponêmicos e não treponêmicos para a definição laboratorial do diagnóstico.  
Os testes não treponêmicos tornam-se reagentes cerca de uma a três semanas após o aparecimento do cancro duro. Se a infecção for detectada nas fases tardias da doença, são esperados títulos baixos nesses testes. Títulos baixos (<1:4) podem persistir por meses ou anos. Pessoas com títulos baixos em testes não treponêmicos, sem registro de tratamento e sem data de infecção conhecida, são consideradas como portadoras de sífilis latente tardia, devendo ser tratadas.  
> 2 A diferenciação entre teste qualitativo e quantitativo faz parte da rotina laboratorial para testar amostras com testes não treponêmicos. O teste qualitativo se inicia com amostra pura e diluída 1:8 ou 1:16, para evitar resultados falso-negativos em virtude do fenômeno de prozona.  
> Toda amostra reagente no teste qualitativo deve ser testada com o teste quantitativo para determinar o título, ou seja, a maior diluição da amostra que ainda é reagente. As diluições testadas são 1:2, 1:4, 1:8, 1:16, 1:32, 1:64, 1:128, 1:256, 1:512, 1:1024 e assim sucessivamente.  
> O fenômeno de prozona consiste na falta de reatividade no teste realizado em uma amostra que, embora contenha anticorpos não treponêmicos, apresenta resultado não reagente quando é testada sem diluir.  
> Trata-se de fenômeno produzido por excesso de anticorpos em relação à quantidade de antígenos, com formação de imunocomplexos solúveis, gerando resultados falso-negativos.  
> Se a amostra for não reagente no teste qualitativo, naturalmente não precisa de diluição para quantificação de anticorpos.  
**Quadro 23 – Métodos diagnósticos de sífilis: testes imunológicos**  
|||VDRL|Quantificáveis (ex.: 1:2, 1:4, 1:|8).|
|---|---|---|---|---|
||**Não**<br>**treponêmicos**|RPR<br>TRUST<br>USR|Importantes para o diagn<br>monitoramento da res<br>tratamento.|óstico e<br>posta ao|
|**TESTES**<br>**IMUNOLÓGICOS**|**Treponêmicos**|FTA-Abs<br>ELISA/EQL/CMIA<br>TPHA/TPPA/MHA-<br>TP|São os primeiros a se<br>reagentes.<br>Na maioria das vezes, per<br>reagentes por toda a vid<br>após o tratamento.<br>São importantes para o diagnó|tornarem<br>manecem<br>a, mesmo<br>stico, mas|
|||Teste Rápido (TR)|**não**<br>**estão**<br>**indicad**<br>**monitoramento da res**<br>**tratamento.**|**os**<br>**para**<br>**posta ao**|
|Fonte: DCCI/SVS/MS.|||||
|_A análise isolada do_<br>_RPR) é um equí_<br>_do qual o resul_<br>_falso-reagente_<br>_inadequadas._<br>_Há que se incorporar_<br>_(em queda) po_<br>_títulos baixos p_<br>_- infecção recente;_<br>_- estágios tardios da_<br>_- casos de pessoas a_<br>|_título de um únic_<br>_voco frequente. T_<br>_tado seria indicat_<br>_ou de inatividad_<br>_definitivamente a_<br>_dem ser encontra_<br>_odem ser encontr_<br>_infecção (sífilis ta_<br>_dequadamente tr_<br>|_o resultado de um test_<br>_extos antigos menciona_<br>_ivo de doença ativa e,_<br>_e da doença. Essa ideia_<br>_ideia de que títulos alt_<br>_dos em pacientes adeq_<br>_ados em três situações:_<br>_rdia); e_<br>_atadas que não tenham_<br>|_e não treponêmico (ex.: VDRL,_<br>_vam um ponto de corte acima_<br>_abaixo, indicativo de resultado_<br>_leva a decisões terapêuticas_<br>_os nos testes não treponêmicos_<br>_uadamente tratados, e de que_<br> <br>_atingido a negativação. Esse_<br>||  
<!-- Start of picture text -->
Le Conitec zs<br><!-- End of picture text -->  
_fenômeno pode ser temporário ou persistente e é denominado cicatriz sorológica._  
_Os testes treponêmicos (ex. testes rápidos, FTA-Abs, TPHA), por sua vez, permanecem quase sempre reagentes por toda a vida, apesar de tratamento adequado. Entretanto, frente a achados clínico-epidemiológicos, na ausência de tratamento, são indicativos de doença ativa. Ainda assim, os testes não treponêmicos devem ser solicitados para acompanhamento sorológico._  
A Figura 8 apresenta o desempenho dos testes laboratoriais em cada estágio de sífilis.  
Figura 8 – Estágios clínicos e métodos diagnósticos de sífilis  
<!-- Start of picture text -->
Curso da sifilis nao tratada<br>TESTES<br>SENSIBILIDADE FTA-abs e outros testes treponémicos<br>100<br>90 VDRLe outros testes<br>80 nao treponémicos<br>70 campo caro<br>60 POSITIVO POsITIVO<br>° — CF<br>FASES PRIMARIA SECUNDARIA LATENTE TERCIARIA<br>cunso. yesecunpanias = LATENTE | LATENTE<br>EXPOSICAO—> —<br>Bias | [S'Sewanas SEMANAS t t<br>LewesTau | APOS A'SIFILIS APOS A'SIFILIS<br>PRIMARIA PRIMARIA’<br><!-- End of picture text -->  
Fonte: adaptado de Brasil, 2006.  
###### **4.5. Diagnóstico de sífilis**  
O diagnóstico de sífilis exige uma correlação entre dados clínicos, resultados de testes laboratoriais, histórico de infecções passadas e investigação de exposição recente. Apenas o conjunto de todas essas  
###### O e 2% Conitec  
informações permitirá a correta avaliação diagnóstica de cada caso e, consequentemente, o tratamento adequado.  
A presença de sinais e sintomas compatíveis com sífilis (primária, secundária e terciária) favorecem a suspeição clínica. Entretanto, não há sinal ou sintoma patognomônico da doença. Portanto, para a confirmação do diagnóstico é necessária a solicitação de testes diagnósticos. Nas fases sintomáticas, é possível a realização de exames diretos, enquanto os testes imunológicos podem ser utilizados tanto na fase sintomática quanto na fase de latência.  
###### **A escolha dos testes imunológicos**  
Considerando a sensibilidade dos fluxos diagnósticos, recomenda-se, sempre que possível, iniciar a investigação por um teste treponêmico, preferencialmente o teste rápido.  
A combinação de testes sequenciais tem por objetivo aumentar o valor preditivo positivo (VPP) de um resultado reagente no teste inicial. O fluxograma em série é custo-efetivo e está apresentado na Figura 9.  
Figura 9 – Testes imunológicos para diagnóstico de sífilis  
<!-- Start of picture text -->
Teste treponémico Teste nao<br>REAGENTE: treponémico Diagnéstico<br>~ Teste rapido + REAGENTE: = de sifilis<br>-FTA-Abs —s -VDRL confirmado*<br>- TPHA -RPR<br>-EQL<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
*O diagnóstico de sífilis não estará confirmado quando houver presença de cicatriz sorológica, ou seja, tratamento anterior para sífilis com documentação da queda da titulação em pelo menos duas diluições (ex.: uma titulação de 1:16 antes do tratamento que se torna menor ou igual a 1:4 após o tratamento).  
_Considerando a epidemia de sífilis no Brasil e a sensibilidade dos fluxos de diagnóstico, recomendase iniciar a investigação pelo_ **_teste treponêmico_** _, que é o primeiro teste a ficar reagente._  
<!-- Start of picture text -->
#%¥ Conitec Sy | tes<br><!-- End of picture text -->  
Os profissionais de saúde, tanto da medicina quanto da enfermagem, devem solicitar os testes imunológicos para sífilis, explicitando no formulário de solicitação a finalidade do exame:  
**Diagnóstico de sífilis:** solicitação para rede laboratorial. Deverá ser solicitado na indisponibilidade do teste rápido no serviço.  
**Diagnóstico de sífilis após TR reagente** : quando foi realizada a testagem rápida no serviço de saúde e  
com resultado reagente. Nesse momento, o laboratório iniciará a investigação com o teste não treponêmico.  
**Monitoramento do tratamento de sífilis:** Quando o diagnóstico e tratamento da sífilis já foram realizados e é necessário monitorar os títulos dos anticorpos não treponêmicos.  
###### **Interpretação dos testes imunológicos e conduta**  
O Quadro 24 apresenta as possíveis interpretações e conduta frente ao resultado dos testes imunológicos.  
Quadro 24 – Resultados de testes treponêmicos e não treponêmicos de sífilis, interpretação e conduta  
|||**TESTE**|||
|---|---|---|---|---|
|**PRIMEIRO TESTE**|**+**|**COMPLE-**|**POSSÍVEIS INTERPRETAÇÕES**|**CONDUTA**|
|||**MENTAR**|||

---

<!-- METADADOS: doenca: Prevenção da Transmissão Vertical do HIV, Sífilis e Hepatites Virais | secao: #%¥ Conitec <u>Sy</u> | <u>te</u> _Toda erupção cutânea sem causa determinada deve ser investigada com testes para sífilis._ ~~Po~~ -->
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|Diagnóstico de sífilis.<br><br>Classificação do estágio clínico a<br>ser definida de acordo com o<br>tempo de infecção e o histórico<br>de tratamento.<br>Cicatriz sorológica: tratamento anterior<br>documentado<br>com<br>queda<br>da<br>titulação em pelo menos duas<br>diluições.|Quando sífilis, tratar,<br>realizar<br>monitoramento<br>com<br>teste<br>não<br>treponêmico<br>e<br>notificar o caso de<br>sífilis.<br>Quando<br>confirmado<br>caso de cicatriz<br>sorológica, apenas<br>orientar.|
|---|---|---|---|
|**Teste**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste não**<br>**treponêmico:**<br>**não reagente**|Realiza-se um**terceiro teste**treponêmico<br>com metodologia diferente do<br>primeiro.<br><br>Se**reagente:**diagnóstico de sífilis<br>ou cicatriz sorológica.<br><br>Se**não reagente:**considera-se<br>resultado falso reagente para o<br>primeiro teste, sendo excluído o<br>diagnóstico de sífilis.<br>Se terceiro teste treponêmico não estiver<br>disponível, avaliar exposição de<br>risco, sinais e sintomas e histórico de<br>tratamento<br>para<br>definição<br>de<br>conduta.|Quando sífilis, tratar,<br>realizar<br>monitoramento<br>com<br>teste<br>não<br>treponêmico<br>e<br>notificar o caso de<br>sífilis.<br>Quando<br>confirmado<br>caso de cicatriz<br>sorológica, apenas<br>orientar.<br>Para os casos concluídos<br>como ausência de<br>sífilis,<br>apenas<br>orientar.|  
##### #%¥ Conitec  
|||Diagnóstico de sífilis.|Quando sífilis, tratar,|
|---|---|---|---|
|**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|**+**<br>**Teste**<br>**treponêmico:**<br>**reagente**|<br>Classificação do estágio clínico a<br>ser definida de acordo com o<br>tempo de infecção e o histórico<br>de tratamento.<br>Cicatriz sorológica: tratamento anterior<br>documentado<br>com<br>queda<br>da<br>titulação em pelo menos duas<br>diluições.|realizar<br>monitoramento<br>com<br>teste<br>não<br>treponêmico<br>e<br>notificar o caso de<br>sífilis.<br>Quando<br>confirmado<br>caso de cicatriz<br>sorológica, apenas<br>orientar.|  
#### £% Conitec  
||||Realiza-se um**terceiro teste**treponêmico|Quando sífilis, tratar,|
|---|---|---|---|---|
||||com metodologia diferente do<br>primeiro.|realizar<br>monitoramento|
|**Teste**<br>**não**<br>**treponêmico:**<br>**reagente**|**+**|<br>**Teste**<br>**treponêmico:**<br>**não reagente**|O resultado final do fluxograma será<br>definido<br>pelo<br>resultado<br>desse<br>**terceiro teste.**<br><br>Se**reagente**, diagnóstico de sífilis<br>ou cicatriz sorológica.<br><br>Se**não reagente**, considera-se<br>resultado falso reagente para o<br>primeiro teste, sendo excluído o<br>diagnóstico de sífilis.<br>Cicatriz sorológica: tratamento anterior<br>documentado<br>com<br>queda<br>da<br>titulação em pelo menos duas<br>diluições.<br>Se terceiro teste treponêmico não estiver<br>disponível, avaliar exposição de<br>risco, sinais e sintomas e histórico de<br>tratamento<br>para<br>definição<br>de<br>conduta.|com<br>teste<br>não<br>treponêmico<br>e<br>notificar o caso de<br>sífilis.<br>Quando<br>confirmado<br>caso de cicatriz<br>sorológica, apenas<br>orientar.<br>Para os casos concluídos<br>como ausência de<br>sífilis,<br>apenas<br>orientar.|  
##### #%¥ Conitec  
|||Ausência de infecção ou período de|Em|caso de suspeita|
|---|---|---|---|---|
|||incubação (janela imunológica) de<br>sífilis recente.||clínica<br>e/ou<br>epidemiológica,|
|||||solicitar<br>nova<br>coleta de amostra|
||Não<br>realizar|||em 30 dias.|
|**Teste**<br>**não**|teste||Isso|não<br>deve,<br>no|
|**treponêmico:**|complementar|||entanto, retardar a|
|**não reagente**|se o primeiro|||instituição<br>do|
|**ou**|**+**<br>teste for**não**<br>**reagente**e se|||tratamento, caso o<br>diagnóstico<br>de|
|**Teste**|não<br>houver|||sífilis seja o mais|
|**treponêmico:**|suspeita clínica|||provável<br>(ex.:|
|**não reagente**|de<br>sífilis|||visualização<br>de|
||primária|||úlcera anogenital)|
|||||ou o retorno da<br>pessoa ao serviço|
|||||de<br>saúde<br>não|
|||||possa<br>ser|
|||||garantido.|  
Fonte: DCCI/SVS/MS.  
###### **4.6. Tratamento de sífilis**  
A benzilpenicilina benzatina é o medicamento de escolha para o tratamento de sífilis, sendo a única droga com eficácia documentada durante a gestação. Não há evidências de resistência de _T. pallidum_ à penicilina no Brasil e no mundo.  
Devido ao cenário epidemiológico atual, recomenda-se tratamento imediato, com benzilpenicilina benzatina, após apenas um teste reagente para sífilis (teste treponêmico ou teste não treponêmico) para as seguintes situações (independentemente da presença de sinais e sintomas de sífilis):  
- gestantes;  
- vítimas de violência sexual;  
#%¥ Conitec  
- pessoas com chance de perda de seguimento (que não retornarão ao serviço);  
- pessoas com sinais/sintomas de sífilis primária ou secundária; e  
- pessoas sem diagnóstico prévio de sífilis.  
O fato da realização do tratamento com apenas um teste reagente para sífilis não exclui a necessidade de realização do segundo teste (melhor análise diagnóstica), do monitoramento laboratorial (controle de cura) e do tratamento das parcerias sexuais (interrupção da cadeia de transmissão).  
Para pacientes sintomáticos com suspeita de sífilis primária e secundária e impossibilidade de realização de qualquer teste diagnóstico, recomenda-se tratamento empírico imediato para sífilis recente, assim como para as respectivas parcerias sexuais.  
###### **Aplicação de benzilpenicilina benzatina**  
Como medida de garantia de acesso, a benzilpenicilina benzatina passou a ser componente estratégico na Relação Nacional de Medicamentos Essenciais (Rename) 2017, com aquisição centralizada pelo Ministério da Saúde (6,7). A compra e distribuição tem como base de cálculo os casos notificados de sífilis adquirida e de sífilis em gestantes.  
A benzilpenicilina benzatina dever ser administrada exclusivamente por via intramuscular (IM). A região **ventroglútea é a via preferencial** , por ser livre de vasos e nervos importantes, sendo tecido subcutâneo de menor espessura, com poucos efeitos adversos e dor local. Outros locais alternativos para aplicação são a região do vasto lateral da coxa e o dorso glúteo.  
###### **Tratamento de sífilis recente, sífilis tardia**  
O Quadro 25 apresenta os esquemas terapêuticos utilizados para sífilis, de acordo com a classificação clínica.  
Quadro 25 – Tratamento e monitoramento de sífilis em gestante  
|**ESTADIAMENTO**|**ESQUEMA**|**SEGUIMENTO (TESTE NÃO TREPONÊMICO)**|
|---|---|---|
||**TERAPÊUTICO**<sup>a</sup>||  
|Sífilis recente: sífilis|Benzilpenicilina<br>benzatina|Teste não treponêmico mensal|
|---|---|---|
|primária,|2,4 milhões UI, IM, dose||
|secundária<br>e|única (1,2 milhão UI em||
|latente recente|cada glúteo)<sup>b</sup>||
|(com até um|||
|ano<br>de<br>evolução)|||
|Sífilis tardia: sífilis|Benzilpenicilina<br>benzatina|Teste não treponêmico mensal|
|latente<br>tardia|2,4 milhões UI, IM,||
|(com mais de|1x/semana (1,2 milhão||
|um<br>ano<br>de|UI em cada glúteo) por||
|evolução)<br>ou|3 semanas<sup>c</sup>||
|latente<br>com<br>duração|Dose total: 7,2 milhões UI, IM||
|ignorada e sífilis<br>terciária|||  
Fonte: DCCI/SVS/MS.  
a A benzilpenicilina benzatina é a única opção segura e eficaz para tratamento adequado das gestantes.  
> b Alguns experts recomendam uma dose adicional de 2,4 milhões  de unidades de penicilina G benzatina, IM, uma semana após a primeira dose (8).  
- c O intervalo entre doses não deve ultrapassar 7 dias. Caso isso ocorra, o esquema deve ser reiniciado (8).  
A benzilpenicilina benzatina é a única opção segura e eficaz para o tratamento adequado das gestantes. Qualquer outro tratamento realizado durante a gestação, para fins de definição de caso e abordagem terapêutica de sífilis congênita, é considerado tratamento não adequado da mãe; por conseguinte, o RN será notificado como sífilis congênita e submetido à avaliação clínica e laboratorial. A resolução dos sinais e sintomas após o tratamento, caso estes tenham estado previamente presentes, é indicativa de resposta à terapia. No entanto, o monitoramento pós-tratamento com teste não treponêmico é recomendado a todos os pacientes para determinar se ocorreu resposta imunológica adequada, haja vista que, mesmo com o tratamento adequado na gravidez, em cerca de 14% dos casos poderá ocorrer óbito fetal ou nascimento de crianças com evidências clinicas de sífilis  
##### #%¥ Conitec  
congênita (9–12).  
Os principais fatores relacionados com falha terapêutica da sífilis materna são:  
- coinfecção HIV-sífilis;  
- os estágios precoces da sífilis **;**  
- altos títulos de VDRL no momento do tratamento e parto;  
- severidade da doença fetal: hidropsia, hepatomegalia, espessamento placentário, ascite e anemia fetal;  
- tratamento após 24 semanas;  
- esquema terapêutico reduzido para a fase clínica.  
###### **Reação de Jarisch-Herxheimer**  
A reação de Jarisch-Herxheimer é um evento que pode ocorrer durante as 24 horas após a primeira dose de penicilina, em especial nas fases primária ou secundária. Caracteriza-se por exacerbação das lesões cutâneas, mal-estar geral, febre, cefaleia e artralgia, que regridem espontaneamente após 12 a 24 horas (13). Pode ser controlada com o uso de analgésicos simples, conforme a necessidade, sem ser preciso descontinuar o tratamento.  
As pessoas com prescrição de tratamento devem ser alertadas quanto à possibilidade de ocorrência dessa reação, em especial para que se faça distinção em relação aos quadros de alergia à penicilina. Estes são muito raros com o uso da benzilpenicilina benzatina e, quando ocorrem, apresentam-se frequentemente na forma de urticária e exantema pruriginoso.  
Gestantes que apresentam essa reação podem ter risco de trabalho de parto prematuro, pela liberação de prostaglandinas em altas doses. Entretanto, caso a gestante não seja tratada adequadamente para sífilis, o risco de abortamento ou morte fetal é maior que os riscos potenciais da reação.  
###### **Segurança e eficácia da administração da benzilpenicilina benzatina**  
> _A administração de benzilpenicilina benzatina pode ser feita com segurança na Atenção Básica, tanto para a pessoa com sífilis quanto suas(s) parceria(s) sexual(is)._ ~~<mark>PO</mark>~~  
#%¥ Conitec  
A probabilidade de reação adversa às penicilinas, em especial as reações graves, é muito rara. Diversos medicamentos normalmente prescritos e utilizados na prática clínica diária (ex.: anti-inflamatórios não esteroides – AINE, lidocaína etc.), bem como alimentos (ex.: nozes, frutos do mar, corantes etc.), apresentam maiores riscos de anafilaxia; todavia, não há tanto temor quanto à sua administração ou consumo. Infelizmente, o receio de reações adversas à penicilina por profissionais de saúde, em especial a raríssima reação anafilática, tem contribuído para a perda do momento oportuno de tratamento de pessoas com sífilis, colaborando para a manutenção da cadeia de transmissão da doença, inclusive na sua faceta mais grave, a sífilis congênita.  
A possibilidade de reação anafilática à administração de benzilpenicilina benzatina é de 0,002%, segundo levantamento das evidências científicas constante no relatório de recomendação: “Penicilina benzatina para prevenção da Sífilis Congênita durante a gravidez”, elaborado pela Comissão Nacional de Incorporação de Tecnologia no SUS – Conitec (7).  
O receio de ocorrência de reações adversas não é impeditivo para a administração de benzilpenicilina benzatina nos serviços de saúde, especialmente na Atenção Básica. A anafilaxia, como discutido anteriormente, não é exclusiva das penicilinas e, portanto, os serviços devem estar cientes dos procedimentos a serem adotados em tal situação. A adrenalina é a droga de escolha para tratamento da reação de anafilaxia, caso esta ocorra, e a pessoa deverá receber atendimento conforme preconizado pelo Caderno da Atenção Básica nº 28, v. II, “Acolhimento à Demanda Espontânea: Queixas mais comuns na Atenção Básica”, capítulo 2: Queixas comuns no atendimento à demanda espontânea e urgências/emergências, p. 25 (14).  
Destaca-se também a Decisão nº 0094/2015, do Conselho Federal de Enfermagem – Cofen, que reforça a importância da administração da benzilpenicilina benzatina pelos profissionais de enfermagem na Atenção Básica (COFEN, 2015), além da Nota Técnica Cofen/CTLN nº 03/2017, que reafirma esse compromisso de cuidado à saúde (15).  
###### **Teste de sensibilidade à benzilpenicilina benzatina**  
A maioria dos casos identificados grosseiramente como suspeitos de serem alérgicos à penicilina carece de anamnese criteriosa para qualificar essa alteração. Em vista disso, é fundamental e imperativo que a anamnese seja objetiva, para a adequada obtenção dessas informações. Tal decisão fundamentou-se no elevado número de casos suspeitos de alergia à penicilina encaminhados para dessensibilização, constatando-se que a quase totalidade deles foram descartados somente pela  
##### #%¥ Conitec  
anamnese. Por sua vez, o uso de derivados da penicilina também pode deflagrar crise de alergia à penicilina (16).  
Relembre-se que dor e reação local, exantema maculopapular, náusea, prurido, mal-estar, cefaleia, história de algum evento suspeito há mais de dez anos, história familiar, entre outras manifestações, isoladamente não configuram alergia à penicilina. As manifestações clínicas que justificam encaminhar a gestante para descartar o diagnóstico de alergia à sífilis incluem reação anafilática prévia e lesões cutâneas graves, como síndrome de Stevens-Johnson (17). Gestantes comprovadamente alérgicas à penicilina devem ser dessensibilizadas em ambiente hospitalar.  
Para orientar a anamnese, visando a obter informações mais específicas sobre o passado de alergia à penicilina, pode-se dirigir às gestantes algumas perguntas com maior potencial de assertividade, dentre elas:  
- 1) você se lembra dos detalhes da reação?  
- 2) há quantos anos a reação ocorreu?  
- 3) como foi o tratamento?  
- 4) qual foi o resultado?  
- 5) por que você recebeu penicilina?  
- 6) você já fez algum tratamento com antibióticos depois desse evento?  
- 7) quais foram esses medicamentos (lembrar que medicamentos como a ampicilina, a amoxicilina e as  
- cefalosporinas são exemplos de drogas derivadas da penicilina)?  
- 8) você já fez uso de penicilina ou de seus derivados após esse evento que você acha que foi alergia à penicilina?  
###### **4.7. Monitoramento pós-tratamento de sífilis**  
_Para o seguimento do paciente, os testes não treponêmicos (ex.: VDRL/ RPR) devem ser realizados mensalmente nas gestantes e, no restante da população (incluindo PVHIV), a cada três meses até o 12º mês do acompanhamento do paciente (3, 6, 9 e 12 meses)._  
<!-- Start of picture text -->
#%¥ Conitec ST ot 5<br><!-- End of picture text -->  
A pessoa tratada com sucesso pode ser liberada de novas coletas após um ano de seguimento pós tratamento. Entretanto, a aquisição de uma nova IST, especialmente sífilis, é um fator de risco para outras IST. Deve ser fortemente considerada a realização de rastreamento de acordo com a história sexual e o gerenciamento de risco para sífilis e outras IST na população de pessoas curadas de sífilis.  
Os testes não treponêmicos não são automatizados; portanto, pode haver diferença entre leituras em momentos diferentes e/ou quando realizadas por mais de um observador. Por essa razão, variações do título em uma diluição (ex.: de 1:2 para 1:4; ou de 1:16 para 1:8) devem ser analisadas com cautela.  
O monitoramento é fundamental para classificar a resposta ao tratamento, identificar possível reinfecção e definir a conduta correta para cada caso. Didaticamente, a resposta ao tratamento foi classificada em:  
- resposta imunológica adequada; e  
- critérios de retratamento: reativação e/ou reinfecção.  
- _O monitoramento deve ser realizado com teste não treponêmico e, sempre que possível, com o mesmo método diagnóstico._  
_Por exemplo: se o diagnóstico for realizado com VDRL, deve-se manter seguimento com VDRL. Em caso de diagnóstico realizado com RPR, manter seguimento com RPR._  
###### **4.8. Resposta imunológica ao tratamento de sífilis**  
Considera-se sucesso de tratamento para sífilis em gestante, após a última dose de penicilina (3,8,18,19):  
- a diminuição da titulação do teste não treponêmico em duas diluições (p. ex. 1:64 para 1:16) em até três meses e quatro diluições (p. ex. 1:64 para 1:4) em até seis meses, com evolução até a sororreversão (teste não treponêmico não reagente).  
- a diminuição na titulação em duas diluições em até seis meses para sífilis recente ou em até 12 meses para sífilis tardia **.**  
#### £% Conitec  
Deve ser ressaltado a importância de a gestante ser testada mensalmente após o tratamento para avaliar, além da queda de títulos, a possibilidade de elevação por tratamento inadequado, falha terapêutica ou reinfecção.  
Quanto mais precoce for o diagnóstico e o tratamento, mais rapidamente haverá desaparecimento dos anticorpos circulantes e consequente negativação dos testes não treponêmicos, ou, ainda, sua estabilização em títulos baixos.  
Deve-se realizar a coleta do teste não treponêmico, sempre que possível, no início do tratamento (idealmente, no primeiro dia de tratamento), uma vez que os títulos podem aumentar significativamente se o tratamento só for iniciado após alguns dias do diagnóstico. Isso é importante para documentação da titulação no momento do início do tratamento e servirá como base para o monitoramento clínico.  
A definição de “cicatriz sorológica” é a persistência de resultados reagentes em testes não treponêmicos após o tratamento anterior documentado, adequado para a classificação clínica da sífilis, com queda prévia da titulação em pelo menos duas diluições e descartada possibilidade de reinfecção no período analisado. A presença de cicatriz sorológica não caracteriza falha terapêutica.  
###### _TÍTULO x DILUIÇÃO_  
_Quando os títulos da amostra diminuem em duas diluições (ex.: de 1:64 para 1:16), isso significa que o título da amostra caiu quatro vezes. Isso porque a amostra é diluída em um fator 2; logo, uma diluição equivale a dois títulos._  
_Para realizar um teste não treponêmico, são feitas várias diluições da amostra. A última diluição que ainda apresenta reatividade permite determinar o título (ex.: amostra reagente até a diluição 1:16 corresponde ao título 16)._  
_No Brasil, a maioria dos laboratórios libera o resultado na forma de diluição._  
Após o parto, o seguimento é trimestral até o 12º mês de acompanhamento (3, 6, 9, 12 meses);  
###### **Critérios de retratamento de sífilis: reativação ou reinfecção**  
##### #%¥ Conitec  
Muitas vezes, é difícil distinguir entre reinfecção, reativação e cicatriz sorológica, sendo fundamental a avaliação da presença de sinais e sintomas clínicos novos, da epidemiologia (reexposição), do histórico de tratamento (duração, adesão e medicação utilizada) e dos exames laboratoriais prévios, para facilitar a elucidação diagnóstica.  
São critérios de retratamento e necessitam de conduta ativa do profissional de saúde:  
- ausência de redução da titulação em duas diluições no intervalo de seis meses (sífilis recente, primária e secundária) ou 12 meses (sífilis tardia) após o tratamento adequado (ex.: de 1:32 para >1:8; ou de 1:128 para >1:32);  
OU  
- aumento da titulação em duas diluições ou mais (ex.: de 1:16 para 1:64; ou de 1:4 para 1:16);  
OU  
- persistência ou recorrência de sinais e sintomas clínicos.  
O esquema de retratamento, se para sífilis recente ou tardia, irá depender de cada caso. A investigação de neurossífilis por meio de punção lombar está indicada na população geral, quando não houver exposição sexual no período que justifique uma reinfecção.  
Para mais informações sobre neurossífilis, consultar o Protocolo Clínico e Diretrizes Terapêuticas para atenção integral às pessoas com Infecções Sexualmente Transmissíveis, disponível em <u>http://www.aids.gov.br/pcdt.</u>  
_O monitoramento mensal das gestantes não tem o intuito de avaliar queda da titulação,  mas principalmente descartar aumento da titulação em duas diluições, o que configuraria reinfecção/reativação e necessidade de retratamento da pessoa e das parcerias sexuais._  
###### **4.9. Sífilis: parcerias sexuais**  
Um terço das parcerias sexuais de pessoas com sífilis recente desenvolverão sífilis dentro de 30 dias da exposição. Portanto, além da avaliação clínica e do seguimento laboratorial, se houve exposição à pessoa com sífilis (até 90 dias), recomenda-se oferta de tratamento presuntivo a esses parceiros sexuais (independentemente do estágio clínico ou sinais e sintomas), com dose única de benzilpenicilina benzatina 2,4 milhões, UI, IM (1,2 milhão de UI em cada glúteo).  
#%¥ Conitec  
Todas as parcerias devem ser testadas. Quando o teste de sífilis for reagente, recomenda-se tratamento de sífilis adquirida no adulto, de acordo com o estágio clínico.  
A avaliação e tratamento das parcerias sexuais é crucial para interromper a cadeia de transmissão da infecção.  
###### **4.10. Algoritmo de decisão clínica para manejo da sífilis adquirida e sífilis em gestantes**  
Dividido em seis lâminas, trata-se de uma ferramenta de apoio à decisão clínica que sintetiza as recomendações para sífilis adquirida e sífilis em gestantes. Com o uso desse algoritmo pelos profissionais de saúde, de medicina ou de enfermagem, será possível testar, diagnosticar, tratar, notificar e monitorar os casos de sífilis adquirida e em gestantes.  
As cinco primeiras lâminas abordam a investigação para o diagnóstico de sífilis. São lâminas que procuram contemplar a diversidade de realidades do Brasil. O número de lâminas utilizadas para o diagnóstico dependerá da estrutura do serviço em que o profissional de saúde trabalha (disponibilidade de teste rápido, rede laboratorial mais estruturada ou menos estruturada).  
A **lâmina 1** aborda quem, quando e como testar para sífilis. Reforça-se, aqui, a importância da implantação e utilização do teste rápido para sífilis (teste treponêmico de alta sensibilidade e especificidade, realizado no local) já no primeiro atendimento, de forma oportuna e sem necessidade de encaminhamento ou agendamento.  
A **lâmina 2** orienta a interpretação e conduta frente aos testes treponêmicos ou não treponêmicos não reagentes. Já as **lâminas 3 e 4** trazem a interpretação e conduta após teste rápido treponêmico (lâmina 3) e não treponêmico reagente (lâmina 4). Na lâmina 3 (teste rápido reagente), o próximo passo indicado é “Solicitar diagnóstico de sífilis após TR reagente”. Dessa forma, o laboratório não iniciará o fluxograma de diagnóstico por um teste treponêmico (já realizado pelo serviço) e realizará diretamente um teste não treponêmico (os mais disponíveis no Brasil são o VDRL e RPR).  
A **lâmina 4** indica a conduta diante de um teste não treponêmico reagente isolado. Assim, o fluxograma de diagnóstico deverá ser continuado com a realização de um teste rápido treponêmico. O conjunto de resultados dos dois testes, associados à apresentação clínica e histórico epidemiológico, definirão a  
##### #%¥ Conitec  
conduta clínica.  
A **lâmina 5** traz a alternativa, na indisponibilidade do teste rápido, de solicitação de diagnóstico de sífilis à rede laboratorial (fluxo laboratorial). Nesse caso, o laboratório já realizará o fluxograma completo (teste treponêmico e não treponêmico, quando for o caso). Dessa maneira, evita-se que o paciente necessite retornar ao laboratório para ser novamente testado após o primeiro teste para sífilis reagente, já que o laboratório realizará o segundo ou o terceiro teste com a mesma amostra.  
A **lâmina 6** contém as condutas de tratamento e monitoramento de sífilis. Estão na mesma lâmina para reforçar que tão importante quanto tratar é garantir a segurança do paciente e de suas parcerias sexuais por meio do monitoramento adequado. Os testes recomendados para o monitoramento são os não treponêmicos. Para o monitoramento, a pessoa deverá realizar preferencialmente o mesmo tipo de teste, no mesmo laboratório, de maneira a minimizar diferenças de interpretação do resultado laboratorial.  
No enfrentamento da epidemia de sífilis, necessita-se uma alta suspeição clínica, com testagem de pacientes assintomáticos e tratamento e monitoramento de todos os casos e de suas parcerias sexuais. Nunca se está diante de apenas um caso de sífilis – sempre são pelo menos duas pessoas infectadas. Muitas vezes se trata de toda uma rede sexual infectada. Conversar com o paciente sobre sua prática sexual e suas parcerias sexuais é realizar uma boa assistência à saúde.  
Para o combate à sífilis congênita, o tratamento da gestante com benzilpenicilina benzatina após um teste reagente é fundamental. Cada semana que uma gestante com sífilis passa sem tratamento é mais tempo de exposição e risco de infecção para o concepto. A benzilpenicilina benzatina é segura e a melhor opção para o tratamento da mãe e da criança. Garantir o tratamento adequado da gestante, além de registrá-lo na caderneta de pré-natal, é impedir que o recém-nascido passe por intervenções biomédicas desnecessárias que podem colocá-lo em risco, além de comprometer a relação mãe-bebê.  
<!-- Start of picture text -->
O OTIS - = ll ff is ea —<br>e a7 ~ _ Z - Sa cal (peo -<br>Zé e - > ee — Cae alee ~L-<br>ore Conitec nn ho ae | See<br>oe Fo - Le ~<br><!-- End of picture text -->  
###### **Figura 10 – Algoritmo para manejo da sífilis adquirida e sífilis em gestantes**  
<!-- Start of picture text -->
Lamina 1—- Quem, quando e como testar para sifilis<br>Testar para sifilis em uma ou mais das seguintes situacdes:<br>* Sempre: ee . , 7 5 anal,<br>~ Pessoa com episddio de exposicdo sexual sem uso de preservativo (avaliar também outras IST, hepatites virais, HIV e PEP)<br>- Pessoa em situacao de violéncia sexual (avaliar também outras IST, hepatites virais, HIV e PEPS<br>- Pessoa com diagnostico de outras IST _<br>~- Gestante Pessoa comna parcerias)sexuallis)primeira consulta de compré-natal, diagndsticono inicio de do siflsterceiro trimestre (28° semana) e no momento do parto (ou em caso de aborto/natimorto).|<br>- Puérpera sem registro de teste para sffilis no pré-natal<br>-Mulher com diagnéstico de abortamento espontaneo/natimorto<br>~ Pessoa com sinais clinicos de sffilis:<br>*=*Sinais UlceradeLinfadenopatia cabelo,deanogenitalsffilisespecialmente generalizada/localizadasecundaria:sem causaem erupcdoaparenteclareiras), cutaneasemsintomas (principalmentecausageraisdeterminada(mal-estar,; em palmasfebre, dascefaleia, mos.  eastenia) plantas dos pés),eolesdes orais, lesdes vegetantes (em especial-  nos genitais),_ alopecia; (perda<br>~ Demais situacées em que a avaliacdo clinica demonstrar necessario<br>*Anualmente:- Adolescente/jovem_ <30 anos, com vida; sexual ativa;<br>*Acada= Gay, ~ PessoaHSH, 6 vivendo meses:  trabalhadoycom H (a) do sexo, travesti/transexual,.  pessoa que usa élcool/outras.  drogas ou pessoa privada|  de liberdade;<br>* Acada 3 meses: .. dee ee<br>~ Pessoa em uso de PrEP e ultimo teste para sifilis hd mais de 3 meses<br>rs<br>Escolher qual teste realizar<br>I<br>Osservico de satide tem teste rapido para sffilis disponivel?<br>sim no<br>Realizar teste rapido Solicitar “Diagnéstico de sifilis” ao laboratério®<br>Se o teste répido for nao reagente, ver lamina 2; sé o teste rapido for reagente, ver lamina 3 Ver lamina 5<br>+ Articularamostras junto de sangu ao s e rvico e &total colhidas coordenacopor puncdolocaldigital a implemou v en osa.tagaoTém do teste ra vant a pido.gem de Os serem testesrealrap i zadosdos so no praticos momento e deda facilconsulta, execuglo,possibilitando com leituratratamento do resultadoimediato. em, no maximo, 30 minutos. Podem ser realizados com<br>20 laboratério realizar a investigacdo para diagnéstico de acordo com sua disponibilidade de testes imunoldgicos.<br><!-- End of picture text -->  
<!-- Start of picture text -->
egcgeo - = Pa , ee [=<br>iL Conitec a ae [ |<br>otste eee ea Se<br>~ > ae = ~<br><!-- End of picture text -->  
<!-- Start of picture text -->
Lamina 2 — Investigagdo para diagnostico de sifilis<br>Teste rdpido (ou outro teste treponémico) ou VDRL/RPR (ou outro teste nao treponémico) nao reagente<br>O paciente tem ulcera anogenital?<br>Nao Sim<br>O paciente teve parceria sexual (nos Ultimos 3 meses) com diagnéstico de sifilis e nao foi tratado? Sifilisa recente<br>Nao i *+ Tratar’ Realizarparatestesifilispara recentesifilis' apds(ver 30 lamina dias. 6).<br>‘Teste negativo para sifilis Sifilis recente * AvalareParcerias tratar sexuaispara(ultimos sills recente3 meses), as<br>* Adolescente/jovem <30 anos com vida sexualmente ativa: testar para * Tratar’ para sifilis recente (ver lamina 6).<br>sifilis anualmente. ; * Realizar teste para sifilis' apds 30 dias.<br>* Gay, HSH, trabalhador(a) do sexo,travesti/transexual, pessoa que usa<br>Alcool/outras drogas ou pessoa privada de liberdade testar para sifilis<br>a cada 6 meses. -<br>* Pessoa vivendo com HIV: testar para sifilis a cada 6 meses.<br>* Pessoa em uso de PrEP: testar para sifilis a cada 3 meses. .<br>* Gestante: repetir o teste no terceiro trimestre (28? semana), se ja nao<br>tiver sido realizado, e no momento do parto (ou em caso de<br>aborto/natimorto).<br>4Na indisponibilidade do teste répido, deve-se solicitar “Diagnéstico de sifilis” a0 laboratério.<br><!-- End of picture text -->  
<!-- Start of picture text -->
eprge - - > Pa wax 2S asd<br>L& Conitec ann J Me<br>=e Fo - a ~<br>. pe = : ae<br><!-- End of picture text -->  
<!-- Start of picture text -->
Lamina 3 — Investigacdo para diagnostico de sifilis apds teste rapido reagente<br>Teste rapido reagente<br>Solicitar “Diagnéstico de sifilis apés TR reagente”"<br>* Seadequado o pacientepara apresensifilis: t aratar®Ulcerapara anogenitalsifilis recente ‘ou sinais/sintomas(veja lamina 6)dee sifilisnotificar. secundaria, ou teve parceria sexual com diagnéstico de sifilis, ou é gestante sem registro de tratamento prévio<br>VDRL/RPR reagente VDRU/RPR nao reagente<br>Teste treponémico (metodologia # do primeiro)<br>Reagente ou teste ndo disponivel N&o reagente<br>a, Paciente tem historia e/ou registro de tratamento prévio para sifilis?<br>Nao eePaciente tem VDRL/RPR apés tratamentosim  prévio, para comparacdo? Provavelprimeirarapido)falso-reagentetr e alizset a dosteno<br>I i * Se o paciente apresenta<br>Ngo sim ulcera anogenital ou teve<br>VDRL/RPR —— ———— parceria sexual (nos ultimos 3<br>0 ultimopara VORL/RPRsifilis?atual t( e x.:mreal zado tVDRL/RPR i tulagsoa p éseloatual tratamento menos1:16 2e diluigéesanteriorprévio adequado maior1:4)  que| | meses)stills:  ‘com di a gnostico de<br>~ '<br>sim - Tratar para sifilis recente_<br>Nao {verratado. lamina 6), se ainda ndo<br>Paciente apresenta Ulcera anogenitalou | | _ reali spido?<br>sinais/sintomas de sifilis secundaria?? Regilzat tests rapido? para<br>sin Nio<br>Paciente apresenta dlcera anogenital ou sinais/sintomas de sifilis secundaria?<br>Nao sim<br>Sifilistardia Sifilis recente - Cicatriz sorolégica<br>* Tratar sifilis tardia (ver lamina 6) e notificar. * Tratar para sifilis recente (ver lamina 6), se aindando | * Ver lamina 1.<br>* Avaliare tratar para sifilis recente as parcerias sexuais tratado, e notificar.<br>(ultimos 3 meses). * Avaliar e tratar para sifilis recente as parcerias sexuais<br>(ultimos 3 meses).<br>* Se o paciente for HIV positivo, realizar exame neurolégico. Em caso de sinais/sintomas oculares/neurolégicos, encaminhar, solicitar pungao lombar e investigar neurossifilis.<br><!-- End of picture text -->  
‘2 Nessa solicitacao, o laboratério ira realizar um teste nao treponémico. Os mais disponiveis no Brasil so 0 VDRLe 0 RPR. lesdesOs sinais/sintomasvegetantes (em deespecialsifilis secundarianos genitais), ocorremalopecia entre(perda 6 semanasde cabelo, a 6 mesesespecialmente apésa cicatrizacaoem clareiras),da Ulcerasintomasprimériagerais e incluem(mal-estar, erupeiofebre, cutdneacefaleia, (principalmenteastenia). em palmas das méos e plantas dos pés), lesdes orais, 3'Na indisponibilidade do teste rapido, deve-se solicitar “Diagnéstico de Sifilis” ao laboratério.  
<!-- Start of picture text -->
eprge -<br>iL Conitec<br><!-- End of picture text -->  
<!-- Start of picture text -->
- - : Pa wax 2S asd<br>Conitec nn [ a<br>=e Fo - a ~<br>. ae = : ae<br>Lamina 4 — Investigacao para diagnostico de sifilis iniciado com teste nao treponémico<br>[_VORL/RPRVDRL/RPR (ou(ou outrooutro testeteste naondo  treponémico)treponémico) reagentereagente |<br>* ; , _ _ Realizar teste rapido* ‘ , 4 ‘<br>adequadoSe o pacientepara apresensifilis: t ara t ilceraar para anogenitalsifilis recente ou sinais/sintomas(ver lamina 6) dee not sif i lisficar. secundaria2, ou teve parceria sexual com diagnéstico de sifilis, ou é gestante sem registro de tratamento prévio<br>Teste rapido reagente Teste rapido nao reagente<br>Solicitar outro teste treponémico (metodologia # do teste rapido)<br>I I<br>Reagente ou teste nao disponivel Nao reagente<br>Paciente tem historia e/ou registro de tratamento prévio para sifilis? Provavel falso-reagente no<br>teste nao treponémico<br>Nao Sim * Investigar. outras causas<br>Paciente tem VDRL/RPR prévio apds tratamento adequado, para comparacao? * Seo paciente apresenta<br>lcera anogenital ou teve<br>Nao Sim parceria sexual com<br>r Giagndstico de sfils (nos<br>©VDRL/RPRUltimo VDRL/RPRatual temrealizado tiulagso= apos pelo tratamento menos 2 diluigdes prévioae  adequado maior—  que -tiltimos Tratar’Iti  3 para meses}:sifilis:  recente<br>para sifilis? (ex.: VDRL/RPR atual 1:16 e anterior 1:4) (ver lamina 6), se ainda<br>Sim Naoz nao tratado.<br>- Realizar teste rapido! para<br>Paciente apresenta Ulcera anogenital ou sifilis apos 30 dias.<br>sinais/sintomas de sffilis secundaria??<br>Paciente apresenta dicera anogenital ou sinais/sintomas de sffilis secundaria”? [Nio|<br>Nao fo Sim \Giegtriz sorolégica<br>** Tratar’ Avaliar e para tratarsffilispara tardiaSifilissffilis tardia (verrecente lamina as parcerias6) e notificar. ». Rotificar. Tage para sifilis recente‘fl Sfflispecente(veree lamina 6), se.  aindaa, nao tratado,‘lt  e *Ver lamina 1.<br>sexuais (ultimos 3 meses). Avallat € tratar para sifilis recente as parcerias sexuais (Uiltimos 3<br>* Se o paciente for HIV positivo, realizar exame neuroldgico:<br>= Em caso de sinais/sintomas oculares/neuroldgicos: encaminhar, solicitar pungao lombar e investigar neurossifilis.<br>208Navegetantes sinaig/sintomasindisponibilidade em especial desifilisdo testenos secundaria genitais,rapido, deve-sealopecia ocorrem (perdarealizar entre 6dea solicitacdo semanas cabelo) especialmente a 6 “Diagnéstico meses apes de em a cigatrizacdo Sifilis”clareiras, a0.laboratério. sintomasja ulcera gerais priméria (mal-estar,.  e incluerpfebre,erupgsecefaleia, cuténea astenia). (principalmente7  se em palmas das méos e plantas dos pés), lesdes orais, lesdes<br>3 vels conduta para tratamento na lamina 6.<br><!-- End of picture text -->  
<!-- Start of picture text -->
Lamina 5 — Investiga¢ao para diagnéstico de sifilis iniciado com Fluxo Laboratorial'<br>Teste treponémico laboratorial (FTA-Abs, ELISA/EQL/CMIA, TPHA/TPPA/MHA-TP) reagente<br>VDRL/RPR reagente VDRL/RPR nao reagente<br>Teste treponémico (metodologia # do primeiro<br>Reagente ou teste ndo disponivel<br>Paciente tem historia e/ou registro de tratamento prévio para sifilis Provavel falso-reagente no<br>primeiro teste treponémico<br>Li realizado<br>Paciente tem VDRL/RPR apés tratamento prévio, para comparacao? * FeoBemnepenitlouteve<br>. 1 parceria sexual (nos ultimos 3<br>Nao sim meses)sifilis:  com diagnéstico de<br>©VDRL/RPRultimo VDRL/RPRatual tem realizadotitulac3o apdspelo tratamentomenos 2 dilui¢desprévio adequadomaior que | - Tratar para sifilis recente_<br>para sifilis? (ex.: VDRL/RPR atual 1:16 e anterior 1:4) (verratado. emina 6), se ainda nado<br>sim LCN : spi<br>Paciente apresenta Ulcera anogenital ou - sifilisRealizar apsteste30 rapido”dias.  para<br>sinais/sintomas de sifilis secundaria®?<br>Paciente tem ulcera anogenital ou sinais/sintomas de sffilis secundaria??<br>Nao ih sim Nao<br>* Tratar sffilis tardia (verSifilis lamina tardia6) € notificar. * Tratar para sifilis recenteSifilis (verrecente lamina 6), se ainda nao everCicatriz Satzsorolégicasorolée<br>* Avaliar e tratar para sifilis recente as parcerias sexuais tratado, e notificar.<br>(ultimos 3 meses). * Avaliar e tratar para sifilis recente as parcerias sexuais<br>(ultimos 3 meses).<br>* Se o paciente for HIV positivo, realizar exame neuroldgico:<br>- Em caso de sinais/sintomas oculares/neurolégicos: encaminhar, solicitar pungo lombar e investigar neurossifilis.<br>10 laboratério realizar a investigaco para diagnéstico de acordo com sua disponibilidade de testes imunoldgicos.<br>2 Na indisponibilidade do teste rapido, deve-se solicitar “Diagndstico de Sifiis” ao laboratério. a ; ;<br>VOfEUMHSLSOt DSS AE.FOS SEAMBA 2 6RCIS ToS PAS dR ESBAGS Spe ARREARS Sin CaN Stones BEAR inalcealar TabreL ESPNS AREA BIi cPaImente em Palmas das maos e plantas dos pés), lesbes oral, lesbes<br><!-- End of picture text -->  
ore  
###### otste  
<!-- Start of picture text -->
Lamina 6 — Tratamento e monitoramento de sifilis<br>Sifilis recente (primaria, secundaria e latente recente) Sifilis tardia (terciaria, latente tardia ou latente com duracao ignorada)<br>* Aplicar, na mesma consulta, dose Unica de benzilpenicilina benzatina 2,4MUI IM. Se * Aplicar, na mesma consulta, primeira dose de benzilpenicilina 2,4MUI IM e repetir<br>estivhouv er  Contraindicagaoamamentando, prescrevera benzilpenicilinadoxiciclinabenzatina100mg S12/12h, paciente por nao15 fordias. gestante/ pacientesemanalmente nao for por gestante/estiver mais 2 semanas.amamentando, Se houver contp r escreveraindicacao' doxiciclinaa benzilpenicilina100mg 12/12he<br>+ Segem paciente anafllaxia for apos gestante/estiver uso de penicilina, amamentandoe aplicar dose tier unica historia de peniclinade reacbenzatina leve/moderada2,4MUIIM. |_| porSe paciente 30 dias. for gestante/estiver amamentando e tiver historia de reacdo leve/moderada<br>*Seapospacienteuso de forpenicilina, gestante/estiverencaminhar/discutir amamentandoe tive historia de reacao‘grave/anatilaxia sem anafilaxia apos uso de penicilina, aplicar primeira dose de benzilpenicilina 2,4MUI IM<br>com especialista. e repetir Semanalmente por mals 2 semanas. . . .<br>*Seaps paciemtauso de forpenicilina, gestante/estiverencaminhar/discutir amamentandocom e tiverespecialista. historia de reacdo grave/anafilaxia<br>.* Eebre,Tratarmg dondeparceria(s) 6/6h, secabeca, sor necessario.(dos Ultimos muscular3 meses) e rashpara podemsifilisle  ocorrerrecente apés(independentemente.  tratamento e melhoramde sintomas/resultado.  em 1-2 dias, espontaneamente dos testes) e testar (Reacaopara desifilis_ Jarish-Herxheimer).na mesma semana.PrescreverInterpretar paracetamolresultados oupara dipirona<br>decidir continuar tratamento para sifilis tardia. ; : : ;<br>+A regra é de que o intervalo entre as doses seja de 7 dias para completar o tratamento. No entanto, caso esse intervalo ultrapasse 14 dias, o esquema devera ser reiniciado.<br>* Segestantenatal.  e em tratamento completo para 0 estagio clinico da sifils com penicilina benzatina e INICIADO ate 30 dias antes do parto: registrar tratamento adequado na carteira de pré-<br>+ Em caso de sinais e sintomas neuroldégicos/oftalmoldgicos ou sifilis tercidria ativa: solicitar pun¢do lombar e investigar neurossifilis*.<br>Solicitar ao laboratério “Monitoramento do tratamento de sifilis”? comrepetir 3, 6,até9 ecompletar 12 meses. Em1 ano caso(3, de6, 9 gestante,e 12 meses). repetir mensalmente (registrar na carteira de pré-natal) e, apds 0 parto,<br>Monitoramento de sifilis<br>Comparar novo VORL/RPR com VDRL/RPR prévio |<br>I<br>** VORL/RPR VDRL/RPR atualatual € é pelopelo menosmenos 22 diluicoesdiluicdes menores que menores que o o dodo diagnosticodiagndstico (ex.:{ex.: anterioranterior 1:32,1:32, atualatual 1:8),1:8), 126 meses meses apds apos tratamentotratamento paraparasifilissifilisrecente, tardia ou<br>Nao. in Paciente mantém/desenvolveutratamento incompletonova ulcerado paciente/parceria(s) anogenitalsimox1  ou sinais/sintomas ou houve  denovasifilisexposicao? secundaria*ou ocorreu ]<br>[ sim mn Nao ]<br>© ¥<br>*Se HIV positivo, retratar paciente e parceria(s) para sifilis recente, ou tardia (de acordo * Repetir VORL/RPR trimestralmente até completar 12 meses. Se n3o houver aumento de<br>* Secom HIV cada negativo,caso}, solicitarretratar puncao paciente lombar e parceria(s)e investigarpara  neurossifilis*.sifilis recente ou tardia (de acordo titulagdoassintomatico em pelo no periodo, menos 2 darGiluicoes alta. (ex.: anterior 1:4, atual;  21:16) e persistir;<br>comsolicit c a rdapungao caso). lombar Em caso e de tratameinvestigar n eurossifilis?.to comp leto e sem nova exposi¢ao, também * ST e petir gestante, VDRL/RPRrepistrar mensalmente. tratamentoApos adequadpart o , e queda manter da seguiment titulacd o  naaté carteira completar de pré-natal,12 meses.<br>parceria(s)Se houver qualquerpara sifilis VORL/RPRrecente oucomtardia pelo(de menos acordo 2 diluigdes com cada maiorcaso). queSe anterior tratamentoou persisténcia/novoscompleto e sem nova sinaisexposicao de sifilis:confirmadinvestig a r, reexposi¢go/tratametambém solicitar pu n ¢aoto incompleto lombar e investigar e retratarneurossifilis?. paciente e<br>23 SovarsincicartnEm caso de dlagndstico h beraipeictinahencatine:de neurossfil, encaminhar/dlscutirprananea da slconecom, especialista (prctage ou wiconepara internagdo leuldo ncusal hospitalare nos tratamento. locals recomend para aplcagso IM ca mecicaysoe slarie/snafiaxa ape wrod panklina<br>30s testes no treponémicos laboratoriais (VORL/RPR/USR/TRUST) sao 0s testes utilizados para o monitoramento do tratamento de sifilis. Orienta-se realizar a mesma metodologia durante todo o periodo de monitoramento.<br><!-- End of picture text -->  
###### Fonte: DCCI/SVS/MS.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
**4.11. Sífilis congênita e criança exposta à sífilis**  
A OMS estimou que, em 2012, a ocorrência de sífilis causou 350 mil desfechos gestacionais adversos, incluindo 143 mil mortes fetais e natimortos, 62 mil óbitos neonatais, 44 mil neonatos prematuros ou com baixo peso ao nascer, 102 mil crianças com sífilis congênita (20). No Brasil, nos últimos cinco anos, foi observado um aumento constante no número de casos de sífilis em gestantes, sífilis congênita e sífilis adquirida. Esse aumento pode ser atribuído, em parte, à elevação nos números de testagem, decorrente da disseminação dos testes rápidos, mas também à diminuição do uso de preservativos, à redução na administração da penicilina na Atenção Básica e ao desabastecimento mundial de penicilina, entre outros.  
A Sífilis Congênita (SC) é o resultado da transmissão da espiroqueta do _Treponema pallidum_ da corrente sanguínea da gestante infectada para o concepto por via transplacentária ou, ocasionalmente, por contato direto com a lesão no momento do parto (transmissão vertical). A maioria dos casos acontece porque a mãe não foi testada para sífilis durante o pré-natal ou porque recebeu tratamento não adequado para sífilis antes ou durante a gestação (21–26).  
A transmissão vertical é passível de ocorrer em qualquer fase gestacional ou estágio da doença materna e pode resultar em aborto, natimorto, prematuridade ou um amplo espectro de manifestações clínicas; apenas os casos muito graves são clinicamente aparentes ao nascimento.  
Estima-se que, na ausência de tratamento eficaz, 11% das gestações resultarão em morte fetal a termo e 13%, em partos prematuros ou baixo peso ao nascer, além de pelo menos 20% de recém-nascidos (RN) que apresentarão sinais sugestivos de SC (27,28).  
Portanto, trata-se de uma doença que pode ser prevenida, sendo possível alcançar a eliminação da SC por meio da implementação de estratégias efetivas de diagnóstico precoce e tratamento de sífilis nas gestantes e suas parcerias sexuais (20). Além disso, o risco de desfechos desfavoráveis à criança será mínimo se a gestante receber tratamento adequado e precoce durante a gestação.  
**A sífilis em gestantes e a SC são agravos de notificação compulsória** .  
###### **4.12. Avaliação inicial da criança exposta ou com sífilis congênita**  
A avaliação inicial da criança exposta à sífilis ou com sífilis congênita é realizada especialmente  
na maternidade/casa de parto, considerando os seguintes aspectos:  
- histórico materno de sífilis quanto ao tratamento e seguimento na gestação;  
- sinais e sintomas clínicos da criança (na maioria das vezes ausentes ou inespecíficos); e  
- teste não treponêmico de sangue periférico da criança comparado com o da mãe.  
Não existe uma avaliação complementar que determine com precisão o diagnóstico da infecção na criança. Assim, esse diagnóstico exige uma combinação de avaliação clínica, epidemiológica e laboratorial (29).  
_Tratamento adequado para sífilis durante a gestação: tratamento completo para estágio clínico de sífilis com benzilpenicilina benzatina, iniciado até 30 dias antes do parto._  
_Gestantes que não se enquadrarem nesses critérios serão consideradas como tratadas de forma não adequada._  
O tratamento das parcerias sexuais não entra nos critérios epidemiológicos de definição de casos de sífilis congênita (30). Entretanto, faz-se imprescindível esse tratamento, considerando a possibilidade de reinfecção.  
Todas as crianças nascidas de mães diagnosticadas com sífilis durante o pré-natal necessitam de uma avaliação criteriosa no momento do parto, com anamnese, exame físico e teste não treponêmico. Essa avaliação do profissional de saúde pode acrescentar outros dados e gerar uma conclusão de tratamento inadequado para sífilis durante a gestação, mesmo se enquadrando inicialmente dentro dos critérios epidemiológicos de tratamento adequado.  
O histórico de tratamento e seguimento da sífilis na gestação devem estar documentados em prontuário médico ou na caderneta da gestante, não se recomenda considerar apenas a informação verbal.  
<!-- Start of picture text -->
3<br><!-- End of picture text -->  
_Para fins clínicos e assistenciais, alguns fatores são considerados para o tratamento adequado da GESTANTE com sífilis, como:_  
_> Administração de penicilina benzatina;_  
_> Início do tratamento até 30 dias antes do parto;_  
_> Esquema terapêutico de acordo com o estágio clínico;_  
_> Respeito ao intervalo recomendado de doses;_  
_> Avaliação quanto ao risco de reinfecção;_  
_> Documentação de queda do título do teste não treponêmico em pelo menos duas diluições em três meses, ou de quatro diluições em seis meses após a conclusão do tratamento (ex: antes, 1:16; depois, menor ou igual a 1:4) – resposta imunológica adequada._  
A resposta imunológica adequada durante a gestação pode não ser encontrada, uma vez que depende do momento em que o tratamento foi realizado e essa resposta é mais comum quando os títulos não treponêmicos são mais altos no início do tratamento e em estágios mais recentes da infecção (sífilis primaria, secundaria e latente recente).  
A resposta imunológica pode ser mais lenta, sem que se configure falha de tratamento, com redução da titulação em duas diluições no intervalo de seis meses (sífilis primária, secundária e sífilis latente recente) ou 12 meses (sífilis tardia) após tratamento adequado.  
Muitas vezes, é difícil diferenciar entre reinfecção, reativação, falha terapêutica e resposta imunológica mais lenta, sendo fundamental a avaliação da presença de sinais ou sintomas clínicos novos, reexposição de risco, violência sexual, comorbidades, histórico do tratamento (duração, adesão e medicação utilizada) e exames laboratoriais prévios, para facilitar a elucidação diagnóstica.  
Nessa perspectiva, a conduta de identificar adequadamente crianças expostas (mas não infectadas) é tão importante quanto detectar e tratar crianças com sífilis congênita, para não submeter as crianças expostas a condutas desnecessárias, como exames invasivos e internações prolongadas. _É essencial garantir o seguimento de todas as crianças expostas à sífilis, excluída ou confirmada a doença em uma avaliação inicial, na perspectiva de que elas podem desenvolver sinais e sintomas mais tardios, independentemente da primeira avaliação e/ ou tratamento na maternidade._ ~~<mark>Oo</mark>~~  
<!-- Start of picture text -->
% Conitec Cc a<br><!-- End of picture text -->  
Diante do exposto, todas as crianças expostas à sífilis ou com sífilis congênita deverão ser avaliadas ao nascimento. A Figura 11 sistematiza o fluxo de notificação a partir da classificação do RN ao nascimento, com base apenas no histórico materno.  
Figura 11 – Fluxo de notificação a partir da classificação do RN ao nascimento baseado apenas no histórico materno  
<!-- Start of picture text -->
Recém-nascido<br>RN de mulher diagnosticada<br>Não notificar; realizar<br>com sífilis durante pré-natal e<br>ADEQUADAMENTE  avaliação e manejo clínico<br>Recém-nascido   TRATADA*  conforme a  Figura 13<br>exposto à sífilis<br>Recém-  RN de mulher diagnosticada<br>nascido com  com sífilis no pré-natal, parto  Notificar; realizar avaliação<br>sífilis  ou puerpério, NÃO TRATADA  e manejo clínico conforme<br>congênita  ou TRATADA DE FORMA  a  Figura 13<br>NÃO ADEQUADA<br>a=<br>Fonte: DCCI/SVS/MS.<br><!-- End of picture text -->  
* **Tratamento adequado** : tratamento completo para o respectivo estágio clínico da sífilis, com benzilpenicilina benzatina, **iniciado** até 30 dias antes do parto. As gestantes que não se enquadrarem nesse critério serão consideradas como tratadas de forma não adequada.  
Nota: As crianças nascidas de mãe com cicatriz sorológica para sífilis antes da gestação **DEVEM** realizar teste não treponêmico na maternidade e, na ausência de sinais/sintomas, não necessitam de avaliação ou tratamento na maternidade.  
###### **4.13. Criança exposta à sífilis**  
O referenciamento da criança exposta no momento da alta compete à maternidade ou casa de parto. Toda criança exposta será necessariamente encaminhada para a Atenção Primária à Saúde (APS) de sua área de residência. A APS é o nível de atenção à saúde responsável pela puericultura e coordenação de cuidado dos usuários do SUS; e preferencialmente encontra-se estruturado pela Estratégia de Saúde da Família (ESF). No entanto, a criança exposta também pode ser acompanhada de forma complementar em um serviço de referência existente no território.  
###### **4.13.1. Exame físico da criança exposta à sífilis**  
Na criança exposta à sífilis, para exclusão da possibilidade de sífilis congênita, o exame físico deve ser completamente normal; o achado de qualquer sinal ou sintoma deve levar à investigação complementar, e a sífilis congênita será incluída no diagnóstico diferencial. Vale  
<!-- Start of picture text -->
X¥ Conitec Sy Les<br><!-- End of picture text -->  
lembrar que os sinais e sintomas de sífilis são inespecíficos e podem ser encontrados em outras síndromes congênitas, como toxoplasmose, rubéola, citomegalovírus (CMV), herpes vírus simplex (HSV), sepse neonatal, hepatite neonatal, hidropisia fetal, entre outros.  
Deve haver atenção específica aos sinais e sintomas mais clássicos, referentes às manifestações precoces de sífilis congênita.  
A presença de sinais e sintomas incluem a criança na classificação de SC sintomática, com necessidade de notificação compulsória e tratamento imediato.  
Além do exame físico, toda criança exposta à sífilis deve ser submetida a análise de exame laboratorial não treponêmico para exclusão da possibilidade de sífilis congênita.  
###### **4.13.2. Testagem para sífilis na criança exposta à sífilis**  
Todos os RNs nascidos de mãe com diagnóstico de sífilis durante a gestação, independentemente do histórico de tratamento materno, deverão realizar **teste não treponêmico no sangue periférico** . O sangue de cordão umbilical não deve ser utilizado, pois esse tipo de amostra contém uma mistura do sangue da criança com o materno e pode resultar em testes falso-reagentes.  
_A testagem simultânea da mãe e da criança, no pós-parto imediato, com o mesmo tipo de teste não treponêmico, configura o melhor cenário para a determinação do significado dos achados sorológicos da criança._  
No teste não treponêmico, um **título maior que o materno em pelo menos duas diluições** (ex.: materno 1:4, RN maior ou igual a 1:16) é indicativo de infecção congênita. No entanto, a **ausência desse achado não exclui a possibilidade do diagnóstico de SC.**  
Ressalta-se que o título do teste não treponêmico do recém-nascido igual ou inferior ao materno não exclui completamente a sífilis congênita, mesmo nas mães adequadamente tratadas. A decisão de investigar e tratar a criança não deve ser baseada apenas na definição de caso de notificação de sífilis congênita, mas também na avaliação clínica, epidemiológica e laboratorial da infecção.  
<!-- Start of picture text -->
X¥ Conitec — 4= S<br><!-- End of picture text -->  
Alguns estudos demonstraram que menos de 30% das crianças com sífilis congênita têm resultado pareado do teste não treponêmico maior que o materno (31,32); portanto, é fundamental a realização do seguimento de todas as crianças.  
Não há correlação entre a titulação dos testes treponêmicos do RN e da mãe que possa sugerir SC. Dessa forma, não se recomenda a realização do teste treponêmico no bebê até os 18 meses (33).  
O Quadro 26 apresenta os testes para a criança exposta à sífilis que devem ser realizados na maternidade ou casa de parto e no seguimento clínico e laboratorial.  
Quadro 26 – Testes de sífilis para criança exposta à sífilis  
|**TESTES DE**<br>**SÍFILIS**|**NA MATERNIDADE**<br>**OU CASA DE PARTO**|**NO SEGUIMENTO**|**O QUE AVALIAR**|
|---|---|---|---|
|**Teste não**<br>**treponêmico**|Coletar amostra de<br>sangue periférico do<br>RN<br>e<br>da<br>mãe<br>pareados<br>para<br>comparação.<br>Não realizar coleta de<br>cordão umbilical.|Realizar com 1, 3, 6,<br>12 e 18 meses de<br>idade.<br>Interromper<br>o<br>seguimento<br>laboratorial após dois<br>testes**não reagentes**<br>consecutivos.|Não reagente ou reagente com titulação<br>menor, igual ou até uma diluição maior<br>que o materno (ex.: 1:4 e materno 1:2):<br>baixo risco de SC.<br>Reagente com titulação superior à<br>materna em pelo menos duas diluições:<br>sífilis congênita. Tratar conforme a<br>Figura 13 e realizar notificação imediata<br>do caso de sífilis congênita.<br>Espera-se<br>que<br>os<br>testes<br>não<br>treponêmicos declinem aos 3 meses de<br>idade, devendo ser**não reagentes**aos 6<br>meses nos casos em que a criança não<br>tiver sido infectada e seja apenas<br>passagem passiva de anticorpo materno.<br>Se no seguimento ocorrer elevação de<br>títulos em duas diluições em teste não<br>treponêmico ou persistência da titulação<br>aos 6 meses de idade, a criança deverá<br>ser investigada, submetida à coleta de<br>líquor (LCR), tratada para sífilis congênita<br>com<br>benzilpenicilina<br>potássica<br>(cristalina) por 10 dias e notificada a<br>vigilância epidemiológica.<br>Idealmente, o exame deve ser feito pelo<br>mesmo<br>método<br>e<br>no<br>mesmo<br>laboratório.|
|**Teste**<br>**treponêmico**|Não realizar|**NÃO é obrigatório.**|Um teste treponêmico reagente após os<br>18 meses idade (quando desaparecem<br>os anticorpos maternos transferidos|  
<!-- Start of picture text -->
X¥ Conitec a ae ee<br><!-- End of picture text -->  
|Pode ser realizado a<br>partir dos 18 meses|passivamente no período intrauterino)<br>confirma<br>o<br>diagnóstico<br>de<br>sífilis|
|---|---|
|de idade.|congênita. Um resultado não reagente<br>não exclui sífilis congênita nos casos em<br>que a criança foi tratada precocemente.<br>Crianças<br>com<br>teste<br>treponêmico<br>reagente após 18 meses de idade e que<br>não tenham histórico de tratamento<br>prévio deverão passar por uma avaliação<br>completa, receber tratamento e ser<br>notificadas<br>como<br>caso<br>de<br>sífilis<br>congênita.|  
Fonte: adaptado de Workowski; Bolan, 2015; Hardy et al., 1970; Rawstron et al., 2001; Chang et al., 1995; Lago et al., 2013.  
Existem testes treponêmicos capazes de detectar anticorpos do tipo IgM contra o _T_ . _pallidum_ no sangue do RN, que são anticorpos que não atravessam a barreira placentária e, portanto, quando presentes na amostra da criança, indicam resposta do sistema imune frente à sífilis, e a não transferência de anticorpos maternos. Porém, esses anticorpos IgM não são detectados em todos os casos de sífilis congênita e, dessa forma, um resultado negativo não exclui o diagnóstico de sífilis no RN. Por isso, não se recomenda a utilização de testes que detectam IgM, como, por exemplo, teste de absorção do anticorpo treponêmico fluorescente ( _Fluorescent Treponemal Antibody-Absorption -_ FTA-Abs) IgM e imunoensaios IgM para o diagnóstico da sífilis congênita (3,34).  
###### **4.13.3. Seguimento clínico-laboratorial da criança exposta à sífilis**  
É esperado que os testes não treponêmicos das crianças declinem aos três meses de idade, devendo ser **não reagentes aos seis meses** nos casos em que a criança não tiver sido infectada ou que tenha sido adequadamente tratada. A resposta pode ser mais lenta em crianças tratadas após um mês de idade. Idealmente, o exame deve ser feito pelo mesmo método e no mesmo laboratório.  
A falha no tratamento em prevenir a ocorrência de SC é indicada por:  
>  Persistência da titulação reagente do teste não treponêmico aos seis meses de idade; E/OU  
<!-- Start of picture text -->
% Conitec Sy te<br><!-- End of picture text -->  
 aumento nos títulos não treponêmicos em duas diluições ao longo do seguimento (ex.: 1:2 ao nascimento e 1:8 após). ~~Pe~~  
Nesses dois casos, as crianças serão notificadas para sífilis congênita e submetidas à punção lombar para estudo do LCR com análise do VDRL, contagem celular e proteína, devendo ser tratadas durante dez dias com penicilina parenteral (a escolha do tratamento dependerá da presença ou não de neurossífilis), mesmo quando houver histórico de tratamento prévio.  
O seguimento de crianças expostas à sífilis pode ser feito na Atenção Básica (35), com atenção mais cuidadosa no monitoramento de sinais e sintomas sugestivos de sífilis congênita, além do monitoramento laboratorial com teste não treponêmico em 1, 3, 6, 12 e 18 meses de idade. A partir dessa idade, se não houver achados clínicos e laboratoriais, exclui-se sífilis congênita.  
A garantia do seguimento clínico e coleta de teste não treponêmico no 1<sup>o</sup> mês de vida é particularmente importante. O referenciamento da maternidade ou casa de parto deve levar em consideração, entre outras questões, a rede de serviços de saúde implantada no território e localidade de moradia da família, para melhor suprir a necessidade de seguimento da criança exposta à sífilis.  
O Quadro 27 sumariza as recomendações do seguimento clínico das crianças exposta à sífilis.  
Quadro 27 – Seguimento clínico da criança exposta à sífilis  
|**PROCEDIMENTO**|**FREQUÊNCIA E**<br>**DURAÇÃO**|**O QUE AVALIAR**|
|---|---|---|
|**Consultas**<br>**ambulatoriais de**<br>**puericultura**|Seguimento habitual na<br>rotina da puericultura,<br>conforme<br>recomendação da<br>Saúde da Criança: na 1ª<br>semana de vida e nos<br>meses 1, 2, 4, 6, 9, 12 e<br>18, com retorno para<br>checagem de exames<br>complementares, se for<br>o caso.|A criança exposta à sífilis, mesmo que não tenha sido<br>diagnosticada com sífilis congênita no momento no<br>nascimento, pode apresentar sinais e sintomas<br>compatíveis com a doença ao longo do seu<br>desenvolvimento. Dessa forma, deve ser realizada<br>busca ativa de sinais e sintomas a cada retorno (ver<br>Quadro 27, referente às manifestações precoces de<br>sífilis congênita). Especial atenção deve ser dada aos<br>sinais e sintomas clínicos, além de vigilância quanto ao<br>desenvolvimento neuropsicomotor.<br>Fazer a solicitação dos testes não treponêmicos, para<br>que os resultados estejam disponíveis na consulta de<br>retorno.<br>Aproveitar o momento da consulta para avaliar risco de<br>outras IST maternas. O diagnósticoprévio de uma IST é|  
fator de risco para outras, inclusive HIV, que pode ser transmitido pelo aleitamento materno. Indagar sobre práticas sexuais e oferecer testagem para a mãe da criança e suas parcerias sexuais, na rotina, enquanto a mulher estiver amamentando (testagem para HIV pelo menos a cada 6 meses). Oferecer teste rápido para hepatite B e vacina contra hepatite B, quando não houver histórico de vacinação.  
Fonte: (35)  
###### **4.14. Criança com sífilis congênita**  
A sífilis congênita precoce pode surgir até o segundo ano de vida. Já a sífilis congênita tardia é definida como aquela em que os sinais e sintomas surgem após os dois anos de idade da criança.  
A sífilis congênita precoce deve ser diagnosticada por meio de criteriosa avaliação clínica e epidemiológica da situação materna, associada à avaliação clínico-laboratorial e exames de imagem na criança.  
As crianças com sífilis congênita deverão ser investigadas ainda na maternidade quanto às **manifestações clínicas, exames complementares e resultado do teste não treponêmico** .  
Quando a mãe não foi tratada ou foi tratada de forma não adequada durante o pré-natal, as crianças são classificadas como caso de sífilis congênita, independentemente dos resultados da avaliação clínica ou de exames complementares.  
Independentemente do histórico de tratamento materno, as crianças com resultado de teste não treponêmico maior que o da mãe em pelo menos duas diluições (ex.: mãe 1:4 e RN ≥1:16) são consideradas caso de sífilis congênita, devendo ser notificadas, investigadas, tratadas e acompanhadas quanto a aspectos clínicos e laboratoriais.  
Todas as crianças com sífilis congênita devem ser submetidas a uma investigação completa, incluindo punção lombar para análise do líquor e radiografia de ossos longos.  
As crianças com manifestação clínica, alteração liquórica ou radiológica de sífilis congênita **E** teste não treponêmico reagente preenchem critério para sífilis congênita, independentemente do histórico materno quanto ao tratamento e das titulações dos testes não treponêmicos.  
<!-- Start of picture text -->
#¥ Conitec a beg<br><!-- End of picture text -->  
###### **4.14.1. Exame físico da criança com sífilis congênita**  
Nas crianças com sífilis congênita, aproximadamente 60% a 90% dos RN vivos são assintomáticos ao nascimento; apenas os casos mais graves nascem com sinais/sintomas. As manifestações clínicas das crianças com sífilis congênita raramente surgem após três a quatro meses; dois terços desenvolvem sintomas em três a oito semanas (36–38).  
A presença de sinais e sintomas ao nascimento depende do momento da infecção intrauterina  
e do tratamento durante a gestação (39). São sinais mais frequentes (8,36):  
- hepatomegalia;  
- esplenomegalia;  
- icterícia;  
- corrimento nasal (rinite sifilítica);  
- exantema maculopapular;  
- linfadenopatia generalizada;  
- anormalidades esqueléticas.  
As manifestações clínicas de sífilis **congênita precoce** são variadas. As principais características dessa síndrome estão descritas no Quadro 28.  
As crianças sintomáticas devem ser notificadas, tratadas e acompanhadas em relação a aspectos clínicos e laboratoriais, segundo observado nos Quadros 28 a 30.  
_Todas essas manifestações são inespecíficas e podem ser encontradas no contexto de outras infecções congênitas. É necessário investigar possíveis diagnósticos diferenciais._ ~~<u><mark>Po</mark></u>~~ Quadro 28 – Manifestações clínicas de sífilis congênita precoce **GESTACIONAIS/PERINATAIS** Pode ocorrer em qualquer momento da gestação. **Natimorto/aborto** Desfecho em aproximadamente 40% dos casos de sífilis adquirida durante a **espontâneo** gestação, com maior risco no primeiro trimestre de gestação. ~~a~~  
<u>— 4= S</u>  
|**Prematuridade**|–|
|---|---|
|**Baixo peso ao nascer**<br>**(<2.500g)**|–|
|**Hidropsia fetal não**<br>**imune**|–|
|**Placenta**|Placenta desproporcionalmente grande, grossa, pálida; vilite proliferativa<br>focal; arterite endo e perivascular; imaturidade difusa ou focal das vilosidades<br>placentares.<br>Encaminhar para análise anatomopatológica.|
|**Cordão umbilical**|Funisite necrotizante é rara, mas patognomônica quando presente. É<br>caracterizada pelo cordão umbilical edemaciado e inflamado, que pode<br>apresentar listras vermelhas e azuladas em alternância com áreas<br>esbranquiçadas. Pontos de abscesso na substância de Wharton, centradas ao<br>redor dos vasos umbilicais.<br>Encaminhar para análise anatomopatológica.|
||**SISTÊMICAS**|
|**Febre**|Pode ser mais significativa em crianças nascidas de mães infectadas<br>tardiamente na gestação.|
|**Hepatomegalia**|Ocorre em praticamente todos os casos de crianças com sífilis congênita<br>(26,40).<br>O achado ultrassonográfico de hepatomegalia pode indicar falha do<br>tratamento materno para prevenir a transmissão vertical (10).<br>Está associada a icterícia e colestase. Achados laboratoriais podem incluir<br>aumento de AST/ALT, FA, bilirrubina direta, alargamento do tempo de<br>protrombina e espiroquetas visíveis em biópsia hepática (quando realizada).<br>As alterações de provas hepáticas podem ser exacerbadas com a<br>administração da penicilina, antes da melhora. A melhora geralmente é lenta,<br>mesmo com terapêutica adequada (26).|
|**Esplenomegalia**|Ocorre em aproximadamente 50% dos pacientes com hepatomegalia (não<br>acontece isoladamente).|
|**Linfadenomegalia**<br>**generalizada**|O linfonodo pode ser de até 1 cm, geralmente não flutuante e firme.|
|**Atraso no**<br>**desenvolvimento**<br>**neuropsicomotor**|–|
|**Edema**|Causado por anemia/hidropsia fetal, síndrome nefrótica, desnutrição|
||**MUCOCUTÂNEAS**|
|**Rinite sifilítica ou**<br>**corrimento nasal**|Pode ser um sinal precoce, surgindo após a primeira semana de vida. Ocorre<br>em aproximadamente 40% dos casos.<br>A secreção contém espiroquetas e é infectante. Usar precaução de contato.|  
<u>is 5</u>  
||Geralmente aparece 1 a 2 semanas após a rinite.|
|---|---|
|**Exantema**<br>**maculopapular**|Apresenta-se como lesões ovais, inicialmente vermelhas ou rosadas,<br>evoluindo para coloração marrom acobreada; podem estar associadas à<br>descamação superficial, caracteristicamente nas regiões palmar e plantar.<br>São mais comuns na região glútea, nas costas, parte posterior das coxas e<br>plantas.<br>As lesões contêm espiroquetas e são infectantes. Usar precaução de contato.|
|**Exantema vesicular**<br>**(pênfigo sifilítico)**|Pode estar presente ao nascimento, desenvolvendo-se mais frequentemente<br>nas primeiras quatro semanas de vida; é amplamente disseminado.<br>O fluido vesicular contém espiroquetas e é infectante. Usar precaução de<br>contato.|
|**Condiloma lata**|Único ou múltiplo. Lesões planas, verrucosas, úmidas ao redor da boca,<br>narinas e ânus e outras áreas da pele em que há umidade ou fricção.<br>Frequentemente presente sem qualquer outro sintoma associado.<br>As lesões contêm espiroquetas e são infectantes. Usar precaução de contato.|
|**Icterícia**|Hiperbilirrubinemia secundária à hepatite sifilítica e/ou hemólise.|
||**HEMATOLÓGICAS**|
|**Anemia**|Período neonatal: hemolítica (teste de Coombs [teste antiglobulina direto]<br>não reagente).<br>Pode persistir após tratamento efetivo.<br>Após 1 mês de idade: pode ser crônica e não hemolítica.|
|**Trombocitopenia**|Algumas vezes associada a sangramento ou petéquias.<br>Pode ser a única manifestação da infecção congênita.|
|**Leucopenia**|–|
|**Leucocitose**|–|
||**MUSCULOESQUELÉTICAS**<br>|
|**Pseudoparalisia de**<br>**Parrot**|Ausência de movimentação de um membro causada por dor associada à lesão<br>óssea. Afeta com mais frequência membros superiores que inferiores;<br>geralmente unilateral; raramente presente ao nascimento.<br>Baixa correlação com anormalidades radiográficas.|
|**Anormalidades**<br>**radiográficas**|Anormalidade mais comum na sífilis congênita precoce não tratada, surgindo<br>em 70% a 100% dos casos; tipicamente múltipla e simétrica, acometendo<br>principalmente ossos longos (rádio, ulna, úmero, tíbia, fêmur e fíbula).<br>Pode ocorrer dor à movimentação ativa ou passiva dos membros e, por causa<br>da dor, a criança pode apresentar-se irritada e tendente à imobilidade.|
|**Periostite**|Espessamento periosteal irregular, especialmente na diáfise; geralmente<br>extensa, bilateral e simétrica.|
|**Sinal de Wegner**|Osteocondrite metafisária, visível nas extremidades principalmente do fêmur<br>e do úmero. Há uma sombra de maior densidade, que é a matriz calcificada,<br>com formação “em taça” da epífise.|
|**Sinal de Wimberger**|Desmineralização e destruição óssea da parte superior medial tibial.|  
<!-- Start of picture text -->
£% Conitec Sy Ay<br><!-- End of picture text -->  
||**NEUROLÓGICAS**|
|---|---|
|**Anormalidades no**<br>**líquido**<br>**cefalorraquidiano**<br>**(líquor, LCR)**|No mínimo 1 dos 3 parâmetros alterados: células > 25/mm3 OU proteínas ><br>150 mg/dl, ou VDRL POSITIVO.|
|**Leptomeningite**<br>**sifilítica aguda**|Surge no primeiro ano de vida, geralmente entre 3 e 6 meses; apresentação<br>semelhante à meningite bacteriana, mas com alterações liquóricas mais<br>consistentes com meningite asséptica (predominância mononuclear).<br>Responde à terapêutica com penicilina.|
|**Sífilis crônica**<br>**meningovascular**|Surge a partir do fim do primeiro ano de vida.<br>Hidrocefalia; paralisia de nervo craniano; deterioração do desenvolvimento<br>intelectual/neuropsicomotor; infarto cerebral.<br>Curso prolongado.|
||**OUTROS**|
|**Pneumonia/pneumon**<br>**ite/esforço**<br>**respiratório**|Opacificação completa de ambos os campos pulmonares na radiografia de<br>tórax.|
|**Síndrome nefrótica**|Geralmente acontece entre 2 e 3 meses de idade, manifestando-se como<br>edema generalizado e ascite (anasarca).|  
Fontes: (10,20,31,40–43)  
Legenda: AST/ALT – aspartato aminotransferase/alanina aminotransferase; FA – fosfatase alcalina.  
As manifestações clínicas da sífilis congênita tardia estão relacionadas à inflamação cicatricial ou persistente da infecção precoce e se caracterizam pela presença de formação das gomas sifilíticas em diversos tecidos. Surgem em aproximadamente 40% das crianças nascidas de mulheres não tratadas para sífilis durante a gestação. Algumas manifestações podem ser prevenidas por meio do tratamento materno durante a gestação ou do tratamento da criança nos primeiros três meses de vida (44). Porém, outras manifestações, como a ceratite intersticial, articulações de Clutton e surdez neurossensorial podem ocorrer e progredir, a despeito de terapêutica apropriada (45–47).  
As manifestações de sífilis congênita tardia estão descritas no Quadro 29.  
Quadro 29 – Manifestações clínicas de sífilis congênita tardia  
|**CARACTERÍSTICAS**|**MANIFESTAÇÕES**|
|---|---|
|**Faciais**|Fronte olímpica, nariz em sela, hipodesenvolvimento maxilar,<br>palato em ogiva.|  
|**Oftalmológicas**|Ceratite intersticial, coriorretinite, glaucoma secundário, cicatriz<br>córnea, atrofia óptica.|
|---|---|
|**Auditivas**|Perda aditiva sensorial.|
|**Orofaríngeas**|Dentes de Hutchinson: incisivos medianos deformados, molares em<br>amora, perfuração do palato duro.|
|**Cutâneas**|Rágades (fissuras periorais e perinasais), gomas.|
|**Sistema nervoso**<br>**central**|Atraso no desenvolvimento, comprometimento intelectual,<br>hidrocefalia, crises convulsivas, atrofia do nervo óptico, paresia<br>juvenil.|
|**Esqueléticas**|Tíbia em sabre, sinal de Higoumenakis (alargamento da porção<br>esternoclavicular da clavícula), juntas de Clutton (artrite indolor),<br>escápula escafoide.|  
Fonte: (10,20,31,40–43).  
###### **4.14.2. Testagem para sífilis e exames complementares para a criança com sífilis congênita**  
Nos casos de sífilis congênita, o _T. pallidum_ é liberado diretamente na circulação fetal, resultando em ampla disseminação das espiroquetas por quase todos os órgãos e sistemas. As manifestações clínicas decorrem da resposta inflamatória e são variáveis. Ossos, fígado, pâncreas, intestino, rins e baço são os órgãos mais frequente e gravemente envolvidos. Dessa forma, a investigação com exames complementares tem como objetivo a identificação dessas alterações (39).  
|Os testes de sífilis e ex<br>Quadro 30 – Testes de<br>**EXAME**<br>**COMPLEMENTAR**<br>|ames deverão ser r<br>sífilis e exames co<br>**NA**<br>**MATERNIDADE**<br>|ealizados de acordo com<br>mplementares para crianç<br>**NO SEGUIMENTO**<br>|o Quadro 30.<br>as com sífilis congênita<br>**O QUE AVALIAR**<br>|
|---|---|---|---|
|**Teste não**<br>**treponêmico**<br>|Coletar<br>amostras<br>de<br>sangue<br>periférico do RN<br>e<br>da<br>mãe<br>pareadas<br>para<br>comparação.<br>Não<br>realizar<br>coleta de cordão<br>umbilical.<br>|Realizar com 1,<br>3, 6, 12 e 18<br>meses de idade.<br>Interromper<br>o<br>seguimento<br>laboratorial<br>após:<br>Dois<br>testes<br>**não**<br>**reagentes**<br>consecutivos.<br>|Espera-se<br>que<br>os<br>testes<br>não<br>treponêmicos declinem aos 3 meses<br>de idade, devendo ser**não reagentes**<br>aos 6 meses caso a criança tenha sido<br>adequadamente tratada.<br>Idealmente, o exame deve ser feito<br>pelo mesmo método e no mesmo<br>laboratório.<br>~~a~~|  
<!-- Start of picture text -->
% Conitec Sy te<br><!-- End of picture text -->  
|**Teste treponêmico**|Não realizar.|**NÃO é obrigatório.**<br>Pode ser realizado a<br>partir dos 18 meses de<br>idade.|Um teste treponêmico reagente após<br>os<br>18<br>meses<br>idade<br>(quando<br>desaparecem os anticorpos maternos<br>transferidos<br>passivamente<br>no<br>período intrauterino) confirma o<br>diagnóstico de sífilis congênita. Um<br>resultado não reagente não exclui<br>sífilis congênita nos casos em que a<br>criança foi tratada precocemente<br>Criança com teste treponêmico<br>reagente após 18 meses de idade e<br>que<br>não<br>tenha<br>histórico<br>de<br>tratamento prévio deverá passar por<br>avaliação<br>completa,<br>receber<br>tratamento e ser notificada como<br>caso de sífilis congênita|
|---|---|---|---|
|**Hemograma**|SIM|De acordo com<br>alterações clínicas.<br>A critério clínico.|Anemia hemolítica com Coombs não<br>reagente no período neonatal ou<br>crônica não hemolítica no período<br>pós-natal.<br>Leucopenia ou leucocitose.<br>Hemólise pode estar acompanhada<br>de crioglobulinemia, formação de<br>complexo<br>imune<br>e<br>macroglobulinemia.<br>Esse<br>quadro<br>pode durar semanas e costuma não<br>ser responsivo à terapêutica.<br>Plaquetopenia.|
|**Plaquetas**|SIM||Trombocitopenia;|
|**Exames para**<br>**avaliação de**<br>**função hepática,**<br>**pancreática, renal**<br>**e distúrbios**<br>**eletrolíticos.**|SIM||aumento das trasaminases;<br>icterícia;<br>distúrbios hidroeletrolíticos|
|**Líquor (LCR)**|SIM|Deve ser avaliado a<br>cada<br>6<br>meses<br>nas<br>crianças<br>que<br>apresentaram<br>alteração<br>inicial<br>(neurossífilis),<br>até<br>normalização.|VDRL reagente no líquor.<br>Pleocitose.<br>Proteína aumentada (Valores de<br>exames liquóricos no Quadro 31).<br>VDRL reagente no líquor ou aumento<br>na celularidade ou da proteína que<br>não possam ser atribuídos a outras<br>causas requerem tratamento para<br>possível neurossífilis (Figura 13).|  
|<br>Coni|<br> tec|<br> <br>|<br> <br> <br>><br>a<br>is 5|
|---|---|---|---|
|**Radiografia de**<br>**ossos longos**|SIM|De<br>acordo<br>com<br>alterações clínicas|Bandas<br>metafisárias<br>luzentes<br>(diagnóstico diferencial com outras<br>doenças sistêmicas).<br>Desmineralizações<br>simétricas<br>localizadas e destruição óssea da<br>porção medial da metáfise proximal<br>tibial<br>(sinal<br>de<br>Wimberger<br>–<br>diagnóstico<br>diferencial<br>com<br>osteomielite e hiperparatireoidismo<br>neonatal).<br>Serrilhado<br>metafisário<br>(sinal<br>de<br>Wegener).<br>Periostite<br>diafisária<br>com<br>neoformação óssea (pode acontecer<br>em outras patologias).<br>Áreas irregulares de aumento de<br>densidade e rarefação.|
|**Radiografia de**<br>**tórax**|SIM||A descrição clássica é a opacificação<br>completa de ambos os campos<br>pulmonares. No entanto, com o<br>advento da penicilina, é mais comum<br>encontrar<br>infiltrado<br>difuso<br>envolvendo<br>todos<br>os<br>campos<br>pulmonares.|
|**Neuroimagem**|A critério clínico||Realizar neuroimagem nas crianças<br>que apresentem alterações LCR<br>persistentes<br>(VDRL<br>reagente,<br>proteinorraquia<br>ou<br>celularidade),<br>sem outra explicação mais provável.<br>USTF seria um exame não invasivo.|  
Fonte: DCCI/SVS/MS.  
###### **4.14.3. Neurossífilis na criança com sífilis congênita**  
A infecção do sistema nervoso central pelo _T. pallidum_ , ou neurossífilis, pode ser sintomática ou assintomática nas crianças com sífilis congênita. A neurossífilis é de ocorrência mais provável em crianças que nascem sintomáticas do que nas assintomáticas; portanto, o benefício do teste deve ser considerado, especialmente em razão da necessidade de internação para administração de benzilpenicilina potássica/cristalina.  
Acredita-se que a neurossífilis ocorra em 60% das crianças com sífilis congênita, com base na presença de alterações no líquor, como reatividade no VDRL, pleocitose e aumento na proteinorraquia. No entanto, nenhum desses achados apresentam suficiente sensibilidade e especificidade (48,49). Além disso, a reatividade do VDRL no líquor do recém-nascido pode  
<!-- Start of picture text -->
% Conitec Sy . :<br><!-- End of picture text -->  
representar falso reagente relacionado a anticorpos maternos circulando no SNC do neonato,  
ou contaminação com sangue periférico por acidente de punção; podem existir, ainda, falsonegativos (recém-nascidos com VDRL não reagente em um primeiro momento) que posteriormente desenvolvem sinais de neurossífilis.  
A despeito disso, o teste não treponêmico reagente é o parâmetro mais importante, com 90% de especificidade e 54% de sensibilidade (48). Mas, para adequada avaliação desses parâmetros, o LCR deve estar livre de qualquer contaminação por sangue que possa ocorrer em casos de acidente de punção.  
Para o exame liquórico do RN, consideram-se os valores para diagnóstico de neurossífilis constantes no Quadro 31.  
Quadro 31 – Valores de exame liquórico em crianças com suspeita de neurossífilis  
|**Parâmetro**|**LCR normal pré-**<br>**termo**|**LCR normal a**<br>**termo**|**LCR sugestivo de**<br>**sífilis no RN**|**LCR sugestivo de**<br>**sífilis nas crianças**<br>**maiores que 28 dias**|
|---|---|---|---|---|
|**Leucócitos**|9+8 céls/mm<sup>3</sup><br>(LVN: 0-29<br>céls/mm<sup>3</sup>)|8+7 céls/mm<sup>3</sup><br>(LVN: 0-32<br>céls/mm<sup>3</sup>)|Maior que 25<br>céls/mm<sup>3</sup>|Maior que 5<br>céls/mm<sup>3</sup>|
|**Proteínas**|115mg/dL<br>(LVN: 65-<br>150mg/dL)|90mg/dL<br>(LVN: 20-<br>170mg/dL)|Maior que<br>150mg/dL|Maior que 40mg/dL|
|**VDRL**|Não reagente|Não reagente|Reagente|Reagente|  
Fonte: (26,50) Legenda: LVN – Limite de variação do normal.  
###### **4.14.4. Seguimento clínico da criança com sífilis congênita**  
O seguimento pode ser feito na puericultura, na Atenção Básica, durante as consultas de rotina, conforme orientação da Saúde da Criança (35), com atenção mais cuidadosa no monitoramento de sinais e sintomas sugestivos de sífilis congênita, além dos testes de sífilis e exames complementares constantes no Quadro 32.  
Mesmo recebendo tratamento com penicilina na maternidade, deve-se considerar que essa criança se insere em um grupo de risco de desenvolvimento de sífilis congênita sintomática. Assim, é fundamental o seguimento clínico dessa criança.  
O seguimento clínico mínimo das crianças com sífilis congênita (sintomáticas e assintomáticas) está descrito no Quadro 32. As orientações poderão mudar de acordo com as necessidades da  
<!-- Start of picture text -->
% Conitec Sy te<br><!-- End of picture text -->  
criança, devendo ser garantido o cuidado tanto na Atenção Básica como nos serviços especializados e hospitalares, quando for o caso.  
Quadro 32 – Seguimento clínico da criança com sífilis congênita  
|**PROCEDIMENTO**|**FREQUÊNCIA E**<br>**DURAÇÃO**|**O QUE AVALIAR**|
|---|---|---|
|**Consultas**<br>**ambulatoriais de**<br>**puericultura**|Seguimento habitual na<br>rotina da puericultura,<br>conforme<br>recomendação da<br>Saúde da Criança: na 1ª<br>semana de vida e no 1º,<br>2º, 4º, 6º, 9º, 12º e 18º<br>mês, com retorno para<br>checagem de exames<br>complementares, se for<br>o caso.|A criança exposta à sífilis, mesmo que não tenha sido<br>diagnosticada com sífilis congênita no momento no<br>nascimento, pode apresentar sinais e sintomas<br>compatíveis ao longo do seu desenvolvimento. Dessa<br>forma, deve ser realizada busca ativa de sinais e<br>sintomas a cada retorno (Quadro 28, referente às<br>manifestações precoces de sífilis congênita). Especial<br>atenção deve ser dada aos sinais e sintomas clínicos,<br>além de vigilância quanto ao desenvolvimento<br>neuropsicomotor.<br>Fazer a solicitação dos testes não treponêmicos, para<br>que os resultados estejam disponíveis na consulta de<br>retorno.<br>Aproveitar o momento da consulta para avaliar risco de<br>outras IST maternas. O diagnóstico prévio de uma IST é<br>fator de risco para outras, inclusive HIV, que pode ser<br>transmitido pelo aleitamento materno.<br>Indagar sobre práticas sexuais e oferecer testagem para<br>a mãe da criança e suas parcerias sexuais, na rotina,<br>enquanto a mulher estiver amamentando (testagem<br>para HIV pelo menos a cada 6 meses).<br>Oferecer teste rápido para hepatite B e vacina contra<br>hepatite B, quando não houver histórico de vacinação.|
|**Consulta**<br>**oftalmológica**|Semestrais por 2 anos|Buscar anomalias oftalmológicas. As mais comuns são<br>ceratite intersticial, coriorretinite, glaucoma secundário,<br>cicatriz córnea e atrofia óptica. A faixa etária de<br>acometimento de ceratite intersticial costuma ser dos 2<br>aos 20 anos.|
|**Consulta**<br>**audiológica**|Semestrais por 2 anos|Buscar anomalias auditivas.<br>A perda auditiva sensorial pode ter ocorrência mais<br>tardia, entre 10 e 40 anos de idade, por acometimento<br>do 8º par craniano.|
|**Consulta**<br>**odontológica**|Semestrais por 2 anos,<br>após 12 meses de idade<br>(1 ano até 3 anos de<br>idade)|Buscar anomalias odontológicas. As mais comuns são<br>dentes de Hutchinson (incisivos medianos deformados)<br>e dentes de Mulberry (primeiros molares com formato<br>de amora, perfuração do palato duro). Os dentes de<br>Hutchinson só surgem com o aparecimento dos dentes<br>permanentes. Os molares de Mulberry são mais<br>precoces, aparecendo entre os 13 e 19 meses de idade.|  
|**Consulta**|Semestrais por 2 anos|Avaliar o desenvolvimento neuropsicomotor.|
|---|---|---|
|**neurológica**||No caso de neurossífilis, repetir punção lombar a cada 6<br>meses, até normalização bioquímica, citológica e<br>sorológica. Se o VDRL liquórico se mantiver positivo ou<br>celularidade e/ou proteína liquóricos se mantiverem<br>alterados, realizar nova investigação clínico laboratorial<br>e retratar. Exame de imagem pode ser considerado<br>também nesse cenário.|  
Fonte: DCCI/SVS/MS.  
###### **4.15. Tratamento da criança com sífilis congênita**  
O medicamento para tratamento de crianças com sífilis congênita é a benzilpenicilina (potássica/cristalina, procaína ou benzatina), a depender do tratamento materno durante a gestação e/ou titulação de teste não treponêmico da criança comparado ao materno e/ou exames clínicos/laboratoriais da criança (51).  
Para as crianças com sífilis congênita que apresentem neurossífilis, a cristalina é o medicamento de escolha, sendo obrigatória a internação hospitalar. Na ausência de neurossífilis, a criança com sífilis congênita pode ser tratada com benzilpenicilina procaína fora da unidade hospitalar, por via intramuscular, ou com benzilpenicilina potássica/cristalina, por via endovenosa, internada.  
A benzilpenicilina benzatina é uma opção terapêutica, mas restrita às crianças cuja mãe não foi tratada ou foi tratada de forma não adequada, e que apresentem exame físico normal, exames complementares normais e teste não treponêmico não reagente ao nascimento. _A única situação em que não é necessário tratamento é a da criança exposta à sífilis (aquela nascida assintomática, cuja mãe foi adequadamente tratada e cujo teste não treponêmico é não reagente ou reagente com titulação menor, igual ou até uma diluição maior que o materno). Essas crianças não são notificadas na maternidade, mas devem ser acompanhadas na Atenção Básica, com seguimento clínico e laboratorial._ ~~<mark>Oo</mark>~~ Até o momento, não há evidências científicas da eficácia do uso da ceftriaxona no tratamento de sífilis congênita e, portanto, reforça-se que essa medicação poderá ser utilizada como alternativa somente em situações de indisponibilidade das benzilpenicilinas potássica  
<!-- Start of picture text -->
X¥ Conitec “ | u 4 £<br><!-- End of picture text -->  
(cristalina) e procaína. Também não se observa evidência de resistência do _Treponema pallidum_ à penicilina no Brasil e no mundo.  
###### **4.15.1. Tratamento com benzilpenicilina benzatina em dose única**  
Para crianças assintomáticas, ou seja, com exame físico normal, sem alterações liquóricas, com radiografias de ossos longos normais e sem outras alterações viscerais, com teste não treponêmico não reagente, o tratamento com benzilpenicilina benzatina em dose única é eficaz para prevenção de evidência clínica de sífilis congênita, conforme a Figura 12  (52,53).  
Figura 12 – Tratamento com benzilpenicilina benzatina dose única  
<!-- Start of picture text -->
Crianças nascidas de mães não tratadas ou tratadas de forma não adequada, com<br>exame físico normal, exames complementares normais e teste não treponêmico<br>não reagente ao nascimento<br>|<br>↓<br>Tratar com benzilpenicilina 50.000 UI/kg, intramuscular, dose<br>única<br>PF<br><!-- End of picture text -->  
Fonte: DCCI/SVS/MS.  
###### **4.15.2. Tratamento com benzilpenicilina por dez dias**  
- Benzilpenicilina procaína 50.000 UI/kg, IM, uma vez ao dia, por 10 dias OU  
- benzilpenicilina potássica (cristalina) 50.000 UI/kg, IV, de 12/12h (crianças com menos de 1 semana de vida) e de 8/8h (crianças com mais de 1 semana de vida), por 10 dias.  
É necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose.  
**Na ausência de neurossífilis** , a criança com sífilis congênita pode ser tratada com benzilpenicilina procaína fora da unidade hospitalar, por via intramuscular; OU com benzilpenicilina potássica/cristalina, com internação hospitalar.  
Como existem evidências de que os níveis de penicilina no líquor são menores com penicilina procaína, é recomendado o uso de **benzilpenicilina potássica/cristalina para os casos de neurossífilis** , com necessidade de internação hospitalar (54).  
. :  
O esquema completo de dez dias com benzilpenicilina deve ser administrado mesmo nos casos  
em que a criança tenha recebido ampicilina por outra causa.  
###### **4.15.3. Tratamento de sífilis congênita no período pós-natal**  
- Benzilpenicilina potássica (cristalina) 50.000 UI/kg, IV, de 4/4h a 6/6h, <u>por 10 dias.</u>  
Crianças diagnosticadas com sífilis congênita após um mês de idade e aquelas com sífilis adquirida deverão ser tratadas com benzilpenicilina potássica/cristalina.  
**4.16. Manejo da criança exposta à sífilis e da criança com sífilis congênita**  
Figura 13 – Fluxograma para avaliação e manejo na maternidade das crianças nascidas de mães com diagnóstico de sífilis na gestação atual ou no momento do parto  
Fonte: DCCI/SVS/MS.  
Legenda: TNT – Teste não treponêmico periférico.  
* Realizar TNT em sangue periférico em todos recém-nascidos de mãe com teste rápido e/ou TNT reagente no momento do parto, independentemente de tratamento prévio realizado.  
Observação 1:  
**Tratamento materno adequado:**  
Registro de tratamento completo com benzilpenicilina benzatina, adequado para o estágio clínico, com primeira dose realizada até 30 dias antes do parto.  
Observação 2:  
###### **Opções terapêuticas:**  
**Benzilpenicilina potássica/cristalina** 50.000 UI/kg, intravenosa, de 12/12h na primeira semana de vida, de 8/8h após a primeira semana de vida, por 10 dias.  
Obs.: é necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose.  
**Benzilpenicilina procaína** 50.000 UI/kg, intramuscular, uma vez ao dia, por 10 dias.  
Obs.: é necessário reiniciar o tratamento se houver atraso de mais de 24 horas na dose.  
**Benzilpenicilina benzatina** 50.000 UI/kg, intramuscular, dose única.  
Observação 3:  
**Investigação para STORCH (sífilis, toxoplasmose, rubéola, citomegalovírus e herpes vírus):**  
Portaria nº 3.502, de 19 de dezembro de 2017, que instituiu a Estratégia de fortalecimento das ações de cuidado das crianças suspeitas ou confirmadas para Síndrome Congênita associada à infecção pelo vírus Zika e outras síndromes causadas por sífilis, toxoplasmose, rubéola, citomegalovírus e herpes vírus.  
Avaliação de acordo com as “Orientações integradas de vigilância e atenção à saúde no âmbito da Emergência de Saúde Pública de Importância Nacional”.  
_As crianças nascidas de mãe com cicatriz sorológica para sífilis antes da gestação_ **_DEVEM_** _realizar teste não treponêmico na maternidade e, na ausência de sinais/sintomas, não necessitam de avaliação ou tratamento na maternidade. No entanto, a testagem para sífilis deve ocorrer, conforme rotina preconizada no pré-natal (1º e 3º trimestres de gestação), idealmente por meio de testes não treponêmicos._  
_* Documentação de queda do título do teste não treponêmico em pelo menos duas diluições em três meses, ou de quatro diluições em seis meses após a conclusão do tratamento (ex: antes, 1:16; depois, menor ou igual a 1:4)_  
**4.17. Atribuições essenciais dos pontos de atenção à criança exposta/sífilis congênita**  
O cuidado à criança exposta à sífilis e com sífilis congênita envolve diferentes pontos de atenção à saúde. O seguimento é fundamental para crianças expostas à sífilis e com diagnóstico de sífilis congênita. Portanto, estabelecer a linha de cuidado dessas crianças na rede de atenção é de  
<!-- Start of picture text -->
#¥ Conitec a bk<br><!-- End of picture text -->  
responsabilidade de estados, DF e municípios. A Figura 14 delimita os campos de responsabilidade e o papel da Atenção Básica como coordenadora do cuidado.  
Figura 14 – Linha de cuidado da criança exposta à sífilis e com sífilis congênita  
###### **Atenção Básica Pré-natal**  
###### **Maternidade ou casa de parto**  
###### **Atenção Básica coordenadora do cuidado**  
###### **Serviços da especialidade**  
- Receber referência da Atenção Básica quanto ao histórico de tratamento e resultado de exames realizados durante o prénatal.  
- Garantir cobertura de pré-natal a todas as gestantes e suas parcerias sexuais. Idealmente, fazer seguimento e planejamento reprodutivo, incluindo rastreio de IST, abordagem à saúde sexual e Prevenção Combinada.  
- Fazer TR de HIV e sífilis no momento do parto ou em caso de aborto/ natimorto.  
- Realizar parto de acordo com indicação obstétrica.  
- Realizar testagem de obstétrica. sífilis no pré-natal, no  Avaliar todo RN ao  
- primeiro e terceiro nascimento quanto ao  
- trimestres de gestação e histórico de tratamento  
- no puerpério. materno e presença ou  
- Realizar tanto TR para ausência de sinais/ sífilis quanto teste não sintomas clínicos. treponêmico (ex.:  Notificar a mãe como  
- VDRL/RPR). sífilis em gestante caso  
- Notificar todos os casos não haja registro no  
- de sífilis em gestantes. Sinan.  
- Aplicar penicilina  Notificar a criança benzatina na gestante e conforme definição de documentar tratamento. caso de sífilis congênita.  
- Orientar a gestante  Fazer contrarreferência quanto ao risco de nova para Atenção Básica  
- exposição à sífilis. (com consulta  
- Investigar e tratar as agendada), de modo a parceiras sexuais das garantir o seguimento gestantes. clínico e laboratorial da  
- Avaliar todo RN ao nascimento quanto ao histórico de tratamento materno e presença ou ausência de sinais/ sintomas clínicos.  
- Notificar a criança conforme definição de caso de sífilis congênita.  
- Fazer contrarreferência para Atenção Básica (com consulta agendada), de modo a garantir o seguimento clínico e laboratorial da criança exposta ou com sífilis congênita na puericultura.  
- Monitorar mensalmente a gestante com teste não treponêmico.  
- Tratar criança com sífilis congênita na maternidade, sem dispensar seguimento posterior na Atenção Básica.  
- Referenciar a gestante para a maternidade/ casa de parto com histórico de tratamento, resultado de exames realizados durante o prénatal e número da notificação da gestante no Sinan.  
- Receber referência da maternidade quanto à investigação clínica e laboratorial realizada na maternidade.  
- Fazer seguimento clínico e laboratorial da criança exposta à sífilis ou com sífilis congênita.  
- Realizar puericultura conforme orientações da Saúde da Criança.  
- Notificar criança conforme definição de caso de sífilis congênita, se durante o seguimento houver alteração clínica e/ou laboratorial.  
- Coordenar o cuidado: referência e contrarreferência para especialidade, de acordo com protocolos e necessidade clínica.  
- Manter diálogo com a mulher puérpera sobre saúde sexual, ofertar Prevenção Combinada e rastrear para IST/HIV.  
 Receber referência da Atenção Básica e avaliar seguimento da criança com sífilis congênita, quanto a consultas e exames especializados.  
- Fornecer contrarreferência à Atenção Básica.  
 Notificar criança conforme definição de caso de sífilis congênita, se durante o seguimento houver alteração clínica e/ou laboratorial.  
Fonte: DCCI/SVS/MS.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
###### **REFERÊNCIAS da Parte IV - Prevenção da transmissão vertical da sífilis**  
1. Brasil. Procolo Clínico e Diretrizes Terapeuticas para Atenção às Pessoas com Infecções Sexualmente Transmissíveis (IST). 2020;(0014125063):1–250.  
2. Rolfs RT, Joesoef MR, Hendershot EF, Rompalo AM, Augenbraun MH, Chiu M, et al. A randomized trial of enhanced therapy for early syphilis in patients with and without human immunodeficiency virus infection. N Engl J Med. 1997;337(5):307–14.  
3. Workowski, Kimberly A., Gail A. Bolan. MMWR Sexually Transmitted Diseases Treatment Guidelines, 2015 [Internet]. Vol. 64. 2015. Available from: https://www.cdc.gov/std/tg2015/tg-2015-print.pdf  
4. Peeling RW, Mabey D, Kamb ML, Chen X, David J, Benzaken AS, et al. Syphilis. Nat Rev Dis Prim. 2018;3(17073):49.  
5. Gomez GB, Kamb ML, Newman LM, Mark J, Broutet N, Hawkes SJ. Untreated maternal syphilis and adverse outcomes of pregnancy: a systematic review and meta-analysis. Bull World Health Organ. 2013;91(3):217–26.  
6. Brasil. Relação Nacional de Medicamentos Essenciais: Rename 2017. Ministério da Saúde Secr Ciência, Tecnol e Insumos Estratégicos Dep Assist Farm e Insumos Estratégicos [Internet]. 2017; Available from: https://bvsms.saude.gov.br/bvs/saudelegis/gm/1998/prt3916_30_10_1998.html%0Aht tp://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prt2436_22_09_2017.html  
7. Brasil. Penicilina benzatina para prevenção da sífilis congênita durante a gravidez. CONITEC - Comissão Nac Inc Tecnol no SUS [Internet]. 2015; Available from: http://conitec.gov.br/images/Relatorios/2015/Relatorio_Penicilina_SifilisCongenita_fin al.pdf  
8. Ghanem KG, Ram S, Rice PA. The modern epidemic of syphilis. N Engl J Med. 2020;382(9):845–54.  
9. Seña AC, Wolff M, Behets F, Martin DH, Leone P, Langley C, et al. Rate of Decline in Nontreponemal Antibody Titers and Seroreversion after Treatment of Early Syphilis. Sex Transm Dis. 2017;44(1):7–11.  
10. Hollier LM, Harstad TW, Sanchez PJ, Twickler DM, Wendel GD. Fetal syphilis: Clinical and laboratory characteristics. Obstet Gynecol. 2001;97(6):947–53.  
11. Mehmet Genç WJL. Syphilis in Pregnancy. Sex Transm Inf2000;76. 2000;76:73–79.  
12. Rac MWF, Revell PA, Eppes CS. Syphilis during pregnancy: a preventable threat to maternal-fetal health. Am J Obstet Gynecol [Internet]. 2017;216(4):352–63. Available from: http://dx.doi.org/10.1016/j.ajog.2016.11.1052  
13. Butler T. The Jarisch-Herxheimer reaction after antibiotic treatment of spirochetal infections: A review of recent cases and our understanding of pathogenesis. Am J Trop Med Hyg. 2017;96(1):46–52.  
14. BRASIL. Acolhimento à demanda espontânea: Queixas mais comuns na Atenção Básica. Cadernos de Atenção Básica [Internet]. Ministério. Vol. II. 2013. Available from: http://bvsms.saude.gov.br/bvs/publicacoes/acolhimento_demanda_espontanea_cab2  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
8v1.pdf  
15. COFEN. Decisão n° 0094/2015, de 8 de julho de 2015. Revoga o Parecer de Conselheiro 008/2014. PAD COFEN 032/2012. Administração de penicilina pelos profissionais de enfermagem. Brasília: COFEN, 2015. Disponível em: <http://www.cofen.gov.br/decisaocofen-no-00942.  
16. Shenoy ES, Macy E, Rowe T, Blumenthal KG. Evaluation and Management of Penicillin Allergy: A Review. JAMA - J Am Med Assoc. 2019;321(2):188–99.  
17. Galvao TF, Silva MT, Serruya SJ, Newman LM, Klausner JD, Pereira MG, et al. Safety of Benzathine Penicillin for Preventing Congenital Syphilis: A Systematic Review. PLoS One. 2013;8(2).  
18. Romanowski B, Sutherland R, Fick GH, Mooney D, Love EJ. Serologic response to treatment of infectious syphilis. Ann Intern Med. 1991;114(12):1005–9.  
19. Tong ML, Lin LR, Liu GL, Zhang HL, Zeng YL, Zheng WH, et al. Factors Associated with Serological Cure and the Serofast State of HIV-Negative Patients with Primary, Secondary, Latent, and Tertiary Syphilis. PLoS One. 2013;8(7).  
20. WHO. WHO guideline on syphilis screening and treatment for pregnant women. [Internet]. 2017. 56 p. Available from: http://apps.who.int/iris.  
21. Grimprel E, Sanchez PJ, Wendel GD, Burstain JM, McCracken GH, Radolf JD, et al. Use of polymerase chain reaction and rabbit infectivity testing to detect Treponema pallidum in amniotic fluid, fetal and neonatal sera, and cerebrospinal fluid. J Clin Microbiol. 1991;29(8):1711–8.  
22. Nathan L, Twickler DM, Peters MT, Sánchez PJ, Wendel GD. Fetal syphilis: Correlation of sonographic findings and rabbit infectivity testing of amniotic fluid. Obstet Gynecol Surv. 1993;48(11):730–1.  
23. Qureshi F, Jacques SM, Reyes MP. Placental histopathology in syphilis. Hum Pathol. 1993;24(7):779–84.  
24. Milagros P. Reyes, Nancy Hunt, Enrique M. Ostrea, Jr.  and DG. Maternal/Congenital Syphilis in a Large Tertiary-Care Urban Hospital. Clin Infect Dis. 1993;17(6):1041–6.  
25. Caddy SC, Lee BE, Sutherland K, Robinson JL, Plitt SS, Read R, et al. Pregnancy and Neonatal Outcomes of Women With Reactive Syphilis Serology in Alberta, 2002 to 2006. J Obstet Gynaecol Canada [Internet]. 2011;33(5):453–9. Available from: http://dx.doi.org/10.1016/S1701-2163(16)34878-2  
26. Lago EG, Vaccari A, Fiori RM. Clinical features and follow-up of congenital syphilis. Sex Transm Dis. 2013;40(2):85–94.  
27. Berman SM. Maternal syphilis: Pathophysiology and treatment. Bull World Health Organ. 2004;82(6):433–8.  
28. Blencowe H, Cousens S, Kamb M, Berman S, Lawn JE. Lives saved tool supplement detection and treatment of syphilis in pregnancy to reduce syphilis related stillbirths and neonatal mortality. BMC Public Health [Internet]. 2011;11(SUPPL. 3):S9. Available from: http://www.biomedcentral.com/1471-2458/11/S3/S9  
29. Woods CR. Congenital syphilis-persisting pestilence. Pediatr Infect Dis J. 2009;28(6):536– 7.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
30. Brasil. Nota informativa n<sup>o</sup> 2-SEI/2017-.DIAHV/SVS/MS - Altera os critérios de definição de casos para notificacao de sífilis adquirida, sífilis em gestantes e sífilis congênita [Internet]. 2017. p. 6. Available from: http://portalsinan.saude.gov.br/images/documentos/Agravos/SifilisGes/Nota_Informativa_Sifilis.pdf  
31. Rawstron SA, Mehta S, Marcellino L, Rempel J, Chery F, Bromberg K. Reactivity After the Age of 1 Year. :412–6.  
32. Morshed MG, Singhb AE. Recent trends in the serologic diagnosis of syphilis. Clin Vaccine Immunol. 2015;22(2):137–43.  
33. Singh AE, Guenette T, Gratrix J, Bergman J, Parker P, Anderson B, et al. Seroreversion of treponemal tests in infants meeting Canadian surveillance criteria for confirmed early congenital syphilis. Pediatr Infect Dis J. 2013;32(3):199–202.  
34. OMS. Laboratory diagnosis of sexually transmitted infections, including human immunodeficiency virus. World Heal Organ. 2013;244.  
35. Brasil. Ministério da Saúde. Secretaria de Atenção à Saúde. Departamento de Atenção Básica. Saúde da criança: crescimento e desenvolvimento (Cadernos de Atenção Básica n<sup>o</sup> 33). [Internet]. 2012. 271p.: il. Available from: https://bvsms.saude.gov.br/bvs/publicacoes/saude_crianca_crescimento_desenvolvim ento.pdf  
36. BOWEN, V.; SU, J.; TORRONE E. Increase in incidence of congenital syphilis, United States, 2012-2014. MMWR. 2015;64(44):1241.  
37. Ortiz-Lopez N, Diez M, Diaz O, Simon F, Diaz A. Epidemiological surveillance of congenital syphilis in Spain, 2000-2010. Pediatr Infect Dis J. 2012;31(9):988–90.  
38. Herremans T, Kortbeek L, Notermans DW. A review of diagnostic tests for congenital syphilis in newborns. Eur J Clin Microbiol Infect Dis. 2010;29(5):495–501.  
39. Woods CR. Syphilis in children: Congenital and acquired. Semin Pediatr Infect Dis. 2005;16(4):245–57.  
40. KOLLMANN, T. R.; DOBSON, S. Syphilis. In: WILSON, C. B.; NIZET, V.; MALDONADO Y et al. Remington and Klein’s Infectious Diseases of the Fetus and Newborn Infant. 7. ed. Vol. 66, Archives of Disease in Childhood. Philadelphia: Elsevier Saunders; 2010. 524 p.  
41. Chakraborty R, Luck S. Syphilis is on the increase: The implications for child health. Arch Dis Child. 2008;93(2):105–9.  
42. Robinson JL, Society CP. Congenital syphilis: No longer just of historical interest. Paediatr Child Health (Oxford). 2009;14(5):337.  
43. Moreira-silva SF, Prebianchi PA, Dias CF, Júnior ANA, Dalvi LG, Frauches DO. Alteraçôes Ósseas em Lactantes com Sífilis congênita. DST- J .bras Doenças Sex Transm. 2009;21(4):175–8.  
44. Stamos JK, Rowley AH. Timely diagnosis of congenital infections. Pediatr Clin North Am. 1994;41(5):1017–33.  
45. OKSALA A. Interstitial keratitis after adequate penicillin therapy; a case report. Br J Vener Dis. 1957;33(2):113–4.  
46. RODIN P. Clutton’s joints. A brief review of the literature, and an unusual case treated  
with intra-articular hydrocortisone. Br J Vener Dis. 1961;37:204–6.  
47. Karmody CS, Schuknecht HF. Deafness in Congenital Syphilis. Arch Otolaryngol. 1966;83(1):18–27.  
48. Michelow IC, Wendel GD, Norgard M V., Zeray F, Kristine Leos N, Alsaadi R, et al. Central nervous system infection in congenital syphilis. N Engl J Med. 2002;346(23):1792–8.  
49. Beeram MR, Chopde N, Dawood Y, Siriboe S, Abedin M. Lumbar puncture in the evaluation of possible asymptomatic congenital syphilis in neonates. J Pediatr. 1996;128(1):125–9.  
50. Joseph J. Volpe MD (Author), Terrie E Inder MB ChB MD (Author), Basil T. Darras (Author), Linda S de Vries MD (Author), Adre J du Plessis MB ChB (Author), Jeffrey Neil MD (Author) JMPMbc (Author). Volpe’s Neurology of the Newborn, 6th edition. 6 edition. Elsevier; 2017. 1240 p.  
51. Walker GJA, Walker D, Franco DM, Grillo-Ardila CF. Antibiotic treatment for newborns with congenital syphilis. Cochrane Database Syst Rev. 2019;2019(2).  
52. Paryani SG, Arthur J V. PEDIATRIC PHARMACOLOGY AND THERAPEUTICS Treatment of asymptomatic congenital syphilis : Benzathine versus procaine penicillin G therapy. 1994;(Cdc):5–9.  
53. Radcliffe M, Roditi MM, Malan A. Single-dose benzathine penicillin in infants at risk of congenital syphilis - results of a randomised study. S Afr Med J. 1997;87(1):62–5.  
54. Azimi PH, Janner D, Berne P, Fulroth R, Lvoff V, Franklin L, et al. Concentrations of procaine and aqueous penicillin in the cerebrospinal fluid of infants treated for congenital syphilis. J Pediatr. 1994;124(4):649–53.  
###### **Parte V - Prevenção da transmissão vertical das hepatites virais 5.1. História natural da hepatite B na gestação**  
A infecção pelo HBV continua sendo um problema de saúde pública mundial (WHO, 2017) devido à sua alta transmissibilidade e o impacto da transmissão vertical na manutenção dos casos crônicos. A hepatite B crônica possui significativas taxas de morbidade e de mortalidade e pode ser classificada em cinco fases, de acordo com os marcadores imunológicos, o grau de atividade da doença e de replicação viral. Para mais informações sobre hepatite B, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e Coinfecções, disponível em <u>http://www.aids.gov.br/pcdt.</u>  
###### **5.1.1. Infecção crônica pelo HBV**  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
A maioria das mulheres jovens com infecção crônica pelo HBV apresenta-se na fase de imunotolerância da infecção (HBsAg positivo, HBeAg positivo), que se caracteriza pela intensa replicação viral, porém, sem doença hepática ativa (ALT/AST em níveis dentro da normalidade e histologia hepática com mínimas alterações). A hepatite B crônica tem pouca influência no curso da gestação, assim como a gestação em geral não altera a história natural da doença; porém, após o parto, poderá ocorrer reativação viral com exacerbação da doença hepática na parturiente (1).  
Na coinfecção com os vírus das hepatites virais B e/ou C, a mulher com infecção crônica poderá usar métodos hormonais, caso não apresente cirrose grave. Sempre que houver dúvidas sobre a prescrição de contraceptivos, consultar os critérios de elegibilidade médica para métodos contraceptivos da Organização Mundial de Saúde (2).  
Mulheres com cirrose hepática secundária ao HBV podem ter prejuízo na sua fertilidade devido às alterações hormonais associadas, e estão sob risco de morte materna e perinatal. Além disso, hipertensão gestacional, aborto, parto pré-termo e restrição do crescimento fetal podem acontecer devido à doença ativa (1).  
Durante a gestação, os níveis de cortisol plasmático se elevam, principalmente, no último trimestre, ocasionando um estado de imunossupressão fisiológica. Nesse período, pode-se observar elevação dos níveis de CV-HBV sem alteração dos níveis de ALT/AST e sem exacerbação da doença hepática (3).  
Entretanto, no pós-parto e no puerpério, os níveis de cortisol plasmático retornam ao normal e há a reconstituição da resposta imunológica materna, podendo ocorrer exacerbação da doença hepática, elevação dos níveis de ALT e em algumas vezes, soroconversão espontânea HBeAg/anti-HBe (3).  
O teste rápido é uma importante ferramenta de acesso rápido ao resultado do HBsAg, para identificar das mulheres portadoras crônicas do HBV, especialmente as que possuem CV-HBV elevada, para que seja iniciado o tratamento ou a quimioprofilaxia em tempo oportuno, e a oferta de profilaxias ao RN exposto no pós-parto imediato, de modo a impedir a TV do HBV (4,5).  
**5.1.2. Infecção aguda pelo HBV**  
<!-- Start of picture text -->
% Conitec Sy . :<br><!-- End of picture text -->  
A infecção aguda pelo HBV durante a gestação não está relacionada a aumento de mortalidade materna ou efeito teratogênico no feto. Há, no entanto, relatos de maior incidência de prematuridade, baixo peso ao nascer e morte fetal ou perinatal, possivelmente devidos a fatores associados à infecção (6–8).  
Quando a infecção aguda pelo HBV ocorre no primeiro trimestre da gestação, o risco de transmissão da infecção ao RN é pequeno, menor que 10%; porém, **quando a infecção ocorre no segundo ou terceiro trimestres da gestação, o risco de transmissão se eleva a níveis superiores a 60%.**  
###### **5.2. Abordagem à mulher em idade reprodutiva com hepatite B**  
O planejamento familiar deve ser sempre discutido com a mulher em idade fértil antes de iniciar qualquer terapêutica, particularmente a terapia antiviral para hepatite B. A decisão de iniciar terapia para hepatite B deve pesar o risco de progressão da doença hepática, o risco de TV e o risco de aumentos transitórios da CV-HBV no período perinatal, além dos possíveis efeitos adversos da medicação e dos riscos de desfechos adversos fetais (1).  
Nas mulheres com infecção crônica pelo HBV com indicação de terapia antiviral (atividade inflamatória moderada a grave e/ou fibrose moderada a grave ou cirrose hepática crônica) e que **não estejam planejando engravidar,** qualquer um dos medicamentos de primeira linha (interferon, entecavir ou tenofovir) poderá ser utilizado, em conjunto com **oferta de contracepção** .  
Nas mulheres com infecção crônica pelo HBV em tratamento com interferon, deve-se garantir a contracepção até o término do tratamento com esse medicamento.  
**5.3. Abordagem de rastreio e vacinação para hepatite B na gestante**  
<u>. :</u>  
Deve-se proceder à investigação da infecção pelo HBV **com pesquisa do HBsAg em todas as gestantes no 1º trimestre da gestação, ou quando se iniciar o pré-natal.** ~~<mark>Po</mark>~~  
Gestantes portadoras de exame **HBsAg reagente** deverão ser orientadas e referenciadas já durante o pré-natal a **unidades obstétricas que assegurem a administração de vacina hepatite B e da imunoglobulina humana anti-hepatite B (IGHAHB) ao RN.** A referência e contrarreferência devem ser documentadas no cartão da gestante.  
**Gestantes que não foram avaliadas durante o pré-natal devem realizar a pesquisa de HBsAg no momento da admissão hospitalar para o parto.** O exame pode ser feito por meio de teste rápido.  
O **esquema vacinal para a hepatite B** com três doses está recomendado durante a gestação, desde o primeiro trimestre, para todas as gestantes sem histórico de vacinação ou com esquema vacinal incompleto.  
**Gestantes expostas ao HBV** em qualquer trimestre, por relação sexual ou acidente com material biológico, deverão receber **associação de vacina e IGHAHB** .  
A realização de testagem para confirmação de imunidade não é recomendada de rotina para todos os indivíduos vacinados, haja vista que a primovacinação induz concentração de anticorpos protetores em >95% dos lactentes, crianças e adultos jovens saudáveis (9).  
Além disso, não se deve testar para anti-HBs indivíduos sem documentação de esquema vacinal completo e realizado respeitando os intervalos mínimos entre as doses, uma vez que os valores de soroproteção não foram validados para pessoas não vacinadas ou com esquemas incompletos (10).  
A dosagem de anti-HBs pós-vacinal em gestantes depende da presença de fator de risco de maior exposição ao vírus ou para perda da resposta de memória imunológica. Estão listadas abaixo as situações em que há recomendação de teste de anti-HBs pós-vacinal:  
- profissionais de saúde e de segurança pública,  
- filhas de mães HBsAg reagente,  
- parcerias sexuais de pessoas vivendo com HBV,  
- usuários de drogas injetáveis,  
- pessoas privadas de liberdade,  
- trabalhadoras do sexo,  
- usuárias de PrEP,  
- pessoas trans,  
- pessoas vivendo com HIV com contagem de linfócitos T CD4+ <350 células/mm³,  
- transplantadas de órgãos sólidos,  
- pessoas em uso de terapia imunossupressora ou quimioterapia,  
- pessoas com neoplasias,  
- hemodialíticos crônicos,  
- aqueles que apresentavam no momento da vacinação: obesidade (IMC ≥30), diabete  
- melito, coinfecção com HCV, doença inflamatória intestinal, doença celíaca.  
Caso a paciente gestante não se encaixe em uma dessas situações, não há indicação de coletar anti-HBs.  
O teste de anti-HBs deve ser feito idealmente entre 1 a 2 meses após o término do esquema vacinal, podendo ser considerados também exames coletados até 6 meses após a última dose.  
Em caso de realização de anti-HBs fora do período preconizado, após 6 meses da última dose, com resultado <10 UI/L, deve-se administrar uma dose de reforço ( _booster_ ), seguido da repetição do exame entre 1 a 2 meses após essa dose (10).  
Mais informações podem ser encontradas no “Manual dos Centros de Referência para Imunobiológicos Especiais”, disponível em http://www.saúde.gov.br/arquivos.  
**5.4. Abordagem à gestante vivendo com hepatite B**  
<!-- Start of picture text -->
£% Conitec > a: {<br><!-- End of picture text -->  
Todas as gestantes identificadas com HBsAg **reagente** devem ser encaminhadas ao pré-natal de  
alto risco e/ou serviço de referência. No entanto, a solicitação de exames complementares e indicação de terapia profilática não devem aguardar a consulta com o especialista.  
O uso de metodologias não invasivas (biomarcadores, elastografia) para estadiamento da doença hepática não possuem validação e/ou recomendações para uso durante a gestação (11).  
Gestantes com HBsAg reagente no exame de triagem deverão complementar a avaliação com solicitação de HBeAg, ALT e CV-HBV, para determinar a indicação de tratamento, conforme os critérios de inclusão abaixo:  
- gestante com idade maior de 30 anos E com HBeAg reagente;  
- gestante com CV-HBV >2.000 UI/mL e ALT > 1x limite superior da normalidade (LSN)* mantida por 3 a 6 meses.  
**_*Considerar como LSN de ALT em mulheres para decisão de tratamento o ponto de corte de 19 U/L_**  
Caso seja verificada alguma indicação de tratamento, recomenda-se encaminhamento ao serviço especializado com urgência, visando à vinculação ao serviço e ao início oportuno do tratamento (1).  
Das opções terapêuticas disponíveis para HBV, o TDF é o único antiviral que tem seu uso recomendado na gestação.  
No caso de gestantes com infecção crônica pelo HBV e que já estejam em terapia antiviral, devese levar em consideração a gravidade da doença materna e o potencial risco/benefício para o feto. São elencadas algumas situações especiais:  
- **gestantes com fibrose hepática avançada (Metavir F3) ou com cirrose hepática (Metavir F4)** , e que já estejam em terapia antiviral, deverão continuar o tratamento com o TDF;  
- **mulheres que engravidem em uso de entecavir** deverão ter seu esquema substituído por TDF; e  
<!-- Start of picture text -->
% Conitec Sy . :<br><!-- End of picture text -->  
 **o uso de interferon está contraindicado durante a gestação** , seu uso deverá ser  
descontinuado e introduzir esquema oral com TDF.  
Estudos de reprodução foram realizados tanto em animais quanto em humanos com TDF e demonstraram não haver evidência de dano ao feto causado pelo uso da medicação. O TDF é o medicamento de preferência por ter melhor perfil de barreira genética à resistência e por ter sido mais amplamente estudado em mulheres gestantes portadoras de HBV (1,5,12). A preocupação sobre os efeitos do uso de TDF no desenvolvimento fetal pode ser reduzida pelo fato de, na quimioprofilaxia, este ser utilizado apenas no último trimestre da gestação, quando os estágios fetais de desenvolvimento estão quase completos.  
Para outras indicações de tratamento e mais informações sobre manejo da hepatite B, consultar o “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e coinfecções”, disponível em <u>http://www.aids.gov.br/biblioteca.</u>  
Mulheres que apresentam perfil sorológico **HBsAg e HBeAg reagentes** não necessitam exame de CV-HBV para determinar a profilaxia antiviral. Entende-se que, em razão desse perfil, essas gestantes já **apresentam níveis elevados de CV-HBV** , com incremento de risco de transmissão perinatal. **A terapia profilática com TDF no último trimestre da gestação está indicada.**  
No caso de gestantes que apresentarem **o perfil sorológico HBsAg reagente e HBeAg não reagente** , mesmo com valores de ALT dentro do LSN, a determinação dos níveis de CV-HBV deverá ser realizada imediatamente (avaliação inicial) e repetida ao final do segundo trimestre da gestação. A decisão sobre a terapia profilática deverá ser realizada entre a 28ª e a 32ª semana de gestação.  
Todas as gestantes com **hepatite B** que apresentem níveis de **CV-HBV superiores a 200.000 UI/mL** devem receber terapia profilática com **TDF 300mg uma vez ao dia VO,** a partir de **2832 semanas de gestação** (terceiro trimestre).  
Ressalta-se que esse fluxograma leva em consideração o cenário com início do pré-natal e identificação do estado sorológico quanto à hepatite B no primeiro trimestre de gestação, assim como acesso em tempo hábil ao resultado dos exames.  
<u>. :</u>  
Para gestantes que tenham comprovadamente HBsAg **reagente** e que iniciem tardiamente o pré-natal, ou que não tenham acesso ao resultado da CV-HBV em tempo hábil, será necessário considerar iniciar profilaxia com TDF enquanto se aguarda CV-HBV ou até o momento do parto.  
Pode-se considerar a antecipação do início do TDF profilático para o segundo trimestre de gestação, desde que respeitadas as indicações para quimioprofilaxia, na presença de: fatores de risco para trabalho de parto pré-termo, gestação múltipla (gemelar), necessidade de procedimentos fetais invasivos (por exemplo, amniocentese) ou HBV-DNA ≥ 10<sup>9</sup> UI/mL na primeira dosagem (13).  
Estudo randomizado com profilaxia com TDF sendo utilizado a partir do terceiro trimestre de gestação, em mulheres com HBsAg **reagente** e CV-HBV-DNA maior que 200.000 UI/mL, demonstrou que a taxa de TV na 28ª semana após o parto foi de 0% nas mulheres tratadas com TDF, em comparação a 7% de taxa de transmissão vertical no grupo placebo do protocolo, com perfil de segurança semelhante (12).  
Quanto à segurança da medicação para a gestante, há relatos de acidose láctica e esteatose hepática em pacientes que utilizaram esses antivirais, sendo fundamental monitorar as enzimas hepáticas durante o tratamento.  
A decisão quanto à **suspensão da profilaxia medicamentosa** será definida por especialista da rede de referência, preferencialmente entre 1 a 3 meses após o término da gestação.  Pode ser considerada a manutenção da quimioprofilaxia com TDF se houver planejamento de gestações futuras.  
Recomenda-se que gestantes com hepatite B crônica que não estão em uso terapêutico de antiviral ou que suspenderam a quimioprofilaxia com TDF sejam monitoradas com avaliação mensal de ALT nos primeiros 3 meses, depois no 6º mês; posteriormente manter seguimento de rotina. Tal atenção nos primeiros 6 meses após o parto deve-se ao risco de reativação **viral com exacerbação da doença hepática materna.**  
Após esse período de monitorização no puerpério, manter seguimento de adulto portador de hepatite B crônica, de acordo com as recomendações contidas no “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e coinfecções”, disponível em http://www.aids.gov.br/biblioteca.  
|Figura 15 - Fluxograma de prevenção de transm<br>*LNS para mulheres = 19 U/L<br>Testar HBsAg na primeira<br>consulta do pré-natal<br>(preferencialmente no<br>primeiro trimestre) e a<br>cada exposição de risco<br>Não Reagente<br>Checar histórico de<br>vacinação<br>Vacinar os suscetíveis,<br>considerar esquema<br>encurtado (0, 1 e 4m) em<br>gestantes com<br>vulnerabilidade<br>• Gestante com idade maior de 30<br>anos E com HBeAg reagente<br>OU<br>• Gestante com CV-HBV >2.000<br>UI/mL e ALT > 1x LSN* mantida<br>por 3 a 6 meses.<br>Iniciar**tratamento**com<br>TDF<br>Notificar Hep<br>Investigar cont<br>domiciliares e<br>sexuai<br>Solicitar: CV<br>HBeAG e ALT<br>com 24-28 se<br>|issão vertical de hepatite B<br>Reagente<br>Avaliar indicação de<br>tratamento ou de<br>quimioprofilaxia<br> <br>Gestante HBeAG<br>reagente e idade<br>menor que 30 anos<br>OU<br>Gestante CV-<br>HBV>**200.000 UI/mL****<br>Iniciar profilaxia com<br>TDF entre 28-32<br>semanas de gestação<br>RN expostos recebem<br>**vacina hepatite B e**<br>**IGHAHB**nas primeiras<br>12 horas<br>Monitorar flare no pós-<br>parto: ALT mensal nos<br>primeiros 3 meses e no<br>6º mês<br>Gestante HBeAg não<br>reagente<br>Gestante CV-<br>HBV<**200.000 UI/mL**<br>atite B<br>actantes<br>parcerias<br>s<br>-HBV,<br>e repetir<br>manas IG<br>~~=~~|
|---|---|  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
** Para gestantes que tenham comprovadamente HBsAg **reagente** e que iniciem tardiamente o pré-natal, ou que não tenham acesso ao resultado da CV-HBV em tempo hábil, será necessário considerar iniciar profilaxia com TDF enquanto se aguarda CV-HBV ou até o momento do parto.  
######  **Estratégias de concepção para parcerias sexuais sorodiferentes para HBV**  
A figura abaixo apresenta a conduta recomendada para parceria de pessoa vivendo com hepatite B. Para os parceiros sexuais (casuais ou estáveis) que são suscetíveis e não completaram seu esquema vacinal, métodos de barreira como prevenção devem ser utilizados.  
<!-- Start of picture text -->
X¥ Conitec Sy Les<br><!-- End of picture text -->  
Figura 16 - Fluxograma de conduta para parceria soronegativa para HBV  
<!-- Start of picture text -->
Ofertar teste rápido<br>para HBV<br>Teste rápido não<br>Teste rápido reagente<br>reagente<br>Informar sobre<br>possibilidade de Infecção  Checar histórico vacinal<br>pelo HBV<br>Conduta conforme PCDT<br>Hepatite B<br>esquema vacinal<br>não vacinou<br>completo*<br>Imunizar conforme<br>Dosar Anti-HBs<br>recomendação do PNI<br>30 - 60 dias após<br>antihbs - > 10 uI/mL -<br>esquema vacinal - antihbs - < 10 uI/mL<br>considerar imunizado<br>dosar Anti-HBs<br>Realizar "booster"<br>Antihbs - > 10 uI/mL Antihbs  < 10 uI/mL Considerar imunizado<br>vacinal<br>Recomendar esquema  30 - 60 dias após<br>Considerar imunizado de revacinação  "booster" - dosar novo<br>conforme PNI Anti-HBs<br>antihbs - > 10 uI/mL antihbs  < 10 uI/mL<br>Completar esquema de<br>Considerar imunizado revacinação conforme<br>PNI<br><!-- End of picture text -->  
*03 doses comprovadas em cartão vacinal  
. :  
Fonte:DCCI/SVS/MS.  
###### **5.5. Prevenção da transmissão vertical da hepatite B**  
###### **5.5.1. Transmissão Vertical do HBV**  
Crianças nascidas de mães infectadas pelo HBV e que são positivas tanto para HBsAg quanto para o HBeAg têm maior risco para aquisição da infecção – entre 40% e 90% –quando comparadas àquelas nascidas de mães HBsAg positivas, com HBeAg negativo (5% a 30% de chance de transmissão vertical) (14).  
A principal forma de TV da infecção pelo HBV é a perinatal, sendo a transmissão intrauterina mais rara. Os fatores de risco relacionados à **transmissão intrauterina** do HBV são:  
- presença de HBeAg reagente materno;  
- parto pré-termo laborioso; e  
- procedimentos obstétricos com manipulação de placenta.  
Ocasionalmente, a infecção da criança ocorre no período pós-natal pelo contato com adultos infectados pelo HBV, sendo essa forma de transmissão definida como horizontal.  
O risco de cronificação da infecção pelo HBV é inversamente relacionado à idade de aquisição, sendo 90% em RN 25 a 30% entre 1 a 5 anos de idade, e menor que 5% em adultos (15).  
A imunoprofilaxia combinada de IGHAHB e vacina no RN exposto previne a transmissão perinatal da hepatite B em mais de 90% dos RN.  
Logo após o nascimento, os **RNs de mulheres com HBV (HBsAg reagente) devem receber imunoglobulina humana anti-hepatite B (IGHAHB) e a primeira dose do esquema vacinal para HBV** . As demais doses serão feitas aos 2, 4 e 6 meses.  
**Vale ressaltar que todas as medidas para prevenção da TV-HBV também previnem a transmissão do vírus da hepatite Delta** (16).  
<!-- Start of picture text -->
X¥ Conitec Sy | to< {<br><!-- End of picture text -->  
######  **Parto**  
Uma vez que a maior frequência de TV do HBV ocorre no momento do parto, essa temática se reveste de grande importância. No entanto, a evidência é conflituosa quanto ao efeito do modo de parto na redução das taxas de TV.  
**Não há evidências concretas dos benefícios da realização de cesariana como medida preventiva da transmissão vertical de hepatite B** , sendo esse um tema ainda controverso na literatura (4,17). Esse procedimento não deve ser realizado como única indicação para PTV do vírus da hepatite B.  
######  **Amamentação**  
A amamentação não está contraindicada, ainda que não tenham sido realizadas ações para prevenção de TV-HBV (4,5).  
###### **5.6. Cuidados ao RN exposto à hepatite B (mãe HBsAg reagente)**  
Recomenda-se (18):  
- Proceder **com banho em água corrente ainda na sala de parto** , imediatamente após o nascimento. Quando isso não for possível, limpar com compressas macias todo o sangue e secreções visíveis no RN e proceder ao banho em água corrente logo em seguida.  
- Utilizar aspiração gástrica para a remoção de secreção infectada.  
- Aplicar a **vacina hepatite B** ainda na sala de parto ou, o mais tardar, nas primeiras 12 horas após o nascimento, na dose de 0,5mL no vasto lateral.  
- Administrar a **imunoglobulina humana anti-hepatite B (IGHAHB)** ao neonato ainda na sala de parto ou dentro das primeiras 12 a 24 horas de vida, para RN de qualquer peso ou idade gestacional, na dose de 0,5mL no vasto lateral do membro oposto ao da vacina da hepatite B.  
- Administrar concomitantemente a primeira dose da vacina e a IGHAHB em locais de aplicação diferentes; mais detalhes sobre o esquema podem ser encontrados no “Manual dos Centros de Referência para Imunobiológicos Especiais”, disponível em <u>http://www.saude.pr.gov.br/arquivos/File/-01VACINA/manual_crie_.pdf.</u>  
######  **Seguimento da criança exposta ao vírus da hepatite B**  
Na **ausência de informações sobre o estado imunológico da mãe** , recomenda-se administração de vacina de hepatite B imediatamente na sala de parto, coleta do HBsAg  
<u>is 5</u>  
materno e fornecimento de IGHAHB à criança confirmada como exposta dentro dos primeiros sete dias de vida (19).  
Para as crianças expostas ao HBV que não receberam seguimento adequado durante o período pós-natal, com vacina e IGHAHB, deverá ser realizada investigação quanto à infecção pelo HBV. Esse fluxo também necessita ser seguido por aquelas crianças expostas que chegam tardiamente ao serviço de saúde e para as quais não há registro da profilaxia para hepatite B após o nascimento.  
Recomenda-se que a pesquisa laboratorial (sorologia ou teste rápido) do HBsAg seja realizada após os 6 meses de idade e, no mínimo, após 30 dias da dose de vacina de hepatite B, haja vista que a vacina contra hepatite B possui antígeno de superfície recombinante, pode haver elevação transitória do HBsAg, sem significar infecção crônica (20–22).  
Recomenda-se que a avaliação da soroconversão da vacina de HBV deve ser realizada entre 9 e 12 meses de idade, após, pelo menos 30 dias da última dose, pois a IGHAHB consiste na imunização passiva com anti-Hbs para conferir a proteção transitória e este marcador sorológico de HBV pode ser detectado até 6 meses após administração da IGHAHB (10).  
Filhos de mães HBsAg reagente que receberam imunoglobulina humana anti-hepatite B (IGHAHB) devem realizar testagem para HBsAg e anti-HBs entre 9-12 meses de idade (ou 1 a 2 meses da última dose do esquema vacinal e com ≥9 meses de idade naqueles que forem vacinadas fora do prazo padrão).  
Em caso de não terem utilizado IGHAHB, recomenda-se que os testes para HBsAg e anti-HBs sejam realizados 1 a 2 meses da última dose vacinal.  
Para aquelas crianças nascidas de mães HBsAg reagente, mas que não utilizaram IGHAHB, a testagem para HBsAg e anti-HBs deve ser realizada 1 a 2 meses da última dose de vacina.  
Crianças nascidas de mães HBsAg reagente e que não se infectaram pelo HBV podem apresentar anti-HBc detectável por até 24 meses após o nascimento por aquisição passiva de anticorpos maternos (10).  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
Crianças com HBsAg **reagente** necessitam de avaliação complementar com dosagem de HBeAg, CV-HBV e dosagem sérica de ALT, além de ultrassonografia de abdome superior para avaliação hepática inicial.  
Para avaliação dos critérios de tratamento da criança com hepatite B, seguir as recomendações contidas no “Protocolo Clínico e Diretrizes Terapêuticas para Hepatite B e coinfecções”, disponível em http://www.aids.gov.br/biblioteca.  
<!-- Start of picture text -->
#% Conitec Sp hee<br><!-- End of picture text -->  
Figura 17- Fluxograma de seguimento da criança exposta ao HBV  
<!-- Start of picture text -->
RN exposto a HBV<br>|<br>Nas primeiras 12 horas:<br>vacina hepatite B E<br>IGHAHB<br>—<br>Recebeu vacina hepatite<br>B + IGHAHB Não recebeu vacina<br>hepatite B nem IGHAHB<br>ou<br>Recebeu somente a<br>vacina hepatite B<br>P ) LLL<br>Realizar HBsAg<br>Completar esquema<br>vacinal<br>oJ Le<br>Não reagente  Reagente<br>entre 9 e 12 meses de<br>idade*: dosar HBsAg e<br>anti-HBs<br>== CPD<br>Notificar<br>Realizar esquema vacinal Realizar:<br>se HBsAg reagente - CV-HBV-DNA<br>seguir fluxograma<br>HBeAg<br>AST/ALT<br>PY<br>após 30 dias término do<br>esquema vacinal: dosar<br>anti-HBs<br>anti-HBs - > 10 uI/mL -<br>considerar imunizado<br>ee<br>> 10 uI/mL - considerar<br>imunizado<br>anti-HBs <10 uI/mL -<br>revacinar conforme<br>orientação do PNI<br>PL<br><10 uI/mL - revacinar<br>conforme orientação do<br>PNI<br>—<br><!-- End of picture text -->  
| oo 5  
_*ou 1 a 2 meses da última dose de vacina E maior ou igual a 9 meses de idade, para quem iniciou esquema vacinal fora do prazo padrão._  
###### **5.7. Hepatite viral C**  
A infecção pelo HCV ocorre pela via parenteral, por meio da exposição ao sangue contaminado, por via sexual e por transmissão vertical, que é a principal via de transmissão em crianças infectadas pelo HCV (23).  
A infecção pelo HCV não é, por si só, impeditiva para o planejamento da gravidez. ~~<mark>PO</mark>~~ A gestante com HCV deve ter, no início do pré-natal, dosagens da CV-HCV e testes de função hepática, para avaliar risco de TV-HCV e estadiamento de doença hepática (15).  
Há evidências de que mulheres com HCV estão sob risco de piores desfechos maternos e neonatais, como diabetes gestacional, pré-eclâmpsia, restrição de crescimento, hemorragia préparto e parto pré-termo (6–8,24). A colestase intra-hepática é mais comum em mulheres com HCV-RNA positivo, chegando a taxas de 20%. Enquanto que, em alguns casos, pode haver uma queda dos níveis de transaminases durante o segundo e terceiro trimestres, mediada por fatores imunológicos característicos da gestação (15,25–27)  
Os **medicamentos utilizados para o tratamento da hepatite C aguda e crônica são teratogênicos** ou não possuem dados que comprovem segurança na gestação; por isso, são contraindicados durante esse período (Jhaveri _et al._ , 2018; Kushner e Terrault, 2019). Com os esquemas terapêuticos atuais, espera-se que as mulheres portadoras do HCV sejam tratadas antes de uma gestação planejada.  
**Se for confirmada a gestação durante o tratamento da hepatite C, este deverá ser suspenso** . Recomenda-se que mulheres em idade fértil em tratamento de hepatite C sejam submetidas a testes de gravidez com periodicidade e que utilizem contracepção de barreira. Após o tratamento, deve-se evitar gestação pelos próximos seis meses.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
Uma metanálise recente demonstrou uma taxa de TV de hepatite C de 5,8%, embora as taxas variem a depender de fatores geográficos, gravidade da doença e altos títulos de CV-HCV, comorbidades como a coinfecção com o HIV ou presença de monócitos infectados pelo HCV em sangue periférico (29).  
**É recomendada a realização da testagem para HCV (preferencialmente com teste rápido) em todas as gestantes na primeira consulta de pré-natal (preferencialmente no primeiro trimestre), em todas as gestações e nas mulheres em planejamento reprodutivo.**  
Recomenda-se a testagem para HCV universal para as gestantes, na primeira consulta de prénatal (preferencialmente no primeiro trimestre) com as seguintes justificativas:  diversos estudos demonstram que a testagem baseada em fatores de risco não é efetiva, notadamente durante a gestação; além disso, há pouca investigação ativa de tais práticas pelos profissionais de saúde; a gestação é um importante fator para a busca de serviços de saúde, sendo essa uma oportunidade única para testagem e diagnóstico; o conhecimento do estado sorológico favorece decisões clínicas que diminuem a exposição ou o risco de TV-HCV, como a realização de procedimentos invasivos desnecessários; por fim, o diagnóstico dessa gestante permite sinalizar quem são as crianças expostas ao HCV e, assim, incluir mulher e criança em um fluxo de seguimento (23,30–32).  
A análise das evidências que corroboram com a testagem universal para HCV no pré-natal se  
encontra no relatório da Conitec, disponível em <u>http://conitec.gov.br/images/Consultas/Relatorios/2020/Relatorio_Testagem_Universal_Hepa tite_C_Gestantes_final_545_32_2020.pdf (33).</u>  
Não há evidências científicas que recomendem uma via de parto preferencial com o propósito de prevenir a TV do HCV. Orienta-se evitar procedimentos invasivos, parto laborioso e tempo de ruptura de membranas maior que seis horas para minimizar a possibilidade de TV (15,23,27,34).  
Não há recomendações específicas em relação aos cuidados imediatos com o RN exposto ao HCV. Contudo, orienta-se proceder com banho em água corrente ainda na sala de parto, imediatamente após o nascimento. Quando isso não for possível, limpar com compressas macias todo o sangue e secreções visíveis no RN e proceder ao banho em água corrente logo em seguida; utilizar aspiração gástrica para a remoção de secreção infectada.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
O aleitamento materno não é contraindicado em mulheres portadoras do HCV e não há evidências de que o aleitamento favoreça TV do HCV, contudo, a presença de fissuras ou feridas sangrantes na mama contitui-se um meio de exposição ao lactente. Portanto, está recomendado que haja interrupção temporária de amamentação na mama lesionada, até cicatrização completa, manter ordenha e descarte do leite (32,35,36).  
A maioria das infecções crônicas pelo HCV na infância é assintomática e benigna. No entanto, o estágio precoce de infecção adquirida por transmissão vertical é caracterizado por uma ampla variação de anormalidade de ALT (32).  
São descritos três desfechos possíveis para a infecção pelo HCV adquirida verticalmente (37):  
- 20% a 40% dos RN irão negativar o vírus;  
- 50% dos RN desenvolverão infecção crônica assintomática (CV-HCV detectável intermitentemente e níveis normais de ALT);  
- 30% dos RN terão infecção crônica ativa com CV-HCV persistentemente detectável e ALT frequentemente anormal.  
Entre as crianças com infecção crônica, foi relatada progressão de fibrose hepática para cirrose em adolescentes, com curso mais rápido naquelas coinfectadas com HIV. Existem ainda casos mais raros de ocorrência de carcinoma hepatocelular que necessitaram de transplante hepático na adolescência. Além disso, existem na literatura descrições de manifestações extra-hepáticas nessa população, porém, elas são raras (Espinosa, Jhaveri e Barritt, 2018).  
Os anticorpos contra o vírus da hepatite C (anti-HCV) da classe IgG maternos podem atravessar passivamente a barreira placentária e serem detectados na criança até os 18 meses de idade, sem necessariamente indicar infecção. A manutenção dos níveis de IgG séricos após os 18 meses de idade, mesmo em títulos menores, é indicativa de que são produzidos pela própria criança, confirmando a infecção. Os anticorpos da classe IgM não atravessam a barreira placentária, e por isso, se forem detectados na corrente sanguínea do RN, indicam TV do vírus. Porém, pode ocorrer resultado falso-positivo, a partir de uma IgM pode ser heteróloga (não específica).  
O diagnóstico da infecção pelo HCV em indivíduos menores que 18 meses deve ser feito por teste molecular. A avaliação laboratorial precoce tem por objetivo a vinculação da criança exposta em um serviço para seguimento, além do estadiamento da doença hepática nos casos de infecção por HCV. Recomenda-se que o primeiro teste seja feito entre 03 e 06 meses de idade (38).  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
Dessa forma, podem-se considerar os dois cenários relacionados à primeira CV-HCV:  
- Crianças com CV-HCV detectável:  notificar o caso, inserir a criança no serviço especializado. Aos 18 meses de idade, realizar um teste para detecção do anti-HCV (imunoensaio ou teste rápido) e uma CV-HCV; a nova carga viral tem por objetivo avaliar os casos de clareamento espontâneo do vírus.  
- Crianças com CV-HCV não detectável: realizar um teste para a detecção do anti-HCV aos 18 meses de idade.  
Após a realização do anti-HCV, os seguintes cenários são possíveis:  
- crianças com anti-HCV não reagente e CV-HCV não detectável: descartar TV-HCV.  
- crianças com anti-HCV reagente e CV-HCV detectável: confirmam a infecção pelo vírus da hepatite C;  
- crianças anti-HCV reagente e CV-HCV não detectável (após os 18 meses) indicam contato passado e provável cura espontânea do vírus da hepatite C.  
<!-- Start of picture text -->
X¥ Conitec Sy Les<br><!-- End of picture text -->  
Figura 18 – Fluxograma de investigação laboratorial da criança exposta ao HCV  
<!-- Start of picture text -->
3-6 meses de idade:<br>Realizar teste molecular<br>(CV HCV-RNA)<br>CV HCV-RNA  CV HCV-RNA detectável<br>não detectável Notificar para HCV<br>Seguimento como criança  Seguimento como criança<br>exposta à hepatite C infectada por hepatite C<br>18 meses de idade:<br>18 meses de idade: Teste anti-HCV<br>Teste anti-HCV<br>(laboratorial ou TR) e<br>(laboratorial ou TR)<br>CV HCV-RNA<br>anti-HCV reagente   anti-HCV reagente e CV HCV-<br>realizar teste molecular  RNA não detectável:<br>CV HCV-RNA Clareamento espontâneo do<br>HCV<br>notificar para HCV<br>Seguimento como criança<br>com hepatite C<br>anti-HCV não reagente e<br>CV HCV-RNA não detectável:<br>anti-HCV  não<br>Descartar TV-HCV<br>reagente  <br>Descartada a infecção<br>pelo HCV<br>anti-HCV reagente e CV<br>HCV-RNA detectável:<br>Seguimento como<br>criança com hepatite C<br><!-- End of picture text -->  
###### Fonte: DCCI/SVS/MS  
A exposição do lactente a partir de uma mama lesionada com fluido contendo sangue constituise em uma potencial exposição de risco. Recomenda-se manter o seguimento laboratorial dessa criança exposta, conforme o exposto no Fluxograma 18.  
O seguimento nas crianças portadoras do HCV deve ser feito anualmente com enzimas hepáticas (AST, ALT, GGT, FA) e carga viral de HCV. Não há recomendação de exames radiológicos de rotina. Se houver alteração das enzimas hepáticas acima de 1,5 vezes o limite superior da  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
normalidade, recomenda-se tratamento após os 3 anos de idade nas crianças com genótipo 1 e após os 4 anos com genótipo 3 (32).  
######  **Estratégias de concepção para parcerias sexuais sorodiferentes para HCV**  
Estudos mostram que o risco de transmissão sexual em parcerias heterossexuais monogâmicas em que um dos parceiros é portador de HCV é muito baixo, com incidência máxima de transmissão sexual do HCV foi de 0,07% ao ano (39). Portanto, nesse cenário específico, o profissional de saúde pode discutir com o casal sobre o uso do preservativo, devendo ser uma decisão conjunta a relação sexual sem preservativo quando houver planejamento de engravidar.  
Deve-se reavaliar essa decisão e indicar o uso de preservativo caso haja sexo anal, múltiplas parcerias, coinfecção com HIV ou histórico atual de IST.  
A recomendação é que a mulher trate antes da concepção: atualmente, os tratamentos possuem alta taxa de cura, poucos efeitos colaterais, uma menor duração e eliminam o risco de transmissão vertical (40).  
Recomenda-se que a mulher aguarde 06 meses para engravidar após o término do tratamento.  
###### **Referências da Parte V - prevenção da transmissão vertical das hepatites virais**  
1. Ayoub W, Cohen E. Hepatitis B Management in the Pregnant Patient: An Update. J Clin Transl Hepatol. 2016;4(3):241–7.  
2. OMS. Medical eligibility criteria for contraceptive use - 5th edition. Med eligibility criteria Contracept use -- 5th ed [Internet]. 2015;(978 92 4 154915 8). Available from: http://apps.who.int/iris/bitstream/10665/181468/1/9789241549158_eng.pdf%0Ahttp: //icmer.org/documentos/anticoncepcion_de_emergencia/WHO 2015 Medical eligibility criteria for contraceptive use.pdf  
3. Söderström A, Norkrans G, Lindh M. Hepatitis B virus DNA during pregnancy and post partum: Aspects on vertical transmission. Scand J Infect Dis. 2003;35(11–12):814–9.  
4. Terrault NA, Bzowej NH, Chang KM, Hwang JP, Jonas MM, Murad MH. AASLD guidelines for treatment of chronic hepatitis B. Hepatology. 2016;63(1):261–83.  
5. EASL. EASL 2017 Clinical Practice Guidelines on the management of hepatitis B virus infection. J Hepatol. 2017;67(2):370–98.  
6. Connell LE, Salihu HM, Salemi JL, August EM, Weldeselasse H, Mbah AK. Maternal hepatitis B and hepatitis C carrier status and perinatal outcomes. Liver Int. 2011;31(8):1163–70.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
7. Safir A, Levy A, Sikuler E, Sheiner E. Maternal hepatitis B virus or hepatitis C virus carrier status as an independent risk factor for adverse perinatal outcome. Liver Int. 2010;30(5):765–70.  
8. Reddick KLB, Jhaveri R, Gandhi M, James AH, Swamy GK. Pregnancy outcomes associated with viral hepatitis. J Viral Hepat. 2011;18(7):394–8.  
9. OMS. Hepatitis B vaccines: WHO position paper – July 2017. Relev Epidemiol Hebd. 2017;92(27):369–92.  
10. Schillie S, Vellozzi C, Reingold A, Harris A, Haber P, Ward JW, et al. Prevention of hepatitis B virus infection in the United States: Recommendations of the advisory committee on immunization practices. MMWR Recomm Reports. 2018;67(1):1–31.  
11. Stenberg Ribeiro M, Hagström H, Stål P, Ajne G. Transient liver elastography in normal pregnancy–a longitudinal cohort study. Scand J Gastroenterol [Internet]. 2019;54(6):761–5. Available from: https://doi.org/10.1080/00365521.2019.1629007  
12. Pan CQ, Duan Z, Dai E, Zhang S, Han G, Wang Y, et al. Tenofovir to prevent hepatitis B transmission in mothers with high viral load. N Engl J Med. 2016;374(24):2324–34.  
13. Park JS, Pan CQ. Viral factors for HBV mother-to-child transmission. Hepatol Int. 2017;11(6):476–80.  
14. Keane E, Funk AL, Shimakawa Y. Systematic review with meta-analysis: the risk of mother-to-child transmission of hepatitis B virus infection in sub-Saharan Africa. Aliment Pharmacol Ther. 2016;44(10):1005–17.  
15. Chung RT, Ghany MG, Kim AY, Marks KM, Naggie S, Vargas HE, et al. Hepatitis C guidance 2018 update: Aasld-idsa recommendations for testing, managing, and treating Hepatitis C Virus infection. Clin Infect Dis. 2018;67(10):1477–92.  
16. Siqueira de Oliveira M, da Costa Negreiros do Valle S, Medeiros de Souza R, Paulo Martins Silva R, Níglio de Figueiredo E, Taminato M, et al. Evidências científicas sobre a hepatite Delta no Brasil: revisão integrativa da literatura Scientific evidence on hepatitis Delta in Brazil: integrative literature review. 2017;30(6):658–66. Available from: http://dx.doi.org/10.1590/1982-  
17. Pan CQ, Zou H Bin, Chen Y, Zhang X, Zhang H, Li J, et al. Cesarean section reduces perinatal transmission of hepatitis B virus infection from hepatitis b surface antigen-positive women to their infants. Clin Gastroenterol Hepatol [Internet]. 2013;11(10):1349–55. Available from: http://dx.doi.org/10.1016/j.cgh.2013.04.026  
18. Kimberlin David et al. Red Book: 2015 Report of the Committee on Infectious Diseases RED BOOK ® [Internet]. 2015. 230 p. Available from: https://redbook.solutions.aap.org/DocumentLibrary/Red Book 2015 1.pdf  
19. Brasil. Manual dos Centros de Referência para Imunobiológicos E speciais. 2014. 188 p.  
20. Ly D, Yee HF, Brezina M, Martin P, Gitnick G, Saab S. Hepatitis B surface antigenemia in chronic hemodialysis patients: Effect of hepatitis B immunization. Am J Gastroenterol.  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
2002;97(1):138–41.  
21. Bernstein et al. Incidence and duration of hepatitis B surface antigenemia after neonatal hepatitis B immunization. J Pediatr. 1994;125(4):621–2.  
22. Mohan D, Railey M, Al Rukhaimi M, Janzen L, Minuk GY, Fast M, et al. Vaccination and transient hepatitis B surface antigenemia. J Am Soc Nephrol. 2011;7(8):1–6.  
23. Kushner T, Terrault NA. Hepatitis C in Pregnancy: A Unique Opportunity to Improve the Hepatitis C Cascade of Care. Hepatol Commun. 2019;3(1):20–8.  
24. Huang QT, Huang Q, Zhong M, Wei SS, Luo W, Li F, et al. Chronic hepatitis C virus infection is associated with increased risk of preterm birth: A meta-analysis of observational studies. Vol. 22, Journal of Viral Hepatitis. 2015. p. 1033–42.  
25. Berkley EMF, Leslie KK, Arora S, Qualls C, Dunkelberg JC. Chronic hepatitis c in pregnancy. Obstet Gynecol. 2008;112(2):304–10.  
26. Locatelli A, Roncaglia N, Arreghini A, Bellini P, Vergani P, Ghidini A. Hepatitis C virus infection is associated with a higher incidence of cholestasis of pregnancy. BJOG An Int J Obstet Gynaecol. 1999;106(5):498–500.  
27. Prasad MR, Honegger JR. Hepatitis C virus in pregnancy. Am J Perinatol. 2013;30(2):149– 59.  
28. Jhaveri R, Broder T, Bhattacharya D, Peters MG, Kim AY, Jonas MM. Universal screening of pregnant women for Hepatitis C: The time is now. Clin Infect Dis. 2018;67(10):1493– 7.  
29. Benova L, Mohamoud YA, Calvert C, Abu-Raddad LJ. Vertical transmission of hepatitis C virus: Systematic review and meta-analysis. Clin Infect Dis. 2014;59(6):765–73.  
30. Akhtar F, Rehman S. A Public Health Analysis on Gaps in Disease Monitoring and Opportunities for Improved Care for the Management of Hepatitis B and C. Cureus. 2018;10(1):1–10.  
31. Barros MM de O, Ronchini KRO de M, Soares RLS. Hepatitis B and C in pregnant women attended by a prenatal program in an universitary hospital in Rio de Janeiro, Brazil: Retrospective study of seroprevalence screening. Arq Gastroenterol. 2018;55(3):267–73.  
32. Espinosa C, Jhaveri R, Barritt AS. Unique Challenges of Hepatitis C in Infants, Children, and Adolescents. Clin Ther [Internet]. 2018;40(8):1299–307. Available from: https://doi.org/10.1016/j.clinthera.2018.07.010  
33. Brasil. Testagem universal para hepatite viral C em gestantes no pré-natal: Relatório de recomendação da Conitec. Disponível em: http://conitec.gov.br/images/Consultas/Relatorios/2020/Relatorio_Testagem_Universa l_Hepatite_C_Gestantes_final_545_32_2020.pdf  
34. Hughes BL, Page CM, Kuller JA. Hepatitis C in pregnancy: screening, treatment, and management. Am J Obstet Gynecol [Internet]. 2017;217(5):B2–12. Available from:  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
https://doi.org/10.1016/j.ajog.2017.07.039  
35. Aebi-Popp K, Duppenthaler A, Rauch A, De Gottardi A, Kahlert C. Vertical transmission of hepatitis C: towards universal antenatal screening in the era of new direct acting antivirals (DAAs)? Short review and analysis of the situation in Switzerland. J virus Erad [Internet]. 2016;2(1):52–4. Available from: http://www.ncbi.nlm.nih.gov/pubmed/27482435%0Ahttp://www.pubmedcentral.nih.g ov/articlerender.fcgi?artid=PMC4946698  
36. Garcia-Loygorri MC, Deluis D, Torreblanca B, March GA, Bachiller MR, Eiros JM. La leche materna como vehículo de transmisión de virus. Nutr Hosp. 2015;32(1):4–10.  
37. Tovo PA, Calitri C, Scolfaro C, Gabiano C, Garazzino S. Vertically acquired hepatitis C virus infection: Correlates of transmission and disease progression. World J Gastroenterol. 2016;22(4):1382–92.  
38. BRASIL. Diagnóstico das hepatites virais. Ministério da Saúde. 2018;2.  
39. Dodge JL, Terrault NA. Sexual transmission of hepatitis C: A rare event among heterosexual couples. J Coagul Disord. 2014;4(1):38–9.  
40. BRASIL. Hepatite C e coinfecções. Minist Da Saude. 2017;1.  
**APÊNDICE 1- METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**  
<!-- Start of picture text -->
£% Conitec > a is 5<br><!-- End of picture text -->  
**METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA**  
###### **1.  Escopo e finalidade da Diretriz**  
Após o levantamento das atualizações das evidências referentes à prevenção da transmissão vertical do HIV, sífilis e hepatites virais, foi realizada uma reunião do grupo de especialistas externos no tema, no dia 05 de junho de 2019. Dessa reunião, duas mudanças de recomendação foram deliberadas: incorporação do dolutegravir como antirretroviral de escolha para tratamento de gestantes vivendo com HIV a partir da 13ª semana de gestação; e testagem universal para hepatite C para todas as gestantes durante o pré-natal. Ambas as recomendações foram avaliadas individualmente e aprovadas pela Conitec. Os relatórios de recomendação estão disponíveis em:  
1. <u>http://conitec.gov.br/images/Relatorios/2020/Relatorio_Dolutegravir_Gestante_HIV_ 515_2020_FINAL.pdf</u>  
2. <u>http://conitec.gov.br/images/Consultas/Relatorios/2020/Relatorio_Testagem_Univers al_Hepatite_C_Gestantes_final_545_32_2020.pdf</u>  
Após as aprovações de cada uma das recomendações, o documento inteiro do Protocolo Clínico e Diretrizes Terapêuticas para prevenção da transmissão vertical do HIV, sífilis e hepatites virais foi atualizado, de forma a incorporar as duas mudanças.  
###### **2. Equipe de elaboração e partes interessadas**  
O Protocolo foi atualizado pelo Departamento de Doenças de Condições Crônicas e Infecções Sexualmente Transmissíveis (DCCI/SVS) com a revisão externa de especialistas da área.  
**Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas**  
<!-- Start of picture text -->
% Conitec Sy . .<br><!-- End of picture text -->  
O texto do PCDT foi avaliado pela Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas em 14 de julho de 2020. Estiveram presentes, além da equipe da Coordenação de Gestão de Protocolos Clínicos e Diretrizes Terapêuticas (CPCDT/DGITIS) e da Secretaria de Vigilância em Saúde (SVS), membros das seguintes áreas: Departamento de Assistência Farmacêutica (DAF), Departamento de Ciência e Tecnologia (DECIT), Departamento de Atenção Especializada e Temática (DAET) e Secretaria de Atenção Especializada à Saúde (SAES). O texto foi aprovado pela subcomissão técnica para avaliação da Conitec.  
###### **Busca da evidência**  
Considerando a versão vigente do PCDT para prevenção da transmissão vertical do HIV, sífilis e hepatites virais, partiu-se deste documento de base, o qual manteve a estrutura de metodologia, acrescentando dados referentes à atualização das tecnologias recomendadas, conforme relatório da Conitec, diretrizes internacionais e referências contidas no documento ao final de cada uma das cinco partes do PCDT.

---

