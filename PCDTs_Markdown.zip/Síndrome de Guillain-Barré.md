<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: Geral -->
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 15, DE 13 DE OUTUBRO DE 2020.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Guillain-Barré.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas  atribuições,  
Considerando a necessidade de se atualizarem parâmetros sobre a síndrome de Guillain-Barré no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 547/2020 e o Relatório de Recomendação n<sup><u>o</u></sup> 553 – Setembro de 2020 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – da Síndrome de Guillain-Barré.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da síndrome de Guillain-Barré, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio http://portalms.saude.gov.br/protocolos-e-diretrizes, é de caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da síndrome de Guillain-Barré.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.171/SAS/MS, de 19 de novembro de 2015, publicada no Diário Oficial da União nº 222, de 20 de novembro de 2015, seção 1, página 83.  
LUIZ OTAVIO FRANCO DUARTE

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **1. INTRODUÇÃO** -->
A Síndrome de Guillain-Barré (SGB), também conhecida como polirradiculoneurite aguda, é a maior causa de paralisia flácida generalizada no mundo<sup>1, 2,</sup> com incidência anual de 0,81 a 1,89 casos por 100.000 habitantes, acometendo principalmente a população entre 20 e 40 anos de idade, de ambos os sexos. Em situações normais, a maioria dos casos ocorre de maneira esporádica e parece não apresentar sazonalidade<sup>1, 2</sup> .  
No Brasil há escassez de dados sistematizados sobre a SGB. Durante a flavirose pelo vírus Zika, em 2015, com aumento de incidência de SGB, aventou-se a possibilidade de relação direta entre essas duas condiçõese e estimulou-se melhor coleta de informações epidemiológicas<sup>3</sup> . Durante o período do surto epidêmico, de março a agosto de 2015, a incidência geral de SGB e outras manifestações neurológicas foi de 4,4 casos por 100 mil habitantes na Bahia, sendo de 4,2 por 100 mil habitantes em Salvador. A incidência de SGB e outras manifestações neurológicas foi de 5,0/100 mil habitantes entre os homens, e de 3,8/100 mil habitantes entre as mulheres, com mediana de idade geral de 44 anos (intervalo interquartil de 1 e 3: 31-59 anos - amplitude: 2-83 anos)<sup>4</sup> .  
A SGB é uma doença de caráter autoimune que acomete primordialmente a mielina da porção proximal dos nervos periféricos de forma aguda/subaguda. Aproximadamente 60% a 70% dos pacientes com SGB apresentam alguma doença aguda precedente (1 a 3 semanas antes)<sup>5, 6</sup> , sendo a infecção por _Campylobacter jejuni_ a mais frequente (32%), seguida por citomegalovírus (13%), vírus Epstein Barr (10%) e outras infecções virais, tais como hepatite por vírus tipo A, B e C, influenza e vírus da imunodeficiência humana (HIV)<sup>7, 8</sup> . Outros fatores precipitantes de menor importância são cirurgia, imunização e gravidez<sup>9, 10.</sup>  
A maioria dos pacientes percebe inicialmente a doença pela sensação de parestesias nas extremidades distais dos membros inferiores e, em seguida, superiores. Dor neuropática lombar ou nas pernas pode ser vista em pelo menos 50% dos casos<sup>11</sup> . Fraqueza progressiva é o sinal mais perceptível ao paciente, ocorrendo geralmente nesta ordem: membros inferiores, braços, tronco, cabeça e pescoço. A intensidade pode variar desde fraqueza leve, que sequer motiva a busca por atendimento médico em nível primário<sup>12</sup> , até ocorrência de tetraplegia completa com necessidade de ventilação mecânica (VM) por paralisia de musculatura respiratória acessória. Fraqueza facial ocorre na metade dos pacientes ao longo do curso da doença. Entre 5%-15% dos pacientes desenvolvem oftalmoparesia e ptose. A função esfincteriana é, na maioria das vezes, preservada, enquanto a perda dos reflexos miotáticos pode preceder os sintomas sensitivos até mesmo em músculos pouco afetados. Instabilidade autonômica é um achado comum, causando eventualmente arritmias importantes<sup>7, 8</sup> , mas que raramente persistem após duas semanas<sup>8,10.</sup>  
A síndrome usualmente progride por 2 a 4 semanas. Pelo menos 50% a 75% dos pacientes atingem seu nadir (pico de piora) na segunda semana, 80% a 92% até a terceira semana e 90% a 94% até a quarta semana<sup>8, 13</sup> . Insuficiência respiratória com necessidade de VM ocorre em até 30% dos pacientes nessa fase. Progressão de sinais e sintomas por mais de 8 semanas exclui o diagnóstico de SGB, sugerindo então uma polineuropatia inflamatória desmielinizante crônica (PIDC). Passada a fase da progressão, a doença entra em platô por vários dias ou semanas, com subsequente recuperação gradual da função motora ao longo de vários meses. Entretanto, apenas 15% dos pacientes ficarão sem nenhum déficit residual após 2 anos do início da doença e 5% a 10% permanecerão com sintomas motores ou sensitivos incapacitantes. A mortalidade nos pacientes com SGB é de aproximadamente 5% a 7%, geralmente resultante de insuficiência respiratória, pneumonia aspirativa, embolia pulmonar, arritmias cardíacas e sepse hospitalar<sup>8, 14.</sup>  
Os fatores de risco para um mau prognóstico funcional são idade acima dos 50 anos, diarreia precedente, início abrupto de fraqueza grave (menos de 7 dias), necessidade de VM e amplitude do potencial da neurocondução motora menor que 20% do limite normal<sup>9, 16, 17.</sup> O prognóstico motor é melhor nas crianças, pois necessitam menos de suporte ventilatório e recuperam-se com maior rapidez<sup>8</sup> . Recorrência do episódio pode ocorrer em até 3% dos casos, não havendo relação com a forma de tratamento utilizada na fase aguda, conforme se acredi <mark>tava</mark><sup>15</sup> <mark>.</mark>  
O tratamento específico da SGB visa primordialmente a acelerar o processo de recuperação, diminuindo as complicações associadas à fase aguda e reduzindo os déficits neurológicos residuais em longo prazo<sup>9</sup> , e inclui o uso de plasmaférese e imunoglobulina humana intravenosa (IgIV).  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Básica um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da Síndrome de Guillain-Barré. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- G61.0 Síndrome de Guillain-Barré

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3. DIAGNÓSTICO** -->
O diagnóstico da SGB é primariamente clínico. No entanto, exames complementares são necessários para confirmar a hipótese diagnóstica e excluir outras causas de paresia flácida.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.1 Diagnóstico Clínico** -->
Os pacientes com SGB geralmente apresentam fraqueza muscular em mais de um segmento apendicular de forma simétrica, incluindo musculatura craniana. Os reflexos miotáticos distais usualmente estão reduzidos ou ausentes. A progressão dos sinais e sintomas é de suma importância, não podendo ultrapassar 8 semanas e com recuperação iniciando 2-4 semanas após fase de platô<sup>16</sup> . Febre e disfunção sensitiva são achados pouco frequentes, devendo levantar suspeita de uma etiologia alternativa, de causa provavelmente infecciosa.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.2. Diagnóstico Laboratorial** -->
Análise do líquido cefalorraquiano (LCR): elevação da proteína no líquor acompanhada por poucas células mononucleares é o achado laboratorial característico, evidente em até 80% dos pacientes após a segunda semana. Entretanto, na primeira semana, a proteína no LCR pode ser normal em até 1/3 dos pacientes. Caso o número de linfócitos no líquor exceda 10 células/mm<sup>3</sup> , deve-se suspeitar de outras causas de polineuropatia, tais como sarcoidose, doença de Lyme ou infecção pelo HIV<sup>17</sup> .  
Diagnóstico eletroneuromiográfico (ENMG): a análise das neuroconduções nervosas e a eletromiografia por agulha são as ferramentas da ENMG utilizadas para confirmar o diagnóstico de SGB e fornecer algumas informações sobre o prognóstico. A ENMG permite classificar as principais formas de apresentação da SGB diferenciando as formas de acometimento desmielinizante das formas axonais do nervo periférico<sup>18</sup> .  
As formas desmielinizantes da SGB são acompanhadas de achados pela ENMG como: velocidades de condução motora reduzidas, prolongamento das latências motoras distais das neuroconduções, sinais de bloqueio da condução nervosa motora  
com dispersão temporal da onda em análise e também latências de ondas F prolongadas. As formas de apresentação axonal, muitas vezes, são evidenciadas pela diminuição das amplitudes sensitivas e motoras.  
Como a SGB é um processo dinâmico com taxa de progressão variável<sup>16</sup> , estudos seriados de ENMG são frequentemente úteis.  É importante salientar que a presença de achados na ENMG de normalidade no início do curso da doença não exclui a hipótese de SGB, visto que as alterações na ENMG são tipicamente mais pronunciadas aproximadamente 2 semanas após a instalação da fraqueza. No entanto, a exploração eletrofisiológica faz-se necessária para a exclusão de outras doenças neuromusculares causadoras de paralisia flácida aguda.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.3. Critérios Diagnósticos** -->
Existem vários critérios propostos para a definição clara do diagnóstico de SGB, sendo exigidos todos os especificados abaixo<sup>2,19</sup> :  
- a) Presença de dois critérios essenciais (conforme a seguir);  
- b) Presença de pelo menos três critérios clínicos sugestivos (conforme a seguir);  
- c) Ausência de mais de uma situação que reduza a possibilidade de SGB;  
- d) Ausência de situação que exclua o diagnóstico de SGB;  
- e) Análise do LCR;  
- f) ENMG compatível com a doença e investigação adicional criteriosa com intuito de afastar outras etiologias. Nessas  
- situações, deve ser avaliado por consultor médico especialista em doenças neuromusculares.  
Cabe salientar que o diagnóstico da SGB é essencialmente clínico e norteado pela presença dos critérios essenciais e sugestivos e que permitem o início do tratamento com as medidas de suporte e também as terapias modificadoras da doença, acelerando a recuperação do doentes<sup>20</sup> .  
A seguir, relacionam-se os critérios essenciais, que sugerem, reduzem ou excluem o diagnóstico da SGB, bem como uma escala de gravidade ( **Quadro 1** ) da SGB<sup>13</sup> .

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.3.1.  Critérios essenciais para o diagnóstico da SGB** -->
a) Fraqueza progressiva de mais de um membro ou de músculos cranianos de graus variáveis, desde paresia leve até  
plegia;  
b) Hiporreflexia e arreflexia distal com graus variáveis de hiporreflexia proximal.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.3.2.  Critérios sugestivos da SGB** -->
_Clínicos:_  
- a) Progressão dos sintomas ao longo de 4 semanas;  
- b) demonstração de relativa simetria da paresia de membros;  
- c) sinais sensitivos leves a moderados;  
- d) acometimento de nervos cranianos, especialmente expresso por fraqueza bilateral dos músculos faciais;  
- e) dor;  
- f) disfunção autonômica;  
- g) ausência de febre no início do quadro.  
_Análise do LCR:_  
a) Alta concentração de proteína;  
b) Presença de menos de 10 células/mm<sup>3</sup> .

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: _Estudo ENMG típico_<sup>_2_</sup> _:_ -->
São necessários três dos quatro critérios abaixo (geralmente ausentes antes de 5-7 dias, podendo não revelar anormalidades em até 15%-20% dos casos, após esse período):  
a) Redução da velocidade de condução motora em dois ou mais nervos;  
b) bloqueio de condução do potencial de ação motor composto ou dispersão temporal anormal em um ou mais nervos;  
c) prolongamento da latência motora distal em dois ou mais nervos;  
d) prolongamento de latência da Onda-F ou ausência dessa onda.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.3.3.  Critérios que reduzem a possibilidade da SGB** -->
a) Fraqueza assimétrica;  
b) disfunção intestinal e de bexiga no início do quadro;  
c) ausência de resolução de sintomas intestinais ou urinários;  
d) presença de mais de 50 células/mm3 na análise do LCR;  
e) presença de células polimorfonucleares no LCR;  
f) nível sensitivo bem demarcado.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.3.4.  Critérios que excluem a possibilidade da SGB** -->
a) História de exposição a hexacarbono, presente em solventes, tintas, pesticidas ou metais pesados;  
- b) achados sugestivos de metabolismo anormal da porfirina;  
- c) história recente de difteria;  
d) suspeita de intoxicação por chumbo (ou outros metais pesados).  
- e) síndrome sensitiva pura (ausência de sinais motores).  
f) diagnóstico de botulismo, miastenia gravis, poliomielite, neuropatia tóxica, paralisia periódica ou paralisia conversiva.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3.4. Diagnóstico Diferencial** -->
A SGB é uma das causas mais frequentes de polineuropatia aguda vista nos  hospitais gerais<sup>(21)</sup> . Entretanto, várias outras condições neurológicas devem ser distinguidas da SGB. O dilema imediato é diferenciar SGB de uma doença medular aguda. Confusão pode ocorrer nas lesões medulares agudas em que os reflexos são inicialmente abolidos (choque espinhal). Nessas situações, outros sinais devem ser buscados. A ausência de nível sensitivo bem definido ao exame físico neurológico, o acometimento da musculatura facial e respiratória acessória e o padrão parestésico em bota e luva relatado espontaneamente pelo paciente, com relativa preservação da sensibilidade distal, falam a favor da SGB. Perda do controle esfincteriano, disfunção autonômica e dor lombar podem ocorrer em ambos os casos, embora predominem nas mielopatias. Paralisia predominantemente motora é também característica da poliomielite ou de outras mielites infecciosas. Febre, sinais meníngeos, pleocitose liquórica e distribuição assimétrica da fraqueza costumam coexistir nesses casos<sup>22</sup> .  
Outras causas importantes de polineuropatia aguda que devem sempre ser incluídas no diagnóstico diferencial da SGB são: infecciosas (HIV, doença de Lyme, difteria), paraneoplásicas (principalmente carcinoma brônquico de pulmão), autoimunes (doenças do colágeno, vasculites primárias), tóxicas (história exposicional a amiodarona, cloroquina, organofosforados e metais pesados, entre outros agentes) e metabólicas (porfiria). A polineuropatia crônica deve ser diferenciada da SGB pelo seu tempo de progressão motora superior a 8 semanas.  
Ptose e fraqueza motora ocular podem causar confusão com miastenia gravis. No entanto, nessa situação, não há padrão ascendente de perda de força e os reflexos miotáticos são usualmente preservados<sup>23</sup> .  
Por fim, nos pacientes criticamente enfermos, uma variedade de distúrbios neuromusculares (polineuromiopatia) podem existir e devem ser distinguidos da SGB. Estes incluem polineuropatia ou miopatia do paciente crítico, neuropatia rapidamente progressiva nos pacientes com insuficiência renal em diálise peritoneal, hipofosfatemia aguda induzida por hiperalimentação, miopatia por corticoide e efeitos prolongados de bloqueadores musculares. Nesses casos, o estudo ENMG e do líquor é de grande auxílio na definição de doença desmielinizante.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo todos os pacientes que:  
- preencherem os critérios diagnósticos do item 3, incluindo as formas variantes da SGB, avaliados por médico,  
- preferencialmente especialista em neurologia, com expedição de laudo detalhado; e  
- apresentarem doença moderada-grave (Escala de Incapacidade) e menos de 8 semanas de evolução.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos deste Protocolo os pacientes com mais de 8 semanas de evolução da doença, com insuficiência renal ou que apresentarem contraindicações ou efeitos adversos não toleráveis à IgIV.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **6. CASOS ESPECIAIS** -->
**SGB em crianças** : os achados clínicos, laboratoriais e eletrofisiológicos em crianças com SGB são similares aos encontrados em adultos. No entanto, na população pediátrica, a prevalência de infecção precedente é de 75% e a queixa principal mais frequente é a dor. A maioria das crianças com SGB tem recuperação satisfatória, mesmo com redução significativa da amplitude do potencial de neurocondução motora<sup>24</sup> .  
**Neuropatia axonal sensitivo-motora aguda (NASMA)** : primeiramente descrita como uma variante axonal da SGB<sup>11</sup> , do ponto de vista clínico e eletrofisiológico inicial é indistinguível da SGB. Da mesma forma que a SGB, a doença inicia com anormalidades sensitivas subjetivas nas extremidades e evolução mais rápida (poucos dias) da fraqueza generalizada, sendo necessária a VM para a maioria dos pacientes. O prognóstico da NASMA é pior do que o da SGB e a maioria dos casos exibe recuperação motora lenta e incompleta<sup>(25)</sup> . Em adição ao padrão liquórico usual de hiperproteinorraquia sem pleocitose, também visto nos pacientes com SGB, há evidência de infecção recente por _Campylobacter jejuni_ e presença de anticorpos antigangliosídeos, particularmente anti-GM1. Embora não existam ensaios clínicos randomizados e controlados específicos para essa variante, e devido à impossibilidade de diferenciação clínica (e eletrofisiológica, pelo menos na fase inicial) entre NASMA e SGB, ambas as situações são tratadas de forma semelhante<sup>13.</sup>  
**Neuropatia axonal motora aguda (NAMA)** : outra variante axonal da SGB, caracterizada por início abrupto de fraqueza generalizada, com músculos distais mais gravemente afetados que os proximais. _Deficit_ de nervos cranianos e insuficiência respiratória exigindo VM estão presentes em 33% dos casos. Ao contrário da SGB e da NASMA, sintomas sensitivos estão ausentes e os reflexos tendinosos podem ser normais. Anticorpos anti-GM1 e anti-GD1 são comumente detectados, em geral associados com infecção recente por _Campylobacter jejuni_<sup>18, 26</sup> .  Os pacientes com NAMA costumam apresentar boa recuperação  
dentro do primeiro ano, mas fraqueza distal residual é comum. Não existem ensaios clínicos específicos avaliando a eficácia da imunoglobulina ou da plasmaférese para NAMA. No entanto, é provável que essa entidade esteja incluída em alguns ensaios para SGB comparando essas duas modalidades terapêuticas, como evidenciado posteriormente na análise criteriosa dos pacientes selecionados para o estudo do _Dutch GBS Trial_<sup>27</sup> . Nesse estudo, 18% dos pacientes inicialmente identificados como portadores de SGB, apresentavam na realidade NAMA, havendo recuperação mais rápida com a administração de imunoglobulina isolada, sendo, portanto, uma prática justificada nesses casos.  
**Síndrome de Miller-Fisher:** é uma variante de SGB, caracterizada pela tríade ataxia, arreflexia a oftalmoplegia. Paresia de outros nervos cranianos, especialmente do sétimo, pode ocorrer. Fraqueza apendicular proximal pode ser demonstrada ao longo do curso da doença em aproximadamente 1/3 dos casos, podendo haver progressão para fraqueza generalizada mais grave de forma semelhante à SGB<sup>11</sup> . Em termos de achados eletrofisiológicos, diferente das outras variantes da SGB, a anormalidade mais frequente é a redução das amplitudes do potencial de neurocondução sensitiva fora de proporção ao prolongamento das latências distais ou lentificação das velocidades de condução sensitiva<sup>28</sup> .  A recuperação, em geral, se dá após 2 semanas do início dos sintomas, com evolução favorável após 3 a 5 meses. Da mesma forma que nas outras variantes da SGB, há evidência sorológica de infecção recente por _Campylobacter jejuni_ , bem como presença de anticorpos antigangliosídeo, particularmente antiGQ1b<sup>29</sup> . Embora a síndrome de Miller-Fischer seja autolimitada<sup>29</sup> , alguns pacientes podem evoluir para insuficiência respiratória<sup>30</sup> . Assim, parece prudente tratar os pacientes com imunoglobulina ou plasmaférese<sup>11</sup> , desde que respeitadas as condições do item critérios de inclusão.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7. TRATAMENTO** -->
Existem dois tipos de tratamento na SGB: a) a antecipação e o controle das comorbidades associadas; b) tratamento modificador da doença, visando a um menor tempo de recuperação e minimização de déficits motores. Não há necessidade de tratamento de manutenção, fora da fase aguda da doença.  
Assim, pacientes com SGB necessitam ser inicialmente admitidos no hospital para observação rigorosa. O cuidado para eles é mais bem encontrado em centros terciários, com facilidades de cuidados intensivos e uma equipe de profissionais que esteja familiarizada com as necessidades especiais dos pacientes com SGB<sup>14</sup> . Vigilância estrita e antecipação das potenciais complicações são necessárias para a otimização das chances de um desfecho favorável. As áreas de atenção incluem prevenção de fenômenos tromboembólicos, monitorização cardíaca, avaliações seriadas de reserva ventilatória e de fraqueza orofaríngea, proteção de vias aéreas, manutenção da função intestinal, controle apropriado da dor e nutrição e suporte psicológico adequados. A fisioterapia motora deve ser iniciada nesta fase com intuito de auxiliar na mobilização precoce<sup>31</sup> .  
Para a correta indicação do tratamento, faz-se necessária a determinação da gravidade clínica proposta por Hughes _et al._<sup>32</sup> , sendo considerada doença leve de 0 a 2 e moderada-grave de 3 a 6 ( **Quadro 1** ).  
**Quadro 1 -** Escala de gravidade clínica proposta por Hughes _et al._<sup>32</sup>  
|0|Saudável|
|---|---|
|1|Sinais e sintomas menores de neuropatia, mas capaz de realizar tarefas manuais|
|2|Apto a caminhar sem auxílio da bengala, mas incapaz de realizar tarefas manuais|
|3|Capaz de caminhar somente com bengala ou suporte|  
|4<br>Confinado a cama ou cadeira de rodas|
|---|  
|5<br>Necessita de ventilação assistida|
|---|  
|6<br>Morte|
|---|  
O Escore Prognóstico para SGB de Erasmus (EGOS)<sup>33</sup> é um modelo prognóstico que se baseia em dados clínicoepidemiológicos para prever a probabilidade de um paciente com SGB estar caminhando sem auxílio em 6 meses ( **Quadro 2** ). Pacientes com escore igual a 4 após duas semanas do início do quadro tem 7% de risco de não caminharem independentemente em 6 meses. Esse risco aumenta para 27% com escore de 5 e para 52% com escore maior que 5. Esses dados devem também ser considerados para decisão sobre instituição de tratamentos modificadores de doença.  
**Quadro 2** - Escore de Desfecho para Síndrome de Guillain-Barré de Erasmus (EGOS)  
||CATEGORIA|ESCORE|
|---|---|---|
|Idade no início|>60 anos|1|
||41-60 anos|0,5|
||40 anos ou menos|0|
|Diarreia (<4 semanas do início)|Ausente|0|
||Presente|1|
|Escore de gravidade clínica (com 2 semanas)|0 ou 1|1|
||2|2|
||3|3|
||4|4|
||5|5|
|Escore Prognóstico (EGOS)||1 - 7|  
Os tratamentos modificadores de doença preconizados na SGB incluem um tratamento não medicamentoso (plasmaférese) e um medicamentoso (imunoglobulina humana endovenosa). Não se observam diferenças significativas na resposta a essas duas formas de tratamento<sup>34</sup> .

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **Plasmaférese** -->
A plasmaférese consiste na separação do plasma e células sanguíneas, sendo que essas últimas são reinfundidas após diluição em albumina diluída com gelatina ou plasma fresco. Seu uso na SGB se baseia na remoção de anticorpos, complemento e outros fatores responsáveis por lesão nervosa.  
O efeito da plasmaférese foi avaliado em uma revisão sistemática da Cochrane que concluiu que a plasmaférese aumenta a probabilidade dos pacientes deambularem de forma independente em 4 semanas, diminuiu o tempo de VM, risco de infecções graves, instabilidade cardiovascular e arritmias cardíacas em relação ao tratamento de suporte<sup>35</sup> .  
Cada sessão de plasmaférese remove de uma a uma e meia volemia de plasma, com intervalo de 48 horas entre sessões. Pacientes incapazes de ficarem em pé sem auxílio (escala de gravidade de Hughes >3) devem receber quatro sessões enquanto pacientes com acometimento leve (escala de gravidade de Hughes menor ou igual a 3) podem se beneficiar de duas sessões<sup>36</sup> .  
O papel da plasmaférese em crianças menores de 12 anos de idade e após 30 dias do início dos sintomas permanece incerto<sup>9, 37, 38</sup> , logo, a critério médico, pode ser indicada.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7.2. Tratamento medicamentoso** -->
A Imunoglobulina humana (IgIV), pela facilidade de uso, tornou-se o tratamento de escolha na maioria dos países,  
apesar de seu mecanismo de ação pouco compreendido<sup>31</sup> . Sua eficácia na recuperação motora, risco de morte e efeitos adversos comparada a tratamento com plasmaférese mostrou que os resultados dentro de duas semanas são semelhantes<sup>34</sup> .  
A dose preconizada de IgIV na SGB é de 2 g/Kg dividida em 2 a 5 dias<sup>39</sup> . A maior dose diária pode aumentar o risco de complicações renais ou vasculares, especialmente em pacientes idosos.  
Glicocorticoides estão contraindicados no tratamento da SGB.<sup>32,40</sup> , assim como poliglicosídeo<sup>41</sup> , a filtragem do líquor<sup>42</sup> e outros tratamentos adjuvantes à IgIV, tais como fator neurotrófico cerebral<sup>43</sup> ou betainterferona<sup>44</sup> . Nenhum desses estudos observou mínimos efeitos benéficos significativos com relação às práticas usuais e não são preconizados.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7.2.1.  Fármaco** -->
Imunoglobulina humana: frascos-ampola de 0,5; 1,0; 2,5; 5,0 g.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7.2.2.  Esquema de administração** -->
Imunoglobulina humana: 0,4 g/kg/dia, por via intravenosa.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7.2.3. Tempo de tratamento – Critérios de Interrupção** -->
A imunoglobulina humana deve ser administrada de 2 a 5 dias e interrompida caso haja qualquer evidência de perda da função renal e anafilaxia.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **7.2.3.1. Benefícios esperados** -->
- Diminuição do tempo de recuperação da capacidade de deambular com e sem ajuda;  
- diminuição do número de pacientes com complicações associadas necessitando de VM;  
- diminuição do tempo de VM;  
- aumento da porcentagem de pacientes com recuperação total da força muscular em um ano;  
- diminuição da mortalidade em um ano.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **8. MONITORAMENTO** -->
Deve-se realizar avaliação prévia da função renal (especialmente em pacientes diabéticos), nível sérico de IgA, sorologia para HIV e hidratação prévia. Durante a administração, controlar sinais clínicos para anafilaxia e efeitos adversos, tais como dor moderada no peito, no quadril ou nas costas, náuseas e vômitos, calafrios, febre, mal-estar, fadiga, sensação de fraqueza ou leve tontura, cefaleia, urticária, eritema, tensão do tórax e dispneia.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **9. ACOMPANHAMENTO PÓS-TRATAMENTO** -->
O tratamento de pacientes que não apresentam melhora, ou mesmo seguem piorando, após o tratamento, não está claramente definido. As opções de repetir o tratamento inicial ou de usar imunoglobulina após plasmaférese são preconizadas com base na opinião de especialistas. Já o uso de plasmaférese após imunoglobulina não é preconizado<sup>45</sup> . Quando os pacientes apresentam piora progressiva além de oito semanas após o início do quadro, deve-se considerar o diagnóstico de polirradiculoneuropatia inflamatória desmielinizante crônica (PIDC), cujo tratamento é diferente<sup>46</sup> .  
Os pacientes devem ser reavaliados clinicamente após a alta, periodicamente, à critério médico até estabilização de sua melhora.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e a monitorização do tratamento, bem como a verificação periódica da dose prescrita e dispensada e a adequação de uso do medicamento.  
Alerta-se ao gestor para se organizar no sentido de evitar o fornecimento concomitante da imunoglobulina humana pela Autorização de Internação Hospitalar (AIH/SIH) e Autorização de Procedimentos de Alta Complexidade (APAC/SIA).  
De acordo com a portaria vigente [PRC n° 4, de 28 de setembro de 2017, Anexo 1 do Anexo V (Origem: Portaria GM/MS 204/2016, Anexo 1)], a ocorrência de suspeita ou confirmação de paralisia flácida aguda deve ser comunicada, obrigatoriamente, pelos médicos, profissionais da saúde ou responsáveis pelos estabelecimentos de saúde, públicos ou privados, à autoridade de saúde - Ministério da Saúde (MS), Secretaria de Estado da Saúde (SES) ou Secretaria Municipal de Saúde (SMS).

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **11. REFERÊNCIAS** -->
1. Heemstra HE, de Vrueh RL, van Weely S, Buller HA, Leufkens HG. Predictors of orphan drug approval in the European Union. Eur J Clin Pharmacol. 2008 May;64(5):545-52. PubMed PMID: 18210097. PMCID: PMC2668549. Epub 2008/01/23. eng.  
2. Willison HJ, Jacobs BC, van Doorn PA. Guillain-Barre syndrome. Lancet. 2016 Aug 13;388(10045):717-27. PubMed PMID: 26948435. Epub 2016/03/08. eng.  
3. Masiêro Araujo L, Ferreira MLB, Nascimento OJ. Guillain-Barré syndrome associated with the Zika virus outbreak in Brazil Síndrome de Guillain-Barré associada ao surto de infecção por vírus Zika no Brasil2016:[253 - 5 pp.].  
4. Malta JMAS, Vargas A, Leite PLE, Percio J, Coelho GE, Ferraro AHA, et al. Síndrome de Guillain-Barré e outras manifestações neurológicas possivelmente relacionadas à infecção pelo vírus Zika em municípios da Bahia, 2015.2015; 26:[9 - 18 pp.].  
5. Ropper AH. The Guillain-Barre syndrome. N Engl J Med. 1992 Apr 23;326(17):1130-6. PubMed PMID: 1552914. Epub 1992/04/23. eng.  
6. Hughes RA, Rees JH. Clinical and epidemiologic features of Guillain-Barre syndrome. J Infect Dis. 1997 Dec;176 Suppl 2:S92-8. PubMed PMID: 9396689. Epub 1997/12/13. eng.  
7. Kieseier BC, Hartung HP. Therapeutic strategies in the Guillain-Barre syndrome. Semin Neurol. 2003 Jun;23(2):15968. PubMed PMID: 12894381. Epub 2003/08/02. eng.  
8. Hahn AF. Guillain-Barre syndrome. Lancet. 1998 Aug 22;352(9128):635-41. PubMed PMID: 9746040. Epub 1998/09/24. eng.  
9. Raphael JC, Chevret S, Hughes RA, Annane D. Plasma exchange for Guillain-Barre syndrome. Cochrane Database Syst Rev. 2002 (2):Cd001798. PubMed PMID: 12076424. Epub 2002/06/22. eng.  
10. Hughes RA, Cornblath DR. Guillain-Barré syndrome. Lancet. 2005 Nov;366(9497):1653-66. PubMed PMID: 16271648. eng.  
11. Vucic S, Kiernan MC, Cornblath DR. Guillain-Barré syndrome: an update. J Clin Neurosci. 2009 Jun;16(6):733-41. PubMed PMID: 19356935. eng.  
12. Hadden RD, Hughes RA. Management of inflammatory neuropathies. J Neurol Neurosurg Psychiatry. 2003 Jun;74 Suppl 2:ii9-ii14. PubMed PMID: 12754323. PMCID: Pmc1765628. Epub 2003/05/20. eng.  
13. van Doorn PA, Ruts L, Jacobs BC. Clinical features, pathogenesis, and treatment of Guillain-Barre syndrome. Lancet Neurol. 2008 Oct;7(10):939-50. PubMed PMID: 18848313. Epub 2008/10/14. eng.  
14. Hughes RA, Wijdicks EF, Benson E, Cornblath DR, Hahn AF, Meythaler JM, et al. Supportive care for patients with Guillain-Barre syndrome. Arch Neurol. 2005 Aug;62(8):1194-8. PubMed PMID: 16087757. Epub 2005/08/10. eng.  
15. Romano JG, Rotta FT, Potter P, Rosenfeld V, Santibanez R, Rocha B, et al. Relapses in the Guillain-Barre syndrome after treatment with intravenous immune globulin or plasma exchange. Muscle Nerve. 1998 Oct;21(10):1327-30. PubMed PMID: 9736064. Epub 1998/09/15. eng.  
16. Fokke C, van den Berg B, Drenthen J, Walgaard C, van Doorn PA, Jacobs BC. Diagnosis of Guillain-Barre syndrome and validation of Brighton criteria. Brain. 2014 Jan;137(Pt 1):33-43. PubMed PMID: 24163275. Epub 2013/10/29. eng.  
17. Walling AD, Dickson G. Guillain-Barre syndrome. Am Fam Physician. 2013 Feb 1;87(3):191-7. PubMed PMID: 23418763. Epub 2013/02/20. eng.  
18. Hadden RD, Cornblath DR, Hughes RA, Zielasek J, Hartung HP, Toyka KV, et al. Electrophysiological classification of Guillain-Barre syndrome: clinical associations and outcome. Plasma Exchange/Sandoglobulin Guillain-Barre Syndrome Trial Group. Ann Neurol. 1998 Nov;44(5):780-8. PubMed PMID: 9818934. Epub 1998/11/18. eng.  
19. Asbury AK, Cornblath DR. Assessment of current diagnostic criteria for Guillain-Barre syndrome. Ann Neurol. 1990;27 Suppl:S21-4. PubMed PMID: 2194422. Epub 1990/01/01. eng.  
20. Patwa HS, Chaudhry V, Katzberg H, Rae-Grant AD, So YT. Evidence-based guideline: intravenous immunoglobulin in the treatment of neuromuscular disorders: report of the Therapeutics and Technology Assessment Subcommittee of the American Academy of Neurology. Neurology. 2012 Mar 27;78(13):1009-15. PubMed PMID: 22454268. Epub 2012/03/29. eng.  
21. Donofrio PD. Guillain-Barre Syndrome. Continuum (Minneap Minn). 2017 Oct;23(5, Peripheral Nerve and Motor Neuron Disorders):1295-309. PubMed PMID: 28968363. Epub 2017/10/03. eng.  
22. Govoni V, Granieri E, Tola MR, Casetta I, Ruppi P, Vaghi L. The frequency of clinical variants of Guillain-Barre syndrome in Ferrara, Italy. J Neurol. 1999 Nov;246(11):1010-4. PubMed PMID: 10631631. Epub 2000/01/13. eng.  
23. Drachman DB. Myasthenia Gravis. Semin Neurol. 2016 Oct;36(5):419-24. PubMed PMID: 27704496. Epub 2016/10/06. eng.  
24. Albers J, Donofrio P, McGonable T. Sequential electrodiagnostic abnormalities in acute inflammatory demyelinating polyradiculoneuropathy. Muscle Nerve1985. p. 528-39.  
25. Miller RG, Peterson GW, Daube JR, Albers JW. Prognostic value of electrodiagnosis in Guillain-Barré syndrome. Muscle Nerve. 1988 Jul;11(7):769-74. PubMed PMID: 3405243. eng.  
26. Yuki N, Yamada M, Sato S, Ohama E, Kawase Y, Ikuta F, et al. Association of IgG anti-GD1a antibody with severe Guillain-Barré syndrome. Muscle Nerve. 1993 Jun;16(6):642-7. PubMed PMID: 8502262. eng.  
27. van der Meche FG, Schmitz PI. A randomized trial comparing intravenous immune globulin and plasma exchange in Guillain-Barre syndrome. Dutch Guillain-Barre Study Group. N Engl J Med. 1992 Apr 23;326(17):1123-9. PubMed PMID: 1552913. Epub 1992/04/23. eng.  
28. Fross RD, Daube JR. Neuropathy in the Miller Fisher syndrome: clinical and electrophysiologic findings. Neurology. 1987 Sep;37(9):1493-8. PubMed PMID: 2819783. Epub 1987/09/01. eng.  
29. Mori M, Kuwabara S, Fukutake T, Yuki N, Hattori T. Clinical features and prognosis of Miller Fisher syndrome. Neurology. 2001 Apr 24;56(8):1104-6. PubMed PMID: 11320188. Epub 2001/04/26. eng.  
30. Blau I, Casson I, Lieberman A, Weiss E. The not-so-benign Miller Fisher syndrome: a variant of the Guilain-Barre syndrome. Arch Neurol. 1980 Jun;37(6):384-5. PubMed PMID: 7387472. Epub 1980/06/01. eng.  
31. Hughes RA, van Der Meche FG. Corticosteroids for treating Guillain-Barre syndrome. Cochrane Database Syst Rev. 2000 (3):Cd001446. PubMed PMID: 10908498. Epub 2000/07/25. eng.  
32. Hughes RA, Newsom-Davis JM, Perkin GD, Pierce JM. Controlled trial prednisolone in acute polyneuropathy. Lancet. 1978 Oct 7;2(8093):750-3. PubMed PMID: 80682. Epub 1978/10/07. eng.  
33. van Koningsveld R, Steyerberg EW, Hughes RA, Swan AV, van Doorn PA, Jacobs BC. A clinical prognostic scoring system for Guillain-Barre syndrome. Lancet Neurol. 2007 Jul;6(7):589-94. PubMed PMID: 17537676. Epub 2007/06/01. eng.  
34. Hughes RA, Swan AV, van Doorn PA. Intravenous immunoglobulin for Guillain-Barre syndrome. Cochrane database of systematic reviews (Online). 2012;7:CD002063.  
35. Chevret S, Hughes RA, Annane D. Plasma exchange for Guillain-Barre syndrome. Cochrane Database Syst Rev. 2017 Feb 27;2:Cd001798. PubMed PMID: 28241090. PMCID: PMC6464100. Epub 2017/02/28. eng.  
36. Appropriate number of plasma exchanges in Guillain-Barre syndrome. The French Cooperative Group on Plasma Exchange in Guillain-Barre Syndrome. Ann Neurol. 1997 Mar;41(3):298-306. PubMed PMID: 9066350. Epub 1997/03/01. eng. 37. Korinthenberg R, Schessl J, Kirschner J, Mönting JS. Intravenously administered immunoglobulin in the treatment of childhood Guillain-Barré syndrome: a randomized trial. Pediatrics. 2005 Jul;116(1):8-14. PubMed PMID: 15995024. eng.  
38. El-Bayoumi MA, El-Refaey AM, Abdelkader AM, El-Assmy MM, Alwakeel AA, El-Tahan HM. Comparison of intravenous immunoglobulin and plasma exchange in treatment of mechanically ventilated children with Guillain Barre syndrome: a randomized study. Crit Care. 2011;15(4):R164. PubMed PMID: 21745374. PMCID: Pmc3387601. Epub 2011/07/13. eng.  
39. Elovaara I, Apostolski S, van Doorn P, Gilhus NE, Hietaharju A, Honkaniemi J, et al. EFNS guidelines for the use of intravenous immunoglobulin in treatment of neurological diseases: EFNS task force on the use of intravenous immunoglobulin in treatment of neurological diseases. Eur J Neurol. 2008 Sep;15(9):893-908. PubMed PMID: 18796075. Epub 2008/09/18. eng.  
40. Double-blind trial of intravenous methylprednisolone in Guillain-Barre syndrome. Guillain-Barre Syndrome Steroid Trial Group. Lancet. 1993 Mar 6;341(8845):586-90. PubMed PMID: 8094828. Epub 1993/03/06. eng.  
41. Zhang X, Xia J, Ye H. [Effect of Tripterygium polyglycoside on interleukin-6 in patients with Guillain-Barre syndrome]. Zhongguo Zhong Xi Yi Jie He Za Zhi. 2000 May;20(5):332-4. PubMed PMID: 11789240. Epub 2002/01/16. chi. 42. Wollinsky KH, Hulser PJ, Brinkmeier H, Aulkemeyer P, Bossenecker W, Huber-Hartmann KH, et al. CSF filtration is an effective treatment of Guillain-Barre syndrome: a randomized clinical trial. Neurology. 2001 Sep 11;57(5):774-80. PubMed PMID: 11552002. Epub 2001/09/12. eng.  
43. Bensa S, Hadden RD, Hahn A, Hughes RA, Willison HJ. Randomized controlled trial of brain-derived neurotrophic factor in Guillain-Barre syndrome: a pilot study. Eur J Neurol. 2000 Jul;7(4):423-6. PubMed PMID: 10971602. Epub 2000/09/06. eng.  
44. Pritchard J, Gray IA, Idrissova ZR, Lecky BR, Sutton IJ, Swan AV, et al. A randomized controlled trial of recombinant interferon-beta 1a in Guillain-Barre syndrome. Neurology. 2003 Nov 11;61(9):1282-4. PubMed PMID: 14610140. Epub 2003/11/12. eng.  
45. Verboon C, van Doorn PA, Jacobs BC. Treatment dilemmas in Guillain-Barre syndrome. J Neurol Neurosurg Psychiatry. 2017 Apr;88(4):346-52. PubMed PMID: 27837102. Epub 2016/11/12. eng.  
46. Dyck PJB, Tracy JA. History, Diagnosis, and Management of Chronic Inflammatory Demyelinating Polyradiculoneuropathy. Mayo Clin Proc. 2018 Jun;93(6):777-93. PubMed PMID: 29866282. Epub 2018/06/06. eng.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: IMUNOGLOBULINA HUMANA -->
Eu, ___________________________________________ (nome do(a) paciente), abaixo identificado(a) e firmado(a),  
declaro ter sido informado(a) claramente sobre todas as indicações, contraindicações, principais efeitos colaterais e riscos  
relacionados ao uso do medicamento **imunoglobulina humana** , indicado para o tratamento da **síndrome de Guillain-Barré** .  
Os termos médicos foram explicados e todas as minhas dúvidas foram resolvidas pelo  
médico________________________(nome do médico que prescreve).  
Assim declaro que fui claramente informado(a) de que o medicamento que passo a receber pode trazer as seguintes benefícios:  
- diminuição do tempo de recuperação motora (maior rapidez do início da capacidade de caminhar com ou sem auxílio);  
- diminuição de complicações associadas, incluindo necessidade de ventilação mecânica;  
- diminuição do tempo de ventilação mecânica, caso esta seja necessária;  
- aumento da força muscular em 1 ano;  
- diminuição da mortalidade em 1 ano.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais efeitos colaterais e riscos:  
- não se sabe ao certo os riscos do uso deste medicamento na gravidez, portanto, caso engravide, devo avisar  
- imediatamente ao meu médico;  
- os efeitos colaterais já relatados são: dor de cabeça, calafrios, febre, reações no local de aplicação da injeção, que  
- incluem dor, coceira e vermelhidão. Problemas nos rins também já foram relatados.  
- medicamento contraindicado em casos de hipersensibilidade (alergia) ao fármaco;  
- o risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser assistido, inclusive se desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazer uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.   (   ) Sim    (   ) Não  
|Local:|Data:|||
|---|---|---|---|
|Nome do paciente:||||
|Cartão Nacional de Saúde:||||
|Nome do responsável legal:||||
|Documento de identificação do resp|onsável legal:|||
||____________________<br>Assinatura do paciente o|_________________<br>u do responsável legal||
|Médico Responsável:||CRM:|UF:|  
___________________________ Assinatura e carimbo do médico Data:____________________  
**Nota:** Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: METODOLOGIA DE BUSCA E AVALIAÇÃO DA LITERATURA -->
Este PCDT se destina a profissionais da saúde, pacientes com Síndrome de Guillain-Barré e gestores do SUS. O documento foi elaborado visando a garantir o melhor cuidado de saúde e o uso racional dos recursos disponíveis no Sistema Único de Saúde.  
Depois da publicação, em 13/10/2020, da Portaria Conjunta SAES/SCTIE nº 15, impôs-se a reedição do Protocolo Clínico e Diretrizes Terapêuticas da Síndrome de Guillain-Barré, pela necessidade de se excluírem apresentações farmacêuticas de imunoglobulina humana devido à ausência de registros válidos na Agência Nacional de Vigilância Sanitária (Anvisa). Para tal, foi também adequado o Relatório de Recomendação n.º 553/2020 da Conitec.  
À 104ª Reunião Ordinária da Conitec, realizada dia 09/12/2021, havia sido analisado o Relatório de Recomendação nº 694/2021, que se refere à exclusão de medicamentos cujos registros sanitários caducaram ou foram cancelados no Brasil. Àquela ocasião, foi deliberado, por unanimidade, recomendar a exclusão de imunoglobulina humana 3 g pó liofilizado para solução injetável ou solução injetável na concentração de 3 g e imunoglobulina humana 6 g em pó liofilizado para solução injetável 6 g. A decisão de exclusão das apresentações foi publicada por meio da Portaria SCTIE nº 83, de 29/12/2021. Por fim, o tema foi apresentado como informe à 96ª reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 22/02/2022 e também à 106ª Reunião Ordinária da Conitec, em 10/03/2022.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Síndrome de Guillain-Barré iniciou-se com reunião presencial, realizada dia 23 de maio de 2019 em Brasília/Distrito Federal, para delimitação do escopo. O objetivo desta reunião foi a discussão da atualização do referido PCDT.  
Essa reunião presencial contou com a presença de sete membros do Grupo Elaborador, sendo quatro dos quais especialistas e três metodologistas, além de um representante de associação de pacientes e três representantes do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria nº 1.171/SAS/MS, de 19 de novembro de 2015) e na estrutura de PCDT definida pela Portaria n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas diagnósticas e terapêuticas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratar de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Esses profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **2.1. Colaboração externa** -->
Além dos representantes do Departamento de Gestão e Incorporação de Tecnologias em Saúde do Ministério da Saúde (DGITIS/SCTIE/MS), os demais participantes na elaboração deste Protocolo foram, no âmbito do Programa para o Desenvolvimento Institucional do SUS (PROADI-SUS), metodologistas do Hospital Alemão Oswaldo Cruz (HAOC) e especialistas no tema.  
Todos os participantes do Grupo Elaborador preencheram e assinaram o formulário de Declaração de Conflito de Interesses, que foram enviados ao Ministério da Saúde, como parte dos resultados do trabalho de elaboração.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **2.3. Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A primeira versão deste Protocolo foi apresentada à 75ª reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas, realizada dia 17 de dezembro de 2019, com a participação de áreas técnicas deste Ministério, e, após a análise e sugestões de ajustes e correções, foi por unanimidade decidido pautar o tema à reunião da Conitec.

---

<!-- METADADOS: doenca: Síndrome de Guillain-Barré | secao: **3. Busca da evidência** -->
Para auxiliar na atualização do PCDT, e com o intuito de o parear com as melhores e mais atuais evidências disponíveis, em 20/09/2019 foram realizadas buscas no PubMed e Embase, limitando-se os resultados para ensaios clínicos, ensaios clínicos randomizados (ECR), revisões sistemáticas e meta-análises publicados desde 27/11/2014, data da última atualização do Protocolo vigente. As estratégias de busca foram:  
||**Base**|**Estratégia de busca**|**Localizados**|**Duplicata**|**Selecionados**<br>**para leirtura**|
|---|---|---|---|---|---|
|||"Guillain-Barre<br>Syndrome"[Mesh]<br>AND<br>"Therapeutics"[Mesh]<br>AND<br>((Clinical<br>Trial[ptyp]<br>OR<br>Meta-||||
|PubMed||Analysis[ptyp]<br>OR<br>Randomized<br>Controlled<br>Trial[ptyp]<br>OR<br>systematic[sb])<br>AND<br>("2014/11/27"[PDAT]<br>:<br>"3000/12/31"[PDAT])<br>AND<br>"humans"[MeSH Terms])|15|7|133|
|||'guillain barre syndrome'/exp AND<br>'therapy' AND ([cochrane review]/lim<br>OR [systematic review]/lim OR [meta||||
|Embase||analysis]/lim OR [controlled clinical<br>trial]/lim OR [randomized controlled<br>trial]/lim) AND [embase]/lim AND<br>[2014-2019]/py|125|||  
Outros estudos de conhecimento dos especialistas foram incluídos para a atualização da seção de casos especiais do PCDT.

---

