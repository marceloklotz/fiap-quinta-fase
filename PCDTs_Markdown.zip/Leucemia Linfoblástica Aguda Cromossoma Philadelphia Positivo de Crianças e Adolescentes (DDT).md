<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: Geral -->
<!-- Start of picture text -->
eSa<br>osa<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: MINISTÉRIO DA SAÚDE SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE -->
PORTARIA CONJUNTA Nº 11, DE 02 DE JULHO DE 2021.  
Aprova as Diretrizes Diagnósticas e Terapêuticas – Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a leucemia linfoblástica aguda cromossoma Philadelphia positivo no Brasil e de diretrizes nacionais para diagnóstico, tratamento e acompanhamento de crianças e adolescentes com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação n<sup><u>o</u></sup> 618/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 623 – Maio de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão de Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Atenção Especializada e Temática (DAET/SAES/MS) e do Instituto Nacional de Câncer (INCA/SAES/MS), resolvem:  
Art. 1º  Ficam aprovadas as Diretrizes Diagnósticas e Terapêuticas – Mesilato de Imatinibe no Tratamento da Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes.  
Parágrafo único. As diretrizes objeto deste artigo, que contêm o conceito geral de leucemia linfoblástica aguda cromossoma Philadelphia positivo de crianças e adolescentes, critérios de diagnóstico, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas- <u>pcdt, são de caráter nacional e devem ser utilizadas pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios</u> na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da leucemia linfoblástica aguda cromossoma Philadelphia positivo de crianças e adolescentes.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no Anexo desta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 115/SAS/MS, de 10 de fevereiro de 2012, publicada no Diário Oficial da União nº 35, de 17  de fevereiro de 2012, seção 1, páginas 61-62.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: HÉLIO ANGOTTI NETO -->
1  
ANEXO

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: DIRETRIZES DIAGNÓSTICAS E TERAPÊUTICAS -->
MESILATO DE IMATINIBE NO TRATAMENTO DA  
LEUCEMIA LINFOBLÁSTICA AGUDA CROMOSSOMO PHILADELPHIA POSITIVO DE CRIANÇAS E ADOLESCENTES

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **1. INTRODUÇÃO** -->
A Leucemia Linfoblástica Aguda (LLA) é a neoplasia mais comum da infância, categorizada pela _International Classification of Childhood Cancer_ , em sua terceira edição, como neoplasia de células precursoras linfoides<sup>1</sup> . Segundo a Organização Mundial da Saúde (OMS), pode se apresentar como leucemia linfoblástica aguda ou como linfoma linfoblástico, primariamente em sítio nodal e extra-nodal, de acordo com o grau de acometimento da medula óssea<sup>2</sup> .  
Segundo o Instituto Nacional de Câncer (INCA)<sup>3</sup> , o número de casos novos de câncer de crianças e adolescentes esperados para o Brasil, para cada ano do triênio 2020-2022, será de 4.310 casos novos no sexo masculino e de 4.150 para o sexo feminino. Como as leucemias correspondem a 28% dos cânceres nessas faixas etárias, representam cerca de 2.368 dos 8.460 casos novos anuais, dos quais a grande maioria será de leucemia linfoblástica aguda (LLA).  
Dados do Registro de Câncer de Base Populacional (RCBP) no município de São Paulo, de 1997 a 2013, mostram a taxa de incidência de LLA de 34,7 casos por milhão. No mesmo estudo, a taxa de mortalidade foi de 9,0 óbitos por milhão<sup>4</sup> . Em Recife, a taxa de incidência ajustada por idade para todas as leucemias foi de 41,1 casos por milhão, sendo 27,1 casos por milhão especificamente de LLA. O pico da taxa de incidência ocorreu entre um e quatro anos de idade. A taxa geral de sobrevida relativa em cinco anos para doentes de LLA foi de 76,5%<sup>5</sup> . Após a análise de 16 registros de câncer brasileiros, a taxa média de incidência ajustada por idade foi de 53,3 casos por milhão<sup>6</sup> . No Nordeste brasileiro, os RCBP mostram menor taxa de incidência ajustada por idade em comparação com o Sudeste e o Sul<sup>6</sup> . Os estudos não descartam a possibilidade de menor incidência por causa de subnotificação, o que, por sua vez, pode ser resultado de subdiagnóstico<sup>6</sup> .  
Nos EUA, a incidência anual de LLA nos Estados Unidos é de 1,7 casos por 100.000 indivíduos, sendo a mediana de idade para o diagnóstico de 15 anos e o pico de incidência em crianças entre três e cinco anos (4 casos por 100.000 indivíduos)<sup>7</sup> .  
Historicamente relacionada a resultados inferiores, a LLA cromossomo Philadelphia positivo (LLA Ph+) se caracteriza pela alteração genética t(9;22)(q34;11), que resulta no gene de fusão _BCR-ABL1_ e a proteína BCR-ABL1, e representa 3% a 5% dos casos de LLA em crianças e adolescentes<sup>8,9</sup> .  
Sabe-se que há associação dessa doença com alterações genéticas adquiridas ainda intra-útero, síndromes de instabilidade genética, exposição a derivados petroquímicos (como pesticidas) e a radiação ionizante<sup>10</sup> . Acredita-se que a LLA resulte de uma resposta anormal às infecções comuns, como, por exemplo, pelo vírus _Influenza_ . As crianças mais suscetíveis seriam aquelas minimamente expostas às infecções durante os primeiros anos de vida e que são portadoras de clones pré-leucêmicos adquiridos<sup>11</sup> .  
Os principais sintomas de LLA são febre, sangramento, dor óssea, linfonodonomegalia, esplenomegalia e hepatomegalia. O hemograma evidencia leucocitose na maioria dos casos, sendo anemia e plaquetopenia achados comuns<sup>12</sup> . Apesar de os tratamentos atuais levarem à sobrevida em longo prazo acima de 90% nos pacientes de mais baixo risco, alguns subgrupos ainda têm mau prognóstico<sup>13</sup> . Antes da introdução dos inibidores da tirosinoquinase (ITQ), a sobrevida em longo prazo dos pacientes pediátricos com LLA Ph+ tratados com ou sem transplante de células-tronco hematopoéticas alogênico (TCTH-alo) era abaixo de 45%<sup>14</sup> . Depois do sucesso no tratamento da Leucemia Mieloide Crônica (LMC), o imatinibe mostrou-se também eficaz no  
2  
tratamento da leucemia LLA Ph+, tanto em adultos quanto em crianças.  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Estas Diretrizes visam a estabelecer os critérios diagnósticos e terapêuticos da leucemia linfoblástica aguda cromossoma Phuladelphia positivo de crianças e adolescentes, especificando o uso do mesiliato de imatinibe no seu tratamento. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS ELACIONADOS À SAÚDE (CID-10)** -->
- C91.0 Leucemia linfoblástica aguda  
- C83.5 Linfoma linfoblástico  
**Nota 1** : A leucemia linfoblástica aguda (LLA) e o linfoma linfoblástico (LLb) são entidades nosológicas equivalentes, diferenciando-se somente pelo local primário da doença e sua forma de apresentação<sup>15,16</sup> .  
**Nota 2:** A OMS incluiu em sua classificação a LLA/LLb-B BCR-ABL1-like (ou Ph-like) como entidade provisória. Esse novo subtipo vem ganhando importância por conferir mau prognóstico e, em alguns casos, responder à terapia com ITQ. A LLA Ph-like é de difícil distinção clínica e se caracteriza por translocações envolvendo diferentes tirosinoquinases (ABL1 e parceiros alternativos, ABL2, PDGRFB, NTRK3, TYK2, CSF1R e JAK2, por exemplo), CRLF2 ou o receptor de eritropoietina<sup>17</sup> . Este subtipo de LLA não está contemplada nestas Diretrizes.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **3. DIAGNÓSTICO** -->
Clinicamente, não é possível distinguir a LLA Ph+ dos outros tipos de LLA. Portanto, a conduta diagnóstica é a mesma para todos os casos suspeitos de LLA. A avaliação morfológica do sangue ou da medula óssea é recomendada, já que a identificação de linfoblastos no sangue periférico direciona a subsequente etapa  diagnóstica inicial<sup>15</sup> .  
Quando há impossibilidade de se aspirar medula óssea (caso de aspirado seco) para se proceder ao mielograma, ou quando não houver linfoblastos suficientes em amostra de sangue periférico, deve-se realizar biópsia de medula óssea e _imprint_ do material biopsiado. E, mesmo em pacientes sem sintomas relacionados ao sistema nervoso central (SNC), preconiza- se o exame citológico do líquor, com o objetivo de se descartar invasão leucêmica do SNC, o que pode mudar a conduta terapêutica<sup>2</sup> .Os padrões morfológicos e citoquímicos da LLA Ph+ não são específicos. O diagnóstico diferencial com outras neoplasias de morfologia semelhante e com precursores normais deve ser feito por imunofenotipagem do sangue periférico ou da medula óssea, que mostra o perfil antigênico de precursores linfoides B com expressão aberrante na maioria dos casos<sup>18</sup> . O perfil antigênico típico é CD10+, CD19+ e TdT+, com expressão mais frequente dos marcadores mieloide CD13 e CD33. O CD117 tipicamente não é expresso, enquanto o CD25+ se associa fortemente com a presença de BCR-ABL1, pelo menos em adultos. Alguns raros casos de LLA Ph+ podem ter fenótipo T. A identificação da translocação t(9;22), ou cromossomo Philapelphia pode ser feita por meio do cariótipo ou por _Fluorescence In Situ Hybridization_ (FISH).  
Este segundo exame pode ser utilizado para o diagnóstico quando a avaliação do cariótipo revela ausência de metáfases ou rearranjos complexos para confirmar a presença da translocação específica. A avaliação do transcrito BCR-ABL1 deve ser feita ao diagnóstico pelo método de reação em cadeia da polimerase (PCR, sigla de _Polymerase Chain Reaction_ ), e a maioria das crianças com LLA Ph+ apresenta o BCR-ABL1 p190 kDa, menor que o BCR-ABL1 p210 kDa presente na Leucemia Mieloide 3  
Crônica (LMC). Esta informação é essencial para a monitorização subsequente da presença de Doença Residual Mínima (DRM), permite identificar a doença ativa por meio do PCR e pode orientar a intensidade da quimioterapia<sup>13</sup> .  
É importante ressaltar que os testes de reação em cadeia de polimerase – transcriptase reversa (RT-PCR) qualitativa e quantitativa e de hibridização _in situ_ (ISH) – para o diagnóstico e monitoramento da LLA Ph+ são disponíveis no SUS, incorporados que foram em 2019<sup>19</sup> .  
Em resumo, para o diagnóstico de LLA Ph+, estas Diretrizes preconizam:  
- Citomorfomologia e citoquímica por microscopia ótica do sangue periférico e, se for o caso, da medula óssea;  
- biópsia de medula óssea com imuno-histoquímica, em caso de impossibilidade de se aspirar a medula óssea ou de  
- aspirado medular seco;  
- citomorfologia do líquor;  
- imunofenotipagem das células blásticas do sangue periférico, medula óssea ou líquor; e  
- identificação do cromossoma Philadelphia no sangue periférico ou na medula óssea por exame de citogenética  
- convencional ou ISH, ou da proteína BCR-ABL1 por exame de biologia molecular<sup>19</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos nestas DDT os pacientes com:  
- idade inferior a 19 anos; e  
- diagnóstico inicial de LLA ou de linfoma linfoblástico (LLb) com a presença de: t(9;22)(q34;q11.2) ou cromossomo  
- Philadelphia ou rearranjo BCL-ABL1; ou  
- LLA Ph+ ou LLb em recidiva molecular, citogenética ou hematológica e que não tenham recebido imatinibe em seu  
- tratamento anterior.  
**Nota** : Pacientes com LLA Ph+ ou LLb Ph+ de 19 ou mais anos de idade devem ser incluídos no protocolo específico estabelecido pelo Ministério da Saúde para o uso do mesilato de imatinibe no tratamento de LLA Ph+.  
Para a indicação de TCTH-alo <mark>aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, devem ser observados os critérios estabelecidos no Regulamento Técnico do Sistema Nacional de Transplantes (SNT), devendo todos os potenciais receptores estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS.</mark>

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos destas DDT:  
- Pacientes com LLA/LLb-B BCR-ABL1-like (ou Ph-like);  
- pacientes em fase de amamentação; ou  
- pacientes que apresentem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou tenham  
- contraindicação absoluta ao uso do mesilato de imatinibe ou a procedimento, inclusive o TCTH, preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **6. CASOS ESPECIAIS** -->
- **6.1 Gestação e amamentação**  
4  
De acordo com as recomendações do fabricante, o mesilato de imatinibe não é recomendado durante a gravidez a menos que claramente necessário, pois pode prejudicar o desenvolvimento do feto<sup>20</sup> .  
Existem relatos de caso de tratamento de LLA em adolescentes grávidas, porém não foram encontrados relatos específicos para LLA Ph+ em adolescentes, somente em mulheres adultas<sup>21,22</sup> . Apenas um estudo avaliou o uso de imatinibe na fase de indução do tratamento, em uma gestante adulta (38 anos) com LLA Ph+ com 24 semanas de gestação. Foi tratada com ciclofosfamida, mesna, dexametasona, doxorrubicina e vincristina, além de mesilato de imatinibe e citarabina. Teve parto cesareano com 30 semanas de gestação, com bebê saudável. No entanto, a mãe faleceu de complicações progressivas<sup>21</sup> .  
Nos demais relatos de caso, foram apresentados os casos de uma adulta e duas adolescentes (16 anos) entre a segunda e a terceira semanas de gestação. Os esquemas de indução incluíram quimioterápicos como daunorrubicina, vincristina, ciclofosfamida e prednisona ou daunorrubicina, vincristina, asparaginase, prednisolona e metotrexato intratecal. As três pacientes tiveram parto cesáreo com 32 semanas de gestação. Os bebês nasceram saudáveis e as mães deram continuidade ao tratamento (incluindo o imatinibe), com remissão completa<sup>22–24</sup> .  
Estudos relatam que o uso de ITQ no primeiro trimestre de gestação é contraindicado, e no segundo e terceiro trimestres a orientação seria evitar, se possível. O uso de imatinibe nesse caso seria feito com extremo cuidado, se o benefício para a mãe claramente superar o risco ao feto<sup>25</sup> .  
Dessa forma, as decisões quanto ao tratamento desses casos especiais devem ser tomadas em conjunto, pela equipe multidisciplinar, paciente e familiares. Deve-se considerar a relação risco benefício do tratamento, considerando-se o tipo de LLA e o momento do diagnóstico na gestação. Pacientes em uso de ITQ e que engravidam devem ser orientadas a interromper o uso desse medicamento de imediato, uma vez que são contraindicados durante a gravidez. A terapia deve ser interrompida, com preferência por um período de repouso de três meses antes da concepção e durante a gravidez, e deve ser reiniciada imediatamente após o nascimento.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **6.2 Irradiação craniana** -->
A irradiação craniana com finalidade terapêutica, sempre maximamente evitada, pode ser indicada em casos especiais, a depender da conduta (“protocolo”) institucional adotada<sup>26</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7. TRATAMENTO** -->
O tratamento de LLA é definido pelo protocolo terapêutico adotado no hospital. Os pacientes são classificados ao diagnóstico e tratados conforme o “grupo de risco” em que se enquadram e há protocolos específicos para os doentes virgens de tratamento (recém-diagnosticados) e recidivados.  
Os grupos de risco são diferentemente chamados, mas, no geral, o são como baixo, intermediário (ou padrão) e alto, havendo, a depender do protocolo, nuances nessa classificação.  
Os detalhes das fases da poliquimioterapia de indução, consolidação, reindução e manutenção - com quimioterapia intratecal e, quando adotada no protocolo do hospital, radioterapia do SNC - variam de acordo com cada protocolo de tratamento.  
Os critérios para suspensão da terapia também são detalhados em cada protocolo. Em caso de crianças e adolescentes, preconiza-se, conforme o protocolo adotado, a interrupção do ITQ  junto com o término da fase da quimioterapia de manutenção oral, se a LLA Ph+ se mostra em remissão molecular contínua<sup>14,27</sup> .  
Devem ser realizados os seguintes exames basais (antes do início do tratamento):  
- hemograma com contagem de plaquetas;  
- exames sorológicos para hepatites B e C e para HIV;  
5  
- dosagem sérica das aminotransferases/transaminases (AST/TGO, ALT/TGP), bilirrubinas, fosfatase alcalina e  
- desidrogenase láctica (DHL);  
- dosagem sérica de glicose, ureia e creatinina;  
- dosagem sérica dos íons sódio, potássio, fósforo, cálcio e magnésio;  
- dosagem sérica do ácido úrico;  
- estudo da coagulação sanguínea;  
- exame parasitológico de fezes;  
- análise sumária de urina;  
- eletrocardiograma ou ecocardiograma;  
- radiografia simples de tórax em PA e perfil; e  
- dosagem sérica de gonadotrofina coriônica (beta HCG), em casos de mulheres adolescentes com vida sexual ativa.  
O tratamento da LLA começa com uma pré-fase de corticoterapia. Então, inicia-se a quimioterapia de indução, a qual, geralmente a partir do 15º dia (D15) inclui o ITQ (o imatinibe) no caso de LLA Ph+, conforme o protocolo institucional e com avaliação contínua de resposta terapêutica<sup>15</sup> .  
A fase de consolidação adota o esquema adequado ao risco prognóstico estabelecido ao diagnóstico do paciente<sup>15</sup> . Pacientes de baixo risco recebem quimioterapia de consolidação menos intensa, ao passo que pacientes de alto risco a recebem mais intensa. A fase de consolidação pode consistir de quatro a seis ciclos de quimioterapia<sup>15</sup> . Se o paciente for considerado de risco padrão, isto é, com baixa detecção de DRM, a de consolidação seria continuar com quimioterapia e, se LLA Ph+,  ITQ, assim como na fase de de manutenção, na qual se considera a possibilidade de TCTH-alo<sup>15</sup> .  
A fase de manutenção serve para prevenir a recidiva da doença após as terapias de indução e consolidação e pode durar de dois a três anos<sup>15,26</sup> .  
6  
O fluxograma para diagnóstico e tratamento da LLA de crianças e adolescentes pode ser visto na **Figura 1** .  
**Figura 1** – Fluxograma para o Diagnóstico e Tratamento de Leucemia Linfoblástica Aguda  
<!-- Start of picture text -->
Suspeita de leucemia: >)<br>+ Febre<br>+ Sangramento<br>+ Dor éssea<br>+ Linfadenomegalia<br>Hemograma:<br>+ Leucocitose<br>+ Citopenia(s)<br>Aspirado de medula éssea*:<br>+ Mielograma<br>+ Imunofenotipagem<br>+ Citogenética<br>+ Cariétipo, FISH<br>+ Biologia molecular<br>Leucemia linfoblistica aguda Leucemia linfobldstica aguda<br>BCR/ABLI presente, }e BCR/ABL1 ausente,<br>‘cromossomo Pht: cromossomo Ph-:<br>Iniciar a pré-fase de Iniciar quimioterapia<br>corticoterapia, seguida da conforme protocolo<br>‘quimioterapia, conforme institucional<br>protocolo institucional,<br>induindo o imatinibe<br>geralmente a partir do 15° dia<br>(015) da fase de inducSo na<br>dose de 340/mg/m*/dia (mix.<br>de 600/dia)<br><!-- End of picture text -->  
*  Na impossibilidade de se aspirar medula óssea (caso de aspirado seco) para se proceder ao mielograma, ou na ausência de linfoblastos suficientes em amostra de sangue periférico, deve-se realizar biópsia de medula óssea.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.1. Profilaxia de doença no SNC** -->
Por conta dos muito reconhecidos efeitos adversos neurocognitivos, de crescimento e desenvolvimento, orgânicos e hormonais, a irradiação craniana para prevenir a recidiva  leucêmica no SNC já não é preconizada no tratamento de LLA de crianças e adolescentes, sendo a profilaxia obtida com quimioterapia intratecal, aplicada conjuntamente com a quimioterapia sistêmica.  
O objetivo de se proceder à profilaxia no SNC com a aplicação de quimioterapia intratecal é prevenir recidiva leucêmica em local inacessível à quimioterapia sistêmica por causa da barreira hemato-encefálica<sup>15</sup> . A quimioterapia intratecal é indicada durante todo o curso do tratamento, nas fases de indução, consolidação e manutenção, independentemente de haver cromossomo Ph e ida idade do paciente<sup>15,16,26</sup> .  
7

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.2. Transplante de células-tronco hematopoéticas alogênico (TCTH-ALO)** -->
O transplante de células-tronco hematopoéticas alogênico (TCTH-alo) não é indicado para todas as crianças com LLA Ph+ em primeira remissão, tratadas com quimioterapia e ITQ. O TCTH-alo é reservado aos pacientes com resposta pobre ao tratamento (persistência de Doença Residual Mínima - DRM) e para resgate de recaídas, ainda que de acordo com a opinião de especialistas14,28.  
A indicação de TCTH deve observar o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3. Mesilato de Imatinibe** -->
O mesilato de imatinibe é preconizado em primeira linha de tratamento da LL Ph+ de crianças e adolescentes já a partir da fase de indução<sup>13</sup> .  
A dose de imatinibe é de 260–340 mg/m<sup>2</sup> /dia (dose máxima 600mg/dia), por via oral. Ele pode ser administrado em dose única, ou em dose dividida, de manhã e à noite, e deve ser administrado com comida e um grande copo de água. Caso não seja possível a deglutição dos comprimidos, eles não devem ser esmagados. Nesse caso, devem ser dispersos em água ou suco de maçã, sendo que o número de comprimidos deve estar em volume adequado de líquido e misturado com uma colher (50ml de líquido para cada 100mg de comprimido). A suspensão deve ser ingerida imediatamente após a desintegração do comprimido<sup>29</sup> .  
A data do início do uso de imatinibe deve ser de acordo com o protocolo adotado no hospital no qual o paciente for atendido, habitualmente no D15 (15º dia) da fase de indução. Interrupções ou mudanças de doses podem ser necessárias em caso de eventos adversos. Em caso de TCTH-alo, o imatinibe habitualmente é mantido até um ano após o transplante.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3.1. Benefícios esperados** -->
A literatura especializada relata que incluir um ITQ na quimioterapia da LLA Ph+ tanto na fase de indução como na de consolidação gera altas taxas de remissão leucêmica completa e de sobrevida dos pacientes<sup>16</sup> .  
Em estudo com crianças e adolescentes com LLA Ph+ tratados com quimioterapia intensiva e imatinibe, aqueles que tiveram exposição contínua ao imatinibe tiveram sobrevida livre de eventos em três anos de 80,5% (IC 95%: 64,5% a 89,8%)<sup>14,15</sup> . Esse dado foi comparado a uma coorte histórica de pacientes tratados com outro protocolo, cuja sobrevida livre de eventos em três anos foi de 35%<sup>15,30</sup> . De modo similar, no estudo EsPhALL, pacientes com perfil de risco padrão que receberam imatinibe com quimioterapia tiveram sobrevida livre de eventos em quatro anos de 75,2%, em comparação com o resultado de 55,9% para pacientes que não receberam o imatinibe (p=0,06)<sup>13,15</sup> . Posteriormente, o estudo EsPhALL foi modificado para passar a usar imanitibe de forma contínua na fase de indução a partir do 15º dia (D15). Dessa maneira, 97% dos paciente atingiram remissão leucêmica completa<sup>13,15</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3.2.  Avaliação da resposta terapêutica** -->
Para a avaliação de resposta ao tratamento, inclusive com o mesilato de imatinibe, é necessário monitorar as respostas molecular e citogenética, conforme o protocolo institucional adotado.  
A doença residual mínima (DRM) é um fator preditivo de recaída leucêmica. A sua mensuração pode ser realizada por meio de citometria de fluxo (imunofenotipagem) e de RT-PCR<sup>31</sup> .  
Um ponto de corte comumente utilizado para definir a positividade para a DRM é 0,01%. Assim, pacientes que apresentam valores inferiores a 0,01% têm chance elevada de permanecer em remissão com a terapia de manutenção. A DRM também é fator prognóstico para pacientes pediátricos em primeira recidiva que apresentaram segunda remissão e para aqueles  
8  
com recidiva extramedular isolada. Adicionalmente, a detecção de DRM anteriormente ao transplante de células-tronco hematopoéticas alogênico está associada a um aumento do risco de recidiva pós-transplante<sup>32</sup> .  
Em estudo de avaliação de longo prazo do uso de imatinibe no tratamento da LLA Ph+, a avaliação da DRM sugeriu que o uso desse ITQ pode, por reduzir a DRM, minimizar o impacto desse marcador como preditivo da recaída leucêmica<sup>14</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3.3.  Eventos adversos** -->
Os eventos adversos associados ao uso do imatinibe podem ser descritos de acordo com a seguinte categorização:  
**COMUNS** (21%-100%): Náusea/diarreia, retenção hídrica, edema periférico, edema periorbitário, mielossupressão (neutrófilos/plaquetas), fadiga, _rash_ , câimbras musculares, artralgia. Retardo do crescimento, principalmente em pacientes impúberes<sup>20</sup> .  
**OCASIONAIS** (5%-20%): Febre, tremores e calafrios, síndrome tipo resfriado, dor abdominal, cefaleia, dor no peito, dispepsia/queimação, flatulência, vômitos, zumbidos, insônia, constipação, sudorese noturna, ganho de peso, disgeusia, anemia, anorexia, mialgia, hemorragia, disfagia, esofagite, odinofagia, mucosite/estomatite, tosse, epistaxe, prurido, ascite, neuropatia (motora ou sensorial) e, mais tardiamente, despigmentação (vitiligo) e alopecia. Diminuição da densidade óssea e aumento do volume da trabécula óssea<sup>20</sup> .  
**RAROS** (<5%): Angioedema, aumento da pressão intracraniana, edema cerebral, desidratação, elevação das transferases/transaminases, fosfatase alcalina e bilirrubina, derrame pleural, edema pulmonar, pneumonite, dispneia, edema pericárdico, dermatite exfoliativa, hemorragia/sangramento sem trombocitopenia de grau 3 ou 4 - incluindo o SNC, olho, pulmão e trato gastrointestinal, conjuntivite, borramento da visão, olho seco, hipocalemia, hiponatremia, hipofosfatemia, ansiedade,  alteração do humor, infecções. De aparecimento mais tardio, destacamse: hepatotoxicidade, toxicidade renal, insuficiência renal, rotura esplênica, artrite, osteonecrose, fraqueza muscular (descrita como temporária e nas extremidades inferiores), disfunção do ventrículo esquerdo (secundária a dano nos miócitos), trombose/tromboembolismo<sup>20</sup> .  
Todos os eventos adversos relacionados ao uso do imatinibe devem ser valorizados e registrados, pois podem contribuir para uma sub-utilização deste medicamento. O emprego do imatinibe pode ser mantido na vigência de leve efeito adverso, desde que haja acompanhamento regular com o hematologista; porém, a ocorrência de efeito adverso moderado ou grave exige a suspensão do uso, passível de reintrodução na dependência do dano causado e da vontade do responsável pelo paciente<sup>20</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3.4.  Interações medicamentosas** -->
O uso concomitante do imatinibe com outros medicamentos – principalmente com os que também podem produzir depressão da medula óssea, hepatotoxicidade e nefrotoxicidade – deve ser cuidadosa e rigorosamente monitorado. Devem-se buscar exaustivamente possíveis interações de qualquer medicamento a ser administrado concomitantemente ao imatinibe<sup>20,29</sup> .  
O mesilato de imatinibe é metabolizado primariamente pela enzima CYP3A4. Dessa forma, é necessário evitar o uso concomitante com medicamentos que sejam indutores dessa enzima, e considerar até 50% de aumento da dose se essa co-administração não puder ser evitada. Por outro lado, também é necessário cautela se for necessário usar o imatinibe em conjunto com os inúmeros  medicamentos inibidores da CYP3A4<sup>29</sup> .  
Exemplos de possíveis interações medicamentosas incluem os antagonistas de histamina-2, inibidores de bomba de prótons<sup>15</sup> , acetaminofeno, aspirina, codeína, dexametasona, diclofenaco e ibuprofeno, entre muitos  
9  
outros<sup>29</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **7.3.5. Outras tecnologias** -->
Com a hipótese de que o dasatinibe pudesse melhorar ainda mais o prognóstico da LLA Ph+, o _Children Oncology Group_ (COG) estudou a associação do dasatinibe em primeira linha de tratamento com quimioterapia intensiva, de formas intermitente ou contínua. Esta estratégia se mostrou preliminarmente segura e resultou em respostas mais intensas. Esses resultados podem ser explicados pelo fato de o dasatinibe ser mais potente, penetrar no SNC e atuar em formas de BCR-ABL1 resistentes ao imatinibe (com exceção dos casos com a mutação T315I). Considerando os efeitos tardios indesejáveis da quimioterapia, os grupos COG e _European intergroup study of post-induction treatment of Philadelphia-chromosome-positive ALL_ (EsPhALL) se uniram em um novo estudo para avaliar os resultados do dasatinibe associado à quimioterapia menos intensa<sup>33</sup> .  
Atualmente, não há dados disponíveis para a recomendação sobre uso de dasatinibe em primeira linha no tratamento de crianças e adolescentes com LLA Ph+. Ademais, o dasatinibe não tem indicação em bula para o tratamento de crianças e adolescentes<sup>34</sup> , razão pela qual não houve avaliação pela Comissão Nacional de Incorporação de Tecnologias em Saúde no SUS (Conitec).  
Em parte dos pacientes com recidiva, a ausência de mutações no BCR-ABL1 mostra que vias alternativas também são importantes na leucemogênese da LLA Ph+<sup>35</sup> . Apesar de não haver consenso, alguns autores sugerem a pesquisa de mutações no BCR-ABL1 (se disponível), quando houver perda da resposta molecular, recaída hematológica ou necessidade de substituir o imatinibe por toxicidade, com o intuito de guiar a próxima linha terapêutica<sup>36</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **8. MONITORAMENTO** -->
Não se procede ao monitoramento dos níveis séricos do imatinibe.  
O monitoramento de doença residual mínima (DRM) deve ser realizado conforme previsto no protocolo adotado no hospital, para a identificação de pacientes que precisem intensificar o tratamento por meio do TCTH-alo<sup>37</sup> . Quando a intenção é reduzir a intensidade da quimioterapia, o ideal é utilizar como parâmetro o método mais sensível para se detectar a DRM. Portanto, a resposta terapêutica adequada na LLA Ph+ significa ausência de BCR-ABL1 na medula óssea, avaliado pela técnica de PCR (sensibilidade até 10<sup>6</sup> )<sup>31</sup> .  
Para o monitoramento laboratorial, devem ser realizados os exames previstos no protocolo utilizado no hospital, incluindo o mielograma, os exames citogenéticos e a determinação quantitativa da DRM na medula óssea. Controles periódicos do líquor serão realizados por ocasião das aplicações de quimioterapia intratecal.

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes para o uso do mesilato de imatinibe, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso desse medicamento.  
Casos de leucemia linfoblástica aguda devem ser atendidos em hospitais habilitados em Oncologia e com porte tecnológico suficiente para diagnosticar, tratar e acompanhar clínica e laboratorialmente os pacientes.  
Além da familiaridade que esses hospitais guardam com o tratamento, o ajuste das doses e o controle dos efeitos adversos, eles têm toda a estrutura ambulatorial, de internação, de terapia intensiva, de hemoterapia, de suporte multiprofissional e de laboratórios necessária para o adequado atendimento e obtenção dos resultados terapêuticos esperados.  
A regulação do acesso é um componente essencial da gestão para a organização da rede assistencial e garantia do  
10  
atendimento aos pacientes, e muito facilita as ações de controle e avaliação. Estas incluem, entre outras: a manutenção atualizada do Cadastro Nacional dos Estabelecimentos de Saúde (CNES); a autorização prévia dos procedimentos; o monitoramento da produção dos procedimentos (por exemplo, frequência apresentada versus autorizada, valores apresentados versus autorizados versus ressarcidos); e a verificação dos percentuais das frequências dos procedimentos quimioterápicos em suas diferentes linhas (cuja ordem descendente – primeira maior do que segunda maior do que terceira – sinaliza a efetividade terapêutica). Ações de auditoria devem verificar in loco, por exemplo, a existência e a observância da conduta ou protocolo adotados no hospital; regulação do acesso assistencial; qualidade da autorização; a conformidade da prescrição e da dispensação e administração dos medicamentos (tipos e doses); compatibilidade do procedimento codificado com o diagnóstico e a capacidade funcional (escala de Zubrod); a compatibilidade da cobrança com os serviços executados; a abrangência e a integralidade assistenciais; e o grau de satisfação dos pacientes.  
Para a autorização do TCTH alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes.  
Os receptores transplantados submetidos a TCTH alogênico, originários dos próprios hospitais transplantadores neles devem continuar sendo assistidos e acompanhados; e os demais receptores transplantados deverão, efetivada a alta do hospital transplantador, ser devidamente reencaminhados aos seus hospitais de origem, para a continuidade da assistência e acompanhamento. A comunicação entre os hospitais deve ser mantida de modo que o hospital solicitante conte, sempre que necessário, com a orientação do hospital transplantador e este, com as informações atualizadas sobre a evolução dos transplantados.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), radioterápicos e quimioterápicos  (Grupo 03, Subgrupo 04), cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva neoplasia maligna, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabela-unificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
**NOTA 1** – O mesilato de imatinibe, de uso preconizado nestas Diretrizes, é, hoje, adquirido pelo Ministério da Saúde e fornecido pelas Secretarias de Saúde para os hospitais e, por esses, aos usuários do Sistema Único de Saúde (SUS). Os procedimentos quimioterápicos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS (“Tabela do SUS”) não fazem referência a qualquer medicamento e são aplicáveis às situações clínicas específicas para as quais terapias antineoplásicas medicamentosas são indicadas. Assim, os hospitais credenciados no SUS e habilitados em Oncologia são os responsáveis pelo fornecimento de outros medicamentos contra a LLA, previstos nos respectivos protocolos que adotam e que eles, livremente, padronizem, adquiram e forneçam, cabendo-lhes codificar e registrar conforme o respectivo procedimento seja o hospital público ou privado, com ou sem fins lucrativos.  
**NOTA 2** – O uso do mesilato de imatinibe é associado aos outros antineoplásicos do esquema terapêutico e, assim, o seu fornecimento pode ser concomitante à autorização de APAC para os seguintes procedimentos da tabela do SUS para a quimioterapia de leucemia linfoblástica aguda ou linfoma linfoblástico, em não tendo havido uso prévio ao respectivo procedimento:  
03.04.07.006-8 - Quimioterapia de leucemia linfoide/linfoblástica aguda, linfoma linfoblástico, leucemia mieloide aguda e leucemia promielocítica aguda na infância e adolescência - 1ª linha – fases terapêuticas iniciais;  
03.04.07.007-6 - Quimioterapia de leucemia linfoide/linfoblástica aguda, leucemia mieloide aguda e leucemia promielocítica aguda na infância e adolescência - 1ª linha – fase de manutenção;  
11  
03.04.07.002- 5 – Quimioterapia de Câncer na Infância e Adolescência – 2ª linha (primeira recidiva); 03.04.07.004-1– Quimioterapia de Câncer na Infância e Adolescência – 3ª linha (segunda recidiva); e  
03.04.07.003-3 – Quimioterapia de Câncer na Infância e Adolescência – 4ª linha (terceira recidiva).  
**NOTA 3 –** Como o mesilato de imatinibe é comprado pelo Ministério da Saúde e fornecido aos hospitais habilitados em oncologia no SUS pela Assistência Farmacêutica das Secretarias Estaduais de Saúde, não pode ser autorizada APAC para procedimento de quimioterapia, _quando o seu uso é isolado_ , como, por exemplo, para manutenção no pós-transplante. Neste caso, o atendimento ambulatorial pode ser ressarcido como consulta especializada (procedimento 03.01.01.007-2 - Consulta Médica em Atenção Especializada).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso do medicamento preconizado nestas Diretrizes, levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **11. REFERÊNCIAS** -->
1. Steliarova-Foucher E, Stiller C, Lacour B, Kaatsch P. International Classification of Childhood Cancer, third edition. _Cancer_ . 2005;103(7):1457-1467. doi:10.1002/cncr.20910  
2. World Health Organization. _WHO Classification of Tumours of Hematopoietic and Lymphoid Tissues: [... Reflects the Views of a Working Group That Convened for an Editorial and Consensus Conference at the International Agency for Research on Cancer (IARC)]._ ; 2008.  
3. Brasil. Ministério da Saúde. Instituto Nacional de Câncer. _Estimativa 2020: Incidência de Câncer No Brasil_ . Rio de Janeiro; 2019.  
4. Silva FF da, Latorre M do RD de O. Sobrevida das leucemias linfoides agudas em crianças no Município de São Paulo, Brasil . _Cad Saúde Pública_ . 2020;36.  
5. Lins MM, Santos M de O, de Albuquerque M de FPM, de Castro CCL, Mello MJG, de Camargo B. Incidence and survival of childhood leukemia in Recife, Brazil: A population-based  analysis. _Pediatr Blood Cancer_ . 2017;64(8). doi:10.1002/pbc.26391  
6. de Souza Reis RS, de Camargo B, de Oliveira Santos M, de Oliveira JM, Azevedo Silva F, Pombo-de-Oliveira MS. Childhood leukemia incidence in Brazil according to different geographical regions. _Pediatr Blood Cancer_ . 2011;56(1):58-64. doi:10.1002/pbc.22736  
7. Howlader N, Altekruse SF, Li CI, et al. US incidence of breast cancer subtypes defined by joint hormone receptor and  
HER2  status. _J Natl Cancer Inst_ . 2014;106(5). doi:10.1093/jnci/dju055  
8. Andolina JR. BCR/ABL1 Kinase Domain Mutation Monitoring: Could Philadelphia Chromosome-Positive  Acute Lymphoblastic Leukemia Benefit As Well? _Acta Haematol_ . 2015;134(2):69-70. doi:10.1159/000380874  
9. Rubnitz JE, Pui CH. Childhood Acute Lymphoblastic Leukemia. _Oncologist_ . 1997;2(6):374-380.  
10. Advani AS, Lazarus HM, eds. _Adult Acute Lymphocytic Leukemia_ . Springer S. Humana Press; 2011. doi:10.1007/978-  
1-60761-707-5  
11. Inaba H, Greaves M, Mullighan CG. Acute lymphoblastic leukaemia. _Lancet (London, England)_ .  
2013;381(9881):1943-1955. doi:10.1016/S0140-6736(12)62187-4  
12. Fish J, Lipton J, Lanzkowsky P, eds. _Lanzkowsky’s Manual of Pediatric Hematology and Oncology_ . 6th Editio.  
- Academic Press; 2016.  
12  
13. Biondi A, Schrappe M, De Lorenzo P, et al. Imatinib after induction for treatment of children and adolescents with Philadelphia-chromosome-positive acute lymphoblastic leukaemia (EsPhALL): a randomised, open-label, intergroup study. _Lancet Oncol_ . 2012;13(9):936-945. doi:10.1016/S1470-2045(12)70377-7  
14. Schultz KR, Carroll A, Heerema NA, et al. Long-term follow-up of imatinib in pediatric Philadelphia chromosomepositive acute  lymphoblastic leukemia: Children’s Oncology Group study AALL0031. _Leukemia_ . 2014;28(7):1467-1471. doi:10.1038/leu.2014.30  
15. Brown P, Inaba H, Annesley C, et al. Pediatric acute lymphoblastic leukemia, version 2.2020. _JNCCN J Natl Compr Cancer Netw_ . 2020;18(1):81-112. doi:10.6004/jnccn.2020.0001  
16. Hatta Y, Hayakawa F, Yamazaki E. JSH practical guidelines for hematological malignancies, 2018: I. leukemia-3. acute lymphoblastic leukemia/lymphoblastic lymphoma (ALL/LBL). _Int J Hematol_ . 2020;112(4):439-458. doi:10.1007/s12185-02002965-z  
17. Arber DA, Orazi A, Hasserjian R, et al. The 2016 revision to the World Health Organization classification of myeloid neoplasms and acute leukemia. _Blood_ . 2016;127(20):2391-2405. doi:10.1182/blood-2016-03-643544  
18. Jaffe E, Arber D, Campo E, Quintanilla-Fend L, Orazi A. _Hematopathology_ . 2nd Editio. Elsevier; 2016.  
19. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE. _Relatório de Recomendação n 475 (Novembro de_  
- _2019) - Reação Em Cadeia Da Polimerase - Transcriptase Reversa (RT-PCR) Qualitativa e Quantitativa (RT-QPCR) e_  
_Hibridização in Situ (ISH) Para o Diagnóstico e Monitoramento Da Leucemia Mieloide Crônica (LMC) E_ .; 2019.  
20. EMS S/A. _Bula Mesilato de Imatinibe, Comprimidos Revestidos, 100mg e 400mg_ .; 2017.  
21. Mainor CB, Duffy AP, Atkins KL, Kimball AS, Baer MR. Treatment of Philadelphia chromosome-positive acute lymphoblastic leukemia in  pregnancy. _J Oncol Pharm Pract  Off Publ Int  Soc Oncol Pharm Pract_ . 2016;22(2):374-377. doi:10.1177/1078155214568582  
22. Nakajima Y, Kuwabara H, Hattori Y, et al. Successful treatment of a pregnant woman with Philadelphia chromosomepositive acute  lymphoblastic leukemia. _Int J Hematol_ . 2013;97(3):427-429. doi:10.1007/s12185-013-1264-5  
23. Matsouka C, Marinopoulos S, Barbaroussi D, Antsaklis A. Acute lymphoblastic leukemia during gestation. _Med Oncol_ . 2008;25(2):190-193. doi:10.1007/s12032-007-9024-0  
24. Papantoniou N, Daskalakis G, Marinopoulos S, Anastasakis E, Mesogitis S, Antsaklis A. Management of pregnancy in adolescence complicated by acute lymphoblastic leukemia. _Fetal Diagn Ther_ . 2008;23(2):164-167. doi:10.1159/000111600  
25. Zaidi A, Johnson L-M, Church CL, et al. Management of Concurrent Pregnancy and Acute Lymphoblastic Malignancy in Teenaged Patients: Two Illustrative Cases and Review of the Literature. _J Adolesc Young Adult Oncol_ . 2014;3(4):160-175. doi:10.1089/jayao.2014.0014  
26. National Comprehensive Cancer Network. _NCCN Clinical Practice Guidelines in Oncology: Pediatric Acute Lymphoblastic Leukemia. Version 2.2021_ .; 2022. Disponível em:  
https://www.nccn.org/guidelines/guidelines-detail?category=1&id=1496  
27. Bernt KM, Hunger SP. Current concepts in pediatric Philadelphia chromosome-positive acute lymphoblastic  leukemia. _Front Oncol_ . 2014;4:54. doi:10.3389/fonc.2014.00054  
28. Jeha S, Coustan-Smith E, Pei D, et al. Impact of tyrosine kinase inhibitors on minimal residual disease and outcome in childhood Philadelphia chromosome-positive acute lymphoblastic leukemia. _Cancer_ . 2014;120(10):1514-1519. doi:10.1002/cncr.28598  
29. ClinicalKey. _Imatinib_ .; 2021.  
30. Schultz KR, Bowman WP, Aledo A, et al. Improved early event-free survival with imatinib in Philadelphia  
chromosome-positive  acute lymphoblastic leukemia: a children’s oncology group study. _J Clin Oncol  Off J Am Soc Clin Oncol_ . 2009;27(31):5175-5181. doi:10.1200/JCO.2008.21.2514  
13  
31. Schrappe M. Detection and management of minimal residual disease in acute lymphoblastic  leukemia. _Hematol Am Soc Hematol Educ Progr_ . 2014;2014(1):244-249. doi:10.1182/asheducation-2014.1.244  
32. Campana D. Minimal residual disease in acute lymphoblastic leukemia. _Hematol Am Soc Hematol Educ Progr_ . 2010;2010:7-12. doi:10.1182/asheducation-2010.1.7  
33. Slayton WB, Schultz KR, Jones T, et al. Continuous Dose Dasatinib Is Safe and Feasible in Combination with Intensive Chemotherapy in Pediatric Philadelphia Chromosome Positive Acute Lymphoblastic Leukemia (Ph+ ALL): Children’s Oncology Group (COG) Trial AALL0622. _Blood_ . 2012;120(21):137. doi:10.1182/blood.V120.21.137.137  
34. Bristol-Myers Squibb Farmacêutica LTDA. _SPRYCEL_ .; 2020.  
https://consultas.anvisa.gov.br/#/medicamentos/25351344647200695/?substancia=23691.  
35. Chang BH, Willis SG, Stork L, et al. Imatinib resistant BCR-ABL1 mutations at relapse in children with Ph+ ALL: a Children’s Oncology Group (COG) study. _Br J Haematol_ . 2012;157(4):507-510. doi:10.1111/j.1365-2141.2012.09039.x  
36. Molinos-Quintana A, Aquino V, Montero I, et al. Emerging BCR/ABL1 Mutations Under Treatment with Tyrosine Kinase Inhibitors in  Paediatric Acute Lymphoblastic Leukaemia. _Acta Haematol_ . 2015;134(2):71-75. doi:10.1159/000371831  
37. Jeha S, Coustan-Smith E, Pei D, et al. Impact of tyrosine kinase inhibitors on minimal residual disease and outcome in childhood Philadelphia chromosome-positive acute lymphoblastic leukemia. _Cancer_ . 2014;120(10):1514-1519. doi:10.1002/cncr.28598  
38. Ministério da Saúde. _Portaria No 375, de 10 de Novembro de 2009. Aprova o Roteiro a Ser Utilizado Na Elaboração de Protocolos Clínicos e Diretrizes Terapêuticas No Âmbito Da Sceretaria de Atenção à Saúde._ Brasilia; 2009.  
39. Brasil. Ministério da Saúde. Secretaria de Ciência, Tecnologia I e IE. _Relatório de Recomendação No. 584 (Dezembro de 2020) - Dasatinibe Para Adultos Com Leucemia Linfoblástica Aguda Cromossomo Philadelphia Positivo Resistentes/Intolerantes Ao Mesilato de Imatinibe_ .; 2020.  
40. Shea BJ, Reeves BC, Wells G, et al. AMSTAR 2: a critical appraisal tool for systematic reviews that include randomised  or non-randomised studies of healthcare interventions, or both. _BMJ_ . 2017;358:j4008. doi:10.1136/bmj.j4008  
41. Higgins J, Green S. _Cochrane Handbook for Systematic Reviews of Interventions._ ; 2011.  
42. Wells G, O’connel D, Peterson J, Welch V, Losos M, Tugwell P. The Newcastle-Ottawa Scale (NOS) for assessing the quality of nonrandomized studies in meta-analyses. 2013.  
43. Whiting PF, Rutjes AWS, Westwood ME, et al. QUADAS-2: a revised tool for the quality assessment of diagnostic  
accuracy studies. _Ann Intern Med_ . 2011;155(8):529-536. doi:10.7326/0003-4819-155-8-201110180-00009  
44. Ottmann O, Dombret H, Martinelli G, et al. Dasatinib induces rapid hematologic and cytogenetic responses in adult patients with  Philadelphia chromosome positive acute lymphoblastic leukemia with resistance or intolerance to imatinib: interim results of a phase 2 study. _Blood_ . 2007;110(7):2309-2315. doi:10.1182/blood-2007-02-073528  
45. Sakamaki H, Ishizawa K-I, Taniwaki M, et al. Phase 1/2 clinical study of dasatinib in Japanese patients with chronic myeloid  leukemia or Philadelphia chromosome-positive acute lymphoblastic leukemia. _Int J Hematol_ . 2009;89(3):332-341. doi:10.1007/s12185-009-0260-2  
46. Lilly MB, Ottmann OG, Shah NP, et al. Dasatinib 140 mg once daily versus 70 mg twice daily in patients with Ph-  
positive  acute lymphoblastic leukemia who failed imatinib: Results from a phase 3 study. _Am J Hematol_ . 2010;85(3):164-170. doi:10.1002/ajh.21615  
47. Zwaan CM, Rizzari C, Mechinaud F, et al. Dasatinib In Children and Adolescents with Relapsed or Refractory Leukemia: Results of the CA180018 Phase 1 Dose-Escalation Study of the Innovative Therapies for Children with Cancer (ITCC) Consortium. _Blood_ . 2010;116(21):2265. doi:10.1182/blood.V116.21.2265.2265  
48. Zwaan CM, Rizzari C, Mechinaud F, et al. Dasatinib in children and adolescents with relapsed or refractory leukemia: results  of the CA180-018 phase I dose-escalation study of the Innovative Therapies for Children with Cancer Consortium. _J_  
14  
_Clin Oncol  Off J Am Soc Clin  Oncol_ . 2013;31(19):2460-2468. doi:10.1200/JCO.2012.46.8280  
49. Zwaan M, Stork LC, Bertrand Y, et al. A phase II study of dasatinib therapy in children and adolescents with newly diagnosed chronic phase chronic myelogenous leukemia (CML-CP) or Philadelphia chromosome-positive (Ph+) leukemias resistant or intolerant to imatinib. _J Clin Oncol_ . 2012;30(15_suppl):TPS9594-TPS9594. doi:10.1200/jco.2012.30.15_suppl.tps9594  
50. Chang BH, Willis SG, Stork L, et al. Imatinib resistant BCR-ABL1 mutations at relapse in children with Ph+ ALL: a Children’s Oncology Group (COG) study. _Br J Haematol_ . 2012;157(4):507-510. doi:10.1111/j.1365-2141.2012.09039.x 51. Aoe M, Shimada A, Muraoka M, et al. ABL kinase mutation and relapse in 4 pediatric Philadelphia chromosomepositive  acute lymphoblastic leukemia cases. _Int J Hematol_ . 2014;99(5):609-615. doi:10.1007/s12185-014-1565-3  
52. Talpaz M, Shah NP, Kantarjian H, et al. Dasatinib in imatinib-resistant Philadelphia chromosome-positive leukemias. _N Engl J Med_ . 2006;354(24):2531-2541. doi:10.1056/NEJMoa055229  
15

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: MESILATO DE IMATINIBE -->
Eu, (nome do [a] paciente ou de seu responsável legal),declaro ter sido informado (a) claramente sobre os benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso de mesilato de imatinibe, indicado para o tratamento da Leucemia Mielóde Crônica com presença do cromossoma Philadelphia.  
Os  termos  médicos  foram  explicados  e  todas  as  dúvidas  foram  esclarecidas   pelo   médico <u>_____________(nome do médico que prescreve). Assim, declaro que fui claramente informado (a) de que o medicamento que</u> passo a tomar/fornecer ao meu (minha) filho (a) pode contribuir para trazer as seguintes melhoras:  
- recuperação das contagens celulares;  
- destruição das células malignas; e  
- diminuição do tamanho do fígado, do baço e outros locais, em decorrência da destruição dessas células.  
Fui também claramente informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos do uso do medicamento:  
- risco de uso no imatinibe na gravidez: caso o (a) doente engravide, deve avisar imediatamente o médico;  
- interação do imatinibe com outros medicamentos, por exemplo, anticonvulsivantes, antidepressivos, alguns  
- antitérmicos, remédios contra fungos e outros, o que exige a leitura detalhada das recomendações descritas pelo fabricante;  
- efeitos adversos mais comumente relatados: diminuição da produção dos glóbulos brancos, glóbulos vermelhos e  
- plaquetas, problemas no fígado e ossos, dores articulares e musculares, náusea, vômitos, alteração do metabolismo ósseo, certa diminuição da velocidade do crescimento, problemas respiratórios e cardíacos;  
- contraindicação em casos de hipersensibilidade (alergia) ao remédio; e  
- risco da ocorrência de efeitos adversos aumenta com a superdosagem.  
Estou ciente de que este medicamento somente pode ser utilizado por mim/meu (minha) filho (a), comprometendo-me a devolvê-lo ao hospital para que este o devolva à Assistência Farmacêutica da Secretaria Estadual de Saúde, caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que eu/meu (minha) filho (a)  continuarei/continuará a ser atendido (a), inclusive em caso de desistir de usar o medicamento.  
Autorizo o Ministério da Saúde e as secretárias de Saúde a fazerem uso de informações relativas ao tratamento do (a)  
meu (minha) filho (a) ou meu próprio, desde que assegurado o anonimato.  
- (   ) Sim (   ) Não  
Local: Data: Nome do paciente: Cartão Nacional de Saúde: Nome do responsável legal: Documento de identificação do responsável legal: Assinatura do responsável legal ou do paciente  
16  
Médico responsável: CRM: UF: Assinatura e carimbo do médico Data ~~<u>:</u>~~  
**Observação** : O medicamento deste termo é adquirido pelo Ministério da Saúde e fornecido a hospitais habilitados em oncologia no SUS pelas  
respectivas Secretarias Estaduais de Saúde.  
17  
**APÊNDICE 1**

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **METODOLOGIA** -->
Com a presença de quatro membros do Grupo Elaborador (2 especialistas e 2 metodologistas) e dois representantes do Comitê Gestor, uma reunião presencial para definição do escopo das Diretrizes Diagnósticas e Terapêuticas (DDT) foi conduzida. Todos os componentes do Grupo Elaborador preencheram o formulário de declaração de conflitos de interesse, que foram enviados ao Ministério da Saúde como parte dos resultados.  
Inicialmente, a macroestrutura das DDT foi estabelecida com base na Portaria n° 375/SAS/MS, de 10 de novembro de 2009<sup>38</sup> que define o roteiro para elaboração das DDT, definindo-se as seções do documento.  
Após essa definição, cada seção foi detalhada e discutida entre o Grupo Elaborador, com o objetivo de identificar as tecnologias que seriam consideradas nas recomendações. Com o arsenal de tecnologias previamente disponíveis no SUS, as novas tecnologias puderam ser identificadas.  
Os médicos especialistas do tema do presente documento foram, então, orientados a elencar questões de pesquisa, estruturadas de acordo com o acrônimo PICO ( **Figura A** ), para cada nova tecnologia não incorporada no Sistema Único de Saúde ou em casos de quaisquer incertezas clínicas. Não houve restrição do número de questões de pesquisa a serem elencadas pelos especialistas durante a condução dessa dinâmica.  
Ao final dessa dinâmica, duas questões de pesquisa foram definidas para as presentes DDT ( **Quadro A** ).  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questão de pesquisa definidas, por se tratar de prática clínica estabelecida, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento.  
As perguntas de pesquisa serviram para dar subsídio à escrita do texto. O dasatinibe, apesar de avaliado nessa diretriz, não foi considerado para incorporação para essa população, pois, como estabelecido em bula, esse medicamento não possui indicação para crianças e adolescentes. O mesmo medicamento foi apreciado pelo Plenário da Conitec, em sua 91ª reunião ordinária no dia 07 de outubro, para população adulta com LLA Ph+, e teve parecer preliminar desfavorável à incorporação<sup>39</sup> .  
As seções foram distribuídas entre os médicos especialistas (chamados relatores da seção), responsáveis pela redação da primeira versão da seção. A seção poderia ou não ter uma ou mais questões de pesquisa elencadas. Na ausência de questão de pesquisa (recomendações pautadas em prática clínica estabelecida e apenas com tecnologias já disponíveis no SUS), os especialistas foram orientados a referenciar a recomendação com base nos estudos pivotais que consolidaram a prática clínica. Quando a seção continha uma ou mais questões de pesquisa, os relatores, após atuação dos metodologistas (ver descrição a seguir), interpretavam as evidências e redigiam uma primeira versão da recomendação para ser discutida entre o painel de especialistas na ocasião do consenso.  
Coube aos metodologistas do Grupo Elaborador atuarem na elaboração das estratégias e busca nas bases de dados MEDLINE via Pubmed e Embase, para cada questão de pesquisa definida nas DDT. As bases de dados Epistemonikos e Google acadêmico também foram utilizadas para validar os achados das buscas nas bases primárias de dados.  
O fluxo de seleção dos artigos foi descritivo, por questão de pesquisa. A seleção das evidências foi realizada por um metodologista e respeitou o conceito da hierarquia das evidências. Dessa forma, na etapa de triagem das referências por meio da leitura do título e resumo, os estudos que potencialmente preenchessem os critérios PICO foram mantidos, independentemente do delineamento do estudo. Havendo ensaios clínicos randomizados, preconizou-se a utilização de revisões sistemáticas com  
18  
meta-análise. Havendo mais de uma revisão sistemática com meta-análise, a mais completa, atual e com menor risco de viés foi selecionada. Se a sobreposição dos estudos nas revisões sistemáticas com meta-análise era pequena, mais de uma revisão sistemática com meta- análise foi considerada. Quando a revisão sistemática não tinha meta-análise, preferiu-se considerar os estudos originais, por serem mais completos em relação às descrições das variáveis clínico- demográficas e desfechos de eficácia/segurança. Adicionalmente, checou-se a identificação de ensaios clínicos randomizados adicionais, para complementar o corpo das evidências, que poderiam não ter sido incluídos nas revisões sistemáticas com meta-análises selecionadas por conta de limitações na estratégia de busca da revisão ou por terem sido publicados após a data de publicação da revisão sistemática considerada. Na ausência de ensaios clínicos randomizados, priorizaram-se os estudos comparativos não randomizados e, por fim, as séries de casos. Quando apenas séries de casos foram identificadas e estavam presentes em número significante, definiuse um tamanho de amostra mínimo para a inclusão. Mesmo quando ensaios clínicos randomizados eram identificados, mas séries de casos de amostras significantes também fossem encontradas, estas também eram incluídas, principalmente para compor o perfil de segurança da tecnologia.  
Quando, durante o processo de triagem, era percebida a escassez de evidências, estudos similares que atuassem como provedores de evidência indireta para a questão de pesquisa também foram mantidos para posterior discussão para definir a inclusão ou não ao corpo da evidência. Os estudos excluídos tiveram suas razões de exclusão relatadas, mas não referenciadas, por conta da extensão do documento. Entretanto, suas respectivas cópias em formato PDF, correspondentes ao quantitativo descrito no fluxo de seleção, foram enviadas ao Ministério da Saúde como parte dos resultados do trabalho de elaboração das DDT. O detalhamento desse processo de seleção foi descrito por questão de pesquisa.  
Com o corpo das evidências identificado, procedeu-se à extração dos dados quantitativos dos estudos. A extração dos dados foi feita por um metodologista e revisado por um segundo, em uma única planilha. As características dos participantes nos estudos foram definidas com base na importância para interpretação dos achados e com o auxílio do especialista relator da questão. As características dos estudos também foram extraídas, bem como os desfechos de importância definidos na questão de pesquisa.  
O risco de viés dos estudos foi avaliado de acordo com o delineamento de pesquisa e ferramenta específica. Apenas a conclusão desta avaliação foi reportada. Se o estudo apresentasse baixo risco de viés, isso significaria que não havia nenhum comprometimento do domínio avaliado pela respectiva ferramenta. Se o estudo apresentasse alto risco de viés, os domínios da ferramenta que estavam comprometidos eram explicitados. Dessa forma, o risco de viés de revisões sistemáticas foi avaliado pela ferramenta _A Measurement Tool to Assess systematic Reviews 2_ (AMSTAR-2)<sup>40</sup> , os ensaios clínicos randomizados pela ferramenta de risco de viés da Cochrane<sup>41</sup> , os estudos observacionais pela ferramenta Newcastle-Ottawa<sup>42</sup> e os estudos de acurácia diagnóstica pelo _Quality Assessment of Diagnostic Accuracy Studies 2_ (QUADAS-2)<sup>43</sup> . Séries de casos que respondiam à questão de pesquisa com o objetivo de se estimar eficácia foram definidas a priori como detentoras de alto risco de viés.  
Após a finalização da extração dos dados, as tabelas foram editadas de modo a auxiliar na interpretação dos achados pelos especialistas. Para a redação da primeira versão da recomendação, essas tabelas foram detalhadas por questão de pesquisa.  
Todo o documento foi apresentado à 83ª Reunião da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas da Conitec, realizada no dia 20/10/2020, cujas solicitações foram incluídas na versão levada para o Plenário da Conitec, que, em sua 93ª Reunião Ordinária, realizada em 08 e 09 de dezembro de 2020,  avaliou e deliberou que fosse submetido à consulta pública. O retorno à Conitec deu-se em maio de 2021, quando o Plenário aprovou o Relatório de Recomendação das presentes diretrizes.  
19  
**Figura A** – Definição da questão de pesquisa estruturada de acordo com o acrônimo PICO  
<!-- Start of picture text -->
-<br><!-- End of picture text -->  
**Quadro A** – Questões de pesquisa elencadas pelo Grupo Elaboradordas Diretrizes Diagnósticas e Terapêuticas  
|Número|Descrição|Seção|
|---|---|---|
|1|Qual a eficácia e segurança do dasatinibe em<br>casos de resistência/refratariedade ao<br>imatinibe?|**Tratamento**|
|2|Quais são os locus que caracterizam<br>resistência aos inibidores da tirosinoquinase<br>TKIs (tratamento preconizado vs. tipos de<br>mutação/lócus)?|**Tratamento**|  
20

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **QUESTÕES DE PESQUISA** -->
**QUESTÃO DE PESQUISA 1:** Qual a eficácia e segurança do dasatinibe em casos de  resistência ou refratariedade ao imatinibe?  
Estratégia de busca MEDLINE via Pubmed:  
((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia))) AND ("Dasatinib"[Mesh] OR dasatinib OR  
BMS354825 OR Sprycel)) AND ((imatinib-refractory OR imatinib refractory OR imatinib resistance OR  
imatinib-resistant OR imatinib refractoriness) Total: 123 referências  
Data do acesso: 15/01/2017 EMBASE:  
'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim  
AND  
'dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim AND  
('imatinib refractory' AND [embase]/lim) OR (imatinib AND refractory AND [embase]/lim) OR (imatinib AND resistance AND [embase]/lim) OR ('imatinib resistant' AND [embase]/lim) OR (imatinib AND refractoriness AND [embase]/lim) Total: 146 referências  
Data do acesso: 16/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 269 referências (123 no MEDLINE e 146 no Embase). Destas, 55 foram excluídas por estarem duplicadas. Duzentas e quatorze referências foram triadas por meio da leitura de título e resumos, das quais 17 tiveram seus textos completos avaliados para confirmação da elegibilidade. Nessa etapa, 11 estudos foram excluídos, sendo duas por representarem revisões narrativas, uma revisão sistemática sem população de interesse e dois por avaliarem fases de LMC. Adicionalmente, quatro estudos, um em população pediátrica e três em população adulta, foram excluídos por considerarem participantes com LLA Ph+ e LMC em alguma fase, sem apresentarem os resultados por tipo de doença. Outro estudo avaliou o dasatinibe no pós-transplante em população pediátrica. Um último avaliou desfechos em seis pacientes com LLA Ph+ que receberam dasatinibe ou nilotinibe, sem apresentá-los de acordo com o medicamento que receberam. Ao final, seis publicações<sup>44–49</sup> , representando quatro estudos, foram consideradas elegíveis, apenas uma delas envolvendo crianças e adolescentes.  
Foram identificadas duas adicionais citações de resumos de congresso do mesmo estudo de Zwaan et al.<sup>47–49</sup> e três estudos em adultos<sup>44–46</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos encontra-se na **Tabela A** . As características dos pacientes encontram- se descritas na **Tabela B** . As **Tabelas C e D** apresentam dados de eficácia e segurança, respectivamente.  
**QUESTÃO DE PESQUISA 2:** Quais são os lócus que caracterizam resistência aos inibidores da tirosinoquinase TKIs  
21  
(tratamento preconizado versus tipos de mutação/locus)?  
Estratégia de busca MEDLINE via Pubmed:  
((("Precursor Cell Lymphoblastic Leukemia-Lymphoma"[Mesh] OR Acute Lymphoblastic Leukemia OR Leukemia, Lymphoblastic, Acute, Philadelphia-Positive OR Philadelphia chromosome-positive acute lymphoblastic leukemia OR Acute Lymphocytic Leukemia))) AND ((((tyrosine kinase inhibitors OR imatinib OR dasatinib))) AND ((("Genes, MDR"[Mesh] OR Multidrug Resistance Genes OR polymorphism OR polymorphisms) OR ("Locus Control Region"[Mesh] OR locus OR loci)))) Total: 35 referências  
Data de acesso: 15/01/2017 EMBASE:  
'acute lymphoblastic leukemia'/exp/mj AND [embase]/lim OR acute AND lymphoblastic AND leukemia AND philadelphia AND positive AND [embase]/lim  
AND  
('protein tyrosine kinase inhibitor'/exp OR 'protein tyrosine kinase inhibitor' AND [embase]/lim  
) OR (('tyrosine'/exp OR tyrosine AND ('kinase'/exp OR kinase) AND ('inhibitors'/exp OR inhibitors) AND [embase]/lim)) OR  
('dasatinib'/exp/mj AND [embase]/lim OR sprycel AND [embase]/lim) OR ('imatinib'/exp/mj AND [embase]/lim OR gleevec AND [embase]/lim OR glivec AND [embase]/lim)  
AND  
('gene locus'/exp OR 'gene locus' AND [embase]/lim) OR (multidrug AND ('resistance'/exp OR resistance) AND ('genes'/exp OR genes) AND [embase]/lim)  
AND  
('child'/exp/mj AND [embase]/lim) OR ('adolescent'/exp/mj AND [embase]/lim) OR ('children'/exp OR children AND [embase]/lim) OR (pediatric AND [embase]/lim) Total: 70 referências  
Data do acesso: 16/01/2017

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **Seleção das evidências** -->
A busca das evidências na base MEDLINE (via PubMed) e Embase resultou em 105 referências (35 no MEDLINE e 70 no Embase). Destas, 4 foram excluídas por estarem duplicadas. Cento e uma referências foram triadas por meio da leitura de título e resumos, das quais 19 tiveram seus textos completos avaliados para confirmação da elegibilidade. Dezesseis foram excluídos nessa etapa (três resumos de congresso): 15 (quinze) por avaliarem mutações em população adulta e um que, apesar de incluir dois participantes pediátricos, não permitiu identificar quais foram as mutações apenas nessa população. Apenas duas séries de casos incluindo população pediátrica foram identificadas<sup>50,51</sup> . Adicionalmente foi incluído um estudo que incluiu 84    pacientes – ainda que com apenas 10 com LLA em crise blástica ou LLA Ph+ e idade >14 anos – que apresentou mutações no início do estudo para este estrato de pacientes<sup>52</sup> .

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **Descrição dos estudos e seus resultados** -->
A descrição sumária dos estudos e as mutações encontradas referentes aos inibidores da tirosinoquinase encontram-se na **Tabela E** .  
22  
**Tabela A** – Características dos estudos  
|Autor, ano|Desenho de<br>estudo|Objetivo do<br>estudo|População|Detalhes da<br>Intervenção|Detalhes do<br>controle|<br>Risco de viés|
|---|---|---|---|---|---|---|
|Lilly et al.<br>2010<sup>46</sup>|<br>Ensaios clínico<br>randomizado<br>(fase III),<br>multicêntrico<br>(44 centros)<br>|<br>Comparar a<br>eficácia e a<br>segurança do<br>dasatinibe 140mg<br>1x ao dia versus<br>dasatinibe 70mg<br>2x ao dia.|Pacientes adultos<br>LLA Ph+<br>resistentes ou<br>intolerantes ao<br>imatinibe|Dasatinibe 140mg<br>1x ao dia,<br>continuado até a<br>progressão da<br>doença, toxicidade<br>inaceitável, ou<br>retirada a pedido do<br>paciente ou<br>investigador|Dasatinibe<br>70mg 2x ao<br>dia, no<br>mesmo<br>esquema de<br>continuação<br>da<br>intervenção|<br>Incerto: não há<br>descrição da<br>randomização e<br>garantia do sigilo<br>da alocação.|
|Ottmann<br>et al.<br>2007<sup>44</sup>|Série de<br>casos (estudo<br>fase II),<br>multicêntrico<br>|Avaliar<br>tolerabilidade,<br>eficácia e<br>segurança do<br>dasatinibe.|Pacientes adultos<br>LLA Ph+<br>resistentes ou<br>intolerantes ao<br>imatinibe|Dasatinibe 70mg 2x<br>ao dia (total 140mg)|NA|Alto risco:<br>série de casos,<br>população não<br>representativa.|
|Sakamaki<br>et al.<br>2009<sup>45</sup>|Série de casos<br>(estudo fase<br>II),<br>multicêntrico<br>(Japão)<br>|Avaliar eficácia<br>e segurança do<br>dasatinibe.|Pacientes Japoneses<br>adultos com LMC<br>fase crônica, fase<br>acelerada/blástica<br>ou LLA Ph+<br>resistentes ou<br>intolerantes ao<br>imatinibe (dados<br>apresentados para o<br>estrato LLA Ph+)|Dasatinibe 70mg 2x<br>ao dia (total 140mg)<br>por 12 semanas|NA|Alto risco: série<br>de casos,<br>população não<br>representativa.|
|Zwaan et<br>al.<br>2013<sup>47–49</sup>*|Série de casos<br>(estudo fase I<br>de<br>escalonamento<br>de dose),<br>multicêntrico<br>(6 centros)|Estabelecer a<br>dose para<br>estudo de fase<br>II, avaliar<br>tolerabilidade,<br>eficácia e<br>segurança do<br>dasatinibe.|Pacientes<br>pediátricos com<br>LMC, LMA, LLA<br>Ph+ ou LLA Ph-<br>previamente<br>expostas/refratárias<br>ao imatinibe (dados<br>apresentados para o<br>estrato LMC<br>avançada + LLA<br>Ph+)|Dasatinibe 1x ao<br>dia com dose<br>inicial de 60mg/m2<br>e aumento de dose<br>baseada na<br>tolerabilidade e<br>resposta individual<br>até 120mg/m2|NA|Alto risco: série<br>de casos,<br>população não<br>representativa.|  
LMC: Leucemia Mieloide Crônica; Ph+: cromossomo Philadelphia positivo; N: número de pacientes; NA: não se aplica.  
*Estudo envolvendo população pediátrica.  
23  
**Tabela B** – Características dos pacientes  
|Autor,<br>ano|N intervenção|N controle|Idade<br>Dasa|Idade,<br>controle|% sexo<br>masculino<br>Dasa|% sexo<br>masculino<br>controle|Tempo de<br>tratamento|Descontinuação n/<br>N (%)|Razão para<br>descontinuação<br>(n paciente)|Tempo de<br>seguimento|
|---|---|---|---|---|---|---|---|---|---|---|
|Lilly et al.<br>2010<sup>46</sup>|40|44|51,8 anos<br>(17–73)|51,0 anos<br>(15–80)|45|50|NR|38/40 (95) no grupo<br>intervenção e 41/44<br>(93) no grupo<br>controle|Progressão da doença<br>(28 vs. 33), toxicidade<br>(2 vs. 2), outras causas<br>(8 vs. 6)|2 anos|
|Ottmann<br>et al.<br>2007<sup>44</sup>|36|NA|46 anos<br>(15-85)|NA|64|NA|NR|27/36 (75)|Progressão da doença<br>(7), toxicidade (2),<br>outras causas (8)|8 meses|
|Sakamaki<br>et al.<br>2009<sup>45</sup>|<br>13|NA|64 anos<br>(29-70)|NA|NR|NA|11 semanas|7/13 (54)|Resposta insuficiente (6)<br>ou evento adverso (1)|<br>12 semanas|
|Zwaan et<br>al.<br>2013<sup>47–</sup><br>49*|17, sendo 14 com LLA<br>Ph+ e 3 com LMC<br>Avançada|<br>NA|10|NA|67|NA|3 meses<br>(0,5-37,7)|10/14 (59)|Resistência ou<br>refratariedade|24 meses|  
N: número de pacientes; Dasa: dasatinibe; n: número de pacientes que apresentaram o evento; DAP: Doença Arterial Periférica; NA: não se aplica; NR: não reportado. Quando não especificados, os dados foram apresentados em mediana (valor mínimo – valor máximo). *Estudo envolvendo população pediátrica.  
24  
**Tabela C** – Desfechos de eficácia  
|Autor, ano|Grupo|Mortalidade ou<br>Sobrevida|Respo|sta n/N (%)|Tempo até resposta|Duração da resposta|
|---|---|---|---|---|---|---|
||Dasa<br>140mg 1x|SLP: mediana 4,0|RHM: 38%<br>RHMe: 10%|RHC: 33%<br>SED: 5%|RHM (em até 4 meses):<br>1,2 (95% IC: 0,9-18)|RHM: 4,6 (IC95% NR)<br>RCC + parcial: 4,1 (IC95% NR)|
|||SG: mediana 6,5|RCC: 50%|RCP: 20%|RCC + parcial (em até 3 meses):<br>1,0 (IC 95% 1,0-1,3)|RCC: 4,3 (IC95% 3,7-6,9)|
||Dasa||RHM: 32%|RHC: 25%|RHM (em até 4 meses):|RHM: 11,5 (IC95% NR)|
|Lilly<br>et<br>a|l.<br>70mg 2x|SLP: mediana 3,1|RHMe: 9%|SED: 7%|1,0 (IC95%: 1,0-2,8)|RCC + parcial: 4,4 (IC95%|
|2010<sup>46</sup>||SG: mediana 9,1|RCC: 39%|RCP: 14%|RCC + parcial (em até 3 meses):<br>1,0 (IC95% 1,0-1,2)|NR) RCC: 5,5 (IC95% 3,3-<br>13,4)|
||p|SLP: mediana 0,73<br>SG: mediana 0,33|RHM: 0,65<br>Demais NR||NR|NR|
|Ottmann et al.<br>2007<sup>44</sup>|NA|Mortalidade: 4/36 (11)<br>SLP: mediana 3,3|RHM: 15/36 (<br>RHC: 12/36 (3<br>RHMe: 3/36 (8<br>RCMe: 1/36 (3|42) RHG:18/36 (50)<br>3) SED: 3/36 (8)<br>) RCC: 21/36 (58)<br>)|Mediana de 1,8 meses até RHM|Min 1,9; Máx 8,7 meses|
|Sakamaki et al.|NA|NR|RHM: 5/13 (38<br>SED: 4/13 (31|) RHC: 1/13 (8)<br>)<br>RHMe: 4/13 (31)|Mediana de 57 dias até RHM|NR|
|2009<sup>45</sup>|||RCC: 7/13 (54<br>RCP: 1/13 (8)|) RCC: 6/13 (46)|||
|Zwaan et al.<br>2013<sup>47–49</sup>*|NA|Mortalidade:<br>12/17(71)<br>SG: 8,6 (IC95% 3,9-22,5)<br>SLP: 4,9 (IC95% 1,2-8,4)|<br>RHM: 8/17 (47<br>RCM: 11/17 (6|) RHC: 6/17 (35)<br>5) RCC: 11/17 (65)|Todas as RHM foram atingidas em até 7<br>semanas|RHM: 4,4 (IC95% 3,5 - >=24)<br>RCC: 4,6 (IC95% 2,1 - 17,4)|  
N: número de pacientes; Dasa: dasatinibe; n: número de pacientes que apresentaram o evento; NA: não se aplica; NR: não reportado; SLP: Sobrevida Livre de Progressão; SG: Sobrevida Global; RHM: Resposta Hematológica  
Maior; RHC: Resposta Hematológica Completa; RHMe: Resposta Hematológica Menor; SED: Sem Evidência de Doença; RCC: Resposta Citogenética Completa; RCP: Resposta Citogenética Parcial; RHG: Resposta Hematológica Geral;  
25

---

<!-- METADADOS: doenca: Leucemia Linfoblástica Aguda Cromossoma Philadelphia Positivo de Crianças e Adolescentes (DDT) | secao: **Descrição dos estudos e seus resultados** -->
Quando não especificados, os dados foram apresentados em mediana (valor mínimo – valor máximo) ou mediana (intervalo de confiança de 95%) ou n/N (%).  
*Estudo envolvendo população pediátrica.  
26  
**Tabela D** – Eventos adversos  
||||Autor, ano|||
|---|---|---|---|---|---|
|Eventos|Lilly et al. 201|0<sup>46</sup>|Ottmann et al.|Sakamaki et al.|Zwaan et al.|
|adversos|||2007<sup>44</sup>|2009<sup>45</sup>|2013<sup>47–49</sup>*|
|(Grau 3-4)|Dasa<br>140mg 1xdia|Dasa<br>140mg<br>1xdia||||
|Anemia|14/40 (35)|14/40 (35)|17/36 (47)|4/13 (31)|6/17 (35,3)|
|Anorexia|0|0|NR|NR|NR|
|Ascite|0|0|NR|NR|NR|
|Astenia|NR|NR|3/36 (8)|NR|NR|
|Cefaleia|0|0|0|NR|0|
|Derrame pericárdico|0|0|NR|NR|NR|
|Derrame pleural|1/40 (3)|1/40 (3)|1/36 (8)|NR|NR|
|Diarreia|2/40 (5)|2/40 (5)|3/36 (8)|NR|0|
|Dispneia|1/40 (3)|1/40 (3)|1/36 (8)|NR|NR|
|Doença arterial periférica|NR|NR|NR|NR|NR|
|Dor em extremidades|NR|NR|NR|NR|0|
|Dor|0|0|NR|NR|0|
|musculoesquelética/Artralgi|a|||||
|Dorsalgia|NR|NR|NR|NR|0|
|Edema generalizado|0|0|NR|NR|NR|
|Edema periférico|NR|NR|0|NR|0|
|Edema pulmonar|0|0|NR|NR|NR|
|Edema superficial|0|0|NR|NR|NR|
|Edema periorbital|NR|NR|NR|NR|NR|
|Epistaxe|NR|NR|NR|NR|1/17 (5,9)|
|Fadiga|0|0|0|NR|0|
|Febre|0|0|1/36 (8)|NR|0|
|Gastrite|1/40 (3)|1/40 (3)|NR|NR|NR|
|Infecção|3/40 (8)|3/40 (8)|NR|NR|NR|
|Leucopenia|21/40 (53)|21/40 (53)|23/36 (64)|10/13 (77)|NR|
|Mal-estar|NR|NR|NR|NR|0|
|Nasofaringite|NR|NR|NR|NR|0|
|Náusea|1/40 (3)|1/40 (3)|0|NR|0|
|Neutropenia|NR|NR|23/36 (64)|10/13 (77)|9/17 (52,9)|
|Neutropenia febril|5/40 (13)|5/40 (13)|4/36 (11)|NR|NR|
|Perda de peso|NR|NR|0|NR|NR|  
27  
|Rash|0|0|1/36 (8)|NR|0|
|---|---|---|---|---|---|
|Rubor|NR|NR|NR|NR|NR|
|Sangramento cerebral|0|0|NR|NR|NR|
|Sangramento gastrointestinal|2/40 (5)|2/40 (5)|NR|NR|NR|
|Trombocitopenia|26/40 (67)|26/40 (67)|28/36 (72)|8/13 (62)|12/17 (70,6)|
|Ulceração oral|NR|NR|NR|NR|0|
|Urticária/Prurido|NR|NR|NR|NR|0|
|Vômito|0|0|0|NR|0|  
NR: não reportado. Dados foram apresentados em n/N (%).  
28  
**Tabela E** – Características dos estudos e as mutações referentes aos inibidores da tirosinoquinase  
|Autor,<br>ano|<br>Desenho de<br>estudo|Objetivo do estudo|População|N|Idade|Molécula|Método<br>de<br>avaliaçã<br>o da|Mutações|
|---|---|---|---|---|---|---|---|---|
||||||||mutação||
|Aoe et<br>al.<br>2014<sup>51</sup>|<br>Série de casos|Avaliar as mutações ABL<br>kinase e o uso apropriado de<br>iTK e transplante em<br>população pediátrica com<br>LLA Ph+.|<br>População pediátrica com LLA Ph+ que<br>recebeu tratamento com imatinibe e<br>transplante que apresentou mutação ABL<br>quinase ao diagnóstico de LLA|<br>Um caso<br>de 4<br>avaliados|9 anos|Imatinibe<br>dasatinibe|RT-PCR<br>quantitativo|Apenas o paciente 4 (9 anos)<br>apresentou a mutação ABL<br>quinase F359C. Após receber<br>dasatinibe, não apresentou<br>sensibilidade ao tratamento. A<br>mutação adicional F317I ocorreu<br>nesse paciente. O paciente<br>recebeu nilotinibe, mas também<br>não respondeu.|  
|Chang<br>et al.<br>2012<sup>50</sup><br>Séri<br>Autor, ano|e de casos<br>i<br>Desenho<br>estudo|Relatar duas mutações que<br>ocorreram em crianças<br>participantes do estudo<br>AALL0031, que utilizou<br>matinibe 340mg/m2/dia com<br>quimioterapia intensiva, por<br>mais de um ano.<br>de<br>Objetivo do<br>estudo<br>P|<br>Caso 1 – Adulto jovem de 23 anos de<br>idade, com células brancas de 117 × 10<sup>9</sup><br>células/L tratado por indução com<br>vincristina, asparginase, doxorubicina e<br>prednisona, alcançando remissão<br>completa morfológica e citogenética ao<br>final da indução. Recebeu terapia pós-<br>indução de acordo com a coorte 5 do<br>estudo AALL0031 (tratamento contínuo<br>com imatinibe, exceto por 2 semanas<br>cada 4 semanas durante os blocos de<br>manutenção 5 ao 12). Após 24 meses no<br>tratamento, apresentou recaída no<br>sistema nervoso central, sem leucemia<br>detectada na medula. caso 2 - não<br>especificado, apenasinforma que o<br>paciente tinha mais que um ano e teve a<br>recaída após 15 meses de tratamento.<br>opulação<br>N|2 casos,<br>de 10<br>avaliados<br>Id|2 anos de<br>idade e o<br>segundo não<br>especificado(><br>1 ano)<br>ade<br>M|<br>Imatinib<br>olécula|e<br>PCR<br>Método de<br>avaliação da<br>mutação|Caso 1 - substituição da guanina<br>por adenosina, produzindo uma<br>mutação missesnse da metionina<br>244 para     valina     (M244V).<br>Caso 2 - 15 meses após<br>diagnóstico - mutação histidina<br>396 para prolina (H396P), sem a<br>mutação ao diagnóstico.<br>Mutações|
|---|---|---|---|---|---|---|---|---|  
|Talpaz et al<br>2006<sup>52</sup>|.<br>Série de casos<br>(estudo fase 1<br>de<br>escalonamento<br>de dose,<br>unicêntrico)|Estabelecer a dose<br>para estudo de<br>fase II, avaliar<br>tolerabilidade,<br>efiácia e segurança<br>do dasatinibe.|Pacientes com pelo menos 14 anos<br>de idade com LMC Ph+ em fase<br>crônica, acelerada ou crise blástica,<br>ou LLA Ph+ com resistência ou<br>intolerância ao imatinibe|84, sendo 10<br>com LLA em<br>crise blástica<br>ou LLA Ph+.<br>Neste último<br>estrato, 60%<br>dos pacientes|Extrato LLA<br>Ph+ ou LLA<br>em crise<br>blástica: 50<br>(15-73)|Imatinibe|Amplificação do<br>DNA complementar<br>por RT-PCR|<br>T315I - 6/10 pacientes<br>apresentavam mutação T315I<br>no início do estudo (pacientes<br>resistentes ao imatinibe). No<br>decorrer do estudo, 4/84<br>apresentaram novas mutações,<br>no entanto, não foi descrito o|
|---|---|---|---|---|---|---|---|---|
|||||apresentaram<br>mutação<br>BCR-<br>ABL||||estrato a que esses pacientes<br>pertenciam.|  
N: número de pacientes; RT-PCR: transcriptase reversa – proteína C reativa.  
Quando não especificados, os dados foram apresentados em mediana (valor mínimo – valor máximo).

---

