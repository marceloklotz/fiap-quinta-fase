<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: PORTARIA N ~~º~~ -->
Aprova diretrizes gerais, amplia e incorpora procedimentos para a Atenção Especializada às Pessoas com Deficiência Auditiva no Sistema Único de Saúde (SUS).  
**O MINISTRO DE ESTADO DA SAÚDE** , no uso das atribuições que lhe confere o inciso II do parágrafo único do art. 87 de Constituição, e  
Considerando a Lei n ~~º~~ 8.080, de 19 de setembro de 1990, que dispõe sobre as condições para a promoção, proteção e recuperação da saúde, a organização e o funcionamento dos serviços correspondentes e dá outras providências;  
Considerando o Decreto n ~~º~~ 7.508, de 28 de junho de 2011, que regulamenta a Lei n ~~º~~ 8.080, de 1990, para dispor sobre a organização do Sistema Único de Saúde (SUS), o planejamento da saúde, a assistência à saúde e a articulação interfederativa, e dá outras providências;  
Considerando o Decreto n ~~º~~ 7.612, de 17 de novembro de 2011, que institui o Plano Nacional dos Direitos da Pessoa com Deficiência - Plano Viver sem Limite;  
Considerando a Portaria n ~~º~~ 4.279/GM/MS, de 30 de dezembro de 2010, que estabelece diretrizes para a organização da Rede de Atenção à Saúde no âmbito do SUS;  
Considerando a Portaria n ~~º~~ 793/GM/MS, de 24 de abril de 2012, que institui a Rede de Cuidados à Pessoa com Deficiência no âmbito do SUS;  
Considerando a Portaria n ~~º~~ 1.328/SAS/MS, de 3 de dezembro de 2012, que aprova as Diretrizes de Atenção à Triagem Auditiva Neonatal no âmbito do SUS;  
Considerando a Portaria n ~~º~~ 18/SCTIE/MS, de 10 de junho de 2014, que torna publica a decisão de incorporar procedimentos relativos à assistência hospitalar à saúde auditiva (implante coclear e prótese auditiva ancorada no osso) no SUS;  
Considerando a Deliberação da Comissão Nacional de Incorporação de Tecnologias  
(CONITEC) n ~~º~~ 69 de 2013;  
Considerando que, em determinados casos de deficiência auditiva, há a necessidade de se utilizar recursos e tecnologia mais avançados para sua recuperação e reabilitação;  
Considerando a necessidade de atualizar os critérios de indicação e contraindicação da cirurgia de implante coclear, e estabelecer os critérios de indicação e contraindicação da cirurgia de prótese auditiva ancorada no osso nos serviços habilitados pelo SUS;  
Considerando a magnitude social da deficiência auditiva na população brasileira e suas consequências; e  
Considerando a possibilidade de êxito de intervenção na história natural da deficiência, por intermédio de equipe multiprofissional e interdisciplinar, utilizando-se de métodos e técnicas terapêuticas específicas, resolve:

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: CAPÍTULO I DAS DISPOSIÇÕES GERAIS -->
Art. 1 ~~º~~ Esta Portaria aprova diretrizes gerais, amplia e incorpora procedimentos para a Atenção Especializada às Pessoas com Deficiência Auditiva no Sistema Único de Saúde (SUS).  
Art. 2 ~~º~~ O cuidado na Atenção Especializada às Pessoas com Deficiência Auditiva, em especial a indicação para tratamento cirúrgico e respectivo acompanhamento ambulatorial, deve obedecer aos critérios estabelecidos nas diretrizes gerais para a Atenção Especializada às Pessoas com Deficiência Auditiva no SUS, disponibilizada no endereço eletrônico http://www.portal.saude.gov.br.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: DOS CRITÉRIOS PARA HABILITAÇÃO À ATENÇÃO ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA -->
Art. 3 ~~º~~ O estabelecimento de saúde a ser habilitado deve oferecer ou promover ações e  
serviços de saúde em:  
I - promoção e prevenção das afecções otológicas e déficit auditivo, as quais devem ser desenvolvidas de maneira articulada com os programas e normas definidas pelo Ministério da Saúde, e pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios;  
II - diagnóstico e tratamentos clínico e cirúrgico destinados ao atendimento de pacientes com doenças otológicas e déficit auditivo, complementando a Rede de Atenção à Saúde (RAS), incluindo:  
a) atendimento ambulatorial e hospitalar de otorrinolaringologia, conforme o estabelecido na RAS pelo gestor local, mediante termo de compromisso firmado entre as partes, onde deverá constar a quantidade de consultas médicas otorrinolaringológicas a serem ofertadas, de acordo com o número total mínimo de cirurgia de implante coclear, prótese auditiva ancorada no osso e cirurgias otológicas, conforme detalhado no art. 12 e a proporcionalidade definida no anexo I; e  
b) exames de diagnose e terapia em otologia e fonoaudiologia, conforme procedimentos constantes na Tabela de Procedimentos, Medicamentos e OPM do SUS disponível no endereço eletrônico www.sigtap.datasus.gov.br, os quais estarão disponíveis para a RAS, cujos quantitativos serão acordados pelo gestor local;  
c) salas de cirurgia exclusivas ou eletivas, com possibilidade de reserva programada e disponibilidade de salas para absorver as intercorrências cirúrgicas do pós-operatório;  
III - atendimento de urgência nos casos de alterações otológicas e déficit auditivo, que funcione 24 (vinte e quatro) horas por dia, mediante termo de compromisso firmado com o gestor local do SUS; e  
IV - reabilitação, suporte e acompanhamento por meio de procedimentos específicos que promovam a melhoria das condições físicas e psicológicas do paciente, no preparo pré-operatório e no seguimento pós-cirúrgico, a fim de restituir sua capacidade funcional.  
Art. 4 ~~º~~ O  estabelecimento de saúde interessado na habilitação à Atenção Especializada às Pessoas com Deficiência Auditiva deverá apresentar requerimento à Secretaria de Saúde do Estado, do Distrito Federal ou do Município, contendo os seguintes documentos:  
I - documento de solicitação/aceitação de credenciamento por parte do estabelecimento de saúde assinado pelo diretor do hospital;  
II - indicação do médico especialista em otorrinolaringologia como responsável técnico, devidamente cadastrado no Sistema de Cadastro Nacional de Estabelecimentos de Saúde (SCNES); e  
III - relação da equipe do serviço, devidamente cadastrada no SCNES, com as respectivas titulações, conforme exigência do art. ~~8º~~ desta Portaria.  
§ 1 ~~º~~ O requerimento referido no “caput” será apreciado pela Secretaria de Saúde dos Estados, do Distrito Federal ou dos Municípios, que, se concordar, formalizará o processo e encaminhará à Coordenação-Geral de Média e Alta Complexidade (CGMAC/DAET/SAS/MS), os seguintes documentos:  
I - parecer conclusivo do gestor de saúde quanto ao credenciamento do interessado à Atenção Especializada às pessoas com Deficiência Auditiva;  
II - formulário de vistoria, disponível no endereço eletrônico www.saude.gov.br/sas, preenchido e assinado pelo respectivo gestor de saúde;  
III - relatório de vistoria local;  
IV - resolução do Colegiado Intergestores Regional (CIR), da Comissão Intergestores Bipartite (CIB), ou, quando for o caso, do Colegiado de Gestão da Secretaria de Saúde do Distrito Federal (CGSES/DF), contendo pactuação das ações e dos serviços necessários para a assistência à Atenção Especializada às pessoas com Deficiência Auditiva;  
V - declaração do impacto financeiro do serviço a ser habilitado, contendo a meta física e financeira, segundo os valores dos procedimentos constantes na Tabela de Procedimentos, Medicamentos e OPM do SUS; e  
VI - indicação do médico especialista em otorrinolaringologia como responsável técnico, devidamente cadastrado no SCNES.  
- § 2 ~~º~~ Na habilitação em Atenção Especializada às Pessoas com Deficiência Auditiva será  
- respeitada a seguinte ordem:  
I - estabelecimentos de saúde públicos;  
II - estabelecimentos de saúde privados filantrópicos; e  
III - estabelecimento de saúde privados com fins lucrativos.  
§ 3 ~~º~~ A Região de Saúde que já contemplar um estabelecimento com Atenção Especializada às Pessoas com Deficiência Auditiva e solicitar mais uma habilitação deverá justificar essa necessidade, apresentando as seguintes informações:  
I - realidade locorregional;  
II - demanda reprimida; e  
III - produção anual mínima estabelecida para cirurgias de implante coclear e prótese auditiva ancorada no osso e seus respectivos acompanhamentos, conforme estabelecido no art. 12.  
Art. 5 ~~º~~ O Ministério da Saúde avaliará os documentos encaminhados pela Secretaria de Saúde dos Estados, do Distrito Federal ou dos Municípios, referidos no art. 4 ~~º,~~ podendo visitar o estabelecimento de saúde interessado para confirmar as informações apresentadas pelo gestor de saúde estadual ou distrital.  
Parágrafo único.  Caso concorde com as informações apresentadas pela Secretaria de Saúde do Estado ou do Distrito Federal, o Ministro de Estado da Saúde publicará ato específico no Diário Oficial da União, habilitando o estabelecimento de saúde interessado à Atenção Especializada às Pessoas com Deficiência Auditiva.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: CAPÍTULO III -->
DAS CONDIÇÕES TÉCNICAS DOS ESTABELECIMENTOS DE SAÚDE HABILITADOS À ATENÇÃO ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA  
Art. 6 ~~º~~ A Atenção Especializada às Pessoas com Deficiência Auditiva será realizada pelos estabelecimentos de saúde que ofereçam apoio diagnóstico e terapêutico especializado, condições técnicas, instalações físicas, equipamentos e recursos humanos adequados ao atendimento ambulatorial e hospitalar, na mesma estrutura física.  
Art. 7 ~~º~~ O estabelecimento de saúde habilitado à Atenção Especializada às Pessoas com Deficiência Auditiva deve contar com um responsável técnico, médico otorrinolaringologista, com título de especialista da Associação Brasileira de Otorrinolaringologia e Cirurgia Cérvico Facial (ABORLCCF) e/ou certificado de Residência Médica na especialidade, emitido por Programa de Residência Médica reconhecido pelo Ministério da Educação (MEC).  
§ 1 ~~º~~ O médico referido no “caput” deste artigo somente poderá assumir a responsabilidade técnica por um único estabelecimento de saúde cadastrado no SUS, devendo residir no mesmo Município ou em cidades circunvizinhas.  
§ 2 ~~º~~ A responsabilidade técnica assumida pelo médico não o impede de exercer a medicina em outro estabelecimento de saúde credenciado pelo SUS.  
§ 3 ~~º~~ A equipe deve contar com, pelo menos, mais um médico otorrinolaringologista, especialista pela (ABORLCCF) ou titular de certificado de Residência Médica em Otorrinolaringologia emitido por Programa de Residência Médica reconhecido pelo MEC.  
Art. 8 ~~º~~ O estabelecimento de saúde habilitado à Atenção Especializada às Pessoas com Deficiência Auditiva deverá disponibilizar atendimento de enfermaria, ambulatorial e de intercorrências clínicas e cirúrgicas do pós-operatório.  
§ 1 ~~º~~ Para a prestação dos serviços de saúde descritos no “caput”, o estabelecimento de saúde deverá contar com equipe composta, no mínimo, dos seguintes profissionais:  
I - 2 (dois) Médicos Otorrinolaringologistas, com curso teórico prático de 60 (sessenta) horas em implante coclear e prótese ancorada no osso, estágio prático de 80 (oitenta) horas em ambulatório e acompanhamento de 10 (dez) cirurgias em adulto e 10 (dez) cirurgias em criança, realizadas nos Serviços de Implante Coclear habilitados, no mínimo, há 10 (dez) anos.  
II - 4 (quatro) fonoaudiólogos, sendo 2 (dois) deles com especialização em audiologia clínica e curso teórico prático de 60 (sessenta) horas em implante coclear e prótese ancorada no osso, estágio prático ambulatorial de 80 (oitenta) horas e acompanhamento de 10 (dez) cirurgias em adultos e 10 (dez) cirurgias em crianças, realizadas nos Serviços de Implante Coclear habilitados, no mínimo, há 10 (dez) anos.  
III - psicólogo, em quantitativo suficiente para o atendimento ambulatorial pré-cirúrgico de pacientes candidatos à cirurgia de implante coclear e/ou prótese auditiva ancorada no osso e para o acompanhamento pós-cirúrgico de pacientes implantados;  
IV - 1 (um) assistente social exclusivo para o atendimento ambulatorial pré-cirúrgico de pacientes candidatos à cirurgia de implante coclear e/ou prótese auditiva ancorada no osso e para o acompanhamento pós-cirúrgico de pacientes implantados;  
V - anestesiologista, com Certificado de Residência Médica reconhecido pelo MEC em Anestesia ou Título de Especialista em Anestesiologia emitido pela Sociedade Brasileira de Anestesiologia; e  
VI - na área de enfermagem, a equipe deve possuir 1 (um) enfermeiro coordenador, e, ainda, enfermeiros, técnicos de enfermagem e auxiliares de enfermagem em quantitativo suficiente para o atendimento de enfermaria.  
§ 2 ~~º~~ Os estabelecimentos de saúde atualmente habilitados que possuam 10 (dez) anos de habilitação junto ao Ministério da Saúde ou no mínimo 240 (duzentos e quarenta) implantes realizados estão isentos de apresentarem o curso teórico prático exigido para o médico otorrinolaringologista e para os fonoaudiólogos.  
Art. 9 ~~º~~ Os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva devem possuir, também, equipe complementar composta de clínico geral,  
neuropediatra, neurologista, pediatra, radiologista, cardiologista, anestesista, cirurgião plástico e geneticista, todos residentes no mesmo Município ou em cidades circunvizinhas.  
Parágrafo único.  Além da equipe complementar descrita no “caput”, os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva deverão prestar, na mesma área física, serviços de suporte, próprios ou contratados, nas seguintes áreas:  
I - nutrição; II - farmácia; III - hemoterapia; e IV - radiologia.  
Art. 10.  Os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva deverão dispor de: I - consultório médico com equipe e instrumental de otorrinolaringologia; II - consultórios médicos para as diferentes especialidades médicas; III - salas para o serviço de Audiologia Clínica; IV - salas para avaliação e terapia fonoaudiológica; V - salas para atendimento psicológico e para atendimento em serviço social; VI - salas para serviços administrativos; VII - recepção e sala de espera para acompanhantes; VIII - área para arquivo médico e registro de pacientes; IX - depósito de material de limpeza; e X - área para guarda de materiais e equipamentos.  
Art. 11.  Os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva deverão dispor de todos os materiais e equipamentos necessários, em perfeito estado de conservação e funcionamento, para assegurar a qualidade dos serviços de enfermagem, fonoaudiologia, nutricional e dietético, possibilitando o diagnóstico, o tratamento e o respectivo acompanhamento médico.  
§ 1 ~~º~~ Para o atendimento otorrinolaringológico ou otológico, os estabelecimentos de saúde deverão possuir os seguintes materiais: I - instrumental em otorrinolaringologia para atendimento ambulatorial; II - aspirador otológico de secreção; III - cadeira com comando elétrico ou mecânico (para exame físico); IV - cureta para remoção de cerumem; V - equipo de otorrinolaringologia (ORL); VI - 20 (vinte) unidades de espéculo auricular; VII - 10 (dez) unidades de espéculo nasal metálico; VIII - estilete para retirada de corpo estranho; IX - estilete porta algodão; X - fotóforo; XI - otoscópio; XII - ponta de aspiração otológica; e XIII - seringa metálica de 100 (cem) mililitros (ml) para remoção de cerumem.  
§ 2 ~~º~~ O serviço cirúrgico do estabelecimento de saúde deverá dispor de uma sala de cirurgia  
equipada com:  
I - microscópio cirúrgico, com vídeo e possibilidade de documentação científica; II - dois sistemas de brocas cirúrgicas com motor de alta rotação; III - monitor de nervo facial para uso transoperatório; IV - instrumental específico para cirurgia otológica de grande porte;  
V - computador e periféricos para monitoramento intra-operatório para telemetria de respostas neurais (NRT) e outras provas; VI - notebook; VII - raio X intraoperatório; VIII - interfaces e softwares para testes eletrofisiológicos intraoperatório e pós-operatório; IX - analisador de gases anestésicos; X - capnógrafo; XI - desfibrilador com pás externas e internas; XII - oxímetro de pulso; XIII - monitor de transporte; XIV - monitor de pressão não invasiva; XV - aquecedor de sangue; XVI - respirador a volume, com misturador tipo blender microprocessado; XVII - possibilidade de filtro bacteriológico, no aparelho respirador ou anestésico; XVIII - pelo menos 2 (duas) bombas de infusão; e XIX - 1 (um) termômetro termoeletrônico.  
§ 3 ~~º~~ Os estabelecimentos de saúde deverão possuir os seguintes materiais de avaliação e reabilitação audiológica: I - cabina acústica; II - audiômetro de dois canais; III - imitanciômetro multifrequencial; IV - sistema de campo livre; V - sistema completo de reforço visual; VI - emissões Otoacústicas (evocadas transientes e por produto de distorção); VII - potenciais Evocados Auditivos de curta, média e longa latência; VIII - equipamento de verificação eletroacústica – ganho de inserção; IX - interface de programação com todas as marcas de AASI (ex: HI-PRO, etc); X - conjuntos de modelos de AASI adequados aos diferentes graus e tipos de perda auditiva para testes de seleção (no mínimo 3 conjuntos);  
XI - programas de computação periféricos para programação de AASI; XII - conjunto de acessórios para AASI - testador de baterias, baterias, aspirador, estetoscópio, desumidificador, presilhas, alicate; XIII - caneta otoscópio, seringa e massa para pré-moldagem; XIV - materiais pedagógicos; XV - espelho Fixo; XVI - televisão e vídeo para o trabalho com crianças; XVII - conjunto básico de instrumentos musicais; e XVIII - brinquedos para ludoterapia e terapia fonoaudiológica.  
§ 4 ~~º~~ Os estabelecimentos de saúde deverão possuir os seguintes recursos auxiliares de diagnóstico e terapia:  
I - laboratório de análises clínicas, participante de programa de controle de qualidade, que realize exames de hematologia, bioquímica, microbiologia, gasometria, líquidos orgânicos e uroanálise, devendo o serviço estar disponível 24 (vinte e quatro) horas por dia;  
II - serviço de imagenologia integrante de programa de controle de qualidade, dotado de equipamento de Rx convencional de 500 mA fixo, equipamento de Rx portátil, Tomografia Computadorizada e Ressonância Magnética;  
III - hemoterapia disponível nas 24 (vinte e quatro) horas do dia, por Agência Transfusional (AT) ou estrutura de complexidade maior, conforme legislação vigente; e  
IV - Unidade de Tratamento Intensivo (UTI) com leitos habilitados pelo SUS.  
§ 5 ~~º~~ Os exames de tomografia e ressonância magnética poderão ser realizados por terceiros, instalados dentro ou fora da estrutura ambulatório-hospitalar, desde que sejam cadastrados no SCNES nessa qualidade.  
Art. 12.  O estabelecimento de saúde habilitado em Atenção Especializada às Pessoas com Deficiência Auditiva deve realizar, no mínimo:  
I - 24 (vinte e quatro) atos operatórios de implantes cocleares ao ano;  
II - 3 (três) cirurgias de prótese auditiva ancorada no osso ao ano;  
III - 144 (cento e quarenta e quatro) cirurgias otológicas ao ano, listadas no anexo II a esta Portaria, em pacientes do SUS; e  
IV - 480 (quatrocentos e oitenta) consultas otorrinolaringológicas ao ano.  
Art. 13.  Os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva deverão possuir prontuário único para cada paciente, no qual devem ser incluídos todos os atendimentos a ele referentes, contendo, no mínimo, as seguintes informações:  
I - identificação do paciente;  
II - histórico clínico;  
III - avaliação inicial;  
IV - indicação do procedimento cirúrgico, de acordo com o protocolo estabelecido;  
V - descrição do ato cirúrgico ou procedimento, em ficha específica, contendo:  
a) identificação da equipe; e  
b) descrição cirúrgica, incluindo materiais usados e seus respectivos registros nacionais, quando existirem, para controle e rastreamento de implantes;  
VI - descrição da evolução;  
VII - sumário de alta hospitalar; VIII - ficha de registro de infecção hospitalar; e  
IX - evolução ambulatorial.  
Art. 14.  Os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva deverão possuir rotinas e normas escritas, anualmente atualizadas e assinadas pelo Responsável Técnico pelo Serviço, devendo abordar todos os processos envolvidos na assistência e na administração, contemplando os seguintes itens:  
I - manutenção preventiva e corretiva de materiais e equipamentos;  
II - avaliação dos pacientes;  
III - indicação do procedimento cirúrgico;  
IV - protocolos médico-cirúrgicos;  
V - protocolos de enfermagem;  
VI - protocolos de avaliação auditiva;  
VII - protocolos para Suporte nutricional;  
VIII - controle de Infecção Hospitalar;  
IX - acompanhamento ambulatorial dos pacientes;  
X - protocolo de acompanhamento, manutenção preventiva e reabilitação fonoaudiológica; XI - avaliação de satisfação do cliente; e  
XII - escala dos profissionais em sobreaviso, das referências interinstitucionais e dos serviços terceirizados.  
CAPITULO IV  
DO FINANCIAMENTO  
Art. 15.  Os procedimentos da Tabela de Procedimentos, Medicamentos, Órteses/Próteses e Materiais Especiais, constantes no anexo III - B a esta Portaria, serão financiados por meio do Teto de Média e Alta Complexidade (MAC), pós-produção, em conformidade com o limite financeiro estabelecido em portaria específica.  
§ 1 ~~º~~ Farão jus ao recebimento do recurso financeiro de que trata o “caput” os estabelecimentos de saúde habilitados à Atenção Especializada às Pessoas com Deficiência Auditiva.  
§ 2 ~~º~~ O repasse dos recursos de que trata este artigo ocorrerá em conformidade com a produção dos respectivos procedimentos informados no Sistema de Informação Ambulatorial (SIA/SUS) e no Sistema de Informação Hospitalar (SIH/SUS), observado o limite financeiro estabelecido.  
§ 3 ~~º~~ O recurso financeiro previsto no “caput” será repassado pelo Fundo Nacional de Saúde para os fundos de saúde dos entes federativos beneficiários, respeitando-se a especificidade do serviço.  
§ 4 ~~º~~ Os recursos para financiamento dos procedimentos de que trata o "caput" permanecerão, por um período de 6 (seis) meses, sendo efetivados pelo Fundo de Ações Estratégicas e Compensação (FAEC) para a formação de série histórica necessária à sua incorporação ao Teto de Média e Alta Complexidade (MAC) dos Estados, do Distrito Federal e dos Municípios, conforme será definido em ato específico do Ministro de Estado da Saúde.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: DO MONITORAMENTO E AVALIAÇÃO -->
Art. 16.  Os estabelecimentos de saúde habilitados a prestarem a Atenção Especializada às Pessoas com deficiência auditiva no âmbito do SUS estarão submetidos à regulação, controle e avaliação pelos respectivos gestores públicos de saúde.  
Art. 17.  O Ministério da Saúde, através do Departamento de Regulação, Avaliação e Controle de Sistemas (DRAC/SAS/MS), em conjunto com a CGMAC/DAET/SAS/MS, monitorará e avaliará periodicamente o atendimento contínuo dos serviços prestados para manutenção do repasse dos recursos financeiros ao ente federativo beneficiário, de acordo com as informações constantes no SIA/SUS e no SIH/SUS.  
§ 1 ~~º~~ O estabelecimento de saúde que não cumprir as metas estabelecidas no art. 12 será notificado a respeito.  
§ 2 ~~º~~ No caso do § 1 ~~º~~ , o gestor público de saúde interessado em manter a habilitação do serviço encaminhará, ao Ministério da Saúde, justificativa sobre o não cumprimento da produção mínima exigida, no prazo de 15 (quinze) dias, a contar do recebimento da notificação.  
§ 3 ~~º~~ O Ministério da Saúde analisará a justificativa de que trata o § 2 ~~º~~ e decidirá pela manutenção da habilitação ou pela desabilitação do estabelecimento hospitalar.  
§ 4 ~~º~~ A desabilitação referida no § 3 ~~º~~ será processada pela edição de ato específico do Ministro de Estado da Saúde, com indicação do ente federativo desabilitado, nome e código SCNES do serviço desabilitado e o tipo de habilitação cancelada.  
§ 5 ~~º~~ O ente federativo desabilitado fica obrigado a restituir ao Ministério da Saúde os valores referentes ao período no qual não tenha cumprido as metas mínimas.  
Art. 18.  O monitoramento descrito no art. 17 não exonera a Secretaria de Saúde do respectivo ente federativo de avaliar, anualmente, o estabelecimento de saúde que lhe é vinculado, ou, ainda, em virtude de recomendação da CGMAC/DAET/SAS/MS, no que tange ao cumprimento das metas descritas no art. 12.  
§ 1 ~~º~~ Os relatórios gerados, incluindo avaliações anuais, qualitativas e quantitativas dos estabelecimentos produzidos, deverão ser encaminhados à CGMAC/DAET/SAS/MS para análise.  
§ 2 ~~º~~ A Secretaria de Atenção à Saúde, por meio da CGMAC/DAET/SAS/MS, determinará o descredenciamento ou a manutenção da habilitação, amparado no cumprimento das normas estabelecidas nesta Portaria, nos relatórios periódicos de avaliação e na produção anual.  
Art. 19.  O repasse dos incentivos financeiros de que trata esta Portaria será imediatamente  
interrompido quando:  
I - constatada, durante o monitoramento, a inobservância dos requisitos de habilitação e das demais condições previstas nesta Portaria; e  
II - houver falha na alimentação do SIA/SUS e SIH/SUS, por período igual ou superior a 3 (três) competências consecutivas, conforme determinação contida na Portaria n ~~º~~ 3.462/GM/MS, de 11 de novembro de 2010.  
Parágrafo único.  Uma vez interrompido o repasse do incentivo financeiro, novo pedido somente será deferido após novo procedimento de habilitação, em que fique demonstrado o cumprimento de todos os requisitos previstos nesta Portaria, hipótese em que o custeio voltará a ser pago, sem efeitos retroativos, a partir do novo deferimento pelo Ministério da Saúde.  
Art. 20.  Na hipótese de execução integral do objeto originalmente pactuado e verificada sobra de recursos financeiros, o ente federativo poderá efetuar o remanejamento dos recursos e a sua aplicação nos termos das Portarias n ~~º~~ 204/GM/MS, de 29 de janeiro de 2007, e n ~~º~~ 3.134/GM/MS, de 17 de dezembro de 2013.  
Art. 21.  Nos casos em que for verificada a não execução integral do objeto originalmente pactuado e a existência de recursos financeiros repassados pelo Fundo Nacional de Saúde para os Fundos de Saúde Estaduais, Distrital e Municipais não executados, seja parcial ou totalmente, o ente federativo estará sujeito à devolução dos recursos financeiros transferidos e não executados, acrescidos da correção monetária prevista em lei, observado o regular processo administrativo.  
Art. 22.  Nos casos em que for verificado que os recursos financeiros transferidos pelo Fundo Nacional de Saúde foram executados, total ou parcialmente em objeto distinto ao originalmente pactuado, aplicar-se-á o regramento disposto na Lei Complementar n ~~º~~ 141, de 3 de janeiro de 2012, e no Decreto n ~~º~~ 7.827, de 16 de outubro de 2012.  
Art. 23.  O monitoramento de que trata esta Portaria não dispensa o ente federativo beneficiário de comprovação da aplicação dos recursos financeiros percebidos por meio do Relatório Anual de Gestão (RAG).

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: DAS DISPOSIÇÕES TRANSITÓRIAS -->
Art. 24.  Os estabelecimentos atualmente habilitados em 0301 (Centros/Núcleos para Realização de Implante Coclear), segundo as regras da Portaria n ~~º~~ 1.278/GM/MS, de 20 de outubro de 1999, terão o prazo de 12 (doze) meses, a partir da publicação desta Portaria, para se adequarem às  
normas constantes deste ato normativo e requererem nova habilitação também nos termos deste ato normativo, sob pena de revogação da atual habilitação pelo Ministério da Saúde.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: CAPITULO VII DAS DISPOSIÇÕES FINAIS -->
Art. 25.  Compete ao estabelecimento de saúde da Atenção Especializada às Pessoas com Deficiência Auditiva avaliar e ofertar, dentro do período de garantia, as trocas e manutenções das OPME relacionadas à assistência que trata esta Portaria, após autorização do respectivo gestor.  
Art. 26.  As Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios adotarão as providências necessárias ao cumprimento das normas estabelecidas nesta Portaria, podendo estabelecer normas de caráter suplementar, a fim de adequá-las às especificidades locais ou regionais.  
Art. 27.  Eventual complementação dos recursos financeiros repassados pelo Ministério da Saúde para o custeio das ações previstas nesta Portaria é de responsabilidade conjunta dos Estados, do Distrito Federal e dos Municípios, em conformidade com a pactuação estabelecida na respectiva CIB e CIR.  
Art. 28.  Fica incluída a classificação 008 (Atenção Especializada às Pessoas com Deficiência Auditiva) no serviço de código 107 (Serviço de Atenção à Saúde Auditiva) da tabela de serviço/classificação do SCNES.  
Art. 29.  Ficam alterados, na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, os procedimentos descritos no item “A” do anexo III a esta Portaria.  
Art. 30.  Ficam incluídos, na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS, os procedimentos descritos no item “B” do anexo III a esta Portaria.  
Art. 31.  Ficam incluídas as compatibilidades entre os procedimentos da Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS relacionados no Anexo IV a esta Portaria.  
Art. 32.  A Autorização de Procedimento Ambulatorial (APAC) emitida para a realização do procedimento de manutenção da prótese de implante coclear (03.01.07.017-2) terá validade fixa de 12 (doze) competências.  
§ 1 ~~º~~ Na APAC inicial do procedimento descrito no “caput” do art. 13 deverá ser registrado o procedimento principal de manutenção com o quantitativo 1 (um), compatibilizando-o com os procedimentos secundários necessários e quantificados.  
§ 2 ~~º~~ A partir da segunda competência (APAC de continuidades), se houver necessidade de trocas, o procedimento principal de manutenção da prótese de implante coclear (03.01.07. 017-2) deverá ser registrado com o quantitativo zerado e os respectivos procedimentos secundários quantificados, durante o período de validade da APAC.  
Art. 33.  Os procedimentos incluídos nos termos do disposto no anexo III - B, e deverão ser utilizados pelos estabelecimentos habilitados em Atenção Especializada às Pessoas com deficiência auditiva, de acordo com o estabelecido no Capitulo IV.  
Art. 34.  As Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios devem estabelecer fluxos assistenciais para a Atenção Especializada às Pessoas com Deficiência Auditiva.  
Art. 35.  Os recursos orçamentários, de que trata esta Portaria, ocorrerão por conta do orçamento do Ministério da Saúde, devendo onerar o Programa de Trabalho 10.302.1220.8585 - Atenção à Saúde da População para Procedimentos de Média e Alta Complexidade.  
Art. 36.Caberá à Coordenação-Geral dos Sistemas de Informação (CGSI/DRAC/SAS/MS), adotar as providências necessárias junto ao Departamento de Informática do SUS (DATASUS/SGEP/MS) para o cumprimento do disposto nesta Portaria.  
Art. 37.  Esta Portaria entra em vigor na data de sua publicação, com efeitos operacionais nos sistemas na competência seguinte à sua publicação.  
Art. 38.  Fica revogada a Portaria n ~~º~~ 1.278/GM/MS, de 20 de outubro de 1999, publicada no Diário Oficial da União n ~~º~~ 202, Seção 1, do dia seguinte, p. 90.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: ARTHUR CHIORO -->
DAPO.NANDO/DVALLADAO

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: PROPORCIONALIDADE -->
|CIRURGIA DE IMPLANTE COCLEAR<br>(UNI OU BILATERAL)|CIRURGIA DE PROTESE<br>AUDITIVA ANCORADA NO OSSO|CIRURGIAS<br>OTOLOGICAS|CONSULTAS MÉDICAS<br>OTORRINOLARINGOLÓGICAS|
|---|---|---|---|
|08|1|32|80|

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: FORMULÁRIO DE VISTORIA DO GESTOR PARA HABILITAÇÃO DO ESTABELECIMENTO EM ATENÇÃO ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA -->
|Nome do estabelecimento: _______________________________________________________________|
|---|
|CNPJ: ____________________________________CNES:_____________________________________|
|Endereço: ____________________________________________________________________________|
|Município: _____________________________UF:___________________________________________|
|CEP:__________________________________Telefones: (    )__________________________________|
|Fax: (       ) ___________________________________________________________________________|
|E-mail:_______________________________________________________________________________|
|Diretor Técnico: _______________________________________________________________________|
|Telefones: (    )_______________________________Fax:  (    )_________________________________|
|E-mail: ______________________________________________________________________________|
|Gestor: ___________________________________Telefones: (    )_______________________________|
|Fax: (   )______________________________________________________________________________|
|E-mail: ______________________________________________________________________________|

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: NORMAS ESPECÍFICAS PARA HABILITAÇÃO EM ATENÇÃO ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA -->
- A) EXIGÊNCIAS GERAIS: 1. Parecer conclusivo do respectivo Gestor (Municipal e/ou Estadual) do SUS – manifestação expressa, firmada pelo Secretário da Saúde, em relação ao credenciamento:  
- _____________________________________________________________________________________ _____________________________________________________________________________________ _____________________________________________________________________________________ _________________________________________________________________________ 2. A aprovação da habilitação foi pactuada em CIB:       (   ) Sim         (   ) Não Informar CIB N ~~º:~~ _______________________Data: ______de ________________de__________. 3. Relatório de vistoria da VISA local com parecer conclusivo sobre a habilitação em pauta: (   ) Sim (   ) Não  
- B) EXIGÊNCIAS ESPECÍFICAS:  
1. Dispõe de estrutura física e funcional, com equipe multiprofissional devidamente qualificada e capacitada para a prestação de assistência especializada às pessoas com doenças otológicas e em especial às pessoas com deficiência auditiva a nível hospitalar.      (   ) Sim         (   ) Não  
2. Registro das informações do paciente em Serviço de Arquivo médico:   (   ) Sim         (   ) Não Prontuário único para cada paciente contendo todos os tipos de atendimentos a ele referentes conforme item 2, do anexo II.

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: 3. Recursos Humanos: -->
3.1 O Serviço conta com um responsável técnico, médico otorrinolaringologista, devidamente habilitado. (   ) Sim (   ) Não  
Nome:_____________________________________________________________________________ Registro Profissional: ________________________________________________________________  
3.1.1. O técnico é responsável por um único serviço credenciado pelo SUS  (   ) Sim   (   ) Não 3.1.2 - O técnico responsável reside no mesmo município ou cidade circunvizinha do serviço que está solicitando o credenciamento    (   ) Sim    (   ) Não 3.2. O Estabelecimento dimensiona a sua equipe multiprofissional de acordo com os parâmetros de equipe mínima e qualificação profissional       (   ) Sim         ) Não 4. Equipe básica (mínima): a - Otorrinolaringologista:     (   ) Sim     (   ) Não Quantos: Nome:________________________________________________Especialidade:___________________ Nome:________________________________________________Especialidade:___________________ Nome:________________________________________________Especialidade:___________________  
O Estabelecimento Possui:  
- Residência Médica em Otorrinolaringologia ou título de especialista em otorrinolaringologia. (   ) Sim   (   ) Não  
- Experiência em cirurgia otológica, com a carga horária exigida na Residência Médica.  
(   ) Sim   (   ) Não - curso teórico prático de 60 horas e estágio prático de 80 horas em ambulatório, acompanhamento de 10 cirurgias de IC em adulto e 10 cirurgias de implante coclear em criança comprovados nos Serviços de Implante Coclear habilitados no mínimo há 10 anos.(   ) Sim (   ) Não b - Fonoaudiólogo:     (   ) Sim     (   ) Não Quantos: - 02 Fonoaudiólogos com especialização em audiologia clínica e com curso teórico prático de 60 horas e estágio prático de 80 horas em ambulatório, acompanhamento de 10 cirurgias de IC em adulto e 10 cirurgias de implante coclear em criança comprovados nos Serviços de Implante Coclear habilitados no mínimo há 10 anos.         (   ) Sim      (   ) Não Nome:_____________________________________________________________________________ Especialidade:______________________________________________________________________ Nome:_____________________________________________________________________________ Especialidade:______________________________________________________________________ Nome:_____________________________________________________________________________ Especialidade:______________________________________________________________________ Nome:_____________________________________________________________________________ Especialidade:______________________________________________________________________ c - Psicólogo:      (   ) Sim     (   ) Não Quantos: Nome:_____________________________________________________________________________ Especialidade:______________________________________________________________________ d - Assistente Social:      (   ) Sim     (   ) Não  
|Quantos:|
|---|
|Nome:_____________________________________________________________________________|
|Especialidade:______________________________________________________________________|
|e - Anestesiologista:      (   ) Sim    (   ) Não<br>|
|Quantos:<br>|
|Nome:_____________________________________________________________________________<br>|
|Especialidade:______________________________________________________________________|
|f - Enfermagem:    (   ) Sim     (   ) Não<br>|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade:______________________________________________________________________|
|5. Equipe Complementar:<br>a - Neurologista:    (   ) Sim   (   ) Não|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|b -  Neuropediatra:     (   ) Sim    (   ) Não<br>|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|c - Geneticista     (   ) Sim   (   ) Não|
|Quantos:<br>|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|d - Clínico Geral     (   ) Sim  (   ) Não|
|Quantos:<br>|
|Nome:_____________________________________________________________________________|
|Especialidade_________________________________________________________________________|
|e - Pediatra     (   ) Sim   (   ) Não|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|f - cardiologista   (   ) Sim   (   ) Não|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|g - cirurgião plástico   (   ) Sim  (   ) Não|
|Quantos: (   )|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|h – nutricionista   (   ) Sim  (   ) Não|
|Quantos:|
|Nome:_____________________________________________________________________________|
|Especialidade_______________________________________________________________________|
|6. Infraestrutura Hospitalar:|
|a – Laboratório clínico   (   ) Sim  (   ) Não|
|Quantos:|  
_____________________________________________________________________________________ _____________________________________________________________________________________ ____________________________________________________________________________ b - diagnóstico por imagem    (   ) Sim   (   ) Não Quantos: _____________________________________________________________________________________ _____________________________________________________________________________________ ____________________________________________________________________________ c - farmácia     (   ) Sim    (   ) Não Quantos: _____________________________________________________________________________________ _____________________________________________________________________________________ ____________________________________________________________________________ OBSERVAÇÕES: Os estabelecimentos poderão contratar serviços especializados de terceiros a seu critério e responsabilidade, desde que isso não comprometa a integralidade e interdisciplinaridade do tratamento ofertado ao paciente.  
|7 - Instalações físicas:<br>O Estabelecimento possui:||
|---|---|
|a - Consultório Médico com equipe e instrumental de otorrinolaringologia, incluin<br>otológico   (   ) Sim   (   ) Não|do microscópio|
|Quantos:||
|b - Consultórios Médicos para as diferentes especialidades médicas (neurologia, genética e<br>(   ) Sim|pediatria<br>(   ) Não|
|Quantos:||
|c - Serviço de Audiologia Clínica com salas equipadas com: cabine acústica, VR<br>imitanciômetro, BERA, amplificadores coletivos, vibradores táteis, ganho de inserç<br>otoacústicas, equipamentos para testes perceptuais e conjuntos para teste de diferentes mo<br>Hardware, Software e periféricos para ativação, mapeamento e balanceamento de eletrodo<br>(   ) Sim|A, audiômetro,<br>ão e emissões<br>delos de AASI,<br>s<br>(   ) Não|
|d - Sala para avaliação e terapia fonoaudiológica<br>(   ) Sim|(   ) Não|
|Quantos:||
|e - Sala para atendimento psicológico e serviço social<br>(   ) Sim|(   ) Não|
|Quantos:||
|f - Sala para serviços administrativos<br>(   ) Sim|(   ) Não|
|Quantos:||
|g - Sala de recepção e de espera para acompanhantes<br>(   ) Sim|(   ) Não|
|Quantos:<br>||
|h - Área de arquivo médico e registro de pacientes<br>(   ) Sim|(   ) Não|
|Quantos:||
|i - Depósito de material de limpeza<br>(   ) Sim|(   ) Não|
|Quantos:<br>||
|j - Área para guardar materiais/ equipamentos||  
(   ) Sim (   ) Não

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: OBSERVAÇÕES: -->
|a - deverão ser utilizados equipamentos de implante coclear e prótese auditiva ancorada no osso|
|---|
|devidamente registrados na Agência Nacional de Vigilância Sanitária – ANVISA, do Ministério da Saúde<br>- MS.|
|b - fica a critério do estabelecimento a escolha do equipamento mais indicado para cada caso.|
|8 – Materiais e equipamentos|
|8.1 - Dos materiais de atendimento otorrinolaringológico/ otológica:|
|a - instrumental em otorrinolaringologia para atendimento ambulatorial                         (   ) Sim    (   ) Não|
|b - aspirador otológico de secreção                                                                                   (   ) Sim    (   ) Não|
|c - cadeira com comando elétrico ou mecânico (para exame físico)                                 (   ) Sim    (   ) Não|
|d - cureta para remoção de cerúmen                                                                                  (   ) Sim   (   ) Não|
|e - equipo de ORL                                                                                                              (   ) Sim   (   ) Não|
|f - espéculo auricular (20 unidades )                                                                                  (   ) Sim   (   ) Não|
|g - espéculo nasal metálico (10 unidades)                                                                          (   ) Sim   (   ) Não|
|h - estilete para retirada de corpo estranho                                                                         (   ) Sim   (   ) Não|
|i - estilete porta algodão                                                                                                    (   ) Sim   (   ) Não|
|j - fotóforo                                                                                                                        (   ) Sim   (   ) Não|
|k - otoscópio                                                                                                                     (   ) Sim   (   ) Não|
|l - ponta de aspiração otológica                                                                                        (   ) Sim   (   ) Não|
|m - seringa metálica de 100 ml para remoção de cerumem                                               (   ) Sim   (   ) Não|
|8.2<br>-  Dos materiais destinados à atividade cirúrgica|
|a - Microscópio cirúrgico, com vídeo e possibilidade de documentação científica            (   ) Sim  (   ) Não|
|Quantos:|
|b - dois sistemas de brocas cirúrgicas com motor de alta rotação                                       (   ) Sim  (   ) Não|
|<br>Quantos:|
|c - Monitor nervo facial transoperatório                                                                             (   ) Sim   (   ) Não|
|Quantos:|
|d - instrumental específico para cirurgia otológica de grande porte                                 (   ) Sim    (   ) Não|
|Quantos:|
|e - computador e periféricos para monitoramento intra-operatório para telemetria de respostas neurais|
|(NRT)  e outras provas                                                                                                       (   ) Sim   (   ) Não|
|Quantos:|
|f – notebook                                                                                                                        (   ) Sim   (   ) Não|
|Quantos:|
|g - raio X intraoperatório                                                                                                    (   ) Sim   (   ) Não|
|Quantos:|
|h - interfaces e softwares para testes eletrofisiológicos intraoperatório e|
|pós-operatório                                                                                                                     (   ) Sim   (   ) Não|
|Quantos:|
|i - analisador de gases anestésicos                                                                                      (   ) Sim   (   ) Não|
|Quantos:|
|<br>j - capnógrafo                                                                                                                      (   ) Sim   (   ) Não|
|<br>Quantos:|
|k - desfibrilador com pás externas e internas                                                                     (   ) Sim    (   )Não|
|Quantos:|
|l - oxímetro de pulso                                                                                                          (   ) Sim    (   ) Não|  
|Quantos:|
|---|
|m - monitor de transporte                                                                                                   (   ) Sim   (   ) Não|
|Quantos:|
|n - monitor de pressão não invasiva                                                                                   (   ) Sim   (   ) Não|
|Quantos:|
|o - aquecedor de sangue                                                                                                     (   ) Sim   (   ) Não|
|Quantos:|
|p - respirador a volume, com misturador tipo blender microprocessado                           (   ) Sim   (   ) Não<br>Quantos:|
|q - possibilidade de filtro bacteriológico, no aparelho respirador ou anestésico                (   ) Sim   (   ) Não<br>Quantos:<br>|
|r - 02 bombas de infusão, no mínimo                                                                                 (   ) Sim   (   ) Não<br>|
|Quantos:|
|s - 01 termômetro termoeletrônico                                                                                     (   ) Sim   (   ) Não|
|Quantos:|
|t - Equipamento de telemetria para aferição pós-operatório                                              (   ) Sim    (   ) Não|
|Quantos:|
|u - Sistema motor (brocas cirúrgicas)                                                                                 (   ) Sim   (   ) Não|
|Quantos:|
|v - Sistema de vídeo documentação                                                                                   (   ) Sim   (   ) Não|
|Quantos:|
|w - Condições bloco cirúrgico - favorável                                                                        (   ) Sim    (   ) Não|
|Quantos:|
|x - Condições anestésicas - favorável                                                                                (   ) Sim    (   ) Não|
|Quantos:|
|y - Condições UTI - favorável                                                                                            (   ) Sim   (   ) Não|
|8.3 - Dos materiais de avaliação e reabilitação audiológica:|
|a - Cabina acústica                                                                                                              (   ) Sim   (   ) Não|
|Quantos:|
|b - Audiômetro de dois canais                                                                                            (   ) Sim   (   ) Não|
|Quantos:|
|c - Imitanciômetro multifrequencial                                                                                   (   ) Sim   (   ) Não|
|Quantos:|
|d - Sistema de campo livre                                                                                                 (   ) Sim   (   ) Não|
|Quantos:|
|e - Sistema completo de reforço visual                                                                               (   ) Sim   (   ) Não|
|Quantos:|
|f -  Emissões Otoacústicas (evocadas transientes e por produto de distorção)                  (   ) Sim    (   ) Não|
|Quantos:|
|g - Potenciais Evocados Auditivos de curta, média e longa latência                                 (   ) Sim   (   ) Não|
|Quantos:|
|h - Equipamento de verificação eletroacústica – ganho de inserção                                  (   ) Sim   (   ) Não<br>Quantos:|
|i - Interface de programação com todas as marcas de AASI (ex: HI-PRO, etc)                (   ) Sim   (   ) Não|
|Quantos:|
|j - Conjuntos de modelos de AASI adequados aos diferentes graus e tipos de perda auditiva para testes de|
|seleção (no mínimo 3 conjuntos)                                                                                        (   ) Sim   (   ) Não|
|Quantos:|
|k - Programas de computação periféricos para programação de AASI                              (   ) Sim   (   ) Não<br>Quantos:|  
l - Conjunto de acessórios para AASI - testador de baterias, baterias, aspirador, estetoscópio, desumidificador, presilhas, alicate                                                                                     (   ) Sim   (   ) Não Quantos: m - Caneta otoscópio, seringa e massa para pré-moldagem                                               (   ) Sim   (   ) Não Quantos: n - Materiais pedagógicos                                                                                                   (   ) Sim   (   ) Não Quantos: o - Espelho Fixo                                                                                                                  (   ) Sim   (   ) Não Quantos: p - Televisão e vídeo para o trabalho com crianças                                                            (   ) Sim   (   ) Não Quantos: q - Conjunto básico de instrumentos musicais                                                                   (   ) Sim   (   ) Não Quantos: r - Brinquedos para ludoterapia e terapia fonoaudiológica                                                 (   ) Sim   (   ) Não Quantos: 9. - Recursos Auxiliares de Diagnóstico e Terapia a - Laboratório de Análises Clínicas que realize exames na unidade, disponíveis nas 24 horas do dia de hematologia, bioquímica; microbiologia, gasometria, líquidos orgânicos e uroanálise.  
O Laboratório deverá participar de Programa de Controle de Qualidade  
b - Serviço de Imagenologia: equipamento de Rx convencional de 500 mA fixo, equipamento de Rx portátil,  Tomografia Computadorizada e Ressonância Magnética. O serviço de Imagenologia deverá participar de Programa de Controle de Qualidade.                                                             (   ) Sim   (   ) Não c - Hemoterapia disponível nas 24 horas do dia, por Agência Transfusional (AT) ou estrutura de complexidade maior, conforme legislação vigente.                                                           (   ) Sim   (   ) Não  
d - Unidade de Tratamento Intensivo (UTI) com leitos habilitados pelo SUS, conforme legislação vigente. (   ) Sim   (   ) Não

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: 10. - Registro de Pacientes -->
Os estabelecimentos devem possuir um prontuário para cada paciente, com as informações sobre sua doença, seus diagnósticos, resultados de exames e tratamentos prévios, todos devidamente escritos, de forma clara e precisa, datadas e assinadas pelo profissional responsável pelo atendimento. Os prontuários deverão estar devidamente ordenados no Serviço de Arquivo Médico. Informações e procedimentos mínimos:  
- Identificação do paciente                                                                                                  (   ) Sim   (   ) Não - Histórico clínico e audiológico                                                                                        (   ) Sim   (   ) Não - Diagnóstico                                                                                                                      (   ) Sim   (   ) Não - Indicação do Implante Coclear                                                                                         (   ) Sim   (   ) Não - Descrição do ato cirúrgico                                                                                               (   ) Sim   (   ) Não - Condições na alta hospitalar e na retirada dos pontos                                                      (   ) Sim   (   ) Não - Acompanhamento do paciente com implante coclear nas etapas, conforme anexo I - Diretrizes Gerais para a Atenção às Pessoas com Deficiência Auditiva no âmbito hospitalar no Sistema Único de Saúde – SUS, item D:  
<u>Transoperatório: potencial evocado eletricamente no sistema auditivo (telemetrias - impedância e</u> compliância dos eletrodos, telemetria de respostas neurais)                                       (   ) Sim   (    ) Não <u>Ativação: do dispositivo interno (eletrodo), com adaptação da unidade externa, no prazo máximo de 45</u> dias após o ato cirúrgico (salvo nos casos de contraindicação clínica). Na ocasião deverão ser realizadas: telemetria neural, impedância dos eletrodos, medidas psicofísicas do implante coclear (programação ou  
mapeamento), avaliação dos limiares em campo livre com o Implante e avaliações e orientações clínicas pertinentes.                                                                                                                        (   ) Sim   (    ) Não

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: Frequência dos acompanhamentos: -->
Crianças:  
- Primeiro ano de uso: 6 (seis) acompanhamentos  
- Segundo ano de uso: 4 (quatro) acompanhamentos  
- Terceiro ano de uso:  
Para crianças de até três anos de idade: 4 (quatro) acompanhamentos  
Para crianças com mais de três anos de idade: 2 (dois) acompanhamentos  
- A partir do quarto ano: anualmente (uma vez/ano).

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: Adultos: -->
- Primeiro ano de uso: 4 (quatro) acompanhamentos;  
- Segundo ano de uso: 2 (dois) acompanhamentos;  
- A partir do quarto ano: anualmente (uma vez/ano).

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: **INFORMAÇÕES ADICIONAIS:** -->
Anexar cópia do diploma de graduação, títulos, curso de capacitação e comprovantes de experiência dos profissionais.  
INTERESSE DO GESTOR (ESTADUAL OU MUNICIPAL) NO CREDENCIAMENTO:  
__________________________________________________________________________________ __________________________________________________________________________________ __________________________________________________________________________________

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: CONCLUSÃO: -->
De acordo com vistoria realizada _in loco_ , no dia___/___/______a Instituição cumpre com os requisitos da Portaria SAS/MS nº XXX, de XXX de XXX de 2013. OBSERVAÇÕES:  
_________________________________________________________________________________ _____________________________________________________________________________________ _____________________________________________________________________________________ ____________________________________________________________________________  
LOCAL / DATA: _________________________________________  
CARIMBO E ASSINATURA DO GESTOR: ___________________

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: PROCEDIMENTOS PARA ASSISTÊNCIA ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA NA TABELA DE PROCEDIMENTOS, MEDICAMENTOS E OPM DO SUS -->
|Procedimento:|02.11.07.007-6- AVALIACAO DE LINGUAGEM ORAL|
|---|---|
|Instrumento de Registro:|01 - BPA (Consolidado)<br>02 – BPA (Individualizado)<br>05 - AIH (Proc. Secundário)<br>07 – APAC(Proc. Secundário)|
|Procedimento:|03.01.07.001-6 - ACOMPANHAMENTO DE PACIENTE C/ IMPLANTE<br>COCLEAR|
|Descrição:|Consiste no acompanhamento de paciente com implante coclear para ativação<br>e/ou mapeamento e balanceamento dos eletrodos, avaliação do desempenho e<br>orientações de cuidados e manutenção.|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9, H93.3, H93.8, H93.9, H94.0.|
|Procedimento:|07.02.09.003-4 - PROTESE P/ IMPLANTE COCLEAR MULTICANAL|
|Descrição:|Consiste em umaprótese auditiva implantável|
|Procedimento:|04.04.01.014-8 - IMPLANTE COCLEAR|
|Descrição:|Consiste na implantação cirúrgica unilateral de feixe de eletrodos posicionado<br>dentro da cóclea com objetivo de substituir parcialmente as funções da orelha<br>interna(cóclea),transformando os sinais sonoros em sinais elétricos.|
|Quantidade Máxima:|1|

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: PROCEDIMENTOS PARA ASSISTÊNCIA ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA NA TABELA DE PROCEDIMENTOS, MEDICAMENTOS E OPM DO SUS -->
|Procedimento:|02.11.07.037-8 - AVALIAÇÃO E SELEÇÃO PRÉ-CIRÚRGICA PARA<br>IMPLANTE COCLEAR|
|---|---|
|Descrição:|Consiste na avaliação dos candidatos ao implante coclear realizada pela equipe<br>multidisciplinar, incluindo as seguintes avaliações: avaliação<br>otorrinolaringológica, avaliação psicológica, avaliação de serviço social,<br>avaliação audiológica (audiometria tonal limiar ou audiometria de reforço visual<br>(VRA) ou audiometria condicionada lúdica por via aérea e via óssea;<br>logoaudiometria (LDV, LRF, IRF); imitanciometria, potencial evocado auditivo<br>de curta, média e/ou longa latência, emissões otoacústicas evocadas transiente<br>e/ou produto de distorção e pesquisa do ganho funcional) e avaliação de<br>linguagem.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 - Ambulatorial|
|Instrumento de Registro:|APAC(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$46,56|
|Valor Ambulatorial Total:|R$46,56|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|  
|Sexo:<br>|Ambos<br>|
|---|---|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|02.11.07.038-6– MAPEAMENTO E BALANCEAMENTO DOS ELETRODOS|
|Descrição:|Consiste nos procedimentos de programação e balanceamento dos eletrodos, ou<br>seja, estabelecer os parâmetros, em cada mapa, de como será a conversão dos<br>sinais acústicos em elétricos e medir os níveis de corrente necessários para a<br>estimulação elétrica em níveis audíveis e confortáveis em todo o feixe de<br>eletrodos,estabelecendo a área dinâmicapara estimulação elétrica.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|APAC(Proc. Secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$33,91|
|Valor Ambulatorial Total:|R$33,91|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|02.11.07.039-4 – POTENCIAL EVOCADO ELETRICAMENTE NO SISTEMA<br>AUDITIVO|
|Descrição:|Consiste na pesquisa do potencial evocado eletricamente no sistema auditivo<br>utilizando o próprio implante para eliciar o estímulo elétrico (usando o<br>processador de fala) e registrando a resposta por meio do equipamento de<br>potenciais evocados.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 - Ambulatorial,02 - Hospitalar,03 - Hospital Dia|
|Instrumento de Registro:|05 - AIH(Proc. Especial),07 - APAC(Proc. Secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$93,76|
|Valor Ambulatorial Total:|R$93,76|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|  
|Valor Hospitalar Total:<br>Sexo:|R$0,00<br>Ambos|
|---|---|
|<br>Idade Mínima:|<br>0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|02.11.07.040-8 – REFLEXO ESTAPEDIANO ELICIADO ELETRICAMENTE|
|Descrição:|Consiste na pesquisa do reflexo estapediano estimulado com sinal elétrico do<br>implante coclear|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 - Ambulatorial,02 - Hospitalar,03 - Hospital Dia|
|Instrumento de Registro:|05 - AIH(Proc. Secundário),07 - APAC(Proc. Secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$46,00|
|Valor Ambulatorial Total:|R$46,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|02.11.07.041-6 - AVALIAÇÃO E SELEÇÃO PRÉ-CIRÚRGICA PARA<br>PRÓTESE AUDITIVA ANCORADA NO OSSO|
|Descrição:|Consiste na avaliação dos candidatos a prótese auditiva ancorada no osso<br>realizada pela equipe multidisciplinar, incluindo as seguintes avaliações:<br>avaliação otorrinolaringológica, avaliação psicológica, avaliação de serviço<br>social, avaliação audiologica (audiometria tonal limiar ou audiometria de reforço<br>visual (VRA) ou audiometria condicionada lúdica por via aérea e via óssea;<br>logoaudiometria (LDV, LRF, IRF); imitanciometria, potencial evocado auditivo<br>de curta, média e/ou longa latência, emissões otoacústicas evocadas transiente<br>e/ou produto de distorção e pesquisa do ganho funcional e, avaliação de<br>linguagem.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|APAC(Proc. Principal)|
|Tipo de Financiamento:<br>Valor Ambulatorial SA:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)<br>R$46,56|  
|Valor Ambulatorial Total:|R$46,56<br>|
|---|---|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:<br>|5 Ano(s)|
|Idade Máxima:<br>|130 Ano(s)<br>|
|Quantidade Máxima:|1|
|CBO:|225275,2238|
|CID:|H61.3,H90.0,H90.2,H90.6,H90.8, Q16.1.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|03.01.07.017-2 – MANUTENÇÃO DA PROTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na troca ou substituição dos componentes externos do implante coclear.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced.principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$1.226,35|
|Valor Ambulatorial Total:|R$1.226,35|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|03.01.07.018-0 - ACOMPANHAMENTO DE PACIENTE C/ PROTESE<br>AUDITIVA ANCORADA NO OSSO|
|Descrição:|Consiste no acompanhamento de paciente com prótese auditiva ancorada no osso<br>para adaptação do áudio processador, avaliações do desempenho e orientações de<br>cuidados e manutenção.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|APAC(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$58,62|
|Valor Ambulatorial Total:|R$58,62|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:<br>Sexo:|R$0,00<br>Ambos|  
|Idade Mínima:<br>|0 Mês(s)<br>|
|---|---|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|CBO:|225275,223810|
|CID:|H83.3, H90.0, H90.1, H90.2, H90.3, H90.4, H90.5, H90.6, H90.7, H90.8, H91.8,<br>H91.9,H93.2.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.057-1  - CIRURGIA DE IMPLANTE COCLEAR UNILATERAL|
|Descrição:|Consiste na implantação cirúrgica unilateral de feixe de eletrodos posicionado<br>dentro da cóclea com objetivo de substituir parcialmente as funções da orelha<br>interna(cóclea),transformando os sinais sonoros em sinais elétricos.|
|Origem:|04.04.01.014-8|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SH:|R$1.058,98|
|Valor Hospitalar SP:|R$655,68|
|Valor Hospitalar Total:|R$1.714,66|
|Sexo|Ambos|
|Idade Mínima:|0 Mes(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|Pontos|400|
|CBO|225275|
|Leito|01 – Cirúrgico;07 - Pediátrico|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Atributo Complementar:|001 Inclui valor da anestesia; 004 Admite permanência à maior; 017 Exige<br>informação da OPM.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 -  Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.058-0 - CIRURGIA DE IMPLANTE COCLEAR BILATERAL|
|Descrição:|Consiste na implantação cirúrgica bilateral de feixe de eletrodos posicionado<br>dentro da cóclea com objetivo de substituir parcialmente as funções da orelha<br>interna(cóclea),transformando os sinais sonoros em sinais elétricos.|
|Origem:|04.04.01.014-8|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|  
|Valor Hospitalar SP:<br>|R$2.040,45<br>|
|---|---|
|Valor Hospitalar SH:|R$87448|
|Valor Hospitalar Total:|,<br>R$2.914,92|
|Sexo:|Ambos|
|Idade Mínima:|0 Mes(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1<br>|
|Pontos|400|
|Média de Permanência:|2|
|Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo Complementar:|001 Inclui valor da anestesia; 004 Admite permanência à maior; 017 Exige<br>informação da OPM.|
|CBO:|225275|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.059-8 - CIRURGIA PARA REVISÃO DO IMPLANTE COCLEAR<br>SEM DISPOSITIVO INTERNO DO IMPLANTE COCLEAR|
||Consiste na revisão ou reimplantação cirúrgica, com a|
|Descrição:|recolocação/reposicionamento do feixe de eletrodos dentro da cóclea (orelha<br>interna). Nãopermite OPM.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$196,70|
|Valor Hospitalar SH:|R$317,69|
|Valor Hospitalar Total:|R$514,40|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|Média de Permanência:|2|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo complementar|001 Inclui valor da anestesia;004 Admitepermanência à maior.|
|CBO:|225275|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H.90.6, H91.0, H91.1, H91.2, H91.3,<br>H91.8,H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção Especializada às pessoas com<br>Deficiência Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.060-1  - CIRURGIA PARA PRÓTESE AUDITIVA ANCORADA NO<br>OSSO - 1º TEMPO|
|Descrição:|<br>Consiste na implantação cirúrgica do implante de titânio daprótese auditiva|  
||ancorada no osso. Permite apenas a OPM de implante de titânio da prótese<br>auditiva ancorada no osso sem o áudioprocessador.|
|---|---|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)<br>|
|Valor Ambulatorial SA:|R$0,00<br>|
|Valor Ambulatorial Total:|R$0,00<br>|
|Valor Hospitalar SP:|R$586,41|
|Valor Hospitalar SH:|R$956,78|
|Valor Hospitalar Total:|R$1.543,19|
|Sexo:|Ambos|
|Idade Mínima:|5 Ano(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|Média de Permanência:|1|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo complementar|001 Inclui valor da anestesia; 004 Admite permanência à maior;  017 Exige<br>informação da OPM.|
|CBO:|225275|
|CID:|H61.3,H90.0,H90.2,H90.6,H90.8, Q16.1.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.061-0 - CIRURGIA PARA PRÓTESE AUDITIVA ANCORADA NO<br>OSSO - 2º TEMPO|
|Descrição:|Consiste na exposição do implante de titânio da prótese auditiva ancorada no<br>osso e acoplamento do pilar. Permite apenas a OPM do pilar e do áudio<br>processador daprótese auditiva ancorada no osso.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 - Hospitalar,03 - Hospital Dia|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$58,64|
|Valor Hospitalar SH:|R$95,68|
|Valor Hospitalar Total:|R$154,32|
|Sexo:|Ambos|
|Idade Mínima:|5 Ano(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|Média de Permanência:|1|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo complementar|001 Inclui valor da anestesia; 004 Admite permanência à maior;  017 Exige<br>informação da OPM.|
|CBO:|225275|
|CID:|H61.3,H90.0,H90.2,H90.6,H90.8, Q16.1.|  
|Serviço/classificação:|107/008 - Serviço Especializado Atenção àspessoas com Deficiência Auditiva|
|---|---|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.062-8 - CIRURGIA PARA PRÓTESE AUDITIVA ANCORADA NO<br>OSSO – TEMPO ÚNICO|
|Descrição:|Consiste na implantação cirúrgica do implante de titânio e do pilar da prótese<br>auditiva ancorada no osso. Permite a OPM de implante de titânio, pilar e do<br>áudioprocessador daprótese auditiva ancorada no osso.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$655,68|
|Valor Hospitalar SH:|R$1.058,98|
|Valor Hospitalar Total:|R$1.714,66|
|Sexo:|Ambos|
|Idade Mínima:|7 Ano(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|Média de Permanência:|1|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo complementar|001 Inclui valor da anestesia; 004 Admite permanência à maior;  017 Exige<br>informação da OPM.|
|CBO:|225275|
|CID:|H61.3,H90.0,H90.2,H90.6,H90.8, Q16.1.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.063-6 - CIRURGIA PARA REVISÃO DA PRÓTESE AUDITIVA<br>ANCORADA NO OSSO|
|Descrição:|Consiste na revisão cirúrgica de complicações pós-implante da prótese auditiva<br>ancorada no osso. Nãopermite OPM.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$175,92|
|Valor Hospitalar SH:|R$287,03|
|Valor Hospitalar Total:|R$462,95|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|Atributo complementar|001 Inclui valor da anestesia;004 Admitepermanência à maior|  
|Média de Permanência:<br>|1<br>|
|---|---|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|CBO:|225275|
|CID:|H61.3, H90.0, H90.2, H90.6, H90.8, L02.8, L03.8, L08.8, L08.9, L91.0, L91.8,<br>L91.9,L98.4, Q16.1,Y70.2,Y72.8,Y83.1,Y83.8,Y83.9,Y84.8,Y84.9.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|04.04.01.064-4 - CIRURGIA PARA REIMPLANTAÇÃO DA PROTESE<br>AUDITIVA ANCORADA NO OSSO|
|Descrição:|Consiste na reimplantação cirúrgica do implante de titânio e pilar da prótese<br>auditiva ancorada no osso nos casos de complicações com perda da<br>osteointegração do implante de titânio e/ou a necessidade de substituição do<br>pilar. Permite apenas as OPM implante de titânio e/oupilar.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$655,68|
|Valor Hospitalar SH:|R$1.058,98|
|Valor Hospitalar Total:|R$1.714,66|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|2|
|Média de Permanência:|1|
|Pontos|400|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Atributo complementar|001 Inclui valor da anestesia; 004 Admite permanência à maior;  017 Exige<br>informação da OPM.|
|CBO:|225275|
|CID:|H61.3, H90.0, H90.2, H90.6, H90.8, L02.8, L03.8, L08.8, L08.9, L91.0, L91.8,<br>L91.9,L98.4, Q16.1,Y70.2,Y72.8,Y83.1,Y83.8,Y83.9,Y84.8,Y84.9.|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.010-3 SUBSTITUIÇÃO/TROCA DO CABO DE CONEXÃO DA<br>PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do cabo de conexão do componente externo do<br>implante coclear.|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|  
|Valor Ambulatorial Total:|R$0,00<br>|
|---|---|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.011-1 SUBSTITUIÇÃO/TROCA DO COMPARTIMENTO/GAVETA<br>DE BATERIAS DA PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na  substituição/troca do compartimento/gaveta de baterias da prótese<br>de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.120-0 CONSERTO DO COMPARTIMENTO/GAVETA DE<br>BATERIAS DA PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste no  conserto do compartimento/gaveta de baterias da prótese de<br>implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|  
|Quantidade Máxima:|4|
|---|---|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.013-8 SUBSTITUIÇÃO/TROCA DA ANTENA DA PRÓTESE DE<br>IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca da antena daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09. 014-6 CONSERTO DA ANTENA DA PRÓTESE DE IMPLANTE<br>COCLEAR|
|Descrição:|Consiste no conserto da antena daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.015-4 SUBSTITUIÇÃO/TROCA DAS BATERIAS<br>RECARREGÁVEIS DA PRÓTESE DE IMPLANTE COCLEAR|  
|Descrição:|Consiste na substituição/troca das baterias recarregáveis da prótese de implante<br>coclear|
|---|---|
|Complexidade:|<br>Não se aplica|
|Modalidade:<br>|01 – Ambulatorial<br>|
|Instrumento de Registro:<br>|03 – APAC(proced. secundário)<br>|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.016-2 SUBSTITUIÇÃO/TROCA DO CONTROLE REMOTO DA<br>PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do controle remoto daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.017-0 CONSERTO DO CONTROLE REMOTO DA PRÓTESE DE<br>IMPLANTE COCLEAR|
|Descrição:|Consiste no conserto do controle remoto daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|  
|Valor Hospitalar SH:|R$0,00<br>|
|---|---|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.018-9 SUBSTITUIÇÃO/TROCA DO IMÃ DA ANTENA DA<br>PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do imã da antena daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.019-7 SUBSTITUIÇÃO/TROCA DO CARREGADOR DE BATERIA<br>RECARREGÁVEL DA PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do carregador de bateria recarregável da prótese de<br>implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$000|
|<br>Valor Hospitalar SP:|, <br>R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:||  
||107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|---|---|
|Habilitação:|<br>0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.020-0 SUBSTITUIÇÃO/TROCA DO GANCHO DA PRÓTESE DE<br>IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca dogancho daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00<br>|
|Valor Hospitalar SP:|R$0,00<br>|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00<br>|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.021-9 SUBSTITUIÇÃO/TROCA DO GANCHO COM MICROFONE<br>DA PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do gancho com microfone da prótese de implante<br>coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00<br>|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.022-7 SUBSTITUIÇÃO/TROCA DO DESUMIDIFICADOR DA<br>PRÓTESE DE IMPLANTE COCLEAR|
|Descrição:|Consiste na substituição/troca do desumidificador daprótese de implante coclear|
|Complexidade:|Não se aplica|  
|Modalidade:<br>|01 – Ambulatorial<br>|
|---|---|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00<br>|
|Valor Hospitalar SH:|R$0,00<br>|
|Valor Hospitalar Total:<br>|R$0,00<br>|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.01.09.023-5 CONSERTO DO PROCESSADOR DE FALA DA PRÓTESE<br>DE IMPLANTE COCLEAR|
|Descrição:|Consiste no conserto doprocessador de fala daprótese de implante coclear|
|Complexidade:|Não se aplica|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|4|
|CBO:|225275,223810|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.02.09.005-0 - IMPLANTE DE TITÂNIO DA PRÓTESE AUDITIVA<br>ANCORADA NO OSSO|
|Descrição:|Consiste em um pino ou parafuso de titânio implantado no crânio, atrás da<br>orelha.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Especial)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$6.468,75|
|Valor Hospitalar Total:|R$6.468,75|  
|Sexo:|Ambos|
|---|---|
|Idade Mínima:|Não se aplica|
|Idade Máxima:|Não se aplica|
|Quantidade Máxima:|2|
|Média de Permanência:|1|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.02.09.006-9 - PILAR DA PRÓTESE AUDITIVA ANCORADA NO OSSO|
|Descrição:|Consiste em um pilar intermediário encaixado entre o implante de titânio e o<br>áudioprocessador daprótese auditiva ancorada no osso.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|03 – AIH(Proc. Especial)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$4.398,75|
|Valor Hospitalar Total:|R$4.398,75|
|Sexo:|Ambos|
|Idade Mínima:|Não se aplica|
|Idade Máxima:|Não se aplica|
|Quantidade Máxima:|2|
|Média de Permanência:|1|
|Especialidade do Leito:|01 – Cirúrgico;07 - Pediátrico|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.02.09.007-7 - AUDIO PROCESSADOR DA PRÓTESE AUDITIVA<br>ANCORADA NO OSSO|
|Descrição:|Consiste em um processador de som que capta o som e o transfere diretamente<br>pelo osso à cóclea.|
|Complexidade:|AC – Alta Complexidade|
|Modalidade:|01 - ambulatorial|
|Instrumento de Registro:|03 – APAC(proced. secundário)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$15.007,50|
|Valor Hospitalar Total:|R$15.007,50|
|Sexo:|Ambos|
|Idade Mínima:|Não se aplica|
|Idade Máxima:|Não se aplica|
|Quantidade Máxima:|2|
|Serviço/classificação:||  
||107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|---|---|
|Habilitação:|<br>0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.02.09.008-5 - PRÓTESE AUDITIVA ANCORADA NO OSSO<br>|
|Descrição:|Consiste em uma prótese auditiva implantável, composta por implante de titânio,<br>pilar e áudio processador, capaz de decodificar os sons e transmiti-los<br>diretamentepara a cóclea.|
|Complexidade:|N/A|
|Modalidade:<br>|02 – Hospitalar<br>|
|Instrumento de Registro:|AIH(Proc. Especial)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)<br>|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$25.875,00|
|Valor Hospitalar Total:|R$25.875,00|
|Sexo:|Ambos|
|Idade Mínima:|Não se aplica|
|Idade Máxima:|Não se aplica|
|Quantidade Máxima:|2|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|07.02.09.009-3 - PRÓTESE PARA IMPLANTE COCLEAR MULTICANAL|
|Descrição:|Consiste em umaprótese auditiva implantável.|
|Origem|07.02.09.003-4|
|Complexidade:|Não se aplica|
|Modalidade:|02 – Hospitalar|
|Instrumento de Registro:|AIH(Proc. Especial)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$0,00|
|Valor Ambulatorial Total:|R$0,00|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$43.830,15|
|Valor Hospitalar Total:|R$43.830,15|
|Sexo:|Ambos|
|Idade Mínima:|Não se aplica|
|Idade Máxima:|Não se aplica|
|Quantidade Máxima:|2|
|Serviço/classificação:|107/008 - Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|
|Procedimento:|03.01.07.019-9 - ACOMPANHAMENTO DE PACIENTE COM IMPLANTE<br>COCLEAR|
|Descrição:<br>Origem|Consiste no acompanhamento de paciente com implante coclear para ativação<br>e/ou mapeamento e balanceamento dos eletrodos, avaliação do desempenho e<br>orientações de cuidados e manutenção.<br>03.01.07.001-6|  
|Complexidade:|AC – Alta Complexidade|
|---|---|
|Modalidade:|01 – Ambulatorial|
|Instrumento de Registro:|APAC(Proc. Principal)|
|Tipo de Financiamento:|04 - Fundo de Ações Estratégicas e Compensações(FAEC)|
|Valor Ambulatorial SA:|R$58,62|
|Valor Ambulatorial Total:|R$58,62|
|Valor Hospitalar SP:|R$0,00|
|Valor Hospitalar SH:|R$0,00|
|Valor Hospitalar Total:|R$0,00|
|Sexo:|Ambos|
|Idade Mínima:|0 Mês(s)|
|Idade Máxima:|130 Ano(s)|
|Quantidade Máxima:|1|
|CBO:|225275,223810|
|CID:|H80.2, H83.3, H83.8, H83.9, H90.3, H90.6, H91.0, H91.1, H91.2, H91.3, H91.8,<br>H91.9,H93.3,H93.8,H93.9,H94.0.|
|Serviço/classificação:|107/008 – Serviço Especializado de Atenção às pessoas com Deficiência<br>Auditiva|
|Habilitação:|0305 - Atenção Especializada àspessoas com Deficiência Auditiva|

---

<!-- METADADOS: doenca: Pessoas com Deficiência Auditiva | secao: ANEXO IV -->
RELAÇÃO DAS COMPATIBILIDADES ENTRE PROCEDIMENTOS DA TABELA DE PROCEDIMENTOS, MEDICAMENTOS, ÓRTESES, PRÓTESES E MATERIAIS ESPECIAIS DO SISTEMA ÚNICO DE SAÚDE (SUS) PARA ATENÇÃO ESPECIALIZADA ÀS PESSOAS COM DEFICIÊNCIA AUDITIVA  
|CÓDIGO DO<br>PROCEDIMENTO|PROCEDIMENTO|CÓDIGO DO<br>PROCEDIMENTO|PROCEDIMENTO<br>|QUANTI<br>DADE|
|---|---|---|---|---|
||CIRURGIA<br>DE|07.02.09.009-3|PRÓTESE<br>P/<br>IMPLANTE<br>COCLEAR MULTICANAL|1|
|04.04.01.057-1|IMPLANTE<br>COCLEAR<br>UNILATERAL|<br>02.11.07.039-4|POTENCIAL<br>EVOCADO<br>ELETRICAMENTE<br>NO<br>SISTEMA AUDITIVO<br>|1|
||CIRURGIA<br>DE|07.02.09.009-3|PRÓTESE<br>P/<br>IMPLANTE<br>COCLEAR MULTICANAL|2|
|04.04.01.58-0|IMPLANTE<br>COCLEAR<br>BILATERAL|02.11.07.039-4|POTENCIAL<br>EVOCADO<br>ELETRICAMENTE<br>NO<br>SISTEMA AUDITIVO|1|
|04.04.01.059-8|CIRURGIA<br>PARA<br>REVISÃO<br>DO<br>IMPLANTE<br>COCLEAR<br>SEM<br>DISPOSITIVO<br>INTERNO<br>DO<br>IMPLANTE COCLEAR|<br>02.11.07.039-4|POTENCIAL<br>EVOCADO<br>ELETRICAMENTE<br>NO<br>SISTEMA AUDITIVO|1|
|04.04.01.060-1|CIRURGIA<br>PARA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO -<br>1~~º~~TEMPO|07.02.09.005-0|IMPLANTE DE TITÂNIO DA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO|1|
|04.04.01.061-0|CIRURGIA<br>PARA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO -<br>2~~º~~TEMPO|07.02.09.006-9|PILAR<br>DA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA<br>NO<br>OSSO|1|
|04.04.01.062-8|CIRURGIA<br>PARA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO<br>- TEMPO ÚNICO|07.02.09.008-5|PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO|1|
|0404010644|CIRURGIA<br>PARA<br>REIMPLANTAÇÃO<br>DA|07.02.09.005-0|IMPLANTE DE TITÂNIO DA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA NO OSSO|1|
|...-|PROTESE<br>AUDITIVA<br>ANCORADA NO OSSO|07.02.09.006-9|PILAR<br>DA<br>PRÓTESE<br>AUDITIVA<br>ANCORADA<br>NO<br>OSSO|1|
|||02.11.07.021-1|LOGOAUDIOMETRIA<br>(LDV-<br>IRF-LRF)|1|
|||02.11.07.020-3|IMITANCIOMETRIA|1|
|||02.11.07.004-1|AUDIOMETRIA<br>TONAL<br>LIMIAR(VIA AEREA / OSSEA)|1|
||AVALIAÇÃO E<br> <br>|02.11.07.002-5|AUDIOMETRIA DE REFORCO<br>VISUAL(VIA AEREA / OSSEA)|1|
|02.11.07.037-8|SELEÇÃO<br>PRÉ-<br>CIRÚRGICA<br>PARA<br>IMPLANTE COCLEAR|02.11.07.003-3|AUDIOMETRIA EM CAMPO<br>LIVRE|1|
|||02.11.07.024-6|PESQUISA DE GANHO DE<br>INSERCAO|1|
|||02.11.07.015-7|ESTUDO<br>DE<br>EMISSOES<br>OTOACUSTICAS<br>EVOCADAS<br>TRANSITORIAS E PRODUTOS<br>DE DISTORCAO(EOA)|1|  
|||02.11.07.026-2|POTENCIAL<br>EVOCADO<br>AUDITIVO DE CURTA MEDIA<br>E LONGA LATENCIA|1|
|---|---|---|---|---|
|||02.11.07.021-1|LOGOAUDIOMETRIA<br>(LDV-<br>IRF-LRF)|1|
|||02.11.07.004-1|AUDIOMETRIA<br>TONAL<br>LIMIAR(VIA AEREA / OSSEA)|1|
|||02.11.07.002-5|AUDIOMETRIA DE REFORCO<br>VISUAL(VIA AEREA / OSSEA)|1|
||AVALIAÇÃO<br>E<br>SELEÇÃO<br>PRÉ-<br>|02.11.07.003-3|AUDIOMETRIA EM CAMPO<br>LIVRE|1|
|02.11.07.041-6|CIRÚRGICA PARA DA<br>PRÓTESE<br>AUDITIVA|02.11.07.024-6|PESQUISA DE GANHO DE<br>INSERCAO|1|
||ANCORADA NO OSSO||ESTUDO<br>DE<br>EMISSOES||
|||02.11.07.015-7|OTOACUSTICAS<br>EVOCADAS<br>TRANSITORIAS E PRODUTOS<br>DE DISTORCAO(EOA)|1|
|||02.11.07.026-2|POTENCIAL<br>EVOCADO<br>AUDITIVO DE CURTA MEDIA<br>E LONGA LATENCIA|1|
||||MAPEAMENTO<br>E||
|||02.11.07.038-6|BALANCEAMENTO<br>DOS<br>ELETRODOS|1|
|||02.11.07.004-1|AUDIOMETRIA<br>TONAL<br>LIMIAR(VIA AEREA / OSSEA)|1|
|||02.11.07.002-5|AUDIOMETRIA DE REFORCO<br>VISUAL(VIA AEREA / OSSEA)|1|
|||02.11.07.00,-3|AUDIOMETRIA EM CAMPO<br>LIVRE|1|
|03.01.07.019-9|ACOMPANHAMENTO<br>DE<br>PACIENTE<br>C/|02.11.07.024-6|PESQUISA DE GANHO DE<br>INSERCAO|1|
||IMPLANTE COCLEAR|02.11.07.021-1|LOGOAUDIOMETRIA<br>(LDV-<br>IRF-LRF)|1|
|||02.11.07.020-3|IMITANCIOMETRIA|1|
|||02.11.07.007-6|AVALIACAO DE LINGUAGEM<br>ORAL|1|
|||02.11.07.039-4|POTENCIAL<br>EVOCADO<br>ELETRICAMENTE<br>NO<br>SISTEMA AUDITIVO|1|
|||02.11.07.040-8|REFLEXO<br>ESTAPEDIANO<br>ELICIADO ELETRICAMENTE|1|
|||02.11.07.003-3|AUDIOMETRIA EM CAMPO<br>LIVRE|1|
||ACOMPANHAMENTO<br>DE<br>PACIENTE<br>COM|02.11.07.021-1|LOGOAUDIOMETRIA<br>(LDV-<br>IRF-LRF)|1|
|03.01.07.018-0|PROTESE<br>AUDITIVA<br>ANCORADA NO OSSO|02.11.07.024-6|PESQUISA DE GANHO DE<br>INSERCAO|1|
|||02.11.07.007-6|AVALIACAO DE LINGUAGEM<br>ORAL|1|
|||07.01.09. 010-3|SUBSTITUIÇÃO/TROCA DO<br>CABO DE CONEXÃO DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR|4|
||MANUTENÇÃO<br>DA||SUBSTITUIÇÃO/TROCA DO|4|
|03.01. 07 017-2|<br>PRÓTESE DE IMPLANTE<br>COCLEAR|07.01.09. 011-1|<br>COMPARTIMENTO/GAVETA<br>DE BATERIAS DA PRÓTESE<br>DE IMPLANTE COCLEAR||
||||CONSERTO DO|4|
|||07.01.09. 012-0|COMPARTIMENTO/GAVETA<br>DE BATERIAS DA PRÓTESE||  
||DE IMPLANTE COCLEAR<br>||
|---|---|---|
|07.01.09. 013-8|SUBSTITUIÇÃO/TROCA DA<br>ANTENA DA PRÓTESE DE<br>IMPLANTE COCLEAR|4|
|07.01.09. 014-6|CONSERTO DA ANTENA DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR<br>|4|
|07.01.09. 015-4|SUBSTITUIÇÃO/TROCA DAS<br>BATERIAS RECARREGÁVEIS<br>DA PRÓTESE DE IMPLANTE<br>COCLEAR<br>|4|
|07.01.09. 016-2|SUBSTITUIÇÃO/TROCA DO<br>CONTROLE REMOTO DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR|4|
|07.01.09. 017-0|CONSERTO DO CONTROLE<br>REMOTO DA PRÓTESE DE<br>IMPLANTE COCLEAR<br>|4|
|07.01.09. 018-9|SUBSTITUIÇÃO/TROCA DO<br>IMÃ DA ANTENA DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR<br>|4|
|07.01.09. 019-7|SUBSTITUIÇÃO/TROCA DO<br>CARREGADOR DE BATERIA<br>RECARREGÁVEL DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR<br>|4|
|07.01.09. 020-0|SUBSTITUIÇÃO/TROCA DO<br>GANCHO DA PRÓTESE DE<br>IMPLANTE COCLEAR<br>|4|
|07.01.09. 021-9|SUBSTITUIÇÃO/TROCA DO<br>GANCHO COM MICROFONE<br>DA PRÓTESE DE IMPLANTE<br>COCLEAR|4|
|07.01.09. 022-7|SUBSTITUIÇÃO/TROCA DO<br>DESUMIDIFICADOR DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR|4|
|07.01.09. 023-5|CONSERTO DO<br>PROCESSADOR DE FALA DA<br>PRÓTESE DE IMPLANTE<br>COCLEAR|4|

---

