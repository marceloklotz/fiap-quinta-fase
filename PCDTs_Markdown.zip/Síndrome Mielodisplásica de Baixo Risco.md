<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: Geral -->
<!-- Start of picture text -->
Ris”<br><!-- End of picture text -->  
MINISTÉRIO DA SAÚDE  
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE  
SECRETARIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 22, de 03 de NOVEMBRO de 2022.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas da Síndrome  
Mielodisplásica de Baixo Risco.  
A SECRETÁRIA DE ATENÇÃO ESPECIALIZADA À SAÚDE - SUBSTITUTA e a SECRETÁRIA DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOS ESTRATÉGICOS EM SAÚDE – SUBSTITUTA, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre a Síndrome Mielodisplásica de Baixo Risco no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação nº 756/2022 e o Relatório de Recomendação nº 759 – Julho de 2022 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias em Saúde (DGITS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Síndrome Mielodisplásica de Baixo Risco.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral da Síndrome Mielodisplásica de Baixo Risco, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de caráter</u> nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais (efeitos ou eventos adversos) relacionados ao uso de procedimento ou medicamento preconizados para o tratamento da Síndrome Mielodisplásica de Baixo Risco.  
Art. 3º Os gestores estaduais, distrital e municipais do SUS, conforme suas competências e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º Fica revogada a Portaria SAS/MS n<sup>o</sup> 493, de 11 de junho de 2015, publicada no Diário Oficial da União nº 110, de 12 de junho de 2015, seção 1, página 55.  
Art. 5º Esta Portaria entra em vigor na data de sua publicação.  
MARIA INEZ PORDEUS GADELHA  
ANA PAULA TELES FERREIRA BARRETO  
PROTOCOLO CLÍNICO E DIRETRIZES TERAPÊUTICAS SÍNDROME MIELODISPLÁSICA DE BAIXO RISCO

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **1. INTRODUÇÃO** -->
A Síndrome Mielodisplásica (SMD) são um grupo de neoplasias da medula óssea caracterizadas por hematopoese ineficaz e manifestada por displasia morfológica em células hematopoéticas e por citopenia(s) no sangue periférico, na ausência de outras causas que justifiquem a(s) citopenia(s)<sup>1</sup> . Predominantemente uma doença dos idosos (a idade mediana dos pacientes ao diagnóstico é 75,7 anos), a SMD pode evoluir para leucemia mieloide aguda (LMA) e é mais comum em homens (aproximadamente 2:1)<sup>2</sup> . Sua incidência no Reino Unido é de 3,72/100.000 habitantes/ano<sup>2</sup> . No Brasil, segundo dados dos sistemas de informações hospitalares e ambulatoriais do SUS (respectivamente disponíveis em <u>https://datasus.saude.gov.br/acesso-a-informacao/producao-hospitalar-sih-sus/</u> e https://datasus.saude.gov.br/acesso-ainformacao/producao-ambulatorial-sia-sus/), de 2019 a 2021 registraram-se, por Síndrome Mielodisplásica, 7.648 internações (média anual de 2.549) e 42.994 (média anual de 14.331) procedimentos ambulatoriais.  
Pacientes com suspeita de Síndrome Mielodisplásica devem ser avaliados por um especialista na área de hematologia para serem submetidos à investigação diagnóstica.  
A Síndrome Mielodisplásica de baixo risco inclui pacientes classificados por meio do Sistema Internacional de Escore Prognóstico ( _International Prognostic Scoring System_ [IPSS])<sup>3</sup> baixo e intermediário-1 e do Sistema Internacional de Escore Prognóstico Revisado ( _Revised International Prognostic Scoring System_ [IPSS-R])<sup>4</sup> como muito baixo, baixo e intermediário até 3,5 pontos<sup>5,6</sup> .  
A única terapia curativa para a Síndrome Mielodisplásica é o transplante de células-tronco hematopoéticas (TCTH) alogênico, reservado preferencialmente para pacientes abaixo de 75 anos e síndrome mielodisplásica de risco intermediário e alto definidos pelo IPSS e IPSS-R. O objetivo principal da terapia da Síndrome Mielodisplásica de baixo risco é melhorar a(s) citopenia(s), a fim de prevenir complicações, como sangramento e infecções graves, reduzir a necessidade de transfusão de hemocomponentes e melhorar a qualidade de vida dos pacientes. A observação clínica, sem necessidade de terapia específica, pode ser a melhor opção para pacientes com Síndrome Mielodisplásica de baixo risco e citopenia(s) assintomática(s). A detecção de sinais de gravidade ou evolução da doença indicam a necessidade de terapia específica. Os indicadores de evolução são o agravamento de citopenia(s) e um número crescente de blastos no sangue periférico ou medula óssea e evolução clonal<sup>6,7</sup> .  
Como se trata de doença com curso clínico variável, o diagnóstico, a estratificação de risco e tratamento são feitos por médicos hematologistas. Diretrizes que abordam o melhor tratamento para grupos específicos de pacientes com Síndrome Mielodisplásica de baixo risco têm o potencial de orientar a melhor terapia disponível e garantir a resposta hematológica, benefício na qualidade de vida dos pacientes e melhora da sobrevida em grupos específicos<sup>6,7</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Este Protocolo visa a estabelecer os critérios diagnósticos e terapêuticos da Síndrome Mielodisplásica de baixo risco. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .  
**2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)**  
- D46.0 Anemia refratária sem sideroblastos  
- D46.1 Anemia refratária com sideroblastos  
- D46.4 Anemia refratária, não especificada  
- D46.7 Outras síndromes mielodisplásicas

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **3.1. Diagnóstico clínico, laboratorial, citogenético e molecular** -->
Os pacientes com SMD podem ser assintomáticos ou apresentarem sinais e sintomas de fraqueza/astenia, infecções de repetição ou sangramento cutâneo mucoso decorrentes de anemia, neutropenia ou plaquetopenia, respectivamente. A SMD deve ser considerada em todos os pacientes com citopenia(s) inexplicada(s) persistentes detectadas em exame de hemograma. A Organização Mundial da Saúde (OMS) definiu citopenia(s) como hemoglobina abaixo de 10 g/L, contagem absoluta de neutrófilos abaixo de 1,8 x 10<sup>9</sup> /L e plaquetas abaixo de 100 x 10<sup>9</sup> /L<sup>1</sup> .  
Se o paciente apresentar citopenia(s) persistente e inexplicável, a confirmação do diagnóstico de SMD requer a exclusão  
de outras causas de citopenias e a presença de, pelo menos, um dos critérios a seguir<sup>1,9</sup> :  
- (i) displasia morfológica (envolvendo 10% ou mais de células da medula óssea em 1 ou mais linhagem);  
- (ii) aumento de mieloblastos (maior ou igual a 5% e menor que 20%); ou  
- (iii) evidência de clonalidade por meio de detecção de anormalidade citogenética característica de SMD.  
Definir o diagnóstico de SMD pode ser desafiador. Outras causas de displasia morfológica devem ser excluídas e um período de observação seguido de reavaliações periódicas pode ser necessário. A displasia morfológica não ocorre apenas em pacientes com SMD e pode ocorrer após exposição a agente tóxico, em condições reativas (vide diagnóstico diferencial), na presença de anemias de outras causas, além de ter sido relatada em indivíduos saudáveis<sup>10</sup> . Além da identificação de sinais e sintomas de citopenia(s) e confirmação de citopenia(s) persistente(s) no exame de hemograma completo, o algoritmo sugerido para investigação diagnóstica de SMD inclui anamnese e exame físico completos, exames laboratoriais para investigar outras causas de citopenia(s), citomorfologia do esfregaço de sangue periférico e avaliação da medula óssea, conforme descritas no **Quadro 1** .  
**Quadro 1** - Investigação clínica e laboratorial mínimas do paciente com suspeita de Síndrome Mielodisplásica.  
|**Investigação**|**Dados coletados**|
|---|---|
|Anamnese|Consumo de álcool|
||Exposição prévia à quimioterapia/radioterapia|
||Histórico familiar de SMD/LMA, trombocitopenia, neoplasia ou fibrose hepática/pulmonar|
||Histórico nutricional, ambiental ou ocupacional (exposição a benzeno e chumbo), deficiência|  
nutricional  
|Exame físico|Características dismórficas (sugerindo falência medular congênita)<br>Infecção, hematoma ou sangramento ativos|
|---|---|
|Exames|Hemograma completo|
|laboratoriais|Análise morfológica do esfregaço de sangue periférico<br>Contagem de reticulócitos|  
Dosagem de vitamina B12, ácido fólico, ferritina e estudo da cinética do ferro (ferro sérico, saturação  
de transferrina)  
Dosagem da lactato desidrogenase

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Investigação** -->
**Dados coletados**  
Teste para avaliação hepática (enzimas hepáticas [TGO/AST e TGP/ALT] e canaliculares [FA e  
GGT], TTPA, TP, bilirrubinas [total e frações], eletroforese de proteínas séricas)  
Teste de função renal e eletrólitos (ureia, creatinina, sódio, potássio, cálcio, fósforo, urina de rotina)  
Sorologias para HIV, hepatite B e C, CMV  
Função tireoidiana (TSH e T4 livre)  
Investigação de doença autoimune (Fator antinuclear e Fator reumatoide)  
Exames de imagem RX de tórax Ultrassonografia de abdômen Aspirado e biópsia Análise morfológica do aspirado de medula óssea (500 células) para avaliação de celularidade, de medula óssea displasias e contagem de blastos Coloração do ferro e quantificação de sideroblastos em anel Biópsia de medula óssea com coloração para reticulina  
Análise citogenética convencional com bandeamento G  
Análise citogenética molecular com FISH<sup>a</sup> ou SNP array<sup>b</sup>  
Imunofenotipagem com análise de expressão antigênica aberrante e quantificação dos blastos<sup>b</sup>  
Análise mutacional/genômica<sup>b</sup>  
LMA, leucemia mieloide aguda; SMD, síndrome mielodisplásica; TGO, transaminase oxalacética; AST, aspartato aminotransferase; TGP, transaminase pirúvica; ALT, alanina aminotransferase; FA, fosfatase alcalina; GGT, gama glutamil transferase; TTPA, tempo de tromboplastina parcial ativada; TP, tempo de protrombina; CMV, citomegalovírus; HIV, vírus da imunodeficiência humana; TSH, hormônio tireoestimulante; T4 livre, tetraiodotironina livre; FISH, hibridização fluorescente in situ; SNP, polimorfismo de nucleotídeo único. Nota:<sup>a</sup> Não mandatório.<sup>b</sup> Não mandatório. Pode ser realizado apenas se estiver disponível.  
Adaptado de Killick et al., 2021<sup>6</sup> .  
Na ausência de outras causas de citopenia(s), deve-se realizar o aspirado de medula óssea (morfologia, avaliação de sideroblastos em anel e cariótipo) e a biópsia de medula óssea, conforme detalhado na **Figura 1** .  
**Figura 1** - Algoritmo para diagnóstico da Síndrome Mielodisplásica  
<!-- Start of picture text -->
Citopenias persistentes A<br>Nivel de hemoglobina abaixo de 10 g/L<br>Contagem absoluta de neutrofilos abaixo de 1,8 x 10°/L ou<br>Q Contagem de plaquetas abaixo de 100 x 10°/L<br>Anamnese e exame fisico<br>Citomorfologia do esfregaco do sangue periférico<br>Exames laboratoriais para descartar outras causas de citopenia(s)<br>sim<br>Existe evidéncia de -<br>EASELS<br>| No<br>Monitoramento Nao sim A(s) citopenia(s)<br>clinico investigacbes invasivas?O paciente é elegivel a /“ causaspersistemcorecdosecundarias? apesardas  da<br>‘Sim Nao<br>Aspirado de medula ossea e Monitoramento<br>Biopsia de medula Ossea clinico<br>Anélise morfologica do grau de displasia<br>Contagem de biastos<br>Coloraco para ferro (% siderablatos em anel)<br>Citogenética convencional<br>Sim Critérios morfolégicos Nao<br>ou citogenéticos*<br>minimos para SMD?<br>Diagnésticode Sindrome -<br>Mielodisplasica<br>Monitoramento clinico<br>Reavaliacdo de investigacdo de outras causas de<br>citopenias<br>Classificacdo OMS Reavaliacdo da medula Ossea se houver piora<br>Estratificagao do risco prognostico (IPSS) a(s) citopenia(s)<br>eIPSS-R)<br><!-- End of picture text -->  
aEvidência presuntiva de SMD: -7 ou del(7q); -5 ou del(5q); i(17q) t(17p) ou del(17p); -13 ou del(13q); del(11q); del(12p) ou t(12p); del(9q); Idic(X)(q13); t(11;16)(q23;p13·3); t(3;21)(q26·2;q22·1); t(1;3)(p36·3;q21·2); t(2;11)(p21;q23·3); inv(3)(q21q26·2)/t(3;3)(q21;q23·3); t(6;9) (p23;q34·1). Adaptado de Killick et al., 2021<sup>6</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Avaliação morfológica** -->
A avaliação morfológica é fundamental para o diagnóstico, classificação e prognóstico de SMD. As alterações morfológicas, incluindo displasias, devem ser avaliadas no esfregaço de sangue periférico e de medula óssea, por um hematologista ou hematopatologista com experiência. Esfregaços e colorações de boa qualidade são essenciais para diagnóstico.  
Amostras frescas devem ser processadas dentro de 2 horas, sempre que possível, e o excesso de etilenodiamina tetraacético ácido (EDTA) deve ser estritamente evitado. A contagem diferencial ideal do esfregaço de medula óssea corado por May–Grunwald– Giemsa (ou equivalente) deve avaliar 500 ou mais células nucleadas, incluindo 30 ou mais megacariócitos, a presença de displasia nas séries eritroide, granulocítica e megacariocítica e a porcentagem de mieloblastos. A coloração com Azul da Prússia ou Perls deve ser realizada em todos os aspirados de medula para avaliar os estoques de ferro e quantificar os sideroblastos em anel.  
Todos os pacientes com suspeita de SMD devem contar com biópsia de medula óssea para que as informações sobre a arquitetura da medula óssea, celularidade e fibrose (com coloração de reticulina) auxiliem no diagnóstico e na classificação de SMD. O padrão ouro para a contagem da porcentagem de mieloblastos é a avaliação morfológica do aspirado de medula óssea. No entanto, se o aspirado for de baixa qualidade, a biópsia de medula óssea pode ser utilizada para quantificar blastos usando imunohistoquímica<sup>1,9.</sup>

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Avaliação citogenética** -->
Anormalidades cromossômicas que evidenciam um distúrbio clonal são detectadas por exame de cariótipo convencional com banda G em aproximadamente 50% dos pacientes com SMD. Algumas anormalidades recorrentes [mais comumente -5, del(5q), -7, del(7q), i(17q)] são consideradas definidoras de SMD em paciente com citopenia<sup>1,9,11</sup> . A análise citogenética convencional de banda G de amostra de medula óssea deve ser realizada em todos os casos suspeitos de SMD para auxiliar no diagnóstico, prognóstico e tratamento. Quando nenhuma anormalidade for encontrada em uma amostra diagnóstica, no mínimo 20 metáfases devem ser examinadas e relatadas usando as recomendações do Sistema Internacional de Nomenclatura Citogenética Humana<sup>12,13</sup> . Nos casos em que a análise da banda G não é possível por ausência de metáfases, análises de hibridização _in situ_ por fluorescência (FISH) podem ser realizadas para fins de detectar as principais anormalidades de significância prognóstica ou fornecer confirmação de clonalidade. Entretanto, as análises de FISH são limitadas à pesquisa de uma única anormalidade por exame e só devem ser realizadas se estiverem disponíveis.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Avaliação molecular** -->
Metodologias de análise do genoma em larga escala podem fornecer informações relevantes sobre anormalidades cromossômicas, clonalidade e mutações, como análise de matriz de polimorfismos de nucleotídeo único<sup>14,15</sup> , e sequenciamento em larga escala de todo o genoma<sup>1,16,17</sup> , mas não são obrigatórias e não estão disponíveis no SUS.  
Mutações somáticas podem ser identificadas em indivíduos saudáveis e, portanto, apenas a detecção de mutações não é considerada critério diagnóstico<sup>1</sup> . As metodologias de avaliação do genoma em larga escala requerem alto custo de recursos humanos, equipamentos e insumos, padronizações e validações de análises e interpretações, e não são obrigatórias na avaliação diagnóstica e prognóstica dos pacientes com SMD.  
A detecção de certas mutações associadas a SMD pode ser usada para estabelecer subtipos com relevância prognóstica. Mutações SF3B1 são encontradas em mais de 95% dos casos de SMD com sideroblastos em anel (SMD-SA)<sup>18</sup> . Na classificação revisada da OMS, a presença de uma mutação SF3B1 reduz a porcentagem de sideroblastos em anel necessária para um diagnóstico de SMD-SA de 15% a 5%<sup>1</sup> . Em SMD-SA, a presença de mutação SF3B1 está associada a um prognóstico favorável<sup>18</sup> . Análises univariadas indicaram que mutações nos genes _ASXL1_ , _EZH2_ , _RUNX1_ e _TP53_ conferem prognóstico adverso, contudo, sua significância prognóstica em análises multivariadas ainda não foi consistentemente reproduzida em séries independentes<sup>16,17,19</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Citometria de fluxo** -->
A citometria de fluxo pode ser útil para quantificar a porcentagem de blastos. No entanto, este exame não é obrigatório para o diagnóstico de SMD porque os achados podem não estar precisamente correlacionados com a morfologia, devido à hemodiluição do aspirado, ao fenótipo da célula progenitora sem expressão de CD34<sup>20,21</sup> ou à ausência de imunofenótipo específico. Os achados mais comuns são expressão de antígeno aberrante em progenitores mieloides, maturação aberrante das células das linhagens mieloides, monocíticas e eritroides e aumento de células CD34<sup>+</sup> . Achados imunofenotípicos, quando  
disponíveis, devem sempre ser interpretados em conjunto com achados da avaliação da morfologia e citogenética da medula óssea.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **3.2. Diagnóstico diferencial** -->
O diagnóstico de SMD exige exclusão de outras causas de citopenias, conforme investigação complementar descrita no **Quadro 1** . Doenças ou condições sistêmicas que obrigatoriamente devem ser descartadas são: deficiências nutricionais, infecção por vírus do HIV, hepatites B e C, CMV, doenças autoimunes, hepática e renal, hipotireoidismo, neoplasias e uso de medicamentos.  
Doenças da medula óssea também devem ser consideradas no diagnóstico diferencial de SMD. Pacientes com SMD e medula óssea hipocelular representam cerca de 10% a 20% dos casos e são definidos pela OMS como SMD hipocelular<sup>1,22,23</sup> ; estes pacientes devem realizar citometria de fluxo para verificar a possibilidade de hemoglobinúria paroxística noturna. O diagnóstico diferencial com outras falências medulares, especialmente anemia aplástica, também deve ser considerado.  
A síndrome mielodisplásica secundária à terapia citotóxica é classificada separadamente como neoplasia mieloide relacionada à terapia, um dos subgrupos da categoria da OMS definido como LMA e neoplasia de precursores mieloides<sup>1</sup> .  
Outra categoria definida pela OMS é a neoplasia mieloide com predisposição germinativa. Assim, é necessário investigar a história clínica e familiar dos pacientes para identificar quadro clínico de SMD com potencial predisposição germinativa<sup>1</sup> . Nesses casos, é indicado o encaminhamento precoce do paciente a um centro com experiência com casos de síndrome de falência medular constitucional. A neoplasia mieloide com predisposição germinativa deve ser investigada caso o paciente apresente SMD ou LMA e, adicionalmente, pelo menos um dos seguintes achados<sup>24,25</sup> :  
- Histórico pessoal de múltiplos cânceres;  
- trombocitopenia, propensão a sangramento ou macrocitose precedendo o diagnóstico de SMD/LMA em alguns anos;  
- parentes de primeiro ou segundo grau com neoplasia hematológica;  
- parentes de primeiro ou segundo grau com tumor sólido consistente com predisposição germinativa; como, sarcoma, câncer de mama com surgimento precoce (pacientes com idade inferior a 50 anos), ou tumores cerebrais;  
- pigmentação anormal em unhas ou pele, leucoplaquia bucal, fibrose pulmonar idiopática, doença hepática inexplicada, linfedema, infecções atípicas, imunodeficiências, anomalias congênitas dos membros, ou baixa estatura (no paciente ou parentes de primeiro ou segundo grau);  
- qualquer doador saudável de células-tronco hematopoéticas que planeja doação a um membro da família acometido por malignidade de origem hematopoética com qualquer das condições listadas acima ou em que se falha em mobilizar células-tronco por meio dos protocolos padrões.  
Avaliações complementares que podem auxiliar no diagnóstico diferencial em casos específicos estão indicadas no **Quadro 2** .  
**Quadro 2 -** Investigação complementar para auxiliar o diagnóstico diferencial em casos específicos  
**Exames que auxiliam no diagnóstico diferencial**  
Citometria de fluxo para Hemoglobinúria Paroxística Noturna  
Cariótipo de sangue periférico para avaliação de quebras cromossômicas para Anemia de Fanconi  
Análise mutacional na suspeita de falência medular de causa constitucional<sup>a</sup>  
Análise do _status_ mutacional para o gene _JAK2_ em pacientes com características mieloproliferativas ou trombocitose  
a Portaria GM/MS nº 199, de 30 de Janeiro de 2014. Adaptado de Killick et al., 2021<sup>6</sup>

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **3.3. Classificação da Síndrome Mielodisplásica** -->
A classificação da SMD baseia-se na avaliação morfológica. Todos os casos devem ser classificados de acordo com a classificação da OMS vigente, revisada em 2016 ( **Quadro 3** ). Essa classificação deixou de ser focada em linhagens específicas  
de citopenia(s), passando a definir as SMD em<sup>1,26</sup>  
- SMD com displasia de única linhagem (SMD-DUL);  
- SMD com displasia de múltiplas linhagens (SMD-DML);  
- SMD-SA: com DUL ou DML;  
- SMD com deleção 5q;  
- SMD com excesso de blastos (SMD-EB): tipo 1 e tipo 2;  
- SMD não classificada (SMD-NC): com 1% de blastos, com DUL e pancitopenia, baseada em alterações citogenéticas específicas.  
**Quadro 3 -** Classificação da síndrome mielodisplásica  
|**Classificação**|**Linhagens**<br>**displásicas**<br>**(Nº)**|**Citopenia(s)**<sup>**a**</sup><br>**(Nº)**|**Sideroblastos**<br>**em anel na**<br>**medula óssea**<br>**(%)**|**Blastos no**<br>**sangue**<br>**periférico e**<br>**medula óssea**<br>**(%)**|**Alterações**<br>**cromossômicas**<br>**detectadas por análise**<br>**citogenética**<br>**convencional e**<br>**definidoras do subtipo**|
|---|---|---|---|---|---|
|SMD com displasia de<br>única linhagem (SMD-<br>DUL)|1|1-2|<15/<5<sup>b</sup>|MO <5,<br>SP <1,<br>Sem bastões<br>de Auer|Quaisquer, a menos que<br>satisfaça todos os<br>critérios para SMD com<br>del(5q) isolada|
|SMD com displasia de<br>múltiplas linhagens<br>(SMD-DML)<br>SMD com sideroblastos em|2-3<br>anel (SMD-SA|1-3<br>)|<15/<5<sup>b</sup><br>|MO <5,<br>SP <1,<br>Sem bastões<br>de Auer|Quaisquer, a menos que<br>satisfaça todos os<br>critérios para SMD com<br>del(5q) isolada|
|SMD com sideroblastos<br>em anel e displasia de<br>única linhagem (SMD-<br>SA-DUL)|1|1-2|≥15/≥5<sup>b</sup>|MO <5%,<br>SP <1%,<br>Sem bastões<br>de Auer|Quaisquer, a menos que<br>satisfaça todos os<br>critérios para SMD com<br>del(5q) isolada|
|SMD com sideroblastos<br>em anel e displasia de<br>múltiplas linhagens<br>(SMD-SA-DML)|2-3|1-3|≥15/≥5<sup>b</sup>|MO <5,<br>SP <1,<br>Sem bastões<br>de Auer|Quaisquer, a menos que<br>satisfaça todos os<br>critérios para SMD com<br>del(5q) isolada|
|SMD com del(5q)<br>isolada|1-3|1-2|Nenhum ou<br>qualquer|MO <5,<br>SP <1,|del(5q) isolada ou com<br>uma anormalidade|  
|**Classificação**|**Linhagens**<br>**displásicas**<br>**(Nº)**|**Citopenia(s)**<sup>**a**</sup><br>**(Nº)**|**Sideroblastos**<br>**em anel na**<br>**medula óssea**<br>**(%)**|**Blastos no**<br>**sangue**<br>**periférico e**<br>**medula óssea**<br>**(%)**|**Alterações**<br>**cromossômicas**<br>**detectadas por análise**<br>**citogenética**<br>**convencional e**<br>**definidoras do subtipo**|
|---|---|---|---|---|---|
|SMD com excesso de blast<br>|os (SMD-EB)<br>|||Sem bastões<br>de Auer<br>|adicional, exceto perda<br>do cromossomo 7 ou<br>del(7q)<br>|
|SMD-EB1|1-3|1-3|Nenhum ou<br>qualquer|MO 5-9 ou SP<br>2-4,<br>MO <10 e SP<br><5<br>Sem bastões<br>de Auer|Quaisquer|
|SMD-EB2|1-3|1-3|Nenhum ou<br>qualquer|MO 10-19 ou<br>SP 5-19,<br>Ou bastões de<br>Auer em MO e<br>SP <20|Quaisquer|
|SMD não classificada (SM|D-NC)|||||
|com 1% de blastos|1-3|1-3|Nenhum ou<br>qualquer|MO <5,<br>SP <1<sup>c</sup>,<br>Sem bastões<br>de Auer|Quaisquer|
|com displasia de única<br>linhagem (DUL) e<br>pancitopenia|1|3|Nenhum ou<br>qualquer|MO <5,<br>SP <1,<br>Sem bastões<br>de Auer|Quaisquer|
|Baseado em alterações<br>citogenéticas específicas|0|1-3|<15<sup>d</sup>|MO <5,<br>SP <1,<br>Sem bastões<br>de Auer|Anormalidade<br>definidoras de SMD<sup>e</sup>|  
MO, medula óssea; SP, sangue periférico. Nota:<sup>a</sup> Citopenias definidas como concentração de hemoglobina inferior a 10 g/L, contagem de plaquetas inferior a 100×10<sup>9</sup> /L e contagem absoluta de neutrófilos inferior a 1,8×10<sup>9</sup> /L. Monócitos em SP deve estar abaixo de 1×10<sup>9</sup> /L.<sup>b</sup> Se a mutação em SF3B1 for presente.<sup>c</sup> 1% de blastos em SP devem ser registrados em duas ou mais ocasiões separadas.<sup>d</sup> Casos com ≥15% de sideroblastos em anel, por definição, tem displasia eritroide  
significante e são classificados como SMD-SA-DUL.<sup>e</sup> -7 ou del(7q); -5 ou del(5q); i(17q) t(17p) ou del(17p); -13 ou del(13q); del(11q); del(12p) ou t(12p); del(9q); Idic(X)(q13); t(11;16)(q23;p13·3); t(3;21)(q26·2;q22·1); t(1;3)(p36·3;q21·2); t(2;11)(p21;q23·3); inv(3)(q21q26·2)/t(3;3)(q21;q23·3); t(6;9) (p23;q34·1). Digno de nota, a Síndrome mielodisplásica (SMD) associada à terapia e a SMD/neoplasia mieloproliferativa crônica (NMP) são classificadas pela OMS na categoria Neoplasias Mieloides Associadas à Terapia. Adaptado de Swerdlow SH et al., 2017<sup>1</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **3.3.1 Estratificação de Risco Prognóstico da Síndrome Mielodisplásica** -->
Desde a sua publicação em 1997, os índices de prognóstico internacionais, incluindo o Sistema Internacional de Escore Prognóstico (IPSS) e o Sistema Internacional de Escore Prognóstico Revisado (IPSS-R), têm sido uma importante ferramenta para avaliar o prognóstico de pacientes adultos com SMD<sup>3,4</sup> . O IPSS define quatro categorias de risco prognóstico: baixo, intermediário 1, intermediário 2 e alto risco<sup>3</sup> . Já o IPSS-R utiliza os mesmos parâmetros que o IPSS (risco citogenético, porcentagem de blastos na medula óssea e citopenias), mas utiliza uma estratificação de risco citogenético atualizada (conforme **Quadro 4** )<sup>11</sup> e também considera a gravidade da(s) citopenia(s)<sup>4</sup> .  
**Quadro 4 -** Categorias de risco citogenético para SMD utilizado para o IPSS-R.  
|**Risco citogenético**|**Alterações citogenéticas definidoras do risco**|
|---|---|
|Muito bom|-Y, del(11q)|
|Bom|Normal, del(5q), del(12q), del(20q), alteração dupla que inclua del(5q)|
|Intermediário|del(7q), +8, +19, i(17q), quaisquer outros clones independentes simples ou duplos|
|Ruim|-7, inv(3), alteração dupla incluindo -7/del(7q), complexo: 3 anomalias|
|Muito ruim|Complexo: >3 anomalias|  
Adaptado de Schanz J et al, 2012<sup>11</sup> .  
A pontuação específica do paciente na IPSS-R é definida considerando a categoria de risco citogenético, a porcentagem de blastos na medula óssea, a gravidade da anemia (concentração de hemoglobina), da plaquetopenia e da neutropenia, conforme descrito na **Tabela 1** . Para cálculo do escore prognóstico, os pontos atribuídos ao paciente em cada um dos cinco critérios indicados na **Tabela 1** devem ser somados. A pontuação final indicará as categorias de risco definidas pelo IPSS-R: muito baixo, baixo, intermediário, alto e muito alto risco conforme indicado na Tabela 2. Uma ferramenta para cálculo do IPSS-R está disponível no sítio eletrônico do UK MDS Forum (http://www.ukmdsforum.org.uk/)<sup>4</sup> .  
**Tabela 1 -** Sistema de Pontuação definido para o Sistema Internacional de Escore Prognóstico Revisado (IPSS-R).  
|Variável prognóstica|Pontuaçã<br>0|o a ser atrib<br>0,5|uída para cada v<br>1|ariável<br>1,5|2|3|4|
|---|---|---|---|---|---|---|---|
|Risco citogenético|Muito|-|Bom|-|Intermediário|Ruim|Muito|
||bom||||||ruim|
|Porcentagem de blastos na|≤2|-|>2-<5|-|5-10|>10|-|
|medula óssea||||||||  
|Concentração<br>de<br>hemoglobina (g/L)|≥10|-|8 -<10|<80|-|-<br>-|
|---|---|---|---|---|---|---|
|Contagem<br>de<br>plaquetas<br>(x10<sup>9</sup>/L)|≥100|50-<100|<50|-|-|-<br>-|
|Contagem de neutrófilos<br>(x10<sup>9</sup>/L)|≥0,8|<0,8|-|-|-|-<br>-|  
Adaptado de Greenberg PL et al., 2012<sup>4</sup> .  
Cada categoria de risco do IPSS-R apresenta diferentes desfechos clínicos de sobrevida global e sobrevida livre de evolução para LMA, conforme descrito na **Tabela 2**<sup>4</sup> . Ao diagnóstico, o prognóstico de todos os pacientes deve ser calculado usando o IPSS-R e também o IPSS.  
**Tabela 2** - Categorias de risco de acordo com a pontuação do Sistema Internacional de Escore Prognóstico Revisado (IPSS-R) e desfechos clínicos para pacientes com SMD.  
|Categoria de risco|Pontuação|Anos de sobrevida<br>(mediana)|Anos decorridos até que 25% dos pacientes<br>evoluam a LMA (mediana)|
|---|---|---|---|
|Muito baixo|≤1,5|8,8|Não alcançado|
|Baixo|>1,5 - 3|5,3|10,8|
|Intermediário|>3 - 4,5|3,0|3,2|
|Alto|>4,5 - 6|1,6|1,4|
|Muito alto|>6|0,8|0,73|  
LMA, leucemia mieloide aguda Adaptado de Greenberg PL et al., 2012<sup>4</sup> .  
A Síndrome Mielodisplásica de baixo risco inclui pacientes classificados como IPSS baixo ou intermediário-1 ou IPSSR muito baixo, baixo e intermediário até 3,5 pontos. Já os pacientes com SMD de alto risco são aqueles classificados como IPSS intermediário-2 e alto ou IPSS-R intermediário acima de 3,5 pontos, alto e muito alto<sup>5,6</sup> .  
Os pacientes devem ser tratados de acordo com suas características clínicas e biológicas individuais, considerando suas preferências e as do médico. O prognóstico dos pacientes com SMD deve ser reavaliado regularmente, especialmente quando ocorrer perda de resposta a um tratamento e piora das contagens hematimétricas<sup>6</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **4. CRITÉRIOS DE INCLUSÃO** -->
Devem ser incluídos nesse PCDT os pacientes adultos (idade maior ou igual a 18 anos) com diagnóstico de SMD de baixo risco (IPSS baixo ou intermediário-1 ou IPSS-R muito baixo, baixo e intermediário até 3,5 pontos).  
Para o uso de **alfaepoetina** , serão incluídos apenas pacientes com SMD de baixo risco e anemia sintomática (Hb menor ou igual a 10 g/L).  
Para uso de **filgrastim** , serão incluídos pacientes com síndrome mielodisplásica de baixo risco e:  
(i) contagem de neutrófilos abaixo de 0,5 x 10<sup>9</sup> /L e infecções resistentes ou infecções de repetição ou;  
(ii) diagnóstico de anemia e que não apresentem resposta eritroide satisfatória após uso de alfaepoetina durante 16 semanas.  
Para o uso de **talidomida** , serão incluídos apenas os pacientes diagnosticados com anemia refratária sem sideroblastos (D46.0), anemia refratária com sideroblastos (D46.1) ou anemia refratária, não especificada (D46.4), que não responderam a alfaepoetina, que consentirem com o uso do medicamento e que atendam, um dos seguintes critérios:  
(i) pacientes do sexo masculino ou do sexo feminino em idade não reprodutiva;  
(ii) pacientes do sexo feminino em idade reprodutiva que estejam utilizando, pelo menos, dois métodos contraceptivos, dos quais no mínimo um deve ser de barreira, há pelo menos 1 mês antes do início do tratamento e que apresentem dois testes de gravidez negativos, feitos com método sensível;  
(iii) pacientes do sexo feminino em idade fértil que tenham sido submetidas a procedimento de esterilização.  
Serão elegíveis ao **transplante de células-tronco hematopoéticas (TCTH) alogênico** os pacientes com SMD de baixo risco, classificados como IPSS intermediário-1 ou IPSS-R intermediário até 3,5 pontos, com doador identificado e em condições clínicas para o transplante, conforme o vigente Regulamento Técnico do Sistema Nacional de Transplantes e as idades mínima e máxima atribuídas aos respectivos procedimentos na Tabela de Procedimentos, Medicamentos, Órteses, Próteses e Materiais Especiais do SUS.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **5. CRITÉRIOS DE EXCLUSÃO** -->
Serão excluídos pacientes que apresentarem toxicidade (intolerância, hipersensibilidade ou outro evento adverso) ou contraindicações absolutas ao uso do respectivo medicamento preconizado ou procedimento preconizados neste Protocolo.  
Para o uso de **filgrastim** , serão excluídos pacientes com contagem de neutrófilos acima de 10x10<sup>9</sup> /L.  
Para o uso de **talidomida** , serão excluídos pacientes com neuropatia periférica grau II ou maior, mulheres grávidas ou que tenham intenção de engravidar, que não estejam utilizando métodos contraceptivos e pacientes que não concordem ou não assinem o Termo de Responsabilidade/Esclarecimento.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **6. CASOS ESPECIAIS** -->
Durante a gestação e durante o período de amamentação, as mulheres devem ser preferencialmente elegíveis para tratamento de suporte e necessitam ser avaliadas individualmente. A indicação de tratamento medicamentoso deverá ser avaliada individualmente conforme riscos e benefícios específicos de cada medicamento.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **7.1. Tratamento não medicamentoso** -->
Os cuidados de suporte com transfusões de hemocomponentes são fundamentais para o tratamento de pacientes com  
SMD.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Transfusão de concentrado de hemácias** -->
Em SMD, a dependência de transfusão de concentrado de hemácias está associada à diminuição de sobrevida global e sobrevida livre de evolução para LMA, além de redução na qualidade de vida<sup>27,28</sup> . O suporte transfusional com concentrado de hemácias está associado com riscos de aloimunização<sup>29,30</sup> . Os protocolos transfusionais são definidos pela unidade de saúde e devem incluir hemácias fenotipadas para os antígenos Rh e Kell<sup>31</sup> ou fenotipagem estendida<sup>32</sup> . Hemocomponentes irradiados são preconizados para pacientes com SMD submetidos ao tratamento com globulina antitimocítica ou TCTH alogênico<sup>33</sup> .  
Embora a gravidade da anemia tenha um grande impacto na sobrevida e qualidade de vida em pacientes com SMD<sup>34</sup> , não se conhece a amplitude da melhora pelas diferentes políticas de transfusão de eritrócitos. Os médicos podem optar por aplicar  
uma conduta transfusional individualizada e orientada pelos sintomas. Na prática, são frequentemente utilizados limiares específicos de hemoglobina, sendo geralmente utilizado 8 g/L<sup>35,36</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Transfusão de plaquetas** -->
A transfusão de plaquetas unitárias ou aférese de plaquetas em SMD é comum, mas os protocolos são definidos pela unidade de saúde. Um estudo retrospectivo envolvendo pacientes com anemia aplástica grave descreveu um acompanhamento sem transfusão profilática de plaquetas e verificou que evitar transfusões desnecessárias de plaquetas em pacientes sem sinais de sangramento reduz a necessidade de atendimento ambulatorial, melhora a qualidade de vida e pode reduzir o risco de refratariedade plaquetária<sup>37</sup> . Pacientes com trombocitopenia crônica apresentando sangramento de grau 2 ou superior, de acordo com a definição da OMS, devem receber transfusões de plaquetas<sup>37,38,39</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Planejamento conjunto** -->
Todos os pacientes devem ser acompanhados por um especialista, para que estejam cientes de seu diagnóstico e das opções terapêuticas existentes. Cada paciente deve ser reavaliado regularmente, de forma individualizada<sup>27</sup> .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **<mark>Transplante de células-tronco hematopoéticas (TCTH) alogênico</mark>** -->
<mark>Em pacientes de SMD, o TCTH alogênico está indicado apenas para os casos de risco intermediário ou alto definidos pelo IPSS e IPSS-R, no âmbito do SUS em conformidade com a Portaria de Consolidação nº 4/2017</mark><sup>40</sup> <mark>.</mark>  
<mark>Os pacientes de baixo risco definidos pelo IPSS e IPSS-R devem ser acompanhados a fim de verificar a progressão da SMD. Em caso de evolução para risco intermediário ou alto, a decisão de realizar o TCTH alogênico nos pacientes elegíveis deve ser feita caso a caso, avaliando paciente, doador e fatores de doença</mark> conhecidos por influenciar os resultados do TCTH alogênico<sup>41</sup> . Não há consenso na literatura sobre a realização de TCTH em pacientes com SMD de baixo risco definidos pelo IPSS e IPSS-R e o procedimento precoce não é preconizado devido à redução subsequente na expectativa de vida.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Agentes estimulantes da eritropoese - alfaepoetina** -->
A terapia com agente estimulador de eritropoese (alfaepoetina) é considerada primeira linha de tratamento de pacientes adultos com SMD de baixo risco com anemia sintomática (Hb menor ou igual a 10 g/L)<sup>42,43,44,45,46</sup> .  
O tratamento com alfaepoetina deve ser iniciado após o diagnóstico de SMD e antes da dependência transfusional estabelecida<sup>47,48</sup> . Após o uso de alfaepoetina, a resposta eritroide do paciente pode ser completa, com nível de hemoglobina acima de 11,5 g/L e independência transfusional; ou parcial, com um incremento de hemoglobina acima de 2 g/L e independência transfusional, enquanto o nível de hemoglobina permanecer abaixo de 11,5 g/L. Alguns pacientes podem alcançar resultados potencialmente benéficos com o aumento do intervalo entre as transfusões, embora não se reconheça este parâmetro como critério de resposta<sup>7</sup> .  
Ao iniciar o tratamento, os pacientes devem ser monitorados por até 24 semanas de terapia. Durante as primeiras oito semanas de tratamento, deve-se utilizar a dose inicial de alfaepoetina e, nas oito semanas seguintes, as doses mais altas, se necessário<sup>46</sup> . Caso não haja resposta satisfatória após 16 semanas, deve-se iniciar o tratamento concomitante com filgrastim por mais oito semanas, antes de considerar que o paciente falhou no tratamento com alfaepoetina. Após este período, os pacientes que atingiram uma resposta eritroide completa ou parcial devem continuar em tratamento de longo prazo com a dose mínima de alfaepoetina necessária para manter a resposta ou até que a resposta seja perdida<sup>7</sup> .  
Pacientes em terapia com alfaepoetina podem desenvolver deficiência de ferro absoluta ou funcional, aumento do risco de eventos cardiovasculares graves, tais como trombose venosa, acidente vascular cerebral, infarto agudo do miocárdio e tromboembolismo venoso. Em um estudo randomizado de alfaepoetina, não foi relatado evento tromboembólico de grau 3 ou 4 ou acidente vascular cerebral nos pacientes tratados<sup>46</sup> . Assim, apesar de o risco de trombose ser baixo, deve-se interromper o uso de alfaepoetina se o nível de hemoglobina for superior a 12 g/dL ou se ocorrer um rápido aumento na hemoglobina (acima de 1  
g/dL em duas semanas). O paciente pode retornar ao uso de doses mais baixas de alfaepoetina com monitoramento cuidadoso dos valores da hemoglobina e do hematócrito.  
No início do tratamento, pode haver aumento da pressão arterial após a administração de alfaepoetina, quando o hematócrito está aumentando agudamente. Em pacientes com insuficiência renal crônica, observa-se maior risco de encefalopatia hipertensiva e convulsões, particularmente naqueles com histórico anterior de convulsões. Também foram observadas cefaleia, náusea, falta de ar, edema, vômito, taquicardia e diarreia em alguns pacientes. Pode ocorrer eritema no local da injeção e sintomas semelhantes aos da gripe (como artralgias e mialgias), que duram de 2 a 4 horas.  
A alfaepoetina foi avaliada pela Conitec para o tratamento de pacientes adultos com SMD de baixo risco, com recomendação favorável.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Fator estimulador de colônias de granulócitos - filgrastim** -->
O fator de crescimento de colônias de granulócitos (G-CSF/filgrastim) está preconizado para pacientes com SMD de baixo risco com contagem de neutrófilos abaixo de 0,5 x 10<sup>9</sup> /L e com infecções resistentes ou infecções de repetição<sup>49,50.</sup> . O filgrastim também deve ser utilizado por pacientes adultos com diagnóstico de SMD de baixo risco e anemia, que não apresentem resposta eritroide satisfatória ao uso de alfaepoetina após 16 semanas<sup>42,45,50</sup> .  
Como não existem dados suficientes sobre a utilização de filgrastim em mulheres grávidas e sobre sua excreção no leite humano, este medicamento não deve ser utilizado por mulheres durante a gravidez ou que estejam amamentando, a menos que o benefício do seu uso supere os riscos.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Talidomida** -->
A talidomida é preconizada para o tratamento de adultos com diagnóstico de SMD de baixo risco, refratários ao tratamento  
com alfaepoetina.  
Considerando os riscos de teratogenia, conforme as orientações do Anexo V da Resolução da Diretoria Colegiada nº 11, de 22 de março de 2011, da Agência Nacional de Vigilância Sanitária – Anvisa, para a prescrição, por conseguinte, dispensação de talidomida, é obrigatório o consentimento do paciente. Além disso, só poderão utilizar o medicamento pacientes do sexo masculino ou do sexo feminino em idade não reprodutiva e pacientes do sexo feminino em idade reprodutiva que estejam utilizando dois ou mais métodos contraceptivos, dos quais no mínimo um método de barreira, há pelo menos 1 mês antes do início do tratamento e com a apresentação de dois testes de gravidez negativos, feitos com método sensível. No entanto, o uso desses métodos é desnecessário no caso de mulheres que tenham sido submetidas a procedimento de esterilização. Os métodos anticoncepcionais devem ser mantidos durante o uso do medicamento e, pelo menos, até 1 mês após o término do tratamento. A talidomida é proibida para mulheres grávidas ou com chance de engravidar ou que estejam amamentando.  
Um estudo de braço único envolvendo pacientes com SMD de baixo risco tratados com talidomida indicou melhora hematológica. Contudo, a maioria dos pacientes suspendeu o medicamento antes da 16ª semana devido à ocorrência de eventos adversos<sup>51</sup> . Em outro estudo de braço único, planejou-se administrar 200 mg de talidomida diários aos pacientes. No entanto, devido à alta proporção de pacientes que necessitaram interromper o tratamento antes da 12ª semana devido aos eventos adversos, o protocolo foi alterado para administração de 50 mg/dia. Os pacientes que utilizaram 50 mg e 200 mg por dia foram avaliados após 12 semanas de tratamento. Atingiram resposta hematológica eritroide, 27% dos pacientes no grupo que utilizou 200 mg/dia e 21% no grupo que utilizou 50 mg/dia. Verificou-se a necessidade de redução da dose antes da 12ª semana em 25 pacientes<sup>52</sup> .  
Além da teratogenicidade, outro efeito adverso do uso da talidomida é a neuropatia periférica, a qual deve ser monitorada pois, quanto mais precoce o seu diagnóstico, maiores são as chances de reversão do quadro. Em caso de neuropatia periférica grau I (parestesia, fraqueza ou perda de reflexos sem perda de função), deve-se considerar redução da dose. Já em caso de neuropatia periférica grau II ou maior (interferindo com a função), o uso de talidomida deve ser suspenso.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Lenalidomida** -->
Na Europa, a lenalidomida é utilizada no tratamento de pacientes com SMD com IPSS baixo e intermediário 1 ou IPSSR com pontuação < 3,5 e dependente de transfusão com del(5q) isolado (com até uma anormalidade adicional diferente de 7/7q) que falharam ou não responderam a agente estimulador de eritropoetina. Em pacientes com SMD de baixo risco com deleção de 5q, o uso de lenalidomida apresentou resultados significativos na melhora da resposta hematológica eritroide, na sobrevida global e na progressão para LMA, além de estar relacionada com menos reações adversas quando comparada com a talidomida<sup>53,54,55,56</sup> .  
As evidências existentes apontam para a ausência de benefício da lenalidomida para pacientes com mais de 5% de blastos na medula óssea, presença de anormalidade citogenética, monossomia do 7 ou 7q associada a del(5q) e presença de duas anormalidades citogenéticas adicionais a del(5q)<sup>56</sup> . Além disso, pacientes com del(5q) isolado e mutação TP53 têm pior prognóstico e maior chance de falha na terapia com lenalidomida<sup>19,57</sup> .  
O uso de lenalidomida para SMD de baixo risco não foi avaliado pela Conitec.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Imunossupressão com globulina antitimocítica e ciclosporina** -->
O tratamento de imunossupressão com ciclosporina associada à imunoglobulina antitimocítica apresenta melhores resultados quando comparado ao suporte transfusional padrão na resposta hematológica eritroide dos pacientes com SMD de baixo risco<sup>58,59</sup> .  
Este Protocolo não preconiza o uso de imunossupressão com ciclosporina e globulina antitimocítica para SMD de baixo risco, uma vez que sua ampliação de uso para essa indicação não foi avaliada pela Conitec.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Quelação de ferro** -->
Pacientes com SMD de baixo risco que desenvolverem sobrecarga de ferro devem ser avaliados para indicação de desferroxamina, deferiprona ou deferasirox conforme definido no Protocolo Clínico e Diretrizes Terapêuticas da Sobrecarga de Ferro vigente.  
Um fluxograma de tratamento da síndrome mielodisplásica de baixo risco é apresentado na **Figura 2** .  
**Figura 2 -** Algoritmo para tratamento da Síndrome Mielodisplásica de Baixo Risco  
<!-- Start of picture text -->
Sindrome Mielodlspésica<br>IPSS-R mute TPSSbai,DakoBaoe intermediéno-t€itermediriode patio atérsco3.5 pontos<br>een aciente apresenta Pacente apcesenta contagem de<br>‘assintomatica(s) abana‘anemiahemogiobinade (niveis10 dt) de infecoesneutrétios resistentes ababxorepaigdo de 0,5xou infeccBas 10%/L ede plaquetopenia ePaciente apresenta sangramento<br>Sepuimentocinico EEL pre Tassoce<br>(Tratamento de longosim Resposta Nao<br>(razo‘em cam dose atfeepoetna minima  << sasatov‘sem nas? a  apés 16», Miia tralamentomais concomitante8 semanas com flrastim por |<br>‘sim Pacente conserte Nao. , A ; ‘sim<br>Cee Gam<br>taldomida?<br>Nao<br>Supotetranstusional Manterafaepostina ©<br>| Teicoms Guslagdo oe ero | | tiorastin<br>| Seesausénca de resposta . fo. Perda de2<br>‘em 12 semanas? respast<br>Nao Nao<br>Monteriaicomige ‘Manter alfaepoetina<br>figrastim:<br><!-- End of picture text -->  
IPSS, _International Prognostic Scoring System/_ Sistema Internacional de Escore Prognóstico; IPSS-R, _Revised International Prognostic Scoring System/_ Sistema Internacional de Escore Prognóstico Revisado.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **7.2.1 Medicamentos** -->
- Alfaepoetina: solução injetável ou pó para solução injetável contendo 10.000 UI;  
- Filgrastim: solução injetável contendo 300 microgramas (mcg);  
- Talidomida: comprimidos de 100 mg.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **7.2.2 Esquemas de administração** -->
- Alfaepoetina: a dose inicial deve ser de 30.000 a 40.000 UI (ou 450 UI/kg) por semana, administradas por via  
- subcutânea. Na ausência de resposta após oito semanas, a dose pode ser aumentada até 60.000 UI (cerca de 1.050 UI/kg) por semana, dose única ou duas administrações. Doses maiores que 60.000 UI por semana não são toleradas. Pacientes com baixo peso e com déficit de função renal devem utilizar dose reduzida de alfaepoetina.  
● Filgrastim: para tratamento da neutropenia, a dose preconizada é de 5 mcg/kg/dia. Para uso associado à alfaepoetina, preconiza-se uma dose inicial de 300 mcg por semana, dividida em duas a três administrações. A dose pode ser aumentada para até 900 mcg, divididas em três administrações semanais, caso o paciente não responda à dose usual.  
● Talidomida: a dose inicial é 100 mg/dia por via oral, em dose única, durante 4 semanas, com aumento da dose a cada mês, conforme a tolerância do paciente. Doses acima de 200 mg/dia devem ser divididas em duas a quatro administrações diárias, 1 hora após as refeições. A dose de resposta ao tratamento varia entre 200 mg e 400 mg ao dia, sendo esta última a dose máxima diária. A redução da dose diária para 100 mg ou 50 mg foi associada à diminuição de eventos adversos.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **7.2.3 Critérios de interrupção e tempo de tratamento** -->
● Alfaepoetina: deve-se interromper o tratamento caso não haja resposta eritroide completa após a 24ª semana de tratamento, considerando o ajuste de dose e o uso associado ao filgrastim durante as oito últimas semanas. Pacientes que atinjam uma resposta eritroide completa ou parcial devem continuar em terapia de longo prazo na dose mínima de alfaepoetina necessária para manter a resposta ou até que a resposta seja perdida.  
● Filgrastim: para correção da neutropenia, o tratamento deve ser mantido a critério clínico, de acordo com a recorrência de infecções e contagem de neutrófilos. Para o uso associado à alfaepoetina, caso o paciente tenha atingido a resposta eritroide completa ou parcial, seu uso deve ser mantido em terapia de longo prazo na dose mínima necessária para manter a resposta ou até que a resposta seja perdida. O uso de filgrastim deve ser interrompido na ausência de resposta eritroide após oito semanas de seu uso associado à alfaepoetina.  
● Talidomida: o tratamento deve ser mantido enquanto houver ação terapêutica sem intolerância ao medicamento. Não havendo resposta terapêutica com 12 a 16 semanas, o tratamento deve ser suspenso.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **8. MONITORAMENTO** -->
Para o monitoramento do uso de alfaepoetina, deve-se realizar hemograma a cada quinze dias, durante o primeiro mês, seguido de hemograma mensal até a 24ª semana de tratamento. Em caso de resposta completa, deve-se manter o tratamento e realizar um hemograma trimestralmente. A conduta pode ser individualizada conforme os valores de hemoglobina e dependência transfusional de cada paciente. O monitoramento da contagem de neutrófilos e dos valores de hemoglobina é obrigatório para definição de resposta e para evitar valores de hemoglobina acima de 12 g/dL.  
Para o monitoramento do tratamento com filgrastim, o paciente deve contar com hemogramas semanais ou quinzenais até a definição da dose ideal de acordo com a necessidade e resposta. Para correção de neutropenia, a dose de filgrastim deve ser ajustada para manter contagem de neutrófilos acima de 1 x 10<sup>9</sup> /L. Para uso associado à alfaepoetina, a dose de filgrastim deve ser adequada para dobrar a contagem inicial de leucócitos nos pacientes com contagem de leucócitos abaixo de 1,5 x 10<sup>9</sup> /L no início do tratamento, ou para manter a contagem de leucócitos nos pacientes com leucócitos entre 6 e 10 x 10<sup>9</sup> /L no início do tratamento.  
Em relação à talidomida, deve-se realizar, a cada três meses, hemograma com plaquetas e dosagem sérica de fosfatase alcalina e enzimas hepáticas. Além disso, mulheres em idade fértil devem ser monitoradas quanto à possibilidade de gravidez. O aumento de enzimas hepáticas pode ocorrer em raros casos e, quando for superior a duas vezes o limite superior de referência, a talidomida deve ser suspensa até a normalização do exame. Também deve-se suspender a talidomida nos casos em que houver surgimento de sintomas e sinais compatíveis com neuropatia periférica. Pacientes vivendo com HIV devem submeter-se a monitoramento da quantificação viral a cada 3 meses, pois pode haver um aumento dos níveis de RNAm do vírus HIV devido ao uso de talidomida. O uso de talidomida causa sonolência e, portanto, os pacientes devem ser orientados a não operar máquinas ou dirigir carro. O efeito sedativo da talidomida é aumentado quando a talidomida é associada a barbitúricos, clorpromazina e reserpina. Devido à possibilidade de interação medicamentosa com talidomida, devem ser cuidadosamente monitorados pacientes em tratamento com os seguintes medicamentos: agentes quimioterápicos neurotóxicos, como cisplatina, etoposídeo, alcaloides da vinca ou taxanos; antirretrovirais conhecidamente associados à neuropatia periférica, como estavudina e didanosina; tuberculostáticos como isoniazida, etambutol e etionamida; bortezomibe, cloranfenicol, dapsona, fenitoína,  
hidralazina, lítio, metronidazol, nitrofurantoína e óxido nitroso. O uso de corticoides sistêmicos, como dexametasona, implica na necessidade de monitorar o risco de eventos tromboembólicos. Indiretamente, antibióticos, principalmente a rifampicina, podem interagir com os anticoncepcionais hormonais alterando os níveis plasmáticos regulares e diminuindo a eficácia dos contraceptivos hormonais recomendado durante o uso da talidomida para evitar efeitos teratogênicos no caso de gravidez associado ao uso de talidomida.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **9. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de doentes neste Protocolo, a duração e a monitorização do tratamento, bem como para a verificação periódica das doses de medicamento(s) prescritas e dispensadas e da adequação de uso e do acompanhamento pós-tratamento. Doentes de SMD devem ser atendidos em serviços especializados em hematologia, para seu adequado diagnóstico, inclusão no protocolo de tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.  
Os estados e municípios deverão manter atualizadas as informações referentes aos registros de estoque, distribuição e dispensação do(s) medicamento(s) e encaminhar estas informações ao Ministério da Saúde via Base Nacional de Dados de Ações e Serviços da Assistência Farmacêutica no âmbito do Sistema Único de Saúde (BNAFAR), conforme as normativas vigentes.  
Os procedimentos diagnósticos (Grupo 02 e seus vários subgrupos – clínicos, cirúrgicos, laboratoriais e por imagem), terapêuticos clínicos (Grupo 03), terapêuticos cirúrgicos (Grupo 04 e os vários subgrupos cirúrgicos por especialidades e complexidade) e de transplantes (Grupo 05 e seus seis subgrupos)  da Tabela de Procedimentos, Medicamentos e Órteses, Próteses e Materiais Especiais do SUS podem ser acessados, por código ou nome do procedimento e por código da CID-10 para a respectiva doença, no SIGTAP − Sistema de Gerenciamento dessa Tabela (http://sigtap.datasus.gov.br/tabelaunificada/app/sec/inicio.jsp), com versão mensalmente atualizada e disponibilizada.  
Para a autorização do TCTH alogênico não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical, do tipo mieloablativo, todos os potenciais receptores devem estar inscritos no Registro Nacional de Receptores de Medula Óssea ou outros precursores hematopoéticos – REREME/INCA/MS, e devem ser observadas as normas técnicas e operacionais do Sistema Nacional de Transplantes. Os resultados de todos os casos de síndrome mielodisplásica de baixo risco submetidos a TCTH mieloablativo alogênico aparentado ou não aparentado de medula óssea, de sangue periférico ou de sangue de cordão umbilical deverão ter sua evolução registrada no REREME a cada três meses até completar pelo menos 1 (um) ano da realização do transplante.  
A dispensação e o fornecimento ambulatoriais de filgrastim e de epoetina para SMD de baixo risco (D46.0 Anemia refratária sem sideroblastos, D46.1 Anemia refratária com sideroblastos, D46.4 Anemia refratária, não especificada e D46.7 Outras síndromes mielodisplásicas) dão-se no âmbito do Componente Especializado da Assistência Farmacêutica no SUS, pelas secretarias estaduais de saúde. Se em internação, incluem-se no procedimento utilizado para o registro em AIH (Autorização de Internação Hospitalar).  
Em se tratando de paciente, internado ou ambulatorial, com SMD classificada como D46.2 Anemia refratária com excesso de blastos e D46.9 Síndrome mielodisplásica não especificada, são os seguintes os códigos de procedimentos quimioterápicos compatíveis da tabela do SUS: 03.04.03.003-1 – Doença Mieloproliferativa Rara - 1ª linha e 03.04.03.004-0 – Doença Mieloproliferativa Rara - 2ª linha. Nestes casos, o fornecimento de filgrastim ou de epoetina, mesmo quando associada(s) à quimioterapia, competem ao hospital habilitado na alta complexidade em oncologia no SUS, visto que os procedimentos quimioterápicos da tabela do SUS não referem medicamentos, mas, sim, indicações terapêuticas de tipos e situações tumorais especificadas em cada procedimento descrito e independentes de esquema terapêutico utilizado.  
Por sua vez, quando a SDM é classificada como D46.3 - Anemia refratária com excesso de blastos com transformação compatibiliza-se com os procedimentos de quimioterapia curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt, quais sejam: 03.04.06.007-0 Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma de Burkitt – 1ª linha, 03.04.06.008-9 Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 2ª linha (primeira recaída), 03.04.06.009-7 Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 3ª linha (segunda recaída) e 03.04.06.010-0 Quimioterapia Curativa de Leucemia Aguda/Mielodisplasia/Linfoma Linfoblástico/Linfoma de Burkitt – 4ª linha (terceira recaída). E, se os pacientes têm até 19 anos incompletos, os procedimentos compatíveis são: 03.04.07.001-7 Quimioterapia de Câncer na Infância e Adolescência – 1ª linha, 03.04.07.002-5 Quimioterapia de Câncer na Infância e Adolescência – 2ª linha (primeira recidiva), 03.04.07.004-1 Quimioterapia de Câncer na Infância e Adolescência – 3ª linha (segunda recidiva) e 03.04.07.003-3 Quimioterapia de Câncer na Infância e Adolescência – 4ª linha (terceira recidiva).  
A Comissão Nacional de Incorporação de Tecnologias do SUS (CONITEC) aprovou a talidomida como opção terapêutica da Síndrome Mielodisplásica (códigos da CID: D46.0 Anemia refratária sem sideroblastos, D46.1 Anemia refratária com sideroblastos e D46.4  Anemia refratária NE – não especificada) para os pacientes refratários à eritropoietina.  
A talidomida é um medicamento adquirido pelo Ministério da Saúde e dispensado por farmacêutico nas Unidades Públicas Dispensadoras de Talidomida credenciadas pela autoridade sanitária competente, conforme os artigos nº 11 e nº 30 da RDC nº 11/2011 da Anvisa. Destaca-se que, segundo os artigos nº 14 e nº 15 desta mesma RDC, os pacientes deverão ser cadastrados pela Área de Assistência Farmacêutica das Secretarias Estaduais de Saúde, e o Ministério da Saúde manterá o Cadastro Nacional de Usuários do Medicamento à Base de Talidomida. Informações complementares estão disponíveis no endereço eletrônico www.saude.gov.br/cgafme.  
Todos os demais requisitos estabelecidos na RDC nº11/2011 da Anvisa devem ser seguidos pelos médicos e demais profissionais da saúde envolvidos no atendimento ao paciente. Para prescrever a talidomida, o médico deve ser cadastrado pela autoridade sanitária local e utilizar a Notificação de Receita de Talidomida (Anexo VI da RDC nº. 11/2011 da Anvisa), obtida junto a essa autoridade. Conforme o artigo nº. 27 da referida RDC, a talidomida para pacientes internados em estabelecimentos hospitalares deve ser prescrita _em receita ou outro documento equivalente, subscrita em papel privativo do estabelecimento, acompanhada do Termo de Responsabilidade/Esclarecimento assinado pelo médico e pelo paciente ou seu responsável, em caso de impedimento do paciente_ .

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **10. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE – TER** -->
Deve-se informar o paciente ou seu responsável legal sobre os potenciais riscos, benefícios e eventos adversos relacionados ao uso dos medicamentos preconizados neste Protocolo, levando-se em consideração as informações contidas no TER.  
Durante o uso da talidomida, é obrigatória, a cada consulta, a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e eventos adversos relacionados ao uso do medicamento preconizado neste Protocolo, o que deverá ser formalizado por meio da assinatura do Termo de Responsabilidade/Esclarecimento para o usuário da Talidomida, de acordo com o modelo constante nos anexos V-A e V-B da RDC nº 11/2011 da Anvisa.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **11. REFERÊNCIAS** -->
1.  Steven Swerdlow, Elias Campo NH. _WHO Classification of Tumours of Haematopoietic and Lymphoid Tissues._ Revised 4t. IARC; 2017.  
2.  Roman E, Smith A, Appleton S, et al. Myeloid malignancies in the real-world: Occurrence, progression and survival in the UK’s population-based Haematological Malignancy Research Network 2004-15. _Cancer Epidemiol_ . 2016;42:186-198.  
doi:10.1016/j.canep.2016.03.011  
3.  Greenberg P, Cox C, LeBeau MM, et al. International scoring system for evaluating prognosis in myelodysplastic  
syndromes. _Blood_ . 1997;89(6):2079-2088. doi:10.1182/blood.v89.6.2079  
4.  Greenberg PL, Tuechler H, Schanz J, et al. Revised international prognostic scoring system for myelodysplastic  
syndromes. _Blood_ . 2012;120(12):2454-2465. doi:10.1182/blood-2012-03-420489  
5.  Pfeilstocker M, Tuechler H, Sanz G, et al. Time-dependent changes in mortality and transformation risk in MDS.  
2016;128(7):902-910. doi:10.1182/blood-2016-02-700054.  
6.  Killick SB, Wiseman DH, Quek L, et al. British Society for Haematology guidelines for the diagnosis and evaluation  
of prognosis of Adult Myelodysplastic Syndromes. _Br J Haematol_ . 2021;194(2):282-293. doi:10.1111/bjh.17621  
7.  Killick SB, Ingram W, Culligan D, et al. British Society for Haematology guidelines for the management of adult  
myelodysplastic syndromes. _Br J Haematol_ . 2021;194(2):267-281. doi:10.1111/bjh.17612  
8.  Gopalakrishna G, Mustafa RA, Davenport C, et al. Applying Grading of Recommendations Assessment, Development  
and Evaluation (GRADE) to diagnostic tests was challenging but doable. _J Clin Epidemiol_ . 2014;67(7):760-768. doi:10.1016/j.jclinepi.2014.01.006  
9.  Valent P, Orazi A, Steensma DP, et al. Oncotarget 73483 www.impactjournals.com/oncotarget Proposed minimal  
diagnostic criteria for myelodysplastic syndromes (MDS) and potential pre-MDS conditions Priority Review. _Oncotarget_ . 2017;8(43):73483-73500. www.impactjournals.com/oncotarget/  
10.  Steensma DP. Dysplasia has a differential diagnosis: Distinguishing genuine myelodysplastic syndromes (MDS)  
from mimics, imitators, copycats and impostors. _Curr Hematol Malig Rep_ . 2012;7(4):310-320. doi:10.1007/s11899-012-0140-3  
11. Schanz J, Tüchler H, Solé F, et al. New comprehensive cytogenetic scoring system for primary myelodysplastic  
syndromes (MDS) and oligoblastic acute myeloid leukemia after MDS derived from an international database merge. _J Clin Oncol_ . 2012;30(8):820-829. doi:10.1200/JCO.2011.35.6394  
12. Rack KA, van den Berg E, Haferlach C, et al. European recommendations and quality assurance for cytogenomic  
analysis of haematological neoplasms. _Leukemia_ . 2019;33(8):1851-1867. doi:10.1038/s41375-019-0378-z  
13. Chun K, Hagemeijer A, Iqbal A, Slovak ML. Implementation of standardized international karyotype scoring  
practices is needed to provide uniform and systematic evaluation for patients with myelodysplastic syndrome using IPSS criteria: An International Working Group on MDS Cytogenetics Study. _Leuk Res_ . 2010;34(2):160-165. doi:10.1016/j.leukres.2009.07.006  
14. Makishima H, Rataul M, Gondek LP, et al. FISH and SNP-A karyotyping in myelodysplastic syndromes:  
Improving cytogenetic detection of del(5q), monosomy 7, del(7q), trisomy 8 and del(20q). _Leuk Res_ . 2010;34(4):447-453. doi:10.1016/j.leukres.2009.08.023  
15. MacIejewski JP, Tiu R V., O’Keefe C. Application of array-based whole genome scanning technologies as a  
cytogenetic tool in haematological malignancies. _Br J Haematol_ . 2009;146(5):479-488. doi:10.1111/j.1365-2141.2009.07757.x  
16. Haferlach T, Nagata Y, Grossmann V, et al. Landscape of genetic lesions in 944 patients with myelodysplastic  
syndromes. _Leukemia_ . 2014;28(2):241-247. doi:10.1038/leu.2013.336  
17. Papaemmanuil E, Gerstung M, Malcovati L, et al. Clinical and biological implications of driver mutations in  
myelodysplastic syndromes. _Blood_ . 2013;122(22):3616-3627. doi:10.1182/blood-2013-08-518886  
18. Malcovati L, Karimi M, Papaemmanuil E, et al. SF3B1 mutation identifies a distinct subset of myelodysplastic  
syndrome with ring sideroblasts. _Blood_ . 2015;126(2):233-241. doi:10.1182/blood-2015-03-633537  
19. Jädersten M, Saft L, Smith A, et al. TP53 mutations in low-risk myelodysplastic syndromes with del(5q) predict  
disease progression. _J Clin Oncol_ . 2011;29(15):1971-1979. doi:10.1200/JCO.2010.31.8576  
20. Porta MGD, Picone C, Pascutto C, et al. Multicenter validation of a reproducible flow cytometric score for the  
diagnosis of low-grade myelodysplastic syndromes: Results of a European LeukemiaNET study. _Haematologica_ . 2012;97(8):1209-1217. doi:10.3324/haematol.2011.048421  
21. Van De Loosdrecht AA, Alhan C, Béné MC, et al. Standardization of flow cytometry in myelodysplastic syndromes: Report from the first European LeukemiaNet working conference on flow cytometry in myelodysplastic syndromes. _Haematologica_ . 2009;94(8):1124-1134. doi:10.3324/haematol.2009.005801  
22. Bennett JM, Orazi A. Diagnostic criteria to distinguish hypocellular acute myeloid leukemia from hypocellular  
myelodysplastic syndromes and aplastic anemia: Recommendations for a standardized approach. _Haematologica_ . 2009;94(2):264-268. doi:10.3324/haematol.13755  
23. Bono E, McLornan D, Travaglino E, et al. Clinical, histopathological and molecular characterization of  
hypoplastic myelodysplastic syndrome. _Leukemia_ . 2019;33(10):2495-2505. doi:10.1038/s41375-019-0457-1  
24. Churpek JE, Lorenz R, Nedumgottil S, et al. Proposal for the clinical detection and management of patients and  
their family members with familial myelodysplastic syndrome/acute leukemia predisposition syndromes. _Leuk Lymphoma_ . 2013;54(1):28-35. doi:10.3109/10428194.2012.701738  
25. Godley LA, Shimamura A. Genetic predisposition to hematologic malignancies: Management and surveillance.  
_Blood_ . 2017;130(4):424-432. doi:10.1182/blood-2017-02-735290  
26. Arber DA, Orazi A, Hasserjian R, et al. The 2016 revision to the World Health Organization classification of  
myeloid neoplasms and acute leukemia. _Blood_ . 2016;127(20):2391-2405. doi:10.1182/blood-2016-03-643544  
27. Sekeres MA, Maciejewski JP, List AF, et al. Perceptions of Disease State, Treatment Outcomes, and Prognosis  
Among Patients with Myelodysplastic Syndromes: Results from an Internet-Based Survey. _Oncologist_ . 2011;16(6):904-911. doi:10.1634/theoncologist.2010-0199  
28. Wood EM, McQuilten ZK. Outpatient transfusions for myelodysplastic syndromes. _Hematology_ .  
2020;2020(1):167-174. doi:10.1182/hematology.2020000103  
29. Evers D, Middelburg RA, de Haas M, et al. Red-blood-cell alloimmunisation in relation to antigens’ exposure and  
their immunogenicity: a cohort study. _Lancet Haematol_ . 2016;3(6):e284-e292. doi:10.1016/S2352-3026(16)30019-9  
30. Singhal D, Kutyna MM, Chhetri R, et al. Red cell alloimmunization is associated with development of  
autoantibodies and increased red cell transfusion requirements in myelodysplastic syndrome. _Haematologica_ . 2017;102(12):2021-2029. doi:10.3324/haematol.2017.175752  
31. Lin Y, Saskin A, Wells RA, et al. Prophylactic RhCE and Kell antigen matching: impact on alloimmunization in  
transfusion-dependent patients with myelodysplastic syndromes. _Vox Sang_ . 2017;112(1):79-86. doi:10.1111/vox.12455  
32. Milkins C, Berryman J, Cantwell C, et al. Guidelines for pre-transfusion compatibility procedures in blood  
transfusion laboratories. _Transfus Med_ . 2012;(July). doi:10.1111/j.1365-3148.2012.01199.x  
33. Foukaneli T, Kerr P, Bolton-Maggs PHB, et al. Guidelines on the use of irradiated blood components. _Br J_  
_Haematol_ . 2020;191(5):704-724. doi:10.1111/bjh.17015  
34. Stauder R, Yu G, Koinig KA, et al. Health-related quality of life in lower-risk MDS patients compared with age-  
and sex-matched reference populations: A European LeukemiaNet study. _Leukemia_ . 2018;32(6):1380-1392.  
doi:10.1038/s41375-018-0089-x  
35. Mo A, McQuilten ZK, Wood EM, Weinkove R. Red cell transfusion thresholds in myelodysplastic syndromes: a  
clinician survey to inform future clinical trials. _Intern Med J_ . 2017;47(6):695-698. doi:10.1111/imj.13434  
36. Stanworth SJ, Killick S, McQuilten ZK, et al. Red cell transfusion in outpatients with myelodysplastic syndromes:  
a feasibility and exploratory randomised trial. _Br J Haematol_ . 2020;189(2):279-290. doi:10.1111/bjh.16347  
37. Sagmeister M, Oec L, Gmür J. A restrictive platelet transfusion policy allowing long-term support of outpatients  
with severe aplastic anemia. _Blood_ . 1999;93(9):3124-3126. doi:10.1182/blood.v93.9.3124  
38. Estcourt LJ, Birchall J, Allard S, et al. Guidelines for the use of platelet transfusions. _Br J Haematol_ . 2017;176(3):365-394. doi:10.1111/bjh.14423  
39. Kaufman RM, Djulbegovic B, Gernsheimer T, Kleinman S, Tinmouth AT, Capocelli KE  et al. Platelet Transfusion: A Clinical Practice Guideline From the AABB. In: _Annals of Internal Medicine_ . ; 2015:205-213.  
40. Ministério da Saúde. Consolidação das normas sobre os sistemas e os subsistemas do Sistema Único de Saúde. PORTARIA DE CONSOLIDAÇÃO N<sup>o</sup> 4, DE 28 DE SETEMBRO DE 2017. https://bvsms.saude.gov.br/bvs/saudelegis/gm/2017/prc0004_03_10_2017.html  
41. Yu Z-P, Ding J-H, Sun A-N, Ge Z, Chen B-A, Wu D-P. A Randomized Study Comparing Stem Cell Transplantation Versus Conventional Therapy for Low- and Intermediate-Risk Myelodysplastic Syndromes Patients. _Stem Cells Dev_ . 2017;26(15):1132-1139. doi:10.1089/scd.2017.0031  
42. Affentranger L, Bohlius J, Hallal M, Bonadies N. Efficacy of granulocyte colony stimulating factor in combination with erythropoiesis stimulating agents for treatment of anemia in patients with lower risk myelodysplastic syndromes: A systematic review. _Crit Rev Oncol Hematol_ . 2019;136(January):37-47. doi:10.1016/j.critrevonc.2019.01.021  
43. Park S, Greenberg P, Yucel A, et al. Clinical effectiveness and safety of erythropoietin-stimulating agents for the treatment of low- and intermediate-1−risk myelodysplastic syndrome: a systematic literature review. _Br J Haematol_ . 2019;184(2):134-160. doi:10.1111/bjh.15707  
44. Ferrini PR, Grossi A, Vannucchi AM, et al. A randomized double-blind placebo-controlled study with subcutaneous recombinant human erythropoietin in patients with low-risk myelodysplastic syndromes. _Br J Haematol_ . 1998;103(4):1070-1074. doi:10.1046/j.1365-2141.1998.01085.x  
45. Thompson JA, Gilliland DG, Prchal JT, et al. Effect of recombinant human erythropoietin combined with granulocyte/macrophage colony-stimulating factor in the treatment of patients with myelodysplastic syndrome. _Blood_ . 2000;95(4):1175-1179. doi:10.1182/blood.v95.4.1175.004k51_1175_1179  
46. Fenaux P, Santini V, Spiriti MAA, et al. A phase 3 randomized, placebo-controlled study assessing the efficacy and safety of epoetin-α in anemic patients with low-risk MDS. _Leukemia_ . 2018;32(12):2648-2658. doi:10.1038/s41375-0180118-9  
47. Hellström-Lindberg E, Gulbrandsen N, Lindberg G, et al. A validated decision model for treating the anaemia of myelodysplastic syndromes with erythropoietin + granulocyte colony-stimulating factor: Significant effects on quality of life. _Br J Haematol_ . 2003;120(6):1037-1046. doi:10.1046/j.1365-2141.2003.04153.x  
48. Buckstein R, Balleari E, Wells R, et al. ITACA: A new validated international erythropoietic stimulating agentresponse score that further refines the predictive power of previous scoring systems. _Am J Hematol_ . 2017;92(10):1037-1046. doi:10.1002/ajh.24842  
49. Smith TJ, Khatcheressian J, Lyman GH, et al. 2006 Update of recommendations for the use of white blood cell growth factors: An evidence-based clinical practice guideline. _J Clin Oncol_ . 2006;24(19):3187-3205. doi:10.1200/JCO.2006.06.4451  
50. Hutzschenreuter F, Monsef I, Kreuzer KA, Engert A, Skoetz N. Granulocyte and granulocyte-macrophage colony stimulating factors for newly diagnosed patients with myelodysplastic syndromes. _Cochrane Database Syst Rev_ . 2016;2016(2). doi:10.1002/14651858.CD009310.pub2  
51. Bouscary D, Legros L, Tulliez M, et al. A non-randomised dose-escalating phase II study of thalidomide for the treatment of patients with low-risk myelodysplastic syndromes: The Thal-SMD-2000 trial of the Groupe Français des Myélodysplasies. _Br J Haematol_ . 2005;131(5):609-618. doi:10.1111/j.1365-2141.2005.05817.x  
52. Tamburini J, Elie C, Park S, et al. Effectiveness and tolerance of low to very low dose thalidomide in low-risk myelodysplastic syndromes. _Leuk Res_ . 2009;33(4):547-550. doi:10.1016/j.leukres.2008.06.005  
53. Fenaux P, Giagounidis A, Selleslag D, et al. A randomized phase 3 study of lenalidomide versus placebo in RBC transfusion-dependent patients with Low-/Intermediate-1-risk myelodysplastic syndromes with del5q. _Blood_ . 2011;118(14):3765-3776. doi:10.1182/blood-2011-01-330126  
54. Revicki DA, Brandenburg NA, Muus P, Yu R, Knight R, Fenaux P. Health-related quality of life outcomes of lenalidomide in transfusion-dependent patients with Low- or Intermediate-1-risk myelodysplastic syndromes with a chromosome 5q deletion: Results from a randomized clinical trial. _Leuk Res_ . 2013;37(3):259-265. doi:10.1016/j.leukres.2012.11.017  
55. Giagounidis A, Mufti GJ, Mittelman M, et al. Outcomes in RBC transfusion-dependent patients with Low/Intermediate-1-risk myelodysplastic syndromes with isolated deletion 5q treated with lenalidomide: A subset analysis from the MDS-004 study. _Eur J Haematol_ . 2014;93(5):429-438. doi:10.1111/ejh.12380  
56. Lian XY, Zhang ZH, Deng ZQ, et al. Efficacy and safety of lenalidomide for treatment of low-/Intermediate-1risk myelodysplastic syndromes with or without 5q deletion: A systematic review and meta-analysis. _PLoS One_ . 2016;11(11):116. doi:10.1371/journal.pone.0165948  
57. Scharenberg C, Giai V, Pellagatti A, et al. Progression in patients with low- and intermediate-1-risk del(5q) myelodysplastic syndromes is predicted by a limited subset of mutations. _Haematologica_ . 2017;102(3):498-508. doi:10.3324/haematol.2016.152025  
58. Passweg JR, Giagounidis AAN, Simcock M, et al. Immunosuppressive therapy for patients with myelodysplastic syndrome: A prospective randomized multicenter phase III trial comparing antithymocyte globulin plus cyclosporine with best supportive care - SAKK 33/99. _J Clin Oncol_ . 2011;29(3):303-309. doi:10.1200/JCO.2010.31.2686  
59. Stahl M, Bewersdorf JP, Giri S, Wang R, Zeidan AM. Use of immunosuppressive therapy for management of myelodysplastic syndromes: A systematic review and meta-analysis. _Haematologica_ . 2020;105(1):102-111. doi:10.3324/haematol.2019.219345

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **TERMO DE ESCLARECIMENTO E RESPONSABILIDADE** -->
ALFAEPOETINA, FILGRASTIM E TALIDOMIDA.  
Eu,____________________________________________________________________________________________  
(nome do[a] paciente), declaro ter sido informado(a) sobre benefícios, riscos, contraindicações e principais eventos adversos relacionados ao uso de alfaepoetina, filgrastim e talidomida, indicada para o tratamento da Síndrome Mielodisplásica de baixo risco .  
Os termos médicos foram explicados e todas as dúvidas foram esclarecidas pelo(a) médico(a) _____________________  
_________________________________________________________________________(nome do médico que prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- O uso de alfaepoetina pode aumentar os valores de hemoglobina, reduzir os sintomas de anemia e reduzir a necessidade  
- de transfusão de concentrado de hemácias.  
- O uso de fator estimulador de colônias de granulócitos (G-CSF/filgrastim) associado a alfaepoetina pode aumentar os  
- valores de hemoglobina, reduzir os sintomas de anemia e reduzir a necessidade de transfusão de concentrado de hemácias.  
- O uso de fator estimulador de colônias de granulócitos (G-CSF/filgrastim) pode aumentar a contagem de neutrófilos e  
- reduzir a recorrência de infecções.  
- O uso de talidomida pode aumentar os valores de hemoglobina, reduzir os sintomas de anemia e reduzir a necessidade  
- de transfusão de concentrado de hemácias.  
Fui também claramente informado(a) a respeito das seguintes contraindicações, potenciais eventos adversos e riscos:  
- Os eventos adversos mais comuns da alfaepoetina são: aumento da pressão arterial, cefaleia, náusea, falta de ar, edema, vômito, taquicardia e diarreia em alguns pacientes. Pode ocorrer eritema no local da injeção e sintomas semelhantes aos da gripe (como artralgias e mialgias), que duram de 2 a 4 horas.  
-O uso de alfaepoetina pode causar: deficiência de ferro absoluta ou funcional, aumento do risco de eventos cardiovasculares graves, tais como trombose venosa, acidente vascular cerebral, infarto agudo do miocárdio e tromboembolismo venoso, principalmente quando níveis de hemoglobina alvo atingem mais de 12 g/dL ou um rápido aumento na hemoglobina acima de 1 g/dL em duas semanas. Em pacientes com insuficiência renal crônica, as chances de encefalopatia hipertensiva e convulsões aumentam, particularmente naqueles com histórico anterior de convulsões. Consultas e exames durante o tratamento são necessários.  
- Os eventos adversos mais comuns de filgrastim são: dor musculoesquelética geral (mais frequente), esplenomegalia, trombocitopenia, diarreia, anemia, reação no local de injeção, cefaleia, hepatomegalia, alopecia, osteoporose. Reações alérgicas incluindo anafilaxia, rash cutâneo, urticária, angioedema, dispneia e hipotensão.  
- A talidomida é classificada na gestação como categoria X pelo FDA.  
- O principal evento adverso da talidomida é a teratogenicidade. Outros eventos adversos mais comuns são cardiovasculares (edema, hipotensão ortostática), neurológicos (fadiga, sonolência, tontura, neuropatia periférica, confusão, ansiedade, agitação, febre, cefaleia), dermatológicos (rash cutâneo, descamação, síndrome de Stevens-Johnson, pele seca, acne), endócrinos (hipercalcemia), gastrointestinais (constipação, náusea, anorexia, alteração do peso, diarreia), hematológicos, principalmente nos doentes de AIDS (leucopenia, neutropenia, anemia, linfadenopatia), hepáticos (aumento de transaminases e bilirrubinas), neuromusculares (fraqueza, tremor, mialgia, parestesia, artralgia), renais (hematúria), respiratórios (dispneia), diaforese (sudorese excessiva) e complicações tromboembólicas, incluindo trombose venosa profunda e trombose pulmonar. Menos comumente, ocorre edema facial, insônia, vertigem, dor, dermatite, prurido, alteração ungueal, dislipidemia, xerostomia, flatulência, dor dentária, impotência sexual, disfunção hepática, rigidez de nuca, dor cervical ou lombar, albuminúria. A  
neuropatia periférica pode deixar sequela, e deve-se estar atento a esta complicação, pois quanto mais precoce o seu diagnóstico, maiores são as chances de reversão do quadro. Em caso de neuropatia periférica grau I (parestesia, fraqueza ou perda de reflexos sem perda de função), deve-se considerar redução da dose; em caso de neuropatia periférica grau II ou maior (interferindo com a função), a talidomida deve ser suspensa.  
- A talidomida pode causar neuropatia periférica que pode ser irreversível, gravar a neuropatia periférica pré-existente.  
- Consultas e exames durante o tratamento são necessários.  
- Todos esses medicamentos são contraindicados em casos de hipersensibilidade (alergia) aos fármacos ou aos  
- componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato.  
- (    ) Sim     (    ) Não  
Meu tratamento constará do seguinte medicamento:  
- (    ) Alfaepoetina  
- (    ) Filgrastim  
- (    ) Talidomida  
Local:                                                             Data:  
Nome do paciente: Cartão Nacional de Saúde:  
Nome do responsável legal:  
Documento de identificação do responsável legal:  
<!-- Start of picture text -->
_____________________________________<br>Assinatura do paciente ou do responsável legal<br>Médico responsável:  CRM:  UF:<br>___________________________<br>Assinatura e carimbo do médico<br>Data:____________________<br><!-- End of picture text -->  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontram os medicamentos preconizados neste Protocolo.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **1. Escopo e finalidade do Protocolo** -->
O presente apêndice consiste no documento de trabalho do grupo de elaboração do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) da Síndrome Mielodisplásica de Baixo Risco contendo a descrição da metodologia de busca de evidências científicas, as recomendações e seus julgamentos (fundamentos para a tomada de decisão), tendo como objetivo embasar o texto do PCDT, aumentar a sua transparência e prover considerações adicionais para profissionais da saúde, gestores e demais potenciais interessados.  
O grupo desenvolvedor deste Protocolo foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITIS/SCTIE/MS). O painel de especialistas incluiu médicos hematologistas.  
Todos os participantes do processo de elaboração do PCDT preencheram o formulário de Declaração de Conflitos de Interesse, que foram enviados ao Ministério da Saúde para análise prévia às reuniões de escopo e formulação de recomendações.  
A elaboração desse documento foi iniciada em 19 de maio de 2021, com uma reunião de escopo, a qual definiu as questões clínicas apresentadas neste documento. Não foram realizadas reuniões de recomendações junto ao painel de especialistas, pois o grupo elaborador optou por adotar as recomendações presentes nos documentos previamente publicados:  
- Portaria, SAS/MS nº 113, de 4 de fevereiro de 2016 (PCDT de Anemia Aplástica, Mielodisplasia e Neutropenias  
- Constitucionais – Uso de Fatores Estimulantes de Crescimento de Colônias de Neutrófilos) e  
- Portaria, SAS/MS nº 493, de 11 de junho de 2015 (Protocolo de Uso de Talidomida no Tratamento da Síndrome  
- Mielodisplásica).

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **2. Equipe de elaboração e partes interessadas** -->
O grupo desenvolvedor desta diretriz foi composto por um painel de especialistas sob coordenação do Departamento de Gestão e Incorporação de Tecnologias em Saúde da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos do Ministério da Saúde (DGITS/SCTIE/MS).  
As reuniões de escopo e de recomendações contaram com a participação de médicos hematologistas, além de representantes do Ministério da Saúde, hospitais de excelência, sociedades médicas, sociedades sem fins lucrativos e associação de pacientes.  
Este grupo foi responsável pelo julgamento das evidências propostas em resposta às questões da diretriz e das suas respectivas recomendações, além da revisão do documento final.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Conflito de Interesses** -->
Todos os membros votantes e metodologistas do Grupo Elaborador declararam seus conflitos de interesses, utilizando a Declaração de Potenciais Conflitos de Interesses ( **Quadro A** ).  
**Quadro A** - Questionário de conflito de interesses relativos a diretrizes clínico-assistenciais.  
|1. Você já aceitou de uma instituição que pode se beneficiar ou se prejudicar financeiramente|algum dos benefícios abaixo?|
|---|---|
|a) Reembolso por comparecimento a eventos na área de interesse da diretriz|(   ) Sim<br>(   ) Não|
|b) Honorários por apresentação, consultoria, palestra ou atividades de ensino|(   ) Sim<br>(   ) Não|
|c) Financiamento para redação de artigos ou editorias|(   ) Sim|  
||(   ) Não|
|---|---|
|d) Suporte para realização ou desenvolvimento de pesquisa na área|(   ) Sim<br>(   ) Não|
|e) Recursos ou apoio financeiro para membro da equipe|(   ) Sim<br>(   ) Não|
|f) Algum outro benefício financeiro|(   ) Sim<br>(   ) Não|
|2. Você possui apólices ou ações de alguma empresa que possa de alguma forma ser beneficiada ou<br>prejudicada com as recomendações da diretriz?|(   ) Sim<br>(   ) Não|
|3. Você possui algum direito de propriedade intelectual (patentes, registros de marca, royalties) de alguma<br>tecnologia ligada ao tema da diretriz?|(   ) Sim<br>(   ) Não|
|4. Você já atuou como perito judicial na área tema da diretriz?|(   ) Sim<br>(   ) Não|
|5. Você participa, direta ou indiretamente, de algum grupo citado abaixo cujos interesses possam ser a<br>atividade na elaboração ou revisão da diretriz?|fetados pela sua|
|a) Instituição privada com ou sem fins lucrativos|(   ) Sim<br>(   ) Não|
|b) Organização governamental ou não-governamental|(   ) Sim<br>(   ) Não|
|c) Produtor, distribuidor ou detentor de registro|(   ) Sim<br>(   ) Não|
|d) Partido político|(   ) Sim<br>(   ) Não|
|e) Comitê, sociedade ou grupo de trabalho|(   ) Sim<br>(   ) Não|
|f) Outro grupo de interesse|(   ) Sim<br>(   ) Não|
|6. Você poderia ter algum tipo de benefício clínico?|(   ) Sim<br>(   ) Não|
|7. Você possui uma ligação ou rivalidade acadêmica com alguém cujos interesses possam ser afetados?|(   ) Sim<br>(   ) Não|
|8. Você possui profunda convicção pessoal ou religiosa que pode comprometer o que você irá escrever e<br>que deveria ser do conhecimento público?|(   ) Sim<br>(   ) Não|
|9. Existe algum aspecto do seu histórico profissional, que não esteja relacionado acima, que possa afetar<br>sua objetividade ou imparcialidade?|(   ) Sim<br>(   ) Não|
|10. Sua família ou pessoas que mantenha relações próximas possui alguns dos conflitos listados acima?|(   ) Sim<br>(   ) Não|

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Avaliação da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas** -->
A proposta de elaboração do PCDT da Síndrome Mielodisplásica de Baixo Risco foi apresentada à 98ª Reunião da Subcomissão Técnica de Avaliação de Protocolos Clínicos e Diretrizes Terapêuticas, realizada em 19 de abril de 2022. A reunião teve a presença de representantes da Secretaria de Ciência, Tecnologia, Inovação e Insumos Estratégicos em Saúde (SCTIE); Secretaria de Atenção Especializada em Saúde (SAES) e Secretaria de Vigilância em Saúde (SVS). O PCDT foi aprovado para avaliação da Conitec, com a exclusão dos códigos da CID não especificados. A proposta foi apresentada aos membros do Plenário da Conitec à sua 108ª Reunião Ordinária, os quais recomendaram favoravelmente ao texto.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **3. Busca da evidência e recomendações** -->
O processo de desenvolvimento desse PCDT envolveu a realização de revisões sistemáticas (RS) e ensaios clínicos randomizados (ECR) para as sínteses de evidências e foram adotadas ou adaptadas as recomendações de diretrizes já publicadas para as tecnologias que se encontram disponíveis no SUS para as respectivas condições. Na sequência, são apresentadas para cada uma das questões clínicas, os métodos e resultados das buscas, as recomendações do painel e um resumo das evidências. Para as tecnologias recomendadas, foram apresentadas justificativas e as considerações gerais.  
**QUESTÃO 1:** Para pacientes adultos com Síndrome Mielodisplásica de baixo risco (SMD-BR), o uso da alfaepoetina, quando comparada ao suporte transfusional, é seguro, eficaz e custo-efetivo?  
**Recomendação:** após avaliação pela Conitec, houve recomendação favorável à ampliação de uso da alfaepoetina para tratar pacientes com Síndrome Mielodisplásica de Baixo Risco (SMD-BR) no âmbito do SUS. A estrutura PICO para esta pergunta foi: **População -** Indivíduos adultos diagnosticados com SMD-BR **Intervenção -** Alfaepoetina **Comparador -** Suporte transfusional **Desfechos** - Resposta eritroide; sobrevida; 1ualidade de vida e segurança **Métodos e resultados da busca:**  
Para realizar a análise de evidências, foram utilizadas as referências e síntese de evidências apresentadas no Relatório de Recomendação nº 698/2022, relativo à proposta de ampliação de uso da alfaepoetina. Utilizou-se a estratégia ilustrada no **Quadro B** , com a finalidade de se elaborar uma síntese de evidências atualizadas. Além de consultar as referências citadas, foi realizada a busca nas bases PubMed, EMBASE e Cochrane Reviews. Os resultados dessas bases foram exportados para a base RAYYAN<sup>®</sup> , permitindo que dois observadores independentes fizessem a avaliação dos artigos encontrados, sendo que as divergências foram posteriormente resolvidas, após a abertura do cegamento, em reunião presencial, e um terceiro revisor serviu para auxiliar em casos específicos. Além dessa estratégia citada anteriormente, os dois avaliadores consultaram as referências bibliográficas utilizadas para a composição das duas RS publicadas recentemente sobre o tema<sup>1,2</sup> , para identificar alguma publicação adicional que não tenha sido evidenciada pela estratégia de busca inicial. Durante a busca manual, observou-se que essas revisões citavam um artigo que não tinha sido identificado pela estratégia de busca inicial. Sendo assim, o mesmo foi incluído após a leitura. Dessa forma, três artigos descrevendo ensaios clínicos randomizados e controlados foram avaliados nesse primeiro momento<sup>3,4,5</sup> para a síntese de evidências ( **Figura 1** ).  
**Quadro B** – Descritores utilizados e número de publicações identificadas nas bases de dados consultadas para responder à questão sobre o uso de alfaepoetina em pacientes adultos com Síndrome Mielodisplásica de baixo risco.  
|**Base de**<br>**dados**||**Termos**|**Publicações**|
|---|---|---|---|
|**PUBMED**<br>**(Medline)**|(EPO<br>agents<br>Myelo<br>myelo|or epoetin or "erythropoietin stimulating proteins" or "erythropoietin stimulating<br>" or ea or "epoetin alfa" or "epoetin alfa"[Mesh ]) AND (" Low risk<br>dysplastic syndromes"[Mesh] or "Myelodysplastic syndrome" or<br>dysplasia)|205|
|**Embase**|#1 (ep<br>'erythr<br>'recom<br>#2 (“M<br>myelo<br>#3 (“B<br>#4 'cli<br>('phase<br>('rando<br>#5   #1|o OR 'epoetin'/exp OR epoetin OR 'erythropoietin stimulating proteins' OR<br>opoietin stimulating agents' OR esa OR 'epoetin alfa'/exp OR 'epoetin alfa' OR<br>binant erythropoietin'/exp OR 'recombinant erythropoietin') 76102 hits<br>yelodysplastic syndromes”/exp or “Myelodysplastic syndrome” or MDS or<br>dysplasia) 102703 hits<br>lood transfusion”/exp or “Blood transfusion”) 247134 hits<br>nical trial'/exp AND topic OR ('phase 3 clinical trial':ab,ti AND topic:ab,ti) OR<br>2 clinical trial':ab,ti AND topic:ab,ti) OR 'randomized controlled trial'/exp OR<br>mized controlled trial'/exp AND topic) 695009 hits<br>AND #2 AND #3 AND #4|279|
|**Cochrane**|#1|EPO 2319 hits|762|
|**Reviews**|#2<br>#3<br>#4<br>#5<br>#6<br>#10<br>#11<br>#12<br>#13<br>#15<br>#17<br>#18<br>#19|epoetin 1628 hits<br>“erythropoietin stimulating proteins” 1 hits<br>“erythropoietin stimulating agents” 65 hits<br>ESA 1021 hits<br>“epoetin alfa” 1094 hits<br>#7<br>MeSH descriptor: [Epoetin Alfa] explode all trees 697 hits<br>#8<br>#1 OR #2 OR #3 OR #4 OR #5 OR #6 OR #7 OR #8 6113 hits<br>#9<br>MeSH descriptor: [Myelodysplastic Syndromes] explode all trees 727<br>hits<br>“Myelodysplastic syndrome” 1727 hits<br>MDS 5622 hits<br>myelodysplasia 286 hits<br>#10 OR #11 OR #12 OR #13 6684 hits<br>#14<br>MeSH descriptor: [Blood Transfusion] explode all trees 3646 hits<br>“Blood transfusion” 9374 hits<br>#16<br>MeSH descriptor: [Clinical Trials as Topic] explode all trees 48407<br>hits<br>("Controlled Clinical Trial"):pt 90431 hits<br>("randomized controlled trial"):pt 518722 hits<br>("clinical trial"):pt 328394 hits<br>#20<br>MeSH descriptor: [Randomized Controlled Trial] explode all trees<br>119 hits<br>#21<br>MeSH descriptor: [Random Allocation] explode all trees 20643 hits||  
|**Base de**<br>**dados**|||**Termos**|**Publicações**|
|---|---|---|---|---|
|||#22|MeSH descriptor: [Clinical Trials as Topic] explode all trees 48407||
|||hits|||
||#23|(place|bo):ti,ab,kW 321949 hits||
||#24|(rando|mly):ti,ab,kW 264798 hits||
||#25|"clinic|al trial" 680104 hits||
|||#26|MeSH descriptor: [Double-Blind Method] explode all trees 142481||
|||hits|||
||#27|("doub|le-blind"):ti,ab,kw 298459 hits||
||#28|#15 O|R #16 10330 hits||
|||#29|#17 OR #18 OR #19 OR #20 OR #21 OR #22 OR #23 OR #24 OR||
|||#25 O|R #26 OR #27 OR #28 1132401 hits||
||#30|#9 AN|D #14 AND #29 AND #30||
|**Total**|-|||**1246**|  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: Alfaepoetina  
- (c) Tipos de estudos: RS ou ensaio clínico randomizado (ECR)  
- (d) Desfechos: Resposta eritroide; Sobrevida; Qualidade de vida e Segurança  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem  
Dois ECRs que utilizaram alfaepoetina subcutânea comparada com placebo foram selecionados a partir de uma busca  
bibliográfica conduzida nas bases PubMed, EMBASE e Cochrane Reviews.  
**Figura 1** – Fluxograma de busca, localização, seleção e inclusão de estudos sobre o uso da alfaepoetina, segundo recomendações do checklist PRISMA.  
<!-- Start of picture text -->
Identifieagdo cette 270) Identificados em<br>|| CochraneFeinc/Pubmed(n = 762)(n = 205) Dupleadosremovdes(9=216) | | reeréncias bibles<br>Excluidos (n = 1028)<br>Rastreados = Moti<br>(n = 1030)  Populagéo-Desenho de diferente estudo (n (n= =290) 516) Rastreados (n = 2) eerie n= 0<br>~ tipo de publicagao (n = 77)<br>Elegiveis (n = 2) -“ourimo noRreapresentamtrenneis)os(n=desfechos 83) [enwesons |<br>= lingua estrangeira (n = 11)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
Dois ECRs identificados utilizaram alfaepoetina subcutânea comparada com grupo placebo, sendo que o estudo realizado em 2018<sup>5</sup> foi considerado o mais adequado, pois apresentava os resultados clínicos de acordo com a classificação atual da SMD  
e de resposta eritroide esperada, além de ter sido realizado em 27 centros colaboradores. Fenaux et al.<sup>5</sup> , consideraram os resultados de 128 pacientes, apresentando resposta eritroide para alfaepoetina em 31,8% dos pacientes do grupo intervenção, em comparação a 4,6% dos pacientes do grupo placebo (p<0,01), após seguimento de 24 semanas. Além desse estudo, recuperouse uma pesquisa publicada em 1988 pelo _Italian Cooperative Study Group for rHuEpo in Myelodysplastic Syndromes_ que considerou os resultados de 75 pacientes, alcançando resposta eritroide plena ou parcial combinadas em 36,8% dos indivíduos do grupo intervenção e em 10,8% dos pacientes do grupo placebo (p<0,05), após seguimento de oito semanas<sup>3</sup> .  
Sendo assim, uma meta-análise foi realizada considerando esses dois estudos<sup>3,5</sup> , totalizando 123 pacientes incluídos no grupo intervenção e 80 pacientes incluídos no grupo controle. Como resultado, a resposta eritroide alcançada foi de 33,3% no grupo intervenção e 7,5% no grupo controle, levando a um risco relativo (RR) de 4,34 (IC95% 1,91-9,85). Além da resposta eritroide, a meta-análise avaliou a segurança da alfaepoetina, obtendo valores semelhantes de eventos adversos no grupo intervenção e controle, alcançando RR de 0,96 (IC95% 0,69-1,34). Apenas um estudo avaliou a qualidade de vida, e não houve diferença nesse desfecho entre os grupos em qualquer período. Entretanto, a qualidade de vida na 24ª semana de uso foi significativamente diferente entre os pacientes que responderam à alfaepoetina e o grupo placebo (Escore do índice EQ-5D p = 0,034). A qualidade da evidência dos estudos foi avaliada utilizando-se o GRADE<sup>6</sup> , sendo classificada como moderada para os desfechos resposta eritroide, qualidade de vida e segurança, conforme apresentado no Relatório de Recomendação nº 698/2022. A sobrevida com o uso do medicamento não foi avaliada porque não foi encontrada referência na literatura para este desfecho.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Justificativa para a recomendação:** -->
O grupo elaborador optou por recomendar a ampliação de uso da alfaepoetina para o tratamento de pacientes com SMD de baixo risco (SMD-BR) com indicação de uso no SUS, uma vez que houve recomendação favorável pela Conitec.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Considerações gerais e para implementação:** -->
Em relação ao uso de alfaepoetina para o tratamento de pacientes adultos com SMD de baixo risco, a evidência considerada foi composta por dois ECR de qualidade moderada, de acordo com o GRADE<sup>6</sup> , com resultados favoráveis quanto aos desfechos resposta eritroide e segurança, conforme meta-análise conduzida. A análise de custo-efetividade encontrou que, em relação ao suporte transfusional, o uso da alfaepoetina pode proporcionar uma redução de R$ 7.659,52/ano por paciente com RCEI de - R$ 294,38, ou seja, haveria uma economia com o uso dessa tecnologia para o tratamento da SMD-BR. Na avaliação de impacto orçamentário, a incorporação da alfaepoetina resultaria em economia de recursos de até 51,9% (até R$ 321 milhões), em relação ao cenário referência (suporte transfusional).  
O Plenário da Conitec, em sua 105ª Reunião Ordinária, nos dias 09 e 10 de fevereiro de 2022, deliberou recomendação final favorável à ampliação de uso da alfaepoetina para o tratamento de pacientes com Síndrome Mielodisplásica de Baixo Risco no âmbito do SUS. Os membros da Conitec consideraram os resultados apresentados (resposta eritroide, qualidade de vida, segurança e avaliação econômica), bem como os argumentos relacionados ao acesso ao medicamento, levantados pelo Plenário, para tomar essa decisão.  
Inclusão:  
- Pacientes adultos com diagnóstico de SMD de baixo risco e anemia.  
Exclusão:  
- Não se aplica.  
Contraindicações:  
- A alfaepoetina é contraindicada nos casos conhecidos de hipersensibilidade à alfaepoetina, à albumina sérica humana  
- ou a produtos derivados de células de mamíferos.  
Casos especiais:  
● Embora o risco de trombose seja baixo, parece apropriado interromper temporariamente a terapia com alfaepoetina se houver um rápido aumento do hematócrito, ou se o nível de hemoglobina subir acima de 12 g/L. Doses mais baixas de alfaepoetina podem ser introduzidas com monitoramento cuidadoso dos parâmetros de resposta.  
● Pacientes com baixo peso e com déficit de função renal devem utilizar dose reduzida de alfaepoetina.  
- Esquemas de administração e tempos de tratamento:  
- Apresentação: solução injetável ou pó para solução injetável 10.000 UI (unidades) de alfaepoetina.  
- Posologia: a dose inicial recomendada é de 30.000 a 40.000 UI (ou 450 UI/kg) por semana, via subcutânea.  
● Ajustes de dose: na ausência de resposta à alfaepoetina na dose de 30.000–40.000 UI/semana em oito semanas, a dose pode ser aumentada para uma dose máxima de 60.000 UI (cerca de 1050 UI/kg) por semana (dividida em uma ou duas administrações) por mais oito semanas. Doses acima de 60.000 UI por semana não são toleradas. Para pacientes que não apresentem resposta satisfatória após 16 semanas, recomenda-se adição de filgrastim durante as 8 semanas seguintes. Uma dose inicial 300 mcg de filgrastim por semana ou dividida em 2 a 3 administrações por semana, aumentando para 300 mcg três vezes por semana em não respondedores, é apropriada. No entanto, o esquema posológico deve ser adaptado individualmente para pacientes de acordo com a necessidade e resposta. A dose de filgrastim deve ser adequada para dobrar a contagem inicial de células brancas se a contagem de leucócitos estiver abaixo de 1,5 x 10<sup>9</sup> /L ou a contagem de leucócitos deve ser mantida se a contagem inicial de leucócitos estiver entre 6–10 x 10<sup>9</sup> /L.  
● Tempo de tratamento/critérios de interrupção: Os critérios para definir a resposta completa é nível de hemoglobina acima de 11,5 g/L e independência transfusional. Já a resposta eritroide parcial é definida como incremento acima de 2 g/L nos níveis de hemoglobina e independência transfusional, apesar de o nível de hemoglobina permanecer abaixo de 11,5 g/L. Alguns pacientes podem alcançar resultados potencialmente benéficos por prolongar o intervalo entre as transfusões, embora esta medida não seja critério de resposta reconhecido. No início do tratamento, os pacientes devem receber o medicamento por até 24 semanas, a fim de determinar sua resposta. Durante essas 24 semanas, deve-se usar a dose inicial de alfaepoetina nas oito primeiras semanas e nas oito semanas, as doses mais altas, se necessário. Nas últimas oito semanas, deve-se associar o uso de alfaepoetina ao filgrastim, caso o tratamento tenha falhado. Pacientes que atingem uma resposta eritroide completa ou parcial por critérios aceitos devem continuar em terapia de longo prazo na dose mínima de alfaepoetina necessária para manter a resposta ou até que a resposta seja perdida.  
● Eventos adversos: pacientes em terapia com alfaepoetina podem desenvolver deficiência de ferro absoluta ou funcional, aumento do risco de eventos cardiovasculares graves, tais como trombose venosa, acidente vascular cerebral, infarto agudo do miocárdio e tromboembolismo venoso, principalmente quando os níveis de hemoglobina atingem mais de 12 g/dL ou ocorre um rápido aumento na hemoglobina (acima de 1 g/dL em duas semanas). No início do tratamento, pode haver aumento da pressão arterial após a administração de alfaepoetina, quando o hematócrito está aumentando agudamente. Em pacientes com insuficiência renal crônica, as chances de encefalopatia hipertensiva e convulsões aumentam, particularmente naqueles com histórico anterior de convulsões. Também foram relatados cefaleia, náusea, falta de ar, edema, vômito, taquicardia e diarreia em alguns pacientes. Pode ocorrer eritema no local da injeção e sintomas semelhantes aos da gripe (como artralgias e mialgias), que duram de 2 a 4 horas.  
**QUESTÃO 2:** Devemos utilizar fator estimulador de colônias de granulócitos em pacientes com SMD de baixo risco?  
**Recomendação:** Manteve-se a recomendação de utilizar o fator estimulador de granulócitos em pacientes com SMD de baixo risco (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com SMD de baixo risco  
**Intervenção -** Fator estimulador de colônias de granulócitos  
**Comparador -** Seguimento clínico sem intervenção  
**Desfechos** - Resposta hematológica; sobrevida global

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Métodos e resultados da busca:** -->
Para a tomada de decisão, foram consideradas as evidências descritas no PCDT de Anemia Aplástica, Mielodisplasia e Neutropenias Constitucionais (Portaria SAS/MS nº 113, de 04 de fevereiro de 2016), e, adicionalmente, foi estruturada e realizada uma busca sistemática para localizar as novas evidências acerca da questão. Com base na pergunta PICO estruturada, foi realizada busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro C** . Foram selecionadas as revisões sistemáticas com meta-análise (RSMA) e, na ausência de RSMA, ECR.  
**Quadro C -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de fator estimulador de colônias de granulócitos em pacientes com SMD de baixo risco.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**<br>**Pubmed**<br>**18/01/2022**|#1  "Granulocyte Colony-Stimulating Factor"[Mesh] OR  "Filgrastim"[Mesh] OR<br>G-CSF OR “Recombinant-Methionyl Human Granulocyte Colony-Stimulating<br>Factor” OR  “Recombinant Methionyl” OR “Human Granulocyte Colony<br>Stimulating Factor” OR “G-CSF Recombinant, Human Methionyl” OR “G CSF<br>Recombinant, Human Methionyl” OR  “R-metHuG-CSF” OR “R metHuG CSF”<br>OR Zarxio OR “Filgrastim-sndz” OR “Tbo-Filgrastim” OR “Tbo Filgrastim” OR<br>Granix OR Topneuter OR Neupogen<br>#2 “Myelodysplastic syndromes”[Mesh]  OR “MDS” OR “Myelodysplastic<br>Syndrome” OR “Syndromes Myelodysplastic”  OR “Dysmyelopoietic<br>Syndromes” OR “Dysmyelopoietic Syndrome” OR “Syndrome, Dysmyelopoietic”<br>OR “Syndromes, Dysmyelopoietic” OR “Hematopoetic Myelodysplasia” OR<br>“Hematopoetic Myelodysplasias” OR “Myelodysplasia, Hematopoetic” OR<br>“Myelodysplasias, Hematopoetic”<br>#3 "Blood Transfusion"[Mesh] OR “Blood Transfusions” OR “Transfusion,<br>Blood” OR “Transfusions, Blood”<br>#4 "Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR “Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR “clinical trials as topic” [Mesh] OR<br>“placebo”[tiab] OR “randomly”[tiab] OR “clinical trial”[tiab] OR "double-blind<br>method"[MeSH] OR "double-blind”[tiab]<br>Estratégia final: #5 #1 AND #2 AND #3 AND #4|**19**|
|**Embase**<br>**18/01/2022**|#1  ('myelodysplastic syndrome'/exp OR 'mds (myelodysplastic syndrome)' OR<br>'bone marrow dysplasia' OR 'myelodysplasia' OR 'myelodysplastic syndrome' OR<br>'myelodysplastic syndromes' OR 'syndrome, myelodysplastic') AND ('blood<br>transfusion'/exp OR 'blood exchange' OR 'blood infusion' OR 'blood replacement'|**78**|  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
||OR 'blood retransfusion' OR 'blood transfusion' OR 'hemotherapy' OR<br>'multitransfusion' OR 'polytransfusion' OR 'retransfusion' OR 'transfusion blood'<br>OR 'transfusion therapy' OR 'transfusion, blood') AND ('granulocyte colony<br>stimulating factor'/exp OR 'g csf' OR 'colony stimulating factor, granulocyte' OR<br>'granulocyte colony stimulating factor' OR 'granulocyte colony-stimulating factor'<br>OR 'filgrastim'/exp OR 'accofil' OR 'ax 200' OR 'ax200' OR 'biofigran' OR<br>'biograstim' OR 'bnt 002' OR 'bnt002' OR 'colstim' OR 'da 3030' OR 'da3030' OR<br>'ep 2006' OR 'ep2006' OR 'fegrast' OR 'ficocyte' OR 'filgrastim' OR 'filgrastim aafi'<br>OR 'filgrastim hexal' OR 'filgrastim ratiopharm' OR 'filgrastim sndz' OR<br>'filgrastim-aafi' OR 'filgrastim-sndz' OR 'gracin' OR 'grafeel' OR 'gran' OR 'granix'<br>OR 'granulen' OR 'granulokine' OR 'granulostim' OR 'grasin' OR 'grastofil' OR<br>'grimatin' OR 'ins 19' OR 'ins19' OR 'krn 8601' OR 'krn8601' OR 'leucostim' OR<br>'leukostim' OR 'meograstim' OR 'mk 4214' OR 'mk4214' OR 'mngx 100' OR<br>'mngx100' OR 'neopogen' OR 'neotromax' OR 'neukine' OR 'neupogen' OR<br>'neutrogen' OR 'neutromax' OR 'neutroval' OR 'nivestim' OR 'nivestym' OR 'nufil'<br>OR 'nupen' OR 'nupogen' OR 'ratiograstim' OR 'religrast' OR 'scilocyte' OR 'tbo<br>filgrastim' OR 'tbo-filgrastim' OR 'tevagrastim' OR 'topneuter' OR 'tx 01' OR 'tx01'<br>OR 'xm 02' OR 'xm02' OR 'zarxio' OR 'zarzio')<br>#2 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial'<br>OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,<br>randomized controlled' OR 'systematic review'/exp) AND [embase]/lim<br>Estratégia final: #3 #1 AND #2||
|**Cochrane**<br>**Library**<br>**18/01/2022**|#1 "granulocyte colony stimulating factor" OR MeSH descriptor: [Granulocyte<br>Colony-Stimulating Factor] explode all trees OR Filgrastim<br>#2 MeSH descriptor: [Myelodysplastic Syndromes] this term only<br>#3 MeSH descriptor: [Blood Transfusion] this term only<br>Estratégia final: #4 #1 AND #2 AND #3|**50**|  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: fator estimulador de colônias de granulócitos  
- (c) Tipos de estudos: RS ou RCR  
- (d) Desfechos: resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resultados da busca:** -->
Para responder a dúvida clínica, foi considerada 01 (uma) RS, sendo descritos os resultados do ECR que se encaixou na  
PICO estabelecida a _priori_ . O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 2** .  
**Figura 2** - Fluxograma de seleção dos estudos incluídos sobre o uso de fator estimulador de colônias de granulócitos em pacientes com SMD de baixo risco.  
<!-- Start of picture text -->
identincagao || Eraser= 78) Dupleadosremovides n= | | Weniieadosem<br>Medline/PubmedCochrane (n = 50)(n = 19) 11) Busca de citecden,i  (n=0)<br>Excluidos (n = 127)<br>Motivos:<br>Rastreados (n = 136) - Populacdo diferente (n = Rastreados (n = 0) | Excluidos (n= 0)<br>27)<br>- Desenho de estudo (n =<br>27)<br>-desfechosnao apresentamde interesse os (n Elegiveis (n = 0)<br>Elegiveis (n = 9) =9)<br>“nla itevengto (n= 63)<br>“ing estongera (n=)<br>Estudos inidos(n =1)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
A RS de Hutzschenreuter et al.<sup>7</sup> foi utilizada para discutir as evidências relacionadas com a questão clínica. Entre os estudos incluídos a revisão, apenas um ECR atendeu todos os critérios estabelecidos a priori na PICO, ou seja, comparação do fator estimulador de colônias de granulócitos (G-CSF) com o tratamento observacional. Os demais incluíam a eritropoietina como fator de comparação. O estudo de Greenberg (1993)<sup>8</sup> foi publicado apenas no formato de resumo e, assim, o risco de viés do ECR não foi avaliado. Este estudo avaliou o uso de G-CSF comparado ao controle (observação) por um período de 9 meses (1 a 30 meses). O tempo mediano até a progressão para leucemia mieloide aguda (LMA) não foi alcançado no grupo G-CSF e foi de, aproximadamente, 16 meses no grupo controle, sem diferença entre os grupos (p = 0,7) na análise geral. O estudo também apresentou resultados subdivididos em dois grupos, de acordo com a presença de anemia refratária com excesso de blastos (AREB) ou anemia refratária com excesso de blastos em transformação (AREB-t). A incidência de progressão para LMA no grupo AREB foi de 14% entre os pacientes que receberam G-CSF e de 18%, no grupo controle. No grupo AREB-t, a incidência foi de 60% no grupo G-CSF e de 41%, no controle. A sobrevida avaliada no subgrupo AREB-t foi semelhante entre os grupos G-CSF e controle (p > 0,9). No subgrupo REAB, a sobrevida mediana foi menor no grupo que recebeu G-CSF (10,4 vs 21,4 meses, p = 0,02). Porém, o estudo não apresentou homogeneidade entre os grupos quanto ao total de pacientes classificados com um prognóstico de risco mais alto (29% vs 14%). A redução da sobrevida ficou evidenciada apenas no grupo com alto risco, quando comparado ao grupo G-CSF e controle (p = 0,006).

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Justificativa para a recomendação:** -->
Foi mantida a recomendação de uso de filgrastim, que já constava no Protocolo Clínico e Diretrizes Terapêuticas da Anemia Aplástica, Mielodisplasia e Neutropenias Constitucionais – Uso de Fatores Estimulantes de Crescimento de Colônias de Neutrófilos (Portaria SAS/MS nº 113, de 04 de fevereiro de 2016).

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador das recomendações considerou que o fator de crescimento de colônias de granulócitos (GCSF/filgrastim) está indicado para pacientes com SMD de baixo risco com contagem de neutrófilos abaixo de 0,5 x 10<sup>9</sup> /L e com infecções resistentes ou infecções de repetição. O filgrastim também deve ser utilizado por pacientes adultos com diagnóstico de SMD de baixo risco e anemia, que não apresentem resposta eritroide satisfatória ao uso de alfaepoetina após 16 semanas.  
Como não existem dados suficientes sobre a utilização de filgrastim em mulheres grávidas e sobre sua excreção no leite humano, este medicamento não deve ser utilizado durante a gravidez ou que estejam amamentando, a menos que o benefício do seu uso supere os riscos.  
- Inclusão:  
- Para uso de fator estimulador de colônias de granulócitos, serão incluídos pacientes com SMD de baixo risco e: o (i) contagem de neutrófilos abaixo de 0,5 x 10<sup>9</sup> /L e infecções resistentes ou infecções de repetição ou; o (ii) anemia, que não apresentem resposta eritroide satisfatória após uso de alfaepoetina durante 16 semanas.  
- Exclusão:  
- Pacientes com contagem de neutrófilos acima de 10 x 10<sup>9</sup> /L.  
- Contraindicações:  
- Filgrastim é contraindicado para pacientes com hipersensibilidade conhecida ao filgrastim ou a qualquer componente  
- da formulação.  
Casos especiais:  
● Gravidez: Não existem dados suficientes sobre a utilização de filgrastim em mulheres grávidas. Há relatos na literatura acerca da passagem de filgrastim através da placenta em mulheres grávidas. Estudos em animais revelaram toxicidade reprodutiva. O risco potencial para os seres humanos é desconhecido. O filgrastim não deve ser utilizado durante a gravidez, a menos que seja claramente necessário.  
● Lactação: não há informações acerca da excreção de filgrastim no leite humano e esta não foi estudada em animais. A manutenção ou interrupção do tratamento em mulheres que estejam em aleitamento deve considerar os riscos e benefícios para a paciente e seu lactente.  
- O filgrastim apresenta influência baixa a moderada sobre a capacidade de dirigir e operar máquinas. Recomenda-se  
- cautela ao dirigir e operar máquinas caso o paciente apresente fadiga.  
Esquemas de administração e tempos de tratamento:  
- Apresentação: solução injetável contendo 300 mcg de filgrastim.  
- Posologia:  
o Para correção da neutropenia: a dose recomendada é de 5 mcg/kg/dia.  
o Para uso associado à alfaepoetina: recomenda-se uma dose inicial de 300 mcg por semana, dividida em 2 a 3 administrações por semana, aumentando para até 900 mcg, dividida em três administrações semanais, em não respondedores.  
- Ajustes de dose:  
- O esquema posológico deve ser adaptado individualmente para pacientes de acordo com a necessidade e resposta.  
- A dose de filgrastim deve ser individualizada em pacientes neutropênicos para manter contagem de neutrófilos acima  
- de 1 x 10<sup>9</sup> /L  
`o` A dose de filgrastim associada à alfaepoetina deve ser adequada para dobrar a contagem inicial de leucócitos nos pacientes com contagem de leucócitos abaixo de 1,5 x 10<sup>9</sup> /L no início do tratamento, ou para manter a contagem de leucócitos nos pacientes com contagem de leucócitos entre 6 e 10 x 10<sup>9</sup> /L no início do tratamento.  
- Tempo de tratamento/critérios de interrupção:  
`o` Para correção da neutropenia: o tratamento deve ser mantido a critério clínico, de acordo com a recorrência de infecções e contagem de neutrófilos.  
`o` Para uso associado à alfaepoetina: Pacientes que atingem uma resposta eritroide completa ou parcial devem continuar em terapia de longo prazo na dose mínima de filgrastim associado à alfaepoetina necessária para manter a resposta ou até que a resposta seja perdida. O uso de filgrastim deve ser interrompido na ausência de resposta eritroide após 8 semanas de uso associado à alfaepoetina. Os critérios para definir a resposta eritroide completa são nível de hemoglobina acima de 11,5 g/L e independência transfusional. Já a resposta eritroide parcial é definida como o incremento maior que 2 g/L no nível de hemoglobina e independência transfusional, apesar de o nível de hemoglobina permanecer abaixo de 11,5 g/L.  
● Eventos adversos: A reação adversa mais frequente é dor musculoesquelética geral. Outras reações adversas incluem esplenomegalia, trombocitopenia, diarreia e anemia. Podem ocorrer aumentos transitórios do ácido úrico sérico, da desidrogenase lática, fosfatase alcalina e gama-glutamil transferase, sem quaisquer sintomas clínicos. Reações adversas possivelmente relacionadas à terapia com filgrastim incluem reação no local de injeção, cefaleia, hepatomegalia, artralgia, alopecia, osteoporose. Reações alérgicas incluindo anafilaxia, rash cutâneo, urticária, angioedema, dispneia e hipotensão, ocorrendo no tratamento inicial ou subsequente, foram relatadas em pacientes recebendo filgrastim. O filgrastim deve ser suspenso de forma permanente em pacientes que sofram reações alérgicas graves. Após uso prolongado, casos de vasculite cutânea foram relatados em 2% dos pacientes.  
**QUESTÃO 3:** Devemos utilizar agente imunomodulador lenalidomida em pacientes com SMD de baixo risco?  
**Recomendação** : como a lenalidomida não foi avaliada para incorporação para tratamento desta condição no âmbito do SUS, este Protocolo não preconiza o uso desta tecnologia. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com SMD com deleção 5q **Intervenção -** Lenalidomida  
**Comparador -** Suporte transfusional  
**Desfechos -** Resposta hematológica; sobrevida global **Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foi realizada uma busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro D** . Foram selecionadas as RSMA e, na ausência de RSMA, ECR.  
**Quadro D -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de agente imunomodulador lenalidomida em pacientes com SMD de baixo risco.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**|#1 ("Lenalidomide"[Mesh]) OR “Lenalidomide”|**29**|
|**Pubmed**|||
|**18/01/2022**|#2 “Myelodysplastic syndromes”[Mesh]  OR “MDS” OR “Myelodysplastic<br>Syndrome” OR “Syndromes Myelodysplastic”  OR “Dysmyelopoietic<br>Syndromes” OR “Dysmyelopoietic Syndrome” OR “Syndrome, Dysmyelopoietic”<br>OR “Syndromes, Dysmyelopoietic” OR “Hematopoetic Myelodysplasia” OR<br>“Hematopoetic Myelodysplasias” OR “Myelodysplasia, Hematopoetic” OR<br>“Myelodysplasias, Hematopoetic”||  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
||#3 "Blood Transfusion"[Mesh] OR “Blood Transfusions” OR “Transfusion,<br>Blood” OR “Transfusions, Blood”<br>#4 "Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR “Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR “clinical trials as topic” [Mesh] OR<br>“placebo”[tiab] OR “randomly”[tiab] OR “clinical trial”[tiab] OR "double-blind<br>method"[MeSH] OR "double-blind”[tiab]||
||Estratégia final: #1 AND #2 AND #3 AND #4||
|**Embase**<br>**18/01/2022**|# 1 - ('myelodysplastic syndrome'/exp OR 'mds (myelodysplastic syndrome)' OR<br>'bone marrow dysplasia' OR 'myelodysplasia' OR 'myelodysplastic syndrome' OR<br>'myelodysplastic syndromes' OR 'syndrome, myelodysplastic') AND ('blood<br>transfusion'/exp OR 'blood exchange' OR 'blood infusion' OR 'blood replacement'<br>OR 'blood retransfusion' OR 'blood transfusion' OR 'hemotherapy' OR<br>'multitransfusion' OR 'polytransfusion' OR 'retransfusion' OR 'transfusion blood'<br>OR 'transfusion therapy' OR 'transfusion, blood')  AND ("lenalidomide" OR<br>lenalidomide)<br>#2 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial'<br>OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,<br>randomized controlled' OR 'systematic review'/exp) AND [embase]/lim<br>Estratégia final: #1 AND #2|**96**|
|**Cochrane**<br>**Library**<br>**18/01/2022**|#1<br>MeSH descriptor: [Myelodysplastic Syndromes] this term only<br>#2<br>MeSH descriptor: [Lenalidomide] this term only|**2**|
||#3<br>MeSH descriptor: [Blood Transfusion] this term only<br>Estratégia final: #1 AND #2 AND #3||  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR e del(5q)  
- (b) Tipo de intervenção: Lenalidomida  
- (c) Tipos de estudos: RS ou ECR  
- (d) Desfechos: Resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resultados da busca:** -->
Para responder a dúvida clínica, foi considerada uma RSMA, a qual citou três publicações que respondiam a PICO estabelecida a _priori_ . O resultado de cada etapa do processo de seleção dos estudos foi apresentado na **Figura 3** .  
**Figura 3 -** Fluxograma de seleção dos estudos incluídos sobre o uso de agente imunomodulador lenalidomida em pacientes com SMD de baixo risco.  
<!-- Start of picture text -->
Identificados: Identificad<br>ledentificagao | | Embase(nNecino(P urea = 96) (n= 28) Duplicadosm  removidos (n = referénciasBusca de citagdes(nbiblograficas: = 0)<br>Excluidos (n = 99)<br>Rastreados (n = 110) Motivos: Rastreados (n = 0) || Excluidos (n = 0)<br>- Populacao diferente (n = 17)<br>=-ndoDesenhoapresentamos de estudo(n = 60)<br>desfechos de interesse (n = 3)<br>= outra intervengdo (n = 19) Elegiveis (n = 0)<br>Elegiveis (n = 11)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
Foram encontradas três publicações de um único RCT multicêntrico, MDS-004, que avaliou a eficácia e a segurança da lenalidomida em pacientes com SMD baixo risco e SMD risco intermediário-1 definidos IPSS com deleção de 5q, tratados com lenalidomida nas doses de 5 ou 10 mg/dia comparados com placebo<sup>9</sup> . Fenaux et al.<sup>9</sup> observaram que a lenalidomida, nas doses de 5 mg/dia e 10 mg/dia, mostrou resultado significativamente superior ao placebo em relação à resposta eritroide. Ademais, a publicação de Giagounidis et al.<sup>10</sup> , mostrou que os pacientes que utilizaram lenalidomida apresentaram melhora da sobrevida global, principalmente naqueles que tiveram resposta eritroide e apresentaram taxas de independência transfusional de concentrado de hemácias maior ou igual a 182 dias quando comparados aos pacientes não respondentes. Em relação à melhora nas taxas de independência transfusional de concentrado de hemácias maior ou igual a 182 dias, 57,4% e 37,2% dos pacientes que receberam 10 mg e 5 mg de lenalidomida, respectivamente, apresentaram resposta eritroide. A mesma resposta foi observada em 2,2% dos pacientes que receberam placebo<sup>10</sup> . A publicação de Revicki et al.<sup>11</sup> comparou os níveis de hemoglobina e a qualidade de vida ( _Functional Assessment of Cancer Therapy-Anemia/FACT-An_ ) de pacientes após 12 semanas de uso de 5 mg e 10 mg de lenalidomida e pacientes que utilizaram placebo. Houve associação entre o uso de lenalidomida e melhora desses parâmetros, com aumento de 5,7 pontos no _score_ de qualidade de vida entre os pacientes que utilizaram lenalidomida e redução de 2,8 pontos no _score_ entre os pacientes que utilizaram placebo.  
**QUESTÃO 4:** Devemos utilizar imunossupressão com imunoglobulina antitimocítica (ATG) combinada com ciclosporina em SMD de baixo risco?  
**Recomendação:** como a imunossupressão com imunoglobulina antitimocítica associada à ciclosporina não foi avaliada para tratamento desta condição no âmbito do SUS, este Protocolo não preconiza o uso destas tecnologias. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com SMD de baixo risco **Intervenção -** Globulina antitimocítica e ciclosporina **Comparador -** Suporte transfusional  
**Desfechos -** Resposta hematológica; sobrevida global  
**Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foi realizada uma busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro E** . Foram selecionadas as RSMAs e, na ausência de RSMA, ECR.  
**Quadro E -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de imunossupressão com imunoglobulina antitimocítica (ATG) em pacientes com SMD de baixo risco.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**<br>**Pubmed**<br>**18/01/2022**|#1 ("Cyclosporine"[Mesh]) AND "Antilymphocyte Serum"[Mesh]<br>#2 (“Myelodysplastic syndromes”[Mesh]  or “Myelodysplastic syndrome” or<br>MDS or myelodysplasia)|**28**|
||#3 (“Blood transfusion”[Mesh]  or “Blood transfusion”)<br>#4 "Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR “Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR “clinical trials as topic” [Mesh] OR<br>“placebo”[tiab] OR “randomly”[tiab] OR “clinical trial”[tiab] OR "double-blind<br>method"[MeSH] OR "double-blind”[tiab]<br>Estratégia final: #1 AND #2 AND #3 AND #4||
|**Embase**<br>**18/01/2022**|# 1 - ('myelodysplastic syndrome'/exp OR 'mds (myelodysplastic syndrome)' OR<br>'bone marrow dysplasia' OR 'myelodysplasia' OR 'myelodysplastic syndrome' OR<br>'myelodysplastic syndromes' OR 'syndrome, myelodysplastic') AND ('blood<br>transfusion'/exp OR 'blood exchange' OR 'blood infusion' OR 'blood replacement'<br>OR 'blood retransfusion' OR 'blood transfusion' OR 'hemotherapy' OR<br>'multitransfusion' OR 'polytransfusion' OR 'retransfusion' OR 'transfusion blood'<br>OR 'transfusion therapy' OR 'transfusion, blood')  AND ("Cyclosporine" AND<br>“Antilymphocyte Serum “)|**5**|  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
||#2 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial'<br>OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,<br>randomized controlled' OR 'systematic review'/exp) AND [embase]/lim<br>Estratégia final: #1 AND #2||
|**Cochrane**<br>**Library**|#1 MeSH descriptor: [Cyclosporine] this term only|**3**|
|**18/01/2022**|#2 MeSH descriptor: [Antilymphocyte Serum] this term only||
||#3 MeSH descriptor: [Blood Transfusion] this term only||
||Estratégia final: #1 AND #2 AND #3||  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para  
o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: Imunoglobulina antitimocítica (coelho e cavalo) e ciclosporina  
- (c) Tipos de estudos: RS ou ECR  
- (d) Desfechos: Resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem  
**Resultados da busca:**  
Para responder a dúvida clínica, foi considerada um ECR (citado na RS encontrada) que avaliou o uso de imunoglobulina antitimocítica de cavalo e ciclosporina, que se encaixou na PICO estabelecida a _priori_ . O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 4** .  
**Figura 4 -** Fluxograma de seleção dos estudos incluídos sobre o uso de imunossupressão com imunoglobulina antitimocítica (ATG) combinada com ciclosporina em SMD de baixo risco.  
<!-- Start of picture text -->
Identificados: Ieentiicados em<br>EmbaseModine/bubmed(n (n = 05) = 28) Duplicados removidos (n == 0) biogetias sesin=<br>Cochrane (n = 03) 1) ie<br>Excluidos (n = 33)<br>Excluidos (n= 1)<br>Rastreados (n = 36) Motivos: Rastreados (n = 1) | +]<br>- Populacdo diferente (n = 04)<br>= Desenho de estudo (n = 25)<br>- outa intervencao (n = 4)<br>Elegiveis (n = 0)<br>Elegiveis (n = 03)<br><!-- End of picture text -->  
Para responder a pergunta PICO proposta, foi incluído um estudo após a busca nas bases de dados, que trata-se de um ECR realizado por Passweg et al.<sup>12</sup> , 2011 (“ _Immunosuppressive Therapy for Patients With Myelodysplastic Syndrome: A Prospective Randomized Multicenter Phase III Trial Comparing Antithymocyte Globulin Plus Cyclosporine With Best Supportive Care—SAKK 33/99_ ”), que comparou a associação entre imunoglobulina antitimocítica de cavalo e ciclosporina versus o melhor tratamento de suporte possível em pacientes com SMD de risco baixo ou intermediário de acordo com o IPSS. Os resultados mostraram impacto positivo na resposta eritroide de aproximadamente um terço dos pacientes que utilizaram a associação dos dois medicamentos, os quais foram superiores aos resultados dos pacientes que receberam o tratamento de suporte padrão.  
**QUESTÃO 5:** Devemos utilizar transplante de células-tronco hematopoéticas (TCTH) alogênico para pacientes com SMD de baixo risco?  
**Recomendação:** <mark>no âmbito do Sistema Único de Saúde, o TCTH alogênico está indicado apenas para os pacientes com Síndrome</mark> Mielodisplásica de risco intermediário e alto. Por <mark>se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.</mark>  
A estrutura PICO para esta pergunta foi: **População -** Pacientes com SMD de baixo risco **Intervenção -** TCTH alogênico **Comparador -** Tratamento de suporte ou medicamentoso **Desfechos -** Resposta hematológica; sobrevida global **Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foi realizada uma busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro F** . Foram selecionadas as RSMA e, na ausência de RSMA, ECR.  
**Quadro F -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de transplante de células-tronco hematopoéticas (TCTH) alogênico em pacientes com SMD de baixo risco.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**<br>**Pubmed**<br>**18/01/2022**|#1 ("Bone Marrow Transplantation"[Mesh]) OR "Hematopoietic Stem Cell<br>Transplantation"[Mesh]<br>#2 (“Myelodysplastic syndromes”[Mesh]  OR “Myelodysplastic syndrome” OR<br>MDS OR myelodysplasia) = 39.451<br>#3 (“Blood transfusion”[Mesh]  OR “Blood transfusion”)<br>#4 "Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR “Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR “clinical trials as topic” [Mesh] OR<br>“placebo”[tiab] OR “randomly”[tiab] OR “clinical trial”[tiab] OR "double-blind<br>method"[MeSH] OR "double-blind”[tiab]|**41**|
||Estratégia final: #1 AND #2 AND #3 AND #4||
|**Embase**<br>**18/01/2022**|# 1 - ('myelodysplastic syndrome'/exp OR 'mds (myelodysplastic syndrome)' OR<br>'bone marrow dysplasia' OR 'myelodysplasia' OR 'myelodysplastic syndrome' OR<br>'myelodysplastic syndromes' OR 'syndrome, myelodysplastic') AND ('blood<br>transfusion'/exp OR 'blood exchange' OR 'blood infusion' OR 'blood replacement'<br>OR 'blood retransfusion' OR 'blood transfusion' OR 'hemotherapy' OR<br>'multitransfusion' OR 'polytransfusion' OR 'retransfusion' OR 'transfusion blood'<br>OR 'transfusion therapy' OR 'transfusion, blood')  AND ("Bone Marrow<br>Transplantation" OR "Hematopoietic Stem Cell Transplantation")<br>#2 ('meta analysis'/exp OR 'analysis, meta' OR 'meta analysis' OR 'meta-analysis'<br>OR 'metaanalysis' OR 'randomized controlled trial'/exp OR 'controlled trial,<br>randomized' OR 'randomised controlled study' OR 'randomised controlled trial'<br>OR 'randomized controlled study' OR 'randomized controlled trial' OR 'trial,<br>randomized controlled' OR 'systematic review'/exp) AND [embase]/lim<br>Estratégia final: #1 AND #2|**57**|
|**Cochrane**<br>**Library**<br>**18/01/2022**|#1 MeSH descriptor: [Bone Marrow Transplantation] OR MeSH descriptor:<br>[Hematopoietic Stem Cell Transplantation]<br>#2 MeSH descriptor: [Myelodysplastic Syndromes] this term only<br>#3 MeSH descriptor: [Blood Transfusion] this term only<br>Estratégia final: #1 AND #2 AND #3|**51**|  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias  
foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: TCTH alogênico  
- (c) Tipos de estudos: RS ou ECR  
- (d) Desfechos: Resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resultados da busca:** -->
Para responder a dúvida clínica, foi considerado um ensaio clínico randomizado que se encaixou na PICO estabelecida a  
_priori_ , e que foi recuperado por meio da estratégia de busca. O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 5** .  
**Figura 5 -** Fluxograma de seleção dos estudos incluídos sobre o uso de TCTH alogênico para pacientes com SMD de baixo risco.  
<!-- Start of picture text -->
IdentificadosEmbase(n = 57) Duplicados removidos (n ertencics bblogrficas<br>Medline/Pubmed (n = 41) = 04) Busta de citagoes(n = 0)<br>Cochrane (n = 51)<br>Excluidos (n = 144)<br>Rastreados (n = 145) Motivos: Rastreados (n = 0) Excluidos (n = 0)<br>= populagdo diferente (n =<br>47)<br>- desenho de estudo (n =<br>42)<br>[esimen=n | -52)- outranao apresentam intervengao os (n= Elegiveis (n = 0)<br>desfechos de interesse (n<br>= 02)<br>Sa<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
Após as buscas, foi selecionado um ECR que respondia à PICO, comparando pacientes com SMD de baixo risco e risco intermediário 1 e risco intermediário 2 definidos pelo IPSS tratados com cuidados de suporte e quimioterápicos versus aqueles tratados com transplante alogênico de células-tronco hematopoéticas (alo-TCTH)<sup>13</sup> . A remissão completa (53,8% vs 33,0%; p < 0,05), a qualidade de vida (53,8% vs 37,4%; p < 0,05) e a sobrevida global (79,0% vs 56,0%; p < 0,05) foram superiores no grupo TCTH quando comparado ao grupo controle. Diante desses achados, observa-se que o TCTH alogênico, quando comparado ao tratamento de suporte ou medicamentoso, apresenta resultado significativamente positivo na melhora da resposta eritroide e na sobrevida global em pacientes com SMD de baixo risco e risco intermediário 1 e intermediário 2 definidos pelo IPSS<sup>13</sup> .  
**QUESTÃO 6:** Devemos utilizar talidomida em pacientes com SMD de baixo risco?  
**Recomendação:** sugerimos manter a recomendação de utilizar a talidomida em pacientes com SMD de baixo risco (recomendação não graduada).  
A estrutura PICO para esta pergunta foi:  
**População -** Pacientes com SMD de baixo risco  
**Intervenção -** Talidomida  
**Comparador -** Suporte transfusional  
**Desfechos** - Resposta hematológica; sobrevida global  
**Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foi realizada uma busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro G** . Foram selecionadas as RSMA e, na ausência de RSMA, ECR.  
**Quadro G -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados sobre o uso de talidomida em pacientes com SMD de baixo risco.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**<br>**Pubmed**<br>**18/01/2022**|#1 Thalidomide"[Mesh] OR "Sedoval" OR "Thalomid"<br>#2 (“Myelodysplastic syndromes”[Mesh]  or “Myelodysplastic syndrome” or<br>MDS or myelodysplasia)<br>#3 (“Blood transfusion”[Mesh]  or “Blood transfusion”)<br>#4 "Clinical Trials as Topic"[Mesh] OR "Controlled Clinical Trial"[Publication<br>Type] OR “Randomized Controlled Trial"[Publication Type] OR "Clinical<br>Trial"[Publication Type] OR "Randomized Controlled Trials as Topic"[Mesh] OR<br>"Random Allocation"[Mesh] OR “clinical trials as topic” [Mesh] OR<br>“placebo”[tiab] OR “randomly”[tiab] OR “clinical trial”[tiab] OR "double-blind<br>method"[MeSH] OR "double-blind”[tiab]<br>Estratégia final: #1 AND #2 AND #3 AND #4|**25**|
|**Embase**<br>**18/01/2022**|#1 'myelodysplastic syndrome'/exp<br>#2 'thalidomide'<br>#3 'blood transfusion'<br>#4 #1 AND #2 AND #3<br>Estratégia final: #4 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim)<br>AND ('article'/it OR 'review'/it)|**16**|  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**Cochrane**|#1<br>MeSH descriptor: [Myelodysplastic Syndromes] explode all trees OR|**28**|
|**Library**|“Myelodysplastic Syndromes”||
|**18/01/2022**|||
||#2<br>MeSH descriptor: [Thalidomide] explode all trees OR “Thalidomide”||
||Estratégia final: #1 AND #2||  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: Talidomida  
- (c) Tipos de estudos: RS ou ECR  
- (d) Desfechos: Resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resultados da busca:** -->
Não foram identificados RSMA ou ECR que se responderam a PICO estabelecida a _priori_ . O resultado de cada etapa do processo de seleção dos estudos está apresentado na **Figura 6** .  
**Figura 6 -** Fluxograma de seleção dos estudos incluídos para responder à questão sobre o uso de talidomida em pacientes com SMD de baixo risco.  
<!-- Start of picture text -->
{dentificados: Identificados em<br>Embase(n = 16) Duplicados removidos (n =<br>Medline/Pubmed eeeeogrticas:<br>Cochrane (n = 28)(n = 25) 07) See teeeee te)<br>Excluidos (n = 60)<br>. Motivos:<br>exctuidos (n = 3)<br>Rastreados (n = 62) populagao diferente (n= 05) | | Rastreados (n = 3) | —+|<br>- desenho de estudo (n = 19)<br>= no apresentamos<br>desfechos de interesse (n =<br>02) ;<br>fone Elegiveis<br>Elegiveiseign(n= 2) = outa intervengo (n = 32) (n = 0)<br>- lingua estrangeira (n = 02)<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
Na busca realizada junto às bases de dados, inicialmente foram selecionados dois ECR potencialmente elegíveis. Entretanto, ao avaliar o texto completo desses estudos, observou-se que o estudo registrado pela Celgene Corporation (“ _A Study to Access the Safety/Efficacy of Thalidomide in the Treatment of Anemia in Patients With Myelodysplastic Syndromes_ ” NCT00050843) e o estudo registrado pelo pesquisador James L. Slack do Roswell Park Cancer Institute (“ _Thalidomide in_  
_Treating Anemia in Patients With Myelodysplastic Syndrome_ ” NCT00030550) não publicaram resultados primários ou secundários, o que impossibilitou suas inclusões na síntese das evidências. Adicionalmente, identificou-se três estudos potencialmente elegíveis, por meio da revisão das referências de outros estudos (Figura 6). Os três estudos precisaram ser <mark>excluídos por não responderem a PICO: uma revisão</mark> narrativa<sup>14</sup> ; um ensaio clínico de braço único<sup>15</sup> e um ensaio clínico em que os dois grupos de pacientes utilizaram a talidomida<sup>16</sup> .  
Diante da ausência de referências, verificou-se que o <mark>Protocolo de Uso de Talidomida no Tratamento da Síndrome Mielodisplásica (Portaria SAS/MS nº 493 de 11 de junho de 2015),</mark> contempla duas referências que abordam o uso de talidomida em pacientes com SMD<sup>17,18</sup> . Bouscary et al., 2005<sup>17</sup> descreveram um ensaio clínico de braço único, incluindo 47 pacientes com SMD de baixo risco tratados com talidomida (200 mg/dia, aumentado em 200 mg/dia a cada 4 semanas até a 16ª semana). Verificou-se que vinte e três pacientes apresentaram melhora hematológica: quatro respostas eritroides maiores, 15 respostas eritroides menores, seis respostas neutrofílicas maiores e duas respostas plaquetárias maiores. No geral, as respostas eritroides representaram 70% de todas as respostas observadas. No entanto, apenas quatro deles se tornaram independentes de transfusão. Entre os 23 respondedores, a duração média da resposta foi de 260 dias (intervalo de 30 a 650) e apenas um paciente não manteve a resposta. Independentemente da resposta hematológica, 37 de 47 (78%) pacientes tiveram que interromper a talidomida devido aos eventos adversos: 26 antes da semana 16 (55%), oito na semana 16 e três após a semana 16. Entre estes, 38% pararam com 200 mg, 35% a 400 mg, 18% a 600 mg e 9% a 800 mg. Os eventos adversos mais comuns foram sedação (72%), constipação (40%), fadiga (25%), tontura (25%) e câimbras musculares (12%). Sintomas de neuropatia periférica foram observados em 8% dos pacientes. A piora transitória da neutropenia foi detectada em 7% dos casos, mas resolvida espontaneamente em todos os casos. Não foi observada piora da trombocitopenia relacionada à talidomida. Cefaleias, náusea, reações cutâneas, desidratação, dispneia ou palpitações (os últimos sinais geralmente associados a anemia significativa), principalmente de grau 1–2 e reversíveis, foram observados em até 5% dos pacientes. Trombose venosa profunda não ocorreu neste estudo. Sessenta e cinco por cento dos pacientes experimentaram mais de dois eventos adversos.  
Já Tamburini et al., 2009<sup>18</sup> tiveram a intenção de avaliar pacientes que receberam uma dose diária de 200 mg de talidomida. No entanto, devido à alta proporção de pacientes que interromperam o tratamento antes da 12ª semana, foi realizada uma emenda no protocolo de estudo, permitindo o uso de 50 mg/dia. Portanto, os primeiros 59 pacientes receberam 200 mg/dia de talidomida e os últimos 28 pacientes receberam 50 mg/dia. Todos foram avaliados após 12 semanas de tratamento. No grupo de 200 mg/dia, 16/59 (27%) atingiram resposta na 12ª semana, incluindo nove respostas maiores e 7 menores. Devido aos eventos adversos, a redução da dose antes da 12ª semana foi necessária em 25 pacientes (23 reduziram para 100 mg/dia e 2 reduziram para 50 mg/dia). As respostas foram alcançadas em oito pacientes utilizando 200 mg/dia, seis pacientes utilizando 100 mg/dia e dois pacientes utilizando 50 mg/dia. Dentre os 28 pacientes que foram incluídos no estudo utilizando 50 mg/dia, a resposta eritroide foi obtida em 6/28 (21%), dos quais quatro pacientes apresentaram resposta eritroide maior e dois pacientes apresentaram resposta eritroide menor.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Justificativa para a recomendação:** -->
Manteve-se a recomendação do <mark>Protocolo de Uso de Talidomida no Tratamento da Síndrome Mielodisplásica (Portaria SAS/MS nº 493 de 11 de junho de 2015).</mark>

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Considerações gerais e para implementação:** -->
O grupo elaborador considerou que a utilização de talidomida é indicada em pacientes diagnosticados com SMD de baixo risco, em ambiente ambulatorial ou hospitalar, de acordo com os critérios clínicos de elegibilidade a seguir.  
Inclusão:  
● Pacientes do sexo masculino com diagnóstico de SMD de baixo risco, classificada como CID10 D46.0, D46.1 ou D46.4, refratárias à alfaepoetina.  
● Pacientes do sexo feminino em idade não reprodutiva com diagnóstico de SMD de baixo risco, classificada como CID10 D46.0, D46.1 ou D46.4, refratárias à alfaepoetina.  
● Pacientes do sexo feminino em idade reprodutiva com diagnóstico de SMD de baixo risco, classificada como CID10 D46.0, D46.1 ou D46.4, refratárias à alfaepoetina que estejam utilizando dois ou mais métodos contraceptivos, sendo pelo menos um deles um método de barreira, há pelo menos 1 mês antes do início do tratamento, além de dois testes de gravidez negativos, feitos com método sensível, conforme as orientações dadas no Anexo IV da Resolução da Diretoria Colegiada - RDC no. 11, de 22 de março de 2011, da Agência Nacional de Vigilância Sanitária – Anvisa, sendo o uso desses métodos desnecessário no caso de mulheres que tenham sido submetidas a procedimento de esterilização. Os métodos anticoncepcionais devem ser mantidos durante e pelo menos até 1 mês após o término do tratamento.  
Exclusão:  
- Pacientes do sexo feminino em idade reprodutiva que não estejam usando pelo menos dois métodos contraceptivos ou  
que estejam grávidas ou que tenham intenção de engravidar.  
- Pacientes com neuropatia periférica grau II ou maior.  
- Pacientes que não concordem ou não assinem o Termo de Responsabilidade/Esclarecimento, constante na RDC no.  
- 11/2011 da Anvisa.  
- Pacientes com hipersensibilidade à talidomida ou componentes da fórmula.  
Contraindicações:  
- Pacientes que apresentam hipersensibilidade ao medicamento ou aos seus componentes.  
- Pacientes com sinais ou sintomas clínicos prévios de neuropatia periférica.  
- Proibida para mulheres grávidas ou com chance de engravidar. Categoria de Risco X do FDA.  
- Casos especiais:  
- Ressalta-se que mesmo pequenas doses da substância talidomida (50 mg ou 100 mg) já são capazes de produzir  
- malformação fetal; portanto, mesmo com apenas 1 comprimido (100 mg) administrado à paciente grávida, o feto fica exposto aos graves efeitos de malformações.  
- Pacientes vivendo com HIV devem submeter-se a monitoramento da quantificação viral a cada 3 meses, pois pode haver  
- um aumento dos níveis de RNAm do vírus HIV.  
- Todos os doentes em uso de talidomida devem ser orientados a não operar máquinas ou dirigir carro, pois a talidomida  
- causa sonolência.  
● Precauções especiais devem ser tomadas, a critério médico, em pacientes que estejam em tratamento com os seguintes medicamentos: agentes quimioterápicos neurotóxicos, como cisplatina, etoposídeo, alcaloides da vinca ou taxanos; antirretrovirais conhecidamente associados à neuropatia periférica, como estavudina e didanosina; tuberculostáticos, como isoniazida, etambutol e etionamida; bortezomibe, cloranfenicol, dapsona, fenitoína, hidralazina, lítio, metronidazol, nitrofurantoína e óxido nitroso.  
- Existe pouca evidência do aparecimento de neuropatia periférica associada ao uso do medicamento em pacientes com  
- eritema nodoso hansênico.  
Esquemas de administração e tempos de tratamento:  
- Apresentação: Comprimidos de 100 mg  
● Posologia: Iniciar com 100 mg/dia por via oral, em dose única, durante 4 semanas, com aumento da dose a cada mês, conforme a tolerância do paciente. Doses acima de 200 mg/dia devem ser divididas em duas a quatro administrações diárias, 1 hora após as refeições. A dose de resposta ao tratamento varia entre 200 mg e 400 mg ao dia, sendo esta última a dose máxima diária. A redução da dose diária para 100 mg ou mesmo 50 mg foi associada à diminuição de eventos adversos.  
● Tempo de tratamento/critérios de interrupção: O tratamento deve ser mantido até quando houver ação terapêutica sem intolerância ao medicamento. Não havendo resposta terapêutica após tratamento durante 12 a 16 semanas, o tratamento deve ser suspenso.  
● Interação medicamentosa e com o álcool: o efeito sedativo da talidomida é aumentado quando o medicamento é utilizado associado a barbitúricos, clorpromazina e reserpina, bem como ao álcool. A talidomida reduz os efeitos clínicos produzidos pela histamina, serotonina, acetilcolina e prostaglandinas.  
● Eventos adversos: o principal evento adverso da talidomida é a teratogenicidade. Outros eventos adversos mais comuns são: cardiovasculares (edema, hipotensão ortostática), neurológicos (fadiga, sonolência, tontura, neuropatia periférica, confusão, ansiedade, agitação, febre, cefaleia), dermatológicos ( _rash_ cutâneo, descamação, síndrome de Stevens-Johnson, pele seca, acne), endócrinos (hipercalcemia), gastrointestinais (constipação, náusea, anorexia, alteração do peso, diarreia), hematológicos, principalmente nos doentes de AIDS (leucopenia, neutropenia, anemia, linfadenopatia), hepáticos (aumento de transaminases e bilirrubinas), neuromusculares (fraqueza, tremor, mialgia, parestesia, artralgia), renais (hematúria), respiratórios (dispneia), diaforese (sudorese excessiva) e complicações tromboembólicas, incluindo trombose venosa profunda e trombose pulmonar. Menos comumente, ocorre: edema facial, insônia, vertigem, dor, dermatite, prurido, alteração ungueal, dislipidemia, xerostomia, flatulência, dor dentária, impotência sexual, disfunção hepática, rigidez de nuca, dor cervical ou lombar, albuminúria. A neuropatia periférica pode deixar sequela, e deve-se estar atento a esta complicação, pois quanto mais precoce o seu diagnóstico, maiores são as chances de reversão do quadro. Em caso de neuropatia periférica grau I (parestesia, fraqueza ou perda de reflexos sem perda de função), deve-se considerar redução da dose; em caso de neuropatia periférica grau II ou maior (interferindo com a função), a talidomida deve ser suspensa. Exceto pela teratogenicidade, a maior parte dos eventos adversos são reversíveis com a suspensão do uso da talidomida.  
**QUESTÃO 7:** Devemos utilizar dosagem sérica de eritropoetina para monitorização dos pacientes com SMD de baixo risco em tratamento com estimulador de eritropoetina?  
**Recomendação:** como a dosagem de eritropoetina não foi avaliada para monitorização dos pacientes com SMD de baixo risco no âmbito do SUS, este Protocolo não recomenda este exame. Entretanto, por se tratar de uma dúvida clínica, foi realizada a síntese e a avaliação crítica das evidências.  
A estrutura PICO para esta pergunta foi: **População -** Pacientes com SMD de baixo risco **Intervenção -** Dosagem sérica de eritropoetina **Comparador -** Não realizar a dosagem sérica de eritropoetina **Desfechos -** Resposta hematológica; sobrevida global **Métodos e resultados da busca:**  
Para a tomada de decisão, foi estruturada e realizada uma RS para localizar as novas evidências acerca da questão clínica. Com base na pergunta PICO estruturada, foi realizada uma busca nas bases de dados EMBASE, MEDLINE (via Pubmed) e Cochrane até 18 de janeiro de 2022. As estratégias de busca estão descritas no **Quadro H** . Foram selecionadas as RSMA e, na ausência de RSMA, ECR e não-RCT.  
**Quadro H -** Estratégias de busca, de acordo com a base de dados, para identificação de revisões sistemáticas ou ensaios clínicos randomizados ou não sobre o uso de dosagem sérica de eritropoetina para monitorização dos pacientes com SMD de baixo risco em tratamento com estimulador de eritropoetina.  
|**Base de dados**|**Termos**|**Publicações**|
|---|---|---|
|**MEDLINE**<br>**via**<br>**Pubmed**<br>**18/01/2022**|#1  ( "Investigative Techniques/blood"[Mesh] OR "Investigative<br>Techniques/diagnosis"[Mesh] OR "Investigative Techniques/therapeutic<br>use"[Mesh] OR "Investigative Techniques/therapy"[Mesh] )<br>#2  ( "Erythropoietin/blood"[Mesh] OR "Erythropoietin/deficiency"[Mesh] OR<br>"Erythropoietin/isolation and purification"[Mesh] OR<br>"Erythropoietin/metabolism"[Mesh] OR<br>"Erythropoietin/pharmacokinetics"[Mesh] )<br>#3 ("Myelodysplastic syndromes"[Mesh] OR "Myelodysplastic syndrome" OR<br>MDS OR myelodysplasia) 39,506<br>#4 (sensitiv*[Title/Abstract] OR sensitivity and specificity[MeSH Terms] OR<br>diagnose[Title/Abstract] OR diagnosed[Title/Abstract] OR<br>diagnoses[Title/Abstract] OR diagnosing[Title/Abstract] OR<br>diagnosis[Title/Abstract] OR diagnostic[Title/Abstract] OR<br>diagnosis[MeSH:noexp] OR (diagnostic equipment[MeSH:noexp] OR diagnostic<br>errors[MeSH:noexp] OR diagnostic imaging[MeSH:noexp] OR diagnostic<br>services[MeSH:noexp]) OR diagnosis, differential[MeSH:noexp] OR<br>diagnosis[Subheading:noexp])  5,969,086<br>Estratégia final: #1 AND #2 AND #3 AND #4|**91**|
|**Embase**<br>**18/01/2022**|#1 'investigative procedures'/mj AND 'erythropoietin'/mj AND 'myelodysplastic<br>syndrome'/exp<br>#2 'erythropoietin'/mj AND 'myelodysplastic syndrome'/exp<br>#3 #2 AND [embase]/lim NOT ([embase]/lim AND [medline]/lim) AND<br>('article'/it OR 'review'/it)<br>Estratégia final: #1 AND #3|**38**|
|**Cochrane**<br>**Library**<br>**18/01/2022**|#1 MeSH descriptor: [Myelodysplastic Syndromes] this term only<br>#2 MeSH descriptor: [Erythropoietin] this term only<br>Estratégia final: #1 AND #2|**27**|  
Após obter os resultados das estratégias de busca, foram salvos arquivos RIF das plataformas de busca e importadas para o Rayyan. A seleção dos estudos foi realizada inicialmente por dois revisores independentes e, posteriormente, as discordâncias  
foram discutidas com um terceiro revisor.  
Foram considerados como critérios de elegibilidade:  
- (a) Tipos de participantes: Pacientes adultos (>18 anos) diagnosticados com SMD-BR  
- (b) Tipo de intervenção: Dosagem sérica de eritropoetina  
- (c) Tipos de estudos: RS ou ECR ou não-RCT.  
- (d) Desfechos: Resposta hematológica e sobrevida global  
- (e) Idioma: Não foi utilizada restrição em relação à linguagem

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resultados da busca:** -->
Não foram localizados RSMA ou ECR que responderam a PICO estabelecida a _priori_ . O resultado de cada etapa do  
processo de seleção dos estudos está apresentado na **Figura 7** .  
**Figura 7 -** Fluxograma de seleção dos estudos incluídos sobre o uso de dosagem sérica de eritropoetina para monitorização dos pacientes com SMD de baixo risco em tratamento com estimulador de eritropoetina.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Resumo das evidências:** -->
<mark>Após a busca nas bases de dados foi selecionado um estudo não-RCT realizado por Nakazaki et al., 2013</mark><sup>19</sup> <mark>para avaliação. Entretanto, esse artigo não foi incluído porque não respondia a PICO elaborada. Diante disso, foram selecionados três estudos em referências bibliográficas. O estudo de Park et al., 2020</mark><sup>20</sup> <mark>estava em duplicata e, após avaliação, não foi incluído por se tratar de uma revisão narrativa sobre o tema e não conseguir responder a PICO de maneira adequada. O estudo restante (Moyo et al., 2008)</mark><sup>21</sup> <mark>comparou medicamentos para estimular a eritropoese (alfaepoetina e darbapoetina), portanto, também foi excluído por não comparar dosagens de eritropoietina.</mark>

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **Justificativa para a recomendação:** -->
Devido à ausência de estudos randomizados controlados ou revisões sistemáticas com meta-análise que sustentem a indicação **,** não é possível demandar a avaliação da dosagem sérica de eritropoetina pela Conitec nem recomendar seu uso neste momento.

---

<!-- METADADOS: doenca: Síndrome Mielodisplásica de Baixo Risco | secao: **REFERÊNCIAS** -->
1.  Affentranger L, Bohlius J, Hallal M, Bonadies N. Efficacy of granulocyte colony stimulating factor in combination with erythropoiesis stimulating agents for treatment of anemia in patients with lower risk myelodysplastic syndromes: A systematic review. _Crit Rev Oncol Hematol_ . 2019;136(January):37-47. doi:10.1016/j.critrevonc.2019.01.021  
2.  Park S, Greenberg P, Yucel A, et al. Clinical effectiveness and safety of erythropoietin-stimulating agents for the treatment of low- and intermediate-1−risk myelodysplastic syndrome: a systematic literature review. _Br J Haematol_ . 2019;184(2):134-160. doi:10.1111/bjh.15707  
3.  Ferrini PR, Grossi A, Vannucchi AM, et al. A randomized double-blind placebo-controlled study with subcutaneous recombinant human erythropoietin in patients with low-risk myelodysplastic syndromes. _Br J Haematol_ . 1998;103(4):10701074. doi:10.1046/j.1365-2141.1998.01085.x  
4.  Thompson JA, Gilliland DG, Prchal JT, et al. Effect of recombinant human erythropoietin combined with granulocyte/macrophage colony-stimulating factor in the treatment of patients with myelodysplastic syndrome. _Blood_ . 2000;95(4):1175-1179. doi:10.1182/blood.v95.4.1175.004k51_1175_1179  
5.  Fenaux P, Santini V, Spiriti MAA, et al. A phase 3 randomized, placebo-controlled study assessing the efficacy and safety of epoetin-α in anemic patients with low-risk MDS. _Leukemia_ . 2018;32(12):2648-2658. doi:10.1038/s41375-018-0118-9  
6.  Gopalakrishna G, Mustafa RA, Davenport C, et al. Applying Grading of Recommendations Assessment, Development and Evaluation (GRADE) to diagnostic tests was challenging but doable. _J Clin Epidemiol_ . 2014;67(7):760-768. doi:10.1016/j.jclinepi.2014.01.006  
7.  Hutzschenreuter F, Monsef I, Kreuzer KA, Engert A, Skoetz N. Granulocyte and granulocyte-macrophage colony stimulating factors for newly diagnosed patients with myelodysplastic syndromes. _Cochrane Database Syst Rev_ . 2016;2016(2). doi:10.1002/14651858.CD009310.pub2  
8.  Greenberg P, Taylor K, Lardon R, KoeDler P, Negrin R, Saba H  et al. Phase III randomized multicenter trial of G- CSF vs. observation for myelodysplastic syndromes (MDS). _Blood_ . 1993;(Suppl:196a.).  
9.  Fenaux P, Giagounidis A, Selleslag D, et al. A randomized phase 3 study of lenalidomide versus placebo in RBC  
transfusion-dependent patients with Low-/Intermediate-1-risk myelodysplastic syndromes with del5q. _Blood_ . 2011;118(14):3765-3776. doi:10.1182/blood-2011-01-330126  
10.  Giagounidis A, Mufti GJ, Mittelman M, et al. Outcomes in RBC transfusion-dependent patients with Low/Intermediate-1-risk myelodysplastic syndromes with isolated deletion 5q treated with lenalidomide: A subset analysis from the MDS-004 study. _Eur J Haematol_ . 2014;93(5):429-438. doi:10.1111/ejh.12380  
11.  Revicki DA, Brandenburg NA, Muus P, Yu R, Knight R, Fenaux P. Health-related quality of life outcomes of lenalidomide in transfusion-dependent patients with Low- or Intermediate-1-risk myelodysplastic syndromes with a chromosome 5q deletion: Results from a randomized clinical trial. _Leuk Res_ . 2013;37(3):259-265. doi:10.1016/j.leukres.2012.11.017  
12.  Passweg JR, Giagounidis AAN, Simcock M, et al. Immunosuppressive therapy for patients with myelodysplastic syndrome: A prospective randomized multicenter phase III trial comparing antithymocyte globulin plus cyclosporine with best supportive care - SAKK 33/99. _J Clin Oncol_ . 2011;29(3):303-309. doi:10.1200/JCO.2010.31.2686  
13.  Yu Z-P, Ding J-H, Sun A-N, Ge Z, Chen B-A, Wu D-P. A Randomized Study Comparing Stem Cell Transplantation Versus Conventional Therapy for Low- and Intermediate-Risk Myelodysplastic Syndromes Patients. _Stem Cells Dev_ . 2017;26(15):1132-1139. doi:10.1089/scd.2017.0031  
14.  Musto P. Thalidomide therapy for myelodysplastic syndromes: Current status and future perspectives. _Leuk Res_ . 2004;28(4):325-332. doi:10.1016/j.leukres.2003.08.007  
15.  Chung CY, Lin SF, Chen PM, et al. Thalidomide for the treatment of myelodysplastic syndrome in Taiwan: Results of a phase II trial. _Anticancer Res_ . 2012;32(8):3415-3419.  
16.  Moreno-Aspitia A, Colon-Otero G, Hoering A, et al. Thalidomide therapy in adult patients with myelodysplastic  
syndrome: A North Central Cancer Treatment Group Phase II trial. _Cancer_ . 2006;107(4):767-772. doi:10.1002/cncr.22047  
17.  Bouscary D, Legros L, Tulliez M, et al. A non-randomised dose-escalating phase II study of thalidomide for the  
treatment of patients with low-risk myelodysplastic syndromes: The Thal-SMD-2000 trial of the Groupe Français des Myélodysplasies. _Br J Haematol_ . 2005;131(5):609-618. doi:10.1111/j.1365-2141.2005.05817.x  
18.  Tamburini J, Elie C, Park S, et al. Effectiveness and tolerance of low to very low dose thalidomide in low-risk  
myelodysplastic syndromes. _Leuk Res_ . 2009;33(4):547-550. doi:10.1016/j.leukres.2008.06.005  
19.  Nakazaki K, Nannya Y, Kurokawa M. Distribution of serum erythropoietin levels in lower risk myelodysplastic  
syndrome cases with anemia. _Int J Hematol_ . 2014;99(1):53-56. doi:10.1007/s12185-013-1485-7  
20.  Park S, Kelaidi C, Meunier M, Casadevall N, Gerds AT, Platzbecker U. The prognostic value of serum  
erythropoietin in patients with lower-risk myelodysplastic syndromes: a review of the literature and expert opinion. _Ann Hematol_ . 2020;99(1):7-19. doi:10.1007/s00277-019-03799-4  
21.  Moyo V, Lefebvre P, Duh MS, Yektashenas B, Mundle S. Erythropoiesis-stimulating agents in the treatment of anemia in myelodysplastic syndromes: a meta-analysis. _Ann Hematol_ . 2008;87(7):527-536. doi:10.1007/s00277-008-0450-7

---

