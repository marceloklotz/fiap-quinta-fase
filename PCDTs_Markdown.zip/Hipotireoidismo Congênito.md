<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: Geral -->
<!-- Start of picture text -->
ea<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: MINISTÉRIO DA SAÚDE -->
SECRETARIA DE ATENÇÃO ESPECIALIZADA À SAÚDE SECRETARIA DE CIÊNCIA, TECNOLOGIA E INSUMOS ESTRATÉGICOS EM SAÚDE  
PORTARIA CONJUNTA Nº 05, DE 16 DE ABRIL DE 2021.  
Aprova o Protocolo Clínico e Diretrizes Terapêuticas do Hipotireoidismo Congênito.  
O SECRETÁRIO DE ATENÇÃO ESPECIALIZADA À SAÚDE e o SECRETÁRIO DE CIÊNCIA, TECNOLOGIA, INOVAÇÃO E INSUMOSESTRATÉGICOS EM SAÚDE, no uso de suas atribuições,  
Considerando a necessidade de se atualizarem os parâmetros sobre o hipotireoidismo congênito no Brasil e diretrizes nacionais para diagnóstico, tratamento e acompanhamento dos indivíduos com esta doença;  
Considerando que os protocolos clínicos e diretrizes terapêuticas são resultado de consenso técnico-científico e são formulados dentro de rigorosos parâmetros de qualidade e precisão de indicação;  
Considerando o Registro de Deliberação N<sup><u>o</u></sup> 581/2021 e o Relatório de Recomendação n<sup><u>o</u></sup> 586 – Março de 2021 da Comissão Nacional de Incorporação de Tecnologias no SUS (CONITEC), a atualização da busca e avaliação da literatura; e  
Considerando a avaliação técnica do Departamento de Gestão e Incorporação de Tecnologias e Inovação em Saúde (DGITIS/SCTIE/MS), do Departamento de Assistência Farmacêutica e Insumos Estratégicos (DAF/SCTIE/MS) e do Departamento de Atenção Especializada e Temática (DAET/SAES/MS), resolvem:  
Art. 1º  Fica aprovado o Protocolo Clínico e Diretrizes Terapêuticas – Hipotireoidismo  
Congênita.  
Parágrafo único.  O Protocolo objeto deste artigo, que contém o conceito geral do hipotireoidismo congênito, critérios de diagnóstico, critérios de inclusão e de exclusão, tratamento e mecanismos de regulação, controle e avaliação, disponível no sítio <u>https://www.gov.br/saude/pt-br/assuntos/protocolos-clinicos-e-diretrizes-terapeuticas-pcdt, é de</u> caráter nacional e deve ser utilizado pelas Secretarias de Saúde dos Estados, do Distrito Federal e dos Municípios na regulação do acesso assistencial, autorização, registro e ressarcimento dos procedimentos correspondentes.  
Art. 2º  É obrigatória a cientificação do paciente, ou de seu responsável legal, dos potenciais riscos e efeitos colaterais relacionados ao uso de procedimento ou medicamento preconizados para o tratamento do hipotireoidismo congênito.  
Art. 3º  Os gestores estaduais, distrital e municipais do SUS, conforme a sua  
competência e pactuações, deverão estruturar a rede assistencial, definir os serviços referenciais e estabelecer os fluxos para o atendimento dos indivíduos com essa doença em todas as etapas descritas no anexo a esta Portaria, disponível no sítio citado no parágrafo único do art. 1º.  
Art. 4º  Esta Portaria entra em vigor na data de sua publicação.  
Art. 5º  Fica revogada a Portaria n<sup>o</sup> 1.161/SAS/MS, de 18 de novembro de 2015, publicada no Diário Oficial da União nº 222, de 20 de novembro de 2015, seção 1, página 81.  
SERGIO YOSHIMASA OKANE HÉLIO ANGOTTI NETO  
**ANEXO**

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **1. INTRODUÇÃO** -->
O Hipotireoidismo Congênito (HC) é a doença congênita mais comum do sistema endócrino e a principal causa de deficiência mental passível de prevenção no mundo. Mesmo quando diagnosticado precocemente, se não tratado e acompanhado de forma adequada, pode levar a complicações irreversíveis, como prejuízos no desenvolvimento mental e no crescimento da criança<sup>1</sup> .  
A glândula tireoide é responsável pela síntese e liberação dos hormônios tireoidianos, os quais são essenciais para o crescimento, desenvolvimento e metabolismo dos diversos órgãos e sistemas fisiológicos<sup>2</sup> .  
O principal hormônio produzido pela tireoide é a levotiroxina (T4). No entanto, o hormônio metabolicamente ativo é a triiodotironina (T3). Apenas 20% dos níveis circulantes de T3 são provenientes da tireoide, sendo o restante originário da desiodação do T4 em tecidos periféricos<sup>2</sup> .  
A função tireoidiana é controlada basicamente por dois mecanismos:  
1. Eixo hipotálamo-hipófise-tireoide: O hormônio hipotalâmico liberador da tireotrofina (TRH) estimula a síntese e liberação do hormônio estimulador da tireoide (TSH) pela hipófise, o qual promove a síntese e secreção de hormônios pela tireoide. Por outro lado, os níveis séricos dos hormônios tireoidianos regulam os níveis do TSH/TRH por meio de mecanismo de retroalimentação clássico ( _feed back_ ): a diminuição dos níveis séricos dos hormônios tireoidianos estimula a síntese/secreção de TSH/TRH, enquanto o oposto ocorre na presença de excesso de hormônios circulantes<sup>3</sup> ; e  
2. Autorregulação da síntese hormonal pela glândula tireoide: Ocorre conforme a disponibilidade de iodo inorgânico, que é essencial para a síntese dos hormônios tireoidianos.  
Na deficiência do iodo, ocorre o aumento na captação deste elemento pela glândula tireoide, como um meio de compensação, enquanto o excesso de iodo provoca uma perda transitória da função glandular<sup>4</sup> .  
O hipotireoidismo caracteriza-se pela diminuição dos níveis séricos dos hormônios tireoidianos, sendo classificado como<sup>2</sup> :  
a) primário - quando a deficiência dos hormônios tireoidianos ocorre devido à incapacidade parcial ou total de síntese hormonal pela glândula tireoide; e  
b) central - causado pela diminuição da produção ou bioatividade do TSH como resultado de disfunção hipotalâmica ou hipofisária.  
A incidência mundial do HC primário varia de 1:1.500 a 1:4.000 nascidos vivos, sendo maior entre hispânicos e menor entre negros<sup>5,6</sup> . Dados brasileirtos apontam para uma incidência de 1 caso para cada 2.595-4.795 nascidos vivos<sup>7,8</sup> . A maioria dos casos de HC é classificada como hipotireoidismo primário, e as causas são agrupadas em duas categorias principais: disgenesia tireoidiana, responsável por cerca de 85% dos casos, e dishormonogênese, que responde pelos 15% restantes<sup>9-11</sup> . A disgenesia é causada por uma ampla variedade de malformações estruturais que resultam em diferentes quadros clínicos de HC e é subdividida em agenesia (ausência  
completa de tecido tireoidiano), hemiogênese (ausência de um dos lobos da tireoide), hipoplasia (desenvolvimento defeituoso ou incompleto) ou ectopia (localização anômala) da tireoide.  
A disgenesia é causada por uma ampla variedade de malformações estruturais, que resultam em diferentes quadros clínicos de HC.  
Por outro lado, a dishormonogênese é causada por mutações deletérias em moléculas-chave da síntese dos hormônios tireoidianos, comprometendo a produção hormonal. O diagnóstico é estabelecido mediante a detecção de níveis séricos elevados do TSH, principal hormônio regulador da função tireoidiana<sup>12</sup> .  
Os casos de HC central são raros, ocorrendo em cerca de 1:16.000-1:100.000 recémnascidos vivos, sendo que, na maioria deles, esse quadro está associado a outros déficits hormonais hipofisários, com mutações em fatores transcricionais que envolvem a hipófise. No Brasil, o HC central ocorre aproximadamente entre 1:25.000 e 1:100.000 nascidos vivos. O diagnóstico é determinado  pelos baixos níveis séricos do T4 e TSH<sup>13-15</sup> .  
Hipotireoidismo neonatal transitório pode ocorrer devido ao tratamento das mães durante a gravidez com iodetos, substâncias antitireoidianas ou iodo radioativo. Também pode ocorrer em recém-nascidos muito prematuros que recebem nutrição parenteral total<sup>16</sup> .  
O Programa Nacional de Triagem Neonatal (PNTN), desenvolvido pelo Ministério da Saúde em parceria com as Secretaria de Saúde dos Estados, Distrito Federal e dos Municípios, provê a detecção do HC pela dosagem do TSH sérico em papel-filtro. A importância desse Programa se justifica pela necessidade do diagnóstico e tratamento precoces. O HC não tratado pode causar graves alterações no desenvolvimento da criança, nanismo e incapacidade intelectual grave, sendo que o comprometimento da função cognitiva pode ser irreversível<sup>14,16-18</sup> . O prognóstico depende, fundamentalmente, do tempo decorrido para início do tratamento, da gravidade do hipotireoidismo e da adequada manutenção dos níveis hormonais<sup>14,17,18</sup> .  
A identificação de fatores de risco e da doença em seu estágio inicial e o encaminhamento ágil e adequado para o atendimento especializado dão à Atenção Primária um caráter essencial para um melhor resultado terapêutico e prognóstico dos casos.  
Esse PCDT visa a estabelecer os critérios de diagnóstico e terapêuticos do hipotireoidismo congênito. A metodologia de busca e avaliação das evidências estão detalhadas no **Apêndice 1** .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **2. CLASSIFICAÇÃO ESTATÍSTICA INTERNACIONAL DE DOENÇAS E PROBLEMAS RELACIONADOS À SAÚDE (CID-10)** -->
- E03.0 Hipotireoidismo congênito com bócio difuso - E03.1 Hipotireoidismo congênito sem bócio

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **3. TRIAGEM NEONATAL** -->
No Brasil, a triagem neonatal é feita pela medida do TSH por imunofluometria, em amostra de sangue coletada em papel de filtro, cujos valores variam de 5 a 10 mUI/L (teste do pezinho)<sup>18</sup> . O PNTN padroniza o nível de corte para TSH em 10 mUI/L<sup>14,19</sup> . Nas crianças a termo e aparentemente saudáveis, a triagem neonatal deve ser procedida 48 horas após o nascimento ou até o 5º dia de vida, após a diminuição do pico fisiológico do TSH e do hormônio materno ter sido excretado e metabolizado<sup>1,14,16,20</sup> . A coleta realizada antes de 48 horas de vida pode levar a um excesso de falsos positivos.  
Para crianças a termo, com mais de 48 horas de vida e valores de TSH neonatal menores que 10mUI/L, nenhum seguimento é preconizado. A delimitação dos valores de TSH  
menores do que 10mUI/L na triagem evita resultados falsos negativos e os riscos de não tratar crianças com resultados limítrofes, que poderiam se beneficiar do tratamento<sup>14,21</sup> .  
A observação clínica não tem valor prático para o diagnóstico do HC, pois o quadro clínico se estabelece lentamente, em semanas ou meses, e a maioria das observações é inespecífica. Apenas 5% das crianças são diagnosticadas clinicamente no período neonatal. Um dos primeiros sinais é a icterícia neonatal prolongada. À medida que o tempo passa sem diagnóstico realizado, a criança apresenta-se letárgica, com choro rouco, engasgos frequentes, constipação, macroglossia, hérnia umbilical, fontanela ampla, hipotonia, movimentos lentos e pele seca. Poucos recém- nascidos com diagnóstico etiológico de disormonogênese apresentam bócio ao nascimento<sup>18</sup> . Resultados de TSH entre 10 e 20 mUI/L requerem a solicitação de uma segunda amostra e, na maioria das vezes, o segundo resultado é normal. Quando o resultado do TSH for maior que 20 mUI/L, a criança deve ser consultada e procedidos os testes para avaliação da função tireoidiana em amostras de sangue com a maior brevidade possível<sup>1,18,19</sup> . O  
**Quadro** resume os níveis de corte para convocar as crianças a fim de investigar as alterações da triagem neonatal.  
|**Quadro 1 -**Interpre|tação dos re<br>**Progra**<br>|sultados da triagem ne<br>congênito<br>**ma Nacional de Triagem**<br>|onatal na avaliação do hipotireoidismo<br>**Neonatal(PNTN) do Brasil**<br>|
|---|---|---|---|
|**Exame**|**Valor**<br>**(mUI/L)**|**Interpretação**|**Conduta**|
||<10|Resultado normal|Nenhuma|
||10-20|Resultado limítrofe|Convocarpara novo teste dopezinho|
|TSH|>20|Sugestivo de<br>hipotireoidismo|Convocar com urgência para consulta<br>médica e dosagem sérica (sangue<br>venoso)de T4 total ou livre e TSH|  
Fonte: Alves CAD et al. Hipotireoidismo Congênito: Triagem Neonatal. SBP, 2018<sup>22</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **4. DIAGNÓSTICO** -->
Os testes utilizados na triagem neonatal de HC não são diagnósticos, e o diagnóstico de HC é dado pela dosagem em amostra de sangue venoso de TSH e T4 total ou livre, feita com a maior brevidade possível. A realização da TNN e desses exames, nessa sequência, permite o diagnóstico precoce de mais de 99% dos casos<sup>14,18,20,22</sup> .  
Pacientes com valores de TSH acima de 10 mUI/L e T4 livre ou T4 total baixos confirmam o diagnóstico do HC primário e indicam o início do tratamento<sup>18</sup> . No  
**Quadro 2** , estão os valores de referência dos exames referidos entre 4 e 30 dias de vida<sup>22</sup> .  
A radiografia simples do joelho do feto pode ser feita para avaliar a gravidade do hipotireoidismo intrauterino, pela presença ou ausência das epífises femoral ou tibial<sup>1</sup> .  
**Quadro 2** - Valores de referência para TSH, T4 TOTAL, T4 livre e tireoglobulina no período neonatal  
|SUBSTÂNCIA|DOSAGEM SÉRICA (SANGUE|
|---|---|
||VENOSO)|
|TSH|< 9 mUI/L|  
|T4 livre|0,8-2,3 ng/dL|
|---|---|
|T4 total|7-16µg/dL|
|Tireoglobulina|2,0-35,0 ng/dL|  
Fonte: PNTN, Brasil.<sup>22</sup>  
Para que seja determinada a etiologia do HC, que em torno de 90% dos casos é do tipo primário, está indicada a ultrassonografia (US) cervical (preferencialmente com Doppler) ou a cintilografia da tireoide, e a dosagem da tireoglobulina.  
A investigação se inicia com a US cervical, a se complementar com a cintilografia da tireoide nos casos em que a US não for suficiente para determinar o diagnóstico. A impossibilidade de se proceder aos exames para determinação etiológica não deve atrasar o início do tratamento<sup>1,20,23</sup> .  
Nesses casos, inicia-se o tratamento, postergando-se a determinação da causa do HC para após os 3 anos de vida da criança, quando a suspensão da levotiroxina pode ser feita e a investigação completada<sup>1,18</sup> . O  
**Quadro** 3 mostra o diagnóstico diferencial do HC.  
**Quadro 3 -** Diagnóstico diferencial do hipotireoidismo congênito  
|**Características principais**|**Outros achados**|**Provável diagnóstico**|
|---|---|---|
|TSH aumentado,<br>T4 ou T4 livre diminuído| Tireoglobulina reduzida;<br> ultrassonografia sem tireoide em local<br>típico; e<br> idade óssea atrasada.|Atireose|
|TSH aumentado,<br>T4 ou T4 livre diminuído| Tireoglobulina mensurável;<br> ultrassonografia sem tireoide em local<br>típico; e<br> idade óssea normal ou atrasada.|Ectopia|
|TSH aumentado,<br>T4 ou T4 livre diminuído| Tireoglobulina mensurável;<br> ultrassonografia com tireoide tópica e<br>de volume reduzido; e<br> idade óssea normal ou atrasada.|Hipoplasia|
|TSH aumentado,<br>T4 ou T4 livre diminuído| Tireoglobulina normal ou elevada;<br> ultrassonografia com tireoide tópica<br>normal ou aumentada; e<br> idade óssea normal ou atrasada.|Disormoniogênese|
|TSH aumentado,<br>T4 ou T4 livre diminuído<br>ou normal| Tireoglobulina normal;<br> ultrassonografia com tireoide tópica e<br>normal; e<br> idade óssea normal.|Hipotireoidismo<br>Transitório|  
Fonte: Alves CAD et al. Sociedade Brasileira de Pediatria, 2018<sup>22</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **5. CRITÉRIOS DE INCLUSÃO** -->
Serão incluídos neste Protocolo os pacientes que apresentarem diagnóstico laboratorial confirmado de hipotireoidismo congênito por meio da dosagem sérica de TSH e T4 total ou livre, independentemente da causa etiológica.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **6. CRITÉRIOS DE EXCLUSÃO** -->
Confirmado o diagnóstico de hipotireoidismo congênito, não há critérios de exclusão deste Protocolo.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **7. CASOS ESPECIAIS** -->
Evidências de diferentes programas de triagem neonatal indicam que, pelo incompleto desenvolvimento do eixo hipotálamo-hipófisário, a taxa de HC foi maior em recémnascidos pré-termo e com baixo peso ao nascer do que nos nascidos normais. Além disso, muitas vezes esses pacientes se encontram internados em unidade de terapia intensiva e são submetidos a intervenções com potencial de alterar o resultado dos exames utilizados para o diagnóstico do HC.  
Por essas razões, o diagnóstico pode ser mais difícil e o exame deve ser repetido com um mês de vida ou na alta hospitalar, o que ocorrer primeiro. Ou então proceder-se à triagem tripla com coleta no 5º, 10º e 30º dias de vida para melhor avaliação<sup>1,14,16,20,24</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **8. TRATAMENTO** -->
O tratamento do HC é feito com levotiroxina. Com boa absorção por via oral e com meia-vida de aproximadamente sete dias, a levotiroxina é administrada em dose única diária<sup>18</sup> . Devem sempre ser utilizados comprimidos de levotiroxina, uma vez que não existem soluções líquidas do hormônio aprovadas no Brasil<sup>1,18</sup>  
Impõe-se que o tratamento seja iniciado o mais precocemente possível, idealmente nos primeiros 14 dias de vida, após a coleta de sangue para os exames diagnósticos confirmatórios, e com doses elevadas de levotiroxina.<sup>23,25</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **8.1. Fármaco** -->
**-** Levotiroxina sódica: comprimidos de 12,5; 25; 37,5; 50 e 100 mcg.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **8.2. Esquema de administração** -->
A dose de levotiroxina varia de acordo com a idade e peso corporal do paciente. Crianças mais jovens necessitam de doses mais elevadas do que crianças maiores e adultos<sup>16,22,26</sup> .  
O tratamento inicia-se com a dose-padrão de 10-15 mcg/kg via oral, uma vez por dia, e esta deve ser ajustada periodicamente de acordo com os controles laboratoriais (ver item 9. Monitoramento). Doses maiores (entre 12-17 mcg/kg, por exemplo) são usadas para iniciar o tratamento dos pacientes com hipotireoidismo mais grave (menores níveis de T4 livre). A dose média para recém-nascido (RN) a termo é de 50 mcg/dia e para RN pré-termo, de 25-37,5 mcg/dia<sup>1,16,18,22</sup> .  
Para RN e lactentes, o comprimido de levotiroxina deve ser triturado, misturado com um pouco de água ou leite materno e administrado com uma colher. Não diluir na mamadeira. A dose pode ser administrada pela manhã ou à tarde, de preferência antes das refeições. Se a criança vomitar logo em seguida, preconiza-se repetir a mesma dose da levotiroxina<sup>22</sup> .  
Deve ser evitada a administração concomitante com leite de soja, ferro e cálcio na forma de suplementos alimentares, por interferir em sua absorção. O aleitamento materno deve ser mantido. Mães que usam medicamentos antitireoidianos podem também manter a  
amamentação de seus filhos, mesmo que eles tenham hipotireoidismo. Se houver insuficiência adrenal concomitante, a reposição de levotiroxina só deve ser iniciada 3-5 dias após o início da corticoterapia para evitar a precipitação de uma crise adrenal<sup>22</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **8.3** . **Benefícios esperados** -->
O tratamento do HC leva ao desenvolvimento natural da criança e mesmo à recuperação do ganho da estatura e do peso e melhora do desenvolvimento neuropsicomotor, se chegaram a se observar. Os benefícios são maiores quando o tratamento é iniciado precocemente e com doses adequadas de levotiroxina<sup>16,23</sup> .

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **9. MONITORAMENTO** -->
O acompanhamento dos pacientes deve incluir a avaliação clínica do desenvolvimento estaturoponderal e neuropsicomotor e o controle laboratorial de função tireoidiana.  
O tratamento deve ser monitorado laboratorialmente por meio da determinação das concentrações plasmáticas de TSH e T4 livre ou T4 total. Seu objetivo é assegurar os crescimento e desenvolvimento adequados, mantendo os valores de TSH e T4 dentro da faixa de referência para a idade. A frequência do monitoramento deve ser baseada em dados clínicos e laboratoriais, conforme preconizado no **Quadro 4** . Para valores elevados de TSH, preconiza-se o aumento da dose de levotiroxina e reavaliação laboratorial após 4 semanas. Reajustes de dose deverão ser feitos com base nos resultados dos exames de TSH e T4, e avaliação clínica do indivíduo. A coleta dos exames deve ser feita antes da administração da levotiroxina<sup>16</sup> .  
O tratamento deve ser mantido por toda a vida do indivíduo. Nos casos em que há suspeita de hipotireoidismo neonatal transitório, o tratamento pode ser suspenso após os três anos de idade por um curto período, com o objetivo de reavaliar a função tiroidiana. Esses casos incluem pacientes sem etiologia do hipotireoidismo definida por exame de imagem (especialmente se for demonstrada tireoide normal à US), pacientes com quadro clínico e laboratorial inicial duvidoso e pacientes que não precisaram de aumento de dose de tiroxina durante o seguimento<sup>1</sup> . Após um mês da suspensão do tratamento, devem-se proceder a três avaliações seriadas de TSH, com intervalos mensais. Caso os valores se mantenham <5 mUI/L nas três medidas, o diagnóstico de HC transitório é confirmado<sup>**22**</sup> .  
**Quadro 4** - Monitoramento laboratorial<sup>22</sup>

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **Dosar T4 total ou livre e TSH** -->
- Em 2 e 4 semanas após o início da terapia.  
- Repetir:  
- Entre 0 e 6 meses de idade: a cada 1 a 2 meses.  
- Entre 6 meses e 3 anos de idade: a cada 2 a 3 meses.  Em > 3 anos: a cada 6 a 12 meses.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **Dosagens adicionais de T4 total ou livre e TSH** -->
- 4 semanas após cada mudança de dose.  
- Se a regularidade do tratamento for questionada.  
- Se valores hormonais forem anormais.  
_A coleta de sangue deve ser feita antes de administrar a levotiroxina. Caso ela tenha sido administrada, aguardar no mínimo 4 horas para coletar o sangue._  
O **Quadro 5** mostra as metas de tratamento do HC nos 3 primeiros anos de vida<sup>22</sup> .  
**Quadro 5 -** Metas do tratamento para os primeiros 3 anos de vida  
<!-- Start of picture text -->
- Assegurar os crescimento e desenvolvimento adequados.<br> - Manter os hormônios tireoidianos dentro do valor de referência desejado:<br> T4 livre entre 1,4 ng/dL  a 2,3 ng/dL ou<br> T4 total entre 10 μg/dL e 16 μg/dL<br> - Manter o TSH dentro do valor de referência desejado:<br> TSH entre 0,4 mUI/L e 4 mUI/L<br><!-- End of picture text -->

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **10. REGULAÇÃO/CONTROLE/AVALIAÇÃO PELO GESTOR** -->
Devem ser observados os critérios de inclusão e exclusão de pacientes neste Protocolo, a duração e o monitoramento do tratamento, bem como a verificação periódica das doses prescritas e dispensadas e a adequação de uso do medicamento.  
Conforme definido no PNTN, os Serviços de Referência em Triagem Neonatal/Acompanhamento e Tratamento de Doenças Congênitas Tipo I, II ou III – grupo em que se inclui o HC – são os responsáveis pela realização da triagem dos pacientes, assim como para seu tratamento e acompanhamento.  
Verificar na Relação Nacional de Medicamentos Essenciais (RENAME) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **11. TERMO DE ESCLARECIMENTO E RESPONSABILIDADE (TER)** -->
Deve-se informar ao paciente, ou seu responsável legal, sobre os potenciais riscos, benefícios e efeitos adversos relacionados ao uso dos procedimentos e dos medicamentos preconizados neste Protocolo, inclusive levando-se em consideração as informações contidas no Termo de Esclarecimento e Responsabilidade (TER).

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **12. REFERÊNCIAS** -->
1. Léger J, Olivieri A, Donaldson M, Torresani T, Krude H, van Vliet G, et al. European Society for Paediatric Endocrinology consensus guidelines on screening, diagnosis, and management of congenital hypothyroidism. J Clin Endocrinol Metab. 2014;99(2):363-84.  
2. Melmed S, Koenig R, Rosen C, Auchus R, Goldfine A. Williams Textbook of Endocrinology: Section III: THYROID. 14th Edition, 2019, Elsevier  
3. Moura, E.G, Moura, C.P. Regulação da síntese e secreção de tireotrofina. Arq Bras Endocrinol Metab. 2004; 48 (1).  
4. Vaisman,M. et al. Enzimas envolvidas na organificação tireoidiana de iodo. Arq Bras Endocrinol Metab. 2004; 48 (1).  
5. Kiess W, Penke M, Gesing J, Stoltze A, Korner A, Pfaffle R, et al. Congenital hypothyroidism. J Pediatr Endocrinol Metab. 2018;31(6):595-6.  
6. Fagman H, Nilsson M. Morphogenesis of the thyroid gland. Mol Cell Endocrinol. 2010;323(1):35- 54.  
7. Ramos H, Nesi França S, Boldarine V, Pereira R, Chiamolera M, Camacho C, et al. Clinical and Molecular Analysis of Thyroid Hypoplasia: A Population-Based Approach in Southern Brazil. Thyroid : official journal of the American Thyroid Association. 2008;19:61-8.  
8. Silvestrin SM, Leone C, Leone CR. Detecting congenital hypothyroidism with newborn screening: the relevance of thyroid-stimulating hormone cutoff values. J Pediatr (Rio J). 2017;93(3):274-80.  
9. Gaudino R, Garel C, Czernichow P, Leger J. Proportion of various types of thyroid disorders among newborns with congenital hypothyroidism and normally located gland: a regional cohort study. Clin Endocrinol (Oxf). 2005;62(4):444-8.  
10. Szinnai G. Genetics of normal and abnormal thyroid development in humans. Best Pract Res Clin Endocrinol Metab. 2014;28(2):133-50.  
11. Devos H, Rodd C, Gagne N, Laframboise R, Van Vliet G. A search for the possible molecular mechanisms of thyroid dysgenesis: sex ratios and associated malformations. J Clin Endocrinol Metab. 1999;84(7):2502-6.  
12. Hannoush ZC, Weiss RE. Defects of Thyroid Hormone Synthesis and Action. Endocrinology and metabolism clinics of North America. 2017;46(2):375-88. 13. Cherella CE, Wassner AJ. Congenital hypothyroidism: insights into pathogenesis and treatment. International journal of pediatric endocrinology. 2017;2017:11-.  
14. Brasil MdS, Saúde. SdAà, Temática. DdAEe. Triagem Neonatal biológica: manual técnico. http://bvsms.saude.gov.br/bvs/publicacoes/triagemneonatalbiologicamanualtécnico.pdf: Brasília: Ministério da Saúde.; 2016.  
15. Benvenga S, Klose M, Vita R, Feldt-Rasmussen U. Less known aspects of central hypothyroidism: Part 2 - Congenital etiologies. J Clin Transl Endocrinol. 2018;14:5-11.  
16. Rose SR, Brown RS, Foley T, Kaplowitz PB, Kaye CI, Sundararajan S, et al. Update of newborn screening and therapy for congenital hypothyroidism. Pediatrics. 2006;117(6):2290-303. 17. Klein AH, Meltzer S, Kenny FM. Improved prognosis in congenital hypothyroidism treated before age three months. J Pediatr. 1972;81(5):912-5. 18. Maciel LM, Kimura ET, Nogueira CR, Mazeto GM, Magalhaes PK, Nascimento ML, et al. Congenital hypothyroidism: recommendations of the Thyroid Department of the Brazilian Society of Endocrinology and Metabolism. Arq Bras Endocrinol Metabol. 2013;57(3):184-92. 19. Brasil MdS, Saúde. SdAà, Especializada. DdA. Programa Nacional de Triagem Neonatal: oficinas regionais de qualificação da gestão. <u>http://bvsms.saude.gov.br/bvs/publicacoes/06</u> 1031 M1.pdf: Brasília: Ministério da Saúde.; 2006. 20. Hashemipour M, Hovsepian S, Ansari A, Keikha M, Khalighinejad P, Niknam N.  
Screening of congenital hypothyroidism in preterm, low birth weight and very low birth weight neonates: A systematic review. Pediatrics & Neonatology. 2018;59(1):3-14.  
21. Veisani Y, Sayehmiri K, Rezaeian S, Delpisheh A. Congenital hypothyroidism screening program in iran; a systematic review and metaanalysis. Iranian journal of pediatrics. 2014;24(6):665-72.  
22. Alves C, Cargnin K, de Paula L, Garcia L, Collet-Solberg P, Liberato Jr R, et al. Hipotireoidismo Congênito: Triagem Neonatal. Sociedade Brasileira de Pediatria. 2018;5:1-12.  
23. Rahmani K, Yarahmadi S, Etemad K, Koosha A, Mehrabi Y, Aghang N, et al. Congenital Hypothyroidism: Optimal Initial Dosage and Time of Initiation of Treatment: A Systematic Review. International journal of endocrinology and metabolism. 2016;14(3):e36080-e.  
24. Kucharska, A.M. Congenital hypothyroidism - Polish recommendations for therapy, treatment monitoring, and screening tests in special categories of neonates with increased risk of hypothyroidism. 2016;67(5):536-547.  
25. Ng SM, Anand D, Weindling AM. High versus low dose of initial thyroid hormone replacement for congenital hypothyroidism. Cochrane Database Syst Rev. 2009(1):Cd006972. 26. Gruters A, Krude H. Update on the management of congenital hypothyroidism. Horm Res. 2007;68 Suppl 5:107-11.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: LEVOTIROXINA -->
Eu, <u>(nome do [a] paciente), declaro</u> ter sido informado (a) sobre benefícios, riscos, contraindicações e principais efeitos adversos relacionados ao uso da **levotiroxina** indicada para o tratamento do **hipotireoidismo congênito** . Os   termos   médicos   foram   explicados   e   todas   as   dúvidas   foram   esclarecidas   pelo médico <u>(nome</u> do médico que  
prescreve).  
Assim, declaro que fui claramente informado (a) de que o medicamento que passo a receber pode trazer os seguintes benefícios:  
- Assegurar crescimentos e desenvolvimento adequados. - Manter hormônios tireoidianos dentro do valor de referência desejado.  
Fui também informado (a) a respeito das seguintes contraindicações, potenciais efeitos adversos e riscos:  
- Levotiroxina: medicamento classificado como fator de risco A para gestantes (pode ser utilizado durante a gravidez desde que sob prescrição médica).  
- Efeitos adversos da **levotiroxina** : geralmente estão relacionados a uma dose excessiva do medicamento e correspondem aos sintomas do hipertireoidismo. As reações mais comuns são palpitações, insônia, dor de cabeça, batimentos acelerados do coração e nervosismo. Podem ocorrer problemas circulatórios em prematuros de baixo peso e hipertensão intracraniana benigna particularmente em crianças.  
- Medicamento contraindicado em casos de hipersensibilidade (alergia) aos fármacos ou aos componentes da fórmula.  
Estou ciente de que este medicamento somente pode ser utilizado por mim, comprometendo-me a devolvê-lo caso não queira ou não possa utilizá-lo ou se o tratamento for interrompido. Sei também que continuarei a ser atendido (a), inclusive em caso de desistência do uso do medicamento.  
Autorizo o Ministério da Saúde e as Secretarias de Saúde a fazerem uso de informações relativas ao meu tratamento, desde que assegurado o anonimato. (   ) Sim     (   ) Não  
Meu tratamento constará do seguinte medicamento: (   ) Levotiroxina  
|Local:|Data:|
|---|---|
|Nome do paciente:||
|Cartão Nacional de Saúde:||
|Nome do responsável legal:||
|Documento de identificação do responsável legal:||  
Assinatura do paciente ou do responsável legal  
|Médico Responsável:<br>CRM:<br>Assinatura e carimbo do médico Data:|UF:|
|---|---|  
NOTA: Verificar na Relação Nacional de Medicamentos Essenciais (Rename) vigente em qual componente da Assistência Farmacêutica se encontra o medicamento preconizado neste Protocolo.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **1. Escopo e finalidade do Protocolo** -->
A atualização do Protocolo Clínico e Diretrizes Terapêuticas (PCDT) do Hipotireoidismo congênito iniciou- se com a reunião presencial para delimitação do escopo. O objetivo dessa reunião foi a discussão da atualização do referido PCDT.  
Essa reunião presencial contou com a presença de seis membros do Grupo Elaborador, três especialistas e três metodologistas, além de um representante de sociedade médica e quatro representantes do Comitê Gestor.  
A dinâmica da reunião foi conduzida com base no PCDT vigente (Portaria SAS/MS nº 1160 - 18/11/2015) e na estrutura de PCDT definida pela Portaria n° 375, de 10 de novembro de 2009. Cada seção do PCDT foi discutida entre o Grupo Elaborador com o objetivo de revisar as condutas diagnósticas e terapêuticas e identificar as tecnologias que poderiam ser consideradas nas recomendações.  
Foi estabelecido que as recomendações diagnósticas, de tratamento ou acompanhamento que utilizassem tecnologias previamente disponibilizadas no SUS não teriam questões de pesquisa definidas por se tratarem de práticas clínicas estabelecidas, exceto em casos de incertezas atuais sobre seu uso, casos de desuso ou oportunidades de desinvestimento. Como não foram elencadas novas questões de pesquisa para a revisão do PCDT, a relatoria do texto foi distribuída entre os médicos especialistas. Estes profissionais foram orientados a referenciar as recomendações com base nos estudos pivotais, meta-análises e diretrizes atuais que consolidam a prática clínica e a atualizar os dados epidemiológicos descritos no PCDT vigente.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **Inclusão da Levotiroxina sódica 12,5 e 37,5 mcg** -->
Em reunião de escopo para a revisão do PCDT da HC realizada em 11/09/2019, na qual estavam presentes metodologistas, especialistas em endocrinologia e membros do DGITIS, foi sugerida a avaliação da incorporação das apresentações de 12,5 e 37,5 mcg de levotiroxina sódica para os pacientes com HC.  
As apresentações de levotiroxina sódica disponíveis na Rename e indicadas no PCDT para o tratamento do HC são os comprimidos de 25, 50 e 100 mcg. A necessidade de ajustes posológicos de acordo com o crescimento da criança e dos níveis de TSH e T4 livre ou total mostrase frequente. A utilização de apresentações intermediárias reduz a necessidade de utilização de comprimidos partidos para complementação das doses, minimizando erros de administração, e permitindo ajustes de doses mais fidedignos à necessidade e o desperdício dos comprimidos.  
Tendo em vista que a levotiroxina sódica já está incorporada no Sistema Único de Saúde (SUS) e sua evidência de utilização no tratamento do HC já está bem estabelecida, não foi realizada revisão da literatura, mas somente a apresentação das posologias recomendadas para o tratamento e os valores das apresentações solicitadas, com cálculo de impacto orçamentário (AIO) em cinco anos.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **2. Equipe de elaboração e partes interessadas** -->
Além dos representantes do Ministério da Saúde do Departamento de Gestão e Incorporação de  
Tecnologias em Saúde do Ministério da Saúde (DGITIS/MS), participaram do desenvolvimento deste Protocolo metodologistas do Hospital Alemão Oswaldo Cruz (HAOC), colaboradores e especialistas no tema.  
Todos os presentes do Grupo Elaborador preencheram o formulário de Declaração  
de Conflitos de  
Interesse, que foram enviados ao Ministério da Saúde, como parte dos resultados. **Colaboração Externa**  
Representantes da Sociedade Brasileira de Endocrinologia e Metabologia (SBEM) e da Sociedade Brasileira de Pediatria (SBP) foram convidados a participar do processo de atualização do PCDT, sendo dada a opção de participar nas diversas fases de desenvolvimento do documento.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **3. Avaliação da Subcomissão Técnica de Protocolos Clínicos e Diretrizes Terapêuticas** -->
O documento elaborado foi apresentado à 82ª Reunião da Subcomissão de PCDT da Conitec, realizada no dia 08/09/2020 com a participação de áreas técnicas do Ministério da Saúde, que apresentou sugestões ao texto com vistas à avaliação e deliberação dessa Comissão, o que ocorreu à sua 91ª Reunião Ordinária, em 07/10/2021.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **<u>4. Consulta Pública e Recomendação Final da Conitec</u>** -->
A Consulta Pública nº 57/2020, do Protocolo Clínico e Diretrizes Terapêuticas do Hipotiroidismo Congênito, foi realizada entre os dias 04/11/2020 a 11/11/2020, com prorrogação até 30/11/2020. Foram recebidas 05 (cinco) contribuições no total, mais contribuições enviada por e-mail acerca de uma seção específica do PCDT, tendo sido analisadas.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **<u>Recomendação Final da Conitec</u>** -->
A recomendação final da Conitec ocorreu em sua 94ª Reunião da Conitec, em 03/02/2021, a partir da qual foi publicado o Relatório de Recomendação N<sup>o</sup> 586 - Março de 2021.

---

<!-- METADADOS: doenca: Hipotireoidismo Congênito | secao: **5. Busca da evidência e recomendações** -->
Para auxiliar na atualização do PCDT, foram realizadas buscas na literatura nas bases de dados PUBMED e Embase, conforme disposto no **Quadro A** .  
**Quadro A -** Descrição das buscas, resultados e estudos selecionados  
|**Base**|**Estratégia**<br>|**Localizados**|**Duplicados**|**Selecionados**|
|---|---|---|---|---|
|Medline (via<br>PubMed)<br>Data da busca:<br>08/10/2019|"Congenital<br>Hypothyroidism"[Mesh]<br>OR "Congenital<br>Hypothyroidism"[All Fields]<br>AND ((Guideline[ptyp] OR<br>Meta-Analysis[ptyp] OR<br>systematic[sb]) AND<br>"2014/10/13"[PDat] :<br>"2019/10/11"[PDat])|<br>7|7|6<br>**Motivo das**<br>**exclusões:**<br>- sem relação com<br>escopo do PCDT|
|Embase<br>Data da busca:<br>08/10/2019|('congenital<br>hypothyroidism'/exp OR<br>'congenital<br>hypothyroidism') AND<br>([cochrane review]/lim OR<br>[systematic review]/lim OR<br>[meta analysis]/lim) AND<br>[embase]/lim AND [2014-<br>2019]/py|<br>19|||  
Outros estudos de conhecimento dos especialistas foram incluídos, para a atualização do item 7. Casos Especiais.

---

